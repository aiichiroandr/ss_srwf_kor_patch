#include "p_srwfin_installed_funcs.h"

namespace p_srwfin_installed {

void f_06026B14(SH2Context& c) {
    ran[505] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06026B14 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06026B16 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06026B18 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06026B1A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06026B1C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06026B1E sts.l pr,@-r15
    c.r[1] = ld32(0x06026BD0u);  // 06026B20 mov.l 0x06026BD0,r1
    c.r[2] = ld32(c.r[1]);  // 06026B22 mov.l @r1,r2
    c.r[1] = c.r[2];  // 06026B24 mov r2,r1
    c.r[1] += 1;  // 06026B26 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06026B28 mov.b @r1,r1
    c.r[2] += 2;  // 06026B2A add #2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06026B2C extu.b r1,r1
    c.r[8] = c.r[1];  // 06026B2E mov r1,r8
    c.r[8] <<= 8;  // 06026B30 shll8 r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06026B32 mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06026B34 extu.b r1,r1
    c.r[8] |= c.r[1];  // 06026B36 or r1,r8
    c.r[1] = ld32(0x06026BD4u);  // 06026B38 mov.l 0x06026BD4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06026B3Eu; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06026B3Eu) return; }  // 06026B3A jsr @r1 ; mov r15,r14
    c.r[1] = ld32(0x06026BD8u);  // 06026B3E mov.l 0x06026BD8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06026B40 mov.b @r1,r1
    c.r[11] = ld32(0x06026BDCu);  // 06026B42 mov.l 0x06026BDC,r11
    c.r[2] = ld32(c.r[11]);  // 06026B44 mov.l @r11,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06026B46 extu.b r1,r1
    c.r[1] <<= 2;  // 06026B48 shll2 r1
    c.r[1] <<= 2;  // 06026B4A shll2 r1
    c.r[3] = c.r[1];  // 06026B4C mov r1,r3
    c.r[3] += c.r[2];  // 06026B4E add r2,r3
    c.r[0] = c.r[1];  // 06026B50 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06026B52 mov.b @(r0,r2),r1
    c.r[3] += 1;  // 06026B54 add #1,r3
    c.r[10] = c.r[1] & 0xFFu;  // 06026B56 extu.b r1,r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06026B58 mov.b @r3,r1
    c.r[9] = c.r[1] & 0xFFu;  // 06026B5A extu.b r1,r9
    c.r[1] = c.r[8];  // 06026B5C mov r8,r1
    c.r[1] >>= 8;  // 06026B5E shlr8 r1
    c.r[1] += c.r[1];  // 06026B60 add r1,r1
    c.r[1] >>= 8;  // 06026B62 shlr8 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06026B64 tst r1,r1
    if (c.t) { goto L_06026B84; }  // 06026B66 bt 0x06026B84
    c.r[4] = (uint32_t)(int16_t)ld16(0x06026BCAu);  // 06026B68 mov.w 0x06026BCA,r4
    c.r[0] = ld32(0x06026BE0u);  // 06026B6A mov.l 0x06026BE0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06026B70u; c.r[4] &= c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06026B70u) return; }  // 06026B6C jsr @r0 ; and r8,r4
    c.r[3] = c.r[0] & 0xFFu;  // 06026B70 extu.b r0,r3
    c.r[2] = 0xFFFFFFFFu;  // 06026B72 mov #-1,r2
    c.r[1] = c.r[2] & 0xFFu;  // 06026B74 extu.b r2,r1
    c.t = c.r[3] == c.r[1];  // 06026B76 cmp/eq r1,r3
    if (c.t) { goto L_06026B84; }  // 06026B78 bt 0x06026B84
    c.r[1] = ld32(c.r[11]);  // 06026B7A mov.l @r11,r1
    c.r[3] <<= 2;  // 06026B7C shll2 r3
    c.r[3] <<= 2;  // 06026B7E shll2 r3
    c.r[0] = c.r[3];  // 06026B80 mov r3,r0
    st8(c.r[0] + c.r[1], c.r[2]);  // 06026B82 mov.b r2,@(r0,r1)
L_06026B84:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06026BCAu);  // 06026B84 mov.w 0x06026BCA,r1
    c.r[8] &= c.r[1];  // 06026B86 and r1,r8
    c.r[0] = ld32(0x06026BE4u);  // 06026B88 mov.l 0x06026BE4,r0
    c.r[6] = c.r[8];  // 06026B8A mov r8,r6
    c.r[5] = c.r[9];  // 06026B8C mov r9,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06026B92u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06026B92u) return; }  // 06026B8E jsr @r0 ; mov r10,r4
    c.r[3] = c.r[0] & 0xFFu;  // 06026B92 extu.b r0,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x06026BCCu);  // 06026B94 mov.w 0x06026BCC,r1
    c.t = c.r[3] == c.r[1];  // 06026B96 cmp/eq r1,r3
    { const bool k = c.t; c.r[2] = c.r[3]; if (k) { goto L_06026BB8; } }  // 06026B98 bt/s 0x06026BB8 ; mov r3,r2
    c.r[1] = ld32(0x06026BDCu);  // 06026B9C mov.l 0x06026BDC,r1
    c.r[1] = ld32(c.r[1]);  // 06026B9E mov.l @r1,r1
    c.r[2] <<= 2;  // 06026BA0 shll2 r2
    c.r[2] <<= 2;  // 06026BA2 shll2 r2
    c.r[2] += c.r[1];  // 06026BA4 add r1,r2
    c.r[2] += 3;  // 06026BA6 add #3,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06026BA8 mov.b @r2,r0
    c.r[1] = ld32(0x06026BD8u);  // 06026BAA mov.l 0x06026BD8,r1
    c.r[0] &= 0x7Fu;  // 06026BAC and #127,r0
    st8(c.r[2], c.r[0]);  // 06026BAE mov.b r0,@r2
    st8(c.r[1], c.r[3]);  // 06026BB0 mov.b r3,@r1
    c.r[1] = ld32(0x06026BE8u);  // 06026BB2 mov.l 0x06026BE8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06026BB8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06026BB8u) return; }  // 06026BB4 jsr @r1 ; nop
L_06026BB8:
    c.r[15] = c.r[14];  // 06026BB8 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06026BBA lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06026BBC mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06026BBE mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06026BC0 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06026BC2 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06026BCEu);  // 06026BC4 mov.w 0x06026BCE,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06026BC6 rts ; mov.l @r15+,r8
}

void f_06026BEC(SH2Context& c) {
    ran[506] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06026BEC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06026BEE sts.l pr,@-r15
    c.r[1] = ld32(0x06026C0Cu);  // 06026BF0 mov.l 0x06026C0C,r1
    c.r[1] = ld32(c.r[1]);  // 06026BF2 mov.l @r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06026BF4 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06026BF6 extu.b r1,r0
    c.r[0] <<= 2;  // 06026BF8 shll2 r0
    c.r[1] = ld32(0x06026C10u);  // 06026BFA mov.l 0x06026C10,r1
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 06026BFC mov.l @(r0,r1),r0
    { const uint32_t x = c.r[0]; c.pr = 0x06026C02u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06026C02u) return; }  // 06026BFE jsr @r0 ; mov r15,r14
    c.r[15] = c.r[14];  // 06026C02 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06026C04 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06026C06 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[0] & 0xFFFFu; c.pc = x; return; }  // 06026C08 rts ; extu.w r0,r0
}

void f_06026C14(SH2Context& c) {
    ran[507] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06026C14 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06026C16 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06026C18 mov r15,r14
    c.r[0] = ld32(0x06026C30u);  // 06026C1A mov.l 0x06026C30,r0
    c.r[5] = 0x1u;  // 06026C1C mov #1,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06026C22u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06026C22u) return; }  // 06026C1E jsr @r0 ; mov #0,r4
    c.r[15] = c.r[14];  // 06026C22 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06026C24 lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x06026C2Cu);  // 06026C26 mov.w 0x06026C2C,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06026C28 rts ; mov.l @r15+,r14
}

void f_06026C34(SH2Context& c) {
    ran[508] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06026C34 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06026C36 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06026C38 mov r15,r14
    c.r[0] = ld32(0x06026C5Cu);  // 06026C3A mov.l 0x06026C5C,r0
    c.r[5] = 0x0u;  // 06026C3C mov #0,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06026C42u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06026C42u) return; }  // 06026C3E jsr @r0 ; mov #1,r4
    c.r[1] = ld32(0x06026C60u);  // 06026C42 mov.l 0x06026C60,r1
    c.r[1] = ld32(c.r[1]);  // 06026C44 mov.l @r1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 06026C46 mov.b @r1+,r2
    c.r[3] = ld32(0x06026C64u);  // 06026C48 mov.l 0x06026C64,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06026C4A mov.b @r1,r1
    c.r[15] = c.r[14];  // 06026C4C mov r14,r15
    st8(c.r[3], c.r[1]);  // 06026C4E mov.b r1,@r3
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06026C50 lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x06026C58u);  // 06026C52 mov.w 0x06026C58,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06026C54 rts ; mov.l @r15+,r14
}

void f_06026C68(SH2Context& c) {
    ran[509] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06026C68 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06026C6A sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06026C6C mov r15,r14
    c.r[0] = ld32(0x06026C90u);  // 06026C6E mov.l 0x06026C90,r0
    c.r[5] = 0x0u;  // 06026C70 mov #0,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06026C76u; c.r[4] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06026C76u) return; }  // 06026C72 jsr @r0 ; mov #2,r4
    c.r[1] = ld32(0x06026C94u);  // 06026C76 mov.l 0x06026C94,r1
    c.r[1] = ld32(c.r[1]);  // 06026C78 mov.l @r1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 06026C7A mov.b @r1+,r2
    c.r[3] = ld32(0x06026C98u);  // 06026C7C mov.l 0x06026C98,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06026C7E mov.b @r1,r1
    c.r[15] = c.r[14];  // 06026C80 mov r14,r15
    st8(c.r[3], c.r[1]);  // 06026C82 mov.b r1,@r3
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06026C84 lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x06026C8Cu);  // 06026C86 mov.w 0x06026C8C,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06026C88 rts ; mov.l @r15+,r14
}

void f_06026C9C(SH2Context& c) {
    ran[510] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06026C9C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06026C9E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06026CA0 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06026CA2 mov r15,r14
    c.r[6] = 0x0u;  // 06026CA4 mov #0,r6
    c.r[8] = 0x0u;  // 06026CA6 mov #0,r8
    c.r[5] = (uint32_t)(int16_t)ld16(0x06026D68u);  // 06026CA8 mov.w 0x06026D68,r5
L_06026CAA:
    c.r[1] = ld32(0x06026D70u);  // 06026CAA mov.l 0x06026D70,r1
    c.r[3] = c.r[6];  // 06026CAC mov r6,r3
    c.r[3] <<= 2;  // 06026CAE shll2 r3
    c.r[3] <<= 2;  // 06026CB0 shll2 r3
    c.r[7] = ld32(c.r[1]);  // 06026CB2 mov.l @r1,r7
    c.r[2] = c.r[3];  // 06026CB4 mov r3,r2
    c.r[2] += c.r[7];  // 06026CB6 add r7,r2
    c.r[1] = c.r[2];  // 06026CB8 mov r2,r1
    c.r[1] += 3;  // 06026CBA add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06026CBC mov.b @r1,r1
    c.r[0] = c.r[1];  // 06026CBE mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06026CC0 shlr r0
    c.r[0] &= 0x3u;  // 06026CC2 and #3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06026CC4 tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[6]; if (k) { goto L_06026D3A; } }  // 06026CC6 bf/s 0x06026D3A ; mov r6,r1
    c.r[0] = c.r[3];  // 06026CCA mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06026CCC mov.b @(r0,r7),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06026CCE extu.b r1,r1
    c.t = c.r[1] == c.r[5];  // 06026CD0 cmp/eq r5,r1
    { const bool k = c.t; c.r[1] = c.r[6]; if (k) { goto L_06026D3A; } }  // 06026CD2 bt/s 0x06026D3A ; mov r6,r1
    c.r[2] += 2;  // 06026CD6 add #2,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06026CD8 mov.b @r2,r2
    c.r[1] = ld32(0x06026D74u);  // 06026CDA mov.l 0x06026D74,r1
    c.r[3] = ld32(c.r[1]);  // 06026CDC mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06026CDE extu.b r2,r2
    c.r[1] = 0x1Eu;  // 06026CE0 mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 06026CE2 mul.l r1,r2
    c.r[1] = c.macl;  // 06026CE4 sts macl,r1
    c.r[1] += c.r[3];  // 06026CE6 add r3,r1
    c.r[1] += 15;  // 06026CE8 add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06026CEA mov.b @r1,r1
    c.r[3] = c.r[1] & 0xFFu;  // 06026CEC extu.b r1,r3
    c.r[1] = ld32(0x06026D78u);  // 06026CEE mov.l 0x06026D78,r1
    c.r[2] = c.r[3];  // 06026CF0 mov r3,r2
    c.r[2] += c.r[2];  // 06026CF2 add r2,r2
    c.r[2] += c.r[3];  // 06026CF4 add r3,r2
    c.r[1] = ld32(c.r[1]);  // 06026CF6 mov.l @r1,r1
    c.r[2] <<= 2;  // 06026CF8 shll2 r2
    c.r[2] += c.r[1];  // 06026CFA add r1,r2
    c.r[1] = c.r[2];  // 06026CFC mov r2,r1
    c.r[1] += 3;  // 06026CFE add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06026D00 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06026D02 mov r1,r0
    c.r[0] >>= 2;  // 06026D04 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06026D06 shlr r0
    c.r[0] &= 0x1u;  // 06026D08 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06026D0A tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[6]; if (k) { goto L_06026D3A; } }  // 06026D0C bf/s 0x06026D3A ; mov r6,r1
    c.r[2] += 8;  // 06026D10 add #8,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06026D12 mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06026D14 extu.b r1,r1
    c.t = c.r[1] == c.r[5];  // 06026D16 cmp/eq r5,r1
    { const bool k = !c.t; c.r[1] = c.r[6]; if (k) { goto L_06026D3A; } }  // 06026D18 bf/s 0x06026D3A ; mov r6,r1
    c.r[1] = ld32(0x06026D7Cu);  // 06026D1C mov.l 0x06026D7C,r1
    c.r[2] = c.r[8];  // 06026D1E mov r8,r2
    c.r[1] = ld32(c.r[1]);  // 06026D20 mov.l @r1,r1
    c.r[2] += c.r[2];  // 06026D22 add r2,r2
    c.r[0] = c.r[1];  // 06026D24 mov r1,r0
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06026D26 mov.b @(r0,r2),r7
    c.r[8] += 1;  // 06026D28 add #1,r8
    c.r[0] = (uint32_t)(int16_t)ld16(0x06026D6Au);  // 06026D2A mov.w 0x06026D6A,r0
    c.r[7] &= c.r[0];  // 06026D2C and r0,r7
    c.r[0] = c.r[1];  // 06026D2E mov r1,r0
    st8(c.r[0] + c.r[2], c.r[7]);  // 06026D30 mov.b r7,@(r0,r2)
    c.r[1] += c.r[2];  // 06026D32 add r2,r1
    c.r[1] += 1;  // 06026D34 add #1,r1
    st8(c.r[1], c.r[3]);  // 06026D36 mov.b r3,@r1
    c.r[1] = c.r[6];  // 06026D38 mov r6,r1
L_06026D3A:
    c.r[1] += 1;  // 06026D3A add #1,r1
    c.r[6] = c.r[1] & 0xFFu;  // 06026D3C extu.b r1,r6
    c.r[1] = 0x49u;  // 06026D3E mov #73,r1
    c.t = c.r[6] > c.r[1];  // 06026D40 cmp/hi r1,r6
    if (!c.t) { SH2_POLL(c); goto L_06026CAA; }  // 06026D42 bf 0x06026CAA
    c.r[1] = ld32(0x06026D7Cu);  // 06026D44 mov.l 0x06026D7C,r1
    c.r[1] = ld32(c.r[1]);  // 06026D46 mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06026D6Cu);  // 06026D48 mov.w 0x06026D6C,r0
    st8(c.r[0] + c.r[1], c.r[8]);  // 06026D4A mov.b r8,@(r0,r1)
    c.r[1] = ld32(0x06026D80u);  // 06026D4C mov.l 0x06026D80,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06026D52u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06026D52u) return; }  // 06026D4E jsr @r1 ; nop
    c.t = (c.r[8] & c.r[8]) == 0;  // 06026D52 tst r8,r8
    if (c.t) { goto L_06026D5C; }  // 06026D54 bt 0x06026D5C
    c.r[1] = ld32(0x06026D84u);  // 06026D56 mov.l 0x06026D84,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06026D5Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06026D5Cu) return; }  // 06026D58 jsr @r1 ; nop
L_06026D5C:
    c.r[15] = c.r[14];  // 06026D5C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06026D5E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06026D60 mov.l @r15+,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x06026D6Eu);  // 06026D62 mov.w 0x06026D6E,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06026D64 rts ; mov.l @r15+,r8
}

void f_06026D88(SH2Context& c) {
    ran[511] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06026D88 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06026D8A sts.l pr,@-r15
    c.r[1] = ld32(0x06026DA8u);  // 06026D8C mov.l 0x06026DA8,r1
    c.r[1] = ld32(c.r[1]);  // 06026D8E mov.l @r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06026D90 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06026D92 extu.b r1,r0
    c.r[0] <<= 2;  // 06026D94 shll2 r0
    c.r[1] = ld32(0x06026DACu);  // 06026D96 mov.l 0x06026DAC,r1
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 06026D98 mov.l @(r0,r1),r0
    { const uint32_t x = c.r[0]; c.pr = 0x06026D9Eu; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06026D9Eu) return; }  // 06026D9A jsr @r0 ; mov r15,r14
    c.r[15] = c.r[14];  // 06026D9E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06026DA0 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06026DA2 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[0] & 0xFFFFu; c.pc = x; return; }  // 06026DA4 rts ; extu.w r0,r0
}

void f_06026DB0(SH2Context& c) {
    ran[512] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06026DB0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06026DB2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06026DB4 sts.l pr,@-r15
    c.r[1] = ld32(0x06026E00u);  // 06026DB6 mov.l 0x06026E00,r1
    c.r[1] = ld32(c.r[1]);  // 06026DB8 mov.l @r1,r1
    c.r[14] = c.r[15];  // 06026DBA mov r15,r14
    c.r[1] += 1;  // 06026DBC add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06026DBE mov.b @r1,r1
    c.r[0] = ld32(0x06026E04u);  // 06026DC0 mov.l 0x06026E04,r0
    c.r[8] = c.r[1] & 0xFFu;  // 06026DC2 extu.b r1,r8
    c.r[1] = ld32(0x06026E08u);  // 06026DC4 mov.l 0x06026E08,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06026DC6 mov.w @r1,r4
    c.r[8] >>= 2;  // 06026DC8 shlr2 r8
    c.r[8] >>= 2;  // 06026DCA shlr2 r8
    { const uint32_t x = c.r[0]; c.pr = 0x06026DD0u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06026DD0u) return; }  // 06026DCC jsr @r0 ; extu.w r4,r4
    c.r[0] = c.r[0] & 0xFFu;  // 06026DD0 extu.b r0,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06026DFCu);  // 06026DD2 mov.w 0x06026DFC,r1
    c.t = c.r[0] == c.r[1];  // 06026DD4 cmp/eq r1,r0
    { const bool k = c.t; c.r[2] = c.r[0]; if (k) { goto L_06026DF0; } }  // 06026DD6 bt/s 0x06026DF0 ; mov r0,r2
    c.r[1] = ld32(0x06026E0Cu);  // 06026DDA mov.l 0x06026E0C,r1
    c.r[1] = ld32(c.r[1]);  // 06026DDC mov.l @r1,r1
    c.r[2] <<= 2;  // 06026DDE shll2 r2
    c.r[2] <<= 2;  // 06026DE0 shll2 r2
    c.r[2] += c.r[1];  // 06026DE2 add r1,r2
    c.r[2] += 4;  // 06026DE4 add #4,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06026DE6 mov.b @r2,r0
    c.r[8] += c.r[8];  // 06026DE8 add r8,r8
    c.r[0] &= 0xE1u;  // 06026DEA and #225,r0
    c.r[0] |= c.r[8];  // 06026DEC or r8,r0
    st8(c.r[2], c.r[0]);  // 06026DEE mov.b r0,@r2
L_06026DF0:
    c.r[15] = c.r[14];  // 06026DF0 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06026DF2 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06026DF4 mov.l @r15+,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x06026DFEu);  // 06026DF6 mov.w 0x06026DFE,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06026DF8 rts ; mov.l @r15+,r8
}

void f_06026E10(SH2Context& c) {
    ran[513] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06026E10 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06026E12 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06026E14 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06026E16 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06026E18 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06026E1A mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06026E1C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06026E1E sts.l pr,@-r15
    c.r[15] -= 4;  // 06026E20 add #-4,r15
    c.r[1] = ld32(0x06026F80u);  // 06026E22 mov.l 0x06026F80,r1
    c.r[12] = 0x0u;  // 06026E24 mov #0,r12
    c.r[1] = ld32(c.r[1]);  // 06026E26 mov.l @r1,r1
    c.r[3] = ld32(0x06026F84u);  // 06026E28 mov.l 0x06026F84,r3
    c.r[2] = ld32(c.r[3]);  // 06026E2A mov.l @r3,r2
    c.r[1] += 1;  // 06026E2C add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06026E2E mov.b @r1,r1
    c.r[0] = c.r[2];  // 06026E30 mov r2,r0
    c.r[7] = c.r[1] & 0xFFu;  // 06026E32 extu.b r1,r7
    c.r[1] = (uint32_t)(int16_t)ld16(0x06026F74u);  // 06026E34 mov.w 0x06026F74,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06026E36 mov.b @(r0,r1),r1
    c.r[7] >>= 2;  // 06026E38 shlr2 r7
    c.r[7] >>= 2;  // 06026E3A shlr2 r7
    c.r[1] = c.r[1] & 0xFFu;  // 06026E3C extu.b r1,r1
    c.t = (int32_t)c.r[12] >= (int32_t)c.r[1];  // 06026E3E cmp/ge r1,r12
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_06026E48; } }  // 06026E40 bf/s 0x06026E48 ; mov r15,r14
    goto L_06026F5C;  // 06026E44 bra 0x06026F5C ; nop
L_06026E48:
    c.r[13] = c.r[7];  // 06026E48 mov r7,r13
    c.r[13] += c.r[13];  // 06026E4A add r13,r13
    c.r[6] = (uint32_t)(int16_t)ld16(0x06026F76u);  // 06026E4C mov.w 0x06026F76,r6
    c.r[1] = c.r[12];  // 06026E4E mov r12,r1
L_06026E50:
    c.r[2] = ld32(c.r[3]);  // 06026E50 mov.l @r3,r2
    c.r[1] += c.r[1];  // 06026E52 add r1,r1
    c.r[2] += c.r[1];  // 06026E54 add r1,r2
    c.r[2] += 1;  // 06026E56 add #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06026E58 mov.b @r2,r1
    c.r[11] = c.r[1] & 0xFFu;  // 06026E5A extu.b r1,r11
    c.r[1] = ld32(0x06026F88u);  // 06026E5C mov.l 0x06026F88,r1
    c.r[7] = c.r[11];  // 06026E5E mov r11,r7
    c.r[1] = ld32(c.r[1]);  // 06026E60 mov.l @r1,r1
    c.r[7] <<= 2;  // 06026E62 shll2 r7
    c.r[7] <<= 2;  // 06026E64 shll2 r7
    c.r[7] += c.r[1];  // 06026E66 add r1,r7
    c.r[1] = c.r[7];  // 06026E68 mov r7,r1
    c.r[1] += 3;  // 06026E6A add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06026E6C mov.b @r1,r1
    c.r[0] = c.r[1];  // 06026E6E mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06026E70 shlr r0
    c.r[0] &= 0x3u;  // 06026E72 and #3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06026E74 tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[7]; if (k) { goto L_06026F3C; } }  // 06026E76 bf/s 0x06026F3C ; mov r7,r1
    c.r[1] += 2;  // 06026E7A add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06026E7C mov.b @r1,r2
    c.r[1] = ld32(0x06026F8Cu);  // 06026E7E mov.l 0x06026F8C,r1
    c.r[3] = ld32(c.r[1]);  // 06026E80 mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06026E82 extu.b r2,r2
    c.r[1] = 0x1Eu;  // 06026E84 mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 06026E86 mul.l r1,r2
    c.r[2] = c.macl;  // 06026E88 sts macl,r2
    c.r[2] += c.r[3];  // 06026E8A add r3,r2
    c.r[1] = c.r[2];  // 06026E8C mov r2,r1
    c.r[1] += 15;  // 06026E8E add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06026E90 mov.b @r1,r1
    c.r[3] = c.r[1] & 0xFFu;  // 06026E92 extu.b r1,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06026E94 mov.w @r2,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06026E96 extu.w r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06026F78u);  // 06026E98 mov.w 0x06026F78,r2
    c.t = c.r[1] == c.r[2];  // 06026E9A cmp/eq r2,r1
    { const bool k = c.t; c.r[0] = c.r[3]; if (k) { goto L_06026F46; } }  // 06026E9C bt/s 0x06026F46 ; mov r3,r0
    c.r[1] = ld32(0x06026F90u);  // 06026EA0 mov.l 0x06026F90,r1
    c.r[0] += c.r[0];  // 06026EA2 add r0,r0
    c.r[0] += c.r[3];  // 06026EA4 add r3,r0
    c.r[1] = ld32(c.r[1]);  // 06026EA6 mov.l @r1,r1
    c.r[0] <<= 2;  // 06026EA8 shll2 r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06026EAA mov.w @(r0,r1),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06026F7Au);  // 06026EAC mov.w 0x06026F7A,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 06026EAE extu.w r1,r1
    c.t = c.r[1] == c.r[2];  // 06026EB0 cmp/eq r2,r1
    { const bool k = c.t; c.r[1] = c.r[7]; if (k) { goto L_06026F46; } }  // 06026EB2 bt/s 0x06026F46 ; mov r7,r1
    c.r[1] += 4;  // 06026EB6 add #4,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06026EB8 mov.b @r1,r0
    c.r[10] = 0x0u;  // 06026EBA mov #0,r10
    c.r[9] = 0x0u;  // 06026EBC mov #0,r9
    c.r[0] &= 0xE1u;  // 06026EBE and #225,r0
    c.r[0] |= c.r[13];  // 06026EC0 or r13,r0
    st8(c.r[1], c.r[0]);  // 06026EC2 mov.b r0,@r1
L_06026EC4:
    c.t = c.r[10] == c.r[11];  // 06026EC4 cmp/eq r11,r10
    { const bool k = c.t; c.r[3] = c.r[9]; if (k) { goto L_06026F2E; } }  // 06026EC6 bt/s 0x06026F2E ; mov r9,r3
    c.r[1] = ld32(0x06026F88u);  // 06026ECA mov.l 0x06026F88,r1
    c.r[2] = ld32(c.r[1]);  // 06026ECC mov.l @r1,r2
    c.r[0] = c.r[9];  // 06026ECE mov r9,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06026ED0 mov.b @(r0,r2),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06026ED2 extu.b r1,r1
    c.t = c.r[1] == c.r[6];  // 06026ED4 cmp/eq r6,r1
    { const bool k = c.t; c.r[3] += c.r[2]; if (k) { goto L_06026F2E; } }  // 06026ED6 bt/s 0x06026F2E ; add r2,r3
    c.r[1] = c.r[3];  // 06026EDA mov r3,r1
    c.r[1] += 7;  // 06026EDC add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06026EDE mov.b @r1,r1
    c.r[0] = c.r[1];  // 06026EE0 mov r1,r0
    c.r[0] >>= 2;  // 06026EE2 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06026EE4 shlr r0
    c.r[0] &= 0x1u;  // 06026EE6 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06026EE8 tst r0,r0
    { const bool k = !c.t; c.r[8] = c.r[3]; if (k) { goto L_06026F2E; } }  // 06026EEA bf/s 0x06026F2E ; mov r3,r8
    c.r[8] += 9;  // 06026EEE add #9,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06026EF0 mov.b @r8,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06026EF2 extu.b r1,r1
    c.t = c.r[1] == c.r[11];  // 06026EF4 cmp/eq r11,r1
    { const bool k = !c.t; c.r[1] = c.r[11]; if (k) { goto L_06026F2E; } }  // 06026EF6 bf/s 0x06026F2E ; mov r11,r1
    c.r[1] <<= 2;  // 06026EFA shll2 r1
    c.r[1] <<= 2;  // 06026EFC shll2 r1
    c.r[1] += c.r[2];  // 06026EFE add r2,r1
    c.r[1] += 4;  // 06026F00 add #4,r1
    c.r[0] = 0xFu;  // 06026F02 mov #15,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06026F04 mov.b @r1,r1
    c.r[3] += 3;  // 06026F06 add #3,r3
    c.r[2] = c.r[1];  // 06026F08 mov r1,r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 06026F0A shlr r2
    c.r[2] &= c.r[0];  // 06026F0C and r0,r2
    c.r[0] = 0x3u;  // 06026F0E mov #3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06026F10 mov.b @r3,r1
    c.r[4] = c.r[2];  // 06026F12 mov r2,r4
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06026F14 shlr r1
    c.r[1] &= c.r[0];  // 06026F16 and r0,r1
    c.r[5] = c.r[1];  // 06026F18 mov r1,r5
    c.r[0] = ld32(0x06026F94u);  // 06026F1A mov.l 0x06026F94,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06026F20u; st32(c.r[14], c.r[6]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06026F20u) return; }  // 06026F1C jsr @r0 ; mov.l r6,@r14
    c.r[1] = c.r[0];  // 06026F20 mov r0,r1
    c.r[0] = 0x1u;  // 06026F22 mov #1,r0
    c.r[1] &= c.r[0];  // 06026F24 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06026F26 tst r1,r1
    { const bool k = !c.t; c.r[6] = ld32(c.r[14]); if (k) { goto L_06026F2E; } }  // 06026F28 bf/s 0x06026F2E ; mov.l @r14,r6
    st8(c.r[8], c.r[6]);  // 06026F2C mov.b r6,@r8
L_06026F2E:
    c.r[10] += 1;  // 06026F2E add #1,r10
    c.r[1] = 0x49u;  // 06026F30 mov #73,r1
    c.t = (int32_t)c.r[10] > (int32_t)c.r[1];  // 06026F32 cmp/gt r1,r10
    { const bool k = !c.t; c.r[9] += 16; if (k) { SH2_POLL(c); goto L_06026EC4; } }  // 06026F34 bf/s 0x06026EC4 ; add #16,r9
    goto L_06026F46;  // 06026F38 bra 0x06026F46 ; nop
L_06026F3C:
    c.r[1] += 4;  // 06026F3C add #4,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06026F3E mov.b @r1,r0
    c.r[0] &= 0xE1u;  // 06026F40 and #225,r0
    c.r[0] |= c.r[13];  // 06026F42 or r13,r0
    st8(c.r[1], c.r[0]);  // 06026F44 mov.b r0,@r1
L_06026F46:
    c.r[3] = ld32(0x06026F84u);  // 06026F46 mov.l 0x06026F84,r3
    c.r[1] = ld32(c.r[3]);  // 06026F48 mov.l @r3,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06026F74u);  // 06026F4A mov.w 0x06026F74,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06026F4C mov.b @(r0,r1),r1
    c.r[12] += 1;  // 06026F4E add #1,r12
    c.r[1] = c.r[1] & 0xFFu;  // 06026F50 extu.b r1,r1
    c.t = (int32_t)c.r[12] >= (int32_t)c.r[1];  // 06026F52 cmp/ge r1,r12
    { const bool k = c.t; c.r[1] = c.r[12]; if (k) { goto L_06026F5C; } }  // 06026F54 bt/s 0x06026F5C ; mov r12,r1
    SH2_POLL(c); goto L_06026E50;  // 06026F58 bra 0x06026E50 ; nop
L_06026F5C:
    c.r[14] += 4;  // 06026F5C add #4,r14
    c.r[15] = c.r[14];  // 06026F5E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06026F60 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06026F62 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06026F64 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06026F66 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06026F68 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06026F6A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06026F6C mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06026F7Cu);  // 06026F6E mov.w 0x06026F7C,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06026F70 rts ; mov.l @r15+,r8
}

void f_06026F98(SH2Context& c) {
    ran[514] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06026F98 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06026F9A sts.l pr,@-r15
    c.r[1] = ld32(0x06026FD8u);  // 06026F9C mov.l 0x06026FD8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06026FA2u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06026FA2u) return; }  // 06026F9E jsr @r1 ; mov r15,r14
    c.r[1] = ld32(0x06026FDCu);  // 06026FA2 mov.l 0x06026FDC,r1
    c.r[1] = ld32(c.r[1]);  // 06026FA4 mov.l @r1,r1
    c.r[1] += 1;  // 06026FA6 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06026FA8 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06026FAA extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06026FAC tst r1,r1
    if (c.t) { goto L_06026FB6; }  // 06026FAE bt 0x06026FB6
    c.r[1] = ld32(0x06026FE0u);  // 06026FB0 mov.l 0x06026FE0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]); goto L_06026FBA;  // 06026FB2 bra 0x06026FBA ; mov.b @r1,r1
L_06026FB6:
    c.r[1] = ld32(0x06026FE4u);  // 06026FB6 mov.l 0x06026FE4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06026FB8 mov.b @r1,r1
L_06026FBA:
    c.r[0] = c.r[1];  // 06026FBA mov r1,r0
    c.r[0] >>= 2;  // 06026FBC shlr2 r0
    c.r[0] >>= 2;  // 06026FBE shlr2 r0
    c.r[0] &= 0x1u;  // 06026FC0 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06026FC2 tst r0,r0
    if (c.t) { goto L_06026FCC; }  // 06026FC4 bt 0x06026FCC
    c.r[1] = ld32(0x06026FE8u);  // 06026FC6 mov.l 0x06026FE8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06026FCCu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06026FCCu) return; }  // 06026FC8 jsr @r1 ; nop
L_06026FCC:
    c.r[15] = c.r[14];  // 06026FCC mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06026FCE lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x06026FD6u);  // 06026FD0 mov.w 0x06026FD6,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06026FD2 rts ; mov.l @r15+,r14
}

void f_06026FEC(SH2Context& c) {
    ran[515] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06026FEC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06026FEE sts.l pr,@-r15
    c.r[15] -= 76;  // 06026FF0 add #-76,r15
    c.r[14] = c.r[15];  // 06026FF2 mov r15,r14
    c.r[1] = ld32(0x06027018u);  // 06026FF4 mov.l 0x06027018,r1
    c.r[1] = ld32(c.r[1]);  // 06026FF6 mov.l @r1,r1
    c.r[0] = ld32(0x0602701Cu);  // 06026FF8 mov.l 0x0602701C,r0
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06026FFA mov.b @r1,r6
    c.r[7] = 0x0u;  // 06026FFC mov #0,r7
    c.r[1] = ld32(0x06027020u);  // 06026FFE mov.l 0x06027020,r1
    c.r[4] = ld32(c.r[1]);  // 06027000 mov.l @r1,r4
    { const uint32_t x = c.r[0]; c.pr = 0x06027006u; c.r[5] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06027006u) return; }  // 06027002 jsr @r0 ; mov r14,r5
    c.r[1] = ld32(0x06027024u);  // 06027006 mov.l 0x06027024,r1
    st32(c.r[1] + 20, c.r[0]);  // 06027008 mov.l r0,@(20,r1)
    c.r[14] += 76;  // 0602700A add #76,r14
    c.r[15] = c.r[14];  // 0602700C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602700E lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x06027016u);  // 06027010 mov.w 0x06027016,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06027012 rts ; mov.l @r15+,r14
}

void f_06027028(SH2Context& c) {
    ran[516] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06027028 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602702A sts.l pr,@-r15
    c.r[1] = ld32(0x06027048u);  // 0602702C mov.l 0x06027048,r1
    c.r[1] = ld32(c.r[1]);  // 0602702E mov.l @r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06027030 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06027032 extu.b r1,r0
    c.r[0] <<= 2;  // 06027034 shll2 r0
    c.r[1] = ld32(0x0602704Cu);  // 06027036 mov.l 0x0602704C,r1
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 06027038 mov.l @(r0,r1),r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602703Eu; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602703Eu) return; }  // 0602703A jsr @r0 ; mov r15,r14
    c.r[15] = c.r[14];  // 0602703E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06027040 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06027042 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[0] & 0xFFFFu; c.pc = x; return; }  // 06027044 rts ; extu.w r0,r0
}

void f_06027050(SH2Context& c) {
    ran[517] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06027050 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06027052 mov r15,r14
    c.r[1] = ld32(0x0602706Cu);  // 06027054 mov.l 0x0602706C,r1
    c.r[1] = ld32(c.r[1]);  // 06027056 mov.l @r1,r1
    c.r[2] = ld32(0x06027070u);  // 06027058 mov.l 0x06027070,r2
    c.r[1] += 16;  // 0602705A add #16,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602705C mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602705E extu.b r1,r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06027060 shlr r1
    st32(c.r[2] + 20, c.r[1]);  // 06027062 mov.l r1,@(20,r2)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602706Au);  // 06027064 mov.w 0x0602706A,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06027066 rts ; mov.l @r15+,r14
}

void f_06027074(SH2Context& c) {
    ran[518] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06027074 mov.l r14,@-r15
    c.r[1] = ld32(0x060270C0u);  // 06027076 mov.l 0x060270C0,r1
    c.r[7] = ld32(c.r[1]);  // 06027078 mov.l @r1,r7
    c.r[1] = c.r[7];  // 0602707A mov r7,r1
    c.r[1] += 1;  // 0602707C add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602707E mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06027080 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06027082 tst r1,r1
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0602709A; } }  // 06027084 bf/s 0x0602709A ; mov r15,r14
    c.r[1] = ld32(0x060270C4u);  // 06027088 mov.l 0x060270C4,r1
    c.r[1] = ld32(c.r[1]);  // 0602708A mov.l @r1,r1
    c.r[2] = ld32(0x060270C8u);  // 0602708C mov.l 0x060270C8,r2
    c.r[1] += 14;  // 0602708E add #14,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06027090 mov.w @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060270BCu);  // 06027092 mov.w 0x060270BC,r0
    c.r[1] = c.r[1] & 0xFFFFu;  // 06027094 extu.w r1,r1
    st32(c.r[2] + 20, c.r[1]); goto L_060270B6;  // 06027096 bra 0x060270B6 ; mov.l r1,@(20,r2)
L_0602709A:
    c.r[1] = ld32(0x060270C4u);  // 0602709A mov.l 0x060270C4,r1
    c.r[3] = ld32(c.r[1]);  // 0602709C mov.l @r1,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x060270BEu);  // 0602709E mov.w 0x060270BE,r0
    c.r[3] += 14;  // 060270A0 add #14,r3
    c.r[1] = c.r[7];  // 060270A2 mov r7,r1
    c.r[1] += 2;  // 060270A4 add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060270A6 mov.b @r1,r2
    c.r[7] += 3;  // 060270A8 add #3,r7
    c.r[2] = c.r[2] & 0xFFu;  // 060270AA extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 060270AC mov.b @r7,r1
    c.r[2] <<= 8;  // 060270AE shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 060270B0 extu.b r1,r1
    c.r[2] |= c.r[1];  // 060270B2 or r1,r2
    st16(c.r[3], c.r[2]);  // 060270B4 mov.w r2,@r3
L_060270B6:
    c.r[15] = c.r[14];  // 060270B6 mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060270B8 rts ; mov.l @r15+,r14
}

void f_060270CC(SH2Context& c) {
    ran[519] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060270CC mov.l r14,@-r15
    c.r[1] = ld32(0x0602714Cu);  // 060270CE mov.l 0x0602714C,r1
    c.r[1] = ld32(c.r[1]);  // 060270D0 mov.l @r1,r1
    c.r[1] += 1;  // 060270D2 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060270D4 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060270D6 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060270D8 tst r1,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0602710E; } }  // 060270DA bt/s 0x0602710E ; mov r15,r14
    c.r[7] = ld32(0x06027150u);  // 060270DE mov.l 0x06027150,r7
    c.r[3] = ld32(c.r[7]);  // 060270E0 mov.l @r7,r3
    c.r[3] += 14;  // 060270E2 add #14,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 060270E4 mov.w @r3,r2
    c.r[1] = c.r[2] & 0xFFFFu;  // 060270E6 extu.w r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060270E8 tst r1,r1
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_060270F2; } }  // 060270EA bt/s 0x060270F2 ; mov r2,r1
    c.r[1] -= 1;  // 060270EE add #-1,r1
    st16(c.r[3], c.r[1]);  // 060270F0 mov.w r1,@r3
L_060270F2:
    c.r[2] = ld32(c.r[7]);  // 060270F2 mov.l @r7,r2
    c.r[2] += 16;  // 060270F4 add #16,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060270F6 mov.b @r2,r0
    c.r[1] = c.r[0] & 0xFFu;  // 060270F8 extu.b r0,r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060270FA shlr r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060270FC tst r1,r1
    { const bool k = c.t; c.r[15] = c.r[14]; if (k) { goto L_06027144; } }  // 060270FE bt/s 0x06027144 ; mov r14,r15
    c.r[1] -= 1;  // 06027102 add #-1,r1
    c.r[1] += c.r[1];  // 06027104 add r1,r1
    c.r[0] &= 0x1u;  // 06027106 and #1,r0
    c.r[0] |= c.r[1];  // 06027108 or r1,r0
    st8(c.r[2], c.r[0]); goto L_06027144;  // 0602710A bra 0x06027144 ; mov.b r0,@r2
L_0602710E:
    c.r[6] = ld32(0x06027150u);  // 0602710E mov.l 0x06027150,r6
    c.r[7] = ld32(c.r[6]);  // 06027110 mov.l @r6,r7
    c.r[7] += 14;  // 06027112 add #14,r7
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[7]);  // 06027114 mov.w @r7,r3
    c.r[1] = ld32(0x06027154u);  // 06027116 mov.l 0x06027154,r1
    c.r[2] = c.r[3] & 0xFFFFu;  // 06027118 extu.w r3,r2
    c.t = c.r[2] > c.r[1];  // 0602711A cmp/hi r1,r2
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_06027124; } }  // 0602711C bt/s 0x06027124 ; mov r3,r1
    c.r[1] += 1;  // 06027120 add #1,r1
    st16(c.r[7], c.r[1]);  // 06027122 mov.w r1,@r7
L_06027124:
    c.r[3] = ld32(c.r[6]);  // 06027124 mov.l @r6,r3
    c.r[3] += 16;  // 06027126 add #16,r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06027128 mov.b @r3,r0
    c.r[1] = 0x63u;  // 0602712A mov #99,r1
    c.r[2] = c.r[0] & 0xFFu;  // 0602712C extu.b r0,r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 0602712E shlr r2
    c.r[2] += 1;  // 06027130 add #1,r2
    c.t = c.r[2] > c.r[1];  // 06027132 cmp/hi r1,r2
    { const bool k = !c.t; c.r[0] &= 0x1u; if (k) { goto L_0602713C; } }  // 06027134 bf/s 0x0602713C ; and #1,r0
    c.r[0] |= 0xC6u; goto L_06027140;  // 06027138 bra 0x06027140 ; or #198,r0
L_0602713C:
    c.r[2] += c.r[2];  // 0602713C add r2,r2
    c.r[0] |= c.r[2];  // 0602713E or r2,r0
L_06027140:
    st8(c.r[3], c.r[0]);  // 06027140 mov.b r0,@r3
    c.r[15] = c.r[14];  // 06027142 mov r14,r15
L_06027144:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602714Au);  // 06027144 mov.w 0x0602714A,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06027146 rts ; mov.l @r15+,r14
}

void f_06027158(SH2Context& c) {
    ran[520] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06027158 mov.l r14,@-r15
    c.r[1] = ld32(0x06027190u);  // 0602715A mov.l 0x06027190,r1
    c.r[1] = ld32(c.r[1]);  // 0602715C mov.l @r1,r1
    c.r[1] += 1;  // 0602715E add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06027160 mov.b @r1,r1
    c.r[6] = c.r[1] & 0xFFu;  // 06027162 extu.b r1,r6
    c.r[1] = ld32(0x06027194u);  // 06027164 mov.l 0x06027194,r1
    c.r[3] = ld32(c.r[1]);  // 06027166 mov.l @r1,r3
    c.r[3] += 14;  // 06027168 add #14,r3
    c.r[7] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0602716A mov.w @r3,r7
    c.r[1] = ld32(0x06027198u);  // 0602716C mov.l 0x06027198,r1
    c.r[2] = c.r[7] & 0xFFFFu;  // 0602716E extu.w r7,r2
    c.r[2] += c.r[6];  // 06027170 add r6,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 06027172 cmp/gt r1,r2
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0602717E; } }  // 06027174 bt/s 0x0602717E ; mov r15,r14
    c.r[6] += c.r[7];  // 06027178 add r7,r6
    st16(c.r[3], c.r[6]); goto L_06027182;  // 0602717A bra 0x06027182 ; mov.w r6,@r3
L_0602717E:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602718Au);  // 0602717E mov.w 0x0602718A,r1
    st16(c.r[3], c.r[1]);  // 06027180 mov.w r1,@r3
L_06027182:
    c.r[15] = c.r[14];  // 06027182 mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602718Cu);  // 06027184 mov.w 0x0602718C,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06027186 rts ; mov.l @r15+,r14
}

void f_0602719C(SH2Context& c) {
    ran[521] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602719C mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0602719E mov r15,r14
    c.r[7] = 0x0u;  // 060271A0 mov #0,r7
    c.r[3] = ld32(0x06027204u);  // 060271A2 mov.l 0x06027204,r3
    c.r[2] = 0x0u;  // 060271A4 mov #0,r2
L_060271A6:
    c.r[1] = ld32(c.r[3]);  // 060271A6 mov.l @r3,r1
    c.r[1] += c.r[2];  // 060271A8 add r2,r1
    c.r[1] += 7;  // 060271AA add #7,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060271AC mov.b @r1,r0
    c.r[0] &= 0xDFu;  // 060271AE and #223,r0
    st8(c.r[1], c.r[0]);  // 060271B0 mov.b r0,@r1
    c.r[1] = ld32(c.r[3]);  // 060271B2 mov.l @r3,r1
    c.r[1] += c.r[2];  // 060271B4 add r2,r1
    c.r[1] += 10;  // 060271B6 add #10,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060271B8 mov.b @r1,r0
    c.r[0] &= 0xEFu;  // 060271BA and #239,r0
    st8(c.r[1], c.r[0]);  // 060271BC mov.b r0,@r1
    c.r[1] = ld32(c.r[3]);  // 060271BE mov.l @r3,r1
    c.r[1] += c.r[2];  // 060271C0 add r2,r1
    c.r[1] += 10;  // 060271C2 add #10,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060271C4 mov.b @r1,r0
    c.r[0] &= 0xFEu;  // 060271C6 and #254,r0
    st8(c.r[1], c.r[0]);  // 060271C8 mov.b r0,@r1
    c.r[1] = ld32(c.r[3]);  // 060271CA mov.l @r3,r1
    c.r[1] += c.r[2];  // 060271CC add r2,r1
    c.r[1] += 11;  // 060271CE add #11,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060271D0 mov.b @r1,r0
    c.r[0] &= 0x7Fu;  // 060271D2 and #127,r0
    st8(c.r[1], c.r[0]);  // 060271D4 mov.b r0,@r1
    c.r[1] = ld32(c.r[3]);  // 060271D6 mov.l @r3,r1
    c.r[1] += c.r[2];  // 060271D8 add r2,r1
    c.r[1] += 11;  // 060271DA add #11,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060271DC mov.b @r1,r0
    c.r[0] &= 0xBFu;  // 060271DE and #191,r0
    st8(c.r[1], c.r[0]);  // 060271E0 mov.b r0,@r1
    c.r[1] = ld32(c.r[3]);  // 060271E2 mov.l @r3,r1
    c.r[7] += 1;  // 060271E4 add #1,r7
    c.r[1] += c.r[2];  // 060271E6 add r2,r1
    c.r[1] += 11;  // 060271E8 add #11,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060271EA mov.b @r1,r0
    c.r[0] &= 0xDFu;  // 060271EC and #223,r0
    st8(c.r[1], c.r[0]);  // 060271EE mov.b r0,@r1
    c.r[1] = 0x49u;  // 060271F0 mov #73,r1
    c.t = (int32_t)c.r[7] > (int32_t)c.r[1];  // 060271F2 cmp/gt r1,r7
    { const bool k = !c.t; c.r[2] += 16; if (k) { SH2_POLL(c); goto L_060271A6; } }  // 060271F4 bf/s 0x060271A6 ; add #16,r2
    c.r[15] = c.r[14];  // 060271F8 mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x06027200u);  // 060271FA mov.w 0x06027200,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060271FC rts ; mov.l @r15+,r14
}

void f_06027208(SH2Context& c) {
    ran[522] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06027208 mov.l r14,@-r15
    c.r[1] = ld32(0x06027224u);  // 0602720A mov.l 0x06027224,r1
    c.r[1] = ld32(c.r[1]);  // 0602720C mov.l @r1,r1
    c.r[14] = c.r[15];  // 0602720E mov r15,r14
    c.r[1] += 16;  // 06027210 add #16,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06027212 mov.b @r1,r0
    c.r[0] &= 0x1u;  // 06027214 and #1,r0
    c.r[0] |= 0x2u;  // 06027216 or #2,r0
    st8(c.r[1], c.r[0]);  // 06027218 mov.b r0,@r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06027220u);  // 0602721A mov.w 0x06027220,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602721C rts ; mov.l @r15+,r14
}

void f_06027228(SH2Context& c) {
    ran[523] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06027228 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602722A sts.l pr,@-r15
    c.r[1] = ld32(0x0602725Cu);  // 0602722C mov.l 0x0602725C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06027232u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06027232u) return; }  // 0602722E jsr @r1 ; mov r15,r14
    c.r[1] = ld32(0x06027260u);  // 06027232 mov.l 0x06027260,r1
    c.r[1] = ld32(c.r[1]);  // 06027234 mov.l @r1,r1
    c.r[1] += 16;  // 06027236 add #16,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06027238 mov.b @r1,r2
    c.r[3] = ld32(0x06027264u);  // 0602723A mov.l 0x06027264,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0602723C extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0602723E mov.b @r3,r1
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 06027240 shlr r2
    c.r[1] = c.r[1] & 0xFFu;  // 06027242 extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 06027244 cmp/eq r2,r1
    if (!c.t) { goto L_0602724E; }  // 06027246 bf 0x0602724E
    c.r[1] = ld32(0x06027268u);  // 06027248 mov.l 0x06027268,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602724Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602724Eu) return; }  // 0602724A jsr @r1 ; nop
L_0602724E:
    c.r[15] = c.r[14];  // 0602724E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06027250 lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x06027258u);  // 06027252 mov.w 0x06027258,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06027254 rts ; mov.l @r15+,r14
}

void f_0602726C(SH2Context& c) {
    ran[524] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602726C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602726E sts.l pr,@-r15
    c.r[1] = ld32(0x0602728Cu);  // 06027270 mov.l 0x0602728C,r1
    c.r[1] = ld32(c.r[1]);  // 06027272 mov.l @r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06027274 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06027276 extu.b r1,r0
    c.r[0] <<= 2;  // 06027278 shll2 r0
    c.r[1] = ld32(0x06027290u);  // 0602727A mov.l 0x06027290,r1
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 0602727C mov.l @(r0,r1),r0
    { const uint32_t x = c.r[0]; c.pr = 0x06027282u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06027282u) return; }  // 0602727E jsr @r0 ; mov r15,r14
    c.r[15] = c.r[14];  // 06027282 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06027284 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06027286 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[0] & 0xFFFFu; c.pc = x; return; }  // 06027288 rts ; extu.w r0,r0
}

void f_06027294(SH2Context& c) {
    ran[525] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06027294 mov.l r14,@-r15
    c.r[1] = ld32(0x060272ECu);  // 06027296 mov.l 0x060272EC,r1
    c.r[2] = ld32(c.r[1]);  // 06027298 mov.l @r1,r2
    c.r[1] = c.r[2];  // 0602729A mov r2,r1
    c.r[1] += 1;  // 0602729C add #1,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602729E mov.b @r1,r3
    c.r[2] += 2;  // 060272A0 add #2,r2
    c.r[3] = c.r[3] & 0xFFu;  // 060272A2 extu.b r3,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060272A4 mov.b @r2,r1
    c.r[3] <<= 8;  // 060272A6 shll8 r3
    c.r[1] = c.r[1] & 0xFFu;  // 060272A8 extu.b r1,r1
    c.r[3] |= c.r[1];  // 060272AA or r1,r3
    c.r[1] = ld32(0x060272F0u);  // 060272AC mov.l 0x060272F0,r1
    c.r[1] = ld32(c.r[1]);  // 060272AE mov.l @r1,r1
    c.r[6] = c.r[1];  // 060272B0 mov r1,r6
    c.r[6] += 10;  // 060272B2 add #10,r6
    c.r[5] = c.r[1];  // 060272B4 mov r1,r5
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[6]);  // 060272B6 mov.w @r6,r2
    c.r[5] += 12;  // 060272B8 add #12,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[5]);  // 060272BA mov.b @r5,r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 060272BC extu.w r2,r2
    c.r[2] <<= 8;  // 060272BE shll8 r2
    c.r[7] = c.r[1] & 0xFFu;  // 060272C0 extu.b r1,r7
    c.r[7] |= c.r[2];  // 060272C2 or r2,r7
    c.r[7] += c.r[3];  // 060272C4 add r3,r7
    c.r[1] = ld32(0x060272F4u);  // 060272C6 mov.l 0x060272F4,r1
    c.t = c.r[7] > c.r[1];  // 060272C8 cmp/hi r1,r7
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_060272D8; } }  // 060272CA bf/s 0x060272D8 ; mov r15,r14
    c.r[1] = (uint32_t)(int16_t)ld16(0x060272E8u);  // 060272CE mov.w 0x060272E8,r1
    st16(c.r[6], c.r[1]);  // 060272D0 mov.w r1,@r6
    c.r[1] = 0x7Fu;  // 060272D2 mov #127,r1
    st8(c.r[5], c.r[1]); goto L_060272E0;  // 060272D4 bra 0x060272E0 ; mov.b r1,@r5
L_060272D8:
    c.r[1] = c.r[7];  // 060272D8 mov r7,r1
    c.r[1] >>= 8;  // 060272DA shlr8 r1
    st16(c.r[6], c.r[1]);  // 060272DC mov.w r1,@r6
    st8(c.r[5], c.r[7]);  // 060272DE mov.b r7,@r5
L_060272E0:
    c.r[15] = c.r[14];  // 060272E0 mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x060272EAu);  // 060272E2 mov.w 0x060272EA,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060272E4 rts ; mov.l @r15+,r14
}

void f_060272F8(SH2Context& c) {
    ran[526] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060272F8 mov.l r14,@-r15
    c.r[1] = ld32(0x0602734Cu);  // 060272FA mov.l 0x0602734C,r1
    c.r[2] = ld32(c.r[1]);  // 060272FC mov.l @r1,r2
    c.r[1] = c.r[2];  // 060272FE mov r2,r1
    c.r[1] += 1;  // 06027300 add #1,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06027302 mov.b @r1,r3
    c.r[2] += 2;  // 06027304 add #2,r2
    c.r[3] = c.r[3] & 0xFFu;  // 06027306 extu.b r3,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06027308 mov.b @r2,r1
    c.r[3] <<= 8;  // 0602730A shll8 r3
    c.r[1] = c.r[1] & 0xFFu;  // 0602730C extu.b r1,r1
    c.r[3] |= c.r[1];  // 0602730E or r1,r3
    c.r[1] = ld32(0x06027350u);  // 06027310 mov.l 0x06027350,r1
    c.r[1] = ld32(c.r[1]);  // 06027312 mov.l @r1,r1
    c.r[6] = c.r[1];  // 06027314 mov r1,r6
    c.r[6] += 10;  // 06027316 add #10,r6
    c.r[5] = c.r[1];  // 06027318 mov r1,r5
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[6]);  // 0602731A mov.w @r6,r2
    c.r[5] += 12;  // 0602731C add #12,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[5]);  // 0602731E mov.b @r5,r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 06027320 extu.w r2,r2
    c.r[2] <<= 8;  // 06027322 shll8 r2
    c.r[7] = c.r[1] & 0xFFu;  // 06027324 extu.b r1,r7
    c.r[7] |= c.r[2];  // 06027326 or r2,r7
    c.r[7] -= c.r[3];  // 06027328 sub r3,r7
    c.t = (int32_t)c.r[7] >= 0;  // 0602732A cmp/pz r7
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06027338; } }  // 0602732C bt/s 0x06027338 ; mov r15,r14
    c.r[1] = 0x0u;  // 06027330 mov #0,r1
    st16(c.r[6], c.r[1]);  // 06027332 mov.w r1,@r6
    st8(c.r[5], c.r[1]); goto L_06027340;  // 06027334 bra 0x06027340 ; mov.b r1,@r5
L_06027338:
    c.r[1] = c.r[7];  // 06027338 mov r7,r1
    c.r[1] >>= 8;  // 0602733A shlr8 r1
    st16(c.r[6], c.r[1]);  // 0602733C mov.w r1,@r6
    st8(c.r[5], c.r[7]);  // 0602733E mov.b r7,@r5
L_06027340:
    c.r[15] = c.r[14];  // 06027340 mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x06027348u);  // 06027342 mov.w 0x06027348,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06027344 rts ; mov.l @r15+,r14
}

void f_06027354(SH2Context& c) {
    ran[527] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06027354 mov.l r14,@-r15
    c.r[1] = ld32(0x06027388u);  // 06027356 mov.l 0x06027388,r1
    c.r[3] = ld32(c.r[1]);  // 06027358 mov.l @r1,r3
    c.r[14] = c.r[15];  // 0602735A mov r15,r14
    c.r[1] = c.r[3];  // 0602735C mov r3,r1
    c.r[1] += 10;  // 0602735E add #10,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06027360 mov.w @r1,r2
    c.r[3] += 12;  // 06027362 add #12,r3
    c.r[2] = c.r[2] & 0xFFFFu;  // 06027364 extu.w r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06027366 mov.b @r3,r1
    c.r[2] <<= 8;  // 06027368 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0602736A extu.b r1,r1
    c.r[1] |= c.r[2];  // 0602736C or r2,r1
    c.r[2] = ld32(0x0602738Cu);  // 0602736E mov.l 0x0602738C,r2
    { uint64_t p = (uint64_t)c.r[1] * c.r[2]; c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 06027370 dmulu.l r2,r1
    c.r[7] = ld32(0x06027390u);  // 06027372 mov.l 0x06027390,r7
    c.r[1] = c.mach;  // 06027374 sts mach,r1
    c.r[1] >>= 2;  // 06027376 shlr2 r1
    c.r[1] >>= 2;  // 06027378 shlr2 r1
    c.r[1] >>= 2;  // 0602737A shlr2 r1
    st32(c.r[7] + 20, c.r[1]);  // 0602737C mov.l r1,@(20,r7)
    c.r[0] = (uint32_t)(int16_t)ld16(0x06027384u);  // 0602737E mov.w 0x06027384,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06027380 rts ; mov.l @r15+,r14
}

void f_06027394(SH2Context& c) {
    ran[528] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06027394 mov.l r14,@-r15
    c.r[1] = ld32(0x060273BCu);  // 06027396 mov.l 0x060273BC,r1
    c.r[1] = ld32(c.r[1]);  // 06027398 mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060273B6u);  // 0602739A mov.w 0x060273B6,r0
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 0602739C mov.l @(r0,r1),r2
    c.r[14] = c.r[15];  // 0602739E mov r15,r14
    c.r[1] = ld32(0x060273C0u);  // 060273A0 mov.l 0x060273C0,r1
    { uint64_t p = (uint64_t)c.r[2] * c.r[1]; c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060273A2 dmulu.l r1,r2
    c.r[3] = ld32(0x060273C4u);  // 060273A4 mov.l 0x060273C4,r3
    c.r[1] = c.mach;  // 060273A6 sts mach,r1
    c.r[1] >>= 2;  // 060273A8 shlr2 r1
    c.r[1] >>= 2;  // 060273AA shlr2 r1
    c.r[1] >>= 2;  // 060273AC shlr2 r1
    st32(c.r[3] + 20, c.r[1]);  // 060273AE mov.l r1,@(20,r3)
    c.r[0] = (uint32_t)(int16_t)ld16(0x060273B8u);  // 060273B0 mov.w 0x060273B8,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060273B2 rts ; mov.l @r15+,r14
}

void f_060273C8(SH2Context& c) {
    ran[529] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060273C8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060273CA sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060273CC mov r15,r14
    c.r[0] = ld32(0x060273F0u);  // 060273CE mov.l 0x060273F0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060273D4u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060273D4u) return; }  // 060273D0 jsr @r0 ; extu.w r4,r4
    c.r[0] = c.r[0] & 0xFFu;  // 060273D4 extu.b r0,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x060273ECu);  // 060273D6 mov.w 0x060273EC,r1
    c.t = c.r[0] == c.r[1];  // 060273D8 cmp/eq r1,r0
    { const bool k = c.t; c.r[2] = c.r[0]; if (k) { goto L_060273E2; } }  // 060273DA bt/s 0x060273E2 ; mov r0,r2
    c.r[1] = ld32(0x060273F4u);  // 060273DE mov.l 0x060273F4,r1
    st8(c.r[1], c.r[0]);  // 060273E0 mov.b r0,@r1
L_060273E2:
    c.r[15] = c.r[14];  // 060273E2 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060273E4 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060273E6 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[2]; c.pc = x; return; }  // 060273E8 rts ; mov r2,r0
}

void f_060273F8(SH2Context& c) {
    ran[530] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060273F8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060273FA mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060273FC sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060273FE mov r15,r14
    c.r[0] = ld32(0x06027430u);  // 06027400 mov.l 0x06027430,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06027406u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06027406u) return; }  // 06027402 jsr @r0 ; extu.w r4,r4
    c.r[4] = c.r[0] & 0xFFu;  // 06027406 extu.b r0,r4
    c.r[8] = (uint32_t)(int16_t)ld16(0x0602742Eu);  // 06027408 mov.w 0x0602742E,r8
    c.t = c.r[4] == c.r[8];  // 0602740A cmp/eq r8,r4
    if (c.t) { goto L_06027422; }  // 0602740C bt 0x06027422
    c.r[0] = ld32(0x06027434u);  // 0602740E mov.l 0x06027434,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06027414u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06027414u) return; }  // 06027410 jsr @r0 ; nop
    c.r[4] = c.r[0] & 0xFFu;  // 06027414 extu.b r0,r4
    c.r[0] = ld32(0x06027438u);  // 06027416 mov.l 0x06027438,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602741Cu; c.r[5] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602741Cu) return; }  // 06027418 jsr @r0 ; mov #1,r5
    c.r[0] = c.r[0] & 0xFFu;  // 0602741C extu.b r0,r0
    c.t = c.r[0] == c.r[8];  // 0602741E cmp/eq r8,r0
    if (!c.t) { goto L_06027424; }  // 06027420 bf 0x06027424
L_06027422:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602742Eu);  // 06027422 mov.w 0x0602742E,r0
L_06027424:
    c.r[15] = c.r[14];  // 06027424 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06027426 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06027428 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602742A rts ; mov.l @r15+,r8
}

void f_0602743C(SH2Context& c) {
    ran[531] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602743C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602743E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06027440 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06027442 mov r15,r14
    c.r[9] = c.r[5];  // 06027444 mov r5,r9
    c.r[4] = c.r[4] & 0xFFu;  // 06027446 extu.b r4,r4
    c.r[7] = 0x0u;  // 06027448 mov #0,r7
    c.r[1] = ld32(0x060274DCu);  // 0602744A mov.l 0x060274DC,r1
    c.r[6] = ld32(c.r[1]);  // 0602744C mov.l @r1,r6
    c.r[5] = (uint32_t)(int16_t)ld16(0x060274DAu);  // 0602744E mov.w 0x060274DA,r5
    c.r[8] = 0x1Eu;  // 06027450 mov #30,r8
    c.r[0] = c.r[7];  // 06027452 mov r7,r0
L_06027454:
    c.r[0] <<= 2;  // 06027454 shll2 r0
    c.r[0] <<= 2;  // 06027456 shll2 r0
    c.r[2] = c.r[0];  // 06027458 mov r0,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 0602745A mov.b @(r0,r6),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602745C extu.b r1,r1
    c.t = c.r[1] == c.r[5];  // 0602745E cmp/eq r5,r1
    { const bool k = c.t; c.r[2] += c.r[6]; if (k) { goto L_060274C0; } }  // 06027460 bt/s 0x060274C0 ; add r6,r2
    c.r[1] = c.r[2];  // 06027464 mov r2,r1
    c.r[1] += 7;  // 06027466 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06027468 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0602746A mov r1,r0
    c.r[0] >>= 2;  // 0602746C shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0602746E shlr r0
    c.r[0] &= 0x1u;  // 06027470 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06027472 tst r0,r0
    { const bool k = c.t; c.t = (c.r[9] & c.r[9]) == 0; if (k) { goto L_0602747C; } }  // 06027474 bt/s 0x0602747C ; tst r9,r9
    { const bool k = !c.t; c.r[1] = c.r[7]; if (k) { goto L_060274C2; } }  // 06027478 bf/s 0x060274C2 ; mov r7,r1
L_0602747C:
    c.r[2] += 2;  // 0602747C add #2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602747E mov.b @r2,r1
    c.r[2] = c.r[1] & 0xFFu;  // 06027480 extu.b r1,r2
    c.t = c.r[2] == c.r[5];  // 06027482 cmp/eq r5,r2
    { const bool k = c.t; c.r[1] = c.r[7]; if (k) { goto L_060274C2; } }  // 06027484 bt/s 0x060274C2 ; mov r7,r1
    c.macl = c.r[2] * c.r[8];  // 06027488 mul.l r8,r2
    c.r[1] = ld32(0x060274E0u);  // 0602748A mov.l 0x060274E0,r1
    c.r[3] = ld32(c.r[1]);  // 0602748C mov.l @r1,r3
    c.r[2] = c.macl;  // 0602748E sts macl,r2
    c.r[2] += c.r[3];  // 06027490 add r3,r2
    c.r[1] = c.r[2];  // 06027492 mov r2,r1
    c.r[1] += 15;  // 06027494 add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06027496 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06027498 extu.b r1,r1
    c.t = c.r[1] == c.r[4];  // 0602749A cmp/eq r4,r1
    { const bool k = c.t; c.r[0] = c.r[7]; if (k) { goto L_060274D0; } }  // 0602749C bt/s 0x060274D0 ; mov r7,r0
    c.r[2] += 16;  // 060274A0 add #16,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060274A2 mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060274A4 extu.b r1,r1
    c.t = c.r[1] == c.r[5];  // 060274A6 cmp/eq r5,r1
    { const bool k = c.t; c.macl = c.r[1] * c.r[8]; if (k) { goto L_060274C0; } }  // 060274A8 bt/s 0x060274C0 ; mul.l r8,r1
    c.r[1] = c.macl;  // 060274AC sts macl,r1
    c.r[1] += c.r[3];  // 060274AE add r3,r1
    c.r[1] += 15;  // 060274B0 add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060274B2 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060274B4 extu.b r1,r1
    c.t = c.r[1] == c.r[4];  // 060274B6 cmp/eq r4,r1
    { const bool k = !c.t; c.r[1] = c.r[7]; if (k) { goto L_060274C2; } }  // 060274B8 bf/s 0x060274C2 ; mov r7,r1
    c.r[15] = c.r[14]; goto L_060274D2;  // 060274BC bra 0x060274D2 ; mov r14,r15
L_060274C0:
    c.r[1] = c.r[7];  // 060274C0 mov r7,r1
L_060274C2:
    c.r[1] += 1;  // 060274C2 add #1,r1
    c.r[7] = c.r[1] & 0xFFu;  // 060274C4 extu.b r1,r7
    c.r[1] = 0x49u;  // 060274C6 mov #73,r1
    c.t = c.r[7] > c.r[1];  // 060274C8 cmp/hi r1,r7
    { const bool k = !c.t; c.r[0] = c.r[7]; if (k) { SH2_POLL(c); goto L_06027454; } }  // 060274CA bf/s 0x06027454 ; mov r7,r0
    c.r[0] = (uint32_t)(int16_t)ld16(0x060274DAu);  // 060274CE mov.w 0x060274DA,r0
L_060274D0:
    c.r[15] = c.r[14];  // 060274D0 mov r14,r15
L_060274D2:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060274D2 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060274D4 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060274D6 rts ; mov.l @r15+,r8
}

void f_060274E4(SH2Context& c) {
    ran[532] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060274E4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060274E6 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060274E8 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060274EA mov r15,r14
    c.r[5] = (uint32_t)(int16_t)ld16(0x06027538u);  // 060274EC mov.w 0x06027538,r5
    c.r[8] = ld32(0x0602753Cu);  // 060274EE mov.l 0x0602753C,r8
    c.r[1] = ld32(0x06027540u);  // 060274F0 mov.l 0x06027540,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060274F6u; c.r[4] = ld32(c.r[8]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060274F6u) return; }  // 060274F2 jsr @r1 ; mov.l @r8,r4
    c.r[3] = 0xFFFFFFFFu;  // 060274F6 mov #-1,r3
    c.r[2] = 0x0u;  // 060274F8 mov #0,r2
    c.r[7] = (uint32_t)(int16_t)ld16(0x0602753Au);  // 060274FA mov.w 0x0602753A,r7
L_060274FC:
    c.r[0] = ld32(c.r[8]);  // 060274FC mov.l @r8,r0
    st8(c.r[0] + c.r[2], c.r[3]);  // 060274FE mov.b r3,@(r0,r2)
    c.r[1] = ld32(c.r[8]);  // 06027500 mov.l @r8,r1
    c.r[1] += c.r[2];  // 06027502 add r2,r1
    c.r[1] += 2;  // 06027504 add #2,r1
    st8(c.r[1], c.r[3]);  // 06027506 mov.b r3,@r1
    c.r[1] = ld32(c.r[8]);  // 06027508 mov.l @r8,r1
    c.r[1] += c.r[2];  // 0602750A add r2,r1
    c.r[1] += 6;  // 0602750C add #6,r1
    st8(c.r[1], c.r[3]);  // 0602750E mov.b r3,@r1
    c.r[1] = ld32(c.r[8]);  // 06027510 mov.l @r8,r1
    c.r[1] += c.r[2];  // 06027512 add r2,r1
    c.r[1] += 8;  // 06027514 add #8,r1
    st8(c.r[1], c.r[3]);  // 06027516 mov.b r3,@r1
    c.r[1] = ld32(c.r[8]);  // 06027518 mov.l @r8,r1
    c.r[1] += c.r[2];  // 0602751A add r2,r1
    c.r[1] += 5;  // 0602751C add #5,r1
    st8(c.r[1], c.r[3]);  // 0602751E mov.b r3,@r1
    c.r[1] = ld32(c.r[8]);  // 06027520 mov.l @r8,r1
    c.r[1] += c.r[2];  // 06027522 add r2,r1
    c.r[1] += 9;  // 06027524 add #9,r1
    c.r[2] += 16;  // 06027526 add #16,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[7];  // 06027528 cmp/gt r7,r2
    { const bool k = !c.t; st8(c.r[1], c.r[3]); if (k) { SH2_POLL(c); goto L_060274FC; } }  // 0602752A bf/s 0x060274FC ; mov.b r3,@r1
    c.r[15] = c.r[14];  // 0602752E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06027530 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06027532 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06027534 rts ; mov.l @r15+,r8
}

void f_06027544(SH2Context& c) {
    ran[533] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06027544 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06027546 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06027548 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0602754A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0602754C mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0602754E mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06027550 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06027552 sts.l pr,@-r15
    c.r[15] -= 36;  // 06027554 add #-36,r15
    c.r[14] = c.r[15];  // 06027556 mov r15,r14
    c.r[1] = c.r[6];  // 06027558 mov r6,r1
    c.r[0] = 0x44u;  // 0602755A mov #68,r0
    c.r[0] += c.r[14];  // 0602755C add r14,r0
    c.r[3] = 0x48u;  // 0602755E mov #72,r3
    c.r[3] += c.r[14];  // 06027560 add r14,r3
    c.r[4] = c.r[4] & 0xFFu;  // 06027562 extu.b r4,r4
    c.r[5] = c.r[5] & 0xFFu;  // 06027564 extu.b r5,r5
    c.r[1] = c.r[1] & 0xFFFFu;  // 06027566 extu.w r1,r1
    c.r[7] = c.r[7] & 0xFFu;  // 06027568 extu.b r7,r7
    c.r[11] = ld32(c.r[0]);  // 0602756A mov.l @r0,r11
    c.r[12] = ld32(c.r[3]);  // 0602756C mov.l @r3,r12
    c.r[0] = 0x4Cu;  // 0602756E mov #76,r0
    c.r[0] += c.r[14];  // 06027570 add r14,r0
    c.r[3] = 0x58u;  // 06027572 mov #88,r3
    c.r[3] += c.r[14];  // 06027574 add r14,r3
    c.r[11] = c.r[11] & 0xFFFFu;  // 06027576 extu.w r11,r11
    c.r[13] = ld32(c.r[0]);  // 06027578 mov.l @r0,r13
    c.r[12] = c.r[12] & 0xFFu;  // 0602757A extu.b r12,r12
    c.r[2] = ld32(c.r[3]);  // 0602757C mov.l @r3,r2
    c.r[0] = 0x60u;  // 0602757E mov #96,r0
    c.r[0] += c.r[14];  // 06027580 add r14,r0
    c.r[3] = 0x68u;  // 06027582 mov #104,r3
    c.r[3] += c.r[14];  // 06027584 add r14,r3
    c.r[13] = c.r[13] & 0xFFu;  // 06027586 extu.b r13,r13
    c.r[6] = ld32(c.r[0]);  // 06027588 mov.l @r0,r6
    c.r[2] = c.r[2] & 0xFFu;  // 0602758A extu.b r2,r2
    c.r[8] = ld32(c.r[3]);  // 0602758C mov.l @r3,r8
    c.r[0] = 0x6Cu;  // 0602758E mov #108,r0
    c.r[0] += c.r[14];  // 06027590 add r14,r0
    c.r[3] = 0x70u;  // 06027592 mov #112,r3
    c.r[3] += c.r[14];  // 06027594 add r14,r3
    c.r[9] = ld32(c.r[0]);  // 06027596 mov.l @r0,r9
    c.r[6] = c.r[6] & 0xFFu;  // 06027598 extu.b r6,r6
    c.r[10] = ld32(c.r[3]);  // 0602759A mov.l @r3,r10
    c.r[8] = c.r[8] & 0xFFu;  // 0602759C extu.b r8,r8
    st32(c.r[14], c.r[4]);  // 0602759E mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 060275A0 mov.l r5,@(4,r14)
    st32(c.r[14] + 8, c.r[11]);  // 060275A2 mov.l r11,@(8,r14)
    c.r[0] = 0x53u;  // 060275A4 mov #83,r0
    c.r[0] += c.r[14];  // 060275A6 add r14,r0
    c.r[3] = 0x5Fu;  // 060275A8 mov #95,r3
    c.r[3] += c.r[14];  // 060275AA add r14,r3
    c.r[11] = c.r[9] & 0xFFu;  // 060275AC extu.b r9,r11
    c.r[10] = c.r[10] & 0xFFu;  // 060275AE extu.b r10,r10
    c.r[5] = c.r[7];  // 060275B0 mov r7,r5
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0]);  // 060275B2 mov.b @r0,r0
    c.r[4] = c.r[1];  // 060275B4 mov r1,r4
    c.r[0] = c.r[0] & 0xFFu;  // 060275B6 extu.b r0,r0
    st32(c.r[14] + 12, c.r[0]);  // 060275B8 mov.l r0,@(12,r14)
    st32(c.r[14] + 16, c.r[2]);  // 060275BA mov.l r2,@(16,r14)
    c.r[0] = 0x67u;  // 060275BC mov #103,r0
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060275BE mov.b @r3,r3
    c.r[0] += c.r[14];  // 060275C0 add r14,r0
    c.r[3] = c.r[3] & 0xFFu;  // 060275C2 extu.b r3,r3
    st32(c.r[14] + 20, c.r[3]);  // 060275C4 mov.l r3,@(20,r14)
    st32(c.r[14] + 24, c.r[6]);  // 060275C6 mov.l r6,@(24,r14)
    c.r[6] = 0x0u;  // 060275C8 mov #0,r6
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0]);  // 060275CA mov.b @r0,r0
    c.r[3] = ld32(0x06027680u);  // 060275CC mov.l 0x06027680,r3
    c.r[0] = c.r[0] & 0xFFu;  // 060275CE extu.b r0,r0
    st32(c.r[14] + 28, c.r[0]);  // 060275D0 mov.l r0,@(28,r14)
    { const uint32_t x = c.r[3]; c.pr = 0x060275D6u; st32(c.r[14] + 32, c.r[8]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060275D6u) return; }  // 060275D2 jsr @r3 ; mov.l r8,@(32,r14)
    c.r[1] = c.r[0];  // 060275D6 mov r0,r1
    c.r[9] = c.r[1] & 0xFFu;  // 060275D8 extu.b r1,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602767Eu);  // 060275DA mov.w 0x0602767E,r0
    c.t = c.r[9] == c.r[0];  // 060275DC cmp/eq r0,r9
    if (c.t) { goto L_06027668; }  // 060275DE bt 0x06027668
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060275E0 mov.l r10,@-r15
    c.r[7] = c.r[13];  // 060275E2 mov r13,r7
    c.r[6] = 0x0u;  // 060275E4 mov #0,r6
    c.r[5] = c.r[12];  // 060275E6 mov r12,r5
    c.r[3] = ld32(0x06027684u);  // 060275E8 mov.l 0x06027684,r3
    { const uint32_t x = c.r[3]; c.pr = 0x060275EEu; c.r[4] = ld32(c.r[14] + 8); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060275EEu) return; }  // 060275EA jsr @r3 ; mov.l @(8,r14),r4
    c.r[1] = c.r[0];  // 060275EE mov r0,r1
    c.r[8] = c.r[1] & 0xFFu;  // 060275F0 extu.b r1,r8
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602767Eu);  // 060275F2 mov.w 0x0602767E,r0
    c.t = c.r[8] == c.r[0];  // 060275F4 cmp/eq r0,r8
    { const bool k = c.t; c.r[15] += 4; if (k) { goto L_06027668; } }  // 060275F6 bt/s 0x06027668 ; add #4,r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060275FA mov.l r11,@-r15
    c.r[3] = ld32(c.r[14] + 32);  // 060275FC mov.l @(32,r14),r3
    c.r[15] -= 4; st32(c.r[15], c.r[3]);  // 060275FE mov.l r3,@-r15
    c.r[0] = ld32(c.r[14] + 28);  // 06027600 mov.l @(28,r14),r0
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 06027602 mov.l r0,@-r15
    c.r[7] = ld32(c.r[14] + 24);  // 06027604 mov.l @(24,r14),r7
    c.r[6] = ld32(c.r[14] + 20);  // 06027606 mov.l @(20,r14),r6
    c.r[1] = ld32(0x06027688u);  // 06027608 mov.l 0x06027688,r1
    c.r[5] = ld32(c.r[14] + 16);  // 0602760A mov.l @(16,r14),r5
    { const uint32_t x = c.r[1]; c.pr = 0x06027610u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06027610u) return; }  // 0602760C jsr @r1 ; mov r8,r4
    c.r[5] = c.r[9];  // 06027610 mov r9,r5
    c.r[3] = ld32(0x0602768Cu);  // 06027612 mov.l 0x0602768C,r3
    { const uint32_t x = c.r[3]; c.pr = 0x06027618u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06027618u) return; }  // 06027614 jsr @r3 ; mov r8,r4
    c.r[4] = 0x1u;  // 06027618 mov #1,r4
    c.r[15] -= 4; st32(c.r[15], c.r[4]);  // 0602761A mov.l r4,@-r15
    c.r[0] = 0x54u;  // 0602761C mov #84,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 0602761E mov.l @(r0,r14),r0
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 06027620 mov.l r0,@-r15
    c.r[1] = ld32(c.r[14] + 12);  // 06027622 mov.l @(12,r14),r1
    c.r[3] = 0x3u;  // 06027624 mov #3,r3
    c.r[1] >>= 2;  // 06027626 shlr2 r1
    c.r[1] &= c.r[3];  // 06027628 and r3,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0602762A mov.l r1,@-r15
    c.r[0] = ld32(c.r[14] + 12);  // 0602762C mov.l @(12,r14),r0
    c.r[0] >>= 2;  // 0602762E shlr2 r0
    c.r[0] >>= 2;  // 06027630 shlr2 r0
    c.r[0] &= 0x7u;  // 06027632 and #7,r0
    st32(c.r[14] + 12, c.r[0]);  // 06027634 mov.l r0,@(12,r14)
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 06027636 mov.l r0,@-r15
    c.r[7] = ld32(c.r[14] + 4);  // 06027638 mov.l @(4,r14),r7
    c.r[5] = c.r[8];  // 0602763A mov r8,r5
    c.r[3] = ld32(0x06027690u);  // 0602763C mov.l 0x06027690,r3
    { const uint32_t x = c.r[3]; c.pr = 0x06027642u; c.r[6] = ld32(c.r[14]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06027642u) return; }  // 0602763E jsr @r3 ; mov.l @r14,r6
    c.r[1] = c.r[0];  // 06027642 mov r0,r1
    c.r[8] = c.r[1] & 0xFFu;  // 06027644 extu.b r1,r8
    c.r[1] = ld32(0x06027694u);  // 06027646 mov.l 0x06027694,r1
    c.r[2] = c.r[8];  // 06027648 mov r8,r2
    c.r[2] <<= 2;  // 0602764A shll2 r2
    c.r[2] <<= 2;  // 0602764C shll2 r2
    c.r[0] = 0x7Fu;  // 0602764E mov #127,r0
    c.r[4] = (uint32_t)(int32_t)(int16_t)c.r[8];  // 06027650 exts.w r8,r4
    c.r[1] = ld32(c.r[1]);  // 06027652 mov.l @r1,r1
    c.r[6] = 0x0u;  // 06027654 mov #0,r6
    c.r[2] += c.r[1];  // 06027656 add r1,r2
    c.r[2] += 3;  // 06027658 add #3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602765A mov.b @r2,r1
    c.r[1] &= c.r[0];  // 0602765C and r0,r1
    st8(c.r[2], c.r[1]);  // 0602765E mov.b r1,@r2
    c.r[1] = ld32(0x06027698u);  // 06027660 mov.l 0x06027698,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06027666u; c.r[5] = 0xEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06027666u) return; }  // 06027662 jsr @r1 ; mov #14,r5
    c.r[0] = c.r[8];  // 06027666 mov r8,r0
L_06027668:
    c.r[14] += 36;  // 06027668 add #36,r14
    c.r[15] = c.r[14];  // 0602766A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602766C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602766E mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06027670 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06027672 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06027674 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06027676 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06027678 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602767A rts ; mov.l @r15+,r8
}

void f_0602769C(SH2Context& c) {
    ran[534] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602769C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602769E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060276A0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060276A2 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060276A4 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060276A6 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060276A8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060276AA sts.l pr,@-r15
    c.r[15] -= 8;  // 060276AC add #-8,r15
    c.r[14] = c.r[15];  // 060276AE mov r15,r14
    c.r[4] = c.r[4] & 0xFFu;  // 060276B0 extu.b r4,r4
    st32(c.r[14], c.r[4]);  // 060276B2 mov.l r4,@r14
    c.r[5] = c.r[5] & 0xFFu;  // 060276B4 extu.b r5,r5
    st32(c.r[14] + 4, c.r[5]);  // 060276B6 mov.l r5,@(4,r14)
    c.r[9] = c.r[6] & 0xFFFFu;  // 060276B8 extu.w r6,r9
    c.r[10] = c.r[7] & 0xFFu;  // 060276BA extu.b r7,r10
    c.r[8] = (uint32_t)(int16_t)ld16(0x06027754u);  // 060276BC mov.w 0x06027754,r8
    c.r[0] = ld32(0x06027758u);  // 060276BE mov.l 0x06027758,r0
    c.r[1] = ld32(c.r[14] + 40);  // 060276C0 mov.l @(40,r14),r1
    c.r[4] = c.r[9];  // 060276C2 mov r9,r4
    c.r[2] = ld32(c.r[14] + 44);  // 060276C4 mov.l @(44,r14),r2
    c.r[12] = c.r[1] & 0xFFFFu;  // 060276C6 extu.w r1,r12
    { const uint32_t x = c.r[0]; c.pr = 0x060276CCu; c.r[11] = c.r[2] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060276CCu) return; }  // 060276C8 jsr @r0 ; extu.b r2,r11
    c.r[1] = c.r[0] & 0xFFu;  // 060276CC extu.b r0,r1
    c.t = c.r[1] == c.r[8];  // 060276CE cmp/eq r8,r1
    { const bool k = !c.t; c.r[6] = c.r[11]; if (k) { goto L_0602773C; } }  // 060276D0 bf/s 0x0602773C ; mov r11,r6
    c.r[0] = ld32(0x0602775Cu);  // 060276D4 mov.l 0x0602775C,r0
    c.r[5] = c.r[10];  // 060276D6 mov r10,r5
    { const uint32_t x = c.r[0]; c.pr = 0x060276DCu; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060276DCu) return; }  // 060276D8 jsr @r0 ; mov r9,r4
    c.r[9] = c.r[0] & 0xFFu;  // 060276DC extu.b r0,r9
    c.t = c.r[9] == c.r[8];  // 060276DE cmp/eq r8,r9
    { const bool k = c.t; c.r[13] = 0x0u; if (k) { goto L_0602773C; } }  // 060276E0 bt/s 0x0602773C ; mov #0,r13
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060276E4 mov.l r13,@-r15
    c.r[0] = ld32(0x06027760u);  // 060276E6 mov.l 0x06027760,r0
    c.r[7] = c.r[8];  // 060276E8 mov r8,r7
    c.r[6] = c.r[11];  // 060276EA mov r11,r6
    c.r[5] = 0x0u;  // 060276EC mov #0,r5
    { const uint32_t x = c.r[0]; c.pr = 0x060276F2u; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060276F2u) return; }  // 060276EE jsr @r0 ; mov r12,r4
    c.r[10] = c.r[0] & 0xFFu;  // 060276F2 extu.b r0,r10
    c.t = c.r[10] == c.r[8];  // 060276F4 cmp/eq r8,r10
    { const bool k = c.t; c.r[15] += 4; if (k) { goto L_0602773C; } }  // 060276F6 bt/s 0x0602773C ; add #4,r15
    c.r[0] = ld32(0x06027764u);  // 060276FA mov.l 0x06027764,r0
    c.r[5] = c.r[9];  // 060276FC mov r9,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06027702u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06027702u) return; }  // 060276FE jsr @r0 ; mov r10,r4
    c.r[1] = c.r[0] & 0xFFu;  // 06027702 extu.b r0,r1
    c.t = c.r[1] == c.r[8];  // 06027704 cmp/eq r8,r1
    { const bool k = c.t; c.r[1] = 0x1u; if (k) { goto L_0602773C; } }  // 06027706 bt/s 0x0602773C ; mov #1,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0602770A mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0602770C mov.l r13,@-r15
    c.r[1] = ld32(0x06027768u);  // 0602770E mov.l 0x06027768,r1
    c.r[2] = c.r[9];  // 06027710 mov r9,r2
    c.r[2] += c.r[2];  // 06027712 add r2,r2
    c.r[2] += c.r[9];  // 06027714 add r9,r2
    c.r[1] = ld32(c.r[1]);  // 06027716 mov.l @r1,r1
    c.r[2] <<= 2;  // 06027718 shll2 r2
    c.r[2] += c.r[1];  // 0602771A add r1,r2
    c.r[2] += 3;  // 0602771C add #3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602771E mov.b @r2,r1
    c.r[0] = ld32(0x0602776Cu);  // 06027720 mov.l 0x0602776C,r0
    c.r[1] = c.r[1] & 0xFFu;  // 06027722 extu.b r1,r1
    c.r[1] >>= 2;  // 06027724 shlr2 r1
    c.r[1] >>= 2;  // 06027726 shlr2 r1
    c.r[1] >>= 2;  // 06027728 shlr2 r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0602772A mov.l r1,@-r15
    c.r[1] = 0x2u;  // 0602772C mov #2,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0602772E mov.l r1,@-r15
    c.r[7] = ld32(c.r[14] + 4);  // 06027730 mov.l @(4,r14),r7
    c.r[5] = c.r[10];  // 06027732 mov r10,r5
    c.r[6] = ld32(c.r[14]);  // 06027734 mov.l @r14,r6
    { const uint32_t x = c.r[0]; c.pr = 0x0602773Au; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602773Au) return; }  // 06027736 jsr @r0 ; mov #0,r4
    c.r[8] = c.r[0] & 0xFFu;  // 0602773A extu.b r0,r8
L_0602773C:
    c.r[14] += 8;  // 0602773C add #8,r14
    c.r[15] = c.r[14];  // 0602773E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06027740 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06027742 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06027744 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06027746 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06027748 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0602774A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0602774C mov.l @r15+,r9
    c.r[0] = c.r[8];  // 0602774E mov r8,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06027750 rts ; mov.l @r15+,r8
}

void f_06027770(SH2Context& c) {
    ran[535] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06027770 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06027772 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06027774 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06027776 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06027778 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0602777A mov r15,r14
    c.r[9] = c.r[4] & 0xFFu;  // 0602777C extu.b r4,r9
    c.r[10] = c.r[5] & 0xFFu;  // 0602777E extu.b r5,r10
    c.r[6] = c.r[6] & 0xFFFFu;  // 06027780 extu.w r6,r6
    c.r[8] = (uint32_t)(int16_t)ld16(0x06027814u);  // 06027782 mov.w 0x06027814,r8
    c.r[0] = ld32(0x0602781Cu);  // 06027784 mov.l 0x0602781C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602778Au; c.r[4] = c.r[6]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602778Au) return; }  // 06027786 jsr @r0 ; mov r6,r4
    c.r[6] = c.r[0] & 0xFFu;  // 0602778A extu.b r0,r6
    c.t = c.r[6] == c.r[8];  // 0602778C cmp/eq r8,r6
    { const bool k = c.t; c.t = c.r[9] == c.r[8]; if (k) { goto L_06027804; } }  // 0602778E bt/s 0x06027804 ; cmp/eq r8,r9
    { const bool k = c.t; c.r[7] = 0x2u; if (k) { goto L_060277D2; } }  // 06027792 bt/s 0x060277D2 ; mov #2,r7
    c.r[0] = ld32(0x06027820u);  // 06027796 mov.l 0x06027820,r0
    c.r[5] = c.r[10];  // 06027798 mov r10,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0602779Eu; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602779Eu) return; }  // 0602779A jsr @r0 ; mov r9,r4
    c.r[8] = c.r[0] & 0xFFu;  // 0602779E extu.b r0,r8
    c.r[1] = ld32(0x06027824u);  // 060277A0 mov.l 0x06027824,r1
    c.r[2] = c.r[8];  // 060277A2 mov r8,r2
    c.r[1] = ld32(c.r[1]);  // 060277A4 mov.l @r1,r1
    c.r[2] <<= 2;  // 060277A6 shll2 r2
    c.r[2] <<= 2;  // 060277A8 shll2 r2
    c.r[2] += c.r[1];  // 060277AA add r1,r2
    c.r[1] = c.r[2];  // 060277AC mov r2,r1
    c.r[1] += 7;  // 060277AE add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060277B0 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060277B2 extu.b r1,r1
    c.r[1] >>= 2;  // 060277B4 shlr2 r1
    c.r[1] >>= 2;  // 060277B6 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060277B8 shlr r1
    c.r[1] >>= 2;  // 060277BA shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060277BC tst r1,r1
    { const bool k = c.t; c.r[2] += 3; if (k) { goto L_06027804; } }  // 060277BE bt/s 0x06027804 ; add #3,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060277C2 mov.b @r2,r0
    c.r[1] = ld32(0x06027828u);  // 060277C4 mov.l 0x06027828,r1
    c.r[1] = ld32(c.r[1]);  // 060277C6 mov.l @r1,r1
    c.r[0] &= 0x6u;  // 060277C8 and #6,r0
    c.r[0] += c.r[1];  // 060277CA add r1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06027816u);  // 060277CC mov.w 0x06027816,r1
    st16(c.r[0] + c.r[1], c.r[8]); goto L_06027804;  // 060277CE bra 0x06027804 ; mov.w r8,@(r0,r1)
L_060277D2:
    c.r[0] = ld32(0x06027820u);  // 060277D2 mov.l 0x06027820,r0
    c.r[5] = 0x0u;  // 060277D4 mov #0,r5
    { const uint32_t x = c.r[0]; c.pr = 0x060277DAu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060277DAu) return; }  // 060277D6 jsr @r0 ; mov #0,r4
    c.r[8] = c.r[0] & 0xFFu;  // 060277DA extu.b r0,r8
    c.t = c.r[8] == c.r[9];  // 060277DC cmp/eq r9,r8
    { const bool k = c.t; c.r[2] = c.r[8]; if (k) { goto L_06027804; } }  // 060277DE bt/s 0x06027804 ; mov r8,r2
    c.r[3] = ld32(0x06027824u);  // 060277E2 mov.l 0x06027824,r3
    c.r[2] <<= 2;  // 060277E4 shll2 r2
    c.r[2] <<= 2;  // 060277E6 shll2 r2
    c.r[1] = ld32(0x06027828u);  // 060277E8 mov.l 0x06027828,r1
    c.r[7] = ld32(c.r[3]);  // 060277EA mov.l @r3,r7
    c.r[0] = (uint32_t)(int16_t)ld16(0x06027818u);  // 060277EC mov.w 0x06027818,r0
    c.r[1] = ld32(c.r[1]);  // 060277EE mov.l @r1,r1
    c.r[7] += c.r[2];  // 060277F0 add r2,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060277F2 mov.b @(r0,r1),r1
    c.r[7] += 5;  // 060277F4 add #5,r7
    st8(c.r[7], c.r[1]);  // 060277F6 mov.b r1,@r7
    c.r[1] = ld32(c.r[3]);  // 060277F8 mov.l @r3,r1
    c.r[1] += c.r[2];  // 060277FA add r2,r1
    c.r[1] += 4;  // 060277FC add #4,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060277FE mov.b @r1,r0
    c.r[0] |= 0x40u;  // 06027800 or #64,r0
    st8(c.r[1], c.r[0]);  // 06027802 mov.b r0,@r1
L_06027804:
    c.r[15] = c.r[14];  // 06027804 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06027806 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06027808 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0602780A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0602780C mov.l @r15+,r9
    c.r[0] = c.r[8];  // 0602780E mov r8,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06027810 rts ; mov.l @r15+,r8
}

void f_0602782C(SH2Context& c) {
    ran[536] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602782C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602782E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06027830 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06027832 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06027834 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06027836 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06027838 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602783A sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x06027926u);  // 0602783C mov.w 0x06027926,r3
    c.r[15] += c.r[3];  // 0602783E add r3,r15
    c.r[14] = c.r[15];  // 06027840 mov r15,r14
    c.r[4] = c.r[4] & 0xFFu;  // 06027842 extu.b r4,r4
    c.r[0] = (uint32_t)(int16_t)ld16(0x06027928u);  // 06027844 mov.w 0x06027928,r0
    st32(c.r[0] + c.r[14], c.r[4]);  // 06027846 mov.l r4,@(r0,r14)
    c.r[5] = c.r[5] & 0xFFu;  // 06027848 extu.b r5,r5
    c.r[11] = (uint32_t)(int16_t)ld16(0x0602792Au);  // 0602784A mov.w 0x0602792A,r11
    c.r[11] += c.r[14];  // 0602784C add r14,r11
    st32(c.r[11], c.r[5]);  // 0602784E mov.l r5,@r11
    c.r[10] = c.r[6] & 0xFFu;  // 06027850 extu.b r6,r10
    c.r[1] = ld32(0x06027934u);  // 06027852 mov.l 0x06027934,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602792Cu);  // 06027854 mov.w 0x0602792C,r0
    c.r[0] += c.r[14];  // 06027856 add r14,r0
    c.r[2] = ld32(c.r[1]);  // 06027858 mov.l @r1,r2
    c.r[11] = (uint32_t)(int16_t)ld16(0x0602792Cu);  // 0602785A mov.w 0x0602792C,r11
    c.r[1] = 0x1Eu;  // 0602785C mov #30,r1
    c.macl = c.r[10] * c.r[1];  // 0602785E mul.l r1,r10
    c.r[11] += c.r[14];  // 06027860 add r14,r11
    c.r[4] = ld32(0x06027938u);  // 06027862 mov.l 0x06027938,r4
    c.r[7] = c.macl;  // 06027864 sts macl,r7
    c.r[7] += c.r[2];  // 06027866 add r2,r7
    c.r[1] = c.r[7];  // 06027868 mov r7,r1
    c.r[1] += 15;  // 0602786A add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602786C mov.b @r1,r1
    c.r[2] = ld32(0x0602793Cu);  // 0602786E mov.l 0x0602793C,r2
    c.r[2] = ld32(c.r[2]);  // 06027870 mov.l @r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06027872 extu.b r1,r1
    c.r[3] = c.r[1];  // 06027874 mov r1,r3
    c.r[3] += c.r[3];  // 06027876 add r3,r3
    c.r[3] += c.r[1];  // 06027878 add r1,r3
    c.r[3] <<= 2;  // 0602787A shll2 r3
    c.r[3] += c.r[2];  // 0602787C add r2,r3
    c.r[3] += 3;  // 0602787E add #3,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06027880 mov.b @r3,r1
    c.r[9] = ld32(0x06027940u);  // 06027882 mov.l 0x06027940,r9
    c.r[1] = c.r[1] & 0xFFu;  // 06027884 extu.b r1,r1
    st32(c.r[0], c.r[1]);  // 06027886 mov.l r1,@r0
    c.r[0] = ld32(c.r[11]);  // 06027888 mov.l @r11,r0
    c.r[5] = 0x1Bu;  // 0602788A mov #27,r5
    c.r[0] >>= 2;  // 0602788C shlr2 r0
    c.r[0] >>= 2;  // 0602788E shlr2 r0
    c.r[0] >>= 2;  // 06027890 shlr2 r0
    st32(c.r[11], c.r[0]);  // 06027892 mov.l r0,@r11
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[7]);  // 06027894 mov.w @r7,r8
    { const uint32_t x = c.r[9]; c.pr = 0x0602789Au; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602789Au) return; }  // 06027896 jsr @r9 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 0602789A mov r0,r1
    c.r[5] = c.r[8];  // 0602789C mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x060278A2u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060278A2u) return; }  // 0602789E jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 060278A2 mov r0,r1
    c.r[1] += 7;  // 060278A4 add #7,r1
    c.r[11] = (uint32_t)(int16_t)ld16(0x0602792Eu);  // 060278A6 mov.w 0x0602792E,r11
    c.r[11] += c.r[14];  // 060278A8 add r14,r11
    c.r[9] = 0x7u;  // 060278AA mov #7,r9
    c.r[5] = c.r[10];  // 060278AC mov r10,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060278AE mov.b @r1,r1
    c.r[4] = 0x0u;  // 060278B0 mov #0,r4
    c.r[0] = c.r[1];  // 060278B2 mov r1,r0
    c.r[0] &= 0x78u;  // 060278B4 and #120,r0
    st32(c.r[11], c.r[0]);  // 060278B6 mov.l r0,@r11
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602792Eu);  // 060278B8 mov.w 0x0602792E,r0
    c.r[0] += c.r[14];  // 060278BA add r14,r0
    c.r[9] &= c.r[1];  // 060278BC and r1,r9
    c.r[11] = ld32(c.r[0]);  // 060278BE mov.l @r0,r11
    c.r[1] = 0x1u;  // 060278C0 mov #1,r1
    c.r[11] >>= 2;  // 060278C2 shlr2 r11
    c.t = c.r[11] & 1; c.r[11] >>= 1;  // 060278C4 shlr r11
    st32(c.r[0], c.r[11]);  // 060278C6 mov.l r11,@r0
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060278C8 mov.l r1,@-r15
    c.r[1] = 0x0u;  // 060278CA mov #0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060278CC mov.l r1,@-r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602792Cu);  // 060278CE mov.w 0x0602792C,r0
    c.r[0] += c.r[14];  // 060278D0 add r14,r0
    c.r[1] = 0x2u;  // 060278D2 mov #2,r1
    c.r[11] = (uint32_t)(int16_t)ld16(0x0602792Au);  // 060278D4 mov.w 0x0602792A,r11
    c.r[0] = ld32(c.r[0]);  // 060278D6 mov.l @r0,r0
    c.r[11] += c.r[14];  // 060278D8 add r14,r11
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 060278DA mov.l r0,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060278DC mov.l r1,@-r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x06027928u);  // 060278DE mov.w 0x06027928,r0
    c.r[7] = ld32(c.r[11]);  // 060278E0 mov.l @r11,r7
    c.r[0] += c.r[14];  // 060278E2 add r14,r0
    c.r[11] = ld32(0x06027944u);  // 060278E4 mov.l 0x06027944,r11
    { const uint32_t x = c.r[11]; c.pr = 0x060278EAu; c.r[6] = ld32(c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060278EAu) return; }  // 060278E6 jsr @r11 ; mov.l @r0,r6
    c.r[1] = c.r[0];  // 060278EA mov r0,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060278EC extu.b r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06027930u);  // 060278EE mov.w 0x06027930,r0
    st32(c.r[0] + c.r[14], c.r[1]);  // 060278F0 mov.l r1,@(r0,r14)
    c.r[11] = (uint32_t)(int16_t)ld16(0x0602792Eu);  // 060278F2 mov.w 0x0602792E,r11
    c.r[11] += c.r[14];  // 060278F4 add r14,r11
    c.r[2] = ld32(c.r[11]);  // 060278F6 mov.l @r11,r2
    c.r[1] = 0x8u;  // 060278F8 mov #8,r1
    c.r[2] -= 1;  // 060278FA add #-1,r2
    c.t = c.r[2] > c.r[1];  // 060278FC cmp/hi r1,r2
    { const bool k = !c.t; c.r[15] += 16; if (k) { goto L_06027906; } }  // 060278FE bf/s 0x06027906 ; add #16,r15
    goto L_06027ED4;  // 06027902 bra 0x06027ED4 ; nop
L_06027906:
    c.r[1] = c.r[2];  // 06027906 mov r2,r1
    c.r[1] += c.r[1];  // 06027908 add r1,r1
    c.r[0] = 0x06027914u;  // 0602790A mova 0x06027914,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0602790C mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 0602790E add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x06027ED4u: goto L_06027ED4; case 0x06027948u: goto L_06027948; case 0x06027A5Cu: goto L_06027A5C; case 0x06027C08u: goto L_06027C08; case 0x06027E22u: goto L_06027E22; default: sh2_call(c, x); return; } }  // 06027910 jmp @r0 ; nop
L_06027948:
    c.r[6] = c.r[14];  // 06027948 mov r14,r6
    c.r[5] = 0x3u;  // 0602794A mov #3,r5
    c.r[0] = ld32(0x06027ACCu);  // 0602794C mov.l 0x06027ACC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06027952u; c.r[4] = 0x4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06027952u) return; }  // 0602794E jsr @r0 ; mov #4,r4
    c.r[8] = 0x0u;  // 06027952 mov #0,r8
    c.r[6] = c.r[14];  // 06027954 mov r14,r6
    c.r[6] += 1;  // 06027956 add #1,r6
    c.r[7] = 0x0u;  // 06027958 mov #0,r7
    c.r[3] = 0x6u;  // 0602795A mov #6,r3
L_0602795C:
    c.r[0] = c.r[7];  // 0602795C mov r7,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 0602795E mov.b @(r0,r14),r1
    c.r[5] = 0x7Fu;  // 06027960 mov #127,r5
    c.r[5] &= c.r[1];  // 06027962 and r1,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 06027964 mov.b @(r0,r6),r1
    c.r[5] <<= 8;  // 06027966 shll8 r5
    c.r[2] = c.r[1] & 0xFFu;  // 06027968 extu.b r1,r2
    c.r[2] |= c.r[5];  // 0602796A or r5,r2
    c.r[1] = c.r[2] & 0xFFu;  // 0602796C extu.b r2,r1
    c.t = c.r[10] == c.r[1];  // 0602796E cmp/eq r1,r10
    { const bool k = c.t; c.r[2] = c.r[2] & 0xFFFFu; if (k) { goto L_0602798A; } }  // 06027970 bt/s 0x0602798A ; extu.w r2,r2
    c.r[1] = c.r[2];  // 06027974 mov r2,r1
    c.r[1] >>= 8;  // 06027976 shlr8 r1
    c.r[0] = c.r[14];  // 06027978 mov r14,r0
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0602797A mov.b @(r0,r3),r5
    c.r[11] = (uint32_t)(int16_t)ld16(0x06027ABAu);  // 0602797C mov.w 0x06027ABA,r11
    c.r[5] &= c.r[11];  // 0602797E and r11,r5
    c.r[5] |= c.r[1];  // 06027980 or r1,r5
    st8(c.r[0] + c.r[3], c.r[5]);  // 06027982 mov.b r5,@(r0,r3)
    c.r[0] = c.r[6];  // 06027984 mov r6,r0
    st8(c.r[0] + c.r[3], c.r[2]);  // 06027986 mov.b r2,@(r0,r3)
    c.r[3] += 2;  // 06027988 add #2,r3
L_0602798A:
    c.r[8] += 1;  // 0602798A add #1,r8
    c.r[2] = 0x2u;  // 0602798C mov #2,r2
    c.t = (int32_t)c.r[8] > (int32_t)c.r[2];  // 0602798E cmp/gt r2,r8
    { const bool k = !c.t; c.r[7] += 2; if (k) { SH2_POLL(c); goto L_0602795C; } }  // 06027990 bf/s 0x0602795C ; add #2,r7
    c.r[1] = c.r[14];  // 06027994 mov r14,r1
    c.r[1] += 7;  // 06027996 add #7,r1
    c.r[8] = 0x0u;  // 06027998 mov #0,r8
    c.r[11] = (uint32_t)(int16_t)ld16(0x06027ABCu);  // 0602799A mov.w 0x06027ABC,r11
    c.r[11] += c.r[14];  // 0602799C add r14,r11
    c.r[9] = ld32(0x06027AD0u);  // 0602799E mov.l 0x06027AD0,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06027ABEu);  // 060279A0 mov.w 0x06027ABE,r0
    c.r[0] += c.r[14];  // 060279A2 add r14,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060279A4 mov.b @r1,r1
    c.r[4] = 0x0u;  // 060279A6 mov #0,r4
    c.r[12] = c.r[1] & 0xFFu;  // 060279A8 extu.b r1,r12
    c.r[1] = c.r[14];  // 060279AA mov r14,r1
    c.r[1] += 9;  // 060279AC add #9,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060279AE mov.b @r1,r1
    c.r[5] = c.r[12];  // 060279B0 mov r12,r5
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060279B2 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060279B4 mov.l r8,@-r15
    c.r[11] = ld32(c.r[11]);  // 060279B6 mov.l @r11,r11
    c.r[13] = c.r[1] & 0xFFu;  // 060279B8 extu.b r1,r13
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060279BA mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 060279BC mov.l r2,@-r15
    c.r[11] = (uint32_t)(int16_t)ld16(0x06027AC0u);  // 060279BE mov.w 0x06027AC0,r11
    c.r[7] = ld32(c.r[0]);  // 060279C0 mov.l @r0,r7
    c.r[11] += c.r[14];  // 060279C2 add r14,r11
    c.r[6] = ld32(c.r[11]);  // 060279C4 mov.l @r11,r6
    c.r[0] = (uint32_t)(int16_t)ld16(0x06027AC2u);  // 060279C6 mov.w 0x06027AC2,r0
    c.r[0] += c.r[14];  // 060279C8 add r14,r0
    { const uint32_t x = c.r[9]; c.pr = 0x060279CEu; st32(c.r[0], c.r[2]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060279CEu) return; }  // 060279CA jsr @r9 ; mov.l r2,@r0
    c.r[1] = c.r[0];  // 060279CE mov r0,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060279D0 extu.b r1,r1
    c.r[11] = (uint32_t)(int16_t)ld16(0x06027AC4u);  // 060279D2 mov.w 0x06027AC4,r11
    c.r[11] += c.r[14];  // 060279D4 add r14,r11
    st32(c.r[11], c.r[1]);  // 060279D6 mov.l r1,@r11
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060279D8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060279DA mov.l r8,@-r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x06027ABCu);  // 060279DC mov.w 0x06027ABC,r0
    c.r[0] += c.r[14];  // 060279DE add r14,r0
    c.r[11] = (uint32_t)(int16_t)ld16(0x06027AC2u);  // 060279E0 mov.w 0x06027AC2,r11
    c.r[11] += c.r[14];  // 060279E2 add r14,r11
    c.r[0] = ld32(c.r[0]);  // 060279E4 mov.l @r0,r0
    c.r[5] = c.r[13];  // 060279E6 mov r13,r5
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 060279E8 mov.l r0,@-r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x06027ABEu);  // 060279EA mov.w 0x06027ABE,r0
    c.r[2] = ld32(c.r[11]);  // 060279EC mov.l @r11,r2
    c.r[0] += c.r[14];  // 060279EE add r14,r0
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 060279F0 mov.l r2,@-r15
    c.r[11] = (uint32_t)(int16_t)ld16(0x06027AC0u);  // 060279F2 mov.w 0x06027AC0,r11
    c.r[7] = ld32(c.r[0]);  // 060279F4 mov.l @r0,r7
    c.r[11] += c.r[14];  // 060279F6 add r14,r11
    c.r[6] = ld32(c.r[11]);  // 060279F8 mov.l @r11,r6
    { const uint32_t x = c.r[9]; c.pr = 0x060279FEu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060279FEu) return; }  // 060279FA jsr @r9 ; mov #0,r4
    c.r[1] = c.r[0];  // 060279FE mov r0,r1
    c.r[3] = c.r[1] & 0xFFu;  // 06027A00 extu.b r1,r3
    c.r[6] = ld32(0x06027AD4u);  // 06027A02 mov.l 0x06027AD4,r6
    c.r[0] = (uint32_t)(int16_t)ld16(0x06027AC4u);  // 06027A04 mov.w 0x06027AC4,r0
    c.r[7] = ld32(c.r[0] + c.r[14]);  // 06027A06 mov.l @(r0,r14),r7
    c.r[11] = 0x20u;  // 06027A08 mov #32,r11
    c.r[1] = ld32(c.r[6]);  // 06027A0A mov.l @r6,r1
    c.r[7] <<= 2;  // 06027A0C shll2 r7
    c.r[7] <<= 2;  // 06027A0E shll2 r7
    c.r[2] = c.r[7];  // 06027A10 mov r7,r2
    c.r[2] += c.r[1];  // 06027A12 add r1,r2
    c.r[3] <<= 2;  // 06027A14 shll2 r3
    c.r[3] <<= 2;  // 06027A16 shll2 r3
    c.r[1] += c.r[3];  // 06027A18 add r3,r1
    c.r[1] += 4;  // 06027A1A add #4,r1
    c.r[2] += 4;  // 06027A1C add #4,r2
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06027A1E mov.b @r1,r5
    c.r[0] = (uint32_t)(int16_t)ld16(0x06027AC6u);  // 06027A20 mov.w 0x06027AC6,r0
    c.r[5] |= c.r[11];  // 06027A22 or r11,r5
    st8(c.r[1], c.r[5]);  // 06027A24 mov.b r5,@r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06027A26 mov.b @r2,r1
    c.r[0] += c.r[14];  // 06027A28 add r14,r0
    c.r[1] |= c.r[11];  // 06027A2A or r11,r1
    st8(c.r[2], c.r[1]);  // 06027A2C mov.b r1,@r2
    c.r[2] = ld32(c.r[6]);  // 06027A2E mov.l @r6,r2
    c.r[5] = c.r[7];  // 06027A30 mov r7,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06027A32 mov.b @r0,r1
    c.r[5] += c.r[2];  // 06027A34 add r2,r5
    c.r[5] += 6;  // 06027A36 add #6,r5
    c.r[2] += c.r[3];  // 06027A38 add r3,r2
    c.r[2] += 6;  // 06027A3A add #6,r2
    st8(c.r[2], c.r[1]);  // 06027A3C mov.b r1,@r2
    st8(c.r[5], c.r[1]);  // 06027A3E mov.b r1,@r5
    c.r[1] = ld32(c.r[6]);  // 06027A40 mov.l @r6,r1
    c.r[11] = 0x7Fu;  // 06027A42 mov #127,r11
    c.r[7] += c.r[1];  // 06027A44 add r1,r7
    c.r[3] += c.r[1];  // 06027A46 add r1,r3
    c.r[3] += 3;  // 06027A48 add #3,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06027A4A mov.b @r3,r1
    c.r[7] += 3;  // 06027A4C add #3,r7
    c.r[1] &= c.r[11];  // 06027A4E and r11,r1
    st8(c.r[3], c.r[1]);  // 06027A50 mov.b r1,@r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06027A52 mov.b @r7,r1
    c.r[15] += 32;  // 06027A54 add #32,r15
    c.r[1] &= c.r[11];  // 06027A56 and r11,r1
    st8(c.r[7], c.r[1]); goto L_06027ED4;  // 06027A58 bra 0x06027ED4 ; mov.b r1,@r7
L_06027A5C:
    c.r[8] = 0x0u;  // 06027A5C mov #0,r8
    c.r[6] = 0x0u;  // 06027A5E mov #0,r6
    c.r[4] = ld32(0x06027AD8u);  // 06027A60 mov.l 0x06027AD8,r4
    c.r[5] = c.r[14];  // 06027A62 mov r14,r5
    c.r[5] += 1;  // 06027A64 add #1,r5
    c.r[7] = 0x0u;  // 06027A66 mov #0,r7
    c.r[3] = 0x0u;  // 06027A68 mov #0,r3
L_06027A6A:
    c.r[1] = ld32(c.r[4]);  // 06027A6A mov.l @r4,r1
    c.r[1] += c.r[7];  // 06027A6C add r7,r1
    c.r[1] += 16;  // 06027A6E add #16,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06027A70 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06027A72 extu.b r1,r1
    c.t = c.r[10] == c.r[1];  // 06027A74 cmp/eq r1,r10
    { const bool k = !c.t; c.r[1] = c.r[8] & 0xFFFFu; if (k) { goto L_06027A94; } }  // 06027A76 bf/s 0x06027A94 ; extu.w r8,r1
    c.r[9] = c.r[1];  // 06027A7A mov r1,r9
    c.r[9] >>= 8;  // 06027A7C shlr8 r9
    c.r[0] = 0x7Fu;  // 06027A7E mov #127,r0
    c.r[9] &= c.r[0];  // 06027A80 and r0,r9
    c.r[0] = c.r[3];  // 06027A82 mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 06027A84 mov.b @(r0,r14),r2
    c.r[11] = (uint32_t)(int16_t)ld16(0x06027ABAu);  // 06027A86 mov.w 0x06027ABA,r11
    c.r[3] += 2;  // 06027A88 add #2,r3
    c.r[6] += 1;  // 06027A8A add #1,r6
    c.r[2] &= c.r[11];  // 06027A8C and r11,r2
    c.r[2] |= c.r[9];  // 06027A8E or r9,r2
    st8(c.r[0] + c.r[14], c.r[2]);  // 06027A90 mov.b r2,@(r0,r14)
    st8(c.r[0] + c.r[5], c.r[1]);  // 06027A92 mov.b r1,@(r0,r5)
L_06027A94:
    c.r[8] += 1;  // 06027A94 add #1,r8
    c.r[1] = 0x7Fu;  // 06027A96 mov #127,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 06027A98 cmp/gt r1,r8
    { const bool k = !c.t; c.r[7] += 30; if (k) { SH2_POLL(c); goto L_06027A6A; } }  // 06027A9A bf/s 0x06027A6A ; add #30,r7
    c.r[1] = 0x3u;  // 06027A9E mov #3,r1
    c.t = (int32_t)c.r[6] > (int32_t)c.r[1];  // 06027AA0 cmp/gt r1,r6
    { const bool k = c.t; c.r[1] = c.r[14]; if (k) { goto L_06027AE0; } }  // 06027AA2 bt/s 0x06027AE0 ; mov r14,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06027AC8u);  // 06027AA6 mov.w 0x06027AC8,r0
    c.r[0] += c.r[14];  // 06027AA8 add r14,r0
    c.r[1] = ld32(0x06027ADCu);  // 06027AAA mov.l 0x06027ADC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06027AB0u; c.r[4] = ld32(c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06027AB0u) return; }  // 06027AAC jsr @r1 ; mov.l @r0,r4
    c.r[0] = (uint32_t)(int16_t)ld16(0x06027ACAu);  // 06027AB0 mov.w 0x06027ACA,r0
    c.r[11] = (uint32_t)(int16_t)ld16(0x06027AC8u);  // 06027AB2 mov.w 0x06027AC8,r11
    c.r[11] += c.r[14];  // 06027AB4 add r14,r11
    st32(c.r[11], c.r[0]); goto L_06027ED4;  // 06027AB6 bra 0x06027ED4 ; mov.l r0,@r11
L_06027AE0:
    c.r[1] += 3;  // 06027AE0 add #3,r1
    c.r[11] = (uint32_t)(int16_t)ld16(0x06027C8Cu);  // 06027AE2 mov.w 0x06027C8C,r11
    c.r[11] += c.r[14];  // 06027AE4 add r14,r11
    c.r[8] = 0x0u;  // 06027AE6 mov #0,r8
    c.r[0] = (uint32_t)(int16_t)ld16(0x06027C8Eu);  // 06027AE8 mov.w 0x06027C8E,r0
    c.r[0] += c.r[14];  // 06027AEA add r14,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06027AEC mov.b @r1,r1
    c.r[9] = 0x2u;  // 06027AEE mov #2,r9
    c.r[12] = c.r[1] & 0xFFu;  // 06027AF0 extu.b r1,r12
    c.r[1] = c.r[14];  // 06027AF2 mov r14,r1
    c.r[1] += 5;  // 06027AF4 add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06027AF6 mov.b @r1,r1
    c.r[10] = ld32(0x06027CA0u);  // 06027AF8 mov.l 0x06027CA0,r10
    c.r[13] = c.r[1] & 0xFFu;  // 06027AFA extu.b r1,r13
    c.r[1] = c.r[14];  // 06027AFC mov r14,r1
    c.r[1] += 7;  // 06027AFE add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06027B00 mov.b @r1,r1
    c.r[4] = 0x0u;  // 06027B02 mov #0,r4
    c.r[1] = c.r[1] & 0xFFu;  // 06027B04 extu.b r1,r1
    st32(c.r[11], c.r[1]);  // 06027B06 mov.l r1,@r11
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06027B08 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06027B0A mov.l r8,@-r15
    c.r[11] = (uint32_t)(int16_t)ld16(0x06027C90u);  // 06027B0C mov.w 0x06027C90,r11
    c.r[0] = ld32(c.r[0]);  // 06027B0E mov.l @r0,r0
    c.r[11] += c.r[14];  // 06027B10 add r14,r11
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 06027B12 mov.l r0,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06027B14 mov.l r9,@-r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x06027C92u);  // 06027B16 mov.w 0x06027C92,r0
    c.r[7] = ld32(c.r[11]);  // 06027B18 mov.l @r11,r7
    c.r[6] = ld32(c.r[0] + c.r[14]);  // 06027B1A mov.l @(r0,r14),r6
    { const uint32_t x = c.r[10]; c.pr = 0x06027B20u; c.r[5] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06027B20u) return; }  // 06027B1C jsr @r10 ; mov r12,r5
    c.r[1] = c.r[0];  // 06027B20 mov r0,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06027B22 extu.b r1,r1
    c.r[11] = (uint32_t)(int16_t)ld16(0x06027C94u);  // 06027B24 mov.w 0x06027C94,r11
    c.r[11] += c.r[14];  // 06027B26 add r14,r11
    st32(c.r[11], c.r[1]);  // 06027B28 mov.l r1,@r11
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06027B2A mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06027B2C mov.l r8,@-r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x06027C8Eu);  // 06027B2E mov.w 0x06027C8E,r0
    c.r[0] += c.r[14];  // 06027B30 add r14,r0
    c.r[11] = (uint32_t)(int16_t)ld16(0x06027C90u);  // 06027B32 mov.w 0x06027C90,r11
    c.r[11] += c.r[14];  // 06027B34 add r14,r11
    c.r[0] = ld32(c.r[0]);  // 06027B36 mov.l @r0,r0
    c.r[5] = c.r[13];  // 06027B38 mov r13,r5
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 06027B3A mov.l r0,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06027B3C mov.l r9,@-r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x06027C92u);  // 06027B3E mov.w 0x06027C92,r0
    c.r[7] = ld32(c.r[11]);  // 06027B40 mov.l @r11,r7
    c.r[6] = ld32(c.r[0] + c.r[14]);  // 06027B42 mov.l @(r0,r14),r6
    { const uint32_t x = c.r[10]; c.pr = 0x06027B48u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06027B48u) return; }  // 06027B44 jsr @r10 ; mov #0,r4
    c.r[1] = c.r[0];  // 06027B48 mov r0,r1
    c.r[12] = c.r[1] & 0xFFu;  // 06027B4A extu.b r1,r12
    c.r[15] += 32;  // 06027B4C add #32,r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06027B4E mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06027B50 mov.l r8,@-r15
    c.r[11] = (uint32_t)(int16_t)ld16(0x06027C8Eu);  // 06027B52 mov.w 0x06027C8E,r11
    c.r[11] += c.r[14];  // 06027B54 add r14,r11
    c.r[0] = (uint32_t)(int16_t)ld16(0x06027C90u);  // 06027B56 mov.w 0x06027C90,r0
    c.r[11] = ld32(c.r[11]);  // 06027B58 mov.l @r11,r11
    c.r[0] += c.r[14];  // 06027B5A add r14,r0
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06027B5C mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06027B5E mov.l r9,@-r15
    c.r[11] = (uint32_t)(int16_t)ld16(0x06027C92u);  // 06027B60 mov.w 0x06027C92,r11
    c.r[7] = ld32(c.r[0]);  // 06027B62 mov.l @r0,r7
    c.r[11] += c.r[14];  // 06027B64 add r14,r11
    c.r[6] = ld32(c.r[11]);  // 06027B66 mov.l @r11,r6
    c.r[0] = (uint32_t)(int16_t)ld16(0x06027C8Cu);  // 06027B68 mov.w 0x06027C8C,r0
    c.r[5] = ld32(c.r[0] + c.r[14]);  // 06027B6A mov.l @(r0,r14),r5
    { const uint32_t x = c.r[10]; c.pr = 0x06027B70u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06027B70u) return; }  // 06027B6C jsr @r10 ; mov #0,r4
    c.r[1] = c.r[0];  // 06027B70 mov r0,r1
    c.r[7] = c.r[1] & 0xFFu;  // 06027B72 extu.b r1,r7
    c.r[4] = ld32(0x06027CA4u);  // 06027B74 mov.l 0x06027CA4,r4
    c.r[11] = (uint32_t)(int16_t)ld16(0x06027C94u);  // 06027B76 mov.w 0x06027C94,r11
    c.r[11] += c.r[14];  // 06027B78 add r14,r11
    c.r[0] = (uint32_t)(int16_t)ld16(0x06027C96u);  // 06027B7A mov.w 0x06027C96,r0
    c.r[0] += c.r[14];  // 06027B7C add r14,r0
    c.r[6] = ld32(c.r[11]);  // 06027B7E mov.l @r11,r6
    c.r[3] = c.r[12];  // 06027B80 mov r12,r3
    c.r[2] = ld32(c.r[4]);  // 06027B82 mov.l @r4,r2
    c.r[6] <<= 2;  // 06027B84 shll2 r6
    c.r[6] <<= 2;  // 06027B86 shll2 r6
    c.r[11] = c.r[6];  // 06027B88 mov r6,r11
    c.r[11] += c.r[2];  // 06027B8A add r2,r11
    st32(c.r[0], c.r[11]);  // 06027B8C mov.l r11,@r0
    c.r[0] = (uint32_t)(int16_t)ld16(0x06027C96u);  // 06027B8E mov.w 0x06027C96,r0
    c.r[0] += c.r[14];  // 06027B90 add r14,r0
    c.r[3] <<= 2;  // 06027B92 shll2 r3
    c.r[3] <<= 2;  // 06027B94 shll2 r3
    c.r[5] = c.r[3];  // 06027B96 mov r3,r5
    c.r[5] += c.r[2];  // 06027B98 add r2,r5
    c.r[5] += 6;  // 06027B9A add #6,r5
    c.r[7] <<= 2;  // 06027B9C shll2 r7
    c.r[7] <<= 2;  // 06027B9E shll2 r7
    c.r[2] += c.r[7];  // 06027BA0 add r7,r2
    c.r[11] = ld32(c.r[0]);  // 06027BA2 mov.l @r0,r11
    c.r[2] += 6;  // 06027BA4 add #6,r2
    c.r[11] += 6;  // 06027BA6 add #6,r11
    st32(c.r[0], c.r[11]);  // 06027BA8 mov.l r11,@r0
    c.r[0] = (uint32_t)(int16_t)ld16(0x06027C98u);  // 06027BAA mov.w 0x06027C98,r0
    c.r[0] += c.r[14];  // 06027BAC add r14,r0
    c.r[11] = (uint32_t)(int16_t)ld16(0x06027C96u);  // 06027BAE mov.w 0x06027C96,r11
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06027BB0 mov.b @r0,r1
    c.r[11] += c.r[14];  // 06027BB2 add r14,r11
    st8(c.r[2], c.r[1]);  // 06027BB4 mov.b r1,@r2
    st8(c.r[5], c.r[1]);  // 06027BB6 mov.b r1,@r5
    c.r[5] = c.r[6];  // 06027BB8 mov r6,r5
    c.r[0] = ld32(c.r[11]);  // 06027BBA mov.l @r11,r0
    c.r[2] = c.r[3];  // 06027BBC mov r3,r2
    st8(c.r[0], c.r[1]);  // 06027BBE mov.b r1,@r0
    c.r[1] = ld32(c.r[4]);  // 06027BC0 mov.l @r4,r1
    c.r[11] = 0x20u;  // 06027BC2 mov #32,r11
    c.r[5] += c.r[1];  // 06027BC4 add r1,r5
    c.r[2] += c.r[1];  // 06027BC6 add r1,r2
    c.r[1] += c.r[7];  // 06027BC8 add r7,r1
    c.r[1] += 4;  // 06027BCA add #4,r1
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06027BCC mov.b @r1,r8
    c.r[2] += 4;  // 06027BCE add #4,r2
    c.r[8] |= c.r[11];  // 06027BD0 or r11,r8
    st8(c.r[1], c.r[8]);  // 06027BD2 mov.b r8,@r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06027BD4 mov.b @r2,r1
    c.r[5] += 4;  // 06027BD6 add #4,r5
    c.r[1] |= c.r[11];  // 06027BD8 or r11,r1
    st8(c.r[2], c.r[1]);  // 06027BDA mov.b r1,@r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[5]);  // 06027BDC mov.b @r5,r1
    c.r[1] |= c.r[11];  // 06027BDE or r11,r1
    st8(c.r[5], c.r[1]);  // 06027BE0 mov.b r1,@r5
    c.r[1] = ld32(c.r[4]);  // 06027BE2 mov.l @r4,r1
    c.r[0] = 0x7Fu;  // 06027BE4 mov #127,r0
    c.r[6] += c.r[1];  // 06027BE6 add r1,r6
    c.r[3] += c.r[1];  // 06027BE8 add r1,r3
    c.r[7] += c.r[1];  // 06027BEA add r1,r7
    c.r[7] += 3;  // 06027BEC add #3,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06027BEE mov.b @r7,r1
    c.r[3] += 3;  // 06027BF0 add #3,r3
    c.r[1] &= c.r[0];  // 06027BF2 and r0,r1
    st8(c.r[7], c.r[1]);  // 06027BF4 mov.b r1,@r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06027BF6 mov.b @r3,r1
    c.r[6] += 3;  // 06027BF8 add #3,r6
    c.r[1] &= c.r[0];  // 06027BFA and r0,r1
    st8(c.r[3], c.r[1]);  // 06027BFC mov.b r1,@r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 06027BFE mov.b @r6,r1
    c.r[15] += 16;  // 06027C00 add #16,r15
    c.r[1] &= c.r[0];  // 06027C02 and r0,r1
    st8(c.r[6], c.r[1]); goto L_06027ED4;  // 06027C04 bra 0x06027ED4 ; mov.b r1,@r6
L_06027C08:
    c.r[8] = 0x0u;  // 06027C08 mov #0,r8
    c.r[6] = 0x0u;  // 06027C0A mov #0,r6
    c.r[4] = ld32(0x06027CA8u);  // 06027C0C mov.l 0x06027CA8,r4
    c.r[5] = c.r[14];  // 06027C0E mov r14,r5
    c.r[5] += 1;  // 06027C10 add #1,r5
    c.r[7] = 0x0u;  // 06027C12 mov #0,r7
    c.r[3] = 0x0u;  // 06027C14 mov #0,r3
L_06027C16:
    c.r[1] = ld32(c.r[4]);  // 06027C16 mov.l @r4,r1
    c.r[1] += c.r[7];  // 06027C18 add r7,r1
    c.r[1] += 16;  // 06027C1A add #16,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06027C1C mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06027C1E extu.b r1,r1
    c.t = c.r[10] == c.r[1];  // 06027C20 cmp/eq r1,r10
    { const bool k = !c.t; c.r[1] = c.r[8] & 0xFFFFu; if (k) { goto L_06027C40; } }  // 06027C22 bf/s 0x06027C40 ; extu.w r8,r1
    c.r[9] = c.r[1];  // 06027C26 mov r1,r9
    c.r[9] >>= 8;  // 06027C28 shlr8 r9
    c.r[11] = 0x7Fu;  // 06027C2A mov #127,r11
    c.r[9] &= c.r[11];  // 06027C2C and r11,r9
    c.r[0] = c.r[3];  // 06027C2E mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 06027C30 mov.b @(r0,r14),r2
    c.r[11] = (uint32_t)(int16_t)ld16(0x06027C9Au);  // 06027C32 mov.w 0x06027C9A,r11
    c.r[3] += 2;  // 06027C34 add #2,r3
    c.r[6] += 1;  // 06027C36 add #1,r6
    c.r[2] &= c.r[11];  // 06027C38 and r11,r2
    c.r[2] |= c.r[9];  // 06027C3A or r9,r2
    st8(c.r[0] + c.r[14], c.r[2]);  // 06027C3C mov.b r2,@(r0,r14)
    st8(c.r[0] + c.r[5], c.r[1]);  // 06027C3E mov.b r1,@(r0,r5)
L_06027C40:
    c.r[8] += 1;  // 06027C40 add #1,r8
    c.r[1] = 0x7Fu;  // 06027C42 mov #127,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 06027C44 cmp/gt r1,r8
    { const bool k = !c.t; c.r[7] += 30; if (k) { SH2_POLL(c); goto L_06027C16; } }  // 06027C46 bf/s 0x06027C16 ; add #30,r7
    c.r[1] = c.r[14];  // 06027C4A mov r14,r1
    c.r[1] += 3;  // 06027C4C add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06027C4E mov.b @r1,r1
    c.r[5] = c.r[1] & 0xFFu;  // 06027C50 extu.b r1,r5
    c.r[1] = c.r[14];  // 06027C52 mov r14,r1
    c.r[1] += 5;  // 06027C54 add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06027C56 mov.b @r1,r1
    c.r[12] = c.r[1] & 0xFFu;  // 06027C58 extu.b r1,r12
    c.r[1] = c.r[14];  // 06027C5A mov r14,r1
    c.r[1] += 7;  // 06027C5C add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06027C5E mov.b @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06027C8Cu);  // 06027C60 mov.w 0x06027C8C,r0
    c.r[13] = c.r[1] & 0xFFu;  // 06027C62 extu.b r1,r13
    c.r[1] = c.r[14];  // 06027C64 mov r14,r1
    c.r[1] += 9;  // 06027C66 add #9,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06027C68 mov.b @r1,r1
    c.r[0] += c.r[14];  // 06027C6A add r14,r0
    c.r[1] = c.r[1] & 0xFFu;  // 06027C6C extu.b r1,r1
    st32(c.r[0], c.r[1]);  // 06027C6E mov.l r1,@r0
    c.r[1] = 0x4u;  // 06027C70 mov #4,r1
    c.t = (int32_t)c.r[6] > (int32_t)c.r[1];  // 06027C72 cmp/gt r1,r6
    { const bool k = c.t; c.r[8] = 0x0u; if (k) { goto L_06027CB0; } }  // 06027C74 bt/s 0x06027CB0 ; mov #0,r8
    c.r[11] = (uint32_t)(int16_t)ld16(0x06027C9Cu);  // 06027C78 mov.w 0x06027C9C,r11
    c.r[11] += c.r[14];  // 06027C7A add r14,r11
    c.r[1] = ld32(0x06027CACu);  // 06027C7C mov.l 0x06027CAC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06027C82u; c.r[4] = ld32(c.r[11]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06027C82u) return; }  // 06027C7E jsr @r1 ; mov.l @r11,r4
    c.r[11] = (uint32_t)(int16_t)ld16(0x06027C9Eu);  // 06027C82 mov.w 0x06027C9E,r11
    c.r[0] = (uint32_t)(int16_t)ld16(0x06027C9Cu);  // 06027C84 mov.w 0x06027C9C,r0
    c.r[0] += c.r[14];  // 06027C86 add r14,r0
    st32(c.r[0], c.r[11]); goto L_06027ED4;  // 06027C88 bra 0x06027ED4 ; mov.l r11,@r0
L_06027CB0:
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06027CB0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06027CB2 mov.l r8,@-r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x06027E58u);  // 06027CB4 mov.w 0x06027E58,r0
    c.r[0] += c.r[14];  // 06027CB6 add r14,r0
    c.r[10] = 0x2u;  // 06027CB8 mov #2,r10
    c.r[11] = (uint32_t)(int16_t)ld16(0x06027E5Au);  // 06027CBA mov.w 0x06027E5A,r11
    c.r[11] += c.r[14];  // 06027CBC add r14,r11
    c.r[0] = ld32(c.r[0]);  // 06027CBE mov.l @r0,r0
    c.r[4] = 0x0u;  // 06027CC0 mov #0,r4
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 06027CC2 mov.l r0,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06027CC4 mov.l r10,@-r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x06027E5Cu);  // 06027CC6 mov.w 0x06027E5C,r0
    c.r[7] = ld32(c.r[11]);  // 06027CC8 mov.l @r11,r7
    c.r[0] += c.r[14];  // 06027CCA add r14,r0
    c.r[11] = ld32(0x06027E6Cu);  // 06027CCC mov.l 0x06027E6C,r11
    { const uint32_t x = c.r[11]; c.pr = 0x06027CD2u; c.r[6] = ld32(c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06027CD2u) return; }  // 06027CCE jsr @r11 ; mov.l @r0,r6
    c.r[1] = c.r[0];  // 06027CD2 mov r0,r1
    c.r[9] = c.r[1] & 0xFFu;  // 06027CD4 extu.b r1,r9
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06027CD6 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06027CD8 mov.l r8,@-r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x06027E58u);  // 06027CDA mov.w 0x06027E58,r0
    c.r[0] += c.r[14];  // 06027CDC add r14,r0
    c.r[11] = (uint32_t)(int16_t)ld16(0x06027E5Au);  // 06027CDE mov.w 0x06027E5A,r11
    c.r[11] += c.r[14];  // 06027CE0 add r14,r11
    c.r[5] = c.r[12];  // 06027CE2 mov r12,r5
    c.r[0] = ld32(c.r[0]);  // 06027CE4 mov.l @r0,r0
    c.r[4] = 0x0u;  // 06027CE6 mov #0,r4
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 06027CE8 mov.l r0,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06027CEA mov.l r10,@-r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x06027E5Cu);  // 06027CEC mov.w 0x06027E5C,r0
    c.r[7] = ld32(c.r[11]);  // 06027CEE mov.l @r11,r7
    c.r[0] += c.r[14];  // 06027CF0 add r14,r0
    c.r[11] = ld32(0x06027E6Cu);  // 06027CF2 mov.l 0x06027E6C,r11
    { const uint32_t x = c.r[11]; c.pr = 0x06027CF8u; c.r[6] = ld32(c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06027CF8u) return; }  // 06027CF4 jsr @r11 ; mov.l @r0,r6
    c.r[1] = c.r[0];  // 06027CF8 mov r0,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06027CFA extu.b r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06027E5Eu);  // 06027CFC mov.w 0x06027E5E,r0
    st32(c.r[0] + c.r[14], c.r[1]);  // 06027CFE mov.l r1,@(r0,r14)
    c.r[15] += 32;  // 06027D00 add #32,r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06027D02 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06027D04 mov.l r8,@-r15
    c.r[11] = (uint32_t)(int16_t)ld16(0x06027E58u);  // 06027D06 mov.w 0x06027E58,r11
    c.r[11] += c.r[14];  // 06027D08 add r14,r11
    c.r[0] = (uint32_t)(int16_t)ld16(0x06027E5Au);  // 06027D0A mov.w 0x06027E5A,r0
    c.r[0] += c.r[14];  // 06027D0C add r14,r0
    c.r[5] = c.r[13];  // 06027D0E mov r13,r5
    c.r[11] = ld32(c.r[11]);  // 06027D10 mov.l @r11,r11
    c.r[4] = 0x0u;  // 06027D12 mov #0,r4
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06027D14 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06027D16 mov.l r10,@-r15
    c.r[11] = (uint32_t)(int16_t)ld16(0x06027E5Cu);  // 06027D18 mov.w 0x06027E5C,r11
    c.r[7] = ld32(c.r[0]);  // 06027D1A mov.l @r0,r7
    c.r[11] += c.r[14];  // 06027D1C add r14,r11
    c.r[0] = ld32(0x06027E6Cu);  // 06027D1E mov.l 0x06027E6C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06027D24u; c.r[6] = ld32(c.r[11]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06027D24u) return; }  // 06027D20 jsr @r0 ; mov.l @r11,r6
    c.r[1] = c.r[0];  // 06027D24 mov r0,r1
    c.r[12] = c.r[1] & 0xFFu;  // 06027D26 extu.b r1,r12
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06027D28 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06027D2A mov.l r8,@-r15
    c.r[11] = (uint32_t)(int16_t)ld16(0x06027E58u);  // 06027D2C mov.w 0x06027E58,r11
    c.r[11] += c.r[14];  // 06027D2E add r14,r11
    c.r[0] = (uint32_t)(int16_t)ld16(0x06027E5Au);  // 06027D30 mov.w 0x06027E5A,r0
    c.r[0] += c.r[14];  // 06027D32 add r14,r0
    c.r[11] = ld32(c.r[11]);  // 06027D34 mov.l @r11,r11
    c.r[4] = 0x0u;  // 06027D36 mov #0,r4
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06027D38 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06027D3A mov.l r10,@-r15
    c.r[11] = (uint32_t)(int16_t)ld16(0x06027E5Cu);  // 06027D3C mov.w 0x06027E5C,r11
    c.r[7] = ld32(c.r[0]);  // 06027D3E mov.l @r0,r7
    c.r[11] += c.r[14];  // 06027D40 add r14,r11
    c.r[6] = ld32(c.r[11]);  // 06027D42 mov.l @r11,r6
    c.r[0] = (uint32_t)(int16_t)ld16(0x06027E60u);  // 06027D44 mov.w 0x06027E60,r0
    c.r[0] += c.r[14];  // 06027D46 add r14,r0
    c.r[11] = ld32(0x06027E6Cu);  // 06027D48 mov.l 0x06027E6C,r11
    { const uint32_t x = c.r[11]; c.pr = 0x06027D4Eu; c.r[5] = ld32(c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06027D4Eu) return; }  // 06027D4A jsr @r11 ; mov.l @r0,r5
    c.r[1] = c.r[0];  // 06027D4E mov r0,r1
    c.r[7] = c.r[1] & 0xFFu;  // 06027D50 extu.b r1,r7
    c.r[4] = ld32(0x06027E70u);  // 06027D52 mov.l 0x06027E70,r4
    c.r[9] <<= 2;  // 06027D54 shll2 r9
    c.r[9] <<= 2;  // 06027D56 shll2 r9
    c.r[8] = c.r[9];  // 06027D58 mov r9,r8
    c.r[0] = (uint32_t)(int16_t)ld16(0x06027E5Eu);  // 06027D5A mov.w 0x06027E5E,r0
    c.r[0] += c.r[14];  // 06027D5C add r14,r0
    c.r[11] = (uint32_t)(int16_t)ld16(0x06027E62u);  // 06027D5E mov.w 0x06027E62,r11
    c.r[11] += c.r[14];  // 06027D60 add r14,r11
    c.r[2] = ld32(c.r[4]);  // 06027D62 mov.l @r4,r2
    c.r[3] = c.r[12];  // 06027D64 mov r12,r3
    c.r[5] = ld32(c.r[0]);  // 06027D66 mov.l @r0,r5
    c.r[8] += c.r[2];  // 06027D68 add r2,r8
    c.r[8] += 6;  // 06027D6A add #6,r8
    c.r[5] <<= 2;  // 06027D6C shll2 r5
    c.r[5] <<= 2;  // 06027D6E shll2 r5
    c.r[0] = c.r[5];  // 06027D70 mov r5,r0
    c.r[0] += c.r[2];  // 06027D72 add r2,r0
    st32(c.r[11], c.r[0]);  // 06027D74 mov.l r0,@r11
    c.r[11] = (uint32_t)(int16_t)ld16(0x06027E62u);  // 06027D76 mov.w 0x06027E62,r11
    c.r[11] += c.r[14];  // 06027D78 add r14,r11
    c.r[3] <<= 2;  // 06027D7A shll2 r3
    c.r[3] <<= 2;  // 06027D7C shll2 r3
    c.r[6] = c.r[3];  // 06027D7E mov r3,r6
    c.r[6] += c.r[2];  // 06027D80 add r2,r6
    c.r[6] += 6;  // 06027D82 add #6,r6
    c.r[7] <<= 2;  // 06027D84 shll2 r7
    c.r[7] <<= 2;  // 06027D86 shll2 r7
    c.r[2] += c.r[7];  // 06027D88 add r7,r2
    c.r[0] = ld32(c.r[11]);  // 06027D8A mov.l @r11,r0
    c.r[2] += 6;  // 06027D8C add #6,r2
    c.r[0] += 6;  // 06027D8E add #6,r0
    st32(c.r[11], c.r[0]);  // 06027D90 mov.l r0,@r11
    c.r[11] = (uint32_t)(int16_t)ld16(0x06027E64u);  // 06027D92 mov.w 0x06027E64,r11
    c.r[11] += c.r[14];  // 06027D94 add r14,r11
    c.r[0] = (uint32_t)(int16_t)ld16(0x06027E62u);  // 06027D96 mov.w 0x06027E62,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[11]);  // 06027D98 mov.b @r11,r1
    c.r[0] += c.r[14];  // 06027D9A add r14,r0
    st8(c.r[2], c.r[1]);  // 06027D9C mov.b r1,@r2
    st8(c.r[6], c.r[1]);  // 06027D9E mov.b r1,@r6
    c.r[6] = c.r[5];  // 06027DA0 mov r5,r6
    c.r[11] = ld32(c.r[0]);  // 06027DA2 mov.l @r0,r11
    c.r[2] = c.r[3];  // 06027DA4 mov r3,r2
    st8(c.r[11], c.r[1]);  // 06027DA6 mov.b r1,@r11
    st8(c.r[8], c.r[1]);  // 06027DA8 mov.b r1,@r8
    c.r[11] = c.r[9];  // 06027DAA mov r9,r11
    c.r[0] = (uint32_t)(int16_t)ld16(0x06027E62u);  // 06027DAC mov.w 0x06027E62,r0
    c.r[1] = ld32(c.r[4]);  // 06027DAE mov.l @r4,r1
    c.r[0] += c.r[14];  // 06027DB0 add r14,r0
    c.r[11] += c.r[1];  // 06027DB2 add r1,r11
    st32(c.r[0], c.r[11]);  // 06027DB4 mov.l r11,@r0
    c.r[6] += c.r[1];  // 06027DB6 add r1,r6
    c.r[2] += c.r[1];  // 06027DB8 add r1,r2
    c.r[1] += c.r[7];  // 06027DBA add r7,r1
    c.r[1] += 4;  // 06027DBC add #4,r1
    c.r[0] = 0x20u;  // 06027DBE mov #32,r0
    c.r[2] += 4;  // 06027DC0 add #4,r2
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06027DC2 mov.b @r1,r8
    c.r[6] += 4;  // 06027DC4 add #4,r6
    c.r[8] |= c.r[0];  // 06027DC6 or r0,r8
    st8(c.r[1], c.r[8]);  // 06027DC8 mov.b r8,@r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06027DCA mov.b @r2,r1
    c.r[11] = (uint32_t)(int16_t)ld16(0x06027E62u);  // 06027DCC mov.w 0x06027E62,r11
    c.r[1] |= c.r[0];  // 06027DCE or r0,r1
    st8(c.r[2], c.r[1]);  // 06027DD0 mov.b r1,@r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 06027DD2 mov.b @r6,r1
    c.r[11] += c.r[14];  // 06027DD4 add r14,r11
    c.r[1] |= c.r[0];  // 06027DD6 or r0,r1
    st8(c.r[6], c.r[1]);  // 06027DD8 mov.b r1,@r6
    c.r[0] = ld32(c.r[11]);  // 06027DDA mov.l @r11,r0
    c.r[0] += 4;  // 06027DDC add #4,r0
    st32(c.r[11], c.r[0]);  // 06027DDE mov.l r0,@r11
    c.r[11] = (uint32_t)(int16_t)ld16(0x06027E62u);  // 06027DE0 mov.w 0x06027E62,r11
    c.r[11] += c.r[14];  // 06027DE2 add r14,r11
    c.r[0] = ld32(c.r[11]);  // 06027DE4 mov.l @r11,r0
    c.r[15] += 32;  // 06027DE6 add #32,r15
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06027DE8 mov.b @r0,r1
    c.r[11] = 0x20u;  // 06027DEA mov #32,r11
    c.r[1] |= c.r[11];  // 06027DEC or r11,r1
    c.r[11] = (uint32_t)(int16_t)ld16(0x06027E62u);  // 06027DEE mov.w 0x06027E62,r11
    st8(c.r[0], c.r[1]);  // 06027DF0 mov.b r1,@r0
    c.r[1] = ld32(c.r[4]);  // 06027DF2 mov.l @r4,r1
    c.r[0] = 0x7Fu;  // 06027DF4 mov #127,r0
    c.r[9] += c.r[1];  // 06027DF6 add r1,r9
    c.r[5] += c.r[1];  // 06027DF8 add r1,r5
    c.r[3] += c.r[1];  // 06027DFA add r1,r3
    c.r[7] += c.r[1];  // 06027DFC add r1,r7
    c.r[7] += 3;  // 06027DFE add #3,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06027E00 mov.b @r7,r1
    c.r[3] += 3;  // 06027E02 add #3,r3
    c.r[1] &= c.r[0];  // 06027E04 and r0,r1
    st8(c.r[7], c.r[1]);  // 06027E06 mov.b r1,@r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06027E08 mov.b @r3,r1
    c.r[5] += 3;  // 06027E0A add #3,r5
    c.r[1] &= c.r[0];  // 06027E0C and r0,r1
    st8(c.r[3], c.r[1]);  // 06027E0E mov.b r1,@r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[5]);  // 06027E10 mov.b @r5,r1
    c.r[9] += 3;  // 06027E12 add #3,r9
    c.r[1] &= c.r[0];  // 06027E14 and r0,r1
    st8(c.r[5], c.r[1]);  // 06027E16 mov.b r1,@r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06027E18 mov.b @r9,r1
    c.r[11] += c.r[14];  // 06027E1A add r14,r11
    c.r[1] &= c.r[0];  // 06027E1C and r0,r1
    st8(c.r[9], c.r[1]); goto L_06027ED4;  // 06027E1E bra 0x06027ED4 ; mov.b r1,@r9
L_06027E22:
    c.r[0] = c.r[9];  // 06027E22 mov r9,r0
    c.t = c.r[0] == 0x2u;  // 06027E24 cmp/eq #2,r0
    if (!c.t) { goto L_06027ED4; }  // 06027E26 bf 0x06027ED4
    c.r[8] = ld32(0x06027E74u);  // 06027E28 mov.l 0x06027E74,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06027E2Eu; c.r[4] = 0x3u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06027E2Eu) return; }  // 06027E2A jsr @r8 ; mov #3,r4
    c.r[1] = c.r[0];  // 06027E2E mov r0,r1
    c.r[12] = c.r[1] & 0xFFu;  // 06027E30 extu.b r1,r12
    { const uint32_t x = c.r[8]; c.pr = 0x06027E36u; c.r[4] = 0x4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06027E36u) return; }  // 06027E32 jsr @r8 ; mov #4,r4
    c.r[1] = c.r[0];  // 06027E36 mov r0,r1
    c.r[8] = (uint32_t)(int16_t)ld16(0x06027E66u);  // 06027E38 mov.w 0x06027E66,r8
    c.t = c.r[12] == c.r[8];  // 06027E3A cmp/eq r8,r12
    { const bool k = c.t; c.r[13] = c.r[1] & 0xFFu; if (k) { goto L_06027E46; } }  // 06027E3C bt/s 0x06027E46 ; extu.b r1,r13
    c.t = c.r[13] == c.r[8];  // 06027E40 cmp/eq r8,r13
    { const bool k = !c.t; c.r[1] = 0x0u; if (k) { goto L_06027E7C; } }  // 06027E42 bf/s 0x06027E7C ; mov #0,r1
L_06027E46:
    c.r[11] = (uint32_t)(int16_t)ld16(0x06027E68u);  // 06027E46 mov.w 0x06027E68,r11
    c.r[11] += c.r[14];  // 06027E48 add r14,r11
    c.r[1] = ld32(0x06027E78u);  // 06027E4A mov.l 0x06027E78,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06027E50u; c.r[4] = ld32(c.r[11]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06027E50u) return; }  // 06027E4C jsr @r1 ; mov.l @r11,r4
    c.r[0] = (uint32_t)(int16_t)ld16(0x06027E68u);  // 06027E50 mov.w 0x06027E68,r0
    c.r[0] += c.r[14];  // 06027E52 add r14,r0
    st32(c.r[0], c.r[8]); goto L_06027ED4;  // 06027E54 bra 0x06027ED4 ; mov.l r8,@r0
L_06027E7C:
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06027E7C mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06027E7E mov.l r1,@-r15
    c.r[11] = (uint32_t)(int16_t)ld16(0x06027F44u);  // 06027E80 mov.w 0x06027F44,r11
    c.r[11] += c.r[14];  // 06027E82 add r14,r11
    c.r[0] = (uint32_t)(int16_t)ld16(0x06027F46u);  // 06027E84 mov.w 0x06027F46,r0
    c.r[0] += c.r[14];  // 06027E86 add r14,r0
    c.r[5] = c.r[13];  // 06027E88 mov r13,r5
    c.r[11] = ld32(c.r[11]);  // 06027E8A mov.l @r11,r11
    c.r[4] = 0x0u;  // 06027E8C mov #0,r4
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06027E8E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06027E90 mov.l r9,@-r15
    c.r[11] = (uint32_t)(int16_t)ld16(0x06027F48u);  // 06027E92 mov.w 0x06027F48,r11
    c.r[7] = ld32(c.r[0]);  // 06027E94 mov.l @r0,r7
    c.r[11] += c.r[14];  // 06027E96 add r14,r11
    c.r[0] = ld32(0x06027F54u);  // 06027E98 mov.l 0x06027F54,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06027E9Eu; c.r[6] = ld32(c.r[11]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06027E9Eu) return; }  // 06027E9A jsr @r0 ; mov.l @r11,r6
    c.r[1] = c.r[0];  // 06027E9E mov r0,r1
    c.r[3] = c.r[1] & 0xFFu;  // 06027EA0 extu.b r1,r3
    c.r[1] = ld32(0x06027F58u);  // 06027EA2 mov.l 0x06027F58,r1
    c.r[3] <<= 2;  // 06027EA4 shll2 r3
    c.r[3] <<= 2;  // 06027EA6 shll2 r3
    c.r[11] = (uint32_t)(int16_t)ld16(0x06027F4Au);  // 06027EA8 mov.w 0x06027F4A,r11
    c.r[2] = ld32(c.r[1]);  // 06027EAA mov.l @r1,r2
    c.r[11] += c.r[14];  // 06027EAC add r14,r11
    c.r[2] += c.r[3];  // 06027EAE add r3,r2
    c.r[2] += 6;  // 06027EB0 add #6,r2
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[11]);  // 06027EB2 mov.b @r11,r11
    st8(c.r[2], c.r[11]);  // 06027EB4 mov.b r11,@r2
    c.r[2] = ld32(c.r[1]);  // 06027EB6 mov.l @r1,r2
    c.r[2] += c.r[3];  // 06027EB8 add r3,r2
    c.r[2] += 4;  // 06027EBA add #4,r2
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06027EBC mov.b @r2,r7
    c.r[0] = 0x20u;  // 06027EBE mov #32,r0
    c.r[7] |= c.r[0];  // 06027EC0 or r0,r7
    st8(c.r[2], c.r[7]);  // 06027EC2 mov.b r7,@r2
    c.r[1] = ld32(c.r[1]);  // 06027EC4 mov.l @r1,r1
    c.r[15] += 16;  // 06027EC6 add #16,r15
    c.r[1] += c.r[3];  // 06027EC8 add r3,r1
    c.r[1] += 3;  // 06027ECA add #3,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06027ECC mov.b @r1,r2
    c.r[11] = 0x7Fu;  // 06027ECE mov #127,r11
    c.r[2] &= c.r[11];  // 06027ED0 and r11,r2
    st8(c.r[1], c.r[2]);  // 06027ED2 mov.b r2,@r1
L_06027ED4:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06027F4Cu);  // 06027ED4 mov.w 0x06027F4C,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06027F4Cu);  // 06027ED6 mov.w 0x06027F4C,r0
    c.t = c.r[0] == c.r[1];  // 06027ED8 cmp/eq r1,r0
    { const bool k = c.t; c.r[8] = 0x0u; if (k) { goto L_06027F28; } }  // 06027EDA bt/s 0x06027F28 ; mov #0,r8
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[0];  // 06027EDE cmp/ge r0,r8
    if (c.t) { goto L_06027F28; }  // 06027EE0 bt 0x06027F28
    c.r[13] = ld32(0x06027F5Cu);  // 06027EE2 mov.l 0x06027F5C,r13
    c.r[9] = ld32(0x06027F60u);  // 06027EE4 mov.l 0x06027F60,r9
    c.r[10] = ld32(0x06027F64u);  // 06027EE6 mov.l 0x06027F64,r10
L_06027EE8:
    c.r[5] = (uint32_t)(int16_t)ld16(0x06027F4Cu);  // 06027EE8 mov.w 0x06027F4C,r5
    c.r[5] += 1;  // 06027EEA add #1,r5
    c.r[6] = c.r[14];  // 06027EEC mov r14,r6
    c.r[11] = (uint32_t)(int16_t)ld16(0x06027F4Eu);  // 06027EEE mov.w 0x06027F4E,r11
    c.r[11] += c.r[14];  // 06027EF0 add r14,r11
    c.r[4] = ld32(c.r[11]);  // 06027EF2 mov.l @r11,r4
    { const uint32_t x = c.r[13]; c.pr = 0x06027EF8u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06027EF8u) return; }  // 06027EF4 jsr @r13 ; extu.b r5,r5
    c.r[8] += 1;  // 06027EF8 add #1,r8
    c.r[2] = c.r[8];  // 06027EFA mov r8,r2
    c.r[2] += c.r[2];  // 06027EFC add r2,r2
    c.r[1] = c.r[14];  // 06027EFE mov r14,r1
    c.r[1] += 1;  // 06027F00 add #1,r1
    c.r[0] = c.r[1];  // 06027F02 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06027F04 mov.b @(r0,r2),r1
    c.r[11] = (uint32_t)(int16_t)ld16(0x06027F50u);  // 06027F06 mov.w 0x06027F50,r11
    c.r[4] = ld32(c.r[9]);  // 06027F08 mov.l @r9,r4
    c.r[11] += c.r[14];  // 06027F0A add r14,r11
    c.r[6] = ld32(c.r[11]);  // 06027F0C mov.l @r11,r6
    c.r[12] = c.r[1] & 0xFFu;  // 06027F0E extu.b r1,r12
    { const uint32_t x = c.r[10]; c.pr = 0x06027F14u; c.r[5] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06027F14u) return; }  // 06027F10 jsr @r10 ; mov r12,r5
    c.r[1] = ld32(c.r[9]);  // 06027F14 mov.l @r9,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06027F50u);  // 06027F16 mov.w 0x06027F50,r0
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06027F18 mov.w @r1,r5
    c.r[4] = ld32(c.r[0] + c.r[14]);  // 06027F1A mov.l @(r0,r14),r4
    c.r[1] = ld32(0x06027F68u);  // 06027F1C mov.l 0x06027F68,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06027F22u; c.r[5] = c.r[5] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06027F22u) return; }  // 06027F1E jsr @r1 ; extu.w r5,r5
    c.r[11] = (uint32_t)(int16_t)ld16(0x06027F4Cu);  // 06027F22 mov.w 0x06027F4C,r11
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[11];  // 06027F24 cmp/ge r11,r8
    if (!c.t) { SH2_POLL(c); goto L_06027EE8; }  // 06027F26 bf 0x06027EE8
L_06027F28:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06027F50u);  // 06027F28 mov.w 0x06027F50,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06027F2A mov.l @(r0,r14),r0
    c.r[3] = (uint32_t)(int16_t)ld16(0x06027F52u);  // 06027F2C mov.w 0x06027F52,r3
    c.r[14] += c.r[3];  // 06027F2E add r3,r14
    c.r[15] = c.r[14];  // 06027F30 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06027F32 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06027F34 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06027F36 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06027F38 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06027F3A mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06027F3C mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06027F3E mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06027F40 rts ; mov.l @r15+,r8
}

void f_06027F6C(SH2Context& c) {
    ran[537] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06027F6C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06027F6E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06027F70 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06027F72 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06027F74 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06027F76 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06027F78 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06027F7A mov r15,r14
    c.r[4] = c.r[4] & 0xFFFFu;  // 06027F7C extu.w r4,r4
    c.r[9] = c.r[5] & 0xFFFFu;  // 06027F7E extu.w r5,r9
    c.r[8] = (uint32_t)(int16_t)ld16(0x06028050u);  // 06027F80 mov.w 0x06028050,r8
    c.r[0] = ld32(0x06028054u);  // 06027F82 mov.l 0x06028054,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06027F88u; c.r[11] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06027F88u) return; }  // 06027F84 jsr @r0 ; mov r9,r11
    c.r[10] = c.r[0] & 0xFFu;  // 06027F88 extu.b r0,r10
    c.t = c.r[10] == c.r[8];  // 06027F8A cmp/eq r8,r10
    { const bool k = c.t; c.t = (c.r[9] & c.r[9]) == 0; if (k) { goto L_0602803C; } }  // 06027F8C bt/s 0x0602803C ; tst r9,r9
    c.r[1] = ld32(0x06028058u);  // 06027F90 mov.l 0x06028058,r1
    c.r[2] = ld32(c.r[1]);  // 06027F92 mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 06027F94 mov #30,r1
    c.macl = c.r[10] * c.r[1];  // 06027F96 mul.l r1,r10
    c.r[1] = c.macl;  // 06027F98 sts macl,r1
    c.r[1] += c.r[2];  // 06027F9A add r2,r1
    c.r[1] += 15;  // 06027F9C add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06027F9E mov.b @r1,r1
    { const bool k = !c.t; c.r[12] = c.r[1] & 0xFFu; if (k) { goto L_06027FAE; } }  // 06027FA0 bf/s 0x06027FAE ; extu.b r1,r12
    c.r[1] = ld32(0x0602805Cu);  // 06027FA4 mov.l 0x0602805C,r1
    c.r[1] = ld32(c.r[1]);  // 06027FA6 mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06028052u);  // 06027FA8 mov.w 0x06028052,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]); goto L_06027FD2;  // 06027FAA bra 0x06027FD2 ; mov.b @(r0,r1),r1
L_06027FAE:
    c.r[0] = ld32(0x06028060u);  // 06027FAE mov.l 0x06028060,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06027FB4u; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06027FB4u) return; }  // 06027FB0 jsr @r0 ; mov r11,r4
    c.r[4] = c.r[0] & 0xFFu;  // 06027FB4 extu.b r0,r4
    c.t = c.r[4] == c.r[8];  // 06027FB6 cmp/eq r8,r4
    if (c.t) { goto L_06027FD0; }  // 06027FB8 bt 0x06027FD0
    c.r[0] = ld32(0x06028064u);  // 06027FBA mov.l 0x06028064,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06027FC0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06027FC0u) return; }  // 06027FBC jsr @r0 ; nop
    c.r[4] = c.r[0] & 0xFFu;  // 06027FC0 extu.b r0,r4
    c.r[0] = ld32(0x06028068u);  // 06027FC2 mov.l 0x06028068,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06027FC8u; c.r[5] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06027FC8u) return; }  // 06027FC4 jsr @r0 ; mov #1,r5
    c.r[0] = c.r[0] & 0xFFu;  // 06027FC8 extu.b r0,r0
    c.t = c.r[0] == c.r[8];  // 06027FCA cmp/eq r8,r0
    { const bool k = !c.t; c.r[1] = c.r[0]; if (k) { goto L_06027FD2; } }  // 06027FCC bf/s 0x06027FD2 ; mov r0,r1
L_06027FD0:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06028050u);  // 06027FD0 mov.w 0x06028050,r1
L_06027FD2:
    c.r[9] = c.r[1] & 0xFFu;  // 06027FD2 extu.b r1,r9
    c.r[1] = 0x1u;  // 06027FD4 mov #1,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06027FD6 mov.l r1,@-r15
    c.r[1] = 0x0u;  // 06027FD8 mov #0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06027FDA mov.l r1,@-r15
    c.r[1] = ld32(0x0602806Cu);  // 06027FDC mov.l 0x0602806C,r1
    c.r[2] = c.r[12];  // 06027FDE mov r12,r2
    c.r[2] += c.r[2];  // 06027FE0 add r2,r2
    c.r[2] += c.r[12];  // 06027FE2 add r12,r2
    c.r[2] <<= 2;  // 06027FE4 shll2 r2
    c.r[0] = ld32(0x06028070u);  // 06027FE6 mov.l 0x06028070,r0
    c.r[7] = 0x0u;  // 06027FE8 mov #0,r7
    c.r[6] = 0x0u;  // 06027FEA mov #0,r6
    c.r[1] = ld32(c.r[1]);  // 06027FEC mov.l @r1,r1
    c.r[5] = c.r[10];  // 06027FEE mov r10,r5
    c.r[2] += c.r[1];  // 06027FF0 add r1,r2
    c.r[2] += 3;  // 06027FF2 add #3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06027FF4 mov.b @r2,r1
    c.r[4] = 0x0u;  // 06027FF6 mov #0,r4
    c.r[1] = c.r[1] & 0xFFu;  // 06027FF8 extu.b r1,r1
    c.r[1] >>= 2;  // 06027FFA shlr2 r1
    c.r[1] >>= 2;  // 06027FFC shlr2 r1
    c.r[1] >>= 2;  // 06027FFE shlr2 r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06028000 mov.l r1,@-r15
    c.r[1] = 0x2u;  // 06028002 mov #2,r1
    { const uint32_t x = c.r[0]; c.pr = 0x06028008u; c.r[15] -= 4; st32(c.r[15], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06028008u) return; }  // 06028004 jsr @r0 ; mov.l r1,@-r15
    c.r[8] = c.r[0] & 0xFFu;  // 06028008 extu.b r0,r8
    c.r[1] = (uint32_t)(int16_t)ld16(0x06028050u);  // 0602800A mov.w 0x06028050,r1
    c.t = c.r[8] == c.r[1];  // 0602800C cmp/eq r1,r8
    { const bool k = c.t; c.t = c.r[9] == c.r[1]; if (k) { goto L_0602803C; } }  // 0602800E bt/s 0x0602803C ; cmp/eq r1,r9
    { const bool k = c.t; c.r[1] = c.r[8]; if (k) { goto L_0602803C; } }  // 06028012 bt/s 0x0602803C ; mov r8,r1
    c.r[2] = ld32(0x06028074u);  // 06028016 mov.l 0x06028074,r2
    c.r[3] = ld32(c.r[2]);  // 06028018 mov.l @r2,r3
    c.r[1] <<= 2;  // 0602801A shll2 r1
    c.r[1] <<= 2;  // 0602801C shll2 r1
    c.r[3] += c.r[1];  // 0602801E add r1,r3
    c.r[3] += 4;  // 06028020 add #4,r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06028022 mov.b @r3,r0
    c.r[0] |= 0x40u;  // 06028024 or #64,r0
    st8(c.r[3], c.r[0]);  // 06028026 mov.b r0,@r3
    c.r[3] = ld32(c.r[2]);  // 06028028 mov.l @r2,r3
    c.r[3] += c.r[1];  // 0602802A add r1,r3
    c.r[3] += 5;  // 0602802C add #5,r3
    st8(c.r[3], c.r[9]);  // 0602802E mov.b r9,@r3
    c.r[2] = ld32(c.r[2]);  // 06028030 mov.l @r2,r2
    c.r[2] += c.r[1];  // 06028032 add r1,r2
    c.r[2] += 3;  // 06028034 add #3,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06028036 mov.b @r2,r0
    c.r[0] &= 0x7Fu;  // 06028038 and #127,r0
    st8(c.r[2], c.r[0]);  // 0602803A mov.b r0,@r2
L_0602803C:
    c.r[15] = c.r[14];  // 0602803C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602803E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06028040 mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06028042 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06028044 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06028046 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06028048 mov.l @r15+,r9
    c.r[0] = c.r[8];  // 0602804A mov r8,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602804C rts ; mov.l @r15+,r8
}

void f_06028078(SH2Context& c) {
    ran[538] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06028078 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602807A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0602807C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0602807E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06028080 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06028082 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06028084 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06028086 sts.l pr,@-r15
    c.r[1] = ld32(0x06028190u);  // 06028088 mov.l 0x06028190,r1
    c.r[2] = ld32(c.r[1]);  // 0602808A mov.l @r1,r2
    c.r[4] = c.r[4] & 0xFFu;  // 0602808C extu.b r4,r4
    c.r[1] = 0x1Eu;  // 0602808E mov #30,r1
    c.macl = c.r[4] * c.r[1];  // 06028090 mul.l r1,r4
    c.r[15] -= 4;  // 06028092 add #-4,r15
    c.r[14] = c.r[15];  // 06028094 mov r15,r14
    c.r[3] = c.macl;  // 06028096 sts macl,r3
    c.r[3] += c.r[2];  // 06028098 add r2,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0602809A mov.w @r3,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0602809C extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0602809E tst r1,r1
    { const bool k = c.t; c.r[11] = c.r[5] & 0xFFu; if (k) { goto L_060280B0; } }  // 060280A0 bt/s 0x060280B0 ; extu.b r5,r11
    c.r[3] += 15;  // 060280A4 add #15,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060280A6 mov.b @r3,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0602818Au);  // 060280A8 mov.w 0x0602818A,r2
    c.r[1] = c.r[1] & 0xFFu;  // 060280AA extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 060280AC cmp/eq r2,r1
    if (!c.t) { goto L_0602816E; }  // 060280AE bf 0x0602816E
L_060280B0:
    c.r[0] = ld32(0x06028190u);  // 060280B0 mov.l 0x06028190,r0
    c.r[1] = 0x1Eu;  // 060280B2 mov #30,r1
    c.r[9] = ld32(0x06028194u);  // 060280B4 mov.l 0x06028194,r9
    c.macl = c.r[4] * c.r[1];  // 060280B6 mul.l r1,r4
    c.r[2] = ld32(c.r[0]);  // 060280B8 mov.l @r0,r2
    c.r[5] = 0x1Bu;  // 060280BA mov #27,r5
    c.r[0] = c.macl;  // 060280BC sts macl,r0
    st32(c.r[14], c.r[0]);  // 060280BE mov.l r0,@r14
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 060280C0 mov.w @(r0,r2),r8
    c.r[4] = ld32(0x06028198u);  // 060280C2 mov.l 0x06028198,r4
    { const uint32_t x = c.r[9]; c.pr = 0x060280C8u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060280C8u) return; }  // 060280C4 jsr @r9 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 060280C8 mov r0,r1
    c.r[5] = c.r[8];  // 060280CA mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x060280D0u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060280D0u) return; }  // 060280CC jsr @r9 ; mov r1,r4
    c.r[3] = c.r[0];  // 060280D0 mov r0,r3
    c.r[1] = c.r[3];  // 060280D2 mov r3,r1
    c.r[1] += 5;  // 060280D4 add #5,r1
    c.r[3] += 4;  // 060280D6 add #4,r3
    c.r[10] = ld32(0x0602819Cu);  // 060280D8 mov.l 0x0602819C,r10
    c.r[12] = c.r[11];  // 060280DA mov r11,r12
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060280DC mov.b @r1,r2
    c.r[5] = 0x1Cu;  // 060280DE mov #28,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060280E0 mov.b @r3,r1
    c.r[2] = c.r[2] & 0xFFu;  // 060280E2 extu.b r2,r2
    c.r[13] = c.r[1] & 0xFFu;  // 060280E4 extu.b r1,r13
    c.r[13] <<= 8;  // 060280E6 shll8 r13
    c.r[13] |= c.r[2];  // 060280E8 or r2,r13
    c.r[13] >>= 2;  // 060280EA shlr2 r13
    c.r[13] >>= 2;  // 060280EC shlr2 r13
    c.r[12] += c.r[12];  // 060280EE add r12,r12
    c.r[12] += c.r[11];  // 060280F0 add r11,r12
    c.r[12] <<= 2;  // 060280F2 shll2 r12
    c.r[1] = ld32(c.r[10]);  // 060280F4 mov.l @r10,r1
    c.r[0] = c.r[12];  // 060280F6 mov r12,r0
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 060280F8 mov.w @(r0,r1),r8
    c.r[4] = ld32(0x06028198u);  // 060280FA mov.l 0x06028198,r4
    { const uint32_t x = c.r[9]; c.pr = 0x06028100u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06028100u) return; }  // 060280FC jsr @r9 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 06028100 mov r0,r1
    c.r[5] = c.r[8];  // 06028102 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06028108u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06028108u) return; }  // 06028104 jsr @r9 ; mov r1,r4
    c.r[0] = ld32(0x06028190u);  // 06028108 mov.l 0x06028190,r0
    c.r[1] = ld32(c.r[0]);  // 0602810A mov.l @r0,r1
    c.r[0] = ld32(c.r[14]);  // 0602810C mov.l @r14,r0
    c.r[0] += c.r[1];  // 0602810E add r1,r0
    c.r[0] += 2;  // 06028110 add #2,r0
    st32(c.r[14], c.r[0]);  // 06028112 mov.l r0,@r14
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06028114 mov.b @r0,r2
    c.r[1] = c.r[12];  // 06028116 mov r12,r1
    c.r[10] = ld32(c.r[10]);  // 06028118 mov.l @r10,r10
    c.r[2] = c.r[2] & 0xFFu;  // 0602811A extu.b r2,r2
    c.r[1] += c.r[10];  // 0602811C add r10,r1
    c.r[1] += 3;  // 0602811E add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06028120 mov.b @r1,r1
    c.r[0] = 0x3u;  // 06028122 mov #3,r0
    c.r[1] >>= 2;  // 06028124 shlr2 r1
    c.r[1] >>= 2;  // 06028126 shlr2 r1
    c.r[2] >>= 2;  // 06028128 shlr2 r2
    c.r[2] >>= 2;  // 0602812A shlr2 r2
    c.r[2] >>= 2;  // 0602812C shlr2 r2
    c.r[1] &= c.r[0];  // 0602812E and r0,r1
    c.t = c.r[2] == c.r[1];  // 06028130 cmp/eq r1,r2
    if (!c.t) { goto L_06028164; }  // 06028132 bf 0x06028164
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602818Cu);  // 06028134 mov.w 0x0602818C,r1
    c.t = c.r[13] == c.r[1];  // 06028136 cmp/eq r1,r13
    { const bool k = c.t; c.t = (int32_t)c.r[13] > (int32_t)c.r[1]; if (k) { goto L_0602814C; } }  // 06028138 bt/s 0x0602814C ; cmp/gt r1,r13
    { const bool k = c.t; c.t = (c.r[13] & c.r[13]) == 0; if (k) { goto L_06028146; } }  // 0602813C bt/s 0x06028146 ; tst r13,r13
    if (!c.t) { goto L_0602815A; }  // 06028140 bf 0x0602815A
    goto L_06028166;  // 06028142 bra 0x06028166 ; nop
L_06028146:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602818Eu);  // 06028146 mov.w 0x0602818E,r1
    c.t = c.r[13] == c.r[1];  // 06028148 cmp/eq r1,r13
    if (!c.t) { goto L_0602815A; }  // 0602814A bf 0x0602815A
L_0602814C:
    c.r[0] = c.r[12];  // 0602814C mov r12,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[10]);  // 0602814E mov.w @(r0,r10),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06028150 extu.w r1,r1
    c.t = c.r[1] == c.r[13];  // 06028152 cmp/eq r13,r1
    if (!c.t) { goto L_06028164; }  // 06028154 bf 0x06028164
    goto L_06028166;  // 06028156 bra 0x06028166 ; nop
L_0602815A:
    c.r[0] = ld32(0x060281A0u);  // 0602815A mov.l 0x060281A0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06028160u; c.r[4] = c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06028160u) return; }  // 0602815C jsr @r0 ; mov r13,r4
    c.r[11] = c.r[0]; goto L_06028166;  // 06028160 bra 0x06028166 ; mov r0,r11
L_06028164:
    c.r[11] = (uint32_t)(int16_t)ld16(0x0602818Au);  // 06028164 mov.w 0x0602818A,r11
L_06028166:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602818Au);  // 06028166 mov.w 0x0602818A,r1
    c.t = c.r[11] == c.r[1];  // 06028168 cmp/eq r1,r11
    { const bool k = !c.t; c.r[0] = 0x0u; if (k) { goto L_06028174; } }  // 0602816A bf/s 0x06028174 ; mov #0,r0
L_0602816E:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602818Au);  // 0602816E mov.w 0x0602818A,r0
    c.r[14] += 4; goto L_06028176;  // 06028170 bra 0x06028176 ; add #4,r14
L_06028174:
    c.r[14] += 4;  // 06028174 add #4,r14
L_06028176:
    c.r[15] = c.r[14];  // 06028176 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06028178 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602817A mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0602817C mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0602817E mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06028180 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06028182 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06028184 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06028186 rts ; mov.l @r15+,r8
}

void f_060281A4(SH2Context& c) {
    ran[539] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060281A4 mov.l r14,@-r15
    c.r[4] = c.r[4] & 0xFFu;  // 060281A6 extu.b r4,r4
    c.r[1] = ld32(0x06028264u);  // 060281A8 mov.l 0x06028264,r1
    c.r[4] <<= 2;  // 060281AA shll2 r4
    c.r[4] <<= 2;  // 060281AC shll2 r4
    c.r[2] = ld32(c.r[1]);  // 060281AE mov.l @r1,r2
    c.r[3] = 0xFFFFFFFFu;  // 060281B0 mov #-1,r3
    c.r[2] += c.r[4];  // 060281B2 add r4,r2
    c.r[2] += 8;  // 060281B4 add #8,r2
    st8(c.r[2], c.r[3]);  // 060281B6 mov.b r3,@r2
    c.r[2] = ld32(c.r[1]);  // 060281B8 mov.l @r1,r2
    c.r[2] += c.r[4];  // 060281BA add r4,r2
    c.r[2] += 9;  // 060281BC add #9,r2
    st8(c.r[2], c.r[3]);  // 060281BE mov.b r3,@r2
    c.r[2] = ld32(c.r[1]);  // 060281C0 mov.l @r1,r2
    c.r[2] += c.r[4];  // 060281C2 add r4,r2
    c.r[2] += 10;  // 060281C4 add #10,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060281C6 mov.b @r2,r0
    c.r[0] &= 0x7Fu;  // 060281C8 and #127,r0
    st8(c.r[2], c.r[0]);  // 060281CA mov.b r0,@r2
    c.r[2] = ld32(c.r[1]);  // 060281CC mov.l @r1,r2
    c.r[2] += c.r[4];  // 060281CE add r4,r2
    c.r[2] += 10;  // 060281D0 add #10,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060281D2 mov.b @r2,r0
    c.r[0] &= 0xBFu;  // 060281D4 and #191,r0
    st8(c.r[2], c.r[0]);  // 060281D6 mov.b r0,@r2
    c.r[2] = ld32(c.r[1]);  // 060281D8 mov.l @r1,r2
    c.r[2] += c.r[4];  // 060281DA add r4,r2
    c.r[2] += 10;  // 060281DC add #10,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060281DE mov.b @r2,r0
    c.r[0] &= 0xDFu;  // 060281E0 and #223,r0
    st8(c.r[2], c.r[0]);  // 060281E2 mov.b r0,@r2
    c.r[2] = ld32(c.r[1]);  // 060281E4 mov.l @r1,r2
    c.r[2] += c.r[4];  // 060281E6 add r4,r2
    c.r[2] += 10;  // 060281E8 add #10,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060281EA mov.b @r2,r0
    c.r[0] &= 0xEFu;  // 060281EC and #239,r0
    st8(c.r[2], c.r[0]);  // 060281EE mov.b r0,@r2
    c.r[2] = ld32(c.r[1]);  // 060281F0 mov.l @r1,r2
    c.r[2] += c.r[4];  // 060281F2 add r4,r2
    c.r[2] += 10;  // 060281F4 add #10,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060281F6 mov.b @r2,r0
    c.r[0] &= 0xF7u;  // 060281F8 and #247,r0
    st8(c.r[2], c.r[0]);  // 060281FA mov.b r0,@r2
    c.r[2] = ld32(c.r[1]);  // 060281FC mov.l @r1,r2
    c.r[2] += c.r[4];  // 060281FE add r4,r2
    c.r[2] += 10;  // 06028200 add #10,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06028202 mov.b @r2,r0
    c.r[0] &= 0xFBu;  // 06028204 and #251,r0
    st8(c.r[2], c.r[0]);  // 06028206 mov.b r0,@r2
    c.r[2] = ld32(c.r[1]);  // 06028208 mov.l @r1,r2
    c.r[2] += c.r[4];  // 0602820A add r4,r2
    c.r[2] += 10;  // 0602820C add #10,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602820E mov.b @r2,r0
    c.r[0] &= 0xFDu;  // 06028210 and #253,r0
    st8(c.r[2], c.r[0]);  // 06028212 mov.b r0,@r2
    c.r[2] = ld32(c.r[1]);  // 06028214 mov.l @r1,r2
    c.r[2] += c.r[4];  // 06028216 add r4,r2
    c.r[2] += 10;  // 06028218 add #10,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602821A mov.b @r2,r0
    c.r[0] &= 0xFEu;  // 0602821C and #254,r0
    st8(c.r[2], c.r[0]);  // 0602821E mov.b r0,@r2
    c.r[2] = ld32(c.r[1]);  // 06028220 mov.l @r1,r2
    c.r[2] += c.r[4];  // 06028222 add r4,r2
    c.r[2] += 11;  // 06028224 add #11,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06028226 mov.b @r2,r0
    c.r[0] &= 0x7Fu;  // 06028228 and #127,r0
    st8(c.r[2], c.r[0]);  // 0602822A mov.b r0,@r2
    c.r[2] = ld32(c.r[1]);  // 0602822C mov.l @r1,r2
    c.r[2] += c.r[4];  // 0602822E add r4,r2
    c.r[2] += 11;  // 06028230 add #11,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06028232 mov.b @r2,r0
    c.r[0] &= 0xBFu;  // 06028234 and #191,r0
    st8(c.r[2], c.r[0]);  // 06028236 mov.b r0,@r2
    c.r[2] = ld32(c.r[1]);  // 06028238 mov.l @r1,r2
    c.r[2] += c.r[4];  // 0602823A add r4,r2
    c.r[2] += 11;  // 0602823C add #11,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602823E mov.b @r2,r0
    c.r[0] &= 0xDFu;  // 06028240 and #223,r0
    st8(c.r[2], c.r[0]);  // 06028242 mov.b r0,@r2
    c.r[2] = ld32(c.r[1]);  // 06028244 mov.l @r1,r2
    c.r[2] += c.r[4];  // 06028246 add r4,r2
    c.r[2] += 11;  // 06028248 add #11,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602824A mov.b @r2,r0
    c.r[0] &= 0xEFu;  // 0602824C and #239,r0
    st8(c.r[2], c.r[0]);  // 0602824E mov.b r0,@r2
    c.r[1] = ld32(c.r[1]);  // 06028250 mov.l @r1,r1
    c.r[14] = c.r[15];  // 06028252 mov r15,r14
    c.r[1] += c.r[4];  // 06028254 add r4,r1
    c.r[1] += 11;  // 06028256 add #11,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06028258 mov.b @r1,r0
    c.r[0] &= 0xF7u;  // 0602825A and #247,r0
    st8(c.r[1], c.r[0]);  // 0602825C mov.b r0,@r1
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602825E rts ; mov.l @r15+,r14
}

void f_06028268(SH2Context& c) {
    ran[540] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06028268 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602826A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0602826C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0602826E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06028270 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06028272 mov r15,r14
    c.r[9] = c.r[5];  // 06028274 mov r5,r9
    c.r[8] = c.r[4] & 0xFFu;  // 06028276 extu.b r4,r8
    c.r[5] = 0x0u;  // 06028278 mov #0,r5
    c.r[4] = 0x0u;  // 0602827A mov #0,r4
    c.r[10] = (uint32_t)(int16_t)ld16(0x06028306u);  // 0602827C mov.w 0x06028306,r10
    c.r[6] = 0x0u;  // 0602827E mov #0,r6
L_06028280:
    c.r[1] = ld32(0x0602830Cu);  // 06028280 mov.l 0x0602830C,r1
    c.r[0] = ld32(c.r[1]);  // 06028282 mov.l @r1,r0
    c.r[2] = c.r[6];  // 06028284 mov r6,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 06028286 mov.b @(r0,r6),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06028288 extu.b r1,r1
    c.t = c.r[1] == c.r[10];  // 0602828A cmp/eq r10,r1
    { const bool k = c.t; c.r[2] += c.r[0]; if (k) { goto L_060282DC; } }  // 0602828C bt/s 0x060282DC ; add r0,r2
    c.r[1] = c.r[2];  // 06028290 mov r2,r1
    c.r[1] += 3;  // 06028292 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06028294 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06028296 mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06028298 shlr r0
    c.r[0] &= 0x3u;  // 0602829A and #3,r0
    c.t = c.r[0] == c.r[8];  // 0602829C cmp/eq r8,r0
    { const bool k = !c.t; c.r[2] += 7; if (k) { goto L_060282DC; } }  // 0602829E bf/s 0x060282DC ; add #7,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060282A2 mov.b @r2,r1
    c.r[0] = c.r[1];  // 060282A4 mov r1,r0
    c.r[0] >>= 2;  // 060282A6 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060282A8 shlr r0
    c.r[0] &= 0x1u;  // 060282AA and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060282AC tst r0,r0
    { const bool k = c.t; c.t = (c.r[9] & c.r[9]) == 0; if (k) { goto L_060282B4; } }  // 060282AE bt/s 0x060282B4 ; tst r9,r9
    if (c.t) { goto L_060282DC; }  // 060282B2 bt 0x060282DC
L_060282B4:
    c.r[1] = ld32(0x06028310u);  // 060282B4 mov.l 0x06028310,r1
    c.r[7] = c.r[4];  // 060282B6 mov r4,r7
    c.r[7] += c.r[7];  // 060282B8 add r7,r7
    c.r[2] = c.r[5] & 0xFFFFu;  // 060282BA extu.w r5,r2
    c.r[11] = c.r[2];  // 060282BC mov r2,r11
    c.r[11] >>= 8;  // 060282BE shlr8 r11
    c.r[0] = 0x7Fu;  // 060282C0 mov #127,r0
    c.r[1] = ld32(c.r[1]);  // 060282C2 mov.l @r1,r1
    c.r[11] &= c.r[0];  // 060282C4 and r0,r11
    c.r[0] = c.r[1];  // 060282C6 mov r1,r0
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 060282C8 mov.b @(r0,r7),r3
    c.r[4] += 1;  // 060282CA add #1,r4
    c.r[0] = (uint32_t)(int16_t)ld16(0x06028308u);  // 060282CC mov.w 0x06028308,r0
    c.r[3] &= c.r[0];  // 060282CE and r0,r3
    c.r[3] |= c.r[11];  // 060282D0 or r11,r3
    c.r[0] = c.r[1];  // 060282D2 mov r1,r0
    st8(c.r[0] + c.r[7], c.r[3]);  // 060282D4 mov.b r3,@(r0,r7)
    c.r[1] += c.r[7];  // 060282D6 add r7,r1
    c.r[1] += 1;  // 060282D8 add #1,r1
    st8(c.r[1], c.r[2]);  // 060282DA mov.b r2,@r1
L_060282DC:
    c.r[5] += 1;  // 060282DC add #1,r5
    c.r[1] = 0x49u;  // 060282DE mov #73,r1
    c.t = (int32_t)c.r[5] > (int32_t)c.r[1];  // 060282E0 cmp/gt r1,r5
    { const bool k = !c.t; c.r[6] += 16; if (k) { SH2_POLL(c); goto L_06028280; } }  // 060282E2 bf/s 0x06028280 ; add #16,r6
    c.r[3] = ld32(0x06028314u);  // 060282E6 mov.l 0x06028314,r3
    c.r[1] = ld32(0x06028310u);  // 060282E8 mov.l 0x06028310,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602830Au);  // 060282EA mov.w 0x0602830A,r0
    c.r[2] = ld32(c.r[1]);  // 060282EC mov.l @r1,r2
    c.r[15] = c.r[14];  // 060282EE mov r14,r15
    c.r[1] = c.r[4];  // 060282F0 mov r4,r1
    st8(c.r[0] + c.r[2], c.r[1]);  // 060282F2 mov.b r1,@(r0,r2)
    c.r[1] = c.r[1] & 0xFFu;  // 060282F4 extu.b r1,r1
    st32(c.r[3] + 20, c.r[1]);  // 060282F6 mov.l r1,@(20,r3)
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060282F8 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060282FA mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060282FC mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060282FE mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06028300 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.r[0] = c.r[4] & 0xFFu; c.pc = x; return; }  // 06028302 rts ; extu.b r4,r0
}

void f_06028318(SH2Context& c) {
    ran[541] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06028318 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602831A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602831C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602831E sts.l pr,@-r15
    c.r[9] = c.r[4] & 0xFFu;  // 06028320 extu.b r4,r9
    c.r[1] = ld32(0x060283E0u);  // 06028322 mov.l 0x060283E0,r1
    c.r[2] = c.r[9];  // 06028324 mov r9,r2
    c.r[1] = ld32(c.r[1]);  // 06028326 mov.l @r1,r1
    c.r[2] <<= 2;  // 06028328 shll2 r2
    c.r[2] <<= 2;  // 0602832A shll2 r2
    c.r[2] += c.r[1];  // 0602832C add r1,r2
    c.r[2] += 2;  // 0602832E add #2,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06028330 mov.b @r2,r2
    c.r[1] = ld32(0x060283E4u);  // 06028332 mov.l 0x060283E4,r1
    c.r[3] = ld32(c.r[1]);  // 06028334 mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06028336 extu.b r2,r2
    c.r[1] = 0x1Eu;  // 06028338 mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 0602833A mul.l r1,r2
    c.r[14] = c.r[15];  // 0602833C mov r15,r14
    c.r[1] = c.macl;  // 0602833E sts macl,r1
    c.r[0] = c.r[1];  // 06028340 mov r1,r0
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 06028342 mov.w @(r0,r3),r5
    c.r[4] = 0x0u;  // 06028344 mov #0,r4
    c.r[0] = ld32(0x060283E8u);  // 06028346 mov.l 0x060283E8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602834Cu; c.r[5] = c.r[5] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602834Cu) return; }  // 06028348 jsr @r0 ; extu.w r5,r5
    c.r[1] = c.r[0];  // 0602834C mov r0,r1
    c.r[2] = c.r[1] & 0xFFFFu;  // 0602834E extu.w r1,r2
    c.r[1] = ld32(0x060283ECu);  // 06028350 mov.l 0x060283EC,r1
    c.t = c.r[2] == c.r[1];  // 06028352 cmp/eq r1,r2
    { const bool k = c.t; c.r[2] <<= 2; if (k) { goto L_06028366; } }  // 06028354 bt/s 0x06028366 ; shll2 r2
    c.r[1] = ld32(0x060283F0u);  // 06028358 mov.l 0x060283F0,r1
    c.r[1] = ld32(c.r[1]);  // 0602835A mov.l @r1,r1
    c.r[1] += c.r[2];  // 0602835C add r2,r1
    c.r[1] += 22;  // 0602835E add #22,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06028360 mov.b @r1,r0
    c.r[0] &= 0x3Fu;  // 06028362 and #63,r0
    st8(c.r[1], c.r[0]);  // 06028364 mov.b r0,@r1
L_06028366:
    c.r[7] = ld32(0x060283F0u);  // 06028366 mov.l 0x060283F0,r7
    c.r[1] = ld32(c.r[7]);  // 06028368 mov.l @r7,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060283DCu);  // 0602836A mov.w 0x060283DC,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0602836C mov.w @(r0,r1),r1
    c.r[2] = c.r[9] & 0xFFFFu;  // 0602836E extu.w r9,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 06028370 extu.w r1,r1
    c.t = c.r[2] == c.r[1];  // 06028372 cmp/eq r1,r2
    { const bool k = !c.t; c.r[3] = 0x0u; if (k) { goto L_06028390; } }  // 06028374 bf/s 0x06028390 ; mov #0,r3
    c.r[6] = 0x4u;  // 06028378 mov #4,r6
L_0602837A:
    c.r[1] = c.r[3];  // 0602837A mov r3,r1
    c.r[1] <<= 2;  // 0602837C shll2 r1
    c.r[2] = ld32(c.r[7]);  // 0602837E mov.l @r7,r2
    c.r[3] += 1;  // 06028380 add #1,r3
    c.r[2] += c.r[1];  // 06028382 add r1,r2
    c.r[2] += 22;  // 06028384 add #22,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06028386 mov.b @r2,r0
    c.t = (int32_t)c.r[3] > (int32_t)c.r[6];  // 06028388 cmp/gt r6,r3
    c.r[0] &= 0x3Fu;  // 0602838A and #63,r0
    { const bool k = !c.t; st8(c.r[2], c.r[0]); if (k) { SH2_POLL(c); goto L_0602837A; } }  // 0602838C bf/s 0x0602837A ; mov.b r0,@r2
L_06028390:
    c.r[8] = ld32(0x060283E0u);  // 06028390 mov.l 0x060283E0,r8
    c.r[9] <<= 2;  // 06028392 shll2 r9
    c.r[9] <<= 2;  // 06028394 shll2 r9
    c.r[1] = ld32(0x060283F4u);  // 06028396 mov.l 0x060283F4,r1
    c.r[4] = ld32(c.r[8]);  // 06028398 mov.l @r8,r4
    c.r[5] = 0x10u;  // 0602839A mov #16,r5
    { const uint32_t x = c.r[1]; c.pr = 0x060283A0u; c.r[4] += c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060283A0u) return; }  // 0602839C jsr @r1 ; add r9,r4
    c.r[2] = 0xFFFFFFFFu;  // 060283A0 mov #-1,r2
    c.r[1] = ld32(c.r[8]);  // 060283A2 mov.l @r8,r1
    c.r[0] = c.r[9];  // 060283A4 mov r9,r0
    st8(c.r[0] + c.r[1], c.r[2]);  // 060283A6 mov.b r2,@(r0,r1)
    c.r[1] = ld32(c.r[8]);  // 060283A8 mov.l @r8,r1
    c.r[1] += c.r[9];  // 060283AA add r9,r1
    c.r[1] += 2;  // 060283AC add #2,r1
    st8(c.r[1], c.r[2]);  // 060283AE mov.b r2,@r1
    c.r[1] = ld32(c.r[8]);  // 060283B0 mov.l @r8,r1
    c.r[1] += c.r[9];  // 060283B2 add r9,r1
    c.r[1] += 6;  // 060283B4 add #6,r1
    st8(c.r[1], c.r[2]);  // 060283B6 mov.b r2,@r1
    c.r[1] = ld32(c.r[8]);  // 060283B8 mov.l @r8,r1
    c.r[1] += c.r[9];  // 060283BA add r9,r1
    c.r[1] += 8;  // 060283BC add #8,r1
    st8(c.r[1], c.r[2]);  // 060283BE mov.b r2,@r1
    c.r[1] = ld32(c.r[8]);  // 060283C0 mov.l @r8,r1
    c.r[1] += c.r[9];  // 060283C2 add r9,r1
    c.r[1] += 5;  // 060283C4 add #5,r1
    st8(c.r[1], c.r[2]);  // 060283C6 mov.b r2,@r1
    c.r[1] = ld32(c.r[8]);  // 060283C8 mov.l @r8,r1
    c.r[15] = c.r[14];  // 060283CA mov r14,r15
    c.r[9] += c.r[1];  // 060283CC add r1,r9
    c.r[9] += 9;  // 060283CE add #9,r9
    st8(c.r[9], c.r[2]);  // 060283D0 mov.b r2,@r9
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060283D2 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060283D4 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060283D6 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060283D8 rts ; mov.l @r15+,r8
}

void f_060283F8(SH2Context& c) {
    ran[542] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060283F8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060283FA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060283FC mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060283FE mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06028400 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06028402 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06028404 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06028406 sts.l pr,@-r15
    c.r[15] -= 20;  // 06028408 add #-20,r15
    c.r[14] = c.r[15];  // 0602840A mov r15,r14
    c.r[11] = c.r[4];  // 0602840C mov r4,r11
    c.r[12] = c.r[5];  // 0602840E mov r5,r12
    c.r[6] = c.r[6] & 0xFFu;  // 06028410 extu.b r6,r6
    st32(c.r[14], c.r[6]);  // 06028412 mov.l r6,@r14
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[11]);  // 06028414 mov.b @r11,r1
    c.r[5] = (uint32_t)(int16_t)ld16(0x06028538u);  // 06028416 mov.w 0x06028538,r5
    c.r[1] = c.r[1] & 0xFFu;  // 06028418 extu.b r1,r1
    st32(c.r[14] + 4, c.r[1]);  // 0602841A mov.l r1,@(4,r14)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[12]);  // 0602841C mov.b @r12,r1
    c.r[4] = ld32(0x0602853Cu);  // 0602841E mov.l 0x0602853C,r4
    c.r[1] = c.r[1] & 0xFFu;  // 06028420 extu.b r1,r1
    st32(c.r[14] + 8, c.r[1]);  // 06028422 mov.l r1,@(8,r14)
    c.r[1] = ld32(0x06028540u);  // 06028424 mov.l 0x06028540,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602842Au; c.r[10] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602842Au) return; }  // 06028426 jsr @r1 ; mov #0,r10
    c.r[0] = 0x0u;  // 0602842A mov #0,r0
    st32(c.r[14] + 12, c.r[0]);  // 0602842C mov.l r0,@(12,r14)
    c.r[9] = 0x3Fu;  // 0602842E mov #63,r9
    c.r[13] = 0x0u;  // 06028430 mov #0,r13
L_06028432:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[11]);  // 06028432 mov.b @r11,r1
    c.r[0] = ld32(0x0602853Cu);  // 06028434 mov.l 0x0602853C,r0
    c.r[3] = c.r[1] & 0xFFu;  // 06028436 extu.b r1,r3
    c.r[3] <<= 2;  // 06028438 shll2 r3
    c.r[3] <<= 2;  // 0602843A shll2 r3
    c.r[3] <<= 2;  // 0602843C shll2 r3
    c.r[3] += c.r[0];  // 0602843E add r0,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[12]);  // 06028440 mov.b @r12,r1
    c.r[0] = c.r[3];  // 06028442 mov r3,r0
    c.r[2] = c.r[1] & 0xFFu;  // 06028444 extu.b r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06028446 mov.b @(r0,r2),r1
    c.t = (int32_t)c.r[1] >= 0;  // 06028448 cmp/pz r1
    { const bool k = !c.t; c.r[1] = 0xFFFFFFFFu; if (k) { goto L_06028470; } }  // 0602844A bf/s 0x06028470 ; mov #-1,r1
    st8(c.r[0] + c.r[2], c.r[1]);  // 0602844E mov.b r1,@(r0,r2)
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[12]);  // 06028450 mov.b @r12,r5
    c.r[7] = 0xFFFFFFFFu;  // 06028452 mov #-1,r7
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[11]);  // 06028454 mov.b @r11,r4
    c.r[0] = ld32(0x06028544u);  // 06028456 mov.l 0x06028544,r0
    c.r[6] = ld32(c.r[14]);  // 06028458 mov.l @r14,r6
    c.r[5] = c.r[5] & 0xFFu;  // 0602845A extu.b r5,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06028460u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06028460u) return; }  // 0602845C jsr @r0 ; extu.b r4,r4
    c.r[1] = c.r[0];  // 06028460 mov r0,r1
    c.r[1] = (uint32_t)(int32_t)(int8_t)c.r[1];  // 06028462 exts.b r1,r1
    c.t = (int32_t)c.r[1] >= 0;  // 06028464 cmp/pz r1
    { const bool k = c.t; c.r[0] = c.r[1]; if (k) { goto L_06028522; } }  // 06028466 bt/s 0x06028522 ; mov r1,r0
    c.r[0] = ld32(c.r[14]);  // 0602846A mov.l @r14,r0
    c.r[0] &= 0xEFu;  // 0602846C and #239,r0
    st32(c.r[14], c.r[0]);  // 0602846E mov.l r0,@r14
L_06028470:
    c.r[8] = 0x0u;  // 06028470 mov #0,r8
    c.r[4] = ld32(0x06028548u);  // 06028472 mov.l 0x06028548,r4
    c.r[5] = 0x0u;  // 06028474 mov #0,r5
    c.r[0] = c.r[10];  // 06028476 mov r10,r0
    c.r[0] += c.r[0];  // 06028478 add r0,r0
    c.r[6] = ld32(0x0602854Cu);  // 0602847A mov.l 0x0602854C,r6
    c.r[6] += c.r[0];  // 0602847C add r0,r6
    c.r[7] = c.r[0];  // 0602847E mov r0,r7
L_06028480:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602853Au);  // 06028480 mov.w 0x0602853A,r1
    c.t = c.r[10] > c.r[1];  // 06028482 cmp/hi r1,r10
    if (c.t) { goto L_060284F6; }  // 06028484 bt 0x060284F6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[11]);  // 06028486 mov.b @r11,r1
    c.r[0] = ld32(0x06028548u);  // 06028488 mov.l 0x06028548,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 0602848A mov.b @(r0,r5),r2
    c.r[1] += c.r[2];  // 0602848C add r2,r1
    c.r[3] = (uint32_t)(int32_t)(int8_t)c.r[1];  // 0602848E exts.b r1,r3
    c.t = (int32_t)c.r[3] >= 0;  // 06028490 cmp/pz r3
    { const bool k = c.t; c.t = (int32_t)c.r[3] > (int32_t)c.r[9]; if (k) { goto L_0602849A; } }  // 06028492 bt/s 0x0602849A ; cmp/gt r9,r3
    c.r[3] = 0x0u; goto L_0602849E;  // 06028496 bra 0x0602849E ; mov #0,r3
L_0602849A:
    if (!c.t) { goto L_0602849E; }  // 0602849A bf 0x0602849E
    c.r[3] = c.r[9];  // 0602849C mov r9,r3
L_0602849E:
    c.r[1] = c.r[4];  // 0602849E mov r4,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[12]);  // 060284A0 mov.b @r12,r2
    c.r[1] += 1;  // 060284A2 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060284A4 mov.b @r1,r1
    c.r[2] += c.r[1];  // 060284A6 add r1,r2
    c.r[2] = (uint32_t)(int32_t)(int8_t)c.r[2];  // 060284A8 exts.b r2,r2
    c.t = (int32_t)c.r[2] >= 0;  // 060284AA cmp/pz r2
    { const bool k = c.t; st32(c.r[14] + 16, c.r[2]); if (k) { goto L_060284B6; } }  // 060284AC bt/s 0x060284B6 ; mov.l r2,@(16,r14)
    c.r[0] = 0x0u;  // 060284B0 mov #0,r0
    st32(c.r[14] + 16, c.r[0]); goto L_060284BE;  // 060284B2 bra 0x060284BE ; mov.l r0,@(16,r14)
L_060284B6:
    c.r[0] = ld32(c.r[14] + 16);  // 060284B6 mov.l @(16,r14),r0
    c.t = (int32_t)c.r[0] > (int32_t)c.r[9];  // 060284B8 cmp/gt r9,r0
    if (!c.t) { goto L_060284BE; }  // 060284BA bf 0x060284BE
    st32(c.r[14] + 16, c.r[9]);  // 060284BC mov.l r9,@(16,r14)
L_060284BE:
    c.r[2] = c.r[3];  // 060284BE mov r3,r2
    c.r[2] <<= 2;  // 060284C0 shll2 r2
    c.r[2] <<= 2;  // 060284C2 shll2 r2
    c.r[2] <<= 2;  // 060284C4 shll2 r2
    c.r[0] = ld32(0x0602853Cu);  // 060284C6 mov.l 0x0602853C,r0
    c.r[2] += c.r[0];  // 060284C8 add r0,r2
    c.r[0] = ld32(c.r[14] + 16);  // 060284CA mov.l @(16,r14),r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 060284CC mov.b @(r0,r2),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060284CE tst r1,r1
    { const bool k = !c.t; c.r[1] = 0x1u; if (k) { goto L_060284EA; } }  // 060284D0 bf/s 0x060284EA ; mov #1,r1
    st8(c.r[0] + c.r[2], c.r[1]);  // 060284D4 mov.b r1,@(r0,r2)
    c.r[0] = ld32(0x0602854Cu);  // 060284D6 mov.l 0x0602854C,r0
    st8(c.r[0] + c.r[7], c.r[3]);  // 060284D8 mov.b r3,@(r0,r7)
    c.r[1] = c.r[6];  // 060284DA mov r6,r1
    c.r[1] += 1;  // 060284DC add #1,r1
    c.r[0] = 0x13u;  // 060284DE mov #19,r0
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 060284E0 mov.b @(r0,r14),r0
    c.r[6] += 2;  // 060284E2 add #2,r6
    c.r[7] += 2;  // 060284E4 add #2,r7
    c.r[10] += 1;  // 060284E6 add #1,r10
    st8(c.r[1], c.r[0]);  // 060284E8 mov.b r0,@r1
L_060284EA:
    c.r[4] += 2;  // 060284EA add #2,r4
    c.r[8] += 1;  // 060284EC add #1,r8
    c.r[1] = 0x3u;  // 060284EE mov #3,r1
    c.t = c.r[8] > c.r[1];  // 060284F0 cmp/hi r1,r8
    { const bool k = !c.t; c.r[5] += 2; if (k) { SH2_POLL(c); goto L_06028480; } }  // 060284F2 bf/s 0x06028480 ; add #2,r5
L_060284F6:
    c.r[2] = ld32(0x0602854Cu);  // 060284F6 mov.l 0x0602854C,r2
    c.r[2] += c.r[13];  // 060284F8 add r13,r2
    c.r[0] = ld32(0x0602854Cu);  // 060284FA mov.l 0x0602854C,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[13]);  // 060284FC mov.b @(r0,r13),r1
    c.r[2] += 1;  // 060284FE add #1,r2
    st8(c.r[11], c.r[1]);  // 06028500 mov.b r1,@r11
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06028502 mov.b @r2,r1
    c.r[13] += 2;  // 06028504 add #2,r13
    st8(c.r[12], c.r[1]);  // 06028506 mov.b r1,@r12
    c.r[0] = ld32(c.r[14] + 12);  // 06028508 mov.l @(12,r14),r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602853Au);  // 0602850A mov.w 0x0602853A,r1
    c.r[0] += 1;  // 0602850C add #1,r0
    c.t = c.r[0] > c.r[1];  // 0602850E cmp/hi r1,r0
    { const bool k = !c.t; st32(c.r[14] + 12, c.r[0]); if (k) { SH2_POLL(c); goto L_06028432; } }  // 06028510 bf/s 0x06028432 ; mov.l r0,@(12,r14)
    c.r[0] = 0x7u;  // 06028514 mov #7,r0
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 06028516 mov.b @(r0,r14),r0
    st8(c.r[11], c.r[0]);  // 06028518 mov.b r0,@r11
    c.r[0] = 0xBu;  // 0602851A mov #11,r0
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 0602851C mov.b @(r0,r14),r0
    st8(c.r[12], c.r[0]);  // 0602851E mov.b r0,@r12
    c.r[0] = 0xFFFFFFFFu;  // 06028520 mov #-1,r0
L_06028522:
    c.r[14] += 20;  // 06028522 add #20,r14
    c.r[15] = c.r[14];  // 06028524 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06028526 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06028528 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0602852A mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0602852C mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0602852E mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06028530 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06028532 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06028534 rts ; mov.l @r15+,r8
}

void f_06028550(SH2Context& c) {
    ran[543] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06028550 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06028552 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06028554 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06028556 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06028558 sts.l pr,@-r15
    c.r[15] -= 76;  // 0602855A add #-76,r15
    c.r[14] = c.r[15];  // 0602855C mov r15,r14
    c.r[0] = ld32(0x060285B0u);  // 0602855E mov.l 0x060285B0,r0
    c.r[6] = 0x1u;  // 06028560 mov #1,r6
    c.r[5] = 0xFFFFFFFBu;  // 06028562 mov #-5,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06028568u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06028568u) return; }  // 06028564 jsr @r0 ; mov r14,r4
    c.r[9] = c.r[0];  // 06028568 mov r0,r9
    c.r[8] = 0x0u;  // 0602856A mov #0,r8
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[9];  // 0602856C cmp/ge r9,r8
    { const bool k = c.t; c.r[7] = 0x7Fu; if (k) { goto L_06028588; } }  // 0602856E bt/s 0x06028588 ; mov #127,r7
    c.r[10] = ld32(0x060285B4u);  // 06028572 mov.l 0x060285B4,r10
    c.r[0] = c.r[14];  // 06028574 mov r14,r0
L_06028576:
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 06028576 mov.b @(r0,r8),r4
    { const uint32_t x = c.r[10]; c.pr = 0x0602857Cu; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602857Cu) return; }  // 06028578 jsr @r10 ; extu.b r4,r4
    c.r[8] += 1;  // 0602857C add #1,r8
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[9];  // 0602857E cmp/ge r9,r8
    { const bool k = !c.t; c.r[0] = c.r[14]; if (k) { SH2_POLL(c); goto L_06028576; } }  // 06028580 bf/s 0x06028576 ; mov r14,r0
    c.r[8] = 0x0u;  // 06028584 mov #0,r8
    c.r[7] = 0x7Fu;  // 06028586 mov #127,r7
L_06028588:
    c.r[3] = ld32(0x060285B8u);  // 06028588 mov.l 0x060285B8,r3
    c.r[2] = 0x0u;  // 0602858A mov #0,r2
L_0602858C:
    c.r[8] += 1;  // 0602858C add #1,r8
    c.r[1] = ld32(c.r[3]);  // 0602858E mov.l @r3,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[7];  // 06028590 cmp/gt r7,r8
    c.r[1] += c.r[2];  // 06028592 add r2,r1
    c.r[1] += 2;  // 06028594 add #2,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06028596 mov.b @r1,r0
    c.r[2] += 30;  // 06028598 add #30,r2
    c.r[0] &= 0xDFu;  // 0602859A and #223,r0
    { const bool k = !c.t; st8(c.r[1], c.r[0]); if (k) { SH2_POLL(c); goto L_0602858C; } }  // 0602859C bf/s 0x0602858C ; mov.b r0,@r1
    c.r[14] += 76;  // 060285A0 add #76,r14
    c.r[15] = c.r[14];  // 060285A2 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060285A4 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060285A6 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060285A8 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060285AA mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060285AC rts ; mov.l @r15+,r8
}

void f_060285BC(SH2Context& c) {
    ran[544] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060285BC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060285BE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060285C0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060285C2 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060285C4 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060285C6 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060285C8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060285CA sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x0602870Eu);  // 060285CC mov.w 0x0602870E,r3
    c.r[15] += c.r[3];  // 060285CE add r3,r15
    c.r[14] = c.r[15];  // 060285D0 mov r15,r14
    c.r[11] = c.r[4] & 0xFFu;  // 060285D2 extu.b r4,r11
    c.r[0] = ld32(0x06028718u);  // 060285D4 mov.l 0x06028718,r0
    c.r[9] = c.r[11];  // 060285D6 mov r11,r9
    c.r[9] <<= 2;  // 060285D8 shll2 r9
    c.r[9] <<= 2;  // 060285DA shll2 r9
    c.r[12] = ld32(0x0602871Cu);  // 060285DC mov.l 0x0602871C,r12
    c.r[1] = ld32(c.r[0]);  // 060285DE mov.l @r0,r1
    c.r[6] = c.r[11];  // 060285E0 mov r11,r6
    c.r[1] += c.r[9];  // 060285E2 add r9,r1
    c.r[1] += 2;  // 060285E4 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060285E6 mov.b @r1,r1
    c.r[13] = ld32(0x06028720u);  // 060285E8 mov.l 0x06028720,r13
    c.r[4] = ld32(c.r[12]);  // 060285EA mov.l @r12,r4
    c.r[10] = c.r[1] & 0xFFu;  // 060285EC extu.b r1,r10
    { const uint32_t x = c.r[13]; c.pr = 0x060285F2u; c.r[5] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060285F2u) return; }  // 060285EE jsr @r13 ; mov r10,r5
    c.r[13] = 0x0u;  // 060285F2 mov #0,r13
    c.r[0] = (uint32_t)(int16_t)ld16(0x06028710u);  // 060285F4 mov.w 0x06028710,r0
    st32(c.r[0] + c.r[14], c.r[13]);  // 060285F6 mov.l r13,@(r0,r14)
    c.r[1] = ld32(0x06028724u);  // 060285F8 mov.l 0x06028724,r1
    c.r[2] = ld32(c.r[1]);  // 060285FA mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 060285FC mov #30,r1
    c.macl = c.r[10] * c.r[1];  // 060285FE mul.l r1,r10
    c.r[4] = 0x0u;  // 06028600 mov #0,r4
    c.r[1] = c.macl;  // 06028602 sts macl,r1
    c.r[0] = c.r[1];  // 06028604 mov r1,r0
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 06028606 mov.w @(r0,r2),r5
    c.r[13] = ld32(0x06028728u);  // 06028608 mov.l 0x06028728,r13
    { const uint32_t x = c.r[13]; c.pr = 0x0602860Eu; c.r[5] = c.r[5] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602860Eu) return; }  // 0602860A jsr @r13 ; extu.w r5,r5
    c.r[1] = c.r[0];  // 0602860E mov r0,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06028610 extu.w r1,r1
    c.r[0] = c.r[1];  // 06028612 mov r1,r0
    c.t = c.r[0] == 0x4u;  // 06028614 cmp/eq #4,r0
    { const bool k = !c.t; c.r[0] = 0x1u; if (k) { goto L_06028620; } }  // 06028616 bf/s 0x06028620 ; mov #1,r0
    c.r[13] = (uint32_t)(int16_t)ld16(0x06028710u);  // 0602861A mov.w 0x06028710,r13
    c.r[13] += c.r[14];  // 0602861C add r14,r13
    st32(c.r[13], c.r[0]);  // 0602861E mov.l r0,@r13
L_06028620:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06028712u);  // 06028620 mov.w 0x06028712,r0
    c.r[13] = (uint32_t)(int16_t)ld16(0x06028714u);  // 06028622 mov.w 0x06028714,r13
    c.r[1] = ld32(c.r[12]);  // 06028624 mov.l @r12,r1
    c.r[13] += c.r[14];  // 06028626 add r14,r13
    st32(c.r[13], c.r[0]);  // 06028628 mov.l r0,@r13
    c.r[13] = (uint32_t)(int16_t)ld16(0x06028714u);  // 0602862A mov.w 0x06028714,r13
    c.r[13] += c.r[14];  // 0602862C add r14,r13
    c.r[0] = ld32(c.r[13]);  // 0602862E mov.l @r13,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06028630 mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06028632 extu.b r1,r1
    c.r[2] = c.r[1];  // 06028634 mov r1,r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 06028636 shlr r2
    c.r[0] = 0xFu;  // 06028638 mov #15,r0
    c.r[2] &= c.r[0];  // 0602863A and r0,r2
    c.r[0] = c.r[2];  // 0602863C mov r2,r0
    c.t = c.r[0] == 0x9u;  // 0602863E cmp/eq #9,r0
    { const bool k = !c.t; c.r[8] = 0x0u; if (k) { goto L_060286A2; } }  // 06028640 bf/s 0x060286A2 ; mov #0,r8
    c.r[12] = c.r[1];  // 06028644 mov r1,r12
    c.r[12] >>= 2;  // 06028646 shlr2 r12
    c.t = c.r[12] & 1; c.r[12] >>= 1;  // 06028648 shlr r12
    c.r[12] >>= 2;  // 0602864A shlr2 r12
    c.r[0] = c.r[12];  // 0602864C mov r12,r0
    c.t = c.r[0] == 0x1u;  // 0602864E cmp/eq #1,r0
    { const bool k = !c.t; c.r[2] = c.r[9]; if (k) { goto L_060286A2; } }  // 06028650 bf/s 0x060286A2 ; mov r9,r2
    c.r[13] = ld32(0x06028718u);  // 06028654 mov.l 0x06028718,r13
    c.r[3] = ld32(c.r[13]);  // 06028656 mov.l @r13,r3
    c.r[2] += c.r[3];  // 06028658 add r3,r2
    c.r[1] = c.r[2];  // 0602865A mov r2,r1
    c.r[1] += 4;  // 0602865C add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602865E mov.b @r1,r1
    c.r[0] = 0x1u;  // 06028660 mov #1,r0
    c.r[1] >>= 2;  // 06028662 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06028664 shlr r1
    c.r[1] >>= 2;  // 06028666 shlr2 r1
    c.r[1] &= c.r[0];  // 06028668 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0602866A tst r1,r1
    { const bool k = c.t; c.r[2] += 6; if (k) { goto L_060286A2; } }  // 0602866C bt/s 0x060286A2 ; add #6,r2
    c.r[6] = (uint32_t)(int16_t)ld16(0x06028716u);  // 06028670 mov.w 0x06028716,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06028672 mov.b @r2,r1
    c.r[4] = c.r[14];  // 06028674 mov r14,r4
    c.r[1] = c.r[1] & 0xFFu;  // 06028676 extu.b r1,r1
    c.r[1] <<= 2;  // 06028678 shll2 r1
    c.r[1] <<= 2;  // 0602867A shll2 r1
    c.r[1] += c.r[3];  // 0602867C add r3,r1
    c.r[1] += 2;  // 0602867E add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06028680 mov.b @r1,r1
    c.r[13] = ld32(0x06028720u);  // 06028682 mov.l 0x06028720,r13
    c.r[9] = c.r[1] & 0xFFu;  // 06028684 extu.b r1,r9
    { const uint32_t x = c.r[13]; c.pr = 0x0602868Au; c.r[5] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602868Au) return; }  // 06028686 jsr @r13 ; mov r9,r5
    c.r[13] = (uint32_t)(int16_t)ld16(0x06028714u);  // 0602868A mov.w 0x06028714,r13
    c.r[13] += c.r[14];  // 0602868C add r14,r13
    c.r[0] = ld32(c.r[13]);  // 0602868E mov.l @r13,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 06028690 mov.b @(r0,r14),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06028692 extu.b r1,r1
    c.r[1] >>= 2;  // 06028694 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06028696 shlr r1
    c.r[1] >>= 2;  // 06028698 shlr2 r1
    c.r[0] = c.r[1];  // 0602869A mov r1,r0
    c.t = c.r[0] == 0x2u;  // 0602869C cmp/eq #2,r0
    if (c.t) { goto L_060286A2; }  // 0602869E bt 0x060286A2
    c.r[8] = c.r[12];  // 060286A0 mov r12,r8
L_060286A2:
    c.r[1] = ld32(0x06028718u);  // 060286A2 mov.l 0x06028718,r1
    c.r[2] = c.r[11];  // 060286A4 mov r11,r2
    c.r[1] = ld32(c.r[1]);  // 060286A6 mov.l @r1,r1
    c.r[2] <<= 2;  // 060286A8 shll2 r2
    c.r[2] <<= 2;  // 060286AA shll2 r2
    c.r[2] += c.r[1];  // 060286AC add r1,r2
    c.r[1] = ld32(c.r[2] + 12);  // 060286AE mov.l @(12,r2),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060286B0 tst r1,r1
    if (c.t) { goto L_060286C2; }  // 060286B2 bt 0x060286C2
    c.r[13] = (uint32_t)(int16_t)ld16(0x06028710u);  // 060286B4 mov.w 0x06028710,r13
    c.r[13] += c.r[14];  // 060286B6 add r14,r13
    c.r[13] = ld32(c.r[13]);  // 060286B8 mov.l @r13,r13
    c.t = (c.r[13] & c.r[13]) == 0;  // 060286BA tst r13,r13
    if (!c.t) { goto L_060286C2; }  // 060286BC bf 0x060286C2
    goto L_060287F2;  // 060286BE bra 0x060287F2 ; nop
L_060286C2:
    c.r[2] += 7;  // 060286C2 add #7,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060286C4 mov.b @r2,r1
    c.r[0] = c.r[1];  // 060286C6 mov r1,r0
    c.r[0] >>= 2;  // 060286C8 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060286CA shlr r0
    c.r[0] &= 0x1u;  // 060286CC and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060286CE tst r0,r0
    if (!c.t) { goto L_060286DE; }  // 060286D0 bf 0x060286DE
    c.r[0] = (uint32_t)(int16_t)ld16(0x06028710u);  // 060286D2 mov.w 0x06028710,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 060286D4 mov.l @(r0,r14),r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060286D6 tst r0,r0
    { const bool k = !c.t; c.t = (c.r[8] & c.r[8]) == 0; if (k) { goto L_060286DE; } }  // 060286D8 bf/s 0x060286DE ; tst r8,r8
    if (c.t) { goto L_060287A6; }  // 060286DC bt 0x060287A6
L_060286DE:
    c.r[0] = ld32(0x0602872Cu);  // 060286DE mov.l 0x0602872C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060286E4u; c.r[4] = 0x45u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060286E4u) return; }  // 060286E0 jsr @r0 ; mov #69,r4
    c.r[5] = c.r[0] & 0xFFFFu;  // 060286E4 extu.w r0,r5
    c.t = (c.r[5] & c.r[5]) == 0;  // 060286E6 tst r5,r5
    { const bool k = !c.t; c.r[2] = c.r[11]; if (k) { goto L_0602876A; } }  // 060286E8 bf/s 0x0602876A ; mov r11,r2
    c.r[1] = ld32(0x06028718u);  // 060286EC mov.l 0x06028718,r1
    c.r[1] = ld32(c.r[1]);  // 060286EE mov.l @r1,r1
    c.r[2] <<= 2;  // 060286F0 shll2 r2
    c.r[2] <<= 2;  // 060286F2 shll2 r2
    c.r[2] += c.r[1];  // 060286F4 add r1,r2
    c.r[2] += 4;  // 060286F6 add #4,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060286F8 mov.b @r2,r1
    c.r[0] = c.r[1];  // 060286FA mov r1,r0
    c.r[0] >>= 2;  // 060286FC shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060286FE shlr r0
    c.r[0] >>= 2;  // 06028700 shlr2 r0
    c.r[0] &= 0x1u;  // 06028702 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06028704 tst r0,r0
    { const bool k = c.t; c.t = (c.r[8] & c.r[8]) == 0; if (k) { goto L_06028732; } }  // 06028706 bt/s 0x06028732 ; tst r8,r8
    goto L_06028730;  // 0602870A bra 0x06028730 ; nop
L_06028730:
    if (c.t) { goto L_0602876A; }  // 06028730 bt 0x0602876A
L_06028732:
    c.r[1] = ld32(0x06028814u);  // 06028732 mov.l 0x06028814,r1
    c.r[1] = ld32(c.r[1]);  // 06028734 mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602880Au);  // 06028736 mov.w 0x0602880A,r0
    c.r[3] = c.r[1];  // 06028738 mov r1,r3
    c.r[3] += 10;  // 0602873A add #10,r3
    c.r[7] = c.r[1];  // 0602873C mov r1,r7
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0602873E mov.w @r3,r2
    c.r[7] += 12;  // 06028740 add #12,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06028742 mov.b @r7,r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 06028744 extu.w r2,r2
    c.r[6] = c.r[1] & 0xFFu;  // 06028746 extu.b r1,r6
    c.r[1] = ld32(0x06028818u);  // 06028748 mov.l 0x06028818,r1
    c.r[1] = ld32(c.r[1]);  // 0602874A mov.l @r1,r1
    c.r[2] <<= 8;  // 0602874C shll8 r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0602874E mov.w @(r0,r1),r1
    c.r[6] |= c.r[2];  // 06028750 or r2,r6
    c.r[1] = c.r[1] & 0xFFFFu;  // 06028752 extu.w r1,r1
    c.t = c.r[6] >= c.r[1];  // 06028754 cmp/hs r1,r6
    { const bool k = c.t; c.r[2] = c.r[6]; if (k) { goto L_06028760; } }  // 06028756 bt/s 0x06028760 ; mov r6,r2
    st16(c.r[3], c.r[5]);  // 0602875A mov.w r5,@r3
    st8(c.r[7], c.r[5]); goto L_0602876A;  // 0602875C bra 0x0602876A ; mov.b r5,@r7
L_06028760:
    c.r[2] -= c.r[1];  // 06028760 sub r1,r2
    c.r[1] = c.r[2];  // 06028762 mov r2,r1
    c.r[1] >>= 8;  // 06028764 shlr8 r1
    st16(c.r[3], c.r[1]);  // 06028766 mov.w r1,@r3
    st8(c.r[7], c.r[2]);  // 06028768 mov.b r2,@r7
L_0602876A:
    c.r[1] = ld32(0x0602881Cu);  // 0602876A mov.l 0x0602881C,r1
    c.r[2] = c.r[11];  // 0602876C mov r11,r2
    c.r[2] <<= 2;  // 0602876E shll2 r2
    c.r[2] <<= 2;  // 06028770 shll2 r2
    c.r[13] = (uint32_t)(int16_t)ld16(0x0602880Cu);  // 06028772 mov.w 0x0602880C,r13
    c.r[1] = ld32(c.r[1]);  // 06028774 mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602880Eu);  // 06028776 mov.w 0x0602880E,r0
    c.r[2] += c.r[1];  // 06028778 add r1,r2
    c.r[2] += 7;  // 0602877A add #7,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602877C mov.b @r2,r1
    c.r[0] += c.r[14];  // 0602877E add r14,r0
    c.r[1] &= c.r[13];  // 06028780 and r13,r1
    st8(c.r[2], c.r[1]);  // 06028782 mov.b r1,@r2
    c.r[0] = ld32(c.r[0]);  // 06028784 mov.l @r0,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06028786 tst r0,r0
    if (c.t) { goto L_060287A6; }  // 06028788 bt 0x060287A6
    c.r[1] = ld32(0x06028820u);  // 0602878A mov.l 0x06028820,r1
    c.r[2] = ld32(c.r[1]);  // 0602878C mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 0602878E mov #30,r1
    c.macl = c.r[10] * c.r[1];  // 06028790 mul.l r1,r10
    c.r[1] = c.macl;  // 06028792 sts macl,r1
    c.r[1] += c.r[2];  // 06028794 add r2,r1
    c.r[1] += 15;  // 06028796 add #15,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06028798 mov.b @r1,r4
    c.r[1] = ld32(0x06028824u);  // 0602879A mov.l 0x06028824,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060287A0u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060287A0u) return; }  // 0602879C jsr @r1 ; extu.b r4,r4
    c.r[0] = ld32(0x06028828u);  // 060287A0 mov.l 0x06028828,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060287A6u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060287A6u) return; }  // 060287A2 jsr @r0 ; mov r10,r4
L_060287A6:
    c.r[8] = ld32(0x06028818u);  // 060287A6 mov.l 0x06028818,r8
    c.r[4] = ld32(c.r[8]);  // 060287A8 mov.l @r8,r4
    c.r[1] = ld32(0x0602882Cu);  // 060287AA mov.l 0x0602882C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060287B0u; c.r[5] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060287B0u) return; }  // 060287AC jsr @r1 ; mov r10,r5
    c.r[9] = 0x0u;  // 060287B0 mov #0,r9
    c.r[12] = ld32(0x06028830u);  // 060287B2 mov.l 0x06028830,r12
L_060287B4:
    c.r[1] = ld32(0x06028820u);  // 060287B4 mov.l 0x06028820,r1
    c.r[2] = ld32(c.r[1]);  // 060287B6 mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 060287B8 mov #30,r1
    c.macl = c.r[9] * c.r[1];  // 060287BA mul.l r1,r9
    c.r[3] = c.macl;  // 060287BC sts macl,r3
    c.r[3] += c.r[2];  // 060287BE add r2,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 060287C0 mov.w @r3,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 060287C2 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060287C4 tst r1,r1
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_060287E8; } }  // 060287C6 bt/s 0x060287E8 ; mov r9,r1
    c.r[3] += 16;  // 060287CA add #16,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060287CC mov.b @r3,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060287CE extu.b r1,r1
    c.t = c.r[1] == c.r[10];  // 060287D0 cmp/eq r10,r1
    { const bool k = !c.t; c.r[1] = c.r[9]; if (k) { goto L_060287E8; } }  // 060287D2 bf/s 0x060287E8 ; mov r9,r1
    c.r[6] = c.r[11];  // 060287D6 mov r11,r6
    c.r[4] = ld32(c.r[8]);  // 060287D8 mov.l @r8,r4
    { const uint32_t x = c.r[12]; c.pr = 0x060287DEu; c.r[5] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060287DEu) return; }  // 060287DA jsr @r12 ; mov r9,r5
    c.r[1] = ld32(0x0602882Cu);  // 060287DE mov.l 0x0602882C,r1
    c.r[4] = ld32(c.r[8]);  // 060287E0 mov.l @r8,r4
    { const uint32_t x = c.r[1]; c.pr = 0x060287E6u; c.r[5] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060287E6u) return; }  // 060287E2 jsr @r1 ; mov r9,r5
    c.r[1] = c.r[9];  // 060287E6 mov r9,r1
L_060287E8:
    c.r[1] += 1;  // 060287E8 add #1,r1
    c.r[9] = c.r[1] & 0xFFu;  // 060287EA extu.b r1,r9
    c.r[1] = 0x7Fu;  // 060287EC mov #127,r1
    c.t = c.r[9] > c.r[1];  // 060287EE cmp/hi r1,r9
    if (!c.t) { SH2_POLL(c); goto L_060287B4; }  // 060287F0 bf 0x060287B4
L_060287F2:
    c.r[3] = (uint32_t)(int16_t)ld16(0x06028810u);  // 060287F2 mov.w 0x06028810,r3
    c.r[14] += c.r[3];  // 060287F4 add r3,r14
    c.r[15] = c.r[14];  // 060287F6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060287F8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060287FA mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060287FC mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060287FE mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06028800 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06028802 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06028804 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06028806 rts ; mov.l @r15+,r8
}

void f_06028834(SH2Context& c) {
    ran[545] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06028834 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06028836 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06028838 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0602883A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0602883C mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0602883E mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06028840 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06028842 sts.l pr,@-r15
    c.r[15] -= 8;  // 06028844 add #-8,r15
    c.r[14] = c.r[15];  // 06028846 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06028848 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 0602884A mov.l r5,@(4,r14)
    c.r[10] = (uint32_t)(int32_t)(int16_t)c.r[6];  // 0602884C exts.w r6,r10
    c.r[1] = ld32(0x06028960u);  // 0602884E mov.l 0x06028960,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06028850 mov.b @r1,r1
    c.r[2] = c.r[10];  // 06028852 mov r10,r2
    c.r[2] += 8;  // 06028854 add #8,r2
    c.r[9] = c.r[1] & 0xFFu;  // 06028856 extu.b r1,r9
    c.r[1] = 0x8u;  // 06028858 mov #8,r1
    c.t = c.r[2] > c.r[1];  // 0602885A cmp/hi r1,r2
    { const bool k = c.t; c.r[11] = 0x0u; if (k) { goto L_0602891E; } }  // 0602885C bt/s 0x0602891E ; mov #0,r11
    c.r[1] = c.r[2];  // 06028860 mov r2,r1
    c.r[1] += c.r[1];  // 06028862 add r1,r1
    c.r[0] = 0x06028870u;  // 06028864 mova 0x06028870,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06028866 mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 06028868 add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x06028882u: goto L_06028882; case 0x060288BAu: goto L_060288BA; case 0x06028A6Eu: goto L_06028A6E; case 0x060288F4u: goto L_060288F4; case 0x060288FAu: goto L_060288FA; case 0x06028900u: goto L_06028900; case 0x06028906u: goto L_06028906; case 0x06028912u: goto L_06028912; case 0x06028918u: goto L_06028918; default: sh2_call(c, x); return; } }  // 0602886A jmp @r0 ; nop
L_06028882:
    c.r[1] = c.r[9];  // 06028882 mov r9,r1
    c.r[3] = ld32(c.r[14]);  // 06028884 mov.l @r14,r3
    c.r[1] <<= 2;  // 06028886 shll2 r1
    c.r[1] <<= 2;  // 06028888 shll2 r1
    c.r[0] = ld32(c.r[14]);  // 0602888A mov.l @r14,r0
    c.r[3] += c.r[1];  // 0602888C add r1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0602888E mov.b @(r0,r1),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0602895Cu);  // 06028890 mov.w 0x0602895C,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06028892 extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 06028894 cmp/eq r2,r1
    { const bool k = !c.t; c.r[0] = c.r[11]; if (k) { goto L_0602889E; } }  // 06028896 bf/s 0x0602889E ; mov r11,r0
    goto L_06028A70;  // 0602889A bra 0x06028A70 ; nop
L_0602889E:
    c.r[3] += 7;  // 0602889E add #7,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060288A0 mov.b @r3,r1
    c.r[0] = c.r[1];  // 060288A2 mov r1,r0
    c.r[0] >>= 2;  // 060288A4 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060288A6 shlr r0
    c.r[0] &= 0x1u;  // 060288A8 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060288AA tst r0,r0
    { const bool k = c.t; c.r[0] = ld32(c.r[14] + 4); if (k) { goto L_060288B4; } }  // 060288AC bt/s 0x060288B4 ; mov.l @(4,r14),r0
    goto L_06028A6E;  // 060288B0 bra 0x06028A6E ; nop
L_060288B4:
    st8(c.r[0] + c.r[11], c.r[9]);  // 060288B4 mov.b r9,@(r0,r11)
    c.r[11] += 1; goto L_06028A6E;  // 060288B6 bra 0x06028A6E ; add #1,r11
L_060288BA:
    c.r[1] = c.r[9];  // 060288BA mov r9,r1
    c.r[3] = ld32(c.r[14]);  // 060288BC mov.l @r14,r3
    c.r[1] <<= 2;  // 060288BE shll2 r1
    c.r[1] <<= 2;  // 060288C0 shll2 r1
    c.r[0] = ld32(c.r[14]);  // 060288C2 mov.l @r14,r0
    c.r[3] += c.r[1];  // 060288C4 add r1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060288C6 mov.b @(r0,r1),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0602895Cu);  // 060288C8 mov.w 0x0602895C,r2
    c.r[1] = c.r[1] & 0xFFu;  // 060288CA extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 060288CC cmp/eq r2,r1
    { const bool k = !c.t; c.r[0] = c.r[11]; if (k) { goto L_060288D6; } }  // 060288CE bf/s 0x060288D6 ; mov r11,r0
    goto L_06028A70;  // 060288D2 bra 0x06028A70 ; nop
L_060288D6:
    c.r[2] = ld32(c.r[3] + 4);  // 060288D6 mov.l @(4,r3),r2
    c.r[1] = ld32(0x06028964u);  // 060288D8 mov.l 0x06028964,r1
    c.r[2] &= c.r[1];  // 060288DA and r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 060288DC tst r2,r2
    { const bool k = c.t; c.r[3] += 4; if (k) { goto L_060288E6; } }  // 060288DE bt/s 0x060288E6 ; add #4,r3
    goto L_06028A70;  // 060288E2 bra 0x06028A70 ; nop
L_060288E6:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060288E6 mov.b @r3,r1
    c.r[0] = 0xFu;  // 060288E8 mov #15,r0
    c.r[10] = 0xFFFFFFFFu;  // 060288EA mov #-1,r10
    c.r[13] = c.r[1];  // 060288EC mov r1,r13
    c.t = c.r[13] & 1; c.r[13] >>= 1;  // 060288EE shlr r13
    c.r[13] &= c.r[0]; goto L_06028920;  // 060288F0 bra 0x06028920 ; and r0,r13
L_060288F4:
    c.r[13] = 0x1u;  // 060288F4 mov #1,r13
    c.r[10] = 0xFFFFFFFFu; goto L_06028920;  // 060288F6 bra 0x06028920 ; mov #-1,r10
L_060288FA:
    c.r[13] = 0x2u;  // 060288FA mov #2,r13
    c.r[10] = 0xFFFFFFFFu; goto L_06028920;  // 060288FC bra 0x06028920 ; mov #-1,r10
L_06028900:
    c.r[13] = 0x4u;  // 06028900 mov #4,r13
    c.r[10] = 0xFFFFFFFFu; goto L_06028920;  // 06028902 bra 0x06028920 ; mov #-1,r10
L_06028906:
    c.r[1] = ld32(0x06028968u);  // 06028906 mov.l 0x06028968,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06028908 mov.b @r1,r1
    c.r[0] = ld32(c.r[14] + 4);  // 0602890A mov.l @(4,r14),r0
    st8(c.r[0], c.r[1]);  // 0602890C mov.b r1,@r0
    c.r[0] = 0x1u; goto L_06028A70;  // 0602890E bra 0x06028A70 ; mov #1,r0
L_06028912:
    c.r[1] = ld32(0x0602896Cu);  // 06028912 mov.l 0x0602896C,r1
    c.r[10] = (uint32_t)(int16_t)ld16(c.r[1]); goto L_0602891E;  // 06028914 bra 0x0602891E ; mov.w @r1,r10
L_06028918:
    c.r[13] = 0x7u;  // 06028918 mov #7,r13
    c.r[10] = 0xFFFFFFFFu; goto L_06028920;  // 0602891A bra 0x06028920 ; mov #-1,r10
L_0602891E:
    c.r[13] = 0x7u;  // 0602891E mov #7,r13
L_06028920:
    c.t = (c.r[7] & c.r[7]) == 0;  // 06028920 tst r7,r7
    { const bool k = !c.t; c.t = (int32_t)c.r[10] > 0; if (k) { goto L_06028A00; } }  // 06028922 bf/s 0x06028A00 ; cmp/pl r10
    { const bool k = !c.t; c.r[9] = 0x0u; if (k) { goto L_0602897C; } }  // 06028926 bf/s 0x0602897C ; mov #0,r9
    c.r[0] = ld32(0x06028970u);  // 0602892A mov.l 0x06028970,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06028930u; c.r[4] = c.r[10] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06028930u) return; }  // 0602892C jsr @r0 ; extu.w r10,r4
    c.r[1] = c.r[0];  // 06028930 mov r0,r1
    c.r[0] = ld32(0x06028974u);  // 06028932 mov.l 0x06028974,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06028938u; c.r[4] = c.r[1] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06028938u) return; }  // 06028934 jsr @r0 ; extu.b r1,r4
    c.r[1] = c.r[0];  // 06028938 mov r0,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0602893A extu.b r1,r2
    c.r[1] = ld32(0x06028978u);  // 0602893C mov.l 0x06028978,r1
    c.r[3] = ld32(c.r[1]);  // 0602893E mov.l @r1,r3
    c.r[1] = c.r[2];  // 06028940 mov r2,r1
    c.r[1] += c.r[1];  // 06028942 add r1,r1
    c.r[1] += c.r[2];  // 06028944 add r2,r1
    c.r[1] <<= 2;  // 06028946 shll2 r1
    c.r[0] = c.r[1];  // 06028948 mov r1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602895Cu);  // 0602894A mov.w 0x0602895C,r1
    c.t = c.r[2] == c.r[1];  // 0602894C cmp/eq r1,r2
    { const bool k = c.t; c.r[10] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]); if (k) { goto L_06028958; } }  // 0602894E bt/s 0x06028958 ; mov.w @(r0,r3),r10
    c.t = (c.r[10] & c.r[10]) == 0;  // 06028952 tst r10,r10
    { const bool k = !c.t; c.r[9] = 0x0u; if (k) { goto L_0602897C; } }  // 06028954 bf/s 0x0602897C ; mov #0,r9
L_06028958:
    c.r[0] = 0x0u; goto L_06028A70;  // 06028958 bra 0x06028A70 ; mov #0,r0
L_0602897C:
    c.r[8] = ld32(c.r[14]);  // 0602897C mov.l @r14,r8
    c.r[12] = 0x0u;  // 0602897E mov #0,r12
L_06028980:
    c.r[0] = ld32(c.r[14]);  // 06028980 mov.l @r14,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[12]);  // 06028982 mov.b @(r0,r12),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06028A86u);  // 06028984 mov.w 0x06028A86,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06028986 extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 06028988 cmp/eq r2,r1
    if (c.t) { goto L_060289F0; }  // 0602898A bt 0x060289F0
    c.r[2] = ld32(c.r[8] + 4);  // 0602898C mov.l @(4,r8),r2
    c.r[1] = ld32(0x06028A88u);  // 0602898E mov.l 0x06028A88,r1
    c.r[2] &= c.r[1];  // 06028990 and r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06028992 tst r2,r2
    { const bool k = !c.t; c.r[1] = c.r[8]; if (k) { goto L_060289F0; } }  // 06028994 bf/s 0x060289F0 ; mov r8,r1
    c.r[1] += 3;  // 06028998 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602899A mov.b @r1,r1
    c.r[0] = 0x3u;  // 0602899C mov #3,r0
    c.r[4] = c.r[13];  // 0602899E mov r13,r4
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060289A0 shlr r1
    c.r[1] &= c.r[0];  // 060289A2 and r0,r1
    c.r[0] = ld32(0x06028A8Cu);  // 060289A4 mov.l 0x06028A8C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060289AAu; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060289AAu) return; }  // 060289A6 jsr @r0 ; mov r1,r5
    c.r[1] = c.r[0];  // 060289AA mov r0,r1
    c.r[0] = 0x1u;  // 060289AC mov #1,r0
    c.r[1] &= c.r[0];  // 060289AE and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060289B0 tst r1,r1
    { const bool k = c.t; c.r[0] = c.r[10]; if (k) { goto L_060289F0; } }  // 060289B2 bt/s 0x060289F0 ; mov r10,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 060289B6 cmp/eq #-1,r0
    { const bool k = c.t; c.r[0] = ld32(c.r[14] + 4); if (k) { goto L_060289EC; } }  // 060289B8 bt/s 0x060289EC ; mov.l @(4,r14),r0
    c.r[1] = c.r[8];  // 060289BC mov r8,r1
    c.r[1] += 2;  // 060289BE add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060289C0 mov.b @r1,r2
    c.r[1] = ld32(0x06028A90u);  // 060289C2 mov.l 0x06028A90,r1
    c.r[3] = ld32(c.r[1]);  // 060289C4 mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 060289C6 extu.b r2,r2
    c.r[1] = 0x1Eu;  // 060289C8 mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 060289CA mul.l r1,r2
    c.r[1] = c.macl;  // 060289CC sts macl,r1
    c.r[1] += c.r[3];  // 060289CE add r3,r1
    c.r[1] += 15;  // 060289D0 add #15,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060289D2 mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 060289D4 extu.b r2,r2
    c.r[1] = ld32(0x06028A94u);  // 060289D6 mov.l 0x06028A94,r1
    c.r[0] = c.r[2];  // 060289D8 mov r2,r0
    c.r[0] += c.r[0];  // 060289DA add r0,r0
    c.r[0] += c.r[2];  // 060289DC add r2,r0
    c.r[1] = ld32(c.r[1]);  // 060289DE mov.l @r1,r1
    c.r[0] <<= 2;  // 060289E0 shll2 r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 060289E2 mov.w @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 060289E4 extu.w r1,r1
    c.t = c.r[10] == c.r[1];  // 060289E6 cmp/eq r1,r10
    { const bool k = !c.t; c.r[0] = ld32(c.r[14] + 4); if (k) { goto L_060289F0; } }  // 060289E8 bf/s 0x060289F0 ; mov.l @(4,r14),r0
L_060289EC:
    st8(c.r[0] + c.r[11], c.r[9]);  // 060289EC mov.b r9,@(r0,r11)
    c.r[11] += 1;  // 060289EE add #1,r11
L_060289F0:
    c.r[8] += 16;  // 060289F0 add #16,r8
    c.r[9] += 1;  // 060289F2 add #1,r9
    c.r[1] = 0x49u;  // 060289F4 mov #73,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 060289F6 cmp/gt r1,r9
    { const bool k = !c.t; c.r[12] += 16; if (k) { SH2_POLL(c); goto L_06028980; } }  // 060289F8 bf/s 0x06028980 ; add #16,r12
    c.r[0] = c.r[11]; goto L_06028A70;  // 060289FC bra 0x06028A70 ; mov r11,r0
L_06028A00:
    c.r[9] = 0x0u;  // 06028A00 mov #0,r9
    c.r[8] = ld32(c.r[14]);  // 06028A02 mov.l @r14,r8
    c.r[12] = 0x0u;  // 06028A04 mov #0,r12
L_06028A06:
    c.r[0] = ld32(c.r[14]);  // 06028A06 mov.l @r14,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[12]);  // 06028A08 mov.b @(r0,r12),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06028A86u);  // 06028A0A mov.w 0x06028A86,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06028A0C extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 06028A0E cmp/eq r2,r1
    if (c.t) { goto L_06028A62; }  // 06028A10 bt 0x06028A62
    c.r[2] = ld32(c.r[8] + 4);  // 06028A12 mov.l @(4,r8),r2
    c.r[1] = ld32(0x06028A98u);  // 06028A14 mov.l 0x06028A98,r1
    c.r[2] &= c.r[1];  // 06028A16 and r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06028A18 tst r2,r2
    { const bool k = !c.t; c.r[1] = c.r[8]; if (k) { goto L_06028A62; } }  // 06028A1A bf/s 0x06028A62 ; mov r8,r1
    c.r[1] += 3;  // 06028A1E add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06028A20 mov.b @r1,r1
    c.r[0] = 0x3u;  // 06028A22 mov #3,r0
    c.r[4] = c.r[13];  // 06028A24 mov r13,r4
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06028A26 shlr r1
    c.r[1] &= c.r[0];  // 06028A28 and r0,r1
    c.r[0] = ld32(0x06028A8Cu);  // 06028A2A mov.l 0x06028A8C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06028A30u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06028A30u) return; }  // 06028A2C jsr @r0 ; mov r1,r5
    c.r[1] = c.r[0];  // 06028A30 mov r0,r1
    c.r[0] = 0x1u;  // 06028A32 mov #1,r0
    c.r[1] &= c.r[0];  // 06028A34 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06028A36 tst r1,r1
    { const bool k = c.t; c.r[0] = c.r[10]; if (k) { goto L_06028A62; } }  // 06028A38 bt/s 0x06028A62 ; mov r10,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 06028A3C cmp/eq #-1,r0
    { const bool k = c.t; c.r[0] = ld32(c.r[14] + 4); if (k) { goto L_06028A5E; } }  // 06028A3E bt/s 0x06028A5E ; mov.l @(4,r14),r0
    c.r[1] = c.r[8];  // 06028A42 mov r8,r1
    c.r[1] += 2;  // 06028A44 add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06028A46 mov.b @r1,r2
    c.r[1] = ld32(0x06028A90u);  // 06028A48 mov.l 0x06028A90,r1
    c.r[3] = ld32(c.r[1]);  // 06028A4A mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06028A4C extu.b r2,r2
    c.r[1] = 0x1Eu;  // 06028A4E mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 06028A50 mul.l r1,r2
    c.r[0] = c.macl;  // 06028A52 sts macl,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 06028A54 mov.w @(r0,r3),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06028A56 extu.w r1,r1
    c.t = c.r[10] == c.r[1];  // 06028A58 cmp/eq r1,r10
    { const bool k = !c.t; c.r[0] = ld32(c.r[14] + 4); if (k) { goto L_06028A62; } }  // 06028A5A bf/s 0x06028A62 ; mov.l @(4,r14),r0
L_06028A5E:
    st8(c.r[0] + c.r[11], c.r[9]);  // 06028A5E mov.b r9,@(r0,r11)
    c.r[11] += 1;  // 06028A60 add #1,r11
L_06028A62:
    c.r[8] += 16;  // 06028A62 add #16,r8
    c.r[9] += 1;  // 06028A64 add #1,r9
    c.r[1] = 0x49u;  // 06028A66 mov #73,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 06028A68 cmp/gt r1,r9
    { const bool k = !c.t; c.r[12] += 16; if (k) { SH2_POLL(c); goto L_06028A06; } }  // 06028A6A bf/s 0x06028A06 ; add #16,r12
L_06028A6E:
    c.r[0] = c.r[11];  // 06028A6E mov r11,r0
L_06028A70:
    c.r[14] += 8;  // 06028A70 add #8,r14
    c.r[15] = c.r[14];  // 06028A72 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06028A74 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06028A76 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06028A78 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06028A7A mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06028A7C mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06028A7E mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06028A80 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06028A82 rts ; mov.l @r15+,r8
}

void f_06028A9C(SH2Context& c) {
    ran[546] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06028A9C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06028A9E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06028AA0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06028AA2 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06028AA4 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06028AA6 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06028AA8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06028AAA sts.l pr,@-r15
    c.r[15] -= 8;  // 06028AAC add #-8,r15
    c.r[14] = c.r[15];  // 06028AAE mov r15,r14
    st32(c.r[14], c.r[4]);  // 06028AB0 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[6]);  // 06028AB2 mov.l r6,@(4,r14)
    c.r[9] = (uint32_t)(int32_t)(int16_t)c.r[5];  // 06028AB4 exts.w r5,r9
    c.r[1] = ld32(0x06028C00u);  // 06028AB6 mov.l 0x06028C00,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06028AB8 mov.b @r1,r1
    c.r[2] = c.r[9];  // 06028ABA mov r9,r2
    c.r[2] += 8;  // 06028ABC add #8,r2
    c.r[11] = c.r[1] & 0xFFu;  // 06028ABE extu.b r1,r11
    c.r[1] = 0x8u;  // 06028AC0 mov #8,r1
    c.t = c.r[2] > c.r[1];  // 06028AC2 cmp/hi r1,r2
    { const bool k = c.t; c.r[12] = 0x0u; if (k) { goto L_06028BC4; } }  // 06028AC4 bt/s 0x06028BC4 ; mov #0,r12
    c.r[1] = c.r[2];  // 06028AC8 mov r2,r1
    c.r[1] += c.r[1];  // 06028ACA add r1,r1
    c.r[0] = 0x06028AD8u;  // 06028ACC mova 0x06028AD8,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06028ACE mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 06028AD0 add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x06028AEAu: goto L_06028AEA; case 0x06028B26u: goto L_06028B26; case 0x06028B64u: goto L_06028B64; case 0x06028B9Au: goto L_06028B9A; case 0x06028BA0u: goto L_06028BA0; case 0x06028BA6u: goto L_06028BA6; case 0x06028BACu: goto L_06028BAC; case 0x06028BB8u: goto L_06028BB8; case 0x06028BBEu: goto L_06028BBE; default: sh2_call(c, x); return; } }  // 06028AD2 jmp @r0 ; nop
L_06028AEA:
    c.r[1] = ld32(0x06028C04u);  // 06028AEA mov.l 0x06028C04,r1
    c.r[2] = ld32(c.r[1]);  // 06028AEC mov.l @r1,r2
    c.r[1] = c.r[11];  // 06028AEE mov r11,r1
    c.r[1] <<= 2;  // 06028AF0 shll2 r1
    c.r[1] <<= 2;  // 06028AF2 shll2 r1
    c.r[3] = c.r[1];  // 06028AF4 mov r1,r3
    c.r[0] = c.r[1];  // 06028AF6 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06028AF8 mov.b @(r0,r2),r1
    c.r[3] += c.r[2];  // 06028AFA add r2,r3
    c.r[1] = c.r[1] & 0xFFu;  // 06028AFC extu.b r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06028BFEu);  // 06028AFE mov.w 0x06028BFE,r2
    c.t = c.r[1] == c.r[2];  // 06028B00 cmp/eq r2,r1
    { const bool k = !c.t; c.r[0] = c.r[12]; if (k) { goto L_06028B0A; } }  // 06028B02 bf/s 0x06028B0A ; mov r12,r0
    goto L_06028CB0;  // 06028B06 bra 0x06028CB0 ; nop
L_06028B0A:
    c.r[3] += 7;  // 06028B0A add #7,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06028B0C mov.b @r3,r1
    c.r[0] = c.r[1];  // 06028B0E mov r1,r0
    c.r[0] >>= 2;  // 06028B10 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06028B12 shlr r0
    c.r[0] &= 0x1u;  // 06028B14 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06028B16 tst r0,r0
    { const bool k = c.t; c.r[0] = ld32(c.r[14]); if (k) { goto L_06028B20; } }  // 06028B18 bt/s 0x06028B20 ; mov.l @r14,r0
    goto L_06028CAE;  // 06028B1C bra 0x06028CAE ; nop
L_06028B20:
    st8(c.r[0] + c.r[12], c.r[11]);  // 06028B20 mov.b r11,@(r0,r12)
    c.r[12] += 1; goto L_06028CAE;  // 06028B22 bra 0x06028CAE ; add #1,r12
L_06028B26:
    c.r[1] = ld32(0x06028C04u);  // 06028B26 mov.l 0x06028C04,r1
    c.r[2] = ld32(c.r[1]);  // 06028B28 mov.l @r1,r2
    c.r[1] = c.r[11];  // 06028B2A mov r11,r1
    c.r[1] <<= 2;  // 06028B2C shll2 r1
    c.r[1] <<= 2;  // 06028B2E shll2 r1
    c.r[3] = c.r[1];  // 06028B30 mov r1,r3
    c.r[0] = c.r[1];  // 06028B32 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06028B34 mov.b @(r0,r2),r1
    c.r[3] += c.r[2];  // 06028B36 add r2,r3
    c.r[1] = c.r[1] & 0xFFu;  // 06028B38 extu.b r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06028BFEu);  // 06028B3A mov.w 0x06028BFE,r2
    c.t = c.r[1] == c.r[2];  // 06028B3C cmp/eq r2,r1
    { const bool k = !c.t; c.r[0] = c.r[12]; if (k) { goto L_06028B46; } }  // 06028B3E bf/s 0x06028B46 ; mov r12,r0
    goto L_06028CB0;  // 06028B42 bra 0x06028CB0 ; nop
L_06028B46:
    c.r[2] = ld32(c.r[3] + 4);  // 06028B46 mov.l @(4,r3),r2
    c.r[1] = ld32(0x06028C08u);  // 06028B48 mov.l 0x06028C08,r1
    c.r[2] &= c.r[1];  // 06028B4A and r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06028B4C tst r2,r2
    { const bool k = c.t; c.r[3] += 4; if (k) { goto L_06028B56; } }  // 06028B4E bt/s 0x06028B56 ; add #4,r3
    goto L_06028CB0;  // 06028B52 bra 0x06028CB0 ; nop
L_06028B56:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06028B56 mov.b @r3,r1
    c.r[0] = 0xFu;  // 06028B58 mov #15,r0
    c.r[9] = 0xFFFFFFFFu;  // 06028B5A mov #-1,r9
    c.r[13] = c.r[1];  // 06028B5C mov r1,r13
    c.t = c.r[13] & 1; c.r[13] >>= 1;  // 06028B5E shlr r13
    c.r[13] &= c.r[0]; goto L_06028BC6;  // 06028B60 bra 0x06028BC6 ; and r0,r13
L_06028B64:
    c.r[1] = ld32(0x06028C04u);  // 06028B64 mov.l 0x06028C04,r1
    c.r[2] = ld32(c.r[1]);  // 06028B66 mov.l @r1,r2
    c.r[1] = c.r[11];  // 06028B68 mov r11,r1
    c.r[1] <<= 2;  // 06028B6A shll2 r1
    c.r[1] <<= 2;  // 06028B6C shll2 r1
    c.r[3] = c.r[1];  // 06028B6E mov r1,r3
    c.r[0] = c.r[1];  // 06028B70 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06028B72 mov.b @(r0,r2),r1
    c.r[3] += c.r[2];  // 06028B74 add r2,r3
    c.r[1] = c.r[1] & 0xFFu;  // 06028B76 extu.b r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06028BFEu);  // 06028B78 mov.w 0x06028BFE,r2
    c.t = c.r[1] == c.r[2];  // 06028B7A cmp/eq r2,r1
    { const bool k = !c.t; c.r[0] = c.r[12]; if (k) { goto L_06028B84; } }  // 06028B7C bf/s 0x06028B84 ; mov r12,r0
    goto L_06028CB0;  // 06028B80 bra 0x06028CB0 ; nop
L_06028B84:
    c.r[2] = ld32(c.r[3] + 4);  // 06028B84 mov.l @(4,r3),r2
    c.r[1] = ld32(0x06028C08u);  // 06028B86 mov.l 0x06028C08,r1
    c.r[2] &= c.r[1];  // 06028B88 and r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06028B8A tst r2,r2
    { const bool k = c.t; c.r[0] = ld32(c.r[14]); if (k) { goto L_06028B94; } }  // 06028B8C bt/s 0x06028B94 ; mov.l @r14,r0
    goto L_06028CAE;  // 06028B90 bra 0x06028CAE ; nop
L_06028B94:
    st8(c.r[0] + c.r[12], c.r[11]);  // 06028B94 mov.b r11,@(r0,r12)
    c.r[12] += 1; goto L_06028CAE;  // 06028B96 bra 0x06028CAE ; add #1,r12
L_06028B9A:
    c.r[13] = 0x1u;  // 06028B9A mov #1,r13
    c.r[9] = 0xFFFFFFFFu; goto L_06028BC6;  // 06028B9C bra 0x06028BC6 ; mov #-1,r9
L_06028BA0:
    c.r[13] = 0x2u;  // 06028BA0 mov #2,r13
    c.r[9] = 0xFFFFFFFFu; goto L_06028BC6;  // 06028BA2 bra 0x06028BC6 ; mov #-1,r9
L_06028BA6:
    c.r[13] = 0x4u;  // 06028BA6 mov #4,r13
    c.r[9] = 0xFFFFFFFFu; goto L_06028BC6;  // 06028BA8 bra 0x06028BC6 ; mov #-1,r9
L_06028BAC:
    c.r[1] = ld32(0x06028C0Cu);  // 06028BAC mov.l 0x06028C0C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06028BAE mov.b @r1,r1
    c.r[0] = ld32(c.r[14]);  // 06028BB0 mov.l @r14,r0
    st8(c.r[0], c.r[1]);  // 06028BB2 mov.b r1,@r0
    c.r[0] = 0x1u; goto L_06028CB0;  // 06028BB4 bra 0x06028CB0 ; mov #1,r0
L_06028BB8:
    c.r[1] = ld32(0x06028C10u);  // 06028BB8 mov.l 0x06028C10,r1
    c.r[9] = (uint32_t)(int16_t)ld16(c.r[1]); goto L_06028BC4;  // 06028BBA bra 0x06028BC4 ; mov.w @r1,r9
L_06028BBE:
    c.r[13] = 0x7u;  // 06028BBE mov #7,r13
    c.r[9] = 0xFFFFFFFFu; goto L_06028BC6;  // 06028BC0 bra 0x06028BC6 ; mov #-1,r9
L_06028BC4:
    c.r[13] = 0x7u;  // 06028BC4 mov #7,r13
L_06028BC6:
    c.t = (int32_t)c.r[9] > 0;  // 06028BC6 cmp/pl r9
    { const bool k = !c.t; c.r[11] = 0x0u; if (k) { goto L_06028C20; } }  // 06028BC8 bf/s 0x06028C20 ; mov #0,r11
    c.r[0] = ld32(0x06028C14u);  // 06028BCC mov.l 0x06028C14,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06028BD2u; c.r[4] = c.r[9] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06028BD2u) return; }  // 06028BCE jsr @r0 ; extu.w r9,r4
    c.r[1] = c.r[0];  // 06028BD2 mov r0,r1
    c.r[0] = ld32(0x06028C18u);  // 06028BD4 mov.l 0x06028C18,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06028BDAu; c.r[4] = c.r[1] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06028BDAu) return; }  // 06028BD6 jsr @r0 ; extu.b r1,r4
    c.r[1] = c.r[0];  // 06028BDA mov r0,r1
    c.r[2] = c.r[1] & 0xFFu;  // 06028BDC extu.b r1,r2
    c.r[1] = ld32(0x06028C1Cu);  // 06028BDE mov.l 0x06028C1C,r1
    c.r[3] = ld32(c.r[1]);  // 06028BE0 mov.l @r1,r3
    c.r[1] = c.r[2];  // 06028BE2 mov r2,r1
    c.r[1] += c.r[1];  // 06028BE4 add r1,r1
    c.r[1] += c.r[2];  // 06028BE6 add r2,r1
    c.r[1] <<= 2;  // 06028BE8 shll2 r1
    c.r[0] = c.r[1];  // 06028BEA mov r1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06028BFEu);  // 06028BEC mov.w 0x06028BFE,r1
    c.t = c.r[2] == c.r[1];  // 06028BEE cmp/eq r1,r2
    { const bool k = c.t; c.r[9] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]); if (k) { goto L_06028BFA; } }  // 06028BF0 bt/s 0x06028BFA ; mov.w @(r0,r3),r9
    c.t = (c.r[9] & c.r[9]) == 0;  // 06028BF4 tst r9,r9
    { const bool k = !c.t; c.r[11] = 0x0u; if (k) { goto L_06028C20; } }  // 06028BF6 bf/s 0x06028C20 ; mov #0,r11
L_06028BFA:
    c.r[0] = 0x0u; goto L_06028CB0;  // 06028BFA bra 0x06028CB0 ; mov #0,r0
L_06028C20:
    c.r[10] = 0x0u;  // 06028C20 mov #0,r10
L_06028C22:
    c.r[1] = ld32(0x06028CC8u);  // 06028C22 mov.l 0x06028CC8,r1
    c.r[8] = c.r[10];  // 06028C24 mov r10,r8
    c.r[0] = ld32(c.r[1]);  // 06028C26 mov.l @r1,r0
    c.r[2] = (uint32_t)(int16_t)ld16(0x06028CC6u);  // 06028C28 mov.w 0x06028CC6,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 06028C2A mov.b @(r0,r10),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06028C2C extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 06028C2E cmp/eq r2,r1
    { const bool k = c.t; c.r[8] += c.r[0]; if (k) { goto L_06028CA4; } }  // 06028C30 bt/s 0x06028CA4 ; add r0,r8
    c.r[0] = ld32(c.r[14] + 4);  // 06028C34 mov.l @(4,r14),r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06028C36 tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[8]; if (k) { goto L_06028C4C; } }  // 06028C38 bf/s 0x06028C4C ; mov r8,r1
    c.r[1] += 7;  // 06028C3C add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06028C3E mov.b @r1,r1
    c.r[0] = c.r[1];  // 06028C40 mov r1,r0
    c.r[0] >>= 2;  // 06028C42 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06028C44 shlr r0
    c.r[0] &= 0x1u;  // 06028C46 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06028C48 tst r0,r0
    if (!c.t) { goto L_06028CA4; }  // 06028C4A bf 0x06028CA4
L_06028C4C:
    c.r[1] = c.r[8];  // 06028C4C mov r8,r1
    c.r[1] += 3;  // 06028C4E add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06028C50 mov.b @r1,r1
    c.r[0] = 0x3u;  // 06028C52 mov #3,r0
    c.r[4] = c.r[13];  // 06028C54 mov r13,r4
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06028C56 shlr r1
    c.r[1] &= c.r[0];  // 06028C58 and r0,r1
    c.r[0] = ld32(0x06028CCCu);  // 06028C5A mov.l 0x06028CCC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06028C60u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06028C60u) return; }  // 06028C5C jsr @r0 ; mov r1,r5
    c.r[1] = c.r[0];  // 06028C60 mov r0,r1
    c.r[0] = 0x1u;  // 06028C62 mov #1,r0
    c.r[1] &= c.r[0];  // 06028C64 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06028C66 tst r1,r1
    { const bool k = c.t; c.r[0] = c.r[9]; if (k) { goto L_06028CA4; } }  // 06028C68 bt/s 0x06028CA4 ; mov r9,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 06028C6C cmp/eq #-1,r0
    { const bool k = c.t; c.r[0] = ld32(c.r[14]); if (k) { goto L_06028CA0; } }  // 06028C6E bt/s 0x06028CA0 ; mov.l @r14,r0
    c.r[8] += 2;  // 06028C72 add #2,r8
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06028C74 mov.b @r8,r2
    c.r[1] = ld32(0x06028CD0u);  // 06028C76 mov.l 0x06028CD0,r1
    c.r[3] = ld32(c.r[1]);  // 06028C78 mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06028C7A extu.b r2,r2
    c.r[1] = 0x1Eu;  // 06028C7C mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 06028C7E mul.l r1,r2
    c.r[1] = c.macl;  // 06028C80 sts macl,r1
    c.r[1] += c.r[3];  // 06028C82 add r3,r1
    c.r[1] += 15;  // 06028C84 add #15,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06028C86 mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 06028C88 extu.b r2,r2
    c.r[1] = ld32(0x06028CD4u);  // 06028C8A mov.l 0x06028CD4,r1
    c.r[0] = c.r[2];  // 06028C8C mov r2,r0
    c.r[0] += c.r[0];  // 06028C8E add r0,r0
    c.r[0] += c.r[2];  // 06028C90 add r2,r0
    c.r[1] = ld32(c.r[1]);  // 06028C92 mov.l @r1,r1
    c.r[0] <<= 2;  // 06028C94 shll2 r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06028C96 mov.w @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06028C98 extu.w r1,r1
    c.t = c.r[9] == c.r[1];  // 06028C9A cmp/eq r1,r9
    { const bool k = !c.t; c.r[0] = ld32(c.r[14]); if (k) { goto L_06028CA4; } }  // 06028C9C bf/s 0x06028CA4 ; mov.l @r14,r0
L_06028CA0:
    st8(c.r[0] + c.r[12], c.r[11]);  // 06028CA0 mov.b r11,@(r0,r12)
    c.r[12] += 1;  // 06028CA2 add #1,r12
L_06028CA4:
    c.r[11] += 1;  // 06028CA4 add #1,r11
    c.r[1] = 0x49u;  // 06028CA6 mov #73,r1
    c.t = (int32_t)c.r[11] > (int32_t)c.r[1];  // 06028CA8 cmp/gt r1,r11
    { const bool k = !c.t; c.r[10] += 16; if (k) { SH2_POLL(c); goto L_06028C22; } }  // 06028CAA bf/s 0x06028C22 ; add #16,r10
L_06028CAE:
    c.r[0] = c.r[12];  // 06028CAE mov r12,r0
L_06028CB0:
    c.r[14] += 8;  // 06028CB0 add #8,r14
    c.r[15] = c.r[14];  // 06028CB2 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06028CB4 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06028CB6 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06028CB8 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06028CBA mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06028CBC mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06028CBE mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06028CC0 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06028CC2 rts ; mov.l @r15+,r8
}

void f_06028CD8(SH2Context& c) {
    ran[547] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06028CD8 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06028CDA mov r15,r14
    c.r[4] = c.r[4] & 0xFFu;  // 06028CDC extu.b r4,r4
    c.r[5] = c.r[5] & 0xFFu;  // 06028CDE extu.b r5,r5
    c.r[2] = 0x0u;  // 06028CE0 mov #0,r2
    c.r[1] = ld32(0x06028D38u);  // 06028CE2 mov.l 0x06028D38,r1
    c.r[6] = ld32(c.r[1]);  // 06028CE4 mov.l @r1,r6
    c.r[3] = c.r[2];  // 06028CE6 mov r2,r3
L_06028CE8:
    c.r[3] <<= 2;  // 06028CE8 shll2 r3
    c.r[3] <<= 2;  // 06028CEA shll2 r3
    c.r[7] = c.r[3];  // 06028CEC mov r3,r7
    c.r[7] += c.r[6];  // 06028CEE add r6,r7
    c.r[1] = c.r[7];  // 06028CF0 mov r7,r1
    c.r[1] += 7;  // 06028CF2 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06028CF4 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06028CF6 mov r1,r0
    c.r[0] >>= 2;  // 06028CF8 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06028CFA shlr r0
    c.r[0] &= 0x1u;  // 06028CFC and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06028CFE tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[2]; if (k) { goto L_06028D20; } }  // 06028D00 bf/s 0x06028D20 ; mov r2,r1
    c.r[0] = c.r[3];  // 06028D04 mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 06028D06 mov.b @(r0,r6),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06028D08 extu.b r1,r1
    c.t = c.r[1] == c.r[4];  // 06028D0A cmp/eq r4,r1
    { const bool k = !c.t; c.r[1] = c.r[2]; if (k) { goto L_06028D20; } }  // 06028D0C bf/s 0x06028D20 ; mov r2,r1
    c.r[7] += 1;  // 06028D10 add #1,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06028D12 mov.b @r7,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06028D14 extu.b r1,r1
    c.t = c.r[1] == c.r[5];  // 06028D16 cmp/eq r5,r1
    { const bool k = !c.t; c.r[1] = c.r[2]; if (k) { goto L_06028D20; } }  // 06028D18 bf/s 0x06028D20 ; mov r2,r1
    c.r[0] = c.r[2]; goto L_06028D2E;  // 06028D1C bra 0x06028D2E ; mov r2,r0
L_06028D20:
    c.r[1] += 1;  // 06028D20 add #1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 06028D22 extu.b r1,r2
    c.r[1] = 0x49u;  // 06028D24 mov #73,r1
    c.t = c.r[2] > c.r[1];  // 06028D26 cmp/hi r1,r2
    { const bool k = !c.t; c.r[3] = c.r[2]; if (k) { SH2_POLL(c); goto L_06028CE8; } }  // 06028D28 bf/s 0x06028CE8 ; mov r2,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x06028D34u);  // 06028D2C mov.w 0x06028D34,r0
L_06028D2E:
    c.r[15] = c.r[14];  // 06028D2E mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06028D30 rts ; mov.l @r15+,r14
}

void f_06028D3C(SH2Context& c) {
    ran[548] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06028D3C mov.l r14,@-r15
    c.r[4] = c.r[4] & 0xFFu;  // 06028D3E extu.b r4,r4
    c.r[2] = 0xFFFFFFFFu;  // 06028D40 mov #-1,r2
    c.r[1] = c.r[2] & 0xFFu;  // 06028D42 extu.b r2,r1
    c.t = c.r[4] == c.r[1];  // 06028D44 cmp/eq r1,r4
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06028D68; } }  // 06028D46 bt/s 0x06028D68 ; mov r15,r14
    c.r[5] = ld32(0x06028D70u);  // 06028D4A mov.l 0x06028D70,r5
    c.r[6] = c.r[2];  // 06028D4C mov r2,r6
    c.r[3] = 0x0u;  // 06028D4E mov #0,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x06028D6Eu);  // 06028D50 mov.w 0x06028D6E,r7
L_06028D52:
    c.r[2] = ld32(c.r[5]);  // 06028D52 mov.l @r5,r2
    c.r[2] += c.r[3];  // 06028D54 add r3,r2
    c.r[2] += 9;  // 06028D56 add #9,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06028D58 mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06028D5A extu.b r1,r1
    c.t = c.r[1] == c.r[4];  // 06028D5C cmp/eq r4,r1
    if (!c.t) { goto L_06028D62; }  // 06028D5E bf 0x06028D62
    st8(c.r[2], c.r[6]);  // 06028D60 mov.b r6,@r2
L_06028D62:
    c.r[3] += 16;  // 06028D62 add #16,r3
    c.t = (int32_t)c.r[3] > (int32_t)c.r[7];  // 06028D64 cmp/gt r7,r3
    if (!c.t) { SH2_POLL(c); goto L_06028D52; }  // 06028D66 bf 0x06028D52
L_06028D68:
    c.r[15] = c.r[14];  // 06028D68 mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06028D6A rts ; mov.l @r15+,r14
}

void f_06028D74(SH2Context& c) {
    ran[549] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06028D74 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06028D76 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06028D78 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06028D7A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06028D7C sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06028D7E mov r15,r14
    c.r[4] = c.r[4] & 0xFFFFu;  // 06028D80 extu.w r4,r4
    c.r[1] = c.r[4];  // 06028D82 mov r4,r1
    c.r[10] = c.r[5] & 0xFFFFu;  // 06028D84 extu.w r5,r10
    c.t = (c.r[6] & c.r[6]) == 0;  // 06028D86 tst r6,r6
    { const bool k = !c.t; c.r[2] = c.r[10]; if (k) { goto L_06028D9C; } }  // 06028D88 bf/s 0x06028D9C ; mov r10,r2
    c.r[8] = ld32(0x06028E7Cu);  // 06028D8C mov.l 0x06028E7C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06028D92u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06028D92u) return; }  // 06028D8E jsr @r8 ; nop
    c.r[9] = c.r[0] & 0xFFu;  // 06028D92 extu.b r0,r9
    { const uint32_t x = c.r[8]; c.pr = 0x06028D98u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06028D98u) return; }  // 06028D94 jsr @r8 ; mov r10,r4
    c.r[10] = c.r[0] & 0xFFu; goto L_06028DA0;  // 06028D98 bra 0x06028DA0 ; extu.b r0,r10
L_06028D9C:
    c.r[9] = c.r[1];  // 06028D9C mov r1,r9
    c.r[10] = c.r[2];  // 06028D9E mov r2,r10
L_06028DA0:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06028E7Au);  // 06028DA0 mov.w 0x06028E7A,r1
    c.t = c.r[9] == c.r[1];  // 06028DA2 cmp/eq r1,r9
    { const bool k = c.t; c.r[0] = 0xFFFFFFFFu; if (k) { goto L_06028E6C; } }  // 06028DA4 bt/s 0x06028E6C ; mov #-1,r0
    c.t = c.r[10] == c.r[1];  // 06028DA8 cmp/eq r1,r10
    if (c.t) { goto L_06028E6C; }  // 06028DAA bt 0x06028E6C
    c.r[8] = ld32(0x06028E80u);  // 06028DAC mov.l 0x06028E80,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06028DB2u; c.r[4] = c.r[9] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06028DB2u) return; }  // 06028DAE jsr @r8 ; extu.b r9,r4
    { const uint32_t x = c.r[8]; c.pr = 0x06028DB6u; c.r[4] = c.r[10] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06028DB6u) return; }  // 06028DB2 jsr @r8 ; extu.b r10,r4
    c.r[1] = ld32(0x06028E84u);  // 06028DB6 mov.l 0x06028E84,r1
    c.r[2] = ld32(c.r[1]);  // 06028DB8 mov.l @r1,r2
    c.r[1] = c.r[9];  // 06028DBA mov r9,r1
    c.r[1] <<= 2;  // 06028DBC shll2 r1
    c.r[1] <<= 2;  // 06028DBE shll2 r1
    c.r[3] = c.r[1];  // 06028DC0 mov r1,r3
    c.r[3] += c.r[2];  // 06028DC2 add r2,r3
    c.r[0] = c.r[1];  // 06028DC4 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06028DC6 mov.b @(r0,r2),r1
    c.r[3] += 1;  // 06028DC8 add #1,r3
    c.r[6] = c.r[1] & 0xFFu;  // 06028DCA extu.b r1,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06028DCC mov.b @r3,r1
    c.r[5] = c.r[1] & 0xFFu;  // 06028DCE extu.b r1,r5
    c.r[1] = c.r[10];  // 06028DD0 mov r10,r1
    c.r[1] <<= 2;  // 06028DD2 shll2 r1
    c.r[1] <<= 2;  // 06028DD4 shll2 r1
    c.r[3] = c.r[1];  // 06028DD6 mov r1,r3
    c.r[0] = c.r[1];  // 06028DD8 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06028DDA mov.b @(r0,r2),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06028DDC extu.b r1,r1
    c.t = c.r[6] == c.r[1];  // 06028DDE cmp/eq r1,r6
    { const bool k = !c.t; c.r[3] += c.r[2]; if (k) { goto L_06028DF4; } }  // 06028DE0 bf/s 0x06028DF4 ; add r2,r3
    c.r[2] = c.r[5];  // 06028DE4 mov r5,r2
    c.r[3] += 1;  // 06028DE6 add #1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06028DE8 mov.b @r3,r1
    c.r[2] -= 1;  // 06028DEA add #-1,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06028DEC extu.b r1,r1
    c.t = c.r[2] == c.r[1];  // 06028DEE cmp/eq r1,r2
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_06028E6C; } }  // 06028DF0 bt/s 0x06028E6C ; mov #0,r0
L_06028DF4:
    c.r[3] = c.r[6];  // 06028DF4 mov r6,r3
    c.r[1] = ld32(0x06028E84u);  // 06028DF6 mov.l 0x06028E84,r1
    c.r[2] = ld32(c.r[1]);  // 06028DF8 mov.l @r1,r2
    c.r[3] += 1;  // 06028DFA add #1,r3
    c.r[1] = c.r[10];  // 06028DFC mov r10,r1
    c.r[1] <<= 2;  // 06028DFE shll2 r1
    c.r[1] <<= 2;  // 06028E00 shll2 r1
    c.r[7] = c.r[1];  // 06028E02 mov r1,r7
    c.r[0] = c.r[1];  // 06028E04 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06028E06 mov.b @(r0,r2),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06028E08 extu.b r1,r1
    c.t = c.r[3] == c.r[1];  // 06028E0A cmp/eq r1,r3
    { const bool k = !c.t; c.r[7] += c.r[2]; if (k) { goto L_06028E1C; } }  // 06028E0C bf/s 0x06028E1C ; add r2,r7
    c.r[7] += 1;  // 06028E10 add #1,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06028E12 mov.b @r7,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06028E14 extu.b r1,r1
    c.t = c.r[5] == c.r[1];  // 06028E16 cmp/eq r1,r5
    { const bool k = c.t; c.r[0] = 0x1u; if (k) { goto L_06028E6C; } }  // 06028E18 bt/s 0x06028E6C ; mov #1,r0
L_06028E1C:
    c.r[1] = ld32(0x06028E84u);  // 06028E1C mov.l 0x06028E84,r1
    c.r[2] = ld32(c.r[1]);  // 06028E1E mov.l @r1,r2
    c.r[1] = c.r[10];  // 06028E20 mov r10,r1
    c.r[1] <<= 2;  // 06028E22 shll2 r1
    c.r[1] <<= 2;  // 06028E24 shll2 r1
    c.r[3] = c.r[1];  // 06028E26 mov r1,r3
    c.r[0] = c.r[1];  // 06028E28 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06028E2A mov.b @(r0,r2),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06028E2C extu.b r1,r1
    c.t = c.r[6] == c.r[1];  // 06028E2E cmp/eq r1,r6
    { const bool k = !c.t; c.r[3] += c.r[2]; if (k) { goto L_06028E44; } }  // 06028E30 bf/s 0x06028E44 ; add r2,r3
    c.r[2] = c.r[5];  // 06028E34 mov r5,r2
    c.r[3] += 1;  // 06028E36 add #1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06028E38 mov.b @r3,r1
    c.r[2] += 1;  // 06028E3A add #1,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06028E3C extu.b r1,r1
    c.t = c.r[2] == c.r[1];  // 06028E3E cmp/eq r1,r2
    { const bool k = c.t; c.r[0] = 0x2u; if (k) { goto L_06028E6C; } }  // 06028E40 bt/s 0x06028E6C ; mov #2,r0
L_06028E44:
    c.r[1] = ld32(0x06028E84u);  // 06028E44 mov.l 0x06028E84,r1
    c.r[2] = ld32(c.r[1]);  // 06028E46 mov.l @r1,r2
    c.r[6] -= 1;  // 06028E48 add #-1,r6
    c.r[1] = c.r[10];  // 06028E4A mov r10,r1
    c.r[1] <<= 2;  // 06028E4C shll2 r1
    c.r[1] <<= 2;  // 06028E4E shll2 r1
    c.r[3] = c.r[1];  // 06028E50 mov r1,r3
    c.r[0] = c.r[1];  // 06028E52 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06028E54 mov.b @(r0,r2),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06028E56 extu.b r1,r1
    c.t = c.r[6] == c.r[1];  // 06028E58 cmp/eq r1,r6
    { const bool k = !c.t; c.r[3] += c.r[2]; if (k) { goto L_06028E6A; } }  // 06028E5A bf/s 0x06028E6A ; add r2,r3
    c.r[3] += 1;  // 06028E5E add #1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06028E60 mov.b @r3,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06028E62 extu.b r1,r1
    c.t = c.r[5] == c.r[1];  // 06028E64 cmp/eq r1,r5
    { const bool k = c.t; c.r[0] = 0x3u; if (k) { goto L_06028E6C; } }  // 06028E66 bt/s 0x06028E6C ; mov #3,r0
L_06028E6A:
    c.r[0] = 0xFFFFFFFFu;  // 06028E6A mov #-1,r0
L_06028E6C:
    c.r[15] = c.r[14];  // 06028E6C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06028E6E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06028E70 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06028E72 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06028E74 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06028E76 rts ; mov.l @r15+,r8
}

void f_06028E88(SH2Context& c) {
    ran[550] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06028E88 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06028E8A sts.l pr,@-r15
    c.r[4] = c.r[4] & 0xFFu;  // 06028E8C extu.b r4,r4
    c.r[1] = ld32(0x06028EBCu);  // 06028E8E mov.l 0x06028EBC,r1
    c.r[2] = c.r[4];  // 06028E90 mov r4,r2
    c.r[2] += c.r[2];  // 06028E92 add r2,r2
    c.r[2] += c.r[4];  // 06028E94 add r4,r2
    c.r[1] = ld32(c.r[1]);  // 06028E96 mov.l @r1,r1
    c.r[2] <<= 2;  // 06028E98 shll2 r2
    c.r[2] += c.r[1];  // 06028E9A add r1,r2
    c.r[1] = ld32(0x06028EC0u);  // 06028E9C mov.l 0x06028EC0,r1
    c.r[1] = ld32(c.r[1]);  // 06028E9E mov.l @r1,r1
    c.r[14] = c.r[15];  // 06028EA0 mov r15,r14
    c.r[1] += 12;  // 06028EA2 add #12,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06028EA4 mov.w @r1,r1
    c.r[2] += 10;  // 06028EA6 add #10,r2
    st16(c.r[2], c.r[1]);  // 06028EA8 mov.w r1,@r2
    c.r[1] = ld32(0x06028EC4u);  // 06028EAA mov.l 0x06028EC4,r1
    c.r[4] = ld32(c.r[1]);  // 06028EAC mov.l @r1,r4
    c.r[1] = ld32(0x06028EC8u);  // 06028EAE mov.l 0x06028EC8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06028EB4u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06028EB4u) return; }  // 06028EB0 jsr @r1 ; extu.b r5,r5
    c.r[15] = c.r[14];  // 06028EB4 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06028EB6 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06028EB8 rts ; mov.l @r15+,r14
}

void f_06028ECC(SH2Context& c) {
    ran[551] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06028ECC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06028ECE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06028ED0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06028ED2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06028ED4 sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x06028F22u);  // 06028ED6 mov.w 0x06028F22,r3
    c.r[15] += c.r[3];  // 06028ED8 add r3,r15
    c.r[14] = c.r[15];  // 06028EDA mov r15,r14
    c.r[8] = c.r[5];  // 06028EDC mov r5,r8
    c.r[10] = c.r[4] & 0xFFu;  // 06028EDE extu.b r4,r10
    c.r[8] = c.r[8] & 0xFFFFu;  // 06028EE0 extu.w r8,r8
    c.r[4] = ld32(0x06028F28u);  // 06028EE2 mov.l 0x06028F28,r4
    c.r[9] = ld32(0x06028F2Cu);  // 06028EE4 mov.l 0x06028F2C,r9
    { const uint32_t x = c.r[9]; c.pr = 0x06028EEAu; c.r[5] = 0x1Bu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06028EEAu) return; }  // 06028EE6 jsr @r9 ; mov #27,r5
    c.r[5] = c.r[8];  // 06028EEA mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06028EF0u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06028EF0u) return; }  // 06028EEC jsr @r9 ; mov r0,r4
    c.r[2] = c.r[0];  // 06028EF0 mov r0,r2
    c.r[2] += 38;  // 06028EF2 add #38,r2
    c.r[0] = ld32(0x06028F30u);  // 06028EF4 mov.l 0x06028F30,r0
    c.r[5] = c.r[2];  // 06028EF6 mov r2,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06028EFCu; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06028EFCu) return; }  // 06028EF8 jsr @r0 ; mov r14,r4
    c.r[2] = c.r[0];  // 06028EFC mov r0,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x06028F24u);  // 06028EFE mov.w 0x06028F24,r3
    c.r[10] |= c.r[3];  // 06028F00 or r3,r10
    c.r[1] = ld32(0x06028F34u);  // 06028F02 mov.l 0x06028F34,r1
    c.r[0] = ld32(0x06028F38u);  // 06028F04 mov.l 0x06028F38,r0
    c.r[7] = 0x0u;  // 06028F06 mov #0,r7
    c.r[6] = c.r[10];  // 06028F08 mov r10,r6
    c.r[4] = ld32(c.r[1]);  // 06028F0A mov.l @r1,r4
    { const uint32_t x = c.r[0]; c.pr = 0x06028F10u; c.r[5] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06028F10u) return; }  // 06028F0C jsr @r0 ; mov r2,r5
    c.r[3] = (uint32_t)(int16_t)ld16(0x06028F26u);  // 06028F10 mov.w 0x06028F26,r3
    c.r[14] += c.r[3];  // 06028F12 add r3,r14
    c.r[15] = c.r[14];  // 06028F14 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06028F16 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06028F18 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06028F1A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06028F1C mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06028F1E rts ; mov.l @r15+,r8
}

void f_06028F3C(SH2Context& c) {
    ran[552] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06028F3C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06028F3E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06028F40 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06028F42 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06028F44 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06028F46 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06028F48 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06028F4A sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x060290A8u);  // 06028F4C mov.w 0x060290A8,r3
    c.r[15] += c.r[3];  // 06028F4E add r3,r15
    c.r[14] = c.r[15];  // 06028F50 mov r15,r14
    c.r[4] = c.r[4] & 0xFFu;  // 06028F52 extu.b r4,r4
    c.r[0] = (uint32_t)(int16_t)ld16(0x060290AAu);  // 06028F54 mov.w 0x060290AA,r0
    st32(c.r[0] + c.r[14], c.r[4]);  // 06028F56 mov.l r4,@(r0,r14)
    c.r[1] = ld32(0x060290B4u);  // 06028F58 mov.l 0x060290B4,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x060290AAu);  // 06028F5A mov.w 0x060290AA,r3
    c.r[3] += c.r[14];  // 06028F5C add r14,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x060290ACu);  // 06028F5E mov.w 0x060290AC,r0
    c.r[0] += c.r[14];  // 06028F60 add r14,r0
    c.r[10] = (uint32_t)(int16_t)ld16(0x060290AEu);  // 06028F62 mov.w 0x060290AE,r10
    c.r[2] = ld32(c.r[3]);  // 06028F64 mov.l @r3,r2
    c.r[10] += c.r[14];  // 06028F66 add r14,r10
    c.r[1] = ld32(c.r[1]);  // 06028F68 mov.l @r1,r1
    c.r[2] <<= 2;  // 06028F6A shll2 r2
    c.r[2] <<= 2;  // 06028F6C shll2 r2
    c.r[2] += c.r[1];  // 06028F6E add r1,r2
    c.r[2] += 2;  // 06028F70 add #2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06028F72 mov.b @r2,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x060290ACu);  // 06028F74 mov.w 0x060290AC,r3
    c.r[1] = c.r[1] & 0xFFu;  // 06028F76 extu.b r1,r1
    st32(c.r[0], c.r[1]);  // 06028F78 mov.l r1,@r0
    c.r[1] = ld32(0x060290B8u);  // 06028F7A mov.l 0x060290B8,r1
    c.r[2] = ld32(c.r[1]);  // 06028F7C mov.l @r1,r2
    c.r[3] += c.r[14];  // 06028F7E add r14,r3
    c.r[3] = ld32(c.r[3]);  // 06028F80 mov.l @r3,r3
    c.r[1] = 0x1Eu;  // 06028F82 mov #30,r1
    c.macl = c.r[3] * c.r[1];  // 06028F84 mul.l r1,r3
    c.r[9] = ld32(0x060290BCu);  // 06028F86 mov.l 0x060290BC,r9
    c.r[5] = 0x1Bu;  // 06028F88 mov #27,r5
    c.r[1] = c.macl;  // 06028F8A sts macl,r1
    c.r[0] = c.r[1];  // 06028F8C mov r1,r0
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 06028F8E mov.w @(r0,r2),r8
    c.r[4] = ld32(0x060290C0u);  // 06028F90 mov.l 0x060290C0,r4
    { const uint32_t x = c.r[9]; c.pr = 0x06028F96u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06028F96u) return; }  // 06028F92 jsr @r9 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 06028F96 mov r0,r1
    c.r[5] = c.r[8];  // 06028F98 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06028F9Eu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06028F9Eu) return; }  // 06028F9A jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 06028F9E mov r0,r1
    c.r[1] += 38;  // 06028FA0 add #38,r1
    c.r[5] = c.r[1];  // 06028FA2 mov r1,r5
    c.r[3] = ld32(0x060290C4u);  // 06028FA4 mov.l 0x060290C4,r3
    { const uint32_t x = c.r[3]; c.pr = 0x06028FAAu; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06028FAAu) return; }  // 06028FA6 jsr @r3 ; mov r10,r4
    c.r[1] = c.r[0];  // 06028FAA mov r0,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060290AAu);  // 06028FAC mov.w 0x060290AA,r0
    c.r[0] += c.r[14];  // 06028FAE add r14,r0
    c.r[8] = ld32(0x060290C8u);  // 06028FB0 mov.l 0x060290C8,r8
    c.r[7] = 0x0u;  // 06028FB2 mov #0,r7
    c.r[5] = c.r[1];  // 06028FB4 mov r1,r5
    c.r[6] = ld32(c.r[0]);  // 06028FB6 mov.l @r0,r6
    c.r[3] = ld32(0x060290CCu);  // 06028FB8 mov.l 0x060290CC,r3
    c.r[4] = ld32(c.r[8]);  // 06028FBA mov.l @r8,r4
    c.r[0] = (uint32_t)(int16_t)ld16(0x060290B0u);  // 06028FBC mov.w 0x060290B0,r0
    { const uint32_t x = c.r[3]; c.pr = 0x06028FC2u; c.r[6] |= c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06028FC2u) return; }  // 06028FBE jsr @r3 ; or r0,r6
    c.r[1] = ld32(c.r[8]);  // 06028FC2 mov.l @r8,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x060290B2u);  // 06028FC4 mov.w 0x060290B2,r2
    c.r[0] = c.r[1];  // 06028FC6 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06028FC8 mov.b @(r0,r2),r1
    c.r[3] = 0xFu;  // 06028FCA mov #15,r3
    c.r[2] = c.r[1];  // 06028FCC mov r1,r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 06028FCE shlr r2
    c.r[2] &= c.r[3];  // 06028FD0 and r3,r2
    c.r[1] = 0x8u;  // 06028FD2 mov #8,r1
    c.r[2] -= 1;  // 06028FD4 add #-1,r2
    c.t = c.r[2] > c.r[1];  // 06028FD6 cmp/hi r1,r2
    { const bool k = !c.t; c.r[1] = c.r[2]; if (k) { goto L_06028FE0; } }  // 06028FD8 bf/s 0x06028FE0 ; mov r2,r1
    goto L_06029872;  // 06028FDC bra 0x06029872 ; nop
L_06028FE0:
    c.r[1] += c.r[1];  // 06028FE0 add r1,r1
    c.r[0] = 0x06028FECu;  // 06028FE2 mova 0x06028FEC,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06028FE4 mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 06028FE6 add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x06028FFEu: goto L_06028FFE; case 0x0602903Eu: goto L_0602903E; case 0x060290D0u: goto L_060290D0; case 0x06029872u: goto L_06029872; case 0x060292DAu: goto L_060292DA; case 0x06029508u: goto L_06029508; case 0x0602970Cu: goto L_0602970C; default: sh2_call(c, x); return; } }  // 06028FE8 jmp @r0 ; nop
L_06028FFE:
    c.r[11] = ld32(0x060290C8u);  // 06028FFE mov.l 0x060290C8,r11
    c.r[1] = ld32(c.r[11]);  // 06029000 mov.l @r11,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060290B2u);  // 06029002 mov.w 0x060290B2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06029004 mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06029006 extu.b r1,r1
    c.r[1] >>= 2;  // 06029008 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0602900A shlr r1
    c.r[1] >>= 2;  // 0602900C shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0602900E tst r1,r1
    { const bool k = c.t; c.r[0] = c.r[1]; if (k) { goto L_06029056; } }  // 06029010 bt/s 0x06029056 ; mov r1,r0
    c.t = c.r[0] == 0x1u;  // 06029014 cmp/eq #1,r0
    if (c.t) { goto L_0602901C; }  // 06029016 bt 0x0602901C
    goto L_06029872;  // 06029018 bra 0x06029872 ; nop
L_0602901C:
    c.r[5] = 0x1Bu;  // 0602901C mov #27,r5
    c.r[1] = ld32(0x060290B8u);  // 0602901E mov.l 0x060290B8,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x060290ACu);  // 06029020 mov.w 0x060290AC,r3
    c.r[3] += c.r[14];  // 06029022 add r14,r3
    c.r[10] = (uint32_t)(int16_t)ld16(0x060290AEu);  // 06029024 mov.w 0x060290AE,r10
    c.r[2] = ld32(c.r[1]);  // 06029026 mov.l @r1,r2
    c.r[10] += c.r[14];  // 06029028 add r14,r10
    c.r[3] = ld32(c.r[3]);  // 0602902A mov.l @r3,r3
    c.r[1] = 0x1Eu;  // 0602902C mov #30,r1
    c.macl = c.r[3] * c.r[1];  // 0602902E mul.l r1,r3
    c.r[9] = ld32(0x060290BCu);  // 06029030 mov.l 0x060290BC,r9
    c.r[1] = c.macl;  // 06029032 sts macl,r1
    c.r[0] = c.r[1];  // 06029034 mov r1,r0
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 06029036 mov.w @(r0,r2),r8
    c.r[4] = ld32(0x060290C0u);  // 06029038 mov.l 0x060290C0,r4
    c.r[8] -= 1; goto L_06029076;  // 0602903A bra 0x06029076 ; add #-1,r8
L_0602903E:
    c.r[11] = ld32(0x060290C8u);  // 0602903E mov.l 0x060290C8,r11
    c.r[1] = ld32(c.r[11]);  // 06029040 mov.l @r11,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060290B2u);  // 06029042 mov.w 0x060290B2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06029044 mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06029046 extu.b r1,r1
    c.r[1] >>= 2;  // 06029048 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0602904A shlr r1
    c.r[1] >>= 2;  // 0602904C shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0602904E tst r1,r1
    if (c.t) { goto L_06029056; }  // 06029050 bt 0x06029056
    goto L_06029872;  // 06029052 bra 0x06029872 ; nop
L_06029056:
    c.r[1] = ld32(0x060290B8u);  // 06029056 mov.l 0x060290B8,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060290ACu);  // 06029058 mov.w 0x060290AC,r0
    c.r[0] += c.r[14];  // 0602905A add r14,r0
    c.r[10] = (uint32_t)(int16_t)ld16(0x060290AEu);  // 0602905C mov.w 0x060290AE,r10
    c.r[2] = ld32(c.r[1]);  // 0602905E mov.l @r1,r2
    c.r[10] += c.r[14];  // 06029060 add r14,r10
    c.r[0] = ld32(c.r[0]);  // 06029062 mov.l @r0,r0
    c.r[1] = 0x1Eu;  // 06029064 mov #30,r1
    c.macl = c.r[0] * c.r[1];  // 06029066 mul.l r1,r0
    c.r[9] = ld32(0x060290BCu);  // 06029068 mov.l 0x060290BC,r9
    c.r[5] = 0x1Bu;  // 0602906A mov #27,r5
    c.r[1] = c.macl;  // 0602906C sts macl,r1
    c.r[0] = c.r[1];  // 0602906E mov r1,r0
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 06029070 mov.w @(r0,r2),r8
    c.r[4] = ld32(0x060290C0u);  // 06029072 mov.l 0x060290C0,r4
    c.r[8] += 1;  // 06029074 add #1,r8
L_06029076:
    { const uint32_t x = c.r[9]; c.pr = 0x0602907Au; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602907Au) return; }  // 06029076 jsr @r9 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 0602907A mov r0,r1
    c.r[5] = c.r[8];  // 0602907C mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06029082u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06029082u) return; }  // 0602907E jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 06029082 mov r0,r1
    c.r[1] += 38;  // 06029084 add #38,r1
    c.r[5] = c.r[1];  // 06029086 mov r1,r5
    c.r[3] = ld32(0x060290C4u);  // 06029088 mov.l 0x060290C4,r3
    { const uint32_t x = c.r[3]; c.pr = 0x0602908Eu; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602908Eu) return; }  // 0602908A jsr @r3 ; mov r10,r4
    c.r[1] = c.r[0];  // 0602908E mov r0,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060290AAu);  // 06029090 mov.w 0x060290AA,r0
    c.r[0] += c.r[14];  // 06029092 add r14,r0
    c.r[7] = 0x0u;  // 06029094 mov #0,r7
    c.r[5] = c.r[1];  // 06029096 mov r1,r5
    c.r[6] = ld32(c.r[0]);  // 06029098 mov.l @r0,r6
    c.r[3] = ld32(0x060290CCu);  // 0602909A mov.l 0x060290CC,r3
    c.r[4] = ld32(c.r[11]);  // 0602909C mov.l @r11,r4
    c.r[0] = (uint32_t)(int16_t)ld16(0x060290B0u);  // 0602909E mov.w 0x060290B0,r0
    { const uint32_t x = c.r[3]; c.pr = 0x060290A4u; c.r[6] |= c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060290A4u) return; }  // 060290A0 jsr @r3 ; or r0,r6
    c.r[8] = 0x0u; goto L_06029874;  // 060290A4 bra 0x06029874 ; mov #0,r8
L_060290D0:
    c.r[0] = ld32(0x0602922Cu);  // 060290D0 mov.l 0x0602922C,r0
    c.r[1] = ld32(c.r[0]);  // 060290D2 mov.l @r0,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0602921Cu);  // 060290D4 mov.w 0x0602921C,r2
    c.r[0] = c.r[1];  // 060290D6 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 060290D8 mov.b @(r0,r2),r1
    c.r[1] = c.r[1] & 0xFFu;  // 060290DA extu.b r1,r1
    c.r[1] >>= 2;  // 060290DC shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060290DE shlr r1
    c.r[1] >>= 2;  // 060290E0 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060290E2 tst r1,r1
    if (!c.t) { goto L_0602917E; }  // 060290E4 bf 0x0602917E
    c.r[1] = 0x1Eu;  // 060290E6 mov #30,r1
    c.r[3] = ld32(0x06029230u);  // 060290E8 mov.l 0x06029230,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602921Eu);  // 060290EA mov.w 0x0602921E,r0
    c.r[0] += c.r[14];  // 060290EC add r14,r0
    c.r[9] = ld32(0x06029234u);  // 060290EE mov.l 0x06029234,r9
    c.r[0] = ld32(c.r[0]);  // 060290F0 mov.l @r0,r0
    c.r[5] = 0x1Bu;  // 060290F2 mov #27,r5
    c.r[2] = ld32(c.r[3]);  // 060290F4 mov.l @r3,r2
    c.macl = c.r[0] * c.r[1];  // 060290F6 mul.l r1,r0
    c.r[4] = ld32(0x06029238u);  // 060290F8 mov.l 0x06029238,r4
    c.r[3] = (uint32_t)(int16_t)ld16(0x06029220u);  // 060290FA mov.w 0x06029220,r3
    c.r[13] = c.macl;  // 060290FC sts macl,r13
    c.r[0] = c.r[13];  // 060290FE mov r13,r0
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 06029100 mov.w @(r0,r2),r8
    c.r[3] += c.r[14];  // 06029102 add r14,r3
    c.r[8] += 1;  // 06029104 add #1,r8
    c.r[0] = (uint32_t)(int16_t)ld16(0x06029222u);  // 06029106 mov.w 0x06029222,r0
    st32(c.r[3], c.r[0]);  // 06029108 mov.l r0,@r3
    c.r[3] = (uint32_t)(int16_t)ld16(0x06029220u);  // 0602910A mov.w 0x06029220,r3
    c.r[3] += c.r[14];  // 0602910C add r14,r3
    c.r[0] = ld32(c.r[3]);  // 0602910E mov.l @r3,r0
    c.r[8] = c.r[8] & 0xFFFFu;  // 06029110 extu.w r8,r8
    c.r[0] += c.r[14];  // 06029112 add r14,r0
    { const uint32_t x = c.r[9]; c.pr = 0x06029118u; st32(c.r[3], c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06029118u) return; }  // 06029114 jsr @r9 ; mov.l r0,@r3
    c.r[1] = c.r[0];  // 06029118 mov r0,r1
    c.r[5] = c.r[8];  // 0602911A mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06029120u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06029120u) return; }  // 0602911C jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 06029120 mov r0,r1
    c.r[1] += 38;  // 06029122 add #38,r1
    c.r[11] = ld32(0x0602923Cu);  // 06029124 mov.l 0x0602923C,r11
    c.r[3] = (uint32_t)(int16_t)ld16(0x06029220u);  // 06029126 mov.w 0x06029220,r3
    c.r[3] += c.r[14];  // 06029128 add r14,r3
    c.r[4] = ld32(c.r[3]);  // 0602912A mov.l @r3,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06029130u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06029130u) return; }  // 0602912C jsr @r11 ; mov r1,r5
    c.r[1] = c.r[0];  // 06029130 mov r0,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06029224u);  // 06029132 mov.w 0x06029224,r0
    c.r[0] += c.r[14];  // 06029134 add r14,r0
    c.r[3] = ld32(0x0602922Cu);  // 06029136 mov.l 0x0602922C,r3
    c.r[12] = ld32(0x06029240u);  // 06029138 mov.l 0x06029240,r12
    c.r[7] = 0x0u;  // 0602913A mov #0,r7
    c.r[10] = ld32(c.r[0]);  // 0602913C mov.l @r0,r10
    c.r[5] = c.r[1];  // 0602913E mov r1,r5
    c.r[4] = ld32(c.r[3]);  // 06029140 mov.l @r3,r4
    c.r[0] = (uint32_t)(int16_t)ld16(0x06029226u);  // 06029142 mov.w 0x06029226,r0
    c.r[10] |= c.r[0];  // 06029144 or r0,r10
    { const uint32_t x = c.r[12]; c.pr = 0x0602914Au; c.r[6] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602914Au) return; }  // 06029146 jsr @r12 ; mov r10,r6
    c.r[0] = ld32(0x06029230u);  // 0602914A mov.l 0x06029230,r0
    c.r[1] = ld32(c.r[0]);  // 0602914C mov.l @r0,r1
    c.r[5] = 0x1Bu;  // 0602914E mov #27,r5
    c.r[0] = c.r[13];  // 06029150 mov r13,r0
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06029152 mov.w @(r0,r1),r8
    c.r[4] = ld32(0x06029238u);  // 06029154 mov.l 0x06029238,r4
    c.r[8] += 2;  // 06029156 add #2,r8
    { const uint32_t x = c.r[9]; c.pr = 0x0602915Cu; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602915Cu) return; }  // 06029158 jsr @r9 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 0602915C mov r0,r1
    c.r[5] = c.r[8];  // 0602915E mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06029164u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06029164u) return; }  // 06029160 jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 06029164 mov r0,r1
    c.r[1] += 38;  // 06029166 add #38,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x06029220u);  // 06029168 mov.w 0x06029220,r3
    c.r[3] += c.r[14];  // 0602916A add r14,r3
    c.r[4] = ld32(c.r[3]);  // 0602916C mov.l @r3,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06029172u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06029172u) return; }  // 0602916E jsr @r11 ; mov r1,r5
    c.r[1] = c.r[0];  // 06029172 mov r0,r1
    c.r[0] = ld32(0x0602922Cu);  // 06029174 mov.l 0x0602922C,r0
    c.r[7] = 0x0u;  // 06029176 mov #0,r7
    c.r[6] = c.r[10];  // 06029178 mov r10,r6
    c.r[4] = ld32(c.r[0]); goto L_0602986E;  // 0602917A bra 0x0602986E ; mov.l @r0,r4
L_0602917E:
    c.r[0] = c.r[1];  // 0602917E mov r1,r0
    c.t = c.r[0] == 0x1u;  // 06029180 cmp/eq #1,r0
    { const bool k = !c.t; c.r[1] = 0x1Eu; if (k) { goto L_06029244; } }  // 06029182 bf/s 0x06029244 ; mov #30,r1
    c.r[3] = ld32(0x06029230u);  // 06029186 mov.l 0x06029230,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602921Eu);  // 06029188 mov.w 0x0602921E,r0
    c.r[0] += c.r[14];  // 0602918A add r14,r0
    c.r[9] = ld32(0x06029234u);  // 0602918C mov.l 0x06029234,r9
    c.r[0] = ld32(c.r[0]);  // 0602918E mov.l @r0,r0
    c.r[5] = 0x1Bu;  // 06029190 mov #27,r5
    c.r[2] = ld32(c.r[3]);  // 06029192 mov.l @r3,r2
    c.macl = c.r[0] * c.r[1];  // 06029194 mul.l r1,r0
    c.r[4] = ld32(0x06029238u);  // 06029196 mov.l 0x06029238,r4
    c.r[3] = (uint32_t)(int16_t)ld16(0x06029228u);  // 06029198 mov.w 0x06029228,r3
    c.r[13] = c.macl;  // 0602919A sts macl,r13
    c.r[0] = c.r[13];  // 0602919C mov r13,r0
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 0602919E mov.w @(r0,r2),r8
    c.r[3] += c.r[14];  // 060291A0 add r14,r3
    c.r[8] -= 1;  // 060291A2 add #-1,r8
    c.r[0] = (uint32_t)(int16_t)ld16(0x06029222u);  // 060291A4 mov.w 0x06029222,r0
    st32(c.r[3], c.r[0]);  // 060291A6 mov.l r0,@r3
    c.r[3] = (uint32_t)(int16_t)ld16(0x06029228u);  // 060291A8 mov.w 0x06029228,r3
    c.r[3] += c.r[14];  // 060291AA add r14,r3
    c.r[0] = ld32(c.r[3]);  // 060291AC mov.l @r3,r0
    c.r[8] = c.r[8] & 0xFFFFu;  // 060291AE extu.w r8,r8
    c.r[0] += c.r[14];  // 060291B0 add r14,r0
    { const uint32_t x = c.r[9]; c.pr = 0x060291B6u; st32(c.r[3], c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060291B6u) return; }  // 060291B2 jsr @r9 ; mov.l r0,@r3
    c.r[1] = c.r[0];  // 060291B6 mov r0,r1
    c.r[5] = c.r[8];  // 060291B8 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x060291BEu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060291BEu) return; }  // 060291BA jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 060291BE mov r0,r1
    c.r[1] += 38;  // 060291C0 add #38,r1
    c.r[11] = ld32(0x0602923Cu);  // 060291C2 mov.l 0x0602923C,r11
    c.r[3] = (uint32_t)(int16_t)ld16(0x06029228u);  // 060291C4 mov.w 0x06029228,r3
    c.r[3] += c.r[14];  // 060291C6 add r14,r3
    c.r[4] = ld32(c.r[3]);  // 060291C8 mov.l @r3,r4
    { const uint32_t x = c.r[11]; c.pr = 0x060291CEu; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060291CEu) return; }  // 060291CA jsr @r11 ; mov r1,r5
    c.r[1] = c.r[0];  // 060291CE mov r0,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06029224u);  // 060291D0 mov.w 0x06029224,r0
    c.r[0] += c.r[14];  // 060291D2 add r14,r0
    c.r[3] = ld32(0x0602922Cu);  // 060291D4 mov.l 0x0602922C,r3
    c.r[12] = ld32(0x06029240u);  // 060291D6 mov.l 0x06029240,r12
    c.r[7] = 0x0u;  // 060291D8 mov #0,r7
    c.r[10] = ld32(c.r[0]);  // 060291DA mov.l @r0,r10
    c.r[5] = c.r[1];  // 060291DC mov r1,r5
    c.r[4] = ld32(c.r[3]);  // 060291DE mov.l @r3,r4
    c.r[0] = (uint32_t)(int16_t)ld16(0x06029226u);  // 060291E0 mov.w 0x06029226,r0
    c.r[10] |= c.r[0];  // 060291E2 or r0,r10
    { const uint32_t x = c.r[12]; c.pr = 0x060291E8u; c.r[6] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060291E8u) return; }  // 060291E4 jsr @r12 ; mov r10,r6
    c.r[0] = ld32(0x06029230u);  // 060291E8 mov.l 0x06029230,r0
    c.r[1] = ld32(c.r[0]);  // 060291EA mov.l @r0,r1
    c.r[5] = 0x1Bu;  // 060291EC mov #27,r5
    c.r[0] = c.r[13];  // 060291EE mov r13,r0
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 060291F0 mov.w @(r0,r1),r8
    c.r[4] = ld32(0x06029238u);  // 060291F2 mov.l 0x06029238,r4
    c.r[8] += 1;  // 060291F4 add #1,r8
    { const uint32_t x = c.r[9]; c.pr = 0x060291FAu; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060291FAu) return; }  // 060291F6 jsr @r9 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 060291FA mov r0,r1
    c.r[5] = c.r[8];  // 060291FC mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06029202u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06029202u) return; }  // 060291FE jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 06029202 mov r0,r1
    c.r[1] += 38;  // 06029204 add #38,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x06029228u);  // 06029206 mov.w 0x06029228,r3
    c.r[3] += c.r[14];  // 06029208 add r14,r3
    c.r[4] = ld32(c.r[3]);  // 0602920A mov.l @r3,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06029210u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06029210u) return; }  // 0602920C jsr @r11 ; mov r1,r5
    c.r[1] = c.r[0];  // 06029210 mov r0,r1
    c.r[0] = ld32(0x0602922Cu);  // 06029212 mov.l 0x0602922C,r0
    c.r[7] = 0x0u;  // 06029214 mov #0,r7
    c.r[6] = c.r[10];  // 06029216 mov r10,r6
    c.r[4] = ld32(c.r[0]); goto L_0602986E;  // 06029218 bra 0x0602986E ; mov.l @r0,r4
L_06029244:
    c.r[3] = ld32(0x06029398u);  // 06029244 mov.l 0x06029398,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x06029388u);  // 06029246 mov.w 0x06029388,r0
    c.r[0] += c.r[14];  // 06029248 add r14,r0
    c.r[9] = ld32(0x0602939Cu);  // 0602924A mov.l 0x0602939C,r9
    c.r[0] = ld32(c.r[0]);  // 0602924C mov.l @r0,r0
    c.r[5] = 0x1Bu;  // 0602924E mov #27,r5
    c.r[2] = ld32(c.r[3]);  // 06029250 mov.l @r3,r2
    c.macl = c.r[0] * c.r[1];  // 06029252 mul.l r1,r0
    c.r[4] = ld32(0x060293A0u);  // 06029254 mov.l 0x060293A0,r4
    c.r[3] = (uint32_t)(int16_t)ld16(0x0602938Au);  // 06029256 mov.w 0x0602938A,r3
    c.r[13] = c.macl;  // 06029258 sts macl,r13
    c.r[0] = c.r[13];  // 0602925A mov r13,r0
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 0602925C mov.w @(r0,r2),r8
    c.r[3] += c.r[14];  // 0602925E add r14,r3
    c.r[8] -= 2;  // 06029260 add #-2,r8
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602938Cu);  // 06029262 mov.w 0x0602938C,r0
    st32(c.r[3], c.r[0]);  // 06029264 mov.l r0,@r3
    c.r[3] = (uint32_t)(int16_t)ld16(0x0602938Au);  // 06029266 mov.w 0x0602938A,r3
    c.r[3] += c.r[14];  // 06029268 add r14,r3
    c.r[0] = ld32(c.r[3]);  // 0602926A mov.l @r3,r0
    c.r[8] = c.r[8] & 0xFFFFu;  // 0602926C extu.w r8,r8
    c.r[0] += c.r[14];  // 0602926E add r14,r0
    { const uint32_t x = c.r[9]; c.pr = 0x06029274u; st32(c.r[3], c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06029274u) return; }  // 06029270 jsr @r9 ; mov.l r0,@r3
    c.r[1] = c.r[0];  // 06029274 mov r0,r1
    c.r[5] = c.r[8];  // 06029276 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0602927Cu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602927Cu) return; }  // 06029278 jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 0602927C mov r0,r1
    c.r[1] += 38;  // 0602927E add #38,r1
    c.r[11] = ld32(0x060293A4u);  // 06029280 mov.l 0x060293A4,r11
    c.r[3] = (uint32_t)(int16_t)ld16(0x0602938Au);  // 06029282 mov.w 0x0602938A,r3
    c.r[3] += c.r[14];  // 06029284 add r14,r3
    c.r[4] = ld32(c.r[3]);  // 06029286 mov.l @r3,r4
    { const uint32_t x = c.r[11]; c.pr = 0x0602928Cu; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602928Cu) return; }  // 06029288 jsr @r11 ; mov r1,r5
    c.r[1] = c.r[0];  // 0602928C mov r0,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602938Eu);  // 0602928E mov.w 0x0602938E,r0
    c.r[0] += c.r[14];  // 06029290 add r14,r0
    c.r[3] = ld32(0x060293A8u);  // 06029292 mov.l 0x060293A8,r3
    c.r[12] = ld32(0x060293ACu);  // 06029294 mov.l 0x060293AC,r12
    c.r[7] = 0x0u;  // 06029296 mov #0,r7
    c.r[10] = ld32(c.r[0]);  // 06029298 mov.l @r0,r10
    c.r[5] = c.r[1];  // 0602929A mov r1,r5
    c.r[4] = ld32(c.r[3]);  // 0602929C mov.l @r3,r4
    c.r[0] = (uint32_t)(int16_t)ld16(0x06029390u);  // 0602929E mov.w 0x06029390,r0
    c.r[10] |= c.r[0];  // 060292A0 or r0,r10
    { const uint32_t x = c.r[12]; c.pr = 0x060292A6u; c.r[6] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060292A6u) return; }  // 060292A2 jsr @r12 ; mov r10,r6
    c.r[0] = ld32(0x06029398u);  // 060292A6 mov.l 0x06029398,r0
    c.r[1] = ld32(c.r[0]);  // 060292A8 mov.l @r0,r1
    c.r[5] = 0x1Bu;  // 060292AA mov #27,r5
    c.r[0] = c.r[13];  // 060292AC mov r13,r0
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 060292AE mov.w @(r0,r1),r8
    c.r[4] = ld32(0x060293A0u);  // 060292B0 mov.l 0x060293A0,r4
    c.r[8] -= 1;  // 060292B2 add #-1,r8
    { const uint32_t x = c.r[9]; c.pr = 0x060292B8u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060292B8u) return; }  // 060292B4 jsr @r9 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 060292B8 mov r0,r1
    c.r[5] = c.r[8];  // 060292BA mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x060292C0u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060292C0u) return; }  // 060292BC jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 060292C0 mov r0,r1
    c.r[1] += 38;  // 060292C2 add #38,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x0602938Au);  // 060292C4 mov.w 0x0602938A,r3
    c.r[3] += c.r[14];  // 060292C6 add r14,r3
    c.r[4] = ld32(c.r[3]);  // 060292C8 mov.l @r3,r4
    { const uint32_t x = c.r[11]; c.pr = 0x060292CEu; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060292CEu) return; }  // 060292CA jsr @r11 ; mov r1,r5
    c.r[1] = c.r[0];  // 060292CE mov r0,r1
    c.r[0] = ld32(0x060293A8u);  // 060292D0 mov.l 0x060293A8,r0
    c.r[7] = 0x0u;  // 060292D2 mov #0,r7
    c.r[6] = c.r[10];  // 060292D4 mov r10,r6
    c.r[4] = ld32(c.r[0]); goto L_0602986E;  // 060292D6 bra 0x0602986E ; mov.l @r0,r4
L_060292DA:
    c.r[3] = ld32(0x060293A8u);  // 060292DA mov.l 0x060293A8,r3
    c.r[1] = ld32(c.r[3]);  // 060292DC mov.l @r3,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06029392u);  // 060292DE mov.w 0x06029392,r2
    c.r[0] = c.r[1];  // 060292E0 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 060292E2 mov.b @(r0,r2),r1
    c.r[1] = c.r[1] & 0xFFu;  // 060292E4 extu.b r1,r1
    c.r[1] >>= 2;  // 060292E6 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060292E8 shlr r1
    c.r[1] >>= 2;  // 060292EA shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060292EC tst r1,r1
    if (!c.t) { goto L_060293B0; }  // 060292EE bf 0x060293B0
    c.r[1] = 0x1Eu;  // 060292F0 mov #30,r1
    c.r[3] = ld32(0x06029398u);  // 060292F2 mov.l 0x06029398,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x06029388u);  // 060292F4 mov.w 0x06029388,r0
    c.r[0] += c.r[14];  // 060292F6 add r14,r0
    c.r[9] = ld32(0x0602939Cu);  // 060292F8 mov.l 0x0602939C,r9
    c.r[0] = ld32(c.r[0]);  // 060292FA mov.l @r0,r0
    c.r[5] = 0x1Bu;  // 060292FC mov #27,r5
    c.r[2] = ld32(c.r[3]);  // 060292FE mov.l @r3,r2
    c.macl = c.r[0] * c.r[1];  // 06029300 mul.l r1,r0
    c.r[4] = ld32(0x060293A0u);  // 06029302 mov.l 0x060293A0,r4
    c.r[3] = (uint32_t)(int16_t)ld16(0x06029394u);  // 06029304 mov.w 0x06029394,r3
    c.r[13] = c.macl;  // 06029306 sts macl,r13
    c.r[0] = c.r[13];  // 06029308 mov r13,r0
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 0602930A mov.w @(r0,r2),r8
    c.r[3] += c.r[14];  // 0602930C add r14,r3
    c.r[8] += 1;  // 0602930E add #1,r8
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602938Cu);  // 06029310 mov.w 0x0602938C,r0
    st32(c.r[3], c.r[0]);  // 06029312 mov.l r0,@r3
    c.r[3] = (uint32_t)(int16_t)ld16(0x06029394u);  // 06029314 mov.w 0x06029394,r3
    c.r[3] += c.r[14];  // 06029316 add r14,r3
    c.r[0] = ld32(c.r[3]);  // 06029318 mov.l @r3,r0
    c.r[8] = c.r[8] & 0xFFFFu;  // 0602931A extu.w r8,r8
    c.r[0] += c.r[14];  // 0602931C add r14,r0
    { const uint32_t x = c.r[9]; c.pr = 0x06029322u; st32(c.r[3], c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06029322u) return; }  // 0602931E jsr @r9 ; mov.l r0,@r3
    c.r[1] = c.r[0];  // 06029322 mov r0,r1
    c.r[5] = c.r[8];  // 06029324 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0602932Au; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602932Au) return; }  // 06029326 jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 0602932A mov r0,r1
    c.r[1] += 38;  // 0602932C add #38,r1
    c.r[11] = ld32(0x060293A4u);  // 0602932E mov.l 0x060293A4,r11
    c.r[3] = (uint32_t)(int16_t)ld16(0x06029394u);  // 06029330 mov.w 0x06029394,r3
    c.r[3] += c.r[14];  // 06029332 add r14,r3
    c.r[4] = ld32(c.r[3]);  // 06029334 mov.l @r3,r4
    { const uint32_t x = c.r[11]; c.pr = 0x0602933Au; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602933Au) return; }  // 06029336 jsr @r11 ; mov r1,r5
    c.r[1] = c.r[0];  // 0602933A mov r0,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602938Eu);  // 0602933C mov.w 0x0602938E,r0
    c.r[0] += c.r[14];  // 0602933E add r14,r0
    c.r[3] = ld32(0x060293A8u);  // 06029340 mov.l 0x060293A8,r3
    c.r[12] = ld32(0x060293ACu);  // 06029342 mov.l 0x060293AC,r12
    c.r[7] = 0x0u;  // 06029344 mov #0,r7
    c.r[10] = ld32(c.r[0]);  // 06029346 mov.l @r0,r10
    c.r[5] = c.r[1];  // 06029348 mov r1,r5
    c.r[4] = ld32(c.r[3]);  // 0602934A mov.l @r3,r4
    c.r[0] = (uint32_t)(int16_t)ld16(0x06029390u);  // 0602934C mov.w 0x06029390,r0
    c.r[10] |= c.r[0];  // 0602934E or r0,r10
    { const uint32_t x = c.r[12]; c.pr = 0x06029354u; c.r[6] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06029354u) return; }  // 06029350 jsr @r12 ; mov r10,r6
    c.r[0] = ld32(0x06029398u);  // 06029354 mov.l 0x06029398,r0
    c.r[1] = ld32(c.r[0]);  // 06029356 mov.l @r0,r1
    c.r[5] = 0x1Bu;  // 06029358 mov #27,r5
    c.r[0] = c.r[13];  // 0602935A mov r13,r0
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0602935C mov.w @(r0,r1),r8
    c.r[4] = ld32(0x060293A0u);  // 0602935E mov.l 0x060293A0,r4
    c.r[8] += 2;  // 06029360 add #2,r8
    { const uint32_t x = c.r[9]; c.pr = 0x06029366u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06029366u) return; }  // 06029362 jsr @r9 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 06029366 mov r0,r1
    c.r[5] = c.r[8];  // 06029368 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0602936Eu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602936Eu) return; }  // 0602936A jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 0602936E mov r0,r1
    c.r[1] += 38;  // 06029370 add #38,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x06029394u);  // 06029372 mov.w 0x06029394,r3
    c.r[3] += c.r[14];  // 06029374 add r14,r3
    c.r[4] = ld32(c.r[3]);  // 06029376 mov.l @r3,r4
    { const uint32_t x = c.r[11]; c.pr = 0x0602937Cu; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602937Cu) return; }  // 06029378 jsr @r11 ; mov r1,r5
    c.r[1] = c.r[0];  // 0602937C mov r0,r1
    c.r[0] = ld32(0x060293A8u);  // 0602937E mov.l 0x060293A8,r0
    c.r[7] = 0x0u;  // 06029380 mov #0,r7
    c.r[6] = c.r[10];  // 06029382 mov r10,r6
    c.r[4] = ld32(c.r[0]); goto L_0602986E;  // 06029384 bra 0x0602986E ; mov.l @r0,r4
L_060293B0:
    c.r[0] = c.r[1];  // 060293B0 mov r1,r0
    c.t = c.r[0] == 0x1u;  // 060293B2 cmp/eq #1,r0
    { const bool k = !c.t; c.r[1] = 0x1Eu; if (k) { goto L_0602944E; } }  // 060293B4 bf/s 0x0602944E ; mov #30,r1
    c.r[3] = ld32(0x060294F0u);  // 060293B8 mov.l 0x060294F0,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x060294E4u);  // 060293BA mov.w 0x060294E4,r0
    c.r[0] += c.r[14];  // 060293BC add r14,r0
    c.r[9] = ld32(0x060294F4u);  // 060293BE mov.l 0x060294F4,r9
    c.r[0] = ld32(c.r[0]);  // 060293C0 mov.l @r0,r0
    c.r[5] = 0x1Bu;  // 060293C2 mov #27,r5
    c.r[2] = ld32(c.r[3]);  // 060293C4 mov.l @r3,r2
    c.macl = c.r[0] * c.r[1];  // 060293C6 mul.l r1,r0
    c.r[4] = ld32(0x060294F8u);  // 060293C8 mov.l 0x060294F8,r4
    c.r[3] = (uint32_t)(int16_t)ld16(0x060294E6u);  // 060293CA mov.w 0x060294E6,r3
    c.r[13] = c.macl;  // 060293CC sts macl,r13
    c.r[0] = c.r[13];  // 060293CE mov r13,r0
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 060293D0 mov.w @(r0,r2),r8
    c.r[3] += c.r[14];  // 060293D2 add r14,r3
    c.r[8] -= 1;  // 060293D4 add #-1,r8
    c.r[0] = (uint32_t)(int16_t)ld16(0x060294E8u);  // 060293D6 mov.w 0x060294E8,r0
    st32(c.r[3], c.r[0]);  // 060293D8 mov.l r0,@r3
    c.r[3] = (uint32_t)(int16_t)ld16(0x060294E6u);  // 060293DA mov.w 0x060294E6,r3
    c.r[3] += c.r[14];  // 060293DC add r14,r3
    c.r[0] = ld32(c.r[3]);  // 060293DE mov.l @r3,r0
    c.r[8] = c.r[8] & 0xFFFFu;  // 060293E0 extu.w r8,r8
    c.r[0] += c.r[14];  // 060293E2 add r14,r0
    { const uint32_t x = c.r[9]; c.pr = 0x060293E8u; st32(c.r[3], c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060293E8u) return; }  // 060293E4 jsr @r9 ; mov.l r0,@r3
    c.r[1] = c.r[0];  // 060293E8 mov r0,r1
    c.r[5] = c.r[8];  // 060293EA mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x060293F0u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060293F0u) return; }  // 060293EC jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 060293F0 mov r0,r1
    c.r[1] += 38;  // 060293F2 add #38,r1
    c.r[11] = ld32(0x060294FCu);  // 060293F4 mov.l 0x060294FC,r11
    c.r[3] = (uint32_t)(int16_t)ld16(0x060294E6u);  // 060293F6 mov.w 0x060294E6,r3
    c.r[3] += c.r[14];  // 060293F8 add r14,r3
    c.r[4] = ld32(c.r[3]);  // 060293FA mov.l @r3,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06029400u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06029400u) return; }  // 060293FC jsr @r11 ; mov r1,r5
    c.r[1] = c.r[0];  // 06029400 mov r0,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060294EAu);  // 06029402 mov.w 0x060294EA,r0
    c.r[0] += c.r[14];  // 06029404 add r14,r0
    c.r[3] = ld32(0x06029500u);  // 06029406 mov.l 0x06029500,r3
    c.r[12] = ld32(0x06029504u);  // 06029408 mov.l 0x06029504,r12
    c.r[7] = 0x0u;  // 0602940A mov #0,r7
    c.r[10] = ld32(c.r[0]);  // 0602940C mov.l @r0,r10
    c.r[5] = c.r[1];  // 0602940E mov r1,r5
    c.r[4] = ld32(c.r[3]);  // 06029410 mov.l @r3,r4
    c.r[0] = (uint32_t)(int16_t)ld16(0x060294ECu);  // 06029412 mov.w 0x060294EC,r0
    c.r[10] |= c.r[0];  // 06029414 or r0,r10
    { const uint32_t x = c.r[12]; c.pr = 0x0602941Au; c.r[6] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602941Au) return; }  // 06029416 jsr @r12 ; mov r10,r6
    c.r[0] = ld32(0x060294F0u);  // 0602941A mov.l 0x060294F0,r0
    c.r[1] = ld32(c.r[0]);  // 0602941C mov.l @r0,r1
    c.r[5] = 0x1Bu;  // 0602941E mov #27,r5
    c.r[0] = c.r[13];  // 06029420 mov r13,r0
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06029422 mov.w @(r0,r1),r8
    c.r[4] = ld32(0x060294F8u);  // 06029424 mov.l 0x060294F8,r4
    c.r[8] += 1;  // 06029426 add #1,r8
    { const uint32_t x = c.r[9]; c.pr = 0x0602942Cu; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602942Cu) return; }  // 06029428 jsr @r9 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 0602942C mov r0,r1
    c.r[5] = c.r[8];  // 0602942E mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06029434u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06029434u) return; }  // 06029430 jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 06029434 mov r0,r1
    c.r[1] += 38;  // 06029436 add #38,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x060294E6u);  // 06029438 mov.w 0x060294E6,r3
    c.r[3] += c.r[14];  // 0602943A add r14,r3
    c.r[4] = ld32(c.r[3]);  // 0602943C mov.l @r3,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06029442u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06029442u) return; }  // 0602943E jsr @r11 ; mov r1,r5
    c.r[1] = c.r[0];  // 06029442 mov r0,r1
    c.r[0] = ld32(0x06029500u);  // 06029444 mov.l 0x06029500,r0
    c.r[7] = 0x0u;  // 06029446 mov #0,r7
    c.r[6] = c.r[10];  // 06029448 mov r10,r6
    c.r[4] = ld32(c.r[0]); goto L_0602986E;  // 0602944A bra 0x0602986E ; mov.l @r0,r4
L_0602944E:
    c.r[3] = ld32(0x060294F0u);  // 0602944E mov.l 0x060294F0,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x060294E4u);  // 06029450 mov.w 0x060294E4,r0
    c.r[0] += c.r[14];  // 06029452 add r14,r0
    c.r[9] = ld32(0x060294F4u);  // 06029454 mov.l 0x060294F4,r9
    c.r[0] = ld32(c.r[0]);  // 06029456 mov.l @r0,r0
    c.r[5] = 0x1Bu;  // 06029458 mov #27,r5
    c.r[2] = ld32(c.r[3]);  // 0602945A mov.l @r3,r2
    c.macl = c.r[0] * c.r[1];  // 0602945C mul.l r1,r0
    c.r[4] = ld32(0x060294F8u);  // 0602945E mov.l 0x060294F8,r4
    c.r[3] = (uint32_t)(int16_t)ld16(0x060294EEu);  // 06029460 mov.w 0x060294EE,r3
    c.r[13] = c.macl;  // 06029462 sts macl,r13
    c.r[0] = c.r[13];  // 06029464 mov r13,r0
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 06029466 mov.w @(r0,r2),r8
    c.r[3] += c.r[14];  // 06029468 add r14,r3
    c.r[8] -= 2;  // 0602946A add #-2,r8
    c.r[0] = (uint32_t)(int16_t)ld16(0x060294E8u);  // 0602946C mov.w 0x060294E8,r0
    st32(c.r[3], c.r[0]);  // 0602946E mov.l r0,@r3
    c.r[3] = (uint32_t)(int16_t)ld16(0x060294EEu);  // 06029470 mov.w 0x060294EE,r3
    c.r[3] += c.r[14];  // 06029472 add r14,r3
    c.r[0] = ld32(c.r[3]);  // 06029474 mov.l @r3,r0
    c.r[8] = c.r[8] & 0xFFFFu;  // 06029476 extu.w r8,r8
    c.r[0] += c.r[14];  // 06029478 add r14,r0
    { const uint32_t x = c.r[9]; c.pr = 0x0602947Eu; st32(c.r[3], c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602947Eu) return; }  // 0602947A jsr @r9 ; mov.l r0,@r3
    c.r[1] = c.r[0];  // 0602947E mov r0,r1
    c.r[5] = c.r[8];  // 06029480 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06029486u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06029486u) return; }  // 06029482 jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 06029486 mov r0,r1
    c.r[1] += 38;  // 06029488 add #38,r1
    c.r[11] = ld32(0x060294FCu);  // 0602948A mov.l 0x060294FC,r11
    c.r[3] = (uint32_t)(int16_t)ld16(0x060294EEu);  // 0602948C mov.w 0x060294EE,r3
    c.r[3] += c.r[14];  // 0602948E add r14,r3
    c.r[4] = ld32(c.r[3]);  // 06029490 mov.l @r3,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06029496u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06029496u) return; }  // 06029492 jsr @r11 ; mov r1,r5
    c.r[1] = c.r[0];  // 06029496 mov r0,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060294EAu);  // 06029498 mov.w 0x060294EA,r0
    c.r[0] += c.r[14];  // 0602949A add r14,r0
    c.r[3] = ld32(0x06029500u);  // 0602949C mov.l 0x06029500,r3
    c.r[12] = ld32(0x06029504u);  // 0602949E mov.l 0x06029504,r12
    c.r[7] = 0x0u;  // 060294A0 mov #0,r7
    c.r[10] = ld32(c.r[0]);  // 060294A2 mov.l @r0,r10
    c.r[5] = c.r[1];  // 060294A4 mov r1,r5
    c.r[4] = ld32(c.r[3]);  // 060294A6 mov.l @r3,r4
    c.r[0] = (uint32_t)(int16_t)ld16(0x060294ECu);  // 060294A8 mov.w 0x060294EC,r0
    c.r[10] |= c.r[0];  // 060294AA or r0,r10
    { const uint32_t x = c.r[12]; c.pr = 0x060294B0u; c.r[6] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060294B0u) return; }  // 060294AC jsr @r12 ; mov r10,r6
    c.r[0] = ld32(0x060294F0u);  // 060294B0 mov.l 0x060294F0,r0
    c.r[1] = ld32(c.r[0]);  // 060294B2 mov.l @r0,r1
    c.r[5] = 0x1Bu;  // 060294B4 mov #27,r5
    c.r[0] = c.r[13];  // 060294B6 mov r13,r0
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 060294B8 mov.w @(r0,r1),r8
    c.r[4] = ld32(0x060294F8u);  // 060294BA mov.l 0x060294F8,r4
    c.r[8] -= 1;  // 060294BC add #-1,r8
    { const uint32_t x = c.r[9]; c.pr = 0x060294C2u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060294C2u) return; }  // 060294BE jsr @r9 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 060294C2 mov r0,r1
    c.r[5] = c.r[8];  // 060294C4 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x060294CAu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060294CAu) return; }  // 060294C6 jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 060294CA mov r0,r1
    c.r[1] += 38;  // 060294CC add #38,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x060294EEu);  // 060294CE mov.w 0x060294EE,r3
    c.r[3] += c.r[14];  // 060294D0 add r14,r3
    c.r[4] = ld32(c.r[3]);  // 060294D2 mov.l @r3,r4
    { const uint32_t x = c.r[11]; c.pr = 0x060294D8u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060294D8u) return; }  // 060294D4 jsr @r11 ; mov r1,r5
    c.r[1] = c.r[0];  // 060294D8 mov r0,r1
    c.r[0] = ld32(0x06029500u);  // 060294DA mov.l 0x06029500,r0
    c.r[7] = 0x0u;  // 060294DC mov #0,r7
    c.r[6] = c.r[10];  // 060294DE mov r10,r6
    c.r[4] = ld32(c.r[0]); goto L_0602986E;  // 060294E0 bra 0x0602986E ; mov.l @r0,r4
L_06029508:
    c.r[7] = 0x0u;  // 06029508 mov #0,r7
    c.r[6] = 0x0u;  // 0602950A mov #0,r6
    c.r[8] = ld32(0x06029674u);  // 0602950C mov.l 0x06029674,r8
    c.r[4] = c.r[14];  // 0602950E mov r14,r4
    c.r[4] += 1;  // 06029510 add #1,r4
    c.r[5] = 0x0u;  // 06029512 mov #0,r5
    c.r[10] = 0x0u;  // 06029514 mov #0,r10
L_06029516:
    c.r[1] = ld32(c.r[8]);  // 06029516 mov.l @r8,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06029664u);  // 06029518 mov.w 0x06029664,r0
    c.r[1] += c.r[5];  // 0602951A add r5,r1
    c.r[1] += 16;  // 0602951C add #16,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602951E mov.b @r1,r1
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06029520 mov.l @(r0,r14),r0
    c.r[1] = c.r[1] & 0xFFu;  // 06029522 extu.b r1,r1
    c.t = c.r[0] == c.r[1];  // 06029524 cmp/eq r1,r0
    { const bool k = !c.t; c.r[1] = c.r[7] & 0xFFFFu; if (k) { goto L_06029544; } }  // 06029526 bf/s 0x06029544 ; extu.w r7,r1
    c.r[9] = c.r[1];  // 0602952A mov r1,r9
    c.r[9] >>= 8;  // 0602952C shlr8 r9
    c.r[3] = 0x7Fu;  // 0602952E mov #127,r3
    c.r[9] &= c.r[3];  // 06029530 and r3,r9
    c.r[0] = c.r[10];  // 06029532 mov r10,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 06029534 mov.b @(r0,r14),r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x06029666u);  // 06029536 mov.w 0x06029666,r3
    c.r[10] += 2;  // 06029538 add #2,r10
    c.r[6] += 1;  // 0602953A add #1,r6
    c.r[2] &= c.r[3];  // 0602953C and r3,r2
    c.r[2] |= c.r[9];  // 0602953E or r9,r2
    st8(c.r[0] + c.r[14], c.r[2]);  // 06029540 mov.b r2,@(r0,r14)
    st8(c.r[0] + c.r[4], c.r[1]);  // 06029542 mov.b r1,@(r0,r4)
L_06029544:
    c.r[7] += 1;  // 06029544 add #1,r7
    c.r[1] = 0x7Fu;  // 06029546 mov #127,r1
    c.t = (int32_t)c.r[7] > (int32_t)c.r[1];  // 06029548 cmp/gt r1,r7
    { const bool k = !c.t; c.r[5] += 30; if (k) { SH2_POLL(c); goto L_06029516; } }  // 0602954A bf/s 0x06029516 ; add #30,r5
    c.r[1] = 0x3u;  // 0602954E mov #3,r1
    c.t = (int32_t)c.r[6] > (int32_t)c.r[1];  // 06029550 cmp/gt r1,r6
    { const bool k = c.t; c.r[1] = c.r[14]; if (k) { goto L_0602955A; } }  // 06029552 bt/s 0x0602955A ; mov r14,r1
    goto L_06029872;  // 06029556 bra 0x06029872 ; nop
L_0602955A:
    c.r[1] += 1;  // 0602955A add #1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06029664u);  // 0602955C mov.w 0x06029664,r0
    c.r[0] += c.r[14];  // 0602955E add r14,r0
    c.r[13] = ld32(0x06029674u);  // 06029560 mov.l 0x06029674,r13
    c.r[3] = (uint32_t)(int16_t)ld16(0x06029664u);  // 06029562 mov.w 0x06029664,r3
    c.r[3] += c.r[14];  // 06029564 add r14,r3
    c.r[12] = (uint32_t)(int16_t)ld16(0x06029668u);  // 06029566 mov.w 0x06029668,r12
    c.r[12] += c.r[14];  // 06029568 add r14,r12
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602956A mov.b @r1,r1
    c.r[10] = ld32(0x06029678u);  // 0602956C mov.l 0x06029678,r10
    c.r[1] = c.r[1] & 0xFFu;  // 0602956E extu.b r1,r1
    st32(c.r[0], c.r[1]);  // 06029570 mov.l r1,@r0
    c.r[3] = ld32(c.r[3]);  // 06029572 mov.l @r3,r3
    c.r[1] = 0x1Eu;  // 06029574 mov #30,r1
    c.macl = c.r[3] * c.r[1];  // 06029576 mul.l r1,r3
    c.r[5] = 0x1Bu;  // 06029578 mov #27,r5
    c.r[2] = ld32(c.r[13]);  // 0602957A mov.l @r13,r2
    c.r[9] = c.macl;  // 0602957C sts macl,r9
    c.r[0] = c.r[9];  // 0602957E mov r9,r0
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 06029580 mov.w @(r0,r2),r8
    c.r[4] = ld32(0x0602967Cu);  // 06029582 mov.l 0x0602967C,r4
    { const uint32_t x = c.r[10]; c.pr = 0x06029588u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06029588u) return; }  // 06029584 jsr @r10 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 06029588 mov r0,r1
    c.r[5] = c.r[8];  // 0602958A mov r8,r5
    { const uint32_t x = c.r[10]; c.pr = 0x06029590u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06029590u) return; }  // 0602958C jsr @r10 ; mov r1,r4
    c.r[1] = c.r[0];  // 06029590 mov r0,r1
    c.r[1] += 38;  // 06029592 add #38,r1
    c.r[5] = c.r[1];  // 06029594 mov r1,r5
    c.r[3] = ld32(0x06029680u);  // 06029596 mov.l 0x06029680,r3
    { const uint32_t x = c.r[3]; c.pr = 0x0602959Cu; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602959Cu) return; }  // 06029598 jsr @r3 ; mov r12,r4
    c.r[1] = c.r[0];  // 0602959C mov r0,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602966Au);  // 0602959E mov.w 0x0602966A,r0
    c.r[0] += c.r[14];  // 060295A0 add r14,r0
    c.r[3] = ld32(0x06029684u);  // 060295A2 mov.l 0x06029684,r3
    c.r[7] = 0x0u;  // 060295A4 mov #0,r7
    c.r[11] = ld32(c.r[0]);  // 060295A6 mov.l @r0,r11
    c.r[5] = c.r[1];  // 060295A8 mov r1,r5
    c.r[4] = ld32(c.r[3]);  // 060295AA mov.l @r3,r4
    c.r[0] = (uint32_t)(int16_t)ld16(0x06029666u);  // 060295AC mov.w 0x06029666,r0
    c.r[11] |= c.r[0];  // 060295AE or r0,r11
    c.r[0] = ld32(0x06029688u);  // 060295B0 mov.l 0x06029688,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060295B6u; c.r[6] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060295B6u) return; }  // 060295B2 jsr @r0 ; mov r11,r6
    c.r[6] = (uint32_t)(int16_t)ld16(0x0602966Cu);  // 060295B6 mov.w 0x0602966C,r6
    c.r[8] = (uint32_t)(int16_t)ld16(0x0602966Eu);  // 060295B8 mov.w 0x0602966E,r8
    c.r[8] += c.r[14];  // 060295BA add r14,r8
    c.r[1] = ld32(0x0602968Cu);  // 060295BC mov.l 0x0602968C,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x06029664u);  // 060295BE mov.w 0x06029664,r3
    c.r[3] += c.r[14];  // 060295C0 add r14,r3
    c.r[5] = ld32(c.r[3]);  // 060295C2 mov.l @r3,r5
    { const uint32_t x = c.r[1]; c.pr = 0x060295C8u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060295C8u) return; }  // 060295C4 jsr @r1 ; mov r8,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x06029670u);  // 060295C8 mov.w 0x06029670,r1
    c.r[0] = c.r[8];  // 060295CA mov r8,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060295CC mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 060295CE extu.b r1,r1
    c.r[1] >>= 2;  // 060295D0 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060295D2 shlr r1
    c.r[1] >>= 2;  // 060295D4 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060295D6 tst r1,r1
    { const bool k = !c.t; c.r[0] = c.r[9]; if (k) { goto L_0602961C; } }  // 060295D8 bf/s 0x0602961C ; mov r9,r0
    c.r[1] = ld32(c.r[13]);  // 060295DC mov.l @r13,r1
    c.r[5] = 0x1Bu;  // 060295DE mov #27,r5
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 060295E0 mov.w @(r0,r1),r8
    c.r[4] = ld32(0x0602967Cu);  // 060295E2 mov.l 0x0602967C,r4
    c.r[8] += 1;  // 060295E4 add #1,r8
    { const uint32_t x = c.r[10]; c.pr = 0x060295EAu; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060295EAu) return; }  // 060295E6 jsr @r10 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 060295EA mov r0,r1
    c.r[5] = c.r[8];  // 060295EC mov r8,r5
    { const uint32_t x = c.r[10]; c.pr = 0x060295F2u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060295F2u) return; }  // 060295EE jsr @r10 ; mov r1,r4
    c.r[1] = c.r[0];  // 060295F2 mov r0,r1
    c.r[1] += 38;  // 060295F4 add #38,r1
    c.r[5] = c.r[1];  // 060295F6 mov r1,r5
    c.r[3] = ld32(0x06029680u);  // 060295F8 mov.l 0x06029680,r3
    { const uint32_t x = c.r[3]; c.pr = 0x060295FEu; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060295FEu) return; }  // 060295FA jsr @r3 ; mov r12,r4
    c.r[1] = c.r[0];  // 060295FE mov r0,r1
    c.r[0] = ld32(0x06029684u);  // 06029600 mov.l 0x06029684,r0
    c.r[7] = 0x0u;  // 06029602 mov #0,r7
    c.r[6] = c.r[11];  // 06029604 mov r11,r6
    c.r[5] = c.r[1];  // 06029606 mov r1,r5
    c.r[3] = ld32(0x06029688u);  // 06029608 mov.l 0x06029688,r3
    { const uint32_t x = c.r[3]; c.pr = 0x0602960Eu; c.r[4] = ld32(c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602960Eu) return; }  // 0602960A jsr @r3 ; mov.l @r0,r4
    c.r[0] = c.r[9];  // 0602960E mov r9,r0
    c.r[1] = ld32(c.r[13]);  // 06029610 mov.l @r13,r1
    c.r[5] = 0x1Bu;  // 06029612 mov #27,r5
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06029614 mov.w @(r0,r1),r8
    c.r[4] = ld32(0x0602967Cu);  // 06029616 mov.l 0x0602967C,r4
    c.r[8] += 2; goto L_060296CE;  // 06029618 bra 0x060296CE ; add #2,r8
L_0602961C:
    c.r[0] = c.r[1];  // 0602961C mov r1,r0
    c.t = c.r[0] == 0x1u;  // 0602961E cmp/eq #1,r0
    { const bool k = !c.t; c.r[0] = c.r[9]; if (k) { goto L_06029690; } }  // 06029620 bf/s 0x06029690 ; mov r9,r0
    c.r[1] = ld32(c.r[13]);  // 06029624 mov.l @r13,r1
    c.r[5] = 0x1Bu;  // 06029626 mov #27,r5
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06029628 mov.w @(r0,r1),r8
    c.r[4] = ld32(0x0602967Cu);  // 0602962A mov.l 0x0602967C,r4
    c.r[8] -= 1;  // 0602962C add #-1,r8
    { const uint32_t x = c.r[10]; c.pr = 0x06029632u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06029632u) return; }  // 0602962E jsr @r10 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 06029632 mov r0,r1
    c.r[5] = c.r[8];  // 06029634 mov r8,r5
    { const uint32_t x = c.r[10]; c.pr = 0x0602963Au; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602963Au) return; }  // 06029636 jsr @r10 ; mov r1,r4
    c.r[1] = c.r[0];  // 0602963A mov r0,r1
    c.r[1] += 38;  // 0602963C add #38,r1
    c.r[5] = c.r[1];  // 0602963E mov r1,r5
    c.r[3] = ld32(0x06029680u);  // 06029640 mov.l 0x06029680,r3
    { const uint32_t x = c.r[3]; c.pr = 0x06029646u; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06029646u) return; }  // 06029642 jsr @r3 ; mov r12,r4
    c.r[1] = c.r[0];  // 06029646 mov r0,r1
    c.r[0] = ld32(0x06029684u);  // 06029648 mov.l 0x06029684,r0
    c.r[7] = 0x0u;  // 0602964A mov #0,r7
    c.r[6] = c.r[11];  // 0602964C mov r11,r6
    c.r[5] = c.r[1];  // 0602964E mov r1,r5
    c.r[3] = ld32(0x06029688u);  // 06029650 mov.l 0x06029688,r3
    { const uint32_t x = c.r[3]; c.pr = 0x06029656u; c.r[4] = ld32(c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06029656u) return; }  // 06029652 jsr @r3 ; mov.l @r0,r4
    c.r[0] = c.r[9];  // 06029656 mov r9,r0
    c.r[1] = ld32(c.r[13]);  // 06029658 mov.l @r13,r1
    c.r[5] = 0x1Bu;  // 0602965A mov #27,r5
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0602965C mov.w @(r0,r1),r8
    c.r[4] = ld32(0x0602967Cu);  // 0602965E mov.l 0x0602967C,r4
    c.r[8] += 1; goto L_060296CE;  // 06029660 bra 0x060296CE ; add #1,r8
L_06029690:
    c.r[1] = ld32(c.r[13]);  // 06029690 mov.l @r13,r1
    c.r[5] = 0x1Bu;  // 06029692 mov #27,r5
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06029694 mov.w @(r0,r1),r8
    c.r[4] = ld32(0x060296FCu);  // 06029696 mov.l 0x060296FC,r4
    c.r[8] -= 2;  // 06029698 add #-2,r8
    { const uint32_t x = c.r[10]; c.pr = 0x0602969Eu; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602969Eu) return; }  // 0602969A jsr @r10 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 0602969E mov r0,r1
    c.r[5] = c.r[8];  // 060296A0 mov r8,r5
    { const uint32_t x = c.r[10]; c.pr = 0x060296A6u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060296A6u) return; }  // 060296A2 jsr @r10 ; mov r1,r4
    c.r[1] = c.r[0];  // 060296A6 mov r0,r1
    c.r[1] += 38;  // 060296A8 add #38,r1
    c.r[5] = c.r[1];  // 060296AA mov r1,r5
    c.r[3] = ld32(0x06029700u);  // 060296AC mov.l 0x06029700,r3
    { const uint32_t x = c.r[3]; c.pr = 0x060296B2u; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060296B2u) return; }  // 060296AE jsr @r3 ; mov r12,r4
    c.r[1] = c.r[0];  // 060296B2 mov r0,r1
    c.r[0] = ld32(0x06029704u);  // 060296B4 mov.l 0x06029704,r0
    c.r[7] = 0x0u;  // 060296B6 mov #0,r7
    c.r[6] = c.r[11];  // 060296B8 mov r11,r6
    c.r[5] = c.r[1];  // 060296BA mov r1,r5
    c.r[3] = ld32(0x06029708u);  // 060296BC mov.l 0x06029708,r3
    { const uint32_t x = c.r[3]; c.pr = 0x060296C2u; c.r[4] = ld32(c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060296C2u) return; }  // 060296BE jsr @r3 ; mov.l @r0,r4
    c.r[0] = c.r[9];  // 060296C2 mov r9,r0
    c.r[1] = ld32(c.r[13]);  // 060296C4 mov.l @r13,r1
    c.r[5] = 0x1Bu;  // 060296C6 mov #27,r5
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 060296C8 mov.w @(r0,r1),r8
    c.r[4] = ld32(0x060296FCu);  // 060296CA mov.l 0x060296FC,r4
    c.r[8] -= 1;  // 060296CC add #-1,r8
L_060296CE:
    { const uint32_t x = c.r[10]; c.pr = 0x060296D2u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060296D2u) return; }  // 060296CE jsr @r10 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 060296D2 mov r0,r1
    c.r[5] = c.r[8];  // 060296D4 mov r8,r5
    { const uint32_t x = c.r[10]; c.pr = 0x060296DAu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060296DAu) return; }  // 060296D6 jsr @r10 ; mov r1,r4
    c.r[1] = c.r[0];  // 060296DA mov r0,r1
    c.r[1] += 38;  // 060296DC add #38,r1
    c.r[5] = c.r[1];  // 060296DE mov r1,r5
    c.r[3] = ld32(0x06029700u);  // 060296E0 mov.l 0x06029700,r3
    { const uint32_t x = c.r[3]; c.pr = 0x060296E6u; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060296E6u) return; }  // 060296E2 jsr @r3 ; mov r12,r4
    c.r[1] = c.r[0];  // 060296E6 mov r0,r1
    c.r[0] = ld32(0x06029704u);  // 060296E8 mov.l 0x06029704,r0
    c.r[7] = 0x0u;  // 060296EA mov #0,r7
    c.r[6] = c.r[11];  // 060296EC mov r11,r6
    c.r[5] = c.r[1];  // 060296EE mov r1,r5
    c.r[3] = ld32(0x06029708u);  // 060296F0 mov.l 0x06029708,r3
    { const uint32_t x = c.r[3]; c.pr = 0x060296F6u; c.r[4] = ld32(c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060296F6u) return; }  // 060296F2 jsr @r3 ; mov.l @r0,r4
    c.r[8] = 0x0u; goto L_06029874;  // 060296F6 bra 0x06029874 ; mov #0,r8
L_0602970C:
    c.r[7] = 0x0u;  // 0602970C mov #0,r7
    c.r[6] = 0x0u;  // 0602970E mov #0,r6
    c.r[8] = ld32(0x060298C0u);  // 06029710 mov.l 0x060298C0,r8
    c.r[4] = c.r[14];  // 06029712 mov r14,r4
    c.r[4] += 1;  // 06029714 add #1,r4
    c.r[5] = 0x0u;  // 06029716 mov #0,r5
    c.r[10] = 0x0u;  // 06029718 mov #0,r10
L_0602971A:
    c.r[1] = ld32(c.r[8]);  // 0602971A mov.l @r8,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060298B2u);  // 0602971C mov.w 0x060298B2,r0
    c.r[1] += c.r[5];  // 0602971E add r5,r1
    c.r[1] += 16;  // 06029720 add #16,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06029722 mov.b @r1,r1
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06029724 mov.l @(r0,r14),r0
    c.r[1] = c.r[1] & 0xFFu;  // 06029726 extu.b r1,r1
    c.t = c.r[0] == c.r[1];  // 06029728 cmp/eq r1,r0
    { const bool k = !c.t; c.r[1] = c.r[7] & 0xFFFFu; if (k) { goto L_06029748; } }  // 0602972A bf/s 0x06029748 ; extu.w r7,r1
    c.r[9] = c.r[1];  // 0602972E mov r1,r9
    c.r[9] >>= 8;  // 06029730 shlr8 r9
    c.r[3] = 0x7Fu;  // 06029732 mov #127,r3
    c.r[9] &= c.r[3];  // 06029734 and r3,r9
    c.r[0] = c.r[10];  // 06029736 mov r10,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 06029738 mov.b @(r0,r14),r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x060298B4u);  // 0602973A mov.w 0x060298B4,r3
    c.r[10] += 2;  // 0602973C add #2,r10
    c.r[6] += 1;  // 0602973E add #1,r6
    c.r[2] &= c.r[3];  // 06029740 and r3,r2
    c.r[2] |= c.r[9];  // 06029742 or r9,r2
    st8(c.r[0] + c.r[14], c.r[2]);  // 06029744 mov.b r2,@(r0,r14)
    st8(c.r[0] + c.r[4], c.r[1]);  // 06029746 mov.b r1,@(r0,r4)
L_06029748:
    c.r[7] += 1;  // 06029748 add #1,r7
    c.r[1] = 0x7Fu;  // 0602974A mov #127,r1
    c.t = (int32_t)c.r[7] > (int32_t)c.r[1];  // 0602974C cmp/gt r1,r7
    { const bool k = !c.t; c.r[5] += 30; if (k) { SH2_POLL(c); goto L_0602971A; } }  // 0602974E bf/s 0x0602971A ; add #30,r5
    c.r[1] = 0x4u;  // 06029752 mov #4,r1
    c.t = (int32_t)c.r[6] > (int32_t)c.r[1];  // 06029754 cmp/gt r1,r6
    { const bool k = c.t; c.r[1] = c.r[14]; if (k) { goto L_0602975E; } }  // 06029756 bt/s 0x0602975E ; mov r14,r1
    goto L_06029872;  // 0602975A bra 0x06029872 ; nop
L_0602975E:
    c.r[1] += 1;  // 0602975E add #1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060298B2u);  // 06029760 mov.w 0x060298B2,r0
    c.r[0] += c.r[14];  // 06029762 add r14,r0
    c.r[3] = ld32(0x060298C0u);  // 06029764 mov.l 0x060298C0,r3
    c.r[9] = ld32(0x060298C4u);  // 06029766 mov.l 0x060298C4,r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06029768 mov.b @r1,r1
    c.r[5] = 0x1Bu;  // 0602976A mov #27,r5
    c.r[1] = c.r[1] & 0xFFu;  // 0602976C extu.b r1,r1
    st32(c.r[0], c.r[1]);  // 0602976E mov.l r1,@r0
    c.r[0] = (uint32_t)(int16_t)ld16(0x060298B2u);  // 06029770 mov.w 0x060298B2,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06029772 mov.l @(r0,r14),r0
    c.r[1] = 0x1Eu;  // 06029774 mov #30,r1
    c.r[2] = ld32(c.r[3]);  // 06029776 mov.l @r3,r2
    c.macl = c.r[0] * c.r[1];  // 06029778 mul.l r1,r0
    c.r[3] = (uint32_t)(int16_t)ld16(0x060298B6u);  // 0602977A mov.w 0x060298B6,r3
    c.r[3] += c.r[14];  // 0602977C add r14,r3
    c.r[0] = c.macl;  // 0602977E sts macl,r0
    st32(c.r[3], c.r[0]);  // 06029780 mov.l r0,@r3
    c.r[3] = (uint32_t)(int16_t)ld16(0x060298B6u);  // 06029782 mov.w 0x060298B6,r3
    c.r[3] += c.r[14];  // 06029784 add r14,r3
    c.r[0] = ld32(c.r[3]);  // 06029786 mov.l @r3,r0
    c.r[4] = ld32(0x060298C8u);  // 06029788 mov.l 0x060298C8,r4
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 0602978A mov.w @(r0,r2),r8
    c.r[3] = (uint32_t)(int16_t)ld16(0x060298B8u);  // 0602978C mov.w 0x060298B8,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x060298BAu);  // 0602978E mov.w 0x060298BA,r0
    st32(c.r[0] + c.r[14], c.r[3]);  // 06029790 mov.l r3,@(r0,r14)
    c.r[0] = (uint32_t)(int16_t)ld16(0x060298BAu);  // 06029792 mov.w 0x060298BA,r0
    c.r[0] += c.r[14];  // 06029794 add r14,r0
    c.r[3] = ld32(c.r[0]);  // 06029796 mov.l @r0,r3
    c.r[8] = c.r[8] & 0xFFFFu;  // 06029798 extu.w r8,r8
    c.r[3] += c.r[14];  // 0602979A add r14,r3
    { const uint32_t x = c.r[9]; c.pr = 0x060297A0u; st32(c.r[0], c.r[3]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060297A0u) return; }  // 0602979C jsr @r9 ; mov.l r3,@r0
    c.r[1] = c.r[0];  // 060297A0 mov r0,r1
    c.r[5] = c.r[8];  // 060297A2 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x060297A8u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060297A8u) return; }  // 060297A4 jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 060297A8 mov r0,r1
    c.r[1] += 38;  // 060297AA add #38,r1
    c.r[13] = ld32(0x060298CCu);  // 060297AC mov.l 0x060298CC,r13
    c.r[0] = (uint32_t)(int16_t)ld16(0x060298BAu);  // 060297AE mov.w 0x060298BA,r0
    c.r[4] = ld32(c.r[0] + c.r[14]);  // 060297B0 mov.l @(r0,r14),r4
    { const uint32_t x = c.r[13]; c.pr = 0x060297B6u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060297B6u) return; }  // 060297B2 jsr @r13 ; mov r1,r5
    c.r[1] = c.r[0];  // 060297B6 mov r0,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x060298BCu);  // 060297B8 mov.w 0x060298BC,r3
    c.r[3] += c.r[14];  // 060297BA add r14,r3
    c.r[10] = ld32(0x060298D0u);  // 060297BC mov.l 0x060298D0,r10
    c.r[12] = ld32(0x060298D4u);  // 060297BE mov.l 0x060298D4,r12
    c.r[7] = 0x0u;  // 060297C0 mov #0,r7
    c.r[11] = ld32(c.r[3]);  // 060297C2 mov.l @r3,r11
    c.r[5] = c.r[1];  // 060297C4 mov r1,r5
    c.r[4] = ld32(c.r[10]);  // 060297C6 mov.l @r10,r4
    c.r[3] = (uint32_t)(int16_t)ld16(0x060298B4u);  // 060297C8 mov.w 0x060298B4,r3
    c.r[11] |= c.r[3];  // 060297CA or r3,r11
    { const uint32_t x = c.r[12]; c.pr = 0x060297D0u; c.r[6] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060297D0u) return; }  // 060297CC jsr @r12 ; mov r11,r6
    c.r[0] = ld32(0x060298C0u);  // 060297D0 mov.l 0x060298C0,r0
    c.r[3] = (uint32_t)(int16_t)ld16(0x060298B6u);  // 060297D2 mov.w 0x060298B6,r3
    c.r[1] = ld32(c.r[0]);  // 060297D4 mov.l @r0,r1
    c.r[3] += c.r[14];  // 060297D6 add r14,r3
    c.r[0] = ld32(c.r[3]);  // 060297D8 mov.l @r3,r0
    c.r[5] = 0x1Bu;  // 060297DA mov #27,r5
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 060297DC mov.w @(r0,r1),r8
    c.r[4] = ld32(0x060298C8u);  // 060297DE mov.l 0x060298C8,r4
    c.r[8] += 1;  // 060297E0 add #1,r8
    { const uint32_t x = c.r[9]; c.pr = 0x060297E6u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060297E6u) return; }  // 060297E2 jsr @r9 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 060297E6 mov r0,r1
    c.r[5] = c.r[8];  // 060297E8 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x060297EEu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060297EEu) return; }  // 060297EA jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 060297EE mov r0,r1
    c.r[1] += 38;  // 060297F0 add #38,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060298BAu);  // 060297F2 mov.w 0x060298BA,r0
    c.r[4] = ld32(c.r[0] + c.r[14]);  // 060297F4 mov.l @(r0,r14),r4
    { const uint32_t x = c.r[13]; c.pr = 0x060297FAu; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060297FAu) return; }  // 060297F6 jsr @r13 ; mov r1,r5
    c.r[1] = c.r[0];  // 060297FA mov r0,r1
    c.r[7] = 0x0u;  // 060297FC mov #0,r7
    c.r[6] = c.r[11];  // 060297FE mov r11,r6
    c.r[4] = ld32(c.r[10]);  // 06029800 mov.l @r10,r4
    { const uint32_t x = c.r[12]; c.pr = 0x06029806u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06029806u) return; }  // 06029802 jsr @r12 ; mov r1,r5
    c.r[3] = ld32(0x060298C0u);  // 06029806 mov.l 0x060298C0,r3
    c.r[1] = ld32(c.r[3]);  // 06029808 mov.l @r3,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x060298B6u);  // 0602980A mov.w 0x060298B6,r3
    c.r[3] += c.r[14];  // 0602980C add r14,r3
    c.r[0] = ld32(c.r[3]);  // 0602980E mov.l @r3,r0
    c.r[5] = 0x1Bu;  // 06029810 mov #27,r5
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06029812 mov.w @(r0,r1),r8
    c.r[4] = ld32(0x060298C8u);  // 06029814 mov.l 0x060298C8,r4
    c.r[8] += 2;  // 06029816 add #2,r8
    { const uint32_t x = c.r[9]; c.pr = 0x0602981Cu; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602981Cu) return; }  // 06029818 jsr @r9 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 0602981C mov r0,r1
    c.r[5] = c.r[8];  // 0602981E mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06029824u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06029824u) return; }  // 06029820 jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 06029824 mov r0,r1
    c.r[1] += 38;  // 06029826 add #38,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060298BAu);  // 06029828 mov.w 0x060298BA,r0
    c.r[4] = ld32(c.r[0] + c.r[14]);  // 0602982A mov.l @(r0,r14),r4
    { const uint32_t x = c.r[13]; c.pr = 0x06029830u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06029830u) return; }  // 0602982C jsr @r13 ; mov r1,r5
    c.r[1] = c.r[0];  // 06029830 mov r0,r1
    c.r[7] = 0x0u;  // 06029832 mov #0,r7
    c.r[6] = c.r[11];  // 06029834 mov r11,r6
    c.r[4] = ld32(c.r[10]);  // 06029836 mov.l @r10,r4
    { const uint32_t x = c.r[12]; c.pr = 0x0602983Cu; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602983Cu) return; }  // 06029838 jsr @r12 ; mov r1,r5
    c.r[3] = ld32(0x060298C0u);  // 0602983C mov.l 0x060298C0,r3
    c.r[1] = ld32(c.r[3]);  // 0602983E mov.l @r3,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x060298B6u);  // 06029840 mov.w 0x060298B6,r3
    c.r[3] += c.r[14];  // 06029842 add r14,r3
    c.r[0] = ld32(c.r[3]);  // 06029844 mov.l @r3,r0
    c.r[5] = 0x1Bu;  // 06029846 mov #27,r5
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06029848 mov.w @(r0,r1),r8
    c.r[4] = ld32(0x060298C8u);  // 0602984A mov.l 0x060298C8,r4
    c.r[8] += 3;  // 0602984C add #3,r8
    { const uint32_t x = c.r[9]; c.pr = 0x06029852u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06029852u) return; }  // 0602984E jsr @r9 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 06029852 mov r0,r1
    c.r[5] = c.r[8];  // 06029854 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0602985Au; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602985Au) return; }  // 06029856 jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 0602985A mov r0,r1
    c.r[1] += 38;  // 0602985C add #38,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060298BAu);  // 0602985E mov.w 0x060298BA,r0
    c.r[4] = ld32(c.r[0] + c.r[14]);  // 06029860 mov.l @(r0,r14),r4
    { const uint32_t x = c.r[13]; c.pr = 0x06029866u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06029866u) return; }  // 06029862 jsr @r13 ; mov r1,r5
    c.r[1] = c.r[0];  // 06029866 mov r0,r1
    c.r[7] = 0x0u;  // 06029868 mov #0,r7
    c.r[6] = c.r[11];  // 0602986A mov r11,r6
    c.r[4] = ld32(c.r[10]);  // 0602986C mov.l @r10,r4
L_0602986E:
    { const uint32_t x = c.r[12]; c.pr = 0x06029872u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06029872u) return; }  // 0602986E jsr @r12 ; mov r1,r5
L_06029872:
    c.r[8] = 0x0u;  // 06029872 mov #0,r8
L_06029874:
    c.r[9] = ld32(0x060298D8u);  // 06029874 mov.l 0x060298D8,r9
L_06029876:
    c.r[1] = ld32(0x060298C0u);  // 06029876 mov.l 0x060298C0,r1
    c.r[2] = ld32(c.r[1]);  // 06029878 mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 0602987A mov #30,r1
    c.macl = c.r[8] * c.r[1];  // 0602987C mul.l r1,r8
    c.r[3] = (uint32_t)(int16_t)ld16(0x060298B2u);  // 0602987E mov.w 0x060298B2,r3
    c.r[1] = c.macl;  // 06029880 sts macl,r1
    c.r[1] += c.r[2];  // 06029882 add r2,r1
    c.r[1] += 16;  // 06029884 add #16,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06029886 mov.b @r1,r1
    c.r[3] += c.r[14];  // 06029888 add r14,r3
    c.r[3] = ld32(c.r[3]);  // 0602988A mov.l @r3,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0602988C extu.b r1,r1
    c.t = c.r[1] == c.r[3];  // 0602988E cmp/eq r3,r1
    { const bool k = !c.t; c.r[1] = c.r[8]; if (k) { goto L_060298A8; } }  // 06029890 bf/s 0x060298A8 ; mov r8,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060298BCu);  // 06029894 mov.w 0x060298BC,r0
    c.r[6] = ld32(c.r[0] + c.r[14]);  // 06029896 mov.l @(r0,r14),r6
    c.r[0] = (uint32_t)(int16_t)ld16(0x060298B4u);  // 06029898 mov.w 0x060298B4,r0
    c.r[6] |= c.r[0];  // 0602989A or r0,r6
    c.r[1] = ld32(0x060298D0u);  // 0602989C mov.l 0x060298D0,r1
    c.r[4] = ld32(c.r[1]);  // 0602989E mov.l @r1,r4
    c.r[6] = c.r[6] & 0xFFu;  // 060298A0 extu.b r6,r6
    { const uint32_t x = c.r[9]; c.pr = 0x060298A6u; c.r[5] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060298A6u) return; }  // 060298A2 jsr @r9 ; mov r8,r5
    c.r[1] = c.r[8];  // 060298A6 mov r8,r1
L_060298A8:
    c.r[1] += 1;  // 060298A8 add #1,r1
    c.r[8] = c.r[1] & 0xFFu;  // 060298AA extu.b r1,r8
    c.r[1] = 0x7Fu;  // 060298AC mov #127,r1
    c.t = c.r[8] > c.r[1]; goto L_060298DC;  // 060298AE bra 0x060298DC ; cmp/hi r1,r8
L_060298DC:
    if (!c.t) { SH2_POLL(c); goto L_06029876; }  // 060298DC bf 0x06029876
    c.r[3] = (uint32_t)(int16_t)ld16(0x060298F6u);  // 060298DE mov.w 0x060298F6,r3
    c.r[14] += c.r[3];  // 060298E0 add r3,r14
    c.r[15] = c.r[14];  // 060298E2 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060298E4 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060298E6 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060298E8 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060298EA mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060298EC mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060298EE mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060298F0 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060298F2 rts ; mov.l @r15+,r8
}

void f_060298F8(SH2Context& c) {
    ran[553] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060298F8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060298FA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060298FC mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060298FE mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06029900 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06029902 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06029904 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06029906 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06029908 mov r15,r14
    c.r[13] = c.r[4] & 0xFFu;  // 0602990A extu.b r4,r13
    c.r[11] = c.r[5] & 0xFFu;  // 0602990C extu.b r5,r11
    c.r[9] = c.r[6] & 0xFFu;  // 0602990E extu.b r6,r9
    c.r[10] = ld32(0x06029A58u);  // 06029910 mov.l 0x06029A58,r10
    c.r[8] = c.r[9];  // 06029912 mov r9,r8
    c.r[8] += c.r[8];  // 06029914 add r8,r8
    c.r[8] += c.r[9];  // 06029916 add r9,r8
    c.r[8] <<= 2;  // 06029918 shll2 r8
    c.r[2] = ld32(c.r[10]);  // 0602991A mov.l @r10,r2
    c.r[12] = ld32(0x06029A5Cu);  // 0602991C mov.l 0x06029A5C,r12
    c.r[1] = ld32(c.r[12]);  // 0602991E mov.l @r12,r1
    c.r[2] += c.r[8];  // 06029920 add r8,r2
    c.r[1] += 12;  // 06029922 add #12,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06029924 mov.w @r1,r1
    c.r[2] += 10;  // 06029926 add #10,r2
    st16(c.r[2], c.r[1]);  // 06029928 mov.w r1,@r2
    c.r[1] = ld32(0x06029A60u);  // 0602992A mov.l 0x06029A60,r1
    c.r[4] = ld32(c.r[1]);  // 0602992C mov.l @r1,r4
    c.r[1] = ld32(0x06029A64u);  // 0602992E mov.l 0x06029A64,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06029934u; c.r[5] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06029934u) return; }  // 06029930 jsr @r1 ; mov r11,r5
    c.r[1] = ld32(c.r[10]);  // 06029934 mov.l @r10,r1
    c.r[8] += c.r[1];  // 06029936 add r1,r8
    c.r[8] += 8;  // 06029938 add #8,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0602993A mov.b @r8,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06029A50u);  // 0602993C mov.w 0x06029A50,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0602993E extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 06029940 cmp/eq r2,r1
    { const bool k = c.t; c.r[2] = c.r[9]; if (k) { goto L_0602999A; } }  // 06029942 bt/s 0x0602999A ; mov r9,r2
L_06029946:
    c.r[2] += c.r[2];  // 06029946 add r2,r2
    c.r[2] += c.r[9];  // 06029948 add r9,r2
    c.r[1] = ld32(c.r[10]);  // 0602994A mov.l @r10,r1
    c.r[2] <<= 2;  // 0602994C shll2 r2
    c.r[2] += c.r[1];  // 0602994E add r1,r2
    c.r[2] += 8;  // 06029950 add #8,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06029952 mov.b @r2,r1
    c.r[4] = ld32(c.r[12]);  // 06029954 mov.l @r12,r4
    c.r[9] = c.r[1] & 0xFFu;  // 06029956 extu.b r1,r9
    c.r[8] = c.r[9] & 0xFFu;  // 06029958 extu.b r9,r8
    c.r[1] = ld32(0x06029A68u);  // 0602995A mov.l 0x06029A68,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06029960u; c.r[5] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06029960u) return; }  // 0602995C jsr @r1 ; mov r8,r5
    c.r[2] = c.r[8];  // 06029960 mov r8,r2
    c.r[2] += c.r[2];  // 06029962 add r2,r2
    c.r[2] += c.r[8];  // 06029964 add r8,r2
    c.r[1] = ld32(c.r[10]);  // 06029966 mov.l @r10,r1
    c.r[2] <<= 2;  // 06029968 shll2 r2
    c.r[2] += c.r[1];  // 0602996A add r1,r2
    c.r[1] = ld32(c.r[12]);  // 0602996C mov.l @r12,r1
    c.r[1] += 12;  // 0602996E add #12,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06029970 mov.w @r1,r1
    c.r[2] += 10;  // 06029972 add #10,r2
    st16(c.r[2], c.r[1]);  // 06029974 mov.w r1,@r2
    c.r[1] = ld32(0x06029A60u);  // 06029976 mov.l 0x06029A60,r1
    c.r[4] = ld32(c.r[1]);  // 06029978 mov.l @r1,r4
    c.r[1] = ld32(0x06029A64u);  // 0602997A mov.l 0x06029A64,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06029980u; c.r[5] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06029980u) return; }  // 0602997C jsr @r1 ; mov r11,r5
    c.r[2] = c.r[9];  // 06029980 mov r9,r2
    c.r[2] += c.r[2];  // 06029982 add r2,r2
    c.r[2] += c.r[9];  // 06029984 add r9,r2
    c.r[1] = ld32(c.r[10]);  // 06029986 mov.l @r10,r1
    c.r[2] <<= 2;  // 06029988 shll2 r2
    c.r[2] += c.r[1];  // 0602998A add r1,r2
    c.r[2] += 8;  // 0602998C add #8,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602998E mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06029990 extu.b r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06029A50u);  // 06029992 mov.w 0x06029A50,r2
    c.t = c.r[1] == c.r[2];  // 06029994 cmp/eq r2,r1
    { const bool k = !c.t; c.r[2] = c.r[9]; if (k) { SH2_POLL(c); goto L_06029946; } }  // 06029996 bf/s 0x06029946 ; mov r9,r2
L_0602999A:
    c.r[1] = ld32(0x06029A6Cu);  // 0602999A mov.l 0x06029A6C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060299A0u; c.r[4] = c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060299A0u) return; }  // 0602999C jsr @r1 ; mov r13,r4
    c.r[1] = ld32(0x06029A70u);  // 060299A0 mov.l 0x06029A70,r1
    c.r[2] = ld32(c.r[1]);  // 060299A2 mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 060299A4 mov #30,r1
    c.macl = c.r[11] * c.r[1];  // 060299A6 mul.l r1,r11
    c.r[9] = c.r[9] & 0xFFu;  // 060299A8 extu.b r9,r9
    c.r[1] = c.macl;  // 060299AA sts macl,r1
    c.r[0] = c.r[1];  // 060299AC mov r1,r0
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 060299AE mov.w @(r0,r2),r5
    c.r[4] = 0x0u;  // 060299B0 mov #0,r4
    c.r[0] = ld32(0x06029A74u);  // 060299B2 mov.l 0x06029A74,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060299B8u; c.r[5] = c.r[5] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060299B8u) return; }  // 060299B4 jsr @r0 ; extu.w r5,r5
    c.r[1] = c.r[0];  // 060299B8 mov r0,r1
    c.r[8] = c.r[1] & 0xFFFFu;  // 060299BA extu.w r1,r8
    c.r[1] = ld32(0x06029A78u);  // 060299BC mov.l 0x06029A78,r1
    c.t = c.r[8] == c.r[1];  // 060299BE cmp/eq r1,r8
    if (c.t) { goto L_06029A3C; }  // 060299C0 bt 0x06029A3C
    c.r[0] = ld32(0x06029A7Cu);  // 060299C2 mov.l 0x06029A7C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060299C8u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060299C8u) return; }  // 060299C4 jsr @r0 ; mov r9,r4
    c.r[2] = c.r[0];  // 060299C8 mov r0,r2
    c.r[3] = ld32(0x06029A80u);  // 060299CA mov.l 0x06029A80,r3
    c.r[7] = c.r[8];  // 060299CC mov r8,r7
    c.r[7] <<= 2;  // 060299CE shll2 r7
    c.r[6] = c.r[8];  // 060299D0 mov r8,r6
    c.r[6] += c.r[6];  // 060299D2 add r6,r6
    c.r[1] = ld32(0x06029A84u);  // 060299D4 mov.l 0x06029A84,r1
    c.r[2] = c.r[2] & 0xFFu;  // 060299D6 extu.b r2,r2
    c.r[0] = c.r[6];  // 060299D8 mov r6,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 060299DA mov.w @(r0,r1),r1
    c.r[7] += c.r[3];  // 060299DC add r3,r7
    c.r[1] += c.r[2];  // 060299DE add r2,r1
    c.r[6] = c.r[1] & 0xFFFFu;  // 060299E0 extu.w r1,r6
    c.r[5] = c.r[6];  // 060299E2 mov r6,r5
    c.r[5] >>= 2;  // 060299E4 shlr2 r5
    c.t = c.r[5] & 1; c.r[5] >>= 1;  // 060299E6 shlr r5
    c.r[5] >>= 2;  // 060299E8 shlr2 r5
    c.r[0] = 0x1Fu;  // 060299EA mov #31,r0
    c.r[5] &= c.r[0];  // 060299EC and r0,r5
    c.r[2] = c.r[7];  // 060299EE mov r7,r2
    c.r[2] += 2;  // 060299F0 add #2,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06029A52u);  // 060299F2 mov.w 0x06029A52,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060299F4 mov.b @r2,r1
    c.r[7] += 3;  // 060299F6 add #3,r7
    c.r[1] &= c.r[0];  // 060299F8 and r0,r1
    c.r[1] |= c.r[5];  // 060299FA or r5,r1
    st8(c.r[2], c.r[1]);  // 060299FC mov.b r1,@r2
    c.r[0] = 0x1Fu;  // 060299FE mov #31,r0
    c.r[6] &= c.r[0];  // 06029A00 and r0,r6
    c.r[6] <<= 2;  // 06029A02 shll2 r6
    c.r[6] += c.r[6];  // 06029A04 add r6,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06029A06 mov.b @r7,r1
    c.r[5] = 0x7u;  // 06029A08 mov #7,r5
    c.r[5] &= c.r[1];  // 06029A0A and r1,r5
    c.r[5] |= c.r[6];  // 06029A0C or r6,r5
    st8(c.r[7], c.r[5]);  // 06029A0E mov.b r5,@r7
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06029A10 mov.b @r2,r3
    c.r[1] = 0x1Fu;  // 06029A12 mov #31,r1
    c.r[1] &= c.r[3];  // 06029A14 and r3,r1
    c.r[1] <<= 2;  // 06029A16 shll2 r1
    c.r[1] += c.r[1];  // 06029A18 add r1,r1
    c.r[1] <<= 2;  // 06029A1A shll2 r1
    c.r[5] >>= 2;  // 06029A1C shlr2 r5
    c.t = c.r[5] & 1; c.r[5] >>= 1;  // 06029A1E shlr r5
    c.r[5] |= c.r[1];  // 06029A20 or r1,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x06029A54u);  // 06029A22 mov.w 0x06029A54,r1
    c.t = c.r[5] > c.r[1];  // 06029A24 cmp/hi r1,r5
    { const bool k = !c.t; c.r[0] = c.r[3]; if (k) { goto L_06029A36; } }  // 06029A26 bf/s 0x06029A36 ; mov r3,r0
    c.r[0] |= 0x1Fu;  // 06029A2A or #31,r0
    st8(c.r[2], c.r[0]);  // 06029A2C mov.b r0,@r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06029A2E mov.b @r7,r0
    c.r[0] &= 0x7u;  // 06029A30 and #7,r0
    c.r[0] |= 0x38u;  // 06029A32 or #56,r0
    st8(c.r[7], c.r[0]);  // 06029A34 mov.b r0,@r7
L_06029A36:
    c.r[1] = ld32(0x06029A88u);  // 06029A36 mov.l 0x06029A88,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06029A3Cu; c.r[4] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06029A3Cu) return; }  // 06029A38 jsr @r1 ; extu.w r8,r4
L_06029A3C:
    c.r[15] = c.r[14];  // 06029A3C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06029A3E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06029A40 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06029A42 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06029A44 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06029A46 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06029A48 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06029A4A mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06029A4C rts ; mov.l @r15+,r8
}

void f_06029A8C(SH2Context& c) {
    ran[554] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06029A8C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06029A8E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06029A90 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06029A92 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06029A94 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06029A96 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06029A98 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06029A9A sts.l pr,@-r15
    c.r[15] -= 12;  // 06029A9C add #-12,r15
    c.r[14] = c.r[15];  // 06029A9E mov r15,r14
    c.r[11] = c.r[5] & 0xFFu;  // 06029AA0 extu.b r5,r11
    c.r[6] = c.r[6] & 0xFFu;  // 06029AA2 extu.b r6,r6
    st8(c.r[14], c.r[6]);  // 06029AA4 mov.b r6,@r14
    c.r[7] = c.r[7] & 0xFFu;  // 06029AA6 extu.b r7,r7
    c.r[1] = ld32(c.r[14] + 44);  // 06029AA8 mov.l @(44,r14),r1
    c.r[3] = c.r[14];  // 06029AAA mov r14,r3
    c.r[2] = ld32(c.r[14] + 48);  // 06029AAC mov.l @(48,r14),r2
    c.r[3] += 1;  // 06029AAE add #1,r3
    st8(c.r[3], c.r[7]);  // 06029AB0 mov.b r7,@r3
    c.r[1] = c.r[1] & 0xFFu;  // 06029AB2 extu.b r1,r1
    st32(c.r[14] + 4, c.r[1]);  // 06029AB4 mov.l r1,@(4,r14)
    c.r[2] = c.r[2] & 0xFFu;  // 06029AB6 extu.b r2,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06029B62u);  // 06029AB8 mov.w 0x06029B62,r1
    c.t = c.r[6] == c.r[1];  // 06029ABA cmp/eq r1,r6
    { const bool k = !c.t; st32(c.r[14] + 8, c.r[2]); if (k) { goto L_06029AD0; } }  // 06029ABC bf/s 0x06029AD0 ; mov.l r2,@(8,r14)
    c.r[1] = c.r[7];  // 06029AC0 mov r7,r1
    c.t = c.r[1] == c.r[6];  // 06029AC2 cmp/eq r6,r1
    if (!c.t) { goto L_06029AD0; }  // 06029AC4 bf 0x06029AD0
    c.r[1] = ld32(0x06029B68u);  // 06029AC6 mov.l 0x06029B68,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 06029AC8 mov.b @r1+,r2
    st8(c.r[14], c.r[2]);  // 06029ACA mov.b r2,@r14
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06029ACC mov.b @r1,r1
    st8(c.r[3], c.r[1]);  // 06029ACE mov.b r1,@r3
L_06029AD0:
    c.r[1] = ld32(0x06029B6Cu);  // 06029AD0 mov.l 0x06029B6C,r1
    c.r[2] = ld32(c.r[1]);  // 06029AD2 mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 06029AD4 mov #30,r1
    c.macl = c.r[11] * c.r[1];  // 06029AD6 mul.l r1,r11
    c.r[1] = c.macl;  // 06029AD8 sts macl,r1
    c.r[1] += c.r[2];  // 06029ADA add r2,r1
    c.r[1] += 15;  // 06029ADC add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06029ADE mov.b @r1,r1
    c.t = (c.r[4] & c.r[4]) == 0;  // 06029AE0 tst r4,r4
    { const bool k = !c.t; c.r[12] = c.r[1] & 0xFFu; if (k) { goto L_06029AEC; } }  // 06029AE2 bf/s 0x06029AEC ; extu.b r1,r12
    c.r[0] = ld32(0x06029B70u);  // 06029AE6 mov.l 0x06029B70,r0
    goto L_06029AEE;  // 06029AE8 bra 0x06029AEE ; nop
L_06029AEC:
    c.r[0] = ld32(0x06029B74u);  // 06029AEC mov.l 0x06029B74,r0
L_06029AEE:
    { const uint32_t x = c.r[0]; c.pr = 0x06029AF2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06029AF2u) return; }  // 06029AEE jsr @r0 ; nop
    c.r[9] = c.r[0] & 0xFFu;  // 06029AF2 extu.b r0,r9
    c.r[1] = (uint32_t)(int16_t)ld16(0x06029B64u);  // 06029AF4 mov.w 0x06029B64,r1
    c.t = c.r[9] == c.r[1];  // 06029AF6 cmp/eq r1,r9
    { const bool k = !c.t; c.r[0] = c.r[9]; if (k) { goto L_06029B00; } }  // 06029AF8 bf/s 0x06029B00 ; mov r9,r0
    goto L_06029DF2;  // 06029AFC bra 0x06029DF2 ; nop
L_06029B00:
    c.t = c.r[12] == c.r[1];  // 06029B00 cmp/eq r1,r12
    { const bool k = !c.t; c.r[6] = c.r[9]; if (k) { goto L_06029B0A; } }  // 06029B02 bf/s 0x06029B0A ; mov r9,r6
    goto L_06029DF2;  // 06029B06 bra 0x06029DF2 ; nop
L_06029B0A:
    c.r[10] = ld32(0x06029B78u);  // 06029B0A mov.l 0x06029B78,r10
    c.r[1] = ld32(0x06029B7Cu);  // 06029B0C mov.l 0x06029B7C,r1
    c.r[4] = ld32(c.r[10]);  // 06029B0E mov.l @r10,r4
    { const uint32_t x = c.r[1]; c.pr = 0x06029B14u; c.r[5] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06029B14u) return; }  // 06029B10 jsr @r1 ; mov r11,r5
    c.r[8] = ld32(0x06029B80u);  // 06029B14 mov.l 0x06029B80,r8
    c.r[1] = ld32(0x06029B84u);  // 06029B16 mov.l 0x06029B84,r1
    c.r[4] = ld32(c.r[8]);  // 06029B18 mov.l @r8,r4
    { const uint32_t x = c.r[1]; c.pr = 0x06029B1Eu; c.r[5] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06029B1Eu) return; }  // 06029B1A jsr @r1 ; mov r12,r5
    c.r[1] = ld32(c.r[8]);  // 06029B1E mov.l @r8,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06029B66u);  // 06029B20 mov.w 0x06029B66,r2
    c.r[1] += 22;  // 06029B22 add #22,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06029B24 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06029B26 extu.w r1,r1
    c.t = c.r[1] > c.r[2];  // 06029B28 cmp/hi r2,r1
    { const bool k = !c.t; c.r[13] = 0x0u; if (k) { goto L_06029B3C; } }  // 06029B2A bf/s 0x06029B3C ; mov #0,r13
    c.r[1] = ld32(c.r[10]);  // 06029B2E mov.l @r10,r1
    c.r[1] += 32;  // 06029B30 add #32,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06029B32 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06029B34 extu.w r1,r1
    c.t = c.r[1] > c.r[2];  // 06029B36 cmp/hi r2,r1
    if (!c.t) { goto L_06029B3C; }  // 06029B38 bf 0x06029B3C
    c.r[13] = 0x1u;  // 06029B3A mov #1,r13
L_06029B3C:
    c.r[0] = ld32(0x06029B78u);  // 06029B3C mov.l 0x06029B78,r0
    c.r[8] = c.r[14];  // 06029B3E mov r14,r8
    c.r[8] += 1;  // 06029B40 add #1,r8
    c.r[5] = c.r[8];  // 06029B42 mov r8,r5
    c.r[1] = ld32(c.r[0]);  // 06029B44 mov.l @r0,r1
    c.r[4] = c.r[14];  // 06029B46 mov r14,r4
    c.r[1] += 37;  // 06029B48 add #37,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06029B4A mov.b @r1,r6
    c.r[0] = ld32(0x06029B88u);  // 06029B4C mov.l 0x06029B88,r0
    c.r[6] = c.r[6] & 0xFFu;  // 06029B4E extu.b r6,r6
    c.r[6] >>= 2;  // 06029B50 shlr2 r6
    { const uint32_t x = c.r[0]; c.pr = 0x06029B56u; c.r[6] >>= 2; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06029B56u) return; }  // 06029B52 jsr @r0 ; shlr2 r6
    c.t = c.r[0] == 0xFFFFFFFFu;  // 06029B56 cmp/eq #-1,r0
    { const bool k = !c.t; c.r[2] = c.r[0]; if (k) { goto L_06029B8C; } }  // 06029B58 bf/s 0x06029B8C ; mov r0,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06029B64u);  // 06029B5C mov.w 0x06029B64,r0
    c.r[14] += 12; goto L_06029DF4;  // 06029B5E bra 0x06029DF4 ; add #12,r14
L_06029B8C:
    c.r[6] = ld32(0x06029D98u);  // 06029B8C mov.l 0x06029D98,r6
    c.r[7] = c.r[9];  // 06029B8E mov r9,r7
    c.r[7] <<= 2;  // 06029B90 shll2 r7
    c.r[7] <<= 2;  // 06029B92 shll2 r7
    c.r[0] = 0x3u;  // 06029B94 mov #3,r0
    c.r[2] &= c.r[0];  // 06029B96 and r0,r2
    c.r[1] = ld32(c.r[6]);  // 06029B98 mov.l @r6,r1
    c.r[2] <<= 2;  // 06029B9A shll2 r2
    c.r[2] += c.r[2];  // 06029B9C add r2,r2
    c.r[1] += c.r[7];  // 06029B9E add r7,r1
    c.r[1] += 3;  // 06029BA0 add #3,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06029BA2 mov.b @r1,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x06029D7Cu);  // 06029BA4 mov.w 0x06029D7C,r0
    c.r[3] &= c.r[0];  // 06029BA6 and r0,r3
    c.r[3] |= c.r[2];  // 06029BA8 or r2,r3
    st8(c.r[1], c.r[3]);  // 06029BAA mov.b r3,@r1
    c.r[2] = ld32(c.r[6]);  // 06029BAC mov.l @r6,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[14]);  // 06029BAE mov.b @r14,r1
    c.r[0] = c.r[7];  // 06029BB0 mov r7,r0
    st8(c.r[0] + c.r[2], c.r[1]);  // 06029BB2 mov.b r1,@(r0,r2)
    c.r[2] = ld32(c.r[6]);  // 06029BB4 mov.l @r6,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06029BB6 mov.b @r8,r1
    c.r[2] += c.r[7];  // 06029BB8 add r7,r2
    c.r[2] += 1;  // 06029BBA add #1,r2
    st8(c.r[2], c.r[1]);  // 06029BBC mov.b r1,@r2
    c.r[0] = ld32(c.r[14] + 56);  // 06029BBE mov.l @(56,r14),r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06029BC0 tst r0,r0
    if (c.t) { goto L_06029BDC; }  // 06029BC2 bt 0x06029BDC
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06029BC4 mov.b @r8,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[14]);  // 06029BC6 mov.b @r14,r1
    c.r[3] = ld32(0x06029D9Cu);  // 06029BC8 mov.l 0x06029D9C,r3
    c.r[3] = ld32(c.r[3]);  // 06029BCA mov.l @r3,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06029BCC extu.b r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06029BCE extu.b r1,r1
    c.r[2] <<= 2;  // 06029BD0 shll2 r2
    c.r[2] <<= 2;  // 06029BD2 shll2 r2
    c.r[2] <<= 2;  // 06029BD4 shll2 r2
    c.r[2] += c.r[3];  // 06029BD6 add r3,r2
    c.r[0] = c.r[2];  // 06029BD8 mov r2,r0
    st8(c.r[0] + c.r[1], c.r[9]);  // 06029BDA mov.b r9,@(r0,r1)
L_06029BDC:
    c.r[1] = ld32(c.r[6]);  // 06029BDC mov.l @r6,r1
    c.r[1] += c.r[7];  // 06029BDE add r7,r1
    c.r[1] += 2;  // 06029BE0 add #2,r1
    st8(c.r[1], c.r[11]);  // 06029BE2 mov.b r11,@r1
    c.r[1] = ld32(c.r[6]);  // 06029BE4 mov.l @r6,r1
    c.r[0] = ld32(c.r[14] + 4);  // 06029BE6 mov.l @(4,r14),r0
    c.r[1] += c.r[7];  // 06029BE8 add r7,r1
    c.r[1] += 4;  // 06029BEA add #4,r1
    c.r[0] &= 0xFu;  // 06029BEC and #15,r0
    c.r[0] += c.r[0];  // 06029BEE add r0,r0
    st32(c.r[14] + 4, c.r[0]);  // 06029BF0 mov.l r0,@(4,r14)
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06029BF2 mov.b @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06029D7Eu);  // 06029BF4 mov.w 0x06029D7E,r0
    c.r[2] &= c.r[0];  // 06029BF6 and r0,r2
    c.r[0] = ld32(c.r[14] + 4);  // 06029BF8 mov.l @(4,r14),r0
    c.r[2] |= c.r[0];  // 06029BFA or r0,r2
    st8(c.r[1], c.r[2]);  // 06029BFC mov.b r2,@r1
    c.r[1] = ld32(c.r[6]);  // 06029BFE mov.l @r6,r1
    c.r[0] = ld32(c.r[14] + 52);  // 06029C00 mov.l @(52,r14),r0
    c.r[1] += c.r[7];  // 06029C02 add r7,r1
    st32(c.r[1] + 12, c.r[0]);  // 06029C04 mov.l r0,@(12,r1)
    c.r[1] += 3;  // 06029C06 add #3,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06029C08 mov.b @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06029D80u);  // 06029C0A mov.w 0x06029D80,r0
    c.r[2] |= c.r[0];  // 06029C0C or r0,r2
    st8(c.r[1], c.r[2]);  // 06029C0E mov.b r2,@r1
    c.r[1] = ld32(c.r[6]);  // 06029C10 mov.l @r6,r1
    c.r[1] += c.r[7];  // 06029C12 add r7,r1
    c.r[1] += 3;  // 06029C14 add #3,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06029C16 mov.b @r1,r2
    c.r[0] = 0x40u;  // 06029C18 mov #64,r0
    c.r[2] |= c.r[0];  // 06029C1A or r0,r2
    st8(c.r[1], c.r[2]);  // 06029C1C mov.b r2,@r1
    c.r[1] = ld32(c.r[6]);  // 06029C1E mov.l @r6,r1
    c.r[10] = ld32(0x06029DA0u);  // 06029C20 mov.l 0x06029DA0,r10
    c.r[1] += c.r[7];  // 06029C22 add r7,r1
    c.r[1] += 3;  // 06029C24 add #3,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06029C26 mov.b @r1,r2
    c.r[0] = 0x20u;  // 06029C28 mov #32,r0
    c.r[2] |= c.r[0];  // 06029C2A or r0,r2
    st8(c.r[1], c.r[2]);  // 06029C2C mov.b r2,@r1
    c.r[1] = 0x1Eu;  // 06029C2E mov #30,r1
    c.r[0] = 0x6u;  // 06029C30 mov #6,r0
    c.r[3] = ld32(c.r[6]);  // 06029C32 mov.l @r6,r3
    c.macl = c.r[11] * c.r[1];  // 06029C34 mul.l r1,r11
    c.r[2] = ld32(c.r[10]);  // 06029C36 mov.l @r10,r2
    c.r[3] += c.r[7];  // 06029C38 add r7,r3
    c.r[8] = c.macl;  // 06029C3A sts macl,r8
    c.r[2] += c.r[8];  // 06029C3C add r8,r2
    c.r[2] += 2;  // 06029C3E add #2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06029C40 mov.b @r2,r1
    c.r[3] += 3;  // 06029C42 add #3,r3
    c.r[1] >>= 2;  // 06029C44 shlr2 r1
    c.r[1] &= c.r[0];  // 06029C46 and r0,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06029C48 mov.b @r3,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06029D82u);  // 06029C4A mov.w 0x06029D82,r0
    c.r[2] &= c.r[0];  // 06029C4C and r0,r2
    c.r[2] |= c.r[1];  // 06029C4E or r1,r2
    st8(c.r[3], c.r[2]);  // 06029C50 mov.b r2,@r3
    c.r[2] = ld32(c.r[6]);  // 06029C52 mov.l @r6,r2
    c.r[0] = 0x3u;  // 06029C54 mov #3,r0
    c.r[2] += c.r[7];  // 06029C56 add r7,r2
    c.r[1] = c.r[2];  // 06029C58 mov r2,r1
    c.r[1] += 3;  // 06029C5A add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06029C5C mov.b @r1,r1
    c.r[2] += 7;  // 06029C5E add #7,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06029C60 mov.b @r2,r3
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06029C62 shlr r1
    c.r[1] &= c.r[0];  // 06029C64 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06029C66 tst r1,r1
    c.r[0] = c.t;  // 06029C68 movt r0
    c.r[1] = c.r[0];  // 06029C6A mov r0,r1
    c.r[1] <<= 2;  // 06029C6C shll2 r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06029D84u);  // 06029C6E mov.w 0x06029D84,r0
    c.r[3] &= c.r[0];  // 06029C70 and r0,r3
    c.r[3] |= c.r[1];  // 06029C72 or r1,r3
    st8(c.r[2], c.r[3]);  // 06029C74 mov.b r3,@r2
    c.r[1] = ld32(c.r[6]);  // 06029C76 mov.l @r6,r1
    c.r[0] = 0x1u;  // 06029C78 mov #1,r0
    c.r[5] = ld32(c.r[14] + 8);  // 06029C7A mov.l @(8,r14),r5
    c.r[1] += c.r[7];  // 06029C7C add r7,r1
    c.t = c.r[5] & 1; c.r[5] >>= 1;  // 06029C7E shlr r5
    c.r[5] &= c.r[0];  // 06029C80 and r0,r5
    c.r[2] = c.r[1];  // 06029C82 mov r1,r2
    c.r[2] += 3;  // 06029C84 add #3,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06029C86 mov.b @r2,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x06029D86u);  // 06029C88 mov.w 0x06029D86,r0
    c.r[3] &= c.r[0];  // 06029C8A and r0,r3
    c.r[3] |= c.r[5];  // 06029C8C or r5,r3
    st8(c.r[2], c.r[3]);  // 06029C8E mov.b r3,@r2
    c.r[0] = ld32(c.r[14] + 8);  // 06029C90 mov.l @(8,r14),r0
    c.r[1] += 4;  // 06029C92 add #4,r1
    c.r[0] &= 0x1u;  // 06029C94 and #1,r0
    c.r[0] <<= 2;  // 06029C96 shll2 r0
    c.r[0] <<= 2;  // 06029C98 shll2 r0
    c.r[0] += c.r[0];  // 06029C9A add r0,r0
    c.r[0] <<= 2;  // 06029C9C shll2 r0
    st32(c.r[14] + 8, c.r[0]);  // 06029C9E mov.l r0,@(8,r14)
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06029CA0 mov.b @r1,r2
    c.r[0] = 0x7Fu;  // 06029CA2 mov #127,r0
    c.r[2] &= c.r[0];  // 06029CA4 and r0,r2
    c.r[0] = ld32(c.r[14] + 8);  // 06029CA6 mov.l @(8,r14),r0
    c.r[2] |= c.r[0];  // 06029CA8 or r0,r2
    st8(c.r[1], c.r[2]);  // 06029CAA mov.b r2,@r1
    c.r[1] = ld32(c.r[6]);  // 06029CAC mov.l @r6,r1
    c.r[3] = 0xFFFFFFFFu;  // 06029CAE mov #-1,r3
    c.r[1] += c.r[7];  // 06029CB0 add r7,r1
    c.r[1] += 4;  // 06029CB2 add #4,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06029CB4 mov.b @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06029D88u);  // 06029CB6 mov.w 0x06029D88,r0
    c.r[2] &= c.r[0];  // 06029CB8 and r0,r2
    st8(c.r[1], c.r[2]);  // 06029CBA mov.b r2,@r1
    c.r[1] = ld32(c.r[6]);  // 06029CBC mov.l @r6,r1
    c.r[5] = (uint32_t)(int16_t)ld16(0x06029D8Au);  // 06029CBE mov.w 0x06029D8A,r5
    c.r[1] += c.r[7];  // 06029CC0 add r7,r1
    c.r[1] += 5;  // 06029CC2 add #5,r1
    st8(c.r[1], c.r[3]);  // 06029CC4 mov.b r3,@r1
    c.r[2] = ld32(c.r[6]);  // 06029CC6 mov.l @r6,r2
    c.r[0] = ld32(0x06029DA4u);  // 06029CC8 mov.l 0x06029DA4,r0
    c.r[1] = ld32(c.r[0]);  // 06029CCA mov.l @r0,r1
    c.r[2] += c.r[7];  // 06029CCC add r7,r2
    c.r[0] = c.r[1];  // 06029CCE mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 06029CD0 mov.b @(r0,r5),r1
    c.r[2] += 7;  // 06029CD2 add #7,r2
    c.r[1] += c.r[1];  // 06029CD4 add r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06029D80u);  // 06029CD6 mov.w 0x06029D80,r0
    c.r[1] &= c.r[0];  // 06029CD8 and r0,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06029CDA mov.b @r2,r5
    c.r[0] = 0x7Fu;  // 06029CDC mov #127,r0
    c.r[5] &= c.r[0];  // 06029CDE and r0,r5
    c.r[5] |= c.r[1];  // 06029CE0 or r1,r5
    st8(c.r[2], c.r[5]);  // 06029CE2 mov.b r5,@r2
    c.r[1] = ld32(c.r[6]);  // 06029CE4 mov.l @r6,r1
    c.r[1] += c.r[7];  // 06029CE6 add r7,r1
    c.r[1] += 4;  // 06029CE8 add #4,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06029CEA mov.b @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06029D8Cu);  // 06029CEC mov.w 0x06029D8C,r0
    c.r[2] &= c.r[0];  // 06029CEE and r0,r2
    st8(c.r[1], c.r[2]);  // 06029CF0 mov.b r2,@r1
    c.r[1] = ld32(c.r[6]);  // 06029CF2 mov.l @r6,r1
    c.r[1] += c.r[7];  // 06029CF4 add r7,r1
    c.r[1] += 6;  // 06029CF6 add #6,r1
    st8(c.r[1], c.r[3]);  // 06029CF8 mov.b r3,@r1
    c.r[1] = ld32(c.r[6]);  // 06029CFA mov.l @r6,r1
    c.r[1] += c.r[7];  // 06029CFC add r7,r1
    c.r[1] += 7;  // 06029CFE add #7,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06029D00 mov.b @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06029D88u);  // 06029D02 mov.w 0x06029D88,r0
    c.r[2] &= c.r[0];  // 06029D04 and r0,r2
    st8(c.r[1], c.r[2]);  // 06029D06 mov.b r2,@r1
    c.r[1] = ld32(c.r[6]);  // 06029D08 mov.l @r6,r1
    c.r[13] <<= 2;  // 06029D0A shll2 r13
    c.r[13] += c.r[13];  // 06029D0C add r13,r13
    c.r[13] <<= 2;  // 06029D0E shll2 r13
    c.r[1] += c.r[7];  // 06029D10 add r7,r1
    c.r[1] += 7;  // 06029D12 add #7,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06029D14 mov.b @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06029D8Cu);  // 06029D16 mov.w 0x06029D8C,r0
    c.r[2] &= c.r[0];  // 06029D18 and r0,r2
    c.r[2] |= c.r[13];  // 06029D1A or r13,r2
    st8(c.r[1], c.r[2]);  // 06029D1C mov.b r2,@r1
    c.r[1] = ld32(c.r[6]);  // 06029D1E mov.l @r6,r1
    c.r[1] += c.r[7];  // 06029D20 add r7,r1
    c.r[1] += 7;  // 06029D22 add #7,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06029D24 mov.b @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06029D8Eu);  // 06029D26 mov.w 0x06029D8E,r0
    c.r[2] &= c.r[0];  // 06029D28 and r0,r2
    st8(c.r[1], c.r[2]);  // 06029D2A mov.b r2,@r1
    c.r[1] = ld32(c.r[6]);  // 06029D2C mov.l @r6,r1
    c.r[1] += c.r[7];  // 06029D2E add r7,r1
    c.r[1] += 7;  // 06029D30 add #7,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06029D32 mov.b @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06029D90u);  // 06029D34 mov.w 0x06029D90,r0
    c.r[2] &= c.r[0];  // 06029D36 and r0,r2
    st8(c.r[1], c.r[2]);  // 06029D38 mov.b r2,@r1
    c.r[1] = ld32(0x06029DA8u);  // 06029D3A mov.l 0x06029DA8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06029D40u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06029D40u) return; }  // 06029D3C jsr @r1 ; mov r9,r4
    c.r[1] = ld32(c.r[10]);  // 06029D40 mov.l @r10,r1
    c.r[0] = c.r[8];  // 06029D42 mov r8,r0
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06029D44 mov.w @(r0,r1),r5
    c.r[4] = 0x0u;  // 06029D46 mov #0,r4
    c.r[0] = ld32(0x06029DACu);  // 06029D48 mov.l 0x06029DAC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06029D4Eu; c.r[5] = c.r[5] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06029D4Eu) return; }  // 06029D4A jsr @r0 ; extu.w r5,r5
    c.r[1] = c.r[0];  // 06029D4E mov r0,r1
    c.r[3] = c.r[1] & 0xFFFFu;  // 06029D50 extu.w r1,r3
    c.r[1] = ld32(0x06029DB0u);  // 06029D52 mov.l 0x06029DB0,r1
    c.t = c.r[3] == c.r[1];  // 06029D54 cmp/eq r1,r3
    if (c.t) { goto L_06029DE6; }  // 06029D56 bt 0x06029DE6
    c.r[1] = ld32(0x06029DB4u);  // 06029D58 mov.l 0x06029DB4,r1
    c.r[2] = ld32(c.r[1]);  // 06029D5A mov.l @r1,r2
    c.r[1] = ld32(c.r[10]);  // 06029D5C mov.l @r10,r1
    c.r[8] += c.r[1];  // 06029D5E add r1,r8
    c.r[8] += 2;  // 06029D60 add #2,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06029D62 mov.b @r8,r1
    c.r[0] = c.r[1];  // 06029D64 mov r1,r0
    c.r[0] >>= 2;  // 06029D66 shlr2 r0
    c.r[0] &= 0x6u;  // 06029D68 and #6,r0
    c.r[0] += c.r[2];  // 06029D6A add r2,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06029D92u);  // 06029D6C mov.w 0x06029D92,r1
    c.r[7] = c.r[0];  // 06029D6E mov r0,r7
    c.r[7] += c.r[1];  // 06029D70 add r1,r7
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06029D72 mov.w @(r0,r1),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06029D94u);  // 06029D74 mov.w 0x06029D94,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 06029D76 extu.w r1,r1
    c.t = c.r[1] == c.r[2]; goto L_06029DB8;  // 06029D78 bra 0x06029DB8 ; cmp/eq r2,r1
L_06029DB8:
    { const bool k = c.t; c.r[2] = 0x0u; if (k) { goto L_06029DD4; } }  // 06029DB8 bt/s 0x06029DD4 ; mov #0,r2
    c.r[1] = ld32(0x06029E08u);  // 06029DBC mov.l 0x06029E08,r1
    c.r[0] = c.r[3];  // 06029DBE mov r3,r0
    c.r[7] += 1;  // 06029DC0 add #1,r7
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06029DC2 mov.b @r7,r2
    c.r[0] <<= 2;  // 06029DC4 shll2 r0
    st8(c.r[0] + c.r[1], c.r[2]);  // 06029DC6 mov.b r2,@(r0,r1)
    c.r[1] += c.r[0];  // 06029DC8 add r0,r1
    c.r[1] += 2;  // 06029DCA add #2,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06029DCC mov.b @r1,r0
    c.r[0] &= 0x3Fu;  // 06029DCE and #63,r0
    c.r[0] |= 0x40u; goto L_06029DE4;  // 06029DD0 bra 0x06029DE4 ; or #64,r0
L_06029DD4:
    c.r[1] = ld32(0x06029E08u);  // 06029DD4 mov.l 0x06029E08,r1
    c.r[0] = c.r[3];  // 06029DD6 mov r3,r0
    c.r[0] <<= 2;  // 06029DD8 shll2 r0
    st8(c.r[0] + c.r[1], c.r[2]);  // 06029DDA mov.b r2,@(r0,r1)
    c.r[1] += c.r[0];  // 06029DDC add r0,r1
    c.r[1] += 2;  // 06029DDE add #2,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06029DE0 mov.b @r1,r0
    c.r[0] &= 0x3Fu;  // 06029DE2 and #63,r0
L_06029DE4:
    st8(c.r[1], c.r[0]);  // 06029DE4 mov.b r0,@r1
L_06029DE6:
    c.r[1] = ld32(0x06029E0Cu);  // 06029DE6 mov.l 0x06029E0C,r1
    c.r[6] = c.r[12];  // 06029DE8 mov r12,r6
    c.r[5] = c.r[11];  // 06029DEA mov r11,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06029DF0u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06029DF0u) return; }  // 06029DEC jsr @r1 ; mov r9,r4
    c.r[0] = c.r[9];  // 06029DF0 mov r9,r0
L_06029DF2:
    c.r[14] += 12;  // 06029DF2 add #12,r14
L_06029DF4:
    c.r[15] = c.r[14];  // 06029DF4 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06029DF6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06029DF8 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06029DFA mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06029DFC mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06029DFE mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06029E00 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06029E02 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06029E04 rts ; mov.l @r15+,r8
}

void f_06029E10(SH2Context& c) {
    ran[555] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06029E10 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06029E12 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06029E14 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06029E16 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06029E18 sts.l pr,@-r15
    c.r[8] = c.r[4] & 0xFFu;  // 06029E1A extu.b r4,r8
    c.r[2] = 0xFFFFFFFFu;  // 06029E1C mov #-1,r2
    c.r[1] = c.r[2] & 0xFFu;  // 06029E1E extu.b r2,r1
    c.t = c.r[8] == c.r[1];  // 06029E20 cmp/eq r1,r8
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_06029E2A; } }  // 06029E22 bf/s 0x06029E2A ; mov r15,r14
    goto L_06029F64;  // 06029E26 bra 0x06029F64 ; nop
L_06029E2A:
    c.r[5] = ld32(0x06029F78u);  // 06029E2A mov.l 0x06029F78,r5
    c.r[6] = c.r[2];  // 06029E2C mov r2,r6
    c.r[3] = 0x0u;  // 06029E2E mov #0,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x06029F72u);  // 06029E30 mov.w 0x06029F72,r7
L_06029E32:
    c.r[2] = ld32(c.r[5]);  // 06029E32 mov.l @r5,r2
    c.r[2] += c.r[3];  // 06029E34 add r3,r2
    c.r[2] += 9;  // 06029E36 add #9,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06029E38 mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06029E3A extu.b r1,r1
    c.t = c.r[1] == c.r[8];  // 06029E3C cmp/eq r8,r1
    if (!c.t) { goto L_06029E42; }  // 06029E3E bf 0x06029E42
    st8(c.r[2], c.r[6]);  // 06029E40 mov.b r6,@r2
L_06029E42:
    c.r[3] += 16;  // 06029E42 add #16,r3
    c.t = (int32_t)c.r[3] > (int32_t)c.r[7];  // 06029E44 cmp/gt r7,r3
    if (!c.t) { SH2_POLL(c); goto L_06029E32; }  // 06029E46 bf 0x06029E32
    c.r[3] = 0x0u;  // 06029E48 mov #0,r3
    c.r[4] = ld32(0x06029F78u);  // 06029E4A mov.l 0x06029F78,r4
    c.r[5] = 0xFFFFFFFFu;  // 06029E4C mov #-1,r5
    c.r[6] = 0x49u;  // 06029E4E mov #73,r6
    c.r[7] = 0x0u;  // 06029E50 mov #0,r7
L_06029E52:
    c.r[2] = ld32(c.r[4]);  // 06029E52 mov.l @r4,r2
    c.r[2] += c.r[7];  // 06029E54 add r7,r2
    c.r[2] += 8;  // 06029E56 add #8,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06029E58 mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06029E5A extu.b r1,r1
    c.t = c.r[1] == c.r[8];  // 06029E5C cmp/eq r8,r1
    if (!c.t) { goto L_06029E62; }  // 06029E5E bf 0x06029E62
    st8(c.r[2], c.r[5]);  // 06029E60 mov.b r5,@r2
L_06029E62:
    c.r[3] += 1;  // 06029E62 add #1,r3
    c.t = (int32_t)c.r[3] > (int32_t)c.r[6];  // 06029E64 cmp/gt r6,r3
    { const bool k = !c.t; c.r[7] += 16; if (k) { SH2_POLL(c); goto L_06029E52; } }  // 06029E66 bf/s 0x06029E52 ; add #16,r7
    c.r[6] = ld32(0x06029F78u);  // 06029E6A mov.l 0x06029F78,r6
    c.r[7] = c.r[8];  // 06029E6C mov r8,r7
    c.r[7] <<= 2;  // 06029E6E shll2 r7
    c.r[7] <<= 2;  // 06029E70 shll2 r7
    c.r[3] = ld32(c.r[6]);  // 06029E72 mov.l @r6,r3
    c.r[2] = c.r[7];  // 06029E74 mov r7,r2
    c.r[2] += c.r[3];  // 06029E76 add r3,r2
    c.r[1] = c.r[2];  // 06029E78 mov r2,r1
    c.r[1] += 4;  // 06029E7A add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06029E7C mov.b @r1,r1
    c.r[0] = c.r[1];  // 06029E7E mov r1,r0
    c.r[0] >>= 2;  // 06029E80 shlr2 r0
    c.r[0] >>= 2;  // 06029E82 shlr2 r0
    c.r[0] >>= 2;  // 06029E84 shlr2 r0
    c.r[0] &= 0x1u;  // 06029E86 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06029E88 tst r0,r0
    { const bool k = !c.t; c.r[0] = c.r[7]; if (k) { goto L_06029EAA; } }  // 06029E8A bf/s 0x06029EAA ; mov r7,r0
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06029E8E mov.b @(r0,r3),r3
    c.r[2] += 1;  // 06029E90 add #1,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06029E92 mov.b @r2,r2
    c.r[1] = ld32(0x06029F7Cu);  // 06029E94 mov.l 0x06029F7C,r1
    c.r[1] = ld32(c.r[1]);  // 06029E96 mov.l @r1,r1
    c.r[3] = c.r[3] & 0xFFu;  // 06029E98 extu.b r3,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06029E9A extu.b r2,r2
    c.r[2] <<= 2;  // 06029E9C shll2 r2
    c.r[2] <<= 2;  // 06029E9E shll2 r2
    c.r[2] <<= 2;  // 06029EA0 shll2 r2
    c.r[2] += c.r[1];  // 06029EA2 add r1,r2
    c.r[1] = 0xFFFFFFFFu;  // 06029EA4 mov #-1,r1
    c.r[0] = c.r[2];  // 06029EA6 mov r2,r0
    st8(c.r[0] + c.r[3], c.r[1]);  // 06029EA8 mov.b r1,@(r0,r3)
L_06029EAA:
    c.r[1] = ld32(c.r[6]);  // 06029EAA mov.l @r6,r1
    c.r[7] += c.r[1];  // 06029EAC add r1,r7
    c.r[7] += 2;  // 06029EAE add #2,r7
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06029EB0 mov.b @r7,r2
    c.r[1] = ld32(0x06029F80u);  // 06029EB2 mov.l 0x06029F80,r1
    c.r[3] = ld32(c.r[1]);  // 06029EB4 mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06029EB6 extu.b r2,r2
    c.r[1] = 0x1Eu;  // 06029EB8 mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 06029EBA mul.l r1,r2
    c.r[1] = c.macl;  // 06029EBC sts macl,r1
    c.r[0] = c.r[1];  // 06029EBE mov r1,r0
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 06029EC0 mov.w @(r0,r3),r5
    c.r[4] = 0x0u;  // 06029EC2 mov #0,r4
    c.r[0] = ld32(0x06029F84u);  // 06029EC4 mov.l 0x06029F84,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06029ECAu; c.r[5] = c.r[5] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06029ECAu) return; }  // 06029EC6 jsr @r0 ; extu.w r5,r5
    c.r[1] = c.r[0];  // 06029ECA mov r0,r1
    c.r[2] = c.r[1] & 0xFFFFu;  // 06029ECC extu.w r1,r2
    c.r[1] = ld32(0x06029F88u);  // 06029ECE mov.l 0x06029F88,r1
    c.t = c.r[2] == c.r[1];  // 06029ED0 cmp/eq r1,r2
    { const bool k = c.t; c.r[2] <<= 2; if (k) { goto L_06029EE4; } }  // 06029ED2 bt/s 0x06029EE4 ; shll2 r2
    c.r[1] = ld32(0x06029F8Cu);  // 06029ED6 mov.l 0x06029F8C,r1
    c.r[1] = ld32(c.r[1]);  // 06029ED8 mov.l @r1,r1
    c.r[1] += c.r[2];  // 06029EDA add r2,r1
    c.r[1] += 22;  // 06029EDC add #22,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06029EDE mov.b @r1,r0
    c.r[0] &= 0x3Fu;  // 06029EE0 and #63,r0
    st8(c.r[1], c.r[0]);  // 06029EE2 mov.b r0,@r1
L_06029EE4:
    c.r[7] = ld32(0x06029F8Cu);  // 06029EE4 mov.l 0x06029F8C,r7
    c.r[1] = ld32(c.r[7]);  // 06029EE6 mov.l @r7,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06029F74u);  // 06029EE8 mov.w 0x06029F74,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06029EEA mov.w @(r0,r1),r1
    c.r[2] = c.r[8] & 0xFFFFu;  // 06029EEC extu.w r8,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 06029EEE extu.w r1,r1
    c.t = c.r[2] == c.r[1];  // 06029EF0 cmp/eq r1,r2
    { const bool k = !c.t; c.r[3] = 0x0u; if (k) { goto L_06029F0E; } }  // 06029EF2 bf/s 0x06029F0E ; mov #0,r3
    c.r[6] = 0x4u;  // 06029EF6 mov #4,r6
L_06029EF8:
    c.r[1] = c.r[3];  // 06029EF8 mov r3,r1
    c.r[1] <<= 2;  // 06029EFA shll2 r1
    c.r[2] = ld32(c.r[7]);  // 06029EFC mov.l @r7,r2
    c.r[3] += 1;  // 06029EFE add #1,r3
    c.r[2] += c.r[1];  // 06029F00 add r1,r2
    c.r[2] += 22;  // 06029F02 add #22,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06029F04 mov.b @r2,r0
    c.t = (int32_t)c.r[3] > (int32_t)c.r[6];  // 06029F06 cmp/gt r6,r3
    c.r[0] &= 0x3Fu;  // 06029F08 and #63,r0
    { const bool k = !c.t; st8(c.r[2], c.r[0]); if (k) { SH2_POLL(c); goto L_06029EF8; } }  // 06029F0A bf/s 0x06029EF8 ; mov.b r0,@r2
L_06029F0E:
    c.r[9] = ld32(0x06029F78u);  // 06029F0E mov.l 0x06029F78,r9
    c.r[8] <<= 2;  // 06029F10 shll2 r8
    c.r[8] <<= 2;  // 06029F12 shll2 r8
    c.r[4] = ld32(c.r[9]);  // 06029F14 mov.l @r9,r4
    c.r[0] = 0x3u;  // 06029F16 mov #3,r0
    c.r[4] += c.r[8];  // 06029F18 add r8,r4
    c.r[1] = c.r[4];  // 06029F1A mov r4,r1
    c.r[1] += 3;  // 06029F1C add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06029F1E mov.b @r1,r1
    c.r[5] = 0x10u;  // 06029F20 mov #16,r5
    c.r[10] = c.r[1];  // 06029F22 mov r1,r10
    c.r[10] >>= 2;  // 06029F24 shlr2 r10
    c.t = c.r[10] & 1; c.r[10] >>= 1;  // 06029F26 shlr r10
    c.r[1] = ld32(0x06029F90u);  // 06029F28 mov.l 0x06029F90,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06029F2Eu; c.r[10] &= c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06029F2Eu) return; }  // 06029F2A jsr @r1 ; and r0,r10
    c.r[2] = c.r[8];  // 06029F2E mov r8,r2
    c.r[1] = 0xFFFFFFFFu;  // 06029F30 mov #-1,r1
    c.r[6] = ld32(c.r[9]);  // 06029F32 mov.l @r9,r6
    c.r[0] = c.r[8];  // 06029F34 mov r8,r0
    c.r[2] += c.r[6];  // 06029F36 add r6,r2
    c.r[5] = c.r[2];  // 06029F38 mov r2,r5
    c.r[5] += 2;  // 06029F3A add #2,r5
    c.r[7] = c.r[2];  // 06029F3C mov r2,r7
    c.r[7] += 6;  // 06029F3E add #6,r7
    c.r[3] = c.r[2];  // 06029F40 mov r2,r3
    c.r[3] += 8;  // 06029F42 add #8,r3
    c.r[2] += 5;  // 06029F44 add #5,r2
    st8(c.r[2], c.r[1]);  // 06029F46 mov.b r1,@r2
    st8(c.r[3], c.r[1]);  // 06029F48 mov.b r1,@r3
    st8(c.r[7], c.r[1]);  // 06029F4A mov.b r1,@r7
    st8(c.r[5], c.r[1]);  // 06029F4C mov.b r1,@r5
    st8(c.r[0] + c.r[6], c.r[1]);  // 06029F4E mov.b r1,@(r0,r6)
    c.r[1] = ld32(c.r[9]);  // 06029F50 mov.l @r9,r1
    c.r[10] <<= 2;  // 06029F52 shll2 r10
    c.r[10] += c.r[10];  // 06029F54 add r10,r10
    c.r[1] += c.r[8];  // 06029F56 add r8,r1
    c.r[1] += 3;  // 06029F58 add #3,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06029F5A mov.b @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06029F76u);  // 06029F5C mov.w 0x06029F76,r0
    c.r[2] &= c.r[0];  // 06029F5E and r0,r2
    c.r[2] |= c.r[10];  // 06029F60 or r10,r2
    st8(c.r[1], c.r[2]);  // 06029F62 mov.b r2,@r1
L_06029F64:
    c.r[15] = c.r[14];  // 06029F64 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06029F66 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06029F68 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06029F6A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06029F6C mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06029F6E rts ; mov.l @r15+,r8
}

void f_06029F94(SH2Context& c) {
    ran[556] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06029F94 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06029F96 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06029F98 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06029F9A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06029F9C sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06029F9E mov r15,r14
    c.r[9] = c.r[4] & 0xFFu;  // 06029FA0 extu.b r4,r9
    c.r[8] = 0x0u;  // 06029FA2 mov #0,r8
    c.r[10] = ld32(0x0602A008u);  // 06029FA4 mov.l 0x0602A008,r10
L_06029FA6:
    c.r[1] = ld32(0x0602A00Cu);  // 06029FA6 mov.l 0x0602A00C,r1
    c.r[0] = c.r[8];  // 06029FA8 mov r8,r0
    c.r[0] <<= 2;  // 06029FAA shll2 r0
    c.r[0] <<= 2;  // 06029FAC shll2 r0
    c.r[1] = ld32(c.r[1]);  // 06029FAE mov.l @r1,r1
    c.r[3] = c.r[0];  // 06029FB0 mov r0,r3
    c.r[3] += c.r[1];  // 06029FB2 add r1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06029FB4 mov.b @(r0,r1),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0602A006u);  // 06029FB6 mov.w 0x0602A006,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06029FB8 extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 06029FBA cmp/eq r2,r1
    { const bool k = c.t; c.r[1] = c.r[8]; if (k) { goto L_06029FE8; } }  // 06029FBC bt/s 0x06029FE8 ; mov r8,r1
    c.r[1] = c.r[3];  // 06029FC0 mov r3,r1
    c.r[1] += 4;  // 06029FC2 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06029FC4 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06029FC6 mov r1,r0
    c.r[0] >>= 2;  // 06029FC8 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06029FCA shlr r0
    c.r[0] >>= 2;  // 06029FCC shlr2 r0
    c.r[0] &= 0x1u;  // 06029FCE and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06029FD0 tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[8]; if (k) { goto L_06029FE8; } }  // 06029FD2 bt/s 0x06029FE8 ; mov r8,r1
    c.r[3] += 6;  // 06029FD6 add #6,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06029FD8 mov.b @r3,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06029FDA extu.b r1,r1
    c.t = c.r[9] == c.r[1];  // 06029FDC cmp/eq r1,r9
    { const bool k = !c.t; c.r[1] = c.r[8]; if (k) { goto L_06029FE8; } }  // 06029FDE bf/s 0x06029FE8 ; mov r8,r1
    { const uint32_t x = c.r[10]; c.pr = 0x06029FE6u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06029FE6u) return; }  // 06029FE2 jsr @r10 ; mov r8,r4
    c.r[1] = c.r[8];  // 06029FE6 mov r8,r1
L_06029FE8:
    c.r[1] += 1;  // 06029FE8 add #1,r1
    c.r[8] = c.r[1] & 0xFFu;  // 06029FEA extu.b r1,r8
    c.r[1] = 0x49u;  // 06029FEC mov #73,r1
    c.t = c.r[8] > c.r[1];  // 06029FEE cmp/hi r1,r8
    if (!c.t) { SH2_POLL(c); goto L_06029FA6; }  // 06029FF0 bf 0x06029FA6
    c.r[1] = ld32(0x0602A008u);  // 06029FF2 mov.l 0x0602A008,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06029FF8u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06029FF8u) return; }  // 06029FF4 jsr @r1 ; mov r9,r4
    c.r[15] = c.r[14];  // 06029FF8 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06029FFA lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06029FFC mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06029FFE mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0602A000 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602A002 rts ; mov.l @r15+,r8
}

void f_0602A010(SH2Context& c) {
    ran[557] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602A010 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0602A012 mov r15,r14
    c.r[4] = c.r[4] & 0xFFu;  // 0602A014 extu.b r4,r4
    c.r[5] = 0x0u;  // 0602A016 mov #0,r5
    c.r[1] = ld32(0x0602A05Cu);  // 0602A018 mov.l 0x0602A05C,r1
    c.r[3] = ld32(c.r[1]);  // 0602A01A mov.l @r1,r3
    c.r[6] = (uint32_t)(int16_t)ld16(0x0602A058u);  // 0602A01C mov.w 0x0602A058,r6
    c.r[7] = 0x49u;  // 0602A01E mov #73,r7
    c.r[2] = c.r[5];  // 0602A020 mov r5,r2
L_0602A022:
    c.r[2] <<= 2;  // 0602A022 shll2 r2
    c.r[2] <<= 2;  // 0602A024 shll2 r2
    c.r[1] = c.r[2];  // 0602A026 mov r2,r1
    c.r[1] += c.r[3];  // 0602A028 add r3,r1
    c.r[1] += 2;  // 0602A02A add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602A02C mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602A02E extu.b r1,r1
    c.t = c.r[1] == c.r[4];  // 0602A030 cmp/eq r4,r1
    { const bool k = !c.t; c.r[1] = c.r[5]; if (k) { goto L_0602A046; } }  // 0602A032 bf/s 0x0602A046 ; mov r5,r1
    c.r[0] = c.r[2];  // 0602A036 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0602A038 mov.b @(r0,r3),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602A03A extu.b r1,r1
    c.t = c.r[1] == c.r[6];  // 0602A03C cmp/eq r6,r1
    { const bool k = c.t; c.r[1] = c.r[5]; if (k) { goto L_0602A046; } }  // 0602A03E bt/s 0x0602A046 ; mov r5,r1
    c.r[0] = c.r[5]; goto L_0602A052;  // 0602A042 bra 0x0602A052 ; mov r5,r0
L_0602A046:
    c.r[1] += 1;  // 0602A046 add #1,r1
    c.r[5] = c.r[1] & 0xFFu;  // 0602A048 extu.b r1,r5
    c.t = c.r[5] > c.r[7];  // 0602A04A cmp/hi r7,r5
    { const bool k = !c.t; c.r[2] = c.r[5]; if (k) { SH2_POLL(c); goto L_0602A022; } }  // 0602A04C bf/s 0x0602A022 ; mov r5,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602A058u);  // 0602A050 mov.w 0x0602A058,r0
L_0602A052:
    c.r[15] = c.r[14];  // 0602A052 mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602A054 rts ; mov.l @r15+,r14
}

void f_0602A060(SH2Context& c) {
    ran[558] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602A060 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602A062 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0602A064 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0602A066 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0602A068 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602A06A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602A06C sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0602A06E mov r15,r14
    c.r[0] = ld32(0x0602A0ECu);  // 0602A070 mov.l 0x0602A0EC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602A076u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602A076u) return; }  // 0602A072 jsr @r0 ; extu.w r4,r4
    c.r[11] = c.r[0] & 0xFFu;  // 0602A076 extu.b r0,r11
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602A0E8u);  // 0602A078 mov.w 0x0602A0E8,r1
    c.t = c.r[11] == c.r[1];  // 0602A07A cmp/eq r1,r11
    { const bool k = c.t; c.r[10] = 0x0u; if (k) { goto L_0602A0D4; } }  // 0602A07C bt/s 0x0602A0D4 ; mov #0,r10
    c.r[12] = ld32(0x0602A0F0u);  // 0602A080 mov.l 0x0602A0F0,r12
    c.r[9] = 0x0u;  // 0602A082 mov #0,r9
L_0602A084:
    c.r[1] = ld32(0x0602A0F4u);  // 0602A084 mov.l 0x0602A0F4,r1
    c.r[0] = ld32(c.r[1]);  // 0602A086 mov.l @r1,r0
    c.r[2] = c.r[9];  // 0602A088 mov r9,r2
    c.r[2] += c.r[0];  // 0602A08A add r0,r2
    c.r[1] = c.r[2];  // 0602A08C mov r2,r1
    c.r[1] += 15;  // 0602A08E add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602A090 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602A092 extu.b r1,r1
    c.t = c.r[1] == c.r[11];  // 0602A094 cmp/eq r11,r1
    if (!c.t) { goto L_0602A0CA; }  // 0602A096 bf 0x0602A0CA
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[9]);  // 0602A098 mov.w @(r0,r9),r1
    c.r[8] = c.r[1] & 0xFFFFu;  // 0602A09A extu.w r1,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 0602A09C tst r8,r8
    { const bool k = c.t; c.r[2] += 16; if (k) { goto L_0602A0CA; } }  // 0602A09E bt/s 0x0602A0CA ; add #16,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602A0A2 mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602A0A4 extu.b r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0602A0E8u);  // 0602A0A6 mov.w 0x0602A0E8,r2
    c.t = c.r[1] == c.r[2];  // 0602A0A8 cmp/eq r2,r1
    { const bool k = c.t; c.r[0] = c.r[10] & 0xFFu; if (k) { goto L_0602A0D6; } }  // 0602A0AA bt/s 0x0602A0D6 ; extu.b r10,r0
    c.r[4] = ld32(0x0602A0F8u);  // 0602A0AE mov.l 0x0602A0F8,r4
    { const uint32_t x = c.r[12]; c.pr = 0x0602A0B4u; c.r[5] = 0x1Bu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602A0B4u) return; }  // 0602A0B0 jsr @r12 ; mov #27,r5
    c.r[5] = c.r[8];  // 0602A0B4 mov r8,r5
    { const uint32_t x = c.r[12]; c.pr = 0x0602A0BAu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602A0BAu) return; }  // 0602A0B6 jsr @r12 ; mov r0,r4
    c.r[0] += 7;  // 0602A0BA add #7,r0
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0602A0BC mov.b @r0,r0
    c.r[0] &= 0x78u;  // 0602A0BE and #120,r0
    c.r[0] >>= 2;  // 0602A0C0 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0602A0C2 shlr r0
    c.t = c.r[0] == 0x4u;  // 0602A0C4 cmp/eq #4,r0
    { const bool k = c.t; c.r[0] = c.r[10] & 0xFFu; if (k) { goto L_0602A0D6; } }  // 0602A0C6 bt/s 0x0602A0D6 ; extu.b r10,r0
L_0602A0CA:
    c.r[10] += 1;  // 0602A0CA add #1,r10
    c.r[1] = 0x7Fu;  // 0602A0CC mov #127,r1
    c.t = (int32_t)c.r[10] > (int32_t)c.r[1];  // 0602A0CE cmp/gt r1,r10
    { const bool k = !c.t; c.r[9] += 30; if (k) { SH2_POLL(c); goto L_0602A084; } }  // 0602A0D0 bf/s 0x0602A084 ; add #30,r9
L_0602A0D4:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602A0E8u);  // 0602A0D4 mov.w 0x0602A0E8,r0
L_0602A0D6:
    c.r[15] = c.r[14];  // 0602A0D6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602A0D8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602A0DA mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0602A0DC mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0602A0DE mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0602A0E0 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0602A0E2 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602A0E4 rts ; mov.l @r15+,r8
}

void f_0602A0FC(SH2Context& c) {
    ran[559] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602A0FC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602A0FE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0602A100 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0602A102 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602A104 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602A106 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0602A108 mov r15,r14
    c.r[4] = c.r[4] & 0xFFFFu;  // 0602A10A extu.w r4,r4
    c.r[0] = ld32(0x0602A198u);  // 0602A10C mov.l 0x0602A198,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602A112u; c.r[11] = c.r[5] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602A112u) return; }  // 0602A10E jsr @r0 ; extu.w r5,r11
    c.r[9] = c.r[0] & 0xFFu;  // 0602A112 extu.b r0,r9
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602A192u);  // 0602A114 mov.w 0x0602A192,r1
    c.t = c.r[9] == c.r[1];  // 0602A116 cmp/eq r1,r9
    { const bool k = c.t; c.r[2] = 0x0u; if (k) { goto L_0602A180; } }  // 0602A118 bt/s 0x0602A180 ; mov #0,r2
    c.r[1] = ld32(0x0602A19Cu);  // 0602A11C mov.l 0x0602A19C,r1
    c.r[7] = ld32(c.r[1]);  // 0602A11E mov.l @r1,r7
    c.r[6] = 0x7Fu;  // 0602A120 mov #127,r6
    c.r[0] = 0x0u;  // 0602A122 mov #0,r0
    c.r[3] = c.r[7];  // 0602A124 mov r7,r3
L_0602A126:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[7]);  // 0602A126 mov.w @(r0,r7),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0602A128 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0602A12A tst r1,r1
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_0602A13A; } }  // 0602A12C bt/s 0x0602A13A ; mov r3,r1
    c.r[1] += 15;  // 0602A130 add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602A132 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602A134 extu.b r1,r1
    c.t = c.r[1] == c.r[9];  // 0602A136 cmp/eq r9,r1
    if (c.t) { goto L_0602A144; }  // 0602A138 bt 0x0602A144
L_0602A13A:
    c.r[3] += 30;  // 0602A13A add #30,r3
    c.r[2] += 1;  // 0602A13C add #1,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[6];  // 0602A13E cmp/gt r6,r2
    { const bool k = !c.t; c.r[0] += 30; if (k) { SH2_POLL(c); goto L_0602A126; } }  // 0602A140 bf/s 0x0602A126 ; add #30,r0
L_0602A144:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602A194u);  // 0602A144 mov.w 0x0602A194,r1
    c.t = c.r[2] == c.r[1];  // 0602A146 cmp/eq r1,r2
    { const bool k = !c.t; c.r[8] = 0x0u; if (k) { goto L_0602A180; } }  // 0602A148 bf/s 0x0602A180 ; mov #0,r8
    c.r[10] = ld32(0x0602A1A0u);  // 0602A14C mov.l 0x0602A1A0,r10
L_0602A14E:
    c.r[1] = ld32(0x0602A19Cu);  // 0602A14E mov.l 0x0602A19C,r1
    c.r[2] = ld32(c.r[1]);  // 0602A150 mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 0602A152 mov #30,r1
    c.macl = c.r[8] * c.r[1];  // 0602A154 mul.l r1,r8
    c.r[0] = c.macl;  // 0602A156 sts macl,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 0602A158 mov.w @(r0,r2),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0602A15A extu.w r1,r1
    c.t = c.r[1] == c.r[11];  // 0602A15C cmp/eq r11,r1
    { const bool k = !c.t; c.r[1] = c.r[8]; if (k) { goto L_0602A176; } }  // 0602A15E bf/s 0x0602A176 ; mov r8,r1
    c.r[5] = c.r[9];  // 0602A162 mov r9,r5
    { const uint32_t x = c.r[10]; c.pr = 0x0602A168u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602A168u) return; }  // 0602A164 jsr @r10 ; mov r8,r4
    c.r[2] = c.r[0] & 0xFFu;  // 0602A168 extu.b r0,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602A192u);  // 0602A16A mov.w 0x0602A192,r1
    c.t = c.r[2] == c.r[1];  // 0602A16C cmp/eq r1,r2
    { const bool k = c.t; c.r[1] = c.r[8]; if (k) { goto L_0602A176; } }  // 0602A16E bt/s 0x0602A176 ; mov r8,r1
    c.r[0] = c.r[8]; goto L_0602A182;  // 0602A172 bra 0x0602A182 ; mov r8,r0
L_0602A176:
    c.r[1] += 1;  // 0602A176 add #1,r1
    c.r[8] = c.r[1] & 0xFFu;  // 0602A178 extu.b r1,r8
    c.r[1] = 0x7Fu;  // 0602A17A mov #127,r1
    c.t = c.r[8] > c.r[1];  // 0602A17C cmp/hi r1,r8
    if (!c.t) { SH2_POLL(c); goto L_0602A14E; }  // 0602A17E bf 0x0602A14E
L_0602A180:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602A192u);  // 0602A180 mov.w 0x0602A192,r0
L_0602A182:
    c.r[15] = c.r[14];  // 0602A182 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602A184 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602A186 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0602A188 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0602A18A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0602A18C mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602A18E rts ; mov.l @r15+,r8
}

void f_0602A1A4(SH2Context& c) {
    ran[560] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602A1A4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602A1A6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602A1A8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602A1AA sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0602A1AC mov r15,r14
    c.r[4] = c.r[4] & 0xFFu;  // 0602A1AE extu.b r4,r4
    c.r[8] = c.r[4];  // 0602A1B0 mov r4,r8
    c.r[5] = c.r[5] & 0xFFu;  // 0602A1B2 extu.b r5,r5
    c.r[0] = ld32(0x0602A1E4u);  // 0602A1B4 mov.l 0x0602A1E4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602A1BAu; c.r[9] = c.r[5]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602A1BAu) return; }  // 0602A1B6 jsr @r0 ; mov r5,r9
    c.r[0] = c.r[0] & 0xFFu;  // 0602A1BA extu.b r0,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602A1E0u);  // 0602A1BC mov.w 0x0602A1E0,r1
    c.t = c.r[0] == c.r[1];  // 0602A1BE cmp/eq r1,r0
    if (c.t) { goto L_0602A1D4; }  // 0602A1C0 bt 0x0602A1D4
    c.r[0] = 0x0u;  // 0602A1C2 mov #0,r0
    c.r[1] = ld32(0x0602A1E8u);  // 0602A1C4 mov.l 0x0602A1E8,r1
    c.r[2] = ld32(c.r[1]);  // 0602A1C6 mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 0602A1C8 mov #30,r1
    c.macl = c.r[8] * c.r[1];  // 0602A1CA mul.l r1,r8
    c.r[1] = c.macl;  // 0602A1CC sts macl,r1
    c.r[1] += c.r[2];  // 0602A1CE add r2,r1
    c.r[1] += 15;  // 0602A1D0 add #15,r1
    st8(c.r[1], c.r[9]);  // 0602A1D2 mov.b r9,@r1
L_0602A1D4:
    c.r[15] = c.r[14];  // 0602A1D4 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602A1D6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602A1D8 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0602A1DA mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602A1DC rts ; mov.l @r15+,r8
}

void f_0602A1EC(SH2Context& c) {
    ran[561] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602A1EC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602A1EE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0602A1F0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0602A1F2 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0602A1F4 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602A1F6 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602A1F8 sts.l pr,@-r15
    c.r[10] = c.r[4] & 0xFFFFu;  // 0602A1FA extu.w r4,r10
    c.r[6] = ld32(0x0602A320u);  // 0602A1FC mov.l 0x0602A320,r6
    c.r[0] = c.r[10];  // 0602A1FE mov r10,r0
    c.r[0] <<= 2;  // 0602A200 shll2 r0
    c.r[2] = ld32(0x0602A324u);  // 0602A202 mov.l 0x0602A324,r2
    c.r[1] = c.r[0];  // 0602A204 mov r0,r1
    c.r[1] += c.r[2];  // 0602A206 add r2,r1
    c.r[3] = ld32(c.r[6]);  // 0602A208 mov.l @r6,r3
    c.r[1] += 1;  // 0602A20A add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0602A20C mov.b @(r0,r2),r2
    c.r[3] += c.r[0];  // 0602A20E add r0,r3
    c.r[7] = c.r[3];  // 0602A210 mov r3,r7
    c.r[7] += 20;  // 0602A212 add #20,r7
    st8(c.r[7], c.r[2]);  // 0602A214 mov.b r2,@r7
    c.r[7] = c.r[3];  // 0602A216 mov r3,r7
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0602A218 mov.b @r1+,r2
    c.r[7] += 21;  // 0602A21A add #21,r7
    st8(c.r[7], c.r[2]);  // 0602A21C mov.b r2,@r7
    c.r[7] = c.r[3];  // 0602A21E mov r3,r7
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0602A220 mov.b @r1+,r2
    c.r[7] += 22;  // 0602A222 add #22,r7
    st8(c.r[7], c.r[2]);  // 0602A224 mov.b r2,@r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602A226 mov.b @r1,r1
    c.r[3] += 23;  // 0602A228 add #23,r3
    st8(c.r[3], c.r[1]);  // 0602A22A mov.b r1,@r3
    c.r[1] = ld32(c.r[6]);  // 0602A22C mov.l @r6,r1
    c.r[15] -= 8;  // 0602A22E add #-8,r15
    c.r[0] += c.r[1];  // 0602A230 add r1,r0
    c.r[0] += 22;  // 0602A232 add #22,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0602A234 mov.b @r0,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0602A236 extu.b r1,r2
    c.r[1] = c.r[2];  // 0602A238 mov r2,r1
    c.r[1] >>= 2;  // 0602A23A shlr2 r1
    c.r[1] >>= 2;  // 0602A23C shlr2 r1
    c.r[1] >>= 2;  // 0602A23E shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0602A240 tst r1,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0602A304; } }  // 0602A242 bt/s 0x0602A304 ; mov r15,r14
    c.r[0] = c.r[2];  // 0602A246 mov r2,r0
    c.r[0] >>= 2;  // 0602A248 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0602A24A shlr r0
    c.r[0] >>= 2;  // 0602A24C shlr2 r0
    c.r[0] &= 0x1u;  // 0602A24E and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0602A250 tst r0,r0
    { const bool k = !c.t; c.r[5] = c.r[10]; if (k) { goto L_0602A304; } }  // 0602A252 bf/s 0x0602A304 ; mov r10,r5
    c.r[0] = ld32(0x0602A328u);  // 0602A256 mov.l 0x0602A328,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602A25Cu; c.r[4] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602A25Cu) return; }  // 0602A258 jsr @r0 ; mov #2,r4
    c.r[12] = c.r[0] & 0xFFu;  // 0602A25C extu.b r0,r12
    c.r[1] = ld32(0x0602A32Cu);  // 0602A25E mov.l 0x0602A32C,r1
    c.r[5] = c.r[14];  // 0602A260 mov r14,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0602A266u; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602A266u) return; }  // 0602A262 jsr @r1 ; mov r12,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[14]);  // 0602A266 mov.b @r14,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0602A318u);  // 0602A268 mov.w 0x0602A318,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0602A26A extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 0602A26C cmp/eq r2,r1
    { const bool k = !c.t; c.r[1] = c.r[14]; if (k) { goto L_0602A28C; } }  // 0602A26E bf/s 0x0602A28C ; mov r14,r1
    c.r[7] = ld32(0x0602A330u);  // 0602A272 mov.l 0x0602A330,r7
    c.r[1] += 2;  // 0602A274 add #2,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602A276 mov.b @r1,r5
    c.r[6] = ld32(0x0602A334u);  // 0602A278 mov.l 0x0602A334,r6
    c.r[1] = c.r[14];  // 0602A27A mov r14,r1
    c.r[1] += 1;  // 0602A27C add #1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602A27E mov.b @r1,r4
    c.r[5] = c.r[5] & 0xFFu;  // 0602A280 extu.b r5,r5
    c.r[1] = ld32(0x0602A338u);  // 0602A282 mov.l 0x0602A338,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602A288u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602A288u) return; }  // 0602A284 jsr @r1 ; extu.b r4,r4
    goto L_0602A2CC;  // 0602A288 bra 0x0602A2CC ; nop
L_0602A28C:
    c.r[8] = 0x0u;  // 0602A28C mov #0,r8
    c.r[11] = ld32(0x0602A338u);  // 0602A28E mov.l 0x0602A338,r11
    c.r[9] = 0x0u;  // 0602A290 mov #0,r9
    c.r[0] = c.r[14];  // 0602A292 mov r14,r0
L_0602A294:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0602A294 mov.b @(r0,r8),r1
    c.r[3] = c.r[1] & 0xFFu;  // 0602A296 extu.b r1,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602A31Au);  // 0602A298 mov.w 0x0602A31A,r1
    c.t = c.r[3] == c.r[1];  // 0602A29A cmp/eq r1,r3
    { const bool k = c.t; c.r[0] = c.r[3]; if (k) { goto L_0602A2BE; } }  // 0602A29C bt/s 0x0602A2BE ; mov r3,r0
    c.r[6] = ld32(0x0602A334u);  // 0602A2A0 mov.l 0x0602A334,r6
    c.r[6] += c.r[9];  // 0602A2A2 add r9,r6
    c.r[1] = ld32(0x0602A33Cu);  // 0602A2A4 mov.l 0x0602A33C,r1
    c.r[2] = ld32(c.r[1]);  // 0602A2A6 mov.l @r1,r2
    c.r[0] <<= 2;  // 0602A2A8 shll2 r0
    c.r[0] <<= 2;  // 0602A2AA shll2 r0
    c.r[1] = c.r[0];  // 0602A2AC mov r0,r1
    c.r[1] += c.r[2];  // 0602A2AE add r2,r1
    c.r[1] += 1;  // 0602A2B0 add #1,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602A2B2 mov.b @r1,r5
    c.r[7] = ld32(0x0602A330u);  // 0602A2B4 mov.l 0x0602A330,r7
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0602A2B6 mov.b @(r0,r2),r4
    c.r[5] = c.r[5] & 0xFFu;  // 0602A2B8 extu.b r5,r5
    { const uint32_t x = c.r[11]; c.pr = 0x0602A2BEu; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602A2BEu) return; }  // 0602A2BA jsr @r11 ; extu.b r4,r4
L_0602A2BE:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602A31Cu);  // 0602A2BE mov.w 0x0602A31C,r1
    c.r[9] += c.r[1];  // 0602A2C0 add r1,r9
    c.r[8] += 1;  // 0602A2C2 add #1,r8
    c.r[1] = 0x4u;  // 0602A2C4 mov #4,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 0602A2C6 cmp/gt r1,r8
    { const bool k = !c.t; c.r[0] = c.r[14]; if (k) { SH2_POLL(c); goto L_0602A294; } }  // 0602A2C8 bf/s 0x0602A294 ; mov r14,r0
L_0602A2CC:
    c.r[1] = ld32(0x0602A33Cu);  // 0602A2CC mov.l 0x0602A33C,r1
    c.r[2] = c.r[12];  // 0602A2CE mov r12,r2
    c.r[2] <<= 2;  // 0602A2D0 shll2 r2
    c.r[2] <<= 2;  // 0602A2D2 shll2 r2
    c.r[3] = ld32(c.r[1]);  // 0602A2D4 mov.l @r1,r3
    c.r[0] = c.r[2];  // 0602A2D6 mov r2,r0
    c.r[1] = c.r[2];  // 0602A2D8 mov r2,r1
    c.r[1] += c.r[3];  // 0602A2DA add r3,r1
    c.r[1] += 1;  // 0602A2DC add #1,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602A2DE mov.b @r1,r5
    c.r[6] = c.r[14];  // 0602A2E0 mov r14,r6
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0602A2E2 mov.b @(r0,r3),r4
    c.r[5] = c.r[5] & 0xFFu;  // 0602A2E4 extu.b r5,r5
    c.r[0] = ld32(0x0602A340u);  // 0602A2E6 mov.l 0x0602A340,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602A2ECu; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602A2ECu) return; }  // 0602A2E8 jsr @r0 ; extu.b r4,r4
    c.r[1] = c.r[0];  // 0602A2EC mov r0,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602A2EE extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0602A2F0 tst r1,r1
    { const bool k = !c.t; c.r[10] <<= 2; if (k) { goto L_0602A304; } }  // 0602A2F2 bf/s 0x0602A304 ; shll2 r10
    c.r[1] = ld32(0x0602A320u);  // 0602A2F6 mov.l 0x0602A320,r1
    c.r[1] = ld32(c.r[1]);  // 0602A2F8 mov.l @r1,r1
    c.r[1] += c.r[10];  // 0602A2FA add r10,r1
    c.r[1] += 22;  // 0602A2FC add #22,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602A2FE mov.b @r1,r0
    c.r[0] &= 0x3Fu;  // 0602A300 and #63,r0
    st8(c.r[1], c.r[0]);  // 0602A302 mov.b r0,@r1
L_0602A304:
    c.r[14] += 8;  // 0602A304 add #8,r14
    c.r[15] = c.r[14];  // 0602A306 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602A308 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602A30A mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0602A30C mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0602A30E mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0602A310 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0602A312 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602A314 rts ; mov.l @r15+,r8
}

void f_0602A344(SH2Context& c) {
    ran[562] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602A344 mov.l r14,@-r15
    c.r[4] = c.r[4] & 0xFFu;  // 0602A346 extu.b r4,r4
    c.r[1] = ld32(0x0602A394u);  // 0602A348 mov.l 0x0602A394,r1
    c.r[1] = ld32(c.r[1]);  // 0602A34A mov.l @r1,r1
    c.r[4] <<= 2;  // 0602A34C shll2 r4
    c.r[4] <<= 2;  // 0602A34E shll2 r4
    c.r[4] += c.r[1];  // 0602A350 add r1,r4
    c.r[4] += 2;  // 0602A352 add #2,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]);  // 0602A354 mov.b @r4,r1
    c.r[7] = (uint32_t)(int16_t)ld16(0x0602A390u);  // 0602A356 mov.w 0x0602A390,r7
    c.r[2] = c.r[1] & 0xFFu;  // 0602A358 extu.b r1,r2
    c.t = c.r[2] == c.r[7];  // 0602A35A cmp/eq r7,r2
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0602A388; } }  // 0602A35C bt/s 0x0602A388 ; mov r15,r14
    c.r[1] = ld32(0x0602A398u);  // 0602A360 mov.l 0x0602A398,r1
    c.r[6] = 0x1Eu;  // 0602A362 mov #30,r6
    c.macl = c.r[2] * c.r[6];  // 0602A364 mul.l r6,r2
    c.r[3] = ld32(c.r[1]);  // 0602A366 mov.l @r1,r3
    c.r[1] = c.macl;  // 0602A368 sts macl,r1
    c.r[1] += c.r[3];  // 0602A36A add r3,r1
    c.r[1] += 16;  // 0602A36C add #16,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602A36E mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602A370 extu.b r1,r1
    c.t = c.r[1] == c.r[7];  // 0602A372 cmp/eq r7,r1
    if (c.t) { goto L_0602A378; }  // 0602A374 bt 0x0602A378
    c.r[2] = c.r[1];  // 0602A376 mov r1,r2
L_0602A378:
    c.macl = c.r[2] * c.r[6];  // 0602A378 mul.l r6,r2
    c.r[1] = c.macl;  // 0602A37A sts macl,r1
    c.r[1] += c.r[3];  // 0602A37C add r3,r1
    c.r[1] += 15;  // 0602A37E add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602A380 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0602A382 extu.b r1,r0
    c.t = c.r[0] == c.r[7];  // 0602A384 cmp/eq r7,r0
    if (!c.t) { goto L_0602A38A; }  // 0602A386 bf 0x0602A38A
L_0602A388:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602A390u);  // 0602A388 mov.w 0x0602A390,r0
L_0602A38A:
    c.r[15] = c.r[14];  // 0602A38A mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602A38C rts ; mov.l @r15+,r14
}

void f_0602A39C(SH2Context& c) {
    ran[563] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602A39C mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0602A39E mov r15,r14
    c.r[2] = 0x0u;  // 0602A3A0 mov #0,r2
    c.r[1] = ld32(0x0602A3D4u);  // 0602A3A2 mov.l 0x0602A3D4,r1
    c.r[3] = ld32(c.r[1]);  // 0602A3A4 mov.l @r1,r3
    c.r[6] = (uint32_t)(int16_t)ld16(0x0602A3D0u);  // 0602A3A6 mov.w 0x0602A3D0,r6
    c.r[7] = 0x49u;  // 0602A3A8 mov #73,r7
    c.r[0] = c.r[2];  // 0602A3AA mov r2,r0
L_0602A3AC:
    c.r[0] <<= 2;  // 0602A3AC shll2 r0
    c.r[0] <<= 2;  // 0602A3AE shll2 r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0602A3B0 mov.b @(r0,r3),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602A3B2 extu.b r1,r1
    c.t = c.r[1] == c.r[6];  // 0602A3B4 cmp/eq r6,r1
    { const bool k = !c.t; c.r[1] = c.r[2]; if (k) { goto L_0602A3BE; } }  // 0602A3B6 bf/s 0x0602A3BE ; mov r2,r1
    c.r[0] = c.r[2]; goto L_0602A3CA;  // 0602A3BA bra 0x0602A3CA ; mov r2,r0
L_0602A3BE:
    c.r[1] += 1;  // 0602A3BE add #1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0602A3C0 extu.b r1,r2
    c.t = c.r[2] > c.r[7];  // 0602A3C2 cmp/hi r7,r2
    { const bool k = !c.t; c.r[0] = c.r[2]; if (k) { SH2_POLL(c); goto L_0602A3AC; } }  // 0602A3C4 bf/s 0x0602A3AC ; mov r2,r0
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602A3D0u);  // 0602A3C8 mov.w 0x0602A3D0,r0
L_0602A3CA:
    c.r[15] = c.r[14];  // 0602A3CA mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602A3CC rts ; mov.l @r15+,r14
}

void f_0602A3D8(SH2Context& c) {
    ran[564] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602A3D8 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0602A3DA mov r15,r14
    c.r[6] = 0x49u;  // 0602A3DC mov #73,r6
    c.r[1] = ld32(0x0602A408u);  // 0602A3DE mov.l 0x0602A408,r1
    c.r[3] = ld32(c.r[1]);  // 0602A3E0 mov.l @r1,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x0602A402u);  // 0602A3E2 mov.w 0x0602A402,r7
    c.r[2] = (uint32_t)(int16_t)ld16(0x0602A404u);  // 0602A3E4 mov.w 0x0602A404,r2
L_0602A3E6:
    c.r[0] = c.r[2];  // 0602A3E6 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0602A3E8 mov.b @(r0,r3),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602A3EA extu.b r1,r1
    c.t = c.r[1] == c.r[7];  // 0602A3EC cmp/eq r7,r1
    { const bool k = c.t; c.r[0] = c.r[6] & 0xFFu; if (k) { goto L_0602A3FC; } }  // 0602A3EE bt/s 0x0602A3FC ; extu.b r6,r0
    c.r[6] -= 1;  // 0602A3F2 add #-1,r6
    c.t = (int32_t)c.r[6] >= 0;  // 0602A3F4 cmp/pz r6
    { const bool k = c.t; c.r[2] -= 16; if (k) { SH2_POLL(c); goto L_0602A3E6; } }  // 0602A3F6 bt/s 0x0602A3E6 ; add #-16,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602A402u);  // 0602A3FA mov.w 0x0602A402,r0
L_0602A3FC:
    c.r[15] = c.r[14];  // 0602A3FC mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602A3FE rts ; mov.l @r15+,r14
}

void f_0602A40C(SH2Context& c) {
    ran[565] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602A40C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602A40E sts.l pr,@-r15
    c.r[1] = ld32(0x0602A42Cu);  // 0602A410 mov.l 0x0602A42C,r1
    c.r[1] = ld32(c.r[1]);  // 0602A412 mov.l @r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602A414 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0602A416 extu.b r1,r0
    c.r[0] <<= 2;  // 0602A418 shll2 r0
    c.r[1] = ld32(0x0602A430u);  // 0602A41A mov.l 0x0602A430,r1
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 0602A41C mov.l @(r0,r1),r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602A422u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602A422u) return; }  // 0602A41E jsr @r0 ; mov r15,r14
    c.r[15] = c.r[14];  // 0602A422 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602A424 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602A426 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[0] & 0xFFFFu; c.pc = x; return; }  // 0602A428 rts ; extu.w r0,r0
}

void f_0602A434(SH2Context& c) {
    ran[566] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602A434 mov.l r14,@-r15
    c.r[1] = ld32(0x0602A450u);  // 0602A436 mov.l 0x0602A450,r1
    c.r[2] = ld32(c.r[1]);  // 0602A438 mov.l @r1,r2
    c.r[14] = c.r[15];  // 0602A43A mov r15,r14
    c.r[1] = ld32(0x0602A454u);  // 0602A43C mov.l 0x0602A454,r1
    c.r[1] = ld32(c.r[1]);  // 0602A43E mov.l @r1,r1
    c.r[1] += 1;  // 0602A440 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602A442 mov.b @r1,r1
    c.r[2] += 4;  // 0602A444 add #4,r2
    st8(c.r[2], c.r[1]);  // 0602A446 mov.b r1,@r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602A44Eu);  // 0602A448 mov.w 0x0602A44E,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602A44A rts ; mov.l @r15+,r14
}

void f_0602A458(SH2Context& c) {
    ran[567] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602A458 mov.l r14,@-r15
    c.r[1] = ld32(0x0602A474u);  // 0602A45A mov.l 0x0602A474,r1
    c.r[2] = ld32(c.r[1]);  // 0602A45C mov.l @r1,r2
    c.r[14] = c.r[15];  // 0602A45E mov r15,r14
    c.r[1] = ld32(0x0602A478u);  // 0602A460 mov.l 0x0602A478,r1
    c.r[1] = ld32(c.r[1]);  // 0602A462 mov.l @r1,r1
    c.r[1] += 1;  // 0602A464 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602A466 mov.b @r1,r1
    c.r[2] += 5;  // 0602A468 add #5,r2
    st8(c.r[2], c.r[1]);  // 0602A46A mov.b r1,@r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602A472u);  // 0602A46C mov.w 0x0602A472,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602A46E rts ; mov.l @r15+,r14
}

void f_0602A47C(SH2Context& c) {
    ran[568] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602A47C mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0602A47E mov r15,r14
    c.r[1] = ld32(0x0602A4A4u);  // 0602A480 mov.l 0x0602A4A4,r1
    c.r[2] = ld32(c.r[1]);  // 0602A482 mov.l @r1,r2
    c.r[1] = ld32(0x0602A4A8u);  // 0602A484 mov.l 0x0602A4A8,r1
    c.r[1] = ld32(c.r[1]);  // 0602A486 mov.l @r1,r1
    c.r[2] += 8;  // 0602A488 add #8,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602A48A mov.b @r2,r0
    c.r[1] += 1;  // 0602A48C add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602A48E mov.b @r1,r1
    c.r[0] &= 0x3Fu;  // 0602A490 and #63,r0
    c.r[1] <<= 2;  // 0602A492 shll2 r1
    c.r[1] <<= 2;  // 0602A494 shll2 r1
    c.r[1] <<= 2;  // 0602A496 shll2 r1
    c.r[0] |= c.r[1];  // 0602A498 or r1,r0
    st8(c.r[2], c.r[0]);  // 0602A49A mov.b r0,@r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602A4A2u);  // 0602A49C mov.w 0x0602A4A2,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602A49E rts ; mov.l @r15+,r14
}

void f_0602A4AC(SH2Context& c) {
    ran[569] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602A4AC mov.l r14,@-r15
    c.r[1] = ld32(0x0602A4C4u);  // 0602A4AE mov.l 0x0602A4C4,r1
    c.r[2] = ld32(c.r[1]);  // 0602A4B0 mov.l @r1,r2
    c.r[14] = c.r[15];  // 0602A4B2 mov r15,r14
    c.r[2] += 5;  // 0602A4B4 add #5,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602A4B6 mov.b @r2,r1
    c.r[1] += 1;  // 0602A4B8 add #1,r1
    st8(c.r[2], c.r[1]);  // 0602A4BA mov.b r1,@r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602A4C2u);  // 0602A4BC mov.w 0x0602A4C2,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602A4BE rts ; mov.l @r15+,r14
}

void f_0602A4C8(SH2Context& c) {
    ran[570] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602A4C8 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0602A4CA mov r15,r14
    c.r[1] = ld32(0x0602A4F4u);  // 0602A4CC mov.l 0x0602A4F4,r1
    c.r[2] = ld32(c.r[1]);  // 0602A4CE mov.l @r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0602A4F0u);  // 0602A4D0 mov.w 0x0602A4F0,r3
    c.r[1] = ld32(0x0602A4F8u);  // 0602A4D2 mov.l 0x0602A4F8,r1
    c.r[1] = ld32(c.r[1]);  // 0602A4D4 mov.l @r1,r1
    c.r[1] += 1;  // 0602A4D6 add #1,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602A4D8 mov.b @r1,r0
    c.r[2] += 8;  // 0602A4DA add #8,r2
    c.r[0] &= 0x3u;  // 0602A4DC and #3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602A4DE mov.b @r2,r1
    c.r[0] <<= 2;  // 0602A4E0 shll2 r0
    c.r[0] <<= 2;  // 0602A4E2 shll2 r0
    c.r[1] &= c.r[3];  // 0602A4E4 and r3,r1
    c.r[1] |= c.r[0];  // 0602A4E6 or r0,r1
    st8(c.r[2], c.r[1]);  // 0602A4E8 mov.b r1,@r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602A4F2u);  // 0602A4EA mov.w 0x0602A4F2,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602A4EC rts ; mov.l @r15+,r14
}

void f_0602A4FC(SH2Context& c) {
    ran[571] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602A4FC mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0602A4FE mov r15,r14
    c.r[1] = ld32(0x0602A538u);  // 0602A500 mov.l 0x0602A538,r1
    c.r[2] = ld32(0x0602A53Cu);  // 0602A502 mov.l 0x0602A53C,r2
    c.r[1] = ld32(c.r[1]);  // 0602A504 mov.l @r1,r1
    c.r[6] = 0x8u;  // 0602A506 mov #8,r6
    c.r[1] += 1;  // 0602A508 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602A50A mov.b @r1,r1
    c.r[7] = c.r[1] & 0xFFu;  // 0602A50C extu.b r1,r7
    c.r[3] = c.r[7];  // 0602A50E mov r7,r3
    c.r[1] = ld32(c.r[2]);  // 0602A510 mov.l @r2,r1
    c.r[3] <<= 2;  // 0602A512 shll2 r3
    c.r[1] += 8;  // 0602A514 add #8,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602A516 mov.b @r1,r0
    c.r[3] &= c.r[6];  // 0602A518 and r6,r3
    c.r[0] &= 0xF7u;  // 0602A51A and #247,r0
    c.r[0] |= c.r[3];  // 0602A51C or r3,r0
    st8(c.r[1], c.r[0]);  // 0602A51E mov.b r0,@r1
    c.r[1] = ld32(c.r[2]);  // 0602A520 mov.l @r2,r1
    c.r[6] = 0x1u;  // 0602A522 mov #1,r6
    c.r[1] += 8;  // 0602A524 add #8,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602A526 mov.b @r1,r0
    c.r[7] &= c.r[6];  // 0602A528 and r6,r7
    c.r[0] &= 0xFEu;  // 0602A52A and #254,r0
    c.r[0] |= c.r[7];  // 0602A52C or r7,r0
    st8(c.r[1], c.r[0]);  // 0602A52E mov.b r0,@r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602A536u);  // 0602A530 mov.w 0x0602A536,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602A532 rts ; mov.l @r15+,r14
}

void f_0602A540(SH2Context& c) {
    ran[572] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602A540 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602A542 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602A544 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602A546 sts.l pr,@-r15
    c.r[5] = (uint32_t)(int16_t)ld16(0x0602A6C4u);  // 0602A548 mov.w 0x0602A6C4,r5
    c.r[4] = ld32(0x0602A6ECu);  // 0602A54A mov.l 0x0602A6EC,r4
    c.r[8] = ld32(0x0602A6F0u);  // 0602A54C mov.l 0x0602A6F0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0602A552u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602A552u) return; }  // 0602A54E jsr @r8 ; mov r15,r14
    c.r[9] = ld32(0x0602A6F4u);  // 0602A552 mov.l 0x0602A6F4,r9
    c.r[5] = (uint32_t)(int16_t)ld16(0x0602A6C6u);  // 0602A554 mov.w 0x0602A6C6,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0602A55Au; c.r[4] = ld32(c.r[9]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602A55Au) return; }  // 0602A556 jsr @r8 ; mov.l @r9,r4
    c.r[1] = ld32(c.r[9]);  // 0602A55A mov.l @r9,r1
    c.r[1] += 8;  // 0602A55C add #8,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602A55E mov.b @r1,r0
    c.r[0] &= 0xFBu;  // 0602A560 and #251,r0
    st8(c.r[1], c.r[0]);  // 0602A562 mov.b r0,@r1
    c.r[1] = ld32(c.r[9]);  // 0602A564 mov.l @r9,r1
    c.r[1] += 8;  // 0602A566 add #8,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602A568 mov.b @r1,r0
    c.r[0] |= 0x8u;  // 0602A56A or #8,r0
    st8(c.r[1], c.r[0]);  // 0602A56C mov.b r0,@r1
    c.r[1] = ld32(c.r[9]);  // 0602A56E mov.l @r9,r1
    c.r[1] += 9;  // 0602A570 add #9,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602A572 mov.b @r1,r0
    c.r[0] |= 0x80u;  // 0602A574 or #128,r0
    st8(c.r[1], c.r[0]);  // 0602A576 mov.b r0,@r1
    c.r[1] = ld32(0x0602A6F8u);  // 0602A578 mov.l 0x0602A6F8,r1
    c.r[1] = ld32(c.r[1]);  // 0602A57A mov.l @r1,r1
    c.r[1] += 1;  // 0602A57C add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602A57E mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602A580 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0602A582 tst r1,r1
    if (!c.t) { goto L_0602A58C; }  // 0602A584 bf 0x0602A58C
    c.r[1] = ld32(0x0602A6FCu);  // 0602A586 mov.l 0x0602A6FC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602A58Cu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602A58Cu) return; }  // 0602A588 jsr @r1 ; mov #0,r4
L_0602A58C:
    c.r[1] = ld32(c.r[9]);  // 0602A58C mov.l @r9,r1
    c.r[1] += 8;  // 0602A58E add #8,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602A590 mov.b @r1,r0
    c.r[0] |= 0x2u;  // 0602A592 or #2,r0
    st8(c.r[1], c.r[0]);  // 0602A594 mov.b r0,@r1
    c.r[1] = ld32(c.r[9]);  // 0602A596 mov.l @r9,r1
    c.r[1] += 8;  // 0602A598 add #8,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602A59A mov.b @r1,r0
    c.r[0] |= 0x1u;  // 0602A59C or #1,r0
    st8(c.r[1], c.r[0]);  // 0602A59E mov.b r0,@r1
    c.r[2] = ld32(c.r[9]);  // 0602A5A0 mov.l @r9,r2
    c.r[1] = 0xFFFFFFFFu;  // 0602A5A2 mov #-1,r1
    c.r[6] = c.r[2];  // 0602A5A4 mov r2,r6
    c.r[6] += 4;  // 0602A5A6 add #4,r6
    c.r[7] = c.r[2];  // 0602A5A8 mov r2,r7
    c.r[7] += 5;  // 0602A5AA add #5,r7
    c.r[3] = c.r[2];  // 0602A5AC mov r2,r3
    c.r[3] += 6;  // 0602A5AE add #6,r3
    c.r[2] += 7;  // 0602A5B0 add #7,r2
    st8(c.r[2], c.r[1]);  // 0602A5B2 mov.b r1,@r2
    st8(c.r[3], c.r[1]);  // 0602A5B4 mov.b r1,@r3
    st8(c.r[7], c.r[1]);  // 0602A5B6 mov.b r1,@r7
    st8(c.r[6], c.r[1]);  // 0602A5B8 mov.b r1,@r6
    c.r[1] = ld32(c.r[9]);  // 0602A5BA mov.l @r9,r1
    c.r[5] = 0x2u;  // 0602A5BC mov #2,r5
    c.r[1] += 8;  // 0602A5BE add #8,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602A5C0 mov.b @r1,r0
    c.r[4] = 0xBu;  // 0602A5C2 mov #11,r4
    c.r[0] &= 0x3Fu;  // 0602A5C4 and #63,r0
    c.r[0] |= 0x40u;  // 0602A5C6 or #64,r0
    st8(c.r[1], c.r[0]);  // 0602A5C8 mov.b r0,@r1
    c.r[1] = ld32(c.r[9]);  // 0602A5CA mov.l @r9,r1
    c.r[7] = 0x6u;  // 0602A5CC mov #6,r7
    c.r[1] += 8;  // 0602A5CE add #8,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602A5D0 mov.b @r1,r0
    c.r[0] |= 0x1u;  // 0602A5D2 or #1,r0
    st8(c.r[1], c.r[0]);  // 0602A5D4 mov.b r0,@r1
    c.r[2] = ld32(c.r[9]);  // 0602A5D6 mov.l @r9,r2
    c.r[1] = 0x1u;  // 0602A5D8 mov #1,r1
    c.r[3] = c.r[2];  // 0602A5DA mov r2,r3
    c.r[3] += 14;  // 0602A5DC add #14,r3
    st16(c.r[3], c.r[1]);  // 0602A5DE mov.w r1,@r3
    c.r[2] += 16;  // 0602A5E0 add #16,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602A5E2 mov.b @r2,r0
    c.r[1] = 0xAu;  // 0602A5E4 mov #10,r1
    c.r[0] &= 0x1u;  // 0602A5E6 and #1,r0
    c.r[0] |= 0x2u;  // 0602A5E8 or #2,r0
    st8(c.r[2], c.r[0]);  // 0602A5EA mov.b r0,@r2
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0602A5EC mov.l r1,@-r15
    c.r[1] = 0x9u;  // 0602A5EE mov #9,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0602A5F0 mov.l r1,@-r15
    c.r[1] = 0x8u;  // 0602A5F2 mov #8,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0602A5F4 mov.l r1,@-r15
    c.r[1] = 0x7u;  // 0602A5F6 mov #7,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0602A5F8 mov.l r1,@-r15
    c.r[1] = 0x4u;  // 0602A5FA mov #4,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0602A5FC mov.l r1,@-r15
    c.r[1] = ld32(0x0602A700u);  // 0602A5FE mov.l 0x0602A700,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602A604u; c.r[6] = 0x5u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602A604u) return; }  // 0602A600 jsr @r1 ; mov #5,r6
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602A6C8u);  // 0602A604 mov.w 0x0602A6C8,r0
    c.r[1] = 0x0u;  // 0602A606 mov #0,r1
    c.r[15] += 20;  // 0602A608 add #20,r15
    c.r[7] = 0x2u;  // 0602A60A mov #2,r7
    c.r[6] = (uint32_t)(int16_t)ld16(0x0602A6CAu);  // 0602A60C mov.w 0x0602A6CA,r6
    c.r[2] = ld32(c.r[9]);  // 0602A60E mov.l @r9,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0602A6CCu);  // 0602A610 mov.w 0x0602A6CC,r3
    st32(c.r[0] + c.r[2], c.r[1]);  // 0602A612 mov.l r1,@(r0,r2)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602A6CEu);  // 0602A614 mov.w 0x0602A6CE,r0
    st32(c.r[0] + c.r[2], c.r[1]);  // 0602A616 mov.l r1,@(r0,r2)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602A6D0u);  // 0602A618 mov.w 0x0602A6D0,r0
    st32(c.r[0] + c.r[2], c.r[1]);  // 0602A61A mov.l r1,@(r0,r2)
L_0602A61C:
    c.r[0] = c.r[2];  // 0602A61C mov r2,r0
    st16(c.r[0] + c.r[6], c.r[3]);  // 0602A61E mov.w r3,@(r0,r6)
    c.r[1] += 1;  // 0602A620 add #1,r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[7];  // 0602A622 cmp/gt r7,r1
    { const bool k = !c.t; c.r[2] += 2; if (k) { SH2_POLL(c); goto L_0602A61C; } }  // 0602A624 bf/s 0x0602A61C ; add #2,r2
    c.r[1] = ld32(0x0602A704u);  // 0602A628 mov.l 0x0602A704,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602A62Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602A62Eu) return; }  // 0602A62A jsr @r1 ; nop
    c.r[7] = ld32(0x0602A6F4u);  // 0602A62E mov.l 0x0602A6F4,r7
    c.r[6] = ld32(c.r[7]);  // 0602A630 mov.l @r7,r6
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602A6D2u);  // 0602A632 mov.w 0x0602A6D2,r1
    c.r[3] = c.r[6];  // 0602A634 mov r6,r3
    c.r[3] += 18;  // 0602A636 add #18,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0602A638 mov.w @r3,r2
    c.r[0] = 0x64u;  // 0602A63A mov #100,r0
    c.r[1] &= c.r[2];  // 0602A63C and r2,r1
    c.r[1] |= c.r[0];  // 0602A63E or r0,r1
    st16(c.r[3], c.r[1]);  // 0602A640 mov.w r1,@r3
    c.r[2] = (uint32_t)(int16_t)ld16(0x0602A6D4u);  // 0602A642 mov.w 0x0602A6D4,r2
    c.r[1] = 0xFFFFFFFFu;  // 0602A644 mov #-1,r1
    c.r[0] = c.r[6];  // 0602A646 mov r6,r0
    st8(c.r[0] + c.r[2], c.r[1]);  // 0602A648 mov.b r1,@(r0,r2)
    c.r[1] = ld32(c.r[7]);  // 0602A64A mov.l @r7,r1
    c.r[6] = (uint32_t)(int16_t)ld16(0x0602A6D6u);  // 0602A64C mov.w 0x0602A6D6,r6
    c.r[0] = c.r[1];  // 0602A64E mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 0602A650 mov.b @(r0,r6),r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602A6D8u);  // 0602A652 mov.w 0x0602A6D8,r0
    c.r[2] &= c.r[0];  // 0602A654 and r0,r2
    c.r[0] = 0x4u;  // 0602A656 mov #4,r0
    c.r[2] |= c.r[0];  // 0602A658 or r0,r2
    c.r[0] = c.r[1];  // 0602A65A mov r1,r0
    st8(c.r[0] + c.r[6], c.r[2]);  // 0602A65C mov.b r2,@(r0,r6)
    c.r[3] = ld32(c.r[7]);  // 0602A65E mov.l @r7,r3
    c.r[5] = (uint32_t)(int16_t)ld16(0x0602A6DAu);  // 0602A660 mov.w 0x0602A6DA,r5
    c.r[0] = c.r[3];  // 0602A662 mov r3,r0
    c.r[1] = ld32(c.r[0] + c.r[5]);  // 0602A664 mov.l @(r0,r5),r1
    c.r[2] = ld32(0x0602A708u);  // 0602A666 mov.l 0x0602A708,r2
    c.r[1] &= c.r[2];  // 0602A668 and r2,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0602A6DCu);  // 0602A66A mov.w 0x0602A6DC,r2
    c.r[2] |= c.r[1];  // 0602A66C or r1,r2
    st32(c.r[0] + c.r[5], c.r[2]);  // 0602A66E mov.l r2,@(r0,r5)
    c.r[2] = (uint32_t)(int16_t)ld16(0x0602A6DEu);  // 0602A670 mov.w 0x0602A6DE,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0602A672 mov.b @(r0,r2),r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602A6E0u);  // 0602A674 mov.w 0x0602A6E0,r0
    c.r[1] &= c.r[0];  // 0602A676 and r0,r1
    c.r[0] = c.r[3];  // 0602A678 mov r3,r0
    st8(c.r[0] + c.r[2], c.r[1]);  // 0602A67A mov.b r1,@(r0,r2)
    c.r[1] = ld32(c.r[7]);  // 0602A67C mov.l @r7,r1
    c.r[0] = c.r[1];  // 0602A67E mov r1,r0
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 0602A680 mov.b @(r0,r6),r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602A6E2u);  // 0602A682 mov.w 0x0602A6E2,r0
    c.r[3] &= c.r[0];  // 0602A684 and r0,r3
    c.r[0] = c.r[1];  // 0602A686 mov r1,r0
    st8(c.r[0] + c.r[6], c.r[3]);  // 0602A688 mov.b r3,@(r0,r6)
    c.r[1] = ld32(c.r[7]);  // 0602A68A mov.l @r7,r1
    c.r[0] = c.r[1];  // 0602A68C mov r1,r0
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0602A68E mov.b @(r0,r2),r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602A6E4u);  // 0602A690 mov.w 0x0602A6E4,r0
    c.r[3] &= c.r[0];  // 0602A692 and r0,r3
    c.r[0] = c.r[1];  // 0602A694 mov r1,r0
    st8(c.r[0] + c.r[2], c.r[3]);  // 0602A696 mov.b r3,@(r0,r2)
    c.r[1] = ld32(c.r[7]);  // 0602A698 mov.l @r7,r1
    c.r[0] = c.r[1];  // 0602A69A mov r1,r0
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0602A69C mov.b @(r0,r2),r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602A6E6u);  // 0602A69E mov.w 0x0602A6E6,r0
    c.r[3] &= c.r[0];  // 0602A6A0 and r0,r3
    c.r[0] = c.r[1];  // 0602A6A2 mov r1,r0
    st8(c.r[0] + c.r[2], c.r[3]);  // 0602A6A4 mov.b r3,@(r0,r2)
    c.r[3] = (uint32_t)(int16_t)ld16(0x0602A6E8u);  // 0602A6A6 mov.w 0x0602A6E8,r3
    c.r[2] = ld32(c.r[7]);  // 0602A6A8 mov.l @r7,r2
    c.r[1] = 0x0u;  // 0602A6AA mov #0,r1
    c.r[0] = c.r[2];  // 0602A6AC mov r2,r0
    st8(c.r[0] + c.r[3], c.r[1]);  // 0602A6AE mov.b r1,@(r0,r3)
    c.r[1] = ld32(0x0602A70Cu);  // 0602A6B0 mov.l 0x0602A70C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602A6B6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602A6B6u) return; }  // 0602A6B2 jsr @r1 ; nop
    c.r[15] = c.r[14];  // 0602A6B6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602A6B8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602A6BA mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0602A6BC mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602A6EAu);  // 0602A6BE mov.w 0x0602A6EA,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602A6C0 rts ; mov.l @r15+,r8
}

void f_0602A710(SH2Context& c) {
    ran[573] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602A710 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602A712 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602A714 sts.l pr,@-r15
    c.r[1] = ld32(0x0602A778u);  // 0602A716 mov.l 0x0602A778,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602A71Cu; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602A71Cu) return; }  // 0602A718 jsr @r1 ; mov r15,r14
    c.r[8] = ld32(0x0602A77Cu);  // 0602A71C mov.l 0x0602A77C,r8
    c.r[2] = ld32(c.r[8]);  // 0602A71E mov.l @r8,r2
    c.r[0] = ld32(0x0602A780u);  // 0602A720 mov.l 0x0602A780,r0
    c.r[1] = c.r[2];  // 0602A722 mov r2,r1
    c.r[1] += 1;  // 0602A724 add #1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602A726 mov.b @r1,r4
    c.r[2] += 2;  // 0602A728 add #2,r2
    c.r[4] = c.r[4] & 0xFFu;  // 0602A72A extu.b r4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602A72C mov.b @r2,r1
    c.r[4] <<= 8;  // 0602A72E shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 0602A730 extu.b r1,r1
    { const uint32_t x = c.r[0]; c.pr = 0x0602A736u; c.r[4] |= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602A736u) return; }  // 0602A732 jsr @r0 ; or r1,r4
    c.r[1] = c.r[0] & 0xFFu;  // 0602A736 extu.b r0,r1
    c.r[7] = c.r[1];  // 0602A738 mov r1,r7
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602A772u);  // 0602A73A mov.w 0x0602A772,r1
    c.t = c.r[7] == c.r[1];  // 0602A73C cmp/eq r1,r7
    if (c.t) { goto L_0602A766; }  // 0602A73E bt 0x0602A766
    c.r[1] = ld32(c.r[8]);  // 0602A740 mov.l @r8,r1
    c.r[1] += 3;  // 0602A742 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602A744 mov.b @r1,r1
    c.r[3] = c.r[1] & 0xFFu;  // 0602A746 extu.b r1,r3
    c.r[1] = 0x63u;  // 0602A748 mov #99,r1
    c.t = c.r[3] > c.r[1];  // 0602A74A cmp/hi r1,r3
    if (!c.t) { goto L_0602A750; }  // 0602A74C bf 0x0602A750
    c.r[3] = c.r[1];  // 0602A74E mov r1,r3
L_0602A750:
    c.r[1] = ld32(0x0602A784u);  // 0602A750 mov.l 0x0602A784,r1
    c.r[1] = ld32(c.r[1]);  // 0602A752 mov.l @r1,r1
    c.r[2] = c.r[7];  // 0602A754 mov r7,r2
    c.r[2] += c.r[2];  // 0602A756 add r2,r2
    c.r[2] += c.r[7];  // 0602A758 add r7,r2
    c.r[2] <<= 2;  // 0602A75A shll2 r2
    c.r[2] += c.r[1];  // 0602A75C add r1,r2
    c.r[2] += 2;  // 0602A75E add #2,r2
    c.r[1] = ld32(0x0602A788u);  // 0602A760 mov.l 0x0602A788,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602A766u; st8(c.r[2], c.r[3]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602A766u) return; }  // 0602A762 jsr @r1 ; mov.b r3,@r2
L_0602A766:
    c.r[15] = c.r[14];  // 0602A766 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602A768 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602A76A mov.l @r15+,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602A774u);  // 0602A76C mov.w 0x0602A774,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602A76E rts ; mov.l @r15+,r8
}

void f_0602A78C(SH2Context& c) {
    ran[574] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602A78C mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0602A78E mov r15,r14
    c.r[1] = ld32(0x0602A7C0u);  // 0602A790 mov.l 0x0602A7C0,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x0602A7BAu);  // 0602A792 mov.w 0x0602A7BA,r3
    c.r[2] = ld32(c.r[1]);  // 0602A794 mov.l @r1,r2
    c.r[7] = 0x3u;  // 0602A796 mov #3,r7
    c.r[1] = ld32(0x0602A7C4u);  // 0602A798 mov.l 0x0602A7C4,r1
    c.r[1] = ld32(c.r[1]);  // 0602A79A mov.l @r1,r1
    c.r[1] += 1;  // 0602A79C add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602A79E mov.b @r1,r1
    c.r[0] = c.r[2];  // 0602A7A0 mov r2,r0
    c.r[7] &= c.r[1];  // 0602A7A2 and r1,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0602A7A4 mov.b @(r0,r3),r1
    c.r[7] <<= 2;  // 0602A7A6 shll2 r7
    c.r[7] <<= 2;  // 0602A7A8 shll2 r7
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602A7BCu);  // 0602A7AA mov.w 0x0602A7BC,r0
    c.r[1] &= c.r[0];  // 0602A7AC and r0,r1
    c.r[1] |= c.r[7];  // 0602A7AE or r7,r1
    c.r[0] = c.r[2];  // 0602A7B0 mov r2,r0
    st8(c.r[0] + c.r[3], c.r[1]);  // 0602A7B2 mov.b r1,@(r0,r3)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602A7BEu);  // 0602A7B4 mov.w 0x0602A7BE,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602A7B6 rts ; mov.l @r15+,r14
}

void f_0602A7C8(SH2Context& c) {
    ran[575] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602A7C8 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0602A7CA mov r15,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602A7D2u);  // 0602A7CC mov.w 0x0602A7D2,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602A7CE rts ; mov.l @r15+,r14
}

void f_0602A7D4(SH2Context& c) {
    ran[576] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602A7D4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602A7D6 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602A7D8 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0602A7DA mov r15,r14
    c.r[1] = ld32(0x0602A848u);  // 0602A7DC mov.l 0x0602A848,r1
    c.r[2] = ld32(c.r[1]);  // 0602A7DE mov.l @r1,r2
    c.r[4] = (uint32_t)(int16_t)ld16(0x0602A840u);  // 0602A7E0 mov.w 0x0602A840,r4
    c.r[1] = c.r[2];  // 0602A7E2 mov r2,r1
    c.r[1] += 1;  // 0602A7E4 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602A7E6 mov.b @r1,r1
    c.r[2] += 2;  // 0602A7E8 add #2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0602A7EA extu.b r1,r1
    c.r[8] = c.r[1];  // 0602A7EC mov r1,r8
    c.r[8] <<= 8;  // 0602A7EE shll8 r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602A7F0 mov.b @r2,r1
    c.r[0] = ld32(0x0602A84Cu);  // 0602A7F2 mov.l 0x0602A84C,r0
    c.r[1] = c.r[1] & 0xFFu;  // 0602A7F4 extu.b r1,r1
    c.r[8] |= c.r[1];  // 0602A7F6 or r1,r8
    { const uint32_t x = c.r[0]; c.pr = 0x0602A7FCu; c.r[4] &= c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602A7FCu) return; }  // 0602A7F8 jsr @r0 ; and r8,r4
    c.r[3] = c.r[0] & 0xFFu;  // 0602A7FC extu.b r0,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602A842u);  // 0602A7FE mov.w 0x0602A842,r1
    c.t = c.r[3] == c.r[1];  // 0602A800 cmp/eq r1,r3
    { const bool k = c.t; c.r[2] = c.r[3]; if (k) { goto L_0602A834; } }  // 0602A802 bt/s 0x0602A834 ; mov r3,r2
    c.r[1] = ld32(0x0602A850u);  // 0602A806 mov.l 0x0602A850,r1
    c.r[1] = ld32(c.r[1]);  // 0602A808 mov.l @r1,r1
    c.r[2] <<= 2;  // 0602A80A shll2 r2
    c.r[2] <<= 2;  // 0602A80C shll2 r2
    c.r[2] += c.r[1];  // 0602A80E add r1,r2
    c.r[2] += 7;  // 0602A810 add #7,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602A812 mov.b @r2,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0602A814 extu.b r1,r0
    c.r[0] >>= 2;  // 0602A816 shlr2 r0
    c.r[0] >>= 2;  // 0602A818 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0602A81A shlr r0
    c.r[0] >>= 2;  // 0602A81C shlr2 r0
    c.t = c.r[0] == 0x1u;  // 0602A81E cmp/eq #1,r0
    { const bool k = !c.t; c.r[8] >>= 8; if (k) { goto L_0602A834; } }  // 0602A820 bf/s 0x0602A834 ; shlr8 r8
    c.r[1] = ld32(0x0602A854u);  // 0602A824 mov.l 0x0602A854,r1
    c.r[1] = ld32(c.r[1]);  // 0602A826 mov.l @r1,r1
    c.r[0] = 0x6u;  // 0602A828 mov #6,r0
    c.r[8] &= c.r[0];  // 0602A82A and r0,r8
    c.r[8] += c.r[1];  // 0602A82C add r1,r8
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602A844u);  // 0602A82E mov.w 0x0602A844,r1
    c.r[0] = c.r[8];  // 0602A830 mov r8,r0
    st16(c.r[0] + c.r[1], c.r[3]);  // 0602A832 mov.w r3,@(r0,r1)
L_0602A834:
    c.r[15] = c.r[14];  // 0602A834 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602A836 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602A838 mov.l @r15+,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602A846u);  // 0602A83A mov.w 0x0602A846,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602A83C rts ; mov.l @r15+,r8
}

void f_0602A858(SH2Context& c) {
    ran[577] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602A858 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602A85A sts.l pr,@-r15
    c.r[1] = ld32(0x0602A88Cu);  // 0602A85C mov.l 0x0602A88C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602A862u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602A862u) return; }  // 0602A85E jsr @r1 ; mov r15,r14
    c.r[1] = ld32(0x0602A890u);  // 0602A862 mov.l 0x0602A890,r1
    c.r[1] = ld32(c.r[1]);  // 0602A864 mov.l @r1,r1
    c.r[1] += 1;  // 0602A866 add #1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602A868 mov.b @r1,r4
    c.r[0] = ld32(0x0602A894u);  // 0602A86A mov.l 0x0602A894,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602A870u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602A870u) return; }  // 0602A86C jsr @r0 ; extu.b r4,r4
    c.r[2] = c.r[0] & 0xFFu;  // 0602A870 extu.b r0,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602A888u);  // 0602A872 mov.w 0x0602A888,r1
    c.t = c.r[2] == c.r[1];  // 0602A874 cmp/eq r1,r2
    if (c.t) { goto L_0602A87E; }  // 0602A876 bt 0x0602A87E
    c.r[1] = ld32(0x0602A898u);  // 0602A878 mov.l 0x0602A898,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602A87Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602A87Eu) return; }  // 0602A87A jsr @r1 ; nop
L_0602A87E:
    c.r[15] = c.r[14];  // 0602A87E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602A880 lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602A88Au);  // 0602A882 mov.w 0x0602A88A,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602A884 rts ; mov.l @r15+,r14
}

void f_0602A89C(SH2Context& c) {
    ran[578] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602A89C mov.l r14,@-r15
    c.r[1] = ld32(0x0602A908u);  // 0602A89E mov.l 0x0602A908,r1
    c.r[3] = ld32(c.r[1]);  // 0602A8A0 mov.l @r1,r3
    c.r[1] = c.r[3];  // 0602A8A2 mov r3,r1
    c.r[1] += 1;  // 0602A8A4 add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602A8A6 mov.b @r1,r2
    c.r[3] += 2;  // 0602A8A8 add #2,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0602A8AA extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0602A8AC mov.b @r3,r1
    c.r[2] <<= 8;  // 0602A8AE shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0602A8B0 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0602A8B2 or r1,r2
    c.r[6] = c.r[2];  // 0602A8B4 mov r2,r6
    c.r[1] = ld32(0x0602A90Cu);  // 0602A8B6 mov.l 0x0602A90C,r1
    c.t = c.r[6] == c.r[1];  // 0602A8B8 cmp/eq r1,r6
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0602A8DA; } }  // 0602A8BA bf/s 0x0602A8DA ; mov r15,r14
    c.r[1] = ld32(0x0602A910u);  // 0602A8BE mov.l 0x0602A910,r1
    c.r[1] = ld32(c.r[1]);  // 0602A8C0 mov.l @r1,r1
    c.r[1] += 18;  // 0602A8C2 add #18,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0602A8C4 mov.w @r1,r1
    c.r[2] = ld32(0x0602A914u);  // 0602A8C6 mov.l 0x0602A914,r2
    c.r[1] <<= 16;  // 0602A8C8 shll16 r1
    c.r[1] <<= 2;  // 0602A8CA shll2 r1
    c.r[1] += c.r[1];  // 0602A8CC add r1,r1
    c.r[1] <<= 2;  // 0602A8CE shll2 r1
    c.r[1] >>= 16;  // 0602A8D0 shlr16 r1
    c.r[1] <<= 2;  // 0602A8D2 shll2 r1
    c.r[1] >>= 8;  // 0602A8D4 shlr8 r1
    st32(c.r[2] + 20, c.r[1]); goto L_0602A8F8;  // 0602A8D6 bra 0x0602A8F8 ; mov.l r1,@(20,r2)
L_0602A8DA:
    c.r[1] = ld32(0x0602A910u);  // 0602A8DA mov.l 0x0602A910,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0602A900u);  // 0602A8DC mov.w 0x0602A900,r2
    c.r[7] = ld32(c.r[1]);  // 0602A8DE mov.l @r1,r7
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602A902u);  // 0602A8E0 mov.w 0x0602A902,r0
    c.r[3] = c.r[7];  // 0602A8E2 mov r7,r3
    c.r[3] += 18;  // 0602A8E4 add #18,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602A904u);  // 0602A8E6 mov.w 0x0602A904,r1
    c.r[6] &= c.r[1];  // 0602A8E8 and r1,r6
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0602A8EA mov.w @r3,r1
    c.r[6] += c.r[6];  // 0602A8EC add r6,r6
    c.r[1] &= c.r[2];  // 0602A8EE and r2,r1
    c.r[1] |= c.r[6];  // 0602A8F0 or r6,r1
    st16(c.r[3], c.r[1]);  // 0602A8F2 mov.w r1,@r3
    c.r[1] = 0xFFFFFFFFu;  // 0602A8F4 mov #-1,r1
    st8(c.r[0] + c.r[7], c.r[1]);  // 0602A8F6 mov.b r1,@(r0,r7)
L_0602A8F8:
    c.r[15] = c.r[14];  // 0602A8F8 mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602A906u);  // 0602A8FA mov.w 0x0602A906,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602A8FC rts ; mov.l @r15+,r14
}

void f_0602A918(SH2Context& c) {
    ran[579] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602A918 mov.l r14,@-r15
    c.r[1] = ld32(0x0602A9A8u);  // 0602A91A mov.l 0x0602A9A8,r1
    c.r[1] = ld32(c.r[1]);  // 0602A91C mov.l @r1,r1
    c.r[1] += 1;  // 0602A91E add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602A920 mov.b @r1,r2
    c.r[14] = c.r[15];  // 0602A922 mov r15,r14
    c.t = (int32_t)c.r[2] >= 0;  // 0602A924 cmp/pz r2
    { const bool k = !c.t; c.r[1] = c.r[2]; if (k) { goto L_0602A95E; } }  // 0602A926 bf/s 0x0602A95E ; mov r2,r1
    c.r[1] = ld32(0x0602A9ACu);  // 0602A92A mov.l 0x0602A9AC,r1
    c.r[6] = ld32(c.r[1]);  // 0602A92C mov.l @r1,r6
    c.r[5] = (uint32_t)(int16_t)ld16(0x0602A99Cu);  // 0602A92E mov.w 0x0602A99C,r5
    c.r[6] += 18;  // 0602A930 add #18,r6
    c.r[7] = (uint32_t)(int16_t)ld16(c.r[6]);  // 0602A932 mov.w @r6,r7
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602A99Eu);  // 0602A934 mov.w 0x0602A99E,r1
    c.r[3] = c.r[7] & 0xFFFFu;  // 0602A936 extu.w r7,r3
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 0602A938 shlr r3
    c.r[3] &= c.r[5];  // 0602A93A and r5,r3
    c.r[3] += c.r[2];  // 0602A93C add r2,r3
    c.t = c.r[3] > c.r[1];  // 0602A93E cmp/hi r1,r3
    { const bool k = c.t; c.r[2] = c.r[7]; if (k) { goto L_0602A952; } }  // 0602A940 bt/s 0x0602A952 ; mov r7,r2
    c.r[3] &= c.r[5];  // 0602A944 and r5,r3
    c.r[3] += c.r[3];  // 0602A946 add r3,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602A9A0u);  // 0602A948 mov.w 0x0602A9A0,r1
    c.r[1] &= c.r[7];  // 0602A94A and r7,r1
    c.r[1] |= c.r[3];  // 0602A94C or r3,r1
    st16(c.r[6], c.r[1]); goto L_0602A994;  // 0602A94E bra 0x0602A994 ; mov.w r1,@r6
L_0602A952:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602A9A0u);  // 0602A952 mov.w 0x0602A9A0,r1
    c.r[2] &= c.r[1];  // 0602A954 and r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602A9A2u);  // 0602A956 mov.w 0x0602A9A2,r1
    c.r[2] |= c.r[1];  // 0602A958 or r1,r2
    st16(c.r[6], c.r[2]); goto L_0602A994;  // 0602A95A bra 0x0602A994 ; mov.w r2,@r6
L_0602A95E:
    c.r[1] = 0u - c.r[1];  // 0602A95E neg r1,r1
    c.r[6] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 0602A960 exts.w r1,r6
    c.r[1] = ld32(0x0602A9ACu);  // 0602A962 mov.l 0x0602A9AC,r1
    c.r[7] = ld32(c.r[1]);  // 0602A964 mov.l @r1,r7
    c.r[7] += 18;  // 0602A966 add #18,r7
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[7]);  // 0602A968 mov.w @r7,r2
    c.r[5] = (uint32_t)(int16_t)ld16(0x0602A99Cu);  // 0602A96A mov.w 0x0602A99C,r5
    c.r[3] = c.r[2] & 0xFFFFu;  // 0602A96C extu.w r2,r3
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 0602A96E shlr r3
    c.r[1] = c.r[3];  // 0602A970 mov r3,r1
    c.r[1] &= c.r[5];  // 0602A972 and r5,r1
    c.r[1] -= c.r[6];  // 0602A974 sub r6,r1
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 0602A976 exts.w r1,r1
    c.t = (int32_t)c.r[1] >= 0;  // 0602A978 cmp/pz r1
    if (!c.t) { goto L_0602A98E; }  // 0602A97A bf 0x0602A98E
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602A99Cu);  // 0602A97C mov.w 0x0602A99C,r1
    c.r[3] &= c.r[1];  // 0602A97E and r1,r3
    c.r[3] -= c.r[6];  // 0602A980 sub r6,r3
    c.r[3] &= c.r[5];  // 0602A982 and r5,r3
    c.r[3] += c.r[3];  // 0602A984 add r3,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602A9A0u);  // 0602A986 mov.w 0x0602A9A0,r1
    c.r[1] &= c.r[2];  // 0602A988 and r2,r1
    c.r[1] |= c.r[3]; goto L_0602A992;  // 0602A98A bra 0x0602A992 ; or r3,r1
L_0602A98E:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602A9A0u);  // 0602A98E mov.w 0x0602A9A0,r1
    c.r[1] &= c.r[2];  // 0602A990 and r2,r1
L_0602A992:
    st16(c.r[7], c.r[1]);  // 0602A992 mov.w r1,@r7
L_0602A994:
    c.r[15] = c.r[14];  // 0602A994 mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602A9A4u);  // 0602A996 mov.w 0x0602A9A4,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602A998 rts ; mov.l @r15+,r14
}

void f_0602A9B0(SH2Context& c) {
    ran[580] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602A9B0 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0602A9B2 mov r15,r14
    c.r[1] = ld32(0x0602A9CCu);  // 0602A9B4 mov.l 0x0602A9CC,r1
    c.r[1] = ld32(c.r[1]);  // 0602A9B6 mov.l @r1,r1
    c.r[2] = ld32(0x0602A9D0u);  // 0602A9B8 mov.l 0x0602A9D0,r2
    c.r[1] += 6;  // 0602A9BA add #6,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602A9BC mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602A9BE extu.b r1,r1
    st32(c.r[2] + 20, c.r[1]);  // 0602A9C0 mov.l r1,@(20,r2)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602A9C8u);  // 0602A9C2 mov.w 0x0602A9C8,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602A9C4 rts ; mov.l @r15+,r14
}

void f_0602A9D4(SH2Context& c) {
    ran[581] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602A9D4 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0602A9D6 mov r15,r14
    c.r[2] = ld32(0x0602AA00u);  // 0602A9D8 mov.l 0x0602AA00,r2
    c.r[1] = ld32(c.r[2]);  // 0602A9DA mov.l @r2,r1
    c.r[3] = ld32(0x0602AA04u);  // 0602A9DC mov.l 0x0602AA04,r3
    c.r[7] = ld32(c.r[3]);  // 0602A9DE mov.l @r3,r7
    c.r[1] += 1;  // 0602A9E0 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602A9E2 mov.b @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602A9FAu);  // 0602A9E4 mov.w 0x0602A9FA,r0
    st8(c.r[0] + c.r[7], c.r[1]);  // 0602A9E6 mov.b r1,@(r0,r7)
    c.r[1] = ld32(c.r[2]);  // 0602A9E8 mov.l @r2,r1
    c.r[3] = ld32(c.r[3]);  // 0602A9EA mov.l @r3,r3
    c.r[1] += 2;  // 0602A9EC add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602A9EE mov.b @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602A9FCu);  // 0602A9F0 mov.w 0x0602A9FC,r0
    st8(c.r[0] + c.r[3], c.r[1]);  // 0602A9F2 mov.b r1,@(r0,r3)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602A9FEu);  // 0602A9F4 mov.w 0x0602A9FE,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602A9F6 rts ; mov.l @r15+,r14
}

void f_0602AA08(SH2Context& c) {
    ran[582] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602AA08 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0602AA0A mov r15,r14
    c.r[1] = ld32(0x0602AA34u);  // 0602AA0C mov.l 0x0602AA34,r1
    c.r[2] = ld32(c.r[1]);  // 0602AA0E mov.l @r1,r2
    c.r[1] = ld32(0x0602AA38u);  // 0602AA10 mov.l 0x0602AA38,r1
    c.r[1] = ld32(c.r[1]);  // 0602AA12 mov.l @r1,r1
    c.r[2] += 9;  // 0602AA14 add #9,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602AA16 mov.b @r2,r0
    c.r[1] += 1;  // 0602AA18 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602AA1A mov.b @r1,r1
    c.r[0] &= 0x7Fu;  // 0602AA1C and #127,r0
    c.r[1] = c.r[1] & 0xFFu;  // 0602AA1E extu.b r1,r1
    c.r[1] <<= 2;  // 0602AA20 shll2 r1
    c.r[1] <<= 2;  // 0602AA22 shll2 r1
    c.r[1] += c.r[1];  // 0602AA24 add r1,r1
    c.r[1] <<= 2;  // 0602AA26 shll2 r1
    c.r[0] |= c.r[1];  // 0602AA28 or r1,r0
    st8(c.r[2], c.r[0]);  // 0602AA2A mov.b r0,@r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602AA32u);  // 0602AA2C mov.w 0x0602AA32,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602AA2E rts ; mov.l @r15+,r14
}

void f_0602AA3C(SH2Context& c) {
    ran[583] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602AA3C mov.l r14,@-r15
    c.r[1] = ld32(0x0602AA64u);  // 0602AA3E mov.l 0x0602AA64,r1
    c.r[1] = ld32(c.r[1]);  // 0602AA40 mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602AA5Eu);  // 0602AA42 mov.w 0x0602AA5E,r0
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 0602AA44 mov.l @(r0,r1),r2
    c.r[14] = c.r[15];  // 0602AA46 mov r15,r14
    c.r[1] = ld32(0x0602AA68u);  // 0602AA48 mov.l 0x0602AA68,r1
    { uint64_t p = (uint64_t)c.r[2] * c.r[1]; c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 0602AA4A dmulu.l r1,r2
    c.r[3] = ld32(0x0602AA6Cu);  // 0602AA4C mov.l 0x0602AA6C,r3
    c.r[1] = c.mach;  // 0602AA4E sts mach,r1
    c.r[1] >>= 2;  // 0602AA50 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0602AA52 shlr r1
    c.r[1] >>= 2;  // 0602AA54 shlr2 r1
    st32(c.r[3] + 20, c.r[1]);  // 0602AA56 mov.l r1,@(20,r3)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602AA60u);  // 0602AA58 mov.w 0x0602AA60,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602AA5A rts ; mov.l @r15+,r14
}

void f_0602AA70(SH2Context& c) {
    ran[584] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602AA70 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602AA72 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0602AA74 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0602AA76 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0602AA78 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0602AA7A mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602AA7C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602AA7E sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x0602ABDCu);  // 0602AA80 mov.w 0x0602ABDC,r3
    c.r[15] += c.r[3];  // 0602AA82 add r3,r15
    c.r[14] = c.r[15];  // 0602AA84 mov r15,r14
    c.r[1] = ld32(0x0602ABE4u);  // 0602AA86 mov.l 0x0602ABE4,r1
    c.r[3] = ld32(c.r[1]);  // 0602AA88 mov.l @r1,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602ABDEu);  // 0602AA8A mov.w 0x0602ABDE,r0
    c.r[1] = c.r[3];  // 0602AA8C mov r3,r1
    c.r[1] += 1;  // 0602AA8E add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602AA90 mov.b @r1,r2
    c.r[0] += c.r[14];  // 0602AA92 add r14,r0
    c.r[2] = c.r[2] & 0xFFu;  // 0602AA94 extu.b r2,r2
    c.r[1] = c.r[3];  // 0602AA96 mov r3,r1
    c.r[1] += 2;  // 0602AA98 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602AA9A mov.b @r1,r1
    c.r[2] <<= 8;  // 0602AA9C shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0602AA9E extu.b r1,r1
    c.r[2] |= c.r[1];  // 0602AAA0 or r1,r2
    c.r[8] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0602AAA2 exts.w r2,r8
    c.r[9] = c.r[8];  // 0602AAA4 mov r8,r9
    c.r[1] = c.r[3];  // 0602AAA6 mov r3,r1
    c.r[1] += 3;  // 0602AAA8 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602AAAA mov.b @r1,r1
    c.r[3] += 4;  // 0602AAAC add #4,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0602AAAE extu.b r1,r1
    c.r[13] = c.r[1];  // 0602AAB0 mov r1,r13
    c.r[13] <<= 8;  // 0602AAB2 shll8 r13
    st32(c.r[0], c.r[13]);  // 0602AAB4 mov.l r13,@r0
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602ABDEu);  // 0602AAB6 mov.w 0x0602ABDE,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0602AAB8 mov.b @r3,r1
    c.r[0] += c.r[14];  // 0602AABA add r14,r0
    c.r[13] = ld32(c.r[0]);  // 0602AABC mov.l @r0,r13
    c.r[1] = c.r[1] & 0xFFu;  // 0602AABE extu.b r1,r1
    c.r[13] |= c.r[1];  // 0602AAC0 or r1,r13
    c.r[1] = ld32(0x0602ABE8u);  // 0602AAC2 mov.l 0x0602ABE8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602AAC8u; st32(c.r[0], c.r[13]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602AAC8u) return; }  // 0602AAC4 jsr @r1 ; mov.l r13,@r0
    c.r[10] = (uint32_t)(int16_t)ld16(0x0602ABE0u);  // 0602AAC8 mov.w 0x0602ABE0,r10
    c.r[13] = 0xFFFFFFFFu;  // 0602AACA mov #-1,r13
    c.r[0] = 0x7Cu;  // 0602AACC mov #124,r0
    c.r[0] += c.r[14];  // 0602AACE add r14,r0
    c.t = (int32_t)c.r[8] > 0;  // 0602AAD0 cmp/pl r8
    { const bool k = !c.t; st32(c.r[0], c.r[13]); if (k) { goto L_0602AB3E; } }  // 0602AAD2 bf/s 0x0602AB3E ; mov.l r13,@r0
    c.r[13] = 0x1u;  // 0602AAD6 mov #1,r13
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602ABE2u);  // 0602AAD8 mov.w 0x0602ABE2,r0
    st32(c.r[0] + c.r[14], c.r[13]);  // 0602AADA mov.l r13,@(r0,r14)
    c.r[0] = ld32(0x0602ABECu);  // 0602AADC mov.l 0x0602ABEC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602AAE2u; c.r[4] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602AAE2u) return; }  // 0602AADE jsr @r0 ; extu.w r8,r4
    c.r[1] = c.r[0];  // 0602AAE2 mov r0,r1
    c.r[10] = c.r[1] & 0xFFu;  // 0602AAE4 extu.b r1,r10
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602ABE0u);  // 0602AAE6 mov.w 0x0602ABE0,r1
    c.t = c.r[10] == c.r[1];  // 0602AAE8 cmp/eq r1,r10
    { const bool k = !c.t; c.r[2] = c.r[10]; if (k) { goto L_0602AAF2; } }  // 0602AAEA bf/s 0x0602AAF2 ; mov r10,r2
    goto L_0602ACD0;  // 0602AAEE bra 0x0602ACD0 ; nop
L_0602AAF2:
    c.r[1] = ld32(0x0602ABF0u);  // 0602AAF2 mov.l 0x0602ABF0,r1
    c.r[2] += c.r[2];  // 0602AAF4 add r2,r2
    c.r[2] += c.r[10];  // 0602AAF6 add r10,r2
    c.r[1] = ld32(c.r[1]);  // 0602AAF8 mov.l @r1,r1
    c.r[2] <<= 2;  // 0602AAFA shll2 r2
    c.r[2] += c.r[1];  // 0602AAFC add r1,r2
    c.r[2] += 3;  // 0602AAFE add #3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602AB00 mov.b @r2,r1
    c.r[0] = c.r[1];  // 0602AB02 mov r1,r0
    c.r[0] >>= 2;  // 0602AB04 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0602AB06 shlr r0
    c.r[0] &= 0x1u;  // 0602AB08 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0602AB0A tst r0,r0
    { const bool k = c.t; c.r[4] = c.r[10]; if (k) { goto L_0602AB28; } }  // 0602AB0C bt/s 0x0602AB28 ; mov r10,r4
    c.r[13] = 0x7Cu;  // 0602AB10 mov #124,r13
    c.r[13] += c.r[14];  // 0602AB12 add r14,r13
    st32(c.r[13], c.r[10]);  // 0602AB14 mov.l r10,@r13
    c.r[0] = ld32(0x0602ABF4u);  // 0602AB16 mov.l 0x0602ABF4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602AB1Cu; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602AB1Cu) return; }  // 0602AB18 jsr @r0 ; mov r10,r4
    c.r[1] = c.r[0];  // 0602AB1C mov r0,r1
    c.r[4] = c.r[1] & 0xFFu;  // 0602AB1E extu.b r1,r4
    c.r[13] = (uint32_t)(int16_t)ld16(0x0602ABE2u);  // 0602AB20 mov.w 0x0602ABE2,r13
    c.r[13] += c.r[14];  // 0602AB22 add r14,r13
    c.r[5] = ld32(c.r[13]); goto L_0602AB2E;  // 0602AB24 bra 0x0602AB2E ; mov.l @r13,r5
L_0602AB28:
    c.r[13] = (uint32_t)(int16_t)ld16(0x0602ABE2u);  // 0602AB28 mov.w 0x0602ABE2,r13
    c.r[13] += c.r[14];  // 0602AB2A add r14,r13
    c.r[5] = ld32(c.r[13]);  // 0602AB2C mov.l @r13,r5
L_0602AB2E:
    c.r[0] = ld32(0x0602ABF8u);  // 0602AB2E mov.l 0x0602ABF8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602AB34u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602AB34u) return; }  // 0602AB30 jsr @r0 ; nop
    c.r[2] = c.r[0];  // 0602AB34 mov r0,r2
    c.r[1] = c.r[14];  // 0602AB36 mov r14,r1
    c.r[1] += 48;  // 0602AB38 add #48,r1
    st8(c.r[1], c.r[2]); goto L_0602AB54;  // 0602AB3A bra 0x0602AB54 ; mov.b r2,@r1
L_0602AB3E:
    c.r[5] = c.r[14];  // 0602AB3E mov r14,r5
    c.r[5] += 48;  // 0602AB40 add #48,r5
    c.r[1] = ld32(0x0602ABFCu);  // 0602AB42 mov.l 0x0602ABFC,r1
    c.r[4] = ld32(c.r[1]);  // 0602AB44 mov.l @r1,r4
    c.r[7] = 0x0u;  // 0602AB46 mov #0,r7
    c.r[13] = ld32(0x0602AC00u);  // 0602AB48 mov.l 0x0602AC00,r13
    { const uint32_t x = c.r[13]; c.pr = 0x0602AB4Eu; c.r[6] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602AB4Eu) return; }  // 0602AB4A jsr @r13 ; mov r9,r6
    c.r[13] = (uint32_t)(int16_t)ld16(0x0602ABE2u);  // 0602AB4E mov.w 0x0602ABE2,r13
    c.r[13] += c.r[14];  // 0602AB50 add r14,r13
    st32(c.r[13], c.r[0]);  // 0602AB52 mov.l r0,@r13
L_0602AB54:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602ABE2u);  // 0602AB54 mov.w 0x0602ABE2,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 0602AB56 mov.l @(r0,r14),r0
    c.r[12] = 0x0u;  // 0602AB58 mov #0,r12
    c.t = (int32_t)c.r[12] >= (int32_t)c.r[0];  // 0602AB5A cmp/ge r0,r12
    { const bool k = !c.t; c.r[1] = c.r[14]; if (k) { goto L_0602AB64; } }  // 0602AB5C bf/s 0x0602AB64 ; mov r14,r1
    goto L_0602ACD0;  // 0602AB60 bra 0x0602ACD0 ; nop
L_0602AB64:
    c.r[11] = ld32(0x0602ABF0u);  // 0602AB64 mov.l 0x0602ABF0,r11
L_0602AB66:
    c.r[1] += 48;  // 0602AB66 add #48,r1
    c.r[0] = c.r[1];  // 0602AB68 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[12]);  // 0602AB6A mov.b @(r0,r12),r1
    c.r[4] = c.r[1] & 0xFFu;  // 0602AB6C extu.b r1,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602ABE0u);  // 0602AB6E mov.w 0x0602ABE0,r1
    c.t = c.r[4] == c.r[1];  // 0602AB70 cmp/eq r1,r4
    { const bool k = c.t; c.r[0] = 0x7Cu; if (k) { goto L_0602AC24; } }  // 0602AB72 bt/s 0x0602AC24 ; mov #124,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 0602AB76 mov.l @(r0,r14),r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0602AB78 cmp/eq #-1,r0
    { const bool k = !c.t; c.r[2] = c.r[4]; if (k) { goto L_0602ABA2; } }  // 0602AB7A bf/s 0x0602ABA2 ; mov r4,r2
    c.r[1] = ld32(0x0602ABFCu);  // 0602AB7E mov.l 0x0602ABFC,r1
    c.r[1] = ld32(c.r[1]);  // 0602AB80 mov.l @r1,r1
    c.r[2] <<= 2;  // 0602AB82 shll2 r2
    c.r[2] <<= 2;  // 0602AB84 shll2 r2
    c.r[2] += c.r[1];  // 0602AB86 add r1,r2
    c.r[2] += 2;  // 0602AB88 add #2,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602AB8A mov.b @r2,r2
    c.r[1] = ld32(0x0602AC04u);  // 0602AB8C mov.l 0x0602AC04,r1
    c.r[3] = ld32(c.r[1]);  // 0602AB8E mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0602AB90 extu.b r2,r2
    c.r[1] = 0x1Eu;  // 0602AB92 mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 0602AB94 mul.l r1,r2
    c.r[1] = c.macl;  // 0602AB96 sts macl,r1
    c.r[1] += c.r[3];  // 0602AB98 add r3,r1
    c.r[1] += 15;  // 0602AB9A add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602AB9C mov.b @r1,r1
    c.r[10] = c.r[1] & 0xFFu; goto L_0602ABAA;  // 0602AB9E bra 0x0602ABAA ; extu.b r1,r10
L_0602ABA2:
    c.r[13] = 0x7Fu;  // 0602ABA2 mov #127,r13
    c.r[13] += c.r[14];  // 0602ABA4 add r14,r13
    c.r[13] = (uint32_t)(int8_t)ld8(c.r[13]);  // 0602ABA6 mov.b @r13,r13
    c.r[10] = c.r[13] & 0xFFu;  // 0602ABA8 extu.b r13,r10
L_0602ABAA:
    c.r[3] = c.r[10];  // 0602ABAA mov r10,r3
    c.r[3] += c.r[3];  // 0602ABAC add r3,r3
    c.r[3] += c.r[10];  // 0602ABAE add r10,r3
    c.r[1] = ld32(c.r[11]);  // 0602ABB0 mov.l @r11,r1
    c.r[3] <<= 2;  // 0602ABB2 shll2 r3
    c.r[3] += c.r[1];  // 0602ABB4 add r1,r3
    c.r[1] = c.r[3];  // 0602ABB6 mov r3,r1
    c.r[1] += 2;  // 0602ABB8 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602ABBA mov.b @r1,r1
    c.r[2] = 0x62u;  // 0602ABBC mov #98,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0602ABBE extu.b r1,r1
    c.t = c.r[1] > c.r[2];  // 0602ABC0 cmp/hi r2,r1
    { const bool k = c.t; c.r[1] = 0x2Eu; if (k) { goto L_0602AC0C; } }  // 0602ABC2 bt/s 0x0602AC0C ; mov #46,r1
    c.r[1] = c.r[3];  // 0602ABC6 mov r3,r1
    c.r[1] += 4;  // 0602ABC8 add #4,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602ABDEu);  // 0602ABCA mov.w 0x0602ABDE,r0
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0602ABCC mov.w @r1,r2
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 0602ABCE mov.l @(r0,r14),r0
    c.r[13] = ld32(0x0602AC08u);  // 0602ABD0 mov.l 0x0602AC08,r13
    c.r[2] -= c.r[0];  // 0602ABD2 sub r0,r2
    { const uint32_t x = c.r[13]; c.pr = 0x0602ABD8u; st16(c.r[1], c.r[2]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602ABD8u) return; }  // 0602ABD4 jsr @r13 ; mov.w r2,@r1
    goto L_0602ACBE;  // 0602ABD8 bra 0x0602ACBE ; nop
L_0602AC0C:
    c.macl = c.r[10] * c.r[1];  // 0602AC0C mul.l r1,r10
    c.r[7] = ld32(0x0602ACF4u);  // 0602AC0E mov.l 0x0602ACF4,r7
    c.r[2] = ld32(c.r[7]);  // 0602AC10 mov.l @r7,r2
    c.r[3] = c.macl;  // 0602AC12 sts macl,r3
    c.r[3] += c.r[2];  // 0602AC14 add r2,r3
    c.r[3] += 2;  // 0602AC16 add #2,r3
    c.r[1] = 0x63u;  // 0602AC18 mov #99,r1
    st8(c.r[3], c.r[1]);  // 0602AC1A mov.b r1,@r3
    c.r[1] = ld32(c.r[7]);  // 0602AC1C mov.l @r7,r1
    c.r[2] = c.macl;  // 0602AC1E sts macl,r2
    c.r[2] += c.r[1]; goto L_0602ACB8;  // 0602AC20 bra 0x0602ACB8 ; add r1,r2
L_0602AC24:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602ACEAu);  // 0602AC24 mov.w 0x0602ACEA,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 0602AC26 mov.l @(r0,r14),r0
    c.t = c.r[0] == 0x1u;  // 0602AC28 cmp/eq #1,r0
    if (!c.t) { goto L_0602ACBE; }  // 0602AC2A bf 0x0602ACBE
    c.r[5] = c.r[10];  // 0602AC2C mov r10,r5
    c.r[1] = ld32(0x0602ACF8u);  // 0602AC2E mov.l 0x0602ACF8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602AC34u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602AC34u) return; }  // 0602AC30 jsr @r1 ; mov r14,r4
    c.r[9] = c.r[10];  // 0602AC34 mov r10,r9
    c.r[9] += c.r[9];  // 0602AC36 add r9,r9
    c.r[3] = c.r[9];  // 0602AC38 mov r9,r3
    c.r[3] += c.r[10];  // 0602AC3A add r10,r3
    c.r[1] = ld32(c.r[11]);  // 0602AC3C mov.l @r11,r1
    c.r[3] <<= 2;  // 0602AC3E shll2 r3
    c.r[3] += c.r[1];  // 0602AC40 add r1,r3
    c.r[1] = c.r[3];  // 0602AC42 mov r3,r1
    c.r[1] += 2;  // 0602AC44 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602AC46 mov.b @r1,r1
    c.r[2] = 0x62u;  // 0602AC48 mov #98,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0602AC4A extu.b r1,r1
    c.t = c.r[1] > c.r[2];  // 0602AC4C cmp/hi r2,r1
    { const bool k = c.t; c.r[2] = c.r[3]; if (k) { goto L_0602ACBE; } }  // 0602AC4E bt/s 0x0602ACBE ; mov r3,r2
    c.r[2] += 4;  // 0602AC52 add #4,r2
    c.r[13] = (uint32_t)(int16_t)ld16(0x0602ACECu);  // 0602AC54 mov.w 0x0602ACEC,r13
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0602AC56 mov.w @r2,r1
    c.r[13] += c.r[14];  // 0602AC58 add r14,r13
    c.r[13] = ld32(c.r[13]);  // 0602AC5A mov.l @r13,r13
    c.r[1] -= c.r[13]; goto L_0602AC96;  // 0602AC5C bra 0x0602AC96 ; sub r13,r1
L_0602AC60:
    c.r[8] += c.r[10];  // 0602AC60 add r10,r8
    c.r[7] = ld32(c.r[11]);  // 0602AC62 mov.l @r11,r7
    c.r[8] <<= 2;  // 0602AC64 shll2 r8
    c.r[7] += c.r[8];  // 0602AC66 add r8,r7
    c.r[7] += 2;  // 0602AC68 add #2,r7
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0602AC6A mov.b @r7,r3
    c.r[1] = 0x62u;  // 0602AC6C mov #98,r1
    c.r[2] = c.r[3] & 0xFFu;  // 0602AC6E extu.b r3,r2
    c.t = c.r[2] > c.r[1];  // 0602AC70 cmp/hi r1,r2
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_0602ACA0; } }  // 0602AC72 bt/s 0x0602ACA0 ; mov r3,r1
    c.r[1] += 1;  // 0602AC76 add #1,r1
    st8(c.r[7], c.r[1]);  // 0602AC78 mov.b r1,@r7
    c.r[1] = ld32(c.r[11]);  // 0602AC7A mov.l @r11,r1
    c.r[4] = c.r[14];  // 0602AC7C mov r14,r4
    c.r[1] += c.r[8];  // 0602AC7E add r8,r1
    c.r[1] += 2;  // 0602AC80 add #2,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602AC82 mov.b @r1,r5
    c.r[0] = ld32(0x0602ACFCu);  // 0602AC84 mov.l 0x0602ACFC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602AC8Au; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602AC8Au) return; }  // 0602AC86 jsr @r0 ; extu.b r5,r5
    c.r[2] = ld32(c.r[11]);  // 0602AC8A mov.l @r11,r2
    c.r[2] += c.r[8];  // 0602AC8C add r8,r2
    c.r[2] += 4;  // 0602AC8E add #4,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0602AC90 mov.w @r2,r1
    c.r[3] = c.r[0];  // 0602AC92 mov r0,r3
    c.r[1] += c.r[3];  // 0602AC94 add r3,r1
L_0602AC96:
    st16(c.r[2], c.r[1]);  // 0602AC96 mov.w r1,@r2
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 0602AC98 exts.w r1,r1
    c.t = (int32_t)c.r[1] > 0;  // 0602AC9A cmp/pl r1
    { const bool k = !c.t; c.r[8] = c.r[9]; if (k) { SH2_POLL(c); goto L_0602AC60; } }  // 0602AC9C bf/s 0x0602AC60 ; mov r9,r8
L_0602ACA0:
    c.r[2] = c.r[10];  // 0602ACA0 mov r10,r2
    c.r[2] += c.r[2];  // 0602ACA2 add r2,r2
    c.r[2] += c.r[10];  // 0602ACA4 add r10,r2
    c.r[1] = ld32(c.r[11]);  // 0602ACA6 mov.l @r11,r1
    c.r[2] <<= 2;  // 0602ACA8 shll2 r2
    c.r[2] += c.r[1];  // 0602ACAA add r1,r2
    c.r[1] = c.r[2];  // 0602ACAC mov r2,r1
    c.r[1] += 2;  // 0602ACAE add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602ACB0 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0602ACB2 extu.b r1,r0
    c.t = c.r[0] == 0x63u;  // 0602ACB4 cmp/eq #99,r0
    if (!c.t) { goto L_0602ACBE; }  // 0602ACB6 bf 0x0602ACBE
L_0602ACB8:
    c.r[2] += 4;  // 0602ACB8 add #4,r2
    c.r[1] = 0x0u;  // 0602ACBA mov #0,r1
    st16(c.r[2], c.r[1]);  // 0602ACBC mov.w r1,@r2
L_0602ACBE:
    c.r[13] = (uint32_t)(int16_t)ld16(0x0602ACEAu);  // 0602ACBE mov.w 0x0602ACEA,r13
    c.r[13] += c.r[14];  // 0602ACC0 add r14,r13
    c.r[13] = ld32(c.r[13]);  // 0602ACC2 mov.l @r13,r13
    c.r[12] += 1;  // 0602ACC4 add #1,r12
    c.t = (int32_t)c.r[12] >= (int32_t)c.r[13];  // 0602ACC6 cmp/ge r13,r12
    { const bool k = c.t; c.r[1] = c.r[14]; if (k) { goto L_0602ACD0; } }  // 0602ACC8 bt/s 0x0602ACD0 ; mov r14,r1
    SH2_POLL(c); goto L_0602AB66;  // 0602ACCC bra 0x0602AB66 ; nop
L_0602ACD0:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602ACEEu);  // 0602ACD0 mov.w 0x0602ACEE,r0
    c.r[3] = (uint32_t)(int16_t)ld16(0x0602ACF0u);  // 0602ACD2 mov.w 0x0602ACF0,r3
    c.r[14] += c.r[3];  // 0602ACD4 add r3,r14
    c.r[15] = c.r[14];  // 0602ACD6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602ACD8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602ACDA mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0602ACDC mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0602ACDE mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0602ACE0 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0602ACE2 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0602ACE4 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602ACE6 rts ; mov.l @r15+,r8
}

void f_0602AD00(SH2Context& c) {
    ran[585] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602AD00 mov.l r14,@-r15
    c.r[1] = ld32(0x0602AD20u);  // 0602AD02 mov.l 0x0602AD20,r1
    c.r[2] = ld32(c.r[1]);  // 0602AD04 mov.l @r1,r2
    c.r[14] = c.r[15];  // 0602AD06 mov r15,r14
    c.r[1] = ld32(0x0602AD24u);  // 0602AD08 mov.l 0x0602AD24,r1
    c.r[1] = ld32(c.r[1]);  // 0602AD0A mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602AD1Au);  // 0602AD0C mov.w 0x0602AD1A,r0
    c.r[1] += 1;  // 0602AD0E add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602AD10 mov.b @r1,r1
    st8(c.r[0] + c.r[2], c.r[1]);  // 0602AD12 mov.b r1,@(r0,r2)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602AD1Cu);  // 0602AD14 mov.w 0x0602AD1C,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602AD16 rts ; mov.l @r15+,r14
}

void f_0602AD28(SH2Context& c) {
    ran[586] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602AD28 mov.l r14,@-r15
    c.r[1] = ld32(0x0602AD48u);  // 0602AD2A mov.l 0x0602AD48,r1
    c.r[2] = ld32(c.r[1]);  // 0602AD2C mov.l @r1,r2
    c.r[14] = c.r[15];  // 0602AD2E mov r15,r14
    c.r[1] = ld32(0x0602AD4Cu);  // 0602AD30 mov.l 0x0602AD4C,r1
    c.r[1] = ld32(c.r[1]);  // 0602AD32 mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602AD42u);  // 0602AD34 mov.w 0x0602AD42,r0
    c.r[1] += 1;  // 0602AD36 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602AD38 mov.b @r1,r1
    st8(c.r[0] + c.r[2], c.r[1]);  // 0602AD3A mov.b r1,@(r0,r2)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602AD44u);  // 0602AD3C mov.w 0x0602AD44,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602AD3E rts ; mov.l @r15+,r14
}

void f_0602AD50(SH2Context& c) {
    ran[587] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602AD50 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602AD52 sts.l pr,@-r15
    c.r[0] = ld32(0x0602AD74u);  // 0602AD54 mov.l 0x0602AD74,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602AD5Au; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602AD5Au) return; }  // 0602AD56 jsr @r0 ; mov r15,r14
    c.r[1] = ld32(0x0602AD78u);  // 0602AD5A mov.l 0x0602AD78,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602AD5C mov.b @r1,r1
    c.r[15] = c.r[14];  // 0602AD5E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602AD60 lds.l @r15+,pr
    c.r[1] = c.r[1] & 0xFFu;  // 0602AD62 extu.b r1,r1
    c.r[0] = c.r[1];  // 0602AD64 mov r1,r0
    c.r[0] += c.r[0];  // 0602AD66 add r0,r0
    c.r[0] += 1;  // 0602AD68 add #1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602AD72u);  // 0602AD6A mov.w 0x0602AD72,r1
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602AD6C mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] |= c.r[1]; c.pc = x; return; }  // 0602AD6E rts ; or r1,r0
}

void f_0602AD7C(SH2Context& c) {
    ran[588] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602AD7C mov.l r14,@-r15
    c.r[1] = ld32(0x0602AD9Cu);  // 0602AD7E mov.l 0x0602AD9C,r1
    c.r[1] = ld32(c.r[1]);  // 0602AD80 mov.l @r1,r1
    c.r[1] += 1;  // 0602AD82 add #1,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602AD84 mov.b @r1,r3
    c.r[1] = ld32(0x0602ADA0u);  // 0602AD86 mov.l 0x0602ADA0,r1
    c.r[2] = ld32(c.r[1]);  // 0602AD88 mov.l @r1,r2
    c.r[14] = c.r[15];  // 0602AD8A mov r15,r14
    c.r[2] += 5;  // 0602AD8C add #5,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602AD8E mov.b @r2,r1
    c.r[3] += c.r[1];  // 0602AD90 add r1,r3
    st8(c.r[2], c.r[3]);  // 0602AD92 mov.b r3,@r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602AD9Au);  // 0602AD94 mov.w 0x0602AD9A,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602AD96 rts ; mov.l @r15+,r14
}

void f_0602ADA4(SH2Context& c) {
    ran[589] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602ADA4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602ADA6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0602ADA8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602ADAA mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602ADAC sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0602ADAE mov r15,r14
    c.r[1] = ld32(0x0602ADFCu);  // 0602ADB0 mov.l 0x0602ADFC,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602ADF4u);  // 0602ADB2 mov.w 0x0602ADF4,r0
    c.r[10] = (uint32_t)(int16_t)ld16(0x0602ADF6u);  // 0602ADB4 mov.w 0x0602ADF6,r10
    c.r[4] = ld32(0x0602AE00u);  // 0602ADB6 mov.l 0x0602AE00,r4
    c.r[1] = ld32(c.r[1]);  // 0602ADB8 mov.l @r1,r1
    c.r[9] = ld32(0x0602AE04u);  // 0602ADBA mov.l 0x0602AE04,r9
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0602ADBC mov.w @(r0,r1),r8
    c.r[5] = 0x1Cu;  // 0602ADBE mov #28,r5
    c.r[8] = c.r[8] & 0xFFFFu;  // 0602ADC0 extu.w r8,r8
    c.r[8] >>= 2;  // 0602ADC2 shlr2 r8
    c.r[8] >>= 2;  // 0602ADC4 shlr2 r8
    c.t = c.r[8] & 1; c.r[8] >>= 1;  // 0602ADC6 shlr r8
    { const uint32_t x = c.r[9]; c.pr = 0x0602ADCCu; c.r[8] >>= 2; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602ADCCu) return; }  // 0602ADC8 jsr @r9 ; shlr2 r8
    c.r[5] = c.r[10];  // 0602ADCC mov r10,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0602ADD2u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602ADD2u) return; }  // 0602ADCE jsr @r9 ; mov r0,r4
    c.r[2] = (uint32_t)(int16_t)ld16(0x0602ADF8u);  // 0602ADD2 mov.w 0x0602ADF8,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0602ADD4 mov.b @r0,r1
    c.r[15] = c.r[14];  // 0602ADD6 mov r14,r15
    c.r[2] &= c.r[1];  // 0602ADD8 and r1,r2
    c.r[1] = c.r[8];  // 0602ADDA mov r8,r1
    c.r[1] >>= 8;  // 0602ADDC shlr8 r1
    c.r[2] |= c.r[1];  // 0602ADDE or r1,r2
    st8(c.r[0], c.r[2]);  // 0602ADE0 mov.b r2,@r0
    c.r[0] += 1;  // 0602ADE2 add #1,r0
    st8(c.r[0], c.r[8]);  // 0602ADE4 mov.b r8,@r0
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602ADE6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602ADE8 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0602ADEA mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0602ADEC mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602ADFAu);  // 0602ADEE mov.w 0x0602ADFA,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602ADF0 rts ; mov.l @r15+,r8
}

void f_0602AE08(SH2Context& c) {
    ran[590] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602AE08 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602AE0A sts.l pr,@-r15
    c.r[1] = ld32(0x0602AE20u);  // 0602AE0C mov.l 0x0602AE20,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602AE12u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602AE12u) return; }  // 0602AE0E jsr @r1 ; mov r15,r14
    c.r[15] = c.r[14];  // 0602AE12 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602AE14 lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602AE1Cu);  // 0602AE16 mov.w 0x0602AE1C,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602AE18 rts ; mov.l @r15+,r14
}

void f_0602AE24(SH2Context& c) {
    ran[591] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602AE24 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602AE26 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0602AE28 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602AE2A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602AE2C sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0602AE2E mov r15,r14
    c.r[1] = ld32(0x0602AE7Cu);  // 0602AE30 mov.l 0x0602AE7C,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602AE74u);  // 0602AE32 mov.w 0x0602AE74,r0
    c.r[10] = (uint32_t)(int16_t)ld16(0x0602AE76u);  // 0602AE34 mov.w 0x0602AE76,r10
    c.r[4] = ld32(0x0602AE80u);  // 0602AE36 mov.l 0x0602AE80,r4
    c.r[1] = ld32(c.r[1]);  // 0602AE38 mov.l @r1,r1
    c.r[9] = ld32(0x0602AE84u);  // 0602AE3A mov.l 0x0602AE84,r9
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0602AE3C mov.w @(r0,r1),r8
    c.r[5] = 0x1Cu;  // 0602AE3E mov #28,r5
    c.r[8] = c.r[8] & 0xFFFFu;  // 0602AE40 extu.w r8,r8
    c.r[8] >>= 2;  // 0602AE42 shlr2 r8
    c.r[8] >>= 2;  // 0602AE44 shlr2 r8
    c.t = c.r[8] & 1; c.r[8] >>= 1;  // 0602AE46 shlr r8
    { const uint32_t x = c.r[9]; c.pr = 0x0602AE4Cu; c.r[8] >>= 2; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602AE4Cu) return; }  // 0602AE48 jsr @r9 ; shlr2 r8
    c.r[5] = c.r[10];  // 0602AE4C mov r10,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0602AE52u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602AE52u) return; }  // 0602AE4E jsr @r9 ; mov r0,r4
    c.r[2] = (uint32_t)(int16_t)ld16(0x0602AE78u);  // 0602AE52 mov.w 0x0602AE78,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0602AE54 mov.b @r0,r1
    c.r[15] = c.r[14];  // 0602AE56 mov r14,r15
    c.r[2] &= c.r[1];  // 0602AE58 and r1,r2
    c.r[1] = c.r[8];  // 0602AE5A mov r8,r1
    c.r[1] >>= 8;  // 0602AE5C shlr8 r1
    c.r[2] |= c.r[1];  // 0602AE5E or r1,r2
    st8(c.r[0], c.r[2]);  // 0602AE60 mov.b r2,@r0
    c.r[0] += 1;  // 0602AE62 add #1,r0
    st8(c.r[0], c.r[8]);  // 0602AE64 mov.b r8,@r0
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602AE66 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602AE68 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0602AE6A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0602AE6C mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602AE7Au);  // 0602AE6E mov.w 0x0602AE7A,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602AE70 rts ; mov.l @r15+,r8
}

void f_0602AE88(SH2Context& c) {
    ran[592] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602AE88 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602AE8A sts.l pr,@-r15
    c.r[1] = ld32(0x0602AEA0u);  // 0602AE8C mov.l 0x0602AEA0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602AE92u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602AE92u) return; }  // 0602AE8E jsr @r1 ; mov r15,r14
    c.r[15] = c.r[14];  // 0602AE92 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602AE94 lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602AE9Cu);  // 0602AE96 mov.w 0x0602AE9C,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602AE98 rts ; mov.l @r15+,r14
}

void f_0602AEA4(SH2Context& c) {
    ran[593] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602AEA4 mov.l r14,@-r15
    c.r[0] = c.r[4] & 0xFFu;  // 0602AEA6 extu.b r4,r0
    c.r[1] = ld32(0x0602AEECu);  // 0602AEA8 mov.l 0x0602AEEC,r1
    c.r[1] = ld32(c.r[1]);  // 0602AEAA mov.l @r1,r1
    c.r[0] += c.r[0];  // 0602AEAC add r0,r0
    c.r[0] += c.r[1];  // 0602AEAE add r1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602AEE8u);  // 0602AEB0 mov.w 0x0602AEE8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0602AEB2 mov.b @(r0,r1),r1
    c.r[14] = c.r[15];  // 0602AEB4 mov r15,r14
    c.r[3] = c.r[1] & 0xFFu;  // 0602AEB6 extu.b r1,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602AEEAu);  // 0602AEB8 mov.w 0x0602AEEA,r1
    c.t = c.r[3] == c.r[1];  // 0602AEBA cmp/eq r1,r3
    { const bool k = c.t; c.r[6] = c.r[3]; if (k) { goto L_0602AEE0; } }  // 0602AEBC bt/s 0x0602AEE0 ; mov r3,r6
    c.r[1] = ld32(0x0602AEF0u);  // 0602AEC0 mov.l 0x0602AEF0,r1
    c.r[2] = ld32(c.r[1]);  // 0602AEC2 mov.l @r1,r2
    c.r[7] = ld32(0x0602AEF4u);  // 0602AEC4 mov.l 0x0602AEF4,r7
    c.r[1] = c.r[3];  // 0602AEC6 mov r3,r1
    c.r[1] <<= 2;  // 0602AEC8 shll2 r1
    c.r[1] <<= 2;  // 0602AECA shll2 r1
    c.r[3] = c.r[1];  // 0602AECC mov r1,r3
    c.r[3] += c.r[2];  // 0602AECE add r2,r3
    c.r[0] = c.r[1];  // 0602AED0 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0602AED2 mov.b @(r0,r2),r1
    c.r[3] += 1;  // 0602AED4 add #1,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0602AED6 extu.b r1,r1
    st32(c.r[7] + 12, c.r[1]);  // 0602AED8 mov.l r1,@(12,r7)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0602AEDA mov.b @r3,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602AEDC extu.b r1,r1
    st32(c.r[7] + 16, c.r[1]);  // 0602AEDE mov.l r1,@(16,r7)
L_0602AEE0:
    c.r[15] = c.r[14];  // 0602AEE0 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602AEE2 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[6]; c.pc = x; return; }  // 0602AEE4 rts ; mov r6,r0
}

void f_0602AEF8(SH2Context& c) {
    ran[594] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602AEF8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602AEFA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0602AEFC mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0602AEFE mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0602AF00 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602AF02 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0602AF04 mov r15,r14
    c.r[8] = c.r[6];  // 0602AF06 mov r6,r8
    c.r[5] = c.r[5] & 0xFFu;  // 0602AF08 extu.b r5,r5
    c.r[7] = c.r[7] & 0xFFu;  // 0602AF0A extu.b r7,r7
    c.r[1] = ld32(0x0602AF78u);  // 0602AF0C mov.l 0x0602AF78,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602AF6Cu);  // 0602AF0E mov.w 0x0602AF6C,r0
    c.r[12] = 0xFu;  // 0602AF10 mov #15,r12
    c.r[4] &= c.r[12];  // 0602AF12 and r12,r4
    c.r[5] <<= 2;  // 0602AF14 shll2 r5
    c.r[5] <<= 2;  // 0602AF16 shll2 r5
    c.r[9] = ld32(c.r[14] + 24);  // 0602AF18 mov.l @(24,r14),r9
    c.r[4] |= c.r[5];  // 0602AF1A or r5,r4
    c.r[3] = ld32(c.r[14] + 28);  // 0602AF1C mov.l @(28,r14),r3
    c.r[8] &= c.r[12];  // 0602AF1E and r12,r8
    c.r[10] = ld32(c.r[14] + 32);  // 0602AF20 mov.l @(32,r14),r10
    c.r[7] <<= 2;  // 0602AF22 shll2 r7
    c.r[7] <<= 2;  // 0602AF24 shll2 r7
    c.r[6] = ld32(c.r[14] + 36);  // 0602AF26 mov.l @(36,r14),r6
    c.r[8] |= c.r[7];  // 0602AF28 or r7,r8
    c.r[11] = ld32(c.r[14] + 40);  // 0602AF2A mov.l @(40,r14),r11
    c.r[2] = ld32(c.r[1]);  // 0602AF2C mov.l @r1,r2
    c.r[3] = c.r[3] & 0xFFu;  // 0602AF2E extu.b r3,r3
    c.r[6] = c.r[6] & 0xFFu;  // 0602AF30 extu.b r6,r6
    st8(c.r[0] + c.r[2], c.r[4]);  // 0602AF32 mov.b r4,@(r0,r2)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602AF6Eu);  // 0602AF34 mov.w 0x0602AF6E,r0
    c.r[9] &= c.r[12];  // 0602AF36 and r12,r9
    c.r[3] <<= 2;  // 0602AF38 shll2 r3
    c.r[3] <<= 2;  // 0602AF3A shll2 r3
    c.r[9] |= c.r[3];  // 0602AF3C or r3,r9
    c.r[10] &= c.r[12];  // 0602AF3E and r12,r10
    c.r[6] <<= 2;  // 0602AF40 shll2 r6
    c.r[6] <<= 2;  // 0602AF42 shll2 r6
    c.r[10] |= c.r[6];  // 0602AF44 or r6,r10
    c.r[2] = ld32(c.r[1]);  // 0602AF46 mov.l @r1,r2
    c.r[11] &= c.r[12];  // 0602AF48 and r12,r11
    st8(c.r[0] + c.r[2], c.r[8]);  // 0602AF4A mov.b r8,@(r0,r2)
    c.r[2] = ld32(c.r[1]);  // 0602AF4C mov.l @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602AF70u);  // 0602AF4E mov.w 0x0602AF70,r0
    st8(c.r[0] + c.r[2], c.r[9]);  // 0602AF50 mov.b r9,@(r0,r2)
    c.r[2] = ld32(c.r[1]);  // 0602AF52 mov.l @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602AF72u);  // 0602AF54 mov.w 0x0602AF72,r0
    st8(c.r[0] + c.r[2], c.r[10]);  // 0602AF56 mov.b r10,@(r0,r2)
    c.r[1] = ld32(c.r[1]);  // 0602AF58 mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602AF74u);  // 0602AF5A mov.w 0x0602AF74,r0
    st8(c.r[0] + c.r[1], c.r[11]);  // 0602AF5C mov.b r11,@(r0,r1)
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602AF5E mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0602AF60 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0602AF62 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0602AF64 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0602AF66 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602AF68 rts ; mov.l @r15+,r8
}

void f_0602AF7C(SH2Context& c) {
    ran[595] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602AF7C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602AF7E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0602AF80 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0602AF82 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0602AF84 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0602AF86 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602AF88 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602AF8A sts.l pr,@-r15
    c.r[0] = ld32(0x0602B120u);  // 0602AF8C mov.l 0x0602B120,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602AF92u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602AF92u) return; }  // 0602AF8E jsr @r0 ; mov r15,r14
    c.r[1] = c.r[0];  // 0602AF92 mov r0,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0602AF94 extu.b r1,r2
    c.r[1] = ld32(0x0602B124u);  // 0602AF96 mov.l 0x0602B124,r1
    c.r[0] = c.r[2];  // 0602AF98 mov r2,r0
    c.r[12] = ld32(0x0602B128u);  // 0602AF9A mov.l 0x0602B128,r12
    c.r[9] = ld32(0x0602B12Cu);  // 0602AF9C mov.l 0x0602B12C,r9
    c.r[5] = 0xCu;  // 0602AF9E mov #12,r5
    c.r[10] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0602AFA0 mov.b @(r0,r1),r10
    c.r[4] = c.r[12];  // 0602AFA2 mov r12,r4
    c.r[10] = c.r[10] & 0xFFu;  // 0602AFA4 extu.b r10,r10
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602B116u);  // 0602AFA6 mov.w 0x0602B116,r1
    { const uint32_t x = c.r[9]; c.pr = 0x0602AFACu; c.r[10] += c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602AFACu) return; }  // 0602AFA8 jsr @r9 ; add r1,r10
    c.r[1] = c.r[0];  // 0602AFAC mov r0,r1
    c.r[5] = c.r[10];  // 0602AFAE mov r10,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0602AFB4u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602AFB4u) return; }  // 0602AFB0 jsr @r9 ; mov r1,r4
    c.r[7] = c.r[0];  // 0602AFB4 mov r0,r7
    c.r[11] = ld32(0x0602B130u);  // 0602AFB6 mov.l 0x0602B130,r11
    c.r[8] = (uint32_t)(int16_t)ld16(0x0602B118u);  // 0602AFB8 mov.w 0x0602B118,r8
    c.r[13] = (uint32_t)(int16_t)ld16(0x0602B11Au);  // 0602AFBA mov.w 0x0602B11A,r13
    c.r[5] = 0xCu;  // 0602AFBC mov #12,r5
    c.r[3] = ld32(c.r[11]);  // 0602AFBE mov.l @r11,r3
    c.r[4] = c.r[12];  // 0602AFC0 mov r12,r4
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[7]); c.r[7] += 1;  // 0602AFC2 mov.b @r7+,r2
    c.r[1] = c.r[3];  // 0602AFC4 mov r3,r1
    c.r[1] += c.r[8];  // 0602AFC6 add r8,r1
    c.r[0] = c.r[3];  // 0602AFC8 mov r3,r0
    st8(c.r[0] + c.r[8], c.r[2]);  // 0602AFCA mov.b r2,@(r0,r8)
    c.r[3] = c.r[7];  // 0602AFCC mov r7,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]); c.r[3] += 1;  // 0602AFCE mov.b @r3+,r2
    c.r[1] += 1;  // 0602AFD0 add #1,r1
    st8(c.r[1], c.r[2]);  // 0602AFD2 mov.b r2,@r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]); c.r[3] += 1;  // 0602AFD4 mov.b @r3+,r2
    c.r[1] += 1;  // 0602AFD6 add #1,r1
    st8(c.r[1], c.r[2]);  // 0602AFD8 mov.b r2,@r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]); c.r[3] += 1;  // 0602AFDA mov.b @r3+,r2
    c.r[1] += 1;  // 0602AFDC add #1,r1
    st8(c.r[1], c.r[2]);  // 0602AFDE mov.b r2,@r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]); c.r[3] += 1;  // 0602AFE0 mov.b @r3+,r2
    c.r[1] += 1;  // 0602AFE2 add #1,r1
    st8(c.r[1], c.r[2]);  // 0602AFE4 mov.b r2,@r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]); c.r[3] += 1;  // 0602AFE6 mov.b @r3+,r2
    c.r[1] += 1;  // 0602AFE8 add #1,r1
    st8(c.r[1], c.r[2]);  // 0602AFEA mov.b r2,@r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]); c.r[3] += 1;  // 0602AFEC mov.b @r3+,r2
    c.r[1] += 1;  // 0602AFEE add #1,r1
    st8(c.r[1], c.r[2]);  // 0602AFF0 mov.b r2,@r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]); c.r[3] += 1;  // 0602AFF2 mov.b @r3+,r2
    c.r[1] += 1;  // 0602AFF4 add #1,r1
    st8(c.r[1], c.r[2]);  // 0602AFF6 mov.b r2,@r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]); c.r[3] += 1;  // 0602AFF8 mov.b @r3+,r2
    c.r[1] += 1;  // 0602AFFA add #1,r1
    st8(c.r[1], c.r[2]);  // 0602AFFC mov.b r2,@r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]); c.r[3] += 1;  // 0602AFFE mov.b @r3+,r2
    c.r[1] += 1;  // 0602B000 add #1,r1
    st8(c.r[1], c.r[2]);  // 0602B002 mov.b r2,@r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]); c.r[3] += 1;  // 0602B004 mov.b @r3+,r2
    c.r[1] += 1;  // 0602B006 add #1,r1
    st8(c.r[1], c.r[2]);  // 0602B008 mov.b r2,@r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]); c.r[3] += 1;  // 0602B00A mov.b @r3+,r2
    c.r[1] += 1;  // 0602B00C add #1,r1
    st8(c.r[1], c.r[2]);  // 0602B00E mov.b r2,@r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]); c.r[3] += 1;  // 0602B010 mov.b @r3+,r2
    c.r[1] += 1;  // 0602B012 add #1,r1
    st8(c.r[1], c.r[2]);  // 0602B014 mov.b r2,@r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0602B016 mov.b @r3,r2
    c.r[1] += 1;  // 0602B018 add #1,r1
    { const uint32_t x = c.r[9]; c.pr = 0x0602B01Eu; st8(c.r[1], c.r[2]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602B01Eu) return; }  // 0602B01A jsr @r9 ; mov.b r2,@r1
    c.r[1] = c.r[0];  // 0602B01E mov r0,r1
    c.r[5] = c.r[13];  // 0602B020 mov r13,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0602B026u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602B026u) return; }  // 0602B022 jsr @r9 ; mov r1,r4
    c.r[7] = c.r[0];  // 0602B026 mov r0,r7
    c.r[5] = 0xDu;  // 0602B028 mov #13,r5
    c.r[2] = ld32(c.r[11]);  // 0602B02A mov.l @r11,r2
    c.r[4] = c.r[12];  // 0602B02C mov r12,r4
    c.r[1] = c.r[2];  // 0602B02E mov r2,r1
    c.r[1] += c.r[8];  // 0602B030 add r8,r1
    c.r[0] = c.r[2];  // 0602B032 mov r2,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0602B034 mov.b @(r0,r8),r2
    c.r[1] += 1;  // 0602B036 add #1,r1
    st8(c.r[7], c.r[2]);  // 0602B038 mov.b r2,@r7
    c.r[2] = c.r[7];  // 0602B03A mov r7,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0602B03C mov.b @r1+,r3
    c.r[2] += 1;  // 0602B03E add #1,r2
    st8(c.r[2], c.r[3]);  // 0602B040 mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0602B042 mov.b @r1+,r3
    c.r[2] += 1;  // 0602B044 add #1,r2
    st8(c.r[2], c.r[3]);  // 0602B046 mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0602B048 mov.b @r1+,r3
    c.r[2] += 1;  // 0602B04A add #1,r2
    st8(c.r[2], c.r[3]);  // 0602B04C mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0602B04E mov.b @r1+,r3
    c.r[2] += 1;  // 0602B050 add #1,r2
    st8(c.r[2], c.r[3]);  // 0602B052 mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0602B054 mov.b @r1+,r3
    c.r[2] += 1;  // 0602B056 add #1,r2
    st8(c.r[2], c.r[3]);  // 0602B058 mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0602B05A mov.b @r1+,r3
    c.r[2] += 1;  // 0602B05C add #1,r2
    st8(c.r[2], c.r[3]);  // 0602B05E mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0602B060 mov.b @r1+,r3
    c.r[2] += 1;  // 0602B062 add #1,r2
    st8(c.r[2], c.r[3]);  // 0602B064 mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0602B066 mov.b @r1+,r3
    c.r[2] += 1;  // 0602B068 add #1,r2
    st8(c.r[2], c.r[3]);  // 0602B06A mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0602B06C mov.b @r1+,r3
    c.r[2] += 1;  // 0602B06E add #1,r2
    st8(c.r[2], c.r[3]);  // 0602B070 mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0602B072 mov.b @r1+,r3
    c.r[2] += 1;  // 0602B074 add #1,r2
    st8(c.r[2], c.r[3]);  // 0602B076 mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0602B078 mov.b @r1+,r3
    c.r[2] += 1;  // 0602B07A add #1,r2
    st8(c.r[2], c.r[3]);  // 0602B07C mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0602B07E mov.b @r1+,r3
    c.r[2] += 1;  // 0602B080 add #1,r2
    st8(c.r[2], c.r[3]);  // 0602B082 mov.b r3,@r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602B084 mov.b @r1,r1
    c.r[2] += 1;  // 0602B086 add #1,r2
    { const uint32_t x = c.r[9]; c.pr = 0x0602B08Cu; st8(c.r[2], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602B08Cu) return; }  // 0602B088 jsr @r9 ; mov.b r1,@r2
    c.r[1] = c.r[0];  // 0602B08C mov r0,r1
    c.r[5] = c.r[10];  // 0602B08E mov r10,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0602B094u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602B094u) return; }  // 0602B090 jsr @r9 ; mov r1,r4
    c.r[7] = c.r[0];  // 0602B094 mov r0,r7
    c.r[8] = (uint32_t)(int16_t)ld16(0x0602B11Cu);  // 0602B096 mov.w 0x0602B11C,r8
    c.r[5] = 0xDu;  // 0602B098 mov #13,r5
    c.r[3] = ld32(c.r[11]);  // 0602B09A mov.l @r11,r3
    c.r[4] = c.r[12];  // 0602B09C mov r12,r4
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[7]); c.r[7] += 1;  // 0602B09E mov.b @r7+,r2
    c.r[1] = c.r[3];  // 0602B0A0 mov r3,r1
    c.r[1] += c.r[8];  // 0602B0A2 add r8,r1
    c.r[0] = c.r[3];  // 0602B0A4 mov r3,r0
    st8(c.r[0] + c.r[8], c.r[2]);  // 0602B0A6 mov.b r2,@(r0,r8)
    c.r[3] = c.r[7];  // 0602B0A8 mov r7,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]); c.r[3] += 1;  // 0602B0AA mov.b @r3+,r2
    c.r[1] += 1;  // 0602B0AC add #1,r1
    st8(c.r[1], c.r[2]);  // 0602B0AE mov.b r2,@r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]); c.r[3] += 1;  // 0602B0B0 mov.b @r3+,r2
    c.r[1] += 1;  // 0602B0B2 add #1,r1
    st8(c.r[1], c.r[2]);  // 0602B0B4 mov.b r2,@r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]); c.r[3] += 1;  // 0602B0B6 mov.b @r3+,r2
    c.r[1] += 1;  // 0602B0B8 add #1,r1
    st8(c.r[1], c.r[2]);  // 0602B0BA mov.b r2,@r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]); c.r[3] += 1;  // 0602B0BC mov.b @r3+,r2
    c.r[1] += 1;  // 0602B0BE add #1,r1
    st8(c.r[1], c.r[2]);  // 0602B0C0 mov.b r2,@r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0602B0C2 mov.b @r3,r2
    c.r[1] += 1;  // 0602B0C4 add #1,r1
    { const uint32_t x = c.r[9]; c.pr = 0x0602B0CAu; st8(c.r[1], c.r[2]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602B0CAu) return; }  // 0602B0C6 jsr @r9 ; mov.b r2,@r1
    c.r[1] = c.r[0];  // 0602B0CA mov r0,r1
    c.r[5] = c.r[13];  // 0602B0CC mov r13,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0602B0D2u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602B0D2u) return; }  // 0602B0CE jsr @r9 ; mov r1,r4
    c.r[7] = c.r[0];  // 0602B0D2 mov r0,r7
    c.r[2] = ld32(c.r[11]);  // 0602B0D4 mov.l @r11,r2
    c.r[15] = c.r[14];  // 0602B0D6 mov r14,r15
    c.r[1] = c.r[2];  // 0602B0D8 mov r2,r1
    c.r[1] += c.r[8];  // 0602B0DA add r8,r1
    c.r[0] = c.r[2];  // 0602B0DC mov r2,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0602B0DE mov.b @(r0,r8),r2
    c.r[1] += 1;  // 0602B0E0 add #1,r1
    st8(c.r[7], c.r[2]);  // 0602B0E2 mov.b r2,@r7
    c.r[2] = c.r[7];  // 0602B0E4 mov r7,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0602B0E6 mov.b @r1+,r3
    c.r[2] += 1;  // 0602B0E8 add #1,r2
    st8(c.r[2], c.r[3]);  // 0602B0EA mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0602B0EC mov.b @r1+,r3
    c.r[2] += 1;  // 0602B0EE add #1,r2
    st8(c.r[2], c.r[3]);  // 0602B0F0 mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0602B0F2 mov.b @r1+,r3
    c.r[2] += 1;  // 0602B0F4 add #1,r2
    st8(c.r[2], c.r[3]);  // 0602B0F6 mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0602B0F8 mov.b @r1+,r3
    c.r[2] += 1;  // 0602B0FA add #1,r2
    st8(c.r[2], c.r[3]);  // 0602B0FC mov.b r3,@r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602B0FE mov.b @r1,r1
    c.r[2] += 1;  // 0602B100 add #1,r2
    st8(c.r[2], c.r[1]);  // 0602B102 mov.b r1,@r2
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602B104 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602B106 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0602B108 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0602B10A mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0602B10C mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0602B10E mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0602B110 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602B112 rts ; mov.l @r15+,r8
}

void f_0602B134(SH2Context& c) {
    ran[596] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602B134 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0602B136 mov r15,r14
    c.r[3] = ld32(0x0602B164u);  // 0602B138 mov.l 0x0602B164,r3
    c.r[1] = ld32(0x0602B168u);  // 0602B13A mov.l 0x0602B168,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602B160u);  // 0602B13C mov.w 0x0602B160,r0
    c.r[2] = ld32(c.r[1]);  // 0602B13E mov.l @r1,r2
    c.r[6] = 0x4u;  // 0602B140 mov #4,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0602B142 mov.b @(r0,r2),r1
    c.r[7] = c.r[1];  // 0602B144 mov r1,r7
    c.r[7] >>= 2;  // 0602B146 shlr2 r7
    c.r[7] >>= 2;  // 0602B148 shlr2 r7
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602B162u);  // 0602B14A mov.w 0x0602B162,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0602B14C mov.b @(r0,r2),r1
    c.r[7] &= c.r[6];  // 0602B14E and r6,r7
    c.r[0] = c.r[1];  // 0602B150 mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0602B152 shlr r0
    c.r[0] &= 0x3u;  // 0602B154 and #3,r0
    c.r[7] += c.r[0];  // 0602B156 add r0,r7
    st8(c.r[3], c.r[7]);  // 0602B158 mov.b r7,@r3
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602B15A mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[7]; c.pc = x; return; }  // 0602B15C rts ; mov r7,r0
}

void f_0602B16C(SH2Context& c) {
    ran[597] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602B16C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602B16E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0602B170 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0602B172 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0602B174 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0602B176 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602B178 mov.l r14,@-r15
    c.r[15] -= 4;  // 0602B17A add #-4,r15
    c.r[14] = c.r[15];  // 0602B17C mov r15,r14
    c.r[13] = 0x4u;  // 0602B17E mov #4,r13
    c.r[12] = ld32(0x0602B268u);  // 0602B180 mov.l 0x0602B268,r12
    c.r[9] = ld32(0x0602B26Cu);  // 0602B182 mov.l 0x0602B26C,r9
    c.r[10] = 0xFFFFFFFFu;  // 0602B184 mov #-1,r10
    c.r[11] = ld32(0x0602B270u);  // 0602B186 mov.l 0x0602B270,r11
    c.r[8] = 0x0u;  // 0602B188 mov #0,r8
    c.r[4] = c.r[12];  // 0602B18A mov r12,r4
    c.r[5] = 0x0u;  // 0602B18C mov #0,r5
L_0602B18E:
    c.r[0] = c.r[5];  // 0602B18E mov r5,r0
    c.r[2] = c.r[4];  // 0602B190 mov r4,r2
    c.r[1] = ld32(c.r[9]);  // 0602B192 mov.l @r9,r1
    c.r[2] += 1;  // 0602B194 add #1,r2
    c.r[1] += c.r[5];  // 0602B196 add r5,r1
    c.r[1] += 20;  // 0602B198 add #20,r1
    st8(c.r[1], c.r[10]);  // 0602B19A mov.b r10,@r1
    st8(c.r[0] + c.r[12], c.r[10]);  // 0602B19C mov.b r10,@(r0,r12)
    c.r[1] = ld32(c.r[9]);  // 0602B19E mov.l @r9,r1
    c.r[3] = c.r[4];  // 0602B1A0 mov r4,r3
    c.r[1] += c.r[5];  // 0602B1A2 add r5,r1
    c.r[1] += 21;  // 0602B1A4 add #21,r1
    st8(c.r[1], c.r[10]);  // 0602B1A6 mov.b r10,@r1
    st8(c.r[2], c.r[10]);  // 0602B1A8 mov.b r10,@r2
    c.r[1] = ld32(c.r[9]);  // 0602B1AA mov.l @r9,r1
    c.r[3] += 2;  // 0602B1AC add #2,r3
    c.r[1] += c.r[5];  // 0602B1AE add r5,r1
    c.r[1] += 22;  // 0602B1B0 add #22,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602B1B2 mov.b @r1,r2
    c.r[0] = 0x3Fu;  // 0602B1B4 mov #63,r0
    c.r[2] &= c.r[0];  // 0602B1B6 and r0,r2
    st8(c.r[1], c.r[2]);  // 0602B1B8 mov.b r2,@r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0602B1BA mov.b @r3,r1
    c.r[1] &= c.r[0];  // 0602B1BC and r0,r1
    st8(c.r[3], c.r[1]);  // 0602B1BE mov.b r1,@r3
    c.r[1] = ld32(c.r[9]);  // 0602B1C0 mov.l @r9,r1
    c.r[1] += c.r[5];  // 0602B1C2 add r5,r1
    c.r[1] += 22;  // 0602B1C4 add #22,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602B1C6 mov.b @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602B260u);  // 0602B1C8 mov.w 0x0602B260,r0
    c.r[2] &= c.r[0];  // 0602B1CA and r0,r2
    st8(c.r[1], c.r[2]);  // 0602B1CC mov.b r2,@r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0602B1CE mov.b @r3,r1
    c.r[1] &= c.r[0];  // 0602B1D0 and r0,r1
    st8(c.r[3], c.r[1]);  // 0602B1D2 mov.b r1,@r3
    c.r[0] = c.r[8];  // 0602B1D4 mov r8,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[11]);  // 0602B1D6 mov.w @(r0,r11),r1
    c.r[2] = ld32(c.r[9]);  // 0602B1D8 mov.l @r9,r2
    c.r[6] = c.r[1] & 0xFFFFu;  // 0602B1DA extu.w r1,r6
    c.r[0] = c.r[6];  // 0602B1DC mov r6,r0
    c.r[0] >>= 2;  // 0602B1DE shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0602B1E0 shlr r0
    c.r[0] >>= 2;  // 0602B1E2 shlr2 r0
    c.r[0] &= 0x1Fu;  // 0602B1E4 and #31,r0
    st32(c.r[14], c.r[0]);  // 0602B1E6 mov.l r0,@r14
    c.r[2] += c.r[5];  // 0602B1E8 add r5,r2
    c.r[1] = c.r[2];  // 0602B1EA mov r2,r1
    c.r[1] += 22;  // 0602B1EC add #22,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602B262u);  // 0602B1EE mov.w 0x0602B262,r0
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602B1F0 mov.b @r1,r7
    c.r[2] += 23;  // 0602B1F2 add #23,r2
    c.r[7] &= c.r[0];  // 0602B1F4 and r0,r7
    c.r[0] = ld32(c.r[14]);  // 0602B1F6 mov.l @r14,r0
    c.r[5] += 4;  // 0602B1F8 add #4,r5
    c.r[7] |= c.r[0];  // 0602B1FA or r0,r7
    st8(c.r[1], c.r[7]);  // 0602B1FC mov.b r7,@r1
    c.r[0] = 0x1Fu;  // 0602B1FE mov #31,r0
    c.r[6] &= c.r[0];  // 0602B200 and r0,r6
    c.r[6] <<= 2;  // 0602B202 shll2 r6
    c.r[6] += c.r[6];  // 0602B204 add r6,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602B206 mov.b @r2,r1
    c.r[0] = 0x7u;  // 0602B208 mov #7,r0
    c.r[1] &= c.r[0];  // 0602B20A and r0,r1
    c.r[1] |= c.r[6];  // 0602B20C or r6,r1
    st8(c.r[2], c.r[1]);  // 0602B20E mov.b r1,@r2
    c.r[0] = c.r[8];  // 0602B210 mov r8,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602B264u);  // 0602B212 mov.w 0x0602B264,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[11]);  // 0602B214 mov.w @(r0,r11),r2
    c.r[8] += 2;  // 0602B216 add #2,r8
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0602B218 mov.b @r3,r7
    c.r[2] &= c.r[1];  // 0602B21A and r1,r2
    c.r[1] = c.r[2];  // 0602B21C mov r2,r1
    c.r[1] >>= 2;  // 0602B21E shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0602B220 shlr r1
    c.r[1] >>= 2;  // 0602B222 shlr2 r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602B262u);  // 0602B224 mov.w 0x0602B262,r0
    c.r[7] &= c.r[0];  // 0602B226 and r0,r7
    c.r[7] |= c.r[1];  // 0602B228 or r1,r7
    st8(c.r[3], c.r[7]);  // 0602B22A mov.b r7,@r3
    c.r[0] = 0x1Fu;  // 0602B22C mov #31,r0
    c.r[2] &= c.r[0];  // 0602B22E and r0,r2
    c.r[1] = c.r[4];  // 0602B230 mov r4,r1
    c.r[1] += 3;  // 0602B232 add #3,r1
    c.r[2] <<= 2;  // 0602B234 shll2 r2
    c.r[2] += c.r[2];  // 0602B236 add r2,r2
    c.r[0] = 0x7u;  // 0602B238 mov #7,r0
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602B23A mov.b @r1,r3
    c.r[3] &= c.r[0];  // 0602B23C and r0,r3
    c.r[3] |= c.r[2];  // 0602B23E or r2,r3
    st8(c.r[1], c.r[3]);  // 0602B240 mov.b r3,@r1
    c.r[1] = c.r[13];  // 0602B242 mov r13,r1
    c.r[1] += c.r[1];  // 0602B244 add r1,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 0602B246 cmp/gt r1,r8
    { const bool k = !c.t; c.r[4] += 4; if (k) { SH2_POLL(c); goto L_0602B18E; } }  // 0602B248 bf/s 0x0602B18E ; add #4,r4
    c.r[14] += 4;  // 0602B24C add #4,r14
    c.r[15] = c.r[14];  // 0602B24E mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602B250 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0602B252 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0602B254 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0602B256 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0602B258 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0602B25A mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602B25C rts ; mov.l @r15+,r8
}

void f_0602B274(SH2Context& c) {
    ran[598] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602B274 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602B276 sts.l pr,@-r15
    c.t = (c.r[4] & c.r[4]) == 0;  // 0602B278 tst r4,r4
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0602B2E4; } }  // 0602B27A bt/s 0x0602B2E4 ; mov r15,r14
    c.r[1] = ld32(0x0602B310u);  // 0602B27E mov.l 0x0602B310,r1
    c.r[1] = ld32(c.r[1]);  // 0602B280 mov.l @r1,r1
    c.r[1] += 8;  // 0602B282 add #8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602B284 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0602B286 mov r1,r0
    c.r[0] >>= 2;  // 0602B288 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0602B28A shlr r0
    c.r[0] &= 0x1u;  // 0602B28C and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0602B28E tst r0,r0
    if (c.t) { goto L_0602B2B4; }  // 0602B290 bt 0x0602B2B4
    c.r[0] = ld32(0x0602B314u);  // 0602B292 mov.l 0x0602B314,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602B298u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602B298u) return; }  // 0602B294 jsr @r0 ; nop
    c.r[0] = c.r[0] & 0xFFu;  // 0602B298 extu.b r0,r0
    c.t = c.r[0] == 0x1u;  // 0602B29A cmp/eq #1,r0
    if (c.t) { goto L_0602B308; }  // 0602B29C bt 0x0602B308
    c.r[1] = ld32(0x0602B318u);  // 0602B29E mov.l 0x0602B318,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602B2A4u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602B2A4u) return; }  // 0602B2A0 jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x0602B31Cu);  // 0602B2A4 mov.l 0x0602B31C,r1
    c.r[2] = ld32(c.r[1]);  // 0602B2A6 mov.l @r1,r2
    c.r[2] += 3;  // 0602B2A8 add #3,r2
    c.r[1] = 0x0u;  // 0602B2AA mov #0,r1
    st8(c.r[2], c.r[1]);  // 0602B2AC mov.b r1,@r2
    c.r[1] = ld32(0x0602B320u);  // 0602B2AE mov.l 0x0602B320,r1
    c.r[4] = 0x1u; goto L_0602B2D4;  // 0602B2B0 bra 0x0602B2D4 ; mov #1,r4
L_0602B2B4:
    c.r[0] = ld32(0x0602B314u);  // 0602B2B4 mov.l 0x0602B314,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602B2BAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602B2BAu) return; }  // 0602B2B6 jsr @r0 ; nop
    c.r[1] = c.r[0] & 0xFFu;  // 0602B2BA extu.b r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0602B2BC tst r1,r1
    if (c.t) { goto L_0602B308; }  // 0602B2BE bt 0x0602B308
    c.r[1] = ld32(0x0602B318u);  // 0602B2C0 mov.l 0x0602B318,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602B2C6u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602B2C6u) return; }  // 0602B2C2 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x0602B31Cu);  // 0602B2C6 mov.l 0x0602B31C,r1
    c.r[2] = ld32(c.r[1]);  // 0602B2C8 mov.l @r1,r2
    c.r[2] += 3;  // 0602B2CA add #3,r2
    c.r[1] = 0xFFFFFF80u;  // 0602B2CC mov #-128,r1
    st8(c.r[2], c.r[1]);  // 0602B2CE mov.b r1,@r2
    c.r[1] = ld32(0x0602B320u);  // 0602B2D0 mov.l 0x0602B320,r1
    c.r[4] = 0x0u;  // 0602B2D2 mov #0,r4
L_0602B2D4:
    { const uint32_t x = c.r[1]; c.pr = 0x0602B2D8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602B2D8u) return; }  // 0602B2D4 jsr @r1 ; nop
    c.r[0] = ld32(0x0602B324u);  // 0602B2D8 mov.l 0x0602B324,r0
    c.r[5] = 0x0u;  // 0602B2DA mov #0,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0602B2E0u; c.r[4] = 0xFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602B2E0u) return; }  // 0602B2DC jsr @r0 ; mov #15,r4
    c.r[15] = c.r[14]; goto L_0602B30A;  // 0602B2E0 bra 0x0602B30A ; mov r14,r15
L_0602B2E4:
    c.r[0] = ld32(0x0602B314u);  // 0602B2E4 mov.l 0x0602B314,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602B2EAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602B2EAu) return; }  // 0602B2E6 jsr @r0 ; nop
    c.r[0] = c.r[0] & 0xFFu;  // 0602B2EA extu.b r0,r0
    c.t = c.r[0] == 0x1u;  // 0602B2EC cmp/eq #1,r0
    if (!c.t) { goto L_0602B2FC; }  // 0602B2EE bf 0x0602B2FC
    c.r[1] = ld32(0x0602B310u);  // 0602B2F0 mov.l 0x0602B310,r1
    c.r[1] = ld32(c.r[1]);  // 0602B2F2 mov.l @r1,r1
    c.r[1] += 8;  // 0602B2F4 add #8,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602B2F6 mov.b @r1,r0
    c.r[0] |= 0x8u; goto L_0602B306;  // 0602B2F8 bra 0x0602B306 ; or #8,r0
L_0602B2FC:
    c.r[1] = ld32(0x0602B310u);  // 0602B2FC mov.l 0x0602B310,r1
    c.r[1] = ld32(c.r[1]);  // 0602B2FE mov.l @r1,r1
    c.r[1] += 8;  // 0602B300 add #8,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602B302 mov.b @r1,r0
    c.r[0] &= 0xF7u;  // 0602B304 and #247,r0
L_0602B306:
    st8(c.r[1], c.r[0]);  // 0602B306 mov.b r0,@r1
L_0602B308:
    c.r[15] = c.r[14];  // 0602B308 mov r14,r15
L_0602B30A:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602B30A lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602B30C rts ; mov.l @r15+,r14
}

}  // namespace p_srwfin_installed
