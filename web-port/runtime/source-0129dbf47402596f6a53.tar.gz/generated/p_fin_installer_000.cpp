#include "p_fin_installer_funcs.h"

namespace p_fin_installer {

void f_0028BFA4(SH2Context& c) {
    ran[0] = 1;
L_0028BFA4:
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 0028BFA4 mov.l r0,@-r15
L_0028BFA6:
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0028BFA6 mov.l r1,@-r15
L_0028BFA8:
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 0028BFA8 mov.l r2,@-r15
L_0028BFAA:
    c.r[15] -= 4; st32(c.r[15], c.r[3]);  // 0028BFAA mov.l r3,@-r15
L_0028BFAC:
    c.r[15] -= 4; st32(c.r[15], sh2_get_sr(c));  // 0028BFAC stc.l sr,@-r15
L_0028BFAE:
    c.r[1] = ld32(0x0028BFF0u);  // 0028BFAE mov.l 0x0028BFF0,r1
L_0028BFB0:
    c.r[0] = ld32(c.r[1]); c.r[1] += 4;  // 0028BFB0 mov.l @r1+,r0
L_0028BFB2:
    c.r[2] = ld32(0x0028BFF4u);  // 0028BFB2 mov.l 0x0028BFF4,r2
L_0028BFB4:
    c.t = c.r[0] == c.r[2];  // 0028BFB4 cmp/eq r2,r0
L_0028BFB6:
    if (!c.t) { goto L_0028BFDE; }  // 0028BFB6 bf 0x0028BFDE
L_0028BFB8:
    c.r[0] = ld32(c.r[1]); c.r[1] += 4;  // 0028BFB8 mov.l @r1+,r0
L_0028BFBA:
    c.r[2] = ld32(0x0028BFF8u);  // 0028BFBA mov.l 0x0028BFF8,r2
L_0028BFBC:
    c.t = c.r[0] == c.r[2];  // 0028BFBC cmp/eq r2,r0
L_0028BFBE:
    if (!c.t) { goto L_0028BFDE; }  // 0028BFBE bf 0x0028BFDE
L_0028BFC0:
    c.r[2] = ld32(0x0028BFFCu);  // 0028BFC0 mov.l 0x0028BFFC,r2
L_0028BFC2:
    c.r[3] = ld32(0x0028C000u);  // 0028BFC2 mov.l 0x0028C000,r3
L_0028BFC4:
    c.r[0] = ld32(c.r[1]); c.r[1] += 4;  // 0028BFC4 mov.l @r1+,r0
L_0028BFC6:
    st32(c.r[2], c.r[0]);  // 0028BFC6 mov.l r0,@r2
L_0028BFC8:
    c.r[2] += 4;  // 0028BFC8 add #4,r2
L_0028BFCA:
    c.r[3] -= 1; c.t = c.r[3] == 0;  // 0028BFCA dt r3
L_0028BFCC:
    if (!c.t) { SH2_POLL(c); goto L_0028BFC4; }  // 0028BFCC bf 0x0028BFC4
L_0028BFCE:
    c.r[1] = ld32(0x0028C004u);  // 0028BFCE mov.l 0x0028C004,r1
L_0028BFD0:
    c.r[2] = ld32(c.r[1]); c.r[1] += 4;  // 0028BFD0 mov.l @r1+,r2
L_0028BFD2:
    c.t = (c.r[2] & c.r[2]) == 0;  // 0028BFD2 tst r2,r2
L_0028BFD4:
    if (c.t) { goto L_0028BFDE; }  // 0028BFD4 bt 0x0028BFDE
L_0028BFD6:
    c.r[0] = ld32(c.r[1]); c.r[1] += 4;  // 0028BFD6 mov.l @r1+,r0
L_0028BFD8:
    st32(c.r[2], c.r[0]);  // 0028BFD8 mov.l r0,@r2
L_0028BFDA:
    SH2_POLL(c); goto L_0028BFD0;  // 0028BFDA bra 0x0028BFD0 ; nop
L_0028BFDE:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; sh2_set_sr(c, v & 0x3F3u); SH2_POLL(c); }  // 0028BFDE ldc.l @r15+,sr
L_0028BFE0:
    c.r[3] = ld32(c.r[15]); c.r[15] += 4;  // 0028BFE0 mov.l @r15+,r3
L_0028BFE2:
    c.r[2] = ld32(c.r[15]); c.r[15] += 4;  // 0028BFE2 mov.l @r15+,r2
L_0028BFE4:
    c.r[1] = ld32(c.r[15]); c.r[15] += 4;  // 0028BFE4 mov.l @r15+,r1
L_0028BFE6:
    c.r[0] = ld32(c.r[15]); c.r[15] += 4;  // 0028BFE6 mov.l @r15+,r0
L_0028BFE8:
    c.r[1] = ld32(0x0028C008u); sh2_hook(c, 0x0028BFE8u);  // 0028BFE8 mov.l 0x0028C008,r1
L_0028BFEA:
    { const uint32_t x = c.r[1]; SH2_POLL(c); switch (x) { case 0x0028BFA4u: goto L_0028BFA4; case 0x0028BFA6u: goto L_0028BFA6; case 0x0028BFA8u: goto L_0028BFA8; case 0x0028BFAAu: goto L_0028BFAA; case 0x0028BFACu: goto L_0028BFAC; case 0x0028BFAEu: goto L_0028BFAE; case 0x0028BFB0u: goto L_0028BFB0; case 0x0028BFB2u: goto L_0028BFB2; case 0x0028BFB4u: goto L_0028BFB4; case 0x0028BFB6u: goto L_0028BFB6; case 0x0028BFB8u: goto L_0028BFB8; case 0x0028BFBAu: goto L_0028BFBA; case 0x0028BFBCu: goto L_0028BFBC; case 0x0028BFBEu: goto L_0028BFBE; case 0x0028BFC0u: goto L_0028BFC0; case 0x0028BFC2u: goto L_0028BFC2; case 0x0028BFC4u: goto L_0028BFC4; case 0x0028BFC6u: goto L_0028BFC6; case 0x0028BFC8u: goto L_0028BFC8; case 0x0028BFCAu: goto L_0028BFCA; case 0x0028BFCCu: goto L_0028BFCC; case 0x0028BFCEu: goto L_0028BFCE; case 0x0028BFD0u: goto L_0028BFD0; case 0x0028BFD2u: goto L_0028BFD2; case 0x0028BFD4u: goto L_0028BFD4; case 0x0028BFD6u: goto L_0028BFD6; case 0x0028BFD8u: goto L_0028BFD8; case 0x0028BFDAu: goto L_0028BFDA; case 0x0028BFDEu: goto L_0028BFDE; case 0x0028BFE0u: goto L_0028BFE0; case 0x0028BFE2u: goto L_0028BFE2; case 0x0028BFE4u: goto L_0028BFE4; case 0x0028BFE6u: goto L_0028BFE6; case 0x0028BFE8u: goto L_0028BFE8; case 0x0028BFEAu: goto L_0028BFEA; default: sh2_call(c, x); return; } }  // 0028BFEA jmp @r1 ; nop
}

}  // namespace p_fin_installer
