#include "p_fin_installer_funcs.h"

namespace p_fin_installer {

static const SH2FuncEntry funcs[] = {
    {0x0028BFA4u, f_0028BFA4},
};

uint8_t ran[1];
static const uint16_t sizes[] = {37};

extern const SH2Module module = {"FIN_INSTALLER", 0x0028BFA4u, 104u, 0xAFDE125Du, funcs, 1, ran, sizes, true};

}  // namespace p_fin_installer
