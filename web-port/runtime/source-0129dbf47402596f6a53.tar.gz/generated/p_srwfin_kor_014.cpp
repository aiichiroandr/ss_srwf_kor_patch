#include "p_srwfin_kor_funcs.h"

namespace p_srwfin_kor {

void f_0602FBB4(SH2Context& c) {
    ran[684] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602FBB4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602FBB6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0602FBB8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0602FBBA mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0602FBBC mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0602FBBE mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602FBC0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602FBC2 sts.l pr,@-r15
    c.r[15] -= 12;  // 0602FBC4 add #-12,r15
    c.r[14] = c.r[15];  // 0602FBC6 mov r15,r14
    c.r[5] = c.r[5] & 0xFFu;  // 0602FBC8 extu.b r5,r5
    st32(c.r[14], c.r[5]);  // 0602FBCA mov.l r5,@r14
    c.r[6] = c.r[6] & 0xFFu;  // 0602FBCC extu.b r6,r6
    st32(c.r[14] + 4, c.r[6]);  // 0602FBCE mov.l r6,@(4,r14)
    c.r[0] = ld32(0x0602FDDCu);  // 0602FBD0 mov.l 0x0602FDDC,r0
    c.r[12] = 0x1Eu;  // 0602FBD2 mov #30,r12
    c.macl = c.r[5] * c.r[12];  // 0602FBD4 mul.l r12,r5
    c.r[1] = ld32(c.r[0]);  // 0602FBD6 mov.l @r0,r1
    c.r[13] = c.r[4];  // 0602FBD8 mov r4,r13
    c.r[0] = c.macl;  // 0602FBDA sts macl,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0602FBDC mov.w @(r0,r1),r1
    st32(c.r[14] + 8, c.r[0]);  // 0602FBDE mov.l r0,@(8,r14)
    st16(c.r[13], c.r[1]);  // 0602FBE0 mov.w r1,@r13
    c.r[1] = ld32(0x0602FDE0u);  // 0602FBE2 mov.l 0x0602FDE0,r1
    c.r[1] = ld32(c.r[1]);  // 0602FBE4 mov.l @r1,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0602FBE6 mov.w @r1,r4
    c.r[5] = 0x1u;  // 0602FBE8 mov #1,r5
    c.r[1] = ld32(0x0602FDE4u);  // 0602FBEA mov.l 0x0602FDE4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602FBF0u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602FBF0u) return; }  // 0602FBEC jsr @r1 ; extu.w r4,r4
    c.r[12] = ld32(0x0602FDDCu);  // 0602FBF0 mov.l 0x0602FDDC,r12
    c.r[3] = c.r[13];  // 0602FBF2 mov r13,r3
    c.r[3] += 2;  // 0602FBF4 add #2,r3
    c.r[7] = 0x3Fu;  // 0602FBF6 mov #63,r7
    c.r[10] = c.r[13];  // 0602FBF8 mov r13,r10
    c.r[10] += 3;  // 0602FBFA add #3,r10
    c.r[1] = ld32(c.r[12]);  // 0602FBFC mov.l @r12,r1
    c.r[4] = ld32(0x0602FDE8u);  // 0602FBFE mov.l 0x0602FDE8,r4
    c.r[0] = ld32(c.r[14] + 8);  // 0602FC00 mov.l @(8,r14),r0
    c.r[9] = ld32(0x0602FDECu);  // 0602FC02 mov.l 0x0602FDEC,r9
    c.macl = c.r[0];  // 0602FC04 lds r0,macl
    c.r[12] = (uint32_t)(int16_t)ld16(0x0602FDD4u);  // 0602FC06 mov.w 0x0602FDD4,r12
    c.r[2] = c.macl;  // 0602FC08 sts macl,r2
    c.r[2] += c.r[1];  // 0602FC0A add r1,r2
    c.r[2] += 2;  // 0602FC0C add #2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602FC0E mov.b @r2,r1
    c.r[0] = ld32(0x0602FDDCu);  // 0602FC10 mov.l 0x0602FDDC,r0
    c.r[1] &= c.r[12];  // 0602FC12 and r12,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0602FC14 mov.b @r3,r2
    c.r[12] = 0x20u;  // 0602FC16 mov #32,r12
    c.r[7] &= c.r[2];  // 0602FC18 and r2,r7
    c.r[7] |= c.r[1];  // 0602FC1A or r1,r7
    st8(c.r[3], c.r[7]);  // 0602FC1C mov.b r7,@r3
    c.r[1] = ld32(c.r[0]);  // 0602FC1E mov.l @r0,r1
    c.r[2] = c.macl;  // 0602FC20 sts macl,r2
    c.r[2] += c.r[1];  // 0602FC22 add r1,r2
    c.r[2] += 2;  // 0602FC24 add #2,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602FDD6u);  // 0602FC26 mov.w 0x0602FDD6,r0
    c.r[7] &= c.r[0];  // 0602FC28 and r0,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602FC2A mov.b @r2,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602FDD8u);  // 0602FC2C mov.w 0x0602FDD8,r0
    c.r[1] &= c.r[12];  // 0602FC2E and r12,r1
    c.r[7] |= c.r[1];  // 0602FC30 or r1,r7
    st8(c.r[3], c.r[7]);  // 0602FC32 mov.b r7,@r3
    c.r[12] = ld32(0x0602FDDCu);  // 0602FC34 mov.l 0x0602FDDC,r12
    c.r[1] = ld32(c.r[12]);  // 0602FC36 mov.l @r12,r1
    c.r[2] = c.macl;  // 0602FC38 sts macl,r2
    c.r[2] += c.r[1];  // 0602FC3A add r1,r2
    c.r[2] += 3;  // 0602FC3C add #3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602FC3E mov.b @r2,r1
    c.r[12] = 0xFu;  // 0602FC40 mov #15,r12
    c.r[1] += c.r[1];  // 0602FC42 add r1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0602FC44 mov.b @r10,r2
    c.r[1] &= c.r[0];  // 0602FC46 and r0,r1
    c.r[2] &= c.r[12];  // 0602FC48 and r12,r2
    c.r[2] |= c.r[1];  // 0602FC4A or r1,r2
    st8(c.r[10], c.r[2]);  // 0602FC4C mov.b r2,@r10
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[13]);  // 0602FC4E mov.w @r13,r8
    c.r[5] = 0x1Bu;  // 0602FC50 mov #27,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0602FC56u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602FC56u) return; }  // 0602FC52 jsr @r9 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 0602FC56 mov r0,r1
    c.r[5] = c.r[8];  // 0602FC58 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0602FC5Eu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602FC5Eu) return; }  // 0602FC5A jsr @r9 ; mov r1,r4
    c.r[11] = c.r[0];  // 0602FC5E mov r0,r11
    c.r[0] = ld32(0x0602FDDCu);  // 0602FC60 mov.l 0x0602FDDC,r0
    c.r[3] = 0x7u;  // 0602FC62 mov #7,r3
    c.r[7] = 0xFu;  // 0602FC64 mov #15,r7
    c.r[6] = 0x7u;  // 0602FC66 mov #7,r6
    c.r[1] = ld32(c.r[0]);  // 0602FC68 mov.l @r0,r1
    c.r[8] = 0x0u;  // 0602FC6A mov #0,r8
    c.r[12] = ld32(c.r[14] + 8);  // 0602FC6C mov.l @(8,r14),r12
    c.r[5] = 0x7u;  // 0602FC6E mov #7,r5
    c.macl = c.r[12];  // 0602FC70 lds r12,macl
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602FDD8u);  // 0602FC72 mov.w 0x0602FDD8,r0
    c.r[2] = c.macl;  // 0602FC74 sts macl,r2
    c.r[2] += c.r[1];  // 0602FC76 add r1,r2
    c.r[1] = c.r[2];  // 0602FC78 mov r2,r1
    c.r[1] += 3;  // 0602FC7A add #3,r1
    c.r[2] += 4;  // 0602FC7C add #4,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602FC7E mov.b @r1,r1
    c.r[12] = ld32(0x0602FDDCu);  // 0602FC80 mov.l 0x0602FDDC,r12
    c.r[3] &= c.r[1];  // 0602FC82 and r1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602FC84 mov.b @r2,r1
    c.r[3] += c.r[3];  // 0602FC86 add r3,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0602FC88 extu.b r1,r1
    c.r[1] >>= 2;  // 0602FC8A shlr2 r1
    c.r[1] >>= 2;  // 0602FC8C shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0602FC8E shlr r1
    c.r[1] >>= 2;  // 0602FC90 shlr2 r1
    c.r[3] |= c.r[1];  // 0602FC92 or r1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0602FC94 mov.b @r10,r1
    c.r[2] = c.macl;  // 0602FC96 sts macl,r2
    c.r[1] &= c.r[0];  // 0602FC98 and r0,r1
    c.r[1] |= c.r[3];  // 0602FC9A or r3,r1
    st8(c.r[10], c.r[1]);  // 0602FC9C mov.b r1,@r10
    c.r[1] = ld32(c.r[12]);  // 0602FC9E mov.l @r12,r1
    c.r[3] = c.r[13];  // 0602FCA0 mov r13,r3
    c.r[2] += c.r[1];  // 0602FCA2 add r1,r2
    c.r[2] += 4;  // 0602FCA4 add #4,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602FCA6 mov.b @r2,r1
    c.r[3] += 4;  // 0602FCA8 add #4,r3
    c.r[1] += c.r[1];  // 0602FCAA add r1,r1
    c.r[1] &= c.r[0];  // 0602FCAC and r0,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0602FCAE mov.b @r3,r2
    c.r[0] = 0xFu;  // 0602FCB0 mov #15,r0
    c.r[7] &= c.r[2];  // 0602FCB2 and r2,r7
    c.r[7] |= c.r[1];  // 0602FCB4 or r1,r7
    st8(c.r[3], c.r[7]);  // 0602FCB6 mov.b r7,@r3
    c.r[1] = ld32(c.r[12]);  // 0602FCB8 mov.l @r12,r1
    c.r[2] = c.macl;  // 0602FCBA sts macl,r2
    c.r[2] += c.r[1];  // 0602FCBC add r1,r2
    c.r[2] += 4;  // 0602FCBE add #4,r2
    c.r[12] = (uint32_t)(int16_t)ld16(0x0602FDD8u);  // 0602FCC0 mov.w 0x0602FDD8,r12
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0602FCC2 mov.w @r2,r1
    c.r[7] &= c.r[12];  // 0602FCC4 and r12,r7
    c.r[1] >>= 2;  // 0602FCC6 shlr2 r1
    c.r[1] >>= 2;  // 0602FCC8 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0602FCCA shlr r1
    c.r[1] >>= 2;  // 0602FCCC shlr2 r1
    c.r[1] &= c.r[0];  // 0602FCCE and r0,r1
    c.r[7] |= c.r[1];  // 0602FCD0 or r1,r7
    st8(c.r[3], c.r[7]);  // 0602FCD2 mov.b r7,@r3
    c.r[0] = ld32(0x0602FDDCu);  // 0602FCD4 mov.l 0x0602FDDC,r0
    c.r[2] = c.macl;  // 0602FCD6 sts macl,r2
    c.r[3] = c.r[13];  // 0602FCD8 mov r13,r3
    c.r[1] = ld32(c.r[0]);  // 0602FCDA mov.l @r0,r1
    c.r[3] += 5;  // 0602FCDC add #5,r3
    c.r[2] += c.r[1];  // 0602FCDE add r1,r2
    c.r[2] += 5;  // 0602FCE0 add #5,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602FCE2 mov.b @r2,r1
    c.r[7] = 0xFu;  // 0602FCE4 mov #15,r7
    c.r[1] += c.r[1];  // 0602FCE6 add r1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0602FCE8 mov.b @r3,r2
    c.r[1] &= c.r[12];  // 0602FCEA and r12,r1
    c.r[7] &= c.r[2];  // 0602FCEC and r2,r7
    c.r[7] |= c.r[1];  // 0602FCEE or r1,r7
    st8(c.r[3], c.r[7]);  // 0602FCF0 mov.b r7,@r3
    c.r[2] = c.macl;  // 0602FCF2 sts macl,r2
    c.r[1] = ld32(c.r[0]);  // 0602FCF4 mov.l @r0,r1
    c.r[7] &= c.r[12];  // 0602FCF6 and r12,r7
    c.r[2] += c.r[1];  // 0602FCF8 add r1,r2
    c.r[1] = c.r[2];  // 0602FCFA mov r2,r1
    c.r[1] += 5;  // 0602FCFC add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602FCFE mov.b @r1,r1
    c.r[2] += 6;  // 0602FD00 add #6,r2
    c.r[6] &= c.r[1];  // 0602FD02 and r1,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602FD04 mov.b @r2,r1
    c.r[6] += c.r[6];  // 0602FD06 add r6,r6
    c.r[1] = c.r[1] & 0xFFu;  // 0602FD08 extu.b r1,r1
    c.r[1] >>= 2;  // 0602FD0A shlr2 r1
    c.r[1] >>= 2;  // 0602FD0C shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0602FD0E shlr r1
    c.r[1] >>= 2;  // 0602FD10 shlr2 r1
    c.r[6] |= c.r[1];  // 0602FD12 or r1,r6
    c.r[7] |= c.r[6];  // 0602FD14 or r6,r7
    st8(c.r[3], c.r[7]);  // 0602FD16 mov.b r7,@r3
    c.r[3] = c.r[13];  // 0602FD18 mov r13,r3
    c.r[3] += 14;  // 0602FD1A add #14,r3
    c.r[2] = c.macl;  // 0602FD1C sts macl,r2
    c.r[1] = ld32(c.r[0]);  // 0602FD1E mov.l @r0,r1
    c.r[6] = ld32(0x0602FDDCu);  // 0602FD20 mov.l 0x0602FDDC,r6
    c.r[2] += c.r[1];  // 0602FD22 add r1,r2
    c.r[2] += 15;  // 0602FD24 add #15,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602FD26 mov.b @r2,r1
    c.r[7] = 0x1Eu;  // 0602FD28 mov #30,r7
    st8(c.r[3], c.r[1]);  // 0602FD2A mov.b r1,@r3
    c.r[3] = c.r[13];  // 0602FD2C mov r13,r3
    c.r[1] = ld32(c.r[0]);  // 0602FD2E mov.l @r0,r1
    c.r[2] = c.macl;  // 0602FD30 sts macl,r2
    c.r[2] += c.r[1];  // 0602FD32 add r1,r2
    c.r[2] += 16;  // 0602FD34 add #16,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602FD36 mov.b @r2,r1
    c.r[3] += 15;  // 0602FD38 add #15,r3
    st8(c.r[3], c.r[1]);  // 0602FD3A mov.b r1,@r3
    c.r[3] = c.r[13];  // 0602FD3C mov r13,r3
    c.r[1] = ld32(c.r[0]);  // 0602FD3E mov.l @r0,r1
    c.r[2] = c.macl;  // 0602FD40 sts macl,r2
    c.r[2] += c.r[1];  // 0602FD42 add r1,r2
    c.r[2] += 22;  // 0602FD44 add #22,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0602FD46 mov.w @r2,r1
    c.r[3] += 22;  // 0602FD48 add #22,r3
    st16(c.r[3], c.r[1]);  // 0602FD4A mov.w r1,@r3
L_0602FD4C:
    c.r[3] = c.r[13];  // 0602FD4C mov r13,r3
    c.r[12] = ld32(c.r[14]);  // 0602FD4E mov.l @r14,r12
    c.r[3] += c.r[8];  // 0602FD50 add r8,r3
    c.macl = c.r[12] * c.r[7];  // 0602FD52 mul.l r7,r12
    c.r[3] += 6;  // 0602FD54 add #6,r3
    c.r[1] = ld32(c.r[6]);  // 0602FD56 mov.l @r6,r1
    c.r[2] = c.macl;  // 0602FD58 sts macl,r2
    c.r[2] += c.r[1];  // 0602FD5A add r1,r2
    c.r[2] += c.r[8];  // 0602FD5C add r8,r2
    c.r[2] += 7;  // 0602FD5E add #7,r2
    c.r[8] += 1;  // 0602FD60 add #1,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602FD62 mov.b @r2,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[5];  // 0602FD64 cmp/gt r5,r8
    { const bool k = !c.t; st8(c.r[3], c.r[1]); if (k) { SH2_POLL(c); goto L_0602FD4C; } }  // 0602FD66 bf/s 0x0602FD4C ; mov.b r1,@r3
    c.r[9] = 0x0u;  // 0602FD6A mov #0,r9
    c.r[8] = ld32(0x0602FDECu);  // 0602FD6C mov.l 0x0602FDEC,r8
    c.r[4] = ld32(0x0602FDE8u);  // 0602FD6E mov.l 0x0602FDE8,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0602FD74u; c.r[5] = 0x1Fu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602FD74u) return; }  // 0602FD70 jsr @r8 ; mov #31,r5
    c.r[5] = 0x0u;  // 0602FD74 mov #0,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0602FD7Au; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602FD7Au) return; }  // 0602FD76 jsr @r8 ; mov r0,r4
    c.r[1] = c.r[13];  // 0602FD7A mov r13,r1
    c.r[1] += 5;  // 0602FD7C add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602FD7E mov.b @r1,r1
    c.r[3] = 0x1u;  // 0602FD80 mov #1,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0602FD82 extu.b r1,r1
    c.r[1] >>= 2;  // 0602FD84 shlr2 r1
    c.r[1] >>= 2;  // 0602FD86 shlr2 r1
    c.t = (int32_t)c.r[3] > (int32_t)c.r[1];  // 0602FD88 cmp/gt r1,r3
    { const bool k = c.t; c.r[2] = c.r[0]; if (k) { goto L_0602FDB4; } }  // 0602FD8A bt/s 0x0602FDB4 ; mov r0,r2
    c.r[7] = c.r[1];  // 0602FD8E mov r1,r7
    c.r[6] = c.r[2];  // 0602FD90 mov r2,r6
    c.r[6] += 2;  // 0602FD92 add #2,r6
L_0602FD94:
    c.r[1] = c.r[6];  // 0602FD94 mov r6,r1
    c.r[1] -= 2;  // 0602FD96 add #-2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602FD98 mov.b @r1,r2
    c.r[3] += 1;  // 0602FD9A add #1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0602FD9C extu.b r2,r2
    c.r[2] <<= 8;  // 0602FD9E shll8 r2
    c.r[1] = c.r[6];  // 0602FDA0 mov r6,r1
    c.r[1] -= 1;  // 0602FDA2 add #-1,r1
    c.r[6] += 2;  // 0602FDA4 add #2,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602FDA6 mov.b @r1,r1
    c.t = (int32_t)c.r[3] > (int32_t)c.r[7];  // 0602FDA8 cmp/gt r7,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0602FDAA extu.b r1,r1
    c.r[2] += c.r[1];  // 0602FDAC add r1,r2
    c.r[2] += c.r[9];  // 0602FDAE add r9,r2
    { const bool k = !c.t; c.r[9] = c.r[2] & 0xFFFFu; if (k) { SH2_POLL(c); goto L_0602FD94; } }  // 0602FDB0 bf/s 0x0602FD94 ; extu.w r2,r9
L_0602FDB4:
    c.r[3] = c.r[13];  // 0602FDB4 mov r13,r3
    c.r[3] += 32;  // 0602FDB6 add #32,r3
    c.r[1] = c.r[11];  // 0602FDB8 mov r11,r1
    c.r[1] += 32;  // 0602FDBA add #32,r1
    c.r[5] = c.r[9];  // 0602FDBC mov r9,r5
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602FDBE mov.b @r1,r2
    c.r[4] = c.r[13];  // 0602FDC0 mov r13,r4
    c.r[2] = c.r[2] & 0xFFu;  // 0602FDC2 extu.b r2,r2
    c.r[1] = c.r[11];  // 0602FDC4 mov r11,r1
    c.r[1] += 33;  // 0602FDC6 add #33,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602FDC8 mov.b @r1,r1
    c.r[2] <<= 8;  // 0602FDCA shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0602FDCC extu.b r1,r1
    c.r[2] |= c.r[1];  // 0602FDCE or r1,r2
    st16(c.r[3], c.r[2]); goto L_0602FDF0;  // 0602FDD0 bra 0x0602FDF0 ; mov.w r2,@r3
L_0602FDF0:
    c.r[1] = ld32(0x06030160u);  // 0602FDF0 mov.l 0x06030160,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602FDF6u; c.r[9] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602FDF6u) return; }  // 0602FDF2 jsr @r1 ; mov #0,r9
    c.r[8] = ld32(0x06030164u);  // 0602FDF6 mov.l 0x06030164,r8
    c.r[4] = ld32(0x06030168u);  // 0602FDF8 mov.l 0x06030168,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0602FDFEu; c.r[5] = 0x1Fu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602FDFEu) return; }  // 0602FDFA jsr @r8 ; mov #31,r5
    c.r[5] = 0x0u;  // 0602FDFE mov #0,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0602FE04u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602FE04u) return; }  // 0602FE00 jsr @r8 ; mov r0,r4
    c.r[2] = c.r[0];  // 0602FE04 mov r0,r2
    c.r[1] = c.r[13];  // 0602FE06 mov r13,r1
    c.r[1] += 4;  // 0602FE08 add #4,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602FE0A mov.b @r1,r0
    c.r[3] = 0x1u;  // 0602FE0C mov #1,r3
    c.r[1] = 0xFu;  // 0602FE0E mov #15,r1
    c.r[1] &= c.r[0];  // 0602FE10 and r0,r1
    c.t = (int32_t)c.r[3] > (int32_t)c.r[1];  // 0602FE12 cmp/gt r1,r3
    { const bool k = c.t; c.r[7] = c.r[1]; if (k) { goto L_0602FE3C; } }  // 0602FE14 bt/s 0x0602FE3C ; mov r1,r7
    c.r[6] = c.r[2];  // 0602FE18 mov r2,r6
    c.r[6] += 22;  // 0602FE1A add #22,r6
L_0602FE1C:
    c.r[1] = c.r[6];  // 0602FE1C mov r6,r1
    c.r[1] -= 2;  // 0602FE1E add #-2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602FE20 mov.b @r1,r2
    c.r[3] += 1;  // 0602FE22 add #1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0602FE24 extu.b r2,r2
    c.r[2] <<= 8;  // 0602FE26 shll8 r2
    c.r[1] = c.r[6];  // 0602FE28 mov r6,r1
    c.r[1] -= 1;  // 0602FE2A add #-1,r1
    c.r[6] += 2;  // 0602FE2C add #2,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602FE2E mov.b @r1,r1
    c.t = (int32_t)c.r[3] > (int32_t)c.r[7];  // 0602FE30 cmp/gt r7,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0602FE32 extu.b r1,r1
    c.r[2] += c.r[1];  // 0602FE34 add r1,r2
    c.r[2] += c.r[9];  // 0602FE36 add r9,r2
    { const bool k = !c.t; c.r[9] = c.r[2] & 0xFFFFu; if (k) { SH2_POLL(c); goto L_0602FE1C; } }  // 0602FE38 bf/s 0x0602FE1C ; extu.w r2,r9
L_0602FE3C:
    c.r[3] = c.r[13];  // 0602FE3C mov r13,r3
    c.r[3] += 30;  // 0602FE3E add #30,r3
    c.r[1] = c.r[11];  // 0602FE40 mov r11,r1
    c.r[1] += 28;  // 0602FE42 add #28,r1
    c.r[5] = c.r[9];  // 0602FE44 mov r9,r5
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602FE46 mov.b @r1,r2
    c.r[4] = c.r[13];  // 0602FE48 mov r13,r4
    c.r[2] = c.r[2] & 0xFFu;  // 0602FE4A extu.b r2,r2
    c.r[1] = c.r[11];  // 0602FE4C mov r11,r1
    c.r[1] += 29;  // 0602FE4E add #29,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602FE50 mov.b @r1,r1
    c.r[2] <<= 8;  // 0602FE52 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0602FE54 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0602FE56 or r1,r2
    c.r[1] = ld32(0x0603016Cu);  // 0602FE58 mov.l 0x0603016C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602FE5Eu; st16(c.r[3], c.r[2]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602FE5Eu) return; }  // 0602FE5A jsr @r1 ; mov.w r2,@r3
    c.r[9] = 0x0u;  // 0602FE5E mov #0,r9
    c.r[8] = ld32(0x06030164u);  // 0602FE60 mov.l 0x06030164,r8
    c.r[4] = ld32(0x06030168u);  // 0602FE62 mov.l 0x06030168,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0602FE68u; c.r[5] = 0x1Fu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602FE68u) return; }  // 0602FE64 jsr @r8 ; mov #31,r5
    c.r[5] = 0x0u;  // 0602FE68 mov #0,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0602FE6Eu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602FE6Eu) return; }  // 0602FE6A jsr @r8 ; mov r0,r4
    c.r[2] = c.r[0];  // 0602FE6E mov r0,r2
    c.r[1] = c.r[13];  // 0602FE70 mov r13,r1
    c.r[1] += 3;  // 0602FE72 add #3,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602FE74 mov.b @r1,r0
    c.r[3] = 0x1u;  // 0602FE76 mov #1,r3
    c.r[1] = 0xFu;  // 0602FE78 mov #15,r1
    c.r[1] &= c.r[0];  // 0602FE7A and r0,r1
    c.t = (int32_t)c.r[3] > (int32_t)c.r[1];  // 0602FE7C cmp/gt r1,r3
    { const bool k = c.t; c.r[7] = c.r[1]; if (k) { goto L_0602FEA6; } }  // 0602FE7E bt/s 0x0602FEA6 ; mov r1,r7
    c.r[6] = c.r[2];  // 0602FE82 mov r2,r6
    c.r[6] += 62;  // 0602FE84 add #62,r6
L_0602FE86:
    c.r[1] = c.r[6];  // 0602FE86 mov r6,r1
    c.r[1] -= 2;  // 0602FE88 add #-2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602FE8A mov.b @r1,r2
    c.r[3] += 1;  // 0602FE8C add #1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0602FE8E extu.b r2,r2
    c.r[2] <<= 8;  // 0602FE90 shll8 r2
    c.r[1] = c.r[6];  // 0602FE92 mov r6,r1
    c.r[1] -= 1;  // 0602FE94 add #-1,r1
    c.r[6] += 2;  // 0602FE96 add #2,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602FE98 mov.b @r1,r1
    c.t = (int32_t)c.r[3] > (int32_t)c.r[7];  // 0602FE9A cmp/gt r7,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0602FE9C extu.b r1,r1
    c.r[2] += c.r[1];  // 0602FE9E add r1,r2
    c.r[2] += c.r[9];  // 0602FEA0 add r9,r2
    { const bool k = !c.t; c.r[9] = c.r[2] & 0xFFFFu; if (k) { SH2_POLL(c); goto L_0602FE86; } }  // 0602FEA2 bf/s 0x0602FE86 ; extu.w r2,r9
L_0602FEA6:
    c.r[3] = c.r[13];  // 0602FEA6 mov r13,r3
    c.r[3] += 26;  // 0602FEA8 add #26,r3
    c.r[1] = c.r[11];  // 0602FEAA mov r11,r1
    c.r[1] += 36;  // 0602FEAC add #36,r1
    c.r[5] = c.r[9];  // 0602FEAE mov r9,r5
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602FEB0 mov.b @r1,r2
    c.r[4] = c.r[13];  // 0602FEB2 mov r13,r4
    c.r[2] = c.r[2] & 0xFFu;  // 0602FEB4 extu.b r2,r2
    c.r[1] = c.r[11];  // 0602FEB6 mov r11,r1
    c.r[1] += 37;  // 0602FEB8 add #37,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602FEBA mov.b @r1,r1
    c.r[2] <<= 8;  // 0602FEBC shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0602FEBE extu.b r1,r1
    c.r[2] |= c.r[1];  // 0602FEC0 or r1,r2
    c.r[1] = ld32(0x06030170u);  // 0602FEC2 mov.l 0x06030170,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602FEC8u; st16(c.r[3], c.r[2]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602FEC8u) return; }  // 0602FEC4 jsr @r1 ; mov.w r2,@r3
    c.r[9] = 0x0u;  // 0602FEC8 mov #0,r9
    c.r[8] = ld32(0x06030164u);  // 0602FECA mov.l 0x06030164,r8
    c.r[4] = ld32(0x06030168u);  // 0602FECC mov.l 0x06030168,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0602FED2u; c.r[5] = 0x1Fu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602FED2u) return; }  // 0602FECE jsr @r8 ; mov #31,r5
    c.r[5] = 0x0u;  // 0602FED2 mov #0,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0602FED8u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602FED8u) return; }  // 0602FED4 jsr @r8 ; mov r0,r4
    c.r[2] = c.r[0];  // 0602FED8 mov r0,r2
    c.r[1] = c.r[13];  // 0602FEDA mov r13,r1
    c.r[1] += 5;  // 0602FEDC add #5,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602FEDE mov.b @r1,r0
    c.r[3] = 0x1u;  // 0602FEE0 mov #1,r3
    c.r[1] = 0xFu;  // 0602FEE2 mov #15,r1
    c.r[1] &= c.r[0];  // 0602FEE4 and r0,r1
    c.t = (int32_t)c.r[3] > (int32_t)c.r[1];  // 0602FEE6 cmp/gt r1,r3
    { const bool k = c.t; c.r[7] = c.r[1]; if (k) { goto L_0602FF10; } }  // 0602FEE8 bt/s 0x0602FF10 ; mov r1,r7
    c.r[6] = c.r[2];  // 0602FEEC mov r2,r6
    c.r[6] += 82;  // 0602FEEE add #82,r6
L_0602FEF0:
    c.r[1] = c.r[6];  // 0602FEF0 mov r6,r1
    c.r[1] -= 2;  // 0602FEF2 add #-2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602FEF4 mov.b @r1,r2
    c.r[3] += 1;  // 0602FEF6 add #1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0602FEF8 extu.b r2,r2
    c.r[2] <<= 8;  // 0602FEFA shll8 r2
    c.r[1] = c.r[6];  // 0602FEFC mov r6,r1
    c.r[1] -= 1;  // 0602FEFE add #-1,r1
    c.r[6] += 2;  // 0602FF00 add #2,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602FF02 mov.b @r1,r1
    c.t = (int32_t)c.r[3] > (int32_t)c.r[7];  // 0602FF04 cmp/gt r7,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0602FF06 extu.b r1,r1
    c.r[2] += c.r[1];  // 0602FF08 add r1,r2
    c.r[2] += c.r[9];  // 0602FF0A add r9,r2
    { const bool k = !c.t; c.r[9] = c.r[2] & 0xFFFFu; if (k) { SH2_POLL(c); goto L_0602FEF0; } }  // 0602FF0C bf/s 0x0602FEF0 ; extu.w r2,r9
L_0602FF10:
    c.r[1] = c.r[11];  // 0602FF10 mov r11,r1
    c.r[1] += 30;  // 0602FF12 add #30,r1
    c.r[3] = c.r[13];  // 0602FF14 mov r13,r3
    c.r[3] += 34;  // 0602FF16 add #34,r3
    c.r[5] = c.r[9];  // 0602FF18 mov r9,r5
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602FF1A mov.b @r1,r2
    c.r[4] = c.r[13];  // 0602FF1C mov r13,r4
    c.r[1] = c.r[11];  // 0602FF1E mov r11,r1
    c.r[1] += 31;  // 0602FF20 add #31,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0602FF22 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602FF24 mov.b @r1,r1
    c.r[2] <<= 8;  // 0602FF26 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0602FF28 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0602FF2A or r1,r2
    c.r[1] = ld32(0x06030174u);  // 0602FF2C mov.l 0x06030174,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602FF32u; st16(c.r[3], c.r[2]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602FF32u) return; }  // 0602FF2E jsr @r1 ; mov.w r2,@r3
    c.r[1] = c.r[11];  // 0602FF32 mov r11,r1
    c.r[1] += 25;  // 0602FF34 add #25,r1
    c.r[3] = c.r[13];  // 0602FF36 mov r13,r3
    c.r[3] += 37;  // 0602FF38 add #37,r3
    c.r[0] = 0xFu;  // 0602FF3A mov #15,r0
    c.r[7] = c.r[11];  // 0602FF3C mov r11,r7
    c.r[7] += 27;  // 0602FF3E add #27,r7
    c.r[12] = 0x7u;  // 0602FF40 mov #7,r12
    c.r[5] = (uint32_t)(int16_t)ld16(0x06030138u);  // 0602FF42 mov.w 0x06030138,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602FF44 mov.b @r1,r1
    c.r[8] = ld32(0x06030164u);  // 0602FF46 mov.l 0x06030164,r8
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0602FF48 mov.b @r3,r2
    c.r[1] &= c.r[0];  // 0602FF4A and r0,r1
    c.r[1] <<= 2;  // 0602FF4C shll2 r1
    c.r[1] <<= 2;  // 0602FF4E shll2 r1
    c.r[2] &= c.r[0];  // 0602FF50 and r0,r2
    c.r[2] |= c.r[1];  // 0602FF52 or r1,r2
    st8(c.r[3], c.r[2]);  // 0602FF54 mov.b r2,@r3
    c.r[2] = c.r[13];  // 0602FF56 mov r13,r2
    c.r[2] += 36;  // 0602FF58 add #36,r2
    c.r[1] = c.r[11];  // 0602FF5A mov r11,r1
    c.r[1] += 24;  // 0602FF5C add #24,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602FF5E mov.b @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0603013Au);  // 0602FF60 mov.w 0x0603013A,r0
    st8(c.r[2], c.r[1]);  // 0602FF62 mov.b r1,@r2
    c.r[2] = c.r[11];  // 0602FF64 mov r11,r2
    c.r[2] += 26;  // 0602FF66 add #26,r2
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602FF68 mov.b @r2,r4
    c.r[1] = ld32(0x06030178u);  // 0602FF6A mov.l 0x06030178,r1
    c.r[4] = c.r[4] & 0xFFu;  // 0602FF6C extu.b r4,r4
    c.r[4] <<= 8;  // 0602FF6E shll8 r4
    c.r[4] &= c.r[1];  // 0602FF70 and r1,r4
    c.r[1] = ld32(0x0603017Cu);  // 0602FF72 mov.l 0x0603017C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602FF78u; c.r[9] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602FF78u) return; }  // 0602FF74 jsr @r1 ; mov #0,r9
    c.r[6] = c.r[4];  // 0602FF78 mov r4,r6
    c.r[6] &= c.r[12];  // 0602FF7A and r12,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0602FF7C mov.b @r3,r1
    c.r[6] += c.r[6];  // 0602FF7E add r6,r6
    c.r[1] &= c.r[0];  // 0602FF80 and r0,r1
    c.r[1] |= c.r[6];  // 0602FF82 or r6,r1
    st8(c.r[3], c.r[1]);  // 0602FF84 mov.b r1,@r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603013Cu);  // 0602FF86 mov.w 0x0603013C,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0603013Eu);  // 0602FF88 mov.w 0x0603013E,r0
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602FF8A mov.b @r2,r4
    c.r[6] = (uint32_t)(int16_t)ld16(0x06030140u);  // 0602FF8C mov.w 0x06030140,r6
    c.r[4] = c.r[4] & 0xFFu;  // 0602FF8E extu.b r4,r4
    c.r[4] <<= 8;  // 0602FF90 shll8 r4
    c.r[4] &= c.r[1];  // 0602FF92 and r1,r4
    c.r[1] = ld32(0x06030180u);  // 0602FF94 mov.l 0x06030180,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602FF9Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602FF9Au) return; }  // 0602FF96 jsr @r1 ; nop
    c.r[3] = c.r[4];  // 0602FF9A mov r4,r3
    c.r[3] &= c.r[12];  // 0602FF9C and r12,r3
    c.r[3] <<= 8;  // 0602FF9E shll8 r3
    c.r[3] >>= 2;  // 0602FFA0 shlr2 r3
    c.r[3] <<= 8;  // 0602FFA2 shll8 r3
    c.r[2] = ld32(0x06030184u);  // 0602FFA4 mov.l 0x06030184,r2
    c.r[12] = 0x38u;  // 0602FFA6 mov #56,r12
    c.r[1] = ld32(c.r[13] + 36);  // 0602FFA8 mov.l @(36,r13),r1
    c.r[4] = ld32(0x06030168u);  // 0602FFAA mov.l 0x06030168,r4
    c.r[1] &= c.r[2];  // 0602FFAC and r2,r1
    c.r[3] |= c.r[1];  // 0602FFAE or r1,r3
    st32(c.r[13] + 36, c.r[3]);  // 0602FFB0 mov.l r3,@(36,r13)
    c.r[2] = c.r[13];  // 0602FFB2 mov r13,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0602FFB4 mov.b @r7,r1
    c.r[2] += 38;  // 0602FFB6 add #38,r2
    c.r[3] = c.r[1];  // 0602FFB8 mov r1,r3
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 0602FFBA shlr r3
    c.r[3] &= c.r[12];  // 0602FFBC and r12,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602FFBE mov.b @r2,r1
    c.r[12] = 0x7u;  // 0602FFC0 mov #7,r12
    c.r[1] &= c.r[0];  // 0602FFC2 and r0,r1
    c.r[1] |= c.r[3];  // 0602FFC4 or r3,r1
    st8(c.r[2], c.r[1]);  // 0602FFC6 mov.b r1,@r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06030142u);  // 0602FFC8 mov.w 0x06030142,r0
    c.r[1] &= c.r[0];  // 0602FFCA and r0,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0602FFCC mov.b @r7,r3
    c.r[0] = c.r[13];  // 0602FFCE mov r13,r0
    c.r[3] &= c.r[12];  // 0602FFD0 and r12,r3
    c.r[1] |= c.r[3];  // 0602FFD2 or r3,r1
    st8(c.r[2], c.r[1]);  // 0602FFD4 mov.b r1,@r2
    c.r[3] = c.r[11];  // 0602FFD6 mov r11,r3
    c.r[2] = 0x1u;  // 0602FFD8 mov #1,r2
    c.r[7] = (uint32_t)(int16_t)ld16(0x06030144u);  // 0602FFDA mov.w 0x06030144,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]); c.r[3] += 1;  // 0602FFDC mov.b @r3+,r1
    c.r[12] = 0x7Fu;  // 0602FFDE mov #127,r12
    c.r[2] &= c.r[1];  // 0602FFE0 and r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0602FFE2 mov.b @r3,r1
    c.r[2] <<= 8;  // 0602FFE4 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0602FFE6 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0602FFE8 or r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[7]);  // 0602FFEA mov.w @(r0,r7),r1
    c.r[2] <<= 2;  // 0602FFEC shll2 r2
    c.r[2] <<= 2;  // 0602FFEE shll2 r2
    c.r[2] += c.r[2];  // 0602FFF0 add r2,r2
    c.r[2] <<= 2;  // 0602FFF2 shll2 r2
    c.r[1] &= c.r[12];  // 0602FFF4 and r12,r1
    c.r[1] |= c.r[2];  // 0602FFF6 or r2,r1
    st16(c.r[0] + c.r[7], c.r[1]);  // 0602FFF8 mov.w r1,@(r0,r7)
    c.r[1] = c.r[11];  // 0602FFFA mov r11,r1
    c.r[1] += 2;  // 0602FFFC add #2,r1
    c.r[2] = ld32(0x06030188u);  // 0602FFFE mov.l 0x06030188,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06030000 mov.b @r1,r3
    c.r[12] = 0x7u;  // 06030002 mov #7,r12
    c.r[3] = c.r[3] & 0xFFu;  // 06030004 extu.b r3,r3
    c.r[1] = c.r[11];  // 06030006 mov r11,r1
    c.r[1] += 3;  // 06030008 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603000A mov.b @r1,r1
    c.r[3] <<= 8;  // 0603000C shll8 r3
    c.r[1] = c.r[1] & 0xFFu;  // 0603000E extu.b r1,r1
    c.r[3] |= c.r[1];  // 06030010 or r1,r3
    c.r[3] &= c.r[6];  // 06030012 and r6,r3
    c.r[1] = ld32(c.r[0] + c.r[7]);  // 06030014 mov.l @(r0,r7),r1
    c.r[3] <<= 8;  // 06030016 shll8 r3
    c.r[3] >>= 2;  // 06030018 shlr2 r3
    c.r[3] <<= 8;  // 0603001A shll8 r3
    c.r[1] &= c.r[2];  // 0603001C and r2,r1
    c.r[3] |= c.r[1];  // 0603001E or r1,r3
    st32(c.r[0] + c.r[7], c.r[3]);  // 06030020 mov.l r3,@(r0,r7)
    c.r[1] = c.r[11];  // 06030022 mov r11,r1
    c.r[1] += 4;  // 06030024 add #4,r1
    c.r[7] = c.r[11];  // 06030026 mov r11,r7
    c.r[7] += 5;  // 06030028 add #5,r7
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603002A mov.b @r1,r3
    c.r[2] = (uint32_t)(int16_t)ld16(0x06030146u);  // 0603002C mov.w 0x06030146,r2
    c.r[3] = c.r[3] & 0xFFu;  // 0603002E extu.b r3,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06030030 mov.b @r7,r1
    c.r[3] <<= 8;  // 06030032 shll8 r3
    c.r[1] = c.r[1] & 0xFFu;  // 06030034 extu.b r1,r1
    c.r[3] |= c.r[1];  // 06030036 or r1,r3
    c.r[3] >>= 2;  // 06030038 shlr2 r3
    c.r[3] >>= 2;  // 0603003A shlr2 r3
    c.r[3] &= c.r[6];  // 0603003C and r6,r3
    c.r[3] <<= 2;  // 0603003E shll2 r3
    c.r[3] += c.r[3];  // 06030040 add r3,r3
    c.r[3] <<= 2;  // 06030042 shll2 r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[5]);  // 06030044 mov.w @(r0,r5),r1
    c.r[6] = 0x78u;  // 06030046 mov #120,r6
    c.r[1] &= c.r[2];  // 06030048 and r2,r1
    c.r[1] |= c.r[3];  // 0603004A or r3,r1
    st16(c.r[0] + c.r[5], c.r[1]);  // 0603004C mov.w r1,@(r0,r5)
    c.r[2] = (uint32_t)(int16_t)ld16(0x06030148u);  // 0603004E mov.w 0x06030148,r2
    c.r[3] = 0xFu;  // 06030050 mov #15,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06030052 mov.b @r7,r1
    c.r[5] = 0x1Fu;  // 06030054 mov #31,r5
    c.r[3] &= c.r[1];  // 06030056 and r1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06030058 mov.b @(r0,r2),r1
    c.r[3] += c.r[3];  // 0603005A add r3,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x0603014Au);  // 0603005C mov.w 0x0603014A,r0
    c.r[1] &= c.r[0];  // 0603005E and r0,r1
    c.r[1] |= c.r[3];  // 06030060 or r3,r1
    c.r[0] = c.r[13];  // 06030062 mov r13,r0
    st8(c.r[0] + c.r[2], c.r[1]);  // 06030064 mov.b r1,@(r0,r2)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[11]);  // 06030066 mov.b @r11,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0603014Cu);  // 06030068 mov.w 0x0603014C,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0603006A mov.b @(r0,r2),r3
    c.r[1] = c.r[1] & 0xFFu;  // 0603006C extu.b r1,r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0603006E shlr r1
    c.r[1] <<= 2;  // 06030070 shll2 r1
    c.r[1] += c.r[1];  // 06030072 add r1,r1
    c.r[3] &= c.r[12];  // 06030074 and r12,r3
    c.r[3] |= c.r[1];  // 06030076 or r1,r3
    st8(c.r[0] + c.r[2], c.r[3]);  // 06030078 mov.b r3,@(r0,r2)
    c.r[1] = c.r[11];  // 0603007A mov r11,r1
    c.r[1] += 6;  // 0603007C add #6,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0603014Eu);  // 0603007E mov.w 0x0603014E,r0
    c.r[12] = (uint32_t)(int16_t)ld16(0x06030142u);  // 06030080 mov.w 0x06030142,r12
    c.r[3] &= c.r[12];  // 06030082 and r12,r3
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06030084 mov.b @r1,r7
    c.r[12] = 0x1Fu;  // 06030086 mov #31,r12
    c.r[7] &= c.r[0];  // 06030088 and r0,r7
    c.r[7] >>= 2;  // 0603008A shlr2 r7
    c.t = c.r[7] & 1; c.r[7] >>= 1;  // 0603008C shlr r7
    c.r[7] >>= 2;  // 0603008E shlr2 r7
    c.r[3] |= c.r[7];  // 06030090 or r7,r3
    c.r[0] = c.r[13];  // 06030092 mov r13,r0
    st8(c.r[0] + c.r[2], c.r[3]);  // 06030094 mov.b r3,@(r0,r2)
    c.r[2] = (uint32_t)(int16_t)ld16(0x06030150u);  // 06030096 mov.w 0x06030150,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06030098 mov.b @r1,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x06030152u);  // 0603009A mov.w 0x06030152,r3
    c.r[1] &= c.r[12];  // 0603009C and r12,r1
    st8(c.r[0] + c.r[2], c.r[1]);  // 0603009E mov.b r1,@(r0,r2)
    c.r[2] = c.r[11];  // 060300A0 mov r11,r2
    c.r[2] += 7;  // 060300A2 add #7,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060300A4 mov.b @r2,r1
    c.r[0] = 0x1u;  // 060300A6 mov #1,r0
    c.r[1] >>= 2;  // 060300A8 shlr2 r1
    c.r[1] >>= 2;  // 060300AA shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060300AC shlr r1
    c.r[1] >>= 2;  // 060300AE shlr2 r1
    c.r[1] &= c.r[0];  // 060300B0 and r0,r1
    c.r[0] = c.r[13];  // 060300B2 mov r13,r0
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 060300B4 mov.b @(r0,r3),r7
    c.r[12] = (uint32_t)(int16_t)ld16(0x06030154u);  // 060300B6 mov.w 0x06030154,r12
    c.r[7] &= c.r[12];  // 060300B8 and r12,r7
    c.r[7] |= c.r[1];  // 060300BA or r1,r7
    st8(c.r[0] + c.r[3], c.r[7]);  // 060300BC mov.b r7,@(r0,r3)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060300BE mov.b @r2,r1
    c.r[12] = 0x1Fu;  // 060300C0 mov #31,r12
    c.r[6] &= c.r[1];  // 060300C2 and r1,r6
    c.r[6] >>= 2;  // 060300C4 shlr2 r6
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603014Au);  // 060300C6 mov.w 0x0603014A,r1
    c.r[1] &= c.r[7];  // 060300C8 and r7,r1
    c.r[1] |= c.r[6];  // 060300CA or r6,r1
    st8(c.r[0] + c.r[3], c.r[1]);  // 060300CC mov.b r1,@(r0,r3)
    c.r[0] = 0x7u;  // 060300CE mov #7,r0
    c.r[1] &= c.r[12];  // 060300D0 and r12,r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x06030156u);  // 060300D2 mov.w 0x06030156,r12
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060300D4 mov.b @r2,r2
    c.r[6] = 0x40u;  // 060300D6 mov #64,r6
    c.r[2] &= c.r[0];  // 060300D8 and r0,r2
    c.r[2] <<= 2;  // 060300DA shll2 r2
    c.r[2] += c.r[2];  // 060300DC add r2,r2
    c.r[2] <<= 2;  // 060300DE shll2 r2
    c.r[1] |= c.r[2];  // 060300E0 or r2,r1
    c.r[0] = c.r[13];  // 060300E2 mov r13,r0
    st8(c.r[0] + c.r[3], c.r[1]);  // 060300E4 mov.b r1,@(r0,r3)
    c.r[1] = c.r[11];  // 060300E6 mov r11,r1
    c.r[1] += 8;  // 060300E8 add #8,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060300EA mov.b @r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x06030158u);  // 060300EC mov.w 0x06030158,r3
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 060300EE mov.b @(r0,r3),r7
    c.r[2] &= c.r[12];  // 060300F0 and r12,r2
    c.r[0] = 0x7Fu;  // 060300F2 mov #127,r0
    c.r[7] &= c.r[0];  // 060300F4 and r0,r7
    c.r[7] |= c.r[2];  // 060300F6 or r2,r7
    c.r[0] = c.r[13];  // 060300F8 mov r13,r0
    st8(c.r[0] + c.r[3], c.r[7]);  // 060300FA mov.b r7,@(r0,r3)
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060300FC mov.b @r1,r2
    c.r[12] = 0x8u;  // 060300FE mov #8,r12
    c.r[6] &= c.r[2];  // 06030100 and r2,r6
    c.r[2] = (uint32_t)(int16_t)ld16(0x0603015Au);  // 06030102 mov.w 0x0603015A,r2
    c.r[2] &= c.r[7];  // 06030104 and r7,r2
    c.r[2] |= c.r[6];  // 06030106 or r6,r2
    st8(c.r[0] + c.r[3], c.r[2]);  // 06030108 mov.b r2,@(r0,r3)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0603015Cu);  // 0603010A mov.w 0x0603015C,r0
    c.r[2] &= c.r[0];  // 0603010C and r0,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603010E mov.b @r1,r1
    c.r[0] = c.r[13];  // 06030110 mov r13,r0
    c.r[1] >>= 2;  // 06030112 shlr2 r1
    c.r[1] &= c.r[12];  // 06030114 and r12,r1
    c.r[2] |= c.r[1];  // 06030116 or r1,r2
    { const uint32_t x = c.r[8]; c.pr = 0x0603011Cu; st8(c.r[0] + c.r[3], c.r[2]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603011Cu) return; }  // 06030118 jsr @r8 ; mov.b r2,@(r0,r3)
    c.r[1] = c.r[0];  // 0603011C mov r0,r1
    c.r[5] = 0x0u;  // 0603011E mov #0,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06030124u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06030124u) return; }  // 06030120 jsr @r8 ; mov r1,r4
    c.r[2] = c.r[0];  // 06030124 mov r0,r2
    c.r[1] = c.r[13];  // 06030126 mov r13,r1
    c.r[1] += 4;  // 06030128 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603012A mov.b @r1,r1
    c.r[3] = 0x1u;  // 0603012C mov #1,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0603012E extu.b r1,r1
    c.r[1] >>= 2;  // 06030130 shlr2 r1
    c.r[1] >>= 2;  // 06030132 shlr2 r1
    c.t = (int32_t)c.r[3] > (int32_t)c.r[1]; goto L_0603018C;  // 06030134 bra 0x0603018C ; cmp/gt r1,r3
L_0603018C:
    { const bool k = c.t; c.r[7] = c.r[1]; if (k) { goto L_060301B4; } }  // 0603018C bt/s 0x060301B4 ; mov r1,r7
    c.r[6] = c.r[2];  // 06030190 mov r2,r6
    c.r[6] += 42;  // 06030192 add #42,r6
L_06030194:
    c.r[1] = c.r[6];  // 06030194 mov r6,r1
    c.r[1] -= 2;  // 06030196 add #-2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06030198 mov.b @r1,r2
    c.r[3] += 1;  // 0603019A add #1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0603019C extu.b r2,r2
    c.r[2] <<= 8;  // 0603019E shll8 r2
    c.r[1] = c.r[6];  // 060301A0 mov r6,r1
    c.r[1] -= 1;  // 060301A2 add #-1,r1
    c.r[6] += 2;  // 060301A4 add #2,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060301A6 mov.b @r1,r1
    c.t = (int32_t)c.r[3] > (int32_t)c.r[7];  // 060301A8 cmp/gt r7,r3
    c.r[1] = c.r[1] & 0xFFu;  // 060301AA extu.b r1,r1
    c.r[2] += c.r[1];  // 060301AC add r1,r2
    c.r[2] += c.r[9];  // 060301AE add r9,r2
    { const bool k = !c.t; c.r[9] = c.r[2] & 0xFFFFu; if (k) { SH2_POLL(c); goto L_06030194; } }  // 060301B0 bf/s 0x06030194 ; extu.w r2,r9
L_060301B4:
    c.r[8] = c.r[13];  // 060301B4 mov r13,r8
    c.r[8] += 28;  // 060301B6 add #28,r8
    c.r[1] = c.r[11];  // 060301B8 mov r11,r1
    c.r[1] += 34;  // 060301BA add #34,r1
    c.r[5] = c.r[9];  // 060301BC mov r9,r5
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060301BE mov.b @r1,r2
    c.r[4] = c.r[13];  // 060301C0 mov r13,r4
    c.r[2] = c.r[2] & 0xFFu;  // 060301C2 extu.b r2,r2
    c.r[1] = c.r[11];  // 060301C4 mov r11,r1
    c.r[1] += 35;  // 060301C6 add #35,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060301C8 mov.b @r1,r1
    c.r[2] <<= 8;  // 060301CA shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 060301CC extu.b r1,r1
    c.r[2] |= c.r[1];  // 060301CE or r1,r2
    c.r[1] = ld32(0x06030220u);  // 060301D0 mov.l 0x06030220,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060301D6u; st16(c.r[8], c.r[2]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060301D6u) return; }  // 060301D2 jsr @r1 ; mov.w r2,@r8
    c.r[0] = (uint32_t)(int16_t)ld16(0x0603021Au);  // 060301D6 mov.w 0x0603021A,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[13]);  // 060301D8 mov.b @(r0,r13),r1
    c.r[0] = c.r[1];  // 060301DA mov r1,r0
    c.r[0] >>= 2;  // 060301DC shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060301DE shlr r0
    c.r[0] &= 0x1u;  // 060301E0 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060301E2 tst r0,r0
    { const bool k = c.t; c.r[2] = 0x63u; if (k) { goto L_0603024A; } }  // 060301E4 bt/s 0x0603024A ; mov #99,r2
    c.r[1] = ld32(0x06030224u);  // 060301E8 mov.l 0x06030224,r1
    c.r[1] = ld32(c.r[1]);  // 060301EA mov.l @r1,r1
    c.r[1] += 18;  // 060301EC add #18,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060301EE mov.w @r1,r1
    c.r[1] <<= 16;  // 060301F0 shll16 r1
    c.r[1] <<= 2;  // 060301F2 shll2 r1
    c.r[1] += c.r[1];  // 060301F4 add r1,r1
    c.r[1] <<= 2;  // 060301F6 shll2 r1
    c.r[1] >>= 16;  // 060301F8 shlr16 r1
    c.r[1] <<= 2;  // 060301FA shll2 r1
    c.r[1] >>= 8;  // 060301FC shlr8 r1
    c.t = c.r[1] > c.r[2];  // 060301FE cmp/hi r2,r1
    { const bool k = !c.t; c.r[12] = ld32(c.r[14]); if (k) { goto L_0603022C; } }  // 06030200 bf/s 0x0603022C ; mov.l @r14,r12
    c.r[1] = ld32(0x06030228u);  // 06030204 mov.l 0x06030228,r1
    c.r[2] = ld32(c.r[1]);  // 06030206 mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 06030208 mov #30,r1
    c.macl = c.r[12] * c.r[1];  // 0603020A mul.l r1,r12
    c.r[3] = c.macl;  // 0603020C sts macl,r3
    c.r[3] += c.r[2];  // 0603020E add r2,r3
    c.r[3] += 24;  // 06030210 add #24,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603021Cu);  // 06030212 mov.w 0x0603021C,r1
    st16(c.r[8], c.r[1]);  // 06030214 mov.w r1,@r8
    st16(c.r[3], c.r[1]); goto L_0603024A;  // 06030216 bra 0x0603024A ; mov.w r1,@r3
L_0603022C:
    c.r[1] = ld32(0x0603048Cu);  // 0603022C mov.l 0x0603048C,r1
    c.r[2] = ld32(c.r[1]);  // 0603022E mov.l @r1,r2
    c.r[0] = ld32(c.r[14]);  // 06030230 mov.l @r14,r0
    c.r[1] = 0x1Eu;  // 06030232 mov #30,r1
    c.macl = c.r[0] * c.r[1];  // 06030234 mul.l r1,r0
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06030236 mov.w @r8,r3
    c.r[7] = c.macl;  // 06030238 sts macl,r7
    c.r[7] += c.r[2];  // 0603023A add r2,r7
    c.r[7] += 24;  // 0603023C add #24,r7
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[7]);  // 0603023E mov.w @r7,r1
    c.r[2] = c.r[3] & 0xFFFFu;  // 06030240 extu.w r3,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 06030242 extu.w r1,r1
    c.t = c.r[1] > c.r[2];  // 06030244 cmp/hi r2,r1
    if (!c.t) { goto L_0603024A; }  // 06030246 bf 0x0603024A
    st16(c.r[7], c.r[3]);  // 06030248 mov.w r3,@r7
L_0603024A:
    c.r[1] = ld32(0x0603048Cu);  // 0603024A mov.l 0x0603048C,r1
    c.r[2] = ld32(c.r[1]);  // 0603024C mov.l @r1,r2
    c.r[3] = c.r[13];  // 0603024E mov r13,r3
    c.r[12] = ld32(c.r[14]);  // 06030250 mov.l @r14,r12
    c.r[1] = 0x1Eu;  // 06030252 mov #30,r1
    c.macl = c.r[12] * c.r[1];  // 06030254 mul.l r1,r12
    c.r[3] += 24;  // 06030256 add #24,r3
    c.r[5] = c.r[11];  // 06030258 mov r11,r5
    c.r[1] = c.macl;  // 0603025A sts macl,r1
    c.r[1] += c.r[2];  // 0603025C add r2,r1
    c.r[1] += 24;  // 0603025E add #24,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06030260 mov.w @r1,r1
    st16(c.r[3], c.r[1]);  // 06030262 mov.w r1,@r3
    c.r[1] = ld32(0x06030490u);  // 06030264 mov.l 0x06030490,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603026Au; c.r[4] = c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603026Au) return; }  // 06030266 jsr @r1 ; mov r13,r4
    c.r[2] = c.r[11];  // 0603026A mov r11,r2
    c.r[2] += 8;  // 0603026C add #8,r2
    c.r[6] = (uint32_t)(int16_t)ld16(0x06030460u);  // 0603026E mov.w 0x06030460,r6
    c.r[0] = 0x4u;  // 06030270 mov #4,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06030272 mov.b @r2,r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x06030462u);  // 06030274 mov.w 0x06030462,r12
    c.r[3] = c.r[1];  // 06030276 mov r1,r3
    c.r[3] >>= 2;  // 06030278 shlr2 r3
    c.r[3] &= c.r[0];  // 0603027A and r0,r3
    c.r[0] = c.r[13];  // 0603027C mov r13,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 0603027E mov.b @(r0,r6),r1
    c.r[7] = (uint32_t)(int16_t)ld16(0x06030464u);  // 06030280 mov.w 0x06030464,r7
    c.r[1] &= c.r[12];  // 06030282 and r12,r1
    c.r[1] |= c.r[3];  // 06030284 or r3,r1
    st8(c.r[0] + c.r[6], c.r[1]);  // 06030286 mov.b r1,@(r0,r6)
    c.r[0] = 0xCu;  // 06030288 mov #12,r0
    c.r[12] = (uint32_t)(int16_t)ld16(0x06030466u);  // 0603028A mov.w 0x06030466,r12
    c.r[1] &= c.r[12];  // 0603028C and r12,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0603028E mov.b @r2,r3
    c.r[12] = 0x3u;  // 06030290 mov #3,r12
    c.r[3] &= c.r[0];  // 06030292 and r0,r3
    c.r[3] >>= 2;  // 06030294 shlr2 r3
    c.r[1] |= c.r[3];  // 06030296 or r3,r1
    c.r[0] = c.r[13];  // 06030298 mov r13,r0
    st8(c.r[0] + c.r[6], c.r[1]);  // 0603029A mov.b r1,@(r0,r6)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0603029C mov.b @r2,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x06030468u);  // 0603029E mov.w 0x06030468,r3
    c.r[1] &= c.r[12];  // 060302A0 and r12,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 060302A2 mov.b @(r0,r3),r2
    c.r[1] <<= 2;  // 060302A4 shll2 r1
    c.r[1] <<= 2;  // 060302A6 shll2 r1
    c.r[1] <<= 2;  // 060302A8 shll2 r1
    c.r[0] = 0x3Fu;  // 060302AA mov #63,r0
    c.r[2] &= c.r[0];  // 060302AC and r0,r2
    c.r[2] |= c.r[1];  // 060302AE or r1,r2
    c.r[0] = c.r[13];  // 060302B0 mov r13,r0
    st8(c.r[0] + c.r[3], c.r[2]);  // 060302B2 mov.b r2,@(r0,r3)
    c.r[2] = c.r[11];  // 060302B4 mov r11,r2
    c.r[2] += 9;  // 060302B6 add #9,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060302B8 mov.b @r2,r1
    c.r[12] = 0x20u;  // 060302BA mov #32,r12
    c.r[5] = c.r[1];  // 060302BC mov r1,r5
    c.r[5] >>= 2;  // 060302BE shlr2 r5
    c.r[5] &= c.r[12];  // 060302C0 and r12,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 060302C2 mov.b @(r0,r6),r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x0603046Au);  // 060302C4 mov.w 0x0603046A,r12
    c.r[7] &= c.r[1];  // 060302C6 and r1,r7
    c.r[7] |= c.r[5];  // 060302C8 or r5,r7
    st8(c.r[0] + c.r[6], c.r[7]);  // 060302CA mov.b r7,@(r0,r6)
    c.r[0] = 0x10u;  // 060302CC mov #16,r0
    c.r[7] &= c.r[12];  // 060302CE and r12,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060302D0 mov.b @r2,r1
    c.r[12] = 0x20u;  // 060302D2 mov #32,r12
    c.r[1] >>= 2;  // 060302D4 shlr2 r1
    c.r[1] &= c.r[0];  // 060302D6 and r0,r1
    c.r[7] |= c.r[1];  // 060302D8 or r1,r7
    c.r[0] = c.r[13];  // 060302DA mov r13,r0
    st8(c.r[0] + c.r[6], c.r[7]);  // 060302DC mov.b r7,@(r0,r6)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060302DE mov.b @r2,r1
    c.r[6] = 0x10u;  // 060302E0 mov #16,r6
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 060302E2 mov.b @(r0,r3),r7
    c.r[1] &= c.r[12];  // 060302E4 and r12,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06030464u);  // 060302E6 mov.w 0x06030464,r0
    c.r[7] &= c.r[0];  // 060302E8 and r0,r7
    c.r[7] |= c.r[1];  // 060302EA or r1,r7
    c.r[0] = c.r[13];  // 060302EC mov r13,r0
    st8(c.r[0] + c.r[3], c.r[7]);  // 060302EE mov.b r7,@(r0,r3)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060302F0 mov.b @r2,r1
    c.r[12] = 0x8u;  // 060302F2 mov #8,r12
    c.r[6] &= c.r[1];  // 060302F4 and r1,r6
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603046Au);  // 060302F6 mov.w 0x0603046A,r1
    c.r[1] &= c.r[7];  // 060302F8 and r7,r1
    c.r[1] |= c.r[6];  // 060302FA or r6,r1
    st8(c.r[0] + c.r[3], c.r[1]);  // 060302FC mov.b r1,@(r0,r3)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0603046Cu);  // 060302FE mov.w 0x0603046C,r0
    c.r[1] &= c.r[0];  // 06030300 and r0,r1
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06030302 mov.b @r2,r7
    c.r[0] = c.r[13];  // 06030304 mov r13,r0
    c.r[7] &= c.r[12];  // 06030306 and r12,r7
    c.r[1] |= c.r[7];  // 06030308 or r7,r1
    st8(c.r[0] + c.r[3], c.r[1]);  // 0603030A mov.b r1,@(r0,r3)
    c.r[12] = 0x7u;  // 0603030C mov #7,r12
    c.r[0] = (uint32_t)(int16_t)ld16(0x0603046Eu);  // 0603030E mov.w 0x0603046E,r0
    c.r[1] &= c.r[0];  // 06030310 and r0,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06030312 mov.b @r2,r2
    c.r[0] = c.r[13];  // 06030314 mov r13,r0
    c.r[2] &= c.r[12];  // 06030316 and r12,r2
    c.r[1] |= c.r[2];  // 06030318 or r2,r1
    st8(c.r[0] + c.r[3], c.r[1]);  // 0603031A mov.b r1,@(r0,r3)
    c.r[2] = c.r[11];  // 0603031C mov r11,r2
    c.r[2] += 10;  // 0603031E add #10,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x06030470u);  // 06030320 mov.w 0x06030470,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06030322 mov.b @r2,r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x06030472u);  // 06030324 mov.w 0x06030472,r12
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06030326 mov.b @(r0,r3),r7
    c.r[1] += c.r[1];  // 06030328 add r1,r1
    c.r[1] &= c.r[12];  // 0603032A and r12,r1
    c.r[0] = 0x7Fu;  // 0603032C mov #127,r0
    c.r[7] &= c.r[0];  // 0603032E and r0,r7
    c.r[7] |= c.r[1];  // 06030330 or r1,r7
    c.r[0] = c.r[13];  // 06030332 mov r13,r0
    st8(c.r[0] + c.r[3], c.r[7]);  // 06030334 mov.b r7,@(r0,r3)
    c.r[12] = 0x40u;  // 06030336 mov #64,r12
    c.r[0] = (uint32_t)(int16_t)ld16(0x06030474u);  // 06030338 mov.w 0x06030474,r0
    c.r[7] &= c.r[0];  // 0603033A and r0,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0603033C mov.b @r2,r1
    c.r[0] = c.r[13];  // 0603033E mov r13,r0
    c.r[1] += c.r[1];  // 06030340 add r1,r1
    c.r[1] &= c.r[12];  // 06030342 and r12,r1
    c.r[7] |= c.r[1];  // 06030344 or r1,r7
    st8(c.r[0] + c.r[3], c.r[7]);  // 06030346 mov.b r7,@(r0,r3)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06030348 mov.b @r2,r1
    c.r[12] = 0x20u;  // 0603034A mov #32,r12
    c.r[6] = c.r[1];  // 0603034C mov r1,r6
    c.r[6] += c.r[6];  // 0603034E add r6,r6
    c.r[6] &= c.r[12];  // 06030350 and r12,r6
    c.r[1] = (uint32_t)(int16_t)ld16(0x06030464u);  // 06030352 mov.w 0x06030464,r1
    c.r[1] &= c.r[7];  // 06030354 and r7,r1
    c.r[1] |= c.r[6];  // 06030356 or r6,r1
    st8(c.r[0] + c.r[3], c.r[1]);  // 06030358 mov.b r1,@(r0,r3)
    c.r[0] = 0xCu;  // 0603035A mov #12,r0
    c.r[12] = (uint32_t)(int16_t)ld16(0x06030476u);  // 0603035C mov.w 0x06030476,r12
    c.r[1] &= c.r[12];  // 0603035E and r12,r1
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06030360 mov.b @r2,r7
    c.r[12] = 0x3u;  // 06030362 mov #3,r12
    c.r[7] &= c.r[0];  // 06030364 and r0,r7
    c.r[7] += c.r[7];  // 06030366 add r7,r7
    c.r[1] |= c.r[7];  // 06030368 or r7,r1
    c.r[0] = c.r[13];  // 0603036A mov r13,r0
    st8(c.r[0] + c.r[3], c.r[1]);  // 0603036C mov.b r1,@(r0,r3)
    c.r[0] = (uint32_t)(int16_t)ld16(0x06030478u);  // 0603036E mov.w 0x06030478,r0
    c.r[1] &= c.r[0];  // 06030370 and r0,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06030372 mov.b @r2,r2
    c.r[0] = c.r[13];  // 06030374 mov r13,r0
    c.r[2] &= c.r[12];  // 06030376 and r12,r2
    c.r[2] += c.r[2];  // 06030378 add r2,r2
    c.r[1] |= c.r[2];  // 0603037A or r2,r1
    st8(c.r[0] + c.r[3], c.r[1]);  // 0603037C mov.b r1,@(r0,r3)
    c.r[1] = c.r[11];  // 0603037E mov r11,r1
    c.r[1] += 11;  // 06030380 add #11,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06030382 mov.b @r1,r2
    c.r[1] = c.r[11];  // 06030384 mov r11,r1
    c.r[1] += 12;  // 06030386 add #12,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06030388 mov.b @r1,r1
    c.r[2] <<= 16;  // 0603038A shll16 r2
    c.r[2] <<= 8;  // 0603038C shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603038E extu.b r1,r1
    c.r[1] <<= 16;  // 06030390 shll16 r1
    c.r[2] |= c.r[1];  // 06030392 or r1,r2
    c.r[1] = c.r[11];  // 06030394 mov r11,r1
    c.r[1] += 13;  // 06030396 add #13,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06030398 mov.b @r1,r1
    c.r[8] = 0x0u;  // 0603039A mov #0,r8
    c.r[1] = c.r[1] & 0xFFu;  // 0603039C extu.b r1,r1
    c.r[1] <<= 8;  // 0603039E shll8 r1
    c.r[2] |= c.r[1];  // 060303A0 or r1,r2
    c.r[1] = c.r[11];  // 060303A2 mov r11,r1
    c.r[1] += 14;  // 060303A4 add #14,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060303A6 mov.b @r1,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x0603047Au);  // 060303A8 mov.w 0x0603047A,r3
    c.r[1] = c.r[1] & 0xFFu;  // 060303AA extu.b r1,r1
    c.r[2] |= c.r[1];  // 060303AC or r1,r2
    st32(c.r[0] + c.r[3], c.r[2]);  // 060303AE mov.l r2,@(r0,r3)
    c.r[1] = c.r[11];  // 060303B0 mov r11,r1
    c.r[1] += 15;  // 060303B2 add #15,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060303B4 mov.b @r1,r2
    c.r[1] = c.r[11];  // 060303B6 mov r11,r1
    c.r[1] += 16;  // 060303B8 add #16,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060303BA mov.b @r1,r1
    c.r[2] <<= 16;  // 060303BC shll16 r2
    c.r[2] <<= 8;  // 060303BE shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 060303C0 extu.b r1,r1
    c.r[1] <<= 16;  // 060303C2 shll16 r1
    c.r[2] |= c.r[1];  // 060303C4 or r1,r2
    c.r[1] = c.r[11];  // 060303C6 mov r11,r1
    c.r[1] += 17;  // 060303C8 add #17,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060303CA mov.b @r1,r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x0603047Cu);  // 060303CC mov.w 0x0603047C,r12
    c.r[1] = c.r[1] & 0xFFu;  // 060303CE extu.b r1,r1
    c.r[1] <<= 8;  // 060303D0 shll8 r1
    c.r[2] |= c.r[1];  // 060303D2 or r1,r2
    c.r[1] = c.r[11];  // 060303D4 mov r11,r1
    c.r[1] += 18;  // 060303D6 add #18,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060303D8 mov.b @r1,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x0603047Eu);  // 060303DA mov.w 0x0603047E,r3
    c.r[1] = c.r[1] & 0xFFu;  // 060303DC extu.b r1,r1
    c.r[2] |= c.r[1];  // 060303DE or r1,r2
    st32(c.r[0] + c.r[3], c.r[2]);  // 060303E0 mov.l r2,@(r0,r3)
    c.r[1] = c.r[11];  // 060303E2 mov r11,r1
    c.r[1] += 19;  // 060303E4 add #19,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060303E6 mov.b @r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06030480u);  // 060303E8 mov.w 0x06030480,r2
    st8(c.r[0] + c.r[2], c.r[1]);  // 060303EA mov.b r1,@(r0,r2)
    c.r[1] = c.r[11];  // 060303EC mov r11,r1
    c.r[1] += 20;  // 060303EE add #20,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060303F0 mov.b @r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x06030482u);  // 060303F2 mov.w 0x06030482,r3
    c.r[2] = c.r[2] & 0xFFu;  // 060303F4 extu.b r2,r2
    c.r[1] = c.r[11];  // 060303F6 mov r11,r1
    c.r[1] += 21;  // 060303F8 add #21,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060303FA mov.b @r1,r1
    c.r[2] <<= 8;  // 060303FC shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 060303FE extu.b r1,r1
    c.r[2] |= c.r[1];  // 06030400 or r1,r2
    st16(c.r[0] + c.r[3], c.r[2]);  // 06030402 mov.w r2,@(r0,r3)
    c.r[1] = c.r[11];  // 06030404 mov r11,r1
    c.r[1] += 22;  // 06030406 add #22,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06030408 mov.b @r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x06030484u);  // 0603040A mov.w 0x06030484,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0603040C extu.b r2,r2
    c.r[1] = c.r[11];  // 0603040E mov r11,r1
    c.r[1] += 23;  // 06030410 add #23,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06030412 mov.b @r1,r1
    c.r[2] <<= 8;  // 06030414 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06030416 extu.b r1,r1
    c.r[2] |= c.r[1];  // 06030418 or r1,r2
    st16(c.r[0] + c.r[3], c.r[2]);  // 0603041A mov.w r2,@(r0,r3)
    c.r[1] = c.r[11];  // 0603041C mov r11,r1
    c.r[1] += 25;  // 0603041E add #25,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06030420 mov.b @r1,r3
    c.r[2] = (uint32_t)(int16_t)ld16(0x06030486u);  // 06030422 mov.w 0x06030486,r2
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06030424 mov.b @(r0,r2),r7
    c.r[3] &= c.r[12];  // 06030426 and r12,r3
    c.r[0] = 0x3Fu;  // 06030428 mov #63,r0
    c.r[7] &= c.r[0];  // 0603042A and r0,r7
    c.r[7] |= c.r[3];  // 0603042C or r3,r7
    c.r[0] = c.r[13];  // 0603042E mov r13,r0
    st8(c.r[0] + c.r[2], c.r[7]);  // 06030430 mov.b r7,@(r0,r2)
    c.r[3] = 0x30u;  // 06030432 mov #48,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06030434 mov.b @r1,r1
    c.r[12] = 0x7u;  // 06030436 mov #7,r12
    c.r[3] &= c.r[1];  // 06030438 and r1,r3
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 0603043A shlr r3
    c.r[3] += 8;  // 0603043C add #8,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x06030488u);  // 0603043E mov.w 0x06030488,r1
    c.r[1] &= c.r[7];  // 06030440 and r7,r1
    c.r[1] |= c.r[3];  // 06030442 or r3,r1
    st8(c.r[0] + c.r[2], c.r[1]);  // 06030444 mov.b r1,@(r0,r2)
    c.r[1] >>= 2;  // 06030446 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06030448 shlr r1
    c.r[1] &= c.r[12];  // 0603044A and r12,r1
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 0603044C cmp/ge r1,r8
    { const bool k = c.t; c.r[9] = 0x0u; if (k) { goto L_060304CA; } }  // 0603044E bt/s 0x060304CA ; mov #0,r9
    c.r[10] = ld32(0x06030494u);  // 06030452 mov.l 0x06030494,r10
    c.r[3] = c.r[13];  // 06030454 mov r13,r3
L_06030456:
    c.r[1] = ld32(0x0603048Cu);  // 06030456 mov.l 0x0603048C,r1
    c.r[2] = ld32(c.r[1]);  // 06030458 mov.l @r1,r2
    c.r[3] += c.r[8];  // 0603045A add r8,r3
    c.r[0] = ld32(c.r[14]); goto L_06030498;  // 0603045C bra 0x06030498 ; mov.l @r14,r0
L_06030498:
    c.r[1] = 0x1Eu;  // 06030498 mov #30,r1
    c.macl = c.r[0] * c.r[1];  // 0603049A mul.l r1,r0
    c.r[3] += 16;  // 0603049C add #16,r3
    c.r[5] = c.r[8];  // 0603049E mov r8,r5
    c.r[1] = c.macl;  // 060304A0 sts macl,r1
    c.r[1] += c.r[2];  // 060304A2 add r2,r1
    c.r[1] += c.r[8];  // 060304A4 add r8,r1
    c.r[1] += 17;  // 060304A6 add #17,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060304A8 mov.b @r1,r1
    c.r[4] = c.r[13];  // 060304AA mov r13,r4
    { const uint32_t x = c.r[10]; c.pr = 0x060304B0u; st8(c.r[3], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060304B0u) return; }  // 060304AC jsr @r10 ; mov.b r1,@r3
    c.r[1] = c.r[0];  // 060304B0 mov r0,r1
    c.r[9] += c.r[1];  // 060304B2 add r1,r9
    c.r[8] += 1;  // 060304B4 add #1,r8
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603055Cu);  // 060304B6 mov.w 0x0603055C,r1
    c.r[0] = c.r[13];  // 060304B8 mov r13,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060304BA mov.b @(r0,r1),r1
    c.r[12] = 0x7u;  // 060304BC mov #7,r12
    c.r[1] >>= 2;  // 060304BE shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060304C0 shlr r1
    c.r[1] &= c.r[12];  // 060304C2 and r12,r1
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 060304C4 cmp/ge r1,r8
    { const bool k = !c.t; c.r[3] = c.r[13]; if (k) { SH2_POLL(c); goto L_06030456; } }  // 060304C6 bf/s 0x06030456 ; mov r13,r3
L_060304CA:
    c.r[11] += 38;  // 060304CA add #38,r11
    c.r[5] = c.r[11];  // 060304CC mov r11,r5
    c.r[0] = ld32(0x06030560u);  // 060304CE mov.l 0x06030560,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060304D4u; c.r[4] = c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060304D4u) return; }  // 060304D0 jsr @r0 ; mov r13,r4
    c.r[11] = c.r[0];  // 060304D4 mov r0,r11
    c.r[0] = ld32(c.r[14] + 4);  // 060304D6 mov.l @(4,r14),r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603055Eu);  // 060304D8 mov.w 0x0603055E,r1
    c.t = c.r[0] == c.r[1];  // 060304DA cmp/eq r1,r0
    { const bool k = c.t; c.r[8] = c.r[0]; if (k) { goto L_06030546; } }  // 060304DC bt/s 0x06030546 ; mov r0,r8
    c.r[10] = ld32(0x06030564u);  // 060304E0 mov.l 0x06030564,r10
    c.r[1] = ld32(c.r[10]);  // 060304E2 mov.l @r10,r1
    c.r[8] <<= 2;  // 060304E4 shll2 r8
    c.r[8] <<= 2;  // 060304E6 shll2 r8
    c.r[1] += c.r[8];  // 060304E8 add r8,r1
    c.r[1] += 10;  // 060304EA add #10,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060304EC mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060304EE extu.b r1,r1
    c.r[1] >>= 2;  // 060304F0 shlr2 r1
    c.r[1] >>= 2;  // 060304F2 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060304F4 shlr r1
    c.r[1] >>= 2;  // 060304F6 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060304F8 tst r1,r1
    { const bool k = c.t; c.r[5] = 0x3u; if (k) { goto L_06030504; } }  // 060304FA bt/s 0x06030504 ; mov #3,r5
    c.r[1] = ld32(0x06030568u);  // 060304FE mov.l 0x06030568,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06030504u; c.r[4] = c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06030504u) return; }  // 06030500 jsr @r1 ; mov r13,r4
L_06030504:
    c.r[1] = ld32(c.r[10]);  // 06030504 mov.l @r10,r1
    c.r[8] += c.r[1];  // 06030506 add r1,r8
    c.r[8] += 11;  // 06030508 add #11,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0603050A mov.b @r8,r1
    c.r[0] = c.r[1];  // 0603050C mov r1,r0
    c.r[0] >>= 2;  // 0603050E shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06030510 shlr r0
    c.r[0] >>= 2;  // 06030512 shlr2 r0
    c.r[0] &= 0x1u;  // 06030514 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06030516 tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[13]; if (k) { goto L_06030528; } }  // 06030518 bt/s 0x06030528 ; mov r13,r1
    c.r[1] += 30;  // 0603051C add #30,r1
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0603051E mov.w @r1,r5
    c.r[4] = c.r[13];  // 06030520 mov r13,r4
    c.r[1] = ld32(0x0603056Cu);  // 06030522 mov.l 0x0603056C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06030528u; c.r[5] = c.r[5] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06030528u) return; }  // 06030524 jsr @r1 ; extu.w r5,r5
L_06030528:
    c.r[0] = ld32(0x06030570u);  // 06030528 mov.l 0x06030570,r0
    c.r[7] = 0x0u;  // 0603052A mov #0,r7
    c.r[6] = ld32(c.r[14] + 4);  // 0603052C mov.l @(4,r14),r6
    c.r[5] = c.r[11];  // 0603052E mov r11,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06030534u; c.r[4] = c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06030534u) return; }  // 06030530 jsr @r0 ; mov r13,r4
    c.r[8] = 0x0u;  // 06030534 mov #0,r8
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[9];  // 06030536 cmp/ge r9,r8
    if (c.t) { goto L_06030546; }  // 06030538 bt 0x06030546
    c.r[10] = ld32(0x06030574u);  // 0603053A mov.l 0x06030574,r10
L_0603053C:
    { const uint32_t x = c.r[10]; c.pr = 0x06030540u; c.r[4] = c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06030540u) return; }  // 0603053C jsr @r10 ; mov r13,r4
    c.r[8] += 1;  // 06030540 add #1,r8
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[9];  // 06030542 cmp/ge r9,r8
    if (!c.t) { SH2_POLL(c); goto L_0603053C; }  // 06030544 bf 0x0603053C
L_06030546:
    c.r[14] += 12;  // 06030546 add #12,r14
    c.r[15] = c.r[14];  // 06030548 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603054A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603054C mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0603054E mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06030550 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06030552 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06030554 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06030556 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06030558 rts ; mov.l @r15+,r8
}

void f_06030578(SH2Context& c) {
    ran[685] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06030578 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603057A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0603057C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0603057E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06030580 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06030582 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06030584 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06030586 sts.l pr,@-r15
    c.r[15] -= 4;  // 06030588 add #-4,r15
    c.r[14] = c.r[15];  // 0603058A mov r15,r14
    c.r[8] = c.r[4];  // 0603058C mov r4,r8
    c.r[10] = 0x0u;  // 0603058E mov #0,r10
    c.r[13] = 0x0u;  // 06030590 mov #0,r13
    c.r[11] = 0x0u;  // 06030592 mov #0,r11
    c.r[12] = 0x0u;  // 06030594 mov #0,r12
    c.r[9] = 0x0u;  // 06030596 mov #0,r9
    c.r[7] = 0x0u;  // 06030598 mov #0,r7
    st32(c.r[14], c.r[7]);  // 0603059A mov.l r7,@r14
    c.r[5] += c.r[8];  // 0603059C add r8,r5
    c.r[5] += 16;  // 0603059E add #16,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[5]);  // 060305A0 mov.b @r5,r1
    c.r[2] = c.r[1] & 0xFFu;  // 060305A2 extu.b r1,r2
    c.r[1] = 0x16u;  // 060305A4 mov #22,r1
    c.t = c.r[2] > c.r[1];  // 060305A6 cmp/hi r1,r2
    { const bool k = c.t; c.r[3] = 0x0u; if (k) { goto L_06030656; } }  // 060305A8 bt/s 0x06030656 ; mov #0,r3
    c.r[1] = c.r[2];  // 060305AC mov r2,r1
    c.r[1] += c.r[1];  // 060305AE add r1,r1
    c.r[0] = 0x060305BCu;  // 060305B0 mova 0x060305BC,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 060305B2 mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 060305B4 add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x06030656u: goto L_06030656; case 0x060305EAu: goto L_060305EA; case 0x060305EEu: goto L_060305EE; case 0x060305F2u: goto L_060305F2; case 0x060305F8u: goto L_060305F8; case 0x060305FEu: goto L_060305FE; case 0x06030604u: goto L_06030604; case 0x0603060Au: goto L_0603060A; case 0x06030624u: goto L_06030624; case 0x0603062Au: goto L_0603062A; case 0x06030632u: goto L_06030632; case 0x0603063Au: goto L_0603063A; case 0x06030642u: goto L_06030642; case 0x0603064Au: goto L_0603064A; case 0x0603065Au: goto L_0603065A; case 0x06030652u: goto L_06030652; default: sh2_call(c, x); return; } }  // 060305B6 jmp @r0 ; nop
L_060305EA:
    c.r[3] = 0x1u; goto L_0603065A;  // 060305EA bra 0x0603065A ; mov #1,r3
L_060305EE:
    c.r[3] = 0x2u; goto L_0603065A;  // 060305EE bra 0x0603065A ; mov #2,r3
L_060305F2:
    c.r[12] = 0x1Eu;  // 060305F2 mov #30,r12
    c.r[9] = 0xFu; goto L_0603065A;  // 060305F4 bra 0x0603065A ; mov #15,r9
L_060305F8:
    c.r[12] = 0xFu;  // 060305F8 mov #15,r12
    c.r[9] = 0xAu; goto L_0603065A;  // 060305FA bra 0x0603065A ; mov #10,r9
L_060305FE:
    c.r[3] = 0x1u;  // 060305FE mov #1,r3
    c.r[9] = 0x5u; goto L_0603065A;  // 06030600 bra 0x0603065A ; mov #5,r9
L_06030604:
    c.r[12] = 0x14u;  // 06030604 mov #20,r12
    c.r[9] = 0x5u; goto L_0603065A;  // 06030606 bra 0x0603065A ; mov #5,r9
L_0603060A:
    c.r[1] = c.r[8];  // 0603060A mov r8,r1
    c.r[1] += 38;  // 0603060C add #38,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603060E mov.b @r1,r0
    c.r[0] &= 0xC7u;  // 06030610 and #199,r0
    c.r[0] |= 0x20u;  // 06030612 or #32,r0
    st8(c.r[1], c.r[0]);  // 06030614 mov.b r0,@r1
    c.r[1] = c.r[8];  // 06030616 mov r8,r1
    c.r[1] += 37;  // 06030618 add #37,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603061A mov.b @r1,r0
    c.r[0] &= 0xFu;  // 0603061C and #15,r0
    c.r[0] |= 0x60u;  // 0603061E or #96,r0
    st8(c.r[1], c.r[0]); goto L_0603065A;  // 06030620 bra 0x0603065A ; mov.b r0,@r1
L_06030624:
    c.r[7] = 0x1u;  // 06030624 mov #1,r7
    st32(c.r[14], c.r[7]); goto L_0603065A;  // 06030626 bra 0x0603065A ; mov.l r7,@r14
L_0603062A:
    c.r[11] = (uint32_t)(int16_t)ld16(0x060306A2u);  // 0603062A mov.w 0x060306A2,r11
    c.r[10] = (uint32_t)(int16_t)ld16(0x060306A4u);  // 0603062C mov.w 0x060306A4,r10
    goto L_0603065A;  // 0603062E bra 0x0603065A ; nop
L_06030632:
    c.r[11] = (uint32_t)(int16_t)ld16(0x060306A6u);  // 06030632 mov.w 0x060306A6,r11
    c.r[10] = (uint32_t)(int16_t)ld16(0x060306A8u);  // 06030634 mov.w 0x060306A8,r10
    goto L_0603065A;  // 06030636 bra 0x0603065A ; nop
L_0603063A:
    c.r[3] = 0x2u;  // 0603063A mov #2,r3
    c.r[9] = 0x14u;  // 0603063C mov #20,r9
    c.r[12] = 0x1Eu; goto L_0603065A;  // 0603063E bra 0x0603065A ; mov #30,r12
L_06030642:
    c.r[11] = (uint32_t)(int16_t)ld16(0x060306AAu);  // 06030642 mov.w 0x060306AA,r11
    c.r[10] = (uint32_t)(int16_t)ld16(0x060306ACu);  // 06030644 mov.w 0x060306AC,r10
    goto L_0603065A;  // 06030646 bra 0x0603065A ; nop
L_0603064A:
    c.r[11] = (uint32_t)(int16_t)ld16(0x060306AEu);  // 0603064A mov.w 0x060306AE,r11
    c.r[10] = (uint32_t)(int16_t)ld16(0x060306B0u);  // 0603064C mov.w 0x060306B0,r10
    goto L_0603065A;  // 0603064E bra 0x0603065A ; nop
L_06030652:
    c.r[13] = 0x64u; goto L_0603065A;  // 06030652 bra 0x0603065A ; mov #100,r13
L_06030656:
    c.r[0] = 0x0u; goto L_0603068C;  // 06030656 bra 0x0603068C ; mov #0,r0
L_0603065A:
    c.r[1] = ld32(0x060306B4u);  // 0603065A mov.l 0x060306B4,r1
    c.r[5] = c.r[3];  // 0603065C mov r3,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06030662u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06030662u) return; }  // 0603065E jsr @r1 ; mov r8,r4
    c.r[1] = ld32(0x060306B8u);  // 06030662 mov.l 0x060306B8,r1
    c.r[5] = c.r[9];  // 06030664 mov r9,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0603066Au; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603066Au) return; }  // 06030666 jsr @r1 ; mov r8,r4
    c.r[1] = ld32(0x060306BCu);  // 0603066A mov.l 0x060306BC,r1
    c.r[5] = c.r[10];  // 0603066C mov r10,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06030672u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06030672u) return; }  // 0603066E jsr @r1 ; mov r8,r4
    c.r[1] = ld32(0x060306C0u);  // 06030672 mov.l 0x060306C0,r1
    c.r[5] = c.r[13];  // 06030674 mov r13,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0603067Au; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603067Au) return; }  // 06030676 jsr @r1 ; mov r8,r4
    c.r[1] = ld32(0x060306C4u);  // 0603067A mov.l 0x060306C4,r1
    c.r[5] = c.r[11];  // 0603067C mov r11,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06030682u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06030682u) return; }  // 0603067E jsr @r1 ; mov r8,r4
    c.r[1] = ld32(0x060306C8u);  // 06030682 mov.l 0x060306C8,r1
    c.r[5] = c.r[12];  // 06030684 mov r12,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0603068Au; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603068Au) return; }  // 06030686 jsr @r1 ; mov r8,r4
    c.r[0] = ld32(c.r[14]);  // 0603068A mov.l @r14,r0
L_0603068C:
    c.r[14] += 4;  // 0603068C add #4,r14
    c.r[15] = c.r[14];  // 0603068E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06030690 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06030692 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06030694 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06030696 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06030698 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0603069A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0603069C mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603069E rts ; mov.l @r15+,r8
}

void f_060306CC(SH2Context& c) {
    ran[686] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060306CC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060306CE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060306D0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060306D2 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060306D4 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060306D6 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060306D8 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060306DA mov r15,r14
    c.r[11] = c.r[4];  // 060306DC mov r4,r11
    c.r[4] = ld32(0x0603073Cu);  // 060306DE mov.l 0x0603073C,r4
    c.r[9] = ld32(0x06030740u);  // 060306E0 mov.l 0x06030740,r9
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[11]);  // 060306E2 mov.w @r11,r8
    c.r[5] = 0x1Bu;  // 060306E4 mov #27,r5
    { const uint32_t x = c.r[9]; c.pr = 0x060306EAu; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060306EAu) return; }  // 060306E6 jsr @r9 ; extu.w r8,r8
    c.r[5] = c.r[8];  // 060306EA mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x060306F0u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060306F0u) return; }  // 060306EC jsr @r9 ; mov r0,r4
    c.r[2] = c.r[0];  // 060306F0 mov r0,r2
    c.r[2] += 46;  // 060306F2 add #46,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060306F4 mov.b @r2,r1
    c.r[9] = 0x0u;  // 060306F6 mov #0,r9
    c.r[10] = c.r[1] & 0xFFu;  // 060306F8 extu.b r1,r10
    c.r[2] = c.r[0];  // 060306FA mov r0,r2
    c.r[1] = c.r[10];  // 060306FC mov r10,r1
    c.r[1] <<= 2;  // 060306FE shll2 r1
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[1];  // 06030700 cmp/ge r1,r9
    { const bool k = c.t; c.r[2] += 48; if (k) { goto L_0603072A; } }  // 06030702 bt/s 0x0603072A ; add #48,r2
    c.r[12] = ld32(0x06030744u);  // 06030706 mov.l 0x06030744,r12
    c.r[8] = c.r[2];  // 06030708 mov r2,r8
L_0603070A:
    c.r[1] = c.r[8];  // 0603070A mov r8,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0603070C mov.b @r1+,r2
    c.r[6] = 0x1u;  // 0603070E mov #1,r6
    c.r[4] = c.r[11];  // 06030710 mov r11,r4
    c.r[0] = c.r[2];  // 06030712 mov r2,r0
    c.r[0] >>= 2;  // 06030714 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06030716 shlr r0
    c.r[0] &= 0xFu;  // 06030718 and #15,r0
    { const uint32_t x = c.r[12]; c.pr = 0x0603071Eu; c.r[5] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603071Eu) return; }  // 0603071A jsr @r12 ; mov r0,r5
    c.r[9] += 4;  // 0603071E add #4,r9
    c.r[1] = c.r[10];  // 06030720 mov r10,r1
    c.r[1] <<= 2;  // 06030722 shll2 r1
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[1];  // 06030724 cmp/ge r1,r9
    { const bool k = !c.t; c.r[8] += 4; if (k) { SH2_POLL(c); goto L_0603070A; } }  // 06030726 bf/s 0x0603070A ; add #4,r8
L_0603072A:
    c.r[15] = c.r[14];  // 0603072A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603072C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603072E mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06030730 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06030732 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06030734 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06030736 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06030738 rts ; mov.l @r15+,r8
}

void f_06030748(SH2Context& c) {
    ran[687] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06030748 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603074A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603074C sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x060307BCu);  // 0603074E mov.w 0x060307BC,r3
    c.r[15] += c.r[3];  // 06030750 add r3,r15
    c.r[14] = c.r[15];  // 06030752 mov r15,r14
    c.r[8] = c.r[4] & 0xFFu;  // 06030754 extu.b r4,r8
    c.r[1] = ld32(0x060307C0u);  // 06030756 mov.l 0x060307C0,r1
    c.r[6] = 0x0u;  // 06030758 mov #0,r6
    c.r[5] = c.r[8];  // 0603075A mov r8,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06030760u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06030760u) return; }  // 0603075C jsr @r1 ; mov r14,r4
    c.r[7] = 0x0u;  // 06030760 mov #0,r7
    c.r[4] = ld32(0x060307C4u);  // 06030762 mov.l 0x060307C4,r4
    c.r[5] = 0x1Eu;  // 06030764 mov #30,r5
    c.r[6] = 0x0u;  // 06030766 mov #0,r6
L_06030768:
    c.r[1] = c.r[14];  // 06030768 mov r14,r1
    c.r[1] += 44;  // 0603076A add #44,r1
    c.r[0] = c.r[1];  // 0603076C mov r1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[6]);  // 0603076E mov.w @(r0,r6),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06030770 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06030772 tst r1,r1
    { const bool k = !c.t; c.r[3] = c.r[7]; if (k) { goto L_060307A4; } }  // 06030774 bf/s 0x060307A4 ; mov r7,r3
    c.t = c.r[3] & 1; c.r[3] = (uint32_t)((int32_t)c.r[3] >> 1);  // 06030778 shar r3
    c.r[1] = 0x1u;  // 0603077A mov #1,r1
    c.r[1] &= c.r[7];  // 0603077C and r7,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603077E tst r1,r1
    { const bool k = !c.t; c.macl = c.r[8] * c.r[5]; if (k) { goto L_06030794; } }  // 06030780 bf/s 0x06030794 ; mul.l r5,r8
    c.r[1] = ld32(c.r[4]);  // 06030784 mov.l @r4,r1
    c.r[2] = c.macl;  // 06030786 sts macl,r2
    c.r[2] += c.r[1];  // 06030788 add r1,r2
    c.r[2] += c.r[3];  // 0603078A add r3,r2
    c.r[2] += 7;  // 0603078C add #7,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0603078E mov.b @r2,r0
    c.r[0] &= 0xFu; goto L_060307A2;  // 06030790 bra 0x060307A2 ; and #15,r0
L_06030794:
    c.r[1] = ld32(c.r[4]);  // 06030794 mov.l @r4,r1
    c.r[2] = c.macl;  // 06030796 sts macl,r2
    c.r[2] += c.r[1];  // 06030798 add r1,r2
    c.r[2] += c.r[3];  // 0603079A add r3,r2
    c.r[2] += 7;  // 0603079C add #7,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0603079E mov.b @r2,r0
    c.r[0] &= 0xF0u;  // 060307A0 and #240,r0
L_060307A2:
    st8(c.r[2], c.r[0]);  // 060307A2 mov.b r0,@r2
L_060307A4:
    c.r[7] += 1;  // 060307A4 add #1,r7
    c.r[1] = 0xFu;  // 060307A6 mov #15,r1
    c.t = (int32_t)c.r[7] > (int32_t)c.r[1];  // 060307A8 cmp/gt r1,r7
    { const bool k = !c.t; c.r[6] += 20; if (k) { SH2_POLL(c); goto L_06030768; } }  // 060307AA bf/s 0x06030768 ; add #20,r6
    c.r[3] = (uint32_t)(int16_t)ld16(0x060307BEu);  // 060307AE mov.w 0x060307BE,r3
    c.r[14] += c.r[3];  // 060307B0 add r3,r14
    c.r[15] = c.r[14];  // 060307B2 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060307B4 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060307B6 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060307B8 rts ; mov.l @r15+,r8
}

void f_060307C8(SH2Context& c) {
    ran[688] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060307C8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060307CA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060307CC mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060307CE mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060307D0 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060307D2 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060307D4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060307D6 sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x06030930u);  // 060307D8 mov.w 0x06030930,r3
    c.r[15] += c.r[3];  // 060307DA add r3,r15
    c.r[14] = c.r[15];  // 060307DC mov r15,r14
    c.r[8] = c.r[4] & 0xFFu;  // 060307DE extu.b r4,r8
    c.r[5] = c.r[5] & 0xFFFFu;  // 060307E0 extu.w r5,r5
    c.r[9] = 0x1Eu;  // 060307E2 mov #30,r9
    c.macl = c.r[8] * c.r[9];  // 060307E4 mul.l r9,r8
    c.r[4] = ld32(0x06030940u);  // 060307E6 mov.l 0x06030940,r4
    c.r[3] = ld32(c.r[4]);  // 060307E8 mov.l @r4,r3
    c.r[1] = c.macl;  // 060307EA sts macl,r1
    c.r[1] += c.r[3];  // 060307EC add r3,r1
    c.r[1] += 16;  // 060307EE add #16,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060307F0 mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 060307F2 extu.b r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06030932u);  // 060307F4 mov.w 0x06030932,r1
    c.t = c.r[2] == c.r[1];  // 060307F6 cmp/eq r1,r2
    { const bool k = c.t; c.r[6] = c.r[6] & 0xFFu; if (k) { goto L_060307FE; } }  // 060307F8 bt/s 0x060307FE ; extu.b r6,r6
    c.r[8] = c.r[2];  // 060307FC mov r2,r8
L_060307FE:
    c.r[0] = c.r[5];  // 060307FE mov r5,r0
    c.r[0] &= 0xFu;  // 06030800 and #15,r0
    c.r[10] = (uint32_t)(int16_t)ld16(0x06030934u);  // 06030802 mov.w 0x06030934,r10
    c.r[10] += c.r[14];  // 06030804 add r14,r10
    st32(c.r[10], c.r[0]);  // 06030806 mov.l r0,@r10
    c.r[13] = c.r[5];  // 06030808 mov r5,r13
    c.r[13] >>= 2;  // 0603080A shlr2 r13
    c.r[13] >>= 2;  // 0603080C shlr2 r13
    c.r[0] = 0xFu;  // 0603080E mov #15,r0
    c.r[13] &= c.r[0];  // 06030810 and r0,r13
    c.r[12] = c.r[5];  // 06030812 mov r5,r12
    c.r[12] >>= 8;  // 06030814 shlr8 r12
    c.r[12] &= c.r[0];  // 06030816 and r0,r12
    c.r[11] = c.r[5];  // 06030818 mov r5,r11
    c.r[11] >>= 8;  // 0603081A shlr8 r11
    c.r[11] >>= 2;  // 0603081C shlr2 r11
    c.r[11] >>= 2;  // 0603081E shlr2 r11
    c.r[0] &= c.r[6];  // 06030820 and r6,r0
    c.r[10] = (uint32_t)(int16_t)ld16(0x06030936u);  // 06030822 mov.w 0x06030936,r10
    c.r[10] += c.r[14];  // 06030824 add r14,r10
    c.r[6] >>= 2;  // 06030826 shlr2 r6
    c.r[6] >>= 2;  // 06030828 shlr2 r6
    c.t = (c.r[7] & c.r[7]) == 0;  // 0603082A tst r7,r7
    { const bool k = !c.t; st32(c.r[10], c.r[0]); if (k) { goto L_06030834; } }  // 0603082C bf/s 0x06030834 ; mov.l r0,@r10
    goto L_06030944;  // 06030830 bra 0x06030944 ; nop
L_06030834:
    c.r[5] = 0x7u;  // 06030834 mov #7,r5
    c.r[10] = 0xFu;  // 06030836 mov #15,r10
    c.macl = c.r[8] * c.r[9];  // 06030838 mul.l r9,r8
    c.r[0] = (uint32_t)(int16_t)ld16(0x06030934u);  // 0603083A mov.w 0x06030934,r0
    c.r[0] += c.r[14];  // 0603083C add r14,r0
    c.r[2] = c.macl;  // 0603083E sts macl,r2
    c.r[2] += c.r[3];  // 06030840 add r3,r2
    c.r[1] = c.r[2];  // 06030842 mov r2,r1
    c.r[1] += 3;  // 06030844 add #3,r1
    c.r[3] = c.r[2];  // 06030846 mov r2,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06030848 mov.b @r1,r1
    c.r[3] += 4;  // 0603084A add #4,r3
    c.r[5] &= c.r[1];  // 0603084C and r1,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0603084E mov.b @r3,r1
    c.r[5] += c.r[5];  // 06030850 add r5,r5
    c.r[7] = c.r[1] & 0xFFu;  // 06030852 extu.b r1,r7
    c.r[1] = c.r[7];  // 06030854 mov r7,r1
    c.r[1] >>= 2;  // 06030856 shlr2 r1
    c.r[1] >>= 2;  // 06030858 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0603085A shlr r1
    c.r[1] >>= 2;  // 0603085C shlr2 r1
    c.r[1] |= c.r[5];  // 0603085E or r5,r1
    c.r[11] += c.r[1];  // 06030860 add r1,r11
    c.r[7] >>= 2;  // 06030862 shlr2 r7
    c.t = c.r[7] & 1; c.r[7] >>= 1;  // 06030864 shlr r7
    c.r[7] &= c.r[10];  // 06030866 and r10,r7
    c.r[12] += c.r[7];  // 06030868 add r7,r12
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0603086A mov.w @r3,r1
    c.r[5] = c.r[9];  // 0603086C mov r9,r5
    c.r[1] >>= 2;  // 0603086E shlr2 r1
    c.r[1] >>= 2;  // 06030870 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06030872 shlr r1
    c.r[1] >>= 2;  // 06030874 shlr2 r1
    c.r[1] &= c.r[10];  // 06030876 and r10,r1
    c.r[13] += c.r[1];  // 06030878 add r1,r13
    c.r[1] = c.r[2];  // 0603087A mov r2,r1
    c.r[1] += 5;  // 0603087C add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603087E mov.b @r1,r1
    c.r[9] = 0x9u;  // 06030880 mov #9,r9
    c.r[3] = c.r[1] & 0xFFu;  // 06030882 extu.b r1,r3
    c.r[1] = c.r[3];  // 06030884 mov r3,r1
    c.r[1] >>= 2;  // 06030886 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06030888 shlr r1
    c.r[1] &= c.r[10];  // 0603088A and r10,r1
    c.r[10] = ld32(c.r[0]);  // 0603088C mov.l @r0,r10
    c.r[2] += 6;  // 0603088E add #6,r2
    c.r[10] += c.r[1];  // 06030890 add r1,r10
    st32(c.r[0], c.r[10]);  // 06030892 mov.l r10,@r0
    c.r[0] = 0x7u;  // 06030894 mov #7,r0
    c.r[3] &= c.r[0];  // 06030896 and r0,r3
    c.r[3] += c.r[3];  // 06030898 add r3,r3
    c.r[10] = (uint32_t)(int16_t)ld16(0x06030936u);  // 0603089A mov.w 0x06030936,r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0603089C mov.b @r2,r1
    c.r[10] += c.r[14];  // 0603089E add r14,r10
    c.r[0] = ld32(c.r[10]);  // 060308A0 mov.l @r10,r0
    c.r[1] = c.r[1] & 0xFFu;  // 060308A2 extu.b r1,r1
    c.r[1] >>= 2;  // 060308A4 shlr2 r1
    c.r[1] >>= 2;  // 060308A6 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060308A8 shlr r1
    c.r[1] >>= 2;  // 060308AA shlr2 r1
    c.r[1] |= c.r[3];  // 060308AC or r3,r1
    c.r[0] += c.r[1];  // 060308AE add r1,r0
    st32(c.r[10], c.r[0]);  // 060308B0 mov.l r0,@r10
    c.r[3] = 0x0u;  // 060308B2 mov #0,r3
L_060308B4:
    c.macl = c.r[8] * c.r[5];  // 060308B4 mul.l r5,r8
    c.r[1] = ld32(c.r[4]);  // 060308B6 mov.l @r4,r1
    c.r[2] = c.macl;  // 060308B8 sts macl,r2
    c.r[2] += c.r[1];  // 060308BA add r1,r2
    c.r[2] += c.r[3];  // 060308BC add r3,r2
    c.r[2] += 7;  // 060308BE add #7,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060308C0 mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060308C2 extu.b r1,r1
    c.r[1] >>= 2;  // 060308C4 shlr2 r1
    c.r[1] >>= 2;  // 060308C6 shlr2 r1
    c.r[1] += c.r[6];  // 060308C8 add r6,r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[9];  // 060308CA cmp/gt r9,r1
    if (c.t) { goto L_060308D6; }  // 060308CC bt 0x060308D6
    c.r[1] <<= 2;  // 060308CE shll2 r1
    c.r[1] <<= 2;  // 060308D0 shll2 r1
    c.r[7] = c.r[1] & 0xFFu; goto L_060308DA;  // 060308D2 bra 0x060308DA ; extu.b r1,r7
L_060308D6:
    c.r[7] = (uint32_t)(int16_t)ld16(0x06030938u);  // 060308D6 mov.w 0x06030938,r7
    c.macl = c.r[8] * c.r[5];  // 060308D8 mul.l r5,r8
L_060308DA:
    c.r[1] = ld32(c.r[4]);  // 060308DA mov.l @r4,r1
    c.r[2] = c.macl;  // 060308DC sts macl,r2
    c.r[2] += c.r[1];  // 060308DE add r1,r2
    c.r[2] += c.r[3];  // 060308E0 add r3,r2
    c.r[2] += 7;  // 060308E2 add #7,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060308E4 mov.b @r2,r1
    c.r[10] = 0xFu;  // 060308E6 mov #15,r10
    c.r[1] &= c.r[10];  // 060308E8 and r10,r1
    c.r[1] |= c.r[7];  // 060308EA or r7,r1
    st8(c.r[2], c.r[1]);  // 060308EC mov.b r1,@r2
    c.r[2] = c.macl;  // 060308EE sts macl,r2
    c.r[1] = ld32(c.r[4]);  // 060308F0 mov.l @r4,r1
    c.r[10] = (uint32_t)(int16_t)ld16(0x0603093Au);  // 060308F2 mov.w 0x0603093A,r10
    c.r[2] += c.r[1];  // 060308F4 add r1,r2
    c.r[2] += c.r[3];  // 060308F6 add r3,r2
    c.r[2] += 7;  // 060308F8 add #7,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060308FA mov.b @r2,r1
    c.r[10] += c.r[14];  // 060308FC add r14,r10
    c.r[0] = c.r[1];  // 060308FE mov r1,r0
    c.r[0] &= 0xFu;  // 06030900 and #15,r0
    st32(c.r[10], c.r[0]);  // 06030902 mov.l r0,@r10
    c.r[0] = (uint32_t)(int16_t)ld16(0x0603093Au);  // 06030904 mov.w 0x0603093A,r0
    c.r[0] += c.r[14];  // 06030906 add r14,r0
    c.r[10] = ld32(c.r[0]);  // 06030908 mov.l @r0,r10
    c.r[10] += c.r[6];  // 0603090A add r6,r10
    st32(c.r[0], c.r[10]);  // 0603090C mov.l r10,@r0
    c.r[0] = (uint32_t)(int16_t)ld16(0x0603093Au);  // 0603090E mov.w 0x0603093A,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06030910 mov.l @(r0,r14),r0
    c.t = (int32_t)c.r[0] > (int32_t)c.r[9];  // 06030912 cmp/gt r9,r0
    { const bool k = c.t; c.r[1] = 0xAu; if (k) { goto L_06030920; } }  // 06030914 bt/s 0x06030920 ; mov #10,r1
    c.r[10] = (uint32_t)(int16_t)ld16(0x0603093Cu);  // 06030918 mov.w 0x0603093C,r10
    c.r[10] += c.r[14];  // 0603091A add r14,r10
    c.r[10] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0603091C mov.b @r10,r10
    c.r[1] = c.r[10] & 0xFFu;  // 0603091E extu.b r10,r1
L_06030920:
    c.r[7] |= c.r[1];  // 06030920 or r1,r7
    c.r[3] += 1;  // 06030922 add #1,r3
    c.r[1] = 0x7u;  // 06030924 mov #7,r1
    c.t = (int32_t)c.r[3] > (int32_t)c.r[1];  // 06030926 cmp/gt r1,r3
    { const bool k = !c.t; st8(c.r[2], c.r[7]); if (k) { SH2_POLL(c); goto L_060308B4; } }  // 06030928 bf/s 0x060308B4 ; mov.b r7,@r2
    goto L_06030968;  // 0603092C bra 0x06030968 ; nop
L_06030944:
    c.r[1] = c.r[6];  // 06030944 mov r6,r1
    c.r[1] <<= 2;  // 06030946 shll2 r1
    c.r[1] <<= 2;  // 06030948 shll2 r1
    c.r[1] |= c.r[6];  // 0603094A or r6,r1
    c.r[6] = c.r[1] & 0xFFu;  // 0603094C extu.b r1,r6
    c.r[3] = 0x0u;  // 0603094E mov #0,r3
    c.r[5] = 0x7u;  // 06030950 mov #7,r5
    c.r[7] = c.r[9];  // 06030952 mov r9,r7
    c.macl = c.r[8] * c.r[7];  // 06030954 mul.l r7,r8
L_06030956:
    c.r[1] = ld32(c.r[4]);  // 06030956 mov.l @r4,r1
    c.r[2] = c.macl;  // 06030958 sts macl,r2
    c.r[2] += c.r[1];  // 0603095A add r1,r2
    c.r[2] += c.r[3];  // 0603095C add r3,r2
    c.r[2] += 7;  // 0603095E add #7,r2
    c.r[3] += 1;  // 06030960 add #1,r3
    c.t = (int32_t)c.r[3] > (int32_t)c.r[5];  // 06030962 cmp/gt r5,r3
    { const bool k = !c.t; st8(c.r[2], c.r[6]); if (k) { SH2_POLL(c); goto L_06030956; } }  // 06030964 bf/s 0x06030956 ; mov.b r6,@r2
L_06030968:
    c.r[9] = (uint32_t)(int16_t)ld16(0x060309C8u);  // 06030968 mov.w 0x060309C8,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x060309CAu);  // 0603096A mov.w 0x060309CA,r0
    c.r[0] += c.r[14];  // 0603096C add r14,r0
    c.r[10] = (uint32_t)(int16_t)ld16(0x060309CCu);  // 0603096E mov.w 0x060309CC,r10
    c.r[10] += c.r[14];  // 06030970 add r14,r10
    c.r[1] = ld32(0x060309D0u);  // 06030972 mov.l 0x060309D0,r1
    c.r[7] = c.r[12];  // 06030974 mov r12,r7
    c.r[6] = c.r[11];  // 06030976 mov r11,r6
    c.r[0] = ld32(c.r[0]);  // 06030978 mov.l @r0,r0
    c.r[5] = c.r[9];  // 0603097A mov r9,r5
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 0603097C mov.l r0,@-r15
    c.r[10] = ld32(c.r[10]);  // 0603097E mov.l @r10,r10
    c.r[4] = c.r[8];  // 06030980 mov r8,r4
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06030982 mov.l r10,@-r15
    { const uint32_t x = c.r[1]; c.pr = 0x06030988u; c.r[15] -= 4; st32(c.r[15], c.r[13]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06030988u) return; }  // 06030984 jsr @r1 ; mov.l r13,@-r15
    c.r[0] = ld32(0x060309D4u);  // 06030988 mov.l 0x060309D4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0603098Eu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603098Eu) return; }  // 0603098A jsr @r0 ; mov r8,r4
    c.r[1] = c.r[0];  // 0603098E mov r0,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06030990 extu.b r1,r1
    c.t = c.r[1] == c.r[9];  // 06030992 cmp/eq r9,r1
    { const bool k = c.t; c.r[15] += 12; if (k) { goto L_060309AA; } }  // 06030994 bt/s 0x060309AA ; add #12,r15
    c.r[1] = ld32(0x060309D8u);  // 06030998 mov.l 0x060309D8,r1
    c.r[6] = c.r[9];  // 0603099A mov r9,r6
    c.r[5] = c.r[8];  // 0603099C mov r8,r5
    { const uint32_t x = c.r[1]; c.pr = 0x060309A2u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060309A2u) return; }  // 0603099E jsr @r1 ; mov r14,r4
    c.r[1] = ld32(0x060309DCu);  // 060309A2 mov.l 0x060309DC,r1
    c.r[5] = c.r[8];  // 060309A4 mov r8,r5
    { const uint32_t x = c.r[1]; c.pr = 0x060309AAu; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060309AAu) return; }  // 060309A6 jsr @r1 ; mov r14,r4
L_060309AA:
    c.r[1] = ld32(0x060309E0u);  // 060309AA mov.l 0x060309E0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060309B0u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060309B0u) return; }  // 060309AC jsr @r1 ; mov r8,r4
    c.r[3] = (uint32_t)(int16_t)ld16(0x060309CEu);  // 060309B0 mov.w 0x060309CE,r3
    c.r[14] += c.r[3];  // 060309B2 add r3,r14
    c.r[15] = c.r[14];  // 060309B4 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060309B6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060309B8 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060309BA mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060309BC mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060309BE mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060309C0 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060309C2 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060309C4 rts ; mov.l @r15+,r8
}

void f_060309E4(SH2Context& c) {
    ran[689] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060309E4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060309E6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060309E8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060309EA mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060309EC mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060309EE mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060309F0 mov.l r14,@-r15
    c.r[15] -= 4;  // 060309F2 add #-4,r15
    c.r[14] = c.r[15];  // 060309F4 mov r15,r14
    c.r[4] = c.r[4] & 0xFFu;  // 060309F6 extu.b r4,r4
    st32(c.r[14], c.r[4]);  // 060309F8 mov.l r4,@r14
    c.r[8] = c.r[5] & 0xFFu;  // 060309FA extu.b r5,r8
    c.r[1] = ld32(c.r[14] + 32);  // 060309FC mov.l @(32,r14),r1
    c.r[5] = c.r[6] & 0xFFu;  // 060309FE extu.b r6,r5
    c.r[2] = ld32(c.r[14] + 36);  // 06030A00 mov.l @(36,r14),r2
    c.r[9] = c.r[7] & 0xFFu;  // 06030A02 extu.b r7,r9
    c.r[3] = ld32(c.r[14] + 40);  // 06030A04 mov.l @(40,r14),r3
    c.r[10] = c.r[1] & 0xFFu;  // 06030A06 extu.b r1,r10
    c.r[11] = c.r[2] & 0xFFu;  // 06030A08 extu.b r2,r11
    c.r[1] = (uint32_t)(int16_t)ld16(0x06030B16u);  // 06030A0A mov.w 0x06030B16,r1
    c.t = c.r[8] == c.r[1];  // 06030A0C cmp/eq r1,r8
    { const bool k = c.t; c.r[12] = c.r[3] & 0xFFu; if (k) { goto L_06030A30; } }  // 06030A0E bt/s 0x06030A30 ; extu.b r3,r12
    c.r[1] = ld32(0x06030B1Cu);  // 06030A12 mov.l 0x06030B1C,r1
    c.r[2] = ld32(c.r[1]);  // 06030A14 mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 06030A16 mov #30,r1
    c.macl = c.r[4] * c.r[1];  // 06030A18 mul.l r1,r4
    c.r[13] = 0xFu;  // 06030A1A mov #15,r13
    c.r[8] &= c.r[13];  // 06030A1C and r13,r8
    c.r[1] = c.macl;  // 06030A1E sts macl,r1
    c.r[1] += c.r[2];  // 06030A20 add r2,r1
    c.r[1] += 3;  // 06030A22 add #3,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06030A24 mov.b @r1,r0
    c.r[8] <<= 2;  // 06030A26 shll2 r8
    c.r[8] += c.r[8];  // 06030A28 add r8,r8
    c.r[0] &= 0x87u;  // 06030A2A and #135,r0
    c.r[0] |= c.r[8];  // 06030A2C or r8,r0
    st8(c.r[1], c.r[0]);  // 06030A2E mov.b r0,@r1
L_06030A30:
    c.r[0] = 0xAu;  // 06030A30 mov #10,r0
    c.t = c.r[5] > c.r[0];  // 06030A32 cmp/hi r0,r5
    if (!c.t) { goto L_06030A38; }  // 06030A34 bf 0x06030A38
    c.r[5] = c.r[0];  // 06030A36 mov r0,r5
L_06030A38:
    c.t = c.r[9] > c.r[0];  // 06030A38 cmp/hi r0,r9
    if (!c.t) { goto L_06030A3E; }  // 06030A3A bf 0x06030A3E
    c.r[9] = c.r[0];  // 06030A3C mov r0,r9
L_06030A3E:
    c.t = c.r[10] > c.r[0];  // 06030A3E cmp/hi r0,r10
    if (!c.t) { goto L_06030A44; }  // 06030A40 bf 0x06030A44
    c.r[10] = c.r[0];  // 06030A42 mov r0,r10
L_06030A44:
    c.t = c.r[11] > c.r[0];  // 06030A44 cmp/hi r0,r11
    if (!c.t) { goto L_06030A4A; }  // 06030A46 bf 0x06030A4A
    c.r[11] = c.r[0];  // 06030A48 mov r0,r11
L_06030A4A:
    c.t = c.r[12] > c.r[0];  // 06030A4A cmp/hi r0,r12
    if (!c.t) { goto L_06030A50; }  // 06030A4C bf 0x06030A50
    c.r[12] = c.r[0];  // 06030A4E mov r0,r12
L_06030A50:
    c.r[6] = ld32(0x06030B1Cu);  // 06030A50 mov.l 0x06030B1C,r6
    c.r[1] = 0x1Eu;  // 06030A52 mov #30,r1
    c.r[7] = c.r[5] & 0xFFFFu;  // 06030A54 extu.w r5,r7
    c.r[0] = c.r[7];  // 06030A56 mov r7,r0
    c.r[13] = ld32(c.r[14]);  // 06030A58 mov.l @r14,r13
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06030A5A shlr r0
    c.macl = c.r[13] * c.r[1];  // 06030A5C mul.l r1,r13
    c.r[0] &= 0x7u;  // 06030A5E and #7,r0
    c.r[2] = ld32(c.r[6]);  // 06030A60 mov.l @r6,r2
    c.r[1] = c.macl;  // 06030A62 sts macl,r1
    c.r[1] += c.r[2];  // 06030A64 add r2,r1
    c.r[2] = c.r[1];  // 06030A66 mov r1,r2
    c.r[2] += 3;  // 06030A68 add #3,r2
    c.r[13] = (uint32_t)(int16_t)ld16(0x06030B18u);  // 06030A6A mov.w 0x06030B18,r13
    c.r[1] += 4;  // 06030A6C add #4,r1
    c.r[14] += 4;  // 06030A6E add #4,r14
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06030A70 mov.b @r2,r3
    c.r[15] = c.r[14];  // 06030A72 mov r14,r15
    c.r[3] &= c.r[13];  // 06030A74 and r13,r3
    c.r[3] |= c.r[0];  // 06030A76 or r0,r3
    st8(c.r[2], c.r[3]);  // 06030A78 mov.b r3,@r2
    c.r[13] = 0x1u;  // 06030A7A mov #1,r13
    c.r[7] &= c.r[13];  // 06030A7C and r13,r7
    c.r[7] <<= 2;  // 06030A7E shll2 r7
    c.r[7] <<= 2;  // 06030A80 shll2 r7
    c.r[7] += c.r[7];  // 06030A82 add r7,r7
    c.r[7] <<= 2;  // 06030A84 shll2 r7
    c.r[2] = c.macl;  // 06030A86 sts macl,r2
    c.r[13] = 0xFu;  // 06030A88 mov #15,r13
    c.r[9] &= c.r[13];  // 06030A8A and r13,r9
    c.r[9] <<= 2;  // 06030A8C shll2 r9
    c.r[9] += c.r[9];  // 06030A8E add r9,r9
    c.r[3] = c.macl;  // 06030A90 sts macl,r3
    c.r[10] &= c.r[13];  // 06030A92 and r13,r10
    c.r[10] <<= 2;  // 06030A94 shll2 r10
    c.r[10] <<= 2;  // 06030A96 shll2 r10
    c.r[10] += c.r[10];  // 06030A98 add r10,r10
    c.r[10] <<= 2;  // 06030A9A shll2 r10
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06030A9C mov.b @r1,r0
    c.r[11] &= c.r[13];  // 06030A9E and r13,r11
    c.r[0] &= 0x7Fu;  // 06030AA0 and #127,r0
    c.r[0] |= c.r[7];  // 06030AA2 or r7,r0
    st8(c.r[1], c.r[0]);  // 06030AA4 mov.b r0,@r1
    c.r[1] = ld32(c.r[6]);  // 06030AA6 mov.l @r6,r1
    c.r[11] <<= 2;  // 06030AA8 shll2 r11
    c.r[11] += c.r[11];  // 06030AAA add r11,r11
    c.r[2] += c.r[1];  // 06030AAC add r1,r2
    c.r[2] += 4;  // 06030AAE add #4,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06030AB0 mov.b @r2,r0
    c.r[13] = (uint32_t)(int16_t)ld16(0x06030B18u);  // 06030AB2 mov.w 0x06030B18,r13
    c.r[0] &= 0x87u;  // 06030AB4 and #135,r0
    c.r[0] |= c.r[9];  // 06030AB6 or r9,r0
    st8(c.r[2], c.r[0]);  // 06030AB8 mov.b r0,@r2
    c.r[1] = ld32(c.r[6]);  // 06030ABA mov.l @r6,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06030B1Au);  // 06030ABC mov.w 0x06030B1A,r2
    c.r[3] += c.r[1];  // 06030ABE add r1,r3
    c.r[7] = c.r[3];  // 06030AC0 mov r3,r7
    c.r[7] += 4;  // 06030AC2 add #4,r7
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[7]);  // 06030AC4 mov.w @r7,r1
    c.r[3] += 5;  // 06030AC6 add #5,r3
    c.r[1] &= c.r[2];  // 06030AC8 and r2,r1
    c.r[1] |= c.r[10];  // 06030ACA or r10,r1
    st16(c.r[7], c.r[1]);  // 06030ACC mov.w r1,@r7
    c.r[2] = c.macl;  // 06030ACE sts macl,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06030AD0 mov.b @r3,r0
    c.r[7] = c.r[12] & 0xFFFFu;  // 06030AD2 extu.w r12,r7
    c.r[0] &= 0x87u;  // 06030AD4 and #135,r0
    c.r[0] |= c.r[11];  // 06030AD6 or r11,r0
    st8(c.r[3], c.r[0]);  // 06030AD8 mov.b r0,@r3
    c.r[0] = c.r[7];  // 06030ADA mov r7,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06030ADC shlr r0
    c.r[1] = ld32(c.r[6]);  // 06030ADE mov.l @r6,r1
    c.r[0] &= 0x7u;  // 06030AE0 and #7,r0
    c.r[2] += c.r[1];  // 06030AE2 add r1,r2
    c.r[1] = c.r[2];  // 06030AE4 mov r2,r1
    c.r[1] += 5;  // 06030AE6 add #5,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06030AE8 mov.b @r1,r3
    c.r[2] += 6;  // 06030AEA add #6,r2
    c.r[3] &= c.r[13];  // 06030AEC and r13,r3
    c.r[3] |= c.r[0];  // 06030AEE or r0,r3
    st8(c.r[1], c.r[3]);  // 06030AF0 mov.b r3,@r1
    c.r[13] = 0x1u;  // 06030AF2 mov #1,r13
    c.r[7] &= c.r[13];  // 06030AF4 and r13,r7
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06030AF6 mov.b @r2,r0
    c.r[7] <<= 2;  // 06030AF8 shll2 r7
    c.r[7] <<= 2;  // 06030AFA shll2 r7
    c.r[7] += c.r[7];  // 06030AFC add r7,r7
    c.r[7] <<= 2;  // 06030AFE shll2 r7
    c.r[0] &= 0x7Fu;  // 06030B00 and #127,r0
    c.r[0] |= c.r[7];  // 06030B02 or r7,r0
    st8(c.r[2], c.r[0]);  // 06030B04 mov.b r0,@r2
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06030B06 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06030B08 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06030B0A mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06030B0C mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06030B0E mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06030B10 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06030B12 rts ; mov.l @r15+,r8
}

void f_06030B20(SH2Context& c) {
    ran[690] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06030B20 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06030B22 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06030B24 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06030B26 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06030B28 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06030B2A mov r15,r14
    c.r[8] = 0x0u;  // 06030B2C mov #0,r8
    c.r[10] = ld32(0x06030B4Cu);  // 06030B2E mov.l 0x06030B4C,r10
    c.r[9] = 0x7Fu;  // 06030B30 mov #127,r9
L_06030B32:
    { const uint32_t x = c.r[10]; c.pr = 0x06030B36u; c.r[4] = c.r[8] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06030B36u) return; }  // 06030B32 jsr @r10 ; extu.b r8,r4
    c.r[8] += 1;  // 06030B36 add #1,r8
    c.t = (int32_t)c.r[8] > (int32_t)c.r[9];  // 06030B38 cmp/gt r9,r8
    if (!c.t) { SH2_POLL(c); goto L_06030B32; }  // 06030B3A bf 0x06030B32
    c.r[15] = c.r[14];  // 06030B3C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06030B3E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06030B40 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06030B42 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06030B44 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06030B46 rts ; mov.l @r15+,r8
}

void f_06030B50(SH2Context& c) {
    ran[691] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06030B50 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06030B52 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06030B54 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06030B56 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06030B58 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06030B5A sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06030B5C mov r15,r14
    c.r[8] = c.r[4] & 0xFFu;  // 06030B5E extu.b r4,r8
    c.r[11] = 0x1Eu;  // 06030B60 mov #30,r11
    c.macl = c.r[8] * c.r[11];  // 06030B62 mul.l r11,r8
    c.r[9] = ld32(0x06030CF0u);  // 06030B64 mov.l 0x06030CF0,r9
    c.r[1] = ld32(c.r[9]);  // 06030B66 mov.l @r9,r1
    c.r[10] = c.macl;  // 06030B68 sts macl,r10
    c.r[0] = c.r[10];  // 06030B6A mov r10,r0
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06030B6C mov.w @(r0,r1),r5
    c.r[4] = 0x0u;  // 06030B6E mov #0,r4
    c.r[0] = ld32(0x06030CF4u);  // 06030B70 mov.l 0x06030CF4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06030B76u; c.r[5] = c.r[5] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06030B76u) return; }  // 06030B72 jsr @r0 ; extu.w r5,r5
    c.r[1] = c.r[0];  // 06030B76 mov r0,r1
    c.r[2] = c.r[1] & 0xFFFFu;  // 06030B78 extu.w r1,r2
    c.r[1] = ld32(0x06030CF8u);  // 06030B7A mov.l 0x06030CF8,r1
    c.t = c.r[2] == c.r[1];  // 06030B7C cmp/eq r1,r2
    { const bool k = c.t; c.macl = c.r[10]; if (k) { goto L_06030BD4; } }  // 06030B7E bt/s 0x06030BD4 ; lds r10,macl
    c.r[3] = ld32(0x06030CFCu);  // 06030B82 mov.l 0x06030CFC,r3
    c.r[5] = c.r[2];  // 06030B84 mov r2,r5
    c.r[5] <<= 2;  // 06030B86 shll2 r5
    c.r[7] = ld32(0x06030D00u);  // 06030B88 mov.l 0x06030D00,r7
    c.r[1] = 0xFFFFFFFFu;  // 06030B8A mov #-1,r1
    c.r[2] = ld32(c.r[7]);  // 06030B8C mov.l @r7,r2
    c.r[0] = c.r[3];  // 06030B8E mov r3,r0
    c.r[2] += c.r[5];  // 06030B90 add r5,r2
    c.r[2] += 20;  // 06030B92 add #20,r2
    st8(c.r[2], c.r[1]);  // 06030B94 mov.b r1,@r2
    st8(c.r[0] + c.r[5], c.r[1]);  // 06030B96 mov.b r1,@(r0,r5)
    c.r[2] = c.r[5];  // 06030B98 mov r5,r2
    c.r[2] += c.r[3];  // 06030B9A add r3,r2
    c.r[6] = c.r[2];  // 06030B9C mov r2,r6
    c.r[3] = ld32(c.r[7]);  // 06030B9E mov.l @r7,r3
    c.r[6] += 1;  // 06030BA0 add #1,r6
    c.r[3] += c.r[5];  // 06030BA2 add r5,r3
    c.r[3] += 21;  // 06030BA4 add #21,r3
    st8(c.r[3], c.r[1]);  // 06030BA6 mov.b r1,@r3
    st8(c.r[6], c.r[1]);  // 06030BA8 mov.b r1,@r6
    c.r[1] = ld32(c.r[7]);  // 06030BAA mov.l @r7,r1
    c.r[0] = 0x3Fu;  // 06030BAC mov #63,r0
    c.r[1] += c.r[5];  // 06030BAE add r5,r1
    c.r[1] += 22;  // 06030BB0 add #22,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06030BB2 mov.b @r1,r3
    c.r[2] += 2;  // 06030BB4 add #2,r2
    c.r[3] &= c.r[0];  // 06030BB6 and r0,r3
    st8(c.r[1], c.r[3]);  // 06030BB8 mov.b r3,@r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06030BBA mov.b @r2,r1
    c.r[1] &= c.r[0];  // 06030BBC and r0,r1
    st8(c.r[2], c.r[1]);  // 06030BBE mov.b r1,@r2
    c.r[1] = ld32(c.r[7]);  // 06030BC0 mov.l @r7,r1
    c.r[1] += c.r[5];  // 06030BC2 add r5,r1
    c.r[1] += 22;  // 06030BC4 add #22,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06030BC6 mov.b @r1,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x06030CECu);  // 06030BC8 mov.w 0x06030CEC,r0
    c.r[3] &= c.r[0];  // 06030BCA and r0,r3
    st8(c.r[1], c.r[3]);  // 06030BCC mov.b r3,@r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06030BCE mov.b @r2,r1
    c.r[1] &= c.r[0];  // 06030BD0 and r0,r1
    st8(c.r[2], c.r[1]);  // 06030BD2 mov.b r1,@r2
L_06030BD4:
    c.r[1] = ld32(c.r[9]);  // 06030BD4 mov.l @r9,r1
    c.r[2] = c.macl;  // 06030BD6 sts macl,r2
    c.r[2] += c.r[1];  // 06030BD8 add r1,r2
    c.r[1] = 0x0u;  // 06030BDA mov #0,r1
    st16(c.r[2], c.r[1]);  // 06030BDC mov.w r1,@r2
    c.r[2] += 2;  // 06030BDE add #2,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06030BE0 mov.b @r2,r0
    c.r[0] &= 0x3Fu;  // 06030BE2 and #63,r0
    st8(c.r[2], c.r[0]);  // 06030BE4 mov.b r0,@r2
    c.r[1] = ld32(c.r[9]);  // 06030BE6 mov.l @r9,r1
    c.r[2] = c.macl;  // 06030BE8 sts macl,r2
    c.r[2] += c.r[1];  // 06030BEA add r1,r2
    c.r[2] += 2;  // 06030BEC add #2,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06030BEE mov.b @r2,r0
    c.r[0] &= 0xDFu;  // 06030BF0 and #223,r0
    st8(c.r[2], c.r[0]);  // 06030BF2 mov.b r0,@r2
    c.r[1] = ld32(c.r[9]);  // 06030BF4 mov.l @r9,r1
    c.r[2] = c.macl;  // 06030BF6 sts macl,r2
    c.r[2] += c.r[1];  // 06030BF8 add r1,r2
    c.r[2] += 2;  // 06030BFA add #2,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06030BFC mov.b @r2,r0
    c.r[4] = 0x7u;  // 06030BFE mov #7,r4
    c.r[0] &= 0xE7u;  // 06030C00 and #231,r0
    st8(c.r[2], c.r[0]);  // 06030C02 mov.b r0,@r2
    c.r[1] = ld32(c.r[9]);  // 06030C04 mov.l @r9,r1
    c.r[2] = c.macl;  // 06030C06 sts macl,r2
    c.r[2] += c.r[1];  // 06030C08 add r1,r2
    c.r[2] += 3;  // 06030C0A add #3,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06030C0C mov.b @r2,r0
    c.r[5] = c.r[9];  // 06030C0E mov r9,r5
    c.r[0] &= 0x87u;  // 06030C10 and #135,r0
    st8(c.r[2], c.r[0]);  // 06030C12 mov.b r0,@r2
    c.r[2] = ld32(c.r[9]);  // 06030C14 mov.l @r9,r2
    c.r[1] = c.macl;  // 06030C16 sts macl,r1
    c.r[1] += c.r[2];  // 06030C18 add r2,r1
    c.r[2] = c.r[1];  // 06030C1A mov r1,r2
    c.r[2] += 3;  // 06030C1C add #3,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06030C1E mov.b @r2,r0
    c.r[1] += 4;  // 06030C20 add #4,r1
    c.r[0] &= 0xF8u;  // 06030C22 and #248,r0
    st8(c.r[2], c.r[0]);  // 06030C24 mov.b r0,@r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06030C26 mov.b @r1,r0
    c.r[6] = c.r[11];  // 06030C28 mov r11,r6
    c.r[0] &= 0x7Fu;  // 06030C2A and #127,r0
    st8(c.r[1], c.r[0]);  // 06030C2C mov.b r0,@r1
    c.r[1] = ld32(c.r[9]);  // 06030C2E mov.l @r9,r1
    c.r[2] = c.macl;  // 06030C30 sts macl,r2
    c.r[2] += c.r[1];  // 06030C32 add r1,r2
    c.r[2] += 4;  // 06030C34 add #4,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06030C36 mov.b @r2,r0
    c.r[3] = c.macl;  // 06030C38 sts macl,r3
    c.r[0] &= 0x87u;  // 06030C3A and #135,r0
    st8(c.r[2], c.r[0]);  // 06030C3C mov.b r0,@r2
    c.r[1] = ld32(c.r[9]);  // 06030C3E mov.l @r9,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06030CEEu);  // 06030C40 mov.w 0x06030CEE,r2
    c.r[3] += c.r[1];  // 06030C42 add r1,r3
    c.r[7] = c.r[3];  // 06030C44 mov r3,r7
    c.r[7] += 4;  // 06030C46 add #4,r7
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[7]);  // 06030C48 mov.w @r7,r1
    c.r[3] += 5;  // 06030C4A add #5,r3
    c.r[1] &= c.r[2];  // 06030C4C and r2,r1
    st16(c.r[7], c.r[1]);  // 06030C4E mov.w r1,@r7
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06030C50 mov.b @r3,r0
    c.r[1] = c.macl;  // 06030C52 sts macl,r1
    c.r[0] &= 0x87u;  // 06030C54 and #135,r0
    st8(c.r[3], c.r[0]);  // 06030C56 mov.b r0,@r3
    c.r[2] = ld32(c.r[9]);  // 06030C58 mov.l @r9,r2
    c.r[7] = 0x0u;  // 06030C5A mov #0,r7
    c.r[1] += c.r[2];  // 06030C5C add r2,r1
    c.r[2] = c.r[1];  // 06030C5E mov r1,r2
    c.r[2] += 5;  // 06030C60 add #5,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06030C62 mov.b @r2,r0
    c.r[1] += 6;  // 06030C64 add #6,r1
    c.r[0] &= 0xF8u;  // 06030C66 and #248,r0
    st8(c.r[2], c.r[0]);  // 06030C68 mov.b r0,@r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06030C6A mov.b @r1,r0
    c.r[3] = 0x0u;  // 06030C6C mov #0,r3
    c.r[0] &= 0x7Fu;  // 06030C6E and #127,r0
    st8(c.r[1], c.r[0]);  // 06030C70 mov.b r0,@r1
    c.macl = c.r[8] * c.r[6];  // 06030C72 mul.l r6,r8
L_06030C74:
    c.r[1] = ld32(c.r[5]);  // 06030C74 mov.l @r5,r1
    c.r[2] = c.macl;  // 06030C76 sts macl,r2
    c.r[2] += c.r[1];  // 06030C78 add r1,r2
    c.r[2] += c.r[7];  // 06030C7A add r7,r2
    c.r[2] += 7;  // 06030C7C add #7,r2
    c.r[7] += 1;  // 06030C7E add #1,r7
    c.t = (int32_t)c.r[7] > (int32_t)c.r[4];  // 06030C80 cmp/gt r4,r7
    { const bool k = !c.t; st8(c.r[2], c.r[3]); if (k) { SH2_POLL(c); goto L_06030C74; } }  // 06030C82 bf/s 0x06030C74 ; mov.b r3,@r2
    c.r[3] = ld32(0x06030CF0u);  // 06030C86 mov.l 0x06030CF0,r3
    c.r[6] = 0x1Eu;  // 06030C88 mov #30,r6
    c.r[7] = 0xFFFFFFFFu;  // 06030C8A mov #-1,r7
    c.r[4] = 0x3u;  // 06030C8C mov #3,r4
    c.macl = c.r[8] * c.r[6];  // 06030C8E mul.l r6,r8
    c.r[5] = 0x0u;  // 06030C90 mov #0,r5
    c.r[1] = ld32(c.r[3]);  // 06030C92 mov.l @r3,r1
    c.r[2] = c.macl;  // 06030C94 sts macl,r2
    c.r[2] += c.r[1];  // 06030C96 add r1,r2
    c.r[2] += 15;  // 06030C98 add #15,r2
    st8(c.r[2], c.r[7]);  // 06030C9A mov.b r7,@r2
    c.r[1] = ld32(c.r[3]);  // 06030C9C mov.l @r3,r1
    c.r[2] = c.macl;  // 06030C9E sts macl,r2
    c.r[2] += c.r[1];  // 06030CA0 add r1,r2
    c.r[2] += 16;  // 06030CA2 add #16,r2
    st8(c.r[2], c.r[7]);  // 06030CA4 mov.b r7,@r2
    c.r[7] = 0x0u;  // 06030CA6 mov #0,r7
    c.macl = c.r[8] * c.r[6];  // 06030CA8 mul.l r6,r8
L_06030CAA:
    c.r[1] = ld32(c.r[3]);  // 06030CAA mov.l @r3,r1
    c.r[2] = c.macl;  // 06030CAC sts macl,r2
    c.r[2] += c.r[1];  // 06030CAE add r1,r2
    c.r[2] += c.r[7];  // 06030CB0 add r7,r2
    c.r[2] += 17;  // 06030CB2 add #17,r2
    c.r[7] += 1;  // 06030CB4 add #1,r7
    c.t = (int32_t)c.r[7] > (int32_t)c.r[4];  // 06030CB6 cmp/gt r4,r7
    { const bool k = !c.t; st8(c.r[2], c.r[5]); if (k) { SH2_POLL(c); goto L_06030CAA; } }  // 06030CB8 bf/s 0x06030CAA ; mov.b r5,@r2
    c.r[1] = ld32(0x06030CF0u);  // 06030CBC mov.l 0x06030CF0,r1
    c.r[2] = ld32(c.r[1]);  // 06030CBE mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 06030CC0 mov #30,r1
    c.macl = c.r[8] * c.r[1];  // 06030CC2 mul.l r1,r8
    c.r[15] = c.r[14];  // 06030CC4 mov r14,r15
    c.r[3] = c.macl;  // 06030CC6 sts macl,r3
    c.r[3] += c.r[2];  // 06030CC8 add r2,r3
    c.r[1] = c.r[3];  // 06030CCA mov r3,r1
    c.r[1] += 22;  // 06030CCC add #22,r1
    c.r[2] = 0x0u;  // 06030CCE mov #0,r2
    st16(c.r[1], c.r[2]);  // 06030CD0 mov.w r2,@r1
    c.r[1] = c.r[3];  // 06030CD2 mov r3,r1
    c.r[1] += 24;  // 06030CD4 add #24,r1
    st16(c.r[1], c.r[2]);  // 06030CD6 mov.w r2,@r1
    c.r[3] += 26;  // 06030CD8 add #26,r3
    c.r[1] = 0xFFFFFFFFu;  // 06030CDA mov #-1,r1
    st8(c.r[3], c.r[1]);  // 06030CDC mov.b r1,@r3
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06030CDE lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06030CE0 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06030CE2 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06030CE4 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06030CE6 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06030CE8 rts ; mov.l @r15+,r8
}

void f_06030D04(SH2Context& c) {
    ran[692] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06030D04 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06030D06 mov r15,r14
    c.r[4] = c.r[4] & 0xFFu;  // 06030D08 extu.b r4,r4
    c.r[0] = 0x0u;  // 06030D0A mov #0,r0
    c.r[1] = ld32(0x06030D58u);  // 06030D0C mov.l 0x06030D58,r1
    c.r[3] = ld32(c.r[1]);  // 06030D0E mov.l @r1,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x06030D54u);  // 06030D10 mov.w 0x06030D54,r7
    c.r[1] = 0x1Eu;  // 06030D12 mov #30,r1
L_06030D14:
    c.macl = c.r[0] * c.r[1];  // 06030D14 mul.l r1,r0
    c.r[2] = c.macl;  // 06030D16 sts macl,r2
    c.r[2] += c.r[3];  // 06030D18 add r3,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06030D1A mov.w @r2,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06030D1C extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06030D1E tst r1,r1
    { const bool k = c.t; c.r[1] = c.r[0]; if (k) { goto L_06030D40; } }  // 06030D20 bt/s 0x06030D40 ; mov r0,r1
    c.r[1] = c.r[2];  // 06030D24 mov r2,r1
    c.r[1] += 15;  // 06030D26 add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06030D28 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06030D2A extu.b r1,r1
    c.t = c.r[1] == c.r[4];  // 06030D2C cmp/eq r4,r1
    { const bool k = !c.t; c.r[1] = c.r[0]; if (k) { goto L_06030D40; } }  // 06030D2E bf/s 0x06030D40 ; mov r0,r1
    c.r[2] += 16;  // 06030D32 add #16,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06030D34 mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06030D36 extu.b r1,r1
    c.t = c.r[1] == c.r[7];  // 06030D38 cmp/eq r7,r1
    { const bool k = c.t; c.r[15] = c.r[14]; if (k) { goto L_06030D50; } }  // 06030D3A bt/s 0x06030D50 ; mov r14,r15
    c.r[1] = c.r[0];  // 06030D3E mov r0,r1
L_06030D40:
    c.r[1] += 1;  // 06030D40 add #1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06030D42 extu.b r1,r0
    c.r[1] = 0x7Fu;  // 06030D44 mov #127,r1
    c.t = c.r[0] > c.r[1];  // 06030D46 cmp/hi r1,r0
    { const bool k = !c.t; c.r[1] = 0x1Eu; if (k) { SH2_POLL(c); goto L_06030D14; } }  // 06030D48 bf/s 0x06030D14 ; mov #30,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06030D54u);  // 06030D4C mov.w 0x06030D54,r0
    c.r[15] = c.r[14];  // 06030D4E mov r14,r15
L_06030D50:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06030D50 rts ; mov.l @r15+,r14
}

void f_06030D5C(SH2Context& c) {
    ran[693] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06030D5C mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06030D5E mov r15,r14
    c.r[4] = c.r[4] & 0xFFFFu;  // 06030D60 extu.w r4,r4
    c.r[2] = 0x0u;  // 06030D62 mov #0,r2
    c.r[1] = ld32(0x06030D94u);  // 06030D64 mov.l 0x06030D94,r1
    c.r[3] = ld32(c.r[1]);  // 06030D66 mov.l @r1,r3
    c.r[6] = 0x1Eu;  // 06030D68 mov #30,r6
    c.r[7] = 0x7Fu;  // 06030D6A mov #127,r7
    c.macl = c.r[2] * c.r[6];  // 06030D6C mul.l r6,r2
L_06030D6E:
    c.r[0] = c.macl;  // 06030D6E sts macl,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 06030D70 mov.w @(r0,r3),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06030D72 extu.w r1,r1
    c.t = c.r[1] == c.r[4];  // 06030D74 cmp/eq r4,r1
    { const bool k = !c.t; c.r[1] = c.r[2]; if (k) { goto L_06030D7E; } }  // 06030D76 bf/s 0x06030D7E ; mov r2,r1
    c.r[0] = c.r[2]; goto L_06030D8A;  // 06030D7A bra 0x06030D8A ; mov r2,r0
L_06030D7E:
    c.r[1] += 1;  // 06030D7E add #1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 06030D80 extu.b r1,r2
    c.t = c.r[2] > c.r[7];  // 06030D82 cmp/hi r7,r2
    { const bool k = !c.t; c.macl = c.r[2] * c.r[6]; if (k) { SH2_POLL(c); goto L_06030D6E; } }  // 06030D84 bf/s 0x06030D6E ; mul.l r6,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06030D90u);  // 06030D88 mov.w 0x06030D90,r0
L_06030D8A:
    c.r[15] = c.r[14];  // 06030D8A mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06030D8C rts ; mov.l @r15+,r14
}

void f_06030D98(SH2Context& c) {
    ran[694] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06030D98 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06030D9A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06030D9C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06030D9E mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06030DA0 mov r15,r14
    c.r[9] = c.r[4] & 0xFFFFu;  // 06030DA2 extu.w r4,r9
    c.r[2] = ld32(0x06030E18u);  // 06030DA4 mov.l 0x06030E18,r2
    c.r[3] = ld32(c.r[2]);  // 06030DA6 mov.l @r2,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x06030E14u);  // 06030DA8 mov.w 0x06030E14,r0
    c.r[6] = 0x0u;  // 06030DAA mov #0,r6
    c.r[1] = 0x0u;  // 06030DAC mov #0,r1
    c.r[8] = c.r[2];  // 06030DAE mov r2,r8
    c.r[5] = c.r[0];  // 06030DB0 mov r0,r5
    c.r[4] = 0x0u;  // 06030DB2 mov #0,r4
    st8(c.r[0] + c.r[3], c.r[1]);  // 06030DB4 mov.b r1,@(r0,r3)
L_06030DB6:
    c.r[1] = ld32(0x06030E1Cu);  // 06030DB6 mov.l 0x06030E1C,r1
    c.r[0] = ld32(c.r[1]);  // 06030DB8 mov.l @r1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[4]);  // 06030DBA mov.w @(r0,r4),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06030DBC extu.w r1,r1
    c.t = c.r[1] == c.r[9];  // 06030DBE cmp/eq r9,r1
    if (!c.t) { goto L_06030DF4; }  // 06030DC0 bf 0x06030DF4
    c.r[2] = ld32(c.r[8]);  // 06030DC2 mov.l @r8,r2
    c.r[0] = c.r[2];  // 06030DC4 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 06030DC6 mov.b @(r0,r5),r1
    c.r[7] = c.r[1] & 0xFFu;  // 06030DC8 extu.b r1,r7
    c.r[7] += c.r[7];  // 06030DCA add r7,r7
    c.r[1] = c.r[6] & 0xFFFFu;  // 06030DCC extu.w r6,r1
    c.r[10] = c.r[1];  // 06030DCE mov r1,r10
    c.r[10] >>= 8;  // 06030DD0 shlr8 r10
    c.r[0] = 0x7Fu;  // 06030DD2 mov #127,r0
    c.r[10] &= c.r[0];  // 06030DD4 and r0,r10
    c.r[0] = c.r[2];  // 06030DD6 mov r2,r0
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06030DD8 mov.b @(r0,r7),r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x06030E16u);  // 06030DDA mov.w 0x06030E16,r0
    c.r[3] &= c.r[0];  // 06030DDC and r0,r3
    c.r[3] |= c.r[10];  // 06030DDE or r10,r3
    c.r[0] = c.r[2];  // 06030DE0 mov r2,r0
    st8(c.r[0] + c.r[7], c.r[3]);  // 06030DE2 mov.b r3,@(r0,r7)
    c.r[2] += c.r[7];  // 06030DE4 add r7,r2
    c.r[2] += 1;  // 06030DE6 add #1,r2
    st8(c.r[2], c.r[1]);  // 06030DE8 mov.b r1,@r2
    c.r[2] = ld32(c.r[8]);  // 06030DEA mov.l @r8,r2
    c.r[0] = c.r[2];  // 06030DEC mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 06030DEE mov.b @(r0,r5),r1
    c.r[1] += 1;  // 06030DF0 add #1,r1
    st8(c.r[0] + c.r[5], c.r[1]);  // 06030DF2 mov.b r1,@(r0,r5)
L_06030DF4:
    c.r[6] += 1;  // 06030DF4 add #1,r6
    c.r[1] = 0x7Fu;  // 06030DF6 mov #127,r1
    c.t = (int32_t)c.r[6] > (int32_t)c.r[1];  // 06030DF8 cmp/gt r1,r6
    { const bool k = !c.t; c.r[4] += 30; if (k) { SH2_POLL(c); goto L_06030DB6; } }  // 06030DFA bf/s 0x06030DB6 ; add #30,r4
    c.r[15] = c.r[14];  // 06030DFE mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06030E00 mov.l @r15+,r14
    c.r[1] = ld32(0x06030E18u);  // 06030E02 mov.l 0x06030E18,r1
    c.r[1] = ld32(c.r[1]);  // 06030E04 mov.l @r1,r1
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06030E06 mov.l @r15+,r10
    c.r[0] = (uint32_t)(int16_t)ld16(0x06030E14u);  // 06030E08 mov.w 0x06030E14,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06030E0A mov.b @(r0,r1),r1
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06030E0C mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06030E0E mov.l @r15+,r8
    { const uint32_t x = c.pr; c.r[0] = c.r[1] & 0xFFu; c.pc = x; return; }  // 06030E10 rts ; extu.b r1,r0
}

void f_06030E20(SH2Context& c) {
    ran[695] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06030E20 mov.l r14,@-r15
    c.r[1] = ld32(0x06030E4Cu);  // 06030E22 mov.l 0x06030E4C,r1
    c.r[2] = ld32(c.r[1]);  // 06030E24 mov.l @r1,r2
    c.r[5] = c.r[5] & 0xFFFFu;  // 06030E26 extu.w r5,r5
    c.r[1] = 0x1Eu;  // 06030E28 mov #30,r1
    c.macl = c.r[5] * c.r[1];  // 06030E2A mul.l r1,r5
    c.r[14] = c.r[15];  // 06030E2C mov r15,r14
    c.r[3] = c.macl;  // 06030E2E sts macl,r3
    c.r[3] += c.r[2];  // 06030E30 add r2,r3
    c.r[2] = c.r[3];  // 06030E32 mov r3,r2
    c.r[2] += 22;  // 06030E34 add #22,r2
    c.r[1] = c.r[4];  // 06030E36 mov r4,r1
    c.r[1] += 26;  // 06030E38 add #26,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06030E3A mov.w @r1,r1
    c.r[4] += 28;  // 06030E3C add #28,r4
    st16(c.r[2], c.r[1]);  // 06030E3E mov.w r1,@r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[4]);  // 06030E40 mov.w @r4,r1
    c.r[3] += 24;  // 06030E42 add #24,r3
    st16(c.r[3], c.r[1]);  // 06030E44 mov.w r1,@r3
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06030E46 rts ; mov.l @r15+,r14
}

void f_06030E50(SH2Context& c) {
    ran[696] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06030E50 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06030E52 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06030E54 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06030E56 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06030E58 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06030E5A mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06030E5C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06030E5E sts.l pr,@-r15
    c.r[15] -= 8;  // 06030E60 add #-8,r15
    c.r[14] = c.r[15];  // 06030E62 mov r15,r14
    c.r[9] = c.r[6];  // 06030E64 mov r6,r9
    c.r[4] = c.r[4] & 0xFFu;  // 06030E66 extu.b r4,r4
    st32(c.r[14], c.r[4]);  // 06030E68 mov.l r4,@r14
    c.r[5] = c.r[5] & 0xFFu;  // 06030E6A extu.b r5,r5
    st32(c.r[14] + 4, c.r[5]);  // 06030E6C mov.l r5,@(4,r14)
    c.r[10] = 0x0u;  // 06030E6E mov #0,r10
    c.r[11] = 0x0u;  // 06030E70 mov #0,r11
    c.r[13] = ld32(0x06030F20u);  // 06030E72 mov.l 0x06030F20,r13
    c.r[12] = 0x0u;  // 06030E74 mov #0,r12
L_06030E76:
    c.r[1] = ld32(0x06030F24u);  // 06030E76 mov.l 0x06030F24,r1
    c.r[0] = ld32(c.r[1]);  // 06030E78 mov.l @r1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[12]);  // 06030E7A mov.w @(r0,r12),r1
    c.r[8] = c.r[1] & 0xFFFFu;  // 06030E7C extu.w r1,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 06030E7E tst r8,r8
    if (c.t) { goto L_06030EF4; }  // 06030E80 bt 0x06030EF4
    c.r[4] = ld32(0x06030F28u);  // 06030E82 mov.l 0x06030F28,r4
    { const uint32_t x = c.r[13]; c.pr = 0x06030E88u; c.r[5] = 0x1Bu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06030E88u) return; }  // 06030E84 jsr @r13 ; mov #27,r5
    c.r[1] = c.r[0];  // 06030E88 mov r0,r1
    c.r[5] = c.r[8];  // 06030E8A mov r8,r5
    { const uint32_t x = c.r[13]; c.pr = 0x06030E90u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06030E90u) return; }  // 06030E8C jsr @r13 ; mov r1,r4
    c.r[1] = c.r[0];  // 06030E90 mov r0,r1
    c.r[1] += 7;  // 06030E92 add #7,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06030E94 mov.b @r1,r2
    c.r[0] = ld32(c.r[14]);  // 06030E96 mov.l @r14,r0
    c.r[1] = 0x78u;  // 06030E98 mov #120,r1
    c.r[1] &= c.r[2];  // 06030E9A and r2,r1
    c.r[1] >>= 2;  // 06030E9C shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06030E9E shlr r1
    c.t = c.r[0] == c.r[1];  // 06030EA0 cmp/eq r1,r0
    { const bool k = !c.t; c.r[7] = 0x7u; if (k) { goto L_06030EF4; } }  // 06030EA2 bf/s 0x06030EF4 ; mov #7,r7
    c.r[7] &= c.r[2];  // 06030EA6 and r2,r7
    c.r[3] = c.r[7];  // 06030EA8 mov r7,r3
    c.r[3] += c.r[3];  // 06030EAA add r3,r3
    c.r[2] = c.r[7];  // 06030EAC mov r7,r2
    c.r[2] <<= 8;  // 06030EAE shll8 r2
    c.r[2] += c.r[10];  // 06030EB0 add r10,r2
    c.r[2] = c.r[2] & 0xFFFFu;  // 06030EB2 extu.w r2,r2
    c.r[6] = c.r[2];  // 06030EB4 mov r2,r6
    c.r[6] >>= 8;  // 06030EB6 shlr8 r6
    c.r[0] = 0x7Fu;  // 06030EB8 mov #127,r0
    c.r[6] &= c.r[0];  // 06030EBA and r0,r6
    c.r[0] = c.r[9];  // 06030EBC mov r9,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06030EBE mov.b @(r0,r3),r1
    c.t = (c.r[7] & c.r[7]) == 0;  // 06030EC0 tst r7,r7
    c.r[0] = (uint32_t)(int16_t)ld16(0x06030F1Au);  // 06030EC2 mov.w 0x06030F1A,r0
    c.r[1] &= c.r[0];  // 06030EC4 and r0,r1
    c.r[1] |= c.r[6];  // 06030EC6 or r6,r1
    c.r[0] = c.r[9];  // 06030EC8 mov r9,r0
    st8(c.r[0] + c.r[3], c.r[1]);  // 06030ECA mov.b r1,@(r0,r3)
    c.r[1] = c.r[9];  // 06030ECC mov r9,r1
    c.r[1] += c.r[3];  // 06030ECE add r3,r1
    c.r[1] += 1;  // 06030ED0 add #1,r1
    { const bool k = !c.t; st8(c.r[1], c.r[2]); if (k) { goto L_06030EE2; } }  // 06030ED2 bf/s 0x06030EE2 ; mov.b r2,@r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06030ED6 mov.b @(r0,r7),r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06030F1Au);  // 06030ED8 mov.w 0x06030F1A,r0
    c.r[1] |= c.r[0];  // 06030EDA or r0,r1
    c.r[0] = c.r[9];  // 06030EDC mov r9,r0
    st8(c.r[0] + c.r[7], c.r[1]); goto L_06030EEC;  // 06030EDE bra 0x06030EEC ; mov.b r1,@(r0,r7)
L_06030EE2:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06030EE2 mov.b @(r0,r3),r1
    c.r[0] = 0x7Fu;  // 06030EE4 mov #127,r0
    c.r[1] &= c.r[0];  // 06030EE6 and r0,r1
    c.r[0] = c.r[9];  // 06030EE8 mov r9,r0
    st8(c.r[0] + c.r[3], c.r[1]);  // 06030EEA mov.b r1,@(r0,r3)
L_06030EEC:
    c.r[0] = ld32(c.r[14] + 4);  // 06030EEC mov.l @(4,r14),r0
    c.r[11] += 1;  // 06030EEE add #1,r11
    c.t = c.r[11] == c.r[0];  // 06030EF0 cmp/eq r0,r11
    if (c.t) { goto L_06030EFE; }  // 06030EF2 bt 0x06030EFE
L_06030EF4:
    c.r[10] += 1;  // 06030EF4 add #1,r10
    c.r[1] = 0x7Fu;  // 06030EF6 mov #127,r1
    c.t = (int32_t)c.r[10] > (int32_t)c.r[1];  // 06030EF8 cmp/gt r1,r10
    { const bool k = !c.t; c.r[12] += 30; if (k) { SH2_POLL(c); goto L_06030E76; } }  // 06030EFA bf/s 0x06030E76 ; add #30,r12
L_06030EFE:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06030F1Cu);  // 06030EFE mov.w 0x06030F1C,r0
    st8(c.r[0] + c.r[9], c.r[11]);  // 06030F00 mov.b r11,@(r0,r9)
    c.r[14] += 8;  // 06030F02 add #8,r14
    c.r[15] = c.r[14];  // 06030F04 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06030F06 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06030F08 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06030F0A mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06030F0C mov.l @r15+,r12
    c.r[0] = c.r[11];  // 06030F0E mov r11,r0
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06030F10 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06030F12 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06030F14 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06030F16 rts ; mov.l @r15+,r8
}

void f_06030F2C(SH2Context& c) {
    ran[697] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06030F2C mov.l r14,@-r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x06030F6Eu);  // 06030F2E mov.w 0x06030F6E,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[4]);  // 06030F30 mov.b @(r0,r4),r1
    c.r[2] = 0x0u;  // 06030F32 mov #0,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06030F34 extu.b r1,r1
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[1];  // 06030F36 cmp/ge r1,r2
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06030F66; } }  // 06030F38 bt/s 0x06030F66 ; mov r15,r14
    c.r[3] = c.r[4];  // 06030F3C mov r4,r3
    c.r[0] = 0x0u;  // 06030F3E mov #0,r0
    c.r[7] = c.r[1];  // 06030F40 mov r1,r7
    c.r[7] += c.r[7];  // 06030F42 add r7,r7
L_06030F44:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[4]);  // 06030F44 mov.b @(r0,r4),r1
    c.r[2] = c.r[1] & 0xFFu;  // 06030F46 extu.b r1,r2
    c.r[1] = c.r[2];  // 06030F48 mov r2,r1
    c.r[1] >>= 2;  // 06030F4A shlr2 r1
    c.r[1] >>= 2;  // 06030F4C shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06030F4E shlr r1
    c.r[1] >>= 2;  // 06030F50 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06030F52 tst r1,r1
    { const bool k = c.t; c.r[0] += 2; if (k) { goto L_06030F60; } }  // 06030F54 bt/s 0x06030F60 ; add #2,r0
    c.r[3] += 1;  // 06030F58 add #1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06030F5A mov.b @r3,r1
    c.r[0] = c.r[1] & 0xFFu; goto L_06030F68;  // 06030F5C bra 0x06030F68 ; extu.b r1,r0
L_06030F60:
    c.t = (int32_t)c.r[0] >= (int32_t)c.r[7];  // 06030F60 cmp/ge r7,r0
    { const bool k = !c.t; c.r[3] += 2; if (k) { SH2_POLL(c); goto L_06030F44; } }  // 06030F62 bf/s 0x06030F44 ; add #2,r3
L_06030F66:
    c.r[0] = 0xFFFFFFFFu;  // 06030F66 mov #-1,r0
L_06030F68:
    c.r[15] = c.r[14];  // 06030F68 mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06030F6A rts ; mov.l @r15+,r14
}

void f_06030F70(SH2Context& c) {
    ran[698] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06030F70 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06030F72 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06030F74 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06030F76 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06030F78 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06030F7A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06030F7C sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x06031026u);  // 06030F7E mov.w 0x06031026,r3
    c.r[15] += c.r[3];  // 06030F80 add r3,r15
    c.r[14] = c.r[15];  // 06030F82 mov r15,r14
    c.r[12] = (uint32_t)(int16_t)ld16(0x06031028u);  // 06030F84 mov.w 0x06031028,r12
    c.r[12] += c.r[14];  // 06030F86 add r14,r12
    c.r[11] = c.r[4] & 0xFFFFu;  // 06030F88 extu.w r4,r11
    c.r[10] = c.r[5] & 0xFFu;  // 06030F8A extu.b r5,r10
    c.r[5] = c.r[6] & 0xFFu;  // 06030F8C extu.b r6,r5
    c.r[6] = c.r[7] & 0xFFu;  // 06030F8E extu.b r7,r6
    c.r[2] = 0x0u;  // 06030F90 mov #0,r2
    c.r[8] = 0x1Eu;  // 06030F92 mov #30,r8
    c.r[1] = ld32(c.r[12]);  // 06030F94 mov.l @r12,r1
    c.r[4] = 0x7Fu;  // 06030F96 mov #127,r4
    c.r[7] = c.r[1] & 0xFFu;  // 06030F98 extu.b r1,r7
    c.r[1] = ld32(0x06031030u);  // 06030F9A mov.l 0x06031030,r1
    c.r[3] = ld32(c.r[1]);  // 06030F9C mov.l @r1,r3
    c.macl = c.r[2] * c.r[8];  // 06030F9E mul.l r8,r2
L_06030FA0:
    c.r[0] = c.macl;  // 06030FA0 sts macl,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 06030FA2 mov.w @(r0,r3),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06030FA4 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06030FA6 tst r1,r1
    { const bool k = !c.t; c.r[1] = c.r[2]; if (k) { goto L_06030FB0; } }  // 06030FA8 bf/s 0x06030FB0 ; mov r2,r1
    c.r[0] = c.r[2]; goto L_06030FBC;  // 06030FAC bra 0x06030FBC ; mov r2,r0
L_06030FB0:
    c.r[1] += 1;  // 06030FB0 add #1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 06030FB2 extu.b r1,r2
    c.t = c.r[2] > c.r[4];  // 06030FB4 cmp/hi r4,r2
    { const bool k = !c.t; c.macl = c.r[2] * c.r[8]; if (k) { SH2_POLL(c); goto L_06030FA0; } }  // 06030FB6 bf/s 0x06030FA0 ; mul.l r8,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0603102Au);  // 06030FBA mov.w 0x0603102A,r0
L_06030FBC:
    c.r[8] = c.r[0] & 0xFFu;  // 06030FBC extu.b r0,r8
    c.r[9] = (uint32_t)(int16_t)ld16(0x0603102Au);  // 06030FBE mov.w 0x0603102A,r9
    c.t = c.r[8] == c.r[9];  // 06030FC0 cmp/eq r9,r8
    if (c.t) { goto L_0603100E; }  // 06030FC2 bt 0x0603100E
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 06030FC4 mov.l r7,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[6]);  // 06030FC6 mov.l r6,@-r15
    c.r[1] = ld32(0x06031034u);  // 06030FC8 mov.l 0x06031034,r1
    c.r[7] = c.r[5];  // 06030FCA mov r5,r7
    c.r[6] = c.r[10];  // 06030FCC mov r10,r6
    c.r[5] = c.r[8];  // 06030FCE mov r8,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06030FD4u; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06030FD4u) return; }  // 06030FD0 jsr @r1 ; mov r11,r4
    c.r[1] = ld32(0x06031038u);  // 06030FD4 mov.l 0x06031038,r1
    c.r[6] = c.r[9];  // 06030FD6 mov r9,r6
    c.r[5] = c.r[8];  // 06030FD8 mov r8,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06030FDEu; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06030FDEu) return; }  // 06030FDA jsr @r1 ; mov r14,r4
    c.r[3] = c.r[8] & 0xFFFFu;  // 06030FDE extu.w r8,r3
    c.r[15] += 8;  // 06030FE0 add #8,r15
    c.r[1] = ld32(0x06031030u);  // 06030FE2 mov.l 0x06031030,r1
    c.r[2] = ld32(c.r[1]);  // 06030FE4 mov.l @r1,r2
    c.r[0] = ld32(0x0603103Cu);  // 06030FE6 mov.l 0x0603103C,r0
    c.r[1] = 0x1Eu;  // 06030FE8 mov #30,r1
    c.macl = c.r[3] * c.r[1];  // 06030FEA mul.l r1,r3
    c.r[5] = c.r[11];  // 06030FEC mov r11,r5
    c.r[4] = c.r[8];  // 06030FEE mov r8,r4
    c.r[3] = c.macl;  // 06030FF0 sts macl,r3
    c.r[3] += c.r[2];  // 06030FF2 add r2,r3
    c.r[2] = c.r[3];  // 06030FF4 mov r3,r2
    c.r[1] = c.r[14];  // 06030FF6 mov r14,r1
    c.r[1] += 26;  // 06030FF8 add #26,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06030FFA mov.w @r1,r1
    c.r[2] += 22;  // 06030FFC add #22,r2
    st16(c.r[2], c.r[1]);  // 06030FFE mov.w r1,@r2
    c.r[1] = c.r[14];  // 06031000 mov r14,r1
    c.r[1] += 28;  // 06031002 add #28,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06031004 mov.w @r1,r1
    c.r[3] += 24;  // 06031006 add #24,r3
    { const uint32_t x = c.r[0]; c.pr = 0x0603100Cu; st16(c.r[3], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603100Cu) return; }  // 06031008 jsr @r0 ; mov.w r1,@r3
    c.r[8] = c.r[0] & 0xFFu;  // 0603100C extu.b r0,r8
L_0603100E:
    c.r[3] = (uint32_t)(int16_t)ld16(0x0603102Cu);  // 0603100E mov.w 0x0603102C,r3
    c.r[14] += c.r[3];  // 06031010 add r3,r14
    c.r[15] = c.r[14];  // 06031012 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06031014 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06031016 mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06031018 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0603101A mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0603101C mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0603101E mov.l @r15+,r9
    c.r[0] = c.r[8];  // 06031020 mov r8,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06031022 rts ; mov.l @r15+,r8
}

void f_06031040(SH2Context& c) {
    ran[699] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06031040 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06031042 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06031044 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06031046 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06031048 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0603104A mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603104C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603104E sts.l pr,@-r15
    c.r[15] -= 4;  // 06031050 add #-4,r15
    c.r[14] = c.r[15];  // 06031052 mov r15,r14
    c.r[2] = c.r[4];  // 06031054 mov r4,r2
    c.r[3] = c.r[6];  // 06031056 mov r6,r3
    c.r[12] = c.r[5] & 0xFFu;  // 06031058 extu.b r5,r12
    c.r[7] = c.r[7] & 0xFFu;  // 0603105A extu.b r7,r7
    c.r[8] = ld32(0x060311A8u);  // 0603105C mov.l 0x060311A8,r8
    c.r[11] = 0x1Eu;  // 0603105E mov #30,r11
    c.r[7] <<= 2;  // 06031060 shll2 r7
    c.r[7] <<= 2;  // 06031062 shll2 r7
    c.r[7] <<= 2;  // 06031064 shll2 r7
    c.r[10] = 0xFFFFFFFFu;  // 06031066 mov #-1,r10
    c.r[13] = 0x3u;  // 06031068 mov #3,r13
    c.r[3] &= c.r[13];  // 0603106A and r13,r3
    c.r[1] = ld32(c.r[14] + 40);  // 0603106C mov.l @(40,r14),r1
    c.macl = c.r[12] * c.r[11];  // 0603106E mul.l r11,r12
    c.r[1] = c.r[1] & 0xFFu;  // 06031070 extu.b r1,r1
    st32(c.r[14], c.r[1]);  // 06031072 mov.l r1,@r14
    c.r[1] = ld32(c.r[8]);  // 06031074 mov.l @r8,r1
    c.r[9] = c.macl;  // 06031076 sts macl,r9
    c.r[1] += c.r[9];  // 06031078 add r9,r1
    st16(c.r[1], c.r[2]);  // 0603107A mov.w r2,@r1
    c.r[1] += 2;  // 0603107C add #2,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603107E mov.b @r1,r0
    c.r[3] <<= 2;  // 06031080 shll2 r3
    c.r[3] += c.r[3];  // 06031082 add r3,r3
    c.r[4] = ld32(c.r[14] + 36);  // 06031084 mov.l @(36,r14),r4
    c.r[0] &= 0x3Fu;  // 06031086 and #63,r0
    c.r[0] |= c.r[7];  // 06031088 or r7,r0
    st8(c.r[1], c.r[0]);  // 0603108A mov.b r0,@r1
    c.r[1] = ld32(c.r[8]);  // 0603108C mov.l @r8,r1
    c.r[2] = c.macl;  // 0603108E sts macl,r2
    c.r[2] += c.r[1];  // 06031090 add r1,r2
    c.r[2] += 15;  // 06031092 add #15,r2
    st8(c.r[2], c.r[10]);  // 06031094 mov.b r10,@r2
    c.r[1] = ld32(c.r[8]);  // 06031096 mov.l @r8,r1
    c.r[2] = c.macl;  // 06031098 sts macl,r2
    c.r[2] += c.r[1];  // 0603109A add r1,r2
    c.r[2] += 2;  // 0603109C add #2,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0603109E mov.b @r2,r0
    c.r[0] &= 0xE7u;  // 060310A0 and #231,r0
    c.r[0] |= c.r[3];  // 060310A2 or r3,r0
    st8(c.r[2], c.r[0]);  // 060310A4 mov.b r0,@r2
    c.r[0] = ld32(0x060311ACu);  // 060310A6 mov.l 0x060311AC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060310ACu; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060310ACu) return; }  // 060310A8 jsr @r0 ; extu.b r4,r4
    c.macl = c.r[9];  // 060310AC lds r9,macl
    c.r[1] = ld32(c.r[8]);  // 060310AE mov.l @r8,r1
    c.r[2] = c.macl;  // 060310B0 sts macl,r2
    c.r[2] += c.r[1];  // 060310B2 add r1,r2
    c.r[2] += 26;  // 060310B4 add #26,r2
    st8(c.r[2], c.r[0]);  // 060310B6 mov.b r0,@r2
    c.r[1] = ld32(c.r[8]);  // 060310B8 mov.l @r8,r1
    c.r[2] = c.macl;  // 060310BA sts macl,r2
    c.r[2] += c.r[1];  // 060310BC add r1,r2
    c.r[2] += 2;  // 060310BE add #2,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060310C0 mov.b @r2,r0
    c.r[0] &= 0xDFu;  // 060310C2 and #223,r0
    st8(c.r[2], c.r[0]);  // 060310C4 mov.b r0,@r2
    c.r[1] = ld32(c.r[8]);  // 060310C6 mov.l @r8,r1
    c.r[2] = c.macl;  // 060310C8 sts macl,r2
    c.r[2] += c.r[1];  // 060310CA add r1,r2
    c.r[2] += 3;  // 060310CC add #3,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060310CE mov.b @r2,r0
    c.r[0] &= 0x87u;  // 060310D0 and #135,r0
    st8(c.r[2], c.r[0]);  // 060310D2 mov.b r0,@r2
    c.r[2] = ld32(c.r[8]);  // 060310D4 mov.l @r8,r2
    c.r[1] = c.macl;  // 060310D6 sts macl,r1
    c.r[1] += c.r[2];  // 060310D8 add r2,r1
    c.r[2] = c.r[1];  // 060310DA mov r1,r2
    c.r[2] += 3;  // 060310DC add #3,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060310DE mov.b @r2,r0
    c.r[1] += 4;  // 060310E0 add #4,r1
    c.r[0] &= 0xF8u;  // 060310E2 and #248,r0
    st8(c.r[2], c.r[0]);  // 060310E4 mov.b r0,@r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060310E6 mov.b @r1,r0
    c.r[6] = 0x3u;  // 060310E8 mov #3,r6
    c.r[0] &= 0x7Fu;  // 060310EA and #127,r0
    st8(c.r[1], c.r[0]);  // 060310EC mov.b r0,@r1
    c.r[1] = ld32(c.r[8]);  // 060310EE mov.l @r8,r1
    c.r[2] = c.macl;  // 060310F0 sts macl,r2
    c.r[2] += c.r[1];  // 060310F2 add r1,r2
    c.r[2] += 4;  // 060310F4 add #4,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060310F6 mov.b @r2,r0
    c.r[3] = c.macl;  // 060310F8 sts macl,r3
    c.r[0] &= 0x87u;  // 060310FA and #135,r0
    st8(c.r[2], c.r[0]);  // 060310FC mov.b r0,@r2
    c.r[1] = ld32(c.r[8]);  // 060310FE mov.l @r8,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x060311A4u);  // 06031100 mov.w 0x060311A4,r2
    c.r[3] += c.r[1];  // 06031102 add r1,r3
    c.r[7] = c.r[3];  // 06031104 mov r3,r7
    c.r[7] += 4;  // 06031106 add #4,r7
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[7]);  // 06031108 mov.w @r7,r1
    c.r[3] += 5;  // 0603110A add #5,r3
    c.r[1] &= c.r[2];  // 0603110C and r2,r1
    st16(c.r[7], c.r[1]);  // 0603110E mov.w r1,@r7
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06031110 mov.b @r3,r0
    c.r[1] = c.macl;  // 06031112 sts macl,r1
    c.r[0] &= 0x87u;  // 06031114 and #135,r0
    st8(c.r[3], c.r[0]);  // 06031116 mov.b r0,@r3
    c.r[2] = ld32(c.r[8]);  // 06031118 mov.l @r8,r2
    c.r[7] = 0x0u;  // 0603111A mov #0,r7
    c.r[1] += c.r[2];  // 0603111C add r2,r1
    c.r[2] = c.r[1];  // 0603111E mov r1,r2
    c.r[2] += 5;  // 06031120 add #5,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06031122 mov.b @r2,r0
    c.r[1] += 6;  // 06031124 add #6,r1
    c.r[0] &= 0xF8u;  // 06031126 and #248,r0
    st8(c.r[2], c.r[0]);  // 06031128 mov.b r0,@r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603112A mov.b @r1,r0
    c.r[3] = 0x0u;  // 0603112C mov #0,r3
    c.r[0] &= 0x7Fu;  // 0603112E and #127,r0
    st8(c.r[1], c.r[0]);  // 06031130 mov.b r0,@r1
    c.r[1] = ld32(c.r[8]);  // 06031132 mov.l @r8,r1
    c.r[2] = c.macl;  // 06031134 sts macl,r2
    c.r[2] += c.r[1];  // 06031136 add r1,r2
    c.r[2] += 16;  // 06031138 add #16,r2
    st8(c.r[2], c.r[10]);  // 0603113A mov.b r10,@r2
    c.macl = c.r[12] * c.r[11];  // 0603113C mul.l r11,r12
L_0603113E:
    c.r[1] = ld32(c.r[8]);  // 0603113E mov.l @r8,r1
    c.r[2] = c.macl;  // 06031140 sts macl,r2
    c.r[2] += c.r[1];  // 06031142 add r1,r2
    c.r[2] += c.r[3];  // 06031144 add r3,r2
    c.r[2] += 17;  // 06031146 add #17,r2
    c.r[3] += 1;  // 06031148 add #1,r3
    c.t = (int32_t)c.r[3] > (int32_t)c.r[6];  // 0603114A cmp/gt r6,r3
    { const bool k = !c.t; st8(c.r[2], c.r[7]); if (k) { SH2_POLL(c); goto L_0603113E; } }  // 0603114C bf/s 0x0603113E ; mov.b r7,@r2
    c.r[3] = 0x0u;  // 06031150 mov #0,r3
    c.r[4] = 0x7u;  // 06031152 mov #7,r4
    c.r[5] = ld32(0x060311A8u);  // 06031154 mov.l 0x060311A8,r5
    c.r[7] = ld32(c.r[14]);  // 06031156 mov.l @r14,r7
    c.r[6] = 0x1Eu;  // 06031158 mov #30,r6
    c.r[13] = ld32(c.r[14]);  // 0603115A mov.l @r14,r13
    c.r[7] <<= 2;  // 0603115C shll2 r7
    c.r[7] <<= 2;  // 0603115E shll2 r7
    c.r[7] |= c.r[13];  // 06031160 or r13,r7
    c.macl = c.r[12] * c.r[6];  // 06031162 mul.l r6,r12
L_06031164:
    c.r[1] = ld32(c.r[5]);  // 06031164 mov.l @r5,r1
    c.r[2] = c.macl;  // 06031166 sts macl,r2
    c.r[2] += c.r[1];  // 06031168 add r1,r2
    c.r[2] += c.r[3];  // 0603116A add r3,r2
    c.r[2] += 7;  // 0603116C add #7,r2
    c.r[3] += 1;  // 0603116E add #1,r3
    c.t = (int32_t)c.r[3] > (int32_t)c.r[4];  // 06031170 cmp/gt r4,r3
    { const bool k = !c.t; st8(c.r[2], c.r[7]); if (k) { SH2_POLL(c); goto L_06031164; } }  // 06031172 bf/s 0x06031164 ; mov.b r7,@r2
    c.r[1] = ld32(0x060311A8u);  // 06031176 mov.l 0x060311A8,r1
    c.r[2] = ld32(c.r[1]);  // 06031178 mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 0603117A mov #30,r1
    c.macl = c.r[12] * c.r[1];  // 0603117C mul.l r1,r12
    c.r[14] += 4;  // 0603117E add #4,r14
    c.r[15] = c.r[14];  // 06031180 mov r14,r15
    c.r[3] = c.macl;  // 06031182 sts macl,r3
    c.r[3] += c.r[2];  // 06031184 add r2,r3
    c.r[1] = c.r[3];  // 06031186 mov r3,r1
    c.r[1] += 22;  // 06031188 add #22,r1
    c.r[2] = 0x0u;  // 0603118A mov #0,r2
    st16(c.r[1], c.r[2]);  // 0603118C mov.w r2,@r1
    c.r[3] += 24;  // 0603118E add #24,r3
    st16(c.r[3], c.r[2]);  // 06031190 mov.w r2,@r3
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06031192 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06031194 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06031196 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06031198 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0603119A mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0603119C mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0603119E mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060311A0 rts ; mov.l @r15+,r8
}

void f_060311B0(SH2Context& c) {
    ran[700] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060311B0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060311B2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060311B4 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060311B6 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060311B8 sts.l pr,@-r15
    c.r[15] -= 16;  // 060311BA add #-16,r15
    c.r[14] = c.r[15];  // 060311BC mov r15,r14
    c.r[0] = ld32(0x06031290u);  // 060311BE mov.l 0x06031290,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060311C4u; c.r[10] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060311C4u) return; }  // 060311C0 jsr @r0 ; extu.b r4,r10
    c.r[1] = ld32(0x06031294u);  // 060311C4 mov.l 0x06031294,r1
    c.r[1] = ld32(c.r[1]);  // 060311C6 mov.l @r1,r1
    c.r[8] = ld32(0x06031298u);  // 060311C8 mov.l 0x06031298,r8
    c.r[2] = ld32(c.r[8]);  // 060311CA mov.l @r8,r2
    c.macl = c.r[0] * c.r[1];  // 060311CC mul.l r1,r0
    c.r[9] = (uint32_t)(int16_t)ld16(0x0603128Cu);  // 060311CE mov.w 0x0603128C,r9
    c.r[2] += 1;  // 060311D0 add #1,r2
    c.r[1] = c.macl;  // 060311D2 sts macl,r1
    c.r[1] >>= 16;  // 060311D4 shlr16 r1
    c.r[2] += c.r[1];  // 060311D6 add r1,r2
    c.t = c.r[10] == c.r[9];  // 060311D8 cmp/eq r9,r10
    { const bool k = c.t; st32(c.r[8], c.r[2]); if (k) { goto L_0603127A; } }  // 060311DA bt/s 0x0603127A ; mov.l r2,@r8
    c.r[4] = ld32(0x0603129Cu);  // 060311DE mov.l 0x0603129C,r4
    c.r[8] = ld32(0x060312A0u);  // 060311E0 mov.l 0x060312A0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060311E6u; c.r[5] = 0x20u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060311E6u) return; }  // 060311E2 jsr @r8 ; mov #32,r5
    c.r[1] = c.r[0];  // 060311E6 mov r0,r1
    c.r[5] = c.r[10];  // 060311E8 mov r10,r5
    { const uint32_t x = c.r[8]; c.pr = 0x060311EEu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060311EEu) return; }  // 060311EA jsr @r8 ; mov r1,r4
    c.r[2] = c.r[0];  // 060311EE mov r0,r2
    c.r[8] = 0x0u;  // 060311F0 mov #0,r8
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 060311F2 mov.b @(r0,r8),r3
    c.r[1] = c.r[3] & 0xFFu;  // 060311F4 extu.b r3,r1
    c.t = c.r[1] == c.r[9];  // 060311F6 cmp/eq r9,r1
    { const bool k = c.t; c.r[7] = 0x0u; if (k) { goto L_0603122A; } }  // 060311F8 bt/s 0x0603122A ; mov #0,r7
    c.r[6] = c.r[9];  // 060311FC mov r9,r6
    c.r[5] = c.r[14];  // 060311FE mov r14,r5
    c.r[5] += 1;  // 06031200 add #1,r5
    c.r[4] = c.r[2];  // 06031202 mov r2,r4
L_06031204:
    c.r[2] = c.r[4];  // 06031204 mov r4,r2
    c.r[2] += 1;  // 06031206 add #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06031208 mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0603120A extu.b r1,r1
    c.t = c.r[1] == c.r[6];  // 0603120C cmp/eq r6,r1
    { const bool k = c.t; c.r[0] = c.r[14]; if (k) { goto L_0603122A; } }  // 0603120E bt/s 0x0603122A ; mov r14,r0
    st8(c.r[0] + c.r[8], c.r[3]);  // 06031212 mov.b r3,@(r0,r8)
    c.r[0] = c.r[5];  // 06031214 mov r5,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06031216 mov.b @r2,r1
    c.r[4] += 2;  // 06031218 add #2,r4
    c.r[1] = c.r[1] & 0xFFu;  // 0603121A extu.b r1,r1
    c.r[7] += c.r[1];  // 0603121C add r1,r7
    st8(c.r[0] + c.r[8], c.r[7]);  // 0603121E mov.b r7,@(r0,r8)
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[4]);  // 06031220 mov.b @r4,r3
    c.r[1] = c.r[3] & 0xFFu;  // 06031222 extu.b r3,r1
    c.t = c.r[1] == c.r[6];  // 06031224 cmp/eq r6,r1
    { const bool k = !c.t; c.r[8] += 2; if (k) { SH2_POLL(c); goto L_06031204; } }  // 06031226 bf/s 0x06031204 ; add #2,r8
L_0603122A:
    c.r[1] = 0x63u;  // 0603122A mov #99,r1
    c.t = (int32_t)c.r[7] > (int32_t)c.r[1];  // 0603122C cmp/gt r1,r7
    { const bool k = c.t; c.r[1] = 0xFFFFFFFFu; if (k) { goto L_06031242; } }  // 0603122E bt/s 0x06031242 ; mov #-1,r1
    c.r[0] = c.r[14];  // 06031232 mov r14,r0
    st8(c.r[0] + c.r[8], c.r[1]);  // 06031234 mov.b r1,@(r0,r8)
    c.r[2] = c.r[14];  // 06031236 mov r14,r2
    c.r[2] += 1;  // 06031238 add #1,r2
    c.r[1] = 0x64u;  // 0603123A mov #100,r1
    c.r[0] = c.r[2];  // 0603123C mov r2,r0
    st8(c.r[0] + c.r[8], c.r[1]);  // 0603123E mov.b r1,@(r0,r8)
    c.r[8] += 2;  // 06031240 add #2,r8
L_06031242:
    c.r[0] = ld32(0x06031290u);  // 06031242 mov.l 0x06031290,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06031248u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06031248u) return; }  // 06031244 jsr @r0 ; nop
    c.r[1] = 0x64u;  // 06031248 mov #100,r1
    c.macl = c.r[0] * c.r[1];  // 0603124A mul.l r1,r0
    c.r[7] = 0x0u;  // 0603124C mov #0,r7
    c.r[1] = c.macl;  // 0603124E sts macl,r1
    c.r[1] >>= 16;  // 06031250 shlr16 r1
    c.r[1] += 1;  // 06031252 add #1,r1
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[8];  // 06031254 cmp/ge r8,r7
    { const bool k = c.t; c.r[3] = c.r[1] & 0xFFu; if (k) { goto L_0603127A; } }  // 06031256 bt/s 0x0603127A ; extu.b r1,r3
    c.r[2] = c.r[14];  // 0603125A mov r14,r2
    c.r[2] += 1;  // 0603125C add #1,r2
    c.r[0] = c.r[2];  // 0603125E mov r2,r0
L_06031260:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06031260 mov.b @(r0,r7),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06031262 extu.b r1,r1
    c.t = c.r[3] > c.r[1];  // 06031264 cmp/hi r1,r3
    { const bool k = c.t; c.r[0] = c.r[14]; if (k) { goto L_06031272; } }  // 06031266 bt/s 0x06031272 ; mov r14,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0603126A mov.b @(r0,r7),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0603126C extu.b r1,r1
    c.r[0] = c.r[1]; goto L_0603127C;  // 0603126E bra 0x0603127C ; mov r1,r0
L_06031272:
    c.r[7] += 2;  // 06031272 add #2,r7
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[8];  // 06031274 cmp/ge r8,r7
    { const bool k = !c.t; c.r[0] = c.r[2]; if (k) { SH2_POLL(c); goto L_06031260; } }  // 06031276 bf/s 0x06031260 ; mov r2,r0
L_0603127A:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0603128Cu);  // 0603127A mov.w 0x0603128C,r0
L_0603127C:
    c.r[14] += 16;  // 0603127C add #16,r14
    c.r[15] = c.r[14];  // 0603127E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06031280 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06031282 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06031284 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06031286 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06031288 rts ; mov.l @r15+,r8
}

void f_060312A4(SH2Context& c) {
    ran[701] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060312A4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060312A6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060312A8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060312AA mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060312AC mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060312AE mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060312B0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060312B2 sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x06031358u);  // 060312B4 mov.w 0x06031358,r3
    c.r[15] += c.r[3];  // 060312B6 add r3,r15
    c.r[14] = c.r[15];  // 060312B8 mov r15,r14
    c.r[13] = c.r[4] & 0xFFu;  // 060312BA extu.b r4,r13
    c.r[12] = c.r[5] & 0xFFu;  // 060312BC extu.b r5,r12
    c.r[9] = 0x0u;  // 060312BE mov #0,r9
    c.r[11] = ld32(0x06031364u);  // 060312C0 mov.l 0x06031364,r11
    c.r[10] = (uint32_t)(int16_t)ld16(0x0603135Au);  // 060312C2 mov.w 0x0603135A,r10
L_060312C4:
    c.r[1] = ld32(0x06031368u);  // 060312C4 mov.l 0x06031368,r1
    c.r[2] = ld32(c.r[1]);  // 060312C6 mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 060312C8 mov #30,r1
    c.macl = c.r[9] * c.r[1];  // 060312CA mul.l r1,r9
    c.r[0] = c.macl;  // 060312CC sts macl,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 060312CE mov.w @(r0,r2),r1
    c.r[8] = c.r[1] & 0xFFFFu;  // 060312D0 extu.w r1,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 060312D2 tst r8,r8
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_06031334; } }  // 060312D4 bt/s 0x06031334 ; mov r9,r1
    c.r[4] = ld32(0x0603136Cu);  // 060312D8 mov.l 0x0603136C,r4
    { const uint32_t x = c.r[11]; c.pr = 0x060312DEu; c.r[5] = 0x1Bu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060312DEu) return; }  // 060312DA jsr @r11 ; mov #27,r5
    c.r[1] = c.r[0];  // 060312DE mov r0,r1
    c.r[5] = c.r[8];  // 060312E0 mov r8,r5
    { const uint32_t x = c.r[11]; c.pr = 0x060312E6u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060312E6u) return; }  // 060312E2 jsr @r11 ; mov r1,r4
    c.r[2] = c.r[0];  // 060312E6 mov r0,r2
    c.r[2] += 7;  // 060312E8 add #7,r2
    c.r[3] = 0x78u;  // 060312EA mov #120,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060312EC mov.b @r2,r1
    c.r[0] = c.r[14];  // 060312EE mov r14,r0
    c.r[3] &= c.r[1];  // 060312F0 and r1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 060312F2 mov.b @(r0,r10),r1
    c.r[3] >>= 2;  // 060312F4 shlr2 r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x0603135Cu);  // 060312F6 mov.w 0x0603135C,r0
    c.r[1] &= c.r[0];  // 060312F8 and r0,r1
    c.r[1] |= c.r[3];  // 060312FA or r3,r1
    c.r[0] = c.r[14];  // 060312FC mov r14,r0
    st8(c.r[0] + c.r[10], c.r[1]);  // 060312FE mov.b r1,@(r0,r10)
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06031300 mov.b @r2,r2
    c.r[0] = 0x7u;  // 06031302 mov #7,r0
    c.r[2] &= c.r[0];  // 06031304 and r0,r2
    c.r[2] <<= 2;  // 06031306 shll2 r2
    c.r[2] += c.r[2];  // 06031308 add r2,r2
    c.r[2] <<= 2;  // 0603130A shll2 r2
    c.r[0] = 0x1Fu;  // 0603130C mov #31,r0
    c.r[1] &= c.r[0];  // 0603130E and r0,r1
    c.r[1] |= c.r[2];  // 06031310 or r2,r1
    c.r[0] = c.r[14];  // 06031312 mov r14,r0
    st8(c.r[0] + c.r[10], c.r[1]);  // 06031314 mov.b r1,@(r0,r10)
    c.r[2] = c.r[1];  // 06031316 mov r1,r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 06031318 shlr r2
    c.r[0] = 0xFu;  // 0603131A mov #15,r0
    c.r[2] &= c.r[0];  // 0603131C and r0,r2
    c.t = c.r[2] == c.r[13];  // 0603131E cmp/eq r13,r2
    { const bool k = !c.t; c.r[1] >>= 2; if (k) { goto L_06031332; } }  // 06031320 bf/s 0x06031332 ; shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06031324 shlr r1
    c.r[1] >>= 2;  // 06031326 shlr2 r1
    c.t = c.r[1] == c.r[12];  // 06031328 cmp/eq r12,r1
    { const bool k = !c.t; c.r[1] = c.r[9]; if (k) { goto L_06031334; } }  // 0603132A bf/s 0x06031334 ; mov r9,r1
    c.r[0] = c.r[9]; goto L_06031340;  // 0603132E bra 0x06031340 ; mov r9,r0
L_06031332:
    c.r[1] = c.r[9];  // 06031332 mov r9,r1
L_06031334:
    c.r[1] += 1;  // 06031334 add #1,r1
    c.r[9] = c.r[1] & 0xFFu;  // 06031336 extu.b r1,r9
    c.r[1] = 0x7Fu;  // 06031338 mov #127,r1
    c.t = c.r[9] > c.r[1];  // 0603133A cmp/hi r1,r9
    if (!c.t) { SH2_POLL(c); goto L_060312C4; }  // 0603133C bf 0x060312C4
    c.r[0] = (uint32_t)(int16_t)ld16(0x0603135Eu);  // 0603133E mov.w 0x0603135E,r0
L_06031340:
    c.r[3] = (uint32_t)(int16_t)ld16(0x06031360u);  // 06031340 mov.w 0x06031360,r3
    c.r[14] += c.r[3];  // 06031342 add r3,r14
    c.r[15] = c.r[14];  // 06031344 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06031346 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06031348 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0603134A mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0603134C mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0603134E mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06031350 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06031352 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06031354 rts ; mov.l @r15+,r8
}

void f_06031370(SH2Context& c) {
    ran[702] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06031370 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06031372 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06031374 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06031376 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06031378 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603137A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603137C sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x06031464u);  // 0603137E mov.w 0x06031464,r3
    c.r[15] += c.r[3];  // 06031380 add r3,r15
    c.r[14] = c.r[15];  // 06031382 mov r15,r14
    c.r[8] = c.r[5];  // 06031384 mov r5,r8
    c.r[4] = c.r[4] & 0xFFFFu;  // 06031386 extu.w r4,r4
    c.r[8] = c.r[8] & 0xFFFFu;  // 06031388 extu.w r8,r8
    c.r[5] = c.r[8];  // 0603138A mov r8,r5
    c.r[9] = ld32(0x0603146Cu);  // 0603138C mov.l 0x0603146C,r9
    c.r[1] = ld32(c.r[9]);  // 0603138E mov.l @r9,r1
    c.r[5] >>= 8;  // 06031390 shlr8 r5
    c.t = c.r[5] & 1; c.r[5] >>= 1;  // 06031392 shlr r5
    c.r[1] += 8;  // 06031394 add #8,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06031396 mov.b @r1,r6
    c.r[0] = ld32(0x06031470u);  // 06031398 mov.l 0x06031470,r0
    c.r[6] = c.r[6] & 0xFFu;  // 0603139A extu.b r6,r6
    c.r[6] >>= 2;  // 0603139C shlr2 r6
    c.r[6] >>= 2;  // 0603139E shlr2 r6
    { const uint32_t x = c.r[0]; c.pr = 0x060313A4u; c.r[6] >>= 2; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060313A4u) return; }  // 060313A0 jsr @r0 ; shlr2 r6
    c.r[11] = c.r[0] & 0xFFu;  // 060313A4 extu.b r0,r11
    c.r[2] = (uint32_t)(int16_t)ld16(0x06031466u);  // 060313A6 mov.w 0x06031466,r2
    c.r[10] = c.r[2];  // 060313A8 mov r2,r10
    c.r[10] &= c.r[8];  // 060313AA and r8,r10
    c.r[12] = (uint32_t)(int16_t)ld16(0x06031468u);  // 060313AC mov.w 0x06031468,r12
    c.r[4] = 0x0u;  // 060313AE mov #0,r4
    c.r[2] = 0x0u;  // 060313B0 mov #0,r2
    c.r[1] = ld32(c.r[9]);  // 060313B2 mov.l @r9,r1
    c.r[5] = 0x1Eu;  // 060313B4 mov #30,r5
    c.r[1] += 8;  // 060313B6 add #8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060313B8 mov.b @r1,r1
    c.r[6] = 0x7Fu;  // 060313BA mov #127,r6
    c.r[7] = c.r[1] & 0xFFu;  // 060313BC extu.b r1,r7
    c.r[7] >>= 2;  // 060313BE shlr2 r7
    c.r[7] >>= 2;  // 060313C0 shlr2 r7
    c.r[7] >>= 2;  // 060313C2 shlr2 r7
    c.r[1] = ld32(0x06031474u);  // 060313C4 mov.l 0x06031474,r1
    c.r[3] = ld32(c.r[1]);  // 060313C6 mov.l @r1,r3
    c.macl = c.r[2] * c.r[5];  // 060313C8 mul.l r5,r2
L_060313CA:
    c.r[0] = c.macl;  // 060313CA sts macl,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 060313CC mov.w @(r0,r3),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 060313CE extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060313D0 tst r1,r1
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_06031448; } }  // 060313D2 bt/s 0x06031448 ; mov r2,r1
    c.r[1] += 1;  // 060313D6 add #1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 060313D8 extu.b r1,r2
    c.t = c.r[2] > c.r[6];  // 060313DA cmp/hi r6,r2
    { const bool k = !c.t; c.macl = c.r[2] * c.r[5]; if (k) { SH2_POLL(c); goto L_060313CA; } }  // 060313DC bf/s 0x060313CA ; mul.l r5,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x06031468u);  // 060313E0 mov.w 0x06031468,r3
L_060313E2:
    c.r[8] = c.r[3] & 0xFFu;  // 060313E2 extu.b r3,r8
    c.r[9] = (uint32_t)(int16_t)ld16(0x06031468u);  // 060313E4 mov.w 0x06031468,r9
    c.t = c.r[8] == c.r[9];  // 060313E6 cmp/eq r9,r8
    { const bool k = c.t; c.t = c.r[11] == c.r[9]; if (k) { goto L_06031436; } }  // 060313E8 bt/s 0x06031436 ; cmp/eq r9,r11
    c.r[15] -= 4; st32(c.r[15], c.r[4]);  // 060313EC mov.l r4,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060313EE mov.l r12,@-r15
    c.r[1] = ld32(0x06031478u);  // 060313F0 mov.l 0x06031478,r1
    c.r[6] = 0x0u;  // 060313F2 mov #0,r6
    c.r[5] = c.r[8];  // 060313F4 mov r8,r5
    { const uint32_t x = c.r[1]; c.pr = 0x060313FAu; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060313FAu) return; }  // 060313F6 jsr @r1 ; mov r10,r4
    c.r[1] = ld32(0x0603147Cu);  // 060313FA mov.l 0x0603147C,r1
    c.r[6] = c.r[9];  // 060313FC mov r9,r6
    c.r[5] = c.r[8];  // 060313FE mov r8,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06031404u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06031404u) return; }  // 06031400 jsr @r1 ; mov r14,r4
    c.r[3] = c.r[8] & 0xFFFFu;  // 06031404 extu.w r8,r3
    c.r[15] += 8;  // 06031406 add #8,r15
    c.r[1] = ld32(0x06031474u);  // 06031408 mov.l 0x06031474,r1
    c.r[2] = ld32(c.r[1]);  // 0603140A mov.l @r1,r2
    c.r[0] = ld32(0x06031480u);  // 0603140C mov.l 0x06031480,r0
    c.r[1] = 0x1Eu;  // 0603140E mov #30,r1
    c.macl = c.r[3] * c.r[1];  // 06031410 mul.l r1,r3
    c.r[5] = c.r[10];  // 06031412 mov r10,r5
    c.r[4] = c.r[8];  // 06031414 mov r8,r4
    c.r[3] = c.macl;  // 06031416 sts macl,r3
    c.r[3] += c.r[2];  // 06031418 add r2,r3
    c.r[2] = c.r[3];  // 0603141A mov r3,r2
    c.r[1] = c.r[14];  // 0603141C mov r14,r1
    c.r[1] += 26;  // 0603141E add #26,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06031420 mov.w @r1,r1
    c.r[2] += 22;  // 06031422 add #22,r2
    st16(c.r[2], c.r[1]);  // 06031424 mov.w r1,@r2
    c.r[1] = c.r[14];  // 06031426 mov r14,r1
    c.r[1] += 28;  // 06031428 add #28,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0603142A mov.w @r1,r1
    c.r[3] += 24;  // 0603142C add #24,r3
    { const uint32_t x = c.r[0]; c.pr = 0x06031432u; st16(c.r[3], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06031432u) return; }  // 0603142E jsr @r0 ; mov.w r1,@r3
    c.r[8] = c.r[0] & 0xFFu;  // 06031432 extu.b r0,r8
    c.t = c.r[11] == c.r[9];  // 06031434 cmp/eq r9,r11
L_06031436:
    { const bool k = c.t; c.t = c.r[8] == c.r[9]; if (k) { goto L_0603144C; } }  // 06031436 bt/s 0x0603144C ; cmp/eq r9,r8
    { const bool k = c.t; c.r[5] = c.r[11]; if (k) { goto L_0603144C; } }  // 0603143A bt/s 0x0603144C ; mov r11,r5
    c.r[0] = ld32(0x06031484u);  // 0603143E mov.l 0x06031484,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06031444u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06031444u) return; }  // 06031440 jsr @r0 ; mov r8,r4
    c.r[0] = c.r[8]; goto L_0603144E;  // 06031444 bra 0x0603144E ; mov r8,r0
L_06031448:
    c.r[3] = c.r[2]; SH2_POLL(c); goto L_060313E2;  // 06031448 bra 0x060313E2 ; mov r2,r3
L_0603144C:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06031468u);  // 0603144C mov.w 0x06031468,r0
L_0603144E:
    c.r[3] = (uint32_t)(int16_t)ld16(0x0603146Au);  // 0603144E mov.w 0x0603146A,r3
    c.r[14] += c.r[3];  // 06031450 add r3,r14
    c.r[15] = c.r[14];  // 06031452 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06031454 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06031456 mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06031458 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0603145A mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0603145C mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0603145E mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06031460 rts ; mov.l @r15+,r8
}

void f_06031488(SH2Context& c) {
    ran[703] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06031488 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603148A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0603148C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603148E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06031490 sts.l pr,@-r15
    c.r[1] = ld32(0x060314E0u);  // 06031492 mov.l 0x060314E0,r1
    c.r[2] = ld32(c.r[1]);  // 06031494 mov.l @r1,r2
    c.r[8] = c.r[4] & 0xFFu;  // 06031496 extu.b r4,r8
    c.r[1] = 0x1Eu;  // 06031498 mov #30,r1
    c.macl = c.r[8] * c.r[1];  // 0603149A mul.l r1,r8
    c.r[14] = c.r[15];  // 0603149C mov r15,r14
    c.r[1] = c.macl;  // 0603149E sts macl,r1
    c.r[1] += c.r[2];  // 060314A0 add r2,r1
    c.r[1] += 16;  // 060314A2 add #16,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060314A4 mov.b @r1,r1
    c.r[9] = (uint32_t)(int16_t)ld16(0x060314DEu);  // 060314A6 mov.w 0x060314DE,r9
    c.r[4] = c.r[1] & 0xFFu;  // 060314A8 extu.b r1,r4
    c.t = c.r[4] == c.r[9];  // 060314AA cmp/eq r9,r4
    { const bool k = c.t; c.r[10] = c.r[8]; if (k) { goto L_060314B6; } }  // 060314AC bt/s 0x060314B6 ; mov r8,r10
    c.r[1] = ld32(0x060314E4u);  // 060314B0 mov.l 0x060314E4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060314B6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060314B6u) return; }  // 060314B2 jsr @r1 ; nop
L_060314B6:
    c.r[0] = ld32(0x060314E8u);  // 060314B6 mov.l 0x060314E8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060314BCu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060314BCu) return; }  // 060314B8 jsr @r0 ; mov r8,r4
    c.r[0] = c.r[0] & 0xFFu;  // 060314BC extu.b r0,r0
    c.t = c.r[0] == c.r[9];  // 060314BE cmp/eq r9,r0
    if (c.t) { goto L_060314C8; }  // 060314C0 bt 0x060314C8
    c.r[1] = ld32(0x060314ECu);  // 060314C2 mov.l 0x060314EC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060314C8u; c.r[4] = c.r[0] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060314C8u) return; }  // 060314C4 jsr @r1 ; extu.b r0,r4
L_060314C8:
    c.r[1] = ld32(0x060314E4u);  // 060314C8 mov.l 0x060314E4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060314CEu; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060314CEu) return; }  // 060314CA jsr @r1 ; mov r10,r4
    c.r[15] = c.r[14];  // 060314CE mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060314D0 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060314D2 mov.l @r15+,r14
    c.r[0] = c.r[10];  // 060314D4 mov r10,r0
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060314D6 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060314D8 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060314DA rts ; mov.l @r15+,r8
}

void f_060314F0(SH2Context& c) {
    ran[704] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060314F0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060314F2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060314F4 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060314F6 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060314F8 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060314FA mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060314FC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060314FE sts.l pr,@-r15
    c.r[15] -= 48;  // 06031500 add #-48,r15
    c.r[11] = c.r[4];  // 06031502 mov r4,r11
    c.r[10] = c.r[5] & 0xFFu;  // 06031504 extu.b r5,r10
    c.r[1] = c.r[11];  // 06031506 mov r11,r1
    c.r[1] += 14;  // 06031508 add #14,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603150A mov.b @r1,r1
    c.r[8] = (uint32_t)(int16_t)ld16(0x06031610u);  // 0603150C mov.w 0x06031610,r8
    c.r[5] = c.r[1] & 0xFFu;  // 0603150E extu.b r1,r5
    c.t = c.r[5] == c.r[8];  // 06031510 cmp/eq r8,r5
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0603151A; } }  // 06031512 bf/s 0x0603151A ; mov r15,r14
    goto L_0603166A;  // 06031516 bra 0x0603166A ; nop
L_0603151A:
    c.r[1] = ld32(0x06031624u);  // 0603151A mov.l 0x06031624,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06031520u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06031520u) return; }  // 0603151C jsr @r1 ; mov r14,r4
    c.r[9] = 0x0u;  // 06031520 mov #0,r9
    c.r[1] = c.r[10];  // 06031522 mov r10,r1
    c.r[1] <<= 2;  // 06031524 shll2 r1
    c.r[1] += c.r[10];  // 06031526 add r10,r1
    c.r[1] <<= 2;  // 06031528 shll2 r1
    c.r[1] += c.r[11];  // 0603152A add r11,r1
    c.r[13] = c.r[1];  // 0603152C mov r1,r13
    c.r[13] += 44;  // 0603152E add #44,r13
    c.r[12] = c.r[1];  // 06031530 mov r1,r12
    c.r[12] += 60;  // 06031532 add #60,r12
    c.r[1] = c.r[14];  // 06031534 mov r14,r1
L_06031536:
    c.r[1] += 30;  // 06031536 add #30,r1
    c.r[0] = c.r[1];  // 06031538 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 0603153A mov.b @(r0,r9),r1
    c.r[8] = (uint32_t)(int16_t)ld16(0x06031610u);  // 0603153C mov.w 0x06031610,r8
    c.r[3] = c.r[1] & 0xFFu;  // 0603153E extu.b r1,r3
    c.r[1] = 0x2Fu;  // 06031540 mov #47,r1
    c.r[2] = c.r[3];  // 06031542 mov r3,r2
    c.r[2] -= 33;  // 06031544 add #-33,r2
    c.t = c.r[2] > c.r[1];  // 06031546 cmp/hi r1,r2
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_06031636; } }  // 06031548 bt/s 0x06031636 ; mov r2,r1
    c.r[1] += c.r[1];  // 0603154C add r1,r1
    c.r[0] = 0x06031558u;  // 0603154E mova 0x06031558,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06031550 mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 06031552 add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x060315B8u: goto L_060315B8; case 0x060315BEu: goto L_060315BE; case 0x060315C4u: goto L_060315C4; case 0x06031636u: goto L_06031636; case 0x06031630u: goto L_06031630; default: sh2_call(c, x); return; } }  // 06031554 jmp @r0 ; nop
L_060315B8:
    c.r[8] = c.r[3];  // 060315B8 mov r3,r8
    c.r[8] -= 33; goto L_06031636;  // 060315BA bra 0x06031636 ; add #-33,r8
L_060315BE:
    c.r[8] = c.r[3];  // 060315BE mov r3,r8
    c.r[8] -= 42; goto L_06031636;  // 060315C0 bra 0x06031636 ; add #-42,r8
L_060315C4:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[13]);  // 060315C4 mov.w @r13,r1
    c.r[2] = c.r[1] & 0xFFFFu;  // 060315C6 extu.w r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06031612u);  // 060315C8 mov.w 0x06031612,r1
    c.t = c.r[2] == c.r[1];  // 060315CA cmp/eq r1,r2
    { const bool k = c.t; c.r[3] -= 51; if (k) { goto L_060315FA; } }  // 060315CC bt/s 0x060315FA ; add #-51,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x06031614u);  // 060315D0 mov.w 0x06031614,r1
    c.t = c.r[2] == c.r[1];  // 060315D2 cmp/eq r1,r2
    if (c.t) { goto L_060315FA; }  // 060315D4 bt 0x060315FA
    c.r[1] = (uint32_t)(int16_t)ld16(0x06031616u);  // 060315D6 mov.w 0x06031616,r1
    c.t = c.r[2] == c.r[1];  // 060315D8 cmp/eq r1,r2
    if (c.t) { goto L_060315FA; }  // 060315DA bt 0x060315FA
    c.r[1] = (uint32_t)(int16_t)ld16(0x06031618u);  // 060315DC mov.w 0x06031618,r1
    c.t = c.r[2] == c.r[1];  // 060315DE cmp/eq r1,r2
    if (c.t) { goto L_060315FA; }  // 060315E0 bt 0x060315FA
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603161Au);  // 060315E2 mov.w 0x0603161A,r1
    c.t = c.r[2] == c.r[1];  // 060315E4 cmp/eq r1,r2
    if (c.t) { goto L_060315FA; }  // 060315E6 bt 0x060315FA
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603161Cu);  // 060315E8 mov.w 0x0603161C,r1
    c.t = c.r[2] == c.r[1];  // 060315EA cmp/eq r1,r2
    if (c.t) { goto L_060315FA; }  // 060315EC bt 0x060315FA
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603161Eu);  // 060315EE mov.w 0x0603161E,r1
    c.t = c.r[2] == c.r[1];  // 060315F0 cmp/eq r1,r2
    if (c.t) { goto L_060315FA; }  // 060315F2 bt 0x060315FA
    c.r[1] = (uint32_t)(int16_t)ld16(0x06031620u);  // 060315F4 mov.w 0x06031620,r1
    c.t = c.r[2] == c.r[1];  // 060315F6 cmp/eq r1,r2
    if (!c.t) { goto L_06031636; }  // 060315F8 bf 0x06031636
L_060315FA:
    c.r[1] = ld32(0x06031628u);  // 060315FA mov.l 0x06031628,r1
    c.r[3] <<= 2;  // 060315FC shll2 r3
    c.r[0] = c.r[1];  // 060315FE mov r1,r0
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 06031600 mov.w @(r0,r3),r6
    c.r[5] = c.r[10];  // 06031602 mov r10,r5
    c.r[4] = c.r[11];  // 06031604 mov r11,r4
    c.r[1] = ld32(0x0603162Cu);  // 06031606 mov.l 0x0603162C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603160Cu; c.r[6] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603160Cu) return; }  // 06031608 jsr @r1 ; extu.w r6,r6
    goto L_06031636;  // 0603160C bra 0x06031636 ; nop
L_06031630:
    c.r[2] = ld32(0x06031684u);  // 06031630 mov.l 0x06031684,r2
    c.r[1] = 0x1u;  // 06031632 mov #1,r1
    st32(c.r[2], c.r[1]);  // 06031634 mov.l r1,@r2
L_06031636:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06031680u);  // 06031636 mov.w 0x06031680,r1
    c.t = c.r[8] == c.r[1];  // 06031638 cmp/eq r1,r8
    if (c.t) { goto L_0603165C; }  // 0603163A bt 0x0603165C
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[12]);  // 0603163C mov.b @r12,r1
    c.r[2] = 0x11u;  // 0603163E mov #17,r2
    c.r[1] -= 33;  // 06031640 add #-33,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06031642 extu.b r1,r1
    c.t = c.r[1] > c.r[2];  // 06031644 cmp/hi r2,r1
    { const bool k = c.t; c.r[0] = c.r[8]; if (k) { goto L_0603165C; } }  // 06031646 bt/s 0x0603165C ; mov r8,r0
    c.r[1] = ld32(0x06031688u);  // 0603164A mov.l 0x06031688,r1
    c.r[0] += c.r[0];  // 0603164C add r0,r0
    c.r[0] += c.r[8];  // 0603164E add r8,r0
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06031650 mov.b @(r0,r1),r6
    c.r[5] = c.r[10];  // 06031652 mov r10,r5
    c.r[4] = c.r[11];  // 06031654 mov r11,r4
    c.r[1] = ld32(0x0603168Cu);  // 06031656 mov.l 0x0603168C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603165Cu; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603165Cu) return; }  // 06031658 jsr @r1 ; extu.b r6,r6
L_0603165C:
    c.r[9] += 1;  // 0603165C add #1,r9
    c.r[1] = 0x3u;  // 0603165E mov #3,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 06031660 cmp/gt r1,r9
    { const bool k = c.t; c.r[1] = c.r[14]; if (k) { goto L_0603166A; } }  // 06031662 bt/s 0x0603166A ; mov r14,r1
    SH2_POLL(c); goto L_06031536;  // 06031666 bra 0x06031536 ; nop
L_0603166A:
    c.r[14] += 48;  // 0603166A add #48,r14
    c.r[15] = c.r[14];  // 0603166C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603166E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06031670 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06031672 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06031674 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06031676 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06031678 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0603167A mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603167C rts ; mov.l @r15+,r8
}

void f_060318F4(SH2Context& c) {
    ran[705] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060318F4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060318F6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060318F8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060318FA mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060318FC mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060318FE mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06031900 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06031902 sts.l pr,@-r15
    c.r[15] -= 48;  // 06031904 add #-48,r15
    c.r[14] = c.r[15];  // 06031906 mov r15,r14
    c.r[13] = c.r[4];  // 06031908 mov r4,r13
    st32(c.r[14] + 4, c.r[7]);  // 0603190A mov.l r7,@(4,r14)
    c.r[6] = c.r[6] & 0xFFu;  // 0603190C extu.b r6,r6
    st32(c.r[14], c.r[6]);  // 0603190E mov.l r6,@r14
    c.r[0] = 0x0u;  // 06031910 mov #0,r0
    st32(c.r[14] + 28, c.r[0]);  // 06031912 mov.l r0,@(28,r14)
    c.r[12] = 0x0u;  // 06031914 mov #0,r12
    st32(c.r[14] + 32, c.r[12]);  // 06031916 mov.l r12,@(32,r14)
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[13]);  // 06031918 mov.w @r13,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06031A58u);  // 0603191A mov.w 0x06031A58,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 0603191C extu.w r1,r1
    c.t = c.r[1] == c.r[2];  // 0603191E cmp/eq r2,r1
    { const bool k = !c.t; c.r[8] = c.r[5]; if (k) { goto L_0603193E; } }  // 06031920 bf/s 0x0603193E ; mov r5,r8
    c.r[0] = ld32(0x06031A60u);  // 06031924 mov.l 0x06031A60,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0603192Au; c.r[6] = ld32(c.r[14]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603192Au) return; }  // 06031926 jsr @r0 ; mov.l @r14,r6
    c.r[1] = c.r[0];  // 0603192A mov r0,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0603192C extu.w r1,r1
    st32(c.r[14] + 28, c.r[1]);  // 0603192E mov.l r1,@(28,r14)
    c.r[0] = ld32(c.r[14] + 28);  // 06031930 mov.l @(28,r14),r0
    c.r[1] = ld32(0x06031A64u);  // 06031932 mov.l 0x06031A64,r1
    c.t = c.r[0] == c.r[1];  // 06031934 cmp/eq r1,r0
    { const bool k = c.t; c.r[0] = ld32(c.r[14] + 4); if (k) { goto L_06031940; } }  // 06031936 bt/s 0x06031940 ; mov.l @(4,r14),r0
    c.r[12] = 0x1u;  // 0603193A mov #1,r12
    st32(c.r[14] + 32, c.r[12]);  // 0603193C mov.l r12,@(32,r14)
L_0603193E:
    c.r[0] = ld32(c.r[14] + 4);  // 0603193E mov.l @(4,r14),r0
L_06031940:
    c.t = (c.r[0] & c.r[0]) == 0;  // 06031940 tst r0,r0
    { const bool k = c.t; c.r[3] = 0x0u; if (k) { goto L_06031956; } }  // 06031942 bt/s 0x06031956 ; mov #0,r3
    c.r[2] = 0xFu;  // 06031946 mov #15,r2
    c.r[1] = 0xFFFFFFFFu;  // 06031948 mov #-1,r1
    c.r[0] = ld32(c.r[14] + 4);  // 0603194A mov.l @(4,r14),r0
L_0603194C:
    st8(c.r[0] + c.r[3], c.r[1]);  // 0603194C mov.b r1,@(r0,r3)
    c.r[3] += 1;  // 0603194E add #1,r3
    c.t = (int32_t)c.r[3] > (int32_t)c.r[2];  // 06031950 cmp/gt r2,r3
    { const bool k = !c.t; c.r[0] = ld32(c.r[14] + 4); if (k) { SH2_POLL(c); goto L_0603194C; } }  // 06031952 bf/s 0x0603194C ; mov.l @(4,r14),r0
L_06031956:
    c.r[7] = ld32(0x06031A68u);  // 06031956 mov.l 0x06031A68,r7
    c.r[3] = ld32(0x06031A6Cu);  // 06031958 mov.l 0x06031A6C,r3
    c.r[2] = ld32(0x06031A70u);  // 0603195A mov.l 0x06031A70,r2
    c.r[1] = 0x0u;  // 0603195C mov #0,r1
    st32(c.r[2], c.r[1]);  // 0603195E mov.l r1,@r2
    st32(c.r[3], c.r[1]);  // 06031960 mov.l r1,@r3
    st32(c.r[7], c.r[1]);  // 06031962 mov.l r1,@r7
    c.r[12] = 0x0u;  // 06031964 mov #0,r12
    st32(c.r[14] + 8, c.r[12]);  // 06031966 mov.l r12,@(8,r14)
    c.r[1] = ld32(c.r[14]);  // 06031968 mov.l @r14,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06031A5Au);  // 0603196A mov.w 0x06031A5A,r0
    c.r[1] &= c.r[0];  // 0603196C and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603196E tst r1,r1
    { const bool k = c.t; c.r[12] = 0x1u; if (k) { goto L_0603197C; } }  // 06031970 bt/s 0x0603197C ; mov #1,r12
    c.r[0] = ld32(c.r[14]);  // 06031974 mov.l @r14,r0
    st32(c.r[14] + 8, c.r[12]);  // 06031976 mov.l r12,@(8,r14)
    c.r[0] &= 0x7Fu;  // 06031978 and #127,r0
    st32(c.r[14], c.r[0]);  // 0603197A mov.l r0,@r14
L_0603197C:
    c.r[5] = (uint32_t)(int16_t)ld16(0x06031A5Cu);  // 0603197C mov.w 0x06031A5C,r5
    c.r[4] = c.r[13];  // 0603197E mov r13,r4
    c.r[1] = ld32(0x06031A74u);  // 06031980 mov.l 0x06031A74,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06031986u; c.r[4] += 44; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06031986u) return; }  // 06031982 jsr @r1 ; add #44,r4
    c.r[12] = 0x0u;  // 06031986 mov #0,r12
    st32(c.r[14] + 12, c.r[12]);  // 06031988 mov.l r12,@(12,r14)
    c.r[0] = 0x0u;  // 0603198A mov #0,r0
    st32(c.r[14] + 24, c.r[0]);  // 0603198C mov.l r0,@(24,r14)
    c.r[8] += 2;  // 0603198E add #2,r8
    st32(c.r[14] + 36, c.r[8]);  // 06031990 mov.l r8,@(36,r14)
    st32(c.r[14] + 40, c.r[13]);  // 06031992 mov.l r13,@(40,r14)
L_06031994:
    c.r[1] = ld32(c.r[14] + 36);  // 06031994 mov.l @(36,r14),r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 06031996 mov.b @r1+,r2
    c.r[2] = c.r[2] & 0xFFu;  // 06031998 extu.b r2,r2
    c.r[11] = c.r[2];  // 0603199A mov r2,r11
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603199C mov.b @r1,r1
    c.r[11] <<= 8;  // 0603199E shll8 r11
    c.r[1] = c.r[1] & 0xFFu;  // 060319A0 extu.b r1,r1
    c.r[11] |= c.r[1];  // 060319A2 or r1,r11
    c.t = (c.r[11] & c.r[11]) == 0;  // 060319A4 tst r11,r11
    { const bool k = !c.t; c.r[1] = ld32(c.r[14] + 36); if (k) { goto L_060319AE; } }  // 060319A6 bf/s 0x060319AE ; mov.l @(36,r14),r1
    goto L_06031B10;  // 060319AA bra 0x06031B10 ; nop
L_060319AE:
    c.r[1] += 2;  // 060319AE add #2,r1
    c.r[9] = c.r[11];  // 060319B0 mov r11,r9
    c.r[9] >>= 8;  // 060319B2 shlr8 r9
    c.t = c.r[9] & 1; c.r[9] >>= 1;  // 060319B4 shlr r9
    c.r[9] >>= 2;  // 060319B6 shlr2 r9
    c.r[12] = 0xFu;  // 060319B8 mov #15,r12
    c.r[9] &= c.r[12];  // 060319BA and r12,r9
    c.r[10] = ld32(0x06031A78u);  // 060319BC mov.l 0x06031A78,r10
    c.r[10] &= c.r[11];  // 060319BE and r11,r10
    c.r[12] = (uint32_t)(int16_t)ld16(0x06031A5Au);  // 060319C0 mov.w 0x06031A5A,r12
    c.r[8] = 0x0u;  // 060319C2 mov #0,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060319C4 mov.b @r1,r1
    c.t = (c.r[10] & c.r[10]) == 0;  // 060319C6 tst r10,r10
    c.r[2] = c.r[1] & 0xFFu;  // 060319C8 extu.b r1,r2
    c.r[0] = c.r[2];  // 060319CA mov r2,r0
    c.r[1] = ld32(c.r[14] + 36);  // 060319CC mov.l @(36,r14),r1
    c.r[0] &= 0x7Fu;  // 060319CE and #127,r0
    c.r[1] += 3;  // 060319D0 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060319D2 mov.b @r1,r1
    c.r[12] &= c.r[2];  // 060319D4 and r2,r12
    c.r[4] = c.r[1] & 0xFFu;  // 060319D6 extu.b r1,r4
    st32(c.r[14] + 20, c.r[4]);  // 060319D8 mov.l r4,@(20,r14)
    st32(c.r[14] + 16, c.r[0]);  // 060319DA mov.l r0,@(16,r14)
    { const bool k = c.t; st32(c.r[14] + 44, c.r[12]); if (k) { goto L_060319F4; } }  // 060319DC bt/s 0x060319F4 ; mov.l r12,@(44,r14)
    c.r[0] = ld32(0x06031A7Cu);  // 060319E0 mov.l 0x06031A7C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060319E6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060319E6u) return; }  // 060319E2 jsr @r0 ; nop
    c.r[1] = c.r[0] & 0xFFFFu;  // 060319E6 extu.w r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060319E8 tst r1,r1
    { const bool k = !c.t; c.r[0] = ld32(c.r[14] + 36); if (k) { goto L_060319F2; } }  // 060319EA bf/s 0x060319F2 ; mov.l @(36,r14),r0
    goto L_06031B0A;  // 060319EE bra 0x06031B0A ; nop
L_060319F2:
    c.r[8] = 0x1u;  // 060319F2 mov #1,r8
L_060319F4:
    c.r[0] = ld32(c.r[14] + 44);  // 060319F4 mov.l @(44,r14),r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060319F6 tst r0,r0
    { const bool k = c.t; c.r[5] = c.r[9]; if (k) { goto L_06031A1E; } }  // 060319F8 bt/s 0x06031A1E ; mov r9,r5
    c.r[12] = ld32(c.r[14] + 24);  // 060319FC mov.l @(24,r14),r12
    c.r[1] = 0xAu;  // 060319FE mov #10,r1
    c.t = c.r[12] > c.r[1];  // 06031A00 cmp/hi r1,r12
    { const bool k = c.t; c.t = (c.r[10] & c.r[10]) == 0; if (k) { goto L_06031A0A; } }  // 06031A02 bt/s 0x06031A0A ; tst r10,r10
    goto L_06031B08;  // 06031A06 bra 0x06031B08 ; nop
L_06031A0A:
    { const bool k = c.t; c.r[8] = 0x1u; if (k) { goto L_06031A1E; } }  // 06031A0A bt/s 0x06031A1E ; mov #1,r8
    c.r[0] = ld32(0x06031A7Cu);  // 06031A0E mov.l 0x06031A7C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06031A14u; c.r[4] = ld32(c.r[14] + 20); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06031A14u) return; }  // 06031A10 jsr @r0 ; mov.l @(20,r14),r4
    c.r[1] = c.r[0] & 0xFFFFu;  // 06031A14 extu.w r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06031A16 tst r1,r1
    { const bool k = c.t; c.r[0] = ld32(c.r[14] + 36); if (k) { goto L_06031B0A; } }  // 06031A18 bt/s 0x06031B0A ; mov.l @(36,r14),r0
    c.r[5] = c.r[9];  // 06031A1C mov r9,r5
L_06031A1E:
    c.r[0] = ld32(0x06031A80u);  // 06031A1E mov.l 0x06031A80,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06031A24u; c.r[4] = c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06031A24u) return; }  // 06031A20 jsr @r0 ; mov r13,r4
    c.r[1] = c.r[0];  // 06031A24 mov r0,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06031A26 extu.b r1,r1
    c.r[12] = ld32(c.r[14] + 44);  // 06031A28 mov.l @(44,r14),r12
    c.t = (c.r[12] & c.r[12]) == 0;  // 06031A2A tst r12,r12
    { const bool k = !c.t; st32(c.r[14] + 24, c.r[1]); if (k) { goto L_06031A36; } }  // 06031A2C bf/s 0x06031A36 ; mov.l r1,@(24,r14)
    c.t = (c.r[10] & c.r[10]) == 0;  // 06031A30 tst r10,r10
    if (!c.t) { goto L_06031A36; }  // 06031A32 bf 0x06031A36
    c.r[8] = 0x1u;  // 06031A34 mov #1,r8
L_06031A36:
    c.t = (c.r[8] & c.r[8]) == 0;  // 06031A36 tst r8,r8
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_06031B08; } }  // 06031A38 bt/s 0x06031B08 ; mov r9,r1
    c.r[1] <<= 2;  // 06031A3C shll2 r1
    c.r[1] += c.r[9];  // 06031A3E add r9,r1
    c.r[1] <<= 2;  // 06031A40 shll2 r1
    c.r[1] += c.r[13];  // 06031A42 add r13,r1
    c.r[1] += 44;  // 06031A44 add #44,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06031A5Eu);  // 06031A46 mov.w 0x06031A5E,r2
    c.r[11] &= c.r[2];  // 06031A48 and r2,r11
    st16(c.r[1], c.r[11]);  // 06031A4A mov.w r11,@r1
    c.r[1] = ld32(0x06031A84u);  // 06031A4C mov.l 0x06031A84,r1
    c.r[5] = c.r[9];  // 06031A4E mov r9,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06031A54u; c.r[4] = c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06031A54u) return; }  // 06031A50 jsr @r1 ; mov r13,r4
    c.r[0] = ld32(c.r[14] + 32); goto L_06031A88;  // 06031A54 bra 0x06031A88 ; mov.l @(32,r14),r0
L_06031A88:
    c.t = (c.r[0] & c.r[0]) == 0;  // 06031A88 tst r0,r0
    { const bool k = c.t; c.r[0] = ld32(c.r[14] + 40); if (k) { goto L_06031AA2; } }  // 06031A8A bt/s 0x06031AA2 ; mov.l @(40,r14),r0
    c.t = (c.r[10] & c.r[10]) == 0;  // 06031A8E tst r10,r10
    { const bool k = c.t; c.r[12] = ld32(c.r[14] + 12); if (k) { goto L_06031AA4; } }  // 06031A90 bt/s 0x06031AA4 ; mov.l @(12,r14),r12
    c.r[1] = ld32(c.r[14] + 40);  // 06031A94 mov.l @(40,r14),r1
    c.r[12] = ld32(c.r[14] + 28);  // 06031A96 mov.l @(28,r14),r12
    c.r[1] += 48;  // 06031A98 add #48,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06031A9A mov.w @r1,r2
    c.r[2] += c.r[12];  // 06031A9C add r12,r2
    st16(c.r[1], c.r[2]);  // 06031A9E mov.w r2,@r1
    c.r[0] = ld32(c.r[14] + 40);  // 06031AA0 mov.l @(40,r14),r0
L_06031AA2:
    c.r[12] = ld32(c.r[14] + 12);  // 06031AA2 mov.l @(12,r14),r12
L_06031AA4:
    c.r[0] += 20;  // 06031AA4 add #20,r0
    st32(c.r[14] + 40, c.r[0]);  // 06031AA6 mov.l r0,@(40,r14)
    c.r[12] += 1;  // 06031AA8 add #1,r12
    c.r[0] = ld32(c.r[14] + 8);  // 06031AAA mov.l @(8,r14),r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06031AAC tst r0,r0
    { const bool k = c.t; st32(c.r[14] + 12, c.r[12]); if (k) { goto L_06031AEC; } }  // 06031AAE bt/s 0x06031AEC ; mov.l r12,@(12,r14)
    c.r[3] = c.r[9];  // 06031AB2 mov r9,r3
    c.r[3] <<= 2;  // 06031AB4 shll2 r3
    c.r[3] += c.r[9];  // 06031AB6 add r9,r3
    c.r[3] <<= 2;  // 06031AB8 shll2 r3
    c.r[3] += c.r[13];  // 06031ABA add r13,r3
    c.r[1] = c.r[3];  // 06031ABC mov r3,r1
    c.r[1] += 51;  // 06031ABE add #51,r1
    c.r[12] = 0x4u;  // 06031AC0 mov #4,r12
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06031AC2 mov.b @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06031B58u);  // 06031AC4 mov.w 0x06031B58,r0
    c.r[2] |= c.r[12];  // 06031AC6 or r12,r2
    c.r[2] &= c.r[0];  // 06031AC8 and r0,r2
    st8(c.r[1], c.r[2]);  // 06031ACA mov.b r2,@r1
    c.r[12] = ld32(c.r[14] + 16);  // 06031ACC mov.l @(16,r14),r12
    c.t = (c.r[12] & c.r[12]) == 0;  // 06031ACE tst r12,r12
    { const bool k = c.t; c.r[0] = ld32(c.r[14] + 4); if (k) { goto L_06031AEE; } }  // 06031AD0 bt/s 0x06031AEE ; mov.l @(4,r14),r0
    c.r[1] = ld32(0x06031B5Cu);  // 06031AD4 mov.l 0x06031B5C,r1
    c.r[2] = ld32(c.r[14]);  // 06031AD6 mov.l @r14,r2
    c.r[3] += 52;  // 06031AD8 add #52,r3
    c.r[1] = ld32(c.r[1]);  // 06031ADA mov.l @r1,r1
    c.r[2] <<= 2;  // 06031ADC shll2 r2
    c.r[2] <<= 2;  // 06031ADE shll2 r2
    c.r[2] += c.r[1];  // 06031AE0 add r1,r2
    c.r[2] += c.r[12];  // 06031AE2 add r12,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06031AE4 mov.w @r3,r1
    c.r[2] += 39;  // 06031AE6 add #39,r2
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06031AE8 shlr r1
    st8(c.r[2], c.r[1]);  // 06031AEA mov.b r1,@r2
L_06031AEC:
    c.r[0] = ld32(c.r[14] + 4);  // 06031AEC mov.l @(4,r14),r0
L_06031AEE:
    c.t = (c.r[0] & c.r[0]) == 0;  // 06031AEE tst r0,r0
    { const bool k = c.t; c.r[0] = ld32(c.r[14] + 36); if (k) { goto L_06031B0A; } }  // 06031AF0 bt/s 0x06031B0A ; mov.l @(36,r14),r0
    c.r[12] = ld32(c.r[14] + 16);  // 06031AF4 mov.l @(16,r14),r12
    c.t = (c.r[12] & c.r[12]) == 0;  // 06031AF6 tst r12,r12
    { const bool k = c.t; c.r[0] += 4; if (k) { goto L_06031B0C; } }  // 06031AF8 bt/s 0x06031B0C ; add #4,r0
    c.r[12] -= 1;  // 06031AFC add #-1,r12
    st32(c.r[14] + 16, c.r[12]);  // 06031AFE mov.l r12,@(16,r14)
    c.r[0] = 0x13u;  // 06031B00 mov #19,r0
    c.r[12] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 06031B02 mov.b @(r0,r14),r12
    c.r[0] = ld32(c.r[14] + 4);  // 06031B04 mov.l @(4,r14),r0
    st8(c.r[0] + c.r[9], c.r[12]);  // 06031B06 mov.b r12,@(r0,r9)
L_06031B08:
    c.r[0] = ld32(c.r[14] + 36);  // 06031B08 mov.l @(36,r14),r0
L_06031B0A:
    c.r[0] += 4;  // 06031B0A add #4,r0
L_06031B0C:
    st32(c.r[14] + 36, c.r[0]); SH2_POLL(c); goto L_06031994;  // 06031B0C bra 0x06031994 ; mov.l r0,@(36,r14)
L_06031B10:
    c.r[1] = ld32(0x06031B60u);  // 06031B10 mov.l 0x06031B60,r1
    c.r[5] = ld32(c.r[1]);  // 06031B12 mov.l @r1,r5
    c.r[1] = ld32(0x06031B64u);  // 06031B14 mov.l 0x06031B64,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06031B1Au; c.r[4] = c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06031B1Au) return; }  // 06031B16 jsr @r1 ; mov r13,r4
    c.r[1] = ld32(0x06031B68u);  // 06031B1A mov.l 0x06031B68,r1
    c.r[5] = ld32(c.r[1]);  // 06031B1C mov.l @r1,r5
    c.r[1] = ld32(0x06031B6Cu);  // 06031B1E mov.l 0x06031B6C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06031B24u; c.r[4] = c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06031B24u) return; }  // 06031B20 jsr @r1 ; mov r13,r4
    c.r[13] += 14;  // 06031B24 add #14,r13
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 06031B26 mov.b @r13,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06031B5Au);  // 06031B28 mov.w 0x06031B5A,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06031B2A extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 06031B2C cmp/eq r2,r1
    { const bool k = c.t; c.r[0] = ld32(c.r[14] + 12); if (k) { goto L_06031B42; } }  // 06031B2E bt/s 0x06031B42 ; mov.l @(12,r14),r0
    c.r[1] = ld32(0x06031B70u);  // 06031B32 mov.l 0x06031B70,r1
    c.r[5] = ld32(c.r[1]);  // 06031B34 mov.l @r1,r5
    c.r[1] = ld32(0x06031B74u);  // 06031B36 mov.l 0x06031B74,r1
    c.r[4] = ld32(c.r[1]);  // 06031B38 mov.l @r1,r4
    c.r[1] = ld32(0x06031B78u);  // 06031B3A mov.l 0x06031B78,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06031B40u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06031B40u) return; }  // 06031B3C jsr @r1 ; nop
    c.r[0] = ld32(c.r[14] + 12);  // 06031B40 mov.l @(12,r14),r0
L_06031B42:
    c.r[14] += 48;  // 06031B42 add #48,r14
    c.r[15] = c.r[14];  // 06031B44 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06031B46 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06031B48 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06031B4A mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06031B4C mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06031B4E mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06031B50 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06031B52 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06031B54 rts ; mov.l @r15+,r8
}

void f_06031B7C(SH2Context& c) {
    ran[706] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06031B7C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06031B7E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06031B80 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06031B82 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06031B84 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06031B86 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06031B88 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06031B8A sts.l pr,@-r15
    c.r[15] -= 4;  // 06031B8C add #-4,r15
    c.r[14] = c.r[15];  // 06031B8E mov r15,r14
    st32(c.r[14], c.r[4]);  // 06031B90 mov.l r4,@r14
    c.r[13] = c.r[5] & 0xFFu;  // 06031B92 extu.b r5,r13
    c.r[10] = c.r[13];  // 06031B94 mov r13,r10
    c.r[10] <<= 2;  // 06031B96 shll2 r10
    c.r[10] += c.r[13];  // 06031B98 add r13,r10
    c.r[10] <<= 2;  // 06031B9A shll2 r10
    c.r[10] += c.r[4];  // 06031B9C add r4,r10
    c.r[1] = c.r[10];  // 06031B9E mov r10,r1
    c.r[1] += 44;  // 06031BA0 add #44,r1
    c.r[9] = ld32(0x06031DF8u);  // 06031BA2 mov.l 0x06031DF8,r9
    c.r[5] = 0x1Du;  // 06031BA4 mov #29,r5
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06031BA6 mov.w @r1,r8
    c.r[4] = ld32(0x06031DFCu);  // 06031BA8 mov.l 0x06031DFC,r4
    { const uint32_t x = c.r[9]; c.pr = 0x06031BAEu; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06031BAEu) return; }  // 06031BAA jsr @r9 ; extu.w r8,r8
    c.r[5] = c.r[8];  // 06031BAE mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06031BB4u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06031BB4u) return; }  // 06031BB0 jsr @r9 ; mov r0,r4
    c.r[12] = c.r[0];  // 06031BB4 mov r0,r12
    c.r[3] = c.r[10];  // 06031BB6 mov r10,r3
    c.r[3] += 48;  // 06031BB8 add #48,r3
    c.r[1] = c.r[12];  // 06031BBA mov r12,r1
    c.r[1] += 5;  // 06031BBC add #5,r1
    c.r[10] += 63;  // 06031BBE add #63,r10
    c.r[5] = 0x1Fu;  // 06031BC0 mov #31,r5
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06031BC2 mov.b @r1,r2
    c.r[4] = ld32(0x06031DFCu);  // 06031BC4 mov.l 0x06031DFC,r4
    c.r[2] = c.r[2] & 0xFFu;  // 06031BC6 extu.b r2,r2
    c.r[1] = c.r[12];  // 06031BC8 mov r12,r1
    c.r[1] += 6;  // 06031BCA add #6,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06031BCC mov.b @r1,r1
    c.r[2] <<= 8;  // 06031BCE shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06031BD0 extu.b r1,r1
    c.r[2] |= c.r[1];  // 06031BD2 or r1,r2
    st16(c.r[3], c.r[2]);  // 06031BD4 mov.w r2,@r3
    { const uint32_t x = c.r[9]; c.pr = 0x06031BDAu; st8(c.r[10], c.r[13]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06031BDAu) return; }  // 06031BD6 jsr @r9 ; mov.b r13,@r10
    c.r[5] = 0x2u;  // 06031BDA mov #2,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06031BE0u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06031BE0u) return; }  // 06031BDC jsr @r9 ; mov r0,r4
    c.r[8] = c.r[0];  // 06031BE0 mov r0,r8
    c.r[1] = c.r[12];  // 06031BE2 mov r12,r1
    c.r[1] += 8;  // 06031BE4 add #8,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06031BE6 mov.b @r1,r0
    c.r[5] = c.r[13];  // 06031BE8 mov r13,r5
    c.r[4] = ld32(c.r[14]);  // 06031BEA mov.l @r14,r4
    c.r[0] &= 0xFu;  // 06031BEC and #15,r0
    c.r[0] += c.r[0];  // 06031BEE add r0,r0
    c.r[1] = c.r[0];  // 06031BF0 mov r0,r1
    c.r[1] <<= 2;  // 06031BF2 shll2 r1
    c.r[1] += c.r[0];  // 06031BF4 add r0,r1
    c.r[1] += c.r[1];  // 06031BF6 add r1,r1
    c.r[0] = ld32(0x06031E00u);  // 06031BF8 mov.l 0x06031E00,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06031BFEu; c.r[8] += c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06031BFEu) return; }  // 06031BFA jsr @r0 ; add r1,r8
    c.r[1] = c.r[0];  // 06031BFE mov r0,r1
    c.r[1] += c.r[1];  // 06031C00 add r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06031C02 extu.b r1,r1
    c.r[6] = 0x0u;  // 06031C04 mov #0,r6
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[1];  // 06031C06 cmp/ge r1,r6
    { const bool k = c.t; c.r[0] = c.r[8]; if (k) { goto L_06031C28; } }  // 06031C08 bt/s 0x06031C28 ; mov r8,r0
    c.r[3] = c.r[1];  // 06031C0C mov r1,r3
    c.r[3] += c.r[0];  // 06031C0E add r0,r3
L_06031C10:
    c.r[1] = c.r[0];  // 06031C10 mov r0,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 06031C12 mov.b @r1+,r2
    c.r[0] += 2;  // 06031C14 add #2,r0
    c.r[2] = c.r[2] & 0xFFu;  // 06031C16 extu.b r2,r2
    c.r[2] <<= 8;  // 06031C18 shll8 r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06031C1A mov.b @r1,r1
    c.t = (int32_t)c.r[0] >= (int32_t)c.r[3];  // 06031C1C cmp/ge r3,r0
    c.r[1] = c.r[1] & 0xFFu;  // 06031C1E extu.b r1,r1
    c.r[2] |= c.r[1];  // 06031C20 or r1,r2
    c.r[2] += c.r[6];  // 06031C22 add r6,r2
    { const bool k = !c.t; c.r[6] = c.r[2] & 0xFFFFu; if (k) { SH2_POLL(c); goto L_06031C10; } }  // 06031C24 bf/s 0x06031C10 ; extu.w r2,r6
L_06031C28:
    c.r[1] = ld32(0x06031E04u);  // 06031C28 mov.l 0x06031E04,r1
    c.r[4] = ld32(c.r[14]);  // 06031C2A mov.l @r14,r4
    { const uint32_t x = c.r[1]; c.pr = 0x06031C30u; c.r[5] = c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06031C30u) return; }  // 06031C2C jsr @r1 ; mov r13,r5
    c.r[7] = c.r[13];  // 06031C30 mov r13,r7
    c.r[7] <<= 2;  // 06031C32 shll2 r7
    c.r[7] += c.r[13];  // 06031C34 add r13,r7
    c.r[7] <<= 2;  // 06031C36 shll2 r7
    c.r[2] = (uint32_t)(int16_t)ld16(0x06031DE2u);  // 06031C38 mov.w 0x06031DE2,r2
    c.r[3] = 0x3Fu;  // 06031C3A mov #63,r3
    c.r[4] = c.r[12];  // 06031C3C mov r12,r4
    c.r[11] = ld32(c.r[14]);  // 06031C3E mov.l @r14,r11
    c.r[5] = 0x3Fu;  // 06031C40 mov #63,r5
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[12]);  // 06031C42 mov.b @r12,r0
    c.r[7] += c.r[11];  // 06031C44 add r11,r7
    c.r[1] = c.r[7];  // 06031C46 mov r7,r1
    c.r[1] += 50;  // 06031C48 add #50,r1
    c.r[2] &= c.r[0];  // 06031C4A and r0,r2
    c.r[11] = (uint32_t)(int16_t)ld16(0x06031DE2u);  // 06031C4C mov.w 0x06031DE2,r11
    c.r[6] = c.r[7];  // 06031C4E mov r7,r6
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06031C50 mov.b @r1,r0
    c.r[6] += 46;  // 06031C52 add #46,r6
    c.r[3] &= c.r[0];  // 06031C54 and r0,r3
    c.r[3] |= c.r[2];  // 06031C56 or r2,r3
    st8(c.r[1], c.r[3]);  // 06031C58 mov.b r3,@r1
    c.r[3] &= c.r[11];  // 06031C5A and r11,r3
    c.r[2] = 0x7Fu;  // 06031C5C mov #127,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 06031C5E mov.b @r4+,r0
    c.r[11] = (uint32_t)(int16_t)ld16(0x06031DE4u);  // 06031C60 mov.w 0x06031DE4,r11
    c.r[0] &= 0x3Fu;  // 06031C62 and #63,r0
    c.r[3] |= c.r[0];  // 06031C64 or r0,r3
    st8(c.r[1], c.r[3]);  // 06031C66 mov.b r3,@r1
    c.r[3] = c.r[7];  // 06031C68 mov r7,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]);  // 06031C6A mov.b @r4,r1
    c.r[3] += 51;  // 06031C6C add #51,r3
    c.r[0] = c.r[1];  // 06031C6E mov r1,r0
    c.r[0] <<= 2;  // 06031C70 shll2 r0
    c.r[0] += c.r[0];  // 06031C72 add r0,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06031C74 mov.b @r3,r1
    c.r[0] &= 0x80u;  // 06031C76 and #128,r0
    c.r[2] &= c.r[1];  // 06031C78 and r1,r2
    c.r[2] |= c.r[0];  // 06031C7A or r0,r2
    st8(c.r[3], c.r[2]);  // 06031C7C mov.b r2,@r3
    c.r[2] &= c.r[11];  // 06031C7E and r11,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]);  // 06031C80 mov.b @r4,r1
    c.r[11] = (uint32_t)(int16_t)ld16(0x06031DE6u);  // 06031C82 mov.w 0x06031DE6,r11
    c.r[0] = c.r[1];  // 06031C84 mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06031C86 shlr r0
    c.r[0] &= 0x40u;  // 06031C88 and #64,r0
    c.r[2] |= c.r[0];  // 06031C8A or r0,r2
    st8(c.r[3], c.r[2]);  // 06031C8C mov.b r2,@r3
    c.r[2] &= c.r[11];  // 06031C8E and r11,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]);  // 06031C90 mov.b @r4,r1
    c.r[11] = (uint32_t)(int16_t)ld16(0x06031DE8u);  // 06031C92 mov.w 0x06031DE8,r11
    c.r[0] = c.r[1];  // 06031C94 mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06031C96 shlr r0
    c.r[0] &= 0x20u;  // 06031C98 and #32,r0
    c.r[2] |= c.r[0];  // 06031C9A or r0,r2
    st8(c.r[3], c.r[2]);  // 06031C9C mov.b r2,@r3
    c.r[2] &= c.r[11];  // 06031C9E and r11,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]);  // 06031CA0 mov.b @r4,r1
    c.r[11] = (uint32_t)(int16_t)ld16(0x06031DEAu);  // 06031CA2 mov.w 0x06031DEA,r11
    c.r[0] = c.r[1];  // 06031CA4 mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06031CA6 shlr r0
    c.r[0] &= 0x10u;  // 06031CA8 and #16,r0
    c.r[2] |= c.r[0];  // 06031CAA or r0,r2
    st8(c.r[3], c.r[2]);  // 06031CAC mov.b r2,@r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]);  // 06031CAE mov.b @r4,r1
    c.r[2] &= c.r[11];  // 06031CB0 and r11,r2
    c.r[0] = c.r[1];  // 06031CB2 mov r1,r0
    c.r[0] >>= 2;  // 06031CB4 shlr2 r0
    c.r[0] &= 0x2u;  // 06031CB6 and #2,r0
    c.r[2] |= c.r[0];  // 06031CB8 or r0,r2
    st8(c.r[3], c.r[2]);  // 06031CBA mov.b r2,@r3
    c.r[2] = c.r[7];  // 06031CBC mov r7,r2
    c.r[1] = c.r[12];  // 06031CBE mov r12,r1
    c.r[1] += 2;  // 06031CC0 add #2,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06031CC2 mov.b @r1,r0
    c.r[2] += 57;  // 06031CC4 add #57,r2
    c.r[0] &= 0x3Fu;  // 06031CC6 and #63,r0
    st8(c.r[2], c.r[0]);  // 06031CC8 mov.b r0,@r2
    c.r[1] = c.r[12];  // 06031CCA mov r12,r1
    c.r[1] += 3;  // 06031CCC add #3,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06031CCE mov.b @r1,r2
    c.r[11] = (uint32_t)(int16_t)ld16(0x06031DECu);  // 06031CD0 mov.w 0x06031DEC,r11
    c.r[2] = c.r[2] & 0xFFu;  // 06031CD2 extu.b r2,r2
    c.r[1] = c.r[12];  // 06031CD4 mov r12,r1
    c.r[1] += 4;  // 06031CD6 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06031CD8 mov.b @r1,r1
    c.r[2] <<= 8;  // 06031CDA shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06031CDC extu.b r1,r1
    c.r[2] |= c.r[1];  // 06031CDE or r1,r2
    st16(c.r[6], c.r[2]);  // 06031CE0 mov.w r2,@r6
    c.r[1] = c.r[12];  // 06031CE2 mov r12,r1
    c.r[1] += 8;  // 06031CE4 add #8,r1
    c.r[6] = c.r[7];  // 06031CE6 mov r7,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06031CE8 mov.b @r1,r1
    c.r[6] += 52;  // 06031CEA add #52,r6
    c.r[2] = c.r[1] & 0xFFu;  // 06031CEC extu.b r1,r2
    c.r[2] >>= 2;  // 06031CEE shlr2 r2
    c.r[2] >>= 2;  // 06031CF0 shlr2 r2
    c.r[0] = c.r[2];  // 06031CF2 mov r2,r0
    c.r[0] >>= 2;  // 06031CF4 shlr2 r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06031CF6 mov.b @r3,r1
    c.r[0] &= 0x1u;  // 06031CF8 and #1,r0
    c.r[1] &= c.r[11];  // 06031CFA and r11,r1
    c.r[1] |= c.r[0];  // 06031CFC or r0,r1
    st8(c.r[3], c.r[1]);  // 06031CFE mov.b r1,@r3
    c.r[11] = 0x3u;  // 06031D00 mov #3,r11
    c.r[2] &= c.r[11];  // 06031D02 and r11,r2
    c.r[2] <<= 2;  // 06031D04 shll2 r2
    c.r[2] <<= 2;  // 06031D06 shll2 r2
    c.r[2] <<= 2;  // 06031D08 shll2 r2
    c.r[1] = c.r[7];  // 06031D0A mov r7,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[6]);  // 06031D0C mov.b @r6,r0
    c.r[1] += 56;  // 06031D0E add #56,r1
    c.r[0] &= 0x3Fu;  // 06031D10 and #63,r0
    c.r[0] |= c.r[2];  // 06031D12 or r2,r0
    st8(c.r[6], c.r[0]);  // 06031D14 mov.b r0,@r6
    c.r[2] = c.r[12];  // 06031D16 mov r12,r2
    c.r[2] += 11;  // 06031D18 add #11,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06031D1A mov.b @r2,r0
    c.r[3] = (uint32_t)(int16_t)ld16(0x06031DE2u);  // 06031D1C mov.w 0x06031DE2,r3
    c.r[3] &= c.r[0];  // 06031D1E and r0,r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06031D20 mov.b @r1,r0
    c.r[11] = (uint32_t)(int16_t)ld16(0x06031DEEu);  // 06031D22 mov.w 0x06031DEE,r11
    c.r[5] &= c.r[0];  // 06031D24 and r0,r5
    c.r[5] |= c.r[3];  // 06031D26 or r3,r5
    st8(c.r[1], c.r[5]);  // 06031D28 mov.b r5,@r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x06031DF0u);  // 06031D2A mov.w 0x06031DF0,r3
    c.r[3] &= c.r[5];  // 06031D2C and r5,r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06031D2E mov.b @r2,r0
    c.r[5] = c.r[13];  // 06031D30 mov r13,r5
    c.r[0] &= 0x30u;  // 06031D32 and #48,r0
    c.r[3] |= c.r[0];  // 06031D34 or r0,r3
    st8(c.r[1], c.r[3]);  // 06031D36 mov.b r3,@r1
    c.r[3] &= c.r[11];  // 06031D38 and r11,r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06031D3A mov.b @r2,r0
    c.r[11] = (uint32_t)(int16_t)ld16(0x06031DF2u);  // 06031D3C mov.w 0x06031DF2,r11
    c.r[0] &= 0xCu;  // 06031D3E and #12,r0
    c.r[3] |= c.r[0];  // 06031D40 or r0,r3
    st8(c.r[1], c.r[3]);  // 06031D42 mov.b r3,@r1
    c.r[3] &= c.r[11];  // 06031D44 and r11,r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06031D46 mov.b @r2,r0
    c.r[11] = (uint32_t)(int16_t)ld16(0x06031DF4u);  // 06031D48 mov.w 0x06031DF4,r11
    c.r[0] &= 0x3u;  // 06031D4A and #3,r0
    c.r[3] |= c.r[0];  // 06031D4C or r0,r3
    st8(c.r[1], c.r[3]);  // 06031D4E mov.b r3,@r1
    c.r[1] = c.r[12];  // 06031D50 mov r12,r1
    c.r[1] += 12;  // 06031D52 add #12,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06031D54 mov.b @r1,r3
    c.r[2] = (uint32_t)(int16_t)ld16(0x06031DF6u);  // 06031D56 mov.w 0x06031DF6,r2
    c.r[3] = c.r[3] & 0xFFu;  // 06031D58 extu.b r3,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[6]);  // 06031D5A mov.w @r6,r1
    c.r[3] += c.r[3];  // 06031D5C add r3,r3
    c.r[1] &= c.r[2];  // 06031D5E and r2,r1
    c.r[1] |= c.r[3];  // 06031D60 or r3,r1
    st16(c.r[6], c.r[1]);  // 06031D62 mov.w r1,@r6
    c.r[3] = c.r[7];  // 06031D64 mov r7,r3
    c.r[1] = c.r[12];  // 06031D66 mov r12,r1
    c.r[1] += 13;  // 06031D68 add #13,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06031D6A mov.b @r1,r2
    c.r[3] += 54;  // 06031D6C add #54,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06031D6E extu.b r2,r2
    c.r[1] = c.r[12];  // 06031D70 mov r12,r1
    c.r[1] += 14;  // 06031D72 add #14,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06031D74 mov.b @r1,r1
    c.r[2] <<= 8;  // 06031D76 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06031D78 extu.b r1,r1
    c.r[2] |= c.r[1];  // 06031D7A or r1,r2
    st16(c.r[3], c.r[2]);  // 06031D7C mov.w r2,@r3
    c.r[2] = c.r[7];  // 06031D7E mov r7,r2
    c.r[1] = c.r[12];  // 06031D80 mov r12,r1
    c.r[1] += 7;  // 06031D82 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06031D84 mov.b @r1,r1
    c.r[2] += 58;  // 06031D86 add #58,r2
    st8(c.r[2], c.r[1]);  // 06031D88 mov.b r1,@r2
    c.r[2] = c.r[7];  // 06031D8A mov r7,r2
    c.r[1] = c.r[12];  // 06031D8C mov r12,r1
    c.r[1] += 9;  // 06031D8E add #9,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06031D90 mov.b @r1,r1
    c.r[2] += 61;  // 06031D92 add #61,r2
    st8(c.r[2], c.r[1]);  // 06031D94 mov.b r1,@r2
    c.r[2] = c.r[7];  // 06031D96 mov r7,r2
    c.r[1] = c.r[12];  // 06031D98 mov r12,r1
    c.r[1] += 10;  // 06031D9A add #10,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06031D9C mov.b @r1,r1
    c.r[2] += 62;  // 06031D9E add #62,r2
    st8(c.r[2], c.r[1]);  // 06031DA0 mov.b r1,@r2
    c.r[2] = c.r[7];  // 06031DA2 mov r7,r2
    c.r[1] = c.r[12];  // 06031DA4 mov r12,r1
    c.r[1] += 15;  // 06031DA6 add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06031DA8 mov.b @r1,r1
    c.r[2] += 59;  // 06031DAA add #59,r2
    st8(c.r[2], c.r[1]);  // 06031DAC mov.b r1,@r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4]);  // 06031DAE mov.b @r4,r0
    c.r[12] += 16;  // 06031DB0 add #16,r12
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 06031DB2 mov.b @r6,r1
    c.r[0] &= 0x7u;  // 06031DB4 and #7,r0
    c.r[0] <<= 2;  // 06031DB6 shll2 r0
    c.r[0] += c.r[0];  // 06031DB8 add r0,r0
    c.r[1] &= c.r[11];  // 06031DBA and r11,r1
    c.r[1] |= c.r[0];  // 06031DBC or r0,r1
    st8(c.r[6], c.r[1]);  // 06031DBE mov.b r1,@r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[12]);  // 06031DC0 mov.b @r12,r1
    c.r[7] += 60;  // 06031DC2 add #60,r7
    st8(c.r[7], c.r[1]);  // 06031DC4 mov.b r1,@r7
    c.r[1] = ld32(0x06031E08u);  // 06031DC6 mov.l 0x06031E08,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06031DCCu; c.r[4] = ld32(c.r[14]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06031DCCu) return; }  // 06031DC8 jsr @r1 ; mov.l @r14,r4
    c.r[14] += 4;  // 06031DCC add #4,r14
    c.r[15] = c.r[14];  // 06031DCE mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06031DD0 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06031DD2 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06031DD4 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06031DD6 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06031DD8 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06031DDA mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06031DDC mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06031DDE rts ; mov.l @r15+,r8
}

void f_06031E0C(SH2Context& c) {
    ran[707] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06031E0C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06031E0E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06031E10 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06031E12 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06031E14 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06031E16 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06031E18 sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x06031F26u);  // 06031E1A mov.w 0x06031F26,r3
    c.r[15] += c.r[3];  // 06031E1C add r3,r15
    c.r[14] = c.r[15];  // 06031E1E mov r15,r14
    c.r[12] = c.r[4];  // 06031E20 mov r4,r12
    c.r[11] = c.r[5];  // 06031E22 mov r5,r11
    c.r[10] = (uint32_t)(int16_t)ld16(0x06031F28u);  // 06031E24 mov.w 0x06031F28,r10
    c.r[1] = ld32(0x06031F30u);  // 06031E26 mov.l 0x06031F30,r1
    c.r[4] = ld32(0x06031F34u);  // 06031E28 mov.l 0x06031F34,r4
    c.r[1] = ld32(c.r[1]);  // 06031E2A mov.l @r1,r1
    c.r[9] = ld32(0x06031F38u);  // 06031E2C mov.l 0x06031F38,r9
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06031E2E mov.w @r1,r8
    c.r[5] = 0x1Bu;  // 06031E30 mov #27,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06031E36u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06031E36u) return; }  // 06031E32 jsr @r9 ; extu.w r8,r8
    c.r[5] = c.r[8];  // 06031E36 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06031E3Cu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06031E3Cu) return; }  // 06031E38 jsr @r9 ; mov r0,r4
    c.r[1] = c.r[0];  // 06031E3C mov r0,r1
    c.r[1] += 38;  // 06031E3E add #38,r1
    c.r[0] = ld32(0x06031F3Cu);  // 06031E40 mov.l 0x06031F3C,r0
    c.r[5] = c.r[1];  // 06031E42 mov r1,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06031E48u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06031E48u) return; }  // 06031E44 jsr @r0 ; mov r14,r4
    c.r[8] = c.r[0];  // 06031E48 mov r0,r8
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[12]);  // 06031E4A mov.w @r12,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06031F2Au);  // 06031E4C mov.w 0x06031F2A,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 06031E4E extu.w r1,r1
    c.t = c.r[1] == c.r[2];  // 06031E50 cmp/eq r2,r1
    { const bool k = !c.t; c.r[8] += 2; if (k) { goto L_06031ECC; } }  // 06031E52 bf/s 0x06031ECC ; add #2,r8
    c.r[4] = (uint32_t)(int16_t)ld16(0x06031F2Cu);  // 06031E56 mov.w 0x06031F2C,r4
    c.r[0] = ld32(0x06031F40u);  // 06031E58 mov.l 0x06031F40,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06031E5Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06031E5Eu) return; }  // 06031E5A jsr @r0 ; nop
    c.r[1] = c.r[0] & 0xFFFFu;  // 06031E5E extu.w r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06031E60 tst r1,r1
    { const bool k = !c.t; c.r[0] = c.r[10]; if (k) { goto L_06031F4E; } }  // 06031E62 bf/s 0x06031F4E ; mov r10,r0
    c.r[9] = ld32(0x06031F44u);  // 06031E66 mov.l 0x06031F44,r9
L_06031E68:
    c.r[1] = c.r[8];  // 06031E68 mov r8,r1
L_06031E6A:
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 06031E6A mov.b @r1+,r2
    c.r[2] = c.r[2] & 0xFFu;  // 06031E6C extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06031E6E mov.b @r1,r1
    c.r[2] <<= 8;  // 06031E70 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06031E72 extu.b r1,r1
    c.r[2] |= c.r[1];  // 06031E74 or r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06031E76 tst r2,r2
    { const bool k = c.t; c.r[1] = c.r[8]; if (k) { goto L_06031EC8; } }  // 06031E78 bt/s 0x06031EC8 ; mov r8,r1
    c.r[1] += 2;  // 06031E7C add #2,r1
    c.r[2] >>= 8;  // 06031E7E shlr8 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 06031E80 shlr r2
    c.r[2] >>= 2;  // 06031E82 shlr2 r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06031E84 mov.b @r1,r1
    c.r[3] = 0xFu;  // 06031E86 mov #15,r3
    c.r[0] = c.r[1] & 0xFFu;  // 06031E88 extu.b r1,r0
    c.r[1] = c.r[8];  // 06031E8A mov r8,r1
    c.r[1] += 3;  // 06031E8C add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06031E8E mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06031E90 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06031E92 tst r1,r1
    { const bool k = c.t; c.r[2] &= c.r[3]; if (k) { goto L_06031EA2; } }  // 06031E94 bt/s 0x06031EA2 ; and r3,r2
    c.t = c.r[11] == c.r[2];  // 06031E98 cmp/eq r2,r11
    { const bool k = c.t; c.r[10] = c.r[2]; if (k) { goto L_06031F4C; } }  // 06031E9A bt/s 0x06031F4C ; mov r2,r10
    c.r[8] += 4; SH2_POLL(c); goto L_06031E68;  // 06031E9E bra 0x06031E68 ; add #4,r8
L_06031EA2:
    c.r[0] &= 0x7Fu;  // 06031EA2 and #127,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06031EA4 tst r0,r0
    { const bool k = !c.t; c.t = c.r[11] == c.r[2]; if (k) { goto L_06031EB4; } }  // 06031EA6 bf/s 0x06031EB4 ; cmp/eq r2,r11
    { const bool k = c.t; c.r[8] += 4; if (k) { goto L_06031F4C; } }  // 06031EAA bt/s 0x06031F4C ; add #4,r8
    c.r[10] = (uint32_t)(int16_t)ld16(0x06031F28u);  // 06031EAE mov.w 0x06031F28,r10
    c.r[1] = c.r[8]; SH2_POLL(c); goto L_06031E6A;  // 06031EB0 bra 0x06031E6A ; mov r8,r1
L_06031EB4:
    c.r[5] = c.r[2];  // 06031EB4 mov r2,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06031EBAu; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06031EBAu) return; }  // 06031EB6 jsr @r9 ; mov r12,r4
    c.r[2] = c.r[0] & 0xFFu;  // 06031EBA extu.b r0,r2
    c.r[1] = 0x9u;  // 06031EBC mov #9,r1
    c.t = c.r[2] > c.r[1];  // 06031EBE cmp/hi r1,r2
    { const bool k = !c.t; c.r[8] += 4; if (k) { goto L_06031F4C; } }  // 06031EC0 bf/s 0x06031F4C ; add #4,r8
    SH2_POLL(c); goto L_06031E68;  // 06031EC4 bra 0x06031E68 ; nop
L_06031EC8:
    c.r[0] = c.r[10]; goto L_06031F4E;  // 06031EC8 bra 0x06031F4E ; mov r10,r0
L_06031ECC:
    c.r[9] = (uint32_t)(int16_t)ld16(0x06031F2Eu);  // 06031ECC mov.w 0x06031F2E,r9
L_06031ECE:
    c.r[1] = c.r[8];  // 06031ECE mov r8,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 06031ED0 mov.b @r1+,r2
    c.r[2] = c.r[2] & 0xFFu;  // 06031ED2 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06031ED4 mov.b @r1,r1
    c.r[2] <<= 8;  // 06031ED6 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06031ED8 extu.b r1,r1
    c.r[2] |= c.r[1];  // 06031EDA or r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06031EDC tst r2,r2
    { const bool k = c.t; c.r[2] &= c.r[9]; if (k) { goto L_06031F4C; } }  // 06031EDE bt/s 0x06031F4C ; and r9,r2
    c.r[2] >>= 8;  // 06031EE2 shlr8 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 06031EE4 shlr r2
    c.r[2] >>= 2;  // 06031EE6 shlr2 r2
    c.t = c.r[11] == c.r[2];  // 06031EE8 cmp/eq r2,r11
    { const bool k = !c.t; c.r[5] = c.r[2]; if (k) { goto L_06031F48; } }  // 06031EEA bf/s 0x06031F48 ; mov r2,r5
    c.r[0] = ld32(0x06031F44u);  // 06031EEE mov.l 0x06031F44,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06031EF4u; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06031EF4u) return; }  // 06031EF0 jsr @r0 ; mov r12,r4
    c.r[2] = c.r[0] & 0xFFu;  // 06031EF4 extu.b r0,r2
    c.r[1] = 0x9u;  // 06031EF6 mov #9,r1
    c.t = c.r[2] > c.r[1];  // 06031EF8 cmp/hi r1,r2
    { const bool k = !c.t; c.r[1] = c.r[8]; if (k) { goto L_06031F48; } }  // 06031EFA bf/s 0x06031F48 ; mov r8,r1
    c.r[1] += 6;  // 06031EFE add #6,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06031F00 mov.b @r1,r0
    c.r[0] &= 0x80u;  // 06031F02 and #128,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06031F04 tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[8]; if (k) { goto L_06031F4C; } }  // 06031F06 bt/s 0x06031F4C ; mov r8,r1
    c.r[1] += 4;  // 06031F0A add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06031F0C mov.b @r1,r1
    c.r[8] += 5;  // 06031F0E add #5,r8
    c.r[1] = c.r[1] & 0xFFu;  // 06031F10 extu.b r1,r1
    c.r[0] = c.r[1];  // 06031F12 mov r1,r0
    c.r[0] <<= 8;  // 06031F14 shll8 r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06031F16 mov.b @r8,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06031F18 extu.b r1,r1
    c.r[0] |= c.r[1];  // 06031F1A or r1,r0
    c.r[0] &= c.r[9];  // 06031F1C and r9,r0
    c.r[0] >>= 8;  // 06031F1E shlr8 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06031F20 shlr r0
    c.r[0] >>= 2; goto L_06031F4E;  // 06031F22 bra 0x06031F4E ; shlr2 r0
L_06031F48:
    c.r[8] += 4; SH2_POLL(c); goto L_06031ECE;  // 06031F48 bra 0x06031ECE ; add #4,r8
L_06031F4C:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06031F64u);  // 06031F4C mov.w 0x06031F64,r0
L_06031F4E:
    c.r[3] = (uint32_t)(int16_t)ld16(0x06031F66u);  // 06031F4E mov.w 0x06031F66,r3
    c.r[14] += c.r[3];  // 06031F50 add r3,r14
    c.r[15] = c.r[14];  // 06031F52 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06031F54 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06031F56 mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06031F58 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06031F5A mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06031F5C mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06031F5E mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06031F60 rts ; mov.l @r15+,r8
}

void f_06031F68(SH2Context& c) {
    ran[708] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06031F68 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06031F6A mov r15,r14
    c.r[5] = c.r[5] & 0xFFu;  // 06031F6C extu.b r5,r5
    c.r[1] = 0x1u;  // 06031F6E mov #1,r1
    c.r[1] &= c.r[5];  // 06031F70 and r5,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06031F72 tst r1,r1
    { const bool k = c.t; c.r[2] = c.r[5]; if (k) { goto L_06031F84; } }  // 06031F74 bt/s 0x06031F84 ; mov r5,r2
    c.t = c.r[5] & 1; c.r[5] >>= 1;  // 06031F78 shlr r5
    c.r[4] += c.r[5];  // 06031F7A add r5,r4
    c.r[4] += 6;  // 06031F7C add #6,r4
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4]);  // 06031F7E mov.b @r4,r0
    c.r[0] &= 0xFu; goto L_06031F92;  // 06031F80 bra 0x06031F92 ; and #15,r0
L_06031F84:
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 06031F84 shlr r2
    c.r[4] += c.r[2];  // 06031F86 add r2,r4
    c.r[4] += 6;  // 06031F88 add #6,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]);  // 06031F8A mov.b @r4,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06031F8C extu.b r1,r0
    c.r[0] >>= 2;  // 06031F8E shlr2 r0
    c.r[0] >>= 2;  // 06031F90 shlr2 r0
L_06031F92:
    c.r[15] = c.r[14];  // 06031F92 mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06031F94 rts ; mov.l @r15+,r14
}

void f_06031F98(SH2Context& c) {
    ran[709] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06031F98 mov.l r14,@-r15
    c.t = (c.r[5] & c.r[5]) == 0;  // 06031F9A tst r5,r5
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06031FB8; } }  // 06031F9C bt/s 0x06031FB8 ; mov r15,r14
    c.r[4] += 36;  // 06031FA0 add #36,r4
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[4]);  // 06031FA2 mov.b @r4,r3
    c.r[1] = 0x62u;  // 06031FA4 mov #98,r1
    c.r[2] = c.r[3] & 0xFFu;  // 06031FA6 extu.b r3,r2
    c.r[2] += c.r[5];  // 06031FA8 add r5,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 06031FAA cmp/gt r1,r2
    { const bool k = c.t; c.r[1] = 0x63u; if (k) { goto L_06031FB6; } }  // 06031FAC bt/s 0x06031FB6 ; mov #99,r1
    c.r[5] += c.r[3];  // 06031FB0 add r3,r5
    st8(c.r[4], c.r[5]); goto L_06031FB8;  // 06031FB2 bra 0x06031FB8 ; mov.b r5,@r4
L_06031FB6:
    st8(c.r[4], c.r[1]);  // 06031FB6 mov.b r1,@r4
L_06031FB8:
    c.r[15] = c.r[14];  // 06031FB8 mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06031FBA rts ; mov.l @r15+,r14
}

void f_06031FC0(SH2Context& c) {
    ran[710] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06031FC0 mov.l r14,@-r15
    c.t = (c.r[5] & c.r[5]) == 0;  // 06031FC2 tst r5,r5
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06031FE0; } }  // 06031FC4 bt/s 0x06031FE0 ; mov r15,r14
    c.r[4] += 34;  // 06031FC8 add #34,r4
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[4]);  // 06031FCA mov.w @r4,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x06031FE6u);  // 06031FCC mov.w 0x06031FE6,r1
    c.r[2] = c.r[3] & 0xFFFFu;  // 06031FCE extu.w r3,r2
    c.r[2] += c.r[5];  // 06031FD0 add r5,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 06031FD2 cmp/gt r1,r2
    { const bool k = c.t; c.r[5] += c.r[3]; if (k) { goto L_06031FDC; } }  // 06031FD4 bt/s 0x06031FDC ; add r3,r5
    st16(c.r[4], c.r[5]); goto L_06031FE0;  // 06031FD8 bra 0x06031FE0 ; mov.w r5,@r4
L_06031FDC:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06031FE8u);  // 06031FDC mov.w 0x06031FE8,r1
    st16(c.r[4], c.r[1]);  // 06031FDE mov.w r1,@r4
L_06031FE0:
    c.r[15] = c.r[14];  // 06031FE0 mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06031FE2 rts ; mov.l @r15+,r14
}

void f_06031FEC(SH2Context& c) {
    ran[711] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06031FEC mov.l r14,@-r15
    c.t = (c.r[5] & c.r[5]) == 0;  // 06031FEE tst r5,r5
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0603200C; } }  // 06031FF0 bt/s 0x0603200C ; mov r15,r14
    c.r[4] += 26;  // 06031FF4 add #26,r4
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[4]);  // 06031FF6 mov.w @r4,r3
    c.r[1] = ld32(0x06032014u);  // 06031FF8 mov.l 0x06032014,r1
    c.r[2] = c.r[3] & 0xFFFFu;  // 06031FFA extu.w r3,r2
    c.r[2] += c.r[5];  // 06031FFC add r5,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 06031FFE cmp/gt r1,r2
    { const bool k = c.t; c.r[5] += c.r[3]; if (k) { goto L_06032008; } }  // 06032000 bt/s 0x06032008 ; add r3,r5
    st16(c.r[4], c.r[5]); goto L_0603200C;  // 06032004 bra 0x0603200C ; mov.w r5,@r4
L_06032008:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06032012u);  // 06032008 mov.w 0x06032012,r1
    st16(c.r[4], c.r[1]);  // 0603200A mov.w r1,@r4
L_0603200C:
    c.r[15] = c.r[14];  // 0603200C mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603200E rts ; mov.l @r15+,r14
}

void f_06032018(SH2Context& c) {
    ran[712] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06032018 mov.l r14,@-r15
    c.t = (c.r[5] & c.r[5]) == 0;  // 0603201A tst r5,r5
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06032038; } }  // 0603201C bt/s 0x06032038 ; mov r15,r14
    c.r[4] += 28;  // 06032020 add #28,r4
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[4]);  // 06032022 mov.w @r4,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603203Eu);  // 06032024 mov.w 0x0603203E,r1
    c.r[2] = c.r[3] & 0xFFFFu;  // 06032026 extu.w r3,r2
    c.r[2] += c.r[5];  // 06032028 add r5,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0603202A cmp/gt r1,r2
    { const bool k = c.t; c.r[5] += c.r[3]; if (k) { goto L_06032034; } }  // 0603202C bt/s 0x06032034 ; add r3,r5
    st16(c.r[4], c.r[5]); goto L_06032038;  // 06032030 bra 0x06032038 ; mov.w r5,@r4
L_06032034:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06032040u);  // 06032034 mov.w 0x06032040,r1
    st16(c.r[4], c.r[1]);  // 06032036 mov.w r1,@r4
L_06032038:
    c.r[15] = c.r[14];  // 06032038 mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603203A rts ; mov.l @r15+,r14
}

void f_06032044(SH2Context& c) {
    ran[713] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06032044 mov.l r14,@-r15
    c.t = (c.r[5] & c.r[5]) == 0;  // 06032046 tst r5,r5
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06032064; } }  // 06032048 bt/s 0x06032064 ; mov r15,r14
    c.r[4] += 30;  // 0603204C add #30,r4
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[4]);  // 0603204E mov.w @r4,r3
    c.r[1] = ld32(0x0603206Cu);  // 06032050 mov.l 0x0603206C,r1
    c.r[2] = c.r[3] & 0xFFFFu;  // 06032052 extu.w r3,r2
    c.r[2] += c.r[5];  // 06032054 add r5,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 06032056 cmp/gt r1,r2
    { const bool k = c.t; c.r[5] += c.r[3]; if (k) { goto L_06032060; } }  // 06032058 bt/s 0x06032060 ; add r3,r5
    st16(c.r[4], c.r[5]); goto L_06032064;  // 0603205C bra 0x06032064 ; mov.w r5,@r4
L_06032060:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603206Au);  // 06032060 mov.w 0x0603206A,r1
    st16(c.r[4], c.r[1]);  // 06032062 mov.w r1,@r4
L_06032064:
    c.r[15] = c.r[14];  // 06032064 mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06032066 rts ; mov.l @r15+,r14
}

void f_06032070(SH2Context& c) {
    ran[714] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06032070 mov.l r14,@-r15
    c.t = (c.r[5] & c.r[5]) == 0;  // 06032072 tst r5,r5
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06032090; } }  // 06032074 bt/s 0x06032090 ; mov r15,r14
    c.r[4] += 32;  // 06032078 add #32,r4
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[4]);  // 0603207A mov.w @r4,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x06032096u);  // 0603207C mov.w 0x06032096,r1
    c.r[2] = c.r[3] & 0xFFFFu;  // 0603207E extu.w r3,r2
    c.r[2] += c.r[5];  // 06032080 add r5,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 06032082 cmp/gt r1,r2
    { const bool k = c.t; c.r[5] += c.r[3]; if (k) { goto L_0603208C; } }  // 06032084 bt/s 0x0603208C ; add r3,r5
    st16(c.r[4], c.r[5]); goto L_06032090;  // 06032088 bra 0x06032090 ; mov.w r5,@r4
L_0603208C:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06032098u);  // 0603208C mov.w 0x06032098,r1
    st16(c.r[4], c.r[1]);  // 0603208E mov.w r1,@r4
L_06032090:
    c.r[15] = c.r[14];  // 06032090 mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06032092 rts ; mov.l @r15+,r14
}

void f_0603209C(SH2Context& c) {
    ran[715] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603209C mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0603209E mov r15,r14
    c.t = (c.r[6] & c.r[6]) == 0;  // 060320A0 tst r6,r6
    { const bool k = c.t; c.r[5] = c.r[5] & 0xFFu; if (k) { goto L_060320C8; } }  // 060320A2 bt/s 0x060320C8 ; extu.b r5,r5
    c.r[3] = c.r[5];  // 060320A6 mov r5,r3
    c.r[3] <<= 2;  // 060320A8 shll2 r3
    c.r[3] += c.r[5];  // 060320AA add r5,r3
    c.r[3] <<= 2;  // 060320AC shll2 r3
    c.r[3] += c.r[4];  // 060320AE add r4,r3
    c.r[3] += 48;  // 060320B0 add #48,r3
    c.r[7] = (uint32_t)(int16_t)ld16(c.r[3]);  // 060320B2 mov.w @r3,r7
    c.r[1] = ld32(0x060320D0u);  // 060320B4 mov.l 0x060320D0,r1
    c.r[2] = c.r[7] & 0xFFFFu;  // 060320B6 extu.w r7,r2
    c.r[2] += c.r[6];  // 060320B8 add r6,r2
    c.t = c.r[2] > c.r[1];  // 060320BA cmp/hi r1,r2
    { const bool k = c.t; c.r[6] += c.r[7]; if (k) { goto L_060320C4; } }  // 060320BC bt/s 0x060320C4 ; add r7,r6
    st16(c.r[3], c.r[6]); goto L_060320C8;  // 060320C0 bra 0x060320C8 ; mov.w r6,@r3
L_060320C4:
    c.r[1] = (uint32_t)(int16_t)ld16(0x060320CEu);  // 060320C4 mov.w 0x060320CE,r1
    st16(c.r[3], c.r[1]);  // 060320C6 mov.w r1,@r3
L_060320C8:
    c.r[15] = c.r[14];  // 060320C8 mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060320CA rts ; mov.l @r15+,r14
}

void f_060320D4(SH2Context& c) {
    ran[716] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060320D4 mov.l r14,@-r15
    c.t = (c.r[5] & c.r[5]) == 0;  // 060320D6 tst r5,r5
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_060320F4; } }  // 060320D8 bt/s 0x060320F4 ; mov r15,r14
    c.r[4] += 16;  // 060320DC add #16,r4
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[4]);  // 060320DE mov.w @r4,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x060320FAu);  // 060320E0 mov.w 0x060320FA,r1
    c.r[2] = c.r[3] & 0xFFFFu;  // 060320E2 extu.w r3,r2
    c.r[2] += c.r[5];  // 060320E4 add r5,r2
    c.t = c.r[2] > c.r[1];  // 060320E6 cmp/hi r1,r2
    { const bool k = c.t; c.r[5] += c.r[3]; if (k) { goto L_060320F0; } }  // 060320E8 bt/s 0x060320F0 ; add r3,r5
    st16(c.r[4], c.r[5]); goto L_060320F4;  // 060320EC bra 0x060320F4 ; mov.w r5,@r4
L_060320F0:
    c.r[1] = (uint32_t)(int16_t)ld16(0x060320FCu);  // 060320F0 mov.w 0x060320FC,r1
    st16(c.r[4], c.r[1]);  // 060320F2 mov.w r1,@r4
L_060320F4:
    c.r[15] = c.r[14];  // 060320F4 mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060320F6 rts ; mov.l @r15+,r14
}

void f_06032100(SH2Context& c) {
    ran[717] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06032100 mov.l r14,@-r15
    c.r[5] = c.r[5] & 0xFFu;  // 06032102 extu.b r5,r5
    c.r[1] = c.r[5];  // 06032104 mov r5,r1
    c.r[1] <<= 2;  // 06032106 shll2 r1
    c.r[1] += c.r[5];  // 06032108 add r5,r1
    c.r[1] <<= 2;  // 0603210A shll2 r1
    c.r[4] += c.r[1];  // 0603210C add r1,r4
    c.r[1] = c.r[4];  // 0603210E mov r4,r1
    c.r[1] += 50;  // 06032110 add #50,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06032112 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06032114 extu.b r1,r0
    c.r[0] >>= 2;  // 06032116 shlr2 r0
    c.r[0] >>= 2;  // 06032118 shlr2 r0
    c.r[0] >>= 2;  // 0603211A shlr2 r0
    c.t = c.r[0] == 0x2u;  // 0603211C cmp/eq #2,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0603213A; } }  // 0603211E bt/s 0x0603213A ; mov r15,r14
    c.r[4] += 62;  // 06032122 add #62,r4
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[4]);  // 06032124 mov.b @r4,r3
    c.r[1] = 0x1u;  // 06032126 mov #1,r1
    c.r[2] = c.r[3] & 0xFFu;  // 06032128 extu.b r3,r2
    c.t = c.r[2] > c.r[1];  // 0603212A cmp/hi r1,r2
    { const bool k = !c.t; c.r[2] += c.r[6]; if (k) { goto L_0603213A; } }  // 0603212C bf/s 0x0603213A ; add r6,r2
    c.r[1] = 0x62u;  // 06032130 mov #98,r1
    c.t = c.r[2] > c.r[1];  // 06032132 cmp/hi r1,r2
    { const bool k = c.t; c.r[6] += c.r[3]; if (k) { goto L_0603213A; } }  // 06032134 bt/s 0x0603213A ; add r3,r6
    st8(c.r[4], c.r[6]);  // 06032138 mov.b r6,@r4
L_0603213A:
    c.r[15] = c.r[14];  // 0603213A mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603213C rts ; mov.l @r15+,r14
}

void f_06032140(SH2Context& c) {
    ran[718] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06032140 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06032142 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06032144 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06032146 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06032148 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0603214A mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603214C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603214E sts.l pr,@-r15
    c.r[15] -= 12;  // 06032150 add #-12,r15
    c.r[14] = c.r[15];  // 06032152 mov r15,r14
    c.r[9] = c.r[4];  // 06032154 mov r4,r9
    c.r[13] = c.r[6] & 0xFFu;  // 06032156 extu.b r6,r13
    c.r[0] = 0x0u;  // 06032158 mov #0,r0
    st32(c.r[14] + 4, c.r[0]);  // 0603215A mov.l r0,@(4,r14)
    c.r[11] = 0x0u;  // 0603215C mov #0,r11
    c.r[1] = (uint32_t)(int16_t)ld16(0x06032268u);  // 0603215E mov.w 0x06032268,r1
    c.r[1] &= c.r[13];  // 06032160 and r13,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06032162 tst r1,r1
    { const bool k = c.t; st32(c.r[14] + 8, c.r[0]); if (k) { goto L_06032170; } }  // 06032164 bt/s 0x06032170 ; mov.l r0,@(8,r14)
    c.r[0] = 0x7Fu;  // 06032168 mov #127,r0
    c.r[13] &= c.r[0];  // 0603216A and r0,r13
    c.r[0] = 0x1u;  // 0603216C mov #1,r0
    st32(c.r[14] + 4, c.r[0]);  // 0603216E mov.l r0,@(4,r14)
L_06032170:
    c.r[3] = ld32(0x0603226Cu);  // 06032170 mov.l 0x0603226C,r3
    c.r[2] = ld32(0x06032270u);  // 06032172 mov.l 0x06032270,r2
    c.r[1] = ld32(0x06032274u);  // 06032174 mov.l 0x06032274,r1
    st32(c.r[1], c.r[11]);  // 06032176 mov.l r11,@r1
    st32(c.r[2], c.r[11]);  // 06032178 mov.l r11,@r2
    st32(c.r[3], c.r[11]);  // 0603217A mov.l r11,@r3
    c.r[0] = 0x0u;  // 0603217C mov #0,r0
    st32(c.r[14], c.r[0]);  // 0603217E mov.l r0,@r14
    c.r[10] = c.r[5];  // 06032180 mov r5,r10
    c.r[10] += 2;  // 06032182 add #2,r10
L_06032184:
    c.r[1] = c.r[10];  // 06032184 mov r10,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 06032186 mov.b @r1+,r2
    c.r[2] = c.r[2] & 0xFFu;  // 06032188 extu.b r2,r2
    c.r[3] = c.r[2];  // 0603218A mov r2,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603218C mov.b @r1,r1
    c.r[3] <<= 8;  // 0603218E shll8 r3
    c.r[1] = c.r[1] & 0xFFu;  // 06032190 extu.b r1,r1
    c.r[3] |= c.r[1];  // 06032192 or r1,r3
    c.t = (c.r[3] & c.r[3]) == 0;  // 06032194 tst r3,r3
    { const bool k = !c.t; c.r[1] = c.r[10]; if (k) { goto L_0603219E; } }  // 06032196 bf/s 0x0603219E ; mov r10,r1
    goto L_06032332;  // 0603219A bra 0x06032332 ; nop
L_0603219E:
    c.r[1] += 2;  // 0603219E add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060321A0 mov.b @r1,r1
    c.r[8] = c.r[3];  // 060321A2 mov r3,r8
    c.r[8] >>= 8;  // 060321A4 shlr8 r8
    c.t = c.r[8] & 1; c.r[8] >>= 1;  // 060321A6 shlr r8
    c.r[8] >>= 2;  // 060321A8 shlr2 r8
    c.r[0] = 0xFu;  // 060321AA mov #15,r0
    c.r[8] &= c.r[0];  // 060321AC and r0,r8
    c.r[12] = 0x7Fu;  // 060321AE mov #127,r12
    c.r[6] = ld32(0x06032278u);  // 060321B0 mov.l 0x06032278,r6
    c.r[6] &= c.r[3];  // 060321B2 and r3,r6
    c.r[7] = (uint32_t)(int16_t)ld16(0x06032268u);  // 060321B4 mov.w 0x06032268,r7
    c.r[2] = 0x0u;  // 060321B6 mov #0,r2
    c.t = (c.r[6] & c.r[6]) == 0;  // 060321B8 tst r6,r6
    c.r[1] = c.r[1] & 0xFFu;  // 060321BA extu.b r1,r1
    c.r[12] &= c.r[1];  // 060321BC and r1,r12
    { const bool k = c.t; c.r[7] &= c.r[1]; if (k) { goto L_060321C6; } }  // 060321BE bt/s 0x060321C6 ; and r1,r7
    goto L_0603232E;  // 060321C2 bra 0x0603232E ; nop
L_060321C6:
    c.t = (c.r[7] & c.r[7]) == 0;  // 060321C6 tst r7,r7
    { const bool k = c.t; c.r[1] = 0x1u; if (k) { goto L_060321DC; } }  // 060321C8 bt/s 0x060321DC ; mov #1,r1
    c.r[0] = ld32(c.r[14]);  // 060321CC mov.l @r14,r0
    c.r[1] = 0xAu;  // 060321CE mov #10,r1
    c.t = c.r[0] > c.r[1];  // 060321D0 cmp/hi r1,r0
    { const bool k = c.t; c.r[2] = 0x1u; if (k) { goto L_060321DA; } }  // 060321D2 bt/s 0x060321DA ; mov #1,r2
    goto L_0603232E;  // 060321D6 bra 0x0603232E ; nop
L_060321DA:
    c.r[1] = 0x1u;  // 060321DA mov #1,r1
L_060321DC:
    c.r[1] &= c.r[8];  // 060321DC and r8,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060321DE tst r1,r1
    { const bool k = !c.t; c.r[1] = c.r[8]; if (k) { goto L_060321F4; } }  // 060321E0 bf/s 0x060321F4 ; mov r8,r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060321E4 shlr r1
    c.r[1] += c.r[9];  // 060321E6 add r9,r1
    c.r[1] += 6;  // 060321E8 add #6,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060321EA mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060321EC extu.b r1,r1
    c.r[1] >>= 2;  // 060321EE shlr2 r1
    c.r[1] >>= 2; goto L_06032200;  // 060321F0 bra 0x06032200 ; shlr2 r1
L_060321F4:
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060321F4 shlr r1
    c.r[1] += c.r[9];  // 060321F6 add r9,r1
    c.r[1] += 6;  // 060321F8 add #6,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060321FA mov.b @r1,r0
    c.r[1] = 0xFu;  // 060321FC mov #15,r1
    c.r[1] &= c.r[0];  // 060321FE and r0,r1
L_06032200:
    c.t = (c.r[7] & c.r[7]) == 0;  // 06032200 tst r7,r7
    { const bool k = !c.t; st32(c.r[14], c.r[1]); if (k) { goto L_0603220C; } }  // 06032202 bf/s 0x0603220C ; mov.l r1,@r14
    c.t = (c.r[6] & c.r[6]) == 0;  // 06032206 tst r6,r6
    if (!c.t) { goto L_0603220C; }  // 06032208 bf 0x0603220C
    c.r[2] = 0x1u;  // 0603220A mov #1,r2
L_0603220C:
    c.t = (c.r[2] & c.r[2]) == 0;  // 0603220C tst r2,r2
    { const bool k = !c.t; c.r[1] = c.r[8]; if (k) { goto L_06032216; } }  // 0603220E bf/s 0x06032216 ; mov r8,r1
    goto L_0603232E;  // 06032212 bra 0x0603232E ; nop
L_06032216:
    c.r[1] <<= 2;  // 06032216 shll2 r1
    c.r[1] += c.r[8];  // 06032218 add r8,r1
    c.r[1] <<= 2;  // 0603221A shll2 r1
    c.r[1] += c.r[9];  // 0603221C add r9,r1
    c.r[1] += 44;  // 0603221E add #44,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0603226Au);  // 06032220 mov.w 0x0603226A,r2
    c.r[3] &= c.r[2];  // 06032222 and r2,r3
    st16(c.r[1], c.r[3]);  // 06032224 mov.w r3,@r1
    c.r[1] = ld32(0x0603227Cu);  // 06032226 mov.l 0x0603227C,r1
    c.r[5] = c.r[8];  // 06032228 mov r8,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0603222Eu; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603222Eu) return; }  // 0603222A jsr @r1 ; mov r9,r4
    c.t = (c.r[12] & c.r[12]) == 0;  // 0603222E tst r12,r12
    { const bool k = c.t; c.r[1] = 0x1u; if (k) { goto L_0603232E; } }  // 06032230 bt/s 0x0603232E ; mov #1,r1
    c.r[1] &= c.r[8];  // 06032234 and r8,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06032236 tst r1,r1
    { const bool k = !c.t; c.r[1] = c.r[8]; if (k) { goto L_0603224C; } }  // 06032238 bf/s 0x0603224C ; mov r8,r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0603223C shlr r1
    c.r[1] += c.r[9];  // 0603223E add r9,r1
    c.r[1] += 6;  // 06032240 add #6,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06032242 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06032244 extu.b r1,r1
    c.r[1] >>= 2;  // 06032246 shlr2 r1
    c.r[1] >>= 2; goto L_06032258;  // 06032248 bra 0x06032258 ; shlr2 r1
L_0603224C:
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0603224C shlr r1
    c.r[1] += c.r[9];  // 0603224E add r9,r1
    c.r[1] += 6;  // 06032250 add #6,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06032252 mov.b @r1,r0
    c.r[1] = 0xFu;  // 06032254 mov #15,r1
    c.r[1] &= c.r[0];  // 06032256 and r0,r1
L_06032258:
    c.r[2] = c.r[1] & 0xFFu;  // 06032258 extu.b r1,r2
    c.r[1] = 0x9u;  // 0603225A mov #9,r1
    c.t = c.r[2] > c.r[1];  // 0603225C cmp/hi r1,r2
    { const bool k = c.t; c.r[1] = 0x1u; if (k) { goto L_06032284; } }  // 0603225E bt/s 0x06032284 ; mov #1,r1
    c.r[0] = ld32(0x06032280u);  // 06032262 mov.l 0x06032280,r0
    c.r[14] += 12; goto L_0603234E;  // 06032264 bra 0x0603234E ; add #12,r14
L_06032284:
    c.r[1] &= c.r[8];  // 06032284 and r8,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06032286 tst r1,r1
    { const bool k = !c.t; c.r[1] = c.r[8]; if (k) { goto L_0603229C; } }  // 06032288 bf/s 0x0603229C ; mov r8,r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0603228C shlr r1
    c.r[1] += c.r[9];  // 0603228E add r9,r1
    c.r[1] += 6;  // 06032290 add #6,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06032292 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06032294 extu.b r1,r1
    c.r[1] >>= 2;  // 06032296 shlr2 r1
    c.r[1] >>= 2; goto L_060322A8;  // 06032298 bra 0x060322A8 ; shlr2 r1
L_0603229C:
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0603229C shlr r1
    c.r[1] += c.r[9];  // 0603229E add r9,r1
    c.r[1] += 6;  // 060322A0 add #6,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060322A2 mov.b @r1,r0
    c.r[1] = 0xFu;  // 060322A4 mov #15,r1
    c.r[1] &= c.r[0];  // 060322A6 and r0,r1
L_060322A8:
    c.r[2] = c.r[1] & 0xFFu;  // 060322A8 extu.b r1,r2
    c.r[1] = 0xAu;  // 060322AA mov #10,r1
    c.t = c.r[2] > c.r[1];  // 060322AC cmp/hi r1,r2
    { const bool k = !c.t; c.r[3] = 0x0u; if (k) { goto L_060322C6; } }  // 060322AE bf/s 0x060322C6 ; mov #0,r3
    c.r[0] = ld32(0x06032364u);  // 060322B2 mov.l 0x06032364,r0
    c.r[4] = (uint32_t)(int16_t)ld16(0x06032362u);  // 060322B4 mov.w 0x06032362,r4
    { const uint32_t x = c.r[0]; c.pr = 0x060322BAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060322BAu) return; }  // 060322B6 jsr @r0 ; nop
    c.r[1] = c.r[0] & 0xFFFFu;  // 060322BA extu.w r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060322BC tst r1,r1
    { const bool k = !c.t; c.r[0] = 0x1u; if (k) { goto L_060322C4; } }  // 060322BE bf/s 0x060322C4 ; mov #1,r0
    st32(c.r[14] + 8, c.r[0]);  // 060322C2 mov.l r0,@(8,r14)
L_060322C4:
    c.r[3] = 0x0u;  // 060322C4 mov #0,r3
L_060322C6:
    c.r[1] = c.r[8];  // 060322C6 mov r8,r1
    c.r[1] <<= 2;  // 060322C8 shll2 r1
    c.r[1] += c.r[8];  // 060322CA add r8,r1
    c.r[1] <<= 2;  // 060322CC shll2 r1
    c.r[1] += c.r[9];  // 060322CE add r9,r1
    c.r[2] = c.r[1];  // 060322D0 mov r1,r2
    c.r[2] += 44;  // 060322D2 add #44,r2
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[2]);  // 060322D4 mov.w @r2,r2
    c.r[7] = c.r[1];  // 060322D6 mov r1,r7
    c.r[7] += 52;  // 060322D8 add #52,r7
    c.r[2] = c.r[2] & 0xFFFFu;  // 060322DA extu.w r2,r2
    c.r[1] = c.r[3];  // 060322DC mov r3,r1
L_060322DE:
    c.r[1] <<= 2;  // 060322DE shll2 r1
    c.r[0] = ld32(0x06032368u);  // 060322E0 mov.l 0x06032368,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 060322E2 mov.w @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 060322E4 extu.w r1,r1
    c.t = c.r[1] == c.r[2];  // 060322E6 cmp/eq r2,r1
    { const bool k = !c.t; c.r[0] = ld32(c.r[14] + 4); if (k) { goto L_06032320; } }  // 060322E8 bf/s 0x06032320 ; mov.l @(4,r14),r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060322EC tst r0,r0
    { const bool k = c.t; c.r[2] = c.r[13]; if (k) { goto L_060322F8; } }  // 060322EE bt/s 0x060322F8 ; mov r13,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[7]);  // 060322F2 mov.w @r7,r1
    c.t = c.r[1] & 1; c.r[1] >>= 1; goto L_06032308;  // 060322F4 bra 0x06032308 ; shlr r1
L_060322F8:
    c.r[1] = ld32(0x0603236Cu);  // 060322F8 mov.l 0x0603236C,r1
    c.r[1] = ld32(c.r[1]);  // 060322FA mov.l @r1,r1
    c.r[2] <<= 2;  // 060322FC shll2 r2
    c.r[2] <<= 2;  // 060322FE shll2 r2
    c.r[2] += c.r[1];  // 06032300 add r1,r2
    c.r[2] += c.r[12];  // 06032302 add r12,r2
    c.r[2] += 39;  // 06032304 add #39,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06032306 mov.b @r2,r1
L_06032308:
    c.r[2] = c.r[1] & 0xFFu;  // 06032308 extu.b r1,r2
    c.r[3] <<= 2;  // 0603230A shll2 r3
    c.r[0] = ld32(0x06032368u);  // 0603230C mov.l 0x06032368,r0
    c.r[3] += c.r[0];  // 0603230E add r0,r3
    c.r[3] += 2;  // 06032310 add #2,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06032312 mov.b @r3,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06032314 extu.b r1,r1
    c.macl = (c.r[1] & 0xFFFFu) * (c.r[2] & 0xFFFFu);  // 06032316 mulu.w r2,r1
    c.r[1] = c.macl;  // 06032318 sts macl,r1
    c.r[1] += c.r[11];  // 0603231A add r11,r1
    c.r[11] = c.r[1] & 0xFFFFu; goto L_0603232E;  // 0603231C bra 0x0603232E ; extu.w r1,r11
L_06032320:
    c.r[1] = c.r[3];  // 06032320 mov r3,r1
    c.r[1] += 1;  // 06032322 add #1,r1
    c.r[3] = c.r[1] & 0xFFFFu;  // 06032324 extu.w r1,r3
    c.r[1] = 0x5u;  // 06032326 mov #5,r1
    c.t = c.r[3] > c.r[1];  // 06032328 cmp/hi r1,r3
    { const bool k = !c.t; c.r[1] = c.r[3]; if (k) { SH2_POLL(c); goto L_060322DE; } }  // 0603232A bf/s 0x060322DE ; mov r3,r1
L_0603232E:
    c.r[10] += 4; SH2_POLL(c); goto L_06032184;  // 0603232E bra 0x06032184 ; add #4,r10
L_06032332:
    c.r[0] = ld32(c.r[14] + 8);  // 06032332 mov.l @(8,r14),r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06032334 tst r0,r0
    { const bool k = c.t; c.r[0] = c.r[11]; if (k) { goto L_0603234C; } }  // 06032336 bt/s 0x0603234C ; mov r11,r0
    c.r[1] = ld32(0x06032370u);  // 0603233A mov.l 0x06032370,r1
    c.r[1] = ld32(c.r[1]);  // 0603233C mov.l @r1,r1
    c.t = c.r[9] == c.r[1];  // 0603233E cmp/eq r1,r9
    if (!c.t) { goto L_0603234C; }  // 06032340 bf 0x0603234C
    c.r[4] = (uint32_t)(int16_t)ld16(0x06032362u);  // 06032342 mov.w 0x06032362,r4
    c.r[1] = ld32(0x06032374u);  // 06032344 mov.l 0x06032374,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603234Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603234Au) return; }  // 06032346 jsr @r1 ; nop
    c.r[0] = c.r[11];  // 0603234A mov r11,r0
L_0603234C:
    c.r[14] += 12;  // 0603234C add #12,r14
L_0603234E:
    c.r[15] = c.r[14];  // 0603234E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06032350 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06032352 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06032354 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06032356 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06032358 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0603235A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0603235C mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603235E rts ; mov.l @r15+,r8
}

void f_06032378(SH2Context& c) {
    ran[719] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06032378 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603237A sts.l pr,@-r15
    c.r[1] = ld32(0x06032398u);  // 0603237C mov.l 0x06032398,r1
    c.r[1] = ld32(c.r[1]);  // 0603237E mov.l @r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06032380 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06032382 extu.b r1,r0
    c.r[0] <<= 2;  // 06032384 shll2 r0
    c.r[1] = ld32(0x0603239Cu);  // 06032386 mov.l 0x0603239C,r1
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 06032388 mov.l @(r0,r1),r0
    { const uint32_t x = c.r[0]; c.pr = 0x0603238Eu; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603238Eu) return; }  // 0603238A jsr @r0 ; mov r15,r14
    c.r[15] = c.r[14];  // 0603238E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06032390 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06032392 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[0] & 0xFFFFu; c.pc = x; return; }  // 06032394 rts ; extu.w r0,r0
}

void f_060323A0(SH2Context& c) {
    ran[720] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060323A0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060323A2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060323A4 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060323A6 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060323A8 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060323AA mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060323AC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060323AE sts.l pr,@-r15
    c.r[8] = ld32(0x0603257Cu);  // 060323B0 mov.l 0x0603257C,r8
    c.r[1] = ld32(c.r[8]);  // 060323B2 mov.l @r8,r1
    c.r[1] += 5;  // 060323B4 add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060323B6 mov.b @r1,r1
    c.r[14] = c.r[15];  // 060323B8 mov r15,r14
    c.r[12] = c.r[1] & 0xFFu;  // 060323BA extu.b r1,r12
    c.r[1] = ld32(0x06032580u);  // 060323BC mov.l 0x06032580,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060323BE mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060323C0 extu.b r1,r1
    c.r[1] >>= 2;  // 060323C2 shlr2 r1
    c.r[1] >>= 2;  // 060323C4 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060323C6 shlr r1
    c.r[1] >>= 2;  // 060323C8 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060323CA tst r1,r1
    { const bool k = c.t; c.r[13] = 0x0u; if (k) { goto L_060323D2; } }  // 060323CC bt/s 0x060323D2 ; mov #0,r13
    c.r[13] = 0x1u;  // 060323D0 mov #1,r13
L_060323D2:
    c.r[1] = ld32(0x06032584u);  // 060323D2 mov.l 0x06032584,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060323D8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060323D8u) return; }  // 060323D4 jsr @r1 ; nop
    c.r[3] = ld32(c.r[8]);  // 060323D8 mov.l @r8,r3
    c.r[1] = c.r[3];  // 060323DA mov r3,r1
    c.r[1] += 1;  // 060323DC add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060323DE mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 060323E0 extu.b r2,r2
    c.r[1] = c.r[3];  // 060323E2 mov r3,r1
    c.r[1] += 2;  // 060323E4 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060323E6 mov.b @r1,r1
    c.r[2] <<= 8;  // 060323E8 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 060323EA extu.b r1,r1
    c.r[2] |= c.r[1];  // 060323EC or r1,r2
    c.r[10] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 060323EE exts.w r2,r10
    c.r[1] = c.r[3];  // 060323F0 mov r3,r1
    c.r[1] += 3;  // 060323F2 add #3,r1
    c.r[3] += 4;  // 060323F4 add #4,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060323F6 mov.b @r1,r2
    c.r[0] = c.r[10];  // 060323F8 mov r10,r0
    c.r[2] = c.r[2] & 0xFFu;  // 060323FA extu.b r2,r2
    c.r[2] <<= 8;  // 060323FC shll8 r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060323FE mov.b @r3,r1
    c.t = c.r[0] == 0xFFFFFFFEu;  // 06032400 cmp/eq #-2,r0
    c.r[1] = c.r[1] & 0xFFu;  // 06032402 extu.b r1,r1
    c.r[2] |= c.r[1];  // 06032404 or r1,r2
    { const bool k = !c.t; c.r[8] = (uint32_t)(int32_t)(int16_t)c.r[2]; if (k) { goto L_06032438; } }  // 06032406 bf/s 0x06032438 ; exts.w r2,r8
    c.r[1] = ld32(0x06032588u);  // 0603240A mov.l 0x06032588,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603240C mov.b @r1,r3
    c.r[3] = c.r[3] & 0xFFu;  // 0603240E extu.b r3,r3
    c.r[1] = ld32(0x0603258Cu);  // 06032410 mov.l 0x0603258C,r1
    c.r[2] = c.r[3];  // 06032412 mov r3,r2
    c.r[1] = ld32(c.r[1]);  // 06032414 mov.l @r1,r1
    c.r[2] <<= 2;  // 06032416 shll2 r2
    c.r[2] <<= 2;  // 06032418 shll2 r2
    c.r[2] += c.r[1];  // 0603241A add r1,r2
    c.r[2] += 2;  // 0603241C add #2,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0603241E mov.b @r2,r2
    c.r[1] = ld32(0x06032590u);  // 06032420 mov.l 0x06032590,r1
    c.r[7] = ld32(c.r[1]);  // 06032422 mov.l @r1,r7
    c.r[2] = c.r[2] & 0xFFu;  // 06032424 extu.b r2,r2
    c.r[1] = 0x1Eu;  // 06032426 mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 06032428 mul.l r1,r2
    c.r[1] = c.macl;  // 0603242A sts macl,r1
    c.r[1] += c.r[7];  // 0603242C add r7,r1
    c.r[1] += 15;  // 0603242E add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06032430 mov.b @r1,r1
    c.r[11] = c.r[3];  // 06032432 mov r3,r11
    c.r[9] = c.r[1] & 0xFFu; goto L_06032452;  // 06032434 bra 0x06032452 ; extu.b r1,r9
L_06032438:
    c.r[0] = ld32(0x06032594u);  // 06032438 mov.l 0x06032594,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0603243Eu; c.r[4] = c.r[10] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603243Eu) return; }  // 0603243A jsr @r0 ; extu.w r10,r4
    c.r[9] = c.r[0] & 0xFFu;  // 0603243E extu.b r0,r9
    c.r[0] = ld32(0x06032598u);  // 06032440 mov.l 0x06032598,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06032446u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06032446u) return; }  // 06032442 jsr @r0 ; mov r9,r4
    c.r[9] = c.r[0] & 0xFFu;  // 06032446 extu.b r0,r9
    c.r[0] = ld32(0x0603259Cu);  // 06032448 mov.l 0x0603259C,r0
    c.r[5] = 0x1u;  // 0603244A mov #1,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06032450u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06032450u) return; }  // 0603244C jsr @r0 ; mov r9,r4
    c.r[11] = c.r[0] & 0xFFu;  // 06032450 extu.b r0,r11
L_06032452:
    c.t = c.r[10] == c.r[8];  // 06032452 cmp/eq r8,r10
    if (!c.t) { goto L_0603245C; }  // 06032454 bf 0x0603245C
    c.r[8] = c.r[9];  // 06032456 mov r9,r8
    c.r[10] = c.r[11]; goto L_060324AA;  // 06032458 bra 0x060324AA ; mov r11,r10
L_0603245C:
    c.r[0] = c.r[8];  // 0603245C mov r8,r0
    c.t = c.r[0] == 0xFFFFFFFEu;  // 0603245E cmp/eq #-2,r0
    if (!c.t) { goto L_06032490; }  // 06032460 bf 0x06032490
    c.r[1] = ld32(0x06032588u);  // 06032462 mov.l 0x06032588,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06032464 mov.b @r1,r3
    c.r[3] = c.r[3] & 0xFFu;  // 06032466 extu.b r3,r3
    c.r[1] = ld32(0x0603258Cu);  // 06032468 mov.l 0x0603258C,r1
    c.r[2] = c.r[3];  // 0603246A mov r3,r2
    c.r[1] = ld32(c.r[1]);  // 0603246C mov.l @r1,r1
    c.r[2] <<= 2;  // 0603246E shll2 r2
    c.r[2] <<= 2;  // 06032470 shll2 r2
    c.r[2] += c.r[1];  // 06032472 add r1,r2
    c.r[2] += 2;  // 06032474 add #2,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06032476 mov.b @r2,r2
    c.r[1] = ld32(0x06032590u);  // 06032478 mov.l 0x06032590,r1
    c.r[7] = ld32(c.r[1]);  // 0603247A mov.l @r1,r7
    c.r[2] = c.r[2] & 0xFFu;  // 0603247C extu.b r2,r2
    c.r[1] = 0x1Eu;  // 0603247E mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 06032480 mul.l r1,r2
    c.r[1] = c.macl;  // 06032482 sts macl,r1
    c.r[1] += c.r[7];  // 06032484 add r7,r1
    c.r[1] += 15;  // 06032486 add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06032488 mov.b @r1,r1
    c.r[10] = c.r[3];  // 0603248A mov r3,r10
    c.r[8] = c.r[1] & 0xFFu; goto L_060324AA;  // 0603248C bra 0x060324AA ; extu.b r1,r8
L_06032490:
    c.r[0] = ld32(0x06032594u);  // 06032490 mov.l 0x06032594,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06032496u; c.r[4] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06032496u) return; }  // 06032492 jsr @r0 ; extu.w r8,r4
    c.r[8] = c.r[0] & 0xFFu;  // 06032496 extu.b r0,r8
    c.r[0] = ld32(0x06032598u);  // 06032498 mov.l 0x06032598,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0603249Eu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603249Eu) return; }  // 0603249A jsr @r0 ; mov r8,r4
    c.r[8] = c.r[0] & 0xFFu;  // 0603249E extu.b r0,r8
    c.r[0] = ld32(0x0603259Cu);  // 060324A0 mov.l 0x0603259C,r0
    c.r[5] = 0x1u;  // 060324A2 mov #1,r5
    { const uint32_t x = c.r[0]; c.pr = 0x060324A8u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060324A8u) return; }  // 060324A4 jsr @r0 ; mov r8,r4
    c.r[10] = c.r[0] & 0xFFu;  // 060324A8 extu.b r0,r10
L_060324AA:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06032578u);  // 060324AA mov.w 0x06032578,r1
    c.t = c.r[9] == c.r[1];  // 060324AC cmp/eq r1,r9
    { const bool k = c.t; c.t = c.r[8] == c.r[1]; if (k) { goto L_06032562; } }  // 060324AE bt/s 0x06032562 ; cmp/eq r1,r8
    if (c.t) { goto L_06032562; }  // 060324B2 bt 0x06032562
    c.r[8] = ld32(0x060325A0u);  // 060324B4 mov.l 0x060325A0,r8
    c.r[4] = ld32(c.r[8]);  // 060324B6 mov.l @r8,r4
    c.r[1] = ld32(0x060325A4u);  // 060324B8 mov.l 0x060325A4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060324BEu; c.r[5] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060324BEu) return; }  // 060324BA jsr @r1 ; mov r9,r5
    c.t = (c.r[13] & c.r[13]) == 0;  // 060324BE tst r13,r13
    { const bool k = c.t; c.r[2] = 0x5u; if (k) { goto L_060324EA; } }  // 060324C0 bt/s 0x060324EA ; mov #5,r2
    c.r[0] = ld32(0x060325A8u);  // 060324C4 mov.l 0x060325A8,r0
    c.r[6] = 0x0u;  // 060324C6 mov #0,r6
    c.r[5] = ld32(c.r[8]);  // 060324C8 mov.l @r8,r5
    { const uint32_t x = c.r[0]; c.pr = 0x060324CEu; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060324CEu) return; }  // 060324CA jsr @r0 ; mov r12,r4
    c.r[1] = ld32(0x060325ACu);  // 060324CE mov.l 0x060325AC,r1
    c.r[3] = c.r[9];  // 060324D0 mov r9,r3
    c.r[3] += c.r[3];  // 060324D2 add r3,r3
    c.r[3] += c.r[9];  // 060324D4 add r9,r3
    c.r[1] = ld32(c.r[1]);  // 060324D6 mov.l @r1,r1
    c.r[3] <<= 2;  // 060324D8 shll2 r3
    c.r[3] += c.r[1];  // 060324DA add r1,r3
    c.r[3] += 10;  // 060324DC add #10,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 060324DE mov.w @r3,r1
    c.r[2] = c.r[0] & 0xFFu;  // 060324E0 extu.b r0,r2
    c.r[1] += c.r[2];  // 060324E2 add r2,r1
    st16(c.r[3], c.r[1]);  // 060324E4 mov.w r1,@r3
    c.r[3] = 0x0u; goto L_06032504;  // 060324E6 bra 0x06032504 ; mov #0,r3
L_060324EA:
    c.r[3] = 0x0u;  // 060324EA mov #0,r3
    c.r[4] = ld32(c.r[8]);  // 060324EC mov.l @r8,r4
    c.r[1] = c.r[4];  // 060324EE mov r4,r1
L_060324F0:
    c.r[1] += c.r[3];  // 060324F0 add r3,r1
    c.r[1] += 24;  // 060324F2 add #24,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060324F4 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060324F6 extu.b r1,r1
    c.t = c.r[1] == c.r[12];  // 060324F8 cmp/eq r12,r1
    if (c.t) { goto L_06032504; }  // 060324FA bt 0x06032504
    c.r[3] += 1;  // 060324FC add #1,r3
    c.t = (int32_t)c.r[3] > (int32_t)c.r[2];  // 060324FE cmp/gt r2,r3
    { const bool k = !c.t; c.r[1] = c.r[4]; if (k) { SH2_POLL(c); goto L_060324F0; } }  // 06032500 bf/s 0x060324F0 ; mov r4,r1
L_06032504:
    c.r[0] = c.r[3];  // 06032504 mov r3,r0
    c.t = c.r[0] == 0x6u;  // 06032506 cmp/eq #6,r0
    { const bool k = c.t; c.r[6] = 0x0u; if (k) { goto L_06032562; } }  // 06032508 bt/s 0x06032562 ; mov #0,r6
    c.r[8] = ld32(0x060325A0u);  // 0603250C mov.l 0x060325A0,r8
    c.r[0] = ld32(0x060325A8u);  // 0603250E mov.l 0x060325A8,r0
    c.r[5] = ld32(c.r[8]);  // 06032510 mov.l @r8,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06032516u; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06032516u) return; }  // 06032512 jsr @r0 ; mov r12,r4
    c.r[1] = ld32(c.r[8]);  // 06032516 mov.l @r8,r1
    c.r[1] += 10;  // 06032518 add #10,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0603251A mov.w @r1,r1
    c.r[2] = c.r[0] & 0xFFu;  // 0603251C extu.b r0,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 0603251E extu.w r1,r1
    c.t = c.r[2] > c.r[1];  // 06032520 cmp/hi r1,r2
    { const bool k = c.t; c.r[7] = 0x0u; if (k) { goto L_06032562; } }  // 06032522 bt/s 0x06032562 ; mov #0,r7
    c.r[8] = ld32(0x060325B0u);  // 06032526 mov.l 0x060325B0,r8
    c.r[6] = c.r[12];  // 06032528 mov r12,r6
    c.r[5] = c.r[10];  // 0603252A mov r10,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06032530u; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06032530u) return; }  // 0603252C jsr @r8 ; mov r11,r4
    c.r[1] = c.r[0] & 0xFFu;  // 06032530 extu.b r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06032532 tst r1,r1
    { const bool k = !c.t; c.t = (c.r[13] & c.r[13]) == 0; if (k) { goto L_0603253A; } }  // 06032534 bf/s 0x0603253A ; tst r13,r13
    if (c.t) { goto L_06032562; }  // 06032538 bt 0x06032562
L_0603253A:
    c.r[1] = ld32(0x060325B4u);  // 0603253A mov.l 0x060325B4,r1
    c.r[3] = 0x0u;  // 0603253C mov #0,r3
    c.r[2] = ld32(0x060325B8u);  // 0603253E mov.l 0x060325B8,r2
    c.r[7] = 0x1u;  // 06032540 mov #1,r7
    c.r[6] = c.r[12];  // 06032542 mov r12,r6
    c.r[1] = ld32(c.r[1]);  // 06032544 mov.l @r1,r1
    c.r[5] = c.r[10];  // 06032546 mov r10,r5
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06032548 mov.b @r1,r0
    c.r[4] = c.r[11];  // 0603254A mov r11,r4
    c.r[0] &= 0x80u;  // 0603254C and #128,r0
    st8(c.r[1], c.r[0]);  // 0603254E mov.b r0,@r1
    c.r[1] += 1;  // 06032550 add #1,r1
    st8(c.r[1], c.r[9]);  // 06032552 mov.b r9,@r1
    c.r[1] = ld32(0x060325BCu);  // 06032554 mov.l 0x060325BC,r1
    st8(c.r[1], c.r[3]);  // 06032556 mov.b r3,@r1
    { const uint32_t x = c.r[8]; c.pr = 0x0603255Cu; st8(c.r[2], c.r[3]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603255Cu) return; }  // 06032558 jsr @r8 ; mov.b r3,@r2
    c.r[1] = ld32(0x060325C0u);  // 0603255C mov.l 0x060325C0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06032562u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06032562u) return; }  // 0603255E jsr @r1 ; nop
L_06032562:
    c.r[15] = c.r[14];  // 06032562 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06032564 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06032566 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06032568 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0603256A mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0603256C mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0603256E mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06032570 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0603257Au);  // 06032572 mov.w 0x0603257A,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06032574 rts ; mov.l @r15+,r8
}

void f_060325C4(SH2Context& c) {
    ran[721] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060325C4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060325C6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060325C8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060325CA mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060325CC mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060325CE mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060325D0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060325D2 sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x0603266Au);  // 060325D4 mov.w 0x0603266A,r3
    c.r[15] += c.r[3];  // 060325D6 add r3,r15
    c.r[14] = c.r[15];  // 060325D8 mov r15,r14
    c.r[4] = c.r[4] & 0xFFu;  // 060325DA extu.b r4,r4
    c.r[0] = (uint32_t)(int16_t)ld16(0x0603266Cu);  // 060325DC mov.w 0x0603266C,r0
    st32(c.r[0] + c.r[14], c.r[4]);  // 060325DE mov.l r4,@(r0,r14)
    c.r[5] = c.r[5] & 0xFFFFu;  // 060325E0 extu.w r5,r5
    c.r[11] = (uint32_t)(int16_t)ld16(0x0603266Eu);  // 060325E2 mov.w 0x0603266E,r11
    c.r[11] += c.r[14];  // 060325E4 add r14,r11
    st32(c.r[11], c.r[5]);  // 060325E6 mov.l r5,@r11
    c.r[4] = ld32(0x06032674u);  // 060325E8 mov.l 0x06032674,r4
    c.r[8] = ld32(0x06032678u);  // 060325EA mov.l 0x06032678,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060325F0u; c.r[5] = 0x1Bu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060325F0u) return; }  // 060325EC jsr @r8 ; mov #27,r5
    c.r[1] = c.r[0];  // 060325F0 mov r0,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0603266Eu);  // 060325F2 mov.w 0x0603266E,r0
    c.r[5] = ld32(c.r[0] + c.r[14]);  // 060325F4 mov.l @(r0,r14),r5
    { const uint32_t x = c.r[8]; c.pr = 0x060325FAu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060325FAu) return; }  // 060325F6 jsr @r8 ; mov r1,r4
    c.r[1] = c.r[0];  // 060325FA mov r0,r1
    c.r[1] += 7;  // 060325FC add #7,r1
    c.r[10] = 0x78u;  // 060325FE mov #120,r10
    c.r[8] = 0x7u;  // 06032600 mov #7,r8
    c.r[9] = (uint32_t)(int16_t)ld16(0x06032670u);  // 06032602 mov.w 0x06032670,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0603266Cu);  // 06032604 mov.w 0x0603266C,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06032606 mov.b @r1,r1
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06032608 mov.l @(r0,r14),r0
    c.r[10] &= c.r[1];  // 0603260A and r1,r10
    c.r[10] >>= 2;  // 0603260C shlr2 r10
    c.t = c.r[10] & 1; c.r[10] >>= 1;  // 0603260E shlr r10
    c.t = c.r[0] == c.r[9];  // 06032610 cmp/eq r9,r0
    { const bool k = !c.t; c.r[8] &= c.r[1]; if (k) { goto L_06032628; } }  // 06032612 bf/s 0x06032628 ; and r1,r8
    c.r[11] = (uint32_t)(int16_t)ld16(0x0603266Eu);  // 06032616 mov.w 0x0603266E,r11
    c.r[11] += c.r[14];  // 06032618 add r14,r11
    c.r[0] = ld32(0x0603267Cu);  // 0603261A mov.l 0x0603267C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06032620u; c.r[4] = ld32(c.r[11]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06032620u) return; }  // 0603261C jsr @r0 ; mov.l @r11,r4
    c.r[1] = c.r[0];  // 06032620 mov r0,r1
    c.r[11] = (uint32_t)(int16_t)ld16(0x06032672u);  // 06032622 mov.w 0x06032672,r11
    c.r[11] += c.r[14];  // 06032624 add r14,r11
    st8(c.r[11], c.r[1]);  // 06032626 mov.b r1,@r11
L_06032628:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0603266Cu);  // 06032628 mov.w 0x0603266C,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 0603262A mov.l @(r0,r14),r0
    c.t = c.r[0] == c.r[9];  // 0603262C cmp/eq r9,r0
    { const bool k = !c.t; c.r[1] = 0x8u; if (k) { goto L_06032636; } }  // 0603262E bf/s 0x06032636 ; mov #8,r1
    goto L_06032986;  // 06032632 bra 0x06032986 ; nop
L_06032636:
    c.r[2] = c.r[10];  // 06032636 mov r10,r2
    c.r[2] -= 1;  // 06032638 add #-1,r2
    c.t = c.r[2] > c.r[1];  // 0603263A cmp/hi r1,r2
    { const bool k = !c.t; c.r[1] = c.r[2]; if (k) { goto L_06032644; } }  // 0603263C bf/s 0x06032644 ; mov r2,r1
    goto L_06032986;  // 06032640 bra 0x06032986 ; nop
L_06032644:
    c.r[1] += c.r[1];  // 06032644 add r1,r1
    c.r[0] = 0x06032650u;  // 06032646 mova 0x06032650,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06032648 mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 0603264A add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x06032986u: goto L_06032986; case 0x06032680u: goto L_06032680; case 0x060327C4u: goto L_060327C4; case 0x06032864u: goto L_06032864; default: sh2_call(c, x); return; } }  // 0603264C jmp @r0 ; nop
L_06032662:
    c.r[11] = (uint32_t)(int16_t)ld16(0x0603266Cu);  // 06032662 mov.w 0x0603266C,r11
    c.r[11] += c.r[14];  // 06032664 add r14,r11
    st32(c.r[11], c.r[1]); goto L_06032756;  // 06032666 bra 0x06032756 ; mov.l r1,@r11
L_06032680:
    c.r[1] = ld32(0x060327BCu);  // 06032680 mov.l 0x060327BC,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060327AAu);  // 06032682 mov.w 0x060327AA,r0
    c.r[0] += c.r[14];  // 06032684 add r14,r0
    c.r[9] = 0x0u;  // 06032686 mov #0,r9
    c.r[13] = 0x1u;  // 06032688 mov #1,r13
    c.r[13] |= c.r[14];  // 0603268A or r14,r13
    c.r[2] = ld32(c.r[1]);  // 0603268C mov.l @r1,r2
    c.r[8] = c.r[14];  // 0603268E mov r14,r8
    c.r[0] = ld32(c.r[0]);  // 06032690 mov.l @r0,r0
    c.r[1] = 0x1Eu;  // 06032692 mov #30,r1
    c.macl = c.r[0] * c.r[1];  // 06032694 mul.l r1,r0
    c.r[11] = (uint32_t)(int16_t)ld16(0x060327ACu);  // 06032696 mov.w 0x060327AC,r11
    c.r[11] += c.r[14];  // 06032698 add r14,r11
    c.r[3] = c.macl;  // 0603269A sts macl,r3
    c.r[3] += c.r[2];  // 0603269C add r2,r3
    c.r[3] += 16;  // 0603269E add #16,r3
    c.r[1] = 0xFFFFFFFFu;  // 060326A0 mov #-1,r1
    st8(c.r[3], c.r[1]);  // 060326A2 mov.b r1,@r3
    c.r[0] = 0x1u;  // 060326A4 mov #1,r0
    st32(c.r[11], c.r[0]);  // 060326A6 mov.l r0,@r11
    c.r[0] = 0x0u;  // 060326A8 mov #0,r0
    c.r[11] = (uint32_t)(int16_t)ld16(0x060327AEu);  // 060326AA mov.w 0x060327AE,r11
    c.r[11] += c.r[14];  // 060326AC add r14,r11
    st32(c.r[11], c.r[0]);  // 060326AE mov.l r0,@r11
L_060326B0:
    c.r[11] = (uint32_t)(int16_t)ld16(0x060327B0u);  // 060326B0 mov.w 0x060327B0,r11
    c.r[11] += c.r[14];  // 060326B2 add r14,r11
    c.r[4] = ld32(c.r[11]);  // 060326B4 mov.l @r11,r4
    c.r[11] = (uint32_t)(int16_t)ld16(0x060327ACu);  // 060326B6 mov.w 0x060327AC,r11
    c.r[11] += c.r[14];  // 060326B8 add r14,r11
    c.r[11] = ld32(c.r[11]);  // 060326BA mov.l @r11,r11
    c.r[0] = ld32(0x060327C0u);  // 060326BC mov.l 0x060327C0,r0
    c.r[4] += c.r[11];  // 060326BE add r11,r4
    { const uint32_t x = c.r[0]; c.pr = 0x060326C4u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060326C4u) return; }  // 060326C0 jsr @r0 ; extu.w r4,r4
    c.r[1] = c.r[0];  // 060326C4 mov r0,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060326C6 extu.b r1,r1
    c.r[11] = (uint32_t)(int16_t)ld16(0x060327B2u);  // 060326C8 mov.w 0x060327B2,r11
    c.r[12] = (uint32_t)(int16_t)ld16(0x060327B4u);  // 060326CA mov.w 0x060327B4,r12
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[8]);  // 060326CC mov.b @r8,r2
    c.r[12] &= c.r[1];  // 060326CE and r1,r12
    c.r[2] &= c.r[11];  // 060326D0 and r11,r2
    st8(c.r[8], c.r[2]);  // 060326D2 mov.b r2,@r8
    st8(c.r[13], c.r[1]);  // 060326D4 mov.b r1,@r13
    c.r[1] = (uint32_t)(int16_t)ld16(0x060327B6u);  // 060326D6 mov.w 0x060327B6,r1
    c.t = c.r[12] == c.r[1];  // 060326D8 cmp/eq r1,r12
    if (!c.t) { goto L_06032736; }  // 060326DA bf 0x06032736
    c.r[0] = (uint32_t)(int16_t)ld16(0x060327B0u);  // 060326DC mov.w 0x060327B0,r0
    c.r[0] += c.r[14];  // 060326DE add r14,r0
    c.r[11] = (uint32_t)(int16_t)ld16(0x060327AEu);  // 060326E0 mov.w 0x060327AE,r11
    c.r[10] = ld32(c.r[0]);  // 060326E2 mov.l @r0,r10
    c.r[11] += c.r[14];  // 060326E4 add r14,r11
    c.r[11] = ld32(c.r[11]);  // 060326E6 mov.l @r11,r11
    c.r[10] += 1;  // 060326E8 add #1,r10
    c.r[10] += c.r[11];  // 060326EA add r11,r10
    c.r[4] = c.r[10];  // 060326EC mov r10,r4
    c.r[4] += 1;  // 060326EE add #1,r4
    c.r[0] = ld32(0x060327C0u);  // 060326F0 mov.l 0x060327C0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060326F6u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060326F6u) return; }  // 060326F2 jsr @r0 ; extu.w r4,r4
    c.r[1] = c.r[0];  // 060326F6 mov r0,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060326F8 extu.b r1,r1
    c.r[11] = (uint32_t)(int16_t)ld16(0x060327B2u);  // 060326FA mov.w 0x060327B2,r11
    c.r[3] = (uint32_t)(int16_t)ld16(0x060327B4u);  // 060326FC mov.w 0x060327B4,r3
    c.r[3] &= c.r[1];  // 060326FE and r1,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06032700 mov.b @r8,r2
    c.t = c.r[3] == c.r[12];  // 06032702 cmp/eq r12,r3
    c.r[2] &= c.r[11];  // 06032704 and r11,r2
    st8(c.r[8], c.r[2]);  // 06032706 mov.b r2,@r8
    { const bool k = !c.t; st8(c.r[13], c.r[1]); if (k) { goto L_06032736; } }  // 06032708 bf/s 0x06032736 ; mov.b r1,@r13
    c.r[10] += 2;  // 0603270C add #2,r10
    c.r[4] = c.r[10] & 0xFFFFu;  // 0603270E extu.w r10,r4
    c.r[0] = (uint32_t)(int16_t)ld16(0x060327B8u);  // 06032710 mov.w 0x060327B8,r0
    c.r[0] += c.r[14];  // 06032712 add r14,r0
    c.r[11] = ld32(0x060327C0u);  // 06032714 mov.l 0x060327C0,r11
    { const uint32_t x = c.r[11]; c.pr = 0x0603271Au; st32(c.r[0], c.r[3]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603271Au) return; }  // 06032716 jsr @r11 ; mov.l r3,@r0
    c.r[1] = c.r[0];  // 0603271A mov r0,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0603271C extu.b r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060327B2u);  // 0603271E mov.w 0x060327B2,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06032720 mov.b @r8,r2
    c.r[11] = (uint32_t)(int16_t)ld16(0x060327B4u);  // 06032722 mov.w 0x060327B4,r11
    c.r[2] &= c.r[0];  // 06032724 and r0,r2
    st8(c.r[8], c.r[2]);  // 06032726 mov.b r2,@r8
    st8(c.r[13], c.r[1]);  // 06032728 mov.b r1,@r13
    c.r[0] = (uint32_t)(int16_t)ld16(0x060327B8u);  // 0603272A mov.w 0x060327B8,r0
    c.r[0] += c.r[14];  // 0603272C add r14,r0
    c.r[3] = ld32(c.r[0]);  // 0603272E mov.l @r0,r3
    c.r[1] &= c.r[11];  // 06032730 and r11,r1
    c.t = c.r[1] == c.r[3];  // 06032732 cmp/eq r3,r1
    if (c.t) { SH2_POLL(c); goto L_06032662; }  // 06032734 bt 0x06032662
L_06032736:
    c.r[13] += 2;  // 06032736 add #2,r13
    c.r[8] += 2;  // 06032738 add #2,r8
    c.r[11] = (uint32_t)(int16_t)ld16(0x060327ACu);  // 0603273A mov.w 0x060327AC,r11
    c.r[11] += c.r[14];  // 0603273C add r14,r11
    c.r[9] += 1;  // 0603273E add #1,r9
    c.r[0] = ld32(c.r[11]);  // 06032740 mov.l @r11,r0
    c.r[1] = 0x3u;  // 06032742 mov #3,r1
    c.r[0] += 3;  // 06032744 add #3,r0
    st32(c.r[11], c.r[0]);  // 06032746 mov.l r0,@r11
    c.r[11] = (uint32_t)(int16_t)ld16(0x060327AEu);  // 06032748 mov.w 0x060327AE,r11
    c.r[11] += c.r[14];  // 0603274A add r14,r11
    c.r[0] = ld32(c.r[11]);  // 0603274C mov.l @r11,r0
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 0603274E cmp/gt r1,r9
    c.r[0] += 3;  // 06032750 add #3,r0
    { const bool k = !c.t; st32(c.r[11], c.r[0]); if (k) { SH2_POLL(c); goto L_060326B0; } }  // 06032752 bf/s 0x060326B0 ; mov.l r0,@r11
L_06032756:
    c.r[9] = 0x0u;  // 06032756 mov #0,r9
    c.r[6] = ld32(0x060327BCu);  // 06032758 mov.l 0x060327BC,r6
    c.r[7] = 0x1Eu;  // 0603275A mov #30,r7
    c.r[5] = 0x0u;  // 0603275C mov #0,r5
L_0603275E:
    c.r[1] = c.r[14];  // 0603275E mov r14,r1
    c.r[1] += 1;  // 06032760 add #1,r1
    c.r[0] = c.r[1];  // 06032762 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 06032764 mov.b @(r0,r5),r1
    c.r[11] = (uint32_t)(int16_t)ld16(0x060327BAu);  // 06032766 mov.w 0x060327BA,r11
    c.r[8] = c.r[1] & 0xFFu;  // 06032768 extu.b r1,r8
    c.macl = c.r[8] * c.r[7];  // 0603276A mul.l r7,r8
    c.r[11] += c.r[14];  // 0603276C add r14,r11
    c.r[1] = ld32(c.r[6]);  // 0603276E mov.l @r6,r1
    c.r[3] = c.macl;  // 06032770 sts macl,r3
    c.r[1] += c.r[3];  // 06032772 add r3,r1
    c.r[1] += 16;  // 06032774 add #16,r1
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[11]);  // 06032776 mov.b @r11,r11
    c.t = (c.r[9] & c.r[9]) == 0;  // 06032778 tst r9,r9
    { const bool k = !c.t; st8(c.r[1], c.r[11]); if (k) { goto L_06032794; } }  // 0603277A bf/s 0x06032794 ; mov.b r11,@r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060327AAu);  // 0603277E mov.w 0x060327AA,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06032780 mov.l @(r0,r14),r0
    c.r[1] = ld32(c.r[6]);  // 06032782 mov.l @r6,r1
    c.macl = c.r[0] * c.r[7];  // 06032784 mul.l r7,r0
    c.r[3] += c.r[1];  // 06032786 add r1,r3
    c.r[3] += 15;  // 06032788 add #15,r3
    c.r[2] = c.macl;  // 0603278A sts macl,r2
    c.r[2] += c.r[1];  // 0603278C add r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0603278E mov.b @r3,r1
    c.r[2] += 15;  // 06032790 add #15,r2
    st8(c.r[2], c.r[1]);  // 06032792 mov.b r1,@r2
L_06032794:
    c.r[9] += 1;  // 06032794 add #1,r9
    c.r[1] = 0x3u;  // 06032796 mov #3,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 06032798 cmp/gt r1,r9
    { const bool k = !c.t; c.r[5] += 2; if (k) { SH2_POLL(c); goto L_0603275E; } }  // 0603279A bf/s 0x0603275E ; add #2,r5
    goto L_06032986;  // 0603279E bra 0x06032986 ; nop
L_060327A2:
    c.r[11] = (uint32_t)(int16_t)ld16(0x060327AAu);  // 060327A2 mov.w 0x060327AA,r11
    c.r[11] += c.r[14];  // 060327A4 add r14,r11
    st32(c.r[11], c.r[2]); goto L_06032818;  // 060327A6 bra 0x06032818 ; mov.l r2,@r11
L_060327C4:
    c.r[1] = ld32(0x060328D8u);  // 060327C4 mov.l 0x060328D8,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060328CEu);  // 060327C6 mov.w 0x060328CE,r0
    c.r[2] = ld32(c.r[1]);  // 060327C8 mov.l @r1,r2
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 060327CA mov.l @(r0,r14),r0
    c.r[1] = 0x1Eu;  // 060327CC mov #30,r1
    c.macl = c.r[0] * c.r[1];  // 060327CE mul.l r1,r0
    c.r[9] = 0x0u;  // 060327D0 mov #0,r9
    c.r[10] = ld32(0x060328DCu);  // 060327D2 mov.l 0x060328DC,r10
    c.r[3] = c.macl;  // 060327D4 sts macl,r3
    c.r[3] += c.r[2];  // 060327D6 add r2,r3
    c.r[3] += 16;  // 060327D8 add #16,r3
    c.r[1] = 0xFFFFFFFFu;  // 060327DA mov #-1,r1
    st8(c.r[3], c.r[1]);  // 060327DC mov.b r1,@r3
    c.r[8] = c.r[9];  // 060327DE mov r9,r8
L_060327E0:
    c.r[11] = (uint32_t)(int16_t)ld16(0x060328D0u);  // 060327E0 mov.w 0x060328D0,r11
    c.r[11] += c.r[14];  // 060327E2 add r14,r11
    c.r[4] = ld32(c.r[11]);  // 060327E4 mov.l @r11,r4
    c.r[8] += 1;  // 060327E6 add #1,r8
    c.r[4] += c.r[8];  // 060327E8 add r8,r4
    { const uint32_t x = c.r[10]; c.pr = 0x060327EEu; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060327EEu) return; }  // 060327EA jsr @r10 ; extu.w r4,r4
    c.r[1] = c.r[0];  // 060327EE mov r0,r1
    c.r[3] = c.r[9];  // 060327F0 mov r9,r3
    c.r[3] += c.r[3];  // 060327F2 add r3,r3
    c.r[2] = c.r[1] & 0xFFu;  // 060327F4 extu.b r1,r2
    c.r[0] = c.r[14];  // 060327F6 mov r14,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 060327F8 mov.b @(r0,r3),r1
    c.r[11] = (uint32_t)(int16_t)ld16(0x060328D2u);  // 060327FA mov.w 0x060328D2,r11
    c.r[1] &= c.r[11];  // 060327FC and r11,r1
    st8(c.r[0] + c.r[3], c.r[1]);  // 060327FE mov.b r1,@(r0,r3)
    c.r[1] = c.r[14];  // 06032800 mov r14,r1
    c.r[1] += 1;  // 06032802 add #1,r1
    c.r[0] = c.r[1];  // 06032804 mov r1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x060328D4u);  // 06032806 mov.w 0x060328D4,r1
    c.t = c.r[2] == c.r[1];  // 06032808 cmp/eq r1,r2
    { const bool k = c.t; st8(c.r[0] + c.r[3], c.r[2]); if (k) { SH2_POLL(c); goto L_060327A2; } }  // 0603280A bt/s 0x060327A2 ; mov.b r2,@(r0,r3)
    c.r[9] = c.r[8];  // 0603280E mov r8,r9
    c.r[1] = 0x4u;  // 06032810 mov #4,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 06032812 cmp/gt r1,r9
    { const bool k = !c.t; c.r[8] = c.r[9]; if (k) { SH2_POLL(c); goto L_060327E0; } }  // 06032814 bf/s 0x060327E0 ; mov r9,r8
L_06032818:
    c.r[9] = 0x0u;  // 06032818 mov #0,r9
    c.r[6] = ld32(0x060328D8u);  // 0603281A mov.l 0x060328D8,r6
    c.r[7] = 0x1Eu;  // 0603281C mov #30,r7
    c.r[5] = 0x0u;  // 0603281E mov #0,r5
L_06032820:
    c.r[1] = c.r[14];  // 06032820 mov r14,r1
    c.r[1] += 1;  // 06032822 add #1,r1
    c.r[0] = c.r[1];  // 06032824 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 06032826 mov.b @(r0,r5),r1
    c.r[11] = (uint32_t)(int16_t)ld16(0x060328D6u);  // 06032828 mov.w 0x060328D6,r11
    c.r[8] = c.r[1] & 0xFFu;  // 0603282A extu.b r1,r8
    c.macl = c.r[8] * c.r[7];  // 0603282C mul.l r7,r8
    c.r[11] += c.r[14];  // 0603282E add r14,r11
    c.r[1] = ld32(c.r[6]);  // 06032830 mov.l @r6,r1
    c.r[3] = c.macl;  // 06032832 sts macl,r3
    c.r[1] += c.r[3];  // 06032834 add r3,r1
    c.r[1] += 16;  // 06032836 add #16,r1
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[11]);  // 06032838 mov.b @r11,r11
    c.t = (c.r[9] & c.r[9]) == 0;  // 0603283A tst r9,r9
    { const bool k = !c.t; st8(c.r[1], c.r[11]); if (k) { goto L_06032856; } }  // 0603283C bf/s 0x06032856 ; mov.b r11,@r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060328CEu);  // 06032840 mov.w 0x060328CE,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06032842 mov.l @(r0,r14),r0
    c.r[1] = ld32(c.r[6]);  // 06032844 mov.l @r6,r1
    c.macl = c.r[0] * c.r[7];  // 06032846 mul.l r7,r0
    c.r[3] += c.r[1];  // 06032848 add r1,r3
    c.r[3] += 15;  // 0603284A add #15,r3
    c.r[2] = c.macl;  // 0603284C sts macl,r2
    c.r[2] += c.r[1];  // 0603284E add r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06032850 mov.b @r3,r1
    c.r[2] += 15;  // 06032852 add #15,r2
    st8(c.r[2], c.r[1]);  // 06032854 mov.b r1,@r2
L_06032856:
    c.r[9] += 1;  // 06032856 add #1,r9
    c.r[1] = 0x4u;  // 06032858 mov #4,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 0603285A cmp/gt r1,r9
    { const bool k = !c.t; c.r[5] += 2; if (k) { SH2_POLL(c); goto L_06032820; } }  // 0603285C bf/s 0x06032820 ; add #2,r5
    goto L_06032986;  // 06032860 bra 0x06032986 ; nop
L_06032864:
    c.r[0] = c.r[8];  // 06032864 mov r8,r0
    c.t = c.r[0] == 0x1u;  // 06032866 cmp/eq #1,r0
    { const bool k = c.t; c.r[1] = 0x1u; if (k) { goto L_060328E0; } }  // 06032868 bt/s 0x060328E0 ; mov #1,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 0603286C cmp/gt r1,r8
    { const bool k = c.t; c.t = c.r[0] == 0x2u; if (k) { goto L_0603287E; } }  // 0603286E bt/s 0x0603287E ; cmp/eq #2,r0
    c.t = (c.r[8] & c.r[8]) == 0;  // 06032872 tst r8,r8
    if (c.t) { goto L_0603287A; }  // 06032874 bt 0x0603287A
    goto L_06032986;  // 06032876 bra 0x06032986 ; nop
L_0603287A:
    goto L_06032888;  // 0603287A bra 0x06032888 ; nop
L_0603287E:
    if (c.t) { goto L_06032884; }  // 0603287E bt 0x06032884
    goto L_06032986;  // 06032880 bra 0x06032986 ; nop
L_06032884:
    goto L_06032912;  // 06032884 bra 0x06032912 ; nop
L_06032888:
    c.r[10] = ld32(0x060328DCu);  // 06032888 mov.l 0x060328DC,r10
    { const uint32_t x = c.r[10]; c.pr = 0x0603288Eu; c.r[4] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603288Eu) return; }  // 0603288A jsr @r10 ; mov #2,r4
    c.r[1] = c.r[0];  // 0603288E mov r0,r1
    c.r[8] = c.r[1] & 0xFFu;  // 06032890 extu.b r1,r8
    c.r[9] = (uint32_t)(int16_t)ld16(0x060328D4u);  // 06032892 mov.w 0x060328D4,r9
    c.t = c.r[8] == c.r[9];  // 06032894 cmp/eq r9,r8
    if (c.t) { goto L_06032986; }  // 06032896 bt 0x06032986
    { const uint32_t x = c.r[10]; c.pr = 0x0603289Cu; c.r[4] = 0x4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603289Cu) return; }  // 06032898 jsr @r10 ; mov #4,r4
    c.r[1] = c.r[0];  // 0603289C mov r0,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0603289E extu.b r1,r1
    c.t = c.r[1] == c.r[9];  // 060328A0 cmp/eq r9,r1
    { const bool k = c.t; c.r[2] = 0x1Eu; if (k) { goto L_06032986; } }  // 060328A2 bt/s 0x06032986 ; mov #30,r2
    c.r[11] = (uint32_t)(int16_t)ld16(0x060328CEu);  // 060328A6 mov.w 0x060328CE,r11
    c.r[11] += c.r[14];  // 060328A8 add r14,r11
    c.r[11] = ld32(c.r[11]);  // 060328AA mov.l @r11,r11
    c.macl = c.r[11] * c.r[2];  // 060328AC mul.l r2,r11
    c.r[1] = ld32(0x060328D8u);  // 060328AE mov.l 0x060328D8,r1
    c.r[3] = ld32(c.r[1]);  // 060328B0 mov.l @r1,r3
    c.r[7] = c.macl;  // 060328B2 sts macl,r7
    c.r[3] += c.r[7];  // 060328B4 add r7,r3
    c.r[3] += 16;  // 060328B6 add #16,r3
    st8(c.r[3], c.r[8]);  // 060328B8 mov.b r8,@r3
    c.r[1] = ld32(c.r[1]);  // 060328BA mov.l @r1,r1
    c.macl = c.r[8] * c.r[2];  // 060328BC mul.l r2,r8
    c.r[7] += c.r[1];  // 060328BE add r1,r7
    c.r[7] += 15;  // 060328C0 add #15,r7
    c.r[2] = c.macl;  // 060328C2 sts macl,r2
    c.r[2] += c.r[1];  // 060328C4 add r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 060328C6 mov.b @r7,r1
    c.r[2] += 15;  // 060328C8 add #15,r2
    st8(c.r[2], c.r[1]); goto L_06032986;  // 060328CA bra 0x06032986 ; mov.b r1,@r2
L_060328E0:
    c.r[10] = ld32(0x060329ACu);  // 060328E0 mov.l 0x060329AC,r10
    { const uint32_t x = c.r[10]; c.pr = 0x060328E6u; c.r[4] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060328E6u) return; }  // 060328E2 jsr @r10 ; mov #2,r4
    c.r[1] = c.r[0];  // 060328E6 mov r0,r1
    c.r[8] = c.r[1] & 0xFFu;  // 060328E8 extu.b r1,r8
    c.r[9] = (uint32_t)(int16_t)ld16(0x060329A2u);  // 060328EA mov.w 0x060329A2,r9
    c.t = c.r[8] == c.r[9];  // 060328EC cmp/eq r9,r8
    if (c.t) { goto L_06032986; }  // 060328EE bt 0x06032986
    { const uint32_t x = c.r[10]; c.pr = 0x060328F4u; c.r[4] = 0x3u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060328F4u) return; }  // 060328F0 jsr @r10 ; mov #3,r4
    c.r[1] = c.r[0];  // 060328F4 mov r0,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060328F6 extu.b r1,r1
    c.t = c.r[1] == c.r[9];  // 060328F8 cmp/eq r9,r1
    if (c.t) { goto L_06032986; }  // 060328FA bt 0x06032986
    c.r[1] = ld32(0x060329B0u);  // 060328FC mov.l 0x060329B0,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060329A4u);  // 060328FE mov.w 0x060329A4,r0
    c.r[2] = ld32(c.r[1]);  // 06032900 mov.l @r1,r2
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06032902 mov.l @(r0,r14),r0
    c.r[1] = 0x1Eu;  // 06032904 mov #30,r1
    c.macl = c.r[0] * c.r[1];  // 06032906 mul.l r1,r0
    c.r[1] = c.macl;  // 06032908 sts macl,r1
    c.r[1] += c.r[2];  // 0603290A add r2,r1
    c.r[1] += 16;  // 0603290C add #16,r1
    st8(c.r[1], c.r[8]); goto L_06032986;  // 0603290E bra 0x06032986 ; mov.b r8,@r1
L_06032912:
    c.r[11] = ld32(0x060329ACu);  // 06032912 mov.l 0x060329AC,r11
    { const uint32_t x = c.r[11]; c.pr = 0x06032918u; c.r[4] = 0x3u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06032918u) return; }  // 06032914 jsr @r11 ; mov #3,r4
    c.r[1] = c.r[0];  // 06032918 mov r0,r1
    c.r[8] = c.r[1] & 0xFFu;  // 0603291A extu.b r1,r8
    c.r[6] = (uint32_t)(int16_t)ld16(0x060329A2u);  // 0603291C mov.w 0x060329A2,r6
    c.t = c.r[8] == c.r[6];  // 0603291E cmp/eq r6,r8
    { const bool k = c.t; c.r[7] = 0x1Eu; if (k) { goto L_06032958; } }  // 06032920 bt/s 0x06032958 ; mov #30,r7
    c.macl = c.r[8] * c.r[7];  // 06032924 mul.l r7,r8
    c.r[5] = ld32(0x060329B0u);  // 06032926 mov.l 0x060329B0,r5
    c.r[2] = ld32(c.r[5]);  // 06032928 mov.l @r5,r2
    c.r[3] = c.macl;  // 0603292A sts macl,r3
    c.r[2] += c.r[3];  // 0603292C add r3,r2
    c.r[2] += 16;  // 0603292E add #16,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06032930 mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06032932 extu.b r1,r1
    c.t = c.r[1] == c.r[6];  // 06032934 cmp/eq r6,r1
    if (!c.t) { goto L_06032958; }  // 06032936 bf 0x06032958
    c.r[0] = (uint32_t)(int16_t)ld16(0x060329A6u);  // 06032938 mov.w 0x060329A6,r0
    c.r[0] += c.r[14];  // 0603293A add r14,r0
    c.r[11] = (uint32_t)(int16_t)ld16(0x060329A4u);  // 0603293C mov.w 0x060329A4,r11
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0603293E mov.b @r0,r0
    c.r[11] += c.r[14];  // 06032940 add r14,r11
    st8(c.r[2], c.r[0]);  // 06032942 mov.b r0,@r2
    c.r[11] = ld32(c.r[11]);  // 06032944 mov.l @r11,r11
    c.r[1] = ld32(c.r[5]);  // 06032946 mov.l @r5,r1
    c.macl = c.r[11] * c.r[7];  // 06032948 mul.l r7,r11
    c.r[3] += c.r[1];  // 0603294A add r1,r3
    c.r[3] += 15;  // 0603294C add #15,r3
    c.r[2] = c.macl;  // 0603294E sts macl,r2
    c.r[2] += c.r[1];  // 06032950 add r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06032952 mov.b @r3,r1
    c.r[2] += 15;  // 06032954 add #15,r2
    st8(c.r[2], c.r[1]);  // 06032956 mov.b r1,@r2
L_06032958:
    c.r[0] = ld32(0x060329ACu);  // 06032958 mov.l 0x060329AC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0603295Eu; c.r[4] = 0x4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603295Eu) return; }  // 0603295A jsr @r0 ; mov #4,r4
    c.r[1] = c.r[0];  // 0603295E mov r0,r1
    c.r[8] = c.r[1] & 0xFFu;  // 06032960 extu.b r1,r8
    c.r[7] = (uint32_t)(int16_t)ld16(0x060329A2u);  // 06032962 mov.w 0x060329A2,r7
    c.t = c.r[8] == c.r[7];  // 06032964 cmp/eq r7,r8
    if (c.t) { goto L_06032986; }  // 06032966 bt 0x06032986
    c.r[1] = ld32(0x060329B0u);  // 06032968 mov.l 0x060329B0,r1
    c.r[2] = ld32(c.r[1]);  // 0603296A mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 0603296C mov #30,r1
    c.macl = c.r[8] * c.r[1];  // 0603296E mul.l r1,r8
    c.r[3] = c.macl;  // 06032970 sts macl,r3
    c.r[3] += c.r[2];  // 06032972 add r2,r3
    c.r[3] += 16;  // 06032974 add #16,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06032976 mov.b @r3,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06032978 extu.b r1,r1
    c.t = c.r[1] == c.r[7];  // 0603297A cmp/eq r7,r1
    if (!c.t) { goto L_06032986; }  // 0603297C bf 0x06032986
    c.r[11] = (uint32_t)(int16_t)ld16(0x060329A6u);  // 0603297E mov.w 0x060329A6,r11
    c.r[11] += c.r[14];  // 06032980 add r14,r11
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[11]);  // 06032982 mov.b @r11,r11
    st8(c.r[3], c.r[11]);  // 06032984 mov.b r11,@r3
L_06032986:
    c.r[0] = (uint32_t)(int16_t)ld16(0x060329A4u);  // 06032986 mov.w 0x060329A4,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06032988 mov.l @(r0,r14),r0
    c.r[3] = (uint32_t)(int16_t)ld16(0x060329A8u);  // 0603298A mov.w 0x060329A8,r3
    c.r[14] += c.r[3];  // 0603298C add r3,r14
    c.r[15] = c.r[14];  // 0603298E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06032990 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06032992 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06032994 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06032996 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06032998 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0603299A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0603299C mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603299E rts ; mov.l @r15+,r8
}

void f_060329B4(SH2Context& c) {
    ran[722] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060329B4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060329B6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060329B8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060329BA mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060329BC mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060329BE mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060329C0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060329C2 sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x06032A50u);  // 060329C4 mov.w 0x06032A50,r3
    c.r[15] += c.r[3];  // 060329C6 add r3,r15
    c.r[14] = c.r[15];  // 060329C8 mov r15,r14
    c.r[4] = c.r[4] & 0xFFu;  // 060329CA extu.b r4,r4
    c.r[0] = (uint32_t)(int16_t)ld16(0x06032A52u);  // 060329CC mov.w 0x06032A52,r0
    st32(c.r[0] + c.r[14], c.r[4]);  // 060329CE mov.l r4,@(r0,r14)
    c.r[5] = c.r[5] & 0xFFFFu;  // 060329D0 extu.w r5,r5
    c.r[12] = (uint32_t)(int16_t)ld16(0x06032A54u);  // 060329D2 mov.w 0x06032A54,r12
    c.r[12] += c.r[14];  // 060329D4 add r14,r12
    st32(c.r[12], c.r[5]);  // 060329D6 mov.l r5,@r12
    c.r[4] = ld32(0x06032A5Cu);  // 060329D8 mov.l 0x06032A5C,r4
    c.r[8] = ld32(0x06032A60u);  // 060329DA mov.l 0x06032A60,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060329E0u; c.r[5] = 0x1Bu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060329E0u) return; }  // 060329DC jsr @r8 ; mov #27,r5
    c.r[1] = c.r[0];  // 060329E0 mov r0,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06032A54u);  // 060329E2 mov.w 0x06032A54,r0
    c.r[5] = ld32(c.r[0] + c.r[14]);  // 060329E4 mov.l @(r0,r14),r5
    { const uint32_t x = c.r[8]; c.pr = 0x060329EAu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060329EAu) return; }  // 060329E6 jsr @r8 ; mov r1,r4
    c.r[1] = c.r[0];  // 060329EA mov r0,r1
    c.r[1] += 7;  // 060329EC add #7,r1
    c.r[9] = 0x78u;  // 060329EE mov #120,r9
    c.r[8] = (uint32_t)(int16_t)ld16(0x06032A56u);  // 060329F0 mov.w 0x06032A56,r8
    c.r[0] = (uint32_t)(int16_t)ld16(0x06032A52u);  // 060329F2 mov.w 0x06032A52,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060329F4 mov.b @r1,r1
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 060329F6 mov.l @(r0,r14),r0
    c.r[9] &= c.r[1];  // 060329F8 and r1,r9
    c.r[9] >>= 2;  // 060329FA shlr2 r9
    c.t = c.r[9] & 1; c.r[9] >>= 1;  // 060329FC shlr r9
    c.t = c.r[0] == c.r[8];  // 060329FE cmp/eq r8,r0
    if (!c.t) { goto L_06032A14; }  // 06032A00 bf 0x06032A14
    c.r[12] = (uint32_t)(int16_t)ld16(0x06032A54u);  // 06032A02 mov.w 0x06032A54,r12
    c.r[12] += c.r[14];  // 06032A04 add r14,r12
    c.r[0] = ld32(0x06032A64u);  // 06032A06 mov.l 0x06032A64,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06032A0Cu; c.r[4] = ld32(c.r[12]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06032A0Cu) return; }  // 06032A08 jsr @r0 ; mov.l @r12,r4
    c.r[1] = c.r[0];  // 06032A0C mov r0,r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x06032A58u);  // 06032A0E mov.w 0x06032A58,r12
    c.r[12] += c.r[14];  // 06032A10 add r14,r12
    st8(c.r[12], c.r[1]);  // 06032A12 mov.b r1,@r12
L_06032A14:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06032A52u);  // 06032A14 mov.w 0x06032A52,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06032A16 mov.l @(r0,r14),r0
    c.t = c.r[0] == c.r[8];  // 06032A18 cmp/eq r8,r0
    { const bool k = !c.t; c.r[1] = 0x5u; if (k) { goto L_06032A22; } }  // 06032A1A bf/s 0x06032A22 ; mov #5,r1
    goto L_06032C84;  // 06032A1E bra 0x06032C84 ; nop
L_06032A22:
    c.r[2] = c.r[9];  // 06032A22 mov r9,r2
    c.r[2] -= 4;  // 06032A24 add #-4,r2
    c.t = c.r[2] > c.r[1];  // 06032A26 cmp/hi r1,r2
    { const bool k = !c.t; c.r[1] = c.r[2]; if (k) { goto L_06032A30; } }  // 06032A28 bf/s 0x06032A30 ; mov r2,r1
    goto L_06032C84;  // 06032A2C bra 0x06032C84 ; nop
L_06032A30:
    c.r[1] += c.r[1];  // 06032A30 add r1,r1
    c.r[0] = 0x06032A3Cu;  // 06032A32 mova 0x06032A3C,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06032A34 mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 06032A36 add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x06032C84u: goto L_06032C84; case 0x06032A68u: goto L_06032A68; case 0x06032B90u: goto L_06032B90; case 0x06032C22u: goto L_06032C22; default: sh2_call(c, x); return; } }  // 06032A38 jmp @r0 ; nop
L_06032A48:
    c.r[12] = (uint32_t)(int16_t)ld16(0x06032A52u);  // 06032A48 mov.w 0x06032A52,r12
    c.r[12] += c.r[14];  // 06032A4A add r14,r12
    st32(c.r[12], c.r[1]); goto L_06032B1C;  // 06032A4C bra 0x06032B1C ; mov.l r1,@r12
L_06032A68:
    c.r[8] = 0x0u;  // 06032A68 mov #0,r8
    c.r[13] = 0x1u;  // 06032A6A mov #1,r13
    c.r[13] |= c.r[14];  // 06032A6C or r14,r13
    c.r[9] = c.r[14];  // 06032A6E mov r14,r9
    c.r[12] = 0x1u;  // 06032A70 mov #1,r12
    c.r[0] = (uint32_t)(int16_t)ld16(0x06032B78u);  // 06032A72 mov.w 0x06032B78,r0
    st32(c.r[0] + c.r[14], c.r[12]);  // 06032A74 mov.l r12,@(r0,r14)
    c.r[12] = 0x0u;  // 06032A76 mov #0,r12
    c.r[0] = (uint32_t)(int16_t)ld16(0x06032B7Au);  // 06032A78 mov.w 0x06032B7A,r0
    st32(c.r[0] + c.r[14], c.r[12]);  // 06032A7A mov.l r12,@(r0,r14)
L_06032A7C:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06032B7Cu);  // 06032A7C mov.w 0x06032B7C,r0
    c.r[4] = ld32(c.r[0] + c.r[14]);  // 06032A7E mov.l @(r0,r14),r4
    c.r[0] = (uint32_t)(int16_t)ld16(0x06032B78u);  // 06032A80 mov.w 0x06032B78,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06032A82 mov.l @(r0,r14),r0
    c.r[12] = ld32(0x06032B88u);  // 06032A84 mov.l 0x06032B88,r12
    c.r[4] += c.r[0];  // 06032A86 add r0,r4
    { const uint32_t x = c.r[12]; c.pr = 0x06032A8Cu; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06032A8Cu) return; }  // 06032A88 jsr @r12 ; extu.w r4,r4
    c.r[1] = c.r[0];  // 06032A8C mov r0,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06032A8E extu.b r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06032B7Eu);  // 06032A90 mov.w 0x06032B7E,r0
    c.r[3] = (uint32_t)(int16_t)ld16(0x06032B80u);  // 06032A92 mov.w 0x06032B80,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06032A94 mov.b @r9,r2
    c.r[3] &= c.r[1];  // 06032A96 and r1,r3
    c.r[2] &= c.r[0];  // 06032A98 and r0,r2
    st8(c.r[9], c.r[2]);  // 06032A9A mov.b r2,@r9
    st8(c.r[13], c.r[1]);  // 06032A9C mov.b r1,@r13
    c.r[1] = (uint32_t)(int16_t)ld16(0x06032B82u);  // 06032A9E mov.w 0x06032B82,r1
    c.t = c.r[3] == c.r[1];  // 06032AA0 cmp/eq r1,r3
    if (!c.t) { goto L_06032AFC; }  // 06032AA2 bf 0x06032AFC
    c.r[12] = (uint32_t)(int16_t)ld16(0x06032B7Cu);  // 06032AA4 mov.w 0x06032B7C,r12
    c.r[12] += c.r[14];  // 06032AA6 add r14,r12
    c.r[0] = (uint32_t)(int16_t)ld16(0x06032B7Au);  // 06032AA8 mov.w 0x06032B7A,r0
    c.r[10] = ld32(c.r[12]);  // 06032AAA mov.l @r12,r10
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06032AAC mov.l @(r0,r14),r0
    c.r[10] += 1;  // 06032AAE add #1,r10
    c.r[10] += c.r[0];  // 06032AB0 add r0,r10
    c.r[4] = c.r[10];  // 06032AB2 mov r10,r4
    c.r[4] += 1;  // 06032AB4 add #1,r4
    c.r[4] = c.r[4] & 0xFFFFu;  // 06032AB6 extu.w r4,r4
    c.r[12] = (uint32_t)(int16_t)ld16(0x06032B84u);  // 06032AB8 mov.w 0x06032B84,r12
    c.r[12] += c.r[14];  // 06032ABA add r14,r12
    c.r[0] = ld32(0x06032B88u);  // 06032ABC mov.l 0x06032B88,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06032AC2u; st32(c.r[12], c.r[3]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06032AC2u) return; }  // 06032ABE jsr @r0 ; mov.l r3,@r12
    c.r[1] = c.r[0];  // 06032AC2 mov r0,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06032AC4 extu.b r1,r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x06032B7Eu);  // 06032AC6 mov.w 0x06032B7E,r12
    c.r[11] = (uint32_t)(int16_t)ld16(0x06032B80u);  // 06032AC8 mov.w 0x06032B80,r11
    c.r[0] = (uint32_t)(int16_t)ld16(0x06032B84u);  // 06032ACA mov.w 0x06032B84,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06032ACC mov.b @r9,r2
    c.r[0] += c.r[14];  // 06032ACE add r14,r0
    c.r[2] &= c.r[12];  // 06032AD0 and r12,r2
    st8(c.r[9], c.r[2]);  // 06032AD2 mov.b r2,@r9
    st8(c.r[13], c.r[1]);  // 06032AD4 mov.b r1,@r13
    c.r[3] = ld32(c.r[0]);  // 06032AD6 mov.l @r0,r3
    c.r[11] &= c.r[1];  // 06032AD8 and r1,r11
    c.t = c.r[11] == c.r[3];  // 06032ADA cmp/eq r3,r11
    if (!c.t) { goto L_06032AFC; }  // 06032ADC bf 0x06032AFC
    c.r[10] += 2;  // 06032ADE add #2,r10
    c.r[12] = ld32(0x06032B88u);  // 06032AE0 mov.l 0x06032B88,r12
    { const uint32_t x = c.r[12]; c.pr = 0x06032AE6u; c.r[4] = c.r[10] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06032AE6u) return; }  // 06032AE2 jsr @r12 ; extu.w r10,r4
    c.r[1] = c.r[0];  // 06032AE6 mov r0,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06032AE8 extu.b r1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06032AEA mov.b @r9,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06032B7Eu);  // 06032AEC mov.w 0x06032B7E,r0
    c.r[12] = (uint32_t)(int16_t)ld16(0x06032B80u);  // 06032AEE mov.w 0x06032B80,r12
    c.r[2] &= c.r[0];  // 06032AF0 and r0,r2
    st8(c.r[9], c.r[2]);  // 06032AF2 mov.b r2,@r9
    st8(c.r[13], c.r[1]);  // 06032AF4 mov.b r1,@r13
    c.r[1] &= c.r[12];  // 06032AF6 and r12,r1
    c.t = c.r[1] == c.r[11];  // 06032AF8 cmp/eq r11,r1
    if (c.t) { SH2_POLL(c); goto L_06032A48; }  // 06032AFA bt 0x06032A48
L_06032AFC:
    c.r[13] += 2;  // 06032AFC add #2,r13
    c.r[9] += 2;  // 06032AFE add #2,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06032B78u);  // 06032B00 mov.w 0x06032B78,r0
    c.r[0] += c.r[14];  // 06032B02 add r14,r0
    c.r[8] += 1;  // 06032B04 add #1,r8
    c.r[12] = ld32(c.r[0]);  // 06032B06 mov.l @r0,r12
    c.r[1] = 0x3u;  // 06032B08 mov #3,r1
    c.r[12] += 3;  // 06032B0A add #3,r12
    st32(c.r[0], c.r[12]);  // 06032B0C mov.l r12,@r0
    c.r[0] = (uint32_t)(int16_t)ld16(0x06032B7Au);  // 06032B0E mov.w 0x06032B7A,r0
    c.r[0] += c.r[14];  // 06032B10 add r14,r0
    c.r[12] = ld32(c.r[0]);  // 06032B12 mov.l @r0,r12
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 06032B14 cmp/gt r1,r8
    c.r[12] += 3;  // 06032B16 add #3,r12
    { const bool k = !c.t; st32(c.r[0], c.r[12]); if (k) { SH2_POLL(c); goto L_06032A7C; } }  // 06032B18 bf/s 0x06032A7C ; mov.l r12,@r0
L_06032B1C:
    c.r[8] = 0x0u;  // 06032B1C mov #0,r8
    c.r[6] = ld32(0x06032B8Cu);  // 06032B1E mov.l 0x06032B8C,r6
    c.r[5] = 0x1Eu;  // 06032B20 mov #30,r5
    c.r[7] = 0x0u;  // 06032B22 mov #0,r7
L_06032B24:
    c.r[1] = c.r[14];  // 06032B24 mov r14,r1
    c.r[1] += 1;  // 06032B26 add #1,r1
    c.r[0] = c.r[1];  // 06032B28 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06032B2A mov.b @(r0,r7),r1
    c.t = (c.r[8] & c.r[8]) == 0;  // 06032B2C tst r8,r8
    c.r[4] = c.r[1] & 0xFFu;  // 06032B2E extu.b r1,r4
    c.macl = c.r[4] * c.r[5];  // 06032B30 mul.l r5,r4
    c.r[2] = ld32(c.r[6]);  // 06032B32 mov.l @r6,r2
    c.r[1] = 0xFFFFFFFFu;  // 06032B34 mov #-1,r1
    c.r[3] = c.macl;  // 06032B36 sts macl,r3
    c.r[2] += c.r[3];  // 06032B38 add r3,r2
    c.r[2] += 16;  // 06032B3A add #16,r2
    { const bool k = !c.t; st8(c.r[2], c.r[1]); if (k) { goto L_06032B62; } }  // 06032B3C bf/s 0x06032B62 ; mov.b r1,@r2
    c.r[12] = (uint32_t)(int16_t)ld16(0x06032B86u);  // 06032B40 mov.w 0x06032B86,r12
    c.r[12] += c.r[14];  // 06032B42 add r14,r12
    c.r[12] = ld32(c.r[12]);  // 06032B44 mov.l @r12,r12
    c.macl = c.r[12] * c.r[5];  // 06032B46 mul.l r5,r12
    c.r[1] = ld32(c.r[6]);  // 06032B48 mov.l @r6,r1
    c.r[2] = c.macl;  // 06032B4A sts macl,r2
    c.r[2] += c.r[1];  // 06032B4C add r1,r2
    c.r[2] += 16;  // 06032B4E add #16,r2
    st8(c.r[2], c.r[4]);  // 06032B50 mov.b r4,@r2
    c.r[1] = ld32(c.r[6]);  // 06032B52 mov.l @r6,r1
    c.r[2] = c.macl;  // 06032B54 sts macl,r2
    c.r[2] += c.r[1];  // 06032B56 add r1,r2
    c.r[3] += c.r[1];  // 06032B58 add r1,r3
    c.r[3] += 15;  // 06032B5A add #15,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06032B5C mov.b @r3,r1
    c.r[2] += 15;  // 06032B5E add #15,r2
    st8(c.r[2], c.r[1]);  // 06032B60 mov.b r1,@r2
L_06032B62:
    c.r[8] += 1;  // 06032B62 add #1,r8
    c.r[1] = 0x3u;  // 06032B64 mov #3,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 06032B66 cmp/gt r1,r8
    { const bool k = !c.t; c.r[7] += 2; if (k) { SH2_POLL(c); goto L_06032B24; } }  // 06032B68 bf/s 0x06032B24 ; add #2,r7
    goto L_06032C84;  // 06032B6C bra 0x06032C84 ; nop
L_06032B70:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06032B86u);  // 06032B70 mov.w 0x06032B86,r0
    c.r[0] += c.r[14];  // 06032B72 add r14,r0
    st32(c.r[0], c.r[2]); goto L_06032BCE;  // 06032B74 bra 0x06032BCE ; mov.l r2,@r0
L_06032B90:
    c.r[8] = 0x0u;  // 06032B90 mov #0,r8
    c.r[10] = ld32(0x06032CACu);  // 06032B92 mov.l 0x06032CAC,r10
    c.r[9] = c.r[8];  // 06032B94 mov r8,r9
L_06032B96:
    c.r[12] = (uint32_t)(int16_t)ld16(0x06032CA2u);  // 06032B96 mov.w 0x06032CA2,r12
    c.r[12] += c.r[14];  // 06032B98 add r14,r12
    c.r[4] = ld32(c.r[12]);  // 06032B9A mov.l @r12,r4
    c.r[9] += 1;  // 06032B9C add #1,r9
    c.r[4] += c.r[9];  // 06032B9E add r9,r4
    { const uint32_t x = c.r[10]; c.pr = 0x06032BA4u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06032BA4u) return; }  // 06032BA0 jsr @r10 ; extu.w r4,r4
    c.r[1] = c.r[0];  // 06032BA4 mov r0,r1
    c.r[3] = c.r[8];  // 06032BA6 mov r8,r3
    c.r[3] += c.r[3];  // 06032BA8 add r3,r3
    c.r[2] = c.r[1] & 0xFFu;  // 06032BAA extu.b r1,r2
    c.r[0] = c.r[14];  // 06032BAC mov r14,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06032BAE mov.b @(r0,r3),r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x06032CA4u);  // 06032BB0 mov.w 0x06032CA4,r12
    c.r[1] &= c.r[12];  // 06032BB2 and r12,r1
    st8(c.r[0] + c.r[3], c.r[1]);  // 06032BB4 mov.b r1,@(r0,r3)
    c.r[1] = c.r[14];  // 06032BB6 mov r14,r1
    c.r[1] += 1;  // 06032BB8 add #1,r1
    c.r[0] = c.r[1];  // 06032BBA mov r1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06032CA6u);  // 06032BBC mov.w 0x06032CA6,r1
    c.t = c.r[2] == c.r[1];  // 06032BBE cmp/eq r1,r2
    { const bool k = c.t; st8(c.r[0] + c.r[3], c.r[2]); if (k) { SH2_POLL(c); goto L_06032B70; } }  // 06032BC0 bt/s 0x06032B70 ; mov.b r2,@(r0,r3)
    c.r[8] = c.r[9];  // 06032BC4 mov r9,r8
    c.r[1] = 0x4u;  // 06032BC6 mov #4,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 06032BC8 cmp/gt r1,r8
    { const bool k = !c.t; c.r[9] = c.r[8]; if (k) { SH2_POLL(c); goto L_06032B96; } }  // 06032BCA bf/s 0x06032B96 ; mov r8,r9
L_06032BCE:
    c.r[8] = 0x0u;  // 06032BCE mov #0,r8
    c.r[6] = ld32(0x06032CB0u);  // 06032BD0 mov.l 0x06032CB0,r6
    c.r[5] = 0x1Eu;  // 06032BD2 mov #30,r5
    c.r[7] = 0x0u;  // 06032BD4 mov #0,r7
L_06032BD6:
    c.r[1] = c.r[14];  // 06032BD6 mov r14,r1
    c.r[1] += 1;  // 06032BD8 add #1,r1
    c.r[0] = c.r[1];  // 06032BDA mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06032BDC mov.b @(r0,r7),r1
    c.t = (c.r[8] & c.r[8]) == 0;  // 06032BDE tst r8,r8
    c.r[4] = c.r[1] & 0xFFu;  // 06032BE0 extu.b r1,r4
    c.macl = c.r[4] * c.r[5];  // 06032BE2 mul.l r5,r4
    c.r[2] = ld32(c.r[6]);  // 06032BE4 mov.l @r6,r2
    c.r[1] = 0xFFFFFFFFu;  // 06032BE6 mov #-1,r1
    c.r[3] = c.macl;  // 06032BE8 sts macl,r3
    c.r[2] += c.r[3];  // 06032BEA add r3,r2
    c.r[2] += 16;  // 06032BEC add #16,r2
    { const bool k = !c.t; st8(c.r[2], c.r[1]); if (k) { goto L_06032C14; } }  // 06032BEE bf/s 0x06032C14 ; mov.b r1,@r2
    c.r[12] = (uint32_t)(int16_t)ld16(0x06032CA8u);  // 06032BF2 mov.w 0x06032CA8,r12
    c.r[12] += c.r[14];  // 06032BF4 add r14,r12
    c.r[12] = ld32(c.r[12]);  // 06032BF6 mov.l @r12,r12
    c.macl = c.r[12] * c.r[5];  // 06032BF8 mul.l r5,r12
    c.r[1] = ld32(c.r[6]);  // 06032BFA mov.l @r6,r1
    c.r[2] = c.macl;  // 06032BFC sts macl,r2
    c.r[2] += c.r[1];  // 06032BFE add r1,r2
    c.r[2] += 16;  // 06032C00 add #16,r2
    st8(c.r[2], c.r[4]);  // 06032C02 mov.b r4,@r2
    c.r[1] = ld32(c.r[6]);  // 06032C04 mov.l @r6,r1
    c.r[2] = c.macl;  // 06032C06 sts macl,r2
    c.r[2] += c.r[1];  // 06032C08 add r1,r2
    c.r[3] += c.r[1];  // 06032C0A add r1,r3
    c.r[3] += 15;  // 06032C0C add #15,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06032C0E mov.b @r3,r1
    c.r[2] += 15;  // 06032C10 add #15,r2
    st8(c.r[2], c.r[1]);  // 06032C12 mov.b r1,@r2
L_06032C14:
    c.r[8] += 1;  // 06032C14 add #1,r8
    c.r[1] = 0x4u;  // 06032C16 mov #4,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 06032C18 cmp/gt r1,r8
    { const bool k = !c.t; c.r[7] += 2; if (k) { SH2_POLL(c); goto L_06032BD6; } }  // 06032C1A bf/s 0x06032BD6 ; add #2,r7
    goto L_06032C84;  // 06032C1E bra 0x06032C84 ; nop
L_06032C22:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06032CA8u);  // 06032C22 mov.w 0x06032CA8,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06032C24 mov.l @(r0,r14),r0
    c.r[11] = 0x1Eu;  // 06032C26 mov #30,r11
    c.macl = c.r[0] * c.r[11];  // 06032C28 mul.l r11,r0
    c.r[9] = ld32(0x06032CB0u);  // 06032C2A mov.l 0x06032CB0,r9
    c.r[2] = ld32(c.r[9]);  // 06032C2C mov.l @r9,r2
    c.r[10] = c.macl;  // 06032C2E sts macl,r10
    c.r[2] += c.r[10];  // 06032C30 add r10,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06032C32 mov.w @r2,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06032C34 extu.w r1,r1
    c.r[0] = c.r[1];  // 06032C36 mov r1,r0
    c.t = c.r[0] == 0x2u;  // 06032C38 cmp/eq #2,r0
    { const bool k = !c.t; c.r[2] += 16; if (k) { goto L_06032C80; } }  // 06032C3A bf/s 0x06032C80 ; add #16,r2
    c.r[13] = ld32(0x06032CACu);  // 06032C3E mov.l 0x06032CAC,r13
    { const uint32_t x = c.r[13]; c.pr = 0x06032C44u; c.r[4] = 0x3u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06032C44u) return; }  // 06032C40 jsr @r13 ; mov #3,r4
    c.r[1] = c.r[0];  // 06032C44 mov r0,r1
    c.r[4] = c.r[1] & 0xFFu;  // 06032C46 extu.b r1,r4
    c.r[12] = (uint32_t)(int16_t)ld16(0x06032CA6u);  // 06032C48 mov.w 0x06032CA6,r12
    c.t = c.r[4] == c.r[12];  // 06032C4A cmp/eq r12,r4
    { const bool k = c.t; c.r[8] = 0xFFFFFFFFu; if (k) { goto L_06032C64; } }  // 06032C4C bt/s 0x06032C64 ; mov #-1,r8
    c.macl = c.r[4] * c.r[11];  // 06032C50 mul.l r11,r4
    c.r[1] = ld32(c.r[9]);  // 06032C52 mov.l @r9,r1
    c.r[2] = c.macl;  // 06032C54 sts macl,r2
    c.r[2] += c.r[1];  // 06032C56 add r1,r2
    c.r[2] += 16;  // 06032C58 add #16,r2
    st8(c.r[2], c.r[8]);  // 06032C5A mov.b r8,@r2
    c.r[1] = ld32(c.r[9]);  // 06032C5C mov.l @r9,r1
    c.r[10] += c.r[1];  // 06032C5E add r1,r10
    c.r[10] += 16;  // 06032C60 add #16,r10
    st8(c.r[10], c.r[4]);  // 06032C62 mov.b r4,@r10
L_06032C64:
    { const uint32_t x = c.r[13]; c.pr = 0x06032C68u; c.r[4] = 0x4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06032C68u) return; }  // 06032C64 jsr @r13 ; mov #4,r4
    c.r[1] = c.r[0];  // 06032C68 mov r0,r1
    c.r[2] = c.r[1] & 0xFFu;  // 06032C6A extu.b r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06032CA6u);  // 06032C6C mov.w 0x06032CA6,r0
    c.t = c.r[2] == c.r[0];  // 06032C6E cmp/eq r0,r2
    { const bool k = c.t; c.macl = c.r[2] * c.r[11]; if (k) { goto L_06032C84; } }  // 06032C70 bt/s 0x06032C84 ; mul.l r11,r2
    c.r[1] = ld32(c.r[9]);  // 06032C74 mov.l @r9,r1
    c.r[2] = c.macl;  // 06032C76 sts macl,r2
    c.r[2] += c.r[1];  // 06032C78 add r1,r2
    c.r[2] += 16;  // 06032C7A add #16,r2
    st8(c.r[2], c.r[8]); goto L_06032C84;  // 06032C7C bra 0x06032C84 ; mov.b r8,@r2
L_06032C80:
    c.r[1] = 0xFFFFFFFFu;  // 06032C80 mov #-1,r1
    st8(c.r[2], c.r[1]);  // 06032C82 mov.b r1,@r2
L_06032C84:
    c.r[12] = (uint32_t)(int16_t)ld16(0x06032CA8u);  // 06032C84 mov.w 0x06032CA8,r12
    c.r[12] += c.r[14];  // 06032C86 add r14,r12
    c.r[0] = ld32(c.r[12]);  // 06032C88 mov.l @r12,r0
    c.r[3] = (uint32_t)(int16_t)ld16(0x06032CAAu);  // 06032C8A mov.w 0x06032CAA,r3
    c.r[14] += c.r[3];  // 06032C8C add r3,r14
    c.r[15] = c.r[14];  // 06032C8E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06032C90 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06032C92 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06032C94 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06032C96 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06032C98 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06032C9A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06032C9C mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06032C9E rts ; mov.l @r15+,r8
}

void f_06032CB4(SH2Context& c) {
    ran[723] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06032CB4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06032CB6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06032CB8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06032CBA mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06032CBC mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06032CBE mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06032CC0 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06032CC2 mov r15,r14
    c.r[0] = ld32(0x06032DF4u);  // 06032CC4 mov.l 0x06032DF4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06032CCAu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06032CCAu) return; }  // 06032CC6 jsr @r0 ; mov #0,r4
    c.r[11] = 0x0u;  // 06032CCA mov #0,r11
    c.r[12] = ld32(0x06032DF8u);  // 06032CCC mov.l 0x06032DF8,r12
    c.r[10] = 0x0u;  // 06032CCE mov #0,r10
L_06032CD0:
    c.r[0] = ld32(c.r[12]);  // 06032CD0 mov.l @r12,r0
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[10]);  // 06032CD2 mov.w @(r0,r10),r5
    c.r[4] = 0x0u;  // 06032CD4 mov #0,r4
    c.r[0] = ld32(0x06032DFCu);  // 06032CD6 mov.l 0x06032DFC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06032CDCu; c.r[5] = c.r[5] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06032CDCu) return; }  // 06032CD8 jsr @r0 ; extu.w r5,r5
    c.r[0] = c.r[0] & 0xFFFFu;  // 06032CDC extu.w r0,r0
    c.r[1] = ld32(0x06032E00u);  // 06032CDE mov.l 0x06032E00,r1
    c.t = c.r[0] == c.r[1];  // 06032CE0 cmp/eq r1,r0
    { const bool k = c.t; c.r[2] = c.r[0]; if (k) { goto L_06032D2E; } }  // 06032CE2 bt/s 0x06032D2E ; mov r0,r2
    c.r[3] = ld32(0x06032E04u);  // 06032CE6 mov.l 0x06032E04,r3
    c.r[1] = ld32(c.r[3]);  // 06032CE8 mov.l @r3,r1
    c.r[2] <<= 2;  // 06032CEA shll2 r2
    c.r[1] += c.r[2];  // 06032CEC add r2,r1
    c.r[1] += 22;  // 06032CEE add #22,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06032CF0 mov.b @r1,r0
    c.r[0] &= 0x3Fu;  // 06032CF2 and #63,r0
    st8(c.r[1], c.r[0]);  // 06032CF4 mov.b r0,@r1
    c.r[1] = ld32(0x06032E08u);  // 06032CF6 mov.l 0x06032E08,r1
    c.r[1] += c.r[2];  // 06032CF8 add r2,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06032CFA mov.b @r1,r0
    c.r[0] &= 0x3Fu;  // 06032CFC and #63,r0
    st8(c.r[1], c.r[0]);  // 06032CFE mov.b r0,@r1
    c.r[3] = ld32(c.r[3]);  // 06032D00 mov.l @r3,r3
    c.r[3] += c.r[2];  // 06032D02 add r2,r3
    c.r[1] = c.r[3];  // 06032D04 mov r3,r1
    c.r[1] += 22;  // 06032D06 add #22,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06032D08 mov.b @r1,r0
    c.r[3] += 23;  // 06032D0A add #23,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06032D0C mov.b @r3,r2
    c.r[0] &= 0x1Fu;  // 06032D0E and #31,r0
    c.r[0] <<= 2;  // 06032D10 shll2 r0
    c.r[0] += c.r[0];  // 06032D12 add r0,r0
    c.r[0] <<= 2;  // 06032D14 shll2 r0
    c.r[2] = c.r[2] & 0xFFu;  // 06032D16 extu.b r2,r2
    c.r[2] >>= 2;  // 06032D18 shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 06032D1A shlr r2
    c.r[2] |= c.r[0];  // 06032D1C or r0,r2
    c.r[1] = 0x9u;  // 06032D1E mov #9,r1
    c.t = c.r[2] > c.r[1];  // 06032D20 cmp/hi r1,r2
    if (c.t) { goto L_06032D2E; }  // 06032D22 bt 0x06032D2E
    c.r[2] = ld32(c.r[12]);  // 06032D24 mov.l @r12,r2
    c.r[1] = 0xFFFFFFFFu;  // 06032D26 mov #-1,r1
    c.r[2] += c.r[10];  // 06032D28 add r10,r2
    c.r[2] += 15;  // 06032D2A add #15,r2
    st8(c.r[2], c.r[1]);  // 06032D2C mov.b r1,@r2
L_06032D2E:
    c.r[0] = ld32(c.r[12]);  // 06032D2E mov.l @r12,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[10]);  // 06032D30 mov.w @(r0,r10),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06032DF0u);  // 06032D32 mov.w 0x06032DF0,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 06032D34 extu.w r1,r1
    c.t = c.r[1] == c.r[2];  // 06032D36 cmp/eq r2,r1
    if (!c.t) { goto L_06032D3E; }  // 06032D38 bf 0x06032D3E
    c.r[1] = (uint32_t)(int16_t)ld16(0x06032DF2u);  // 06032D3A mov.w 0x06032DF2,r1
    st16(c.r[0] + c.r[10], c.r[1]);  // 06032D3C mov.w r1,@(r0,r10)
L_06032D3E:
    c.r[9] = ld32(0x06032E0Cu);  // 06032D3E mov.l 0x06032E0C,r9
    c.r[0] = ld32(c.r[12]);  // 06032D40 mov.l @r12,r0
    c.r[5] = 0x1Bu;  // 06032D42 mov #27,r5
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[10]);  // 06032D44 mov.w @(r0,r10),r8
    c.r[4] = ld32(0x06032E10u);  // 06032D46 mov.l 0x06032E10,r4
    { const uint32_t x = c.r[9]; c.pr = 0x06032D4Cu; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06032D4Cu) return; }  // 06032D48 jsr @r9 ; extu.w r8,r8
    c.r[5] = c.r[8];  // 06032D4C mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06032D52u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06032D52u) return; }  // 06032D4E jsr @r9 ; mov r0,r4
    c.r[0] += 7;  // 06032D52 add #7,r0
    c.r[2] = 0x78u;  // 06032D54 mov #120,r2
    c.r[3] = 0x7u;  // 06032D56 mov #7,r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06032D58 mov.b @r0,r0
    c.r[1] = 0x8u;  // 06032D5A mov #8,r1
    c.r[2] &= c.r[0];  // 06032D5C and r0,r2
    c.r[2] >>= 2;  // 06032D5E shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 06032D60 shlr r2
    c.r[2] -= 1;  // 06032D62 add #-1,r2
    c.t = c.r[2] > c.r[1];  // 06032D64 cmp/hi r1,r2
    { const bool k = c.t; c.r[3] &= c.r[0]; if (k) { goto L_06032DD0; } }  // 06032D66 bt/s 0x06032DD0 ; and r0,r3
    c.r[1] = c.r[2];  // 06032D6A mov r2,r1
    c.r[1] += c.r[1];  // 06032D6C add r1,r1
    c.r[0] = 0x06032D78u;  // 06032D6E mova 0x06032D78,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06032D70 mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 06032D72 add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x06032D8Au: goto L_06032D8A; case 0x06032DD0u: goto L_06032DD0; case 0x06032DC8u: goto L_06032DC8; case 0x06032D94u: goto L_06032D94; case 0x06032D9Au: goto L_06032D9A; case 0x06032DB8u: goto L_06032DB8; default: sh2_call(c, x); return; } }  // 06032D74 jmp @r0 ; nop
L_06032D8A:
    c.t = (c.r[3] & c.r[3]) == 0;  // 06032D8A tst r3,r3
    if (c.t) { goto L_06032DD0; }  // 06032D8C bt 0x06032DD0
    c.r[0] = ld32(c.r[12]);  // 06032D8E mov.l @r12,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[10]); goto L_06032DCC;  // 06032D90 bra 0x06032DCC ; mov.w @(r0,r10),r1
L_06032D94:
    c.r[0] = ld32(0x06032E14u);  // 06032D94 mov.l 0x06032E14,r0
    c.r[4] = 0x40u; goto L_06032D9E;  // 06032D96 bra 0x06032D9E ; mov #64,r4
L_06032D9A:
    c.r[0] = ld32(0x06032E14u);  // 06032D9A mov.l 0x06032E14,r0
    c.r[4] = 0x42u;  // 06032D9C mov #66,r4
L_06032D9E:
    { const uint32_t x = c.r[0]; c.pr = 0x06032DA2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06032DA2u) return; }  // 06032D9E jsr @r0 ; nop
    c.r[1] = c.r[0] & 0xFFFFu;  // 06032DA2 extu.w r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06032DA4 tst r1,r1
    if (!c.t) { goto L_06032DD0; }  // 06032DA6 bf 0x06032DD0
    c.r[0] = ld32(c.r[12]);  // 06032DA8 mov.l @r12,r0
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[10]);  // 06032DAA mov.w @(r0,r10),r5
    c.r[4] = c.r[11] & 0xFFu;  // 06032DAC extu.b r11,r4
    c.r[0] = ld32(0x06032E18u);  // 06032DAE mov.l 0x06032E18,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06032DB4u; c.r[5] = c.r[5] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06032DB4u) return; }  // 06032DB0 jsr @r0 ; extu.w r5,r5
    c.r[10] += 30; goto L_06032DD2;  // 06032DB4 bra 0x06032DD2 ; add #30,r10
L_06032DB8:
    c.r[0] = ld32(c.r[12]);  // 06032DB8 mov.l @r12,r0
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[10]);  // 06032DBA mov.w @(r0,r10),r5
    c.r[4] = c.r[11] & 0xFFu;  // 06032DBC extu.b r11,r4
    c.r[0] = ld32(0x06032E1Cu);  // 06032DBE mov.l 0x06032E1C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06032DC4u; c.r[5] = c.r[5] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06032DC4u) return; }  // 06032DC0 jsr @r0 ; extu.w r5,r5
    c.r[10] += 30; goto L_06032DD2;  // 06032DC4 bra 0x06032DD2 ; add #30,r10
L_06032DC8:
    c.r[0] = ld32(c.r[12]);  // 06032DC8 mov.l @r12,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[10]);  // 06032DCA mov.w @(r0,r10),r1
L_06032DCC:
    c.r[1] -= c.r[3];  // 06032DCC sub r3,r1
    st16(c.r[0] + c.r[10], c.r[1]);  // 06032DCE mov.w r1,@(r0,r10)
L_06032DD0:
    c.r[10] += 30;  // 06032DD0 add #30,r10
L_06032DD2:
    c.r[11] += 1;  // 06032DD2 add #1,r11
    c.r[1] = 0x7Fu;  // 06032DD4 mov #127,r1
    c.t = (int32_t)c.r[11] > (int32_t)c.r[1];  // 06032DD6 cmp/gt r1,r11
    if (c.t) { goto L_06032DDE; }  // 06032DD8 bt 0x06032DDE
    SH2_POLL(c); goto L_06032CD0;  // 06032DDA bra 0x06032CD0 ; nop
L_06032DDE:
    c.r[15] = c.r[14];  // 06032DDE mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06032DE0 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06032DE2 mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06032DE4 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06032DE6 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06032DE8 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06032DEA mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06032DEC rts ; mov.l @r15+,r8
}

void f_06032E20(SH2Context& c) {
    ran[724] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06032E20 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06032E22 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06032E24 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06032E26 sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x06032EEAu);  // 06032E28 mov.w 0x06032EEA,r3
    c.r[15] += c.r[3];  // 06032E2A add r3,r15
    c.r[14] = c.r[15];  // 06032E2C mov r15,r14
    c.r[9] = c.r[4] & 0xFFu;  // 06032E2E extu.b r4,r9
    c.r[8] = (uint32_t)(int16_t)ld16(0x06032EECu);  // 06032E30 mov.w 0x06032EEC,r8
    c.r[0] = ld32(0x06032EF4u);  // 06032E32 mov.l 0x06032EF4,r0
    c.r[6] = c.r[14];  // 06032E34 mov r14,r6
    c.r[5] = 0x3u;  // 06032E36 mov #3,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06032E3Cu; c.r[4] = 0x4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06032E3Cu) return; }  // 06032E38 jsr @r0 ; mov #4,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 06032E3C tst r0,r0
    { const bool k = c.t; c.r[6] = 0x0u; if (k) { goto L_06032ED8; } }  // 06032E3E bt/s 0x06032ED8 ; mov #0,r6
    c.r[0] = (uint32_t)(int16_t)ld16(0x06032EEEu);  // 06032E42 mov.w 0x06032EEE,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 06032E44 mov.b @(r0,r14),r1
    c.r[2] = c.r[1] & 0xFFu;  // 06032E46 extu.b r1,r2
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[2];  // 06032E48 cmp/ge r2,r6
    { const bool k = c.t; c.r[0] = c.r[9]; if (k) { goto L_06032E80; } }  // 06032E4A bt/s 0x06032E80 ; mov r9,r0
    c.r[5] = c.r[14];  // 06032E4E mov r14,r5
    c.r[5] += 1;  // 06032E50 add #1,r5
    c.r[1] = ld32(0x06032EF8u);  // 06032E52 mov.l 0x06032EF8,r1
    c.r[6] = ld32(c.r[1]);  // 06032E54 mov.l @r1,r6
    c.r[7] = c.r[8];  // 06032E56 mov r8,r7
    c.r[4] = 0x0u;  // 06032E58 mov #0,r4
    c.r[3] = c.r[2];  // 06032E5A mov r2,r3
    c.r[3] += c.r[3];  // 06032E5C add r3,r3
    c.r[0] = c.r[4];  // 06032E5E mov r4,r0
L_06032E60:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 06032E60 mov.b @(r0,r5),r1
    c.r[2] = 0x1Eu;  // 06032E62 mov #30,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06032E64 extu.b r1,r1
    c.macl = c.r[1] * c.r[2];  // 06032E66 mul.l r2,r1
    c.r[1] = c.macl;  // 06032E68 sts macl,r1
    c.r[1] += c.r[6];  // 06032E6A add r6,r1
    c.r[1] += 16;  // 06032E6C add #16,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06032E6E mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06032E70 extu.b r1,r1
    c.t = c.r[1] == c.r[7];  // 06032E72 cmp/eq r7,r1
    if (c.t) { goto L_06032E7E; }  // 06032E74 bt 0x06032E7E
    c.r[4] += 2;  // 06032E76 add #2,r4
    c.t = (int32_t)c.r[4] >= (int32_t)c.r[3];  // 06032E78 cmp/ge r3,r4
    { const bool k = !c.t; c.r[0] = c.r[4]; if (k) { SH2_POLL(c); goto L_06032E60; } }  // 06032E7A bf/s 0x06032E60 ; mov r4,r0
L_06032E7E:
    c.r[0] = c.r[9];  // 06032E7E mov r9,r0
L_06032E80:
    c.r[0] += c.r[0];  // 06032E80 add r0,r0
    c.r[1] = c.r[14];  // 06032E82 mov r14,r1
    c.r[1] += 1;  // 06032E84 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06032E86 mov.b @(r0,r1),r1
    c.r[8] = c.r[1] & 0xFFu;  // 06032E88 extu.b r1,r8
    c.r[0] = (uint32_t)(int16_t)ld16(0x06032EEEu);  // 06032E8A mov.w 0x06032EEE,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 06032E8C mov.b @(r0,r14),r1
    c.r[6] = 0x0u;  // 06032E8E mov #0,r6
    c.r[1] = c.r[1] & 0xFFu;  // 06032E90 extu.b r1,r1
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[1];  // 06032E92 cmp/ge r1,r6
    { const bool k = c.t; c.r[5] = 0x1Eu; if (k) { goto L_06032ED6; } }  // 06032E94 bt/s 0x06032ED6 ; mov #30,r5
    c.r[4] = ld32(0x06032EF8u);  // 06032E98 mov.l 0x06032EF8,r4
    c.r[7] = 0x0u;  // 06032E9A mov #0,r7
L_06032E9C:
    c.r[1] = c.r[14];  // 06032E9C mov r14,r1
    c.r[1] += 1;  // 06032E9E add #1,r1
    c.r[0] = c.r[1];  // 06032EA0 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06032EA2 mov.b @(r0,r7),r1
    c.t = c.r[9] == c.r[6];  // 06032EA4 cmp/eq r6,r9
    c.r[2] = c.r[1] & 0xFFu;  // 06032EA6 extu.b r1,r2
    { const bool k = !c.t; c.r[3] = c.r[2]; if (k) { goto L_06032EBC; } }  // 06032EA8 bf/s 0x06032EBC ; mov r2,r3
    c.macl = c.r[2] * c.r[5];  // 06032EAC mul.l r5,r2
    c.r[1] = ld32(c.r[4]);  // 06032EAE mov.l @r4,r1
    c.r[2] = c.macl;  // 06032EB0 sts macl,r2
    c.r[2] += c.r[1];  // 06032EB2 add r1,r2
    c.r[2] += 16;  // 06032EB4 add #16,r2
    c.r[1] = 0xFFFFFFFFu;  // 06032EB6 mov #-1,r1
    st8(c.r[2], c.r[1]); goto L_06032EC8;  // 06032EB8 bra 0x06032EC8 ; mov.b r1,@r2
L_06032EBC:
    c.macl = c.r[3] * c.r[5];  // 06032EBC mul.l r5,r3
    c.r[1] = ld32(c.r[4]);  // 06032EBE mov.l @r4,r1
    c.r[2] = c.macl;  // 06032EC0 sts macl,r2
    c.r[2] += c.r[1];  // 06032EC2 add r1,r2
    c.r[2] += 16;  // 06032EC4 add #16,r2
    st8(c.r[2], c.r[8]);  // 06032EC6 mov.b r8,@r2
L_06032EC8:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06032EEEu);  // 06032EC8 mov.w 0x06032EEE,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 06032ECA mov.b @(r0,r14),r1
    c.r[6] += 1;  // 06032ECC add #1,r6
    c.r[1] = c.r[1] & 0xFFu;  // 06032ECE extu.b r1,r1
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[1];  // 06032ED0 cmp/ge r1,r6
    { const bool k = !c.t; c.r[7] += 2; if (k) { SH2_POLL(c); goto L_06032E9C; } }  // 06032ED2 bf/s 0x06032E9C ; add #2,r7
L_06032ED6:
    c.r[8] = 0x0u;  // 06032ED6 mov #0,r8
L_06032ED8:
    c.r[3] = (uint32_t)(int16_t)ld16(0x06032EF0u);  // 06032ED8 mov.w 0x06032EF0,r3
    c.r[14] += c.r[3];  // 06032EDA add r3,r14
    c.r[15] = c.r[14];  // 06032EDC mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06032EDE lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06032EE0 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06032EE2 mov.l @r15+,r9
    c.r[0] = c.r[8];  // 06032EE4 mov r8,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06032EE6 rts ; mov.l @r15+,r8
}

void f_06032EFC(SH2Context& c) {
    ran[725] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06032EFC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06032EFE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06032F00 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06032F02 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06032F04 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06032F06 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06032F08 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06032F0A sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x06033080u);  // 06032F0C mov.w 0x06033080,r3
    c.r[15] += c.r[3];  // 06032F0E add r3,r15
    c.r[14] = c.r[15];  // 06032F10 mov r15,r14
    c.r[4] = c.r[4] & 0xFFFFu;  // 06032F12 extu.w r4,r4
    c.r[0] = (uint32_t)(int16_t)ld16(0x06033082u);  // 06032F14 mov.w 0x06033082,r0
    st32(c.r[0] + c.r[14], c.r[4]);  // 06032F16 mov.l r4,@(r0,r14)
    c.r[8] = (uint32_t)(int16_t)ld16(0x06033084u);  // 06032F18 mov.w 0x06033084,r8
    c.r[11] = 0x0u;  // 06032F1A mov #0,r11
    c.r[9] = ld32(0x06033090u);  // 06032F1C mov.l 0x06033090,r9
L_06032F1E:
    c.r[1] = ld32(0x06033094u);  // 06032F1E mov.l 0x06033094,r1
    c.r[0] = c.r[11];  // 06032F20 mov r11,r0
    c.r[0] <<= 2;  // 06032F22 shll2 r0
    c.r[0] <<= 2;  // 06032F24 shll2 r0
    c.r[1] = ld32(c.r[1]);  // 06032F26 mov.l @r1,r1
    c.r[3] = c.r[0];  // 06032F28 mov r0,r3
    c.r[3] += c.r[1];  // 06032F2A add r1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06032F2C mov.b @(r0,r1),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06033084u);  // 06032F2E mov.w 0x06033084,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06032F30 extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 06032F32 cmp/eq r2,r1
    { const bool k = c.t; c.r[1] = c.r[11]; if (k) { goto L_06032F6C; } }  // 06032F34 bt/s 0x06032F6C ; mov r11,r1
    c.r[1] = c.r[3];  // 06032F38 mov r3,r1
    c.r[1] += 7;  // 06032F3A add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06032F3C mov.b @r1,r1
    c.r[0] = c.r[1];  // 06032F3E mov r1,r0
    c.r[0] >>= 2;  // 06032F40 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06032F42 shlr r0
    c.r[0] &= 0x1u;  // 06032F44 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06032F46 tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[11]; if (k) { goto L_06032F6C; } }  // 06032F48 bf/s 0x06032F6C ; mov r11,r1
    c.r[3] += 2;  // 06032F4C add #2,r3
    c.r[6] = c.r[11];  // 06032F4E mov r11,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06032F50 mov.b @r3,r1
    c.r[4] = c.r[14];  // 06032F52 mov r14,r4
    c.r[8] = c.r[1] & 0xFFu;  // 06032F54 extu.b r1,r8
    { const uint32_t x = c.r[9]; c.pr = 0x06032F5Au; c.r[5] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06032F5Au) return; }  // 06032F56 jsr @r9 ; mov r8,r5
    c.r[0] = (uint32_t)(int16_t)ld16(0x06033086u);  // 06032F5A mov.w 0x06033086,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 06032F5C mov.b @(r0,r14),r1
    c.r[0] = c.r[1];  // 06032F5E mov r1,r0
    c.r[0] >>= 2;  // 06032F60 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06032F62 shlr r0
    c.r[0] &= 0x1u;  // 06032F64 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06032F66 tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[11]; if (k) { goto L_06032F76; } }  // 06032F68 bf/s 0x06032F76 ; mov r11,r1
L_06032F6C:
    c.r[1] += 1;  // 06032F6C add #1,r1
    c.r[11] = c.r[1] & 0xFFu;  // 06032F6E extu.b r1,r11
    c.r[1] = 0x49u;  // 06032F70 mov #73,r1
    c.t = c.r[11] > c.r[1];  // 06032F72 cmp/hi r1,r11
    if (!c.t) { SH2_POLL(c); goto L_06032F1E; }  // 06032F74 bf 0x06032F1E
L_06032F76:
    c.r[0] = c.r[11];  // 06032F76 mov r11,r0
    c.t = c.r[0] == 0x4Au;  // 06032F78 cmp/eq #74,r0
    { const bool k = !c.t; c.r[0] = 0xFFFFFFFFu; if (k) { goto L_06032F82; } }  // 06032F7A bf/s 0x06032F82 ; mov #-1,r0
    goto L_0603331E;  // 06032F7E bra 0x0603331E ; nop
L_06032F82:
    c.r[12] = (uint32_t)(int16_t)ld16(0x06033082u);  // 06032F82 mov.w 0x06033082,r12
    c.r[12] += c.r[14];  // 06032F84 add r14,r12
    c.r[12] = ld32(c.r[12]);  // 06032F86 mov.l @r12,r12
    c.t = (c.r[12] & c.r[12]) == 0;  // 06032F88 tst r12,r12
    if (c.t) { goto L_06032F9A; }  // 06032F8A bt 0x06032F9A
    c.r[0] = (uint32_t)(int16_t)ld16(0x06033082u);  // 06032F8C mov.w 0x06033082,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06032F8E mov.l @(r0,r14),r0
    c.r[1] = ld32(0x06033098u);  // 06032F90 mov.l 0x06033098,r1
    c.t = c.r[0] == c.r[1];  // 06032F92 cmp/eq r1,r0
    if (c.t) { goto L_06032F9A; }  // 06032F94 bt 0x06032F9A
    goto L_0603319C;  // 06032F96 bra 0x0603319C ; nop
L_06032F9A:
    c.r[1] = ld32(0x0603309Cu);  // 06032F9A mov.l 0x0603309C,r1
    c.r[1] = ld32(c.r[1]);  // 06032F9C mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06033088u);  // 06032F9E mov.w 0x06033088,r0
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06032FA0 mov.b @(r0,r1),r7
    c.r[9] = (uint32_t)(int16_t)ld16(0x06033084u);  // 06032FA2 mov.w 0x06033084,r9
    c.r[4] = c.r[7] & 0xFFu;  // 06032FA4 extu.b r7,r4
    c.t = c.r[4] == c.r[9];  // 06032FA6 cmp/eq r9,r4
    { const bool k = !c.t; c.r[0] = 0xFFFFFFFFu; if (k) { goto L_06032FB0; } }  // 06032FA8 bf/s 0x06032FB0 ; mov #-1,r0
    goto L_0603331E;  // 06032FAC bra 0x0603331E ; nop
L_06032FB0:
    c.r[1] = ld32(0x060330A0u);  // 06032FB0 mov.l 0x060330A0,r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x0603308Au);  // 06032FB2 mov.w 0x0603308A,r12
    c.r[12] += c.r[14];  // 06032FB4 add r14,r12
    c.r[5] = ld32(0x06033094u);  // 06032FB6 mov.l 0x06033094,r5
    c.r[6] = c.r[4];  // 06032FB8 mov r4,r6
    c.r[3] = ld32(c.r[1]);  // 06032FBA mov.l @r1,r3
    c.r[6] += c.r[6];  // 06032FBC add r6,r6
    c.r[1] = 0x1Eu;  // 06032FBE mov #30,r1
    c.macl = c.r[8] * c.r[1];  // 06032FC0 mul.l r1,r8
    c.r[6] += c.r[4];  // 06032FC2 add r4,r6
    c.r[13] = (uint32_t)(int16_t)ld16(0x0603308Cu);  // 06032FC4 mov.w 0x0603308C,r13
    c.r[2] = c.macl;  // 06032FC6 sts macl,r2
    c.r[2] += c.r[3];  // 06032FC8 add r3,r2
    c.r[2] += 15;  // 06032FCA add #15,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06032FCC mov.b @r2,r1
    c.r[0] = 0x1u;  // 06032FCE mov #1,r0
    c.r[1] = c.r[1] & 0xFFu;  // 06032FD0 extu.b r1,r1
    st32(c.r[12], c.r[1]);  // 06032FD2 mov.l r1,@r12
    st8(c.r[2], c.r[7]);  // 06032FD4 mov.b r7,@r2
    c.r[2] = c.r[11];  // 06032FD6 mov r11,r2
    c.r[2] <<= 2;  // 06032FD8 shll2 r2
    c.r[2] <<= 2;  // 06032FDA shll2 r2
    c.r[1] = ld32(c.r[5]);  // 06032FDC mov.l @r5,r1
    c.r[7] = ld32(0x060330A4u);  // 06032FDE mov.l 0x060330A4,r7
    c.r[2] += c.r[1];  // 06032FE0 add r1,r2
    c.r[1] = ld32(c.r[7]);  // 06032FE2 mov.l @r7,r1
    c.r[6] <<= 2;  // 06032FE4 shll2 r6
    c.r[1] += c.r[6];  // 06032FE6 add r6,r1
    c.r[1] += 3;  // 06032FE8 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06032FEA mov.b @r1,r1
    c.r[12] = 0x7Fu;  // 06032FEC mov #127,r12
    c.r[4] = c.r[1] & 0xFFu;  // 06032FEE extu.b r1,r4
    c.r[4] >>= 2;  // 06032FF0 shlr2 r4
    c.r[4] >>= 2;  // 06032FF2 shlr2 r4
    c.r[4] >>= 2;  // 06032FF4 shlr2 r4
    c.r[3] = c.r[4];  // 06032FF6 mov r4,r3
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 06032FF8 shlr r3
    c.r[1] = c.r[2];  // 06032FFA mov r2,r1
    c.r[1] += 3;  // 06032FFC add #3,r1
    c.r[4] &= c.r[0];  // 06032FFE and r0,r4
    c.r[2] += 4;  // 06033000 add #4,r2
    c.r[4] <<= 2;  // 06033002 shll2 r4
    c.r[4] <<= 2;  // 06033004 shll2 r4
    c.r[4] += c.r[4];  // 06033006 add r4,r4
    c.r[4] <<= 2;  // 06033008 shll2 r4
    c.r[0] = (uint32_t)(int16_t)ld16(0x0603308Au);  // 0603300A mov.w 0x0603308A,r0
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603300C mov.b @r1,r8
    c.r[0] += c.r[14];  // 0603300E add r14,r0
    c.r[8] &= c.r[13];  // 06033010 and r13,r8
    c.r[8] |= c.r[3];  // 06033012 or r3,r8
    st8(c.r[1], c.r[8]);  // 06033014 mov.b r8,@r1
    c.r[13] = (uint32_t)(int16_t)ld16(0x0603308Au);  // 06033016 mov.w 0x0603308A,r13
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06033018 mov.b @r2,r1
    c.r[13] += c.r[14];  // 0603301A add r14,r13
    c.r[1] &= c.r[12];  // 0603301C and r12,r1
    c.r[1] |= c.r[4];  // 0603301E or r4,r1
    st8(c.r[2], c.r[1]);  // 06033020 mov.b r1,@r2
    c.r[1] = ld32(c.r[7]);  // 06033022 mov.l @r7,r1
    c.r[8] = c.r[9];  // 06033024 mov r9,r8
    c.r[3] = ld32(c.r[13]);  // 06033026 mov.l @r13,r3
    c.r[2] = c.r[6];  // 06033028 mov r6,r2
    c.r[0] = ld32(c.r[0]);  // 0603302A mov.l @r0,r0
    c.r[2] += c.r[1];  // 0603302C add r1,r2
    c.r[3] += c.r[3];  // 0603302E add r3,r3
    c.r[3] += c.r[0];  // 06033030 add r0,r3
    c.r[3] <<= 2;  // 06033032 shll2 r3
    c.r[1] += c.r[3];  // 06033034 add r3,r1
    c.r[1] += 2;  // 06033036 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06033038 mov.b @r1,r1
    c.r[2] += 2;  // 0603303A add #2,r2
    st8(c.r[2], c.r[1]);  // 0603303C mov.b r1,@r2
    c.r[1] = ld32(c.r[7]);  // 0603303E mov.l @r7,r1
    c.r[4] = 0x49u;  // 06033040 mov #73,r4
    c.r[6] += c.r[1];  // 06033042 add r1,r6
    c.r[6] += 6;  // 06033044 add #6,r6
    c.r[3] += c.r[1];  // 06033046 add r1,r3
    c.r[3] += 6;  // 06033048 add #6,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0603304A mov.w @r3,r1
    c.r[7] = 0x0u;  // 0603304C mov #0,r7
    st16(c.r[6], c.r[1]);  // 0603304E mov.w r1,@r6
    c.r[5] = ld32(c.r[5]);  // 06033050 mov.l @r5,r5
    c.r[3] = 0x0u;  // 06033052 mov #0,r3
    c.r[6] = c.r[5];  // 06033054 mov r5,r6
    c.r[0] = c.r[3];  // 06033056 mov r3,r0
L_06033058:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 06033058 mov.b @(r0,r5),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0603305A extu.b r1,r1
    c.t = c.r[1] == c.r[8];  // 0603305C cmp/eq r8,r1
    { const bool k = c.t; c.r[2] = c.r[6]; if (k) { goto L_06033074; } }  // 0603305E bt/s 0x06033074 ; mov r6,r2
    c.r[1] = c.r[2];  // 06033062 mov r2,r1
    c.r[1] += 3;  // 06033064 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06033066 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06033068 mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0603306A shlr r0
    c.r[0] &= 0x3u;  // 0603306C and #3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603306E tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[11]; if (k) { goto L_06033144; } }  // 06033070 bt/s 0x06033144 ; mov r11,r1
L_06033074:
    c.r[6] = c.r[2];  // 06033074 mov r2,r6
    c.r[6] += 16;  // 06033076 add #16,r6
    c.r[3] += 16;  // 06033078 add #16,r3
    c.r[7] += 1;  // 0603307A add #1,r7
    c.t = (int32_t)c.r[7] > (int32_t)c.r[4]; goto L_060330A8;  // 0603307C bra 0x060330A8 ; cmp/gt r4,r7
L_060330A8:
    { const bool k = !c.t; c.r[0] = c.r[3]; if (k) { SH2_POLL(c); goto L_06033058; } }  // 060330A8 bf/s 0x06033058 ; mov r3,r0
L_060330AC:
    c.r[0] = c.r[7];  // 060330AC mov r7,r0
    c.t = c.r[0] == 0x4Au;  // 060330AE cmp/eq #74,r0
    if (!c.t) { goto L_060330D0; }  // 060330B0 bf 0x060330D0
    c.r[1] = ld32(0x0603317Cu);  // 060330B2 mov.l 0x0603317C,r1
    c.r[2] = ld32(c.r[1]);  // 060330B4 mov.l @r1,r2
    c.r[1] = c.r[11];  // 060330B6 mov r11,r1
    c.r[1] <<= 2;  // 060330B8 shll2 r1
    c.r[1] <<= 2;  // 060330BA shll2 r1
    c.r[1] += c.r[2];  // 060330BC add r2,r1
    c.r[2] = c.r[1];  // 060330BE mov r1,r2
    c.r[2] += 3;  // 060330C0 add #3,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060330C2 mov.b @r2,r0
    c.r[1] += 4;  // 060330C4 add #4,r1
    c.r[0] |= 0x1u;  // 060330C6 or #1,r0
    st8(c.r[2], c.r[0]);  // 060330C8 mov.b r0,@r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060330CA mov.b @r1,r0
    c.r[0] &= 0x7Fu;  // 060330CC and #127,r0
    st8(c.r[1], c.r[0]);  // 060330CE mov.b r0,@r1
L_060330D0:
    c.r[9] = ld32(0x0603317Cu);  // 060330D0 mov.l 0x0603317C,r9
    c.r[8] = c.r[11];  // 060330D2 mov r11,r8
    c.r[8] <<= 2;  // 060330D4 shll2 r8
    c.r[8] <<= 2;  // 060330D6 shll2 r8
    c.r[1] = 0x0u;  // 060330D8 mov #0,r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x06033174u);  // 060330DA mov.w 0x06033174,r12
    c.r[2] = ld32(c.r[9]);  // 060330DC mov.l @r9,r2
    c.r[12] += c.r[14];  // 060330DE add r14,r12
    c.r[2] += c.r[8];  // 060330E0 add r8,r2
    st32(c.r[2] + 12, c.r[1]);  // 060330E2 mov.l r1,@(12,r2)
    c.r[1] = ld32(0x06033180u);  // 060330E4 mov.l 0x06033180,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060330EAu; c.r[4] = ld32(c.r[12]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060330EAu) return; }  // 060330E6 jsr @r1 ; mov.l @r12,r4
    c.r[13] = ld32(0x06033184u);  // 060330EA mov.l 0x06033184,r13
    { const uint32_t x = c.r[13]; c.pr = 0x060330F0u; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060330F0u) return; }  // 060330EC jsr @r13 ; mov r11,r4
    c.r[2] = c.r[0];  // 060330F0 mov r0,r2
    c.r[3] = 0x1u;  // 060330F2 mov #1,r3
    c.r[3] &= c.r[2];  // 060330F4 and r2,r3
    c.r[1] = ld32(c.r[9]);  // 060330F6 mov.l @r9,r1
    c.r[3] <<= 2;  // 060330F8 shll2 r3
    c.r[3] += c.r[3];  // 060330FA add r3,r3
    c.r[3] <<= 2;  // 060330FC shll2 r3
    c.r[1] += c.r[8];  // 060330FE add r8,r1
    c.r[1] += 7;  // 06033100 add #7,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06033102 mov.b @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06033176u);  // 06033104 mov.w 0x06033176,r0
    c.r[2] &= c.r[0];  // 06033106 and r0,r2
    c.r[2] |= c.r[3];  // 06033108 or r3,r2
    st8(c.r[1], c.r[2]);  // 0603310A mov.b r2,@r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06033178u);  // 0603310C mov.w 0x06033178,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 0603310E mov.l @(r0,r14),r0
    c.r[1] = ld32(0x06033188u);  // 06033110 mov.l 0x06033188,r1
    c.t = c.r[0] == c.r[1];  // 06033112 cmp/eq r1,r0
    if (!c.t) { goto L_06033162; }  // 06033114 bf 0x06033162
    c.r[1] = ld32(0x0603318Cu);  // 06033116 mov.l 0x0603318C,r1
    c.r[1] = ld32(c.r[1]);  // 06033118 mov.l @r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0603317Au);  // 0603311A mov.w 0x0603317A,r2
    c.r[0] = c.r[1];  // 0603311C mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0603311E mov.b @(r0,r2),r1
    c.r[6] = ld32(0x06033190u);  // 06033120 mov.l 0x06033190,r6
    c.r[7] = c.r[1] & 0xFFu;  // 06033122 extu.b r1,r7
    c.r[1] = ld32(0x06033194u);  // 06033124 mov.l 0x06033194,r1
    c.r[2] = c.r[7];  // 06033126 mov r7,r2
    c.r[2] += c.r[2];  // 06033128 add r2,r2
    c.r[2] += c.r[7];  // 0603312A add r7,r2
    c.r[3] = ld32(c.r[1]);  // 0603312C mov.l @r1,r3
    c.r[2] <<= 2;  // 0603312E shll2 r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[6]);  // 06033130 mov.w @r6,r1
    c.r[0] = c.r[2];  // 06033132 mov r2,r0
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 06033134 mov.w @(r0,r3),r3
    c.r[1] = c.r[1] & 0xFFFFu;  // 06033136 extu.w r1,r1
    c.r[2] = c.r[3] & 0xFFFFu;  // 06033138 extu.w r3,r2
    c.t = c.r[1] == c.r[2];  // 0603313A cmp/eq r2,r1
    if (!c.t) { goto L_0603315E; }  // 0603313C bf 0x0603315E
    st16(c.r[6], c.r[3]);  // 0603313E mov.w r3,@r6
    goto L_06033162;  // 06033140 bra 0x06033162 ; nop
L_06033144:
    c.r[1] <<= 2;  // 06033144 shll2 r1
    c.r[1] <<= 2;  // 06033146 shll2 r1
    c.r[1] += c.r[5];  // 06033148 add r5,r1
    c.r[6] += 4;  // 0603314A add #4,r6
    c.r[1] += 4;  // 0603314C add #4,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0603314E mov.b @r6,r0
    c.r[2] = 0x1Eu;  // 06033150 mov #30,r2
    c.r[2] &= c.r[0];  // 06033152 and r0,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06033154 mov.b @r1,r0
    c.r[0] &= 0xE1u;  // 06033156 and #225,r0
    c.r[0] |= c.r[2];  // 06033158 or r2,r0
    st8(c.r[1], c.r[0]); SH2_POLL(c); goto L_060330AC;  // 0603315A bra 0x060330AC ; mov.b r0,@r1
L_0603315E:
    c.r[6] += 2;  // 0603315E add #2,r6
    st16(c.r[6], c.r[3]);  // 06033160 mov.w r3,@r6
L_06033162:
    c.r[1] = ld32(0x0603318Cu);  // 06033162 mov.l 0x0603318C,r1
    c.r[2] = ld32(c.r[1]);  // 06033164 mov.l @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0603317Au);  // 06033166 mov.w 0x0603317A,r0
    c.r[1] = 0xFFFFFFFFu;  // 06033168 mov #-1,r1
    st8(c.r[0] + c.r[2], c.r[1]);  // 0603316A mov.b r1,@(r0,r2)
    c.r[1] = ld32(0x06033198u);  // 0603316C mov.l 0x06033198,r1
    st8(c.r[1], c.r[11]);  // 0603316E mov.b r11,@r1
    c.r[0] = 0x0u; goto L_0603331E;  // 06033170 bra 0x0603331E ; mov #0,r0
L_0603319C:
    c.r[12] = ld32(0x06033350u);  // 0603319C mov.l 0x06033350,r12
    c.r[0] = (uint32_t)(int16_t)ld16(0x06033336u);  // 0603319E mov.w 0x06033336,r0
    c.r[13] = (uint32_t)(int16_t)ld16(0x06033338u);  // 060331A0 mov.w 0x06033338,r13
    c.r[1] = ld32(c.r[12]);  // 060331A2 mov.l @r12,r1
    c.r[13] += c.r[14];  // 060331A4 add r14,r13
    st32(c.r[13], c.r[0]);  // 060331A6 mov.l r0,@r13
    c.r[12] = (uint32_t)(int16_t)ld16(0x06033338u);  // 060331A8 mov.w 0x06033338,r12
    c.r[12] += c.r[14];  // 060331AA add r14,r12
    c.r[0] = ld32(c.r[12]);  // 060331AC mov.l @r12,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060331AE mov.b @(r0,r1),r1
    c.r[13] = 0xFFFFFFFFu;  // 060331B0 mov #-1,r13
    c.r[9] = c.r[1] & 0xFFu;  // 060331B2 extu.b r1,r9
    c.r[1] = c.r[13] & 0xFFu;  // 060331B4 extu.b r13,r1
    c.t = c.r[9] == c.r[1];  // 060331B6 cmp/eq r1,r9
    { const bool k = c.t; c.r[1] = 0x1Eu; if (k) { goto L_060331C0; } }  // 060331B8 bt/s 0x060331C0 ; mov #30,r1
    goto L_0603331C;  // 060331BC bra 0x0603331C ; nop
L_060331C0:
    c.r[0] = ld32(0x06033354u);  // 060331C0 mov.l 0x06033354,r0
    c.r[12] = (uint32_t)(int16_t)ld16(0x0603333Au);  // 060331C2 mov.w 0x0603333A,r12
    c.r[12] += c.r[14];  // 060331C4 add r14,r12
    c.r[6] = 0x0u;  // 060331C6 mov #0,r6
    c.r[2] = ld32(c.r[0]);  // 060331C8 mov.l @r0,r2
    c.macl = c.r[8] * c.r[1];  // 060331CA mul.l r1,r8
    c.r[0] = (uint32_t)(int16_t)ld16(0x0603333Au);  // 060331CC mov.w 0x0603333A,r0
    c.r[0] += c.r[14];  // 060331CE add r14,r0
    c.r[13] = c.macl;  // 060331D0 sts macl,r13
    st32(c.r[12], c.r[13]);  // 060331D2 mov.l r13,@r12
    c.r[12] = (uint32_t)(int16_t)ld16(0x0603333Cu);  // 060331D4 mov.w 0x0603333C,r12
    c.r[12] += c.r[14];  // 060331D6 add r14,r12
    c.r[0] = ld32(c.r[0]);  // 060331D8 mov.l @r0,r0
    c.r[13] = ld32(0x06033358u);  // 060331DA mov.l 0x06033358,r13
    c.r[2] += c.r[0];  // 060331DC add r0,r2
    c.r[2] += 15;  // 060331DE add #15,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0603333Cu);  // 060331E0 mov.w 0x0603333C,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060331E2 mov.b @r2,r1
    c.r[0] += c.r[14];  // 060331E4 add r14,r0
    c.r[1] = c.r[1] & 0xFFu;  // 060331E6 extu.b r1,r1
    st32(c.r[12], c.r[1]);  // 060331E8 mov.l r1,@r12
    c.r[1] = ld32(c.r[13]);  // 060331EA mov.l @r13,r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x0603333Cu);  // 060331EC mov.w 0x0603333C,r12
    c.r[2] = ld32(c.r[0]);  // 060331EE mov.l @r0,r2
    c.r[12] += c.r[14];  // 060331F0 add r14,r12
    c.r[12] = ld32(c.r[12]);  // 060331F2 mov.l @r12,r12
    c.r[2] += c.r[2];  // 060331F4 add r2,r2
    c.r[2] += c.r[12];  // 060331F6 add r12,r2
    c.r[2] <<= 2;  // 060331F8 shll2 r2
    c.r[2] += c.r[1];  // 060331FA add r1,r2
    c.r[1] = c.r[2];  // 060331FC mov r2,r1
    c.r[1] += 2;  // 060331FE add #2,r1
    c.r[2] += 7;  // 06033200 add #7,r2
    c.r[13] = (uint32_t)(int16_t)ld16(0x0603333Eu);  // 06033202 mov.w 0x0603333E,r13
    c.r[13] += c.r[14];  // 06033204 add r14,r13
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06033206 mov.b @r1,r1
    c.r[0] = ld32(0x0603335Cu);  // 06033208 mov.l 0x0603335C,r0
    c.r[4] = ld32(c.r[13]);  // 0603320A mov.l @r13,r4
    c.r[8] = c.r[1] & 0xFFu;  // 0603320C extu.b r1,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0603320E mov.b @r2,r1
    c.r[5] = c.r[8];  // 06033210 mov r8,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06033216u; c.r[10] = c.r[1] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06033216u) return; }  // 06033212 jsr @r0 ; extu.b r1,r10
    c.r[1] = c.r[0];  // 06033216 mov r0,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06033218 extu.b r1,r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x06033340u);  // 0603321A mov.w 0x06033340,r12
    c.r[12] += c.r[14];  // 0603321C add r14,r12
    st32(c.r[12], c.r[1]);  // 0603321E mov.l r1,@r12
    c.r[0] = (uint32_t)(int16_t)ld16(0x06033340u);  // 06033220 mov.w 0x06033340,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06033222 mov.l @(r0,r14),r0
    c.t = c.r[0] == c.r[9];  // 06033224 cmp/eq r9,r0
    { const bool k = c.t; c.r[0] = 0xFFFFFFFFu; if (k) { goto L_0603331E; } }  // 06033226 bt/s 0x0603331E ; mov #-1,r0
    c.r[12] = ld32(0x06033358u);  // 0603322A mov.l 0x06033358,r12
    c.r[13] = (uint32_t)(int16_t)ld16(0x06033340u);  // 0603322C mov.w 0x06033340,r13
    c.r[13] += c.r[14];  // 0603322E add r14,r13
    c.r[0] = (uint32_t)(int16_t)ld16(0x06033340u);  // 06033230 mov.w 0x06033340,r0
    c.r[1] = ld32(c.r[12]);  // 06033232 mov.l @r12,r1
    c.r[0] += c.r[14];  // 06033234 add r14,r0
    c.r[9] = ld32(c.r[13]);  // 06033236 mov.l @r13,r9
    c.r[3] = c.r[11];  // 06033238 mov r11,r3
    c.r[0] = ld32(c.r[0]);  // 0603323A mov.l @r0,r0
    c.r[9] += c.r[9];  // 0603323C add r9,r9
    c.r[9] += c.r[0];  // 0603323E add r0,r9
    c.r[9] <<= 2;  // 06033240 shll2 r9
    c.r[1] += c.r[9];  // 06033242 add r9,r1
    c.r[1] += 2;  // 06033244 add #2,r1
    st8(c.r[1], c.r[8]);  // 06033246 mov.b r8,@r1
    c.r[3] <<= 2;  // 06033248 shll2 r3
    c.r[3] <<= 2;  // 0603324A shll2 r3
    c.r[13] = 0xEu;  // 0603324C mov #14,r13
    c.r[0] = ld32(0x06033358u);  // 0603324E mov.l 0x06033358,r0
    c.r[2] = ld32(c.r[12]);  // 06033250 mov.l @r12,r2
    c.r[8] = ld32(0x06033360u);  // 06033252 mov.l 0x06033360,r8
    c.r[2] += c.r[9];  // 06033254 add r9,r2
    c.r[1] = c.r[2];  // 06033256 mov r2,r1
    c.r[1] += 6;  // 06033258 add #6,r1
    st16(c.r[1], c.r[10]);  // 0603325A mov.w r10,@r1
    c.r[2] += 9;  // 0603325C add #9,r2
    c.r[1] = 0xFFFFFF96u;  // 0603325E mov #-106,r1
    st8(c.r[2], c.r[1]);  // 06033260 mov.b r1,@r2
    c.r[10] = ld32(0x06033364u);  // 06033262 mov.l 0x06033364,r10
    c.r[2] = ld32(c.r[10]);  // 06033264 mov.l @r10,r2
    c.r[1] = ld32(0x06033368u);  // 06033266 mov.l 0x06033368,r1
    c.r[1] = ld32(c.r[1]);  // 06033268 mov.l @r1,r1
    c.r[2] += c.r[3];  // 0603326A add r3,r2
    st32(c.r[2] + 12, c.r[1]);  // 0603326C mov.l r1,@(12,r2)
    c.r[2] += 4;  // 0603326E add #4,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06033270 mov.b @r2,r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x06033342u);  // 06033272 mov.w 0x06033342,r12
    c.r[1] &= c.r[12];  // 06033274 and r12,r1
    c.r[1] |= c.r[13];  // 06033276 or r13,r1
    st8(c.r[2], c.r[1]);  // 06033278 mov.b r1,@r2
    c.r[12] = 0x3Fu;  // 0603327A mov #63,r12
    c.r[2] = ld32(c.r[10]);  // 0603327C mov.l @r10,r2
    c.r[13] = 0x40u;  // 0603327E mov #64,r13
    c.r[1] = ld32(c.r[0]);  // 06033280 mov.l @r0,r1
    c.r[2] += c.r[3];  // 06033282 add r3,r2
    c.r[1] += c.r[9];  // 06033284 add r9,r1
    c.r[1] += 3;  // 06033286 add #3,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06033288 mov.b @r1,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x06033344u);  // 0603328A mov.w 0x06033344,r0
    c.r[3] &= c.r[12];  // 0603328C and r12,r3
    c.r[3] |= c.r[13];  // 0603328E or r13,r3
    st8(c.r[1], c.r[3]);  // 06033290 mov.b r3,@r1
    c.r[1] = c.r[2];  // 06033292 mov r2,r1
    c.r[1] += 3;  // 06033294 add #3,r1
    c.r[2] += 4;  // 06033296 add #4,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06033298 mov.b @r1,r3
    c.r[12] = (uint32_t)(int16_t)ld16(0x06033346u);  // 0603329A mov.w 0x06033346,r12
    c.r[3] &= c.r[0];  // 0603329C and r0,r3
    st8(c.r[1], c.r[3]);  // 0603329E mov.b r3,@r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060332A0 mov.b @r2,r1
    c.r[13] = (uint32_t)(int16_t)ld16(0x06033340u);  // 060332A2 mov.w 0x06033340,r13
    c.r[1] |= c.r[12];  // 060332A4 or r12,r1
    st8(c.r[2], c.r[1]);  // 060332A6 mov.b r1,@r2
    c.r[4] = ld32(c.r[8]);  // 060332A8 mov.l @r8,r4
    c.r[13] += c.r[14];  // 060332AA add r14,r13
    c.r[1] = ld32(0x0603336Cu);  // 060332AC mov.l 0x0603336C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060332B2u; c.r[5] = ld32(c.r[13]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060332B2u) return; }  // 060332AE jsr @r1 ; mov.l @r13,r5
    c.r[0] = ld32(0x06033358u);  // 060332B2 mov.l 0x06033358,r0
    c.r[1] = ld32(c.r[0]);  // 060332B4 mov.l @r0,r1
    c.r[12] = ld32(0x06033354u);  // 060332B6 mov.l 0x06033354,r12
    c.r[9] += c.r[1];  // 060332B8 add r1,r9
    c.r[1] = ld32(c.r[8]);  // 060332BA mov.l @r8,r1
    c.r[13] = (uint32_t)(int16_t)ld16(0x0603333Au);  // 060332BC mov.w 0x0603333A,r13
    c.r[1] += 12;  // 060332BE add #12,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060332C0 mov.w @r1,r1
    c.r[9] += 10;  // 060332C2 add #10,r9
    st16(c.r[9], c.r[1]);  // 060332C4 mov.w r1,@r9
    c.r[1] = ld32(c.r[12]);  // 060332C6 mov.l @r12,r1
    c.r[13] += c.r[14];  // 060332C8 add r14,r13
    c.r[0] = ld32(c.r[13]);  // 060332CA mov.l @r13,r0
    c.r[0] += c.r[1];  // 060332CC add r1,r0
    st32(c.r[13], c.r[0]);  // 060332CE mov.l r0,@r13
    c.r[12] = (uint32_t)(int16_t)ld16(0x0603333Au);  // 060332D0 mov.w 0x0603333A,r12
    c.r[12] += c.r[14];  // 060332D2 add r14,r12
    c.r[0] = (uint32_t)(int16_t)ld16(0x06033348u);  // 060332D4 mov.w 0x06033348,r0
    c.r[13] = ld32(c.r[12]);  // 060332D6 mov.l @r12,r13
    c.r[0] += c.r[14];  // 060332D8 add r14,r0
    c.r[13] += 15;  // 060332DA add #15,r13
    st32(c.r[12], c.r[13]);  // 060332DC mov.l r13,@r12
    c.r[13] = (uint32_t)(int8_t)ld8(c.r[0]);  // 060332DE mov.b @r0,r13
    c.r[6] = 0xFFFFFFFFu;  // 060332E0 mov #-1,r6
    c.r[0] = (uint32_t)(int16_t)ld16(0x0603333Au);  // 060332E2 mov.w 0x0603333A,r0
    c.r[12] = ld32(c.r[0] + c.r[14]);  // 060332E4 mov.l @(r0,r14),r12
    c.r[3] = 0x0u;  // 060332E6 mov #0,r3
    st8(c.r[12], c.r[13]);  // 060332E8 mov.b r13,@r12
    c.r[0] = ld32(0x06033350u);  // 060332EA mov.l 0x06033350,r0
    c.r[1] = ld32(c.r[0]);  // 060332EC mov.l @r0,r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x06033338u);  // 060332EE mov.w 0x06033338,r12
    c.r[0] = (uint32_t)(int16_t)ld16(0x0603334Au);  // 060332F0 mov.w 0x0603334A,r0
    c.r[13] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 060332F2 mov.b @(r0,r14),r13
    c.r[12] += c.r[14];  // 060332F4 add r14,r12
    c.r[0] = ld32(c.r[12]);  // 060332F6 mov.l @r12,r0
    c.r[7] = (uint32_t)(int16_t)ld16(0x0603334Cu);  // 060332F8 mov.w 0x0603334C,r7
    st8(c.r[0] + c.r[1], c.r[13]);  // 060332FA mov.b r13,@(r0,r1)
    c.r[1] = ld32(0x06033370u);  // 060332FC mov.l 0x06033370,r1
    st8(c.r[1], c.r[11]);  // 060332FE mov.b r11,@r1
L_06033300:
    c.r[2] = ld32(c.r[10]);  // 06033300 mov.l @r10,r2
    c.r[2] += c.r[3];  // 06033302 add r3,r2
    c.r[2] += 8;  // 06033304 add #8,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06033306 mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06033308 extu.b r1,r1
    c.t = c.r[1] == c.r[11];  // 0603330A cmp/eq r11,r1
    if (!c.t) { goto L_06033310; }  // 0603330C bf 0x06033310
    st8(c.r[2], c.r[6]);  // 0603330E mov.b r6,@r2
L_06033310:
    c.r[3] += 16;  // 06033310 add #16,r3
    c.t = (int32_t)c.r[3] > (int32_t)c.r[7];  // 06033312 cmp/gt r7,r3
    { const bool k = !c.t; c.r[0] = 0x0u; if (k) { SH2_POLL(c); goto L_06033300; } }  // 06033314 bf/s 0x06033300 ; mov #0,r0
    goto L_0603331E;  // 06033318 bra 0x0603331E ; nop
L_0603331C:
    c.r[0] = 0xFFFFFFFFu;  // 0603331C mov #-1,r0
L_0603331E:
    c.r[3] = (uint32_t)(int16_t)ld16(0x0603334Eu);  // 0603331E mov.w 0x0603334E,r3
    c.r[14] += c.r[3];  // 06033320 add r3,r14
    c.r[15] = c.r[14];  // 06033322 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06033324 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06033326 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06033328 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0603332A mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0603332C mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0603332E mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06033330 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06033332 rts ; mov.l @r15+,r8
}

void f_06033374(SH2Context& c) {
    ran[726] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06033374 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06033376 sts.l pr,@-r15
    c.r[1] = ld32(0x06033394u);  // 06033378 mov.l 0x06033394,r1
    c.r[1] = ld32(c.r[1]);  // 0603337A mov.l @r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603337C mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0603337E extu.b r1,r0
    c.r[0] <<= 2;  // 06033380 shll2 r0
    c.r[1] = ld32(0x06033398u);  // 06033382 mov.l 0x06033398,r1
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 06033384 mov.l @(r0,r1),r0
    { const uint32_t x = c.r[0]; c.pr = 0x0603338Au; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603338Au) return; }  // 06033386 jsr @r0 ; mov r15,r14
    c.r[15] = c.r[14];  // 0603338A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603338C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603338E mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[0] & 0xFFFFu; c.pc = x; return; }  // 06033390 rts ; extu.w r0,r0
}

void f_0603339C(SH2Context& c) {
    ran[727] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603339C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603339E sts.l pr,@-r15
    c.r[1] = ld32(0x060333C0u);  // 060333A0 mov.l 0x060333C0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060333A6u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060333A6u) return; }  // 060333A2 jsr @r1 ; mov r15,r14
    c.r[5] = (uint32_t)(int16_t)ld16(0x060333BAu);  // 060333A6 mov.w 0x060333BA,r5
    c.r[4] = ld32(0x060333C4u);  // 060333A8 mov.l 0x060333C4,r4
    c.r[1] = ld32(0x060333C8u);  // 060333AA mov.l 0x060333C8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060333B0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060333B0u) return; }  // 060333AC jsr @r1 ; nop
    c.r[15] = c.r[14];  // 060333B0 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060333B2 lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x060333BCu);  // 060333B4 mov.w 0x060333BC,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060333B6 rts ; mov.l @r15+,r14
}

void f_060333CC(SH2Context& c) {
    ran[728] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060333CC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060333CE mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060333D0 sts.l pr,@-r15
    c.r[1] = ld32(0x06033414u);  // 060333D2 mov.l 0x06033414,r1
    c.r[1] = ld32(c.r[1]);  // 060333D4 mov.l @r1,r1
    c.r[1] += 1;  // 060333D6 add #1,r1
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060333D8 mov.b @r1,r8
    c.r[14] = c.r[15];  // 060333DA mov r15,r14
    c.r[1] = ld32(0x06033418u);  // 060333DC mov.l 0x06033418,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060333E2u; c.r[8] = c.r[8] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060333E2u) return; }  // 060333DE jsr @r1 ; extu.b r8,r8
    c.r[6] = 0x1u;  // 060333E2 mov #1,r6
    c.r[6] &= c.r[8];  // 060333E4 and r8,r6
    c.t = c.r[8] & 1; c.r[8] >>= 1;  // 060333E6 shlr r8
    c.r[0] = ld32(0x0603341Cu);  // 060333E8 mov.l 0x0603341C,r0
    c.r[7] = 0x1u;  // 060333EA mov #1,r7
    c.r[5] = 0x0u;  // 060333EC mov #0,r5
    { const uint32_t x = c.r[0]; c.pr = 0x060333F2u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060333F2u) return; }  // 060333EE jsr @r0 ; mov r8,r4
    c.r[8] = ld32(0x06033420u);  // 060333F2 mov.l 0x06033420,r8
    c.t = (c.r[0] & c.r[0]) == 0;  // 060333F4 tst r0,r0
    { const bool k = !c.t; st32(c.r[8] + 20, c.r[0]); if (k) { goto L_06033400; } }  // 060333F6 bf/s 0x06033400 ; mov.l r0,@(20,r8)
    c.r[1] = ld32(0x06033424u);  // 060333FA mov.l 0x06033424,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06033400u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06033400u) return; }  // 060333FC jsr @r1 ; nop
L_06033400:
    c.r[1] = ld32(c.r[8] + 20);  // 06033400 mov.l @(20,r8),r1
    c.r[15] = c.r[14];  // 06033402 mov r14,r15
    c.r[1] = c.r[1] & 0xFFFFu;  // 06033404 extu.w r1,r1
    st32(c.r[8] + 20, c.r[1]);  // 06033406 mov.l r1,@(20,r8)
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06033408 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603340A mov.l @r15+,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x06033412u);  // 0603340C mov.w 0x06033412,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603340E rts ; mov.l @r15+,r8
}

void f_06033428(SH2Context& c) {
    ran[729] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06033428 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603342A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603342C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603342E sts.l pr,@-r15
    c.r[1] = ld32(0x06033474u);  // 06033430 mov.l 0x06033474,r1
    c.r[1] = ld32(c.r[1]);  // 06033432 mov.l @r1,r1
    c.r[14] = c.r[15];  // 06033434 mov r15,r14
    c.r[1] += 1;  // 06033436 add #1,r1
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06033438 mov.b @r1,r8
    c.r[9] = 0x7Fu;  // 0603343A mov #127,r9
    c.r[8] = c.r[8] & 0xFFu;  // 0603343C extu.b r8,r8
    c.r[1] = ld32(0x06033478u);  // 0603343E mov.l 0x06033478,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06033444u; c.r[9] &= c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06033444u) return; }  // 06033440 jsr @r1 ; and r8,r9
    c.r[8] >>= 2;  // 06033444 shlr2 r8
    c.r[8] >>= 2;  // 06033446 shlr2 r8
    c.t = c.r[8] & 1; c.r[8] >>= 1;  // 06033448 shlr r8
    c.r[8] >>= 2;  // 0603344A shlr2 r8
    c.r[0] = ld32(0x0603347Cu);  // 0603344C mov.l 0x0603347C,r0
    c.r[5] = c.r[8];  // 0603344E mov r8,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06033454u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06033454u) return; }  // 06033450 jsr @r0 ; mov r9,r4
    c.r[1] = ld32(0x06033480u);  // 06033454 mov.l 0x06033480,r1
    c.t = (c.r[0] & c.r[0]) == 0;  // 06033456 tst r0,r0
    { const bool k = !c.t; st32(c.r[1] + 20, c.r[0]); if (k) { goto L_06033462; } }  // 06033458 bf/s 0x06033462 ; mov.l r0,@(20,r1)
    c.r[1] = ld32(0x06033484u);  // 0603345C mov.l 0x06033484,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06033462u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06033462u) return; }  // 0603345E jsr @r1 ; nop
L_06033462:
    c.r[15] = c.r[14];  // 06033462 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06033464 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06033466 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06033468 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06033470u);  // 0603346A mov.w 0x06033470,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603346C rts ; mov.l @r15+,r8
}

void f_06033488(SH2Context& c) {
    ran[730] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06033488 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603348A sts.l pr,@-r15
    c.r[1] = ld32(0x060334BCu);  // 0603348C mov.l 0x060334BC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06033492u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06033492u) return; }  // 0603348E jsr @r1 ; mov r15,r14
    c.r[1] = ld32(0x060334C0u);  // 06033492 mov.l 0x060334C0,r1
    c.r[1] = ld32(c.r[1]);  // 06033494 mov.l @r1,r1
    c.r[0] = ld32(0x060334C4u);  // 06033496 mov.l 0x060334C4,r0
    c.r[1] += 1;  // 06033498 add #1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603349A mov.b @r1,r4
    c.r[5] = 0x0u;  // 0603349C mov #0,r5
    { const uint32_t x = c.r[0]; c.pr = 0x060334A2u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060334A2u) return; }  // 0603349E jsr @r0 ; extu.b r4,r4
    c.r[1] = ld32(0x060334C8u);  // 060334A2 mov.l 0x060334C8,r1
    c.t = (c.r[0] & c.r[0]) == 0;  // 060334A4 tst r0,r0
    { const bool k = !c.t; st32(c.r[1] + 20, c.r[0]); if (k) { goto L_060334B0; } }  // 060334A6 bf/s 0x060334B0 ; mov.l r0,@(20,r1)
    c.r[1] = ld32(0x060334CCu);  // 060334AA mov.l 0x060334CC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060334B0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060334B0u) return; }  // 060334AC jsr @r1 ; nop
L_060334B0:
    c.r[15] = c.r[14];  // 060334B0 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060334B2 lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x060334BAu);  // 060334B4 mov.w 0x060334BA,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060334B6 rts ; mov.l @r15+,r14
}

void f_060334D0(SH2Context& c) {
    ran[731] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060334D0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060334D2 sts.l pr,@-r15
    c.r[0] = ld32(0x06033520u);  // 060334D4 mov.l 0x06033520,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060334DAu; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060334DAu) return; }  // 060334D6 jsr @r0 ; mov r15,r14
    c.r[1] = ld32(0x06033524u);  // 060334DA mov.l 0x06033524,r1
    st32(c.r[1] + 20, c.r[0]);  // 060334DC mov.l r0,@(20,r1)
    c.r[7] = ld32(0x06033528u);  // 060334DE mov.l 0x06033528,r7
    c.r[2] = c.r[7];  // 060334E0 mov r7,r2
    c.r[2] += 108;  // 060334E2 add #108,r2
    c.r[3] = ld32(0x0603352Cu);  // 060334E4 mov.l 0x0603352C,r3
    c.r[1] = ld32(c.r[3]);  // 060334E6 mov.l @r3,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0603351Au);  // 060334E8 mov.w 0x0603351A,r0
    st32(c.r[2], c.r[1]);  // 060334EA mov.l r1,@r2
    c.r[2] = c.r[7];  // 060334EC mov r7,r2
    c.r[1] = ld32(c.r[3] + 4);  // 060334EE mov.l @(4,r3),r1
    c.r[2] += 120;  // 060334F0 add #120,r2
    st32(c.r[2], c.r[1]);  // 060334F2 mov.l r1,@r2
    c.r[2] = c.r[7];  // 060334F4 mov r7,r2
    c.r[1] = ld32(c.r[3] + 8);  // 060334F6 mov.l @(8,r3),r1
    c.r[2] += 116;  // 060334F8 add #116,r2
    st32(c.r[2], c.r[1]);  // 060334FA mov.l r1,@r2
    c.r[2] = c.r[7];  // 060334FC mov r7,r2
    c.r[1] = ld32(c.r[3] + 12);  // 060334FE mov.l @(12,r3),r1
    c.r[2] += 112;  // 06033500 add #112,r2
    st32(c.r[2], c.r[1]);  // 06033502 mov.l r1,@r2
    c.r[2] = c.r[7];  // 06033504 mov r7,r2
    c.r[1] = ld32(c.r[3] + 16);  // 06033506 mov.l @(16,r3),r1
    c.r[2] += 124;  // 06033508 add #124,r2
    st32(c.r[2], c.r[1]);  // 0603350A mov.l r1,@r2
    c.r[1] = ld32(c.r[3] + 20);  // 0603350C mov.l @(20,r3),r1
    c.r[15] = c.r[14];  // 0603350E mov r14,r15
    st32(c.r[0] + c.r[7], c.r[1]);  // 06033510 mov.l r1,@(r0,r7)
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06033512 lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x0603351Cu);  // 06033514 mov.w 0x0603351C,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06033516 rts ; mov.l @r15+,r14
}

void f_06033530(SH2Context& c) {
    ran[732] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06033530 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06033532 sts.l pr,@-r15
    c.r[1] = ld32(0x06033570u);  // 06033534 mov.l 0x06033570,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603353Au; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603353Au) return; }  // 06033536 jsr @r1 ; mov r15,r14
    c.r[1] = ld32(0x06033574u);  // 0603353A mov.l 0x06033574,r1
    c.r[1] = ld32(c.r[1]);  // 0603353C mov.l @r1,r1
    c.r[1] += 1;  // 0603353E add #1,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06033540 mov.b @r1,r0
    c.r[5] = c.r[0] & 0xFFu;  // 06033542 extu.b r0,r5
    c.r[5] >>= 2;  // 06033544 shlr2 r5
    c.r[5] >>= 2;  // 06033546 shlr2 r5
    c.t = c.r[5] & 1; c.r[5] >>= 1;  // 06033548 shlr r5
    c.r[5] >>= 2;  // 0603354A shlr2 r5
    c.r[1] = 0x7Fu;  // 0603354C mov #127,r1
    c.r[1] &= c.r[0];  // 0603354E and r0,r1
    c.r[0] = ld32(0x06033578u);  // 06033550 mov.l 0x06033578,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06033556u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06033556u) return; }  // 06033552 jsr @r0 ; mov r1,r4
    c.r[1] = ld32(0x0603357Cu);  // 06033556 mov.l 0x0603357C,r1
    c.t = (c.r[0] & c.r[0]) == 0;  // 06033558 tst r0,r0
    { const bool k = !c.t; st32(c.r[1] + 20, c.r[0]); if (k) { goto L_06033564; } }  // 0603355A bf/s 0x06033564 ; mov.l r0,@(20,r1)
    c.r[1] = ld32(0x06033580u);  // 0603355E mov.l 0x06033580,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06033564u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06033564u) return; }  // 06033560 jsr @r1 ; nop
L_06033564:
    c.r[15] = c.r[14];  // 06033564 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06033566 lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x0603356Eu);  // 06033568 mov.w 0x0603356E,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603356A rts ; mov.l @r15+,r14
}

void f_06033584(SH2Context& c) {
    ran[733] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06033584 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06033586 mov r15,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x0603358Eu);  // 06033588 mov.w 0x0603358E,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603358A rts ; mov.l @r15+,r14
}

void f_06033590(SH2Context& c) {
    ran[734] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06033590 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06033592 mov r15,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x0603359Au);  // 06033594 mov.w 0x0603359A,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06033596 rts ; mov.l @r15+,r14
}

void f_0603359C(SH2Context& c) {
    ran[735] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603359C mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0603359E mov r15,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x060335A6u);  // 060335A0 mov.w 0x060335A6,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060335A2 rts ; mov.l @r15+,r14
}

void f_060335A8(SH2Context& c) {
    ran[736] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060335A8 mov.l r14,@-r15
    c.r[1] = ld32(0x060335D8u);  // 060335AA mov.l 0x060335D8,r1
    c.r[1] = ld32(c.r[1]);  // 060335AC mov.l @r1,r1
    c.r[1] += 1;  // 060335AE add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060335B0 mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 060335B2 extu.b r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x060335D2u);  // 060335B4 mov.w 0x060335D2,r1
    c.t = c.r[2] == c.r[1];  // 060335B6 cmp/eq r1,r2
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_060335C2; } }  // 060335B8 bt/s 0x060335C2 ; mov r15,r14
    c.r[1] = ld32(0x060335DCu);  // 060335BC mov.l 0x060335DC,r1
    st32(c.r[1], c.r[2]); goto L_060335CA;  // 060335BE bra 0x060335CA ; mov.l r2,@r1
L_060335C2:
    c.r[2] = ld32(0x060335DCu);  // 060335C2 mov.l 0x060335DC,r2
    c.r[2] = ld32(c.r[2]);  // 060335C4 mov.l @r2,r2
    c.r[1] = ld32(0x060335E0u);  // 060335C6 mov.l 0x060335E0,r1
    st32(c.r[1] + 20, c.r[2]);  // 060335C8 mov.l r2,@(20,r1)
L_060335CA:
    c.r[15] = c.r[14];  // 060335CA mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x060335D4u);  // 060335CC mov.w 0x060335D4,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060335CE rts ; mov.l @r15+,r14
}

void f_060335E4(SH2Context& c) {
    ran[737] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060335E4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060335E6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060335E8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060335EA mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060335EC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060335EE sts.l pr,@-r15
    c.r[1] = ld32(0x06033648u);  // 060335F0 mov.l 0x06033648,r1
    c.r[1] = ld32(c.r[1]);  // 060335F2 mov.l @r1,r1
    c.r[14] = c.r[15];  // 060335F4 mov r15,r14
    c.r[1] += 1;  // 060335F6 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060335F8 mov.b @r1,r1
    c.r[8] = ld32(0x0603364Cu);  // 060335FA mov.l 0x0603364C,r8
    c.r[11] = ld32(c.r[8]);  // 060335FC mov.l @r8,r11
    c.r[0] = c.r[1] & 0xFFu;  // 060335FE extu.b r1,r0
    c.r[9] = c.r[0];  // 06033600 mov r0,r9
    c.r[0] &= 0x7Fu;  // 06033602 and #127,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06033604 tst r0,r0
    { const bool k = !c.t; c.r[10] = c.r[0]; if (k) { goto L_06033610; } }  // 06033606 bf/s 0x06033610 ; mov r0,r10
    c.r[1] = ld32(0x06033650u);  // 0603360A mov.l 0x06033650,r1
    c.r[1] = ld32(c.r[1]);  // 0603360C mov.l @r1,r1
    st32(c.r[8], c.r[1]);  // 0603360E mov.l r1,@r8
L_06033610:
    c.r[1] = ld32(0x06033654u);  // 06033610 mov.l 0x06033654,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06033616u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06033616u) return; }  // 06033612 jsr @r1 ; nop
    c.r[9] >>= 2;  // 06033616 shlr2 r9
    c.r[9] >>= 2;  // 06033618 shlr2 r9
    c.t = c.r[9] & 1; c.r[9] >>= 1;  // 0603361A shlr r9
    c.r[9] >>= 2;  // 0603361C shlr2 r9
    c.r[0] = ld32(0x06033658u);  // 0603361E mov.l 0x06033658,r0
    c.r[5] = c.r[9];  // 06033620 mov r9,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06033626u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06033626u) return; }  // 06033622 jsr @r0 ; mov r10,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 06033626 tst r0,r0
    if (!c.t) { goto L_06033630; }  // 06033628 bf 0x06033630
    c.r[1] = ld32(0x0603365Cu);  // 0603362A mov.l 0x0603365C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06033630u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06033630u) return; }  // 0603362C jsr @r1 ; nop
L_06033630:
    st32(c.r[8], c.r[11]);  // 06033630 mov.l r11,@r8
    c.r[15] = c.r[14];  // 06033632 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06033634 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06033636 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06033638 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0603363A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0603363C mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06033644u);  // 0603363E mov.w 0x06033644,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06033640 rts ; mov.l @r15+,r8
}

void f_06033660(SH2Context& c) {
    ran[738] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06033660 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06033662 mov r15,r14
    c.r[1] = ld32(0x06033688u);  // 06033664 mov.l 0x06033688,r1
    c.r[0] = ld32(c.r[1]);  // 06033666 mov.l @r1,r0
    c.r[2] = ld32(0x0603368Cu);  // 06033668 mov.l 0x0603368C,r2
    c.r[0] <<= 2;  // 0603366A shll2 r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 0603366C mov.w @(r0,r2),r1
    c.r[3] = ld32(0x06033690u);  // 0603366E mov.l 0x06033690,r3
    c.r[1] = c.r[1] & 0xFFFFu;  // 06033670 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06033672 tst r1,r1
    { const bool k = !c.t; c.r[1] = 0x0u; if (k) { goto L_0603367A; } }  // 06033674 bf/s 0x0603367A ; mov #0,r1
    c.r[1] = 0xFFFFFFFFu;  // 06033678 mov #-1,r1
L_0603367A:
    st32(c.r[3] + 20, c.r[1]);  // 0603367A mov.l r1,@(20,r3)
    c.r[15] = c.r[14];  // 0603367C mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x06033684u);  // 0603367E mov.w 0x06033684,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06033680 rts ; mov.l @r15+,r14
}

void f_06033694(SH2Context& c) {
    ran[739] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06033694 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06033696 sts.l pr,@-r15
    c.r[1] = ld32(0x060336ACu);  // 06033698 mov.l 0x060336AC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603369Eu; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603369Eu) return; }  // 0603369A jsr @r1 ; mov r15,r14
    c.r[15] = c.r[14];  // 0603369E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060336A0 lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x060336A8u);  // 060336A2 mov.w 0x060336A8,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060336A4 rts ; mov.l @r15+,r14
}

void f_060336B0(SH2Context& c) {
    ran[740] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060336B0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060336B2 sts.l pr,@-r15
    c.r[1] = ld32(0x060336C8u);  // 060336B4 mov.l 0x060336C8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060336BAu; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060336BAu) return; }  // 060336B6 jsr @r1 ; mov r15,r14
    c.r[15] = c.r[14];  // 060336BA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060336BC lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x060336C4u);  // 060336BE mov.w 0x060336C4,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060336C0 rts ; mov.l @r15+,r14
}

void f_060336CC(SH2Context& c) {
    ran[741] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060336CC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060336CE sts.l pr,@-r15
    c.r[1] = ld32(0x060336E4u);  // 060336D0 mov.l 0x060336E4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060336D6u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060336D6u) return; }  // 060336D2 jsr @r1 ; mov r15,r14
    c.r[15] = c.r[14];  // 060336D6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060336D8 lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x060336E0u);  // 060336DA mov.w 0x060336E0,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060336DC rts ; mov.l @r15+,r14
}

void f_060336E8(SH2Context& c) {
    ran[742] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060336E8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060336EA sts.l pr,@-r15
    c.r[1] = ld32(0x06033700u);  // 060336EC mov.l 0x06033700,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060336F2u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060336F2u) return; }  // 060336EE jsr @r1 ; mov r15,r14
    c.r[15] = c.r[14];  // 060336F2 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060336F4 lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x060336FCu);  // 060336F6 mov.w 0x060336FC,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060336F8 rts ; mov.l @r15+,r14
}

void f_06033704(SH2Context& c) {
    ran[743] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06033704 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06033706 sts.l pr,@-r15
    c.r[1] = ld32(0x0603372Cu);  // 06033708 mov.l 0x0603372C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603370Eu; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603370Eu) return; }  // 0603370A jsr @r1 ; mov r15,r14
    c.r[0] = ld32(0x06033730u);  // 0603370E mov.l 0x06033730,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06033714u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06033714u) return; }  // 06033710 jsr @r0 ; nop
    c.t = (int32_t)c.r[0] >= 0;  // 06033714 cmp/pz r0
    if (!c.t) { goto L_0603371E; }  // 06033716 bf 0x0603371E
    c.r[1] = ld32(0x06033734u);  // 06033718 mov.l 0x06033734,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603371Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603371Eu) return; }  // 0603371A jsr @r1 ; nop
L_0603371E:
    c.r[15] = c.r[14];  // 0603371E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06033720 lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x06033728u);  // 06033722 mov.w 0x06033728,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06033724 rts ; mov.l @r15+,r14
}

void f_06033738(SH2Context& c) {
    ran[744] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06033738 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603373A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603373C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603373E sts.l pr,@-r15
    c.r[1] = ld32(0x060337C0u);  // 06033740 mov.l 0x060337C0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06033746u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06033746u) return; }  // 06033742 jsr @r1 ; mov r15,r14
    c.r[9] = ld32(0x060337C4u);  // 06033746 mov.l 0x060337C4,r9
    c.r[1] = ld32(c.r[9]);  // 06033748 mov.l @r9,r1
    c.r[8] = (uint32_t)(int16_t)ld16(0x060337B6u);  // 0603374A mov.w 0x060337B6,r8
    c.r[0] = c.r[1];  // 0603374C mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0603374E mov.b @(r0,r8),r1
    c.r[1] >>= 2;  // 06033750 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06033752 shlr r1
    c.r[0] = 0x1u;  // 06033754 mov #1,r0
    c.r[1] &= c.r[0];  // 06033756 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06033758 tst r1,r1
    if (!c.t) { goto L_060337A8; }  // 0603375A bf 0x060337A8
    c.r[1] = ld32(0x060337C8u);  // 0603375C mov.l 0x060337C8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06033762u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06033762u) return; }  // 0603375E jsr @r1 ; nop
    c.r[3] = ld32(0x060337CCu);  // 06033762 mov.l 0x060337CC,r3
    c.r[1] = c.r[3];  // 06033764 mov r3,r1
    c.r[1] += 1;  // 06033766 add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06033768 mov.b @r1,r2
    c.r[7] = ld32(c.r[9]);  // 0603376A mov.l @r9,r7
    c.r[0] = (uint32_t)(int16_t)ld16(0x060337B8u);  // 0603376C mov.w 0x060337B8,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0603376E mov.b @(r0,r7),r1
    c.r[2] = c.r[2] & 0xFFu;  // 06033770 extu.b r2,r2
    c.r[0] = c.r[1];  // 06033772 mov r1,r0
    c.r[0] >>= 2;  // 06033774 shlr2 r0
    c.r[0] &= 0xFu;  // 06033776 and #15,r0
    c.t = c.r[2] == c.r[0];  // 06033778 cmp/eq r0,r2
    { const bool k = !c.t; c.r[3] += 2; if (k) { goto L_060337A8; } }  // 0603377A bf/s 0x060337A8 ; add #2,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0603377E mov.b @r3,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060337BAu);  // 06033780 mov.w 0x060337BA,r0
    c.r[0] = ld32(c.r[0] + c.r[7]);  // 06033782 mov.l @(r0,r7),r0
    c.r[1] = c.r[1] & 0xFFu;  // 06033784 extu.b r1,r1
    c.r[0] >>= 8;  // 06033786 shlr8 r0
    c.r[0] >>= 2;  // 06033788 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0603378A shlr r0
    c.r[0] >>= 2;  // 0603378C shlr2 r0
    c.r[0] &= 0x1Fu;  // 0603378E and #31,r0
    c.t = c.r[1] == c.r[0];  // 06033790 cmp/eq r0,r1
    if (!c.t) { goto L_060337A8; }  // 06033792 bf 0x060337A8
    c.r[1] = ld32(0x060337D0u);  // 06033794 mov.l 0x060337D0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603379Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603379Au) return; }  // 06033796 jsr @r1 ; nop
    c.r[1] = ld32(c.r[9]);  // 0603379A mov.l @r9,r1
    c.r[0] = c.r[1];  // 0603379C mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0603379E mov.b @(r0,r8),r2
    c.r[0] = 0x8u;  // 060337A0 mov #8,r0
    c.r[2] |= c.r[0];  // 060337A2 or r0,r2
    c.r[0] = c.r[1];  // 060337A4 mov r1,r0
    st8(c.r[0] + c.r[8], c.r[2]);  // 060337A6 mov.b r2,@(r0,r8)
L_060337A8:
    c.r[15] = c.r[14];  // 060337A8 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060337AA lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060337AC mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060337AE mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x060337BCu);  // 060337B0 mov.w 0x060337BC,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060337B2 rts ; mov.l @r15+,r8
}

void f_060337D4(SH2Context& c) {
    ran[745] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060337D4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060337D6 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060337D8 sts.l pr,@-r15
    c.r[1] = ld32(0x060338B8u);  // 060337DA mov.l 0x060338B8,r1
    c.r[1] = ld32(c.r[1]);  // 060337DC mov.l @r1,r1
    c.r[1] += 1;  // 060337DE add #1,r1
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060337E0 mov.b @r1,r8
    c.r[1] = ld32(0x060338BCu);  // 060337E2 mov.l 0x060338BC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060337E8u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060337E8u) return; }  // 060337E4 jsr @r1 ; mov r15,r14
    c.r[2] = ld32(0x060338C0u);  // 060337E8 mov.l 0x060338C0,r2
    c.r[1] = ld32(c.r[2]);  // 060337EA mov.l @r2,r1
    c.r[8] = c.r[8] & 0xFFu;  // 060337EC extu.b r8,r8
    c.t = c.r[1] == c.r[8];  // 060337EE cmp/eq r8,r1
    { const bool k = !c.t; c.r[0] = c.r[1]; if (k) { goto L_0603389E; } }  // 060337F0 bf/s 0x0603389E ; mov r1,r0
    c.r[0] += 1;  // 060337F4 add #1,r0
    c.t = c.r[0] == 0x6u;  // 060337F6 cmp/eq #6,r0
    { const bool k = !c.t; st32(c.r[2], c.r[0]); if (k) { goto L_060338A2; } }  // 060337F8 bf/s 0x060338A2 ; mov.l r0,@r2
    c.r[1] = 0x0u;  // 060337FC mov #0,r1
    c.r[4] = (uint32_t)(int16_t)ld16(0x060338AEu);  // 060337FE mov.w 0x060338AE,r4
    c.r[0] = ld32(0x060338C4u);  // 06033800 mov.l 0x060338C4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06033806u; st32(c.r[2], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06033806u) return; }  // 06033802 jsr @r0 ; mov.l r1,@r2
    c.r[1] = c.r[0] & 0xFFFFu;  // 06033806 extu.w r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06033808 tst r1,r1
    if (c.t) { goto L_06033846; }  // 0603380A bt 0x06033846
    c.r[5] = ld32(0x060338C8u);  // 0603380C mov.l 0x060338C8,r5
    c.r[1] = ld32(c.r[5]);  // 0603380E mov.l @r5,r1
    c.r[6] = c.r[1];  // 06033810 mov r1,r6
    c.r[6] += 10;  // 06033812 add #10,r6
    c.r[7] = c.r[1];  // 06033814 mov r1,r7
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[6]);  // 06033816 mov.w @r6,r2
    c.r[7] += 12;  // 06033818 add #12,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0603381A mov.b @r7,r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 0603381C extu.w r2,r2
    c.r[2] <<= 8;  // 0603381E shll8 r2
    c.r[3] = c.r[1] & 0xFFu;  // 06033820 extu.b r1,r3
    c.r[3] |= c.r[2];  // 06033822 or r2,r3
    c.r[1] = ld32(0x060338CCu);  // 06033824 mov.l 0x060338CC,r1
    c.t = c.r[3] > c.r[1];  // 06033826 cmp/hi r1,r3
    { const bool k = c.t; c.r[2] = c.r[3]; if (k) { goto L_06033840; } }  // 06033828 bt/s 0x06033840 ; mov r3,r2
    c.r[2] += 1;  // 0603382C add #1,r2
    c.r[1] = c.r[2];  // 0603382E mov r2,r1
    c.r[1] >>= 8;  // 06033830 shlr8 r1
    st16(c.r[6], c.r[1]);  // 06033832 mov.w r1,@r6
    st8(c.r[7], c.r[2]);  // 06033834 mov.b r2,@r7
    c.r[2] = ld32(c.r[5]);  // 06033836 mov.l @r5,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x060338B0u);  // 06033838 mov.w 0x060338B0,r0
    c.r[1] = ld32(c.r[0] + c.r[2]);  // 0603383A mov.l @(r0,r2),r1
    c.r[1] += 1;  // 0603383C add #1,r1
    st32(c.r[0] + c.r[2], c.r[1]);  // 0603383E mov.l r1,@(r0,r2)
L_06033840:
    c.r[2] = ld32(0x060338D0u);  // 06033840 mov.l 0x060338D0,r2
    c.r[1] = 0x1u; goto L_06033892;  // 06033842 bra 0x06033892 ; mov #1,r1
L_06033846:
    c.r[4] = ld32(0x060338C8u);  // 06033846 mov.l 0x060338C8,r4
    c.r[1] = ld32(c.r[4]);  // 06033848 mov.l @r4,r1
    c.r[6] = c.r[1];  // 0603384A mov r1,r6
    c.r[6] += 10;  // 0603384C add #10,r6
    c.r[5] = c.r[1];  // 0603384E mov r1,r5
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[6]);  // 06033850 mov.w @r6,r2
    c.r[5] += 12;  // 06033852 add #12,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[5]);  // 06033854 mov.b @r5,r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 06033856 extu.w r2,r2
    c.r[2] <<= 8;  // 06033858 shll8 r2
    c.r[7] = c.r[1] & 0xFFu;  // 0603385A extu.b r1,r7
    c.r[7] |= c.r[2];  // 0603385C or r2,r7
    c.r[1] = ld32(0x060338CCu);  // 0603385E mov.l 0x060338CC,r1
    c.t = c.r[7] > c.r[1];  // 06033860 cmp/hi r1,r7
    { const bool k = c.t; c.r[2] = c.r[7]; if (k) { goto L_0603387E; } }  // 06033862 bt/s 0x0603387E ; mov r7,r2
    c.r[3] = ld32(0x060338D4u);  // 06033866 mov.l 0x060338D4,r3
    c.r[2] += c.r[3];  // 06033868 add r3,r2
    c.r[1] = c.r[2];  // 0603386A mov r2,r1
    c.r[1] >>= 8;  // 0603386C shlr8 r1
    st16(c.r[6], c.r[1]);  // 0603386E mov.w r1,@r6
    st8(c.r[5], c.r[2]);  // 06033870 mov.b r2,@r5
    c.r[2] = ld32(c.r[4]);  // 06033872 mov.l @r4,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x060338B0u);  // 06033874 mov.w 0x060338B0,r0
    c.r[1] = ld32(c.r[0] + c.r[2]);  // 06033876 mov.l @(r0,r2),r1
    c.r[1] += c.r[3];  // 06033878 add r3,r1
    st32(c.r[0] + c.r[2], c.r[1]); goto L_06033886;  // 0603387A bra 0x06033886 ; mov.l r1,@(r0,r2)
L_0603387E:
    c.r[1] = (uint32_t)(int16_t)ld16(0x060338B2u);  // 0603387E mov.w 0x060338B2,r1
    st16(c.r[6], c.r[1]);  // 06033880 mov.w r1,@r6
    c.r[1] = 0x7Fu;  // 06033882 mov #127,r1
    st8(c.r[5], c.r[1]);  // 06033884 mov.b r1,@r5
L_06033886:
    c.r[4] = (uint32_t)(int16_t)ld16(0x060338AEu);  // 06033886 mov.w 0x060338AE,r4
    c.r[1] = ld32(0x060338D8u);  // 06033888 mov.l 0x060338D8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603388Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603388Eu) return; }  // 0603388A jsr @r1 ; nop
    c.r[2] = ld32(0x060338D0u);  // 0603388E mov.l 0x060338D0,r2
    c.r[1] = 0x0u;  // 06033890 mov #0,r1
L_06033892:
    st8(c.r[2], c.r[1]);  // 06033892 mov.b r1,@r2
    c.r[1] = ld32(0x060338DCu);  // 06033894 mov.l 0x060338DC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603389Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603389Au) return; }  // 06033896 jsr @r1 ; nop
    c.r[15] = c.r[14]; goto L_060338A4;  // 0603389A bra 0x060338A4 ; mov r14,r15
L_0603389E:
    c.r[1] = 0x0u;  // 0603389E mov #0,r1
    st32(c.r[2], c.r[1]);  // 060338A0 mov.l r1,@r2
L_060338A2:
    c.r[15] = c.r[14];  // 060338A2 mov r14,r15
L_060338A4:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060338A4 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060338A6 mov.l @r15+,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x060338B4u);  // 060338A8 mov.w 0x060338B4,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060338AA rts ; mov.l @r15+,r8
}

void f_060338F0(SH2Context& c) {
    ran[746] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060338F0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060338F2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060338F4 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060338F6 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060338F8 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060338FA mov r15,r14
    c.r[8] = ld32(0x06033934u);  // 060338FC mov.l 0x06033934,r8
    c.r[1] = ld32(0x06033938u);  // 060338FE mov.l 0x06033938,r1
    c.r[5] = ld32(0x0603393Cu);  // 06033900 mov.l 0x0603393C,r5
    c.r[9] = ld32(0x06033940u);  // 06033902 mov.l 0x06033940,r9
    c.r[0] = ld32(0x06033944u);  // 06033904 mov.l 0x06033944,r0
    c.r[10] = ld32(c.r[8]);  // 06033906 mov.l @r8,r10
    c.r[6] = 0x0u;  // 06033908 mov #0,r6
    c.r[1] = ld32(c.r[1]);  // 0603390A mov.l @r1,r1
    c.r[4] = c.r[9];  // 0603390C mov r9,r4
    { const uint32_t x = c.r[0]; c.pr = 0x06033912u; st32(c.r[8], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06033912u) return; }  // 0603390E jsr @r0 ; mov.l r1,@r8
    c.r[5] = ld32(0x06033948u);  // 06033912 mov.l 0x06033948,r5
    c.r[6] = (uint32_t)(int16_t)ld16(0x06033930u);  // 06033914 mov.w 0x06033930,r6
    c.r[0] = ld32(0x0603394Cu);  // 06033916 mov.l 0x0603394C,r0
    c.r[7] = 0x0u;  // 06033918 mov #0,r7
    { const uint32_t x = c.r[0]; c.pr = 0x0603391Eu; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603391Eu) return; }  // 0603391A jsr @r0 ; mov r9,r4
    st32(c.r[8], c.r[10]);  // 0603391E mov.l r10,@r8
    c.r[15] = c.r[14];  // 06033920 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06033922 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06033924 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06033926 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06033928 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06033932u);  // 0603392A mov.w 0x06033932,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603392C rts ; mov.l @r15+,r8
}

void f_06033950(SH2Context& c) {
    ran[747] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06033950 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06033952 mov r15,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x0603395Au);  // 06033954 mov.w 0x0603395A,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06033956 rts ; mov.l @r15+,r14
}

void f_0603395C(SH2Context& c) {
    ran[748] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603395C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603395E sts.l pr,@-r15
    c.r[1] = ld32(0x06033974u);  // 06033960 mov.l 0x06033974,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06033966u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06033966u) return; }  // 06033962 jsr @r1 ; mov r15,r14
    c.r[15] = c.r[14];  // 06033966 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06033968 lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x06033970u);  // 0603396A mov.w 0x06033970,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603396C rts ; mov.l @r15+,r14
}

void f_06033978(SH2Context& c) {
    ran[749] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06033978 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603397A sts.l pr,@-r15
    c.r[1] = ld32(0x060339E8u);  // 0603397C mov.l 0x060339E8,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603397E mov.b @r1,r0
    c.r[14] = c.r[15]; goto L_06033986;  // 06033980 bra 0x06033986 ; mov r15,r14
L_06033984:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06033984 mov.b @r1,r0
L_06033986:
    c.r[0] &= 0x1u;  // 06033986 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06033988 tst r0,r0
    if (!c.t) { SH2_POLL(c); goto L_06033984; }  // 0603398A bf 0x06033984
    c.r[1] = 0x1u;  // 0603398C mov #1,r1
    c.r[3] = ld32(0x060339E8u);  // 0603398E mov.l 0x060339E8,r3
    st8(c.r[3], c.r[1]);  // 06033990 mov.b r1,@r3
    c.r[2] = ld32(0x060339ECu);  // 06033992 mov.l 0x060339EC,r2
    c.r[1] = 0x1Au;  // 06033994 mov #26,r1
    st8(c.r[2], c.r[1]);  // 06033996 mov.b r1,@r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06033998 mov.b @r3,r0
    c.r[0] &= 0x1u;  // 0603399A and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603399C tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_060339AA; } }  // 0603399E bt/s 0x060339AA ; mov r3,r1
L_060339A2:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060339A2 mov.b @r1,r0
    c.r[0] &= 0x1u;  // 060339A4 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060339A6 tst r0,r0
    if (!c.t) { SH2_POLL(c); goto L_060339A2; }  // 060339A8 bf 0x060339A2
L_060339AA:
    c.r[1] = ld32(0x060339F0u);  // 060339AA mov.l 0x060339F0,r1
    c.r[6] = ld32(0x060339F4u);  // 060339AC mov.l 0x060339F4,r6
    c.r[5] = ld32(0x060339F8u);  // 060339AE mov.l 0x060339F8,r5
    c.r[1] = ld32(c.r[1]);  // 060339B0 mov.l @r1,r1
    c.r[4] = ld32(0x060339FCu);  // 060339B2 mov.l 0x060339FC,r4
    { const uint32_t x = c.r[1]; c.pr = 0x060339B8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060339B8u) return; }  // 060339B4 jsr @r1 ; nop
    c.r[1] = ld32(0x060339E8u);  // 060339B8 mov.l 0x060339E8,r1
L_060339BA:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060339BA mov.b @r1,r0
    c.r[0] &= 0x1u;  // 060339BC and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060339BE tst r0,r0
    if (!c.t) { SH2_POLL(c); goto L_060339BA; }  // 060339C0 bf 0x060339BA
    c.r[1] = 0x1u;  // 060339C2 mov #1,r1
    c.r[3] = ld32(0x060339E8u);  // 060339C4 mov.l 0x060339E8,r3
    st8(c.r[3], c.r[1]);  // 060339C6 mov.b r1,@r3
    c.r[2] = ld32(0x060339ECu);  // 060339C8 mov.l 0x060339EC,r2
    c.r[1] = 0x19u;  // 060339CA mov #25,r1
    st8(c.r[2], c.r[1]);  // 060339CC mov.b r1,@r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060339CE mov.b @r3,r0
    c.r[0] &= 0x1u;  // 060339D0 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060339D2 tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_060339E0; } }  // 060339D4 bt/s 0x060339E0 ; mov r3,r1
L_060339D8:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060339D8 mov.b @r1,r0
    c.r[0] &= 0x1u;  // 060339DA and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060339DC tst r0,r0
    if (!c.t) { SH2_POLL(c); goto L_060339D8; }  // 060339DE bf 0x060339D8
L_060339E0:
    c.r[15] = c.r[14];  // 060339E0 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060339E2 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060339E4 rts ; mov.l @r15+,r14
}

void f_06033A00(SH2Context& c) {
    ran[750] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06033A00 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06033A02 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06033A04 mov r15,r14
    c.r[2] = ld32(0x06033AA8u);  // 06033A06 mov.l 0x06033AA8,r2
    c.r[3] = c.r[2];  // 06033A08 mov r2,r3
    c.r[3] += 108;  // 06033A0A add #108,r3
    c.r[2] += 112;  // 06033A0C add #112,r2
    c.r[1] = 0x0u;  // 06033A0E mov #0,r1
    st32(c.r[2], c.r[1]);  // 06033A10 mov.l r1,@r2
    st32(c.r[3], c.r[1]);  // 06033A12 mov.l r1,@r3
    c.r[1] = ld32(0x06033AACu);  // 06033A14 mov.l 0x06033AAC,r1
    c.r[0] = ld32(c.r[1]);  // 06033A16 mov.l @r1,r0
    c.r[2] = ld32(0x06033AB0u);  // 06033A18 mov.l 0x06033AB0,r2
    c.r[0] <<= 2;  // 06033A1A shll2 r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 06033A1C mov.w @(r0,r2),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06033A1E extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06033A20 tst r1,r1
    { const bool k = c.t; c.r[6] = 0x1u; if (k) { goto L_06033A9A; } }  // 06033A22 bt/s 0x06033A9A ; mov #1,r6
    c.r[1] = ld32(0x06033AB4u);  // 06033A26 mov.l 0x06033AB4,r1
L_06033A28:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06033A28 mov.b @r1,r0
    c.r[0] &= 0x1u;  // 06033A2A and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06033A2C tst r0,r0
    if (!c.t) { SH2_POLL(c); goto L_06033A28; }  // 06033A2E bf 0x06033A28
    c.r[1] = 0x1u;  // 06033A30 mov #1,r1
    c.r[3] = ld32(0x06033AB4u);  // 06033A32 mov.l 0x06033AB4,r3
    st8(c.r[3], c.r[1]);  // 06033A34 mov.b r1,@r3
    c.r[2] = ld32(0x06033AB8u);  // 06033A36 mov.l 0x06033AB8,r2
    c.r[1] = 0x1Au;  // 06033A38 mov #26,r1
    st8(c.r[2], c.r[1]);  // 06033A3A mov.b r1,@r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06033A3C mov.b @r3,r0
    c.r[0] &= 0x1u;  // 06033A3E and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06033A40 tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_06033A4E; } }  // 06033A42 bt/s 0x06033A4E ; mov r3,r1
L_06033A46:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06033A46 mov.b @r1,r0
    c.r[0] &= 0x1u;  // 06033A48 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06033A4A tst r0,r0
    if (!c.t) { SH2_POLL(c); goto L_06033A46; }  // 06033A4C bf 0x06033A46
L_06033A4E:
    c.r[1] = ld32(0x06033ABCu);  // 06033A4E mov.l 0x06033ABC,r1
    c.r[2] = ld32(c.r[1]);  // 06033A50 mov.l @r1,r2
    c.r[1] = ld32(0x06033AACu);  // 06033A52 mov.l 0x06033AAC,r1
    c.r[6] = ld32(0x06033AC0u);  // 06033A54 mov.l 0x06033AC0,r6
    c.r[0] = ld32(c.r[2] + 12);  // 06033A56 mov.l @(12,r2),r0
    c.r[5] = (uint32_t)(int16_t)ld16(0x06033AA4u);  // 06033A58 mov.w 0x06033AA4,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06033A5Eu; c.r[4] = ld32(c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06033A5Eu) return; }  // 06033A5A jsr @r0 ; mov.l @r1,r4
    c.r[6] = c.r[0];  // 06033A5E mov r0,r6
    c.r[1] = ld32(0x06033AB4u);  // 06033A60 mov.l 0x06033AB4,r1
L_06033A62:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06033A62 mov.b @r1,r0
    c.r[0] &= 0x1u;  // 06033A64 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06033A66 tst r0,r0
    if (!c.t) { SH2_POLL(c); goto L_06033A62; }  // 06033A68 bf 0x06033A62
    c.r[1] = 0x1u;  // 06033A6A mov #1,r1
    c.r[3] = ld32(0x06033AB4u);  // 06033A6C mov.l 0x06033AB4,r3
    st8(c.r[3], c.r[1]);  // 06033A6E mov.b r1,@r3
    c.r[2] = ld32(0x06033AB8u);  // 06033A70 mov.l 0x06033AB8,r2
    c.r[1] = 0x19u;  // 06033A72 mov #25,r1
    st8(c.r[2], c.r[1]);  // 06033A74 mov.b r1,@r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06033A76 mov.b @r3,r0
    c.r[0] &= 0x1u;  // 06033A78 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06033A7A tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_06033A88; } }  // 06033A7C bt/s 0x06033A88 ; mov r3,r1
L_06033A80:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06033A80 mov.b @r1,r0
    c.r[0] &= 0x1u;  // 06033A82 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06033A84 tst r0,r0
    if (!c.t) { SH2_POLL(c); goto L_06033A80; }  // 06033A86 bf 0x06033A80
L_06033A88:
    c.r[7] = ld32(0x06033AA8u);  // 06033A88 mov.l 0x06033AA8,r7
    c.r[3] = c.r[7];  // 06033A8A mov r7,r3
    c.r[2] = ld32(0x06033AC0u);  // 06033A8C mov.l 0x06033AC0,r2
    c.r[1] = ld32(c.r[2]);  // 06033A8E mov.l @r2,r1
    c.r[3] += 108;  // 06033A90 add #108,r3
    st32(c.r[3], c.r[1]);  // 06033A92 mov.l r1,@r3
    c.r[1] = ld32(c.r[2] + 12);  // 06033A94 mov.l @(12,r2),r1
    c.r[7] += 112;  // 06033A96 add #112,r7
    st32(c.r[7], c.r[1]);  // 06033A98 mov.l r1,@r7
L_06033A9A:
    c.r[15] = c.r[14];  // 06033A9A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06033A9C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06033A9E mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[6]; c.pc = x; return; }  // 06033AA0 rts ; mov r6,r0
}

void f_06033AC4(SH2Context& c) {
    ran[751] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06033AC4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06033AC6 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06033AC8 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06033ACA mov r15,r14
    c.r[4] = c.r[4] & 0xFFu;  // 06033ACC extu.b r4,r4
    c.r[7] = 0xFFFFFFFFu;  // 06033ACE mov #-1,r7
    c.r[2] = ld32(0x06033B64u);  // 06033AD0 mov.l 0x06033B64,r2
    c.t = (c.r[4] & c.r[4]) == 0;  // 06033AD2 tst r4,r4
    { const bool k = !c.t; c.r[8] = ld32(c.r[2]); if (k) { goto L_06033ADE; } }  // 06033AD4 bf/s 0x06033ADE ; mov.l @r2,r8
    c.r[1] = ld32(0x06033B68u);  // 06033AD8 mov.l 0x06033B68,r1
    c.r[1] = ld32(c.r[1]);  // 06033ADA mov.l @r1,r1
    st32(c.r[2], c.r[1]);  // 06033ADC mov.l r1,@r2
L_06033ADE:
    c.r[0] = ld32(c.r[2]);  // 06033ADE mov.l @r2,r0
    c.r[1] = ld32(0x06033B6Cu);  // 06033AE0 mov.l 0x06033B6C,r1
    c.r[0] <<= 2;  // 06033AE2 shll2 r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06033AE4 mov.w @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06033AE6 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06033AE8 tst r1,r1
    if (c.t) { goto L_06033B52; }  // 06033AEA bt 0x06033B52
    c.r[1] = ld32(0x06033B70u);  // 06033AEC mov.l 0x06033B70,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06033AF2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06033AF2u) return; }  // 06033AEE jsr @r1 ; nop
    c.r[1] = ld32(0x06033B74u);  // 06033AF2 mov.l 0x06033B74,r1
L_06033AF4:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06033AF4 mov.b @r1,r0
    c.r[0] &= 0x1u;  // 06033AF6 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06033AF8 tst r0,r0
    if (!c.t) { SH2_POLL(c); goto L_06033AF4; }  // 06033AFA bf 0x06033AF4
    c.r[1] = 0x1u;  // 06033AFC mov #1,r1
    c.r[3] = ld32(0x06033B74u);  // 06033AFE mov.l 0x06033B74,r3
    st8(c.r[3], c.r[1]);  // 06033B00 mov.b r1,@r3
    c.r[2] = ld32(0x06033B78u);  // 06033B02 mov.l 0x06033B78,r2
    c.r[1] = 0x1Au;  // 06033B04 mov #26,r1
    st8(c.r[2], c.r[1]);  // 06033B06 mov.b r1,@r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06033B08 mov.b @r3,r0
    c.r[0] &= 0x1u;  // 06033B0A and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06033B0C tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_06033B1A; } }  // 06033B0E bt/s 0x06033B1A ; mov r3,r1
L_06033B12:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06033B12 mov.b @r1,r0
    c.r[0] &= 0x1u;  // 06033B14 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06033B16 tst r0,r0
    if (!c.t) { SH2_POLL(c); goto L_06033B12; }  // 06033B18 bf 0x06033B12
L_06033B1A:
    c.r[1] = ld32(0x06033B7Cu);  // 06033B1A mov.l 0x06033B7C,r1
    c.r[2] = ld32(c.r[1]);  // 06033B1C mov.l @r1,r2
    c.r[1] = ld32(0x06033B64u);  // 06033B1E mov.l 0x06033B64,r1
    c.r[0] = ld32(c.r[2] + 24);  // 06033B20 mov.l @(24,r2),r0
    c.r[5] = ld32(0x06033B80u);  // 06033B22 mov.l 0x06033B80,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06033B28u; c.r[4] = ld32(c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06033B28u) return; }  // 06033B24 jsr @r0 ; mov.l @r1,r4
    c.r[7] = c.r[0];  // 06033B28 mov r0,r7
    c.r[1] = ld32(0x06033B74u);  // 06033B2A mov.l 0x06033B74,r1
L_06033B2C:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06033B2C mov.b @r1,r0
    c.r[0] &= 0x1u;  // 06033B2E and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06033B30 tst r0,r0
    if (!c.t) { SH2_POLL(c); goto L_06033B2C; }  // 06033B32 bf 0x06033B2C
    c.r[1] = 0x1u;  // 06033B34 mov #1,r1
    c.r[3] = ld32(0x06033B74u);  // 06033B36 mov.l 0x06033B74,r3
    st8(c.r[3], c.r[1]);  // 06033B38 mov.b r1,@r3
    c.r[2] = ld32(0x06033B78u);  // 06033B3A mov.l 0x06033B78,r2
    c.r[1] = 0x19u;  // 06033B3C mov #25,r1
    st8(c.r[2], c.r[1]);  // 06033B3E mov.b r1,@r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06033B40 mov.b @r3,r0
    c.r[0] &= 0x1u;  // 06033B42 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06033B44 tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_06033B52; } }  // 06033B46 bt/s 0x06033B52 ; mov r3,r1
L_06033B4A:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06033B4A mov.b @r1,r0
    c.r[0] &= 0x1u;  // 06033B4C and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06033B4E tst r0,r0
    if (!c.t) { SH2_POLL(c); goto L_06033B4A; }  // 06033B50 bf 0x06033B4A
L_06033B52:
    c.r[1] = ld32(0x06033B64u);  // 06033B52 mov.l 0x06033B64,r1
    st32(c.r[1], c.r[8]);  // 06033B54 mov.l r8,@r1
    c.r[15] = c.r[14];  // 06033B56 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06033B58 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06033B5A mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06033B5C mov.l @r15+,r8
    { const uint32_t x = c.pr; c.r[0] = c.r[7]; c.pc = x; return; }  // 06033B5E rts ; mov r7,r0
}

void f_06033B84(SH2Context& c) {
    ran[752] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06033B84 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06033B86 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06033B88 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06033B8A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06033B8C mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06033B8E mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06033B90 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06033B92 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06033B94 mov r15,r14
    c.r[8] = c.r[5];  // 06033B96 mov r5,r8
    c.r[12] = c.r[6];  // 06033B98 mov r6,r12
    c.r[9] = c.r[7];  // 06033B9A mov r7,r9
    c.r[10] = c.r[4] & 0xFFu;  // 06033B9C extu.b r4,r10
    c.r[11] = 0x0u;  // 06033B9E mov #0,r11
    c.r[2] = ld32(0x06033C68u);  // 06033BA0 mov.l 0x06033C68,r2
    c.t = (c.r[10] & c.r[10]) == 0;  // 06033BA2 tst r10,r10
    { const bool k = !c.t; c.r[13] = ld32(c.r[2]); if (k) { goto L_06033BAE; } }  // 06033BA4 bf/s 0x06033BAE ; mov.l @r2,r13
    c.r[1] = ld32(0x06033C6Cu);  // 06033BA8 mov.l 0x06033C6C,r1
    c.r[1] = ld32(c.r[1]);  // 06033BAA mov.l @r1,r1
    st32(c.r[2], c.r[1]);  // 06033BAC mov.l r1,@r2
L_06033BAE:
    c.t = (c.r[8] & c.r[8]) == 0;  // 06033BAE tst r8,r8
    if (!c.t) { goto L_06033BB6; }  // 06033BB0 bf 0x06033BB6
    c.r[11] = 0x1u;  // 06033BB2 mov #1,r11
    c.r[8] = ld32(0x06033C70u);  // 06033BB4 mov.l 0x06033C70,r8
L_06033BB6:
    c.r[1] = ld32(0x06033C74u);  // 06033BB6 mov.l 0x06033C74,r1
    c.r[5] = c.r[12];  // 06033BB8 mov r12,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06033BBEu; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06033BBEu) return; }  // 06033BBA jsr @r1 ; mov r10,r4
    c.r[4] = ld32(0x06033C78u);  // 06033BBE mov.l 0x06033C78,r4
    c.r[0] = ld32(0x06033C7Cu);  // 06033BC0 mov.l 0x06033C7C,r0
    c.r[6] = c.r[9];  // 06033BC2 mov r9,r6
    { const uint32_t x = c.r[0]; c.pr = 0x06033BC8u; c.r[5] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06033BC8u) return; }  // 06033BC4 jsr @r0 ; mov r8,r5
    c.r[9] = c.r[0];  // 06033BC8 mov r0,r9
    c.t = (c.r[9] & c.r[9]) == 0;  // 06033BCA tst r9,r9
    { const bool k = !c.t; c.t = (c.r[11] & c.r[11]) == 0; if (k) { goto L_06033C48; } }  // 06033BCC bf/s 0x06033C48 ; tst r11,r11
    { const bool k = c.t; c.t = (c.r[10] & c.r[10]) == 0; if (k) { goto L_06033C48; } }  // 06033BD0 bt/s 0x06033C48 ; tst r10,r10
    c.r[5] = (uint32_t)(int16_t)ld16(0x06033C62u);  // 06033BD4 mov.w 0x06033C62,r5
    if (c.t) { goto L_06033BDA; }  // 06033BD6 bt 0x06033BDA
    c.r[5] = (uint32_t)(int16_t)ld16(0x06033C64u);  // 06033BD8 mov.w 0x06033C64,r5
L_06033BDA:
    c.r[0] = ld32(0x06033C80u);  // 06033BDA mov.l 0x06033C80,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06033BE0u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06033BE0u) return; }  // 06033BDC jsr @r0 ; mov r8,r4
    c.r[11] = c.r[0];  // 06033BE0 mov r0,r11
    c.r[1] = ld32(0x06033C84u);  // 06033BE2 mov.l 0x06033C84,r1
    c.r[2] = ld32(c.r[1]);  // 06033BE4 mov.l @r1,r2
    c.r[8] = ld32(0x06033C70u);  // 06033BE6 mov.l 0x06033C70,r8
    c.r[1] = ld32(c.r[8]);  // 06033BE8 mov.l @r8,r1
    c.t = (c.r[10] & c.r[10]) == 0;  // 06033BEA tst r10,r10
    { const bool k = c.t; st32(c.r[2], c.r[1]); if (k) { goto L_06033C00; } }  // 06033BEC bt/s 0x06033C00 ; mov.l r1,@r2
    c.r[1] = ld32(0x06033C88u);  // 06033BF0 mov.l 0x06033C88,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06033BF6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06033BF6u) return; }  // 06033BF2 jsr @r1 ; nop
    c.r[1] = ld32(0x06033C8Cu);  // 06033BF6 mov.l 0x06033C8C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06033BFCu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06033BFCu) return; }  // 06033BF8 jsr @r1 ; nop
    goto L_06033C12;  // 06033BFC bra 0x06033C12 ; nop
L_06033C00:
    c.r[1] = ld32(0x06033C90u);  // 06033C00 mov.l 0x06033C90,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06033C06u; c.r[8] += 4; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06033C06u) return; }  // 06033C02 jsr @r1 ; add #4,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06033C06 mov.b @r8,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06033C66u);  // 06033C08 mov.w 0x06033C66,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06033C0A extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 06033C0C cmp/eq r2,r1
    if (!c.t) { goto L_06033C12; }  // 06033C0E bf 0x06033C12
    c.r[9] = 0xFFFFFFFDu;  // 06033C10 mov #-3,r9
L_06033C12:
    c.r[1] = ld32(0x06033C84u);  // 06033C12 mov.l 0x06033C84,r1
    c.r[1] = ld32(c.r[1]);  // 06033C14 mov.l @r1,r1
    c.r[1] = ld32(c.r[1]);  // 06033C16 mov.l @r1,r1
    c.t = c.r[1] == c.r[11];  // 06033C18 cmp/eq r11,r1
    { const bool k = !c.t; c.t = (c.r[11] & c.r[11]) == 0; if (k) { goto L_06033C22; } }  // 06033C1A bf/s 0x06033C22 ; tst r11,r11
    { const bool k = !c.t; c.t = (c.r[9] & c.r[9]) == 0; if (k) { goto L_06033C26; } }  // 06033C1E bf/s 0x06033C26 ; tst r9,r9
L_06033C22:
    c.r[9] = 0xFFFFFFFEu;  // 06033C22 mov #-2,r9
    c.t = (c.r[9] & c.r[9]) == 0;  // 06033C24 tst r9,r9
L_06033C26:
    if (!c.t) { goto L_06033C48; }  // 06033C26 bf 0x06033C48
    c.r[1] = ld32(0x06033C94u);  // 06033C28 mov.l 0x06033C94,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06033C2Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06033C2Eu) return; }  // 06033C2A jsr @r1 ; nop
    c.r[0] = ld32(0x06033C98u);  // 06033C2E mov.l 0x06033C98,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06033C34u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06033C34u) return; }  // 06033C30 jsr @r0 ; nop
    c.r[1] = ld32(0x06033C9Cu);  // 06033C34 mov.l 0x06033C9C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06033C3Au; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06033C3Au) return; }  // 06033C36 jsr @r1 ; mov #1,r4
    c.t = (c.r[12] & c.r[12]) == 0;  // 06033C3A tst r12,r12
    { const bool k = !c.t; c.t = (c.r[10] & c.r[10]) == 0; if (k) { goto L_06033C48; } }  // 06033C3C bf/s 0x06033C48 ; tst r10,r10
    if (c.t) { goto L_06033C48; }  // 06033C40 bt 0x06033C48
    c.r[1] = ld32(0x06033CA0u);  // 06033C42 mov.l 0x06033CA0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06033C48u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06033C48u) return; }  // 06033C44 jsr @r1 ; nop
L_06033C48:
    c.r[1] = ld32(0x06033C68u);  // 06033C48 mov.l 0x06033C68,r1
    st32(c.r[1], c.r[13]);  // 06033C4A mov.l r13,@r1
    c.r[15] = c.r[14];  // 06033C4C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06033C4E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06033C50 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06033C52 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06033C54 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06033C56 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06033C58 mov.l @r15+,r10
    c.r[0] = c.r[9];  // 06033C5A mov r9,r0
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06033C5C mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06033C5E rts ; mov.l @r15+,r8
}

void f_06033CA4(SH2Context& c) {
    ran[753] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06033CA4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06033CA6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06033CA8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06033CAA sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06033CAC mov r15,r14
    c.r[9] = c.r[4];  // 06033CAE mov r4,r9
    c.r[8] = c.r[6];  // 06033CB0 mov r6,r8
    c.r[1] = ld32(0x06033D3Cu);  // 06033CB2 mov.l 0x06033D3C,r1
    c.r[0] = ld32(c.r[1]);  // 06033CB4 mov.l @r1,r0
    c.r[2] = ld32(0x06033D40u);  // 06033CB6 mov.l 0x06033D40,r2
    c.r[0] <<= 2;  // 06033CB8 shll2 r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 06033CBA mov.w @(r0,r2),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06033CBC extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06033CBE tst r1,r1
    { const bool k = c.t; c.r[7] = 0xFFFFFFFFu; if (k) { goto L_06033D2E; } }  // 06033CC0 bt/s 0x06033D2E ; mov #-1,r7
    c.t = (c.r[8] & c.r[8]) == 0;  // 06033CC4 tst r8,r8
    if (c.t) { goto L_06033CF0; }  // 06033CC6 bt 0x06033CF0
    c.r[1] = ld32(0x06033D44u);  // 06033CC8 mov.l 0x06033D44,r1
L_06033CCA:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06033CCA mov.b @r1,r0
    c.r[0] &= 0x1u;  // 06033CCC and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06033CCE tst r0,r0
    if (!c.t) { SH2_POLL(c); goto L_06033CCA; }  // 06033CD0 bf 0x06033CCA
    c.r[1] = 0x1u;  // 06033CD2 mov #1,r1
    c.r[3] = ld32(0x06033D44u);  // 06033CD4 mov.l 0x06033D44,r3
    st8(c.r[3], c.r[1]);  // 06033CD6 mov.b r1,@r3
    c.r[2] = ld32(0x06033D48u);  // 06033CD8 mov.l 0x06033D48,r2
    c.r[1] = 0x1Au;  // 06033CDA mov #26,r1
    st8(c.r[2], c.r[1]);  // 06033CDC mov.b r1,@r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06033CDE mov.b @r3,r0
    c.r[0] &= 0x1u;  // 06033CE0 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06033CE2 tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_06033CF0; } }  // 06033CE4 bt/s 0x06033CF0 ; mov r3,r1
L_06033CE8:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06033CE8 mov.b @r1,r0
    c.r[0] &= 0x1u;  // 06033CEA and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06033CEC tst r0,r0
    if (!c.t) { SH2_POLL(c); goto L_06033CE8; }  // 06033CEE bf 0x06033CE8
L_06033CF0:
    c.r[1] = ld32(0x06033D4Cu);  // 06033CF0 mov.l 0x06033D4C,r1
    c.r[2] = ld32(c.r[1]);  // 06033CF2 mov.l @r1,r2
    c.r[1] = ld32(0x06033D3Cu);  // 06033CF4 mov.l 0x06033D3C,r1
    c.r[4] = ld32(c.r[1]);  // 06033CF6 mov.l @r1,r4
    c.r[6] = c.r[5];  // 06033CF8 mov r5,r6
    c.r[0] = ld32(c.r[2] + 20);  // 06033CFA mov.l @(20,r2),r0
    { const uint32_t x = c.r[0]; c.pr = 0x06033D00u; c.r[5] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06033D00u) return; }  // 06033CFC jsr @r0 ; mov r9,r5
    c.t = (c.r[8] & c.r[8]) == 0;  // 06033D00 tst r8,r8
    { const bool k = c.t; c.r[7] = c.r[0]; if (k) { goto L_06033D2E; } }  // 06033D02 bt/s 0x06033D2E ; mov r0,r7
    c.r[1] = ld32(0x06033D44u);  // 06033D06 mov.l 0x06033D44,r1
L_06033D08:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06033D08 mov.b @r1,r0
    c.r[0] &= 0x1u;  // 06033D0A and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06033D0C tst r0,r0
    if (!c.t) { SH2_POLL(c); goto L_06033D08; }  // 06033D0E bf 0x06033D08
    c.r[1] = 0x1u;  // 06033D10 mov #1,r1
    c.r[3] = ld32(0x06033D44u);  // 06033D12 mov.l 0x06033D44,r3
    st8(c.r[3], c.r[1]);  // 06033D14 mov.b r1,@r3
    c.r[2] = ld32(0x06033D48u);  // 06033D16 mov.l 0x06033D48,r2
    c.r[1] = 0x19u;  // 06033D18 mov #25,r1
    st8(c.r[2], c.r[1]);  // 06033D1A mov.b r1,@r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06033D1C mov.b @r3,r0
    c.r[0] &= 0x1u;  // 06033D1E and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06033D20 tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_06033D2E; } }  // 06033D22 bt/s 0x06033D2E ; mov r3,r1
L_06033D26:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06033D26 mov.b @r1,r0
    c.r[0] &= 0x1u;  // 06033D28 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06033D2A tst r0,r0
    if (!c.t) { SH2_POLL(c); goto L_06033D26; }  // 06033D2C bf 0x06033D26
L_06033D2E:
    c.r[15] = c.r[14];  // 06033D2E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06033D30 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06033D32 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06033D34 mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06033D36 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.r[0] = c.r[7]; c.pc = x; return; }  // 06033D38 rts ; mov r7,r0
}

void f_06033D50(SH2Context& c) {
    ran[754] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06033D50 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06033D52 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06033D54 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06033D56 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06033D58 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06033D5A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06033D5C sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06033D5E mov r15,r14
    c.r[11] = c.r[5];  // 06033D60 mov r5,r11
    c.r[10] = c.r[4] & 0xFFu;  // 06033D62 extu.b r4,r10
    c.r[2] = ld32(0x06033E04u);  // 06033D64 mov.l 0x06033E04,r2
    c.t = (c.r[10] & c.r[10]) == 0;  // 06033D66 tst r10,r10
    { const bool k = !c.t; c.r[12] = ld32(c.r[2]); if (k) { goto L_06033D72; } }  // 06033D68 bf/s 0x06033D72 ; mov.l @r2,r12
    c.r[1] = ld32(0x06033E08u);  // 06033D6C mov.l 0x06033E08,r1
    c.r[1] = ld32(c.r[1]);  // 06033D6E mov.l @r1,r1
    st32(c.r[2], c.r[1]);  // 06033D70 mov.l r1,@r2
L_06033D72:
    c.r[1] = 0x7Eu;  // 06033D72 mov #126,r1
    c.t = c.r[10] > c.r[1];  // 06033D74 cmp/hi r1,r10
    if (!c.t) { goto L_06033D94; }  // 06033D76 bf 0x06033D94
    c.r[10] = 0x0u;  // 06033D78 mov #0,r10
    c.r[4] = ld32(0x06033E0Cu);  // 06033D7A mov.l 0x06033E0C,r4
    c.r[1] = ld32(0x06033E10u);  // 06033D7C mov.l 0x06033E10,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06033D82u; c.r[5] = 0x4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06033D82u) return; }  // 06033D7E jsr @r1 ; mov #4,r5
    c.r[3] = ld32(0x06033E14u);  // 06033D82 mov.l 0x06033E14,r3
    c.r[2] = ld32(c.r[3]);  // 06033D84 mov.l @r3,r2
    c.r[1] = 0xFFFFFFFFu;  // 06033D86 mov #-1,r1
    c.r[2] += 4;  // 06033D88 add #4,r2
    st8(c.r[2], c.r[1]);  // 06033D8A mov.b r1,@r2
    c.r[2] = ld32(c.r[3]);  // 06033D8C mov.l @r3,r2
    c.r[1] = 0x1u;  // 06033D8E mov #1,r1
    c.r[2] += 7;  // 06033D90 add #7,r2
    st8(c.r[2], c.r[1]);  // 06033D92 mov.b r1,@r2
L_06033D94:
    c.r[1] = ld32(0x06033E18u);  // 06033D94 mov.l 0x06033E18,r1
    c.r[5] = c.r[11];  // 06033D96 mov r11,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06033D9Cu; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06033D9Cu) return; }  // 06033D98 jsr @r1 ; mov r10,r4
    c.t = (c.r[10] & c.r[10]) == 0;  // 06033D9C tst r10,r10
    if (c.t) { goto L_06033DB4; }  // 06033D9E bt 0x06033DB4
    c.r[1] = ld32(0x06033E1Cu);  // 06033DA0 mov.l 0x06033E1C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06033DA6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06033DA6u) return; }  // 06033DA2 jsr @r1 ; nop
    c.r[1] = ld32(0x06033E20u);  // 06033DA6 mov.l 0x06033E20,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06033DACu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06033DACu) return; }  // 06033DA8 jsr @r1 ; nop
    c.r[9] = ld32(0x06033E24u);  // 06033DAC mov.l 0x06033E24,r9
    c.r[8] = (uint32_t)(int16_t)ld16(0x06033E00u);  // 06033DAE mov.w 0x06033E00,r8
    goto L_06033DBE;  // 06033DB0 bra 0x06033DBE ; nop
L_06033DB4:
    c.r[1] = ld32(0x06033E28u);  // 06033DB4 mov.l 0x06033E28,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06033DBAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06033DBAu) return; }  // 06033DB6 jsr @r1 ; nop
    c.r[9] = ld32(0x06033E24u);  // 06033DBA mov.l 0x06033E24,r9
    c.r[8] = (uint32_t)(int16_t)ld16(0x06033E02u);  // 06033DBC mov.w 0x06033E02,r8
L_06033DBE:
    c.r[0] = ld32(0x06033E2Cu);  // 06033DBE mov.l 0x06033E2C,r0
    c.r[5] = c.r[8];  // 06033DC0 mov r8,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06033DC6u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06033DC6u) return; }  // 06033DC2 jsr @r0 ; mov r9,r4
    c.r[1] = ld32(0x06033E14u);  // 06033DC6 mov.l 0x06033E14,r1
    c.r[2] = ld32(c.r[1]);  // 06033DC8 mov.l @r1,r2
    c.r[4] = ld32(0x06033E30u);  // 06033DCA mov.l 0x06033E30,r4
    c.r[7] = 0x0u;  // 06033DCC mov #0,r7
    c.r[6] = c.r[8];  // 06033DCE mov r8,r6
    c.r[1] = ld32(0x06033E24u);  // 06033DD0 mov.l 0x06033E24,r1
    st32(c.r[1], c.r[0]);  // 06033DD2 mov.l r0,@r1
    st32(c.r[2], c.r[0]);  // 06033DD4 mov.l r0,@r2
    c.r[0] = ld32(0x06033E34u);  // 06033DD6 mov.l 0x06033E34,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06033DDCu; c.r[5] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06033DDCu) return; }  // 06033DD8 jsr @r0 ; mov r9,r5
    c.t = (c.r[10] & c.r[10]) == 0;  // 06033DDC tst r10,r10
    { const bool k = c.t; c.r[8] = c.r[0]; if (k) { goto L_06033DE8; } }  // 06033DDE bt/s 0x06033DE8 ; mov r0,r8
    c.r[0] = ld32(0x06033E38u);  // 06033DE2 mov.l 0x06033E38,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06033DE8u; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06033DE8u) return; }  // 06033DE4 jsr @r0 ; mov r11,r4
L_06033DE8:
    c.r[1] = ld32(0x06033E04u);  // 06033DE8 mov.l 0x06033E04,r1
    st32(c.r[1], c.r[12]);  // 06033DEA mov.l r12,@r1
    c.r[15] = c.r[14];  // 06033DEC mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06033DEE lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06033DF0 mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06033DF2 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06033DF4 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06033DF6 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06033DF8 mov.l @r15+,r9
    c.r[0] = c.r[8];  // 06033DFA mov r8,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06033DFC rts ; mov.l @r15+,r8
}

void f_06033E3C(SH2Context& c) {
    ran[755] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06033E3C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06033E3E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06033E40 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06033E42 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06033E44 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06033E46 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06033E48 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06033E4A mov r15,r14
    c.r[10] = c.r[4];  // 06033E4C mov r4,r10
    c.r[12] = c.r[5];  // 06033E4E mov r5,r12
    c.r[11] = c.r[6];  // 06033E50 mov r6,r11
    c.r[1] = ld32(0x06033F18u);  // 06033E52 mov.l 0x06033F18,r1
    c.r[0] = ld32(c.r[1]);  // 06033E54 mov.l @r1,r0
    c.r[2] = ld32(0x06033F1Cu);  // 06033E56 mov.l 0x06033F1C,r2
    c.r[0] <<= 2;  // 06033E58 shll2 r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 06033E5A mov.w @(r0,r2),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06033E5C extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06033E5E tst r1,r1
    { const bool k = c.t; c.r[8] = 0x1u; if (k) { goto L_06033F02; } }  // 06033E60 bt/s 0x06033F02 ; mov #1,r8
    c.r[0] = ld32(0x06033F20u);  // 06033E64 mov.l 0x06033F20,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06033E6Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06033E6Au) return; }  // 06033E66 jsr @r0 ; nop
    c.t = (c.r[0] & c.r[0]) == 0;  // 06033E6A tst r0,r0
    if (!c.t) { goto L_06033F02; }  // 06033E6C bf 0x06033F02
    c.r[1] = ld32(0x06033F24u);  // 06033E6E mov.l 0x06033F24,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06033E74u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06033E74u) return; }  // 06033E70 jsr @r1 ; nop
    c.r[8] = ld32(0x06033F28u);  // 06033E74 mov.l 0x06033F28,r8
    c.r[9] = ld32(0x06033F2Cu);  // 06033E76 mov.l 0x06033F2C,r9
    c.r[5] = c.r[10];  // 06033E78 mov r10,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06033E7Eu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06033E7Eu) return; }  // 06033E7A jsr @r9 ; mov r8,r4
    c.r[5] = ld32(0x06033F30u);  // 06033E7E mov.l 0x06033F30,r5
    c.r[4] = c.r[8];  // 06033E80 mov r8,r4
    { const uint32_t x = c.r[9]; c.pr = 0x06033E86u; c.r[4] += 12; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06033E86u) return; }  // 06033E82 jsr @r9 ; add #12,r4
    c.r[2] = c.r[8];  // 06033E86 mov r8,r2
    c.r[2] += 23;  // 06033E88 add #23,r2
    c.r[1] = 0x0u;  // 06033E8A mov #0,r1
    st8(c.r[2], c.r[1]);  // 06033E8C mov.b r1,@r2
    st32(c.r[8] + 28, c.r[11]);  // 06033E8E mov.l r11,@(28,r8)
    c.r[1] = ld32(0x06033F34u);  // 06033E90 mov.l 0x06033F34,r1
    c.r[1] = ld32(c.r[1]);  // 06033E92 mov.l @r1,r1
    c.r[0] = ld32(c.r[1] + 40);  // 06033E94 mov.l @(40,r1),r0
    c.r[4] = ld32(0x06033F38u);  // 06033E96 mov.l 0x06033F38,r4
    { const uint32_t x = c.r[0]; c.pr = 0x06033E9Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06033E9Cu) return; }  // 06033E98 jsr @r0 ; nop
    st32(c.r[8] + 24, c.r[0]);  // 06033E9C mov.l r0,@(24,r8)
    c.r[1] = ld32(0x06033F3Cu);  // 06033E9E mov.l 0x06033F3C,r1
L_06033EA0:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06033EA0 mov.b @r1,r0
    c.r[0] &= 0x1u;  // 06033EA2 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06033EA4 tst r0,r0
    if (!c.t) { SH2_POLL(c); goto L_06033EA0; }  // 06033EA6 bf 0x06033EA0
    c.r[1] = 0x1u;  // 06033EA8 mov #1,r1
    c.r[3] = ld32(0x06033F3Cu);  // 06033EAA mov.l 0x06033F3C,r3
    st8(c.r[3], c.r[1]);  // 06033EAC mov.b r1,@r3
    c.r[2] = ld32(0x06033F40u);  // 06033EAE mov.l 0x06033F40,r2
    c.r[1] = 0x1Au;  // 06033EB0 mov #26,r1
    st8(c.r[2], c.r[1]);  // 06033EB2 mov.b r1,@r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06033EB4 mov.b @r3,r0
    c.r[0] &= 0x1u;  // 06033EB6 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06033EB8 tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_06033EC6; } }  // 06033EBA bt/s 0x06033EC6 ; mov r3,r1
L_06033EBE:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06033EBE mov.b @r1,r0
    c.r[0] &= 0x1u;  // 06033EC0 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06033EC2 tst r0,r0
    if (!c.t) { SH2_POLL(c); goto L_06033EBE; }  // 06033EC4 bf 0x06033EBE
L_06033EC6:
    c.r[1] = ld32(0x06033F34u);  // 06033EC6 mov.l 0x06033F34,r1
    c.r[2] = ld32(c.r[1]);  // 06033EC8 mov.l @r1,r2
    c.r[5] = ld32(0x06033F28u);  // 06033ECA mov.l 0x06033F28,r5
    c.r[1] = ld32(0x06033F18u);  // 06033ECC mov.l 0x06033F18,r1
    c.r[4] = ld32(c.r[1]);  // 06033ECE mov.l @r1,r4
    c.r[7] = 0x0u;  // 06033ED0 mov #0,r7
    c.r[0] = ld32(c.r[2] + 16);  // 06033ED2 mov.l @(16,r2),r0
    { const uint32_t x = c.r[0]; c.pr = 0x06033ED8u; c.r[6] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06033ED8u) return; }  // 06033ED4 jsr @r0 ; mov r12,r6
    c.r[8] = c.r[0];  // 06033ED8 mov r0,r8
    c.r[1] = ld32(0x06033F3Cu);  // 06033EDA mov.l 0x06033F3C,r1
L_06033EDC:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06033EDC mov.b @r1,r0
    c.r[0] &= 0x1u;  // 06033EDE and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06033EE0 tst r0,r0
    if (!c.t) { SH2_POLL(c); goto L_06033EDC; }  // 06033EE2 bf 0x06033EDC
    c.r[1] = 0x1u;  // 06033EE4 mov #1,r1
    c.r[3] = ld32(0x06033F3Cu);  // 06033EE6 mov.l 0x06033F3C,r3
    st8(c.r[3], c.r[1]);  // 06033EE8 mov.b r1,@r3
    c.r[2] = ld32(0x06033F40u);  // 06033EEA mov.l 0x06033F40,r2
    c.r[1] = 0x19u;  // 06033EEC mov #25,r1
    st8(c.r[2], c.r[1]);  // 06033EEE mov.b r1,@r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06033EF0 mov.b @r3,r0
    c.r[0] &= 0x1u;  // 06033EF2 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06033EF4 tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_06033F02; } }  // 06033EF6 bt/s 0x06033F02 ; mov r3,r1
L_06033EFA:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06033EFA mov.b @r1,r0
    c.r[0] &= 0x1u;  // 06033EFC and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06033EFE tst r0,r0
    if (!c.t) { SH2_POLL(c); goto L_06033EFA; }  // 06033F00 bf 0x06033EFA
L_06033F02:
    c.r[15] = c.r[14];  // 06033F02 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06033F04 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06033F06 mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06033F08 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06033F0A mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06033F0C mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06033F0E mov.l @r15+,r9
    c.r[0] = c.r[8];  // 06033F10 mov r8,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06033F12 rts ; mov.l @r15+,r8
}

void f_06033F44(SH2Context& c) {
    ran[756] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06033F44 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06033F46 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06033F48 mov r15,r14
    c.r[4] = c.r[4] & 0xFFu;  // 06033F4A extu.b r4,r4
    c.r[1] = ld32(0x06033FD0u);  // 06033F4C mov.l 0x06033FD0,r1
    c.r[0] = ld32(c.r[1]);  // 06033F4E mov.l @r1,r0
    c.r[2] = ld32(0x06033FD4u);  // 06033F50 mov.l 0x06033FD4,r2
    c.r[0] <<= 2;  // 06033F52 shll2 r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 06033F54 mov.w @(r0,r2),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06033F56 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06033F58 tst r1,r1
    { const bool k = c.t; c.r[7] = 0xFFFFFFFFu; if (k) { goto L_06033FC6; } }  // 06033F5A bt/s 0x06033FC6 ; mov #-1,r7
    c.r[1] = ld32(0x06033FD8u);  // 06033F5E mov.l 0x06033FD8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06033F64u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06033F64u) return; }  // 06033F60 jsr @r1 ; nop
    c.r[1] = ld32(0x06033FDCu);  // 06033F64 mov.l 0x06033FDC,r1
L_06033F66:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06033F66 mov.b @r1,r0
    c.r[0] &= 0x1u;  // 06033F68 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06033F6A tst r0,r0
    if (!c.t) { SH2_POLL(c); goto L_06033F66; }  // 06033F6C bf 0x06033F66
    c.r[1] = 0x1u;  // 06033F6E mov #1,r1
    c.r[3] = ld32(0x06033FDCu);  // 06033F70 mov.l 0x06033FDC,r3
    st8(c.r[3], c.r[1]);  // 06033F72 mov.b r1,@r3
    c.r[2] = ld32(0x06033FE0u);  // 06033F74 mov.l 0x06033FE0,r2
    c.r[1] = 0x1Au;  // 06033F76 mov #26,r1
    st8(c.r[2], c.r[1]);  // 06033F78 mov.b r1,@r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06033F7A mov.b @r3,r0
    c.r[0] &= 0x1u;  // 06033F7C and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06033F7E tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_06033F8C; } }  // 06033F80 bt/s 0x06033F8C ; mov r3,r1
L_06033F84:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06033F84 mov.b @r1,r0
    c.r[0] &= 0x1u;  // 06033F86 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06033F88 tst r0,r0
    if (!c.t) { SH2_POLL(c); goto L_06033F84; }  // 06033F8A bf 0x06033F84
L_06033F8C:
    c.r[1] = ld32(0x06033FE4u);  // 06033F8C mov.l 0x06033FE4,r1
    c.r[2] = ld32(c.r[1]);  // 06033F8E mov.l @r1,r2
    c.r[1] = ld32(0x06033FD0u);  // 06033F90 mov.l 0x06033FD0,r1
    c.r[6] = ld32(0x06033FE8u);  // 06033F92 mov.l 0x06033FE8,r6
    c.r[0] = ld32(c.r[2] + 32);  // 06033F94 mov.l @(32,r2),r0
    c.r[5] = ld32(0x06033FECu);  // 06033F96 mov.l 0x06033FEC,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06033F9Cu; c.r[4] = ld32(c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06033F9Cu) return; }  // 06033F98 jsr @r0 ; mov.l @r1,r4
    c.r[7] = c.r[0];  // 06033F9C mov r0,r7
    c.r[1] = ld32(0x06033FDCu);  // 06033F9E mov.l 0x06033FDC,r1
L_06033FA0:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06033FA0 mov.b @r1,r0
    c.r[0] &= 0x1u;  // 06033FA2 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06033FA4 tst r0,r0
    if (!c.t) { SH2_POLL(c); goto L_06033FA0; }  // 06033FA6 bf 0x06033FA0
    c.r[1] = 0x1u;  // 06033FA8 mov #1,r1
    c.r[3] = ld32(0x06033FDCu);  // 06033FAA mov.l 0x06033FDC,r3
    st8(c.r[3], c.r[1]);  // 06033FAC mov.b r1,@r3
    c.r[2] = ld32(0x06033FE0u);  // 06033FAE mov.l 0x06033FE0,r2
    c.r[1] = 0x19u;  // 06033FB0 mov #25,r1
    st8(c.r[2], c.r[1]);  // 06033FB2 mov.b r1,@r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06033FB4 mov.b @r3,r0
    c.r[0] &= 0x1u;  // 06033FB6 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06033FB8 tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_06033FC6; } }  // 06033FBA bt/s 0x06033FC6 ; mov r3,r1
L_06033FBE:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06033FBE mov.b @r1,r0
    c.r[0] &= 0x1u;  // 06033FC0 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06033FC2 tst r0,r0
    if (!c.t) { SH2_POLL(c); goto L_06033FBE; }  // 06033FC4 bf 0x06033FBE
L_06033FC6:
    c.r[15] = c.r[14];  // 06033FC6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06033FC8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06033FCA mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[7]; c.pc = x; return; }  // 06033FCC rts ; mov r7,r0
}

void f_06034008(SH2Context& c) {
    ran[757] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06034008 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603400A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0603400C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603400E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06034010 sts.l pr,@-r15
    c.r[2] = ld32(0x06034050u);  // 06034012 mov.l 0x06034050,r2
    c.r[1] = 0x0u;  // 06034014 mov #0,r1
    st8(c.r[2], c.r[1]);  // 06034016 mov.b r1,@r2
    c.r[5] = (uint32_t)(int16_t)ld16(0x0603404Eu);  // 06034018 mov.w 0x0603404E,r5
    c.r[4] = ld32(0x06034054u);  // 0603401A mov.l 0x06034054,r4
    c.r[1] = ld32(0x06034058u);  // 0603401C mov.l 0x06034058,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06034022u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06034022u) return; }  // 0603401E jsr @r1 ; mov r15,r14
    c.r[10] = ld32(0x0603405Cu);  // 06034022 mov.l 0x0603405C,r10
    c.r[8] = ld32(0x06034060u);  // 06034024 mov.l 0x06034060,r8
    c.r[5] = c.r[10];  // 06034026 mov r10,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0603402Cu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603402Cu) return; }  // 06034028 jsr @r8 ; mov #1,r4
    c.r[9] = ld32(0x06034064u);  // 0603402C mov.l 0x06034064,r9
    c.r[5] = c.r[9];  // 0603402E mov r9,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06034034u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06034034u) return; }  // 06034030 jsr @r8 ; mov #1,r4
    c.r[5] = c.r[10];  // 06034034 mov r10,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0603403Au; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603403Au) return; }  // 06034036 jsr @r8 ; mov #0,r4
    c.r[5] = c.r[9];  // 0603403A mov r9,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06034040u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06034040u) return; }  // 0603403C jsr @r8 ; mov #0,r4
    c.r[15] = c.r[14];  // 06034040 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06034042 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06034044 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06034046 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06034048 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603404A rts ; mov.l @r15+,r8
}

void f_06034068(SH2Context& c) {
    ran[758] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06034068 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603406A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0603406C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0603406E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06034070 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06034072 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06034074 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06034076 mov r15,r14
    c.r[11] = c.r[4] & 0xFFu;  // 06034078 extu.b r4,r11
    c.r[12] = ld32(0x06034170u);  // 0603407A mov.l 0x06034170,r12
    c.r[1] = ld32(0x06034174u);  // 0603407C mov.l 0x06034174,r1
    c.r[0] = c.r[11];  // 0603407E mov r11,r0
    c.r[0] <<= 2;  // 06034080 shll2 r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06034082 mov.w @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06034084 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06034086 tst r1,r1
    { const bool k = c.t; c.r[8] = 0x0u; if (k) { goto L_0603415A; } }  // 06034088 bt/s 0x0603415A ; mov #0,r8
    c.r[1] = ld32(0x06034178u);  // 0603408C mov.l 0x06034178,r1
L_0603408E:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603408E mov.b @r1,r0
    c.r[0] &= 0x1u;  // 06034090 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06034092 tst r0,r0
    if (!c.t) { SH2_POLL(c); goto L_0603408E; }  // 06034094 bf 0x0603408E
    c.r[1] = 0x1u;  // 06034096 mov #1,r1
    c.r[3] = ld32(0x06034178u);  // 06034098 mov.l 0x06034178,r3
    st8(c.r[3], c.r[1]);  // 0603409A mov.b r1,@r3
    c.r[2] = ld32(0x0603417Cu);  // 0603409C mov.l 0x0603417C,r2
    c.r[1] = 0x1Au;  // 0603409E mov #26,r1
    st8(c.r[2], c.r[1]);  // 060340A0 mov.b r1,@r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060340A2 mov.b @r3,r0
    c.r[0] &= 0x1u;  // 060340A4 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060340A6 tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_060340B4; } }  // 060340A8 bt/s 0x060340B4 ; mov r3,r1
L_060340AC:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060340AC mov.b @r1,r0
    c.r[0] &= 0x1u;  // 060340AE and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060340B0 tst r0,r0
    if (!c.t) { SH2_POLL(c); goto L_060340AC; }  // 060340B2 bf 0x060340AC
L_060340B4:
    c.r[1] = ld32(0x06034180u);  // 060340B4 mov.l 0x06034180,r1
    c.r[7] = c.r[12];  // 060340B6 mov r12,r7
    c.r[1] = ld32(c.r[1]);  // 060340B8 mov.l @r1,r1
    c.r[6] = 0x62u;  // 060340BA mov #98,r6
    c.r[0] = ld32(c.r[1] + 28);  // 060340BC mov.l @(28,r1),r0
    { const uint32_t x = c.r[0]; c.pr = 0x060340C2u; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060340C2u) return; }  // 060340BE jsr @r0 ; mov r11,r4
    c.r[8] = c.r[0];  // 060340C2 mov r0,r8
    c.r[1] = ld32(0x06034178u);  // 060340C4 mov.l 0x06034178,r1
L_060340C6:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060340C6 mov.b @r1,r0
    c.r[0] &= 0x1u;  // 060340C8 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060340CA tst r0,r0
    if (!c.t) { SH2_POLL(c); goto L_060340C6; }  // 060340CC bf 0x060340C6
    c.r[1] = 0x1u;  // 060340CE mov #1,r1
    c.r[3] = ld32(0x06034178u);  // 060340D0 mov.l 0x06034178,r3
    st8(c.r[3], c.r[1]);  // 060340D2 mov.b r1,@r3
    c.r[2] = ld32(0x0603417Cu);  // 060340D4 mov.l 0x0603417C,r2
    c.r[1] = 0x19u;  // 060340D6 mov #25,r1
    st8(c.r[2], c.r[1]);  // 060340D8 mov.b r1,@r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060340DA mov.b @r3,r0
    c.r[0] &= 0x1u;  // 060340DC and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060340DE tst r0,r0
    if (c.t) { goto L_060340EC; }  // 060340E0 bt 0x060340EC
    c.r[1] = c.r[3];  // 060340E2 mov r3,r1
L_060340E4:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060340E4 mov.b @r1,r0
    c.r[0] &= 0x1u;  // 060340E6 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060340E8 tst r0,r0
    if (!c.t) { SH2_POLL(c); goto L_060340E4; }  // 060340EA bf 0x060340E4
L_060340EC:
    c.t = (int32_t)c.r[8] > 0;  // 060340EC cmp/pl r8
    { const bool k = !c.t; c.r[5] = 0x0u; if (k) { goto L_0603415A; } }  // 060340EE bf/s 0x0603415A ; mov #0,r5
    c.t = (int32_t)c.r[5] >= (int32_t)c.r[8];  // 060340F2 cmp/ge r8,r5
    { const bool k = c.t; c.r[6] = c.r[12]; if (k) { goto L_0603415A; } }  // 060340F4 bt/s 0x0603415A ; mov r12,r6
    c.r[9] = ld32(0x06034184u);  // 060340F8 mov.l 0x06034184,r9
    c.r[10] = ld32(0x06034188u);  // 060340FA mov.l 0x06034188,r10
    c.r[4] = 0x0u;  // 060340FC mov #0,r4
L_060340FE:
    c.r[2] = 0x28u;  // 060340FE mov #40,r2
    c.r[0] = c.r[4];  // 06034100 mov r4,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06034102 mov.b @r9,r1
    c.r[4] += 36;  // 06034104 add #36,r4
    c.r[1] = c.r[1] & 0xFFu;  // 06034106 extu.b r1,r1
    c.macl = c.r[1] * c.r[2];  // 06034108 mul.l r2,r1
    c.r[5] += 1;  // 0603410A add #1,r5
    c.t = (int32_t)c.r[5] >= (int32_t)c.r[8];  // 0603410C cmp/ge r8,r5
    c.r[3] = c.macl;  // 0603410E sts macl,r3
    c.r[2] = c.r[3];  // 06034110 mov r3,r2
    c.r[2] += c.r[10];  // 06034112 add r10,r2
    c.r[1] = ld32(c.r[0] + c.r[12]);  // 06034114 mov.l @(r0,r12),r1
    c.r[7] = c.r[2];  // 06034116 mov r2,r7
    c.r[0] = c.r[3];  // 06034118 mov r3,r0
    st32(c.r[0] + c.r[10], c.r[1]);  // 0603411A mov.l r1,@(r0,r10)
    c.r[3] = c.r[6];  // 0603411C mov r6,r3
    c.r[1] = ld32(c.r[6] + 4);  // 0603411E mov.l @(4,r6),r1
    c.r[3] += 8;  // 06034120 add #8,r3
    st32(c.r[2] + 4, c.r[1]);  // 06034122 mov.l r1,@(4,r2)
    c.r[1] = ld32(c.r[3]); c.r[3] += 4;  // 06034124 mov.l @r3+,r1
    c.r[7] += 8;  // 06034126 add #8,r7
    st32(c.r[7], c.r[1]);  // 06034128 mov.l r1,@r7
    c.r[1] = ld32(c.r[3]); c.r[3] += 4;  // 0603412A mov.l @r3+,r1
    c.r[7] += 4;  // 0603412C add #4,r7
    st32(c.r[7], c.r[1]);  // 0603412E mov.l r1,@r7
    c.r[1] = ld32(c.r[3]); c.r[3] += 4;  // 06034130 mov.l @r3+,r1
    c.r[7] += 4;  // 06034132 add #4,r7
    st32(c.r[7], c.r[1]);  // 06034134 mov.l r1,@r7
    c.r[1] = ld32(c.r[3]); c.r[3] += 4;  // 06034136 mov.l @r3+,r1
    c.r[7] += 4;  // 06034138 add #4,r7
    st32(c.r[7], c.r[1]);  // 0603413A mov.l r1,@r7
    c.r[1] = ld32(c.r[3]); c.r[3] += 4;  // 0603413C mov.l @r3+,r1
    c.r[7] += 4;  // 0603413E add #4,r7
    st32(c.r[7], c.r[1]);  // 06034140 mov.l r1,@r7
    c.r[1] = ld32(c.r[3]); c.r[3] += 4;  // 06034142 mov.l @r3+,r1
    c.r[7] += 4;  // 06034144 add #4,r7
    st32(c.r[7], c.r[1]);  // 06034146 mov.l r1,@r7
    c.r[1] = ld32(c.r[3]);  // 06034148 mov.l @r3,r1
    c.r[2] += 36;  // 0603414A add #36,r2
    st32(c.r[7] + 4, c.r[1]);  // 0603414C mov.l r1,@(4,r7)
    st8(c.r[2], c.r[11]);  // 0603414E mov.b r11,@r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06034150 mov.b @r9,r1
    c.r[6] += 36;  // 06034152 add #36,r6
    c.r[1] += 1;  // 06034154 add #1,r1
    { const bool k = !c.t; st8(c.r[9], c.r[1]); if (k) { SH2_POLL(c); goto L_060340FE; } }  // 06034156 bf/s 0x060340FE ; mov.b r1,@r9
L_0603415A:
    c.r[15] = c.r[14];  // 0603415A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603415C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603415E mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06034160 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06034162 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06034164 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06034166 mov.l @r15+,r9
    c.r[0] = c.r[8];  // 06034168 mov r8,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603416A rts ; mov.l @r15+,r8
}

void f_0603418C(SH2Context& c) {
    ran[759] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603418C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603418E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06034190 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06034192 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06034194 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06034196 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06034198 sts.l pr,@-r15
    c.r[1] = ld32(0x06034228u);  // 0603419A mov.l 0x06034228,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603419C mov.b @r1,r1
    c.r[9] = 0x0u;  // 0603419E mov #0,r9
    c.r[1] = c.r[1] & 0xFFu;  // 060341A0 extu.b r1,r1
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[1];  // 060341A2 cmp/ge r1,r9
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06034214; } }  // 060341A4 bt/s 0x06034214 ; mov r15,r14
    c.r[12] = ld32(0x0603422Cu);  // 060341A8 mov.l 0x0603422C,r12
    c.r[11] = ld32(0x06034230u);  // 060341AA mov.l 0x06034230,r11
    c.r[10] = 0x0u;  // 060341AC mov #0,r10
L_060341AE:
    c.r[8] = ld32(0x06034234u);  // 060341AE mov.l 0x06034234,r8
    c.r[8] += c.r[10];  // 060341B0 add r10,r8
    c.r[1] = c.r[8];  // 060341B2 mov r8,r1
    c.r[1] += 36;  // 060341B4 add #36,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060341B6 mov.b @r1,r1
    c.r[2] = ld32(c.r[12]);  // 060341B8 mov.l @r12,r2
    c.r[1] = c.r[1] & 0xFFu;  // 060341BA extu.b r1,r1
    c.t = c.r[2] == c.r[1];  // 060341BC cmp/eq r1,r2
    if (!c.t) { goto L_06034206; }  // 060341BE bf 0x06034206
    c.r[0] = ld32(0x06034238u);  // 060341C0 mov.l 0x06034238,r0
    c.r[4] = ld32(0x0603423Cu);  // 060341C2 mov.l 0x0603423C,r4
    { const uint32_t x = c.r[0]; c.pr = 0x060341C8u; c.r[5] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060341C8u) return; }  // 060341C4 jsr @r0 ; mov r8,r5
    c.t = (c.r[0] & c.r[0]) == 0;  // 060341C8 tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[8]; if (k) { goto L_06034206; } }  // 060341CA bf/s 0x06034206 ; mov r8,r1
    c.r[2] = ld32(c.r[1]); c.r[1] += 4;  // 060341CE mov.l @r1+,r2
    c.r[3] = c.r[11];  // 060341D0 mov r11,r3
    st32(c.r[11], c.r[2]);  // 060341D2 mov.l r2,@r11
    c.r[2] = ld32(c.r[8] + 4);  // 060341D4 mov.l @(4,r8),r2
    c.r[1] += 4;  // 060341D6 add #4,r1
    st32(c.r[11] + 4, c.r[2]);  // 060341D8 mov.l r2,@(4,r11)
    c.r[2] = ld32(c.r[1]); c.r[1] += 4;  // 060341DA mov.l @r1+,r2
    c.r[3] += 8;  // 060341DC add #8,r3
    st32(c.r[3], c.r[2]);  // 060341DE mov.l r2,@r3
    c.r[2] = ld32(c.r[1]); c.r[1] += 4;  // 060341E0 mov.l @r1+,r2
    c.r[3] += 4;  // 060341E2 add #4,r3
    st32(c.r[3], c.r[2]);  // 060341E4 mov.l r2,@r3
    c.r[2] = ld32(c.r[1]); c.r[1] += 4;  // 060341E6 mov.l @r1+,r2
    c.r[3] += 4;  // 060341E8 add #4,r3
    st32(c.r[3], c.r[2]);  // 060341EA mov.l r2,@r3
    c.r[2] = ld32(c.r[1]); c.r[1] += 4;  // 060341EC mov.l @r1+,r2
    c.r[3] += 4;  // 060341EE add #4,r3
    st32(c.r[3], c.r[2]);  // 060341F0 mov.l r2,@r3
    c.r[2] = ld32(c.r[1]); c.r[1] += 4;  // 060341F2 mov.l @r1+,r2
    c.r[3] += 4;  // 060341F4 add #4,r3
    st32(c.r[3], c.r[2]);  // 060341F6 mov.l r2,@r3
    c.r[2] = ld32(c.r[1]); c.r[1] += 4;  // 060341F8 mov.l @r1+,r2
    c.r[3] += 4;  // 060341FA add #4,r3
    st32(c.r[3], c.r[2]);  // 060341FC mov.l r2,@r3
    c.r[1] = ld32(c.r[1]);  // 060341FE mov.l @r1,r1
    c.r[0] = 0x1u;  // 06034200 mov #1,r0
    st32(c.r[3] + 4, c.r[1]); goto L_06034216;  // 06034202 bra 0x06034216 ; mov.l r1,@(4,r3)
L_06034206:
    c.r[1] = ld32(0x06034228u);  // 06034206 mov.l 0x06034228,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06034208 mov.b @r1,r1
    c.r[9] += 1;  // 0603420A add #1,r9
    c.r[1] = c.r[1] & 0xFFu;  // 0603420C extu.b r1,r1
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[1];  // 0603420E cmp/ge r1,r9
    { const bool k = !c.t; c.r[10] += 40; if (k) { SH2_POLL(c); goto L_060341AE; } }  // 06034210 bf/s 0x060341AE ; add #40,r10
L_06034214:
    c.r[0] = 0x0u;  // 06034214 mov #0,r0
L_06034216:
    c.r[15] = c.r[14];  // 06034216 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06034218 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603421A mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0603421C mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0603421E mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06034220 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06034222 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06034224 rts ; mov.l @r15+,r8
}

void f_06034240(SH2Context& c) {
    ran[760] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06034240 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06034242 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06034244 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06034246 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06034248 mov r15,r14
    c.r[8] = ld32(0x06034320u);  // 0603424A mov.l 0x06034320,r8
    c.r[5] = 0x0u;  // 0603424C mov #0,r5
L_0603424E:
    { const uint32_t x = c.r[8]; c.pr = 0x06034252u; c.r[4] = 0xDu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06034252u) return; }  // 0603424E jsr @r8 ; mov #13,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 06034252 tst r0,r0
    { const bool k = !c.t; c.r[5] = 0x0u; if (k) { SH2_POLL(c); goto L_0603424E; } }  // 06034254 bf/s 0x0603424E ; mov #0,r5
    c.r[1] = ld32(0x06034324u);  // 06034258 mov.l 0x06034324,r1
    c.r[7] = ld32(0x06034328u);  // 0603425A mov.l 0x06034328,r7
    c.r[9] = 0xFu;  // 0603425C mov #15,r9
    c.r[3] = ld32(c.r[1]);  // 0603425E mov.l @r1,r3
    c.r[15] = c.r[14];  // 06034260 mov r14,r15
    c.r[4] = c.r[3];  // 06034262 mov r3,r4
    c.r[4] += 4;  // 06034264 add #4,r4
    c.r[5] = c.r[3];  // 06034266 mov r3,r5
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[4]);  // 06034268 mov.w @r4,r1
    c.r[5] += 6;  // 0603426A add #6,r5
    c.r[6] = c.r[1] & 0xFFFFu;  // 0603426C extu.w r1,r6
    c.r[2] = c.r[6];  // 0603426E mov r6,r2
    c.r[2] >>= 8;  // 06034270 shlr8 r2
    c.r[2] >>= 2;  // 06034272 shlr2 r2
    c.r[2] >>= 2;  // 06034274 shlr2 r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603431Cu);  // 06034276 mov.w 0x0603431C,r1
    c.r[0] = c.r[6];  // 06034278 mov r6,r0
    c.r[0] >>= 8;  // 0603427A shlr8 r0
    c.r[0] &= 0xFu;  // 0603427C and #15,r0
    c.macl = (c.r[2] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 0603427E mulu.w r1,r2
    c.r[6] >>= 2;  // 06034280 shlr2 r6
    c.r[6] >>= 2;  // 06034282 shlr2 r6
    c.r[2] = c.macl;  // 06034284 sts macl,r2
    c.r[1] = 0x64u;  // 06034286 mov #100,r1
    c.macl = (c.r[0] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 06034288 mulu.w r1,r0
    c.r[6] &= c.r[9];  // 0603428A and r9,r6
    c.r[1] = c.macl;  // 0603428C sts macl,r1
    c.r[2] += c.r[1];  // 0603428E add r1,r2
    c.r[1] = 0xAu;  // 06034290 mov #10,r1
    c.macl = (c.r[6] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 06034292 mulu.w r1,r6
    c.r[4] += 4;  // 06034294 add #4,r4
    c.r[1] = c.macl;  // 06034296 sts macl,r1
    c.r[2] += c.r[1];  // 06034298 add r1,r2
    c.r[1] = c.r[3];  // 0603429A mov r3,r1
    c.r[1] += 5;  // 0603429C add #5,r1
    c.r[6] = c.r[7];  // 0603429E mov r7,r6
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060342A0 mov.b @r1,r0
    c.r[6] += 2;  // 060342A2 add #2,r6
    c.r[0] &= 0xFu;  // 060342A4 and #15,r0
    c.r[2] += c.r[0];  // 060342A6 add r0,r2
    c.r[2] += 68;  // 060342A8 add #68,r2
    st8(c.r[7], c.r[2]);  // 060342AA mov.b r2,@r7
    c.r[1] = c.r[7];  // 060342AC mov r7,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[5]);  // 060342AE mov.b @r5,r0
    c.r[1] += 1;  // 060342B0 add #1,r1
    c.r[0] &= 0xFu;  // 060342B2 and #15,r0
    st8(c.r[1], c.r[0]);  // 060342B4 mov.b r0,@r1
    c.r[1] = c.r[3];  // 060342B6 mov r3,r1
    c.r[1] += 7;  // 060342B8 add #7,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060342BA mov.b @r1,r0
    c.r[3] += 9;  // 060342BC add #9,r3
    c.r[1] = c.r[0] & 0xFFu;  // 060342BE extu.b r0,r1
    c.r[1] >>= 2;  // 060342C0 shlr2 r1
    c.r[1] >>= 2;  // 060342C2 shlr2 r1
    c.r[2] = c.r[1];  // 060342C4 mov r1,r2
    c.r[2] <<= 2;  // 060342C6 shll2 r2
    c.r[2] += c.r[1];  // 060342C8 add r1,r2
    c.r[2] += c.r[2];  // 060342CA add r2,r2
    c.r[0] &= 0xFu;  // 060342CC and #15,r0
    c.r[2] += c.r[0];  // 060342CE add r0,r2
    st8(c.r[6], c.r[2]);  // 060342D0 mov.b r2,@r6
    c.r[6] = c.r[7];  // 060342D2 mov r7,r6
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4]);  // 060342D4 mov.b @r4,r0
    c.r[6] += 3;  // 060342D6 add #3,r6
    c.r[1] = c.r[0] & 0xFFu;  // 060342D8 extu.b r0,r1
    c.r[1] >>= 2;  // 060342DA shlr2 r1
    c.r[1] >>= 2;  // 060342DC shlr2 r1
    c.r[2] = c.r[1];  // 060342DE mov r1,r2
    c.r[2] <<= 2;  // 060342E0 shll2 r2
    c.r[2] += c.r[1];  // 060342E2 add r1,r2
    c.r[2] += c.r[2];  // 060342E4 add r2,r2
    c.r[0] &= 0xFu;  // 060342E6 and #15,r0
    c.r[2] += c.r[0];  // 060342E8 add r0,r2
    st8(c.r[6], c.r[2]);  // 060342EA mov.b r2,@r6
    c.r[6] = c.r[7];  // 060342EC mov r7,r6
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060342EE mov.b @r3,r0
    c.r[6] += 4;  // 060342F0 add #4,r6
    c.r[1] = c.r[0] & 0xFFu;  // 060342F2 extu.b r0,r1
    c.r[1] >>= 2;  // 060342F4 shlr2 r1
    c.r[1] >>= 2;  // 060342F6 shlr2 r1
    c.r[2] = c.r[1];  // 060342F8 mov r1,r2
    c.r[2] <<= 2;  // 060342FA shll2 r2
    c.r[2] += c.r[1];  // 060342FC add r1,r2
    c.r[2] += c.r[2];  // 060342FE add r2,r2
    c.r[0] &= 0xFu;  // 06034300 and #15,r0
    c.r[2] += c.r[0];  // 06034302 add r0,r2
    st8(c.r[6], c.r[2]);  // 06034304 mov.b r2,@r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[5]);  // 06034306 mov.b @r5,r1
    c.r[7] += 5;  // 06034308 add #5,r7
    c.r[1] = c.r[1] & 0xFFu;  // 0603430A extu.b r1,r1
    c.r[1] >>= 2;  // 0603430C shlr2 r1
    c.r[1] >>= 2;  // 0603430E shlr2 r1
    st8(c.r[7], c.r[1]);  // 06034310 mov.b r1,@r7
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06034312 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06034314 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06034316 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06034318 rts ; mov.l @r15+,r8
}

void f_0603432C(SH2Context& c) {
    ran[761] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603432C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603432E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06034330 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06034332 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06034334 mov r15,r14
    c.r[4] = c.r[4] & 0xFFu;  // 06034336 extu.b r4,r4
    c.r[8] = c.r[4];  // 06034338 mov r4,r8
    c.r[1] = 0x62u;  // 0603433A mov #98,r1
    c.t = c.r[8] > c.r[1];  // 0603433C cmp/hi r1,r8
    { const bool k = c.t; c.r[9] = c.r[6]; if (k) { goto L_06034352; } }  // 0603433E bt/s 0x06034352 ; mov r6,r9
    c.r[1] = ld32(0x0603436Cu);  // 06034342 mov.l 0x0603436C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06034348u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06034348u) return; }  // 06034344 jsr @r1 ; mov r8,r4
    c.r[0] = ld32(0x06034370u);  // 06034348 mov.l 0x06034370,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0603434Eu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603434Eu) return; }  // 0603434A jsr @r0 ; mov r8,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603434E tst r0,r0
    if (!c.t) { goto L_06034356; }  // 06034350 bf 0x06034356
L_06034352:
    c.r[0] = 0xFFFFFFFFu; goto L_0603435E;  // 06034352 bra 0x0603435E ; mov #-1,r0
L_06034356:
    c.r[1] = ld32(0x06034374u);  // 06034356 mov.l 0x06034374,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603435Cu; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603435Cu) return; }  // 06034358 jsr @r1 ; mov r9,r4
    c.r[0] = 0x0u;  // 0603435C mov #0,r0
L_0603435E:
    c.r[15] = c.r[14];  // 0603435E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06034360 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06034362 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06034364 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06034366 rts ; mov.l @r15+,r8
}

void f_06034378(SH2Context& c) {
    ran[762] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06034378 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603437A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603437C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603437E sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06034380 mov r15,r14
    c.r[9] = c.r[4];  // 06034382 mov r4,r9
    c.r[8] = ld32(0x06034454u);  // 06034384 mov.l 0x06034454,r8
    c.r[5] = 0x0u;  // 06034386 mov #0,r5
L_06034388:
    { const uint32_t x = c.r[8]; c.pr = 0x0603438Cu; c.r[4] = 0xDu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603438Cu) return; }  // 06034388 jsr @r8 ; mov #13,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603438C tst r0,r0
    { const bool k = !c.t; c.r[5] = 0x0u; if (k) { SH2_POLL(c); goto L_06034388; } }  // 0603438E bf/s 0x06034388 ; mov #0,r5
    c.t = (c.r[9] & c.r[9]) == 0;  // 06034392 tst r9,r9
    if (c.t) { goto L_060343BE; }  // 06034394 bt 0x060343BE
    c.r[1] = ld32(0x06034458u);  // 06034396 mov.l 0x06034458,r1
L_06034398:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06034398 mov.b @r1,r0
    c.r[0] &= 0x1u;  // 0603439A and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603439C tst r0,r0
    if (!c.t) { SH2_POLL(c); goto L_06034398; }  // 0603439E bf 0x06034398
    c.r[1] = 0x1u;  // 060343A0 mov #1,r1
    c.r[3] = ld32(0x06034458u);  // 060343A2 mov.l 0x06034458,r3
    st8(c.r[3], c.r[1]);  // 060343A4 mov.b r1,@r3
    c.r[2] = ld32(0x0603445Cu);  // 060343A6 mov.l 0x0603445C,r2
    c.r[1] = 0x1Au;  // 060343A8 mov #26,r1
    st8(c.r[2], c.r[1]);  // 060343AA mov.b r1,@r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060343AC mov.b @r3,r0
    c.r[0] &= 0x1u;  // 060343AE and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060343B0 tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_060343BE; } }  // 060343B2 bt/s 0x060343BE ; mov r3,r1
L_060343B6:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060343B6 mov.b @r1,r0
    c.r[0] &= 0x1u;  // 060343B8 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060343BA tst r0,r0
    if (!c.t) { SH2_POLL(c); goto L_060343B6; }  // 060343BC bf 0x060343B6
L_060343BE:
    c.r[1] = ld32(0x06034460u);  // 060343BE mov.l 0x06034460,r1
    c.r[2] = ld32(c.r[1]);  // 060343C0 mov.l @r1,r2
    c.r[1] = ld32(0x06034464u);  // 060343C2 mov.l 0x06034464,r1
    c.r[4] = ld32(c.r[1] + 24);  // 060343C4 mov.l @(24,r1),r4
    c.r[1] = ld32(c.r[2] + 36);  // 060343C6 mov.l @(36,r2),r1
    c.r[5] = ld32(0x06034468u);  // 060343C8 mov.l 0x06034468,r5
    { const uint32_t x = c.r[1]; c.pr = 0x060343CEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060343CEu) return; }  // 060343CA jsr @r1 ; nop
    c.t = (c.r[9] & c.r[9]) == 0;  // 060343CE tst r9,r9
    if (c.t) { goto L_060343FA; }  // 060343D0 bt 0x060343FA
    c.r[1] = ld32(0x06034458u);  // 060343D2 mov.l 0x06034458,r1
L_060343D4:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060343D4 mov.b @r1,r0
    c.r[0] &= 0x1u;  // 060343D6 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060343D8 tst r0,r0
    if (!c.t) { SH2_POLL(c); goto L_060343D4; }  // 060343DA bf 0x060343D4
    c.r[1] = 0x1u;  // 060343DC mov #1,r1
    c.r[3] = ld32(0x06034458u);  // 060343DE mov.l 0x06034458,r3
    st8(c.r[3], c.r[1]);  // 060343E0 mov.b r1,@r3
    c.r[2] = ld32(0x0603445Cu);  // 060343E2 mov.l 0x0603445C,r2
    c.r[1] = 0x19u;  // 060343E4 mov #25,r1
    st8(c.r[2], c.r[1]);  // 060343E6 mov.b r1,@r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060343E8 mov.b @r3,r0
    c.r[0] &= 0x1u;  // 060343EA and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060343EC tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_060343FA; } }  // 060343EE bt/s 0x060343FA ; mov r3,r1
L_060343F2:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060343F2 mov.b @r1,r0
    c.r[0] &= 0x1u;  // 060343F4 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060343F6 tst r0,r0
    if (!c.t) { SH2_POLL(c); goto L_060343F2; }  // 060343F8 bf 0x060343F2
L_060343FA:
    c.r[5] = ld32(0x0603446Cu);  // 060343FA mov.l 0x0603446C,r5
    c.r[6] = ld32(0x06034470u);  // 060343FC mov.l 0x06034470,r6
    c.r[7] = c.r[6];  // 060343FE mov r6,r7
    c.r[3] = ld32(0x06034468u);  // 06034400 mov.l 0x06034468,r3
    c.r[1] = c.r[3];  // 06034402 mov r3,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 06034404 mov.b @r1+,r2
    c.r[7] += 108;  // 06034406 add #108,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06034408 mov.b @r1,r1
    c.r[2] <<= 16;  // 0603440A shll16 r2
    c.r[2] <<= 8;  // 0603440C shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603440E extu.b r1,r1
    c.r[1] <<= 16;  // 06034410 shll16 r1
    c.r[2] += c.r[1];  // 06034412 add r1,r2
    c.r[1] = c.r[3];  // 06034414 mov r3,r1
    c.r[1] += 2;  // 06034416 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06034418 mov.b @r1,r1
    c.r[6] += 112;  // 0603441A add #112,r6
    c.r[1] = c.r[1] & 0xFFu;  // 0603441C extu.b r1,r1
    c.r[1] <<= 8;  // 0603441E shll8 r1
    c.r[2] += c.r[1];  // 06034420 add r1,r2
    c.r[1] = c.r[3];  // 06034422 mov r3,r1
    c.r[1] += 5;  // 06034424 add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06034426 mov.b @r1,r1
    c.r[15] = c.r[14];  // 06034428 mov r14,r15
    c.r[1] = c.r[1] & 0xFFu;  // 0603442A extu.b r1,r1
    c.r[2] += c.r[1];  // 0603442C add r1,r2
    st32(c.r[7], c.r[2]);  // 0603442E mov.l r2,@r7
    st32(c.r[5], c.r[2]);  // 06034430 mov.l r2,@r5
    c.r[1] = c.r[3];  // 06034432 mov r3,r1
    c.r[1] += 3;  // 06034434 add #3,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06034436 mov.b @r1,r2
    c.r[3] += 4;  // 06034438 add #4,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0603443A extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0603443C mov.b @r3,r1
    c.r[2] <<= 8;  // 0603443E shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06034440 extu.b r1,r1
    c.r[2] += c.r[1];  // 06034442 add r1,r2
    st32(c.r[6], c.r[2]);  // 06034444 mov.l r2,@r6
    st32(c.r[5] + 4, c.r[2]);  // 06034446 mov.l r2,@(4,r5)
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06034448 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603444A mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0603444C mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603444E rts ; mov.l @r15+,r8
}

void f_06034484(SH2Context& c) {
    ran[763] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06034484 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06034486 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06034488 mov r15,r14
    c.r[6] = c.r[4] & 0xFFu;  // 0603448A extu.b r4,r6
    c.t = (c.r[5] & c.r[5]) == 0;  // 0603448C tst r5,r5
    { const bool k = !c.t; c.r[1] = c.r[6]; if (k) { goto L_0603449C; } }  // 0603448E bf/s 0x0603449C ; mov r6,r1
    c.r[5] = ld32(0x060344B0u);  // 06034492 mov.l 0x060344B0,r5
    c.r[4] = ld32(0x060344B4u);  // 06034494 mov.l 0x060344B4,r4
    c.r[0] = ld32(0x060344B8u);  // 06034496 mov.l 0x060344B8,r0
    goto L_060344A4;  // 06034498 bra 0x060344A4 ; nop
L_0603449C:
    c.r[5] = ld32(0x060344BCu);  // 0603449C mov.l 0x060344BC,r5
    c.r[4] = ld32(0x060344B4u);  // 0603449E mov.l 0x060344B4,r4
    c.r[0] = ld32(0x060344B8u);  // 060344A0 mov.l 0x060344B8,r0
    c.r[6] = c.r[1];  // 060344A2 mov r1,r6
L_060344A4:
    { const uint32_t x = c.r[0]; c.pr = 0x060344A8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060344A8u) return; }  // 060344A4 jsr @r0 ; nop
    c.r[15] = c.r[14];  // 060344A8 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060344AA lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060344AC rts ; mov.l @r15+,r14
}

void f_060344C0(SH2Context& c) {
    ran[764] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060344C0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060344C2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060344C4 sts.l pr,@-r15
    c.r[8] = c.r[4] & 0xFFu;  // 060344C6 extu.b r4,r8
    c.r[1] = 0x62u;  // 060344C8 mov #98,r1
    c.t = c.r[8] > c.r[1];  // 060344CA cmp/hi r1,r8
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06034506; } }  // 060344CC bt/s 0x06034506 ; mov r15,r14
    c.t = (c.r[5] & c.r[5]) == 0;  // 060344D0 tst r5,r5
    { const bool k = !c.t; c.r[6] = c.r[8]; if (k) { goto L_060344DE; } }  // 060344D2 bf/s 0x060344DE ; mov r8,r6
    c.r[0] = ld32(0x06034514u);  // 060344D6 mov.l 0x06034514,r0
    c.r[5] = ld32(0x06034518u);  // 060344D8 mov.l 0x06034518,r5
    goto L_060344E2;  // 060344DA bra 0x060344E2 ; nop
L_060344DE:
    c.r[0] = ld32(0x06034514u);  // 060344DE mov.l 0x06034514,r0
    c.r[5] = ld32(0x0603451Cu);  // 060344E0 mov.l 0x0603451C,r5
L_060344E2:
    c.r[4] = ld32(0x06034520u);  // 060344E2 mov.l 0x06034520,r4
    { const uint32_t x = c.r[0]; c.pr = 0x060344E8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060344E8u) return; }  // 060344E4 jsr @r0 ; nop
    c.r[0] = ld32(0x06034524u);  // 060344E8 mov.l 0x06034524,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060344EEu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060344EEu) return; }  // 060344EA jsr @r0 ; mov r8,r4
    c.t = (int32_t)c.r[0] > 0;  // 060344EE cmp/pl r0
    { const bool k = !c.t; c.t = (int32_t)c.r[0] >= 0; if (k) { goto L_06034502; } }  // 060344F0 bf/s 0x06034502 ; cmp/pz r0
    c.r[5] = ld32(0x06034520u);  // 060344F4 mov.l 0x06034520,r5
    c.r[4] = ld32(0x06034528u);  // 060344F6 mov.l 0x06034528,r4
    c.r[0] = ld32(0x0603452Cu);  // 060344F8 mov.l 0x0603452C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060344FEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060344FEu) return; }  // 060344FA jsr @r0 ; nop
    c.r[15] = c.r[14]; goto L_0603450A;  // 060344FE bra 0x0603450A ; mov r14,r15
L_06034502:
    { const bool k = !c.t; c.r[0] = 0xFFFFFFFEu; if (k) { goto L_06034508; } }  // 06034502 bf/s 0x06034508 ; mov #-2,r0
L_06034506:
    c.r[0] = 0xFFFFFFFFu;  // 06034506 mov #-1,r0
L_06034508:
    c.r[15] = c.r[14];  // 06034508 mov r14,r15
L_0603450A:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603450A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603450C mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603450E rts ; mov.l @r15+,r8
}

void f_06034530(SH2Context& c) {
    ran[765] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06034530 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06034532 mov r15,r14
    c.r[0] = 0x4u;  // 06034534 mov #4,r0
    c.r[5] -= 4;  // 06034536 add #-4,r5
    c.t = c.r[0] >= c.r[5];  // 06034538 cmp/hs r5,r0
    { const bool k = c.t; c.r[2] = 0x0u; if (k) { goto L_0603454A; } }  // 0603453A bt/s 0x0603454A ; mov #0,r2
L_0603453E:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[4]);  // 0603453E mov.b @(r0,r4),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06034540 extu.b r1,r1
    c.r[0] += 1;  // 06034542 add #1,r0
    c.t = c.r[0] >= c.r[5];  // 06034544 cmp/hs r5,r0
    { const bool k = !c.t; c.r[2] += c.r[1]; if (k) { SH2_POLL(c); goto L_0603453E; } }  // 06034546 bf/s 0x0603453E ; add r1,r2
L_0603454A:
    c.r[15] = c.r[14];  // 0603454A mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603454C mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[2]; c.pc = x; return; }  // 0603454E rts ; mov r2,r0
}

void f_06034554(SH2Context& c) {
    ran[766] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06034554 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06034556 sts.l pr,@-r15
    c.r[1] = ld32(0x06034578u);  // 06034558 mov.l 0x06034578,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603455Eu; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603455Eu) return; }  // 0603455A jsr @r1 ; mov r15,r14
    c.r[4] = ld32(0x0603457Cu);  // 0603455E mov.l 0x0603457C,r4
    c.r[1] = ld32(0x06034580u);  // 06034560 mov.l 0x06034580,r1
    c.r[5] = ld32(c.r[1]);  // 06034562 mov.l @r1,r5
    c.r[6] = (uint32_t)(int16_t)ld16(0x06034574u);  // 06034564 mov.w 0x06034574,r6
    c.r[1] = ld32(0x06034584u);  // 06034566 mov.l 0x06034584,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603456Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603456Cu) return; }  // 06034568 jsr @r1 ; nop
    c.r[15] = c.r[14];  // 0603456C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603456E lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06034570 rts ; mov.l @r15+,r14
}

void f_06034588(SH2Context& c) {
    ran[767] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06034588 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603458A sts.l pr,@-r15
    c.r[1] = ld32(0x060345ACu);  // 0603458C mov.l 0x060345AC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06034592u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06034592u) return; }  // 0603458E jsr @r1 ; mov r15,r14
    c.r[1] = ld32(0x060345B0u);  // 06034592 mov.l 0x060345B0,r1
    c.r[5] = ld32(0x060345B4u);  // 06034594 mov.l 0x060345B4,r5
    c.r[4] = ld32(c.r[1]);  // 06034596 mov.l @r1,r4
    c.r[6] = (uint32_t)(int16_t)ld16(0x060345A8u);  // 06034598 mov.w 0x060345A8,r6
    c.r[1] = ld32(0x060345B8u);  // 0603459A mov.l 0x060345B8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060345A0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060345A0u) return; }  // 0603459C jsr @r1 ; nop
    c.r[15] = c.r[14];  // 060345A0 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060345A2 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060345A4 rts ; mov.l @r15+,r14
}

void f_060345BC(SH2Context& c) {
    ran[768] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060345BC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060345BE mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060345C0 sts.l pr,@-r15
    c.r[1] = ld32(0x06034604u);  // 060345C2 mov.l 0x06034604,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060345C8u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060345C8u) return; }  // 060345C4 jsr @r1 ; mov r15,r14
    c.r[1] = ld32(0x06034608u);  // 060345C8 mov.l 0x06034608,r1
    c.r[6] = (uint32_t)(int16_t)ld16(0x060345FEu);  // 060345CA mov.w 0x060345FE,r6
    c.r[5] = ld32(c.r[1]);  // 060345CC mov.l @r1,r5
    c.r[4] = ld32(0x0603460Cu);  // 060345CE mov.l 0x0603460C,r4
    c.r[1] = ld32(0x06034610u);  // 060345D0 mov.l 0x06034610,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060345D6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060345D6u) return; }  // 060345D2 jsr @r1 ; nop
    c.r[4] = ld32(0x06034614u);  // 060345D6 mov.l 0x06034614,r4
    c.r[1] = ld32(0x06034618u);  // 060345D8 mov.l 0x06034618,r1
    c.r[8] = ld32(0x0603461Cu);  // 060345DA mov.l 0x0603461C,r8
    c.r[6] = (uint32_t)(int16_t)ld16(0x06034600u);  // 060345DC mov.w 0x06034600,r6
    { const uint32_t x = c.r[8]; c.pr = 0x060345E2u; c.r[5] = ld32(c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060345E2u) return; }  // 060345DE jsr @r8 ; mov.l @r1,r5
    c.r[1] = ld32(0x06034620u);  // 060345E2 mov.l 0x06034620,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060345E8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060345E8u) return; }  // 060345E4 jsr @r1 ; nop
    c.r[4] = ld32(0x06034624u);  // 060345E8 mov.l 0x06034624,r4
    c.r[1] = ld32(0x06034628u);  // 060345EA mov.l 0x06034628,r1
    c.r[6] = (uint32_t)(int16_t)ld16(0x06034600u);  // 060345EC mov.w 0x06034600,r6
    c.r[5] = ld32(c.r[1]);  // 060345EE mov.l @r1,r5
    c.r[15] = c.r[14];  // 060345F0 mov r14,r15
    { const uint32_t x = c.r[8]; c.pr = 0x060345F6u; c.r[5] += 40; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060345F6u) return; }  // 060345F2 jsr @r8 ; add #40,r5
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060345F6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060345F8 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060345FA rts ; mov.l @r15+,r8
}

void f_0603462C(SH2Context& c) {
    ran[769] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603462C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603462E sts.l pr,@-r15
    c.r[1] = ld32(0x06034670u);  // 06034630 mov.l 0x06034670,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06034636u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06034636u) return; }  // 06034632 jsr @r1 ; mov r15,r14
    c.r[1] = ld32(0x06034674u);  // 06034636 mov.l 0x06034674,r1
    c.r[6] = (uint32_t)(int16_t)ld16(0x0603466Au);  // 06034638 mov.w 0x0603466A,r6
    c.r[4] = ld32(c.r[1]);  // 0603463A mov.l @r1,r4
    c.r[5] = ld32(0x06034678u);  // 0603463C mov.l 0x06034678,r5
    c.r[1] = ld32(0x0603467Cu);  // 0603463E mov.l 0x0603467C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06034644u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06034644u) return; }  // 06034640 jsr @r1 ; nop
    c.r[1] = ld32(0x06034680u);  // 06034644 mov.l 0x06034680,r1
    c.r[5] = ld32(0x06034684u);  // 06034646 mov.l 0x06034684,r5
    c.r[2] = ld32(0x06034688u);  // 06034648 mov.l 0x06034688,r2
    c.r[6] = (uint32_t)(int16_t)ld16(0x0603466Cu);  // 0603464A mov.w 0x0603466C,r6
    { const uint32_t x = c.r[2]; c.pr = 0x06034650u; c.r[4] = ld32(c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06034650u) return; }  // 0603464C jsr @r2 ; mov.l @r1,r4
    c.r[1] = ld32(0x0603468Cu);  // 06034650 mov.l 0x0603468C,r1
    c.r[5] = ld32(0x06034690u);  // 06034652 mov.l 0x06034690,r5
    c.r[4] = ld32(c.r[1]);  // 06034654 mov.l @r1,r4
    c.r[6] = (uint32_t)(int16_t)ld16(0x0603466Cu);  // 06034656 mov.w 0x0603466C,r6
    { const uint32_t x = c.r[2]; c.pr = 0x0603465Cu; c.r[4] += 40; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603465Cu) return; }  // 06034658 jsr @r2 ; add #40,r4
    c.r[1] = ld32(0x06034694u);  // 0603465C mov.l 0x06034694,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06034662u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06034662u) return; }  // 0603465E jsr @r1 ; nop
    c.r[15] = c.r[14];  // 06034662 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06034664 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06034666 rts ; mov.l @r15+,r14
}

void f_06034698(SH2Context& c) {
    ran[770] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06034698 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603469A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0603469C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0603469E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060346A0 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060346A2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060346A4 sts.l pr,@-r15
    c.r[1] = ld32(0x060348B0u);  // 060346A6 mov.l 0x060348B0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060346ACu; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060346ACu) return; }  // 060346A8 jsr @r1 ; mov r15,r14
    c.r[5] = (uint32_t)(int16_t)ld16(0x06034884u);  // 060346AC mov.w 0x06034884,r5
    c.r[8] = ld32(0x060348B4u);  // 060346AE mov.l 0x060348B4,r8
    c.r[1] = ld32(0x060348B8u);  // 060346B0 mov.l 0x060348B8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060346B6u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060346B6u) return; }  // 060346B2 jsr @r1 ; mov r8,r4
    c.r[3] = (uint32_t)(int16_t)ld16(0x06034886u);  // 060346B6 mov.w 0x06034886,r3
    c.r[1] = ld32(0x060348BCu);  // 060346B8 mov.l 0x060348BC,r1
    c.r[7] = 0x0u;  // 060346BA mov #0,r7
    c.r[2] = ld32(c.r[1]);  // 060346BC mov.l @r1,r2
    c.r[6] = 0x2u;  // 060346BE mov #2,r6
    c.r[1] = (uint32_t)(int16_t)ld16(0x06034888u);  // 060346C0 mov.w 0x06034888,r1
    c.r[0] = c.r[2];  // 060346C2 mov r2,r0
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 060346C4 mov.l @(r0,r1),r1
    c.r[5] = (uint32_t)(int16_t)ld16(0x0603488Au);  // 060346C6 mov.w 0x0603488A,r5
    c.r[0] = c.r[8];  // 060346C8 mov r8,r0
    st32(c.r[0] + c.r[3], c.r[1]);  // 060346CA mov.l r1,@(r0,r3)
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603488Cu);  // 060346CC mov.w 0x0603488C,r1
    c.r[0] = c.r[2];  // 060346CE mov r2,r0
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 060346D0 mov.l @(r0,r1),r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x0603488Eu);  // 060346D2 mov.w 0x0603488E,r3
    c.r[0] = c.r[8];  // 060346D4 mov r8,r0
    st32(c.r[0] + c.r[3], c.r[1]);  // 060346D6 mov.l r1,@(r0,r3)
    c.r[3] = (uint32_t)(int16_t)ld16(0x06034890u);  // 060346D8 mov.w 0x06034890,r3
L_060346DA:
    c.r[0] = c.r[2];  // 060346DA mov r2,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[5]);  // 060346DC mov.w @(r0,r5),r1
    c.r[2] += 2;  // 060346DE add #2,r2
    c.r[7] += 1;  // 060346E0 add #1,r7
    c.t = (int32_t)c.r[7] > (int32_t)c.r[6];  // 060346E2 cmp/gt r6,r7
    c.r[0] = c.r[8];  // 060346E4 mov r8,r0
    st16(c.r[0] + c.r[3], c.r[1]);  // 060346E6 mov.w r1,@(r0,r3)
    { const bool k = !c.t; c.r[8] += 2; if (k) { SH2_POLL(c); goto L_060346DA; } }  // 060346E8 bf/s 0x060346DA ; add #2,r8
    c.r[2] = ld32(0x060348B4u);  // 060346EC mov.l 0x060348B4,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06034892u);  // 060346EE mov.w 0x06034892,r0
    c.r[3] = ld32(0x060348BCu);  // 060346F0 mov.l 0x060348BC,r3
    c.r[7] = 0x0u;  // 060346F2 mov #0,r7
    c.r[4] = 0x3Fu;  // 060346F4 mov #63,r4
    c.r[1] = ld32(c.r[3]);  // 060346F6 mov.l @r3,r1
    c.r[5] = (uint32_t)(int16_t)ld16(0x06034894u);  // 060346F8 mov.w 0x06034894,r5
    c.r[1] += 14;  // 060346FA add #14,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060346FC mov.w @r1,r1
    c.r[6] = (uint32_t)(int16_t)ld16(0x06034896u);  // 060346FE mov.w 0x06034896,r6
    st16(c.r[0] + c.r[2], c.r[1]);  // 06034700 mov.w r1,@(r0,r2)
L_06034702:
    c.r[8] = c.r[7];  // 06034702 mov r7,r8
    c.r[1] = ld32(c.r[3]);  // 06034704 mov.l @r3,r1
    c.r[8] += c.r[2];  // 06034706 add r2,r8
    c.r[1] += c.r[7];  // 06034708 add r7,r1
    c.r[0] = c.r[1];  // 0603470A mov r1,r0
    c.r[7] += 1;  // 0603470C add #1,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 0603470E mov.b @(r0,r6),r1
    c.t = (int32_t)c.r[7] > (int32_t)c.r[4];  // 06034710 cmp/gt r4,r7
    c.r[0] = c.r[8];  // 06034712 mov r8,r0
    { const bool k = !c.t; st8(c.r[0] + c.r[5], c.r[1]); if (k) { SH2_POLL(c); goto L_06034702; } }  // 06034714 bf/s 0x06034702 ; mov.b r1,@(r0,r5)
    c.r[2] = ld32(0x060348C0u);  // 06034718 mov.l 0x060348C0,r2
    c.r[4] = ld32(0x060348BCu);  // 0603471A mov.l 0x060348BC,r4
    c.r[3] = (uint32_t)(int16_t)ld16(0x06034898u);  // 0603471C mov.w 0x06034898,r3
    c.r[6] = ld32(0x060348B4u);  // 0603471E mov.l 0x060348B4,r6
    c.r[11] = 0x4u;  // 06034720 mov #4,r11
    c.r[8] = (uint32_t)(int16_t)ld16(0x0603489Au);  // 06034722 mov.w 0x0603489A,r8
    c.r[10] = (uint32_t)(int16_t)ld16(0x0603489Cu);  // 06034724 mov.w 0x0603489C,r10
    c.r[5] = ld32(c.r[4]);  // 06034726 mov.l @r4,r5
    c.r[9] = (uint32_t)(int16_t)ld16(0x0603489Eu);  // 06034728 mov.w 0x0603489E,r9
    c.r[1] = c.r[5];  // 0603472A mov r5,r1
    c.r[1] += c.r[3];  // 0603472C add r3,r1
    c.r[0] = c.r[5];  // 0603472E mov r5,r0
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 06034730 mov.w @(r0,r3),r3
    c.r[1] += 2;  // 06034732 add #2,r1
    st16(c.r[2], c.r[3]);  // 06034734 mov.w r3,@r2
    c.r[2] += 2;  // 06034736 add #2,r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 06034738 mov.w @r1+,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x060348A0u);  // 0603473A mov.w 0x060348A0,r0
    st16(c.r[2], c.r[3]);  // 0603473C mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 0603473E mov.w @r1+,r3
    c.r[2] += 2;  // 06034740 add #2,r2
    st16(c.r[2], c.r[3]);  // 06034742 mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 06034744 mov.w @r1+,r3
    c.r[2] += 2;  // 06034746 add #2,r2
    st16(c.r[2], c.r[3]);  // 06034748 mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 0603474A mov.w @r1+,r3
    c.r[2] += 2;  // 0603474C add #2,r2
    st16(c.r[2], c.r[3]);  // 0603474E mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 06034750 mov.w @r1+,r3
    c.r[2] += 2;  // 06034752 add #2,r2
    st16(c.r[2], c.r[3]);  // 06034754 mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 06034756 mov.w @r1+,r3
    c.r[2] += 2;  // 06034758 add #2,r2
    st16(c.r[2], c.r[3]);  // 0603475A mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 0603475C mov.w @r1+,r3
    c.r[2] += 2;  // 0603475E add #2,r2
    st16(c.r[2], c.r[3]);  // 06034760 mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 06034762 mov.w @r1+,r3
    c.r[2] += 2;  // 06034764 add #2,r2
    st16(c.r[2], c.r[3]);  // 06034766 mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 06034768 mov.w @r1+,r3
    c.r[2] += 2;  // 0603476A add #2,r2
    st16(c.r[2], c.r[3]);  // 0603476C mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 0603476E mov.w @r1+,r3
    c.r[2] += 2;  // 06034770 add #2,r2
    st16(c.r[2], c.r[3]);  // 06034772 mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 06034774 mov.w @r1+,r3
    c.r[2] += 2;  // 06034776 add #2,r2
    st16(c.r[2], c.r[3]);  // 06034778 mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 0603477A mov.w @r1+,r3
    c.r[2] += 2;  // 0603477C add #2,r2
    st16(c.r[2], c.r[3]);  // 0603477E mov.w r3,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 06034780 mov.w @r1+,r3
    c.r[2] += 2;  // 06034782 add #2,r2
    st16(c.r[2], c.r[3]);  // 06034784 mov.w r3,@r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06034786 mov.w @r1,r1
    c.r[2] += 2;  // 06034788 add #2,r2
    st16(c.r[2], c.r[1]);  // 0603478A mov.w r1,@r2
    c.r[1] = c.r[5];  // 0603478C mov r5,r1
    c.r[1] += 8;  // 0603478E add #8,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06034790 mov.b @r1,r3
    c.r[2] += 2;  // 06034792 add #2,r2
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06034794 mov.b @r2,r7
    c.r[3] &= c.r[0];  // 06034796 and r0,r3
    c.r[0] = 0x3Fu;  // 06034798 mov #63,r0
    c.r[7] &= c.r[0];  // 0603479A and r0,r7
    c.r[7] |= c.r[3];  // 0603479C or r3,r7
    st8(c.r[2], c.r[7]);  // 0603479E mov.b r7,@r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060347A0 mov.b @r1,r1
    c.r[0] = 0x30u;  // 060347A2 mov #48,r0
    c.r[1] &= c.r[0];  // 060347A4 and r0,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060348A2u);  // 060347A6 mov.w 0x060348A2,r0
    c.r[7] &= c.r[0];  // 060347A8 and r0,r7
    c.r[7] |= c.r[1];  // 060347AA or r1,r7
    st8(c.r[2], c.r[7]);  // 060347AC mov.b r7,@r2
    c.r[1] = c.r[5];  // 060347AE mov r5,r1
    c.r[1] += 10;  // 060347B0 add #10,r1
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060347B2 mov.w @r1,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x060348A4u);  // 060347B4 mov.w 0x060348A4,r0
    c.r[3] = c.r[3] & 0xFFFFu;  // 060347B6 extu.w r3,r3
    c.r[3] <<= 8;  // 060347B8 shll8 r3
    c.r[1] = c.r[5];  // 060347BA mov r5,r1
    c.r[1] += 12;  // 060347BC add #12,r1
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060347BE mov.b @r1,r7
    c.r[5] += 16;  // 060347C0 add #16,r5
    c.r[7] = c.r[7] & 0xFFu;  // 060347C2 extu.b r7,r7
    c.r[7] |= c.r[3];  // 060347C4 or r3,r7
    c.r[1] = ld32(c.r[2]);  // 060347C6 mov.l @r2,r1
    c.r[3] = ld32(0x060348C4u);  // 060347C8 mov.l 0x060348C4,r3
    c.r[1] &= c.r[3];  // 060347CA and r3,r1
    c.r[7] |= c.r[1];  // 060347CC or r1,r7
    st32(c.r[2], c.r[7]);  // 060347CE mov.l r7,@r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x060348A6u);  // 060347D0 mov.w 0x060348A6,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[5]);  // 060347D2 mov.b @r5,r2
    c.r[7] = 0x0u;  // 060347D4 mov #0,r7
    c.r[2] &= c.r[0];  // 060347D6 and r0,r2
    c.r[0] = c.r[6];  // 060347D8 mov r6,r0
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060347DA mov.b @(r0,r1),r3
    c.r[5] = (uint32_t)(int16_t)ld16(0x060348A8u);  // 060347DC mov.w 0x060348A8,r5
    c.r[0] = 0x1u;  // 060347DE mov #1,r0
    c.r[3] &= c.r[0];  // 060347E0 and r0,r3
    c.r[3] |= c.r[2];  // 060347E2 or r2,r3
    c.r[0] = c.r[6];  // 060347E4 mov r6,r0
    st8(c.r[0] + c.r[1], c.r[3]);  // 060347E6 mov.b r3,@(r0,r1)
L_060347E8:
    c.r[3] = c.r[7];  // 060347E8 mov r7,r3
    c.r[3] <<= 2;  // 060347EA shll2 r3
    c.r[12] = 0x1Fu;  // 060347EC mov #31,r12
    c.r[2] = ld32(c.r[4]);  // 060347EE mov.l @r4,r2
    c.r[0] = c.r[6];  // 060347F0 mov r6,r0
    c.r[2] += c.r[3];  // 060347F2 add r3,r2
    c.r[1] = c.r[2];  // 060347F4 mov r2,r1
    c.r[1] += 22;  // 060347F6 add #22,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060347F8 mov.b @r1,r1
    c.r[2] += 23;  // 060347FA add #23,r2
    c.r[12] &= c.r[1];  // 060347FC and r1,r12
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060347FE mov.b @r2,r1
    c.r[12] <<= 2;  // 06034800 shll2 r12
    c.r[12] += c.r[12];  // 06034802 add r12,r12
    c.r[12] <<= 2;  // 06034804 shll2 r12
    c.r[2] = c.r[1] & 0xFFu;  // 06034806 extu.b r1,r2
    c.r[2] >>= 2;  // 06034808 shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 0603480A shlr r2
    c.r[2] |= c.r[12];  // 0603480C or r12,r2
    c.r[1] = c.r[2];  // 0603480E mov r2,r1
    c.r[12] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 06034810 mov.b @(r0,r5),r12
    c.r[1] >>= 2;  // 06034812 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06034814 shlr r1
    c.r[1] >>= 2;  // 06034816 shlr2 r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060348AAu);  // 06034818 mov.w 0x060348AA,r0
    c.r[12] &= c.r[0];  // 0603481A and r0,r12
    c.r[12] |= c.r[1];  // 0603481C or r1,r12
    c.r[0] = c.r[6];  // 0603481E mov r6,r0
    st8(c.r[0] + c.r[5], c.r[12]);  // 06034820 mov.b r12,@(r0,r5)
    c.r[0] = 0x1Fu;  // 06034822 mov #31,r0
    c.r[2] &= c.r[0];  // 06034824 and r0,r2
    c.r[0] = c.r[6];  // 06034826 mov r6,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 06034828 mov.b @(r0,r8),r1
    c.r[2] <<= 2;  // 0603482A shll2 r2
    c.r[2] += c.r[2];  // 0603482C add r2,r2
    c.r[0] = 0x7u;  // 0603482E mov #7,r0
    c.r[1] &= c.r[0];  // 06034830 and r0,r1
    c.r[1] |= c.r[2];  // 06034832 or r2,r1
    c.r[0] = c.r[6];  // 06034834 mov r6,r0
    st8(c.r[0] + c.r[8], c.r[1]);  // 06034836 mov.b r1,@(r0,r8)
    c.r[1] = ld32(c.r[4]);  // 06034838 mov.l @r4,r1
    c.r[1] += c.r[3];  // 0603483A add r3,r1
    c.r[1] += 20;  // 0603483C add #20,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603483E mov.b @r1,r1
    st8(c.r[0] + c.r[10], c.r[1]);  // 06034840 mov.b r1,@(r0,r10)
    c.r[1] = ld32(c.r[4]);  // 06034842 mov.l @r4,r1
    c.r[1] += c.r[3];  // 06034844 add r3,r1
    c.r[1] += 21;  // 06034846 add #21,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06034848 mov.b @r1,r1
    st8(c.r[0] + c.r[9], c.r[1]);  // 0603484A mov.b r1,@(r0,r9)
    c.r[1] = ld32(c.r[4]);  // 0603484C mov.l @r4,r1
    c.r[1] += c.r[3];  // 0603484E add r3,r1
    c.r[1] += 22;  // 06034850 add #22,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06034852 mov.b @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060348A0u);  // 06034854 mov.w 0x060348A0,r0
    c.r[1] &= c.r[0];  // 06034856 and r0,r1
    c.r[0] = c.r[6];  // 06034858 mov r6,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 0603485A mov.b @(r0,r5),r2
    c.r[7] += 1;  // 0603485C add #1,r7
    c.r[0] = 0x3Fu;  // 0603485E mov #63,r0
    c.r[2] &= c.r[0];  // 06034860 and r0,r2
    c.r[2] |= c.r[1];  // 06034862 or r1,r2
    c.r[0] = c.r[6];  // 06034864 mov r6,r0
    st8(c.r[0] + c.r[5], c.r[2]);  // 06034866 mov.b r2,@(r0,r5)
    c.r[1] = ld32(c.r[4]);  // 06034868 mov.l @r4,r1
    c.t = (int32_t)c.r[7] > (int32_t)c.r[11];  // 0603486A cmp/gt r11,r7
    c.r[1] += c.r[3];  // 0603486C add r3,r1
    c.r[1] += 22;  // 0603486E add #22,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06034870 mov.b @r1,r1
    c.r[0] = 0x20u;  // 06034872 mov #32,r0
    c.r[1] &= c.r[0];  // 06034874 and r0,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060348ACu);  // 06034876 mov.w 0x060348AC,r0
    c.r[2] &= c.r[0];  // 06034878 and r0,r2
    c.r[2] |= c.r[1];  // 0603487A or r1,r2
    c.r[0] = c.r[6];  // 0603487C mov r6,r0
    st8(c.r[0] + c.r[5], c.r[2]);  // 0603487E mov.b r2,@(r0,r5)
    c.r[6] += 4; goto L_060348C8;  // 06034880 bra 0x060348C8 ; add #4,r6
L_060348C8:
    if (!c.t) { SH2_POLL(c); goto L_060347E8; }  // 060348C8 bf 0x060347E8
    c.r[8] = 0x0u;  // 060348CA mov #0,r8
    c.r[4] = ld32(0x06034ADCu);  // 060348CC mov.l 0x06034ADC,r4
    c.r[5] = 0x0u;  // 060348CE mov #0,r5
    c.r[6] = ld32(0x06034AE0u);  // 060348D0 mov.l 0x06034AE0,r6
L_060348D2:
    c.r[0] = ld32(c.r[4]);  // 060348D2 mov.l @r4,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[5]);  // 060348D4 mov.w @(r0,r5),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 060348D6 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060348D8 tst r1,r1
    if (!c.t) { goto L_060348E0; }  // 060348DA bf 0x060348E0
    goto L_06034A50;  // 060348DC bra 0x06034A50 ; nop
L_060348E0:
    c.r[7] = 0x0u;  // 060348E0 mov #0,r7
    c.r[3] = 0x7u;  // 060348E2 mov #7,r3
    c.r[2] = (uint32_t)(int16_t)ld16(0x06034AB0u);  // 060348E4 mov.w 0x06034AB0,r2
L_060348E6:
    c.r[0] = c.r[6];  // 060348E6 mov r6,r0
    c.r[1] = ld32(c.r[4]);  // 060348E8 mov.l @r4,r1
    c.r[0] += c.r[7];  // 060348EA add r7,r0
    c.r[1] += c.r[5];  // 060348EC add r5,r1
    c.r[1] += c.r[7];  // 060348EE add r7,r1
    c.r[1] += 7;  // 060348F0 add #7,r1
    c.r[7] += 1;  // 060348F2 add #1,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060348F4 mov.b @r1,r1
    c.t = (int32_t)c.r[7] > (int32_t)c.r[3];  // 060348F6 cmp/gt r3,r7
    { const bool k = !c.t; st8(c.r[0] + c.r[2], c.r[1]); if (k) { SH2_POLL(c); goto L_060348E6; } }  // 060348F8 bf/s 0x060348E6 ; mov.b r1,@(r0,r2)
    c.r[3] = (uint32_t)(int16_t)ld16(0x06034AB2u);  // 060348FC mov.w 0x06034AB2,r3
    c.r[2] = c.r[5];  // 060348FE mov r5,r2
    c.r[0] = c.r[5];  // 06034900 mov r5,r0
    c.r[1] = ld32(c.r[4]);  // 06034902 mov.l @r4,r1
    c.r[7] = 0x0u;  // 06034904 mov #0,r7
    c.r[2] += c.r[1];  // 06034906 add r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06034908 mov.w @(r0,r1),r1
    c.r[2] += 15;  // 0603490A add #15,r2
    c.r[0] = c.r[6];  // 0603490C mov r6,r0
    st16(c.r[0] + c.r[3], c.r[1]);  // 0603490E mov.w r1,@(r0,r3)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06034910 mov.b @r2,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x06034AB4u);  // 06034912 mov.w 0x06034AB4,r3
    st8(c.r[0] + c.r[3], c.r[1]);  // 06034914 mov.b r1,@(r0,r3)
    c.r[1] = ld32(c.r[4]);  // 06034916 mov.l @r4,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06034AB6u);  // 06034918 mov.w 0x06034AB6,r2
    c.r[1] += c.r[5];  // 0603491A add r5,r1
    c.r[1] += 16;  // 0603491C add #16,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603491E mov.b @r1,r1
    c.r[3] = 0x3u;  // 06034920 mov #3,r3
    st8(c.r[0] + c.r[2], c.r[1]);  // 06034922 mov.b r1,@(r0,r2)
    c.r[2] = (uint32_t)(int16_t)ld16(0x06034AB8u);  // 06034924 mov.w 0x06034AB8,r2
L_06034926:
    c.r[0] = c.r[6];  // 06034926 mov r6,r0
    c.r[1] = ld32(c.r[4]);  // 06034928 mov.l @r4,r1
    c.r[0] += c.r[7];  // 0603492A add r7,r0
    c.r[1] += c.r[5];  // 0603492C add r5,r1
    c.r[1] += c.r[7];  // 0603492E add r7,r1
    c.r[1] += 17;  // 06034930 add #17,r1
    c.r[7] += 1;  // 06034932 add #1,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06034934 mov.b @r1,r1
    c.t = (int32_t)c.r[7] > (int32_t)c.r[3];  // 06034936 cmp/gt r3,r7
    { const bool k = !c.t; st8(c.r[0] + c.r[2], c.r[1]); if (k) { SH2_POLL(c); goto L_06034926; } }  // 06034938 bf/s 0x06034926 ; mov.b r1,@(r0,r2)
    c.r[1] = ld32(c.r[4]);  // 0603493C mov.l @r4,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06034ABAu);  // 0603493E mov.w 0x06034ABA,r2
    c.r[1] += c.r[5];  // 06034940 add r5,r1
    c.r[1] += 26;  // 06034942 add #26,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06034944 mov.b @r1,r1
    c.r[0] = c.r[6];  // 06034946 mov r6,r0
    st8(c.r[0] + c.r[2], c.r[1]);  // 06034948 mov.b r1,@(r0,r2)
    c.r[1] = ld32(c.r[4]);  // 0603494A mov.l @r4,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x06034ABCu);  // 0603494C mov.w 0x06034ABC,r3
    c.r[1] += c.r[5];  // 0603494E add r5,r1
    c.r[1] += 2;  // 06034950 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06034952 mov.b @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06034ABEu);  // 06034954 mov.w 0x06034ABE,r0
    c.r[1] &= c.r[0];  // 06034956 and r0,r1
    c.r[0] = c.r[6];  // 06034958 mov r6,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0603495A mov.b @(r0,r3),r2
    c.r[0] = 0x3Fu;  // 0603495C mov #63,r0
    c.r[2] &= c.r[0];  // 0603495E and r0,r2
    c.r[2] |= c.r[1];  // 06034960 or r1,r2
    c.r[0] = c.r[6];  // 06034962 mov r6,r0
    st8(c.r[0] + c.r[3], c.r[2]);  // 06034964 mov.b r2,@(r0,r3)
    c.r[1] = ld32(c.r[4]);  // 06034966 mov.l @r4,r1
    c.r[1] += c.r[5];  // 06034968 add r5,r1
    c.r[1] += 2;  // 0603496A add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603496C mov.b @r1,r1
    c.r[0] = 0x30u;  // 0603496E mov #48,r0
    c.r[1] += c.r[1];  // 06034970 add r1,r1
    c.r[1] &= c.r[0];  // 06034972 and r0,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06034AC0u);  // 06034974 mov.w 0x06034AC0,r0
    c.r[2] &= c.r[0];  // 06034976 and r0,r2
    c.r[2] |= c.r[1];  // 06034978 or r1,r2
    c.r[0] = c.r[6];  // 0603497A mov r6,r0
    st8(c.r[0] + c.r[3], c.r[2]);  // 0603497C mov.b r2,@(r0,r3)
    c.r[1] = ld32(c.r[4]);  // 0603497E mov.l @r4,r1
    c.r[1] += c.r[5];  // 06034980 add r5,r1
    c.r[1] += 3;  // 06034982 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06034984 mov.b @r1,r1
    c.r[0] = 0xFu;  // 06034986 mov #15,r0
    c.r[1] >>= 2;  // 06034988 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0603498A shlr r1
    c.r[1] &= c.r[0];  // 0603498C and r0,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06034AC2u);  // 0603498E mov.w 0x06034AC2,r0
    c.r[2] &= c.r[0];  // 06034990 and r0,r2
    c.r[2] |= c.r[1];  // 06034992 or r1,r2
    c.r[0] = c.r[6];  // 06034994 mov r6,r0
    st8(c.r[0] + c.r[3], c.r[2]);  // 06034996 mov.b r2,@(r0,r3)
    c.r[2] = ld32(c.r[4]);  // 06034998 mov.l @r4,r2
    c.r[3] = 0x7u;  // 0603499A mov #7,r3
    c.r[2] += c.r[5];  // 0603499C add r5,r2
    c.r[1] = c.r[2];  // 0603499E mov r2,r1
    c.r[1] += 3;  // 060349A0 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060349A2 mov.b @r1,r1
    c.r[2] += 4;  // 060349A4 add #4,r2
    c.r[3] &= c.r[1];  // 060349A6 and r1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060349A8 mov.b @r2,r1
    c.r[3] += c.r[3];  // 060349AA add r3,r3
    c.r[1] = c.r[1] & 0xFFu;  // 060349AC extu.b r1,r1
    c.r[1] >>= 2;  // 060349AE shlr2 r1
    c.r[1] >>= 2;  // 060349B0 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060349B2 shlr r1
    c.r[1] >>= 2;  // 060349B4 shlr2 r1
    c.r[1] |= c.r[3];  // 060349B6 or r3,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06034AC4u);  // 060349B8 mov.w 0x06034AC4,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 060349BA mov.b @(r0,r2),r3
    c.r[1] <<= 2;  // 060349BC shll2 r1
    c.r[1] <<= 2;  // 060349BE shll2 r1
    c.r[0] = 0xFu;  // 060349C0 mov #15,r0
    c.r[3] &= c.r[0];  // 060349C2 and r0,r3
    c.r[3] |= c.r[1];  // 060349C4 or r1,r3
    c.r[0] = c.r[6];  // 060349C6 mov r6,r0
    st8(c.r[0] + c.r[2], c.r[3]);  // 060349C8 mov.b r3,@(r0,r2)
    c.r[1] = ld32(c.r[4]);  // 060349CA mov.l @r4,r1
    c.r[1] += c.r[5];  // 060349CC add r5,r1
    c.r[1] += 4;  // 060349CE add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060349D0 mov.b @r1,r1
    c.r[0] = 0xFu;  // 060349D2 mov #15,r0
    c.r[1] >>= 2;  // 060349D4 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060349D6 shlr r1
    c.r[1] &= c.r[0];  // 060349D8 and r0,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06034AC2u);  // 060349DA mov.w 0x06034AC2,r0
    c.r[3] &= c.r[0];  // 060349DC and r0,r3
    c.r[3] |= c.r[1];  // 060349DE or r1,r3
    c.r[0] = c.r[6];  // 060349E0 mov r6,r0
    st8(c.r[0] + c.r[2], c.r[3]);  // 060349E2 mov.b r3,@(r0,r2)
    c.r[1] = ld32(c.r[4]);  // 060349E4 mov.l @r4,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06034AC6u);  // 060349E6 mov.w 0x06034AC6,r2
    c.r[1] += c.r[5];  // 060349E8 add r5,r1
    c.r[1] += 4;  // 060349EA add #4,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060349EC mov.w @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06034AC2u);  // 060349EE mov.w 0x06034AC2,r0
    c.r[1] >>= 2;  // 060349F0 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060349F2 shlr r1
    c.r[1] &= c.r[0];  // 060349F4 and r0,r1
    c.r[0] = c.r[6];  // 060349F6 mov r6,r0
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 060349F8 mov.b @(r0,r2),r3
    c.r[0] = 0xFu;  // 060349FA mov #15,r0
    c.r[3] &= c.r[0];  // 060349FC and r0,r3
    c.r[3] |= c.r[1];  // 060349FE or r1,r3
    c.r[0] = c.r[6];  // 06034A00 mov r6,r0
    st8(c.r[0] + c.r[2], c.r[3]);  // 06034A02 mov.b r3,@(r0,r2)
    c.r[1] = ld32(c.r[4]);  // 06034A04 mov.l @r4,r1
    c.r[1] += c.r[5];  // 06034A06 add r5,r1
    c.r[1] += 5;  // 06034A08 add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06034A0A mov.b @r1,r1
    c.r[0] = 0xFu;  // 06034A0C mov #15,r0
    c.r[1] >>= 2;  // 06034A0E shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06034A10 shlr r1
    c.r[1] &= c.r[0];  // 06034A12 and r0,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06034AC2u);  // 06034A14 mov.w 0x06034AC2,r0
    c.r[3] &= c.r[0];  // 06034A16 and r0,r3
    c.r[3] |= c.r[1];  // 06034A18 or r1,r3
    c.r[0] = c.r[6];  // 06034A1A mov r6,r0
    st8(c.r[0] + c.r[2], c.r[3]);  // 06034A1C mov.b r3,@(r0,r2)
    c.r[2] = ld32(c.r[4]);  // 06034A1E mov.l @r4,r2
    c.r[3] = 0x7u;  // 06034A20 mov #7,r3
    c.r[2] += c.r[5];  // 06034A22 add r5,r2
    c.r[1] = c.r[2];  // 06034A24 mov r2,r1
    c.r[1] += 5;  // 06034A26 add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06034A28 mov.b @r1,r1
    c.r[2] += 6;  // 06034A2A add #6,r2
    c.r[3] &= c.r[1];  // 06034A2C and r1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06034A2E mov.b @r2,r1
    c.r[3] += c.r[3];  // 06034A30 add r3,r3
    c.r[1] = c.r[1] & 0xFFu;  // 06034A32 extu.b r1,r1
    c.r[1] >>= 2;  // 06034A34 shlr2 r1
    c.r[1] >>= 2;  // 06034A36 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06034A38 shlr r1
    c.r[1] >>= 2;  // 06034A3A shlr2 r1
    c.r[1] |= c.r[3];  // 06034A3C or r3,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06034AC8u);  // 06034A3E mov.w 0x06034AC8,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06034A40 mov.b @(r0,r2),r3
    c.r[1] <<= 2;  // 06034A42 shll2 r1
    c.r[1] <<= 2;  // 06034A44 shll2 r1
    c.r[0] = 0xFu;  // 06034A46 mov #15,r0
    c.r[3] &= c.r[0];  // 06034A48 and r0,r3
    c.r[3] |= c.r[1];  // 06034A4A or r1,r3
    c.r[0] = c.r[6];  // 06034A4C mov r6,r0
    st8(c.r[0] + c.r[2], c.r[3]);  // 06034A4E mov.b r3,@(r0,r2)
L_06034A50:
    c.r[5] += 30;  // 06034A50 add #30,r5
    c.r[8] += 1;  // 06034A52 add #1,r8
    c.r[1] = 0x7Fu;  // 06034A54 mov #127,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 06034A56 cmp/gt r1,r8
    { const bool k = c.t; c.r[6] += 22; if (k) { goto L_06034A60; } }  // 06034A58 bt/s 0x06034A60 ; add #22,r6
    SH2_POLL(c); goto L_060348D2;  // 06034A5C bra 0x060348D2 ; nop
L_06034A60:
    c.r[8] = 0x0u;  // 06034A60 mov #0,r8
    c.r[4] = ld32(0x06034AE4u);  // 06034A62 mov.l 0x06034AE4,r4
    c.r[11] = (uint32_t)(int16_t)ld16(0x06034ACAu);  // 06034A64 mov.w 0x06034ACA,r11
    c.r[10] = (uint32_t)(int16_t)ld16(0x06034ACCu);  // 06034A66 mov.w 0x06034ACC,r10
    c.r[9] = (uint32_t)(int16_t)ld16(0x06034ACEu);  // 06034A68 mov.w 0x06034ACE,r9
    c.r[5] = (uint32_t)(int16_t)ld16(0x06034AD0u);  // 06034A6A mov.w 0x06034AD0,r5
    c.r[6] = 0x0u;  // 06034A6C mov #0,r6
L_06034A6E:
    c.r[0] = ld32(c.r[4]);  // 06034A6E mov.l @r4,r0
    c.r[7] = c.r[6];  // 06034A70 mov r6,r7
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[6]);  // 06034A72 mov.w @(r0,r6),r3
    c.r[1] = c.r[3] & 0xFFFFu;  // 06034A74 extu.w r3,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06034A76 tst r1,r1
    { const bool k = c.t; c.r[7] += c.r[0]; if (k) { goto L_06034B3E; } }  // 06034A78 bt/s 0x06034B3E ; add r0,r7
    c.r[2] = ld32(0x06034AE0u);  // 06034A7C mov.l 0x06034AE0,r2
    c.r[2] += c.r[6];  // 06034A7E add r6,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06034AD2u);  // 06034A80 mov.w 0x06034AD2,r1
    c.r[0] = c.r[2];  // 06034A82 mov r2,r0
    st16(c.r[0] + c.r[1], c.r[3]);  // 06034A84 mov.w r3,@(r0,r1)
    c.r[1] = c.r[7];  // 06034A86 mov r7,r1
    c.r[1] += 4;  // 06034A88 add #4,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06034A8A mov.w @r1,r1
    st16(c.r[0] + c.r[11], c.r[1]);  // 06034A8C mov.w r1,@(r0,r11)
    c.r[1] = c.r[7];  // 06034A8E mov r7,r1
    c.r[1] += 6;  // 06034A90 add #6,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06034A92 mov.w @r1,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x06034AD4u);  // 06034A94 mov.w 0x06034AD4,r3
    st16(c.r[0] + c.r[3], c.r[1]);  // 06034A96 mov.w r1,@(r0,r3)
    c.r[3] = (uint32_t)(int16_t)ld16(0x06034AD6u);  // 06034A98 mov.w 0x06034AD6,r3
    c.r[1] = c.r[7];  // 06034A9A mov r7,r1
    c.r[1] += 10;  // 06034A9C add #10,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06034A9E mov.w @r1,r1
    c.r[7] += 2;  // 06034AA0 add #2,r7
    st16(c.r[0] + c.r[3], c.r[1]);  // 06034AA2 mov.w r1,@(r0,r3)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06034AA4 mov.b @r7,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x06034AD8u);  // 06034AA6 mov.w 0x06034AD8,r3
    st8(c.r[0] + c.r[3], c.r[1]);  // 06034AA8 mov.b r1,@(r0,r3)
    c.r[1] = ld32(c.r[4]);  // 06034AAA mov.l @r4,r1
    c.r[1] += c.r[6]; goto L_06034AE8;  // 06034AAC bra 0x06034AE8 ; add r6,r1
L_06034AE8:
    c.r[1] += 8;  // 06034AE8 add #8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06034AEA mov.b @r1,r1
    st8(c.r[0] + c.r[10], c.r[1]);  // 06034AEC mov.b r1,@(r0,r10)
    c.r[1] = ld32(c.r[4]);  // 06034AEE mov.l @r4,r1
    c.r[1] += c.r[6];  // 06034AF0 add r6,r1
    c.r[1] += 9;  // 06034AF2 add #9,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06034AF4 mov.b @r1,r1
    st8(c.r[0] + c.r[9], c.r[1]);  // 06034AF6 mov.b r1,@(r0,r9)
    c.r[1] = ld32(c.r[4]);  // 06034AF8 mov.l @r4,r1
    c.r[1] += c.r[6];  // 06034AFA add r6,r1
    c.r[1] += 3;  // 06034AFC add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06034AFE mov.b @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06034B5Au);  // 06034B00 mov.w 0x06034B5A,r0
    c.r[1] &= c.r[0];  // 06034B02 and r0,r1
    c.r[0] = c.r[2];  // 06034B04 mov r2,r0
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 06034B06 mov.b @(r0,r5),r3
    c.r[0] = 0x3Fu;  // 06034B08 mov #63,r0
    c.r[3] &= c.r[0];  // 06034B0A and r0,r3
    c.r[3] |= c.r[1];  // 06034B0C or r1,r3
    c.r[0] = c.r[2];  // 06034B0E mov r2,r0
    st8(c.r[0] + c.r[5], c.r[3]);  // 06034B10 mov.b r3,@(r0,r5)
    c.r[1] = ld32(c.r[4]);  // 06034B12 mov.l @r4,r1
    c.r[1] += c.r[6];  // 06034B14 add r6,r1
    c.r[1] += 3;  // 06034B16 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06034B18 mov.b @r1,r1
    c.r[0] = 0x30u;  // 06034B1A mov #48,r0
    c.r[1] &= c.r[0];  // 06034B1C and r0,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06034B5Cu);  // 06034B1E mov.w 0x06034B5C,r0
    c.r[3] &= c.r[0];  // 06034B20 and r0,r3
    c.r[3] |= c.r[1];  // 06034B22 or r1,r3
    c.r[0] = c.r[2];  // 06034B24 mov r2,r0
    st8(c.r[0] + c.r[5], c.r[3]);  // 06034B26 mov.b r3,@(r0,r5)
    c.r[1] = ld32(c.r[4]);  // 06034B28 mov.l @r4,r1
    c.r[1] += c.r[6];  // 06034B2A add r6,r1
    c.r[1] += 3;  // 06034B2C add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06034B2E mov.b @r1,r1
    c.r[0] = 0x8u;  // 06034B30 mov #8,r0
    c.r[1] &= c.r[0];  // 06034B32 and r0,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06034B5Eu);  // 06034B34 mov.w 0x06034B5E,r0
    c.r[3] &= c.r[0];  // 06034B36 and r0,r3
    c.r[3] |= c.r[1];  // 06034B38 or r1,r3
    c.r[0] = c.r[2];  // 06034B3A mov r2,r0
    st8(c.r[0] + c.r[5], c.r[3]);  // 06034B3C mov.b r3,@(r0,r5)
L_06034B3E:
    c.r[8] += 1;  // 06034B3E add #1,r8
    c.r[1] = 0x7Fu;  // 06034B40 mov #127,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 06034B42 cmp/gt r1,r8
    { const bool k = !c.t; c.r[6] += 12; if (k) { SH2_POLL(c); goto L_06034A6E; } }  // 06034B44 bf/s 0x06034A6E ; add #12,r6
    c.r[15] = c.r[14];  // 06034B48 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06034B4A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06034B4C mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06034B4E mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06034B50 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06034B52 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06034B54 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06034B56 rts ; mov.l @r15+,r8
}

}  // namespace p_srwfin_kor
