#include "p_srwfin_installed_funcs.h"

namespace p_srwfin_installed {

void f_060970AC(SH2Context& c) {
    ran[2292] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060970AC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060970AE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060970B0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060970B2 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060970B4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060970B6 sts.l pr,@-r15
    c.r[15] -= 48;  // 060970B8 add #-48,r15
    c.r[14] = c.r[15];  // 060970BA mov r15,r14
    st32(c.r[14], c.r[4]);  // 060970BC mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 060970BE mov.l r5,@(4,r14)
    st32(c.r[14] + 8, c.r[6]);  // 060970C0 mov.l r6,@(8,r14)
    c.r[9] = c.r[7];  // 060970C2 mov r7,r9
    c.r[8] = c.r[14];  // 060970C4 mov r14,r8
    c.r[10] = c.r[14];  // 060970C6 mov r14,r10
    c.r[10] += 12;  // 060970C8 add #12,r10
    st8(c.r[10], c.r[9]);  // 060970CA mov.b r9,@r10
    c.r[1] = c.r[14];  // 060970CC mov r14,r1
    c.r[1] += 16;  // 060970CE add #16,r1
    c.r[2] = ld32(c.r[14] + 4);  // 060970D0 mov.l @(4,r14),r2
    c.r[5] = c.r[1];  // 060970D2 mov r1,r5
    c.r[4] = c.r[2];  // 060970D4 mov r2,r4
    c.r[11] = ld32(0x06097168u);  // 060970D6 mov.l 0x06097168,r11
    { const uint32_t x = c.r[11]; c.pr = 0x060970DCu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060970DCu) return; }  // 060970D8 jsr @r11 ; nop
    st32(c.r[14] + 44, c.r[0]);  // 060970DC mov.l r0,@(44,r14)
    c.r[1] = ld32(c.r[14] + 44);  // 060970DE mov.l @(44,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060970E0 tst r1,r1
    if (!c.t) { goto L_06097138; }  // 060970E2 bf 0x06097138
    c.r[1] = ld32(c.r[14] + 8);  // 060970E4 mov.l @(8,r14),r1
    c.r[2] = c.r[14];  // 060970E6 mov r14,r2
    c.r[2] += 28;  // 060970E8 add #28,r2
    c.r[6] = 0xCu;  // 060970EA mov #12,r6
    c.r[5] = c.r[1];  // 060970EC mov r1,r5
    c.r[4] = c.r[2];  // 060970EE mov r2,r4
    c.r[11] = ld32(0x0609716Cu);  // 060970F0 mov.l 0x0609716C,r11
    { const uint32_t x = c.r[11]; c.pr = 0x060970F6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060970F6u) return; }  // 060970F2 jsr @r11 ; nop
    c.r[2] = c.r[14];  // 060970F6 mov r14,r2
    c.r[1] = c.r[14];  // 060970F8 mov r14,r1
    c.r[1] += 28;  // 060970FA add #28,r1
    c.r[2] = c.r[14];  // 060970FC mov r14,r2
    c.r[3] = c.r[14];  // 060970FE mov r14,r3
    c.r[3] += 16;  // 06097100 add #16,r3
    c.r[2] = c.r[3];  // 06097102 mov r3,r2
    c.r[3] += 10;  // 06097104 add #10,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06097106 mov.b @r3,r2
    c.r[3] = c.r[2] & 0xFFu;  // 06097108 extu.b r2,r3
    st16(c.r[1], c.r[3]);  // 0609710A mov.w r3,@r1
    c.r[1] = c.r[14];  // 0609710C mov r14,r1
    c.r[1] += 28;  // 0609710E add #28,r1
    c.r[2] = ld32(c.r[14] + 4);  // 06097110 mov.l @(4,r14),r2
    c.r[3] = c.r[14];  // 06097112 mov r14,r3
    c.r[3] += 16;  // 06097114 add #16,r3
    c.r[7] = c.r[14];  // 06097116 mov r14,r7
    c.r[6] = c.r[14];  // 06097118 mov r14,r6
    c.r[6] += 12;  // 0609711A add #12,r6
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0609711C mov.b @r6,r5
    c.r[7] = c.r[5] & 0xFFu;  // 0609711E extu.b r5,r7
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 06097120 mov.l r7,@-r15
    c.r[7] = c.r[1];  // 06097122 mov r1,r7
    c.r[6] = c.r[2];  // 06097124 mov r2,r6
    c.r[5] = c.r[3];  // 06097126 mov r3,r5
    c.r[4] = ld32(c.r[14]);  // 06097128 mov.l @r14,r4
    c.r[11] = ld32(0x06097170u);  // 0609712A mov.l 0x06097170,r11
    { const uint32_t x = c.r[11]; c.pr = 0x06097130u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06097130u) return; }  // 0609712C jsr @r11 ; nop
    c.r[15] += 4;  // 06097130 add #4,r15
    st32(c.r[14] + 40, c.r[0]);  // 06097132 mov.l r0,@(40,r14)
    goto L_0609714C;  // 06097134 bra 0x0609714C ; nop
L_06097138:
    c.r[1] = ld32(c.r[14] + 44);  // 06097138 mov.l @(44,r14),r1
    c.r[4] = c.r[1];  // 0609713A mov r1,r4
    c.r[11] = ld32(0x06097174u);  // 0609713C mov.l 0x06097174,r11
    { const uint32_t x = c.r[11]; c.pr = 0x06097142u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06097142u) return; }  // 0609713E jsr @r11 ; nop
    c.r[11] = ld32(0x06097178u);  // 06097142 mov.l 0x06097178,r11
    { const uint32_t x = c.r[11]; c.pr = 0x06097148u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06097148u) return; }  // 06097144 jsr @r11 ; nop
    c.r[1] = 0x0u;  // 06097148 mov #0,r1
    st32(c.r[14] + 40, c.r[1]);  // 0609714A mov.l r1,@(40,r14)
L_0609714C:
    c.r[0] = ld32(c.r[14] + 40);  // 0609714C mov.l @(40,r14),r0
    goto L_06097152;  // 0609714E bra 0x06097152 ; nop
L_06097152:
    c.r[14] += 48;  // 06097152 add #48,r14
    c.r[15] = c.r[14];  // 06097154 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06097156 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06097158 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0609715A mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0609715C mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609715E mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06097160 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06097162 rts ; nop
}

void f_0609717C(SH2Context& c) {
    ran[2293] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609717C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609717E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06097180 sts.l pr,@-r15
    c.r[15] -= 28;  // 06097182 add #-28,r15
    c.r[14] = c.r[15];  // 06097184 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06097186 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 06097188 mov.l r5,@(4,r14)
    st32(c.r[14] + 8, c.r[6]);  // 0609718A mov.l r6,@(8,r14)
    st32(c.r[14] + 12, c.r[7]);  // 0609718C mov.l r7,@(12,r14)
    c.r[1] = (uint32_t)(int16_t)ld16(0x06097234u);  // 0609718E mov.w 0x06097234,r1
    c.r[4] = c.r[1];  // 06097190 mov r1,r4
    c.r[8] = ld32(0x06097238u);  // 06097192 mov.l 0x06097238,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06097198u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06097198u) return; }  // 06097194 jsr @r8 ; nop
    c.r[1] = ld32(c.r[14]);  // 06097198 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609719A tst r1,r1
    if (!c.t) { goto L_060971B2; }  // 0609719C bf 0x060971B2
    c.r[4] = 0xFFFFFFF5u;  // 0609719E mov #-11,r4
    c.r[8] = ld32(0x0609723Cu);  // 060971A0 mov.l 0x0609723C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060971A6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060971A6u) return; }  // 060971A2 jsr @r8 ; nop
    c.r[8] = ld32(0x06097240u);  // 060971A6 mov.l 0x06097240,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060971ACu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060971ACu) return; }  // 060971A8 jsr @r8 ; nop
    c.r[0] = 0x0u;  // 060971AC mov #0,r0
    goto L_06097226;  // 060971AE bra 0x06097226 ; nop
L_060971B2:
    c.r[1] = ld32(c.r[14] + 12);  // 060971B2 mov.l @(12,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060971B4 tst r1,r1
    if (!c.t) { goto L_060971C6; }  // 060971B6 bf 0x060971C6
    c.r[1] = c.r[14];  // 060971B8 mov r14,r1
    c.r[2] = c.r[14];  // 060971BA mov r14,r2
    c.r[2] += 24;  // 060971BC add #24,r2
    c.r[1] = 0x4u;  // 060971BE mov #4,r1
    st8(c.r[2], c.r[1]);  // 060971C0 mov.b r1,@r2
    goto L_060971EE;  // 060971C2 bra 0x060971EE ; nop
L_060971C6:
    c.r[0] = ld32(c.r[14] + 12);  // 060971C6 mov.l @(12,r14),r0
    c.t = c.r[0] == 0x1u;  // 060971C8 cmp/eq #1,r0
    if (!c.t) { goto L_060971DA; }  // 060971CA bf 0x060971DA
    c.r[1] = c.r[14];  // 060971CC mov r14,r1
    c.r[2] = c.r[14];  // 060971CE mov r14,r2
    c.r[2] += 24;  // 060971D0 add #24,r2
    c.r[1] = 0x0u;  // 060971D2 mov #0,r1
    st8(c.r[2], c.r[1]);  // 060971D4 mov.b r1,@r2
    goto L_060971EE;  // 060971D6 bra 0x060971EE ; nop
L_060971DA:
    c.r[4] = 0xFFFFFFEFu;  // 060971DA mov #-17,r4
    c.r[8] = ld32(0x0609723Cu);  // 060971DC mov.l 0x0609723C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060971E2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060971E2u) return; }  // 060971DE jsr @r8 ; nop
    c.r[8] = ld32(0x06097240u);  // 060971E2 mov.l 0x06097240,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060971E8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060971E8u) return; }  // 060971E4 jsr @r8 ; nop
    c.r[0] = 0x0u;  // 060971E8 mov #0,r0
    goto L_06097226;  // 060971EA bra 0x06097226 ; nop
L_060971EE:
    c.r[1] = c.r[14];  // 060971EE mov r14,r1
    c.r[2] = c.r[14];  // 060971F0 mov r14,r2
    c.r[2] += 24;  // 060971F2 add #24,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060971F4 mov.b @r2,r3
    c.r[1] = c.r[3] & 0xFFu;  // 060971F6 extu.b r3,r1
    c.r[2] = ld32(c.r[14] + 8);  // 060971F8 mov.l @(8,r14),r2
    c.r[3] = ld32(c.r[14] + 4);  // 060971FA mov.l @(4,r14),r3
    c.r[7] = c.r[1];  // 060971FC mov r1,r7
    c.r[6] = c.r[2];  // 060971FE mov r2,r6
    c.r[5] = c.r[3];  // 06097200 mov r3,r5
    c.r[4] = ld32(c.r[14]);  // 06097202 mov.l @r14,r4
    c.r[8] = ld32(0x06097244u);  // 06097204 mov.l 0x06097244,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0609720Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609720Au) return; }  // 06097206 jsr @r8 ; nop
    st32(c.r[14] + 16, c.r[0]);  // 0609720A mov.l r0,@(16,r14)
    c.r[8] = ld32(0x06097248u);  // 0609720C mov.l 0x06097248,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06097212u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06097212u) return; }  // 0609720E jsr @r8 ; nop
    st32(c.r[14] + 20, c.r[0]);  // 06097212 mov.l r0,@(20,r14)
    c.r[1] = ld32(c.r[14] + 20);  // 06097214 mov.l @(20,r14),r1
    c.t = (int32_t)c.r[1] >= 0;  // 06097216 cmp/pz r1
    if (c.t) { goto L_06097220; }  // 06097218 bt 0x06097220
    c.r[0] = 0x0u;  // 0609721A mov #0,r0
    goto L_06097226;  // 0609721C bra 0x06097226 ; nop
L_06097220:
    c.r[0] = ld32(c.r[14] + 16);  // 06097220 mov.l @(16,r14),r0
    goto L_06097226;  // 06097222 bra 0x06097226 ; nop
L_06097226:
    c.r[14] += 28;  // 06097226 add #28,r14
    c.r[15] = c.r[14];  // 06097228 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609722A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609722C mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0609722E mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06097230 rts ; nop
}

void f_0609724C(SH2Context& c) {
    ran[2294] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609724C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609724E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06097250 sts.l pr,@-r15
    c.r[15] -= 40;  // 06097252 add #-40,r15
    c.r[14] = c.r[15];  // 06097254 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06097256 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 06097258 mov.l r5,@(4,r14)
    st32(c.r[14] + 8, c.r[6]);  // 0609725A mov.l r6,@(8,r14)
    st32(c.r[14] + 12, c.r[7]);  // 0609725C mov.l r7,@(12,r14)
    c.r[1] = (uint32_t)(int16_t)ld16(0x06097394u);  // 0609725E mov.w 0x06097394,r1
    c.r[4] = c.r[1];  // 06097260 mov r1,r4
    c.r[8] = ld32(0x0609739Cu);  // 06097262 mov.l 0x0609739C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06097268u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06097268u) return; }  // 06097264 jsr @r8 ; nop
    c.r[1] = ld32(c.r[14]);  // 06097268 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609726A tst r1,r1
    if (!c.t) { goto L_06097282; }  // 0609726C bf 0x06097282
    c.r[4] = 0xFFFFFFF5u;  // 0609726E mov #-11,r4
    c.r[8] = ld32(0x060973A0u);  // 06097270 mov.l 0x060973A0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06097276u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06097276u) return; }  // 06097272 jsr @r8 ; nop
    c.r[8] = ld32(0x060973A4u);  // 06097276 mov.l 0x060973A4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0609727Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609727Cu) return; }  // 06097278 jsr @r8 ; nop
    c.r[0] = 0x0u;  // 0609727C mov #0,r0
    goto L_06097386;  // 0609727E bra 0x06097386 ; nop
L_06097282:
    c.r[1] = ld32(c.r[14] + 4);  // 06097282 mov.l @(4,r14),r1
    c.r[2] = ld32(c.r[1]);  // 06097284 mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06097396u);  // 06097286 mov.w 0x06097396,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 06097288 cmp/gt r1,r2
    if (!c.t) { goto L_06097298; }  // 0609728A bf 0x06097298
    c.r[1] = ld32(c.r[14] + 4);  // 0609728C mov.l @(4,r14),r1
    c.r[2] = ld32(c.r[1] + 4);  // 0609728E mov.l @(4,r1),r2
    c.t = (int32_t)c.r[2] >= 0;  // 06097290 cmp/pz r2
    if (!c.t) { goto L_06097298; }  // 06097292 bf 0x06097298
    goto L_060972AC;  // 06097294 bra 0x060972AC ; nop
L_06097298:
    c.r[4] = 0xFFFFFFF2u;  // 06097298 mov #-14,r4
    c.r[8] = ld32(0x060973A0u);  // 0609729A mov.l 0x060973A0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060972A0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060972A0u) return; }  // 0609729C jsr @r8 ; nop
    c.r[8] = ld32(0x060973A4u);  // 060972A0 mov.l 0x060973A4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060972A6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060972A6u) return; }  // 060972A2 jsr @r8 ; nop
    c.r[0] = 0x0u;  // 060972A6 mov #0,r0
    goto L_06097386;  // 060972A8 bra 0x06097386 ; nop
L_060972AC:
    c.r[2] = c.r[14];  // 060972AC mov r14,r2
    c.r[1] = c.r[14];  // 060972AE mov r14,r1
    c.r[1] += 16;  // 060972B0 add #16,r1
    c.r[2] = ld32(c.r[14] + 4);  // 060972B2 mov.l @(4,r14),r2
    c.r[3] = ld32(c.r[2]);  // 060972B4 mov.l @r2,r3
    st32(c.r[1], c.r[3]);  // 060972B6 mov.l r3,@r1
    c.r[2] = c.r[14];  // 060972B8 mov r14,r2
    c.r[1] = c.r[14];  // 060972BA mov r14,r1
    c.r[1] += 16;  // 060972BC add #16,r1
    c.r[2] = ld32(c.r[14] + 4);  // 060972BE mov.l @(4,r14),r2
    c.r[3] = ld32(c.r[2] + 4);  // 060972C0 mov.l @(4,r2),r3
    c.r[2] = (uint32_t)(int16_t)ld16(0x06097398u);  // 060972C2 mov.w 0x06097398,r2
    c.macl = c.r[3] * c.r[2];  // 060972C4 mul.l r2,r3
    c.r[2] = c.macl;  // 060972C6 sts macl,r2
    st32(c.r[1] + 4, c.r[2]);  // 060972C8 mov.l r2,@(4,r1)
    c.r[1] = c.r[14];  // 060972CA mov r14,r1
    c.r[3] = c.r[14];  // 060972CC mov r14,r3
    c.r[3] += 16;  // 060972CE add #16,r3
    c.r[2] = c.r[3];  // 060972D0 mov r3,r2
    c.r[1] = c.r[3];  // 060972D2 mov r3,r1
    c.r[1] += 10;  // 060972D4 add #10,r1
    c.r[3] = ld32(c.r[14] + 8);  // 060972D6 mov.l @(8,r14),r3
    c.r[2] = c.r[3];  // 060972D8 mov r3,r2
    c.r[3] += 1;  // 060972DA add #1,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060972DC mov.b @r3,r2
    st8(c.r[1], c.r[2]);  // 060972DE mov.b r2,@r1
    c.r[1] = c.r[14];  // 060972E0 mov r14,r1
    c.r[2] = c.r[14];  // 060972E2 mov r14,r2
    c.r[2] += 16;  // 060972E4 add #16,r2
    c.r[1] = c.r[2];  // 060972E6 mov r2,r1
    c.r[2] += 11;  // 060972E8 add #11,r2
    c.r[1] = 0x0u;  // 060972EA mov #0,r1
    st8(c.r[2], c.r[1]);  // 060972EC mov.b r1,@r2
    c.r[1] = c.r[14];  // 060972EE mov r14,r1
    c.r[2] = c.r[14];  // 060972F0 mov r14,r2
    c.r[2] += 16;  // 060972F2 add #16,r2
    c.r[1] = c.r[2];  // 060972F4 mov r2,r1
    c.r[2] += 8;  // 060972F6 add #8,r2
    c.r[1] = 0x1u;  // 060972F8 mov #1,r1
    st8(c.r[2], c.r[1]);  // 060972FA mov.b r1,@r2
    c.r[1] = c.r[14];  // 060972FC mov r14,r1
    c.r[2] = c.r[14];  // 060972FE mov r14,r2
    c.r[2] += 16;  // 06097300 add #16,r2
    c.r[1] = c.r[2];  // 06097302 mov r2,r1
    c.r[2] += 9;  // 06097304 add #9,r2
    c.r[1] = 0x0u;  // 06097306 mov #0,r1
    st8(c.r[2], c.r[1]);  // 06097308 mov.b r1,@r2
    c.r[1] = ld32(c.r[14] + 12);  // 0609730A mov.l @(12,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609730C tst r1,r1
    if (!c.t) { goto L_0609731E; }  // 0609730E bf 0x0609731E
    c.r[1] = c.r[14];  // 06097310 mov r14,r1
    c.r[2] = c.r[14];  // 06097312 mov r14,r2
    c.r[2] += 36;  // 06097314 add #36,r2
    c.r[1] = 0x4u;  // 06097316 mov #4,r1
    st8(c.r[2], c.r[1]);  // 06097318 mov.b r1,@r2
    goto L_06097346;  // 0609731A bra 0x06097346 ; nop
L_0609731E:
    c.r[0] = ld32(c.r[14] + 12);  // 0609731E mov.l @(12,r14),r0
    c.t = c.r[0] == 0x1u;  // 06097320 cmp/eq #1,r0
    if (!c.t) { goto L_06097332; }  // 06097322 bf 0x06097332
    c.r[1] = c.r[14];  // 06097324 mov r14,r1
    c.r[2] = c.r[14];  // 06097326 mov r14,r2
    c.r[2] += 36;  // 06097328 add #36,r2
    c.r[1] = 0x0u;  // 0609732A mov #0,r1
    st8(c.r[2], c.r[1]);  // 0609732C mov.b r1,@r2
    goto L_06097346;  // 0609732E bra 0x06097346 ; nop
L_06097332:
    c.r[4] = 0xFFFFFFEFu;  // 06097332 mov #-17,r4
    c.r[8] = ld32(0x060973A0u);  // 06097334 mov.l 0x060973A0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0609733Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609733Au) return; }  // 06097336 jsr @r8 ; nop
    c.r[8] = ld32(0x060973A4u);  // 0609733A mov.l 0x060973A4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06097340u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06097340u) return; }  // 0609733C jsr @r8 ; nop
    c.r[0] = 0x0u;  // 06097340 mov #0,r0
    goto L_06097386;  // 06097342 bra 0x06097386 ; nop
L_06097346:
    c.r[1] = ld32(c.r[14] + 8);  // 06097346 mov.l @(8,r14),r1
    c.r[2] = ld32(0x060973A8u);  // 06097348 mov.l 0x060973A8,r2
    c.r[3] = c.r[14];  // 0609734A mov r14,r3
    c.r[3] += 16;  // 0609734C add #16,r3
    c.r[7] = c.r[14];  // 0609734E mov r14,r7
    c.r[6] = c.r[14];  // 06097350 mov r14,r6
    c.r[6] += 36;  // 06097352 add #36,r6
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[6]);  // 06097354 mov.b @r6,r5
    c.r[7] = c.r[5] & 0xFFu;  // 06097356 extu.b r5,r7
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 06097358 mov.l r7,@-r15
    c.r[7] = c.r[1];  // 0609735A mov r1,r7
    c.r[6] = c.r[2];  // 0609735C mov r2,r6
    c.r[5] = c.r[3];  // 0609735E mov r3,r5
    c.r[4] = ld32(c.r[14]);  // 06097360 mov.l @r14,r4
    c.r[8] = ld32(0x060973ACu);  // 06097362 mov.l 0x060973AC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06097368u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06097368u) return; }  // 06097364 jsr @r8 ; nop
    c.r[15] += 4;  // 06097368 add #4,r15
    st32(c.r[14] + 28, c.r[0]);  // 0609736A mov.l r0,@(28,r14)
    c.r[8] = ld32(0x060973B0u);  // 0609736C mov.l 0x060973B0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06097372u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06097372u) return; }  // 0609736E jsr @r8 ; nop
    st32(c.r[14] + 32, c.r[0]);  // 06097372 mov.l r0,@(32,r14)
    c.r[1] = ld32(c.r[14] + 32);  // 06097374 mov.l @(32,r14),r1
    c.t = (int32_t)c.r[1] >= 0;  // 06097376 cmp/pz r1
    if (c.t) { goto L_06097380; }  // 06097378 bt 0x06097380
    c.r[0] = 0x0u;  // 0609737A mov #0,r0
    goto L_06097386;  // 0609737C bra 0x06097386 ; nop
L_06097380:
    c.r[0] = ld32(c.r[14] + 28);  // 06097380 mov.l @(28,r14),r0
    goto L_06097386;  // 06097382 bra 0x06097386 ; nop
L_06097386:
    c.r[14] += 40;  // 06097386 add #40,r14
    c.r[15] = c.r[14];  // 06097388 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609738A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609738C mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0609738E mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06097390 rts ; nop
}

void f_060973B4(SH2Context& c) {
    ran[2295] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060973B4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060973B6 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060973B8 sts.l pr,@-r15
    c.r[15] -= 8;  // 060973BA add #-8,r15
    c.r[14] = c.r[15];  // 060973BC mov r15,r14
    st32(c.r[14], c.r[4]);  // 060973BE mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 060973C0 mov.l r5,@(4,r14)
    c.r[2] = ld32(c.r[14]);  // 060973C2 mov.l @r14,r2
    c.r[1] = c.r[2];  // 060973C4 mov r2,r1
    c.r[2] += 44;  // 060973C6 add #44,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060973C8 mov.b @r2,r1
    c.r[2] = 0x2u;  // 060973CA mov #2,r2
    c.r[2] &= c.r[1];  // 060973CC and r1,r2
    c.r[1] = c.r[2] & 0xFFu;  // 060973CE extu.b r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060973D0 tst r1,r1
    if (c.t) { goto L_060973E4; }  // 060973D2 bt 0x060973E4
    c.r[2] = ld32(c.r[14]);  // 060973D4 mov.l @r14,r2
    c.r[1] = ld32(c.r[2] + 16);  // 060973D6 mov.l @(16,r2),r1
    c.r[6] = 0x0u;  // 060973D8 mov #0,r6
    c.r[5] = 0x0u;  // 060973DA mov #0,r5
    c.r[4] = c.r[1];  // 060973DC mov r1,r4
    c.r[8] = ld32(0x06097404u);  // 060973DE mov.l 0x06097404,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060973E4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060973E4u) return; }  // 060973E0 jsr @r8 ; nop
L_060973E4:
    c.r[1] = ld32(c.r[14]);  // 060973E4 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 16);  // 060973E6 mov.l @(16,r1),r2
    c.r[1] = c.r[2];  // 060973E8 mov r2,r1
    c.r[1] += 108;  // 060973EA add #108,r1
    c.r[2] = 0x0u;  // 060973EC mov #0,r2
    st32(c.r[1] + 52, c.r[2]);  // 060973EE mov.l r2,@(52,r1)
    c.r[1] = ld32(c.r[14]);  // 060973F0 mov.l @r14,r1
    c.r[2] = ld32(c.r[14] + 4);  // 060973F2 mov.l @(4,r14),r2
    st32(c.r[1] + 40, c.r[2]);  // 060973F4 mov.l r2,@(40,r1)
    c.r[14] += 8;  // 060973F6 add #8,r14
    c.r[15] = c.r[14];  // 060973F8 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060973FA lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060973FC mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060973FE mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06097400 rts ; nop
}

void f_06097408(SH2Context& c) {
    ran[2296] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06097408 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609740A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609740C sts.l pr,@-r15
    c.r[15] -= 8;  // 0609740E add #-8,r15
    c.r[14] = c.r[15];  // 06097410 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06097412 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 06097414 mov.l r5,@(4,r14)
    c.r[1] = (uint32_t)(int16_t)ld16(0x06097476u);  // 06097416 mov.w 0x06097476,r1
    c.r[4] = c.r[1];  // 06097418 mov r1,r4
    c.r[8] = ld32(0x06097478u);  // 0609741A mov.l 0x06097478,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06097420u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06097420u) return; }  // 0609741C jsr @r8 ; nop
    c.r[1] = ld32(c.r[14]);  // 06097420 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06097422 tst r1,r1
    if (!c.t) { goto L_06097438; }  // 06097424 bf 0x06097438
    c.r[4] = 0xFFFFFFF5u;  // 06097426 mov #-11,r4
    c.r[8] = ld32(0x0609747Cu);  // 06097428 mov.l 0x0609747C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0609742Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609742Eu) return; }  // 0609742A jsr @r8 ; nop
    c.r[8] = ld32(0x06097480u);  // 0609742E mov.l 0x06097480,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06097434u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06097434u) return; }  // 06097430 jsr @r8 ; nop
    goto L_06097468;  // 06097434 bra 0x06097468 ; nop
L_06097438:
    c.r[1] = ld32(c.r[14] + 4);  // 06097438 mov.l @(4,r14),r1
    c.t = (int32_t)c.r[1] >= 0;  // 0609743A cmp/pz r1
    if (c.t) { goto L_06097450; }  // 0609743C bt 0x06097450
    c.r[4] = 0xFFFFFFF2u;  // 0609743E mov #-14,r4
    c.r[8] = ld32(0x0609747Cu);  // 06097440 mov.l 0x0609747C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06097446u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06097446u) return; }  // 06097442 jsr @r8 ; nop
    c.r[8] = ld32(0x06097480u);  // 06097446 mov.l 0x06097480,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0609744Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609744Cu) return; }  // 06097448 jsr @r8 ; nop
    goto L_06097468;  // 0609744C bra 0x06097468 ; nop
L_06097450:
    c.r[1] = ld32(c.r[14]);  // 06097450 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 4);  // 06097452 mov.l @(4,r1),r2
    st32(c.r[14], c.r[2]);  // 06097454 mov.l r2,@r14
    c.r[1] = ld32(c.r[14] + 4);  // 06097456 mov.l @(4,r14),r1
    c.r[5] = c.r[1];  // 06097458 mov r1,r5
    c.r[4] = ld32(c.r[14]);  // 0609745A mov.l @r14,r4
    c.r[8] = ld32(0x06097484u);  // 0609745C mov.l 0x06097484,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06097462u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06097462u) return; }  // 0609745E jsr @r8 ; nop
    c.r[8] = ld32(0x06097488u);  // 06097462 mov.l 0x06097488,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06097468u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06097468u) return; }  // 06097464 jsr @r8 ; nop
L_06097468:
    c.r[14] += 8;  // 06097468 add #8,r14
    c.r[15] = c.r[14];  // 0609746A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609746C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609746E mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06097470 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06097472 rts ; nop
}

void f_0609748C(SH2Context& c) {
    ran[2297] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609748C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609748E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06097490 sts.l pr,@-r15
    c.r[15] -= 24;  // 06097492 add #-24,r15
    c.r[14] = c.r[15];  // 06097494 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06097496 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 06097498 mov.l r5,@(4,r14)
    st32(c.r[14] + 8, c.r[6]);  // 0609749A mov.l r6,@(8,r14)
    st32(c.r[14] + 12, c.r[7]);  // 0609749C mov.l r7,@(12,r14)
    c.r[1] = (uint32_t)(int16_t)ld16(0x06097532u);  // 0609749E mov.w 0x06097532,r1
    c.r[4] = c.r[1];  // 060974A0 mov r1,r4
    c.r[8] = ld32(0x06097534u);  // 060974A2 mov.l 0x06097534,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060974A8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060974A8u) return; }  // 060974A4 jsr @r8 ; nop
    c.r[1] = ld32(c.r[14]);  // 060974A8 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060974AA tst r1,r1
    if (!c.t) { goto L_060974C2; }  // 060974AC bf 0x060974C2
    c.r[4] = 0xFFFFFFF5u;  // 060974AE mov #-11,r4
    c.r[8] = ld32(0x06097538u);  // 060974B0 mov.l 0x06097538,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060974B6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060974B6u) return; }  // 060974B2 jsr @r8 ; nop
    c.r[8] = ld32(0x0609753Cu);  // 060974B6 mov.l 0x0609753C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060974BCu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060974BCu) return; }  // 060974B8 jsr @r8 ; nop
    c.r[0] = 0x0u;  // 060974BC mov #0,r0
    goto L_06097524;  // 060974BE bra 0x06097524 ; nop
L_060974C2:
    c.r[1] = ld32(c.r[14] + 12);  // 060974C2 mov.l @(12,r14),r1
    c.t = (int32_t)c.r[1] >= 0;  // 060974C4 cmp/pz r1
    if (c.t) { goto L_060974DC; }  // 060974C6 bt 0x060974DC
    c.r[4] = 0xFFFFFFF2u;  // 060974C8 mov #-14,r4
    c.r[8] = ld32(0x06097538u);  // 060974CA mov.l 0x06097538,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060974D0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060974D0u) return; }  // 060974CC jsr @r8 ; nop
    c.r[8] = ld32(0x0609753Cu);  // 060974D0 mov.l 0x0609753C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060974D6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060974D6u) return; }  // 060974D2 jsr @r8 ; nop
    c.r[0] = 0x0u;  // 060974D6 mov #0,r0
    goto L_06097524;  // 060974D8 bra 0x06097524 ; nop
L_060974DC:
    c.r[1] = ld32(c.r[14] + 8);  // 060974DC mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[14] + 4);  // 060974DE mov.l @(4,r14),r2
    c.r[7] = 0x6u;  // 060974E0 mov #6,r7
    c.r[6] = c.r[1];  // 060974E2 mov r1,r6
    c.r[5] = c.r[2];  // 060974E4 mov r2,r5
    c.r[4] = ld32(c.r[14]);  // 060974E6 mov.l @r14,r4
    c.r[8] = ld32(0x06097540u);  // 060974E8 mov.l 0x06097540,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060974EEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060974EEu) return; }  // 060974EA jsr @r8 ; nop
    st32(c.r[14] + 16, c.r[0]);  // 060974EE mov.l r0,@(16,r14)
    c.r[1] = ld32(c.r[14] + 16);  // 060974F0 mov.l @(16,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060974F2 tst r1,r1
    if (!c.t) { goto L_060974FC; }  // 060974F4 bf 0x060974FC
    c.r[0] = 0x0u;  // 060974F6 mov #0,r0
    goto L_06097524;  // 060974F8 bra 0x06097524 ; nop
L_060974FC:
    c.r[1] = ld32(c.r[14] + 12);  // 060974FC mov.l @(12,r14),r1
    c.r[2] = ld32(c.r[14] + 16);  // 060974FE mov.l @(16,r14),r2
    c.r[5] = c.r[1];  // 06097500 mov r1,r5
    c.r[4] = c.r[2];  // 06097502 mov r2,r4
    c.r[8] = ld32(0x06097544u);  // 06097504 mov.l 0x06097544,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0609750Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609750Au) return; }  // 06097506 jsr @r8 ; nop
    c.r[8] = ld32(0x06097548u);  // 0609750A mov.l 0x06097548,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06097510u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06097510u) return; }  // 0609750C jsr @r8 ; nop
    st32(c.r[14] + 20, c.r[0]);  // 06097510 mov.l r0,@(20,r14)
    c.r[1] = ld32(c.r[14] + 20);  // 06097512 mov.l @(20,r14),r1
    c.t = (int32_t)c.r[1] >= 0;  // 06097514 cmp/pz r1
    if (c.t) { goto L_0609751E; }  // 06097516 bt 0x0609751E
    c.r[0] = 0x0u;  // 06097518 mov #0,r0
    goto L_06097524;  // 0609751A bra 0x06097524 ; nop
L_0609751E:
    c.r[0] = ld32(c.r[14] + 16);  // 0609751E mov.l @(16,r14),r0
    goto L_06097524;  // 06097520 bra 0x06097524 ; nop
L_06097524:
    c.r[14] += 24;  // 06097524 add #24,r14
    c.r[15] = c.r[14];  // 06097526 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06097528 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609752A mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0609752C mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0609752E rts ; nop
}

void f_0609754C(SH2Context& c) {
    ran[2298] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609754C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609754E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06097550 sts.l pr,@-r15
    c.r[15] -= 4;  // 06097552 add #-4,r15
    c.r[14] = c.r[15];  // 06097554 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06097556 mov.l r4,@r14
    c.r[1] = (uint32_t)(int16_t)ld16(0x060975ACu);  // 06097558 mov.w 0x060975AC,r1
    c.r[4] = c.r[1];  // 0609755A mov r1,r4
    c.r[8] = ld32(0x060975B0u);  // 0609755C mov.l 0x060975B0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06097562u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06097562u) return; }  // 0609755E jsr @r8 ; nop
    c.r[1] = ld32(c.r[14]);  // 06097562 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06097564 tst r1,r1
    if (!c.t) { goto L_06097576; }  // 06097566 bf 0x06097576
    c.r[4] = 0xFFFFFFF5u;  // 06097568 mov #-11,r4
    c.r[8] = ld32(0x060975B4u);  // 0609756A mov.l 0x060975B4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06097570u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06097570u) return; }  // 0609756C jsr @r8 ; nop
    c.r[8] = ld32(0x060975B8u);  // 06097570 mov.l 0x060975B8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06097576u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06097576u) return; }  // 06097572 jsr @r8 ; nop
L_06097576:
    c.r[1] = ld32(c.r[14]);  // 06097576 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 4);  // 06097578 mov.l @(4,r1),r2
    st32(c.r[14], c.r[2]);  // 0609757A mov.l r2,@r14
    c.r[4] = ld32(c.r[14]);  // 0609757C mov.l @r14,r4
    c.r[8] = ld32(0x060975BCu);  // 0609757E mov.l 0x060975BC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06097584u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06097584u) return; }  // 06097580 jsr @r8 ; nop
    c.r[1] = ld32(0x060975C0u);  // 06097584 mov.l 0x060975C0,r1
    c.r[2] = ld32(c.r[1]);  // 06097586 mov.l @r1,r2
    c.r[1] = c.r[2];  // 06097588 mov r2,r1
    c.r[1] += 28;  // 0609758A add #28,r1
    c.r[2] = ld32(c.r[1]);  // 0609758C mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0609758E tst r2,r2
    if (c.t) { goto L_06097598; }  // 06097590 bt 0x06097598
    c.r[8] = ld32(0x060975B8u);  // 06097592 mov.l 0x060975B8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06097598u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06097598u) return; }  // 06097594 jsr @r8 ; nop
L_06097598:
    c.r[8] = ld32(0x060975C4u);  // 06097598 mov.l 0x060975C4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0609759Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609759Eu) return; }  // 0609759A jsr @r8 ; nop
    c.r[14] += 4;  // 0609759E add #4,r14
    c.r[15] = c.r[14];  // 060975A0 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060975A2 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060975A4 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060975A6 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060975A8 rts ; nop
}

void f_060975C8(SH2Context& c) {
    ran[2299] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060975C8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060975CA mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060975CC sts.l pr,@-r15
    c.r[15] -= 28;  // 060975CE add #-28,r15
    c.r[14] = c.r[15];  // 060975D0 mov r15,r14
    st32(c.r[14], c.r[4]);  // 060975D2 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 060975D4 mov.l r5,@(4,r14)
    c.r[1] = (uint32_t)(int16_t)ld16(0x06097708u);  // 060975D6 mov.w 0x06097708,r1
    c.r[4] = c.r[1];  // 060975D8 mov r1,r4
    c.r[8] = ld32(0x0609770Cu);  // 060975DA mov.l 0x0609770C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060975E0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060975E0u) return; }  // 060975DC jsr @r8 ; nop
    c.r[1] = ld32(c.r[14]);  // 060975E0 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060975E2 tst r1,r1
    if (!c.t) { goto L_060975F8; }  // 060975E4 bf 0x060975F8
    c.r[4] = 0xFFFFFFF5u;  // 060975E6 mov #-11,r4
    c.r[8] = ld32(0x06097710u);  // 060975E8 mov.l 0x06097710,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060975EEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060975EEu) return; }  // 060975EA jsr @r8 ; nop
    c.r[8] = ld32(0x06097714u);  // 060975EE mov.l 0x06097714,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060975F4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060975F4u) return; }  // 060975F0 jsr @r8 ; nop
    goto L_060976FA;  // 060975F4 bra 0x060976FA ; nop
L_060975F8:
    c.r[1] = ld32(c.r[14]);  // 060975F8 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 4);  // 060975FA mov.l @(4,r1),r2
    st32(c.r[14], c.r[2]);  // 060975FC mov.l r2,@r14
    c.r[1] = ld32(c.r[14]);  // 060975FE mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 20);  // 06097600 mov.l @(20,r1),r2
    c.r[1] = c.r[2];  // 06097602 mov r2,r1
    c.r[1] += 28;  // 06097604 add #28,r1
    c.r[2] = ld32(c.r[1]);  // 06097606 mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06097608 tst r2,r2
    if (c.t) { goto L_06097610; }  // 0609760A bt 0x06097610
    goto L_060976FA;  // 0609760C bra 0x060976FA ; nop
L_06097610:
    c.r[2] = c.r[14];  // 06097610 mov r14,r2
    c.r[1] = c.r[14];  // 06097612 mov r14,r1
    c.r[1] += 8;  // 06097614 add #8,r1
    c.r[3] = ld32(c.r[14] + 4);  // 06097616 mov.l @(4,r14),r3
    c.r[2] = c.r[3];  // 06097618 mov r3,r2
    c.r[3] += 1;  // 0609761A add #1,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0609761C mov.b @r3,r2
    st8(c.r[1], c.r[2]);  // 0609761E mov.b r2,@r1
    c.r[1] = c.r[14];  // 06097620 mov r14,r1
    c.r[3] = c.r[14];  // 06097622 mov r14,r3
    c.r[3] += 8;  // 06097624 add #8,r3
    c.r[2] = c.r[3];  // 06097626 mov r3,r2
    c.r[1] = c.r[3];  // 06097628 mov r3,r1
    c.r[1] += 1;  // 0609762A add #1,r1
    c.r[3] = ld32(c.r[14] + 4);  // 0609762C mov.l @(4,r14),r3
    c.r[2] = c.r[3];  // 0609762E mov r3,r2
    c.r[3] += 2;  // 06097630 add #2,r3
    c.r[2] = c.r[3];  // 06097632 mov r3,r2
    c.r[3] += 1;  // 06097634 add #1,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06097636 mov.b @r3,r2
    st8(c.r[1], c.r[2]);  // 06097638 mov.b r2,@r1
    c.r[1] = c.r[14];  // 0609763A mov r14,r1
    c.r[3] = c.r[14];  // 0609763C mov r14,r3
    c.r[3] += 8;  // 0609763E add #8,r3
    c.r[2] = c.r[3];  // 06097640 mov r3,r2
    c.r[1] = c.r[3];  // 06097642 mov r3,r1
    c.r[1] += 2;  // 06097644 add #2,r1
    c.r[3] = ld32(c.r[14] + 4);  // 06097646 mov.l @(4,r14),r3
    c.r[2] = c.r[3];  // 06097648 mov r3,r2
    c.r[3] += 4;  // 0609764A add #4,r3
    c.r[2] = c.r[3];  // 0609764C mov r3,r2
    c.r[3] += 1;  // 0609764E add #1,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06097650 mov.b @r3,r2
    st8(c.r[1], c.r[2]);  // 06097652 mov.b r2,@r1
    c.r[1] = c.r[14];  // 06097654 mov r14,r1
    c.r[3] = c.r[14];  // 06097656 mov r14,r3
    c.r[3] += 8;  // 06097658 add #8,r3
    c.r[2] = c.r[3];  // 0609765A mov r3,r2
    c.r[1] = c.r[3];  // 0609765C mov r3,r1
    c.r[1] += 3;  // 0609765E add #3,r1
    c.r[3] = ld32(c.r[14] + 4);  // 06097660 mov.l @(4,r14),r3
    c.r[2] = c.r[3];  // 06097662 mov r3,r2
    c.r[3] += 6;  // 06097664 add #6,r3
    c.r[2] = c.r[3];  // 06097666 mov r3,r2
    c.r[3] += 1;  // 06097668 add #1,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0609766A mov.b @r3,r2
    st8(c.r[1], c.r[2]);  // 0609766C mov.b r2,@r1
    c.r[1] = c.r[14];  // 0609766E mov r14,r1
    c.r[3] = c.r[14];  // 06097670 mov r14,r3
    c.r[3] += 8;  // 06097672 add #8,r3
    c.r[2] = c.r[3];  // 06097674 mov r3,r2
    c.r[1] = c.r[3];  // 06097676 mov r3,r1
    c.r[1] += 4;  // 06097678 add #4,r1
    c.r[3] = ld32(c.r[14] + 4);  // 0609767A mov.l @(4,r14),r3
    c.r[2] = c.r[3];  // 0609767C mov r3,r2
    c.r[3] += 8;  // 0609767E add #8,r3
    c.r[2] = c.r[3];  // 06097680 mov r3,r2
    c.r[3] += 1;  // 06097682 add #1,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06097684 mov.b @r3,r2
    st8(c.r[1], c.r[2]);  // 06097686 mov.b r2,@r1
    c.r[1] = c.r[14];  // 06097688 mov r14,r1
    c.r[3] = c.r[14];  // 0609768A mov r14,r3
    c.r[3] += 8;  // 0609768C add #8,r3
    c.r[2] = c.r[3];  // 0609768E mov r3,r2
    c.r[1] = c.r[3];  // 06097690 mov r3,r1
    c.r[1] += 5;  // 06097692 add #5,r1
    c.r[3] = ld32(c.r[14] + 4);  // 06097694 mov.l @(4,r14),r3
    c.r[2] = c.r[3];  // 06097696 mov r3,r2
    c.r[3] += 10;  // 06097698 add #10,r3
    c.r[2] = c.r[3];  // 0609769A mov r3,r2
    c.r[3] += 1;  // 0609769C add #1,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0609769E mov.b @r3,r2
    st8(c.r[1], c.r[2]);  // 060976A0 mov.b r2,@r1
    c.r[1] = ld32(c.r[14] + 4);  // 060976A2 mov.l @(4,r14),r1
    c.r[4] = c.r[1];  // 060976A4 mov r1,r4
    c.r[8] = ld32(0x06097718u);  // 060976A6 mov.l 0x06097718,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060976ACu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060976ACu) return; }  // 060976A8 jsr @r8 ; nop
    st32(c.r[14] + 16, c.r[0]);  // 060976AC mov.l r0,@(16,r14)
    c.r[1] = ld32(c.r[14]);  // 060976AE mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 20);  // 060976B0 mov.l @(20,r1),r2
    st32(c.r[14] + 20, c.r[2]);  // 060976B2 mov.l r2,@(20,r14)
    c.r[2] = ld32(c.r[14] + 20);  // 060976B4 mov.l @(20,r14),r2
    c.r[1] = ld32(c.r[2] + 4);  // 060976B6 mov.l @(4,r2),r1
    c.r[2] = c.r[14];  // 060976B8 mov r14,r2
    c.r[2] += 8;  // 060976BA add #8,r2
    c.r[3] = ld32(c.r[14] + 16);  // 060976BC mov.l @(16,r14),r3
    c.r[7] = ld32(c.r[14]);  // 060976BE mov.l @r14,r7
    c.r[6] = ld32(c.r[7] + 20);  // 060976C0 mov.l @(20,r7),r6
    c.r[7] = c.r[6];  // 060976C2 mov r6,r7
    c.r[7] += 28;  // 060976C4 add #28,r7
    c.r[4] = ld32(c.r[7] + 12);  // 060976C6 mov.l @(12,r7),r4
    c.r[7] = ld32(c.r[14] + 20);  // 060976C8 mov.l @(20,r14),r7
    c.r[6] = ld32(c.r[7] + 20);  // 060976CA mov.l @(20,r7),r6
    c.r[15] -= 4; st32(c.r[15], c.r[6]);  // 060976CC mov.l r6,@-r15
    c.r[7] = c.r[1];  // 060976CE mov r1,r7
    c.r[6] = c.r[2];  // 060976D0 mov r2,r6
    c.r[5] = c.r[3];  // 060976D2 mov r3,r5
    c.r[8] = ld32(0x0609771Cu);  // 060976D4 mov.l 0x0609771C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060976DAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060976DAu) return; }  // 060976D6 jsr @r8 ; nop
    c.r[15] += 4;  // 060976DA add #4,r15
    c.r[8] = ld32(0x06097720u);  // 060976DC mov.l 0x06097720,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060976E2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060976E2u) return; }  // 060976DE jsr @r8 ; nop
    st32(c.r[14] + 24, c.r[0]);  // 060976E2 mov.l r0,@(24,r14)
    c.r[1] = ld32(c.r[14] + 24);  // 060976E4 mov.l @(24,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060976E6 tst r1,r1
    if (c.t) { goto L_060976FA; }  // 060976E8 bt 0x060976FA
    c.r[1] = ld32(c.r[14] + 24);  // 060976EA mov.l @(24,r14),r1
    c.r[4] = c.r[1];  // 060976EC mov r1,r4
    c.r[8] = ld32(0x06097724u);  // 060976EE mov.l 0x06097724,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060976F4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060976F4u) return; }  // 060976F0 jsr @r8 ; nop
    c.r[8] = ld32(0x06097714u);  // 060976F4 mov.l 0x06097714,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060976FAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060976FAu) return; }  // 060976F6 jsr @r8 ; nop
L_060976FA:
    c.r[14] += 28;  // 060976FA add #28,r14
    c.r[15] = c.r[14];  // 060976FC mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060976FE lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06097700 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06097702 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06097704 rts ; nop
}

void f_06097728(SH2Context& c) {
    ran[2300] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06097728 mov.l r14,@-r15
    c.r[15] -= 4;  // 0609772A add #-4,r15
    c.r[14] = c.r[15];  // 0609772C mov r15,r14
    st32(c.r[14], c.r[4]);  // 0609772E mov.l r4,@r14
    c.r[1] = ld32(0x06097748u);  // 06097730 mov.l 0x06097748,r1
    c.r[2] = ld32(c.r[1]);  // 06097732 mov.l @r1,r2
    c.r[1] = c.r[2];  // 06097734 mov r2,r1
    c.r[1] += 28;  // 06097736 add #28,r1
    c.r[2] = ld32(c.r[14]);  // 06097738 mov.l @r14,r2
    st32(c.r[1] + 4, c.r[2]);  // 0609773A mov.l r2,@(4,r1)
    c.r[14] += 4;  // 0609773C add #4,r14
    c.r[15] = c.r[14];  // 0609773E mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06097740 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06097742 rts ; nop
}

void f_0609774C(SH2Context& c) {
    ran[2301] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609774C mov.l r14,@-r15
    c.r[15] -= 4;  // 0609774E add #-4,r15
    c.r[14] = c.r[15];  // 06097750 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06097752 mov.l r4,@r14
    c.r[1] = ld32(0x06097784u);  // 06097754 mov.l 0x06097784,r1
    c.r[2] = ld32(c.r[1]);  // 06097756 mov.l @r1,r2
    c.r[1] = c.r[2];  // 06097758 mov r2,r1
    c.r[1] += 28;  // 0609775A add #28,r1
    c.r[2] = ld32(c.r[1]);  // 0609775C mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0609775E tst r2,r2
    if (!c.t) { goto L_06097774; }  // 06097760 bf 0x06097774
    c.r[1] = ld32(0x06097784u);  // 06097762 mov.l 0x06097784,r1
    c.r[2] = ld32(c.r[1]);  // 06097764 mov.l @r1,r2
    c.r[1] = c.r[2];  // 06097766 mov r2,r1
    c.r[1] += 28;  // 06097768 add #28,r1
    c.r[2] = ld32(c.r[14]);  // 0609776A mov.l @r14,r2
    st32(c.r[1], c.r[2]);  // 0609776C mov.l r2,@r1
    c.r[0] = 0x1u;  // 0609776E mov #1,r0
    goto L_0609777A;  // 06097770 bra 0x0609777A ; nop
L_06097774:
    c.r[0] = 0x0u;  // 06097774 mov #0,r0
    goto L_0609777A;  // 06097776 bra 0x0609777A ; nop
L_0609777A:
    c.r[14] += 4;  // 0609777A add #4,r14
    c.r[15] = c.r[14];  // 0609777C mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609777E mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06097780 rts ; nop
}

void f_06097788(SH2Context& c) {
    ran[2302] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06097788 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609778A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609778C sts.l pr,@-r15
    c.r[15] -= 8;  // 0609778E add #-8,r15
    c.r[14] = c.r[15];  // 06097790 mov r15,r14
    c.r[2] = ld32(0x06097824u);  // 06097792 mov.l 0x06097824,r2
    c.r[1] = ld32(c.r[2]);  // 06097794 mov.l @r2,r1
    c.r[3] = 0x10u;  // 06097796 mov #16,r3
    c.r[2] = 0xFFFFFFF0u;  // 06097798 mov #-16,r2
    c.r[1] -= c.r[2];  // 0609779A sub r2,r1
    c.t = c.r[1] > c.r[3];  // 0609779C cmp/hi r3,r1
    if (c.t) { goto L_060977EC; }  // 0609779E bt 0x060977EC
    c.r[1] += c.r[1];  // 060977A0 add r1,r1
    c.r[0] = 0x060977ACu;  // 060977A2 mova 0x060977AC,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 060977A4 mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 060977A6 add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x060977E4u: goto L_060977E4; case 0x060977ECu: goto L_060977EC; case 0x060977DCu: goto L_060977DC; case 0x060977D4u: goto L_060977D4; case 0x060977CEu: goto L_060977CE; default: sh2_call(c, x); return; } }  // 060977A8 jmp @r0 ; nop
L_060977CE:
    c.r[0] = 0x0u;  // 060977CE mov #0,r0
    goto L_06097814;  // 060977D0 bra 0x06097814 ; nop
L_060977D4:
    c.r[1] = 0xFFFFFFE9u;  // 060977D4 mov #-23,r1
    st32(c.r[14], c.r[1]);  // 060977D6 mov.l r1,@r14
    goto L_060977F2;  // 060977D8 bra 0x060977F2 ; nop
L_060977DC:
    c.r[1] = 0xFFFFFFFEu;  // 060977DC mov #-2,r1
    st32(c.r[14], c.r[1]);  // 060977DE mov.l r1,@r14
    goto L_060977F2;  // 060977E0 bra 0x060977F2 ; nop
L_060977E4:
    c.r[1] = 0xFFFFFFE7u;  // 060977E4 mov #-25,r1
    st32(c.r[14], c.r[1]);  // 060977E6 mov.l r1,@r14
    goto L_060977F2;  // 060977E8 bra 0x060977F2 ; nop
L_060977EC:
    c.r[0] = 0x0u;  // 060977EC mov #0,r0
    goto L_06097814;  // 060977EE bra 0x06097814 ; nop
L_060977F2:
    c.r[4] = ld32(c.r[14]);  // 060977F2 mov.l @r14,r4
    c.r[8] = ld32(0x06097828u);  // 060977F4 mov.l 0x06097828,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060977FAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060977FAu) return; }  // 060977F6 jsr @r8 ; nop
    st32(c.r[14] + 4, c.r[0]);  // 060977FA mov.l r0,@(4,r14)
    c.r[0] = ld32(c.r[14] + 4);  // 060977FC mov.l @(4,r14),r0
    c.t = c.r[0] == 0x1u;  // 060977FE cmp/eq #1,r0
    if (!c.t) { goto L_0609780E; }  // 06097800 bf 0x0609780E
    c.r[8] = ld32(0x0609782Cu);  // 06097802 mov.l 0x0609782C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06097808u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06097808u) return; }  // 06097804 jsr @r8 ; nop
    c.r[0] = ld32(c.r[14]);  // 06097808 mov.l @r14,r0
    goto L_06097814;  // 0609780A bra 0x06097814 ; nop
L_0609780E:
    c.r[0] = 0x0u;  // 0609780E mov #0,r0
    goto L_06097814;  // 06097810 bra 0x06097814 ; nop
L_06097814:
    c.r[14] += 8;  // 06097814 add #8,r14
    c.r[15] = c.r[14];  // 06097816 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06097818 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609781A mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0609781C mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0609781E rts ; nop
}

void f_06097830(SH2Context& c) {
    ran[2303] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06097830 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06097832 sts.l pr,@-r15
    c.r[15] -= 4;  // 06097834 add #-4,r15
    c.r[14] = c.r[15];  // 06097836 mov r15,r14
    c.r[1] = ld32(0x06097880u);  // 06097838 mov.l 0x06097880,r1
    c.r[2] = ld32(c.r[1]);  // 0609783A mov.l @r1,r2
    c.r[1] = c.r[2];  // 0609783C mov r2,r1
    c.r[1] += 28;  // 0609783E add #28,r1
    st32(c.r[14], c.r[1]);  // 06097840 mov.l r1,@r14
    c.r[1] = ld32(c.r[14]);  // 06097842 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 8);  // 06097844 mov.l @(8,r1),r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06097846 tst r2,r2
    if (c.t) { goto L_0609786C; }  // 06097848 bt 0x0609786C
    c.r[1] = ld32(0x06097880u);  // 0609784A mov.l 0x06097880,r1
    c.r[2] = ld32(c.r[1]);  // 0609784C mov.l @r1,r2
    c.r[1] = c.r[2];  // 0609784E mov r2,r1
    c.r[1] += 28;  // 06097850 add #28,r1
    c.r[2] = ld32(c.r[1]);  // 06097852 mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06097854 tst r2,r2
    if (c.t) { goto L_0609786C; }  // 06097856 bt 0x0609786C
    c.r[1] = ld32(c.r[14]);  // 06097858 mov.l @r14,r1
    c.r[3] = ld32(c.r[14]);  // 0609785A mov.l @r14,r3
    c.r[2] = ld32(c.r[3]);  // 0609785C mov.l @r3,r2
    c.r[7] = ld32(c.r[14]);  // 0609785E mov.l @r14,r7
    c.r[3] = ld32(c.r[7] + 12);  // 06097860 mov.l @(12,r7),r3
    c.r[1] = ld32(c.r[1] + 8);  // 06097862 mov.l @(8,r1),r1
    c.r[5] = c.r[2];  // 06097864 mov r2,r5
    c.r[4] = c.r[3];  // 06097866 mov r3,r4
    { const uint32_t x = c.r[1]; c.pr = 0x0609786Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609786Cu) return; }  // 06097868 jsr @r1 ; nop
L_0609786C:
    c.r[1] = ld32(c.r[14]);  // 0609786C mov.l @r14,r1
    c.r[2] = 0x0u;  // 0609786E mov #0,r2
    st32(c.r[1], c.r[2]);  // 06097870 mov.l r2,@r1
    c.r[14] += 4;  // 06097872 add #4,r14
    c.r[15] = c.r[14];  // 06097874 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06097876 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06097878 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0609787A rts ; nop
}

void f_06097884(SH2Context& c) {
    ran[2304] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06097884 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06097886 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06097888 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609788A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609788C sts.l pr,@-r15
    c.r[15] -= 16;  // 0609788E add #-16,r15
    c.r[14] = c.r[15];  // 06097890 mov r15,r14
    c.r[9] = c.r[4];  // 06097892 mov r4,r9
    c.r[2] = 0x0u;  // 06097894 mov #0,r2
    st32(c.r[14], c.r[2]);  // 06097896 mov.l r2,@r14
    st32(c.r[14] + 4, c.r[2]);  // 06097898 mov.l r2,@(4,r14)
    c.r[8] = c.r[14];  // 0609789A mov r14,r8
    c.r[8] += 8;  // 0609789C add #8,r8
    c.r[1] = 0x0u;  // 0609789E mov #0,r1
    st8(c.r[14], c.r[1]);  // 060978A0 mov.b r1,@r14
    c.r[0] = ld32(0x060978CCu);  // 060978A2 mov.l 0x060978CC,r0
    c.r[7] = 0x1u;  // 060978A4 mov #1,r7
    c.r[6] = c.r[8];  // 060978A6 mov r8,r6
    c.r[5] = c.r[14];  // 060978A8 mov r14,r5
    { const uint32_t x = c.r[0]; c.pr = 0x060978AEu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060978AEu) return; }  // 060978AA jsr @r0 ; mov #0,r4
    c.r[10] = c.r[0];  // 060978AE mov r0,r10
    c.r[1] = ld32(0x060978D0u);  // 060978B0 mov.l 0x060978D0,r1
    c.r[5] = c.r[9];  // 060978B2 mov r9,r5
    { const uint32_t x = c.r[1]; c.pr = 0x060978B8u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060978B8u) return; }  // 060978B4 jsr @r1 ; mov r8,r4
    c.r[14] += 16;  // 060978B8 add #16,r14
    c.r[15] = c.r[14];  // 060978BA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060978BC lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060978BE mov.l @r15+,r14
    c.r[0] = c.r[10];  // 060978C0 mov r10,r0
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060978C2 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060978C4 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060978C6 rts ; mov.l @r15+,r8
}

void f_060978D4(SH2Context& c) {
    ran[2305] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060978D4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060978D6 sts.l pr,@-r15
    c.r[0] = ld32(0x060978E8u);  // 060978D8 mov.l 0x060978E8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060978DEu; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060978DEu) return; }  // 060978DA jsr @r0 ; mov r15,r14
    c.r[15] = c.r[14];  // 060978DE mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060978E0 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060978E2 rts ; mov.l @r15+,r14
}

void f_060978EC(SH2Context& c) {
    ran[2306] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060978EC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060978EE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060978F0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060978F2 sts.l pr,@-r15
    c.r[15] -= 8;  // 060978F4 add #-8,r15
    c.r[14] = c.r[15];  // 060978F6 mov r15,r14
    c.r[9] = c.r[4];  // 060978F8 mov r4,r9
    c.r[0] = ld32(0x06097934u);  // 060978FA mov.l 0x06097934,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06097900u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06097900u) return; }  // 060978FC jsr @r0 ; mov r14,r4
    c.r[8] = c.r[0];  // 06097900 mov r0,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 06097902 tst r8,r8
    { const bool k = !c.t; c.r[5] = c.r[9]; if (k) { goto L_06097924; } }  // 06097904 bf/s 0x06097924 ; mov r9,r5
    c.r[1] = ld32(0x06097938u);  // 06097908 mov.l 0x06097938,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609790Eu; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609790Eu) return; }  // 0609790A jsr @r1 ; mov r14,r4
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0609790E mov.b @r9,r0
    c.r[2] = (uint32_t)(int16_t)ld16(0x06097932u);  // 06097910 mov.w 0x06097932,r2
    c.r[1] = c.r[0] & 0xFFu;  // 06097912 extu.b r0,r1
    c.t = c.r[1] == c.r[2];  // 06097914 cmp/eq r2,r1
    { const bool k = c.t; c.r[0] &= 0x20u; if (k) { goto L_06097920; } }  // 06097916 bt/s 0x06097920 ; and #32,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609791A tst r0,r0
    { const bool k = !c.t; c.r[0] = c.r[8]; if (k) { goto L_06097924; } }  // 0609791C bf/s 0x06097924 ; mov r8,r0
L_06097920:
    c.r[8] = 0xFFFFFFF8u;  // 06097920 mov #-8,r8
    c.r[0] = c.r[8];  // 06097922 mov r8,r0
L_06097924:
    c.r[14] += 8;  // 06097924 add #8,r14
    c.r[15] = c.r[14];  // 06097926 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06097928 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609792A mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609792C mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609792E rts ; mov.l @r15+,r8
}

void f_0609793C(SH2Context& c) {
    ran[2307] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609793C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609793E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06097940 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06097942 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06097944 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06097946 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06097948 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609794A sts.l pr,@-r15
    c.r[15] -= 8;  // 0609794C add #-8,r15
    c.r[14] = c.r[15];  // 0609794E mov r15,r14
    c.r[11] = c.r[4];  // 06097950 mov r4,r11
    c.r[10] = c.r[14];  // 06097952 mov r14,r10
    c.r[12] = 0xFFFFFFFDu;  // 06097954 mov #-3,r12
    c.r[9] = 0x0u;  // 06097956 mov #0,r9
    c.r[13] = ld32(0x060979BCu);  // 06097958 mov.l 0x060979BC,r13
L_0609795A:
    c.r[0] = sh2_get_sr(c);  // 0609795A stc sr,r0
    c.r[0] &= 0xF0u;  // 0609795C and #240,r0
    c.r[8] = c.r[0];  // 0609795E mov r0,r8
    c.r[8] >>= 2;  // 06097960 shlr2 r8
    c.r[8] >>= 2;  // 06097962 shlr2 r8
    c.r[1] = sh2_get_sr(c);  // 06097964 stc sr,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060979BAu);  // 06097966 mov.w 0x060979BA,r0
    c.r[0] &= c.r[1];  // 06097968 and r1,r0
    c.r[0] |= 0xF0u;  // 0609796A or #240,r0
    sh2_set_sr(c, c.r[0] & 0x3F3u); SH2_POLL(c);  // 0609796C ldc r0,sr
    { const uint32_t x = c.r[13]; c.pr = 0x06097972u; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06097972u) return; }  // 0609796E jsr @r13 ; mov r11,r4
    { const uint32_t x = c.r[13]; c.pr = 0x06097976u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06097976u) return; }  // 06097972 jsr @r13 ; mov r10,r4
    c.r[1] = sh2_get_sr(c);  // 06097976 stc sr,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x060979BAu);  // 06097978 mov.w 0x060979BA,r3
    c.r[1] &= c.r[3];  // 0609797A and r3,r1
    c.r[8] <<= 2;  // 0609797C shll2 r8
    c.r[8] <<= 2;  // 0609797E shll2 r8
    c.r[1] |= c.r[8];  // 06097980 or r8,r1
    sh2_set_sr(c, c.r[1] & 0x3F3u); SH2_POLL(c);  // 06097982 ldc r1,sr
    c.r[2] = ld32(c.r[11]);  // 06097984 mov.l @r11,r2
    c.r[1] = ld32(c.r[10]);  // 06097986 mov.l @r10,r1
    c.t = c.r[2] == c.r[1];  // 06097988 cmp/eq r1,r2
    if (!c.t) { goto L_0609799A; }  // 0609798A bf 0x0609799A
    c.r[2] = ld32(c.r[11] + 4);  // 0609798C mov.l @(4,r11),r2
    c.r[1] = ld32(c.r[10] + 4);  // 0609798E mov.l @(4,r10),r1
    c.t = c.r[2] == c.r[1];  // 06097990 cmp/eq r1,r2
    { const bool k = !c.t; c.r[9] += 1; if (k) { goto L_0609799C; } }  // 06097992 bf/s 0x0609799C ; add #1,r9
    c.r[12] = 0x0u; goto L_060979A2;  // 06097996 bra 0x060979A2 ; mov #0,r12
L_0609799A:
    c.r[9] += 1;  // 0609799A add #1,r9
L_0609799C:
    c.r[1] = 0x63u;  // 0609799C mov #99,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 0609799E cmp/gt r1,r9
    if (!c.t) { SH2_POLL(c); goto L_0609795A; }  // 060979A0 bf 0x0609795A
L_060979A2:
    c.r[14] += 8;  // 060979A2 add #8,r14
    c.r[15] = c.r[14];  // 060979A4 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060979A6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060979A8 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060979AA mov.l @r15+,r13
    c.r[0] = c.r[12];  // 060979AC mov r12,r0
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060979AE mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060979B0 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060979B2 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060979B4 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060979B6 rts ; mov.l @r15+,r8
}

void f_060979C0(SH2Context& c) {
    ran[2308] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060979C0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060979C2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060979C4 sts.l pr,@-r15
    c.r[15] -= 16;  // 060979C6 add #-16,r15
    c.r[14] = c.r[15];  // 060979C8 mov r15,r14
    c.r[8] = c.r[4];  // 060979CA mov r4,r8
    c.r[3] = 0x0u;  // 060979CC mov #0,r3
    st32(c.r[14], c.r[3]);  // 060979CE mov.l r3,@r14
    st32(c.r[14] + 4, c.r[3]);  // 060979D0 mov.l r3,@(4,r14)
    c.r[6] = c.r[14];  // 060979D2 mov r14,r6
    c.r[6] += 8;  // 060979D4 add #8,r6
    c.r[1] = 0x1u;  // 060979D6 mov #1,r1
    st8(c.r[14], c.r[1]);  // 060979D8 mov.b r1,@r14
    c.r[0] = ld32(0x06097A24u);  // 060979DA mov.l 0x06097A24,r0
    c.r[5] = c.r[14];  // 060979DC mov r14,r5
    { const uint32_t x = c.r[0]; c.pr = 0x060979E2u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060979E2u) return; }  // 060979DE jsr @r0 ; mov #0,r4
    c.r[1] = c.r[14];  // 060979E2 mov r14,r1
    c.r[1] += 10;  // 060979E4 add #10,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060979E6 mov.b @r1,r1
    c.r[2] = c.r[8];  // 060979E8 mov r8,r2
    st8(c.r[8], c.r[1]);  // 060979EA mov.b r1,@r8
    c.r[1] = c.r[14];  // 060979EC mov r14,r1
    c.r[1] += 11;  // 060979EE add #11,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060979F0 mov.b @r1,r1
    c.r[2] += 1;  // 060979F2 add #1,r2
    st8(c.r[2], c.r[1]);  // 060979F4 mov.b r1,@r2
    c.r[2] = c.r[8];  // 060979F6 mov r8,r2
    c.r[1] = c.r[14];  // 060979F8 mov r14,r1
    c.r[1] += 13;  // 060979FA add #13,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060979FC mov.b @r1,r1
    c.r[2] += 2;  // 060979FE add #2,r2
    st8(c.r[2], c.r[1]);  // 06097A00 mov.b r1,@r2
    c.r[2] = c.r[8];  // 06097A02 mov r8,r2
    c.r[2] += 3;  // 06097A04 add #3,r2
    c.r[1] = c.r[14];  // 06097A06 mov r14,r1
    c.r[1] += 14;  // 06097A08 add #14,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06097A0A mov.b @r1,r1
    c.r[8] += 4;  // 06097A0C add #4,r8
    st8(c.r[2], c.r[1]);  // 06097A0E mov.b r1,@r2
    c.r[1] = c.r[14];  // 06097A10 mov r14,r1
    c.r[1] += 15;  // 06097A12 add #15,r1
    c.r[14] += 16;  // 06097A14 add #16,r14
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06097A16 mov.b @r1,r1
    c.r[15] = c.r[14];  // 06097A18 mov r14,r15
    st8(c.r[8], c.r[1]);  // 06097A1A mov.b r1,@r8
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06097A1C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06097A1E mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06097A20 rts ; mov.l @r15+,r8
}

void f_06097A28(SH2Context& c) {
    ran[2309] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06097A28 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06097A2A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06097A2C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06097A2E sts.l pr,@-r15
    c.r[15] -= 16;  // 06097A30 add #-16,r15
    c.r[14] = c.r[15];  // 06097A32 mov r15,r14
    c.r[9] = c.r[4];  // 06097A34 mov r4,r9
    c.r[2] = 0x0u;  // 06097A36 mov #0,r2
    st32(c.r[14], c.r[2]);  // 06097A38 mov.l r2,@r14
    st32(c.r[14] + 4, c.r[2]);  // 06097A3A mov.l r2,@(4,r14)
    c.r[8] = c.r[14];  // 06097A3C mov r14,r8
    c.r[8] += 8;  // 06097A3E add #8,r8
    c.r[1] = 0x2u;  // 06097A40 mov #2,r1
    st8(c.r[14], c.r[1]);  // 06097A42 mov.b r1,@r14
    c.r[0] = ld32(0x06097A6Cu);  // 06097A44 mov.l 0x06097A6C,r0
    c.r[6] = c.r[8];  // 06097A46 mov r8,r6
    c.r[5] = c.r[14];  // 06097A48 mov r14,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06097A4Eu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06097A4Eu) return; }  // 06097A4A jsr @r0 ; mov #0,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 06097A4E tst r0,r0
    { const bool k = !c.t; c.r[5] = c.r[9]; if (k) { goto L_06097A5E; } }  // 06097A50 bf/s 0x06097A5E ; mov r9,r5
    c.r[1] = ld32(0x06097A70u);  // 06097A54 mov.l 0x06097A70,r1
    c.r[4] = ld32(c.r[8]);  // 06097A56 mov.l @r8,r4
    c.r[0] = ld32(0x06097A74u);  // 06097A58 mov.l 0x06097A74,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06097A5Eu; c.r[4] &= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06097A5Eu) return; }  // 06097A5A jsr @r0 ; and r1,r4
L_06097A5E:
    c.r[14] += 16;  // 06097A5E add #16,r14
    c.r[15] = c.r[14];  // 06097A60 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06097A62 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06097A64 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06097A66 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06097A68 rts ; mov.l @r15+,r8
}

void f_06097A78(SH2Context& c) {
    ran[2310] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06097A78 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06097A7A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06097A7C sts.l pr,@-r15
    c.r[15] -= 16;  // 06097A7E add #-16,r15
    c.r[14] = c.r[15];  // 06097A80 mov r15,r14
    c.r[8] = c.r[5];  // 06097A82 mov r5,r8
    c.r[2] = 0x0u;  // 06097A84 mov #0,r2
    st32(c.r[14], c.r[2]);  // 06097A86 mov.l r2,@r14
    st32(c.r[14] + 4, c.r[2]);  // 06097A88 mov.l r2,@(4,r14)
    c.r[6] = c.r[14];  // 06097A8A mov r14,r6
    c.r[6] += 8;  // 06097A8C add #8,r6
    c.r[1] = 0x3u;  // 06097A8E mov #3,r1
    st8(c.r[14], c.r[1]);  // 06097A90 mov.b r1,@r14
    c.r[1] = c.r[14];  // 06097A92 mov r14,r1
    c.r[1] += 1;  // 06097A94 add #1,r1
    st8(c.r[1], c.r[4]);  // 06097A96 mov.b r4,@r1
    c.r[0] = ld32(0x06097AB0u);  // 06097A98 mov.l 0x06097AB0,r0
    c.r[5] = c.r[14];  // 06097A9A mov r14,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06097AA0u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06097AA0u) return; }  // 06097A9C jsr @r0 ; mov #0,r4
    c.r[2] = ld32(c.r[14] + 12);  // 06097AA0 mov.l @(12,r14),r2
    st32(c.r[8], c.r[2]);  // 06097AA2 mov.l r2,@r8
    c.r[14] += 16;  // 06097AA4 add #16,r14
    c.r[15] = c.r[14];  // 06097AA6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06097AA8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06097AAA mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06097AAC rts ; mov.l @r15+,r8
}

void f_06097AB4(SH2Context& c) {
    ran[2311] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06097AB4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06097AB6 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06097AB8 sts.l pr,@-r15
    c.r[15] -= 8;  // 06097ABA add #-8,r15
    c.r[14] = c.r[15];  // 06097ABC mov r15,r14
    c.r[0] = c.r[4];  // 06097ABE mov r4,r0
    c.r[2] = 0x0u;  // 06097AC0 mov #0,r2
    st32(c.r[14], c.r[2]);  // 06097AC2 mov.l r2,@r14
    st32(c.r[14] + 4, c.r[2]);  // 06097AC4 mov.l r2,@(4,r14)
    c.r[1] = 0x4u;  // 06097AC6 mov #4,r1
    st8(c.r[14], c.r[1]);  // 06097AC8 mov.b r1,@r14
    c.r[1] = c.r[14];  // 06097ACA mov r14,r1
    c.r[1] += 1;  // 06097ACC add #1,r1
    st8(c.r[1], c.r[0]);  // 06097ACE mov.b r0,@r1
    c.r[1] = c.r[14];  // 06097AD0 mov r14,r1
    c.r[1] += 2;  // 06097AD2 add #2,r1
    st16(c.r[1], c.r[5]);  // 06097AD4 mov.w r5,@r1
    c.r[1] = c.r[14];  // 06097AD6 mov r14,r1
    c.r[1] += 6;  // 06097AD8 add #6,r1
    st8(c.r[1], c.r[6]);  // 06097ADA mov.b r6,@r1
    c.r[1] = c.r[14];  // 06097ADC mov r14,r1
    c.r[1] += 7;  // 06097ADE add #7,r1
    c.r[0] &= 0x81u;  // 06097AE0 and #129,r0
    c.t = c.r[0] == 0x1u;  // 06097AE2 cmp/eq #1,r0
    { const bool k = !c.t; st8(c.r[1], c.r[7]); if (k) { goto L_06097B0E; } }  // 06097AE4 bf/s 0x06097B0E ; mov.b r7,@r1
    c.r[4] = (uint32_t)(int16_t)ld16(0x06097B26u);  // 06097AE8 mov.w 0x06097B26,r4
    c.r[1] = ld32(0x06097B28u);  // 06097AEA mov.l 0x06097B28,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06097AF0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06097AF0u) return; }  // 06097AEC jsr @r1 ; nop
    c.r[1] = ld32(0x06097B2Cu);  // 06097AF0 mov.l 0x06097B2C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06097AF6u; c.r[4] = 0x41u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06097AF6u) return; }  // 06097AF2 jsr @r1 ; mov #65,r4
    c.r[0] = ld32(0x06097B30u);  // 06097AF6 mov.l 0x06097B30,r0
    c.r[5] = c.r[14];  // 06097AF8 mov r14,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06097AFEu; c.r[4] = 0x40u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06097AFEu) return; }  // 06097AFA jsr @r0 ; mov #64,r4
    c.r[8] = c.r[0];  // 06097AFE mov r0,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 06097B00 tst r8,r8
    if (!c.t) { goto L_06097B18; }  // 06097B02 bf 0x06097B18
    c.r[1] = ld32(0x06097B34u);  // 06097B04 mov.l 0x06097B34,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06097B0Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06097B0Au) return; }  // 06097B06 jsr @r1 ; nop
    c.r[14] += 8; goto L_06097B1A;  // 06097B0A bra 0x06097B1A ; add #8,r14
L_06097B0E:
    c.r[0] = ld32(0x06097B30u);  // 06097B0E mov.l 0x06097B30,r0
    c.r[5] = c.r[14];  // 06097B10 mov r14,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06097B16u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06097B16u) return; }  // 06097B12 jsr @r0 ; mov #0,r4
    c.r[8] = c.r[0];  // 06097B16 mov r0,r8
L_06097B18:
    c.r[14] += 8;  // 06097B18 add #8,r14
L_06097B1A:
    c.r[15] = c.r[14];  // 06097B1A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06097B1C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06097B1E mov.l @r15+,r14
    c.r[0] = c.r[8];  // 06097B20 mov r8,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06097B22 rts ; mov.l @r15+,r8
}

void f_06097B38(SH2Context& c) {
    ran[2312] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06097B38 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06097B3A sts.l pr,@-r15
    c.r[15] -= 8;  // 06097B3C add #-8,r15
    c.r[14] = c.r[15];  // 06097B3E mov r15,r14
    c.r[2] = 0x0u;  // 06097B40 mov #0,r2
    st32(c.r[14], c.r[2]);  // 06097B42 mov.l r2,@r14
    st32(c.r[14] + 4, c.r[2]);  // 06097B44 mov.l r2,@(4,r14)
    c.r[1] = 0x5u;  // 06097B46 mov #5,r1
    st8(c.r[14], c.r[1]);  // 06097B48 mov.b r1,@r14
    c.r[0] = ld32(0x06097B5Cu);  // 06097B4A mov.l 0x06097B5C,r0
    c.r[5] = c.r[14];  // 06097B4C mov r14,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06097B52u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06097B52u) return; }  // 06097B4E jsr @r0 ; mov #0,r4
    c.r[14] += 8;  // 06097B52 add #8,r14
    c.r[15] = c.r[14];  // 06097B54 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06097B56 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06097B58 rts ; mov.l @r15+,r14
}

void f_06097B60(SH2Context& c) {
    ran[2313] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06097B60 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06097B62 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06097B64 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06097B66 sts.l pr,@-r15
    c.r[15] -= 8;  // 06097B68 add #-8,r15
    c.r[14] = c.r[15];  // 06097B6A mov r15,r14
    c.r[9] = c.r[4];  // 06097B6C mov r4,r9
    c.r[0] = c.r[9];  // 06097B6E mov r9,r0
    c.t = c.r[0] == 0x1u;  // 06097B70 cmp/eq #1,r0
    { const bool k = !c.t; c.r[1] = 0x2u; if (k) { goto L_06097B7C; } }  // 06097B72 bf/s 0x06097B7C ; mov #2,r1
    c.r[0] = 0xFFFFFF80u;  // 06097B76 mov #-128,r0
    c.r[0] = c.r[0] & 0xFFu;  // 06097B78 extu.b r0,r0
    c.r[1] |= c.r[0];  // 06097B7A or r0,r1
L_06097B7C:
    c.r[5] = c.r[14];  // 06097B7C mov r14,r5
    c.r[0] = ld32(0x06097BC0u);  // 06097B7E mov.l 0x06097BC0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06097B84u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06097B84u) return; }  // 06097B80 jsr @r0 ; mov r1,r4
    c.r[8] = c.r[0];  // 06097B84 mov r0,r8
    c.r[0] = c.r[9];  // 06097B86 mov r9,r0
    c.t = c.r[0] == 0x1u;  // 06097B88 cmp/eq #1,r0
    { const bool k = !c.t; c.t = (c.r[8] & c.r[8]) == 0; if (k) { goto L_06097B9E; } }  // 06097B8A bf/s 0x06097B9E ; tst r8,r8
    { const bool k = !c.t; c.r[0] = ld32(c.r[14]); if (k) { goto L_06097B9E; } }  // 06097B8E bf/s 0x06097B9E ; mov.l @r14,r0
    c.r[0] &= 0x80u;  // 06097B92 and #128,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06097B94 tst r0,r0
    { const bool k = c.t; c.t = (c.r[8] & c.r[8]) == 0; if (k) { goto L_06097B9E; } }  // 06097B96 bt/s 0x06097B9E ; tst r8,r8
    c.r[8] = 0xFFFFFFFCu;  // 06097B9A mov #-4,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 06097B9C tst r8,r8
L_06097B9E:
    { const bool k = c.t; c.r[4] = c.r[14]; if (k) { goto L_06097BA8; } }  // 06097B9E bt/s 0x06097BA8 ; mov r14,r4
    c.r[0] = ld32(0x06097BC4u);  // 06097BA2 mov.l 0x06097BC4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06097BA8u; c.r[4] += 4; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06097BA8u) return; }  // 06097BA4 jsr @r0 ; add #4,r4
L_06097BA8:
    c.r[1] = ld32(0x06097BC8u);  // 06097BA8 mov.l 0x06097BC8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06097BAEu; c.r[4] = 0xFFFFFFFDu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06097BAEu) return; }  // 06097BAA jsr @r1 ; mov #-3,r4
    c.r[14] += 8;  // 06097BAE add #8,r14
    c.r[15] = c.r[14];  // 06097BB0 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06097BB2 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06097BB4 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06097BB6 mov.l @r15+,r9
    c.r[0] = c.r[8];  // 06097BB8 mov r8,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06097BBA rts ; mov.l @r15+,r8
}

void f_06097BCC(SH2Context& c) {
    ran[2314] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06097BCC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06097BCE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06097BD0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06097BD2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06097BD4 sts.l pr,@-r15
    c.r[15] -= 16;  // 06097BD6 add #-16,r15
    c.r[14] = c.r[15];  // 06097BD8 mov r15,r14
    c.r[9] = c.r[4];  // 06097BDA mov r4,r9
    c.r[3] = 0x0u;  // 06097BDC mov #0,r3
    st32(c.r[14], c.r[3]);  // 06097BDE mov.l r3,@r14
    st32(c.r[14] + 4, c.r[3]);  // 06097BE0 mov.l r3,@(4,r14)
    c.r[8] = c.r[14];  // 06097BE2 mov r14,r8
    c.r[8] += 8;  // 06097BE4 add #8,r8
    c.r[1] = 0x6u;  // 06097BE6 mov #6,r1
    st8(c.r[14], c.r[1]);  // 06097BE8 mov.b r1,@r14
    c.r[0] = ld32(0x06097C18u);  // 06097BEA mov.l 0x06097C18,r0
    c.r[6] = c.r[8];  // 06097BEC mov r8,r6
    c.r[5] = c.r[14];  // 06097BEE mov r14,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06097BF4u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06097BF4u) return; }  // 06097BF0 jsr @r0 ; mov #0,r4
    c.r[10] = c.r[0];  // 06097BF4 mov r0,r10
    c.r[2] = ld32(0x06097C1Cu);  // 06097BF6 mov.l 0x06097C1C,r2
    c.r[1] = ld32(c.r[8]);  // 06097BF8 mov.l @r8,r1
    c.r[1] &= c.r[2];  // 06097BFA and r2,r1
    st32(c.r[9], c.r[1]);  // 06097BFC mov.l r1,@r9
    c.r[1] = ld32(0x06097C20u);  // 06097BFE mov.l 0x06097C20,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06097C04u; c.r[4] = 0xFFFFFFFDu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06097C04u) return; }  // 06097C00 jsr @r1 ; mov #-3,r4
    c.r[14] += 16;  // 06097C04 add #16,r14
    c.r[15] = c.r[14];  // 06097C06 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06097C08 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06097C0A mov.l @r15+,r14
    c.r[0] = c.r[10];  // 06097C0C mov r10,r0
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06097C0E mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06097C10 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06097C12 rts ; mov.l @r15+,r8
}

void f_06097C24(SH2Context& c) {
    ran[2315] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06097C24 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06097C26 sts.l pr,@-r15
    c.r[15] -= 8;  // 06097C28 add #-8,r15
    c.r[14] = c.r[15];  // 06097C2A mov r15,r14
    c.r[2] = 0x0u;  // 06097C2C mov #0,r2
    st32(c.r[14], c.r[2]);  // 06097C2E mov.l r2,@r14
    st32(c.r[14] + 4, c.r[2]);  // 06097C30 mov.l r2,@(4,r14)
    c.r[1] = 0x70u;  // 06097C32 mov #112,r1
    st8(c.r[14], c.r[1]);  // 06097C34 mov.b r1,@r14
    st32(c.r[14] + 4, c.r[5]);  // 06097C36 mov.l r5,@(4,r14)
    c.r[1] = c.r[14];  // 06097C38 mov r14,r1
    c.r[1] += 4;  // 06097C3A add #4,r1
    st8(c.r[1], c.r[4]);  // 06097C3C mov.b r4,@r1
    c.r[4] = (uint32_t)(int16_t)ld16(0x06097C50u);  // 06097C3E mov.w 0x06097C50,r4
    c.r[0] = ld32(0x06097C54u);  // 06097C40 mov.l 0x06097C54,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06097C46u; c.r[5] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06097C46u) return; }  // 06097C42 jsr @r0 ; mov r14,r5
    c.r[14] += 8;  // 06097C46 add #8,r14
    c.r[15] = c.r[14];  // 06097C48 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06097C4A lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06097C4C rts ; mov.l @r15+,r14
}

void f_06097C58(SH2Context& c) {
    ran[2316] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06097C58 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06097C5A sts.l pr,@-r15
    c.r[15] -= 8;  // 06097C5C add #-8,r15
    c.r[14] = c.r[15];  // 06097C5E mov r15,r14
    c.r[2] = 0x0u;  // 06097C60 mov #0,r2
    st32(c.r[14], c.r[2]);  // 06097C62 mov.l r2,@r14
    st32(c.r[14] + 4, c.r[2]);  // 06097C64 mov.l r2,@(4,r14)
    c.r[1] = 0x71u;  // 06097C66 mov #113,r1
    st8(c.r[14], c.r[1]);  // 06097C68 mov.b r1,@r14
    st32(c.r[14] + 4, c.r[5]);  // 06097C6A mov.l r5,@(4,r14)
    c.r[1] = c.r[14];  // 06097C6C mov r14,r1
    c.r[1] += 4;  // 06097C6E add #4,r1
    st8(c.r[1], c.r[4]);  // 06097C70 mov.b r4,@r1
    c.r[4] = (uint32_t)(int16_t)ld16(0x06097C84u);  // 06097C72 mov.w 0x06097C84,r4
    c.r[0] = ld32(0x06097C88u);  // 06097C74 mov.l 0x06097C88,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06097C7Au; c.r[5] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06097C7Au) return; }  // 06097C76 jsr @r0 ; mov r14,r5
    c.r[14] += 8;  // 06097C7A add #8,r14
    c.r[15] = c.r[14];  // 06097C7C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06097C7E lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06097C80 rts ; mov.l @r15+,r14
}

void f_06097C8C(SH2Context& c) {
    ran[2317] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06097C8C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06097C8E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06097C90 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06097C92 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06097C94 sts.l pr,@-r15
    c.r[15] -= 16;  // 06097C96 add #-16,r15
    c.r[14] = c.r[15];  // 06097C98 mov r15,r14
    c.r[10] = c.r[4];  // 06097C9A mov r4,r10
    c.r[8] = c.r[5];  // 06097C9C mov r5,r8
    c.r[9] = c.r[6];  // 06097C9E mov r6,r9
    c.r[7] = 0x0u;  // 06097CA0 mov #0,r7
    st32(c.r[14], c.r[7]);  // 06097CA2 mov.l r7,@r14
    st32(c.r[14] + 4, c.r[7]);  // 06097CA4 mov.l r7,@(4,r14)
    c.r[6] = c.r[14];  // 06097CA6 mov r14,r6
    c.r[6] += 8;  // 06097CA8 add #8,r6
    c.r[1] = 0x72u;  // 06097CAA mov #114,r1
    st8(c.r[14], c.r[1]);  // 06097CAC mov.b r1,@r14
    c.r[0] = ld32(0x06097CE4u);  // 06097CAE mov.l 0x06097CE4,r0
    c.r[5] = c.r[14];  // 06097CB0 mov r14,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06097CB6u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06097CB6u) return; }  // 06097CB2 jsr @r0 ; mov #0,r4
    c.r[1] = c.r[14];  // 06097CB6 mov r14,r1
    c.r[1] += 10;  // 06097CB8 add #10,r1
    c.r[3] = c.r[14];  // 06097CBA mov r14,r3
    c.r[3] += 12;  // 06097CBC add #12,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06097CBE mov.w @r1,r1
    c.r[2] = ld32(0x06097CE8u);  // 06097CC0 mov.l 0x06097CE8,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 06097CC2 extu.w r1,r1
    st32(c.r[8], c.r[1]);  // 06097CC4 mov.l r1,@r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06097CC6 mov.b @r3,r1
    c.r[14] += 16;  // 06097CC8 add #16,r14
    c.r[1] = c.r[1] & 0xFFu;  // 06097CCA extu.b r1,r1
    st32(c.r[9], c.r[1]);  // 06097CCC mov.l r1,@r9
    c.r[1] = ld32(c.r[3]);  // 06097CCE mov.l @r3,r1
    c.r[15] = c.r[14];  // 06097CD0 mov r14,r15
    c.r[1] &= c.r[2];  // 06097CD2 and r2,r1
    st32(c.r[10], c.r[1]);  // 06097CD4 mov.l r1,@r10
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06097CD6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06097CD8 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06097CDA mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06097CDC mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06097CDE rts ; mov.l @r15+,r8
}

void f_06097CEC(SH2Context& c) {
    ran[2318] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06097CEC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06097CEE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06097CF0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06097CF2 sts.l pr,@-r15
    c.r[15] -= 16;  // 06097CF4 add #-16,r15
    c.r[14] = c.r[15];  // 06097CF6 mov r15,r14
    c.r[9] = c.r[5];  // 06097CF8 mov r5,r9
    c.r[3] = 0x0u;  // 06097CFA mov #0,r3
    st32(c.r[14], c.r[3]);  // 06097CFC mov.l r3,@r14
    st32(c.r[14] + 4, c.r[3]);  // 06097CFE mov.l r3,@(4,r14)
    c.r[8] = c.r[14];  // 06097D00 mov r14,r8
    c.r[8] += 8;  // 06097D02 add #8,r8
    c.r[1] = 0x73u;  // 06097D04 mov #115,r1
    st8(c.r[14], c.r[1]);  // 06097D06 mov.b r1,@r14
    st32(c.r[14] + 4, c.r[4]);  // 06097D08 mov.l r4,@(4,r14)
    c.r[2] = c.r[14];  // 06097D0A mov r14,r2
    c.r[2] += 4;  // 06097D0C add #4,r2
    c.r[1] = 0x0u;  // 06097D0E mov #0,r1
    st8(c.r[2], c.r[1]);  // 06097D10 mov.b r1,@r2
    c.r[0] = ld32(0x06097D3Cu);  // 06097D12 mov.l 0x06097D3C,r0
    c.r[6] = c.r[8];  // 06097D14 mov r8,r6
    c.r[5] = c.r[14];  // 06097D16 mov r14,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06097D1Cu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06097D1Cu) return; }  // 06097D18 jsr @r0 ; mov #0,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 06097D1C tst r0,r0
    { const bool k = !c.t; c.r[5] = c.r[9]; if (k) { goto L_06097D2C; } }  // 06097D1E bf/s 0x06097D2C ; mov r9,r5
    c.r[1] = ld32(0x06097D40u);  // 06097D22 mov.l 0x06097D40,r1
    c.r[4] = ld32(c.r[8]);  // 06097D24 mov.l @r8,r4
    c.r[0] = ld32(0x06097D44u);  // 06097D26 mov.l 0x06097D44,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06097D2Cu; c.r[4] &= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06097D2Cu) return; }  // 06097D28 jsr @r0 ; and r1,r4
L_06097D2C:
    c.r[14] += 16;  // 06097D2C add #16,r14
    c.r[15] = c.r[14];  // 06097D2E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06097D30 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06097D32 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06097D34 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06097D36 rts ; mov.l @r15+,r8
}

void f_06097D48(SH2Context& c) {
    ran[2319] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06097D48 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06097D4A sts.l pr,@-r15
    c.r[15] -= 8;  // 06097D4C add #-8,r15
    c.r[14] = c.r[15];  // 06097D4E mov r15,r14
    c.r[2] = 0x0u;  // 06097D50 mov #0,r2
    st32(c.r[14], c.r[2]);  // 06097D52 mov.l r2,@r14
    st32(c.r[14] + 4, c.r[2]);  // 06097D54 mov.l r2,@(4,r14)
    st32(c.r[14], c.r[6]);  // 06097D56 mov.l r6,@r14
    c.r[1] = 0x74u;  // 06097D58 mov #116,r1
    st8(c.r[14], c.r[1]);  // 06097D5A mov.b r1,@r14
    st32(c.r[14] + 4, c.r[5]);  // 06097D5C mov.l r5,@(4,r14)
    c.r[1] = c.r[14];  // 06097D5E mov r14,r1
    c.r[1] += 4;  // 06097D60 add #4,r1
    st8(c.r[1], c.r[4]);  // 06097D62 mov.b r4,@r1
    c.r[4] = (uint32_t)(int16_t)ld16(0x06097D76u);  // 06097D64 mov.w 0x06097D76,r4
    c.r[0] = ld32(0x06097D78u);  // 06097D66 mov.l 0x06097D78,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06097D6Cu; c.r[5] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06097D6Cu) return; }  // 06097D68 jsr @r0 ; mov r14,r5
    c.r[14] += 8;  // 06097D6C add #8,r14
    c.r[15] = c.r[14];  // 06097D6E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06097D70 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06097D72 rts ; mov.l @r15+,r14
}

void f_06097D7C(SH2Context& c) {
    ran[2320] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06097D7C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06097D7E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06097D80 sts.l pr,@-r15
    c.r[15] -= 8;  // 06097D82 add #-8,r15
    c.r[14] = c.r[15];  // 06097D84 mov r15,r14
    c.r[2] = 0x0u;  // 06097D86 mov #0,r2
    st32(c.r[14], c.r[2]);  // 06097D88 mov.l r2,@r14
    st32(c.r[14] + 4, c.r[2]);  // 06097D8A mov.l r2,@(4,r14)
    c.r[1] = 0x75u;  // 06097D8C mov #117,r1
    st8(c.r[14], c.r[1]);  // 06097D8E mov.b r1,@r14
    c.r[8] = (uint32_t)(int16_t)ld16(0x06097DACu);  // 06097D90 mov.w 0x06097DAC,r8
    c.r[1] = ld32(0x06097DB0u);  // 06097D92 mov.l 0x06097DB0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06097D98u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06097D98u) return; }  // 06097D94 jsr @r1 ; mov r8,r4
    c.r[0] = ld32(0x06097DB4u);  // 06097D98 mov.l 0x06097DB4,r0
    c.r[5] = c.r[14];  // 06097D9A mov r14,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06097DA0u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06097DA0u) return; }  // 06097D9C jsr @r0 ; mov r8,r4
    c.r[14] += 8;  // 06097DA0 add #8,r14
    c.r[15] = c.r[14];  // 06097DA2 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06097DA4 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06097DA6 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06097DA8 rts ; mov.l @r15+,r8
}

void f_06097DB8(SH2Context& c) {
    ran[2321] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06097DB8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06097DBA sts.l pr,@-r15
    c.r[15] -= 16;  // 06097DBC add #-16,r15
    c.r[14] = c.r[15];  // 06097DBE mov r15,r14
    st32(c.r[14], c.r[4]);  // 06097DC0 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 06097DC2 mov.l r5,@(4,r14)
    c.r[1] = ld32(c.r[14]);  // 06097DC4 mov.l @r14,r1
    st32(c.r[14] + 8, c.r[1]);  // 06097DC6 mov.l r1,@(8,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 06097DC8 mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[14] + 4);  // 06097DCA mov.l @(4,r14),r2
    c.r[3] = ld32(c.r[14] + 8);  // 06097DCC mov.l @(8,r14),r3
    c.r[6] = ld32(c.r[14] + 8);  // 06097DCE mov.l @(8,r14),r6
    c.r[7] = ld32(c.r[6] + 28);  // 06097DD0 mov.l @(28,r6),r7
    c.r[1] = ld32(c.r[1] + 24);  // 06097DD2 mov.l @(24,r1),r1
    c.r[6] = c.r[2];  // 06097DD4 mov r2,r6
    c.r[5] = c.r[3];  // 06097DD6 mov r3,r5
    c.r[4] = c.r[7];  // 06097DD8 mov r7,r4
    { const uint32_t x = c.r[1]; c.pr = 0x06097DDEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06097DDEu) return; }  // 06097DDA jsr @r1 ; nop
    st32(c.r[14] + 12, c.r[0]);  // 06097DDE mov.l r0,@(12,r14)
    c.r[0] = ld32(c.r[14] + 12);  // 06097DE0 mov.l @(12,r14),r0
    goto L_06097DE6;  // 06097DE2 bra 0x06097DE6 ; nop
L_06097DE6:
    c.r[14] += 16;  // 06097DE6 add #16,r14
    c.r[15] = c.r[14];  // 06097DE8 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06097DEA lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06097DEC mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06097DEE rts ; nop
}

void f_06097DF4(SH2Context& c) {
    ran[2322] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06097DF4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06097DF6 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06097DF8 sts.l pr,@-r15
    c.r[15] -= 16;  // 06097DFA add #-16,r15
    c.r[14] = c.r[15];  // 06097DFC mov r15,r14
    st32(c.r[14], c.r[4]);  // 06097DFE mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 06097E00 mov.l r5,@(4,r14)
    st32(c.r[14] + 8, c.r[6]);  // 06097E02 mov.l r6,@(8,r14)
    c.r[1] = (uint32_t)(int16_t)ld16(0x06097EC6u);  // 06097E04 mov.w 0x06097EC6,r1
    c.r[4] = c.r[1];  // 06097E06 mov r1,r4
    c.r[8] = ld32(0x06097ECCu);  // 06097E08 mov.l 0x06097ECC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06097E0Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06097E0Eu) return; }  // 06097E0A jsr @r8 ; nop
    c.r[1] = ld32(c.r[14]);  // 06097E0E mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06097E10 tst r1,r1
    if (!c.t) { goto L_06097E26; }  // 06097E12 bf 0x06097E26
    c.r[4] = 0xFFFFFFF5u;  // 06097E14 mov #-11,r4
    c.r[8] = ld32(0x06097ED0u);  // 06097E16 mov.l 0x06097ED0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06097E1Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06097E1Cu) return; }  // 06097E18 jsr @r8 ; nop
    c.r[8] = ld32(0x06097ED4u);  // 06097E1C mov.l 0x06097ED4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06097E22u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06097E22u) return; }  // 06097E1E jsr @r8 ; nop
    goto L_06097EB8;  // 06097E22 bra 0x06097EB8 ; nop
L_06097E26:
    c.r[1] = ld32(c.r[14]);  // 06097E26 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 4);  // 06097E28 mov.l @(4,r1),r2
    st32(c.r[14], c.r[2]);  // 06097E2A mov.l r2,@r14
    c.r[1] = ld32(c.r[14]);  // 06097E2C mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 16);  // 06097E2E mov.l @(16,r1),r2
    c.r[1] = c.r[2];  // 06097E30 mov r2,r1
    c.r[1] += 108;  // 06097E32 add #108,r1
    st32(c.r[14] + 12, c.r[1]);  // 06097E34 mov.l r1,@(12,r14)
    c.r[1] = ld32(c.r[14]);  // 06097E36 mov.l @r14,r1
    c.r[2] = ld32(c.r[14] + 4);  // 06097E38 mov.l @(4,r14),r2
    st32(c.r[1] + 24, c.r[2]);  // 06097E3A mov.l r2,@(24,r1)
    c.r[1] = ld32(c.r[14] + 4);  // 06097E3C mov.l @(4,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06097E3E tst r1,r1
    if (!c.t) { goto L_06097E7A; }  // 06097E40 bf 0x06097E7A
    c.r[2] = (uint32_t)(int16_t)ld16(0x06097EC8u);  // 06097E42 mov.w 0x06097EC8,r2
    c.r[1] = ld32(c.r[14] + 12);  // 06097E44 mov.l @(12,r14),r1
    c.r[7] = c.r[2];  // 06097E46 mov r2,r7
    c.r[6] = 0x0u;  // 06097E48 mov #0,r6
    c.r[5] = 0x0u;  // 06097E4A mov #0,r5
    c.r[4] = c.r[1];  // 06097E4C mov r1,r4
    c.r[8] = ld32(0x06097ED8u);  // 06097E4E mov.l 0x06097ED8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06097E54u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06097E54u) return; }  // 06097E50 jsr @r8 ; nop
    c.r[1] = ld32(c.r[14] + 12);  // 06097E54 mov.l @(12,r14),r1
    c.r[5] = 0x3u;  // 06097E56 mov #3,r5
    c.r[4] = c.r[1];  // 06097E58 mov r1,r4
    c.r[8] = ld32(0x06097EDCu);  // 06097E5A mov.l 0x06097EDC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06097E60u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06097E60u) return; }  // 06097E5C jsr @r8 ; nop
    c.r[2] = ld32(c.r[14]);  // 06097E60 mov.l @r14,r2
    c.r[1] = ld32(c.r[2] + 16);  // 06097E62 mov.l @(16,r2),r1
    c.r[6] = 0x0u;  // 06097E64 mov #0,r6
    c.r[5] = 0x0u;  // 06097E66 mov #0,r5
    c.r[4] = c.r[1];  // 06097E68 mov r1,r4
    c.r[8] = ld32(0x06097EE0u);  // 06097E6A mov.l 0x06097EE0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06097E70u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06097E70u) return; }  // 06097E6C jsr @r8 ; nop
    c.r[1] = ld32(c.r[14]);  // 06097E70 mov.l @r14,r1
    c.r[2] = 0x0u;  // 06097E72 mov #0,r2
    st32(c.r[1] + 28, c.r[2]);  // 06097E74 mov.l r2,@(28,r1)
    goto L_06097EB2;  // 06097E76 bra 0x06097EB2 ; nop
L_06097E7A:
    c.r[2] = (uint32_t)(int16_t)ld16(0x06097EC8u);  // 06097E7A mov.w 0x06097EC8,r2
    c.r[3] = ld32(0x06097EE4u);  // 06097E7C mov.l 0x06097EE4,r3
    c.r[1] = ld32(c.r[14] + 12);  // 06097E7E mov.l @(12,r14),r1
    c.r[7] = c.r[2];  // 06097E80 mov r2,r7
    c.r[6] = c.r[3];  // 06097E82 mov r3,r6
    c.r[5] = 0x0u;  // 06097E84 mov #0,r5
    c.r[4] = c.r[1];  // 06097E86 mov r1,r4
    c.r[8] = ld32(0x06097ED8u);  // 06097E88 mov.l 0x06097ED8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06097E8Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06097E8Eu) return; }  // 06097E8A jsr @r8 ; nop
    c.r[1] = ld32(c.r[14] + 12);  // 06097E8E mov.l @(12,r14),r1
    c.r[5] = 0x4u;  // 06097E90 mov #4,r5
    c.r[4] = c.r[1];  // 06097E92 mov r1,r4
    c.r[8] = ld32(0x06097EDCu);  // 06097E94 mov.l 0x06097EDC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06097E9Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06097E9Au) return; }  // 06097E96 jsr @r8 ; nop
    c.r[1] = ld32(0x06097EE8u);  // 06097E9A mov.l 0x06097EE8,r1
    c.r[3] = ld32(c.r[14]);  // 06097E9C mov.l @r14,r3
    c.r[2] = ld32(c.r[3] + 16);  // 06097E9E mov.l @(16,r3),r2
    c.r[6] = ld32(c.r[14]);  // 06097EA0 mov.l @r14,r6
    c.r[5] = c.r[1];  // 06097EA2 mov r1,r5
    c.r[4] = c.r[2];  // 06097EA4 mov r2,r4
    c.r[8] = ld32(0x06097EE0u);  // 06097EA6 mov.l 0x06097EE0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06097EACu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06097EACu) return; }  // 06097EA8 jsr @r8 ; nop
    c.r[1] = ld32(c.r[14]);  // 06097EAC mov.l @r14,r1
    c.r[2] = ld32(c.r[14] + 8);  // 06097EAE mov.l @(8,r14),r2
    st32(c.r[1] + 28, c.r[2]);  // 06097EB0 mov.l r2,@(28,r1)
L_06097EB2:
    c.r[8] = ld32(0x06097EECu);  // 06097EB2 mov.l 0x06097EEC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06097EB8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06097EB8u) return; }  // 06097EB4 jsr @r8 ; nop
L_06097EB8:
    c.r[14] += 16;  // 06097EB8 add #16,r14
    c.r[15] = c.r[14];  // 06097EBA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06097EBC lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06097EBE mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06097EC0 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06097EC2 rts ; nop
}

void f_06097EF0(SH2Context& c) {
    ran[2323] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06097EF0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06097EF2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06097EF4 sts.l pr,@-r15
    c.r[15] -= 12;  // 06097EF6 add #-12,r15
    c.r[14] = c.r[15];  // 06097EF8 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06097EFA mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 06097EFC mov.l r5,@(4,r14)
    c.r[1] = (uint32_t)(int16_t)ld16(0x06097F7Au);  // 06097EFE mov.w 0x06097F7A,r1
    c.r[4] = c.r[1];  // 06097F00 mov r1,r4
    c.r[8] = ld32(0x06097F7Cu);  // 06097F02 mov.l 0x06097F7C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06097F08u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06097F08u) return; }  // 06097F04 jsr @r8 ; nop
    c.r[1] = ld32(c.r[14]);  // 06097F08 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06097F0A tst r1,r1
    if (!c.t) { goto L_06097F22; }  // 06097F0C bf 0x06097F22
    c.r[4] = 0xFFFFFFF5u;  // 06097F0E mov #-11,r4
    c.r[8] = ld32(0x06097F80u);  // 06097F10 mov.l 0x06097F80,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06097F16u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06097F16u) return; }  // 06097F12 jsr @r8 ; nop
    c.r[8] = ld32(0x06097F84u);  // 06097F16 mov.l 0x06097F84,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06097F1Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06097F1Cu) return; }  // 06097F18 jsr @r8 ; nop
    c.r[0] = 0x0u;  // 06097F1C mov #0,r0
    goto L_06097F6C;  // 06097F1E bra 0x06097F6C ; nop
L_06097F22:
    c.r[1] = ld32(c.r[14]);  // 06097F22 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 4);  // 06097F24 mov.l @(4,r1),r2
    st32(c.r[14], c.r[2]);  // 06097F26 mov.l r2,@r14
    c.r[1] = ld32(c.r[14]);  // 06097F28 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 16);  // 06097F2A mov.l @(16,r1),r2
    c.r[1] = c.r[2];  // 06097F2C mov r2,r1
    c.r[1] += 108;  // 06097F2E add #108,r1
    c.r[2] = ld32(c.r[1] + 12);  // 06097F30 mov.l @(12,r1),r2
    st32(c.r[14] + 8, c.r[2]);  // 06097F32 mov.l r2,@(8,r14)
    c.r[1] = ld32(c.r[14]);  // 06097F34 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 20);  // 06097F36 mov.l @(20,r1),r2
    c.r[1] = c.r[2];  // 06097F38 mov r2,r1
    c.r[1] += 28;  // 06097F3A add #28,r1
    c.r[2] = ld32(c.r[1]);  // 06097F3C mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06097F3E tst r2,r2
    if (!c.t) { goto L_06097F56; }  // 06097F40 bf 0x06097F56
    c.r[1] = ld32(c.r[14]);  // 06097F42 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 20);  // 06097F44 mov.l @(20,r1),r2
    c.r[1] = c.r[2];  // 06097F46 mov r2,r1
    c.r[1] += 28;  // 06097F48 add #28,r1
    c.r[2] = ld32(c.r[14] + 8);  // 06097F4A mov.l @(8,r14),r2
    c.r[5] = c.r[1];  // 06097F4C mov r1,r5
    c.r[4] = c.r[2];  // 06097F4E mov r2,r4
    c.r[8] = ld32(0x06097F88u);  // 06097F50 mov.l 0x06097F88,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06097F56u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06097F56u) return; }  // 06097F52 jsr @r8 ; nop
L_06097F56:
    c.r[1] = ld32(c.r[14] + 4);  // 06097F56 mov.l @(4,r14),r1
    c.r[2] = ld32(c.r[14] + 8);  // 06097F58 mov.l @(8,r14),r2
    c.r[3] = ld32(c.r[2] + 4);  // 06097F5A mov.l @(4,r2),r3
    st32(c.r[1], c.r[3]);  // 06097F5C mov.l r3,@r1
    c.r[8] = ld32(0x06097F8Cu);  // 06097F5E mov.l 0x06097F8C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06097F64u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06097F64u) return; }  // 06097F60 jsr @r8 ; nop
    c.r[1] = ld32(c.r[14] + 8);  // 06097F64 mov.l @(8,r14),r1
    c.r[0] = ld32(c.r[1]);  // 06097F66 mov.l @r1,r0
    goto L_06097F6C;  // 06097F68 bra 0x06097F6C ; nop
L_06097F6C:
    c.r[14] += 12;  // 06097F6C add #12,r14
    c.r[15] = c.r[14];  // 06097F6E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06097F70 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06097F72 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06097F74 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06097F76 rts ; nop
}

void f_06097F90(SH2Context& c) {
    ran[2324] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06097F90 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06097F92 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06097F94 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06097F96 sts.l pr,@-r15
    c.r[15] -= 20;  // 06097F98 add #-20,r15
    c.r[14] = c.r[15];  // 06097F9A mov r15,r14
    st32(c.r[14], c.r[4]);  // 06097F9C mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 06097F9E mov.l r5,@(4,r14)
    st32(c.r[14] + 8, c.r[6]);  // 06097FA0 mov.l r6,@(8,r14)
    st32(c.r[14] + 12, c.r[7]);  // 06097FA2 mov.l r7,@(12,r14)
    c.r[0] = ld32(c.r[14] + 12);  // 06097FA4 mov.l @(12,r14),r0
    c.t = c.r[0] == 0x2u;  // 06097FA6 cmp/eq #2,r0
    if (!c.t) { goto L_06097FB8; }  // 06097FA8 bf 0x06097FB8
    c.r[1] = ld32(c.r[14] + 8);  // 06097FAA mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 06097FAC mov r1,r2
    c.r[1] = c.r[2];  // 06097FAE mov r2,r1
    c.r[1] += c.r[1];  // 06097FB0 add r1,r1
    st32(c.r[14] + 8, c.r[1]);  // 06097FB2 mov.l r1,@(8,r14)
    c.r[1] = 0x1u;  // 06097FB4 mov #1,r1
    st32(c.r[14] + 12, c.r[1]);  // 06097FB6 mov.l r1,@(12,r14)
L_06097FB8:
    c.r[1] = ld32(c.r[14]);  // 06097FB8 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 20);  // 06097FBA mov.l @(20,r1),r2
    st32(c.r[14] + 16, c.r[2]);  // 06097FBC mov.l r2,@(16,r14)
    c.r[0] = ld32(c.r[14] + 12);  // 06097FBE mov.l @(12,r14),r0
    c.t = c.r[0] == 0x1u;  // 06097FC0 cmp/eq #1,r0
    if (c.t) { goto L_06097FD0; }  // 06097FC2 bt 0x06097FD0
    c.r[1] = ld32(c.r[14] + 16);  // 06097FC4 mov.l @(16,r14),r1
    c.r[2] = ld32(c.r[1] + 16);  // 06097FC6 mov.l @(16,r1),r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06097FC8 tst r2,r2
    if (!c.t) { goto L_06097FD0; }  // 06097FCA bf 0x06097FD0
    goto L_0609801C;  // 06097FCC bra 0x0609801C ; nop
L_06097FD0:
    c.r[1] = ld32(c.r[14] + 16);  // 06097FD0 mov.l @(16,r14),r1
    c.r[3] = ld32(c.r[14] + 16);  // 06097FD2 mov.l @(16,r14),r3
    c.r[2] = ld32(c.r[3] + 8);  // 06097FD4 mov.l @(8,r3),r2
    c.r[3] = c.r[2];  // 06097FD6 mov r2,r3
    c.t = (int32_t)c.r[3] >= 0;  // 06097FD8 cmp/pz r3
    if (c.t) { goto L_06097FE0; }  // 06097FDA bt 0x06097FE0
    c.r[7] = (uint32_t)(int16_t)ld16(0x0609804Cu);  // 06097FDC mov.w 0x0609804C,r7
    c.r[3] += c.r[7];  // 06097FDE add r7,r3
L_06097FE0:
    c.r[4] = c.r[3];  // 06097FE0 mov r3,r4
    c.r[3] = ld32(0x06098050u);  // 06097FE2 mov.l 0x06098050,r3
    { const uint32_t x = c.r[3]; c.pr = 0x06097FE8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06097FE8u) return; }  // 06097FE4 jsr @r3 ; nop
    c.r[3] = c.r[4];  // 06097FE8 mov r4,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x0609804Eu);  // 06097FEA mov.w 0x0609804E,r7
    c.macl = c.r[3] * c.r[7];  // 06097FEC mul.l r7,r3
    c.r[3] = c.macl;  // 06097FEE sts macl,r3
    c.r[2] -= c.r[3];  // 06097FF0 sub r3,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0609804Eu);  // 06097FF2 mov.w 0x0609804E,r3
    c.r[9] = c.r[3];  // 06097FF4 mov r3,r9
    c.r[9] -= c.r[2];  // 06097FF6 sub r2,r9
    c.r[2] = c.r[9];  // 06097FF8 mov r9,r2
    c.r[3] = c.r[2];  // 06097FFA mov r2,r3
    c.t = (int32_t)c.r[3] >= 0;  // 06097FFC cmp/pz r3
    if (c.t) { goto L_06098004; }  // 06097FFE bt 0x06098004
    c.r[7] = (uint32_t)(int16_t)ld16(0x0609804Cu);  // 06098000 mov.w 0x0609804C,r7
    c.r[3] += c.r[7];  // 06098002 add r7,r3
L_06098004:
    c.r[4] = c.r[3];  // 06098004 mov r3,r4
    c.r[3] = ld32(0x06098050u);  // 06098006 mov.l 0x06098050,r3
    { const uint32_t x = c.r[3]; c.pr = 0x0609800Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609800Cu) return; }  // 06098008 jsr @r3 ; nop
    c.r[3] = c.r[4];  // 0609800C mov r4,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x0609804Eu);  // 0609800E mov.w 0x0609804E,r7
    c.macl = c.r[3] * c.r[7];  // 06098010 mul.l r7,r3
    c.r[3] = c.macl;  // 06098012 sts macl,r3
    c.r[2] -= c.r[3];  // 06098014 sub r3,r2
    st32(c.r[1] + 24, c.r[2]);  // 06098016 mov.l r2,@(24,r1)
    goto L_06098022;  // 06098018 bra 0x06098022 ; nop
L_0609801C:
    c.r[1] = ld32(c.r[14] + 16);  // 0609801C mov.l @(16,r14),r1
    c.r[2] = 0x0u;  // 0609801E mov #0,r2
    st32(c.r[1] + 24, c.r[2]);  // 06098020 mov.l r2,@(24,r1)
L_06098022:
    c.r[1] = ld32(c.r[14] + 12);  // 06098022 mov.l @(12,r14),r1
    c.r[2] = ld32(c.r[14] + 8);  // 06098024 mov.l @(8,r14),r2
    c.r[3] = ld32(c.r[14] + 4);  // 06098026 mov.l @(4,r14),r3
    c.r[7] = ld32(c.r[14]);  // 06098028 mov.l @r14,r7
    c.r[6] = ld32(c.r[7] + 16);  // 0609802A mov.l @(16,r7),r6
    c.r[4] = c.r[6];  // 0609802C mov r6,r4
    c.r[4] += 108;  // 0609802E add #108,r4
    c.r[7] = c.r[1];  // 06098030 mov r1,r7
    c.r[6] = c.r[2];  // 06098032 mov r2,r6
    c.r[5] = c.r[3];  // 06098034 mov r3,r5
    c.r[8] = ld32(0x06098054u);  // 06098036 mov.l 0x06098054,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0609803Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609803Cu) return; }  // 06098038 jsr @r8 ; nop
    c.r[14] += 20;  // 0609803C add #20,r14
    c.r[15] = c.r[14];  // 0609803E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06098040 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06098042 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06098044 mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06098046 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06098048 rts ; nop
}

void f_06098058(SH2Context& c) {
    ran[2325] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06098058 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609805A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609805C sts.l pr,@-r15
    c.r[15] -= 16;  // 0609805E add #-16,r15
    c.r[14] = c.r[15];  // 06098060 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06098062 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 06098064 mov.l r5,@(4,r14)
    st32(c.r[14] + 8, c.r[6]);  // 06098066 mov.l r6,@(8,r14)
    st32(c.r[14] + 12, c.r[7]);  // 06098068 mov.l r7,@(12,r14)
    c.r[1] = (uint32_t)(int16_t)ld16(0x06098100u);  // 0609806A mov.w 0x06098100,r1
    c.r[4] = c.r[1];  // 0609806C mov r1,r4
    c.r[8] = ld32(0x06098108u);  // 0609806E mov.l 0x06098108,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06098074u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06098074u) return; }  // 06098070 jsr @r8 ; nop
    c.r[1] = ld32(c.r[14]);  // 06098074 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06098076 tst r1,r1
    if (!c.t) { goto L_0609808C; }  // 06098078 bf 0x0609808C
    c.r[4] = 0xFFFFFFF5u;  // 0609807A mov #-11,r4
    c.r[8] = ld32(0x0609810Cu);  // 0609807C mov.l 0x0609810C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06098082u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06098082u) return; }  // 0609807E jsr @r8 ; nop
    c.r[8] = ld32(0x06098110u);  // 06098082 mov.l 0x06098110,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06098088u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06098088u) return; }  // 06098084 jsr @r8 ; nop
    goto L_060980F2;  // 06098088 bra 0x060980F2 ; nop
L_0609808C:
    c.r[1] = ld32(c.r[14] + 8);  // 0609808C mov.l @(8,r14),r1
    c.t = (int32_t)c.r[1] >= 0;  // 0609808E cmp/pz r1
    if (c.t) { goto L_060980A4; }  // 06098090 bt 0x060980A4
    c.r[4] = 0xFFFFFFF2u;  // 06098092 mov #-14,r4
    c.r[8] = ld32(0x0609810Cu);  // 06098094 mov.l 0x0609810C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0609809Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609809Au) return; }  // 06098096 jsr @r8 ; nop
    c.r[8] = ld32(0x06098110u);  // 0609809A mov.l 0x06098110,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060980A0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060980A0u) return; }  // 0609809C jsr @r8 ; nop
    goto L_060980F2;  // 060980A0 bra 0x060980F2 ; nop
L_060980A4:
    c.r[0] = ld32(c.r[14] + 12);  // 060980A4 mov.l @(12,r14),r0
    c.t = c.r[0] == 0x1u;  // 060980A6 cmp/eq #1,r0
    if (c.t) { goto L_060980D2; }  // 060980A8 bt 0x060980D2
    c.r[0] = ld32(c.r[14] + 12);  // 060980AA mov.l @(12,r14),r0
    c.t = c.r[0] == 0x2u;  // 060980AC cmp/eq #2,r0
    if (c.t) { goto L_060980D2; }  // 060980AE bt 0x060980D2
    c.r[1] = ld32(c.r[14] + 12);  // 060980B0 mov.l @(12,r14),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06098102u);  // 060980B2 mov.w 0x06098102,r2
    c.t = c.r[1] == c.r[2];  // 060980B4 cmp/eq r2,r1
    if (c.t) { goto L_060980D2; }  // 060980B6 bt 0x060980D2
    c.r[1] = ld32(c.r[14] + 12);  // 060980B8 mov.l @(12,r14),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06098104u);  // 060980BA mov.w 0x06098104,r2
    c.t = c.r[1] == c.r[2];  // 060980BC cmp/eq r2,r1
    if (c.t) { goto L_060980D2; }  // 060980BE bt 0x060980D2
    c.r[4] = 0xFFFFFFEFu;  // 060980C0 mov #-17,r4
    c.r[8] = ld32(0x0609810Cu);  // 060980C2 mov.l 0x0609810C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060980C8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060980C8u) return; }  // 060980C4 jsr @r8 ; nop
    c.r[8] = ld32(0x06098110u);  // 060980C8 mov.l 0x06098110,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060980CEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060980CEu) return; }  // 060980CA jsr @r8 ; nop
    goto L_060980F2;  // 060980CE bra 0x060980F2 ; nop
L_060980D2:
    c.r[1] = ld32(c.r[14]);  // 060980D2 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 4);  // 060980D4 mov.l @(4,r1),r2
    st32(c.r[14], c.r[2]);  // 060980D6 mov.l r2,@r14
    c.r[1] = ld32(c.r[14] + 12);  // 060980D8 mov.l @(12,r14),r1
    c.r[2] = ld32(c.r[14] + 8);  // 060980DA mov.l @(8,r14),r2
    c.r[3] = ld32(c.r[14] + 4);  // 060980DC mov.l @(4,r14),r3
    c.r[7] = c.r[1];  // 060980DE mov r1,r7
    c.r[6] = c.r[2];  // 060980E0 mov r2,r6
    c.r[5] = c.r[3];  // 060980E2 mov r3,r5
    c.r[4] = ld32(c.r[14]);  // 060980E4 mov.l @r14,r4
    c.r[8] = ld32(0x06098114u);  // 060980E6 mov.l 0x06098114,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060980ECu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060980ECu) return; }  // 060980E8 jsr @r8 ; nop
    c.r[8] = ld32(0x06098118u);  // 060980EC mov.l 0x06098118,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060980F2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060980F2u) return; }  // 060980EE jsr @r8 ; nop
L_060980F2:
    c.r[14] += 16;  // 060980F2 add #16,r14
    c.r[15] = c.r[14];  // 060980F4 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060980F6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060980F8 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060980FA mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060980FC rts ; nop
}

void f_0609811C(SH2Context& c) {
    ran[2326] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609811C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609811E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06098120 sts.l pr,@-r15
    c.r[15] -= 24;  // 06098122 add #-24,r15
    c.r[14] = c.r[15];  // 06098124 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06098126 mov.l r4,@r14
    c.r[1] = ld32(c.r[14]);  // 06098128 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 16);  // 0609812A mov.l @(16,r1),r2
    c.r[1] = c.r[2];  // 0609812C mov r2,r1
    c.r[1] += 108;  // 0609812E add #108,r1
    st32(c.r[14] + 20, c.r[1]);  // 06098130 mov.l r1,@(20,r14)
    c.r[1] = ld32(c.r[14] + 20);  // 06098132 mov.l @(20,r14),r1
    c.r[4] = c.r[1];  // 06098134 mov r1,r4
    c.r[8] = ld32(0x06098190u);  // 06098136 mov.l 0x06098190,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0609813Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609813Cu) return; }  // 06098138 jsr @r8 ; nop
    st32(c.r[14] + 8, c.r[0]);  // 0609813C mov.l r0,@(8,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 0609813E mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[14] + 20);  // 06098140 mov.l @(20,r14),r2
    c.r[5] = c.r[1];  // 06098142 mov r1,r5
    c.r[4] = c.r[2];  // 06098144 mov r2,r4
    c.r[8] = ld32(0x06098194u);  // 06098146 mov.l 0x06098194,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0609814Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609814Cu) return; }  // 06098148 jsr @r8 ; nop
    c.r[1] = ld32(c.r[14] + 20);  // 0609814C mov.l @(20,r14),r1
    c.r[2] = ld32(c.r[1]);  // 0609814E mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06098150 tst r2,r2
    if (c.t) { goto L_06098182; }  // 06098152 bt 0x06098182
    c.r[1] = c.r[14];  // 06098154 mov r14,r1
    c.r[1] += 16;  // 06098156 add #16,r1
    c.r[2] = c.r[14];  // 06098158 mov r14,r2
    c.r[2] += 12;  // 0609815A add #12,r2
    c.r[3] = c.r[14];  // 0609815C mov r14,r3
    c.r[3] += 4;  // 0609815E add #4,r3
    c.r[4] = ld32(c.r[14] + 20);  // 06098160 mov.l @(20,r14),r4
    c.r[7] = c.r[1];  // 06098162 mov r1,r7
    c.r[6] = c.r[2];  // 06098164 mov r2,r6
    c.r[5] = c.r[3];  // 06098166 mov r3,r5
    c.r[8] = ld32(0x06098198u);  // 06098168 mov.l 0x06098198,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0609816Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609816Eu) return; }  // 0609816A jsr @r8 ; nop
    c.r[1] = ld32(c.r[14] + 16);  // 0609816E mov.l @(16,r14),r1
    c.r[2] = ld32(c.r[14] + 12);  // 06098170 mov.l @(12,r14),r2
    c.r[3] = ld32(c.r[14] + 4);  // 06098172 mov.l @(4,r14),r3
    c.r[4] = ld32(c.r[14] + 20);  // 06098174 mov.l @(20,r14),r4
    c.r[7] = c.r[1];  // 06098176 mov r1,r7
    c.r[6] = c.r[2];  // 06098178 mov r2,r6
    c.r[5] = c.r[3];  // 0609817A mov r3,r5
    c.r[8] = ld32(0x0609819Cu);  // 0609817C mov.l 0x0609819C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06098182u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06098182u) return; }  // 0609817E jsr @r8 ; nop
L_06098182:
    c.r[14] += 24;  // 06098182 add #24,r14
    c.r[15] = c.r[14];  // 06098184 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06098186 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06098188 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0609818A mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0609818C rts ; nop
}

void f_060981A0(SH2Context& c) {
    ran[2327] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060981A0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060981A2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060981A4 sts.l pr,@-r15
    c.r[15] -= 4;  // 060981A6 add #-4,r15
    c.r[14] = c.r[15];  // 060981A8 mov r15,r14
    st32(c.r[14], c.r[4]);  // 060981AA mov.l r4,@r14
    c.r[1] = (uint32_t)(int16_t)ld16(0x060981F0u);  // 060981AC mov.w 0x060981F0,r1
    c.r[4] = c.r[1];  // 060981AE mov r1,r4
    c.r[8] = ld32(0x060981F4u);  // 060981B0 mov.l 0x060981F4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060981B6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060981B6u) return; }  // 060981B2 jsr @r8 ; nop
    c.r[1] = ld32(c.r[14]);  // 060981B6 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060981B8 tst r1,r1
    if (!c.t) { goto L_060981CE; }  // 060981BA bf 0x060981CE
    c.r[4] = 0xFFFFFFF5u;  // 060981BC mov #-11,r4
    c.r[8] = ld32(0x060981F8u);  // 060981BE mov.l 0x060981F8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060981C4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060981C4u) return; }  // 060981C0 jsr @r8 ; nop
    c.r[8] = ld32(0x060981FCu);  // 060981C4 mov.l 0x060981FC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060981CAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060981CAu) return; }  // 060981C6 jsr @r8 ; nop
    goto L_060981E2;  // 060981CA bra 0x060981E2 ; nop
L_060981CE:
    c.r[1] = ld32(c.r[14]);  // 060981CE mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 4);  // 060981D0 mov.l @(4,r1),r2
    st32(c.r[14], c.r[2]);  // 060981D2 mov.l r2,@r14
    c.r[4] = ld32(c.r[14]);  // 060981D4 mov.l @r14,r4
    c.r[8] = ld32(0x06098200u);  // 060981D6 mov.l 0x06098200,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060981DCu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060981DCu) return; }  // 060981D8 jsr @r8 ; nop
    c.r[8] = ld32(0x06098204u);  // 060981DC mov.l 0x06098204,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060981E2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060981E2u) return; }  // 060981DE jsr @r8 ; nop
L_060981E2:
    c.r[14] += 4;  // 060981E2 add #4,r14
    c.r[15] = c.r[14];  // 060981E4 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060981E6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060981E8 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060981EA mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060981EC rts ; nop
}

void f_06098208(SH2Context& c) {
    ran[2328] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06098208 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609820A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609820C sts.l pr,@-r15
    c.r[15] -= 12;  // 0609820E add #-12,r15
    c.r[14] = c.r[15];  // 06098210 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06098212 mov.l r4,@r14
    c.r[1] = (uint32_t)(int16_t)ld16(0x0609827Eu);  // 06098214 mov.w 0x0609827E,r1
    c.r[4] = c.r[1];  // 06098216 mov r1,r4
    c.r[8] = ld32(0x06098280u);  // 06098218 mov.l 0x06098280,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0609821Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609821Eu) return; }  // 0609821A jsr @r8 ; nop
    c.r[1] = ld32(c.r[14]);  // 0609821E mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06098220 tst r1,r1
    if (!c.t) { goto L_06098238; }  // 06098222 bf 0x06098238
    c.r[4] = 0xFFFFFFF5u;  // 06098224 mov #-11,r4
    c.r[8] = ld32(0x06098284u);  // 06098226 mov.l 0x06098284,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0609822Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609822Cu) return; }  // 06098228 jsr @r8 ; nop
    c.r[8] = ld32(0x06098288u);  // 0609822C mov.l 0x06098288,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06098232u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06098232u) return; }  // 0609822E jsr @r8 ; nop
    c.r[0] = 0xFFFFFFFFu;  // 06098232 mov #-1,r0
    goto L_06098270;  // 06098234 bra 0x06098270 ; nop
L_06098238:
    c.r[1] = ld32(c.r[14]);  // 06098238 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 4);  // 0609823A mov.l @(4,r1),r2
    st32(c.r[14], c.r[2]);  // 0609823C mov.l r2,@r14
    c.r[1] = ld32(c.r[14]);  // 0609823E mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 16);  // 06098240 mov.l @(16,r1),r2
    c.r[1] = c.r[2];  // 06098242 mov r2,r1
    c.r[1] += 108;  // 06098244 add #108,r1
    c.r[4] = c.r[1];  // 06098246 mov r1,r4
    c.r[8] = ld32(0x0609828Cu);  // 06098248 mov.l 0x0609828C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0609824Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609824Eu) return; }  // 0609824A jsr @r8 ; nop
    st32(c.r[14] + 4, c.r[0]);  // 0609824E mov.l r0,@(4,r14)
    c.r[8] = ld32(0x06098290u);  // 06098250 mov.l 0x06098290,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06098256u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06098256u) return; }  // 06098252 jsr @r8 ; nop
    st32(c.r[14] + 8, c.r[0]);  // 06098256 mov.l r0,@(8,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 06098258 mov.l @(8,r14),r1
    c.t = (int32_t)c.r[1] >= 0;  // 0609825A cmp/pz r1
    if (c.t) { goto L_06098264; }  // 0609825C bt 0x06098264
    c.r[0] = ld32(c.r[14] + 8);  // 0609825E mov.l @(8,r14),r0
    goto L_06098270;  // 06098260 bra 0x06098270 ; nop
L_06098264:
    c.r[2] = ld32(c.r[14] + 4);  // 06098264 mov.l @(4,r14),r2
    c.r[1] = c.r[2];  // 06098266 mov r2,r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06098268 shlr r1
    c.r[0] = c.r[1];  // 0609826A mov r1,r0
    goto L_06098270;  // 0609826C bra 0x06098270 ; nop
L_06098270:
    c.r[14] += 12;  // 06098270 add #12,r14
    c.r[15] = c.r[14];  // 06098272 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06098274 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06098276 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06098278 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0609827A rts ; nop
}

void f_06098294(SH2Context& c) {
    ran[2329] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06098294 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06098296 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06098298 sts.l pr,@-r15
    c.r[15] -= 8;  // 0609829A add #-8,r15
    c.r[14] = c.r[15];  // 0609829C mov r15,r14
    st32(c.r[14], c.r[4]);  // 0609829E mov.l r4,@r14
    c.r[1] = ld32(c.r[14]);  // 060982A0 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 16);  // 060982A2 mov.l @(16,r1),r2
    c.r[1] = c.r[2];  // 060982A4 mov r2,r1
    c.r[1] += 108;  // 060982A6 add #108,r1
    c.r[4] = c.r[1];  // 060982A8 mov r1,r4
    c.r[8] = ld32(0x060982D8u);  // 060982AA mov.l 0x060982D8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060982B0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060982B0u) return; }  // 060982AC jsr @r8 ; nop
    st32(c.r[14] + 4, c.r[0]);  // 060982B0 mov.l r0,@(4,r14)
    c.r[1] = ld32(c.r[14] + 4);  // 060982B2 mov.l @(4,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060982B4 tst r1,r1
    if (!c.t) { goto L_060982C2; }  // 060982B6 bf 0x060982C2
    c.r[0] = 0x1u;  // 060982B8 mov #1,r0
    goto L_060982C8;  // 060982BA bra 0x060982C8 ; nop
L_060982C2:
    c.r[0] = 0x0u;  // 060982C2 mov #0,r0
    goto L_060982C8;  // 060982C4 bra 0x060982C8 ; nop
L_060982C8:
    c.r[14] += 8;  // 060982C8 add #8,r14
    c.r[15] = c.r[14];  // 060982CA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060982CC lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060982CE mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060982D0 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060982D2 rts ; nop
}

void f_060982DC(SH2Context& c) {
    ran[2330] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060982DC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060982DE mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060982E0 sts.l pr,@-r15
    c.r[15] -= 8;  // 060982E2 add #-8,r15
    c.r[14] = c.r[15];  // 060982E4 mov r15,r14
    st32(c.r[14], c.r[4]);  // 060982E6 mov.l r4,@r14
    c.r[1] = (uint32_t)(int16_t)ld16(0x06098336u);  // 060982E8 mov.w 0x06098336,r1
    c.r[4] = c.r[1];  // 060982EA mov r1,r4
    c.r[8] = ld32(0x06098338u);  // 060982EC mov.l 0x06098338,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060982F2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060982F2u) return; }  // 060982EE jsr @r8 ; nop
    c.r[1] = ld32(c.r[14]);  // 060982F2 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060982F4 tst r1,r1
    if (!c.t) { goto L_0609830C; }  // 060982F6 bf 0x0609830C
    c.r[4] = 0xFFFFFFF5u;  // 060982F8 mov #-11,r4
    c.r[8] = ld32(0x0609833Cu);  // 060982FA mov.l 0x0609833C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06098300u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06098300u) return; }  // 060982FC jsr @r8 ; nop
    c.r[8] = ld32(0x06098340u);  // 06098300 mov.l 0x06098340,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06098306u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06098306u) return; }  // 06098302 jsr @r8 ; nop
    c.r[0] = 0x0u;  // 06098306 mov #0,r0
    goto L_06098328;  // 06098308 bra 0x06098328 ; nop
L_0609830C:
    c.r[1] = ld32(c.r[14]);  // 0609830C mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 4);  // 0609830E mov.l @(4,r1),r2
    st32(c.r[14], c.r[2]);  // 06098310 mov.l r2,@r14
    c.r[4] = ld32(c.r[14]);  // 06098312 mov.l @r14,r4
    c.r[8] = ld32(0x06098344u);  // 06098314 mov.l 0x06098344,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0609831Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609831Au) return; }  // 06098316 jsr @r8 ; nop
    st32(c.r[14] + 4, c.r[0]);  // 0609831A mov.l r0,@(4,r14)
    c.r[8] = ld32(0x06098348u);  // 0609831C mov.l 0x06098348,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06098322u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06098322u) return; }  // 0609831E jsr @r8 ; nop
    c.r[0] = ld32(c.r[14] + 4);  // 06098322 mov.l @(4,r14),r0
    goto L_06098328;  // 06098324 bra 0x06098328 ; nop
L_06098328:
    c.r[14] += 8;  // 06098328 add #8,r14
    c.r[15] = c.r[14];  // 0609832A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609832C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609832E mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06098330 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06098332 rts ; nop
}

void f_0609834C(SH2Context& c) {
    ran[2331] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609834C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609834E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06098350 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06098352 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06098354 mov r15,r14
    c.r[5] = c.r[4];  // 06098356 mov r4,r5
    c.r[9] = ld32(0x060983E4u);  // 06098358 mov.l 0x060983E4,r9
    c.r[4] = ld32(c.r[9]);  // 0609835A mov.l @r9,r4
    c.r[8] = (uint32_t)(int16_t)ld16(0x060983E0u);  // 0609835C mov.w 0x060983E0,r8
    c.r[0] = c.r[4];  // 0609835E mov r4,r0
    c.r[2] = ld32(c.r[0] + c.r[8]);  // 06098360 mov.l @(r0,r8),r2
    c.r[1] = 0xFFFFFFFEu;  // 06098362 mov #-2,r1
    c.r[2] &= c.r[1];  // 06098364 and r1,r2
    st32(c.r[0] + c.r[8], c.r[2]);  // 06098366 mov.l r2,@(r0,r8)
    c.r[1] = (uint32_t)(int16_t)ld16(0x060983E2u);  // 06098368 mov.w 0x060983E2,r1
    c.r[0] = ld32(0x060983E8u);  // 0609836A mov.l 0x060983E8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06098370u; c.r[4] += c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06098370u) return; }  // 0609836C jsr @r0 ; add r1,r4
    c.r[2] = c.r[0];  // 06098370 mov r0,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06098372 tst r2,r2
    if (!c.t) { goto L_06098384; }  // 06098374 bf 0x06098384
    c.r[1] = ld32(c.r[9]);  // 06098376 mov.l @r9,r1
    c.r[0] = c.r[1];  // 06098378 mov r1,r0
    c.r[3] = ld32(c.r[0] + c.r[8]);  // 0609837A mov.l @(r0,r8),r3
    c.r[0] = 0x1u;  // 0609837C mov #1,r0
    c.r[3] |= c.r[0];  // 0609837E or r0,r3
    c.r[0] = c.r[1];  // 06098380 mov r1,r0
    st32(c.r[0] + c.r[8], c.r[3]);  // 06098382 mov.l r3,@(r0,r8)
L_06098384:
    c.r[1] = 0x10u;  // 06098384 mov #16,r1
    c.r[2] += 16;  // 06098386 add #16,r2
    c.t = c.r[2] > c.r[1];  // 06098388 cmp/hi r1,r2
    { const bool k = c.t; c.r[0] = 0xFFFFFFFFu; if (k) { goto L_060983D4; } }  // 0609838A bt/s 0x060983D4 ; mov #-1,r0
    c.r[1] = c.r[2];  // 0609838E mov r2,r1
    c.r[1] += c.r[1];  // 06098390 add r1,r1
    c.r[0] = 0x0609839Cu;  // 06098392 mova 0x0609839C,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06098394 mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 06098396 add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x060983CEu: goto L_060983CE; case 0x060983CAu: goto L_060983CA; case 0x060983C6u: goto L_060983C6; case 0x060983C2u: goto L_060983C2; case 0x060983D2u: goto L_060983D2; case 0x060983BEu: goto L_060983BE; default: sh2_call(c, x); return; } }  // 06098398 jmp @r0 ; nop
L_060983BE:
    c.r[0] = 0x0u; goto L_060983D4;  // 060983BE bra 0x060983D4 ; mov #0,r0
L_060983C2:
    c.r[0] = 0xFFFFFFE9u; goto L_060983D4;  // 060983C2 bra 0x060983D4 ; mov #-23,r0
L_060983C6:
    c.r[0] = 0xFFFFFFFEu; goto L_060983D4;  // 060983C6 bra 0x060983D4 ; mov #-2,r0
L_060983CA:
    c.r[0] = 0xFFFFFFFDu; goto L_060983D4;  // 060983CA bra 0x060983D4 ; mov #-3,r0
L_060983CE:
    c.r[0] = 0xFFFFFFE7u; goto L_060983D4;  // 060983CE bra 0x060983D4 ; mov #-25,r0
L_060983D2:
    c.r[0] = 0xFFFFFFFFu;  // 060983D2 mov #-1,r0
L_060983D4:
    c.r[15] = c.r[14];  // 060983D4 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060983D6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060983D8 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060983DA mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060983DC rts ; mov.l @r15+,r8
}

void f_060983EC(SH2Context& c) {
    ran[2332] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060983EC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060983EE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060983F0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060983F2 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060983F4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060983F6 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060983F8 mov r15,r14
    c.r[11] = c.r[4];  // 060983FA mov r4,r11
    c.r[8] = c.r[5];  // 060983FC mov r5,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 060983FE tst r8,r8
    { const bool k = !c.t; c.r[10] = c.r[11]; if (k) { goto L_0609841A; } }  // 06098400 bf/s 0x0609841A ; mov r11,r10
    st32(c.r[11], c.r[6]);  // 06098404 mov.l r6,@r11
    c.r[5] = c.r[11];  // 06098406 mov r11,r5
    c.r[5] += 4;  // 06098408 add #4,r5
    c.r[0] = ld32(0x06098518u);  // 0609840A mov.l 0x06098518,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06098410u; c.r[4] = c.r[6]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06098410u) return; }  // 0609840C jsr @r0 ; mov r6,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 06098410 tst r0,r0
    if (!c.t) { goto L_06098502; }  // 06098412 bf 0x06098502
    c.r[9] = ld32(c.r[11] + 8);  // 06098414 mov.l @(8,r11),r9
    c.r[8] += 11; goto L_0609847C;  // 06098416 bra 0x0609847C ; add #11,r8
L_0609841A:
    c.r[1] = c.r[8];  // 0609841A mov r8,r1
    c.r[1] += 11;  // 0609841C add #11,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0609841E mov.b @r1,r0
    c.r[0] &= 0x80u;  // 06098420 and #128,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06098422 tst r0,r0
    { const bool k = c.t; c.r[9] = ld32(c.r[8] + 4); if (k) { goto L_06098442; } }  // 06098424 bt/s 0x06098442 ; mov.l @(4,r8),r9
    c.r[1] = (uint32_t)(int16_t)ld16(0x06098514u);  // 06098428 mov.w 0x06098514,r1
    c.r[4] = c.r[9];  // 0609842A mov r9,r4
    c.r[4] += c.r[1];  // 0609842C add r1,r4
    c.t = (int32_t)c.r[4] >= 0;  // 0609842E cmp/pz r4
    if (c.t) { goto L_06098434; }  // 06098430 bt 0x06098434
    c.r[4] += c.r[1];  // 06098432 add r1,r4
L_06098434:
    c.r[1] = ld32(0x0609851Cu);  // 06098434 mov.l 0x0609851C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609843Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609843Au) return; }  // 06098436 jsr @r1 ; nop
    c.r[9] = c.r[4];  // 0609843A mov r4,r9
    c.r[9] <<= 8;  // 0609843C shll8 r9
    c.r[9] += c.r[9];  // 0609843E add r9,r9
    c.r[9] <<= 2;  // 06098440 shll2 r9
L_06098442:
    st32(c.r[10], c.r[6]);  // 06098442 mov.l r6,@r10
    c.r[1] = ld32(c.r[8]);  // 06098444 mov.l @r8,r1
    c.r[2] = c.r[10];  // 06098446 mov r10,r2
    st32(c.r[10] + 4, c.r[1]);  // 06098448 mov.l r1,@(4,r10)
    st32(c.r[10] + 8, c.r[9]);  // 0609844A mov.l r9,@(8,r10)
    c.r[1] = c.r[8];  // 0609844C mov r8,r1
    c.r[1] += 8;  // 0609844E add #8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06098450 mov.b @r1,r1
    c.r[2] += 12;  // 06098452 add #12,r2
    st8(c.r[2], c.r[1]);  // 06098454 mov.b r1,@r2
    c.r[2] = c.r[10];  // 06098456 mov r10,r2
    c.r[1] = c.r[8];  // 06098458 mov r8,r1
    c.r[1] += 9;  // 0609845A add #9,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0609845C mov.b @r1,r1
    c.r[2] += 13;  // 0609845E add #13,r2
    st8(c.r[2], c.r[1]);  // 06098460 mov.b r1,@r2
    c.r[2] = c.r[10];  // 06098462 mov r10,r2
    c.r[1] = c.r[8];  // 06098464 mov r8,r1
    c.r[1] += 10;  // 06098466 add #10,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06098468 mov.b @r1,r1
    c.r[2] += 14;  // 0609846A add #14,r2
    st8(c.r[2], c.r[1]);  // 0609846C mov.b r1,@r2
    c.r[2] = c.r[10];  // 0609846E mov r10,r2
    c.r[1] = c.r[8];  // 06098470 mov r8,r1
    c.r[1] += 11;  // 06098472 add #11,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06098474 mov.b @r1,r1
    c.r[2] += 15;  // 06098476 add #15,r2
    st8(c.r[2], c.r[1]);  // 06098478 mov.b r1,@r2
    c.r[8] += 11;  // 0609847A add #11,r8
L_0609847C:
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0609847C mov.b @r8,r4
    c.r[0] = ld32(0x06098520u);  // 0609847E mov.l 0x06098520,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06098484u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06098484u) return; }  // 06098480 jsr @r0 ; extu.b r4,r4
    st32(c.r[10] + 16, c.r[0]);  // 06098484 mov.l r0,@(16,r10)
    c.r[7] = (uint32_t)(int16_t)ld16(0x06098514u);  // 06098486 mov.w 0x06098514,r7
    c.r[2] = c.r[9];  // 06098488 mov r9,r2
    c.r[2] += c.r[7];  // 0609848A add r7,r2
    c.r[1] = c.r[2];  // 0609848C mov r2,r1
    c.r[1] >>= 8;  // 0609848E shlr8 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06098490 shlr r1
    c.r[1] >>= 2;  // 06098492 shlr2 r1
    st32(c.r[10] + 20, c.r[1]);  // 06098494 mov.l r1,@(20,r10)
    c.r[1] = ld32(c.r[10] + 16);  // 06098496 mov.l @(16,r10),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06098498 tst r1,r1
    if (!c.t) { goto L_060984A2; }  // 0609849A bf 0x060984A2
    st32(c.r[10] + 24, c.r[1]);  // 0609849C mov.l r1,@(24,r10)
    goto L_060984D2;  // 0609849E bra 0x060984D2 ; nop
L_060984A2:
    c.t = (int32_t)c.r[9] >= 0;  // 060984A2 cmp/pz r9
    { const bool k = c.t; c.r[4] = c.r[9]; if (k) { goto L_060984AA; } }  // 060984A4 bt/s 0x060984AA ; mov r9,r4
    c.r[4] = c.r[2];  // 060984A8 mov r2,r4
L_060984AA:
    c.r[3] = ld32(0x0609851Cu);  // 060984AA mov.l 0x0609851C,r3
    { const uint32_t x = c.r[3]; c.pr = 0x060984B0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060984B0u) return; }  // 060984AC jsr @r3 ; nop
    c.r[1] = (uint32_t)(int16_t)ld16(0x06098516u);  // 060984B0 mov.w 0x06098516,r1
    c.r[4] <<= 8;  // 060984B2 shll8 r4
    c.r[4] += c.r[4];  // 060984B4 add r4,r4
    c.r[4] <<= 2;  // 060984B6 shll2 r4
    c.r[9] -= c.r[4];  // 060984B8 sub r4,r9
    c.r[2] = c.r[1];  // 060984BA mov r1,r2
    c.r[2] -= c.r[9];  // 060984BC sub r9,r2
    c.t = (int32_t)c.r[2] >= 0;  // 060984BE cmp/pz r2
    { const bool k = c.t; c.r[4] = c.r[2]; if (k) { goto L_060984C6; } }  // 060984C0 bt/s 0x060984C6 ; mov r2,r4
    c.r[4] += c.r[7];  // 060984C4 add r7,r4
L_060984C6:
    { const uint32_t x = c.r[3]; c.pr = 0x060984CAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060984CAu) return; }  // 060984C6 jsr @r3 ; nop
    c.macl = c.r[4] * c.r[1];  // 060984CA mul.l r1,r4
    c.r[1] = c.macl;  // 060984CC sts macl,r1
    c.r[2] -= c.r[1];  // 060984CE sub r1,r2
    st32(c.r[10] + 24, c.r[2]);  // 060984D0 mov.l r2,@(24,r10)
L_060984D2:
    c.r[0] = ld32(0x06098524u);  // 060984D2 mov.l 0x06098524,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060984D8u; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060984D8u) return; }  // 060984D4 jsr @r0 ; mov r11,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 060984D8 tst r0,r0
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_06098504; } }  // 060984DA bt/s 0x06098504 ; mov #0,r0
    c.r[1] = c.r[11];  // 060984DE mov r11,r1
    c.r[1] += 76;  // 060984E0 add #76,r1
    c.r[2] = 0x0u;  // 060984E2 mov #0,r2
    st32(c.r[1], c.r[2]);  // 060984E4 mov.l r2,@r1
    c.r[1] = c.r[11];  // 060984E6 mov r11,r1
    c.r[1] += 80;  // 060984E8 add #80,r1
    st32(c.r[1], c.r[2]);  // 060984EA mov.l r2,@r1
    c.r[3] = c.r[11];  // 060984EC mov r11,r3
    c.r[3] += 84;  // 060984EE add #84,r3
    c.r[1] = c.r[11];  // 060984F0 mov r11,r1
    c.r[1] += 88;  // 060984F2 add #88,r1
    st32(c.r[1], c.r[2]);  // 060984F4 mov.l r2,@r1
    st32(c.r[3], c.r[2]);  // 060984F6 mov.l r2,@r3
    c.r[11] += 92;  // 060984F8 add #92,r11
    c.r[1] = ld32(0x06098528u);  // 060984FA mov.l 0x06098528,r1
    st32(c.r[11], c.r[1]);  // 060984FC mov.l r1,@r11
    c.r[0] = 0x1u; goto L_06098504;  // 060984FE bra 0x06098504 ; mov #1,r0
L_06098502:
    c.r[0] = 0x0u;  // 06098502 mov #0,r0
L_06098504:
    c.r[15] = c.r[14];  // 06098504 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06098506 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06098508 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0609850A mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0609850C mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609850E mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06098510 rts ; mov.l @r15+,r8
}

void f_0609852C(SH2Context& c) {
    ran[2333] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609852C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609852E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06098530 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06098532 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06098534 mov r15,r14
    c.r[8] = c.r[4];  // 06098536 mov r4,r8
    c.r[9] = c.r[5];  // 06098538 mov r5,r9
    c.r[1] = c.r[8];  // 0609853A mov r8,r1
    c.r[1] += 84;  // 0609853C add #84,r1
    st32(c.r[1], c.r[9]);  // 0609853E mov.l r9,@r1
    c.r[5] = ld32(0x06098568u);  // 06098540 mov.l 0x06098568,r5
    c.r[0] = ld32(0x0609856Cu);  // 06098542 mov.l 0x0609856C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06098548u; c.r[6] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06098548u) return; }  // 06098544 jsr @r0 ; mov #0,r6
    c.t = (int32_t)c.r[0] >= 0;  // 06098548 cmp/pz r0
    if (c.t) { goto L_0609854E; }  // 0609854A bt 0x0609854E
    c.r[0] = 0x0u;  // 0609854C mov #0,r0
L_0609854E:
    c.r[1] = c.r[8];  // 0609854E mov r8,r1
    c.t = (int32_t)c.r[0] > (int32_t)c.r[9];  // 06098550 cmp/gt r9,r0
    { const bool k = !c.t; c.r[1] += 88; if (k) { goto L_06098558; } }  // 06098552 bf/s 0x06098558 ; add #88,r1
    c.r[0] = c.r[9];  // 06098556 mov r9,r0
L_06098558:
    st32(c.r[1], c.r[0]);  // 06098558 mov.l r0,@r1
    c.r[15] = c.r[14];  // 0609855A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609855C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609855E mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06098560 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06098562 rts ; mov.l @r15+,r8
}

void f_06098570(SH2Context& c) {
    ran[2334] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06098570 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06098572 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06098574 mov r15,r14
    c.r[0] = ld32(c.r[14] + 8);  // 06098576 mov.l @(8,r14),r0
    c.r[3] = ld32(c.r[14] + 12);  // 06098578 mov.l @(12,r14),r3
    c.r[2] = ld32(c.r[14] + 16);  // 0609857A mov.l @(16,r14),r2
    c.t = (c.r[5] & c.r[5]) == 0;  // 0609857C tst r5,r5
    { const bool k = c.t; c.r[8] = ld32(c.r[14] + 20); if (k) { goto L_06098586; } }  // 0609857E bt/s 0x06098586 ; mov.l @(20,r14),r8
    c.r[1] = ld32(c.r[4]);  // 06098582 mov.l @r4,r1
    st32(c.r[5], c.r[1]);  // 06098584 mov.l r1,@r5
L_06098586:
    c.t = (c.r[6] & c.r[6]) == 0;  // 06098586 tst r6,r6
    { const bool k = c.t; c.t = (c.r[2] & c.r[2]) == 0; if (k) { goto L_06098590; } }  // 06098588 bt/s 0x06098590 ; tst r2,r2
    c.r[1] = ld32(c.r[4] + 4);  // 0609858C mov.l @(4,r4),r1
    st32(c.r[6], c.r[1]);  // 0609858E mov.l r1,@r6
L_06098590:
    { const bool k = c.t; c.t = (c.r[7] & c.r[7]) == 0; if (k) { goto L_0609859E; } }  // 06098590 bt/s 0x0609859E ; tst r7,r7
    c.r[1] = c.r[4];  // 06098594 mov r4,r1
    c.r[1] += 14;  // 06098596 add #14,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06098598 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0609859A extu.b r1,r1
    st32(c.r[2], c.r[1]);  // 0609859C mov.l r1,@r2
L_0609859E:
    { const bool k = c.t; c.t = (c.r[0] & c.r[0]) == 0; if (k) { goto L_060985A6; } }  // 0609859E bt/s 0x060985A6 ; tst r0,r0
    c.r[1] = ld32(c.r[4] + 16);  // 060985A2 mov.l @(16,r4),r1
    st32(c.r[7], c.r[1]);  // 060985A4 mov.l r1,@r7
L_060985A6:
    { const bool k = c.t; c.t = (c.r[8] & c.r[8]) == 0; if (k) { goto L_060985AE; } }  // 060985A6 bt/s 0x060985AE ; tst r8,r8
    c.r[1] = ld32(c.r[4] + 20);  // 060985AA mov.l @(20,r4),r1
    st32(c.r[0], c.r[1]);  // 060985AC mov.l r1,@r0
L_060985AE:
    { const bool k = c.t; c.t = (c.r[3] & c.r[3]) == 0; if (k) { goto L_060985BC; } }  // 060985AE bt/s 0x060985BC ; tst r3,r3
    c.r[1] = c.r[4];  // 060985B2 mov r4,r1
    c.r[1] += 15;  // 060985B4 add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060985B6 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060985B8 extu.b r1,r1
    st32(c.r[8], c.r[1]);  // 060985BA mov.l r1,@r8
L_060985BC:
    { const bool k = c.t; c.r[15] = c.r[14]; if (k) { goto L_060985DC; } }  // 060985BC bt/s 0x060985DC ; mov r14,r15
    c.r[1] = c.r[4];  // 060985C0 mov r4,r1
    c.r[1] += 15;  // 060985C2 add #15,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060985C4 mov.b @r1,r0
    c.r[0] &= 0x18u;  // 060985C6 and #24,r0
    c.t = c.r[0] == 0x18u;  // 060985C8 cmp/eq #24,r0
    { const bool k = !c.t; c.r[1] = 0x0u; if (k) { goto L_060985D2; } }  // 060985CA bf/s 0x060985D2 ; mov #0,r1
    st32(c.r[3], c.r[1]); goto L_060985DC;  // 060985CE bra 0x060985DC ; mov.l r1,@r3
L_060985D2:
    c.r[2] = ld32(c.r[4] + 16);  // 060985D2 mov.l @(16,r4),r2
    c.r[1] = ld32(c.r[4] + 24);  // 060985D4 mov.l @(24,r4),r1
    c.r[2] -= c.r[1];  // 060985D6 sub r1,r2
    st32(c.r[3], c.r[2]);  // 060985D8 mov.l r2,@r3
    c.r[15] = c.r[14];  // 060985DA mov r14,r15
L_060985DC:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060985DC mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060985DE rts ; mov.l @r15+,r8
}

void f_060985E4(SH2Context& c) {
    ran[2335] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060985E4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060985E6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060985E8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060985EA mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060985EC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060985EE sts.l pr,@-r15
    c.r[15] -= 36;  // 060985F0 add #-36,r15
    c.r[14] = c.r[15];  // 060985F2 mov r15,r14
    c.r[11] = c.r[4];  // 060985F4 mov r4,r11
    c.r[8] = c.r[11];  // 060985F6 mov r11,r8
    c.r[8] += 28;  // 060985F8 add #28,r8
    c.r[5] = c.r[14];  // 060985FA mov r14,r5
    c.r[5] += 24;  // 060985FC add #24,r5
    c.r[4] = c.r[14];  // 060985FE mov r14,r4
    c.r[0] = ld32(0x06098708u);  // 06098600 mov.l 0x06098708,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06098606u; c.r[4] += 20; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06098606u) return; }  // 06098602 jsr @r0 ; add #20,r4
    c.r[9] = c.r[0];  // 06098606 mov r0,r9
    c.r[1] = ld32(0x0609870Cu);  // 06098608 mov.l 0x0609870C,r1
    st32(c.r[1], c.r[9]);  // 0609860A mov.l r9,@r1
    c.r[2] = ld32(0x06098710u);  // 0609860C mov.l 0x06098710,r2
    c.r[1] = ld32(c.r[14] + 20);  // 0609860E mov.l @(20,r14),r1
    c.r[10] = c.r[14];  // 06098610 mov r14,r10
    c.r[10] += 28;  // 06098612 add #28,r10
    c.r[0] = ld32(0x06098714u);  // 06098614 mov.l 0x06098714,r0
    c.r[6] = c.r[10];  // 06098616 mov r10,r6
    c.r[5] = c.r[9];  // 06098618 mov r9,r5
    c.r[4] = c.r[11];  // 0609861A mov r11,r4
    { const uint32_t x = c.r[0]; c.pr = 0x06098620u; st32(c.r[2], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06098620u) return; }  // 0609861C jsr @r0 ; mov.l r1,@r2
    c.t = (c.r[0] & c.r[0]) == 0;  // 06098620 tst r0,r0
    { const bool k = c.t; c.r[0] = ld32(c.r[14] + 28); if (k) { goto L_060986F0; } }  // 06098622 bt/s 0x060986F0 ; mov.l @(28,r14),r0
    c.r[0] = ld32(0x06098718u);  // 06098626 mov.l 0x06098718,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609862Cu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609862Cu) return; }  // 06098628 jsr @r0 ; mov r8,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609862C tst r0,r0
    { const bool k = !c.t; c.r[5] = c.r[14]; if (k) { goto L_060986A4; } }  // 0609862E bf/s 0x060986A4 ; mov r14,r5
    c.r[5] += 32;  // 06098632 add #32,r5
    c.r[0] = ld32(0x0609871Cu);  // 06098634 mov.l 0x0609871C,r0
    c.r[6] = c.r[10];  // 06098636 mov r10,r6
    { const uint32_t x = c.r[0]; c.pr = 0x0609863Cu; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609863Cu) return; }  // 06098638 jsr @r0 ; mov r11,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609863C tst r0,r0
    { const bool k = c.t; c.r[0] = ld32(c.r[14] + 28); if (k) { goto L_060986F0; } }  // 0609863E bt/s 0x060986F0 ; mov.l @(28,r14),r0
    c.r[0] = ld32(0x06098720u);  // 06098642 mov.l 0x06098720,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06098648u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06098648u) return; }  // 06098644 jsr @r0 ; mov r8,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 06098648 tst r0,r0
    { const bool k = c.t; c.r[0] = 0x8u; if (k) { goto L_060986F0; } }  // 0609864A bt/s 0x060986F0 ; mov #8,r0
    c.r[0] = ld32(0x06098724u);  // 0609864E mov.l 0x06098724,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06098654u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06098654u) return; }  // 06098650 jsr @r0 ; mov r8,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 06098654 tst r0,r0
    { const bool k = c.t; c.r[0] = 0x8u; if (k) { goto L_060986F0; } }  // 06098656 bt/s 0x060986F0 ; mov #8,r0
    c.r[9] = 0x1u;  // 0609865A mov #1,r9
    st32(c.r[14], c.r[9]);  // 0609865C mov.l r9,@r14
    c.r[2] = ld32(c.r[8] + 40);  // 0609865E mov.l @(40,r8),r2
    st32(c.r[14] + 4, c.r[2]);  // 06098660 mov.l r2,@(4,r14)
    st32(c.r[14] + 8, c.r[9]);  // 06098662 mov.l r9,@(8,r14)
    c.r[1] = ld32(c.r[8] + 44);  // 06098664 mov.l @(44,r8),r1
    c.r[0] = ld32(0x06098728u);  // 06098666 mov.l 0x06098728,r0
    c.r[1] -= c.r[2];  // 06098668 sub r2,r1
    st32(c.r[14] + 12, c.r[1]);  // 0609866A mov.l r1,@(12,r14)
    c.r[2] = c.r[14];  // 0609866C mov r14,r2
    c.r[2] += 16;  // 0609866E add #16,r2
    c.r[1] = 0x0u;  // 06098670 mov #0,r1
    st8(c.r[2], c.r[1]);  // 06098672 mov.b r1,@r2
    c.r[5] = ld32(c.r[8] + 28);  // 06098674 mov.l @(28,r8),r5
    { const uint32_t x = c.r[0]; c.pr = 0x0609867Au; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609867Au) return; }  // 06098676 jsr @r0 ; mov r14,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609867A tst r0,r0
    { const bool k = c.t; st32(c.r[14] + 28, c.r[0]); if (k) { goto L_06098684; } }  // 0609867C bt/s 0x06098684 ; mov.l r0,@(28,r14)
    c.r[0] = 0x8u; goto L_060986F0;  // 06098680 bra 0x060986F0 ; mov #8,r0
L_06098684:
    c.r[2] = c.r[11];  // 06098684 mov r11,r2
    c.r[2] += 88;  // 06098686 add #88,r2
    c.r[3] = ld32(c.r[2]);  // 06098688 mov.l @r2,r3
    c.r[1] = ld32(c.r[14] + 32);  // 0609868A mov.l @(32,r14),r1
    c.r[3] += c.r[1];  // 0609868C add r1,r3
    st32(c.r[2], c.r[3]);  // 0609868E mov.l r3,@r2
    c.r[1] = ld32(0x0609872Cu);  // 06098690 mov.l 0x0609872C,r1
    c.r[2] = ld32(c.r[1]);  // 06098692 mov.l @r1,r2
    c.r[1] = ld32(c.r[14] + 4);  // 06098694 mov.l @(4,r14),r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06098702u);  // 06098696 mov.w 0x06098702,r0
    st32(c.r[0] + c.r[2], c.r[1]);  // 06098698 mov.l r1,@(r0,r2)
    c.r[1] = ld32(c.r[8] + 44);  // 0609869A mov.l @(44,r8),r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06098704u);  // 0609869C mov.w 0x06098704,r0
    st32(c.r[0] + c.r[2], c.r[1]);  // 0609869E mov.l r1,@(r0,r2)
    c.r[0] = c.r[9]; goto L_060986F0;  // 060986A0 bra 0x060986F0 ; mov r9,r0
L_060986A4:
    c.r[2] = ld32(c.r[14] + 20);  // 060986A4 mov.l @(20,r14),r2
    c.r[1] = ld32(c.r[8] + 44);  // 060986A6 mov.l @(44,r8),r1
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[1];  // 060986A8 cmp/ge r1,r2
    { const bool k = !c.t; c.r[0] = ld32(c.r[14] + 24); if (k) { goto L_060986EE; } }  // 060986AA bf/s 0x060986EE ; mov.l @(24,r14),r0
    c.r[0] &= 0x4u;  // 060986AE and #4,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060986B0 tst r0,r0
    { const bool k = !c.t; c.t = (c.r[9] & c.r[9]) == 0; if (k) { goto L_060986BA; } }  // 060986B2 bf/s 0x060986BA ; tst r9,r9
    { const bool k = !c.t; c.r[0] = 0x2u; if (k) { goto L_060986F0; } }  // 060986B6 bf/s 0x060986F0 ; mov #2,r0
L_060986BA:
    c.r[1] = ld32(0x06098730u);  // 060986BA mov.l 0x06098730,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060986C0u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060986C0u) return; }  // 060986BC jsr @r1 ; mov r8,r4
    c.r[1] = c.r[11];  // 060986C0 mov r11,r1
    c.r[1] += 84;  // 060986C2 add #84,r1
    c.r[2] = ld32(c.r[1]);  // 060986C4 mov.l @r1,r2
    c.r[11] += 88;  // 060986C6 add #88,r11
    c.r[1] = ld32(c.r[11]);  // 060986C8 mov.l @r11,r1
    c.t = c.r[2] == c.r[1];  // 060986CA cmp/eq r1,r2
    { const bool k = !c.t; c.r[0] = 0x2u; if (k) { goto L_060986F0; } }  // 060986CC bf/s 0x060986F0 ; mov #2,r0
    c.r[1] = ld32(0x0609872Cu);  // 060986D0 mov.l 0x0609872C,r1
    c.r[3] = ld32(c.r[1]);  // 060986D2 mov.l @r1,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x06098704u);  // 060986D4 mov.w 0x06098704,r0
    c.r[2] = ld32(c.r[0] + c.r[3]);  // 060986D6 mov.l @(r0,r3),r2
    c.r[1] = ld32(c.r[14] + 20);  // 060986D8 mov.l @(20,r14),r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 060986DA cmp/gt r1,r2
    { const bool k = c.t; c.r[0] = 0x2u; if (k) { goto L_060986F0; } }  // 060986DC bt/s 0x060986F0 ; mov #2,r0
    c.r[0] = c.r[9];  // 060986E0 mov r9,r0
    c.t = c.r[0] == 0x2u;  // 060986E2 cmp/eq #2,r0
    if (c.t) { goto L_060986EE; }  // 060986E4 bt 0x060986EE
    c.r[0] = (uint32_t)(int16_t)ld16(0x06098702u);  // 060986E6 mov.w 0x06098702,r0
    st32(c.r[0] + c.r[3], c.r[2]);  // 060986E8 mov.l r2,@(r0,r3)
    c.r[0] = 0x4u; goto L_060986F0;  // 060986EA bra 0x060986F0 ; mov #4,r0
L_060986EE:
    c.r[0] = 0x2u;  // 060986EE mov #2,r0
L_060986F0:
    c.r[14] += 36;  // 060986F0 add #36,r14
    c.r[15] = c.r[14];  // 060986F2 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060986F4 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060986F6 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060986F8 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060986FA mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060986FC mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060986FE rts ; mov.l @r15+,r8
}

void f_06098734(SH2Context& c) {
    ran[2336] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06098734 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06098736 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06098738 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0609873A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0609873C mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609873E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06098740 sts.l pr,@-r15
    c.r[15] -= 12;  // 06098742 add #-12,r15
    c.r[14] = c.r[15];  // 06098744 mov r15,r14
    c.r[9] = c.r[4];  // 06098746 mov r4,r9
    c.r[8] = c.r[5];  // 06098748 mov r5,r8
    c.r[9] += 28;  // 0609874A add #28,r9
    c.r[12] = ld32(0x060987B8u);  // 0609874C mov.l 0x060987B8,r12
    c.r[2] = ld32(c.r[12]);  // 0609874E mov.l @r12,r2
    c.r[11] = (uint32_t)(int16_t)ld16(0x060987B4u);  // 06098750 mov.w 0x060987B4,r11
    c.r[10] = (uint32_t)(int16_t)ld16(0x060987B6u);  // 06098752 mov.w 0x060987B6,r10
    c.r[1] = 0x0u;  // 06098754 mov #0,r1
    c.r[5] = c.r[14];  // 06098756 mov r14,r5
    c.r[4] = c.r[9];  // 06098758 mov r9,r4
    c.r[0] = c.r[2];  // 0609875A mov r2,r0
    st32(c.r[0] + c.r[10], c.r[1]);  // 0609875C mov.l r1,@(r0,r10)
    st32(c.r[0] + c.r[11], c.r[1]);  // 0609875E mov.l r1,@(r0,r11)
    c.r[1] = 0x3u;  // 06098760 mov #3,r1
    c.r[0] = ld32(0x060987BCu);  // 06098762 mov.l 0x060987BC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06098768u; st32(c.r[14], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06098768u) return; }  // 06098764 jsr @r0 ; mov.l r1,@r14
    c.t = (c.r[8] & c.r[8]) == 0;  // 06098768 tst r8,r8
    if (c.t) { goto L_06098772; }  // 0609876A bt 0x06098772
    c.r[1] = ld32(0x060987C0u);  // 0609876C mov.l 0x060987C0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06098772u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06098772u) return; }  // 0609876E jsr @r1 ; nop
L_06098772:
    c.r[0] = ld32(0x060987C4u);  // 06098772 mov.l 0x060987C4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06098778u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06098778u) return; }  // 06098774 jsr @r0 ; mov r9,r4
    c.r[0] = ld32(0x060987C8u);  // 06098778 mov.l 0x060987C8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609877Eu; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609877Eu) return; }  // 0609877A jsr @r0 ; mov r9,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609877E tst r0,r0
    if (c.t) { goto L_060987A0; }  // 06098780 bt 0x060987A0
    c.r[1] = ld32(0x060987CCu);  // 06098782 mov.l 0x060987CC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06098788u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06098788u) return; }  // 06098784 jsr @r1 ; mov r9,r4
    c.r[4] = c.r[14];  // 06098788 mov r14,r4
    c.r[4] += 8;  // 0609878A add #8,r4
    c.r[0] = ld32(0x060987D0u);  // 0609878C mov.l 0x060987D0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06098792u; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06098792u) return; }  // 0609878E jsr @r0 ; mov #0,r5
    c.r[2] = ld32(c.r[12]);  // 06098792 mov.l @r12,r2
    c.r[1] = ld32(c.r[14] + 8);  // 06098794 mov.l @(8,r14),r1
    c.r[0] = c.r[2];  // 06098796 mov r2,r0
    c.r[3] = ld32(c.r[0] + c.r[10]);  // 06098798 mov.l @(r0,r10),r3
    c.t = (int32_t)c.r[3] > (int32_t)c.r[1];  // 0609879A cmp/gt r1,r3
    if (c.t) { goto L_060987A0; }  // 0609879C bt 0x060987A0
    st32(c.r[0] + c.r[11], c.r[3]);  // 0609879E mov.l r3,@(r0,r11)
L_060987A0:
    c.r[14] += 12;  // 060987A0 add #12,r14
    c.r[15] = c.r[14];  // 060987A2 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060987A4 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060987A6 mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060987A8 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060987AA mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060987AC mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060987AE mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060987B0 rts ; mov.l @r15+,r8
}

void f_060987D4(SH2Context& c) {
    ran[2337] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060987D4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060987D6 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060987D8 sts.l pr,@-r15
    c.r[15] -= 20;  // 060987DA add #-20,r15
    c.r[14] = c.r[15];  // 060987DC mov r15,r14
    c.r[8] = c.r[4];  // 060987DE mov r4,r8
    c.r[8] += 28;  // 060987E0 add #28,r8
    c.r[0] = ld32(0x06098818u);  // 060987E2 mov.l 0x06098818,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060987E8u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060987E8u) return; }  // 060987E4 jsr @r0 ; mov r8,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 060987E8 tst r0,r0
    { const bool k = c.t; c.r[0] = 0x8u; if (k) { goto L_0609880C; } }  // 060987EA bt/s 0x0609880C ; mov #8,r0
    c.r[1] = 0x3u;  // 060987EE mov #3,r1
    st32(c.r[14], c.r[1]);  // 060987F0 mov.l r1,@r14
    st32(c.r[14] + 8, c.r[1]);  // 060987F2 mov.l r1,@(8,r14)
    c.r[2] = c.r[14];  // 060987F4 mov r14,r2
    c.r[2] += 16;  // 060987F6 add #16,r2
    c.r[1] = 0xFFFFFFFFu;  // 060987F8 mov #-1,r1
    st8(c.r[2], c.r[1]);  // 060987FA mov.b r1,@r2
    c.r[5] = ld32(c.r[8] + 28);  // 060987FC mov.l @(28,r8),r5
    c.r[0] = ld32(0x0609881Cu);  // 060987FE mov.l 0x0609881C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06098804u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06098804u) return; }  // 06098800 jsr @r0 ; mov r14,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 06098804 tst r0,r0
    { const bool k = c.t; c.r[0] = 0x2u; if (k) { goto L_0609880C; } }  // 06098806 bt/s 0x0609880C ; mov #2,r0
    c.r[0] = 0x8u;  // 0609880A mov #8,r0
L_0609880C:
    c.r[14] += 20;  // 0609880C add #20,r14
    c.r[15] = c.r[14];  // 0609880E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06098810 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06098812 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06098814 rts ; mov.l @r15+,r8
}

void f_06098820(SH2Context& c) {
    ran[2338] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06098820 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06098822 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06098824 mov r15,r14
    c.r[0] = ld32(0x06098834u);  // 06098826 mov.l 0x06098834,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609882Cu; c.r[4] += 28; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609882Cu) return; }  // 06098828 jsr @r0 ; add #28,r4
    c.r[15] = c.r[14];  // 0609882C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609882E lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06098830 rts ; mov.l @r15+,r14
}

void f_06098838(SH2Context& c) {
    ran[2339] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06098838 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609883A sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0609883C mov r15,r14
    c.r[0] = ld32(0x0609884Cu);  // 0609883E mov.l 0x0609884C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06098844u; c.r[6] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06098844u) return; }  // 06098840 jsr @r0 ; mov #0,r6
    c.r[15] = c.r[14];  // 06098844 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06098846 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06098848 rts ; mov.l @r15+,r14
}

void f_06098850(SH2Context& c) {
    ran[2340] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06098850 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06098852 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06098854 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06098856 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06098858 sts.l pr,@-r15
    c.r[15] -= 8;  // 0609885A add #-8,r15
    c.r[14] = c.r[15];  // 0609885C mov r15,r14
    c.r[9] = c.r[4];  // 0609885E mov r4,r9
    c.r[10] = c.r[5];  // 06098860 mov r5,r10
    c.r[0] = ld32(0x060988DCu);  // 06098862 mov.l 0x060988DC,r0
    c.r[5] = 0x0u;  // 06098864 mov #0,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0609886Au; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609886Au) return; }  // 06098866 jsr @r0 ; mov #0,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609886A tst r0,r0
    { const bool k = !c.t; c.r[8] = c.r[9]; if (k) { goto L_0609887E; } }  // 0609886C bf/s 0x0609887E ; mov r9,r8
    c.r[8] += 28;  // 06098870 add #28,r8
    c.r[0] = ld32(0x060988E0u);  // 06098872 mov.l 0x060988E0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06098878u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06098878u) return; }  // 06098874 jsr @r0 ; mov r8,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 06098878 tst r0,r0
    { const bool k = !c.t; c.r[1] = 0x1u; if (k) { goto L_06098882; } }  // 0609887A bf/s 0x06098882 ; mov #1,r1
L_0609887E:
    c.r[0] = 0xFFFFFFECu; goto L_060988CC;  // 0609887E bra 0x060988CC ; mov #-20,r0
L_06098882:
    st32(c.r[14], c.r[1]);  // 06098882 mov.l r1,@r14
    c.r[0] = ld32(0x060988E4u);  // 06098884 mov.l 0x060988E4,r0
    c.r[5] = c.r[10];  // 06098886 mov r10,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0609888Cu; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609888Cu) return; }  // 06098888 jsr @r0 ; mov r9,r4
    c.r[1] = ld32(c.r[9] + 4);  // 0609888C mov.l @(4,r9),r1
    c.r[5] = c.r[14];  // 0609888E mov r14,r5
    c.r[0] += c.r[1];  // 06098890 add r1,r0
    st32(c.r[14] + 4, c.r[0]);  // 06098892 mov.l r0,@(4,r14)
    c.r[0] = ld32(0x060988E8u);  // 06098894 mov.l 0x060988E8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609889Au; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609889Au) return; }  // 06098896 jsr @r0 ; mov r8,r4
    c.t = c.r[0] == 0xFFFFFFF7u;  // 0609889A cmp/eq #-9,r0
    { const bool k = c.t; c.r[1] = 0xFFFFFFF7u; if (k) { goto L_060988B8; } }  // 0609889C bt/s 0x060988B8 ; mov #-9,r1
    c.t = (int32_t)c.r[0] > (int32_t)c.r[1];  // 060988A0 cmp/gt r1,r0
    { const bool k = c.t; c.t = (c.r[0] & c.r[0]) == 0; if (k) { goto L_060988B0; } }  // 060988A2 bt/s 0x060988B0 ; tst r0,r0
    c.t = c.r[0] == 0xFFFFFFF3u;  // 060988A6 cmp/eq #-13,r0
    if (c.t) { goto L_060988BC; }  // 060988A8 bt 0x060988BC
    c.r[8] = 0xFFFFFFFFu;  // 060988AA mov #-1,r8
    c.r[9] += 28; goto L_060988C4;  // 060988AC bra 0x060988C4 ; add #28,r9
L_060988B0:
    if (!c.t) { goto L_060988C0; }  // 060988B0 bf 0x060988C0
    c.r[8] = 0x0u;  // 060988B2 mov #0,r8
    c.r[9] += 28; goto L_060988C4;  // 060988B4 bra 0x060988C4 ; add #28,r9
L_060988B8:
    c.r[8] = 0xFFFFFFECu; goto L_060988C2;  // 060988B8 bra 0x060988C2 ; mov #-20,r8
L_060988BC:
    c.r[8] = 0xFFFFFFE9u; goto L_060988C2;  // 060988BC bra 0x060988C2 ; mov #-23,r8
L_060988C0:
    c.r[8] = 0xFFFFFFFFu;  // 060988C0 mov #-1,r8
L_060988C2:
    c.r[9] += 28;  // 060988C2 add #28,r9
L_060988C4:
    c.r[1] = ld32(0x060988ECu);  // 060988C4 mov.l 0x060988EC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060988CAu; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060988CAu) return; }  // 060988C6 jsr @r1 ; mov r9,r4
    c.r[0] = c.r[8];  // 060988CA mov r8,r0
L_060988CC:
    c.r[14] += 8;  // 060988CC add #8,r14
    c.r[15] = c.r[14];  // 060988CE mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060988D0 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060988D2 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060988D4 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060988D6 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060988D8 rts ; mov.l @r15+,r8
}

void f_060988F0(SH2Context& c) {
    ran[2341] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060988F0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060988F2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060988F4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060988F6 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060988F8 mov r15,r14
    c.r[8] = c.r[4];  // 060988FA mov r4,r8
    c.r[1] = c.r[8];  // 060988FC mov r8,r1
    c.r[1] += 12;  // 060988FE add #12,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06098900 mov.b @r1,r1
    c.r[6] = c.r[1] & 0xFFu;  // 06098902 extu.b r1,r6
    c.t = (c.r[6] & c.r[6]) == 0;  // 06098904 tst r6,r6
    { const bool k = c.t; c.r[9] = c.r[5]; if (k) { goto L_0609892C; } }  // 06098906 bt/s 0x0609892C ; mov r5,r9
    c.r[4] = c.r[9];  // 0609890A mov r9,r4
    c.r[7] = ld32(0x0609893Cu);  // 0609890C mov.l 0x0609893C,r7
    { const uint32_t x = c.r[7]; c.pr = 0x06098912u; c.r[5] = c.r[6]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06098912u) return; }  // 0609890E jsr @r7 ; mov r6,r5
    c.r[8] += 13;  // 06098912 add #13,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06098914 mov.b @r8,r1
    c.r[7] = c.r[0];  // 06098916 mov r0,r7
    c.r[1] = c.r[1] & 0xFFu;  // 06098918 extu.b r1,r1
    c.r[1] += c.r[6];  // 0609891A add r6,r1
    c.macl = c.r[7] * c.r[1];  // 0609891C mul.l r1,r7
    c.r[2] = c.macl;  // 0609891E sts macl,r2
    c.macl = c.r[7] * c.r[6];  // 06098920 mul.l r6,r7
    c.r[1] = c.macl;  // 06098922 sts macl,r1
    c.r[9] -= c.r[1];  // 06098924 sub r1,r9
    c.r[2] += c.r[9];  // 06098926 add r9,r2
    c.r[0] = c.r[2]; goto L_0609892E;  // 06098928 bra 0x0609892E ; mov r2,r0
L_0609892C:
    c.r[0] = c.r[9];  // 0609892C mov r9,r0
L_0609892E:
    c.r[15] = c.r[14];  // 0609892E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06098930 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06098932 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06098934 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06098936 rts ; mov.l @r15+,r8
}

void f_06098940(SH2Context& c) {
    ran[2342] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06098940 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06098942 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06098944 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06098946 sts.l pr,@-r15
    c.r[15] -= 12;  // 06098948 add #-12,r15
    c.r[14] = c.r[15];  // 0609894A mov r15,r14
    c.r[9] = c.r[4];  // 0609894C mov r4,r9
    c.r[8] = c.r[5];  // 0609894E mov r5,r8
    c.r[0] = ld32(0x060989D0u);  // 06098950 mov.l 0x060989D0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06098956u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06098956u) return; }  // 06098952 jsr @r0 ; mov r14,r4
    c.t = (c.r[8] & c.r[8]) == 0;  // 06098956 tst r8,r8
    if (c.t) { goto L_0609895C; }  // 06098958 bt 0x0609895C
    st32(c.r[8], c.r[0]);  // 0609895A mov.l r0,@r8
L_0609895C:
    c.t = (c.r[9] & c.r[9]) == 0;  // 0609895C tst r9,r9
    { const bool k = c.t; c.r[1] = ld32(c.r[14] + 8); if (k) { goto L_06098964; } }  // 0609895E bt/s 0x06098964 ; mov.l @(8,r14),r1
    st32(c.r[9], c.r[1]);  // 06098962 mov.l r1,@r9
L_06098964:
    c.r[1] = ld32(0x060989D4u);  // 06098964 mov.l 0x060989D4,r1
    c.r[0] = ld32(c.r[1]);  // 06098966 mov.l @r1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06098968 tst r0,r0
    if (!c.t) { goto L_060989A4; }  // 0609896A bf 0x060989A4
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[14]);  // 0609896C mov.b @r14,r0
    c.r[1] = 0x9u;  // 0609896E mov #9,r1
    c.r[0] &= 0xFu;  // 06098970 and #15,r0
    c.t = c.r[0] > c.r[1];  // 06098972 cmp/hi r1,r0
    { const bool k = c.t; c.r[1] = c.r[0]; if (k) { goto L_060989BE; } }  // 06098974 bt/s 0x060989BE ; mov r0,r1
    c.r[1] += c.r[1];  // 06098978 add r1,r1
    c.r[0] = 0x06098984u;  // 0609897A mova 0x06098984,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0609897C mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 0609897E add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x0609899Cu: goto L_0609899C; case 0x06098998u: goto L_06098998; case 0x060989A0u: goto L_060989A0; case 0x060989BEu: goto L_060989BE; default: sh2_call(c, x); return; } }  // 06098980 jmp @r0 ; nop
L_06098998:
    c.r[0] = 0x0u; goto L_060989C0;  // 06098998 bra 0x060989C0 ; mov #0,r0
L_0609899C:
    c.r[0] = 0x2u; goto L_060989C0;  // 0609899C bra 0x060989C0 ; mov #2,r0
L_060989A0:
    c.r[0] = 0x1u; goto L_060989C0;  // 060989A0 bra 0x060989C0 ; mov #1,r0
L_060989A4:
    c.t = c.r[0] == 0xFFFFFFF3u;  // 060989A4 cmp/eq #-13,r0
    if (!c.t) { goto L_060989AE; }  // 060989A6 bf 0x060989AE
    c.r[0] = 0x3u;  // 060989A8 mov #3,r0
    c.r[14] += 12; goto L_060989C2;  // 060989AA bra 0x060989C2 ; add #12,r14
L_060989AE:
    c.t = c.r[0] == 0xFFFFFFF2u;  // 060989AE cmp/eq #-14,r0
    if (!c.t) { goto L_060989B8; }  // 060989B0 bf 0x060989B8
    c.r[0] = 0x4u;  // 060989B2 mov #4,r0
    c.r[14] += 12; goto L_060989C2;  // 060989B4 bra 0x060989C2 ; add #12,r14
L_060989B8:
    c.t = c.r[0] == 0xFFFFFFF0u;  // 060989B8 cmp/eq #-16,r0
    { const bool k = c.t; c.r[0] = 0x6u; if (k) { goto L_060989C0; } }  // 060989BA bt/s 0x060989C0 ; mov #6,r0
L_060989BE:
    c.r[0] = 0x5u;  // 060989BE mov #5,r0
L_060989C0:
    c.r[14] += 12;  // 060989C0 add #12,r14
L_060989C2:
    c.r[15] = c.r[14];  // 060989C2 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060989C4 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060989C6 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060989C8 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060989CA rts ; mov.l @r15+,r8
}

void f_060989D8(SH2Context& c) {
    ran[2343] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060989D8 mov.l r14,@-r15
    c.r[0] = c.r[4];  // 060989DA mov r4,r0
    c.r[1] = 0x40u;  // 060989DC mov #64,r1
    c.r[1] &= c.r[0];  // 060989DE and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060989E0 tst r1,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_060989EC; } }  // 060989E2 bt/s 0x060989EC ; mov r15,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x06098A0Au);  // 060989E6 mov.w 0x06098A0A,r0
    c.r[15] = c.r[14]; goto L_06098A06;  // 060989E8 bra 0x06098A06 ; mov r14,r15
L_060989EC:
    c.r[1] = 0x10u;  // 060989EC mov #16,r1
    c.r[1] &= c.r[0];  // 060989EE and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060989F0 tst r1,r1
    { const bool k = c.t; c.r[0] &= 0x8u; if (k) { goto L_06098A02; } }  // 060989F2 bt/s 0x06098A02 ; and #8,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060989F6 tst r0,r0
    c.r[0] = (uint32_t)(int16_t)ld16(0x06098A0Cu);  // 060989F8 mov.w 0x06098A0C,r0
    if (c.t) { goto L_06098A04; }  // 060989FA bt 0x06098A04
    c.r[0] = 0x0u;  // 060989FC mov #0,r0
    c.r[15] = c.r[14]; goto L_06098A06;  // 060989FE bra 0x06098A06 ; mov r14,r15
L_06098A02:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06098A0Eu);  // 06098A02 mov.w 0x06098A0E,r0
L_06098A04:
    c.r[15] = c.r[14];  // 06098A04 mov r14,r15
L_06098A06:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06098A06 rts ; mov.l @r15+,r14
}

void f_06098A10(SH2Context& c) {
    ran[2344] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06098A10 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06098A12 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06098A14 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06098A16 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06098A18 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06098A1A sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06098A1C mov r15,r14
    c.r[10] = c.r[4];  // 06098A1E mov r4,r10
    c.r[9] = c.r[6];  // 06098A20 mov r6,r9
    c.r[11] = c.r[10];  // 06098A22 mov r10,r11
    c.r[1] = 0x6u;  // 06098A24 mov #6,r1
    c.t = c.r[5] > c.r[1];  // 06098A26 cmp/hi r1,r5
    { const bool k = c.t; c.r[11] += 28; if (k) { goto L_06098A70; } }  // 06098A28 bt/s 0x06098A70 ; add #28,r11
    c.r[1] = c.r[5];  // 06098A2C mov r5,r1
    c.r[1] += c.r[1];  // 06098A2E add r1,r1
    c.r[0] = 0x06098A3Cu;  // 06098A30 mova 0x06098A3C,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06098A32 mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 06098A34 add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x06098A54u: goto L_06098A54; case 0x06098A78u: goto L_06098A78; case 0x06098A4Au: goto L_06098A4A; case 0x06098A64u: goto L_06098A64; case 0x06098A68u: goto L_06098A68; case 0x06098A70u: goto L_06098A70; case 0x06098A6Cu: goto L_06098A6C; default: sh2_call(c, x); return; } }  // 06098A36 jmp @r0 ; nop
L_06098A4A:
    c.r[10] += 80;  // 06098A4A add #80,r10
    c.r[1] = ld32(c.r[10]);  // 06098A4C mov.l @r10,r1
    c.r[0] = 0x0u;  // 06098A4E mov #0,r0
    st32(c.r[9], c.r[1]); goto L_06098AAA;  // 06098A50 bra 0x06098AAA ; mov.l r1,@r9
L_06098A54:
    c.r[0] = ld32(0x06098AC0u);  // 06098A54 mov.l 0x06098AC0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06098A5Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06098A5Au) return; }  // 06098A56 jsr @r0 ; nop
    c.t = (c.r[0] & c.r[0]) == 0;  // 06098A5A tst r0,r0
    { const bool k = !c.t; c.r[1] = 0x3u; if (k) { goto L_06098A78; } }  // 06098A5C bf/s 0x06098A78 ; mov #3,r1
    st32(c.r[9], c.r[1]); goto L_06098A74;  // 06098A60 bra 0x06098A74 ; mov.l r1,@r9
L_06098A64:
    c.r[1] = 0x5u; goto L_06098A72;  // 06098A64 bra 0x06098A72 ; mov #5,r1
L_06098A68:
    c.r[1] = 0x6u; goto L_06098A72;  // 06098A68 bra 0x06098A72 ; mov #6,r1
L_06098A6C:
    c.r[1] = 0x9u; goto L_06098A72;  // 06098A6C bra 0x06098A72 ; mov #9,r1
L_06098A70:
    c.r[1] = 0x8u;  // 06098A70 mov #8,r1
L_06098A72:
    st32(c.r[9], c.r[1]);  // 06098A72 mov.l r1,@r9
L_06098A74:
    c.r[0] = 0x0u; goto L_06098AAA;  // 06098A74 bra 0x06098AAA ; mov #0,r0
L_06098A78:
    c.r[1] = c.r[10];  // 06098A78 mov r10,r1
    c.r[1] += 76;  // 06098A7A add #76,r1
    c.r[0] = ld32(c.r[1]);  // 06098A7C mov.l @r1,r0
    c.t = c.r[0] == 0x1u;  // 06098A7E cmp/eq #1,r0
    { const bool k = c.t; c.r[0] = 0x1u; if (k) { goto L_06098AA8; } }  // 06098A80 bt/s 0x06098AA8 ; mov #1,r0
    c.r[1] = c.r[10];  // 06098A84 mov r10,r1
    c.r[1] += 80;  // 06098A86 add #80,r1
    c.r[8] = ld32(c.r[1]);  // 06098A88 mov.l @r1,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 06098A8A tst r8,r8
    if (!c.t) { goto L_06098AA8; }  // 06098A8C bf 0x06098AA8
    c.r[0] = ld32(0x06098AC4u);  // 06098A8E mov.l 0x06098AC4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06098A94u; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06098A94u) return; }  // 06098A90 jsr @r0 ; mov r11,r4
    c.r[10] += 88;  // 06098A94 add #88,r10
    st32(c.r[10], c.r[8]);  // 06098A96 mov.l r8,@r10
    c.r[1] = ld32(0x06098AC8u);  // 06098A98 mov.l 0x06098AC8,r1
    c.r[1] = ld32(c.r[1]);  // 06098A9A mov.l @r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06098ABAu);  // 06098A9C mov.w 0x06098ABA,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x06098ABCu);  // 06098A9E mov.w 0x06098ABC,r3
    c.r[0] = c.r[1];  // 06098AA0 mov r1,r0
    st32(c.r[0] + c.r[3], c.r[8]);  // 06098AA2 mov.l r8,@(r0,r3)
    st32(c.r[0] + c.r[2], c.r[8]);  // 06098AA4 mov.l r8,@(r0,r2)
    c.r[0] = 0x1u;  // 06098AA6 mov #1,r0
L_06098AA8:
    st32(c.r[9], c.r[0]);  // 06098AA8 mov.l r0,@r9
L_06098AAA:
    c.r[15] = c.r[14];  // 06098AAA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06098AAC lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06098AAE mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06098AB0 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06098AB2 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06098AB4 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06098AB6 rts ; mov.l @r15+,r8
}

void f_06098ACC(SH2Context& c) {
    ran[2345] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06098ACC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06098ACE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06098AD0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06098AD2 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06098AD4 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06098AD6 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06098AD8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06098ADA sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06098ADC mov r15,r14
    c.r[12] = c.r[4];  // 06098ADE mov r4,r12
    c.r[10] = c.r[5];  // 06098AE0 mov r5,r10
    c.r[13] = c.r[6];  // 06098AE2 mov r6,r13
    c.r[8] = c.r[12];  // 06098AE4 mov r12,r8
    c.r[1] = c.r[8];  // 06098AE6 mov r8,r1
    c.r[1] += 84;  // 06098AE8 add #84,r1
    c.r[2] = c.r[8];  // 06098AEA mov r8,r2
    c.r[3] = ld32(c.r[1]);  // 06098AEC mov.l @r1,r3
    c.r[2] += 88;  // 06098AEE add #88,r2
    c.r[1] = ld32(c.r[2]);  // 06098AF0 mov.l @r2,r1
    c.r[11] = c.r[8];  // 06098AF2 mov r8,r11
    c.r[3] -= c.r[1];  // 06098AF4 sub r1,r3
    st32(c.r[10], c.r[3]);  // 06098AF6 mov.l r3,@r10
    c.r[1] = c.r[8];  // 06098AF8 mov r8,r1
    c.r[1] += 92;  // 06098AFA add #92,r1
    c.r[1] = ld32(c.r[1]);  // 06098AFC mov.l @r1,r1
    c.t = (int32_t)c.r[3] > (int32_t)c.r[1];  // 06098AFE cmp/gt r1,r3
    { const bool k = !c.t; c.r[11] += 28; if (k) { goto L_06098B08; } }  // 06098B00 bf/s 0x06098B08 ; add #28,r11
    c.r[3] = c.r[1];  // 06098B04 mov r1,r3
    st32(c.r[10], c.r[3]);  // 06098B06 mov.l r3,@r10
L_06098B08:
    c.r[0] = ld32(0x06098BF8u);  // 06098B08 mov.l 0x06098BF8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06098B0Eu; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06098B0Eu) return; }  // 06098B0A jsr @r0 ; mov r11,r4
    c.r[1] = c.r[0];  // 06098B0E mov r0,r1
    c.r[0] = ld32(0x06098BFCu);  // 06098B10 mov.l 0x06098BFC,r0
    c.r[5] = c.r[1];  // 06098B12 mov r1,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06098B18u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06098B18u) return; }  // 06098B14 jsr @r0 ; mov r8,r4
    c.r[1] = c.r[8];  // 06098B18 mov r8,r1
    c.r[9] = ld32(c.r[8] + 4);  // 06098B1A mov.l @(4,r8),r9
    c.r[1] += 76;  // 06098B1C add #76,r1
    c.r[9] += c.r[0];  // 06098B1E add r0,r9
    c.r[0] = ld32(c.r[1]);  // 06098B20 mov.l @r1,r0
    c.t = c.r[0] == 0x1u;  // 06098B22 cmp/eq #1,r0
    { const bool k = !c.t; c.r[6] = 0x0u; if (k) { goto L_06098B50; } }  // 06098B24 bf/s 0x06098B50 ; mov #0,r6
    c.r[5] = ld32(0x06098C00u);  // 06098B28 mov.l 0x06098C00,r5
    c.r[0] = ld32(0x06098C04u);  // 06098B2A mov.l 0x06098C04,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06098B30u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06098B30u) return; }  // 06098B2C jsr @r0 ; mov r8,r4
    c.r[7] = c.r[0];  // 06098B30 mov r0,r7
    c.t = (int32_t)c.r[7] >= 0;  // 06098B32 cmp/pz r7
    if (c.t) { goto L_06098B38; }  // 06098B34 bt 0x06098B38
    c.r[7] = 0x0u;  // 06098B36 mov #0,r7
L_06098B38:
    c.t = (int32_t)c.r[7] > 0;  // 06098B38 cmp/pl r7
    if (!c.t) { goto L_06098B52; }  // 06098B3A bf 0x06098B52
    c.r[1] = ld32(0x06098C08u);  // 06098B3C mov.l 0x06098C08,r1
    c.r[1] = ld32(c.r[1]);  // 06098B3E mov.l @r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06098BF4u);  // 06098B40 mov.w 0x06098BF4,r2
    c.r[0] = c.r[1];  // 06098B42 mov r1,r0
    c.r[1] = ld32(c.r[0] + c.r[2]);  // 06098B44 mov.l @(r0,r2),r1
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[1];  // 06098B46 cmp/ge r1,r9
    { const bool k = c.t; c.r[1] -= c.r[9]; if (k) { goto L_06098B52; } }  // 06098B48 bt/s 0x06098B52 ; sub r9,r1
    c.r[7] -= c.r[1]; goto L_06098B52;  // 06098B4C bra 0x06098B52 ; sub r1,r7
L_06098B50:
    c.r[7] = 0x0u;  // 06098B50 mov #0,r7
L_06098B52:
    c.r[3] = ld32(c.r[10]);  // 06098B52 mov.l @r10,r3
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[3];  // 06098B54 cmp/ge r3,r7
    { const bool k = !c.t; c.r[1] = c.r[12]; if (k) { goto L_06098B8C; } }  // 06098B56 bf/s 0x06098B8C ; mov r12,r1
    c.r[1] += 88;  // 06098B5A add #88,r1
    c.r[2] = ld32(c.r[1]);  // 06098B5C mov.l @r1,r2
    c.r[12] += 84;  // 06098B5E add #84,r12
    c.r[2] += c.r[3];  // 06098B60 add r3,r2
    st32(c.r[1], c.r[2]);  // 06098B62 mov.l r2,@r1
    c.r[1] = ld32(c.r[12]);  // 06098B64 mov.l @r12,r1
    c.t = c.r[1] == c.r[2];  // 06098B66 cmp/eq r2,r1
    { const bool k = !c.t; c.r[1] = 0x4u; if (k) { goto L_06098B7E; } }  // 06098B68 bf/s 0x06098B7E ; mov #4,r1
    st32(c.r[13], c.r[1]);  // 06098B6C mov.l r1,@r13
    c.r[1] = ld32(0x06098C08u);  // 06098B6E mov.l 0x06098C08,r1
    c.r[2] = ld32(c.r[1]);  // 06098B70 mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06098BF6u);  // 06098B72 mov.w 0x06098BF6,r1
    c.r[0] = c.r[2];  // 06098B74 mov r2,r0
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 06098B76 mov.l @(r0,r1),r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x06098BF4u);  // 06098B78 mov.w 0x06098BF4,r3
    st32(c.r[0] + c.r[3], c.r[1]); goto L_06098BDA;  // 06098B7A bra 0x06098BDA ; mov.l r1,@(r0,r3)
L_06098B7E:
    c.r[1] = 0x2u;  // 06098B7E mov #2,r1
    st32(c.r[13], c.r[1]);  // 06098B80 mov.l r1,@r13
    c.r[1] = ld32(0x06098C08u);  // 06098B82 mov.l 0x06098C08,r1
    c.r[1] = ld32(c.r[1]);  // 06098B84 mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06098BF4u);  // 06098B86 mov.w 0x06098BF4,r0
    st32(c.r[0] + c.r[1], c.r[9]); goto L_06098BDA;  // 06098B88 bra 0x06098BDA ; mov.l r9,@(r0,r1)
L_06098B8C:
    c.r[3] -= c.r[7];  // 06098B8C sub r7,r3
    st32(c.r[10], c.r[3]);  // 06098B8E mov.l r3,@r10
    st32(c.r[11] + 40, c.r[9]);  // 06098B90 mov.l r9,@(40,r11)
    c.r[0] = ld32(0x06098BF8u);  // 06098B92 mov.l 0x06098BF8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06098B98u; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06098B98u) return; }  // 06098B94 jsr @r0 ; mov r11,r4
    c.r[1] = c.r[0];  // 06098B98 mov r0,r1
    c.r[4] = c.r[8];  // 06098B9A mov r8,r4
    c.r[5] = ld32(c.r[10]);  // 06098B9C mov.l @r10,r5
    c.r[0] = ld32(0x06098BFCu);  // 06098B9E mov.l 0x06098BFC,r0
    c.r[5] += c.r[1];  // 06098BA0 add r1,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06098BA6u; c.r[5] -= 1; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06098BA6u) return; }  // 06098BA2 jsr @r0 ; add #-1,r5
    c.r[2] = ld32(c.r[8] + 4);  // 06098BA6 mov.l @(4,r8),r2
    c.r[1] = c.r[0];  // 06098BA8 mov r0,r1
    c.r[2] += c.r[1];  // 06098BAA add r1,r2
    c.r[2] += 1;  // 06098BAC add #1,r2
    st32(c.r[11] + 44, c.r[2]);  // 06098BAE mov.l r2,@(44,r11)
    c.r[1] = ld32(0x06098C08u);  // 06098BB0 mov.l 0x06098C08,r1
    c.r[1] = ld32(c.r[1]);  // 06098BB2 mov.l @r1,r1
    c.r[6] = (uint32_t)(int16_t)ld16(0x06098BF4u);  // 06098BB4 mov.w 0x06098BF4,r6
    c.r[4] = ld32(c.r[11] + 40);  // 06098BB6 mov.l @(40,r11),r4
    c.r[0] = c.r[1];  // 06098BB8 mov r1,r0
    c.r[7] = ld32(c.r[0] + c.r[6]);  // 06098BBA mov.l @(r0,r6),r7
    c.t = (int32_t)c.r[7] > (int32_t)c.r[4];  // 06098BBC cmp/gt r4,r7
    { const bool k = c.t; c.r[0] = 0x1u; if (k) { goto L_06098BE0; } }  // 06098BBE bt/s 0x06098BE0 ; mov #1,r0
    c.r[0] = (uint32_t)(int16_t)ld16(0x06098BF6u);  // 06098BC2 mov.w 0x06098BF6,r0
    c.r[3] = ld32(c.r[0] + c.r[1]);  // 06098BC4 mov.l @(r0,r1),r3
    c.t = (int32_t)c.r[4] >= (int32_t)c.r[3];  // 06098BC6 cmp/ge r3,r4
    { const bool k = c.t; c.t = (int32_t)c.r[7] >= (int32_t)c.r[2]; if (k) { goto L_06098BDE; } }  // 06098BC8 bt/s 0x06098BDE ; cmp/ge r2,r7
    { const bool k = c.t; c.t = (int32_t)c.r[2] > (int32_t)c.r[3]; if (k) { goto L_06098BDE; } }  // 06098BCC bt/s 0x06098BDE ; cmp/gt r3,r2
    { const bool k = c.t; c.r[0] = c.r[1]; if (k) { goto L_06098BDE; } }  // 06098BD0 bt/s 0x06098BDE ; mov r1,r0
    st32(c.r[0] + c.r[6], c.r[4]);  // 06098BD4 mov.l r4,@(r0,r6)
    c.r[1] = 0x1u;  // 06098BD6 mov #1,r1
    st32(c.r[13], c.r[1]);  // 06098BD8 mov.l r1,@r13
L_06098BDA:
    c.r[0] = 0x0u; goto L_06098BE0;  // 06098BDA bra 0x06098BE0 ; mov #0,r0
L_06098BDE:
    c.r[0] = 0x1u;  // 06098BDE mov #1,r0
L_06098BE0:
    c.r[15] = c.r[14];  // 06098BE0 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06098BE2 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06098BE4 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06098BE6 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06098BE8 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06098BEA mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06098BEC mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06098BEE mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06098BF0 rts ; mov.l @r15+,r8
}

void f_06098C0C(SH2Context& c) {
    ran[2346] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06098C0C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06098C0E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06098C10 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06098C12 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06098C14 sts.l pr,@-r15
    c.r[15] -= 4;  // 06098C16 add #-4,r15
    c.r[14] = c.r[15];  // 06098C18 mov r15,r14
    c.r[9] = c.r[4];  // 06098C1A mov r4,r9
    c.r[8] = c.r[5];  // 06098C1C mov r5,r8
    c.t = (c.r[9] & c.r[9]) == 0;  // 06098C1E tst r9,r9
    { const bool k = c.t; c.r[10] = c.r[6]; if (k) { goto L_06098C4A; } }  // 06098C20 bt/s 0x06098C4A ; mov r6,r10
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06098C24 mov.l r14,@-r15
    c.r[1] = ld32(0x06098C70u);  // 06098C26 mov.l 0x06098C70,r1
    c.r[7] = 0x0u;  // 06098C28 mov #0,r7
    c.r[6] = 0x0u;  // 06098C2A mov #0,r6
    { const uint32_t x = c.r[1]; c.pr = 0x06098C30u; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06098C30u) return; }  // 06098C2C jsr @r1 ; mov #0,r5
    c.r[0] = ld32(c.r[14]);  // 06098C30 mov.l @r14,r0
    c.r[0] &= 0x80u;  // 06098C32 and #128,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06098C34 tst r0,r0
    { const bool k = !c.t; c.r[15] += 4; if (k) { goto L_06098C3E; } }  // 06098C36 bf/s 0x06098C3E ; add #4,r15
    c.r[0] = 0xFFFFFFFAu; goto L_06098C60;  // 06098C3A bra 0x06098C60 ; mov #-6,r0
L_06098C3E:
    c.r[0] = ld32(0x06098C74u);  // 06098C3E mov.l 0x06098C74,r0
    c.r[5] = c.r[10];  // 06098C40 mov r10,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06098C46u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06098C46u) return; }  // 06098C42 jsr @r0 ; mov r9,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 06098C46 tst r0,r0
    if (!c.t) { goto L_06098C60; }  // 06098C48 bf 0x06098C60
L_06098C4A:
    c.r[1] = ld32(c.r[8]);  // 06098C4A mov.l @r8,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06098C4C tst r1,r1
    { const bool k = !c.t; c.r[6] = ld32(c.r[8] + 4); if (k) { goto L_06098C58; } }  // 06098C4E bf/s 0x06098C58 ; mov.l @(4,r8),r6
    c.r[0] = ld32(0x06098C78u);  // 06098C52 mov.l 0x06098C78,r0
    c.r[5] = ld32(c.r[8] + 8); goto L_06098C5C;  // 06098C54 bra 0x06098C5C ; mov.l @(8,r8),r5
L_06098C58:
    c.r[0] = ld32(0x06098C7Cu);  // 06098C58 mov.l 0x06098C7C,r0
    c.r[5] = ld32(c.r[8] + 8);  // 06098C5A mov.l @(8,r8),r5
L_06098C5C:
    { const uint32_t x = c.r[0]; c.pr = 0x06098C60u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06098C60u) return; }  // 06098C5C jsr @r0 ; mov r9,r4
L_06098C60:
    c.r[14] += 4;  // 06098C60 add #4,r14
    c.r[15] = c.r[14];  // 06098C62 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06098C64 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06098C66 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06098C68 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06098C6A mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06098C6C rts ; mov.l @r15+,r8
}

void f_06098C80(SH2Context& c) {
    ran[2347] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06098C80 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06098C82 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06098C84 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06098C86 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06098C88 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06098C8A mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06098C8C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06098C8E sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06098C90 mov r15,r14
    c.r[9] = c.r[4];  // 06098C92 mov r4,r9
    c.r[11] = c.r[6];  // 06098C94 mov r6,r11
    c.r[8] = 0x0u;  // 06098C96 mov #0,r8
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[11];  // 06098C98 cmp/ge r11,r8
    { const bool k = c.t; c.r[12] = c.r[5]; if (k) { goto L_06098CC6; } }  // 06098C9A bt/s 0x06098CC6 ; mov r5,r12
    c.r[13] = ld32(0x06098CDCu);  // 06098C9E mov.l 0x06098CDC,r13
    c.r[10] = c.r[9];  // 06098CA0 mov r9,r10
    c.r[10] += 11;  // 06098CA2 add #11,r10
L_06098CA4:
    c.r[5] = c.r[9];  // 06098CA4 mov r9,r5
    c.r[5] += 12;  // 06098CA6 add #12,r5
    c.r[6] = 0xCu;  // 06098CA8 mov #12,r6
    { const uint32_t x = c.r[13]; c.pr = 0x06098CAEu; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06098CAEu) return; }  // 06098CAA jsr @r13 ; mov r12,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 06098CAE tst r0,r0
    { const bool k = c.t; c.r[0] = c.r[8]; if (k) { goto L_06098CC8; } }  // 06098CB0 bt/s 0x06098CC8 ; mov r8,r0
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[10]);  // 06098CB4 mov.b @r10,r0
    c.r[0] &= 0x1u;  // 06098CB6 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06098CB8 tst r0,r0
    { const bool k = !c.t; c.r[10] += 24; if (k) { goto L_06098CC6; } }  // 06098CBA bf/s 0x06098CC6 ; add #24,r10
    c.r[8] += 1;  // 06098CBE add #1,r8
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[11];  // 06098CC0 cmp/ge r11,r8
    { const bool k = !c.t; c.r[9] += 24; if (k) { SH2_POLL(c); goto L_06098CA4; } }  // 06098CC2 bf/s 0x06098CA4 ; add #24,r9
L_06098CC6:
    c.r[0] = 0xFFFFFFFFu;  // 06098CC6 mov #-1,r0
L_06098CC8:
    c.r[15] = c.r[14];  // 06098CC8 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06098CCA lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06098CCC mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06098CCE mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06098CD0 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06098CD2 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06098CD4 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06098CD6 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06098CD8 rts ; mov.l @r15+,r8
}

void f_06098CE0(SH2Context& c) {
    ran[2348] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06098CE0 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06098CE2 mov r15,r14
    c.r[0] = c.r[5];  // 06098CE4 mov r5,r0
    c.r[1] = c.r[4];  // 06098CE6 mov r4,r1
    c.r[1] += c.r[1];  // 06098CE8 add r1,r1
    c.r[1] += c.r[4];  // 06098CEA add r4,r1
    c.r[1] <<= 2;  // 06098CEC shll2 r1
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06098CEE mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] += c.r[1]; c.pc = x; return; }  // 06098CF0 rts ; add r1,r0
}

void f_06098CF4(SH2Context& c) {
    ran[2349] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06098CF4 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06098CF6 mov r15,r14
    c.r[0] = c.r[5];  // 06098CF8 mov r5,r0
    c.r[1] = 0x18u;  // 06098CFA mov #24,r1
    c.macl = c.r[4] * c.r[1];  // 06098CFC mul.l r1,r4
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06098CFE mov.l @r15+,r14
    c.r[1] = c.macl;  // 06098D00 sts macl,r1
    { const uint32_t x = c.pr; c.r[0] += c.r[1]; c.pc = x; return; }  // 06098D02 rts ; add r1,r0
}

void f_06098D08(SH2Context& c) {
    ran[2350] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06098D08 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06098D0A mov r15,r14
    c.r[1] = c.r[4];  // 06098D0C mov r4,r1
    c.r[1] += c.r[1];  // 06098D0E add r1,r1
    c.r[1] += c.r[4];  // 06098D10 add r4,r1
    c.r[1] <<= 2;  // 06098D12 shll2 r1
    c.r[1] += c.r[5];  // 06098D14 add r5,r1
    c.r[1] += 11;  // 06098D16 add #11,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06098D18 mov.b @r1,r1
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06098D1A mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[1] & 0xFFu; c.pc = x; return; }  // 06098D1C rts ; extu.b r1,r0
}

void f_06098D20(SH2Context& c) {
    ran[2351] = 1;
    c.r[1] = 0x18u;  // 06098D20 mov #24,r1
    c.macl = c.r[4] * c.r[1];  // 06098D22 mul.l r1,r4
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06098D24 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06098D26 mov r15,r14
    c.r[1] = c.macl;  // 06098D28 sts macl,r1
    c.r[1] += c.r[5];  // 06098D2A add r5,r1
    c.r[1] += 11;  // 06098D2C add #11,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06098D2E mov.b @r1,r1
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06098D30 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[1] & 0xFFu; c.pc = x; return; }  // 06098D32 rts ; extu.b r1,r0
}

void f_06098D38(SH2Context& c) {
    ran[2352] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06098D38 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06098D3A sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06098D3C mov r15,r14
    c.r[0] = ld32(0x06098D4Cu);  // 06098D3E mov.l 0x06098D4C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06098D44u; c.r[4] = 0xFFFFFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06098D44u) return; }  // 06098D40 jsr @r0 ; mov #-1,r4
    c.r[15] = c.r[14];  // 06098D44 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06098D46 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06098D48 rts ; mov.l @r15+,r14
}

void f_06098D50(SH2Context& c) {
    ran[2353] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06098D50 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06098D52 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06098D54 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06098D56 sts.l pr,@-r15
    c.r[15] -= 4;  // 06098D58 add #-4,r15
    c.r[8] = c.r[4];  // 06098D5A mov r4,r8
    c.r[4] = ld32(0x06098DCCu);  // 06098D5C mov.l 0x06098DCC,r4
    c.r[1] = ld32(0x06098DD0u);  // 06098D5E mov.l 0x06098DD0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06098D64u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06098D64u) return; }  // 06098D60 jsr @r1 ; mov r15,r14
    c.r[9] = ld32(0x06098DD4u);  // 06098D64 mov.l 0x06098DD4,r9
    c.r[6] = c.r[14];  // 06098D66 mov r14,r6
L_06098D68:
    c.r[5] = 0x17u;  // 06098D68 mov #23,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06098D6Eu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06098D6Eu) return; }  // 06098D6A jsr @r9 ; mov r8,r4
    c.t = c.r[0] == 0xFFFFFFFBu;  // 06098D6E cmp/eq #-5,r0
    { const bool k = c.t; c.t = (c.r[0] & c.r[0]) == 0; if (k) { goto L_06098DB6; } }  // 06098D70 bt/s 0x06098DB6 ; tst r0,r0
    { const bool k = !c.t; c.r[6] = c.r[14]; if (k) { SH2_POLL(c); goto L_06098D68; } }  // 06098D74 bf/s 0x06098D68 ; mov r14,r6
    c.r[0] = ld32(0x06098DD8u);  // 06098D78 mov.l 0x06098DD8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06098D7Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06098D7Eu) return; }  // 06098D7A jsr @r0 ; nop
    c.t = c.r[0] == 0x3u;  // 06098D7E cmp/eq #3,r0
    if (!c.t) { goto L_06098D88; }  // 06098D80 bf 0x06098D88
    c.r[0] = 0xFFFFFFEAu;  // 06098D82 mov #-22,r0
    c.r[14] += 4; goto L_06098DBE;  // 06098D84 bra 0x06098DBE ; add #4,r14
L_06098D88:
    c.t = c.r[0] == 0x2u;  // 06098D88 cmp/eq #2,r0
    { const bool k = !c.t; c.t = (c.r[0] & c.r[0]) == 0; if (k) { goto L_06098DAE; } }  // 06098D8A bf/s 0x06098DAE ; tst r0,r0
    c.r[1] = ld32(0x06098DDCu);  // 06098D8E mov.l 0x06098DDC,r1
    c.r[0] = ld32(c.r[1]);  // 06098D90 mov.l @r1,r0
    c.t = c.r[0] == 0xFFFFFFF2u;  // 06098D92 cmp/eq #-14,r0
    { const bool k = c.t; c.r[1] = 0xFFFFFFF2u; if (k) { goto L_06098DA6; } }  // 06098D94 bt/s 0x06098DA6 ; mov #-14,r1
    c.t = (int32_t)c.r[0] > (int32_t)c.r[1];  // 06098D98 cmp/gt r1,r0
    { const bool k = !c.t; c.t = c.r[0] == 0xFFFFFFF3u; if (k) { goto L_06098DAA; } }  // 06098D9A bf/s 0x06098DAA ; cmp/eq #-13,r0
    { const bool k = !c.t; c.r[0] = 0xFFFFFFE9u; if (k) { goto L_06098DAA; } }  // 06098D9E bf/s 0x06098DAA ; mov #-23,r0
    c.r[14] += 4; goto L_06098DBE;  // 06098DA2 bra 0x06098DBE ; add #4,r14
L_06098DA6:
    c.r[0] = 0xFFFFFFFEu; goto L_06098DBC;  // 06098DA6 bra 0x06098DBC ; mov #-2,r0
L_06098DAA:
    c.r[0] = 0xFFFFFFE7u; goto L_06098DBC;  // 06098DAA bra 0x06098DBC ; mov #-25,r0
L_06098DAE:
    { const bool k = !c.t; c.r[0] = ld32(c.r[14]); if (k) { goto L_06098DBA; } }  // 06098DAE bf/s 0x06098DBA ; mov.l @r14,r0
    c.r[14] += 4; goto L_06098DBE;  // 06098DB2 bra 0x06098DBE ; add #4,r14
L_06098DB6:
    c.r[0] = 0xFFFFFFF9u; goto L_06098DBC;  // 06098DB6 bra 0x06098DBC ; mov #-7,r0
L_06098DBA:
    c.r[0] = 0xFFFFFFFFu;  // 06098DBA mov #-1,r0
L_06098DBC:
    c.r[14] += 4;  // 06098DBC add #4,r14
L_06098DBE:
    c.r[15] = c.r[14];  // 06098DBE mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06098DC0 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06098DC2 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06098DC4 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06098DC6 rts ; mov.l @r15+,r8
}

void f_06098DE0(SH2Context& c) {
    ran[2354] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06098DE0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06098DE2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06098DE4 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06098DE6 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06098DE8 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06098DEA mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06098DEC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06098DEE sts.l pr,@-r15
    c.r[15] -= 48;  // 06098DF0 add #-48,r15
    c.r[14] = c.r[15];  // 06098DF2 mov r15,r14
    c.r[9] = c.r[6];  // 06098DF4 mov r6,r9
    c.r[8] = c.r[5];  // 06098DF6 mov r5,r8
    c.r[1] = ld32(0x06098E58u);  // 06098DF8 mov.l 0x06098E58,r1
    c.r[5] = c.r[4];  // 06098DFA mov r4,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06098E00u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06098E00u) return; }  // 06098DFC jsr @r1 ; mov r14,r4
    c.t = (int32_t)c.r[9] > 0;  // 06098E00 cmp/pl r9
    { const bool k = !c.t; c.r[11] = 0x0u; if (k) { goto L_06098E34; } }  // 06098E02 bf/s 0x06098E34 ; mov #0,r11
    c.r[10] = c.r[14];  // 06098E06 mov r14,r10
    c.r[10] += 20;  // 06098E08 add #20,r10
    c.r[13] = ld32(0x06098E5Cu);  // 06098E0A mov.l 0x06098E5C,r13
    c.r[12] = ld32(0x06098E60u);  // 06098E0C mov.l 0x06098E60,r12
L_06098E0E:
    c.r[5] = c.r[10];  // 06098E0E mov r10,r5
    { const uint32_t x = c.r[13]; c.pr = 0x06098E14u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06098E14u) return; }  // 06098E10 jsr @r13 ; mov r14,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 06098E14 tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[14]; if (k) { goto L_06098E40; } }  // 06098E16 bf/s 0x06098E40 ; mov r14,r1
    c.r[1] += 28;  // 06098E1A add #28,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06098E1C mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06098E1E extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06098E20 tst r1,r1
    { const bool k = c.t; c.r[5] = c.r[10]; if (k) { goto L_06098E34; } }  // 06098E22 bt/s 0x06098E34 ; mov r10,r5
    { const uint32_t x = c.r[12]; c.pr = 0x06098E2Au; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06098E2Au) return; }  // 06098E26 jsr @r12 ; mov r8,r4
    c.r[8] += 12;  // 06098E2A add #12,r8
    c.r[9] -= 1;  // 06098E2C add #-1,r9
    c.t = (int32_t)c.r[9] > 0;  // 06098E2E cmp/pl r9
    { const bool k = c.t; c.r[11] += 1; if (k) { SH2_POLL(c); goto L_06098E0E; } }  // 06098E30 bt/s 0x06098E0E ; add #1,r11
L_06098E34:
    c.r[1] = c.r[8];  // 06098E34 mov r8,r1
    c.r[1] -= 1;  // 06098E36 add #-1,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06098E38 mov.b @r1,r0
    c.r[0] |= 0x1u;  // 06098E3A or #1,r0
    st8(c.r[1], c.r[0]);  // 06098E3C mov.b r0,@r1
    c.r[0] = c.r[11];  // 06098E3E mov r11,r0
L_06098E40:
    c.r[14] += 48;  // 06098E40 add #48,r14
    c.r[15] = c.r[14];  // 06098E42 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06098E44 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06098E46 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06098E48 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06098E4A mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06098E4C mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06098E4E mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06098E50 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06098E52 rts ; mov.l @r15+,r8
}

void f_06098E64(SH2Context& c) {
    ran[2355] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06098E64 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06098E66 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06098E68 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06098E6A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06098E6C mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06098E6E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06098E70 sts.l pr,@-r15
    c.r[15] -= 48;  // 06098E72 add #-48,r15
    c.r[14] = c.r[15];  // 06098E74 mov r15,r14
    c.r[9] = c.r[6];  // 06098E76 mov r6,r9
    c.r[8] = c.r[5];  // 06098E78 mov r5,r8
    c.r[1] = ld32(0x06098EFCu);  // 06098E7A mov.l 0x06098EFC,r1
    c.r[5] = c.r[4];  // 06098E7C mov r4,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06098E82u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06098E82u) return; }  // 06098E7E jsr @r1 ; mov r14,r4
    c.t = (int32_t)c.r[9] > 0;  // 06098E82 cmp/pl r9
    { const bool k = !c.t; c.r[10] = 0x0u; if (k) { goto L_06098EDC; } }  // 06098E84 bf/s 0x06098EDC ; mov #0,r10
    c.r[11] = c.r[14];  // 06098E88 mov r14,r11
    c.r[11] += 20;  // 06098E8A add #20,r11
    c.r[12] = ld32(0x06098F00u);  // 06098E8C mov.l 0x06098F00,r12
L_06098E8E:
    c.r[0] = ld32(0x06098F04u);  // 06098E8E mov.l 0x06098F04,r0
    c.r[5] = c.r[11];  // 06098E90 mov r11,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06098E96u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06098E96u) return; }  // 06098E92 jsr @r0 ; mov r14,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 06098E96 tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[14]; if (k) { goto L_06098EE8; } }  // 06098E98 bf/s 0x06098EE8 ; mov r14,r1
    c.r[1] += 28;  // 06098E9C add #28,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06098E9E mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06098EA0 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06098EA2 tst r1,r1
    { const bool k = c.t; c.r[1] = 0x2u; if (k) { goto L_06098EDC; } }  // 06098EA4 bt/s 0x06098EDC ; mov #2,r1
    c.t = (int32_t)c.r[10] > (int32_t)c.r[1];  // 06098EA8 cmp/gt r1,r10
    { const bool k = !c.t; c.r[4] = c.r[8]; if (k) { goto L_06098EBC; } }  // 06098EAA bf/s 0x06098EBC ; mov r8,r4
    c.r[4] -= 12;  // 06098EAE add #-12,r4
    c.r[6] = 0xCu;  // 06098EB0 mov #12,r6
    c.r[5] = c.r[14];  // 06098EB2 mov r14,r5
    { const uint32_t x = c.r[12]; c.pr = 0x06098EB8u; c.r[5] += 32; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06098EB8u) return; }  // 06098EB4 jsr @r12 ; add #32,r5
    c.t = (c.r[0] & c.r[0]) == 0;  // 06098EB8 tst r0,r0
    if (c.t) { goto L_06098ED2; }  // 06098EBA bt 0x06098ED2
L_06098EBC:
    c.r[1] = ld32(0x06098F08u);  // 06098EBC mov.l 0x06098F08,r1
    c.r[5] = c.r[11];  // 06098EBE mov r11,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06098EC4u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06098EC4u) return; }  // 06098EC0 jsr @r1 ; mov r8,r4
    c.r[4] = c.r[8];  // 06098EC4 mov r8,r4
    c.r[4] += 12;  // 06098EC6 add #12,r4
    c.r[0] = ld32(0x06098F0Cu);  // 06098EC8 mov.l 0x06098F0C,r0
    c.r[6] = 0xCu;  // 06098ECA mov #12,r6
    c.r[5] = c.r[14];  // 06098ECC mov r14,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06098ED2u; c.r[5] += 32; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06098ED2u) return; }  // 06098ECE jsr @r0 ; add #32,r5
L_06098ED2:
    c.r[8] += 24;  // 06098ED2 add #24,r8
    c.r[9] -= 1;  // 06098ED4 add #-1,r9
    c.t = (int32_t)c.r[9] > 0;  // 06098ED6 cmp/pl r9
    { const bool k = c.t; c.r[10] += 1; if (k) { SH2_POLL(c); goto L_06098E8E; } }  // 06098ED8 bt/s 0x06098E8E ; add #1,r10
L_06098EDC:
    c.r[1] = c.r[8];  // 06098EDC mov r8,r1
    c.r[1] -= 13;  // 06098EDE add #-13,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06098EE0 mov.b @r1,r0
    c.r[0] |= 0x1u;  // 06098EE2 or #1,r0
    st8(c.r[1], c.r[0]);  // 06098EE4 mov.b r0,@r1
    c.r[0] = c.r[10];  // 06098EE6 mov r10,r0
L_06098EE8:
    c.r[14] += 48;  // 06098EE8 add #48,r14
    c.r[15] = c.r[14];  // 06098EEA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06098EEC lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06098EEE mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06098EF0 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06098EF2 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06098EF4 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06098EF6 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06098EF8 rts ; mov.l @r15+,r8
}

void f_06098F10(SH2Context& c) {
    ran[2356] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06098F10 mov.l r14,@-r15
    st32(c.r[4], c.r[5]);  // 06098F12 mov.l r5,@r4
    c.r[1] = ld32(0x06098F34u);  // 06098F14 mov.l 0x06098F34,r1
    c.r[2] = ld32(c.r[1]);  // 06098F16 mov.l @r1,r2
    c.r[14] = c.r[15];  // 06098F18 mov r15,r14
    c.r[1] = (uint32_t)(int16_t)ld16(0x06098F30u);  // 06098F1A mov.w 0x06098F30,r1
    c.r[2] += c.r[1];  // 06098F1C add r1,r2
    st32(c.r[4] + 4, c.r[2]);  // 06098F1E mov.l r2,@(4,r4)
    c.r[1] = 0xFFFFFFFFu;  // 06098F20 mov #-1,r1
    st32(c.r[4] + 8, c.r[1]);  // 06098F22 mov.l r1,@(8,r4)
    c.r[1] = ld32(c.r[5] + 32);  // 06098F24 mov.l @(32,r5),r1
    st32(c.r[4] + 16, c.r[1]);  // 06098F26 mov.l r1,@(16,r4)
    c.r[1] = 0x0u;  // 06098F28 mov #0,r1
    st32(c.r[4] + 12, c.r[1]);  // 06098F2A mov.l r1,@(12,r4)
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06098F2C rts ; mov.l @r15+,r14
}

void f_06098F38(SH2Context& c) {
    ran[2357] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06098F38 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06098F3A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06098F3C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06098F3E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06098F40 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06098F42 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06098F44 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06098F46 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06098F48 mov r15,r14
    c.r[9] = c.r[4];  // 06098F4A mov r4,r9
    c.r[12] = c.r[5];  // 06098F4C mov r5,r12
    c.r[4] = ld32(c.r[9]);  // 06098F4E mov.l @r9,r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 06098F50 tst r4,r4
    { const bool k = !c.t; c.r[10] = c.r[6]; if (k) { goto L_06098F62; } }  // 06098F52 bf/s 0x06098F62 ; mov r6,r10
    c.r[0] = ld32(0x06098FECu);  // 06098F56 mov.l 0x06098FEC,r0
    c.r[5] = 0x0u;  // 06098F58 mov #0,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06098F5Eu; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06098F5Eu) return; }  // 06098F5A jsr @r0 ; mov r12,r4
    c.r[0] = 0x0u; goto L_06098FD2;  // 06098F5E bra 0x06098FD2 ; mov #0,r0
L_06098F62:
    c.r[0] = ld32(c.r[9] + 8);  // 06098F62 mov.l @(8,r9),r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 06098F64 cmp/eq #-1,r0
    if (c.t) { goto L_06098F6E; }  // 06098F66 bt 0x06098F6E
    c.r[1] = (uint32_t)(int16_t)ld16(0x06098FE6u);  // 06098F68 mov.w 0x06098FE6,r1
    c.t = (int32_t)c.r[0] > (int32_t)c.r[1];  // 06098F6A cmp/gt r1,r0
    if (!c.t) { goto L_06098F8C; }  // 06098F6C bf 0x06098F8C
L_06098F6E:
    c.r[8] = (uint32_t)(int16_t)ld16(0x06098FE8u);  // 06098F6E mov.w 0x06098FE8,r8
    c.r[6] = ld32(c.r[9] + 4);  // 06098F70 mov.l @(4,r9),r6
    c.r[0] = ld32(0x06098FF0u);  // 06098F72 mov.l 0x06098FF0,r0
    c.r[7] = c.r[8];  // 06098F74 mov r8,r7
    { const uint32_t x = c.r[0]; c.pr = 0x06098F7Au; c.r[5] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06098F7Au) return; }  // 06098F76 jsr @r0 ; mov #1,r5
    c.t = c.r[0] == c.r[8];  // 06098F7A cmp/eq r8,r0
    { const bool k = c.t; c.r[1] = 0x0u; if (k) { goto L_06098F8A; } }  // 06098F7C bt/s 0x06098F8A ; mov #0,r1
L_06098F80:
    c.t = (int32_t)c.r[0] >= 0;  // 06098F80 cmp/pz r0
    if (!c.t) { goto L_06098FD2; }  // 06098F82 bf 0x06098FD2
    c.r[0] = 0xFFFFFFFFu;  // 06098F84 mov #-1,r0
    c.r[15] = c.r[14]; goto L_06098FD4;  // 06098F86 bra 0x06098FD4 ; mov r14,r15
L_06098F8A:
    st32(c.r[9] + 8, c.r[1]);  // 06098F8A mov.l r1,@(8,r9)
L_06098F8C:
    c.r[1] = ld32(c.r[9] + 8);  // 06098F8C mov.l @(8,r9),r1
    c.r[11] = (uint32_t)(int16_t)ld16(0x06098FE8u);  // 06098F8E mov.w 0x06098FE8,r11
    c.r[8] = c.r[11];  // 06098F90 mov r11,r8
    c.r[8] -= c.r[1];  // 06098F92 sub r1,r8
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[10];  // 06098F94 cmp/ge r10,r8
    { const bool k = !c.t; c.r[6] = c.r[8]; if (k) { goto L_06098F9C; } }  // 06098F96 bf/s 0x06098F9C ; mov r8,r6
    c.r[6] = c.r[10];  // 06098F9A mov r10,r6
L_06098F9C:
    c.r[8] = c.r[6];  // 06098F9C mov r6,r8
    c.r[13] = ld32(0x06098FF4u);  // 06098F9E mov.l 0x06098FF4,r13
    c.r[5] = ld32(c.r[9] + 4);  // 06098FA0 mov.l @(4,r9),r5
    c.r[4] = c.r[12];  // 06098FA2 mov r12,r4
    { const uint32_t x = c.r[13]; c.pr = 0x06098FA8u; c.r[5] += c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06098FA8u) return; }  // 06098FA4 jsr @r13 ; add r1,r5
    c.r[1] = ld32(c.r[9] + 8);  // 06098FA8 mov.l @(8,r9),r1
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[10];  // 06098FAA cmp/ge r10,r8
    c.r[1] += c.r[8];  // 06098FAC add r8,r1
    { const bool k = c.t; st32(c.r[9] + 8, c.r[1]); if (k) { goto L_06098FD0; } }  // 06098FAE bt/s 0x06098FD0 ; mov.l r1,@(8,r9)
    c.r[10] -= c.r[8];  // 06098FB2 sub r8,r10
    c.r[0] = ld32(0x06098FF0u);  // 06098FB4 mov.l 0x06098FF0,r0
    c.r[6] = ld32(c.r[9] + 4);  // 06098FB6 mov.l @(4,r9),r6
    c.r[7] = c.r[11];  // 06098FB8 mov r11,r7
    c.r[4] = ld32(c.r[9]);  // 06098FBA mov.l @r9,r4
    { const uint32_t x = c.r[0]; c.pr = 0x06098FC0u; c.r[5] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06098FC0u) return; }  // 06098FBC jsr @r0 ; mov #1,r5
    c.t = c.r[0] == c.r[11];  // 06098FC0 cmp/eq r11,r0
    if (!c.t) { SH2_POLL(c); goto L_06098F80; }  // 06098FC2 bf 0x06098F80
    c.r[5] = ld32(c.r[9] + 4);  // 06098FC4 mov.l @(4,r9),r5
    c.r[12] += c.r[8];  // 06098FC6 add r8,r12
    c.r[6] = c.r[10];  // 06098FC8 mov r10,r6
    { const uint32_t x = c.r[13]; c.pr = 0x06098FCEu; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06098FCEu) return; }  // 06098FCA jsr @r13 ; mov r12,r4
    st32(c.r[9] + 8, c.r[10]);  // 06098FCE mov.l r10,@(8,r9)
L_06098FD0:
    c.r[0] = 0x0u;  // 06098FD0 mov #0,r0
L_06098FD2:
    c.r[15] = c.r[14];  // 06098FD2 mov r14,r15
L_06098FD4:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06098FD4 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06098FD6 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06098FD8 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06098FDA mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06098FDC mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06098FDE mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06098FE0 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06098FE2 rts ; mov.l @r15+,r8
}

void f_06098FF8(SH2Context& c) {
    ran[2358] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06098FF8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06098FFA mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06098FFC sts.l pr,@-r15
    c.r[15] -= 4;  // 06098FFE add #-4,r15
    c.r[14] = c.r[15];  // 06099000 mov r15,r14
    c.r[8] = c.r[5];  // 06099002 mov r5,r8
    c.r[0] = ld32(0x06099020u);  // 06099004 mov.l 0x06099020,r0
    c.r[6] = 0x1u;  // 06099006 mov #1,r6
    { const uint32_t x = c.r[0]; c.pr = 0x0609900Cu; c.r[5] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609900Cu) return; }  // 06099008 jsr @r0 ; mov r14,r5
    st32(c.r[8], c.r[0]);  // 0609900C mov.l r0,@r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[14]);  // 0609900E mov.b @r14,r1
    c.r[14] += 4;  // 06099010 add #4,r14
    c.r[15] = c.r[14];  // 06099012 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06099014 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06099016 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06099018 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.r[0] = c.r[1] & 0xFFu; c.pc = x; return; }  // 0609901A rts ; extu.b r1,r0
}

void f_06099024(SH2Context& c) {
    ran[2359] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06099024 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06099026 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06099028 sts.l pr,@-r15
    c.r[15] -= 4;  // 0609902A add #-4,r15
    c.r[14] = c.r[15];  // 0609902C mov r15,r14
    c.r[8] = c.r[5];  // 0609902E mov r5,r8
    c.r[0] = ld32(0x0609904Cu);  // 06099030 mov.l 0x0609904C,r0
    c.r[6] = 0x2u;  // 06099032 mov #2,r6
    { const uint32_t x = c.r[0]; c.pr = 0x06099038u; c.r[5] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06099038u) return; }  // 06099034 jsr @r0 ; mov r14,r5
    st32(c.r[8], c.r[0]);  // 06099038 mov.l r0,@r8
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[14]);  // 0609903A mov.w @r14,r1
    c.r[14] += 4;  // 0609903C add #4,r14
    c.r[15] = c.r[14];  // 0609903E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06099040 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06099042 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06099044 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.r[0] = c.r[1] & 0xFFFFu; c.pc = x; return; }  // 06099046 rts ; extu.w r1,r0
}

void f_06099050(SH2Context& c) {
    ran[2360] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06099050 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06099052 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06099054 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06099056 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06099058 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609905A sts.l pr,@-r15
    c.r[15] -= 4;  // 0609905C add #-4,r15
    c.r[14] = c.r[15];  // 0609905E mov r15,r14
    c.r[9] = c.r[4];  // 06099060 mov r4,r9
    c.r[10] = c.r[5];  // 06099062 mov r5,r10
    c.r[11] = ld32(0x060990A0u);  // 06099064 mov.l 0x060990A0,r11
    c.r[6] = 0x2u;  // 06099066 mov #2,r6
    { const uint32_t x = c.r[11]; c.pr = 0x0609906Cu; c.r[5] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609906Cu) return; }  // 06099068 jsr @r11 ; mov r14,r5
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609906C tst r0,r0
    { const bool k = !c.t; st32(c.r[10], c.r[0]); if (k) { goto L_0609908A; } }  // 0609906E bf/s 0x0609908A ; mov.l r0,@r10
    c.r[8] = c.r[14];  // 06099072 mov r14,r8
    c.r[8] += 2;  // 06099074 add #2,r8
    c.r[6] = 0x2u;  // 06099076 mov #2,r6
    c.r[5] = c.r[8];  // 06099078 mov r8,r5
    { const uint32_t x = c.r[11]; c.pr = 0x0609907Eu; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609907Eu) return; }  // 0609907A jsr @r11 ; mov r9,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609907E tst r0,r0
    { const bool k = !c.t; st32(c.r[10], c.r[0]); if (k) { goto L_0609908A; } }  // 06099080 bf/s 0x0609908A ; mov.l r0,@r10
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06099084 mov.w @r8,r1
    c.r[0] = c.r[1] & 0xFFFFu; goto L_0609908C;  // 06099086 bra 0x0609908C ; extu.w r1,r0
L_0609908A:
    c.r[0] = 0x0u;  // 0609908A mov #0,r0
L_0609908C:
    c.r[14] += 4;  // 0609908C add #4,r14
    c.r[15] = c.r[14];  // 0609908E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06099090 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06099092 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06099094 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06099096 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06099098 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609909A rts ; mov.l @r15+,r8
}

void f_060990A4(SH2Context& c) {
    ran[2361] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060990A4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060990A6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060990A8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060990AA mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060990AC sts.l pr,@-r15
    c.r[15] -= 8;  // 060990AE add #-8,r15
    c.r[14] = c.r[15];  // 060990B0 mov r15,r14
    c.r[8] = c.r[4];  // 060990B2 mov r4,r8
    c.r[9] = c.r[5];  // 060990B4 mov r5,r9
    c.r[10] = ld32(0x060990ECu);  // 060990B6 mov.l 0x060990EC,r10
    c.r[6] = 0x4u;  // 060990B8 mov #4,r6
    { const uint32_t x = c.r[10]; c.pr = 0x060990BEu; c.r[5] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060990BEu) return; }  // 060990BA jsr @r10 ; mov r14,r5
    c.t = (c.r[0] & c.r[0]) == 0;  // 060990BE tst r0,r0
    { const bool k = !c.t; st32(c.r[9], c.r[0]); if (k) { goto L_060990D8; } }  // 060990C0 bf/s 0x060990D8 ; mov.l r0,@r9
    c.r[5] = c.r[14];  // 060990C4 mov r14,r5
    c.r[5] += 4;  // 060990C6 add #4,r5
    c.r[6] = 0x4u;  // 060990C8 mov #4,r6
    { const uint32_t x = c.r[10]; c.pr = 0x060990CEu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060990CEu) return; }  // 060990CA jsr @r10 ; mov r8,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 060990CE tst r0,r0
    { const bool k = !c.t; st32(c.r[9], c.r[0]); if (k) { goto L_060990D8; } }  // 060990D0 bf/s 0x060990D8 ; mov.l r0,@r9
    c.r[0] = ld32(c.r[14] + 4); goto L_060990DA;  // 060990D4 bra 0x060990DA ; mov.l @(4,r14),r0
L_060990D8:
    c.r[0] = 0x0u;  // 060990D8 mov #0,r0
L_060990DA:
    c.r[14] += 8;  // 060990DA add #8,r14
    c.r[15] = c.r[14];  // 060990DC mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060990DE lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060990E0 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060990E2 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060990E4 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060990E6 rts ; mov.l @r15+,r8
}

void f_060990F0(SH2Context& c) {
    ran[2362] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060990F0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060990F2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060990F4 sts.l pr,@-r15
    c.r[15] -= 4;  // 060990F6 add #-4,r15
    c.r[14] = c.r[15];  // 060990F8 mov r15,r14
    c.r[8] = c.r[5];  // 060990FA mov r5,r8
    c.r[0] = ld32(0x06099114u);  // 060990FC mov.l 0x06099114,r0
    c.r[6] = 0x4u;  // 060990FE mov #4,r6
    { const uint32_t x = c.r[0]; c.pr = 0x06099104u; c.r[5] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06099104u) return; }  // 06099100 jsr @r0 ; mov r14,r5
    st32(c.r[8], c.r[0]);  // 06099104 mov.l r0,@r8
    c.r[0] = ld32(c.r[14]); c.r[14] += 4;  // 06099106 mov.l @r14+,r0
    c.r[15] = c.r[14];  // 06099108 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609910A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609910C mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609910E rts ; mov.l @r15+,r8
}

void f_06099118(SH2Context& c) {
    ran[2363] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06099118 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609911A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0609911C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0609911E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06099120 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06099122 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06099124 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06099126 mov r15,r14
    c.r[9] = c.r[4];  // 06099128 mov r4,r9
    c.r[12] = ld32(0x06099194u);  // 0609912A mov.l 0x06099194,r12
    { const uint32_t x = c.r[12]; c.pr = 0x06099130u; c.r[11] = c.r[5]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06099130u) return; }  // 0609912C jsr @r12 ; mov r5,r11
    c.r[1] = ld32(c.r[11]);  // 06099130 mov.l @r11,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06099132 tst r1,r1
    { const bool k = !c.t; c.r[10] = c.r[0] & 0xFFu; if (k) { goto L_0609917C; } }  // 06099134 bf/s 0x0609917C ; extu.b r0,r10
    c.t = (c.r[10] & c.r[10]) == 0;  // 06099138 tst r10,r10
    if (!c.t) { goto L_06099178; }  // 0609913A bf 0x06099178
    c.r[2] = ld32(c.r[9] + 12);  // 0609913C mov.l @(12,r9),r2
    c.r[1] = ld32(c.r[9] + 16);  // 0609913E mov.l @(16,r9),r1
    c.r[2] += 1;  // 06099140 add #1,r2
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[1];  // 06099142 cmp/ge r1,r2
    { const bool k = c.t; st32(c.r[9] + 12, c.r[2]); if (k) { goto L_0609917C; } }  // 06099144 bt/s 0x0609917C ; mov.l r2,@(12,r9)
    c.r[8] = (uint32_t)(int16_t)ld16(0x06099190u);  // 06099148 mov.w 0x06099190,r8
    c.r[0] = ld32(0x06099198u);  // 0609914A mov.l 0x06099198,r0
    c.r[6] = ld32(c.r[9] + 4);  // 0609914C mov.l @(4,r9),r6
    c.r[7] = c.r[8];  // 0609914E mov r8,r7
    c.r[4] = ld32(c.r[9]);  // 06099150 mov.l @r9,r4
    { const uint32_t x = c.r[0]; c.pr = 0x06099156u; c.r[5] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06099156u) return; }  // 06099152 jsr @r0 ; mov #1,r5
    c.t = c.r[0] == c.r[8];  // 06099156 cmp/eq r8,r0
    { const bool k = c.t; c.t = (int32_t)c.r[0] > 0; if (k) { goto L_06099168; } }  // 06099158 bt/s 0x06099168 ; cmp/pl r0
    { const bool k = !c.t; c.r[1] = 0xFFFFFFFFu; if (k) { goto L_06099164; } }  // 0609915C bf/s 0x06099164 ; mov #-1,r1
    st32(c.r[11], c.r[1]); goto L_0609917C;  // 06099160 bra 0x0609917C ; mov.l r1,@r11
L_06099164:
    st32(c.r[11], c.r[0]); goto L_0609917C;  // 06099164 bra 0x0609917C ; mov.l r0,@r11
L_06099168:
    st32(c.r[9] + 8, c.r[10]);  // 06099168 mov.l r10,@(8,r9)
    c.r[5] = c.r[11];  // 0609916A mov r11,r5
    { const uint32_t x = c.r[12]; c.pr = 0x06099170u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06099170u) return; }  // 0609916C jsr @r12 ; mov r9,r4
    c.r[1] = ld32(c.r[11]);  // 06099170 mov.l @r11,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06099172 tst r1,r1
    { const bool k = !c.t; c.r[10] = c.r[0] & 0xFFu; if (k) { goto L_0609917C; } }  // 06099174 bf/s 0x0609917C ; extu.b r0,r10
L_06099178:
    c.r[0] = c.r[10]; goto L_0609917E;  // 06099178 bra 0x0609917E ; mov r10,r0
L_0609917C:
    c.r[0] = 0x0u;  // 0609917C mov #0,r0
L_0609917E:
    c.r[15] = c.r[14];  // 0609917E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06099180 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06099182 mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06099184 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06099186 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06099188 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609918A mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609918C rts ; mov.l @r15+,r8
}

void f_060991A4(SH2Context& c) {
    ran[2364] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060991A4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060991A6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060991A8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060991AA mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060991AC mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060991AE mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060991B0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060991B2 sts.l pr,@-r15
    c.r[15] -= 20;  // 060991B4 add #-20,r15
    c.r[14] = c.r[15];  // 060991B6 mov r15,r14
    c.r[12] = c.r[4];  // 060991B8 mov r4,r12
    c.r[13] = c.r[5];  // 060991BA mov r5,r13
    c.r[1] = ld32(c.r[12]);  // 060991BC mov.l @r12,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060991BE tst r1,r1
    { const bool k = !c.t; c.r[11] = 0x0u; if (k) { goto L_060991C8; } }  // 060991C0 bf/s 0x060991C8 ; mov #0,r11
    c.r[13] += 8; goto L_060994E6;  // 060991C4 bra 0x060994E6 ; add #8,r13
L_060991C8:
    c.r[0] = ld32(0x060992D0u);  // 060991C8 mov.l 0x060992D0,r0
    c.r[5] = c.r[14];  // 060991CA mov r14,r5
    { const uint32_t x = c.r[0]; c.pr = 0x060991D0u; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060991D0u) return; }  // 060991CC jsr @r0 ; mov r12,r4
    c.r[2] = c.r[0];  // 060991D0 mov r0,r2
    c.r[1] = c.r[13];  // 060991D2 mov r13,r1
    c.r[1] += 8;  // 060991D4 add #8,r1
    st8(c.r[1], c.r[2]);  // 060991D6 mov.b r2,@r1
    c.r[1] = ld32(c.r[14]);  // 060991D8 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060991DA tst r1,r1
    if (c.t) { goto L_060991E2; }  // 060991DC bt 0x060991E2
    goto L_060994DC;  // 060991DE bra 0x060994DC ; nop
L_060991E2:
    c.r[1] = c.r[2] & 0xFFu;  // 060991E2 extu.b r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060991E4 tst r1,r1
    { const bool k = !c.t; c.r[0] = 0x0u; if (k) { goto L_060991EE; } }  // 060991E6 bf/s 0x060991EE ; mov #0,r0
    goto L_060994EC;  // 060991EA bra 0x060994EC ; nop
L_060991EE:
    c.r[9] = ld32(0x060992D4u);  // 060991EE mov.l 0x060992D4,r9
    c.r[5] = c.r[14];  // 060991F0 mov r14,r5
    { const uint32_t x = c.r[9]; c.pr = 0x060991F6u; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060991F6u) return; }  // 060991F2 jsr @r9 ; mov r12,r4
    c.r[1] = ld32(c.r[14]);  // 060991F6 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060991F8 tst r1,r1
    { const bool k = c.t; c.r[5] = c.r[14]; if (k) { goto L_06099202; } }  // 060991FA bt/s 0x06099202 ; mov r14,r5
    goto L_060994DC;  // 060991FE bra 0x060994DC ; nop
L_06099202:
    c.r[8] = ld32(0x060992D8u);  // 06099202 mov.l 0x060992D8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06099208u; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06099208u) return; }  // 06099204 jsr @r8 ; mov r12,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x060992CEu);  // 06099208 mov.w 0x060992CE,r1
    c.r[0] += c.r[1];  // 0609920A add r1,r0
    c.r[1] = ld32(c.r[14]);  // 0609920C mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609920E tst r1,r1
    { const bool k = c.t; st32(c.r[13], c.r[0]); if (k) { goto L_06099218; } }  // 06099210 bt/s 0x06099218 ; mov.l r0,@r13
    goto L_060994DC;  // 06099214 bra 0x060994DC ; nop
L_06099218:
    c.r[5] = c.r[14];  // 06099218 mov r14,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0609921Eu; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609921Eu) return; }  // 0609921A jsr @r8 ; mov r12,r4
    c.r[1] = ld32(c.r[14]);  // 0609921E mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06099220 tst r1,r1
    { const bool k = c.t; st32(c.r[13] + 4, c.r[0]); if (k) { goto L_0609922A; } }  // 06099222 bt/s 0x0609922A ; mov.l r0,@(4,r13)
    goto L_060994DC;  // 06099226 bra 0x060994DC ; nop
L_0609922A:
    c.r[8] = 0x0u;  // 0609922A mov #0,r8
    c.r[10] = c.r[9];  // 0609922C mov r9,r10
    c.r[9] = 0x6u;  // 0609922E mov #6,r9
    c.r[5] = c.r[14];  // 06099230 mov r14,r5
L_06099232:
    { const uint32_t x = c.r[10]; c.pr = 0x06099236u; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06099236u) return; }  // 06099232 jsr @r10 ; mov r12,r4
    c.r[0] = ld32(c.r[14]);  // 06099236 mov.l @r14,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06099238 tst r0,r0
    { const bool k = c.t; st32(c.r[14] + 16, c.r[0]); if (k) { goto L_06099242; } }  // 0609923A bt/s 0x06099242 ; mov.l r0,@(16,r14)
    goto L_060994D8;  // 0609923E bra 0x060994D8 ; nop
L_06099242:
    c.r[8] += 1;  // 06099242 add #1,r8
    c.t = (int32_t)c.r[8] > (int32_t)c.r[9];  // 06099244 cmp/gt r9,r8
    { const bool k = !c.t; c.r[5] = c.r[14]; if (k) { SH2_POLL(c); goto L_06099232; } }  // 06099246 bf/s 0x06099232 ; mov r14,r5
    c.r[8] = ld32(0x060992D4u);  // 0609924A mov.l 0x060992D4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06099250u; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06099250u) return; }  // 0609924C jsr @r8 ; mov r12,r4
    c.r[0] = c.r[0] & 0xFFu;  // 06099250 extu.b r0,r0
    c.r[1] = ld32(c.r[14]);  // 06099252 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06099254 tst r1,r1
    { const bool k = c.t; st32(c.r[14] + 8, c.r[0]); if (k) { goto L_0609925E; } }  // 06099256 bt/s 0x0609925E ; mov.l r0,@(8,r14)
    goto L_060994DC;  // 0609925A bra 0x060994DC ; nop
L_0609925E:
    c.r[5] = c.r[14];  // 0609925E mov r14,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06099264u; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06099264u) return; }  // 06099260 jsr @r8 ; mov r12,r4
    c.r[1] = c.r[13];  // 06099264 mov r13,r1
    c.r[1] += 10;  // 06099266 add #10,r1
    st8(c.r[1], c.r[0]);  // 06099268 mov.b r0,@r1
    c.r[1] = ld32(c.r[14]);  // 0609926A mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609926C tst r1,r1
    { const bool k = c.t; c.r[5] = c.r[14]; if (k) { goto L_06099276; } }  // 0609926E bt/s 0x06099276 ; mov r14,r5
    goto L_060994DC;  // 06099272 bra 0x060994DC ; nop
L_06099276:
    { const uint32_t x = c.r[8]; c.pr = 0x0609927Au; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609927Au) return; }  // 06099276 jsr @r8 ; mov r12,r4
    c.r[1] = c.r[13];  // 0609927A mov r13,r1
    c.r[1] += 11;  // 0609927C add #11,r1
    st8(c.r[1], c.r[0]);  // 0609927E mov.b r0,@r1
    c.r[1] = ld32(c.r[14]);  // 06099280 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06099282 tst r1,r1
    { const bool k = c.t; c.r[5] = c.r[14]; if (k) { goto L_0609928C; } }  // 06099284 bt/s 0x0609928C ; mov r14,r5
    goto L_060994DC;  // 06099288 bra 0x060994DC ; nop
L_0609928C:
    c.r[0] = ld32(0x060992DCu);  // 0609928C mov.l 0x060992DC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06099292u; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06099292u) return; }  // 0609928E jsr @r0 ; mov r12,r4
    c.r[1] = ld32(c.r[14]);  // 06099292 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06099294 tst r1,r1
    { const bool k = c.t; c.r[5] = c.r[14]; if (k) { goto L_0609929E; } }  // 06099296 bt/s 0x0609929E ; mov r14,r5
    goto L_060994DC;  // 0609929A bra 0x060994DC ; nop
L_0609929E:
    { const uint32_t x = c.r[8]; c.pr = 0x060992A2u; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060992A2u) return; }  // 0609929E jsr @r8 ; mov r12,r4
    c.r[1] = ld32(c.r[14]);  // 060992A2 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060992A4 tst r1,r1
    { const bool k = c.t; c.r[10] = c.r[0] & 0xFFu; if (k) { goto L_060992AE; } }  // 060992A6 bt/s 0x060992AE ; extu.b r0,r10
    goto L_060994DC;  // 060992AA bra 0x060994DC ; nop
L_060992AE:
    c.r[0] = c.r[10];  // 060992AE mov r10,r0
    c.r[0] += 33;  // 060992B0 add #33,r0
    st32(c.r[14] + 4, c.r[0]);  // 060992B2 mov.l r0,@(4,r14)
    c.r[9] = c.r[13];  // 060992B4 mov r13,r9
    c.r[9] += 12;  // 060992B6 add #12,r9
    st32(c.r[14] + 12, c.r[9]);  // 060992B8 mov.l r9,@(12,r14)
    c.r[8] = 0x0u;  // 060992BA mov #0,r8
    c.r[1] = 0x8u;  // 060992BC mov #8,r1
    c.t = c.r[10] > c.r[1];  // 060992BE cmp/hi r1,r10
    { const bool k = c.t; c.r[2] = 0x0u; if (k) { goto L_060992E0; } }  // 060992C0 bt/s 0x060992E0 ; mov #0,r2
    c.r[0] = ld32(c.r[14] + 16);  // 060992C4 mov.l @(16,r14),r0
    c.t = (int32_t)c.r[0] >= (int32_t)c.r[10]; goto L_06099316;  // 060992C6 bra 0x06099316 ; cmp/ge r10,r0
L_060992CA:
    st32(c.r[14] + 12, c.r[9]); goto L_06099318;  // 060992CA bra 0x06099318 ; mov.l r9,@(12,r14)
L_060992E0:
    c.r[1] = 0x7u;  // 060992E0 mov #7,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 060992E2 cmp/gt r1,r2
    { const bool k = c.t; c.r[0] = c.r[11]; if (k) { goto L_0609931A; } }  // 060992E4 bt/s 0x0609931A ; mov r11,r0
L_060992E8:
    c.r[0] = ld32(0x06099424u);  // 060992E8 mov.l 0x06099424,r0
    c.r[5] = c.r[14];  // 060992EA mov r14,r5
    { const uint32_t x = c.r[0]; c.pr = 0x060992F0u; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060992F0u) return; }  // 060992EC jsr @r0 ; mov r12,r4
    c.r[11] = (uint32_t)(int32_t)(int8_t)c.r[0];  // 060992F0 exts.b r0,r11
    c.r[1] = ld32(c.r[14]);  // 060992F2 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060992F4 tst r1,r1
    { const bool k = c.t; c.r[8] += 1; if (k) { goto L_060992FE; } }  // 060992F6 bt/s 0x060992FE ; add #1,r8
    goto L_060994DC;  // 060992FA bra 0x060994DC ; nop
L_060992FE:
    c.r[0] = c.r[11];  // 060992FE mov r11,r0
    c.t = c.r[0] == 0x3Bu;  // 06099300 cmp/eq #59,r0
    if (c.t) { goto L_0609931C; }  // 06099302 bt 0x0609931C
    st8(c.r[9], c.r[11]);  // 06099304 mov.b r11,@r9
    c.t = c.r[0] == 0x2Eu;  // 06099306 cmp/eq #46,r0
    { const bool k = c.t; c.r[9] += 1; if (k) { SH2_POLL(c); goto L_060992CA; } }  // 06099308 bt/s 0x060992CA ; add #1,r9
    c.r[1] = 0x8u;  // 0609930C mov #8,r1
    c.t = c.r[10] > c.r[1];  // 0609930E cmp/hi r1,r10
    { const bool k = c.t; c.r[2] = c.r[8]; if (k) { SH2_POLL(c); goto L_060992E0; } }  // 06099310 bt/s 0x060992E0 ; mov r8,r2
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[10];  // 06099314 cmp/ge r10,r8
L_06099316:
    if (!c.t) { SH2_POLL(c); goto L_060992E8; }  // 06099316 bf 0x060992E8
L_06099318:
    c.r[0] = c.r[11];  // 06099318 mov r11,r0
L_0609931A:
    c.t = c.r[0] == 0x3Bu;  // 0609931A cmp/eq #59,r0
L_0609931C:
    { const bool k = !c.t; c.t = (int32_t)c.r[8] >= (int32_t)c.r[10]; if (k) { goto L_06099348; } }  // 0609931C bf/s 0x06099348 ; cmp/ge r10,r8
    { const bool k = c.t; c.r[5] = c.r[14]; if (k) { goto L_060993DC; } }  // 06099320 bt/s 0x060993DC ; mov r14,r5
    c.r[11] = ld32(0x06099424u);  // 06099324 mov.l 0x06099424,r11
L_06099326:
    { const uint32_t x = c.r[11]; c.pr = 0x0609932Au; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609932Au) return; }  // 06099326 jsr @r11 ; mov r12,r4
    c.r[1] = ld32(c.r[14]);  // 0609932A mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609932C tst r1,r1
    { const bool k = c.t; c.r[8] += 1; if (k) { goto L_06099336; } }  // 0609932E bt/s 0x06099336 ; add #1,r8
    goto L_060994DC;  // 06099332 bra 0x060994DC ; nop
L_06099336:
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[10];  // 06099336 cmp/ge r10,r8
    { const bool k = !c.t; c.r[5] = c.r[14]; if (k) { SH2_POLL(c); goto L_06099326; } }  // 06099338 bf/s 0x06099326 ; mov r14,r5
    goto L_060993DC;  // 0609933C bra 0x060993DC ; nop
L_06099340:
    st8(c.r[9], c.r[11]);  // 06099340 mov.b r11,@r9
    c.r[9] += 1;  // 06099342 add #1,r9
    st32(c.r[14] + 12, c.r[9]); goto L_060993DA;  // 06099344 bra 0x060993DA ; mov.l r9,@(12,r14)
L_06099348:
    c.r[0] = c.r[11];  // 06099348 mov r11,r0
    c.t = c.r[0] == 0x2Eu;  // 0609934A cmp/eq #46,r0
    { const bool k = c.t; c.t = (int32_t)c.r[8] >= (int32_t)c.r[10]; if (k) { goto L_060993DC; } }  // 0609934C bt/s 0x060993DC ; cmp/ge r10,r8
    { const bool k = c.t; c.r[5] = c.r[14]; if (k) { goto L_060993DC; } }  // 06099350 bt/s 0x060993DC ; mov r14,r5
L_06099354:
    c.r[0] = ld32(0x06099424u);  // 06099354 mov.l 0x06099424,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609935Au; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609935Au) return; }  // 06099356 jsr @r0 ; mov r12,r4
    c.r[1] = c.r[0];  // 0609935A mov r0,r1
    c.r[11] = (uint32_t)(int32_t)(int8_t)c.r[1];  // 0609935C exts.b r1,r11
    c.r[1] = ld32(c.r[14]);  // 0609935E mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06099360 tst r1,r1
    { const bool k = c.t; c.r[8] += 1; if (k) { goto L_0609936A; } }  // 06099362 bt/s 0x0609936A ; add #1,r8
    goto L_060994DC;  // 06099366 bra 0x060994DC ; nop
L_0609936A:
    c.r[0] = c.r[11];  // 0609936A mov r11,r0
    c.t = c.r[0] == 0x2Eu;  // 0609936C cmp/eq #46,r0
    { const bool k = c.t; c.t = (int32_t)c.r[8] >= (int32_t)c.r[10]; if (k) { SH2_POLL(c); goto L_06099340; } }  // 0609936E bt/s 0x06099340 ; cmp/ge r10,r8
    { const bool k = !c.t; c.r[5] = c.r[14]; if (k) { SH2_POLL(c); goto L_06099354; } }  // 06099372 bf/s 0x06099354 ; mov r14,r5
    goto L_060993DC;  // 06099376 bra 0x060993DC ; nop
L_0609937A:
    c.r[0] = ld32(0x06099424u);  // 0609937A mov.l 0x06099424,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06099380u; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06099380u) return; }  // 0609937C jsr @r0 ; mov r12,r4
    c.r[1] = c.r[0];  // 06099380 mov r0,r1
    c.r[11] = (uint32_t)(int32_t)(int8_t)c.r[1];  // 06099382 exts.b r1,r11
    c.r[1] = ld32(c.r[14]);  // 06099384 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06099386 tst r1,r1
    { const bool k = c.t; c.r[8] += 1; if (k) { goto L_06099390; } }  // 06099388 bt/s 0x06099390 ; add #1,r8
    goto L_060994DC;  // 0609938C bra 0x060994DC ; nop
L_06099390:
    c.r[0] = c.r[11];  // 06099390 mov r11,r0
    c.t = c.r[0] == 0x3Bu;  // 06099392 cmp/eq #59,r0
    { const bool k = !c.t; c.t = (int32_t)c.r[8] >= (int32_t)c.r[10]; if (k) { goto L_060993BA; } }  // 06099394 bf/s 0x060993BA ; cmp/ge r10,r8
    { const bool k = c.t; c.r[2] = c.r[9]; if (k) { goto L_060993E2; } }  // 06099398 bt/s 0x060993E2 ; mov r9,r2
    c.r[5] = c.r[14];  // 0609939C mov r14,r5
L_0609939E:
    c.r[0] = ld32(0x06099424u);  // 0609939E mov.l 0x06099424,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060993A4u; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060993A4u) return; }  // 060993A0 jsr @r0 ; mov r12,r4
    c.r[1] = ld32(c.r[14]);  // 060993A4 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060993A6 tst r1,r1
    { const bool k = c.t; c.r[8] += 1; if (k) { goto L_060993B0; } }  // 060993A8 bt/s 0x060993B0 ; add #1,r8
    goto L_060994DC;  // 060993AC bra 0x060994DC ; nop
L_060993B0:
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[10];  // 060993B0 cmp/ge r10,r8
    { const bool k = !c.t; c.r[5] = c.r[14]; if (k) { SH2_POLL(c); goto L_0609939E; } }  // 060993B2 bf/s 0x0609939E ; mov r14,r5
    c.r[2] = c.r[9]; goto L_060993E2;  // 060993B6 bra 0x060993E2 ; mov r9,r2
L_060993BA:
    c.r[2] = c.r[9];  // 060993BA mov r9,r2
    c.r[0] = ld32(c.r[14] + 12);  // 060993BC mov.l @(12,r14),r0
    c.r[1] = 0x3u;  // 060993BE mov #3,r1
    c.r[2] -= c.r[0];  // 060993C0 sub r0,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 060993C2 cmp/gt r1,r2
    { const bool k = c.t; c.t = (int32_t)c.r[8] >= (int32_t)c.r[10]; if (k) { goto L_060993DC; } }  // 060993C4 bt/s 0x060993DC ; cmp/ge r10,r8
    c.r[2] = c.r[9];  // 060993C8 mov r9,r2
    c.r[2] -= 12;  // 060993CA add #-12,r2
    c.r[2] -= c.r[13];  // 060993CC sub r13,r2
    c.r[1] = 0xBu;  // 060993CE mov #11,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 060993D0 cmp/gt r1,r2
    { const bool k = c.t; c.t = (int32_t)c.r[8] >= (int32_t)c.r[10]; if (k) { goto L_060993DC; } }  // 060993D2 bt/s 0x060993DC ; cmp/ge r10,r8
    st8(c.r[9], c.r[11]);  // 060993D6 mov.b r11,@r9
    c.r[9] += 1;  // 060993D8 add #1,r9
L_060993DA:
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[10];  // 060993DA cmp/ge r10,r8
L_060993DC:
    { const bool k = !c.t; c.r[5] = c.r[14]; if (k) { SH2_POLL(c); goto L_0609937A; } }  // 060993DC bf/s 0x0609937A ; mov r14,r5
    c.r[2] = c.r[9];  // 060993E0 mov r9,r2
L_060993E2:
    c.r[2] -= 12;  // 060993E2 add #-12,r2
    c.r[2] -= c.r[13];  // 060993E4 sub r13,r2
    c.r[1] = 0xBu;  // 060993E6 mov #11,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 060993E8 cmp/gt r1,r2
    { const bool k = c.t; c.r[1] = 0x0u; if (k) { goto L_060993F0; } }  // 060993EA bt/s 0x060993F0 ; mov #0,r1
    st8(c.r[9], c.r[1]);  // 060993EE mov.b r1,@r9
L_060993F0:
    c.r[10] += 1;  // 060993F0 add #1,r10
    c.r[0] = 0x1u;  // 060993F2 mov #1,r0
    c.r[10] &= c.r[0];  // 060993F4 and r0,r10
    c.t = (c.r[10] & c.r[10]) == 0;  // 060993F6 tst r10,r10
    { const bool k = c.t; c.r[3] = c.r[13]; if (k) { goto L_06099412; } }  // 060993F8 bt/s 0x06099412 ; mov r13,r3
    c.r[0] = ld32(0x06099424u);  // 060993FC mov.l 0x06099424,r0
    c.r[5] = c.r[14];  // 060993FE mov r14,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06099404u; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06099404u) return; }  // 06099400 jsr @r0 ; mov r12,r4
    c.r[1] = ld32(c.r[14]);  // 06099404 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06099406 tst r1,r1
    { const bool k = !c.t; c.r[0] = ld32(c.r[14] + 4); if (k) { goto L_060994DC; } }  // 06099408 bf/s 0x060994DC ; mov.l @(4,r14),r0
    c.r[0] += 1;  // 0609940C add #1,r0
    st32(c.r[14] + 4, c.r[0]);  // 0609940E mov.l r0,@(4,r14)
    c.r[3] = c.r[13];  // 06099410 mov r13,r3
L_06099412:
    c.r[3] += 12;  // 06099412 add #12,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06099414 mov.b @r3,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06099416 tst r1,r1
    { const bool k = !c.t; c.r[0] = c.r[1]; if (k) { goto L_0609942C; } }  // 06099418 bf/s 0x0609942C ; mov r1,r0
    c.r[1] = ld32(0x06099428u);  // 0609941C mov.l 0x06099428,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0609941E mov.w @r1,r1
    st16(c.r[3], c.r[1]); goto L_06099440;  // 06099420 bra 0x06099440 ; mov.w r1,@r3
L_0609942C:
    c.t = c.r[0] == 0x1u;  // 0609942C cmp/eq #1,r0
    { const bool k = !c.t; c.r[9] = c.r[13]; if (k) { goto L_06099442; } }  // 0609942E bf/s 0x06099442 ; mov r13,r9
    c.r[1] = ld32(0x06099504u);  // 06099432 mov.l 0x06099504,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 06099434 mov.w @r1+,r2
    st16(c.r[3], c.r[2]);  // 06099436 mov.w r2,@r3
    c.r[2] = c.r[13];  // 06099438 mov r13,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0609943A mov.b @r1,r1
    c.r[2] += 14;  // 0609943C add #14,r2
    st8(c.r[2], c.r[1]);  // 0609943E mov.b r1,@r2
L_06099440:
    c.r[9] = c.r[13];  // 06099440 mov r13,r9
L_06099442:
    c.r[9] += 8;  // 06099442 add #8,r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06099444 mov.b @r9,r1
    c.r[0] = ld32(c.r[14] + 4);  // 06099446 mov.l @(4,r14),r0
    c.r[1] = c.r[1] & 0xFFu;  // 06099448 extu.b r1,r1
    c.t = (int32_t)c.r[0] >= (int32_t)c.r[1];  // 0609944A cmp/ge r1,r0
    { const bool k = c.t; c.r[2] = c.r[13]; if (k) { goto L_060994C8; } }  // 0609944C bt/s 0x060994C8 ; mov r13,r2
    c.r[0] = ld32(0x06099508u);  // 06099450 mov.l 0x06099508,r0
    c.r[5] = c.r[14];  // 06099452 mov r14,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06099458u; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06099458u) return; }  // 06099454 jsr @r0 ; mov r12,r4
    c.r[1] = ld32(c.r[14]);  // 06099458 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609945A tst r1,r1
    { const bool k = !c.t; c.r[5] = c.r[14]; if (k) { goto L_060994DC; } }  // 0609945C bf/s 0x060994DC ; mov r14,r5
    c.r[10] = ld32(0x0609950Cu);  // 06099460 mov.l 0x0609950C,r10
    { const uint32_t x = c.r[10]; c.pr = 0x06099466u; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06099466u) return; }  // 06099462 jsr @r10 ; mov r12,r4
    c.r[1] = c.r[13];  // 06099466 mov r13,r1
    c.r[1] += 9;  // 06099468 add #9,r1
    c.r[0] &= 0xF8u;  // 0609946A and #248,r0
    st8(c.r[1], c.r[0]);  // 0609946C mov.b r0,@r1
    c.r[1] = ld32(c.r[14]);  // 0609946E mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06099470 tst r1,r1
    { const bool k = !c.t; c.r[5] = c.r[14]; if (k) { goto L_060994DC; } }  // 06099472 bf/s 0x060994DC ; mov r14,r5
    { const uint32_t x = c.r[10]; c.pr = 0x0609947Au; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609947Au) return; }  // 06099476 jsr @r10 ; mov r12,r4
    c.r[1] = ld32(c.r[14]);  // 0609947A mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609947C tst r1,r1
    { const bool k = !c.t; c.r[5] = c.r[14]; if (k) { goto L_060994DC; } }  // 0609947E bf/s 0x060994DC ; mov r14,r5
    c.r[0] = ld32(0x06099510u);  // 06099482 mov.l 0x06099510,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06099488u; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06099488u) return; }  // 06099484 jsr @r0 ; mov r12,r4
    c.r[1] = ld32(c.r[14]);  // 06099488 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609948A tst r1,r1
    { const bool k = !c.t; c.r[5] = c.r[14]; if (k) { goto L_060994DC; } }  // 0609948C bf/s 0x060994DC ; mov r14,r5
    { const uint32_t x = c.r[10]; c.pr = 0x06099494u; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06099494u) return; }  // 06099490 jsr @r10 ; mov r12,r4
    c.r[13] += 25;  // 06099494 add #25,r13
    st8(c.r[13], c.r[0]);  // 06099496 mov.b r0,@r13
    c.r[1] = ld32(c.r[14]);  // 06099498 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609949A tst r1,r1
    { const bool k = !c.t; c.r[8] = ld32(c.r[14] + 4); if (k) { goto L_060994DC; } }  // 0609949C bf/s 0x060994DC ; mov.l @(4,r14),r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 060994A0 mov.b @r9,r1
    c.r[8] += 9;  // 060994A2 add #9,r8
    c.r[1] = c.r[1] & 0xFFu;  // 060994A4 extu.b r1,r1
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 060994A6 cmp/ge r1,r8
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_060994EC; } }  // 060994A8 bt/s 0x060994EC ; mov #0,r0
    c.r[5] = c.r[14];  // 060994AC mov r14,r5
L_060994AE:
    { const uint32_t x = c.r[10]; c.pr = 0x060994B2u; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060994B2u) return; }  // 060994AE jsr @r10 ; mov r12,r4
    c.r[1] = ld32(c.r[14]);  // 060994B2 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060994B4 tst r1,r1
    if (!c.t) { goto L_060994DC; }  // 060994B6 bf 0x060994DC
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 060994B8 mov.b @r9,r1
    c.r[8] += 1;  // 060994BA add #1,r8
    c.r[1] = c.r[1] & 0xFFu;  // 060994BC extu.b r1,r1
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 060994BE cmp/ge r1,r8
    { const bool k = !c.t; c.r[5] = c.r[14]; if (k) { SH2_POLL(c); goto L_060994AE; } }  // 060994C0 bf/s 0x060994AE ; mov r14,r5
    c.r[0] = 0x0u; goto L_060994EC;  // 060994C4 bra 0x060994EC ; mov #0,r0
L_060994C8:
    c.r[0] = ld32(c.r[14] + 8);  // 060994C8 mov.l @(8,r14),r0
    c.r[2] += 9;  // 060994CA add #9,r2
    c.r[0] &= 0x2u;  // 060994CC and #2,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060994CE tst r0,r0
    { const bool k = c.t; st32(c.r[14] + 8, c.r[0]); if (k) { goto L_060994E0; } }  // 060994D0 bt/s 0x060994E0 ; mov.l r0,@(8,r14)
    c.r[1] = 0xFFFFFF80u; goto L_060994E2;  // 060994D4 bra 0x060994E2 ; mov #-128,r1
L_060994D8:
    c.r[0] = ld32(c.r[14] + 16); goto L_060994EC;  // 060994D8 bra 0x060994EC ; mov.l @(16,r14),r0
L_060994DC:
    c.r[0] = c.r[1]; goto L_060994EC;  // 060994DC bra 0x060994EC ; mov r1,r0
L_060994E0:
    c.r[1] = 0x0u;  // 060994E0 mov #0,r1
L_060994E2:
    st8(c.r[2], c.r[1]);  // 060994E2 mov.b r1,@r2
    c.r[13] += 25;  // 060994E4 add #25,r13
L_060994E6:
    c.r[1] = 0x0u;  // 060994E6 mov #0,r1
    st8(c.r[13], c.r[1]);  // 060994E8 mov.b r1,@r13
    c.r[0] = 0x0u;  // 060994EA mov #0,r0
L_060994EC:
    c.r[14] += 20;  // 060994EC add #20,r14
    c.r[15] = c.r[14];  // 060994EE mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060994F0 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060994F2 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060994F4 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060994F6 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060994F8 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060994FA mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060994FC mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060994FE rts ; mov.l @r15+,r8
}

void f_06099514(SH2Context& c) {
    ran[2365] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06099514 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06099516 mov r15,r14
    c.r[1] = ld32(c.r[5]);  // 06099518 mov.l @r5,r1
    c.r[2] = c.r[4];  // 0609951A mov r4,r2
    st32(c.r[4], c.r[1]);  // 0609951C mov.l r1,@r4
    c.r[1] = ld32(c.r[5] + 4);  // 0609951E mov.l @(4,r5),r1
    c.r[2] += 10;  // 06099520 add #10,r2
    st32(c.r[4] + 4, c.r[1]);  // 06099522 mov.l r1,@(4,r4)
    c.r[1] = c.r[5];  // 06099524 mov r5,r1
    c.r[1] += 25;  // 06099526 add #25,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06099528 mov.b @r1,r1
    st8(c.r[2], c.r[1]);  // 0609952A mov.b r1,@r2
    c.r[2] = c.r[4];  // 0609952C mov r4,r2
    c.r[1] = c.r[5];  // 0609952E mov r5,r1
    c.r[1] += 9;  // 06099530 add #9,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06099532 mov.b @r1,r1
    c.r[2] += 11;  // 06099534 add #11,r2
    st8(c.r[2], c.r[1]);  // 06099536 mov.b r1,@r2
    c.r[2] = c.r[4];  // 06099538 mov r4,r2
    c.r[2] += 8;  // 0609953A add #8,r2
    c.r[1] = c.r[5];  // 0609953C mov r5,r1
    c.r[1] += 10;  // 0609953E add #10,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06099540 mov.b @r1,r1
    c.r[5] += 11;  // 06099542 add #11,r5
    st8(c.r[2], c.r[1]);  // 06099544 mov.b r1,@r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[5]);  // 06099546 mov.b @r5,r1
    c.r[4] += 9;  // 06099548 add #9,r4
    st8(c.r[4], c.r[1]);  // 0609954A mov.b r1,@r4
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609954C rts ; mov.l @r15+,r14
}

void f_06099580(SH2Context& c) {
    ran[2366] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06099580 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06099582 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06099584 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06099586 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06099588 mov r15,r14
    c.r[9] = c.r[4];  // 0609958A mov r4,r9
    c.r[8] = 0x0u;  // 0609958C mov #0,r8
    st32(c.r[9], c.r[8]);  // 0609958E mov.l r8,@r9
    st32(c.r[9] + 4, c.r[8]);  // 06099590 mov.l r8,@(4,r9)
    st32(c.r[9] + 8, c.r[8]);  // 06099592 mov.l r8,@(8,r9)
    st32(c.r[9] + 12, c.r[8]);  // 06099594 mov.l r8,@(12,r9)
    st32(c.r[9] + 16, c.r[8]);  // 06099596 mov.l r8,@(16,r9)
    c.r[5] = 0x1u;  // 06099598 mov #1,r5
    st32(c.r[9] + 20, c.r[5]);  // 0609959A mov.l r5,@(20,r9)
    st32(c.r[9] + 24, c.r[8]);  // 0609959C mov.l r8,@(24,r9)
    st32(c.r[9] + 28, c.r[8]);  // 0609959E mov.l r8,@(28,r9)
    c.r[1] = ld32(0x060995C0u);  // 060995A0 mov.l 0x060995C0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060995A6u; st32(c.r[9] + 32, c.r[8]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060995A6u) return; }  // 060995A2 jsr @r1 ; mov.l r8,@(32,r9)
    st32(c.r[9] + 52, c.r[8]);  // 060995A6 mov.l r8,@(52,r9)
    c.r[0] = ld32(0x060995C4u);  // 060995A8 mov.l 0x060995C4,r0
    c.r[5] = 0x3u;  // 060995AA mov #3,r5
    { const uint32_t x = c.r[0]; c.pr = 0x060995B0u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060995B0u) return; }  // 060995AC jsr @r0 ; mov r9,r4
    c.r[15] = c.r[14];  // 060995B0 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060995B2 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060995B4 mov.l @r15+,r14
    c.r[0] = c.r[9];  // 060995B6 mov r9,r0
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060995B8 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060995BA rts ; mov.l @r15+,r8
}

void f_060995C8(SH2Context& c) {
    ran[2367] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060995C8 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 060995CA mov r15,r14
    c.r[1] = 0x0u;  // 060995CC mov #0,r1
    st32(c.r[4] + 36, c.r[1]);  // 060995CE mov.l r1,@(36,r4)
    st32(c.r[4] + 40, c.r[1]);  // 060995D0 mov.l r1,@(40,r4)
    c.r[0] = ld32(c.r[4] + 56);  // 060995D2 mov.l @(56,r4),r0
    st32(c.r[4] + 56, c.r[5]);  // 060995D4 mov.l r5,@(56,r4)
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060995D6 rts ; mov.l @r15+,r14
}

void f_060995DC(SH2Context& c) {
    ran[2368] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060995DC mov.l r14,@-r15
    c.r[14] = c.r[15];  // 060995DE mov r15,r14
    st32(c.r[4] + 44, c.r[5]);  // 060995E0 mov.l r5,@(44,r4)
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060995E2 rts ; mov.l @r15+,r14
}

void f_060995E8(SH2Context& c) {
    ran[2369] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060995E8 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 060995EA mov r15,r14
    st32(c.r[4] + 24, c.r[5]);  // 060995EC mov.l r5,@(24,r4)
    c.r[1] = 0x0u;  // 060995EE mov #0,r1
    c.r[0] = ld32(c.r[4] + 52);  // 060995F0 mov.l @(52,r4),r0
    c.t = c.r[0] == 0x6u;  // 060995F2 cmp/eq #6,r0
    { const bool k = !c.t; st32(c.r[4] + 28, c.r[1]); if (k) { goto L_06099614; } }  // 060995F4 bf/s 0x06099614 ; mov.l r1,@(28,r4)
    st32(c.r[4] + 52, c.r[1]);  // 060995F8 mov.l r1,@(52,r4)
    c.r[0] = ld32(c.r[4] + 56);  // 060995FA mov.l @(56,r4),r0
    c.r[1] = 0x1u;  // 060995FC mov #1,r1
    c.r[2] = c.r[0];  // 060995FE mov r0,r2
    c.r[2] -= 1;  // 06099600 add #-1,r2
    c.t = c.r[2] > c.r[1];  // 06099602 cmp/hi r1,r2
    { const bool k = !c.t; c.t = c.r[0] == 0x3u; if (k) { goto L_0609960A; } }  // 06099604 bf/s 0x0609960A ; cmp/eq #3,r0
    if (!c.t) { goto L_06099614; }  // 06099608 bf 0x06099614
L_0609960A:
    c.r[1] = ld32(c.r[4] + 8);  // 0609960A mov.l @(8,r4),r1
    c.r[1] += 3;  // 0609960C add #3,r1
    c.r[1] >>= 2;  // 0609960E shlr2 r1
    c.r[1] <<= 2;  // 06099610 shll2 r1
    st32(c.r[4] + 8, c.r[1]);  // 06099612 mov.l r1,@(8,r4)
L_06099614:
    c.r[15] = c.r[14];  // 06099614 mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06099616 rts ; mov.l @r15+,r14
}

void f_0609961C(SH2Context& c) {
    ran[2370] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609961C mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0609961E mov r15,r14
    c.r[0] = ld32(c.r[4] + 24);  // 06099620 mov.l @(24,r4),r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06099622 rts ; mov.l @r15+,r14
}

void f_06099628(SH2Context& c) {
    ran[2371] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06099628 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0609962A mov r15,r14
    c.r[0] = ld32(c.r[4] + 28);  // 0609962C mov.l @(28,r4),r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609962E rts ; mov.l @r15+,r14
}

void f_06099634(SH2Context& c) {
    ran[2372] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06099634 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06099636 mov r15,r14
    c.r[0] = ld32(c.r[4] + 20);  // 06099638 mov.l @(20,r4),r0
    st32(c.r[4] + 20, c.r[5]);  // 0609963A mov.l r5,@(20,r4)
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609963C rts ; mov.l @r15+,r14
}

void f_06099640(SH2Context& c) {
    ran[2373] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06099640 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06099642 mov r15,r14
    c.r[1] = 0x1u;  // 06099644 mov #1,r1
    st32(c.r[4] + 48, c.r[1]);  // 06099646 mov.l r1,@(48,r4)
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06099648 rts ; mov.l @r15+,r14
}

void f_0609964C(SH2Context& c) {
    ran[2374] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609964C mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0609964E mov r15,r14
    c.r[1] = 0x0u;  // 06099650 mov #0,r1
    st32(c.r[4] + 48, c.r[1]);  // 06099652 mov.l r1,@(48,r4)
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06099654 rts ; mov.l @r15+,r14
}

void f_06099658(SH2Context& c) {
    ran[2375] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06099658 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609965A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0609965C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0609965E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06099660 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06099662 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06099664 sts.l pr,@-r15
    c.r[15] -= 4;  // 06099666 add #-4,r15
    c.r[14] = c.r[15];  // 06099668 mov r15,r14
    c.r[10] = c.r[4];  // 0609966A mov r4,r10
    c.r[8] = c.r[10];  // 0609966C mov r10,r8
    c.r[8] += 108;  // 0609966E add #108,r8
    c.r[1] = ld32(0x060996F8u);  // 06099670 mov.l 0x060996F8,r1
    c.r[2] = ld32(c.r[1]);  // 06099672 mov.l @r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x060996F6u);  // 06099674 mov.w 0x060996F6,r3
    c.r[1] = 0x0u;  // 06099676 mov #0,r1
    c.r[0] = c.r[2];  // 06099678 mov r2,r0
    st32(c.r[0] + c.r[3], c.r[1]);  // 0609967A mov.l r1,@(r0,r3)
    c.r[1] = ld32(c.r[8] + 52);  // 0609967C mov.l @(52,r8),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609967E tst r1,r1
    { const bool k = c.t; c.r[12] = c.r[5]; if (k) { goto L_060996B0; } }  // 06099680 bt/s 0x060996B0 ; mov r5,r12
    c.r[11] = ld32(0x060996FCu);  // 06099684 mov.l 0x060996FC,r11
    c.r[9] = c.r[3];  // 06099686 mov r3,r9
L_06099688:
    c.r[2] = ld32(c.r[8] + 52);  // 06099688 mov.l @(52,r8),r2
    c.r[1] = 0x1u;  // 0609968A mov #1,r1
    c.r[2] -= 6;  // 0609968C add #-6,r2
    c.t = c.r[2] > c.r[1];  // 0609968E cmp/hi r1,r2
    { const bool k = !c.t; c.r[5] = c.r[14]; if (k) { goto L_060996B0; } }  // 06099690 bf/s 0x060996B0 ; mov r14,r5
    { const uint32_t x = c.r[11]; c.pr = 0x06099698u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06099698u) return; }  // 06099694 jsr @r11 ; mov r10,r4
    c.r[1] = ld32(0x060996F8u);  // 06099698 mov.l 0x060996F8,r1
    c.r[1] = ld32(c.r[1]);  // 0609969A mov.l @r1,r1
    c.r[0] = c.r[1];  // 0609969C mov r1,r0
    c.r[2] = ld32(c.r[0] + c.r[9]);  // 0609969E mov.l @(r0,r9),r2
    c.r[2] += 1;  // 060996A0 add #1,r2
    c.r[1] = ld32(0x06099700u);  // 060996A2 mov.l 0x06099700,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 060996A4 cmp/gt r1,r2
    { const bool k = c.t; st32(c.r[0] + c.r[9], c.r[2]); if (k) { goto L_060996B0; } }  // 060996A6 bt/s 0x060996B0 ; mov.l r2,@(r0,r9)
    c.r[1] = ld32(c.r[8] + 52);  // 060996AA mov.l @(52,r8),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060996AC tst r1,r1
    if (!c.t) { SH2_POLL(c); goto L_06099688; }  // 060996AE bf 0x06099688
L_060996B0:
    c.r[5] = ld32(c.r[8] + 12);  // 060996B0 mov.l @(12,r8),r5
    c.t = (c.r[5] & c.r[5]) == 0;  // 060996B2 tst r5,r5
    { const bool k = c.t; c.r[6] = c.r[12]; if (k) { goto L_060996CC; } }  // 060996B4 bt/s 0x060996CC ; mov r12,r6
    c.r[1] = ld32(0x06099704u);  // 060996B8 mov.l 0x06099704,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060996BEu; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060996BEu) return; }  // 060996BA jsr @r1 ; mov r10,r4
    c.r[1] = ld32(c.r[8] + 12);  // 060996BE mov.l @(12,r8),r1
    c.r[2] = ld32(c.r[8] + 28);  // 060996C0 mov.l @(28,r8),r2
    c.r[1] = ld32(c.r[1] + 12);  // 060996C2 mov.l @(12,r1),r1
    c.r[2] += c.r[1];  // 060996C4 add r1,r2
    st32(c.r[8] + 28, c.r[2]);  // 060996C6 mov.l r2,@(28,r8)
    c.r[1] = 0x0u;  // 060996C8 mov #0,r1
    st32(c.r[8] + 12, c.r[1]);  // 060996CA mov.l r1,@(12,r8)
L_060996CC:
    c.r[5] = ld32(c.r[8] + 16);  // 060996CC mov.l @(16,r8),r5
    c.t = (c.r[5] & c.r[5]) == 0;  // 060996CE tst r5,r5
    { const bool k = c.t; c.r[1] = 0x6u; if (k) { goto L_060996E0; } }  // 060996D0 bt/s 0x060996E0 ; mov #6,r1
    c.r[1] = ld32(0x06099708u);  // 060996D4 mov.l 0x06099708,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060996DAu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060996DAu) return; }  // 060996D6 jsr @r1 ; mov r8,r4
    c.r[1] = 0x0u;  // 060996DA mov #0,r1
    st32(c.r[8] + 16, c.r[1]);  // 060996DC mov.l r1,@(16,r8)
    c.r[1] = 0x6u;  // 060996DE mov #6,r1
L_060996E0:
    st32(c.r[8] + 52, c.r[1]);  // 060996E0 mov.l r1,@(52,r8)
    c.r[14] += 4;  // 060996E2 add #4,r14
    c.r[15] = c.r[14];  // 060996E4 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060996E6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060996E8 mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060996EA mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060996EC mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060996EE mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060996F0 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060996F2 rts ; mov.l @r15+,r8
}

void f_0609970C(SH2Context& c) {
    ran[2376] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609970C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609970E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06099710 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06099712 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06099714 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06099716 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06099718 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0609971A mov r15,r14
    c.r[10] = c.r[4];  // 0609971C mov r4,r10
    c.r[12] = c.r[5];  // 0609971E mov r5,r12
    c.r[7] = c.r[10];  // 06099720 mov r10,r7
    c.r[7] += 108;  // 06099722 add #108,r7
    c.r[3] = ld32(c.r[7] + 56);  // 06099724 mov.l @(56,r7),r3
    c.r[1] = 0x4u;  // 06099726 mov #4,r1
    c.t = c.r[3] > c.r[1];  // 06099728 cmp/hi r1,r3
    { const bool k = c.t; c.r[2] = 0x6u; if (k) { goto L_06099752; } }  // 0609972A bt/s 0x06099752 ; mov #6,r2
    c.r[1] = c.r[3];  // 0609972E mov r3,r1
    c.r[1] += c.r[1];  // 06099730 add r1,r1
    c.r[0] = 0x0609973Cu;  // 06099732 mova 0x0609973C,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06099734 mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 06099736 add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x06099746u: goto L_06099746; case 0x06099752u: goto L_06099752; default: sh2_call(c, x); return; } }  // 06099738 jmp @r0 ; nop
L_06099746:
    c.r[1] = ld32(c.r[7] + 52);  // 06099746 mov.l @(52,r7),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06099748 tst r1,r1
    { const bool k = c.t; c.r[9] = 0x1u; if (k) { goto L_06099754; } }  // 0609974A bt/s 0x06099754 ; mov #1,r9
    c.r[9] = 0x2u; goto L_06099754;  // 0609974E bra 0x06099754 ; mov #2,r9
L_06099752:
    c.r[9] = 0x1u;  // 06099752 mov #1,r9
L_06099754:
    c.r[8] = 0x0u;  // 06099754 mov #0,r8
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[9];  // 06099756 cmp/ge r9,r8
    { const bool k = c.t; c.r[5] = c.r[12]; if (k) { goto L_06099778; } }  // 06099758 bt/s 0x06099778 ; mov r12,r5
    c.r[11] = ld32(0x0609978Cu);  // 0609975C mov.l 0x0609978C,r11
L_0609975E:
    { const uint32_t x = c.r[11]; c.pr = 0x06099762u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06099762u) return; }  // 0609975E jsr @r11 ; mov r10,r4
    c.t = c.r[0] == 0x7u;  // 06099762 cmp/eq #7,r0
    { const bool k = c.t; c.r[2] = c.r[0]; if (k) { goto L_06099778; } }  // 06099764 bt/s 0x06099778 ; mov r0,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06099768 tst r2,r2
    { const bool k = c.t; c.t = c.r[0] == 0x6u; if (k) { goto L_06099770; } }  // 0609976A bt/s 0x06099770 ; cmp/eq #6,r0
    if (!c.t) { goto L_06099778; }  // 0609976E bf 0x06099778
L_06099770:
    c.r[8] += 1;  // 06099770 add #1,r8
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[9];  // 06099772 cmp/ge r9,r8
    { const bool k = !c.t; c.r[5] = c.r[12]; if (k) { SH2_POLL(c); goto L_0609975E; } }  // 06099774 bf/s 0x0609975E ; mov r12,r5
L_06099778:
    c.r[15] = c.r[14];  // 06099778 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609977A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609977C mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0609977E mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06099780 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06099782 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06099784 mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06099786 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.r[0] = c.r[2]; c.pc = x; return; }  // 06099788 rts ; mov r2,r0
}

void f_06099790(SH2Context& c) {
    ran[2377] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06099790 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06099792 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06099794 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06099796 sts.l pr,@-r15
    c.r[9] = c.r[4];  // 06099798 mov r4,r9
    c.r[8] = c.r[9];  // 0609979A mov r9,r8
    c.r[8] += 108;  // 0609979C add #108,r8
    c.r[1] = ld32(c.r[8] + 24);  // 0609979E mov.l @(24,r8),r1
    c.t = (int32_t)c.r[1] > 0;  // 060997A0 cmp/pl r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_060997AA; } }  // 060997A2 bt/s 0x060997AA ; mov r15,r14
    c.r[0] = 0x6u; goto L_060997FA;  // 060997A6 bra 0x060997FA ; mov #6,r0
L_060997AA:
    c.r[1] = ld32(c.r[8] + 48);  // 060997AA mov.l @(48,r8),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060997AC tst r1,r1
    if (c.t) { goto L_060997F8; }  // 060997AE bt 0x060997F8
    c.r[0] = ld32(c.r[8] + 52);  // 060997B0 mov.l @(52,r8),r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060997B2 tst r0,r0
    { const bool k = c.t; c.t = c.r[0] == 0x5u; if (k) { goto L_060997C0; } }  // 060997B4 bt/s 0x060997C0 ; cmp/eq #5,r0
    if (c.t) { goto L_060997D0; }  // 060997B8 bt 0x060997D0
    c.r[15] = c.r[14];  // 060997BA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; } goto L_060997FE;  // 060997BC bra 0x060997FE ; lds.l @r15+,pr
L_060997C0:
    c.r[1] = ld32(0x06099808u);  // 060997C0 mov.l 0x06099808,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060997C6u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060997C6u) return; }  // 060997C2 jsr @r1 ; mov r9,r4
    c.r[1] = ld32(c.r[8] + 12);  // 060997C6 mov.l @(12,r8),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060997C8 tst r1,r1
    { const bool k = c.t; c.r[1] = 0x5u; if (k) { goto L_060997F8; } }  // 060997CA bt/s 0x060997F8 ; mov #5,r1
    st32(c.r[8] + 52, c.r[1]);  // 060997CE mov.l r1,@(52,r8)
L_060997D0:
    c.r[1] = ld32(0x0609980Cu);  // 060997D0 mov.l 0x0609980C,r1
    c.r[6] = 0xFFFFFFFFu;  // 060997D2 mov #-1,r6
    c.r[5] = ld32(c.r[8] + 12);  // 060997D4 mov.l @(12,r8),r5
    { const uint32_t x = c.r[1]; c.pr = 0x060997DAu; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060997DAu) return; }  // 060997D6 jsr @r1 ; mov r9,r4
    c.r[1] = ld32(c.r[8] + 12);  // 060997DA mov.l @(12,r8),r1
    c.r[2] = ld32(c.r[8] + 28);  // 060997DC mov.l @(28,r8),r2
    c.r[1] = ld32(c.r[1] + 12);  // 060997DE mov.l @(12,r1),r1
    c.r[2] += c.r[1];  // 060997E0 add r1,r2
    st32(c.r[8] + 28, c.r[2]);  // 060997E2 mov.l r2,@(28,r8)
    c.r[2] = ld32(c.r[8] + 28);  // 060997E4 mov.l @(28,r8),r2
    c.r[3] = 0x0u;  // 060997E6 mov #0,r3
    c.r[1] = ld32(c.r[8] + 24);  // 060997E8 mov.l @(24,r8),r1
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[1];  // 060997EA cmp/ge r1,r2
    { const bool k = !c.t; st32(c.r[8] + 12, c.r[3]); if (k) { goto L_060997F6; } }  // 060997EC bf/s 0x060997F6 ; mov.l r3,@(12,r8)
    c.r[1] = 0x6u;  // 060997F0 mov #6,r1
    st32(c.r[8] + 52, c.r[1]); goto L_060997F8;  // 060997F2 bra 0x060997F8 ; mov.l r1,@(52,r8)
L_060997F6:
    st32(c.r[8] + 52, c.r[3]);  // 060997F6 mov.l r3,@(52,r8)
L_060997F8:
    c.r[0] = ld32(c.r[8] + 52);  // 060997F8 mov.l @(52,r8),r0
L_060997FA:
    c.r[15] = c.r[14];  // 060997FA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060997FC lds.l @r15+,pr
L_060997FE:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060997FE mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06099800 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06099802 rts ; mov.l @r15+,r8
}

void f_06099810(SH2Context& c) {
    ran[2378] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06099810 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06099812 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06099814 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06099816 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06099818 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609981A sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0609981C mov r15,r14
    c.r[9] = c.r[4];  // 0609981E mov r4,r9
    c.r[11] = c.r[5];  // 06099820 mov r5,r11
    c.r[8] = c.r[9];  // 06099822 mov r9,r8
    c.r[8] += 108;  // 06099824 add #108,r8
    c.r[1] = ld32(c.r[8] + 24);  // 06099826 mov.l @(24,r8),r1
    c.t = (int32_t)c.r[1] > 0;  // 06099828 cmp/pl r1
    { const bool k = c.t; c.r[10] = 0x0u; if (k) { goto L_06099834; } }  // 0609982A bt/s 0x06099834 ; mov #0,r10
    st32(c.r[11], c.r[10]);  // 0609982E mov.l r10,@r11
    c.r[0] = 0x6u; goto L_060998E8;  // 06099830 bra 0x060998E8 ; mov #6,r0
L_06099834:
    c.r[1] = ld32(c.r[8] + 48);  // 06099834 mov.l @(48,r8),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06099836 tst r1,r1
    if (c.t) { goto L_060998E4; }  // 06099838 bt 0x060998E4
    c.r[2] = ld32(c.r[8] + 52);  // 0609983A mov.l @(52,r8),r2
    c.r[1] = 0x5u;  // 0609983C mov #5,r1
    c.t = c.r[2] > c.r[1];  // 0609983E cmp/hi r1,r2
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_060998E4; } }  // 06099840 bt/s 0x060998E4 ; mov r2,r1
    c.r[1] += c.r[1];  // 06099844 add r1,r1
    c.r[0] = 0x06099850u;  // 06099846 mova 0x06099850,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06099848 mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 0609984A add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x0609985Cu: goto L_0609985C; case 0x0609986Cu: goto L_0609986C; case 0x0609987Cu: goto L_0609987C; case 0x0609988Au: goto L_0609988A; case 0x06099898u: goto L_06099898; case 0x060998A8u: goto L_060998A8; default: sh2_call(c, x); return; } }  // 0609984C jmp @r0 ; nop
L_0609985C:
    c.r[1] = ld32(0x060998F8u);  // 0609985C mov.l 0x060998F8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06099862u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06099862u) return; }  // 0609985E jsr @r1 ; mov r9,r4
    c.r[1] = ld32(c.r[8] + 12);  // 06099862 mov.l @(12,r8),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06099864 tst r1,r1
    { const bool k = c.t; c.r[1] = 0x1u; if (k) { goto L_060998E4; } }  // 06099866 bt/s 0x060998E4 ; mov #1,r1
    st32(c.r[8] + 52, c.r[1]);  // 0609986A mov.l r1,@(52,r8)
L_0609986C:
    c.r[1] = ld32(0x060998FCu);  // 0609986C mov.l 0x060998FC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06099872u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06099872u) return; }  // 0609986E jsr @r1 ; mov r8,r4
    c.r[1] = ld32(c.r[8] + 16);  // 06099872 mov.l @(16,r8),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06099874 tst r1,r1
    { const bool k = c.t; c.r[1] = 0x2u; if (k) { goto L_060998E4; } }  // 06099876 bt/s 0x060998E4 ; mov #2,r1
    st32(c.r[8] + 52, c.r[1]);  // 0609987A mov.l r1,@(52,r8)
L_0609987C:
    c.r[0] = ld32(0x06099900u);  // 0609987C mov.l 0x06099900,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06099882u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06099882u) return; }  // 0609987E jsr @r0 ; mov r8,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 06099882 tst r0,r0
    { const bool k = c.t; c.r[1] = 0x3u; if (k) { goto L_060998E4; } }  // 06099884 bt/s 0x060998E4 ; mov #3,r1
    st32(c.r[8] + 52, c.r[1]);  // 06099888 mov.l r1,@(52,r8)
L_0609988A:
    c.r[0] = ld32(0x06099904u);  // 0609988A mov.l 0x06099904,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06099890u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06099890u) return; }  // 0609988C jsr @r0 ; mov r9,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 06099890 tst r0,r0
    { const bool k = c.t; c.r[1] = 0x4u; if (k) { goto L_060998E4; } }  // 06099892 bt/s 0x060998E4 ; mov #4,r1
    st32(c.r[8] + 52, c.r[1]);  // 06099896 mov.l r1,@(52,r8)
L_06099898:
    c.r[0] = ld32(0x06099908u);  // 06099898 mov.l 0x06099908,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609989Eu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609989Eu) return; }  // 0609989A jsr @r0 ; mov r8,r4
    c.t = (int32_t)c.r[0] > 0;  // 0609989E cmp/pl r0
    if (c.t) { goto L_060998E4; }  // 060998A0 bt 0x060998E4
    c.r[10] = 0x1u;  // 060998A2 mov #1,r10
    c.r[1] = 0x5u;  // 060998A4 mov #5,r1
    st32(c.r[8] + 52, c.r[1]);  // 060998A6 mov.l r1,@(52,r8)
L_060998A8:
    c.r[5] = ld32(c.r[8] + 12);  // 060998A8 mov.l @(12,r8),r5
    c.r[2] = ld32(c.r[8] + 32);  // 060998AA mov.l @(32,r8),r2
    c.r[1] = ld32(c.r[5] + 8);  // 060998AC mov.l @(8,r5),r1
    c.t = c.r[2] == c.r[1];  // 060998AE cmp/eq r1,r2
    { const bool k = !c.t; c.r[6] = 0xFFFFFFFFu; if (k) { goto L_060998C8; } }  // 060998B0 bf/s 0x060998C8 ; mov #-1,r6
    c.r[1] = ld32(0x0609990Cu);  // 060998B4 mov.l 0x0609990C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060998BAu; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060998BAu) return; }  // 060998B6 jsr @r1 ; mov r9,r4
    c.r[1] = ld32(c.r[8] + 12);  // 060998BA mov.l @(12,r8),r1
    c.r[2] = ld32(c.r[8] + 28);  // 060998BC mov.l @(28,r8),r2
    c.r[1] = ld32(c.r[1] + 12);  // 060998BE mov.l @(12,r1),r1
    c.r[2] += c.r[1];  // 060998C0 add r1,r2
    st32(c.r[8] + 28, c.r[2]);  // 060998C2 mov.l r2,@(28,r8)
    c.r[1] = 0x0u;  // 060998C4 mov #0,r1
    st32(c.r[8] + 12, c.r[1]);  // 060998C6 mov.l r1,@(12,r8)
L_060998C8:
    c.r[1] = ld32(0x06099910u);  // 060998C8 mov.l 0x06099910,r1
    c.r[5] = ld32(c.r[8] + 16);  // 060998CA mov.l @(16,r8),r5
    { const uint32_t x = c.r[1]; c.pr = 0x060998D0u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060998D0u) return; }  // 060998CC jsr @r1 ; mov r8,r4
    c.r[2] = ld32(c.r[8] + 28);  // 060998D0 mov.l @(28,r8),r2
    c.r[3] = 0x0u;  // 060998D2 mov #0,r3
    c.r[1] = ld32(c.r[8] + 24);  // 060998D4 mov.l @(24,r8),r1
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[1];  // 060998D6 cmp/ge r1,r2
    { const bool k = !c.t; st32(c.r[8] + 16, c.r[3]); if (k) { goto L_060998E2; } }  // 060998D8 bf/s 0x060998E2 ; mov.l r3,@(16,r8)
    c.r[1] = 0x6u;  // 060998DC mov #6,r1
    st32(c.r[8] + 52, c.r[1]); goto L_060998E4;  // 060998DE bra 0x060998E4 ; mov.l r1,@(52,r8)
L_060998E2:
    st32(c.r[8] + 52, c.r[3]);  // 060998E2 mov.l r3,@(52,r8)
L_060998E4:
    st32(c.r[11], c.r[10]);  // 060998E4 mov.l r10,@r11
    c.r[0] = ld32(c.r[8] + 52);  // 060998E6 mov.l @(52,r8),r0
L_060998E8:
    c.r[15] = c.r[14];  // 060998E8 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060998EA lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060998EC mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060998EE mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060998F0 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060998F2 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060998F4 rts ; mov.l @r15+,r8
}

void f_06099914(SH2Context& c) {
    ran[2379] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06099914 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06099916 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06099918 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0609991A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609991C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609991E sts.l pr,@-r15
    c.r[11] = c.r[4];  // 06099920 mov r4,r11
    c.r[8] = c.r[11];  // 06099922 mov r11,r8
    c.r[8] += 108;  // 06099924 add #108,r8
    c.r[9] = ld32(c.r[8] + 24);  // 06099926 mov.l @(24,r8),r9
    c.r[1] = ld32(c.r[8] + 28);  // 06099928 mov.l @(28,r8),r1
    c.r[9] -= c.r[1];  // 0609992A sub r1,r9
    c.r[1] = ld32(c.r[8] + 20);  // 0609992C mov.l @(20,r8),r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 0609992E cmp/gt r1,r9
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_06099936; } }  // 06099930 bf/s 0x06099936 ; mov r15,r14
    c.r[9] = c.r[1];  // 06099934 mov r1,r9
L_06099936:
    c.r[5] = ld32(c.r[8] + 44);  // 06099936 mov.l @(44,r8),r5
    c.r[1] = 0x1u;  // 06099938 mov #1,r1
    c.t = (int32_t)c.r[5] > (int32_t)c.r[1];  // 0609993A cmp/gt r1,r5
    if (!c.t) { goto L_06099968; }  // 0609993C bf 0x06099968
    c.r[1] = ld32(c.r[8] + 12);  // 0609993E mov.l @(12,r8),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06099940 tst r1,r1
    if (c.t) { goto L_06099950; }  // 06099942 bt 0x06099950
    c.r[4] = ld32(c.r[1] + 8);  // 06099944 mov.l @(8,r1),r4
    c.r[1] = ld32(c.r[8] + 32);  // 06099946 mov.l @(32,r8),r1
    c.r[7] = ld32(0x06099990u);  // 06099948 mov.l 0x06099990,r7
    { const uint32_t x = c.r[7]; c.pr = 0x0609994Eu; c.r[4] -= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609994Eu) return; }  // 0609994A jsr @r7 ; sub r1,r4
    c.r[9] = c.r[0];  // 0609994E mov r0,r9
L_06099950:
    c.r[0] = ld32(0x06099994u);  // 06099950 mov.l 0x06099994,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06099956u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06099956u) return; }  // 06099952 jsr @r0 ; mov r8,r4
    c.r[1] = c.r[0];  // 06099956 mov r0,r1
    c.r[5] = ld32(c.r[8] + 44);  // 06099958 mov.l @(44,r8),r5
    c.r[7] = ld32(0x06099990u);  // 0609995A mov.l 0x06099990,r7
    { const uint32_t x = c.r[7]; c.pr = 0x06099960u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06099960u) return; }  // 0609995C jsr @r7 ; mov r1,r4
    c.r[7] = c.r[0];  // 06099960 mov r0,r7
    c.t = (int32_t)c.r[9] > (int32_t)c.r[7];  // 06099962 cmp/gt r7,r9
    if (!c.t) { goto L_06099968; }  // 06099964 bf 0x06099968
    c.r[9] = c.r[7];  // 06099966 mov r7,r9
L_06099968:
    c.r[10] = ld32(c.r[8] + 12);  // 06099968 mov.l @(12,r8),r10
    c.t = (c.r[10] & c.r[10]) == 0;  // 0609996A tst r10,r10
    { const bool k = !c.t; c.r[5] = c.r[9]; if (k) { goto L_0609997E; } }  // 0609996C bf/s 0x0609997E ; mov r9,r5
    c.r[0] = ld32(0x06099998u);  // 06099970 mov.l 0x06099998,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06099976u; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06099976u) return; }  // 06099972 jsr @r0 ; mov r11,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 06099976 tst r0,r0
    { const bool k = c.t; st32(c.r[8] + 12, c.r[0]); if (k) { goto L_0609997E; } }  // 06099978 bt/s 0x0609997E ; mov.l r0,@(12,r8)
    st32(c.r[8] + 32, c.r[10]);  // 0609997C mov.l r10,@(32,r8)
L_0609997E:
    c.r[15] = c.r[14];  // 0609997E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06099980 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06099982 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06099984 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06099986 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06099988 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609998A rts ; mov.l @r15+,r8
}

void f_0609999C(SH2Context& c) {
    ran[2380] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609999C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609999E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060999A0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060999A2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060999A4 sts.l pr,@-r15
    c.r[9] = c.r[4];  // 060999A6 mov r4,r9
    c.r[2] = ld32(c.r[9] + 44);  // 060999A8 mov.l @(44,r9),r2
    c.r[1] = 0x1u;  // 060999AA mov #1,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 060999AC cmp/gt r1,r2
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_060999B8; } }  // 060999AE bf/s 0x060999B8 ; mov r15,r14
    c.r[1] = ld32(c.r[9] + 12);  // 060999B2 mov.l @(12,r9),r1
    c.r[8] = ld32(c.r[1] + 8); goto L_060999D6;  // 060999B4 bra 0x060999D6 ; mov.l @(8,r1),r8
L_060999B8:
    c.r[1] = ld32(c.r[9] + 12);  // 060999B8 mov.l @(12,r9),r1
    c.r[8] = ld32(c.r[1] + 8);  // 060999BA mov.l @(8,r1),r8
    c.r[10] = ld32(0x060999F0u);  // 060999BC mov.l 0x060999F0,r10
    c.r[1] = ld32(c.r[9] + 32);  // 060999BE mov.l @(32,r9),r1
    c.r[4] = c.r[9];  // 060999C0 mov r9,r4
    { const uint32_t x = c.r[10]; c.pr = 0x060999C6u; c.r[8] -= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060999C6u) return; }  // 060999C2 jsr @r10 ; sub r1,r8
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[0];  // 060999C6 cmp/ge r0,r8
    { const bool k = !c.t; c.r[0] = c.r[8]; if (k) { goto L_060999D4; } }  // 060999C8 bf/s 0x060999D4 ; mov r8,r0
    { const uint32_t x = c.r[10]; c.pr = 0x060999D0u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060999D0u) return; }  // 060999CC jsr @r10 ; mov r9,r4
    c.r[8] = c.r[0]; goto L_060999D6;  // 060999D0 bra 0x060999D6 ; mov r0,r8
L_060999D4:
    c.r[8] = c.r[0];  // 060999D4 mov r0,r8
L_060999D6:
    c.r[0] = ld32(0x060999F4u);  // 060999D6 mov.l 0x060999F4,r0
    c.r[5] = c.r[8];  // 060999D8 mov r8,r5
    { const uint32_t x = c.r[0]; c.pr = 0x060999DEu; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060999DEu) return; }  // 060999DA jsr @r0 ; mov r9,r4
    st32(c.r[9] + 16, c.r[0]);  // 060999DE mov.l r0,@(16,r9)
    c.r[15] = c.r[14];  // 060999E0 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060999E2 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060999E4 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060999E6 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060999E8 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060999EA rts ; mov.l @r15+,r8
}

void f_060999F8(SH2Context& c) {
    ran[2381] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060999F8 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 060999FA mov r15,r14
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060999FC mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 060999FE rts ; mov #1,r0
}

void f_06099A04(SH2Context& c) {
    ran[2382] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06099A04 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06099A06 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06099A08 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06099A0A sts.l pr,@-r15
    c.r[15] -= 40;  // 06099A0C add #-40,r15
    c.r[14] = c.r[15];  // 06099A0E mov r15,r14
    c.r[8] = c.r[4];  // 06099A10 mov r4,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 06099A12 tst r8,r8
    { const bool k = c.t; c.r[9] = ld32(c.r[14] + 56); if (k) { goto L_06099A74; } }  // 06099A14 bt/s 0x06099A74 ; mov.l @(56,r14),r9
    st32(c.r[14], c.r[6]);  // 06099A18 mov.l r6,@r14
    st32(c.r[14] + 4, c.r[8]);  // 06099A1A mov.l r8,@(4,r14)
    c.t = (c.r[7] & c.r[7]) == 0;  // 06099A1C tst r7,r7
    { const bool k = !c.t; st32(c.r[14] + 8, c.r[9]); if (k) { goto L_06099A26; } }  // 06099A1E bf/s 0x06099A26 ; mov.l r9,@(8,r14)
    st32(c.r[14] + 12, c.r[7]); goto L_06099A2A;  // 06099A22 bra 0x06099A2A ; mov.l r7,@(12,r14)
L_06099A26:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06099A82u);  // 06099A26 mov.w 0x06099A82,r1
    st32(c.r[14] + 12, c.r[1]);  // 06099A28 mov.l r1,@(12,r14)
L_06099A2A:
    c.t = (c.r[5] & c.r[5]) == 0;  // 06099A2A tst r5,r5
    if (!c.t) { goto L_06099A34; }  // 06099A2C bf 0x06099A34
    st32(c.r[14] + 16, c.r[5]);  // 06099A2E mov.l r5,@(16,r14)
    c.r[1] = 0x0u; goto L_06099A4A;  // 06099A30 bra 0x06099A4A ; mov #0,r1
L_06099A34:
    c.r[1] = ld32(0x06099A84u);  // 06099A34 mov.l 0x06099A84,r1
    c.r[1] &= c.r[8];  // 06099A36 and r8,r1
    c.r[2] = ld32(0x06099A88u);  // 06099A38 mov.l 0x06099A88,r2
    c.r[1] += c.r[2];  // 06099A3A add r2,r1
    c.r[2] = ld32(0x06099A8Cu);  // 06099A3C mov.l 0x06099A8C,r2
    c.t = c.r[1] > c.r[2];  // 06099A3E cmp/hi r2,r1
    { const bool k = c.t; c.r[1] = 0x2u; if (k) { goto L_06099A46; } }  // 06099A40 bt/s 0x06099A46 ; mov #2,r1
    c.r[1] = 0x1u;  // 06099A44 mov #1,r1
L_06099A46:
    st32(c.r[14] + 16, c.r[1]);  // 06099A46 mov.l r1,@(16,r14)
    c.r[1] = 0x0u;  // 06099A48 mov #0,r1
L_06099A4A:
    st32(c.r[14] + 20, c.r[1]);  // 06099A4A mov.l r1,@(20,r14)
    st32(c.r[14] + 24, c.r[1]);  // 06099A4C mov.l r1,@(24,r14)
    st32(c.r[14] + 28, c.r[1]);  // 06099A4E mov.l r1,@(28,r14)
    c.r[1] = 0x7u;  // 06099A50 mov #7,r1
    st32(c.r[14] + 32, c.r[1]);  // 06099A52 mov.l r1,@(32,r14)
    c.r[1] = 0x3u;  // 06099A54 mov #3,r1
    st32(c.r[14] + 36, c.r[1]);  // 06099A56 mov.l r1,@(36,r14)
    c.r[2] = ld32(0x06099A90u);  // 06099A58 mov.l 0x06099A90,r2
    c.r[1] = 0x1u;  // 06099A5A mov #1,r1
    st32(c.r[2], c.r[1]);  // 06099A5C mov.l r1,@r2
    c.r[1] = ld32(0x06099A94u);  // 06099A5E mov.l 0x06099A94,r1
    c.r[5] = 0x0u;  // 06099A60 mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06099A66u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06099A66u) return; }  // 06099A62 jsr @r1 ; mov r14,r4
    c.r[1] = ld32(0x06099A98u);  // 06099A66 mov.l 0x06099A98,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06099A6Cu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06099A6Cu) return; }  // 06099A68 jsr @r1 ; mov #0,r4
    c.r[0] = ld32(0x06099A9Cu);  // 06099A6C mov.l 0x06099A9C,r0
    c.r[5] = c.r[9];  // 06099A6E mov r9,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06099A74u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06099A74u) return; }  // 06099A70 jsr @r0 ; mov r8,r4
L_06099A74:
    c.r[14] += 40;  // 06099A74 add #40,r14
    c.r[15] = c.r[14];  // 06099A76 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06099A78 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06099A7A mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06099A7C mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06099A7E rts ; mov.l @r15+,r8
}

void f_06099AA0(SH2Context& c) {
    ran[2383] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06099AA0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06099AA2 sts.l pr,@-r15
    c.r[15] -= 4;  // 06099AA4 add #-4,r15
    c.r[14] = c.r[15];  // 06099AA6 mov r15,r14
    c.r[1] = ld32(0x06099AC8u);  // 06099AA8 mov.l 0x06099AC8,r1
    c.r[5] = 0x0u;  // 06099AAA mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06099AB0u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06099AB0u) return; }  // 06099AAC jsr @r1 ; mov r14,r4
    c.r[0] = ld32(c.r[14]);  // 06099AB0 mov.l @r14,r0
    c.t = c.r[0] == 0x1u;  // 06099AB2 cmp/eq #1,r0
    { const bool k = c.t; c.r[1] = 0x0u; if (k) { goto L_06099ABE; } }  // 06099AB4 bt/s 0x06099ABE ; mov #0,r1
    c.r[2] = ld32(0x06099ACCu);  // 06099AB8 mov.l 0x06099ACC,r2
    st32(c.r[2], c.r[1]);  // 06099ABA mov.l r1,@r2
    c.r[0] = 0x0u;  // 06099ABC mov #0,r0
L_06099ABE:
    c.r[14] += 4;  // 06099ABE add #4,r14
    c.r[15] = c.r[14];  // 06099AC0 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06099AC2 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06099AC4 rts ; mov.l @r15+,r14
}

void f_06099AD0(SH2Context& c) {
    ran[2384] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06099AD0 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06099AD2 mov r15,r14
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06099AD4 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 06099AD6 rts ; mov #1,r0
}

void f_06099ADC(SH2Context& c) {
    ran[2385] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06099ADC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06099ADE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06099AE0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06099AE2 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06099AE4 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06099AE6 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06099AE8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06099AEA sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06099AEC mov r15,r14
    c.r[10] = c.r[5];  // 06099AEE mov r5,r10
    c.r[12] = c.r[6];  // 06099AF0 mov r6,r12
    c.r[8] = ld32(c.r[14] + 36);  // 06099AF2 mov.l @(36,r14),r8
    c.r[11] = c.r[7];  // 06099AF4 mov r7,r11
    c.r[9] = c.r[8];  // 06099AF6 mov r8,r9
    c.r[9] >>= 2;  // 06099AF8 shlr2 r9
    c.t = (int32_t)c.r[9] > 0;  // 06099AFA cmp/pl r9
    { const bool k = !c.t; c.r[13] = ld32(c.r[14] + 32); if (k) { goto L_06099B12; } }  // 06099AFC bf/s 0x06099B12 ; mov.l @(32,r14),r13
    c.t = (c.r[13] & c.r[13]) == 0;  // 06099B00 tst r13,r13
    { const bool k = !c.t; c.r[7] = 0xEu; if (k) { goto L_06099B08; } }  // 06099B02 bf/s 0x06099B08 ; mov #14,r7
    c.r[7] = 0x11u;  // 06099B06 mov #17,r7
L_06099B08:
    c.r[1] = ld32(0x06099B44u);  // 06099B08 mov.l 0x06099B44,r1
    c.r[6] = c.r[8];  // 06099B0A mov r8,r6
    c.r[5] = c.r[10];  // 06099B0C mov r10,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06099B12u; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06099B12u) return; }  // 06099B0E jsr @r1 ; mov r11,r4
L_06099B12:
    c.r[1] = ld32(0x06099B48u);  // 06099B12 mov.l 0x06099B48,r1
    c.r[3] = 0x3u;  // 06099B14 mov #3,r3
    c.r[8] &= c.r[3];  // 06099B16 and r3,r8
    c.macl = c.r[9] * c.r[12];  // 06099B18 mul.l r12,r9
    st32(c.r[1], c.r[8]);  // 06099B1A mov.l r8,@r1
    c.r[15] = c.r[14];  // 06099B1C mov r14,r15
    c.r[2] = c.macl;  // 06099B1E sts macl,r2
    c.r[2] <<= 2;  // 06099B20 shll2 r2
    c.macl = c.r[9] * c.r[13];  // 06099B22 mul.l r13,r9
    c.r[10] += c.r[2];  // 06099B24 add r2,r10
    st32(c.r[1] + 8, c.r[10]);  // 06099B26 mov.l r10,@(8,r1)
    c.r[2] = c.macl;  // 06099B28 sts macl,r2
    c.r[2] <<= 2;  // 06099B2A shll2 r2
    c.r[11] += c.r[2];  // 06099B2C add r2,r11
    st32(c.r[1] + 4, c.r[11]);  // 06099B2E mov.l r11,@(4,r1)
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06099B30 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06099B32 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06099B34 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06099B36 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06099B38 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06099B3A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06099B3C mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06099B3E rts ; mov.l @r15+,r8
}

void f_06099B4C(SH2Context& c) {
    ran[2386] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06099B4C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06099B4E sts.l pr,@-r15
    c.r[0] = ld32(0x06099B74u);  // 06099B50 mov.l 0x06099B74,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06099B56u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06099B56u) return; }  // 06099B52 jsr @r0 ; mov r15,r14
    c.t = (c.r[0] & c.r[0]) == 0;  // 06099B56 tst r0,r0
    { const bool k = !c.t; c.r[0] = 0x1u; if (k) { goto L_06099B6C; } }  // 06099B58 bf/s 0x06099B6C ; mov #1,r0
    c.r[1] = ld32(0x06099B78u);  // 06099B5C mov.l 0x06099B78,r1
    c.r[6] = ld32(c.r[1] + 4);  // 06099B5E mov.l @(4,r1),r6
    c.r[5] = ld32(c.r[1] + 8);  // 06099B60 mov.l @(8,r1),r5
    c.r[4] = ld32(c.r[1]);  // 06099B62 mov.l @r1,r4
    c.r[1] = ld32(0x06099B7Cu);  // 06099B64 mov.l 0x06099B7C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06099B6Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06099B6Au) return; }  // 06099B66 jsr @r1 ; nop
    c.r[0] = 0x0u;  // 06099B6A mov #0,r0
L_06099B6C:
    c.r[15] = c.r[14];  // 06099B6C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06099B6E lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06099B70 rts ; mov.l @r15+,r14
}

void f_06099B80(SH2Context& c) {
    ran[2387] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06099B80 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06099B82 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06099B84 mov r15,r14
    c.r[0] = ld32(0x06099B94u);  // 06099B86 mov.l 0x06099B94,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06099B8Cu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06099B8Cu) return; }  // 06099B88 jsr @r0 ; mov #0,r4
    c.r[15] = c.r[14];  // 06099B8C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06099B8E lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06099B90 rts ; mov.l @r15+,r14
}

void f_06099B98(SH2Context& c) {
    ran[2388] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06099B98 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06099B9A sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06099B9C mov r15,r14
    c.r[1] = ld32(c.r[14] + 8);  // 06099B9E mov.l @(8,r14),r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06099BA0 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 06099BA2 mov.l r7,@-r15
    c.r[1] = ld32(0x06099BB8u);  // 06099BA4 mov.l 0x06099BB8,r1
    c.r[7] = c.r[6];  // 06099BA6 mov r6,r7
    c.r[6] = c.r[5];  // 06099BA8 mov r5,r6
    c.r[5] = c.r[4];  // 06099BAA mov r4,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06099BB0u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06099BB0u) return; }  // 06099BAC jsr @r1 ; mov #0,r4
    c.r[15] = c.r[14];  // 06099BB0 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06099BB2 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06099BB4 rts ; mov.l @r15+,r14
}

void f_06099BBC(SH2Context& c) {
    ran[2389] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06099BBC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06099BBE sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06099BC0 mov r15,r14
    c.r[0] = ld32(0x06099BD0u);  // 06099BC2 mov.l 0x06099BD0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06099BC8u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06099BC8u) return; }  // 06099BC4 jsr @r0 ; mov #0,r4
    c.r[15] = c.r[14];  // 06099BC8 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06099BCA lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06099BCC rts ; mov.l @r15+,r14
}

void f_06099BD4(SH2Context& c) {
    ran[2390] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06099BD4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06099BD6 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06099BD8 mov r15,r14
    c.r[0] = ld32(0x06099BE8u);  // 06099BDA mov.l 0x06099BE8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06099BE0u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06099BE0u) return; }  // 06099BDC jsr @r0 ; mov #1,r4
    c.r[15] = c.r[14];  // 06099BE0 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06099BE2 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06099BE4 rts ; mov.l @r15+,r14
}

void f_06099BEC(SH2Context& c) {
    ran[2391] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06099BEC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06099BEE sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06099BF0 mov r15,r14
    c.r[1] = ld32(c.r[14] + 8);  // 06099BF2 mov.l @(8,r14),r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06099BF4 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 06099BF6 mov.l r7,@-r15
    c.r[1] = ld32(0x06099C0Cu);  // 06099BF8 mov.l 0x06099C0C,r1
    c.r[7] = c.r[6];  // 06099BFA mov r6,r7
    c.r[6] = c.r[5];  // 06099BFC mov r5,r6
    c.r[5] = c.r[4];  // 06099BFE mov r4,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06099C04u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06099C04u) return; }  // 06099C00 jsr @r1 ; mov #1,r4
    c.r[15] = c.r[14];  // 06099C04 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06099C06 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06099C08 rts ; mov.l @r15+,r14
}

void f_06099C10(SH2Context& c) {
    ran[2392] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06099C10 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06099C12 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06099C14 mov r15,r14
    c.r[0] = ld32(0x06099C24u);  // 06099C16 mov.l 0x06099C24,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06099C1Cu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06099C1Cu) return; }  // 06099C18 jsr @r0 ; mov #1,r4
    c.r[15] = c.r[14];  // 06099C1C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06099C1E lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06099C20 rts ; mov.l @r15+,r14
}

void f_06099C28(SH2Context& c) {
    ran[2393] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06099C28 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06099C2A mov r15,r14
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06099C2C mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 06099C2E rts ; mov #1,r0
}

void f_06099C34(SH2Context& c) {
    ran[2394] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06099C34 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06099C36 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06099C38 mov r15,r14
    c.t = (c.r[4] & c.r[4]) == 0;  // 06099C3A tst r4,r4
    { const bool k = c.t; c.r[0] = ld32(c.r[14] + 8); if (k) { goto L_06099C66; } }  // 06099C3C bt/s 0x06099C66 ; mov.l @(8,r14),r0
    c.r[3] = c.r[0];  // 06099C40 mov r0,r3
    c.r[3] >>= 2;  // 06099C42 shlr2 r3
    c.r[2] = 0x0u;  // 06099C44 mov #0,r2
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[3];  // 06099C46 cmp/ge r3,r2
    { const bool k = c.t; c.r[5] <<= 2; if (k) { goto L_06099C5C; } }  // 06099C48 bt/s 0x06099C5C ; shll2 r5
    c.r[7] <<= 2;  // 06099C4C shll2 r7
L_06099C4E:
    c.r[1] = ld32(c.r[6]);  // 06099C4E mov.l @r6,r1
    c.r[2] += 1;  // 06099C50 add #1,r2
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[3];  // 06099C52 cmp/ge r3,r2
    st32(c.r[4], c.r[1]);  // 06099C54 mov.l r1,@r4
    c.r[4] += c.r[5];  // 06099C56 add r5,r4
    { const bool k = !c.t; c.r[6] += c.r[7]; if (k) { SH2_POLL(c); goto L_06099C4E; } }  // 06099C58 bf/s 0x06099C4E ; add r7,r6
L_06099C5C:
    c.r[0] &= 0x3u;  // 06099C5C and #3,r0
    c.r[1] = ld32(0x06099C70u);  // 06099C5E mov.l 0x06099C70,r1
    c.r[5] = c.r[4];  // 06099C60 mov r4,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06099C66u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06099C66u) return; }  // 06099C62 jsr @r1 ; mov r0,r4
L_06099C66:
    c.r[15] = c.r[14];  // 06099C66 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06099C68 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06099C6A rts ; mov.l @r15+,r14
}

void f_06099C74(SH2Context& c) {
    ran[2395] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06099C74 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06099C76 mov r15,r14
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06099C78 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = 0x0u; c.pc = x; return; }  // 06099C7A rts ; mov #0,r0
}

void f_06099C80(SH2Context& c) {
    ran[2396] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06099C80 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06099C82 sts.l pr,@-r15
    c.r[3] = ld32(c.r[4] + 56);  // 06099C84 mov.l @(56,r4),r3
    c.r[1] = ld32(c.r[4] + 16);  // 06099C86 mov.l @(16,r4),r1
    c.r[14] = c.r[15];  // 06099C88 mov r15,r14
    c.t = (c.r[3] & c.r[3]) == 0;  // 06099C8A tst r3,r3
    { const bool k = c.t; c.r[1] = ld32(c.r[1]); if (k) { goto L_06099C9C; } }  // 06099C8C bt/s 0x06099C9C ; mov.l @r1,r1
    c.r[0] = c.r[3];  // 06099C90 mov r3,r0
    c.t = c.r[0] == 0x4u;  // 06099C92 cmp/eq #4,r0
    { const bool k = !c.t; c.r[0] = 0x1u; if (k) { goto L_06099CB6; } }  // 06099C94 bf/s 0x06099CB6 ; mov #1,r0
    c.r[15] = c.r[14]; goto L_06099CC8;  // 06099C98 bra 0x06099CC8 ; mov r14,r15
L_06099C9C:
    c.r[7] = ld32(0x06099CD0u);  // 06099C9C mov.l 0x06099CD0,r7
    c.r[7] &= c.r[1];  // 06099C9E and r1,r7
    c.r[2] = ld32(0x06099CD4u);  // 06099CA0 mov.l 0x06099CD4,r2
    c.r[2] += c.r[7];  // 06099CA2 add r7,r2
    c.r[1] = ld32(0x06099CD8u);  // 06099CA4 mov.l 0x06099CD8,r1
    c.t = c.r[2] > c.r[1];  // 06099CA6 cmp/hi r1,r2
    if (!c.t) { goto L_06099CB4; }  // 06099CA8 bf 0x06099CB4
    c.r[1] = ld32(0x06099CDCu);  // 06099CAA mov.l 0x06099CDC,r1
    c.r[7] += c.r[1];  // 06099CAC add r1,r7
    c.r[1] = ld32(0x06099CE0u);  // 06099CAE mov.l 0x06099CE0,r1
    c.t = c.r[7] > c.r[1];  // 06099CB0 cmp/hi r1,r7
    if (c.t) { goto L_06099CB6; }  // 06099CB2 bt 0x06099CB6
L_06099CB4:
    c.r[3] = 0x3u;  // 06099CB4 mov #3,r3
L_06099CB6:
    c.r[1] = ld32(0x06099CE4u);  // 06099CB6 mov.l 0x06099CE4,r1
    c.r[0] = c.r[3];  // 06099CB8 mov r3,r0
    c.r[0] += c.r[0];  // 06099CBA add r0,r0
    c.r[0] += c.r[3];  // 06099CBC add r3,r0
    c.r[0] <<= 2;  // 06099CBE shll2 r0
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 06099CC0 mov.l @(r0,r1),r0
    { const uint32_t x = c.r[0]; c.pr = 0x06099CC6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06099CC6u) return; }  // 06099CC2 jsr @r0 ; nop
    c.r[15] = c.r[14];  // 06099CC6 mov r14,r15
L_06099CC8:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06099CC8 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06099CCA rts ; mov.l @r15+,r14
}

void f_06099CE8(SH2Context& c) {
    ran[2397] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06099CE8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06099CEA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06099CEC mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06099CEE mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06099CF0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06099CF2 sts.l pr,@-r15
    c.r[9] = c.r[4];  // 06099CF4 mov r4,r9
    c.r[9] += 108;  // 06099CF6 add #108,r9
    c.r[8] = ld32(c.r[9] + 12);  // 06099CF8 mov.l @(12,r9),r8
    c.r[0] = ld32(c.r[9] + 56);  // 06099CFA mov.l @(56,r9),r0
    c.r[14] = c.r[15];  // 06099CFC mov r15,r14
    c.t = c.r[0] == 0x4u;  // 06099CFE cmp/eq #4,r0
    { const bool k = !c.t; c.r[10] = ld32(c.r[9] + 16); if (k) { goto L_06099D28; } }  // 06099D00 bf/s 0x06099D28 ; mov.l @(16,r9),r10
    c.r[5] = ld32(c.r[8] + 12);  // 06099D04 mov.l @(12,r8),r5
    c.r[0] = ld32(c.r[9] + 40);  // 06099D06 mov.l @(40,r9),r0
    { const uint32_t x = c.r[0]; c.pr = 0x06099D0Cu; c.r[4] = ld32(c.r[9] + 36); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06099D0Cu) return; }  // 06099D08 jsr @r0 ; mov.l @(36,r9),r4
    c.t = (int32_t)c.r[0] >= 0;  // 06099D0C cmp/pz r0
    if (!c.t) { goto L_06099D22; }  // 06099D0E bf 0x06099D22
    st32(c.r[8] + 12, c.r[0]);  // 06099D10 mov.l r0,@(12,r8)
    st32(c.r[10] + 12, c.r[0]);  // 06099D12 mov.l r0,@(12,r10)
    c.r[1] = ld32(c.r[9] + 44);  // 06099D14 mov.l @(44,r9),r1
    c.macl = c.r[0] * c.r[1];  // 06099D16 mul.l r1,r0
    c.r[11] = c.macl;  // 06099D18 sts macl,r11
    st32(c.r[8] + 8, c.r[11]);  // 06099D1A mov.l r11,@(8,r8)
    st32(c.r[10] + 8, c.r[11]);  // 06099D1C mov.l r11,@(8,r10)
    st32(c.r[9] + 32, c.r[11]); goto L_06099D88;  // 06099D1E bra 0x06099D88 ; mov.l r11,@(32,r9)
L_06099D22:
    st32(c.r[8] + 8, c.r[0]);  // 06099D22 mov.l r0,@(8,r8)
    c.r[0] = 0x0u; goto L_06099D8A;  // 06099D24 bra 0x06099D8A ; mov #0,r0
L_06099D28:
    c.r[1] = ld32(c.r[9] + 32);  // 06099D28 mov.l @(32,r9),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06099D2A tst r1,r1
    { const bool k = !c.t; c.r[4] += 12; if (k) { goto L_06099D3E; } }  // 06099D2C bf/s 0x06099D3E ; add #12,r4
    c.r[0] = ld32(0x06099D9Cu);  // 06099D30 mov.l 0x06099D9C,r0
    c.r[5] = c.r[4];  // 06099D32 mov r4,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06099D38u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06099D38u) return; }  // 06099D34 jsr @r0 ; mov r8,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 06099D38 tst r0,r0
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_06099D8A; } }  // 06099D3A bt/s 0x06099D8A ; mov #0,r0
L_06099D3E:
    c.r[7] = ld32(c.r[8] + 4);  // 06099D3E mov.l @(4,r8),r7
    c.r[1] = ld32(c.r[9] + 32);  // 06099D40 mov.l @(32,r9),r1
    c.r[6] = ld32(c.r[8]);  // 06099D42 mov.l @r8,r6
    c.r[5] = ld32(c.r[10] + 4);  // 06099D44 mov.l @(4,r10),r5
    c.r[4] = ld32(c.r[10]);  // 06099D46 mov.l @r10,r4
    c.r[0] = ld32(c.r[9] + 56);  // 06099D48 mov.l @(56,r9),r0
    c.macl = c.r[7] * c.r[1];  // 06099D4A mul.l r1,r7
    c.t = (c.r[0] & c.r[0]) == 0;  // 06099D4C tst r0,r0
    c.r[8] = ld32(c.r[10] + 8);  // 06099D4E mov.l @(8,r10),r8
    c.r[1] = c.macl;  // 06099D50 sts macl,r1
    { const bool k = !c.t; c.r[6] += c.r[1]; if (k) { goto L_06099D70; } }  // 06099D52 bf/s 0x06099D70 ; add r1,r6
    c.r[3] = ld32(0x06099DA0u);  // 06099D56 mov.l 0x06099DA0,r3
    c.r[3] &= c.r[4];  // 06099D58 and r4,r3
    c.r[2] = ld32(0x06099DA4u);  // 06099D5A mov.l 0x06099DA4,r2
    c.r[2] += c.r[3];  // 06099D5C add r3,r2
    c.r[1] = ld32(0x06099DA8u);  // 06099D5E mov.l 0x06099DA8,r1
    c.t = c.r[2] > c.r[1];  // 06099D60 cmp/hi r1,r2
    if (!c.t) { goto L_06099D6E; }  // 06099D62 bf 0x06099D6E
    c.r[1] = ld32(0x06099DACu);  // 06099D64 mov.l 0x06099DAC,r1
    c.r[3] += c.r[1];  // 06099D66 add r1,r3
    c.r[1] = ld32(0x06099DB0u);  // 06099D68 mov.l 0x06099DB0,r1
    c.t = c.r[3] > c.r[1];  // 06099D6A cmp/hi r1,r3
    if (c.t) { goto L_06099D70; }  // 06099D6C bt 0x06099D70
L_06099D6E:
    c.r[0] = 0x3u;  // 06099D6E mov #3,r0
L_06099D70:
    c.r[1] = ld32(0x06099DB4u);  // 06099D70 mov.l 0x06099DB4,r1
    c.r[2] = c.r[0];  // 06099D72 mov r0,r2
    c.r[2] += c.r[2];  // 06099D74 add r2,r2
    c.r[2] += c.r[0];  // 06099D76 add r0,r2
    c.r[2] <<= 2;  // 06099D78 shll2 r2
    c.r[2] += c.r[1];  // 06099D7A add r1,r2
    c.r[1] = ld32(c.r[2] + 4);  // 06099D7C mov.l @(4,r2),r1
    { const uint32_t x = c.r[1]; c.pr = 0x06099D82u; c.r[15] -= 4; st32(c.r[15], c.r[8]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06099D82u) return; }  // 06099D7E jsr @r1 ; mov.l r8,@-r15
    c.r[1] = ld32(c.r[9] + 32);  // 06099D82 mov.l @(32,r9),r1
    c.r[1] += c.r[8];  // 06099D84 add r8,r1
    st32(c.r[9] + 32, c.r[1]);  // 06099D86 mov.l r1,@(32,r9)
L_06099D88:
    c.r[0] = 0x1u;  // 06099D88 mov #1,r0
L_06099D8A:
    c.r[15] = c.r[14];  // 06099D8A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06099D8C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06099D8E mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06099D90 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06099D92 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06099D94 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06099D96 rts ; mov.l @r15+,r8
}

void f_06099DB8(SH2Context& c) {
    ran[2398] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06099DB8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06099DBA sts.l pr,@-r15
    c.r[0] = ld32(c.r[4] + 56);  // 06099DBC mov.l @(56,r4),r0
    c.r[1] = ld32(c.r[4] + 16);  // 06099DBE mov.l @(16,r4),r1
    c.r[14] = c.r[15];  // 06099DC0 mov r15,r14
    c.t = (c.r[0] & c.r[0]) == 0;  // 06099DC2 tst r0,r0
    { const bool k = c.t; c.r[2] = ld32(c.r[1]); if (k) { goto L_06099DD4; } }  // 06099DC4 bt/s 0x06099DD4 ; mov.l @r1,r2
    c.t = c.r[0] == 0x4u;  // 06099DC8 cmp/eq #4,r0
    if (!c.t) { goto L_06099DEE; }  // 06099DCA bf 0x06099DEE
    c.r[0] = ld32(c.r[1] + 12);  // 06099DCC mov.l @(12,r1),r0
    c.t = c.r[0] >> 31; c.r[0] = c.r[0] << 1 | c.t;  // 06099DCE rotl r0
    c.r[0] = c.t; goto L_06099E00;  // 06099DD0 bra 0x06099E00 ; movt r0
L_06099DD4:
    c.r[3] = ld32(0x06099E08u);  // 06099DD4 mov.l 0x06099E08,r3
    c.r[3] &= c.r[2];  // 06099DD6 and r2,r3
    c.r[2] = ld32(0x06099E0Cu);  // 06099DD8 mov.l 0x06099E0C,r2
    c.r[2] += c.r[3];  // 06099DDA add r3,r2
    c.r[1] = ld32(0x06099E10u);  // 06099DDC mov.l 0x06099E10,r1
    c.t = c.r[2] > c.r[1];  // 06099DDE cmp/hi r1,r2
    if (!c.t) { goto L_06099DEC; }  // 06099DE0 bf 0x06099DEC
    c.r[1] = ld32(0x06099E14u);  // 06099DE2 mov.l 0x06099E14,r1
    c.r[3] += c.r[1];  // 06099DE4 add r1,r3
    c.r[1] = ld32(0x06099E18u);  // 06099DE6 mov.l 0x06099E18,r1
    c.t = c.r[3] > c.r[1];  // 06099DE8 cmp/hi r1,r3
    if (c.t) { goto L_06099DEE; }  // 06099DEA bt 0x06099DEE
L_06099DEC:
    c.r[0] = 0x3u;  // 06099DEC mov #3,r0
L_06099DEE:
    c.r[1] = ld32(0x06099E1Cu);  // 06099DEE mov.l 0x06099E1C,r1
    c.r[2] = c.r[0];  // 06099DF0 mov r0,r2
    c.r[2] += c.r[2];  // 06099DF2 add r2,r2
    c.r[2] += c.r[0];  // 06099DF4 add r0,r2
    c.r[2] <<= 2;  // 06099DF6 shll2 r2
    c.r[2] += c.r[1];  // 06099DF8 add r1,r2
    c.r[0] = ld32(c.r[2] + 8);  // 06099DFA mov.l @(8,r2),r0
    { const uint32_t x = c.r[0]; c.pr = 0x06099E00u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06099E00u) return; }  // 06099DFC jsr @r0 ; nop
L_06099E00:
    c.r[15] = c.r[14];  // 06099E00 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06099E02 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06099E04 rts ; mov.l @r15+,r14
}

void f_06099E20(SH2Context& c) {
    ran[2399] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06099E20 mov.l r14,@-r15
    c.r[15] -= 4;  // 06099E22 add #-4,r15
    c.t = (int32_t)c.r[4] > 0;  // 06099E24 cmp/pl r4
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_06099E40; } }  // 06099E26 bf/s 0x06099E40 ; mov r15,r14
    c.r[1] = ld32(c.r[6]);  // 06099E2A mov.l @r6,r1
    c.r[0] = 0x0u;  // 06099E2C mov #0,r0
    c.t = (int32_t)c.r[0] >= (int32_t)c.r[4];  // 06099E2E cmp/ge r4,r0
    { const bool k = c.t; st32(c.r[14], c.r[1]); if (k) { goto L_06099E40; } }  // 06099E30 bt/s 0x06099E40 ; mov.l r1,@r14
L_06099E34:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 06099E34 mov.b @(r0,r14),r1
    st8(c.r[5], c.r[1]);  // 06099E36 mov.b r1,@r5
    c.r[0] += 1;  // 06099E38 add #1,r0
    c.t = (int32_t)c.r[0] >= (int32_t)c.r[4];  // 06099E3A cmp/ge r4,r0
    { const bool k = !c.t; c.r[5] += 1; if (k) { SH2_POLL(c); goto L_06099E34; } }  // 06099E3C bf/s 0x06099E34 ; add #1,r5
L_06099E40:
    c.r[14] += 4;  // 06099E40 add #4,r14
    c.r[15] = c.r[14];  // 06099E42 mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06099E44 rts ; mov.l @r15+,r14
}

void f_06099E48(SH2Context& c) {
    ran[2400] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06099E48 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06099E4A mov r15,r14
    c.r[0] = ld32(c.r[4] + 8);  // 06099E4C mov.l @(8,r4),r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06099E4E rts ; mov.l @r15+,r14
}

void f_06099E54(SH2Context& c) {
    ran[2401] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06099E54 mov.l r14,@-r15
    c.r[2] = ld32(c.r[4] + 4);  // 06099E56 mov.l @(4,r4),r2
    c.r[14] = c.r[15];  // 06099E58 mov r15,r14
    c.r[1] = ld32(c.r[4] + 44);  // 06099E5A mov.l @(44,r4),r1
    c.macl = c.r[2] * c.r[1];  // 06099E5C mul.l r1,r2
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06099E5E mov.l @r15+,r14
    c.r[1] = ld32(c.r[4] + 8);  // 06099E60 mov.l @(8,r4),r1
    c.r[0] = c.macl;  // 06099E62 sts macl,r0
    { const uint32_t x = c.pr; c.r[0] -= c.r[1]; c.pc = x; return; }  // 06099E64 rts ; sub r1,r0
}

void f_06099E68(SH2Context& c) {
    ran[2402] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06099E68 mov.l r14,@-r15
    c.r[1] = ld32(0x06099E9Cu);  // 06099E6A mov.l 0x06099E9C,r1
    c.r[3] = ld32(c.r[1]);  // 06099E6C mov.l @r1,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x06099E9Au);  // 06099E6E mov.w 0x06099E9A,r7
    c.r[6] = c.r[3];  // 06099E70 mov r3,r6
    c.r[6] += c.r[7];  // 06099E72 add r7,r6
    c.r[1] = ld32(c.r[6] + 16);  // 06099E74 mov.l @(16,r6),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06099E76 tst r1,r1
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_06099E92; } }  // 06099E78 bf/s 0x06099E92 ; mov r15,r14
    c.r[1] = ld32(c.r[4]);  // 06099E7C mov.l @r4,r1
    c.r[2] = ld32(c.r[4] + 8);  // 06099E7E mov.l @(8,r4),r2
    c.r[0] = c.r[3];  // 06099E80 mov r3,r0
    c.r[1] += c.r[2];  // 06099E82 add r2,r1
    st32(c.r[0] + c.r[7], c.r[1]);  // 06099E84 mov.l r1,@(r0,r7)
    c.r[1] = 0x1u;  // 06099E86 mov #1,r1
    st32(c.r[6] + 4, c.r[1]);  // 06099E88 mov.l r1,@(4,r6)
    st32(c.r[6] + 8, c.r[5]);  // 06099E8A mov.l r5,@(8,r6)
    st32(c.r[6] + 16, c.r[1]);  // 06099E8C mov.l r1,@(16,r6)
    c.r[0] = c.r[6]; goto L_06099E94;  // 06099E8E bra 0x06099E94 ; mov r6,r0
L_06099E92:
    c.r[0] = 0x0u;  // 06099E92 mov #0,r0
L_06099E94:
    c.r[15] = c.r[14];  // 06099E94 mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06099E96 rts ; mov.l @r15+,r14
}

void f_06099EA0(SH2Context& c) {
    ran[2403] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06099EA0 mov.l r14,@-r15
    c.r[0] = ld32(c.r[4] + 56);  // 06099EA2 mov.l @(56,r4),r0
    c.t = c.r[0] == 0x4u;  // 06099EA4 cmp/eq #4,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06099EB2; } }  // 06099EA6 bt/s 0x06099EB2 ; mov r15,r14
    c.r[2] = ld32(c.r[4] + 8);  // 06099EAA mov.l @(8,r4),r2
    c.r[1] = ld32(c.r[5] + 8);  // 06099EAC mov.l @(8,r5),r1
    c.r[2] += c.r[1];  // 06099EAE add r1,r2
    st32(c.r[4] + 8, c.r[2]);  // 06099EB0 mov.l r2,@(8,r4)
L_06099EB2:
    c.r[1] = 0x0u;  // 06099EB2 mov #0,r1
    st32(c.r[5] + 16, c.r[1]);  // 06099EB4 mov.l r1,@(16,r5)
    c.r[15] = c.r[14];  // 06099EB6 mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06099EB8 rts ; mov.l @r15+,r14
}

void f_06099EBC(SH2Context& c) {
    ran[2404] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06099EBC mov.l r14,@-r15
    c.r[1] = ld32(c.r[4]);  // 06099EBE mov.l @r4,r1
    st32(c.r[5], c.r[1]);  // 06099EC0 mov.l r1,@r5
    c.r[1] = ld32(c.r[4] + 4);  // 06099EC2 mov.l @(4,r4),r1
    c.r[14] = c.r[15];  // 06099EC4 mov r15,r14
    st32(c.r[6], c.r[1]);  // 06099EC6 mov.l r1,@r6
    c.r[1] = ld32(c.r[4] + 44);  // 06099EC8 mov.l @(44,r4),r1
    st32(c.r[7], c.r[1]);  // 06099ECA mov.l r1,@r7
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06099ECC rts ; mov.l @r15+,r14
}

void f_06099ED0(SH2Context& c) {
    ran[2405] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06099ED0 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06099ED2 mov r15,r14
    st32(c.r[4], c.r[5]);  // 06099ED4 mov.l r5,@r4
    st32(c.r[4] + 4, c.r[6]);  // 06099ED6 mov.l r6,@(4,r4)
    st32(c.r[4] + 44, c.r[7]);  // 06099ED8 mov.l r7,@(44,r4)
    c.r[1] = 0x0u;  // 06099EDA mov #0,r1
    st32(c.r[4] + 8, c.r[1]);  // 06099EDC mov.l r1,@(8,r4)
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06099EDE rts ; mov.l @r15+,r14
}

void f_06099EE4(SH2Context& c) {
    ran[2406] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06099EE4 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06099EE6 mov r15,r14
    c.r[4] += 108;  // 06099EE8 add #108,r4
    st32(c.r[4] + 36, c.r[6]);  // 06099EEA mov.l r6,@(36,r4)
    st32(c.r[4] + 40, c.r[5]);  // 06099EEC mov.l r5,@(40,r4)
    c.r[1] = 0x4u;  // 06099EEE mov #4,r1
    st32(c.r[4] + 56, c.r[1]);  // 06099EF0 mov.l r1,@(56,r4)
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06099EF2 rts ; mov.l @r15+,r14
}

void f_06099F28(SH2Context& c) {
    ran[2407] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06099F28 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06099F2A sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06099F2C mov r15,r14
    c.r[2] = c.r[4];  // 06099F2E mov r4,r2
    c.r[2] += 12;  // 06099F30 add #12,r2
    c.r[0] = ld32(c.r[4] + 40);  // 06099F32 mov.l @(40,r4),r0
    c.r[1] = ld32(0x06099F48u);  // 06099F34 mov.l 0x06099F48,r1
    c.r[0] <<= 2;  // 06099F36 shll2 r0
    c.r[0] <<= 2;  // 06099F38 shll2 r0
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 06099F3A mov.l @(r0,r1),r0
    { const uint32_t x = c.r[0]; c.pr = 0x06099F40u; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06099F40u) return; }  // 06099F3C jsr @r0 ; mov r2,r4
    c.r[15] = c.r[14];  // 06099F40 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06099F42 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06099F44 rts ; mov.l @r15+,r14
}

void f_06099F4C(SH2Context& c) {
    ran[2408] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06099F4C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06099F4E sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06099F50 mov r15,r14
    c.r[2] = c.r[4];  // 06099F52 mov r4,r2
    c.r[2] += 12;  // 06099F54 add #12,r2
    c.r[1] = ld32(0x06099F70u);  // 06099F56 mov.l 0x06099F70,r1
    c.r[5] = ld32(0x06099F74u);  // 06099F58 mov.l 0x06099F74,r5
    c.r[0] = ld32(c.r[4] + 40);  // 06099F5A mov.l @(40,r4),r0
    c.r[6] = 0x0u;  // 06099F5C mov #0,r6
    c.r[0] <<= 2;  // 06099F5E shll2 r0
    c.r[0] <<= 2;  // 06099F60 shll2 r0
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 06099F62 mov.l @(r0,r1),r0
    { const uint32_t x = c.r[0]; c.pr = 0x06099F68u; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06099F68u) return; }  // 06099F64 jsr @r0 ; mov r2,r4
    c.r[15] = c.r[14];  // 06099F68 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06099F6A lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06099F6C rts ; mov.l @r15+,r14
}

void f_06099F78(SH2Context& c) {
    ran[2409] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06099F78 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06099F7A sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06099F7C mov r15,r14
    c.r[3] = c.r[4];  // 06099F7E mov r4,r3
    c.r[3] += 12;  // 06099F80 add #12,r3
    c.r[2] = ld32(c.r[4] + 40);  // 06099F82 mov.l @(40,r4),r2
    c.r[1] = ld32(0x06099F9Cu);  // 06099F84 mov.l 0x06099F9C,r1
    c.r[2] <<= 2;  // 06099F86 shll2 r2
    c.r[2] <<= 2;  // 06099F88 shll2 r2
    c.r[2] += c.r[1];  // 06099F8A add r1,r2
    c.r[0] = ld32(c.r[2] + 4);  // 06099F8C mov.l @(4,r2),r0
    { const uint32_t x = c.r[0]; c.pr = 0x06099F92u; c.r[4] = c.r[3]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06099F92u) return; }  // 06099F8E jsr @r0 ; mov r3,r4
    c.r[15] = c.r[14];  // 06099F92 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06099F94 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06099F96 rts ; mov.l @r15+,r14
}

void f_06099FA0(SH2Context& c) {
    ran[2410] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06099FA0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06099FA2 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06099FA4 mov r15,r14
    c.r[3] = c.r[5];  // 06099FA6 mov r5,r3
    c.r[3] += 28;  // 06099FA8 add #28,r3
    c.r[2] = ld32(c.r[5] + 28);  // 06099FAA mov.l @(28,r5),r2
    c.r[1] = ld32(0x06099FC4u);  // 06099FAC mov.l 0x06099FC4,r1
    c.r[2] <<= 2;  // 06099FAE shll2 r2
    c.r[2] <<= 2;  // 06099FB0 shll2 r2
    c.r[2] += c.r[1];  // 06099FB2 add r1,r2
    c.r[0] = ld32(c.r[2] + 8);  // 06099FB4 mov.l @(8,r2),r0
    { const uint32_t x = c.r[0]; c.pr = 0x06099FBAu; c.r[5] = c.r[3]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06099FBAu) return; }  // 06099FB6 jsr @r0 ; mov r3,r5
    c.r[15] = c.r[14];  // 06099FBA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06099FBC lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06099FBE rts ; mov.l @r15+,r14
}

void f_06099FC8(SH2Context& c) {
    ran[2411] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06099FC8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06099FCA sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06099FCC mov r15,r14
    c.r[3] = c.r[4];  // 06099FCE mov r4,r3
    c.r[3] += 12;  // 06099FD0 add #12,r3
    c.r[2] = ld32(c.r[4] + 40);  // 06099FD2 mov.l @(40,r4),r2
    c.r[1] = ld32(0x06099FECu);  // 06099FD4 mov.l 0x06099FEC,r1
    c.r[2] <<= 2;  // 06099FD6 shll2 r2
    c.r[2] <<= 2;  // 06099FD8 shll2 r2
    c.r[2] += c.r[1];  // 06099FDA add r1,r2
    c.r[1] = ld32(c.r[2] + 12);  // 06099FDC mov.l @(12,r2),r1
    { const uint32_t x = c.r[1]; c.pr = 0x06099FE2u; c.r[4] = c.r[3]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06099FE2u) return; }  // 06099FDE jsr @r1 ; mov r3,r4
    c.r[15] = c.r[14];  // 06099FE2 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06099FE4 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06099FE6 rts ; mov.l @r15+,r14
}

void f_06099FF0(SH2Context& c) {
    ran[2412] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06099FF0 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06099FF2 mov r15,r14
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06099FF4 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 06099FF6 rts ; mov #1,r0
}

void f_06099FFC(SH2Context& c) {
    ran[2413] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06099FFC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06099FFE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609A000 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609A002 sts.l pr,@-r15
    c.r[15] -= 16;  // 0609A004 add #-16,r15
    c.r[14] = c.r[15];  // 0609A006 mov r15,r14
    c.r[8] = c.r[4];  // 0609A008 mov r4,r8
    c.r[8] += 28;  // 0609A00A add #28,r8
    c.r[7] = 0x0u;  // 0609A00C mov #0,r7
    st32(c.r[4] + 28, c.r[7]);  // 0609A00E mov.l r7,@(28,r4)
    c.r[9] = 0x1u;  // 0609A010 mov #1,r9
    st32(c.r[8] + 24, c.r[9]);  // 0609A012 mov.l r9,@(24,r8)
    c.r[1] = c.r[4];  // 0609A014 mov r4,r1
    c.r[1] += 14;  // 0609A016 add #14,r1
    c.r[3] = 0x0u;  // 0609A018 mov #0,r3
    c.r[2] = c.r[14];  // 0609A01A mov r14,r2
    c.r[2] += 2;  // 0609A01C add #2,r2
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0609A01E mov.b @r1,r6
    c.r[0] = ld32(0x0609A0ECu);  // 0609A020 mov.l 0x0609A0EC,r0
    st8(c.r[14], c.r[6]);  // 0609A022 mov.b r6,@r14
    c.r[1] = c.r[14];  // 0609A024 mov r14,r1
    c.r[1] += 1;  // 0609A026 add #1,r1
    st8(c.r[1], c.r[3]);  // 0609A028 mov.b r3,@r1
    st8(c.r[2], c.r[3]);  // 0609A02A mov.b r3,@r2
    c.r[2] = c.r[14];  // 0609A02C mov r14,r2
    c.r[2] += 3;  // 0609A02E add #3,r2
    st8(c.r[2], c.r[3]);  // 0609A030 mov.b r3,@r2
    c.r[2] = c.r[14];  // 0609A032 mov r14,r2
    c.r[2] += 4;  // 0609A034 add #4,r2
    st8(c.r[2], c.r[3]);  // 0609A036 mov.b r3,@r2
    c.r[2] = c.r[14];  // 0609A038 mov r14,r2
    c.r[2] += 5;  // 0609A03A add #5,r2
    st8(c.r[2], c.r[3]);  // 0609A03C mov.b r3,@r2
    c.r[2] = c.r[4];  // 0609A03E mov r4,r2
    c.r[2] += 44;  // 0609A040 add #44,r2
    st8(c.r[2], c.r[6]);  // 0609A042 mov.b r6,@r2
    c.r[3] = c.r[4];  // 0609A044 mov r4,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0609A046 mov.b @r1+,r2
    c.r[3] += 45;  // 0609A048 add #45,r3
    st8(c.r[3], c.r[2]);  // 0609A04A mov.b r2,@r3
    c.r[3] = c.r[4];  // 0609A04C mov r4,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0609A04E mov.b @r1+,r2
    c.r[3] += 46;  // 0609A050 add #46,r3
    st8(c.r[3], c.r[2]);  // 0609A052 mov.b r2,@r3
    c.r[3] = c.r[4];  // 0609A054 mov r4,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0609A056 mov.b @r1+,r2
    c.r[3] += 47;  // 0609A058 add #47,r3
    st8(c.r[3], c.r[2]);  // 0609A05A mov.b r2,@r3
    c.r[3] = c.r[4];  // 0609A05C mov r4,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0609A05E mov.b @r1+,r2
    c.r[3] += 48;  // 0609A060 add #48,r3
    st8(c.r[3], c.r[2]);  // 0609A062 mov.b r2,@r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0609A064 mov.b @r1,r1
    c.r[4] += 49;  // 0609A066 add #49,r4
    st8(c.r[4], c.r[1]);  // 0609A068 mov.b r1,@r4
    c.r[1] = 0xFFFFFFFFu;  // 0609A06A mov #-1,r1
    st32(c.r[8] + 28, c.r[1]);  // 0609A06C mov.l r1,@(28,r8)
    st32(c.r[8] + 36, c.r[7]);  // 0609A06E mov.l r7,@(36,r8)
    st32(c.r[8] + 32, c.r[7]);  // 0609A070 mov.l r7,@(32,r8)
    st32(c.r[8] + 44, c.r[7]);  // 0609A072 mov.l r7,@(44,r8)
    st32(c.r[8] + 40, c.r[7]);  // 0609A074 mov.l r7,@(40,r8)
    c.r[4] = c.r[14];  // 0609A076 mov r14,r4
    { const uint32_t x = c.r[0]; c.pr = 0x0609A07Cu; c.r[4] += 8; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609A07Cu) return; }  // 0609A078 jsr @r0 ; add #8,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609A07C tst r0,r0
    { const bool k = !c.t; c.r[1] = ld32(c.r[14] + 8); if (k) { goto L_0609A0D8; } }  // 0609A07E bf/s 0x0609A0D8 ; mov.l @(8,r14),r1
    c.r[4] = c.r[14];  // 0609A082 mov r14,r4
    c.r[4] += 12;  // 0609A084 add #12,r4
    c.r[0] = ld32(0x0609A0F0u);  // 0609A086 mov.l 0x0609A0F0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609A08Cu; st32(c.r[8] + 4, c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609A08Cu) return; }  // 0609A088 jsr @r0 ; mov.l r1,@(4,r8)
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609A08C tst r0,r0
    { const bool k = c.t; c.r[7] = 0x0u; if (k) { goto L_0609A09C; } }  // 0609A08E bt/s 0x0609A09C ; mov #0,r7
    c.r[0] = ld32(0x0609A0F4u);  // 0609A092 mov.l 0x0609A0F4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609A098u; c.r[4] = ld32(c.r[14] + 8); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609A098u) return; }  // 0609A094 jsr @r0 ; mov.l @(8,r14),r4
    c.r[0] = 0x0u; goto L_0609A0DA;  // 0609A098 bra 0x0609A0DA ; mov #0,r0
L_0609A09C:
    c.r[4] = ld32(c.r[14] + 12);  // 0609A09C mov.l @(12,r14),r4
    c.r[5] = ld32(c.r[8] + 24);  // 0609A09E mov.l @(24,r8),r5
    st32(c.r[8] + 12, c.r[4]);  // 0609A0A0 mov.l r4,@(12,r8)
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 0609A0A2 mov.l r0,@-r15
    c.r[0] = ld32(0x0609A0F8u);  // 0609A0A4 mov.l 0x0609A0F8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609A0AAu; c.r[6] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609A0AAu) return; }  // 0609A0A6 jsr @r0 ; mov r14,r6
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609A0AA tst r0,r0
    { const bool k = !c.t; c.r[15] += 4; if (k) { goto L_0609A0D8; } }  // 0609A0AC bf/s 0x0609A0D8 ; add #4,r15
    c.r[5] = ld32(c.r[14] + 8);  // 0609A0B0 mov.l @(8,r14),r5
    c.r[6] = (uint32_t)(int16_t)ld16(0x0609A0E8u);  // 0609A0B2 mov.w 0x0609A0E8,r6
    c.r[0] = ld32(0x0609A0FCu);  // 0609A0B4 mov.l 0x0609A0FC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609A0BAu; c.r[4] = ld32(c.r[14] + 12); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609A0BAu) return; }  // 0609A0B6 jsr @r0 ; mov.l @(12,r14),r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609A0BA tst r0,r0
    { const bool k = !c.t; c.r[0] = 0x0u; if (k) { goto L_0609A0DA; } }  // 0609A0BC bf/s 0x0609A0DA ; mov #0,r0
    c.r[0] = ld32(0x0609A100u);  // 0609A0C0 mov.l 0x0609A100,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609A0C6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609A0C6u) return; }  // 0609A0C2 jsr @r0 ; nop
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609A0C6 tst r0,r0
    { const bool k = !c.t; c.r[0] = 0x0u; if (k) { goto L_0609A0DA; } }  // 0609A0C8 bf/s 0x0609A0DA ; mov #0,r0
    c.r[0] = ld32(0x0609A104u);  // 0609A0CC mov.l 0x0609A104,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609A0D2u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609A0D2u) return; }  // 0609A0CE jsr @r0 ; mov r8,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609A0D2 tst r0,r0
    { const bool k = c.t; c.r[0] = c.r[9]; if (k) { goto L_0609A0DA; } }  // 0609A0D4 bt/s 0x0609A0DA ; mov r9,r0
L_0609A0D8:
    c.r[0] = 0x0u;  // 0609A0D8 mov #0,r0
L_0609A0DA:
    c.r[14] += 16;  // 0609A0DA add #16,r14
    c.r[15] = c.r[14];  // 0609A0DC mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609A0DE lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609A0E0 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609A0E2 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609A0E4 rts ; mov.l @r15+,r8
}

void f_0609A108(SH2Context& c) {
    ran[2414] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609A108 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609A10A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609A10C sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0609A10E mov r15,r14
    c.r[8] = c.r[4];  // 0609A110 mov r4,r8
    c.r[0] = ld32(0x0609A128u);  // 0609A112 mov.l 0x0609A128,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609A118u; c.r[4] = ld32(c.r[8] + 4); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609A118u) return; }  // 0609A114 jsr @r0 ; mov.l @(4,r8),r4
    c.r[0] = ld32(0x0609A12Cu);  // 0609A118 mov.l 0x0609A12C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609A11Eu; c.r[4] = ld32(c.r[8] + 12); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609A11Eu) return; }  // 0609A11A jsr @r0 ; mov.l @(12,r8),r4
    c.r[15] = c.r[14];  // 0609A11E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609A120 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609A122 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609A124 rts ; mov.l @r15+,r8
}

void f_0609A130(SH2Context& c) {
    ran[2415] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609A130 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609A132 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0609A134 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609A136 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609A138 sts.l pr,@-r15
    c.r[15] -= 16;  // 0609A13A add #-16,r15
    c.r[14] = c.r[15];  // 0609A13C mov r15,r14
    c.r[10] = c.r[4];  // 0609A13E mov r4,r10
    c.r[1] = c.r[5];  // 0609A140 mov r5,r1
    c.r[9] = c.r[6];  // 0609A142 mov r6,r9
    c.r[8] = c.r[10];  // 0609A144 mov r10,r8
    c.r[8] += 28;  // 0609A146 add #28,r8
    c.r[0] = ld32(0x0609A1C4u);  // 0609A148 mov.l 0x0609A1C4,r0
    c.r[5] = ld32(c.r[8] + 36);  // 0609A14A mov.l @(36,r8),r5
    c.r[7] = c.r[14];  // 0609A14C mov r14,r7
    c.r[4] = ld32(c.r[8] + 4);  // 0609A14E mov.l @(4,r8),r4
    c.r[6] = c.r[1];  // 0609A150 mov r1,r6
    { const uint32_t x = c.r[0]; c.pr = 0x0609A156u; c.r[15] -= 4; st32(c.r[15], c.r[9]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609A156u) return; }  // 0609A152 jsr @r0 ; mov.l r9,@-r15
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609A156 tst r0,r0
    { const bool k = !c.t; c.r[15] += 4; if (k) { goto L_0609A168; } }  // 0609A158 bf/s 0x0609A168 ; add #4,r15
    c.r[0] = ld32(0x0609A1C8u);  // 0609A15C mov.l 0x0609A1C8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609A162u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609A162u) return; }  // 0609A15E jsr @r0 ; nop
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609A162 tst r0,r0
    { const bool k = c.t; c.t = (c.r[9] & c.r[9]) == 0; if (k) { goto L_0609A16C; } }  // 0609A164 bt/s 0x0609A16C ; tst r9,r9
L_0609A168:
    c.r[0] = 0x0u; goto L_0609A1B4;  // 0609A168 bra 0x0609A1B4 ; mov #0,r0
L_0609A16C:
    { const bool k = c.t; c.r[7] = c.r[14]; if (k) { goto L_0609A1B2; } }  // 0609A16C bt/s 0x0609A1B2 ; mov r14,r7
    c.r[7] += 4;  // 0609A170 add #4,r7
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 0609A172 mov.l r0,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 0609A174 mov.l r0,@-r15
    c.r[1] = c.r[14];  // 0609A176 mov r14,r1
    c.r[1] += 12;  // 0609A178 add #12,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0609A17A mov.l r1,@-r15
    c.r[1] = c.r[14];  // 0609A17C mov r14,r1
    c.r[1] += 8;  // 0609A17E add #8,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0609A180 mov.l r1,@-r15
    c.r[1] = ld32(0x0609A1CCu);  // 0609A182 mov.l 0x0609A1CC,r1
    c.r[6] = 0x0u;  // 0609A184 mov #0,r6
    c.r[5] = 0x0u;  // 0609A186 mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0609A18Cu; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609A18Cu) return; }  // 0609A188 jsr @r1 ; mov r10,r4
    c.r[0] = ld32(0x0609A1D0u);  // 0609A18C mov.l 0x0609A1D0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609A192u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609A192u) return; }  // 0609A18E jsr @r0 ; mov r8,r4
    c.r[2] = ld32(c.r[14]);  // 0609A192 mov.l @r14,r2
    c.r[1] = ld32(c.r[14] + 8);  // 0609A194 mov.l @(8,r14),r1
    c.r[0] += c.r[2];  // 0609A196 add r2,r0
    c.t = (int32_t)c.r[0] >= (int32_t)c.r[1];  // 0609A198 cmp/ge r1,r0
    { const bool k = !c.t; c.r[1] = ld32(c.r[14] + 12); if (k) { goto L_0609A1B2; } }  // 0609A19A bf/s 0x0609A1B2 ; mov.l @(12,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609A19E tst r1,r1
    { const bool k = c.t; c.r[0] = ld32(c.r[14]); if (k) { goto L_0609A1B4; } }  // 0609A1A0 bt/s 0x0609A1B4 ; mov.l @r14,r0
    c.t = (int32_t)c.r[2] > 0;  // 0609A1A4 cmp/pl r2
    { const bool k = !c.t; c.r[2] = ld32(c.r[14] + 4); if (k) { goto L_0609A1B4; } }  // 0609A1A6 bf/s 0x0609A1B4 ; mov.l @(4,r14),r2
    c.r[2] -= c.r[1];  // 0609A1AA sub r1,r2
    c.r[1] = ld32(c.r[9]);  // 0609A1AC mov.l @r9,r1
    c.r[1] -= c.r[2];  // 0609A1AE sub r2,r1
    st32(c.r[9], c.r[1]);  // 0609A1B0 mov.l r1,@r9
L_0609A1B2:
    c.r[0] = ld32(c.r[14]);  // 0609A1B2 mov.l @r14,r0
L_0609A1B4:
    c.r[14] += 16;  // 0609A1B4 add #16,r14
    c.r[15] = c.r[14];  // 0609A1B6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609A1B8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609A1BA mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0609A1BC mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609A1BE mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609A1C0 rts ; mov.l @r15+,r8
}

void f_0609A1D4(SH2Context& c) {
    ran[2416] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609A1D4 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0609A1D6 mov r15,r14
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609A1D8 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = 0x0u; c.pc = x; return; }  // 0609A1DA rts ; mov #0,r0
}

void f_0609A1E0(SH2Context& c) {
    ran[2417] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609A1E0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609A1E2 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0609A1E4 mov r15,r14
    st32(c.r[4] + 24, c.r[5]);  // 0609A1E6 mov.l r5,@(24,r4)
    c.r[3] = c.r[4];  // 0609A1E8 mov r4,r3
    c.r[3] += 16;  // 0609A1EA add #16,r3
    c.r[1] = c.r[6];  // 0609A1EC mov r6,r1
    c.r[0] = ld32(0x0609A23Cu);  // 0609A1EE mov.l 0x0609A23C,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0609A1F0 mov.b @r1+,r2
    c.r[7] = 0x0u;  // 0609A1F2 mov #0,r7
    st8(c.r[3], c.r[2]);  // 0609A1F4 mov.b r2,@r3
    c.r[3] = c.r[4];  // 0609A1F6 mov r4,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0609A1F8 mov.b @r1+,r2
    c.r[3] += 17;  // 0609A1FA add #17,r3
    st8(c.r[3], c.r[2]);  // 0609A1FC mov.b r2,@r3
    c.r[3] = c.r[4];  // 0609A1FE mov r4,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0609A200 mov.b @r1+,r2
    c.r[3] += 18;  // 0609A202 add #18,r3
    st8(c.r[3], c.r[2]);  // 0609A204 mov.b r2,@r3
    c.r[3] = c.r[4];  // 0609A206 mov r4,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0609A208 mov.b @r1+,r2
    c.r[3] += 19;  // 0609A20A add #19,r3
    st8(c.r[3], c.r[2]);  // 0609A20C mov.b r2,@r3
    c.r[3] = c.r[4];  // 0609A20E mov r4,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0609A210 mov.b @r1+,r2
    c.r[3] += 20;  // 0609A212 add #20,r3
    st8(c.r[3], c.r[2]);  // 0609A214 mov.b r2,@r3
    c.r[3] = c.r[4];  // 0609A216 mov r4,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0609A218 mov.b @r1,r1
    c.r[3] += 21;  // 0609A21A add #21,r3
    st8(c.r[3], c.r[1]);  // 0609A21C mov.b r1,@r3
    c.r[4] = ld32(c.r[4] + 12);  // 0609A21E mov.l @(12,r4),r4
    c.r[1] = 0x0u;  // 0609A220 mov #0,r1
    { const uint32_t x = c.r[0]; c.pr = 0x0609A226u; c.r[15] -= 4; st32(c.r[15], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609A226u) return; }  // 0609A222 jsr @r0 ; mov.l r1,@-r15
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609A226 tst r0,r0
    { const bool k = !c.t; c.r[15] += 4; if (k) { goto L_0609A232; } }  // 0609A228 bf/s 0x0609A232 ; add #4,r15
    c.r[0] = ld32(0x0609A240u);  // 0609A22C mov.l 0x0609A240,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609A232u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609A232u) return; }  // 0609A22E jsr @r0 ; nop
L_0609A232:
    c.r[15] = c.r[14];  // 0609A232 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609A234 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609A236 rts ; mov.l @r15+,r14
}

void f_0609A244(SH2Context& c) {
    ran[2418] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609A244 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609A246 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0609A248 mov r15,r14
    c.r[0] = ld32(0x0609A264u);  // 0609A24A mov.l 0x0609A264,r0
    c.r[6] = 0xFFFFFFFFu;  // 0609A24C mov #-1,r6
    c.r[4] = ld32(c.r[4] + 4);  // 0609A24E mov.l @(4,r4),r4
    { const uint32_t x = c.r[0]; c.pr = 0x0609A254u; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609A254u) return; }  // 0609A250 jsr @r0 ; mov #0,r5
    c.r[0] = ld32(0x0609A268u);  // 0609A254 mov.l 0x0609A268,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609A25Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609A25Au) return; }  // 0609A256 jsr @r0 ; nop
    c.r[15] = c.r[14];  // 0609A25A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609A25C lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609A25E rts ; mov.l @r15+,r14
}

void f_0609A26C(SH2Context& c) {
    ran[2419] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609A26C mov.l r14,@-r15
    c.r[0] = ld32(c.r[4] + 32);  // 0609A26E mov.l @(32,r4),r0
    c.r[14] = c.r[15];  // 0609A270 mov r15,r14
    c.r[1] = ld32(c.r[4] + 36);  // 0609A272 mov.l @(36,r4),r1
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609A274 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] += c.r[1]; c.pc = x; return; }  // 0609A276 rts ; add r1,r0
}

void f_0609A27C(SH2Context& c) {
    ran[2420] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609A27C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609A27E sts.l pr,@-r15
    c.r[15] -= 4;  // 0609A280 add #-4,r15
    c.r[14] = c.r[15];  // 0609A282 mov r15,r14
    c.r[6] = ld32(0x0609A2BCu);  // 0609A284 mov.l 0x0609A2BC,r6
    c.r[4] = ld32(c.r[4] + 4);  // 0609A286 mov.l @(4,r4),r4
    c.r[1] = 0x0u;  // 0609A288 mov #0,r1
    c.r[0] = ld32(0x0609A2C0u);  // 0609A28A mov.l 0x0609A2C0,r0
    c.r[7] = c.r[14];  // 0609A28C mov r14,r7
    c.r[5] = 0x0u;  // 0609A28E mov #0,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0609A294u; c.r[15] -= 4; st32(c.r[15], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609A294u) return; }  // 0609A290 jsr @r0 ; mov.l r1,@-r15
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609A294 tst r0,r0
    { const bool k = !c.t; c.r[15] += 4; if (k) { goto L_0609A2A6; } }  // 0609A296 bf/s 0x0609A2A6 ; add #4,r15
    c.r[0] = ld32(0x0609A2C4u);  // 0609A29A mov.l 0x0609A2C4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609A2A0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609A2A0u) return; }  // 0609A29C jsr @r0 ; nop
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609A2A0 tst r0,r0
    { const bool k = c.t; c.r[1] = ld32(c.r[14]); if (k) { goto L_0609A2AA; } }  // 0609A2A2 bt/s 0x0609A2AA ; mov.l @r14,r1
L_0609A2A6:
    c.r[0] = 0xFFFFFFFFu; goto L_0609A2B2;  // 0609A2A6 bra 0x0609A2B2 ; mov #-1,r0
L_0609A2AA:
    c.t = (int32_t)c.r[1] >= 0;  // 0609A2AA cmp/pz r1
    if (c.t) { goto L_0609A2B0; }  // 0609A2AC bt 0x0609A2B0
    st32(c.r[14], c.r[0]);  // 0609A2AE mov.l r0,@r14
L_0609A2B0:
    c.r[0] = ld32(c.r[14]);  // 0609A2B0 mov.l @r14,r0
L_0609A2B2:
    c.r[14] += 4;  // 0609A2B2 add #4,r14
    c.r[15] = c.r[14];  // 0609A2B4 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609A2B6 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609A2B8 rts ; mov.l @r15+,r14
}

void f_0609A2C8(SH2Context& c) {
    ran[2421] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609A2C8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609A2CA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0609A2CC mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0609A2CE mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0609A2D0 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609A2D2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609A2D4 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0609A2D6 mov r15,r14
    c.r[11] = c.r[4];  // 0609A2D8 mov r4,r11
    c.r[9] = c.r[5];  // 0609A2DA mov r5,r9
    c.r[12] = c.r[6];  // 0609A2DC mov r6,r12
    c.r[8] = c.r[11];  // 0609A2DE mov r11,r8
    c.t = (int32_t)c.r[9] >= 0;  // 0609A2E0 cmp/pz r9
    { const bool k = c.t; c.r[8] += 28; if (k) { goto L_0609A2E8; } }  // 0609A2E2 bt/s 0x0609A2E8 ; add #28,r8
    c.r[9] = 0x0u;  // 0609A2E6 mov #0,r9
L_0609A2E8:
    c.r[0] = c.r[12];  // 0609A2E8 mov r12,r0
    c.t = c.r[0] == 0x1u;  // 0609A2EA cmp/eq #1,r0
    { const bool k = !c.t; c.r[10] = c.r[9]; if (k) { goto L_0609A2FA; } }  // 0609A2EC bf/s 0x0609A2FA ; mov r9,r10
    c.r[0] = ld32(0x0609A3ACu);  // 0609A2F0 mov.l 0x0609A3AC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609A2F6u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609A2F6u) return; }  // 0609A2F2 jsr @r0 ; mov r8,r4
    c.r[9] += c.r[0]; goto L_0609A314;  // 0609A2F6 bra 0x0609A314 ; add r0,r9
L_0609A2FA:
    c.r[0] = ld32(0x0609A3ACu);  // 0609A2FA mov.l 0x0609A3AC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609A300u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609A300u) return; }  // 0609A2FC jsr @r0 ; mov r8,r4
    c.t = c.r[0] == c.r[9];  // 0609A300 cmp/eq r9,r0
    { const bool k = c.t; c.r[0] = c.r[9]; if (k) { goto L_0609A39A; } }  // 0609A302 bt/s 0x0609A39A ; mov r9,r0
    c.r[0] = ld32(0x0609A3B0u);  // 0609A306 mov.l 0x0609A3B0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609A30Cu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609A30Cu) return; }  // 0609A308 jsr @r0 ; mov r8,r4
    c.r[10] = c.r[0];  // 0609A30C mov r0,r10
    c.t = (int32_t)c.r[10] >= 0;  // 0609A30E cmp/pz r10
    { const bool k = !c.t; c.r[0] = 0xFFFFFFFFu; if (k) { goto L_0609A39A; } }  // 0609A310 bf/s 0x0609A39A ; mov #-1,r0
L_0609A314:
    c.r[11] += 76;  // 0609A314 add #76,r11
    c.r[1] = ld32(c.r[11]);  // 0609A316 mov.l @r11,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609A318 tst r1,r1
    if (!c.t) { goto L_0609A358; }  // 0609A31A bf 0x0609A358
    c.r[1] = ld32(c.r[8] + 32);  // 0609A31C mov.l @(32,r8),r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[9];  // 0609A31E cmp/gt r9,r1
    { const bool k = c.t; c.t = (int32_t)c.r[10] > 0; if (k) { goto L_0609A338; } }  // 0609A320 bt/s 0x0609A338 ; cmp/pl r10
    c.r[0] = ld32(0x0609A3ACu);  // 0609A324 mov.l 0x0609A3AC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609A32Au; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609A32Au) return; }  // 0609A326 jsr @r0 ; mov r8,r4
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[0];  // 0609A32A cmp/ge r0,r9
    { const bool k = c.t; c.t = (int32_t)c.r[10] > 0; if (k) { goto L_0609A338; } }  // 0609A32C bt/s 0x0609A338 ; cmp/pl r10
    c.r[1] = ld32(c.r[8] + 32);  // 0609A330 mov.l @(32,r8),r1
    c.r[10] = c.r[9];  // 0609A332 mov r9,r10
    c.r[10] -= c.r[1];  // 0609A334 sub r1,r10
    c.t = (int32_t)c.r[10] > 0;  // 0609A336 cmp/pl r10
L_0609A338:
    if (!c.t) { goto L_0609A350; }  // 0609A338 bf 0x0609A350
    c.r[4] = ld32(c.r[8] + 4);  // 0609A33A mov.l @(4,r8),r4
    c.r[0] = ld32(0x0609A3B4u);  // 0609A33C mov.l 0x0609A3B4,r0
    c.r[6] = c.r[10];  // 0609A33E mov r10,r6
    { const uint32_t x = c.r[0]; c.pr = 0x0609A344u; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609A344u) return; }  // 0609A340 jsr @r0 ; mov #0,r5
    c.r[0] = ld32(0x0609A3B8u);  // 0609A344 mov.l 0x0609A3B8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609A34Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609A34Au) return; }  // 0609A346 jsr @r0 ; nop
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609A34A tst r0,r0
    { const bool k = !c.t; c.r[0] = 0xFFFFFFFFu; if (k) { goto L_0609A39A; } }  // 0609A34C bf/s 0x0609A39A ; mov #-1,r0
L_0609A350:
    st32(c.r[8] + 32, c.r[9]);  // 0609A350 mov.l r9,@(32,r8)
    c.r[1] = 0x0u;  // 0609A352 mov #0,r1
    st32(c.r[8] + 36, c.r[1]); goto L_0609A394;  // 0609A354 bra 0x0609A394 ; mov.l r1,@(36,r8)
L_0609A358:
    c.r[0] = c.r[1];  // 0609A358 mov r1,r0
    c.t = c.r[0] == 0x1u;  // 0609A35A cmp/eq #1,r0
    { const bool k = !c.t; c.r[0] = c.r[12]; if (k) { goto L_0609A394; } }  // 0609A35C bf/s 0x0609A394 ; mov r12,r0
    c.t = c.r[0] == 0x1u;  // 0609A360 cmp/eq #1,r0
    if (!c.t) { goto L_0609A372; }  // 0609A362 bf 0x0609A372
    c.r[0] = ld32(0x0609A3B0u);  // 0609A364 mov.l 0x0609A3B0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609A36Au; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609A36Au) return; }  // 0609A366 jsr @r0 ; mov r8,r4
    c.r[10] = c.r[0];  // 0609A36A mov r0,r10
    c.t = (int32_t)c.r[10] >= 0;  // 0609A36C cmp/pz r10
    { const bool k = !c.t; c.r[0] = 0xFFFFFFFFu; if (k) { goto L_0609A39A; } }  // 0609A36E bf/s 0x0609A39A ; mov #-1,r0
L_0609A372:
    c.r[1] = ld32(c.r[8] + 32);  // 0609A372 mov.l @(32,r8),r1
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[1];  // 0609A374 cmp/ge r1,r9
    { const bool k = !c.t; c.r[1] += c.r[10]; if (k) { goto L_0609A380; } }  // 0609A376 bf/s 0x0609A380 ; add r10,r1
    c.r[1] += 1;  // 0609A37A add #1,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 0609A37C cmp/gt r1,r9
    if (!c.t) { goto L_0609A38E; }  // 0609A37E bf 0x0609A38E
L_0609A380:
    c.r[0] = ld32(0x0609A3BCu);  // 0609A380 mov.l 0x0609A3BC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609A386u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609A386u) return; }  // 0609A382 jsr @r0 ; mov r8,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609A386 tst r0,r0
    { const bool k = !c.t; c.r[0] = 0xFFFFFFFFu; if (k) { goto L_0609A39A; } }  // 0609A388 bf/s 0x0609A39A ; mov #-1,r0
    st32(c.r[8] + 32, c.r[9]);  // 0609A38C mov.l r9,@(32,r8)
L_0609A38E:
    c.r[1] = ld32(c.r[8] + 32);  // 0609A38E mov.l @(32,r8),r1
    c.r[9] -= c.r[1];  // 0609A390 sub r1,r9
    st32(c.r[8] + 36, c.r[9]);  // 0609A392 mov.l r9,@(36,r8)
L_0609A394:
    c.r[0] = ld32(0x0609A3ACu);  // 0609A394 mov.l 0x0609A3AC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609A39Au; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609A39Au) return; }  // 0609A396 jsr @r0 ; mov r8,r4
L_0609A39A:
    c.r[15] = c.r[14];  // 0609A39A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609A39C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609A39E mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0609A3A0 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0609A3A2 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0609A3A4 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609A3A6 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609A3A8 rts ; mov.l @r15+,r8
}

void f_0609A3C0(SH2Context& c) {
    ran[2422] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609A3C0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609A3C2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0609A3C4 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609A3C6 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609A3C8 sts.l pr,@-r15
    c.r[15] -= 20;  // 0609A3CA add #-20,r15
    c.r[14] = c.r[15];  // 0609A3CC mov r15,r14
    c.r[10] = c.r[4];  // 0609A3CE mov r4,r10
    c.r[6] = c.r[5];  // 0609A3D0 mov r5,r6
    c.r[1] = ld32(0x0609A480u);  // 0609A3D2 mov.l 0x0609A480,r1
    c.r[8] = ld32(c.r[1]);  // 0609A3D4 mov.l @r1,r8
    c.r[9] = c.r[10];  // 0609A3D6 mov r10,r9
    c.r[1] = (uint32_t)(int16_t)ld16(0x0609A47Cu);  // 0609A3D8 mov.w 0x0609A47C,r1
    c.r[8] += c.r[1];  // 0609A3DA add r1,r8
    c.r[1] = ld32(c.r[8] + 16);  // 0609A3DC mov.l @(16,r8),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609A3DE tst r1,r1
    { const bool k = !c.t; c.r[9] += 28; if (k) { goto L_0609A40C; } }  // 0609A3E0 bf/s 0x0609A40C ; add #28,r9
    c.r[1] = c.r[14];  // 0609A3E4 mov r14,r1
    c.r[1] += 4;  // 0609A3E6 add #4,r1
    c.r[5] = ld32(c.r[9] + 36);  // 0609A3E8 mov.l @(36,r9),r5
    c.r[0] = ld32(0x0609A484u);  // 0609A3EA mov.l 0x0609A484,r0
    c.r[4] = ld32(c.r[9] + 4);  // 0609A3EC mov.l @(4,r9),r4
    c.r[7] = c.r[14];  // 0609A3EE mov r14,r7
    { const uint32_t x = c.r[0]; c.pr = 0x0609A3F4u; c.r[15] -= 4; st32(c.r[15], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609A3F4u) return; }  // 0609A3F0 jsr @r0 ; mov.l r1,@-r15
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609A3F4 tst r0,r0
    { const bool k = !c.t; c.r[15] += 4; if (k) { goto L_0609A40C; } }  // 0609A3F6 bf/s 0x0609A40C ; add #4,r15
    c.r[0] = ld32(0x0609A488u);  // 0609A3FA mov.l 0x0609A488,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609A400u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609A400u) return; }  // 0609A3FC jsr @r0 ; nop
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609A400 tst r0,r0
    { const bool k = !c.t; c.r[1] = ld32(c.r[14] + 4); if (k) { goto L_0609A40C; } }  // 0609A402 bf/s 0x0609A40C ; mov.l @(4,r14),r1
    c.t = (int32_t)c.r[1] > 0;  // 0609A406 cmp/pl r1
    { const bool k = c.t; c.r[7] = c.r[14]; if (k) { goto L_0609A410; } }  // 0609A408 bt/s 0x0609A410 ; mov r14,r7
L_0609A40C:
    c.r[0] = 0x0u; goto L_0609A46C;  // 0609A40C bra 0x0609A46C ; mov #0,r0
L_0609A410:
    c.r[7] += 8;  // 0609A410 add #8,r7
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 0609A412 mov.l r0,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 0609A414 mov.l r0,@-r15
    c.r[1] = c.r[14];  // 0609A416 mov r14,r1
    c.r[1] += 16;  // 0609A418 add #16,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0609A41A mov.l r1,@-r15
    c.r[1] = c.r[14];  // 0609A41C mov r14,r1
    c.r[1] += 12;  // 0609A41E add #12,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0609A420 mov.l r1,@-r15
    c.r[1] = ld32(0x0609A48Cu);  // 0609A422 mov.l 0x0609A48C,r1
    c.r[6] = 0x0u;  // 0609A424 mov #0,r6
    c.r[5] = 0x0u;  // 0609A426 mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0609A42Cu; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609A42Cu) return; }  // 0609A428 jsr @r1 ; mov r10,r4
    c.r[0] = ld32(0x0609A490u);  // 0609A42C mov.l 0x0609A490,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609A432u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609A432u) return; }  // 0609A42E jsr @r0 ; mov r9,r4
    c.r[2] = ld32(c.r[14]);  // 0609A432 mov.l @r14,r2
    c.r[1] = ld32(c.r[14] + 12);  // 0609A434 mov.l @(12,r14),r1
    c.r[0] += c.r[2];  // 0609A436 add r2,r0
    c.t = (int32_t)c.r[0] >= (int32_t)c.r[1];  // 0609A438 cmp/ge r1,r0
    { const bool k = !c.t; c.r[15] += 16; if (k) { goto L_0609A452; } }  // 0609A43A bf/s 0x0609A452 ; add #16,r15
    c.r[1] = ld32(c.r[14] + 16);  // 0609A43E mov.l @(16,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609A440 tst r1,r1
    { const bool k = c.t; c.t = (int32_t)c.r[2] > 0; if (k) { goto L_0609A452; } }  // 0609A442 bt/s 0x0609A452 ; cmp/pl r2
    { const bool k = !c.t; c.r[2] = ld32(c.r[14] + 8); if (k) { goto L_0609A452; } }  // 0609A446 bf/s 0x0609A452 ; mov.l @(8,r14),r2
    c.r[2] -= c.r[1];  // 0609A44A sub r1,r2
    c.r[1] = ld32(c.r[14] + 4);  // 0609A44C mov.l @(4,r14),r1
    c.r[1] -= c.r[2];  // 0609A44E sub r2,r1
    st32(c.r[14] + 4, c.r[1]);  // 0609A450 mov.l r1,@(4,r14)
L_0609A452:
    c.r[0] = ld32(0x0609A494u);  // 0609A452 mov.l 0x0609A494,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609A458u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609A458u) return; }  // 0609A454 jsr @r0 ; nop
    c.r[1] = 0x0u;  // 0609A458 mov #0,r1
    st32(c.r[8] + 4, c.r[1]);  // 0609A45A mov.l r1,@(4,r8)
    c.r[1] = ld32(c.r[14] + 4);  // 0609A45C mov.l @(4,r14),r1
    st32(c.r[8], c.r[0]);  // 0609A45E mov.l r0,@r8
    st32(c.r[8] + 8, c.r[1]);  // 0609A460 mov.l r1,@(8,r8)
    c.r[1] = ld32(c.r[14]);  // 0609A462 mov.l @r14,r1
    c.r[0] = c.r[8];  // 0609A464 mov r8,r0
    st32(c.r[8] + 12, c.r[1]);  // 0609A466 mov.l r1,@(12,r8)
    c.r[1] = 0x1u;  // 0609A468 mov #1,r1
    st32(c.r[8] + 16, c.r[1]);  // 0609A46A mov.l r1,@(16,r8)
L_0609A46C:
    c.r[14] += 20;  // 0609A46C add #20,r14
    c.r[15] = c.r[14];  // 0609A46E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609A470 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609A472 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0609A474 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609A476 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609A478 rts ; mov.l @r15+,r8
}

void f_0609A498(SH2Context& c) {
    ran[2423] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609A498 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609A49A sts.l pr,@-r15
    c.r[6] = ld32(c.r[4] + 12);  // 0609A49C mov.l @(12,r4),r6
    c.r[1] = ld32(c.r[5] + 36);  // 0609A49E mov.l @(36,r5),r1
    c.r[14] = c.r[15];  // 0609A4A0 mov r15,r14
    c.r[4] = ld32(c.r[5] + 4);  // 0609A4A2 mov.l @(4,r5),r4
    c.r[0] = ld32(0x0609A4C8u);  // 0609A4A4 mov.l 0x0609A4C8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609A4AAu; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609A4AAu) return; }  // 0609A4A6 jsr @r0 ; mov r1,r5
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609A4AA tst r0,r0
    { const bool k = !c.t; c.r[0] = 0x0u; if (k) { goto L_0609A4BE; } }  // 0609A4AC bf/s 0x0609A4BE ; mov #0,r0
    c.r[0] = ld32(0x0609A4CCu);  // 0609A4B0 mov.l 0x0609A4CC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609A4B6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609A4B6u) return; }  // 0609A4B2 jsr @r0 ; nop
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609A4B6 tst r0,r0
    { const bool k = c.t; c.r[0] = 0x1u; if (k) { goto L_0609A4BE; } }  // 0609A4B8 bt/s 0x0609A4BE ; mov #1,r0
    c.r[0] = 0x0u;  // 0609A4BC mov #0,r0
L_0609A4BE:
    c.r[15] = c.r[14];  // 0609A4BE mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609A4C0 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609A4C2 rts ; mov.l @r15+,r14
}

void f_0609A4D0(SH2Context& c) {
    ran[2424] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609A4D0 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0609A4D2 mov r15,r14
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609A4D4 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = 0x0u; c.pc = x; return; }  // 0609A4D6 rts ; mov #0,r0
}

void f_0609A4DC(SH2Context& c) {
    ran[2425] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609A4DC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609A4DE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0609A4E0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609A4E2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609A4E4 sts.l pr,@-r15
    c.r[15] -= 4;  // 0609A4E6 add #-4,r15
    c.r[14] = c.r[15];  // 0609A4E8 mov r15,r14
    c.r[10] = c.r[4];  // 0609A4EA mov r4,r10
    c.r[9] = c.r[5];  // 0609A4EC mov r5,r9
    c.r[8] = c.r[6];  // 0609A4EE mov r6,r8
    c.r[0] = ld32(0x0609A51Cu);  // 0609A4F0 mov.l 0x0609A51C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609A4F6u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609A4F6u) return; }  // 0609A4F2 jsr @r0 ; mov r14,r4
    c.r[0] = c.r[8];  // 0609A4F6 mov r8,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0609A4F8 cmp/eq #-1,r0
    if (!c.t) { goto L_0609A4FE; }  // 0609A4FA bf 0x0609A4FE
    c.r[8] = ld32(c.r[9] + 12);  // 0609A4FC mov.l @(12,r9),r8
L_0609A4FE:
    c.r[0] = ld32(0x0609A520u);  // 0609A4FE mov.l 0x0609A520,r0
    c.r[6] = 0x1u;  // 0609A500 mov #1,r6
    c.r[5] = c.r[8];  // 0609A502 mov r8,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0609A508u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609A508u) return; }  // 0609A504 jsr @r0 ; mov r10,r4
    c.r[1] = 0x0u;  // 0609A508 mov #0,r1
    st32(c.r[9] + 16, c.r[1]);  // 0609A50A mov.l r1,@(16,r9)
    c.r[14] += 4;  // 0609A50C add #4,r14
    c.r[15] = c.r[14];  // 0609A50E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609A510 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609A512 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0609A514 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609A516 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609A518 rts ; mov.l @r15+,r8
}

void f_0609A524(SH2Context& c) {
    ran[2426] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609A524 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609A526 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0609A528 mov r15,r14
    c.r[1] = c.r[5];  // 0609A52A mov r5,r1
    c.r[5] = ld32(c.r[4] + 28);  // 0609A52C mov.l @(28,r4),r5
    c.r[0] = ld32(0x0609A53Cu);  // 0609A52E mov.l 0x0609A53C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609A534u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609A534u) return; }  // 0609A530 jsr @r0 ; mov r1,r4
    c.r[15] = c.r[14];  // 0609A534 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609A536 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609A538 rts ; mov.l @r15+,r14
}

void f_0609A540(SH2Context& c) {
    ran[2427] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609A540 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609A542 sts.l pr,@-r15
    c.r[5] = ld32(c.r[4] + 28);  // 0609A544 mov.l @(28,r4),r5
    c.r[14] = c.r[15];  // 0609A546 mov r15,r14
    c.r[0] = ld32(0x0609A56Cu);  // 0609A548 mov.l 0x0609A56C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609A54Eu; c.r[4] = ld32(c.r[4] + 12); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609A54Eu) return; }  // 0609A54A jsr @r0 ; mov.l @(12,r4),r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609A54E tst r0,r0
    { const bool k = !c.t; c.r[0] = 0x0u; if (k) { goto L_0609A562; } }  // 0609A550 bf/s 0x0609A562 ; mov #0,r0
    c.r[0] = ld32(0x0609A570u);  // 0609A554 mov.l 0x0609A570,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609A55Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609A55Au) return; }  // 0609A556 jsr @r0 ; nop
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609A55A tst r0,r0
    { const bool k = c.t; c.r[0] = 0x1u; if (k) { goto L_0609A562; } }  // 0609A55C bt/s 0x0609A562 ; mov #1,r0
    c.r[0] = 0x0u;  // 0609A560 mov #0,r0
L_0609A562:
    c.r[15] = c.r[14];  // 0609A562 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609A564 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609A566 rts ; mov.l @r15+,r14
}

void f_0609A574(SH2Context& c) {
    ran[2428] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609A574 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609A576 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609A578 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0609A57A mov r15,r14
    c.r[0] = ld32(0x0609A598u);  // 0609A57C mov.l 0x0609A598,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609A582u; c.r[8] = c.r[4]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609A582u) return; }  // 0609A57E jsr @r0 ; mov r4,r8
    c.t = (int32_t)c.r[0] >= 0;  // 0609A582 cmp/pz r0
    if (!c.t) { goto L_0609A58C; }  // 0609A584 bf 0x0609A58C
    st32(c.r[8] + 28, c.r[0]);  // 0609A586 mov.l r0,@(28,r8)
    c.r[0] = 0x1u; goto L_0609A58E;  // 0609A588 bra 0x0609A58E ; mov #1,r0
L_0609A58C:
    c.r[0] = 0x0u;  // 0609A58C mov #0,r0
L_0609A58E:
    c.r[15] = c.r[14];  // 0609A58E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609A590 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609A592 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609A594 rts ; mov.l @r15+,r8
}

void f_0609A59C(SH2Context& c) {
    ran[2429] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609A59C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609A59E sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0609A5A0 mov r15,r14
    c.r[0] = ld32(0x0609A5B0u);  // 0609A5A2 mov.l 0x0609A5B0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609A5A8u; c.r[4] = ld32(c.r[4] + 28); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609A5A8u) return; }  // 0609A5A4 jsr @r0 ; mov.l @(28,r4),r4
    c.r[15] = c.r[14];  // 0609A5A8 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609A5AA lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609A5AC rts ; mov.l @r15+,r14
}

void f_0609A5B4(SH2Context& c) {
    ran[2430] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609A5B4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609A5B6 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0609A5B8 mov r15,r14
    c.r[0] = ld32(0x0609A5C8u);  // 0609A5BA mov.l 0x0609A5C8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609A5C0u; c.r[4] = ld32(c.r[4] + 28); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609A5C0u) return; }  // 0609A5BC jsr @r0 ; mov.l @(28,r4),r4
    c.r[15] = c.r[14];  // 0609A5C0 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609A5C2 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609A5C4 rts ; mov.l @r15+,r14
}

void f_0609A5CC(SH2Context& c) {
    ran[2431] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609A5CC mov.l r14,@-r15
    c.t = (c.r[4] & c.r[4]) == 0;  // 0609A5CE tst r4,r4
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0609A5DC; } }  // 0609A5D0 bt/s 0x0609A5DC ; mov r15,r14
    c.r[3] = ld32(0x0609A5F4u);  // 0609A5D4 mov.l 0x0609A5F4,r3
    c.r[1] = ld32(c.r[3]);  // 0609A5D6 mov.l @r3,r1
    c.r[2] = 0x1u; goto L_0609A5E2;  // 0609A5D8 bra 0x0609A5E2 ; mov #1,r2
L_0609A5DC:
    c.r[3] = ld32(0x0609A5F4u);  // 0609A5DC mov.l 0x0609A5F4,r3
    c.r[1] = ld32(c.r[3]);  // 0609A5DE mov.l @r3,r1
    c.r[2] = 0x0u;  // 0609A5E0 mov #0,r2
L_0609A5E2:
    c.r[1] += 23;  // 0609A5E2 add #23,r1
    st8(c.r[1], c.r[2]);  // 0609A5E4 mov.b r2,@r1
    c.r[1] = ld32(c.r[3]);  // 0609A5E6 mov.l @r3,r1
    c.r[1] += 47;  // 0609A5E8 add #47,r1
    st8(c.r[1], c.r[2]);  // 0609A5EA mov.b r2,@r1
    c.r[15] = c.r[14];  // 0609A5EC mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609A5EE rts ; mov.l @r15+,r14
}

void f_0609A5F8(SH2Context& c) {
    ran[2432] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609A5F8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609A5FA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0609A5FC mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609A5FE mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609A600 sts.l pr,@-r15
    c.r[15] -= 20;  // 0609A602 add #-20,r15
    c.r[14] = c.r[15];  // 0609A604 mov r15,r14
    c.r[9] = c.r[5];  // 0609A606 mov r5,r9
    c.r[1] = ld32(0x0609A7A8u);  // 0609A608 mov.l 0x0609A7A8,r1
    st32(c.r[1], c.r[4]);  // 0609A60A mov.l r4,@r1
    c.r[1] = ld32(0x0609A7ACu);  // 0609A60C mov.l 0x0609A7AC,r1
    c.r[2] = 0x0u;  // 0609A60E mov #0,r2
    st32(c.r[1], c.r[2]);  // 0609A610 mov.l r2,@r1
    c.r[8] = ld32(0x0609A7B0u);  // 0609A612 mov.l 0x0609A7B0,r8
    c.r[1] = ld32(0x0609A7B4u);  // 0609A614 mov.l 0x0609A7B4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609A61Au; st32(c.r[8], c.r[2]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609A61Au) return; }  // 0609A616 jsr @r1 ; mov.l r2,@r8
    c.r[1] = ld32(0x0609A7B8u);  // 0609A61A mov.l 0x0609A7B8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609A620u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609A620u) return; }  // 0609A61C jsr @r1 ; mov r9,r4
    c.r[0] = ld32(0x0609A7BCu);  // 0609A620 mov.l 0x0609A7BC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609A626u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609A626u) return; }  // 0609A622 jsr @r0 ; mov r14,r4
    c.r[0] = ld32(c.r[8]);  // 0609A626 mov.l @r8,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609A628 tst r0,r0
    if (c.t) { goto L_0609A630; }  // 0609A62A bt 0x0609A630
    goto L_0609A78C;  // 0609A62C bra 0x0609A78C ; nop
L_0609A630:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[14]);  // 0609A630 mov.b @r14,r0
    c.r[0] &= 0xFu;  // 0609A632 and #15,r0
    c.t = c.r[0] == 0x9u;  // 0609A634 cmp/eq #9,r0
    { const bool k = !c.t; c.r[0] = 0xFFFFFFF6u; if (k) { goto L_0609A63E; } }  // 0609A636 bf/s 0x0609A63E ; mov #-10,r0
    goto L_0609A78C;  // 0609A63A bra 0x0609A78C ; nop
L_0609A63E:
    c.r[0] = ld32(0x0609A7C0u);  // 0609A63E mov.l 0x0609A7C0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609A644u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609A644u) return; }  // 0609A640 jsr @r0 ; nop
    c.r[0] = ld32(0x0609A7C4u);  // 0609A644 mov.l 0x0609A7C4,r0
    c.r[7] = 0xFu;  // 0609A646 mov #15,r7
    c.r[6] = 0x4u;  // 0609A648 mov #4,r6
    c.r[5] = 0x0u;  // 0609A64A mov #0,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0609A650u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609A650u) return; }  // 0609A64C jsr @r0 ; mov #0,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609A650 tst r0,r0
    { const bool k = c.t; st32(c.r[14] + 12, c.r[0]); if (k) { goto L_0609A65A; } }  // 0609A652 bt/s 0x0609A65A ; mov.l r0,@(12,r14)
    goto L_0609A78A;  // 0609A656 bra 0x0609A78A ; nop
L_0609A65A:
    c.r[8] = 0x0u;  // 0609A65A mov #0,r8
    c.r[9] = ld32(0x0609A7C8u);  // 0609A65C mov.l 0x0609A7C8,r9
    c.r[5] = 0xFFFFFFFFu;  // 0609A65E mov #-1,r5
L_0609A660:
    { const uint32_t x = c.r[9]; c.pr = 0x0609A664u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609A664u) return; }  // 0609A660 jsr @r9 ; mov #0,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609A664 tst r0,r0
    { const bool k = c.t; st32(c.r[14] + 12, c.r[0]); if (k) { goto L_0609A684; } }  // 0609A666 bt/s 0x0609A684 ; mov.l r0,@(12,r14)
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0609A66A cmp/eq #-1,r0
    { const bool k = c.t; c.r[0] = 0xFFFFFFFEu; if (k) { goto L_0609A674; } }  // 0609A66C bt/s 0x0609A674 ; mov #-2,r0
    goto L_0609A78C;  // 0609A670 bra 0x0609A78C ; nop
L_0609A674:
    c.r[1] = ld32(0x0609A7CCu);  // 0609A674 mov.l 0x0609A7CC,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 0609A676 cmp/gt r1,r8
    { const bool k = !c.t; c.r[8] += 1; if (k) { goto L_0609A680; } }  // 0609A678 bf/s 0x0609A680 ; add #1,r8
    goto L_0609A78C;  // 0609A67C bra 0x0609A78C ; nop
L_0609A680:
    c.r[5] = 0xFFFFFFFFu; SH2_POLL(c); goto L_0609A660;  // 0609A680 bra 0x0609A660 ; mov #-1,r5
L_0609A684:
    c.r[1] = ld32(0x0609A7A8u);  // 0609A684 mov.l 0x0609A7A8,r1
    c.r[2] = ld32(c.r[1]);  // 0609A686 mov.l @r1,r2
    c.r[8] = ld32(0x0609A7D0u);  // 0609A688 mov.l 0x0609A7D0,r8
    c.r[1] = ld32(0x0609A7CCu);  // 0609A68A mov.l 0x0609A7CC,r1
    st32(c.r[2] + 60, c.r[1]);  // 0609A68C mov.l r1,@(60,r2)
L_0609A68E:
    { const uint32_t x = c.r[8]; c.pr = 0x0609A692u; c.r[4] = 0x40u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609A692u) return; }  // 0609A68E jsr @r8 ; mov #64,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609A692 tst r0,r0
    if (!c.t) { goto L_0609A6A6; }  // 0609A694 bf 0x0609A6A6
    c.r[1] = ld32(0x0609A7A8u);  // 0609A696 mov.l 0x0609A7A8,r1
    c.r[1] = ld32(c.r[1]);  // 0609A698 mov.l @r1,r1
    c.r[2] = ld32(c.r[1] + 60);  // 0609A69A mov.l @(60,r1),r2
    c.r[2] -= 1; c.t = c.r[2] == 0;  // 0609A69C dt r2
    { const bool k = !c.t; st32(c.r[1] + 60, c.r[2]); if (k) { SH2_POLL(c); goto L_0609A68E; } }  // 0609A69E bf/s 0x0609A68E ; mov.l r2,@(60,r1)
    c.r[0] = 0xFFFFFFFEu; goto L_0609A78C;  // 0609A6A2 bra 0x0609A78C ; mov #-2,r0
L_0609A6A6:
    c.r[1] = ld32(0x0609A7A8u);  // 0609A6A6 mov.l 0x0609A7A8,r1
    c.r[2] = ld32(c.r[1]);  // 0609A6A8 mov.l @r1,r2
    c.r[1] = 0x0u;  // 0609A6AA mov #0,r1
    st32(c.r[2] + 60, c.r[1]);  // 0609A6AC mov.l r1,@(60,r2)
    c.r[1] = ld32(0x0609A7D4u);  // 0609A6AE mov.l 0x0609A7D4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609A6B4u; c.r[4] = 0xFFFFFFE7u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609A6B4u) return; }  // 0609A6B0 jsr @r1 ; mov #-25,r4
    c.r[8] = 0x0u;  // 0609A6B4 mov #0,r8
    c.r[9] = 0x0u;  // 0609A6B6 mov #0,r9
    c.r[10] = 0x1u;  // 0609A6B8 mov #1,r10
L_0609A6BA:
    c.r[0] = ld32(0x0609A7D0u);  // 0609A6BA mov.l 0x0609A7D0,r0
    c.r[4] = (uint32_t)(int16_t)ld16(0x0609A79Cu);  // 0609A6BC mov.w 0x0609A79C,r4
    { const uint32_t x = c.r[0]; c.pr = 0x0609A6C2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609A6C2u) return; }  // 0609A6BE jsr @r0 ; nop
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609A6C2 tst r0,r0
    { const bool k = c.t; c.t = (c.r[9] & c.r[9]) == 0; if (k) { goto L_0609A704; } }  // 0609A6C4 bt/s 0x0609A704 ; tst r9,r9
    c.r[1] = ld32(0x0609A7D4u);  // 0609A6C8 mov.l 0x0609A7D4,r1
    c.r[4] = (uint32_t)(int16_t)ld16(0x0609A79Eu);  // 0609A6CA mov.w 0x0609A79E,r4
    { const uint32_t x = c.r[1]; c.pr = 0x0609A6D0u; c.r[8] += 1; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609A6D0u) return; }  // 0609A6CC jsr @r1 ; add #1,r8
    c.r[1] = (uint32_t)(int16_t)ld16(0x0609A7A0u);  // 0609A6D0 mov.w 0x0609A7A0,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 0609A6D2 cmp/gt r1,r8
    { const bool k = c.t; c.r[0] = 0xFFFFFFFEu; if (k) { goto L_0609A78C; } }  // 0609A6D4 bt/s 0x0609A78C ; mov #-2,r0
    c.r[0] = ld32(0x0609A7BCu);  // 0609A6D8 mov.l 0x0609A7BC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609A6DEu; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609A6DEu) return; }  // 0609A6DA jsr @r0 ; mov r14,r4
    c.r[1] = ld32(0x0609A7B0u);  // 0609A6DE mov.l 0x0609A7B0,r1
    c.r[0] = ld32(c.r[1]);  // 0609A6E0 mov.l @r1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609A6E2 tst r0,r0
    if (!c.t) { goto L_0609A78C; }  // 0609A6E4 bf 0x0609A78C
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[14]);  // 0609A6E6 mov.b @r14,r0
    c.r[0] &= 0xFu;  // 0609A6E8 and #15,r0
    c.t = (int32_t)c.r[0] >= (int32_t)c.r[10];  // 0609A6EA cmp/ge r10,r0
    { const bool k = !c.t; c.t = (c.r[9] & c.r[9]) == 0; if (k) { goto L_0609A704; } }  // 0609A6EC bf/s 0x0609A704 ; tst r9,r9
    c.r[1] = 0x2u;  // 0609A6F0 mov #2,r1
    c.t = (int32_t)c.r[0] > (int32_t)c.r[1];  // 0609A6F2 cmp/gt r1,r0
    { const bool k = !c.t; c.t = c.r[0] == 0x9u; if (k) { goto L_0609A700; } }  // 0609A6F4 bf/s 0x0609A700 ; cmp/eq #9,r0
    { const bool k = !c.t; c.t = (c.r[9] & c.r[9]) == 0; if (k) { goto L_0609A704; } }  // 0609A6F8 bf/s 0x0609A704 ; tst r9,r9
    c.r[0] = 0xFFFFFFF6u; goto L_0609A78C;  // 0609A6FC bra 0x0609A78C ; mov #-10,r0
L_0609A700:
    c.r[9] = c.r[10];  // 0609A700 mov r10,r9
    c.t = (c.r[9] & c.r[9]) == 0;  // 0609A702 tst r9,r9
L_0609A704:
    { const bool k = c.t; c.r[4] = c.r[14]; if (k) { SH2_POLL(c); goto L_0609A6BA; } }  // 0609A704 bt/s 0x0609A6BA ; mov r14,r4
    c.r[0] = ld32(0x0609A7D8u);  // 0609A708 mov.l 0x0609A7D8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609A70Eu; c.r[4] += 12; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609A70Eu) return; }  // 0609A70A jsr @r0 ; add #12,r4
    c.r[1] = ld32(0x0609A7DCu);  // 0609A70E mov.l 0x0609A7DC,r1
    c.r[10] = ld32(c.r[1]);  // 0609A710 mov.l @r1,r10
    c.r[0] = ld32(0x0609A7E0u);  // 0609A712 mov.l 0x0609A7E0,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0609A7A2u);  // 0609A714 mov.w 0x0609A7A2,r1
    c.r[10] += c.r[1];  // 0609A716 add r1,r10
    { const uint32_t x = c.r[0]; c.pr = 0x0609A71Cu; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609A71Cu) return; }  // 0609A718 jsr @r0 ; mov r10,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609A71C tst r0,r0
    { const bool k = !c.t; st32(c.r[14] + 12, c.r[0]); if (k) { goto L_0609A78A; } }  // 0609A71E bf/s 0x0609A78A ; mov.l r0,@(12,r14)
    c.r[8] = c.r[14];  // 0609A722 mov r14,r8
    c.r[8] += 16;  // 0609A724 add #16,r8
    c.r[9] = ld32(0x0609A7E4u);  // 0609A726 mov.l 0x0609A7E4,r9
    c.r[5] = c.r[8];  // 0609A728 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0609A72Eu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609A72Eu) return; }  // 0609A72A jsr @r9 ; mov #0,r4
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0609A72E mov.b @r8,r4
    c.r[5] = c.r[8];  // 0609A730 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0609A736u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609A736u) return; }  // 0609A732 jsr @r9 ; extu.b r4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0609A736 mov.b @r8,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0609A738 extu.b r1,r1
    c.r[1] <<= 2;  // 0609A73A shll2 r1
    c.r[1] += c.r[10];  // 0609A73C add r10,r1
    c.r[1] -= 4;  // 0609A73E add #-4,r1
    c.r[2] = ld32(c.r[1]);  // 0609A740 mov.l @r1,r2
    c.r[1] = ld32(0x0609A7E8u);  // 0609A742 mov.l 0x0609A7E8,r1
    c.r[2] &= c.r[1];  // 0609A744 and r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0609A746 tst r2,r2
    { const bool k = c.t; c.r[0] = 0xFFFFFFF1u; if (k) { goto L_0609A78C; } }  // 0609A748 bt/s 0x0609A78C ; mov #-15,r0
    c.r[5] = (uint32_t)(int16_t)ld16(0x0609A7A4u);  // 0609A74C mov.w 0x0609A7A4,r5
    c.r[4] = (uint32_t)(int16_t)ld16(0x0609A7A6u);  // 0609A74E mov.w 0x0609A7A6,r4
    c.r[0] = ld32(0x0609A7ECu);  // 0609A750 mov.l 0x0609A7EC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609A756u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609A756u) return; }  // 0609A752 jsr @r0 ; nop
    st32(c.r[14] + 12, c.r[0]);  // 0609A756 mov.l r0,@(12,r14)
    c.r[1] = ld32(0x0609A7A8u);  // 0609A758 mov.l 0x0609A7A8,r1
    c.r[2] = ld32(c.r[1]);  // 0609A75A mov.l @r1,r2
    c.r[1] = ld32(0x0609A7CCu);  // 0609A75C mov.l 0x0609A7CC,r1
    st32(c.r[2] + 60, c.r[1]);  // 0609A75E mov.l r1,@(60,r2)
L_0609A760:
    c.r[0] = ld32(0x0609A7D0u);  // 0609A760 mov.l 0x0609A7D0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609A766u; c.r[4] = 0x40u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609A766u) return; }  // 0609A762 jsr @r0 ; mov #64,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609A766 tst r0,r0
    if (c.t) { goto L_0609A77E; }  // 0609A768 bt 0x0609A77E
    c.r[1] = ld32(0x0609A7A8u);  // 0609A76A mov.l 0x0609A7A8,r1
    c.r[4] = ld32(c.r[1]);  // 0609A76C mov.l @r1,r4
    c.r[0] = ld32(0x0609A7BCu);  // 0609A76E mov.l 0x0609A7BC,r0
    c.r[1] = 0x0u;  // 0609A770 mov #0,r1
    st32(c.r[4] + 60, c.r[1]);  // 0609A772 mov.l r1,@(60,r4)
    { const uint32_t x = c.r[0]; c.pr = 0x0609A778u; c.r[4] += 64; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609A778u) return; }  // 0609A774 jsr @r0 ; add #64,r4
    c.r[1] = ld32(0x0609A7B0u);  // 0609A778 mov.l 0x0609A7B0,r1
    c.r[0] = ld32(c.r[1]); goto L_0609A78C;  // 0609A77A bra 0x0609A78C ; mov.l @r1,r0
L_0609A77E:
    c.r[1] = ld32(0x0609A7A8u);  // 0609A77E mov.l 0x0609A7A8,r1
    c.r[1] = ld32(c.r[1]);  // 0609A780 mov.l @r1,r1
    c.r[2] = ld32(c.r[1] + 60);  // 0609A782 mov.l @(60,r1),r2
    c.r[2] -= 1; c.t = c.r[2] == 0;  // 0609A784 dt r2
    { const bool k = !c.t; st32(c.r[1] + 60, c.r[2]); if (k) { SH2_POLL(c); goto L_0609A760; } }  // 0609A786 bf/s 0x0609A760 ; mov.l r2,@(60,r1)
L_0609A78A:
    c.r[0] = 0xFFFFFFFEu;  // 0609A78A mov #-2,r0
L_0609A78C:
    c.r[14] += 20;  // 0609A78C add #20,r14
    c.r[15] = c.r[14];  // 0609A78E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609A790 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609A792 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0609A794 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609A796 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609A798 rts ; mov.l @r15+,r8
}

void f_0609A7F0(SH2Context& c) {
    ran[2433] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609A7F0 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0609A7F2 mov r15,r14
    c.r[3] = 0x0u;  // 0609A7F4 mov #0,r3
    c.r[6] = ld32(0x0609A824u);  // 0609A7F6 mov.l 0x0609A824,r6
    c.r[5] = 0x1u;  // 0609A7F8 mov #1,r5
    c.r[7] = 0x17u;  // 0609A7FA mov #23,r7
L_0609A7FC:
    c.r[2] = ld32(c.r[6]);  // 0609A7FC mov.l @r6,r2
    c.r[2] += c.r[3];  // 0609A7FE add r3,r2
    c.r[2] += 24;  // 0609A800 add #24,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0609A802 mov.b @r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609A804 tst r1,r1
    if (!c.t) { goto L_0609A810; }  // 0609A806 bf 0x0609A810
    st8(c.r[2], c.r[5]);  // 0609A808 mov.b r5,@r2
    st32(c.r[4], c.r[3]);  // 0609A80A mov.l r3,@r4
    c.r[0] = 0x0u; goto L_0609A81C;  // 0609A80C bra 0x0609A81C ; mov #0,r0
L_0609A810:
    c.r[3] += 1;  // 0609A810 add #1,r3
    c.t = (int32_t)c.r[3] > (int32_t)c.r[7];  // 0609A812 cmp/gt r7,r3
    { const bool k = !c.t; c.r[1] = 0xFFFFFFFFu; if (k) { SH2_POLL(c); goto L_0609A7FC; } }  // 0609A814 bf/s 0x0609A7FC ; mov #-1,r1
    st32(c.r[4], c.r[1]);  // 0609A818 mov.l r1,@r4
    c.r[0] = 0xFFFFFFFDu;  // 0609A81A mov #-3,r0
L_0609A81C:
    c.r[15] = c.r[14];  // 0609A81C mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609A81E rts ; mov.l @r15+,r14
}

void f_0609A828(SH2Context& c) {
    ran[2434] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609A828 mov.l r14,@-r15
    c.r[1] = 0x17u;  // 0609A82A mov #23,r1
    c.t = c.r[4] > c.r[1];  // 0609A82C cmp/hi r1,r4
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0609A836; } }  // 0609A82E bf/s 0x0609A836 ; mov r15,r14
    c.r[0] = 0xFFFFFFFAu; goto L_0609A84E;  // 0609A832 bra 0x0609A84E ; mov #-6,r0
L_0609A836:
    c.r[1] = ld32(0x0609A854u);  // 0609A836 mov.l 0x0609A854,r1
    c.r[2] = ld32(c.r[1]);  // 0609A838 mov.l @r1,r2
    c.r[2] += c.r[4];  // 0609A83A add r4,r2
    c.r[2] += 24;  // 0609A83C add #24,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0609A83E mov.b @r2,r0
    c.t = c.r[0] == 0x1u;  // 0609A840 cmp/eq #1,r0
    { const bool k = !c.t; c.r[1] = 0x0u; if (k) { goto L_0609A84C; } }  // 0609A842 bf/s 0x0609A84C ; mov #0,r1
    st8(c.r[2], c.r[1]);  // 0609A846 mov.b r1,@r2
    c.r[0] = 0x0u; goto L_0609A84E;  // 0609A848 bra 0x0609A84E ; mov #0,r0
L_0609A84C:
    c.r[0] = 0xFFFFFFF9u;  // 0609A84C mov #-7,r0
L_0609A84E:
    c.r[15] = c.r[14];  // 0609A84E mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609A850 rts ; mov.l @r15+,r14
}

void f_0609A858(SH2Context& c) {
    ran[2435] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609A858 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0609A85A mov r15,r14
    c.r[0] = 0x0u;  // 0609A85C mov #0,r0
    c.r[7] = ld32(0x0609A888u);  // 0609A85E mov.l 0x0609A888,r7
    c.r[6] = 0x1u;  // 0609A860 mov #1,r6
    c.r[3] = 0x17u;  // 0609A862 mov #23,r3
L_0609A864:
    c.r[2] = ld32(c.r[7]);  // 0609A864 mov.l @r7,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0609A866 mov.b @(r0,r2),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609A868 tst r1,r1
    if (!c.t) { goto L_0609A874; }  // 0609A86A bf 0x0609A874
    st8(c.r[0] + c.r[2], c.r[6]);  // 0609A86C mov.b r6,@(r0,r2)
    st32(c.r[4], c.r[0]);  // 0609A86E mov.l r0,@r4
    c.r[0] = 0x0u; goto L_0609A880;  // 0609A870 bra 0x0609A880 ; mov #0,r0
L_0609A874:
    c.r[0] += 1;  // 0609A874 add #1,r0
    c.t = (int32_t)c.r[0] > (int32_t)c.r[3];  // 0609A876 cmp/gt r3,r0
    { const bool k = !c.t; c.r[1] = 0xFFFFFFFFu; if (k) { SH2_POLL(c); goto L_0609A864; } }  // 0609A878 bf/s 0x0609A864 ; mov #-1,r1
    st32(c.r[4], c.r[1]);  // 0609A87C mov.l r1,@r4
    c.r[0] = 0xFFFFFFFCu;  // 0609A87E mov #-4,r0
L_0609A880:
    c.r[15] = c.r[14];  // 0609A880 mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609A882 rts ; mov.l @r15+,r14
}

void f_0609A88C(SH2Context& c) {
    ran[2436] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609A88C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609A88E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0609A890 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609A892 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609A894 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0609A896 mov r15,r14
    c.r[2] = ld32(0x0609A910u);  // 0609A898 mov.l 0x0609A910,r2
    c.r[0] = ld32(c.r[2]);  // 0609A89A mov.l @r2,r0
    c.t = c.r[0] == 0xFFFFFFF0u;  // 0609A89C cmp/eq #-16,r0
    { const bool k = !c.t; c.r[9] = c.r[4]; if (k) { goto L_0609A8A6; } }  // 0609A89E bf/s 0x0609A8A6 ; mov r4,r9
    c.r[1] = 0x0u;  // 0609A8A2 mov #0,r1
    st32(c.r[2], c.r[1]);  // 0609A8A4 mov.l r1,@r2
L_0609A8A6:
    c.r[1] = 0x17u;  // 0609A8A6 mov #23,r1
    c.t = c.r[9] > c.r[1];  // 0609A8A8 cmp/hi r1,r9
    { const bool k = c.t; c.r[0] = 0xFFFFFFFAu; if (k) { goto L_0609A902; } }  // 0609A8AA bt/s 0x0609A902 ; mov #-6,r0
    c.r[1] = ld32(0x0609A914u);  // 0609A8AE mov.l 0x0609A914,r1
    c.r[1] = ld32(c.r[1]);  // 0609A8B0 mov.l @r1,r1
    c.r[0] = c.r[1];  // 0609A8B2 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 0609A8B4 mov.b @(r0,r9),r1
    c.r[0] = c.r[1];  // 0609A8B6 mov r1,r0
    c.t = c.r[0] == 0x1u;  // 0609A8B8 cmp/eq #1,r0
    { const bool k = c.t; c.r[6] = 0xFFFFFFFFu; if (k) { goto L_0609A8C6; } }  // 0609A8BA bt/s 0x0609A8C6 ; mov #-1,r6
    c.r[0] = 0xFFFFFFF9u; goto L_0609A902;  // 0609A8BE bra 0x0609A902 ; mov #-7,r0
L_0609A8C2:
    c.r[0] = 0xFFFFFFF4u; goto L_0609A902;  // 0609A8C2 bra 0x0609A902 ; mov #-12,r0
L_0609A8C6:
    c.r[0] = ld32(0x0609A918u);  // 0609A8C6 mov.l 0x0609A918,r0
    c.r[5] = 0x0u;  // 0609A8C8 mov #0,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0609A8CEu; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609A8CEu) return; }  // 0609A8CA jsr @r0 ; mov r9,r4
    c.r[4] = ld32(0x0609A91Cu);  // 0609A8CE mov.l 0x0609A91C,r4
    c.r[8] = ld32(0x0609A920u);  // 0609A8D0 mov.l 0x0609A920,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0609A8D6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609A8D6u) return; }  // 0609A8D2 jsr @r8 ; nop
    c.r[10] = ld32(0x0609A924u);  // 0609A8D6 mov.l 0x0609A924,r10
L_0609A8D8:
    c.r[0] = ld32(0x0609A928u);  // 0609A8D8 mov.l 0x0609A928,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609A8DEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609A8DEu) return; }  // 0609A8DA jsr @r0 ; nop
    c.t = c.r[0] == 0x3u;  // 0609A8DE cmp/eq #3,r0
    { const bool k = c.t; c.r[1] = c.r[0]; if (k) { SH2_POLL(c); goto L_0609A8C2; } }  // 0609A8E0 bt/s 0x0609A8C2 ; mov r0,r1
    c.t = c.r[0] == 0x2u;  // 0609A8E4 cmp/eq #2,r0
    { const bool k = c.t; c.r[0] = 0xFFFFFFF0u; if (k) { goto L_0609A902; } }  // 0609A8E6 bt/s 0x0609A902 ; mov #-16,r0
    { const uint32_t x = c.r[10]; c.pr = 0x0609A8EEu; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609A8EEu) return; }  // 0609A8EA jsr @r10 ; mov r9,r4
    c.t = c.r[0] == 0x1u;  // 0609A8EE cmp/eq #1,r0
    if (!c.t) { SH2_POLL(c); goto L_0609A8D8; }  // 0609A8F0 bf 0x0609A8D8
    { const uint32_t x = c.r[8]; c.pr = 0x0609A8F6u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609A8F6u) return; }  // 0609A8F2 jsr @r8 ; mov #0,r4
    c.r[1] = ld32(0x0609A914u);  // 0609A8F6 mov.l 0x0609A914,r1
    c.r[2] = ld32(c.r[1]);  // 0609A8F8 mov.l @r1,r2
    c.r[1] = 0x0u;  // 0609A8FA mov #0,r1
    c.r[0] = c.r[2];  // 0609A8FC mov r2,r0
    st8(c.r[0] + c.r[9], c.r[1]);  // 0609A8FE mov.b r1,@(r0,r9)
    c.r[0] = 0x0u;  // 0609A900 mov #0,r0
L_0609A902:
    c.r[15] = c.r[14];  // 0609A902 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609A904 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609A906 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0609A908 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609A90A mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609A90C rts ; mov.l @r15+,r8
}

void f_0609A92C(SH2Context& c) {
    ran[2437] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609A92C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609A92E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609A930 sts.l pr,@-r15
    c.r[15] -= 4;  // 0609A932 add #-4,r15
    c.r[14] = c.r[15];  // 0609A934 mov r15,r14
    c.r[8] = ld32(0x0609A958u);  // 0609A936 mov.l 0x0609A958,r8
    c.r[5] = c.r[14];  // 0609A938 mov r14,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0609A93Eu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609A93Eu) return; }  // 0609A93A jsr @r8 ; mov #0,r4
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[14]);  // 0609A93E mov.b @r14,r4
    c.r[5] = c.r[14];  // 0609A940 mov r14,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0609A946u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609A946u) return; }  // 0609A942 jsr @r8 ; extu.b r4,r4
    c.r[0] = ld32(c.r[14]); c.r[14] += 4;  // 0609A946 mov.l @r14+,r0
    c.r[15] = c.r[14];  // 0609A948 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609A94A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609A94C mov.l @r15+,r14
    c.r[1] = ld32(0x0609A95Cu);  // 0609A94E mov.l 0x0609A95C,r1
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0609A950 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.r[0] &= c.r[1]; c.pc = x; return; }  // 0609A952 rts ; and r1,r0
}

void f_0609A960(SH2Context& c) {
    ran[2438] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609A960 mov.l r14,@-r15
    c.r[3] = ld32(0x0609A990u);  // 0609A962 mov.l 0x0609A990,r3
    c.r[2] = ld32(c.r[3]);  // 0609A964 mov.l @r3,r2
    c.r[0] = ld32(c.r[2] + 48);  // 0609A966 mov.l @(48,r2),r0
    c.t = c.r[0] == 0x1u;  // 0609A968 cmp/eq #1,r0
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0609A972; } }  // 0609A96A bf/s 0x0609A972 ; mov r15,r14
    c.r[0] = 0xFFFFFFFBu; goto L_0609A988;  // 0609A96E bra 0x0609A988 ; mov #-5,r0
L_0609A972:
    c.r[1] = 0x1u;  // 0609A972 mov #1,r1
    st32(c.r[2] + 48, c.r[1]);  // 0609A974 mov.l r1,@(48,r2)
    c.r[1] = ld32(c.r[2] + 56);  // 0609A976 mov.l @(56,r2),r1
    c.r[1] += 1;  // 0609A978 add #1,r1
    c.t = (int32_t)c.r[1] >= 0;  // 0609A97A cmp/pz r1
    { const bool k = c.t; st32(c.r[2] + 56, c.r[1]); if (k) { goto L_0609A984; } }  // 0609A97C bt/s 0x0609A984 ; mov.l r1,@(56,r2)
    c.r[1] = 0x0u;  // 0609A980 mov #0,r1
    st32(c.r[2] + 56, c.r[1]);  // 0609A982 mov.l r1,@(56,r2)
L_0609A984:
    c.r[1] = ld32(c.r[3]);  // 0609A984 mov.l @r3,r1
    c.r[0] = ld32(c.r[1] + 56);  // 0609A986 mov.l @(56,r1),r0
L_0609A988:
    c.r[15] = c.r[14];  // 0609A988 mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609A98A rts ; mov.l @r15+,r14
}

void f_0609A994(SH2Context& c) {
    ran[2439] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609A994 mov.l r14,@-r15
    c.r[1] = ld32(0x0609A9BCu);  // 0609A996 mov.l 0x0609A9BC,r1
    c.r[2] = ld32(c.r[1]);  // 0609A998 mov.l @r1,r2
    c.r[1] = ld32(c.r[2] + 48);  // 0609A99A mov.l @(48,r2),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609A99C tst r1,r1
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0609A9A6; } }  // 0609A99E bf/s 0x0609A9A6 ; mov r15,r14
    c.r[0] = 0xFFFFFFF9u; goto L_0609A9B6;  // 0609A9A2 bra 0x0609A9B6 ; mov #-7,r0
L_0609A9A6:
    c.r[1] = ld32(c.r[2] + 56);  // 0609A9A6 mov.l @(56,r2),r1
    c.t = c.r[1] == c.r[4];  // 0609A9A8 cmp/eq r4,r1
    { const bool k = !c.t; c.r[1] = 0x0u; if (k) { goto L_0609A9B4; } }  // 0609A9AA bf/s 0x0609A9B4 ; mov #0,r1
    st32(c.r[2] + 48, c.r[1]);  // 0609A9AE mov.l r1,@(48,r2)
    c.r[0] = 0x0u; goto L_0609A9B6;  // 0609A9B0 bra 0x0609A9B6 ; mov #0,r0
L_0609A9B4:
    c.r[0] = 0xFFFFFFF7u;  // 0609A9B4 mov #-9,r0
L_0609A9B6:
    c.r[15] = c.r[14];  // 0609A9B6 mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609A9B8 rts ; mov.l @r15+,r14
}

void f_0609A9C0(SH2Context& c) {
    ran[2440] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609A9C0 mov.l r14,@-r15
    c.r[1] = ld32(0x0609A9E0u);  // 0609A9C2 mov.l 0x0609A9E0,r1
    c.r[2] = ld32(c.r[1]);  // 0609A9C4 mov.l @r1,r2
    c.r[1] = ld32(c.r[2] + 48);  // 0609A9C6 mov.l @(48,r2),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609A9C8 tst r1,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0609A9D6; } }  // 0609A9CA bt/s 0x0609A9D6 ; mov r15,r14
    c.r[1] = ld32(c.r[2] + 56);  // 0609A9CE mov.l @(56,r2),r1
    c.t = c.r[1] == c.r[4];  // 0609A9D0 cmp/eq r4,r1
    c.r[0] = c.t; goto L_0609A9D8;  // 0609A9D2 bra 0x0609A9D8 ; movt r0
L_0609A9D6:
    c.r[0] = 0x0u;  // 0609A9D6 mov #0,r0
L_0609A9D8:
    c.r[15] = c.r[14];  // 0609A9D8 mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609A9DA rts ; mov.l @r15+,r14
}

void f_0609A9E4(SH2Context& c) {
    ran[2441] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609A9E4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609A9E6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609A9E8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609A9EA sts.l pr,@-r15
    c.r[3] = c.r[4];  // 0609A9EC mov r4,r3
    c.r[4] = ld32(0x0609AA9Cu);  // 0609A9EE mov.l 0x0609AA9C,r4
    c.r[2] = ld32(c.r[4]);  // 0609A9F0 mov.l @r4,r2
    c.r[8] = c.r[7];  // 0609A9F2 mov r7,r8
    c.r[1] = c.r[2];  // 0609A9F4 mov r2,r1
    c.r[1] += 84;  // 0609A9F6 add #84,r1
    c.r[7] = ld32(c.r[1]);  // 0609A9F8 mov.l @r1,r7
    c.r[15] -= 4;  // 0609A9FA add #-4,r15
    c.r[1] = c.r[2];  // 0609A9FC mov r2,r1
    c.r[1] += c.r[3];  // 0609A9FE add r3,r1
    c.r[1] += 24;  // 0609AA00 add #24,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0609AA02 mov.b @r1,r0
    c.r[14] = c.r[15];  // 0609AA04 mov r15,r14
    c.t = c.r[0] == 0x1u;  // 0609AA06 cmp/eq #1,r0
    { const bool k = c.t; c.r[9] = ld32(c.r[14] + 20); if (k) { goto L_0609AA10; } }  // 0609AA08 bt/s 0x0609AA10 ; mov.l @(20,r14),r9
    c.r[0] = 0xFFFFFFF9u; goto L_0609AA8E;  // 0609AA0C bra 0x0609AA8E ; mov #-7,r0
L_0609AA10:
    c.r[1] = 0x17u;  // 0609AA10 mov #23,r1
    c.t = (int32_t)c.r[7] > (int32_t)c.r[1];  // 0609AA12 cmp/gt r1,r7
    if (!c.t) { goto L_0609AA1C; }  // 0609AA14 bf 0x0609AA1C
    c.r[0] = 0xFFFFFFF8u;  // 0609AA16 mov #-8,r0
    c.r[14] += 4; goto L_0609AA90;  // 0609AA18 bra 0x0609AA90 ; add #4,r14
L_0609AA1C:
    c.r[2] += 88;  // 0609AA1C add #88,r2
    c.r[1] = ld32(c.r[2]);  // 0609AA1E mov.l @r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609AA20 tst r1,r1
    if (!c.t) { goto L_0609AA26; }  // 0609AA22 bf 0x0609AA26
    st32(c.r[2], c.r[0]);  // 0609AA24 mov.l r0,@r2
L_0609AA26:
    c.r[1] = ld32(c.r[4]);  // 0609AA26 mov.l @r4,r1
    c.r[7] <<= 2;  // 0609AA28 shll2 r7
    c.r[7] <<= 2;  // 0609AA2A shll2 r7
    c.r[1] += c.r[7];  // 0609AA2C add r7,r1
    c.r[1] += 92;  // 0609AA2E add #92,r1
    st8(c.r[1], c.r[3]);  // 0609AA30 mov.b r3,@r1
    c.r[1] = ld32(c.r[4]);  // 0609AA32 mov.l @r4,r1
    c.r[1] += c.r[7];  // 0609AA34 add r7,r1
    c.r[1] += 93;  // 0609AA36 add #93,r1
    st8(c.r[1], c.r[5]);  // 0609AA38 mov.b r5,@r1
    c.r[3] = ld32(c.r[4]);  // 0609AA3A mov.l @r4,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]); c.r[6] += 1;  // 0609AA3C mov.b @r6+,r1
    c.r[3] += c.r[7];  // 0609AA3E add r7,r3
    c.r[2] = c.r[3];  // 0609AA40 mov r3,r2
    c.r[2] += 94;  // 0609AA42 add #94,r2
    st8(c.r[2], c.r[1]);  // 0609AA44 mov.b r1,@r2
    c.r[5] = c.r[3];  // 0609AA46 mov r3,r5
    c.r[1] = c.r[6];  // 0609AA48 mov r6,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0609AA4A mov.b @r1+,r2
    c.r[5] += 95;  // 0609AA4C add #95,r5
    st8(c.r[5], c.r[2]);  // 0609AA4E mov.b r2,@r5
    c.r[5] = c.r[3];  // 0609AA50 mov r3,r5
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0609AA52 mov.b @r1+,r2
    c.r[5] += 96;  // 0609AA54 add #96,r5
    st8(c.r[5], c.r[2]);  // 0609AA56 mov.b r2,@r5
    c.r[5] = c.r[3];  // 0609AA58 mov r3,r5
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0609AA5A mov.b @r1+,r2
    c.r[5] += 97;  // 0609AA5C add #97,r5
    st8(c.r[5], c.r[2]);  // 0609AA5E mov.b r2,@r5
    c.r[5] = c.r[3];  // 0609AA60 mov r3,r5
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0609AA62 mov.b @r1+,r2
    c.r[5] += 98;  // 0609AA64 add #98,r5
    st8(c.r[5], c.r[2]);  // 0609AA66 mov.b r2,@r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0609AA68 mov.b @r1,r1
    c.r[3] += 99;  // 0609AA6A add #99,r3
    st8(c.r[3], c.r[1]);  // 0609AA6C mov.b r1,@r3
    c.r[2] = ld32(c.r[4]);  // 0609AA6E mov.l @r4,r2
    c.r[0] = ld32(0x0609AAA0u);  // 0609AA70 mov.l 0x0609AAA0,r0
    c.r[3] = c.r[2];  // 0609AA72 mov r2,r3
    c.r[3] += c.r[7];  // 0609AA74 add r7,r3
    c.r[1] = c.r[3];  // 0609AA76 mov r3,r1
    c.r[1] += 100;  // 0609AA78 add #100,r1
    st32(c.r[1], c.r[8]);  // 0609AA7A mov.l r8,@r1
    c.r[3] += 104;  // 0609AA7C add #104,r3
    st32(c.r[3], c.r[9]);  // 0609AA7E mov.l r9,@r3
    c.r[2] += 84;  // 0609AA80 add #84,r2
    c.r[1] = ld32(c.r[2]);  // 0609AA82 mov.l @r2,r1
    c.r[4] = c.r[14];  // 0609AA84 mov r14,r4
    c.r[1] += 1;  // 0609AA86 add #1,r1
    { const uint32_t x = c.r[0]; c.pr = 0x0609AA8Cu; st32(c.r[2], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609AA8Cu) return; }  // 0609AA88 jsr @r0 ; mov.l r1,@r2
    c.r[0] = 0x0u;  // 0609AA8C mov #0,r0
L_0609AA8E:
    c.r[14] += 4;  // 0609AA8E add #4,r14
L_0609AA90:
    c.r[15] = c.r[14];  // 0609AA90 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609AA92 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609AA94 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609AA96 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609AA98 rts ; mov.l @r15+,r8
}

void f_0609AAA4(SH2Context& c) {
    ran[2442] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609AAA4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609AAA6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609AAA8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609AAAA sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0609AAAC mov r15,r14
    c.r[8] = c.r[4];  // 0609AAAE mov r4,r8
    c.r[0] = ld32(0x0609AAE0u);  // 0609AAB0 mov.l 0x0609AAE0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609AAB6u; c.r[9] = c.r[6]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609AAB6u) return; }  // 0609AAB2 jsr @r0 ; mov r6,r9
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609AAB6 tst r0,r0
    { const bool k = !c.t; c.r[5] = c.r[9]; if (k) { goto L_0609AAD2; } }  // 0609AAB8 bf/s 0x0609AAD2 ; mov r9,r5
    c.r[0] = ld32(0x0609AAE4u);  // 0609AABC mov.l 0x0609AAE4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609AAC2u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609AAC2u) return; }  // 0609AABE jsr @r0 ; mov r8,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609AAC2 tst r0,r0
    { const bool k = !c.t; c.r[0] = 0xFFFFFFF6u; if (k) { goto L_0609AAD4; } }  // 0609AAC4 bf/s 0x0609AAD4 ; mov #-10,r0
    c.r[1] = ld32(0x0609AAE8u);  // 0609AAC8 mov.l 0x0609AAE8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609AACEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609AACEu) return; }  // 0609AACA jsr @r1 ; nop
    c.r[0] = 0x0u; goto L_0609AAD4;  // 0609AACE bra 0x0609AAD4 ; mov #0,r0
L_0609AAD2:
    c.r[0] = 0xFFFFFFF6u;  // 0609AAD2 mov #-10,r0
L_0609AAD4:
    c.r[15] = c.r[14];  // 0609AAD4 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609AAD6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609AAD8 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609AADA mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609AADC rts ; mov.l @r15+,r8
}

void f_0609AAEC(SH2Context& c) {
    ran[2443] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609AAEC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609AAEE sts.l pr,@-r15
    c.r[15] -= 4;  // 0609AAF0 add #-4,r15
    c.r[1] = (uint32_t)(int16_t)ld16(0x0609AB34u);  // 0609AAF2 mov.w 0x0609AB34,r1
    c.t = c.r[4] == c.r[1];  // 0609AAF4 cmp/eq r1,r4
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0609AB0A; } }  // 0609AAF6 bt/s 0x0609AB0A ; mov r15,r14
    c.r[1] = ld32(0x0609AB3Cu);  // 0609AAFA mov.l 0x0609AB3C,r1
    c.r[1] = ld32(c.r[1]);  // 0609AAFC mov.l @r1,r1
    c.r[1] += c.r[4];  // 0609AAFE add r4,r1
    c.r[1] += 24;  // 0609AB00 add #24,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0609AB02 mov.b @r1,r0
    c.t = c.r[0] == 0x1u;  // 0609AB04 cmp/eq #1,r0
    { const bool k = !c.t; c.r[0] = 0xFFFFFFF9u; if (k) { goto L_0609AB2A; } }  // 0609AB06 bf/s 0x0609AB2A ; mov #-7,r0
L_0609AB0A:
    c.r[1] = ld32(0x0609AB3Cu);  // 0609AB0A mov.l 0x0609AB3C,r1
    c.r[2] = ld32(c.r[1]);  // 0609AB0C mov.l @r1,r2
    c.r[1] = ld32(c.r[2] + 56);  // 0609AB0E mov.l @(56,r2),r1
    c.t = c.r[1] == c.r[5];  // 0609AB10 cmp/eq r5,r1
    { const bool k = !c.t; c.r[1] = 0x1u; if (k) { goto L_0609AB28; } }  // 0609AB12 bf/s 0x0609AB28 ; mov #1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609AB36u);  // 0609AB16 mov.w 0x0609AB36,r0
    st32(c.r[0] + c.r[2], c.r[1]);  // 0609AB18 mov.l r1,@(r0,r2)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609AB38u);  // 0609AB1A mov.w 0x0609AB38,r0
    st32(c.r[0] + c.r[2], c.r[4]);  // 0609AB1C mov.l r4,@(r0,r2)
    c.r[0] = ld32(0x0609AB40u);  // 0609AB1E mov.l 0x0609AB40,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609AB24u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609AB24u) return; }  // 0609AB20 jsr @r0 ; mov r14,r4
    c.r[0] = 0x0u; goto L_0609AB2A;  // 0609AB24 bra 0x0609AB2A ; mov #0,r0
L_0609AB28:
    c.r[0] = 0xFFFFFFF7u;  // 0609AB28 mov #-9,r0
L_0609AB2A:
    c.r[14] += 4;  // 0609AB2A add #4,r14
    c.r[15] = c.r[14];  // 0609AB2C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609AB2E lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609AB30 rts ; mov.l @r15+,r14
}

void f_0609AB44(SH2Context& c) {
    ran[2444] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609AB44 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609AB46 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609AB48 sts.l pr,@-r15
    c.r[15] -= 12;  // 0609AB4A add #-12,r15
    c.r[1] = ld32(0x0609AB8Cu);  // 0609AB4C mov.l 0x0609AB8C,r1
    c.r[1] = ld32(c.r[1]);  // 0609AB4E mov.l @r1,r1
    c.r[14] = c.r[15];  // 0609AB50 mov r15,r14
    c.r[1] = ld32(c.r[1] + 56);  // 0609AB52 mov.l @(56,r1),r1
    c.t = c.r[1] == c.r[5];  // 0609AB54 cmp/eq r5,r1
    { const bool k = c.t; c.r[8] = c.r[4]; if (k) { goto L_0609AB5E; } }  // 0609AB56 bt/s 0x0609AB5E ; mov r4,r8
    c.r[0] = 0xFFFFFFF7u; goto L_0609AB80;  // 0609AB5A bra 0x0609AB80 ; mov #-9,r0
L_0609AB5E:
    c.r[0] = ld32(0x0609AB90u);  // 0609AB5E mov.l 0x0609AB90,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609AB64u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609AB64u) return; }  // 0609AB60 jsr @r0 ; mov r14,r4
    c.r[1] = ld32(0x0609AB94u);  // 0609AB64 mov.l 0x0609AB94,r1
    c.r[0] = ld32(c.r[1]);  // 0609AB66 mov.l @r1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609AB68 tst r0,r0
    if (!c.t) { goto L_0609AB80; }  // 0609AB6A bf 0x0609AB80
    c.r[1] = ld32(0x0609AB98u);  // 0609AB6C mov.l 0x0609AB98,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609AB72u; c.r[4] = 0xFFFFFFEBu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609AB72u) return; }  // 0609AB6E jsr @r1 ; mov #-21,r4
    c.r[0] = ld32(0x0609AB9Cu);  // 0609AB72 mov.l 0x0609AB9C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609AB78u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609AB78u) return; }  // 0609AB74 jsr @r0 ; mov r8,r4
    c.r[2] = ld32(0x0609ABA0u);  // 0609AB78 mov.l 0x0609ABA0,r2
    c.r[1] = 0x1u;  // 0609AB7A mov #1,r1
    st32(c.r[2], c.r[1]);  // 0609AB7C mov.l r1,@r2
    c.r[0] = 0x0u;  // 0609AB7E mov #0,r0
L_0609AB80:
    c.r[14] += 12;  // 0609AB80 add #12,r14
    c.r[15] = c.r[14];  // 0609AB82 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609AB84 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609AB86 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609AB88 rts ; mov.l @r15+,r8
}

void f_0609ABA4(SH2Context& c) {
    ran[2445] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609ABA4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609ABA6 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609ABA8 sts.l pr,@-r15
    c.r[15] -= 4;  // 0609ABAA add #-4,r15
    c.r[1] = ld32(0x0609AC00u);  // 0609ABAC mov.l 0x0609AC00,r1
    c.r[2] = ld32(c.r[1]);  // 0609ABAE mov.l @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609ABF0u);  // 0609ABB0 mov.w 0x0609ABF0,r0
    c.r[3] = ld32(c.r[0] + c.r[2]);  // 0609ABB2 mov.l @(r0,r2),r3
    c.r[14] = c.r[15];  // 0609ABB4 mov r15,r14
    c.t = (c.r[3] & c.r[3]) == 0;  // 0609ABB6 tst r3,r3
    { const bool k = !c.t; c.r[8] = ld32(c.r[14] + 16); if (k) { goto L_0609ABE2; } }  // 0609ABB8 bf/s 0x0609ABE2 ; mov.l @(16,r14),r8
    c.r[1] = 0x1u;  // 0609ABBC mov #1,r1
    st32(c.r[0] + c.r[2], c.r[1]);  // 0609ABBE mov.l r1,@(r0,r2)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609ABF2u);  // 0609ABC0 mov.w 0x0609ABF2,r0
    st32(c.r[0] + c.r[2], c.r[4]);  // 0609ABC2 mov.l r4,@(r0,r2)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609ABF4u);  // 0609ABC4 mov.w 0x0609ABF4,r0
    st32(c.r[0] + c.r[2], c.r[5]);  // 0609ABC6 mov.l r5,@(r0,r2)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609ABF6u);  // 0609ABC8 mov.w 0x0609ABF6,r0
    st32(c.r[0] + c.r[2], c.r[6]);  // 0609ABCA mov.l r6,@(r0,r2)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609ABF8u);  // 0609ABCC mov.w 0x0609ABF8,r0
    st32(c.r[0] + c.r[2], c.r[3]);  // 0609ABCE mov.l r3,@(r0,r2)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609ABFAu);  // 0609ABD0 mov.w 0x0609ABFA,r0
    st32(c.r[0] + c.r[2], c.r[7]);  // 0609ABD2 mov.l r7,@(r0,r2)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609ABFCu);  // 0609ABD4 mov.w 0x0609ABFC,r0
    st32(c.r[0] + c.r[2], c.r[8]);  // 0609ABD6 mov.l r8,@(r0,r2)
    c.r[0] = ld32(0x0609AC04u);  // 0609ABD8 mov.l 0x0609AC04,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609ABDEu; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609ABDEu) return; }  // 0609ABDA jsr @r0 ; mov r14,r4
    c.r[0] = 0x0u; goto L_0609ABE4;  // 0609ABDE bra 0x0609ABE4 ; mov #0,r0
L_0609ABE2:
    c.r[0] = 0xFFFFFFFFu;  // 0609ABE2 mov #-1,r0
L_0609ABE4:
    c.r[14] += 4;  // 0609ABE4 add #4,r14
    c.r[15] = c.r[14];  // 0609ABE6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609ABE8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609ABEA mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609ABEC rts ; mov.l @r15+,r8
}

void f_0609AC08(SH2Context& c) {
    ran[2446] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609AC08 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609AC0A sts.l pr,@-r15
    c.r[15] -= 4;  // 0609AC0C add #-4,r15
    c.r[1] = ld32(0x0609AC5Cu);  // 0609AC0E mov.l 0x0609AC5C,r1
    c.r[2] = ld32(c.r[1]);  // 0609AC10 mov.l @r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0609AC52u);  // 0609AC12 mov.w 0x0609AC52,r3
    c.r[0] = c.r[2];  // 0609AC14 mov r2,r0
    c.r[1] = ld32(c.r[0] + c.r[3]);  // 0609AC16 mov.l @(r0,r3),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609AC18 tst r1,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0609AC22; } }  // 0609AC1A bt/s 0x0609AC22 ; mov r15,r14
    c.r[0] = 0xFFFFFFFFu; goto L_0609AC48;  // 0609AC1E bra 0x0609AC48 ; mov #-1,r0
L_0609AC22:
    c.r[0] = ld32(c.r[2] + 52);  // 0609AC22 mov.l @(52,r2),r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0609AC24 cmp/eq #-1,r0
    if (!c.t) { goto L_0609AC46; }  // 0609AC26 bf 0x0609AC46
    st32(c.r[2] + 52, c.r[4]);  // 0609AC28 mov.l r4,@(52,r2)
    c.r[1] = 0x1u;  // 0609AC2A mov #1,r1
    c.r[0] = c.r[2];  // 0609AC2C mov r2,r0
    st32(c.r[0] + c.r[3], c.r[1]);  // 0609AC2E mov.l r1,@(r0,r3)
    c.r[1] = (uint32_t)(int16_t)ld16(0x0609AC54u);  // 0609AC30 mov.w 0x0609AC54,r1
    st32(c.r[0] + c.r[1], c.r[4]);  // 0609AC32 mov.l r4,@(r0,r1)
    c.r[1] = (uint32_t)(int16_t)ld16(0x0609AC56u);  // 0609AC34 mov.w 0x0609AC56,r1
    st32(c.r[0] + c.r[1], c.r[5]);  // 0609AC36 mov.l r5,@(r0,r1)
    c.r[1] = (uint32_t)(int16_t)ld16(0x0609AC58u);  // 0609AC38 mov.w 0x0609AC58,r1
    st32(c.r[0] + c.r[1], c.r[6]);  // 0609AC3A mov.l r6,@(r0,r1)
    c.r[0] = ld32(0x0609AC60u);  // 0609AC3C mov.l 0x0609AC60,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609AC42u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609AC42u) return; }  // 0609AC3E jsr @r0 ; mov r14,r4
    c.r[0] = 0x0u; goto L_0609AC48;  // 0609AC42 bra 0x0609AC48 ; mov #0,r0
L_0609AC46:
    c.r[0] = 0xFFFFFFFBu;  // 0609AC46 mov #-5,r0
L_0609AC48:
    c.r[14] += 4;  // 0609AC48 add #4,r14
    c.r[15] = c.r[14];  // 0609AC4A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609AC4C lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609AC4E rts ; mov.l @r15+,r14
}

void f_0609AC64(SH2Context& c) {
    ran[2447] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609AC64 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609AC66 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609AC68 sts.l pr,@-r15
    c.r[8] = ld32(0x0609ACA0u);  // 0609AC6A mov.l 0x0609ACA0,r8
    c.r[1] = ld32(c.r[8]);  // 0609AC6C mov.l @r8,r1
    c.r[0] = ld32(c.r[1] + 52);  // 0609AC6E mov.l @(52,r1),r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0609AC70 cmp/eq #-1,r0
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0609AC7A; } }  // 0609AC72 bf/s 0x0609AC7A ; mov r15,r14
    c.r[0] = 0xFFFFFFF9u; goto L_0609AC96;  // 0609AC76 bra 0x0609AC96 ; mov #-7,r0
L_0609AC7A:
    c.r[0] = ld32(0x0609ACA4u);  // 0609AC7A mov.l 0x0609ACA4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609AC80u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609AC80u) return; }  // 0609AC7C jsr @r0 ; nop
    c.r[2] = ld32(c.r[8]);  // 0609AC80 mov.l @r8,r2
    c.r[1] = 0xFFFFFFFFu;  // 0609AC82 mov #-1,r1
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609AC84 tst r0,r0
    { const bool k = !c.t; st32(c.r[2] + 52, c.r[1]); if (k) { goto L_0609AC94; } }  // 0609AC86 bf/s 0x0609AC94 ; mov.l r1,@(52,r2)
    c.r[1] = ld32(0x0609ACA8u);  // 0609AC8A mov.l 0x0609ACA8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609AC90u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609AC90u) return; }  // 0609AC8C jsr @r1 ; nop
    c.r[0] = 0x0u; goto L_0609AC96;  // 0609AC90 bra 0x0609AC96 ; mov #0,r0
L_0609AC94:
    c.r[0] = 0xFFFFFFF6u;  // 0609AC94 mov #-10,r0
L_0609AC96:
    c.r[15] = c.r[14];  // 0609AC96 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609AC98 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609AC9A mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609AC9C rts ; mov.l @r15+,r8
}

void f_0609ACAC(SH2Context& c) {
    ran[2448] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609ACAC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609ACAE sts.l pr,@-r15
    c.r[15] -= 4;  // 0609ACB0 add #-4,r15
    c.r[1] = ld32(0x0609ACF8u);  // 0609ACB2 mov.l 0x0609ACF8,r1
    c.r[2] = ld32(c.r[1]);  // 0609ACB4 mov.l @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609ACF0u);  // 0609ACB6 mov.w 0x0609ACF0,r0
    c.r[1] = ld32(c.r[0] + c.r[2]);  // 0609ACB8 mov.l @(r0,r2),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609ACBA tst r1,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0609ACC4; } }  // 0609ACBC bt/s 0x0609ACC4 ; mov r15,r14
    c.r[0] = 0xFFFFFFFFu; goto L_0609ACE6;  // 0609ACC0 bra 0x0609ACE6 ; mov #-1,r0
L_0609ACC4:
    c.r[1] = ld32(c.r[2] + 52);  // 0609ACC4 mov.l @(52,r2),r1
    c.t = c.r[1] == c.r[4];  // 0609ACC6 cmp/eq r4,r1
    { const bool k = c.t; c.r[1] = 0x1u; if (k) { goto L_0609ACE4; } }  // 0609ACC8 bt/s 0x0609ACE4 ; mov #1,r1
    st32(c.r[0] + c.r[2], c.r[1]);  // 0609ACCC mov.l r1,@(r0,r2)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609ACF2u);  // 0609ACCE mov.w 0x0609ACF2,r0
    st32(c.r[0] + c.r[2], c.r[4]);  // 0609ACD0 mov.l r4,@(r0,r2)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609ACF4u);  // 0609ACD2 mov.w 0x0609ACF4,r0
    st32(c.r[0] + c.r[2], c.r[5]);  // 0609ACD4 mov.l r5,@(r0,r2)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609ACF6u);  // 0609ACD6 mov.w 0x0609ACF6,r0
    st32(c.r[0] + c.r[2], c.r[6]);  // 0609ACD8 mov.l r6,@(r0,r2)
    c.r[0] = ld32(0x0609ACFCu);  // 0609ACDA mov.l 0x0609ACFC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609ACE0u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609ACE0u) return; }  // 0609ACDC jsr @r0 ; mov r14,r4
    c.r[0] = 0x0u; goto L_0609ACE6;  // 0609ACE0 bra 0x0609ACE6 ; mov #0,r0
L_0609ACE4:
    c.r[0] = 0xFFFFFFFBu;  // 0609ACE4 mov #-5,r0
L_0609ACE6:
    c.r[14] += 4;  // 0609ACE6 add #4,r14
    c.r[15] = c.r[14];  // 0609ACE8 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609ACEA lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609ACEC rts ; mov.l @r15+,r14
}

void f_0609AD00(SH2Context& c) {
    ran[2449] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609AD00 mov.l r14,@-r15
    c.r[1] = ld32(0x0609AD28u);  // 0609AD02 mov.l 0x0609AD28,r1
    c.r[2] = ld32(c.r[1]);  // 0609AD04 mov.l @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609AD22u);  // 0609AD06 mov.w 0x0609AD22,r0
    c.r[1] = ld32(c.r[0] + c.r[2]);  // 0609AD08 mov.l @(r0,r2),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609AD0A tst r1,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0609AD1A; } }  // 0609AD0C bt/s 0x0609AD1A ; mov r15,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609AD24u);  // 0609AD10 mov.w 0x0609AD24,r0
    c.r[1] = ld32(c.r[0] + c.r[2]);  // 0609AD12 mov.l @(r0,r2),r1
    c.t = c.r[1] == c.r[4];  // 0609AD14 cmp/eq r4,r1
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_0609AD1C; } }  // 0609AD16 bt/s 0x0609AD1C ; mov #0,r0
L_0609AD1A:
    c.r[0] = 0x1u;  // 0609AD1A mov #1,r0
L_0609AD1C:
    c.r[15] = c.r[14];  // 0609AD1C mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609AD1E rts ; mov.l @r15+,r14
}

void f_0609AD2C(SH2Context& c) {
    ran[2450] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609AD2C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609AD2E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609AD30 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609AD32 sts.l pr,@-r15
    c.r[15] -= 8;  // 0609AD34 add #-8,r15
    c.r[14] = c.r[15];  // 0609AD36 mov r15,r14
    c.r[2] = ld32(0x0609ADC4u);  // 0609AD38 mov.l 0x0609ADC4,r2
    c.r[0] = ld32(c.r[2]);  // 0609AD3A mov.l @r2,r0
    c.t = c.r[0] == 0x1u;  // 0609AD3C cmp/eq #1,r0
    { const bool k = !c.t; c.r[8] = c.r[4]; if (k) { goto L_0609AD4A; } }  // 0609AD3E bf/s 0x0609AD4A ; mov r4,r8
    c.r[0] = 0xFFFFFFF8u;  // 0609AD42 mov #-8,r0
    c.r[1] = 0x0u;  // 0609AD44 mov #0,r1
    st32(c.r[2], c.r[1]); goto L_0609AD50;  // 0609AD46 bra 0x0609AD50 ; mov.l r1,@r2
L_0609AD4A:
    c.r[0] = ld32(0x0609ADC8u);  // 0609AD4A mov.l 0x0609ADC8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609AD50u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609AD50u) return; }  // 0609AD4C jsr @r0 ; mov r8,r4
L_0609AD50:
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609AD50 tst r0,r0
    if (c.t) { goto L_0609AD5A; }  // 0609AD52 bt 0x0609AD5A
    c.r[0] = ld32(0x0609ADCCu);  // 0609AD54 mov.l 0x0609ADCC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609AD5Au; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609AD5Au) return; }  // 0609AD56 jsr @r0 ; mov r8,r4
L_0609AD5A:
    c.r[0] = ld32(0x0609ADD0u);  // 0609AD5A mov.l 0x0609ADD0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609AD60u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609AD60u) return; }  // 0609AD5C jsr @r0 ; nop
    c.r[9] = c.r[0];  // 0609AD60 mov r0,r9
    c.r[3] = 0x20u;  // 0609AD62 mov #32,r3
    c.r[3] &= c.r[9];  // 0609AD64 and r9,r3
    c.t = (c.r[3] & c.r[3]) == 0;  // 0609AD66 tst r3,r3
    if (!c.t) { goto L_0609AD8E; }  // 0609AD68 bf 0x0609AD8E
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0609AD6A mov.b @r8,r0
    c.r[0] &= 0xFu;  // 0609AD6C and #15,r0
    c.t = c.r[0] == 0x7u;  // 0609AD6E cmp/eq #7,r0
    { const bool k = c.t; c.r[1] = 0xFFFFFFF2u; if (k) { goto L_0609AD96; } }  // 0609AD70 bt/s 0x0609AD96 ; mov #-14,r1
    c.r[1] = 0x7u;  // 0609AD74 mov #7,r1
    c.t = (int32_t)c.r[0] > (int32_t)c.r[1];  // 0609AD76 cmp/gt r1,r0
    { const bool k = c.t; c.t = c.r[0] == 0xAu; if (k) { goto L_0609AD86; } }  // 0609AD78 bt/s 0x0609AD86 ; cmp/eq #10,r0
    c.t = c.r[0] == 0x6u;  // 0609AD7C cmp/eq #6,r0
    if (c.t) { goto L_0609AD8E; }  // 0609AD7E bt 0x0609AD8E
    c.r[14] += 8;  // 0609AD80 add #8,r14
    c.r[15] = c.r[14]; goto L_0609ADB6;  // 0609AD82 bra 0x0609ADB6 ; mov r14,r15
L_0609AD86:
    { const bool k = c.t; c.r[1] = 0xFFFFFFF0u; if (k) { goto L_0609AD9C; } }  // 0609AD86 bt/s 0x0609AD9C ; mov #-16,r1
    c.r[14] += 8; goto L_0609ADB4;  // 0609AD8A bra 0x0609ADB4 ; add #8,r14
L_0609AD8E:
    c.r[2] = ld32(0x0609ADD4u);  // 0609AD8E mov.l 0x0609ADD4,r2
    c.r[1] = 0xFFFFFFF3u;  // 0609AD90 mov #-13,r1
    st32(c.r[2], c.r[1]); goto L_0609ADB2;  // 0609AD92 bra 0x0609ADB2 ; mov.l r1,@r2
L_0609AD96:
    c.r[2] = ld32(0x0609ADD4u);  // 0609AD96 mov.l 0x0609ADD4,r2
    st32(c.r[2], c.r[1]); goto L_0609ADB2;  // 0609AD98 bra 0x0609ADB2 ; mov.l r1,@r2
L_0609AD9C:
    c.r[2] = ld32(0x0609ADD4u);  // 0609AD9C mov.l 0x0609ADD4,r2
    st32(c.r[2], c.r[1]);  // 0609AD9E mov.l r1,@r2
    st32(c.r[14], c.r[3]);  // 0609ADA0 mov.l r3,@r14
    c.r[0] = ld32(0x0609ADD8u);  // 0609ADA2 mov.l 0x0609ADD8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609ADA8u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609ADA8u) return; }  // 0609ADA4 jsr @r0 ; mov r14,r4
    c.r[8] = ld32(0x0609ADDCu);  // 0609ADA8 mov.l 0x0609ADDC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0609ADAEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609ADAEu) return; }  // 0609ADAA jsr @r8 ; nop
    { const uint32_t x = c.r[8]; c.pr = 0x0609ADB2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609ADB2u) return; }  // 0609ADAE jsr @r8 ; nop
L_0609ADB2:
    c.r[14] += 8;  // 0609ADB2 add #8,r14
L_0609ADB4:
    c.r[15] = c.r[14];  // 0609ADB4 mov r14,r15
L_0609ADB6:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609ADB6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609ADB8 mov.l @r15+,r14
    c.r[0] = c.r[9];  // 0609ADBA mov r9,r0
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609ADBC mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609ADBE rts ; mov.l @r15+,r8
}

void f_0609ADE0(SH2Context& c) {
    ran[2451] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609ADE0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609ADE2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609ADE4 sts.l pr,@-r15
    c.r[15] -= 12;  // 0609ADE6 add #-12,r15
    c.r[1] = ld32(0x0609AE1Cu);  // 0609ADE8 mov.l 0x0609AE1C,r1
    c.r[1] = ld32(c.r[1]);  // 0609ADEA mov.l @r1,r1
    c.r[14] = c.r[15];  // 0609ADEC mov r15,r14
    c.r[1] = ld32(c.r[1] + 56);  // 0609ADEE mov.l @(56,r1),r1
    c.t = c.r[1] == c.r[5];  // 0609ADF0 cmp/eq r5,r1
    { const bool k = c.t; c.r[8] = c.r[4]; if (k) { goto L_0609ADFA; } }  // 0609ADF2 bt/s 0x0609ADFA ; mov r4,r8
    c.r[0] = 0xFFFFFFF7u; goto L_0609AE10;  // 0609ADF6 bra 0x0609AE10 ; mov #-9,r0
L_0609ADFA:
    c.r[0] = ld32(0x0609AE20u);  // 0609ADFA mov.l 0x0609AE20,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609AE00u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609AE00u) return; }  // 0609ADFC jsr @r0 ; mov r14,r4
    c.r[1] = ld32(0x0609AE24u);  // 0609AE00 mov.l 0x0609AE24,r1
    c.r[0] = ld32(c.r[1]);  // 0609AE02 mov.l @r1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609AE04 tst r0,r0
    if (!c.t) { goto L_0609AE10; }  // 0609AE06 bf 0x0609AE10
    c.r[0] = ld32(0x0609AE28u);  // 0609AE08 mov.l 0x0609AE28,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609AE0Eu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609AE0Eu) return; }  // 0609AE0A jsr @r0 ; mov r8,r4
    c.r[0] = 0x0u;  // 0609AE0E mov #0,r0
L_0609AE10:
    c.r[14] += 12;  // 0609AE10 add #12,r14
    c.r[15] = c.r[14];  // 0609AE12 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609AE14 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609AE16 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609AE18 rts ; mov.l @r15+,r8
}

void f_0609AE2C(SH2Context& c) {
    ran[2452] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609AE2C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609AE2E sts.l pr,@-r15
    c.r[1] = ld32(0x0609AE90u);  // 0609AE30 mov.l 0x0609AE90,r1
    c.r[2] = ld32(c.r[1]);  // 0609AE32 mov.l @r1,r2
    c.r[15] -= 4;  // 0609AE34 add #-4,r15
    c.r[1] = c.r[2];  // 0609AE36 mov r2,r1
    c.r[1] += c.r[4];  // 0609AE38 add r4,r1
    c.r[1] += 24;  // 0609AE3A add #24,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0609AE3C mov.b @r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609AE3E tst r1,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0609AE50; } }  // 0609AE40 bt/s 0x0609AE50 ; mov r15,r14
    c.r[1] = c.r[2];  // 0609AE44 mov r2,r1
    c.r[1] += c.r[5];  // 0609AE46 add r5,r1
    c.r[1] += 24;  // 0609AE48 add #24,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0609AE4A mov.b @r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609AE4C tst r1,r1
    if (!c.t) { goto L_0609AE54; }  // 0609AE4E bf 0x0609AE54
L_0609AE50:
    c.r[0] = 0xFFFFFFF9u; goto L_0609AE7C;  // 0609AE50 bra 0x0609AE7C ; mov #-7,r0
L_0609AE54:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609AE86u);  // 0609AE54 mov.w 0x0609AE86,r0
    c.r[1] = ld32(c.r[0] + c.r[2]);  // 0609AE56 mov.l @(r0,r2),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609AE58 tst r1,r1
    { const bool k = !c.t; c.r[1] = 0x1u; if (k) { goto L_0609AE7A; } }  // 0609AE5A bf/s 0x0609AE7A ; mov #1,r1
    st32(c.r[0] + c.r[2], c.r[1]);  // 0609AE5E mov.l r1,@(r0,r2)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609AE88u);  // 0609AE60 mov.w 0x0609AE88,r0
    st32(c.r[0] + c.r[2], c.r[4]);  // 0609AE62 mov.l r4,@(r0,r2)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609AE8Au);  // 0609AE64 mov.w 0x0609AE8A,r0
    st32(c.r[0] + c.r[2], c.r[5]);  // 0609AE66 mov.l r5,@(r0,r2)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609AE8Cu);  // 0609AE68 mov.w 0x0609AE8C,r0
    st32(c.r[0] + c.r[2], c.r[6]);  // 0609AE6A mov.l r6,@(r0,r2)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609AE8Eu);  // 0609AE6C mov.w 0x0609AE8E,r0
    st32(c.r[0] + c.r[2], c.r[7]);  // 0609AE6E mov.l r7,@(r0,r2)
    c.r[0] = ld32(0x0609AE94u);  // 0609AE70 mov.l 0x0609AE94,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609AE76u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609AE76u) return; }  // 0609AE72 jsr @r0 ; mov r14,r4
    c.r[0] = 0x0u; goto L_0609AE7C;  // 0609AE76 bra 0x0609AE7C ; mov #0,r0
L_0609AE7A:
    c.r[0] = 0xFFFFFFFFu;  // 0609AE7A mov #-1,r0
L_0609AE7C:
    c.r[14] += 4;  // 0609AE7C add #4,r14
    c.r[15] = c.r[14];  // 0609AE7E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609AE80 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609AE82 rts ; mov.l @r15+,r14
}

void f_0609AE98(SH2Context& c) {
    ran[2453] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609AE98 mov.l r14,@-r15
    c.r[1] = ld32(0x0609AEB8u);  // 0609AE9A mov.l 0x0609AEB8,r1
    c.r[1] = ld32(c.r[1]);  // 0609AE9C mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609AEB4u);  // 0609AE9E mov.w 0x0609AEB4,r0
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 0609AEA0 mov.l @(r0,r1),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609AEA2 tst r1,r1
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0609AEAC; } }  // 0609AEA4 bf/s 0x0609AEAC ; mov r15,r14
    c.r[0] = 0x1u; goto L_0609AEAE;  // 0609AEA8 bra 0x0609AEAE ; mov #1,r0
L_0609AEAC:
    c.r[0] = 0x0u;  // 0609AEAC mov #0,r0
L_0609AEAE:
    c.r[15] = c.r[14];  // 0609AEAE mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609AEB0 rts ; mov.l @r15+,r14
}

void f_0609AEBC(SH2Context& c) {
    ran[2454] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609AEBC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609AEBE sts.l pr,@-r15
    c.r[2] = c.r[4];  // 0609AEC0 mov r4,r2
    c.r[1] = 0x17u;  // 0609AEC2 mov #23,r1
    c.t = c.r[2] > c.r[1];  // 0609AEC4 cmp/hi r1,r2
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0609AECE; } }  // 0609AEC6 bf/s 0x0609AECE ; mov r15,r14
    c.r[0] = 0xFFFFFFFAu; goto L_0609AEF0;  // 0609AECA bra 0x0609AEF0 ; mov #-6,r0
L_0609AECE:
    c.r[1] = ld32(0x0609AEF8u);  // 0609AECE mov.l 0x0609AEF8,r1
    c.r[1] = ld32(c.r[1]);  // 0609AED0 mov.l @r1,r1
    c.r[0] = c.r[1];  // 0609AED2 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0609AED4 mov.b @(r0,r2),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609AED6 tst r1,r1
    { const bool k = c.t; c.r[0] = 0xFFFFFFF9u; if (k) { goto L_0609AEF0; } }  // 0609AED8 bt/s 0x0609AEF0 ; mov #-7,r0
    c.r[0] = ld32(0x0609AEFCu);  // 0609AEDC mov.l 0x0609AEFC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609AEE2u; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609AEE2u) return; }  // 0609AEDE jsr @r0 ; mov r2,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609AEE2 tst r0,r0
    { const bool k = !c.t; c.r[0] = 0xFFFFFFF6u; if (k) { goto L_0609AEF0; } }  // 0609AEE4 bf/s 0x0609AEF0 ; mov #-10,r0
    c.r[1] = ld32(0x0609AF00u);  // 0609AEE8 mov.l 0x0609AF00,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609AEEEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609AEEEu) return; }  // 0609AEEA jsr @r1 ; nop
    c.r[0] = 0x0u;  // 0609AEEE mov #0,r0
L_0609AEF0:
    c.r[15] = c.r[14];  // 0609AEF0 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609AEF2 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609AEF4 rts ; mov.l @r15+,r14
}

void f_0609AF04(SH2Context& c) {
    ran[2455] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609AF04 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609AF06 sts.l pr,@-r15
    c.r[15] -= 4;  // 0609AF08 add #-4,r15
    c.r[1] = ld32(0x0609AF78u);  // 0609AF0A mov.l 0x0609AF78,r1
    c.r[2] = ld32(c.r[1]);  // 0609AF0C mov.l @r1,r2
    c.r[7] = c.r[5];  // 0609AF0E mov r5,r7
    c.r[1] = c.r[2];  // 0609AF10 mov r2,r1
    c.r[1] += c.r[7];  // 0609AF12 add r7,r1
    c.r[1] += 24;  // 0609AF14 add #24,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0609AF16 mov.b @r1,r0
    c.t = c.r[0] == 0x1u;  // 0609AF18 cmp/eq #1,r0
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0609AF2A; } }  // 0609AF1A bf/s 0x0609AF2A ; mov r15,r14
    c.r[0] = c.r[2];  // 0609AF1E mov r2,r0
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0609AF20 mov.b @(r0,r7),r3
    c.r[0] = c.r[3];  // 0609AF22 mov r3,r0
    c.t = c.r[0] == 0x1u;  // 0609AF24 cmp/eq #1,r0
    { const bool k = c.t; c.r[0] = c.r[2]; if (k) { goto L_0609AF2E; } }  // 0609AF26 bt/s 0x0609AF2E ; mov r2,r0
L_0609AF2A:
    c.r[0] = 0xFFFFFFFBu; goto L_0609AF64;  // 0609AF2A bra 0x0609AF64 ; mov #-5,r0
L_0609AF2E:
    c.r[5] = (uint32_t)(int16_t)ld16(0x0609AF6Eu);  // 0609AF2E mov.w 0x0609AF6E,r5
    c.r[1] = ld32(c.r[0] + c.r[5]);  // 0609AF30 mov.l @(r0,r5),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609AF32 tst r1,r1
    { const bool k = c.t; c.r[0] = c.r[4]; if (k) { goto L_0609AF3C; } }  // 0609AF34 bt/s 0x0609AF3C ; mov r4,r0
    c.r[0] = 0xFFFFFFFFu; goto L_0609AF64;  // 0609AF38 bra 0x0609AF64 ; mov #-1,r0
L_0609AF3C:
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0609AF3C cmp/eq #-1,r0
    { const bool k = !c.t; c.r[1] = 0x3u; if (k) { goto L_0609AF48; } }  // 0609AF3E bf/s 0x0609AF48 ; mov #3,r1
    c.r[0] = c.r[2];  // 0609AF42 mov r2,r0
    st32(c.r[0] + c.r[5], c.r[1]); goto L_0609AF4C;  // 0609AF44 bra 0x0609AF4C ; mov.l r1,@(r0,r5)
L_0609AF48:
    c.r[0] = c.r[2];  // 0609AF48 mov r2,r0
    st32(c.r[0] + c.r[5], c.r[3]);  // 0609AF4A mov.l r3,@(r0,r5)
L_0609AF4C:
    c.r[1] = ld32(0x0609AF78u);  // 0609AF4C mov.l 0x0609AF78,r1
    c.r[1] = ld32(c.r[1]);  // 0609AF4E mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609AF70u);  // 0609AF50 mov.w 0x0609AF70,r0
    st16(c.r[0] + c.r[1], c.r[4]);  // 0609AF52 mov.w r4,@(r0,r1)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609AF72u);  // 0609AF54 mov.w 0x0609AF72,r0
    st16(c.r[0] + c.r[1], c.r[7]);  // 0609AF56 mov.w r7,@(r0,r1)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609AF74u);  // 0609AF58 mov.w 0x0609AF74,r0
    st32(c.r[0] + c.r[1], c.r[6]);  // 0609AF5A mov.l r6,@(r0,r1)
    c.r[0] = ld32(0x0609AF7Cu);  // 0609AF5C mov.l 0x0609AF7C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609AF62u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609AF62u) return; }  // 0609AF5E jsr @r0 ; mov r14,r4
    c.r[0] = 0x0u;  // 0609AF62 mov #0,r0
L_0609AF64:
    c.r[14] += 4;  // 0609AF64 add #4,r14
    c.r[15] = c.r[14];  // 0609AF66 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609AF68 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609AF6A rts ; mov.l @r15+,r14
}

void f_0609AF80(SH2Context& c) {
    ran[2456] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609AF80 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609AF82 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609AF84 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609AF86 sts.l pr,@-r15
    c.r[15] -= 4;  // 0609AF88 add #-4,r15
    c.r[14] = c.r[15];  // 0609AF8A mov r15,r14
    c.r[7] = c.r[4];  // 0609AF8C mov r4,r7
    c.r[1] = ld32(0x0609B070u);  // 0609AF8E mov.l 0x0609B070,r1
    c.r[1] = ld32(c.r[1]);  // 0609AF90 mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609B064u);  // 0609AF92 mov.w 0x0609B064,r0
    c.r[4] = ld32(c.r[0] + c.r[1]);  // 0609AF94 mov.l @(r0,r1),r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x0609B066u);  // 0609AF96 mov.w 0x0609B066,r1
    c.t = c.r[7] == c.r[1];  // 0609AF98 cmp/eq r1,r7
    { const bool k = c.t; c.r[8] = c.r[5]; if (k) { goto L_0609AFAE; } }  // 0609AF9A bt/s 0x0609AFAE ; mov r5,r8
    c.r[0] = c.r[7];  // 0609AF9E mov r7,r0
    c.t = c.r[0] == 0xFFFFFFFEu;  // 0609AFA0 cmp/eq #-2,r0
    { const bool k = c.t; c.r[2] = 0x17u; if (k) { goto L_0609AFB0; } }  // 0609AFA2 bt/s 0x0609AFB0 ; mov #23,r2
    c.r[1] = 0x17u;  // 0609AFA6 mov #23,r1
    c.t = c.r[7] > c.r[1];  // 0609AFA8 cmp/hi r1,r7
    { const bool k = c.t; c.r[0] = 0xFFFFFFFAu; if (k) { goto L_0609B056; } }  // 0609AFAA bt/s 0x0609B056 ; mov #-6,r0
L_0609AFAE:
    c.r[2] = 0x17u;  // 0609AFAE mov #23,r2
L_0609AFB0:
    c.t = c.r[8] > c.r[2];  // 0609AFB0 cmp/hi r2,r8
    { const bool k = c.t; c.r[0] = 0xFFFFFFFAu; if (k) { goto L_0609B056; } }  // 0609AFB2 bt/s 0x0609B056 ; mov #-6,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0609B066u);  // 0609AFB6 mov.w 0x0609B066,r1
    c.t = c.r[6] == c.r[1];  // 0609AFB8 cmp/eq r1,r6
    { const bool k = c.t; c.t = c.r[7] == c.r[1]; if (k) { goto L_0609AFD0; } }  // 0609AFBA bt/s 0x0609AFD0 ; cmp/eq r1,r7
    c.r[0] = c.r[6];  // 0609AFBE mov r6,r0
    c.t = c.r[0] == 0xFFFFFFFEu;  // 0609AFC0 cmp/eq #-2,r0
    { const bool k = c.t; c.t = c.r[7] == c.r[1]; if (k) { goto L_0609AFD0; } }  // 0609AFC2 bt/s 0x0609AFD0 ; cmp/eq r1,r7
    c.t = c.r[6] > c.r[2];  // 0609AFC6 cmp/hi r2,r6
    { const bool k = !c.t; c.t = c.r[7] == c.r[1]; if (k) { goto L_0609AFD0; } }  // 0609AFC8 bf/s 0x0609AFD0 ; cmp/eq r1,r7
    c.r[0] = 0xFFFFFFFAu; goto L_0609B056;  // 0609AFCC bra 0x0609B056 ; mov #-6,r0
L_0609AFD0:
    { const bool k = c.t; c.r[0] = c.r[7]; if (k) { goto L_0609AFE8; } }  // 0609AFD0 bt/s 0x0609AFE8 ; mov r7,r0
    c.t = c.r[0] == 0xFFFFFFFEu;  // 0609AFD4 cmp/eq #-2,r0
    if (c.t) { goto L_0609AFE8; }  // 0609AFD6 bt 0x0609AFE8
    c.r[1] = ld32(0x0609B070u);  // 0609AFD8 mov.l 0x0609B070,r1
    c.r[1] = ld32(c.r[1]);  // 0609AFDA mov.l @r1,r1
    c.r[1] += c.r[7];  // 0609AFDC add r7,r1
    c.r[1] += 24;  // 0609AFDE add #24,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0609AFE0 mov.b @r1,r0
    c.t = c.r[0] == 0x1u;  // 0609AFE2 cmp/eq #1,r0
    { const bool k = !c.t; c.r[0] = 0xFFFFFFF9u; if (k) { goto L_0609B056; } }  // 0609AFE4 bf/s 0x0609B056 ; mov #-7,r0
L_0609AFE8:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0609B066u);  // 0609AFE8 mov.w 0x0609B066,r1
    c.t = c.r[6] == c.r[1];  // 0609AFEA cmp/eq r1,r6
    { const bool k = c.t; c.r[0] = c.r[6]; if (k) { goto L_0609B004; } }  // 0609AFEC bt/s 0x0609B004 ; mov r6,r0
    c.t = c.r[0] == 0xFFFFFFFEu;  // 0609AFF0 cmp/eq #-2,r0
    if (c.t) { goto L_0609B004; }  // 0609AFF2 bt 0x0609B004
    c.r[1] = ld32(0x0609B070u);  // 0609AFF4 mov.l 0x0609B070,r1
    c.r[1] = ld32(c.r[1]);  // 0609AFF6 mov.l @r1,r1
    c.r[1] += c.r[6];  // 0609AFF8 add r6,r1
    c.r[1] += 24;  // 0609AFFA add #24,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0609AFFC mov.b @r1,r0
    c.t = c.r[0] == 0x1u;  // 0609AFFE cmp/eq #1,r0
    { const bool k = !c.t; c.r[0] = 0xFFFFFFF9u; if (k) { goto L_0609B056; } }  // 0609B000 bf/s 0x0609B056 ; mov #-7,r0
L_0609B004:
    c.r[3] = ld32(0x0609B070u);  // 0609B004 mov.l 0x0609B070,r3
    c.r[2] = ld32(c.r[3]);  // 0609B006 mov.l @r3,r2
    c.r[0] = c.r[2];  // 0609B008 mov r2,r0
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0609B00A mov.b @(r0,r8),r5
    c.r[0] = c.r[5];  // 0609B00C mov r5,r0
    c.t = c.r[0] == 0x1u;  // 0609B00E cmp/eq #1,r0
    { const bool k = c.t; c.r[1] = 0x17u; if (k) { goto L_0609B018; } }  // 0609B010 bt/s 0x0609B018 ; mov #23,r1
    c.r[0] = 0xFFFFFFF9u; goto L_0609B056;  // 0609B014 bra 0x0609B056 ; mov #-7,r0
L_0609B018:
    c.t = (int32_t)c.r[4] > (int32_t)c.r[1];  // 0609B018 cmp/gt r1,r4
    { const bool k = c.t; c.r[0] = 0xFFFFFFF8u; if (k) { goto L_0609B056; } }  // 0609B01A bt/s 0x0609B056 ; mov #-8,r0
    c.r[9] = (uint32_t)(int16_t)ld16(0x0609B068u);  // 0609B01E mov.w 0x0609B068,r9
    c.r[0] = c.r[2];  // 0609B020 mov r2,r0
    c.r[1] = ld32(c.r[0] + c.r[9]);  // 0609B022 mov.l @(r0,r9),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609B024 tst r1,r1
    if (!c.t) { goto L_0609B02A; }  // 0609B026 bf 0x0609B02A
    st32(c.r[0] + c.r[9], c.r[5]);  // 0609B028 mov.l r5,@(r0,r9)
L_0609B02A:
    c.r[2] = c.r[4];  // 0609B02A mov r4,r2
    c.r[2] += c.r[2];  // 0609B02C add r2,r2
    c.r[2] += c.r[4];  // 0609B02E add r4,r2
    c.r[2] <<= 2;  // 0609B030 shll2 r2
    c.r[3] = ld32(c.r[3]);  // 0609B032 mov.l @r3,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0609B06Au);  // 0609B034 mov.w 0x0609B06A,r1
    c.r[2] += c.r[3];  // 0609B036 add r3,r2
    c.r[0] = c.r[2];  // 0609B038 mov r2,r0
    st32(c.r[0] + c.r[1], c.r[7]);  // 0609B03A mov.l r7,@(r0,r1)
    c.r[1] = (uint32_t)(int16_t)ld16(0x0609B06Cu);  // 0609B03C mov.w 0x0609B06C,r1
    st32(c.r[0] + c.r[1], c.r[8]);  // 0609B03E mov.l r8,@(r0,r1)
    c.r[1] = (uint32_t)(int16_t)ld16(0x0609B06Eu);  // 0609B040 mov.w 0x0609B06E,r1
    st32(c.r[0] + c.r[1], c.r[6]);  // 0609B042 mov.l r6,@(r0,r1)
    c.r[2] = (uint32_t)(int16_t)ld16(0x0609B064u);  // 0609B044 mov.w 0x0609B064,r2
    c.r[0] = c.r[3];  // 0609B046 mov r3,r0
    c.r[1] = ld32(c.r[0] + c.r[2]);  // 0609B048 mov.l @(r0,r2),r1
    c.r[1] += 1;  // 0609B04A add #1,r1
    st32(c.r[0] + c.r[2], c.r[1]);  // 0609B04C mov.l r1,@(r0,r2)
    c.r[0] = ld32(0x0609B074u);  // 0609B04E mov.l 0x0609B074,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609B054u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B054u) return; }  // 0609B050 jsr @r0 ; mov r14,r4
    c.r[0] = 0x0u;  // 0609B054 mov #0,r0
L_0609B056:
    c.r[14] += 4;  // 0609B056 add #4,r14
    c.r[15] = c.r[14];  // 0609B058 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609B05A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609B05C mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609B05E mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609B060 rts ; mov.l @r15+,r8
}

void f_0609B078(SH2Context& c) {
    ran[2457] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609B078 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609B07A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0609B07C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609B07E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609B080 sts.l pr,@-r15
    c.r[15] -= 12;  // 0609B082 add #-12,r15
    c.r[14] = c.r[15];  // 0609B084 mov r15,r14
    c.r[8] = c.r[4];  // 0609B086 mov r4,r8
    c.r[10] = c.r[5];  // 0609B088 mov r5,r10
    c.r[6] = c.r[14];  // 0609B08A mov r14,r6
    c.r[6] += 8;  // 0609B08C add #8,r6
    c.r[5] = c.r[14];  // 0609B08E mov r14,r5
    c.r[5] += 4;  // 0609B090 add #4,r5
    c.r[0] = ld32(0x0609B13Cu);  // 0609B092 mov.l 0x0609B13C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609B098u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B098u) return; }  // 0609B094 jsr @r0 ; mov r14,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609B098 tst r0,r0
    { const bool k = !c.t; c.r[2] = ld32(c.r[14]); if (k) { goto L_0609B0F4; } }  // 0609B09A bf/s 0x0609B0F4 ; mov.l @r14,r2
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[2];  // 0609B09E cmp/ge r2,r8
    { const bool k = !c.t; c.r[1] = ld32(c.r[14] + 4); if (k) { goto L_0609B0AA; } }  // 0609B0A0 bf/s 0x0609B0AA ; mov.l @(4,r14),r1
    c.r[2] += c.r[1];  // 0609B0A4 add r1,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[8];  // 0609B0A6 cmp/gt r8,r2
    if (c.t) { goto L_0609B0E6; }  // 0609B0A8 bt 0x0609B0E6
L_0609B0AA:
    c.r[0] = ld32(0x0609B140u);  // 0609B0AA mov.l 0x0609B140,r0
    c.r[5] = c.r[8];  // 0609B0AC mov r8,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0609B0B2u; c.r[4] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B0B2u) return; }  // 0609B0AE jsr @r0 ; mov #23,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609B0B2 tst r0,r0
    { const bool k = !c.t; c.r[0] = 0xFFFFFFF5u; if (k) { goto L_0609B12A; } }  // 0609B0B4 bf/s 0x0609B12A ; mov #-11,r0
    c.r[9] = ld32(0x0609B144u);  // 0609B0B8 mov.l 0x0609B144,r9
L_0609B0BA:
    c.r[4] = (uint32_t)(int16_t)ld16(0x0609B13Au);  // 0609B0BA mov.w 0x0609B13A,r4
    { const uint32_t x = c.r[9]; c.pr = 0x0609B0C0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B0C0u) return; }  // 0609B0BC jsr @r9 ; nop
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609B0C0 tst r0,r0
    { const bool k = c.t; c.r[6] = c.r[14]; if (k) { SH2_POLL(c); goto L_0609B0BA; } }  // 0609B0C2 bt/s 0x0609B0BA ; mov r14,r6
    c.r[6] += 8;  // 0609B0C6 add #8,r6
    c.r[5] = c.r[14];  // 0609B0C8 mov r14,r5
    c.r[5] += 4;  // 0609B0CA add #4,r5
    c.r[0] = ld32(0x0609B13Cu);  // 0609B0CC mov.l 0x0609B13C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609B0D2u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B0D2u) return; }  // 0609B0CE jsr @r0 ; mov r14,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609B0D2 tst r0,r0
    { const bool k = !c.t; c.r[2] = ld32(c.r[14]); if (k) { goto L_0609B0F4; } }  // 0609B0D4 bf/s 0x0609B0F4 ; mov.l @r14,r2
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[2];  // 0609B0D8 cmp/ge r2,r8
    { const bool k = c.t; c.r[1] = ld32(c.r[14] + 4); if (k) { goto L_0609B0E6; } }  // 0609B0DA bt/s 0x0609B0E6 ; mov.l @(4,r14),r1
    c.r[2] += c.r[1];  // 0609B0DE add r1,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[8];  // 0609B0E0 cmp/gt r8,r2
    { const bool k = !c.t; c.r[0] = 0xFFFFFFF5u; if (k) { goto L_0609B12A; } }  // 0609B0E2 bf/s 0x0609B12A ; mov #-11,r0
L_0609B0E6:
    c.r[0] = ld32(0x0609B148u);  // 0609B0E6 mov.l 0x0609B148,r0
    c.r[5] = c.r[10];  // 0609B0E8 mov r10,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0609B0EEu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B0EEu) return; }  // 0609B0EA jsr @r0 ; mov r8,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609B0EE tst r0,r0
    { const bool k = c.t; c.r[5] = c.r[10]; if (k) { goto L_0609B0F8; } }  // 0609B0F0 bt/s 0x0609B0F8 ; mov r10,r5
L_0609B0F4:
    c.r[0] = 0xFFFFFFF5u; goto L_0609B12A;  // 0609B0F4 bra 0x0609B12A ; mov #-11,r0
L_0609B0F8:
    c.r[5] += 11;  // 0609B0F8 add #11,r5
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[5]);  // 0609B0FA mov.b @r5,r0
    c.r[1] = 0x2u;  // 0609B0FC mov #2,r1
    c.r[1] &= c.r[0];  // 0609B0FE and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609B100 tst r1,r1
    { const bool k = c.t; c.r[1] = ld32(c.r[14] + 8); if (k) { goto L_0609B10C; } }  // 0609B102 bt/s 0x0609B10C ; mov.l @(8,r14),r1
    c.r[0] |= 0x80u;  // 0609B106 or #128,r0
    st8(c.r[5], c.r[0]);  // 0609B108 mov.b r0,@r5
    c.r[1] = ld32(c.r[14] + 8);  // 0609B10A mov.l @(8,r14),r1
L_0609B10C:
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609B10C tst r1,r1
    { const bool k = c.t; c.r[2] = ld32(c.r[14]); if (k) { goto L_0609B122; } }  // 0609B10E bt/s 0x0609B122 ; mov.l @r14,r2
    c.r[1] = ld32(c.r[14] + 4);  // 0609B112 mov.l @(4,r14),r1
    c.r[2] += c.r[1];  // 0609B114 add r1,r2
    c.r[2] -= 1;  // 0609B116 add #-1,r2
    c.t = c.r[2] == c.r[8];  // 0609B118 cmp/eq r8,r2
    if (!c.t) { goto L_0609B122; }  // 0609B11A bf 0x0609B122
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[5]);  // 0609B11C mov.b @r5,r0
    c.r[0] |= 0x1u;  // 0609B11E or #1,r0
    st8(c.r[5], c.r[0]);  // 0609B120 mov.b r0,@r5
L_0609B122:
    c.r[1] = ld32(0x0609B14Cu);  // 0609B122 mov.l 0x0609B14C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609B128u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B128u) return; }  // 0609B124 jsr @r1 ; nop
    c.r[0] = 0x0u;  // 0609B128 mov #0,r0
L_0609B12A:
    c.r[14] += 12;  // 0609B12A add #12,r14
    c.r[15] = c.r[14];  // 0609B12C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609B12E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609B130 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0609B132 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609B134 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609B136 rts ; mov.l @r15+,r8
}

void f_0609B150(SH2Context& c) {
    ran[2458] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609B150 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609B152 sts.l pr,@-r15
    c.r[15] -= 12;  // 0609B154 add #-12,r15
    c.r[14] = c.r[15];  // 0609B156 mov r15,r14
    c.r[6] = c.r[14];  // 0609B158 mov r14,r6
    c.r[6] += 8;  // 0609B15A add #8,r6
    c.r[5] = c.r[14];  // 0609B15C mov r14,r5
    c.r[5] += 4;  // 0609B15E add #4,r5
    c.r[0] = ld32(0x0609B180u);  // 0609B160 mov.l 0x0609B180,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609B166u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B166u) return; }  // 0609B162 jsr @r0 ; mov r14,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609B166 tst r0,r0
    { const bool k = !c.t; c.r[0] = 0xFFFFFFF6u; if (k) { goto L_0609B174; } }  // 0609B168 bf/s 0x0609B174 ; mov #-10,r0
    c.r[1] = ld32(0x0609B184u);  // 0609B16C mov.l 0x0609B184,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609B172u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B172u) return; }  // 0609B16E jsr @r1 ; nop
    c.r[0] = ld32(c.r[14] + 8);  // 0609B172 mov.l @(8,r14),r0
L_0609B174:
    c.r[14] += 12;  // 0609B174 add #12,r14
    c.r[15] = c.r[14];  // 0609B176 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609B178 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609B17A rts ; mov.l @r15+,r14
}

void f_0609B188(SH2Context& c) {
    ran[2459] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609B188 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609B18A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0609B18C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0609B18E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609B190 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609B192 sts.l pr,@-r15
    c.r[15] -= 4;  // 0609B194 add #-4,r15
    c.r[14] = c.r[15];  // 0609B196 mov r15,r14
    c.r[1] = 0x0u;  // 0609B198 mov #0,r1
    st32(c.r[14], c.r[1]);  // 0609B19A mov.l r1,@r14
    c.r[1] = ld32(0x0609B244u);  // 0609B19C mov.l 0x0609B244,r1
    c.r[2] = ld32(c.r[1]);  // 0609B19E mov.l @r1,r2
    c.r[1] = ld32(c.r[2] + 60);  // 0609B1A0 mov.l @(60,r2),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609B1A2 tst r1,r1
    { const bool k = c.t; c.r[9] = 0x0u; if (k) { goto L_0609B1BA; } }  // 0609B1A4 bt/s 0x0609B1BA ; mov #0,r9
    c.r[1] -= 1;  // 0609B1A8 add #-1,r1
    c.t = (int32_t)c.r[1] > 0;  // 0609B1AA cmp/pl r1
    { const bool k = c.t; st32(c.r[2] + 60, c.r[1]); if (k) { goto L_0609B1BA; } }  // 0609B1AC bt/s 0x0609B1BA ; mov.l r1,@(60,r2)
    c.r[1] = ld32(0x0609B248u);  // 0609B1B0 mov.l 0x0609B248,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609B1B6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B1B6u) return; }  // 0609B1B2 jsr @r1 ; nop
    c.r[0] = 0x3u; goto L_0609B22C;  // 0609B1B6 bra 0x0609B22C ; mov #3,r0
L_0609B1BA:
    c.r[8] = ld32(0x0609B244u);  // 0609B1BA mov.l 0x0609B244,r8
    c.r[4] = ld32(c.r[8]);  // 0609B1BC mov.l @r8,r4
    c.r[0] = ld32(0x0609B24Cu);  // 0609B1BE mov.l 0x0609B24C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609B1C4u; c.r[4] += 64; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B1C4u) return; }  // 0609B1C0 jsr @r0 ; add #64,r4
    c.r[1] = ld32(0x0609B250u);  // 0609B1C4 mov.l 0x0609B250,r1
    c.r[1] = ld32(c.r[1]);  // 0609B1C6 mov.l @r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609B1C8 tst r1,r1
    { const bool k = c.t; c.r[0] = 0x2u; if (k) { goto L_0609B1D6; } }  // 0609B1CA bt/s 0x0609B1D6 ; mov #2,r0
    c.r[14] += 4; goto L_0609B22E;  // 0609B1CE bra 0x0609B22E ; add #4,r14
L_0609B1D2:
    c.r[0] = 0x1u; goto L_0609B22C;  // 0609B1D2 bra 0x0609B22C ; mov #1,r0
L_0609B1D6:
    c.r[4] = (uint32_t)(int16_t)ld16(0x0609B23Eu);  // 0609B1D6 mov.w 0x0609B23E,r4
    c.r[0] = ld32(0x0609B254u);  // 0609B1D8 mov.l 0x0609B254,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609B1DEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B1DEu) return; }  // 0609B1DA jsr @r0 ; nop
    c.t = c.r[0] == 0x1u;  // 0609B1DE cmp/eq #1,r0
    if (!c.t) { goto L_0609B1FE; }  // 0609B1E0 bf 0x0609B1FE
    c.r[4] = (uint32_t)(int16_t)ld16(0x0609B240u);  // 0609B1E2 mov.w 0x0609B240,r4
    c.r[1] = ld32(0x0609B258u);  // 0609B1E4 mov.l 0x0609B258,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609B1EAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B1EAu) return; }  // 0609B1E6 jsr @r1 ; nop
    c.r[4] = ld32(c.r[8]);  // 0609B1EA mov.l @r8,r4
    c.r[1] = c.r[4];  // 0609B1EC mov r4,r1
    c.r[1] += 76;  // 0609B1EE add #76,r1
    c.r[1] = ld32(c.r[1]);  // 0609B1F0 mov.l @r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609B1F2 tst r1,r1
    { const bool k = c.t; c.r[8] = 0x0u; if (k) { goto L_0609B200; } }  // 0609B1F4 bt/s 0x0609B200 ; mov #0,r8
    c.r[4] += 80;  // 0609B1F8 add #80,r4
    { const uint32_t x = c.r[1]; c.pr = 0x0609B1FEu; c.r[4] = ld32(c.r[4]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B1FEu) return; }  // 0609B1FA jsr @r1 ; mov.l @r4,r4
L_0609B1FE:
    c.r[8] = 0x0u;  // 0609B1FE mov #0,r8
L_0609B200:
    c.r[11] = ld32(0x0609B25Cu);  // 0609B200 mov.l 0x0609B25C,r11
    c.r[10] = ld32(0x0609B260u);  // 0609B202 mov.l 0x0609B260,r10
L_0609B204:
    { const uint32_t x = c.r[11]; c.pr = 0x0609B208u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B208u) return; }  // 0609B204 jsr @r11 ; mov r8,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609B208 tst r0,r0
    { const bool k = !c.t; c.r[5] = c.r[14]; if (k) { goto L_0609B220; } }  // 0609B20A bf/s 0x0609B220 ; mov r14,r5
    { const uint32_t x = c.r[10]; c.pr = 0x0609B212u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B212u) return; }  // 0609B20E jsr @r10 ; mov r8,r4
    c.t = (int32_t)c.r[0] >= 0;  // 0609B212 cmp/pz r0
    { const bool k = !c.t; c.r[2] = ld32(c.r[14]); if (k) { goto L_0609B22C; } }  // 0609B214 bf/s 0x0609B22C ; mov.l @r14,r2
    c.r[1] = 0x1Eu;  // 0609B218 mov #30,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0609B21A cmp/gt r1,r2
    { const bool k = c.t; c.r[9] += c.r[0]; if (k) { SH2_POLL(c); goto L_0609B1D2; } }  // 0609B21C bt/s 0x0609B1D2 ; add r0,r9
L_0609B220:
    c.r[8] += 1;  // 0609B220 add #1,r8
    c.r[1] = 0x7u;  // 0609B222 mov #7,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 0609B224 cmp/gt r1,r8
    { const bool k = !c.t; c.t = (int32_t)c.r[9] > 0; if (k) { SH2_POLL(c); goto L_0609B204; } }  // 0609B226 bf/s 0x0609B204 ; cmp/pl r9
    c.r[0] = c.t;  // 0609B22A movt r0
L_0609B22C:
    c.r[14] += 4;  // 0609B22C add #4,r14
L_0609B22E:
    c.r[15] = c.r[14];  // 0609B22E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609B230 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609B232 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0609B234 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0609B236 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609B238 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609B23A rts ; mov.l @r15+,r8
}

void f_0609B264(SH2Context& c) {
    ran[2460] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609B264 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0609B266 mov r15,r14
    c.r[1] = 0x7u;  // 0609B268 mov #7,r1
    c.t = c.r[4] > c.r[1];  // 0609B26A cmp/hi r1,r4
    { const bool k = c.t; c.r[2] = 0x0u; if (k) { goto L_0609B2D2; } }  // 0609B26C bt/s 0x0609B2D2 ; mov #0,r2
    c.r[1] = c.r[4];  // 0609B270 mov r4,r1
    c.r[1] += c.r[1];  // 0609B272 add r1,r1
    c.r[0] = 0x0609B280u;  // 0609B274 mova 0x0609B280,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0609B276 mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 0609B278 add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x0609B290u: goto L_0609B290; case 0x0609B29Au: goto L_0609B29A; case 0x0609B2A2u: goto L_0609B2A2; case 0x0609B2AAu: goto L_0609B2AA; case 0x0609B2B2u: goto L_0609B2B2; case 0x0609B2BAu: goto L_0609B2BA; case 0x0609B2C2u: goto L_0609B2C2; case 0x0609B2CAu: goto L_0609B2CA; default: sh2_call(c, x); return; } }  // 0609B27A jmp @r0 ; nop
L_0609B290:
    c.r[1] = ld32(0x0609B2ECu);  // 0609B290 mov.l 0x0609B2EC,r1
    c.r[1] = ld32(c.r[1]);  // 0609B292 mov.l @r1,r1
    c.r[1] += 88;  // 0609B294 add #88,r1
    c.r[2] = ld32(c.r[1]); goto L_0609B2D2;  // 0609B296 bra 0x0609B2D2 ; mov.l @r1,r2
L_0609B29A:
    c.r[1] = ld32(0x0609B2ECu);  // 0609B29A mov.l 0x0609B2EC,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609B2DCu);  // 0609B29C mov.w 0x0609B2DC,r0
    c.r[1] = ld32(c.r[1]); goto L_0609B2D0;  // 0609B29E bra 0x0609B2D0 ; mov.l @r1,r1
L_0609B2A2:
    c.r[1] = ld32(0x0609B2ECu);  // 0609B2A2 mov.l 0x0609B2EC,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609B2DEu);  // 0609B2A4 mov.w 0x0609B2DE,r0
    c.r[1] = ld32(c.r[1]); goto L_0609B2D0;  // 0609B2A6 bra 0x0609B2D0 ; mov.l @r1,r1
L_0609B2AA:
    c.r[1] = ld32(0x0609B2ECu);  // 0609B2AA mov.l 0x0609B2EC,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609B2E0u);  // 0609B2AC mov.w 0x0609B2E0,r0
    c.r[1] = ld32(c.r[1]); goto L_0609B2D0;  // 0609B2AE bra 0x0609B2D0 ; mov.l @r1,r1
L_0609B2B2:
    c.r[1] = ld32(0x0609B2ECu);  // 0609B2B2 mov.l 0x0609B2EC,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609B2E2u);  // 0609B2B4 mov.w 0x0609B2E2,r0
    c.r[1] = ld32(c.r[1]); goto L_0609B2D0;  // 0609B2B6 bra 0x0609B2D0 ; mov.l @r1,r1
L_0609B2BA:
    c.r[1] = ld32(0x0609B2ECu);  // 0609B2BA mov.l 0x0609B2EC,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609B2E4u);  // 0609B2BC mov.w 0x0609B2E4,r0
    c.r[1] = ld32(c.r[1]); goto L_0609B2D0;  // 0609B2BE bra 0x0609B2D0 ; mov.l @r1,r1
L_0609B2C2:
    c.r[1] = ld32(0x0609B2ECu);  // 0609B2C2 mov.l 0x0609B2EC,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609B2E6u);  // 0609B2C4 mov.w 0x0609B2E6,r0
    c.r[1] = ld32(c.r[1]); goto L_0609B2D0;  // 0609B2C6 bra 0x0609B2D0 ; mov.l @r1,r1
L_0609B2CA:
    c.r[1] = ld32(0x0609B2ECu);  // 0609B2CA mov.l 0x0609B2EC,r1
    c.r[1] = ld32(c.r[1]);  // 0609B2CC mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609B2E8u);  // 0609B2CE mov.w 0x0609B2E8,r0
L_0609B2D0:
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 0609B2D0 mov.l @(r0,r1),r2
L_0609B2D2:
    c.t = (c.r[2] & c.r[2]) == 0;  // 0609B2D2 tst r2,r2
    c.r[15] = c.r[14];  // 0609B2D4 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609B2D6 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.t; c.pc = x; return; }  // 0609B2D8 rts ; movt r0
}

void f_0609B2F0(SH2Context& c) {
    ran[2461] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609B2F0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609B2F2 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0609B2F4 mov r15,r14
    c.r[2] = c.r[4];  // 0609B2F6 mov r4,r2
    c.r[1] = 0x7u;  // 0609B2F8 mov #7,r1
    c.t = c.r[2] > c.r[1];  // 0609B2FA cmp/hi r1,r2
    { const bool k = c.t; c.r[4] = c.r[5]; if (k) { goto L_0609B370; } }  // 0609B2FC bt/s 0x0609B370 ; mov r5,r4
    c.r[1] = c.r[2];  // 0609B300 mov r2,r1
    c.r[1] += c.r[1];  // 0609B302 add r1,r1
    c.r[0] = 0x0609B310u;  // 0609B304 mova 0x0609B310,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0609B306 mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 0609B308 add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x0609B320u: goto L_0609B320; case 0x0609B32Au: goto L_0609B32A; case 0x0609B334u: goto L_0609B334; case 0x0609B33Eu: goto L_0609B33E; case 0x0609B348u: goto L_0609B348; case 0x0609B352u: goto L_0609B352; case 0x0609B35Cu: goto L_0609B35C; case 0x0609B366u: goto L_0609B366; default: sh2_call(c, x); return; } }  // 0609B30A jmp @r0 ; nop
L_0609B320:
    c.r[0] = ld32(0x0609B37Cu);  // 0609B320 mov.l 0x0609B37C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609B326u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B326u) return; }  // 0609B322 jsr @r0 ; nop
    c.r[15] = c.r[14]; goto L_0609B374;  // 0609B326 bra 0x0609B374 ; mov r14,r15
L_0609B32A:
    c.r[0] = ld32(0x0609B380u);  // 0609B32A mov.l 0x0609B380,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609B330u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B330u) return; }  // 0609B32C jsr @r0 ; nop
    c.r[15] = c.r[14]; goto L_0609B374;  // 0609B330 bra 0x0609B374 ; mov r14,r15
L_0609B334:
    c.r[0] = ld32(0x0609B384u);  // 0609B334 mov.l 0x0609B384,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609B33Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B33Au) return; }  // 0609B336 jsr @r0 ; nop
    c.r[15] = c.r[14]; goto L_0609B374;  // 0609B33A bra 0x0609B374 ; mov r14,r15
L_0609B33E:
    c.r[0] = ld32(0x0609B388u);  // 0609B33E mov.l 0x0609B388,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609B344u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B344u) return; }  // 0609B340 jsr @r0 ; nop
    c.r[15] = c.r[14]; goto L_0609B374;  // 0609B344 bra 0x0609B374 ; mov r14,r15
L_0609B348:
    c.r[0] = ld32(0x0609B38Cu);  // 0609B348 mov.l 0x0609B38C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609B34Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B34Eu) return; }  // 0609B34A jsr @r0 ; nop
    c.r[15] = c.r[14]; goto L_0609B374;  // 0609B34E bra 0x0609B374 ; mov r14,r15
L_0609B352:
    c.r[0] = ld32(0x0609B390u);  // 0609B352 mov.l 0x0609B390,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609B358u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B358u) return; }  // 0609B354 jsr @r0 ; nop
    c.r[15] = c.r[14]; goto L_0609B374;  // 0609B358 bra 0x0609B374 ; mov r14,r15
L_0609B35C:
    c.r[0] = ld32(0x0609B394u);  // 0609B35C mov.l 0x0609B394,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609B362u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B362u) return; }  // 0609B35E jsr @r0 ; nop
    c.r[15] = c.r[14]; goto L_0609B374;  // 0609B362 bra 0x0609B374 ; mov r14,r15
L_0609B366:
    c.r[0] = ld32(0x0609B398u);  // 0609B366 mov.l 0x0609B398,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609B36Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B36Cu) return; }  // 0609B368 jsr @r0 ; nop
    c.r[15] = c.r[14]; goto L_0609B374;  // 0609B36C bra 0x0609B374 ; mov r14,r15
L_0609B370:
    c.r[0] = 0x0u;  // 0609B370 mov #0,r0
    c.r[15] = c.r[14];  // 0609B372 mov r14,r15
L_0609B374:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609B374 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609B376 rts ; mov.l @r15+,r14
}

void f_0609B39C(SH2Context& c) {
    ran[2462] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609B39C mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0609B39E mov r15,r14
    c.r[1] = ld32(0x0609B3ACu);  // 0609B3A0 mov.l 0x0609B3AC,r1
    c.r[1] = ld32(c.r[1]);  // 0609B3A2 mov.l @r1,r1
    st32(c.r[1] + 60, c.r[4]);  // 0609B3A4 mov.l r4,@(60,r1)
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609B3A6 rts ; mov.l @r15+,r14
}

void f_0609B3B0(SH2Context& c) {
    ran[2463] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609B3B0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609B3B2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609B3B4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609B3B6 sts.l pr,@-r15
    c.r[4] = ld32(0x0609B3E0u);  // 0609B3B8 mov.l 0x0609B3E0,r4
    c.r[1] = ld32(0x0609B3E4u);  // 0609B3BA mov.l 0x0609B3E4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609B3C0u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B3C0u) return; }  // 0609B3BC jsr @r1 ; mov r15,r14
    c.r[9] = ld32(0x0609B3E8u);  // 0609B3C0 mov.l 0x0609B3E8,r9
L_0609B3C2:
    { const uint32_t x = c.r[9]; c.pr = 0x0609B3C6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B3C6u) return; }  // 0609B3C2 jsr @r9 ; nop
    c.t = c.r[0] == 0x1u;  // 0609B3C6 cmp/eq #1,r0
    { const bool k = c.t; c.r[8] = c.r[0]; if (k) { SH2_POLL(c); goto L_0609B3C2; } }  // 0609B3C8 bt/s 0x0609B3C2 ; mov r0,r8
    c.r[1] = ld32(0x0609B3E4u);  // 0609B3CC mov.l 0x0609B3E4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609B3D2u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B3D2u) return; }  // 0609B3CE jsr @r1 ; mov #0,r4
    c.r[15] = c.r[14];  // 0609B3D2 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609B3D4 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609B3D6 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609B3D8 mov.l @r15+,r9
    c.r[0] = c.r[8];  // 0609B3DA mov r8,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609B3DC rts ; mov.l @r15+,r8
}

void f_0609B3EC(SH2Context& c) {
    ran[2464] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609B3EC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609B3EE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0609B3F0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0609B3F2 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0609B3F4 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0609B3F6 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609B3F8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609B3FA sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0609B3FC mov r15,r14
    c.r[2] = ld32(0x0609B57Cu);  // 0609B3FE mov.l 0x0609B57C,r2
    c.r[1] = ld32(c.r[2]);  // 0609B400 mov.l @r2,r1
    c.r[1] += 84;  // 0609B402 add #84,r1
    c.r[1] = ld32(c.r[1]);  // 0609B404 mov.l @r1,r1
    c.r[8] = 0x0u;  // 0609B406 mov #0,r8
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 0609B408 cmp/ge r1,r8
    { const bool k = c.t; c.r[10] = c.r[4]; if (k) { goto L_0609B4DC; } }  // 0609B40A bt/s 0x0609B4DC ; mov r4,r10
    c.r[11] = c.r[2];  // 0609B40E mov r2,r11
    c.r[13] = ld32(0x0609B580u);  // 0609B410 mov.l 0x0609B580,r13
    c.r[9] = 0x0u;  // 0609B412 mov #0,r9
    c.r[12] = 0x5Cu;  // 0609B414 mov #92,r12
L_0609B416:
    c.r[2] = ld32(c.r[11]);  // 0609B416 mov.l @r11,r2
    c.r[1] = c.r[2];  // 0609B418 mov r2,r1
    c.r[1] += 88;  // 0609B41A add #88,r1
    c.r[0] = ld32(c.r[1]);  // 0609B41C mov.l @r1,r0
    c.t = c.r[0] == 0x1u;  // 0609B41E cmp/eq #1,r0
    { const bool k = !c.t; c.r[2] += c.r[9]; if (k) { goto L_0609B44C; } }  // 0609B420 bf/s 0x0609B44C ; add r9,r2
    c.r[1] = c.r[2];  // 0609B424 mov r2,r1
    c.r[1] += 93;  // 0609B426 add #93,r1
    c.r[2] += 92;  // 0609B428 add #92,r2
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0609B42A mov.b @r1,r5
    c.r[0] = ld32(0x0609B584u);  // 0609B42C mov.l 0x0609B584,r0
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0609B42E mov.b @r2,r4
    c.r[5] = c.r[5] & 0xFFu;  // 0609B430 extu.b r5,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0609B436u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B436u) return; }  // 0609B432 jsr @r0 ; extu.b r4,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609B436 tst r0,r0
    if (!c.t) { goto L_0609B4DC; }  // 0609B438 bf 0x0609B4DC
    { const uint32_t x = c.r[13]; c.pr = 0x0609B43Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B43Eu) return; }  // 0609B43A jsr @r13 ; nop
    c.r[1] = ld32(c.r[10]);  // 0609B43E mov.l @r10,r1
    c.r[1] += 1;  // 0609B440 add #1,r1
    st32(c.r[10], c.r[1]);  // 0609B442 mov.l r1,@r10
    c.r[2] = ld32(c.r[11]);  // 0609B444 mov.l @r11,r2
    c.r[1] = 0x2u;  // 0609B446 mov #2,r1
    c.r[2] += 88;  // 0609B448 add #88,r2
    st32(c.r[2], c.r[1]);  // 0609B44A mov.l r1,@r2
L_0609B44C:
    c.r[4] = ld32(c.r[11]);  // 0609B44C mov.l @r11,r4
    c.r[1] = c.r[4];  // 0609B44E mov r4,r1
    c.r[1] += 88;  // 0609B450 add #88,r1
    c.r[0] = ld32(c.r[1]);  // 0609B452 mov.l @r1,r0
    c.t = c.r[0] == 0x2u;  // 0609B454 cmp/eq #2,r0
    { const bool k = !c.t; c.r[5] = c.r[4]; if (k) { goto L_0609B492; } }  // 0609B456 bf/s 0x0609B492 ; mov r4,r5
    c.r[5] += c.r[12];  // 0609B45A add r12,r5
    c.r[5] += 2;  // 0609B45C add #2,r5
    c.r[4] += c.r[9];  // 0609B45E add r9,r4
    c.r[4] += 92;  // 0609B460 add #92,r4
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[4]);  // 0609B462 mov.b @r4,r4
    c.r[0] = ld32(0x0609B588u);  // 0609B464 mov.l 0x0609B588,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609B46Au; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B46Au) return; }  // 0609B466 jsr @r0 ; extu.b r4,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609B46A tst r0,r0
    if (!c.t) { goto L_0609B4DC; }  // 0609B46C bf 0x0609B4DC
    { const uint32_t x = c.r[13]; c.pr = 0x0609B472u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B472u) return; }  // 0609B46E jsr @r13 ; nop
    c.r[1] = ld32(c.r[10]);  // 0609B472 mov.l @r10,r1
    c.r[1] += 1;  // 0609B474 add #1,r1
    st32(c.r[10], c.r[1]);  // 0609B476 mov.l r1,@r10
    c.r[2] = ld32(c.r[11]);  // 0609B478 mov.l @r11,r2
    c.r[1] = c.r[2];  // 0609B47A mov r2,r1
    c.r[1] += c.r[9];  // 0609B47C add r9,r1
    c.r[1] += 104;  // 0609B47E add #104,r1
    c.r[1] = ld32(c.r[1]);  // 0609B480 mov.l @r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609B482 tst r1,r1
    { const bool k = c.t; c.r[1] = 0x1u; if (k) { goto L_0609B48E; } }  // 0609B484 bt/s 0x0609B48E ; mov #1,r1
    c.r[2] += 88;  // 0609B488 add #88,r2
    c.r[1] = 0x3u; goto L_0609B490;  // 0609B48A bra 0x0609B490 ; mov #3,r1
L_0609B48E:
    c.r[2] += 88;  // 0609B48E add #88,r2
L_0609B490:
    st32(c.r[2], c.r[1]);  // 0609B490 mov.l r1,@r2
L_0609B492:
    c.r[2] = ld32(c.r[11]);  // 0609B492 mov.l @r11,r2
    c.r[1] = c.r[2];  // 0609B494 mov r2,r1
    c.r[1] += 88;  // 0609B496 add #88,r1
    c.r[0] = ld32(c.r[1]);  // 0609B498 mov.l @r1,r0
    c.t = c.r[0] == 0x3u;  // 0609B49A cmp/eq #3,r0
    { const bool k = !c.t; c.r[2] += c.r[9]; if (k) { goto L_0609B4CC; } }  // 0609B49C bf/s 0x0609B4CC ; add r9,r2
    c.r[1] = c.r[2];  // 0609B4A0 mov r2,r1
    c.r[1] += 104;  // 0609B4A2 add #104,r1
    c.r[6] = ld32(c.r[1]);  // 0609B4A4 mov.l @r1,r6
    c.r[0] = ld32(0x0609B58Cu);  // 0609B4A6 mov.l 0x0609B58C,r0
    c.r[1] = c.r[2];  // 0609B4A8 mov r2,r1
    c.r[2] += 92;  // 0609B4AA add #92,r2
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0609B4AC mov.b @r2,r4
    c.r[1] += 100;  // 0609B4AE add #100,r1
    c.r[5] = ld32(c.r[1]);  // 0609B4B0 mov.l @r1,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0609B4B6u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B4B6u) return; }  // 0609B4B2 jsr @r0 ; extu.b r4,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609B4B6 tst r0,r0
    if (!c.t) { goto L_0609B4DC; }  // 0609B4B8 bf 0x0609B4DC
    { const uint32_t x = c.r[13]; c.pr = 0x0609B4BEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B4BEu) return; }  // 0609B4BA jsr @r13 ; nop
    c.r[1] = ld32(c.r[10]);  // 0609B4BE mov.l @r10,r1
    c.r[1] += 1;  // 0609B4C0 add #1,r1
    st32(c.r[10], c.r[1]);  // 0609B4C2 mov.l r1,@r10
    c.r[2] = ld32(c.r[11]);  // 0609B4C4 mov.l @r11,r2
    c.r[1] = 0x1u;  // 0609B4C6 mov #1,r1
    c.r[2] += 88;  // 0609B4C8 add #88,r2
    st32(c.r[2], c.r[1]);  // 0609B4CA mov.l r1,@r2
L_0609B4CC:
    c.r[9] += 16;  // 0609B4CC add #16,r9
    c.r[1] = ld32(c.r[11]);  // 0609B4CE mov.l @r11,r1
    c.r[1] += 84;  // 0609B4D0 add #84,r1
    c.r[1] = ld32(c.r[1]);  // 0609B4D2 mov.l @r1,r1
    c.r[8] += 1;  // 0609B4D4 add #1,r8
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 0609B4D6 cmp/ge r1,r8
    { const bool k = !c.t; c.r[12] += 16; if (k) { SH2_POLL(c); goto L_0609B416; } }  // 0609B4D8 bf/s 0x0609B416 ; add #16,r12
L_0609B4DC:
    c.r[1] = ld32(0x0609B57Cu);  // 0609B4DC mov.l 0x0609B57C,r1
    c.r[2] = ld32(c.r[1]);  // 0609B4DE mov.l @r1,r2
    c.r[3] = c.r[2];  // 0609B4E0 mov r2,r3
    c.r[3] += 84;  // 0609B4E2 add #84,r3
    c.r[1] = ld32(c.r[3]);  // 0609B4E4 mov.l @r3,r1
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 0609B4E6 cmp/ge r1,r8
    { const bool k = !c.t; c.r[1] = 0x0u; if (k) { goto L_0609B4F0; } }  // 0609B4E8 bf/s 0x0609B4F0 ; mov #0,r1
    st32(c.r[3], c.r[1]); goto L_0609B544;  // 0609B4EC bra 0x0609B544 ; mov.l r1,@r3
L_0609B4F0:
    c.r[6] = 0x0u;  // 0609B4F0 mov #0,r6
    c.r[5] = c.r[3];  // 0609B4F2 mov r3,r5
    c.r[7] = c.r[2];  // 0609B4F4 mov r2,r7
    c.r[3] = c.r[8];  // 0609B4F6 mov r8,r3
    c.r[3] <<= 2;  // 0609B4F8 shll2 r3
    c.r[3] <<= 2;  // 0609B4FA shll2 r3
    c.r[3] += c.r[7];  // 0609B4FC add r7,r3
L_0609B4FE:
    c.r[2] = c.r[7];  // 0609B4FE mov r7,r2
    c.r[2] += 92;  // 0609B500 add #92,r2
    c.r[1] = c.r[3];  // 0609B502 mov r3,r1
    c.r[1] += 92;  // 0609B504 add #92,r1
    c.r[8] += 1;  // 0609B506 add #1,r8
    c.r[1] = ld32(c.r[1]);  // 0609B508 mov.l @r1,r1
    c.r[6] += 1;  // 0609B50A add #1,r6
    st32(c.r[2], c.r[1]);  // 0609B50C mov.l r1,@r2
    c.r[2] = c.r[7];  // 0609B50E mov r7,r2
    c.r[1] = c.r[3];  // 0609B510 mov r3,r1
    c.r[1] += 96;  // 0609B512 add #96,r1
    c.r[1] = ld32(c.r[1]);  // 0609B514 mov.l @r1,r1
    c.r[2] += 96;  // 0609B516 add #96,r2
    st32(c.r[2], c.r[1]);  // 0609B518 mov.l r1,@r2
    c.r[2] = c.r[7];  // 0609B51A mov r7,r2
    c.r[1] = c.r[3];  // 0609B51C mov r3,r1
    c.r[1] += 100;  // 0609B51E add #100,r1
    c.r[1] = ld32(c.r[1]);  // 0609B520 mov.l @r1,r1
    c.r[2] += 100;  // 0609B522 add #100,r2
    st32(c.r[2], c.r[1]);  // 0609B524 mov.l r1,@r2
    c.r[2] = c.r[7];  // 0609B526 mov r7,r2
    c.r[2] += 104;  // 0609B528 add #104,r2
    c.r[1] = c.r[3];  // 0609B52A mov r3,r1
    c.r[1] += 104;  // 0609B52C add #104,r1
    c.r[1] = ld32(c.r[1]);  // 0609B52E mov.l @r1,r1
    c.r[3] += 16;  // 0609B530 add #16,r3
    st32(c.r[2], c.r[1]);  // 0609B532 mov.l r1,@r2
    c.r[1] = ld32(c.r[5]);  // 0609B534 mov.l @r5,r1
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 0609B536 cmp/ge r1,r8
    { const bool k = !c.t; c.r[7] += 16; if (k) { SH2_POLL(c); goto L_0609B4FE; } }  // 0609B538 bf/s 0x0609B4FE ; add #16,r7
    c.r[1] = ld32(0x0609B57Cu);  // 0609B53C mov.l 0x0609B57C,r1
    c.r[1] = ld32(c.r[1]);  // 0609B53E mov.l @r1,r1
    c.r[1] += 84;  // 0609B540 add #84,r1
    st32(c.r[1], c.r[6]);  // 0609B542 mov.l r6,@r1
L_0609B544:
    c.r[0] = ld32(0x0609B590u);  // 0609B544 mov.l 0x0609B590,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609B54Au; c.r[4] = 0x40u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B54Au) return; }  // 0609B546 jsr @r0 ; mov #64,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609B54A tst r0,r0
    if (c.t) { goto L_0609B560; }  // 0609B54C bt 0x0609B560
    c.r[1] = ld32(0x0609B57Cu);  // 0609B54E mov.l 0x0609B57C,r1
    c.r[2] = ld32(c.r[1]);  // 0609B550 mov.l @r1,r2
    c.r[1] = c.r[2];  // 0609B552 mov r2,r1
    c.r[1] += 84;  // 0609B554 add #84,r1
    c.r[1] = ld32(c.r[1]);  // 0609B556 mov.l @r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609B558 tst r1,r1
    { const bool k = !c.t; c.r[2] += 88; if (k) { goto L_0609B560; } }  // 0609B55A bf/s 0x0609B560 ; add #88,r2
    st32(c.r[2], c.r[1]);  // 0609B55E mov.l r1,@r2
L_0609B560:
    c.r[15] = c.r[14];  // 0609B560 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609B562 lds.l @r15+,pr
    c.r[1] = ld32(0x0609B57Cu);  // 0609B564 mov.l 0x0609B57C,r1
    c.r[1] = ld32(c.r[1]);  // 0609B566 mov.l @r1,r1
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609B568 mov.l @r15+,r14
    c.r[1] += 84;  // 0609B56A add #84,r1
    c.r[0] = ld32(c.r[1]);  // 0609B56C mov.l @r1,r0
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0609B56E mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0609B570 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0609B572 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0609B574 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609B576 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609B578 rts ; mov.l @r15+,r8
}

void f_0609B594(SH2Context& c) {
    ran[2465] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609B594 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609B596 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0609B598 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609B59A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609B59C sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0609B59E mov r15,r14
    c.r[10] = ld32(0x0609B610u);  // 0609B5A0 mov.l 0x0609B610,r10
    c.r[1] = ld32(c.r[10]);  // 0609B5A2 mov.l @r10,r1
    c.r[9] = (uint32_t)(int16_t)ld16(0x0609B60Cu);  // 0609B5A4 mov.w 0x0609B60C,r9
    c.r[0] = c.r[1];  // 0609B5A6 mov r1,r0
    c.r[2] = ld32(c.r[0] + c.r[9]);  // 0609B5A8 mov.l @(r0,r9),r2
    c.r[0] = c.r[2];  // 0609B5AA mov r2,r0
    c.t = c.r[0] == 0x1u;  // 0609B5AC cmp/eq #1,r0
    { const bool k = !c.t; c.r[8] = c.r[4]; if (k) { goto L_0609B5D4; } }  // 0609B5AE bf/s 0x0609B5D4 ; mov r4,r8
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609B60Eu);  // 0609B5B2 mov.w 0x0609B60E,r0
    c.r[4] = ld32(c.r[0] + c.r[1]);  // 0609B5B4 mov.l @(r0,r1),r4
    c.r[0] = ld32(0x0609B614u);  // 0609B5B6 mov.l 0x0609B614,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609B5BCu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B5BCu) return; }  // 0609B5B8 jsr @r0 ; nop
    c.r[1] = ld32(c.r[8]);  // 0609B5BC mov.l @r8,r1
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609B5BE tst r0,r0
    c.r[1] += 1;  // 0609B5C0 add #1,r1
    { const bool k = !c.t; st32(c.r[8], c.r[1]); if (k) { goto L_0609B5CE; } }  // 0609B5C2 bf/s 0x0609B5CE ; mov.l r1,@r8
    c.r[2] = ld32(c.r[10]);  // 0609B5C6 mov.l @r10,r2
    c.r[1] = 0x2u;  // 0609B5C8 mov #2,r1
    c.r[0] = c.r[2];  // 0609B5CA mov r2,r0
    st32(c.r[0] + c.r[9], c.r[1]);  // 0609B5CC mov.l r1,@(r0,r9)
L_0609B5CE:
    c.r[1] = ld32(0x0609B618u);  // 0609B5CE mov.l 0x0609B618,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609B5D4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B5D4u) return; }  // 0609B5D0 jsr @r1 ; nop
L_0609B5D4:
    c.r[9] = ld32(0x0609B610u);  // 0609B5D4 mov.l 0x0609B610,r9
    c.r[1] = ld32(c.r[9]);  // 0609B5D6 mov.l @r9,r1
    c.r[8] = (uint32_t)(int16_t)ld16(0x0609B60Cu);  // 0609B5D8 mov.w 0x0609B60C,r8
    c.r[0] = c.r[1];  // 0609B5DA mov r1,r0
    c.r[1] = ld32(c.r[0] + c.r[8]);  // 0609B5DC mov.l @(r0,r8),r1
    c.r[0] = c.r[1];  // 0609B5DE mov r1,r0
    c.t = c.r[0] == 0x2u;  // 0609B5E0 cmp/eq #2,r0
    if (!c.t) { goto L_0609B5F6; }  // 0609B5E2 bf 0x0609B5F6
    c.r[0] = ld32(0x0609B61Cu);  // 0609B5E4 mov.l 0x0609B61C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609B5EAu; c.r[4] = 0x40u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B5EAu) return; }  // 0609B5E6 jsr @r0 ; mov #64,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609B5EA tst r0,r0
    if (c.t) { goto L_0609B5F6; }  // 0609B5EC bt 0x0609B5F6
    c.r[2] = ld32(c.r[9]);  // 0609B5EE mov.l @r9,r2
    c.r[1] = 0x0u;  // 0609B5F0 mov #0,r1
    c.r[0] = c.r[2];  // 0609B5F2 mov r2,r0
    st32(c.r[0] + c.r[8], c.r[1]);  // 0609B5F4 mov.l r1,@(r0,r8)
L_0609B5F6:
    c.r[15] = c.r[14];  // 0609B5F6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609B5F8 lds.l @r15+,pr
    c.r[1] = ld32(0x0609B610u);  // 0609B5FA mov.l 0x0609B610,r1
    c.r[1] = ld32(c.r[1]);  // 0609B5FC mov.l @r1,r1
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609B5FE mov.l @r15+,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609B60Cu);  // 0609B600 mov.w 0x0609B60C,r0
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 0609B602 mov.l @(r0,r1),r0
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0609B604 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609B606 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609B608 rts ; mov.l @r15+,r8
}

void f_0609B620(SH2Context& c) {
    ran[2466] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609B620 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609B622 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0609B624 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0609B626 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0609B628 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609B62A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609B62C sts.l pr,@-r15
    c.r[15] -= 8;  // 0609B62E add #-8,r15
    c.r[14] = c.r[15];  // 0609B630 mov r15,r14
    c.r[9] = ld32(0x0609B75Cu);  // 0609B632 mov.l 0x0609B75C,r9
    c.r[1] = ld32(c.r[9]);  // 0609B634 mov.l @r9,r1
    c.r[8] = (uint32_t)(int16_t)ld16(0x0609B750u);  // 0609B636 mov.w 0x0609B750,r8
    c.r[0] = c.r[1];  // 0609B638 mov r1,r0
    c.r[2] = ld32(c.r[0] + c.r[8]);  // 0609B63A mov.l @(r0,r8),r2
    c.r[0] = c.r[2];  // 0609B63C mov r2,r0
    c.t = c.r[0] == 0x1u;  // 0609B63E cmp/eq #1,r0
    { const bool k = !c.t; c.r[11] = c.r[4]; if (k) { goto L_0609B6A6; } }  // 0609B640 bf/s 0x0609B6A6 ; mov r4,r11
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609B752u);  // 0609B644 mov.w 0x0609B752,r0
    c.r[4] = ld32(c.r[0] + c.r[1]);  // 0609B646 mov.l @(r0,r1),r4
    c.r[0] = ld32(0x0609B760u);  // 0609B648 mov.l 0x0609B760,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609B64Eu; c.r[5] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B64Eu) return; }  // 0609B64A jsr @r0 ; mov r14,r5
    c.r[1] = ld32(0x0609B764u);  // 0609B64E mov.l 0x0609B764,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609B654u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B654u) return; }  // 0609B650 jsr @r1 ; nop
    c.r[1] = ld32(c.r[11]);  // 0609B654 mov.l @r11,r1
    c.r[1] += 1;  // 0609B656 add #1,r1
    st32(c.r[11], c.r[1]);  // 0609B658 mov.l r1,@r11
    c.r[3] = ld32(c.r[9]);  // 0609B65A mov.l @r9,r3
    c.r[2] = ld32(c.r[14]);  // 0609B65C mov.l @r14,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609B754u);  // 0609B65E mov.w 0x0609B754,r0
    c.r[1] = ld32(c.r[0] + c.r[3]);  // 0609B660 mov.l @(r0,r3),r1
    c.r[2] -= c.r[1];  // 0609B662 sub r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609B756u);  // 0609B664 mov.w 0x0609B756,r0
    c.r[1] = ld32(c.r[0] + c.r[3]);  // 0609B666 mov.l @(r0,r3),r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0609B668 cmp/gt r1,r2
    { const bool k = !c.t; st32(c.r[14], c.r[2]); if (k) { goto L_0609B670; } }  // 0609B66A bf/s 0x0609B670 ; mov.l r2,@r14
    c.r[2] = c.r[1];  // 0609B66E mov r1,r2
L_0609B670:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0609B758u);  // 0609B670 mov.w 0x0609B758,r1
    c.r[0] = c.r[3];  // 0609B672 mov r3,r0
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 0609B674 mov.l @(r0,r1),r1
    st32(c.r[14], c.r[2]);  // 0609B676 mov.l r2,@r14
    st32(c.r[1], c.r[2]);  // 0609B678 mov.l r2,@r1
    c.r[3] = ld32(c.r[9]);  // 0609B67A mov.l @r9,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x0609B75Au);  // 0609B67C mov.w 0x0609B75A,r7
    c.r[0] = c.r[3];  // 0609B67E mov r3,r0
    c.r[1] = ld32(c.r[0] + c.r[7]);  // 0609B680 mov.l @(r0,r7),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609B682 tst r1,r1
    if (!c.t) { goto L_0609B68C; }  // 0609B684 bf 0x0609B68C
    st32(c.r[0] + c.r[8], c.r[1]);  // 0609B686 mov.l r1,@(r0,r8)
    c.r[0] = 0x0u; goto L_0609B73C;  // 0609B688 bra 0x0609B73C ; mov #0,r0
L_0609B68C:
    c.r[1] = ld32(c.r[14]);  // 0609B68C mov.l @r14,r1
    c.t = (int32_t)c.r[1] > 0;  // 0609B68E cmp/pl r1
    { const bool k = c.t; c.r[1] = 0x2u; if (k) { goto L_0609B6A2; } }  // 0609B690 bt/s 0x0609B6A2 ; mov #2,r1
    c.r[2] = 0x0u;  // 0609B694 mov #0,r2
    c.r[0] = c.r[3];  // 0609B696 mov r3,r0
    st32(c.r[0] + c.r[8], c.r[2]);  // 0609B698 mov.l r2,@(r0,r8)
    c.r[1] = ld32(c.r[0] + c.r[7]);  // 0609B69A mov.l @(r0,r7),r1
    st32(c.r[1], c.r[2]);  // 0609B69C mov.l r2,@r1
    c.r[0] = 0x0u; goto L_0609B73C;  // 0609B69E bra 0x0609B73C ; mov #0,r0
L_0609B6A2:
    c.r[0] = c.r[3];  // 0609B6A2 mov r3,r0
    st32(c.r[0] + c.r[8], c.r[1]);  // 0609B6A4 mov.l r1,@(r0,r8)
L_0609B6A6:
    c.r[12] = ld32(0x0609B75Cu);  // 0609B6A6 mov.l 0x0609B75C,r12
    c.r[2] = ld32(c.r[12]);  // 0609B6A8 mov.l @r12,r2
    c.r[10] = (uint32_t)(int16_t)ld16(0x0609B750u);  // 0609B6AA mov.w 0x0609B750,r10
    c.r[0] = c.r[2];  // 0609B6AC mov r2,r0
    c.r[9] = ld32(c.r[0] + c.r[10]);  // 0609B6AE mov.l @(r0,r10),r9
    c.r[0] = c.r[9];  // 0609B6B0 mov r9,r0
    c.t = c.r[0] == 0x2u;  // 0609B6B2 cmp/eq #2,r0
    if (!c.t) { goto L_0609B6F4; }  // 0609B6B4 bf 0x0609B6F4
    c.r[0] = ld32(c.r[2] + 52);  // 0609B6B6 mov.l @(52,r2),r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0609B6B8 cmp/eq #-1,r0
    { const bool k = !c.t; c.r[0] = c.r[2]; if (k) { goto L_0609B6DC; } }  // 0609B6BA bf/s 0x0609B6DC ; mov r2,r0
    c.r[3] = (uint32_t)(int16_t)ld16(0x0609B752u);  // 0609B6BE mov.w 0x0609B752,r3
    c.r[1] = ld32(c.r[0] + c.r[3]);  // 0609B6C0 mov.l @(r0,r3),r1
    st32(c.r[2] + 52, c.r[1]);  // 0609B6C2 mov.l r1,@(52,r2)
    c.r[1] = (uint32_t)(int16_t)ld16(0x0609B758u);  // 0609B6C4 mov.w 0x0609B758,r1
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 0609B6C6 mov.l @(r0,r1),r1
    c.r[6] = ld32(c.r[1]);  // 0609B6C8 mov.l @r1,r6
    c.r[4] = ld32(c.r[0] + c.r[3]);  // 0609B6CA mov.l @(r0,r3),r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x0609B754u);  // 0609B6CC mov.w 0x0609B754,r1
    c.r[5] = ld32(c.r[0] + c.r[1]);  // 0609B6CE mov.l @(r0,r1),r5
    c.r[0] = ld32(0x0609B768u);  // 0609B6D0 mov.l 0x0609B768,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609B6D6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B6D6u) return; }  // 0609B6D2 jsr @r0 ; nop
    c.r[8] = c.r[0];  // 0609B6D6 mov r0,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 0609B6D8 tst r8,r8
    if (c.t) { goto L_0609B6E0; }  // 0609B6DA bt 0x0609B6E0
L_0609B6DC:
    c.r[0] = c.r[9]; goto L_0609B73C;  // 0609B6DC bra 0x0609B73C ; mov r9,r0
L_0609B6E0:
    c.r[1] = ld32(0x0609B764u);  // 0609B6E0 mov.l 0x0609B764,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609B6E6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B6E6u) return; }  // 0609B6E2 jsr @r1 ; nop
    c.r[1] = ld32(c.r[11]);  // 0609B6E6 mov.l @r11,r1
    c.r[1] += 1;  // 0609B6E8 add #1,r1
    st32(c.r[11], c.r[1]);  // 0609B6EA mov.l r1,@r11
    c.r[2] = ld32(c.r[12]);  // 0609B6EC mov.l @r12,r2
    c.r[1] = 0x3u;  // 0609B6EE mov #3,r1
    c.r[0] = c.r[2];  // 0609B6F0 mov r2,r0
    st32(c.r[0] + c.r[10], c.r[1]);  // 0609B6F2 mov.l r1,@(r0,r10)
L_0609B6F4:
    c.r[10] = ld32(0x0609B75Cu);  // 0609B6F4 mov.l 0x0609B75C,r10
    c.r[1] = ld32(c.r[10]);  // 0609B6F6 mov.l @r10,r1
    c.r[9] = (uint32_t)(int16_t)ld16(0x0609B750u);  // 0609B6F8 mov.w 0x0609B750,r9
    c.r[0] = c.r[1];  // 0609B6FA mov r1,r0
    c.r[1] = ld32(c.r[0] + c.r[9]);  // 0609B6FC mov.l @(r0,r9),r1
    c.r[0] = c.r[1];  // 0609B6FE mov r1,r0
    c.t = c.r[0] == 0x3u;  // 0609B700 cmp/eq #3,r0
    { const bool k = !c.t; c.r[4] = c.r[14]; if (k) { goto L_0609B73A; } }  // 0609B702 bf/s 0x0609B73A ; mov r14,r4
    c.r[0] = ld32(0x0609B76Cu);  // 0609B706 mov.l 0x0609B76C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609B70Cu; c.r[4] += 4; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B70Cu) return; }  // 0609B708 jsr @r0 ; add #4,r4
    c.r[8] = c.r[0];  // 0609B70C mov r0,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 0609B70E tst r8,r8
    { const bool k = !c.t; c.r[0] = 0x1u; if (k) { goto L_0609B73C; } }  // 0609B710 bf/s 0x0609B73C ; mov #1,r0
    c.r[1] = ld32(0x0609B764u);  // 0609B714 mov.l 0x0609B764,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609B71Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B71Au) return; }  // 0609B716 jsr @r1 ; nop
    c.r[1] = ld32(c.r[11]);  // 0609B71A mov.l @r11,r1
    c.r[1] += 1;  // 0609B71C add #1,r1
    st32(c.r[11], c.r[1]);  // 0609B71E mov.l r1,@r11
    c.r[1] = ld32(c.r[10]);  // 0609B720 mov.l @r10,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0609B75Au);  // 0609B722 mov.w 0x0609B75A,r2
    c.r[0] = c.r[1];  // 0609B724 mov r1,r0
    st32(c.r[0] + c.r[9], c.r[8]);  // 0609B726 mov.l r8,@(r0,r9)
    c.r[2] = ld32(c.r[0] + c.r[2]);  // 0609B728 mov.l @(r0,r2),r2
    c.r[1] = ld32(c.r[14] + 4);  // 0609B72A mov.l @(4,r14),r1
    c.r[0] = 0x0u;  // 0609B72C mov #0,r0
    c.r[1] += c.r[1];  // 0609B72E add r1,r1
    st32(c.r[2], c.r[1]);  // 0609B730 mov.l r1,@r2
    c.r[2] = ld32(c.r[10]);  // 0609B732 mov.l @r10,r2
    c.r[1] = 0xFFFFFFFFu;  // 0609B734 mov #-1,r1
    st32(c.r[2] + 52, c.r[1]); goto L_0609B73C;  // 0609B736 bra 0x0609B73C ; mov.l r1,@(52,r2)
L_0609B73A:
    c.r[0] = 0x1u;  // 0609B73A mov #1,r0
L_0609B73C:
    c.r[14] += 8;  // 0609B73C add #8,r14
    c.r[15] = c.r[14];  // 0609B73E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609B740 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609B742 mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0609B744 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0609B746 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0609B748 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609B74A mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609B74C rts ; mov.l @r15+,r8
}

void f_0609B770(SH2Context& c) {
    ran[2467] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609B770 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609B772 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0609B774 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0609B776 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609B778 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609B77A sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0609B77C mov r15,r14
    c.r[11] = ld32(0x0609B800u);  // 0609B77E mov.l 0x0609B800,r11
    c.r[1] = ld32(c.r[11]);  // 0609B780 mov.l @r11,r1
    c.r[10] = (uint32_t)(int16_t)ld16(0x0609B7F8u);  // 0609B782 mov.w 0x0609B7F8,r10
    c.r[0] = c.r[1];  // 0609B784 mov r1,r0
    c.r[8] = ld32(c.r[0] + c.r[10]);  // 0609B786 mov.l @(r0,r10),r8
    c.r[0] = c.r[8];  // 0609B788 mov r8,r0
    c.t = c.r[0] == 0x1u;  // 0609B78A cmp/eq #1,r0
    { const bool k = !c.t; c.r[9] = c.r[4]; if (k) { goto L_0609B7BE; } }  // 0609B78C bf/s 0x0609B7BE ; mov r4,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609B7FAu);  // 0609B790 mov.w 0x0609B7FA,r0
    c.r[6] = ld32(c.r[0] + c.r[1]);  // 0609B792 mov.l @(r0,r1),r6
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609B7FCu);  // 0609B794 mov.w 0x0609B7FC,r0
    c.r[5] = ld32(c.r[0] + c.r[1]);  // 0609B796 mov.l @(r0,r1),r5
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609B7FEu);  // 0609B798 mov.w 0x0609B7FE,r0
    c.r[4] = ld32(c.r[0] + c.r[1]);  // 0609B79A mov.l @(r0,r1),r4
    c.r[0] = ld32(0x0609B804u);  // 0609B79C mov.l 0x0609B804,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609B7A2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B7A2u) return; }  // 0609B79E jsr @r0 ; nop
    c.r[2] = c.r[0];  // 0609B7A2 mov r0,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0609B7A4 tst r2,r2
    { const bool k = !c.t; c.r[0] = 0x1u; if (k) { goto L_0609B7E8; } }  // 0609B7A6 bf/s 0x0609B7E8 ; mov #1,r0
    c.r[1] = ld32(0x0609B808u);  // 0609B7AA mov.l 0x0609B808,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609B7B0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B7B0u) return; }  // 0609B7AC jsr @r1 ; nop
    c.r[1] = ld32(c.r[9]);  // 0609B7B0 mov.l @r9,r1
    c.r[1] += 1;  // 0609B7B2 add #1,r1
    st32(c.r[9], c.r[1]);  // 0609B7B4 mov.l r1,@r9
    c.r[2] = ld32(c.r[11]);  // 0609B7B6 mov.l @r11,r2
    c.r[1] = 0x2u;  // 0609B7B8 mov #2,r1
    c.r[0] = c.r[2];  // 0609B7BA mov r2,r0
    st32(c.r[0] + c.r[10], c.r[1]);  // 0609B7BC mov.l r1,@(r0,r10)
L_0609B7BE:
    c.r[9] = ld32(0x0609B800u);  // 0609B7BE mov.l 0x0609B800,r9
    c.r[1] = ld32(c.r[9]);  // 0609B7C0 mov.l @r9,r1
    c.r[8] = (uint32_t)(int16_t)ld16(0x0609B7F8u);  // 0609B7C2 mov.w 0x0609B7F8,r8
    c.r[0] = c.r[1];  // 0609B7C4 mov r1,r0
    c.r[1] = ld32(c.r[0] + c.r[8]);  // 0609B7C6 mov.l @(r0,r8),r1
    c.r[0] = c.r[1];  // 0609B7C8 mov r1,r0
    c.t = c.r[0] == 0x2u;  // 0609B7CA cmp/eq #2,r0
    { const bool k = !c.t; c.r[0] = 0x1u; if (k) { goto L_0609B7E8; } }  // 0609B7CC bf/s 0x0609B7E8 ; mov #1,r0
    c.r[0] = ld32(0x0609B80Cu);  // 0609B7D0 mov.l 0x0609B80C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609B7D6u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B7D6u) return; }  // 0609B7D2 jsr @r0 ; mov #0,r4
    c.r[2] = c.r[0];  // 0609B7D6 mov r0,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0609B7D8 tst r2,r2
    if (!c.t) { goto L_0609B7E6; }  // 0609B7DA bf 0x0609B7E6
    c.r[1] = ld32(c.r[9]);  // 0609B7DC mov.l @r9,r1
    c.r[0] = c.r[1];  // 0609B7DE mov r1,r0
    st32(c.r[0] + c.r[8], c.r[2]);  // 0609B7E0 mov.l r2,@(r0,r8)
    c.r[0] = 0x0u; goto L_0609B7E8;  // 0609B7E2 bra 0x0609B7E8 ; mov #0,r0
L_0609B7E6:
    c.r[0] = 0x1u;  // 0609B7E6 mov #1,r0
L_0609B7E8:
    c.r[15] = c.r[14];  // 0609B7E8 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609B7EA lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609B7EC mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0609B7EE mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0609B7F0 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609B7F2 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609B7F4 rts ; mov.l @r15+,r8
}

void f_0609B810(SH2Context& c) {
    ran[2468] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0609B810 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0609B812 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0609B814 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0609B816 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0609B818 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0609B81A sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0609B81C mov r15,r14
    c.r[8] = c.r[4];  // 0609B81E mov r4,r8
    c.r[11] = ld32(0x0609B928u);  // 0609B820 mov.l 0x0609B928,r11
    c.r[2] = ld32(c.r[11]);  // 0609B822 mov.l @r11,r2
    c.r[10] = (uint32_t)(int16_t)ld16(0x0609B91Cu);  // 0609B824 mov.w 0x0609B91C,r10
    c.r[0] = c.r[2];  // 0609B826 mov r2,r0
    c.r[1] = ld32(c.r[0] + c.r[10]);  // 0609B828 mov.l @(r0,r10),r1
    c.r[0] = c.r[1];  // 0609B82A mov r1,r0
    c.t = c.r[0] == 0x1u;  // 0609B82C cmp/eq #1,r0
    { const bool k = !c.t; c.r[9] = 0x1u; if (k) { goto L_0609B884; } }  // 0609B82E bf/s 0x0609B884 ; mov #1,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609B91Eu);  // 0609B832 mov.w 0x0609B91E,r0
    c.r[1] = ld32(c.r[0] + c.r[2]);  // 0609B834 mov.l @(r0,r2),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609B836 tst r1,r1
    if (!c.t) { goto L_0609B86A; }  // 0609B838 bf 0x0609B86A
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609B920u);  // 0609B83A mov.w 0x0609B920,r0
    c.r[0] = ld32(c.r[0] + c.r[2]);  // 0609B83C mov.l @(r0,r2),r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0609B83E cmp/eq #-1,r0
    if (!c.t) { goto L_0609B86A; }  // 0609B840 bf 0x0609B86A
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609B922u);  // 0609B842 mov.w 0x0609B922,r0
    c.r[5] = ld32(c.r[0] + c.r[2]);  // 0609B844 mov.l @(r0,r2),r5
    c.r[0] = ld32(0x0609B92Cu);  // 0609B846 mov.l 0x0609B92C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609B84Cu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B84Cu) return; }  // 0609B848 jsr @r0 ; mov #0,r4
    c.r[2] = c.r[0];  // 0609B84C mov r0,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0609B84E tst r2,r2
    { const bool k = !c.t; c.r[0] = c.r[9]; if (k) { goto L_0609B90C; } }  // 0609B850 bf/s 0x0609B90C ; mov r9,r0
    c.r[1] = ld32(0x0609B930u);  // 0609B854 mov.l 0x0609B930,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609B85Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B85Au) return; }  // 0609B856 jsr @r1 ; nop
    c.r[1] = ld32(c.r[8]);  // 0609B85A mov.l @r8,r1
    c.r[1] += 1;  // 0609B85C add #1,r1
    st32(c.r[8], c.r[1]);  // 0609B85E mov.l r1,@r8
    c.r[2] = ld32(c.r[11]);  // 0609B860 mov.l @r11,r2
    c.r[1] = 0x4u;  // 0609B862 mov #4,r1
    c.r[0] = c.r[2];  // 0609B864 mov r2,r0
    st32(c.r[0] + c.r[10], c.r[1]); goto L_0609B882;  // 0609B866 bra 0x0609B882 ; mov.l r1,@(r0,r10)
L_0609B86A:
    c.r[1] = ld32(0x0609B928u);  // 0609B86A mov.l 0x0609B928,r1
    c.r[2] = ld32(c.r[1]);  // 0609B86C mov.l @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609B920u);  // 0609B86E mov.w 0x0609B920,r0
    c.r[1] = ld32(c.r[0] + c.r[2]);  // 0609B870 mov.l @(r0,r2),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0609B872 tst r1,r1
    if (!c.t) { goto L_0609B87C; }  // 0609B874 bf 0x0609B87C
    c.r[9] = 0x0u;  // 0609B876 mov #0,r9
    goto L_0609B882;  // 0609B878 bra 0x0609B882 ; nop
L_0609B87C:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609B91Cu);  // 0609B87C mov.w 0x0609B91C,r0
    c.r[1] = 0x2u;  // 0609B87E mov #2,r1
    st32(c.r[0] + c.r[2], c.r[1]);  // 0609B880 mov.l r1,@(r0,r2)
L_0609B882:
    c.r[11] = ld32(0x0609B928u);  // 0609B882 mov.l 0x0609B928,r11
L_0609B884:
    c.r[1] = ld32(c.r[11]);  // 0609B884 mov.l @r11,r1
    c.r[10] = (uint32_t)(int16_t)ld16(0x0609B91Cu);  // 0609B886 mov.w 0x0609B91C,r10
    c.r[0] = c.r[1];  // 0609B888 mov r1,r0
    c.r[2] = ld32(c.r[0] + c.r[10]);  // 0609B88A mov.l @(r0,r10),r2
    c.r[0] = c.r[2];  // 0609B88C mov r2,r0
    c.t = c.r[0] == 0x2u;  // 0609B88E cmp/eq #2,r0
    if (!c.t) { goto L_0609B8BC; }  // 0609B890 bf 0x0609B8BC
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609B920u);  // 0609B892 mov.w 0x0609B920,r0
    c.r[6] = ld32(c.r[0] + c.r[1]);  // 0609B894 mov.l @(r0,r1),r6
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609B91Eu);  // 0609B896 mov.w 0x0609B91E,r0
    c.r[5] = ld32(c.r[0] + c.r[1]);  // 0609B898 mov.l @(r0,r1),r5
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609B922u);  // 0609B89A mov.w 0x0609B922,r0
    c.r[4] = ld32(c.r[0] + c.r[1]);  // 0609B89C mov.l @(r0,r1),r4
    c.r[0] = ld32(0x0609B934u);  // 0609B89E mov.l 0x0609B934,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609B8A4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B8A4u) return; }  // 0609B8A0 jsr @r0 ; nop
    c.r[2] = c.r[0];  // 0609B8A4 mov r0,r2
    c.r[1] = ld32(c.r[8]);  // 0609B8A6 mov.l @r8,r1
    c.t = (c.r[2] & c.r[2]) == 0;  // 0609B8A8 tst r2,r2
    c.r[1] += 1;  // 0609B8AA add #1,r1
    { const bool k = !c.t; st32(c.r[8], c.r[1]); if (k) { goto L_0609B8BC; } }  // 0609B8AC bf/s 0x0609B8BC ; mov.l r1,@r8
    c.r[1] = ld32(c.r[11]);  // 0609B8B0 mov.l @r11,r1
    c.r[2] = 0x3u;  // 0609B8B2 mov #3,r2
    c.r[0] = c.r[1];  // 0609B8B4 mov r1,r0
    c.r[1] = ld32(0x0609B930u);  // 0609B8B6 mov.l 0x0609B930,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609B8BCu; st32(c.r[0] + c.r[10], c.r[2]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B8BCu) return; }  // 0609B8B8 jsr @r1 ; mov.l r2,@(r0,r10)
L_0609B8BC:
    c.r[1] = ld32(0x0609B928u);  // 0609B8BC mov.l 0x0609B928,r1
    c.r[1] = ld32(c.r[1]);  // 0609B8BE mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609B91Cu);  // 0609B8C0 mov.w 0x0609B91C,r0
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 0609B8C2 mov.l @(r0,r1),r0
    c.t = c.r[0] == 0x3u;  // 0609B8C4 cmp/eq #3,r0
    if (!c.t) { goto L_0609B8D6; }  // 0609B8C6 bf 0x0609B8D6
    c.r[4] = (uint32_t)(int16_t)ld16(0x0609B924u);  // 0609B8C8 mov.w 0x0609B924,r4
    c.r[0] = ld32(0x0609B938u);  // 0609B8CA mov.l 0x0609B938,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609B8D0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B8D0u) return; }  // 0609B8CC jsr @r0 ; nop
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609B8D0 tst r0,r0
    if (c.t) { goto L_0609B8D6; }  // 0609B8D2 bt 0x0609B8D6
    c.r[9] = 0x0u;  // 0609B8D4 mov #0,r9
L_0609B8D6:
    c.r[1] = ld32(0x0609B928u);  // 0609B8D6 mov.l 0x0609B928,r1
    c.r[1] = ld32(c.r[1]);  // 0609B8D8 mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609B91Cu);  // 0609B8DA mov.w 0x0609B91C,r0
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 0609B8DC mov.l @(r0,r1),r0
    c.t = c.r[0] == 0x4u;  // 0609B8DE cmp/eq #4,r0
    { const bool k = !c.t; c.r[0] = c.r[9]; if (k) { goto L_0609B8F2; } }  // 0609B8E0 bf/s 0x0609B8F2 ; mov r9,r0
    c.r[0] = ld32(0x0609B938u);  // 0609B8E4 mov.l 0x0609B938,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0609B8EAu; c.r[4] = 0x40u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B8EAu) return; }  // 0609B8E6 jsr @r0 ; mov #64,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 0609B8EA tst r0,r0
    if (c.t) { goto L_0609B8F0; }  // 0609B8EC bt 0x0609B8F0
    c.r[9] = 0x0u;  // 0609B8EE mov #0,r9
L_0609B8F0:
    c.r[0] = c.r[9];  // 0609B8F0 mov r9,r0
L_0609B8F2:
    c.t = c.r[0] == 0x1u;  // 0609B8F2 cmp/eq #1,r0
    if (c.t) { goto L_0609B90A; }  // 0609B8F4 bt 0x0609B90A
    c.r[1] = ld32(0x0609B93Cu);  // 0609B8F6 mov.l 0x0609B93C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0609B8FCu; c.r[4] = 0xFFFFFFF7u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0609B8FCu) return; }  // 0609B8F8 jsr @r1 ; mov #-9,r4
    c.r[1] = ld32(0x0609B928u);  // 0609B8FC mov.l 0x0609B928,r1
    c.r[2] = ld32(c.r[1]);  // 0609B8FE mov.l @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0609B91Cu);  // 0609B900 mov.w 0x0609B91C,r0
    c.r[1] = 0x0u;  // 0609B902 mov #0,r1
    st32(c.r[0] + c.r[2], c.r[1]);  // 0609B904 mov.l r1,@(r0,r2)
    c.r[0] = 0x0u; goto L_0609B90C;  // 0609B906 bra 0x0609B90C ; mov #0,r0
L_0609B90A:
    c.r[0] = c.r[9];  // 0609B90A mov r9,r0
L_0609B90C:
    c.r[15] = c.r[14];  // 0609B90C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0609B90E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0609B910 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0609B912 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0609B914 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0609B916 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0609B918 rts ; mov.l @r15+,r8
}

}  // namespace p_srwfin_installed
