#include "p_srwfin_installed_funcs.h"

namespace p_srwfin_installed {

void f_060804B8(SH2Context& c) {
    ran[1790] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060804B8 mov.l r14,@-r15
    c.r[1] = ld32(0x060804D8u);  // 060804BA mov.l 0x060804D8,r1
    c.r[1] = ld32(c.r[1]);  // 060804BC mov.l @r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060804BE tst r1,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_060804CA; } }  // 060804C0 bt/s 0x060804CA ; mov r15,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x060804D2u);  // 060804C4 mov.w 0x060804D2,r0
    c.r[15] = c.r[14]; goto L_060804CE;  // 060804C6 bra 0x060804CE ; mov r14,r15
L_060804CA:
    c.r[0] = (uint32_t)(int16_t)ld16(0x060804D4u);  // 060804CA mov.w 0x060804D4,r0
    c.r[15] = c.r[14];  // 060804CC mov r14,r15
L_060804CE:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060804CE rts ; mov.l @r15+,r14
}

void f_060804DC(SH2Context& c) {
    ran[1791] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060804DC mov.l r14,@-r15
    c.r[1] = ld32(0x0608054Cu);  // 060804DE mov.l 0x0608054C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060804E0 mov.b @r1,r1
    c.r[3] = c.r[1] & 0xFFu;  // 060804E2 extu.b r1,r3
    c.r[1] = ld32(0x06080550u);  // 060804E4 mov.l 0x06080550,r1
    c.r[0] = c.r[3];  // 060804E6 mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060804E8 mov.b @(r0,r1),r1
    c.r[2] = 0x7u;  // 060804EA mov #7,r2
    c.r[1] = c.r[1] & 0xFFu;  // 060804EC extu.b r1,r1
    c.r[1] -= 1;  // 060804EE add #-1,r1
    c.macl = c.r[1] * c.r[2];  // 060804F0 mul.l r2,r1
    c.r[1] = ld32(0x06080554u);  // 060804F2 mov.l 0x06080554,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060804F4 mov.b @(r0,r1),r1
    c.r[2] = c.macl;  // 060804F6 sts macl,r2
    c.r[1] = c.r[1] & 0xFFu;  // 060804F8 extu.b r1,r1
    c.r[2] += c.r[1];  // 060804FA add r1,r2
    c.r[1] = ld32(0x06080558u);  // 060804FC mov.l 0x06080558,r1
    c.r[1] = ld32(c.r[1]);  // 060804FE mov.l @r1,r1
    c.r[2] += c.r[2];  // 06080500 add r2,r2
    c.r[0] = c.r[1];  // 06080502 mov r1,r0
    c.r[1] += c.r[2];  // 06080504 add r2,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06080506 mov.b @(r0,r2),r3
    c.r[1] += 1;  // 06080508 add #1,r1
    c.r[0] = 0x7Fu;  // 0608050A mov #127,r0
    c.r[3] &= c.r[0];  // 0608050C and r0,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0608050E mov.b @r1,r2
    c.r[3] <<= 8;  // 06080510 shll8 r3
    c.r[2] = c.r[2] & 0xFFu;  // 06080512 extu.b r2,r2
    c.r[2] |= c.r[3];  // 06080514 or r3,r2
    c.r[1] = ld32(0x0608055Cu);  // 06080516 mov.l 0x0608055C,r1
    c.r[3] = ld32(c.r[1]);  // 06080518 mov.l @r1,r3
    c.r[1] = c.r[2];  // 0608051A mov r2,r1
    c.r[1] <<= 2;  // 0608051C shll2 r1
    c.r[1] += c.r[2];  // 0608051E add r2,r1
    c.r[1] <<= 2;  // 06080520 shll2 r1
    c.r[3] += c.r[1];  // 06080522 add r1,r3
    c.r[3] += 50;  // 06080524 add #50,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06080526 mov.b @r3,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06080528 extu.b r1,r1
    c.r[1] >>= 2;  // 0608052A shlr2 r1
    c.r[1] >>= 2;  // 0608052C shlr2 r1
    c.r[1] >>= 2;  // 0608052E shlr2 r1
    c.r[0] = c.r[1];  // 06080530 mov r1,r0
    c.t = c.r[0] == 0x3u;  // 06080532 cmp/eq #3,r0
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0608053E; } }  // 06080534 bf/s 0x0608053E ; mov r15,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x06080546u);  // 06080538 mov.w 0x06080546,r0
    c.r[15] = c.r[14]; goto L_06080542;  // 0608053A bra 0x06080542 ; mov r14,r15
L_0608053E:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06080548u);  // 0608053E mov.w 0x06080548,r0
    c.r[15] = c.r[14];  // 06080540 mov r14,r15
L_06080542:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06080542 rts ; mov.l @r15+,r14
}

void f_06080560(SH2Context& c) {
    ran[1792] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06080560 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06080562 mov r15,r14
    c.r[1] = ld32(0x0608057Cu);  // 06080564 mov.l 0x0608057C,r1
    c.r[2] = ld32(c.r[1]);  // 06080566 mov.l @r1,r2
    c.r[3] = ld32(0x06080580u);  // 06080568 mov.l 0x06080580,r3
    c.r[2] += 1;  // 0608056A add #1,r2
    st32(c.r[1], c.r[2]);  // 0608056C mov.l r2,@r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0608056E mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06080570 extu.b r1,r1
    st32(c.r[3], c.r[1]);  // 06080572 mov.l r1,@r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x0608057Au);  // 06080574 mov.w 0x0608057A,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06080576 rts ; mov.l @r15+,r14
}

void f_06080584(SH2Context& c) {
    ran[1793] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06080584 mov.l r14,@-r15
    c.r[1] = ld32(0x060805C0u);  // 06080586 mov.l 0x060805C0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06080588 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0608058A extu.b r1,r0
    c.r[1] = ld32(0x060805C4u);  // 0608058C mov.l 0x060805C4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0608058E mov.b @(r0,r1),r1
    c.r[2] = 0x7u;  // 06080590 mov #7,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06080592 extu.b r1,r1
    c.r[1] -= 1;  // 06080594 add #-1,r1
    c.macl = c.r[1] * c.r[2];  // 06080596 mul.l r2,r1
    c.r[1] = ld32(0x060805C8u);  // 06080598 mov.l 0x060805C8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0608059A mov.b @(r0,r1),r1
    c.r[2] = c.macl;  // 0608059C sts macl,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0608059E extu.b r1,r1
    c.r[2] += c.r[1];  // 060805A0 add r1,r2
    c.r[1] = ld32(0x060805CCu);  // 060805A2 mov.l 0x060805CC,r1
    c.r[1] = ld32(c.r[1] + 4);  // 060805A4 mov.l @(4,r1),r1
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[1];  // 060805A6 cmp/ge r1,r2
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_060805B2; } }  // 060805A8 bf/s 0x060805B2 ; mov r15,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x060805BAu);  // 060805AC mov.w 0x060805BA,r0
    c.r[15] = c.r[14]; goto L_060805B6;  // 060805AE bra 0x060805B6 ; mov r14,r15
L_060805B2:
    c.r[0] = (uint32_t)(int16_t)ld16(0x060805BCu);  // 060805B2 mov.w 0x060805BC,r0
    c.r[15] = c.r[14];  // 060805B4 mov r14,r15
L_060805B6:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060805B6 rts ; mov.l @r15+,r14
}

void f_060805D0(SH2Context& c) {
    ran[1794] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060805D0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060805D2 sts.l pr,@-r15
    c.r[1] = ld32(0x06080660u);  // 060805D4 mov.l 0x06080660,r1
    c.r[2] = ld32(c.r[1]);  // 060805D6 mov.l @r1,r2
    c.r[2] += 1;  // 060805D8 add #1,r2
    st32(c.r[1], c.r[2]);  // 060805DA mov.l r2,@r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060805DC mov.b @r2,r1
    c.r[2] = c.r[1] & 0xFFu;  // 060805DE extu.b r1,r2
    c.r[1] = 0x6u;  // 060805E0 mov #6,r1
    c.t = c.r[2] > c.r[1];  // 060805E2 cmp/hi r1,r2
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06080654; } }  // 060805E4 bt/s 0x06080654 ; mov r15,r14
    c.r[1] = c.r[2];  // 060805E8 mov r2,r1
    c.r[1] += c.r[1];  // 060805EA add r1,r1
    c.r[0] = 0x060805F8u;  // 060805EC mova 0x060805F8,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 060805EE mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 060805F0 add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x06080606u: goto L_06080606; case 0x0608060Cu: goto L_0608060C; case 0x06080612u: goto L_06080612; case 0x06080618u: goto L_06080618; case 0x0608061Eu: goto L_0608061E; case 0x0608064Eu: goto L_0608064E; case 0x06080624u: goto L_06080624; default: sh2_call(c, x); return; } }  // 060805F2 jmp @r0 ; nop
L_06080606:
    c.r[1] = ld32(0x06080664u);  // 06080606 mov.l 0x06080664,r1
    goto L_06080650;  // 06080608 bra 0x06080650 ; nop
L_0608060C:
    c.r[1] = ld32(0x06080668u);  // 0608060C mov.l 0x06080668,r1
    goto L_06080650;  // 0608060E bra 0x06080650 ; nop
L_06080612:
    c.r[1] = ld32(0x0608066Cu);  // 06080612 mov.l 0x0608066C,r1
    goto L_06080650;  // 06080614 bra 0x06080650 ; nop
L_06080618:
    c.r[1] = ld32(0x06080670u);  // 06080618 mov.l 0x06080670,r1
    goto L_06080650;  // 0608061A bra 0x06080650 ; nop
L_0608061E:
    c.r[1] = ld32(0x06080674u);  // 0608061E mov.l 0x06080674,r1
    goto L_06080650;  // 06080620 bra 0x06080650 ; nop
L_06080624:
    c.r[1] = ld32(0x06080678u);  // 06080624 mov.l 0x06080678,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06080626 mov.b @r1,r1
    c.r[3] = c.r[1] & 0xFFu;  // 06080628 extu.b r1,r3
    c.t = (c.r[3] & c.r[3]) == 0;  // 0608062A tst r3,r3
    { const bool k = c.t; c.r[3] -= 1; if (k) { goto L_06080654; } }  // 0608062C bt/s 0x06080654 ; add #-1,r3
    c.r[2] = ld32(0x0608067Cu);  // 06080630 mov.l 0x0608067C,r2
    c.r[1] = ld32(0x06080680u);  // 06080632 mov.l 0x06080680,r1
    c.r[1] = ld32(c.r[1]);  // 06080634 mov.l @r1,r1
    c.r[3] += c.r[3];  // 06080636 add r3,r3
    c.r[0] = c.r[1];  // 06080638 mov r1,r0
    c.r[1] += c.r[3];  // 0608063A add r3,r1
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0608063C mov.b @(r0,r3),r7
    c.r[1] += 1;  // 0608063E add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06080640 mov.b @r1,r1
    c.r[0] = 0x7Fu;  // 06080642 mov #127,r0
    c.r[7] &= c.r[0];  // 06080644 and r0,r7
    c.r[7] <<= 8;  // 06080646 shll8 r7
    c.r[1] = c.r[1] & 0xFFu;  // 06080648 extu.b r1,r1
    c.r[1] |= c.r[7];  // 0608064A or r7,r1
    st16(c.r[2], c.r[1]);  // 0608064C mov.w r1,@r2
L_0608064E:
    c.r[1] = ld32(0x06080684u);  // 0608064E mov.l 0x06080684,r1
L_06080650:
    { const uint32_t x = c.r[1]; c.pr = 0x06080654u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06080654u) return; }  // 06080650 jsr @r1 ; nop
L_06080654:
    c.r[15] = c.r[14];  // 06080654 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06080656 lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x0608065Eu);  // 06080658 mov.w 0x0608065E,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0608065A rts ; mov.l @r15+,r14
}

void f_06080688(SH2Context& c) {
    ran[1795] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06080688 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608068A mov.l r14,@-r15
    c.r[1] = ld32(0x06080704u);  // 0608068C mov.l 0x06080704,r1
    c.r[2] = ld32(c.r[1]);  // 0608068E mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06080700u);  // 06080690 mov.w 0x06080700,r1
    c.r[0] = c.r[2];  // 06080692 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06080694 mov.b @(r0,r1),r1
    c.r[7] = 0x0u;  // 06080696 mov #0,r7
    c.r[3] = c.r[1] & 0xFFu;  // 06080698 extu.b r1,r3
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[3];  // 0608069A cmp/ge r3,r7
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_060806D0; } }  // 0608069C bt/s 0x060806D0 ; mov r15,r14
    c.r[6] = c.r[2];  // 060806A0 mov r2,r6
    c.r[1] = ld32(0x06080708u);  // 060806A2 mov.l 0x06080708,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060806A4 mov.b @r1,r1
    c.r[5] = c.r[3];  // 060806A6 mov r3,r5
    c.r[3] = c.r[6];  // 060806A8 mov r6,r3
    c.r[2] = 0x0u;  // 060806AA mov #0,r2
    c.r[4] = c.r[1] & 0xFFu;  // 060806AC extu.b r1,r4
L_060806AE:
    c.r[0] = c.r[2];  // 060806AE mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 060806B0 mov.b @(r0,r6),r1
    c.r[8] = 0x7Fu;  // 060806B2 mov #127,r8
    c.r[8] &= c.r[1];  // 060806B4 and r1,r8
    c.r[1] = c.r[3];  // 060806B6 mov r3,r1
    c.r[1] += 1;  // 060806B8 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060806BA mov.b @r1,r1
    c.r[8] <<= 8;  // 060806BC shll8 r8
    c.r[1] = c.r[1] & 0xFFu;  // 060806BE extu.b r1,r1
    c.r[1] |= c.r[8];  // 060806C0 or r8,r1
    c.t = c.r[1] == c.r[4];  // 060806C2 cmp/eq r4,r1
    { const bool k = c.t; c.r[3] += 2; if (k) { goto L_060806D0; } }  // 060806C4 bt/s 0x060806D0 ; add #2,r3
    c.r[7] += 1;  // 060806C8 add #1,r7
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[5];  // 060806CA cmp/ge r5,r7
    { const bool k = !c.t; c.r[2] += 2; if (k) { SH2_POLL(c); goto L_060806AE; } }  // 060806CC bf/s 0x060806AE ; add #2,r2
L_060806D0:
    c.r[1] = ld32(0x0608070Cu);  // 060806D0 mov.l 0x0608070C,r1
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[7] * (int32_t)c.r[1]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060806D2 dmuls.l r1,r7
    c.r[2] = ld32(0x06080710u);  // 060806D4 mov.l 0x06080710,r2
    c.r[3] = c.mach;  // 060806D6 sts mach,r3
    c.r[3] += c.r[7];  // 060806D8 add r7,r3
    c.t = c.r[3] & 1; c.r[3] = (uint32_t)((int32_t)c.r[3] >> 1);  // 060806DA shar r3
    c.t = c.r[3] & 1; c.r[3] = (uint32_t)((int32_t)c.r[3] >> 1);  // 060806DC shar r3
    c.r[1] = c.r[7];  // 060806DE mov r7,r1
    c.t = c.r[1] >> 31; c.r[1] <<= 1;  // 060806E0 shll r1
    { uint32_t a = c.r[1], b = c.r[1], t = c.t; c.r[1] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060806E2 subc r1,r1
    c.r[3] -= c.r[1];  // 060806E4 sub r1,r3
    c.r[1] = c.r[3];  // 060806E6 mov r3,r1
    c.r[1] += 1;  // 060806E8 add #1,r1
    st8(c.r[2], c.r[1]);  // 060806EA mov.b r1,@r2
    c.r[1] = 0x7u;  // 060806EC mov #7,r1
    c.macl = c.r[3] * c.r[1];  // 060806EE mul.l r1,r3
    c.r[15] = c.r[14];  // 060806F0 mov r14,r15
    c.r[2] = ld32(0x06080714u);  // 060806F2 mov.l 0x06080714,r2
    c.r[1] = c.macl;  // 060806F4 sts macl,r1
    c.r[7] -= c.r[1];  // 060806F6 sub r1,r7
    st8(c.r[2], c.r[7]);  // 060806F8 mov.b r7,@r2
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060806FA mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060806FC rts ; mov.l @r15+,r8
}

void f_06080718(SH2Context& c) {
    ran[1796] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06080718 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608071A mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0608071C mov r15,r14
    c.r[7] = 0x0u;  // 0608071E mov #0,r7
    c.r[4] = 0xFu;  // 06080720 mov #15,r4
    c.r[1] = ld32(0x06080784u);  // 06080722 mov.l 0x06080784,r1
    c.r[6] = ld32(c.r[1]);  // 06080724 mov.l @r1,r6
    c.r[2] = 0x0u;  // 06080726 mov #0,r2
    c.r[1] = ld32(0x06080788u);  // 06080728 mov.l 0x06080788,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0608072A mov.b @r1,r1
    c.r[3] = c.r[6];  // 0608072C mov r6,r3
    c.r[5] = c.r[1] & 0xFFu;  // 0608072E extu.b r1,r5
L_06080730:
    c.r[0] = c.r[2];  // 06080730 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 06080732 mov.b @(r0,r6),r1
    c.r[8] = 0x7Fu;  // 06080734 mov #127,r8
    c.r[8] &= c.r[1];  // 06080736 and r1,r8
    c.r[1] = c.r[3];  // 06080738 mov r3,r1
    c.r[1] += 1;  // 0608073A add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0608073C mov.b @r1,r1
    c.r[8] <<= 8;  // 0608073E shll8 r8
    c.r[1] = c.r[1] & 0xFFu;  // 06080740 extu.b r1,r1
    c.r[1] |= c.r[8];  // 06080742 or r8,r1
    c.t = c.r[1] == c.r[5];  // 06080744 cmp/eq r5,r1
    { const bool k = c.t; c.r[3] += 2; if (k) { goto L_06080752; } }  // 06080746 bt/s 0x06080752 ; add #2,r3
    c.r[7] += 1;  // 0608074A add #1,r7
    c.t = (int32_t)c.r[7] > (int32_t)c.r[4];  // 0608074C cmp/gt r4,r7
    { const bool k = !c.t; c.r[2] += 2; if (k) { SH2_POLL(c); goto L_06080730; } }  // 0608074E bf/s 0x06080730 ; add #2,r2
L_06080752:
    c.r[1] = ld32(0x0608078Cu);  // 06080752 mov.l 0x0608078C,r1
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[7] * (int32_t)c.r[1]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 06080754 dmuls.l r1,r7
    c.r[2] = ld32(0x06080790u);  // 06080756 mov.l 0x06080790,r2
    c.r[3] = c.mach;  // 06080758 sts mach,r3
    c.r[3] += c.r[7];  // 0608075A add r7,r3
    c.t = c.r[3] & 1; c.r[3] = (uint32_t)((int32_t)c.r[3] >> 1);  // 0608075C shar r3
    c.t = c.r[3] & 1; c.r[3] = (uint32_t)((int32_t)c.r[3] >> 1);  // 0608075E shar r3
    c.r[1] = c.r[7];  // 06080760 mov r7,r1
    c.t = c.r[1] >> 31; c.r[1] <<= 1;  // 06080762 shll r1
    { uint32_t a = c.r[1], b = c.r[1], t = c.t; c.r[1] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 06080764 subc r1,r1
    c.r[3] -= c.r[1];  // 06080766 sub r1,r3
    c.r[1] = c.r[3];  // 06080768 mov r3,r1
    c.r[1] += 1;  // 0608076A add #1,r1
    st8(c.r[2], c.r[1]);  // 0608076C mov.b r1,@r2
    c.r[1] = 0x7u;  // 0608076E mov #7,r1
    c.macl = c.r[3] * c.r[1];  // 06080770 mul.l r1,r3
    c.r[15] = c.r[14];  // 06080772 mov r14,r15
    c.r[2] = ld32(0x06080794u);  // 06080774 mov.l 0x06080794,r2
    c.r[1] = c.macl;  // 06080776 sts macl,r1
    c.r[7] -= c.r[1];  // 06080778 sub r1,r7
    st8(c.r[2], c.r[7]);  // 0608077A mov.b r7,@r2
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608077C mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0608077E rts ; mov.l @r15+,r8
}

void f_06080798(SH2Context& c) {
    ran[1797] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06080798 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0608079A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608079C mov.l r14,@-r15
    c.r[1] = ld32(0x0608082Cu);  // 0608079E mov.l 0x0608082C,r1
    c.r[2] = ld32(c.r[1]);  // 060807A0 mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06080828u);  // 060807A2 mov.w 0x06080828,r1
    c.r[0] = c.r[2];  // 060807A4 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060807A6 mov.b @(r0,r1),r1
    c.r[7] = 0x0u;  // 060807A8 mov #0,r7
    c.r[3] = c.r[1] & 0xFFu;  // 060807AA extu.b r1,r3
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[3];  // 060807AC cmp/ge r3,r7
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_060807FA; } }  // 060807AE bt/s 0x060807FA ; mov r15,r14
    c.r[5] = c.r[2];  // 060807B2 mov r2,r5
    c.r[1] = ld32(0x06080830u);  // 060807B4 mov.l 0x06080830,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060807B6 mov.b @r1,r1
    c.r[4] = ld32(0x06080834u);  // 060807B8 mov.l 0x06080834,r4
    c.r[8] = c.r[3];  // 060807BA mov r3,r8
    c.r[6] = c.r[5];  // 060807BC mov r5,r6
    c.r[3] = 0x0u;  // 060807BE mov #0,r3
    c.r[9] = c.r[1] & 0xFFu;  // 060807C0 extu.b r1,r9
L_060807C2:
    c.r[0] = c.r[3];  // 060807C2 mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 060807C4 mov.b @(r0,r5),r1
    c.r[2] = 0x7Fu;  // 060807C6 mov #127,r2
    c.r[2] &= c.r[1];  // 060807C8 and r1,r2
    c.r[1] = c.r[6];  // 060807CA mov r6,r1
    c.r[1] += 1;  // 060807CC add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060807CE mov.b @r1,r1
    c.r[2] <<= 8;  // 060807D0 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 060807D2 extu.b r1,r1
    c.r[1] |= c.r[2];  // 060807D4 or r2,r1
    c.t = c.r[1] == c.r[9];  // 060807D6 cmp/eq r9,r1
    { const bool k = !c.t; c.r[0] = c.r[7]; if (k) { goto L_060807F0; } }  // 060807D8 bf/s 0x060807F0 ; mov r7,r0
    c.r[1] = ld32(0x06080838u);  // 060807DC mov.l 0x06080838,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060807DE mov.b @r1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[4]);  // 060807E0 mov.b @(r0,r4),r2
    c.r[1] = c.r[1] & 0xFFu;  // 060807E2 extu.b r1,r1
    c.r[0] = c.r[1];  // 060807E4 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[4]);  // 060807E6 mov.b @(r0,r4),r1
    c.r[2] = c.r[2] & 0xFFu;  // 060807E8 extu.b r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 060807EA extu.b r1,r1
    c.t = c.r[2] == c.r[1];  // 060807EC cmp/eq r1,r2
    if (c.t) { goto L_060807FA; }  // 060807EE bt 0x060807FA
L_060807F0:
    c.r[6] += 2;  // 060807F0 add #2,r6
    c.r[7] += 1;  // 060807F2 add #1,r7
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[8];  // 060807F4 cmp/ge r8,r7
    { const bool k = !c.t; c.r[3] += 2; if (k) { SH2_POLL(c); goto L_060807C2; } }  // 060807F6 bf/s 0x060807C2 ; add #2,r3
L_060807FA:
    c.r[1] = ld32(0x0608083Cu);  // 060807FA mov.l 0x0608083C,r1
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[7] * (int32_t)c.r[1]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060807FC dmuls.l r1,r7
    c.r[2] = ld32(0x06080840u);  // 060807FE mov.l 0x06080840,r2
    c.r[3] = c.mach;  // 06080800 sts mach,r3
    c.t = c.r[3] & 1; c.r[3] = (uint32_t)((int32_t)c.r[3] >> 1);  // 06080802 shar r3
    c.r[1] = c.r[7];  // 06080804 mov r7,r1
    c.t = c.r[1] >> 31; c.r[1] <<= 1;  // 06080806 shll r1
    { uint32_t a = c.r[1], b = c.r[1], t = c.t; c.r[1] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 06080808 subc r1,r1
    c.r[3] -= c.r[1];  // 0608080A sub r1,r3
    c.r[1] = c.r[3];  // 0608080C mov r3,r1
    c.r[1] += 1;  // 0608080E add #1,r1
    st8(c.r[2], c.r[1]);  // 06080810 mov.b r1,@r2
    c.r[1] = 0x9u;  // 06080812 mov #9,r1
    c.macl = c.r[3] * c.r[1];  // 06080814 mul.l r1,r3
    c.r[15] = c.r[14];  // 06080816 mov r14,r15
    c.r[2] = ld32(0x06080844u);  // 06080818 mov.l 0x06080844,r2
    c.r[1] = c.macl;  // 0608081A sts macl,r1
    c.r[7] -= c.r[1];  // 0608081C sub r1,r7
    st8(c.r[2], c.r[7]);  // 0608081E mov.b r7,@r2
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06080820 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06080822 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06080824 rts ; mov.l @r15+,r8
}

void f_06080848(SH2Context& c) {
    ran[1798] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06080848 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608084A mov.l r14,@-r15
    c.r[1] = ld32(0x060808C8u);  // 0608084C mov.l 0x060808C8,r1
    c.r[3] = ld32(c.r[1]);  // 0608084E mov.l @r1,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x060808C4u);  // 06080850 mov.w 0x060808C4,r1
    c.r[0] = c.r[3];  // 06080852 mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06080854 mov.b @(r0,r1),r1
    c.r[2] = 0x0u;  // 06080856 mov #0,r2
    c.r[7] = c.r[1] & 0xFFu;  // 06080858 extu.b r1,r7
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[7];  // 0608085A cmp/ge r7,r2
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06080890; } }  // 0608085C bt/s 0x06080890 ; mov r15,r14
    c.r[6] = c.r[3];  // 06080860 mov r3,r6
    c.r[1] = ld32(0x060808CCu);  // 06080862 mov.l 0x060808CC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06080864 mov.b @r1,r1
    c.r[5] = c.r[7];  // 06080866 mov r7,r5
    c.r[7] = c.r[6];  // 06080868 mov r6,r7
    c.r[3] = 0x0u;  // 0608086A mov #0,r3
    c.r[4] = c.r[1] & 0xFFu;  // 0608086C extu.b r1,r4
L_0608086E:
    c.r[0] = c.r[3];  // 0608086E mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 06080870 mov.b @(r0,r6),r1
    c.r[8] = 0x7Fu;  // 06080872 mov #127,r8
    c.r[8] &= c.r[1];  // 06080874 and r1,r8
    c.r[1] = c.r[7];  // 06080876 mov r7,r1
    c.r[1] += 1;  // 06080878 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0608087A mov.b @r1,r1
    c.r[8] <<= 8;  // 0608087C shll8 r8
    c.r[1] = c.r[1] & 0xFFu;  // 0608087E extu.b r1,r1
    c.r[1] |= c.r[8];  // 06080880 or r8,r1
    c.t = c.r[1] == c.r[4];  // 06080882 cmp/eq r4,r1
    if (c.t) { goto L_06080890; }  // 06080884 bt 0x06080890
    c.r[7] += 2;  // 06080886 add #2,r7
    c.r[2] += 1;  // 06080888 add #1,r2
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[5];  // 0608088A cmp/ge r5,r2
    { const bool k = !c.t; c.r[3] += 2; if (k) { SH2_POLL(c); goto L_0608086E; } }  // 0608088C bf/s 0x0608086E ; add #2,r3
L_06080890:
    c.r[3] = ld32(0x060808D0u);  // 06080890 mov.l 0x060808D0,r3
    c.t = (int32_t)c.r[2] >= 0;  // 06080892 cmp/pz r2
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_0608089A; } }  // 06080894 bt/s 0x0608089A ; mov r2,r1
    c.r[1] += 7;  // 06080898 add #7,r1
L_0608089A:
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0608089A shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0608089C shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0608089E shar r1
    c.r[1] += 1;  // 060808A0 add #1,r1
    st8(c.r[3], c.r[1]);  // 060808A2 mov.b r1,@r3
    c.r[3] = ld32(0x060808D4u);  // 060808A4 mov.l 0x060808D4,r3
    c.t = (int32_t)c.r[2] >= 0;  // 060808A6 cmp/pz r2
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_060808AE; } }  // 060808A8 bt/s 0x060808AE ; mov r2,r1
    c.r[1] += 7;  // 060808AC add #7,r1
L_060808AE:
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 060808AE shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 060808B0 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 060808B2 shar r1
    c.r[1] <<= 2;  // 060808B4 shll2 r1
    c.r[1] += c.r[1];  // 060808B6 add r1,r1
    c.r[2] -= c.r[1];  // 060808B8 sub r1,r2
    st8(c.r[3], c.r[2]);  // 060808BA mov.b r2,@r3
    c.r[15] = c.r[14];  // 060808BC mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060808BE mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060808C0 rts ; mov.l @r15+,r8
}

void f_060808D8(SH2Context& c) {
    ran[1799] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060808D8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060808DA mov.l r14,@-r15
    c.r[1] = ld32(0x06080950u);  // 060808DC mov.l 0x06080950,r1
    c.r[2] = ld32(c.r[1]);  // 060808DE mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0608094Cu);  // 060808E0 mov.w 0x0608094C,r1
    c.r[0] = c.r[2];  // 060808E2 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060808E4 mov.b @(r0,r1),r1
    c.r[7] = 0x0u;  // 060808E6 mov #0,r7
    c.r[3] = c.r[1] & 0xFFu;  // 060808E8 extu.b r1,r3
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[3];  // 060808EA cmp/ge r3,r7
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06080920; } }  // 060808EC bt/s 0x06080920 ; mov r15,r14
    c.r[6] = c.r[2];  // 060808F0 mov r2,r6
    c.r[1] = ld32(0x06080954u);  // 060808F2 mov.l 0x06080954,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060808F4 mov.b @r1,r1
    c.r[5] = c.r[3];  // 060808F6 mov r3,r5
    c.r[3] = c.r[6];  // 060808F8 mov r6,r3
    c.r[2] = 0x0u;  // 060808FA mov #0,r2
    c.r[4] = c.r[1] & 0xFFu;  // 060808FC extu.b r1,r4
L_060808FE:
    c.r[0] = c.r[2];  // 060808FE mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 06080900 mov.b @(r0,r6),r1
    c.r[8] = 0x7Fu;  // 06080902 mov #127,r8
    c.r[8] &= c.r[1];  // 06080904 and r1,r8
    c.r[1] = c.r[3];  // 06080906 mov r3,r1
    c.r[1] += 1;  // 06080908 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0608090A mov.b @r1,r1
    c.r[8] <<= 8;  // 0608090C shll8 r8
    c.r[1] = c.r[1] & 0xFFu;  // 0608090E extu.b r1,r1
    c.r[1] |= c.r[8];  // 06080910 or r8,r1
    c.t = c.r[1] == c.r[4];  // 06080912 cmp/eq r4,r1
    { const bool k = c.t; c.r[3] += 2; if (k) { goto L_06080920; } }  // 06080914 bt/s 0x06080920 ; add #2,r3
    c.r[7] += 1;  // 06080918 add #1,r7
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[5];  // 0608091A cmp/ge r5,r7
    { const bool k = !c.t; c.r[2] += 2; if (k) { SH2_POLL(c); goto L_060808FE; } }  // 0608091C bf/s 0x060808FE ; add #2,r2
L_06080920:
    c.r[1] = ld32(0x06080958u);  // 06080920 mov.l 0x06080958,r1
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[7] * (int32_t)c.r[1]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 06080922 dmuls.l r1,r7
    c.r[2] = ld32(0x0608095Cu);  // 06080924 mov.l 0x0608095C,r2
    c.r[3] = c.mach;  // 06080926 sts mach,r3
    c.t = c.r[3] & 1; c.r[3] = (uint32_t)((int32_t)c.r[3] >> 1);  // 06080928 shar r3
    c.r[1] = c.r[7];  // 0608092A mov r7,r1
    c.t = c.r[1] >> 31; c.r[1] <<= 1;  // 0608092C shll r1
    { uint32_t a = c.r[1], b = c.r[1], t = c.t; c.r[1] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 0608092E subc r1,r1
    c.r[3] -= c.r[1];  // 06080930 sub r1,r3
    c.r[1] = c.r[3];  // 06080932 mov r3,r1
    c.r[1] += 1;  // 06080934 add #1,r1
    st8(c.r[2], c.r[1]);  // 06080936 mov.b r1,@r2
    c.r[1] = 0x9u;  // 06080938 mov #9,r1
    c.macl = c.r[3] * c.r[1];  // 0608093A mul.l r1,r3
    c.r[15] = c.r[14];  // 0608093C mov r14,r15
    c.r[2] = ld32(0x06080960u);  // 0608093E mov.l 0x06080960,r2
    c.r[1] = c.macl;  // 06080940 sts macl,r1
    c.r[7] -= c.r[1];  // 06080942 sub r1,r7
    st8(c.r[2], c.r[7]);  // 06080944 mov.b r7,@r2
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06080946 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06080948 rts ; mov.l @r15+,r8
}

void f_06080964(SH2Context& c) {
    ran[1800] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06080964 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06080966 mov.l r14,@-r15
    c.r[1] = ld32(0x060809E0u);  // 06080968 mov.l 0x060809E0,r1
    c.r[2] = ld32(c.r[1]);  // 0608096A mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x060809DCu);  // 0608096C mov.w 0x060809DC,r1
    c.r[0] = c.r[2];  // 0608096E mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06080970 mov.b @(r0,r1),r1
    c.r[7] = 0x0u;  // 06080972 mov #0,r7
    c.r[3] = c.r[1] & 0xFFu;  // 06080974 extu.b r1,r3
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[3];  // 06080976 cmp/ge r3,r7
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_060809AC; } }  // 06080978 bt/s 0x060809AC ; mov r15,r14
    c.r[6] = c.r[2];  // 0608097C mov r2,r6
    c.r[1] = ld32(0x060809E4u);  // 0608097E mov.l 0x060809E4,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06080980 mov.w @r1,r1
    c.r[5] = c.r[3];  // 06080982 mov r3,r5
    c.r[3] = c.r[6];  // 06080984 mov r6,r3
    c.r[2] = 0x0u;  // 06080986 mov #0,r2
    c.r[4] = c.r[1] & 0xFFFFu;  // 06080988 extu.w r1,r4
L_0608098A:
    c.r[0] = c.r[2];  // 0608098A mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 0608098C mov.b @(r0,r6),r1
    c.r[8] = 0x7Fu;  // 0608098E mov #127,r8
    c.r[8] &= c.r[1];  // 06080990 and r1,r8
    c.r[1] = c.r[3];  // 06080992 mov r3,r1
    c.r[1] += 1;  // 06080994 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06080996 mov.b @r1,r1
    c.r[8] <<= 8;  // 06080998 shll8 r8
    c.r[1] = c.r[1] & 0xFFu;  // 0608099A extu.b r1,r1
    c.r[1] |= c.r[8];  // 0608099C or r8,r1
    c.t = c.r[1] == c.r[4];  // 0608099E cmp/eq r4,r1
    { const bool k = c.t; c.r[3] += 2; if (k) { goto L_060809AC; } }  // 060809A0 bt/s 0x060809AC ; add #2,r3
    c.r[7] += 1;  // 060809A4 add #1,r7
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[5];  // 060809A6 cmp/ge r5,r7
    { const bool k = !c.t; c.r[2] += 2; if (k) { SH2_POLL(c); goto L_0608098A; } }  // 060809A8 bf/s 0x0608098A ; add #2,r2
L_060809AC:
    c.r[1] = ld32(0x060809E8u);  // 060809AC mov.l 0x060809E8,r1
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[7] * (int32_t)c.r[1]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060809AE dmuls.l r1,r7
    c.r[2] = ld32(0x060809ECu);  // 060809B0 mov.l 0x060809EC,r2
    c.r[3] = c.mach;  // 060809B2 sts mach,r3
    c.r[3] += c.r[7];  // 060809B4 add r7,r3
    c.t = c.r[3] & 1; c.r[3] = (uint32_t)((int32_t)c.r[3] >> 1);  // 060809B6 shar r3
    c.t = c.r[3] & 1; c.r[3] = (uint32_t)((int32_t)c.r[3] >> 1);  // 060809B8 shar r3
    c.r[1] = c.r[7];  // 060809BA mov r7,r1
    c.t = c.r[1] >> 31; c.r[1] <<= 1;  // 060809BC shll r1
    { uint32_t a = c.r[1], b = c.r[1], t = c.t; c.r[1] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060809BE subc r1,r1
    c.r[3] -= c.r[1];  // 060809C0 sub r1,r3
    c.r[1] = c.r[3];  // 060809C2 mov r3,r1
    c.r[1] += 1;  // 060809C4 add #1,r1
    st8(c.r[2], c.r[1]);  // 060809C6 mov.b r1,@r2
    c.r[1] = 0x7u;  // 060809C8 mov #7,r1
    c.macl = c.r[3] * c.r[1];  // 060809CA mul.l r1,r3
    c.r[15] = c.r[14];  // 060809CC mov r14,r15
    c.r[2] = ld32(0x060809F0u);  // 060809CE mov.l 0x060809F0,r2
    c.r[1] = c.macl;  // 060809D0 sts macl,r1
    c.r[7] -= c.r[1];  // 060809D2 sub r1,r7
    st8(c.r[2], c.r[7]);  // 060809D4 mov.b r7,@r2
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060809D6 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060809D8 rts ; mov.l @r15+,r8
}

void f_060809F4(SH2Context& c) {
    ran[1801] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060809F4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060809F6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060809F8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060809FA mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060809FC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060809FE sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06080A00 mov r15,r14
    c.r[1] = ld32(0x06080B30u);  // 06080A02 mov.l 0x06080B30,r1
    c.r[2] = ld32(c.r[1]);  // 06080A04 mov.l @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06080B26u);  // 06080A06 mov.w 0x06080B26,r0
    c.r[8] = 0x0u;  // 06080A08 mov #0,r8
    c.r[10] = ld32(0x06080B34u);  // 06080A0A mov.l 0x06080B34,r10
    c.r[11] = ld32(0x06080B38u);  // 06080A0C mov.l 0x06080B38,r11
    c.r[9] = 0x0u;  // 06080A0E mov #0,r9
    c.r[1] = 0x0u;  // 06080A10 mov #0,r1
    st8(c.r[0] + c.r[2], c.r[1]);  // 06080A12 mov.b r1,@(r0,r2)
L_06080A14:
    c.r[0] = ld32(c.r[10]);  // 06080A14 mov.l @r10,r0
    c.r[2] = c.r[9];  // 06080A16 mov r9,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[9]);  // 06080A18 mov.w @(r0,r9),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06080A1A extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06080A1C tst r1,r1
    { const bool k = c.t; c.r[2] += c.r[0]; if (k) { goto L_06080A8C; } }  // 06080A1E bt/s 0x06080A8C ; add r0,r2
    c.r[2] += 2;  // 06080A22 add #2,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06080A24 mov.b @r2,r2
    c.r[1] = ld32(0x06080B3Cu);  // 06080A26 mov.l 0x06080B3C,r1
    c.r[1] = ld32(c.r[1]);  // 06080A28 mov.l @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 06080A2A extu.b r2,r2
    c.r[1] += 8;  // 06080A2C add #8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06080A2E mov.b @r1,r1
    c.r[2] >>= 2;  // 06080A30 shlr2 r2
    c.r[2] >>= 2;  // 06080A32 shlr2 r2
    c.r[2] >>= 2;  // 06080A34 shlr2 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06080A36 extu.b r1,r1
    c.r[1] >>= 2;  // 06080A38 shlr2 r1
    c.r[1] >>= 2;  // 06080A3A shlr2 r1
    c.r[1] >>= 2;  // 06080A3C shlr2 r1
    c.t = c.r[2] == c.r[1];  // 06080A3E cmp/eq r1,r2
    { const bool k = !c.t; c.r[5] = c.r[8] & 0xFFu; if (k) { goto L_06080A8C; } }  // 06080A40 bf/s 0x06080A8C ; extu.b r8,r5
    c.r[1] = ld32(0x06080B40u);  // 06080A44 mov.l 0x06080B40,r1
    c.r[6] = (uint32_t)(int16_t)ld16(0x06080B28u);  // 06080A46 mov.w 0x06080B28,r6
    { const uint32_t x = c.r[1]; c.pr = 0x06080A4Cu; c.r[4] = ld32(c.r[11]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06080A4Cu) return; }  // 06080A48 jsr @r1 ; mov.l @r11,r4
    c.r[7] = ld32(c.r[10]);  // 06080A4C mov.l @r10,r7
    c.r[0] = (uint32_t)(int16_t)ld16(0x06080B2Au);  // 06080A4E mov.w 0x06080B2A,r0
    c.r[2] = ld32(c.r[11]);  // 06080A50 mov.l @r11,r2
    c.r[7] += c.r[9];  // 06080A52 add r9,r7
    c.r[3] = c.r[7];  // 06080A54 mov r7,r3
    c.r[1] = c.r[2];  // 06080A56 mov r2,r1
    c.r[1] += 26;  // 06080A58 add #26,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06080A5A mov.w @r1,r1
    c.r[3] += 22;  // 06080A5C add #22,r3
    st16(c.r[3], c.r[1]);  // 06080A5E mov.w r1,@r3
    c.r[1] = c.r[2];  // 06080A60 mov r2,r1
    c.r[1] += 28;  // 06080A62 add #28,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06080A64 mov.w @r1,r1
    c.r[7] += 24;  // 06080A66 add #24,r7
    st16(c.r[7], c.r[1]);  // 06080A68 mov.w r1,@r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06080A6A mov.b @(r0,r2),r1
    c.r[0] = c.r[1];  // 06080A6C mov r1,r0
    c.r[0] >>= 2;  // 06080A6E shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06080A70 shlr r0
    c.r[0] &= 0x7u;  // 06080A72 and #7,r0
    c.r[2] = 0x3u;  // 06080A74 mov #3,r2
    c.t = (int32_t)c.r[0] > (int32_t)c.r[2];  // 06080A76 cmp/gt r2,r0
    if (c.t) { goto L_06080A8C; }  // 06080A78 bt 0x06080A8C
    c.r[3] = 0x0u;  // 06080A7A mov #0,r3
L_06080A7C:
    c.r[1] = ld32(c.r[10]);  // 06080A7C mov.l @r10,r1
    c.r[1] += c.r[9];  // 06080A7E add r9,r1
    c.r[1] += c.r[0];  // 06080A80 add r0,r1
    c.r[1] += 17;  // 06080A82 add #17,r1
    c.r[0] += 1;  // 06080A84 add #1,r0
    c.t = (int32_t)c.r[0] > (int32_t)c.r[2];  // 06080A86 cmp/gt r2,r0
    { const bool k = !c.t; st8(c.r[1], c.r[3]); if (k) { SH2_POLL(c); goto L_06080A7C; } }  // 06080A88 bf/s 0x06080A7C ; mov.b r3,@r1
L_06080A8C:
    c.r[8] += 1;  // 06080A8C add #1,r8
    c.r[1] = 0x7Fu;  // 06080A8E mov #127,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 06080A90 cmp/gt r1,r8
    { const bool k = !c.t; c.r[9] += 30; if (k) { SH2_POLL(c); goto L_06080A14; } }  // 06080A92 bf/s 0x06080A14 ; add #30,r9
    c.r[1] = ld32(0x06080B30u);  // 06080A96 mov.l 0x06080B30,r1
    c.r[2] = ld32(c.r[1]);  // 06080A98 mov.l @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06080B26u);  // 06080A9A mov.w 0x06080B26,r0
    c.r[8] = 0x0u;  // 06080A9C mov #0,r8
    c.r[11] = ld32(0x06080B44u);  // 06080A9E mov.l 0x06080B44,r11
    c.r[10] = ld32(0x06080B48u);  // 06080AA0 mov.l 0x06080B48,r10
    c.r[9] = 0x0u;  // 06080AA2 mov #0,r9
    c.r[1] = 0x0u;  // 06080AA4 mov #0,r1
    st8(c.r[0] + c.r[2], c.r[1]);  // 06080AA6 mov.b r1,@(r0,r2)
L_06080AA8:
    c.r[0] = ld32(c.r[11]);  // 06080AA8 mov.l @r11,r0
    c.r[2] = c.r[9];  // 06080AAA mov r9,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[9]);  // 06080AAC mov.w @(r0,r9),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06080AAE extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06080AB0 tst r1,r1
    { const bool k = c.t; c.r[2] += c.r[0]; if (k) { goto L_06080AEC; } }  // 06080AB2 bt/s 0x06080AEC ; add r0,r2
    c.r[2] += 3;  // 06080AB6 add #3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06080AB8 mov.b @r2,r1
    c.r[0] = c.r[1];  // 06080ABA mov r1,r0
    c.r[0] >>= 2;  // 06080ABC shlr2 r0
    c.r[0] >>= 2;  // 06080ABE shlr2 r0
    c.r[1] = ld32(0x06080B3Cu);  // 06080AC0 mov.l 0x06080B3C,r1
    c.r[1] = ld32(c.r[1]);  // 06080AC2 mov.l @r1,r1
    c.r[1] += 8;  // 06080AC4 add #8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06080AC6 mov.b @r1,r1
    c.r[0] &= 0x3u;  // 06080AC8 and #3,r0
    c.r[1] = c.r[1] & 0xFFu;  // 06080ACA extu.b r1,r1
    c.r[1] >>= 2;  // 06080ACC shlr2 r1
    c.r[1] >>= 2;  // 06080ACE shlr2 r1
    c.r[1] >>= 2;  // 06080AD0 shlr2 r1
    c.t = c.r[0] == c.r[1];  // 06080AD2 cmp/eq r1,r0
    { const bool k = !c.t; c.r[5] = c.r[8] & 0xFFu; if (k) { goto L_06080AEC; } }  // 06080AD4 bf/s 0x06080AEC ; extu.b r8,r5
    c.r[1] = ld32(0x06080B4Cu);  // 06080AD8 mov.l 0x06080B4C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06080ADEu; c.r[4] = ld32(c.r[10]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06080ADEu) return; }  // 06080ADA jsr @r1 ; mov.l @r10,r4
    c.r[2] = ld32(c.r[11]);  // 06080ADE mov.l @r11,r2
    c.r[1] = ld32(c.r[10]);  // 06080AE0 mov.l @r10,r1
    c.r[2] += c.r[9];  // 06080AE2 add r9,r2
    c.r[1] += 12;  // 06080AE4 add #12,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06080AE6 mov.w @r1,r1
    c.r[2] += 10;  // 06080AE8 add #10,r2
    st16(c.r[2], c.r[1]);  // 06080AEA mov.w r1,@r2
L_06080AEC:
    c.r[8] += 1;  // 06080AEC add #1,r8
    c.r[1] = 0x7Fu;  // 06080AEE mov #127,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 06080AF0 cmp/gt r1,r8
    { const bool k = !c.t; c.r[9] += 12; if (k) { SH2_POLL(c); goto L_06080AA8; } }  // 06080AF2 bf/s 0x06080AA8 ; add #12,r9
    c.r[8] = 0x0u;  // 06080AF6 mov #0,r8
    c.r[6] = ld32(0x06080B3Cu);  // 06080AF8 mov.l 0x06080B3C,r6
    c.r[2] = (uint32_t)(int16_t)ld16(0x06080B2Cu);  // 06080AFA mov.w 0x06080B2C,r2
    c.r[3] = 0x9u;  // 06080AFC mov #9,r3
    c.r[7] = 0x1Du;  // 06080AFE mov #29,r7
L_06080B00:
    c.r[0] = ld32(c.r[6]);  // 06080B00 mov.l @r6,r0
    c.r[0] += c.r[8];  // 06080B02 add r8,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06080B04 mov.b @(r0,r2),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06080B06 extu.b r1,r1
    c.t = c.r[1] > c.r[3];  // 06080B08 cmp/hi r3,r1
    if (!c.t) { goto L_06080B0E; }  // 06080B0A bf 0x06080B0E
    st8(c.r[0] + c.r[2], c.r[3]);  // 06080B0C mov.b r3,@(r0,r2)
L_06080B0E:
    c.r[8] += 1;  // 06080B0E add #1,r8
    c.t = (int32_t)c.r[8] > (int32_t)c.r[7];  // 06080B10 cmp/gt r7,r8
    if (!c.t) { SH2_POLL(c); goto L_06080B00; }  // 06080B12 bf 0x06080B00
    c.r[15] = c.r[14];  // 06080B14 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06080B16 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06080B18 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06080B1A mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06080B1C mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06080B1E mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06080B2Eu);  // 06080B20 mov.w 0x06080B2E,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06080B22 rts ; mov.l @r15+,r8
}

void f_06080B50(SH2Context& c) {
    ran[1802] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06080B50 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06080B52 sts.l pr,@-r15
    c.r[1] = ld32(0x06080B68u);  // 06080B54 mov.l 0x06080B68,r1
    c.r[1] = ld32(c.r[1]);  // 06080B56 mov.l @r1,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06080B5Cu; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06080B5Cu) return; }  // 06080B58 jsr @r1 ; mov r15,r14
    c.r[15] = c.r[14];  // 06080B5C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06080B5E lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x06080B66u);  // 06080B60 mov.w 0x06080B66,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06080B62 rts ; mov.l @r15+,r14
}

void f_06080B6C(SH2Context& c) {
    ran[1803] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06080B6C mov.l r14,@-r15
    c.r[1] = ld32(0x06080BA0u);  // 06080B6E mov.l 0x06080BA0,r1
    c.r[2] = ld32(c.r[1]);  // 06080B70 mov.l @r1,r2
    c.r[2] += 1;  // 06080B72 add #1,r2
    st32(c.r[1], c.r[2]);  // 06080B74 mov.l r2,@r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06080B76 mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06080B78 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06080B7A tst r1,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06080B86; } }  // 06080B7C bt/s 0x06080B86 ; mov r15,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x06080B9Au);  // 06080B80 mov.w 0x06080B9A,r0
    c.r[15] = c.r[14]; goto L_06080B96;  // 06080B82 bra 0x06080B96 ; mov r14,r15
L_06080B86:
    c.r[1] = ld32(0x06080BA4u);  // 06080B86 mov.l 0x06080BA4,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06080B88 mov.b @r1,r2
    c.r[2] += c.r[2];  // 06080B8A add r2,r2
    c.r[2] += 1;  // 06080B8C add #1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06080B9Cu);  // 06080B8E mov.w 0x06080B9C,r1
    c.r[2] |= c.r[1];  // 06080B90 or r1,r2
    c.r[0] = c.r[2] & 0xFFFFu;  // 06080B92 extu.w r2,r0
    c.r[15] = c.r[14];  // 06080B94 mov r14,r15
L_06080B96:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06080B96 rts ; mov.l @r15+,r14
}

void f_06080BA8(SH2Context& c) {
    ran[1804] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06080BA8 mov.l r14,@-r15
    c.r[1] = ld32(0x06080BE4u);  // 06080BAA mov.l 0x06080BE4,r1
    c.r[2] = ld32(c.r[1]);  // 06080BAC mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06080BDCu);  // 06080BAE mov.w 0x06080BDC,r1
    c.r[0] = c.r[2];  // 06080BB0 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06080BB2 mov.b @(r0,r1),r1
    c.r[0] = 0x1u;  // 06080BB4 mov #1,r0
    c.r[1] &= c.r[0];  // 06080BB6 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06080BB8 tst r1,r1
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_06080BD4; } }  // 06080BBA bf/s 0x06080BD4 ; mov r15,r14
    c.r[2] += 7;  // 06080BBE add #7,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06080BC0 mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06080BC2 extu.b r1,r1
    c.r[0] = c.r[1];  // 06080BC4 mov r1,r0
    c.t = c.r[0] == 0x1Eu;  // 06080BC6 cmp/eq #30,r0
    { const bool k = c.t; c.t = c.r[0] == 0x43u; if (k) { goto L_06080BCE; } }  // 06080BC8 bt/s 0x06080BCE ; cmp/eq #67,r0
    if (!c.t) { goto L_06080BD4; }  // 06080BCC bf 0x06080BD4
L_06080BCE:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06080BDEu);  // 06080BCE mov.w 0x06080BDE,r0
    c.r[15] = c.r[14]; goto L_06080BD8;  // 06080BD0 bra 0x06080BD8 ; mov r14,r15
L_06080BD4:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06080BE0u);  // 06080BD4 mov.w 0x06080BE0,r0
    c.r[15] = c.r[14];  // 06080BD6 mov r14,r15
L_06080BD8:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06080BD8 rts ; mov.l @r15+,r14
}

void f_06080BE8(SH2Context& c) {
    ran[1805] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06080BE8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06080BEA sts.l pr,@-r15
    c.r[1] = ld32(0x06080C30u);  // 06080BEC mov.l 0x06080C30,r1
    c.r[1] = ld32(c.r[1]);  // 06080BEE mov.l @r1,r1
    c.r[1] += 8;  // 06080BF0 add #8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06080BF2 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06080BF4 mov r1,r0
    c.r[0] >>= 2;  // 06080BF6 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06080BF8 shlr r0
    c.r[0] &= 0x1u;  // 06080BFA and #1,r0
    c.t = c.r[0] == 0x1u;  // 06080BFC cmp/eq #1,r0
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_06080C12; } }  // 06080BFE bf/s 0x06080C12 ; mov r15,r14
    c.r[1] = ld32(0x06080C34u);  // 06080C02 mov.l 0x06080C34,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06080C08u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06080C08u) return; }  // 06080C04 jsr @r1 ; mov r0,r4
    c.r[1] = ld32(0x06080C38u);  // 06080C08 mov.l 0x06080C38,r1
    c.r[2] = ld32(c.r[1]);  // 06080C0A mov.l @r1,r2
    c.r[2] += 3;  // 06080C0C add #3,r2
    c.r[1] = 0x0u; goto L_06080C20;  // 06080C0E bra 0x06080C20 ; mov #0,r1
L_06080C12:
    c.r[1] = ld32(0x06080C34u);  // 06080C12 mov.l 0x06080C34,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06080C18u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06080C18u) return; }  // 06080C14 jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x06080C38u);  // 06080C18 mov.l 0x06080C38,r1
    c.r[2] = ld32(c.r[1]);  // 06080C1A mov.l @r1,r2
    c.r[2] += 3;  // 06080C1C add #3,r2
    c.r[1] = 0xFFFFFF80u;  // 06080C1E mov #-128,r1
L_06080C20:
    st8(c.r[2], c.r[1]);  // 06080C20 mov.b r1,@r2
    c.r[15] = c.r[14];  // 06080C22 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06080C24 lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x06080C2Cu);  // 06080C26 mov.w 0x06080C2C,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06080C28 rts ; mov.l @r15+,r14
}

void f_06080C3C(SH2Context& c) {
    ran[1806] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06080C3C mov.l r14,@-r15
    c.r[1] = ld32(0x06080C64u);  // 06080C3E mov.l 0x06080C64,r1
    c.r[2] = ld32(c.r[1]);  // 06080C40 mov.l @r1,r2
    c.r[1] = ld32(0x06080C68u);  // 06080C42 mov.l 0x06080C68,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06080C44 mov.b @r1,r1
    c.r[14] = c.r[15];  // 06080C46 mov r15,r14
    c.r[0] = c.r[1] & 0xFFu;  // 06080C48 extu.b r1,r0
    c.r[0] += c.r[0];  // 06080C4A add r0,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06080C4C mov.b @(r0,r2),r1
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06080C4E mov.l @r15+,r14
    c.r[0] = c.r[1];  // 06080C50 mov r1,r0
    c.r[0] >>= 2;  // 06080C52 shlr2 r0
    c.r[0] >>= 2;  // 06080C54 shlr2 r0
    c.r[0] >>= 2;  // 06080C56 shlr2 r0
    c.r[0] &= 0x2u;  // 06080C58 and #2,r0
    c.r[0] += 1;  // 06080C5A add #1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06080C62u);  // 06080C5C mov.w 0x06080C62,r1
    { const uint32_t x = c.pr; c.r[0] |= c.r[1]; c.pc = x; return; }  // 06080C5E rts ; or r1,r0
}

void f_06080C6C(SH2Context& c) {
    ran[1807] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06080C6C mov.l r14,@-r15
    c.r[1] = ld32(0x06080C98u);  // 06080C6E mov.l 0x06080C98,r1
    c.r[1] = ld32(c.r[1]);  // 06080C70 mov.l @r1,r1
    c.r[1] += 1;  // 06080C72 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06080C74 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06080C76 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06080C78 tst r1,r1
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_06080C86; } }  // 06080C7A bf/s 0x06080C86 ; mov r15,r14
    c.r[2] = ld32(0x06080C9Cu);  // 06080C7E mov.l 0x06080C9C,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06080C80 mov.w @r2,r1
    c.r[1] += 1; goto L_06080C8C;  // 06080C82 bra 0x06080C8C ; add #1,r1
L_06080C86:
    c.r[2] = ld32(0x06080C9Cu);  // 06080C86 mov.l 0x06080C9C,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06080C88 mov.w @r2,r1
    c.r[1] -= 1;  // 06080C8A add #-1,r1
L_06080C8C:
    st16(c.r[2], c.r[1]);  // 06080C8C mov.w r1,@r2
    c.r[15] = c.r[14];  // 06080C8E mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x06080C96u);  // 06080C90 mov.w 0x06080C96,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06080C92 rts ; mov.l @r15+,r14
}

void f_06080CA0(SH2Context& c) {
    ran[1808] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06080CA0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06080CA2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06080CA4 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06080CA6 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06080CA8 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06080CAA mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06080CAC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06080CAE sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x06080DEEu);  // 06080CB0 mov.w 0x06080DEE,r3
    c.r[15] += c.r[3];  // 06080CB2 add r3,r15
    c.r[14] = c.r[15];  // 06080CB4 mov r15,r14
    c.r[3] = ld32(0x06080E00u);  // 06080CB6 mov.l 0x06080E00,r3
    c.r[2] = c.r[3];  // 06080CB8 mov r3,r2
    c.r[2] += 112;  // 06080CBA add #112,r2
    c.r[1] = 0x3Fu;  // 06080CBC mov #63,r1
    st16(c.r[2], c.r[1]);  // 06080CBE mov.w r1,@r2
    c.r[3] += 114;  // 06080CC0 add #114,r3
    c.r[1] = 0xFFFFFFDFu;  // 06080CC2 mov #-33,r1
    st16(c.r[3], c.r[1]);  // 06080CC4 mov.w r1,@r3
    c.r[1] = ld32(0x06080E04u);  // 06080CC6 mov.l 0x06080E04,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06080CCCu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06080CCCu) return; }  // 06080CC8 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06080E08u);  // 06080CCC mov.l 0x06080E08,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06080CD2u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06080CD2u) return; }  // 06080CCE jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06080E0Cu);  // 06080CD2 mov.l 0x06080E0C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06080CD8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06080CD8u) return; }  // 06080CD4 jsr @r1 ; nop
    c.r[10] = ld32(0x06080E10u);  // 06080CD8 mov.l 0x06080E10,r10
    c.r[9] = ld32(0x06080E14u);  // 06080CDA mov.l 0x06080E14,r9
    c.r[8] = ld32(0x06080E18u);  // 06080CDC mov.l 0x06080E18,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 06080CDE mov.b @r10,r1
    c.r[5] = 0x0u;  // 06080CE0 mov #0,r5
    c.r[1] = c.r[1] & 0xFFu;  // 06080CE2 extu.b r1,r1
    c.r[0] = c.r[1];  // 06080CE4 mov r1,r0
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 06080CE6 mov.b @(r0,r9),r6
    c.r[4] = 0x0u;  // 06080CE8 mov #0,r4
    { const uint32_t x = c.r[8]; c.pr = 0x06080CEEu; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06080CEEu) return; }  // 06080CEA jsr @r8 ; extu.b r6,r6
    c.r[11] = ld32(0x06080E1Cu);  // 06080CEE mov.l 0x06080E1C,r11
    c.r[1] = ld32(c.r[11]);  // 06080CF0 mov.l @r11,r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x06080DF0u);  // 06080CF2 mov.w 0x06080DF0,r12
    c.r[0] = c.r[1];  // 06080CF4 mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[12]);  // 06080CF6 mov.b @(r0,r12),r2
    c.r[2] = c.r[2] & 0xFFu;  // 06080CF8 extu.b r2,r2
    c.r[2] += 8;  // 06080CFA add #8,r2
    c.r[1] = ld32(0x06080E20u);  // 06080CFC mov.l 0x06080E20,r1
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[2] * (int32_t)c.r[1]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 06080CFE dmuls.l r1,r2
    c.r[5] = 0x0u;  // 06080D00 mov #0,r5
    c.r[4] = 0x0u;  // 06080D02 mov #0,r4
    c.r[6] = c.mach;  // 06080D04 sts mach,r6
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 06080D06 shar r6
    c.t = c.r[2] >> 31; c.r[2] <<= 1;  // 06080D08 shll r2
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 06080D0A subc r2,r2
    { const uint32_t x = c.r[8]; c.pr = 0x06080D10u; c.r[6] -= c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06080D10u) return; }  // 06080D0C jsr @r8 ; sub r2,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 06080D10 mov.b @r10,r1
    c.r[13] = (uint32_t)(int16_t)ld16(0x06080DF2u);  // 06080D12 mov.w 0x06080DF2,r13
    c.r[6] = c.r[1] & 0xFFu;  // 06080D14 extu.b r1,r6
    c.r[0] = c.r[6];  // 06080D16 mov r6,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 06080D18 mov.b @(r0,r9),r1
    c.r[13] += c.r[14];  // 06080D1A add r14,r13
    c.r[1] = c.r[1] & 0xFFu;  // 06080D1C extu.b r1,r1
    st32(c.r[13], c.r[1]);  // 06080D1E mov.l r1,@r13
    c.r[0] = (uint32_t)(int16_t)ld16(0x06080DF2u);  // 06080D20 mov.w 0x06080DF2,r0
    c.r[0] += c.r[14];  // 06080D22 add r14,r0
    c.r[13] = ld32(c.r[0]);  // 06080D24 mov.l @r0,r13
    c.r[13] -= 1;  // 06080D26 add #-1,r13
    st32(c.r[0], c.r[13]);  // 06080D28 mov.l r13,@r0
    c.r[0] = (uint32_t)(int16_t)ld16(0x06080DF2u);  // 06080D2A mov.w 0x06080DF2,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06080D2C mov.l @(r0,r14),r0
    c.r[7] = 0x9u;  // 06080D2E mov #9,r7
    c.macl = c.r[0] * c.r[7];  // 06080D30 mul.l r7,r0
    c.r[3] = ld32(0x06080E24u);  // 06080D32 mov.l 0x06080E24,r3
    c.r[1] = ld32(0x06080E28u);  // 06080D34 mov.l 0x06080E28,r1
    c.r[0] = c.r[6];  // 06080D36 mov r6,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06080D38 mov.b @(r0,r1),r1
    c.r[2] = c.macl;  // 06080D3A sts macl,r2
    c.r[2] += c.r[1];  // 06080D3C add r1,r2
    st8(c.r[3], c.r[2]);  // 06080D3E mov.b r2,@r3
    c.r[1] = ld32(c.r[11]);  // 06080D40 mov.l @r11,r1
    c.r[0] = c.r[1];  // 06080D42 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[12]);  // 06080D44 mov.b @(r0,r12),r1
    c.r[4] = c.r[1] & 0xFFu;  // 06080D46 extu.b r1,r4
    c.r[1] = c.macl;  // 06080D48 sts macl,r1
    c.r[4] -= c.r[1];  // 06080D4A sub r1,r4
    c.t = (int32_t)c.r[4] > (int32_t)c.r[7];  // 06080D4C cmp/gt r7,r4
    if (c.t) { goto L_06080D58; }  // 06080D4E bt 0x06080D58
    c.r[13] = (uint32_t)(int16_t)ld16(0x06080DF4u);  // 06080D50 mov.w 0x06080DF4,r13
    c.r[13] += c.r[14];  // 06080D52 add r14,r13
    st32(c.r[13], c.r[4]); goto L_06080D5C;  // 06080D54 bra 0x06080D5C ; mov.l r4,@r13
L_06080D58:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06080DF4u);  // 06080D58 mov.w 0x06080DF4,r0
    st32(c.r[0] + c.r[14], c.r[7]);  // 06080D5A mov.l r7,@(r0,r14)
L_06080D5C:
    c.r[13] = (uint32_t)(int16_t)ld16(0x06080DF6u);  // 06080D5C mov.w 0x06080DF6,r13
    c.r[13] += c.r[14];  // 06080D5E add r14,r13
    c.r[13] = (uint32_t)(int8_t)ld8(c.r[13]);  // 06080D60 mov.b @r13,r13
    c.r[1] = ld32(0x06080E2Cu);  // 06080D62 mov.l 0x06080E2C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06080D68u; c.r[4] = c.r[13] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06080D68u) return; }  // 06080D64 jsr @r1 ; extu.b r13,r4
    c.r[1] = 0x9u;  // 06080D68 mov #9,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06080DF2u);  // 06080D6A mov.w 0x06080DF2,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06080D6C mov.l @(r0,r14),r0
    c.r[13] = (uint32_t)(int16_t)ld16(0x06080DF4u);  // 06080D6E mov.w 0x06080DF4,r13
    c.macl = c.r[0] * c.r[1];  // 06080D70 mul.l r1,r0
    c.r[13] += c.r[14];  // 06080D72 add r14,r13
    c.r[13] = ld32(c.r[13]);  // 06080D74 mov.l @r13,r13
    c.r[10] = c.macl;  // 06080D76 sts macl,r10
    c.r[1] = c.macl;  // 06080D78 sts macl,r1
    c.r[1] += c.r[13];  // 06080D7A add r13,r1
    c.t = (int32_t)c.r[10] >= (int32_t)c.r[1];  // 06080D7C cmp/ge r1,r10
    if (!c.t) { goto L_06080D84; }  // 06080D7E bf 0x06080D84
    goto L_06080ECA;  // 06080D80 bra 0x06080ECA ; nop
L_06080D84:
    c.r[12] = ld32(0x06080E30u);  // 06080D84 mov.l 0x06080E30,r12
L_06080D86:
    c.r[1] = ld32(0x06080E1Cu);  // 06080D86 mov.l 0x06080E1C,r1
    c.r[2] = c.r[10];  // 06080D88 mov r10,r2
    c.r[2] += c.r[2];  // 06080D8A add r2,r2
    c.r[1] = ld32(c.r[1]);  // 06080D8C mov.l @r1,r1
    c.r[13] = 0x7Fu;  // 06080D8E mov #127,r13
    c.r[0] = c.r[1];  // 06080D90 mov r1,r0
    c.r[1] += c.r[2];  // 06080D92 add r2,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06080D94 mov.b @(r0,r2),r3
    c.r[1] += 1;  // 06080D96 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06080D98 mov.b @r1,r1
    c.r[3] &= c.r[13];  // 06080D9A and r13,r3
    c.r[3] <<= 8;  // 06080D9C shll8 r3
    c.r[11] = c.r[1] & 0xFFu;  // 06080D9E extu.b r1,r11
    c.r[11] |= c.r[3];  // 06080DA0 or r3,r11
    c.r[1] = 0x1Eu;  // 06080DA2 mov #30,r1
    c.macl = c.r[11] * c.r[1];  // 06080DA4 mul.l r1,r11
    c.r[2] = ld32(c.r[12]);  // 06080DA6 mov.l @r12,r2
    c.r[3] = c.macl;  // 06080DA8 sts macl,r3
    c.r[3] += c.r[2];  // 06080DAA add r2,r3
    c.r[1] = c.r[3];  // 06080DAC mov r3,r1
    c.r[1] += 15;  // 06080DAE add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06080DB0 mov.b @r1,r1
    c.r[0] = c.r[10];  // 06080DB2 mov r10,r0
    c.r[8] = c.r[1] & 0xFFu;  // 06080DB4 extu.b r1,r8
    c.r[1] = ld32(0x06080E34u);  // 06080DB6 mov.l 0x06080E34,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06080DB8 mov.b @(r0,r1),r4
    c.r[5] = (uint32_t)(int16_t)ld16(0x06080DF8u);  // 06080DBA mov.w 0x06080DF8,r5
    c.r[4] = c.r[4] & 0xFFu;  // 06080DBC extu.b r4,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x06080DFAu);  // 06080DBE mov.w 0x06080DFA,r1
    c.r[4] += c.r[1];  // 06080DC0 add r1,r4
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06080DC2 mov.w @r3,r1
    c.r[13] = ld32(0x06080E38u);  // 06080DC4 mov.l 0x06080E38,r13
    c.r[4] += c.r[1];  // 06080DC6 add r1,r4
    { const uint32_t x = c.r[13]; c.pr = 0x06080DCCu; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06080DCCu) return; }  // 06080DC8 jsr @r13 ; extu.w r4,r4
    c.r[0] = (uint32_t)(int16_t)ld16(0x06080DF8u);  // 06080DCC mov.w 0x06080DF8,r0
    c.t = c.r[8] == c.r[0];  // 06080DCE cmp/eq r0,r8
    { const bool k = c.t; c.r[5] = c.r[8]; if (k) { goto L_06080E40; } }  // 06080DD0 bt/s 0x06080E40 ; mov r8,r5
    c.r[1] = ld32(0x06080E3Cu);  // 06080DD4 mov.l 0x06080E3C,r1
    c.r[2] = c.r[8];  // 06080DD6 mov r8,r2
    c.r[2] += c.r[2];  // 06080DD8 add r2,r2
    c.r[2] += c.r[8];  // 06080DDA add r8,r2
    c.r[2] <<= 2;  // 06080DDC shll2 r2
    c.r[1] = ld32(c.r[1]);  // 06080DDE mov.l @r1,r1
    c.r[0] = c.r[2];  // 06080DE0 mov r2,r0
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06080DE2 mov.w @(r0,r1),r4
    c.r[5] = (uint32_t)(int16_t)ld16(0x06080DF8u);  // 06080DE4 mov.w 0x06080DF8,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x06080DFCu);  // 06080DE6 mov.w 0x06080DFC,r1
    c.r[4] += c.r[1];  // 06080DE8 add r1,r4
    c.r[4] = c.r[4] & 0xFFFFu; goto L_06080E44;  // 06080DEA bra 0x06080E44 ; extu.w r4,r4
L_06080E40:
    c.r[4] = ld32(0x06080FE0u);  // 06080E40 mov.l 0x06080FE0,r4
    c.r[13] = ld32(0x06080FE4u);  // 06080E42 mov.l 0x06080FE4,r13
L_06080E44:
    { const uint32_t x = c.r[13]; c.pr = 0x06080E48u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06080E48u) return; }  // 06080E44 jsr @r13 ; nop
    c.r[1] = ld32(0x06080FE8u);  // 06080E48 mov.l 0x06080FE8,r1
    c.r[0] = c.r[10];  // 06080E4A mov r10,r0
    c.r[1] = ld32(c.r[1]);  // 06080E4C mov.l @r1,r1
    c.r[0] += c.r[0];  // 06080E4E add r0,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06080E50 mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06080E52 extu.b r1,r1
    c.r[1] >>= 2;  // 06080E54 shlr2 r1
    c.r[1] >>= 2;  // 06080E56 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06080E58 shlr r1
    c.r[1] >>= 2;  // 06080E5A shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06080E5C tst r1,r1
    { const bool k = c.t; c.r[1] = 0x1Eu; if (k) { goto L_06080E98; } }  // 06080E5E bt/s 0x06080E98 ; mov #30,r1
    c.r[1] = ld32(0x06080FECu);  // 06080E62 mov.l 0x06080FEC,r1
    c.r[0] = c.r[10];  // 06080E64 mov r10,r0
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06080E66 mov.b @(r0,r1),r7
    c.r[1] = c.r[7] & 0xFFu;  // 06080E68 extu.b r7,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06080E6A tst r1,r1
    { const bool k = c.t; c.r[1] = 0x1Eu; if (k) { goto L_06080E98; } }  // 06080E6C bt/s 0x06080E98 ; mov #30,r1
    c.r[5] = c.r[11] & 0xFFu;  // 06080E70 extu.b r11,r5
    c.r[6] = (uint32_t)(int16_t)ld16(0x06080FCCu);  // 06080E72 mov.w 0x06080FCC,r6
    c.macl = c.r[11] * c.r[1];  // 06080E74 mul.l r1,r11
    c.r[4] = c.r[14];  // 06080E76 mov r14,r4
    c.r[3] = ld32(c.r[12]);  // 06080E78 mov.l @r12,r3
    c.r[8] = c.macl;  // 06080E7A sts macl,r8
    c.r[3] += c.r[8];  // 06080E7C add r8,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06080E7E mov.w @r3,r2
    c.r[1] = c.r[7] & 0xFFu;  // 06080E80 extu.b r7,r1
    c.r[9] = c.r[2] & 0xFFFFu;  // 06080E82 extu.w r2,r9
    c.r[2] += c.r[1];  // 06080E84 add r1,r2
    c.r[1] = ld32(0x06080FF0u);  // 06080E86 mov.l 0x06080FF0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06080E8Cu; st16(c.r[3], c.r[2]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06080E8Cu) return; }  // 06080E88 jsr @r1 ; mov.w r2,@r3
    c.r[1] = c.r[14];  // 06080E8C mov r14,r1
    c.r[1] += 26;  // 06080E8E add #26,r1
    c.r[0] = ld32(c.r[12]);  // 06080E90 mov.l @r12,r0
    c.r[5] = 0x0u;  // 06080E92 mov #0,r5
    st16(c.r[0] + c.r[8], c.r[9]); goto L_06080EA4;  // 06080E94 bra 0x06080EA4 ; mov.w r9,@(r0,r8)
L_06080E98:
    c.macl = c.r[11] * c.r[1];  // 06080E98 mul.l r1,r11
    c.r[5] = 0x0u;  // 06080E9A mov #0,r5
    c.r[2] = ld32(c.r[12]);  // 06080E9C mov.l @r12,r2
    c.r[1] = c.macl;  // 06080E9E sts macl,r1
    c.r[1] += c.r[2];  // 06080EA0 add r2,r1
    c.r[1] += 22;  // 06080EA2 add #22,r1
L_06080EA4:
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06080EA4 mov.w @r1,r6
    c.r[4] = 0x0u;  // 06080EA6 mov #0,r4
    c.r[1] = ld32(0x06080FF4u);  // 06080EA8 mov.l 0x06080FF4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06080EAEu; c.r[6] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06080EAEu) return; }  // 06080EAA jsr @r1 ; extu.w r6,r6
    c.r[10] += 1;  // 06080EAE add #1,r10
    c.r[1] = 0x9u;  // 06080EB0 mov #9,r1
    c.r[13] = (uint32_t)(int16_t)ld16(0x06080FCEu);  // 06080EB2 mov.w 0x06080FCE,r13
    c.r[13] += c.r[14];  // 06080EB4 add r14,r13
    c.r[13] = ld32(c.r[13]);  // 06080EB6 mov.l @r13,r13
    c.r[0] = (uint32_t)(int16_t)ld16(0x06080FD0u);  // 06080EB8 mov.w 0x06080FD0,r0
    c.macl = c.r[13] * c.r[1];  // 06080EBA mul.l r1,r13
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06080EBC mov.l @(r0,r14),r0
    c.r[1] = c.macl;  // 06080EBE sts macl,r1
    c.r[1] += c.r[0];  // 06080EC0 add r0,r1
    c.t = (int32_t)c.r[10] >= (int32_t)c.r[1];  // 06080EC2 cmp/ge r1,r10
    if (c.t) { goto L_06080ECA; }  // 06080EC4 bt 0x06080ECA
    SH2_POLL(c); goto L_06080D86;  // 06080EC6 bra 0x06080D86 ; nop
L_06080ECA:
    c.r[13] = (uint32_t)(int16_t)ld16(0x06080FCEu);  // 06080ECA mov.w 0x06080FCE,r13
    c.r[13] += c.r[14];  // 06080ECC add r14,r13
    c.r[13] = ld32(c.r[13]);  // 06080ECE mov.l @r13,r13
    c.r[1] = 0x9u;  // 06080ED0 mov #9,r1
    c.macl = c.r[13] * c.r[1];  // 06080ED2 mul.l r1,r13
    c.r[1] = ld32(0x06080FF8u);  // 06080ED4 mov.l 0x06080FF8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06080ED6 mov.b @r1,r1
    c.r[2] = c.macl;  // 06080ED8 sts macl,r2
    c.r[3] = c.r[1] & 0xFFu;  // 06080EDA extu.b r1,r3
    c.r[1] = ld32(0x06080FFCu);  // 06080EDC mov.l 0x06080FFC,r1
    c.r[0] = c.r[3];  // 06080EDE mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06080EE0 mov.b @(r0,r1),r1
    c.r[13] = 0x7Fu;  // 06080EE2 mov #127,r13
    c.r[1] = c.r[1] & 0xFFu;  // 06080EE4 extu.b r1,r1
    c.r[2] += c.r[1];  // 06080EE6 add r1,r2
    c.r[1] = ld32(0x06080FE8u);  // 06080EE8 mov.l 0x06080FE8,r1
    c.r[1] = ld32(c.r[1]);  // 06080EEA mov.l @r1,r1
    c.r[2] += c.r[2];  // 06080EEC add r2,r2
    c.r[0] = c.r[1];  // 06080EEE mov r1,r0
    c.r[1] += c.r[2];  // 06080EF0 add r2,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06080EF2 mov.b @(r0,r2),r3
    c.r[1] += 1;  // 06080EF4 add #1,r1
    c.r[3] &= c.r[13];  // 06080EF6 and r13,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06080EF8 mov.b @r1,r2
    c.r[3] <<= 8;  // 06080EFA shll8 r3
    c.r[2] = c.r[2] & 0xFFu;  // 06080EFC extu.b r2,r2
    c.r[2] |= c.r[3];  // 06080EFE or r3,r2
    c.r[1] = ld32(0x06081000u);  // 06080F00 mov.l 0x06081000,r1
    c.r[3] = ld32(c.r[1]);  // 06080F02 mov.l @r1,r3
    c.r[1] = 0x1Eu;  // 06080F04 mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 06080F06 mul.l r1,r2
    c.r[9] = ld32(0x06081004u);  // 06080F08 mov.l 0x06081004,r9
    c.r[1] = c.macl;  // 06080F0A sts macl,r1
    c.r[1] += c.r[3];  // 06080F0C add r3,r1
    c.r[1] += 15;  // 06080F0E add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06080F10 mov.b @r1,r1
    c.r[5] = (uint32_t)(int16_t)ld16(0x06080FCCu);  // 06080F12 mov.w 0x06080FCC,r5
    c.r[4] = ld32(c.r[9]);  // 06080F14 mov.l @r9,r4
    c.r[8] = c.r[1] & 0xFFu;  // 06080F16 extu.b r1,r8
    c.r[1] = c.r[8];  // 06080F18 mov r8,r1
    c.r[1] += c.r[1];  // 06080F1A add r1,r1
    c.r[1] += c.r[8];  // 06080F1C add r8,r1
    c.r[1] <<= 2;  // 06080F1E shll2 r1
    c.r[1] += c.r[4];  // 06080F20 add r4,r1
    c.r[1] += 8;  // 06080F22 add #8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06080F24 mov.b @r1,r1
    c.t = c.r[8] == c.r[5];  // 06080F26 cmp/eq r5,r8
    { const bool k = c.t; c.r[1] = c.r[1] & 0xFFu; if (k) { goto L_06080F66; } }  // 06080F28 bt/s 0x06080F66 ; extu.b r1,r1
    c.t = c.r[1] == c.r[5];  // 06080F2C cmp/eq r5,r1
    { const bool k = c.t; c.r[8] = c.r[1]; if (k) { goto L_06080F66; } }  // 06080F2E bt/s 0x06080F66 ; mov r1,r8
    c.r[8] += c.r[8];  // 06080F32 add r8,r8
    c.r[8] += c.r[1];  // 06080F34 add r1,r8
    c.r[8] <<= 2;  // 06080F36 shll2 r8
    c.r[0] = c.r[8];  // 06080F38 mov r8,r0
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[4]);  // 06080F3A mov.w @(r0,r4),r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x06080FD2u);  // 06080F3C mov.w 0x06080FD2,r1
    c.r[2] = c.r[4] & 0xFFFFu;  // 06080F3E extu.w r4,r2
    c.t = c.r[2] == c.r[1];  // 06080F40 cmp/eq r1,r2
    if (c.t) { goto L_06080F4A; }  // 06080F42 bt 0x06080F4A
    c.r[1] = (uint32_t)(int16_t)ld16(0x06080FD4u);  // 06080F44 mov.w 0x06080FD4,r1
    c.t = c.r[2] == c.r[1];  // 06080F46 cmp/eq r1,r2
    if (!c.t) { goto L_06080F66; }  // 06080F48 bf 0x06080F66
L_06080F4A:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06080FD6u);  // 06080F4A mov.w 0x06080FD6,r1
    c.r[4] += c.r[1];  // 06080F4C add r1,r4
    c.r[1] = ld32(0x06080FE4u);  // 06080F4E mov.l 0x06080FE4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06080F54u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06080F54u) return; }  // 06080F50 jsr @r1 ; extu.w r4,r4
    c.r[5] = 0x0u;  // 06080F54 mov #0,r5
    c.r[1] = ld32(c.r[9]);  // 06080F56 mov.l @r9,r1
    c.r[4] = 0x0u;  // 06080F58 mov #0,r4
    c.r[8] += c.r[1];  // 06080F5A add r1,r8
    c.r[8] += 2;  // 06080F5C add #2,r8
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06080F5E mov.b @r8,r6
    c.r[1] = ld32(0x06080FF4u);  // 06080F60 mov.l 0x06080FF4,r1
    c.r[6] = c.r[6] & 0xFFu; goto L_06080F76;  // 06080F62 bra 0x06080F76 ; extu.b r6,r6
L_06080F66:
    c.r[4] = ld32(0x06080FE0u);  // 06080F66 mov.l 0x06080FE0,r4
    c.r[1] = ld32(0x06080FE4u);  // 06080F68 mov.l 0x06080FE4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06080F6Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06080F6Eu) return; }  // 06080F6A jsr @r1 ; nop
    c.r[1] = ld32(0x06080FF4u);  // 06080F6E mov.l 0x06080FF4,r1
    c.r[6] = 0x0u;  // 06080F70 mov #0,r6
    c.r[5] = 0x0u;  // 06080F72 mov #0,r5
    c.r[4] = 0x20u;  // 06080F74 mov #32,r4
L_06080F76:
    { const uint32_t x = c.r[1]; c.pr = 0x06080F7Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06080F7Au) return; }  // 06080F76 jsr @r1 ; nop
    c.r[1] = ld32(0x06080FE8u);  // 06080F7A mov.l 0x06080FE8,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06080FD8u);  // 06080F7C mov.w 0x06080FD8,r0
    c.r[2] = 0x1u;  // 06080F7E mov #1,r2
    c.r[7] = 0x2u;  // 06080F80 mov #2,r7
    c.r[6] = 0x24u;  // 06080F82 mov #36,r6
    c.r[1] = ld32(c.r[1]);  // 06080F84 mov.l @r1,r1
    c.r[5] = 0x5u;  // 06080F86 mov #5,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06080F88 mov.b @(r0,r1),r1
    c.r[4] = 0x2u;  // 06080F8A mov #2,r4
    c.r[1] = c.r[1] & 0xFFu;  // 06080F8C extu.b r1,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06080F8E mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06080F90 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06080F92 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06080F94 mov.l r2,@-r15
    c.r[1] = 0x0u;  // 06080F96 mov #0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06080F98 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06080F9A mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06080F9C mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06080F9E mov.l r1,@-r15
    c.r[1] = 0x9u;  // 06080FA0 mov #9,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06080FA2 mov.l r1,@-r15
    c.r[1] = ld32(0x06081008u);  // 06080FA4 mov.l 0x06081008,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06080FAAu; c.r[15] -= 4; st32(c.r[15], c.r[2]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06080FAAu) return; }  // 06080FA6 jsr @r1 ; mov.l r2,@-r15
    c.r[15] += 40;  // 06080FAA add #40,r15
    c.r[1] = ld32(0x0608100Cu);  // 06080FAC mov.l 0x0608100C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06080FB2u; c.r[4] = 0x3Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06080FB2u) return; }  // 06080FAE jsr @r1 ; mov #60,r4
    c.r[3] = (uint32_t)(int16_t)ld16(0x06080FDAu);  // 06080FB2 mov.w 0x06080FDA,r3
    c.r[14] += c.r[3];  // 06080FB4 add r3,r14
    c.r[15] = c.r[14];  // 06080FB6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06080FB8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06080FBA mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06080FBC mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06080FBE mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06080FC0 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06080FC2 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06080FC4 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06080FDCu);  // 06080FC6 mov.w 0x06080FDC,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06080FC8 rts ; mov.l @r15+,r8
}

void f_06081010(SH2Context& c) {
    ran[1809] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06081010 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06081012 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06081014 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06081016 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06081018 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0608101A mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608101C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608101E sts.l pr,@-r15
    c.r[15] -= 12;  // 06081020 add #-12,r15
    c.r[14] = c.r[15];  // 06081022 mov r15,r14
    c.r[13] = ld32(0x0608116Cu);  // 06081024 mov.l 0x0608116C,r13
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 06081026 mov.b @r13,r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x06081166u);  // 06081028 mov.w 0x06081166,r12
    c.r[1] = c.r[1] & 0xFFu;  // 0608102A extu.b r1,r1
    c.r[0] = c.r[1];  // 0608102C mov r1,r0
    c.t = c.r[0] == 0x41u;  // 0608102E cmp/eq #65,r0
    c.r[0] = 0x1u;  // 06081030 mov #1,r0
    { const bool k = !c.t; st32(c.r[14] + 4, c.r[0]); if (k) { goto L_0608103A; } }  // 06081032 bf/s 0x0608103A ; mov.l r0,@(4,r14)
    c.r[0] = 0x0u;  // 06081036 mov #0,r0
    st32(c.r[14] + 4, c.r[0]);  // 06081038 mov.l r0,@(4,r14)
L_0608103A:
    c.r[1] = ld32(0x06081170u);  // 0608103A mov.l 0x06081170,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06081040u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06081040u) return; }  // 0608103C jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06081174u);  // 06081040 mov.l 0x06081174,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06081046u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06081046u) return; }  // 06081042 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06081178u);  // 06081046 mov.l 0x06081178,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0608104Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608104Cu) return; }  // 06081048 jsr @r1 ; nop
    c.r[10] = ld32(0x0608117Cu);  // 0608104C mov.l 0x0608117C,r10
    c.r[8] = ld32(0x06081180u);  // 0608104E mov.l 0x06081180,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 06081050 mov.b @r13,r1
    c.r[5] = 0x0u;  // 06081052 mov #0,r5
    c.r[1] = c.r[1] & 0xFFu;  // 06081054 extu.b r1,r1
    c.r[0] = c.r[1];  // 06081056 mov r1,r0
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 06081058 mov.b @(r0,r10),r6
    c.r[4] = 0x0u;  // 0608105A mov #0,r4
    { const uint32_t x = c.r[8]; c.pr = 0x06081060u; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06081060u) return; }  // 0608105C jsr @r8 ; extu.b r6,r6
    c.r[11] = ld32(0x06081184u);  // 06081060 mov.l 0x06081184,r11
    c.r[1] = ld32(c.r[11]);  // 06081062 mov.l @r11,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06081168u);  // 06081064 mov.w 0x06081168,r0
    st32(c.r[14] + 8, c.r[0]);  // 06081066 mov.l r0,@(8,r14)
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06081068 mov.b @(r0,r1),r2
    c.r[2] = c.r[2] & 0xFFu;  // 0608106A extu.b r2,r2
    c.r[2] += 8;  // 0608106C add #8,r2
    c.r[1] = ld32(0x06081188u);  // 0608106E mov.l 0x06081188,r1
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[2] * (int32_t)c.r[1]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 06081070 dmuls.l r1,r2
    c.r[5] = 0x0u;  // 06081072 mov #0,r5
    c.r[4] = 0x0u;  // 06081074 mov #0,r4
    c.r[6] = c.mach;  // 06081076 sts mach,r6
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 06081078 shar r6
    c.t = c.r[2] >> 31; c.r[2] <<= 1;  // 0608107A shll r2
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 0608107C subc r2,r2
    { const uint32_t x = c.r[8]; c.pr = 0x06081082u; c.r[6] -= c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06081082u) return; }  // 0608107E jsr @r8 ; sub r2,r6
    c.r[4] = ld32(0x0608118Cu);  // 06081082 mov.l 0x0608118C,r4
    c.r[8] = ld32(0x06081190u);  // 06081084 mov.l 0x06081190,r8
    c.r[9] = ld32(c.r[14] + 4);  // 06081086 mov.l @(4,r14),r9
    c.r[5] = 0x17u;  // 06081088 mov #23,r5
    c.r[9] += 47;  // 0608108A add #47,r9
    { const uint32_t x = c.r[8]; c.pr = 0x06081090u; c.r[9] = c.r[9] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06081090u) return; }  // 0608108C jsr @r8 ; extu.w r9,r9
    c.r[1] = c.r[0];  // 06081090 mov r0,r1
    c.r[5] = 0x23u;  // 06081092 mov #35,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06081098u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06081098u) return; }  // 06081094 jsr @r8 ; mov r1,r4
    c.r[1] = c.r[0];  // 06081098 mov r0,r1
    c.r[5] = c.r[9];  // 0608109A mov r9,r5
    { const uint32_t x = c.r[8]; c.pr = 0x060810A0u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060810A0u) return; }  // 0608109C jsr @r8 ; mov r1,r4
    c.r[2] = c.r[0];  // 060810A0 mov r0,r2
    c.r[1] = ld32(0x06081194u);  // 060810A2 mov.l 0x06081194,r1
    c.r[6] = 0x0u;  // 060810A4 mov #0,r6
    c.r[5] = c.r[2];  // 060810A6 mov r2,r5
    { const uint32_t x = c.r[1]; c.pr = 0x060810ACu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060810ACu) return; }  // 060810A8 jsr @r1 ; mov #0,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 060810AC mov.b @r13,r1
    c.r[3] = ld32(0x06081198u);  // 060810AE mov.l 0x06081198,r3
    c.r[6] = c.r[1] & 0xFFu;  // 060810B0 extu.b r1,r6
    c.r[0] = c.r[6];  // 060810B2 mov r6,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 060810B4 mov.b @(r0,r10),r1
    c.r[7] = 0x9u;  // 060810B6 mov #9,r7
    c.r[1] = c.r[1] & 0xFFu;  // 060810B8 extu.b r1,r1
    st32(c.r[14], c.r[1]);  // 060810BA mov.l r1,@r14
    c.r[0] = c.r[1];  // 060810BC mov r1,r0
    c.r[0] -= 1;  // 060810BE add #-1,r0
    c.macl = c.r[0] * c.r[7];  // 060810C0 mul.l r7,r0
    st32(c.r[14], c.r[0]);  // 060810C2 mov.l r0,@r14
    c.r[1] = ld32(0x0608119Cu);  // 060810C4 mov.l 0x0608119C,r1
    c.r[0] = c.r[6];  // 060810C6 mov r6,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060810C8 mov.b @(r0,r1),r1
    c.r[2] = c.macl;  // 060810CA sts macl,r2
    c.r[2] += c.r[1];  // 060810CC add r1,r2
    st8(c.r[3], c.r[2]);  // 060810CE mov.b r2,@r3
    c.r[1] = ld32(c.r[11]);  // 060810D0 mov.l @r11,r1
    c.r[0] = ld32(c.r[14] + 8);  // 060810D2 mov.l @(8,r14),r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060810D4 mov.b @(r0,r1),r1
    c.r[4] = c.r[1] & 0xFFu;  // 060810D6 extu.b r1,r4
    c.r[1] = c.macl;  // 060810D8 sts macl,r1
    c.r[4] -= c.r[1];  // 060810DA sub r1,r4
    c.t = (int32_t)c.r[4] > (int32_t)c.r[7];  // 060810DC cmp/gt r7,r4
    { const bool k = c.t; c.r[13] = c.r[7]; if (k) { goto L_060810E4; } }  // 060810DE bt/s 0x060810E4 ; mov r7,r13
    c.r[13] = c.r[4];  // 060810E2 mov r4,r13
L_060810E4:
    c.r[1] = ld32(0x060811A0u);  // 060810E4 mov.l 0x060811A0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060810EAu; c.r[4] = c.r[13] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060810EAu) return; }  // 060810E6 jsr @r1 ; extu.b r13,r4
    c.r[0] = ld32(c.r[14]);  // 060810EA mov.l @r14,r0
    c.r[1] = 0x9u;  // 060810EC mov #9,r1
    c.macl = c.r[0] * c.r[1];  // 060810EE mul.l r1,r0
    c.r[10] = c.macl;  // 060810F0 sts macl,r10
    c.r[1] = c.macl;  // 060810F2 sts macl,r1
    c.r[1] += c.r[13];  // 060810F4 add r13,r1
    c.t = (int32_t)c.r[10] >= (int32_t)c.r[1];  // 060810F6 cmp/ge r1,r10
    { const bool k = !c.t; c.r[1] = 0x9u; if (k) { goto L_06081100; } }  // 060810F8 bf/s 0x06081100 ; mov #9,r1
    goto L_0608122E;  // 060810FC bra 0x0608122E ; nop
L_06081100:
    c.r[11] = (uint32_t)(int16_t)ld16(0x06081166u);  // 06081100 mov.w 0x06081166,r11
L_06081102:
    c.r[1] = ld32(0x06081184u);  // 06081102 mov.l 0x06081184,r1
    c.r[2] = c.r[10];  // 06081104 mov r10,r2
    c.r[1] = ld32(c.r[1]);  // 06081106 mov.l @r1,r1
    c.r[2] += c.r[2];  // 06081108 add r2,r2
    c.r[0] = c.r[1];  // 0608110A mov r1,r0
    c.r[1] += c.r[2];  // 0608110C add r2,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0608110E mov.b @(r0,r2),r3
    c.r[1] += 1;  // 06081110 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06081112 mov.b @r1,r1
    c.r[0] = 0x7Fu;  // 06081114 mov #127,r0
    c.r[3] &= c.r[0];  // 06081116 and r0,r3
    c.r[3] <<= 8;  // 06081118 shll8 r3
    c.r[9] = c.r[1] & 0xFFu;  // 0608111A extu.b r1,r9
    c.r[9] |= c.r[3];  // 0608111C or r3,r9
    c.r[0] = ld32(0x060811A4u);  // 0608111E mov.l 0x060811A4,r0
    c.r[8] = c.r[9];  // 06081120 mov r9,r8
    c.r[8] += c.r[8];  // 06081122 add r8,r8
    c.r[8] += c.r[9];  // 06081124 add r9,r8
    c.r[1] = ld32(c.r[0]);  // 06081126 mov.l @r0,r1
    c.r[8] <<= 2;  // 06081128 shll2 r8
    c.r[0] = c.r[8];  // 0608112A mov r8,r0
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0608112C mov.w @(r0,r1),r4
    c.r[5] = c.r[11];  // 0608112E mov r11,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x0608116Au);  // 06081130 mov.w 0x0608116A,r1
    c.r[4] += c.r[1];  // 06081132 add r1,r4
    c.r[0] = ld32(0x060811A8u);  // 06081134 mov.l 0x060811A8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0608113Au; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608113Au) return; }  // 06081136 jsr @r0 ; extu.w r4,r4
    c.r[0] = ld32(0x060811A4u);  // 0608113A mov.l 0x060811A4,r0
    c.r[1] = ld32(c.r[0]);  // 0608113C mov.l @r0,r1
    c.r[8] += c.r[1];  // 0608113E add r1,r8
    c.r[8] += 3;  // 06081140 add #3,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06081142 mov.b @r8,r1
    c.r[0] = 0x1u;  // 06081144 mov #1,r0
    c.r[1] >>= 2;  // 06081146 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06081148 shlr r1
    c.r[1] &= c.r[0];  // 0608114A and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0608114C tst r1,r1
    { const bool k = c.t; c.r[4] = c.r[9] & 0xFFu; if (k) { goto L_060811B2; } }  // 0608114E bt/s 0x060811B2 ; extu.b r9,r4
    c.r[8] = c.r[9] & 0xFFu;  // 06081152 extu.b r9,r8
    c.r[0] = ld32(0x060811ACu);  // 06081154 mov.l 0x060811AC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0608115Au; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608115Au) return; }  // 06081156 jsr @r0 ; mov r8,r4
    c.r[12] = c.r[0] & 0xFFu;  // 0608115A extu.b r0,r12
    c.t = c.r[12] == c.r[11];  // 0608115C cmp/eq r11,r12
    { const bool k = !c.t; c.r[4] = c.r[8]; if (k) { goto L_060811B0; } }  // 0608115E bf/s 0x060811B0 ; mov r8,r4
    goto L_060811B2;  // 06081162 bra 0x060811B2 ; nop
L_060811B0:
    c.r[4] = c.r[12] & 0xFFu;  // 060811B0 extu.b r12,r4
L_060811B2:
    c.r[0] = ld32(0x06081314u);  // 060811B2 mov.l 0x06081314,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060811B8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060811B8u) return; }  // 060811B4 jsr @r0 ; nop
    c.r[1] = c.r[0];  // 060811B8 mov r0,r1
    c.r[8] = c.r[1] & 0xFFu;  // 060811BA extu.b r1,r8
    c.t = c.r[8] == c.r[11];  // 060811BC cmp/eq r11,r8
    { const bool k = c.t; c.r[5] = c.r[8]; if (k) { goto L_060811DA; } }  // 060811BE bt/s 0x060811DA ; mov r8,r5
    c.r[1] = ld32(0x06081318u);  // 060811C2 mov.l 0x06081318,r1
    c.r[2] = ld32(c.r[1]);  // 060811C4 mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 060811C6 mov #30,r1
    c.macl = c.r[8] * c.r[1];  // 060811C8 mul.l r1,r8
    c.r[1] = c.macl;  // 060811CA sts macl,r1
    c.r[0] = c.r[1];  // 060811CC mov r1,r0
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 060811CE mov.w @(r0,r2),r4
    c.r[5] = c.r[11];  // 060811D0 mov r11,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x0608130Au);  // 060811D2 mov.w 0x0608130A,r1
    c.r[4] += c.r[1];  // 060811D4 add r1,r4
    c.r[4] = c.r[4] & 0xFFFFu; goto L_060811DC;  // 060811D6 bra 0x060811DC ; extu.w r4,r4
L_060811DA:
    c.r[4] = ld32(0x0608131Cu);  // 060811DA mov.l 0x0608131C,r4
L_060811DC:
    c.r[0] = ld32(0x06081320u);  // 060811DC mov.l 0x06081320,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060811E2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060811E2u) return; }  // 060811DE jsr @r0 ; nop
    c.r[0] = ld32(0x06081324u);  // 060811E2 mov.l 0x06081324,r0
    c.r[2] = c.r[9];  // 060811E4 mov r9,r2
    c.r[2] += c.r[2];  // 060811E6 add r2,r2
    c.r[2] += c.r[9];  // 060811E8 add r9,r2
    c.r[2] <<= 2;  // 060811EA shll2 r2
    c.r[5] = 0x0u;  // 060811EC mov #0,r5
    c.r[1] = ld32(c.r[0]);  // 060811EE mov.l @r0,r1
    c.r[4] = 0x0u;  // 060811F0 mov #0,r4
    c.r[2] += c.r[1];  // 060811F2 add r1,r2
    c.r[2] += 2;  // 060811F4 add #2,r2
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060811F6 mov.b @r2,r6
    c.r[1] = ld32(0x06081328u);  // 060811F8 mov.l 0x06081328,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060811FEu; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060811FEu) return; }  // 060811FA jsr @r1 ; extu.b r6,r6
    c.r[1] = ld32(0x0608132Cu);  // 060811FE mov.l 0x0608132C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06081200 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06081202 extu.b r1,r1
    c.t = c.r[10] == c.r[1];  // 06081204 cmp/eq r1,r10
    { const bool k = !c.t; c.r[0] = ld32(c.r[14]); if (k) { goto L_06081218; } }  // 06081206 bf/s 0x06081218 ; mov.l @r14,r0
    c.r[1] = ld32(0x06081330u);  // 0608120A mov.l 0x06081330,r1
    st8(c.r[1], c.r[8]);  // 0608120C mov.b r8,@r1
    c.r[1] = ld32(0x06081334u);  // 0608120E mov.l 0x06081334,r1
    st8(c.r[1], c.r[12]);  // 06081210 mov.b r12,@r1
    c.r[1] = ld32(0x06081338u);  // 06081212 mov.l 0x06081338,r1
    st8(c.r[1], c.r[9]);  // 06081214 mov.b r9,@r1
    c.r[0] = ld32(c.r[14]);  // 06081216 mov.l @r14,r0
L_06081218:
    c.r[1] = 0x9u;  // 06081218 mov #9,r1
    c.macl = c.r[0] * c.r[1];  // 0608121A mul.l r1,r0
    c.r[10] += 1;  // 0608121C add #1,r10
    c.r[1] = c.macl;  // 0608121E sts macl,r1
    c.r[1] += c.r[13];  // 06081220 add r13,r1
    c.t = (int32_t)c.r[10] >= (int32_t)c.r[1];  // 06081222 cmp/ge r1,r10
    { const bool k = c.t; c.r[0] = ld32(c.r[14]); if (k) { goto L_0608122C; } }  // 06081224 bt/s 0x0608122C ; mov.l @r14,r0
    SH2_POLL(c); goto L_06081102;  // 06081228 bra 0x06081102 ; nop
L_0608122C:
    c.r[1] = 0x9u;  // 0608122C mov #9,r1
L_0608122E:
    c.macl = c.r[0] * c.r[1];  // 0608122E mul.l r1,r0
    c.r[1] = ld32(0x0608133Cu);  // 06081230 mov.l 0x0608133C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06081232 mov.b @r1,r1
    c.r[3] = 0x7Fu;  // 06081234 mov #127,r3
    c.r[2] = c.r[1] & 0xFFu;  // 06081236 extu.b r1,r2
    c.r[1] = ld32(0x06081340u);  // 06081238 mov.l 0x06081340,r1
    c.r[0] = c.r[2];  // 0608123A mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0608123C mov.b @(r0,r1),r1
    c.r[7] = c.macl;  // 0608123E sts macl,r7
    c.r[1] = c.r[1] & 0xFFu;  // 06081240 extu.b r1,r1
    c.r[7] += c.r[1];  // 06081242 add r1,r7
    c.r[1] = ld32(0x06081344u);  // 06081244 mov.l 0x06081344,r1
    c.r[2] = ld32(c.r[1]);  // 06081246 mov.l @r1,r2
    c.r[7] += c.r[7];  // 06081248 add r7,r7
    c.r[0] = c.r[2];  // 0608124A mov r2,r0
    c.r[2] += c.r[7];  // 0608124C add r7,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0608124E mov.b @(r0,r7),r1
    c.r[2] += 1;  // 06081250 add #1,r2
    c.r[6] = c.r[1] & 0xFFu;  // 06081252 extu.b r1,r6
    c.r[3] &= c.r[6];  // 06081254 and r6,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06081256 mov.b @r2,r1
    c.r[3] <<= 8;  // 06081258 shll8 r3
    c.r[0] = ld32(c.r[14] + 4);  // 0608125A mov.l @(4,r14),r0
    c.r[9] = c.r[1] & 0xFFu;  // 0608125C extu.b r1,r9
    c.t = (c.r[0] & c.r[0]) == 0;  // 0608125E tst r0,r0
    { const bool k = c.t; c.r[9] |= c.r[3]; if (k) { goto L_06081270; } }  // 06081260 bt/s 0x06081270 ; or r3,r9
    c.r[6] >>= 2;  // 06081264 shlr2 r6
    c.r[6] >>= 2;  // 06081266 shlr2 r6
    c.t = c.r[6] & 1; c.r[6] >>= 1;  // 06081268 shlr r6
    c.r[6] >>= 2;  // 0608126A shlr2 r6
    c.t = (c.r[6] & c.r[6]) == 0;  // 0608126C tst r6,r6
    if (!c.t) { goto L_060812B2; }  // 0608126E bf 0x060812B2
L_06081270:
    c.r[1] = ld32(0x06081324u);  // 06081270 mov.l 0x06081324,r1
    c.r[2] = ld32(c.r[1]);  // 06081272 mov.l @r1,r2
    c.r[1] = c.r[9];  // 06081274 mov r9,r1
    c.r[1] += c.r[1];  // 06081276 add r1,r1
    c.r[1] += c.r[9];  // 06081278 add r9,r1
    c.r[1] <<= 2;  // 0608127A shll2 r1
    c.r[1] += c.r[2];  // 0608127C add r2,r1
    c.r[1] += 8;  // 0608127E add #8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06081280 mov.b @r1,r1
    c.r[12] = c.r[1] & 0xFFu;  // 06081282 extu.b r1,r12
    c.r[1] = c.r[12];  // 06081284 mov r12,r1
    c.r[1] += c.r[1];  // 06081286 add r1,r1
    c.r[1] += c.r[12];  // 06081288 add r12,r1
    c.r[1] <<= 2;  // 0608128A shll2 r1
    c.r[0] = c.r[1];  // 0608128C mov r1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 0608128E mov.w @(r0,r2),r1
    c.r[2] = c.r[1] & 0xFFFFu;  // 06081290 extu.w r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0608130Cu);  // 06081292 mov.w 0x0608130C,r1
    c.t = c.r[2] == c.r[1];  // 06081294 cmp/eq r1,r2
    if (c.t) { goto L_060812A0; }  // 06081296 bt 0x060812A0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0608130Eu);  // 06081298 mov.w 0x0608130E,r1
    c.t = c.r[2] == c.r[1];  // 0608129A cmp/eq r1,r2
    if (c.t) { goto L_060812A0; }  // 0608129C bt 0x060812A0
    c.r[12] = (uint32_t)(int16_t)ld16(0x06081310u);  // 0608129E mov.w 0x06081310,r12
L_060812A0:
    c.r[4] = ld32(0x06081348u);  // 060812A0 mov.l 0x06081348,r4
    c.r[8] = ld32(0x0608134Cu);  // 060812A2 mov.l 0x0608134C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060812A8u; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060812A8u) return; }  // 060812A4 jsr @r8 ; mov #23,r5
    c.r[5] = 0x23u;  // 060812A8 mov #35,r5
    { const uint32_t x = c.r[8]; c.pr = 0x060812AEu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060812AEu) return; }  // 060812AA jsr @r8 ; mov r0,r4
    c.r[5] = 0x31u; goto L_060812CA;  // 060812AE bra 0x060812CA ; mov #49,r5
L_060812B2:
    c.r[0] = ld32(0x06081350u);  // 060812B2 mov.l 0x06081350,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060812B8u; c.r[4] = c.r[9] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060812B8u) return; }  // 060812B4 jsr @r0 ; extu.b r9,r4
    c.r[12] = c.r[0] & 0xFFu;  // 060812B8 extu.b r0,r12
    c.r[4] = ld32(0x06081348u);  // 060812BA mov.l 0x06081348,r4
    c.r[8] = ld32(0x0608134Cu);  // 060812BC mov.l 0x0608134C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060812C2u; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060812C2u) return; }  // 060812BE jsr @r8 ; mov #23,r5
    c.r[5] = 0x23u;  // 060812C2 mov #35,r5
    { const uint32_t x = c.r[8]; c.pr = 0x060812C8u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060812C8u) return; }  // 060812C4 jsr @r8 ; mov r0,r4
    c.r[5] = 0x32u;  // 060812C8 mov #50,r5
L_060812CA:
    { const uint32_t x = c.r[8]; c.pr = 0x060812CEu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060812CEu) return; }  // 060812CA jsr @r8 ; mov r0,r4
    c.r[1] = ld32(0x06081354u);  // 060812CE mov.l 0x06081354,r1
    c.r[6] = 0x0u;  // 060812D0 mov #0,r6
    c.r[5] = c.r[0];  // 060812D2 mov r0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x060812D8u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060812D8u) return; }  // 060812D4 jsr @r1 ; mov #0,r4
    c.r[5] = (uint32_t)(int16_t)ld16(0x06081310u);  // 060812D8 mov.w 0x06081310,r5
    c.t = c.r[12] == c.r[5];  // 060812DA cmp/eq r5,r12
    { const bool k = c.t; c.r[9] = c.r[12]; if (k) { goto L_06081358; } }  // 060812DC bt/s 0x06081358 ; mov r12,r9
    c.r[8] = ld32(0x06081324u);  // 060812E0 mov.l 0x06081324,r8
    c.r[9] += c.r[9];  // 060812E2 add r9,r9
    c.r[9] += c.r[12];  // 060812E4 add r12,r9
    c.r[9] <<= 2;  // 060812E6 shll2 r9
    c.r[1] = ld32(c.r[8]);  // 060812E8 mov.l @r8,r1
    c.r[0] = c.r[9];  // 060812EA mov r9,r0
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 060812EC mov.w @(r0,r1),r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x06081312u);  // 060812EE mov.w 0x06081312,r1
    c.r[4] += c.r[1];  // 060812F0 add r1,r4
    c.r[1] = ld32(0x06081320u);  // 060812F2 mov.l 0x06081320,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060812F8u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060812F8u) return; }  // 060812F4 jsr @r1 ; extu.w r4,r4
    c.r[5] = 0x0u;  // 060812F8 mov #0,r5
    c.r[1] = ld32(c.r[8]);  // 060812FA mov.l @r8,r1
    c.r[4] = 0x0u;  // 060812FC mov #0,r4
    c.r[9] += c.r[1];  // 060812FE add r1,r9
    c.r[9] += 2;  // 06081300 add #2,r9
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06081302 mov.b @r9,r6
    c.r[1] = ld32(0x06081328u);  // 06081304 mov.l 0x06081328,r1
    c.r[6] = c.r[6] & 0xFFu; goto L_06081368;  // 06081306 bra 0x06081368 ; extu.b r6,r6
L_06081358:
    c.r[4] = ld32(0x060813C0u);  // 06081358 mov.l 0x060813C0,r4
    c.r[1] = ld32(0x060813C4u);  // 0608135A mov.l 0x060813C4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06081360u; c.r[5] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06081360u) return; }  // 0608135C jsr @r1 ; mov r12,r5
    c.r[1] = ld32(0x060813C8u);  // 06081360 mov.l 0x060813C8,r1
    c.r[6] = 0x0u;  // 06081362 mov #0,r6
    c.r[5] = 0x0u;  // 06081364 mov #0,r5
    c.r[4] = 0x20u;  // 06081366 mov #32,r4
L_06081368:
    { const uint32_t x = c.r[1]; c.pr = 0x0608136Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608136Cu) return; }  // 06081368 jsr @r1 ; nop
    c.r[1] = ld32(0x060813CCu);  // 0608136C mov.l 0x060813CC,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060813BCu);  // 0608136E mov.w 0x060813BC,r0
    c.r[2] = 0x1u;  // 06081370 mov #1,r2
    c.r[7] = 0x2u;  // 06081372 mov #2,r7
    c.r[6] = 0x24u;  // 06081374 mov #36,r6
    c.r[1] = ld32(c.r[1]);  // 06081376 mov.l @r1,r1
    c.r[5] = 0x5u;  // 06081378 mov #5,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0608137A mov.b @(r0,r1),r1
    c.r[4] = 0x2u;  // 0608137C mov #2,r4
    c.r[1] = c.r[1] & 0xFFu;  // 0608137E extu.b r1,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06081380 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06081382 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06081384 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06081386 mov.l r2,@-r15
    c.r[1] = 0x0u;  // 06081388 mov #0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0608138A mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 0608138C mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0608138E mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06081390 mov.l r1,@-r15
    c.r[1] = 0x9u;  // 06081392 mov #9,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06081394 mov.l r1,@-r15
    c.r[1] = ld32(0x060813D0u);  // 06081396 mov.l 0x060813D0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0608139Cu; c.r[15] -= 4; st32(c.r[15], c.r[2]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608139Cu) return; }  // 06081398 jsr @r1 ; mov.l r2,@-r15
    c.r[15] += 40;  // 0608139C add #40,r15
    c.r[1] = ld32(0x060813D4u);  // 0608139E mov.l 0x060813D4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060813A4u; c.r[4] = 0x3Du; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060813A4u) return; }  // 060813A0 jsr @r1 ; mov #61,r4
    c.r[14] += 12;  // 060813A4 add #12,r14
    c.r[15] = c.r[14];  // 060813A6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060813A8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060813AA mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060813AC mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060813AE mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060813B0 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060813B2 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060813B4 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x060813BEu);  // 060813B6 mov.w 0x060813BE,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060813B8 rts ; mov.l @r15+,r8
}

void f_060813D8(SH2Context& c) {
    ran[1810] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060813D8 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 060813DA mov r15,r14
    c.r[4] = c.r[4] & 0xFFu;  // 060813DC extu.b r4,r4
    c.r[7] = (uint32_t)(int16_t)ld16(0x06081424u);  // 060813DE mov.w 0x06081424,r7
    c.r[3] = 0x0u;  // 060813E0 mov #0,r3
    c.r[1] = ld32(0x06081428u);  // 060813E2 mov.l 0x06081428,r1
    c.r[6] = ld32(c.r[1]);  // 060813E4 mov.l @r1,r6
    c.r[5] = 0x1Eu;  // 060813E6 mov #30,r5
    c.macl = c.r[3] * c.r[5];  // 060813E8 mul.l r5,r3
L_060813EA:
    c.r[2] = c.macl;  // 060813EA sts macl,r2
    c.r[2] += c.r[6];  // 060813EC add r6,r2
    c.r[1] = c.r[2];  // 060813EE mov r2,r1
    c.r[1] += 15;  // 060813F0 add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060813F2 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060813F4 extu.b r1,r1
    c.t = c.r[1] == c.r[4];  // 060813F6 cmp/eq r4,r1
    { const bool k = !c.t; c.r[1] = c.r[3]; if (k) { goto L_06081410; } }  // 060813F8 bf/s 0x06081410 ; mov r3,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 060813FC mov.w @r2,r1
    c.r[0] = c.r[1] & 0xFFFFu;  // 060813FE extu.w r1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06081400 tst r0,r0
    { const bool k = c.t; c.t = c.r[0] == 0x2u; if (k) { goto L_0608140E; } }  // 06081402 bt/s 0x0608140E ; cmp/eq #2,r0
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_06081410; } }  // 06081406 bt/s 0x06081410 ; mov r3,r1
    c.r[7] = c.r[3]; goto L_0608141C;  // 0608140A bra 0x0608141C ; mov r3,r7
L_0608140E:
    c.r[1] = c.r[3];  // 0608140E mov r3,r1
L_06081410:
    c.r[1] += 1;  // 06081410 add #1,r1
    c.r[3] = c.r[1] & 0xFFu;  // 06081412 extu.b r1,r3
    c.r[1] = 0x7Fu;  // 06081414 mov #127,r1
    c.t = c.r[3] > c.r[1];  // 06081416 cmp/hi r1,r3
    { const bool k = !c.t; c.macl = c.r[3] * c.r[5]; if (k) { SH2_POLL(c); goto L_060813EA; } }  // 06081418 bf/s 0x060813EA ; mul.l r5,r3
L_0608141C:
    c.r[15] = c.r[14];  // 0608141C mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608141E mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[7]; c.pc = x; return; }  // 06081420 rts ; mov r7,r0
}

void f_0608142C(SH2Context& c) {
    ran[1811] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608142C mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0608142E mov r15,r14
    c.r[4] = c.r[4] & 0xFFFFu;  // 06081430 extu.w r4,r4
    c.r[3] = (uint32_t)(int16_t)ld16(0x06081462u);  // 06081432 mov.w 0x06081462,r3
    c.r[2] = 0x0u;  // 06081434 mov #0,r2
    c.r[1] = ld32(0x06081464u);  // 06081436 mov.l 0x06081464,r1
    c.r[7] = ld32(c.r[1]);  // 06081438 mov.l @r1,r7
    c.r[5] = 0x1Eu;  // 0608143A mov #30,r5
    c.r[6] = 0x7Fu;  // 0608143C mov #127,r6
    c.macl = c.r[2] * c.r[5];  // 0608143E mul.l r5,r2
L_06081440:
    c.r[0] = c.macl;  // 06081440 sts macl,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[7]);  // 06081442 mov.w @(r0,r7),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06081444 extu.w r1,r1
    c.t = c.r[1] == c.r[4];  // 06081446 cmp/eq r4,r1
    { const bool k = !c.t; c.r[1] = c.r[2]; if (k) { goto L_06081450; } }  // 06081448 bf/s 0x06081450 ; mov r2,r1
    c.r[3] = c.r[2]; goto L_0608145A;  // 0608144C bra 0x0608145A ; mov r2,r3
L_06081450:
    c.r[1] += 1;  // 06081450 add #1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 06081452 extu.b r1,r2
    c.t = c.r[2] > c.r[6];  // 06081454 cmp/hi r6,r2
    { const bool k = !c.t; c.macl = c.r[2] * c.r[5]; if (k) { SH2_POLL(c); goto L_06081440; } }  // 06081456 bf/s 0x06081440 ; mul.l r5,r2
L_0608145A:
    c.r[15] = c.r[14];  // 0608145A mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608145C mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[3]; c.pc = x; return; }  // 0608145E rts ; mov r3,r0
}

void f_06081468(SH2Context& c) {
    ran[1812] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06081468 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0608146A mov r15,r14
    c.r[2] = c.r[4] & 0xFFu;  // 0608146C extu.b r4,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x060814B8u);  // 0608146E mov.w 0x060814B8,r3
    c.r[1] = ld32(0x060814BCu);  // 06081470 mov.l 0x060814BC,r1
    c.r[6] = ld32(c.r[1]);  // 06081472 mov.l @r1,r6
    c.r[5] = 0x7Fu;  // 06081474 mov #127,r5
    c.r[7] = 0x0u;  // 06081476 mov #0,r7
L_06081478:
    c.r[4] = 0x0u;  // 06081478 mov #0,r4
    c.r[1] = c.r[4];  // 0608147A mov r4,r1
L_0608147C:
    c.r[1] += c.r[1];  // 0608147C add r1,r1
    c.r[1] += c.r[4];  // 0608147E add r4,r1
    c.r[1] <<= 2;  // 06081480 shll2 r1
    c.r[1] += c.r[6];  // 06081482 add r6,r1
    c.r[1] += 8;  // 06081484 add #8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06081486 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06081488 extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 0608148A cmp/eq r2,r1
    { const bool k = !c.t; c.t = (c.r[2] & c.r[2]) == 0; if (k) { goto L_0608149C; } }  // 0608148C bf/s 0x0608149C ; tst r2,r2
    { const bool k = c.t; c.r[1] = c.r[4]; if (k) { goto L_0608149E; } }  // 06081490 bt/s 0x0608149E ; mov r4,r1
    c.r[3] = c.r[4];  // 06081494 mov r4,r3
    c.r[7] = 0x1u;  // 06081496 mov #1,r7
    c.r[2] = c.r[3]; goto L_060814A8;  // 06081498 bra 0x060814A8 ; mov r3,r2
L_0608149C:
    c.r[1] = c.r[4];  // 0608149C mov r4,r1
L_0608149E:
    c.r[1] += 1;  // 0608149E add #1,r1
    c.r[4] = c.r[1] & 0xFFu;  // 060814A0 extu.b r1,r4
    c.t = c.r[4] > c.r[5];  // 060814A2 cmp/hi r5,r4
    { const bool k = !c.t; c.r[1] = c.r[4]; if (k) { SH2_POLL(c); goto L_0608147C; } }  // 060814A4 bf/s 0x0608147C ; mov r4,r1
L_060814A8:
    c.r[0] = c.r[7];  // 060814A8 mov r7,r0
    c.t = c.r[0] == 0x1u;  // 060814AA cmp/eq #1,r0
    { const bool k = c.t; c.r[7] = 0x0u; if (k) { SH2_POLL(c); goto L_06081478; } }  // 060814AC bt/s 0x06081478 ; mov #0,r7
    c.r[15] = c.r[14];  // 060814B0 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060814B2 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[3]; c.pc = x; return; }  // 060814B4 rts ; mov r3,r0
}

void f_060814C0(SH2Context& c) {
    ran[1813] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060814C0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060814C2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060814C4 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060814C6 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060814C8 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060814CA mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060814CC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060814CE sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608161Eu);  // 060814D0 mov.w 0x0608161E,r3
    c.r[15] += c.r[3];  // 060814D2 add r3,r15
    c.r[14] = c.r[15];  // 060814D4 mov r15,r14
    c.r[3] = ld32(0x06081630u);  // 060814D6 mov.l 0x06081630,r3
    c.r[2] = c.r[3];  // 060814D8 mov r3,r2
    c.r[2] += 112;  // 060814DA add #112,r2
    c.r[1] = 0x3Fu;  // 060814DC mov #63,r1
    st16(c.r[2], c.r[1]);  // 060814DE mov.w r1,@r2
    c.r[3] += 114;  // 060814E0 add #114,r3
    c.r[1] = 0xFFFFFFDFu;  // 060814E2 mov #-33,r1
    st16(c.r[3], c.r[1]);  // 060814E4 mov.w r1,@r3
    c.r[1] = ld32(0x06081634u);  // 060814E6 mov.l 0x06081634,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060814ECu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060814ECu) return; }  // 060814E8 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06081638u);  // 060814EC mov.l 0x06081638,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060814F2u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060814F2u) return; }  // 060814EE jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x0608163Cu);  // 060814F2 mov.l 0x0608163C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060814F8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060814F8u) return; }  // 060814F4 jsr @r1 ; nop
    c.r[11] = ld32(0x06081640u);  // 060814F8 mov.l 0x06081640,r11
    c.r[10] = ld32(0x06081644u);  // 060814FA mov.l 0x06081644,r10
    c.r[8] = ld32(0x06081648u);  // 060814FC mov.l 0x06081648,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[11]);  // 060814FE mov.b @r11,r1
    c.r[5] = 0x0u;  // 06081500 mov #0,r5
    c.r[1] = c.r[1] & 0xFFu;  // 06081502 extu.b r1,r1
    c.r[0] = c.r[1];  // 06081504 mov r1,r0
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 06081506 mov.b @(r0,r10),r6
    c.r[4] = 0x0u;  // 06081508 mov #0,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0608150Eu; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608150Eu) return; }  // 0608150A jsr @r8 ; extu.b r6,r6
    c.r[12] = ld32(0x0608164Cu);  // 0608150E mov.l 0x0608164C,r12
    c.r[0] = (uint32_t)(int16_t)ld16(0x06081620u);  // 06081510 mov.w 0x06081620,r0
    c.r[13] = (uint32_t)(int16_t)ld16(0x06081622u);  // 06081512 mov.w 0x06081622,r13
    c.r[1] = ld32(c.r[12]);  // 06081514 mov.l @r12,r1
    c.r[13] += c.r[14];  // 06081516 add r14,r13
    st32(c.r[13], c.r[0]);  // 06081518 mov.l r0,@r13
    c.r[13] = (uint32_t)(int16_t)ld16(0x06081622u);  // 0608151A mov.w 0x06081622,r13
    c.r[13] += c.r[14];  // 0608151C add r14,r13
    c.r[0] = ld32(c.r[13]);  // 0608151E mov.l @r13,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06081520 mov.b @(r0,r1),r2
    c.r[2] = c.r[2] & 0xFFu;  // 06081522 extu.b r2,r2
    c.r[2] += 6;  // 06081524 add #6,r2
    c.r[1] = ld32(0x06081650u);  // 06081526 mov.l 0x06081650,r1
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[2] * (int32_t)c.r[1]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 06081528 dmuls.l r1,r2
    c.r[5] = 0x0u;  // 0608152A mov #0,r5
    c.r[4] = 0x0u;  // 0608152C mov #0,r4
    c.r[6] = c.mach;  // 0608152E sts mach,r6
    c.r[6] += c.r[2];  // 06081530 add r2,r6
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 06081532 shar r6
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 06081534 shar r6
    c.t = c.r[2] >> 31; c.r[2] <<= 1;  // 06081536 shll r2
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 06081538 subc r2,r2
    { const uint32_t x = c.r[8]; c.pr = 0x0608153Eu; c.r[6] -= c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608153Eu) return; }  // 0608153A jsr @r8 ; sub r2,r6
    c.r[1] = ld32(0x06081654u);  // 0608153E mov.l 0x06081654,r1
    c.r[4] = ld32(0x06081658u);  // 06081540 mov.l 0x06081658,r4
    c.r[8] = ld32(0x0608165Cu);  // 06081542 mov.l 0x0608165C,r8
    c.r[9] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06081544 mov.b @r1,r9
    c.r[5] = 0x17u;  // 06081546 mov #23,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0608154Cu; c.r[9] = c.r[9] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608154Cu) return; }  // 06081548 jsr @r8 ; extu.w r9,r9
    c.r[1] = c.r[0];  // 0608154C mov r0,r1
    c.r[5] = 0x23u;  // 0608154E mov #35,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06081554u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06081554u) return; }  // 06081550 jsr @r8 ; mov r1,r4
    c.r[1] = c.r[0];  // 06081554 mov r0,r1
    c.r[5] = c.r[9];  // 06081556 mov r9,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0608155Cu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608155Cu) return; }  // 06081558 jsr @r8 ; mov r1,r4
    c.r[2] = c.r[0];  // 0608155C mov r0,r2
    c.r[1] = ld32(0x06081660u);  // 0608155E mov.l 0x06081660,r1
    c.r[6] = 0x0u;  // 06081560 mov #0,r6
    c.r[5] = c.r[2];  // 06081562 mov r2,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06081568u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06081568u) return; }  // 06081564 jsr @r1 ; mov #0,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[11]);  // 06081568 mov.b @r11,r1
    c.r[13] = (uint32_t)(int16_t)ld16(0x06081624u);  // 0608156A mov.w 0x06081624,r13
    c.r[6] = c.r[1] & 0xFFu;  // 0608156C extu.b r1,r6
    c.r[0] = c.r[6];  // 0608156E mov r6,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 06081570 mov.b @(r0,r10),r1
    c.r[13] += c.r[14];  // 06081572 add r14,r13
    c.r[1] = c.r[1] & 0xFFu;  // 06081574 extu.b r1,r1
    st32(c.r[13], c.r[1]);  // 06081576 mov.l r1,@r13
    c.r[0] = (uint32_t)(int16_t)ld16(0x06081624u);  // 06081578 mov.w 0x06081624,r0
    c.r[0] += c.r[14];  // 0608157A add r14,r0
    c.r[13] = ld32(c.r[0]);  // 0608157C mov.l @r0,r13
    c.r[3] = ld32(0x06081664u);  // 0608157E mov.l 0x06081664,r3
    c.r[13] -= 1;  // 06081580 add #-1,r13
    st32(c.r[0], c.r[13]);  // 06081582 mov.l r13,@r0
    c.r[0] = (uint32_t)(int16_t)ld16(0x06081624u);  // 06081584 mov.w 0x06081624,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06081586 mov.l @(r0,r14),r0
    c.r[7] = 0x7u;  // 06081588 mov #7,r7
    c.macl = c.r[0] * c.r[7];  // 0608158A mul.l r7,r0
    c.r[1] = ld32(0x06081668u);  // 0608158C mov.l 0x06081668,r1
    c.r[13] = (uint32_t)(int16_t)ld16(0x06081622u);  // 0608158E mov.w 0x06081622,r13
    c.r[0] = c.r[6];  // 06081590 mov r6,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06081592 mov.b @(r0,r1),r1
    c.r[2] = c.macl;  // 06081594 sts macl,r2
    c.r[2] += c.r[1];  // 06081596 add r1,r2
    st8(c.r[3], c.r[2]);  // 06081598 mov.b r2,@r3
    c.r[1] = ld32(c.r[12]);  // 0608159A mov.l @r12,r1
    c.r[13] += c.r[14];  // 0608159C add r14,r13
    c.r[0] = ld32(c.r[13]);  // 0608159E mov.l @r13,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060815A0 mov.b @(r0,r1),r1
    c.r[4] = c.r[1] & 0xFFu;  // 060815A2 extu.b r1,r4
    c.r[1] = c.macl;  // 060815A4 sts macl,r1
    c.r[4] -= c.r[1];  // 060815A6 sub r1,r4
    c.t = (int32_t)c.r[4] > (int32_t)c.r[7];  // 060815A8 cmp/gt r7,r4
    if (c.t) { goto L_060815B4; }  // 060815AA bt 0x060815B4
    c.r[0] = (uint32_t)(int16_t)ld16(0x06081626u);  // 060815AC mov.w 0x06081626,r0
    c.r[0] += c.r[14];  // 060815AE add r14,r0
    st32(c.r[0], c.r[4]); goto L_060815BA;  // 060815B0 bra 0x060815BA ; mov.l r4,@r0
L_060815B4:
    c.r[13] = (uint32_t)(int16_t)ld16(0x06081626u);  // 060815B4 mov.w 0x06081626,r13
    c.r[13] += c.r[14];  // 060815B6 add r14,r13
    st32(c.r[13], c.r[7]);  // 060815B8 mov.l r7,@r13
L_060815BA:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06081628u);  // 060815BA mov.w 0x06081628,r0
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 060815BC mov.b @(r0,r14),r0
    c.r[1] = ld32(0x0608166Cu);  // 060815BE mov.l 0x0608166C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060815C4u; c.r[4] = c.r[0] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060815C4u) return; }  // 060815C0 jsr @r1 ; extu.b r0,r4
    c.r[1] = 0x7u;  // 060815C4 mov #7,r1
    c.r[13] = (uint32_t)(int16_t)ld16(0x06081624u);  // 060815C6 mov.w 0x06081624,r13
    c.r[13] += c.r[14];  // 060815C8 add r14,r13
    c.r[13] = ld32(c.r[13]);  // 060815CA mov.l @r13,r13
    c.r[0] = (uint32_t)(int16_t)ld16(0x06081626u);  // 060815CC mov.w 0x06081626,r0
    c.macl = c.r[13] * c.r[1];  // 060815CE mul.l r1,r13
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 060815D0 mov.l @(r0,r14),r0
    c.r[11] = c.macl;  // 060815D2 sts macl,r11
    c.r[1] = c.macl;  // 060815D4 sts macl,r1
    c.r[1] += c.r[0];  // 060815D6 add r0,r1
    c.t = (int32_t)c.r[11] >= (int32_t)c.r[1];  // 060815D8 cmp/ge r1,r11
    if (!c.t) { goto L_060815E0; }  // 060815DA bf 0x060815E0
    goto L_0608173E;  // 060815DC bra 0x0608173E ; nop
L_060815E0:
    c.r[12] = ld32(0x06081670u);  // 060815E0 mov.l 0x06081670,r12
L_060815E2:
    c.r[1] = ld32(0x0608164Cu);  // 060815E2 mov.l 0x0608164C,r1
    c.r[0] = c.r[11];  // 060815E4 mov r11,r0
    c.r[1] = ld32(c.r[1]);  // 060815E6 mov.l @r1,r1
    c.r[0] += c.r[0];  // 060815E8 add r0,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060815EA mov.b @(r0,r1),r2
    c.r[3] = 0x7Fu;  // 060815EC mov #127,r3
    c.r[2] = c.r[2] & 0xFFu;  // 060815EE extu.b r2,r2
    c.r[3] &= c.r[2];  // 060815F0 and r2,r3
    c.r[3] <<= 8;  // 060815F2 shll8 r3
    c.r[1] += c.r[0];  // 060815F4 add r0,r1
    c.r[1] += 1;  // 060815F6 add #1,r1
    c.r[2] >>= 2;  // 060815F8 shlr2 r2
    c.r[2] >>= 2;  // 060815FA shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 060815FC shlr r2
    c.r[2] >>= 2;  // 060815FE shlr2 r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06081600 mov.b @r1,r1
    c.t = (c.r[2] & c.r[2]) == 0;  // 06081602 tst r2,r2
    c.r[10] = c.r[1] & 0xFFu;  // 06081604 extu.b r1,r10
    { const bool k = !c.t; c.r[10] |= c.r[3]; if (k) { goto L_06081674; } }  // 06081606 bf/s 0x06081674 ; or r3,r10
    c.r[13] = 0x1Eu;  // 0608160A mov #30,r13
    c.macl = c.r[10] * c.r[13];  // 0608160C mul.l r13,r10
    c.r[1] = ld32(c.r[12]);  // 0608160E mov.l @r12,r1
    c.r[2] = c.macl;  // 06081610 sts macl,r2
    c.r[0] = c.r[2];  // 06081612 mov r2,r0
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06081614 mov.w @(r0,r1),r4
    c.r[5] = (uint32_t)(int16_t)ld16(0x0608162Au);  // 06081616 mov.w 0x0608162A,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x0608162Cu);  // 06081618 mov.w 0x0608162C,r1
    c.r[4] += c.r[1]; goto L_06081690;  // 0608161A bra 0x06081690 ; add r1,r4
L_06081674:
    c.r[13] = 0x1Eu;  // 06081674 mov #30,r13
    c.r[1] = ld32(0x060817ACu);  // 06081676 mov.l 0x060817AC,r1
    c.r[0] = c.r[11];  // 06081678 mov r11,r0
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0608167A mov.b @(r0,r1),r4
    c.macl = c.r[10] * c.r[13];  // 0608167C mul.l r13,r10
    c.r[2] = ld32(c.r[12]);  // 0608167E mov.l @r12,r2
    c.r[4] = c.r[4] & 0xFFu;  // 06081680 extu.b r4,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x060817A4u);  // 06081682 mov.w 0x060817A4,r1
    c.r[4] += c.r[1];  // 06081684 add r1,r4
    c.r[3] = c.macl;  // 06081686 sts macl,r3
    c.r[0] = c.r[3];  // 06081688 mov r3,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 0608168A mov.w @(r0,r2),r1
    c.r[5] = (uint32_t)(int16_t)ld16(0x060817A6u);  // 0608168C mov.w 0x060817A6,r5
    c.r[4] += c.r[1];  // 0608168E add r1,r4
L_06081690:
    c.r[1] = ld32(0x060817B0u);  // 06081690 mov.l 0x060817B0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06081696u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06081696u) return; }  // 06081692 jsr @r1 ; extu.w r4,r4
    c.r[1] = ld32(0x060817B4u);  // 06081696 mov.l 0x060817B4,r1
    c.r[0] = c.r[11];  // 06081698 mov r11,r0
    c.r[1] = ld32(c.r[1]);  // 0608169A mov.l @r1,r1
    c.r[0] += c.r[0];  // 0608169C add r0,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0608169E mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 060816A0 extu.b r1,r1
    c.r[1] >>= 2;  // 060816A2 shlr2 r1
    c.r[1] >>= 2;  // 060816A4 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060816A6 shlr r1
    c.r[1] >>= 2;  // 060816A8 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060816AA tst r1,r1
    { const bool k = c.t; c.r[0] = 0x1Eu; if (k) { goto L_060816FC; } }  // 060816AC bt/s 0x060816FC ; mov #30,r0
    c.r[1] = ld32(0x060817ACu);  // 060816B0 mov.l 0x060817AC,r1
    c.r[0] = c.r[11];  // 060816B2 mov r11,r0
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060816B4 mov.b @(r0,r1),r7
    c.r[1] = c.r[7] & 0xFFu;  // 060816B6 extu.b r7,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060816B8 tst r1,r1
    { const bool k = c.t; c.r[0] = 0x1Eu; if (k) { goto L_060816FC; } }  // 060816BA bt/s 0x060816FC ; mov #30,r0
    c.r[13] = 0x1Eu;  // 060816BE mov #30,r13
    c.r[1] = c.r[7] & 0xFFu;  // 060816C0 extu.b r7,r1
    c.r[5] = c.r[10] & 0xFFu;  // 060816C2 extu.b r10,r5
    c.macl = c.r[10] * c.r[13];  // 060816C4 mul.l r13,r10
    c.r[6] = (uint32_t)(int16_t)ld16(0x060817A6u);  // 060816C6 mov.w 0x060817A6,r6
    c.r[3] = ld32(c.r[12]);  // 060816C8 mov.l @r12,r3
    c.r[9] = c.macl;  // 060816CA sts macl,r9
    c.r[3] += c.r[9];  // 060816CC add r9,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 060816CE mov.w @r3,r2
    c.r[4] = c.r[14];  // 060816D0 mov r14,r4
    c.r[8] = c.r[2] & 0xFFFFu;  // 060816D2 extu.w r2,r8
    c.r[2] += c.r[1];  // 060816D4 add r1,r2
    c.r[1] = ld32(0x060817B8u);  // 060816D6 mov.l 0x060817B8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060816DCu; st16(c.r[3], c.r[2]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060816DCu) return; }  // 060816D8 jsr @r1 ; mov.w r2,@r3
    c.r[0] = c.r[9];  // 060816DC mov r9,r0
    c.r[5] = 0x0u;  // 060816DE mov #0,r5
    c.r[1] = ld32(c.r[12]);  // 060816E0 mov.l @r12,r1
    c.r[4] = 0x0u;  // 060816E2 mov #0,r4
    st16(c.r[0] + c.r[1], c.r[8]);  // 060816E4 mov.w r8,@(r0,r1)
    c.r[1] = c.r[14];  // 060816E6 mov r14,r1
    c.r[1] += 26;  // 060816E8 add #26,r1
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060816EA mov.w @r1,r6
    c.r[13] = ld32(0x060817BCu);  // 060816EC mov.l 0x060817BC,r13
    { const uint32_t x = c.r[13]; c.pr = 0x060816F2u; c.r[6] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060816F2u) return; }  // 060816EE jsr @r13 ; extu.w r6,r6
    c.r[1] = c.r[14];  // 060816F2 mov r14,r1
    c.r[1] += 28;  // 060816F4 add #28,r1
    c.r[5] = 0x0u;  // 060816F6 mov #0,r5
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]); goto L_0608171C;  // 060816F8 bra 0x0608171C ; mov.w @r1,r6
L_060816FC:
    c.r[5] = 0x0u;  // 060816FC mov #0,r5
    c.macl = c.r[10] * c.r[0];  // 060816FE mul.l r0,r10
    c.r[4] = 0x0u;  // 06081700 mov #0,r4
    c.r[1] = ld32(c.r[12]);  // 06081702 mov.l @r12,r1
    c.r[8] = c.macl;  // 06081704 sts macl,r8
    c.r[1] += c.r[8];  // 06081706 add r8,r1
    c.r[1] += 22;  // 06081708 add #22,r1
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0608170A mov.w @r1,r6
    c.r[13] = ld32(0x060817BCu);  // 0608170C mov.l 0x060817BC,r13
    { const uint32_t x = c.r[13]; c.pr = 0x06081712u; c.r[6] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06081712u) return; }  // 0608170E jsr @r13 ; extu.w r6,r6
    c.r[1] = ld32(c.r[12]);  // 06081712 mov.l @r12,r1
    c.r[5] = 0x0u;  // 06081714 mov #0,r5
    c.r[8] += c.r[1];  // 06081716 add r1,r8
    c.r[8] += 24;  // 06081718 add #24,r8
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[8]);  // 0608171A mov.w @r8,r6
L_0608171C:
    c.r[4] = 0x0u;  // 0608171C mov #0,r4
    { const uint32_t x = c.r[13]; c.pr = 0x06081722u; c.r[6] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06081722u) return; }  // 0608171E jsr @r13 ; extu.w r6,r6
    c.r[11] += 1;  // 06081722 add #1,r11
    c.r[1] = 0x7u;  // 06081724 mov #7,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060817A8u);  // 06081726 mov.w 0x060817A8,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06081728 mov.l @(r0,r14),r0
    c.r[13] = (uint32_t)(int16_t)ld16(0x060817AAu);  // 0608172A mov.w 0x060817AA,r13
    c.macl = c.r[0] * c.r[1];  // 0608172C mul.l r1,r0
    c.r[13] += c.r[14];  // 0608172E add r14,r13
    c.r[13] = ld32(c.r[13]);  // 06081730 mov.l @r13,r13
    c.r[1] = c.macl;  // 06081732 sts macl,r1
    c.r[1] += c.r[13];  // 06081734 add r13,r1
    c.t = (int32_t)c.r[11] >= (int32_t)c.r[1];  // 06081736 cmp/ge r1,r11
    if (c.t) { goto L_0608173E; }  // 06081738 bt 0x0608173E
    SH2_POLL(c); goto L_060815E2;  // 0608173A bra 0x060815E2 ; nop
L_0608173E:
    c.r[0] = (uint32_t)(int16_t)ld16(0x060817A8u);  // 0608173E mov.w 0x060817A8,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06081740 mov.l @(r0,r14),r0
    c.r[1] = 0x7u;  // 06081742 mov #7,r1
    c.macl = c.r[0] * c.r[1];  // 06081744 mul.l r1,r0
    c.r[1] = ld32(0x060817C0u);  // 06081746 mov.l 0x060817C0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06081748 mov.b @r1,r1
    c.r[13] = 0x7Fu;  // 0608174A mov #127,r13
    c.r[2] = c.r[1] & 0xFFu;  // 0608174C extu.b r1,r2
    c.r[1] = ld32(0x060817C4u);  // 0608174E mov.l 0x060817C4,r1
    c.r[0] = c.r[2];  // 06081750 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06081752 mov.b @(r0,r1),r1
    c.r[3] = c.macl;  // 06081754 sts macl,r3
    c.r[1] = c.r[1] & 0xFFu;  // 06081756 extu.b r1,r1
    c.r[3] += c.r[1];  // 06081758 add r1,r3
    c.r[1] = ld32(0x060817B4u);  // 0608175A mov.l 0x060817B4,r1
    c.r[2] = c.r[3];  // 0608175C mov r3,r2
    c.r[1] = ld32(c.r[1]);  // 0608175E mov.l @r1,r1
    c.r[2] += c.r[2];  // 06081760 add r2,r2
    c.r[0] = c.r[1];  // 06081762 mov r1,r0
    c.r[1] += c.r[2];  // 06081764 add r2,r1
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06081766 mov.b @(r0,r2),r7
    c.r[1] += 1;  // 06081768 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0608176A mov.b @r1,r1
    c.r[7] &= c.r[13];  // 0608176C and r13,r7
    c.r[7] <<= 8;  // 0608176E shll8 r7
    c.r[10] = c.r[1] & 0xFFu;  // 06081770 extu.b r1,r10
    c.r[10] |= c.r[7];  // 06081772 or r7,r10
    c.r[1] = 0x1Eu;  // 06081774 mov #30,r1
    c.macl = c.r[10] * c.r[1];  // 06081776 mul.l r1,r10
    c.r[12] = ld32(0x060817C8u);  // 06081778 mov.l 0x060817C8,r12
    c.r[2] = ld32(c.r[12]);  // 0608177A mov.l @r12,r2
    c.r[9] = c.macl;  // 0608177C sts macl,r9
    c.r[2] += c.r[9];  // 0608177E add r9,r2
    c.r[1] = c.r[2];  // 06081780 mov r2,r1
    c.r[1] += 15;  // 06081782 add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06081784 mov.b @r1,r1
    c.r[0] = c.r[3];  // 06081786 mov r3,r0
    c.r[11] = c.r[1] & 0xFFu;  // 06081788 extu.b r1,r11
    c.r[1] = ld32(0x060817ACu);  // 0608178A mov.l 0x060817AC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0608178C mov.b @(r0,r1),r1
    c.r[8] = c.r[1] & 0xFFu;  // 0608178E extu.b r1,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 06081790 tst r8,r8
    if (!c.t) { goto L_060817D0; }  // 06081792 bf 0x060817D0
    c.r[6] = (uint32_t)(int16_t)ld16(0x060817A6u);  // 06081794 mov.w 0x060817A6,r6
    c.r[1] = ld32(0x060817CCu);  // 06081796 mov.l 0x060817CC,r1
    c.r[4] = ld32(c.r[1]);  // 06081798 mov.l @r1,r4
    c.r[1] = ld32(0x060817B8u);  // 0608179A mov.l 0x060817B8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060817A0u; c.r[5] = c.r[10] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060817A0u) return; }  // 0608179C jsr @r1 ; extu.b r10,r5
    goto L_060817EC;  // 060817A0 bra 0x060817EC ; nop
L_060817D0:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 060817D0 mov.w @r2,r1
    c.r[6] = (uint32_t)(int16_t)ld16(0x060818B4u);  // 060817D2 mov.w 0x060818B4,r6
    c.r[1] += c.r[8];  // 060817D4 add r8,r1
    st16(c.r[2], c.r[1]);  // 060817D6 mov.w r1,@r2
    c.r[1] = ld32(0x060818C0u);  // 060817D8 mov.l 0x060818C0,r1
    c.r[4] = ld32(c.r[1]);  // 060817DA mov.l @r1,r4
    c.r[1] = ld32(0x060818C4u);  // 060817DC mov.l 0x060818C4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060817E2u; c.r[5] = c.r[10] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060817E2u) return; }  // 060817DE jsr @r1 ; extu.b r10,r5
    c.r[2] = ld32(c.r[12]);  // 060817E2 mov.l @r12,r2
    c.r[2] += c.r[9];  // 060817E4 add r9,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 060817E6 mov.w @r2,r1
    c.r[1] -= c.r[8];  // 060817E8 sub r8,r1
    st16(c.r[2], c.r[1]);  // 060817EA mov.w r1,@r2
L_060817EC:
    c.r[8] = ld32(0x060818C0u);  // 060817EC mov.l 0x060818C0,r8
    c.r[9] = ld32(0x060818C8u);  // 060817EE mov.l 0x060818C8,r9
    c.r[1] = ld32(c.r[8]);  // 060817F0 mov.l @r8,r1
    c.r[5] = 0x0u;  // 060817F2 mov #0,r5
    c.r[1] += 34;  // 060817F4 add #34,r1
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060817F6 mov.w @r1,r6
    c.r[4] = 0x0u;  // 060817F8 mov #0,r4
    { const uint32_t x = c.r[9]; c.pr = 0x060817FEu; c.r[6] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060817FEu) return; }  // 060817FA jsr @r9 ; extu.w r6,r6
    c.r[1] = ld32(c.r[8]);  // 060817FE mov.l @r8,r1
    c.r[5] = 0x0u;  // 06081800 mov #0,r5
    c.r[1] += 30;  // 06081802 add #30,r1
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06081804 mov.w @r1,r6
    c.r[4] = 0x0u;  // 06081806 mov #0,r4
    { const uint32_t x = c.r[9]; c.pr = 0x0608180Cu; c.r[6] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608180Cu) return; }  // 06081808 jsr @r9 ; extu.w r6,r6
    c.r[1] = ld32(c.r[8]);  // 0608180C mov.l @r8,r1
    c.r[5] = 0x0u;  // 0608180E mov #0,r5
    c.r[1] += 32;  // 06081810 add #32,r1
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06081812 mov.w @r1,r6
    c.r[4] = 0x0u;  // 06081814 mov #0,r4
    { const uint32_t x = c.r[9]; c.pr = 0x0608181Au; c.r[6] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608181Au) return; }  // 06081816 jsr @r9 ; extu.w r6,r6
    c.r[5] = (uint32_t)(int16_t)ld16(0x060818B4u);  // 0608181A mov.w 0x060818B4,r5
    c.t = c.r[11] == c.r[5];  // 0608181C cmp/eq r5,r11
    if (c.t) { goto L_0608183A; }  // 0608181E bt 0x0608183A
    c.r[1] = ld32(0x060818CCu);  // 06081820 mov.l 0x060818CC,r1
    c.r[2] = ld32(c.r[1]);  // 06081822 mov.l @r1,r2
    c.r[1] = c.r[11];  // 06081824 mov r11,r1
    c.r[1] += c.r[1];  // 06081826 add r1,r1
    c.r[1] += c.r[11];  // 06081828 add r11,r1
    c.r[1] <<= 2;  // 0608182A shll2 r1
    c.r[0] = c.r[1];  // 0608182C mov r1,r0
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 0608182E mov.w @(r0,r2),r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x060818B6u);  // 06081830 mov.w 0x060818B6,r1
    c.r[4] += c.r[1];  // 06081832 add r1,r4
    c.r[1] = ld32(0x060818D0u);  // 06081834 mov.l 0x060818D0,r1
    c.r[4] = c.r[4] & 0xFFFFu; goto L_06081840;  // 06081836 bra 0x06081840 ; extu.w r4,r4
L_0608183A:
    c.r[4] = ld32(0x060818D4u);  // 0608183A mov.l 0x060818D4,r4
    c.r[1] = ld32(0x060818D0u);  // 0608183C mov.l 0x060818D0,r1
    c.r[5] = c.r[11];  // 0608183E mov r11,r5
L_06081840:
    { const uint32_t x = c.r[1]; c.pr = 0x06081844u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06081844u) return; }  // 06081840 jsr @r1 ; nop
    c.r[1] = ld32(0x060818D8u);  // 06081844 mov.l 0x060818D8,r1
    c.r[5] = 0x0u;  // 06081846 mov #0,r5
    c.r[2] = ld32(c.r[1]);  // 06081848 mov.l @r1,r2
    c.r[1] = c.r[2];  // 0608184A mov r2,r1
    c.r[1] += 10;  // 0608184C add #10,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0608184E mov.w @r1,r1
    c.r[2] += 12;  // 06081850 add #12,r2
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06081852 mov.b @r2,r6
    c.r[1] = c.r[1] & 0xFFFFu;  // 06081854 extu.w r1,r1
    c.r[1] <<= 8;  // 06081856 shll8 r1
    c.r[6] = c.r[6] & 0xFFu;  // 06081858 extu.b r6,r6
    c.r[6] |= c.r[1];  // 0608185A or r1,r6
    c.r[1] = ld32(0x060818C8u);  // 0608185C mov.l 0x060818C8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06081862u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06081862u) return; }  // 0608185E jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x060818DCu);  // 06081862 mov.l 0x060818DC,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060818B8u);  // 06081864 mov.w 0x060818B8,r0
    c.r[2] = 0x1u;  // 06081866 mov #1,r2
    c.r[7] = 0x2u;  // 06081868 mov #2,r7
    c.r[6] = 0x24u;  // 0608186A mov #36,r6
    c.r[1] = ld32(c.r[1]);  // 0608186C mov.l @r1,r1
    c.r[5] = 0x5u;  // 0608186E mov #5,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06081870 mov.b @(r0,r1),r1
    c.r[4] = 0x2u;  // 06081872 mov #2,r4
    c.r[1] = c.r[1] & 0xFFu;  // 06081874 extu.b r1,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06081876 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06081878 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 0608187A mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 0608187C mov.l r2,@-r15
    c.r[1] = 0x0u;  // 0608187E mov #0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06081880 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06081882 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06081884 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06081886 mov.l r1,@-r15
    c.r[1] = 0x7u;  // 06081888 mov #7,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0608188A mov.l r1,@-r15
    c.r[1] = ld32(0x060818E0u);  // 0608188C mov.l 0x060818E0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06081892u; c.r[15] -= 4; st32(c.r[15], c.r[2]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06081892u) return; }  // 0608188E jsr @r1 ; mov.l r2,@-r15
    c.r[15] += 40;  // 06081892 add #40,r15
    c.r[1] = ld32(0x060818E4u);  // 06081894 mov.l 0x060818E4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0608189Au; c.r[4] = 0x3Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608189Au) return; }  // 06081896 jsr @r1 ; mov #62,r4
    c.r[3] = (uint32_t)(int16_t)ld16(0x060818BAu);  // 0608189A mov.w 0x060818BA,r3
    c.r[14] += c.r[3];  // 0608189C add r3,r14
    c.r[15] = c.r[14];  // 0608189E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060818A0 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060818A2 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060818A4 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060818A6 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060818A8 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060818AA mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060818AC mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x060818BCu);  // 060818AE mov.w 0x060818BC,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060818B0 rts ; mov.l @r15+,r8
}

void f_060818E8(SH2Context& c) {
    ran[1814] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060818E8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060818EA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060818EC mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060818EE mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060818F0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060818F2 sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x06081A7Eu);  // 060818F4 mov.w 0x06081A7E,r3
    c.r[15] += c.r[3];  // 060818F6 add r3,r15
    c.r[14] = c.r[15];  // 060818F8 mov r15,r14
    c.r[0] = 0x0u;  // 060818FA mov #0,r0
    st32(c.r[14], c.r[0]);  // 060818FC mov.l r0,@r14
    st8(c.r[14] + 4, c.r[0]);  // 060818FE mov.b r0,@(4,r14)
    c.r[3] = ld32(0x06081A8Cu);  // 06081900 mov.l 0x06081A8C,r3
    c.r[2] = c.r[3];  // 06081902 mov r3,r2
    c.r[2] += 112;  // 06081904 add #112,r2
    c.r[1] = 0x47u;  // 06081906 mov #71,r1
    st16(c.r[2], c.r[1]);  // 06081908 mov.w r1,@r2
    c.r[3] += 114;  // 0608190A add #114,r3
    c.r[1] = 0xFFFFFFCFu;  // 0608190C mov #-49,r1
    st16(c.r[3], c.r[1]);  // 0608190E mov.w r1,@r3
    c.r[1] = ld32(0x06081A90u);  // 06081910 mov.l 0x06081A90,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06081916u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06081916u) return; }  // 06081912 jsr @r1 ; mov #0,r4
    c.r[8] = ld32(0x06081A94u);  // 06081916 mov.l 0x06081A94,r8
    c.r[2] = ld32(c.r[8]);  // 06081918 mov.l @r8,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06081A80u);  // 0608191A mov.w 0x06081A80,r1
    c.r[0] = c.r[2];  // 0608191C mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0608191E mov.b @(r0,r1),r1
    c.r[1] >>= 2;  // 06081920 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06081922 shlr r1
    c.r[0] = 0x1u;  // 06081924 mov #1,r0
    c.r[1] &= c.r[0];  // 06081926 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06081928 tst r1,r1
    { const bool k = c.t; c.r[6] = 0x2u; if (k) { goto L_06081966; } }  // 0608192A bt/s 0x06081966 ; mov #2,r6
    c.r[1] = ld32(0x06081A98u);  // 0608192E mov.l 0x06081A98,r1
    c.r[1] = ld32(c.r[1]);  // 06081930 mov.l @r1,r1
    c.r[1] += 18;  // 06081932 add #18,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06081934 mov.w @r1,r4
    c.r[0] = ld32(0x06081A9Cu);  // 06081936 mov.l 0x06081A9C,r0
    c.r[4] <<= 16;  // 06081938 shll16 r4
    c.r[4] <<= 2;  // 0608193A shll2 r4
    c.r[4] += c.r[4];  // 0608193C add r4,r4
    c.r[4] <<= 2;  // 0608193E shll2 r4
    c.r[4] >>= 16;  // 06081940 shlr16 r4
    c.r[4] <<= 2;  // 06081942 shll2 r4
    { const uint32_t x = c.r[0]; c.pr = 0x06081948u; c.r[4] >>= 8; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06081948u) return; }  // 06081944 jsr @r0 ; shlr8 r4
    c.r[3] = c.r[0];  // 06081948 mov r0,r3
    c.r[2] = (uint32_t)(int16_t)ld16(0x06081A82u);  // 0608194A mov.w 0x06081A82,r2
    c.r[6] = 0x2u;  // 0608194C mov #2,r6
    c.r[1] = ld32(c.r[8]);  // 0608194E mov.l @r8,r1
    c.r[5] = 0x14u;  // 06081950 mov #20,r5
    c.r[0] = c.r[1];  // 06081952 mov r1,r0
    c.r[7] = ld32(c.r[0] + c.r[2]);  // 06081954 mov.l @(r0,r2),r7
    c.r[4] = 0x0u;  // 06081956 mov #0,r4
    c.r[7] <<= 8;  // 06081958 shll8 r7
    c.r[7] += c.r[7];  // 0608195A add r7,r7
    c.r[7] >>= 16;  // 0608195C shlr16 r7
    c.r[7] += c.r[7];  // 0608195E add r7,r7
    c.r[7] >>= 8;  // 06081960 shlr8 r7
    c.r[1] = c.r[3] & 0xFFu; goto L_06081978;  // 06081962 bra 0x06081978 ; extu.b r3,r1
L_06081966:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06081A82u);  // 06081966 mov.w 0x06081A82,r0
    c.r[7] = ld32(c.r[0] + c.r[2]);  // 06081968 mov.l @(r0,r2),r7
    c.r[5] = 0x14u;  // 0608196A mov #20,r5
    c.r[4] = 0x0u;  // 0608196C mov #0,r4
    c.r[7] <<= 8;  // 0608196E shll8 r7
    c.r[7] += c.r[7];  // 06081970 add r7,r7
    c.r[7] >>= 16;  // 06081972 shlr16 r7
    c.r[7] += c.r[7];  // 06081974 add r7,r7
    c.r[7] >>= 8;  // 06081976 shlr8 r7
L_06081978:
    c.r[0] = ld32(0x06081AA0u);  // 06081978 mov.l 0x06081AA0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0608197Eu; c.r[15] -= 4; st32(c.r[15], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608197Eu) return; }  // 0608197A jsr @r0 ; mov.l r1,@-r15
    c.r[15] += 4;  // 0608197E add #4,r15
    c.r[1] = ld32(0x06081AA4u);  // 06081980 mov.l 0x06081AA4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06081986u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06081986u) return; }  // 06081982 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06081AA8u);  // 06081986 mov.l 0x06081AA8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0608198Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608198Cu) return; }  // 06081988 jsr @r1 ; nop
    c.r[9] = ld32(0x06081AACu);  // 0608198C mov.l 0x06081AAC,r9
    c.r[4] = (uint32_t)(int16_t)ld16(0x06081A84u);  // 0608198E mov.w 0x06081A84,r4
    c.r[1] = 0xAu;  // 06081990 mov #10,r1
    c.r[6] = 0xFu;  // 06081992 mov #15,r6
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06081994 mov.b @r9,r7
    c.r[5] = 0x1u;  // 06081996 mov #1,r5
    c.r[7] += 18;  // 06081998 add #18,r7
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0608199A mov.l r1,@-r15
    c.r[1] = ld32(0x06081AB0u);  // 0608199C mov.l 0x06081AB0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060819A2u; c.r[7] = c.r[7] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060819A2u) return; }  // 0608199E jsr @r1 ; extu.b r7,r7
    c.r[8] = ld32(0x06081AB4u);  // 060819A2 mov.l 0x06081AB4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060819A8u; c.r[4] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060819A8u) return; }  // 060819A4 jsr @r8 ; mov #2,r4
    { const uint32_t x = c.r[8]; c.pr = 0x060819ACu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060819ACu) return; }  // 060819A8 jsr @r8 ; mov #1,r4
    c.pr = 0x060819B0u; c.r[15] += 4; SH2_POLL(c); sh2_call(c, 0x060819B8u); if (c.pc != 0x060819B0u) return;  // 060819AC bsr 0x060819B8 ; add #4,r15
    c.r[11] = c.r[0];  // 060819B0 mov r0,r11
    c.r[3] = 0x0u;  // 060819B2 mov #0,r3
    goto L_060819DC;  // 060819B4 bra 0x060819DC ; nop
L_060819DC:
    c.r[11] |= c.r[3];  // 060819DC or r3,r11
    c.r[0] = ld32(0x060819E8u);  // 060819DE mov.l 0x060819E8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060819E4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060819E4u) return; }  // 060819E0 jsr @r0 ; nop
    goto L_06081D38;  // 060819E4 bra 0x06081D38 ; nop
L_06081D38:
    c.r[1] = ld32(0x06081EB0u);  // 06081D38 mov.l 0x06081EB0,r1
    c.r[1] = ld32(c.r[1]);  // 06081D3A mov.l @r1,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06081D3C mov.w @r1,r4
    c.r[5] = 0xFFFFFFFFu;  // 06081D3E mov #-1,r5
    c.r[5] = c.r[5] & 0xFFu;  // 06081D40 extu.b r5,r5
    c.r[1] = 0xFFFFFFEFu;  // 06081D42 mov #-17,r1
    c.r[1] <<= 8;  // 06081D44 shll8 r1
    c.r[4] += c.r[1];  // 06081D46 add r1,r4
    c.r[1] = ld32(0x06081EB4u);  // 06081D48 mov.l 0x06081EB4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06081D4Eu; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06081D4Eu) return; }  // 06081D4A jsr @r1 ; extu.w r4,r4
    c.r[1] = ld32(0x06081EB8u);  // 06081D4E mov.l 0x06081EB8,r1
    c.r[8] = ld32(0x06081EBCu);  // 06081D50 mov.l 0x06081EBC,r8
    c.r[5] = 0x0u;  // 06081D52 mov #0,r5
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06081D54 mov.b @r1,r6
    c.r[4] = 0x0u;  // 06081D56 mov #0,r4
    { const uint32_t x = c.r[8]; c.pr = 0x06081D5Cu; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06081D5Cu) return; }  // 06081D58 jsr @r8 ; extu.b r6,r6
    c.r[1] = ld32(0x06081EC0u);  // 06081D5C mov.l 0x06081EC0,r1
    c.r[5] = 0x0u;  // 06081D5E mov #0,r5
    c.r[2] = ld32(c.r[1]);  // 06081D60 mov.l @r1,r2
    c.r[4] = 0x0u;  // 06081D62 mov #0,r4
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[2] + 10);  // 06081D64 mov.w @(10,r2),r0
    c.r[1] = c.r[0] & 0xFFFFu;  // 06081D66 extu.w r0,r1
    c.r[1] <<= 8;  // 06081D68 shll8 r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2] + 12);  // 06081D6A mov.b @(12,r2),r0
    c.r[6] = c.r[0] & 0xFFu;  // 06081D6C extu.b r0,r6
    { const uint32_t x = c.r[8]; c.pr = 0x06081D72u; c.r[6] |= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06081D72u) return; }  // 06081D6E jsr @r8 ; or r1,r6
    c.r[1] = ld32(0x06081EC4u);  // 06081D72 mov.l 0x06081EC4,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06081D74 mov.b @r1,r0
    c.r[0] = c.r[0] & 0xFFu;  // 06081D76 extu.b r0,r0
    c.r[1] = ld32(0x06081EC8u);  // 06081D78 mov.l 0x06081EC8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06081D7A mov.b @(r0,r1),r1
    c.pr = 0x06081D80u; c.r[2] = c.r[1] & 0xFFu; SH2_POLL(c); sh2_call(c, 0x06081C38u); if (c.pc != 0x06081D80u) return;  // 06081D7C bsr 0x06081C38 ; extu.b r1,r2
    { const uint32_t x = c.r[8]; c.pr = 0x06081D84u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06081D84u) return; }  // 06081D80 jsr @r8 ; nop
    c.r[0] = 0x06081DC8u;  // 06081D84 mova 0x06081DC8,r0
    c.r[10] = c.r[0];  // 06081D86 mov r0,r10
    c.r[9] = 0x0u;  // 06081D88 mov #0,r9
L_06081D8A:
    c.r[1] = ld32(0x06081EB0u);  // 06081D8A mov.l 0x06081EB0,r1
    c.r[1] = ld32(c.r[1]);  // 06081D8C mov.l @r1,r1
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[10]); c.r[10] += 1;  // 06081D8E mov.b @r10+,r11
    c.r[1] += c.r[11];  // 06081D90 add r11,r1
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06081D92 mov.w @r1,r6
    c.r[5] = 0x0u;  // 06081D94 mov #0,r5
    c.r[4] = 0x0u;  // 06081D96 mov #0,r4
    { const uint32_t x = c.r[8]; c.pr = 0x06081D9Cu; c.r[6] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06081D9Cu) return; }  // 06081D98 jsr @r8 ; extu.w r6,r6
    c.r[0] = c.r[14];  // 06081D9C mov r14,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 06081D9E mov.b @(r0,r9),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06081DA0 tst r1,r1
    { const bool k = !c.t; c.r[1] = c.r[14]; if (k) { goto L_06081DB2; } }  // 06081DA2 bf/s 0x06081DB2 ; mov r14,r1
    c.r[1] += c.r[11];  // 06081DA6 add r11,r1
    c.r[1] += 8;  // 06081DA8 add #8,r1
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06081DAA mov.w @r1,r6
    c.r[4] = 0x0u;  // 06081DAC mov #0,r4
    c.r[6] = c.r[6] & 0xFFFFu; goto L_06081DB6;  // 06081DAE bra 0x06081DB6 ; extu.w r6,r6
L_06081DB2:
    c.r[6] = 0x0u;  // 06081DB2 mov #0,r6
    c.r[4] = 0x50u;  // 06081DB4 mov #80,r4
L_06081DB6:
    { const uint32_t x = c.r[8]; c.pr = 0x06081DBAu; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06081DBAu) return; }  // 06081DB6 jsr @r8 ; mov #0,r5
    c.r[9] += 1;  // 06081DBA add #1,r9
    c.r[0] = 0x5u;  // 06081DBC mov #5,r0
    c.t = c.r[9] >= c.r[0];  // 06081DBE cmp/hs r0,r9
    if (!c.t) { SH2_POLL(c); goto L_06081D8A; }  // 06081DC0 bf 0x06081D8A
    goto L_06081F48;  // 06081DC2 bra 0x06081F48 ; nop
L_06081F48:
    c.r[3] = 0x5u;  // 06081F48 mov #5,r3
    c.r[15] -= 4; st32(c.r[15], c.r[3]);  // 06081F4A mov.l r3,@-r15
    c.r[2] = 0x1u;  // 06081F4C mov #1,r2
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06081F4E mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06081F50 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06081F52 mov.l r2,@-r15
    c.r[1] = 0x0u;  // 06081F54 mov #0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06081F56 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06081F58 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06081F5A mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06081F5C mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[3]);  // 06081F5E mov.l r3,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06081F60 mov.l r2,@-r15
    c.r[1] = ld32(0x06081F98u);  // 06081F62 mov.l 0x06081F98,r1
    c.r[7] = 0x2u;  // 06081F64 mov #2,r7
    c.r[6] = 0xAu;  // 06081F66 mov #10,r6
    c.r[5] = 0x10u;  // 06081F68 mov #16,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06081F6Eu; c.r[4] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06081F6Eu) return; }  // 06081F6A jsr @r1 ; mov #2,r4
    c.r[15] += 40;  // 06081F6E add #40,r15
    c.r[1] = ld32(0x06081F9Cu);  // 06081F70 mov.l 0x06081F9C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06081F76u; c.r[4] = 0x3Fu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06081F76u) return; }  // 06081F72 jsr @r1 ; mov #63,r4
    c.r[3] = (uint32_t)(int16_t)ld16(0x06081F8Cu);  // 06081F76 mov.w 0x06081F8C,r3
    c.r[14] += c.r[3];  // 06081F78 add r3,r14
    c.r[15] = c.r[14];  // 06081F7A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06081F7C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06081F7E mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06081F80 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06081F82 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06081F84 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06081F8Eu);  // 06081F86 mov.w 0x06081F8E,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06081F88 rts ; mov.l @r15+,r8
}

void f_060819B8(SH2Context& c) {
    ran[1815] = 1;
    c.r[1] = ld32(0x06081AB8u);  // 060819B8 mov.l 0x06081AB8,r1
    c.r[1] = ld32(c.r[1]);  // 060819BA mov.l @r1,r1
    c.r[2] = ld32(0x06081ABCu);  // 060819BC mov.l 0x06081ABC,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060819BE mov.b @r2,r2
    c.r[2] = c.r[2] & 0xFFu;  // 060819C0 extu.b r2,r2
    c.r[2] += c.r[2];  // 060819C2 add r2,r2
    c.r[1] += c.r[2];  // 060819C4 add r2,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 060819C6 mov.b @r1+,r0
    c.r[2] = 0x7Fu;  // 060819C8 mov #127,r2
    c.r[0] &= c.r[2];  // 060819CA and r2,r0
    c.r[0] <<= 8;  // 060819CC shll8 r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060819CE mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 060819D0 extu.b r2,r2
    { const uint32_t x = c.pr; c.r[0] |= c.r[2]; c.pc = x; return; }  // 060819D2 rts ; or r2,r0
}

void f_06081AC4(SH2Context& c) {
    ran[1816] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06081AC4 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06081AC6 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06081AC8 sts.l pr,@-r15
    c.r[1] = ld32(0x06081BECu);  // 06081ACA mov.l 0x06081BEC,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1] + 13);  // 06081ACC mov.b @(13,r1),r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 06081ACE cmp/eq #-1,r0
    if (c.t) { goto L_06081ADA; }  // 06081AD0 bt 0x06081ADA
    c.r[2] = ld32(0x06081BF0u);  // 06081AD2 mov.l 0x06081BF0,r2
    st8(c.r[2], c.r[0]);  // 06081AD4 mov.b r0,@r2
    c.r[0] = 0xFFFFFFFFu;  // 06081AD6 mov #-1,r0
    st8(c.r[1] + 13, c.r[0]);  // 06081AD8 mov.b r0,@(13,r1)
L_06081ADA:
    c.r[13] = 0x0u;  // 06081ADA mov #0,r13
L_06081ADC:
    c.pr = 0x06081AE0u; c.r[4] = c.r[13]; SH2_POLL(c); sh2_call(c, 0x06081B86u); if (c.pc != 0x06081AE0u) return;  // 06081ADC bsr 0x06081B86 ; mov r13,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06081AE0 mov.b @r9,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06081AE2 extu.b r1,r1
    c.t = c.r[0] >= c.r[1];  // 06081AE4 cmp/hs r1,r0
    if (!c.t) { goto L_06081AF2; }  // 06081AE6 bf 0x06081AF2
    c.r[1] = c.r[14];  // 06081AE8 mov r14,r1
    c.r[1] += c.r[13];  // 06081AEA add r13,r1
    c.r[2] = 0x1u;  // 06081AEC mov #1,r2
    st8(c.r[1], c.r[2]); goto L_06081B0C;  // 06081AEE bra 0x06081B0C ; mov.b r2,@r1
L_06081AF2:
    c.r[12] = c.r[0];  // 06081AF2 mov r0,r12
    c.r[6] = c.r[1];  // 06081AF4 mov r1,r6
    c.pr = 0x06081AFAu; c.r[4] = c.r[13]; SH2_POLL(c); sh2_call(c, 0x06081BA6u); if (c.pc != 0x06081AFAu) return;  // 06081AF6 bsr 0x06081BA6 ; mov r13,r4
    c.r[5] = c.r[12];  // 06081AFA mov r12,r5
    c.r[5] += c.r[0];  // 06081AFC add r0,r5
    c.t = c.r[5] > c.r[6];  // 06081AFE cmp/hi r6,r5
    if (!c.t) { goto L_06081B04; }  // 06081B00 bf 0x06081B04
    c.r[5] = c.r[6];  // 06081B02 mov r6,r5
L_06081B04:
    c.r[4] = c.r[13];  // 06081B04 mov r13,r4
    c.r[0] = ld32(0x06081BF4u);  // 06081B06 mov.l 0x06081BF4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06081B0Cu; c.r[6] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06081B0Cu) return; }  // 06081B08 jsr @r0 ; mov r11,r6
L_06081B0C:
    c.r[13] += 1;  // 06081B0C add #1,r13
    c.r[0] = 0x5u;  // 06081B0E mov #5,r0
    c.t = c.r[13] >= c.r[0];  // 06081B10 cmp/hs r0,r13
    if (!c.t) { SH2_POLL(c); goto L_06081ADC; }  // 06081B12 bf 0x06081ADC
    c.r[4] = c.r[14];  // 06081B14 mov r14,r4
    c.r[4] += 8;  // 06081B16 add #8,r4
    c.r[5] = c.r[11] & 0xFFu;  // 06081B18 extu.b r11,r5
    c.r[6] = (uint32_t)(int16_t)ld16(0x06081C14u);  // 06081B1A mov.w 0x06081C14,r6
    c.r[0] = ld32(0x06081BF8u);  // 06081B1C mov.l 0x06081BF8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06081B22u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06081B22u) return; }  // 06081B1E jsr @r0 ; nop
    c.r[13] = 0x0u;  // 06081B22 mov #0,r13
L_06081B24:
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06081B24 mov.b @r9,r4
    c.r[4] = c.r[4] & 0xFFu;  // 06081B26 extu.b r4,r4
    c.r[0] = ld32(0x06081BFCu);  // 06081B28 mov.l 0x06081BFC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06081B2Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06081B2Eu) return; }  // 06081B2A jsr @r0 ; nop
    c.pr = 0x06081B32u; c.r[4] = c.r[13]; SH2_POLL(c); sh2_call(c, 0x06081B86u); if (c.pc != 0x06081B32u) return;  // 06081B2E bsr 0x06081B86 ; mov r13,r4
    c.r[12] = c.r[0];  // 06081B32 mov r0,r12
    c.r[4] = c.r[13];  // 06081B34 mov r13,r4
    c.pr = 0x06081B3Au; SH2_POLL(c); sh2_call(c, 0x06081BA6u); if (c.pc != 0x06081B3Au) return;  // 06081B36 bsr 0x06081BA6 ; nop
    c.r[0] += c.r[12];  // 06081B3A add r12,r0
    c.r[10] = c.r[0];  // 06081B3C mov r0,r10
    c.r[8] = 0x0u;  // 06081B3E mov #0,r8
L_06081B40:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06081B40 mov.b @r9,r0
    c.r[0] = c.r[0] & 0xFFu;  // 06081B42 extu.b r0,r0
    c.t = c.r[8] >= c.r[0];  // 06081B44 cmp/hs r0,r8
    if (c.t) { goto L_06081B76; }  // 06081B46 bt 0x06081B76
    c.t = c.r[8] >= c.r[12];  // 06081B48 cmp/hs r12,r8
    if (c.t) { goto L_06081B50; }  // 06081B4A bt 0x06081B50
    c.r[4] = 0x33u; goto L_06081B60;  // 06081B4C bra 0x06081B60 ; mov #51,r4
L_06081B50:
    c.t = c.r[8] >= c.r[10];  // 06081B50 cmp/hs r10,r8
    if (c.t) { goto L_06081B5E; }  // 06081B52 bt 0x06081B5E
    c.pr = 0x06081B58u; SH2_POLL(c); sh2_call(c, 0x06081BD8u); if (c.pc != 0x06081B58u) return;  // 06081B54 bsr 0x06081BD8 ; nop
    c.r[4] = 0xFFFFFFE0u;  // 06081B58 mov #-32,r4
    c.r[4] = c.r[4] & 0xFFu; goto L_06081B60;  // 06081B5A bra 0x06081B60 ; extu.b r4,r4
L_06081B5E:
    c.r[4] = 0x31u;  // 06081B5E mov #49,r4
L_06081B60:
    c.r[15] -= 4; st32(c.r[15], c.r[4]);  // 06081B60 mov.l r4,@-r15
    c.r[0] = ld32(0x06081BFCu);  // 06081B62 mov.l 0x06081BFC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06081B68u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06081B68u) return; }  // 06081B64 jsr @r0 ; nop
    c.r[4] = ld32(c.r[15]); c.r[15] += 4;  // 06081B68 mov.l @r15+,r4
    c.r[4] += 1;  // 06081B6A add #1,r4
    c.r[0] = ld32(0x06081BFCu);  // 06081B6C mov.l 0x06081BFC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06081B72u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06081B72u) return; }  // 06081B6E jsr @r0 ; nop
    c.r[8] += 1; SH2_POLL(c); goto L_06081B40;  // 06081B72 bra 0x06081B40 ; add #1,r8
L_06081B76:
    c.r[13] += 1;  // 06081B76 add #1,r13
    c.r[0] = 0x5u;  // 06081B78 mov #5,r0
    c.t = c.r[13] >= c.r[0];  // 06081B7A cmp/hs r0,r13
    if (!c.t) { SH2_POLL(c); goto L_06081B24; }  // 06081B7C bf 0x06081B24
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06081B7E lds.l @r15+,pr
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06081B80 mov.l @r15+,r13
    { const uint32_t x = c.pr; c.r[12] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06081B82 rts ; mov.l @r15+,r12
}

void f_06081B86(SH2Context& c) {
    ran[1817] = 1;
    c.r[1] = ld32(0x06081C00u);  // 06081B86 mov.l 0x06081C00,r1
    c.r[1] += c.r[4];  // 06081B88 add r4,r1
    c.r[1] += c.r[4];  // 06081B8A add r4,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 06081B8C mov.b @r1+,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06081B8E mov.b @r1,r3
    c.r[1] = ld32(0x06081C04u);  // 06081B90 mov.l 0x06081C04,r1
    c.r[1] = ld32(c.r[1]);  // 06081B92 mov.l @r1,r1
    c.r[1] += c.r[2];  // 06081B94 add r2,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06081B96 mov.b @r1,r0
    c.r[0] = c.r[0] & 0xFFu;  // 06081B98 extu.b r0,r0
    c.t = (c.r[3] & c.r[3]) == 0;  // 06081B9A tst r3,r3
    if (c.t) { goto L_06081BA2; }  // 06081B9C bt 0x06081BA2
    c.r[0] >>= 2;  // 06081B9E shlr2 r0
    c.r[0] >>= 2;  // 06081BA0 shlr2 r0
L_06081BA2:
    { const uint32_t x = c.pr; c.r[0] &= 0xFu; c.pc = x; return; }  // 06081BA2 rts ; and #15,r0
}

void f_06081BA6(SH2Context& c) {
    ran[1818] = 1;
    c.r[1] = ld32(0x06081BECu);  // 06081BA6 mov.l 0x06081BEC,r1
    c.r[1] += c.r[4];  // 06081BA8 add r4,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06081BAA mov.b @r1,r0
    c.r[0] = c.r[0] & 0xFFu;  // 06081BAC extu.b r0,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06081BAE tst r0,r0
    if (!c.t) { goto L_06081BD4; }  // 06081BB0 bf 0x06081BD4
    c.r[15] -= 4; st32(c.r[15], c.r[4]);  // 06081BB2 mov.l r4,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06081BB4 sts.l pr,@-r15
    c.r[0] = ld32(0x06081C08u);  // 06081BB6 mov.l 0x06081C08,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06081BBCu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06081BBCu) return; }  // 06081BB8 jsr @r0 ; nop
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06081BBC lds.l @r15+,pr
    c.r[4] = ld32(c.r[15]); c.r[15] += 4;  // 06081BBE mov.l @r15+,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 06081BC0 tst r0,r0
    if (!c.t) { goto L_06081BD2; }  // 06081BC2 bf 0x06081BD2
    c.r[1] = ld32(0x06081BF0u);  // 06081BC4 mov.l 0x06081BF0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06081BC6 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06081BC8 extu.b r1,r1
    c.t = c.r[1] == c.r[4];  // 06081BCA cmp/eq r4,r1
    if (!c.t) { goto L_06081BD2; }  // 06081BCC bf 0x06081BD2
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 06081BCE rts ; mov #1,r0
L_06081BD2:
    c.r[0] = 0x0u;  // 06081BD2 mov #0,r0
L_06081BD4:
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06081BD4 rts ; nop
}

void f_06081BD8(SH2Context& c) {
    ran[1819] = 1;
    c.r[0] = ld32(0x06081C0Cu);  // 06081BD8 mov.l 0x06081C0C,r0
    c.r[2] = ld32(0x06081C10u);  // 06081BDA mov.l 0x06081C10,r2
    c.r[3] = 0x10u;  // 06081BDC mov #16,r3
L_06081BDE:
    c.r[1] = ld32(c.r[0]); c.r[0] += 4;  // 06081BDE mov.l @r0+,r1
    st32(c.r[2], c.r[1]);  // 06081BE0 mov.l r1,@r2
    c.r[3] -= 1; c.t = c.r[3] == 0;  // 06081BE2 dt r3
    { const bool k = !c.t; c.r[2] += 4; if (k) { SH2_POLL(c); goto L_06081BDE; } }  // 06081BE4 bf/s 0x06081BDE ; add #4,r2
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06081BE8 rts ; nop
}

void f_06081C16(SH2Context& c) {
    ran[1820] = 1;
L_06081C16:
    c.r[1] = ld32(0x06081C30u);  // 06081C16 mov.l 0x06081C30,r1
L_06081C18:
    c.r[0] = 0x0u;  // 06081C18 mov #0,r0
L_06081C1A:
    st32(c.r[1], c.r[0]);  // 06081C1A mov.l r0,@r1
L_06081C1C:
    st8(c.r[1] + 4, c.r[0]);  // 06081C1C mov.b r0,@(4,r1)
L_06081C1E:
    c.r[0] = 0x1u;  // 06081C1E mov #1,r0
L_06081C20:
    st8(c.r[1] + 5, c.r[0]);  // 06081C20 mov.b r0,@(5,r1)
L_06081C22:
    st8(c.r[1] + 6, c.r[0]);  // 06081C22 mov.b r0,@(6,r1)
L_06081C24:
    st8(c.r[1] + 7, c.r[0]);  // 06081C24 mov.b r0,@(7,r1)
L_06081C26:
    st8(c.r[1] + 8, c.r[0]);  // 06081C26 mov.b r0,@(8,r1)
L_06081C28:
    st8(c.r[1] + 9, c.r[0]);  // 06081C28 mov.b r0,@(9,r1)
L_06081C2A:
    c.r[0] = ld32(0x06081C34u);  // 06081C2A mov.l 0x06081C34,r0
L_06081C2C:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x06081C16u: goto L_06081C16; case 0x06081C18u: goto L_06081C18; case 0x06081C1Au: goto L_06081C1A; case 0x06081C1Cu: goto L_06081C1C; case 0x06081C1Eu: goto L_06081C1E; case 0x06081C20u: goto L_06081C20; case 0x06081C22u: goto L_06081C22; case 0x06081C24u: goto L_06081C24; case 0x06081C26u: goto L_06081C26; case 0x06081C28u: goto L_06081C28; case 0x06081C2Au: goto L_06081C2A; case 0x06081C2Cu: goto L_06081C2C; default: sh2_call(c, x); return; } }  // 06081C2C jmp @r0 ; nop
}

void f_06081C38(SH2Context& c) {
    ran[1821] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06081C38 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06081C3A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06081C3C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06081C3E sts.l pr,@-r15
    c.pr = 0x06081C44u; c.r[9] = c.r[2]; SH2_POLL(c); sh2_call(c, 0x06081C9Au); if (c.pc != 0x06081C44u) return;  // 06081C40 bsr 0x06081C9A ; mov r2,r9
    c.t = (c.r[0] & c.r[0]) == 0;  // 06081C44 tst r0,r0
    if (c.t) { goto L_06081C70; }  // 06081C46 bt 0x06081C70
    c.r[10] = 0x0u;  // 06081C48 mov #0,r10
    c.r[8] = 0x0u;  // 06081C4A mov #0,r8
L_06081C4C:
    c.r[0] = ld32(0x06081CFCu);  // 06081C4C mov.l 0x06081CFC,r0
    c.r[0] += c.r[8];  // 06081C4E add r8,r0
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06081C50 mov.b @r0,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06081C52 tst r0,r0
    if (c.t) { goto L_06081C62; }  // 06081C54 bt 0x06081C62
    c.r[4] = c.r[11];  // 06081C56 mov r11,r4
    c.r[5] = c.r[8];  // 06081C58 mov r8,r5
    c.r[0] = ld32(0x06081D00u);  // 06081C5A mov.l 0x06081D00,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06081C60u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06081C60u) return; }  // 06081C5C jsr @r0 ; nop
    c.r[10] += c.r[0];  // 06081C60 add r0,r10
L_06081C62:
    c.r[8] += 1;  // 06081C62 add #1,r8
    c.r[0] = 0x5u;  // 06081C64 mov #5,r0
    c.t = c.r[8] >= c.r[0];  // 06081C66 cmp/hs r0,r8
    if (!c.t) { SH2_POLL(c); goto L_06081C4C; }  // 06081C68 bf 0x06081C4C
    c.r[6] = c.r[10];  // 06081C6A mov r10,r6
    c.r[4] = 0x0u; goto L_06081C8E;  // 06081C6C bra 0x06081C8E ; mov #0,r4
L_06081C70:
    c.r[0] = c.r[14];  // 06081C70 mov r14,r0
    c.r[0] += c.r[9];  // 06081C72 add r9,r0
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06081C74 mov.b @r0,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06081C76 tst r0,r0
    if (!c.t) { goto L_06081C8A; }  // 06081C78 bf 0x06081C8A
    c.r[4] = c.r[11];  // 06081C7A mov r11,r4
    c.r[5] = c.r[9];  // 06081C7C mov r9,r5
    c.r[0] = ld32(0x06081D00u);  // 06081C7E mov.l 0x06081D00,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06081C84u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06081C84u) return; }  // 06081C80 jsr @r0 ; nop
    c.r[6] = c.r[0];  // 06081C84 mov r0,r6
    c.r[4] = 0x0u; goto L_06081C8E;  // 06081C86 bra 0x06081C8E ; mov #0,r4
L_06081C8A:
    c.r[6] = 0x0u;  // 06081C8A mov #0,r6
    c.r[4] = 0x70u;  // 06081C8C mov #112,r4
L_06081C8E:
    c.r[5] = 0x0u;  // 06081C8E mov #0,r5
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06081C90 lds.l @r15+,pr
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06081C92 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06081C94 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06081C96 rts ; mov.l @r15+,r8
}

void f_06081C9A(SH2Context& c) {
    ran[1822] = 1;
    c.r[2] = ld32(0x06081CFCu);  // 06081C9A mov.l 0x06081CFC,r2
    c.r[0] = 0x0u;  // 06081C9C mov #0,r0
    c.r[3] = 0x0u;  // 06081C9E mov #0,r3
    c.r[1] = 0xFFFFFFFFu;  // 06081CA0 mov #-1,r1
L_06081CA2:
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[2]); c.r[2] += 1;  // 06081CA2 mov.b @r2+,r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 06081CA4 tst r4,r4
    if (c.t) { goto L_06081CAC; }  // 06081CA6 bt 0x06081CAC
    c.r[0] += 1;  // 06081CA8 add #1,r0
    c.r[1] = c.r[3];  // 06081CAA mov r3,r1
L_06081CAC:
    c.r[3] += 1;  // 06081CAC add #1,r3
    c.r[4] = 0x5u;  // 06081CAE mov #5,r4
    c.t = c.r[3] >= c.r[4];  // 06081CB0 cmp/hs r4,r3
    if (!c.t) { SH2_POLL(c); goto L_06081CA2; }  // 06081CB2 bf 0x06081CA2
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06081CB4 rts ; nop
}

void f_06081CB8(SH2Context& c) {
    ran[1823] = 1;
    c.r[1] = ld32(0x06081D04u);  // 06081CB8 mov.l 0x06081D04,r1
    c.r[1] = ld32(c.r[1]);  // 06081CBA mov.l @r1,r1
    c.r[2] = 0x1Eu;  // 06081CBC mov #30,r2
    c.macl = (c.r[6] & 0xFFFFu) * (c.r[2] & 0xFFFFu);  // 06081CBE mulu.w r2,r6
    c.r[2] = c.macl;  // 06081CC0 sts macl,r2
    c.r[1] += c.r[2];  // 06081CC2 add r2,r1
    c.r[0] = ld32(0x06081D08u);  // 06081CC4 mov.l 0x06081D08,r0
    c.r[0] += c.r[4];  // 06081CC6 add r4,r0
    c.r[0] += c.r[4];  // 06081CC8 add r4,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0]); c.r[0] += 1;  // 06081CCA mov.b @r0+,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06081CCC mov.b @r0,r3
    c.r[1] += c.r[2];  // 06081CCE add r2,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06081CD0 mov.b @r1,r0
    c.r[0] = c.r[0] & 0xFFu;  // 06081CD2 extu.b r0,r0
    c.r[0] <<= 8;  // 06081CD4 shll8 r0
    c.r[2] = c.r[1];  // 06081CD6 mov r1,r2
    c.r[2] += 1;  // 06081CD8 add #1,r2
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06081CDA mov.b @r2,r7
    c.r[7] = c.r[7] & 0xFFu;  // 06081CDC extu.b r7,r7
    c.r[0] |= c.r[7];  // 06081CDE or r7,r0
    c.r[7] = 0xFu;  // 06081CE0 mov #15,r7
    c.r[5] &= c.r[7];  // 06081CE2 and r7,r5
L_06081CE4:
    c.t = c.r[7] >> 31; c.r[7] <<= 1;  // 06081CE4 shll r7
    c.t = c.r[5] >> 31; c.r[5] <<= 1;  // 06081CE6 shll r5
    c.r[3] -= 1; c.t = c.r[3] == 0;  // 06081CE8 dt r3
    if (!c.t) { SH2_POLL(c); goto L_06081CE4; }  // 06081CEA bf 0x06081CE4
    c.r[7] = ~c.r[7];  // 06081CEC not r7,r7
    c.r[0] &= c.r[7];  // 06081CEE and r7,r0
    c.r[0] |= c.r[5];  // 06081CF0 or r5,r0
    st8(c.r[2], c.r[0]);  // 06081CF2 mov.b r0,@r2
    c.r[0] >>= 8;  // 06081CF4 shlr8 r0
    { const uint32_t x = c.pr; st8(c.r[1], c.r[0]); c.pc = x; return; }  // 06081CF6 rts ; mov.b r0,@r1
}

void f_06081D0C(SH2Context& c) {
    ran[1824] = 1;
L_06081D0C:
    c.r[15] -= 4; st32(c.r[15], c.r[4]);  // 06081D0C mov.l r4,@-r15
L_06081D0E:
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06081D0E sts.l pr,@-r15
L_06081D10:
    c.r[0] = ld32(0x06081D2Cu);  // 06081D10 mov.l 0x06081D2C,r0
L_06081D12:
    { const uint32_t x = c.r[0]; c.pr = 0x06081D16u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06081D16u) return; }  // 06081D12 jsr @r0 ; nop
L_06081D16:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06081D16 lds.l @r15+,pr
L_06081D18:
    c.r[4] = ld32(c.r[15]); c.r[15] += 4;  // 06081D18 mov.l @r15+,r4
L_06081D1A:
    c.r[1] = 0x2u;  // 06081D1A mov #2,r1
L_06081D1C:
    c.t = c.r[0] >= c.r[1];  // 06081D1C cmp/hs r1,r0
L_06081D1E:
    if (!c.t) { goto L_06081D26; }  // 06081D1E bf 0x06081D26
L_06081D20:
    c.r[0] += 48;  // 06081D20 add #48,r0
L_06081D22:
    c.r[5] = ld32(0x06081D30u);  // 06081D22 mov.l 0x06081D30,r5
L_06081D24:
    st8(c.r[5], c.r[0]);  // 06081D24 mov.b r0,@r5
L_06081D26:
    c.r[1] = ld32(0x06081D34u);  // 06081D26 mov.l 0x06081D34,r1
L_06081D28:
    { const uint32_t x = c.r[1]; SH2_POLL(c); switch (x) { case 0x06081D0Cu: goto L_06081D0C; case 0x06081D0Eu: goto L_06081D0E; case 0x06081D10u: goto L_06081D10; case 0x06081D12u: goto L_06081D12; case 0x06081D16u: goto L_06081D16; case 0x06081D18u: goto L_06081D18; case 0x06081D1Au: goto L_06081D1A; case 0x06081D1Cu: goto L_06081D1C; case 0x06081D1Eu: goto L_06081D1E; case 0x06081D20u: goto L_06081D20; case 0x06081D22u: goto L_06081D22; case 0x06081D24u: goto L_06081D24; case 0x06081D26u: goto L_06081D26; case 0x06081D28u: goto L_06081D28; default: sh2_call(c, x); return; } }  // 06081D28 jmp @r1 ; nop
}

void f_06081DD0(SH2Context& c) {
    ran[1825] = 1;
L_06081DD0:
    c.r[1] = ld32(0x06081EC4u);  // 06081DD0 mov.l 0x06081EC4,r1
L_06081DD2:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06081DD2 mov.b @r1,r0
L_06081DD4:
    c.t = c.r[0] == 0x58u;  // 06081DD4 cmp/eq #88,r0
L_06081DD6:
    if (!c.t) { goto L_06081EA8; }  // 06081DD6 bf 0x06081EA8
L_06081DD8:
    c.r[1] = ld32(0x06081ECCu);  // 06081DD8 mov.l 0x06081ECC,r1
L_06081DDA:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1] + 14);  // 06081DDA mov.b @(14,r1),r0
L_06081DDC:
    c.r[0] = c.r[0] & 0xFFu;  // 06081DDC extu.b r0,r0
L_06081DDE:
    c.r[1] = 0x1u;  // 06081DDE mov #1,r1
L_06081DE0:
    c.t = c.r[0] > c.r[1];  // 06081DE0 cmp/hi r1,r0
L_06081DE2:
    if (!c.t) { goto L_06081EA8; }  // 06081DE2 bf 0x06081EA8
L_06081DE4:
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06081DE4 mov.l r8,@-r15
L_06081DE6:
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06081DE6 mov.l r9,@-r15
L_06081DE8:
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06081DE8 mov.l r10,@-r15
L_06081DEA:
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06081DEA mov.l r11,@-r15
L_06081DEC:
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06081DEC sts.l pr,@-r15
L_06081DEE:
    c.r[8] = c.r[0];  // 06081DEE mov r0,r8
L_06081DF0:
    c.r[1] = ld32(0x06081EB0u);  // 06081DF0 mov.l 0x06081EB0,r1
L_06081DF2:
    c.r[4] = ld32(c.r[1]);  // 06081DF2 mov.l @r1,r4
L_06081DF4:
    c.r[1] = ld32(0x06081ED0u);  // 06081DF4 mov.l 0x06081ED0,r1
L_06081DF6:
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06081DF6 mov.b @r1,r5
L_06081DF8:
    c.r[0] = ld32(0x06081ED4u);  // 06081DF8 mov.l 0x06081ED4,r0
L_06081DFA:
    { const uint32_t x = c.r[0]; c.pr = 0x06081DFEu; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06081DFEu) return; }  // 06081DFA jsr @r0 ; extu.b r5,r5
L_06081DFE:
    c.r[1] = ld32(0x06081ED8u);  // 06081DFE mov.l 0x06081ED8,r1
L_06081E00:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06081E00 mov.b @r1,r1
L_06081E02:
    c.r[1] = c.r[1] & 0xFFu;  // 06081E02 extu.b r1,r1
L_06081E04:
    c.r[1] -= c.r[0];  // 06081E04 sub r0,r1
L_06081E06:
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 06081E06 cmp/gt r1,r8
L_06081E08:
    if (c.t) { goto L_06081E94; }  // 06081E08 bt 0x06081E94
L_06081E0A:
    c.r[11] = ld32(0x06081EDCu);  // 06081E0A mov.l 0x06081EDC,r11
L_06081E0C:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[11] + 2);  // 06081E0C mov.b @(2,r11),r0
L_06081E0E:
    c.r[0] = c.r[0] & 0xFFu;  // 06081E0E extu.b r0,r0
L_06081E10:
    c.t = c.r[0] == c.r[8];  // 06081E10 cmp/eq r8,r0
L_06081E12:
    if (!c.t) { goto L_06081E94; }  // 06081E12 bf 0x06081E94
L_06081E14:
    c.r[11] -= 20;  // 06081E14 add #-20,r11
L_06081E16:
    c.r[1] = c.r[11];  // 06081E16 mov r11,r1
L_06081E18:
    c.r[3] = c.r[8];  // 06081E18 mov r8,r3
L_06081E1A:
    c.r[2] = 0x0u;  // 06081E1A mov #0,r2
L_06081E1C:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 06081E1C mov.w @r1+,r0
L_06081E1E:
    c.r[0] = c.r[0] & 0xFFFFu;  // 06081E1E extu.w r0,r0
L_06081E20:
    c.r[2] += c.r[0];  // 06081E20 add r0,r2
L_06081E22:
    c.r[3] -= 1; c.t = c.r[3] == 0;  // 06081E22 dt r3
L_06081E24:
    if (!c.t) { SH2_POLL(c); goto L_06081E1C; }  // 06081E24 bf 0x06081E1C
L_06081E26:
    c.r[0] = c.r[2];  // 06081E26 mov r2,r0
L_06081E28:
    c.r[2] <<= 2;  // 06081E28 shll2 r2
L_06081E2A:
    c.r[2] += c.r[0];  // 06081E2A add r0,r2
L_06081E2C:
    c.r[2] += c.r[2];  // 06081E2C add r2,r2
L_06081E2E:
    c.r[9] = ld32(0x06081EE0u);  // 06081E2E mov.l 0x06081EE0,r9
L_06081E30:
    c.r[10] = ld32(c.r[9]);  // 06081E30 mov.l @r9,r10
L_06081E32:
    c.t = c.r[2] == c.r[10];  // 06081E32 cmp/eq r10,r2
L_06081E34:
    if (!c.t) { goto L_06081E94; }  // 06081E34 bf 0x06081E94
L_06081E36:
    c.r[1] = ld32(0x06081EC0u);  // 06081E36 mov.l 0x06081EC0,r1
L_06081E38:
    c.r[1] = ld32(c.r[1]);  // 06081E38 mov.l @r1,r1
L_06081E3A:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[1] + 10);  // 06081E3A mov.w @(10,r1),r0
L_06081E3C:
    c.r[2] = c.r[0] & 0xFFFFu;  // 06081E3C extu.w r0,r2
L_06081E3E:
    c.r[2] <<= 8;  // 06081E3E shll8 r2
L_06081E40:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1] + 12);  // 06081E40 mov.b @(12,r1),r0
L_06081E42:
    c.r[0] = c.r[0] & 0xFFu;  // 06081E42 extu.b r0,r0
L_06081E44:
    c.r[2] |= c.r[0];  // 06081E44 or r0,r2
L_06081E46:
    c.t = c.r[10] > c.r[2];  // 06081E46 cmp/hi r2,r10
L_06081E48:
    if (c.t) { goto L_06081E94; }  // 06081E48 bt 0x06081E94
L_06081E4A:
    c.r[10] = 0x0u;  // 06081E4A mov #0,r10
L_06081E4C:
    c.t = (c.r[10] & c.r[10]) == 0;  // 06081E4C tst r10,r10
L_06081E4E:
    if (c.t) { goto L_06081E70; }  // 06081E4E bt 0x06081E70
L_06081E50:
    c.r[1] = ld32(0x06081EB0u);  // 06081E50 mov.l 0x06081EB0,r1
L_06081E52:
    c.r[1] = ld32(c.r[1]);  // 06081E52 mov.l @r1,r1
L_06081E54:
    c.r[2] = ld32(0x06081ED0u);  // 06081E54 mov.l 0x06081ED0,r2
L_06081E56:
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06081E56 mov.b @r2,r2
L_06081E58:
    c.r[2] = c.r[2] & 0xFFu;  // 06081E58 extu.b r2,r2
L_06081E5A:
    c.r[3] = c.r[2];  // 06081E5A mov r2,r3
L_06081E5C:
    c.r[3] <<= 2;  // 06081E5C shll2 r3
L_06081E5E:
    c.r[3] += c.r[2];  // 06081E5E add r2,r3
L_06081E60:
    c.r[3] <<= 2;  // 06081E60 shll2 r3
L_06081E62:
    c.r[1] += c.r[3];  // 06081E62 add r3,r1
L_06081E64:
    c.r[1] += 48;  // 06081E64 add #48,r1
L_06081E66:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06081E66 mov.w @r1,r0
L_06081E68:
    c.r[0] = c.r[0] & 0xFFFFu;  // 06081E68 extu.w r0,r0
L_06081E6A:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06081EE8u);  // 06081E6A mov.w 0x06081EE8,r1
L_06081E6C:
    c.t = c.r[0] > c.r[1];  // 06081E6C cmp/hi r1,r0
L_06081E6E:
    if (c.t) { goto L_06081E8E; }  // 06081E6E bt 0x06081E8E
L_06081E70:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[11]); c.r[11] += 2;  // 06081E70 mov.w @r11+,r0
L_06081E72:
    c.r[0] = c.r[0] & 0xFFFFu;  // 06081E72 extu.w r0,r0
L_06081E74:
    c.r[1] = c.r[0];  // 06081E74 mov r0,r1
L_06081E76:
    c.r[0] <<= 2;  // 06081E76 shll2 r0
L_06081E78:
    c.r[0] += c.r[1];  // 06081E78 add r1,r0
L_06081E7A:
    c.r[0] += c.r[0];  // 06081E7A add r0,r0
L_06081E7C:
    st32(c.r[9], c.r[0]);  // 06081E7C mov.l r0,@r9
L_06081E7E:
    c.r[0] = ld32(0x06081EE4u);  // 06081E7E mov.l 0x06081EE4,r0
L_06081E80:
    { const uint32_t x = c.r[0]; c.pr = 0x06081E84u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06081E84u) return; }  // 06081E80 jsr @r0 ; nop
L_06081E84:
    c.r[10] += 1;  // 06081E84 add #1,r10
L_06081E86:
    c.t = c.r[10] >= c.r[8];  // 06081E86 cmp/hs r8,r10
L_06081E88:
    if (!c.t) { SH2_POLL(c); goto L_06081E4C; }  // 06081E88 bf 0x06081E4C
L_06081E8A:
    goto L_06081E94;  // 06081E8A bra 0x06081E94 ; nop
L_06081E8E:
    c.r[1] = ld32(0x06081EDCu);  // 06081E8E mov.l 0x06081EDC,r1
L_06081E90:
    c.r[0] = 0x1u;  // 06081E90 mov #1,r0
L_06081E92:
    st8(c.r[1] + 3, c.r[0]);  // 06081E92 mov.b r0,@(3,r1)
L_06081E94:
    c.r[1] = ld32(0x06081ECCu);  // 06081E94 mov.l 0x06081ECC,r1
L_06081E96:
    c.r[0] = 0x1u;  // 06081E96 mov #1,r0
L_06081E98:
    st8(c.r[1] + 14, c.r[0]);  // 06081E98 mov.b r0,@(14,r1)
L_06081E9A:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06081EEAu);  // 06081E9A mov.w 0x06081EEA,r0
L_06081E9C:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06081E9C lds.l @r15+,pr
L_06081E9E:
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06081E9E mov.l @r15+,r11
L_06081EA0:
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06081EA0 mov.l @r15+,r10
L_06081EA2:
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06081EA2 mov.l @r15+,r9
L_06081EA4:
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06081EA4 rts ; mov.l @r15+,r8
L_06081EA8:
    c.r[0] = ld32(0x06081EE4u);  // 06081EA8 mov.l 0x06081EE4,r0
L_06081EAA:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x06081DD0u: goto L_06081DD0; case 0x06081DD2u: goto L_06081DD2; case 0x06081DD4u: goto L_06081DD4; case 0x06081DD6u: goto L_06081DD6; case 0x06081DD8u: goto L_06081DD8; case 0x06081DDAu: goto L_06081DDA; case 0x06081DDCu: goto L_06081DDC; case 0x06081DDEu: goto L_06081DDE; case 0x06081DE0u: goto L_06081DE0; case 0x06081DE2u: goto L_06081DE2; case 0x06081DE4u: goto L_06081DE4; case 0x06081DE6u: goto L_06081DE6; case 0x06081DE8u: goto L_06081DE8; case 0x06081DEAu: goto L_06081DEA; case 0x06081DECu: goto L_06081DEC; case 0x06081DEEu: goto L_06081DEE; case 0x06081DF0u: goto L_06081DF0; case 0x06081DF2u: goto L_06081DF2; case 0x06081DF4u: goto L_06081DF4; case 0x06081DF6u: goto L_06081DF6; case 0x06081DF8u: goto L_06081DF8; case 0x06081DFAu: goto L_06081DFA; case 0x06081DFEu: goto L_06081DFE; case 0x06081E00u: goto L_06081E00; case 0x06081E02u: goto L_06081E02; case 0x06081E04u: goto L_06081E04; case 0x06081E06u: goto L_06081E06; case 0x06081E08u: goto L_06081E08; case 0x06081E0Au: goto L_06081E0A; case 0x06081E0Cu: goto L_06081E0C; case 0x06081E0Eu: goto L_06081E0E; case 0x06081E10u: goto L_06081E10; case 0x06081E12u: goto L_06081E12; case 0x06081E14u: goto L_06081E14; case 0x06081E16u: goto L_06081E16; case 0x06081E18u: goto L_06081E18; case 0x06081E1Au: goto L_06081E1A; case 0x06081E1Cu: goto L_06081E1C; case 0x06081E1Eu: goto L_06081E1E; case 0x06081E20u: goto L_06081E20; case 0x06081E22u: goto L_06081E22; case 0x06081E24u: goto L_06081E24; case 0x06081E26u: goto L_06081E26; case 0x06081E28u: goto L_06081E28; case 0x06081E2Au: goto L_06081E2A; case 0x06081E2Cu: goto L_06081E2C; case 0x06081E2Eu: goto L_06081E2E; case 0x06081E30u: goto L_06081E30; case 0x06081E32u: goto L_06081E32; case 0x06081E34u: goto L_06081E34; case 0x06081E36u: goto L_06081E36; case 0x06081E38u: goto L_06081E38; case 0x06081E3Au: goto L_06081E3A; case 0x06081E3Cu: goto L_06081E3C; case 0x06081E3Eu: goto L_06081E3E; case 0x06081E40u: goto L_06081E40; case 0x06081E42u: goto L_06081E42; case 0x06081E44u: goto L_06081E44; case 0x06081E46u: goto L_06081E46; case 0x06081E48u: goto L_06081E48; case 0x06081E4Au: goto L_06081E4A; case 0x06081E4Cu: goto L_06081E4C; case 0x06081E4Eu: goto L_06081E4E; case 0x06081E50u: goto L_06081E50; case 0x06081E52u: goto L_06081E52; case 0x06081E54u: goto L_06081E54; case 0x06081E56u: goto L_06081E56; case 0x06081E58u: goto L_06081E58; case 0x06081E5Au: goto L_06081E5A; case 0x06081E5Cu: goto L_06081E5C; case 0x06081E5Eu: goto L_06081E5E; case 0x06081E60u: goto L_06081E60; case 0x06081E62u: goto L_06081E62; case 0x06081E64u: goto L_06081E64; case 0x06081E66u: goto L_06081E66; case 0x06081E68u: goto L_06081E68; case 0x06081E6Au: goto L_06081E6A; case 0x06081E6Cu: goto L_06081E6C; case 0x06081E6Eu: goto L_06081E6E; case 0x06081E70u: goto L_06081E70; case 0x06081E72u: goto L_06081E72; case 0x06081E74u: goto L_06081E74; case 0x06081E76u: goto L_06081E76; case 0x06081E78u: goto L_06081E78; case 0x06081E7Au: goto L_06081E7A; case 0x06081E7Cu: goto L_06081E7C; case 0x06081E7Eu: goto L_06081E7E; case 0x06081E80u: goto L_06081E80; case 0x06081E84u: goto L_06081E84; case 0x06081E86u: goto L_06081E86; case 0x06081E88u: goto L_06081E88; case 0x06081E8Au: goto L_06081E8A; case 0x06081E8Eu: goto L_06081E8E; case 0x06081E90u: goto L_06081E90; case 0x06081E92u: goto L_06081E92; case 0x06081E94u: goto L_06081E94; case 0x06081E96u: goto L_06081E96; case 0x06081E98u: goto L_06081E98; case 0x06081E9Au: goto L_06081E9A; case 0x06081E9Cu: goto L_06081E9C; case 0x06081E9Eu: goto L_06081E9E; case 0x06081EA0u: goto L_06081EA0; case 0x06081EA2u: goto L_06081EA2; case 0x06081EA4u: goto L_06081EA4; case 0x06081EA8u: goto L_06081EA8; case 0x06081EAAu: goto L_06081EAA; default: sh2_call(c, x); return; } }  // 06081EAA jmp @r0 ; nop
}

void f_06081EEC(SH2Context& c) {
    ran[1826] = 1;
L_06081EEC:
    c.r[1] = ld32(0x06081F2Cu);  // 06081EEC mov.l 0x06081F2C,r1
L_06081EEE:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06081EEE mov.w @r1,r1
L_06081EF0:
    c.r[0] = ld32(0x06081F30u);  // 06081EF0 mov.l 0x06081F30,r0
L_06081EF2:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06081EF2 mov.b @r0,r0
L_06081EF4:
    c.r[0] = c.r[0] & 0xFFu;  // 06081EF4 extu.b r0,r0
L_06081EF6:
    c.r[2] = (uint32_t)(int16_t)ld16(0x06081F44u);  // 06081EF6 mov.w 0x06081F44,r2
L_06081EF8:
    c.r[0] |= c.r[2];  // 06081EF8 or r2,r0
L_06081EFA:
    c.t = c.r[1] == c.r[0];  // 06081EFA cmp/eq r0,r1
L_06081EFC:
    if (!c.t) { goto L_06081F06; }  // 06081EFC bf 0x06081F06
L_06081EFE:
    c.r[1] = ld32(0x06081F34u);  // 06081EFE mov.l 0x06081F34,r1
L_06081F00:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06081F00 mov.b @r1,r0
L_06081F02:
    c.t = (c.r[0] & 0x8u) == 0;  // 06081F02 tst #8,r0
L_06081F04:
    if (c.t) { goto L_06081F0C; }  // 06081F04 bt 0x06081F0C
L_06081F06:
    c.r[0] = ld32(0x06081F38u);  // 06081F06 mov.l 0x06081F38,r0
L_06081F08:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x06081EECu: goto L_06081EEC; case 0x06081EEEu: goto L_06081EEE; case 0x06081EF0u: goto L_06081EF0; case 0x06081EF2u: goto L_06081EF2; case 0x06081EF4u: goto L_06081EF4; case 0x06081EF6u: goto L_06081EF6; case 0x06081EF8u: goto L_06081EF8; case 0x06081EFAu: goto L_06081EFA; case 0x06081EFCu: goto L_06081EFC; case 0x06081EFEu: goto L_06081EFE; case 0x06081F00u: goto L_06081F00; case 0x06081F02u: goto L_06081F02; case 0x06081F04u: goto L_06081F04; case 0x06081F06u: goto L_06081F06; case 0x06081F08u: goto L_06081F08; case 0x06081F0Cu: goto L_06081F0C; case 0x06081F0Eu: goto L_06081F0E; case 0x06081F10u: goto L_06081F10; case 0x06081F12u: goto L_06081F12; case 0x06081F14u: goto L_06081F14; case 0x06081F16u: goto L_06081F16; case 0x06081F18u: goto L_06081F18; case 0x06081F1Au: goto L_06081F1A; case 0x06081F1Eu: goto L_06081F1E; case 0x06081F20u: goto L_06081F20; case 0x06081F22u: goto L_06081F22; case 0x06081F24u: goto L_06081F24; case 0x06081F26u: goto L_06081F26; case 0x06081F28u: goto L_06081F28; default: sh2_call(c, x); return; } }  // 06081F08 jmp @r0 ; nop
L_06081F0C:
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06081F0C mov.l r8,@-r15
L_06081F0E:
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06081F0E mov.l r9,@-r15
L_06081F10:
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06081F10 sts.l pr,@-r15
L_06081F12:
    c.r[8] = ld32(0x06081F3Cu);  // 06081F12 mov.l 0x06081F3C,r8
L_06081F14:
    c.r[9] = ld32(c.r[8]);  // 06081F14 mov.l @r8,r9
L_06081F16:
    c.r[0] = 0x0u;  // 06081F16 mov #0,r0
L_06081F18:
    c.r[1] = ld32(0x06081F38u);  // 06081F18 mov.l 0x06081F38,r1
L_06081F1A:
    { const uint32_t x = c.r[1]; c.pr = 0x06081F1Eu; st32(c.r[8], c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06081F1Eu) return; }  // 06081F1A jsr @r1 ; mov.l r0,@r8
L_06081F1E:
    st32(c.r[8], c.r[9]);  // 06081F1E mov.l r9,@r8
L_06081F20:
    c.r[1] = ld32(0x06081F40u);  // 06081F20 mov.l 0x06081F40,r1
L_06081F22:
    st32(c.r[1], c.r[9]);  // 06081F22 mov.l r9,@r1
L_06081F24:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06081F24 lds.l @r15+,pr
L_06081F26:
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06081F26 mov.l @r15+,r9
L_06081F28:
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06081F28 rts ; mov.l @r15+,r8
}

void f_06081FA0(SH2Context& c) {
    ran[1827] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06081FA0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06081FA2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06081FA4 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06081FA6 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06081FA8 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06081FAA mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06081FAC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06081FAE sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06081FB0 mov r15,r14
    c.r[3] = ld32(0x06082114u);  // 06081FB2 mov.l 0x06082114,r3
    c.r[2] = c.r[3];  // 06081FB4 mov r3,r2
    c.r[2] += 112;  // 06081FB6 add #112,r2
    c.r[1] = 0x3Fu;  // 06081FB8 mov #63,r1
    st16(c.r[2], c.r[1]);  // 06081FBA mov.w r1,@r2
    c.r[3] += 114;  // 06081FBC add #114,r3
    c.r[1] = 0xFFFFFFDFu;  // 06081FBE mov #-33,r1
    st16(c.r[3], c.r[1]);  // 06081FC0 mov.w r1,@r3
    c.r[1] = ld32(0x06082118u);  // 06081FC2 mov.l 0x06082118,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06081FC8u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06081FC8u) return; }  // 06081FC4 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x0608211Cu);  // 06081FC8 mov.l 0x0608211C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06081FCEu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06081FCEu) return; }  // 06081FCA jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06082120u);  // 06081FCE mov.l 0x06082120,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06081FD4u; c.r[8] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06081FD4u) return; }  // 06081FD0 jsr @r1 ; mov #1,r8
    c.r[1] = ld32(0x06082124u);  // 06081FD4 mov.l 0x06082124,r1
    c.r[2] = ld32(c.r[1]);  // 06081FD6 mov.l @r1,r2
    c.r[1] = ld32(0x06082128u);  // 06081FD8 mov.l 0x06082128,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06081FDA mov.b @r1,r1
    c.r[0] = c.r[2];  // 06081FDC mov r2,r0
    c.r[1] = c.r[1] & 0xFFu;  // 06081FDE extu.b r1,r1
    c.r[1] += c.r[1];  // 06081FE0 add r1,r1
    c.r[2] += c.r[1];  // 06081FE2 add r1,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06081FE4 mov.b @(r0,r1),r3
    c.r[2] += 1;  // 06081FE6 add #1,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06081FE8 mov.b @r2,r2
    c.r[0] = 0x7Fu;  // 06081FEA mov #127,r0
    c.r[3] &= c.r[0];  // 06081FEC and r0,r3
    c.r[3] <<= 8;  // 06081FEE shll8 r3
    c.r[2] = c.r[2] & 0xFFu;  // 06081FF0 extu.b r2,r2
    c.r[2] |= c.r[3];  // 06081FF2 or r3,r2
    c.r[1] = ld32(0x0608212Cu);  // 06081FF4 mov.l 0x0608212C,r1
    c.r[0] = 0x1Eu;  // 06081FF6 mov #30,r0
    c.macl = c.r[2] * c.r[0];  // 06081FF8 mul.l r0,r2
    c.r[3] = ld32(c.r[1]);  // 06081FFA mov.l @r1,r3
    c.r[1] = c.macl;  // 06081FFC sts macl,r1
    c.r[0] = c.r[1];  // 06081FFE mov r1,r0
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 06082000 mov.w @(r0,r3),r4
    c.r[5] = (uint32_t)(int16_t)ld16(0x0608210Cu);  // 06082002 mov.w 0x0608210C,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x0608210Eu);  // 06082004 mov.w 0x0608210E,r1
    c.r[4] += c.r[1];  // 06082006 add r1,r4
    c.r[1] = ld32(0x06082130u);  // 06082008 mov.l 0x06082130,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0608200Eu; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608200Eu) return; }  // 0608200A jsr @r1 ; extu.w r4,r4
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608200E mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06082010 mov.l r8,@-r15
    c.r[11] = 0x0u;  // 06082012 mov #0,r11
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06082014 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06082016 mov.l r8,@-r15
    c.r[0] = 0x6u;  // 06082018 mov #6,r0
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 0608201A mov.l r0,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0608201C mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0608201E mov.l r11,@-r15
    c.r[10] = 0x2u;  // 06082020 mov #2,r10
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06082022 mov.l r10,@-r15
    c.r[7] = 0x1Eu;  // 06082024 mov #30,r7
    c.r[6] = 0xBu;  // 06082026 mov #11,r6
    c.r[5] = 0x5u;  // 06082028 mov #5,r5
    c.r[0] = ld32(0x06082134u);  // 0608202A mov.l 0x06082134,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06082030u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082030u) return; }  // 0608202C jsr @r0 ; mov #0,r4
    c.r[15] += 32;  // 06082030 add #32,r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06082032 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06082034 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06082036 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06082038 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0608203A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608203C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608203E mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06082040 mov.l r10,@-r15
    c.r[7] = 0x1Eu;  // 06082042 mov #30,r7
    c.r[6] = 0xDu;  // 06082044 mov #13,r6
    c.r[5] = 0x5u;  // 06082046 mov #5,r5
    c.r[0] = ld32(0x06082134u);  // 06082048 mov.l 0x06082134,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0608204Eu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608204Eu) return; }  // 0608204A jsr @r0 ; mov r8,r4
    c.r[15] += 32;  // 0608204E add #32,r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06082050 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06082052 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06082054 mov.l r11,@-r15
    c.r[13] = 0x3u;  // 06082056 mov #3,r13
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06082058 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608205A mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0608205C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0608205E mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06082060 mov.l r10,@-r15
    c.r[7] = 0x1Eu;  // 06082062 mov #30,r7
    c.r[6] = 0xFu;  // 06082064 mov #15,r6
    c.r[5] = 0x5u;  // 06082066 mov #5,r5
    c.r[0] = ld32(0x06082134u);  // 06082068 mov.l 0x06082134,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0608206Eu; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608206Eu) return; }  // 0608206A jsr @r0 ; mov r10,r4
    c.r[15] += 32;  // 0608206E add #32,r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06082070 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06082072 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06082074 mov.l r11,@-r15
    c.r[12] = 0x4u;  // 06082076 mov #4,r12
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06082078 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0608207A mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0608207C mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0608207E mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06082080 mov.l r10,@-r15
    c.r[7] = 0x1Eu;  // 06082082 mov #30,r7
    c.r[6] = 0x11u;  // 06082084 mov #17,r6
    c.r[5] = 0x5u;  // 06082086 mov #5,r5
    c.r[0] = ld32(0x06082134u);  // 06082088 mov.l 0x06082134,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0608208Eu; c.r[4] = c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608208Eu) return; }  // 0608208A jsr @r0 ; mov r13,r4
    c.r[15] += 32;  // 0608208E add #32,r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06082090 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06082092 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06082094 mov.l r11,@-r15
    c.r[9] = 0x5u;  // 06082096 mov #5,r9
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06082098 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0608209A mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0608209C mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0608209E mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060820A0 mov.l r10,@-r15
    c.r[7] = 0x1Eu;  // 060820A2 mov #30,r7
    c.r[6] = 0x13u;  // 060820A4 mov #19,r6
    c.r[5] = c.r[9];  // 060820A6 mov r9,r5
    c.r[0] = ld32(0x06082134u);  // 060820A8 mov.l 0x06082134,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060820AEu; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060820AEu) return; }  // 060820AA jsr @r0 ; mov r12,r4
    c.r[15] += 32;  // 060820AE add #32,r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060820B0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060820B2 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060820B4 mov.l r11,@-r15
    c.r[0] = 0x6u;  // 060820B6 mov #6,r0
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 060820B8 mov.l r0,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060820BA mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060820BC mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060820BE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060820C0 mov.l r10,@-r15
    c.r[7] = 0x1Eu;  // 060820C2 mov #30,r7
    c.r[6] = 0x15u;  // 060820C4 mov #21,r6
    c.r[5] = c.r[9];  // 060820C6 mov r9,r5
    c.r[0] = ld32(0x06082134u);  // 060820C8 mov.l 0x06082134,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060820CEu; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060820CEu) return; }  // 060820CA jsr @r0 ; mov r9,r4
    c.r[15] += 32;  // 060820CE add #32,r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060820D0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060820D2 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060820D4 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060820D6 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060820D8 mov.l r9,@-r15
    c.r[0] = 0x6u;  // 060820DA mov #6,r0
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 060820DC mov.l r0,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 060820DE mov.l r0,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060820E0 mov.l r10,@-r15
    c.r[7] = 0x1Eu;  // 060820E2 mov #30,r7
    c.r[6] = 0x18u;  // 060820E4 mov #24,r6
    c.r[5] = c.r[9];  // 060820E6 mov r9,r5
    c.r[0] = ld32(0x06082134u);  // 060820E8 mov.l 0x06082134,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060820EEu; c.r[4] = 0x6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060820EEu) return; }  // 060820EA jsr @r0 ; mov #6,r4
    c.r[15] += 32;  // 060820EE add #32,r15
    c.r[1] = ld32(0x06082138u);  // 060820F0 mov.l 0x06082138,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060820F6u; c.r[4] = 0x40u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060820F6u) return; }  // 060820F2 jsr @r1 ; mov #64,r4
    c.r[15] = c.r[14];  // 060820F6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060820F8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060820FA mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060820FC mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060820FE mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06082100 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06082102 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06082104 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06082110u);  // 06082106 mov.w 0x06082110,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06082108 rts ; mov.l @r15+,r8
}

void f_06082140(SH2Context& c) {
    ran[1828] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06082140 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06082142 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06082144 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06082146 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06082148 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0608214A mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608214C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608214E sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x06082242u);  // 06082150 mov.w 0x06082242,r3
    c.r[15] += c.r[3];  // 06082152 add r3,r15
    c.r[14] = c.r[15];  // 06082154 mov r15,r14
    c.r[3] = 0x17u;  // 06082156 mov #23,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x06082244u);  // 06082158 mov.w 0x06082244,r0
    st32(c.r[0] + c.r[14], c.r[3]);  // 0608215A mov.l r3,@(r0,r14)
    c.r[3] = 0xAu;  // 0608215C mov #10,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x06082246u);  // 0608215E mov.w 0x06082246,r0
    st32(c.r[0] + c.r[14], c.r[3]);  // 06082160 mov.l r3,@(r0,r14)
    c.r[13] = 0x0u;  // 06082162 mov #0,r13
    c.r[12] = 0x0u;  // 06082164 mov #0,r12
    c.r[11] = 0x0u;  // 06082166 mov #0,r11
    c.r[1] = ld32(0x0608224Cu);  // 06082168 mov.l 0x0608224C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0608216Eu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608216Eu) return; }  // 0608216A jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x06082250u);  // 0608216E mov.l 0x06082250,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06082174u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082174u) return; }  // 06082170 jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x06082254u);  // 06082174 mov.l 0x06082254,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0608217Au; c.r[10] = 0x4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608217Au) return; }  // 06082176 jsr @r1 ; mov #4,r10
    c.r[9] = (uint32_t)(int16_t)ld16(0x06082248u);  // 0608217A mov.w 0x06082248,r9
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0608217C mov.l r10,@-r15
    c.r[8] = ld32(0x06082258u);  // 0608217E mov.l 0x06082258,r8
    c.r[7] = 0x1Cu;  // 06082180 mov #28,r7
    c.r[6] = 0x6u;  // 06082182 mov #6,r6
    c.r[5] = 0x5u;  // 06082184 mov #5,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0608218Au; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608218Au) return; }  // 06082186 jsr @r8 ; mov r9,r4
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0608218A mov.l r10,@-r15
    c.r[7] = 0x3u;  // 0608218C mov #3,r7
    c.r[0] = (uint32_t)(int16_t)ld16(0x06082246u);  // 0608218E mov.w 0x06082246,r0
    c.r[0] += c.r[14];  // 06082190 add r14,r0
    c.r[3] = (uint32_t)(int16_t)ld16(0x06082244u);  // 06082192 mov.w 0x06082244,r3
    c.r[6] = ld32(c.r[0]);  // 06082194 mov.l @r0,r6
    c.r[3] += c.r[14];  // 06082196 add r14,r3
    c.r[5] = ld32(c.r[3]);  // 06082198 mov.l @r3,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0608219Eu; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608219Eu) return; }  // 0608219A jsr @r8 ; mov r9,r4
    c.r[4] = (uint32_t)(int16_t)ld16(0x0608224Au);  // 0608219E mov.w 0x0608224A,r4
    c.r[8] = ld32(0x0608225Cu);  // 060821A0 mov.l 0x0608225C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060821A6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060821A6u) return; }  // 060821A2 jsr @r8 ; nop
    { const uint32_t x = c.r[8]; c.pr = 0x060821AAu; c.r[4] = 0x6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060821AAu) return; }  // 060821A6 jsr @r8 ; mov #6,r4
    { const uint32_t x = c.r[8]; c.pr = 0x060821AEu; c.r[4] = 0x7u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060821AEu) return; }  // 060821AA jsr @r8 ; mov #7,r4
    c.r[1] = ld32(0x06082260u);  // 060821AE mov.l 0x06082260,r1
    c.r[4] = c.r[14];  // 060821B0 mov r14,r4
    c.r[2] = ld32(c.r[1]);  // 060821B2 mov.l @r1,r2
    c.r[4] += 44;  // 060821B4 add #44,r4
    c.r[1] = ld32(0x06082264u);  // 060821B6 mov.l 0x06082264,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060821B8 mov.b @r1,r1
    c.r[6] = c.r[9];  // 060821BA mov r9,r6
    c.r[1] = c.r[1] & 0xFFu;  // 060821BC extu.b r1,r1
    c.r[1] += c.r[1];  // 060821BE add r1,r1
    c.r[2] += c.r[1];  // 060821C0 add r1,r2
    c.r[2] += 1;  // 060821C2 add #1,r2
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060821C4 mov.b @r2,r5
    c.r[1] = ld32(0x06082268u);  // 060821C6 mov.l 0x06082268,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060821CCu; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060821CCu) return; }  // 060821C8 jsr @r1 ; extu.b r5,r5
    c.r[1] = ld32(0x0608226Cu);  // 060821CC mov.l 0x0608226C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060821CE mov.b @r1,r1
    c.r[9] = c.r[1] & 0xFFu;  // 060821D0 extu.b r1,r9
    c.t = c.r[9] > c.r[10];  // 060821D2 cmp/hi r10,r9
    { const bool k = c.t; c.r[15] += 8; if (k) { goto L_06082288; } }  // 060821D4 bt/s 0x06082288 ; add #8,r15
    c.r[1] = c.r[9];  // 060821D8 mov r9,r1
    c.r[1] += c.r[1];  // 060821DA add r1,r1
    c.r[0] = 0x060821E8u;  // 060821DC mova 0x060821E8,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 060821DE mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 060821E0 add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x060821F2u: goto L_060821F2; case 0x06082206u: goto L_06082206; case 0x0608221Au: goto L_0608221A; case 0x0608222Eu: goto L_0608222E; case 0x06082274u: goto L_06082274; default: sh2_call(c, x); return; } }  // 060821E2 jmp @r0 ; nop
L_060821F2:
    c.r[1] = ld32(0x06082270u);  // 060821F2 mov.l 0x06082270,r1
    c.r[1] = ld32(c.r[1]);  // 060821F4 mov.l @r1,r1
    c.r[1] += 26;  // 060821F6 add #26,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060821F8 mov.w @r1,r1
    c.r[12] = c.r[1] & 0xFFFFu;  // 060821FA extu.w r1,r12
    c.r[1] = c.r[14];  // 060821FC mov r14,r1
    c.r[1] += 70;  // 060821FE add #70,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06082200 mov.w @r1,r1
    c.r[13] = 0x3u; goto L_06082286;  // 06082202 bra 0x06082286 ; mov #3,r13
L_06082206:
    c.r[1] = ld32(0x06082270u);  // 06082206 mov.l 0x06082270,r1
    c.r[1] = ld32(c.r[1]);  // 06082208 mov.l @r1,r1
    c.r[1] += 28;  // 0608220A add #28,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0608220C mov.w @r1,r1
    c.r[12] = c.r[1] & 0xFFFFu;  // 0608220E extu.w r1,r12
    c.r[1] = c.r[14];  // 06082210 mov r14,r1
    c.r[1] += 72;  // 06082212 add #72,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06082214 mov.w @r1,r1
    c.r[13] = 0x3u; goto L_06082286;  // 06082216 bra 0x06082286 ; mov #3,r13
L_0608221A:
    c.r[1] = ld32(0x06082270u);  // 0608221A mov.l 0x06082270,r1
    c.r[1] = ld32(c.r[1]);  // 0608221C mov.l @r1,r1
    c.r[1] += 34;  // 0608221E add #34,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06082220 mov.w @r1,r1
    c.r[12] = c.r[1] & 0xFFFFu;  // 06082222 extu.w r1,r12
    c.r[1] = c.r[14];  // 06082224 mov r14,r1
    c.r[1] += 78;  // 06082226 add #78,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06082228 mov.w @r1,r1
    c.r[13] = 0x7u; goto L_06082286;  // 0608222A bra 0x06082286 ; mov #7,r13
L_0608222E:
    c.r[1] = ld32(0x06082270u);  // 0608222E mov.l 0x06082270,r1
    c.r[1] = ld32(c.r[1]);  // 06082230 mov.l @r1,r1
    c.r[1] += 30;  // 06082232 add #30,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06082234 mov.w @r1,r1
    c.r[12] = c.r[1] & 0xFFFFu;  // 06082236 extu.w r1,r12
    c.r[1] = c.r[14];  // 06082238 mov r14,r1
    c.r[1] += 74;  // 0608223A add #74,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0608223C mov.w @r1,r1
    c.r[13] = 0x5u; goto L_06082286;  // 0608223E bra 0x06082286 ; mov #5,r13
L_06082274:
    c.r[1] = ld32(0x060823F4u);  // 06082274 mov.l 0x060823F4,r1
    c.r[1] = ld32(c.r[1]);  // 06082276 mov.l @r1,r1
    c.r[1] += 32;  // 06082278 add #32,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0608227A mov.w @r1,r1
    c.r[12] = c.r[1] & 0xFFFFu;  // 0608227C extu.w r1,r12
    c.r[1] = c.r[14];  // 0608227E mov r14,r1
    c.r[1] += 76;  // 06082280 add #76,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06082282 mov.w @r1,r1
    c.r[13] = 0x9u;  // 06082284 mov #9,r13
L_06082286:
    c.r[11] = c.r[1] & 0xFFFFu;  // 06082286 extu.w r1,r11
L_06082288:
    c.r[9] += 21;  // 06082288 add #21,r9
    c.r[9] = c.r[9] & 0xFFFFu;  // 0608228A extu.w r9,r9
    c.r[4] = ld32(0x060823F8u);  // 0608228C mov.l 0x060823F8,r4
    c.r[8] = ld32(0x060823FCu);  // 0608228E mov.l 0x060823FC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06082294u; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082294u) return; }  // 06082290 jsr @r8 ; mov #23,r5
    c.r[5] = 0x23u;  // 06082294 mov #35,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0608229Au; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608229Au) return; }  // 06082296 jsr @r8 ; mov r0,r4
    c.r[5] = c.r[9];  // 0608229A mov r9,r5
    { const uint32_t x = c.r[8]; c.pr = 0x060822A0u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060822A0u) return; }  // 0608229C jsr @r8 ; mov r0,r4
    c.r[1] = ld32(0x06082400u);  // 060822A0 mov.l 0x06082400,r1
    c.r[6] = c.r[13];  // 060822A2 mov r13,r6
    c.r[5] = c.r[0];  // 060822A4 mov r0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x060822AAu; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060822AAu) return; }  // 060822A6 jsr @r1 ; mov r14,r4
    c.r[5] = ld32(0x06082404u);  // 060822AA mov.l 0x06082404,r5
    c.r[8] = c.r[14];  // 060822AC mov r14,r8
    c.r[8] += 32;  // 060822AE add #32,r8
    c.r[0] = ld32(0x06082408u);  // 060822B0 mov.l 0x06082408,r0
    c.r[6] = c.r[12];  // 060822B2 mov r12,r6
    { const uint32_t x = c.r[0]; c.pr = 0x060822B8u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060822B8u) return; }  // 060822B4 jsr @r0 ; mov r8,r4
    c.r[10] = 0x0u;  // 060822B8 mov #0,r10
    c.r[2] = 0x4u;  // 060822BA mov #4,r2
    c.r[9] = c.r[8];  // 060822BC mov r8,r9
    c.r[0] = c.r[9];  // 060822BE mov r9,r0
L_060822C0:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 060822C0 mov.b @(r0,r10),r1
    c.r[1] = c.r[1] & 0xFFu;  // 060822C2 extu.b r1,r1
    c.r[0] = c.r[1];  // 060822C4 mov r1,r0
    c.t = c.r[0] == 0x20u;  // 060822C6 cmp/eq #32,r0
    if (!c.t) { goto L_060822D2; }  // 060822C8 bf 0x060822D2
    c.r[10] += 1;  // 060822CA add #1,r10
    c.t = (int32_t)c.r[10] > (int32_t)c.r[2];  // 060822CC cmp/gt r2,r10
    { const bool k = !c.t; c.r[0] = c.r[9]; if (k) { SH2_POLL(c); goto L_060822C0; } }  // 060822CE bf/s 0x060822C0 ; mov r9,r0
L_060822D2:
    c.r[5] = c.r[9];  // 060822D2 mov r9,r5
    c.r[5] += c.r[10];  // 060822D4 add r10,r5
    c.r[6] = 0u - c.r[10];  // 060822D6 neg r10,r6
    c.r[6] += 5;  // 060822D8 add #5,r6
    c.r[4] = c.r[14];  // 060822DA mov r14,r4
    c.r[1] = ld32(0x06082400u);  // 060822DC mov.l 0x06082400,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060822E2u; c.r[4] += c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060822E2u) return; }  // 060822DE jsr @r1 ; add r13,r4
    c.r[13] += 5;  // 060822E2 add #5,r13
    c.r[13] -= c.r[10];  // 060822E4 sub r10,r13
    c.r[4] = ld32(0x060823F8u);  // 060822E6 mov.l 0x060823F8,r4
    c.r[8] = ld32(0x060823FCu);  // 060822E8 mov.l 0x060823FC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060822EEu; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060822EEu) return; }  // 060822EA jsr @r8 ; mov #23,r5
    c.r[1] = c.r[0];  // 060822EE mov r0,r1
    c.r[5] = 0x23u;  // 060822F0 mov #35,r5
    { const uint32_t x = c.r[8]; c.pr = 0x060822F6u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060822F6u) return; }  // 060822F2 jsr @r8 ; mov r1,r4
    c.r[1] = c.r[0];  // 060822F6 mov r0,r1
    c.r[5] = 0x1Au;  // 060822F8 mov #26,r5
    { const uint32_t x = c.r[8]; c.pr = 0x060822FEu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060822FEu) return; }  // 060822FA jsr @r8 ; mov r1,r4
    c.r[7] = c.r[0];  // 060822FE mov r0,r7
    c.r[0] = c.r[14];  // 06082300 mov r14,r0
    c.r[2] = c.r[14];  // 06082302 mov r14,r2
    c.r[2] += 1;  // 06082304 add #1,r2
    c.r[5] = ld32(0x06082404u);  // 06082306 mov.l 0x06082404,r5
    c.r[6] = c.r[11];  // 06082308 mov r11,r6
    c.r[4] = c.r[9];  // 0608230A mov r9,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]); c.r[7] += 1;  // 0608230C mov.b @r7+,r1
    c.r[3] = ld32(0x06082408u);  // 0608230E mov.l 0x06082408,r3
    st8(c.r[0] + c.r[13], c.r[1]);  // 06082310 mov.b r1,@(r0,r13)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06082312 mov.b @r7,r1
    c.r[0] = c.r[2];  // 06082314 mov r2,r0
    st8(c.r[0] + c.r[13], c.r[1]);  // 06082316 mov.b r1,@(r0,r13)
    { const uint32_t x = c.r[3]; c.pr = 0x0608231Cu; c.r[13] += 2; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608231Cu) return; }  // 06082318 jsr @r3 ; add #2,r13
    c.r[10] = 0x0u;  // 0608231C mov #0,r10
    c.r[2] = 0x4u;  // 0608231E mov #4,r2
    c.r[5] = c.r[14];  // 06082320 mov r14,r5
    c.r[5] += 32;  // 06082322 add #32,r5
    c.r[0] = c.r[5];  // 06082324 mov r5,r0
L_06082326:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 06082326 mov.b @(r0,r10),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06082328 extu.b r1,r1
    c.r[0] = c.r[1];  // 0608232A mov r1,r0
    c.t = c.r[0] == 0x20u;  // 0608232C cmp/eq #32,r0
    if (!c.t) { goto L_06082338; }  // 0608232E bf 0x06082338
    c.r[10] += 1;  // 06082330 add #1,r10
    c.t = (int32_t)c.r[10] > (int32_t)c.r[2];  // 06082332 cmp/gt r2,r10
    { const bool k = !c.t; c.r[0] = c.r[5]; if (k) { SH2_POLL(c); goto L_06082326; } }  // 06082334 bf/s 0x06082326 ; mov r5,r0
L_06082338:
    c.r[5] += c.r[10];  // 06082338 add r10,r5
    c.r[6] = 0u - c.r[10];  // 0608233A neg r10,r6
    c.r[6] += 5;  // 0608233C add #5,r6
    c.r[4] = c.r[14];  // 0608233E mov r14,r4
    c.r[9] = ld32(0x06082400u);  // 06082340 mov.l 0x06082400,r9
    { const uint32_t x = c.r[9]; c.pr = 0x06082346u; c.r[4] += c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082346u) return; }  // 06082342 jsr @r9 ; add r13,r4
    c.r[13] += 5;  // 06082346 add #5,r13
    c.r[13] -= c.r[10];  // 06082348 sub r10,r13
    c.r[4] = ld32(0x060823F8u);  // 0608234A mov.l 0x060823F8,r4
    c.r[8] = ld32(0x060823FCu);  // 0608234C mov.l 0x060823FC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06082352u; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082352u) return; }  // 0608234E jsr @r8 ; mov #23,r5
    c.r[1] = c.r[0];  // 06082352 mov r0,r1
    c.r[5] = 0x23u;  // 06082354 mov #35,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0608235Au; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608235Au) return; }  // 06082356 jsr @r8 ; mov r1,r4
    c.r[1] = c.r[0];  // 0608235A mov r0,r1
    c.r[5] = 0x1Bu;  // 0608235C mov #27,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06082362u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082362u) return; }  // 0608235E jsr @r8 ; mov r1,r4
    c.r[1] = c.r[0];  // 06082362 mov r0,r1
    c.r[13] += c.r[14];  // 06082364 add r14,r13
    c.r[6] = 0x24u;  // 06082366 mov #36,r6
    c.r[5] = c.r[1];  // 06082368 mov r1,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0608236Eu; c.r[4] = c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608236Eu) return; }  // 0608236A jsr @r9 ; mov r13,r4
    c.r[1] = ld32(0x0608240Cu);  // 0608236E mov.l 0x0608240C,r1
    c.r[6] = 0x0u;  // 06082370 mov #0,r6
    c.r[5] = c.r[14];  // 06082372 mov r14,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06082378u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082378u) return; }  // 06082374 jsr @r1 ; mov #0,r4
    c.r[4] = (uint32_t)(int16_t)ld16(0x060823E8u);  // 06082378 mov.w 0x060823E8,r4
    c.r[8] = ld32(0x06082410u);  // 0608237A mov.l 0x06082410,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06082380u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082380u) return; }  // 0608237C jsr @r8 ; nop
    c.r[3] = (uint32_t)(int16_t)ld16(0x060823EAu);  // 06082380 mov.w 0x060823EA,r3
    c.r[3] += c.r[14];  // 06082382 add r14,r3
    c.r[0] = ld32(c.r[3]);  // 06082384 mov.l @r3,r0
    c.r[0] += 1;  // 06082386 add #1,r0
    st32(c.r[3], c.r[0]);  // 06082388 mov.l r0,@r3
    c.r[3] = (uint32_t)(int16_t)ld16(0x060823ECu);  // 0608238A mov.w 0x060823EC,r3
    c.r[3] += c.r[14];  // 0608238C add r14,r3
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0608238E mov.b @r3,r3
    c.r[9] = c.r[3] & 0xFFu;  // 06082390 extu.b r3,r9
    { const uint32_t x = c.r[8]; c.pr = 0x06082396u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082396u) return; }  // 06082392 jsr @r8 ; mov r9,r4
    c.r[0] = (uint32_t)(int16_t)ld16(0x060823EEu);  // 06082396 mov.w 0x060823EE,r0
    c.r[10] = ld32(c.r[0] + c.r[14]);  // 06082398 mov.l @(r0,r14),r10
    c.r[0] = 0x1u;  // 0608239A mov #1,r0
    c.r[10] |= c.r[0];  // 0608239C or r0,r10
    { const uint32_t x = c.r[8]; c.pr = 0x060823A2u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060823A2u) return; }  // 0608239E jsr @r8 ; mov r10,r4
    c.r[7] = 0x2u;  // 060823A2 mov #2,r7
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 060823A4 mov.l r7,@-r15
    c.r[2] = 0x1u;  // 060823A6 mov #1,r2
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 060823A8 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 060823AA mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 060823AC mov.l r2,@-r15
    c.r[1] = 0x0u;  // 060823AE mov #0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060823B0 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 060823B2 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060823B4 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060823B6 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 060823B8 mov.l r7,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 060823BA mov.l r2,@-r15
    c.r[1] = ld32(0x06082414u);  // 060823BC mov.l 0x06082414,r1
    c.r[6] = 0x5u;  // 060823BE mov #5,r6
    c.r[5] = c.r[10];  // 060823C0 mov r10,r5
    { const uint32_t x = c.r[1]; c.pr = 0x060823C6u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060823C6u) return; }  // 060823C2 jsr @r1 ; mov r9,r4
    c.r[15] += 40;  // 060823C6 add #40,r15
    c.r[1] = ld32(0x06082418u);  // 060823C8 mov.l 0x06082418,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060823CEu; c.r[4] = 0x41u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060823CEu) return; }  // 060823CA jsr @r1 ; mov #65,r4
    c.r[3] = (uint32_t)(int16_t)ld16(0x060823F0u);  // 060823CE mov.w 0x060823F0,r3
    c.r[14] += c.r[3];  // 060823D0 add r3,r14
    c.r[15] = c.r[14];  // 060823D2 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060823D4 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060823D6 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060823D8 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060823DA mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060823DC mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060823DE mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060823E0 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x060823F2u);  // 060823E2 mov.w 0x060823F2,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060823E4 rts ; mov.l @r15+,r8
}

void f_0608241C(SH2Context& c) {
    ran[1829] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608241C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0608241E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06082420 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06082422 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06082424 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06082426 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06082428 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608242A sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0608242C mov r15,r14
    c.r[12] = 0x9u;  // 0608242E mov #9,r12
    c.r[11] = 0xDu;  // 06082430 mov #13,r11
    c.r[13] = 0x11u;  // 06082432 mov #17,r13
    c.r[1] = ld32(0x060824F0u);  // 06082434 mov.l 0x060824F0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0608243Au; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608243Au) return; }  // 06082436 jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x060824F4u);  // 0608243A mov.l 0x060824F4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06082440u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082440u) return; }  // 0608243C jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x060824F8u);  // 06082440 mov.l 0x060824F8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06082446u; c.r[8] = 0x4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082446u) return; }  // 06082442 jsr @r1 ; mov #4,r8
    c.r[10] = (uint32_t)(int16_t)ld16(0x060824EAu);  // 06082446 mov.w 0x060824EA,r10
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06082448 mov.l r8,@-r15
    c.r[9] = ld32(0x060824FCu);  // 0608244A mov.l 0x060824FC,r9
    c.r[7] = 0x14u;  // 0608244C mov #20,r7
    c.r[6] = c.r[11];  // 0608244E mov r11,r6
    c.r[5] = c.r[12];  // 06082450 mov r12,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06082456u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082456u) return; }  // 06082452 jsr @r9 ; mov r10,r4
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06082456 mov.l r8,@-r15
    c.r[7] = 0x3u;  // 06082458 mov #3,r7
    c.r[6] = c.r[13];  // 0608245A mov r13,r6
    c.r[5] = 0x17u;  // 0608245C mov #23,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06082462u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082462u) return; }  // 0608245E jsr @r9 ; mov r10,r4
    c.r[11] = (uint32_t)(int16_t)ld16(0x060824ECu);  // 06082462 mov.w 0x060824EC,r11
    c.r[10] = ld32(0x06082500u);  // 06082464 mov.l 0x06082500,r10
    { const uint32_t x = c.r[10]; c.pr = 0x0608246Au; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608246Au) return; }  // 06082466 jsr @r10 ; mov r11,r4
    { const uint32_t x = c.r[10]; c.pr = 0x0608246Eu; c.r[4] = 0xAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608246Eu) return; }  // 0608246A jsr @r10 ; mov #10,r4
    { const uint32_t x = c.r[10]; c.pr = 0x06082472u; c.r[4] = 0xEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082472u) return; }  // 0608246E jsr @r10 ; mov #14,r4
    c.r[1] = ld32(0x06082504u);  // 06082472 mov.l 0x06082504,r1
    c.r[4] = ld32(0x06082508u);  // 06082474 mov.l 0x06082508,r4
    c.r[9] = ld32(0x0608250Cu);  // 06082476 mov.l 0x0608250C,r9
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06082478 mov.b @r1,r8
    c.r[5] = 0x17u;  // 0608247A mov #23,r5
    c.r[8] += 11;  // 0608247C add #11,r8
    { const uint32_t x = c.r[9]; c.pr = 0x06082482u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082482u) return; }  // 0608247E jsr @r9 ; extu.w r8,r8
    c.r[5] = 0x23u;  // 06082482 mov #35,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06082488u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082488u) return; }  // 06082484 jsr @r9 ; mov r0,r4
    c.r[5] = c.r[8];  // 06082488 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0608248Eu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608248Eu) return; }  // 0608248A jsr @r9 ; mov r0,r4
    c.r[1] = ld32(0x06082510u);  // 0608248E mov.l 0x06082510,r1
    c.r[6] = 0x0u;  // 06082490 mov #0,r6
    c.r[5] = c.r[0];  // 06082492 mov r0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06082498u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082498u) return; }  // 06082494 jsr @r1 ; mov #0,r4
    { const uint32_t x = c.r[10]; c.pr = 0x0608249Cu; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608249Cu) return; }  // 06082498 jsr @r10 ; mov r11,r4
    c.r[9] = 0x18u;  // 0608249C mov #24,r9
    { const uint32_t x = c.r[10]; c.pr = 0x060824A2u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060824A2u) return; }  // 0608249E jsr @r10 ; mov r9,r4
    c.r[8] = 0x12u;  // 060824A2 mov #18,r8
    { const uint32_t x = c.r[10]; c.pr = 0x060824A8u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060824A8u) return; }  // 060824A4 jsr @r10 ; mov r8,r4
    c.r[7] = 0x2u;  // 060824A8 mov #2,r7
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 060824AA mov.l r7,@-r15
    c.r[2] = 0x1u;  // 060824AC mov #1,r2
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 060824AE mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 060824B0 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 060824B2 mov.l r2,@-r15
    c.r[1] = 0x0u;  // 060824B4 mov #0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060824B6 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 060824B8 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060824BA mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060824BC mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 060824BE mov.l r7,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 060824C0 mov.l r2,@-r15
    c.r[1] = ld32(0x06082514u);  // 060824C2 mov.l 0x06082514,r1
    c.r[6] = 0x5u;  // 060824C4 mov #5,r6
    c.r[5] = c.r[8];  // 060824C6 mov r8,r5
    { const uint32_t x = c.r[1]; c.pr = 0x060824CCu; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060824CCu) return; }  // 060824C8 jsr @r1 ; mov r9,r4
    c.r[15] += 48;  // 060824CC add #48,r15
    c.r[1] = ld32(0x06082518u);  // 060824CE mov.l 0x06082518,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060824D4u; c.r[4] = 0x41u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060824D4u) return; }  // 060824D0 jsr @r1 ; mov #65,r4
    c.r[15] = c.r[14];  // 060824D4 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060824D6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060824D8 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060824DA mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060824DC mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060824DE mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060824E0 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060824E2 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x060824EEu);  // 060824E4 mov.w 0x060824EE,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060824E6 rts ; mov.l @r15+,r8
}

void f_0608251C(SH2Context& c) {
    ran[1830] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608251C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0608251E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06082520 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06082522 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06082524 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06082526 mov r15,r14
    c.r[9] = 0x5u;  // 06082528 mov #5,r9
    c.r[8] = 0x6u;  // 0608252A mov #6,r8
    c.r[1] = ld32(0x060825C4u);  // 0608252C mov.l 0x060825C4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06082532u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082532u) return; }  // 0608252E jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x060825C8u);  // 06082532 mov.l 0x060825C8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06082538u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082538u) return; }  // 06082534 jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x060825CCu);  // 06082538 mov.l 0x060825CC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0608253Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608253Eu) return; }  // 0608253A jsr @r1 ; nop
    c.r[4] = (uint32_t)(int16_t)ld16(0x060825BCu);  // 0608253E mov.w 0x060825BC,r4
    c.r[1] = 0x2u;  // 06082540 mov #2,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06082542 mov.l r1,@-r15
    c.r[1] = ld32(0x060825D0u);  // 06082544 mov.l 0x060825D0,r1
    c.r[7] = 0x1Cu;  // 06082546 mov #28,r7
    c.r[6] = c.r[8];  // 06082548 mov r8,r6
    { const uint32_t x = c.r[1]; c.pr = 0x0608254Eu; c.r[5] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608254Eu) return; }  // 0608254A jsr @r1 ; mov r9,r5
    c.r[10] = ld32(0x060825D4u);  // 0608254E mov.l 0x060825D4,r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 06082550 mov.b @r10,r1
    c.r[15] += 4;  // 06082552 add #4,r15
    c.r[0] = c.r[1] & 0xFFu;  // 06082554 extu.b r1,r0
    c.t = c.r[0] == 0x47u;  // 06082556 cmp/eq #71,r0
    { const bool k = !c.t; c.r[9] = 0xAu; if (k) { goto L_0608255E; } }  // 06082558 bf/s 0x0608255E ; mov #10,r9
    c.r[9] = 0xEu;  // 0608255C mov #14,r9
L_0608255E:
    c.r[4] = (uint32_t)(int16_t)ld16(0x060825BEu);  // 0608255E mov.w 0x060825BE,r4
    c.r[8] = ld32(0x060825D8u);  // 06082560 mov.l 0x060825D8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06082566u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082566u) return; }  // 06082562 jsr @r8 ; nop
    { const uint32_t x = c.r[8]; c.pr = 0x0608256Au; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608256Au) return; }  // 06082566 jsr @r8 ; mov r9,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0608256Eu; c.r[4] = 0x7u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608256Eu) return; }  // 0608256A jsr @r8 ; mov #7,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0608256E mov.b @r10,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06082570 extu.b r1,r0
    c.t = c.r[0] == 0x47u;  // 06082572 cmp/eq #71,r0
    if (!c.t) { goto L_06082588; }  // 06082574 bf 0x06082588
    c.r[4] = ld32(0x060825DCu);  // 06082576 mov.l 0x060825DC,r4
    c.r[8] = ld32(0x060825E0u);  // 06082578 mov.l 0x060825E0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608257Eu; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608257Eu) return; }  // 0608257A jsr @r8 ; mov #23,r5
    c.r[5] = 0x23u;  // 0608257E mov #35,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06082584u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082584u) return; }  // 06082580 jsr @r8 ; mov r0,r4
    c.r[5] = 0x1Cu; goto L_06082598;  // 06082584 bra 0x06082598 ; mov #28,r5
L_06082588:
    c.r[4] = ld32(0x060825DCu);  // 06082588 mov.l 0x060825DC,r4
    c.r[8] = ld32(0x060825E0u);  // 0608258A mov.l 0x060825E0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06082590u; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082590u) return; }  // 0608258C jsr @r8 ; mov #23,r5
    c.r[5] = 0x23u;  // 06082590 mov #35,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06082596u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082596u) return; }  // 06082592 jsr @r8 ; mov r0,r4
    c.r[5] = 0x1Du;  // 06082596 mov #29,r5
L_06082598:
    { const uint32_t x = c.r[8]; c.pr = 0x0608259Cu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608259Cu) return; }  // 06082598 jsr @r8 ; mov r0,r4
    c.r[1] = ld32(0x060825E4u);  // 0608259C mov.l 0x060825E4,r1
    c.r[6] = 0x0u;  // 0608259E mov #0,r6
    c.r[5] = c.r[0];  // 060825A0 mov r0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x060825A6u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060825A6u) return; }  // 060825A2 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x060825E8u);  // 060825A6 mov.l 0x060825E8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060825ACu; c.r[4] = 0x42u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060825ACu) return; }  // 060825A8 jsr @r1 ; mov #66,r4
    c.r[15] = c.r[14];  // 060825AC mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060825AE lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060825B0 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060825B2 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060825B4 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x060825C0u);  // 060825B6 mov.w 0x060825C0,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060825B8 rts ; mov.l @r15+,r8
}

void f_060825EC(SH2Context& c) {
    ran[1831] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060825EC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060825EE mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060825F0 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060825F2 mov r15,r14
    c.r[1] = ld32(0x06082670u);  // 060825F4 mov.l 0x06082670,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060825FAu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060825FAu) return; }  // 060825F6 jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x06082674u);  // 060825FA mov.l 0x06082674,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06082600u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082600u) return; }  // 060825FC jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x06082678u);  // 06082600 mov.l 0x06082678,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06082606u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082606u) return; }  // 06082602 jsr @r1 ; nop
    c.r[4] = (uint32_t)(int16_t)ld16(0x0608266Au);  // 06082606 mov.w 0x0608266A,r4
    c.r[1] = 0x8u;  // 06082608 mov #8,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0608260A mov.l r1,@-r15
    c.r[1] = ld32(0x0608267Cu);  // 0608260C mov.l 0x0608267C,r1
    c.r[7] = 0x3u;  // 0608260E mov #3,r7
    c.r[6] = 0xBu;  // 06082610 mov #11,r6
    { const uint32_t x = c.r[1]; c.pr = 0x06082616u; c.r[5] = 0x11u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082616u) return; }  // 06082612 jsr @r1 ; mov #17,r5
    c.r[8] = ld32(0x06082680u);  // 06082616 mov.l 0x06082680,r8
    c.r[5] = 0x2u;  // 06082618 mov #2,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0608261Eu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608261Eu) return; }  // 0608261A jsr @r8 ; mov #0,r4
    c.r[5] = 0x0u;  // 0608261E mov #0,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06082624u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082624u) return; }  // 06082620 jsr @r8 ; mov #0,r4
    c.r[5] = 0x1u;  // 06082624 mov #1,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0608262Au; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608262Au) return; }  // 06082626 jsr @r8 ; mov #0,r4
    c.r[5] = 0x3u;  // 0608262A mov #3,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06082630u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082630u) return; }  // 0608262C jsr @r8 ; mov #0,r4
    c.r[3] = 0x4u;  // 06082630 mov #4,r3
    c.r[15] -= 4; st32(c.r[15], c.r[3]);  // 06082632 mov.l r3,@-r15
    c.r[2] = 0x1u;  // 06082634 mov #1,r2
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06082636 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06082638 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 0608263A mov.l r2,@-r15
    c.r[1] = 0x0u;  // 0608263C mov #0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0608263E mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06082640 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06082642 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06082644 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[3]);  // 06082646 mov.l r3,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06082648 mov.l r2,@-r15
    c.r[1] = ld32(0x06082684u);  // 0608264A mov.l 0x06082684,r1
    c.r[7] = 0x2u;  // 0608264C mov #2,r7
    c.r[6] = 0x3u;  // 0608264E mov #3,r6
    c.r[5] = 0xCu;  // 06082650 mov #12,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06082656u; c.r[4] = 0x12u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082656u) return; }  // 06082652 jsr @r1 ; mov #18,r4
    c.r[15] += 44;  // 06082656 add #44,r15
    c.r[1] = ld32(0x06082688u);  // 06082658 mov.l 0x06082688,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0608265Eu; c.r[4] = 0x43u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608265Eu) return; }  // 0608265A jsr @r1 ; mov #67,r4
    c.r[15] = c.r[14];  // 0608265E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06082660 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06082662 mov.l @r15+,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x0608266Cu);  // 06082664 mov.w 0x0608266C,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06082666 rts ; mov.l @r15+,r8
}

void f_0608268C(SH2Context& c) {
    ran[1832] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608268C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0608268E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06082690 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06082692 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06082694 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06082696 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06082698 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608269A sts.l pr,@-r15
    c.r[15] -= 4;  // 0608269C add #-4,r15
    c.r[14] = c.r[15];  // 0608269E mov r15,r14
    c.r[12] = 0x9u;  // 060826A0 mov #9,r12
    c.r[11] = 0xDu;  // 060826A2 mov #13,r11
    c.r[13] = 0x17u;  // 060826A4 mov #23,r13
    c.r[0] = 0x11u;  // 060826A6 mov #17,r0
    st32(c.r[14], c.r[0]);  // 060826A8 mov.l r0,@r14
    c.r[1] = ld32(0x060827B4u);  // 060826AA mov.l 0x060827B4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060826B0u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060826B0u) return; }  // 060826AC jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x060827B8u);  // 060826B0 mov.l 0x060827B8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060826B6u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060826B6u) return; }  // 060826B2 jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x060827BCu);  // 060826B6 mov.l 0x060827BC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060826BCu; c.r[8] = 0x4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060826BCu) return; }  // 060826B8 jsr @r1 ; mov #4,r8
    c.r[10] = (uint32_t)(int16_t)ld16(0x060827B0u);  // 060826BC mov.w 0x060827B0,r10
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060826BE mov.l r8,@-r15
    c.r[9] = ld32(0x060827C0u);  // 060826C0 mov.l 0x060827C0,r9
    c.r[7] = 0x14u;  // 060826C2 mov #20,r7
    c.r[6] = c.r[11];  // 060826C4 mov r11,r6
    c.r[5] = c.r[12];  // 060826C6 mov r12,r5
    { const uint32_t x = c.r[9]; c.pr = 0x060826CCu; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060826CCu) return; }  // 060826C8 jsr @r9 ; mov r10,r4
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060826CC mov.l r8,@-r15
    c.r[7] = 0x3u;  // 060826CE mov #3,r7
    c.r[5] = c.r[13];  // 060826D0 mov r13,r5
    c.r[6] = ld32(c.r[14]);  // 060826D2 mov.l @r14,r6
    { const uint32_t x = c.r[9]; c.pr = 0x060826D8u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060826D8u) return; }  // 060826D4 jsr @r9 ; mov r10,r4
    c.r[1] = ld32(0x060827C4u);  // 060826D8 mov.l 0x060827C4,r1
    c.r[4] = ld32(0x060827C8u);  // 060826DA mov.l 0x060827C8,r4
    c.r[8] = ld32(0x060827CCu);  // 060826DC mov.l 0x060827CC,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060826DE mov.b @r1,r1
    c.r[5] = c.r[13];  // 060826E0 mov r13,r5
    c.r[10] = c.r[1] & 0xFFu;  // 060826E2 extu.b r1,r10
    c.r[9] = c.r[10];  // 060826E4 mov r10,r9
    c.r[9] += 30;  // 060826E6 add #30,r9
    { const uint32_t x = c.r[8]; c.pr = 0x060826ECu; c.r[9] = c.r[9] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060826ECu) return; }  // 060826E8 jsr @r8 ; extu.w r9,r9
    c.r[1] = c.r[0];  // 060826EC mov r0,r1
    c.r[5] = 0x23u;  // 060826EE mov #35,r5
    { const uint32_t x = c.r[8]; c.pr = 0x060826F4u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060826F4u) return; }  // 060826F0 jsr @r8 ; mov r1,r4
    c.r[1] = c.r[0];  // 060826F4 mov r0,r1
    c.r[5] = c.r[9];  // 060826F6 mov r9,r5
    { const uint32_t x = c.r[8]; c.pr = 0x060826FCu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060826FCu) return; }  // 060826F8 jsr @r8 ; mov r1,r4
    c.r[2] = c.r[0];  // 060826FC mov r0,r2
    c.r[1] = ld32(0x060827D0u);  // 060826FE mov.l 0x060827D0,r1
    c.r[6] = 0x0u;  // 06082700 mov #0,r6
    c.r[5] = c.r[2];  // 06082702 mov r2,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06082708u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082708u) return; }  // 06082704 jsr @r1 ; mov #0,r4
    c.t = (c.r[10] & c.r[10]) == 0;  // 06082708 tst r10,r10
    { const bool k = !c.t; c.r[15] += 8; if (k) { goto L_06082714; } }  // 0608270A bf/s 0x06082714 ; add #8,r15
    c.r[1] = ld32(0x060827D4u);  // 0608270E mov.l 0x060827D4,r1
    c.r[5] = 0x2u; goto L_06082732;  // 06082710 bra 0x06082732 ; mov #2,r5
L_06082714:
    c.r[0] = c.r[10];  // 06082714 mov r10,r0
    c.t = c.r[0] == 0x1u;  // 06082716 cmp/eq #1,r0
    { const bool k = !c.t; c.r[5] = 0x0u; if (k) { goto L_06082722; } }  // 06082718 bf/s 0x06082722 ; mov #0,r5
    c.r[1] = ld32(0x060827D4u);  // 0608271C mov.l 0x060827D4,r1
    goto L_06082732;  // 0608271E bra 0x06082732 ; nop
L_06082722:
    c.t = c.r[0] == 0x2u;  // 06082722 cmp/eq #2,r0
    { const bool k = !c.t; c.r[5] = 0x1u; if (k) { goto L_0608272E; } }  // 06082724 bf/s 0x0608272E ; mov #1,r5
    c.r[1] = ld32(0x060827D4u);  // 06082728 mov.l 0x060827D4,r1
    goto L_06082732;  // 0608272A bra 0x06082732 ; nop
L_0608272E:
    c.r[1] = ld32(0x060827D4u);  // 0608272E mov.l 0x060827D4,r1
    c.r[5] = 0x3u;  // 06082730 mov #3,r5
L_06082732:
    { const uint32_t x = c.r[1]; c.pr = 0x06082736u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082736u) return; }  // 06082732 jsr @r1 ; mov #0,r4
    c.r[10] += 30;  // 06082736 add #30,r10
    c.r[9] = c.r[10] & 0xFFFFu;  // 06082738 extu.w r10,r9
    c.r[4] = ld32(0x060827C8u);  // 0608273A mov.l 0x060827C8,r4
    c.r[8] = ld32(0x060827CCu);  // 0608273C mov.l 0x060827CC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06082742u; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082742u) return; }  // 0608273E jsr @r8 ; mov #23,r5
    c.r[1] = c.r[0];  // 06082742 mov r0,r1
    c.r[5] = 0x23u;  // 06082744 mov #35,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0608274Au; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608274Au) return; }  // 06082746 jsr @r8 ; mov r1,r4
    c.r[1] = c.r[0];  // 0608274A mov r0,r1
    c.r[5] = c.r[9];  // 0608274C mov r9,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06082752u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082752u) return; }  // 0608274E jsr @r8 ; mov r1,r4
    c.r[2] = c.r[0];  // 06082752 mov r0,r2
    c.r[1] = ld32(0x060827D0u);  // 06082754 mov.l 0x060827D0,r1
    c.r[6] = 0x0u;  // 06082756 mov #0,r6
    c.r[5] = c.r[2];  // 06082758 mov r2,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0608275Eu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608275Eu) return; }  // 0608275A jsr @r1 ; mov #0,r4
    c.r[0] = 0x3u;  // 0608275E mov #3,r0
    c.r[0] += c.r[14];  // 06082760 add r14,r0
    c.r[13] += 1;  // 06082762 add #1,r13
    c.r[4] = c.r[13] & 0xFFu;  // 06082764 extu.b r13,r4
    c.r[7] = 0x2u;  // 06082766 mov #2,r7
    c.r[2] = 0x1u;  // 06082768 mov #1,r2
    c.r[3] = ld32(c.r[14]);  // 0608276A mov.l @r14,r3
    c.r[1] = 0x0u;  // 0608276C mov #0,r1
    c.r[3] += 1;  // 0608276E add #1,r3
    st32(c.r[14], c.r[3]);  // 06082770 mov.l r3,@r14
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06082772 mov.b @r0,r0
    c.r[6] = 0x5u;  // 06082774 mov #5,r6
    c.r[5] = c.r[0] & 0xFFu;  // 06082776 extu.b r0,r5
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 06082778 mov.l r7,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 0608277A mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 0608277C mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 0608277E mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06082780 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06082782 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06082784 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06082786 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 06082788 mov.l r7,@-r15
    c.r[1] = ld32(0x060827D8u);  // 0608278A mov.l 0x060827D8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06082790u; c.r[15] -= 4; st32(c.r[15], c.r[2]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082790u) return; }  // 0608278C jsr @r1 ; mov.l r2,@-r15
    c.r[15] += 40;  // 06082790 add #40,r15
    c.r[1] = ld32(0x060827DCu);  // 06082792 mov.l 0x060827DC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06082798u; c.r[4] = 0x44u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082798u) return; }  // 06082794 jsr @r1 ; mov #68,r4
    c.r[14] += 4;  // 06082798 add #4,r14
    c.r[15] = c.r[14];  // 0608279A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608279C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608279E mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060827A0 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060827A2 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060827A4 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060827A6 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060827A8 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x060827B2u);  // 060827AA mov.w 0x060827B2,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060827AC rts ; mov.l @r15+,r8
}

void f_060827E0(SH2Context& c) {
    ran[1833] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060827E0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060827E2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060827E4 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060827E6 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060827E8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060827EA sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060827EC mov r15,r14
    c.r[10] = 0x6u;  // 060827EE mov #6,r10
    c.r[1] = ld32(0x06082890u);  // 060827F0 mov.l 0x06082890,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060827F6u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060827F6u) return; }  // 060827F2 jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x06082894u);  // 060827F6 mov.l 0x06082894,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060827FCu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060827FCu) return; }  // 060827F8 jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x06082898u);  // 060827FC mov.l 0x06082898,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06082802u; c.r[9] = 0xBu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082802u) return; }  // 060827FE jsr @r1 ; mov #11,r9
    c.r[3] = ld32(0x0608289Cu);  // 06082802 mov.l 0x0608289C,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06082804 mov.b @r3,r2
    c.r[1] = (uint32_t)(int32_t)(int8_t)c.r[2];  // 06082806 exts.b r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06082808 tst r1,r1
    { const bool k = c.t; c.r[1] = 0x2u; if (k) { goto L_06082828; } }  // 0608280A bt/s 0x06082828 ; mov #2,r1
    c.r[1] = c.r[9];  // 0608280E mov r9,r1
    c.r[1] -= c.r[2];  // 06082810 sub r2,r1
    c.r[9] = c.r[1] & 0xFFu;  // 06082812 extu.b r1,r9
    c.r[4] = (uint32_t)(int16_t)ld16(0x06082888u);  // 06082814 mov.w 0x06082888,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06082816 mov.b @r3,r1
    c.r[7] = 0x19u;  // 06082818 mov #25,r7
    c.r[6] = c.r[9];  // 0608281A mov r9,r6
    c.r[1] += c.r[1];  // 0608281C add r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0608281E extu.b r1,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06082820 mov.l r1,@-r15
    c.r[1] = ld32(0x060828A0u);  // 06082822 mov.l 0x060828A0,r1
    c.r[5] = c.r[10]; goto L_06082834;  // 06082824 bra 0x06082834 ; mov r10,r5
L_06082828:
    c.r[4] = (uint32_t)(int16_t)ld16(0x06082888u);  // 06082828 mov.w 0x06082888,r4
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0608282A mov.l r1,@-r15
    c.r[1] = ld32(0x060828A0u);  // 0608282C mov.l 0x060828A0,r1
    c.r[7] = 0x19u;  // 0608282E mov #25,r7
    c.r[6] = c.r[9];  // 06082830 mov r9,r6
    c.r[5] = c.r[10];  // 06082832 mov r10,r5
L_06082834:
    { const uint32_t x = c.r[1]; c.pr = 0x06082838u; c.r[11] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082838u) return; }  // 06082834 jsr @r1 ; mov #1,r11
    c.r[4] = (uint32_t)(int16_t)ld16(0x0608288Au);  // 06082838 mov.w 0x0608288A,r4
    c.r[8] = ld32(0x060828A4u);  // 0608283A mov.l 0x060828A4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06082840u; c.r[15] += 4; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082840u) return; }  // 0608283C jsr @r8 ; add #4,r15
    c.r[10] |= c.r[11];  // 06082840 or r11,r10
    { const uint32_t x = c.r[8]; c.pr = 0x06082846u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082846u) return; }  // 06082842 jsr @r8 ; mov r10,r4
    c.r[9] += 1;  // 06082846 add #1,r9
    { const uint32_t x = c.r[8]; c.pr = 0x0608284Cu; c.r[4] = c.r[9] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608284Cu) return; }  // 06082848 jsr @r8 ; extu.b r9,r4
    c.r[1] = ld32(0x060828A8u);  // 0608284C mov.l 0x060828A8,r1
    c.r[4] = ld32(0x060828ACu);  // 0608284E mov.l 0x060828AC,r4
    c.r[8] = ld32(0x060828B0u);  // 06082850 mov.l 0x060828B0,r8
    c.r[9] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06082852 mov.b @r1,r9
    c.r[5] = 0x17u;  // 06082854 mov #23,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0608285Au; c.r[9] = c.r[9] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608285Au) return; }  // 06082856 jsr @r8 ; extu.w r9,r9
    c.r[5] = 0x23u;  // 0608285A mov #35,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06082860u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082860u) return; }  // 0608285C jsr @r8 ; mov r0,r4
    c.r[5] = c.r[9];  // 06082860 mov r9,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06082866u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082866u) return; }  // 06082862 jsr @r8 ; mov r0,r4
    c.r[1] = ld32(0x060828B4u);  // 06082866 mov.l 0x060828B4,r1
    c.r[6] = 0x0u;  // 06082868 mov #0,r6
    c.r[5] = c.r[0];  // 0608286A mov r0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06082870u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082870u) return; }  // 0608286C jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x060828B8u);  // 06082870 mov.l 0x060828B8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06082876u; c.r[4] = 0x42u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082876u) return; }  // 06082872 jsr @r1 ; mov #66,r4
    c.r[15] = c.r[14];  // 06082876 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06082878 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608287A mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0608287C mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0608287E mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06082880 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0608288Cu);  // 06082882 mov.w 0x0608288C,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06082884 rts ; mov.l @r15+,r8
}

void f_060828BC(SH2Context& c) {
    ran[1834] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060828BC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060828BE mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060828C0 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060828C2 mov r15,r14
    c.r[1] = ld32(0x06082924u);  // 060828C4 mov.l 0x06082924,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060828CAu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060828CAu) return; }  // 060828C6 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06082928u);  // 060828CA mov.l 0x06082928,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060828D0u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060828D0u) return; }  // 060828CC jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x0608292Cu);  // 060828D0 mov.l 0x0608292C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060828D6u; c.r[8] = 0x8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060828D6u) return; }  // 060828D2 jsr @r1 ; mov #8,r8
    c.r[4] = (uint32_t)(int16_t)ld16(0x0608291Eu);  // 060828D6 mov.w 0x0608291E,r4
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060828D8 mov.l r8,@-r15
    c.r[1] = ld32(0x06082930u);  // 060828DA mov.l 0x06082930,r1
    c.r[7] = 0x7u;  // 060828DC mov #7,r7
    c.r[6] = 0x7u;  // 060828DE mov #7,r6
    { const uint32_t x = c.r[1]; c.pr = 0x060828E4u; c.r[5] = 0xFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060828E4u) return; }  // 060828E0 jsr @r1 ; mov #15,r5
    c.r[3] = 0x4u;  // 060828E4 mov #4,r3
    c.r[15] -= 4; st32(c.r[15], c.r[3]);  // 060828E6 mov.l r3,@-r15
    c.r[2] = 0x1u;  // 060828E8 mov #1,r2
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 060828EA mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 060828EC mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 060828EE mov.l r2,@-r15
    c.r[1] = 0x0u;  // 060828F0 mov #0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060828F2 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 060828F4 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060828F6 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060828F8 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[3]);  // 060828FA mov.l r3,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 060828FC mov.l r2,@-r15
    c.r[1] = ld32(0x06082934u);  // 060828FE mov.l 0x06082934,r1
    c.r[7] = 0x2u;  // 06082900 mov #2,r7
    c.r[6] = 0x7u;  // 06082902 mov #7,r6
    c.r[5] = c.r[8];  // 06082904 mov r8,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0608290Au; c.r[4] = 0x10u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608290Au) return; }  // 06082906 jsr @r1 ; mov #16,r4
    c.r[15] += 44;  // 0608290A add #44,r15
    c.r[1] = ld32(0x06082938u);  // 0608290C mov.l 0x06082938,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06082912u; c.r[4] = 0x45u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082912u) return; }  // 0608290E jsr @r1 ; mov #69,r4
    c.r[15] = c.r[14];  // 06082912 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06082914 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06082916 mov.l @r15+,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x06082920u);  // 06082918 mov.w 0x06082920,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0608291A rts ; mov.l @r15+,r8
}

void f_0608293C(SH2Context& c) {
    ran[1835] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608293C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608293E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06082940 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06082942 mov r15,r14
    c.r[1] = ld32(0x060829D4u);  // 06082944 mov.l 0x060829D4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0608294Au; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608294Au) return; }  // 06082946 jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x060829D8u);  // 0608294A mov.l 0x060829D8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06082950u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082950u) return; }  // 0608294C jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x060829DCu);  // 06082950 mov.l 0x060829DC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06082956u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082956u) return; }  // 06082952 jsr @r1 ; nop
    c.r[4] = (uint32_t)(int16_t)ld16(0x060829CCu);  // 06082956 mov.w 0x060829CC,r4
    c.r[1] = 0x4u;  // 06082958 mov #4,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0608295A mov.l r1,@-r15
    c.r[1] = ld32(0x060829E0u);  // 0608295C mov.l 0x060829E0,r1
    c.r[7] = 0x5u;  // 0608295E mov #5,r7
    c.r[6] = 0xEu;  // 06082960 mov #14,r6
    { const uint32_t x = c.r[1]; c.pr = 0x06082966u; c.r[5] = 0xBu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082966u) return; }  // 06082962 jsr @r1 ; mov #11,r5
    c.r[4] = (uint32_t)(int16_t)ld16(0x060829CEu);  // 06082966 mov.w 0x060829CE,r4
    c.r[8] = ld32(0x060829E4u);  // 06082968 mov.l 0x060829E4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608296Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608296Eu) return; }  // 0608296A jsr @r8 ; nop
    { const uint32_t x = c.r[8]; c.pr = 0x06082972u; c.r[4] = 0xCu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082972u) return; }  // 0608296E jsr @r8 ; mov #12,r4
    { const uint32_t x = c.r[8]; c.pr = 0x06082976u; c.r[4] = 0xFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082976u) return; }  // 06082972 jsr @r8 ; mov #15,r4
    c.r[4] = ld32(0x060829E8u);  // 06082976 mov.l 0x060829E8,r4
    c.r[8] = ld32(0x060829ECu);  // 06082978 mov.l 0x060829EC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608297Eu; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608297Eu) return; }  // 0608297A jsr @r8 ; mov #23,r5
    c.r[5] = 0x23u;  // 0608297E mov #35,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06082984u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082984u) return; }  // 06082980 jsr @r8 ; mov r0,r4
    c.r[5] = 0x33u;  // 06082984 mov #51,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0608298Au; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608298Au) return; }  // 06082986 jsr @r8 ; mov r0,r4
    c.r[1] = ld32(0x060829F0u);  // 0608298A mov.l 0x060829F0,r1
    c.r[6] = 0x0u;  // 0608298C mov #0,r6
    c.r[5] = c.r[0];  // 0608298E mov r0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06082994u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082994u) return; }  // 06082990 jsr @r1 ; mov #0,r4
    c.r[7] = 0x2u;  // 06082994 mov #2,r7
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 06082996 mov.l r7,@-r15
    c.r[2] = 0x1u;  // 06082998 mov #1,r2
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 0608299A mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 0608299C mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 0608299E mov.l r2,@-r15
    c.r[1] = 0x0u;  // 060829A0 mov #0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060829A2 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 060829A4 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060829A6 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060829A8 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 060829AA mov.l r7,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 060829AC mov.l r2,@-r15
    c.r[1] = ld32(0x060829F4u);  // 060829AE mov.l 0x060829F4,r1
    c.r[6] = 0x5u;  // 060829B0 mov #5,r6
    c.r[5] = 0xFu;  // 060829B2 mov #15,r5
    { const uint32_t x = c.r[1]; c.pr = 0x060829B8u; c.r[4] = 0xCu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060829B8u) return; }  // 060829B4 jsr @r1 ; mov #12,r4
    c.r[15] += 44;  // 060829B8 add #44,r15
    c.r[1] = ld32(0x060829F8u);  // 060829BA mov.l 0x060829F8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060829C0u; c.r[4] = 0x42u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060829C0u) return; }  // 060829BC jsr @r1 ; mov #66,r4
    c.r[15] = c.r[14];  // 060829C0 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060829C2 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060829C4 mov.l @r15+,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x060829D0u);  // 060829C6 mov.w 0x060829D0,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060829C8 rts ; mov.l @r15+,r8
}

void f_060829FC(SH2Context& c) {
    ran[1836] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060829FC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060829FE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06082A00 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06082A02 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06082A04 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06082A06 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06082A08 sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x06082ADAu);  // 06082A0A mov.w 0x06082ADA,r3
    c.r[15] += c.r[3];  // 06082A0C add r3,r15
    c.r[14] = c.r[15];  // 06082A0E mov r15,r14
    c.r[1] = ld32(0x06082AE4u);  // 06082A10 mov.l 0x06082AE4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06082A16u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082A16u) return; }  // 06082A12 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06082AE8u);  // 06082A16 mov.l 0x06082AE8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06082A1Cu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082A1Cu) return; }  // 06082A18 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06082AECu);  // 06082A1C mov.l 0x06082AEC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06082A22u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082A22u) return; }  // 06082A1E jsr @r1 ; nop
    c.r[3] = ld32(0x06082AF0u);  // 06082A22 mov.l 0x06082AF0,r3
    c.r[2] = c.r[3];  // 06082A24 mov r3,r2
    c.r[2] += 112;  // 06082A26 add #112,r2
    c.r[1] = 0x47u;  // 06082A28 mov #71,r1
    st16(c.r[2], c.r[1]);  // 06082A2A mov.w r1,@r2
    c.r[3] += 114;  // 06082A2C add #114,r3
    c.r[1] = 0xFFFFFFC7u;  // 06082A2E mov #-57,r1
    st16(c.r[3], c.r[1]);  // 06082A30 mov.w r1,@r3
    c.r[1] = ld32(0x06082AF4u);  // 06082A32 mov.l 0x06082AF4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06082A34 mov.b @r1,r1
    c.r[6] = (uint32_t)(int16_t)ld16(0x06082ADCu);  // 06082A36 mov.w 0x06082ADC,r6
    c.r[5] = c.r[1] & 0xFFu;  // 06082A38 extu.b r1,r5
    c.t = c.r[5] == c.r[6];  // 06082A3A cmp/eq r6,r5
    { const bool k = c.t; c.r[2] = 0x0u; if (k) { goto L_06082A4E; } }  // 06082A3C bt/s 0x06082A4E ; mov #0,r2
    c.r[1] = ld32(0x06082AF8u);  // 06082A40 mov.l 0x06082AF8,r1
    c.r[4] = ld32(c.r[1]);  // 06082A42 mov.l @r1,r4
    c.r[1] = ld32(0x06082AFCu);  // 06082A44 mov.l 0x06082AFC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06082A4Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082A4Au) return; }  // 06082A46 jsr @r1 ; nop
    goto L_06082A5E;  // 06082A4A bra 0x06082A5E ; nop
L_06082A4E:
    c.r[1] = ld32(0x06082AF8u);  // 06082A4E mov.l 0x06082AF8,r1
    c.r[3] = ld32(c.r[1]);  // 06082A50 mov.l @r1,r3
    st16(c.r[3], c.r[2]);  // 06082A52 mov.w r2,@r3
    c.r[1] = c.r[3];  // 06082A54 mov r3,r1
    c.r[1] += 34;  // 06082A56 add #34,r1
    st16(c.r[1], c.r[2]);  // 06082A58 mov.w r2,@r1
    c.r[3] += 32;  // 06082A5A add #32,r3
    st16(c.r[3], c.r[2]);  // 06082A5C mov.w r2,@r3
L_06082A5E:
    c.r[1] = ld32(0x06082B00u);  // 06082A5E mov.l 0x06082B00,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06082A60 mov.b @r1,r1
    c.r[6] = (uint32_t)(int16_t)ld16(0x06082ADCu);  // 06082A62 mov.w 0x06082ADC,r6
    c.r[1] = c.r[1] & 0xFFu;  // 06082A64 extu.b r1,r1
    c.t = c.r[1] == c.r[6];  // 06082A66 cmp/eq r6,r1
    { const bool k = c.t; c.r[2] = c.r[14]; if (k) { goto L_06082B10; } }  // 06082A68 bt/s 0x06082B10 ; mov r14,r2
    c.r[5] = c.r[1] & 0xFFu;  // 06082A6C extu.b r1,r5
    c.r[1] = ld32(0x06082AFCu);  // 06082A6E mov.l 0x06082AFC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06082A74u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082A74u) return; }  // 06082A70 jsr @r1 ; mov r14,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x06082ADEu);  // 06082A74 mov.w 0x06082ADE,r1
    c.r[0] = c.r[14];  // 06082A76 mov r14,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06082A78 mov.b @(r0,r1),r1
    c.r[1] >>= 2;  // 06082A7A shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06082A7C shlr r1
    c.r[0] = 0x1u;  // 06082A7E mov #1,r0
    c.r[1] &= c.r[0];  // 06082A80 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06082A82 tst r1,r1
    { const bool k = c.t; c.r[5] = 0x14u; if (k) { goto L_06082ABE; } }  // 06082A84 bt/s 0x06082ABE ; mov #20,r5
    c.r[1] = ld32(0x06082B04u);  // 06082A88 mov.l 0x06082B04,r1
    c.r[1] = ld32(c.r[1]);  // 06082A8A mov.l @r1,r1
    c.r[1] += 18;  // 06082A8C add #18,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06082A8E mov.w @r1,r4
    c.r[0] = ld32(0x06082B08u);  // 06082A90 mov.l 0x06082B08,r0
    c.r[4] <<= 16;  // 06082A92 shll16 r4
    c.r[4] <<= 2;  // 06082A94 shll2 r4
    c.r[4] += c.r[4];  // 06082A96 add r4,r4
    c.r[4] <<= 2;  // 06082A98 shll2 r4
    c.r[4] >>= 16;  // 06082A9A shlr16 r4
    c.r[4] <<= 2;  // 06082A9C shll2 r4
    { const uint32_t x = c.r[0]; c.pr = 0x06082AA2u; c.r[4] >>= 8; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082AA2u) return; }  // 06082A9E jsr @r0 ; shlr8 r4
    c.r[2] = c.r[0];  // 06082AA2 mov r0,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06082AE0u);  // 06082AA4 mov.w 0x06082AE0,r1
    c.r[0] = c.r[14];  // 06082AA6 mov r14,r0
    c.r[6] = 0x1u;  // 06082AA8 mov #1,r6
    c.r[5] = 0x14u;  // 06082AAA mov #20,r5
    c.r[7] = ld32(c.r[0] + c.r[1]);  // 06082AAC mov.l @(r0,r1),r7
    c.r[4] = 0x0u;  // 06082AAE mov #0,r4
    c.r[7] <<= 8;  // 06082AB0 shll8 r7
    c.r[7] += c.r[7];  // 06082AB2 add r7,r7
    c.r[7] >>= 16;  // 06082AB4 shlr16 r7
    c.r[7] += c.r[7];  // 06082AB6 add r7,r7
    c.r[7] >>= 8;  // 06082AB8 shlr8 r7
    c.r[1] = c.r[2] & 0xFFu; goto L_06082AD0;  // 06082ABA bra 0x06082AD0 ; extu.b r2,r1
L_06082ABE:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06082AE0u);  // 06082ABE mov.w 0x06082AE0,r0
    c.r[7] = ld32(c.r[0] + c.r[14]);  // 06082AC0 mov.l @(r0,r14),r7
    c.r[6] = 0x1u;  // 06082AC2 mov #1,r6
    c.r[4] = 0x0u;  // 06082AC4 mov #0,r4
    c.r[7] <<= 8;  // 06082AC6 shll8 r7
    c.r[7] += c.r[7];  // 06082AC8 add r7,r7
    c.r[7] >>= 16;  // 06082ACA shlr16 r7
    c.r[7] += c.r[7];  // 06082ACC add r7,r7
    c.r[7] >>= 8;  // 06082ACE shlr8 r7
L_06082AD0:
    c.r[0] = ld32(0x06082B0Cu);  // 06082AD0 mov.l 0x06082B0C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06082AD6u; c.r[15] -= 4; st32(c.r[15], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082AD6u) return; }  // 06082AD2 jsr @r0 ; mov.l r1,@-r15
    c.r[15] += 4; goto L_06082B1E;  // 06082AD6 bra 0x06082B1E ; add #4,r15
L_06082B10:
    c.r[1] = 0x0u;  // 06082B10 mov #0,r1
    st16(c.r[14], c.r[1]);  // 06082B12 mov.w r1,@r14
    c.r[2] += 34;  // 06082B14 add #34,r2
    st16(c.r[2], c.r[1]);  // 06082B16 mov.w r1,@r2
    c.r[2] = c.r[14];  // 06082B18 mov r14,r2
    c.r[2] += 32;  // 06082B1A add #32,r2
    st16(c.r[2], c.r[1]);  // 06082B1C mov.w r1,@r2
L_06082B1E:
    c.r[9] = ld32(0x06082C44u);  // 06082B1E mov.l 0x06082C44,r9
    c.r[1] = ld32(c.r[9]);  // 06082B20 mov.l @r9,r1
    c.r[10] = (uint32_t)(int16_t)ld16(0x06082C3Au);  // 06082B22 mov.w 0x06082C3A,r10
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06082B24 mov.w @r1,r4
    c.r[5] = c.r[10];  // 06082B26 mov r10,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x06082C3Cu);  // 06082B28 mov.w 0x06082C3C,r1
    c.r[4] += c.r[1];  // 06082B2A add r1,r4
    c.r[1] = ld32(0x06082C48u);  // 06082B2C mov.l 0x06082C48,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06082B32u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082B32u) return; }  // 06082B2E jsr @r1 ; extu.w r4,r4
    c.r[8] = ld32(0x06082C4Cu);  // 06082B32 mov.l 0x06082C4C,r8
    c.r[1] = ld32(c.r[9]);  // 06082B34 mov.l @r9,r1
    c.r[5] = 0x0u;  // 06082B36 mov #0,r5
    c.r[1] += 2;  // 06082B38 add #2,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06082B3A mov.b @r1,r6
    c.r[4] = 0x0u;  // 06082B3C mov #0,r4
    { const uint32_t x = c.r[8]; c.pr = 0x06082B42u; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082B42u) return; }  // 06082B3E jsr @r8 ; extu.b r6,r6
    c.r[1] = c.r[14];  // 06082B42 mov r14,r1
    c.r[1] += 26;  // 06082B44 add #26,r1
    c.r[5] = 0x0u;  // 06082B46 mov #0,r5
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06082B48 mov.w @r1,r6
    c.r[4] = 0x0u;  // 06082B4A mov #0,r4
    { const uint32_t x = c.r[8]; c.pr = 0x06082B50u; c.r[6] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082B50u) return; }  // 06082B4C jsr @r8 ; extu.w r6,r6
    c.r[1] = ld32(c.r[9]);  // 06082B50 mov.l @r9,r1
    c.r[1] += 3;  // 06082B52 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06082B54 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06082B56 mov r1,r0
    c.r[0] >>= 2;  // 06082B58 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06082B5A shlr r0
    c.r[0] &= 0x1u;  // 06082B5C and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06082B5E tst r0,r0
    if (!c.t) { goto L_06082BB2; }  // 06082B60 bf 0x06082BB2
    c.r[4] = ld32(0x06082C50u);  // 06082B62 mov.l 0x06082C50,r4
    c.r[8] = ld32(0x06082C54u);  // 06082B64 mov.l 0x06082C54,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06082B6Au; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082B6Au) return; }  // 06082B66 jsr @r8 ; mov #23,r5
    c.r[1] = c.r[0];  // 06082B6A mov r0,r1
    c.r[5] = 0x23u;  // 06082B6C mov #35,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06082B72u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082B72u) return; }  // 06082B6E jsr @r8 ; mov r1,r4
    c.r[1] = c.r[0];  // 06082B72 mov r0,r1
    c.r[5] = 0x31u;  // 06082B74 mov #49,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06082B7Au; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082B7Au) return; }  // 06082B76 jsr @r8 ; mov r1,r4
    c.r[2] = c.r[0];  // 06082B7A mov r0,r2
    c.r[1] = ld32(0x06082C58u);  // 06082B7C mov.l 0x06082C58,r1
    c.r[6] = 0x0u;  // 06082B7E mov #0,r6
    c.r[5] = c.r[2];  // 06082B80 mov r2,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06082B86u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082B86u) return; }  // 06082B82 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(c.r[9]);  // 06082B86 mov.l @r9,r1
    c.r[1] += 8;  // 06082B88 add #8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06082B8A mov.b @r1,r1
    c.r[5] = c.r[1] & 0xFFu;  // 06082B8C extu.b r1,r5
    c.r[1] = ld32(0x06082C5Cu);  // 06082B8E mov.l 0x06082C5C,r1
    c.r[2] = ld32(c.r[1]);  // 06082B90 mov.l @r1,r2
    c.r[1] = c.r[5];  // 06082B92 mov r5,r1
    c.r[1] += c.r[1];  // 06082B94 add r1,r1
    c.r[1] += c.r[5];  // 06082B96 add r5,r1
    c.r[1] <<= 2;  // 06082B98 shll2 r1
    c.r[0] = c.r[1];  // 06082B9A mov r1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 06082B9C mov.w @(r0,r2),r1
    c.r[2] = c.r[1] & 0xFFFFu;  // 06082B9E extu.w r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06082C3Eu);  // 06082BA0 mov.w 0x06082C3E,r1
    c.t = c.r[2] == c.r[1];  // 06082BA2 cmp/eq r1,r2
    if (c.t) { goto L_06082C1A; }  // 06082BA4 bt 0x06082C1A
    c.r[1] = (uint32_t)(int16_t)ld16(0x06082C40u);  // 06082BA6 mov.w 0x06082C40,r1
    c.t = c.r[2] == c.r[1];  // 06082BA8 cmp/eq r1,r2
    if (c.t) { goto L_06082C1A; }  // 06082BAA bt 0x06082C1A
    c.r[5] = c.r[10];  // 06082BAC mov r10,r5
    goto L_06082C1A;  // 06082BAE bra 0x06082C1A ; nop
L_06082BB2:
    c.r[4] = ld32(0x06082C50u);  // 06082BB2 mov.l 0x06082C50,r4
    c.r[8] = ld32(0x06082C54u);  // 06082BB4 mov.l 0x06082C54,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06082BBAu; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082BBAu) return; }  // 06082BB6 jsr @r8 ; mov #23,r5
    c.r[5] = 0x23u;  // 06082BBA mov #35,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06082BC0u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082BC0u) return; }  // 06082BBC jsr @r8 ; mov r0,r4
    c.r[5] = 0x32u;  // 06082BC0 mov #50,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06082BC6u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082BC6u) return; }  // 06082BC2 jsr @r8 ; mov r0,r4
    c.r[1] = ld32(0x06082C58u);  // 06082BC6 mov.l 0x06082C58,r1
    c.r[6] = 0x0u;  // 06082BC8 mov #0,r6
    c.r[5] = c.r[0];  // 06082BCA mov r0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06082BD0u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082BD0u) return; }  // 06082BCC jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06082C60u);  // 06082BD0 mov.l 0x06082C60,r1
    c.r[5] = c.r[10];  // 06082BD2 mov r10,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06082BD4 mov.b @r1,r1
    c.r[6] = 0x7Fu;  // 06082BD6 mov #127,r6
    c.r[3] = c.r[1] & 0xFFu;  // 06082BD8 extu.b r1,r3
    c.r[1] = ld32(0x06082C5Cu);  // 06082BDA mov.l 0x06082C5C,r1
    c.r[7] = ld32(c.r[1]);  // 06082BDC mov.l @r1,r7
    c.r[4] = 0x0u;  // 06082BDE mov #0,r4
L_06082BE0:
    c.r[2] = 0x0u;  // 06082BE0 mov #0,r2
    c.r[1] = c.r[2];  // 06082BE2 mov r2,r1
L_06082BE4:
    c.r[1] += c.r[1];  // 06082BE4 add r1,r1
    c.r[1] += c.r[2];  // 06082BE6 add r2,r1
    c.r[1] <<= 2;  // 06082BE8 shll2 r1
    c.r[1] += c.r[7];  // 06082BEA add r7,r1
    c.r[1] += 8;  // 06082BEC add #8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06082BEE mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06082BF0 extu.b r1,r1
    c.t = c.r[1] == c.r[3];  // 06082BF2 cmp/eq r3,r1
    { const bool k = !c.t; c.t = (c.r[3] & c.r[3]) == 0; if (k) { goto L_06082C04; } }  // 06082BF4 bf/s 0x06082C04 ; tst r3,r3
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_06082C06; } }  // 06082BF8 bt/s 0x06082C06 ; mov r2,r1
    c.r[5] = c.r[2];  // 06082BFC mov r2,r5
    c.r[4] = 0x1u;  // 06082BFE mov #1,r4
    c.r[3] = c.r[5]; goto L_06082C10;  // 06082C00 bra 0x06082C10 ; mov r5,r3
L_06082C04:
    c.r[1] = c.r[2];  // 06082C04 mov r2,r1
L_06082C06:
    c.r[1] += 1;  // 06082C06 add #1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 06082C08 extu.b r1,r2
    c.t = c.r[2] > c.r[6];  // 06082C0A cmp/hi r6,r2
    { const bool k = !c.t; c.r[1] = c.r[2]; if (k) { SH2_POLL(c); goto L_06082BE4; } }  // 06082C0C bf/s 0x06082BE4 ; mov r2,r1
L_06082C10:
    c.r[0] = c.r[4];  // 06082C10 mov r4,r0
    c.t = c.r[0] == 0x1u;  // 06082C12 cmp/eq #1,r0
    { const bool k = c.t; c.r[4] = 0x0u; if (k) { SH2_POLL(c); goto L_06082BE0; } }  // 06082C14 bt/s 0x06082BE0 ; mov #0,r4
    c.r[5] = c.r[5] & 0xFFu;  // 06082C18 extu.b r5,r5
L_06082C1A:
    c.r[3] = (uint32_t)(int16_t)ld16(0x06082C3Au);  // 06082C1A mov.w 0x06082C3A,r3
    c.t = c.r[5] == c.r[3];  // 06082C1C cmp/eq r3,r5
    if (c.t) { goto L_06082C64; }  // 06082C1E bt 0x06082C64
    c.r[1] = ld32(0x06082C5Cu);  // 06082C20 mov.l 0x06082C5C,r1
    c.r[2] = ld32(c.r[1]);  // 06082C22 mov.l @r1,r2
    c.r[1] = c.r[5];  // 06082C24 mov r5,r1
    c.r[1] += c.r[1];  // 06082C26 add r1,r1
    c.r[1] += c.r[5];  // 06082C28 add r5,r1
    c.r[1] <<= 2;  // 06082C2A shll2 r1
    c.r[0] = c.r[1];  // 06082C2C mov r1,r0
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 06082C2E mov.w @(r0,r2),r4
    c.r[5] = c.r[3];  // 06082C30 mov r3,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x06082C3Cu);  // 06082C32 mov.w 0x06082C3C,r1
    c.r[4] += c.r[1];  // 06082C34 add r1,r4
    c.r[4] = c.r[4] & 0xFFFFu; goto L_06082C66;  // 06082C36 bra 0x06082C66 ; extu.w r4,r4
L_06082C64:
    c.r[4] = ld32(0x06082DF8u);  // 06082C64 mov.l 0x06082DF8,r4
L_06082C66:
    c.r[1] = ld32(0x06082DFCu);  // 06082C66 mov.l 0x06082DFC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06082C6Cu; c.r[8] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082C6Cu) return; }  // 06082C68 jsr @r1 ; mov r14,r8
    c.r[5] = (uint32_t)(int16_t)ld16(0x06082DECu);  // 06082C6C mov.w 0x06082DEC,r5
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[14]);  // 06082C6E mov.w @r14,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x06082DEEu);  // 06082C70 mov.w 0x06082DEE,r1
    c.r[4] += c.r[1];  // 06082C72 add r1,r4
    c.r[1] = ld32(0x06082DFCu);  // 06082C74 mov.l 0x06082DFC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06082C7Au; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082C7Au) return; }  // 06082C76 jsr @r1 ; extu.w r4,r4
    c.r[8] += 32;  // 06082C7A add #32,r8
    c.r[1] = ld32(0x06082E00u);  // 06082C7C mov.l 0x06082E00,r1
    c.r[5] = 0x0u;  // 06082C7E mov #0,r5
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06082C80 mov.w @r8,r6
    c.r[4] = 0x0u;  // 06082C82 mov #0,r4
    { const uint32_t x = c.r[1]; c.pr = 0x06082C88u; c.r[6] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082C88u) return; }  // 06082C84 jsr @r1 ; extu.w r6,r6
    c.r[4] = (uint32_t)(int16_t)ld16(0x06082DF0u);  // 06082C88 mov.w 0x06082DF0,r4
    c.r[9] = ld32(0x06082E04u);  // 06082C8A mov.l 0x06082E04,r9
    { const uint32_t x = c.r[9]; c.pr = 0x06082C90u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082C90u) return; }  // 06082C8C jsr @r9 ; nop
    c.r[1] = ld32(0x06082E08u);  // 06082C90 mov.l 0x06082E08,r1
    c.r[1] = ld32(c.r[1]);  // 06082C92 mov.l @r1,r1
    c.r[1] += 20;  // 06082C94 add #20,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06082C96 mov.w @r1,r2
    c.r[1] = c.r[14];  // 06082C98 mov r14,r1
    c.r[1] += 34;  // 06082C9A add #34,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06082C9C mov.w @r1,r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 06082C9E extu.w r2,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 06082CA0 extu.w r1,r1
    c.r[2] += c.r[1];  // 06082CA2 add r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06082CA4 mov.w @r8,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06082CA6 extu.w r1,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 06082CA8 cmp/gt r1,r2
    if (!c.t) { goto L_06082CB2; }  // 06082CAA bf 0x06082CB2
    c.r[4] = 0x2u;  // 06082CAC mov #2,r4
    goto L_06082CB4;  // 06082CAE bra 0x06082CB4 ; nop
L_06082CB2:
    c.r[4] = 0x1u;  // 06082CB2 mov #1,r4
L_06082CB4:
    { const uint32_t x = c.r[9]; c.pr = 0x06082CB8u; c.r[11] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082CB8u) return; }  // 06082CB4 jsr @r9 ; mov r14,r11
    c.r[9] = ld32(0x06082E08u);  // 06082CB8 mov.l 0x06082E08,r9
    c.r[8] = ld32(0x06082E00u);  // 06082CBA mov.l 0x06082E00,r8
    c.r[1] = ld32(c.r[9]);  // 06082CBC mov.l @r9,r1
    c.r[5] = 0x0u;  // 06082CBE mov #0,r5
    c.r[1] += 20;  // 06082CC0 add #20,r1
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06082CC2 mov.w @r1,r6
    c.r[4] = 0x0u;  // 06082CC4 mov #0,r4
    { const uint32_t x = c.r[8]; c.pr = 0x06082CCAu; c.r[6] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082CCAu) return; }  // 06082CC6 jsr @r8 ; extu.w r6,r6
    c.r[11] += 34;  // 06082CCA add #34,r11
    c.r[5] = 0x0u;  // 06082CCC mov #0,r5
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[11]);  // 06082CCE mov.w @r11,r6
    c.r[4] = 0x0u;  // 06082CD0 mov #0,r4
    { const uint32_t x = c.r[8]; c.pr = 0x06082CD6u; c.r[6] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082CD6u) return; }  // 06082CD2 jsr @r8 ; extu.w r6,r6
    c.r[10] = (uint32_t)(int16_t)ld16(0x06082DF0u);  // 06082CD6 mov.w 0x06082DF0,r10
    c.r[12] = ld32(0x06082E04u);  // 06082CD8 mov.l 0x06082E04,r12
    { const uint32_t x = c.r[12]; c.pr = 0x06082CDEu; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082CDEu) return; }  // 06082CDA jsr @r12 ; mov r10,r4
    { const uint32_t x = c.r[12]; c.pr = 0x06082CE2u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082CE2u) return; }  // 06082CDE jsr @r12 ; mov #1,r4
    c.r[1] = ld32(c.r[9]);  // 06082CE2 mov.l @r9,r1
    c.r[1] += 20;  // 06082CE4 add #20,r1
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06082CE6 mov.w @r1,r6
    c.r[5] = 0x0u;  // 06082CE8 mov #0,r5
    c.r[1] = ld32(0x06082E0Cu);  // 06082CEA mov.l 0x06082E0C,r1
    c.r[1] = ld32(c.r[1]);  // 06082CEC mov.l @r1,r1
    c.r[4] = 0x0u;  // 06082CEE mov #0,r4
    c.r[1] += 34;  // 06082CF0 add #34,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06082CF2 mov.w @r1,r1
    c.r[6] = c.r[6] & 0xFFFFu;  // 06082CF4 extu.w r6,r6
    c.r[1] = c.r[1] & 0xFFFFu;  // 06082CF6 extu.w r1,r1
    { const uint32_t x = c.r[8]; c.pr = 0x06082CFCu; c.r[6] += c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082CFCu) return; }  // 06082CF8 jsr @r8 ; add r1,r6
    { const uint32_t x = c.r[12]; c.pr = 0x06082D00u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082D00u) return; }  // 06082CFC jsr @r12 ; mov r10,r4
    c.r[1] = ld32(c.r[9]);  // 06082D00 mov.l @r9,r1
    c.r[1] += 16;  // 06082D02 add #16,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06082D04 mov.w @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[11]);  // 06082D06 mov.w @r11,r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 06082D08 extu.w r2,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 06082D0A extu.w r1,r1
    c.r[2] += c.r[1];  // 06082D0C add r1,r2
    c.r[1] = c.r[14];  // 06082D0E mov r14,r1
    c.r[1] += 32;  // 06082D10 add #32,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06082D12 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06082D14 extu.w r1,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 06082D16 cmp/gt r1,r2
    { const bool k = c.t; c.r[4] = 0x2u; if (k) { goto L_06082D1E; } }  // 06082D18 bt/s 0x06082D1E ; mov #2,r4
    c.r[4] = 0x1u;  // 06082D1C mov #1,r4
L_06082D1E:
    { const uint32_t x = c.r[12]; c.pr = 0x06082D22u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082D22u) return; }  // 06082D1E jsr @r12 ; nop
    c.r[11] = ld32(0x06082E08u);  // 06082D22 mov.l 0x06082E08,r11
    c.r[9] = ld32(0x06082E00u);  // 06082D24 mov.l 0x06082E00,r9
    c.r[1] = ld32(c.r[11]);  // 06082D26 mov.l @r11,r1
    c.r[5] = 0x0u;  // 06082D28 mov #0,r5
    c.r[1] += 16;  // 06082D2A add #16,r1
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06082D2C mov.w @r1,r6
    c.r[4] = 0x0u;  // 06082D2E mov #0,r4
    { const uint32_t x = c.r[9]; c.pr = 0x06082D34u; c.r[6] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082D34u) return; }  // 06082D30 jsr @r9 ; extu.w r6,r6
    c.r[1] = c.r[14];  // 06082D34 mov r14,r1
    c.r[1] += 34;  // 06082D36 add #34,r1
    c.r[5] = 0x0u;  // 06082D38 mov #0,r5
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06082D3A mov.w @r1,r6
    c.r[4] = 0x0u;  // 06082D3C mov #0,r4
    { const uint32_t x = c.r[9]; c.pr = 0x06082D42u; c.r[6] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082D42u) return; }  // 06082D3E jsr @r9 ; extu.w r6,r6
    c.r[10] = (uint32_t)(int16_t)ld16(0x06082DF0u);  // 06082D42 mov.w 0x06082DF0,r10
    c.r[8] = ld32(0x06082E04u);  // 06082D44 mov.l 0x06082E04,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06082D4Au; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082D4Au) return; }  // 06082D46 jsr @r8 ; mov r10,r4
    { const uint32_t x = c.r[8]; c.pr = 0x06082D4Eu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082D4Eu) return; }  // 06082D4A jsr @r8 ; mov #1,r4
    c.r[1] = ld32(c.r[11]);  // 06082D4E mov.l @r11,r1
    c.r[1] += 16;  // 06082D50 add #16,r1
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06082D52 mov.w @r1,r6
    c.r[5] = 0x0u;  // 06082D54 mov #0,r5
    c.r[1] = ld32(0x06082E0Cu);  // 06082D56 mov.l 0x06082E0C,r1
    c.r[1] = ld32(c.r[1]);  // 06082D58 mov.l @r1,r1
    c.r[4] = 0x0u;  // 06082D5A mov #0,r4
    c.r[1] += 34;  // 06082D5C add #34,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06082D5E mov.w @r1,r1
    c.r[6] = c.r[6] & 0xFFFFu;  // 06082D60 extu.w r6,r6
    c.r[1] = c.r[1] & 0xFFFFu;  // 06082D62 extu.w r1,r1
    { const uint32_t x = c.r[9]; c.pr = 0x06082D68u; c.r[6] += c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082D68u) return; }  // 06082D64 jsr @r9 ; add r1,r6
    { const uint32_t x = c.r[8]; c.pr = 0x06082D6Cu; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082D6Cu) return; }  // 06082D68 jsr @r8 ; mov r10,r4
    { const uint32_t x = c.r[8]; c.pr = 0x06082D70u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082D70u) return; }  // 06082D6C jsr @r8 ; mov #1,r4
    c.r[8] = ld32(0x06082E10u);  // 06082D70 mov.l 0x06082E10,r8
    c.r[5] = 0x2u;  // 06082D72 mov #2,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06082D78u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082D78u) return; }  // 06082D74 jsr @r8 ; mov #1,r4
    c.r[5] = 0x0u;  // 06082D78 mov #0,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06082D7Eu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082D7Eu) return; }  // 06082D7A jsr @r8 ; mov #1,r4
    c.r[5] = 0x1u;  // 06082D7E mov #1,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06082D84u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082D84u) return; }  // 06082D80 jsr @r8 ; mov #1,r4
    c.r[5] = 0x3u;  // 06082D84 mov #3,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06082D8Au; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082D8Au) return; }  // 06082D86 jsr @r8 ; mov #1,r4
    c.r[10] = 0x2u;  // 06082D8A mov #2,r10
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06082D8C mov.l r10,@-r15
    c.r[8] = 0x1u;  // 06082D8E mov #1,r8
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06082D90 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06082D92 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06082D94 mov.l r8,@-r15
    c.r[9] = 0x0u;  // 06082D96 mov #0,r9
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06082D98 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06082D9A mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06082D9C mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06082D9E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06082DA0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06082DA2 mov.l r8,@-r15
    c.r[1] = ld32(0x06082E14u);  // 06082DA4 mov.l 0x06082E14,r1
    c.r[7] = c.r[10];  // 06082DA6 mov r10,r7
    c.r[6] = 0x5u;  // 06082DA8 mov #5,r6
    c.r[5] = 0x12u;  // 06082DAA mov #18,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06082DB0u; c.r[4] = 0x16u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082DB0u) return; }  // 06082DAC jsr @r1 ; mov #22,r4
    c.r[15] += 40;  // 06082DB0 add #40,r15
    c.r[1] = ld32(0x06082E18u);  // 06082DB2 mov.l 0x06082E18,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06082DB8u; c.r[4] = 0x4Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082DB8u) return; }  // 06082DB4 jsr @r1 ; mov #76,r4
    c.r[0] = ld32(0x06082E1Cu);  // 06082DB8 mov.l 0x06082E1C,r0
    c.r[6] = c.r[8];  // 06082DBA mov r8,r6
    c.r[1] = ld32(c.r[11]);  // 06082DBC mov.l @r11,r1
    c.r[5] = c.r[10];  // 06082DBE mov r10,r5
    c.r[1] += 42;  // 06082DC0 add #42,r1
    c.r[7] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06082DC2 mov.w @r1,r7
    c.r[4] = 0x0u;  // 06082DC4 mov #0,r4
    c.r[7] <<= 16;  // 06082DC6 shll16 r7
    c.r[7] += c.r[7];  // 06082DC8 add r7,r7
    c.r[7] >>= 16;  // 06082DCA shlr16 r7
    c.r[7] += c.r[7];  // 06082DCC add r7,r7
    c.r[7] >>= 8;  // 06082DCE shlr8 r7
    { const uint32_t x = c.r[0]; c.pr = 0x06082DD4u; c.r[15] -= 4; st32(c.r[15], c.r[9]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082DD4u) return; }  // 06082DD0 jsr @r0 ; mov.l r9,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x06082DF2u);  // 06082DD4 mov.w 0x06082DF2,r3
    c.r[14] += c.r[3];  // 06082DD6 add r3,r14
    c.r[15] = c.r[14];  // 06082DD8 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06082DDA lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06082DDC mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06082DDE mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06082DE0 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06082DE2 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06082DE4 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06082DF4u);  // 06082DE6 mov.w 0x06082DF4,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06082DE8 rts ; mov.l @r15+,r8
}

void f_06082E20(SH2Context& c) {
    ran[1837] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06082E20 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06082E22 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06082E24 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06082E26 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06082E28 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06082E2A mov r15,r14
    c.r[1] = ld32(0x06082EE0u);  // 06082E2C mov.l 0x06082EE0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06082E32u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082E32u) return; }  // 06082E2E jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06082EE4u);  // 06082E32 mov.l 0x06082EE4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06082E38u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082E38u) return; }  // 06082E34 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06082EE8u);  // 06082E38 mov.l 0x06082EE8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06082E3Eu; c.r[8] = 0x4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082E3Eu) return; }  // 06082E3A jsr @r1 ; mov #4,r8
    c.r[10] = (uint32_t)(int16_t)ld16(0x06082EDCu);  // 06082E3E mov.w 0x06082EDC,r10
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06082E40 mov.l r8,@-r15
    c.r[9] = ld32(0x06082EECu);  // 06082E42 mov.l 0x06082EEC,r9
    c.r[7] = 0x9u;  // 06082E44 mov #9,r7
    c.r[6] = 0x7u;  // 06082E46 mov #7,r6
    c.r[5] = 0xEu;  // 06082E48 mov #14,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06082E4Eu; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082E4Eu) return; }  // 06082E4A jsr @r9 ; mov r10,r4
    c.r[1] = 0x2u;  // 06082E4E mov #2,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06082E50 mov.l r1,@-r15
    c.r[7] = 0x1Du;  // 06082E52 mov #29,r7
    c.r[6] = 0xDu;  // 06082E54 mov #13,r6
    c.r[5] = c.r[8];  // 06082E56 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06082E5Cu; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082E5Cu) return; }  // 06082E58 jsr @r9 ; mov r10,r4
    c.r[1] = ld32(0x06082EF0u);  // 06082E5C mov.l 0x06082EF0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06082E5E mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06082E60 extu.b r1,r0
    c.t = c.r[0] == 0x50u;  // 06082E62 cmp/eq #80,r0
    { const bool k = !c.t; c.r[15] += 8; if (k) { goto L_06082E6C; } }  // 06082E64 bf/s 0x06082E6C ; add #8,r15
    c.r[2] = 0x0u; goto L_06082E74;  // 06082E68 bra 0x06082E74 ; mov #0,r2
L_06082E6C:
    c.t = c.r[0] == 0x52u;  // 06082E6C cmp/eq #82,r0
    { const bool k = !c.t; c.r[2] = 0x57u; if (k) { goto L_06082E74; } }  // 06082E6E bf/s 0x06082E74 ; mov #87,r2
    c.r[2] = 0x7u;  // 06082E72 mov #7,r2
L_06082E74:
    c.r[1] = ld32(0x06082EF0u);  // 06082E74 mov.l 0x06082EF0,r1
    c.r[4] = ld32(0x06082EF4u);  // 06082E76 mov.l 0x06082EF4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06082E78 mov.b @r1,r1
    c.r[8] = ld32(0x06082EF8u);  // 06082E7A mov.l 0x06082EF8,r8
    c.r[0] = c.r[1] & 0xFFu;  // 06082E7C extu.b r1,r0
    c.r[1] = ld32(0x06082EFCu);  // 06082E7E mov.l 0x06082EFC,r1
    c.r[9] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06082E80 mov.b @(r0,r1),r9
    c.r[5] = 0x17u;  // 06082E82 mov #23,r5
    c.r[9] = c.r[9] & 0xFFu;  // 06082E84 extu.b r9,r9
    { const uint32_t x = c.r[8]; c.pr = 0x06082E8Au; c.r[9] += c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082E8Au) return; }  // 06082E86 jsr @r8 ; add r2,r9
    c.r[5] = 0x23u;  // 06082E8A mov #35,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06082E90u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082E90u) return; }  // 06082E8C jsr @r8 ; mov r0,r4
    c.r[5] = c.r[9];  // 06082E90 mov r9,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06082E96u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082E96u) return; }  // 06082E92 jsr @r8 ; mov r0,r4
    c.r[1] = ld32(0x06082F00u);  // 06082E96 mov.l 0x06082F00,r1
    c.r[6] = 0x0u;  // 06082E98 mov #0,r6
    c.r[5] = c.r[0];  // 06082E9A mov r0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06082EA0u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082EA0u) return; }  // 06082E9C jsr @r1 ; mov #0,r4
    c.r[7] = 0x2u;  // 06082EA0 mov #2,r7
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 06082EA2 mov.l r7,@-r15
    c.r[2] = 0x1u;  // 06082EA4 mov #1,r2
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06082EA6 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06082EA8 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06082EAA mov.l r2,@-r15
    c.r[1] = 0x0u;  // 06082EAC mov #0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06082EAE mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06082EB0 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06082EB2 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06082EB4 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 06082EB6 mov.l r7,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06082EB8 mov.l r2,@-r15
    c.r[1] = ld32(0x06082F04u);  // 06082EBA mov.l 0x06082F04,r1
    c.r[6] = 0x9u;  // 06082EBC mov #9,r6
    c.r[5] = 0x8u;  // 06082EBE mov #8,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06082EC4u; c.r[4] = 0xFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082EC4u) return; }  // 06082EC0 jsr @r1 ; mov #15,r4
    c.r[15] += 40;  // 06082EC4 add #40,r15
    c.r[1] = ld32(0x06082F08u);  // 06082EC6 mov.l 0x06082F08,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06082ECCu; c.r[4] = 0x46u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082ECCu) return; }  // 06082EC8 jsr @r1 ; mov #70,r4
    c.r[15] = c.r[14];  // 06082ECC mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06082ECE lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06082ED0 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06082ED2 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06082ED4 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06082EDEu);  // 06082ED6 mov.w 0x06082EDE,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06082ED8 rts ; mov.l @r15+,r8
}

void f_06082F14(SH2Context& c) {
    ran[1838] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06082F14 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06082F16 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06082F18 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06082F1A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06082F1C mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06082F1E mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06082F20 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06082F22 sts.l pr,@-r15
    c.r[15] -= 52;  // 06082F24 add #-52,r15
    c.r[14] = c.r[15];  // 06082F26 mov r15,r14
    c.r[8] = 0x0u;  // 06082F28 mov #0,r8
    c.r[1] = ld32(0x0608308Cu);  // 06082F2A mov.l 0x0608308C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06082F30u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082F30u) return; }  // 06082F2C jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06083090u);  // 06082F30 mov.l 0x06083090,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06082F36u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082F36u) return; }  // 06082F32 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06083094u);  // 06082F36 mov.l 0x06083094,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06082F3Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082F3Cu) return; }  // 06082F38 jsr @r1 ; nop
    c.r[12] = ld32(0x06083098u);  // 06082F3C mov.l 0x06083098,r12
    c.r[0] = (uint32_t)(int16_t)ld16(0x06083088u);  // 06082F3E mov.w 0x06083088,r0
    c.r[3] = 0x7u;  // 06082F40 mov #7,r3
    c.r[7] = 0x2u;  // 06082F42 mov #2,r7
    c.r[6] = 0x24u;  // 06082F44 mov #36,r6
    c.r[1] = ld32(c.r[12]);  // 06082F46 mov.l @r12,r1
    c.r[5] = 0x5u;  // 06082F48 mov #5,r5
    st32(c.r[14] + 48, c.r[0]);  // 06082F4A mov.l r0,@(48,r14)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06082F4C mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06082F4E extu.b r1,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06082F50 mov.l r1,@-r15
    c.r[1] = 0x1u;  // 06082F52 mov #1,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06082F54 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06082F56 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06082F58 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06082F5A mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06082F5C mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06082F5E mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06082F60 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[3]);  // 06082F62 mov.l r3,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06082F64 mov.l r1,@-r15
    c.r[1] = ld32(0x0608309Cu);  // 06082F66 mov.l 0x0608309C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06082F6Cu; c.r[4] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082F6Cu) return; }  // 06082F68 jsr @r1 ; mov #2,r4
    c.r[15] += 40;  // 06082F6C add #40,r15
    c.r[0] = ld32(0x060830A0u);  // 06082F6E mov.l 0x060830A0,r0
    c.r[8] = ld32(0x060830A4u);  // 06082F70 mov.l 0x060830A4,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06082F72 mov.b @r0,r1
    c.r[5] = 0x0u;  // 06082F74 mov #0,r5
    c.r[1] = c.r[1] & 0xFFu;  // 06082F76 extu.b r1,r1
    c.r[0] = ld32(0x060830A8u);  // 06082F78 mov.l 0x060830A8,r0
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06082F7A mov.b @(r0,r1),r6
    c.r[4] = 0x0u;  // 06082F7C mov #0,r4
    { const uint32_t x = c.r[8]; c.pr = 0x06082F82u; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082F82u) return; }  // 06082F7E jsr @r8 ; extu.b r6,r6
    c.r[1] = ld32(c.r[12]);  // 06082F82 mov.l @r12,r1
    c.r[0] = ld32(c.r[14] + 48);  // 06082F84 mov.l @(48,r14),r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06082F86 mov.b @(r0,r1),r1
    c.r[3] = ld32(0x060830ACu);  // 06082F88 mov.l 0x060830AC,r3
    c.r[1] = c.r[1] & 0xFFu;  // 06082F8A extu.b r1,r1
    c.r[1] += 6;  // 06082F8C add #6,r1
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[1] * (int32_t)c.r[3]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 06082F8E dmuls.l r3,r1
    c.r[5] = 0x0u;  // 06082F90 mov #0,r5
    c.r[4] = 0x0u;  // 06082F92 mov #0,r4
    c.r[6] = c.mach;  // 06082F94 sts mach,r6
    c.r[6] += c.r[1];  // 06082F96 add r1,r6
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 06082F98 shar r6
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 06082F9A shar r6
    c.t = c.r[1] >> 31; c.r[1] <<= 1;  // 06082F9C shll r1
    { uint32_t a = c.r[1], b = c.r[1], t = c.t; c.r[1] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 06082F9E subc r1,r1
    { const uint32_t x = c.r[8]; c.pr = 0x06082FA4u; c.r[6] -= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082FA4u) return; }  // 06082FA0 jsr @r8 ; sub r1,r6
    c.r[10] = ld32(0x060830B0u);  // 06082FA4 mov.l 0x060830B0,r10
    c.r[9] = ld32(0x060830B4u);  // 06082FA6 mov.l 0x060830B4,r9
    c.r[5] = 0x17u;  // 06082FA8 mov #23,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06082FAEu; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082FAEu) return; }  // 06082FAA jsr @r9 ; mov r10,r4
    c.r[1] = c.r[0];  // 06082FAE mov r0,r1
    c.r[5] = 0x23u;  // 06082FB0 mov #35,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06082FB6u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082FB6u) return; }  // 06082FB2 jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 06082FB6 mov r0,r1
    c.r[5] = 0x9u;  // 06082FB8 mov #9,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06082FBEu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082FBEu) return; }  // 06082FBA jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 06082FBE mov r0,r1
    c.r[11] = ld32(0x060830B8u);  // 06082FC0 mov.l 0x060830B8,r11
    c.r[6] = 0x0u;  // 06082FC2 mov #0,r6
    c.r[5] = c.r[1];  // 06082FC4 mov r1,r5
    { const uint32_t x = c.r[11]; c.pr = 0x06082FCAu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082FCAu) return; }  // 06082FC6 jsr @r11 ; mov #0,r4
    c.r[1] = ld32(0x060830BCu);  // 06082FCA mov.l 0x060830BC,r1
    c.r[5] = 0x17u;  // 06082FCC mov #23,r5
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06082FCE mov.w @r1,r8
    c.r[4] = c.r[10];  // 06082FD0 mov r10,r4
    c.r[8] += 2;  // 06082FD2 add #2,r8
    { const uint32_t x = c.r[9]; c.pr = 0x06082FD8u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082FD8u) return; }  // 06082FD4 jsr @r9 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 06082FD8 mov r0,r1
    c.r[5] = 0x23u;  // 06082FDA mov #35,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06082FE0u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082FE0u) return; }  // 06082FDC jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 06082FE0 mov r0,r1
    c.r[5] = c.r[8];  // 06082FE2 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06082FE8u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082FE8u) return; }  // 06082FE4 jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 06082FE8 mov r0,r1
    c.r[6] = 0x0u;  // 06082FEA mov #0,r6
    c.r[5] = c.r[1];  // 06082FEC mov r1,r5
    { const uint32_t x = c.r[11]; c.pr = 0x06082FF2u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06082FF2u) return; }  // 06082FEE jsr @r11 ; mov #0,r4
    c.r[0] = ld32(0x060830A0u);  // 06082FF2 mov.l 0x060830A0,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06082FF4 mov.b @r0,r1
    c.r[5] = c.r[1] & 0xFFu;  // 06082FF6 extu.b r1,r5
    c.r[0] = ld32(0x060830A8u);  // 06082FF8 mov.l 0x060830A8,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 06082FFA mov.b @(r0,r5),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06082FFC extu.b r1,r1
    st32(c.r[14] + 40, c.r[1]);  // 06082FFE mov.l r1,@(40,r14)
    c.r[3] = c.r[1];  // 06083000 mov r1,r3
    c.r[3] -= 1;  // 06083002 add #-1,r3
    st32(c.r[14] + 40, c.r[3]);  // 06083004 mov.l r3,@(40,r14)
    c.r[7] = ld32(c.r[12]);  // 06083006 mov.l @r12,r7
    c.r[0] = ld32(c.r[14] + 48);  // 06083008 mov.l @(48,r14),r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0608300A mov.b @(r0,r7),r1
    c.r[3] = ld32(0x060830ACu);  // 0608300C mov.l 0x060830AC,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0608300E extu.b r1,r1
    c.r[1] += 6;  // 06083010 add #6,r1
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[1] * (int32_t)c.r[3]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 06083012 dmuls.l r3,r1
    c.r[0] = ld32(c.r[14] + 40);  // 06083014 mov.l @(40,r14),r0
    c.r[6] = c.mach;  // 06083016 sts mach,r6
    c.r[6] += c.r[1];  // 06083018 add r1,r6
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 0608301A shar r6
    c.r[3] = 0x7u;  // 0608301C mov #7,r3
    c.macl = c.r[0] * c.r[3];  // 0608301E mul.l r3,r0
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 06083020 shar r6
    c.r[1] = ld32(0x060830C0u);  // 06083022 mov.l 0x060830C0,r1
    c.r[2] = c.macl;  // 06083024 sts macl,r2
    c.r[0] = c.r[5];  // 06083026 mov r5,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06083028 mov.b @(r0,r1),r1
    c.r[3] = ld32(0x060830C4u);  // 0608302A mov.l 0x060830C4,r3
    c.r[2] += c.r[1];  // 0608302C add r1,r2
    st8(c.r[3], c.r[2]);  // 0608302E mov.b r2,@r3
    c.r[0] = ld32(c.r[14] + 48);  // 06083030 mov.l @(48,r14),r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06083032 mov.b @(r0,r7),r1
    c.r[3] = 0x7u;  // 06083034 mov #7,r3
    c.r[2] = c.r[1] & 0xFFu;  // 06083036 extu.b r1,r2
    c.r[1] = c.macl;  // 06083038 sts macl,r1
    c.r[2] -= c.r[1];  // 0608303A sub r1,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[3];  // 0608303C cmp/gt r3,r2
    { const bool k = c.t; c.r[6] -= 1; if (k) { goto L_06083046; } }  // 0608303E bt/s 0x06083046 ; add #-1,r6
    st32(c.r[14] + 36, c.r[2]); goto L_0608304A;  // 06083042 bra 0x0608304A ; mov.l r2,@(36,r14)
L_06083046:
    c.r[0] = 0x7u;  // 06083046 mov #7,r0
    st32(c.r[14] + 36, c.r[0]);  // 06083048 mov.l r0,@(36,r14)
L_0608304A:
    c.r[3] = ld32(c.r[14] + 36);  // 0608304A mov.l @(36,r14),r3
    c.r[1] = 0x1u;  // 0608304C mov #1,r1
    c.t = (int32_t)c.r[3] > (int32_t)c.r[1];  // 0608304E cmp/gt r1,r3
    if (c.t) { goto L_06083068; }  // 06083050 bt 0x06083068
    c.r[1] = ld32(0x060830C8u);  // 06083052 mov.l 0x060830C8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06083054 mov.b @r1,r1
    c.r[2] = ld32(0x060830CCu);  // 06083056 mov.l 0x060830CC,r2
    c.r[2] = ld32(c.r[2]);  // 06083058 mov.l @r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0608305A extu.b r1,r1
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[2];  // 0608305C cmp/ge r2,r1
    { const bool k = c.t; c.r[4] = 0x48u; if (k) { goto L_06083068; } }  // 0608305E bt/s 0x06083068 ; mov #72,r4
    c.r[1] = ld32(0x060830D0u);  // 06083062 mov.l 0x060830D0,r1
    goto L_060832C0;  // 06083064 bra 0x060832C0 ; nop
L_06083068:
    c.r[1] = ld32(0x060830C8u);  // 06083068 mov.l 0x060830C8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0608306A mov.b @r1,r1
    c.r[2] = ld32(0x060830CCu);  // 0608306C mov.l 0x060830CC,r2
    c.r[2] = ld32(c.r[2]);  // 0608306E mov.l @r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06083070 extu.b r1,r1
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[2];  // 06083072 cmp/ge r2,r1
    { const bool k = c.t; c.r[3] = 0x0u; if (k) { goto L_060830D6; } }  // 06083074 bt/s 0x060830D6 ; mov #0,r3
    c.r[0] = ld32(c.r[14] + 40);  // 06083078 mov.l @(40,r14),r0
    c.t = c.r[0] == c.r[6];  // 0608307A cmp/eq r6,r0
    { const bool k = !c.t; c.r[3] = 0x1u; if (k) { goto L_060830D4; } }  // 0608307C bf/s 0x060830D4 ; mov #1,r3
    c.r[0] = ld32(c.r[14] + 36);  // 06083080 mov.l @(36,r14),r0
    st32(c.r[14] + 32, c.r[3]);  // 06083082 mov.l r3,@(32,r14)
    c.r[0] -= 1; goto L_060830DA;  // 06083084 bra 0x060830DA ; add #-1,r0
L_060830D4:
    c.r[3] = 0x0u;  // 060830D4 mov #0,r3
L_060830D6:
    st32(c.r[14] + 32, c.r[3]);  // 060830D6 mov.l r3,@(32,r14)
    c.r[0] = ld32(c.r[14] + 36);  // 060830D8 mov.l @(36,r14),r0
L_060830DA:
    st32(c.r[14] + 44, c.r[0]);  // 060830DA mov.l r0,@(44,r14)
    c.r[3] = 0x2Fu;  // 060830DC mov #47,r3
    c.r[3] += c.r[14];  // 060830DE add r14,r3
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060830E0 mov.b @r3,r3
    c.r[8] = ld32(0x060831E8u);  // 060830E2 mov.l 0x060831E8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060830E8u; c.r[4] = c.r[3] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060830E8u) return; }  // 060830E4 jsr @r8 ; extu.b r3,r4
    c.r[0] = ld32(c.r[14] + 40);  // 060830E8 mov.l @(40,r14),r0
    c.r[1] = 0x7u;  // 060830EA mov #7,r1
    c.macl = c.r[0] * c.r[1];  // 060830EC mul.l r1,r0
    c.r[3] = ld32(c.r[14] + 44);  // 060830EE mov.l @(44,r14),r3
    c.r[11] = c.macl;  // 060830F0 sts macl,r11
    c.r[1] = c.macl;  // 060830F2 sts macl,r1
    c.r[1] += c.r[3];  // 060830F4 add r3,r1
    c.t = (int32_t)c.r[11] >= (int32_t)c.r[1];  // 060830F6 cmp/ge r1,r11
    { const bool k = !c.t; c.r[3] = ld32(c.r[14] + 32); if (k) { goto L_06083100; } }  // 060830F8 bf/s 0x06083100 ; mov.l @(32,r14),r3
    goto L_0608326A;  // 060830FC bra 0x0608326A ; nop
L_06083100:
    c.r[13] = c.r[8];  // 06083100 mov r8,r13
    c.r[1] = 0x28u;  // 06083102 mov #40,r1
    c.macl = c.r[11] * c.r[1];  // 06083104 mul.l r1,r11
    c.r[12] = ld32(0x060831ECu);  // 06083106 mov.l 0x060831EC,r12
    c.r[10] = ld32(0x060831F0u);  // 06083108 mov.l 0x060831F0,r10
    c.r[9] = c.macl;  // 0608310A sts macl,r9
L_0608310C:
    c.r[4] = (uint32_t)(int16_t)ld16(0x060831E6u);  // 0608310C mov.w 0x060831E6,r4
    { const uint32_t x = c.r[13]; c.pr = 0x06083112u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083112u) return; }  // 0608310E jsr @r13 ; nop
    c.r[0] = ld32(0x060831F4u);  // 06083112 mov.l 0x060831F4,r0
    c.r[2] = c.r[11];  // 06083114 mov r11,r2
    c.r[1] = ld32(c.r[0]);  // 06083116 mov.l @r0,r1
    c.r[2] += c.r[2];  // 06083118 add r2,r2
    c.r[0] = c.r[1];  // 0608311A mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0608311C mov.b @(r0,r2),r1
    c.r[3] = 0x7Fu;  // 0608311E mov #127,r3
    c.r[1] &= c.r[3];  // 06083120 and r3,r1
    c.r[1] >>= 2;  // 06083122 shlr2 r1
    c.r[1] >>= 2;  // 06083124 shlr2 r1
    c.r[1] >>= 2;  // 06083126 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06083128 tst r1,r1
    if (!c.t) { goto L_06083144; }  // 0608312A bf 0x06083144
    c.r[1] = ld32(c.r[12]);  // 0608312C mov.l @r12,r1
    c.r[1] += c.r[9];  // 0608312E add r9,r1
    c.r[1] += 39;  // 06083130 add #39,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06083132 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06083134 extu.b r1,r0
    c.t = c.r[0] == 0x49u;  // 06083136 cmp/eq #73,r0
    if (!c.t) { goto L_06083140; }  // 06083138 bf 0x06083140
    c.r[4] = 0x4u;  // 0608313A mov #4,r4
    goto L_06083146;  // 0608313C bra 0x06083146 ; nop
L_06083140:
    c.r[4] = 0x2u; goto L_06083146;  // 06083140 bra 0x06083146 ; mov #2,r4
L_06083144:
    c.r[4] = 0x1u;  // 06083144 mov #1,r4
L_06083146:
    { const uint32_t x = c.r[13]; c.pr = 0x0608314Au; c.r[8] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608314Au) return; }  // 06083146 jsr @r13 ; mov r11,r8
    c.r[0] = ld32(0x060831F4u);  // 0608314A mov.l 0x060831F4,r0
    c.r[8] += c.r[8];  // 0608314C add r8,r8
    c.r[5] = ld32(0x060831F8u);  // 0608314E mov.l 0x060831F8,r5
    c.r[1] = ld32(c.r[0]);  // 06083150 mov.l @r0,r1
    c.r[4] = c.r[14];  // 06083152 mov r14,r4
    c.r[1] += c.r[8];  // 06083154 add r8,r1
    c.r[1] += 1;  // 06083156 add #1,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06083158 mov.b @r1,r6
    c.r[3] = ld32(0x060831FCu);  // 0608315A mov.l 0x060831FC,r3
    { const uint32_t x = c.r[3]; c.pr = 0x06083160u; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083160u) return; }  // 0608315C jsr @r3 ; extu.b r6,r6
    c.r[2] = c.r[14];  // 06083160 mov r14,r2
    c.r[2] += 2;  // 06083162 add #2,r2
    c.r[1] = 0xFFFFFFFFu;  // 06083164 mov #-1,r1
    st8(c.r[2], c.r[1]);  // 06083166 mov.b r1,@r2
    c.r[6] = 0x0u;  // 06083168 mov #0,r6
    c.r[5] = c.r[14];  // 0608316A mov r14,r5
    c.r[0] = ld32(0x06083200u);  // 0608316C mov.l 0x06083200,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06083172u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083172u) return; }  // 0608316E jsr @r0 ; mov #0,r4
    c.r[3] = ld32(0x060831F4u);  // 06083172 mov.l 0x060831F4,r3
    c.r[1] = ld32(c.r[3]);  // 06083174 mov.l @r3,r1
    c.r[0] = c.r[1];  // 06083176 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 06083178 mov.b @(r0,r8),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0608317A extu.b r1,r1
    c.r[1] >>= 2;  // 0608317C shlr2 r1
    c.r[1] >>= 2;  // 0608317E shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06083180 shlr r1
    c.r[1] >>= 2;  // 06083182 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06083184 tst r1,r1
    { const bool k = !c.t; c.r[0] = c.r[9]; if (k) { goto L_06083204; } }  // 06083186 bf/s 0x06083204 ; mov r9,r0
    c.r[1] = ld32(c.r[12]);  // 0608318A mov.l @r12,r1
    c.r[5] = 0x0u;  // 0608318C mov #0,r5
    c.r[6] = ld32(c.r[0] + c.r[1]);  // 0608318E mov.l @(r0,r1),r6
    c.r[4] = 0x0u;  // 06083190 mov #0,r4
    c.r[6] >>= 16;  // 06083192 shlr16 r6
    { const uint32_t x = c.r[10]; c.pr = 0x06083198u; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083198u) return; }  // 06083194 jsr @r10 ; extu.b r6,r6
    c.r[0] = c.r[9];  // 06083198 mov r9,r0
    c.r[1] = ld32(c.r[12]);  // 0608319A mov.l @r12,r1
    c.r[5] = 0x0u;  // 0608319C mov #0,r5
    c.r[6] = ld32(c.r[0] + c.r[1]);  // 0608319E mov.l @(r0,r1),r6
    c.r[4] = 0x0u;  // 060831A0 mov #0,r4
    c.r[6] >>= 8;  // 060831A2 shlr8 r6
    { const uint32_t x = c.r[10]; c.pr = 0x060831A8u; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060831A8u) return; }  // 060831A4 jsr @r10 ; extu.b r6,r6
    c.r[1] = ld32(c.r[12]);  // 060831A8 mov.l @r12,r1
    c.r[5] = 0x0u;  // 060831AA mov #0,r5
    c.r[1] += c.r[9];  // 060831AC add r9,r1
    c.r[6] = ld32(c.r[1] + 4);  // 060831AE mov.l @(4,r1),r6
    c.r[4] = 0x0u;  // 060831B0 mov #0,r4
    c.r[6] >>= 8;  // 060831B2 shlr8 r6
    { const uint32_t x = c.r[10]; c.pr = 0x060831B8u; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060831B8u) return; }  // 060831B4 jsr @r10 ; extu.b r6,r6
    c.r[1] = ld32(c.r[12]);  // 060831B8 mov.l @r12,r1
    c.r[5] = 0x0u;  // 060831BA mov #0,r5
    c.r[1] += c.r[9];  // 060831BC add r9,r1
    c.r[6] = ld32(c.r[1] + 4);  // 060831BE mov.l @(4,r1),r6
    c.r[4] = 0x0u;  // 060831C0 mov #0,r4
    { const uint32_t x = c.r[10]; c.pr = 0x060831C6u; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060831C6u) return; }  // 060831C2 jsr @r10 ; extu.b r6,r6
    c.r[6] = 0x1u;  // 060831C6 mov #1,r6
    c.r[4] = 0x0u;  // 060831C8 mov #0,r4
    c.r[5] = ld32(c.r[12]);  // 060831CA mov.l @r12,r5
    c.r[3] = ld32(0x06083408u);  // 060831CC mov.l 0x06083408,r3
    c.r[5] += c.r[9];  // 060831CE add r9,r5
    { const uint32_t x = c.r[3]; c.pr = 0x060831D4u; c.r[5] += 30; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060831D4u) return; }  // 060831D0 jsr @r3 ; add #30,r5
    c.r[1] = ld32(c.r[12]);  // 060831D4 mov.l @r12,r1
    c.r[5] = 0x0u;  // 060831D6 mov #0,r5
    c.r[1] += c.r[9];  // 060831D8 add r9,r1
    c.r[1] += 36;  // 060831DA add #36,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060831DC mov.b @r1,r6
    c.r[4] = 0x0u;  // 060831DE mov #0,r4
    c.r[6] = c.r[6] & 0xFFu;  // 060831E0 extu.b r6,r6
    c.r[6] -= 1; goto L_0608324E;  // 060831E2 bra 0x0608324E ; add #-1,r6
L_06083204:
    c.r[6] = 0x0u;  // 06083204 mov #0,r6
    c.r[5] = 0x0u;  // 06083206 mov #0,r5
    { const uint32_t x = c.r[10]; c.pr = 0x0608320Cu; c.r[4] = 0x20u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608320Cu) return; }  // 06083208 jsr @r10 ; mov #32,r4
    c.r[6] = 0x0u;  // 0608320C mov #0,r6
    c.r[5] = 0x0u;  // 0608320E mov #0,r5
    { const uint32_t x = c.r[10]; c.pr = 0x06083214u; c.r[4] = 0x20u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083214u) return; }  // 06083210 jsr @r10 ; mov #32,r4
    c.r[6] = 0x0u;  // 06083214 mov #0,r6
    c.r[5] = 0x0u;  // 06083216 mov #0,r5
    { const uint32_t x = c.r[10]; c.pr = 0x0608321Cu; c.r[4] = 0x20u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608321Cu) return; }  // 06083218 jsr @r10 ; mov #32,r4
    c.r[6] = 0x0u;  // 0608321C mov #0,r6
    c.r[5] = 0x0u;  // 0608321E mov #0,r5
    { const uint32_t x = c.r[10]; c.pr = 0x06083224u; c.r[4] = 0x20u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083224u) return; }  // 06083220 jsr @r10 ; mov #32,r4
    c.r[8] = ld32(0x06083400u);  // 06083224 mov.l 0x06083400,r8
    c.r[4] = ld32(0x06083404u);  // 06083226 mov.l 0x06083404,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0608322Cu; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608322Cu) return; }  // 06083228 jsr @r8 ; mov #23,r5
    c.r[1] = c.r[0];  // 0608322C mov r0,r1
    c.r[5] = 0x23u;  // 0608322E mov #35,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06083234u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083234u) return; }  // 06083230 jsr @r8 ; mov r1,r4
    c.r[1] = c.r[0];  // 06083234 mov r0,r1
    c.r[5] = 0x5Fu;  // 06083236 mov #95,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0608323Cu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608323Cu) return; }  // 06083238 jsr @r8 ; mov r1,r4
    c.r[1] = c.r[0];  // 0608323C mov r0,r1
    c.r[6] = 0x0u;  // 0608323E mov #0,r6
    c.r[5] = c.r[1];  // 06083240 mov r1,r5
    c.r[0] = ld32(0x060835D8u);  // 06083242 mov.l 0x060835D8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06083248u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083248u) return; }  // 06083244 jsr @r0 ; mov #0,r4
    c.r[6] = 0x0u;  // 06083248 mov #0,r6
    c.r[5] = 0x0u;  // 0608324A mov #0,r5
    c.r[4] = 0x20u;  // 0608324C mov #32,r4
L_0608324E:
    { const uint32_t x = c.r[10]; c.pr = 0x06083252u; c.r[9] += 40; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083252u) return; }  // 0608324E jsr @r10 ; add #40,r9
    c.r[3] = ld32(c.r[14] + 40);  // 06083252 mov.l @(40,r14),r3
    c.r[1] = 0x7u;  // 06083254 mov #7,r1
    c.macl = c.r[3] * c.r[1];  // 06083256 mul.l r1,r3
    c.r[11] += 1;  // 06083258 add #1,r11
    c.r[0] = ld32(c.r[14] + 44);  // 0608325A mov.l @(44,r14),r0
    c.r[1] = c.macl;  // 0608325C sts macl,r1
    c.r[1] += c.r[0];  // 0608325E add r0,r1
    c.t = (int32_t)c.r[11] >= (int32_t)c.r[1];  // 06083260 cmp/ge r1,r11
    { const bool k = c.t; c.r[3] = ld32(c.r[14] + 32); if (k) { goto L_0608326A; } }  // 06083262 bt/s 0x0608326A ; mov.l @(32,r14),r3
    SH2_POLL(c); goto L_0608310C;  // 06083266 bra 0x0608310C ; nop
L_0608326A:
    c.t = (c.r[3] & c.r[3]) == 0;  // 0608326A tst r3,r3
    { const bool k = c.t; c.r[1] = 0x0u; if (k) { goto L_0608328C; } }  // 0608326C bt/s 0x0608328C ; mov #0,r1
    c.r[4] = ld32(0x06083404u);  // 06083270 mov.l 0x06083404,r4
    c.r[8] = ld32(0x06083400u);  // 06083272 mov.l 0x06083400,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06083278u; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083278u) return; }  // 06083274 jsr @r8 ; mov #23,r5
    c.r[5] = 0x23u;  // 06083278 mov #35,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0608327Eu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608327Eu) return; }  // 0608327A jsr @r8 ; mov r0,r4
    c.r[5] = 0x4u;  // 0608327E mov #4,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06083284u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083284u) return; }  // 06083280 jsr @r8 ; mov r0,r4
    c.r[1] = ld32(0x060835D8u);  // 06083284 mov.l 0x060835D8,r1
    c.r[6] = 0x0u;  // 06083286 mov #0,r6
    c.r[5] = c.r[0]; goto L_0608329C;  // 06083288 bra 0x0608329C ; mov r0,r5
L_0608328C:
    st8(c.r[14], c.r[1]);  // 0608328C mov.b r1,@r14
    c.r[2] = c.r[14];  // 0608328E mov r14,r2
    c.r[2] += 1;  // 06083290 add #1,r2
    c.r[1] = 0xFFFFFFFFu;  // 06083292 mov #-1,r1
    st8(c.r[2], c.r[1]);  // 06083294 mov.b r1,@r2
    c.r[1] = ld32(0x060835D8u);  // 06083296 mov.l 0x060835D8,r1
    c.r[6] = 0x0u;  // 06083298 mov #0,r6
    c.r[5] = c.r[14];  // 0608329A mov r14,r5
L_0608329C:
    { const uint32_t x = c.r[1]; c.pr = 0x060832A0u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060832A0u) return; }  // 0608329C jsr @r1 ; mov #0,r4
    c.r[0] = ld32(c.r[14] + 32);  // 060832A0 mov.l @(32,r14),r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060832A2 tst r0,r0
    { const bool k = c.t; c.r[3] = ld32(c.r[14] + 36); if (k) { goto L_060832CA; } }  // 060832A4 bt/s 0x060832CA ; mov.l @(36,r14),r3
    c.r[1] = ld32(0x0608340Cu);  // 060832A8 mov.l 0x0608340C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060832AA mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 060832AC extu.b r1,r2
    c.r[1] = ld32(0x06083410u);  // 060832AE mov.l 0x06083410,r1
    c.r[0] = c.r[2];  // 060832B0 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060832B2 mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 060832B4 extu.b r1,r1
    c.r[1] += 1;  // 060832B6 add #1,r1
    c.t = c.r[1] == c.r[3];  // 060832B8 cmp/eq r3,r1
    { const bool k = !c.t; c.r[4] = 0x49u; if (k) { goto L_060832CA; } }  // 060832BA bf/s 0x060832CA ; mov #73,r4
    c.r[1] = ld32(0x06083414u);  // 060832BE mov.l 0x06083414,r1
L_060832C0:
    { const uint32_t x = c.r[1]; c.pr = 0x060832C4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060832C4u) return; }  // 060832C0 jsr @r1 ; nop
    c.r[0] = (uint32_t)(int16_t)ld16(0x060833FEu);  // 060832C4 mov.w 0x060833FE,r0
    c.r[14] += 52; goto L_060833EA;  // 060832C6 bra 0x060833EA ; add #52,r14
L_060832CA:
    c.r[1] = ld32(0x06083418u);  // 060832CA mov.l 0x06083418,r1
    c.r[6] = ld32(c.r[1]);  // 060832CC mov.l @r1,r6
    c.r[13] = ld32(0x0608341Cu);  // 060832CE mov.l 0x0608341C,r13
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 060832D0 mov.b @r13,r1
    c.r[0] = c.r[6];  // 060832D2 mov r6,r0
    c.r[2] = c.r[1] & 0xFFu;  // 060832D4 extu.b r1,r2
    c.r[2] += c.r[2];  // 060832D6 add r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 060832D8 mov.b @(r0,r2),r1
    c.r[1] = c.r[1] & 0xFFu;  // 060832DA extu.b r1,r1
    c.r[3] = c.r[1];  // 060832DC mov r1,r3
    c.r[3] >>= 2;  // 060832DE shlr2 r3
    c.r[3] >>= 2;  // 060832E0 shlr2 r3
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 060832E2 shlr r3
    c.r[3] >>= 2;  // 060832E4 shlr2 r3
    c.r[0] = c.r[3];  // 060832E6 mov r3,r0
    c.t = c.r[0] == 0x1u;  // 060832E8 cmp/eq #1,r0
    { const bool k = c.t; c.r[6] += c.r[2]; if (k) { goto L_060833E0; } }  // 060832EA bt/s 0x060833E0 ; add r2,r6
    c.r[6] += 1;  // 060832EE add #1,r6
    c.r[5] = ld32(0x06083420u);  // 060832F0 mov.l 0x06083420,r5
    c.r[4] = c.r[14];  // 060832F2 mov r14,r4
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[6]);  // 060832F4 mov.b @r6,r6
    c.r[3] = ld32(0x06083424u);  // 060832F6 mov.l 0x06083424,r3
    { const uint32_t x = c.r[3]; c.pr = 0x060832FCu; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060832FCu) return; }  // 060832F8 jsr @r3 ; extu.b r6,r6
    c.r[2] = c.r[14];  // 060832FC mov r14,r2
    c.r[2] += 2;  // 060832FE add #2,r2
    c.r[1] = 0xFFFFFFFFu;  // 06083300 mov #-1,r1
    st8(c.r[2], c.r[1]);  // 06083302 mov.b r1,@r2
    c.r[6] = 0x0u;  // 06083304 mov #0,r6
    c.r[5] = c.r[14];  // 06083306 mov r14,r5
    c.r[0] = ld32(0x060835D8u);  // 06083308 mov.l 0x060835D8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0608330Eu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608330Eu) return; }  // 0608330A jsr @r0 ; mov #0,r4
    c.r[11] = ld32(0x06083428u);  // 0608330E mov.l 0x06083428,r11
    c.r[10] = 0x28u;  // 06083310 mov #40,r10
    c.r[6] = 0x0u;  // 06083312 mov #0,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 06083314 mov.b @r13,r1
    c.r[4] = 0x0u;  // 06083316 mov #0,r4
    c.r[1] = c.r[1] & 0xFFu;  // 06083318 extu.b r1,r1
    c.macl = c.r[1] * c.r[10];  // 0608331A mul.l r10,r1
    c.r[3] = ld32(0x06083408u);  // 0608331C mov.l 0x06083408,r3
    c.r[5] = ld32(c.r[11]);  // 0608331E mov.l @r11,r5
    c.r[1] = c.macl;  // 06083320 sts macl,r1
    c.r[5] += c.r[1];  // 06083322 add r1,r5
    { const uint32_t x = c.r[3]; c.pr = 0x06083328u; c.r[5] += 16; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083328u) return; }  // 06083324 jsr @r3 ; add #16,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 06083328 mov.b @r13,r1
    c.r[12] = ld32(0x0608342Cu);  // 0608332A mov.l 0x0608342C,r12
    c.r[1] = c.r[1] & 0xFFu;  // 0608332C extu.b r1,r1
    c.macl = c.r[1] * c.r[10];  // 0608332E mul.l r10,r1
    c.r[5] = 0x0u;  // 06083330 mov #0,r5
    c.r[2] = ld32(c.r[11]);  // 06083332 mov.l @r11,r2
    c.r[1] = c.macl;  // 06083334 sts macl,r1
    c.r[1] += c.r[2];  // 06083336 add r2,r1
    c.r[1] += 37;  // 06083338 add #37,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0608333A mov.b @r1,r6
    c.r[4] = 0x0u;  // 0608333C mov #0,r4
    { const uint32_t x = c.r[12]; c.pr = 0x06083342u; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083342u) return; }  // 0608333E jsr @r12 ; extu.b r6,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 06083342 mov.b @r13,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06083344 extu.b r1,r1
    c.macl = c.r[1] * c.r[10];  // 06083346 mul.l r10,r1
    c.r[5] = 0x0u;  // 06083348 mov #0,r5
    c.r[2] = ld32(c.r[11]);  // 0608334A mov.l @r11,r2
    c.r[1] = c.macl;  // 0608334C sts macl,r1
    c.r[1] += c.r[2];  // 0608334E add r2,r1
    c.r[1] += 36;  // 06083350 add #36,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06083352 mov.b @r1,r6
    c.r[4] = 0x0u;  // 06083354 mov #0,r4
    c.r[6] = c.r[6] & 0xFFu;  // 06083356 extu.b r6,r6
    { const uint32_t x = c.r[12]; c.pr = 0x0608335Cu; c.r[6] -= 1; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608335Cu) return; }  // 06083358 jsr @r12 ; add #-1,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 0608335C mov.b @r13,r1
    c.r[4] = ld32(0x06083404u);  // 0608335E mov.l 0x06083404,r4
    c.r[1] = c.r[1] & 0xFFu;  // 06083360 extu.b r1,r1
    c.macl = c.r[1] * c.r[10];  // 06083362 mul.l r10,r1
    c.r[9] = ld32(0x06083400u);  // 06083364 mov.l 0x06083400,r9
    c.r[2] = ld32(c.r[11]);  // 06083366 mov.l @r11,r2
    c.r[1] = c.macl;  // 06083368 sts macl,r1
    c.r[1] += c.r[2];  // 0608336A add r2,r1
    c.r[1] += 38;  // 0608336C add #38,r1
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0608336E mov.b @r1,r8
    c.r[5] = 0x16u;  // 06083370 mov #22,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06083376u; c.r[8] = c.r[8] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083376u) return; }  // 06083372 jsr @r9 ; extu.b r8,r8
    c.r[1] = c.r[0];  // 06083376 mov r0,r1
    c.r[5] = c.r[8];  // 06083378 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0608337Eu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608337Eu) return; }  // 0608337A jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 0608337E mov r0,r1
    c.r[6] = 0x0u;  // 06083380 mov #0,r6
    c.r[5] = c.r[1];  // 06083382 mov r1,r5
    c.r[0] = ld32(0x060835D8u);  // 06083384 mov.l 0x060835D8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0608338Au; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608338Au) return; }  // 06083386 jsr @r0 ; mov #0,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 0608338A mov.b @r13,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0608338C extu.b r1,r1
    c.macl = c.r[1] * c.r[10];  // 0608338E mul.l r10,r1
    c.r[5] = 0x0u;  // 06083390 mov #0,r5
    c.r[2] = ld32(c.r[11]);  // 06083392 mov.l @r11,r2
    c.r[1] = c.macl;  // 06083394 sts macl,r1
    c.r[1] += c.r[2];  // 06083396 add r2,r1
    c.r[1] += 12;  // 06083398 add #12,r1
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0608339A mov.w @r1,r6
    c.r[4] = 0x0u;  // 0608339C mov #0,r4
    { const uint32_t x = c.r[12]; c.pr = 0x060833A2u; c.r[6] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060833A2u) return; }  // 0608339E jsr @r12 ; extu.w r6,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 060833A2 mov.b @r13,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060833A4 extu.b r1,r1
    c.macl = c.r[1] * c.r[10];  // 060833A6 mul.l r10,r1
    c.r[5] = 0x0u;  // 060833A8 mov #0,r5
    c.r[2] = ld32(c.r[11]);  // 060833AA mov.l @r11,r2
    c.r[1] = c.macl;  // 060833AC sts macl,r1
    c.r[1] += c.r[2];  // 060833AE add r2,r1
    c.r[6] = ld32(c.r[1] + 8);  // 060833B0 mov.l @(8,r1),r6
    { const uint32_t x = c.r[12]; c.pr = 0x060833B6u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060833B6u) return; }  // 060833B2 jsr @r12 ; mov #0,r4
    c.r[1] = ld32(0x06083414u);  // 060833B6 mov.l 0x06083414,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060833BCu; c.r[4] = 0x47u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060833BCu) return; }  // 060833B8 jsr @r1 ; mov #71,r4
    c.r[6] = 0x15u;  // 060833BC mov #21,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 060833BE mov.b @r13,r1
    c.r[5] = 0x2u;  // 060833C0 mov #2,r5
    c.r[1] = c.r[1] & 0xFFu;  // 060833C2 extu.b r1,r1
    c.macl = c.r[1] * c.r[10];  // 060833C4 mul.l r10,r1
    c.r[4] = 0x0u;  // 060833C6 mov #0,r4
    c.r[2] = ld32(c.r[11]);  // 060833C8 mov.l @r11,r2
    c.r[1] = c.macl;  // 060833CA sts macl,r1
    c.r[1] += c.r[2];  // 060833CC add r2,r1
    c.r[1] += 14;  // 060833CE add #14,r1
    c.r[7] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060833D0 mov.w @r1,r7
    c.r[3] = ld32(0x06083430u);  // 060833D2 mov.l 0x06083430,r3
    c.r[7] = c.r[7] & 0xFFFFu;  // 060833D4 extu.w r7,r7
    c.r[1] = 0x0u;  // 060833D6 mov #0,r1
    { const uint32_t x = c.r[3]; c.pr = 0x060833DCu; c.r[15] -= 4; st32(c.r[15], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060833DCu) return; }  // 060833D8 jsr @r3 ; mov.l r1,@-r15
    goto L_060833E6;  // 060833DC bra 0x060833E6 ; nop
L_060833E0:
    c.r[1] = ld32(0x06083414u);  // 060833E0 mov.l 0x06083414,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060833E6u; c.r[4] = 0x5Bu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060833E6u) return; }  // 060833E2 jsr @r1 ; mov #91,r4
L_060833E6:
    c.r[0] = (uint32_t)(int16_t)ld16(0x060833FEu);  // 060833E6 mov.w 0x060833FE,r0
    c.r[14] += 52;  // 060833E8 add #52,r14
L_060833EA:
    c.r[15] = c.r[14];  // 060833EA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060833EC lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060833EE mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060833F0 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060833F2 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060833F4 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060833F6 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060833F8 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060833FA rts ; mov.l @r15+,r8
}

void f_06083434(SH2Context& c) {
    ran[1839] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06083434 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06083436 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06083438 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0608343A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0608343C mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0608343E mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06083440 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06083442 sts.l pr,@-r15
    c.r[15] -= 40;  // 06083444 add #-40,r15
    c.r[14] = c.r[15];  // 06083446 mov r15,r14
    c.r[8] = 0x0u;  // 06083448 mov #0,r8
    c.r[1] = ld32(0x060835ACu);  // 0608344A mov.l 0x060835AC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06083450u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083450u) return; }  // 0608344C jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x060835B0u);  // 06083450 mov.l 0x060835B0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06083456u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083456u) return; }  // 06083452 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x060835B4u);  // 06083456 mov.l 0x060835B4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0608345Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608345Cu) return; }  // 06083458 jsr @r1 ; nop
    c.r[12] = ld32(0x060835B8u);  // 0608345C mov.l 0x060835B8,r12
    c.r[0] = (uint32_t)(int16_t)ld16(0x060835A8u);  // 0608345E mov.w 0x060835A8,r0
    c.r[7] = 0x2u;  // 06083460 mov #2,r7
    c.r[6] = 0x24u;  // 06083462 mov #36,r6
    c.r[1] = ld32(c.r[12]);  // 06083464 mov.l @r12,r1
    c.r[5] = 0x5u;  // 06083466 mov #5,r5
    st32(c.r[14] + 36, c.r[0]);  // 06083468 mov.l r0,@(36,r14)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0608346A mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0608346C extu.b r1,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0608346E mov.l r1,@-r15
    c.r[1] = 0x1u;  // 06083470 mov #1,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06083472 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06083474 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06083476 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06083478 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0608347A mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608347C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608347E mov.l r8,@-r15
    c.r[0] = 0x7u;  // 06083480 mov #7,r0
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 06083482 mov.l r0,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06083484 mov.l r1,@-r15
    c.r[1] = ld32(0x060835BCu);  // 06083486 mov.l 0x060835BC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0608348Cu; c.r[4] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608348Cu) return; }  // 06083488 jsr @r1 ; mov #2,r4
    c.r[15] += 40;  // 0608348C add #40,r15
    c.r[0] = ld32(0x060835C0u);  // 0608348E mov.l 0x060835C0,r0
    c.r[13] = ld32(0x060835C4u);  // 06083490 mov.l 0x060835C4,r13
    c.r[8] = ld32(0x060835C8u);  // 06083492 mov.l 0x060835C8,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06083494 mov.b @r0,r1
    c.r[5] = 0x0u;  // 06083496 mov #0,r5
    c.r[1] = c.r[1] & 0xFFu;  // 06083498 extu.b r1,r1
    c.r[0] = c.r[1];  // 0608349A mov r1,r0
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[13]);  // 0608349C mov.b @(r0,r13),r6
    c.r[4] = 0x0u;  // 0608349E mov #0,r4
    { const uint32_t x = c.r[8]; c.pr = 0x060834A4u; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060834A4u) return; }  // 060834A0 jsr @r8 ; extu.b r6,r6
    c.r[1] = ld32(c.r[12]);  // 060834A4 mov.l @r12,r1
    c.r[0] = ld32(c.r[14] + 36);  // 060834A6 mov.l @(36,r14),r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060834A8 mov.b @(r0,r1),r2
    c.r[2] = c.r[2] & 0xFFu;  // 060834AA extu.b r2,r2
    c.r[2] += 6;  // 060834AC add #6,r2
    c.r[1] = ld32(0x060835CCu);  // 060834AE mov.l 0x060835CC,r1
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[2] * (int32_t)c.r[1]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060834B0 dmuls.l r1,r2
    c.r[5] = 0x0u;  // 060834B2 mov #0,r5
    c.r[4] = 0x0u;  // 060834B4 mov #0,r4
    c.r[6] = c.mach;  // 060834B6 sts mach,r6
    c.r[6] += c.r[2];  // 060834B8 add r2,r6
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 060834BA shar r6
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 060834BC shar r6
    c.t = c.r[2] >> 31; c.r[2] <<= 1;  // 060834BE shll r2
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060834C0 subc r2,r2
    { const uint32_t x = c.r[8]; c.pr = 0x060834C6u; c.r[6] -= c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060834C6u) return; }  // 060834C2 jsr @r8 ; sub r2,r6
    c.r[10] = ld32(0x060835D0u);  // 060834C6 mov.l 0x060835D0,r10
    c.r[9] = ld32(0x060835D4u);  // 060834C8 mov.l 0x060835D4,r9
    c.r[5] = 0x17u;  // 060834CA mov #23,r5
    { const uint32_t x = c.r[9]; c.pr = 0x060834D0u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060834D0u) return; }  // 060834CC jsr @r9 ; mov r10,r4
    c.r[1] = c.r[0];  // 060834D0 mov r0,r1
    c.r[5] = 0x23u;  // 060834D2 mov #35,r5
    { const uint32_t x = c.r[9]; c.pr = 0x060834D8u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060834D8u) return; }  // 060834D4 jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 060834D8 mov r0,r1
    c.r[5] = 0xAu;  // 060834DA mov #10,r5
    { const uint32_t x = c.r[9]; c.pr = 0x060834E0u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060834E0u) return; }  // 060834DC jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 060834E0 mov r0,r1
    c.r[11] = ld32(0x060835D8u);  // 060834E2 mov.l 0x060835D8,r11
    c.r[6] = 0x0u;  // 060834E4 mov #0,r6
    c.r[5] = c.r[1];  // 060834E6 mov r1,r5
    { const uint32_t x = c.r[11]; c.pr = 0x060834ECu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060834ECu) return; }  // 060834E8 jsr @r11 ; mov #0,r4
    c.r[1] = ld32(0x060835DCu);  // 060834EC mov.l 0x060835DC,r1
    c.r[5] = 0x17u;  // 060834EE mov #23,r5
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060834F0 mov.w @r1,r8
    c.r[4] = c.r[10];  // 060834F2 mov r10,r4
    c.r[8] += 2;  // 060834F4 add #2,r8
    { const uint32_t x = c.r[9]; c.pr = 0x060834FAu; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060834FAu) return; }  // 060834F6 jsr @r9 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 060834FA mov r0,r1
    c.r[5] = 0x23u;  // 060834FC mov #35,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06083502u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083502u) return; }  // 060834FE jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 06083502 mov r0,r1
    c.r[5] = c.r[8];  // 06083504 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0608350Au; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608350Au) return; }  // 06083506 jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 0608350A mov r0,r1
    c.r[6] = 0x0u;  // 0608350C mov #0,r6
    c.r[5] = c.r[1];  // 0608350E mov r1,r5
    { const uint32_t x = c.r[11]; c.pr = 0x06083514u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083514u) return; }  // 06083510 jsr @r11 ; mov #0,r4
    c.r[0] = ld32(0x060835C0u);  // 06083514 mov.l 0x060835C0,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06083516 mov.b @r0,r1
    c.r[7] = c.r[1] & 0xFFu;  // 06083518 extu.b r1,r7
    c.r[0] = c.r[7];  // 0608351A mov r7,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[13]);  // 0608351C mov.b @(r0,r13),r1
    c.r[10] = c.r[1] & 0xFFu;  // 0608351E extu.b r1,r10
    c.r[10] -= 1;  // 06083520 add #-1,r10
    c.r[0] = 0x7u;  // 06083522 mov #7,r0
    c.macl = c.r[10] * c.r[0];  // 06083524 mul.l r0,r10
    c.r[3] = ld32(0x060835E0u);  // 06083526 mov.l 0x060835E0,r3
    c.r[1] = ld32(0x060835E4u);  // 06083528 mov.l 0x060835E4,r1
    c.r[0] = c.r[7];  // 0608352A mov r7,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0608352C mov.b @(r0,r1),r1
    c.r[2] = c.macl;  // 0608352E sts macl,r2
    c.r[2] += c.r[1];  // 06083530 add r1,r2
    st8(c.r[3], c.r[2]);  // 06083532 mov.b r2,@r3
    c.r[1] = ld32(c.r[12]);  // 06083534 mov.l @r12,r1
    c.r[0] = ld32(c.r[14] + 36);  // 06083536 mov.l @(36,r14),r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06083538 mov.b @(r0,r1),r1
    c.r[4] = c.r[1] & 0xFFu;  // 0608353A extu.b r1,r4
    c.r[1] = c.macl;  // 0608353C sts macl,r1
    c.r[4] -= c.r[1];  // 0608353E sub r1,r4
    c.r[0] = 0x7u;  // 06083540 mov #7,r0
    c.t = (int32_t)c.r[4] > (int32_t)c.r[0];  // 06083542 cmp/gt r0,r4
    { const bool k = c.t; c.r[8] = 0x7u; if (k) { goto L_0608354A; } }  // 06083544 bt/s 0x0608354A ; mov #7,r8
    c.r[8] = c.r[4];  // 06083548 mov r4,r8
L_0608354A:
    c.r[9] = ld32(0x060835E8u);  // 0608354A mov.l 0x060835E8,r9
    { const uint32_t x = c.r[9]; c.pr = 0x06083550u; c.r[4] = c.r[8] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083550u) return; }  // 0608354C jsr @r9 ; extu.b r8,r4
    c.r[1] = 0x7u;  // 06083550 mov #7,r1
    c.macl = c.r[10] * c.r[1];  // 06083552 mul.l r1,r10
    c.r[0] = c.macl;  // 06083554 sts macl,r0
    c.r[0] += c.r[8];  // 06083556 add r8,r0
    c.r[11] = c.macl;  // 06083558 sts macl,r11
    c.t = (int32_t)c.r[11] >= (int32_t)c.r[0];  // 0608355A cmp/ge r0,r11
    { const bool k = !c.t; st32(c.r[14] + 32, c.r[0]); if (k) { goto L_06083564; } }  // 0608355C bf/s 0x06083564 ; mov.l r0,@(32,r14)
    goto L_060836EC;  // 06083560 bra 0x060836EC ; nop
L_06083564:
    c.r[13] = c.r[9];  // 06083564 mov r9,r13
    c.r[1] = 0x28u;  // 06083566 mov #40,r1
    c.macl = c.r[11] * c.r[1];  // 06083568 mul.l r1,r11
    c.r[12] = ld32(0x060835ECu);  // 0608356A mov.l 0x060835EC,r12
    c.r[10] = ld32(0x060835C8u);  // 0608356C mov.l 0x060835C8,r10
    c.r[9] = c.macl;  // 0608356E sts macl,r9
L_06083570:
    c.r[4] = (uint32_t)(int16_t)ld16(0x060835AAu);  // 06083570 mov.w 0x060835AA,r4
    { const uint32_t x = c.r[13]; c.pr = 0x06083576u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083576u) return; }  // 06083572 jsr @r13 ; nop
    c.r[0] = ld32(0x060835B8u);  // 06083576 mov.l 0x060835B8,r0
    c.r[2] = c.r[11];  // 06083578 mov r11,r2
    c.r[1] = ld32(c.r[0]);  // 0608357A mov.l @r0,r1
    c.r[2] += c.r[2];  // 0608357C add r2,r2
    c.r[0] = c.r[1];  // 0608357E mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06083580 mov.b @(r0,r2),r1
    c.r[0] = 0x7Fu;  // 06083582 mov #127,r0
    c.r[1] &= c.r[0];  // 06083584 and r0,r1
    c.r[1] >>= 2;  // 06083586 shlr2 r1
    c.r[1] >>= 2;  // 06083588 shlr2 r1
    c.r[1] >>= 2;  // 0608358A shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0608358C tst r1,r1
    if (!c.t) { goto L_060835F0; }  // 0608358E bf 0x060835F0
    c.r[1] = ld32(c.r[12]);  // 06083590 mov.l @r12,r1
    c.r[1] += c.r[9];  // 06083592 add r9,r1
    c.r[1] += 39;  // 06083594 add #39,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06083596 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06083598 extu.b r1,r0
    c.t = c.r[0] == 0x49u;  // 0608359A cmp/eq #73,r0
    if (!c.t) { goto L_060835A4; }  // 0608359C bf 0x060835A4
    c.r[4] = 0x4u;  // 0608359E mov #4,r4
    goto L_060835F2;  // 060835A0 bra 0x060835F2 ; nop
L_060835A4:
    c.r[4] = 0x2u; goto L_060835F2;  // 060835A4 bra 0x060835F2 ; mov #2,r4
L_060835F0:
    c.r[4] = 0x1u;  // 060835F0 mov #1,r4
L_060835F2:
    { const uint32_t x = c.r[13]; c.pr = 0x060835F6u; c.r[8] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060835F6u) return; }  // 060835F2 jsr @r13 ; mov r11,r8
    c.r[0] = ld32(0x06083838u);  // 060835F6 mov.l 0x06083838,r0
    c.r[8] += c.r[8];  // 060835F8 add r8,r8
    c.r[5] = ld32(0x0608383Cu);  // 060835FA mov.l 0x0608383C,r5
    c.r[1] = ld32(c.r[0]);  // 060835FC mov.l @r0,r1
    c.r[4] = c.r[14];  // 060835FE mov r14,r4
    c.r[1] += c.r[8];  // 06083600 add r8,r1
    c.r[1] += 1;  // 06083602 add #1,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06083604 mov.b @r1,r6
    c.r[0] = ld32(0x06083840u);  // 06083606 mov.l 0x06083840,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0608360Cu; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608360Cu) return; }  // 06083608 jsr @r0 ; extu.b r6,r6
    c.r[2] = c.r[14];  // 0608360C mov r14,r2
    c.r[2] += 2;  // 0608360E add #2,r2
    c.r[1] = 0xFFFFFFFFu;  // 06083610 mov #-1,r1
    st8(c.r[2], c.r[1]);  // 06083612 mov.b r1,@r2
    c.r[6] = 0x0u;  // 06083614 mov #0,r6
    c.r[5] = c.r[14];  // 06083616 mov r14,r5
    c.r[0] = ld32(0x060839B4u);  // 06083618 mov.l 0x060839B4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0608361Eu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608361Eu) return; }  // 0608361A jsr @r0 ; mov #0,r4
    c.r[0] = ld32(0x06083838u);  // 0608361E mov.l 0x06083838,r0
    c.r[1] = ld32(c.r[0]);  // 06083620 mov.l @r0,r1
    c.r[0] = c.r[1];  // 06083622 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 06083624 mov.b @(r0,r8),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06083626 extu.b r1,r1
    c.r[1] >>= 2;  // 06083628 shlr2 r1
    c.r[1] >>= 2;  // 0608362A shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0608362C shlr r1
    c.r[1] >>= 2;  // 0608362E shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06083630 tst r1,r1
    { const bool k = !c.t; c.r[0] = c.r[9]; if (k) { goto L_06083692; } }  // 06083632 bf/s 0x06083692 ; mov r9,r0
    c.r[1] = ld32(c.r[12]);  // 06083636 mov.l @r12,r1
    c.r[5] = 0x0u;  // 06083638 mov #0,r5
    c.r[6] = ld32(c.r[0] + c.r[1]);  // 0608363A mov.l @(r0,r1),r6
    c.r[4] = 0x0u;  // 0608363C mov #0,r4
    c.r[6] >>= 16;  // 0608363E shlr16 r6
    { const uint32_t x = c.r[10]; c.pr = 0x06083644u; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083644u) return; }  // 06083640 jsr @r10 ; extu.b r6,r6
    c.r[0] = c.r[9];  // 06083644 mov r9,r0
    c.r[1] = ld32(c.r[12]);  // 06083646 mov.l @r12,r1
    c.r[5] = 0x0u;  // 06083648 mov #0,r5
    c.r[6] = ld32(c.r[0] + c.r[1]);  // 0608364A mov.l @(r0,r1),r6
    c.r[4] = 0x0u;  // 0608364C mov #0,r4
    c.r[6] >>= 8;  // 0608364E shlr8 r6
    { const uint32_t x = c.r[10]; c.pr = 0x06083654u; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083654u) return; }  // 06083650 jsr @r10 ; extu.b r6,r6
    c.r[1] = ld32(c.r[12]);  // 06083654 mov.l @r12,r1
    c.r[5] = 0x0u;  // 06083656 mov #0,r5
    c.r[1] += c.r[9];  // 06083658 add r9,r1
    c.r[6] = ld32(c.r[1] + 4);  // 0608365A mov.l @(4,r1),r6
    c.r[4] = 0x0u;  // 0608365C mov #0,r4
    c.r[6] >>= 8;  // 0608365E shlr8 r6
    { const uint32_t x = c.r[10]; c.pr = 0x06083664u; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083664u) return; }  // 06083660 jsr @r10 ; extu.b r6,r6
    c.r[1] = ld32(c.r[12]);  // 06083664 mov.l @r12,r1
    c.r[5] = 0x0u;  // 06083666 mov #0,r5
    c.r[1] += c.r[9];  // 06083668 add r9,r1
    c.r[6] = ld32(c.r[1] + 4);  // 0608366A mov.l @(4,r1),r6
    c.r[4] = 0x0u;  // 0608366C mov #0,r4
    { const uint32_t x = c.r[10]; c.pr = 0x06083672u; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083672u) return; }  // 0608366E jsr @r10 ; extu.b r6,r6
    c.r[6] = 0x1u;  // 06083672 mov #1,r6
    c.r[4] = 0x0u;  // 06083674 mov #0,r4
    c.r[5] = ld32(c.r[12]);  // 06083676 mov.l @r12,r5
    c.r[0] = ld32(0x06083844u);  // 06083678 mov.l 0x06083844,r0
    c.r[5] += c.r[9];  // 0608367A add r9,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06083680u; c.r[5] += 30; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083680u) return; }  // 0608367C jsr @r0 ; add #30,r5
    c.r[1] = ld32(c.r[12]);  // 06083680 mov.l @r12,r1
    c.r[5] = 0x0u;  // 06083682 mov #0,r5
    c.r[1] += c.r[9];  // 06083684 add r9,r1
    c.r[1] += 36;  // 06083686 add #36,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06083688 mov.b @r1,r6
    c.r[4] = 0x0u;  // 0608368A mov #0,r4
    c.r[6] = c.r[6] & 0xFFu;  // 0608368C extu.b r6,r6
    c.r[6] -= 1; goto L_060836DC;  // 0608368E bra 0x060836DC ; add #-1,r6
L_06083692:
    c.r[6] = 0x0u;  // 06083692 mov #0,r6
    c.r[5] = 0x0u;  // 06083694 mov #0,r5
    { const uint32_t x = c.r[10]; c.pr = 0x0608369Au; c.r[4] = 0x20u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608369Au) return; }  // 06083696 jsr @r10 ; mov #32,r4
    c.r[6] = 0x0u;  // 0608369A mov #0,r6
    c.r[5] = 0x0u;  // 0608369C mov #0,r5
    { const uint32_t x = c.r[10]; c.pr = 0x060836A2u; c.r[4] = 0x20u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060836A2u) return; }  // 0608369E jsr @r10 ; mov #32,r4
    c.r[6] = 0x0u;  // 060836A2 mov #0,r6
    c.r[5] = 0x0u;  // 060836A4 mov #0,r5
    { const uint32_t x = c.r[10]; c.pr = 0x060836AAu; c.r[4] = 0x20u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060836AAu) return; }  // 060836A6 jsr @r10 ; mov #32,r4
    c.r[6] = 0x0u;  // 060836AA mov #0,r6
    c.r[5] = 0x0u;  // 060836AC mov #0,r5
    { const uint32_t x = c.r[10]; c.pr = 0x060836B2u; c.r[4] = 0x20u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060836B2u) return; }  // 060836AE jsr @r10 ; mov #32,r4
    c.r[8] = ld32(0x06083848u);  // 060836B2 mov.l 0x06083848,r8
    c.r[4] = ld32(0x0608384Cu);  // 060836B4 mov.l 0x0608384C,r4
    { const uint32_t x = c.r[8]; c.pr = 0x060836BAu; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060836BAu) return; }  // 060836B6 jsr @r8 ; mov #23,r5
    c.r[1] = c.r[0];  // 060836BA mov r0,r1
    c.r[5] = 0x23u;  // 060836BC mov #35,r5
    { const uint32_t x = c.r[8]; c.pr = 0x060836C2u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060836C2u) return; }  // 060836BE jsr @r8 ; mov r1,r4
    c.r[1] = c.r[0];  // 060836C2 mov r0,r1
    c.r[5] = 0x5Fu;  // 060836C4 mov #95,r5
    { const uint32_t x = c.r[8]; c.pr = 0x060836CAu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060836CAu) return; }  // 060836C6 jsr @r8 ; mov r1,r4
    c.r[1] = c.r[0];  // 060836CA mov r0,r1
    c.r[6] = 0x0u;  // 060836CC mov #0,r6
    c.r[5] = c.r[1];  // 060836CE mov r1,r5
    c.r[0] = ld32(0x060839B4u);  // 060836D0 mov.l 0x060839B4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060836D6u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060836D6u) return; }  // 060836D2 jsr @r0 ; mov #0,r4
    c.r[6] = 0x0u;  // 060836D6 mov #0,r6
    c.r[5] = 0x0u;  // 060836D8 mov #0,r5
    c.r[4] = 0x20u;  // 060836DA mov #32,r4
L_060836DC:
    { const uint32_t x = c.r[10]; c.pr = 0x060836E0u; c.r[9] += 40; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060836E0u) return; }  // 060836DC jsr @r10 ; add #40,r9
    c.r[0] = ld32(c.r[14] + 32);  // 060836E0 mov.l @(32,r14),r0
    c.r[11] += 1;  // 060836E2 add #1,r11
    c.t = (int32_t)c.r[11] >= (int32_t)c.r[0];  // 060836E4 cmp/ge r0,r11
    if (c.t) { goto L_060836EC; }  // 060836E6 bt 0x060836EC
    SH2_POLL(c); goto L_06083570;  // 060836E8 bra 0x06083570 ; nop
L_060836EC:
    c.r[1] = 0x0u;  // 060836EC mov #0,r1
    st8(c.r[14], c.r[1]);  // 060836EE mov.b r1,@r14
    c.r[1] = c.r[14];  // 060836F0 mov r14,r1
    c.r[1] += 1;  // 060836F2 add #1,r1
    c.r[8] = 0xFFFFFFFFu;  // 060836F4 mov #-1,r8
    st8(c.r[1], c.r[8]);  // 060836F6 mov.b r8,@r1
    c.r[6] = 0x0u;  // 060836F8 mov #0,r6
    c.r[5] = c.r[14];  // 060836FA mov r14,r5
    c.r[0] = ld32(0x060839B4u);  // 060836FC mov.l 0x060839B4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06083702u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083702u) return; }  // 060836FE jsr @r0 ; mov #0,r4
    c.r[1] = ld32(0x06083838u);  // 06083702 mov.l 0x06083838,r1
    c.r[6] = ld32(c.r[1]);  // 06083704 mov.l @r1,r6
    c.r[13] = ld32(0x06083850u);  // 06083706 mov.l 0x06083850,r13
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 06083708 mov.b @r13,r1
    c.r[0] = c.r[6];  // 0608370A mov r6,r0
    c.r[2] = c.r[1] & 0xFFu;  // 0608370C extu.b r1,r2
    c.r[2] += c.r[2];  // 0608370E add r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06083710 mov.b @(r0,r2),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06083712 extu.b r1,r1
    c.r[3] = c.r[1];  // 06083714 mov r1,r3
    c.r[3] >>= 2;  // 06083716 shlr2 r3
    c.r[3] >>= 2;  // 06083718 shlr2 r3
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 0608371A shlr r3
    c.r[3] >>= 2;  // 0608371C shlr2 r3
    c.r[0] = c.r[3];  // 0608371E mov r3,r0
    c.t = c.r[0] == 0x1u;  // 06083720 cmp/eq #1,r0
    { const bool k = c.t; c.r[6] += c.r[2]; if (k) { goto L_06083816; } }  // 06083722 bt/s 0x06083816 ; add r2,r6
    c.r[6] += 1;  // 06083726 add #1,r6
    c.r[5] = ld32(0x0608383Cu);  // 06083728 mov.l 0x0608383C,r5
    c.r[4] = c.r[14];  // 0608372A mov r14,r4
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0608372C mov.b @r6,r6
    c.r[0] = ld32(0x06083840u);  // 0608372E mov.l 0x06083840,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06083734u; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083734u) return; }  // 06083730 jsr @r0 ; extu.b r6,r6
    c.r[1] = c.r[14];  // 06083734 mov r14,r1
    c.r[1] += 2;  // 06083736 add #2,r1
    st8(c.r[1], c.r[8]);  // 06083738 mov.b r8,@r1
    c.r[6] = 0x0u;  // 0608373A mov #0,r6
    c.r[5] = c.r[14];  // 0608373C mov r14,r5
    c.r[0] = ld32(0x060839B4u);  // 0608373E mov.l 0x060839B4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06083744u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083744u) return; }  // 06083740 jsr @r0 ; mov #0,r4
    c.r[11] = ld32(0x06083854u);  // 06083744 mov.l 0x06083854,r11
    c.r[10] = 0x28u;  // 06083746 mov #40,r10
    c.r[6] = 0x0u;  // 06083748 mov #0,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 0608374A mov.b @r13,r1
    c.r[4] = 0x0u;  // 0608374C mov #0,r4
    c.r[1] = c.r[1] & 0xFFu;  // 0608374E extu.b r1,r1
    c.macl = c.r[1] * c.r[10];  // 06083750 mul.l r10,r1
    c.r[0] = ld32(0x06083844u);  // 06083752 mov.l 0x06083844,r0
    c.r[5] = ld32(c.r[11]);  // 06083754 mov.l @r11,r5
    c.r[1] = c.macl;  // 06083756 sts macl,r1
    c.r[5] += c.r[1];  // 06083758 add r1,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0608375Eu; c.r[5] += 16; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608375Eu) return; }  // 0608375A jsr @r0 ; add #16,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 0608375E mov.b @r13,r1
    c.r[12] = ld32(0x06083858u);  // 06083760 mov.l 0x06083858,r12
    c.r[1] = c.r[1] & 0xFFu;  // 06083762 extu.b r1,r1
    c.macl = c.r[1] * c.r[10];  // 06083764 mul.l r10,r1
    c.r[5] = 0x0u;  // 06083766 mov #0,r5
    c.r[2] = ld32(c.r[11]);  // 06083768 mov.l @r11,r2
    c.r[1] = c.macl;  // 0608376A sts macl,r1
    c.r[1] += c.r[2];  // 0608376C add r2,r1
    c.r[1] += 37;  // 0608376E add #37,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06083770 mov.b @r1,r6
    c.r[4] = 0x0u;  // 06083772 mov #0,r4
    { const uint32_t x = c.r[12]; c.pr = 0x06083778u; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083778u) return; }  // 06083774 jsr @r12 ; extu.b r6,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 06083778 mov.b @r13,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0608377A extu.b r1,r1
    c.macl = c.r[1] * c.r[10];  // 0608377C mul.l r10,r1
    c.r[5] = 0x0u;  // 0608377E mov #0,r5
    c.r[2] = ld32(c.r[11]);  // 06083780 mov.l @r11,r2
    c.r[1] = c.macl;  // 06083782 sts macl,r1
    c.r[1] += c.r[2];  // 06083784 add r2,r1
    c.r[1] += 36;  // 06083786 add #36,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06083788 mov.b @r1,r6
    c.r[4] = 0x0u;  // 0608378A mov #0,r4
    c.r[6] = c.r[6] & 0xFFu;  // 0608378C extu.b r6,r6
    { const uint32_t x = c.r[12]; c.pr = 0x06083792u; c.r[6] -= 1; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083792u) return; }  // 0608378E jsr @r12 ; add #-1,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 06083792 mov.b @r13,r1
    c.r[4] = ld32(0x0608384Cu);  // 06083794 mov.l 0x0608384C,r4
    c.r[1] = c.r[1] & 0xFFu;  // 06083796 extu.b r1,r1
    c.macl = c.r[1] * c.r[10];  // 06083798 mul.l r10,r1
    c.r[9] = ld32(0x06083848u);  // 0608379A mov.l 0x06083848,r9
    c.r[2] = ld32(c.r[11]);  // 0608379C mov.l @r11,r2
    c.r[1] = c.macl;  // 0608379E sts macl,r1
    c.r[1] += c.r[2];  // 060837A0 add r2,r1
    c.r[1] += 38;  // 060837A2 add #38,r1
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060837A4 mov.b @r1,r8
    c.r[5] = 0x16u;  // 060837A6 mov #22,r5
    { const uint32_t x = c.r[9]; c.pr = 0x060837ACu; c.r[8] = c.r[8] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060837ACu) return; }  // 060837A8 jsr @r9 ; extu.b r8,r8
    c.r[1] = c.r[0];  // 060837AC mov r0,r1
    c.r[5] = c.r[8];  // 060837AE mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x060837B4u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060837B4u) return; }  // 060837B0 jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 060837B4 mov r0,r1
    c.r[6] = 0x0u;  // 060837B6 mov #0,r6
    c.r[5] = c.r[1];  // 060837B8 mov r1,r5
    c.r[0] = ld32(0x060839B4u);  // 060837BA mov.l 0x060839B4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060837C0u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060837C0u) return; }  // 060837BC jsr @r0 ; mov #0,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 060837C0 mov.b @r13,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060837C2 extu.b r1,r1
    c.macl = c.r[1] * c.r[10];  // 060837C4 mul.l r10,r1
    c.r[5] = 0x0u;  // 060837C6 mov #0,r5
    c.r[2] = ld32(c.r[11]);  // 060837C8 mov.l @r11,r2
    c.r[1] = c.macl;  // 060837CA sts macl,r1
    c.r[1] += c.r[2];  // 060837CC add r2,r1
    c.r[1] += 12;  // 060837CE add #12,r1
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060837D0 mov.w @r1,r6
    c.r[4] = 0x0u;  // 060837D2 mov #0,r4
    { const uint32_t x = c.r[12]; c.pr = 0x060837D8u; c.r[6] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060837D8u) return; }  // 060837D4 jsr @r12 ; extu.w r6,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 060837D8 mov.b @r13,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060837DA extu.b r1,r1
    c.macl = c.r[1] * c.r[10];  // 060837DC mul.l r10,r1
    c.r[5] = 0x0u;  // 060837DE mov #0,r5
    c.r[2] = ld32(c.r[11]);  // 060837E0 mov.l @r11,r2
    c.r[1] = c.macl;  // 060837E2 sts macl,r1
    c.r[1] += c.r[2];  // 060837E4 add r2,r1
    c.r[6] = ld32(c.r[1] + 8);  // 060837E6 mov.l @(8,r1),r6
    { const uint32_t x = c.r[12]; c.pr = 0x060837ECu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060837ECu) return; }  // 060837E8 jsr @r12 ; mov #0,r4
    c.r[1] = ld32(0x0608385Cu);  // 060837EC mov.l 0x0608385C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060837F2u; c.r[4] = 0x47u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060837F2u) return; }  // 060837EE jsr @r1 ; mov #71,r4
    c.r[6] = 0x15u;  // 060837F2 mov #21,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 060837F4 mov.b @r13,r1
    c.r[5] = 0x2u;  // 060837F6 mov #2,r5
    c.r[1] = c.r[1] & 0xFFu;  // 060837F8 extu.b r1,r1
    c.macl = c.r[1] * c.r[10];  // 060837FA mul.l r10,r1
    c.r[4] = 0x0u;  // 060837FC mov #0,r4
    c.r[2] = ld32(c.r[11]);  // 060837FE mov.l @r11,r2
    c.r[1] = c.macl;  // 06083800 sts macl,r1
    c.r[1] += c.r[2];  // 06083802 add r2,r1
    c.r[1] += 14;  // 06083804 add #14,r1
    c.r[7] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06083806 mov.w @r1,r7
    c.r[0] = ld32(0x06083860u);  // 06083808 mov.l 0x06083860,r0
    c.r[7] = c.r[7] & 0xFFFFu;  // 0608380A extu.w r7,r7
    c.r[1] = 0x0u;  // 0608380C mov #0,r1
    { const uint32_t x = c.r[0]; c.pr = 0x06083812u; c.r[15] -= 4; st32(c.r[15], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083812u) return; }  // 0608380E jsr @r0 ; mov.l r1,@-r15
    goto L_0608381C;  // 06083812 bra 0x0608381C ; nop
L_06083816:
    c.r[1] = ld32(0x0608385Cu);  // 06083816 mov.l 0x0608385C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0608381Cu; c.r[4] = 0x5Bu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608381Cu) return; }  // 06083818 jsr @r1 ; mov #91,r4
L_0608381C:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06083834u);  // 0608381C mov.w 0x06083834,r0
    c.r[14] += 40;  // 0608381E add #40,r14
    c.r[15] = c.r[14];  // 06083820 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06083822 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06083824 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06083826 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06083828 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0608382A mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0608382C mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0608382E mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06083830 rts ; mov.l @r15+,r8
}

void f_06083868(SH2Context& c) {
    ran[1840] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06083868 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0608386A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0608386C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0608386E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06083870 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06083872 sts.l pr,@-r15
    c.r[15] -= 72;  // 06083874 add #-72,r15
    c.r[14] = c.r[15];  // 06083876 mov r15,r14
    c.r[8] = 0x5u;  // 06083878 mov #5,r8
    c.r[11] = 0xBu;  // 0608387A mov #11,r11
    c.r[1] = ld32(0x06083984u);  // 0608387C mov.l 0x06083984,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06083882u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083882u) return; }  // 0608387E jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x06083988u);  // 06083882 mov.l 0x06083988,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06083888u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083888u) return; }  // 06083884 jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x0608398Cu);  // 06083888 mov.l 0x0608398C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0608388Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608388Eu) return; }  // 0608388A jsr @r1 ; nop
    c.r[4] = (uint32_t)(int16_t)ld16(0x06083978u);  // 0608388E mov.w 0x06083978,r4
    c.r[1] = 0x4u;  // 06083890 mov #4,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06083892 mov.l r1,@-r15
    c.r[1] = ld32(0x06083990u);  // 06083894 mov.l 0x06083990,r1
    c.r[7] = 0x1Cu;  // 06083896 mov #28,r7
    c.r[6] = c.r[11];  // 06083898 mov r11,r6
    { const uint32_t x = c.r[1]; c.pr = 0x0608389Eu; c.r[5] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608389Eu) return; }  // 0608389A jsr @r1 ; mov r8,r5
    c.r[4] = (uint32_t)(int16_t)ld16(0x0608397Au);  // 0608389E mov.w 0x0608397A,r4
    c.r[8] = ld32(0x06083994u);  // 060838A0 mov.l 0x06083994,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060838A6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060838A6u) return; }  // 060838A2 jsr @r8 ; nop
    { const uint32_t x = c.r[8]; c.pr = 0x060838AAu; c.r[4] = 0x6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060838AAu) return; }  // 060838A6 jsr @r8 ; mov #6,r4
    { const uint32_t x = c.r[8]; c.pr = 0x060838AEu; c.r[4] = 0xCu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060838AEu) return; }  // 060838AA jsr @r8 ; mov #12,r4
    c.r[0] = ld32(0x06083998u);  // 060838AE mov.l 0x06083998,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060838B4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060838B4u) return; }  // 060838B0 jsr @r0 ; nop
    c.r[1] = ld32(0x0608399Cu);  // 060838B4 mov.l 0x0608399C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060838B6 mov.b @r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060838B8 tst r1,r1
    { const bool k = !c.t; c.r[15] += 4; if (k) { goto L_060838C4; } }  // 060838BA bf/s 0x060838C4 ; add #4,r15
    c.r[10] = (uint32_t)(int16_t)ld16(0x0608397Cu);  // 060838BE mov.w 0x0608397C,r10
    c.r[9] = 0x28u; goto L_060838E4;  // 060838C0 bra 0x060838E4 ; mov #40,r9
L_060838C4:
    c.r[0] = c.r[1];  // 060838C4 mov r1,r0
    c.t = c.r[0] == 0x1u;  // 060838C6 cmp/eq #1,r0
    { const bool k = !c.t; c.r[10] = 0x59u; if (k) { goto L_060838E0; } }  // 060838C8 bf/s 0x060838E0 ; mov #89,r10
    c.r[9] = 0x2Au;  // 060838CC mov #42,r9
    c.r[4] = ld32(0x060839A0u);  // 060838CE mov.l 0x060839A0,r4
    c.r[8] = ld32(0x060839A4u);  // 060838D0 mov.l 0x060839A4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060838D6u; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060838D6u) return; }  // 060838D2 jsr @r8 ; mov #23,r5
    c.r[5] = 0x23u;  // 060838D6 mov #35,r5
    { const uint32_t x = c.r[8]; c.pr = 0x060838DCu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060838DCu) return; }  // 060838D8 jsr @r8 ; mov r0,r4
    c.r[5] = c.r[11]; goto L_060838F4;  // 060838DC bra 0x060838F4 ; mov r11,r5
L_060838E0:
    c.r[10] = (uint32_t)(int16_t)ld16(0x0608397Eu);  // 060838E0 mov.w 0x0608397E,r10
    c.r[9] = 0x28u;  // 060838E2 mov #40,r9
L_060838E4:
    c.r[4] = ld32(0x060839A0u);  // 060838E4 mov.l 0x060839A0,r4
    c.r[8] = ld32(0x060839A4u);  // 060838E6 mov.l 0x060839A4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060838ECu; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060838ECu) return; }  // 060838E8 jsr @r8 ; mov #23,r5
    c.r[5] = 0x23u;  // 060838EC mov #35,r5
    { const uint32_t x = c.r[8]; c.pr = 0x060838F2u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060838F2u) return; }  // 060838EE jsr @r8 ; mov r0,r4
    c.r[5] = 0x25u;  // 060838F2 mov #37,r5
L_060838F4:
    { const uint32_t x = c.r[8]; c.pr = 0x060838F8u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060838F8u) return; }  // 060838F4 jsr @r8 ; mov r0,r4
    c.r[1] = ld32(0x060839A8u);  // 060838F8 mov.l 0x060839A8,r1
    c.r[6] = c.r[9];  // 060838FA mov r9,r6
    c.r[5] = c.r[0];  // 060838FC mov r0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06083902u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083902u) return; }  // 060838FE jsr @r1 ; mov r14,r4
    c.r[6] = c.r[10] & 0xFFu;  // 06083902 extu.b r10,r6
    c.r[5] = ld32(0x060839ACu);  // 06083904 mov.l 0x060839AC,r5
    c.r[4] = c.r[14];  // 06083906 mov r14,r4
    c.r[0] = ld32(0x060839B0u);  // 06083908 mov.l 0x060839B0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0608390Eu; c.r[4] += c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608390Eu) return; }  // 0608390A jsr @r0 ; add r9,r4
    c.r[2] = 0x0u;  // 0608390E mov #0,r2
    c.r[6] = 0x0u;  // 06083910 mov #0,r6
    c.r[7] = 0x2u;  // 06083912 mov #2,r7
    c.r[3] = c.r[9];  // 06083914 mov r9,r3
L_06083916:
    c.r[3] += c.r[2];  // 06083916 add r2,r3
    c.r[0] = c.r[14];  // 06083918 mov r14,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0608391A mov.b @(r0,r3),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0608391C extu.b r1,r1
    c.r[0] = c.r[1];  // 0608391E mov r1,r0
    c.t = c.r[0] == 0x20u;  // 06083920 cmp/eq #32,r0
    { const bool k = !c.t; c.r[0] = c.r[14]; if (k) { goto L_06083928; } }  // 06083922 bf/s 0x06083928 ; mov r14,r0
    st8(c.r[0] + c.r[3], c.r[6]);  // 06083926 mov.b r6,@(r0,r3)
L_06083928:
    c.r[2] += 1;  // 06083928 add #1,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[7];  // 0608392A cmp/gt r7,r2
    { const bool k = !c.t; c.r[3] = c.r[9]; if (k) { SH2_POLL(c); goto L_06083916; } }  // 0608392C bf/s 0x06083916 ; mov r9,r3
    c.r[1] = c.r[14];  // 06083930 mov r14,r1
    c.r[1] += 3;  // 06083932 add #3,r1
    c.r[9] += c.r[1];  // 06083934 add r1,r9
    c.r[4] = ld32(0x060839A0u);  // 06083936 mov.l 0x060839A0,r4
    c.r[8] = ld32(0x060839A4u);  // 06083938 mov.l 0x060839A4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608393Eu; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608393Eu) return; }  // 0608393A jsr @r8 ; mov #23,r5
    c.r[5] = 0x23u;  // 0608393E mov #35,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06083944u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083944u) return; }  // 06083940 jsr @r8 ; mov r0,r4
    c.r[5] = 0xCu;  // 06083944 mov #12,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0608394Au; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608394Au) return; }  // 06083946 jsr @r8 ; mov r0,r4
    c.r[1] = ld32(0x060839A8u);  // 0608394A mov.l 0x060839A8,r1
    c.r[6] = 0x19u;  // 0608394C mov #25,r6
    c.r[5] = c.r[0];  // 0608394E mov r0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06083954u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083954u) return; }  // 06083950 jsr @r1 ; mov r9,r4
    c.r[1] = ld32(0x060839B4u);  // 06083954 mov.l 0x060839B4,r1
    c.r[6] = 0x0u;  // 06083956 mov #0,r6
    c.r[5] = c.r[14];  // 06083958 mov r14,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0608395Eu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608395Eu) return; }  // 0608395A jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x060839B8u);  // 0608395E mov.l 0x060839B8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06083964u; c.r[4] = 0x42u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083964u) return; }  // 06083960 jsr @r1 ; mov #66,r4
    c.r[14] += 72;  // 06083964 add #72,r14
    c.r[15] = c.r[14];  // 06083966 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06083968 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608396A mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0608396C mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0608396E mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06083970 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06083980u);  // 06083972 mov.w 0x06083980,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06083974 rts ; mov.l @r15+,r8
}

void f_060839BC(SH2Context& c) {
    ran[1841] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060839BC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060839BE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060839C0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060839C2 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060839C4 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060839C6 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060839C8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060839CA sts.l pr,@-r15
    c.r[15] -= 4;  // 060839CC add #-4,r15
    c.r[14] = c.r[15];  // 060839CE mov r15,r14
    c.r[1] = ld32(0x06083B24u);  // 060839D0 mov.l 0x06083B24,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060839D6u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060839D6u) return; }  // 060839D2 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06083B28u);  // 060839D6 mov.l 0x06083B28,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060839DCu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060839DCu) return; }  // 060839D8 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06083B2Cu);  // 060839DC mov.l 0x06083B2C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060839E2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060839E2u) return; }  // 060839DE jsr @r1 ; nop
    c.r[1] = ld32(0x06083B30u);  // 060839E2 mov.l 0x06083B30,r1
    c.r[8] = ld32(0x06083B34u);  // 060839E4 mov.l 0x06083B34,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060839E6 mov.b @r1,r1
    c.r[5] = 0x0u;  // 060839E8 mov #0,r5
    c.r[2] = c.r[1] & 0xFFu;  // 060839EA extu.b r1,r2
    c.r[1] = ld32(0x06083B38u);  // 060839EC mov.l 0x06083B38,r1
    c.r[0] = c.r[2];  // 060839EE mov r2,r0
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060839F0 mov.b @(r0,r1),r6
    c.r[4] = 0x0u;  // 060839F2 mov #0,r4
    { const uint32_t x = c.r[8]; c.pr = 0x060839F8u; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060839F8u) return; }  // 060839F4 jsr @r8 ; extu.b r6,r6
    c.r[1] = ld32(0x06083B3Cu);  // 060839F8 mov.l 0x06083B3C,r1
    c.r[1] = ld32(c.r[1]);  // 060839FA mov.l @r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06083B16u);  // 060839FC mov.w 0x06083B16,r2
    c.r[0] = c.r[1];  // 060839FE mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06083A00 mov.b @(r0,r2),r2
    c.r[2] = c.r[2] & 0xFFu;  // 06083A02 extu.b r2,r2
    c.r[2] += 6;  // 06083A04 add #6,r2
    c.r[1] = ld32(0x06083B40u);  // 06083A06 mov.l 0x06083B40,r1
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[2] * (int32_t)c.r[1]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 06083A08 dmuls.l r1,r2
    c.r[5] = 0x0u;  // 06083A0A mov #0,r5
    c.r[4] = 0x0u;  // 06083A0C mov #0,r4
    c.r[6] = c.mach;  // 06083A0E sts mach,r6
    c.r[6] += c.r[2];  // 06083A10 add r2,r6
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 06083A12 shar r6
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 06083A14 shar r6
    c.t = c.r[2] >> 31; c.r[2] <<= 1;  // 06083A16 shll r2
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 06083A18 subc r2,r2
    { const uint32_t x = c.r[8]; c.pr = 0x06083A1Eu; c.r[6] -= c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083A1Eu) return; }  // 06083A1A jsr @r8 ; sub r2,r6
    c.r[9] = ld32(0x06083B44u);  // 06083A1E mov.l 0x06083B44,r9
    c.r[1] = ld32(c.r[9]);  // 06083A20 mov.l @r9,r1
    c.r[10] = (uint32_t)(int16_t)ld16(0x06083B18u);  // 06083A22 mov.w 0x06083B18,r10
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06083A24 mov.w @r1,r4
    c.r[5] = c.r[10];  // 06083A26 mov r10,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x06083B1Au);  // 06083A28 mov.w 0x06083B1A,r1
    c.r[4] += c.r[1];  // 06083A2A add r1,r4
    c.r[1] = ld32(0x06083B48u);  // 06083A2C mov.l 0x06083B48,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06083A32u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083A32u) return; }  // 06083A2E jsr @r1 ; extu.w r4,r4
    c.r[1] = ld32(c.r[9]);  // 06083A32 mov.l @r9,r1
    c.r[5] = 0x0u;  // 06083A34 mov #0,r5
    c.r[1] += 2;  // 06083A36 add #2,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06083A38 mov.b @r1,r6
    c.r[4] = 0x0u;  // 06083A3A mov #0,r4
    { const uint32_t x = c.r[8]; c.pr = 0x06083A40u; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083A40u) return; }  // 06083A3C jsr @r8 ; extu.b r6,r6
    c.r[4] = ld32(0x06083B4Cu);  // 06083A40 mov.l 0x06083B4C,r4
    c.r[8] = ld32(0x06083B50u);  // 06083A42 mov.l 0x06083B50,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06083A48u; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083A48u) return; }  // 06083A44 jsr @r8 ; mov #23,r5
    c.r[1] = c.r[0];  // 06083A48 mov r0,r1
    c.r[5] = 0x23u;  // 06083A4A mov #35,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06083A50u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083A50u) return; }  // 06083A4C jsr @r8 ; mov r1,r4
    c.r[1] = c.r[0];  // 06083A50 mov r0,r1
    c.r[5] = 0x31u;  // 06083A52 mov #49,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06083A58u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083A58u) return; }  // 06083A54 jsr @r8 ; mov r1,r4
    c.r[2] = c.r[0];  // 06083A58 mov r0,r2
    c.r[1] = ld32(0x06083B54u);  // 06083A5A mov.l 0x06083B54,r1
    c.r[6] = 0x0u;  // 06083A5C mov #0,r6
    c.r[5] = c.r[2];  // 06083A5E mov r2,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06083A64u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083A64u) return; }  // 06083A60 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(c.r[9]);  // 06083A64 mov.l @r9,r1
    c.r[1] += 8;  // 06083A66 add #8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06083A68 mov.b @r1,r1
    c.r[5] = c.r[1] & 0xFFu;  // 06083A6A extu.b r1,r5
    c.r[1] = ld32(0x06083B58u);  // 06083A6C mov.l 0x06083B58,r1
    c.r[2] = ld32(c.r[1]);  // 06083A6E mov.l @r1,r2
    c.r[1] = c.r[5];  // 06083A70 mov r5,r1
    c.r[1] += c.r[1];  // 06083A72 add r1,r1
    c.r[1] += c.r[5];  // 06083A74 add r5,r1
    c.r[1] <<= 2;  // 06083A76 shll2 r1
    c.r[0] = c.r[1];  // 06083A78 mov r1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 06083A7A mov.w @(r0,r2),r1
    c.r[2] = c.r[1] & 0xFFFFu;  // 06083A7C extu.w r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06083B1Cu);  // 06083A7E mov.w 0x06083B1C,r1
    c.t = c.r[2] == c.r[1];  // 06083A80 cmp/eq r1,r2
    if (c.t) { goto L_06083A8C; }  // 06083A82 bt 0x06083A8C
    c.r[1] = (uint32_t)(int16_t)ld16(0x06083B1Eu);  // 06083A84 mov.w 0x06083B1E,r1
    c.t = c.r[2] == c.r[1];  // 06083A86 cmp/eq r1,r2
    if (c.t) { goto L_06083A8C; }  // 06083A88 bt 0x06083A8C
    c.r[5] = c.r[10];  // 06083A8A mov r10,r5
L_06083A8C:
    c.r[2] = (uint32_t)(int16_t)ld16(0x06083B18u);  // 06083A8C mov.w 0x06083B18,r2
    c.t = c.r[5] == c.r[2];  // 06083A8E cmp/eq r2,r5
    { const bool k = c.t; c.r[9] = c.r[5]; if (k) { goto L_06083AC0; } }  // 06083A90 bt/s 0x06083AC0 ; mov r5,r9
    c.r[8] = ld32(0x06083B58u);  // 06083A94 mov.l 0x06083B58,r8
    c.r[9] += c.r[9];  // 06083A96 add r9,r9
    c.r[9] += c.r[5];  // 06083A98 add r5,r9
    c.r[9] <<= 2;  // 06083A9A shll2 r9
    c.r[1] = ld32(c.r[8]);  // 06083A9C mov.l @r8,r1
    c.r[0] = c.r[9];  // 06083A9E mov r9,r0
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06083AA0 mov.w @(r0,r1),r4
    c.r[5] = c.r[2];  // 06083AA2 mov r2,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x06083B20u);  // 06083AA4 mov.w 0x06083B20,r1
    c.r[4] += c.r[1];  // 06083AA6 add r1,r4
    c.r[1] = ld32(0x06083B48u);  // 06083AA8 mov.l 0x06083B48,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06083AAEu; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083AAEu) return; }  // 06083AAA jsr @r1 ; extu.w r4,r4
    c.r[5] = 0x0u;  // 06083AAE mov #0,r5
    c.r[1] = ld32(c.r[8]);  // 06083AB0 mov.l @r8,r1
    c.r[4] = 0x0u;  // 06083AB2 mov #0,r4
    c.r[9] += c.r[1];  // 06083AB4 add r1,r9
    c.r[9] += 2;  // 06083AB6 add #2,r9
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06083AB8 mov.b @r9,r6
    c.r[1] = ld32(0x06083B34u);  // 06083ABA mov.l 0x06083B34,r1
    c.r[6] = c.r[6] & 0xFFu; goto L_06083AD0;  // 06083ABC bra 0x06083AD0 ; extu.b r6,r6
L_06083AC0:
    c.r[4] = ld32(0x06083B5Cu);  // 06083AC0 mov.l 0x06083B5C,r4
    c.r[1] = ld32(0x06083B48u);  // 06083AC2 mov.l 0x06083B48,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06083AC8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083AC8u) return; }  // 06083AC4 jsr @r1 ; nop
    c.r[1] = ld32(0x06083B34u);  // 06083AC8 mov.l 0x06083B34,r1
    c.r[6] = 0x0u;  // 06083ACA mov #0,r6
    c.r[5] = 0x0u;  // 06083ACC mov #0,r5
    c.r[4] = 0x20u;  // 06083ACE mov #32,r4
L_06083AD0:
    { const uint32_t x = c.r[1]; c.pr = 0x06083AD4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083AD4u) return; }  // 06083AD0 jsr @r1 ; nop
    c.r[1] = ld32(0x06083B30u);  // 06083AD4 mov.l 0x06083B30,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06083AD6 mov.b @r1,r1
    c.r[3] = ld32(0x06083B60u);  // 06083AD8 mov.l 0x06083B60,r3
    c.r[6] = c.r[1] & 0xFFu;  // 06083ADA extu.b r1,r6
    c.r[1] = ld32(0x06083B38u);  // 06083ADC mov.l 0x06083B38,r1
    c.r[0] = c.r[6];  // 06083ADE mov r6,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06083AE0 mov.b @(r0,r1),r1
    c.r[7] = 0x7u;  // 06083AE2 mov #7,r7
    c.r[1] = c.r[1] & 0xFFu;  // 06083AE4 extu.b r1,r1
    st32(c.r[14], c.r[1]);  // 06083AE6 mov.l r1,@r14
    c.r[0] = c.r[1];  // 06083AE8 mov r1,r0
    c.r[0] -= 1;  // 06083AEA add #-1,r0
    c.macl = c.r[0] * c.r[7];  // 06083AEC mul.l r7,r0
    st32(c.r[14], c.r[0]);  // 06083AEE mov.l r0,@r14
    c.r[1] = ld32(0x06083B64u);  // 06083AF0 mov.l 0x06083B64,r1
    c.r[0] = c.r[6];  // 06083AF2 mov r6,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06083AF4 mov.b @(r0,r1),r1
    c.r[2] = c.macl;  // 06083AF6 sts macl,r2
    c.r[2] += c.r[1];  // 06083AF8 add r1,r2
    st8(c.r[3], c.r[2]);  // 06083AFA mov.b r2,@r3
    c.r[1] = ld32(0x06083B3Cu);  // 06083AFC mov.l 0x06083B3C,r1
    c.r[1] = ld32(c.r[1]);  // 06083AFE mov.l @r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06083B16u);  // 06083B00 mov.w 0x06083B16,r2
    c.r[0] = c.r[1];  // 06083B02 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06083B04 mov.b @(r0,r2),r1
    c.r[4] = c.r[1] & 0xFFu;  // 06083B06 extu.b r1,r4
    c.r[1] = c.macl;  // 06083B08 sts macl,r1
    c.r[4] -= c.r[1];  // 06083B0A sub r1,r4
    c.t = (int32_t)c.r[4] > (int32_t)c.r[7];  // 06083B0C cmp/gt r7,r4
    { const bool k = c.t; c.r[11] = c.r[7]; if (k) { goto L_06083B68; } }  // 06083B0E bt/s 0x06083B68 ; mov r7,r11
    c.r[11] = c.r[4]; goto L_06083B68;  // 06083B12 bra 0x06083B68 ; mov r4,r11
L_06083B68:
    c.r[1] = ld32(0x06083C84u);  // 06083B68 mov.l 0x06083C84,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06083B6Eu; c.r[4] = c.r[11] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083B6Eu) return; }  // 06083B6A jsr @r1 ; extu.b r11,r4
    c.r[0] = ld32(c.r[14]);  // 06083B6E mov.l @r14,r0
    c.r[1] = 0x7u;  // 06083B70 mov #7,r1
    c.macl = c.r[0] * c.r[1];  // 06083B72 mul.l r1,r0
    c.r[9] = c.macl;  // 06083B74 sts macl,r9
    c.r[1] = c.macl;  // 06083B76 sts macl,r1
    c.r[1] += c.r[11];  // 06083B78 add r11,r1
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[1];  // 06083B7A cmp/ge r1,r9
    if (c.t) { goto L_06083C0A; }  // 06083B7C bt 0x06083C0A
    c.r[13] = (uint32_t)(int16_t)ld16(0x06083C78u);  // 06083B7E mov.w 0x06083C78,r13
    c.r[12] = ld32(0x06083C88u);  // 06083B80 mov.l 0x06083C88,r12
L_06083B82:
    c.r[1] = ld32(0x06083C8Cu);  // 06083B82 mov.l 0x06083C8C,r1
    c.r[2] = c.r[9];  // 06083B84 mov r9,r2
    c.r[1] = ld32(c.r[1]);  // 06083B86 mov.l @r1,r1
    c.r[2] += c.r[2];  // 06083B88 add r2,r2
    c.r[0] = c.r[1];  // 06083B8A mov r1,r0
    c.r[1] += c.r[2];  // 06083B8C add r2,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06083B8E mov.b @(r0,r2),r3
    c.r[1] += 1;  // 06083B90 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06083B92 mov.b @r1,r1
    c.r[0] = 0x7Fu;  // 06083B94 mov #127,r0
    c.r[3] &= c.r[0];  // 06083B96 and r0,r3
    c.r[3] <<= 8;  // 06083B98 shll8 r3
    c.r[10] = c.r[1] & 0xFFu;  // 06083B9A extu.b r1,r10
    c.r[10] |= c.r[3];  // 06083B9C or r3,r10
    c.r[1] = ld32(0x06083C90u);  // 06083B9E mov.l 0x06083C90,r1
    c.r[3] = ld32(c.r[1]);  // 06083BA0 mov.l @r1,r3
    c.r[1] = 0x1Eu;  // 06083BA2 mov #30,r1
    c.macl = c.r[10] * c.r[1];  // 06083BA4 mul.l r1,r10
    c.r[2] = c.macl;  // 06083BA6 sts macl,r2
    c.r[2] += c.r[3];  // 06083BA8 add r3,r2
    c.r[1] = c.r[2];  // 06083BAA mov r2,r1
    c.r[1] += 15;  // 06083BAC add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06083BAE mov.b @r1,r1
    c.r[5] = c.r[13];  // 06083BB0 mov r13,r5
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06083BB2 mov.w @r2,r4
    c.r[8] = c.r[1] & 0xFFu;  // 06083BB4 extu.b r1,r8
    c.r[1] = (uint32_t)(int16_t)ld16(0x06083C7Au);  // 06083BB6 mov.w 0x06083C7A,r1
    c.r[4] += c.r[1];  // 06083BB8 add r1,r4
    { const uint32_t x = c.r[12]; c.pr = 0x06083BBEu; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083BBEu) return; }  // 06083BBA jsr @r12 ; extu.w r4,r4
    c.t = c.r[8] == c.r[13];  // 06083BBE cmp/eq r13,r8
    { const bool k = c.t; c.r[5] = c.r[8]; if (k) { goto L_06083BDC; } }  // 06083BC0 bt/s 0x06083BDC ; mov r8,r5
    c.r[1] = ld32(0x06083C94u);  // 06083BC4 mov.l 0x06083C94,r1
    c.r[0] = c.r[8];  // 06083BC6 mov r8,r0
    c.r[0] += c.r[0];  // 06083BC8 add r0,r0
    c.r[0] += c.r[8];  // 06083BCA add r8,r0
    c.r[1] = ld32(c.r[1]);  // 06083BCC mov.l @r1,r1
    c.r[0] <<= 2;  // 06083BCE shll2 r0
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06083BD0 mov.w @(r0,r1),r4
    c.r[5] = c.r[13];  // 06083BD2 mov r13,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x06083C7Cu);  // 06083BD4 mov.w 0x06083C7C,r1
    c.r[4] += c.r[1];  // 06083BD6 add r1,r4
    c.r[4] = c.r[4] & 0xFFFFu; goto L_06083BDE;  // 06083BD8 bra 0x06083BDE ; extu.w r4,r4
L_06083BDC:
    c.r[4] = ld32(0x06083C98u);  // 06083BDC mov.l 0x06083C98,r4
L_06083BDE:
    { const uint32_t x = c.r[12]; c.pr = 0x06083BE2u; c.r[9] += 1; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083BE2u) return; }  // 06083BDE jsr @r12 ; add #1,r9
    c.r[1] = ld32(0x06083C90u);  // 06083BE2 mov.l 0x06083C90,r1
    c.r[2] = ld32(c.r[1]);  // 06083BE4 mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 06083BE6 mov #30,r1
    c.macl = c.r[10] * c.r[1];  // 06083BE8 mul.l r1,r10
    c.r[5] = 0x0u;  // 06083BEA mov #0,r5
    c.r[1] = c.macl;  // 06083BEC sts macl,r1
    c.r[1] += c.r[2];  // 06083BEE add r2,r1
    c.r[1] += 22;  // 06083BF0 add #22,r1
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06083BF2 mov.w @r1,r6
    c.r[4] = 0x0u;  // 06083BF4 mov #0,r4
    c.r[1] = ld32(0x06083C9Cu);  // 06083BF6 mov.l 0x06083C9C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06083BFCu; c.r[6] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083BFCu) return; }  // 06083BF8 jsr @r1 ; extu.w r6,r6
    c.r[0] = ld32(c.r[14]);  // 06083BFC mov.l @r14,r0
    c.r[1] = 0x7u;  // 06083BFE mov #7,r1
    c.macl = c.r[0] * c.r[1];  // 06083C00 mul.l r1,r0
    c.r[1] = c.macl;  // 06083C02 sts macl,r1
    c.r[1] += c.r[11];  // 06083C04 add r11,r1
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[1];  // 06083C06 cmp/ge r1,r9
    if (!c.t) { SH2_POLL(c); goto L_06083B82; }  // 06083C08 bf 0x06083B82
L_06083C0A:
    c.r[1] = ld32(0x06083C8Cu);  // 06083C0A mov.l 0x06083C8C,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06083C7Eu);  // 06083C0C mov.w 0x06083C7E,r0
    c.r[2] = 0x1u;  // 06083C0E mov #1,r2
    c.r[8] = 0x0u;  // 06083C10 mov #0,r8
    c.r[7] = 0x2u;  // 06083C12 mov #2,r7
    c.r[6] = 0x24u;  // 06083C14 mov #36,r6
    c.r[1] = ld32(c.r[1]);  // 06083C16 mov.l @r1,r1
    c.r[5] = 0xDu;  // 06083C18 mov #13,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06083C1A mov.b @(r0,r1),r1
    c.r[4] = 0x2u;  // 06083C1C mov #2,r4
    c.r[1] = c.r[1] & 0xFFu;  // 06083C1E extu.b r1,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06083C20 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06083C22 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06083C24 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06083C26 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06083C28 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06083C2A mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06083C2C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06083C2E mov.l r8,@-r15
    c.r[1] = 0x7u;  // 06083C30 mov #7,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06083C32 mov.l r1,@-r15
    c.r[1] = ld32(0x06083CA0u);  // 06083C34 mov.l 0x06083CA0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06083C3Au; c.r[15] -= 4; st32(c.r[15], c.r[2]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083C3Au) return; }  // 06083C36 jsr @r1 ; mov.l r2,@-r15
    c.r[15] += 40;  // 06083C3A add #40,r15
    c.r[1] = ld32(0x06083CA4u);  // 06083C3C mov.l 0x06083CA4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06083C42u; c.r[4] = 0x4Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083C42u) return; }  // 06083C3E jsr @r1 ; mov #74,r4
    c.r[1] = ld32(0x06083CA8u);  // 06083C42 mov.l 0x06083CA8,r1
    c.r[0] = ld32(0x06083CACu);  // 06083C44 mov.l 0x06083CAC,r0
    c.r[6] = 0x5u;  // 06083C46 mov #5,r6
    c.r[1] = ld32(c.r[1]);  // 06083C48 mov.l @r1,r1
    c.r[5] = 0x2u;  // 06083C4A mov #2,r5
    c.r[1] += 42;  // 06083C4C add #42,r1
    c.r[7] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06083C4E mov.w @r1,r7
    c.r[4] = 0x0u;  // 06083C50 mov #0,r4
    c.r[7] <<= 16;  // 06083C52 shll16 r7
    c.r[7] += c.r[7];  // 06083C54 add r7,r7
    c.r[7] >>= 16;  // 06083C56 shlr16 r7
    c.r[7] += c.r[7];  // 06083C58 add r7,r7
    c.r[7] >>= 8;  // 06083C5A shlr8 r7
    { const uint32_t x = c.r[0]; c.pr = 0x06083C60u; c.r[15] -= 4; st32(c.r[15], c.r[8]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083C60u) return; }  // 06083C5C jsr @r0 ; mov.l r8,@-r15
    c.r[14] += 4;  // 06083C60 add #4,r14
    c.r[15] = c.r[14];  // 06083C62 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06083C64 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06083C66 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06083C68 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06083C6A mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06083C6C mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06083C6E mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06083C70 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06083C80u);  // 06083C72 mov.w 0x06083C80,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06083C74 rts ; mov.l @r15+,r8
}

void f_06083CB0(SH2Context& c) {
    ran[1842] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06083CB0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06083CB2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06083CB4 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06083CB6 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06083CB8 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06083CBA mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06083CBC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06083CBE sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06083CC0 mov r15,r14
    c.r[1] = ld32(0x06083E1Cu);  // 06083CC2 mov.l 0x06083E1C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06083CC8u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083CC8u) return; }  // 06083CC4 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06083E20u);  // 06083CC8 mov.l 0x06083E20,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06083CCEu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083CCEu) return; }  // 06083CCA jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06083E24u);  // 06083CCE mov.l 0x06083E24,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06083CD4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083CD4u) return; }  // 06083CD0 jsr @r1 ; nop
    c.r[1] = ld32(0x06083E28u);  // 06083CD4 mov.l 0x06083E28,r1
    c.r[9] = ld32(0x06083E2Cu);  // 06083CD6 mov.l 0x06083E2C,r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06083CD8 mov.b @r1,r1
    c.r[5] = 0x0u;  // 06083CDA mov #0,r5
    c.r[0] = c.r[1] & 0xFFu;  // 06083CDC extu.b r1,r0
    c.r[1] = ld32(0x06083E30u);  // 06083CDE mov.l 0x06083E30,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06083CE0 mov.b @(r0,r1),r6
    c.r[4] = 0x0u;  // 06083CE2 mov #0,r4
    { const uint32_t x = c.r[9]; c.pr = 0x06083CE8u; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083CE8u) return; }  // 06083CE4 jsr @r9 ; extu.b r6,r6
    c.r[1] = ld32(0x06083E34u);  // 06083CE8 mov.l 0x06083E34,r1
    c.r[1] = ld32(c.r[1]);  // 06083CEA mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06083E12u);  // 06083CEC mov.w 0x06083E12,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06083CEE mov.b @(r0,r1),r2
    c.r[2] = c.r[2] & 0xFFu;  // 06083CF0 extu.b r2,r2
    c.r[2] += 6;  // 06083CF2 add #6,r2
    c.r[1] = ld32(0x06083E38u);  // 06083CF4 mov.l 0x06083E38,r1
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[2] * (int32_t)c.r[1]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 06083CF6 dmuls.l r1,r2
    c.r[5] = 0x0u;  // 06083CF8 mov #0,r5
    c.r[4] = 0x0u;  // 06083CFA mov #0,r4
    c.r[6] = c.mach;  // 06083CFC sts mach,r6
    c.r[6] += c.r[2];  // 06083CFE add r2,r6
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 06083D00 shar r6
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 06083D02 shar r6
    c.t = c.r[2] >> 31; c.r[2] <<= 1;  // 06083D04 shll r2
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 06083D06 subc r2,r2
    { const uint32_t x = c.r[9]; c.pr = 0x06083D0Cu; c.r[6] -= c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083D0Cu) return; }  // 06083D08 jsr @r9 ; sub r2,r6
    c.r[8] = ld32(0x06083E3Cu);  // 06083D0C mov.l 0x06083E3C,r8
    c.r[1] = ld32(c.r[8]);  // 06083D0E mov.l @r8,r1
    c.r[10] = (uint32_t)(int16_t)ld16(0x06083E14u);  // 06083D10 mov.w 0x06083E14,r10
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06083D12 mov.w @r1,r4
    c.r[5] = c.r[10];  // 06083D14 mov r10,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x06083E16u);  // 06083D16 mov.w 0x06083E16,r1
    c.r[4] += c.r[1];  // 06083D18 add r1,r4
    c.r[1] = ld32(0x06083E40u);  // 06083D1A mov.l 0x06083E40,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06083D20u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083D20u) return; }  // 06083D1C jsr @r1 ; extu.w r4,r4
    c.r[1] = ld32(c.r[8]);  // 06083D20 mov.l @r8,r1
    c.r[5] = 0x0u;  // 06083D22 mov #0,r5
    c.r[1] += 2;  // 06083D24 add #2,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06083D26 mov.b @r1,r6
    c.r[4] = 0x0u;  // 06083D28 mov #0,r4
    { const uint32_t x = c.r[9]; c.pr = 0x06083D2Eu; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083D2Eu) return; }  // 06083D2A jsr @r9 ; extu.b r6,r6
    c.r[4] = ld32(0x06083E44u);  // 06083D2E mov.l 0x06083E44,r4
    c.r[8] = ld32(0x06083E48u);  // 06083D30 mov.l 0x06083E48,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06083D36u; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083D36u) return; }  // 06083D32 jsr @r8 ; mov #23,r5
    c.r[5] = 0x23u;  // 06083D36 mov #35,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06083D3Cu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083D3Cu) return; }  // 06083D38 jsr @r8 ; mov r0,r4
    c.r[5] = 0x32u;  // 06083D3C mov #50,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06083D42u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083D42u) return; }  // 06083D3E jsr @r8 ; mov r0,r4
    c.r[1] = ld32(0x06083E4Cu);  // 06083D42 mov.l 0x06083E4C,r1
    c.r[6] = 0x0u;  // 06083D44 mov #0,r6
    c.r[5] = c.r[0];  // 06083D46 mov r0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06083D4Cu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083D4Cu) return; }  // 06083D48 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06083E50u);  // 06083D4C mov.l 0x06083E50,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06083D4E mov.b @r1,r1
    c.r[6] = 0x7Fu;  // 06083D50 mov #127,r6
    c.r[3] = c.r[1] & 0xFFu;  // 06083D52 extu.b r1,r3
    c.r[1] = ld32(0x06083E54u);  // 06083D54 mov.l 0x06083E54,r1
    c.r[7] = ld32(c.r[1]);  // 06083D56 mov.l @r1,r7
    c.r[5] = 0x0u;  // 06083D58 mov #0,r5
L_06083D5A:
    c.r[2] = 0x0u;  // 06083D5A mov #0,r2
    c.r[1] = c.r[2];  // 06083D5C mov r2,r1
L_06083D5E:
    c.r[1] += c.r[1];  // 06083D5E add r1,r1
    c.r[1] += c.r[2];  // 06083D60 add r2,r1
    c.r[1] <<= 2;  // 06083D62 shll2 r1
    c.r[1] += c.r[7];  // 06083D64 add r7,r1
    c.r[1] += 8;  // 06083D66 add #8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06083D68 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06083D6A extu.b r1,r1
    c.t = c.r[1] == c.r[3];  // 06083D6C cmp/eq r3,r1
    { const bool k = !c.t; c.t = (c.r[3] & c.r[3]) == 0; if (k) { goto L_06083D7E; } }  // 06083D6E bf/s 0x06083D7E ; tst r3,r3
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_06083D80; } }  // 06083D72 bt/s 0x06083D80 ; mov r2,r1
    c.r[10] = c.r[2];  // 06083D76 mov r2,r10
    c.r[5] = 0x1u;  // 06083D78 mov #1,r5
    c.r[3] = c.r[10]; goto L_06083D8A;  // 06083D7A bra 0x06083D8A ; mov r10,r3
L_06083D7E:
    c.r[1] = c.r[2];  // 06083D7E mov r2,r1
L_06083D80:
    c.r[1] += 1;  // 06083D80 add #1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 06083D82 extu.b r1,r2
    c.t = c.r[2] > c.r[6];  // 06083D84 cmp/hi r6,r2
    { const bool k = !c.t; c.r[1] = c.r[2]; if (k) { SH2_POLL(c); goto L_06083D5E; } }  // 06083D86 bf/s 0x06083D5E ; mov r2,r1
L_06083D8A:
    c.r[0] = c.r[5];  // 06083D8A mov r5,r0
    c.t = c.r[0] == 0x1u;  // 06083D8C cmp/eq #1,r0
    { const bool k = c.t; c.r[5] = 0x0u; if (k) { SH2_POLL(c); goto L_06083D5A; } }  // 06083D8E bt/s 0x06083D5A ; mov #0,r5
    c.r[5] = c.r[10] & 0xFFu;  // 06083D92 extu.b r10,r5
    c.r[2] = (uint32_t)(int16_t)ld16(0x06083E14u);  // 06083D94 mov.w 0x06083E14,r2
    c.t = c.r[5] == c.r[2];  // 06083D96 cmp/eq r2,r5
    { const bool k = c.t; c.r[9] = c.r[5]; if (k) { goto L_06083DC8; } }  // 06083D98 bt/s 0x06083DC8 ; mov r5,r9
    c.r[8] = ld32(0x06083E54u);  // 06083D9C mov.l 0x06083E54,r8
    c.r[9] += c.r[9];  // 06083D9E add r9,r9
    c.r[9] += c.r[5];  // 06083DA0 add r5,r9
    c.r[9] <<= 2;  // 06083DA2 shll2 r9
    c.r[1] = ld32(c.r[8]);  // 06083DA4 mov.l @r8,r1
    c.r[0] = c.r[9];  // 06083DA6 mov r9,r0
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06083DA8 mov.w @(r0,r1),r4
    c.r[5] = c.r[2];  // 06083DAA mov r2,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x06083E18u);  // 06083DAC mov.w 0x06083E18,r1
    c.r[4] += c.r[1];  // 06083DAE add r1,r4
    c.r[1] = ld32(0x06083E40u);  // 06083DB0 mov.l 0x06083E40,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06083DB6u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083DB6u) return; }  // 06083DB2 jsr @r1 ; extu.w r4,r4
    c.r[5] = 0x0u;  // 06083DB6 mov #0,r5
    c.r[1] = ld32(c.r[8]);  // 06083DB8 mov.l @r8,r1
    c.r[4] = 0x0u;  // 06083DBA mov #0,r4
    c.r[9] += c.r[1];  // 06083DBC add r1,r9
    c.r[9] += 2;  // 06083DBE add #2,r9
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06083DC0 mov.b @r9,r6
    c.r[1] = ld32(0x06083E2Cu);  // 06083DC2 mov.l 0x06083E2C,r1
    c.r[6] = c.r[6] & 0xFFu; goto L_06083DD8;  // 06083DC4 bra 0x06083DD8 ; extu.b r6,r6
L_06083DC8:
    c.r[4] = ld32(0x06083E58u);  // 06083DC8 mov.l 0x06083E58,r4
    c.r[1] = ld32(0x06083E40u);  // 06083DCA mov.l 0x06083E40,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06083DD0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083DD0u) return; }  // 06083DCC jsr @r1 ; nop
    c.r[1] = ld32(0x06083E2Cu);  // 06083DD0 mov.l 0x06083E2C,r1
    c.r[6] = 0x0u;  // 06083DD2 mov #0,r6
    c.r[5] = 0x0u;  // 06083DD4 mov #0,r5
    c.r[4] = 0x20u;  // 06083DD6 mov #32,r4
L_06083DD8:
    { const uint32_t x = c.r[1]; c.pr = 0x06083DDCu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083DDCu) return; }  // 06083DD8 jsr @r1 ; nop
    c.r[1] = ld32(0x06083E28u);  // 06083DDC mov.l 0x06083E28,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06083DDE mov.b @r1,r1
    c.r[3] = ld32(0x06083E5Cu);  // 06083DE0 mov.l 0x06083E5C,r3
    c.r[0] = c.r[1] & 0xFFu;  // 06083DE2 extu.b r1,r0
    c.r[1] = ld32(0x06083E30u);  // 06083DE4 mov.l 0x06083E30,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06083DE6 mov.b @(r0,r1),r1
    c.r[7] = 0x7u;  // 06083DE8 mov #7,r7
    c.r[13] = c.r[1] & 0xFFu;  // 06083DEA extu.b r1,r13
    c.r[13] -= 1;  // 06083DEC add #-1,r13
    c.macl = c.r[13] * c.r[7];  // 06083DEE mul.l r7,r13
    c.r[1] = ld32(0x06083E60u);  // 06083DF0 mov.l 0x06083E60,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06083DF2 mov.b @(r0,r1),r1
    c.r[2] = c.macl;  // 06083DF4 sts macl,r2
    c.r[2] += c.r[1];  // 06083DF6 add r1,r2
    st8(c.r[3], c.r[2]);  // 06083DF8 mov.b r2,@r3
    c.r[1] = ld32(0x06083E34u);  // 06083DFA mov.l 0x06083E34,r1
    c.r[1] = ld32(c.r[1]);  // 06083DFC mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06083E12u);  // 06083DFE mov.w 0x06083E12,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06083E00 mov.b @(r0,r1),r1
    c.r[4] = c.r[1] & 0xFFu;  // 06083E02 extu.b r1,r4
    c.r[1] = c.macl;  // 06083E04 sts macl,r1
    c.r[4] -= c.r[1];  // 06083E06 sub r1,r4
    c.t = (int32_t)c.r[4] > (int32_t)c.r[7];  // 06083E08 cmp/gt r7,r4
    { const bool k = c.t; c.r[12] = c.r[7]; if (k) { goto L_06083E64; } }  // 06083E0A bt/s 0x06083E64 ; mov r7,r12
    c.r[12] = c.r[4]; goto L_06083E64;  // 06083E0E bra 0x06083E64 ; mov r4,r12
L_06083E64:
    c.r[1] = ld32(0x06083FB8u);  // 06083E64 mov.l 0x06083FB8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06083E6Au; c.r[4] = c.r[12] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083E6Au) return; }  // 06083E66 jsr @r1 ; extu.b r12,r4
    c.r[1] = 0x7u;  // 06083E6A mov #7,r1
    c.macl = c.r[13] * c.r[1];  // 06083E6C mul.l r1,r13
    c.r[9] = c.macl;  // 06083E6E sts macl,r9
    c.r[1] = c.macl;  // 06083E70 sts macl,r1
    c.r[1] += c.r[12];  // 06083E72 add r12,r1
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[1];  // 06083E74 cmp/ge r1,r9
    if (c.t) { goto L_06083F40; }  // 06083E76 bt 0x06083F40
    c.r[11] = (uint32_t)(int16_t)ld16(0x06083FACu);  // 06083E78 mov.w 0x06083FAC,r11
L_06083E7A:
    c.r[1] = ld32(0x06083FBCu);  // 06083E7A mov.l 0x06083FBC,r1
    c.r[2] = c.r[9];  // 06083E7C mov r9,r2
    c.r[1] = ld32(c.r[1]);  // 06083E7E mov.l @r1,r1
    c.r[2] += c.r[2];  // 06083E80 add r2,r2
    c.r[0] = c.r[1];  // 06083E82 mov r1,r0
    c.r[1] += c.r[2];  // 06083E84 add r2,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06083E86 mov.b @(r0,r2),r3
    c.r[1] += 1;  // 06083E88 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06083E8A mov.b @r1,r1
    c.r[0] = 0x7Fu;  // 06083E8C mov #127,r0
    c.r[3] &= c.r[0];  // 06083E8E and r0,r3
    c.r[3] <<= 8;  // 06083E90 shll8 r3
    c.r[8] = c.r[1] & 0xFFu;  // 06083E92 extu.b r1,r8
    c.r[8] |= c.r[3];  // 06083E94 or r3,r8
    c.r[1] = ld32(0x06083FC0u);  // 06083E96 mov.l 0x06083FC0,r1
    c.r[2] = c.r[8];  // 06083E98 mov r8,r2
    c.r[2] += c.r[2];  // 06083E9A add r2,r2
    c.r[2] += c.r[8];  // 06083E9C add r8,r2
    c.r[2] <<= 2;  // 06083E9E shll2 r2
    c.r[1] = ld32(c.r[1]);  // 06083EA0 mov.l @r1,r1
    c.r[0] = c.r[2];  // 06083EA2 mov r2,r0
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06083EA4 mov.w @(r0,r1),r4
    c.r[5] = c.r[11];  // 06083EA6 mov r11,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x06083FAEu);  // 06083EA8 mov.w 0x06083FAE,r1
    c.r[4] += c.r[1];  // 06083EAA add r1,r4
    c.r[0] = ld32(0x06083FC4u);  // 06083EAC mov.l 0x06083FC4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06083EB2u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083EB2u) return; }  // 06083EAE jsr @r0 ; extu.w r4,r4
    c.r[6] = c.r[8] & 0xFFu;  // 06083EB2 extu.b r8,r6
    c.r[5] = c.r[11];  // 06083EB4 mov r11,r5
    c.r[3] = 0x0u;  // 06083EB6 mov #0,r3
    c.r[0] = ld32(0x06083FC8u);  // 06083EB8 mov.l 0x06083FC8,r0
    c.r[10] = 0x1Eu;  // 06083EBA mov #30,r10
    c.r[4] = 0x7Fu;  // 06083EBC mov #127,r4
    c.r[7] = ld32(c.r[0]);  // 06083EBE mov.l @r0,r7
    c.macl = c.r[3] * c.r[10];  // 06083EC0 mul.l r10,r3
L_06083EC2:
    c.r[2] = c.macl;  // 06083EC2 sts macl,r2
    c.r[2] += c.r[7];  // 06083EC4 add r7,r2
    c.r[1] = c.r[2];  // 06083EC6 mov r2,r1
    c.r[1] += 15;  // 06083EC8 add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06083ECA mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06083ECC extu.b r1,r1
    c.t = c.r[1] == c.r[6];  // 06083ECE cmp/eq r6,r1
    { const bool k = !c.t; c.r[1] = c.r[3]; if (k) { goto L_06083EE4; } }  // 06083ED0 bf/s 0x06083EE4 ; mov r3,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06083ED4 mov.w @r2,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06083ED6 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06083ED8 tst r1,r1
    { const bool k = c.t; c.r[0] = c.r[1]; if (k) { goto L_06083EE2; } }  // 06083EDA bt/s 0x06083EE2 ; mov r1,r0
    c.t = c.r[0] == 0x2u;  // 06083EDE cmp/eq #2,r0
    if (!c.t) { goto L_06083F0C; }  // 06083EE0 bf 0x06083F0C
L_06083EE2:
    c.r[1] = c.r[3];  // 06083EE2 mov r3,r1
L_06083EE4:
    c.r[1] += 1;  // 06083EE4 add #1,r1
    c.r[3] = c.r[1] & 0xFFu;  // 06083EE6 extu.b r1,r3
    c.t = c.r[3] > c.r[4];  // 06083EE8 cmp/hi r4,r3
    { const bool k = !c.t; c.macl = c.r[3] * c.r[10]; if (k) { SH2_POLL(c); goto L_06083EC2; } }  // 06083EEA bf/s 0x06083EC2 ; mul.l r10,r3
L_06083EEE:
    c.r[5] = c.r[5] & 0xFFu;  // 06083EEE extu.b r5,r5
    c.t = c.r[5] == c.r[11];  // 06083EF0 cmp/eq r11,r5
    { const bool k = c.t; c.r[1] = 0x1Eu; if (k) { goto L_06083F10; } }  // 06083EF2 bt/s 0x06083F10 ; mov #30,r1
    c.r[0] = ld32(0x06083FC8u);  // 06083EF6 mov.l 0x06083FC8,r0
    c.macl = c.r[5] * c.r[1];  // 06083EF8 mul.l r1,r5
    c.r[2] = ld32(c.r[0]);  // 06083EFA mov.l @r0,r2
    c.r[1] = c.macl;  // 06083EFC sts macl,r1
    c.r[0] = c.r[1];  // 06083EFE mov r1,r0
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 06083F00 mov.w @(r0,r2),r4
    c.r[5] = c.r[11];  // 06083F02 mov r11,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x06083FB0u);  // 06083F04 mov.w 0x06083FB0,r1
    c.r[4] += c.r[1];  // 06083F06 add r1,r4
    c.r[4] = c.r[4] & 0xFFFFu; goto L_06083F12;  // 06083F08 bra 0x06083F12 ; extu.w r4,r4
L_06083F0C:
    c.r[5] = c.r[3]; SH2_POLL(c); goto L_06083EEE;  // 06083F0C bra 0x06083EEE ; mov r3,r5
L_06083F10:
    c.r[4] = ld32(0x06083FCCu);  // 06083F10 mov.l 0x06083FCC,r4
L_06083F12:
    c.r[0] = ld32(0x06083FC4u);  // 06083F12 mov.l 0x06083FC4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06083F18u; c.r[9] += 1; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083F18u) return; }  // 06083F14 jsr @r0 ; add #1,r9
    c.r[1] = ld32(0x06083FC0u);  // 06083F18 mov.l 0x06083FC0,r1
    c.r[2] = c.r[8];  // 06083F1A mov r8,r2
    c.r[2] += c.r[2];  // 06083F1C add r2,r2
    c.r[2] += c.r[8];  // 06083F1E add r8,r2
    c.r[2] <<= 2;  // 06083F20 shll2 r2
    c.r[5] = 0x0u;  // 06083F22 mov #0,r5
    c.r[1] = ld32(c.r[1]);  // 06083F24 mov.l @r1,r1
    c.r[4] = 0x0u;  // 06083F26 mov #0,r4
    c.r[2] += c.r[1];  // 06083F28 add r1,r2
    c.r[2] += 2;  // 06083F2A add #2,r2
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06083F2C mov.b @r2,r6
    c.r[1] = ld32(0x06083FD0u);  // 06083F2E mov.l 0x06083FD0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06083F34u; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083F34u) return; }  // 06083F30 jsr @r1 ; extu.b r6,r6
    c.r[1] = 0x7u;  // 06083F34 mov #7,r1
    c.macl = c.r[13] * c.r[1];  // 06083F36 mul.l r1,r13
    c.r[1] = c.macl;  // 06083F38 sts macl,r1
    c.r[1] += c.r[12];  // 06083F3A add r12,r1
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[1];  // 06083F3C cmp/ge r1,r9
    if (!c.t) { SH2_POLL(c); goto L_06083E7A; }  // 06083F3E bf 0x06083E7A
L_06083F40:
    c.r[1] = ld32(0x06083FBCu);  // 06083F40 mov.l 0x06083FBC,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06083FB2u);  // 06083F42 mov.w 0x06083FB2,r0
    c.r[2] = 0x1u;  // 06083F44 mov #1,r2
    c.r[8] = 0x0u;  // 06083F46 mov #0,r8
    c.r[7] = 0x2u;  // 06083F48 mov #2,r7
    c.r[6] = 0x24u;  // 06083F4A mov #36,r6
    c.r[1] = ld32(c.r[1]);  // 06083F4C mov.l @r1,r1
    c.r[5] = 0xDu;  // 06083F4E mov #13,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06083F50 mov.b @(r0,r1),r1
    c.r[4] = 0x2u;  // 06083F52 mov #2,r4
    c.r[1] = c.r[1] & 0xFFu;  // 06083F54 extu.b r1,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06083F56 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06083F58 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06083F5A mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06083F5C mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06083F5E mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06083F60 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06083F62 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06083F64 mov.l r8,@-r15
    c.r[1] = 0x7u;  // 06083F66 mov #7,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06083F68 mov.l r1,@-r15
    c.r[1] = ld32(0x06083FD4u);  // 06083F6A mov.l 0x06083FD4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06083F70u; c.r[15] -= 4; st32(c.r[15], c.r[2]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083F70u) return; }  // 06083F6C jsr @r1 ; mov.l r2,@-r15
    c.r[15] += 40;  // 06083F70 add #40,r15
    c.r[1] = ld32(0x06083FD8u);  // 06083F72 mov.l 0x06083FD8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06083F78u; c.r[4] = 0x4Bu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083F78u) return; }  // 06083F74 jsr @r1 ; mov #75,r4
    c.r[1] = ld32(0x06083FDCu);  // 06083F78 mov.l 0x06083FDC,r1
    c.r[0] = ld32(0x06083FE0u);  // 06083F7A mov.l 0x06083FE0,r0
    c.r[6] = 0x5u;  // 06083F7C mov #5,r6
    c.r[1] = ld32(c.r[1]);  // 06083F7E mov.l @r1,r1
    c.r[5] = 0x2u;  // 06083F80 mov #2,r5
    c.r[1] += 42;  // 06083F82 add #42,r1
    c.r[7] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06083F84 mov.w @r1,r7
    c.r[4] = 0x0u;  // 06083F86 mov #0,r4
    c.r[7] <<= 16;  // 06083F88 shll16 r7
    c.r[7] += c.r[7];  // 06083F8A add r7,r7
    c.r[7] >>= 16;  // 06083F8C shlr16 r7
    c.r[7] += c.r[7];  // 06083F8E add r7,r7
    c.r[7] >>= 8;  // 06083F90 shlr8 r7
    { const uint32_t x = c.r[0]; c.pr = 0x06083F96u; c.r[15] -= 4; st32(c.r[15], c.r[8]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06083F96u) return; }  // 06083F92 jsr @r0 ; mov.l r8,@-r15
    c.r[15] = c.r[14];  // 06083F96 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06083F98 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06083F9A mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06083F9C mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06083F9E mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06083FA0 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06083FA2 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06083FA4 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06083FB4u);  // 06083FA6 mov.w 0x06083FB4,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06083FA8 rts ; mov.l @r15+,r8
}

void f_06083FE4(SH2Context& c) {
    ran[1843] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06083FE4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06083FE6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06083FE8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06083FEA mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06083FEC mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06083FEE mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06083FF0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06083FF2 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06083FF4 mov r15,r14
    c.r[12] = 0x6u;  // 06083FF6 mov #6,r12
    c.r[11] = 0xBu;  // 06083FF8 mov #11,r11
    c.r[13] = 0xDu;  // 06083FFA mov #13,r13
    c.r[1] = ld32(0x06084094u);  // 06083FFC mov.l 0x06084094,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06084002u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084002u) return; }  // 06083FFE jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x06084098u);  // 06084002 mov.l 0x06084098,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06084008u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084008u) return; }  // 06084004 jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x0608409Cu);  // 06084008 mov.l 0x0608409C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0608400Eu; c.r[10] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608400Eu) return; }  // 0608400A jsr @r1 ; mov #2,r10
    c.r[9] = (uint32_t)(int16_t)ld16(0x0608408Eu);  // 0608400E mov.w 0x0608408E,r9
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06084010 mov.l r10,@-r15
    c.r[8] = ld32(0x060840A0u);  // 06084012 mov.l 0x060840A0,r8
    c.r[7] = 0x1Au;  // 06084014 mov #26,r7
    c.r[6] = c.r[11];  // 06084016 mov r11,r6
    c.r[5] = c.r[12];  // 06084018 mov r12,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0608401Eu; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608401Eu) return; }  // 0608401A jsr @r8 ; mov r9,r4
    c.r[1] = 0x4u;  // 0608401E mov #4,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06084020 mov.l r1,@-r15
    c.r[7] = 0x5u;  // 06084022 mov #5,r7
    c.r[6] = c.r[13];  // 06084024 mov r13,r6
    c.r[5] = 0x1Cu;  // 06084026 mov #28,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0608402Cu; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608402Cu) return; }  // 06084028 jsr @r8 ; mov r9,r4
    c.r[9] = (uint32_t)(int16_t)ld16(0x06084090u);  // 0608402C mov.w 0x06084090,r9
    c.r[8] = ld32(0x060840A4u);  // 0608402E mov.l 0x060840A4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06084034u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084034u) return; }  // 06084030 jsr @r8 ; mov r9,r4
    { const uint32_t x = c.r[8]; c.pr = 0x06084038u; c.r[4] = 0x7u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084038u) return; }  // 06084034 jsr @r8 ; mov #7,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0608403Cu; c.r[4] = 0xCu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608403Cu) return; }  // 06084038 jsr @r8 ; mov #12,r4
    { const uint32_t x = c.r[8]; c.pr = 0x06084040u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084040u) return; }  // 0608403C jsr @r8 ; mov r9,r4
    c.r[11] = 0x1Du;  // 06084040 mov #29,r11
    { const uint32_t x = c.r[8]; c.pr = 0x06084046u; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084046u) return; }  // 06084042 jsr @r8 ; mov r11,r4
    c.r[9] = 0xEu;  // 06084046 mov #14,r9
    { const uint32_t x = c.r[8]; c.pr = 0x0608404Cu; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608404Cu) return; }  // 06084048 jsr @r8 ; mov r9,r4
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0608404C mov.l r10,@-r15
    c.r[2] = 0x1u;  // 0608404E mov #1,r2
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06084050 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06084052 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06084054 mov.l r2,@-r15
    c.r[1] = 0x0u;  // 06084056 mov #0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06084058 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 0608405A mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0608405C mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0608405E mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06084060 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06084062 mov.l r2,@-r15
    c.r[1] = ld32(0x060840A8u);  // 06084064 mov.l 0x060840A8,r1
    c.r[7] = c.r[10];  // 06084066 mov r10,r7
    c.r[6] = 0x5u;  // 06084068 mov #5,r6
    c.r[5] = c.r[9];  // 0608406A mov r9,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06084070u; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084070u) return; }  // 0608406C jsr @r1 ; mov r11,r4
    c.r[15] += 48;  // 06084070 add #48,r15
    c.r[1] = ld32(0x060840ACu);  // 06084072 mov.l 0x060840AC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06084078u; c.r[4] = 0x4Du; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084078u) return; }  // 06084074 jsr @r1 ; mov #77,r4
    c.r[15] = c.r[14];  // 06084078 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608407A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608407C mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0608407E mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06084080 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06084082 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06084084 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06084086 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06084092u);  // 06084088 mov.w 0x06084092,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0608408A rts ; mov.l @r15+,r8
}

void f_060840B0(SH2Context& c) {
    ran[1844] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060840B0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060840B2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060840B4 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060840B6 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060840B8 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060840BA mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060840BC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060840BE sts.l pr,@-r15
    c.r[3] = 0xFFFFFF98u;  // 060840C0 mov #-104,r3
    c.r[3] <<= 2;  // 060840C2 shll2 r3
    c.r[15] += c.r[3];  // 060840C4 add r3,r15
    c.r[14] = c.r[15];  // 060840C6 mov r15,r14
    c.r[1] = ld32(0x06084378u);  // 060840C8 mov.l 0x06084378,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060840CEu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060840CEu) return; }  // 060840CA jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x0608437Cu);  // 060840CE mov.l 0x0608437C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060840D4u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060840D4u) return; }  // 060840D0 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06084380u);  // 060840D4 mov.l 0x06084380,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060840DAu; c.r[9] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060840DAu) return; }  // 060840D6 jsr @r1 ; mov #2,r9
    c.r[10] = ld32(0x06084384u);  // 060840DA mov.l 0x06084384,r10
    c.r[4] = 0xFFFFFFFFu;  // 060840DC mov #-1,r4
    c.r[4] = c.r[4] & 0xFFu;  // 060840DE extu.b r4,r4
    c.r[1] = ld32(0x06084388u);  // 060840E0 mov.l 0x06084388,r1
    c.r[6] = 0x5u;  // 060840E2 mov #5,r6
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[10]);  // 060840E4 mov.b @r10,r7
    c.r[5] = 0x1u;  // 060840E6 mov #1,r5
    c.r[7] += 19;  // 060840E8 add #19,r7
    c.r[7] = c.r[7] & 0xFFu;  // 060840EA extu.b r7,r7
    { const uint32_t x = c.r[1]; c.pr = 0x060840F0u; c.r[15] -= 4; st32(c.r[15], c.r[9]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060840F0u) return; }  // 060840EC jsr @r1 ; mov.l r9,@-r15
    c.r[8] = ld32(0x0608438Cu);  // 060840F0 mov.l 0x0608438C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060840F6u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060840F6u) return; }  // 060840F2 jsr @r8 ; mov r9,r4
    { const uint32_t x = c.r[8]; c.pr = 0x060840FAu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060840FAu) return; }  // 060840F6 jsr @r8 ; mov #1,r4
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[10] + 1);  // 060840FA mov.b @(1,r10),r0
    c.r[5] = c.r[0];  // 060840FC mov r0,r5
    c.r[0] = ld32(0x06084390u);  // 060840FE mov.l 0x06084390,r0
    c.r[1] = ld32(0x06084394u);  // 06084100 mov.l 0x06084394,r1
    c.r[4] = ld32(c.r[1]);  // 06084102 mov.l @r1,r4
    { const uint32_t x = c.r[0]; c.pr = 0x06084108u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084108u) return; }  // 06084104 jsr @r0 ; extu.b r5,r5
    c.r[11] = c.r[0] & 0xFFu;  // 06084108 extu.b r0,r11
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0608410A mov.b @r10,r4
    c.r[9] = ld32(0x06084398u);  // 0608410C mov.l 0x06084398,r9
    { const uint32_t x = c.r[9]; c.pr = 0x06084112u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084112u) return; }  // 0608410E jsr @r9 ; extu.b r4,r4
    c.r[15] += 4;  // 06084112 add #4,r15
    c.r[1] = ld32(0x0608439Cu);  // 06084114 mov.l 0x0608439C,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1] + 14);  // 06084116 mov.b @(14,r1),r0
    c.r[12] = c.r[0] & 0xFFu;  // 06084118 extu.b r0,r12
    c.r[12] += c.r[11];  // 0608411A add r11,r12
    c.r[8] = 0x0u;  // 0608411C mov #0,r8
L_0608411E:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0608411E mov.b @r10,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06084120 extu.b r1,r1
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 06084122 cmp/ge r1,r8
    if (c.t) { goto L_06084148; }  // 06084124 bt 0x06084148
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[11];  // 06084126 cmp/ge r11,r8
    { const bool k = !c.t; c.r[13] = 0x33u; if (k) { goto L_0608413A; } }  // 06084128 bf/s 0x0608413A ; mov #51,r13
    c.t = c.r[8] >= c.r[12];  // 0608412C cmp/hs r12,r8
    { const bool k = c.t; c.r[13] = 0x31u; if (k) { goto L_0608413A; } }  // 0608412E bt/s 0x0608413A ; mov #49,r13
    c.r[0] = ld32(0x060843A0u);  // 06084132 mov.l 0x060843A0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06084138u; c.r[13] = 0xFFFFFFE0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084138u) return; }  // 06084134 jsr @r0 ; mov #-32,r13
    c.r[13] = c.r[13] & 0xFFu;  // 06084138 extu.b r13,r13
L_0608413A:
    { const uint32_t x = c.r[9]; c.pr = 0x0608413Eu; c.r[4] = c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608413Eu) return; }  // 0608413A jsr @r9 ; mov r13,r4
    c.r[13] += 1;  // 0608413E add #1,r13
    { const uint32_t x = c.r[9]; c.pr = 0x06084144u; c.r[4] = c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084144u) return; }  // 06084140 jsr @r9 ; mov r13,r4
    c.r[8] += 1; SH2_POLL(c); goto L_0608411E;  // 06084144 bra 0x0608411E ; add #1,r8
L_06084148:
    c.r[13] = c.r[10];  // 06084148 mov r10,r13
    c.r[13] -= 2;  // 0608414A add #-2,r13
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[13] + 3);  // 0608414C mov.b @(3,r13),r0
    c.r[12] = c.r[0] & 0xFFu;  // 0608414E extu.b r0,r12
    c.r[1] = ld32(0x060843A4u);  // 06084150 mov.l 0x060843A4,r1
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06084152 mov.b @r1,r8
    c.r[8] = c.r[8] & 0xFFu;  // 06084154 extu.b r8,r8
    c.r[1] = 0x1Eu;  // 06084156 mov #30,r1
    c.macl = c.r[8] * c.r[1];  // 06084158 mul.l r1,r8
    c.r[10] = c.macl;  // 0608415A sts macl,r10
    c.r[2] = c.r[12];  // 0608415C mov r12,r2
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 0608415E shar r2
    c.r[2] += c.r[10];  // 06084160 add r10,r2
    c.r[2] += 7;  // 06084162 add #7,r2
    c.r[1] = ld32(0x060843A8u);  // 06084164 mov.l 0x060843A8,r1
    c.r[1] = ld32(c.r[1]);  // 06084166 mov.l @r1,r1
    c.r[2] += c.r[1];  // 06084168 add r1,r2
    c.r[9] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0608416A mov.b @r2,r9
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[13] + 2);  // 0608416C mov.b @(2,r13),r0
    c.r[1] = c.r[0] & 0xFFu;  // 0608416E extu.b r0,r1
    c.t = c.r[11] >= c.r[1];  // 06084170 cmp/hs r1,r11
    if (c.t) { goto L_0608419A; }  // 06084172 bt 0x0608419A
    c.r[3] = ld32(0x0608439Cu);  // 06084174 mov.l 0x0608439C,r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3] + 14);  // 06084176 mov.b @(14,r3),r0
    c.r[4] = c.r[0] & 0xFFu;  // 06084178 extu.b r0,r4
    c.r[4] += c.r[11];  // 0608417A add r11,r4
    c.t = c.r[4] > c.r[1];  // 0608417C cmp/hi r1,r4
    if (!c.t) { goto L_06084182; }  // 0608417E bf 0x06084182
    c.r[4] = c.r[1];  // 06084180 mov r1,r4
L_06084182:
    c.r[5] = 0xFu;  // 06084182 mov #15,r5
    c.r[0] = c.r[12];  // 06084184 mov r12,r0
    c.t = (c.r[0] & 0x1u) == 0;  // 06084186 tst #1,r0
    if (!c.t) { goto L_06084192; }  // 06084188 bf 0x06084192
    c.r[5] <<= 2;  // 0608418A shll2 r5
    c.r[5] <<= 2;  // 0608418C shll2 r5
    c.r[4] <<= 2;  // 0608418E shll2 r4
    c.r[4] <<= 2;  // 06084190 shll2 r4
L_06084192:
    c.r[5] = ~c.r[5];  // 06084192 not r5,r5
    c.r[5] &= c.r[9];  // 06084194 and r9,r5
    c.r[5] |= c.r[4];  // 06084196 or r4,r5
    st8(c.r[2], c.r[5]);  // 06084198 mov.b r5,@r2
L_0608419A:
    c.pr = 0x0608419Eu; SH2_POLL(c); sh2_call(c, 0x06084308u); if (c.pc != 0x0608419Eu) return;  // 0608419A bsr 0x06084308 ; nop
    c.r[1] += c.r[2];  // 0608419E add r2,r1
    st16(c.r[3], c.r[1]);  // 060841A0 mov.w r1,@r3
    c.r[5] = c.r[8] & 0xFFu;  // 060841A2 extu.b r8,r5
    c.r[6] = 0xFFFFFF80u;  // 060841A4 mov #-128,r6
    c.r[6] = c.r[6] & 0xFFu;  // 060841A6 extu.b r6,r6
    c.r[1] = ld32(0x060843ACu);  // 060841A8 mov.l 0x060843AC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060841AEu; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060841AEu) return; }  // 060841AA jsr @r1 ; mov r14,r4
    c.pr = 0x060841B2u; SH2_POLL(c); sh2_call(c, 0x06084308u); if (c.pc != 0x060841B2u) return;  // 060841AE bsr 0x06084308 ; nop
    c.r[1] -= c.r[2];  // 060841B2 sub r2,r1
    st16(c.r[3], c.r[1]);  // 060841B4 mov.w r1,@r3
    c.r[1] = c.r[12];  // 060841B6 mov r12,r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 060841B8 shar r1
    c.r[3] += c.r[1];  // 060841BA add r1,r3
    c.r[3] += 7;  // 060841BC add #7,r3
    st8(c.r[3], c.r[9]);  // 060841BE mov.b r9,@r3
    c.r[5] = c.r[12] & 0xFFu;  // 060841C0 extu.b r12,r5
    c.r[1] = c.r[12];  // 060841C2 mov r12,r1
    c.r[1] <<= 2;  // 060841C4 shll2 r1
    c.r[12] += c.r[1];  // 060841C6 add r1,r12
    c.r[12] <<= 2;  // 060841C8 shll2 r12
    c.r[8] = ld32(0x06084394u);  // 060841CA mov.l 0x06084394,r8
    c.r[1] = ld32(c.r[8]);  // 060841CC mov.l @r8,r1
    c.r[1] += c.r[12];  // 060841CE add r12,r1
    c.r[1] += 44;  // 060841D0 add #44,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060841D2 mov.w @r1,r4
    c.r[1] = 0xFFFFFFF5u;  // 060841D4 mov #-11,r1
    c.r[1] <<= 8;  // 060841D6 shll8 r1
    c.r[4] += c.r[1];  // 060841D8 add r1,r4
    c.r[1] = ld32(0x060843B0u);  // 060841DA mov.l 0x060843B0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060841E0u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060841E0u) return; }  // 060841DC jsr @r1 ; extu.w r4,r4
    c.r[1] = ld32(c.r[8]);  // 060841E0 mov.l @r8,r1
    c.r[1] += c.r[12];  // 060841E2 add r12,r1
    c.r[1] += 48;  // 060841E4 add #48,r1
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060841E6 mov.w @r1,r6
    c.r[5] = 0x0u;  // 060841E8 mov #0,r5
    c.r[4] = 0x0u;  // 060841EA mov #0,r4
    c.r[9] = ld32(0x060843B4u);  // 060841EC mov.l 0x060843B4,r9
    { const uint32_t x = c.r[9]; c.pr = 0x060841F2u; c.r[6] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060841F2u) return; }  // 060841EE jsr @r9 ; extu.w r6,r6
    c.r[10] = c.r[14];  // 060841F2 mov r14,r10
    c.r[10] += c.r[12];  // 060841F4 add r12,r10
    c.r[10] += 48;  // 060841F6 add #48,r10
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[13] + 2);  // 060841F8 mov.b @(2,r13),r0
    c.r[1] = c.r[0] & 0xFFu;  // 060841FA extu.b r0,r1
    c.t = c.r[11] >= c.r[1];  // 060841FC cmp/hs r1,r11
    { const bool k = c.t; c.r[5] = 0x0u; if (k) { goto L_0608420A; } }  // 060841FE bt/s 0x0608420A ; mov #0,r5
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[10]);  // 06084202 mov.w @r10,r6
    c.r[4] = 0x0u;  // 06084204 mov #0,r4
    c.r[6] = c.r[6] & 0xFFFFu; goto L_0608420E;  // 06084206 bra 0x0608420E ; extu.w r6,r6
L_0608420A:
    c.r[6] = 0x0u;  // 0608420A mov #0,r6
    c.r[4] = 0x50u;  // 0608420C mov #80,r4
L_0608420E:
    { const uint32_t x = c.r[9]; c.pr = 0x06084212u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084212u) return; }  // 0608420E jsr @r9 ; nop
    c.r[1] = ld32(0x060843B8u);  // 06084212 mov.l 0x060843B8,r1
    c.r[2] = ld32(c.r[1]);  // 06084214 mov.l @r1,r2
    c.r[5] = 0x0u;  // 06084216 mov #0,r5
    c.r[4] = 0x0u;  // 06084218 mov #0,r4
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[2] + 10);  // 0608421A mov.w @(10,r2),r0
    c.r[1] = c.r[0] & 0xFFFFu;  // 0608421C extu.w r0,r1
    c.r[1] <<= 8;  // 0608421E shll8 r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2] + 12);  // 06084220 mov.b @(12,r2),r0
    c.r[6] = c.r[0] & 0xFFu;  // 06084222 extu.b r0,r6
    { const uint32_t x = c.r[9]; c.pr = 0x06084228u; c.r[6] |= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084228u) return; }  // 06084224 jsr @r9 ; or r1,r6
    c.r[2] = ld32(c.r[8]);  // 06084228 mov.l @r8,r2
    c.r[2] += c.r[12];  // 0608422A add r12,r2
    c.r[2] += 44;  // 0608422C add #44,r2
    c.r[12] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0608422E mov.w @r2,r12
    c.r[4] = ld32(0x060843BCu);  // 06084230 mov.l 0x060843BC,r4
    c.r[8] = ld32(0x060843C0u);  // 06084232 mov.l 0x060843C0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06084238u; c.r[5] = 0x1Du; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084238u) return; }  // 06084234 jsr @r8 ; mov #29,r5
    c.r[4] = c.r[0];  // 06084238 mov r0,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0608423Eu; c.r[5] = c.r[12] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608423Eu) return; }  // 0608423A jsr @r8 ; extu.w r12,r5
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0] + 8);  // 0608423E mov.b @(8,r0),r0
    c.r[0] &= 0xFu;  // 06084240 and #15,r0
    c.r[12] = c.r[0];  // 06084242 mov r0,r12
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[13] + 2);  // 06084244 mov.b @(2,r13),r0
    c.r[1] = c.r[0] & 0xFFu;  // 06084246 extu.b r0,r1
    c.t = c.r[11] >= c.r[1];  // 06084248 cmp/hs r1,r11
    { const bool k = c.t; c.r[6] = 0x0u; if (k) { goto L_060842BA; } }  // 0608424A bt/s 0x060842BA ; mov #0,r6
    c.r[4] = ld32(0x060843BCu);  // 0608424E mov.l 0x060843BC,r4
    { const uint32_t x = c.r[8]; c.pr = 0x06084254u; c.r[5] = 0x1Fu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084254u) return; }  // 06084250 jsr @r8 ; mov #31,r5
    c.r[4] = c.r[0];  // 06084254 mov r0,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0608425Au; c.r[5] = 0x3u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608425Au) return; }  // 06084256 jsr @r8 ; mov #3,r5
    c.r[1] = 0x16u;  // 0608425A mov #22,r1
    c.macl = c.r[12] * c.r[1];  // 0608425C mul.l r1,r12
    c.r[2] = c.macl;  // 0608425E sts macl,r2
    c.r[2] += c.r[0];  // 06084260 add r0,r2
    c.r[7] = c.r[11];  // 06084262 mov r11,r7
    c.r[7] += c.r[7];  // 06084264 add r7,r7
    c.r[2] += c.r[7];  // 06084266 add r7,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[10]);  // 06084268 mov.w @r10,r1
    c.r[5] = ld32(0x060843C4u);  // 0608426A mov.l 0x060843C4,r5
    st16(c.r[5], c.r[1]);  // 0608426C mov.w r1,@r5
    c.r[1] = ld32(0x0608439Cu);  // 0608426E mov.l 0x0608439C,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1] + 14);  // 06084270 mov.b @(14,r1),r0
    c.r[3] = c.r[0] & 0xFFu;  // 06084272 extu.b r0,r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[13] + 2);  // 06084274 mov.b @(2,r13),r0
    c.r[1] = c.r[0] & 0xFFu;  // 06084276 extu.b r0,r1
    c.r[1] -= c.r[11];  // 06084278 sub r11,r1
    c.t = (int32_t)c.r[3] > (int32_t)c.r[1];  // 0608427A cmp/gt r1,r3
    if (!c.t) { goto L_06084280; }  // 0608427C bf 0x06084280
    c.r[3] = c.r[1];  // 0608427E mov r1,r3
L_06084280:
    c.t = (int32_t)c.r[3] > 0;  // 06084280 cmp/pl r3
    if (c.t) { goto L_06084286; }  // 06084282 bt 0x06084286
    c.r[3] = 0x1u;  // 06084284 mov #1,r3
L_06084286:
    c.r[0] = c.r[3];  // 06084286 mov r3,r0
    st8(c.r[5] + 2, c.r[0]);  // 06084288 mov.b r0,@(2,r5)
    c.r[5] -= 20;  // 0608428A add #-20,r5
    c.r[6] = 0x0u;  // 0608428C mov #0,r6
L_0608428E:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]); c.r[2] += 1;  // 0608428E mov.b @r2+,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06084290 extu.b r1,r1
    c.r[1] <<= 8;  // 06084292 shll8 r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]); c.r[2] += 1;  // 06084294 mov.b @r2+,r0
    c.r[0] = c.r[0] & 0xFFu;  // 06084296 extu.b r0,r0
    c.r[1] |= c.r[0];  // 06084298 or r0,r1
    st16(c.r[5], c.r[1]);  // 0608429A mov.w r1,@r5
    c.r[5] += 2;  // 0608429C add #2,r5
    c.r[6] += c.r[1];  // 0608429E add r1,r6
    c.r[3] -= 1; c.t = c.r[3] == 0;  // 060842A0 dt r3
    if (!c.t) { SH2_POLL(c); goto L_0608428E; }  // 060842A2 bf 0x0608428E
    c.r[1] = c.r[6];  // 060842A4 mov r6,r1
    c.r[6] <<= 2;  // 060842A6 shll2 r6
    c.r[6] += c.r[1];  // 060842A8 add r1,r6
    c.r[6] += c.r[6];  // 060842AA add r6,r6
    c.r[1] = c.r[13];  // 060842AC mov r13,r1
    c.r[1] -= 128;  // 060842AE add #-128,r1
    c.r[1] -= 16;  // 060842B0 add #-16,r1
    st32(c.r[1], c.r[6]);  // 060842B2 mov.l r6,@r1
    c.r[5] = 0x0u;  // 060842B4 mov #0,r5
    c.r[4] = 0x0u; goto L_060842BE;  // 060842B6 bra 0x060842BE ; mov #0,r4
L_060842BA:
    c.r[5] = 0x0u;  // 060842BA mov #0,r5
    c.r[4] = 0x70u;  // 060842BC mov #112,r4
L_060842BE:
    { const uint32_t x = c.r[9]; c.pr = 0x060842C2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060842C2u) return; }  // 060842BE jsr @r9 ; nop
    c.r[7] = 0x2u;  // 060842C2 mov #2,r7
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 060842C4 mov.l r7,@-r15
    c.r[2] = 0x1u;  // 060842C6 mov #1,r2
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 060842C8 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 060842CA mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 060842CC mov.l r2,@-r15
    c.r[1] = 0x0u;  // 060842CE mov #0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060842D0 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 060842D2 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060842D4 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060842D6 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 060842D8 mov.l r7,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 060842DA mov.l r2,@-r15
    c.r[1] = ld32(0x060843C8u);  // 060842DC mov.l 0x060843C8,r1
    c.r[6] = 0x5u;  // 060842DE mov #5,r6
    c.r[5] = 0xEu;  // 060842E0 mov #14,r5
    { const uint32_t x = c.r[1]; c.pr = 0x060842E6u; c.r[4] = 0xFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060842E6u) return; }  // 060842E2 jsr @r1 ; mov #15,r4
    c.r[15] += 40;  // 060842E6 add #40,r15
    c.r[1] = ld32(0x060843CCu);  // 060842E8 mov.l 0x060843CC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060842EEu; c.r[4] = 0x4Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060842EEu) return; }  // 060842EA jsr @r1 ; mov #78,r4
    c.r[3] = 0x68u;  // 060842EE mov #104,r3
    c.r[3] <<= 2;  // 060842F0 shll2 r3
    c.r[15] += c.r[3];  // 060842F2 add r3,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060842F4 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060842F6 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060842F8 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060842FA mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060842FC mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060842FE mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06084300 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x060843E0u);  // 06084302 mov.w 0x060843E0,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06084304 rts ; mov.l @r15+,r8
}

void f_06084308(SH2Context& c) {
    ran[1845] = 1;
    c.r[1] = ld32(0x060843A8u);  // 06084308 mov.l 0x060843A8,r1
    c.r[3] = ld32(c.r[1]);  // 0608430A mov.l @r1,r3
    c.r[3] += c.r[10];  // 0608430C add r10,r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[13]);  // 0608430E mov.b @(0,r13),r0
    c.r[0] = c.r[0] & 0xFFu;  // 06084310 extu.b r0,r0
    c.r[1] = c.r[13];  // 06084312 mov r13,r1
    c.r[1] -= 128;  // 06084314 add #-128,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06084316 mov.b @(r0,r1),r2
    c.r[2] = c.r[2] & 0xFFu;  // 06084318 extu.b r2,r2
    { const uint32_t x = c.pr; c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]); c.pc = x; return; }  // 0608431A rts ; mov.w @r3,r1
}

void f_0608431E(SH2Context& c) {
    ran[1846] = 1;
    goto L_0608431E;
L_0601B124:
    c.r[3] = ld32(0x0601B240u);  // 0601B124 mov.l 0x0601B240,r3
L_0601B126:
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0601B126 mov.w @r3,r2
L_0601B128:
    c.r[7] = ld32(0x0601B244u);  // 0601B128 mov.l 0x0601B244,r7
L_0601B12A:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[7]);  // 0601B12A mov.w @r7,r1
L_0601B12C:
    c.r[2] |= c.r[1];  // 0601B12C or r1,r2
L_0601B12E:
    st16(c.r[3], c.r[2]);  // 0601B12E mov.w r2,@r3
L_0601B130:
    c.r[1] = 0x0u;  // 0601B130 mov #0,r1
L_0601B132:
    st16(c.r[7], c.r[1]);  // 0601B132 mov.w r1,@r7
L_0601B134:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601B232u);  // 0601B134 mov.w 0x0601B232,r1
L_0601B136:
    c.r[1] &= c.r[2];  // 0601B136 and r2,r1
L_0601B138:
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601B138 tst r1,r1
L_0601B13A:
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0601B144; } }  // 0601B13A bt/s 0x0601B144 ; mov r15,r14
L_0601B13E:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601B234u);  // 0601B13E mov.w 0x0601B234,r0
L_0601B140:
    c.r[15] = c.r[14]; goto L_0601B6D2;  // 0601B140 bra 0x0601B6D2 ; mov r14,r15
L_0601B144:
    c.r[0] = c.r[2];  // 0601B144 mov r2,r0
L_0601B146:
    c.r[0] >>= 8;  // 0601B146 shlr8 r0
L_0601B148:
    c.r[0] &= 0x1u;  // 0601B148 and #1,r0
L_0601B14A:
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601B14A tst r0,r0
L_0601B14C:
    if (c.t) { goto L_0601B156; }  // 0601B14C bt 0x0601B156
L_0601B14E:
    c.r[15] = c.r[14];  // 0601B14E mov r14,r15
L_0601B150:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601B236u);  // 0601B150 mov.w 0x0601B236,r0
L_0601B152:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; } goto L_0601B6D4;  // 0601B152 bra 0x0601B6D4 ; lds.l @r15+,pr
L_0601B156:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601B238u);  // 0601B156 mov.w 0x0601B238,r1
L_0601B158:
    c.r[2] &= c.r[1];  // 0601B158 and r1,r2
L_0601B15A:
    c.t = (c.r[2] & c.r[2]) == 0;  // 0601B15A tst r2,r2
L_0601B15C:
    if (c.t) { goto L_0601B162; }  // 0601B15C bt 0x0601B162
L_0601B15E:
    goto L_0601B46A;  // 0601B15E bra 0x0601B46A ; nop
L_0601B162:
    c.r[1] = ld32(0x0601B248u);  // 0601B162 mov.l 0x0601B248,r1
L_0601B164:
    c.r[9] = ld32(c.r[1]);  // 0601B164 mov.l @r1,r9
L_0601B166:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0601B166 mov.b @r9,r0
L_0601B168:
    c.r[0] &= 0xC0u;  // 0601B168 and #192,r0
L_0601B16A:
    c.r[0] >>= 2;  // 0601B16A shlr2 r0
L_0601B16C:
    c.r[0] >>= 2;  // 0601B16C shlr2 r0
L_0601B16E:
    c.r[0] >>= 2;  // 0601B16E shlr2 r0
L_0601B170:
    c.t = c.r[0] == 0x1u;  // 0601B170 cmp/eq #1,r0
L_0601B172:
    { const bool k = c.t; c.t = (c.r[9] & c.r[9]) == 0; if (k) { goto L_0601B18C; } }  // 0601B172 bt/s 0x0601B18C ; tst r9,r9
L_0601B176:
    c.r[1] = ld32(0x0601B24Cu);  // 0601B176 mov.l 0x0601B24C,r1
L_0601B178:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B178 mov.b @r1,r1
L_0601B17A:
    c.r[0] = c.r[1] & 0xFFu;  // 0601B17A extu.b r1,r0
L_0601B17C:
    c.r[1] = ld32(0x0601B250u);  // 0601B17C mov.l 0x0601B250,r1
L_0601B17E:
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601B17E mov.b @(r0,r1),r5
L_0601B180:
    c.r[4] = c.r[9];  // 0601B180 mov r9,r4
L_0601B182:
    c.r[0] = ld32(0x0601B254u);  // 0601B182 mov.l 0x0601B254,r0
L_0601B184:
    { const uint32_t x = c.r[0]; c.pr = 0x0601B188u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601B188u) return; }  // 0601B184 jsr @r0 ; extu.b r5,r5
L_0601B188:
    c.r[9] = c.r[0];  // 0601B188 mov r0,r9
L_0601B18A:
    c.t = (c.r[9] & c.r[9]) == 0;  // 0601B18A tst r9,r9
L_0601B18C:
    { const bool k = !c.t; c.r[4] = 0x0u; if (k) { goto L_0601B194; } }  // 0601B18C bf/s 0x0601B194 ; mov #0,r4
L_0601B190:
    goto L_0601B6C8;  // 0601B190 bra 0x0601B6C8 ; nop
L_0601B194:
    c.r[1] = ld32(0x0601B258u);  // 0601B194 mov.l 0x0601B258,r1
L_0601B196:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B196 mov.b @r1,r0
L_0601B198:
    c.r[7] = 0x3u;  // 0601B198 mov #3,r7
L_0601B19A:
    c.r[3] = 0x0u;  // 0601B19A mov #0,r3
L_0601B19C:
    c.r[2] = ld32(0x0601B25Cu);  // 0601B19C mov.l 0x0601B25C,r2
L_0601B19E:
    c.r[0] &= 0xFEu;  // 0601B19E and #254,r0
L_0601B1A0:
    st8(c.r[1], c.r[0]);  // 0601B1A0 mov.b r0,@r1
L_0601B1A2:
    c.r[1] = c.r[2];  // 0601B1A2 mov r2,r1
L_0601B1A4:
    c.r[1] += 2;  // 0601B1A4 add #2,r1
L_0601B1A6:
    st8(c.r[1], c.r[3]);  // 0601B1A6 mov.b r3,@r1
L_0601B1A8:
    c.r[4] += 1;  // 0601B1A8 add #1,r4
L_0601B1AA:
    c.t = (int32_t)c.r[4] > (int32_t)c.r[7];  // 0601B1AA cmp/gt r7,r4
L_0601B1AC:
    { const bool k = !c.t; c.r[2] += 3; if (k) { SH2_POLL(c); goto L_0601B1A2; } }  // 0601B1AC bf/s 0x0601B1A2 ; add #3,r2
L_0601B1B0:
    c.r[7] = c.r[9];  // 0601B1B0 mov r9,r7
L_0601B1B2:
    c.r[7] += 2;  // 0601B1B2 add #2,r7
L_0601B1B4:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0601B1B4 mov.b @r7,r1
L_0601B1B6:
    c.r[0] = c.r[1];  // 0601B1B6 mov r1,r0
L_0601B1B8:
    c.r[0] >>= 2;  // 0601B1B8 shlr2 r0
L_0601B1BA:
    c.r[0] >>= 2;  // 0601B1BA shlr2 r0
L_0601B1BC:
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0601B1BC shlr r0
L_0601B1BE:
    c.r[0] >>= 2;  // 0601B1BE shlr2 r0
L_0601B1C0:
    c.r[0] &= 0x1u;  // 0601B1C0 and #1,r0
L_0601B1C2:
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601B1C2 tst r0,r0
L_0601B1C4:
    { const bool k = c.t; c.r[0] = c.r[1]; if (k) { goto L_0601B1E2; } }  // 0601B1C4 bt/s 0x0601B1E2 ; mov r1,r0
L_0601B1C8:
    c.r[1] = ld32(0x0601B258u);  // 0601B1C8 mov.l 0x0601B258,r1
L_0601B1CA:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B1CA mov.b @r1,r0
L_0601B1CC:
    c.r[2] = ld32(0x0601B25Cu);  // 0601B1CC mov.l 0x0601B25C,r2
L_0601B1CE:
    c.r[3] = c.r[2];  // 0601B1CE mov r2,r3
L_0601B1D0:
    c.r[3] += 8;  // 0601B1D0 add #8,r3
L_0601B1D2:
    c.r[2] += 11;  // 0601B1D2 add #11,r2
L_0601B1D4:
    c.r[0] |= 0x1u;  // 0601B1D4 or #1,r0
L_0601B1D6:
    st8(c.r[1], c.r[0]);  // 0601B1D6 mov.b r0,@r1
L_0601B1D8:
    c.r[1] = 0x1u;  // 0601B1D8 mov #1,r1
L_0601B1DA:
    st8(c.r[2], c.r[1]);  // 0601B1DA mov.b r1,@r2
L_0601B1DC:
    st8(c.r[3], c.r[1]);  // 0601B1DC mov.b r1,@r3
L_0601B1DE:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0601B1DE mov.b @r7,r1
L_0601B1E0:
    c.r[0] = c.r[1];  // 0601B1E0 mov r1,r0
L_0601B1E2:
    c.r[0] >>= 2;  // 0601B1E2 shlr2 r0
L_0601B1E4:
    c.r[0] >>= 2;  // 0601B1E4 shlr2 r0
L_0601B1E6:
    c.r[0] >>= 2;  // 0601B1E6 shlr2 r0
L_0601B1E8:
    c.r[0] &= 0x1u;  // 0601B1E8 and #1,r0
L_0601B1EA:
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601B1EA tst r0,r0
L_0601B1EC:
    if (c.t) { goto L_0601B204; }  // 0601B1EC bt 0x0601B204
L_0601B1EE:
    c.r[1] = ld32(0x0601B258u);  // 0601B1EE mov.l 0x0601B258,r1
L_0601B1F0:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B1F0 mov.b @r1,r0
L_0601B1F2:
    c.r[2] = ld32(0x0601B25Cu);  // 0601B1F2 mov.l 0x0601B25C,r2
L_0601B1F4:
    c.r[3] = c.r[2];  // 0601B1F4 mov r2,r3
L_0601B1F6:
    c.r[3] += 2;  // 0601B1F6 add #2,r3
L_0601B1F8:
    c.r[2] += 5;  // 0601B1F8 add #5,r2
L_0601B1FA:
    c.r[0] |= 0x1u;  // 0601B1FA or #1,r0
L_0601B1FC:
    st8(c.r[1], c.r[0]);  // 0601B1FC mov.b r0,@r1
L_0601B1FE:
    c.r[1] = 0x1u;  // 0601B1FE mov #1,r1
L_0601B200:
    st8(c.r[2], c.r[1]);  // 0601B200 mov.b r1,@r2
L_0601B202:
    st8(c.r[3], c.r[1]);  // 0601B202 mov.b r1,@r3
L_0601B204:
    c.r[1] = ld32(0x0601B240u);  // 0601B204 mov.l 0x0601B240,r1
L_0601B206:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0601B206 mov.w @r1,r1
L_0601B208:
    c.r[2] = (uint32_t)(int16_t)ld16(0x0601B23Au);  // 0601B208 mov.w 0x0601B23A,r2
L_0601B20A:
    c.r[2] &= c.r[1];  // 0601B20A and r1,r2
L_0601B20C:
    c.t = (c.r[2] & c.r[2]) == 0;  // 0601B20C tst r2,r2
L_0601B20E:
    if (!c.t) { goto L_0601B214; }  // 0601B20E bf 0x0601B214
L_0601B210:
    goto L_0601B36E;  // 0601B210 bra 0x0601B36E ; nop
L_0601B214:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0601B214 mov.b @r9,r1
L_0601B216:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601B23Cu);  // 0601B216 mov.w 0x0601B23C,r0
L_0601B218:
    c.r[1] &= c.r[0];  // 0601B218 and r0,r1
L_0601B21A:
    c.r[1] >>= 2;  // 0601B21A shlr2 r1
L_0601B21C:
    c.r[1] >>= 2;  // 0601B21C shlr2 r1
L_0601B21E:
    c.r[1] >>= 2;  // 0601B21E shlr2 r1
L_0601B220:
    c.r[0] = c.r[1];  // 0601B220 mov r1,r0
L_0601B222:
    c.t = c.r[0] == 0x1u;  // 0601B222 cmp/eq #1,r0
L_0601B224:
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_0601B260; } }  // 0601B224 bt/s 0x0601B260 ; mov r9,r1
L_0601B228:
    c.t = c.r[0] == 0x2u;  // 0601B228 cmp/eq #2,r0
L_0601B22A:
    { const bool k = c.t; c.r[1] += 4; if (k) { goto L_0601B312; } }  // 0601B22A bt/s 0x0601B312 ; add #4,r1
L_0601B22E:
    goto L_0601B32C;  // 0601B22E bra 0x0601B32C ; nop
L_0601B260:
    c.r[1] += 5;  // 0601B260 add #5,r1
L_0601B262:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B262 mov.b @r1,r1
L_0601B264:
    c.r[10] = c.r[1] & 0xFFu;  // 0601B264 extu.b r1,r10
L_0601B266:
    c.r[1] = c.r[9];  // 0601B266 mov r9,r1
L_0601B268:
    c.r[1] += 4;  // 0601B268 add #4,r1
L_0601B26A:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B26A mov.b @r1,r1
L_0601B26C:
    c.r[13] = ld32(0x0601B438u);  // 0601B26C mov.l 0x0601B438,r13
L_0601B26E:
    c.r[8] = c.r[1] & 0xFFu;  // 0601B26E extu.b r1,r8
L_0601B270:
    c.r[1] = ld32(0x0601B43Cu);  // 0601B270 mov.l 0x0601B43C,r1
L_0601B272:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B272 mov.b @r1,r1
L_0601B274:
    c.r[7] = ld32(0x0601B440u);  // 0601B274 mov.l 0x0601B440,r7
L_0601B276:
    c.r[12] = c.r[1] & 0xFFu;  // 0601B276 extu.b r1,r12
L_0601B278:
    c.r[0] = c.r[12];  // 0601B278 mov r12,r0
L_0601B27A:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[13]);  // 0601B27A mov.b @(r0,r13),r11
L_0601B27C:
    c.r[5] = c.r[8];  // 0601B27C mov r8,r5
L_0601B27E:
    c.r[6] = c.r[11] & 0xFFu;  // 0601B27E extu.b r11,r6
L_0601B280:
    { const uint32_t x = c.r[7]; c.pr = 0x0601B284u; c.r[4] = c.r[6]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601B284u) return; }  // 0601B280 jsr @r7 ; mov r6,r4
L_0601B284:
    c.r[7] = c.r[0];  // 0601B284 mov r0,r7
L_0601B286:
    c.macl = c.r[7] * c.r[8];  // 0601B286 mul.l r8,r7
L_0601B288:
    c.r[0] = c.r[6];  // 0601B288 mov r6,r0
L_0601B28A:
    c.r[1] = c.macl;  // 0601B28A sts macl,r1
L_0601B28C:
    c.r[0] -= c.r[1];  // 0601B28C sub r1,r0
L_0601B28E:
    c.r[1] = c.r[0];  // 0601B28E mov r0,r1
L_0601B290:
    c.t = (int32_t)c.r[1] > 0;  // 0601B290 cmp/pl r1
L_0601B292:
    { const bool k = !c.t; c.r[1] = c.r[11]; if (k) { goto L_0601B29E; } }  // 0601B292 bf/s 0x0601B29E ; mov r11,r1
L_0601B296:
    c.r[1] -= 1;  // 0601B296 add #-1,r1
L_0601B298:
    c.r[0] = c.r[12];  // 0601B298 mov r12,r0
L_0601B29A:
    st8(c.r[0] + c.r[13], c.r[1]); goto L_0601B358;  // 0601B29A bra 0x0601B358 ; mov.b r1,@(r0,r13)
L_0601B29E:
    c.r[1] = c.r[9];  // 0601B29E mov r9,r1
L_0601B2A0:
    c.r[1] += 1;  // 0601B2A0 add #1,r1
L_0601B2A2:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B2A2 mov.b @r1,r1
L_0601B2A4:
    c.r[0] = c.r[1];  // 0601B2A4 mov r1,r0
L_0601B2A6:
    c.r[0] >>= 2;  // 0601B2A6 shlr2 r0
L_0601B2A8:
    c.r[0] >>= 2;  // 0601B2A8 shlr2 r0
L_0601B2AA:
    c.r[0] >>= 2;  // 0601B2AA shlr2 r0
L_0601B2AC:
    c.r[0] &= 0x1u;  // 0601B2AC and #1,r0
L_0601B2AE:
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601B2AE tst r0,r0
L_0601B2B0:
    { const bool k = !c.t; c.r[4] = c.r[6]; if (k) { goto L_0601B2B8; } }  // 0601B2B0 bf/s 0x0601B2B8 ; mov r6,r4
L_0601B2B4:
    goto L_0601B46A;  // 0601B2B4 bra 0x0601B46A ; nop
L_0601B2B8:
    c.r[1] = c.r[9];  // 0601B2B8 mov r9,r1
L_0601B2BA:
    c.r[1] += 8;  // 0601B2BA add #8,r1
L_0601B2BC:
    c.r[3] = c.r[12];  // 0601B2BC mov r12,r3
L_0601B2BE:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B2BE mov.b @r1,r1
L_0601B2C0:
    c.r[0] = c.r[3];  // 0601B2C0 mov r3,r0
L_0601B2C2:
    c.r[2] = c.r[1] & 0xFFu;  // 0601B2C2 extu.b r1,r2
L_0601B2C4:
    c.r[1] = c.r[9];  // 0601B2C4 mov r9,r1
L_0601B2C6:
    c.r[1] += 9;  // 0601B2C6 add #9,r1
L_0601B2C8:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B2C8 mov.b @r1,r1
L_0601B2CA:
    c.r[2] <<= 8;  // 0601B2CA shll8 r2
L_0601B2CC:
    c.r[1] = c.r[1] & 0xFFu;  // 0601B2CC extu.b r1,r1
L_0601B2CE:
    c.r[2] |= c.r[1];  // 0601B2CE or r1,r2
L_0601B2D0:
    c.r[1] = ld32(0x0601B444u);  // 0601B2D0 mov.l 0x0601B444,r1
L_0601B2D2:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601B2D2 mov.b @(r0,r1),r1
L_0601B2D4:
    c.r[1] = c.r[1] & 0xFFu;  // 0601B2D4 extu.b r1,r1
L_0601B2D6:
    c.r[1] -= 1;  // 0601B2D6 add #-1,r1
L_0601B2D8:
    c.macl = c.r[1] * c.r[10];  // 0601B2D8 mul.l r10,r1
L_0601B2DA:
    c.r[4] += c.r[8]; goto L_0601B2F2;  // 0601B2DA bra 0x0601B2F2 ; add r8,r4
L_0601B2DE:
    c.r[1] = ld32(0x0601B438u);  // 0601B2DE mov.l 0x0601B438,r1
L_0601B2E0:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601B2E0 mov.b @(r0,r1),r1
L_0601B2E2:
    c.r[1] = c.r[1] & 0xFFu;  // 0601B2E2 extu.b r1,r1
L_0601B2E4:
    c.t = (int32_t)c.r[4] > (int32_t)c.r[1];  // 0601B2E4 cmp/gt r1,r4
L_0601B2E6:
    if (!c.t) { goto L_0601B306; }  // 0601B2E6 bf 0x0601B306
L_0601B2E8:
    c.r[1] = ld32(0x0601B444u);  // 0601B2E8 mov.l 0x0601B444,r1
L_0601B2EA:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601B2EA mov.b @(r0,r1),r1
L_0601B2EC:
    c.r[1] = c.r[1] & 0xFFu;  // 0601B2EC extu.b r1,r1
L_0601B2EE:
    c.r[1] -= 1;  // 0601B2EE add #-1,r1
L_0601B2F0:
    c.macl = c.r[1] * c.r[10];  // 0601B2F0 mul.l r10,r1
L_0601B2F2:
    c.r[1] = c.macl;  // 0601B2F2 sts macl,r1
L_0601B2F4:
    c.macl = c.r[1] * c.r[8];  // 0601B2F4 mul.l r8,r1
L_0601B2F6:
    c.r[4] -= 1;  // 0601B2F6 add #-1,r4
L_0601B2F8:
    c.r[0] = c.r[2];  // 0601B2F8 mov r2,r0
L_0601B2FA:
    c.r[1] = c.macl;  // 0601B2FA sts macl,r1
L_0601B2FC:
    c.r[0] -= c.r[1];  // 0601B2FC sub r1,r0
L_0601B2FE:
    c.r[1] = c.r[0];  // 0601B2FE mov r0,r1
L_0601B300:
    c.t = (int32_t)c.r[1] > (int32_t)c.r[4];  // 0601B300 cmp/gt r4,r1
L_0601B302:
    { const bool k = !c.t; c.r[0] = c.r[3]; if (k) { SH2_POLL(c); goto L_0601B2DE; } }  // 0601B302 bf/s 0x0601B2DE ; mov r3,r0
L_0601B306:
    c.r[1] = ld32(0x0601B43Cu);  // 0601B306 mov.l 0x0601B43C,r1
L_0601B308:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B308 mov.b @r1,r1
L_0601B30A:
    c.r[0] = c.r[1] & 0xFFu;  // 0601B30A extu.b r1,r0
L_0601B30C:
    c.r[1] = ld32(0x0601B438u);  // 0601B30C mov.l 0x0601B438,r1
L_0601B30E:
    st8(c.r[0] + c.r[1], c.r[4]); goto L_0601B358;  // 0601B30E bra 0x0601B358 ; mov.b r4,@(r0,r1)
L_0601B312:
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B312 mov.b @r1,r3
L_0601B314:
    c.r[2] = c.r[3] & 0xFFu;  // 0601B314 extu.b r3,r2
L_0601B316:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601B434u);  // 0601B316 mov.w 0x0601B434,r1
L_0601B318:
    c.t = c.r[2] == c.r[1];  // 0601B318 cmp/eq r1,r2
L_0601B31A:
    if (!c.t) { goto L_0601B320; }  // 0601B31A bf 0x0601B320
L_0601B31C:
    goto L_0601B46A;  // 0601B31C bra 0x0601B46A ; nop
L_0601B320:
    c.r[1] = ld32(0x0601B43Cu);  // 0601B320 mov.l 0x0601B43C,r1
L_0601B322:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B322 mov.b @r1,r1
L_0601B324:
    c.r[0] = c.r[1] & 0xFFu;  // 0601B324 extu.b r1,r0
L_0601B326:
    c.r[1] = ld32(0x0601B438u);  // 0601B326 mov.l 0x0601B438,r1
L_0601B328:
    st8(c.r[0] + c.r[1], c.r[3]); goto L_0601B358;  // 0601B328 bra 0x0601B358 ; mov.b r3,@(r0,r1)
L_0601B32C:
    c.r[10] = ld32(0x0601B43Cu);  // 0601B32C mov.l 0x0601B43C,r10
L_0601B32E:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0601B32E mov.b @r10,r1
L_0601B330:
    c.r[8] = ld32(0x0601B438u);  // 0601B330 mov.l 0x0601B438,r8
L_0601B332:
    c.r[3] = c.r[1] & 0xFFu;  // 0601B332 extu.b r1,r3
L_0601B334:
    c.r[0] = c.r[3];  // 0601B334 mov r3,r0
L_0601B336:
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0601B336 mov.b @(r0,r8),r2
L_0601B338:
    c.r[1] = c.r[2] & 0xFFu;  // 0601B338 extu.b r2,r1
L_0601B33A:
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601B33A tst r1,r1
L_0601B33C:
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_0601B346; } }  // 0601B33C bt/s 0x0601B346 ; mov r2,r1
L_0601B340:
    c.r[1] -= 1;  // 0601B340 add #-1,r1
L_0601B342:
    st8(c.r[0] + c.r[8], c.r[1]); goto L_0601B358;  // 0601B342 bra 0x0601B358 ; mov.b r1,@(r0,r8)
L_0601B346:
    c.r[1] = ld32(0x0601B448u);  // 0601B346 mov.l 0x0601B448,r1
L_0601B348:
    c.r[0] = ld32(0x0601B44Cu);  // 0601B348 mov.l 0x0601B44C,r0
L_0601B34A:
    { const uint32_t x = c.r[0]; c.pr = 0x0601B34Eu; c.r[4] = ld32(c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601B34Eu) return; }  // 0601B34A jsr @r0 ; mov.l @r1,r4
L_0601B34E:
    c.r[2] = c.r[0];  // 0601B34E mov r0,r2
L_0601B350:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0601B350 mov.b @r10,r1
L_0601B352:
    c.r[2] -= 1;  // 0601B352 add #-1,r2
L_0601B354:
    c.r[0] = c.r[1] & 0xFFu;  // 0601B354 extu.b r1,r0
L_0601B356:
    st8(c.r[0] + c.r[8], c.r[2]);  // 0601B356 mov.b r2,@(r0,r8)
L_0601B358:
    c.r[1] = c.r[9];  // 0601B358 mov r9,r1
L_0601B35A:
    c.r[1] += 1;  // 0601B35A add #1,r1
L_0601B35C:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B35C mov.b @r1,r1
L_0601B35E:
    c.r[0] = c.r[1];  // 0601B35E mov r1,r0
L_0601B360:
    c.r[0] >>= 2;  // 0601B360 shlr2 r0
L_0601B362:
    c.r[0] >>= 2;  // 0601B362 shlr2 r0
L_0601B364:
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0601B364 shlr r0
L_0601B366:
    c.r[0] >>= 2;  // 0601B366 shlr2 r0
L_0601B368:
    c.r[0] &= 0x1u;  // 0601B368 and #1,r0
L_0601B36A:
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601B36A tst r0,r0
L_0601B36C:
    if (!c.t) { goto L_0601B46A; }  // 0601B36C bf 0x0601B46A
L_0601B36E:
    c.r[1] = ld32(0x0601B450u);  // 0601B36E mov.l 0x0601B450,r1
L_0601B370:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0601B370 mov.w @r1,r1
L_0601B372:
    c.r[2] = ld32(0x0601B454u);  // 0601B372 mov.l 0x0601B454,r2
L_0601B374:
    c.r[2] &= c.r[1];  // 0601B374 and r1,r2
L_0601B376:
    c.t = (c.r[2] & c.r[2]) == 0;  // 0601B376 tst r2,r2
L_0601B378:
    if (!c.t) { goto L_0601B37E; }  // 0601B378 bf 0x0601B37E
L_0601B37A:
    goto L_0601B4C6;  // 0601B37A bra 0x0601B4C6 ; nop
L_0601B37E:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0601B37E mov.b @r9,r1
L_0601B380:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601B436u);  // 0601B380 mov.w 0x0601B436,r0
L_0601B382:
    c.r[1] &= c.r[0];  // 0601B382 and r0,r1
L_0601B384:
    c.r[1] >>= 2;  // 0601B384 shlr2 r1
L_0601B386:
    c.r[1] >>= 2;  // 0601B386 shlr2 r1
L_0601B388:
    c.r[1] >>= 2;  // 0601B388 shlr2 r1
L_0601B38A:
    c.r[0] = c.r[1];  // 0601B38A mov r1,r0
L_0601B38C:
    c.t = c.r[0] == 0x1u;  // 0601B38C cmp/eq #1,r0
L_0601B38E:
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_0601B39C; } }  // 0601B38E bt/s 0x0601B39C ; mov r9,r1
L_0601B392:
    c.t = c.r[0] == 0x2u;  // 0601B392 cmp/eq #2,r0
L_0601B394:
    { const bool k = c.t; c.r[1] += 5; if (k) { goto L_0601B470; } }  // 0601B394 bt/s 0x0601B470 ; add #5,r1
L_0601B398:
    goto L_0601B486;  // 0601B398 bra 0x0601B486 ; nop
L_0601B39C:
    c.r[1] += 5;  // 0601B39C add #5,r1
L_0601B39E:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B39E mov.b @r1,r1
L_0601B3A0:
    c.r[10] = c.r[1] & 0xFFu;  // 0601B3A0 extu.b r1,r10
L_0601B3A2:
    c.r[1] = c.r[9];  // 0601B3A2 mov r9,r1
L_0601B3A4:
    c.r[1] += 4;  // 0601B3A4 add #4,r1
L_0601B3A6:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B3A6 mov.b @r1,r1
L_0601B3A8:
    c.r[8] = c.r[1] & 0xFFu;  // 0601B3A8 extu.b r1,r8
L_0601B3AA:
    c.r[1] = c.r[9];  // 0601B3AA mov r9,r1
L_0601B3AC:
    c.r[1] += 8;  // 0601B3AC add #8,r1
L_0601B3AE:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B3AE mov.b @r1,r1
L_0601B3B0:
    c.macl = c.r[10] * c.r[8];  // 0601B3B0 mul.l r8,r10
L_0601B3B2:
    c.r[4] = c.r[1] & 0xFFu;  // 0601B3B2 extu.b r1,r4
L_0601B3B4:
    c.r[1] = c.r[9];  // 0601B3B4 mov r9,r1
L_0601B3B6:
    c.r[1] += 9;  // 0601B3B6 add #9,r1
L_0601B3B8:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B3B8 mov.b @r1,r1
L_0601B3BA:
    c.r[4] <<= 8;  // 0601B3BA shll8 r4
L_0601B3BC:
    c.r[1] = c.r[1] & 0xFFu;  // 0601B3BC extu.b r1,r1
L_0601B3BE:
    c.r[4] |= c.r[1];  // 0601B3BE or r1,r4
L_0601B3C0:
    c.r[1] = ld32(0x0601B43Cu);  // 0601B3C0 mov.l 0x0601B43C,r1
L_0601B3C2:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B3C2 mov.b @r1,r1
L_0601B3C4:
    c.r[10] = c.r[1] & 0xFFu;  // 0601B3C4 extu.b r1,r10
L_0601B3C6:
    c.r[1] = ld32(0x0601B444u);  // 0601B3C6 mov.l 0x0601B444,r1
L_0601B3C8:
    c.r[0] = c.r[10];  // 0601B3C8 mov r10,r0
L_0601B3CA:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601B3CA mov.b @(r0,r1),r1
L_0601B3CC:
    c.r[2] = c.macl;  // 0601B3CC sts macl,r2
L_0601B3CE:
    c.r[1] = c.r[1] & 0xFFu;  // 0601B3CE extu.b r1,r1
L_0601B3D0:
    c.r[1] -= 1;  // 0601B3D0 add #-1,r1
L_0601B3D2:
    c.macl = c.r[2] * c.r[1];  // 0601B3D2 mul.l r1,r2
L_0601B3D4:
    c.r[1] = c.macl;  // 0601B3D4 sts macl,r1
L_0601B3D6:
    c.macl = c.r[2];  // 0601B3D6 lds r2,macl
L_0601B3D8:
    c.r[4] -= c.r[1];  // 0601B3D8 sub r1,r4
L_0601B3DA:
    c.r[1] = c.macl;  // 0601B3DA sts macl,r1
L_0601B3DC:
    c.t = (int32_t)c.r[4] > (int32_t)c.r[1];  // 0601B3DC cmp/gt r1,r4
L_0601B3DE:
    if (!c.t) { goto L_0601B3E2; }  // 0601B3DE bf 0x0601B3E2
L_0601B3E0:
    c.r[4] = c.macl;  // 0601B3E0 sts macl,r4
L_0601B3E2:
    c.r[12] = ld32(0x0601B438u);  // 0601B3E2 mov.l 0x0601B438,r12
L_0601B3E4:
    c.r[0] = c.r[10];  // 0601B3E4 mov r10,r0
L_0601B3E6:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[12]);  // 0601B3E6 mov.b @(r0,r12),r11
L_0601B3E8:
    c.r[6] = c.r[11] & 0xFFu;  // 0601B3E8 extu.b r11,r6
L_0601B3EA:
    c.r[6] += 1;  // 0601B3EA add #1,r6
L_0601B3EC:
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[4];  // 0601B3EC cmp/ge r4,r6
L_0601B3EE:
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_0601B410; } }  // 0601B3EE bt/s 0x0601B410 ; mov r9,r1
L_0601B3F2:
    c.r[4] = c.r[6];  // 0601B3F2 mov r6,r4
L_0601B3F4:
    c.r[7] = ld32(0x0601B440u);  // 0601B3F4 mov.l 0x0601B440,r7
L_0601B3F6:
    { const uint32_t x = c.r[7]; c.pr = 0x0601B3FAu; c.r[5] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601B3FAu) return; }  // 0601B3F6 jsr @r7 ; mov r8,r5
L_0601B3FA:
    c.macl = c.r[0] * c.r[8];  // 0601B3FA mul.l r8,r0
L_0601B3FC:
    c.r[1] = c.macl;  // 0601B3FC sts macl,r1
L_0601B3FE:
    c.r[6] -= c.r[1];  // 0601B3FE sub r1,r6
L_0601B400:
    c.t = (c.r[6] & c.r[6]) == 0;  // 0601B400 tst r6,r6
L_0601B402:
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_0601B410; } }  // 0601B402 bt/s 0x0601B410 ; mov r9,r1
L_0601B406:
    c.r[1] = c.r[11];  // 0601B406 mov r11,r1
L_0601B408:
    c.r[1] += 1;  // 0601B408 add #1,r1
L_0601B40A:
    c.r[0] = c.r[10];  // 0601B40A mov r10,r0
L_0601B40C:
    st8(c.r[0] + c.r[12], c.r[1]); goto L_0601B4B0;  // 0601B40C bra 0x0601B4B0 ; mov.b r1,@(r0,r12)
L_0601B410:
    c.r[1] += 1;  // 0601B410 add #1,r1
L_0601B412:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B412 mov.b @r1,r1
L_0601B414:
    c.r[0] = c.r[1];  // 0601B414 mov r1,r0
L_0601B416:
    c.r[0] >>= 2;  // 0601B416 shlr2 r0
L_0601B418:
    c.r[0] >>= 2;  // 0601B418 shlr2 r0
L_0601B41A:
    c.r[0] >>= 2;  // 0601B41A shlr2 r0
L_0601B41C:
    c.r[0] &= 0x1u;  // 0601B41C and #1,r0
L_0601B41E:
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601B41E tst r0,r0
L_0601B420:
    { const bool k = c.t; c.r[8] -= 1; if (k) { goto L_0601B458; } }  // 0601B420 bt/s 0x0601B458 ; add #-1,r8
L_0601B424:
    c.r[1] = ld32(0x0601B43Cu);  // 0601B424 mov.l 0x0601B43C,r1
L_0601B426:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B426 mov.b @r1,r1
L_0601B428:
    c.r[2] = ld32(0x0601B438u);  // 0601B428 mov.l 0x0601B438,r2
L_0601B42A:
    c.r[0] = c.r[1] & 0xFFu;  // 0601B42A extu.b r1,r0
L_0601B42C:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0601B42C mov.b @(r0,r2),r1
L_0601B42E:
    c.r[1] -= c.r[8];  // 0601B42E sub r8,r1
L_0601B430:
    st8(c.r[0] + c.r[2], c.r[1]); goto L_0601B4B0;  // 0601B430 bra 0x0601B4B0 ; mov.b r1,@(r0,r2)
L_0601B458:
    c.r[1] = ld32(0x0601B564u);  // 0601B458 mov.l 0x0601B564,r1
L_0601B45A:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B45A mov.b @r1,r1
L_0601B45C:
    c.r[0] = c.r[1] & 0xFFu;  // 0601B45C extu.b r1,r0
L_0601B45E:
    c.r[1] = ld32(0x0601B568u);  // 0601B45E mov.l 0x0601B568,r1
L_0601B460:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601B460 mov.b @(r0,r1),r1
L_0601B462:
    c.r[1] = c.r[1] & 0xFFu;  // 0601B462 extu.b r1,r1
L_0601B464:
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601B464 tst r1,r1
L_0601B466:
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_0601B4B2; } }  // 0601B466 bt/s 0x0601B4B2 ; mov r9,r1
L_0601B46A:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601B55Cu);  // 0601B46A mov.w 0x0601B55C,r0
L_0601B46C:
    c.r[15] = c.r[14]; goto L_0601B6D2;  // 0601B46C bra 0x0601B6D2 ; mov r14,r15
L_0601B470:
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B470 mov.b @r1,r3
L_0601B472:
    c.r[2] = c.r[3] & 0xFFu;  // 0601B472 extu.b r3,r2
L_0601B474:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601B55Eu);  // 0601B474 mov.w 0x0601B55E,r1
L_0601B476:
    c.t = c.r[2] == c.r[1];  // 0601B476 cmp/eq r1,r2
L_0601B478:
    if (c.t) { SH2_POLL(c); goto L_0601B46A; }  // 0601B478 bt 0x0601B46A
L_0601B47A:
    c.r[1] = ld32(0x0601B564u);  // 0601B47A mov.l 0x0601B564,r1
L_0601B47C:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B47C mov.b @r1,r1
L_0601B47E:
    c.r[0] = c.r[1] & 0xFFu;  // 0601B47E extu.b r1,r0
L_0601B480:
    c.r[1] = ld32(0x0601B568u);  // 0601B480 mov.l 0x0601B568,r1
L_0601B482:
    st8(c.r[0] + c.r[1], c.r[3]); goto L_0601B4B0;  // 0601B482 bra 0x0601B4B0 ; mov.b r3,@(r0,r1)
L_0601B486:
    c.r[10] = ld32(0x0601B564u);  // 0601B486 mov.l 0x0601B564,r10
L_0601B488:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0601B488 mov.b @r10,r1
L_0601B48A:
    c.r[11] = ld32(0x0601B568u);  // 0601B48A mov.l 0x0601B568,r11
L_0601B48C:
    c.r[0] = c.r[1] & 0xFFu;  // 0601B48C extu.b r1,r0
L_0601B48E:
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 0601B48E mov.b @(r0,r11),r8
L_0601B490:
    c.r[1] = ld32(0x0601B56Cu);  // 0601B490 mov.l 0x0601B56C,r1
L_0601B492:
    c.r[4] = ld32(c.r[1]);  // 0601B492 mov.l @r1,r4
L_0601B494:
    c.r[0] = ld32(0x0601B570u);  // 0601B494 mov.l 0x0601B570,r0
L_0601B496:
    { const uint32_t x = c.r[0]; c.pr = 0x0601B49Au; c.r[8] = c.r[8] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601B49Au) return; }  // 0601B496 jsr @r0 ; extu.b r8,r8
L_0601B49A:
    c.r[0] -= 1;  // 0601B49A add #-1,r0
L_0601B49C:
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[0];  // 0601B49C cmp/ge r0,r8
L_0601B49E:
    { const bool k = c.t; c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]); if (k) { goto L_0601B4AA; } }  // 0601B49E bt/s 0x0601B4AA ; mov.b @r10,r1
L_0601B4A2:
    c.r[0] = c.r[1] & 0xFFu;  // 0601B4A2 extu.b r1,r0
L_0601B4A4:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 0601B4A4 mov.b @(r0,r11),r1
L_0601B4A6:
    c.r[1] += 1; goto L_0601B4AE;  // 0601B4A6 bra 0x0601B4AE ; add #1,r1
L_0601B4AA:
    c.r[0] = c.r[1] & 0xFFu;  // 0601B4AA extu.b r1,r0
L_0601B4AC:
    c.r[1] = 0x0u;  // 0601B4AC mov #0,r1
L_0601B4AE:
    st8(c.r[0] + c.r[11], c.r[1]);  // 0601B4AE mov.b r1,@(r0,r11)
L_0601B4B0:
    c.r[1] = c.r[9];  // 0601B4B0 mov r9,r1
L_0601B4B2:
    c.r[1] += 1;  // 0601B4B2 add #1,r1
L_0601B4B4:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B4B4 mov.b @r1,r1
L_0601B4B6:
    c.r[0] = c.r[1];  // 0601B4B6 mov r1,r0
L_0601B4B8:
    c.r[0] >>= 2;  // 0601B4B8 shlr2 r0
L_0601B4BA:
    c.r[0] >>= 2;  // 0601B4BA shlr2 r0
L_0601B4BC:
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0601B4BC shlr r0
L_0601B4BE:
    c.r[0] >>= 2;  // 0601B4BE shlr2 r0
L_0601B4C0:
    c.r[0] &= 0x1u;  // 0601B4C0 and #1,r0
L_0601B4C2:
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601B4C2 tst r0,r0
L_0601B4C4:
    if (!c.t) { SH2_POLL(c); goto L_0601B46A; }  // 0601B4C4 bf 0x0601B46A
L_0601B4C6:
    c.r[1] = ld32(0x0601B574u);  // 0601B4C6 mov.l 0x0601B574,r1
L_0601B4C8:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0601B4C8 mov.w @r1,r1
L_0601B4CA:
    c.r[2] = (uint32_t)(int16_t)ld16(0x0601B560u);  // 0601B4CA mov.w 0x0601B560,r2
L_0601B4CC:
    c.r[2] &= c.r[1];  // 0601B4CC and r1,r2
L_0601B4CE:
    c.t = (c.r[2] & c.r[2]) == 0;  // 0601B4CE tst r2,r2
L_0601B4D0:
    if (!c.t) { goto L_0601B4D6; }  // 0601B4D0 bf 0x0601B4D6
L_0601B4D2:
    goto L_0601B5E2;  // 0601B4D2 bra 0x0601B5E2 ; nop
L_0601B4D6:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0601B4D6 mov.b @r9,r1
L_0601B4D8:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601B562u);  // 0601B4D8 mov.w 0x0601B562,r0
L_0601B4DA:
    c.r[1] &= c.r[0];  // 0601B4DA and r0,r1
L_0601B4DC:
    c.r[1] >>= 2;  // 0601B4DC shlr2 r1
L_0601B4DE:
    c.r[1] >>= 2;  // 0601B4DE shlr2 r1
L_0601B4E0:
    c.r[1] >>= 2;  // 0601B4E0 shlr2 r1
L_0601B4E2:
    c.r[0] = c.r[1];  // 0601B4E2 mov r1,r0
L_0601B4E4:
    c.t = c.r[0] == 0x1u;  // 0601B4E4 cmp/eq #1,r0
L_0601B4E6:
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_0601B4F4; } }  // 0601B4E6 bt/s 0x0601B4F4 ; mov r9,r1
L_0601B4EA:
    c.t = c.r[0] == 0x2u;  // 0601B4EA cmp/eq #2,r0
L_0601B4EC:
    { const bool k = c.t; c.r[1] += 6; if (k) { goto L_0601B5B0; } }  // 0601B4EC bt/s 0x0601B5B0 ; add #6,r1
L_0601B4F0:
    c.r[1] = c.r[9]; goto L_0601B5CA;  // 0601B4F0 bra 0x0601B5CA ; mov r9,r1
L_0601B4F4:
    c.r[1] += 5;  // 0601B4F4 add #5,r1
L_0601B4F6:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B4F6 mov.b @r1,r1
L_0601B4F8:
    c.r[10] = c.r[1] & 0xFFu;  // 0601B4F8 extu.b r1,r10
L_0601B4FA:
    c.r[1] = c.r[9];  // 0601B4FA mov r9,r1
L_0601B4FC:
    c.r[1] += 4;  // 0601B4FC add #4,r1
L_0601B4FE:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B4FE mov.b @r1,r1
L_0601B500:
    c.r[8] = c.r[1] & 0xFFu;  // 0601B500 extu.b r1,r8
L_0601B502:
    c.r[1] = ld32(0x0601B564u);  // 0601B502 mov.l 0x0601B564,r1
L_0601B504:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B504 mov.b @r1,r1
L_0601B506:
    c.r[3] = ld32(0x0601B568u);  // 0601B506 mov.l 0x0601B568,r3
L_0601B508:
    c.r[2] = c.r[1] & 0xFFu;  // 0601B508 extu.b r1,r2
L_0601B50A:
    c.r[0] = c.r[2];  // 0601B50A mov r2,r0
L_0601B50C:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0601B50C mov.b @(r0,r3),r1
L_0601B50E:
    c.r[7] = c.r[1] & 0xFFu;  // 0601B50E extu.b r1,r7
L_0601B510:
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[8];  // 0601B510 cmp/ge r8,r7
L_0601B512:
    { const bool k = !c.t; c.r[1] -= c.r[8]; if (k) { goto L_0601B51A; } }  // 0601B512 bf/s 0x0601B51A ; sub r8,r1
L_0601B516:
    st8(c.r[0] + c.r[3], c.r[1]); goto L_0601B5C8;  // 0601B516 bra 0x0601B5C8 ; mov.b r1,@(r0,r3)
L_0601B51A:
    c.r[1] = c.r[9];  // 0601B51A mov r9,r1
L_0601B51C:
    c.r[1] += 1;  // 0601B51C add #1,r1
L_0601B51E:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B51E mov.b @r1,r1
L_0601B520:
    c.r[0] = c.r[1];  // 0601B520 mov r1,r0
L_0601B522:
    c.r[0] >>= 2;  // 0601B522 shlr2 r0
L_0601B524:
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0601B524 shlr r0
L_0601B526:
    c.r[0] >>= 2;  // 0601B526 shlr2 r0
L_0601B528:
    c.r[0] &= 0x1u;  // 0601B528 and #1,r0
L_0601B52A:
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601B52A tst r0,r0
L_0601B52C:
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { SH2_POLL(c); goto L_0601B46A; } }  // 0601B52C bt/s 0x0601B46A ; mov r9,r1
L_0601B530:
    c.r[1] += 8;  // 0601B530 add #8,r1
L_0601B532:
    c.r[0] = c.r[2];  // 0601B532 mov r2,r0
L_0601B534:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B534 mov.b @r1,r1
L_0601B536:
    c.macl = c.r[10] * c.r[8];  // 0601B536 mul.l r8,r10
L_0601B538:
    c.r[3] = c.r[1] & 0xFFu;  // 0601B538 extu.b r1,r3
L_0601B53A:
    c.r[1] = c.r[9];  // 0601B53A mov r9,r1
L_0601B53C:
    c.r[1] += 9;  // 0601B53C add #9,r1
L_0601B53E:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B53E mov.b @r1,r1
L_0601B540:
    c.r[3] <<= 8;  // 0601B540 shll8 r3
L_0601B542:
    c.r[1] = c.r[1] & 0xFFu;  // 0601B542 extu.b r1,r1
L_0601B544:
    c.r[3] |= c.r[1];  // 0601B544 or r1,r3
L_0601B546:
    c.r[1] = ld32(0x0601B578u);  // 0601B546 mov.l 0x0601B578,r1
L_0601B548:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601B548 mov.b @(r0,r1),r1
L_0601B54A:
    c.r[4] = c.macl;  // 0601B54A sts macl,r4
L_0601B54C:
    c.r[1] = c.r[1] & 0xFFu;  // 0601B54C extu.b r1,r1
L_0601B54E:
    c.r[1] -= 1;  // 0601B54E add #-1,r1
L_0601B550:
    c.macl = c.r[1] * c.r[10];  // 0601B550 mul.l r10,r1
L_0601B552:
    c.r[4] -= c.r[8];  // 0601B552 sub r8,r4
L_0601B554:
    c.r[1] = c.macl;  // 0601B554 sts macl,r1
L_0601B556:
    c.macl = c.r[1] * c.r[8];  // 0601B556 mul.l r8,r1
L_0601B558:
    c.r[4] += c.r[7]; goto L_0601B596;  // 0601B558 bra 0x0601B596 ; add r7,r4
L_0601B57C:
    c.r[1] = ld32(0x0601B6ECu);  // 0601B57C mov.l 0x0601B6EC,r1
L_0601B57E:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601B57E mov.b @(r0,r1),r1
L_0601B580:
    c.r[1] = c.r[1] & 0xFFu;  // 0601B580 extu.b r1,r1
L_0601B582:
    c.t = (int32_t)c.r[4] > (int32_t)c.r[1];  // 0601B582 cmp/gt r1,r4
L_0601B584:
    if (!c.t) { goto L_0601B5A4; }  // 0601B584 bf 0x0601B5A4
L_0601B586:
    c.r[4] -= c.r[8];  // 0601B586 sub r8,r4
L_0601B588:
    c.r[1] = ld32(0x0601B6F0u);  // 0601B588 mov.l 0x0601B6F0,r1
L_0601B58A:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601B58A mov.b @(r0,r1),r1
L_0601B58C:
    c.r[1] = c.r[1] & 0xFFu;  // 0601B58C extu.b r1,r1
L_0601B58E:
    c.r[1] -= 1;  // 0601B58E add #-1,r1
L_0601B590:
    c.macl = c.r[1] * c.r[10];  // 0601B590 mul.l r10,r1
L_0601B592:
    c.r[1] = c.macl;  // 0601B592 sts macl,r1
L_0601B594:
    c.macl = c.r[1] * c.r[8];  // 0601B594 mul.l r8,r1
L_0601B596:
    c.r[0] = c.r[3];  // 0601B596 mov r3,r0
L_0601B598:
    c.r[1] = c.macl;  // 0601B598 sts macl,r1
L_0601B59A:
    c.r[0] -= c.r[1];  // 0601B59A sub r1,r0
L_0601B59C:
    c.r[1] = c.r[0];  // 0601B59C mov r0,r1
L_0601B59E:
    c.t = (int32_t)c.r[1] > (int32_t)c.r[4];  // 0601B59E cmp/gt r4,r1
L_0601B5A0:
    { const bool k = !c.t; c.r[0] = c.r[2]; if (k) { SH2_POLL(c); goto L_0601B57C; } }  // 0601B5A0 bf/s 0x0601B57C ; mov r2,r0
L_0601B5A4:
    c.r[1] = ld32(0x0601B6F4u);  // 0601B5A4 mov.l 0x0601B6F4,r1
L_0601B5A6:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B5A6 mov.b @r1,r1
L_0601B5A8:
    c.r[0] = c.r[1] & 0xFFu;  // 0601B5A8 extu.b r1,r0
L_0601B5AA:
    c.r[1] = ld32(0x0601B6ECu);  // 0601B5AA mov.l 0x0601B6EC,r1
L_0601B5AC:
    st8(c.r[0] + c.r[1], c.r[4]); goto L_0601B5C8;  // 0601B5AC bra 0x0601B5C8 ; mov.b r4,@(r0,r1)
L_0601B5B0:
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B5B0 mov.b @r1,r3
L_0601B5B2:
    c.r[2] = c.r[3] & 0xFFu;  // 0601B5B2 extu.b r3,r2
L_0601B5B4:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601B6E4u);  // 0601B5B4 mov.w 0x0601B6E4,r1
L_0601B5B6:
    c.t = c.r[2] == c.r[1];  // 0601B5B6 cmp/eq r1,r2
L_0601B5B8:
    if (!c.t) { goto L_0601B5BE; }  // 0601B5B8 bf 0x0601B5BE
L_0601B5BA:
    SH2_POLL(c); goto L_0601B46A;  // 0601B5BA bra 0x0601B46A ; nop
L_0601B5BE:
    c.r[1] = ld32(0x0601B6F4u);  // 0601B5BE mov.l 0x0601B6F4,r1
L_0601B5C0:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B5C0 mov.b @r1,r1
L_0601B5C2:
    c.r[0] = c.r[1] & 0xFFu;  // 0601B5C2 extu.b r1,r0
L_0601B5C4:
    c.r[1] = ld32(0x0601B6ECu);  // 0601B5C4 mov.l 0x0601B6EC,r1
L_0601B5C6:
    st8(c.r[0] + c.r[1], c.r[3]);  // 0601B5C6 mov.b r3,@(r0,r1)
L_0601B5C8:
    c.r[1] = c.r[9];  // 0601B5C8 mov r9,r1
L_0601B5CA:
    c.r[1] += 1;  // 0601B5CA add #1,r1
L_0601B5CC:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B5CC mov.b @r1,r1
L_0601B5CE:
    c.r[0] = c.r[1];  // 0601B5CE mov r1,r0
L_0601B5D0:
    c.r[0] >>= 2;  // 0601B5D0 shlr2 r0
L_0601B5D2:
    c.r[0] >>= 2;  // 0601B5D2 shlr2 r0
L_0601B5D4:
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0601B5D4 shlr r0
L_0601B5D6:
    c.r[0] >>= 2;  // 0601B5D6 shlr2 r0
L_0601B5D8:
    c.r[0] &= 0x1u;  // 0601B5D8 and #1,r0
L_0601B5DA:
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601B5DA tst r0,r0
L_0601B5DC:
    if (c.t) { goto L_0601B5E2; }  // 0601B5DC bt 0x0601B5E2
L_0601B5DE:
    SH2_POLL(c); goto L_0601B46A;  // 0601B5DE bra 0x0601B46A ; nop
L_0601B5E2:
    c.r[1] = ld32(0x0601B6F8u);  // 0601B5E2 mov.l 0x0601B6F8,r1
L_0601B5E4:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0601B5E4 mov.w @r1,r1
L_0601B5E6:
    c.r[2] = (uint32_t)(int16_t)ld16(0x0601B6E6u);  // 0601B5E6 mov.w 0x0601B6E6,r2
L_0601B5E8:
    c.r[2] &= c.r[1];  // 0601B5E8 and r1,r2
L_0601B5EA:
    c.t = (c.r[2] & c.r[2]) == 0;  // 0601B5EA tst r2,r2
L_0601B5EC:
    if (c.t) { goto L_0601B6C8; }  // 0601B5EC bt 0x0601B6C8
L_0601B5EE:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0601B5EE mov.b @r9,r1
L_0601B5F0:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601B6E8u);  // 0601B5F0 mov.w 0x0601B6E8,r0
L_0601B5F2:
    c.r[1] &= c.r[0];  // 0601B5F2 and r0,r1
L_0601B5F4:
    c.r[1] >>= 2;  // 0601B5F4 shlr2 r1
L_0601B5F6:
    c.r[1] >>= 2;  // 0601B5F6 shlr2 r1
L_0601B5F8:
    c.r[1] >>= 2;  // 0601B5F8 shlr2 r1
L_0601B5FA:
    c.r[0] = c.r[1];  // 0601B5FA mov r1,r0
L_0601B5FC:
    c.t = c.r[0] == 0x1u;  // 0601B5FC cmp/eq #1,r0
L_0601B5FE:
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_0601B60C; } }  // 0601B5FE bt/s 0x0601B60C ; mov r9,r1
L_0601B602:
    c.t = c.r[0] == 0x2u;  // 0601B602 cmp/eq #2,r0
L_0601B604:
    { const bool k = c.t; c.r[1] += 7; if (k) { goto L_0601B696; } }  // 0601B604 bt/s 0x0601B696 ; add #7,r1
L_0601B608:
    c.r[1] = c.r[9]; goto L_0601B6B0;  // 0601B608 bra 0x0601B6B0 ; mov r9,r1
L_0601B60C:
    c.r[1] += 5;  // 0601B60C add #5,r1
L_0601B60E:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B60E mov.b @r1,r1
L_0601B610:
    c.r[10] = c.r[1] & 0xFFu;  // 0601B610 extu.b r1,r10
L_0601B612:
    c.r[1] = c.r[9];  // 0601B612 mov r9,r1
L_0601B614:
    c.r[1] += 4;  // 0601B614 add #4,r1
L_0601B616:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B616 mov.b @r1,r1
L_0601B618:
    c.r[8] = c.r[1] & 0xFFu;  // 0601B618 extu.b r1,r8
L_0601B61A:
    c.r[1] = c.r[9];  // 0601B61A mov r9,r1
L_0601B61C:
    c.r[1] += 8;  // 0601B61C add #8,r1
L_0601B61E:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B61E mov.b @r1,r1
L_0601B620:
    c.macl = c.r[10] * c.r[8];  // 0601B620 mul.l r8,r10
L_0601B622:
    c.r[4] = c.r[1] & 0xFFu;  // 0601B622 extu.b r1,r4
L_0601B624:
    c.r[1] = c.r[9];  // 0601B624 mov r9,r1
L_0601B626:
    c.r[1] += 9;  // 0601B626 add #9,r1
L_0601B628:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B628 mov.b @r1,r1
L_0601B62A:
    c.r[4] <<= 8;  // 0601B62A shll8 r4
L_0601B62C:
    c.r[1] = c.r[1] & 0xFFu;  // 0601B62C extu.b r1,r1
L_0601B62E:
    c.r[4] |= c.r[1];  // 0601B62E or r1,r4
L_0601B630:
    c.r[1] = ld32(0x0601B6F4u);  // 0601B630 mov.l 0x0601B6F4,r1
L_0601B632:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B632 mov.b @r1,r1
L_0601B634:
    c.r[10] = c.r[1] & 0xFFu;  // 0601B634 extu.b r1,r10
L_0601B636:
    c.r[1] = ld32(0x0601B6F0u);  // 0601B636 mov.l 0x0601B6F0,r1
L_0601B638:
    c.r[0] = c.r[10];  // 0601B638 mov r10,r0
L_0601B63A:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601B63A mov.b @(r0,r1),r1
L_0601B63C:
    c.r[2] = c.macl;  // 0601B63C sts macl,r2
L_0601B63E:
    c.r[1] = c.r[1] & 0xFFu;  // 0601B63E extu.b r1,r1
L_0601B640:
    c.r[1] -= 1;  // 0601B640 add #-1,r1
L_0601B642:
    c.macl = c.r[2] * c.r[1];  // 0601B642 mul.l r1,r2
L_0601B644:
    c.r[1] = c.macl;  // 0601B644 sts macl,r1
L_0601B646:
    c.macl = c.r[2];  // 0601B646 lds r2,macl
L_0601B648:
    c.r[4] -= c.r[1];  // 0601B648 sub r1,r4
L_0601B64A:
    c.r[1] = c.macl;  // 0601B64A sts macl,r1
L_0601B64C:
    c.t = (int32_t)c.r[4] > (int32_t)c.r[1];  // 0601B64C cmp/gt r1,r4
L_0601B64E:
    if (!c.t) { goto L_0601B652; }  // 0601B64E bf 0x0601B652
L_0601B650:
    c.r[4] = c.macl;  // 0601B650 sts macl,r4
L_0601B652:
    c.r[11] = ld32(0x0601B6ECu);  // 0601B652 mov.l 0x0601B6EC,r11
L_0601B654:
    c.r[0] = c.r[10];  // 0601B654 mov r10,r0
L_0601B656:
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 0601B656 mov.b @(r0,r11),r2
L_0601B658:
    c.r[6] = c.r[2] & 0xFFu;  // 0601B658 extu.b r2,r6
L_0601B65A:
    c.r[1] = c.r[6];  // 0601B65A mov r6,r1
L_0601B65C:
    c.r[1] += c.r[8];  // 0601B65C add r8,r1
L_0601B65E:
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[4];  // 0601B65E cmp/ge r4,r1
L_0601B660:
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_0601B66A; } }  // 0601B660 bt/s 0x0601B66A ; mov r9,r1
L_0601B664:
    c.r[8] += c.r[2];  // 0601B664 add r2,r8
L_0601B666:
    st8(c.r[0] + c.r[11], c.r[8]); goto L_0601B6B0;  // 0601B666 bra 0x0601B6B0 ; mov.b r8,@(r0,r11)
L_0601B66A:
    c.r[1] += 1;  // 0601B66A add #1,r1
L_0601B66C:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B66C mov.b @r1,r1
L_0601B66E:
    c.r[0] = c.r[1];  // 0601B66E mov r1,r0
L_0601B670:
    c.r[0] >>= 2;  // 0601B670 shlr2 r0
L_0601B672:
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0601B672 shlr r0
L_0601B674:
    c.r[0] >>= 2;  // 0601B674 shlr2 r0
L_0601B676:
    c.r[0] &= 0x1u;  // 0601B676 and #1,r0
L_0601B678:
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601B678 tst r0,r0
L_0601B67A:
    { const bool k = !c.t; c.r[4] = c.r[6]; if (k) { goto L_0601B682; } }  // 0601B67A bf/s 0x0601B682 ; mov r6,r4
L_0601B67E:
    SH2_POLL(c); goto L_0601B46A;  // 0601B67E bra 0x0601B46A ; nop
L_0601B682:
    c.r[7] = ld32(0x0601B6FCu);  // 0601B682 mov.l 0x0601B6FC,r7
L_0601B684:
    { const uint32_t x = c.r[7]; c.pr = 0x0601B688u; c.r[5] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601B688u) return; }  // 0601B684 jsr @r7 ; mov r8,r5
L_0601B688:
    c.r[7] = c.r[0];  // 0601B688 mov r0,r7
L_0601B68A:
    c.macl = c.r[7] * c.r[8];  // 0601B68A mul.l r8,r7
L_0601B68C:
    c.r[0] = c.r[10];  // 0601B68C mov r10,r0
L_0601B68E:
    c.r[1] = c.macl;  // 0601B68E sts macl,r1
L_0601B690:
    c.r[6] -= c.r[1];  // 0601B690 sub r1,r6
L_0601B692:
    st8(c.r[0] + c.r[11], c.r[6]); goto L_0601B6AE;  // 0601B692 bra 0x0601B6AE ; mov.b r6,@(r0,r11)
L_0601B696:
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B696 mov.b @r1,r3
L_0601B698:
    c.r[2] = c.r[3] & 0xFFu;  // 0601B698 extu.b r3,r2
L_0601B69A:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601B6E4u);  // 0601B69A mov.w 0x0601B6E4,r1
L_0601B69C:
    c.t = c.r[2] == c.r[1];  // 0601B69C cmp/eq r1,r2
L_0601B69E:
    if (!c.t) { goto L_0601B6A4; }  // 0601B69E bf 0x0601B6A4
L_0601B6A0:
    SH2_POLL(c); goto L_0601B46A;  // 0601B6A0 bra 0x0601B46A ; nop
L_0601B6A4:
    c.r[1] = ld32(0x0601B6F4u);  // 0601B6A4 mov.l 0x0601B6F4,r1
L_0601B6A6:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B6A6 mov.b @r1,r1
L_0601B6A8:
    c.r[0] = c.r[1] & 0xFFu;  // 0601B6A8 extu.b r1,r0
L_0601B6AA:
    c.r[1] = ld32(0x0601B6ECu);  // 0601B6AA mov.l 0x0601B6EC,r1
L_0601B6AC:
    st8(c.r[0] + c.r[1], c.r[3]);  // 0601B6AC mov.b r3,@(r0,r1)
L_0601B6AE:
    c.r[1] = c.r[9];  // 0601B6AE mov r9,r1
L_0601B6B0:
    c.r[1] += 1;  // 0601B6B0 add #1,r1
L_0601B6B2:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B6B2 mov.b @r1,r1
L_0601B6B4:
    c.r[0] = c.r[1];  // 0601B6B4 mov r1,r0
L_0601B6B6:
    c.r[0] >>= 2;  // 0601B6B6 shlr2 r0
L_0601B6B8:
    c.r[0] >>= 2;  // 0601B6B8 shlr2 r0
L_0601B6BA:
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0601B6BA shlr r0
L_0601B6BC:
    c.r[0] >>= 2;  // 0601B6BC shlr2 r0
L_0601B6BE:
    c.r[0] &= 0x1u;  // 0601B6BE and #1,r0
L_0601B6C0:
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601B6C0 tst r0,r0
L_0601B6C2:
    if (c.t) { goto L_0601B6C8; }  // 0601B6C2 bt 0x0601B6C8
L_0601B6C4:
    SH2_POLL(c); goto L_0601B46A;  // 0601B6C4 bra 0x0601B46A ; nop
L_0601B6C8:
    c.r[1] = ld32(0x0601B700u);  // 0601B6C8 mov.l 0x0601B700,r1
L_0601B6CA:
    { const uint32_t x = c.r[1]; c.pr = 0x0601B6CEu; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601B6CEu) return; }  // 0601B6CA jsr @r1 ; mov r9,r4
L_0601B6CE:
    c.r[0] = 0x0u;  // 0601B6CE mov #0,r0
L_0601B6D0:
    c.r[15] = c.r[14];  // 0601B6D0 mov r14,r15
L_0601B6D2:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601B6D2 lds.l @r15+,pr
L_0601B6D4:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601B6D4 mov.l @r15+,r14
L_0601B6D6:
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0601B6D6 mov.l @r15+,r13
L_0601B6D8:
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0601B6D8 mov.l @r15+,r12
L_0601B6DA:
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0601B6DA mov.l @r15+,r11
L_0601B6DC:
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0601B6DC mov.l @r15+,r10
L_0601B6DE:
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0601B6DE mov.l @r15+,r9
L_0601B6E0:
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601B6E0 rts ; mov.l @r15+,r8
L_0607ECBE:
    c.r[1] = ld32(0x0607ED58u);  // 0607ECBE mov.l 0x0607ED58,r1
L_0607ECC0:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607ECC0 mov.b @r1,r0
L_0607ECC2:
    c.t = (c.r[0] & 0x80u) == 0;  // 0607ECC2 tst #128,r0
L_0607ECC4:
    if (!c.t) { goto L_0607ECD2; }  // 0607ECC4 bf 0x0607ECD2
L_0607ECC6:
    c.r[1] = ld32(0x0607ED5Cu);  // 0607ECC6 mov.l 0x0607ED5C,r1
L_0607ECC8:
    c.r[0] = 0x0u;  // 0607ECC8 mov #0,r0
L_0607ECCA:
    st8(c.r[1], c.r[0]);  // 0607ECCA mov.b r0,@r1
L_0607ECCC:
    c.r[1] = ld32(0x0607ED60u);  // 0607ECCC mov.l 0x0607ED60,r1
L_0607ECCE:
    c.r[0] = 0x10u;  // 0607ECCE mov #16,r0
L_0607ECD0:
    st16(c.r[1], c.r[0]);  // 0607ECD0 mov.w r0,@r1
L_0607ECD2:
    c.pr = 0x0607ECD6u; SH2_POLL(c); sh2_call(c, 0x0607ECEEu); if (c.pc != 0x0607ECD6u) return;  // 0607ECD2 bsr 0x0607ECEE ; nop
L_0607ECD6:
    c.r[6] = ld32(0x0607ED38u);  // 0607ECD6 mov.l 0x0607ED38,r6
L_0607ECD8:
    c.r[7] = ld32(c.r[6]);  // 0607ECD8 mov.l @r6,r7
L_0607ECDA:
    c.r[7] -= 14;  // 0607ECDA add #-14,r7
L_0607ECDC:
    st32(c.r[6], c.r[7]);  // 0607ECDC mov.l r7,@r6
L_0607ECDE:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607ED6Au);  // 0607ECDE mov.w 0x0607ED6A,r0
L_0607ECE0:
    goto L_0607EE54;  // 0607ECE0 bra 0x0607EE54 ; nop
L_0607ECE4:
    c.pr = 0x0607ECE8u; SH2_POLL(c); sh2_call(c, 0x0607ECEEu); if (c.pc != 0x0607ECE8u) return;  // 0607ECE4 bsr 0x0607ECEE ; nop
L_0607ECE8:
    c.r[0] = ld32(0x0607ED64u);  // 0607ECE8 mov.l 0x0607ED64,r0
L_0607ECEA:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x0601B124u: goto L_0601B124; case 0x0601B126u: goto L_0601B126; case 0x0601B128u: goto L_0601B128; case 0x0601B12Au: goto L_0601B12A; case 0x0601B12Cu: goto L_0601B12C; case 0x0601B12Eu: goto L_0601B12E; case 0x0601B130u: goto L_0601B130; case 0x0601B132u: goto L_0601B132; case 0x0601B134u: goto L_0601B134; case 0x0601B136u: goto L_0601B136; case 0x0601B138u: goto L_0601B138; case 0x0601B13Au: goto L_0601B13A; case 0x0601B13Eu: goto L_0601B13E; case 0x0601B140u: goto L_0601B140; case 0x0601B144u: goto L_0601B144; case 0x0601B146u: goto L_0601B146; case 0x0601B148u: goto L_0601B148; case 0x0601B14Au: goto L_0601B14A; case 0x0601B14Cu: goto L_0601B14C; case 0x0601B14Eu: goto L_0601B14E; case 0x0601B150u: goto L_0601B150; case 0x0601B152u: goto L_0601B152; case 0x0601B156u: goto L_0601B156; case 0x0601B158u: goto L_0601B158; case 0x0601B15Au: goto L_0601B15A; case 0x0601B15Cu: goto L_0601B15C; case 0x0601B15Eu: goto L_0601B15E; case 0x0601B162u: goto L_0601B162; case 0x0601B164u: goto L_0601B164; case 0x0601B166u: goto L_0601B166; case 0x0601B168u: goto L_0601B168; case 0x0601B16Au: goto L_0601B16A; case 0x0601B16Cu: goto L_0601B16C; case 0x0601B16Eu: goto L_0601B16E; case 0x0601B170u: goto L_0601B170; case 0x0601B172u: goto L_0601B172; case 0x0601B176u: goto L_0601B176; case 0x0601B178u: goto L_0601B178; case 0x0601B17Au: goto L_0601B17A; case 0x0601B17Cu: goto L_0601B17C; case 0x0601B17Eu: goto L_0601B17E; case 0x0601B180u: goto L_0601B180; case 0x0601B182u: goto L_0601B182; case 0x0601B184u: goto L_0601B184; case 0x0601B188u: goto L_0601B188; case 0x0601B18Au: goto L_0601B18A; case 0x0601B18Cu: goto L_0601B18C; case 0x0601B190u: goto L_0601B190; case 0x0601B194u: goto L_0601B194; case 0x0601B196u: goto L_0601B196; case 0x0601B198u: goto L_0601B198; case 0x0601B19Au: goto L_0601B19A; case 0x0601B19Cu: goto L_0601B19C; case 0x0601B19Eu: goto L_0601B19E; case 0x0601B1A0u: goto L_0601B1A0; case 0x0601B1A2u: goto L_0601B1A2; case 0x0601B1A4u: goto L_0601B1A4; case 0x0601B1A6u: goto L_0601B1A6; case 0x0601B1A8u: goto L_0601B1A8; case 0x0601B1AAu: goto L_0601B1AA; case 0x0601B1ACu: goto L_0601B1AC; case 0x0601B1B0u: goto L_0601B1B0; case 0x0601B1B2u: goto L_0601B1B2; case 0x0601B1B4u: goto L_0601B1B4; case 0x0601B1B6u: goto L_0601B1B6; case 0x0601B1B8u: goto L_0601B1B8; case 0x0601B1BAu: goto L_0601B1BA; case 0x0601B1BCu: goto L_0601B1BC; case 0x0601B1BEu: goto L_0601B1BE; case 0x0601B1C0u: goto L_0601B1C0; case 0x0601B1C2u: goto L_0601B1C2; case 0x0601B1C4u: goto L_0601B1C4; case 0x0601B1C8u: goto L_0601B1C8; case 0x0601B1CAu: goto L_0601B1CA; case 0x0601B1CCu: goto L_0601B1CC; case 0x0601B1CEu: goto L_0601B1CE; case 0x0601B1D0u: goto L_0601B1D0; case 0x0601B1D2u: goto L_0601B1D2; case 0x0601B1D4u: goto L_0601B1D4; case 0x0601B1D6u: goto L_0601B1D6; case 0x0601B1D8u: goto L_0601B1D8; case 0x0601B1DAu: goto L_0601B1DA; case 0x0601B1DCu: goto L_0601B1DC; case 0x0601B1DEu: goto L_0601B1DE; case 0x0601B1E0u: goto L_0601B1E0; case 0x0601B1E2u: goto L_0601B1E2; case 0x0601B1E4u: goto L_0601B1E4; case 0x0601B1E6u: goto L_0601B1E6; case 0x0601B1E8u: goto L_0601B1E8; case 0x0601B1EAu: goto L_0601B1EA; case 0x0601B1ECu: goto L_0601B1EC; case 0x0601B1EEu: goto L_0601B1EE; case 0x0601B1F0u: goto L_0601B1F0; case 0x0601B1F2u: goto L_0601B1F2; case 0x0601B1F4u: goto L_0601B1F4; case 0x0601B1F6u: goto L_0601B1F6; case 0x0601B1F8u: goto L_0601B1F8; case 0x0601B1FAu: goto L_0601B1FA; case 0x0601B1FCu: goto L_0601B1FC; case 0x0601B1FEu: goto L_0601B1FE; case 0x0601B200u: goto L_0601B200; case 0x0601B202u: goto L_0601B202; case 0x0601B204u: goto L_0601B204; case 0x0601B206u: goto L_0601B206; case 0x0601B208u: goto L_0601B208; case 0x0601B20Au: goto L_0601B20A; case 0x0601B20Cu: goto L_0601B20C; case 0x0601B20Eu: goto L_0601B20E; case 0x0601B210u: goto L_0601B210; case 0x0601B214u: goto L_0601B214; case 0x0601B216u: goto L_0601B216; case 0x0601B218u: goto L_0601B218; case 0x0601B21Au: goto L_0601B21A; case 0x0601B21Cu: goto L_0601B21C; case 0x0601B21Eu: goto L_0601B21E; case 0x0601B220u: goto L_0601B220; case 0x0601B222u: goto L_0601B222; case 0x0601B224u: goto L_0601B224; case 0x0601B228u: goto L_0601B228; case 0x0601B22Au: goto L_0601B22A; case 0x0601B22Eu: goto L_0601B22E; case 0x0601B260u: goto L_0601B260; case 0x0601B262u: goto L_0601B262; case 0x0601B264u: goto L_0601B264; case 0x0601B266u: goto L_0601B266; case 0x0601B268u: goto L_0601B268; case 0x0601B26Au: goto L_0601B26A; case 0x0601B26Cu: goto L_0601B26C; case 0x0601B26Eu: goto L_0601B26E; case 0x0601B270u: goto L_0601B270; case 0x0601B272u: goto L_0601B272; case 0x0601B274u: goto L_0601B274; case 0x0601B276u: goto L_0601B276; case 0x0601B278u: goto L_0601B278; case 0x0601B27Au: goto L_0601B27A; case 0x0601B27Cu: goto L_0601B27C; case 0x0601B27Eu: goto L_0601B27E; case 0x0601B280u: goto L_0601B280; case 0x0601B284u: goto L_0601B284; case 0x0601B286u: goto L_0601B286; case 0x0601B288u: goto L_0601B288; case 0x0601B28Au: goto L_0601B28A; case 0x0601B28Cu: goto L_0601B28C; case 0x0601B28Eu: goto L_0601B28E; case 0x0601B290u: goto L_0601B290; case 0x0601B292u: goto L_0601B292; case 0x0601B296u: goto L_0601B296; case 0x0601B298u: goto L_0601B298; case 0x0601B29Au: goto L_0601B29A; case 0x0601B29Eu: goto L_0601B29E; case 0x0601B2A0u: goto L_0601B2A0; case 0x0601B2A2u: goto L_0601B2A2; case 0x0601B2A4u: goto L_0601B2A4; case 0x0601B2A6u: goto L_0601B2A6; case 0x0601B2A8u: goto L_0601B2A8; case 0x0601B2AAu: goto L_0601B2AA; case 0x0601B2ACu: goto L_0601B2AC; case 0x0601B2AEu: goto L_0601B2AE; case 0x0601B2B0u: goto L_0601B2B0; case 0x0601B2B4u: goto L_0601B2B4; case 0x0601B2B8u: goto L_0601B2B8; case 0x0601B2BAu: goto L_0601B2BA; case 0x0601B2BCu: goto L_0601B2BC; case 0x0601B2BEu: goto L_0601B2BE; case 0x0601B2C0u: goto L_0601B2C0; case 0x0601B2C2u: goto L_0601B2C2; case 0x0601B2C4u: goto L_0601B2C4; case 0x0601B2C6u: goto L_0601B2C6; case 0x0601B2C8u: goto L_0601B2C8; case 0x0601B2CAu: goto L_0601B2CA; case 0x0601B2CCu: goto L_0601B2CC; case 0x0601B2CEu: goto L_0601B2CE; case 0x0601B2D0u: goto L_0601B2D0; case 0x0601B2D2u: goto L_0601B2D2; case 0x0601B2D4u: goto L_0601B2D4; case 0x0601B2D6u: goto L_0601B2D6; case 0x0601B2D8u: goto L_0601B2D8; case 0x0601B2DAu: goto L_0601B2DA; case 0x0601B2DEu: goto L_0601B2DE; case 0x0601B2E0u: goto L_0601B2E0; case 0x0601B2E2u: goto L_0601B2E2; case 0x0601B2E4u: goto L_0601B2E4; case 0x0601B2E6u: goto L_0601B2E6; case 0x0601B2E8u: goto L_0601B2E8; case 0x0601B2EAu: goto L_0601B2EA; case 0x0601B2ECu: goto L_0601B2EC; case 0x0601B2EEu: goto L_0601B2EE; case 0x0601B2F0u: goto L_0601B2F0; case 0x0601B2F2u: goto L_0601B2F2; case 0x0601B2F4u: goto L_0601B2F4; case 0x0601B2F6u: goto L_0601B2F6; case 0x0601B2F8u: goto L_0601B2F8; case 0x0601B2FAu: goto L_0601B2FA; case 0x0601B2FCu: goto L_0601B2FC; case 0x0601B2FEu: goto L_0601B2FE; case 0x0601B300u: goto L_0601B300; case 0x0601B302u: goto L_0601B302; case 0x0601B306u: goto L_0601B306; case 0x0601B308u: goto L_0601B308; case 0x0601B30Au: goto L_0601B30A; case 0x0601B30Cu: goto L_0601B30C; case 0x0601B30Eu: goto L_0601B30E; case 0x0601B312u: goto L_0601B312; case 0x0601B314u: goto L_0601B314; case 0x0601B316u: goto L_0601B316; case 0x0601B318u: goto L_0601B318; case 0x0601B31Au: goto L_0601B31A; case 0x0601B31Cu: goto L_0601B31C; case 0x0601B320u: goto L_0601B320; case 0x0601B322u: goto L_0601B322; case 0x0601B324u: goto L_0601B324; case 0x0601B326u: goto L_0601B326; case 0x0601B328u: goto L_0601B328; case 0x0601B32Cu: goto L_0601B32C; case 0x0601B32Eu: goto L_0601B32E; case 0x0601B330u: goto L_0601B330; case 0x0601B332u: goto L_0601B332; case 0x0601B334u: goto L_0601B334; case 0x0601B336u: goto L_0601B336; case 0x0601B338u: goto L_0601B338; case 0x0601B33Au: goto L_0601B33A; case 0x0601B33Cu: goto L_0601B33C; case 0x0601B340u: goto L_0601B340; case 0x0601B342u: goto L_0601B342; case 0x0601B346u: goto L_0601B346; case 0x0601B348u: goto L_0601B348; case 0x0601B34Au: goto L_0601B34A; case 0x0601B34Eu: goto L_0601B34E; case 0x0601B350u: goto L_0601B350; case 0x0601B352u: goto L_0601B352; case 0x0601B354u: goto L_0601B354; case 0x0601B356u: goto L_0601B356; case 0x0601B358u: goto L_0601B358; case 0x0601B35Au: goto L_0601B35A; case 0x0601B35Cu: goto L_0601B35C; case 0x0601B35Eu: goto L_0601B35E; case 0x0601B360u: goto L_0601B360; case 0x0601B362u: goto L_0601B362; case 0x0601B364u: goto L_0601B364; case 0x0601B366u: goto L_0601B366; case 0x0601B368u: goto L_0601B368; case 0x0601B36Au: goto L_0601B36A; case 0x0601B36Cu: goto L_0601B36C; case 0x0601B36Eu: goto L_0601B36E; case 0x0601B370u: goto L_0601B370; case 0x0601B372u: goto L_0601B372; case 0x0601B374u: goto L_0601B374; case 0x0601B376u: goto L_0601B376; case 0x0601B378u: goto L_0601B378; case 0x0601B37Au: goto L_0601B37A; case 0x0601B37Eu: goto L_0601B37E; case 0x0601B380u: goto L_0601B380; case 0x0601B382u: goto L_0601B382; case 0x0601B384u: goto L_0601B384; case 0x0601B386u: goto L_0601B386; case 0x0601B388u: goto L_0601B388; case 0x0601B38Au: goto L_0601B38A; case 0x0601B38Cu: goto L_0601B38C; case 0x0601B38Eu: goto L_0601B38E; case 0x0601B392u: goto L_0601B392; case 0x0601B394u: goto L_0601B394; case 0x0601B398u: goto L_0601B398; case 0x0601B39Cu: goto L_0601B39C; case 0x0601B39Eu: goto L_0601B39E; case 0x0601B3A0u: goto L_0601B3A0; case 0x0601B3A2u: goto L_0601B3A2; case 0x0601B3A4u: goto L_0601B3A4; case 0x0601B3A6u: goto L_0601B3A6; case 0x0601B3A8u: goto L_0601B3A8; case 0x0601B3AAu: goto L_0601B3AA; case 0x0601B3ACu: goto L_0601B3AC; case 0x0601B3AEu: goto L_0601B3AE; case 0x0601B3B0u: goto L_0601B3B0; case 0x0601B3B2u: goto L_0601B3B2; case 0x0601B3B4u: goto L_0601B3B4; case 0x0601B3B6u: goto L_0601B3B6; case 0x0601B3B8u: goto L_0601B3B8; case 0x0601B3BAu: goto L_0601B3BA; case 0x0601B3BCu: goto L_0601B3BC; case 0x0601B3BEu: goto L_0601B3BE; case 0x0601B3C0u: goto L_0601B3C0; case 0x0601B3C2u: goto L_0601B3C2; case 0x0601B3C4u: goto L_0601B3C4; case 0x0601B3C6u: goto L_0601B3C6; case 0x0601B3C8u: goto L_0601B3C8; case 0x0601B3CAu: goto L_0601B3CA; case 0x0601B3CCu: goto L_0601B3CC; case 0x0601B3CEu: goto L_0601B3CE; case 0x0601B3D0u: goto L_0601B3D0; case 0x0601B3D2u: goto L_0601B3D2; case 0x0601B3D4u: goto L_0601B3D4; case 0x0601B3D6u: goto L_0601B3D6; case 0x0601B3D8u: goto L_0601B3D8; case 0x0601B3DAu: goto L_0601B3DA; case 0x0601B3DCu: goto L_0601B3DC; case 0x0601B3DEu: goto L_0601B3DE; case 0x0601B3E0u: goto L_0601B3E0; case 0x0601B3E2u: goto L_0601B3E2; case 0x0601B3E4u: goto L_0601B3E4; case 0x0601B3E6u: goto L_0601B3E6; case 0x0601B3E8u: goto L_0601B3E8; case 0x0601B3EAu: goto L_0601B3EA; case 0x0601B3ECu: goto L_0601B3EC; case 0x0601B3EEu: goto L_0601B3EE; case 0x0601B3F2u: goto L_0601B3F2; case 0x0601B3F4u: goto L_0601B3F4; case 0x0601B3F6u: goto L_0601B3F6; case 0x0601B3FAu: goto L_0601B3FA; case 0x0601B3FCu: goto L_0601B3FC; case 0x0601B3FEu: goto L_0601B3FE; case 0x0601B400u: goto L_0601B400; case 0x0601B402u: goto L_0601B402; case 0x0601B406u: goto L_0601B406; case 0x0601B408u: goto L_0601B408; case 0x0601B40Au: goto L_0601B40A; case 0x0601B40Cu: goto L_0601B40C; case 0x0601B410u: goto L_0601B410; case 0x0601B412u: goto L_0601B412; case 0x0601B414u: goto L_0601B414; case 0x0601B416u: goto L_0601B416; case 0x0601B418u: goto L_0601B418; case 0x0601B41Au: goto L_0601B41A; case 0x0601B41Cu: goto L_0601B41C; case 0x0601B41Eu: goto L_0601B41E; case 0x0601B420u: goto L_0601B420; case 0x0601B424u: goto L_0601B424; case 0x0601B426u: goto L_0601B426; case 0x0601B428u: goto L_0601B428; case 0x0601B42Au: goto L_0601B42A; case 0x0601B42Cu: goto L_0601B42C; case 0x0601B42Eu: goto L_0601B42E; case 0x0601B430u: goto L_0601B430; case 0x0601B458u: goto L_0601B458; case 0x0601B45Au: goto L_0601B45A; case 0x0601B45Cu: goto L_0601B45C; case 0x0601B45Eu: goto L_0601B45E; case 0x0601B460u: goto L_0601B460; case 0x0601B462u: goto L_0601B462; case 0x0601B464u: goto L_0601B464; case 0x0601B466u: goto L_0601B466; case 0x0601B46Au: goto L_0601B46A; case 0x0601B46Cu: goto L_0601B46C; case 0x0601B470u: goto L_0601B470; case 0x0601B472u: goto L_0601B472; case 0x0601B474u: goto L_0601B474; case 0x0601B476u: goto L_0601B476; case 0x0601B478u: goto L_0601B478; case 0x0601B47Au: goto L_0601B47A; case 0x0601B47Cu: goto L_0601B47C; case 0x0601B47Eu: goto L_0601B47E; case 0x0601B480u: goto L_0601B480; case 0x0601B482u: goto L_0601B482; case 0x0601B486u: goto L_0601B486; case 0x0601B488u: goto L_0601B488; case 0x0601B48Au: goto L_0601B48A; case 0x0601B48Cu: goto L_0601B48C; case 0x0601B48Eu: goto L_0601B48E; case 0x0601B490u: goto L_0601B490; case 0x0601B492u: goto L_0601B492; case 0x0601B494u: goto L_0601B494; case 0x0601B496u: goto L_0601B496; case 0x0601B49Au: goto L_0601B49A; case 0x0601B49Cu: goto L_0601B49C; case 0x0601B49Eu: goto L_0601B49E; case 0x0601B4A2u: goto L_0601B4A2; case 0x0601B4A4u: goto L_0601B4A4; case 0x0601B4A6u: goto L_0601B4A6; case 0x0601B4AAu: goto L_0601B4AA; case 0x0601B4ACu: goto L_0601B4AC; case 0x0601B4AEu: goto L_0601B4AE; case 0x0601B4B0u: goto L_0601B4B0; case 0x0601B4B2u: goto L_0601B4B2; case 0x0601B4B4u: goto L_0601B4B4; case 0x0601B4B6u: goto L_0601B4B6; case 0x0601B4B8u: goto L_0601B4B8; case 0x0601B4BAu: goto L_0601B4BA; case 0x0601B4BCu: goto L_0601B4BC; case 0x0601B4BEu: goto L_0601B4BE; case 0x0601B4C0u: goto L_0601B4C0; case 0x0601B4C2u: goto L_0601B4C2; case 0x0601B4C4u: goto L_0601B4C4; case 0x0601B4C6u: goto L_0601B4C6; case 0x0601B4C8u: goto L_0601B4C8; case 0x0601B4CAu: goto L_0601B4CA; case 0x0601B4CCu: goto L_0601B4CC; case 0x0601B4CEu: goto L_0601B4CE; case 0x0601B4D0u: goto L_0601B4D0; case 0x0601B4D2u: goto L_0601B4D2; case 0x0601B4D6u: goto L_0601B4D6; case 0x0601B4D8u: goto L_0601B4D8; case 0x0601B4DAu: goto L_0601B4DA; case 0x0601B4DCu: goto L_0601B4DC; case 0x0601B4DEu: goto L_0601B4DE; case 0x0601B4E0u: goto L_0601B4E0; case 0x0601B4E2u: goto L_0601B4E2; case 0x0601B4E4u: goto L_0601B4E4; case 0x0601B4E6u: goto L_0601B4E6; case 0x0601B4EAu: goto L_0601B4EA; case 0x0601B4ECu: goto L_0601B4EC; case 0x0601B4F0u: goto L_0601B4F0; case 0x0601B4F4u: goto L_0601B4F4; case 0x0601B4F6u: goto L_0601B4F6; case 0x0601B4F8u: goto L_0601B4F8; case 0x0601B4FAu: goto L_0601B4FA; case 0x0601B4FCu: goto L_0601B4FC; case 0x0601B4FEu: goto L_0601B4FE; case 0x0601B500u: goto L_0601B500; case 0x0601B502u: goto L_0601B502; case 0x0601B504u: goto L_0601B504; case 0x0601B506u: goto L_0601B506; case 0x0601B508u: goto L_0601B508; case 0x0601B50Au: goto L_0601B50A; case 0x0601B50Cu: goto L_0601B50C; case 0x0601B50Eu: goto L_0601B50E; case 0x0601B510u: goto L_0601B510; case 0x0601B512u: goto L_0601B512; case 0x0601B516u: goto L_0601B516; case 0x0601B51Au: goto L_0601B51A; case 0x0601B51Cu: goto L_0601B51C; case 0x0601B51Eu: goto L_0601B51E; case 0x0601B520u: goto L_0601B520; case 0x0601B522u: goto L_0601B522; case 0x0601B524u: goto L_0601B524; case 0x0601B526u: goto L_0601B526; case 0x0601B528u: goto L_0601B528; case 0x0601B52Au: goto L_0601B52A; case 0x0601B52Cu: goto L_0601B52C; case 0x0601B530u: goto L_0601B530; case 0x0601B532u: goto L_0601B532; case 0x0601B534u: goto L_0601B534; case 0x0601B536u: goto L_0601B536; case 0x0601B538u: goto L_0601B538; case 0x0601B53Au: goto L_0601B53A; case 0x0601B53Cu: goto L_0601B53C; case 0x0601B53Eu: goto L_0601B53E; case 0x0601B540u: goto L_0601B540; case 0x0601B542u: goto L_0601B542; case 0x0601B544u: goto L_0601B544; case 0x0601B546u: goto L_0601B546; case 0x0601B548u: goto L_0601B548; case 0x0601B54Au: goto L_0601B54A; case 0x0601B54Cu: goto L_0601B54C; case 0x0601B54Eu: goto L_0601B54E; case 0x0601B550u: goto L_0601B550; case 0x0601B552u: goto L_0601B552; case 0x0601B554u: goto L_0601B554; case 0x0601B556u: goto L_0601B556; case 0x0601B558u: goto L_0601B558; case 0x0601B57Cu: goto L_0601B57C; case 0x0601B57Eu: goto L_0601B57E; case 0x0601B580u: goto L_0601B580; case 0x0601B582u: goto L_0601B582; case 0x0601B584u: goto L_0601B584; case 0x0601B586u: goto L_0601B586; case 0x0601B588u: goto L_0601B588; case 0x0601B58Au: goto L_0601B58A; case 0x0601B58Cu: goto L_0601B58C; case 0x0601B58Eu: goto L_0601B58E; case 0x0601B590u: goto L_0601B590; case 0x0601B592u: goto L_0601B592; case 0x0601B594u: goto L_0601B594; case 0x0601B596u: goto L_0601B596; case 0x0601B598u: goto L_0601B598; case 0x0601B59Au: goto L_0601B59A; case 0x0601B59Cu: goto L_0601B59C; case 0x0601B59Eu: goto L_0601B59E; case 0x0601B5A0u: goto L_0601B5A0; case 0x0601B5A4u: goto L_0601B5A4; case 0x0601B5A6u: goto L_0601B5A6; case 0x0601B5A8u: goto L_0601B5A8; case 0x0601B5AAu: goto L_0601B5AA; case 0x0601B5ACu: goto L_0601B5AC; case 0x0601B5B0u: goto L_0601B5B0; case 0x0601B5B2u: goto L_0601B5B2; case 0x0601B5B4u: goto L_0601B5B4; case 0x0601B5B6u: goto L_0601B5B6; case 0x0601B5B8u: goto L_0601B5B8; case 0x0601B5BAu: goto L_0601B5BA; case 0x0601B5BEu: goto L_0601B5BE; case 0x0601B5C0u: goto L_0601B5C0; case 0x0601B5C2u: goto L_0601B5C2; case 0x0601B5C4u: goto L_0601B5C4; case 0x0601B5C6u: goto L_0601B5C6; case 0x0601B5C8u: goto L_0601B5C8; case 0x0601B5CAu: goto L_0601B5CA; case 0x0601B5CCu: goto L_0601B5CC; case 0x0601B5CEu: goto L_0601B5CE; case 0x0601B5D0u: goto L_0601B5D0; case 0x0601B5D2u: goto L_0601B5D2; case 0x0601B5D4u: goto L_0601B5D4; case 0x0601B5D6u: goto L_0601B5D6; case 0x0601B5D8u: goto L_0601B5D8; case 0x0601B5DAu: goto L_0601B5DA; case 0x0601B5DCu: goto L_0601B5DC; case 0x0601B5DEu: goto L_0601B5DE; case 0x0601B5E2u: goto L_0601B5E2; case 0x0601B5E4u: goto L_0601B5E4; case 0x0601B5E6u: goto L_0601B5E6; case 0x0601B5E8u: goto L_0601B5E8; case 0x0601B5EAu: goto L_0601B5EA; case 0x0601B5ECu: goto L_0601B5EC; case 0x0601B5EEu: goto L_0601B5EE; case 0x0601B5F0u: goto L_0601B5F0; case 0x0601B5F2u: goto L_0601B5F2; case 0x0601B5F4u: goto L_0601B5F4; case 0x0601B5F6u: goto L_0601B5F6; case 0x0601B5F8u: goto L_0601B5F8; case 0x0601B5FAu: goto L_0601B5FA; case 0x0601B5FCu: goto L_0601B5FC; case 0x0601B5FEu: goto L_0601B5FE; case 0x0601B602u: goto L_0601B602; case 0x0601B604u: goto L_0601B604; case 0x0601B608u: goto L_0601B608; case 0x0601B60Cu: goto L_0601B60C; case 0x0601B60Eu: goto L_0601B60E; case 0x0601B610u: goto L_0601B610; case 0x0601B612u: goto L_0601B612; case 0x0601B614u: goto L_0601B614; case 0x0601B616u: goto L_0601B616; case 0x0601B618u: goto L_0601B618; case 0x0601B61Au: goto L_0601B61A; case 0x0601B61Cu: goto L_0601B61C; case 0x0601B61Eu: goto L_0601B61E; case 0x0601B620u: goto L_0601B620; case 0x0601B622u: goto L_0601B622; case 0x0601B624u: goto L_0601B624; case 0x0601B626u: goto L_0601B626; case 0x0601B628u: goto L_0601B628; case 0x0601B62Au: goto L_0601B62A; case 0x0601B62Cu: goto L_0601B62C; case 0x0601B62Eu: goto L_0601B62E; case 0x0601B630u: goto L_0601B630; case 0x0601B632u: goto L_0601B632; case 0x0601B634u: goto L_0601B634; case 0x0601B636u: goto L_0601B636; case 0x0601B638u: goto L_0601B638; case 0x0601B63Au: goto L_0601B63A; case 0x0601B63Cu: goto L_0601B63C; case 0x0601B63Eu: goto L_0601B63E; case 0x0601B640u: goto L_0601B640; case 0x0601B642u: goto L_0601B642; case 0x0601B644u: goto L_0601B644; case 0x0601B646u: goto L_0601B646; case 0x0601B648u: goto L_0601B648; case 0x0601B64Au: goto L_0601B64A; case 0x0601B64Cu: goto L_0601B64C; case 0x0601B64Eu: goto L_0601B64E; case 0x0601B650u: goto L_0601B650; case 0x0601B652u: goto L_0601B652; case 0x0601B654u: goto L_0601B654; case 0x0601B656u: goto L_0601B656; case 0x0601B658u: goto L_0601B658; case 0x0601B65Au: goto L_0601B65A; case 0x0601B65Cu: goto L_0601B65C; case 0x0601B65Eu: goto L_0601B65E; case 0x0601B660u: goto L_0601B660; case 0x0601B664u: goto L_0601B664; case 0x0601B666u: goto L_0601B666; case 0x0601B66Au: goto L_0601B66A; case 0x0601B66Cu: goto L_0601B66C; case 0x0601B66Eu: goto L_0601B66E; case 0x0601B670u: goto L_0601B670; case 0x0601B672u: goto L_0601B672; case 0x0601B674u: goto L_0601B674; case 0x0601B676u: goto L_0601B676; case 0x0601B678u: goto L_0601B678; case 0x0601B67Au: goto L_0601B67A; case 0x0601B67Eu: goto L_0601B67E; case 0x0601B682u: goto L_0601B682; case 0x0601B684u: goto L_0601B684; case 0x0601B688u: goto L_0601B688; case 0x0601B68Au: goto L_0601B68A; case 0x0601B68Cu: goto L_0601B68C; case 0x0601B68Eu: goto L_0601B68E; case 0x0601B690u: goto L_0601B690; case 0x0601B692u: goto L_0601B692; case 0x0601B696u: goto L_0601B696; case 0x0601B698u: goto L_0601B698; case 0x0601B69Au: goto L_0601B69A; case 0x0601B69Cu: goto L_0601B69C; case 0x0601B69Eu: goto L_0601B69E; case 0x0601B6A0u: goto L_0601B6A0; case 0x0601B6A4u: goto L_0601B6A4; case 0x0601B6A6u: goto L_0601B6A6; case 0x0601B6A8u: goto L_0601B6A8; case 0x0601B6AAu: goto L_0601B6AA; case 0x0601B6ACu: goto L_0601B6AC; case 0x0601B6AEu: goto L_0601B6AE; case 0x0601B6B0u: goto L_0601B6B0; case 0x0601B6B2u: goto L_0601B6B2; case 0x0601B6B4u: goto L_0601B6B4; case 0x0601B6B6u: goto L_0601B6B6; case 0x0601B6B8u: goto L_0601B6B8; case 0x0601B6BAu: goto L_0601B6BA; case 0x0601B6BCu: goto L_0601B6BC; case 0x0601B6BEu: goto L_0601B6BE; case 0x0601B6C0u: goto L_0601B6C0; case 0x0601B6C2u: goto L_0601B6C2; case 0x0601B6C4u: goto L_0601B6C4; case 0x0601B6C8u: goto L_0601B6C8; case 0x0601B6CAu: goto L_0601B6CA; case 0x0601B6CEu: goto L_0601B6CE; case 0x0601B6D0u: goto L_0601B6D0; case 0x0601B6D2u: goto L_0601B6D2; case 0x0601B6D4u: goto L_0601B6D4; case 0x0601B6D6u: goto L_0601B6D6; case 0x0601B6D8u: goto L_0601B6D8; case 0x0601B6DAu: goto L_0601B6DA; case 0x0601B6DCu: goto L_0601B6DC; case 0x0601B6DEu: goto L_0601B6DE; case 0x0601B6E0u: goto L_0601B6E0; case 0x0607ECBEu: goto L_0607ECBE; case 0x0607ECC0u: goto L_0607ECC0; case 0x0607ECC2u: goto L_0607ECC2; case 0x0607ECC4u: goto L_0607ECC4; case 0x0607ECC6u: goto L_0607ECC6; case 0x0607ECC8u: goto L_0607ECC8; case 0x0607ECCAu: goto L_0607ECCA; case 0x0607ECCCu: goto L_0607ECCC; case 0x0607ECCEu: goto L_0607ECCE; case 0x0607ECD0u: goto L_0607ECD0; case 0x0607ECD2u: goto L_0607ECD2; case 0x0607ECD6u: goto L_0607ECD6; case 0x0607ECD8u: goto L_0607ECD8; case 0x0607ECDAu: goto L_0607ECDA; case 0x0607ECDCu: goto L_0607ECDC; case 0x0607ECDEu: goto L_0607ECDE; case 0x0607ECE0u: goto L_0607ECE0; case 0x0607ECE4u: goto L_0607ECE4; case 0x0607ECE8u: goto L_0607ECE8; case 0x0607ECEAu: goto L_0607ECEA; case 0x0607EE54u: goto L_0607EE54; case 0x0607EE56u: goto L_0607EE56; case 0x0607EE58u: goto L_0607EE58; case 0x0607EE5Au: goto L_0607EE5A; case 0x0607EE5Cu: goto L_0607EE5C; case 0x0607EE5Eu: goto L_0607EE5E; case 0x0607EE60u: goto L_0607EE60; case 0x0607EE62u: goto L_0607EE62; case 0x0608431Eu: goto L_0608431E; case 0x06084320u: goto L_06084320; case 0x06084322u: goto L_06084322; case 0x06084324u: goto L_06084324; case 0x06084326u: goto L_06084326; case 0x06084328u: goto L_06084328; case 0x0608432Au: goto L_0608432A; case 0x0608432Cu: goto L_0608432C; case 0x06084330u: goto L_06084330; case 0x06084332u: goto L_06084332; case 0x06084334u: goto L_06084334; case 0x06084336u: goto L_06084336; case 0x06084338u: goto L_06084338; case 0x0608433Au: goto L_0608433A; case 0x0608433Cu: goto L_0608433C; case 0x0608433Eu: goto L_0608433E; case 0x06084340u: goto L_06084340; case 0x06084342u: goto L_06084342; case 0x06084344u: goto L_06084344; case 0x06084346u: goto L_06084346; case 0x06084348u: goto L_06084348; case 0x0608434Au: goto L_0608434A; case 0x0608434Cu: goto L_0608434C; case 0x0608434Eu: goto L_0608434E; case 0x06084350u: goto L_06084350; case 0x06084352u: goto L_06084352; case 0x06084354u: goto L_06084354; case 0x06084356u: goto L_06084356; case 0x06084358u: goto L_06084358; case 0x0608435Au: goto L_0608435A; case 0x0608435Cu: goto L_0608435C; case 0x0608435Eu: goto L_0608435E; case 0x06084362u: goto L_06084362; case 0x06084364u: goto L_06084364; default: sh2_call(c, x); return; } }  // 0607ECEA jmp @r0 ; nop
L_0607EE54:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607EE54 lds.l @r15+,pr
L_0607EE56:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0607EE56 mov.l @r15+,r14
L_0607EE58:
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0607EE58 mov.l @r15+,r13
L_0607EE5A:
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0607EE5A mov.l @r15+,r12
L_0607EE5C:
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0607EE5C mov.l @r15+,r11
L_0607EE5E:
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0607EE5E mov.l @r15+,r10
L_0607EE60:
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0607EE60 mov.l @r15+,r9
L_0607EE62:
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607EE62 rts ; mov.l @r15+,r8
L_0608431E:
    c.r[10] = c.r[5];  // 0608431E mov r5,r10
L_06084320:
    c.r[1] = ld32(0x06084394u);  // 06084320 mov.l 0x06084394,r1
L_06084322:
    c.r[4] = ld32(c.r[1]);  // 06084322 mov.l @r1,r4
L_06084324:
    c.r[1] = ld32(0x060843D0u);  // 06084324 mov.l 0x060843D0,r1
L_06084326:
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06084326 mov.b @r1,r5
L_06084328:
    c.r[5] = c.r[5] & 0xFFu;  // 06084328 extu.b r5,r5
L_0608432A:
    c.r[0] = ld32(0x06084390u);  // 0608432A mov.l 0x06084390,r0
L_0608432C:
    { const uint32_t x = c.r[0]; c.pr = 0x06084330u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084330u) return; }  // 0608432C jsr @r0 ; nop
L_06084330:
    c.r[1] = ld32(0x06084384u);  // 06084330 mov.l 0x06084384,r1
L_06084332:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06084332 mov.b @r1,r1
L_06084334:
    c.r[1] = c.r[1] & 0xFFu;  // 06084334 extu.b r1,r1
L_06084336:
    c.r[1] -= c.r[0];  // 06084336 sub r0,r1
L_06084338:
    c.r[2] = ld32(0x0608439Cu);  // 06084338 mov.l 0x0608439C,r2
L_0608433A:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2] + 14);  // 0608433A mov.b @(14,r2),r0
L_0608433C:
    c.r[0] = c.r[0] & 0xFFu;  // 0608433C extu.b r0,r0
L_0608433E:
    c.r[0] += c.r[10];  // 0608433E add r10,r0
L_06084340:
    c.r[3] = 0x1u;  // 06084340 mov #1,r3
L_06084342:
    c.t = (int32_t)c.r[0] >= (int32_t)c.r[3];  // 06084342 cmp/ge r3,r0
L_06084344:
    if (!c.t) { goto L_06084362; }  // 06084344 bf 0x06084362
L_06084346:
    c.t = (int32_t)c.r[0] > (int32_t)c.r[1];  // 06084346 cmp/gt r1,r0
L_06084348:
    if (c.t) { goto L_06084362; }  // 06084348 bt 0x06084362
L_0608434A:
    c.t = (int32_t)c.r[10] > 0;  // 0608434A cmp/pl r10
L_0608434C:
    if (!c.t) { goto L_0608435A; }  // 0608434C bf 0x0608435A
L_0608434E:
    c.r[3] = ld32(0x060843C4u);  // 0608434E mov.l 0x060843C4,r3
L_06084350:
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06084350 mov.w @r3,r3
L_06084352:
    c.r[3] = c.r[3] & 0xFFFFu;  // 06084352 extu.w r3,r3
L_06084354:
    c.r[4] = (uint32_t)(int16_t)ld16(0x060843E2u);  // 06084354 mov.w 0x060843E2,r4
L_06084356:
    c.t = c.r[3] > c.r[4];  // 06084356 cmp/hi r4,r3
L_06084358:
    if (c.t) { goto L_06084362; }  // 06084358 bt 0x06084362
L_0608435A:
    st8(c.r[2] + 14, c.r[0]);  // 0608435A mov.b r0,@(14,r2)
L_0608435C:
    c.r[0] = ld32(0x060843D4u);  // 0608435C mov.l 0x060843D4,r0
L_0608435E:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x0601B124u: goto L_0601B124; case 0x0601B126u: goto L_0601B126; case 0x0601B128u: goto L_0601B128; case 0x0601B12Au: goto L_0601B12A; case 0x0601B12Cu: goto L_0601B12C; case 0x0601B12Eu: goto L_0601B12E; case 0x0601B130u: goto L_0601B130; case 0x0601B132u: goto L_0601B132; case 0x0601B134u: goto L_0601B134; case 0x0601B136u: goto L_0601B136; case 0x0601B138u: goto L_0601B138; case 0x0601B13Au: goto L_0601B13A; case 0x0601B13Eu: goto L_0601B13E; case 0x0601B140u: goto L_0601B140; case 0x0601B144u: goto L_0601B144; case 0x0601B146u: goto L_0601B146; case 0x0601B148u: goto L_0601B148; case 0x0601B14Au: goto L_0601B14A; case 0x0601B14Cu: goto L_0601B14C; case 0x0601B14Eu: goto L_0601B14E; case 0x0601B150u: goto L_0601B150; case 0x0601B152u: goto L_0601B152; case 0x0601B156u: goto L_0601B156; case 0x0601B158u: goto L_0601B158; case 0x0601B15Au: goto L_0601B15A; case 0x0601B15Cu: goto L_0601B15C; case 0x0601B15Eu: goto L_0601B15E; case 0x0601B162u: goto L_0601B162; case 0x0601B164u: goto L_0601B164; case 0x0601B166u: goto L_0601B166; case 0x0601B168u: goto L_0601B168; case 0x0601B16Au: goto L_0601B16A; case 0x0601B16Cu: goto L_0601B16C; case 0x0601B16Eu: goto L_0601B16E; case 0x0601B170u: goto L_0601B170; case 0x0601B172u: goto L_0601B172; case 0x0601B176u: goto L_0601B176; case 0x0601B178u: goto L_0601B178; case 0x0601B17Au: goto L_0601B17A; case 0x0601B17Cu: goto L_0601B17C; case 0x0601B17Eu: goto L_0601B17E; case 0x0601B180u: goto L_0601B180; case 0x0601B182u: goto L_0601B182; case 0x0601B184u: goto L_0601B184; case 0x0601B188u: goto L_0601B188; case 0x0601B18Au: goto L_0601B18A; case 0x0601B18Cu: goto L_0601B18C; case 0x0601B190u: goto L_0601B190; case 0x0601B194u: goto L_0601B194; case 0x0601B196u: goto L_0601B196; case 0x0601B198u: goto L_0601B198; case 0x0601B19Au: goto L_0601B19A; case 0x0601B19Cu: goto L_0601B19C; case 0x0601B19Eu: goto L_0601B19E; case 0x0601B1A0u: goto L_0601B1A0; case 0x0601B1A2u: goto L_0601B1A2; case 0x0601B1A4u: goto L_0601B1A4; case 0x0601B1A6u: goto L_0601B1A6; case 0x0601B1A8u: goto L_0601B1A8; case 0x0601B1AAu: goto L_0601B1AA; case 0x0601B1ACu: goto L_0601B1AC; case 0x0601B1B0u: goto L_0601B1B0; case 0x0601B1B2u: goto L_0601B1B2; case 0x0601B1B4u: goto L_0601B1B4; case 0x0601B1B6u: goto L_0601B1B6; case 0x0601B1B8u: goto L_0601B1B8; case 0x0601B1BAu: goto L_0601B1BA; case 0x0601B1BCu: goto L_0601B1BC; case 0x0601B1BEu: goto L_0601B1BE; case 0x0601B1C0u: goto L_0601B1C0; case 0x0601B1C2u: goto L_0601B1C2; case 0x0601B1C4u: goto L_0601B1C4; case 0x0601B1C8u: goto L_0601B1C8; case 0x0601B1CAu: goto L_0601B1CA; case 0x0601B1CCu: goto L_0601B1CC; case 0x0601B1CEu: goto L_0601B1CE; case 0x0601B1D0u: goto L_0601B1D0; case 0x0601B1D2u: goto L_0601B1D2; case 0x0601B1D4u: goto L_0601B1D4; case 0x0601B1D6u: goto L_0601B1D6; case 0x0601B1D8u: goto L_0601B1D8; case 0x0601B1DAu: goto L_0601B1DA; case 0x0601B1DCu: goto L_0601B1DC; case 0x0601B1DEu: goto L_0601B1DE; case 0x0601B1E0u: goto L_0601B1E0; case 0x0601B1E2u: goto L_0601B1E2; case 0x0601B1E4u: goto L_0601B1E4; case 0x0601B1E6u: goto L_0601B1E6; case 0x0601B1E8u: goto L_0601B1E8; case 0x0601B1EAu: goto L_0601B1EA; case 0x0601B1ECu: goto L_0601B1EC; case 0x0601B1EEu: goto L_0601B1EE; case 0x0601B1F0u: goto L_0601B1F0; case 0x0601B1F2u: goto L_0601B1F2; case 0x0601B1F4u: goto L_0601B1F4; case 0x0601B1F6u: goto L_0601B1F6; case 0x0601B1F8u: goto L_0601B1F8; case 0x0601B1FAu: goto L_0601B1FA; case 0x0601B1FCu: goto L_0601B1FC; case 0x0601B1FEu: goto L_0601B1FE; case 0x0601B200u: goto L_0601B200; case 0x0601B202u: goto L_0601B202; case 0x0601B204u: goto L_0601B204; case 0x0601B206u: goto L_0601B206; case 0x0601B208u: goto L_0601B208; case 0x0601B20Au: goto L_0601B20A; case 0x0601B20Cu: goto L_0601B20C; case 0x0601B20Eu: goto L_0601B20E; case 0x0601B210u: goto L_0601B210; case 0x0601B214u: goto L_0601B214; case 0x0601B216u: goto L_0601B216; case 0x0601B218u: goto L_0601B218; case 0x0601B21Au: goto L_0601B21A; case 0x0601B21Cu: goto L_0601B21C; case 0x0601B21Eu: goto L_0601B21E; case 0x0601B220u: goto L_0601B220; case 0x0601B222u: goto L_0601B222; case 0x0601B224u: goto L_0601B224; case 0x0601B228u: goto L_0601B228; case 0x0601B22Au: goto L_0601B22A; case 0x0601B22Eu: goto L_0601B22E; case 0x0601B260u: goto L_0601B260; case 0x0601B262u: goto L_0601B262; case 0x0601B264u: goto L_0601B264; case 0x0601B266u: goto L_0601B266; case 0x0601B268u: goto L_0601B268; case 0x0601B26Au: goto L_0601B26A; case 0x0601B26Cu: goto L_0601B26C; case 0x0601B26Eu: goto L_0601B26E; case 0x0601B270u: goto L_0601B270; case 0x0601B272u: goto L_0601B272; case 0x0601B274u: goto L_0601B274; case 0x0601B276u: goto L_0601B276; case 0x0601B278u: goto L_0601B278; case 0x0601B27Au: goto L_0601B27A; case 0x0601B27Cu: goto L_0601B27C; case 0x0601B27Eu: goto L_0601B27E; case 0x0601B280u: goto L_0601B280; case 0x0601B284u: goto L_0601B284; case 0x0601B286u: goto L_0601B286; case 0x0601B288u: goto L_0601B288; case 0x0601B28Au: goto L_0601B28A; case 0x0601B28Cu: goto L_0601B28C; case 0x0601B28Eu: goto L_0601B28E; case 0x0601B290u: goto L_0601B290; case 0x0601B292u: goto L_0601B292; case 0x0601B296u: goto L_0601B296; case 0x0601B298u: goto L_0601B298; case 0x0601B29Au: goto L_0601B29A; case 0x0601B29Eu: goto L_0601B29E; case 0x0601B2A0u: goto L_0601B2A0; case 0x0601B2A2u: goto L_0601B2A2; case 0x0601B2A4u: goto L_0601B2A4; case 0x0601B2A6u: goto L_0601B2A6; case 0x0601B2A8u: goto L_0601B2A8; case 0x0601B2AAu: goto L_0601B2AA; case 0x0601B2ACu: goto L_0601B2AC; case 0x0601B2AEu: goto L_0601B2AE; case 0x0601B2B0u: goto L_0601B2B0; case 0x0601B2B4u: goto L_0601B2B4; case 0x0601B2B8u: goto L_0601B2B8; case 0x0601B2BAu: goto L_0601B2BA; case 0x0601B2BCu: goto L_0601B2BC; case 0x0601B2BEu: goto L_0601B2BE; case 0x0601B2C0u: goto L_0601B2C0; case 0x0601B2C2u: goto L_0601B2C2; case 0x0601B2C4u: goto L_0601B2C4; case 0x0601B2C6u: goto L_0601B2C6; case 0x0601B2C8u: goto L_0601B2C8; case 0x0601B2CAu: goto L_0601B2CA; case 0x0601B2CCu: goto L_0601B2CC; case 0x0601B2CEu: goto L_0601B2CE; case 0x0601B2D0u: goto L_0601B2D0; case 0x0601B2D2u: goto L_0601B2D2; case 0x0601B2D4u: goto L_0601B2D4; case 0x0601B2D6u: goto L_0601B2D6; case 0x0601B2D8u: goto L_0601B2D8; case 0x0601B2DAu: goto L_0601B2DA; case 0x0601B2DEu: goto L_0601B2DE; case 0x0601B2E0u: goto L_0601B2E0; case 0x0601B2E2u: goto L_0601B2E2; case 0x0601B2E4u: goto L_0601B2E4; case 0x0601B2E6u: goto L_0601B2E6; case 0x0601B2E8u: goto L_0601B2E8; case 0x0601B2EAu: goto L_0601B2EA; case 0x0601B2ECu: goto L_0601B2EC; case 0x0601B2EEu: goto L_0601B2EE; case 0x0601B2F0u: goto L_0601B2F0; case 0x0601B2F2u: goto L_0601B2F2; case 0x0601B2F4u: goto L_0601B2F4; case 0x0601B2F6u: goto L_0601B2F6; case 0x0601B2F8u: goto L_0601B2F8; case 0x0601B2FAu: goto L_0601B2FA; case 0x0601B2FCu: goto L_0601B2FC; case 0x0601B2FEu: goto L_0601B2FE; case 0x0601B300u: goto L_0601B300; case 0x0601B302u: goto L_0601B302; case 0x0601B306u: goto L_0601B306; case 0x0601B308u: goto L_0601B308; case 0x0601B30Au: goto L_0601B30A; case 0x0601B30Cu: goto L_0601B30C; case 0x0601B30Eu: goto L_0601B30E; case 0x0601B312u: goto L_0601B312; case 0x0601B314u: goto L_0601B314; case 0x0601B316u: goto L_0601B316; case 0x0601B318u: goto L_0601B318; case 0x0601B31Au: goto L_0601B31A; case 0x0601B31Cu: goto L_0601B31C; case 0x0601B320u: goto L_0601B320; case 0x0601B322u: goto L_0601B322; case 0x0601B324u: goto L_0601B324; case 0x0601B326u: goto L_0601B326; case 0x0601B328u: goto L_0601B328; case 0x0601B32Cu: goto L_0601B32C; case 0x0601B32Eu: goto L_0601B32E; case 0x0601B330u: goto L_0601B330; case 0x0601B332u: goto L_0601B332; case 0x0601B334u: goto L_0601B334; case 0x0601B336u: goto L_0601B336; case 0x0601B338u: goto L_0601B338; case 0x0601B33Au: goto L_0601B33A; case 0x0601B33Cu: goto L_0601B33C; case 0x0601B340u: goto L_0601B340; case 0x0601B342u: goto L_0601B342; case 0x0601B346u: goto L_0601B346; case 0x0601B348u: goto L_0601B348; case 0x0601B34Au: goto L_0601B34A; case 0x0601B34Eu: goto L_0601B34E; case 0x0601B350u: goto L_0601B350; case 0x0601B352u: goto L_0601B352; case 0x0601B354u: goto L_0601B354; case 0x0601B356u: goto L_0601B356; case 0x0601B358u: goto L_0601B358; case 0x0601B35Au: goto L_0601B35A; case 0x0601B35Cu: goto L_0601B35C; case 0x0601B35Eu: goto L_0601B35E; case 0x0601B360u: goto L_0601B360; case 0x0601B362u: goto L_0601B362; case 0x0601B364u: goto L_0601B364; case 0x0601B366u: goto L_0601B366; case 0x0601B368u: goto L_0601B368; case 0x0601B36Au: goto L_0601B36A; case 0x0601B36Cu: goto L_0601B36C; case 0x0601B36Eu: goto L_0601B36E; case 0x0601B370u: goto L_0601B370; case 0x0601B372u: goto L_0601B372; case 0x0601B374u: goto L_0601B374; case 0x0601B376u: goto L_0601B376; case 0x0601B378u: goto L_0601B378; case 0x0601B37Au: goto L_0601B37A; case 0x0601B37Eu: goto L_0601B37E; case 0x0601B380u: goto L_0601B380; case 0x0601B382u: goto L_0601B382; case 0x0601B384u: goto L_0601B384; case 0x0601B386u: goto L_0601B386; case 0x0601B388u: goto L_0601B388; case 0x0601B38Au: goto L_0601B38A; case 0x0601B38Cu: goto L_0601B38C; case 0x0601B38Eu: goto L_0601B38E; case 0x0601B392u: goto L_0601B392; case 0x0601B394u: goto L_0601B394; case 0x0601B398u: goto L_0601B398; case 0x0601B39Cu: goto L_0601B39C; case 0x0601B39Eu: goto L_0601B39E; case 0x0601B3A0u: goto L_0601B3A0; case 0x0601B3A2u: goto L_0601B3A2; case 0x0601B3A4u: goto L_0601B3A4; case 0x0601B3A6u: goto L_0601B3A6; case 0x0601B3A8u: goto L_0601B3A8; case 0x0601B3AAu: goto L_0601B3AA; case 0x0601B3ACu: goto L_0601B3AC; case 0x0601B3AEu: goto L_0601B3AE; case 0x0601B3B0u: goto L_0601B3B0; case 0x0601B3B2u: goto L_0601B3B2; case 0x0601B3B4u: goto L_0601B3B4; case 0x0601B3B6u: goto L_0601B3B6; case 0x0601B3B8u: goto L_0601B3B8; case 0x0601B3BAu: goto L_0601B3BA; case 0x0601B3BCu: goto L_0601B3BC; case 0x0601B3BEu: goto L_0601B3BE; case 0x0601B3C0u: goto L_0601B3C0; case 0x0601B3C2u: goto L_0601B3C2; case 0x0601B3C4u: goto L_0601B3C4; case 0x0601B3C6u: goto L_0601B3C6; case 0x0601B3C8u: goto L_0601B3C8; case 0x0601B3CAu: goto L_0601B3CA; case 0x0601B3CCu: goto L_0601B3CC; case 0x0601B3CEu: goto L_0601B3CE; case 0x0601B3D0u: goto L_0601B3D0; case 0x0601B3D2u: goto L_0601B3D2; case 0x0601B3D4u: goto L_0601B3D4; case 0x0601B3D6u: goto L_0601B3D6; case 0x0601B3D8u: goto L_0601B3D8; case 0x0601B3DAu: goto L_0601B3DA; case 0x0601B3DCu: goto L_0601B3DC; case 0x0601B3DEu: goto L_0601B3DE; case 0x0601B3E0u: goto L_0601B3E0; case 0x0601B3E2u: goto L_0601B3E2; case 0x0601B3E4u: goto L_0601B3E4; case 0x0601B3E6u: goto L_0601B3E6; case 0x0601B3E8u: goto L_0601B3E8; case 0x0601B3EAu: goto L_0601B3EA; case 0x0601B3ECu: goto L_0601B3EC; case 0x0601B3EEu: goto L_0601B3EE; case 0x0601B3F2u: goto L_0601B3F2; case 0x0601B3F4u: goto L_0601B3F4; case 0x0601B3F6u: goto L_0601B3F6; case 0x0601B3FAu: goto L_0601B3FA; case 0x0601B3FCu: goto L_0601B3FC; case 0x0601B3FEu: goto L_0601B3FE; case 0x0601B400u: goto L_0601B400; case 0x0601B402u: goto L_0601B402; case 0x0601B406u: goto L_0601B406; case 0x0601B408u: goto L_0601B408; case 0x0601B40Au: goto L_0601B40A; case 0x0601B40Cu: goto L_0601B40C; case 0x0601B410u: goto L_0601B410; case 0x0601B412u: goto L_0601B412; case 0x0601B414u: goto L_0601B414; case 0x0601B416u: goto L_0601B416; case 0x0601B418u: goto L_0601B418; case 0x0601B41Au: goto L_0601B41A; case 0x0601B41Cu: goto L_0601B41C; case 0x0601B41Eu: goto L_0601B41E; case 0x0601B420u: goto L_0601B420; case 0x0601B424u: goto L_0601B424; case 0x0601B426u: goto L_0601B426; case 0x0601B428u: goto L_0601B428; case 0x0601B42Au: goto L_0601B42A; case 0x0601B42Cu: goto L_0601B42C; case 0x0601B42Eu: goto L_0601B42E; case 0x0601B430u: goto L_0601B430; case 0x0601B458u: goto L_0601B458; case 0x0601B45Au: goto L_0601B45A; case 0x0601B45Cu: goto L_0601B45C; case 0x0601B45Eu: goto L_0601B45E; case 0x0601B460u: goto L_0601B460; case 0x0601B462u: goto L_0601B462; case 0x0601B464u: goto L_0601B464; case 0x0601B466u: goto L_0601B466; case 0x0601B46Au: goto L_0601B46A; case 0x0601B46Cu: goto L_0601B46C; case 0x0601B470u: goto L_0601B470; case 0x0601B472u: goto L_0601B472; case 0x0601B474u: goto L_0601B474; case 0x0601B476u: goto L_0601B476; case 0x0601B478u: goto L_0601B478; case 0x0601B47Au: goto L_0601B47A; case 0x0601B47Cu: goto L_0601B47C; case 0x0601B47Eu: goto L_0601B47E; case 0x0601B480u: goto L_0601B480; case 0x0601B482u: goto L_0601B482; case 0x0601B486u: goto L_0601B486; case 0x0601B488u: goto L_0601B488; case 0x0601B48Au: goto L_0601B48A; case 0x0601B48Cu: goto L_0601B48C; case 0x0601B48Eu: goto L_0601B48E; case 0x0601B490u: goto L_0601B490; case 0x0601B492u: goto L_0601B492; case 0x0601B494u: goto L_0601B494; case 0x0601B496u: goto L_0601B496; case 0x0601B49Au: goto L_0601B49A; case 0x0601B49Cu: goto L_0601B49C; case 0x0601B49Eu: goto L_0601B49E; case 0x0601B4A2u: goto L_0601B4A2; case 0x0601B4A4u: goto L_0601B4A4; case 0x0601B4A6u: goto L_0601B4A6; case 0x0601B4AAu: goto L_0601B4AA; case 0x0601B4ACu: goto L_0601B4AC; case 0x0601B4AEu: goto L_0601B4AE; case 0x0601B4B0u: goto L_0601B4B0; case 0x0601B4B2u: goto L_0601B4B2; case 0x0601B4B4u: goto L_0601B4B4; case 0x0601B4B6u: goto L_0601B4B6; case 0x0601B4B8u: goto L_0601B4B8; case 0x0601B4BAu: goto L_0601B4BA; case 0x0601B4BCu: goto L_0601B4BC; case 0x0601B4BEu: goto L_0601B4BE; case 0x0601B4C0u: goto L_0601B4C0; case 0x0601B4C2u: goto L_0601B4C2; case 0x0601B4C4u: goto L_0601B4C4; case 0x0601B4C6u: goto L_0601B4C6; case 0x0601B4C8u: goto L_0601B4C8; case 0x0601B4CAu: goto L_0601B4CA; case 0x0601B4CCu: goto L_0601B4CC; case 0x0601B4CEu: goto L_0601B4CE; case 0x0601B4D0u: goto L_0601B4D0; case 0x0601B4D2u: goto L_0601B4D2; case 0x0601B4D6u: goto L_0601B4D6; case 0x0601B4D8u: goto L_0601B4D8; case 0x0601B4DAu: goto L_0601B4DA; case 0x0601B4DCu: goto L_0601B4DC; case 0x0601B4DEu: goto L_0601B4DE; case 0x0601B4E0u: goto L_0601B4E0; case 0x0601B4E2u: goto L_0601B4E2; case 0x0601B4E4u: goto L_0601B4E4; case 0x0601B4E6u: goto L_0601B4E6; case 0x0601B4EAu: goto L_0601B4EA; case 0x0601B4ECu: goto L_0601B4EC; case 0x0601B4F0u: goto L_0601B4F0; case 0x0601B4F4u: goto L_0601B4F4; case 0x0601B4F6u: goto L_0601B4F6; case 0x0601B4F8u: goto L_0601B4F8; case 0x0601B4FAu: goto L_0601B4FA; case 0x0601B4FCu: goto L_0601B4FC; case 0x0601B4FEu: goto L_0601B4FE; case 0x0601B500u: goto L_0601B500; case 0x0601B502u: goto L_0601B502; case 0x0601B504u: goto L_0601B504; case 0x0601B506u: goto L_0601B506; case 0x0601B508u: goto L_0601B508; case 0x0601B50Au: goto L_0601B50A; case 0x0601B50Cu: goto L_0601B50C; case 0x0601B50Eu: goto L_0601B50E; case 0x0601B510u: goto L_0601B510; case 0x0601B512u: goto L_0601B512; case 0x0601B516u: goto L_0601B516; case 0x0601B51Au: goto L_0601B51A; case 0x0601B51Cu: goto L_0601B51C; case 0x0601B51Eu: goto L_0601B51E; case 0x0601B520u: goto L_0601B520; case 0x0601B522u: goto L_0601B522; case 0x0601B524u: goto L_0601B524; case 0x0601B526u: goto L_0601B526; case 0x0601B528u: goto L_0601B528; case 0x0601B52Au: goto L_0601B52A; case 0x0601B52Cu: goto L_0601B52C; case 0x0601B530u: goto L_0601B530; case 0x0601B532u: goto L_0601B532; case 0x0601B534u: goto L_0601B534; case 0x0601B536u: goto L_0601B536; case 0x0601B538u: goto L_0601B538; case 0x0601B53Au: goto L_0601B53A; case 0x0601B53Cu: goto L_0601B53C; case 0x0601B53Eu: goto L_0601B53E; case 0x0601B540u: goto L_0601B540; case 0x0601B542u: goto L_0601B542; case 0x0601B544u: goto L_0601B544; case 0x0601B546u: goto L_0601B546; case 0x0601B548u: goto L_0601B548; case 0x0601B54Au: goto L_0601B54A; case 0x0601B54Cu: goto L_0601B54C; case 0x0601B54Eu: goto L_0601B54E; case 0x0601B550u: goto L_0601B550; case 0x0601B552u: goto L_0601B552; case 0x0601B554u: goto L_0601B554; case 0x0601B556u: goto L_0601B556; case 0x0601B558u: goto L_0601B558; case 0x0601B57Cu: goto L_0601B57C; case 0x0601B57Eu: goto L_0601B57E; case 0x0601B580u: goto L_0601B580; case 0x0601B582u: goto L_0601B582; case 0x0601B584u: goto L_0601B584; case 0x0601B586u: goto L_0601B586; case 0x0601B588u: goto L_0601B588; case 0x0601B58Au: goto L_0601B58A; case 0x0601B58Cu: goto L_0601B58C; case 0x0601B58Eu: goto L_0601B58E; case 0x0601B590u: goto L_0601B590; case 0x0601B592u: goto L_0601B592; case 0x0601B594u: goto L_0601B594; case 0x0601B596u: goto L_0601B596; case 0x0601B598u: goto L_0601B598; case 0x0601B59Au: goto L_0601B59A; case 0x0601B59Cu: goto L_0601B59C; case 0x0601B59Eu: goto L_0601B59E; case 0x0601B5A0u: goto L_0601B5A0; case 0x0601B5A4u: goto L_0601B5A4; case 0x0601B5A6u: goto L_0601B5A6; case 0x0601B5A8u: goto L_0601B5A8; case 0x0601B5AAu: goto L_0601B5AA; case 0x0601B5ACu: goto L_0601B5AC; case 0x0601B5B0u: goto L_0601B5B0; case 0x0601B5B2u: goto L_0601B5B2; case 0x0601B5B4u: goto L_0601B5B4; case 0x0601B5B6u: goto L_0601B5B6; case 0x0601B5B8u: goto L_0601B5B8; case 0x0601B5BAu: goto L_0601B5BA; case 0x0601B5BEu: goto L_0601B5BE; case 0x0601B5C0u: goto L_0601B5C0; case 0x0601B5C2u: goto L_0601B5C2; case 0x0601B5C4u: goto L_0601B5C4; case 0x0601B5C6u: goto L_0601B5C6; case 0x0601B5C8u: goto L_0601B5C8; case 0x0601B5CAu: goto L_0601B5CA; case 0x0601B5CCu: goto L_0601B5CC; case 0x0601B5CEu: goto L_0601B5CE; case 0x0601B5D0u: goto L_0601B5D0; case 0x0601B5D2u: goto L_0601B5D2; case 0x0601B5D4u: goto L_0601B5D4; case 0x0601B5D6u: goto L_0601B5D6; case 0x0601B5D8u: goto L_0601B5D8; case 0x0601B5DAu: goto L_0601B5DA; case 0x0601B5DCu: goto L_0601B5DC; case 0x0601B5DEu: goto L_0601B5DE; case 0x0601B5E2u: goto L_0601B5E2; case 0x0601B5E4u: goto L_0601B5E4; case 0x0601B5E6u: goto L_0601B5E6; case 0x0601B5E8u: goto L_0601B5E8; case 0x0601B5EAu: goto L_0601B5EA; case 0x0601B5ECu: goto L_0601B5EC; case 0x0601B5EEu: goto L_0601B5EE; case 0x0601B5F0u: goto L_0601B5F0; case 0x0601B5F2u: goto L_0601B5F2; case 0x0601B5F4u: goto L_0601B5F4; case 0x0601B5F6u: goto L_0601B5F6; case 0x0601B5F8u: goto L_0601B5F8; case 0x0601B5FAu: goto L_0601B5FA; case 0x0601B5FCu: goto L_0601B5FC; case 0x0601B5FEu: goto L_0601B5FE; case 0x0601B602u: goto L_0601B602; case 0x0601B604u: goto L_0601B604; case 0x0601B608u: goto L_0601B608; case 0x0601B60Cu: goto L_0601B60C; case 0x0601B60Eu: goto L_0601B60E; case 0x0601B610u: goto L_0601B610; case 0x0601B612u: goto L_0601B612; case 0x0601B614u: goto L_0601B614; case 0x0601B616u: goto L_0601B616; case 0x0601B618u: goto L_0601B618; case 0x0601B61Au: goto L_0601B61A; case 0x0601B61Cu: goto L_0601B61C; case 0x0601B61Eu: goto L_0601B61E; case 0x0601B620u: goto L_0601B620; case 0x0601B622u: goto L_0601B622; case 0x0601B624u: goto L_0601B624; case 0x0601B626u: goto L_0601B626; case 0x0601B628u: goto L_0601B628; case 0x0601B62Au: goto L_0601B62A; case 0x0601B62Cu: goto L_0601B62C; case 0x0601B62Eu: goto L_0601B62E; case 0x0601B630u: goto L_0601B630; case 0x0601B632u: goto L_0601B632; case 0x0601B634u: goto L_0601B634; case 0x0601B636u: goto L_0601B636; case 0x0601B638u: goto L_0601B638; case 0x0601B63Au: goto L_0601B63A; case 0x0601B63Cu: goto L_0601B63C; case 0x0601B63Eu: goto L_0601B63E; case 0x0601B640u: goto L_0601B640; case 0x0601B642u: goto L_0601B642; case 0x0601B644u: goto L_0601B644; case 0x0601B646u: goto L_0601B646; case 0x0601B648u: goto L_0601B648; case 0x0601B64Au: goto L_0601B64A; case 0x0601B64Cu: goto L_0601B64C; case 0x0601B64Eu: goto L_0601B64E; case 0x0601B650u: goto L_0601B650; case 0x0601B652u: goto L_0601B652; case 0x0601B654u: goto L_0601B654; case 0x0601B656u: goto L_0601B656; case 0x0601B658u: goto L_0601B658; case 0x0601B65Au: goto L_0601B65A; case 0x0601B65Cu: goto L_0601B65C; case 0x0601B65Eu: goto L_0601B65E; case 0x0601B660u: goto L_0601B660; case 0x0601B664u: goto L_0601B664; case 0x0601B666u: goto L_0601B666; case 0x0601B66Au: goto L_0601B66A; case 0x0601B66Cu: goto L_0601B66C; case 0x0601B66Eu: goto L_0601B66E; case 0x0601B670u: goto L_0601B670; case 0x0601B672u: goto L_0601B672; case 0x0601B674u: goto L_0601B674; case 0x0601B676u: goto L_0601B676; case 0x0601B678u: goto L_0601B678; case 0x0601B67Au: goto L_0601B67A; case 0x0601B67Eu: goto L_0601B67E; case 0x0601B682u: goto L_0601B682; case 0x0601B684u: goto L_0601B684; case 0x0601B688u: goto L_0601B688; case 0x0601B68Au: goto L_0601B68A; case 0x0601B68Cu: goto L_0601B68C; case 0x0601B68Eu: goto L_0601B68E; case 0x0601B690u: goto L_0601B690; case 0x0601B692u: goto L_0601B692; case 0x0601B696u: goto L_0601B696; case 0x0601B698u: goto L_0601B698; case 0x0601B69Au: goto L_0601B69A; case 0x0601B69Cu: goto L_0601B69C; case 0x0601B69Eu: goto L_0601B69E; case 0x0601B6A0u: goto L_0601B6A0; case 0x0601B6A4u: goto L_0601B6A4; case 0x0601B6A6u: goto L_0601B6A6; case 0x0601B6A8u: goto L_0601B6A8; case 0x0601B6AAu: goto L_0601B6AA; case 0x0601B6ACu: goto L_0601B6AC; case 0x0601B6AEu: goto L_0601B6AE; case 0x0601B6B0u: goto L_0601B6B0; case 0x0601B6B2u: goto L_0601B6B2; case 0x0601B6B4u: goto L_0601B6B4; case 0x0601B6B6u: goto L_0601B6B6; case 0x0601B6B8u: goto L_0601B6B8; case 0x0601B6BAu: goto L_0601B6BA; case 0x0601B6BCu: goto L_0601B6BC; case 0x0601B6BEu: goto L_0601B6BE; case 0x0601B6C0u: goto L_0601B6C0; case 0x0601B6C2u: goto L_0601B6C2; case 0x0601B6C4u: goto L_0601B6C4; case 0x0601B6C8u: goto L_0601B6C8; case 0x0601B6CAu: goto L_0601B6CA; case 0x0601B6CEu: goto L_0601B6CE; case 0x0601B6D0u: goto L_0601B6D0; case 0x0601B6D2u: goto L_0601B6D2; case 0x0601B6D4u: goto L_0601B6D4; case 0x0601B6D6u: goto L_0601B6D6; case 0x0601B6D8u: goto L_0601B6D8; case 0x0601B6DAu: goto L_0601B6DA; case 0x0601B6DCu: goto L_0601B6DC; case 0x0601B6DEu: goto L_0601B6DE; case 0x0601B6E0u: goto L_0601B6E0; case 0x0607ECBEu: goto L_0607ECBE; case 0x0607ECC0u: goto L_0607ECC0; case 0x0607ECC2u: goto L_0607ECC2; case 0x0607ECC4u: goto L_0607ECC4; case 0x0607ECC6u: goto L_0607ECC6; case 0x0607ECC8u: goto L_0607ECC8; case 0x0607ECCAu: goto L_0607ECCA; case 0x0607ECCCu: goto L_0607ECCC; case 0x0607ECCEu: goto L_0607ECCE; case 0x0607ECD0u: goto L_0607ECD0; case 0x0607ECD2u: goto L_0607ECD2; case 0x0607ECD6u: goto L_0607ECD6; case 0x0607ECD8u: goto L_0607ECD8; case 0x0607ECDAu: goto L_0607ECDA; case 0x0607ECDCu: goto L_0607ECDC; case 0x0607ECDEu: goto L_0607ECDE; case 0x0607ECE0u: goto L_0607ECE0; case 0x0607ECE4u: goto L_0607ECE4; case 0x0607ECE8u: goto L_0607ECE8; case 0x0607ECEAu: goto L_0607ECEA; case 0x0607EE54u: goto L_0607EE54; case 0x0607EE56u: goto L_0607EE56; case 0x0607EE58u: goto L_0607EE58; case 0x0607EE5Au: goto L_0607EE5A; case 0x0607EE5Cu: goto L_0607EE5C; case 0x0607EE5Eu: goto L_0607EE5E; case 0x0607EE60u: goto L_0607EE60; case 0x0607EE62u: goto L_0607EE62; case 0x0608431Eu: goto L_0608431E; case 0x06084320u: goto L_06084320; case 0x06084322u: goto L_06084322; case 0x06084324u: goto L_06084324; case 0x06084326u: goto L_06084326; case 0x06084328u: goto L_06084328; case 0x0608432Au: goto L_0608432A; case 0x0608432Cu: goto L_0608432C; case 0x06084330u: goto L_06084330; case 0x06084332u: goto L_06084332; case 0x06084334u: goto L_06084334; case 0x06084336u: goto L_06084336; case 0x06084338u: goto L_06084338; case 0x0608433Au: goto L_0608433A; case 0x0608433Cu: goto L_0608433C; case 0x0608433Eu: goto L_0608433E; case 0x06084340u: goto L_06084340; case 0x06084342u: goto L_06084342; case 0x06084344u: goto L_06084344; case 0x06084346u: goto L_06084346; case 0x06084348u: goto L_06084348; case 0x0608434Au: goto L_0608434A; case 0x0608434Cu: goto L_0608434C; case 0x0608434Eu: goto L_0608434E; case 0x06084350u: goto L_06084350; case 0x06084352u: goto L_06084352; case 0x06084354u: goto L_06084354; case 0x06084356u: goto L_06084356; case 0x06084358u: goto L_06084358; case 0x0608435Au: goto L_0608435A; case 0x0608435Cu: goto L_0608435C; case 0x0608435Eu: goto L_0608435E; case 0x06084362u: goto L_06084362; case 0x06084364u: goto L_06084364; default: sh2_call(c, x); return; } }  // 0608435E jmp @r0 ; nop
L_06084362:
    c.r[0] = ld32(0x060843D8u);  // 06084362 mov.l 0x060843D8,r0
L_06084364:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x0601B124u: goto L_0601B124; case 0x0601B126u: goto L_0601B126; case 0x0601B128u: goto L_0601B128; case 0x0601B12Au: goto L_0601B12A; case 0x0601B12Cu: goto L_0601B12C; case 0x0601B12Eu: goto L_0601B12E; case 0x0601B130u: goto L_0601B130; case 0x0601B132u: goto L_0601B132; case 0x0601B134u: goto L_0601B134; case 0x0601B136u: goto L_0601B136; case 0x0601B138u: goto L_0601B138; case 0x0601B13Au: goto L_0601B13A; case 0x0601B13Eu: goto L_0601B13E; case 0x0601B140u: goto L_0601B140; case 0x0601B144u: goto L_0601B144; case 0x0601B146u: goto L_0601B146; case 0x0601B148u: goto L_0601B148; case 0x0601B14Au: goto L_0601B14A; case 0x0601B14Cu: goto L_0601B14C; case 0x0601B14Eu: goto L_0601B14E; case 0x0601B150u: goto L_0601B150; case 0x0601B152u: goto L_0601B152; case 0x0601B156u: goto L_0601B156; case 0x0601B158u: goto L_0601B158; case 0x0601B15Au: goto L_0601B15A; case 0x0601B15Cu: goto L_0601B15C; case 0x0601B15Eu: goto L_0601B15E; case 0x0601B162u: goto L_0601B162; case 0x0601B164u: goto L_0601B164; case 0x0601B166u: goto L_0601B166; case 0x0601B168u: goto L_0601B168; case 0x0601B16Au: goto L_0601B16A; case 0x0601B16Cu: goto L_0601B16C; case 0x0601B16Eu: goto L_0601B16E; case 0x0601B170u: goto L_0601B170; case 0x0601B172u: goto L_0601B172; case 0x0601B176u: goto L_0601B176; case 0x0601B178u: goto L_0601B178; case 0x0601B17Au: goto L_0601B17A; case 0x0601B17Cu: goto L_0601B17C; case 0x0601B17Eu: goto L_0601B17E; case 0x0601B180u: goto L_0601B180; case 0x0601B182u: goto L_0601B182; case 0x0601B184u: goto L_0601B184; case 0x0601B188u: goto L_0601B188; case 0x0601B18Au: goto L_0601B18A; case 0x0601B18Cu: goto L_0601B18C; case 0x0601B190u: goto L_0601B190; case 0x0601B194u: goto L_0601B194; case 0x0601B196u: goto L_0601B196; case 0x0601B198u: goto L_0601B198; case 0x0601B19Au: goto L_0601B19A; case 0x0601B19Cu: goto L_0601B19C; case 0x0601B19Eu: goto L_0601B19E; case 0x0601B1A0u: goto L_0601B1A0; case 0x0601B1A2u: goto L_0601B1A2; case 0x0601B1A4u: goto L_0601B1A4; case 0x0601B1A6u: goto L_0601B1A6; case 0x0601B1A8u: goto L_0601B1A8; case 0x0601B1AAu: goto L_0601B1AA; case 0x0601B1ACu: goto L_0601B1AC; case 0x0601B1B0u: goto L_0601B1B0; case 0x0601B1B2u: goto L_0601B1B2; case 0x0601B1B4u: goto L_0601B1B4; case 0x0601B1B6u: goto L_0601B1B6; case 0x0601B1B8u: goto L_0601B1B8; case 0x0601B1BAu: goto L_0601B1BA; case 0x0601B1BCu: goto L_0601B1BC; case 0x0601B1BEu: goto L_0601B1BE; case 0x0601B1C0u: goto L_0601B1C0; case 0x0601B1C2u: goto L_0601B1C2; case 0x0601B1C4u: goto L_0601B1C4; case 0x0601B1C8u: goto L_0601B1C8; case 0x0601B1CAu: goto L_0601B1CA; case 0x0601B1CCu: goto L_0601B1CC; case 0x0601B1CEu: goto L_0601B1CE; case 0x0601B1D0u: goto L_0601B1D0; case 0x0601B1D2u: goto L_0601B1D2; case 0x0601B1D4u: goto L_0601B1D4; case 0x0601B1D6u: goto L_0601B1D6; case 0x0601B1D8u: goto L_0601B1D8; case 0x0601B1DAu: goto L_0601B1DA; case 0x0601B1DCu: goto L_0601B1DC; case 0x0601B1DEu: goto L_0601B1DE; case 0x0601B1E0u: goto L_0601B1E0; case 0x0601B1E2u: goto L_0601B1E2; case 0x0601B1E4u: goto L_0601B1E4; case 0x0601B1E6u: goto L_0601B1E6; case 0x0601B1E8u: goto L_0601B1E8; case 0x0601B1EAu: goto L_0601B1EA; case 0x0601B1ECu: goto L_0601B1EC; case 0x0601B1EEu: goto L_0601B1EE; case 0x0601B1F0u: goto L_0601B1F0; case 0x0601B1F2u: goto L_0601B1F2; case 0x0601B1F4u: goto L_0601B1F4; case 0x0601B1F6u: goto L_0601B1F6; case 0x0601B1F8u: goto L_0601B1F8; case 0x0601B1FAu: goto L_0601B1FA; case 0x0601B1FCu: goto L_0601B1FC; case 0x0601B1FEu: goto L_0601B1FE; case 0x0601B200u: goto L_0601B200; case 0x0601B202u: goto L_0601B202; case 0x0601B204u: goto L_0601B204; case 0x0601B206u: goto L_0601B206; case 0x0601B208u: goto L_0601B208; case 0x0601B20Au: goto L_0601B20A; case 0x0601B20Cu: goto L_0601B20C; case 0x0601B20Eu: goto L_0601B20E; case 0x0601B210u: goto L_0601B210; case 0x0601B214u: goto L_0601B214; case 0x0601B216u: goto L_0601B216; case 0x0601B218u: goto L_0601B218; case 0x0601B21Au: goto L_0601B21A; case 0x0601B21Cu: goto L_0601B21C; case 0x0601B21Eu: goto L_0601B21E; case 0x0601B220u: goto L_0601B220; case 0x0601B222u: goto L_0601B222; case 0x0601B224u: goto L_0601B224; case 0x0601B228u: goto L_0601B228; case 0x0601B22Au: goto L_0601B22A; case 0x0601B22Eu: goto L_0601B22E; case 0x0601B260u: goto L_0601B260; case 0x0601B262u: goto L_0601B262; case 0x0601B264u: goto L_0601B264; case 0x0601B266u: goto L_0601B266; case 0x0601B268u: goto L_0601B268; case 0x0601B26Au: goto L_0601B26A; case 0x0601B26Cu: goto L_0601B26C; case 0x0601B26Eu: goto L_0601B26E; case 0x0601B270u: goto L_0601B270; case 0x0601B272u: goto L_0601B272; case 0x0601B274u: goto L_0601B274; case 0x0601B276u: goto L_0601B276; case 0x0601B278u: goto L_0601B278; case 0x0601B27Au: goto L_0601B27A; case 0x0601B27Cu: goto L_0601B27C; case 0x0601B27Eu: goto L_0601B27E; case 0x0601B280u: goto L_0601B280; case 0x0601B284u: goto L_0601B284; case 0x0601B286u: goto L_0601B286; case 0x0601B288u: goto L_0601B288; case 0x0601B28Au: goto L_0601B28A; case 0x0601B28Cu: goto L_0601B28C; case 0x0601B28Eu: goto L_0601B28E; case 0x0601B290u: goto L_0601B290; case 0x0601B292u: goto L_0601B292; case 0x0601B296u: goto L_0601B296; case 0x0601B298u: goto L_0601B298; case 0x0601B29Au: goto L_0601B29A; case 0x0601B29Eu: goto L_0601B29E; case 0x0601B2A0u: goto L_0601B2A0; case 0x0601B2A2u: goto L_0601B2A2; case 0x0601B2A4u: goto L_0601B2A4; case 0x0601B2A6u: goto L_0601B2A6; case 0x0601B2A8u: goto L_0601B2A8; case 0x0601B2AAu: goto L_0601B2AA; case 0x0601B2ACu: goto L_0601B2AC; case 0x0601B2AEu: goto L_0601B2AE; case 0x0601B2B0u: goto L_0601B2B0; case 0x0601B2B4u: goto L_0601B2B4; case 0x0601B2B8u: goto L_0601B2B8; case 0x0601B2BAu: goto L_0601B2BA; case 0x0601B2BCu: goto L_0601B2BC; case 0x0601B2BEu: goto L_0601B2BE; case 0x0601B2C0u: goto L_0601B2C0; case 0x0601B2C2u: goto L_0601B2C2; case 0x0601B2C4u: goto L_0601B2C4; case 0x0601B2C6u: goto L_0601B2C6; case 0x0601B2C8u: goto L_0601B2C8; case 0x0601B2CAu: goto L_0601B2CA; case 0x0601B2CCu: goto L_0601B2CC; case 0x0601B2CEu: goto L_0601B2CE; case 0x0601B2D0u: goto L_0601B2D0; case 0x0601B2D2u: goto L_0601B2D2; case 0x0601B2D4u: goto L_0601B2D4; case 0x0601B2D6u: goto L_0601B2D6; case 0x0601B2D8u: goto L_0601B2D8; case 0x0601B2DAu: goto L_0601B2DA; case 0x0601B2DEu: goto L_0601B2DE; case 0x0601B2E0u: goto L_0601B2E0; case 0x0601B2E2u: goto L_0601B2E2; case 0x0601B2E4u: goto L_0601B2E4; case 0x0601B2E6u: goto L_0601B2E6; case 0x0601B2E8u: goto L_0601B2E8; case 0x0601B2EAu: goto L_0601B2EA; case 0x0601B2ECu: goto L_0601B2EC; case 0x0601B2EEu: goto L_0601B2EE; case 0x0601B2F0u: goto L_0601B2F0; case 0x0601B2F2u: goto L_0601B2F2; case 0x0601B2F4u: goto L_0601B2F4; case 0x0601B2F6u: goto L_0601B2F6; case 0x0601B2F8u: goto L_0601B2F8; case 0x0601B2FAu: goto L_0601B2FA; case 0x0601B2FCu: goto L_0601B2FC; case 0x0601B2FEu: goto L_0601B2FE; case 0x0601B300u: goto L_0601B300; case 0x0601B302u: goto L_0601B302; case 0x0601B306u: goto L_0601B306; case 0x0601B308u: goto L_0601B308; case 0x0601B30Au: goto L_0601B30A; case 0x0601B30Cu: goto L_0601B30C; case 0x0601B30Eu: goto L_0601B30E; case 0x0601B312u: goto L_0601B312; case 0x0601B314u: goto L_0601B314; case 0x0601B316u: goto L_0601B316; case 0x0601B318u: goto L_0601B318; case 0x0601B31Au: goto L_0601B31A; case 0x0601B31Cu: goto L_0601B31C; case 0x0601B320u: goto L_0601B320; case 0x0601B322u: goto L_0601B322; case 0x0601B324u: goto L_0601B324; case 0x0601B326u: goto L_0601B326; case 0x0601B328u: goto L_0601B328; case 0x0601B32Cu: goto L_0601B32C; case 0x0601B32Eu: goto L_0601B32E; case 0x0601B330u: goto L_0601B330; case 0x0601B332u: goto L_0601B332; case 0x0601B334u: goto L_0601B334; case 0x0601B336u: goto L_0601B336; case 0x0601B338u: goto L_0601B338; case 0x0601B33Au: goto L_0601B33A; case 0x0601B33Cu: goto L_0601B33C; case 0x0601B340u: goto L_0601B340; case 0x0601B342u: goto L_0601B342; case 0x0601B346u: goto L_0601B346; case 0x0601B348u: goto L_0601B348; case 0x0601B34Au: goto L_0601B34A; case 0x0601B34Eu: goto L_0601B34E; case 0x0601B350u: goto L_0601B350; case 0x0601B352u: goto L_0601B352; case 0x0601B354u: goto L_0601B354; case 0x0601B356u: goto L_0601B356; case 0x0601B358u: goto L_0601B358; case 0x0601B35Au: goto L_0601B35A; case 0x0601B35Cu: goto L_0601B35C; case 0x0601B35Eu: goto L_0601B35E; case 0x0601B360u: goto L_0601B360; case 0x0601B362u: goto L_0601B362; case 0x0601B364u: goto L_0601B364; case 0x0601B366u: goto L_0601B366; case 0x0601B368u: goto L_0601B368; case 0x0601B36Au: goto L_0601B36A; case 0x0601B36Cu: goto L_0601B36C; case 0x0601B36Eu: goto L_0601B36E; case 0x0601B370u: goto L_0601B370; case 0x0601B372u: goto L_0601B372; case 0x0601B374u: goto L_0601B374; case 0x0601B376u: goto L_0601B376; case 0x0601B378u: goto L_0601B378; case 0x0601B37Au: goto L_0601B37A; case 0x0601B37Eu: goto L_0601B37E; case 0x0601B380u: goto L_0601B380; case 0x0601B382u: goto L_0601B382; case 0x0601B384u: goto L_0601B384; case 0x0601B386u: goto L_0601B386; case 0x0601B388u: goto L_0601B388; case 0x0601B38Au: goto L_0601B38A; case 0x0601B38Cu: goto L_0601B38C; case 0x0601B38Eu: goto L_0601B38E; case 0x0601B392u: goto L_0601B392; case 0x0601B394u: goto L_0601B394; case 0x0601B398u: goto L_0601B398; case 0x0601B39Cu: goto L_0601B39C; case 0x0601B39Eu: goto L_0601B39E; case 0x0601B3A0u: goto L_0601B3A0; case 0x0601B3A2u: goto L_0601B3A2; case 0x0601B3A4u: goto L_0601B3A4; case 0x0601B3A6u: goto L_0601B3A6; case 0x0601B3A8u: goto L_0601B3A8; case 0x0601B3AAu: goto L_0601B3AA; case 0x0601B3ACu: goto L_0601B3AC; case 0x0601B3AEu: goto L_0601B3AE; case 0x0601B3B0u: goto L_0601B3B0; case 0x0601B3B2u: goto L_0601B3B2; case 0x0601B3B4u: goto L_0601B3B4; case 0x0601B3B6u: goto L_0601B3B6; case 0x0601B3B8u: goto L_0601B3B8; case 0x0601B3BAu: goto L_0601B3BA; case 0x0601B3BCu: goto L_0601B3BC; case 0x0601B3BEu: goto L_0601B3BE; case 0x0601B3C0u: goto L_0601B3C0; case 0x0601B3C2u: goto L_0601B3C2; case 0x0601B3C4u: goto L_0601B3C4; case 0x0601B3C6u: goto L_0601B3C6; case 0x0601B3C8u: goto L_0601B3C8; case 0x0601B3CAu: goto L_0601B3CA; case 0x0601B3CCu: goto L_0601B3CC; case 0x0601B3CEu: goto L_0601B3CE; case 0x0601B3D0u: goto L_0601B3D0; case 0x0601B3D2u: goto L_0601B3D2; case 0x0601B3D4u: goto L_0601B3D4; case 0x0601B3D6u: goto L_0601B3D6; case 0x0601B3D8u: goto L_0601B3D8; case 0x0601B3DAu: goto L_0601B3DA; case 0x0601B3DCu: goto L_0601B3DC; case 0x0601B3DEu: goto L_0601B3DE; case 0x0601B3E0u: goto L_0601B3E0; case 0x0601B3E2u: goto L_0601B3E2; case 0x0601B3E4u: goto L_0601B3E4; case 0x0601B3E6u: goto L_0601B3E6; case 0x0601B3E8u: goto L_0601B3E8; case 0x0601B3EAu: goto L_0601B3EA; case 0x0601B3ECu: goto L_0601B3EC; case 0x0601B3EEu: goto L_0601B3EE; case 0x0601B3F2u: goto L_0601B3F2; case 0x0601B3F4u: goto L_0601B3F4; case 0x0601B3F6u: goto L_0601B3F6; case 0x0601B3FAu: goto L_0601B3FA; case 0x0601B3FCu: goto L_0601B3FC; case 0x0601B3FEu: goto L_0601B3FE; case 0x0601B400u: goto L_0601B400; case 0x0601B402u: goto L_0601B402; case 0x0601B406u: goto L_0601B406; case 0x0601B408u: goto L_0601B408; case 0x0601B40Au: goto L_0601B40A; case 0x0601B40Cu: goto L_0601B40C; case 0x0601B410u: goto L_0601B410; case 0x0601B412u: goto L_0601B412; case 0x0601B414u: goto L_0601B414; case 0x0601B416u: goto L_0601B416; case 0x0601B418u: goto L_0601B418; case 0x0601B41Au: goto L_0601B41A; case 0x0601B41Cu: goto L_0601B41C; case 0x0601B41Eu: goto L_0601B41E; case 0x0601B420u: goto L_0601B420; case 0x0601B424u: goto L_0601B424; case 0x0601B426u: goto L_0601B426; case 0x0601B428u: goto L_0601B428; case 0x0601B42Au: goto L_0601B42A; case 0x0601B42Cu: goto L_0601B42C; case 0x0601B42Eu: goto L_0601B42E; case 0x0601B430u: goto L_0601B430; case 0x0601B458u: goto L_0601B458; case 0x0601B45Au: goto L_0601B45A; case 0x0601B45Cu: goto L_0601B45C; case 0x0601B45Eu: goto L_0601B45E; case 0x0601B460u: goto L_0601B460; case 0x0601B462u: goto L_0601B462; case 0x0601B464u: goto L_0601B464; case 0x0601B466u: goto L_0601B466; case 0x0601B46Au: goto L_0601B46A; case 0x0601B46Cu: goto L_0601B46C; case 0x0601B470u: goto L_0601B470; case 0x0601B472u: goto L_0601B472; case 0x0601B474u: goto L_0601B474; case 0x0601B476u: goto L_0601B476; case 0x0601B478u: goto L_0601B478; case 0x0601B47Au: goto L_0601B47A; case 0x0601B47Cu: goto L_0601B47C; case 0x0601B47Eu: goto L_0601B47E; case 0x0601B480u: goto L_0601B480; case 0x0601B482u: goto L_0601B482; case 0x0601B486u: goto L_0601B486; case 0x0601B488u: goto L_0601B488; case 0x0601B48Au: goto L_0601B48A; case 0x0601B48Cu: goto L_0601B48C; case 0x0601B48Eu: goto L_0601B48E; case 0x0601B490u: goto L_0601B490; case 0x0601B492u: goto L_0601B492; case 0x0601B494u: goto L_0601B494; case 0x0601B496u: goto L_0601B496; case 0x0601B49Au: goto L_0601B49A; case 0x0601B49Cu: goto L_0601B49C; case 0x0601B49Eu: goto L_0601B49E; case 0x0601B4A2u: goto L_0601B4A2; case 0x0601B4A4u: goto L_0601B4A4; case 0x0601B4A6u: goto L_0601B4A6; case 0x0601B4AAu: goto L_0601B4AA; case 0x0601B4ACu: goto L_0601B4AC; case 0x0601B4AEu: goto L_0601B4AE; case 0x0601B4B0u: goto L_0601B4B0; case 0x0601B4B2u: goto L_0601B4B2; case 0x0601B4B4u: goto L_0601B4B4; case 0x0601B4B6u: goto L_0601B4B6; case 0x0601B4B8u: goto L_0601B4B8; case 0x0601B4BAu: goto L_0601B4BA; case 0x0601B4BCu: goto L_0601B4BC; case 0x0601B4BEu: goto L_0601B4BE; case 0x0601B4C0u: goto L_0601B4C0; case 0x0601B4C2u: goto L_0601B4C2; case 0x0601B4C4u: goto L_0601B4C4; case 0x0601B4C6u: goto L_0601B4C6; case 0x0601B4C8u: goto L_0601B4C8; case 0x0601B4CAu: goto L_0601B4CA; case 0x0601B4CCu: goto L_0601B4CC; case 0x0601B4CEu: goto L_0601B4CE; case 0x0601B4D0u: goto L_0601B4D0; case 0x0601B4D2u: goto L_0601B4D2; case 0x0601B4D6u: goto L_0601B4D6; case 0x0601B4D8u: goto L_0601B4D8; case 0x0601B4DAu: goto L_0601B4DA; case 0x0601B4DCu: goto L_0601B4DC; case 0x0601B4DEu: goto L_0601B4DE; case 0x0601B4E0u: goto L_0601B4E0; case 0x0601B4E2u: goto L_0601B4E2; case 0x0601B4E4u: goto L_0601B4E4; case 0x0601B4E6u: goto L_0601B4E6; case 0x0601B4EAu: goto L_0601B4EA; case 0x0601B4ECu: goto L_0601B4EC; case 0x0601B4F0u: goto L_0601B4F0; case 0x0601B4F4u: goto L_0601B4F4; case 0x0601B4F6u: goto L_0601B4F6; case 0x0601B4F8u: goto L_0601B4F8; case 0x0601B4FAu: goto L_0601B4FA; case 0x0601B4FCu: goto L_0601B4FC; case 0x0601B4FEu: goto L_0601B4FE; case 0x0601B500u: goto L_0601B500; case 0x0601B502u: goto L_0601B502; case 0x0601B504u: goto L_0601B504; case 0x0601B506u: goto L_0601B506; case 0x0601B508u: goto L_0601B508; case 0x0601B50Au: goto L_0601B50A; case 0x0601B50Cu: goto L_0601B50C; case 0x0601B50Eu: goto L_0601B50E; case 0x0601B510u: goto L_0601B510; case 0x0601B512u: goto L_0601B512; case 0x0601B516u: goto L_0601B516; case 0x0601B51Au: goto L_0601B51A; case 0x0601B51Cu: goto L_0601B51C; case 0x0601B51Eu: goto L_0601B51E; case 0x0601B520u: goto L_0601B520; case 0x0601B522u: goto L_0601B522; case 0x0601B524u: goto L_0601B524; case 0x0601B526u: goto L_0601B526; case 0x0601B528u: goto L_0601B528; case 0x0601B52Au: goto L_0601B52A; case 0x0601B52Cu: goto L_0601B52C; case 0x0601B530u: goto L_0601B530; case 0x0601B532u: goto L_0601B532; case 0x0601B534u: goto L_0601B534; case 0x0601B536u: goto L_0601B536; case 0x0601B538u: goto L_0601B538; case 0x0601B53Au: goto L_0601B53A; case 0x0601B53Cu: goto L_0601B53C; case 0x0601B53Eu: goto L_0601B53E; case 0x0601B540u: goto L_0601B540; case 0x0601B542u: goto L_0601B542; case 0x0601B544u: goto L_0601B544; case 0x0601B546u: goto L_0601B546; case 0x0601B548u: goto L_0601B548; case 0x0601B54Au: goto L_0601B54A; case 0x0601B54Cu: goto L_0601B54C; case 0x0601B54Eu: goto L_0601B54E; case 0x0601B550u: goto L_0601B550; case 0x0601B552u: goto L_0601B552; case 0x0601B554u: goto L_0601B554; case 0x0601B556u: goto L_0601B556; case 0x0601B558u: goto L_0601B558; case 0x0601B57Cu: goto L_0601B57C; case 0x0601B57Eu: goto L_0601B57E; case 0x0601B580u: goto L_0601B580; case 0x0601B582u: goto L_0601B582; case 0x0601B584u: goto L_0601B584; case 0x0601B586u: goto L_0601B586; case 0x0601B588u: goto L_0601B588; case 0x0601B58Au: goto L_0601B58A; case 0x0601B58Cu: goto L_0601B58C; case 0x0601B58Eu: goto L_0601B58E; case 0x0601B590u: goto L_0601B590; case 0x0601B592u: goto L_0601B592; case 0x0601B594u: goto L_0601B594; case 0x0601B596u: goto L_0601B596; case 0x0601B598u: goto L_0601B598; case 0x0601B59Au: goto L_0601B59A; case 0x0601B59Cu: goto L_0601B59C; case 0x0601B59Eu: goto L_0601B59E; case 0x0601B5A0u: goto L_0601B5A0; case 0x0601B5A4u: goto L_0601B5A4; case 0x0601B5A6u: goto L_0601B5A6; case 0x0601B5A8u: goto L_0601B5A8; case 0x0601B5AAu: goto L_0601B5AA; case 0x0601B5ACu: goto L_0601B5AC; case 0x0601B5B0u: goto L_0601B5B0; case 0x0601B5B2u: goto L_0601B5B2; case 0x0601B5B4u: goto L_0601B5B4; case 0x0601B5B6u: goto L_0601B5B6; case 0x0601B5B8u: goto L_0601B5B8; case 0x0601B5BAu: goto L_0601B5BA; case 0x0601B5BEu: goto L_0601B5BE; case 0x0601B5C0u: goto L_0601B5C0; case 0x0601B5C2u: goto L_0601B5C2; case 0x0601B5C4u: goto L_0601B5C4; case 0x0601B5C6u: goto L_0601B5C6; case 0x0601B5C8u: goto L_0601B5C8; case 0x0601B5CAu: goto L_0601B5CA; case 0x0601B5CCu: goto L_0601B5CC; case 0x0601B5CEu: goto L_0601B5CE; case 0x0601B5D0u: goto L_0601B5D0; case 0x0601B5D2u: goto L_0601B5D2; case 0x0601B5D4u: goto L_0601B5D4; case 0x0601B5D6u: goto L_0601B5D6; case 0x0601B5D8u: goto L_0601B5D8; case 0x0601B5DAu: goto L_0601B5DA; case 0x0601B5DCu: goto L_0601B5DC; case 0x0601B5DEu: goto L_0601B5DE; case 0x0601B5E2u: goto L_0601B5E2; case 0x0601B5E4u: goto L_0601B5E4; case 0x0601B5E6u: goto L_0601B5E6; case 0x0601B5E8u: goto L_0601B5E8; case 0x0601B5EAu: goto L_0601B5EA; case 0x0601B5ECu: goto L_0601B5EC; case 0x0601B5EEu: goto L_0601B5EE; case 0x0601B5F0u: goto L_0601B5F0; case 0x0601B5F2u: goto L_0601B5F2; case 0x0601B5F4u: goto L_0601B5F4; case 0x0601B5F6u: goto L_0601B5F6; case 0x0601B5F8u: goto L_0601B5F8; case 0x0601B5FAu: goto L_0601B5FA; case 0x0601B5FCu: goto L_0601B5FC; case 0x0601B5FEu: goto L_0601B5FE; case 0x0601B602u: goto L_0601B602; case 0x0601B604u: goto L_0601B604; case 0x0601B608u: goto L_0601B608; case 0x0601B60Cu: goto L_0601B60C; case 0x0601B60Eu: goto L_0601B60E; case 0x0601B610u: goto L_0601B610; case 0x0601B612u: goto L_0601B612; case 0x0601B614u: goto L_0601B614; case 0x0601B616u: goto L_0601B616; case 0x0601B618u: goto L_0601B618; case 0x0601B61Au: goto L_0601B61A; case 0x0601B61Cu: goto L_0601B61C; case 0x0601B61Eu: goto L_0601B61E; case 0x0601B620u: goto L_0601B620; case 0x0601B622u: goto L_0601B622; case 0x0601B624u: goto L_0601B624; case 0x0601B626u: goto L_0601B626; case 0x0601B628u: goto L_0601B628; case 0x0601B62Au: goto L_0601B62A; case 0x0601B62Cu: goto L_0601B62C; case 0x0601B62Eu: goto L_0601B62E; case 0x0601B630u: goto L_0601B630; case 0x0601B632u: goto L_0601B632; case 0x0601B634u: goto L_0601B634; case 0x0601B636u: goto L_0601B636; case 0x0601B638u: goto L_0601B638; case 0x0601B63Au: goto L_0601B63A; case 0x0601B63Cu: goto L_0601B63C; case 0x0601B63Eu: goto L_0601B63E; case 0x0601B640u: goto L_0601B640; case 0x0601B642u: goto L_0601B642; case 0x0601B644u: goto L_0601B644; case 0x0601B646u: goto L_0601B646; case 0x0601B648u: goto L_0601B648; case 0x0601B64Au: goto L_0601B64A; case 0x0601B64Cu: goto L_0601B64C; case 0x0601B64Eu: goto L_0601B64E; case 0x0601B650u: goto L_0601B650; case 0x0601B652u: goto L_0601B652; case 0x0601B654u: goto L_0601B654; case 0x0601B656u: goto L_0601B656; case 0x0601B658u: goto L_0601B658; case 0x0601B65Au: goto L_0601B65A; case 0x0601B65Cu: goto L_0601B65C; case 0x0601B65Eu: goto L_0601B65E; case 0x0601B660u: goto L_0601B660; case 0x0601B664u: goto L_0601B664; case 0x0601B666u: goto L_0601B666; case 0x0601B66Au: goto L_0601B66A; case 0x0601B66Cu: goto L_0601B66C; case 0x0601B66Eu: goto L_0601B66E; case 0x0601B670u: goto L_0601B670; case 0x0601B672u: goto L_0601B672; case 0x0601B674u: goto L_0601B674; case 0x0601B676u: goto L_0601B676; case 0x0601B678u: goto L_0601B678; case 0x0601B67Au: goto L_0601B67A; case 0x0601B67Eu: goto L_0601B67E; case 0x0601B682u: goto L_0601B682; case 0x0601B684u: goto L_0601B684; case 0x0601B688u: goto L_0601B688; case 0x0601B68Au: goto L_0601B68A; case 0x0601B68Cu: goto L_0601B68C; case 0x0601B68Eu: goto L_0601B68E; case 0x0601B690u: goto L_0601B690; case 0x0601B692u: goto L_0601B692; case 0x0601B696u: goto L_0601B696; case 0x0601B698u: goto L_0601B698; case 0x0601B69Au: goto L_0601B69A; case 0x0601B69Cu: goto L_0601B69C; case 0x0601B69Eu: goto L_0601B69E; case 0x0601B6A0u: goto L_0601B6A0; case 0x0601B6A4u: goto L_0601B6A4; case 0x0601B6A6u: goto L_0601B6A6; case 0x0601B6A8u: goto L_0601B6A8; case 0x0601B6AAu: goto L_0601B6AA; case 0x0601B6ACu: goto L_0601B6AC; case 0x0601B6AEu: goto L_0601B6AE; case 0x0601B6B0u: goto L_0601B6B0; case 0x0601B6B2u: goto L_0601B6B2; case 0x0601B6B4u: goto L_0601B6B4; case 0x0601B6B6u: goto L_0601B6B6; case 0x0601B6B8u: goto L_0601B6B8; case 0x0601B6BAu: goto L_0601B6BA; case 0x0601B6BCu: goto L_0601B6BC; case 0x0601B6BEu: goto L_0601B6BE; case 0x0601B6C0u: goto L_0601B6C0; case 0x0601B6C2u: goto L_0601B6C2; case 0x0601B6C4u: goto L_0601B6C4; case 0x0601B6C8u: goto L_0601B6C8; case 0x0601B6CAu: goto L_0601B6CA; case 0x0601B6CEu: goto L_0601B6CE; case 0x0601B6D0u: goto L_0601B6D0; case 0x0601B6D2u: goto L_0601B6D2; case 0x0601B6D4u: goto L_0601B6D4; case 0x0601B6D6u: goto L_0601B6D6; case 0x0601B6D8u: goto L_0601B6D8; case 0x0601B6DAu: goto L_0601B6DA; case 0x0601B6DCu: goto L_0601B6DC; case 0x0601B6DEu: goto L_0601B6DE; case 0x0601B6E0u: goto L_0601B6E0; case 0x0607ECBEu: goto L_0607ECBE; case 0x0607ECC0u: goto L_0607ECC0; case 0x0607ECC2u: goto L_0607ECC2; case 0x0607ECC4u: goto L_0607ECC4; case 0x0607ECC6u: goto L_0607ECC6; case 0x0607ECC8u: goto L_0607ECC8; case 0x0607ECCAu: goto L_0607ECCA; case 0x0607ECCCu: goto L_0607ECCC; case 0x0607ECCEu: goto L_0607ECCE; case 0x0607ECD0u: goto L_0607ECD0; case 0x0607ECD2u: goto L_0607ECD2; case 0x0607ECD6u: goto L_0607ECD6; case 0x0607ECD8u: goto L_0607ECD8; case 0x0607ECDAu: goto L_0607ECDA; case 0x0607ECDCu: goto L_0607ECDC; case 0x0607ECDEu: goto L_0607ECDE; case 0x0607ECE0u: goto L_0607ECE0; case 0x0607ECE4u: goto L_0607ECE4; case 0x0607ECE8u: goto L_0607ECE8; case 0x0607ECEAu: goto L_0607ECEA; case 0x0607EE54u: goto L_0607EE54; case 0x0607EE56u: goto L_0607EE56; case 0x0607EE58u: goto L_0607EE58; case 0x0607EE5Au: goto L_0607EE5A; case 0x0607EE5Cu: goto L_0607EE5C; case 0x0607EE5Eu: goto L_0607EE5E; case 0x0607EE60u: goto L_0607EE60; case 0x0607EE62u: goto L_0607EE62; case 0x0608431Eu: goto L_0608431E; case 0x06084320u: goto L_06084320; case 0x06084322u: goto L_06084322; case 0x06084324u: goto L_06084324; case 0x06084326u: goto L_06084326; case 0x06084328u: goto L_06084328; case 0x0608432Au: goto L_0608432A; case 0x0608432Cu: goto L_0608432C; case 0x06084330u: goto L_06084330; case 0x06084332u: goto L_06084332; case 0x06084334u: goto L_06084334; case 0x06084336u: goto L_06084336; case 0x06084338u: goto L_06084338; case 0x0608433Au: goto L_0608433A; case 0x0608433Cu: goto L_0608433C; case 0x0608433Eu: goto L_0608433E; case 0x06084340u: goto L_06084340; case 0x06084342u: goto L_06084342; case 0x06084344u: goto L_06084344; case 0x06084346u: goto L_06084346; case 0x06084348u: goto L_06084348; case 0x0608434Au: goto L_0608434A; case 0x0608434Cu: goto L_0608434C; case 0x0608434Eu: goto L_0608434E; case 0x06084350u: goto L_06084350; case 0x06084352u: goto L_06084352; case 0x06084354u: goto L_06084354; case 0x06084356u: goto L_06084356; case 0x06084358u: goto L_06084358; case 0x0608435Au: goto L_0608435A; case 0x0608435Cu: goto L_0608435C; case 0x0608435Eu: goto L_0608435E; case 0x06084362u: goto L_06084362; case 0x06084364u: goto L_06084364; default: sh2_call(c, x); return; } }  // 06084364 jmp @r0 ; nop
}

void f_06084368(SH2Context& c) {
    ran[1847] = 1;
    c.r[1] = ld32(0x060843DCu);  // 06084368 mov.l 0x060843DC,r1
    c.r[2] = ld32(c.r[1]);  // 0608436A mov.l @r1,r2
    c.r[2] += 1;  // 0608436C add #1,r2
    st32(c.r[1], c.r[2]);  // 0608436E mov.l r2,@r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060843E4u);  // 06084370 mov.w 0x060843E4,r0
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06084372 rts ; nop
}

void f_0608442C(SH2Context& c) {
    ran[1848] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608442C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0608442E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06084430 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06084432 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06084434 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06084436 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06084438 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608443A sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x060845FAu);  // 0608443C mov.w 0x060845FA,r3
    c.r[15] += c.r[3];  // 0608443E add r3,r15
    c.r[14] = c.r[15];  // 06084440 mov r15,r14
    c.r[1] = ld32(0x06084610u);  // 06084442 mov.l 0x06084610,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06084448u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084448u) return; }  // 06084444 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06084614u);  // 06084448 mov.l 0x06084614,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0608444Eu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608444Eu) return; }  // 0608444A jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06084618u);  // 0608444E mov.l 0x06084618,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06084454u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084454u) return; }  // 06084450 jsr @r1 ; nop
    c.r[1] = ld32(0x0608461Cu);  // 06084454 mov.l 0x0608461C,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060845FCu);  // 06084456 mov.w 0x060845FC,r0
    c.r[0] += c.r[14];  // 06084458 add r14,r0
    c.r[12] = ld32(0x06084620u);  // 0608445A mov.l 0x06084620,r12
    c.r[13] = (uint32_t)(int16_t)ld16(0x060845FEu);  // 0608445C mov.w 0x060845FE,r13
    c.r[13] += c.r[14];  // 0608445E add r14,r13
    c.r[10] = ld32(0x06084624u);  // 06084460 mov.l 0x06084624,r10
    c.r[9] = ld32(0x06084628u);  // 06084462 mov.l 0x06084628,r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06084464 mov.b @r1,r1
    c.r[5] = 0x1Du;  // 06084466 mov #29,r5
    c.r[1] = c.r[1] & 0xFFu;  // 06084468 extu.b r1,r1
    st32(c.r[0], c.r[1]);  // 0608446A mov.l r1,@r0
    c.r[1] = ld32(0x0608462Cu);  // 0608446C mov.l 0x0608462C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0608446E mov.b @r1,r1
    c.r[4] = c.r[10];  // 06084470 mov r10,r4
    c.r[2] = ld32(c.r[12]);  // 06084472 mov.l @r12,r2
    c.r[11] = c.r[1] & 0xFFu;  // 06084474 extu.b r1,r11
    st32(c.r[13], c.r[11]);  // 06084476 mov.l r11,@r13
    c.r[1] = c.r[11];  // 06084478 mov r11,r1
    c.r[1] <<= 2;  // 0608447A shll2 r1
    c.r[1] += c.r[11];  // 0608447C add r11,r1
    c.r[1] <<= 2;  // 0608447E shll2 r1
    c.r[2] += c.r[1];  // 06084480 add r1,r2
    c.r[2] += 44;  // 06084482 add #44,r2
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06084484 mov.w @r2,r8
    { const uint32_t x = c.r[9]; c.pr = 0x0608448Au; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608448Au) return; }  // 06084486 jsr @r9 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 0608448A mov r0,r1
    c.r[5] = c.r[8];  // 0608448C mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06084492u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084492u) return; }  // 0608448E jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 06084492 mov r0,r1
    c.r[1] += 8;  // 06084494 add #8,r1
    c.r[8] = 0xFu;  // 06084496 mov #15,r8
    c.r[5] = 0x1Fu;  // 06084498 mov #31,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0608449A mov.b @r1,r1
    c.r[4] = c.r[10];  // 0608449C mov r10,r4
    { const uint32_t x = c.r[9]; c.pr = 0x060844A2u; c.r[8] &= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060844A2u) return; }  // 0608449E jsr @r9 ; and r1,r8
    c.r[1] = c.r[0];  // 060844A2 mov r0,r1
    c.r[5] = 0x3u;  // 060844A4 mov #3,r5
    { const uint32_t x = c.r[9]; c.pr = 0x060844AAu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060844AAu) return; }  // 060844A6 jsr @r9 ; mov r1,r4
    c.r[1] = 0x16u;  // 060844AA mov #22,r1
    c.macl = c.r[8] * c.r[1];  // 060844AC mul.l r1,r8
    c.r[3] = c.r[0];  // 060844AE mov r0,r3
    c.r[1] = c.macl;  // 060844B0 sts macl,r1
    c.r[3] += c.r[1];  // 060844B2 add r1,r3
    c.r[8] = ld32(0x06084630u);  // 060844B4 mov.l 0x06084630,r8
    c.r[1] = c.r[3];  // 060844B6 mov r3,r1
    c.r[1] += 20;  // 060844B8 add #20,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060844BA mov.b @r1,r2
    c.r[3] += 21;  // 060844BC add #21,r3
    c.r[2] = c.r[2] & 0xFFu;  // 060844BE extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060844C0 mov.b @r3,r1
    c.r[2] <<= 8;  // 060844C2 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 060844C4 extu.b r1,r1
    c.r[2] += c.r[1];  // 060844C6 add r1,r2
    c.r[1] = c.r[2];  // 060844C8 mov r2,r1
    c.r[1] <<= 2;  // 060844CA shll2 r1
    c.r[1] += c.r[2];  // 060844CC add r2,r1
    c.r[1] += c.r[1];  // 060844CE add r1,r1
    st32(c.r[8], c.r[1]);  // 060844D0 mov.l r1,@r8
    c.r[1] = ld32(c.r[12]);  // 060844D2 mov.l @r12,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060844D4 mov.w @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06084600u);  // 060844D6 mov.w 0x06084600,r0
    c.r[1] = c.r[1] & 0xFFFFu;  // 060844D8 extu.w r1,r1
    c.t = c.r[1] == c.r[0];  // 060844DA cmp/eq r0,r1
    { const bool k = !c.t; c.r[5] = 0x0u; if (k) { goto L_060844EE; } }  // 060844DC bf/s 0x060844EE ; mov #0,r5
    c.r[1] = ld32(0x06084634u);  // 060844E0 mov.l 0x06084634,r1
    st32(c.r[8], c.r[1]);  // 060844E2 mov.l r1,@r8
    c.r[4] = (uint32_t)(int16_t)ld16(0x06084602u);  // 060844E4 mov.w 0x06084602,r4
    c.r[1] = ld32(0x06084638u);  // 060844E6 mov.l 0x06084638,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060844ECu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060844ECu) return; }  // 060844E8 jsr @r1 ; nop
    c.r[5] = 0x0u;  // 060844EC mov #0,r5
L_060844EE:
    c.r[4] = 0x0u;  // 060844EE mov #0,r4
    c.r[12] = ld32(0x0608463Cu);  // 060844F0 mov.l 0x0608463C,r12
    { const uint32_t x = c.r[12]; c.pr = 0x060844F6u; c.r[6] = ld32(c.r[8]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060844F6u) return; }  // 060844F2 jsr @r12 ; mov.l @r8,r6
    c.r[13] = ld32(0x06084640u);  // 060844F6 mov.l 0x06084640,r13
    c.r[1] = 0x1Eu;  // 060844F8 mov #30,r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x060845FCu);  // 060844FA mov.w 0x060845FC,r12
    c.r[0] = ld32(c.r[13]);  // 060844FC mov.l @r13,r0
    c.r[12] += c.r[14];  // 060844FE add r14,r12
    c.r[13] = (uint32_t)(int16_t)ld16(0x06084604u);  // 06084500 mov.w 0x06084604,r13
    c.r[13] += c.r[14];  // 06084502 add r14,r13
    st32(c.r[13], c.r[0]);  // 06084504 mov.l r0,@r13
    c.r[12] = ld32(c.r[12]);  // 06084506 mov.l @r12,r12
    c.r[10] = 0x0u;  // 06084508 mov #0,r10
    c.macl = c.r[12] * c.r[1];  // 0608450A mul.l r1,r12
    c.r[13] = (uint32_t)(int16_t)ld16(0x06084606u);  // 0608450C mov.w 0x06084606,r13
    c.r[13] += c.r[14];  // 0608450E add r14,r13
    c.r[0] = c.macl;  // 06084510 sts macl,r0
    st32(c.r[13], c.r[0]);  // 06084512 mov.l r0,@r13
    c.r[12] = (uint32_t)(int16_t)ld16(0x06084604u);  // 06084514 mov.w 0x06084604,r12
    c.r[12] += c.r[14];  // 06084516 add r14,r12
    c.r[0] = c.r[11];  // 06084518 mov r11,r0
    c.r[13] = ld32(c.r[12]);  // 0608451A mov.l @r12,r13
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 0608451C shar r0
    c.r[12] = (uint32_t)(int16_t)ld16(0x06084606u);  // 0608451E mov.w 0x06084606,r12
    c.r[12] += c.r[14];  // 06084520 add r14,r12
    c.r[12] = ld32(c.r[12]);  // 06084522 mov.l @r12,r12
    c.r[1] = 0x1u;  // 06084524 mov #1,r1
    c.r[13] += c.r[12];  // 06084526 add r12,r13
    c.r[12] = (uint32_t)(int16_t)ld16(0x06084604u);  // 06084528 mov.w 0x06084604,r12
    c.r[12] += c.r[14];  // 0608452A add r14,r12
    st32(c.r[12], c.r[13]);  // 0608452C mov.l r13,@r12
    c.r[13] = (uint32_t)(int16_t)ld16(0x06084608u);  // 0608452E mov.w 0x06084608,r13
    c.r[13] += c.r[14];  // 06084530 add r14,r13
    st32(c.r[13], c.r[0]);  // 06084532 mov.l r0,@r13
    c.r[12] = (uint32_t)(int16_t)ld16(0x06084604u);  // 06084534 mov.w 0x06084604,r12
    c.r[12] += c.r[14];  // 06084536 add r14,r12
    c.r[13] = ld32(c.r[12]);  // 06084538 mov.l @r12,r13
    c.r[1] &= c.r[11];  // 0608453A and r11,r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x06084608u);  // 0608453C mov.w 0x06084608,r12
    c.r[12] += c.r[14];  // 0608453E add r14,r12
    c.r[12] = ld32(c.r[12]);  // 06084540 mov.l @r12,r12
    c.t = (c.r[1] & c.r[1]) == 0;  // 06084542 tst r1,r1
    c.r[13] += c.r[12];  // 06084544 add r12,r13
    c.r[12] = (uint32_t)(int16_t)ld16(0x06084604u);  // 06084546 mov.w 0x06084604,r12
    c.r[12] += c.r[14];  // 06084548 add r14,r12
    st32(c.r[12], c.r[13]);  // 0608454A mov.l r13,@r12
    c.r[13] = (uint32_t)(int16_t)ld16(0x06084604u);  // 0608454C mov.w 0x06084604,r13
    c.r[13] += c.r[14];  // 0608454E add r14,r13
    c.r[12] = (uint32_t)(int16_t)ld16(0x06084604u);  // 06084550 mov.w 0x06084604,r12
    c.r[0] = ld32(c.r[13]);  // 06084552 mov.l @r13,r0
    c.r[12] += c.r[14];  // 06084554 add r14,r12
    c.r[0] += 7;  // 06084556 add #7,r0
    st32(c.r[13], c.r[0]);  // 06084558 mov.l r0,@r13
    c.r[13] = ld32(c.r[12]);  // 0608455A mov.l @r12,r13
    c.r[0] = (uint32_t)(int16_t)ld16(0x0608460Au);  // 0608455C mov.w 0x0608460A,r0
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[13]);  // 0608455E mov.b @r13,r8
    c.r[0] += c.r[14];  // 06084560 add r14,r0
    c.r[12] = c.r[8] & 0xFFu;  // 06084562 extu.b r8,r12
    { const bool k = !c.t; st32(c.r[0], c.r[12]); if (k) { goto L_0608456A; } }  // 06084564 bf/s 0x0608456A ; mov.l r12,@r0
    c.r[10] = 0x4u;  // 06084568 mov #4,r10
L_0608456A:
    c.r[9] = ld32(0x06084644u);  // 0608456A mov.l 0x06084644,r9
    c.r[5] = c.r[10];  // 0608456C mov r10,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06084572u; c.r[4] = 0xFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084572u) return; }  // 0608456E jsr @r9 ; mov #15,r4
    c.r[1] = c.r[0];  // 06084572 mov r0,r1
    c.r[1] = ~c.r[1];  // 06084574 not r1,r1
    c.r[1] &= c.r[8];  // 06084576 and r8,r1
    c.r[13] = (uint32_t)(int16_t)ld16(0x06084604u);  // 06084578 mov.w 0x06084604,r13
    c.r[13] += c.r[14];  // 0608457A add r14,r13
    c.r[12] = ld32(0x06084640u);  // 0608457C mov.l 0x06084640,r12
    c.r[5] = c.r[10];  // 0608457E mov r10,r5
    c.r[0] = ld32(c.r[13]);  // 06084580 mov.l @r13,r0
    c.r[4] = 0xBu;  // 06084582 mov #11,r4
    st8(c.r[0], c.r[1]);  // 06084584 mov.b r1,@r0
    c.r[13] = (uint32_t)(int16_t)ld16(0x06084606u);  // 06084586 mov.w 0x06084606,r13
    c.r[13] += c.r[14];  // 06084588 add r14,r13
    c.r[8] = ld32(c.r[12]);  // 0608458A mov.l @r12,r8
    c.r[0] = (uint32_t)(int16_t)ld16(0x06084608u);  // 0608458C mov.w 0x06084608,r0
    c.r[13] = ld32(c.r[13]);  // 0608458E mov.l @r13,r13
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06084590 mov.l @(r0,r14),r0
    c.r[8] += c.r[13];  // 06084592 add r13,r8
    c.r[8] += c.r[0];  // 06084594 add r0,r8
    { const uint32_t x = c.r[9]; c.pr = 0x0608459Au; c.r[8] += 7; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608459Au) return; }  // 06084596 jsr @r9 ; add #7,r8
    c.r[2] = c.r[0];  // 0608459A mov r0,r2
    c.r[9] = ld32(0x06084648u);  // 0608459C mov.l 0x06084648,r9
    c.r[6] = 0x0u;  // 0608459E mov #0,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 060845A0 mov.b @r8,r1
    c.r[4] = c.r[14];  // 060845A2 mov r14,r4
    c.r[2] |= c.r[1];  // 060845A4 or r1,r2
    st8(c.r[8], c.r[2]);  // 060845A6 mov.b r2,@r8
    c.r[3] = ld32(c.r[12]);  // 060845A8 mov.l @r12,r3
    c.r[8] = ld32(0x0608464Cu);  // 060845AA mov.l 0x0608464C,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 060845AC mov.b @r9,r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x06084606u);  // 060845AE mov.w 0x06084606,r12
    c.r[12] += c.r[14];  // 060845B0 add r14,r12
    c.r[1] = c.r[1] & 0xFFu;  // 060845B2 extu.b r1,r1
    c.r[12] = ld32(c.r[12]);  // 060845B4 mov.l @r12,r12
    c.r[0] = c.r[1];  // 060845B6 mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 060845B8 mov.b @(r0,r8),r2
    c.r[3] += c.r[12];  // 060845BA add r12,r3
    c.r[2] = c.r[2] & 0xFFu;  // 060845BC extu.b r2,r2
    c.r[12] = (uint32_t)(int16_t)ld16(0x0608460Cu);  // 060845BE mov.w 0x0608460C,r12
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 060845C0 mov.w @r3,r1
    c.r[12] += c.r[14];  // 060845C2 add r14,r12
    c.r[1] += c.r[2];  // 060845C4 add r2,r1
    st16(c.r[3], c.r[1]);  // 060845C6 mov.w r1,@r3
    c.r[12] = (uint32_t)(int8_t)ld8(c.r[12]);  // 060845C8 mov.b @r12,r12
    c.r[1] = ld32(0x06084650u);  // 060845CA mov.l 0x06084650,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060845D0u; c.r[5] = c.r[12] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060845D0u) return; }  // 060845CC jsr @r1 ; extu.b r12,r5
    c.r[13] = ld32(0x06084620u);  // 060845D0 mov.l 0x06084620,r13
    c.r[1] = ld32(c.r[13]);  // 060845D2 mov.l @r13,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060845D4 mov.w @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06084600u);  // 060845D6 mov.w 0x06084600,r0
    c.r[1] = c.r[1] & 0xFFFFu;  // 060845D8 extu.w r1,r1
    c.t = c.r[1] == c.r[0];  // 060845DA cmp/eq r0,r1
    { const bool k = !c.t; c.r[5] = c.r[11]; if (k) { goto L_060845EA; } }  // 060845DC bf/s 0x060845EA ; mov r11,r5
    c.r[4] = (uint32_t)(int16_t)ld16(0x06084602u);  // 060845E0 mov.w 0x06084602,r4
    c.r[1] = ld32(0x06084654u);  // 060845E2 mov.l 0x06084654,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060845E8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060845E8u) return; }  // 060845E4 jsr @r1 ; nop
    c.r[5] = c.r[11];  // 060845E8 mov r11,r5
L_060845EA:
    c.r[12] = ld32(0x06084658u);  // 060845EA mov.l 0x06084658,r12
    { const uint32_t x = c.r[12]; c.pr = 0x060845F0u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060845F0u) return; }  // 060845EC jsr @r12 ; mov r14,r4
    c.r[1] = c.r[0];  // 060845F0 mov r0,r1
    c.r[11] = c.r[1] & 0xFFu;  // 060845F2 extu.b r1,r11
    c.r[13] = (uint32_t)(int16_t)ld16(0x0608460Eu);  // 060845F4 mov.w 0x0608460E,r13
    c.t = c.r[11] == c.r[13]; goto L_0608465C;  // 060845F6 bra 0x0608465C ; cmp/eq r13,r11
L_0608465C:
    { const bool k = !c.t; c.r[6] = 0x5Du; if (k) { goto L_06084664; } }  // 0608465C bf/s 0x06084664 ; mov #93,r6
    goto L_060848C6;  // 06084660 bra 0x060848C6 ; nop
L_06084664:
    c.r[4] = (uint32_t)(int16_t)ld16(0x060847C0u);  // 06084664 mov.w 0x060847C0,r4
    c.r[4] += c.r[14];  // 06084666 add r14,r4
    c.r[0] = ld32(0x060847D4u);  // 06084668 mov.l 0x060847D4,r0
    c.r[1] = ld32(0x060847D8u);  // 0608466A mov.l 0x060847D8,r1
    c.r[12] = ld32(0x060847D4u);  // 0608466C mov.l 0x060847D4,r12
    c.r[13] = ld32(0x060847DCu);  // 0608466E mov.l 0x060847DC,r13
    { const uint32_t x = c.r[1]; c.pr = 0x06084674u; c.r[5] = ld32(c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084674u) return; }  // 06084670 jsr @r1 ; mov.l @r0,r5
    c.r[5] = c.r[14];  // 06084674 mov r14,r5
    c.r[4] = ld32(c.r[12]);  // 06084676 mov.l @r12,r4
    { const uint32_t x = c.r[1]; c.pr = 0x0608467Cu; c.r[6] = 0x5Du; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608467Cu) return; }  // 06084678 jsr @r1 ; mov #93,r6
    c.r[0] = (uint32_t)(int16_t)ld16(0x060847C2u);  // 0608467C mov.w 0x060847C2,r0
    c.r[3] = ld32(c.r[13]);  // 0608467E mov.l @r13,r3
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06084680 mov.l @(r0,r14),r0
    c.r[12] = (uint32_t)(int16_t)ld16(0x060847C4u);  // 06084682 mov.w 0x060847C4,r12
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06084684 mov.b @r9,r1
    c.r[3] += c.r[0];  // 06084686 add r0,r3
    c.r[1] = c.r[1] & 0xFFu;  // 06084688 extu.b r1,r1
    c.r[0] = c.r[1];  // 0608468A mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0608468C mov.b @(r0,r8),r2
    c.r[12] += c.r[14];  // 0608468E add r14,r12
    c.r[2] = c.r[2] & 0xFFu;  // 06084690 extu.b r2,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x060847C4u);  // 06084692 mov.w 0x060847C4,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06084694 mov.w @r3,r1
    c.r[0] += c.r[14];  // 06084696 add r14,r0
    c.r[1] -= c.r[2];  // 06084698 sub r2,r1
    st16(c.r[3], c.r[1]);  // 0608469A mov.w r1,@r3
    c.r[1] = c.r[14];  // 0608469C mov r14,r1
    c.r[13] = ld32(c.r[12]);  // 0608469E mov.l @r12,r13
    c.r[1] += 44;  // 060846A0 add #44,r1
    c.t = c.r[13] & 1; c.r[13] = (uint32_t)((int32_t)c.r[13] >> 1);  // 060846A2 shar r13
    st32(c.r[12], c.r[13]);  // 060846A4 mov.l r13,@r12
    c.r[12] = (uint32_t)(int16_t)ld16(0x060847C6u);  // 060846A6 mov.w 0x060847C6,r12
    c.r[12] += c.r[14];  // 060846A8 add r14,r12
    c.r[13] = (uint32_t)(int16_t)ld16(0x060847C8u);  // 060846AA mov.w 0x060847C8,r13
    c.r[0] = ld32(c.r[0]);  // 060846AC mov.l @r0,r0
    c.r[13] += c.r[14];  // 060846AE add r14,r13
    c.r[3] += c.r[0];  // 060846B0 add r0,r3
    c.r[3] += 7;  // 060846B2 add #7,r3
    c.r[0] = c.r[11];  // 060846B4 mov r11,r0
    c.r[12] = (uint32_t)(int8_t)ld8(c.r[12]);  // 060846B6 mov.b @r12,r12
    c.r[0] <<= 2;  // 060846B8 shll2 r0
    st8(c.r[3], c.r[12]);  // 060846BA mov.b r12,@r3
    st32(c.r[13], c.r[0]);  // 060846BC mov.l r0,@r13
    c.r[12] = (uint32_t)(int16_t)ld16(0x060847C8u);  // 060846BE mov.w 0x060847C8,r12
    c.r[12] += c.r[14];  // 060846C0 add r14,r12
    c.r[10] = ld32(c.r[12]);  // 060846C2 mov.l @r12,r10
    c.r[0] = c.r[1];  // 060846C4 mov r1,r0
    c.r[10] += c.r[11];  // 060846C6 add r11,r10
    c.r[10] <<= 2;  // 060846C8 shll2 r10
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[10]);  // 060846CA mov.w @(r0,r10),r4
    c.r[5] = c.r[11] & 0xFFu;  // 060846CC extu.b r11,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x060847CAu);  // 060846CE mov.w 0x060847CA,r1
    c.r[4] += c.r[1];  // 060846D0 add r1,r4
    c.r[1] = ld32(0x060847E0u);  // 060846D2 mov.l 0x060847E0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060846D8u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060846D8u) return; }  // 060846D4 jsr @r1 ; extu.w r4,r4
    c.r[1] = c.r[14];  // 060846D8 mov r14,r1
    c.r[1] += 48;  // 060846DA add #48,r1
    c.r[0] = c.r[1];  // 060846DC mov r1,r0
    c.r[5] = 0x0u;  // 060846DE mov #0,r5
    c.r[4] = 0x0u;  // 060846E0 mov #0,r4
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[10]);  // 060846E2 mov.w @(r0,r10),r6
    c.r[12] = ld32(0x060847E4u);  // 060846E4 mov.l 0x060847E4,r12
    { const uint32_t x = c.r[12]; c.pr = 0x060846EAu; c.r[6] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060846EAu) return; }  // 060846E6 jsr @r12 ; extu.w r6,r6
    c.r[1] = c.r[14];  // 060846EA mov r14,r1
    c.r[1] += 62;  // 060846EC add #62,r1
    c.r[0] = c.r[1];  // 060846EE mov r1,r0
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 060846F0 mov.b @(r0,r10),r5
    c.r[1] = c.r[14];  // 060846F2 mov r14,r1
    c.r[1] += 61;  // 060846F4 add #61,r1
    c.r[0] = c.r[1];  // 060846F6 mov r1,r0
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 060846F8 mov.b @(r0,r10),r4
    c.r[5] = c.r[5] & 0xFFu;  // 060846FA extu.b r5,r5
    c.r[1] = ld32(0x060847E8u);  // 060846FC mov.l 0x060847E8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06084702u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084702u) return; }  // 060846FE jsr @r1 ; extu.b r4,r4
    c.r[1] = c.r[14];  // 06084702 mov r14,r1
    c.r[1] += 58;  // 06084704 add #58,r1
    c.r[0] = c.r[1];  // 06084706 mov r1,r0
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 06084708 mov.b @(r0,r10),r5
    c.r[1] = ld32(0x060847ECu);  // 0608470A mov.l 0x060847EC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06084710u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084710u) return; }  // 0608470C jsr @r1 ; mov #0,r4
    c.r[5] = (uint32_t)(int16_t)ld16(0x060847CCu);  // 06084710 mov.w 0x060847CC,r5
    c.r[1] = ld32(0x060847F0u);  // 06084712 mov.l 0x060847F0,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06084714 mov.b @r1,r4
    c.r[5] += c.r[14];  // 06084716 add r14,r5
    c.r[1] = ld32(0x060847F4u);  // 06084718 mov.l 0x060847F4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0608471Eu; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608471Eu) return; }  // 0608471A jsr @r1 ; extu.b r4,r4
    c.r[9] = c.r[14];  // 0608471E mov r14,r9
    c.r[9] += 52;  // 06084720 add #52,r9
    c.r[0] = c.r[9];  // 06084722 mov r9,r0
    c.r[12] = (uint32_t)(int16_t)ld16(0x060847CEu);  // 06084724 mov.w 0x060847CE,r12
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[10]);  // 06084726 mov.w @(r0,r10),r1
    c.r[6] = c.r[1] & 0xFFFFu;  // 06084728 extu.w r1,r6
    c.t = c.r[6] & 1; c.r[6] >>= 1;  // 0608472A shlr r6
    c.r[6] &= c.r[12];  // 0608472C and r12,r6
    c.t = (c.r[6] & c.r[6]) == 0;  // 0608472E tst r6,r6
    { const bool k = !c.t; c.r[8] = 0x0u; if (k) { goto L_06084736; } }  // 06084730 bf/s 0x06084736 ; mov #0,r8
    c.r[8] = 0x30u;  // 06084734 mov #48,r8
L_06084736:
    c.r[5] = 0x0u;  // 06084736 mov #0,r5
    c.r[13] = ld32(0x060847E4u);  // 06084738 mov.l 0x060847E4,r13
    { const uint32_t x = c.r[13]; c.pr = 0x0608473Eu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608473Eu) return; }  // 0608473A jsr @r13 ; mov r8,r4
    c.r[0] = c.r[9];  // 0608473E mov r9,r0
    c.r[12] = (uint32_t)(int16_t)ld16(0x060847CEu);  // 06084740 mov.w 0x060847CE,r12
    c.r[5] = 0x0u;  // 06084742 mov #0,r5
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[10]);  // 06084744 mov.w @(r0,r10),r6
    c.r[4] = c.r[8];  // 06084746 mov r8,r4
    c.r[6] = c.r[6] & 0xFFFFu;  // 06084748 extu.w r6,r6
    c.t = c.r[6] & 1; c.r[6] >>= 1;  // 0608474A shlr r6
    { const uint32_t x = c.r[13]; c.pr = 0x06084750u; c.r[6] &= c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084750u) return; }  // 0608474C jsr @r13 ; and r12,r6
    c.r[0] = (uint32_t)(int16_t)ld16(0x060847C8u);  // 06084750 mov.w 0x060847C8,r0
    c.r[0] += c.r[14];  // 06084752 add r14,r0
    c.r[12] = (uint32_t)(int16_t)ld16(0x060847C8u);  // 06084754 mov.w 0x060847C8,r12
    c.r[12] += c.r[14];  // 06084756 add r14,r12
    c.r[0] = ld32(c.r[0]);  // 06084758 mov.l @r0,r0
    c.r[9] = ld32(0x060847F8u);  // 0608475A mov.l 0x060847F8,r9
    c.r[0] |= 0x2u;  // 0608475C or #2,r0
    st32(c.r[12], c.r[0]);  // 0608475E mov.l r0,@r12
    c.r[12] = (uint32_t)(int16_t)ld16(0x060847D0u);  // 06084760 mov.w 0x060847D0,r12
    c.r[12] += c.r[14];  // 06084762 add r14,r12
    c.r[12] = (uint32_t)(int8_t)ld8(c.r[12]);  // 06084764 mov.b @r12,r12
    c.r[5] = 0x2u;  // 06084766 mov #2,r5
    c.r[8] = c.r[12] & 0xFFu;  // 06084768 extu.b r12,r8
    { const uint32_t x = c.r[9]; c.pr = 0x0608476Eu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608476Eu) return; }  // 0608476A jsr @r9 ; mov r8,r4
    c.r[5] = 0x0u;  // 0608476E mov #0,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06084774u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084774u) return; }  // 06084770 jsr @r9 ; mov r8,r4
    c.r[5] = 0x1u;  // 06084774 mov #1,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0608477Au; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608477Au) return; }  // 06084776 jsr @r9 ; mov r8,r4
    c.r[5] = 0x3u;  // 0608477A mov #3,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06084780u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084780u) return; }  // 0608477C jsr @r9 ; mov r8,r4
    c.r[1] = c.r[14];  // 06084780 mov r14,r1
    c.r[1] += 59;  // 06084782 add #59,r1
    c.r[0] = c.r[1];  // 06084784 mov r1,r0
    c.r[5] = 0x0u;  // 06084786 mov #0,r5
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 06084788 mov.b @(r0,r10),r6
    c.r[4] = 0x30u;  // 0608478A mov #48,r4
    { const uint32_t x = c.r[13]; c.pr = 0x06084790u; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084790u) return; }  // 0608478C jsr @r13 ; extu.b r6,r6
    c.r[12] = ld32(0x060847D4u);  // 06084790 mov.l 0x060847D4,r12
    c.r[1] = ld32(c.r[12]);  // 06084792 mov.l @r12,r1
    c.r[1] += 14;  // 06084794 add #14,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06084796 mov.b @r1,r1
    c.r[13] = (uint32_t)(int16_t)ld16(0x060847D2u);  // 06084798 mov.w 0x060847D2,r13
    c.r[3] = c.r[1] & 0xFFu;  // 0608479A extu.b r1,r3
    c.t = c.r[3] == c.r[13];  // 0608479C cmp/eq r13,r3
    { const bool k = c.t; c.r[5] = 0x0u; if (k) { goto L_06084800; } }  // 0608479E bt/s 0x06084800 ; mov #0,r5
    c.r[1] = ld32(0x060847FCu);  // 060847A2 mov.l 0x060847FC,r1
    c.r[2] = c.r[3];  // 060847A4 mov r3,r2
    c.r[2] += c.r[2];  // 060847A6 add r2,r2
    c.r[2] += c.r[3];  // 060847A8 add r3,r2
    c.r[2] <<= 2;  // 060847AA shll2 r2
    c.r[1] = ld32(c.r[1]);  // 060847AC mov.l @r1,r1
    c.r[4] = 0x0u;  // 060847AE mov #0,r4
    c.r[2] += c.r[1];  // 060847B0 add r1,r2
    c.r[2] += 9;  // 060847B2 add #9,r2
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060847B4 mov.b @r2,r6
    c.r[0] = ld32(0x060847E4u);  // 060847B6 mov.l 0x060847E4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060847BCu; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060847BCu) return; }  // 060847B8 jsr @r0 ; extu.b r6,r6
    c.r[9] = c.r[11]; goto L_0608480A;  // 060847BC bra 0x0608480A ; mov r11,r9
L_06084800:
    c.r[6] = 0x0u;  // 06084800 mov #0,r6
    c.r[12] = ld32(0x060848ECu);  // 06084802 mov.l 0x060848EC,r12
    { const uint32_t x = c.r[12]; c.pr = 0x06084808u; c.r[4] = 0x30u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084808u) return; }  // 06084804 jsr @r12 ; mov #48,r4
    c.r[9] = c.r[11];  // 06084808 mov r11,r9
L_0608480A:
    c.r[9] <<= 2;  // 0608480A shll2 r9
    c.r[9] += c.r[11];  // 0608480C add r11,r9
    c.r[9] <<= 2;  // 0608480E shll2 r9
    c.r[1] = c.r[14];  // 06084810 mov r14,r1
    c.r[1] += 54;  // 06084812 add #54,r1
    c.r[0] = c.r[1];  // 06084814 mov r1,r0
    c.r[8] = ld32(0x060848ECu);  // 06084816 mov.l 0x060848EC,r8
    c.r[5] = 0x0u;  // 06084818 mov #0,r5
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[9]);  // 0608481A mov.w @(r0,r9),r6
    c.r[4] = 0x30u;  // 0608481C mov #48,r4
    { const uint32_t x = c.r[8]; c.pr = 0x06084822u; c.r[6] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084822u) return; }  // 0608481E jsr @r8 ; extu.w r6,r6
    c.r[1] = c.r[14];  // 06084822 mov r14,r1
    c.r[1] += 24;  // 06084824 add #24,r1
    c.r[5] = 0x0u;  // 06084826 mov #0,r5
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06084828 mov.w @r1,r6
    c.r[4] = 0x0u;  // 0608482A mov #0,r4
    { const uint32_t x = c.r[8]; c.pr = 0x06084830u; c.r[6] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084830u) return; }  // 0608482C jsr @r8 ; extu.w r6,r6
    c.r[1] = c.r[14];  // 06084830 mov r14,r1
    c.r[1] += 60;  // 06084832 add #60,r1
    c.r[0] = c.r[1];  // 06084834 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 06084836 mov.b @(r0,r9),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06084838 extu.b r1,r1
    c.r[4] = c.r[1];  // 0608483A mov r1,r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 0608483C tst r4,r4
    if (!c.t) { goto L_06084848; }  // 0608483E bf 0x06084848
    c.r[5] = (uint32_t)(int16_t)ld16(0x060848E0u);  // 06084840 mov.w 0x060848E0,r5
    c.r[4] = ld32(0x060848F0u);  // 06084842 mov.l 0x060848F0,r4
    goto L_06084850;  // 06084844 bra 0x06084850 ; nop
L_06084848:
    c.r[5] = (uint32_t)(int16_t)ld16(0x060848E0u);  // 06084848 mov.w 0x060848E0,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x060848E2u);  // 0608484A mov.w 0x060848E2,r1
    c.r[4] += c.r[1];  // 0608484C add r1,r4
    c.r[4] = c.r[4] & 0xFFFFu;  // 0608484E extu.w r4,r4
L_06084850:
    c.r[1] = ld32(0x060848F4u);  // 06084850 mov.l 0x060848F4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06084856u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084856u) return; }  // 06084852 jsr @r1 ; nop
    c.r[2] = c.r[11];  // 06084856 mov r11,r2
    c.r[2] <<= 2;  // 06084858 shll2 r2
    c.r[2] += c.r[11];  // 0608485A add r11,r2
    c.r[2] <<= 2;  // 0608485C shll2 r2
    c.r[1] = c.r[14];  // 0608485E mov r14,r1
    c.r[1] += 51;  // 06084860 add #51,r1
    c.r[0] = c.r[1];  // 06084862 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06084864 mov.b @(r0,r2),r1
    c.r[3] = 0x1u;  // 06084866 mov #1,r3
    c.r[3] &= c.r[1];  // 06084868 and r1,r3
    c.r[1] = c.r[14];  // 0608486A mov r14,r1
    c.r[1] += 52;  // 0608486C add #52,r1
    c.r[0] = c.r[1];  // 0608486E mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06084870 mov.b @(r0,r2),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06084872 extu.b r1,r1
    c.r[1] >>= 2;  // 06084874 shlr2 r1
    c.r[1] >>= 2;  // 06084876 shlr2 r1
    c.r[1] >>= 2;  // 06084878 shlr2 r1
    c.r[2] = c.r[3];  // 0608487A mov r3,r2
    c.r[2] <<= 2;  // 0608487C shll2 r2
    c.r[2] |= c.r[1];  // 0608487E or r1,r2
    c.r[1] = ld32(0x060848F8u);  // 06084880 mov.l 0x060848F8,r1
    c.r[0] = c.r[2];  // 06084882 mov r2,r0
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06084884 mov.b @(r0,r1),r5
    c.r[1] = ld32(0x060848FCu);  // 06084886 mov.l 0x060848FC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0608488Cu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608488Cu) return; }  // 06084888 jsr @r1 ; mov #0,r4
    c.r[7] = 0x2u;  // 0608488C mov #2,r7
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 0608488E mov.l r7,@-r15
    c.r[2] = 0x1u;  // 06084890 mov #1,r2
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06084892 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06084894 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06084896 mov.l r2,@-r15
    c.r[1] = 0x0u;  // 06084898 mov #0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0608489A mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 0608489C mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0608489E mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060848A0 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 060848A2 mov.l r7,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 060848A4 mov.l r2,@-r15
    c.r[1] = ld32(0x06084900u);  // 060848A6 mov.l 0x06084900,r1
    c.r[6] = 0x5u;  // 060848A8 mov #5,r6
    c.r[5] = 0xAu;  // 060848AA mov #10,r5
    { const uint32_t x = c.r[1]; c.pr = 0x060848B0u; c.r[4] = 0x1Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060848B0u) return; }  // 060848AC jsr @r1 ; mov #28,r4
    c.r[15] += 40;  // 060848B0 add #40,r15
    c.r[1] = ld32(0x06084904u);  // 060848B2 mov.l 0x06084904,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060848B8u; c.r[4] = 0x4Fu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060848B8u) return; }  // 060848B4 jsr @r1 ; mov #79,r4
    c.r[1] = ld32(0x06084908u);  // 060848B8 mov.l 0x06084908,r1
    c.r[5] = (uint32_t)(int16_t)ld16(0x060848E4u);  // 060848BA mov.w 0x060848E4,r5
    c.r[5] += c.r[14];  // 060848BC add r14,r5
    c.r[4] = ld32(c.r[1]);  // 060848BE mov.l @r1,r4
    c.r[1] = ld32(0x0608490Cu);  // 060848C0 mov.l 0x0608490C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060848C6u; c.r[6] = 0x5Du; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060848C6u) return; }  // 060848C2 jsr @r1 ; mov #93,r6
L_060848C6:
    c.r[3] = (uint32_t)(int16_t)ld16(0x060848E6u);  // 060848C6 mov.w 0x060848E6,r3
    c.r[14] += c.r[3];  // 060848C8 add r3,r14
    c.r[15] = c.r[14];  // 060848CA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060848CC lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060848CE mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060848D0 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060848D2 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060848D4 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060848D6 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060848D8 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x060848E8u);  // 060848DA mov.w 0x060848E8,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060848DC rts ; mov.l @r15+,r8
}

void f_06084910(SH2Context& c) {
    ran[1849] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06084910 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06084912 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06084914 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06084916 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06084918 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0608491A mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608491C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608491E sts.l pr,@-r15
    c.r[15] -= 4;  // 06084920 add #-4,r15
    c.r[14] = c.r[15];  // 06084922 mov r15,r14
    c.r[1] = ld32(0x06084A94u);  // 06084924 mov.l 0x06084A94,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0608492Au; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608492Au) return; }  // 06084926 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06084A98u);  // 0608492A mov.l 0x06084A98,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06084930u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084930u) return; }  // 0608492C jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06084A9Cu);  // 06084930 mov.l 0x06084A9C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06084936u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084936u) return; }  // 06084932 jsr @r1 ; nop
    c.r[11] = ld32(0x06084AA0u);  // 06084936 mov.l 0x06084AA0,r11
    c.r[10] = ld32(0x06084AA4u);  // 06084938 mov.l 0x06084AA4,r10
    c.r[8] = ld32(0x06084AA8u);  // 0608493A mov.l 0x06084AA8,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[11]);  // 0608493C mov.b @r11,r1
    c.r[5] = 0x0u;  // 0608493E mov #0,r5
    c.r[1] = c.r[1] & 0xFFu;  // 06084940 extu.b r1,r1
    c.r[0] = c.r[1];  // 06084942 mov r1,r0
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 06084944 mov.b @(r0,r10),r6
    c.r[4] = 0x0u;  // 06084946 mov #0,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0608494Cu; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608494Cu) return; }  // 06084948 jsr @r8 ; extu.b r6,r6
    c.r[12] = ld32(0x06084AACu);  // 0608494C mov.l 0x06084AAC,r12
    c.r[1] = ld32(c.r[12]);  // 0608494E mov.l @r12,r1
    c.r[9] = (uint32_t)(int16_t)ld16(0x06084A8Au);  // 06084950 mov.w 0x06084A8A,r9
    c.r[0] = c.r[1];  // 06084952 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 06084954 mov.b @(r0,r9),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06084956 extu.b r1,r1
    c.r[6] = c.r[1];  // 06084958 mov r1,r6
    c.r[6] += 7;  // 0608495A add #7,r6
    c.r[6] >>= 2;  // 0608495C shlr2 r6
    c.t = c.r[6] & 1; c.r[6] >>= 1;  // 0608495E shlr r6
    c.r[5] = 0x0u;  // 06084960 mov #0,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06084966u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084966u) return; }  // 06084962 jsr @r8 ; mov #0,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[11]);  // 06084966 mov.b @r11,r1
    c.r[3] = c.r[1] & 0xFFu;  // 06084968 extu.b r1,r3
    c.r[0] = c.r[3];  // 0608496A mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 0608496C mov.b @(r0,r10),r1
    c.r[2] = ld32(0x06084AB0u);  // 0608496E mov.l 0x06084AB0,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06084970 extu.b r1,r1
    st32(c.r[14], c.r[1]);  // 06084972 mov.l r1,@r14
    c.r[0] = c.r[1];  // 06084974 mov r1,r0
    c.r[0] -= 1;  // 06084976 add #-1,r0
    st32(c.r[14], c.r[0]);  // 06084978 mov.l r0,@r14
    c.r[7] = c.r[0];  // 0608497A mov r0,r7
    c.r[1] = ld32(0x06084AB4u);  // 0608497C mov.l 0x06084AB4,r1
    c.r[0] = c.r[3];  // 0608497E mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06084980 mov.b @(r0,r1),r1
    c.r[7] <<= 2;  // 06084982 shll2 r7
    c.r[7] += c.r[7];  // 06084984 add r7,r7
    c.r[1] += c.r[7];  // 06084986 add r7,r1
    st8(c.r[2], c.r[1]);  // 06084988 mov.b r1,@r2
    c.r[3] = ld32(0x06084AB8u);  // 0608498A mov.l 0x06084AB8,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0608498C extu.b r1,r1
    c.r[2] = ld32(c.r[12]);  // 0608498E mov.l @r12,r2
    c.r[1] += c.r[1];  // 06084990 add r1,r1
    c.r[1] += c.r[2];  // 06084992 add r2,r1
    c.r[1] += 1;  // 06084994 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06084996 mov.b @r1,r1
    c.r[0] = c.r[2];  // 06084998 mov r2,r0
    st8(c.r[3], c.r[1]);  // 0608499A mov.b r1,@r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 0608499C mov.b @(r0,r9),r1
    c.r[4] = 0x8u;  // 0608499E mov #8,r4
    c.r[1] = c.r[1] & 0xFFu;  // 060849A0 extu.b r1,r1
    c.r[1] -= c.r[7];  // 060849A2 sub r7,r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[4];  // 060849A4 cmp/gt r4,r1
    { const bool k = c.t; c.r[11] = c.r[4]; if (k) { goto L_060849AC; } }  // 060849A6 bt/s 0x060849AC ; mov r4,r11
    c.r[11] = c.r[1];  // 060849AA mov r1,r11
L_060849AC:
    c.r[1] = ld32(0x06084ABCu);  // 060849AC mov.l 0x06084ABC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060849B2u; c.r[4] = c.r[11] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060849B2u) return; }  // 060849AE jsr @r1 ; extu.b r11,r4
    c.r[10] = ld32(c.r[14]);  // 060849B2 mov.l @r14,r10
    c.r[10] <<= 2;  // 060849B4 shll2 r10
    c.r[10] += c.r[10];  // 060849B6 add r10,r10
    c.r[1] = c.r[10];  // 060849B8 mov r10,r1
    c.r[1] += c.r[11];  // 060849BA add r11,r1
    c.t = (int32_t)c.r[10] >= (int32_t)c.r[1];  // 060849BC cmp/ge r1,r10
    if (c.t) { goto L_06084A50; }  // 060849BE bt 0x06084A50
    c.r[13] = (uint32_t)(int16_t)ld16(0x06084A8Cu);  // 060849C0 mov.w 0x06084A8C,r13
    c.r[12] = ld32(0x06084AC0u);  // 060849C2 mov.l 0x06084AC0,r12
L_060849C4:
    c.r[1] = ld32(0x06084AACu);  // 060849C4 mov.l 0x06084AAC,r1
    c.r[2] = c.r[10];  // 060849C6 mov r10,r2
    c.r[1] = ld32(c.r[1]);  // 060849C8 mov.l @r1,r1
    c.r[2] += c.r[2];  // 060849CA add r2,r2
    c.r[0] = c.r[1];  // 060849CC mov r1,r0
    c.r[1] += c.r[2];  // 060849CE add r2,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 060849D0 mov.b @(r0,r2),r3
    c.r[1] += 1;  // 060849D2 add #1,r1
    c.r[0] = 0x7Fu;  // 060849D4 mov #127,r0
    c.r[3] &= c.r[0];  // 060849D6 and r0,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060849D8 mov.b @r1,r2
    c.r[3] <<= 8;  // 060849DA shll8 r3
    c.r[2] = c.r[2] & 0xFFu;  // 060849DC extu.b r2,r2
    c.r[2] |= c.r[3];  // 060849DE or r3,r2
    c.r[1] = ld32(0x06084AC4u);  // 060849E0 mov.l 0x06084AC4,r1
    c.r[3] = ld32(c.r[1]);  // 060849E2 mov.l @r1,r3
    c.r[1] = 0x1Eu;  // 060849E4 mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 060849E6 mul.l r1,r2
    c.r[2] = c.macl;  // 060849E8 sts macl,r2
    c.r[2] += c.r[3];  // 060849EA add r3,r2
    c.r[1] = c.r[2];  // 060849EC mov r2,r1
    c.r[1] += 15;  // 060849EE add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060849F0 mov.b @r1,r1
    c.r[5] = c.r[13];  // 060849F2 mov r13,r5
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[2]);  // 060849F4 mov.w @r2,r4
    c.r[8] = c.r[1] & 0xFFu;  // 060849F6 extu.b r1,r8
    c.r[1] = (uint32_t)(int16_t)ld16(0x06084A8Eu);  // 060849F8 mov.w 0x06084A8E,r1
    c.r[4] += c.r[1];  // 060849FA add r1,r4
    { const uint32_t x = c.r[12]; c.pr = 0x06084A00u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084A00u) return; }  // 060849FC jsr @r12 ; extu.w r4,r4
    c.t = c.r[8] == c.r[13];  // 06084A00 cmp/eq r13,r8
    { const bool k = c.t; c.r[9] = c.r[8]; if (k) { goto L_06084A32; } }  // 06084A02 bt/s 0x06084A32 ; mov r8,r9
    c.r[0] = ld32(0x06084AC8u);  // 06084A06 mov.l 0x06084AC8,r0
    c.r[9] += c.r[9];  // 06084A08 add r9,r9
    c.r[9] += c.r[8];  // 06084A0A add r8,r9
    c.r[1] = ld32(c.r[0]);  // 06084A0C mov.l @r0,r1
    c.r[9] <<= 2;  // 06084A0E shll2 r9
    c.r[0] = c.r[9];  // 06084A10 mov r9,r0
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06084A12 mov.w @(r0,r1),r4
    c.r[5] = c.r[13];  // 06084A14 mov r13,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x06084A90u);  // 06084A16 mov.w 0x06084A90,r1
    c.r[4] += c.r[1];  // 06084A18 add r1,r4
    { const uint32_t x = c.r[12]; c.pr = 0x06084A1Eu; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084A1Eu) return; }  // 06084A1A jsr @r12 ; extu.w r4,r4
    c.r[0] = ld32(0x06084AC8u);  // 06084A1E mov.l 0x06084AC8,r0
    c.r[5] = 0x0u;  // 06084A20 mov #0,r5
    c.r[1] = ld32(c.r[0]);  // 06084A22 mov.l @r0,r1
    c.r[4] = 0x0u;  // 06084A24 mov #0,r4
    c.r[9] += c.r[1];  // 06084A26 add r1,r9
    c.r[9] += 2;  // 06084A28 add #2,r9
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06084A2A mov.b @r9,r6
    c.r[0] = ld32(0x06084AA8u);  // 06084A2C mov.l 0x06084AA8,r0
    c.r[6] = c.r[6] & 0xFFu; goto L_06084A40;  // 06084A2E bra 0x06084A40 ; extu.b r6,r6
L_06084A32:
    c.r[4] = ld32(0x06084ACCu);  // 06084A32 mov.l 0x06084ACC,r4
    { const uint32_t x = c.r[12]; c.pr = 0x06084A38u; c.r[5] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084A38u) return; }  // 06084A34 jsr @r12 ; mov r8,r5
    c.r[6] = 0x0u;  // 06084A38 mov #0,r6
    c.r[5] = 0x0u;  // 06084A3A mov #0,r5
    c.r[4] = 0x20u;  // 06084A3C mov #32,r4
    c.r[0] = ld32(0x06084AA8u);  // 06084A3E mov.l 0x06084AA8,r0
L_06084A40:
    { const uint32_t x = c.r[0]; c.pr = 0x06084A44u; c.r[10] += 1; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084A44u) return; }  // 06084A40 jsr @r0 ; add #1,r10
    c.r[1] = ld32(c.r[14]);  // 06084A44 mov.l @r14,r1
    c.r[1] <<= 2;  // 06084A46 shll2 r1
    c.r[1] += c.r[1];  // 06084A48 add r1,r1
    c.r[1] += c.r[11];  // 06084A4A add r11,r1
    c.t = (int32_t)c.r[10] >= (int32_t)c.r[1];  // 06084A4C cmp/ge r1,r10
    if (!c.t) { SH2_POLL(c); goto L_060849C4; }  // 06084A4E bf 0x060849C4
L_06084A50:
    c.r[1] = ld32(0x06084AB8u);  // 06084A50 mov.l 0x06084AB8,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06084A52 mov.b @r1,r5
    c.r[6] = (uint32_t)(int16_t)ld16(0x06084A8Cu);  // 06084A54 mov.w 0x06084A8C,r6
    c.r[1] = ld32(0x06084AD0u);  // 06084A56 mov.l 0x06084AD0,r1
    c.r[4] = ld32(c.r[1]);  // 06084A58 mov.l @r1,r4
    c.r[1] = ld32(0x06084AD4u);  // 06084A5A mov.l 0x06084AD4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06084A60u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084A60u) return; }  // 06084A5C jsr @r1 ; extu.b r5,r5
    c.r[10] = 0x0u;  // 06084A60 mov #0,r10
    c.r[8] = ld32(0x06084AD8u);  // 06084A62 mov.l 0x06084AD8,r8
    c.r[9] = ld32(0x06084ADCu);  // 06084A64 mov.l 0x06084ADC,r9
L_06084A66:
    c.r[1] = ld32(0x06084AD0u);  // 06084A66 mov.l 0x06084AD0,r1
    c.r[1] = ld32(c.r[1]);  // 06084A68 mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06084A92u);  // 06084A6A mov.w 0x06084A92,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06084A6C mov.b @(r0,r1),r1
    c.r[0] = c.r[1];  // 06084A6E mov r1,r0
    c.r[0] >>= 2;  // 06084A70 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06084A72 shlr r0
    c.r[0] &= 0x7u;  // 06084A74 and #7,r0
    c.t = (int32_t)c.r[10] >= (int32_t)c.r[0];  // 06084A76 cmp/ge r0,r10
    if (c.t) { goto L_06084AE4; }  // 06084A78 bt 0x06084AE4
    c.r[4] = ld32(0x06084AE0u);  // 06084A7A mov.l 0x06084AE0,r4
    { const uint32_t x = c.r[8]; c.pr = 0x06084A80u; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084A80u) return; }  // 06084A7C jsr @r8 ; mov #23,r5
    c.r[5] = 0x23u;  // 06084A80 mov #35,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06084A86u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084A86u) return; }  // 06084A82 jsr @r8 ; mov r0,r4
    c.r[5] = 0x37u; goto L_06084AF2;  // 06084A86 bra 0x06084AF2 ; mov #55,r5
L_06084AE4:
    c.r[4] = ld32(0x06084B8Cu);  // 06084AE4 mov.l 0x06084B8C,r4
    { const uint32_t x = c.r[8]; c.pr = 0x06084AEAu; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084AEAu) return; }  // 06084AE6 jsr @r8 ; mov #23,r5
    c.r[5] = 0x23u;  // 06084AEA mov #35,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06084AF0u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084AF0u) return; }  // 06084AEC jsr @r8 ; mov r0,r4
    c.r[5] = 0x38u;  // 06084AF0 mov #56,r5
L_06084AF2:
    { const uint32_t x = c.r[8]; c.pr = 0x06084AF6u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084AF6u) return; }  // 06084AF2 jsr @r8 ; mov r0,r4
    c.r[6] = 0x0u;  // 06084AF6 mov #0,r6
    c.r[5] = c.r[0];  // 06084AF8 mov r0,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06084AFEu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084AFEu) return; }  // 06084AFA jsr @r9 ; mov #0,r4
    c.r[10] += 1;  // 06084AFE add #1,r10
    c.r[1] = 0x3u;  // 06084B00 mov #3,r1
    c.t = (int32_t)c.r[10] > (int32_t)c.r[1];  // 06084B02 cmp/gt r1,r10
    if (!c.t) { SH2_POLL(c); goto L_06084A66; }  // 06084B04 bf 0x06084A66
    c.r[10] = 0x0u;  // 06084B06 mov #0,r10
    c.r[8] = ld32(0x06084B90u);  // 06084B08 mov.l 0x06084B90,r8
L_06084B0A:
    c.r[1] = ld32(0x06084B94u);  // 06084B0A mov.l 0x06084B94,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06084B0C mov.b @r1,r2
    c.r[1] = ld32(0x06084B98u);  // 06084B0E mov.l 0x06084B98,r1
    c.r[3] = ld32(c.r[1]);  // 06084B10 mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06084B12 extu.b r2,r2
    c.r[1] = 0x1Eu;  // 06084B14 mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 06084B16 mul.l r1,r2
    c.r[1] = c.macl;  // 06084B18 sts macl,r1
    c.r[1] += c.r[3];  // 06084B1A add r3,r1
    c.r[1] += c.r[10];  // 06084B1C add r10,r1
    c.r[1] += 17;  // 06084B1E add #17,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06084B20 mov.b @r1,r4
    c.r[5] = (uint32_t)(int16_t)ld16(0x06084B84u);  // 06084B22 mov.w 0x06084B84,r5
    c.r[4] = c.r[4] & 0xFFu;  // 06084B24 extu.b r4,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x06084B86u);  // 06084B26 mov.w 0x06084B86,r1
    { const uint32_t x = c.r[8]; c.pr = 0x06084B2Cu; c.r[4] |= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084B2Cu) return; }  // 06084B28 jsr @r8 ; or r1,r4
    c.r[10] += 1;  // 06084B2C add #1,r10
    c.r[1] = 0x3u;  // 06084B2E mov #3,r1
    c.t = (int32_t)c.r[10] > (int32_t)c.r[1];  // 06084B30 cmp/gt r1,r10
    { const bool k = !c.t; c.r[2] = 0x1u; if (k) { SH2_POLL(c); goto L_06084B0A; } }  // 06084B32 bf/s 0x06084B0A ; mov #1,r2
    c.r[1] = ld32(0x06084B9Cu);  // 06084B36 mov.l 0x06084B9C,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06084B88u);  // 06084B38 mov.w 0x06084B88,r0
    c.r[7] = 0x2u;  // 06084B3A mov #2,r7
    c.r[6] = 0x24u;  // 06084B3C mov #36,r6
    c.r[1] = ld32(c.r[1]);  // 06084B3E mov.l @r1,r1
    c.r[5] = 0x5u;  // 06084B40 mov #5,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06084B42 mov.b @(r0,r1),r1
    c.r[4] = 0x2u;  // 06084B44 mov #2,r4
    c.r[1] = c.r[1] & 0xFFu;  // 06084B46 extu.b r1,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06084B48 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06084B4A mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06084B4C mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06084B4E mov.l r2,@-r15
    c.r[1] = 0x0u;  // 06084B50 mov #0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06084B52 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 06084B54 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06084B56 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06084B58 mov.l r1,@-r15
    c.r[1] = 0x8u;  // 06084B5A mov #8,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06084B5C mov.l r1,@-r15
    c.r[1] = ld32(0x06084BA0u);  // 06084B5E mov.l 0x06084BA0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06084B64u; c.r[15] -= 4; st32(c.r[15], c.r[2]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084B64u) return; }  // 06084B60 jsr @r1 ; mov.l r2,@-r15
    c.r[15] += 40;  // 06084B64 add #40,r15
    c.r[1] = ld32(0x06084BA4u);  // 06084B66 mov.l 0x06084BA4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06084B6Cu; c.r[4] = 0x50u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084B6Cu) return; }  // 06084B68 jsr @r1 ; mov #80,r4
    c.r[14] += 4;  // 06084B6C add #4,r14
    c.r[15] = c.r[14];  // 06084B6E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06084B70 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06084B72 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06084B74 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06084B76 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06084B78 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06084B7A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06084B7C mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06084B8Au);  // 06084B7E mov.w 0x06084B8A,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06084B80 rts ; mov.l @r15+,r8
}

}  // namespace p_srwfin_installed
