#include "p_srwfin_installed_funcs.h"

namespace p_srwfin_installed {

void f_06039240(SH2Context& c) {
    ran[834] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06039240 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06039242 mov r15,r14
    c.r[0] = c.r[5];  // 06039244 mov r5,r0
    c.r[1] = ld32(0x06039260u);  // 06039246 mov.l 0x06039260,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x0603925Eu);  // 06039248 mov.w 0x0603925E,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603924A mov.b @r1,r2
    c.r[7] = 0xCu;  // 0603924C mov #12,r7
    c.r[3] &= c.r[2];  // 0603924E and r2,r3
    st8(c.r[1], c.r[3]);  // 06039250 mov.b r3,@r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0]); c.r[0] += 1;  // 06039252 mov.b @r0+,r2
    c.r[2] &= c.r[7];  // 06039254 and r7,r2
    c.r[3] |= c.r[2];  // 06039256 or r2,r3
    st8(c.r[1], c.r[3]);  // 06039258 mov.b r3,@r1
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603925A rts ; mov.l @r15+,r14
}

void f_06039264(SH2Context& c) {
    ran[835] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06039264 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06039266 mov r15,r14
    c.r[0] = c.r[5];  // 06039268 mov r5,r0
    c.r[1] = ld32(0x06039284u);  // 0603926A mov.l 0x06039284,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x06039282u);  // 0603926C mov.w 0x06039282,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603926E mov.b @r1,r2
    c.r[7] = 0x3u;  // 06039270 mov #3,r7
    c.r[3] &= c.r[2];  // 06039272 and r2,r3
    st8(c.r[1], c.r[3]);  // 06039274 mov.b r3,@r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0]); c.r[0] += 1;  // 06039276 mov.b @r0+,r2
    c.r[2] &= c.r[7];  // 06039278 and r7,r2
    c.r[3] |= c.r[2];  // 0603927A or r2,r3
    st8(c.r[1], c.r[3]);  // 0603927C mov.b r3,@r1
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603927E rts ; mov.l @r15+,r14
}

void f_06039288(SH2Context& c) {
    ran[836] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06039288 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0603928A mov r15,r14
    c.r[1] = ld32(0x060392BCu);  // 0603928C mov.l 0x060392BC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603928E mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06039290 extu.b r1,r1
    c.r[0] = c.r[1];  // 06039292 mov r1,r0
    c.r[0] >>= 2;  // 06039294 shlr2 r0
    c.r[0] >>= 2;  // 06039296 shlr2 r0
    c.r[0] >>= 2;  // 06039298 shlr2 r0
    c.r[1] >>= 2;  // 0603929A shlr2 r1
    c.r[1] >>= 2;  // 0603929C shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0603929E shlr r1
    c.r[1] >>= 2;  // 060392A0 shlr2 r1
    c.r[0] &= 0x1u;  // 060392A2 and #1,r0
    c.t = c.r[1] == c.r[0];  // 060392A4 cmp/eq r0,r1
    { const bool k = c.t; c.r[3] = c.r[5]; if (k) { goto L_060392B2; } }  // 060392A6 bt/s 0x060392B2 ; mov r5,r3
    c.r[1] = ld32(c.r[4] + 4);  // 060392AA mov.l @(4,r4),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x060392BAu);  // 060392AC mov.w 0x060392BA,r2
    c.r[2] -= c.r[1];  // 060392AE sub r1,r2
    st32(c.r[4] + 4, c.r[2]);  // 060392B0 mov.l r2,@(4,r4)
L_060392B2:
    c.r[15] = c.r[14];  // 060392B2 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060392B4 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[3]; c.pc = x; return; }  // 060392B6 rts ; mov r3,r0
}

void f_060392C0(SH2Context& c) {
    ran[837] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060392C0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060392C2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060392C4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060392C6 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060392C8 mov r15,r14
    c.r[8] = ld32(0x060392F8u);  // 060392CA mov.l 0x060392F8,r8
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[8]);  // 060392CC mov.b @r8,r0
    c.r[0] &= 0x1u;  // 060392CE and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060392D0 tst r0,r0
    { const bool k = c.t; c.r[9] = c.r[5]; if (k) { goto L_060392DC; } }  // 060392D2 bt/s 0x060392DC ; mov r5,r9
    c.r[1] = ld32(0x060392FCu);  // 060392D6 mov.l 0x060392FC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060392DCu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060392DCu) return; }  // 060392D8 jsr @r1 ; mov #0,r4
L_060392DC:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[8]);  // 060392DC mov.b @r8,r0
    c.r[0] &= 0x2u;  // 060392DE and #2,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060392E0 tst r0,r0
    if (c.t) { goto L_060392EA; }  // 060392E2 bt 0x060392EA
    c.r[1] = ld32(0x060392FCu);  // 060392E4 mov.l 0x060392FC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060392EAu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060392EAu) return; }  // 060392E6 jsr @r1 ; mov #1,r4
L_060392EA:
    c.r[15] = c.r[14];  // 060392EA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060392EC lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060392EE mov.l @r15+,r14
    c.r[0] = c.r[9];  // 060392F0 mov r9,r0
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060392F2 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060392F4 rts ; mov.l @r15+,r8
}

void f_06039300(SH2Context& c) {
    ran[838] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06039300 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06039302 mov r15,r14
    c.r[1] = ld32(0x0603934Cu);  // 06039304 mov.l 0x0603934C,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06039306 mov.b @r1,r0
    c.r[0] &= 0x1u;  // 06039308 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603930A tst r0,r0
    { const bool k = c.t; c.r[7] = c.r[5]; if (k) { goto L_06039320; } }  // 0603930C bt/s 0x06039320 ; mov r5,r7
    c.r[3] = ld32(0x06039350u);  // 06039310 mov.l 0x06039350,r3
    c.r[2] = ld32(c.r[3] + 32);  // 06039312 mov.l @(32,r3),r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603934Au);  // 06039314 mov.w 0x0603934A,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 06039316 cmp/gt r1,r2
    { const bool k = c.t; c.r[2] += 1; if (k) { goto L_0603931E; } }  // 06039318 bt/s 0x0603931E ; add #1,r2
    st32(c.r[3] + 32, c.r[2]);  // 0603931C mov.l r2,@(32,r3)
L_0603931E:
    c.r[1] = ld32(0x0603934Cu);  // 0603931E mov.l 0x0603934C,r1
L_06039320:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06039320 mov.b @r1,r0
    c.r[0] &= 0x2u;  // 06039322 and #2,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06039324 tst r0,r0
    { const bool k = c.t; c.r[15] = c.r[14]; if (k) { goto L_06039344; } }  // 06039326 bt/s 0x06039344 ; mov r14,r15
    c.r[3] = ld32(0x06039350u);  // 0603932A mov.l 0x06039350,r3
    c.r[1] = c.r[3];  // 0603932C mov r3,r1
    c.r[1] += 108;  // 0603932E add #108,r1
    c.r[2] = ld32(c.r[1]);  // 06039330 mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603934Au);  // 06039332 mov.w 0x0603934A,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 06039334 cmp/gt r1,r2
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_06039344; } }  // 06039336 bt/s 0x06039344 ; mov r3,r1
    c.r[1] += 92;  // 0603933A add #92,r1
    c.r[2] = ld32(c.r[1]);  // 0603933C mov.l @r1,r2
    c.r[2] += 1;  // 0603933E add #1,r2
    st32(c.r[1], c.r[2]);  // 06039340 mov.l r2,@r1
    c.r[15] = c.r[14];  // 06039342 mov r14,r15
L_06039344:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06039344 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[7]; c.pc = x; return; }  // 06039346 rts ; mov r7,r0
}

void f_06039354(SH2Context& c) {
    ran[839] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06039354 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06039356 mov r15,r14
    c.r[1] = ld32(0x0603939Cu);  // 06039358 mov.l 0x0603939C,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603935A mov.b @r1,r0
    c.r[0] &= 0x1u;  // 0603935C and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603935E tst r0,r0
    { const bool k = c.t; c.r[3] = c.r[5]; if (k) { goto L_06039372; } }  // 06039360 bt/s 0x06039372 ; mov r5,r3
    c.r[2] = ld32(0x060393A0u);  // 06039364 mov.l 0x060393A0,r2
    c.r[1] = ld32(c.r[2] + 32);  // 06039366 mov.l @(32,r2),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06039368 tst r1,r1
    { const bool k = c.t; c.r[1] -= 1; if (k) { goto L_06039370; } }  // 0603936A bt/s 0x06039370 ; add #-1,r1
    st32(c.r[2] + 32, c.r[1]);  // 0603936E mov.l r1,@(32,r2)
L_06039370:
    c.r[1] = ld32(0x0603939Cu);  // 06039370 mov.l 0x0603939C,r1
L_06039372:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06039372 mov.b @r1,r0
    c.r[0] &= 0x2u;  // 06039374 and #2,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06039376 tst r0,r0
    { const bool k = c.t; c.r[15] = c.r[14]; if (k) { goto L_06039394; } }  // 06039378 bt/s 0x06039394 ; mov r14,r15
    c.r[2] = ld32(0x060393A0u);  // 0603937C mov.l 0x060393A0,r2
    c.r[1] = c.r[2];  // 0603937E mov r2,r1
    c.r[1] += 108;  // 06039380 add #108,r1
    c.r[1] = ld32(c.r[1]);  // 06039382 mov.l @r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06039384 tst r1,r1
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_06039394; } }  // 06039386 bt/s 0x06039394 ; mov r2,r1
    c.r[1] += 92;  // 0603938A add #92,r1
    c.r[2] = ld32(c.r[1]);  // 0603938C mov.l @r1,r2
    c.r[2] -= 1;  // 0603938E add #-1,r2
    st32(c.r[1], c.r[2]);  // 06039390 mov.l r2,@r1
    c.r[15] = c.r[14];  // 06039392 mov r14,r15
L_06039394:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06039394 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[3]; c.pc = x; return; }  // 06039396 rts ; mov r3,r0
}

void f_060393A4(SH2Context& c) {
    ran[840] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060393A4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060393A6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060393A8 mov.l r14,@-r15
    c.r[7] = ld32(0x0603948Cu);  // 060393AA mov.l 0x0603948C,r7
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[7]);  // 060393AC mov.w @r7,r0
    c.r[6] = ld32(0x06039490u);  // 060393AE mov.l 0x06039490,r6
    c.r[0] |= 0x40u;  // 060393B0 or #64,r0
    st16(c.r[7], c.r[0]);  // 060393B2 mov.w r0,@r7
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[6]);  // 060393B4 mov.b @r6,r0
    c.r[0] &= 0x1u;  // 060393B6 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060393B8 tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_060393DE; } }  // 060393BA bt/s 0x060393DE ; mov r15,r14
    c.r[0] = c.r[5];  // 060393BE mov r5,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]); c.r[0] += 1;  // 060393C0 mov.b @r0+,r1
    c.r[2] = ld32(0x06039494u);  // 060393C2 mov.l 0x06039494,r2
    c.r[1] = c.r[1] & 0xFFu;  // 060393C4 extu.b r1,r1
    st32(c.r[2] + 32, c.r[1]);  // 060393C6 mov.l r1,@(32,r2)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 060393C8 mov.b @r0,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060393CA extu.b r1,r1
    st32(c.r[2] + 28, c.r[1]);  // 060393CC mov.l r1,@(28,r2)
    c.r[1] = c.r[5];  // 060393CE mov r5,r1
    c.r[1] += 2;  // 060393D0 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060393D2 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060393D4 extu.b r1,r1
    st32(c.r[2] + 36, c.r[1]);  // 060393D6 mov.l r1,@(36,r2)
    c.r[1] = 0x0u;  // 060393D8 mov #0,r1
    st32(c.r[2] + 40, c.r[1]);  // 060393DA mov.l r1,@(40,r2)
    st32(c.r[2] + 24, c.r[1]);  // 060393DC mov.l r1,@(24,r2)
L_060393DE:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[6]);  // 060393DE mov.b @r6,r0
    c.r[0] &= 0x2u;  // 060393E0 and #2,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060393E2 tst r0,r0
    { const bool k = c.t; c.r[0] = c.r[5]; if (k) { goto L_06039418; } }  // 060393E4 bt/s 0x06039418 ; mov r5,r0
    c.r[3] = ld32(0x06039494u);  // 060393E8 mov.l 0x06039494,r3
    c.r[2] = c.r[3];  // 060393EA mov r3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]); c.r[0] += 1;  // 060393EC mov.b @r0+,r1
    c.r[2] += 92;  // 060393EE add #92,r2
    c.r[1] = c.r[1] & 0xFFu;  // 060393F0 extu.b r1,r1
    st32(c.r[2], c.r[1]);  // 060393F2 mov.l r1,@r2
    c.r[2] = c.r[3];  // 060393F4 mov r3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 060393F6 mov.b @r0,r1
    c.r[2] += 88;  // 060393F8 add #88,r2
    c.r[1] = c.r[1] & 0xFFu;  // 060393FA extu.b r1,r1
    st32(c.r[2], c.r[1]);  // 060393FC mov.l r1,@r2
    c.r[2] = c.r[3];  // 060393FE mov r3,r2
    c.r[1] = c.r[5];  // 06039400 mov r5,r1
    c.r[1] += 2;  // 06039402 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06039404 mov.b @r1,r1
    c.r[2] += 96;  // 06039406 add #96,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06039408 extu.b r1,r1
    st32(c.r[2], c.r[1]);  // 0603940A mov.l r1,@r2
    c.r[1] = c.r[3];  // 0603940C mov r3,r1
    c.r[1] += 100;  // 0603940E add #100,r1
    c.r[2] = 0x0u;  // 06039410 mov #0,r2
    st32(c.r[1], c.r[2]);  // 06039412 mov.l r2,@r1
    c.r[3] += 84;  // 06039414 add #84,r3
    st32(c.r[3], c.r[2]);  // 06039416 mov.l r2,@r3
L_06039418:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[7]);  // 06039418 mov.w @r7,r0
    c.r[0] |= 0x40u;  // 0603941A or #64,r0
    st16(c.r[7], c.r[0]);  // 0603941C mov.w r0,@r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[5]);  // 0603941E mov.b @r5,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06039420 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06039422 tst r1,r1
    { const bool k = !c.t; c.r[1] = 0x1u; if (k) { goto L_0603947A; } }  // 06039424 bf/s 0x0603947A ; mov #1,r1
    c.r[1] &= c.r[0];  // 06039428 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603942A tst r1,r1
    { const bool k = !c.t; c.r[3] = 0x0u; if (k) { goto L_06039436; } }  // 0603942C bf/s 0x06039436 ; mov #0,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x06039488u);  // 06039430 mov.w 0x06039488,r1
    c.r[0] &= c.r[1];  // 06039432 and r1,r0
    st16(c.r[7], c.r[0]);  // 06039434 mov.w r0,@r7
L_06039436:
    c.r[4] = c.r[6];  // 06039436 mov r6,r4
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4]);  // 06039438 mov.b @r4,r0
    c.r[8] = 0x1u;  // 0603943A mov #1,r8
    c.r[6] = ld32(0x06039494u);  // 0603943C mov.l 0x06039494,r6
    c.r[7] = 0x0u;  // 0603943E mov #0,r7
    c.r[9] = c.r[6];  // 06039440 mov r6,r9
    c.r[9] += 68;  // 06039442 add #68,r9
    c.r[2] = 0x0u;  // 06039444 mov #0,r2
    c.r[8] &= c.r[0];  // 06039446 and r0,r8
L_06039448:
    c.t = (c.r[8] & c.r[8]) == 0;  // 06039448 tst r8,r8
    if (c.t) { goto L_06039458; }  // 0603944A bt 0x06039458
    c.r[0] = ld32(c.r[6] + 16);  // 0603944C mov.l @(16,r6),r0
    st32(c.r[0] + c.r[2], c.r[7]);  // 0603944E mov.l r7,@(r0,r2)
    c.r[0] = c.r[3];  // 06039450 mov r3,r0
    c.r[1] = ld32(c.r[6] + 8);  // 06039452 mov.l @(8,r6),r1
    c.r[0] <<= 2;  // 06039454 shll2 r0
    st32(c.r[0] + c.r[1], c.r[7]);  // 06039456 mov.l r7,@(r0,r1)
L_06039458:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4]);  // 06039458 mov.b @r4,r0
    c.r[0] &= 0x2u;  // 0603945A and #2,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603945C tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[6]; if (k) { goto L_06039470; } }  // 0603945E bt/s 0x06039470 ; mov r6,r1
    c.r[1] += 76;  // 06039462 add #76,r1
    c.r[0] = ld32(c.r[1]);  // 06039464 mov.l @r1,r0
    st32(c.r[0] + c.r[2], c.r[7]);  // 06039466 mov.l r7,@(r0,r2)
    c.r[0] = c.r[3];  // 06039468 mov r3,r0
    c.r[1] = ld32(c.r[9]);  // 0603946A mov.l @r9,r1
    c.r[0] <<= 2;  // 0603946C shll2 r0
    st32(c.r[0] + c.r[1], c.r[7]);  // 0603946E mov.l r7,@(r0,r1)
L_06039470:
    c.r[3] += 1;  // 06039470 add #1,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603948Au);  // 06039472 mov.w 0x0603948A,r1
    c.t = (int32_t)c.r[3] > (int32_t)c.r[1];  // 06039474 cmp/gt r1,r3
    { const bool k = !c.t; c.r[2] += 8; if (k) { SH2_POLL(c); goto L_06039448; } }  // 06039476 bf/s 0x06039448 ; add #8,r2
L_0603947A:
    c.r[15] = c.r[14];  // 0603947A mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603947C mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0603947E mov.l @r15+,r9
    c.r[5] += 3;  // 06039480 add #3,r5
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06039482 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.r[0] = c.r[5]; c.pc = x; return; }  // 06039484 rts ; mov r5,r0
}

void f_06039498(SH2Context& c) {
    ran[841] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06039498 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603949A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603949C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603949E sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060394A0 mov r15,r14
    c.r[8] = ld32(0x060394D0u);  // 060394A2 mov.l 0x060394D0,r8
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[8]);  // 060394A4 mov.b @r8,r0
    c.r[0] &= 0x1u;  // 060394A6 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060394A8 tst r0,r0
    { const bool k = c.t; c.r[9] = c.r[5]; if (k) { goto L_060394B4; } }  // 060394AA bt/s 0x060394B4 ; mov r5,r9
    c.r[1] = ld32(0x060394D4u);  // 060394AE mov.l 0x060394D4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060394B4u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060394B4u) return; }  // 060394B0 jsr @r1 ; mov #0,r4
L_060394B4:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[8]);  // 060394B4 mov.b @r8,r0
    c.r[0] &= 0x2u;  // 060394B6 and #2,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060394B8 tst r0,r0
    if (c.t) { goto L_060394C2; }  // 060394BA bt 0x060394C2
    c.r[1] = ld32(0x060394D4u);  // 060394BC mov.l 0x060394D4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060394C2u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060394C2u) return; }  // 060394BE jsr @r1 ; mov #1,r4
L_060394C2:
    c.r[15] = c.r[14];  // 060394C2 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060394C4 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060394C6 mov.l @r15+,r14
    c.r[0] = c.r[9];  // 060394C8 mov r9,r0
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060394CA mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060394CC rts ; mov.l @r15+,r8
}

void f_060394D8(SH2Context& c) {
    ran[842] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060394D8 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 060394DA mov r15,r14
    c.r[1] = ld32(0x0603951Cu);  // 060394DC mov.l 0x0603951C,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060394DE mov.b @r1,r0
    c.r[0] &= 0x1u;  // 060394E0 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060394E2 tst r0,r0
    { const bool k = c.t; c.r[7] = c.r[5]; if (k) { goto L_060394F8; } }  // 060394E4 bt/s 0x060394F8 ; mov r5,r7
    c.r[3] = ld32(0x06039520u);  // 060394E8 mov.l 0x06039520,r3
    c.r[2] = ld32(c.r[3] + 48);  // 060394EA mov.l @(48,r3),r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06039518u);  // 060394EC mov.w 0x06039518,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 060394EE cmp/gt r1,r2
    { const bool k = c.t; c.r[2] += 1; if (k) { goto L_060394F6; } }  // 060394F0 bt/s 0x060394F6 ; add #1,r2
    st32(c.r[3] + 48, c.r[2]);  // 060394F4 mov.l r2,@(48,r3)
L_060394F6:
    c.r[1] = ld32(0x0603951Cu);  // 060394F6 mov.l 0x0603951C,r1
L_060394F8:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060394F8 mov.b @r1,r0
    c.r[0] &= 0x2u;  // 060394FA and #2,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060394FC tst r0,r0
    { const bool k = c.t; c.r[15] = c.r[14]; if (k) { goto L_06039512; } }  // 060394FE bt/s 0x06039512 ; mov r14,r15
    c.r[3] = ld32(0x06039524u);  // 06039502 mov.l 0x06039524,r3
    c.r[2] = ld32(c.r[3]);  // 06039504 mov.l @r3,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06039518u);  // 06039506 mov.w 0x06039518,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 06039508 cmp/gt r1,r2
    { const bool k = c.t; c.r[2] += 1; if (k) { goto L_06039512; } }  // 0603950A bt/s 0x06039512 ; add #1,r2
    st32(c.r[3], c.r[2]);  // 0603950E mov.l r2,@r3
    c.r[15] = c.r[14];  // 06039510 mov r14,r15
L_06039512:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06039512 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[7]; c.pc = x; return; }  // 06039514 rts ; mov r7,r0
}

void f_06039528(SH2Context& c) {
    ran[843] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06039528 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0603952A mov r15,r14
    c.r[1] = ld32(0x06039564u);  // 0603952C mov.l 0x06039564,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603952E mov.b @r1,r0
    c.r[0] &= 0x1u;  // 06039530 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06039532 tst r0,r0
    { const bool k = c.t; c.r[3] = c.r[5]; if (k) { goto L_06039546; } }  // 06039534 bt/s 0x06039546 ; mov r5,r3
    c.r[2] = ld32(0x06039568u);  // 06039538 mov.l 0x06039568,r2
    c.r[1] = ld32(c.r[2] + 48);  // 0603953A mov.l @(48,r2),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603953C tst r1,r1
    { const bool k = c.t; c.r[1] -= 1; if (k) { goto L_06039544; } }  // 0603953E bt/s 0x06039544 ; add #-1,r1
    st32(c.r[2] + 48, c.r[1]);  // 06039542 mov.l r1,@(48,r2)
L_06039544:
    c.r[1] = ld32(0x06039564u);  // 06039544 mov.l 0x06039564,r1
L_06039546:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06039546 mov.b @r1,r0
    c.r[0] &= 0x2u;  // 06039548 and #2,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603954A tst r0,r0
    { const bool k = c.t; c.r[15] = c.r[14]; if (k) { goto L_0603955E; } }  // 0603954C bt/s 0x0603955E ; mov r14,r15
    c.r[2] = ld32(0x0603956Cu);  // 06039550 mov.l 0x0603956C,r2
    c.r[1] = ld32(c.r[2]);  // 06039552 mov.l @r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06039554 tst r1,r1
    { const bool k = c.t; c.r[1] -= 1; if (k) { goto L_0603955E; } }  // 06039556 bt/s 0x0603955E ; add #-1,r1
    st32(c.r[2], c.r[1]);  // 0603955A mov.l r1,@r2
    c.r[15] = c.r[14];  // 0603955C mov r14,r15
L_0603955E:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603955E mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[3]; c.pc = x; return; }  // 06039560 rts ; mov r3,r0
}

void f_06039570(SH2Context& c) {
    ran[844] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06039570 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06039572 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06039574 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06039576 mov.l r14,@-r15
    c.r[7] = ld32(0x06039668u);  // 06039578 mov.l 0x06039668,r7
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[7]);  // 0603957A mov.w @r7,r0
    c.r[6] = ld32(0x0603966Cu);  // 0603957C mov.l 0x0603966C,r6
    c.r[0] |= 0x40u;  // 0603957E or #64,r0
    st16(c.r[7], c.r[0]);  // 06039580 mov.w r0,@r7
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[6]);  // 06039582 mov.b @r6,r0
    c.r[0] &= 0x1u;  // 06039584 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06039586 tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_060395AC; } }  // 06039588 bt/s 0x060395AC ; mov r15,r14
    c.r[0] = c.r[5];  // 0603958C mov r5,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]); c.r[0] += 1;  // 0603958E mov.b @r0+,r1
    c.r[2] = ld32(0x06039670u);  // 06039590 mov.l 0x06039670,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06039592 extu.b r1,r1
    st32(c.r[2] + 48, c.r[1]);  // 06039594 mov.l r1,@(48,r2)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06039596 mov.b @r0,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06039598 extu.b r1,r1
    st32(c.r[2] + 44, c.r[1]);  // 0603959A mov.l r1,@(44,r2)
    c.r[1] = c.r[5];  // 0603959C mov r5,r1
    c.r[1] += 2;  // 0603959E add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060395A0 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060395A2 extu.b r1,r1
    st32(c.r[2] + 52, c.r[1]);  // 060395A4 mov.l r1,@(52,r2)
    c.r[1] = 0x0u;  // 060395A6 mov #0,r1
    st32(c.r[2] + 56, c.r[1]);  // 060395A8 mov.l r1,@(56,r2)
    st32(c.r[2] + 24, c.r[1]);  // 060395AA mov.l r1,@(24,r2)
L_060395AC:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[6]);  // 060395AC mov.b @r6,r0
    c.r[0] &= 0x2u;  // 060395AE and #2,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060395B0 tst r0,r0
    { const bool k = c.t; c.r[0] = c.r[5]; if (k) { goto L_060395E6; } }  // 060395B2 bt/s 0x060395E6 ; mov r5,r0
    c.r[3] = ld32(0x06039670u);  // 060395B6 mov.l 0x06039670,r3
    c.r[2] = c.r[3];  // 060395B8 mov r3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]); c.r[0] += 1;  // 060395BA mov.b @r0+,r1
    c.r[2] += 108;  // 060395BC add #108,r2
    c.r[1] = c.r[1] & 0xFFu;  // 060395BE extu.b r1,r1
    st32(c.r[2], c.r[1]);  // 060395C0 mov.l r1,@r2
    c.r[2] = c.r[3];  // 060395C2 mov r3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 060395C4 mov.b @r0,r1
    c.r[2] += 104;  // 060395C6 add #104,r2
    c.r[1] = c.r[1] & 0xFFu;  // 060395C8 extu.b r1,r1
    st32(c.r[2], c.r[1]);  // 060395CA mov.l r1,@r2
    c.r[2] = c.r[3];  // 060395CC mov r3,r2
    c.r[1] = c.r[5];  // 060395CE mov r5,r1
    c.r[1] += 2;  // 060395D0 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060395D2 mov.b @r1,r1
    c.r[2] += 112;  // 060395D4 add #112,r2
    c.r[1] = c.r[1] & 0xFFu;  // 060395D6 extu.b r1,r1
    st32(c.r[2], c.r[1]);  // 060395D8 mov.l r1,@r2
    c.r[1] = c.r[3];  // 060395DA mov r3,r1
    c.r[1] += 116;  // 060395DC add #116,r1
    c.r[2] = 0x0u;  // 060395DE mov #0,r2
    st32(c.r[1], c.r[2]);  // 060395E0 mov.l r2,@r1
    c.r[3] += 84;  // 060395E2 add #84,r3
    st32(c.r[3], c.r[2]);  // 060395E4 mov.l r2,@r3
L_060395E6:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[7]);  // 060395E6 mov.w @r7,r0
    c.r[0] |= 0x40u;  // 060395E8 or #64,r0
    st16(c.r[7], c.r[0]);  // 060395EA mov.w r0,@r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[5]);  // 060395EC mov.b @r5,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060395EE extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060395F0 tst r1,r1
    { const bool k = !c.t; c.r[1] = 0x1u; if (k) { goto L_06039654; } }  // 060395F2 bf/s 0x06039654 ; mov #1,r1
    c.r[1] &= c.r[0];  // 060395F6 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060395F8 tst r1,r1
    { const bool k = !c.t; c.r[3] = 0x0u; if (k) { goto L_06039604; } }  // 060395FA bf/s 0x06039604 ; mov #0,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x06039664u);  // 060395FE mov.w 0x06039664,r1
    c.r[0] &= c.r[1];  // 06039600 and r1,r0
    st16(c.r[7], c.r[0]);  // 06039602 mov.w r0,@r7
L_06039604:
    c.r[8] = c.r[6];  // 06039604 mov r6,r8
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06039606 mov.b @r8,r0
    c.r[9] = 0x1u;  // 06039608 mov #1,r9
    c.r[6] = ld32(0x06039670u);  // 0603960A mov.l 0x06039670,r6
    c.r[4] = 0x0u;  // 0603960C mov #0,r4
    c.r[10] = c.r[6];  // 0603960E mov r6,r10
    c.r[10] += 72;  // 06039610 add #72,r10
    c.r[7] = 0x0u;  // 06039612 mov #0,r7
    c.r[9] &= c.r[0];  // 06039614 and r0,r9
L_06039616:
    c.t = (c.r[9] & c.r[9]) == 0;  // 06039616 tst r9,r9
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_0603962C; } }  // 06039618 bt/s 0x0603962C ; mov r3,r1
    c.r[1] <<= 16;  // 0603961C shll16 r1
    c.r[2] = ld32(c.r[6] + 16);  // 0603961E mov.l @(16,r6),r2
    c.r[0] = c.r[3];  // 06039620 mov r3,r0
    c.r[2] += c.r[7];  // 06039622 add r7,r2
    st32(c.r[2] + 4, c.r[1]);  // 06039624 mov.l r1,@(4,r2)
    c.r[1] = ld32(c.r[6] + 12);  // 06039626 mov.l @(12,r6),r1
    c.r[0] <<= 2;  // 06039628 shll2 r0
    st32(c.r[0] + c.r[1], c.r[4]);  // 0603962A mov.l r4,@(r0,r1)
L_0603962C:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0603962C mov.b @r8,r0
    c.r[0] &= 0x2u;  // 0603962E and #2,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06039630 tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[6]; if (k) { goto L_0603964A; } }  // 06039632 bt/s 0x0603964A ; mov r6,r1
    c.r[1] += 76;  // 06039636 add #76,r1
    c.r[2] = ld32(c.r[1]);  // 06039638 mov.l @r1,r2
    c.r[0] = c.r[3];  // 0603963A mov r3,r0
    c.r[2] += c.r[7];  // 0603963C add r7,r2
    c.r[1] = c.r[3];  // 0603963E mov r3,r1
    c.r[1] <<= 16;  // 06039640 shll16 r1
    st32(c.r[2] + 4, c.r[1]);  // 06039642 mov.l r1,@(4,r2)
    c.r[1] = ld32(c.r[10]);  // 06039644 mov.l @r10,r1
    c.r[0] <<= 2;  // 06039646 shll2 r0
    st32(c.r[0] + c.r[1], c.r[4]);  // 06039648 mov.l r4,@(r0,r1)
L_0603964A:
    c.r[3] += 1;  // 0603964A add #1,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x06039666u);  // 0603964C mov.w 0x06039666,r1
    c.t = (int32_t)c.r[3] > (int32_t)c.r[1];  // 0603964E cmp/gt r1,r3
    { const bool k = !c.t; c.r[7] += 8; if (k) { SH2_POLL(c); goto L_06039616; } }  // 06039650 bf/s 0x06039616 ; add #8,r7
L_06039654:
    c.r[15] = c.r[14];  // 06039654 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06039656 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06039658 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0603965A mov.l @r15+,r9
    c.r[5] += 3;  // 0603965C add #3,r5
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0603965E mov.l @r15+,r8
    { const uint32_t x = c.pr; c.r[0] = c.r[5]; c.pc = x; return; }  // 06039660 rts ; mov r5,r0
}

void f_06039674(SH2Context& c) {
    ran[845] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06039674 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06039676 mov r15,r14
    c.r[0] = c.r[5];  // 06039678 mov r5,r0
    c.r[1] = ld32(0x06039688u);  // 0603967A mov.l 0x06039688,r1
    c.r[3] = 0x3u;  // 0603967C mov #3,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0]); c.r[0] += 1;  // 0603967E mov.b @r0+,r2
    c.r[2] &= c.r[3];  // 06039680 and r3,r2
    st8(c.r[1], c.r[2]);  // 06039682 mov.b r2,@r1
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06039684 rts ; mov.l @r15+,r14
}

void f_0603968C(SH2Context& c) {
    ran[846] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603968C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603968E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06039690 sts.l pr,@-r15
    c.r[8] = c.r[5];  // 06039692 mov r5,r8
    c.r[1] = ld32(0x06039704u);  // 06039694 mov.l 0x06039704,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06039696 mov.b @r1,r1
    c.r[5] = ld32(0x06039708u);  // 06039698 mov.l 0x06039708,r5
    c.r[0] = c.r[1];  // 0603969A mov r1,r0
    c.r[0] >>= 2;  // 0603969C shlr2 r0
    c.r[0] >>= 2;  // 0603969E shlr2 r0
    c.r[0] >>= 2;  // 060396A0 shlr2 r0
    c.r[0] &= 0x1u;  // 060396A2 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060396A4 tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_060396AC; } }  // 060396A6 bt/s 0x060396AC ; mov r15,r14
    c.r[5] = ld32(0x0603970Cu);  // 060396AA mov.l 0x0603970C,r5
L_060396AC:
    c.r[1] = c.r[5];  // 060396AC mov r5,r1
    c.r[1] += 6;  // 060396AE add #6,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060396B0 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 060396B2 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060396B4 tst r1,r1
    { const bool k = !c.t; c.t = (c.r[0] & c.r[0]) == 0; if (k) { goto L_060396C0; } }  // 060396B6 bf/s 0x060396C0 ; tst r0,r0
    c.r[5] = ld32(0x06039710u);  // 060396BA mov.l 0x06039710,r5
    if (c.t) { goto L_060396C0; }  // 060396BC bt 0x060396C0
    c.r[5] = ld32(0x06039714u);  // 060396BE mov.l 0x06039714,r5
L_060396C0:
    c.r[0] = ld32(0x06039718u);  // 060396C0 mov.l 0x06039718,r0
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[5]);  // 060396C2 mov.b @r5,r5
    c.r[4] = 0x1u;  // 060396C4 mov #1,r4
    c.r[5] = c.r[5] & 0xFFu;  // 060396C6 extu.b r5,r5
    c.r[5] >>= 2;  // 060396C8 shlr2 r5
    c.t = c.r[5] & 1; c.r[5] >>= 1;  // 060396CA shlr r5
    { const uint32_t x = c.r[0]; c.pr = 0x060396D0u; c.r[5] >>= 2; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060396D0u) return; }  // 060396CC jsr @r0 ; shlr2 r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 060396D0 mov.b @r8,r1
    c.r[2] = c.r[0] & 0xFFu;  // 060396D2 extu.b r0,r2
    c.r[2] &= c.r[1];  // 060396D4 and r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 060396D6 tst r2,r2
    { const bool k = c.t; c.r[1] = c.r[8]; if (k) { goto L_060396F6; } }  // 060396D8 bt/s 0x060396F6 ; mov r8,r1
    c.r[1] += 1;  // 060396DC add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060396DE mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 060396E0 extu.b r2,r2
    c.r[1] = c.r[8];  // 060396E2 mov r8,r1
    c.r[1] += 2;  // 060396E4 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060396E6 mov.b @r1,r1
    c.r[2] <<= 8;  // 060396E8 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 060396EA extu.b r1,r1
    c.r[2] |= c.r[1];  // 060396EC or r1,r2
    c.r[2] += 1;  // 060396EE add #1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 060396F0 exts.w r2,r2
    c.r[8] += c.r[2]; goto L_060396F8;  // 060396F2 bra 0x060396F8 ; add r2,r8
L_060396F6:
    c.r[8] += 3;  // 060396F6 add #3,r8
L_060396F8:
    c.r[15] = c.r[14];  // 060396F8 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060396FA lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060396FC mov.l @r15+,r14
    c.r[0] = c.r[8];  // 060396FE mov r8,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06039700 rts ; mov.l @r15+,r8
}

void f_0603971C(SH2Context& c) {
    ran[847] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603971C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603971E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06039720 sts.l pr,@-r15
    c.r[8] = c.r[5];  // 06039722 mov r5,r8
    c.r[1] = ld32(0x06039794u);  // 06039724 mov.l 0x06039794,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06039726 mov.b @r1,r1
    c.r[5] = ld32(0x06039798u);  // 06039728 mov.l 0x06039798,r5
    c.r[0] = c.r[1];  // 0603972A mov r1,r0
    c.r[0] >>= 2;  // 0603972C shlr2 r0
    c.r[0] >>= 2;  // 0603972E shlr2 r0
    c.r[0] >>= 2;  // 06039730 shlr2 r0
    c.r[0] &= 0x1u;  // 06039732 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06039734 tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0603973C; } }  // 06039736 bt/s 0x0603973C ; mov r15,r14
    c.r[5] = ld32(0x0603979Cu);  // 0603973A mov.l 0x0603979C,r5
L_0603973C:
    c.r[1] = c.r[5];  // 0603973C mov r5,r1
    c.r[1] += 6;  // 0603973E add #6,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06039740 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06039742 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06039744 tst r1,r1
    { const bool k = !c.t; c.t = (c.r[0] & c.r[0]) == 0; if (k) { goto L_06039750; } }  // 06039746 bf/s 0x06039750 ; tst r0,r0
    c.r[5] = ld32(0x060397A0u);  // 0603974A mov.l 0x060397A0,r5
    if (c.t) { goto L_06039750; }  // 0603974C bt 0x06039750
    c.r[5] = ld32(0x060397A4u);  // 0603974E mov.l 0x060397A4,r5
L_06039750:
    c.r[0] = ld32(0x060397A8u);  // 06039750 mov.l 0x060397A8,r0
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[5]);  // 06039752 mov.b @r5,r5
    c.r[4] = 0x1u;  // 06039754 mov #1,r4
    c.r[5] = c.r[5] & 0xFFu;  // 06039756 extu.b r5,r5
    c.r[5] >>= 2;  // 06039758 shlr2 r5
    c.t = c.r[5] & 1; c.r[5] >>= 1;  // 0603975A shlr r5
    { const uint32_t x = c.r[0]; c.pr = 0x06039760u; c.r[5] >>= 2; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06039760u) return; }  // 0603975C jsr @r0 ; shlr2 r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06039760 mov.b @r8,r1
    c.r[2] = c.r[0] & 0xFFu;  // 06039762 extu.b r0,r2
    c.r[2] &= c.r[1];  // 06039764 and r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06039766 tst r2,r2
    { const bool k = c.t; c.r[1] = c.r[8]; if (k) { goto L_06039786; } }  // 06039768 bt/s 0x06039786 ; mov r8,r1
    c.r[1] += 1;  // 0603976C add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603976E mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 06039770 extu.b r2,r2
    c.r[1] = c.r[8];  // 06039772 mov r8,r1
    c.r[1] += 2;  // 06039774 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06039776 mov.b @r1,r1
    c.r[2] <<= 8;  // 06039778 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603977A extu.b r1,r1
    c.r[2] |= c.r[1];  // 0603977C or r1,r2
    c.r[2] += 1;  // 0603977E add #1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 06039780 exts.w r2,r2
    c.r[8] += c.r[2]; goto L_06039788;  // 06039782 bra 0x06039788 ; add r2,r8
L_06039786:
    c.r[8] += 3;  // 06039786 add #3,r8
L_06039788:
    c.r[15] = c.r[14];  // 06039788 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603978A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603978C mov.l @r15+,r14
    c.r[0] = c.r[8];  // 0603978E mov r8,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06039790 rts ; mov.l @r15+,r8
}

void f_060397AC(SH2Context& c) {
    ran[848] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060397AC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060397AE mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060397B0 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060397B2 mov r15,r14
    c.r[1] = ld32(0x06039828u);  // 060397B4 mov.l 0x06039828,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060397B6 mov.b @r1,r1
    c.r[0] = c.r[1];  // 060397B8 mov r1,r0
    c.r[0] >>= 2;  // 060397BA shlr2 r0
    c.r[0] >>= 2;  // 060397BC shlr2 r0
    c.r[0] >>= 2;  // 060397BE shlr2 r0
    c.r[0] &= 0x1u;  // 060397C0 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060397C2 tst r0,r0
    { const bool k = c.t; c.r[8] = c.r[5]; if (k) { goto L_060397CE; } }  // 060397C4 bt/s 0x060397CE ; mov r5,r8
    c.r[1] = ld32(0x0603982Cu);  // 060397C8 mov.l 0x0603982C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]); goto L_060397D2;  // 060397CA bra 0x060397D2 ; mov.b @r1,r1
L_060397CE:
    c.r[1] = ld32(0x06039830u);  // 060397CE mov.l 0x06039830,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060397D0 mov.b @r1,r1
L_060397D2:
    c.r[2] = c.r[1] & 0xFFu;  // 060397D2 extu.b r1,r2
    c.r[1] = ld32(0x06039834u);  // 060397D4 mov.l 0x06039834,r1
    c.r[2] += c.r[2];  // 060397D6 add r2,r2
    c.r[3] = 0x3u;  // 060397D8 mov #3,r3
    c.r[1] = ld32(c.r[1]);  // 060397DA mov.l @r1,r1
    c.r[0] = ld32(0x06039838u);  // 060397DC mov.l 0x06039838,r0
    c.r[2] += c.r[1];  // 060397DE add r1,r2
    c.r[2] += 1;  // 060397E0 add #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060397E2 mov.b @r2,r1
    c.r[4] = 0x1u;  // 060397E4 mov #1,r4
    c.r[1] >>= 2;  // 060397E6 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060397E8 shlr r1
    c.r[1] >>= 2;  // 060397EA shlr2 r1
    c.r[1] &= c.r[3];  // 060397EC and r3,r1
    { const uint32_t x = c.r[0]; c.pr = 0x060397F2u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060397F2u) return; }  // 060397EE jsr @r0 ; mov r1,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 060397F2 mov.b @r8,r1
    c.r[2] = c.r[0] & 0xFFu;  // 060397F4 extu.b r0,r2
    c.r[2] &= c.r[1];  // 060397F6 and r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 060397F8 tst r2,r2
    { const bool k = c.t; c.r[1] = c.r[8]; if (k) { goto L_06039818; } }  // 060397FA bt/s 0x06039818 ; mov r8,r1
    c.r[1] += 1;  // 060397FE add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06039800 mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 06039802 extu.b r2,r2
    c.r[1] = c.r[8];  // 06039804 mov r8,r1
    c.r[1] += 2;  // 06039806 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06039808 mov.b @r1,r1
    c.r[2] <<= 8;  // 0603980A shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603980C extu.b r1,r1
    c.r[2] |= c.r[1];  // 0603980E or r1,r2
    c.r[2] += 1;  // 06039810 add #1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 06039812 exts.w r2,r2
    c.r[8] += c.r[2]; goto L_0603981A;  // 06039814 bra 0x0603981A ; add r2,r8
L_06039818:
    c.r[8] += 3;  // 06039818 add #3,r8
L_0603981A:
    c.r[15] = c.r[14];  // 0603981A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603981C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603981E mov.l @r15+,r14
    c.r[0] = c.r[8];  // 06039820 mov r8,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06039822 rts ; mov.l @r15+,r8
}

void f_0603983C(SH2Context& c) {
    ran[849] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603983C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603983E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06039840 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06039842 mov r15,r14
    c.r[1] = ld32(0x060398B8u);  // 06039844 mov.l 0x060398B8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06039846 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06039848 mov r1,r0
    c.r[0] >>= 2;  // 0603984A shlr2 r0
    c.r[0] >>= 2;  // 0603984C shlr2 r0
    c.r[0] >>= 2;  // 0603984E shlr2 r0
    c.r[0] &= 0x1u;  // 06039850 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06039852 tst r0,r0
    { const bool k = c.t; c.r[8] = c.r[5]; if (k) { goto L_0603985E; } }  // 06039854 bt/s 0x0603985E ; mov r5,r8
    c.r[1] = ld32(0x060398BCu);  // 06039858 mov.l 0x060398BC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]); goto L_06039862;  // 0603985A bra 0x06039862 ; mov.b @r1,r1
L_0603985E:
    c.r[1] = ld32(0x060398C0u);  // 0603985E mov.l 0x060398C0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06039860 mov.b @r1,r1
L_06039862:
    c.r[2] = c.r[1] & 0xFFu;  // 06039862 extu.b r1,r2
    c.r[1] = ld32(0x060398C4u);  // 06039864 mov.l 0x060398C4,r1
    c.r[2] += c.r[2];  // 06039866 add r2,r2
    c.r[3] = 0x3u;  // 06039868 mov #3,r3
    c.r[1] = ld32(c.r[1]);  // 0603986A mov.l @r1,r1
    c.r[0] = ld32(0x060398C8u);  // 0603986C mov.l 0x060398C8,r0
    c.r[2] += c.r[1];  // 0603986E add r1,r2
    c.r[2] += 1;  // 06039870 add #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06039872 mov.b @r2,r1
    c.r[4] = 0x1u;  // 06039874 mov #1,r4
    c.r[1] >>= 2;  // 06039876 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06039878 shlr r1
    c.r[1] >>= 2;  // 0603987A shlr2 r1
    c.r[1] &= c.r[3];  // 0603987C and r3,r1
    { const uint32_t x = c.r[0]; c.pr = 0x06039882u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06039882u) return; }  // 0603987E jsr @r0 ; mov r1,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06039882 mov.b @r8,r1
    c.r[2] = c.r[0] & 0xFFu;  // 06039884 extu.b r0,r2
    c.r[2] &= c.r[1];  // 06039886 and r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06039888 tst r2,r2
    { const bool k = c.t; c.r[1] = c.r[8]; if (k) { goto L_060398A8; } }  // 0603988A bt/s 0x060398A8 ; mov r8,r1
    c.r[1] += 1;  // 0603988E add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06039890 mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 06039892 extu.b r2,r2
    c.r[1] = c.r[8];  // 06039894 mov r8,r1
    c.r[1] += 2;  // 06039896 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06039898 mov.b @r1,r1
    c.r[2] <<= 8;  // 0603989A shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603989C extu.b r1,r1
    c.r[2] |= c.r[1];  // 0603989E or r1,r2
    c.r[2] += 1;  // 060398A0 add #1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 060398A2 exts.w r2,r2
    c.r[8] += c.r[2]; goto L_060398AA;  // 060398A4 bra 0x060398AA ; add r2,r8
L_060398A8:
    c.r[8] += 3;  // 060398A8 add #3,r8
L_060398AA:
    c.r[15] = c.r[14];  // 060398AA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060398AC lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060398AE mov.l @r15+,r14
    c.r[0] = c.r[8];  // 060398B0 mov r8,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060398B2 rts ; mov.l @r15+,r8
}

void f_060398CC(SH2Context& c) {
    ran[850] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060398CC mov.l r14,@-r15
    c.r[14] = c.r[15];  // 060398CE mov r15,r14
    c.r[1] = ld32(0x06039918u);  // 060398D0 mov.l 0x06039918,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060398D2 mov.b @r1,r1
    c.r[0] = c.r[1];  // 060398D4 mov r1,r0
    c.r[0] >>= 2;  // 060398D6 shlr2 r0
    c.r[0] >>= 2;  // 060398D8 shlr2 r0
    c.r[0] >>= 2;  // 060398DA shlr2 r0
    c.r[0] &= 0x1u;  // 060398DC and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060398DE tst r0,r0
    c.r[1] = ld32(0x0603991Cu);  // 060398E0 mov.l 0x0603991C,r1
    { const bool k = c.t; c.r[3] = c.r[5]; if (k) { goto L_060398E8; } }  // 060398E2 bt/s 0x060398E8 ; mov r5,r3
    c.r[1] = ld32(0x06039920u);  // 060398E6 mov.l 0x06039920,r1
L_060398E8:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060398E8 mov.b @r1,r1
    c.r[0] = c.r[1];  // 060398EA mov r1,r0
    c.r[0] >>= 2;  // 060398EC shlr2 r0
    c.r[0] >>= 2;  // 060398EE shlr2 r0
    c.r[0] >>= 2;  // 060398F0 shlr2 r0
    c.r[0] &= 0x1u;  // 060398F2 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060398F4 tst r0,r0
    { const bool k = c.t; c.r[0] = c.r[3]; if (k) { goto L_0603990C; } }  // 060398F6 bt/s 0x0603990C ; mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0]); c.r[0] += 1;  // 060398FA mov.b @r0+,r2
    c.r[2] = c.r[2] & 0xFFu;  // 060398FC extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 060398FE mov.b @r0,r1
    c.r[2] <<= 8;  // 06039900 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06039902 extu.b r1,r1
    c.r[2] |= c.r[1];  // 06039904 or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 06039906 exts.w r2,r2
    c.r[3] += c.r[2]; goto L_0603990E;  // 06039908 bra 0x0603990E ; add r2,r3
L_0603990C:
    c.r[3] += 2;  // 0603990C add #2,r3
L_0603990E:
    c.r[15] = c.r[14];  // 0603990E mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06039910 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[3]; c.pc = x; return; }  // 06039912 rts ; mov r3,r0
}

void f_06039924(SH2Context& c) {
    ran[851] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06039924 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06039926 mov r15,r14
    c.r[1] = ld32(0x0603996Cu);  // 06039928 mov.l 0x0603996C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603992A mov.b @r1,r1
    c.r[0] = c.r[1];  // 0603992C mov r1,r0
    c.r[0] >>= 2;  // 0603992E shlr2 r0
    c.r[0] >>= 2;  // 06039930 shlr2 r0
    c.r[0] >>= 2;  // 06039932 shlr2 r0
    c.r[0] &= 0x1u;  // 06039934 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06039936 tst r0,r0
    c.r[1] = ld32(0x06039970u);  // 06039938 mov.l 0x06039970,r1
    { const bool k = c.t; c.r[3] = c.r[5]; if (k) { goto L_06039940; } }  // 0603993A bt/s 0x06039940 ; mov r5,r3
    c.r[1] = ld32(0x06039974u);  // 0603993E mov.l 0x06039974,r1
L_06039940:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06039940 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06039942 mov r1,r0
    c.r[0] >>= 2;  // 06039944 shlr2 r0
    c.r[0] >>= 2;  // 06039946 shlr2 r0
    c.r[0] &= 0x1u;  // 06039948 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603994A tst r0,r0
    { const bool k = c.t; c.r[0] = c.r[3]; if (k) { goto L_06039962; } }  // 0603994C bt/s 0x06039962 ; mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0]); c.r[0] += 1;  // 06039950 mov.b @r0+,r2
    c.r[2] = c.r[2] & 0xFFu;  // 06039952 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06039954 mov.b @r0,r1
    c.r[2] <<= 8;  // 06039956 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06039958 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0603995A or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0603995C exts.w r2,r2
    c.r[3] += c.r[2]; goto L_06039964;  // 0603995E bra 0x06039964 ; add r2,r3
L_06039962:
    c.r[3] += 2;  // 06039962 add #2,r3
L_06039964:
    c.r[15] = c.r[14];  // 06039964 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06039966 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[3]; c.pc = x; return; }  // 06039968 rts ; mov r3,r0
}

void f_06039978(SH2Context& c) {
    ran[852] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06039978 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0603997A mov r15,r14
    c.r[1] = ld32(0x060399C4u);  // 0603997C mov.l 0x060399C4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603997E mov.b @r1,r1
    c.r[0] = c.r[1];  // 06039980 mov r1,r0
    c.r[0] >>= 2;  // 06039982 shlr2 r0
    c.r[0] >>= 2;  // 06039984 shlr2 r0
    c.r[0] >>= 2;  // 06039986 shlr2 r0
    c.r[0] &= 0x1u;  // 06039988 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603998A tst r0,r0
    c.r[1] = ld32(0x060399C8u);  // 0603998C mov.l 0x060399C8,r1
    { const bool k = c.t; c.r[3] = c.r[5]; if (k) { goto L_06039994; } }  // 0603998E bt/s 0x06039994 ; mov r5,r3
    c.r[1] = ld32(0x060399CCu);  // 06039992 mov.l 0x060399CC,r1
L_06039994:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06039994 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06039996 mov r1,r0
    c.r[0] >>= 2;  // 06039998 shlr2 r0
    c.r[0] >>= 2;  // 0603999A shlr2 r0
    c.r[0] >>= 2;  // 0603999C shlr2 r0
    c.r[0] &= 0x1u;  // 0603999E and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060399A0 tst r0,r0
    { const bool k = !c.t; c.r[0] = c.r[3]; if (k) { goto L_060399B8; } }  // 060399A2 bf/s 0x060399B8 ; mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0]); c.r[0] += 1;  // 060399A6 mov.b @r0+,r2
    c.r[2] = c.r[2] & 0xFFu;  // 060399A8 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 060399AA mov.b @r0,r1
    c.r[2] <<= 8;  // 060399AC shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 060399AE extu.b r1,r1
    c.r[2] |= c.r[1];  // 060399B0 or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 060399B2 exts.w r2,r2
    c.r[3] += c.r[2]; goto L_060399BA;  // 060399B4 bra 0x060399BA ; add r2,r3
L_060399B8:
    c.r[3] += 2;  // 060399B8 add #2,r3
L_060399BA:
    c.r[15] = c.r[14];  // 060399BA mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060399BC mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[3]; c.pc = x; return; }  // 060399BE rts ; mov r3,r0
}

void f_060399D0(SH2Context& c) {
    ran[853] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060399D0 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 060399D2 mov r15,r14
    c.r[1] = ld32(0x06039A1Cu);  // 060399D4 mov.l 0x06039A1C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060399D6 mov.b @r1,r1
    c.r[0] = c.r[1];  // 060399D8 mov r1,r0
    c.r[0] >>= 2;  // 060399DA shlr2 r0
    c.r[0] >>= 2;  // 060399DC shlr2 r0
    c.r[0] >>= 2;  // 060399DE shlr2 r0
    c.r[0] &= 0x1u;  // 060399E0 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060399E2 tst r0,r0
    c.r[1] = ld32(0x06039A20u);  // 060399E4 mov.l 0x06039A20,r1
    { const bool k = c.t; c.r[3] = c.r[5]; if (k) { goto L_060399EC; } }  // 060399E6 bt/s 0x060399EC ; mov r5,r3
    c.r[1] = ld32(0x06039A24u);  // 060399EA mov.l 0x06039A24,r1
L_060399EC:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060399EC mov.b @r1,r1
    c.r[0] = c.r[1];  // 060399EE mov r1,r0
    c.r[0] >>= 2;  // 060399F0 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060399F2 shlr r0
    c.r[0] >>= 2;  // 060399F4 shlr2 r0
    c.r[0] &= 0x1u;  // 060399F6 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060399F8 tst r0,r0
    { const bool k = c.t; c.r[0] = c.r[3]; if (k) { goto L_06039A10; } }  // 060399FA bt/s 0x06039A10 ; mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0]); c.r[0] += 1;  // 060399FE mov.b @r0+,r2
    c.r[2] = c.r[2] & 0xFFu;  // 06039A00 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06039A02 mov.b @r0,r1
    c.r[2] <<= 8;  // 06039A04 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06039A06 extu.b r1,r1
    c.r[2] |= c.r[1];  // 06039A08 or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 06039A0A exts.w r2,r2
    c.r[3] += c.r[2]; goto L_06039A12;  // 06039A0C bra 0x06039A12 ; add r2,r3
L_06039A10:
    c.r[3] += 2;  // 06039A10 add #2,r3
L_06039A12:
    c.r[15] = c.r[14];  // 06039A12 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06039A14 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[3]; c.pc = x; return; }  // 06039A16 rts ; mov r3,r0
}

void f_06039A28(SH2Context& c) {
    ran[854] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06039A28 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06039A2A mov r15,r14
    c.r[1] = ld32(0x06039A70u);  // 06039A2C mov.l 0x06039A70,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06039A2E mov.b @r1,r1
    c.r[0] = c.r[1];  // 06039A30 mov r1,r0
    c.r[0] >>= 2;  // 06039A32 shlr2 r0
    c.r[0] >>= 2;  // 06039A34 shlr2 r0
    c.r[0] >>= 2;  // 06039A36 shlr2 r0
    c.r[0] &= 0x1u;  // 06039A38 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06039A3A tst r0,r0
    c.r[1] = ld32(0x06039A74u);  // 06039A3C mov.l 0x06039A74,r1
    { const bool k = c.t; c.r[3] = c.r[5]; if (k) { goto L_06039A44; } }  // 06039A3E bt/s 0x06039A44 ; mov r5,r3
    c.r[1] = ld32(0x06039A78u);  // 06039A42 mov.l 0x06039A78,r1
L_06039A44:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06039A44 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06039A46 mov r1,r0
    c.r[0] >>= 2;  // 06039A48 shlr2 r0
    c.r[0] &= 0x3u;  // 06039A4A and #3,r0
    c.t = c.r[0] == 0x1u;  // 06039A4C cmp/eq #1,r0
    { const bool k = !c.t; c.r[0] = c.r[3]; if (k) { goto L_06039A64; } }  // 06039A4E bf/s 0x06039A64 ; mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0]); c.r[0] += 1;  // 06039A52 mov.b @r0+,r2
    c.r[2] = c.r[2] & 0xFFu;  // 06039A54 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06039A56 mov.b @r0,r1
    c.r[2] <<= 8;  // 06039A58 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06039A5A extu.b r1,r1
    c.r[2] |= c.r[1];  // 06039A5C or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 06039A5E exts.w r2,r2
    c.r[3] += c.r[2]; goto L_06039A66;  // 06039A60 bra 0x06039A66 ; add r2,r3
L_06039A64:
    c.r[3] += 2;  // 06039A64 add #2,r3
L_06039A66:
    c.r[15] = c.r[14];  // 06039A66 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06039A68 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[3]; c.pc = x; return; }  // 06039A6A rts ; mov r3,r0
}

void f_06039A7C(SH2Context& c) {
    ran[855] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06039A7C mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06039A7E mov r15,r14
    c.r[1] = ld32(0x06039B34u);  // 06039A80 mov.l 0x06039B34,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06039A82 mov.b @r1,r1
    c.r[7] = ld32(0x06039B38u);  // 06039A84 mov.l 0x06039B38,r7
    c.r[0] = c.r[1];  // 06039A86 mov r1,r0
    c.r[0] >>= 2;  // 06039A88 shlr2 r0
    c.r[0] >>= 2;  // 06039A8A shlr2 r0
    c.r[0] >>= 2;  // 06039A8C shlr2 r0
    c.r[0] &= 0x1u;  // 06039A8E and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06039A90 tst r0,r0
    { const bool k = c.t; c.r[3] = c.r[5]; if (k) { goto L_06039A98; } }  // 06039A92 bt/s 0x06039A98 ; mov r5,r3
    c.r[7] = ld32(0x06039B3Cu);  // 06039A96 mov.l 0x06039B3C,r7
L_06039A98:
    c.r[1] = c.r[7];  // 06039A98 mov r7,r1
    c.r[1] += 6;  // 06039A9A add #6,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06039A9C mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06039A9E extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06039AA0 tst r1,r1
    { const bool k = !c.t; c.t = (c.r[0] & c.r[0]) == 0; if (k) { goto L_06039AAC; } }  // 06039AA2 bf/s 0x06039AAC ; tst r0,r0
    c.r[7] = ld32(0x06039B40u);  // 06039AA6 mov.l 0x06039B40,r7
    if (c.t) { goto L_06039AAC; }  // 06039AA8 bt 0x06039AAC
    c.r[7] = ld32(0x06039B44u);  // 06039AAA mov.l 0x06039B44,r7
L_06039AAC:
    c.r[1] = ld32(0x06039B34u);  // 06039AAC mov.l 0x06039B34,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06039AAE mov.b @r1,r1
    c.r[2] = ld32(0x06039B3Cu);  // 06039AB0 mov.l 0x06039B3C,r2
    c.r[0] = c.r[1];  // 06039AB2 mov r1,r0
    c.r[0] >>= 2;  // 06039AB4 shlr2 r0
    c.r[0] >>= 2;  // 06039AB6 shlr2 r0
    c.r[0] >>= 2;  // 06039AB8 shlr2 r0
    c.r[0] &= 0x1u;  // 06039ABA and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06039ABC tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_06039AC6; } }  // 06039ABE bt/s 0x06039AC6 ; mov r2,r1
    c.r[2] = ld32(0x06039B38u);  // 06039AC2 mov.l 0x06039B38,r2
    c.r[1] = c.r[2];  // 06039AC4 mov r2,r1
L_06039AC6:
    c.r[1] += 6;  // 06039AC6 add #6,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06039AC8 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06039ACA extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06039ACC tst r1,r1
    { const bool k = !c.t; c.t = (c.r[0] & c.r[0]) == 0; if (k) { goto L_06039AD8; } }  // 06039ACE bf/s 0x06039AD8 ; tst r0,r0
    c.r[2] = ld32(0x06039B44u);  // 06039AD2 mov.l 0x06039B44,r2
    if (c.t) { goto L_06039AD8; }  // 06039AD4 bt 0x06039AD8
    c.r[2] = ld32(0x06039B40u);  // 06039AD6 mov.l 0x06039B40,r2
L_06039AD8:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06039AD8 mov.b @r7,r1
    c.r[0] = c.r[1];  // 06039ADA mov r1,r0
    c.r[0] &= 0x3u;  // 06039ADC and #3,r0
    c.t = c.r[0] == 0x1u;  // 06039ADE cmp/eq #1,r0
    { const bool k = c.t; c.r[0] = c.r[1]; if (k) { goto L_06039B28; } }  // 06039AE0 bt/s 0x06039B28 ; mov r1,r0
    c.r[0] &= 0x1Fu;  // 06039AE4 and #31,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06039AE6 tst r0,r0
    { const bool k = c.t; c.r[2] += 10; if (k) { goto L_06039B28; } }  // 06039AE8 bt/s 0x06039B28 ; add #10,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06039AEC mov.w @r2,r1
    c.r[0] = c.r[1] & 0xFFFFu;  // 06039AEE extu.w r1,r0
    c.t = c.r[0] == 0x9u;  // 06039AF0 cmp/eq #9,r0
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_06039AFE; } }  // 06039AF2 bt/s 0x06039AFE ; mov r3,r1
    c.r[1] = (uint32_t)(int16_t)ld16(0x06039B32u);  // 06039AF6 mov.w 0x06039B32,r1
    c.t = c.r[0] == c.r[1];  // 06039AF8 cmp/eq r1,r0
    { const bool k = !c.t; c.r[1] = c.r[3]; if (k) { goto L_06039B14; } }  // 06039AFA bf/s 0x06039B14 ; mov r3,r1
L_06039AFE:
    c.r[1] += 2;  // 06039AFE add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06039B00 mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 06039B02 extu.b r2,r2
    c.r[1] = c.r[3];  // 06039B04 mov r3,r1
    c.r[1] += 3;  // 06039B06 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06039B08 mov.b @r1,r1
    c.r[2] <<= 8;  // 06039B0A shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06039B0C extu.b r1,r1
    c.r[2] |= c.r[1];  // 06039B0E or r1,r2
    c.r[2] += 2; goto L_06039B22;  // 06039B10 bra 0x06039B22 ; add #2,r2
L_06039B14:
    c.r[0] = c.r[3];  // 06039B14 mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0]); c.r[0] += 1;  // 06039B16 mov.b @r0+,r2
    c.r[2] = c.r[2] & 0xFFu;  // 06039B18 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06039B1A mov.b @r0,r1
    c.r[2] <<= 8;  // 06039B1C shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06039B1E extu.b r1,r1
    c.r[2] |= c.r[1];  // 06039B20 or r1,r2
L_06039B22:
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 06039B22 exts.w r2,r2
    c.r[3] += c.r[2]; goto L_06039B2A;  // 06039B24 bra 0x06039B2A ; add r2,r3
L_06039B28:
    c.r[3] += 4;  // 06039B28 add #4,r3
L_06039B2A:
    c.r[15] = c.r[14];  // 06039B2A mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06039B2C mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[3]; c.pc = x; return; }  // 06039B2E rts ; mov r3,r0
}

void f_06039B48(SH2Context& c) {
    ran[856] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06039B48 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06039B4A mov r15,r14
    c.r[1] = ld32(0x06039B90u);  // 06039B4C mov.l 0x06039B90,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06039B4E mov.b @r1,r1
    c.r[0] = c.r[1];  // 06039B50 mov r1,r0
    c.r[0] >>= 2;  // 06039B52 shlr2 r0
    c.r[0] >>= 2;  // 06039B54 shlr2 r0
    c.r[0] >>= 2;  // 06039B56 shlr2 r0
    c.r[0] &= 0x1u;  // 06039B58 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06039B5A tst r0,r0
    { const bool k = c.t; c.r[3] = c.r[5]; if (k) { goto L_06039B86; } }  // 06039B5C bt/s 0x06039B86 ; mov r5,r3
    c.r[1] = ld32(0x06039B94u);  // 06039B60 mov.l 0x06039B94,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06039B62 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06039B64 extu.b r1,r1
    c.r[1] >>= 2;  // 06039B66 shlr2 r1
    c.r[1] >>= 2;  // 06039B68 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06039B6A shlr r1
    c.r[1] >>= 2;  // 06039B6C shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06039B6E tst r1,r1
    { const bool k = c.t; c.r[0] = c.r[3]; if (k) { goto L_06039B86; } }  // 06039B70 bt/s 0x06039B86 ; mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0]); c.r[0] += 1;  // 06039B74 mov.b @r0+,r2
    c.r[2] = c.r[2] & 0xFFu;  // 06039B76 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06039B78 mov.b @r0,r1
    c.r[2] <<= 8;  // 06039B7A shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06039B7C extu.b r1,r1
    c.r[2] |= c.r[1];  // 06039B7E or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 06039B80 exts.w r2,r2
    c.r[3] += c.r[2]; goto L_06039B88;  // 06039B82 bra 0x06039B88 ; add r2,r3
L_06039B86:
    c.r[3] += 2;  // 06039B86 add #2,r3
L_06039B88:
    c.r[15] = c.r[14];  // 06039B88 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06039B8A mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[3]; c.pc = x; return; }  // 06039B8C rts ; mov r3,r0
}

void f_06039B98(SH2Context& c) {
    ran[857] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06039B98 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06039B9A mov r15,r14
    c.r[1] = ld32(0x06039C1Cu);  // 06039B9C mov.l 0x06039C1C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06039B9E mov.b @r1,r1
    c.r[2] = ld32(0x06039C20u);  // 06039BA0 mov.l 0x06039C20,r2
    c.r[0] = c.r[1];  // 06039BA2 mov r1,r0
    c.r[0] >>= 2;  // 06039BA4 shlr2 r0
    c.r[0] >>= 2;  // 06039BA6 shlr2 r0
    c.r[0] >>= 2;  // 06039BA8 shlr2 r0
    c.r[0] &= 0x1u;  // 06039BAA and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06039BAC tst r0,r0
    { const bool k = c.t; c.r[3] = c.r[5]; if (k) { goto L_06039BB4; } }  // 06039BAE bt/s 0x06039BB4 ; mov r5,r3
    c.r[2] = ld32(0x06039C24u);  // 06039BB2 mov.l 0x06039C24,r2
L_06039BB4:
    c.r[1] = c.r[2];  // 06039BB4 mov r2,r1
    c.r[1] += 6;  // 06039BB6 add #6,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06039BB8 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06039BBA extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06039BBC tst r1,r1
    { const bool k = !c.t; c.t = (c.r[0] & c.r[0]) == 0; if (k) { goto L_06039BC8; } }  // 06039BBE bf/s 0x06039BC8 ; tst r0,r0
    c.r[2] = ld32(0x06039C28u);  // 06039BC2 mov.l 0x06039C28,r2
    if (c.t) { goto L_06039BC8; }  // 06039BC4 bt 0x06039BC8
    c.r[2] = ld32(0x06039C2Cu);  // 06039BC6 mov.l 0x06039C2C,r2
L_06039BC8:
    c.r[1] = ld32(0x06039C1Cu);  // 06039BC8 mov.l 0x06039C1C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06039BCA mov.b @r1,r1
    c.r[0] = c.r[1];  // 06039BCC mov r1,r0
    c.r[0] >>= 2;  // 06039BCE shlr2 r0
    c.r[0] >>= 2;  // 06039BD0 shlr2 r0
    c.r[0] >>= 2;  // 06039BD2 shlr2 r0
    c.r[0] &= 0x1u;  // 06039BD4 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06039BD6 tst r0,r0
    c.r[1] = ld32(0x06039C30u);  // 06039BD8 mov.l 0x06039C30,r1
    if (c.t) { goto L_06039BDE; }  // 06039BDA bt 0x06039BDE
    c.r[1] = ld32(0x06039C34u);  // 06039BDC mov.l 0x06039C34,r1
L_06039BDE:
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06039BDE mov.b @r2,r2
    c.r[0] = c.r[2];  // 06039BE0 mov r2,r0
    c.r[0] &= 0x3u;  // 06039BE2 and #3,r0
    c.t = c.r[0] == 0x1u;  // 06039BE4 cmp/eq #1,r0
    if (c.t) { goto L_06039C10; }  // 06039BE6 bt 0x06039C10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06039BE8 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06039BEA mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06039BEC shlr r0
    c.r[0] &= 0x1u;  // 06039BEE and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06039BF0 tst r0,r0
    { const bool k = c.t; c.r[0] = c.r[2]; if (k) { goto L_06039C10; } }  // 06039BF2 bt/s 0x06039C10 ; mov r2,r0
    c.r[0] &= 0x1Fu;  // 06039BF6 and #31,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06039BF8 tst r0,r0
    { const bool k = c.t; c.r[0] = c.r[3]; if (k) { goto L_06039C10; } }  // 06039BFA bt/s 0x06039C10 ; mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0]); c.r[0] += 1;  // 06039BFE mov.b @r0+,r2
    c.r[2] = c.r[2] & 0xFFu;  // 06039C00 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06039C02 mov.b @r0,r1
    c.r[2] <<= 8;  // 06039C04 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06039C06 extu.b r1,r1
    c.r[2] |= c.r[1];  // 06039C08 or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 06039C0A exts.w r2,r2
    c.r[3] += c.r[2]; goto L_06039C12;  // 06039C0C bra 0x06039C12 ; add r2,r3
L_06039C10:
    c.r[3] += 2;  // 06039C10 add #2,r3
L_06039C12:
    c.r[15] = c.r[14];  // 06039C12 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06039C14 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[3]; c.pc = x; return; }  // 06039C16 rts ; mov r3,r0
}

void f_06039C38(SH2Context& c) {
    ran[858] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06039C38 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06039C3A mov r15,r14
    c.r[1] = ld32(0x06039C84u);  // 06039C3C mov.l 0x06039C84,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06039C3E mov.b @r1,r1
    c.r[0] = c.r[1];  // 06039C40 mov r1,r0
    c.r[0] >>= 2;  // 06039C42 shlr2 r0
    c.r[0] >>= 2;  // 06039C44 shlr2 r0
    c.r[0] >>= 2;  // 06039C46 shlr2 r0
    c.r[0] &= 0x1u;  // 06039C48 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06039C4A tst r0,r0
    c.r[1] = ld32(0x06039C88u);  // 06039C4C mov.l 0x06039C88,r1
    { const bool k = c.t; c.r[3] = c.r[5]; if (k) { goto L_06039C54; } }  // 06039C4E bt/s 0x06039C54 ; mov r5,r3
    c.r[1] = ld32(0x06039C8Cu);  // 06039C52 mov.l 0x06039C8C,r1
L_06039C54:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06039C54 mov.w @r1,r1
    c.r[0] = c.r[1];  // 06039C56 mov r1,r0
    c.r[0] >>= 2;  // 06039C58 shlr2 r0
    c.r[0] >>= 2;  // 06039C5A shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06039C5C shlr r0
    c.r[0] >>= 2;  // 06039C5E shlr2 r0
    c.r[0] &= 0x3u;  // 06039C60 and #3,r0
    c.t = c.r[0] == 0x1u;  // 06039C62 cmp/eq #1,r0
    { const bool k = !c.t; c.r[0] = c.r[3]; if (k) { goto L_06039C7A; } }  // 06039C64 bf/s 0x06039C7A ; mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0]); c.r[0] += 1;  // 06039C68 mov.b @r0+,r2
    c.r[2] = c.r[2] & 0xFFu;  // 06039C6A extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06039C6C mov.b @r0,r1
    c.r[2] <<= 8;  // 06039C6E shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06039C70 extu.b r1,r1
    c.r[2] |= c.r[1];  // 06039C72 or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 06039C74 exts.w r2,r2
    c.r[3] += c.r[2]; goto L_06039C7C;  // 06039C76 bra 0x06039C7C ; add r2,r3
L_06039C7A:
    c.r[3] += 2;  // 06039C7A add #2,r3
L_06039C7C:
    c.r[15] = c.r[14];  // 06039C7C mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06039C7E mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[3]; c.pc = x; return; }  // 06039C80 rts ; mov r3,r0
}

void f_06039C90(SH2Context& c) {
    ran[859] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06039C90 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06039C92 mov r15,r14
    c.r[1] = ld32(0x06039CDCu);  // 06039C94 mov.l 0x06039CDC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06039C96 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06039C98 mov r1,r0
    c.r[0] >>= 2;  // 06039C9A shlr2 r0
    c.r[0] >>= 2;  // 06039C9C shlr2 r0
    c.r[0] >>= 2;  // 06039C9E shlr2 r0
    c.r[0] &= 0x1u;  // 06039CA0 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06039CA2 tst r0,r0
    c.r[1] = ld32(0x06039CE0u);  // 06039CA4 mov.l 0x06039CE0,r1
    { const bool k = c.t; c.r[3] = c.r[5]; if (k) { goto L_06039CAC; } }  // 06039CA6 bt/s 0x06039CAC ; mov r5,r3
    c.r[1] = ld32(0x06039CE4u);  // 06039CAA mov.l 0x06039CE4,r1
L_06039CAC:
    c.r[1] += 1;  // 06039CAC add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06039CAE mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06039CB0 extu.b r1,r1
    c.r[1] >>= 2;  // 06039CB2 shlr2 r1
    c.r[1] >>= 2;  // 06039CB4 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06039CB6 shlr r1
    c.r[1] >>= 2;  // 06039CB8 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06039CBA tst r1,r1
    { const bool k = c.t; c.r[0] = c.r[3]; if (k) { goto L_06039CD2; } }  // 06039CBC bt/s 0x06039CD2 ; mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0]); c.r[0] += 1;  // 06039CC0 mov.b @r0+,r2
    c.r[2] = c.r[2] & 0xFFu;  // 06039CC2 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06039CC4 mov.b @r0,r1
    c.r[2] <<= 8;  // 06039CC6 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06039CC8 extu.b r1,r1
    c.r[2] |= c.r[1];  // 06039CCA or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 06039CCC exts.w r2,r2
    c.r[3] += c.r[2]; goto L_06039CD4;  // 06039CCE bra 0x06039CD4 ; add r2,r3
L_06039CD2:
    c.r[3] += 2;  // 06039CD2 add #2,r3
L_06039CD4:
    c.r[15] = c.r[14];  // 06039CD4 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06039CD6 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[3]; c.pc = x; return; }  // 06039CD8 rts ; mov r3,r0
}

void f_06039CE8(SH2Context& c) {
    ran[860] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06039CE8 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06039CEA mov r15,r14
    c.r[1] = ld32(0x06039D40u);  // 06039CEC mov.l 0x06039D40,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06039CEE mov.b @r1,r1
    c.r[2] = ld32(0x06039D44u);  // 06039CF0 mov.l 0x06039D44,r2
    c.r[0] = c.r[1];  // 06039CF2 mov r1,r0
    c.r[0] >>= 2;  // 06039CF4 shlr2 r0
    c.r[0] >>= 2;  // 06039CF6 shlr2 r0
    c.r[0] >>= 2;  // 06039CF8 shlr2 r0
    c.r[0] &= 0x1u;  // 06039CFA and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06039CFC tst r0,r0
    { const bool k = c.t; c.r[3] = c.r[5]; if (k) { goto L_06039D04; } }  // 06039CFE bt/s 0x06039D04 ; mov r5,r3
    c.r[2] = ld32(0x06039D48u);  // 06039D02 mov.l 0x06039D48,r2
L_06039D04:
    c.r[1] = c.r[2];  // 06039D04 mov r2,r1
    c.r[1] += 6;  // 06039D06 add #6,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06039D08 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06039D0A extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06039D0C tst r1,r1
    { const bool k = !c.t; c.t = (c.r[0] & c.r[0]) == 0; if (k) { goto L_06039D18; } }  // 06039D0E bf/s 0x06039D18 ; tst r0,r0
    c.r[2] = ld32(0x06039D4Cu);  // 06039D12 mov.l 0x06039D4C,r2
    if (c.t) { goto L_06039D18; }  // 06039D14 bt 0x06039D18
    c.r[2] = ld32(0x06039D50u);  // 06039D16 mov.l 0x06039D50,r2
L_06039D18:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06039D18 mov.b @r2,r0
    c.r[0] &= 0x3u;  // 06039D1A and #3,r0
    c.t = c.r[0] == 0x1u;  // 06039D1C cmp/eq #1,r0
    { const bool k = !c.t; c.r[0] = c.r[3]; if (k) { goto L_06039D34; } }  // 06039D1E bf/s 0x06039D34 ; mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0]); c.r[0] += 1;  // 06039D22 mov.b @r0+,r2
    c.r[2] = c.r[2] & 0xFFu;  // 06039D24 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06039D26 mov.b @r0,r1
    c.r[2] <<= 8;  // 06039D28 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06039D2A extu.b r1,r1
    c.r[2] |= c.r[1];  // 06039D2C or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 06039D2E exts.w r2,r2
    c.r[3] += c.r[2]; goto L_06039D36;  // 06039D30 bra 0x06039D36 ; add r2,r3
L_06039D34:
    c.r[3] += 2;  // 06039D34 add #2,r3
L_06039D36:
    c.r[15] = c.r[14];  // 06039D36 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06039D38 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[3]; c.pc = x; return; }  // 06039D3A rts ; mov r3,r0
}

void f_06039D54(SH2Context& c) {
    ran[861] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06039D54 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06039D56 mov r15,r14
    c.r[1] = ld32(0x06039DCCu);  // 06039D58 mov.l 0x06039DCC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06039D5A mov.b @r1,r1
    c.r[2] = ld32(0x06039DD0u);  // 06039D5C mov.l 0x06039DD0,r2
    c.r[0] = c.r[1];  // 06039D5E mov r1,r0
    c.r[0] >>= 2;  // 06039D60 shlr2 r0
    c.r[0] >>= 2;  // 06039D62 shlr2 r0
    c.r[0] >>= 2;  // 06039D64 shlr2 r0
    c.r[0] &= 0x1u;  // 06039D66 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06039D68 tst r0,r0
    { const bool k = c.t; c.r[3] = c.r[5]; if (k) { goto L_06039D70; } }  // 06039D6A bt/s 0x06039D70 ; mov r5,r3
    c.r[2] = ld32(0x06039DD4u);  // 06039D6E mov.l 0x06039DD4,r2
L_06039D70:
    c.r[1] = c.r[2];  // 06039D70 mov r2,r1
    c.r[1] += 6;  // 06039D72 add #6,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06039D74 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06039D76 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06039D78 tst r1,r1
    { const bool k = !c.t; c.t = (c.r[0] & c.r[0]) == 0; if (k) { goto L_06039D84; } }  // 06039D7A bf/s 0x06039D84 ; tst r0,r0
    c.r[2] = ld32(0x06039DD8u);  // 06039D7E mov.l 0x06039DD8,r2
    if (c.t) { goto L_06039D84; }  // 06039D80 bt 0x06039D84
    c.r[2] = ld32(0x06039DDCu);  // 06039D82 mov.l 0x06039DDC,r2
L_06039D84:
    c.r[1] = ld32(0x06039DCCu);  // 06039D84 mov.l 0x06039DCC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06039D86 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06039D88 mov r1,r0
    c.r[0] >>= 2;  // 06039D8A shlr2 r0
    c.r[0] >>= 2;  // 06039D8C shlr2 r0
    c.r[0] >>= 2;  // 06039D8E shlr2 r0
    c.r[0] &= 0x1u;  // 06039D90 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06039D92 tst r0,r0
    c.r[1] = ld32(0x06039DE0u);  // 06039D94 mov.l 0x06039DE0,r1
    if (c.t) { goto L_06039D9A; }  // 06039D96 bt 0x06039D9A
    c.r[1] = ld32(0x06039DE4u);  // 06039D98 mov.l 0x06039DE4,r1
L_06039D9A:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06039D9A mov.b @r1,r1
    c.r[0] = c.r[1];  // 06039D9C mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06039D9E shlr r0
    c.r[0] &= 0x1u;  // 06039DA0 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06039DA2 tst r0,r0
    if (c.t) { goto L_06039DC2; }  // 06039DA4 bt 0x06039DC2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06039DA6 mov.b @r2,r0
    c.r[0] &= 0x3u;  // 06039DA8 and #3,r0
    c.t = c.r[0] == 0x1u;  // 06039DAA cmp/eq #1,r0
    { const bool k = !c.t; c.r[0] = c.r[3]; if (k) { goto L_06039DC2; } }  // 06039DAC bf/s 0x06039DC2 ; mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0]); c.r[0] += 1;  // 06039DB0 mov.b @r0+,r2
    c.r[2] = c.r[2] & 0xFFu;  // 06039DB2 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06039DB4 mov.b @r0,r1
    c.r[2] <<= 8;  // 06039DB6 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06039DB8 extu.b r1,r1
    c.r[2] |= c.r[1];  // 06039DBA or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 06039DBC exts.w r2,r2
    c.r[3] += c.r[2]; goto L_06039DC4;  // 06039DBE bra 0x06039DC4 ; add r2,r3
L_06039DC2:
    c.r[3] += 2;  // 06039DC2 add #2,r3
L_06039DC4:
    c.r[15] = c.r[14];  // 06039DC4 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06039DC6 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[3]; c.pc = x; return; }  // 06039DC8 rts ; mov r3,r0
}

void f_06039DE8(SH2Context& c) {
    ran[862] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06039DE8 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06039DEA mov r15,r14
    c.r[1] = ld32(0x06039E40u);  // 06039DEC mov.l 0x06039E40,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06039DEE mov.b @r1,r1
    c.r[0] = c.r[1];  // 06039DF0 mov r1,r0
    c.r[0] >>= 2;  // 06039DF2 shlr2 r0
    c.r[0] >>= 2;  // 06039DF4 shlr2 r0
    c.r[0] >>= 2;  // 06039DF6 shlr2 r0
    c.r[0] &= 0x1u;  // 06039DF8 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06039DFA tst r0,r0
    c.r[1] = ld32(0x06039E44u);  // 06039DFC mov.l 0x06039E44,r1
    { const bool k = c.t; c.r[3] = c.r[5]; if (k) { goto L_06039E04; } }  // 06039DFE bt/s 0x06039E04 ; mov r5,r3
    c.r[1] = ld32(0x06039E48u);  // 06039E02 mov.l 0x06039E48,r1
L_06039E04:
    c.r[1] += 1;  // 06039E04 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06039E06 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06039E08 extu.b r1,r1
    c.r[0] = c.r[1];  // 06039E0A mov r1,r0
    c.r[0] >>= 2;  // 06039E0C shlr2 r0
    c.r[0] >>= 2;  // 06039E0E shlr2 r0
    c.r[0] &= 0x1u;  // 06039E10 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06039E12 tst r0,r0
    { const bool k = c.t; c.r[0] = c.r[1]; if (k) { goto L_06039E34; } }  // 06039E14 bt/s 0x06039E34 ; mov r1,r0
    c.r[0] >>= 2;  // 06039E18 shlr2 r0
    c.r[0] &= 0x1u;  // 06039E1A and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06039E1C tst r0,r0
    { const bool k = !c.t; c.r[0] = c.r[3]; if (k) { goto L_06039E34; } }  // 06039E1E bf/s 0x06039E34 ; mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0]); c.r[0] += 1;  // 06039E22 mov.b @r0+,r2
    c.r[2] = c.r[2] & 0xFFu;  // 06039E24 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06039E26 mov.b @r0,r1
    c.r[2] <<= 8;  // 06039E28 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06039E2A extu.b r1,r1
    c.r[2] |= c.r[1];  // 06039E2C or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 06039E2E exts.w r2,r2
    c.r[3] += c.r[2]; goto L_06039E36;  // 06039E30 bra 0x06039E36 ; add r2,r3
L_06039E34:
    c.r[3] += 2;  // 06039E34 add #2,r3
L_06039E36:
    c.r[15] = c.r[14];  // 06039E36 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06039E38 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[3]; c.pc = x; return; }  // 06039E3A rts ; mov r3,r0
}

void f_06039E4C(SH2Context& c) {
    ran[863] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06039E4C mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06039E4E mov r15,r14
    c.r[1] = ld32(0x06039EA4u);  // 06039E50 mov.l 0x06039EA4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06039E52 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06039E54 mov r1,r0
    c.r[0] >>= 2;  // 06039E56 shlr2 r0
    c.r[0] >>= 2;  // 06039E58 shlr2 r0
    c.r[0] >>= 2;  // 06039E5A shlr2 r0
    c.r[0] &= 0x1u;  // 06039E5C and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06039E5E tst r0,r0
    c.r[1] = ld32(0x06039EA8u);  // 06039E60 mov.l 0x06039EA8,r1
    { const bool k = c.t; c.r[3] = c.r[5]; if (k) { goto L_06039E68; } }  // 06039E62 bt/s 0x06039E68 ; mov r5,r3
    c.r[1] = ld32(0x06039EACu);  // 06039E66 mov.l 0x06039EAC,r1
L_06039E68:
    c.r[1] += 1;  // 06039E68 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06039E6A mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06039E6C extu.b r1,r1
    c.r[0] = c.r[1];  // 06039E6E mov r1,r0
    c.r[0] >>= 2;  // 06039E70 shlr2 r0
    c.r[0] >>= 2;  // 06039E72 shlr2 r0
    c.r[0] &= 0x1u;  // 06039E74 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06039E76 tst r0,r0
    { const bool k = c.t; c.r[0] = c.r[1]; if (k) { goto L_06039E98; } }  // 06039E78 bt/s 0x06039E98 ; mov r1,r0
    c.r[0] >>= 2;  // 06039E7C shlr2 r0
    c.r[0] &= 0x1u;  // 06039E7E and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06039E80 tst r0,r0
    { const bool k = !c.t; c.r[0] = c.r[3]; if (k) { goto L_06039E98; } }  // 06039E82 bf/s 0x06039E98 ; mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0]); c.r[0] += 1;  // 06039E86 mov.b @r0+,r2
    c.r[2] = c.r[2] & 0xFFu;  // 06039E88 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06039E8A mov.b @r0,r1
    c.r[2] <<= 8;  // 06039E8C shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06039E8E extu.b r1,r1
    c.r[2] |= c.r[1];  // 06039E90 or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 06039E92 exts.w r2,r2
    c.r[3] += c.r[2]; goto L_06039E9A;  // 06039E94 bra 0x06039E9A ; add r2,r3
L_06039E98:
    c.r[3] += 2;  // 06039E98 add #2,r3
L_06039E9A:
    c.r[15] = c.r[14];  // 06039E9A mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06039E9C mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[3]; c.pc = x; return; }  // 06039E9E rts ; mov r3,r0
}

void f_06039EB0(SH2Context& c) {
    ran[864] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06039EB0 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06039EB2 mov r15,r14
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06039EB4 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[5]; c.pc = x; return; }  // 06039EB6 rts ; mov r5,r0
}

void f_06039EBC(SH2Context& c) {
    ran[865] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06039EBC mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06039EBE mov r15,r14
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06039EC0 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[5]; c.pc = x; return; }  // 06039EC2 rts ; mov r5,r0
}

void f_06039EC8(SH2Context& c) {
    ran[866] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06039EC8 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06039ECA mov r15,r14
    c.r[1] = ld32(0x06039F18u);  // 06039ECC mov.l 0x06039F18,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06039ECE mov.b @r1,r1
    c.r[0] = c.r[1];  // 06039ED0 mov r1,r0
    c.r[0] >>= 2;  // 06039ED2 shlr2 r0
    c.r[0] >>= 2;  // 06039ED4 shlr2 r0
    c.r[0] >>= 2;  // 06039ED6 shlr2 r0
    c.r[0] &= 0x1u;  // 06039ED8 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06039EDA tst r0,r0
    c.r[1] = ld32(0x06039F1Cu);  // 06039EDC mov.l 0x06039F1C,r1
    { const bool k = c.t; c.r[3] = c.r[5]; if (k) { goto L_06039EE4; } }  // 06039EDE bt/s 0x06039EE4 ; mov r5,r3
    c.r[1] = ld32(0x06039F20u);  // 06039EE2 mov.l 0x06039F20,r1
L_06039EE4:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06039EE4 mov.w @r1,r1
    c.r[0] = c.r[1];  // 06039EE6 mov r1,r0
    c.r[0] >>= 2;  // 06039EE8 shlr2 r0
    c.r[0] >>= 2;  // 06039EEA shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06039EEC shlr r0
    c.r[0] >>= 2;  // 06039EEE shlr2 r0
    c.r[0] &= 0x3u;  // 06039EF0 and #3,r0
    c.t = c.r[0] == 0x3u;  // 06039EF2 cmp/eq #3,r0
    if (!c.t) { goto L_06039EFC; }  // 06039EF4 bf 0x06039EFC
    c.r[3] += 2;  // 06039EF6 add #2,r3
    c.r[15] = c.r[14]; goto L_06039F10;  // 06039EF8 bra 0x06039F10 ; mov r14,r15
L_06039EFC:
    c.r[0] = c.r[3];  // 06039EFC mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0]); c.r[0] += 1;  // 06039EFE mov.b @r0+,r2
    c.r[2] = c.r[2] & 0xFFu;  // 06039F00 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06039F02 mov.b @r0,r1
    c.r[2] <<= 8;  // 06039F04 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06039F06 extu.b r1,r1
    c.r[2] |= c.r[1];  // 06039F08 or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 06039F0A exts.w r2,r2
    c.r[3] += c.r[2];  // 06039F0C add r2,r3
    c.r[15] = c.r[14];  // 06039F0E mov r14,r15
L_06039F10:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06039F10 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[3]; c.pc = x; return; }  // 06039F12 rts ; mov r3,r0
}

void f_06039F24(SH2Context& c) {
    ran[867] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06039F24 mov.l r14,@-r15
    c.r[3] = c.r[5];  // 06039F26 mov r5,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06039F28 mov.b @r3,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06039F2A extu.b r1,r0
    c.t = c.r[0] == 0x2u;  // 06039F2C cmp/eq #2,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06039F56; } }  // 06039F2E bt/s 0x06039F56 ; mov r15,r14
    c.r[1] = 0x2u;  // 06039F32 mov #2,r1
    c.t = (int32_t)c.r[0] > (int32_t)c.r[1];  // 06039F34 cmp/gt r1,r0
    { const bool k = c.t; c.t = c.r[0] == 0x4u; if (k) { goto L_06039F44; } }  // 06039F36 bt/s 0x06039F44 ; cmp/eq #4,r0
    c.t = c.r[0] == 0x1u;  // 06039F3A cmp/eq #1,r0
    { const bool k = c.t; c.r[2] = c.r[3]; if (k) { goto L_06039F4C; } }  // 06039F3C bt/s 0x06039F4C ; mov r3,r2
    c.r[3] += 2; goto L_06039F90;  // 06039F40 bra 0x06039F90 ; add #2,r3
L_06039F44:
    if (c.t) { goto L_06039F62; }  // 06039F44 bt 0x06039F62
    c.r[3] += 2;  // 06039F46 add #2,r3
    c.r[15] = c.r[14]; goto L_06039F92;  // 06039F48 bra 0x06039F92 ; mov r14,r15
L_06039F4C:
    c.r[2] += 1;  // 06039F4C add #1,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06039F4E mov.b @r2,r2
    c.r[1] = ld32(0x06039F98u);  // 06039F50 mov.l 0x06039F98,r1
    st8(c.r[1], c.r[2]); goto L_06039F8E;  // 06039F52 bra 0x06039F8E ; mov.b r2,@r1
L_06039F56:
    c.r[2] = c.r[3];  // 06039F56 mov r3,r2
    c.r[2] += 1;  // 06039F58 add #1,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06039F5A mov.b @r2,r2
    c.r[1] = ld32(0x06039F9Cu);  // 06039F5C mov.l 0x06039F9C,r1
    st8(c.r[1], c.r[2]); goto L_06039F8E;  // 06039F5E bra 0x06039F8E ; mov.b r2,@r1
L_06039F62:
    c.r[2] = ld32(0x06039FA0u);  // 06039F62 mov.l 0x06039FA0,r2
    c.r[1] = c.r[2];  // 06039F64 mov r2,r1
    c.r[1] += 1;  // 06039F66 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06039F68 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06039F6A mov r1,r0
    c.r[0] >>= 2;  // 06039F6C shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06039F6E shlr r0
    c.r[0] &= 0x1u;  // 06039F70 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06039F72 tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_06039F82; } }  // 06039F74 bt/s 0x06039F82 ; mov r3,r1
    c.r[1] += 1;  // 06039F78 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06039F7A mov.b @r1,r1
    c.r[2] += 12;  // 06039F7C add #12,r2
    st8(c.r[2], c.r[1]); goto L_06039F8E;  // 06039F7E bra 0x06039F8E ; mov.b r1,@r2
L_06039F82:
    c.r[1] += 1;  // 06039F82 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06039F84 mov.b @r1,r1
    c.r[2] += 12;  // 06039F86 add #12,r2
    c.r[0] = ~c.r[1];  // 06039F88 not r1,r0
    c.r[0] &= 0x1Fu;  // 06039F8A and #31,r0
    st8(c.r[2], c.r[0]);  // 06039F8C mov.b r0,@r2
L_06039F8E:
    c.r[3] += 2;  // 06039F8E add #2,r3
L_06039F90:
    c.r[15] = c.r[14];  // 06039F90 mov r14,r15
L_06039F92:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06039F92 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[3]; c.pc = x; return; }  // 06039F94 rts ; mov r3,r0
}

void f_06039FA4(SH2Context& c) {
    ran[868] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06039FA4 mov.l r14,@-r15
    c.r[3] = c.r[5];  // 06039FA6 mov r5,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06039FA8 mov.b @r3,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06039FAA extu.b r1,r0
    c.t = c.r[0] == 0x2u;  // 06039FAC cmp/eq #2,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06039FE8; } }  // 06039FAE bt/s 0x06039FE8 ; mov r15,r14
    c.r[1] = 0x2u;  // 06039FB2 mov #2,r1
    c.t = (int32_t)c.r[0] > (int32_t)c.r[1];  // 06039FB4 cmp/gt r1,r0
    { const bool k = c.t; c.t = c.r[0] == 0x4u; if (k) { goto L_06039FC4; } }  // 06039FB6 bt/s 0x06039FC4 ; cmp/eq #4,r0
    c.t = c.r[0] == 0x1u;  // 06039FBA cmp/eq #1,r0
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_06039FCC; } }  // 06039FBC bt/s 0x06039FCC ; mov r3,r1
    c.r[3] += 2; goto L_0603A00C;  // 06039FC0 bra 0x0603A00C ; add #2,r3
L_06039FC4:
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_06039FEE; } }  // 06039FC4 bt/s 0x06039FEE ; mov r3,r1
    c.r[3] += 2; goto L_0603A00C;  // 06039FC8 bra 0x0603A00C ; add #2,r3
L_06039FCC:
    c.r[7] = ld32(0x0603A014u);  // 06039FCC mov.l 0x0603A014,r7
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06039FCE mov.b @r7,r2
    c.r[1] += 1;  // 06039FD0 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06039FD2 mov.b @r1,r1
    c.r[2] += c.r[1];  // 06039FD4 add r1,r2
    c.r[2] = (uint32_t)(int32_t)(int8_t)c.r[2];  // 06039FD6 exts.b r2,r2
    c.t = (int32_t)c.r[2] >= 0;  // 06039FD8 cmp/pz r2
    if (c.t) { goto L_06039FDE; }  // 06039FDA bt 0x06039FDE
    c.r[2] = 0x0u;  // 06039FDC mov #0,r2
L_06039FDE:
    c.r[1] = 0x1Fu;  // 06039FDE mov #31,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 06039FE0 cmp/gt r1,r2
    if (!c.t) { goto L_06039FE6; }  // 06039FE2 bf 0x06039FE6
    c.r[2] = c.r[1];  // 06039FE4 mov r1,r2
L_06039FE6:
    st8(c.r[7], c.r[2]);  // 06039FE6 mov.b r2,@r7
L_06039FE8:
    c.r[7] = ld32(0x0603A018u);  // 06039FE8 mov.l 0x0603A018,r7
    c.r[1] = c.r[3]; goto L_06039FF0;  // 06039FEA bra 0x06039FF0 ; mov r3,r1
L_06039FEE:
    c.r[7] = ld32(0x0603A01Cu);  // 06039FEE mov.l 0x0603A01C,r7
L_06039FF0:
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06039FF0 mov.b @r7,r2
    c.r[1] += 1;  // 06039FF2 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06039FF4 mov.b @r1,r1
    c.r[2] += c.r[1];  // 06039FF6 add r1,r2
    c.r[2] = (uint32_t)(int32_t)(int8_t)c.r[2];  // 06039FF8 exts.b r2,r2
    c.t = (int32_t)c.r[2] >= 0;  // 06039FFA cmp/pz r2
    if (c.t) { goto L_0603A000; }  // 06039FFC bt 0x0603A000
    c.r[2] = 0x0u;  // 06039FFE mov #0,r2
L_0603A000:
    c.r[1] = 0x1Fu;  // 0603A000 mov #31,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0603A002 cmp/gt r1,r2
    if (!c.t) { goto L_0603A008; }  // 0603A004 bf 0x0603A008
    c.r[2] = c.r[1];  // 0603A006 mov r1,r2
L_0603A008:
    st8(c.r[7], c.r[2]);  // 0603A008 mov.b r2,@r7
    c.r[3] += 2;  // 0603A00A add #2,r3
L_0603A00C:
    c.r[15] = c.r[14];  // 0603A00C mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603A00E mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[3]; c.pc = x; return; }  // 0603A010 rts ; mov r3,r0
}

void f_0603A028(SH2Context& c) {
    ran[869] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603A028 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603A02A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0603A02C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0603A02E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0603A030 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0603A032 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603A034 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603A036 sts.l pr,@-r15
    c.r[15] -= 8;  // 0603A038 add #-8,r15
    c.r[14] = c.r[15];  // 0603A03A mov r15,r14
    c.r[13] = c.r[5];  // 0603A03C mov r5,r13
    c.r[2] = 0x0u;  // 0603A03E mov #0,r2
    st8(c.r[14], c.r[2]);  // 0603A040 mov.b r2,@r14
    c.r[1] = c.r[14];  // 0603A042 mov r14,r1
    c.r[1] += 1;  // 0603A044 add #1,r1
    st8(c.r[1], c.r[2]);  // 0603A046 mov.b r2,@r1
    c.r[3] = c.r[14];  // 0603A048 mov r14,r3
    c.r[3] += 2;  // 0603A04A add #2,r3
    c.r[1] = 0x1u;  // 0603A04C mov #1,r1
    st8(c.r[3], c.r[1]);  // 0603A04E mov.b r1,@r3
    c.r[1] = c.r[14];  // 0603A050 mov r14,r1
    c.r[1] += 3;  // 0603A052 add #3,r1
    st8(c.r[1], c.r[2]);  // 0603A054 mov.b r2,@r1
    c.r[2] = c.r[14];  // 0603A056 mov r14,r2
    c.r[2] += 4;  // 0603A058 add #4,r2
    c.r[1] = 0x2u;  // 0603A05A mov #2,r1
    st8(c.r[2], c.r[1]);  // 0603A05C mov.b r1,@r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[13]);  // 0603A05E mov.b @r13,r0
    c.r[0] &= 0x7u;  // 0603A060 and #7,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 0603A062 mov.b @(r0,r14),r1
    c.r[8] = c.r[1] & 0xFFu;  // 0603A064 extu.b r1,r8
    c.r[1] = ld32(0x0603A164u);  // 0603A066 mov.l 0x0603A164,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603A068 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0603A06A extu.b r1,r1
    c.r[0] = c.r[1];  // 0603A06C mov r1,r0
    c.r[0] >>= 2;  // 0603A06E shlr2 r0
    c.r[0] >>= 2;  // 0603A070 shlr2 r0
    c.r[0] >>= 2;  // 0603A072 shlr2 r0
    c.r[1] >>= 2;  // 0603A074 shlr2 r1
    c.r[1] >>= 2;  // 0603A076 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0603A078 shlr r1
    c.r[1] >>= 2;  // 0603A07A shlr2 r1
    c.r[0] &= 0x1u;  // 0603A07C and #1,r0
    c.t = c.r[1] == c.r[0];  // 0603A07E cmp/eq r0,r1
    { const bool k = c.t; c.r[2] = c.r[8]; if (k) { goto L_0603A0CC; } }  // 0603A080 bt/s 0x0603A0CC ; mov r8,r2
    c.r[1] = ld32(0x0603A168u);  // 0603A084 mov.l 0x0603A168,r1
    c.r[8] <<= 2;  // 0603A086 shll2 r8
    c.r[8] += c.r[8];  // 0603A088 add r8,r8
    c.r[8] += c.r[1];  // 0603A08A add r1,r8
    c.r[12] = c.r[8];  // 0603A08C mov r8,r12
    c.r[12] += 108;  // 0603A08E add #108,r12
    c.r[1] = c.r[13];  // 0603A090 mov r13,r1
    c.r[1] += 1;  // 0603A092 add #1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603A094 mov.b @r1,r4
    c.r[3] = ld32(0x0603A16Cu);  // 0603A096 mov.l 0x0603A16C,r3
    c.r[4] = c.r[4] & 0xFFu;  // 0603A098 extu.b r4,r4
    c.r[1] = c.r[13];  // 0603A09A mov r13,r1
    c.r[1] += 2;  // 0603A09C add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603A09E mov.b @r1,r1
    c.r[4] <<= 8;  // 0603A0A0 shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 0603A0A2 extu.b r1,r1
    c.r[4] |= c.r[1];  // 0603A0A4 or r1,r4
    { const uint32_t x = c.r[3]; c.pr = 0x0603A0AAu; c.r[4] = (uint32_t)(int32_t)(int16_t)c.r[4]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603A0AAu) return; }  // 0603A0A6 jsr @r3 ; exts.w r4,r4
    c.r[4] = c.r[0];  // 0603A0AA mov r0,r4
    c.r[5] = c.r[1];  // 0603A0AC mov r1,r5
    c.r[1] = ld32(0x0603A170u);  // 0603A0AE mov.l 0x0603A170,r1
    c.r[9] = ld32(c.r[1]);  // 0603A0B0 mov.l @r1,r9
    c.r[10] = ld32(c.r[1] + 4);  // 0603A0B2 mov.l @(4,r1),r10
    c.r[3] = ld32(0x0603A174u);  // 0603A0B4 mov.l 0x0603A174,r3
    c.r[6] = c.r[9];  // 0603A0B6 mov r9,r6
    { const uint32_t x = c.r[3]; c.pr = 0x0603A0BCu; c.r[7] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603A0BCu) return; }  // 0603A0B8 jsr @r3 ; mov r10,r7
    c.r[4] = c.r[0];  // 0603A0BC mov r0,r4
    c.r[11] = ld32(0x0603A178u);  // 0603A0BE mov.l 0x0603A178,r11
    { const uint32_t x = c.r[11]; c.pr = 0x0603A0C4u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603A0C4u) return; }  // 0603A0C0 jsr @r11 ; mov r1,r5
    c.r[1] = ld32(c.r[12]);  // 0603A0C4 mov.l @r12,r1
    c.r[8] += 112;  // 0603A0C6 add #112,r8
    c.r[1] += c.r[0]; goto L_0603A114;  // 0603A0C8 bra 0x0603A114 ; add r0,r1
L_0603A0CC:
    c.r[1] = ld32(0x0603A168u);  // 0603A0CC mov.l 0x0603A168,r1
    c.r[8] = c.r[2];  // 0603A0CE mov r2,r8
    c.r[8] <<= 2;  // 0603A0D0 shll2 r8
    c.r[8] += c.r[8];  // 0603A0D2 add r8,r8
    c.r[8] += c.r[1];  // 0603A0D4 add r1,r8
    c.r[12] = c.r[8];  // 0603A0D6 mov r8,r12
    c.r[12] += 108;  // 0603A0D8 add #108,r12
    c.r[1] = c.r[13];  // 0603A0DA mov r13,r1
    c.r[1] += 1;  // 0603A0DC add #1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603A0DE mov.b @r1,r4
    c.r[3] = ld32(0x0603A16Cu);  // 0603A0E0 mov.l 0x0603A16C,r3
    c.r[4] = c.r[4] & 0xFFu;  // 0603A0E2 extu.b r4,r4
    c.r[1] = c.r[13];  // 0603A0E4 mov r13,r1
    c.r[1] += 2;  // 0603A0E6 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603A0E8 mov.b @r1,r1
    c.r[4] <<= 8;  // 0603A0EA shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 0603A0EC extu.b r1,r1
    c.r[4] |= c.r[1];  // 0603A0EE or r1,r4
    { const uint32_t x = c.r[3]; c.pr = 0x0603A0F4u; c.r[4] = (uint32_t)(int32_t)(int16_t)c.r[4]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603A0F4u) return; }  // 0603A0F0 jsr @r3 ; exts.w r4,r4
    c.r[4] = c.r[0];  // 0603A0F4 mov r0,r4
    c.r[5] = c.r[1];  // 0603A0F6 mov r1,r5
    c.r[1] = ld32(0x0603A170u);  // 0603A0F8 mov.l 0x0603A170,r1
    c.r[9] = ld32(c.r[1]);  // 0603A0FA mov.l @r1,r9
    c.r[10] = ld32(c.r[1] + 4);  // 0603A0FC mov.l @(4,r1),r10
    c.r[3] = ld32(0x0603A174u);  // 0603A0FE mov.l 0x0603A174,r3
    c.r[6] = c.r[9];  // 0603A100 mov r9,r6
    { const uint32_t x = c.r[3]; c.pr = 0x0603A106u; c.r[7] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603A106u) return; }  // 0603A102 jsr @r3 ; mov r10,r7
    c.r[4] = c.r[0];  // 0603A106 mov r0,r4
    c.r[11] = ld32(0x0603A178u);  // 0603A108 mov.l 0x0603A178,r11
    { const uint32_t x = c.r[11]; c.pr = 0x0603A10Eu; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603A10Eu) return; }  // 0603A10A jsr @r11 ; mov r1,r5
    c.r[1] = ld32(c.r[12]);  // 0603A10E mov.l @r12,r1
    c.r[8] += 112;  // 0603A110 add #112,r8
    c.r[1] -= c.r[0];  // 0603A112 sub r0,r1
L_0603A114:
    st32(c.r[12], c.r[1]);  // 0603A114 mov.l r1,@r12
    c.r[1] = c.r[13];  // 0603A116 mov r13,r1
    c.r[1] += 3;  // 0603A118 add #3,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603A11A mov.b @r1,r4
    c.r[3] = ld32(0x0603A16Cu);  // 0603A11C mov.l 0x0603A16C,r3
    c.r[4] = c.r[4] & 0xFFu;  // 0603A11E extu.b r4,r4
    c.r[1] = c.r[13];  // 0603A120 mov r13,r1
    c.r[1] += 4;  // 0603A122 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603A124 mov.b @r1,r1
    c.r[4] <<= 8;  // 0603A126 shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 0603A128 extu.b r1,r1
    c.r[4] |= c.r[1];  // 0603A12A or r1,r4
    { const uint32_t x = c.r[3]; c.pr = 0x0603A130u; c.r[4] = (uint32_t)(int32_t)(int16_t)c.r[4]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603A130u) return; }  // 0603A12C jsr @r3 ; exts.w r4,r4
    c.r[4] = c.r[0];  // 0603A130 mov r0,r4
    c.r[5] = c.r[1];  // 0603A132 mov r1,r5
    c.r[6] = c.r[9];  // 0603A134 mov r9,r6
    c.r[3] = ld32(0x0603A174u);  // 0603A136 mov.l 0x0603A174,r3
    { const uint32_t x = c.r[3]; c.pr = 0x0603A13Cu; c.r[7] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603A13Cu) return; }  // 0603A138 jsr @r3 ; mov r10,r7
    c.r[4] = c.r[0];  // 0603A13C mov r0,r4
    { const uint32_t x = c.r[11]; c.pr = 0x0603A142u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603A142u) return; }  // 0603A13E jsr @r11 ; mov r1,r5
    c.r[1] = ld32(c.r[8]);  // 0603A142 mov.l @r8,r1
    c.r[1] -= c.r[0];  // 0603A144 sub r0,r1
    st32(c.r[8], c.r[1]);  // 0603A146 mov.l r1,@r8
    c.r[14] += 8;  // 0603A148 add #8,r14
    c.r[15] = c.r[14];  // 0603A14A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603A14C lds.l @r15+,pr
    c.r[13] += 5;  // 0603A14E add #5,r13
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603A150 mov.l @r15+,r14
    c.r[0] = c.r[13];  // 0603A152 mov r13,r0
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0603A154 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0603A156 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0603A158 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0603A15A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0603A15C mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603A15E rts ; mov.l @r15+,r8
}

void f_0603A17C(SH2Context& c) {
    ran[870] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603A17C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603A17E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0603A180 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603A182 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603A184 sts.l pr,@-r15
    c.r[15] -= 8;  // 0603A186 add #-8,r15
    c.r[14] = c.r[15];  // 0603A188 mov r15,r14
    c.r[10] = c.r[5];  // 0603A18A mov r5,r10
    c.r[2] = 0x0u;  // 0603A18C mov #0,r2
    st8(c.r[14], c.r[2]);  // 0603A18E mov.b r2,@r14
    c.r[1] = c.r[14];  // 0603A190 mov r14,r1
    c.r[1] += 1;  // 0603A192 add #1,r1
    st8(c.r[1], c.r[2]);  // 0603A194 mov.b r2,@r1
    c.r[3] = c.r[14];  // 0603A196 mov r14,r3
    c.r[3] += 2;  // 0603A198 add #2,r3
    c.r[1] = 0x1u;  // 0603A19A mov #1,r1
    st8(c.r[3], c.r[1]);  // 0603A19C mov.b r1,@r3
    c.r[1] = c.r[14];  // 0603A19E mov r14,r1
    c.r[1] += 3;  // 0603A1A0 add #3,r1
    st8(c.r[1], c.r[2]);  // 0603A1A2 mov.b r2,@r1
    c.r[2] = c.r[14];  // 0603A1A4 mov r14,r2
    c.r[2] += 4;  // 0603A1A6 add #4,r2
    c.r[1] = 0x2u;  // 0603A1A8 mov #2,r1
    st8(c.r[2], c.r[1]);  // 0603A1AA mov.b r1,@r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0603A1AC mov.b @r10,r1
    c.r[0] = 0x7u;  // 0603A1AE mov #7,r0
    c.r[1] &= c.r[0];  // 0603A1B0 and r0,r1
    c.r[0] = c.r[14];  // 0603A1B2 mov r14,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0603A1B4 mov.b @(r0,r1),r1
    c.r[9] = c.r[1] & 0xFFu;  // 0603A1B6 extu.b r1,r9
    c.r[1] = ld32(0x0603A248u);  // 0603A1B8 mov.l 0x0603A248,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603A1BA mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0603A1BC extu.b r1,r1
    c.r[0] = c.r[1];  // 0603A1BE mov r1,r0
    c.t = c.r[0] == 0x1u;  // 0603A1C0 cmp/eq #1,r0
    { const bool k = !c.t; c.t = c.r[9] > c.r[1]; if (k) { goto L_0603A1DE; } }  // 0603A1C2 bf/s 0x0603A1DE ; cmp/hi r1,r9
    { const bool k = c.t; c.r[0] = c.r[9]; if (k) { goto L_0603A1CE; } }  // 0603A1C6 bt/s 0x0603A1CE ; mov r9,r0
    c.r[5] = 0x0u; goto L_0603A1F0;  // 0603A1CA bra 0x0603A1F0 ; mov #0,r5
L_0603A1CE:
    c.t = c.r[0] == 0x2u;  // 0603A1CE cmp/eq #2,r0
    if (!c.t) { goto L_0603A1D8; }  // 0603A1D0 bf 0x0603A1D8
    c.r[5] = (uint32_t)(int16_t)ld16(0x0603A240u);  // 0603A1D2 mov.w 0x0603A240,r5
    goto L_0603A1F0;  // 0603A1D4 bra 0x0603A1F0 ; nop
L_0603A1D8:
    c.r[7] = (uint32_t)(int16_t)ld16(0x0603A240u);  // 0603A1D8 mov.w 0x0603A240,r7
    c.r[5] = 0x0u; goto L_0603A1F2;  // 0603A1DA bra 0x0603A1F2 ; mov #0,r5
L_0603A1DE:
    c.r[1] = ld32(0x0603A24Cu);  // 0603A1DE mov.l 0x0603A24C,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603A1E0 mov.b @r1,r0
    c.r[0] &= 0x1u;  // 0603A1E2 and #1,r0
    c.t = c.r[0] == 0x1u;  // 0603A1E4 cmp/eq #1,r0
    { const bool k = !c.t; c.r[5] = 0x0u; if (k) { goto L_0603A1EC; } }  // 0603A1E6 bf/s 0x0603A1EC ; mov #0,r5
    c.r[5] = (uint32_t)(int16_t)ld16(0x0603A240u);  // 0603A1EA mov.w 0x0603A240,r5
L_0603A1EC:
    c.r[7] = (uint32_t)(int16_t)ld16(0x0603A240u);  // 0603A1EC mov.w 0x0603A240,r7
    if (!c.t) { goto L_0603A1F2; }  // 0603A1EE bf 0x0603A1F2
L_0603A1F0:
    c.r[7] = (uint32_t)(int16_t)ld16(0x0603A242u);  // 0603A1F0 mov.w 0x0603A242,r7
L_0603A1F2:
    c.r[8] = ld32(0x0603A250u);  // 0603A1F2 mov.l 0x0603A250,r8
    c.r[2] = c.r[9];  // 0603A1F4 mov r9,r2
    c.r[2] <<= 2;  // 0603A1F6 shll2 r2
    c.r[2] += c.r[8];  // 0603A1F8 add r8,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603A244u);  // 0603A1FA mov.w 0x0603A244,r1
    c.r[0] = c.r[2];  // 0603A1FC mov r2,r0
    c.r[4] = ld32(c.r[0] + c.r[1]);  // 0603A1FE mov.l @(r0,r1),r4
    c.r[1] = ld32(0x0603A254u);  // 0603A200 mov.l 0x0603A254,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603A206u; c.r[6] = 0x4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603A206u) return; }  // 0603A202 jsr @r1 ; mov #4,r6
    c.r[3] = c.r[9];  // 0603A206 mov r9,r3
    c.r[3] += c.r[3];  // 0603A208 add r3,r3
    c.r[3] += c.r[8];  // 0603A20A add r8,r3
    c.r[1] = c.r[3];  // 0603A20C mov r3,r1
    c.r[1] += 47;  // 0603A20E add #47,r1
    c.r[2] = 0x0u;  // 0603A210 mov #0,r2
    st8(c.r[1], c.r[2]);  // 0603A212 mov.b r2,@r1
    c.r[3] += 48;  // 0603A214 add #48,r3
    st8(c.r[3], c.r[2]);  // 0603A216 mov.b r2,@r3
    c.r[3] = c.r[9];  // 0603A218 mov r9,r3
    c.r[3] <<= 2;  // 0603A21A shll2 r3
    c.r[3] += c.r[3];  // 0603A21C add r3,r3
    c.r[3] += c.r[8];  // 0603A21E add r8,r3
    c.r[1] = c.r[3];  // 0603A220 mov r3,r1
    c.r[1] += 108;  // 0603A222 add #108,r1
    c.r[2] = 0x0u;  // 0603A224 mov #0,r2
    st32(c.r[1], c.r[2]);  // 0603A226 mov.l r2,@r1
    c.r[3] += 112;  // 0603A228 add #112,r3
    st32(c.r[3], c.r[2]);  // 0603A22A mov.l r2,@r3
    c.r[14] += 8;  // 0603A22C add #8,r14
    c.r[15] = c.r[14];  // 0603A22E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603A230 lds.l @r15+,pr
    c.r[10] += 1;  // 0603A232 add #1,r10
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603A234 mov.l @r15+,r14
    c.r[0] = c.r[10];  // 0603A236 mov r10,r0
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0603A238 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0603A23A mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603A23C rts ; mov.l @r15+,r8
}

void f_0603A258(SH2Context& c) {
    ran[871] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603A258 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603A25A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603A25C sts.l pr,@-r15
    c.r[8] = c.r[5];  // 0603A25E mov r5,r8
    c.r[5] = ld32(0x0603A2D4u);  // 0603A260 mov.l 0x0603A2D4,r5
    c.r[4] = ld32(0x0603A2D8u);  // 0603A262 mov.l 0x0603A2D8,r4
    c.r[1] = ld32(0x0603A2DCu);  // 0603A264 mov.l 0x0603A2DC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603A26Au; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603A26Au) return; }  // 0603A266 jsr @r1 ; mov r15,r14
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0603A26A mov.b @r8,r0
    c.r[0] &= 0x80u;  // 0603A26C and #128,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603A26E tst r0,r0
    if (c.t) { goto L_0603A2B2; }  // 0603A270 bt 0x0603A2B2
    c.r[3] = ld32(0x0603A2E0u);  // 0603A272 mov.l 0x0603A2E0,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603A2CAu);  // 0603A274 mov.w 0x0603A2CA,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0603A276 mov.w @r3,r2
    c.r[2] |= c.r[1];  // 0603A278 or r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603A2CCu);  // 0603A27A mov.w 0x0603A2CC,r1
    c.r[2] &= c.r[1];  // 0603A27C and r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603A2CEu);  // 0603A27E mov.w 0x0603A2CE,r1
    c.r[2] &= c.r[1];  // 0603A280 and r1,r2
    st16(c.r[3], c.r[2]);  // 0603A282 mov.w r2,@r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0603A284 mov.b @r8,r1
    c.r[2] = ld32(0x0603A2E4u);  // 0603A286 mov.l 0x0603A2E4,r2
    c.r[0] = c.r[1];  // 0603A288 mov r1,r0
    c.r[0] >>= 2;  // 0603A28A shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0603A28C shlr r0
    c.r[0] >>= 2;  // 0603A28E shlr2 r0
    c.r[0] &= 0x3u;  // 0603A290 and #3,r0
    st8(c.r[2], c.r[0]);  // 0603A292 mov.b r0,@r2
    c.r[1] = ld32(0x0603A2E8u);  // 0603A294 mov.l 0x0603A2E8,r1
    c.r[2] = 0x0u;  // 0603A296 mov #0,r2
    st16(c.r[1], c.r[2]);  // 0603A298 mov.w r2,@r1
    c.r[1] = ld32(0x0603A2ECu);  // 0603A29A mov.l 0x0603A2EC,r1
    st16(c.r[1], c.r[2]);  // 0603A29C mov.w r2,@r1
    c.r[1] = ld32(0x0603A2F0u);  // 0603A29E mov.l 0x0603A2F0,r1
    st16(c.r[1], c.r[2]);  // 0603A2A0 mov.w r2,@r1
    c.r[1] = ld32(0x0603A2F4u);  // 0603A2A2 mov.l 0x0603A2F4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603A2A8u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603A2A8u) return; }  // 0603A2A4 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x0603A2F8u);  // 0603A2A8 mov.l 0x0603A2F8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603A2AEu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603A2AEu) return; }  // 0603A2AA jsr @r1 ; mov #0,r4
    c.r[15] = c.r[14]; goto L_0603A2BE;  // 0603A2AE bra 0x0603A2BE ; mov r14,r15
L_0603A2B2:
    c.r[1] = ld32(0x0603A2E0u);  // 0603A2B2 mov.l 0x0603A2E0,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0603A2B4 mov.w @r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0603A2D0u);  // 0603A2B6 mov.w 0x0603A2D0,r3
    c.r[2] &= c.r[3];  // 0603A2B8 and r3,r2
    st16(c.r[1], c.r[2]);  // 0603A2BA mov.w r2,@r1
    c.r[15] = c.r[14];  // 0603A2BC mov r14,r15
L_0603A2BE:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603A2BE lds.l @r15+,pr
    c.r[8] += 1;  // 0603A2C0 add #1,r8
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603A2C2 mov.l @r15+,r14
    c.r[0] = c.r[8];  // 0603A2C4 mov r8,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603A2C6 rts ; mov.l @r15+,r8
}

void f_0603A2FC(SH2Context& c) {
    ran[872] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603A2FC mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0603A2FE mov r15,r14
    c.r[7] = c.r[5];  // 0603A300 mov r5,r7
    c.r[3] = ld32(0x0603A338u);  // 0603A302 mov.l 0x0603A338,r3
    c.r[6] = (uint32_t)(int16_t)ld16(0x0603A332u);  // 0603A304 mov.w 0x0603A332,r6
    c.r[1] = c.r[7];  // 0603A306 mov r7,r1
    c.r[0] = c.r[3];  // 0603A308 mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0603A30A mov.b @r1+,r2
    c.r[7] += 2;  // 0603A30C add #2,r7
    c.r[2] = c.r[2] & 0xFFu;  // 0603A30E extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603A310 mov.b @r1,r1
    c.r[2] <<= 8;  // 0603A312 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603A314 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0603A316 or r1,r2
    st16(c.r[0] + c.r[6], c.r[2]);  // 0603A318 mov.w r2,@(r0,r6)
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603A334u);  // 0603A31A mov.w 0x0603A334,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0603A31C mov.w @(r0,r1),r1
    c.r[3] = c.r[1] & 0xFFFFu;  // 0603A31E extu.w r1,r3
    c.r[3] <<= 2;  // 0603A320 shll2 r3
    c.r[3] += c.r[3];  // 0603A322 add r3,r3
    c.r[3] <<= 2;  // 0603A324 shll2 r3
    c.r[1] = ld32(0x0603A33Cu);  // 0603A326 mov.l 0x0603A33C,r1
    c.r[0] = c.r[3];  // 0603A328 mov r3,r0
    st16(c.r[0] + c.r[1], c.r[2]);  // 0603A32A mov.w r2,@(r0,r1)
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603A32C mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[7]; c.pc = x; return; }  // 0603A32E rts ; mov r7,r0
}

void f_0603A340(SH2Context& c) {
    ran[873] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603A340 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603A342 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603A344 mov.l r14,@-r15
    c.r[4] = c.r[5];  // 0603A346 mov r5,r4
    c.r[9] = ld32(0x0603A3E8u);  // 0603A348 mov.l 0x0603A3E8,r9
    c.r[8] = (uint32_t)(int16_t)ld16(0x0603A3E2u);  // 0603A34A mov.w 0x0603A3E2,r8
    c.r[1] = c.r[9];  // 0603A34C mov r9,r1
    c.r[1] += c.r[8];  // 0603A34E add r8,r1
    c.r[1] += 1;  // 0603A350 add #1,r1
    c.r[5] = 0x1Fu;  // 0603A352 mov #31,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603A354 mov.b @r1,r1
    c.r[0] = c.r[9];  // 0603A356 mov r9,r0
    c.r[5] &= c.r[1];  // 0603A358 and r1,r5
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[8]);  // 0603A35A mov.w @(r0,r8),r1
    c.r[14] = c.r[15];  // 0603A35C mov r15,r14
    c.r[7] = c.r[1];  // 0603A35E mov r1,r7
    c.r[7] >>= 2;  // 0603A360 shlr2 r7
    c.t = c.r[7] & 1; c.r[7] >>= 1;  // 0603A362 shlr r7
    c.r[7] >>= 2;  // 0603A364 shlr2 r7
    c.r[0] = 0x1Fu;  // 0603A366 mov #31,r0
    c.r[7] &= c.r[0];  // 0603A368 and r0,r7
    c.r[6] = c.r[1];  // 0603A36A mov r1,r6
    c.r[6] >>= 8;  // 0603A36C shlr8 r6
    c.r[6] >>= 2;  // 0603A36E shlr2 r6
    c.r[1] = c.r[4];  // 0603A370 mov r4,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0603A372 mov.b @r1+,r2
    c.r[6] &= c.r[0];  // 0603A374 and r0,r6
    c.r[2] += c.r[5];  // 0603A376 add r5,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603A378 mov.b @r1,r3
    c.r[5] = (uint32_t)(int32_t)(int8_t)c.r[2];  // 0603A37A exts.b r2,r5
    c.r[1] = c.r[4];  // 0603A37C mov r4,r1
    c.r[1] += 2;  // 0603A37E add #2,r1
    c.r[7] += c.r[3];  // 0603A380 add r3,r7
    c.r[2] = (uint32_t)(int32_t)(int8_t)c.r[7];  // 0603A382 exts.b r7,r2
    c.r[3] = 0x20u;  // 0603A384 mov #32,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603A386 mov.b @r1,r1
    c.t = (int32_t)c.r[5] > (int32_t)c.r[3];  // 0603A388 cmp/gt r3,r5
    c.r[6] += c.r[1];  // 0603A38A add r1,r6
    { const bool k = !c.t; c.r[1] = (uint32_t)(int32_t)(int8_t)c.r[6]; if (k) { goto L_0603A392; } }  // 0603A38C bf/s 0x0603A392 ; exts.b r6,r1
    c.r[5] = 0x1Fu;  // 0603A390 mov #31,r5
L_0603A392:
    c.t = (int32_t)c.r[2] > (int32_t)c.r[3];  // 0603A392 cmp/gt r3,r2
    if (!c.t) { goto L_0603A398; }  // 0603A394 bf 0x0603A398
    c.r[2] = 0x1Fu;  // 0603A396 mov #31,r2
L_0603A398:
    c.t = (int32_t)c.r[1] > (int32_t)c.r[3];  // 0603A398 cmp/gt r3,r1
    if (!c.t) { goto L_0603A39E; }  // 0603A39A bf 0x0603A39E
    c.r[1] = 0x1Fu;  // 0603A39C mov #31,r1
L_0603A39E:
    c.t = (int32_t)c.r[5] >= 0;  // 0603A39E cmp/pz r5
    if (c.t) { goto L_0603A3A4; }  // 0603A3A0 bt 0x0603A3A4
    c.r[5] = 0x0u;  // 0603A3A2 mov #0,r5
L_0603A3A4:
    c.t = (int32_t)c.r[2] >= 0;  // 0603A3A4 cmp/pz r2
    if (c.t) { goto L_0603A3AA; }  // 0603A3A6 bt 0x0603A3AA
    c.r[2] = 0x0u;  // 0603A3A8 mov #0,r2
L_0603A3AA:
    c.t = (int32_t)c.r[1] >= 0;  // 0603A3AA cmp/pz r1
    if (c.t) { goto L_0603A3B0; }  // 0603A3AC bt 0x0603A3B0
    c.r[1] = 0x0u;  // 0603A3AE mov #0,r1
L_0603A3B0:
    c.r[1] <<= 8;  // 0603A3B0 shll8 r1
    c.r[1] <<= 2;  // 0603A3B2 shll2 r1
    c.r[2] <<= 2;  // 0603A3B4 shll2 r2
    c.r[2] += c.r[2];  // 0603A3B6 add r2,r2
    c.r[2] <<= 2;  // 0603A3B8 shll2 r2
    c.r[1] |= c.r[2];  // 0603A3BA or r2,r1
    c.r[1] |= c.r[5];  // 0603A3BC or r5,r1
    c.r[0] = c.r[9];  // 0603A3BE mov r9,r0
    st16(c.r[0] + c.r[8], c.r[1]);  // 0603A3C0 mov.w r1,@(r0,r8)
    c.r[2] = (uint32_t)(int16_t)ld16(0x0603A3E4u);  // 0603A3C2 mov.w 0x0603A3E4,r2
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 0603A3C4 mov.w @(r0,r2),r2
    c.r[15] = c.r[14];  // 0603A3C6 mov r14,r15
    c.r[3] = c.r[2] & 0xFFFFu;  // 0603A3C8 extu.w r2,r3
    c.r[3] <<= 2;  // 0603A3CA shll2 r3
    c.r[3] += c.r[3];  // 0603A3CC add r3,r3
    c.r[3] <<= 2;  // 0603A3CE shll2 r3
    c.r[2] = ld32(0x0603A3ECu);  // 0603A3D0 mov.l 0x0603A3EC,r2
    c.r[0] = c.r[3];  // 0603A3D2 mov r3,r0
    st16(c.r[0] + c.r[2], c.r[1]);  // 0603A3D4 mov.w r1,@(r0,r2)
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603A3D6 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0603A3D8 mov.l @r15+,r9
    c.r[4] += 3;  // 0603A3DA add #3,r4
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0603A3DC mov.l @r15+,r8
    { const uint32_t x = c.pr; c.r[0] = c.r[4]; c.pc = x; return; }  // 0603A3DE rts ; mov r4,r0
}

void f_0603A3F0(SH2Context& c) {
    ran[874] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603A3F0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603A3F2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603A3F4 mov.l r14,@-r15
    c.r[15] -= 16;  // 0603A3F6 add #-16,r15
    c.r[14] = c.r[15];  // 0603A3F8 mov r15,r14
    c.r[8] = c.r[5];  // 0603A3FA mov r5,r8
    c.r[6] = 0x0u;  // 0603A3FC mov #0,r6
    st16(c.r[14], c.r[6]);  // 0603A3FE mov.w r6,@r14
    c.r[2] = c.r[14];  // 0603A400 mov r14,r2
    c.r[2] += 2;  // 0603A402 add #2,r2
    c.r[1] = 0x1u;  // 0603A404 mov #1,r1
    st16(c.r[2], c.r[1]);  // 0603A406 mov.w r1,@r2
    c.r[2] = c.r[14];  // 0603A408 mov r14,r2
    c.r[2] += 4;  // 0603A40A add #4,r2
    c.r[1] = 0x2u;  // 0603A40C mov #2,r1
    st16(c.r[2], c.r[1]);  // 0603A40E mov.w r1,@r2
    c.r[7] = c.r[14];  // 0603A410 mov r14,r7
    c.r[7] += 6;  // 0603A412 add #6,r7
    c.r[1] = 0x4u;  // 0603A414 mov #4,r1
    st16(c.r[7], c.r[1]);  // 0603A416 mov.w r1,@r7
    c.r[2] = c.r[14];  // 0603A418 mov r14,r2
    c.r[2] += 8;  // 0603A41A add #8,r2
    c.r[1] = 0x8u;  // 0603A41C mov #8,r1
    st16(c.r[2], c.r[1]);  // 0603A41E mov.w r1,@r2
    c.r[5] = c.r[14];  // 0603A420 mov r14,r5
    c.r[5] += 10;  // 0603A422 add #10,r5
    c.r[1] = 0x10u;  // 0603A424 mov #16,r1
    st16(c.r[5], c.r[1]);  // 0603A426 mov.w r1,@r5
    c.r[2] = c.r[14];  // 0603A428 mov r14,r2
    c.r[2] += 12;  // 0603A42A add #12,r2
    c.r[1] = 0x20u;  // 0603A42C mov #32,r1
    st16(c.r[2], c.r[1]);  // 0603A42E mov.w r1,@r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0603A430 mov.b @r8,r1
    c.r[3] = c.r[1] & 0xFFu;  // 0603A432 extu.b r1,r3
    c.r[0] = c.r[3];  // 0603A434 mov r3,r0
    c.r[0] &= 0x1u;  // 0603A436 and #1,r0
    c.r[0] += c.r[0];  // 0603A438 add r0,r0
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[14]);  // 0603A43A mov.w @(r0,r14),r2
    c.r[0] = c.r[3];  // 0603A43C mov r3,r0
    c.r[0] &= 0x2u;  // 0603A43E and #2,r0
    c.r[0] += c.r[0];  // 0603A440 add r0,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[14]);  // 0603A442 mov.w @(r0,r14),r1
    c.r[4] = c.r[3];  // 0603A444 mov r3,r4
    c.r[1] |= c.r[2];  // 0603A446 or r2,r1
    c.r[0] = c.r[1] & 0xFFFFu;  // 0603A448 extu.w r1,r0
    c.r[1] = 0x4u;  // 0603A44A mov #4,r1
    c.r[1] &= c.r[3];  // 0603A44C and r3,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603A44E tst r1,r1
    { const bool k = c.t; c.r[2] = c.r[14]; if (k) { goto L_0603A456; } }  // 0603A450 bt/s 0x0603A456 ; mov r14,r2
    c.r[2] = c.r[7];  // 0603A454 mov r7,r2
L_0603A456:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0603A456 mov.w @r2,r1
    c.r[9] = 0x10u;  // 0603A458 mov #16,r9
    c.r[2] = c.r[0];  // 0603A45A mov r0,r2
    c.r[2] |= c.r[1];  // 0603A45C or r1,r2
    c.r[0] = c.r[3];  // 0603A45E mov r3,r0
    c.r[0] &= 0x8u;  // 0603A460 and #8,r0
    c.r[3] &= c.r[9];  // 0603A462 and r9,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[14]);  // 0603A464 mov.w @(r0,r14),r1
    c.t = (c.r[3] & c.r[3]) == 0;  // 0603A466 tst r3,r3
    c.r[2] |= c.r[1];  // 0603A468 or r1,r2
    c.r[0] = c.r[2] & 0xFFFFu;  // 0603A46A extu.w r2,r0
    { const bool k = c.t; c.r[1] = c.r[14]; if (k) { goto L_0603A472; } }  // 0603A46C bt/s 0x0603A472 ; mov r14,r1
    c.r[1] = c.r[5];  // 0603A470 mov r5,r1
L_0603A472:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0603A472 mov.w @r1,r1
    c.r[9] = 0x20u;  // 0603A474 mov #32,r9
    c.r[4] &= c.r[9];  // 0603A476 and r9,r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 0603A478 tst r4,r4
    c.r[1] |= c.r[0];  // 0603A47A or r0,r1
    { const bool k = c.t; c.r[0] = c.r[1] & 0xFFFFu; if (k) { goto L_0603A486; } }  // 0603A47C bt/s 0x0603A486 ; extu.w r1,r0
    c.r[0] |= 0x20u;  // 0603A480 or #32,r0
    c.r[1] = ld32(0x0603A4B0u);  // 0603A482 mov.l 0x0603A4B0,r1
    st16(c.r[1], c.r[6]);  // 0603A484 mov.w r6,@r1
L_0603A486:
    c.r[2] = ld32(0x0603A4B4u);  // 0603A486 mov.l 0x0603A4B4,r2
    c.r[1] = c.r[2];  // 0603A488 mov r2,r1
    c.r[1] += 20;  // 0603A48A add #20,r1
    st16(c.r[1], c.r[0]);  // 0603A48C mov.w r0,@r1
    c.r[1] = c.r[2];  // 0603A48E mov r2,r1
    c.r[1] += 14;  // 0603A490 add #14,r1
    st16(c.r[1], c.r[6]);  // 0603A492 mov.w r6,@r1
    c.r[1] = c.r[2];  // 0603A494 mov r2,r1
    c.r[1] += 16;  // 0603A496 add #16,r1
    st16(c.r[1], c.r[6]);  // 0603A498 mov.w r6,@r1
    c.r[2] += 18;  // 0603A49A add #18,r2
    st16(c.r[2], c.r[6]);  // 0603A49C mov.w r6,@r2
    c.r[14] += 16;  // 0603A49E add #16,r14
    c.r[15] = c.r[14];  // 0603A4A0 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603A4A2 mov.l @r15+,r14
    c.r[8] += 1;  // 0603A4A4 add #1,r8
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0603A4A6 mov.l @r15+,r9
    c.r[0] = c.r[8];  // 0603A4A8 mov r8,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603A4AA rts ; mov.l @r15+,r8
}

void f_0603A4B8(SH2Context& c) {
    ran[875] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603A4B8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603A4BA mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603A4BC sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0603A4BE mov r15,r14
    c.r[8] = c.r[5];  // 0603A4C0 mov r5,r8
    c.r[1] = ld32(0x0603A504u);  // 0603A4C2 mov.l 0x0603A504,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603A4C8u; c.r[4] = 0x5Fu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603A4C8u) return; }  // 0603A4C4 jsr @r1 ; mov #95,r4
    c.r[1] = ld32(0x0603A508u);  // 0603A4C8 mov.l 0x0603A508,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603A4CEu; c.r[4] = 0x8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603A4CEu) return; }  // 0603A4CA jsr @r1 ; mov #8,r4
    c.r[1] = ld32(0x0603A50Cu);  // 0603A4CE mov.l 0x0603A50C,r1
    c.r[6] = 0x0u;  // 0603A4D0 mov #0,r6
    c.r[5] = 0x0u;  // 0603A4D2 mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0603A4D8u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603A4D8u) return; }  // 0603A4D4 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x0603A510u);  // 0603A4D8 mov.l 0x0603A510,r1
    c.r[6] = 0x0u;  // 0603A4DA mov #0,r6
    c.r[5] = 0x0u;  // 0603A4DC mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0603A4E2u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603A4E2u) return; }  // 0603A4DE jsr @r1 ; mov #0,r4
    c.r[3] = ld32(0x0603A514u);  // 0603A4E2 mov.l 0x0603A514,r3
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0603A4E4 mov.w @r3,r0
    c.r[0] &= 0x20u;  // 0603A4E6 and #32,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603A4E8 tst r0,r0
    { const bool k = c.t; c.r[1] = 0x0u; if (k) { goto L_0603A4F4; } }  // 0603A4EA bt/s 0x0603A4F4 ; mov #0,r1
    c.r[2] = ld32(0x0603A518u);  // 0603A4EE mov.l 0x0603A518,r2
    st16(c.r[2], c.r[1]);  // 0603A4F0 mov.w r1,@r2
    c.r[1] = 0x0u;  // 0603A4F2 mov #0,r1
L_0603A4F4:
    st16(c.r[3], c.r[1]);  // 0603A4F4 mov.w r1,@r3
    c.r[15] = c.r[14];  // 0603A4F6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603A4F8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603A4FA mov.l @r15+,r14
    c.r[0] = c.r[8];  // 0603A4FC mov r8,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603A4FE rts ; mov.l @r15+,r8
}

void f_0603A51C(SH2Context& c) {
    ran[876] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603A51C mov.l r14,@-r15
    c.r[3] = c.r[5];  // 0603A51E mov r5,r3
    c.r[0] = c.r[3];  // 0603A520 mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0]); c.r[0] += 1;  // 0603A522 mov.b @r0+,r2
    c.r[5] = (uint32_t)(int16_t)ld16(0x0603A5A6u);  // 0603A524 mov.w 0x0603A5A6,r5
    c.r[2] = c.r[2] & 0xFFu;  // 0603A526 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0603A528 mov.b @r0,r1
    c.r[2] <<= 8;  // 0603A52A shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603A52C extu.b r1,r1
    c.r[2] |= c.r[1];  // 0603A52E or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0603A530 exts.w r2,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[5];  // 0603A532 cmp/gt r5,r2
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0603A53A; } }  // 0603A534 bt/s 0x0603A53A ; mov r15,r14
    c.r[2] = (uint32_t)(int16_t)ld16(0x0603A5A8u);  // 0603A538 mov.w 0x0603A5A8,r2
L_0603A53A:
    c.r[6] = (uint32_t)(int16_t)ld16(0x0603A5AAu);  // 0603A53A mov.w 0x0603A5AA,r6
    c.t = (int32_t)c.r[2] > (int32_t)c.r[6];  // 0603A53C cmp/gt r6,r2
    if (!c.t) { goto L_0603A542; }  // 0603A53E bf 0x0603A542
    c.r[2] = c.r[6];  // 0603A540 mov r6,r2
L_0603A542:
    c.r[7] = ld32(0x0603A5ACu);  // 0603A542 mov.l 0x0603A5AC,r7
    c.r[1] = c.r[7];  // 0603A544 mov r7,r1
    c.r[1] += 14;  // 0603A546 add #14,r1
    st16(c.r[1], c.r[2]);  // 0603A548 mov.w r2,@r1
    c.r[1] = c.r[3];  // 0603A54A mov r3,r1
    c.r[1] += 2;  // 0603A54C add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603A54E mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0603A550 extu.b r2,r2
    c.r[1] = c.r[3];  // 0603A552 mov r3,r1
    c.r[1] += 3;  // 0603A554 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603A556 mov.b @r1,r1
    c.r[2] <<= 8;  // 0603A558 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603A55A extu.b r1,r1
    c.r[2] |= c.r[1];  // 0603A55C or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0603A55E exts.w r2,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[5];  // 0603A560 cmp/gt r5,r2
    { const bool k = c.t; c.t = (int32_t)c.r[2] > (int32_t)c.r[6]; if (k) { goto L_0603A56A; } }  // 0603A562 bt/s 0x0603A56A ; cmp/gt r6,r2
    c.r[2] = (uint32_t)(int16_t)ld16(0x0603A5A8u);  // 0603A566 mov.w 0x0603A5A8,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[6];  // 0603A568 cmp/gt r6,r2
L_0603A56A:
    if (!c.t) { goto L_0603A56E; }  // 0603A56A bf 0x0603A56E
    c.r[2] = c.r[6];  // 0603A56C mov r6,r2
L_0603A56E:
    c.r[1] = c.r[7];  // 0603A56E mov r7,r1
    c.r[1] += 16;  // 0603A570 add #16,r1
    st16(c.r[1], c.r[2]);  // 0603A572 mov.w r2,@r1
    c.r[1] = c.r[3];  // 0603A574 mov r3,r1
    c.r[1] += 4;  // 0603A576 add #4,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603A578 mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0603A57A extu.b r2,r2
    c.r[1] = c.r[3];  // 0603A57C mov r3,r1
    c.r[1] += 5;  // 0603A57E add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603A580 mov.b @r1,r1
    c.r[2] <<= 8;  // 0603A582 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603A584 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0603A586 or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0603A588 exts.w r2,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[5];  // 0603A58A cmp/gt r5,r2
    { const bool k = c.t; c.t = (int32_t)c.r[2] > (int32_t)c.r[6]; if (k) { goto L_0603A594; } }  // 0603A58C bt/s 0x0603A594 ; cmp/gt r6,r2
    c.r[2] = (uint32_t)(int16_t)ld16(0x0603A5A8u);  // 0603A590 mov.w 0x0603A5A8,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[6];  // 0603A592 cmp/gt r6,r2
L_0603A594:
    if (!c.t) { goto L_0603A598; }  // 0603A594 bf 0x0603A598
    c.r[2] = c.r[6];  // 0603A596 mov r6,r2
L_0603A598:
    c.r[7] += 18;  // 0603A598 add #18,r7
    st16(c.r[7], c.r[2]);  // 0603A59A mov.w r2,@r7
    c.r[3] += 6;  // 0603A59C add #6,r3
    c.r[15] = c.r[14];  // 0603A59E mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603A5A0 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[3]; c.pc = x; return; }  // 0603A5A2 rts ; mov r3,r0
}

void f_0603A5B0(SH2Context& c) {
    ran[877] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603A5B0 mov.l r14,@-r15
    c.r[3] = c.r[5];  // 0603A5B2 mov r5,r3
    c.r[5] = ld32(0x0603A64Cu);  // 0603A5B4 mov.l 0x0603A64C,r5
    c.r[4] = c.r[5];  // 0603A5B6 mov r5,r4
    c.r[0] = c.r[3];  // 0603A5B8 mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]); c.r[0] += 1;  // 0603A5BA mov.b @r0+,r1
    c.r[4] += 14;  // 0603A5BC add #14,r4
    c.r[1] = c.r[1] & 0xFFu;  // 0603A5BE extu.b r1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0603A5C0 mov.b @r0,r2
    c.r[1] <<= 8;  // 0603A5C2 shll8 r1
    c.r[2] = c.r[2] & 0xFFu;  // 0603A5C4 extu.b r2,r2
    c.r[1] |= c.r[2];  // 0603A5C6 or r2,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[4]);  // 0603A5C8 mov.w @r4,r2
    c.r[6] = (uint32_t)(int16_t)ld16(0x0603A646u);  // 0603A5CA mov.w 0x0603A646,r6
    c.r[1] += c.r[2];  // 0603A5CC add r2,r1
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 0603A5CE exts.w r1,r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[6];  // 0603A5D0 cmp/gt r6,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0603A5D8; } }  // 0603A5D2 bt/s 0x0603A5D8 ; mov r15,r14
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603A648u);  // 0603A5D6 mov.w 0x0603A648,r1
L_0603A5D8:
    c.r[7] = (uint32_t)(int16_t)ld16(0x0603A64Au);  // 0603A5D8 mov.w 0x0603A64A,r7
    c.t = (int32_t)c.r[1] > (int32_t)c.r[7];  // 0603A5DA cmp/gt r7,r1
    if (!c.t) { goto L_0603A5E0; }  // 0603A5DC bf 0x0603A5E0
    c.r[1] = c.r[7];  // 0603A5DE mov r7,r1
L_0603A5E0:
    st16(c.r[4], c.r[1]);  // 0603A5E0 mov.w r1,@r4
    c.r[4] = c.r[5];  // 0603A5E2 mov r5,r4
    c.r[1] = c.r[3];  // 0603A5E4 mov r3,r1
    c.r[1] += 2;  // 0603A5E6 add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603A5E8 mov.b @r1,r2
    c.r[4] += 16;  // 0603A5EA add #16,r4
    c.r[2] = c.r[2] & 0xFFu;  // 0603A5EC extu.b r2,r2
    c.r[1] = c.r[3];  // 0603A5EE mov r3,r1
    c.r[1] += 3;  // 0603A5F0 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603A5F2 mov.b @r1,r1
    c.r[2] <<= 8;  // 0603A5F4 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603A5F6 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0603A5F8 or r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[4]);  // 0603A5FA mov.w @r4,r1
    c.r[2] += c.r[1];  // 0603A5FC add r1,r2
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0603A5FE exts.w r2,r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[6];  // 0603A600 cmp/gt r6,r1
    { const bool k = c.t; c.t = (int32_t)c.r[1] > (int32_t)c.r[7]; if (k) { goto L_0603A60A; } }  // 0603A602 bt/s 0x0603A60A ; cmp/gt r7,r1
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603A648u);  // 0603A606 mov.w 0x0603A648,r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[7];  // 0603A608 cmp/gt r7,r1
L_0603A60A:
    if (!c.t) { goto L_0603A60E; }  // 0603A60A bf 0x0603A60E
    c.r[1] = c.r[7];  // 0603A60C mov r7,r1
L_0603A60E:
    st16(c.r[4], c.r[1]);  // 0603A60E mov.w r1,@r4
    c.r[1] = c.r[3];  // 0603A610 mov r3,r1
    c.r[1] += 4;  // 0603A612 add #4,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603A614 mov.b @r1,r2
    c.r[5] += 18;  // 0603A616 add #18,r5
    c.r[2] = c.r[2] & 0xFFu;  // 0603A618 extu.b r2,r2
    c.r[1] = c.r[3];  // 0603A61A mov r3,r1
    c.r[1] += 5;  // 0603A61C add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603A61E mov.b @r1,r1
    c.r[2] <<= 8;  // 0603A620 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603A622 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0603A624 or r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[5]);  // 0603A626 mov.w @r5,r1
    c.r[2] += c.r[1];  // 0603A628 add r1,r2
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0603A62A exts.w r2,r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[6];  // 0603A62C cmp/gt r6,r1
    { const bool k = c.t; c.t = (int32_t)c.r[1] > (int32_t)c.r[7]; if (k) { goto L_0603A636; } }  // 0603A62E bt/s 0x0603A636 ; cmp/gt r7,r1
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603A648u);  // 0603A632 mov.w 0x0603A648,r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[7];  // 0603A634 cmp/gt r7,r1
L_0603A636:
    if (!c.t) { goto L_0603A63A; }  // 0603A636 bf 0x0603A63A
    c.r[1] = c.r[7];  // 0603A638 mov r7,r1
L_0603A63A:
    st16(c.r[5], c.r[1]);  // 0603A63A mov.w r1,@r5
    c.r[3] += 6;  // 0603A63C add #6,r3
    c.r[15] = c.r[14];  // 0603A63E mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603A640 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[3]; c.pc = x; return; }  // 0603A642 rts ; mov r3,r0
}

void f_0603A650(SH2Context& c) {
    ran[878] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603A650 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603A652 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0603A654 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0603A656 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0603A658 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603A65A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603A65C sts.l pr,@-r15
    c.r[8] = c.r[5];  // 0603A65E mov r5,r8
    c.r[0] = c.r[8];  // 0603A660 mov r8,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]); c.r[0] += 1;  // 0603A662 mov.b @r0+,r1
    c.r[3] = ld32(0x0603A7ACu);  // 0603A664 mov.l 0x0603A7AC,r3
    c.r[9] = c.r[1] & 0xFFu;  // 0603A666 extu.b r1,r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0603A668 mov.b @r0,r1
    c.r[2] = c.r[9];  // 0603A66A mov r9,r2
    c.r[12] = c.r[1] & 0xFFu;  // 0603A66C extu.b r1,r12
    c.r[1] = c.r[8];  // 0603A66E mov r8,r1
    c.r[1] += 2;  // 0603A670 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603A672 mov.b @r1,r1
    c.r[2] += c.r[2];  // 0603A674 add r2,r2
    c.r[10] = c.r[1] & 0xFFu;  // 0603A676 extu.b r1,r10
    c.r[1] = c.r[8];  // 0603A678 mov r8,r1
    c.r[1] += 3;  // 0603A67A add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603A67C mov.b @r1,r1
    c.r[2] += c.r[9];  // 0603A67E add r9,r2
    c.r[11] = c.r[1] & 0xFFu;  // 0603A680 extu.b r1,r11
    c.r[1] = c.r[8];  // 0603A682 mov r8,r1
    c.r[1] += 4;  // 0603A684 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603A686 mov.b @r1,r1
    c.r[2] <<= 2;  // 0603A688 shll2 r2
    c.r[6] = c.r[1] & 0xFFu;  // 0603A68A extu.b r1,r6
    c.r[1] = c.r[2];  // 0603A68C mov r2,r1
    c.r[1] += c.r[3];  // 0603A68E add r3,r1
    c.r[1] += 3;  // 0603A690 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603A692 mov.b @r1,r1
    c.r[1] -= 1;  // 0603A694 add #-1,r1
    c.r[7] = c.r[1] & 0xFFu;  // 0603A696 extu.b r1,r7
    c.r[1] = ld32(0x0603A7B0u);  // 0603A698 mov.l 0x0603A7B0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603A69A mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0603A69C extu.b r1,r0
    c.t = c.r[0] == 0x1u;  // 0603A69E cmp/eq #1,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0603A6B0; } }  // 0603A6A0 bt/s 0x0603A6B0 ; mov r15,r14
    c.r[1] = ld32(0x0603A7B4u);  // 0603A6A4 mov.l 0x0603A7B4,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603A6A6 mov.b @r1,r0
    c.r[0] &= 0x1u;  // 0603A6A8 and #1,r0
    c.t = c.r[0] == 0x1u;  // 0603A6AA cmp/eq #1,r0
    { const bool k = !c.t; c.r[0] = c.r[3]; if (k) { goto L_0603A6B8; } }  // 0603A6AC bf/s 0x0603A6B8 ; mov r3,r0
L_0603A6B0:
    c.r[0] = c.r[3];  // 0603A6B0 mov r3,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 0603A6B2 mov.w @(r0,r2),r1
    c.r[5] = c.r[1] & 0xFFFFu; goto L_0603A6D8;  // 0603A6B4 bra 0x0603A6D8 ; extu.w r1,r5
L_0603A6B8:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 0603A6B8 mov.w @(r0,r2),r1
    c.r[2] = c.r[1] & 0xFFFFu;  // 0603A6BA extu.w r1,r2
    c.r[1] = ld32(0x0603A7B8u);  // 0603A6BC mov.l 0x0603A7B8,r1
    c.r[2] += c.r[1];  // 0603A6BE add r1,r2
    c.t = (int32_t)c.r[2] >= 0;  // 0603A6C0 cmp/pz r2
    { const bool k = c.t; c.r[4] = c.r[2]; if (k) { goto L_0603A6CA; } }  // 0603A6C2 bt/s 0x0603A6CA ; mov r2,r4
    c.r[4] = (uint32_t)(int16_t)ld16(0x0603A7A2u);  // 0603A6C6 mov.w 0x0603A7A2,r4
    c.r[4] += c.r[2];  // 0603A6C8 add r2,r4
L_0603A6CA:
    c.r[1] = ld32(0x0603A7BCu);  // 0603A6CA mov.l 0x0603A7BC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603A6D0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603A6D0u) return; }  // 0603A6CC jsr @r1 ; nop
    c.r[4] <<= 8;  // 0603A6D0 shll8 r4
    c.r[4] <<= 2;  // 0603A6D2 shll2 r4
    c.r[2] -= c.r[4];  // 0603A6D4 sub r4,r2
    c.r[5] = c.r[2] & 0xFFFFu;  // 0603A6D6 extu.w r2,r5
L_0603A6D8:
    c.r[1] = 0x4u;  // 0603A6D8 mov #4,r1
    c.r[1] &= c.r[6];  // 0603A6DA and r6,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603A6DC tst r1,r1
    { const bool k = c.t; c.r[1] = 0x8u; if (k) { goto L_0603A6F8; } }  // 0603A6DE bt/s 0x0603A6F8 ; mov #8,r1
    c.r[1] = ld32(0x0603A7B0u);  // 0603A6E2 mov.l 0x0603A7B0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603A6E4 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0603A6E6 extu.b r1,r1
    c.r[0] = c.r[1];  // 0603A6E8 mov r1,r0
    c.t = c.r[0] == 0x1u;  // 0603A6EA cmp/eq #1,r0
    c.r[7] = c.t;  // 0603A6EC movt r7
    c.r[0] = 0x1u;  // 0603A6EE mov #1,r0
    c.r[7] ^= c.r[0];  // 0603A6F0 xor r0,r7
    c.r[0] = (uint32_t)(int16_t)ld16(0x0603A7A4u);  // 0603A6F2 mov.w 0x0603A7A4,r0
    c.r[6] &= c.r[0];  // 0603A6F4 and r0,r6
    c.r[1] = 0x8u;  // 0603A6F6 mov #8,r1
L_0603A6F8:
    c.r[1] &= c.r[6];  // 0603A6F8 and r6,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603A6FA tst r1,r1
    if (c.t) { goto L_0603A714; }  // 0603A6FC bt 0x0603A714
    c.r[1] = ld32(0x0603A7B0u);  // 0603A6FE mov.l 0x0603A7B0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603A700 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0603A702 extu.b r1,r1
    c.r[0] = c.r[1];  // 0603A704 mov r1,r0
    c.t = c.r[0] == 0x1u;  // 0603A706 cmp/eq #1,r0
    { const bool k = !c.t; c.r[2] = 0x2u; if (k) { goto L_0603A70E; } }  // 0603A708 bf/s 0x0603A70E ; mov #2,r2
    c.r[2] = c.r[1];  // 0603A70C mov r1,r2
L_0603A70E:
    c.r[7] = c.r[2];  // 0603A70E mov r2,r7
    c.r[0] = (uint32_t)(int16_t)ld16(0x0603A7A6u);  // 0603A710 mov.w 0x0603A7A6,r0
    c.r[6] &= c.r[0];  // 0603A712 and r0,r6
L_0603A714:
    c.r[1] = ld32(0x0603A7C0u);  // 0603A714 mov.l 0x0603A7C0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603A716 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0603A718 extu.b r1,r1
    c.r[0] = c.r[1];  // 0603A71A mov r1,r0
    c.r[0] >>= 2;  // 0603A71C shlr2 r0
    c.r[0] >>= 2;  // 0603A71E shlr2 r0
    c.r[0] >>= 2;  // 0603A720 shlr2 r0
    c.r[1] >>= 2;  // 0603A722 shlr2 r1
    c.r[1] >>= 2;  // 0603A724 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0603A726 shlr r1
    c.r[1] >>= 2;  // 0603A728 shlr2 r1
    c.r[0] &= 0x1u;  // 0603A72A and #1,r0
    c.t = c.r[1] == c.r[0];  // 0603A72C cmp/eq r0,r1
    { const bool k = c.t; c.r[2] = c.r[9]; if (k) { goto L_0603A758; } }  // 0603A72E bt/s 0x0603A758 ; mov r9,r2
    c.r[2] += c.r[2];  // 0603A732 add r2,r2
    c.r[2] += c.r[9];  // 0603A734 add r9,r2
    c.r[2] <<= 2;  // 0603A736 shll2 r2
    c.r[1] = ld32(0x0603A7C4u);  // 0603A738 mov.l 0x0603A7C4,r1
    c.r[2] += c.r[1];  // 0603A73A add r1,r2
    c.r[1] = c.r[12];  // 0603A73C mov r12,r1
    c.r[1] <<= 2;  // 0603A73E shll2 r1
    c.r[1] += c.r[1];  // 0603A740 add r1,r1
    c.r[2] = ld32(c.r[2] + 4);  // 0603A742 mov.l @(4,r2),r2
    c.r[10] = 0u - c.r[10];  // 0603A744 neg r10,r10
    c.r[2] += c.r[1];  // 0603A746 add r1,r2
    c.r[2] += 6;  // 0603A748 add #6,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0603A74A mov.b @r2,r1
    c.r[0] = 0x3Fu;  // 0603A74C mov #63,r0
    c.r[10] -= c.r[1];  // 0603A74E sub r1,r10
    c.r[10] += 40;  // 0603A750 add #40,r10
    c.r[10] &= c.r[0];  // 0603A752 and r0,r10
    c.r[0] = 0x1u;  // 0603A754 mov #1,r0
    c.r[6] ^= c.r[0];  // 0603A756 xor r0,r6
L_0603A758:
    c.r[3] = ld32(0x0603A7C8u);  // 0603A758 mov.l 0x0603A7C8,r3
    c.r[2] = c.r[7];  // 0603A75A mov r7,r2
    c.r[2] += c.r[2];  // 0603A75C add r2,r2
    c.r[2] += c.r[3];  // 0603A75E add r3,r2
    c.r[1] = c.r[2];  // 0603A760 mov r2,r1
    c.r[1] += 47;  // 0603A762 add #47,r1
    st8(c.r[1], c.r[10]);  // 0603A764 mov.b r10,@r1
    c.r[2] += 48;  // 0603A766 add #48,r2
    st8(c.r[2], c.r[11]);  // 0603A768 mov.b r11,@r2
    c.r[7] <<= 2;  // 0603A76A shll2 r7
    c.r[7] += c.r[3];  // 0603A76C add r3,r7
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603A7A8u);  // 0603A76E mov.w 0x0603A7A8,r1
    c.r[0] = c.r[7];  // 0603A770 mov r7,r0
    c.r[2] = c.r[9];  // 0603A772 mov r9,r2
    c.r[2] += c.r[2];  // 0603A774 add r2,r2
    c.r[2] += c.r[9];  // 0603A776 add r9,r2
    c.r[2] <<= 2;  // 0603A778 shll2 r2
    c.r[7] = ld32(c.r[0] + c.r[1]);  // 0603A77A mov.l @(r0,r1),r7
    c.r[4] = c.r[12];  // 0603A77C mov r12,r4
    c.r[1] = ld32(0x0603A7C4u);  // 0603A77E mov.l 0x0603A7C4,r1
    c.r[2] += c.r[1];  // 0603A780 add r1,r2
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 0603A782 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0603A784 mov.l r11,@-r15
    c.r[1] = ld32(0x0603A7CCu);  // 0603A786 mov.l 0x0603A7CC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603A78Cu; c.r[15] -= 4; st32(c.r[15], c.r[10]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603A78Cu) return; }  // 0603A788 jsr @r1 ; mov.l r10,@-r15
    c.r[15] = c.r[14];  // 0603A78C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603A78E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603A790 mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0603A792 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0603A794 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0603A796 mov.l @r15+,r10
    c.r[8] += 5;  // 0603A798 add #5,r8
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0603A79A mov.l @r15+,r9
    c.r[0] = c.r[8];  // 0603A79C mov r8,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603A79E rts ; mov.l @r15+,r8
}

void f_0603A7D0(SH2Context& c) {
    ran[879] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603A7D0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603A7D2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0603A7D4 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0603A7D6 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0603A7D8 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603A7DA mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603A7DC sts.l pr,@-r15
    c.r[8] = c.r[5];  // 0603A7DE mov r5,r8
    c.r[0] = c.r[8];  // 0603A7E0 mov r8,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]); c.r[0] += 1;  // 0603A7E2 mov.b @r0+,r1
    c.r[3] = ld32(0x0603A8F4u);  // 0603A7E4 mov.l 0x0603A8F4,r3
    c.r[11] = c.r[1] & 0xFFu;  // 0603A7E6 extu.b r1,r11
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0603A7E8 mov.b @r0,r1
    c.r[2] = c.r[11];  // 0603A7EA mov r11,r2
    c.r[12] = c.r[1] & 0xFFu;  // 0603A7EC extu.b r1,r12
    c.r[1] = c.r[8];  // 0603A7EE mov r8,r1
    c.r[1] += 2;  // 0603A7F0 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603A7F2 mov.b @r1,r1
    c.r[2] += c.r[2];  // 0603A7F4 add r2,r2
    c.r[9] = c.r[1] & 0xFFu;  // 0603A7F6 extu.b r1,r9
    c.r[1] = c.r[8];  // 0603A7F8 mov r8,r1
    c.r[1] += 3;  // 0603A7FA add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603A7FC mov.b @r1,r1
    c.r[2] += c.r[11];  // 0603A7FE add r11,r2
    c.r[10] = c.r[1] & 0xFFu;  // 0603A800 extu.b r1,r10
    c.r[1] = c.r[8];  // 0603A802 mov r8,r1
    c.r[1] += 4;  // 0603A804 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603A806 mov.b @r1,r1
    c.r[2] <<= 2;  // 0603A808 shll2 r2
    c.r[6] = c.r[1] & 0xFFu;  // 0603A80A extu.b r1,r6
    c.r[1] = c.r[2];  // 0603A80C mov r2,r1
    c.r[1] += c.r[3];  // 0603A80E add r3,r1
    c.r[1] += 3;  // 0603A810 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603A812 mov.b @r1,r1
    c.r[1] -= 1;  // 0603A814 add #-1,r1
    c.r[4] = c.r[1] & 0xFFu;  // 0603A816 extu.b r1,r4
    c.r[1] = ld32(0x0603A8F8u);  // 0603A818 mov.l 0x0603A8F8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603A81A mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0603A81C extu.b r1,r0
    c.t = c.r[0] == 0x1u;  // 0603A81E cmp/eq #1,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0603A830; } }  // 0603A820 bt/s 0x0603A830 ; mov r15,r14
    c.r[1] = ld32(0x0603A8FCu);  // 0603A824 mov.l 0x0603A8FC,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603A826 mov.b @r1,r0
    c.r[0] &= 0x1u;  // 0603A828 and #1,r0
    c.t = c.r[0] == 0x1u;  // 0603A82A cmp/eq #1,r0
    { const bool k = !c.t; c.r[5] = 0x0u; if (k) { goto L_0603A836; } }  // 0603A82C bf/s 0x0603A836 ; mov #0,r5
L_0603A830:
    c.r[0] = c.r[3];  // 0603A830 mov r3,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 0603A832 mov.w @(r0,r2),r1
    c.r[5] = c.r[1] & 0xFFFFu;  // 0603A834 extu.w r1,r5
L_0603A836:
    c.r[1] = 0x4u;  // 0603A836 mov #4,r1
    c.r[1] &= c.r[6];  // 0603A838 and r6,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603A83A tst r1,r1
    { const bool k = c.t; c.r[1] = 0x8u; if (k) { goto L_0603A856; } }  // 0603A83C bt/s 0x0603A856 ; mov #8,r1
    c.r[1] = ld32(0x0603A8F8u);  // 0603A840 mov.l 0x0603A8F8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603A842 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0603A844 extu.b r1,r1
    c.r[0] = c.r[1];  // 0603A846 mov r1,r0
    c.t = c.r[0] == 0x1u;  // 0603A848 cmp/eq #1,r0
    c.r[4] = c.t;  // 0603A84A movt r4
    c.r[0] = 0x1u;  // 0603A84C mov #1,r0
    c.r[4] ^= c.r[0];  // 0603A84E xor r0,r4
    c.r[0] = (uint32_t)(int16_t)ld16(0x0603A8EEu);  // 0603A850 mov.w 0x0603A8EE,r0
    c.r[6] &= c.r[0];  // 0603A852 and r0,r6
    c.r[1] = 0x8u;  // 0603A854 mov #8,r1
L_0603A856:
    c.r[1] &= c.r[6];  // 0603A856 and r6,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603A858 tst r1,r1
    if (c.t) { goto L_0603A872; }  // 0603A85A bt 0x0603A872
    c.r[1] = ld32(0x0603A8F8u);  // 0603A85C mov.l 0x0603A8F8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603A85E mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0603A860 extu.b r1,r1
    c.r[0] = c.r[1];  // 0603A862 mov r1,r0
    c.t = c.r[0] == 0x1u;  // 0603A864 cmp/eq #1,r0
    { const bool k = !c.t; c.r[2] = 0x2u; if (k) { goto L_0603A86C; } }  // 0603A866 bf/s 0x0603A86C ; mov #2,r2
    c.r[2] = c.r[1];  // 0603A86A mov r1,r2
L_0603A86C:
    c.r[4] = c.r[2];  // 0603A86C mov r2,r4
    c.r[0] = (uint32_t)(int16_t)ld16(0x0603A8F0u);  // 0603A86E mov.w 0x0603A8F0,r0
    c.r[6] &= c.r[0];  // 0603A870 and r0,r6
L_0603A872:
    c.r[1] = ld32(0x0603A900u);  // 0603A872 mov.l 0x0603A900,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603A874 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0603A876 extu.b r1,r1
    c.r[0] = c.r[1];  // 0603A878 mov r1,r0
    c.r[0] >>= 2;  // 0603A87A shlr2 r0
    c.r[0] >>= 2;  // 0603A87C shlr2 r0
    c.r[0] >>= 2;  // 0603A87E shlr2 r0
    c.r[1] >>= 2;  // 0603A880 shlr2 r1
    c.r[1] >>= 2;  // 0603A882 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0603A884 shlr r1
    c.r[1] >>= 2;  // 0603A886 shlr2 r1
    c.r[0] &= 0x1u;  // 0603A888 and #1,r0
    c.t = c.r[1] == c.r[0];  // 0603A88A cmp/eq r0,r1
    if (c.t) { goto L_0603A898; }  // 0603A88C bt 0x0603A898
    c.r[9] = 0u - c.r[9];  // 0603A88E neg r9,r9
    c.r[0] = 0x3Fu;  // 0603A890 mov #63,r0
    c.r[9] &= c.r[0];  // 0603A892 and r0,r9
    c.r[0] = 0x1u;  // 0603A894 mov #1,r0
    c.r[6] ^= c.r[0];  // 0603A896 xor r0,r6
L_0603A898:
    c.r[7] = ld32(0x0603A904u);  // 0603A898 mov.l 0x0603A904,r7
    c.r[2] = c.r[4];  // 0603A89A mov r4,r2
    c.r[2] += c.r[2];  // 0603A89C add r2,r2
    c.r[2] += c.r[7];  // 0603A89E add r7,r2
    c.r[3] = c.r[2];  // 0603A8A0 mov r2,r3
    c.r[3] += 47;  // 0603A8A2 add #47,r3
    c.r[2] += 48;  // 0603A8A4 add #48,r2
    c.r[4] <<= 2;  // 0603A8A6 shll2 r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0603A8A8 mov.b @r3,r1
    c.r[4] += c.r[7];  // 0603A8AA add r7,r4
    c.r[1] += c.r[9];  // 0603A8AC add r9,r1
    c.r[9] = c.r[1] & 0xFFu;  // 0603A8AE extu.b r1,r9
    st8(c.r[3], c.r[9]);  // 0603A8B0 mov.b r9,@r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0603A8B2 mov.b @r2,r1
    c.r[0] = c.r[4];  // 0603A8B4 mov r4,r0
    c.r[1] += c.r[10];  // 0603A8B6 add r10,r1
    c.r[10] = c.r[1] & 0xFFu;  // 0603A8B8 extu.b r1,r10
    st8(c.r[2], c.r[10]);  // 0603A8BA mov.b r10,@r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603A8F2u);  // 0603A8BC mov.w 0x0603A8F2,r1
    c.r[2] = c.r[11];  // 0603A8BE mov r11,r2
    c.r[2] += c.r[2];  // 0603A8C0 add r2,r2
    c.r[2] += c.r[11];  // 0603A8C2 add r11,r2
    c.r[7] = ld32(c.r[0] + c.r[1]);  // 0603A8C4 mov.l @(r0,r1),r7
    c.r[2] <<= 2;  // 0603A8C6 shll2 r2
    c.r[1] = ld32(0x0603A908u);  // 0603A8C8 mov.l 0x0603A908,r1
    c.r[2] += c.r[1];  // 0603A8CA add r1,r2
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 0603A8CC mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0603A8CE mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603A8D0 mov.l r9,@-r15
    c.r[1] = ld32(0x0603A90Cu);  // 0603A8D2 mov.l 0x0603A90C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603A8D8u; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603A8D8u) return; }  // 0603A8D4 jsr @r1 ; mov r12,r4
    c.r[15] = c.r[14];  // 0603A8D8 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603A8DA lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603A8DC mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0603A8DE mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0603A8E0 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0603A8E2 mov.l @r15+,r10
    c.r[8] += 5;  // 0603A8E4 add #5,r8
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0603A8E6 mov.l @r15+,r9
    c.r[0] = c.r[8];  // 0603A8E8 mov r8,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603A8EA rts ; mov.l @r15+,r8
}

void f_0603A910(SH2Context& c) {
    ran[880] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603A910 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0603A912 mov r15,r14
    c.r[7] = c.r[5];  // 0603A914 mov r5,r7
    c.r[1] = ld32(0x0603A93Cu);  // 0603A916 mov.l 0x0603A93C,r1
    c.r[3] = c.r[1];  // 0603A918 mov r1,r3
    c.r[3] += 2;  // 0603A91A add #2,r3
    c.r[2] = 0x4u;  // 0603A91C mov #4,r2
    st16(c.r[3], c.r[2]);  // 0603A91E mov.w r2,@r3
    c.r[3] = c.r[1];  // 0603A920 mov r1,r3
    c.r[3] += 4;  // 0603A922 add #4,r3
    c.r[2] = 0x7u;  // 0603A924 mov #7,r2
    st16(c.r[3], c.r[2]);  // 0603A926 mov.w r2,@r3
    c.r[2] = 0x4u;  // 0603A928 mov #4,r2
    st32(c.r[1] + 32, c.r[2]);  // 0603A92A mov.l r2,@(32,r1)
    c.r[1] += 1;  // 0603A92C add #1,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603A92E mov.b @r1,r0
    c.r[0] |= 0x8u;  // 0603A930 or #8,r0
    st8(c.r[1], c.r[0]);  // 0603A932 mov.b r0,@r1
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603A934 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[7]; c.pc = x; return; }  // 0603A936 rts ; mov r7,r0
}

void f_0603A940(SH2Context& c) {
    ran[881] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603A940 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0603A942 mov r15,r14
    c.r[7] = c.r[5];  // 0603A944 mov r5,r7
    c.r[1] = ld32(0x0603A96Cu);  // 0603A946 mov.l 0x0603A96C,r1
    c.r[3] = c.r[1];  // 0603A948 mov r1,r3
    c.r[3] += 2;  // 0603A94A add #2,r3
    c.r[2] = 0x6u;  // 0603A94C mov #6,r2
    st16(c.r[3], c.r[2]);  // 0603A94E mov.w r2,@r3
    c.r[3] = c.r[1];  // 0603A950 mov r1,r3
    c.r[3] += 4;  // 0603A952 add #4,r3
    c.r[2] = 0x4u;  // 0603A954 mov #4,r2
    st16(c.r[3], c.r[2]);  // 0603A956 mov.w r2,@r3
    c.r[2] = 0x4u;  // 0603A958 mov #4,r2
    st32(c.r[1] + 32, c.r[2]);  // 0603A95A mov.l r2,@(32,r1)
    c.r[1] += 1;  // 0603A95C add #1,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603A95E mov.b @r1,r0
    c.r[0] &= 0xF7u;  // 0603A960 and #247,r0
    st8(c.r[1], c.r[0]);  // 0603A962 mov.b r0,@r1
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603A964 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[7]; c.pc = x; return; }  // 0603A966 rts ; mov r7,r0
}

void f_0603A970(SH2Context& c) {
    ran[882] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603A970 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0603A972 mov r15,r14
    c.r[7] = c.r[5];  // 0603A974 mov r5,r7
    c.r[1] = ld32(0x0603A99Cu);  // 0603A976 mov.l 0x0603A99C,r1
    c.r[3] = c.r[1];  // 0603A978 mov r1,r3
    c.r[3] += 2;  // 0603A97A add #2,r3
    c.r[2] = 0x4u;  // 0603A97C mov #4,r2
    st16(c.r[3], c.r[2]);  // 0603A97E mov.w r2,@r3
    c.r[3] = c.r[1];  // 0603A980 mov r1,r3
    c.r[3] += 4;  // 0603A982 add #4,r3
    c.r[2] = 0x7u;  // 0603A984 mov #7,r2
    st16(c.r[3], c.r[2]);  // 0603A986 mov.w r2,@r3
    c.r[2] = ld32(0x0603A9A0u);  // 0603A988 mov.l 0x0603A9A0,r2
    st32(c.r[1] + 32, c.r[2]);  // 0603A98A mov.l r2,@(32,r1)
    c.r[1] += 1;  // 0603A98C add #1,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603A98E mov.b @r1,r0
    c.r[0] &= 0xF7u;  // 0603A990 and #247,r0
    st8(c.r[1], c.r[0]);  // 0603A992 mov.b r0,@r1
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603A994 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[7]; c.pc = x; return; }  // 0603A996 rts ; mov r7,r0
}

void f_0603A9A4(SH2Context& c) {
    ran[883] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603A9A4 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0603A9A6 mov r15,r14
    c.r[1] = ld32(0x0603AA24u);  // 0603A9A8 mov.l 0x0603AA24,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603A9AA mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0603A9AC extu.b r1,r1
    c.r[0] = c.r[1];  // 0603A9AE mov r1,r0
    c.r[0] >>= 2;  // 0603A9B0 shlr2 r0
    c.r[0] >>= 2;  // 0603A9B2 shlr2 r0
    c.r[0] >>= 2;  // 0603A9B4 shlr2 r0
    c.r[1] >>= 2;  // 0603A9B6 shlr2 r1
    c.r[1] >>= 2;  // 0603A9B8 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0603A9BA shlr r1
    c.r[1] >>= 2;  // 0603A9BC shlr2 r1
    c.r[0] &= 0x1u;  // 0603A9BE and #1,r0
    c.t = c.r[1] == c.r[0];  // 0603A9C0 cmp/eq r0,r1
    { const bool k = c.t; c.r[6] = c.r[5]; if (k) { goto L_0603A9E2; } }  // 0603A9C2 bt/s 0x0603A9E2 ; mov r5,r6
    c.r[7] = ld32(0x0603AA28u);  // 0603A9C6 mov.l 0x0603AA28,r7
    c.r[3] = c.r[7];  // 0603A9C8 mov r7,r3
    c.r[0] = c.r[6];  // 0603A9CA mov r6,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0]); c.r[0] += 1;  // 0603A9CC mov.b @r0+,r2
    c.r[3] += 62;  // 0603A9CE add #62,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0603A9D0 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0603A9D2 mov.b @r0,r1
    c.r[2] <<= 8;  // 0603A9D4 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603A9D6 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0603A9D8 or r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603AA20u);  // 0603A9DA mov.w 0x0603AA20,r1
    c.r[1] -= c.r[2];  // 0603A9DC sub r2,r1
    st16(c.r[3], c.r[1]); goto L_0603A9F8;  // 0603A9DE bra 0x0603A9F8 ; mov.w r1,@r3
L_0603A9E2:
    c.r[7] = ld32(0x0603AA28u);  // 0603A9E2 mov.l 0x0603AA28,r7
    c.r[3] = c.r[7];  // 0603A9E4 mov r7,r3
    c.r[0] = c.r[6];  // 0603A9E6 mov r6,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0]); c.r[0] += 1;  // 0603A9E8 mov.b @r0+,r2
    c.r[3] += 62;  // 0603A9EA add #62,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0603A9EC extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0603A9EE mov.b @r0,r1
    c.r[2] <<= 8;  // 0603A9F0 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603A9F2 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0603A9F4 or r1,r2
    st16(c.r[3], c.r[2]);  // 0603A9F6 mov.w r2,@r3
L_0603A9F8:
    c.r[1] = c.r[6];  // 0603A9F8 mov r6,r1
    c.r[1] += 2;  // 0603A9FA add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603A9FC mov.b @r1,r2
    c.r[7] += 64;  // 0603A9FE add #64,r7
    c.r[2] = c.r[2] & 0xFFu;  // 0603AA00 extu.b r2,r2
    c.r[1] = c.r[6];  // 0603AA02 mov r6,r1
    c.r[1] += 3;  // 0603AA04 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603AA06 mov.b @r1,r1
    c.r[2] <<= 8;  // 0603AA08 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603AA0A extu.b r1,r1
    c.r[2] |= c.r[1];  // 0603AA0C or r1,r2
    st16(c.r[7], c.r[2]);  // 0603AA0E mov.w r2,@r7
    c.r[2] = ld32(0x0603AA2Cu);  // 0603AA10 mov.l 0x0603AA2C,r2
    c.r[6] += 4;  // 0603AA12 add #4,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]);  // 0603AA14 mov.b @r4,r1
    c.r[15] = c.r[14];  // 0603AA16 mov r14,r15
    st8(c.r[2], c.r[1]);  // 0603AA18 mov.b r1,@r2
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603AA1A mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[6]; c.pc = x; return; }  // 0603AA1C rts ; mov r6,r0
}

void f_0603AA38(SH2Context& c) {
    ran[884] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603AA38 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603AA3A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0603AA3C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0603AA3E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0603AA40 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0603AA42 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603AA44 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603AA46 sts.l pr,@-r15
    c.r[15] -= 4;  // 0603AA48 add #-4,r15
    c.r[14] = c.r[15];  // 0603AA4A mov r15,r14
    st32(c.r[14], c.r[5]);  // 0603AA4C mov.l r5,@r14
    c.r[1] = c.r[4];  // 0603AA4E mov r4,r1
    c.r[1] += 1;  // 0603AA50 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603AA52 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0603AA54 mov r1,r0
    c.r[0] >>= 2;  // 0603AA56 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0603AA58 shlr r0
    c.r[0] &= 0x1u;  // 0603AA5A and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603AA5C tst r0,r0
    if (c.t) { goto L_0603AA6C; }  // 0603AA5E bt 0x0603AA6C
    c.r[1] = ld32(c.r[4] + 4);  // 0603AA60 mov.l @(4,r4),r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0603AA62 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0603AA64 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0603AA66 shar r1
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[1]; goto L_0603AA72;  // 0603AA68 bra 0x0603AA72 ; exts.w r1,r1
L_0603AA6C:
    c.r[1] = c.r[4];  // 0603AA6C mov r4,r1
    c.r[1] += 6;  // 0603AA6E add #6,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0603AA70 mov.w @r1,r1
L_0603AA72:
    c.r[3] = c.r[1];  // 0603AA72 mov r1,r3
    c.r[1] = c.r[4];  // 0603AA74 mov r4,r1
    c.r[1] += 1;  // 0603AA76 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603AA78 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0603AA7A mov r1,r0
    c.r[0] >>= 2;  // 0603AA7C shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0603AA7E shlr r0
    c.r[0] &= 0x1u;  // 0603AA80 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603AA82 tst r0,r0
    if (c.t) { goto L_0603AA92; }  // 0603AA84 bt 0x0603AA92
    c.r[1] = ld32(c.r[4] + 8);  // 0603AA86 mov.l @(8,r4),r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0603AA88 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0603AA8A shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0603AA8C shar r1
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[1]; goto L_0603AA98;  // 0603AA8E bra 0x0603AA98 ; exts.w r1,r1
L_0603AA92:
    c.r[1] = c.r[4];  // 0603AA92 mov r4,r1
    c.r[1] += 10;  // 0603AA94 add #10,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0603AA96 mov.w @r1,r1
L_0603AA98:
    c.r[13] = c.r[1];  // 0603AA98 mov r1,r13
    c.r[1] = c.r[4];  // 0603AA9A mov r4,r1
    c.r[1] += 1;  // 0603AA9C add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603AA9E mov.b @r1,r1
    c.r[0] = c.r[1];  // 0603AAA0 mov r1,r0
    c.r[0] >>= 2;  // 0603AAA2 shlr2 r0
    c.r[0] >>= 2;  // 0603AAA4 shlr2 r0
    c.r[0] &= 0x1u;  // 0603AAA6 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603AAA8 tst r0,r0
    { const bool k = c.t; c.r[4] += 65; if (k) { goto L_0603AB12; } }  // 0603AAAA bt/s 0x0603AB12 ; add #65,r4
    c.r[1] = ld32(0x0603AB84u);  // 0603AAAE mov.l 0x0603AB84,r1
    c.r[7] = ld32(c.r[1]);  // 0603AAB0 mov.l @r1,r7
L_0603AAB2:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]);  // 0603AAB2 mov.b @r4,r1
    c.r[2] = 0x4Cu;  // 0603AAB4 mov #76,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603AAB6 extu.b r1,r1
    c.macl = c.r[1] * c.r[2];  // 0603AAB8 mul.l r2,r1
    c.r[4] = c.macl;  // 0603AABA sts macl,r4
    c.r[4] += c.r[7];  // 0603AABC add r7,r4
    c.r[1] = c.r[4];  // 0603AABE mov r4,r1
    c.r[1] += 1;  // 0603AAC0 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603AAC2 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0603AAC4 mov r1,r0
    c.r[0] >>= 2;  // 0603AAC6 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0603AAC8 shlr r0
    c.r[0] &= 0x1u;  // 0603AACA and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603AACC tst r0,r0
    { const bool k = c.t; c.r[1] = ld32(c.r[4] + 4); if (k) { goto L_0603AAD8; } }  // 0603AACE bt/s 0x0603AAD8 ; mov.l @(4,r4),r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0603AAD2 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0603AAD4 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0603AAD6 shar r1
L_0603AAD8:
    c.r[3] += c.r[1];  // 0603AAD8 add r1,r3
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[3];  // 0603AADA exts.w r3,r1
    c.r[3] = c.r[1];  // 0603AADC mov r1,r3
    c.r[1] = c.r[4];  // 0603AADE mov r4,r1
    c.r[1] += 1;  // 0603AAE0 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603AAE2 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0603AAE4 mov r1,r0
    c.r[0] >>= 2;  // 0603AAE6 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0603AAE8 shlr r0
    c.r[0] &= 0x1u;  // 0603AAEA and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603AAEC tst r0,r0
    { const bool k = c.t; c.r[1] = ld32(c.r[4] + 8); if (k) { goto L_0603AAF8; } }  // 0603AAEE bt/s 0x0603AAF8 ; mov.l @(8,r4),r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0603AAF2 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0603AAF4 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0603AAF6 shar r1
L_0603AAF8:
    c.r[13] += c.r[1];  // 0603AAF8 add r1,r13
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[13];  // 0603AAFA exts.w r13,r1
    c.r[13] = c.r[1];  // 0603AAFC mov r1,r13
    c.r[1] = c.r[4];  // 0603AAFE mov r4,r1
    c.r[1] += 1;  // 0603AB00 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603AB02 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0603AB04 mov r1,r0
    c.r[0] >>= 2;  // 0603AB06 shlr2 r0
    c.r[0] >>= 2;  // 0603AB08 shlr2 r0
    c.r[0] &= 0x1u;  // 0603AB0A and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603AB0C tst r0,r0
    { const bool k = !c.t; c.r[4] += 65; if (k) { SH2_POLL(c); goto L_0603AAB2; } }  // 0603AB0E bf/s 0x0603AAB2 ; add #65,r4
L_0603AB12:
    c.r[10] = ld32(0x0603AB88u);  // 0603AB12 mov.l 0x0603AB88,r10
    c.r[1] = c.r[10];  // 0603AB14 mov r10,r1
    c.r[1] += 62;  // 0603AB16 add #62,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0603AB18 mov.w @r1,r4
    c.r[0] = ld32(0x0603AB8Cu);  // 0603AB1A mov.l 0x0603AB8C,r0
    c.r[1] = c.r[10];  // 0603AB1C mov r10,r1
    c.r[1] += 64;  // 0603AB1E add #64,r1
    c.r[11] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0603AB20 mov.w @r1,r11
    { const uint32_t x = c.r[0]; c.pr = 0x0603AB26u; c.r[4] -= c.r[3]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603AB26u) return; }  // 0603AB22 jsr @r0 ; sub r3,r4
    c.r[4] = c.r[0];  // 0603AB26 mov r0,r4
    c.r[5] = c.r[1];  // 0603AB28 mov r1,r5
    c.r[1] = ld32(0x0603AB90u);  // 0603AB2A mov.l 0x0603AB90,r1
    c.r[8] = ld32(c.r[1]);  // 0603AB2C mov.l @r1,r8
    c.r[9] = ld32(c.r[1] + 4);  // 0603AB2E mov.l @(4,r1),r9
    c.r[0] = ld32(0x0603AB94u);  // 0603AB30 mov.l 0x0603AB94,r0
    c.r[6] = c.r[8];  // 0603AB32 mov r8,r6
    { const uint32_t x = c.r[0]; c.pr = 0x0603AB38u; c.r[7] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603AB38u) return; }  // 0603AB34 jsr @r0 ; mov r9,r7
    c.r[4] = c.r[0];  // 0603AB38 mov r0,r4
    c.r[5] = c.r[1];  // 0603AB3A mov r1,r5
    c.r[0] = ld32(0x0603AB98u);  // 0603AB3C mov.l 0x0603AB98,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0603AB42u; c.r[11] -= c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603AB42u) return; }  // 0603AB3E jsr @r0 ; sub r13,r11
    c.r[1] = c.r[0];  // 0603AB42 mov r0,r1
    c.r[0] = ld32(0x0603AB9Cu);  // 0603AB44 mov.l 0x0603AB9C,r0
    st32(c.r[0], c.r[1]);  // 0603AB46 mov.l r1,@r0
    c.r[12] = (uint32_t)(int16_t)ld16(0x0603AB82u);  // 0603AB48 mov.w 0x0603AB82,r12
    c.r[0] = ld32(0x0603AB8Cu);  // 0603AB4A mov.l 0x0603AB8C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0603AB50u; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603AB50u) return; }  // 0603AB4C jsr @r0 ; mov r11,r4
    c.r[4] = c.r[0];  // 0603AB50 mov r0,r4
    c.r[5] = c.r[1];  // 0603AB52 mov r1,r5
    c.r[6] = c.r[8];  // 0603AB54 mov r8,r6
    c.r[0] = ld32(0x0603AB94u);  // 0603AB56 mov.l 0x0603AB94,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0603AB5Cu; c.r[7] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603AB5Cu) return; }  // 0603AB58 jsr @r0 ; mov r9,r7
    c.r[4] = c.r[0];  // 0603AB5C mov r0,r4
    c.r[5] = c.r[1];  // 0603AB5E mov r1,r5
    c.r[0] = ld32(0x0603AB98u);  // 0603AB60 mov.l 0x0603AB98,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0603AB66u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603AB66u) return; }  // 0603AB62 jsr @r0 ; nop
    c.r[1] = c.r[0];  // 0603AB66 mov r0,r1
    c.r[0] = c.r[10];  // 0603AB68 mov r10,r0
    st32(c.r[0] + c.r[12], c.r[1]);  // 0603AB6A mov.l r1,@(r0,r12)
    c.r[0] = ld32(c.r[14]); c.r[14] += 4;  // 0603AB6C mov.l @r14+,r0
    c.r[15] = c.r[14];  // 0603AB6E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603AB70 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603AB72 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0603AB74 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0603AB76 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0603AB78 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0603AB7A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0603AB7C mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603AB7E rts ; mov.l @r15+,r8
}

void f_0603ABA0(SH2Context& c) {
    ran[885] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603ABA0 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0603ABA2 mov r15,r14
    c.r[1] = ld32(0x0603AC20u);  // 0603ABA4 mov.l 0x0603AC20,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603ABA6 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0603ABA8 extu.b r1,r1
    c.r[0] = c.r[1];  // 0603ABAA mov r1,r0
    c.r[0] >>= 2;  // 0603ABAC shlr2 r0
    c.r[0] >>= 2;  // 0603ABAE shlr2 r0
    c.r[0] >>= 2;  // 0603ABB0 shlr2 r0
    c.r[1] >>= 2;  // 0603ABB2 shlr2 r1
    c.r[1] >>= 2;  // 0603ABB4 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0603ABB6 shlr r1
    c.r[1] >>= 2;  // 0603ABB8 shlr2 r1
    c.r[0] &= 0x1u;  // 0603ABBA and #1,r0
    c.t = c.r[1] == c.r[0];  // 0603ABBC cmp/eq r0,r1
    { const bool k = c.t; c.r[6] = c.r[5]; if (k) { goto L_0603ABDE; } }  // 0603ABBE bt/s 0x0603ABDE ; mov r5,r6
    c.r[7] = ld32(0x0603AC24u);  // 0603ABC2 mov.l 0x0603AC24,r7
    c.r[3] = c.r[7];  // 0603ABC4 mov r7,r3
    c.r[0] = c.r[6];  // 0603ABC6 mov r6,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0]); c.r[0] += 1;  // 0603ABC8 mov.b @r0+,r2
    c.r[3] += 54;  // 0603ABCA add #54,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0603ABCC extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0603ABCE mov.b @r0,r1
    c.r[2] <<= 8;  // 0603ABD0 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603ABD2 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0603ABD4 or r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603AC1Cu);  // 0603ABD6 mov.w 0x0603AC1C,r1
    c.r[1] -= c.r[2];  // 0603ABD8 sub r2,r1
    st16(c.r[3], c.r[1]); goto L_0603ABF4;  // 0603ABDA bra 0x0603ABF4 ; mov.w r1,@r3
L_0603ABDE:
    c.r[7] = ld32(0x0603AC24u);  // 0603ABDE mov.l 0x0603AC24,r7
    c.r[3] = c.r[7];  // 0603ABE0 mov r7,r3
    c.r[0] = c.r[6];  // 0603ABE2 mov r6,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0]); c.r[0] += 1;  // 0603ABE4 mov.b @r0+,r2
    c.r[3] += 54;  // 0603ABE6 add #54,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0603ABE8 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0603ABEA mov.b @r0,r1
    c.r[2] <<= 8;  // 0603ABEC shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603ABEE extu.b r1,r1
    c.r[2] |= c.r[1];  // 0603ABF0 or r1,r2
    st16(c.r[3], c.r[2]);  // 0603ABF2 mov.w r2,@r3
L_0603ABF4:
    c.r[1] = c.r[6];  // 0603ABF4 mov r6,r1
    c.r[1] += 2;  // 0603ABF6 add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603ABF8 mov.b @r1,r2
    c.r[7] += 56;  // 0603ABFA add #56,r7
    c.r[2] = c.r[2] & 0xFFu;  // 0603ABFC extu.b r2,r2
    c.r[1] = c.r[6];  // 0603ABFE mov r6,r1
    c.r[1] += 3;  // 0603AC00 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603AC02 mov.b @r1,r1
    c.r[2] <<= 8;  // 0603AC04 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603AC06 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0603AC08 or r1,r2
    st16(c.r[7], c.r[2]);  // 0603AC0A mov.w r2,@r7
    c.r[2] = ld32(0x0603AC28u);  // 0603AC0C mov.l 0x0603AC28,r2
    c.r[6] += 4;  // 0603AC0E add #4,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]);  // 0603AC10 mov.b @r4,r1
    c.r[15] = c.r[14];  // 0603AC12 mov r14,r15
    st8(c.r[2], c.r[1]);  // 0603AC14 mov.b r1,@r2
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603AC16 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[6]; c.pc = x; return; }  // 0603AC18 rts ; mov r6,r0
}

void f_0603AC34(SH2Context& c) {
    ran[886] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603AC34 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603AC36 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0603AC38 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0603AC3A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0603AC3C mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0603AC3E mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603AC40 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603AC42 sts.l pr,@-r15
    c.r[15] -= 8;  // 0603AC44 add #-8,r15
    c.r[14] = c.r[15];  // 0603AC46 mov r15,r14
    st32(c.r[14], c.r[5]);  // 0603AC48 mov.l r5,@r14
    c.r[1] = ld32(0x0603AD90u);  // 0603AC4A mov.l 0x0603AD90,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0603AC4C mov.w @r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0603AD8Eu);  // 0603AC4E mov.w 0x0603AD8E,r2
    c.r[2] &= c.r[1];  // 0603AC50 and r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0603AC52 tst r2,r2
    { const bool k = !c.t; c.r[0] = ld32(c.r[14]); if (k) { goto L_0603AC5C; } }  // 0603AC54 bf/s 0x0603AC5C ; mov.l @r14,r0
    goto L_0603AD78;  // 0603AC58 bra 0x0603AD78 ; nop
L_0603AC5C:
    c.r[1] = c.r[4];  // 0603AC5C mov r4,r1
    c.r[1] += 1;  // 0603AC5E add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603AC60 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0603AC62 mov r1,r0
    c.r[0] >>= 2;  // 0603AC64 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0603AC66 shlr r0
    c.r[0] &= 0x1u;  // 0603AC68 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603AC6A tst r0,r0
    if (c.t) { goto L_0603AC7A; }  // 0603AC6C bt 0x0603AC7A
    c.r[1] = ld32(c.r[4] + 4);  // 0603AC6E mov.l @(4,r4),r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0603AC70 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0603AC72 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0603AC74 shar r1
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[1]; goto L_0603AC80;  // 0603AC76 bra 0x0603AC80 ; exts.w r1,r1
L_0603AC7A:
    c.r[1] = c.r[4];  // 0603AC7A mov r4,r1
    c.r[1] += 6;  // 0603AC7C add #6,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0603AC7E mov.w @r1,r1
L_0603AC80:
    c.r[3] = c.r[1];  // 0603AC80 mov r1,r3
    c.r[1] = c.r[4];  // 0603AC82 mov r4,r1
    c.r[1] += 1;  // 0603AC84 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603AC86 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0603AC88 mov r1,r0
    c.r[0] >>= 2;  // 0603AC8A shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0603AC8C shlr r0
    c.r[0] &= 0x1u;  // 0603AC8E and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603AC90 tst r0,r0
    if (c.t) { goto L_0603ACA0; }  // 0603AC92 bt 0x0603ACA0
    c.r[1] = ld32(c.r[4] + 8);  // 0603AC94 mov.l @(8,r4),r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0603AC96 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0603AC98 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0603AC9A shar r1
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[1]; goto L_0603ACA6;  // 0603AC9C bra 0x0603ACA6 ; exts.w r1,r1
L_0603ACA0:
    c.r[1] = c.r[4];  // 0603ACA0 mov r4,r1
    c.r[1] += 10;  // 0603ACA2 add #10,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0603ACA4 mov.w @r1,r1
L_0603ACA6:
    c.r[13] = c.r[1];  // 0603ACA6 mov r1,r13
    c.r[1] = c.r[4];  // 0603ACA8 mov r4,r1
    c.r[1] += 1;  // 0603ACAA add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603ACAC mov.b @r1,r1
    c.r[0] = c.r[1];  // 0603ACAE mov r1,r0
    c.r[0] >>= 2;  // 0603ACB0 shlr2 r0
    c.r[0] >>= 2;  // 0603ACB2 shlr2 r0
    c.r[0] &= 0x1u;  // 0603ACB4 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603ACB6 tst r0,r0
    { const bool k = c.t; c.r[4] += 65; if (k) { goto L_0603AD20; } }  // 0603ACB8 bt/s 0x0603AD20 ; add #65,r4
    c.r[1] = ld32(0x0603AD94u);  // 0603ACBC mov.l 0x0603AD94,r1
    c.r[7] = ld32(c.r[1]);  // 0603ACBE mov.l @r1,r7
L_0603ACC0:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]);  // 0603ACC0 mov.b @r4,r1
    c.r[2] = 0x4Cu;  // 0603ACC2 mov #76,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603ACC4 extu.b r1,r1
    c.macl = c.r[1] * c.r[2];  // 0603ACC6 mul.l r2,r1
    c.r[4] = c.macl;  // 0603ACC8 sts macl,r4
    c.r[4] += c.r[7];  // 0603ACCA add r7,r4
    c.r[1] = c.r[4];  // 0603ACCC mov r4,r1
    c.r[1] += 1;  // 0603ACCE add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603ACD0 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0603ACD2 mov r1,r0
    c.r[0] >>= 2;  // 0603ACD4 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0603ACD6 shlr r0
    c.r[0] &= 0x1u;  // 0603ACD8 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603ACDA tst r0,r0
    { const bool k = c.t; c.r[1] = ld32(c.r[4] + 4); if (k) { goto L_0603ACE6; } }  // 0603ACDC bt/s 0x0603ACE6 ; mov.l @(4,r4),r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0603ACE0 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0603ACE2 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0603ACE4 shar r1
L_0603ACE6:
    c.r[3] += c.r[1];  // 0603ACE6 add r1,r3
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[3];  // 0603ACE8 exts.w r3,r1
    c.r[3] = c.r[1];  // 0603ACEA mov r1,r3
    c.r[1] = c.r[4];  // 0603ACEC mov r4,r1
    c.r[1] += 1;  // 0603ACEE add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603ACF0 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0603ACF2 mov r1,r0
    c.r[0] >>= 2;  // 0603ACF4 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0603ACF6 shlr r0
    c.r[0] &= 0x1u;  // 0603ACF8 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603ACFA tst r0,r0
    { const bool k = c.t; c.r[1] = ld32(c.r[4] + 8); if (k) { goto L_0603AD06; } }  // 0603ACFC bt/s 0x0603AD06 ; mov.l @(8,r4),r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0603AD00 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0603AD02 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0603AD04 shar r1
L_0603AD06:
    c.r[13] += c.r[1];  // 0603AD06 add r1,r13
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[13];  // 0603AD08 exts.w r13,r1
    c.r[13] = c.r[1];  // 0603AD0A mov r1,r13
    c.r[1] = c.r[4];  // 0603AD0C mov r4,r1
    c.r[1] += 1;  // 0603AD0E add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603AD10 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0603AD12 mov r1,r0
    c.r[0] >>= 2;  // 0603AD14 shlr2 r0
    c.r[0] >>= 2;  // 0603AD16 shlr2 r0
    c.r[0] &= 0x1u;  // 0603AD18 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603AD1A tst r0,r0
    { const bool k = !c.t; c.r[4] += 65; if (k) { SH2_POLL(c); goto L_0603ACC0; } }  // 0603AD1C bf/s 0x0603ACC0 ; add #65,r4
L_0603AD20:
    c.r[10] = ld32(0x0603AD98u);  // 0603AD20 mov.l 0x0603AD98,r10
    c.r[1] = c.r[10];  // 0603AD22 mov r10,r1
    c.r[1] += 54;  // 0603AD24 add #54,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0603AD26 mov.w @r1,r4
    c.r[12] = ld32(0x0603AD9Cu);  // 0603AD28 mov.l 0x0603AD9C,r12
    c.r[1] = c.r[10];  // 0603AD2A mov r10,r1
    c.r[1] += 56;  // 0603AD2C add #56,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0603AD2E mov.w @r1,r1
    c.r[4] -= c.r[3];  // 0603AD30 sub r3,r4
    { const uint32_t x = c.r[12]; c.pr = 0x0603AD36u; st32(c.r[14] + 4, c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603AD36u) return; }  // 0603AD32 jsr @r12 ; mov.l r1,@(4,r14)
    c.r[4] = c.r[0];  // 0603AD36 mov r0,r4
    c.r[5] = c.r[1];  // 0603AD38 mov r1,r5
    c.r[1] = ld32(0x0603ADA0u);  // 0603AD3A mov.l 0x0603ADA0,r1
    c.r[8] = ld32(c.r[1]);  // 0603AD3C mov.l @r1,r8
    c.r[9] = ld32(c.r[1] + 4);  // 0603AD3E mov.l @(4,r1),r9
    c.r[12] = ld32(0x0603ADA4u);  // 0603AD40 mov.l 0x0603ADA4,r12
    c.r[6] = c.r[8];  // 0603AD42 mov r8,r6
    { const uint32_t x = c.r[12]; c.pr = 0x0603AD48u; c.r[7] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603AD48u) return; }  // 0603AD44 jsr @r12 ; mov r9,r7
    c.r[4] = c.r[0];  // 0603AD48 mov r0,r4
    c.r[11] = ld32(0x0603ADA8u);  // 0603AD4A mov.l 0x0603ADA8,r11
    { const uint32_t x = c.r[11]; c.pr = 0x0603AD50u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603AD50u) return; }  // 0603AD4C jsr @r11 ; mov r1,r5
    c.r[12] = ld32(0x0603ADACu);  // 0603AD50 mov.l 0x0603ADAC,r12
    st32(c.r[12], c.r[0]);  // 0603AD52 mov.l r0,@r12
    c.r[12] = ld32(c.r[14] + 4);  // 0603AD54 mov.l @(4,r14),r12
    c.r[10] += 112;  // 0603AD56 add #112,r10
    c.r[12] -= c.r[13];  // 0603AD58 sub r13,r12
    st32(c.r[14] + 4, c.r[12]);  // 0603AD5A mov.l r12,@(4,r14)
    c.r[12] = ld32(0x0603AD9Cu);  // 0603AD5C mov.l 0x0603AD9C,r12
    { const uint32_t x = c.r[12]; c.pr = 0x0603AD62u; c.r[4] = ld32(c.r[14] + 4); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603AD62u) return; }  // 0603AD5E jsr @r12 ; mov.l @(4,r14),r4
    c.r[4] = c.r[0];  // 0603AD62 mov r0,r4
    c.r[5] = c.r[1];  // 0603AD64 mov r1,r5
    c.r[6] = c.r[8];  // 0603AD66 mov r8,r6
    c.r[12] = ld32(0x0603ADA4u);  // 0603AD68 mov.l 0x0603ADA4,r12
    { const uint32_t x = c.r[12]; c.pr = 0x0603AD6Eu; c.r[7] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603AD6Eu) return; }  // 0603AD6A jsr @r12 ; mov r9,r7
    c.r[4] = c.r[0];  // 0603AD6E mov r0,r4
    { const uint32_t x = c.r[11]; c.pr = 0x0603AD74u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603AD74u) return; }  // 0603AD70 jsr @r11 ; mov r1,r5
    st32(c.r[10], c.r[0]);  // 0603AD74 mov.l r0,@r10
    c.r[0] = ld32(c.r[14]);  // 0603AD76 mov.l @r14,r0
L_0603AD78:
    c.r[14] += 8;  // 0603AD78 add #8,r14
    c.r[15] = c.r[14];  // 0603AD7A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603AD7C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603AD7E mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0603AD80 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0603AD82 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0603AD84 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0603AD86 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0603AD88 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603AD8A rts ; mov.l @r15+,r8
}

void f_0603ADB0(SH2Context& c) {
    ran[887] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603ADB0 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0603ADB2 mov r15,r14
    c.r[1] = ld32(0x0603AE30u);  // 0603ADB4 mov.l 0x0603AE30,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603ADB6 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0603ADB8 extu.b r1,r1
    c.r[0] = c.r[1];  // 0603ADBA mov r1,r0
    c.r[0] >>= 2;  // 0603ADBC shlr2 r0
    c.r[0] >>= 2;  // 0603ADBE shlr2 r0
    c.r[0] >>= 2;  // 0603ADC0 shlr2 r0
    c.r[1] >>= 2;  // 0603ADC2 shlr2 r1
    c.r[1] >>= 2;  // 0603ADC4 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0603ADC6 shlr r1
    c.r[1] >>= 2;  // 0603ADC8 shlr2 r1
    c.r[0] &= 0x1u;  // 0603ADCA and #1,r0
    c.t = c.r[1] == c.r[0];  // 0603ADCC cmp/eq r0,r1
    { const bool k = c.t; c.r[6] = c.r[5]; if (k) { goto L_0603ADEE; } }  // 0603ADCE bt/s 0x0603ADEE ; mov r5,r6
    c.r[7] = ld32(0x0603AE34u);  // 0603ADD2 mov.l 0x0603AE34,r7
    c.r[3] = c.r[7];  // 0603ADD4 mov r7,r3
    c.r[0] = c.r[6];  // 0603ADD6 mov r6,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0]); c.r[0] += 1;  // 0603ADD8 mov.b @r0+,r2
    c.r[3] += 58;  // 0603ADDA add #58,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0603ADDC extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0603ADDE mov.b @r0,r1
    c.r[2] <<= 8;  // 0603ADE0 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603ADE2 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0603ADE4 or r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603AE2Cu);  // 0603ADE6 mov.w 0x0603AE2C,r1
    c.r[1] -= c.r[2];  // 0603ADE8 sub r2,r1
    st16(c.r[3], c.r[1]); goto L_0603AE04;  // 0603ADEA bra 0x0603AE04 ; mov.w r1,@r3
L_0603ADEE:
    c.r[7] = ld32(0x0603AE34u);  // 0603ADEE mov.l 0x0603AE34,r7
    c.r[3] = c.r[7];  // 0603ADF0 mov r7,r3
    c.r[0] = c.r[6];  // 0603ADF2 mov r6,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0]); c.r[0] += 1;  // 0603ADF4 mov.b @r0+,r2
    c.r[3] += 58;  // 0603ADF6 add #58,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0603ADF8 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0603ADFA mov.b @r0,r1
    c.r[2] <<= 8;  // 0603ADFC shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603ADFE extu.b r1,r1
    c.r[2] |= c.r[1];  // 0603AE00 or r1,r2
    st16(c.r[3], c.r[2]);  // 0603AE02 mov.w r2,@r3
L_0603AE04:
    c.r[1] = c.r[6];  // 0603AE04 mov r6,r1
    c.r[1] += 2;  // 0603AE06 add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603AE08 mov.b @r1,r2
    c.r[7] += 60;  // 0603AE0A add #60,r7
    c.r[2] = c.r[2] & 0xFFu;  // 0603AE0C extu.b r2,r2
    c.r[1] = c.r[6];  // 0603AE0E mov r6,r1
    c.r[1] += 3;  // 0603AE10 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603AE12 mov.b @r1,r1
    c.r[2] <<= 8;  // 0603AE14 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603AE16 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0603AE18 or r1,r2
    st16(c.r[7], c.r[2]);  // 0603AE1A mov.w r2,@r7
    c.r[2] = ld32(0x0603AE38u);  // 0603AE1C mov.l 0x0603AE38,r2
    c.r[6] += 4;  // 0603AE1E add #4,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]);  // 0603AE20 mov.b @r4,r1
    c.r[15] = c.r[14];  // 0603AE22 mov r14,r15
    st8(c.r[2], c.r[1]);  // 0603AE24 mov.b r1,@r2
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603AE26 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[6]; c.pc = x; return; }  // 0603AE28 rts ; mov r6,r0
}

void f_0603AE44(SH2Context& c) {
    ran[888] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603AE44 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603AE46 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0603AE48 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0603AE4A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0603AE4C mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0603AE4E mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603AE50 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603AE52 sts.l pr,@-r15
    c.r[15] -= 8;  // 0603AE54 add #-8,r15
    c.r[14] = c.r[15];  // 0603AE56 mov r15,r14
    st32(c.r[14], c.r[5]);  // 0603AE58 mov.l r5,@r14
    c.r[3] = c.r[4];  // 0603AE5A mov r4,r3
    c.r[1] = c.r[3];  // 0603AE5C mov r3,r1
    c.r[1] += 1;  // 0603AE5E add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603AE60 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0603AE62 mov r1,r0
    c.r[0] >>= 2;  // 0603AE64 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0603AE66 shlr r0
    c.r[0] &= 0x1u;  // 0603AE68 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603AE6A tst r0,r0
    if (c.t) { goto L_0603AE7A; }  // 0603AE6C bt 0x0603AE7A
    c.r[1] = ld32(c.r[3] + 4);  // 0603AE6E mov.l @(4,r3),r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0603AE70 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0603AE72 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0603AE74 shar r1
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[1]; goto L_0603AE80;  // 0603AE76 bra 0x0603AE80 ; exts.w r1,r1
L_0603AE7A:
    c.r[1] = c.r[3];  // 0603AE7A mov r3,r1
    c.r[1] += 6;  // 0603AE7C add #6,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0603AE7E mov.w @r1,r1
L_0603AE80:
    c.r[7] = c.r[1];  // 0603AE80 mov r1,r7
    c.r[1] = c.r[3];  // 0603AE82 mov r3,r1
    c.r[1] += 1;  // 0603AE84 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603AE86 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0603AE88 mov r1,r0
    c.r[0] >>= 2;  // 0603AE8A shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0603AE8C shlr r0
    c.r[0] &= 0x1u;  // 0603AE8E and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603AE90 tst r0,r0
    if (c.t) { goto L_0603AEA0; }  // 0603AE92 bt 0x0603AEA0
    c.r[1] = ld32(c.r[3] + 8);  // 0603AE94 mov.l @(8,r3),r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0603AE96 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0603AE98 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0603AE9A shar r1
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[1]; goto L_0603AEA6;  // 0603AE9C bra 0x0603AEA6 ; exts.w r1,r1
L_0603AEA0:
    c.r[1] = c.r[3];  // 0603AEA0 mov r3,r1
    c.r[1] += 10;  // 0603AEA2 add #10,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0603AEA4 mov.w @r1,r1
L_0603AEA6:
    c.r[13] = c.r[1];  // 0603AEA6 mov r1,r13
    c.r[3] += 1;  // 0603AEA8 add #1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0603AEAA mov.b @r3,r1
    c.r[0] = c.r[1];  // 0603AEAC mov r1,r0
    c.r[0] >>= 2;  // 0603AEAE shlr2 r0
    c.r[0] >>= 2;  // 0603AEB0 shlr2 r0
    c.r[0] &= 0x1u;  // 0603AEB2 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603AEB4 tst r0,r0
    { const bool k = c.t; c.r[4] += 65; if (k) { goto L_0603AF1C; } }  // 0603AEB6 bt/s 0x0603AF1C ; add #65,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]);  // 0603AEBA mov.b @r4,r1
    c.r[2] = ld32(0x0603AF8Cu);  // 0603AEBC mov.l 0x0603AF8C,r2
    c.r[2] = ld32(c.r[2]);  // 0603AEBE mov.l @r2,r2
    c.r[6] = c.r[1] & 0xFFu;  // 0603AEC0 extu.b r1,r6
    c.r[1] = 0x4Cu;  // 0603AEC2 mov #76,r1
L_0603AEC4:
    c.macl = c.r[6] * c.r[1];  // 0603AEC4 mul.l r1,r6
    c.r[3] = c.macl;  // 0603AEC6 sts macl,r3
    c.r[3] += c.r[2];  // 0603AEC8 add r2,r3
    c.r[1] = c.r[3];  // 0603AECA mov r3,r1
    c.r[1] += 1;  // 0603AECC add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603AECE mov.b @r1,r1
    c.r[0] = c.r[1];  // 0603AED0 mov r1,r0
    c.r[0] >>= 2;  // 0603AED2 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0603AED4 shlr r0
    c.r[0] &= 0x1u;  // 0603AED6 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603AED8 tst r0,r0
    { const bool k = c.t; c.r[1] = ld32(c.r[3] + 4); if (k) { goto L_0603AEE4; } }  // 0603AEDA bt/s 0x0603AEE4 ; mov.l @(4,r3),r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0603AEDE shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0603AEE0 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0603AEE2 shar r1
L_0603AEE4:
    c.r[7] += c.r[1];  // 0603AEE4 add r1,r7
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[7];  // 0603AEE6 exts.w r7,r1
    c.r[7] = c.r[1];  // 0603AEE8 mov r1,r7
    c.r[1] = c.r[3];  // 0603AEEA mov r3,r1
    c.r[1] += 1;  // 0603AEEC add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603AEEE mov.b @r1,r1
    c.r[0] = c.r[1];  // 0603AEF0 mov r1,r0
    c.r[0] >>= 2;  // 0603AEF2 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0603AEF4 shlr r0
    c.r[0] &= 0x1u;  // 0603AEF6 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603AEF8 tst r0,r0
    { const bool k = c.t; c.r[1] = ld32(c.r[3] + 8); if (k) { goto L_0603AF04; } }  // 0603AEFA bt/s 0x0603AF04 ; mov.l @(8,r3),r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0603AEFE shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0603AF00 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0603AF02 shar r1
L_0603AF04:
    c.r[13] += c.r[1];  // 0603AF04 add r1,r13
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[13];  // 0603AF06 exts.w r13,r1
    c.r[13] = c.r[1];  // 0603AF08 mov r1,r13
    c.r[3] += 1;  // 0603AF0A add #1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0603AF0C mov.b @r3,r1
    c.r[0] = c.r[1];  // 0603AF0E mov r1,r0
    c.r[0] >>= 2;  // 0603AF10 shlr2 r0
    c.r[0] >>= 2;  // 0603AF12 shlr2 r0
    c.r[0] &= 0x1u;  // 0603AF14 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603AF16 tst r0,r0
    { const bool k = !c.t; c.r[1] = 0x4Cu; if (k) { SH2_POLL(c); goto L_0603AEC4; } }  // 0603AF18 bf/s 0x0603AEC4 ; mov #76,r1
L_0603AF1C:
    c.r[10] = ld32(0x0603AF90u);  // 0603AF1C mov.l 0x0603AF90,r10
    c.r[1] = c.r[10];  // 0603AF1E mov r10,r1
    c.r[1] += 58;  // 0603AF20 add #58,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0603AF22 mov.w @r1,r4
    c.r[12] = ld32(0x0603AF94u);  // 0603AF24 mov.l 0x0603AF94,r12
    c.r[1] = c.r[10];  // 0603AF26 mov r10,r1
    c.r[1] += 60;  // 0603AF28 add #60,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0603AF2A mov.w @r1,r1
    c.r[4] -= c.r[7];  // 0603AF2C sub r7,r4
    { const uint32_t x = c.r[12]; c.pr = 0x0603AF32u; st32(c.r[14] + 4, c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603AF32u) return; }  // 0603AF2E jsr @r12 ; mov.l r1,@(4,r14)
    c.r[4] = c.r[0];  // 0603AF32 mov r0,r4
    c.r[5] = c.r[1];  // 0603AF34 mov r1,r5
    c.r[1] = ld32(0x0603AF98u);  // 0603AF36 mov.l 0x0603AF98,r1
    c.r[8] = ld32(c.r[1]);  // 0603AF38 mov.l @r1,r8
    c.r[9] = ld32(c.r[1] + 4);  // 0603AF3A mov.l @(4,r1),r9
    c.r[12] = ld32(0x0603AF9Cu);  // 0603AF3C mov.l 0x0603AF9C,r12
    c.r[6] = c.r[8];  // 0603AF3E mov r8,r6
    { const uint32_t x = c.r[12]; c.pr = 0x0603AF44u; c.r[7] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603AF44u) return; }  // 0603AF40 jsr @r12 ; mov r9,r7
    c.r[4] = c.r[0];  // 0603AF44 mov r0,r4
    c.r[11] = ld32(0x0603AFA0u);  // 0603AF46 mov.l 0x0603AFA0,r11
    { const uint32_t x = c.r[11]; c.pr = 0x0603AF4Cu; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603AF4Cu) return; }  // 0603AF48 jsr @r11 ; mov r1,r5
    c.r[12] = ld32(0x0603AFA4u);  // 0603AF4C mov.l 0x0603AFA4,r12
    st32(c.r[12], c.r[0]);  // 0603AF4E mov.l r0,@r12
    c.r[12] = ld32(c.r[14] + 4);  // 0603AF50 mov.l @(4,r14),r12
    c.r[10] += 120;  // 0603AF52 add #120,r10
    c.r[12] -= c.r[13];  // 0603AF54 sub r13,r12
    st32(c.r[14] + 4, c.r[12]);  // 0603AF56 mov.l r12,@(4,r14)
    c.r[12] = ld32(0x0603AF94u);  // 0603AF58 mov.l 0x0603AF94,r12
    { const uint32_t x = c.r[12]; c.pr = 0x0603AF5Eu; c.r[4] = ld32(c.r[14] + 4); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603AF5Eu) return; }  // 0603AF5A jsr @r12 ; mov.l @(4,r14),r4
    c.r[4] = c.r[0];  // 0603AF5E mov r0,r4
    c.r[5] = c.r[1];  // 0603AF60 mov r1,r5
    c.r[6] = c.r[8];  // 0603AF62 mov r8,r6
    c.r[12] = ld32(0x0603AF9Cu);  // 0603AF64 mov.l 0x0603AF9C,r12
    { const uint32_t x = c.r[12]; c.pr = 0x0603AF6Au; c.r[7] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603AF6Au) return; }  // 0603AF66 jsr @r12 ; mov r9,r7
    c.r[4] = c.r[0];  // 0603AF6A mov r0,r4
    { const uint32_t x = c.r[11]; c.pr = 0x0603AF70u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603AF70u) return; }  // 0603AF6C jsr @r11 ; mov r1,r5
    st32(c.r[10], c.r[0]);  // 0603AF70 mov.l r0,@r10
    c.r[0] = ld32(c.r[14]);  // 0603AF72 mov.l @r14,r0
    c.r[14] += 8;  // 0603AF74 add #8,r14
    c.r[15] = c.r[14];  // 0603AF76 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603AF78 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603AF7A mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0603AF7C mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0603AF7E mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0603AF80 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0603AF82 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0603AF84 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603AF86 rts ; mov.l @r15+,r8
}

void f_0603AFA8(SH2Context& c) {
    ran[889] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603AFA8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603AFAA mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603AFAC sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0603AFAE mov r15,r14
    c.r[1] = ld32(0x0603B030u);  // 0603AFB0 mov.l 0x0603B030,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603AFB2 mov.b @r1,r1
    c.r[8] = c.r[5];  // 0603AFB4 mov r5,r8
    c.r[5] = c.r[1] & 0xFFu;  // 0603AFB6 extu.b r1,r5
    c.r[1] = ld32(0x0603B034u);  // 0603AFB8 mov.l 0x0603B034,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603AFBA mov.b @r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0603B02Eu);  // 0603AFBC mov.w 0x0603B02E,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603AFBE extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 0603AFC0 cmp/eq r2,r1
    { const bool k = c.t; c.r[5] -= c.r[1]; if (k) { goto L_0603B022; } }  // 0603AFC2 bt/s 0x0603B022 ; sub r1,r5
    c.t = (c.r[5] & c.r[5]) == 0;  // 0603AFC6 tst r5,r5
    { const bool k = c.t; c.r[15] = c.r[14]; if (k) { goto L_0603B024; } }  // 0603AFC8 bt/s 0x0603B024 ; mov r14,r15
    c.r[1] = ld32(0x0603B038u);  // 0603AFCC mov.l 0x0603B038,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603AFCE mov.b @r1,r1
    c.r[0] = c.r[1];  // 0603AFD0 mov r1,r0
    c.r[0] >>= 2;  // 0603AFD2 shlr2 r0
    c.r[0] >>= 2;  // 0603AFD4 shlr2 r0
    c.r[0] >>= 2;  // 0603AFD6 shlr2 r0
    c.r[0] &= 0x1u;  // 0603AFD8 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603AFDA tst r0,r0
    if (c.t) { goto L_0603AFF0; }  // 0603AFDC bt 0x0603AFF0
    c.r[0] = ld32(0x0603B03Cu);  // 0603AFDE mov.l 0x0603B03C,r0
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[0]);  // 0603AFE0 mov.w @r0,r6
    c.r[7] = ld32(0x0603B040u);  // 0603AFE2 mov.l 0x0603B040,r7
    { const uint32_t x = c.r[7]; c.pr = 0x0603AFE8u; c.r[4] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603AFE8u) return; }  // 0603AFE4 jsr @r7 ; extu.w r6,r4
    c.r[7] = c.r[0];  // 0603AFE8 mov r0,r7
    c.r[0] = ld32(0x0603B03Cu);  // 0603AFEA mov.l 0x0603B03C,r0
    c.r[6] -= c.r[7]; goto L_0603B000;  // 0603AFEC bra 0x0603B000 ; sub r7,r6
L_0603AFF0:
    c.r[0] = ld32(0x0603B044u);  // 0603AFF0 mov.l 0x0603B044,r0
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[0]);  // 0603AFF2 mov.w @r0,r6
    c.r[7] = ld32(0x0603B040u);  // 0603AFF4 mov.l 0x0603B040,r7
    { const uint32_t x = c.r[7]; c.pr = 0x0603AFFAu; c.r[4] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603AFFAu) return; }  // 0603AFF6 jsr @r7 ; extu.w r6,r4
    c.r[7] = c.r[0];  // 0603AFFA mov r0,r7
    c.r[6] -= c.r[7];  // 0603AFFC sub r7,r6
    c.r[0] = ld32(0x0603B044u);  // 0603AFFE mov.l 0x0603B044,r0
L_0603B000:
    st16(c.r[0], c.r[6]);  // 0603B000 mov.w r6,@r0
    c.r[2] = ld32(0x0603B048u);  // 0603B002 mov.l 0x0603B048,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0603B004 mov.w @r2,r1
    c.r[3] = ld32(0x0603B034u);  // 0603B006 mov.l 0x0603B034,r3
    c.r[7] += c.r[1];  // 0603B008 add r1,r7
    st16(c.r[2], c.r[7]);  // 0603B00A mov.w r7,@r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0603B00C mov.b @r3,r2
    c.r[1] = ld32(0x0603B030u);  // 0603B00E mov.l 0x0603B030,r1
    c.r[2] += 1;  // 0603B010 add #1,r2
    st8(c.r[3], c.r[2]);  // 0603B012 mov.b r2,@r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603B014 mov.b @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0603B016 extu.b r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603B018 extu.b r1,r1
    c.t = c.r[2] == c.r[1];  // 0603B01A cmp/eq r1,r2
    { const bool k = !c.t; c.r[1] = 0xFFFFFFFFu; if (k) { goto L_0603B022; } }  // 0603B01C bf/s 0x0603B022 ; mov #-1,r1
    st8(c.r[3], c.r[1]);  // 0603B020 mov.b r1,@r3
L_0603B022:
    c.r[15] = c.r[14];  // 0603B022 mov r14,r15
L_0603B024:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603B024 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603B026 mov.l @r15+,r14
    c.r[0] = c.r[8];  // 0603B028 mov r8,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603B02A rts ; mov.l @r15+,r8
}

void f_0603B04C(SH2Context& c) {
    ran[890] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603B04C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603B04E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603B050 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0603B052 mov r15,r14
    c.r[1] = ld32(0x0603B0D4u);  // 0603B054 mov.l 0x0603B0D4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603B056 mov.b @r1,r1
    c.r[8] = c.r[5];  // 0603B058 mov r5,r8
    c.r[5] = c.r[1] & 0xFFu;  // 0603B05A extu.b r1,r5
    c.r[1] = ld32(0x0603B0D8u);  // 0603B05C mov.l 0x0603B0D8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603B05E mov.b @r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0603B0D2u);  // 0603B060 mov.w 0x0603B0D2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603B062 extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 0603B064 cmp/eq r2,r1
    { const bool k = c.t; c.r[5] -= c.r[1]; if (k) { goto L_0603B0C6; } }  // 0603B066 bt/s 0x0603B0C6 ; sub r1,r5
    c.t = (c.r[5] & c.r[5]) == 0;  // 0603B06A tst r5,r5
    { const bool k = c.t; c.r[15] = c.r[14]; if (k) { goto L_0603B0C8; } }  // 0603B06C bt/s 0x0603B0C8 ; mov r14,r15
    c.r[1] = ld32(0x0603B0DCu);  // 0603B070 mov.l 0x0603B0DC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603B072 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0603B074 mov r1,r0
    c.r[0] >>= 2;  // 0603B076 shlr2 r0
    c.r[0] >>= 2;  // 0603B078 shlr2 r0
    c.r[0] >>= 2;  // 0603B07A shlr2 r0
    c.r[0] &= 0x1u;  // 0603B07C and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603B07E tst r0,r0
    if (c.t) { goto L_0603B094; }  // 0603B080 bt 0x0603B094
    c.r[0] = ld32(0x0603B0E0u);  // 0603B082 mov.l 0x0603B0E0,r0
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[0]);  // 0603B084 mov.w @r0,r6
    c.r[7] = ld32(0x0603B0E4u);  // 0603B086 mov.l 0x0603B0E4,r7
    { const uint32_t x = c.r[7]; c.pr = 0x0603B08Cu; c.r[4] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603B08Cu) return; }  // 0603B088 jsr @r7 ; extu.w r6,r4
    c.r[7] = c.r[0];  // 0603B08C mov r0,r7
    c.r[0] = ld32(0x0603B0E0u);  // 0603B08E mov.l 0x0603B0E0,r0
    c.r[6] -= c.r[7]; goto L_0603B0A4;  // 0603B090 bra 0x0603B0A4 ; sub r7,r6
L_0603B094:
    c.r[0] = ld32(0x0603B0E8u);  // 0603B094 mov.l 0x0603B0E8,r0
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[0]);  // 0603B096 mov.w @r0,r6
    c.r[7] = ld32(0x0603B0E4u);  // 0603B098 mov.l 0x0603B0E4,r7
    { const uint32_t x = c.r[7]; c.pr = 0x0603B09Eu; c.r[4] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603B09Eu) return; }  // 0603B09A jsr @r7 ; extu.w r6,r4
    c.r[7] = c.r[0];  // 0603B09E mov r0,r7
    c.r[6] -= c.r[7];  // 0603B0A0 sub r7,r6
    c.r[0] = ld32(0x0603B0E8u);  // 0603B0A2 mov.l 0x0603B0E8,r0
L_0603B0A4:
    st16(c.r[0], c.r[6]);  // 0603B0A4 mov.w r6,@r0
    c.r[2] = ld32(0x0603B0ECu);  // 0603B0A6 mov.l 0x0603B0EC,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0603B0A8 mov.w @r2,r1
    c.r[3] = ld32(0x0603B0D8u);  // 0603B0AA mov.l 0x0603B0D8,r3
    c.r[7] += c.r[1];  // 0603B0AC add r1,r7
    st16(c.r[2], c.r[7]);  // 0603B0AE mov.w r7,@r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0603B0B0 mov.b @r3,r2
    c.r[1] = ld32(0x0603B0D4u);  // 0603B0B2 mov.l 0x0603B0D4,r1
    c.r[2] += 1;  // 0603B0B4 add #1,r2
    st8(c.r[3], c.r[2]);  // 0603B0B6 mov.b r2,@r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603B0B8 mov.b @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0603B0BA extu.b r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603B0BC extu.b r1,r1
    c.t = c.r[2] == c.r[1];  // 0603B0BE cmp/eq r1,r2
    { const bool k = !c.t; c.r[1] = 0xFFFFFFFFu; if (k) { goto L_0603B0C6; } }  // 0603B0C0 bf/s 0x0603B0C6 ; mov #-1,r1
    st8(c.r[3], c.r[1]);  // 0603B0C4 mov.b r1,@r3
L_0603B0C6:
    c.r[15] = c.r[14];  // 0603B0C6 mov r14,r15
L_0603B0C8:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603B0C8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603B0CA mov.l @r15+,r14
    c.r[0] = c.r[8];  // 0603B0CC mov r8,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603B0CE rts ; mov.l @r15+,r8
}

void f_0603B0F0(SH2Context& c) {
    ran[891] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603B0F0 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0603B0F2 mov r15,r14
    c.r[7] = ld32(0x0603B138u);  // 0603B0F4 mov.l 0x0603B138,r7
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[7]);  // 0603B0F6 mov.w @r7,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x0603B134u);  // 0603B0F8 mov.w 0x0603B134,r3
    c.r[2] = c.r[3] & 0xFFFFu;  // 0603B0FA extu.w r3,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 0603B0FC extu.w r1,r1
    c.t = c.r[1] == c.r[2];  // 0603B0FE cmp/eq r2,r1
    { const bool k = c.t; c.r[6] = c.r[5]; if (k) { goto L_0603B12C; } }  // 0603B100 bt/s 0x0603B12C ; mov r5,r6
    st16(c.r[7], c.r[3]);  // 0603B104 mov.w r3,@r7
    c.r[1] = ld32(0x0603B13Cu);  // 0603B106 mov.l 0x0603B13C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603B108 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0603B10A mov r1,r0
    c.r[0] >>= 2;  // 0603B10C shlr2 r0
    c.r[0] >>= 2;  // 0603B10E shlr2 r0
    c.r[0] >>= 2;  // 0603B110 shlr2 r0
    c.r[0] &= 0x1u;  // 0603B112 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603B114 tst r0,r0
    if (c.t) { goto L_0603B11E; }  // 0603B116 bt 0x0603B11E
    c.r[2] = ld32(0x0603B140u);  // 0603B118 mov.l 0x0603B140,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]); goto L_0603B122;  // 0603B11A bra 0x0603B122 ; mov.b @r2,r1
L_0603B11E:
    c.r[2] = ld32(0x0603B144u);  // 0603B11E mov.l 0x0603B144,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0603B120 mov.b @r2,r1
L_0603B122:
    c.r[3] = ld32(0x0603B148u);  // 0603B122 mov.l 0x0603B148,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0603B124 extu.b r1,r1
    st16(c.r[3], c.r[1]);  // 0603B126 mov.w r1,@r3
    c.r[1] = 0x0u;  // 0603B128 mov #0,r1
    st8(c.r[2], c.r[1]);  // 0603B12A mov.b r1,@r2
L_0603B12C:
    c.r[15] = c.r[14];  // 0603B12C mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603B12E mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[6]; c.pc = x; return; }  // 0603B130 rts ; mov r6,r0
}

void f_0603B14C(SH2Context& c) {
    ran[892] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603B14C mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0603B14E mov r15,r14
    c.r[0] = c.r[5];  // 0603B150 mov r5,r0
    c.r[2] = ld32(0x0603B15Cu);  // 0603B152 mov.l 0x0603B15C,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]); c.r[0] += 1;  // 0603B154 mov.b @r0+,r1
    st8(c.r[2], c.r[1]);  // 0603B156 mov.b r1,@r2
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603B158 rts ; mov.l @r15+,r14
}

void f_0603B160(SH2Context& c) {
    ran[893] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603B160 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0603B162 mov r15,r14
    c.r[7] = c.r[5];  // 0603B164 mov r5,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]); c.r[7] += 1;  // 0603B166 mov.b @r7+,r1
    c.r[2] = ld32(0x0603B180u);  // 0603B168 mov.l 0x0603B180,r2
    c.r[3] = c.r[1] & 0xFFu;  // 0603B16A extu.b r1,r3
    c.r[3] += c.r[3];  // 0603B16C add r3,r3
    c.r[0] = c.r[3];  // 0603B16E mov r3,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 0603B170 mov.w @(r0,r2),r1
    c.r[1] -= 1;  // 0603B172 add #-1,r1
    st16(c.r[0] + c.r[2], c.r[1]);  // 0603B174 mov.w r1,@(r0,r2)
    c.r[1] = c.r[7];  // 0603B176 mov r7,r1
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603B178 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[1]; c.pc = x; return; }  // 0603B17A rts ; mov r1,r0
}

void f_0603B184(SH2Context& c) {
    ran[894] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603B184 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0603B186 mov r15,r14
    c.r[7] = c.r[5];  // 0603B188 mov r5,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]); c.r[7] += 1;  // 0603B18A mov.b @r7+,r1
    c.r[2] = ld32(0x0603B1A4u);  // 0603B18C mov.l 0x0603B1A4,r2
    c.r[3] = c.r[1] & 0xFFu;  // 0603B18E extu.b r1,r3
    c.r[3] += c.r[3];  // 0603B190 add r3,r3
    c.r[0] = c.r[3];  // 0603B192 mov r3,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 0603B194 mov.w @(r0,r2),r1
    c.r[1] += 1;  // 0603B196 add #1,r1
    st16(c.r[0] + c.r[2], c.r[1]);  // 0603B198 mov.w r1,@(r0,r2)
    c.r[1] = c.r[7];  // 0603B19A mov r7,r1
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603B19C mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[1]; c.pc = x; return; }  // 0603B19E rts ; mov r1,r0
}

void f_0603B1A8(SH2Context& c) {
    ran[895] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603B1A8 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0603B1AA mov r15,r14
    c.r[3] = c.r[5];  // 0603B1AC mov r5,r3
    c.r[2] = ld32(0x0603B1C8u);  // 0603B1AE mov.l 0x0603B1C8,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0603B1B0 mov.b @r3,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0603B1B2 extu.b r1,r0
    c.r[0] += c.r[0];  // 0603B1B4 add r0,r0
    c.r[1] = c.r[3];  // 0603B1B6 mov r3,r1
    c.r[1] += 1;  // 0603B1B8 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603B1BA mov.b @r1,r1
    c.r[3] += 2;  // 0603B1BC add #2,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0603B1BE extu.b r1,r1
    st16(c.r[0] + c.r[2], c.r[1]);  // 0603B1C0 mov.w r1,@(r0,r2)
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603B1C2 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[3]; c.pc = x; return; }  // 0603B1C4 rts ; mov r3,r0
}

void f_0603B1CC(SH2Context& c) {
    ran[896] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603B1CC mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0603B1CE mov r15,r14
    c.r[2] = ld32(0x0603B1E0u);  // 0603B1D0 mov.l 0x0603B1E0,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603B1DCu);  // 0603B1D2 mov.w 0x0603B1DC,r1
    st16(c.r[2], c.r[1]);  // 0603B1D4 mov.w r1,@r2
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603B1D6 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[5]; c.pc = x; return; }  // 0603B1D8 rts ; mov r5,r0
}

void f_0603B1E4(SH2Context& c) {
    ran[897] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603B1E4 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0603B1E6 mov r15,r14
    c.r[1] = ld32(0x0603B29Cu);  // 0603B1E8 mov.l 0x0603B29C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603B1EA mov.b @r1,r1
    c.r[2] = ld32(0x0603B2A0u);  // 0603B1EC mov.l 0x0603B2A0,r2
    c.r[0] = c.r[1];  // 0603B1EE mov r1,r0
    c.r[0] >>= 2;  // 0603B1F0 shlr2 r0
    c.r[0] >>= 2;  // 0603B1F2 shlr2 r0
    c.r[0] >>= 2;  // 0603B1F4 shlr2 r0
    c.r[0] &= 0x1u;  // 0603B1F6 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603B1F8 tst r0,r0
    { const bool k = c.t; c.r[3] = c.r[5]; if (k) { goto L_0603B200; } }  // 0603B1FA bt/s 0x0603B200 ; mov r5,r3
    c.r[2] = ld32(0x0603B2A4u);  // 0603B1FE mov.l 0x0603B2A4,r2
L_0603B200:
    c.r[1] = c.r[2];  // 0603B200 mov r2,r1
    c.r[1] += 6;  // 0603B202 add #6,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0603B204 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0603B206 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603B208 tst r1,r1
    { const bool k = !c.t; c.t = (c.r[0] & c.r[0]) == 0; if (k) { goto L_0603B214; } }  // 0603B20A bf/s 0x0603B214 ; tst r0,r0
    c.r[2] = ld32(0x0603B2A8u);  // 0603B20E mov.l 0x0603B2A8,r2
    if (c.t) { goto L_0603B214; }  // 0603B210 bt 0x0603B214
    c.r[2] = ld32(0x0603B2ACu);  // 0603B212 mov.l 0x0603B2AC,r2
L_0603B214:
    c.r[1] = ld32(0x0603B29Cu);  // 0603B214 mov.l 0x0603B29C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603B216 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0603B218 mov r1,r0
    c.r[0] >>= 2;  // 0603B21A shlr2 r0
    c.r[0] >>= 2;  // 0603B21C shlr2 r0
    c.r[0] >>= 2;  // 0603B21E shlr2 r0
    c.r[0] &= 0x1u;  // 0603B220 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603B222 tst r0,r0
    c.r[1] = ld32(0x0603B2B0u);  // 0603B224 mov.l 0x0603B2B0,r1
    if (c.t) { goto L_0603B22A; }  // 0603B226 bt 0x0603B22A
    c.r[1] = ld32(0x0603B2B4u);  // 0603B228 mov.l 0x0603B2B4,r1
L_0603B22A:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603B22A mov.b @r1,r1
    c.r[0] = c.r[1];  // 0603B22C mov r1,r0
    c.r[0] >>= 2;  // 0603B22E shlr2 r0
    c.r[0] &= 0x3u;  // 0603B230 and #3,r0
    c.t = c.r[0] == 0x1u;  // 0603B232 cmp/eq #1,r0
    { const bool k = !c.t; c.r[2] += 10; if (k) { goto L_0603B276; } }  // 0603B234 bf/s 0x0603B276 ; add #10,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0603B238 mov.w @r2,r1
    c.r[0] = c.r[1] & 0xFFFFu;  // 0603B23A extu.w r1,r0
    c.t = c.r[0] == 0x1Cu;  // 0603B23C cmp/eq #28,r0
    { const bool k = c.t; c.r[1] = 0x1Cu; if (k) { goto L_0603B262; } }  // 0603B23E bt/s 0x0603B262 ; mov #28,r1
    c.t = (int32_t)c.r[0] > (int32_t)c.r[1];  // 0603B242 cmp/gt r1,r0
    { const bool k = c.t; c.t = c.r[0] == 0x19u; if (k) { goto L_0603B250; } }  // 0603B244 bt/s 0x0603B250 ; cmp/eq #25,r0
    { const bool k = c.t; c.r[4] += 56; if (k) { goto L_0603B25C; } }  // 0603B248 bt/s 0x0603B25C ; add #56,r4
    goto L_0603B26E;  // 0603B24C bra 0x0603B26E ; nop
L_0603B250:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603B290u);  // 0603B250 mov.w 0x0603B290,r1
    c.t = c.r[0] == c.r[1];  // 0603B252 cmp/eq r1,r0
    { const bool k = c.t; c.r[4] += 56; if (k) { goto L_0603B268; } }  // 0603B254 bt/s 0x0603B268 ; add #56,r4
    goto L_0603B26E;  // 0603B258 bra 0x0603B26E ; nop
L_0603B25C:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603B292u);  // 0603B25C mov.w 0x0603B292,r1
    st16(c.r[4], c.r[1]); goto L_0603B272;  // 0603B25E bra 0x0603B272 ; mov.w r1,@r4
L_0603B262:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603B294u);  // 0603B262 mov.w 0x0603B294,r1
    c.r[4] += 56; goto L_0603B270;  // 0603B264 bra 0x0603B270 ; add #56,r4
L_0603B268:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603B296u);  // 0603B268 mov.w 0x0603B296,r1
    st16(c.r[4], c.r[1]); goto L_0603B272;  // 0603B26A bra 0x0603B272 ; mov.w r1,@r4
L_0603B26E:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603B298u);  // 0603B26E mov.w 0x0603B298,r1
L_0603B270:
    st16(c.r[4], c.r[1]);  // 0603B270 mov.w r1,@r4
L_0603B272:
    c.r[3] += 2; goto L_0603B288;  // 0603B272 bra 0x0603B288 ; add #2,r3
L_0603B276:
    c.r[0] = c.r[3];  // 0603B276 mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0]); c.r[0] += 1;  // 0603B278 mov.b @r0+,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0603B27A extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0603B27C mov.b @r0,r1
    c.r[2] <<= 8;  // 0603B27E shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603B280 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0603B282 or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0603B284 exts.w r2,r2
    c.r[3] += c.r[2];  // 0603B286 add r2,r3
L_0603B288:
    c.r[15] = c.r[14];  // 0603B288 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603B28A mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[3]; c.pc = x; return; }  // 0603B28C rts ; mov r3,r0
}

void f_0603B2B8(SH2Context& c) {
    ran[898] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603B2B8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603B2BA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0603B2BC mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603B2BE sts.l pr,@-r15
    c.r[9] = c.r[4];  // 0603B2C0 mov r4,r9
    c.r[10] = c.r[5];  // 0603B2C2 mov r5,r10
    c.r[1] = ld32(0x0603B3C8u);  // 0603B2C4 mov.l 0x0603B3C8,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603B2C6 mov.b @r1,r0
    c.t = (c.r[0] & 0x40u) == 0;  // 0603B2C8 tst #64,r0
    c.r[3] = ld32(0x0603B3CCu);  // 0603B2CA mov.l 0x0603B3CC,r3
    c.r[4] = ld32(0x0603B3D0u);  // 0603B2CC mov.l 0x0603B3D0,r4
    if (c.t) { goto L_0603B2D4; }  // 0603B2CE bt 0x0603B2D4
    c.r[3] += 32;  // 0603B2D0 add #32,r3
    c.r[4] = ld32(0x0603B3D4u);  // 0603B2D2 mov.l 0x0603B3D4,r4
L_0603B2D4:
    c.r[1] = c.r[3];  // 0603B2D4 mov r3,r1
    c.r[1] += 6;  // 0603B2D6 add #6,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0603B2D8 mov.w @r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603B2DA tst r1,r1
    if (!c.t) { goto L_0603B2E0; }  // 0603B2DC bf 0x0603B2E0
    c.r[3] += 64;  // 0603B2DE add #64,r3
L_0603B2E0:
    c.r[6] = 0x0u;  // 0603B2E0 mov #0,r6
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4]);  // 0603B2E2 mov.b @r4,r0
    c.t = (c.r[0] & 0x20u) == 0;  // 0603B2E4 tst #32,r0
    if (c.t) { goto L_0603B2EA; }  // 0603B2E6 bt 0x0603B2EA
    c.r[6] = ld32(0x0603B3D8u);  // 0603B2E8 mov.l 0x0603B3D8,r6
L_0603B2EA:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0603B2EA mov.b @r3,r1
    c.r[0] = c.r[1];  // 0603B2EC mov r1,r0
    c.r[0] &= 0x3u;  // 0603B2EE and #3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603B2F0 tst r0,r0
    if (c.t) { goto L_0603B30C; }  // 0603B2F2 bt 0x0603B30C
    c.t = c.r[0] == 0x1u;  // 0603B2F4 cmp/eq #1,r0
    if (c.t) { goto L_0603B300; }  // 0603B2F6 bt 0x0603B300
    c.t = c.r[0] == 0x2u;  // 0603B2F8 cmp/eq #2,r0
    if (c.t) { goto L_0603B306; }  // 0603B2FA bt 0x0603B306
    goto L_0603B330;  // 0603B2FC bra 0x0603B330 ; nop
L_0603B300:
    c.r[6] = ld32(0x0603B3DCu);  // 0603B300 mov.l 0x0603B3DC,r6
    goto L_0603B330;  // 0603B302 bra 0x0603B330 ; nop
L_0603B306:
    c.r[6] = ld32(0x0603B3E0u);  // 0603B306 mov.l 0x0603B3E0,r6
    goto L_0603B330;  // 0603B308 bra 0x0603B330 ; nop
L_0603B30C:
    c.r[0] = c.r[1];  // 0603B30C mov r1,r0
    c.r[0] >>= 2;  // 0603B30E shlr2 r0
    c.r[0] &= 0x7u;  // 0603B310 and #7,r0
    c.t = c.r[0] == 0x1u;  // 0603B312 cmp/eq #1,r0
    if (c.t) { goto L_0603B322; }  // 0603B314 bt 0x0603B322
    c.t = c.r[0] == 0x2u;  // 0603B316 cmp/eq #2,r0
    if (c.t) { goto L_0603B328; }  // 0603B318 bt 0x0603B328
    c.t = c.r[0] == 0x3u;  // 0603B31A cmp/eq #3,r0
    if (c.t) { goto L_0603B32E; }  // 0603B31C bt 0x0603B32E
    goto L_0603B330;  // 0603B31E bra 0x0603B330 ; nop
L_0603B322:
    c.r[6] = ld32(0x0603B3E4u);  // 0603B322 mov.l 0x0603B3E4,r6
    goto L_0603B330;  // 0603B324 bra 0x0603B330 ; nop
L_0603B328:
    c.r[6] = ld32(0x0603B3E8u);  // 0603B328 mov.l 0x0603B3E8,r6
    goto L_0603B330;  // 0603B32A bra 0x0603B330 ; nop
L_0603B32E:
    c.r[6] = ld32(0x0603B3ECu);  // 0603B32E mov.l 0x0603B3EC,r6
L_0603B330:
    c.r[1] = c.r[9];  // 0603B330 mov r9,r1
    c.r[1] += 56;  // 0603B332 add #56,r1
    st16(c.r[1], c.r[6]);  // 0603B334 mov.w r6,@r1
    c.r[4] += 2;  // 0603B336 add #2,r4
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[4]);  // 0603B338 mov.w @r4,r4
    c.r[4] = c.r[4] & 0xFFFFu;  // 0603B33A extu.w r4,r4
    c.t = (c.r[6] & c.r[6]) == 0;  // 0603B33C tst r6,r6
    if (c.t) { goto L_0603B38C; }  // 0603B33E bt 0x0603B38C
    c.t = (c.r[4] & c.r[4]) == 0;  // 0603B340 tst r4,r4
    if (c.t) { goto L_0603B37A; }  // 0603B342 bt 0x0603B37A
    c.r[8] = ld32(0x0603B3F0u);  // 0603B344 mov.l 0x0603B3F0,r8
    c.r[0] = ld32(0x0603B3F4u);  // 0603B346 mov.l 0x0603B3F4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0603B34Cu; c.r[5] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603B34Cu) return; }  // 0603B348 jsr @r0 ; mov r8,r5
    c.r[8] -= 1;  // 0603B34C add #-1,r8
    c.r[2] = c.r[0];  // 0603B34E mov r0,r2
    c.r[1] = c.r[9];  // 0603B350 mov r9,r1
    c.r[1] += 56;  // 0603B352 add #56,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0603B354 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0603B356 extu.b r1,r1
    c.r[1] -= 4;  // 0603B358 add #-4,r1
    c.r[3] = ld32(0x0603B3F8u);  // 0603B35A mov.l 0x0603B3F8,r3
    c.r[0] = c.r[1];  // 0603B35C mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0603B35E mov.b @(r0,r3),r1
    c.r[1] |= c.r[2];  // 0603B360 or r2,r1
    st8(c.r[8], c.r[1]);  // 0603B362 mov.b r1,@r8
    c.r[0] = c.r[2];  // 0603B364 mov r2,r0
    c.r[0] <<= 2;  // 0603B366 shll2 r0
    c.r[0] += c.r[0];  // 0603B368 add r0,r0
    c.r[0] <<= 2;  // 0603B36A shll2 r0
    c.r[0] += 48;  // 0603B36C add #48,r0
    c.r[1] = ld32(c.r[9] + 4);  // 0603B36E mov.l @(4,r9),r1
    c.r[1] -= c.r[0];  // 0603B370 sub r0,r1
    st32(c.r[9] + 4, c.r[1]);  // 0603B372 mov.l r1,@(4,r9)
    c.r[10] += 2;  // 0603B374 add #2,r10
    goto L_0603B3A8;  // 0603B376 bra 0x0603B3A8 ; nop
L_0603B37A:
    c.r[8] = ld32(0x0603B3FCu);  // 0603B37A mov.l 0x0603B3FC,r8
    c.r[0] = 0x0u;  // 0603B37C mov #0,r0
    st8(c.r[8], c.r[0]);  // 0603B37E mov.b r0,@r8
    c.r[1] = ld32(c.r[9] + 4);  // 0603B380 mov.l @(4,r9),r1
    c.r[1] -= 32;  // 0603B382 add #-32,r1
    st32(c.r[9] + 4, c.r[1]);  // 0603B384 mov.l r1,@(4,r9)
    c.r[10] += 4;  // 0603B386 add #4,r10
    goto L_0603B3BA;  // 0603B388 bra 0x0603B3BA ; nop
L_0603B38C:
    c.r[8] = ld32(0x0603B3F0u);  // 0603B38C mov.l 0x0603B3F0,r8
    c.r[0] = ld32(0x0603B3F4u);  // 0603B38E mov.l 0x0603B3F4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0603B394u; c.r[5] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603B394u) return; }  // 0603B390 jsr @r0 ; mov r8,r5
    c.r[8] -= 1;  // 0603B394 add #-1,r8
    st8(c.r[8], c.r[0]);  // 0603B396 mov.b r0,@r8
    c.r[2] = c.r[0] & 0xFFu;  // 0603B398 extu.b r0,r2
    c.r[2] <<= 2;  // 0603B39A shll2 r2
    c.r[2] += 36;  // 0603B39C add #36,r2
    c.r[2] <<= 2;  // 0603B39E shll2 r2
    c.r[2] += c.r[2];  // 0603B3A0 add r2,r2
    c.r[1] = ld32(c.r[9] + 4);  // 0603B3A2 mov.l @(4,r9),r1
    c.r[1] -= c.r[2];  // 0603B3A4 sub r2,r1
    st32(c.r[9] + 4, c.r[1]);  // 0603B3A6 mov.l r1,@(4,r9)
L_0603B3A8:
    c.r[0] = c.r[10];  // 0603B3A8 mov r10,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0]); c.r[0] += 1;  // 0603B3AA mov.b @r0+,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0603B3AC extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0603B3AE mov.b @r0,r1
    c.r[2] <<= 8;  // 0603B3B0 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603B3B2 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0603B3B4 or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0603B3B6 exts.w r2,r2
    c.r[10] += c.r[2];  // 0603B3B8 add r2,r10
L_0603B3BA:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603B3BA lds.l @r15+,pr
    c.r[0] = c.r[10];  // 0603B3BC mov r10,r0
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0603B3BE mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0603B3C0 mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0603B3C2 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0603B3C4 rts ; nop
}

void f_0603B460(SH2Context& c) {
    ran[899] = 1;
    c.r[3] = ld32(0x0603B4ACu);  // 0603B460 mov.l 0x0603B4AC,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0603B462 mov.b @r3,r1
    c.r[0] = c.r[1];  // 0603B464 mov r1,r0
    c.r[0] &= 0x7u;  // 0603B466 and #7,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[5]);  // 0603B468 mov.b @r5,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0603B46A extu.b r2,r2
    c.t = c.r[0] > c.r[2];  // 0603B46C cmp/hi r2,r0
    if (!c.t) { goto L_0603B490; }  // 0603B46E bf 0x0603B490
    c.r[0] -= c.r[2];  // 0603B470 sub r2,r0
    c.r[2] = 0xFFFFFFF8u;  // 0603B472 mov #-8,r2
    c.r[1] &= c.r[2];  // 0603B474 and r2,r1
    c.t = c.r[1] >> 31; c.r[1] <<= 1;  // 0603B476 shll r1
    c.r[6] = ld32(c.r[4] + 4);  // 0603B478 mov.l @(4,r4),r6
    c.r[6] += c.r[1];  // 0603B47A add r1,r6
    st32(c.r[4] + 4, c.r[6]);  // 0603B47C mov.l r6,@(4,r4)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0603B47E mov.b @(r0,r3),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0603B480 extu.b r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0603B4AAu);  // 0603B482 mov.w 0x0603B4AA,r2
    c.r[1] += c.r[2];  // 0603B484 add r2,r1
    c.r[4] += 56;  // 0603B486 add #56,r4
    st16(c.r[4], c.r[1]);  // 0603B488 mov.w r1,@r4
    c.r[0] = c.r[5];  // 0603B48A mov r5,r0
    { const uint32_t x = c.pr; c.r[0] += 3; c.pc = x; return; }  // 0603B48C rts ; add #3,r0
L_0603B490:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[5] + 1);  // 0603B490 mov.b @(1,r5),r0
    c.r[0] = c.r[0] & 0xFFu;  // 0603B492 extu.b r0,r0
    c.r[0] <<= 8;  // 0603B494 shll8 r0
    c.r[2] = c.r[0];  // 0603B496 mov r0,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[5] + 2);  // 0603B498 mov.b @(2,r5),r0
    c.r[0] = c.r[0] & 0xFFu;  // 0603B49A extu.b r0,r0
    c.r[0] |= c.r[2];  // 0603B49C or r2,r0
    c.r[0] += 1;  // 0603B49E add #1,r0
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 0603B4A0 exts.w r0,r0
    c.r[0] += c.r[5];  // 0603B4A2 add r5,r0
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0603B4A4 rts ; nop
}

void f_0603B4B0(SH2Context& c) {
    ran[900] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603B4B0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603B4B2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0603B4B4 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0603B4B6 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603B4B8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603B4BA sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0603B4BC mov r15,r14
    c.r[8] = c.r[4];  // 0603B4BE mov r4,r8
    c.r[10] = c.r[8];  // 0603B4C0 mov r8,r10
    c.r[10] += 54;  // 0603B4C2 add #54,r10
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[10]);  // 0603B4C4 mov.w @r10,r1
    c.r[9] = c.r[1] & 0xFFFFu;  // 0603B4C6 extu.w r1,r9
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603B55Au);  // 0603B4C8 mov.w 0x0603B55A,r1
    c.t = c.r[9] == c.r[1];  // 0603B4CA cmp/eq r1,r9
    { const bool k = !c.t; c.r[11] = c.r[5]; if (k) { goto L_0603B548; } }  // 0603B4CC bf/s 0x0603B548 ; mov r5,r11
    c.r[0] = ld32(0x0603B560u);  // 0603B4D0 mov.l 0x0603B560,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0603B4D6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603B4D6u) return; }  // 0603B4D2 jsr @r0 ; nop
    c.r[0] = c.r[0] & 0xFFu;  // 0603B4D6 extu.b r0,r0
    c.r[1] = c.r[0] & 0xFFFFu;  // 0603B4D8 extu.w r0,r1
    c.t = c.r[1] == c.r[9];  // 0603B4DA cmp/eq r9,r1
    { const bool k = !c.t; st16(c.r[10], c.r[0]); if (k) { goto L_0603B4EC; } }  // 0603B4DC bf/s 0x0603B4EC ; mov.w r0,@r10
    c.r[1] = ld32(0x0603B564u);  // 0603B4E0 mov.l 0x0603B564,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0603B4E2 mov.w @r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0603B55Cu);  // 0603B4E4 mov.w 0x0603B55C,r3
    c.r[2] &= c.r[3];  // 0603B4E6 and r3,r2
    st16(c.r[1], c.r[2]); goto L_0603B548;  // 0603B4E8 bra 0x0603B548 ; mov.w r2,@r1
L_0603B4EC:
    c.r[1] = 0x2Cu;  // 0603B4EC mov #44,r1
    c.macl = (c.r[0] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 0603B4EE mulu.w r1,r0
    c.r[3] = c.macl;  // 0603B4F0 sts macl,r3
    c.r[1] = ld32(0x0603B568u);  // 0603B4F2 mov.l 0x0603B568,r1
    c.r[3] += c.r[1];  // 0603B4F4 add r1,r3
    c.r[1] = c.r[8];  // 0603B4F6 mov r8,r1
    c.r[1] += 1;  // 0603B4F8 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603B4FA mov.b @r1,r1
    c.r[0] = c.r[1];  // 0603B4FC mov r1,r0
    c.r[0] >>= 2;  // 0603B4FE shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0603B500 shlr r0
    c.r[0] &= 0x1u;  // 0603B502 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603B504 tst r0,r0
    { const bool k = c.t; c.r[2] = c.r[3]; if (k) { goto L_0603B524; } }  // 0603B506 bt/s 0x0603B524 ; mov r3,r2
    c.r[1] = ld32(c.r[8] + 4);  // 0603B50A mov.l @(4,r8),r1
    c.r[2] += 12;  // 0603B50C add #12,r2
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0603B50E shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0603B510 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0603B512 shar r1
    st16(c.r[2], c.r[1]);  // 0603B514 mov.w r1,@r2
    c.r[2] = c.r[3];  // 0603B516 mov r3,r2
    c.r[1] = ld32(c.r[8] + 8);  // 0603B518 mov.l @(8,r8),r1
    c.r[2] += 14;  // 0603B51A add #14,r2
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0603B51C shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0603B51E shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1); goto L_0603B536;  // 0603B520 bra 0x0603B536 ; shar r1
L_0603B524:
    c.r[2] += 12;  // 0603B524 add #12,r2
    c.r[1] = c.r[8];  // 0603B526 mov r8,r1
    c.r[1] += 6;  // 0603B528 add #6,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0603B52A mov.w @r1,r1
    c.r[8] += 10;  // 0603B52C add #10,r8
    st16(c.r[2], c.r[1]);  // 0603B52E mov.w r1,@r2
    c.r[2] = c.r[3];  // 0603B530 mov r3,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[8]);  // 0603B532 mov.w @r8,r1
    c.r[2] += 14;  // 0603B534 add #14,r2
L_0603B536:
    st16(c.r[2], c.r[1]);  // 0603B536 mov.w r1,@r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0603B538 mov.b @r3,r0
    c.r[1] = ld32(0x0603B564u);  // 0603B53A mov.l 0x0603B564,r1
    c.r[0] &= 0xFDu;  // 0603B53C and #253,r0
    c.r[0] |= 0x61u;  // 0603B53E or #97,r0
    st8(c.r[3], c.r[0]);  // 0603B540 mov.b r0,@r3
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0603B542 mov.w @r1,r0
    c.r[0] |= 0x20u;  // 0603B544 or #32,r0
    st16(c.r[1], c.r[0]);  // 0603B546 mov.w r0,@r1
L_0603B548:
    c.r[15] = c.r[14];  // 0603B548 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603B54A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603B54C mov.l @r15+,r14
    c.r[0] = c.r[11];  // 0603B54E mov r11,r0
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0603B550 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0603B552 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0603B554 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603B556 rts ; mov.l @r15+,r8
}

void f_0603B56C(SH2Context& c) {
    ran[901] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603B56C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603B56E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603B570 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603B572 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0603B574 mov r15,r14
    c.r[9] = c.r[5];  // 0603B576 mov r5,r9
    c.r[8] = c.r[4];  // 0603B578 mov r4,r8
    c.r[8] += 54;  // 0603B57A add #54,r8
    c.r[4] += 55;  // 0603B57C add #55,r4
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[4]);  // 0603B57E mov.b @r4,r4
    c.r[1] = ld32(0x0603B59Cu);  // 0603B580 mov.l 0x0603B59C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603B586u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603B586u) return; }  // 0603B582 jsr @r1 ; extu.b r4,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603B598u);  // 0603B586 mov.w 0x0603B598,r1
    st16(c.r[8], c.r[1]);  // 0603B588 mov.w r1,@r8
    c.r[15] = c.r[14];  // 0603B58A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603B58C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603B58E mov.l @r15+,r14
    c.r[0] = c.r[9];  // 0603B590 mov r9,r0
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0603B592 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603B594 rts ; mov.l @r15+,r8
}

void f_0603B5A0(SH2Context& c) {
    ran[902] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603B5A0 mov.l r14,@-r15
    c.r[4] += 54;  // 0603B5A2 add #54,r4
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[4]);  // 0603B5A4 mov.w @r4,r2
    c.r[1] = 0x2Cu;  // 0603B5A6 mov #44,r1
    c.macl = (c.r[2] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 0603B5A8 mulu.w r1,r2
    c.r[7] = c.macl;  // 0603B5AA sts macl,r7
    c.r[1] = ld32(0x0603B63Cu);  // 0603B5AC mov.l 0x0603B63C,r1
    c.r[7] += c.r[1];  // 0603B5AE add r1,r7
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0603B5B0 mov.b @r7,r0
    c.r[1] = c.r[7];  // 0603B5B2 mov r7,r1
    c.r[0] &= 0xF3u;  // 0603B5B4 and #243,r0
    c.r[0] |= 0x4u;  // 0603B5B6 or #4,r0
    st8(c.r[7], c.r[0]);  // 0603B5B8 mov.b r0,@r7
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[5]);  // 0603B5BA mov.b @r5,r2
    c.r[1] += 34;  // 0603B5BC add #34,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0603B5BE mov.w @r1,r1
    c.r[1] += c.r[2];  // 0603B5C0 add r2,r1
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 0603B5C2 exts.w r1,r1
    c.t = (int32_t)c.r[1] >= 0;  // 0603B5C4 cmp/pz r1
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0603B5DC; } }  // 0603B5C6 bf/s 0x0603B5DC ; mov r15,r14
    c.r[3] = c.r[1];  // 0603B5CA mov r1,r3
    c.r[6] = (uint32_t)(int16_t)ld16(0x0603B636u);  // 0603B5CC mov.w 0x0603B636,r6
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[3];  // 0603B5CE exts.w r3,r2
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[6];  // 0603B5D0 exts.w r6,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0603B5D2 cmp/gt r1,r2
    if (!c.t) { goto L_0603B5D8; }  // 0603B5D4 bf 0x0603B5D8
    c.r[3] = c.r[6];  // 0603B5D6 mov r6,r3
L_0603B5D8:
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[3]; goto L_0603B5DE;  // 0603B5D8 bra 0x0603B5DE ; exts.w r3,r1
L_0603B5DC:
    c.r[1] = 0x0u;  // 0603B5DC mov #0,r1
L_0603B5DE:
    st32(c.r[7] + 32, c.r[1]);  // 0603B5DE mov.l r1,@(32,r7)
    c.r[1] = c.r[7];  // 0603B5E0 mov r7,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[5]);  // 0603B5E2 mov.b @r5,r2
    c.r[1] += 38;  // 0603B5E4 add #38,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0603B5E6 mov.w @r1,r1
    c.r[1] += c.r[2];  // 0603B5E8 add r2,r1
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 0603B5EA exts.w r1,r1
    c.t = (int32_t)c.r[1] >= 0;  // 0603B5EC cmp/pz r1
    { const bool k = !c.t; c.r[3] = c.r[1]; if (k) { goto L_0603B602; } }  // 0603B5EE bf/s 0x0603B602 ; mov r1,r3
    c.r[6] = (uint32_t)(int16_t)ld16(0x0603B638u);  // 0603B5F2 mov.w 0x0603B638,r6
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[3];  // 0603B5F4 exts.w r3,r2
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[6];  // 0603B5F6 exts.w r6,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0603B5F8 cmp/gt r1,r2
    if (!c.t) { goto L_0603B5FE; }  // 0603B5FA bf 0x0603B5FE
    c.r[3] = c.r[6];  // 0603B5FC mov r6,r3
L_0603B5FE:
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[3]; goto L_0603B604;  // 0603B5FE bra 0x0603B604 ; exts.w r3,r1
L_0603B602:
    c.r[1] = 0x0u;  // 0603B602 mov #0,r1
L_0603B604:
    st32(c.r[7] + 36, c.r[1]);  // 0603B604 mov.l r1,@(36,r7)
    c.r[1] = c.r[7];  // 0603B606 mov r7,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[5]);  // 0603B608 mov.b @r5,r2
    c.r[1] += 42;  // 0603B60A add #42,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0603B60C mov.w @r1,r1
    c.r[1] += c.r[2];  // 0603B60E add r2,r1
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 0603B610 exts.w r1,r1
    c.t = (int32_t)c.r[1] >= 0;  // 0603B612 cmp/pz r1
    { const bool k = !c.t; c.r[3] = c.r[1]; if (k) { goto L_0603B628; } }  // 0603B614 bf/s 0x0603B628 ; mov r1,r3
    c.r[6] = (uint32_t)(int16_t)ld16(0x0603B638u);  // 0603B618 mov.w 0x0603B638,r6
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[3];  // 0603B61A exts.w r3,r2
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[6];  // 0603B61C exts.w r6,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0603B61E cmp/gt r1,r2
    if (!c.t) { goto L_0603B624; }  // 0603B620 bf 0x0603B624
    c.r[3] = c.r[6];  // 0603B622 mov r6,r3
L_0603B624:
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[3]; goto L_0603B62A;  // 0603B624 bra 0x0603B62A ; exts.w r3,r1
L_0603B628:
    c.r[1] = 0x0u;  // 0603B628 mov #0,r1
L_0603B62A:
    st32(c.r[7] + 40, c.r[1]);  // 0603B62A mov.l r1,@(40,r7)
    c.r[5] += 1;  // 0603B62C add #1,r5
    c.r[15] = c.r[14];  // 0603B62E mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603B630 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[5]; c.pc = x; return; }  // 0603B632 rts ; mov r5,r0
}

void f_0603B640(SH2Context& c) {
    ran[903] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603B640 mov.l r14,@-r15
    c.r[4] += 54;  // 0603B642 add #54,r4
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[4]);  // 0603B644 mov.w @r4,r2
    c.r[1] = 0x2Cu;  // 0603B646 mov #44,r1
    c.macl = (c.r[2] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 0603B648 mulu.w r1,r2
    c.r[7] = c.macl;  // 0603B64A sts macl,r7
    c.r[1] = ld32(0x0603B6DCu);  // 0603B64C mov.l 0x0603B6DC,r1
    c.r[7] += c.r[1];  // 0603B64E add r1,r7
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0603B650 mov.b @r7,r0
    c.r[1] = c.r[7];  // 0603B652 mov r7,r1
    c.r[0] &= 0xF3u;  // 0603B654 and #243,r0
    c.r[0] |= 0x8u;  // 0603B656 or #8,r0
    st8(c.r[7], c.r[0]);  // 0603B658 mov.b r0,@r7
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[5]);  // 0603B65A mov.b @r5,r2
    c.r[1] += 34;  // 0603B65C add #34,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0603B65E mov.w @r1,r1
    c.r[1] += c.r[2];  // 0603B660 add r2,r1
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 0603B662 exts.w r1,r1
    c.t = (int32_t)c.r[1] >= 0;  // 0603B664 cmp/pz r1
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0603B67C; } }  // 0603B666 bf/s 0x0603B67C ; mov r15,r14
    c.r[3] = c.r[1];  // 0603B66A mov r1,r3
    c.r[6] = (uint32_t)(int16_t)ld16(0x0603B6D6u);  // 0603B66C mov.w 0x0603B6D6,r6
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[3];  // 0603B66E exts.w r3,r2
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[6];  // 0603B670 exts.w r6,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0603B672 cmp/gt r1,r2
    if (!c.t) { goto L_0603B678; }  // 0603B674 bf 0x0603B678
    c.r[3] = c.r[6];  // 0603B676 mov r6,r3
L_0603B678:
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[3]; goto L_0603B67E;  // 0603B678 bra 0x0603B67E ; exts.w r3,r1
L_0603B67C:
    c.r[1] = 0x0u;  // 0603B67C mov #0,r1
L_0603B67E:
    st32(c.r[7] + 32, c.r[1]);  // 0603B67E mov.l r1,@(32,r7)
    c.r[1] = c.r[7];  // 0603B680 mov r7,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[5]);  // 0603B682 mov.b @r5,r2
    c.r[1] += 38;  // 0603B684 add #38,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0603B686 mov.w @r1,r1
    c.r[1] += c.r[2];  // 0603B688 add r2,r1
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 0603B68A exts.w r1,r1
    c.t = (int32_t)c.r[1] >= 0;  // 0603B68C cmp/pz r1
    { const bool k = !c.t; c.r[3] = c.r[1]; if (k) { goto L_0603B6A2; } }  // 0603B68E bf/s 0x0603B6A2 ; mov r1,r3
    c.r[6] = (uint32_t)(int16_t)ld16(0x0603B6D8u);  // 0603B692 mov.w 0x0603B6D8,r6
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[3];  // 0603B694 exts.w r3,r2
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[6];  // 0603B696 exts.w r6,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0603B698 cmp/gt r1,r2
    if (!c.t) { goto L_0603B69E; }  // 0603B69A bf 0x0603B69E
    c.r[3] = c.r[6];  // 0603B69C mov r6,r3
L_0603B69E:
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[3]; goto L_0603B6A4;  // 0603B69E bra 0x0603B6A4 ; exts.w r3,r1
L_0603B6A2:
    c.r[1] = 0x0u;  // 0603B6A2 mov #0,r1
L_0603B6A4:
    st32(c.r[7] + 36, c.r[1]);  // 0603B6A4 mov.l r1,@(36,r7)
    c.r[1] = c.r[7];  // 0603B6A6 mov r7,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[5]);  // 0603B6A8 mov.b @r5,r2
    c.r[1] += 42;  // 0603B6AA add #42,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0603B6AC mov.w @r1,r1
    c.r[1] += c.r[2];  // 0603B6AE add r2,r1
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 0603B6B0 exts.w r1,r1
    c.t = (int32_t)c.r[1] >= 0;  // 0603B6B2 cmp/pz r1
    { const bool k = !c.t; c.r[3] = c.r[1]; if (k) { goto L_0603B6C8; } }  // 0603B6B4 bf/s 0x0603B6C8 ; mov r1,r3
    c.r[6] = (uint32_t)(int16_t)ld16(0x0603B6D8u);  // 0603B6B8 mov.w 0x0603B6D8,r6
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[3];  // 0603B6BA exts.w r3,r2
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[6];  // 0603B6BC exts.w r6,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0603B6BE cmp/gt r1,r2
    if (!c.t) { goto L_0603B6C4; }  // 0603B6C0 bf 0x0603B6C4
    c.r[3] = c.r[6];  // 0603B6C2 mov r6,r3
L_0603B6C4:
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[3]; goto L_0603B6CA;  // 0603B6C4 bra 0x0603B6CA ; exts.w r3,r1
L_0603B6C8:
    c.r[1] = 0x0u;  // 0603B6C8 mov #0,r1
L_0603B6CA:
    st32(c.r[7] + 40, c.r[1]);  // 0603B6CA mov.l r1,@(40,r7)
    c.r[5] += 1;  // 0603B6CC add #1,r5
    c.r[15] = c.r[14];  // 0603B6CE mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603B6D0 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[5]; c.pc = x; return; }  // 0603B6D2 rts ; mov r5,r0
}

void f_0603B6E0(SH2Context& c) {
    ran[904] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603B6E0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603B6E2 mov.l r14,@-r15
    c.r[4] += 54;  // 0603B6E4 add #54,r4
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[4]);  // 0603B6E6 mov.w @r4,r2
    c.r[1] = 0x2Cu;  // 0603B6E8 mov #44,r1
    c.macl = (c.r[2] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 0603B6EA mulu.w r1,r2
    c.r[14] = c.r[15];  // 0603B6EC mov r15,r14
    c.r[7] = c.macl;  // 0603B6EE sts macl,r7
    c.r[1] = ld32(0x0603B790u);  // 0603B6F0 mov.l 0x0603B790,r1
    c.r[7] += c.r[1];  // 0603B6F2 add r1,r7
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0603B6F4 mov.b @r7,r0
    c.r[1] = ld32(0x0603B794u);  // 0603B6F6 mov.l 0x0603B794,r1
    c.r[0] &= 0xF3u;  // 0603B6F8 and #243,r0
    c.r[0] |= 0x4u;  // 0603B6FA or #4,r0
    st8(c.r[7], c.r[0]);  // 0603B6FC mov.b r0,@r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603B6FE mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0603B700 extu.b r1,r1
    c.r[0] = c.r[1];  // 0603B702 mov r1,r0
    c.r[0] >>= 2;  // 0603B704 shlr2 r0
    c.r[0] >>= 2;  // 0603B706 shlr2 r0
    c.r[0] >>= 2;  // 0603B708 shlr2 r0
    c.r[1] >>= 2;  // 0603B70A shlr2 r1
    c.r[1] >>= 2;  // 0603B70C shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0603B70E shlr r1
    c.r[1] >>= 2;  // 0603B710 shlr2 r1
    c.r[0] &= 0x1u;  // 0603B712 and #1,r0
    c.t = c.r[1] == c.r[0];  // 0603B714 cmp/eq r0,r1
    { const bool k = c.t; c.r[8] = c.r[5]; if (k) { goto L_0603B736; } }  // 0603B716 bt/s 0x0603B736 ; mov r5,r8
    c.r[1] = c.r[7];  // 0603B71A mov r7,r1
    c.r[0] = c.r[8];  // 0603B71C mov r8,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0]); c.r[0] += 1;  // 0603B71E mov.b @r0+,r2
    c.r[1] += 18;  // 0603B720 add #18,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0603B722 mov.w @r1,r1
    c.r[1] += c.r[2];  // 0603B724 add r2,r1
    c.r[3] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 0603B726 exts.w r1,r3
    c.r[1] = c.r[7];  // 0603B728 mov r7,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0603B72A mov.b @r0,r2
    c.r[1] += 22;  // 0603B72C add #22,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0603B72E mov.w @r1,r1
    c.r[1] += c.r[2];  // 0603B730 add r2,r1
    c.r[6] = (uint32_t)(int32_t)(int16_t)c.r[1]; goto L_0603B750;  // 0603B732 bra 0x0603B750 ; exts.w r1,r6
L_0603B736:
    c.r[1] = c.r[7];  // 0603B736 mov r7,r1
    c.r[0] = c.r[8];  // 0603B738 mov r8,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0]); c.r[0] += 1;  // 0603B73A mov.b @r0+,r2
    c.r[1] += 22;  // 0603B73C add #22,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0603B73E mov.w @r1,r1
    c.r[1] += c.r[2];  // 0603B740 add r2,r1
    c.r[6] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 0603B742 exts.w r1,r6
    c.r[1] = c.r[7];  // 0603B744 mov r7,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0603B746 mov.b @r0,r2
    c.r[1] += 18;  // 0603B748 add #18,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0603B74A mov.w @r1,r1
    c.r[1] += c.r[2];  // 0603B74C add r2,r1
    c.r[3] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 0603B74E exts.w r1,r3
L_0603B750:
    c.t = (int32_t)c.r[3] >= 0;  // 0603B750 cmp/pz r3
    { const bool k = !c.t; c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[3]; if (k) { goto L_0603B764; } }  // 0603B752 bf/s 0x0603B764 ; exts.w r3,r2
    c.r[5] = (uint32_t)(int16_t)ld16(0x0603B78Eu);  // 0603B756 mov.w 0x0603B78E,r5
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[5];  // 0603B758 exts.w r5,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0603B75A cmp/gt r1,r2
    if (!c.t) { goto L_0603B760; }  // 0603B75C bf 0x0603B760
    c.r[3] = c.r[5];  // 0603B75E mov r5,r3
L_0603B760:
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[3]; goto L_0603B766;  // 0603B760 bra 0x0603B766 ; exts.w r3,r1
L_0603B764:
    c.r[1] = 0x0u;  // 0603B764 mov #0,r1
L_0603B766:
    c.t = (int32_t)c.r[6] >= 0;  // 0603B766 cmp/pz r6
    { const bool k = !c.t; st32(c.r[7] + 16, c.r[1]); if (k) { goto L_0603B77E; } }  // 0603B768 bf/s 0x0603B77E ; mov.l r1,@(16,r7)
    c.r[3] = c.r[6];  // 0603B76C mov r6,r3
    c.r[6] = (uint32_t)(int16_t)ld16(0x0603B78Eu);  // 0603B76E mov.w 0x0603B78E,r6
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[3];  // 0603B770 exts.w r3,r2
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[6];  // 0603B772 exts.w r6,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0603B774 cmp/gt r1,r2
    if (!c.t) { goto L_0603B77A; }  // 0603B776 bf 0x0603B77A
    c.r[3] = c.r[6];  // 0603B778 mov r6,r3
L_0603B77A:
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[3]; goto L_0603B780;  // 0603B77A bra 0x0603B780 ; exts.w r3,r1
L_0603B77E:
    c.r[1] = 0x0u;  // 0603B77E mov #0,r1
L_0603B780:
    st32(c.r[7] + 20, c.r[1]);  // 0603B780 mov.l r1,@(20,r7)
    c.r[8] += 2;  // 0603B782 add #2,r8
    c.r[15] = c.r[14];  // 0603B784 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603B786 mov.l @r15+,r14
    c.r[0] = c.r[8];  // 0603B788 mov r8,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603B78A rts ; mov.l @r15+,r8
}

void f_0603B798(SH2Context& c) {
    ran[905] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603B798 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603B79A mov.l r14,@-r15
    c.r[4] += 54;  // 0603B79C add #54,r4
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[4]);  // 0603B79E mov.w @r4,r2
    c.r[1] = 0x2Cu;  // 0603B7A0 mov #44,r1
    c.macl = (c.r[2] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 0603B7A2 mulu.w r1,r2
    c.r[14] = c.r[15];  // 0603B7A4 mov r15,r14
    c.r[7] = c.macl;  // 0603B7A6 sts macl,r7
    c.r[1] = ld32(0x0603B84Cu);  // 0603B7A8 mov.l 0x0603B84C,r1
    c.r[7] += c.r[1];  // 0603B7AA add r1,r7
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0603B7AC mov.b @r7,r0
    c.r[1] = ld32(0x0603B850u);  // 0603B7AE mov.l 0x0603B850,r1
    c.r[0] &= 0xF3u;  // 0603B7B0 and #243,r0
    c.r[0] |= 0x8u;  // 0603B7B2 or #8,r0
    st8(c.r[7], c.r[0]);  // 0603B7B4 mov.b r0,@r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603B7B6 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0603B7B8 extu.b r1,r1
    c.r[0] = c.r[1];  // 0603B7BA mov r1,r0
    c.r[0] >>= 2;  // 0603B7BC shlr2 r0
    c.r[0] >>= 2;  // 0603B7BE shlr2 r0
    c.r[0] >>= 2;  // 0603B7C0 shlr2 r0
    c.r[1] >>= 2;  // 0603B7C2 shlr2 r1
    c.r[1] >>= 2;  // 0603B7C4 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0603B7C6 shlr r1
    c.r[1] >>= 2;  // 0603B7C8 shlr2 r1
    c.r[0] &= 0x1u;  // 0603B7CA and #1,r0
    c.t = c.r[1] == c.r[0];  // 0603B7CC cmp/eq r0,r1
    { const bool k = c.t; c.r[8] = c.r[5]; if (k) { goto L_0603B7F0; } }  // 0603B7CE bt/s 0x0603B7F0 ; mov r5,r8
    c.r[3] = c.r[7];  // 0603B7D2 mov r7,r3
    c.r[1] = c.r[8];  // 0603B7D4 mov r8,r1
    c.r[1] += 1;  // 0603B7D6 add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603B7D8 mov.b @r1,r2
    c.r[3] += 18;  // 0603B7DA add #18,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0603B7DC mov.w @r3,r1
    c.r[1] += c.r[2];  // 0603B7DE add r2,r1
    c.r[3] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 0603B7E0 exts.w r1,r3
    c.r[1] = c.r[7];  // 0603B7E2 mov r7,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0603B7E4 mov.b @r8,r2
    c.r[1] += 22;  // 0603B7E6 add #22,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0603B7E8 mov.w @r1,r1
    c.r[1] += c.r[2];  // 0603B7EA add r2,r1
    c.r[6] = (uint32_t)(int32_t)(int16_t)c.r[1]; goto L_0603B80C;  // 0603B7EC bra 0x0603B80C ; exts.w r1,r6
L_0603B7F0:
    c.r[3] = c.r[7];  // 0603B7F0 mov r7,r3
    c.r[1] = c.r[8];  // 0603B7F2 mov r8,r1
    c.r[1] += 1;  // 0603B7F4 add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603B7F6 mov.b @r1,r2
    c.r[3] += 22;  // 0603B7F8 add #22,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0603B7FA mov.w @r3,r1
    c.r[1] += c.r[2];  // 0603B7FC add r2,r1
    c.r[6] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 0603B7FE exts.w r1,r6
    c.r[1] = c.r[7];  // 0603B800 mov r7,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0603B802 mov.b @r8,r2
    c.r[1] += 18;  // 0603B804 add #18,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0603B806 mov.w @r1,r1
    c.r[1] += c.r[2];  // 0603B808 add r2,r1
    c.r[3] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 0603B80A exts.w r1,r3
L_0603B80C:
    c.t = (int32_t)c.r[3] >= 0;  // 0603B80C cmp/pz r3
    { const bool k = !c.t; c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[3]; if (k) { goto L_0603B820; } }  // 0603B80E bf/s 0x0603B820 ; exts.w r3,r2
    c.r[5] = (uint32_t)(int16_t)ld16(0x0603B84Au);  // 0603B812 mov.w 0x0603B84A,r5
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[5];  // 0603B814 exts.w r5,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0603B816 cmp/gt r1,r2
    if (!c.t) { goto L_0603B81C; }  // 0603B818 bf 0x0603B81C
    c.r[3] = c.r[5];  // 0603B81A mov r5,r3
L_0603B81C:
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[3]; goto L_0603B822;  // 0603B81C bra 0x0603B822 ; exts.w r3,r1
L_0603B820:
    c.r[1] = 0x0u;  // 0603B820 mov #0,r1
L_0603B822:
    c.t = (int32_t)c.r[6] >= 0;  // 0603B822 cmp/pz r6
    { const bool k = !c.t; st32(c.r[7] + 16, c.r[1]); if (k) { goto L_0603B83A; } }  // 0603B824 bf/s 0x0603B83A ; mov.l r1,@(16,r7)
    c.r[3] = c.r[6];  // 0603B828 mov r6,r3
    c.r[6] = (uint32_t)(int16_t)ld16(0x0603B84Au);  // 0603B82A mov.w 0x0603B84A,r6
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[3];  // 0603B82C exts.w r3,r2
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[6];  // 0603B82E exts.w r6,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0603B830 cmp/gt r1,r2
    if (!c.t) { goto L_0603B836; }  // 0603B832 bf 0x0603B836
    c.r[3] = c.r[6];  // 0603B834 mov r6,r3
L_0603B836:
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[3]; goto L_0603B83C;  // 0603B836 bra 0x0603B83C ; exts.w r3,r1
L_0603B83A:
    c.r[1] = 0x0u;  // 0603B83A mov #0,r1
L_0603B83C:
    st32(c.r[7] + 20, c.r[1]);  // 0603B83C mov.l r1,@(20,r7)
    c.r[8] += 2;  // 0603B83E add #2,r8
    c.r[15] = c.r[14];  // 0603B840 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603B842 mov.l @r15+,r14
    c.r[0] = c.r[8];  // 0603B844 mov r8,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603B846 rts ; mov.l @r15+,r8
}

void f_0603B854(SH2Context& c) {
    ran[906] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603B854 mov.l r14,@-r15
    c.r[4] += 54;  // 0603B856 add #54,r4
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[4]);  // 0603B858 mov.w @r4,r2
    c.r[1] = 0x2Cu;  // 0603B85A mov #44,r1
    c.macl = (c.r[2] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 0603B85C mulu.w r1,r2
    c.r[7] = c.macl;  // 0603B85E sts macl,r7
    c.r[1] = ld32(0x0603B8CCu);  // 0603B860 mov.l 0x0603B8CC,r1
    c.r[7] += c.r[1];  // 0603B862 add r1,r7
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0603B864 mov.b @r7,r0
    c.r[1] = c.r[7];  // 0603B866 mov r7,r1
    c.r[0] &= 0xF3u;  // 0603B868 and #243,r0
    c.r[0] |= 0x4u;  // 0603B86A or #4,r0
    st8(c.r[7], c.r[0]);  // 0603B86C mov.b r0,@r7
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[5]);  // 0603B86E mov.b @r5,r2
    c.r[1] += 26;  // 0603B870 add #26,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0603B872 mov.w @r1,r1
    c.r[1] += c.r[2];  // 0603B874 add r2,r1
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 0603B876 exts.w r1,r1
    c.t = (int32_t)c.r[1] >= 0;  // 0603B878 cmp/pz r1
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0603B890; } }  // 0603B87A bf/s 0x0603B890 ; mov r15,r14
    c.r[3] = c.r[1];  // 0603B87E mov r1,r3
    c.r[6] = (uint32_t)(int16_t)ld16(0x0603B8C8u);  // 0603B880 mov.w 0x0603B8C8,r6
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[3];  // 0603B882 exts.w r3,r2
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[6];  // 0603B884 exts.w r6,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0603B886 cmp/gt r1,r2
    if (!c.t) { goto L_0603B88C; }  // 0603B888 bf 0x0603B88C
    c.r[3] = c.r[6];  // 0603B88A mov r6,r3
L_0603B88C:
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[3]; goto L_0603B892;  // 0603B88C bra 0x0603B892 ; exts.w r3,r1
L_0603B890:
    c.r[1] = 0x0u;  // 0603B890 mov #0,r1
L_0603B892:
    st32(c.r[7] + 24, c.r[1]);  // 0603B892 mov.l r1,@(24,r7)
    c.r[3] = c.r[7];  // 0603B894 mov r7,r3
    c.r[1] = c.r[5];  // 0603B896 mov r5,r1
    c.r[1] += 1;  // 0603B898 add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603B89A mov.b @r1,r2
    c.r[3] += 30;  // 0603B89C add #30,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0603B89E mov.w @r3,r1
    c.r[1] += c.r[2];  // 0603B8A0 add r2,r1
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 0603B8A2 exts.w r1,r1
    c.t = (int32_t)c.r[1] >= 0;  // 0603B8A4 cmp/pz r1
    { const bool k = !c.t; c.r[3] = c.r[1]; if (k) { goto L_0603B8BA; } }  // 0603B8A6 bf/s 0x0603B8BA ; mov r1,r3
    c.r[6] = (uint32_t)(int16_t)ld16(0x0603B8C8u);  // 0603B8AA mov.w 0x0603B8C8,r6
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[3];  // 0603B8AC exts.w r3,r2
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[6];  // 0603B8AE exts.w r6,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0603B8B0 cmp/gt r1,r2
    if (!c.t) { goto L_0603B8B6; }  // 0603B8B2 bf 0x0603B8B6
    c.r[3] = c.r[6];  // 0603B8B4 mov r6,r3
L_0603B8B6:
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[3]; goto L_0603B8BC;  // 0603B8B6 bra 0x0603B8BC ; exts.w r3,r1
L_0603B8BA:
    c.r[1] = 0x0u;  // 0603B8BA mov #0,r1
L_0603B8BC:
    st32(c.r[7] + 28, c.r[1]);  // 0603B8BC mov.l r1,@(28,r7)
    c.r[5] += 2;  // 0603B8BE add #2,r5
    c.r[15] = c.r[14];  // 0603B8C0 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603B8C2 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[5]; c.pc = x; return; }  // 0603B8C4 rts ; mov r5,r0
}

void f_0603B8D0(SH2Context& c) {
    ran[907] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603B8D0 mov.l r14,@-r15
    c.r[4] += 54;  // 0603B8D2 add #54,r4
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[4]);  // 0603B8D4 mov.w @r4,r2
    c.r[1] = 0x2Cu;  // 0603B8D6 mov #44,r1
    c.macl = (c.r[2] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 0603B8D8 mulu.w r1,r2
    c.r[7] = c.macl;  // 0603B8DA sts macl,r7
    c.r[1] = ld32(0x0603B948u);  // 0603B8DC mov.l 0x0603B948,r1
    c.r[7] += c.r[1];  // 0603B8DE add r1,r7
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0603B8E0 mov.b @r7,r0
    c.r[1] = c.r[7];  // 0603B8E2 mov r7,r1
    c.r[0] &= 0xF3u;  // 0603B8E4 and #243,r0
    c.r[0] |= 0x8u;  // 0603B8E6 or #8,r0
    st8(c.r[7], c.r[0]);  // 0603B8E8 mov.b r0,@r7
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[5]);  // 0603B8EA mov.b @r5,r2
    c.r[1] += 26;  // 0603B8EC add #26,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0603B8EE mov.w @r1,r1
    c.r[1] += c.r[2];  // 0603B8F0 add r2,r1
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 0603B8F2 exts.w r1,r1
    c.t = (int32_t)c.r[1] >= 0;  // 0603B8F4 cmp/pz r1
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0603B90C; } }  // 0603B8F6 bf/s 0x0603B90C ; mov r15,r14
    c.r[3] = c.r[1];  // 0603B8FA mov r1,r3
    c.r[6] = (uint32_t)(int16_t)ld16(0x0603B944u);  // 0603B8FC mov.w 0x0603B944,r6
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[3];  // 0603B8FE exts.w r3,r2
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[6];  // 0603B900 exts.w r6,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0603B902 cmp/gt r1,r2
    if (!c.t) { goto L_0603B908; }  // 0603B904 bf 0x0603B908
    c.r[3] = c.r[6];  // 0603B906 mov r6,r3
L_0603B908:
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[3]; goto L_0603B90E;  // 0603B908 bra 0x0603B90E ; exts.w r3,r1
L_0603B90C:
    c.r[1] = 0x0u;  // 0603B90C mov #0,r1
L_0603B90E:
    st32(c.r[7] + 24, c.r[1]);  // 0603B90E mov.l r1,@(24,r7)
    c.r[3] = c.r[7];  // 0603B910 mov r7,r3
    c.r[1] = c.r[5];  // 0603B912 mov r5,r1
    c.r[1] += 1;  // 0603B914 add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603B916 mov.b @r1,r2
    c.r[3] += 30;  // 0603B918 add #30,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0603B91A mov.w @r3,r1
    c.r[1] += c.r[2];  // 0603B91C add r2,r1
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 0603B91E exts.w r1,r1
    c.t = (int32_t)c.r[1] >= 0;  // 0603B920 cmp/pz r1
    { const bool k = !c.t; c.r[3] = c.r[1]; if (k) { goto L_0603B936; } }  // 0603B922 bf/s 0x0603B936 ; mov r1,r3
    c.r[6] = (uint32_t)(int16_t)ld16(0x0603B944u);  // 0603B926 mov.w 0x0603B944,r6
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[3];  // 0603B928 exts.w r3,r2
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[6];  // 0603B92A exts.w r6,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0603B92C cmp/gt r1,r2
    if (!c.t) { goto L_0603B932; }  // 0603B92E bf 0x0603B932
    c.r[3] = c.r[6];  // 0603B930 mov r6,r3
L_0603B932:
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[3]; goto L_0603B938;  // 0603B932 bra 0x0603B938 ; exts.w r3,r1
L_0603B936:
    c.r[1] = 0x0u;  // 0603B936 mov #0,r1
L_0603B938:
    st32(c.r[7] + 28, c.r[1]);  // 0603B938 mov.l r1,@(28,r7)
    c.r[5] += 2;  // 0603B93A add #2,r5
    c.r[15] = c.r[14];  // 0603B93C mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603B93E mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[5]; c.pc = x; return; }  // 0603B940 rts ; mov r5,r0
}

void f_0603B94C(SH2Context& c) {
    ran[908] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603B94C mov.l r14,@-r15
    c.r[2] = c.r[5];  // 0603B94E mov r5,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0603B950 mov.b @r2,r0
    c.r[0] &= 0x80u;  // 0603B952 and #128,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603B954 tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0603B960; } }  // 0603B956 bt/s 0x0603B960 ; mov r15,r14
    c.r[4] += 60;  // 0603B95A add #60,r4
    c.r[1] = 0x1u;  // 0603B95C mov #1,r1
    st8(c.r[4], c.r[1]);  // 0603B95E mov.b r1,@r4
L_0603B960:
    c.r[15] = c.r[14];  // 0603B960 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603B962 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[2]; c.pc = x; return; }  // 0603B964 rts ; mov r2,r0
}

void f_0603B968(SH2Context& c) {
    ran[909] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603B968 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603B96A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0603B96C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603B96E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603B970 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0603B972 mov r15,r14
    c.r[9] = c.r[4];  // 0603B974 mov r4,r9
    c.r[9] += 54;  // 0603B976 add #54,r9
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]);  // 0603B978 mov.w @r9,r1
    c.r[8] = c.r[1] & 0xFFFFu;  // 0603B97A extu.w r1,r8
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603B9CCu);  // 0603B97C mov.w 0x0603B9CC,r1
    c.t = c.r[8] == c.r[1];  // 0603B97E cmp/eq r1,r8
    { const bool k = !c.t; c.r[10] = c.r[5]; if (k) { goto L_0603B9BC; } }  // 0603B980 bf/s 0x0603B9BC ; mov r5,r10
    c.r[0] = ld32(0x0603B9D0u);  // 0603B984 mov.l 0x0603B9D0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0603B98Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603B98Au) return; }  // 0603B986 jsr @r0 ; nop
    c.r[3] = c.r[0] & 0xFFu;  // 0603B98A extu.b r0,r3
    c.r[1] = c.r[3] & 0xFFFFu;  // 0603B98C extu.w r3,r1
    c.t = c.r[1] == c.r[8];  // 0603B98E cmp/eq r8,r1
    { const bool k = !c.t; st16(c.r[9], c.r[3]); if (k) { goto L_0603B99E; } }  // 0603B990 bf/s 0x0603B99E ; mov.w r3,@r9
    c.r[1] = ld32(0x0603B9D4u);  // 0603B994 mov.l 0x0603B9D4,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0603B996 mov.w @r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0603B9CEu);  // 0603B998 mov.w 0x0603B9CE,r3
    c.r[2] &= c.r[3]; goto L_0603B9BA;  // 0603B99A bra 0x0603B9BA ; and r3,r2
L_0603B99E:
    c.r[1] = ld32(0x0603B9D8u);  // 0603B99E mov.l 0x0603B9D8,r1
    c.r[2] = 0x2Cu;  // 0603B9A0 mov #44,r2
    c.macl = (c.r[3] & 0xFFFFu) * (c.r[2] & 0xFFFFu);  // 0603B9A2 mulu.w r2,r3
    c.r[0] = c.r[1];  // 0603B9A4 mov r1,r0
    c.r[2] = c.macl;  // 0603B9A6 sts macl,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0603B9A8 mov.b @(r0,r2),r3
    c.r[0] = 0x3u;  // 0603B9AA mov #3,r0
    c.r[3] |= c.r[0];  // 0603B9AC or r0,r3
    c.r[0] = c.r[1];  // 0603B9AE mov r1,r0
    st8(c.r[0] + c.r[2], c.r[3]);  // 0603B9B0 mov.b r3,@(r0,r2)
    c.r[1] = ld32(0x0603B9D4u);  // 0603B9B2 mov.l 0x0603B9D4,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0603B9B4 mov.w @r1,r2
    c.r[0] = 0x20u;  // 0603B9B6 mov #32,r0
    c.r[2] |= c.r[0];  // 0603B9B8 or r0,r2
L_0603B9BA:
    st16(c.r[1], c.r[2]);  // 0603B9BA mov.w r2,@r1
L_0603B9BC:
    c.r[15] = c.r[14];  // 0603B9BC mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603B9BE lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603B9C0 mov.l @r15+,r14
    c.r[0] = c.r[10];  // 0603B9C2 mov r10,r0
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0603B9C4 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0603B9C6 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603B9C8 rts ; mov.l @r15+,r8
}

void f_0603B9DC(SH2Context& c) {
    ran[910] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603B9DC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603B9DE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603B9E0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603B9E2 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0603B9E4 mov r15,r14
    c.r[9] = c.r[5];  // 0603B9E6 mov r5,r9
    c.r[8] = c.r[4];  // 0603B9E8 mov r4,r8
    c.r[8] += 54;  // 0603B9EA add #54,r8
    c.r[4] += 55;  // 0603B9EC add #55,r4
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[4]);  // 0603B9EE mov.b @r4,r4
    c.r[1] = ld32(0x0603BA0Cu);  // 0603B9F0 mov.l 0x0603BA0C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603B9F6u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603B9F6u) return; }  // 0603B9F2 jsr @r1 ; extu.b r4,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603BA08u);  // 0603B9F6 mov.w 0x0603BA08,r1
    st16(c.r[8], c.r[1]);  // 0603B9F8 mov.w r1,@r8
    c.r[15] = c.r[14];  // 0603B9FA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603B9FC lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603B9FE mov.l @r15+,r14
    c.r[0] = c.r[9];  // 0603BA00 mov r9,r0
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0603BA02 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603BA04 rts ; mov.l @r15+,r8
}

void f_0603BA10(SH2Context& c) {
    ran[911] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603BA10 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603BA12 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603BA14 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0603BA16 mov r15,r14
    c.r[8] = c.r[5];  // 0603BA18 mov r5,r8
    c.r[1] = c.r[8];  // 0603BA1A mov r8,r1
    c.r[1] += 1;  // 0603BA1C add #1,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0603BA1E mov.b @r8,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603BA20 mov.b @r1,r1
    c.r[5] = c.r[5] & 0xFFu;  // 0603BA22 extu.b r5,r5
    c.r[5] <<= 8;  // 0603BA24 shll8 r5
    c.r[1] = c.r[1] & 0xFFu;  // 0603BA26 extu.b r1,r1
    c.r[5] |= c.r[1];  // 0603BA28 or r1,r5
    c.r[1] = ld32(0x0603BA40u);  // 0603BA2A mov.l 0x0603BA40,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603BA30u; c.r[6] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603BA30u) return; }  // 0603BA2C jsr @r1 ; mov #1,r6
    c.r[15] = c.r[14];  // 0603BA30 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603BA32 lds.l @r15+,pr
    c.r[8] += 2;  // 0603BA34 add #2,r8
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603BA36 mov.l @r15+,r14
    c.r[0] = c.r[8];  // 0603BA38 mov r8,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603BA3A rts ; mov.l @r15+,r8
}

void f_0603BA44(SH2Context& c) {
    ran[912] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603BA44 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603BA46 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603BA48 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0603BA4A mov r15,r14
    c.r[8] = c.r[5];  // 0603BA4C mov r5,r8
    c.r[1] = c.r[8];  // 0603BA4E mov r8,r1
    c.r[1] += 1;  // 0603BA50 add #1,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0603BA52 mov.b @r8,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603BA54 mov.b @r1,r1
    c.r[5] = c.r[5] & 0xFFu;  // 0603BA56 extu.b r5,r5
    c.r[5] <<= 8;  // 0603BA58 shll8 r5
    c.r[1] = c.r[1] & 0xFFu;  // 0603BA5A extu.b r1,r1
    c.r[5] |= c.r[1];  // 0603BA5C or r1,r5
    c.r[1] = ld32(0x0603BA74u);  // 0603BA5E mov.l 0x0603BA74,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603BA64u; c.r[6] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603BA64u) return; }  // 0603BA60 jsr @r1 ; mov #2,r6
    c.r[15] = c.r[14];  // 0603BA64 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603BA66 lds.l @r15+,pr
    c.r[8] += 2;  // 0603BA68 add #2,r8
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603BA6A mov.l @r15+,r14
    c.r[0] = c.r[8];  // 0603BA6C mov r8,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603BA6E rts ; mov.l @r15+,r8
}

void f_0603BA78(SH2Context& c) {
    ran[913] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603BA78 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603BA7A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603BA7C sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0603BA7E mov r15,r14
    c.r[8] = c.r[5];  // 0603BA80 mov r5,r8
    c.r[1] = c.r[8];  // 0603BA82 mov r8,r1
    c.r[1] += 1;  // 0603BA84 add #1,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0603BA86 mov.b @r8,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603BA88 mov.b @r1,r1
    c.r[5] = c.r[5] & 0xFFu;  // 0603BA8A extu.b r5,r5
    c.r[5] <<= 8;  // 0603BA8C shll8 r5
    c.r[1] = c.r[1] & 0xFFu;  // 0603BA8E extu.b r1,r1
    c.r[5] |= c.r[1];  // 0603BA90 or r1,r5
    c.r[1] = ld32(0x0603BAA8u);  // 0603BA92 mov.l 0x0603BAA8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603BA98u; c.r[6] = 0x3u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603BA98u) return; }  // 0603BA94 jsr @r1 ; mov #3,r6
    c.r[15] = c.r[14];  // 0603BA98 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603BA9A lds.l @r15+,pr
    c.r[8] += 2;  // 0603BA9C add #2,r8
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603BA9E mov.l @r15+,r14
    c.r[0] = c.r[8];  // 0603BAA0 mov r8,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603BAA2 rts ; mov.l @r15+,r8
}

void f_0603BAAC(SH2Context& c) {
    ran[914] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603BAAC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603BAAE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0603BAB0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0603BAB2 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603BAB4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603BAB6 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0603BAB8 mov r15,r14
    c.r[11] = c.r[5];  // 0603BABA mov r5,r11
    c.r[8] = (uint32_t)(int16_t)ld16(0x0603BAE8u);  // 0603BABC mov.w 0x0603BAE8,r8
    c.r[9] = (uint32_t)(int16_t)ld16(0x0603BAEAu);  // 0603BABE mov.w 0x0603BAEA,r9
    c.r[4] = ld32(0x0603BAECu);  // 0603BAC0 mov.l 0x0603BAEC,r4
    c.r[10] = ld32(0x0603BAF0u);  // 0603BAC2 mov.l 0x0603BAF0,r10
    c.r[7] = c.r[8];  // 0603BAC4 mov r8,r7
    c.r[6] = 0x1u;  // 0603BAC6 mov #1,r6
    { const uint32_t x = c.r[10]; c.pr = 0x0603BACCu; c.r[5] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603BACCu) return; }  // 0603BAC8 jsr @r10 ; mov r9,r5
    c.r[4] = ld32(0x0603BAF4u);  // 0603BACC mov.l 0x0603BAF4,r4
    c.r[7] = c.r[8];  // 0603BACE mov r8,r7
    c.r[6] = 0x1u;  // 0603BAD0 mov #1,r6
    { const uint32_t x = c.r[10]; c.pr = 0x0603BAD6u; c.r[5] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603BAD6u) return; }  // 0603BAD2 jsr @r10 ; mov r9,r5
    c.r[15] = c.r[14];  // 0603BAD6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603BAD8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603BADA mov.l @r15+,r14
    c.r[0] = c.r[11];  // 0603BADC mov r11,r0
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0603BADE mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0603BAE0 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0603BAE2 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603BAE4 rts ; mov.l @r15+,r8
}

void f_0603BAF8(SH2Context& c) {
    ran[915] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603BAF8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603BAFA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0603BAFC mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0603BAFE mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603BB00 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603BB02 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0603BB04 mov r15,r14
    c.r[11] = c.r[5];  // 0603BB06 mov r5,r11
    c.r[8] = (uint32_t)(int16_t)ld16(0x0603BB34u);  // 0603BB08 mov.w 0x0603BB34,r8
    c.r[9] = (uint32_t)(int16_t)ld16(0x0603BB36u);  // 0603BB0A mov.w 0x0603BB36,r9
    c.r[4] = ld32(0x0603BB38u);  // 0603BB0C mov.l 0x0603BB38,r4
    c.r[10] = ld32(0x0603BB3Cu);  // 0603BB0E mov.l 0x0603BB3C,r10
    c.r[7] = c.r[8];  // 0603BB10 mov r8,r7
    c.r[6] = 0x1u;  // 0603BB12 mov #1,r6
    { const uint32_t x = c.r[10]; c.pr = 0x0603BB18u; c.r[5] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603BB18u) return; }  // 0603BB14 jsr @r10 ; mov r9,r5
    c.r[4] = ld32(0x0603BB40u);  // 0603BB18 mov.l 0x0603BB40,r4
    c.r[7] = c.r[8];  // 0603BB1A mov r8,r7
    c.r[6] = 0x1u;  // 0603BB1C mov #1,r6
    { const uint32_t x = c.r[10]; c.pr = 0x0603BB22u; c.r[5] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603BB22u) return; }  // 0603BB1E jsr @r10 ; mov r9,r5
    c.r[15] = c.r[14];  // 0603BB22 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603BB24 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603BB26 mov.l @r15+,r14
    c.r[0] = c.r[11];  // 0603BB28 mov r11,r0
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0603BB2A mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0603BB2C mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0603BB2E mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603BB30 rts ; mov.l @r15+,r8
}

void f_0603BB44(SH2Context& c) {
    ran[916] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603BB44 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603BB46 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0603BB48 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0603BB4A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603BB4C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603BB4E sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0603BB50 mov r15,r14
    c.r[8] = c.r[4];  // 0603BB52 mov r4,r8
    c.r[9] = c.r[8];  // 0603BB54 mov r8,r9
    c.r[9] += 54;  // 0603BB56 add #54,r9
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]);  // 0603BB58 mov.w @r9,r1
    c.r[10] = 0x10u;  // 0603BB5A mov #16,r10
    c.r[1] = c.r[1] & 0xFFFFu;  // 0603BB5C extu.w r1,r1
    c.t = c.r[1] > c.r[10];  // 0603BB5E cmp/hi r10,r1
    { const bool k = !c.t; c.r[11] = c.r[5]; if (k) { goto L_0603BBEA; } }  // 0603BB60 bf/s 0x0603BBEA ; mov r5,r11
    c.r[0] = ld32(0x0603BC28u);  // 0603BB64 mov.l 0x0603BC28,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0603BB6Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603BB6Au) return; }  // 0603BB66 jsr @r0 ; nop
    c.r[2] = c.r[0] & 0xFFu;  // 0603BB6A extu.b r0,r2
    c.r[1] = 0x2Cu;  // 0603BB6C mov #44,r1
    c.macl = (c.r[2] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 0603BB6E mulu.w r1,r2
    st16(c.r[9], c.r[2]);  // 0603BB70 mov.w r2,@r9
    c.r[3] = c.macl;  // 0603BB72 sts macl,r3
    c.r[1] = ld32(0x0603BC2Cu);  // 0603BB74 mov.l 0x0603BC2C,r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 0603BB76 extu.w r2,r2
    c.t = c.r[2] > c.r[10];  // 0603BB78 cmp/hi r10,r2
    { const bool k = !c.t; c.r[3] += c.r[1]; if (k) { goto L_0603BB8C; } }  // 0603BB7A bf/s 0x0603BB8C ; add r1,r3
    c.r[1] = ld32(0x0603BC30u);  // 0603BB7E mov.l 0x0603BC30,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0603BB80 mov.w @r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0603BC20u);  // 0603BB82 mov.w 0x0603BC20,r3
    c.r[0] = c.r[11];  // 0603BB84 mov r11,r0
    c.r[2] &= c.r[3];  // 0603BB86 and r3,r2
    st16(c.r[1], c.r[2]); goto L_0603BC10;  // 0603BB88 bra 0x0603BC10 ; mov.w r2,@r1
L_0603BB8C:
    c.r[1] = c.r[8];  // 0603BB8C mov r8,r1
    c.r[1] += 1;  // 0603BB8E add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603BB90 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0603BB92 mov r1,r0
    c.r[0] >>= 2;  // 0603BB94 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0603BB96 shlr r0
    c.r[0] &= 0x1u;  // 0603BB98 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603BB9A tst r0,r0
    { const bool k = c.t; c.r[2] = c.r[3]; if (k) { goto L_0603BBBA; } }  // 0603BB9C bt/s 0x0603BBBA ; mov r3,r2
    c.r[1] = c.r[3];  // 0603BBA0 mov r3,r1
    c.r[2] = ld32(c.r[8] + 4);  // 0603BBA2 mov.l @(4,r8),r2
    c.r[1] += 12;  // 0603BBA4 add #12,r1
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 0603BBA6 shar r2
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 0603BBA8 shar r2
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 0603BBAA shar r2
    st16(c.r[1], c.r[2]);  // 0603BBAC mov.w r2,@r1
    c.r[1] = ld32(c.r[8] + 8);  // 0603BBAE mov.l @(8,r8),r1
    c.r[3] += 14;  // 0603BBB0 add #14,r3
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0603BBB2 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0603BBB4 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1); goto L_0603BBCC;  // 0603BBB6 bra 0x0603BBCC ; shar r1
L_0603BBBA:
    c.r[1] = c.r[8];  // 0603BBBA mov r8,r1
    c.r[1] += 6;  // 0603BBBC add #6,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0603BBBE mov.w @r1,r1
    c.r[2] += 12;  // 0603BBC0 add #12,r2
    st16(c.r[2], c.r[1]);  // 0603BBC2 mov.w r1,@r2
    c.r[1] = c.r[8];  // 0603BBC4 mov r8,r1
    c.r[1] += 10;  // 0603BBC6 add #10,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0603BBC8 mov.w @r1,r1
    c.r[3] += 14;  // 0603BBCA add #14,r3
L_0603BBCC:
    st16(c.r[3], c.r[1]);  // 0603BBCC mov.w r1,@r3
    c.r[3] = ld32(0x0603BC2Cu);  // 0603BBCE mov.l 0x0603BC2C,r3
    c.r[8] += 54;  // 0603BBD0 add #54,r8
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[8]);  // 0603BBD2 mov.w @r8,r2
    c.r[1] = 0x2Cu;  // 0603BBD4 mov #44,r1
    c.macl = (c.r[2] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 0603BBD6 mulu.w r1,r2
    c.r[0] = c.r[3];  // 0603BBD8 mov r3,r0
    c.r[1] = c.macl;  // 0603BBDA sts macl,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0603BBDC mov.b @(r0,r1),r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0603BC22u);  // 0603BBDE mov.w 0x0603BC22,r0
    c.r[2] &= c.r[0];  // 0603BBE0 and r0,r2
    c.r[0] = 0x2u;  // 0603BBE2 mov #2,r0
    c.r[2] |= c.r[0];  // 0603BBE4 or r0,r2
    c.r[0] = c.r[3];  // 0603BBE6 mov r3,r0
    st8(c.r[0] + c.r[1], c.r[2]);  // 0603BBE8 mov.b r2,@(r0,r1)
L_0603BBEA:
    c.r[1] = 0x0u;  // 0603BBEA mov #0,r1
    c.r[5] = ld32(0x0603BC34u);  // 0603BBEC mov.l 0x0603BC34,r5
    c.r[6] = ld32(0x0603BC38u);  // 0603BBEE mov.l 0x0603BC38,r6
    c.r[7] = ld32(0x0603BC3Cu);  // 0603BBF0 mov.l 0x0603BC3C,r7
    c.r[3] = 0x0u;  // 0603BBF2 mov #0,r3
    c.r[2] = (uint32_t)(int16_t)ld16(0x0603BC24u);  // 0603BBF4 mov.w 0x0603BC24,r2
L_0603BBF6:
    c.r[0] = c.r[1];  // 0603BBF6 mov r1,r0
    c.r[0] <<= 2;  // 0603BBF8 shll2 r0
    st32(c.r[0] + c.r[5], c.r[6]);  // 0603BBFA mov.l r6,@(r0,r5)
    c.r[1] += 1;  // 0603BBFC add #1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0603BBFE extu.w r1,r1
    c.t = c.r[1] > c.r[2];  // 0603BC00 cmp/hi r2,r1
    { const bool k = !c.t; st32(c.r[0] + c.r[7], c.r[3]); if (k) { SH2_POLL(c); goto L_0603BBF6; } }  // 0603BC02 bf/s 0x0603BBF6 ; mov.l r3,@(r0,r7)
    c.r[1] = ld32(0x0603BC30u);  // 0603BC06 mov.l 0x0603BC30,r1
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0603BC08 mov.w @r1,r0
    c.r[0] |= 0x20u;  // 0603BC0A or #32,r0
    st16(c.r[1], c.r[0]);  // 0603BC0C mov.w r0,@r1
    c.r[0] = c.r[11];  // 0603BC0E mov r11,r0
L_0603BC10:
    c.r[15] = c.r[14];  // 0603BC10 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603BC12 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603BC14 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0603BC16 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0603BC18 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0603BC1A mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603BC1C rts ; mov.l @r15+,r8
}

void f_0603BC40(SH2Context& c) {
    ran[917] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603BC40 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603BC42 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603BC44 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603BC46 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0603BC48 mov r15,r14
    c.r[9] = c.r[5];  // 0603BC4A mov r5,r9
    c.r[8] = c.r[4];  // 0603BC4C mov r4,r8
    c.r[8] += 54;  // 0603BC4E add #54,r8
    c.r[4] += 55;  // 0603BC50 add #55,r4
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[4]);  // 0603BC52 mov.b @r4,r4
    c.r[1] = ld32(0x0603BC70u);  // 0603BC54 mov.l 0x0603BC70,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603BC5Au; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603BC5Au) return; }  // 0603BC56 jsr @r1 ; extu.b r4,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603BC6Cu);  // 0603BC5A mov.w 0x0603BC6C,r1
    st16(c.r[8], c.r[1]);  // 0603BC5C mov.w r1,@r8
    c.r[15] = c.r[14];  // 0603BC5E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603BC60 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603BC62 mov.l @r15+,r14
    c.r[0] = c.r[9];  // 0603BC64 mov r9,r0
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0603BC66 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603BC68 rts ; mov.l @r15+,r8
}

void f_0603BC74(SH2Context& c) {
    ran[918] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603BC74 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0603BC76 mov r15,r14
    c.r[4] += 54;  // 0603BC78 add #54,r4
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[4]);  // 0603BC7A mov.w @r4,r4
    c.r[1] = 0x10u;  // 0603BC7C mov #16,r1
    c.r[2] = c.r[4] & 0xFFFFu;  // 0603BC7E extu.w r4,r2
    c.t = c.r[2] > c.r[1];  // 0603BC80 cmp/hi r1,r2
    { const bool k = c.t; c.r[7] = c.r[5]; if (k) { goto L_0603BCA8; } }  // 0603BC82 bt/s 0x0603BCA8 ; mov r5,r7
    c.r[1] = 0x2Cu;  // 0603BC86 mov #44,r1
    c.macl = (c.r[4] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 0603BC88 mulu.w r1,r4
    c.r[2] = c.macl;  // 0603BC8A sts macl,r2
    c.r[1] = ld32(0x0603BCB4u);  // 0603BC8C mov.l 0x0603BCB4,r1
    c.r[2] += c.r[1];  // 0603BC8E add r1,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0603BC90 mov.b @r2,r0
    c.r[3] = ld32(c.r[2] + 32);  // 0603BC92 mov.l @(32,r2),r3
    c.r[0] &= 0xF3u;  // 0603BC94 and #243,r0
    c.r[0] |= 0x4u;  // 0603BC96 or #4,r0
    st8(c.r[2], c.r[0]);  // 0603BC98 mov.b r0,@r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]); c.r[7] += 1;  // 0603BC9A mov.b @r7+,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0603BC9C mov.b @r2,r0
    c.r[3] += c.r[1];  // 0603BC9E add r1,r3
    st32(c.r[2] + 32, c.r[3]);  // 0603BCA0 mov.l r3,@(32,r2)
    c.r[0] |= 0x60u;  // 0603BCA2 or #96,r0
    st8(c.r[2], c.r[0]); goto L_0603BCAA;  // 0603BCA4 bra 0x0603BCAA ; mov.b r0,@r2
L_0603BCA8:
    c.r[7] += 1;  // 0603BCA8 add #1,r7
L_0603BCAA:
    c.r[0] = c.r[7];  // 0603BCAA mov r7,r0
    c.r[15] = c.r[14];  // 0603BCAC mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603BCAE rts ; mov.l @r15+,r14
}

void f_0603BCB8(SH2Context& c) {
    ran[919] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603BCB8 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0603BCBA mov r15,r14
    c.r[4] += 54;  // 0603BCBC add #54,r4
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[4]);  // 0603BCBE mov.w @r4,r4
    c.r[1] = 0x10u;  // 0603BCC0 mov #16,r1
    c.r[2] = c.r[4] & 0xFFFFu;  // 0603BCC2 extu.w r4,r2
    c.t = c.r[2] > c.r[1];  // 0603BCC4 cmp/hi r1,r2
    { const bool k = c.t; c.r[7] = c.r[5]; if (k) { goto L_0603BCEC; } }  // 0603BCC6 bt/s 0x0603BCEC ; mov r5,r7
    c.r[1] = 0x2Cu;  // 0603BCCA mov #44,r1
    c.macl = (c.r[4] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 0603BCCC mulu.w r1,r4
    c.r[2] = c.macl;  // 0603BCCE sts macl,r2
    c.r[1] = ld32(0x0603BCF8u);  // 0603BCD0 mov.l 0x0603BCF8,r1
    c.r[2] += c.r[1];  // 0603BCD2 add r1,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0603BCD4 mov.b @r2,r0
    c.r[3] = ld32(c.r[2] + 32);  // 0603BCD6 mov.l @(32,r2),r3
    c.r[0] &= 0xF3u;  // 0603BCD8 and #243,r0
    c.r[0] |= 0x8u;  // 0603BCDA or #8,r0
    st8(c.r[2], c.r[0]);  // 0603BCDC mov.b r0,@r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]); c.r[7] += 1;  // 0603BCDE mov.b @r7+,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0603BCE0 mov.b @r2,r0
    c.r[3] += c.r[1];  // 0603BCE2 add r1,r3
    st32(c.r[2] + 32, c.r[3]);  // 0603BCE4 mov.l r3,@(32,r2)
    c.r[0] |= 0x60u;  // 0603BCE6 or #96,r0
    st8(c.r[2], c.r[0]); goto L_0603BCEE;  // 0603BCE8 bra 0x0603BCEE ; mov.b r0,@r2
L_0603BCEC:
    c.r[7] += 1;  // 0603BCEC add #1,r7
L_0603BCEE:
    c.r[0] = c.r[7];  // 0603BCEE mov r7,r0
    c.r[15] = c.r[14];  // 0603BCF0 mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603BCF2 rts ; mov.l @r15+,r14
}

void f_0603BCFC(SH2Context& c) {
    ran[920] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603BCFC mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0603BCFE mov r15,r14
    c.r[4] += 54;  // 0603BD00 add #54,r4
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[4]);  // 0603BD02 mov.w @r4,r4
    c.r[1] = 0x10u;  // 0603BD04 mov #16,r1
    c.r[2] = c.r[4] & 0xFFFFu;  // 0603BD06 extu.w r4,r2
    c.t = c.r[2] > c.r[1];  // 0603BD08 cmp/hi r1,r2
    { const bool k = c.t; c.r[7] = c.r[5]; if (k) { goto L_0603BD30; } }  // 0603BD0A bt/s 0x0603BD30 ; mov r5,r7
    c.r[1] = 0x2Cu;  // 0603BD0E mov #44,r1
    c.macl = (c.r[4] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 0603BD10 mulu.w r1,r4
    c.r[2] = c.macl;  // 0603BD12 sts macl,r2
    c.r[1] = ld32(0x0603BD3Cu);  // 0603BD14 mov.l 0x0603BD3C,r1
    c.r[2] += c.r[1];  // 0603BD16 add r1,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0603BD18 mov.b @r2,r0
    c.r[3] = ld32(c.r[2] + 36);  // 0603BD1A mov.l @(36,r2),r3
    c.r[0] &= 0xF3u;  // 0603BD1C and #243,r0
    c.r[0] |= 0x4u;  // 0603BD1E or #4,r0
    st8(c.r[2], c.r[0]);  // 0603BD20 mov.b r0,@r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]); c.r[7] += 1;  // 0603BD22 mov.b @r7+,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0603BD24 mov.b @r2,r0
    c.r[3] += c.r[1];  // 0603BD26 add r1,r3
    st32(c.r[2] + 36, c.r[3]);  // 0603BD28 mov.l r3,@(36,r2)
    c.r[0] |= 0x60u;  // 0603BD2A or #96,r0
    st8(c.r[2], c.r[0]); goto L_0603BD32;  // 0603BD2C bra 0x0603BD32 ; mov.b r0,@r2
L_0603BD30:
    c.r[7] += 1;  // 0603BD30 add #1,r7
L_0603BD32:
    c.r[0] = c.r[7];  // 0603BD32 mov r7,r0
    c.r[15] = c.r[14];  // 0603BD34 mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603BD36 rts ; mov.l @r15+,r14
}

void f_0603BD40(SH2Context& c) {
    ran[921] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603BD40 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0603BD42 mov r15,r14
    c.r[4] += 54;  // 0603BD44 add #54,r4
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[4]);  // 0603BD46 mov.w @r4,r4
    c.r[1] = 0x10u;  // 0603BD48 mov #16,r1
    c.r[2] = c.r[4] & 0xFFFFu;  // 0603BD4A extu.w r4,r2
    c.t = c.r[2] > c.r[1];  // 0603BD4C cmp/hi r1,r2
    { const bool k = c.t; c.r[7] = c.r[5]; if (k) { goto L_0603BD74; } }  // 0603BD4E bt/s 0x0603BD74 ; mov r5,r7
    c.r[1] = 0x2Cu;  // 0603BD52 mov #44,r1
    c.macl = (c.r[4] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 0603BD54 mulu.w r1,r4
    c.r[2] = c.macl;  // 0603BD56 sts macl,r2
    c.r[1] = ld32(0x0603BD80u);  // 0603BD58 mov.l 0x0603BD80,r1
    c.r[2] += c.r[1];  // 0603BD5A add r1,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0603BD5C mov.b @r2,r0
    c.r[3] = ld32(c.r[2] + 36);  // 0603BD5E mov.l @(36,r2),r3
    c.r[0] &= 0xF3u;  // 0603BD60 and #243,r0
    c.r[0] |= 0x8u;  // 0603BD62 or #8,r0
    st8(c.r[2], c.r[0]);  // 0603BD64 mov.b r0,@r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]); c.r[7] += 1;  // 0603BD66 mov.b @r7+,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0603BD68 mov.b @r2,r0
    c.r[3] += c.r[1];  // 0603BD6A add r1,r3
    st32(c.r[2] + 36, c.r[3]);  // 0603BD6C mov.l r3,@(36,r2)
    c.r[0] |= 0x60u;  // 0603BD6E or #96,r0
    st8(c.r[2], c.r[0]); goto L_0603BD76;  // 0603BD70 bra 0x0603BD76 ; mov.b r0,@r2
L_0603BD74:
    c.r[7] += 1;  // 0603BD74 add #1,r7
L_0603BD76:
    c.r[0] = c.r[7];  // 0603BD76 mov r7,r0
    c.r[15] = c.r[14];  // 0603BD78 mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603BD7A rts ; mov.l @r15+,r14
}

void f_0603BD84(SH2Context& c) {
    ran[922] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603BD84 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0603BD86 mov r15,r14
    c.r[4] += 54;  // 0603BD88 add #54,r4
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[4]);  // 0603BD8A mov.w @r4,r4
    c.r[1] = 0x10u;  // 0603BD8C mov #16,r1
    c.r[2] = c.r[4] & 0xFFFFu;  // 0603BD8E extu.w r4,r2
    c.t = c.r[2] > c.r[1];  // 0603BD90 cmp/hi r1,r2
    { const bool k = c.t; c.r[7] = c.r[5]; if (k) { goto L_0603BDB8; } }  // 0603BD92 bt/s 0x0603BDB8 ; mov r5,r7
    c.r[1] = 0x2Cu;  // 0603BD96 mov #44,r1
    c.macl = (c.r[4] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 0603BD98 mulu.w r1,r4
    c.r[2] = c.macl;  // 0603BD9A sts macl,r2
    c.r[1] = ld32(0x0603BDC4u);  // 0603BD9C mov.l 0x0603BDC4,r1
    c.r[2] += c.r[1];  // 0603BD9E add r1,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0603BDA0 mov.b @r2,r0
    c.r[3] = ld32(c.r[2] + 40);  // 0603BDA2 mov.l @(40,r2),r3
    c.r[0] &= 0xF3u;  // 0603BDA4 and #243,r0
    c.r[0] |= 0x4u;  // 0603BDA6 or #4,r0
    st8(c.r[2], c.r[0]);  // 0603BDA8 mov.b r0,@r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]); c.r[7] += 1;  // 0603BDAA mov.b @r7+,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0603BDAC mov.b @r2,r0
    c.r[3] += c.r[1];  // 0603BDAE add r1,r3
    st32(c.r[2] + 40, c.r[3]);  // 0603BDB0 mov.l r3,@(40,r2)
    c.r[0] |= 0x60u;  // 0603BDB2 or #96,r0
    st8(c.r[2], c.r[0]); goto L_0603BDBA;  // 0603BDB4 bra 0x0603BDBA ; mov.b r0,@r2
L_0603BDB8:
    c.r[7] += 1;  // 0603BDB8 add #1,r7
L_0603BDBA:
    c.r[0] = c.r[7];  // 0603BDBA mov r7,r0
    c.r[15] = c.r[14];  // 0603BDBC mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603BDBE rts ; mov.l @r15+,r14
}

void f_0603BDC8(SH2Context& c) {
    ran[923] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603BDC8 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0603BDCA mov r15,r14
    c.r[4] += 54;  // 0603BDCC add #54,r4
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[4]);  // 0603BDCE mov.w @r4,r4
    c.r[1] = 0x10u;  // 0603BDD0 mov #16,r1
    c.r[2] = c.r[4] & 0xFFFFu;  // 0603BDD2 extu.w r4,r2
    c.t = c.r[2] > c.r[1];  // 0603BDD4 cmp/hi r1,r2
    { const bool k = c.t; c.r[7] = c.r[5]; if (k) { goto L_0603BDFC; } }  // 0603BDD6 bt/s 0x0603BDFC ; mov r5,r7
    c.r[1] = 0x2Cu;  // 0603BDDA mov #44,r1
    c.macl = (c.r[4] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 0603BDDC mulu.w r1,r4
    c.r[2] = c.macl;  // 0603BDDE sts macl,r2
    c.r[1] = ld32(0x0603BE08u);  // 0603BDE0 mov.l 0x0603BE08,r1
    c.r[2] += c.r[1];  // 0603BDE2 add r1,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0603BDE4 mov.b @r2,r0
    c.r[3] = ld32(c.r[2] + 40);  // 0603BDE6 mov.l @(40,r2),r3
    c.r[0] &= 0xF3u;  // 0603BDE8 and #243,r0
    c.r[0] |= 0x8u;  // 0603BDEA or #8,r0
    st8(c.r[2], c.r[0]);  // 0603BDEC mov.b r0,@r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]); c.r[7] += 1;  // 0603BDEE mov.b @r7+,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0603BDF0 mov.b @r2,r0
    c.r[3] += c.r[1];  // 0603BDF2 add r1,r3
    st32(c.r[2] + 40, c.r[3]);  // 0603BDF4 mov.l r3,@(40,r2)
    c.r[0] |= 0x60u;  // 0603BDF6 or #96,r0
    st8(c.r[2], c.r[0]); goto L_0603BDFE;  // 0603BDF8 bra 0x0603BDFE ; mov.b r0,@r2
L_0603BDFC:
    c.r[7] += 1;  // 0603BDFC add #1,r7
L_0603BDFE:
    c.r[0] = c.r[7];  // 0603BDFE mov r7,r0
    c.r[15] = c.r[14];  // 0603BE00 mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603BE02 rts ; mov.l @r15+,r14
}

void f_0603BE0C(SH2Context& c) {
    ran[924] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603BE0C mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0603BE0E mov r15,r14
    c.r[0] = c.r[5];  // 0603BE10 mov r5,r0
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603BE12 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] += 2; c.pc = x; return; }  // 0603BE14 rts ; add #2,r0
}

void f_0603BE18(SH2Context& c) {
    ran[925] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603BE18 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603BE1A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0603BE1C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603BE1E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603BE20 sts.l pr,@-r15
    c.r[9] = c.r[5];  // 0603BE22 mov r5,r9
    c.r[1] = c.r[9];  // 0603BE24 mov r9,r1
    c.r[1] += 1;  // 0603BE26 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603BE28 mov.b @r1,r1
    c.r[14] = c.r[15];  // 0603BE2A mov r15,r14
    c.r[8] = c.r[1] & 0xFFu;  // 0603BE2C extu.b r1,r8
    c.r[1] = 0x1u;  // 0603BE2E mov #1,r1
    c.r[1] &= c.r[8];  // 0603BE30 and r8,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603BE32 tst r1,r1
    { const bool k = c.t; c.r[10] = c.r[8]; if (k) { goto L_0603BE40; } }  // 0603BE34 bt/s 0x0603BE40 ; mov r8,r10
    c.r[5] = (uint32_t)(int16_t)ld16(0x0603BF00u);  // 0603BE38 mov.w 0x0603BF00,r5
    c.r[1] = ld32(0x0603BF04u);  // 0603BE3A mov.l 0x0603BF04,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603BE40u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603BE40u) return; }  // 0603BE3C jsr @r1 ; mov #1,r4
L_0603BE40:
    c.r[1] = 0x2u;  // 0603BE40 mov #2,r1
    c.r[1] &= c.r[8];  // 0603BE42 and r8,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603BE44 tst r1,r1
    { const bool k = c.t; c.r[1] = 0x4u; if (k) { goto L_0603BE54; } }  // 0603BE46 bt/s 0x0603BE54 ; mov #4,r1
    c.r[5] = (uint32_t)(int16_t)ld16(0x0603BF00u);  // 0603BE4A mov.w 0x0603BF00,r5
    c.r[1] = ld32(0x0603BF04u);  // 0603BE4C mov.l 0x0603BF04,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603BE52u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603BE52u) return; }  // 0603BE4E jsr @r1 ; mov #0,r4
    c.r[1] = 0x4u;  // 0603BE52 mov #4,r1
L_0603BE54:
    c.r[1] &= c.r[8];  // 0603BE54 and r8,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603BE56 tst r1,r1
    { const bool k = c.t; c.r[1] = 0x8u; if (k) { goto L_0603BE66; } }  // 0603BE58 bt/s 0x0603BE66 ; mov #8,r1
    c.r[5] = (uint32_t)(int16_t)ld16(0x0603BF00u);  // 0603BE5C mov.w 0x0603BF00,r5
    c.r[1] = ld32(0x0603BF04u);  // 0603BE5E mov.l 0x0603BF04,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603BE64u; c.r[4] = 0x3u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603BE64u) return; }  // 0603BE60 jsr @r1 ; mov #3,r4
    c.r[1] = 0x8u;  // 0603BE64 mov #8,r1
L_0603BE66:
    c.r[1] &= c.r[8];  // 0603BE66 and r8,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603BE68 tst r1,r1
    { const bool k = c.t; c.r[2] = 0x10u; if (k) { goto L_0603BE78; } }  // 0603BE6A bt/s 0x0603BE78 ; mov #16,r2
    c.r[5] = (uint32_t)(int16_t)ld16(0x0603BF00u);  // 0603BE6E mov.w 0x0603BF00,r5
    c.r[1] = ld32(0x0603BF04u);  // 0603BE70 mov.l 0x0603BF04,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603BE76u; c.r[4] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603BE76u) return; }  // 0603BE72 jsr @r1 ; mov #2,r4
    c.r[2] = 0x10u;  // 0603BE76 mov #16,r2
L_0603BE78:
    c.r[8] &= c.r[2];  // 0603BE78 and r2,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 0603BE7A tst r8,r8
    { const bool k = c.t; c.r[2] = 0x20u; if (k) { goto L_0603BE8A; } }  // 0603BE7C bt/s 0x0603BE8A ; mov #32,r2
    c.r[5] = (uint32_t)(int16_t)ld16(0x0603BF00u);  // 0603BE80 mov.w 0x0603BF00,r5
    c.r[1] = ld32(0x0603BF04u);  // 0603BE82 mov.l 0x0603BF04,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603BE88u; c.r[4] = 0x5u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603BE88u) return; }  // 0603BE84 jsr @r1 ; mov #5,r4
    c.r[2] = 0x20u;  // 0603BE88 mov #32,r2
L_0603BE8A:
    c.r[10] &= c.r[2];  // 0603BE8A and r2,r10
    c.t = (c.r[10] & c.r[10]) == 0;  // 0603BE8C tst r10,r10
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_0603BE9C; } }  // 0603BE8E bt/s 0x0603BE9C ; mov r9,r1
    c.r[5] = (uint32_t)(int16_t)ld16(0x0603BF00u);  // 0603BE92 mov.w 0x0603BF00,r5
    c.r[1] = ld32(0x0603BF04u);  // 0603BE94 mov.l 0x0603BF04,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603BE9Au; c.r[4] = 0x4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603BE9Au) return; }  // 0603BE96 jsr @r1 ; mov #4,r4
    c.r[1] = c.r[9];  // 0603BE9A mov r9,r1
L_0603BE9C:
    c.r[1] += 2;  // 0603BE9C add #2,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603BE9E mov.b @r1,r4
    c.r[4] = c.r[4] & 0xFFu;  // 0603BEA0 extu.b r4,r4
    c.r[1] = c.r[9];  // 0603BEA2 mov r9,r1
    c.r[1] += 3;  // 0603BEA4 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603BEA6 mov.b @r1,r1
    c.r[4] <<= 8;  // 0603BEA8 shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 0603BEAA extu.b r1,r1
    c.r[4] |= c.r[1];  // 0603BEAC or r1,r4
    c.r[1] = c.r[9];  // 0603BEAE mov r9,r1
    c.r[1] += 4;  // 0603BEB0 add #4,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603BEB2 mov.b @r1,r5
    c.r[5] = c.r[5] & 0xFFu;  // 0603BEB4 extu.b r5,r5
    c.r[1] = c.r[9];  // 0603BEB6 mov r9,r1
    c.r[1] += 5;  // 0603BEB8 add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603BEBA mov.b @r1,r1
    c.r[5] <<= 8;  // 0603BEBC shll8 r5
    c.r[1] = c.r[1] & 0xFFu;  // 0603BEBE extu.b r1,r1
    c.r[5] |= c.r[1];  // 0603BEC0 or r1,r5
    c.r[1] = c.r[9];  // 0603BEC2 mov r9,r1
    c.r[1] += 6;  // 0603BEC4 add #6,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603BEC6 mov.b @r1,r6
    c.r[6] = c.r[6] & 0xFFu;  // 0603BEC8 extu.b r6,r6
    c.r[1] = c.r[9];  // 0603BECA mov r9,r1
    c.r[1] += 7;  // 0603BECC add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603BECE mov.b @r1,r1
    c.r[6] <<= 8;  // 0603BED0 shll8 r6
    c.r[1] = c.r[1] & 0xFFu;  // 0603BED2 extu.b r1,r1
    c.r[6] |= c.r[1];  // 0603BED4 or r1,r6
    c.r[1] = c.r[9];  // 0603BED6 mov r9,r1
    c.r[1] += 8;  // 0603BED8 add #8,r1
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603BEDA mov.b @r1,r7
    c.r[7] = c.r[7] & 0xFFu;  // 0603BEDC extu.b r7,r7
    c.r[1] = c.r[9];  // 0603BEDE mov r9,r1
    c.r[1] += 9;  // 0603BEE0 add #9,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603BEE2 mov.b @r1,r1
    c.r[7] <<= 8;  // 0603BEE4 shll8 r7
    c.r[1] = c.r[1] & 0xFFu;  // 0603BEE6 extu.b r1,r1
    c.r[7] |= c.r[1];  // 0603BEE8 or r1,r7
    c.r[1] = ld32(0x0603BF08u);  // 0603BEEA mov.l 0x0603BF08,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603BEF0u; c.r[9] += 10; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603BEF0u) return; }  // 0603BEEC jsr @r1 ; add #10,r9
    c.r[15] = c.r[14];  // 0603BEF0 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603BEF2 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603BEF4 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0603BEF6 mov.l @r15+,r10
    c.r[0] = c.r[9];  // 0603BEF8 mov r9,r0
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0603BEFA mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603BEFC rts ; mov.l @r15+,r8
}

void f_0603BF0C(SH2Context& c) {
    ran[926] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603BF0C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603BF0E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0603BF10 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0603BF12 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0603BF14 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603BF16 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603BF18 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0603BF1A mov r15,r14
    c.r[8] = c.r[4];  // 0603BF1C mov r4,r8
    c.r[10] = c.r[5];  // 0603BF1E mov r5,r10
    c.r[1] = c.r[10];  // 0603BF20 mov r10,r1
    c.r[1] += 1;  // 0603BF22 add #1,r1
    c.r[3] = c.r[8];  // 0603BF24 mov r8,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603BF26 mov.b @r1,r2
    c.r[3] += 67;  // 0603BF28 add #67,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0603BF2A extu.b r2,r2
    c.r[1] = c.r[10];  // 0603BF2C mov r10,r1
    c.r[1] += 2;  // 0603BF2E add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603BF30 mov.b @r1,r1
    c.r[2] <<= 8;  // 0603BF32 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603BF34 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0603BF36 or r1,r2
    c.r[11] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0603BF38 exts.w r2,r11
    c.r[1] = c.r[10];  // 0603BF3A mov r10,r1
    c.r[1] += 3;  // 0603BF3C add #3,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603BF3E mov.b @r1,r2
    c.r[6] = c.r[8];  // 0603BF40 mov r8,r6
    c.r[2] = c.r[2] & 0xFFu;  // 0603BF42 extu.b r2,r2
    c.r[1] = c.r[10];  // 0603BF44 mov r10,r1
    c.r[1] += 4;  // 0603BF46 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603BF48 mov.b @r1,r1
    c.r[2] <<= 8;  // 0603BF4A shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603BF4C extu.b r1,r1
    c.r[2] |= c.r[1];  // 0603BF4E or r1,r2
    c.r[12] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0603BF50 exts.w r2,r12
    c.r[2] = c.r[8];  // 0603BF52 mov r8,r2
    c.r[1] = c.r[10];  // 0603BF54 mov r10,r1
    c.r[1] += 5;  // 0603BF56 add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603BF58 mov.b @r1,r1
    c.r[2] += 68;  // 0603BF5A add #68,r2
    st8(c.r[2], c.r[1]);  // 0603BF5C mov.b r1,@r2
    st8(c.r[3], c.r[1]);  // 0603BF5E mov.b r1,@r3
    c.r[9] = c.r[1] & 0xFFu;  // 0603BF60 extu.b r1,r9
    c.r[1] = ld32(0x0603C034u);  // 0603BF62 mov.l 0x0603C034,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603BF64 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0603BF66 extu.b r1,r1
    c.r[0] = c.r[1];  // 0603BF68 mov r1,r0
    c.r[0] >>= 2;  // 0603BF6A shlr2 r0
    c.r[0] >>= 2;  // 0603BF6C shlr2 r0
    c.r[0] >>= 2;  // 0603BF6E shlr2 r0
    c.r[1] >>= 2;  // 0603BF70 shlr2 r1
    c.r[1] >>= 2;  // 0603BF72 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0603BF74 shlr r1
    c.r[1] >>= 2;  // 0603BF76 shlr2 r1
    c.r[0] &= 0x1u;  // 0603BF78 and #1,r0
    c.t = c.r[1] == c.r[0];  // 0603BF7A cmp/eq r0,r1
    { const bool k = c.t; c.r[6] += 16; if (k) { goto L_0603BF84; } }  // 0603BF7C bt/s 0x0603BF84 ; add #16,r6
    c.r[4] = 0u - c.r[11]; goto L_0603BF86;  // 0603BF80 bra 0x0603BF86 ; neg r11,r4
L_0603BF84:
    c.r[4] = c.r[11];  // 0603BF84 mov r11,r4
L_0603BF86:
    c.r[7] = ld32(0x0603C038u);  // 0603BF86 mov.l 0x0603C038,r7
    { const uint32_t x = c.r[7]; c.pr = 0x0603BF8Cu; c.r[5] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603BF8Cu) return; }  // 0603BF88 jsr @r7 ; mov r9,r5
    c.r[4] = c.r[0];  // 0603BF8C mov r0,r4
    st16(c.r[6], c.r[4]);  // 0603BF8E mov.w r4,@r6
    c.r[6] = c.r[8];  // 0603BF90 mov r8,r6
    c.r[6] += 18;  // 0603BF92 add #18,r6
    c.r[4] = c.r[12];  // 0603BF94 mov r12,r4
    c.r[7] = ld32(0x0603C038u);  // 0603BF96 mov.l 0x0603C038,r7
    { const uint32_t x = c.r[7]; c.pr = 0x0603BF9Cu; c.r[5] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603BF9Cu) return; }  // 0603BF98 jsr @r7 ; mov r9,r5
    st16(c.r[6], c.r[0]);  // 0603BF9C mov.w r0,@r6
    c.r[1] = ld32(0x0603C034u);  // 0603BF9E mov.l 0x0603C034,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603BFA0 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0603BFA2 extu.b r1,r1
    c.r[0] = c.r[1];  // 0603BFA4 mov r1,r0
    c.r[0] >>= 2;  // 0603BFA6 shlr2 r0
    c.r[0] >>= 2;  // 0603BFA8 shlr2 r0
    c.r[0] >>= 2;  // 0603BFAA shlr2 r0
    c.r[1] >>= 2;  // 0603BFAC shlr2 r1
    c.r[1] >>= 2;  // 0603BFAE shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0603BFB0 shlr r1
    c.r[1] >>= 2;  // 0603BFB2 shlr2 r1
    c.r[0] &= 0x1u;  // 0603BFB4 and #1,r0
    c.t = c.r[1] == c.r[0];  // 0603BFB6 cmp/eq r0,r1
    { const bool k = c.t; c.r[1] = c.r[8]; if (k) { goto L_0603BFCC; } }  // 0603BFB8 bt/s 0x0603BFCC ; mov r8,r1
    c.r[1] += 16;  // 0603BFBC add #16,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0603BFBE mov.w @r1,r1
    c.macl = c.r[1] * c.r[9];  // 0603BFC0 mul.l r9,r1
    c.r[2] = 0u - c.r[11];  // 0603BFC2 neg r11,r2
    c.r[1] = c.macl;  // 0603BFC4 sts macl,r1
    c.r[2] -= c.r[1];  // 0603BFC6 sub r1,r2
    c.r[4] = (uint32_t)(int32_t)(int16_t)c.r[2]; goto L_0603BFD8;  // 0603BFC8 bra 0x0603BFD8 ; exts.w r2,r4
L_0603BFCC:
    c.r[1] += 16;  // 0603BFCC add #16,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0603BFCE mov.w @r1,r1
    c.macl = c.r[1] * c.r[9];  // 0603BFD0 mul.l r9,r1
    c.r[1] = c.macl;  // 0603BFD2 sts macl,r1
    c.r[11] -= c.r[1];  // 0603BFD4 sub r1,r11
    c.r[4] = (uint32_t)(int32_t)(int16_t)c.r[11];  // 0603BFD6 exts.w r11,r4
L_0603BFD8:
    c.r[2] = c.r[8];  // 0603BFD8 mov r8,r2
    c.r[2] += 18;  // 0603BFDA add #18,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0603BFDC mov.w @r2,r1
    c.macl = c.r[1] * c.r[9];  // 0603BFDE mul.l r9,r1
    c.r[1] = c.macl;  // 0603BFE0 sts macl,r1
    c.r[12] -= c.r[1];  // 0603BFE2 sub r1,r12
    c.r[1] = c.r[8];  // 0603BFE4 mov r8,r1
    c.r[1] += 1;  // 0603BFE6 add #1,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603BFE8 mov.b @r1,r0
    c.r[0] &= 0xFDu;  // 0603BFEA and #253,r0
    st8(c.r[1], c.r[0]);  // 0603BFEC mov.b r0,@r1
    c.r[1] = c.r[8];  // 0603BFEE mov r8,r1
    c.r[1] += 16;  // 0603BFF0 add #16,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0603BFF2 mov.w @r1,r1
    c.r[4] += c.r[1];  // 0603BFF4 add r1,r4
    c.r[1] = ld32(c.r[8] + 4);  // 0603BFF6 mov.l @(4,r8),r1
    c.r[15] = c.r[14];  // 0603BFF8 mov r14,r15
    c.r[1] += c.r[4];  // 0603BFFA add r4,r1
    st32(c.r[8] + 4, c.r[1]);  // 0603BFFC mov.l r1,@(4,r8)
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0603BFFE mov.w @r2,r1
    c.r[3] = (uint32_t)(int32_t)(int16_t)c.r[12];  // 0603C000 exts.w r12,r3
    c.r[3] += c.r[1];  // 0603C002 add r1,r3
    c.r[2] = c.r[8];  // 0603C004 mov r8,r2
    c.r[1] = ld32(c.r[8] + 8);  // 0603C006 mov.l @(8,r8),r1
    c.r[2] += 67;  // 0603C008 add #67,r2
    c.r[1] += c.r[3];  // 0603C00A add r3,r1
    st32(c.r[8] + 8, c.r[1]);  // 0603C00C mov.l r1,@(8,r8)
    c.r[8] += 68;  // 0603C00E add #68,r8
    c.r[1] = c.r[9];  // 0603C010 mov r9,r1
    c.r[1] -= 1;  // 0603C012 add #-1,r1
    st8(c.r[8], c.r[1]);  // 0603C014 mov.b r1,@r8
    st8(c.r[2], c.r[1]);  // 0603C016 mov.b r1,@r2
    c.r[2] = ld32(0x0603C03Cu);  // 0603C018 mov.l 0x0603C03C,r2
    c.r[1] = 0x1u;  // 0603C01A mov #1,r1
    st8(c.r[2], c.r[1]);  // 0603C01C mov.b r1,@r2
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603C01E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603C020 mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0603C022 mov.l @r15+,r12
    c.r[10] += 6;  // 0603C024 add #6,r10
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0603C026 mov.l @r15+,r11
    c.r[0] = c.r[10];  // 0603C028 mov r10,r0
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0603C02A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0603C02C mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603C02E rts ; mov.l @r15+,r8
}

void f_0603C040(SH2Context& c) {
    ran[927] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603C040 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603C042 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0603C044 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0603C046 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0603C048 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0603C04A mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603C04C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603C04E sts.l pr,@-r15
    c.r[15] -= 4;  // 0603C050 add #-4,r15
    c.r[11] = c.r[5];  // 0603C052 mov r5,r11
    c.r[1] = c.r[11];  // 0603C054 mov r11,r1
    c.r[1] += 1;  // 0603C056 add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603C058 mov.b @r1,r2
    c.r[14] = c.r[15];  // 0603C05A mov r15,r14
    c.r[2] = c.r[2] & 0xFFu;  // 0603C05C extu.b r2,r2
    c.r[1] = c.r[11];  // 0603C05E mov r11,r1
    c.r[1] += 2;  // 0603C060 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603C062 mov.b @r1,r1
    c.r[2] <<= 8;  // 0603C064 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603C066 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0603C068 or r1,r2
    c.r[9] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0603C06A exts.w r2,r9
    c.r[1] = c.r[11];  // 0603C06C mov r11,r1
    c.r[1] += 3;  // 0603C06E add #3,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603C070 mov.b @r1,r2
    c.r[8] = c.r[4];  // 0603C072 mov r4,r8
    c.r[2] = c.r[2] & 0xFFu;  // 0603C074 extu.b r2,r2
    c.r[1] = c.r[11];  // 0603C076 mov r11,r1
    c.r[1] += 4;  // 0603C078 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603C07A mov.b @r1,r1
    c.r[2] <<= 8;  // 0603C07C shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603C07E extu.b r1,r1
    c.r[2] |= c.r[1];  // 0603C080 or r1,r2
    c.r[1] = c.r[11];  // 0603C082 mov r11,r1
    c.r[1] += 5;  // 0603C084 add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603C086 mov.b @r1,r1
    c.r[12] = c.r[9];  // 0603C088 mov r9,r12
    c.r[10] = c.r[1] & 0xFFu;  // 0603C08A extu.b r1,r10
    c.r[1] = ld32(0x0603C1B4u);  // 0603C08C mov.l 0x0603C1B4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603C08E mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0603C090 extu.b r1,r1
    c.r[0] = c.r[1];  // 0603C092 mov r1,r0
    c.r[0] >>= 2;  // 0603C094 shlr2 r0
    c.r[0] >>= 2;  // 0603C096 shlr2 r0
    c.r[0] >>= 2;  // 0603C098 shlr2 r0
    c.r[1] >>= 2;  // 0603C09A shlr2 r1
    c.r[1] >>= 2;  // 0603C09C shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0603C09E shlr r1
    c.r[1] >>= 2;  // 0603C0A0 shlr2 r1
    c.r[0] &= 0x1u;  // 0603C0A2 and #1,r0
    c.t = c.r[1] == c.r[0];  // 0603C0A4 cmp/eq r0,r1
    { const bool k = c.t; c.r[13] = (uint32_t)(int32_t)(int16_t)c.r[2]; if (k) { goto L_0603C11A; } }  // 0603C0A6 bt/s 0x0603C11A ; exts.w r2,r13
    c.r[1] = c.r[8];  // 0603C0AA mov r8,r1
    c.r[1] += 1;  // 0603C0AC add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603C0AE mov.b @r1,r1
    c.r[0] = c.r[1];  // 0603C0B0 mov r1,r0
    c.r[0] >>= 2;  // 0603C0B2 shlr2 r0
    c.r[0] >>= 2;  // 0603C0B4 shlr2 r0
    c.r[0] &= 0x1u;  // 0603C0B6 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603C0B8 tst r0,r0
    { const bool k = c.t; c.r[6] = c.r[8]; if (k) { goto L_0603C0E4; } }  // 0603C0BA bt/s 0x0603C0E4 ; mov r8,r6
    c.r[6] += 16;  // 0603C0BE add #16,r6
    c.r[9] = 0u - c.r[9];  // 0603C0C0 neg r9,r9
    c.r[4] = c.r[9];  // 0603C0C2 mov r9,r4
    c.r[5] = c.r[10];  // 0603C0C4 mov r10,r5
    c.r[1] = ld32(c.r[8] + 4);  // 0603C0C6 mov.l @(4,r8),r1
    c.r[7] = ld32(0x0603C1B8u);  // 0603C0C8 mov.l 0x0603C1B8,r7
    { const uint32_t x = c.r[7]; c.pr = 0x0603C0CEu; c.r[4] -= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603C0CEu) return; }  // 0603C0CA jsr @r7 ; sub r1,r4
    c.r[7] = c.r[0];  // 0603C0CE mov r0,r7
    st16(c.r[6], c.r[7]);  // 0603C0D0 mov.w r7,@r6
    c.r[1] = c.r[8];  // 0603C0D2 mov r8,r1
    c.r[1] += 6;  // 0603C0D4 add #6,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0603C0D6 mov.w @r1,r1
    st32(c.r[14], c.r[9]);  // 0603C0D8 mov.l r9,@r14
    c.r[0] = ld32(c.r[14]);  // 0603C0DA mov.l @r14,r0
    c.r[0] -= c.r[1];  // 0603C0DC sub r1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[6]);  // 0603C0DE mov.w @r6,r1
    c.macl = c.r[1] * c.r[10]; goto L_0603C10C;  // 0603C0E0 bra 0x0603C10C ; mul.l r10,r1
L_0603C0E4:
    c.r[6] += 16;  // 0603C0E4 add #16,r6
    c.r[0] = (uint32_t)(int16_t)ld16(0x0603C1B2u);  // 0603C0E6 mov.w 0x0603C1B2,r0
    st32(c.r[14], c.r[0]);  // 0603C0E8 mov.l r0,@r14
    c.r[4] = c.r[0];  // 0603C0EA mov r0,r4
    c.r[5] = c.r[10];  // 0603C0EC mov r10,r5
    c.r[1] = ld32(c.r[8] + 4);  // 0603C0EE mov.l @(4,r8),r1
    c.r[7] = ld32(0x0603C1B8u);  // 0603C0F0 mov.l 0x0603C1B8,r7
    c.r[4] -= c.r[1];  // 0603C0F2 sub r1,r4
    { const uint32_t x = c.r[7]; c.pr = 0x0603C0F8u; c.r[4] -= c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603C0F8u) return; }  // 0603C0F4 jsr @r7 ; sub r9,r4
    c.r[7] = c.r[0];  // 0603C0F8 mov r0,r7
    st16(c.r[6], c.r[7]);  // 0603C0FA mov.w r7,@r6
    c.r[1] = c.r[8];  // 0603C0FC mov r8,r1
    c.r[1] += 6;  // 0603C0FE add #6,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0603C100 mov.w @r1,r1
    c.r[0] = ld32(c.r[14]);  // 0603C102 mov.l @r14,r0
    c.r[0] -= c.r[1];  // 0603C104 sub r1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[6]);  // 0603C106 mov.w @r6,r1
    c.macl = c.r[1] * c.r[10];  // 0603C108 mul.l r10,r1
    c.r[0] -= c.r[9];  // 0603C10A sub r9,r0
L_0603C10C:
    c.r[1] = c.macl;  // 0603C10C sts macl,r1
    c.r[0] -= c.r[1];  // 0603C10E sub r1,r0
    st32(c.r[14], c.r[0]);  // 0603C110 mov.l r0,@r14
    c.r[0] = 0x2u;  // 0603C112 mov #2,r0
    c.r[0] += c.r[14];  // 0603C114 add r14,r0
    c.r[9] = (uint32_t)(int16_t)ld16(c.r[0]); goto L_0603C13E;  // 0603C116 bra 0x0603C13E ; mov.w @r0,r9
L_0603C11A:
    c.r[6] = c.r[8];  // 0603C11A mov r8,r6
    c.r[6] += 16;  // 0603C11C add #16,r6
    c.r[4] = c.r[12];  // 0603C11E mov r12,r4
    c.r[5] = c.r[10];  // 0603C120 mov r10,r5
    c.r[1] = ld32(c.r[8] + 4);  // 0603C122 mov.l @(4,r8),r1
    c.r[7] = ld32(0x0603C1B8u);  // 0603C124 mov.l 0x0603C1B8,r7
    { const uint32_t x = c.r[7]; c.pr = 0x0603C12Au; c.r[4] -= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603C12Au) return; }  // 0603C126 jsr @r7 ; sub r1,r4
    st16(c.r[6], c.r[0]);  // 0603C12A mov.w r0,@r6
    c.r[1] = c.r[8];  // 0603C12C mov r8,r1
    c.r[1] += 6;  // 0603C12E add #6,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0603C130 mov.w @r1,r1
    c.r[12] -= c.r[1];  // 0603C132 sub r1,r12
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[6]);  // 0603C134 mov.w @r6,r1
    c.macl = c.r[1] * c.r[10];  // 0603C136 mul.l r10,r1
    c.r[1] = c.macl;  // 0603C138 sts macl,r1
    c.r[12] -= c.r[1];  // 0603C13A sub r1,r12
    c.r[9] = (uint32_t)(int32_t)(int16_t)c.r[12];  // 0603C13C exts.w r12,r9
L_0603C13E:
    c.r[6] = c.r[8];  // 0603C13E mov r8,r6
    c.r[6] += 18;  // 0603C140 add #18,r6
    c.r[4] = c.r[13];  // 0603C142 mov r13,r4
    c.r[5] = c.r[10];  // 0603C144 mov r10,r5
    c.r[1] = ld32(c.r[8] + 8);  // 0603C146 mov.l @(8,r8),r1
    c.r[7] = ld32(0x0603C1B8u);  // 0603C148 mov.l 0x0603C1B8,r7
    { const uint32_t x = c.r[7]; c.pr = 0x0603C14Eu; c.r[4] -= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603C14Eu) return; }  // 0603C14A jsr @r7 ; sub r1,r4
    st16(c.r[6], c.r[0]);  // 0603C14E mov.w r0,@r6
    c.r[1] = c.r[8];  // 0603C150 mov r8,r1
    c.r[1] += 10;  // 0603C152 add #10,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0603C154 mov.w @r1,r1
    c.r[13] -= c.r[1];  // 0603C156 sub r1,r13
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[6]);  // 0603C158 mov.w @r6,r1
    c.macl = c.r[1] * c.r[10];  // 0603C15A mul.l r10,r1
    c.r[1] = c.macl;  // 0603C15C sts macl,r1
    c.r[13] -= c.r[1];  // 0603C15E sub r1,r13
    c.r[1] = c.r[8];  // 0603C160 mov r8,r1
    c.r[1] += 1;  // 0603C162 add #1,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603C164 mov.b @r1,r0
    c.r[0] &= 0xFDu;  // 0603C166 and #253,r0
    st8(c.r[1], c.r[0]);  // 0603C168 mov.b r0,@r1
    c.r[1] = c.r[8];  // 0603C16A mov r8,r1
    c.r[1] += 16;  // 0603C16C add #16,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0603C16E mov.w @r1,r1
    c.r[9] += c.r[1];  // 0603C170 add r1,r9
    c.r[1] = ld32(c.r[8] + 4);  // 0603C172 mov.l @(4,r8),r1
    c.r[14] += 4;  // 0603C174 add #4,r14
    c.r[1] += c.r[9];  // 0603C176 add r9,r1
    st32(c.r[8] + 4, c.r[1]);  // 0603C178 mov.l r1,@(4,r8)
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[6]);  // 0603C17A mov.w @r6,r1
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[13];  // 0603C17C exts.w r13,r2
    c.r[2] += c.r[1];  // 0603C17E add r1,r2
    c.r[1] = ld32(c.r[8] + 8);  // 0603C180 mov.l @(8,r8),r1
    c.r[15] = c.r[14];  // 0603C182 mov r14,r15
    c.r[1] += c.r[2];  // 0603C184 add r2,r1
    st32(c.r[8] + 8, c.r[1]);  // 0603C186 mov.l r1,@(8,r8)
    c.r[2] = c.r[8];  // 0603C188 mov r8,r2
    c.r[2] += 67;  // 0603C18A add #67,r2
    c.r[8] += 68;  // 0603C18C add #68,r8
    c.r[1] = c.r[10];  // 0603C18E mov r10,r1
    c.r[1] -= 1;  // 0603C190 add #-1,r1
    st8(c.r[8], c.r[1]);  // 0603C192 mov.b r1,@r8
    st8(c.r[2], c.r[1]);  // 0603C194 mov.b r1,@r2
    c.r[2] = ld32(0x0603C1BCu);  // 0603C196 mov.l 0x0603C1BC,r2
    c.r[1] = 0x1u;  // 0603C198 mov #1,r1
    st8(c.r[2], c.r[1]);  // 0603C19A mov.b r1,@r2
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603C19C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603C19E mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0603C1A0 mov.l @r15+,r13
    c.r[11] += 6;  // 0603C1A2 add #6,r11
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0603C1A4 mov.l @r15+,r12
    c.r[0] = c.r[11];  // 0603C1A6 mov r11,r0
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0603C1A8 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0603C1AA mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0603C1AC mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603C1AE rts ; mov.l @r15+,r8
}

void f_0603C1C0(SH2Context& c) {
    ran[928] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603C1C0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603C1C2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0603C1C4 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0603C1C6 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0603C1C8 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0603C1CA mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603C1CC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603C1CE sts.l pr,@-r15
    c.r[15] -= 12;  // 0603C1D0 add #-12,r15
    c.r[14] = c.r[15];  // 0603C1D2 mov r15,r14
    st32(c.r[14] + 8, c.r[5]);  // 0603C1D4 mov.l r5,@(8,r14)
    c.r[3] = 0x6u;  // 0603C1D6 mov #6,r3
    st16(c.r[14], c.r[3]);  // 0603C1D8 mov.w r3,@r14
    c.r[1] = c.r[14];  // 0603C1DA mov r14,r1
    c.r[1] += 2;  // 0603C1DC add #2,r1
    c.r[2] = 0x16u;  // 0603C1DE mov #22,r2
    st16(c.r[1], c.r[2]);  // 0603C1E0 mov.w r2,@r1
    c.r[1] = c.r[14];  // 0603C1E2 mov r14,r1
    c.r[1] += 4;  // 0603C1E4 add #4,r1
    st16(c.r[1], c.r[2]);  // 0603C1E6 mov.w r2,@r1
    c.r[1] = c.r[14];  // 0603C1E8 mov r14,r1
    c.r[1] += 6;  // 0603C1EA add #6,r1
    st16(c.r[1], c.r[3]);  // 0603C1EC mov.w r3,@r1
    c.r[1] = ld32(0x0603C258u);  // 0603C1EE mov.l 0x0603C258,r1
    c.r[2] = 0x2u;  // 0603C1F0 mov #2,r2
    c.r[12] = 0x0u;  // 0603C1F2 mov #0,r12
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603C1F4 mov.b @r1,r1
    c.r[13] = 0x3u;  // 0603C1F6 mov #3,r13
    c.r[1] = c.r[1] & 0xFFu;  // 0603C1F8 extu.b r1,r1
    c.r[0] = c.r[1];  // 0603C1FA mov r1,r0
    c.r[0] >>= 2;  // 0603C1FC shlr2 r0
    c.r[0] >>= 2;  // 0603C1FE shlr2 r0
    c.r[0] &= 0x4u;  // 0603C200 and #4,r0
    c.r[0] += c.r[14];  // 0603C202 add r14,r0
    c.r[1] >>= 2;  // 0603C204 shlr2 r1
    c.r[1] >>= 2;  // 0603C206 shlr2 r1
    c.r[1] &= c.r[2];  // 0603C208 and r2,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0603C20A mov.w @(r0,r1),r1
    c.r[11] = 0x40u;  // 0603C20C mov #64,r11
    c.r[10] = c.r[1] & 0xFFFFu;  // 0603C20E extu.w r1,r10
L_0603C210:
    c.r[8] = 0x0u;  // 0603C210 mov #0,r8
    c.r[9] = c.r[11];  // 0603C212 mov r11,r9
L_0603C214:
    c.r[5] = c.r[10];  // 0603C214 mov r10,r5
    c.r[5] += c.r[8];  // 0603C216 add r8,r5
    c.r[5] = c.r[5] & 0xFFu;  // 0603C218 extu.b r5,r5
    c.r[4] = c.r[9] & 0xFFFFu;  // 0603C21A extu.w r9,r4
    c.r[7] = 0x10u;  // 0603C21C mov #16,r7
    c.r[2] = ld32(0x0603C25Cu);  // 0603C21E mov.l 0x0603C25C,r2
    { const uint32_t x = c.r[2]; c.pr = 0x0603C224u; c.r[6] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603C224u) return; }  // 0603C220 jsr @r2 ; mov #0,r6
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603C256u);  // 0603C224 mov.w 0x0603C256,r1
    c.r[8] += 1;  // 0603C226 add #1,r8
    c.t = (int32_t)c.r[8] > (int32_t)c.r[13];  // 0603C228 cmp/gt r13,r8
    { const bool k = !c.t; c.r[9] += c.r[1]; if (k) { SH2_POLL(c); goto L_0603C214; } }  // 0603C22A bf/s 0x0603C214 ; add r1,r9
    c.r[11] += 16;  // 0603C22E add #16,r11
    c.r[12] += 1;  // 0603C230 add #1,r12
    c.t = (int32_t)c.r[12] > (int32_t)c.r[13];  // 0603C232 cmp/gt r13,r12
    { const bool k = !c.t; c.r[10] += 4; if (k) { SH2_POLL(c); goto L_0603C210; } }  // 0603C234 bf/s 0x0603C210 ; add #4,r10
    c.r[2] = ld32(c.r[14] + 8);  // 0603C238 mov.l @(8,r14),r2
    c.r[2] += 1;  // 0603C23A add #1,r2
    st32(c.r[14] + 8, c.r[2]);  // 0603C23C mov.l r2,@(8,r14)
    c.r[0] = ld32(c.r[14] + 8);  // 0603C23E mov.l @(8,r14),r0
    c.r[14] += 12;  // 0603C240 add #12,r14
    c.r[15] = c.r[14];  // 0603C242 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603C244 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603C246 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0603C248 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0603C24A mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0603C24C mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0603C24E mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0603C250 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603C252 rts ; mov.l @r15+,r8
}

void f_0603C260(SH2Context& c) {
    ran[929] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603C260 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603C262 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0603C264 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0603C266 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0603C268 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0603C26A mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603C26C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603C26E sts.l pr,@-r15
    c.r[15] -= 12;  // 0603C270 add #-12,r15
    c.r[14] = c.r[15];  // 0603C272 mov r15,r14
    st32(c.r[14] + 8, c.r[5]);  // 0603C274 mov.l r5,@(8,r14)
    c.r[3] = 0x6u;  // 0603C276 mov #6,r3
    st16(c.r[14], c.r[3]);  // 0603C278 mov.w r3,@r14
    c.r[1] = c.r[14];  // 0603C27A mov r14,r1
    c.r[1] += 2;  // 0603C27C add #2,r1
    c.r[2] = 0x16u;  // 0603C27E mov #22,r2
    st16(c.r[1], c.r[2]);  // 0603C280 mov.w r2,@r1
    c.r[1] = c.r[14];  // 0603C282 mov r14,r1
    c.r[1] += 4;  // 0603C284 add #4,r1
    st16(c.r[1], c.r[2]);  // 0603C286 mov.w r2,@r1
    c.r[1] = c.r[14];  // 0603C288 mov r14,r1
    c.r[1] += 6;  // 0603C28A add #6,r1
    st16(c.r[1], c.r[3]);  // 0603C28C mov.w r3,@r1
    c.r[1] = ld32(0x0603C2FCu);  // 0603C28E mov.l 0x0603C2FC,r1
    c.r[2] = 0x2u;  // 0603C290 mov #2,r2
    c.r[12] = 0x0u;  // 0603C292 mov #0,r12
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603C294 mov.b @r1,r1
    c.r[13] = 0x3u;  // 0603C296 mov #3,r13
    c.r[1] = c.r[1] & 0xFFu;  // 0603C298 extu.b r1,r1
    c.r[0] = c.r[1];  // 0603C29A mov r1,r0
    c.r[0] >>= 2;  // 0603C29C shlr2 r0
    c.r[0] >>= 2;  // 0603C29E shlr2 r0
    c.r[0] &= 0x4u;  // 0603C2A0 and #4,r0
    c.r[0] += c.r[14];  // 0603C2A2 add r14,r0
    c.r[1] >>= 2;  // 0603C2A4 shlr2 r1
    c.r[1] >>= 2;  // 0603C2A6 shlr2 r1
    c.r[1] &= c.r[2];  // 0603C2A8 and r2,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0603C2AA mov.w @(r0,r1),r1
    c.r[11] = 0x40u;  // 0603C2AC mov #64,r11
    c.r[10] = c.r[1] & 0xFFFFu;  // 0603C2AE extu.w r1,r10
L_0603C2B0:
    c.r[8] = 0x0u;  // 0603C2B0 mov #0,r8
    c.r[9] = c.r[11];  // 0603C2B2 mov r11,r9
L_0603C2B4:
    c.r[7] = c.r[10];  // 0603C2B4 mov r10,r7
    c.r[7] += c.r[8];  // 0603C2B6 add r8,r7
    c.r[7] <<= 2;  // 0603C2B8 shll2 r7
    c.r[7] <<= 2;  // 0603C2BA shll2 r7
    c.r[7] = c.r[7] & 0xFFFFu;  // 0603C2BC extu.w r7,r7
    c.r[4] = c.r[9] & 0xFFFFu;  // 0603C2BE extu.w r9,r4
    c.r[6] = 0xFFFFFFFFu;  // 0603C2C0 mov #-1,r6
    c.r[2] = ld32(0x0603C300u);  // 0603C2C2 mov.l 0x0603C300,r2
    { const uint32_t x = c.r[2]; c.pr = 0x0603C2C8u; c.r[5] = 0x10u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603C2C8u) return; }  // 0603C2C4 jsr @r2 ; mov #16,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603C2FAu);  // 0603C2C8 mov.w 0x0603C2FA,r1
    c.r[8] += 1;  // 0603C2CA add #1,r8
    c.t = (int32_t)c.r[8] > (int32_t)c.r[13];  // 0603C2CC cmp/gt r13,r8
    { const bool k = !c.t; c.r[9] += c.r[1]; if (k) { SH2_POLL(c); goto L_0603C2B4; } }  // 0603C2CE bf/s 0x0603C2B4 ; add r1,r9
    c.r[11] += 16;  // 0603C2D2 add #16,r11
    c.r[12] += 1;  // 0603C2D4 add #1,r12
    c.t = (int32_t)c.r[12] > (int32_t)c.r[13];  // 0603C2D6 cmp/gt r13,r12
    { const bool k = !c.t; c.r[10] += 4; if (k) { SH2_POLL(c); goto L_0603C2B0; } }  // 0603C2D8 bf/s 0x0603C2B0 ; add #4,r10
    c.r[2] = ld32(c.r[14] + 8);  // 0603C2DC mov.l @(8,r14),r2
    c.r[2] += 1;  // 0603C2DE add #1,r2
    st32(c.r[14] + 8, c.r[2]);  // 0603C2E0 mov.l r2,@(8,r14)
    c.r[0] = ld32(c.r[14] + 8);  // 0603C2E2 mov.l @(8,r14),r0
    c.r[14] += 12;  // 0603C2E4 add #12,r14
    c.r[15] = c.r[14];  // 0603C2E6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603C2E8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603C2EA mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0603C2EC mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0603C2EE mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0603C2F0 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0603C2F2 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0603C2F4 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603C2F6 rts ; mov.l @r15+,r8
}

void f_0603C304(SH2Context& c) {
    ran[930] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603C304 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603C306 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0603C308 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0603C30A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0603C30C mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0603C30E mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603C310 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603C312 sts.l pr,@-r15
    c.r[15] -= 20;  // 0603C314 add #-20,r15
    c.r[14] = c.r[15];  // 0603C316 mov r15,r14
    st32(c.r[14] + 12, c.r[5]);  // 0603C318 mov.l r5,@(12,r14)
    c.r[3] = 0x6u;  // 0603C31A mov #6,r3
    st16(c.r[14], c.r[3]);  // 0603C31C mov.w r3,@r14
    c.r[1] = c.r[14];  // 0603C31E mov r14,r1
    c.r[1] += 2;  // 0603C320 add #2,r1
    c.r[2] = 0x16u;  // 0603C322 mov #22,r2
    st16(c.r[1], c.r[2]);  // 0603C324 mov.w r2,@r1
    c.r[1] = c.r[14];  // 0603C326 mov r14,r1
    c.r[1] += 4;  // 0603C328 add #4,r1
    st16(c.r[1], c.r[2]);  // 0603C32A mov.w r2,@r1
    c.r[1] = c.r[14];  // 0603C32C mov r14,r1
    c.r[1] += 6;  // 0603C32E add #6,r1
    st16(c.r[1], c.r[3]);  // 0603C330 mov.w r3,@r1
    c.r[4] = c.r[14];  // 0603C332 mov r14,r4
    c.r[1] = ld32(c.r[14] + 12);  // 0603C334 mov.l @(12,r14),r1
    c.r[4] += 8;  // 0603C336 add #8,r4
    c.r[1] += 1;  // 0603C338 add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603C33A mov.b @r1,r2
    c.r[0] = ld32(0x0603C3C4u);  // 0603C33C mov.l 0x0603C3C4,r0
    c.r[1] = ld32(c.r[14] + 12);  // 0603C33E mov.l @(12,r14),r1
    c.r[2] = c.r[2] & 0xFFu;  // 0603C340 extu.b r2,r2
    c.r[1] += 2;  // 0603C342 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603C344 mov.b @r1,r1
    c.r[2] <<= 8;  // 0603C346 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603C348 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0603C34A or r1,r2
    { const uint32_t x = c.r[0]; c.pr = 0x0603C350u; st16(c.r[4], c.r[2]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603C350u) return; }  // 0603C34C jsr @r0 ; mov.w r2,@r4
    c.r[2] = ld32(0x0603C3C8u);  // 0603C350 mov.l 0x0603C3C8,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0603C352 mov.w @r2,r1
    c.t = (int32_t)c.r[1] >= 0;  // 0603C354 cmp/pz r1
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0603C356 mov.w @r2,r6
    c.r[3] = (uint32_t)(int16_t)ld16(0x0603C3C2u);  // 0603C358 mov.w 0x0603C3C2,r3
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[3];  // 0603C35A exts.w r3,r1
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[6];  // 0603C35C exts.w r6,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0603C35E cmp/gt r1,r2
    { const bool k = !c.t; c.r[13] = c.r[0] & 0xFFFFu; if (k) { goto L_0603C366; } }  // 0603C360 bf/s 0x0603C366 ; extu.w r0,r13
    c.r[6] = c.r[3];  // 0603C364 mov r3,r6
L_0603C366:
    c.r[6] = (uint32_t)(int32_t)(int16_t)c.r[6];  // 0603C366 exts.w r6,r6
    st32(c.r[14] + 16, c.r[6]);  // 0603C368 mov.l r6,@(16,r14)
    c.r[11] = 0x3u;  // 0603C36A mov #3,r11
    c.r[10] = 0x40u;  // 0603C36C mov #64,r10
    c.r[9] = 0x0u;  // 0603C36E mov #0,r9
L_0603C370:
    c.r[8] = c.r[10];  // 0603C370 mov r10,r8
L_0603C372:
    c.r[1] = c.r[14];  // 0603C372 mov r14,r1
    c.r[1] += 8;  // 0603C374 add #8,r1
    c.r[4] = c.r[8] & 0xFFFFu;  // 0603C376 extu.w r8,r4
    c.r[5] = 0x10u;  // 0603C378 mov #16,r5
    c.r[7] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0603C37A mov.w @r1,r7
    c.r[12] = ld32(0x0603C3CCu);  // 0603C37C mov.l 0x0603C3CC,r12
    c.r[6] = ld32(c.r[14] + 16);  // 0603C37E mov.l @(16,r14),r6
    c.r[7] <<= 2;  // 0603C380 shll2 r7
    c.r[7] <<= 2;  // 0603C382 shll2 r7
    c.r[7] += c.r[13];  // 0603C384 add r13,r7
    { const uint32_t x = c.r[12]; c.pr = 0x0603C38Au; c.r[7] = c.r[7] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603C38Au) return; }  // 0603C386 jsr @r12 ; extu.w r7,r7
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603C3C2u);  // 0603C38A mov.w 0x0603C3C2,r1
    c.r[9] += 1;  // 0603C38C add #1,r9
    c.t = (int32_t)c.r[9] > (int32_t)c.r[11];  // 0603C38E cmp/gt r11,r9
    { const bool k = !c.t; c.r[8] += c.r[1]; if (k) { SH2_POLL(c); goto L_0603C372; } }  // 0603C390 bf/s 0x0603C372 ; add r1,r8
    c.r[10] += 16;  // 0603C394 add #16,r10
    c.r[1] = c.r[11];  // 0603C396 mov r11,r1
    c.r[1] <<= 2;  // 0603C398 shll2 r1
    c.r[1] <<= 2;  // 0603C39A shll2 r1
    c.r[1] += 64;  // 0603C39C add #64,r1
    c.t = (int32_t)c.r[10] > (int32_t)c.r[1];  // 0603C39E cmp/gt r1,r10
    { const bool k = !c.t; c.r[9] = 0x0u; if (k) { SH2_POLL(c); goto L_0603C370; } }  // 0603C3A0 bf/s 0x0603C370 ; mov #0,r9
    c.r[12] = ld32(c.r[14] + 12);  // 0603C3A4 mov.l @(12,r14),r12
    c.r[12] += 3;  // 0603C3A6 add #3,r12
    st32(c.r[14] + 12, c.r[12]);  // 0603C3A8 mov.l r12,@(12,r14)
    c.r[0] = ld32(c.r[14] + 12);  // 0603C3AA mov.l @(12,r14),r0
    c.r[14] += 20;  // 0603C3AC add #20,r14
    c.r[15] = c.r[14];  // 0603C3AE mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603C3B0 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603C3B2 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0603C3B4 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0603C3B6 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0603C3B8 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0603C3BA mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0603C3BC mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603C3BE rts ; mov.l @r15+,r8
}

void f_0603C3D0(SH2Context& c) {
    ran[931] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603C3D0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603C3D2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0603C3D4 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603C3D6 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603C3D8 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0603C3DA mov r15,r14
    c.r[8] = ld32(0x0603C440u);  // 0603C3DC mov.l 0x0603C440,r8
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[8]);  // 0603C3DE mov.w @r8,r2
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0603C3E0 exts.w r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603C3E2 tst r1,r1
    { const bool k = c.t; c.r[9] = c.r[5]; if (k) { goto L_0603C414; } }  // 0603C3E4 bt/s 0x0603C414 ; mov r5,r9
    c.r[1] = c.r[2];  // 0603C3E8 mov r2,r1
    c.r[1] += 16;  // 0603C3EA add #16,r1
    st16(c.r[8], c.r[1]);  // 0603C3EC mov.w r1,@r8
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[8]);  // 0603C3EE mov.w @r8,r4
    c.r[10] = ld32(0x0603C444u);  // 0603C3F0 mov.l 0x0603C444,r10
    c.r[6] = c.r[4];  // 0603C3F2 mov r4,r6
    { const uint32_t x = c.r[10]; c.pr = 0x0603C3F8u; c.r[5] = c.r[4]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603C3F8u) return; }  // 0603C3F4 jsr @r10 ; mov r4,r5
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[8]);  // 0603C3F8 mov.w @r8,r1
    c.t = (int32_t)c.r[1] >= 0;  // 0603C3FA cmp/pz r1
    if (!c.t) { goto L_0603C428; }  // 0603C3FC bf 0x0603C428
    c.r[1] = ld32(0x0603C448u);  // 0603C3FE mov.l 0x0603C448,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603C404u; c.r[4] = 0x4Fu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603C404u) return; }  // 0603C400 jsr @r1 ; mov #79,r4
    c.r[6] = 0x0u;  // 0603C404 mov #0,r6
    c.r[5] = 0x0u;  // 0603C406 mov #0,r5
    { const uint32_t x = c.r[10]; c.pr = 0x0603C40Cu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603C40Cu) return; }  // 0603C408 jsr @r10 ; mov #0,r4
    c.r[1] = 0x0u;  // 0603C40C mov #0,r1
    st16(c.r[8], c.r[1]);  // 0603C40E mov.w r1,@r8
    c.r[9] += 1; goto L_0603C428;  // 0603C410 bra 0x0603C428 ; add #1,r9
L_0603C414:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603C43Eu);  // 0603C414 mov.w 0x0603C43E,r1
    st16(c.r[8], c.r[1]);  // 0603C416 mov.w r1,@r8
    c.r[1] = ld32(0x0603C448u);  // 0603C418 mov.l 0x0603C448,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603C41Eu; c.r[4] = 0x3u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603C41Eu) return; }  // 0603C41A jsr @r1 ; mov #3,r4
    c.r[4] = (uint32_t)(int16_t)ld16(0x0603C43Eu);  // 0603C41E mov.w 0x0603C43E,r4
    c.r[1] = ld32(0x0603C444u);  // 0603C420 mov.l 0x0603C444,r1
    c.r[6] = c.r[4];  // 0603C422 mov r4,r6
    { const uint32_t x = c.r[1]; c.pr = 0x0603C428u; c.r[5] = c.r[4]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603C428u) return; }  // 0603C424 jsr @r1 ; mov r4,r5
L_0603C428:
    c.r[2] = ld32(0x0603C44Cu);  // 0603C428 mov.l 0x0603C44C,r2
    c.r[1] = 0x1u;  // 0603C42A mov #1,r1
    st8(c.r[2], c.r[1]);  // 0603C42C mov.b r1,@r2
    c.r[15] = c.r[14];  // 0603C42E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603C430 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603C432 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0603C434 mov.l @r15+,r10
    c.r[0] = c.r[9];  // 0603C436 mov r9,r0
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0603C438 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603C43A rts ; mov.l @r15+,r8
}

void f_0603C450(SH2Context& c) {
    ran[932] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603C450 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603C452 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0603C454 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603C456 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603C458 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0603C45A mov r15,r14
    c.r[8] = ld32(0x0603C4BCu);  // 0603C45C mov.l 0x0603C4BC,r8
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[8]);  // 0603C45E mov.w @r8,r2
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0603C460 exts.w r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603C462 tst r1,r1
    { const bool k = c.t; c.r[9] = c.r[5]; if (k) { goto L_0603C48E; } }  // 0603C464 bt/s 0x0603C48E ; mov r5,r9
    c.r[1] = c.r[2];  // 0603C468 mov r2,r1
    c.r[1] -= 16;  // 0603C46A add #-16,r1
    st16(c.r[8], c.r[1]);  // 0603C46C mov.w r1,@r8
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[8]);  // 0603C46E mov.w @r8,r4
    c.r[10] = ld32(0x0603C4C0u);  // 0603C470 mov.l 0x0603C4C0,r10
    c.r[6] = c.r[4];  // 0603C472 mov r4,r6
    { const uint32_t x = c.r[10]; c.pr = 0x0603C478u; c.r[5] = c.r[4]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603C478u) return; }  // 0603C474 jsr @r10 ; mov r4,r5
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[8]);  // 0603C478 mov.w @r8,r1
    c.r[4] = (uint32_t)(int16_t)ld16(0x0603C4B8u);  // 0603C47A mov.w 0x0603C4B8,r4
    c.t = (int32_t)c.r[1] > (int32_t)c.r[4];  // 0603C47C cmp/gt r4,r1
    { const bool k = c.t; c.r[6] = c.r[4]; if (k) { goto L_0603C4A2; } }  // 0603C47E bt/s 0x0603C4A2 ; mov r4,r6
    { const uint32_t x = c.r[10]; c.pr = 0x0603C486u; c.r[5] = c.r[4]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603C486u) return; }  // 0603C482 jsr @r10 ; mov r4,r5
    c.r[1] = 0x0u;  // 0603C486 mov #0,r1
    st16(c.r[8], c.r[1]);  // 0603C488 mov.w r1,@r8
    c.r[9] += 1; goto L_0603C4A2;  // 0603C48A bra 0x0603C4A2 ; add #1,r9
L_0603C48E:
    c.r[1] = 0xFFFFFFFFu;  // 0603C48E mov #-1,r1
    st16(c.r[8], c.r[1]);  // 0603C490 mov.w r1,@r8
    c.r[1] = ld32(0x0603C4C4u);  // 0603C492 mov.l 0x0603C4C4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603C498u; c.r[4] = 0x3u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603C498u) return; }  // 0603C494 jsr @r1 ; mov #3,r4
    c.r[1] = ld32(0x0603C4C0u);  // 0603C498 mov.l 0x0603C4C0,r1
    c.r[6] = 0x0u;  // 0603C49A mov #0,r6
    c.r[5] = 0x0u;  // 0603C49C mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0603C4A2u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603C4A2u) return; }  // 0603C49E jsr @r1 ; mov #0,r4
L_0603C4A2:
    c.r[2] = ld32(0x0603C4C8u);  // 0603C4A2 mov.l 0x0603C4C8,r2
    c.r[1] = 0x1u;  // 0603C4A4 mov #1,r1
    st8(c.r[2], c.r[1]);  // 0603C4A6 mov.b r1,@r2
    c.r[15] = c.r[14];  // 0603C4A8 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603C4AA lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603C4AC mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0603C4AE mov.l @r15+,r10
    c.r[0] = c.r[9];  // 0603C4B0 mov r9,r0
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0603C4B2 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603C4B4 rts ; mov.l @r15+,r8
}

void f_0603C4CC(SH2Context& c) {
    ran[933] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603C4CC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603C4CE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0603C4D0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603C4D2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603C4D4 sts.l pr,@-r15
    c.r[15] -= 4;  // 0603C4D6 add #-4,r15
    c.r[14] = c.r[15];  // 0603C4D8 mov r15,r14
    c.r[8] = c.r[5];  // 0603C4DA mov r5,r8
    c.r[1] = c.r[8];  // 0603C4DC mov r8,r1
    c.r[1] += 1;  // 0603C4DE add #1,r1
    c.r[7] = c.r[8];  // 0603C4E0 mov r8,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603C4E2 mov.b @r1,r1
    c.r[7] += 5;  // 0603C4E4 add #5,r7
    c.r[1] = c.r[1] & 0xFFu;  // 0603C4E6 extu.b r1,r1
    c.r[10] = c.r[1];  // 0603C4E8 mov r1,r10
    c.r[10] <<= 8;  // 0603C4EA shll8 r10
    c.r[1] = c.r[8];  // 0603C4EC mov r8,r1
    c.r[1] += 2;  // 0603C4EE add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603C4F0 mov.b @r1,r1
    c.r[3] = c.r[8];  // 0603C4F2 mov r8,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0603C4F4 extu.b r1,r1
    c.r[10] |= c.r[1];  // 0603C4F6 or r1,r10
    c.r[1] = c.r[8];  // 0603C4F8 mov r8,r1
    c.r[1] += 3;  // 0603C4FA add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603C4FC mov.b @r1,r1
    c.r[3] += 6;  // 0603C4FE add #6,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0603C500 mov.b @r7,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603C502 extu.b r1,r1
    c.r[9] = c.r[1];  // 0603C504 mov r1,r9
    c.r[9] <<= 8;  // 0603C506 shll8 r9
    c.r[1] = c.r[8];  // 0603C508 mov r8,r1
    c.r[1] += 4;  // 0603C50A add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603C50C mov.b @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0603C50E extu.b r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603C510 extu.b r1,r1
    c.r[9] |= c.r[1];  // 0603C512 or r1,r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0603C514 mov.b @r3,r1
    c.r[2] <<= 8;  // 0603C516 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603C518 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0603C51A or r1,r2
    st16(c.r[14], c.r[2]);  // 0603C51C mov.w r2,@r14
    c.r[1] = ld32(0x0603C568u);  // 0603C51E mov.l 0x0603C568,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603C520 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0603C522 extu.b r1,r0
    c.t = c.r[0] == 0x1u;  // 0603C524 cmp/eq #1,r0
    if (!c.t) { goto L_0603C532; }  // 0603C526 bf 0x0603C532
    c.r[0] = ld32(0x0603C56Cu);  // 0603C528 mov.l 0x0603C56C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0603C52Eu; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603C52Eu) return; }  // 0603C52A jsr @r0 ; mov r14,r4
    c.r[0] = c.r[0] & 0xFFFFu; goto L_0603C53C;  // 0603C52E bra 0x0603C53C ; extu.w r0,r0
L_0603C532:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0603C532 mov.b @r7,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0603C534 extu.b r1,r1
    st16(c.r[14], c.r[1]);  // 0603C536 mov.w r1,@r14
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0603C538 mov.b @r3,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0603C53A extu.b r1,r0
L_0603C53C:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603C566u);  // 0603C53C mov.w 0x0603C566,r1
    c.r[9] &= c.r[1];  // 0603C53E and r1,r9
    c.r[6] = c.r[0] & 0xFFu;  // 0603C540 extu.b r0,r6
    c.r[1] = c.r[14];  // 0603C542 mov r14,r1
    c.r[1] += 1;  // 0603C544 add #1,r1
    c.r[7] = c.r[9];  // 0603C546 mov r9,r7
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603C548 mov.b @r1,r5
    c.r[4] = c.r[10];  // 0603C54A mov r10,r4
    c.r[1] = ld32(0x0603C570u);  // 0603C54C mov.l 0x0603C570,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603C552u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603C552u) return; }  // 0603C54E jsr @r1 ; extu.b r5,r5
    c.r[14] += 4;  // 0603C552 add #4,r14
    c.r[15] = c.r[14];  // 0603C554 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603C556 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603C558 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0603C55A mov.l @r15+,r10
    c.r[8] += 7;  // 0603C55C add #7,r8
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0603C55E mov.l @r15+,r9
    c.r[0] = c.r[8];  // 0603C560 mov r8,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603C562 rts ; mov.l @r15+,r8
}

void f_0603C574(SH2Context& c) {
    ran[934] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603C574 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603C576 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0603C578 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603C57A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603C57C sts.l pr,@-r15
    c.r[15] -= 4;  // 0603C57E add #-4,r15
    c.r[14] = c.r[15];  // 0603C580 mov r15,r14
    c.r[8] = c.r[5];  // 0603C582 mov r5,r8
    c.r[1] = c.r[8];  // 0603C584 mov r8,r1
    c.r[1] += 1;  // 0603C586 add #1,r1
    c.r[7] = c.r[8];  // 0603C588 mov r8,r7
    c.r[7] += 5;  // 0603C58A add #5,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603C58C mov.b @r1,r1
    c.r[3] = c.r[8];  // 0603C58E mov r8,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0603C590 extu.b r1,r1
    c.r[10] = c.r[1];  // 0603C592 mov r1,r10
    c.r[10] <<= 8;  // 0603C594 shll8 r10
    c.r[1] = c.r[8];  // 0603C596 mov r8,r1
    c.r[1] += 2;  // 0603C598 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603C59A mov.b @r1,r1
    c.r[3] += 6;  // 0603C59C add #6,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0603C59E mov.b @r7,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603C5A0 extu.b r1,r1
    c.r[10] |= c.r[1];  // 0603C5A2 or r1,r10
    c.r[1] = c.r[8];  // 0603C5A4 mov r8,r1
    c.r[1] += 3;  // 0603C5A6 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603C5A8 mov.b @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0603C5AA extu.b r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603C5AC extu.b r1,r1
    c.r[9] = c.r[1];  // 0603C5AE mov r1,r9
    c.r[9] <<= 8;  // 0603C5B0 shll8 r9
    c.r[1] = c.r[8];  // 0603C5B2 mov r8,r1
    c.r[1] += 4;  // 0603C5B4 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603C5B6 mov.b @r1,r1
    c.r[4] = c.r[10];  // 0603C5B8 mov r10,r4
    c.r[1] = c.r[1] & 0xFFu;  // 0603C5BA extu.b r1,r1
    c.r[9] |= c.r[1];  // 0603C5BC or r1,r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0603C5BE mov.b @r3,r1
    c.r[2] <<= 8;  // 0603C5C0 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603C5C2 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0603C5C4 or r1,r2
    st16(c.r[14], c.r[2]);  // 0603C5C6 mov.w r2,@r14
    c.r[1] = ld32(0x0603C618u);  // 0603C5C8 mov.l 0x0603C618,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603C5CA mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0603C5CC extu.b r1,r0
    c.t = c.r[0] == 0x1u;  // 0603C5CE cmp/eq #1,r0
    { const bool k = !c.t; c.r[5] = c.r[9]; if (k) { goto L_0603C5EE; } }  // 0603C5D0 bf/s 0x0603C5EE ; mov r9,r5
    c.r[0] = ld32(0x0603C61Cu);  // 0603C5D4 mov.l 0x0603C61C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0603C5DAu; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603C5DAu) return; }  // 0603C5D6 jsr @r0 ; mov r14,r4
    c.r[7] = c.r[0] & 0xFFFFu;  // 0603C5DA extu.w r0,r7
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[14]);  // 0603C5DC mov.w @r14,r1
    c.r[6] = 0xFFFFFFFFu;  // 0603C5DE mov #-1,r6
    c.r[5] = c.r[9];  // 0603C5E0 mov r9,r5
    c.r[4] = c.r[10];  // 0603C5E2 mov r10,r4
    c.r[1] <<= 2;  // 0603C5E4 shll2 r1
    c.r[1] <<= 2;  // 0603C5E6 shll2 r1
    c.r[7] += c.r[1];  // 0603C5E8 add r1,r7
    c.r[7] = c.r[7] & 0xFFFFu; goto L_0603C5FE;  // 0603C5EA bra 0x0603C5FE ; extu.w r7,r7
L_0603C5EE:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0603C5EE mov.b @r7,r1
    c.r[6] = 0xFFFFFFFFu;  // 0603C5F0 mov #-1,r6
    c.r[1] = c.r[1] & 0xFFu;  // 0603C5F2 extu.b r1,r1
    st16(c.r[14], c.r[1]);  // 0603C5F4 mov.w r1,@r14
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0603C5F6 mov.b @r3,r2
    c.r[1] <<= 8;  // 0603C5F8 shll8 r1
    c.r[7] = c.r[2] & 0xFFu;  // 0603C5FA extu.b r2,r7
    c.r[7] |= c.r[1];  // 0603C5FC or r1,r7
L_0603C5FE:
    c.r[1] = ld32(0x0603C620u);  // 0603C5FE mov.l 0x0603C620,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603C604u; c.r[8] += 7; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603C604u) return; }  // 0603C600 jsr @r1 ; add #7,r8
    c.r[14] += 4;  // 0603C604 add #4,r14
    c.r[15] = c.r[14];  // 0603C606 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603C608 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603C60A mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0603C60C mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0603C60E mov.l @r15+,r9
    c.r[0] = c.r[8];  // 0603C610 mov r8,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603C612 rts ; mov.l @r15+,r8
}

void f_0603C668(SH2Context& c) {
    ran[935] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603C668 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603C66A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0603C66C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603C66E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603C670 sts.l pr,@-r15
    c.r[15] -= 68;  // 0603C672 add #-68,r15
    c.r[14] = c.r[15];  // 0603C674 mov r15,r14
    c.r[8] = c.r[5];  // 0603C676 mov r5,r8
    c.r[5] = ld32(0x0603C738u);  // 0603C678 mov.l 0x0603C738,r5
    c.r[1] = ld32(0x0603C73Cu);  // 0603C67A mov.l 0x0603C73C,r1
    c.r[6] = 0x42u;  // 0603C67C mov #66,r6
    { const uint32_t x = c.r[1]; c.pr = 0x0603C682u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603C682u) return; }  // 0603C67E jsr @r1 ; mov r14,r4
    c.r[1] = c.r[8];  // 0603C682 mov r8,r1
    c.r[1] += 1;  // 0603C684 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603C686 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0603C688 extu.b r1,r1
    c.r[10] = c.r[1];  // 0603C68A mov r1,r10
    c.r[10] <<= 8;  // 0603C68C shll8 r10
    c.r[1] = c.r[8];  // 0603C68E mov r8,r1
    c.r[1] += 2;  // 0603C690 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603C692 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0603C694 extu.b r1,r1
    c.r[10] |= c.r[1];  // 0603C696 or r1,r10
    c.r[1] = c.r[8];  // 0603C698 mov r8,r1
    c.r[1] += 3;  // 0603C69A add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603C69C mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0603C69E extu.b r1,r1
    c.r[9] = c.r[1];  // 0603C6A0 mov r1,r9
    c.r[9] <<= 8;  // 0603C6A2 shll8 r9
    c.r[1] = c.r[8];  // 0603C6A4 mov r8,r1
    c.r[1] += 4;  // 0603C6A6 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603C6A8 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0603C6AA extu.b r1,r1
    c.r[9] |= c.r[1];  // 0603C6AC or r1,r9
    c.r[1] = c.r[8];  // 0603C6AE mov r8,r1
    c.r[1] += 5;  // 0603C6B0 add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603C6B2 mov.b @r1,r1
    c.r[4] = c.r[1] & 0xFFu;  // 0603C6B4 extu.b r1,r4
    c.r[1] = c.r[8];  // 0603C6B6 mov r8,r1
    c.r[1] += 6;  // 0603C6B8 add #6,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603C6BA mov.b @r1,r1
    c.r[7] = ld32(0x0603C740u);  // 0603C6BC mov.l 0x0603C740,r7
    c.r[5] = c.r[1] & 0xFFu;  // 0603C6BE extu.b r1,r5
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[7]);  // 0603C6C0 mov.w @r7,r1
    c.t = (int32_t)c.r[1] >= 0;  // 0603C6C2 cmp/pz r1
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[7]);  // 0603C6C4 mov.w @r7,r6
    c.r[2] = (uint32_t)(int16_t)ld16(0x0603C732u);  // 0603C6C6 mov.w 0x0603C732,r2
    c.r[3] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0603C6C8 exts.w r2,r3
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[6];  // 0603C6CA exts.w r6,r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[3];  // 0603C6CC cmp/gt r3,r1
    if (!c.t) { goto L_0603C6D2; }  // 0603C6CE bf 0x0603C6D2
    c.r[6] = c.r[2];  // 0603C6D0 mov r2,r6
L_0603C6D2:
    c.r[6] = (uint32_t)(int32_t)(int16_t)c.r[6];  // 0603C6D2 exts.w r6,r6
    c.t = (c.r[6] & c.r[6]) == 0;  // 0603C6D4 tst r6,r6
    if (c.t) { goto L_0603C710; }  // 0603C6D6 bt 0x0603C710
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603C734u);  // 0603C6D8 mov.w 0x0603C734,r1
    c.t = (int32_t)c.r[6] > (int32_t)c.r[1];  // 0603C6DA cmp/gt r1,r6
    { const bool k = c.t; c.r[0] = c.r[6]; if (k) { goto L_0603C70E; } }  // 0603C6DC bt/s 0x0603C70E ; mov r6,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 0603C6E0 shar r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 0603C6E2 shar r0
    c.r[1] = ld32(0x0603C744u);  // 0603C6E4 mov.l 0x0603C744,r1
    c.r[0] &= c.r[1];  // 0603C6E6 and r1,r0
    c.r[1] = c.r[0];  // 0603C6E8 mov r0,r1
    c.r[1] += c.r[14];  // 0603C6EA add r14,r1
    c.r[1] += 2;  // 0603C6EC add #2,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0603C6EE mov.w @r1,r1
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[14]);  // 0603C6F0 mov.w @(r0,r14),r3
    c.r[1] = c.r[1] & 0xFFFFu;  // 0603C6F2 extu.w r1,r1
    c.r[2] = c.r[3] & 0xFFFFu;  // 0603C6F4 extu.w r3,r2
    c.r[1] -= c.r[2];  // 0603C6F6 sub r2,r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0603C6F8 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0603C6FA shar r1
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[7]);  // 0603C6FC mov.w @r7,r0
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0603C6FE shar r1
    c.r[0] &= 0x7u;  // 0603C700 and #7,r0
    c.macl = c.r[1] * c.r[0];  // 0603C702 mul.l r0,r1
    c.r[1] = c.macl;  // 0603C704 sts macl,r1
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 0603C706 exts.w r1,r1
    c.r[1] += c.r[3];  // 0603C708 add r3,r1
    c.r[6] = (uint32_t)(int32_t)(int16_t)c.r[1]; goto L_0603C710;  // 0603C70A bra 0x0603C710 ; exts.w r1,r6
L_0603C70E:
    c.r[6] = c.r[3];  // 0603C70E mov r3,r6
L_0603C710:
    c.r[4] <<= 8;  // 0603C710 shll8 r4
    c.r[5] |= c.r[4];  // 0603C712 or r4,r5
    c.r[1] = ld32(0x0603C748u);  // 0603C714 mov.l 0x0603C748,r1
    c.r[7] = c.r[5];  // 0603C716 mov r5,r7
    c.r[5] = c.r[9];  // 0603C718 mov r9,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0603C71Eu; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603C71Eu) return; }  // 0603C71A jsr @r1 ; mov r10,r4
    c.r[14] += 68;  // 0603C71E add #68,r14
    c.r[15] = c.r[14];  // 0603C720 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603C722 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603C724 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0603C726 mov.l @r15+,r10
    c.r[8] += 7;  // 0603C728 add #7,r8
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0603C72A mov.l @r15+,r9
    c.r[0] = c.r[8];  // 0603C72C mov r8,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603C72E rts ; mov.l @r15+,r8
}

void f_0603C74C(SH2Context& c) {
    ran[936] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603C74C mov.l r14,@-r15
    c.r[2] = c.r[5];  // 0603C74E mov r5,r2
    c.r[1] = c.r[2];  // 0603C750 mov r2,r1
    c.r[1] += 1;  // 0603C752 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603C754 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0603C756 mov r1,r0
    c.r[0] &= 0x30u;  // 0603C758 and #48,r0
    c.t = c.r[0] == 0x10u;  // 0603C75A cmp/eq #16,r0
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0603C770; } }  // 0603C75C bf/s 0x0603C770 ; mov r15,r14
    c.r[3] = ld32(0x0603C7D4u);  // 0603C760 mov.l 0x0603C7D4,r3
    c.r[0] = c.r[1];  // 0603C762 mov r1,r0
    c.r[0] &= 0x1u;  // 0603C764 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603C766 tst r0,r0
    c.r[1] = ld32(0x0603C7D8u);  // 0603C768 mov.l 0x0603C7D8,r1
    if (c.t) { goto L_0603C76E; }  // 0603C76A bt 0x0603C76E
    c.r[1] = 0x1u;  // 0603C76C mov #1,r1
L_0603C76E:
    st32(c.r[3] + 24, c.r[1]);  // 0603C76E mov.l r1,@(24,r3)
L_0603C770:
    c.r[1] = c.r[2];  // 0603C770 mov r2,r1
    c.r[1] += 1;  // 0603C772 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603C774 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0603C776 mov r1,r0
    c.r[0] &= 0x30u;  // 0603C778 and #48,r0
    c.t = c.r[0] == 0x20u;  // 0603C77A cmp/eq #32,r0
    { const bool k = !c.t; c.r[0] = c.r[1]; if (k) { goto L_0603C78E; } }  // 0603C77C bf/s 0x0603C78E ; mov r1,r0
    c.r[3] = ld32(0x0603C7D4u);  // 0603C780 mov.l 0x0603C7D4,r3
    c.r[0] &= 0x1u;  // 0603C782 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603C784 tst r0,r0
    c.r[1] = ld32(0x0603C7DCu);  // 0603C786 mov.l 0x0603C7DC,r1
    if (c.t) { goto L_0603C78C; }  // 0603C788 bt 0x0603C78C
    c.r[1] = 0x2u;  // 0603C78A mov #2,r1
L_0603C78C:
    st32(c.r[3] + 28, c.r[1]);  // 0603C78C mov.l r1,@(28,r3)
L_0603C78E:
    c.r[1] = c.r[2];  // 0603C78E mov r2,r1
    c.r[1] += 1;  // 0603C790 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603C792 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0603C794 mov r1,r0
    c.r[0] &= 0x30u;  // 0603C796 and #48,r0
    c.t = c.r[0] == 0x30u;  // 0603C798 cmp/eq #48,r0
    { const bool k = !c.t; c.r[0] = c.r[1]; if (k) { goto L_0603C7AC; } }  // 0603C79A bf/s 0x0603C7AC ; mov r1,r0
    c.r[3] = ld32(0x0603C7D4u);  // 0603C79E mov.l 0x0603C7D4,r3
    c.r[0] &= 0x1u;  // 0603C7A0 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603C7A2 tst r0,r0
    c.r[1] = ld32(0x0603C7E0u);  // 0603C7A4 mov.l 0x0603C7E0,r1
    if (c.t) { goto L_0603C7AA; }  // 0603C7A6 bt 0x0603C7AA
    c.r[1] = 0x8u;  // 0603C7A8 mov #8,r1
L_0603C7AA:
    st32(c.r[3] + 36, c.r[1]);  // 0603C7AA mov.l r1,@(36,r3)
L_0603C7AC:
    c.r[1] = c.r[2];  // 0603C7AC mov r2,r1
    c.r[1] += 1;  // 0603C7AE add #1,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603C7B0 mov.b @r1,r0
    c.r[1] = 0x30u;  // 0603C7B2 mov #48,r1
    c.r[1] &= c.r[0];  // 0603C7B4 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603C7B6 tst r1,r1
    { const bool k = !c.t; c.r[0] &= 0x1u; if (k) { goto L_0603C7C8; } }  // 0603C7B8 bf/s 0x0603C7C8 ; and #1,r0
    c.r[3] = ld32(0x0603C7D4u);  // 0603C7BC mov.l 0x0603C7D4,r3
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603C7BE tst r0,r0
    c.r[1] = ld32(0x0603C7E4u);  // 0603C7C0 mov.l 0x0603C7E4,r1
    if (c.t) { goto L_0603C7C6; }  // 0603C7C2 bt 0x0603C7C6
    c.r[1] = 0x10u;  // 0603C7C4 mov #16,r1
L_0603C7C6:
    st32(c.r[3] + 40, c.r[1]);  // 0603C7C6 mov.l r1,@(40,r3)
L_0603C7C8:
    c.r[2] += 2;  // 0603C7C8 add #2,r2
    c.r[15] = c.r[14];  // 0603C7CA mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603C7CC mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[2]; c.pc = x; return; }  // 0603C7CE rts ; mov r2,r0
}

void f_0603C7E8(SH2Context& c) {
    ran[937] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603C7E8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603C7EA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0603C7EC mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0603C7EE mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0603C7F0 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0603C7F2 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603C7F4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603C7F6 sts.l pr,@-r15
    c.r[15] -= 4;  // 0603C7F8 add #-4,r15
    c.r[14] = c.r[15];  // 0603C7FA mov r15,r14
    st32(c.r[14], c.r[5]);  // 0603C7FC mov.l r5,@r14
    c.r[1] = c.r[5];  // 0603C7FE mov r5,r1
    c.r[1] += 1;  // 0603C800 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603C802 mov.b @r1,r1
    c.r[8] = c.r[1] & 0xFFu;  // 0603C804 extu.b r1,r8
    c.r[1] = ld32(0x0603C99Cu);  // 0603C806 mov.l 0x0603C99C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603C808 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0603C80A mov r1,r0
    c.r[0] >>= 2;  // 0603C80C shlr2 r0
    c.r[0] >>= 2;  // 0603C80E shlr2 r0
    c.r[0] >>= 2;  // 0603C810 shlr2 r0
    c.r[0] &= 0x1u;  // 0603C812 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603C814 tst r0,r0
    if (c.t) { goto L_0603C81E; }  // 0603C816 bt 0x0603C81E
    c.r[1] = ld32(0x0603C9A0u);  // 0603C818 mov.l 0x0603C9A0,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]); goto L_0603C822;  // 0603C81A bra 0x0603C822 ; mov.w @r1,r1
L_0603C81E:
    c.r[1] = ld32(0x0603C9A4u);  // 0603C81E mov.l 0x0603C9A4,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0603C820 mov.w @r1,r1
L_0603C822:
    c.r[1] = c.r[1] & 0xFFFFu;  // 0603C822 extu.w r1,r1
    c.r[12] = c.r[1];  // 0603C824 mov r1,r12
    c.r[1] = ld32(0x0603C9A8u);  // 0603C826 mov.l 0x0603C9A8,r1
    c.r[2] = c.r[12];  // 0603C828 mov r12,r2
    c.r[2] <<= 2;  // 0603C82A shll2 r2
    c.r[2] += c.r[2];  // 0603C82C add r2,r2
    c.r[7] = ld32(0x0603C9ACu);  // 0603C82E mov.l 0x0603C9AC,r7
    c.r[5] = 0xEu;  // 0603C830 mov #14,r5
    c.r[1] = ld32(c.r[1]);  // 0603C832 mov.l @r1,r1
    c.r[2] += c.r[1];  // 0603C834 add r1,r2
    c.r[2] += 4;  // 0603C836 add #4,r2
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0603C838 mov.w @r2,r6
    c.r[1] = ld32(0x0603C9B0u);  // 0603C83A mov.l 0x0603C9B0,r1
    c.r[6] = c.r[6] & 0xFFFFu;  // 0603C83C extu.w r6,r6
    c.r[6] <<= 2;  // 0603C83E shll2 r6
    c.r[6] += c.r[6];  // 0603C840 add r6,r6
    c.r[6] += c.r[1];  // 0603C842 add r1,r6
    c.r[1] = ld32(0x0603C9B4u);  // 0603C844 mov.l 0x0603C9B4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603C84Au; c.r[4] = 0x12u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603C84Au) return; }  // 0603C846 jsr @r1 ; mov #18,r4
    c.r[3] = (uint32_t)(int16_t)ld16(0x0603C996u);  // 0603C84A mov.w 0x0603C996,r3
    c.r[3] &= c.r[8];  // 0603C84C and r8,r3
    c.r[3] <<= 8;  // 0603C84E shll8 r3
    c.r[3] <<= 2;  // 0603C850 shll2 r3
    c.r[3] <<= 2;  // 0603C852 shll2 r3
    c.r[1] = ld32(0x0603C9B8u);  // 0603C854 mov.l 0x0603C9B8,r1
    c.r[1] = ld32(c.r[1]);  // 0603C856 mov.l @r1,r1
    c.r[2] = c.r[8];  // 0603C858 mov r8,r2
    c.r[1] += 78;  // 0603C85A add #78,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603C85C mov.b @r1,r1
    c.r[2] <<= 16;  // 0603C85E shll16 r2
    c.r[2] >>= 2;  // 0603C860 shlr2 r2
    c.r[2] <<= 16;  // 0603C862 shll16 r2
    c.r[7] = c.r[1] & 0xFFu;  // 0603C864 extu.b r1,r7
    c.t = c.r[7] & 1; c.r[7] >>= 1;  // 0603C866 shlr r7
    c.r[1] = 0x1u;  // 0603C868 mov #1,r1
    c.r[1] &= c.r[7];  // 0603C86A and r7,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603C86C tst r1,r1
    { const bool k = c.t; c.r[0] = 0x1u; if (k) { goto L_0603C876; } }  // 0603C86E bt/s 0x0603C876 ; mov #1,r0
    c.r[1] = ld32(0x0603C9BCu);  // 0603C872 mov.l 0x0603C9BC,r1
    c.r[2] ^= c.r[1];  // 0603C874 xor r1,r2
L_0603C876:
    c.r[7] &= c.r[0];  // 0603C876 and r0,r7
    c.r[7] ^= c.r[8];  // 0603C878 xor r8,r7
    c.r[0] = 0x3u;  // 0603C87A mov #3,r0
    c.r[7] &= c.r[0];  // 0603C87C and r0,r7
    c.r[1] = 0x3u;  // 0603C87E mov #3,r1
    c.t = c.r[7] > c.r[1];  // 0603C880 cmp/hi r1,r7
    { const bool k = !c.t; c.r[6] = 0x0u; if (k) { goto L_0603C88A; } }  // 0603C882 bf/s 0x0603C88A ; mov #0,r6
    goto L_0603CA26;  // 0603C886 bra 0x0603CA26 ; nop
L_0603C88A:
    c.r[1] = c.r[7];  // 0603C88A mov r7,r1
    c.r[1] += c.r[1];  // 0603C88C add r1,r1
    c.r[0] = 0x0603C898u;  // 0603C88E mova 0x0603C898,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0603C890 mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 0603C892 add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x0603C8A0u: goto L_0603C8A0; case 0x0603C8ECu: goto L_0603C8EC; case 0x0603C946u: goto L_0603C946; case 0x0603C9C4u: goto L_0603C9C4; default: sh2_call(c, x); return; } }  // 0603C894 jmp @r0 ; nop
L_0603C8A0:
    c.r[5] = 0x0u;  // 0603C8A0 mov #0,r5
    c.r[8] = 0x11u;  // 0603C8A2 mov #17,r8
    c.r[4] = ld32(0x0603C9C0u);  // 0603C8A4 mov.l 0x0603C9C0,r4
    c.r[9] = c.r[3];  // 0603C8A6 mov r3,r9
    c.r[9] += c.r[2];  // 0603C8A8 add r2,r9
    c.r[10] = (uint32_t)(int16_t)ld16(0x0603C998u);  // 0603C8AA mov.w 0x0603C998,r10
    c.r[7] = 0x0u;  // 0603C8AC mov #0,r7
    c.r[2] = 0x0u;  // 0603C8AE mov #0,r2
L_0603C8B0:
    c.r[3] = 0x0u;  // 0603C8B0 mov #0,r3
    c.r[6] = c.r[9];  // 0603C8B2 mov r9,r6
    c.r[6] += c.r[10];  // 0603C8B4 add r10,r6
L_0603C8B6:
    c.r[0] = c.r[2];  // 0603C8B6 mov r2,r0
    c.r[0] += c.r[3];  // 0603C8B8 add r3,r0
    c.r[0] <<= 2;  // 0603C8BA shll2 r0
    c.r[1] = c.r[7];  // 0603C8BC mov r7,r1
    c.r[1] += c.r[3];  // 0603C8BE add r3,r1
    c.r[1] += c.r[6];  // 0603C8C0 add r6,r1
    c.r[3] += 1;  // 0603C8C2 add #1,r3
    c.t = (int32_t)c.r[3] > (int32_t)c.r[8];  // 0603C8C4 cmp/gt r8,r3
    { const bool k = !c.t; st32(c.r[0] + c.r[4], c.r[1]); if (k) { SH2_POLL(c); goto L_0603C8B6; } }  // 0603C8C6 bf/s 0x0603C8B6 ; mov.l r1,@(r0,r4)
    c.r[7] += 18;  // 0603C8CA add #18,r7
    c.r[5] += 1;  // 0603C8CC add #1,r5
    c.r[1] = 0xDu;  // 0603C8CE mov #13,r1
    c.t = (int32_t)c.r[5] > (int32_t)c.r[1];  // 0603C8D0 cmp/gt r1,r5
    { const bool k = !c.t; c.r[2] += 64; if (k) { SH2_POLL(c); goto L_0603C8B0; } }  // 0603C8D2 bf/s 0x0603C8B0 ; add #64,r2
    c.r[1] = ld32(0x0603C9A8u);  // 0603C8D6 mov.l 0x0603C9A8,r1
    c.r[2] = ld32(c.r[1] + 16);  // 0603C8D8 mov.l @(16,r1),r2
    c.r[1] = c.r[12];  // 0603C8DA mov r12,r1
    c.r[1] <<= 2;  // 0603C8DC shll2 r1
    c.r[3] = c.r[1];  // 0603C8DE mov r1,r3
    c.r[3] += c.r[2];  // 0603C8E0 add r2,r3
    c.r[0] = c.r[1];  // 0603C8E2 mov r1,r0
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 0603C8E4 mov.w @(r0,r2),r6
    c.r[3] += 2;  // 0603C8E6 add #2,r3
    c.r[7] = (uint32_t)(int16_t)ld16(c.r[3]); goto L_0603CA28;  // 0603C8E8 bra 0x0603CA28 ; mov.w @r3,r7
L_0603C8EC:
    c.r[5] = 0x0u;  // 0603C8EC mov #0,r5
    c.r[8] = 0x11u;  // 0603C8EE mov #17,r8
    c.r[4] = ld32(0x0603C9C0u);  // 0603C8F0 mov.l 0x0603C9C0,r4
    c.r[9] = c.r[3];  // 0603C8F2 mov r3,r9
    c.r[9] += c.r[2];  // 0603C8F4 add r2,r9
    c.r[10] = (uint32_t)(int16_t)ld16(0x0603C998u);  // 0603C8F6 mov.w 0x0603C998,r10
    c.r[7] = 0x0u;  // 0603C8F8 mov #0,r7
    c.r[2] = 0x0u;  // 0603C8FA mov #0,r2
L_0603C8FC:
    c.r[3] = 0x0u;  // 0603C8FC mov #0,r3
    c.r[6] = c.r[9];  // 0603C8FE mov r9,r6
    c.r[6] += c.r[10];  // 0603C900 add r10,r6
L_0603C902:
    c.r[11] = c.r[2];  // 0603C902 mov r2,r11
    c.r[11] += c.r[3];  // 0603C904 add r3,r11
    c.r[11] <<= 2;  // 0603C906 shll2 r11
    c.r[1] = c.r[3];  // 0603C908 mov r3,r1
    c.r[1] -= 17;  // 0603C90A add #-17,r1
    c.r[0] = c.r[7];  // 0603C90C mov r7,r0
    c.r[0] -= c.r[1];  // 0603C90E sub r1,r0
    c.r[1] = c.r[0];  // 0603C910 mov r0,r1
    c.r[1] += c.r[6];  // 0603C912 add r6,r1
    c.r[0] = c.r[11];  // 0603C914 mov r11,r0
    c.r[3] += 1;  // 0603C916 add #1,r3
    c.t = (int32_t)c.r[3] > (int32_t)c.r[8];  // 0603C918 cmp/gt r8,r3
    { const bool k = !c.t; st32(c.r[0] + c.r[4], c.r[1]); if (k) { SH2_POLL(c); goto L_0603C902; } }  // 0603C91A bf/s 0x0603C902 ; mov.l r1,@(r0,r4)
    c.r[7] += 18;  // 0603C91E add #18,r7
    c.r[5] += 1;  // 0603C920 add #1,r5
    c.r[1] = 0xDu;  // 0603C922 mov #13,r1
    c.t = (int32_t)c.r[5] > (int32_t)c.r[1];  // 0603C924 cmp/gt r1,r5
    { const bool k = !c.t; c.r[2] += 64; if (k) { SH2_POLL(c); goto L_0603C8FC; } }  // 0603C926 bf/s 0x0603C8FC ; add #64,r2
    c.r[1] = ld32(0x0603C9A8u);  // 0603C92A mov.l 0x0603C9A8,r1
    c.r[2] = ld32(c.r[1] + 16);  // 0603C92C mov.l @(16,r1),r2
    c.r[1] = c.r[12];  // 0603C92E mov r12,r1
    c.r[1] <<= 2;  // 0603C930 shll2 r1
    c.r[3] = c.r[1];  // 0603C932 mov r1,r3
    c.r[3] += c.r[2];  // 0603C934 add r2,r3
    c.r[0] = c.r[1];  // 0603C936 mov r1,r0
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 0603C938 mov.w @(r0,r2),r2
    c.r[3] += 2;  // 0603C93A add #2,r3
    c.r[7] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0603C93C mov.w @r3,r7
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603C99Au);  // 0603C93E mov.w 0x0603C99A,r1
    c.r[1] -= c.r[2];  // 0603C940 sub r2,r1
    c.r[6] = (uint32_t)(int32_t)(int16_t)c.r[1]; goto L_0603CA28;  // 0603C942 bra 0x0603CA28 ; exts.w r1,r6
L_0603C946:
    c.r[5] = 0x0u;  // 0603C946 mov #0,r5
    c.r[9] = 0x11u;  // 0603C948 mov #17,r9
    c.r[8] = ld32(0x0603C9C0u);  // 0603C94A mov.l 0x0603C9C0,r8
    c.r[10] = c.r[3];  // 0603C94C mov r3,r10
    c.r[10] += c.r[2];  // 0603C94E add r2,r10
    c.r[11] = (uint32_t)(int16_t)ld16(0x0603C998u);  // 0603C950 mov.w 0x0603C998,r11
    c.r[2] = 0x0u;  // 0603C952 mov #0,r2
    c.r[4] = 0xDu;  // 0603C954 mov #13,r4
L_0603C956:
    c.r[3] = 0x0u;  // 0603C956 mov #0,r3
    c.r[6] = c.r[10];  // 0603C958 mov r10,r6
    c.r[6] += c.r[11];  // 0603C95A add r11,r6
    c.r[7] = c.r[4];  // 0603C95C mov r4,r7
L_0603C95E:
    c.r[0] = c.r[2];  // 0603C95E mov r2,r0
    c.r[1] = 0x12u;  // 0603C960 mov #18,r1
    c.macl = c.r[7] * c.r[1];  // 0603C962 mul.l r1,r7
    c.r[0] += c.r[3];  // 0603C964 add r3,r0
    c.r[0] <<= 2;  // 0603C966 shll2 r0
    c.r[1] = c.macl;  // 0603C968 sts macl,r1
    c.r[1] += c.r[3];  // 0603C96A add r3,r1
    c.r[1] += c.r[6];  // 0603C96C add r6,r1
    c.r[3] += 1;  // 0603C96E add #1,r3
    c.t = (int32_t)c.r[3] > (int32_t)c.r[9];  // 0603C970 cmp/gt r9,r3
    { const bool k = !c.t; st32(c.r[0] + c.r[8], c.r[1]); if (k) { SH2_POLL(c); goto L_0603C95E; } }  // 0603C972 bf/s 0x0603C95E ; mov.l r1,@(r0,r8)
    c.r[2] += 64;  // 0603C976 add #64,r2
    c.r[5] += 1;  // 0603C978 add #1,r5
    c.r[1] = 0xDu;  // 0603C97A mov #13,r1
    c.t = (int32_t)c.r[5] > (int32_t)c.r[1];  // 0603C97C cmp/gt r1,r5
    { const bool k = !c.t; c.r[4] -= 1; if (k) { SH2_POLL(c); goto L_0603C956; } }  // 0603C97E bf/s 0x0603C956 ; add #-1,r4
    c.r[1] = ld32(0x0603C9A8u);  // 0603C982 mov.l 0x0603C9A8,r1
    c.r[2] = ld32(c.r[1] + 16);  // 0603C984 mov.l @(16,r1),r2
    c.r[1] = c.r[12];  // 0603C986 mov r12,r1
    c.r[1] <<= 2;  // 0603C988 shll2 r1
    c.r[3] = c.r[1];  // 0603C98A mov r1,r3
    c.r[3] += c.r[2];  // 0603C98C add r2,r3
    c.r[0] = c.r[1];  // 0603C98E mov r1,r0
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 0603C990 mov.w @(r0,r2),r6
    c.r[3] += 2; goto L_0603CA1C;  // 0603C992 bra 0x0603CA1C ; add #2,r3
L_0603C9C4:
    c.r[5] = 0x0u;  // 0603C9C4 mov #0,r5
    c.r[10] = 0x11u;  // 0603C9C6 mov #17,r10
    c.r[9] = ld32(0x0603CA68u);  // 0603C9C8 mov.l 0x0603CA68,r9
    c.r[11] = c.r[3];  // 0603C9CA mov r3,r11
    c.r[11] += c.r[2];  // 0603C9CC add r2,r11
    c.r[13] = (uint32_t)(int16_t)ld16(0x0603CA64u);  // 0603C9CE mov.w 0x0603CA64,r13
    c.r[7] = 0x0u;  // 0603C9D0 mov #0,r7
    c.r[8] = 0xDu;  // 0603C9D2 mov #13,r8
L_0603C9D4:
    c.r[3] = 0x0u;  // 0603C9D4 mov #0,r3
    c.r[4] = c.r[11];  // 0603C9D6 mov r11,r4
    c.r[4] += c.r[13];  // 0603C9D8 add r13,r4
    c.r[6] = c.r[8];  // 0603C9DA mov r8,r6
L_0603C9DC:
    c.r[0] = c.r[7];  // 0603C9DC mov r7,r0
    c.r[1] = 0x12u;  // 0603C9DE mov #18,r1
    c.macl = c.r[6] * c.r[1];  // 0603C9E0 mul.l r1,r6
    c.r[0] += c.r[3];  // 0603C9E2 add r3,r0
    c.r[0] <<= 2;  // 0603C9E4 shll2 r0
    c.r[2] = c.macl;  // 0603C9E6 sts macl,r2
    c.r[1] = c.r[3];  // 0603C9E8 mov r3,r1
    c.r[1] -= 17;  // 0603C9EA add #-17,r1
    c.r[2] -= c.r[1];  // 0603C9EC sub r1,r2
    c.r[2] += c.r[4];  // 0603C9EE add r4,r2
    c.r[3] += 1;  // 0603C9F0 add #1,r3
    c.t = (int32_t)c.r[3] > (int32_t)c.r[10];  // 0603C9F2 cmp/gt r10,r3
    { const bool k = !c.t; st32(c.r[0] + c.r[9], c.r[2]); if (k) { SH2_POLL(c); goto L_0603C9DC; } }  // 0603C9F4 bf/s 0x0603C9DC ; mov.l r2,@(r0,r9)
    c.r[7] += 64;  // 0603C9F8 add #64,r7
    c.r[5] += 1;  // 0603C9FA add #1,r5
    c.r[1] = 0xDu;  // 0603C9FC mov #13,r1
    c.t = (int32_t)c.r[5] > (int32_t)c.r[1];  // 0603C9FE cmp/gt r1,r5
    { const bool k = !c.t; c.r[8] -= 1; if (k) { SH2_POLL(c); goto L_0603C9D4; } }  // 0603CA00 bf/s 0x0603C9D4 ; add #-1,r8
    c.r[1] = ld32(0x0603CA6Cu);  // 0603CA04 mov.l 0x0603CA6C,r1
    c.r[2] = ld32(c.r[1] + 16);  // 0603CA06 mov.l @(16,r1),r2
    c.r[1] = c.r[12];  // 0603CA08 mov r12,r1
    c.r[1] <<= 2;  // 0603CA0A shll2 r1
    c.r[3] = c.r[1];  // 0603CA0C mov r1,r3
    c.r[3] += c.r[2];  // 0603CA0E add r2,r3
    c.r[0] = c.r[1];  // 0603CA10 mov r1,r0
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 0603CA12 mov.w @(r0,r2),r2
    c.r[3] += 2;  // 0603CA14 add #2,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603CA66u);  // 0603CA16 mov.w 0x0603CA66,r1
    c.r[1] -= c.r[2];  // 0603CA18 sub r2,r1
    c.r[6] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 0603CA1A exts.w r1,r6
L_0603CA1C:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0603CA1C mov.w @r3,r1
    c.r[1] = 0u - c.r[1];  // 0603CA1E neg r1,r1
    c.r[1] += 112;  // 0603CA20 add #112,r1
    c.r[7] = (uint32_t)(int32_t)(int16_t)c.r[1]; goto L_0603CA28;  // 0603CA22 bra 0x0603CA28 ; exts.w r1,r7
L_0603CA26:
    c.r[7] = 0x0u;  // 0603CA26 mov #0,r7
L_0603CA28:
    c.r[3] = ld32(0x0603CA70u);  // 0603CA28 mov.l 0x0603CA70,r3
    c.r[1] = c.r[3];  // 0603CA2A mov r3,r1
    c.r[1] += 51;  // 0603CA2C add #51,r1
    c.r[2] = 0x0u;  // 0603CA2E mov #0,r2
    st8(c.r[1], c.r[2]);  // 0603CA30 mov.b r2,@r1
    c.r[1] = c.r[3];  // 0603CA32 mov r3,r1
    c.r[1] += 52;  // 0603CA34 add #52,r1
    st8(c.r[1], c.r[2]);  // 0603CA36 mov.b r2,@r1
    c.r[1] = c.r[3];  // 0603CA38 mov r3,r1
    c.r[1] += 62;  // 0603CA3A add #62,r1
    c.r[6] -= 1;  // 0603CA3C add #-1,r6
    st16(c.r[1], c.r[6]);  // 0603CA3E mov.w r6,@r1
    c.r[3] += 64;  // 0603CA40 add #64,r3
    c.r[0] = ld32(c.r[14]);  // 0603CA42 mov.l @r14,r0
    c.r[7] -= 1;  // 0603CA44 add #-1,r7
    c.r[0] += 2;  // 0603CA46 add #2,r0
    st32(c.r[14], c.r[0]);  // 0603CA48 mov.l r0,@r14
    c.r[0] = ld32(c.r[14]);  // 0603CA4A mov.l @r14,r0
    st16(c.r[3], c.r[7]);  // 0603CA4C mov.w r7,@r3
    c.r[14] += 4;  // 0603CA4E add #4,r14
    c.r[15] = c.r[14];  // 0603CA50 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603CA52 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603CA54 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0603CA56 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0603CA58 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0603CA5A mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0603CA5C mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0603CA5E mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603CA60 rts ; mov.l @r15+,r8
}

void f_0603CA74(SH2Context& c) {
    ran[938] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603CA74 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603CA76 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0603CA78 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0603CA7A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0603CA7C mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0603CA7E mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603CA80 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603CA82 sts.l pr,@-r15
    c.r[15] -= 4;  // 0603CA84 add #-4,r15
    c.r[14] = c.r[15];  // 0603CA86 mov r15,r14
    st32(c.r[14], c.r[5]);  // 0603CA88 mov.l r5,@r14
    c.r[1] = c.r[5];  // 0603CA8A mov r5,r1
    c.r[1] += 1;  // 0603CA8C add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603CA8E mov.b @r1,r1
    c.r[8] = c.r[1] & 0xFFu;  // 0603CA90 extu.b r1,r8
    c.r[1] = ld32(0x0603CC4Cu);  // 0603CA92 mov.l 0x0603CC4C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603CA94 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0603CA96 mov r1,r0
    c.r[0] >>= 2;  // 0603CA98 shlr2 r0
    c.r[0] >>= 2;  // 0603CA9A shlr2 r0
    c.r[0] >>= 2;  // 0603CA9C shlr2 r0
    c.r[0] &= 0x1u;  // 0603CA9E and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603CAA0 tst r0,r0
    if (c.t) { goto L_0603CABA; }  // 0603CAA2 bt 0x0603CABA
    c.r[1] = ld32(0x0603CC50u);  // 0603CAA4 mov.l 0x0603CC50,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0603CAA6 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0603CAA8 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603CAAA tst r1,r1
    if (c.t) { goto L_0603CAB4; }  // 0603CAAC bt 0x0603CAB4
    c.r[1] = ld32(0x0603CC54u);  // 0603CAAE mov.l 0x0603CC54,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]); goto L_0603CACE;  // 0603CAB0 bra 0x0603CACE ; mov.w @r1,r1
L_0603CAB4:
    c.r[1] = ld32(0x0603CC58u);  // 0603CAB4 mov.l 0x0603CC58,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]); goto L_0603CACE;  // 0603CAB6 bra 0x0603CACE ; mov.w @r1,r1
L_0603CABA:
    c.r[1] = ld32(0x0603CC5Cu);  // 0603CABA mov.l 0x0603CC5C,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0603CABC mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0603CABE extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603CAC0 tst r1,r1
    if (c.t) { goto L_0603CACA; }  // 0603CAC2 bt 0x0603CACA
    c.r[1] = ld32(0x0603CC60u);  // 0603CAC4 mov.l 0x0603CC60,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]); goto L_0603CACE;  // 0603CAC6 bra 0x0603CACE ; mov.w @r1,r1
L_0603CACA:
    c.r[1] = ld32(0x0603CC64u);  // 0603CACA mov.l 0x0603CC64,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0603CACC mov.w @r1,r1
L_0603CACE:
    c.r[10] = c.r[1] & 0xFFFFu;  // 0603CACE extu.w r1,r10
    c.r[1] = ld32(0x0603CC68u);  // 0603CAD0 mov.l 0x0603CC68,r1
    c.r[2] = c.r[10];  // 0603CAD2 mov r10,r2
    c.r[2] <<= 2;  // 0603CAD4 shll2 r2
    c.r[2] += c.r[2];  // 0603CAD6 add r2,r2
    c.r[7] = ld32(0x0603CC6Cu);  // 0603CAD8 mov.l 0x0603CC6C,r7
    c.r[5] = 0xEu;  // 0603CADA mov #14,r5
    c.r[1] = ld32(c.r[1]);  // 0603CADC mov.l @r1,r1
    c.r[2] += c.r[1];  // 0603CADE add r1,r2
    c.r[2] += 4;  // 0603CAE0 add #4,r2
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0603CAE2 mov.w @r2,r6
    c.r[1] = ld32(0x0603CC70u);  // 0603CAE4 mov.l 0x0603CC70,r1
    c.r[6] = c.r[6] & 0xFFFFu;  // 0603CAE6 extu.w r6,r6
    c.r[6] <<= 2;  // 0603CAE8 shll2 r6
    c.r[6] += c.r[6];  // 0603CAEA add r6,r6
    c.r[6] += c.r[1];  // 0603CAEC add r1,r6
    c.r[1] = ld32(0x0603CC74u);  // 0603CAEE mov.l 0x0603CC74,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603CAF4u; c.r[4] = 0x12u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603CAF4u) return; }  // 0603CAF0 jsr @r1 ; mov #18,r4
    c.r[3] = (uint32_t)(int16_t)ld16(0x0603CC42u);  // 0603CAF4 mov.w 0x0603CC42,r3
    c.r[3] &= c.r[8];  // 0603CAF6 and r8,r3
    c.r[3] <<= 8;  // 0603CAF8 shll8 r3
    c.r[3] <<= 2;  // 0603CAFA shll2 r3
    c.r[3] <<= 2;  // 0603CAFC shll2 r3
    c.r[1] = ld32(0x0603CC78u);  // 0603CAFE mov.l 0x0603CC78,r1
    c.r[0] = ld32(c.r[1]);  // 0603CB00 mov.l @r1,r0
    c.r[2] = c.r[8];  // 0603CB02 mov r8,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603CC44u);  // 0603CB04 mov.w 0x0603CC44,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0603CB06 mov.b @(r0,r1),r1
    c.r[2] <<= 16;  // 0603CB08 shll16 r2
    c.r[2] >>= 2;  // 0603CB0A shlr2 r2
    c.r[2] <<= 16;  // 0603CB0C shll16 r2
    c.r[7] = c.r[1] & 0xFFu;  // 0603CB0E extu.b r1,r7
    c.t = c.r[7] & 1; c.r[7] >>= 1;  // 0603CB10 shlr r7
    c.r[1] = 0x1u;  // 0603CB12 mov #1,r1
    c.r[1] &= c.r[7];  // 0603CB14 and r7,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603CB16 tst r1,r1
    { const bool k = c.t; c.r[0] = 0x1u; if (k) { goto L_0603CB20; } }  // 0603CB18 bt/s 0x0603CB20 ; mov #1,r0
    c.r[1] = ld32(0x0603CC7Cu);  // 0603CB1C mov.l 0x0603CC7C,r1
    c.r[2] ^= c.r[1];  // 0603CB1E xor r1,r2
L_0603CB20:
    c.r[7] &= c.r[0];  // 0603CB20 and r0,r7
    c.r[7] ^= c.r[8];  // 0603CB22 xor r8,r7
    c.r[0] = 0x3u;  // 0603CB24 mov #3,r0
    c.r[7] &= c.r[0];  // 0603CB26 and r0,r7
    c.r[1] = 0x3u;  // 0603CB28 mov #3,r1
    c.t = c.r[7] > c.r[1];  // 0603CB2A cmp/hi r1,r7
    { const bool k = !c.t; c.r[6] = 0x0u; if (k) { goto L_0603CB34; } }  // 0603CB2C bf/s 0x0603CB34 ; mov #0,r6
    goto L_0603CCE6;  // 0603CB30 bra 0x0603CCE6 ; nop
L_0603CB34:
    c.r[1] = c.r[7];  // 0603CB34 mov r7,r1
    c.r[1] += c.r[1];  // 0603CB36 add r1,r1
    c.r[0] = 0x0603CB44u;  // 0603CB38 mova 0x0603CB44,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0603CB3A mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 0603CB3C add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x0603CB4Cu: goto L_0603CB4C; case 0x0603CB98u: goto L_0603CB98; case 0x0603CBF2u: goto L_0603CBF2; case 0x0603CC84u: goto L_0603CC84; default: sh2_call(c, x); return; } }  // 0603CB3E jmp @r0 ; nop
L_0603CB4C:
    c.r[5] = 0x0u;  // 0603CB4C mov #0,r5
    c.r[8] = 0x11u;  // 0603CB4E mov #17,r8
    c.r[4] = ld32(0x0603CC80u);  // 0603CB50 mov.l 0x0603CC80,r4
    c.r[9] = c.r[3];  // 0603CB52 mov r3,r9
    c.r[9] += c.r[2];  // 0603CB54 add r2,r9
    c.r[11] = (uint32_t)(int16_t)ld16(0x0603CC46u);  // 0603CB56 mov.w 0x0603CC46,r11
    c.r[7] = 0x0u;  // 0603CB58 mov #0,r7
    c.r[2] = 0x0u;  // 0603CB5A mov #0,r2
L_0603CB5C:
    c.r[3] = 0x0u;  // 0603CB5C mov #0,r3
    c.r[6] = c.r[9];  // 0603CB5E mov r9,r6
    c.r[6] += c.r[11];  // 0603CB60 add r11,r6
L_0603CB62:
    c.r[0] = c.r[2];  // 0603CB62 mov r2,r0
    c.r[0] += c.r[3];  // 0603CB64 add r3,r0
    c.r[0] <<= 2;  // 0603CB66 shll2 r0
    c.r[1] = c.r[7];  // 0603CB68 mov r7,r1
    c.r[1] += c.r[3];  // 0603CB6A add r3,r1
    c.r[1] += c.r[6];  // 0603CB6C add r6,r1
    c.r[3] += 1;  // 0603CB6E add #1,r3
    c.t = (int32_t)c.r[3] > (int32_t)c.r[8];  // 0603CB70 cmp/gt r8,r3
    { const bool k = !c.t; st32(c.r[0] + c.r[4], c.r[1]); if (k) { SH2_POLL(c); goto L_0603CB62; } }  // 0603CB72 bf/s 0x0603CB62 ; mov.l r1,@(r0,r4)
    c.r[7] += 18;  // 0603CB76 add #18,r7
    c.r[5] += 1;  // 0603CB78 add #1,r5
    c.r[1] = 0xDu;  // 0603CB7A mov #13,r1
    c.t = (int32_t)c.r[5] > (int32_t)c.r[1];  // 0603CB7C cmp/gt r1,r5
    { const bool k = !c.t; c.r[2] += 64; if (k) { SH2_POLL(c); goto L_0603CB5C; } }  // 0603CB7E bf/s 0x0603CB5C ; add #64,r2
    c.r[1] = ld32(0x0603CC68u);  // 0603CB82 mov.l 0x0603CC68,r1
    c.r[2] = ld32(c.r[1] + 16);  // 0603CB84 mov.l @(16,r1),r2
    c.r[1] = c.r[10];  // 0603CB86 mov r10,r1
    c.r[1] <<= 2;  // 0603CB88 shll2 r1
    c.r[3] = c.r[1];  // 0603CB8A mov r1,r3
    c.r[3] += c.r[2];  // 0603CB8C add r2,r3
    c.r[0] = c.r[1];  // 0603CB8E mov r1,r0
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 0603CB90 mov.w @(r0,r2),r6
    c.r[3] += 2;  // 0603CB92 add #2,r3
    c.r[7] = (uint32_t)(int16_t)ld16(c.r[3]); goto L_0603CCE8;  // 0603CB94 bra 0x0603CCE8 ; mov.w @r3,r7
L_0603CB98:
    c.r[5] = 0x0u;  // 0603CB98 mov #0,r5
    c.r[8] = 0x11u;  // 0603CB9A mov #17,r8
    c.r[4] = ld32(0x0603CC80u);  // 0603CB9C mov.l 0x0603CC80,r4
    c.r[9] = c.r[3];  // 0603CB9E mov r3,r9
    c.r[9] += c.r[2];  // 0603CBA0 add r2,r9
    c.r[11] = (uint32_t)(int16_t)ld16(0x0603CC46u);  // 0603CBA2 mov.w 0x0603CC46,r11
    c.r[7] = 0x0u;  // 0603CBA4 mov #0,r7
    c.r[2] = 0x0u;  // 0603CBA6 mov #0,r2
L_0603CBA8:
    c.r[3] = 0x0u;  // 0603CBA8 mov #0,r3
    c.r[6] = c.r[9];  // 0603CBAA mov r9,r6
    c.r[6] += c.r[11];  // 0603CBAC add r11,r6
L_0603CBAE:
    c.r[12] = c.r[2];  // 0603CBAE mov r2,r12
    c.r[12] += c.r[3];  // 0603CBB0 add r3,r12
    c.r[12] <<= 2;  // 0603CBB2 shll2 r12
    c.r[1] = c.r[3];  // 0603CBB4 mov r3,r1
    c.r[1] -= 17;  // 0603CBB6 add #-17,r1
    c.r[0] = c.r[7];  // 0603CBB8 mov r7,r0
    c.r[0] -= c.r[1];  // 0603CBBA sub r1,r0
    c.r[1] = c.r[0];  // 0603CBBC mov r0,r1
    c.r[1] += c.r[6];  // 0603CBBE add r6,r1
    c.r[0] = c.r[12];  // 0603CBC0 mov r12,r0
    c.r[3] += 1;  // 0603CBC2 add #1,r3
    c.t = (int32_t)c.r[3] > (int32_t)c.r[8];  // 0603CBC4 cmp/gt r8,r3
    { const bool k = !c.t; st32(c.r[0] + c.r[4], c.r[1]); if (k) { SH2_POLL(c); goto L_0603CBAE; } }  // 0603CBC6 bf/s 0x0603CBAE ; mov.l r1,@(r0,r4)
    c.r[7] += 18;  // 0603CBCA add #18,r7
    c.r[5] += 1;  // 0603CBCC add #1,r5
    c.r[1] = 0xDu;  // 0603CBCE mov #13,r1
    c.t = (int32_t)c.r[5] > (int32_t)c.r[1];  // 0603CBD0 cmp/gt r1,r5
    { const bool k = !c.t; c.r[2] += 64; if (k) { SH2_POLL(c); goto L_0603CBA8; } }  // 0603CBD2 bf/s 0x0603CBA8 ; add #64,r2
    c.r[1] = ld32(0x0603CC68u);  // 0603CBD6 mov.l 0x0603CC68,r1
    c.r[2] = ld32(c.r[1] + 16);  // 0603CBD8 mov.l @(16,r1),r2
    c.r[1] = c.r[10];  // 0603CBDA mov r10,r1
    c.r[1] <<= 2;  // 0603CBDC shll2 r1
    c.r[3] = c.r[1];  // 0603CBDE mov r1,r3
    c.r[3] += c.r[2];  // 0603CBE0 add r2,r3
    c.r[0] = c.r[1];  // 0603CBE2 mov r1,r0
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 0603CBE4 mov.w @(r0,r2),r2
    c.r[3] += 2;  // 0603CBE6 add #2,r3
    c.r[7] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0603CBE8 mov.w @r3,r7
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603CC48u);  // 0603CBEA mov.w 0x0603CC48,r1
    c.r[1] -= c.r[2];  // 0603CBEC sub r2,r1
    c.r[6] = (uint32_t)(int32_t)(int16_t)c.r[1]; goto L_0603CCE8;  // 0603CBEE bra 0x0603CCE8 ; exts.w r1,r6
L_0603CBF2:
    c.r[5] = 0x0u;  // 0603CBF2 mov #0,r5
    c.r[9] = 0x11u;  // 0603CBF4 mov #17,r9
    c.r[8] = ld32(0x0603CC80u);  // 0603CBF6 mov.l 0x0603CC80,r8
    c.r[11] = c.r[3];  // 0603CBF8 mov r3,r11
    c.r[11] += c.r[2];  // 0603CBFA add r2,r11
    c.r[12] = (uint32_t)(int16_t)ld16(0x0603CC46u);  // 0603CBFC mov.w 0x0603CC46,r12
    c.r[2] = 0x0u;  // 0603CBFE mov #0,r2
    c.r[4] = 0xDu;  // 0603CC00 mov #13,r4
L_0603CC02:
    c.r[3] = 0x0u;  // 0603CC02 mov #0,r3
    c.r[6] = c.r[11];  // 0603CC04 mov r11,r6
    c.r[6] += c.r[12];  // 0603CC06 add r12,r6
    c.r[7] = c.r[4];  // 0603CC08 mov r4,r7
L_0603CC0A:
    c.r[0] = c.r[2];  // 0603CC0A mov r2,r0
    c.r[1] = 0x12u;  // 0603CC0C mov #18,r1
    c.macl = c.r[7] * c.r[1];  // 0603CC0E mul.l r1,r7
    c.r[0] += c.r[3];  // 0603CC10 add r3,r0
    c.r[0] <<= 2;  // 0603CC12 shll2 r0
    c.r[1] = c.macl;  // 0603CC14 sts macl,r1
    c.r[1] += c.r[3];  // 0603CC16 add r3,r1
    c.r[1] += c.r[6];  // 0603CC18 add r6,r1
    c.r[3] += 1;  // 0603CC1A add #1,r3
    c.t = (int32_t)c.r[3] > (int32_t)c.r[9];  // 0603CC1C cmp/gt r9,r3
    { const bool k = !c.t; st32(c.r[0] + c.r[8], c.r[1]); if (k) { SH2_POLL(c); goto L_0603CC0A; } }  // 0603CC1E bf/s 0x0603CC0A ; mov.l r1,@(r0,r8)
    c.r[2] += 64;  // 0603CC22 add #64,r2
    c.r[5] += 1;  // 0603CC24 add #1,r5
    c.r[1] = 0xDu;  // 0603CC26 mov #13,r1
    c.t = (int32_t)c.r[5] > (int32_t)c.r[1];  // 0603CC28 cmp/gt r1,r5
    { const bool k = !c.t; c.r[4] -= 1; if (k) { SH2_POLL(c); goto L_0603CC02; } }  // 0603CC2A bf/s 0x0603CC02 ; add #-1,r4
    c.r[1] = ld32(0x0603CC68u);  // 0603CC2E mov.l 0x0603CC68,r1
    c.r[2] = ld32(c.r[1] + 16);  // 0603CC30 mov.l @(16,r1),r2
    c.r[1] = c.r[10];  // 0603CC32 mov r10,r1
    c.r[1] <<= 2;  // 0603CC34 shll2 r1
    c.r[3] = c.r[1];  // 0603CC36 mov r1,r3
    c.r[3] += c.r[2];  // 0603CC38 add r2,r3
    c.r[0] = c.r[1];  // 0603CC3A mov r1,r0
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 0603CC3C mov.w @(r0,r2),r6
    c.r[3] += 2; goto L_0603CCDC;  // 0603CC3E bra 0x0603CCDC ; add #2,r3
L_0603CC84:
    c.r[5] = 0x0u;  // 0603CC84 mov #0,r5
    c.r[11] = 0x11u;  // 0603CC86 mov #17,r11
    c.r[9] = ld32(0x0603CD28u);  // 0603CC88 mov.l 0x0603CD28,r9
    c.r[12] = c.r[3];  // 0603CC8A mov r3,r12
    c.r[12] += c.r[2];  // 0603CC8C add r2,r12
    c.r[13] = (uint32_t)(int16_t)ld16(0x0603CD24u);  // 0603CC8E mov.w 0x0603CD24,r13
    c.r[7] = 0x0u;  // 0603CC90 mov #0,r7
    c.r[8] = 0xDu;  // 0603CC92 mov #13,r8
L_0603CC94:
    c.r[3] = 0x0u;  // 0603CC94 mov #0,r3
    c.r[4] = c.r[12];  // 0603CC96 mov r12,r4
    c.r[4] += c.r[13];  // 0603CC98 add r13,r4
    c.r[6] = c.r[8];  // 0603CC9A mov r8,r6
L_0603CC9C:
    c.r[0] = c.r[7];  // 0603CC9C mov r7,r0
    c.r[1] = 0x12u;  // 0603CC9E mov #18,r1
    c.macl = c.r[6] * c.r[1];  // 0603CCA0 mul.l r1,r6
    c.r[0] += c.r[3];  // 0603CCA2 add r3,r0
    c.r[0] <<= 2;  // 0603CCA4 shll2 r0
    c.r[2] = c.macl;  // 0603CCA6 sts macl,r2
    c.r[1] = c.r[3];  // 0603CCA8 mov r3,r1
    c.r[1] -= 17;  // 0603CCAA add #-17,r1
    c.r[2] -= c.r[1];  // 0603CCAC sub r1,r2
    c.r[2] += c.r[4];  // 0603CCAE add r4,r2
    c.r[3] += 1;  // 0603CCB0 add #1,r3
    c.t = (int32_t)c.r[3] > (int32_t)c.r[11];  // 0603CCB2 cmp/gt r11,r3
    { const bool k = !c.t; st32(c.r[0] + c.r[9], c.r[2]); if (k) { SH2_POLL(c); goto L_0603CC9C; } }  // 0603CCB4 bf/s 0x0603CC9C ; mov.l r2,@(r0,r9)
    c.r[7] += 64;  // 0603CCB8 add #64,r7
    c.r[5] += 1;  // 0603CCBA add #1,r5
    c.r[1] = 0xDu;  // 0603CCBC mov #13,r1
    c.t = (int32_t)c.r[5] > (int32_t)c.r[1];  // 0603CCBE cmp/gt r1,r5
    { const bool k = !c.t; c.r[8] -= 1; if (k) { SH2_POLL(c); goto L_0603CC94; } }  // 0603CCC0 bf/s 0x0603CC94 ; add #-1,r8
    c.r[1] = ld32(0x0603CD2Cu);  // 0603CCC4 mov.l 0x0603CD2C,r1
    c.r[2] = ld32(c.r[1] + 16);  // 0603CCC6 mov.l @(16,r1),r2
    c.r[1] = c.r[10];  // 0603CCC8 mov r10,r1
    c.r[1] <<= 2;  // 0603CCCA shll2 r1
    c.r[3] = c.r[1];  // 0603CCCC mov r1,r3
    c.r[3] += c.r[2];  // 0603CCCE add r2,r3
    c.r[0] = c.r[1];  // 0603CCD0 mov r1,r0
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 0603CCD2 mov.w @(r0,r2),r2
    c.r[3] += 2;  // 0603CCD4 add #2,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603CD26u);  // 0603CCD6 mov.w 0x0603CD26,r1
    c.r[1] -= c.r[2];  // 0603CCD8 sub r2,r1
    c.r[6] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 0603CCDA exts.w r1,r6
L_0603CCDC:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0603CCDC mov.w @r3,r1
    c.r[1] = 0u - c.r[1];  // 0603CCDE neg r1,r1
    c.r[1] += 112;  // 0603CCE0 add #112,r1
    c.r[7] = (uint32_t)(int32_t)(int16_t)c.r[1]; goto L_0603CCE8;  // 0603CCE2 bra 0x0603CCE8 ; exts.w r1,r7
L_0603CCE6:
    c.r[7] = 0x0u;  // 0603CCE6 mov #0,r7
L_0603CCE8:
    c.r[3] = ld32(0x0603CD30u);  // 0603CCE8 mov.l 0x0603CD30,r3
    c.r[1] = c.r[3];  // 0603CCEA mov r3,r1
    c.r[1] += 51;  // 0603CCEC add #51,r1
    c.r[2] = 0x0u;  // 0603CCEE mov #0,r2
    st8(c.r[1], c.r[2]);  // 0603CCF0 mov.b r2,@r1
    c.r[1] = c.r[3];  // 0603CCF2 mov r3,r1
    c.r[1] += 52;  // 0603CCF4 add #52,r1
    st8(c.r[1], c.r[2]);  // 0603CCF6 mov.b r2,@r1
    c.r[1] = c.r[3];  // 0603CCF8 mov r3,r1
    c.r[1] += 62;  // 0603CCFA add #62,r1
    c.r[6] -= 1;  // 0603CCFC add #-1,r6
    st16(c.r[1], c.r[6]);  // 0603CCFE mov.w r6,@r1
    c.r[3] += 64;  // 0603CD00 add #64,r3
    c.r[0] = ld32(c.r[14]);  // 0603CD02 mov.l @r14,r0
    c.r[7] -= 1;  // 0603CD04 add #-1,r7
    c.r[0] += 2;  // 0603CD06 add #2,r0
    st32(c.r[14], c.r[0]);  // 0603CD08 mov.l r0,@r14
    c.r[0] = ld32(c.r[14]);  // 0603CD0A mov.l @r14,r0
    st16(c.r[3], c.r[7]);  // 0603CD0C mov.w r7,@r3
    c.r[14] += 4;  // 0603CD0E add #4,r14
    c.r[15] = c.r[14];  // 0603CD10 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603CD12 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603CD14 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0603CD16 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0603CD18 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0603CD1A mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0603CD1C mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0603CD1E mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603CD20 rts ; mov.l @r15+,r8
}

void f_0603CD34(SH2Context& c) {
    ran[939] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603CD34 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603CD36 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0603CD38 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0603CD3A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603CD3C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603CD3E sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0603CD40 mov r15,r14
    c.r[11] = c.r[4];  // 0603CD42 mov r4,r11
    c.r[8] = c.r[5];  // 0603CD44 mov r5,r8
    c.r[10] = c.r[8];  // 0603CD46 mov r8,r10
    c.r[10] += 1;  // 0603CD48 add #1,r10
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0603CD4A mov.b @r10,r4
    c.r[0] = ld32(0x0603CED8u);  // 0603CD4C mov.l 0x0603CED8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0603CD52u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603CD52u) return; }  // 0603CD4E jsr @r0 ; extu.b r4,r4
    c.r[9] = c.r[0];  // 0603CD52 mov r0,r9
    c.t = (c.r[9] & c.r[9]) == 0;  // 0603CD54 tst r9,r9
    if (!c.t) { goto L_0603CD5C; }  // 0603CD56 bf 0x0603CD5C
    goto L_0603CEBC;  // 0603CD58 bra 0x0603CEBC ; nop
L_0603CD5C:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0603CD5C mov.b @r10,r0
    c.r[0] &= 0x80u;  // 0603CD5E and #128,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603CD60 tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[8]; if (k) { goto L_0603CD82; } }  // 0603CD62 bt/s 0x0603CD82 ; mov r8,r1
    c.r[1] += 9;  // 0603CD66 add #9,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603CD68 mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0603CD6A extu.b r2,r2
    c.r[1] = c.r[8];  // 0603CD6C mov r8,r1
    c.r[1] += 10;  // 0603CD6E add #10,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603CD70 mov.b @r1,r1
    c.r[2] <<= 8;  // 0603CD72 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603CD74 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0603CD76 or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0603CD78 exts.w r2,r2
    c.r[2] += 9;  // 0603CD7A add #9,r2
    c.r[2] += c.r[8];  // 0603CD7C add r8,r2
    st32(c.r[9] + 36, c.r[2]); goto L_0603CD9A;  // 0603CD7E bra 0x0603CD9A ; mov.l r2,@(36,r9)
L_0603CD82:
    c.r[1] += 9;  // 0603CD82 add #9,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603CD84 mov.b @r1,r5
    c.r[5] = c.r[5] & 0xFFu;  // 0603CD86 extu.b r5,r5
    c.r[1] = c.r[8];  // 0603CD88 mov r8,r1
    c.r[1] += 10;  // 0603CD8A add #10,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603CD8C mov.b @r1,r1
    c.r[5] <<= 8;  // 0603CD8E shll8 r5
    c.r[1] = c.r[1] & 0xFFu;  // 0603CD90 extu.b r1,r1
    c.r[5] |= c.r[1];  // 0603CD92 or r1,r5
    c.r[1] = ld32(0x0603CEDCu);  // 0603CD94 mov.l 0x0603CEDC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603CD9Au; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603CD9Au) return; }  // 0603CD96 jsr @r1 ; mov r9,r4
L_0603CD9A:
    c.r[3] = c.r[8];  // 0603CD9A mov r8,r3
    c.r[3] += 2;  // 0603CD9C add #2,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0603CD9E mov.b @r3,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603CED0u);  // 0603CDA0 mov.w 0x0603CED0,r1
    c.r[1] &= c.r[2];  // 0603CDA2 and r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603CDA4 tst r1,r1
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_0603CDF4; } }  // 0603CDA6 bt/s 0x0603CDF4 ; mov r9,r1
    c.r[2] = c.r[9];  // 0603CDAA mov r9,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[11]);  // 0603CDAC mov.b @r11,r1
    c.r[2] += 65;  // 0603CDAE add #65,r2
    st8(c.r[2], c.r[1]);  // 0603CDB0 mov.b r1,@r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0603CDB2 mov.b @r3,r0
    c.r[0] &= 0x80u;  // 0603CDB4 and #128,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603CDB6 tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[8]; if (k) { goto L_0603CDFA; } }  // 0603CDB8 bt/s 0x0603CDFA ; mov r8,r1
    c.r[1] += 3;  // 0603CDBC add #3,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603CDBE mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0603CDC0 extu.b r2,r2
    c.r[1] = c.r[8];  // 0603CDC2 mov r8,r1
    c.r[1] += 4;  // 0603CDC4 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603CDC6 mov.b @r1,r1
    c.r[2] <<= 8;  // 0603CDC8 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603CDCA extu.b r1,r1
    c.r[2] |= c.r[1];  // 0603CDCC or r1,r2
    c.r[1] = ld32(c.r[11] + 4);  // 0603CDCE mov.l @(4,r11),r1
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0603CDD0 exts.w r2,r2
    c.r[1] += c.r[2];  // 0603CDD2 add r2,r1
    st32(c.r[9] + 4, c.r[1]);  // 0603CDD4 mov.l r1,@(4,r9)
    c.r[1] = c.r[8];  // 0603CDD6 mov r8,r1
    c.r[1] += 5;  // 0603CDD8 add #5,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603CDDA mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0603CDDC extu.b r2,r2
    c.r[1] = c.r[8];  // 0603CDDE mov r8,r1
    c.r[1] += 6;  // 0603CDE0 add #6,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603CDE2 mov.b @r1,r1
    c.r[2] <<= 8;  // 0603CDE4 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603CDE6 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0603CDE8 or r1,r2
    c.r[1] = ld32(c.r[11] + 8);  // 0603CDEA mov.l @(8,r11),r1
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0603CDEC exts.w r2,r2
    c.r[1] += c.r[2];  // 0603CDEE add r2,r1
    st32(c.r[9] + 8, c.r[1]); goto L_0603CE28;  // 0603CDF0 bra 0x0603CE28 ; mov.l r1,@(8,r9)
L_0603CDF4:
    c.r[1] += 65;  // 0603CDF4 add #65,r1
    st8(c.r[1], c.r[2]);  // 0603CDF6 mov.b r2,@r1
    c.r[1] = c.r[8];  // 0603CDF8 mov r8,r1
L_0603CDFA:
    c.r[1] += 3;  // 0603CDFA add #3,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603CDFC mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0603CDFE extu.b r2,r2
    c.r[1] = c.r[8];  // 0603CE00 mov r8,r1
    c.r[1] += 4;  // 0603CE02 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603CE04 mov.b @r1,r1
    c.r[2] <<= 8;  // 0603CE06 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603CE08 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0603CE0A or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0603CE0C exts.w r2,r2
    st32(c.r[9] + 4, c.r[2]);  // 0603CE0E mov.l r2,@(4,r9)
    c.r[1] = c.r[8];  // 0603CE10 mov r8,r1
    c.r[1] += 5;  // 0603CE12 add #5,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603CE14 mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0603CE16 extu.b r2,r2
    c.r[1] = c.r[8];  // 0603CE18 mov r8,r1
    c.r[1] += 6;  // 0603CE1A add #6,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603CE1C mov.b @r1,r1
    c.r[2] <<= 8;  // 0603CE1E shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603CE20 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0603CE22 or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0603CE24 exts.w r2,r2
    st32(c.r[9] + 8, c.r[2]);  // 0603CE26 mov.l r2,@(8,r9)
L_0603CE28:
    c.r[1] = c.r[8];  // 0603CE28 mov r8,r1
    c.r[1] += 7;  // 0603CE2A add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603CE2C mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0603CE2E extu.b r1,r1
    c.r[7] = c.r[1];  // 0603CE30 mov r1,r7
    c.r[7] <<= 8;  // 0603CE32 shll8 r7
    c.r[1] = c.r[8];  // 0603CE34 mov r8,r1
    c.r[1] += 8;  // 0603CE36 add #8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603CE38 mov.b @r1,r1
    c.r[6] = 0x40u;  // 0603CE3A mov #64,r6
    c.r[1] = c.r[1] & 0xFFu;  // 0603CE3C extu.b r1,r1
    c.r[7] |= c.r[1];  // 0603CE3E or r1,r7
    c.r[1] = ld32(0x0603CEE0u);  // 0603CE40 mov.l 0x0603CEE0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603CE42 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0603CE44 extu.b r1,r1
    c.r[0] = c.r[1];  // 0603CE46 mov r1,r0
    c.r[0] >>= 2;  // 0603CE48 shlr2 r0
    c.r[0] >>= 2;  // 0603CE4A shlr2 r0
    c.r[0] >>= 2;  // 0603CE4C shlr2 r0
    c.r[1] >>= 2;  // 0603CE4E shlr2 r1
    c.r[1] >>= 2;  // 0603CE50 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0603CE52 shlr r1
    c.r[1] >>= 2;  // 0603CE54 shlr2 r1
    c.r[0] &= 0x1u;  // 0603CE56 and #1,r0
    c.t = c.r[1] == c.r[0];  // 0603CE58 cmp/eq r0,r1
    { const bool k = c.t; c.r[7] |= c.r[6]; if (k) { goto L_0603CE68; } }  // 0603CE5A bt/s 0x0603CE68 ; or r6,r7
    c.r[1] = ld32(c.r[9] + 4);  // 0603CE5E mov.l @(4,r9),r1
    c.r[1] = 0u - c.r[1];  // 0603CE60 neg r1,r1
    st32(c.r[9] + 4, c.r[1]);  // 0603CE62 mov.l r1,@(4,r9)
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603CED2u);  // 0603CE64 mov.w 0x0603CED2,r1
    c.r[7] ^= c.r[1];  // 0603CE66 xor r1,r7
L_0603CE68:
    c.r[1] = c.r[9];  // 0603CE68 mov r9,r1
    c.r[1] += 56;  // 0603CE6A add #56,r1
    c.r[3] = 0x0u;  // 0603CE6C mov #0,r3
    st16(c.r[1], c.r[3]);  // 0603CE6E mov.w r3,@r1
    c.r[1] = ld32(0x0603CEE4u);  // 0603CE70 mov.l 0x0603CEE4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603CE76u; c.r[4] = (uint32_t)(int32_t)(int16_t)c.r[7]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603CE76u) return; }  // 0603CE72 jsr @r1 ; exts.w r7,r4
    c.r[0] = c.r[4];  // 0603CE76 mov r4,r0
    c.r[0] &= 0x1u;  // 0603CE78 and #1,r0
    c.r[1] = c.r[9];  // 0603CE7A mov r9,r1
    c.r[1] += 2;  // 0603CE7C add #2,r1
    c.r[0] += c.r[0];  // 0603CE7E add r0,r0
    c.r[6] = (uint32_t)(int16_t)ld16(0x0603CED4u);  // 0603CE80 mov.w 0x0603CED4,r6
    c.r[5] = c.r[7];  // 0603CE82 mov r7,r5
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603CE84 mov.b @r1,r2
    c.r[2] &= c.r[6];  // 0603CE86 and r6,r2
    c.r[2] |= c.r[0];  // 0603CE88 or r0,r2
    c.r[6] = (uint32_t)(int16_t)ld16(0x0603CED6u);  // 0603CE8A mov.w 0x0603CED6,r6
    c.r[2] &= c.r[6];  // 0603CE8C and r6,r2
    st8(c.r[1], c.r[2]);  // 0603CE8E mov.b r2,@r1
    c.r[1] = c.r[9];  // 0603CE90 mov r9,r1
    c.r[1] += 58;  // 0603CE92 add #58,r1
    st16(c.r[1], c.r[3]);  // 0603CE94 mov.w r3,@r1
    c.r[2] = c.r[9];  // 0603CE96 mov r9,r2
    c.r[1] = c.r[8];  // 0603CE98 mov r8,r1
    c.r[1] += 11;  // 0603CE9A add #11,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603CE9C mov.b @r1,r1
    c.r[2] += 61;  // 0603CE9E add #61,r2
    st8(c.r[2], c.r[1]);  // 0603CEA0 mov.b r1,@r2
    c.r[1] = c.r[9];  // 0603CEA2 mov r9,r1
    c.r[1] += 16;  // 0603CEA4 add #16,r1
    st16(c.r[1], c.r[3]);  // 0603CEA6 mov.w r3,@r1
    c.r[1] = c.r[9];  // 0603CEA8 mov r9,r1
    c.r[1] += 18;  // 0603CEAA add #18,r1
    st16(c.r[1], c.r[3]);  // 0603CEAC mov.w r3,@r1
    c.r[2] = c.r[9];  // 0603CEAE mov r9,r2
    c.r[2] += 64;  // 0603CEB0 add #64,r2
    c.r[1] = 0xAu;  // 0603CEB2 mov #10,r1
    st8(c.r[2], c.r[1]);  // 0603CEB4 mov.b r1,@r2
    c.r[1] = ld32(0x0603CEE8u);  // 0603CEB6 mov.l 0x0603CEE8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603CEBCu; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603CEBCu) return; }  // 0603CEB8 jsr @r1 ; mov r9,r4
L_0603CEBC:
    c.r[8] += 12;  // 0603CEBC add #12,r8
    c.r[0] = c.r[8];  // 0603CEBE mov r8,r0
    c.r[15] = c.r[14];  // 0603CEC0 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603CEC2 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603CEC4 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0603CEC6 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0603CEC8 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0603CECA mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603CECC rts ; mov.l @r15+,r8
}

void f_0603CEEC(SH2Context& c) {
    ran[940] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603CEEC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603CEEE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0603CEF0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0603CEF2 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603CEF4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603CEF6 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0603CEF8 mov r15,r14
    c.r[9] = c.r[5];  // 0603CEFA mov r5,r9
    c.r[11] = c.r[9];  // 0603CEFC mov r9,r11
    c.r[11] += 1;  // 0603CEFE add #1,r11
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[11]);  // 0603CF00 mov.b @r11,r4
    c.r[0] = ld32(0x0603D024u);  // 0603CF02 mov.l 0x0603D024,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0603CF08u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603CF08u) return; }  // 0603CF04 jsr @r0 ; extu.b r4,r4
    c.r[8] = c.r[0];  // 0603CF08 mov r0,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 0603CF0A tst r8,r8
    if (!c.t) { goto L_0603CF14; }  // 0603CF0C bf 0x0603CF14
    c.r[9] += 11;  // 0603CF0E add #11,r9
    c.r[0] = c.r[9]; goto L_0603D00E;  // 0603CF10 bra 0x0603D00E ; mov r9,r0
L_0603CF14:
    c.r[1] = c.r[9];  // 0603CF14 mov r9,r1
    c.r[1] += 2;  // 0603CF16 add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603CF18 mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0603CF1A extu.b r2,r2
    c.r[1] = c.r[9];  // 0603CF1C mov r9,r1
    c.r[1] += 3;  // 0603CF1E add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603CF20 mov.b @r1,r1
    c.r[2] <<= 8;  // 0603CF22 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603CF24 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0603CF26 or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0603CF28 exts.w r2,r2
    st32(c.r[8] + 4, c.r[2]);  // 0603CF2A mov.l r2,@(4,r8)
    c.r[1] = c.r[9];  // 0603CF2C mov r9,r1
    c.r[1] += 4;  // 0603CF2E add #4,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603CF30 mov.b @r1,r2
    c.r[3] = c.r[8];  // 0603CF32 mov r8,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0603CF34 extu.b r2,r2
    c.r[1] = c.r[9];  // 0603CF36 mov r9,r1
    c.r[1] += 5;  // 0603CF38 add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603CF3A mov.b @r1,r1
    c.r[2] <<= 8;  // 0603CF3C shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603CF3E extu.b r1,r1
    c.r[2] |= c.r[1];  // 0603CF40 or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0603CF42 exts.w r2,r2
    st32(c.r[8] + 8, c.r[2]);  // 0603CF44 mov.l r2,@(8,r8)
    c.r[1] = c.r[9];  // 0603CF46 mov r9,r1
    c.r[1] += 6;  // 0603CF48 add #6,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603CF4A mov.b @r1,r1
    c.r[3] += 2;  // 0603CF4C add #2,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0603CF4E extu.b r1,r1
    c.r[10] = c.r[1];  // 0603CF50 mov r1,r10
    c.r[10] <<= 8;  // 0603CF52 shll8 r10
    c.r[1] = c.r[9];  // 0603CF54 mov r9,r1
    c.r[1] += 7;  // 0603CF56 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603CF58 mov.b @r1,r1
    c.r[2] = 0x0u;  // 0603CF5A mov #0,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603CF5C extu.b r1,r1
    c.r[10] |= c.r[1];  // 0603CF5E or r1,r10
    c.r[1] = c.r[8];  // 0603CF60 mov r8,r1
    c.r[1] += 56;  // 0603CF62 add #56,r1
    st16(c.r[1], c.r[2]);  // 0603CF64 mov.w r2,@r1
    c.r[1] = c.r[8];  // 0603CF66 mov r8,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0603CF68 mov.b @r3,r0
    c.r[1] += 58;  // 0603CF6A add #58,r1
    c.r[0] &= 0xFCu;  // 0603CF6C and #252,r0
    st8(c.r[3], c.r[0]);  // 0603CF6E mov.b r0,@r3
    st16(c.r[1], c.r[2]);  // 0603CF70 mov.w r2,@r1
    c.r[1] = c.r[8];  // 0603CF72 mov r8,r1
    c.r[1] += 16;  // 0603CF74 add #16,r1
    st16(c.r[1], c.r[2]);  // 0603CF76 mov.w r2,@r1
    c.r[1] = c.r[8];  // 0603CF78 mov r8,r1
    c.r[1] += 18;  // 0603CF7A add #18,r1
    st16(c.r[1], c.r[2]);  // 0603CF7C mov.w r2,@r1
    c.r[2] = c.r[8];  // 0603CF7E mov r8,r2
    c.r[2] += 64;  // 0603CF80 add #64,r2
    c.r[1] = 0xAu;  // 0603CF82 mov #10,r1
    st8(c.r[2], c.r[1]);  // 0603CF84 mov.b r1,@r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[11]);  // 0603CF86 mov.b @r11,r0
    c.r[0] &= 0x80u;  // 0603CF88 and #128,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603CF8A tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[9]; if (k) { goto L_0603CFDE; } }  // 0603CF8C bf/s 0x0603CFDE ; mov r9,r1
    c.r[1] = ld32(0x0603D028u);  // 0603CF90 mov.l 0x0603D028,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603CF92 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0603CF94 extu.b r1,r1
    c.r[0] = c.r[1];  // 0603CF96 mov r1,r0
    c.r[0] >>= 2;  // 0603CF98 shlr2 r0
    c.r[0] >>= 2;  // 0603CF9A shlr2 r0
    c.r[0] >>= 2;  // 0603CF9C shlr2 r0
    c.r[1] >>= 2;  // 0603CF9E shlr2 r1
    c.r[1] >>= 2;  // 0603CFA0 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0603CFA2 shlr r1
    c.r[1] >>= 2;  // 0603CFA4 shlr2 r1
    c.r[0] &= 0x1u;  // 0603CFA6 and #1,r0
    c.t = c.r[1] == c.r[0];  // 0603CFA8 cmp/eq r0,r1
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_0603CFC2; } }  // 0603CFAA bt/s 0x0603CFC2 ; mov r9,r1
    c.r[1] = ld32(c.r[8] + 4);  // 0603CFAE mov.l @(4,r8),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0603D01Eu);  // 0603CFB0 mov.w 0x0603D01E,r2
    c.r[2] -= c.r[1];  // 0603CFB2 sub r1,r2
    st32(c.r[8] + 4, c.r[2]);  // 0603CFB4 mov.l r2,@(4,r8)
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603D020u);  // 0603CFB6 mov.w 0x0603D020,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0603CFB8 mov.b @r3,r0
    c.r[10] |= c.r[1];  // 0603CFBA or r1,r10
    c.r[0] |= 0x2u;  // 0603CFBC or #2,r0
    st8(c.r[3], c.r[0]);  // 0603CFBE mov.b r0,@r3
    c.r[1] = c.r[9];  // 0603CFC0 mov r9,r1
L_0603CFC2:
    c.r[1] += 8;  // 0603CFC2 add #8,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603CFC4 mov.b @r1,r5
    c.r[5] = c.r[5] & 0xFFu;  // 0603CFC6 extu.b r5,r5
    c.r[1] = c.r[9];  // 0603CFC8 mov r9,r1
    c.r[1] += 9;  // 0603CFCA add #9,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603CFCC mov.b @r1,r1
    c.r[5] <<= 8;  // 0603CFCE shll8 r5
    c.r[1] = c.r[1] & 0xFFu;  // 0603CFD0 extu.b r1,r1
    c.r[5] |= c.r[1];  // 0603CFD2 or r1,r5
    c.r[1] = ld32(0x0603D02Cu);  // 0603CFD4 mov.l 0x0603D02C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603CFDAu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603CFDAu) return; }  // 0603CFD6 jsr @r1 ; mov r8,r4
    goto L_0603CFF8;  // 0603CFDA bra 0x0603CFF8 ; nop
L_0603CFDE:
    c.r[1] += 8;  // 0603CFDE add #8,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603CFE0 mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0603CFE2 extu.b r2,r2
    c.r[1] = c.r[9];  // 0603CFE4 mov r9,r1
    c.r[1] += 9;  // 0603CFE6 add #9,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603CFE8 mov.b @r1,r1
    c.r[2] <<= 8;  // 0603CFEA shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603CFEC extu.b r1,r1
    c.r[2] |= c.r[1];  // 0603CFEE or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0603CFF0 exts.w r2,r2
    c.r[2] += 8;  // 0603CFF2 add #8,r2
    c.r[2] += c.r[9];  // 0603CFF4 add r9,r2
    st32(c.r[8] + 36, c.r[2]);  // 0603CFF6 mov.l r2,@(36,r8)
L_0603CFF8:
    c.r[1] = ld32(0x0603D030u);  // 0603CFF8 mov.l 0x0603D030,r1
    c.r[5] = c.r[10];  // 0603CFFA mov r10,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0603D000u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603D000u) return; }  // 0603CFFC jsr @r1 ; mov r8,r4
    c.r[8] += 61;  // 0603D000 add #61,r8
    c.r[1] = c.r[9];  // 0603D002 mov r9,r1
    c.r[1] += 10;  // 0603D004 add #10,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603D006 mov.b @r1,r1
    c.r[9] += 11;  // 0603D008 add #11,r9
    c.r[0] = c.r[9];  // 0603D00A mov r9,r0
    st8(c.r[8], c.r[1]);  // 0603D00C mov.b r1,@r8
L_0603D00E:
    c.r[15] = c.r[14];  // 0603D00E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603D010 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603D012 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0603D014 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0603D016 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0603D018 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603D01A rts ; mov.l @r15+,r8
}

void f_0603D034(SH2Context& c) {
    ran[941] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603D034 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603D036 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0603D038 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603D03A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603D03C sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0603D03E mov r15,r14
    c.r[9] = c.r[5];  // 0603D040 mov r5,r9
    c.r[10] = c.r[9];  // 0603D042 mov r9,r10
    c.r[10] += 1;  // 0603D044 add #1,r10
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0603D046 mov.b @r10,r4
    c.r[0] = ld32(0x0603D0ECu);  // 0603D048 mov.l 0x0603D0EC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0603D04Eu; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603D04Eu) return; }  // 0603D04A jsr @r0 ; extu.b r4,r4
    c.r[8] = c.r[0];  // 0603D04E mov r0,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 0603D050 tst r8,r8
    { const bool k = c.t; c.r[1] = 0x0u; if (k) { goto L_0603D0D8; } }  // 0603D052 bt/s 0x0603D0D8 ; mov #0,r1
    st32(c.r[8] + 4, c.r[1]);  // 0603D056 mov.l r1,@(4,r8)
    st32(c.r[8] + 8, c.r[1]);  // 0603D058 mov.l r1,@(8,r8)
    c.r[1] = c.r[8];  // 0603D05A mov r8,r1
    c.r[1] += 56;  // 0603D05C add #56,r1
    c.r[2] = 0x0u;  // 0603D05E mov #0,r2
    st16(c.r[1], c.r[2]);  // 0603D060 mov.w r2,@r1
    c.r[1] = c.r[8];  // 0603D062 mov r8,r1
    c.r[1] += 2;  // 0603D064 add #2,r1
    c.r[3] = c.r[8];  // 0603D066 mov r8,r3
    c.r[3] += 61;  // 0603D068 add #61,r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603D06A mov.b @r1,r0
    c.r[5] = ld32(0x0603D0F0u);  // 0603D06C mov.l 0x0603D0F0,r5
    c.r[0] &= 0xFCu;  // 0603D06E and #252,r0
    st8(c.r[1], c.r[0]);  // 0603D070 mov.b r0,@r1
    c.r[1] = c.r[8];  // 0603D072 mov r8,r1
    c.r[1] += 58;  // 0603D074 add #58,r1
    st16(c.r[1], c.r[2]);  // 0603D076 mov.w r2,@r1
    c.r[1] = c.r[9];  // 0603D078 mov r9,r1
    c.r[1] += 4;  // 0603D07A add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603D07C mov.b @r1,r1
    st8(c.r[3], c.r[1]);  // 0603D07E mov.b r1,@r3
    c.r[1] = c.r[8];  // 0603D080 mov r8,r1
    c.r[1] += 16;  // 0603D082 add #16,r1
    st16(c.r[1], c.r[2]);  // 0603D084 mov.w r2,@r1
    c.r[1] = c.r[8];  // 0603D086 mov r8,r1
    c.r[1] += 18;  // 0603D088 add #18,r1
    st16(c.r[1], c.r[2]);  // 0603D08A mov.w r2,@r1
    c.r[2] = c.r[8];  // 0603D08C mov r8,r2
    c.r[2] += 64;  // 0603D08E add #64,r2
    c.r[1] = 0xAu;  // 0603D090 mov #10,r1
    st8(c.r[2], c.r[1]);  // 0603D092 mov.b r1,@r2
    c.r[1] = ld32(0x0603D0F4u);  // 0603D094 mov.l 0x0603D0F4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603D09Au; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603D09Au) return; }  // 0603D096 jsr @r1 ; mov r8,r4
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0603D09A mov.b @r10,r0
    c.r[0] &= 0x80u;  // 0603D09C and #128,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603D09E tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_0603D0C0; } }  // 0603D0A0 bt/s 0x0603D0C0 ; mov r9,r1
    c.r[1] += 2;  // 0603D0A4 add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603D0A6 mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0603D0A8 extu.b r2,r2
    c.r[1] = c.r[9];  // 0603D0AA mov r9,r1
    c.r[1] += 3;  // 0603D0AC add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603D0AE mov.b @r1,r1
    c.r[2] <<= 8;  // 0603D0B0 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603D0B2 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0603D0B4 or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0603D0B6 exts.w r2,r2
    c.r[2] += 2;  // 0603D0B8 add #2,r2
    c.r[2] += c.r[9];  // 0603D0BA add r9,r2
    st32(c.r[8] + 36, c.r[2]); goto L_0603D0D8;  // 0603D0BC bra 0x0603D0D8 ; mov.l r2,@(36,r8)
L_0603D0C0:
    c.r[1] += 2;  // 0603D0C0 add #2,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603D0C2 mov.b @r1,r5
    c.r[5] = c.r[5] & 0xFFu;  // 0603D0C4 extu.b r5,r5
    c.r[1] = c.r[9];  // 0603D0C6 mov r9,r1
    c.r[1] += 3;  // 0603D0C8 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603D0CA mov.b @r1,r1
    c.r[5] <<= 8;  // 0603D0CC shll8 r5
    c.r[1] = c.r[1] & 0xFFu;  // 0603D0CE extu.b r1,r1
    c.r[5] |= c.r[1];  // 0603D0D0 or r1,r5
    c.r[1] = ld32(0x0603D0F8u);  // 0603D0D2 mov.l 0x0603D0F8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603D0D8u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603D0D8u) return; }  // 0603D0D4 jsr @r1 ; mov r8,r4
L_0603D0D8:
    c.r[9] += 5;  // 0603D0D8 add #5,r9
    c.r[0] = c.r[9];  // 0603D0DA mov r9,r0
    c.r[15] = c.r[14];  // 0603D0DC mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603D0DE lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603D0E0 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0603D0E2 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0603D0E4 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603D0E6 rts ; mov.l @r15+,r8
}

void f_0603D0FC(SH2Context& c) {
    ran[942] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603D0FC mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0603D0FE mov r15,r14
    c.r[0] = c.r[5];  // 0603D100 mov r5,r0
    c.r[4] += 56;  // 0603D102 add #56,r4
    c.r[1] = c.r[0];  // 0603D104 mov r0,r1
    c.r[1] += 1;  // 0603D106 add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603D108 mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0603D10A extu.b r2,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[4]);  // 0603D10C mov.w @r4,r1
    c.r[2] <<= 8;  // 0603D10E shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603D110 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0603D112 or r1,r2
    st16(c.r[4], c.r[2]);  // 0603D114 mov.w r2,@r4
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603D116 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] += 2; c.pc = x; return; }  // 0603D118 rts ; add #2,r0
}

void f_0603D11C(SH2Context& c) {
    ran[943] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603D11C mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0603D11E mov r15,r14
    c.r[0] = c.r[5];  // 0603D120 mov r5,r0
    c.r[4] += 56;  // 0603D122 add #56,r4
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[4]);  // 0603D124 mov.w @r4,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603D13Cu);  // 0603D126 mov.w 0x0603D13C,r1
    c.r[2] &= c.r[1];  // 0603D128 and r1,r2
    c.r[1] = c.r[0];  // 0603D12A mov r0,r1
    c.r[1] += 1;  // 0603D12C add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603D12E mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0603D130 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0603D132 or r1,r2
    st16(c.r[4], c.r[2]);  // 0603D134 mov.w r2,@r4
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603D136 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] += 2; c.pc = x; return; }  // 0603D138 rts ; add #2,r0
}

void f_0603D140(SH2Context& c) {
    ran[944] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603D140 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0603D142 mov r15,r14
    c.r[0] = c.r[5];  // 0603D144 mov r5,r0
    c.r[4] += 56;  // 0603D146 add #56,r4
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[4]);  // 0603D148 mov.w @r4,r1
    c.r[1] += 1;  // 0603D14A add #1,r1
    st16(c.r[4], c.r[1]);  // 0603D14C mov.w r1,@r4
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603D14E mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] += 1; c.pc = x; return; }  // 0603D150 rts ; add #1,r0
}

void f_0603D154(SH2Context& c) {
    ran[945] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603D154 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0603D156 mov r15,r14
    c.r[0] = c.r[5];  // 0603D158 mov r5,r0
    c.r[4] += 56;  // 0603D15A add #56,r4
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[4]);  // 0603D15C mov.w @r4,r1
    c.r[1] -= 1;  // 0603D15E add #-1,r1
    st16(c.r[4], c.r[1]);  // 0603D160 mov.w r1,@r4
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603D162 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] += 1; c.pc = x; return; }  // 0603D164 rts ; add #1,r0
}

void f_0603D168(SH2Context& c) {
    ran[946] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603D168 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0603D16A mov r15,r14
    c.r[0] = c.r[5];  // 0603D16C mov r5,r0
    c.r[4] += 1;  // 0603D16E add #1,r4
    c.r[2] = 0x40u;  // 0603D170 mov #64,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]);  // 0603D172 mov.b @r4,r1
    c.r[1] |= c.r[2];  // 0603D174 or r2,r1
    st8(c.r[4], c.r[1]);  // 0603D176 mov.b r1,@r4
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603D178 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] += 1; c.pc = x; return; }  // 0603D17A rts ; add #1,r0
}

void f_0603D180(SH2Context& c) {
    ran[947] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603D180 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0603D182 mov r15,r14
    c.r[0] = c.r[5];  // 0603D184 mov r5,r0
    c.r[4] += 1;  // 0603D186 add #1,r4
    c.r[2] = (uint32_t)(int16_t)ld16(0x0603D196u);  // 0603D188 mov.w 0x0603D196,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]);  // 0603D18A mov.b @r4,r1
    c.r[1] &= c.r[2];  // 0603D18C and r2,r1
    st8(c.r[4], c.r[1]);  // 0603D18E mov.b r1,@r4
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603D190 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] += 1; c.pc = x; return; }  // 0603D192 rts ; add #1,r0
}

void f_0603D198(SH2Context& c) {
    ran[948] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603D198 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0603D19A mov r15,r14
    c.r[2] = c.r[5];  // 0603D19C mov r5,r2
    c.r[4] += 2;  // 0603D19E add #2,r4
    c.r[3] = (uint32_t)(int16_t)ld16(0x0603D1BCu);  // 0603D1A0 mov.w 0x0603D1BC,r3
    c.r[2] += 1;  // 0603D1A2 add #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]);  // 0603D1A4 mov.b @r4,r1
    c.r[0] = c.r[1];  // 0603D1A6 mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0603D1A8 shlr r0
    c.r[0] &= 0x1u;  // 0603D1AA and #1,r0
    c.r[0] ^= 0x1u;  // 0603D1AC xor #1,r0
    c.r[0] += c.r[0];  // 0603D1AE add r0,r0
    c.r[1] &= c.r[3];  // 0603D1B0 and r3,r1
    c.r[1] |= c.r[0];  // 0603D1B2 or r0,r1
    st8(c.r[4], c.r[1]);  // 0603D1B4 mov.b r1,@r4
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603D1B6 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[2]; c.pc = x; return; }  // 0603D1B8 rts ; mov r2,r0
}

void f_0603D1C0(SH2Context& c) {
    ran[949] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603D1C0 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0603D1C2 mov r15,r14
    c.r[2] = c.r[5];  // 0603D1C4 mov r5,r2
    c.r[4] += 2;  // 0603D1C6 add #2,r4
    c.r[3] = (uint32_t)(int16_t)ld16(0x0603D1E0u);  // 0603D1C8 mov.w 0x0603D1E0,r3
    c.r[2] += 1;  // 0603D1CA add #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]);  // 0603D1CC mov.b @r4,r1
    c.r[0] = c.r[1];  // 0603D1CE mov r1,r0
    c.r[0] &= 0x1u;  // 0603D1D0 and #1,r0
    c.r[0] ^= 0x1u;  // 0603D1D2 xor #1,r0
    c.r[1] &= c.r[3];  // 0603D1D4 and r3,r1
    c.r[1] |= c.r[0];  // 0603D1D6 or r0,r1
    st8(c.r[4], c.r[1]);  // 0603D1D8 mov.b r1,@r4
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603D1DA mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[2]; c.pc = x; return; }  // 0603D1DC rts ; mov r2,r0
}

void f_0603D1E4(SH2Context& c) {
    ran[950] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603D1E4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603D1E6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0603D1E8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0603D1EA mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0603D1EC mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0603D1EE mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603D1F0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603D1F2 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0603D1F4 mov r15,r14
    c.r[11] = c.r[5];  // 0603D1F6 mov r5,r11
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]);  // 0603D1F8 mov.b @r4,r1
    c.r[8] = 0x0u;  // 0603D1FA mov #0,r8
    c.r[12] = c.r[1] & 0xFFu;  // 0603D1FC extu.b r1,r12
    c.r[1] = ld32(0x0603D24Cu);  // 0603D1FE mov.l 0x0603D24C,r1
    c.r[1] = ld32(c.r[1]);  // 0603D200 mov.l @r1,r1
    c.r[13] = ld32(0x0603D250u);  // 0603D202 mov.l 0x0603D250,r13
    c.r[10] = c.r[1];  // 0603D204 mov r1,r10
    c.r[10] += 65;  // 0603D206 add #65,r10
    c.r[9] = c.r[1];  // 0603D208 mov r1,r9
    c.r[9] += 1;  // 0603D20A add #1,r9
L_0603D20C:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0603D20C mov.b @r9,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603D248u);  // 0603D20E mov.w 0x0603D248,r1
    c.r[0] &= 0x90u;  // 0603D210 and #144,r0
    c.t = c.r[0] == c.r[1];  // 0603D212 cmp/eq r1,r0
    { const bool k = !c.t; c.r[9] += 76; if (k) { goto L_0603D226; } }  // 0603D214 bf/s 0x0603D226 ; add #76,r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0603D218 mov.b @r10,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0603D21A extu.b r1,r1
    c.t = c.r[1] == c.r[12];  // 0603D21C cmp/eq r12,r1
    { const bool k = !c.t; c.r[4] = c.r[8] & 0xFFFFu; if (k) { goto L_0603D226; } }  // 0603D21E bf/s 0x0603D226 ; extu.w r8,r4
    { const uint32_t x = c.r[13]; c.pr = 0x0603D226u; c.r[5] = c.r[4]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603D226u) return; }  // 0603D222 jsr @r13 ; mov r4,r5
L_0603D226:
    c.r[8] += 1;  // 0603D226 add #1,r8
    c.r[1] = 0x7Fu;  // 0603D228 mov #127,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 0603D22A cmp/gt r1,r8
    { const bool k = !c.t; c.r[10] += 76; if (k) { SH2_POLL(c); goto L_0603D20C; } }  // 0603D22C bf/s 0x0603D20C ; add #76,r10
    c.r[15] = c.r[14];  // 0603D230 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603D232 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603D234 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0603D236 mov.l @r15+,r13
    c.r[11] += 1;  // 0603D238 add #1,r11
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0603D23A mov.l @r15+,r12
    c.r[0] = c.r[11];  // 0603D23C mov r11,r0
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0603D23E mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0603D240 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0603D242 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603D244 rts ; mov.l @r15+,r8
}

void f_0603D254(SH2Context& c) {
    ran[951] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603D254 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0603D256 mov r15,r14
    c.r[0] = c.r[5];  // 0603D258 mov r5,r0
    c.r[3] = c.r[0];  // 0603D25A mov r0,r3
    c.r[3] += 1;  // 0603D25C add #1,r3
    st32(c.r[4] + 40, c.r[3]);  // 0603D25E mov.l r3,@(40,r4)
    c.r[1] = c.r[0];  // 0603D260 mov r0,r1
    c.r[1] += 2;  // 0603D262 add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0603D264 mov.b @r3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603D266 mov.b @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0603D268 extu.b r2,r2
    c.r[2] <<= 8;  // 0603D26A shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603D26C extu.b r1,r1
    c.r[2] |= c.r[1];  // 0603D26E or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0603D270 exts.w r2,r2
    c.r[3] += c.r[2];  // 0603D272 add r2,r3
    st32(c.r[4] + 40, c.r[3]);  // 0603D274 mov.l r3,@(40,r4)
    c.r[2] = c.r[4];  // 0603D276 mov r4,r2
    c.r[2] += 70;  // 0603D278 add #70,r2
    c.r[1] = c.r[0];  // 0603D27A mov r0,r1
    c.r[1] += 3;  // 0603D27C add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603D27E mov.b @r1,r1
    c.r[4] += 69;  // 0603D280 add #69,r4
    st8(c.r[2], c.r[1]);  // 0603D282 mov.b r1,@r2
    c.r[1] = 0x0u;  // 0603D284 mov #0,r1
    st8(c.r[4], c.r[1]);  // 0603D286 mov.b r1,@r4
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603D288 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] += 4; c.pc = x; return; }  // 0603D28A rts ; add #4,r0
}

void f_0603D290(SH2Context& c) {
    ran[952] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603D290 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0603D292 mov r15,r14
    c.r[0] = c.r[5];  // 0603D294 mov r5,r0
    c.r[7] = c.r[4];  // 0603D296 mov r4,r7
    c.r[1] = c.r[4];  // 0603D298 mov r4,r1
    c.r[4] += 67;  // 0603D29A add #67,r4
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[4]);  // 0603D29C mov.b @r4,r4
    c.r[1] += 68;  // 0603D29E add #68,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603D2A0 mov.b @r1,r3
    c.r[2] = c.r[4] & 0xFFu;  // 0603D2A2 extu.b r4,r2
    c.r[1] = c.r[3] & 0xFFu;  // 0603D2A4 extu.b r3,r1
    c.t = c.r[2] >= c.r[1];  // 0603D2A6 cmp/hs r1,r2
    { const bool k = c.t; c.r[7] += 60; if (k) { goto L_0603D2AE; } }  // 0603D2A8 bt/s 0x0603D2AE ; add #60,r7
    c.r[4] = c.r[3];  // 0603D2AC mov r3,r4
L_0603D2AE:
    c.r[1] = c.r[4] & 0xFFu;  // 0603D2AE extu.b r4,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603D2B0 tst r1,r1
    { const bool k = !c.t; st8(c.r[7], c.r[4]); if (k) { goto L_0603D2BA; } }  // 0603D2B2 bf/s 0x0603D2BA ; mov.b r4,@r7
    c.r[1] = 0x1u;  // 0603D2B6 mov #1,r1
    st8(c.r[7], c.r[1]);  // 0603D2B8 mov.b r1,@r7
L_0603D2BA:
    c.r[2] = ld32(0x0603D2C8u);  // 0603D2BA mov.l 0x0603D2C8,r2
    c.r[1] = 0x1u;  // 0603D2BC mov #1,r1
    st8(c.r[2], c.r[1]);  // 0603D2BE mov.b r1,@r2
    c.r[15] = c.r[14];  // 0603D2C0 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603D2C2 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] += 1; c.pc = x; return; }  // 0603D2C4 rts ; add #1,r0
}

void f_0603D2CC(SH2Context& c) {
    ran[953] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603D2CC mov.l r14,@-r15
    c.r[3] = c.r[5];  // 0603D2CE mov r5,r3
    c.r[1] = c.r[3];  // 0603D2D0 mov r3,r1
    c.r[1] += 1;  // 0603D2D2 add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603D2D4 mov.b @r1,r2
    c.r[14] = c.r[15];  // 0603D2D6 mov r15,r14
    c.r[2] = c.r[2] & 0xFFu;  // 0603D2D8 extu.b r2,r2
    c.r[1] = c.r[3];  // 0603D2DA mov r3,r1
    c.r[1] += 2;  // 0603D2DC add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603D2DE mov.b @r1,r1
    c.r[2] <<= 8;  // 0603D2E0 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603D2E2 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0603D2E4 or r1,r2
    c.r[7] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0603D2E6 exts.w r2,r7
    c.r[2] = c.r[4];  // 0603D2E8 mov r4,r2
    c.r[2] += 67;  // 0603D2EA add #67,r2
    c.r[1] = 0x0u;  // 0603D2EC mov #0,r1
    st8(c.r[2], c.r[1]);  // 0603D2EE mov.b r1,@r2
    c.r[1] = c.r[4];  // 0603D2F0 mov r4,r1
    c.r[1] += 1;  // 0603D2F2 add #1,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603D2F4 mov.b @r1,r0
    c.r[0] &= 0xFDu;  // 0603D2F6 and #253,r0
    st8(c.r[1], c.r[0]);  // 0603D2F8 mov.b r0,@r1
    c.r[0] >>= 2;  // 0603D2FA shlr2 r0
    c.r[0] &= 0x1u;  // 0603D2FC and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603D2FE tst r0,r0
    { const bool k = c.t; c.r[6] = c.r[7]; if (k) { goto L_0603D30C; } }  // 0603D300 bt/s 0x0603D30C ; mov r7,r6
    c.r[4] += 16;  // 0603D304 add #16,r4
    c.r[1] = 0u - c.r[7];  // 0603D306 neg r7,r1
    st16(c.r[4], c.r[1]); goto L_0603D310;  // 0603D308 bra 0x0603D310 ; mov.w r1,@r4
L_0603D30C:
    c.r[4] += 16;  // 0603D30C add #16,r4
    st16(c.r[4], c.r[6]);  // 0603D30E mov.w r6,@r4
L_0603D310:
    c.r[3] += 3;  // 0603D310 add #3,r3
    c.r[15] = c.r[14];  // 0603D312 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603D314 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[3]; c.pc = x; return; }  // 0603D316 rts ; mov r3,r0
}

void f_0603D31C(SH2Context& c) {
    ran[954] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603D31C mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0603D31E mov r15,r14
    c.r[7] = c.r[5];  // 0603D320 mov r5,r7
    c.r[1] = c.r[7];  // 0603D322 mov r7,r1
    c.r[1] += 1;  // 0603D324 add #1,r1
    c.r[2] = c.r[4];  // 0603D326 mov r4,r2
    c.r[2] += 68;  // 0603D328 add #68,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603D32A mov.b @r1,r3
    c.r[3] = c.r[3] & 0xFFu;  // 0603D32C extu.b r3,r3
    c.r[3] <<= 8;  // 0603D32E shll8 r3
    c.r[1] = c.r[7];  // 0603D330 mov r7,r1
    c.r[1] += 2;  // 0603D332 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603D334 mov.b @r1,r1
    c.r[7] += 3;  // 0603D336 add #3,r7
    c.r[1] = c.r[1] & 0xFFu;  // 0603D338 extu.b r1,r1
    c.r[3] |= c.r[1];  // 0603D33A or r1,r3
    c.r[1] = 0x0u;  // 0603D33C mov #0,r1
    st8(c.r[2], c.r[1]);  // 0603D33E mov.b r1,@r2
    c.r[1] = c.r[4];  // 0603D340 mov r4,r1
    c.r[1] += 1;  // 0603D342 add #1,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603D344 mov.b @r1,r0
    c.r[4] += 18;  // 0603D346 add #18,r4
    c.r[0] &= 0xFDu;  // 0603D348 and #253,r0
    st8(c.r[1], c.r[0]);  // 0603D34A mov.b r0,@r1
    st16(c.r[4], c.r[3]);  // 0603D34C mov.w r3,@r4
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603D34E mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[7]; c.pc = x; return; }  // 0603D350 rts ; mov r7,r0
}

void f_0603D354(SH2Context& c) {
    ran[955] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603D354 mov.l r14,@-r15
    c.r[3] = c.r[5];  // 0603D356 mov r5,r3
    c.r[1] = c.r[3];  // 0603D358 mov r3,r1
    c.r[1] += 1;  // 0603D35A add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603D35C mov.b @r1,r2
    c.r[14] = c.r[15];  // 0603D35E mov r15,r14
    c.r[2] = c.r[2] & 0xFFu;  // 0603D360 extu.b r2,r2
    c.r[1] = c.r[3];  // 0603D362 mov r3,r1
    c.r[1] += 2;  // 0603D364 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603D366 mov.b @r1,r1
    c.r[2] <<= 8;  // 0603D368 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603D36A extu.b r1,r1
    c.r[2] |= c.r[1];  // 0603D36C or r1,r2
    c.r[7] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0603D36E exts.w r2,r7
    c.r[2] = c.r[4];  // 0603D370 mov r4,r2
    c.r[2] += 67;  // 0603D372 add #67,r2
    c.r[1] = 0x0u;  // 0603D374 mov #0,r1
    st8(c.r[2], c.r[1]);  // 0603D376 mov.b r1,@r2
    c.r[1] = c.r[4];  // 0603D378 mov r4,r1
    c.r[1] += 1;  // 0603D37A add #1,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603D37C mov.b @r1,r0
    c.r[0] &= 0xFDu;  // 0603D37E and #253,r0
    st8(c.r[1], c.r[0]);  // 0603D380 mov.b r0,@r1
    c.r[0] >>= 2;  // 0603D382 shlr2 r0
    c.r[0] &= 0x1u;  // 0603D384 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603D386 tst r0,r0
    { const bool k = c.t; c.r[6] = c.r[7]; if (k) { goto L_0603D398; } }  // 0603D388 bt/s 0x0603D398 ; mov r7,r6
    c.r[2] = c.r[4];  // 0603D38C mov r4,r2
    c.r[2] += 16;  // 0603D38E add #16,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0603D390 mov.w @r2,r1
    c.r[1] -= c.r[7];  // 0603D392 sub r7,r1
    st16(c.r[2], c.r[1]); goto L_0603D3A2;  // 0603D394 bra 0x0603D3A2 ; mov.w r1,@r2
L_0603D398:
    c.r[2] = c.r[4];  // 0603D398 mov r4,r2
    c.r[2] += 16;  // 0603D39A add #16,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0603D39C mov.w @r2,r1
    c.r[6] += c.r[1];  // 0603D39E add r1,r6
    st16(c.r[2], c.r[6]);  // 0603D3A0 mov.w r6,@r2
L_0603D3A2:
    c.r[3] += 3;  // 0603D3A2 add #3,r3
    c.r[15] = c.r[14];  // 0603D3A4 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603D3A6 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[3]; c.pc = x; return; }  // 0603D3A8 rts ; mov r3,r0
}

void f_0603D3AC(SH2Context& c) {
    ran[956] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603D3AC mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0603D3AE mov r15,r14
    c.r[7] = c.r[5];  // 0603D3B0 mov r5,r7
    c.r[1] = c.r[7];  // 0603D3B2 mov r7,r1
    c.r[1] += 1;  // 0603D3B4 add #1,r1
    c.r[3] = c.r[4];  // 0603D3B6 mov r4,r3
    c.r[3] += 68;  // 0603D3B8 add #68,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603D3BA mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0603D3BC extu.b r2,r2
    c.r[2] <<= 8;  // 0603D3BE shll8 r2
    c.r[1] = c.r[7];  // 0603D3C0 mov r7,r1
    c.r[1] += 2;  // 0603D3C2 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603D3C4 mov.b @r1,r1
    c.r[7] += 3;  // 0603D3C6 add #3,r7
    c.r[1] = c.r[1] & 0xFFu;  // 0603D3C8 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0603D3CA or r1,r2
    c.r[1] = 0x0u;  // 0603D3CC mov #0,r1
    st8(c.r[3], c.r[1]);  // 0603D3CE mov.b r1,@r3
    c.r[1] = c.r[4];  // 0603D3D0 mov r4,r1
    c.r[1] += 1;  // 0603D3D2 add #1,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603D3D4 mov.b @r1,r0
    c.r[4] += 18;  // 0603D3D6 add #18,r4
    c.r[0] &= 0xFDu;  // 0603D3D8 and #253,r0
    st8(c.r[1], c.r[0]);  // 0603D3DA mov.b r0,@r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[4]);  // 0603D3DC mov.w @r4,r1
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0603D3DE exts.w r2,r2
    c.r[2] += c.r[1];  // 0603D3E0 add r1,r2
    st16(c.r[4], c.r[2]);  // 0603D3E2 mov.w r2,@r4
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603D3E4 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[7]; c.pc = x; return; }  // 0603D3E6 rts ; mov r7,r0
}

void f_0603D3EC(SH2Context& c) {
    ran[957] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603D3EC mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0603D3EE mov r15,r14
    c.r[0] = c.r[5];  // 0603D3F0 mov r5,r0
    c.r[4] += 63;  // 0603D3F2 add #63,r4
    c.r[2] = 0x3u;  // 0603D3F4 mov #3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]); c.r[0] += 1;  // 0603D3F6 mov.b @r0+,r1
    c.r[1] &= c.r[2];  // 0603D3F8 and r2,r1
    st8(c.r[4], c.r[1]);  // 0603D3FA mov.b r1,@r4
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603D3FC rts ; mov.l @r15+,r14
}

void f_0603D400(SH2Context& c) {
    ran[958] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603D400 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0603D402 mov r15,r14
    c.r[0] = c.r[5];  // 0603D404 mov r5,r0
    c.r[4] += 62;  // 0603D406 add #62,r4
    c.r[2] = 0x3u;  // 0603D408 mov #3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]); c.r[0] += 1;  // 0603D40A mov.b @r0+,r1
    c.r[1] &= c.r[2];  // 0603D40C and r2,r1
    st8(c.r[4], c.r[1]);  // 0603D40E mov.b r1,@r4
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603D410 rts ; mov.l @r15+,r14
}

void f_0603D414(SH2Context& c) {
    ran[959] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603D414 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0603D416 mov r15,r14
    c.r[0] = c.r[5];  // 0603D418 mov r5,r0
    c.r[1] = c.r[0];  // 0603D41A mov r0,r1
    c.r[1] += 1;  // 0603D41C add #1,r1
    c.r[4] += 72;  // 0603D41E add #72,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603D420 mov.b @r1,r1
    c.r[3] = 0x70u;  // 0603D422 mov #112,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0603D424 extu.b r1,r1
    c.r[2] = c.r[1];  // 0603D426 mov r1,r2
    c.r[2] <<= 8;  // 0603D428 shll8 r2
    c.r[1] = c.r[0];  // 0603D42A mov r0,r1
    c.r[1] += 2;  // 0603D42C add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603D42E mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0603D430 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0603D432 or r1,r2
    c.r[1] = 0x6u;  // 0603D434 mov #6,r1
    c.r[1] &= c.r[2];  // 0603D436 and r2,r1
    c.r[1] <<= 2;  // 0603D438 shll2 r1
    c.r[1] <<= 2;  // 0603D43A shll2 r1
    c.r[1] += c.r[1];  // 0603D43C add r1,r1
    c.r[1] <<= 2;  // 0603D43E shll2 r1
    c.r[2] >>= 2;  // 0603D440 shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 0603D442 shlr r2
    c.r[2] >>= 2;  // 0603D444 shlr2 r2
    c.r[2] &= c.r[3];  // 0603D446 and r3,r2
    c.r[1] += c.r[2];  // 0603D448 add r2,r1
    st16(c.r[4], c.r[1]);  // 0603D44A mov.w r1,@r4
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603D44C mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] += 3; c.pc = x; return; }  // 0603D44E rts ; add #3,r0
}

void f_0603D454(SH2Context& c) {
    ran[960] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603D454 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603D456 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0603D458 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0603D45A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0603D45C mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0603D45E mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603D460 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603D462 sts.l pr,@-r15
    c.r[15] -= 4;  // 0603D464 add #-4,r15
    c.r[14] = c.r[15];  // 0603D466 mov r15,r14
    c.r[13] = c.r[5];  // 0603D468 mov r5,r13
    c.r[1] = c.r[13];  // 0603D46A mov r13,r1
    c.r[1] += 1;  // 0603D46C add #1,r1
    c.r[0] = ld32(0x0603D4DCu);  // 0603D46E mov.l 0x0603D4DC,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603D470 mov.b @r1,r2
    c.r[4] = c.r[14];  // 0603D472 mov r14,r4
    c.r[2] = c.r[2] & 0xFFu;  // 0603D474 extu.b r2,r2
    c.r[1] = c.r[13];  // 0603D476 mov r13,r1
    c.r[1] += 2;  // 0603D478 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603D47A mov.b @r1,r1
    c.r[2] <<= 8;  // 0603D47C shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603D47E extu.b r1,r1
    c.r[2] |= c.r[1];  // 0603D480 or r1,r2
    { const uint32_t x = c.r[0]; c.pr = 0x0603D486u; st16(c.r[14], c.r[2]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603D486u) return; }  // 0603D482 jsr @r0 ; mov.w r2,@r14
    c.r[12] = c.r[0] & 0xFFFFu;  // 0603D486 extu.w r0,r12
    c.r[11] = 0x3u;  // 0603D488 mov #3,r11
    c.r[10] = 0x40u;  // 0603D48A mov #64,r10
    c.r[9] = 0x0u;  // 0603D48C mov #0,r9
L_0603D48E:
    c.r[8] = c.r[10];  // 0603D48E mov r10,r8
L_0603D490:
    c.r[7] = (uint32_t)(int16_t)ld16(c.r[14]);  // 0603D490 mov.w @r14,r7
    c.r[4] = c.r[8] & 0xFFFFu;  // 0603D492 extu.w r8,r4
    c.r[6] = 0xFFFFFFFFu;  // 0603D494 mov #-1,r6
    c.r[5] = 0x10u;  // 0603D496 mov #16,r5
    c.r[3] = ld32(0x0603D4E0u);  // 0603D498 mov.l 0x0603D4E0,r3
    c.r[7] <<= 2;  // 0603D49A shll2 r7
    c.r[7] <<= 2;  // 0603D49C shll2 r7
    c.r[7] += c.r[12];  // 0603D49E add r12,r7
    { const uint32_t x = c.r[3]; c.pr = 0x0603D4A4u; c.r[7] = c.r[7] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603D4A4u) return; }  // 0603D4A0 jsr @r3 ; extu.w r7,r7
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603D4D8u);  // 0603D4A4 mov.w 0x0603D4D8,r1
    c.r[9] += 1;  // 0603D4A6 add #1,r9
    c.t = (int32_t)c.r[9] > (int32_t)c.r[11];  // 0603D4A8 cmp/gt r11,r9
    { const bool k = !c.t; c.r[8] += c.r[1]; if (k) { SH2_POLL(c); goto L_0603D490; } }  // 0603D4AA bf/s 0x0603D490 ; add r1,r8
    c.r[10] += 16;  // 0603D4AE add #16,r10
    c.r[1] = c.r[11];  // 0603D4B0 mov r11,r1
    c.r[1] <<= 2;  // 0603D4B2 shll2 r1
    c.r[1] <<= 2;  // 0603D4B4 shll2 r1
    c.r[1] += 64;  // 0603D4B6 add #64,r1
    c.t = (int32_t)c.r[10] > (int32_t)c.r[1];  // 0603D4B8 cmp/gt r1,r10
    { const bool k = !c.t; c.r[9] = 0x0u; if (k) { SH2_POLL(c); goto L_0603D48E; } }  // 0603D4BA bf/s 0x0603D48E ; mov #0,r9
    c.r[14] += 4;  // 0603D4BE add #4,r14
    c.r[15] = c.r[14];  // 0603D4C0 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603D4C2 lds.l @r15+,pr
    c.r[13] += 3;  // 0603D4C4 add #3,r13
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603D4C6 mov.l @r15+,r14
    c.r[0] = c.r[13];  // 0603D4C8 mov r13,r0
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0603D4CA mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0603D4CC mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0603D4CE mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0603D4D0 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0603D4D2 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603D4D4 rts ; mov.l @r15+,r8
}

void f_0603D4E4(SH2Context& c) {
    ran[961] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603D4E4 mov.l r14,@-r15
    c.r[0] = c.r[5];  // 0603D4E6 mov r5,r0
    c.r[1] = c.r[0];  // 0603D4E8 mov r0,r1
    c.r[1] += 1;  // 0603D4EA add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603D4EC mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0603D4EE extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603D4F0 tst r1,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0603D522; } }  // 0603D4F2 bt/s 0x0603D522 ; mov r15,r14
    c.r[1] = c.r[0];  // 0603D4F6 mov r0,r1
    c.r[1] += 2;  // 0603D4F8 add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603D4FA mov.b @r1,r2
    c.r[7] = ld32(0x0603D54Cu);  // 0603D4FC mov.l 0x0603D54C,r7
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[7]);  // 0603D4FE mov.w @r7,r1
    c.r[1] += c.r[2];  // 0603D500 add r2,r1
    st16(c.r[7], c.r[1]);  // 0603D502 mov.w r1,@r7
    c.r[2] = c.r[1];  // 0603D504 mov r1,r2
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0603D506 exts.w r2,r1
    c.t = (int32_t)c.r[1] >= 0;  // 0603D508 cmp/pz r1
    if (c.t) { goto L_0603D50E; }  // 0603D50A bt 0x0603D50E
    c.r[2] = 0x0u;  // 0603D50C mov #0,r2
L_0603D50E:
    st16(c.r[7], c.r[2]);  // 0603D50E mov.w r2,@r7
    c.r[3] = c.r[2];  // 0603D510 mov r2,r3
    c.r[6] = (uint32_t)(int16_t)ld16(0x0603D548u);  // 0603D512 mov.w 0x0603D548,r6
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[3];  // 0603D514 exts.w r3,r2
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[6];  // 0603D516 exts.w r6,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0603D518 cmp/gt r1,r2
    if (!c.t) { goto L_0603D51E; }  // 0603D51A bf 0x0603D51E
    c.r[3] = c.r[6];  // 0603D51C mov r6,r3
L_0603D51E:
    st16(c.r[7], c.r[3]); goto L_0603D540;  // 0603D51E bra 0x0603D540 ; mov.w r3,@r7
L_0603D522:
    c.r[1] = c.r[0];  // 0603D522 mov r0,r1
    c.r[1] += 2;  // 0603D524 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603D526 mov.b @r1,r1
    c.r[6] = ld32(0x0603D54Cu);  // 0603D528 mov.l 0x0603D54C,r6
    c.r[1] = c.r[1] & 0xFFu;  // 0603D52A extu.b r1,r1
    st16(c.r[6], c.r[1]);  // 0603D52C mov.w r1,@r6
    st16(c.r[6], c.r[1]);  // 0603D52E mov.w r1,@r6
    c.r[3] = c.r[1];  // 0603D530 mov r1,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x0603D548u);  // 0603D532 mov.w 0x0603D548,r7
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[3];  // 0603D534 exts.w r3,r2
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[7];  // 0603D536 exts.w r7,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0603D538 cmp/gt r1,r2
    if (!c.t) { goto L_0603D53E; }  // 0603D53A bf 0x0603D53E
    c.r[3] = c.r[7];  // 0603D53C mov r7,r3
L_0603D53E:
    st16(c.r[6], c.r[3]);  // 0603D53E mov.w r3,@r6
L_0603D540:
    c.r[15] = c.r[14];  // 0603D540 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603D542 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] += 3; c.pc = x; return; }  // 0603D544 rts ; add #3,r0
}

void f_0603D550(SH2Context& c) {
    ran[962] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603D550 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0603D552 mov r15,r14
    c.r[0] = c.r[5];  // 0603D554 mov r5,r0
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603D556 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] += 2; c.pc = x; return; }  // 0603D558 rts ; add #2,r0
}

void f_0603D55C(SH2Context& c) {
    ran[963] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603D55C mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0603D55E mov r15,r14
    c.r[0] = c.r[5];  // 0603D560 mov r5,r0
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603D562 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] += 2; c.pc = x; return; }  // 0603D564 rts ; add #2,r0
}

void f_0603D568(SH2Context& c) {
    ran[964] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603D568 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0603D56A mov r15,r14
    c.r[0] = c.r[5];  // 0603D56C mov r5,r0
    c.r[2] = ld32(0x0603D57Cu);  // 0603D56E mov.l 0x0603D57C,r2
    c.r[1] = 0x1u;  // 0603D570 mov #1,r1
    st16(c.r[2], c.r[1]);  // 0603D572 mov.w r1,@r2
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603D574 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] += 1; c.pc = x; return; }  // 0603D576 rts ; add #1,r0
}

void f_0603D580(SH2Context& c) {
    ran[965] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603D580 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603D582 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0603D584 mov r15,r14
    c.r[1] = c.r[4];  // 0603D586 mov r4,r1
    c.r[3] = ld32(c.r[4] + 4);  // 0603D588 mov.l @(4,r4),r3
    c.r[1] += 1;  // 0603D58A add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603D58C mov.b @r1,r1
    c.r[2] = c.r[4];  // 0603D58E mov r4,r2
    c.r[0] = c.r[1];  // 0603D590 mov r1,r0
    c.r[0] >>= 2;  // 0603D592 shlr2 r0
    c.r[0] >>= 2;  // 0603D594 shlr2 r0
    c.r[0] &= 0x1u;  // 0603D596 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603D598 tst r0,r0
    { const bool k = c.t; c.r[7] = ld32(c.r[4] + 8); if (k) { goto L_0603D5CE; } }  // 0603D59A bt/s 0x0603D5CE ; mov.l @(8,r4),r7
    c.r[1] = ld32(0x0603D600u);  // 0603D59E mov.l 0x0603D600,r1
    c.r[8] = 0x4Cu;  // 0603D5A0 mov #76,r8
    c.r[6] = ld32(c.r[1]);  // 0603D5A2 mov.l @r1,r6
    c.r[2] += 65;  // 0603D5A4 add #65,r2
L_0603D5A6:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0603D5A6 mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0603D5A8 extu.b r1,r1
    c.macl = c.r[1] * c.r[8];  // 0603D5AA mul.l r8,r1
    c.r[2] = c.macl;  // 0603D5AC sts macl,r2
    c.r[2] += c.r[6];  // 0603D5AE add r6,r2
    c.r[1] = ld32(c.r[2] + 4);  // 0603D5B0 mov.l @(4,r2),r1
    c.r[3] += c.r[1];  // 0603D5B2 add r1,r3
    c.r[1] = ld32(c.r[2] + 8);  // 0603D5B4 mov.l @(8,r2),r1
    c.r[7] += c.r[1];  // 0603D5B6 add r1,r7
    c.r[1] = c.r[2];  // 0603D5B8 mov r2,r1
    c.r[1] += 1;  // 0603D5BA add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603D5BC mov.b @r1,r1
    c.r[0] = c.r[1];  // 0603D5BE mov r1,r0
    c.r[0] >>= 2;  // 0603D5C0 shlr2 r0
    c.r[0] >>= 2;  // 0603D5C2 shlr2 r0
    c.r[0] &= 0x1u;  // 0603D5C4 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603D5C6 tst r0,r0
    { const bool k = !c.t; c.r[2] += 65; if (k) { SH2_POLL(c); goto L_0603D5A6; } }  // 0603D5C8 bf/s 0x0603D5A6 ; add #65,r2
    c.r[2] -= 65;  // 0603D5CC add #-65,r2
L_0603D5CE:
    st32(c.r[4] + 4, c.r[3]);  // 0603D5CE mov.l r3,@(4,r4)
    st32(c.r[4] + 8, c.r[7]);  // 0603D5D0 mov.l r7,@(8,r4)
    c.r[2] += 1;  // 0603D5D2 add #1,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0603D5D4 mov.b @r2,r0
    c.r[1] = 0x20u;  // 0603D5D6 mov #32,r1
    c.r[2] = c.r[4];  // 0603D5D8 mov r4,r2
    c.r[2] += 1;  // 0603D5DA add #1,r2
    c.r[1] &= c.r[0];  // 0603D5DC and r0,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0603D5DE mov.b @r2,r0
    c.r[4] += 65;  // 0603D5E0 add #65,r4
    c.r[0] &= 0xDFu;  // 0603D5E2 and #223,r0
    c.r[0] |= c.r[1];  // 0603D5E4 or r1,r0
    st8(c.r[2], c.r[0]);  // 0603D5E6 mov.b r0,@r2
    c.r[1] = 0x0u;  // 0603D5E8 mov #0,r1
    st8(c.r[4], c.r[1]);  // 0603D5EA mov.b r1,@r4
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0603D5EC mov.b @r2,r0
    c.r[15] = c.r[14];  // 0603D5EE mov r14,r15
    c.r[0] &= 0xEFu;  // 0603D5F0 and #239,r0
    st8(c.r[2], c.r[0]);  // 0603D5F2 mov.b r0,@r2
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603D5F4 mov.l @r15+,r14
    c.r[5] += 1;  // 0603D5F6 add #1,r5
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0603D5F8 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.r[0] = c.r[5]; c.pc = x; return; }  // 0603D5FA rts ; mov r5,r0
}

void f_0603D604(SH2Context& c) {
    ran[966] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603D604 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0603D606 mov r15,r14
    c.r[2] = c.r[4];  // 0603D608 mov r4,r2
    c.r[2] += 1;  // 0603D60A add #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0603D60C mov.b @r2,r1
    c.r[0] = c.r[1];  // 0603D60E mov r1,r0
    c.r[0] >>= 2;  // 0603D610 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0603D612 shlr r0
    c.r[0] >>= 2;  // 0603D614 shlr2 r0
    c.r[0] &= 0x1u;  // 0603D616 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603D618 tst r0,r0
    { const bool k = c.t; c.r[3] = c.r[5]; if (k) { goto L_0603D638; } }  // 0603D61A bt/s 0x0603D638 ; mov r5,r3
    c.r[0] = c.r[1];  // 0603D61E mov r1,r0
    c.r[0] &= 0xDFu;  // 0603D620 and #223,r0
    st8(c.r[2], c.r[0]);  // 0603D622 mov.b r0,@r2
    c.r[2] = ld32(c.r[4] + 4);  // 0603D624 mov.l @(4,r4),r2
    c.r[1] = ld32(0x0603D644u);  // 0603D626 mov.l 0x0603D644,r1
    c.r[1] = ld32(c.r[1]);  // 0603D628 mov.l @r1,r1
    c.r[2] -= c.r[1];  // 0603D62A sub r1,r2
    st32(c.r[4] + 4, c.r[2]);  // 0603D62C mov.l r2,@(4,r4)
    c.r[2] = ld32(c.r[4] + 8);  // 0603D62E mov.l @(8,r4),r2
    c.r[1] = ld32(0x0603D648u);  // 0603D630 mov.l 0x0603D648,r1
    c.r[1] = ld32(c.r[1]);  // 0603D632 mov.l @r1,r1
    c.r[2] -= c.r[1];  // 0603D634 sub r1,r2
    st32(c.r[4] + 8, c.r[2]);  // 0603D636 mov.l r2,@(8,r4)
L_0603D638:
    c.r[3] += 1;  // 0603D638 add #1,r3
    c.r[15] = c.r[14];  // 0603D63A mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603D63C mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[3]; c.pc = x; return; }  // 0603D63E rts ; mov r3,r0
}

void f_0603D64C(SH2Context& c) {
    ran[967] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603D64C mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0603D64E mov r15,r14
    c.r[2] = c.r[4];  // 0603D650 mov r4,r2
    c.r[2] += 1;  // 0603D652 add #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0603D654 mov.b @r2,r1
    c.r[0] = c.r[1];  // 0603D656 mov r1,r0
    c.r[0] >>= 2;  // 0603D658 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0603D65A shlr r0
    c.r[0] >>= 2;  // 0603D65C shlr2 r0
    c.r[0] &= 0x1u;  // 0603D65E and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0603D660 tst r0,r0
    { const bool k = !c.t; c.r[3] = c.r[5]; if (k) { goto L_0603D680; } }  // 0603D662 bf/s 0x0603D680 ; mov r5,r3
    c.r[0] = c.r[1];  // 0603D666 mov r1,r0
    c.r[0] |= 0x20u;  // 0603D668 or #32,r0
    st8(c.r[2], c.r[0]);  // 0603D66A mov.b r0,@r2
    c.r[2] = ld32(c.r[4] + 4);  // 0603D66C mov.l @(4,r4),r2
    c.r[1] = ld32(0x0603D68Cu);  // 0603D66E mov.l 0x0603D68C,r1
    c.r[1] = ld32(c.r[1]);  // 0603D670 mov.l @r1,r1
    c.r[2] += c.r[1];  // 0603D672 add r1,r2
    st32(c.r[4] + 4, c.r[2]);  // 0603D674 mov.l r2,@(4,r4)
    c.r[2] = ld32(c.r[4] + 8);  // 0603D676 mov.l @(8,r4),r2
    c.r[1] = ld32(0x0603D690u);  // 0603D678 mov.l 0x0603D690,r1
    c.r[1] = ld32(c.r[1]);  // 0603D67A mov.l @r1,r1
    c.r[2] += c.r[1];  // 0603D67C add r1,r2
    st32(c.r[4] + 8, c.r[2]);  // 0603D67E mov.l r2,@(8,r4)
L_0603D680:
    c.r[3] += 1;  // 0603D680 add #1,r3
    c.r[15] = c.r[14];  // 0603D682 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603D684 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[3]; c.pc = x; return; }  // 0603D686 rts ; mov r3,r0
}

void f_0603D694(SH2Context& c) {
    ran[968] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603D694 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603D696 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603D698 sts.l pr,@-r15
    c.r[8] = c.r[5];  // 0603D69A mov r5,r8
    c.r[1] = c.r[8];  // 0603D69C mov r8,r1
    c.r[1] += 1;  // 0603D69E add #1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603D6A0 mov.b @r1,r4
    c.r[14] = c.r[15];  // 0603D6A2 mov r15,r14
    c.r[1] = ld32(0x0603D6B8u);  // 0603D6A4 mov.l 0x0603D6B8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0603D6AAu; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603D6AAu) return; }  // 0603D6A6 jsr @r1 ; extu.b r4,r4
    c.r[15] = c.r[14];  // 0603D6AA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603D6AC lds.l @r15+,pr
    c.r[8] += 2;  // 0603D6AE add #2,r8
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603D6B0 mov.l @r15+,r14
    c.r[0] = c.r[8];  // 0603D6B2 mov r8,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603D6B4 rts ; mov.l @r15+,r8
}

void f_0603D6BC(SH2Context& c) {
    ran[969] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603D6BC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603D6BE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603D6C0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603D6C2 sts.l pr,@-r15
    c.r[9] = c.r[5];  // 0603D6C4 mov r5,r9
    c.r[1] = c.r[9];  // 0603D6C6 mov r9,r1
    c.r[1] += 1;  // 0603D6C8 add #1,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603D6CA mov.b @r1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603D712u);  // 0603D6CC mov.w 0x0603D712,r1
    c.r[1] &= c.r[0];  // 0603D6CE and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603D6D0 tst r1,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0603D6EC; } }  // 0603D6D2 bt/s 0x0603D6EC ; mov r15,r14
    c.r[8] = ld32(0x0603D714u);  // 0603D6D6 mov.l 0x0603D714,r8
    c.r[1] = 0x1Fu;  // 0603D6D8 mov #31,r1
    c.r[1] &= c.r[0];  // 0603D6DA and r0,r1
    c.r[0] = ld32(0x0603D718u);  // 0603D6DC mov.l 0x0603D718,r0
    c.r[5] = c.r[1];  // 0603D6DE mov r1,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0603D6E4u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603D6E4u) return; }  // 0603D6E0 jsr @r0 ; mov #1,r4
    c.r[1] = ld32(c.r[8]);  // 0603D6E4 mov.l @r8,r1
    c.r[1] |= c.r[0];  // 0603D6E6 or r0,r1
    st32(c.r[8], c.r[1]); goto L_0603D702;  // 0603D6E8 bra 0x0603D702 ; mov.l r1,@r8
L_0603D6EC:
    c.r[8] = ld32(0x0603D714u);  // 0603D6EC mov.l 0x0603D714,r8
    c.r[1] = 0x1Fu;  // 0603D6EE mov #31,r1
    c.r[1] &= c.r[0];  // 0603D6F0 and r0,r1
    c.r[0] = ld32(0x0603D718u);  // 0603D6F2 mov.l 0x0603D718,r0
    c.r[5] = c.r[1];  // 0603D6F4 mov r1,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0603D6FAu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603D6FAu) return; }  // 0603D6F6 jsr @r0 ; mov #1,r4
    c.r[2] = ld32(c.r[8]);  // 0603D6FA mov.l @r8,r2
    c.r[1] = ~c.r[0];  // 0603D6FC not r0,r1
    c.r[2] &= c.r[1];  // 0603D6FE and r1,r2
    st32(c.r[8], c.r[2]);  // 0603D700 mov.l r2,@r8
L_0603D702:
    c.r[15] = c.r[14];  // 0603D702 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603D704 lds.l @r15+,pr
    c.r[9] += 2;  // 0603D706 add #2,r9
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603D708 mov.l @r15+,r14
    c.r[0] = c.r[9];  // 0603D70A mov r9,r0
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0603D70C mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603D70E rts ; mov.l @r15+,r8
}

void f_0603D71C(SH2Context& c) {
    ran[970] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603D71C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603D71E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0603D720 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603D722 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603D724 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0603D726 mov r15,r14
    c.r[9] = c.r[5];  // 0603D728 mov r5,r9
    c.r[1] = c.r[9];  // 0603D72A mov r9,r1
    c.r[1] += 1;  // 0603D72C add #1,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603D72E mov.b @r1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603D790u);  // 0603D730 mov.w 0x0603D790,r1
    c.r[1] &= c.r[0];  // 0603D732 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603D734 tst r1,r1
    { const bool k = c.t; c.r[10] = c.r[4]; if (k) { goto L_0603D75C; } }  // 0603D736 bt/s 0x0603D75C ; mov r4,r10
    c.r[8] = ld32(0x0603D794u);  // 0603D73A mov.l 0x0603D794,r8
    c.r[1] = 0x1Fu;  // 0603D73C mov #31,r1
    c.r[1] &= c.r[0];  // 0603D73E and r0,r1
    c.r[0] = ld32(0x0603D798u);  // 0603D740 mov.l 0x0603D798,r0
    c.r[5] = c.r[1];  // 0603D742 mov r1,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0603D748u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603D748u) return; }  // 0603D744 jsr @r0 ; mov #1,r4
    c.r[1] = ld32(c.r[8]);  // 0603D748 mov.l @r8,r1
    c.r[1] &= c.r[0];  // 0603D74A and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603D74C tst r1,r1
    { const bool k = !c.t; c.r[10] += 60; if (k) { goto L_0603D77E; } }  // 0603D74E bf/s 0x0603D77E ; add #60,r10
    c.r[2] = 0x1u;  // 0603D752 mov #1,r2
    st8(c.r[10], c.r[2]);  // 0603D754 mov.b r2,@r10
    c.r[1] = ld32(0x0603D79Cu);  // 0603D756 mov.l 0x0603D79C,r1
    st8(c.r[1], c.r[2]); goto L_0603D780;  // 0603D758 bra 0x0603D780 ; mov.b r2,@r1
L_0603D75C:
    c.r[8] = ld32(0x0603D794u);  // 0603D75C mov.l 0x0603D794,r8
    c.r[1] = 0x7Fu;  // 0603D75E mov #127,r1
    c.r[1] &= c.r[0];  // 0603D760 and r0,r1
    c.r[0] = ld32(0x0603D798u);  // 0603D762 mov.l 0x0603D798,r0
    c.r[5] = c.r[1];  // 0603D764 mov r1,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0603D76Au; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603D76Au) return; }  // 0603D766 jsr @r0 ; mov #1,r4
    c.r[1] = ld32(c.r[8]);  // 0603D76A mov.l @r8,r1
    c.r[1] &= c.r[0];  // 0603D76C and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603D76E tst r1,r1
    { const bool k = c.t; c.r[10] += 60; if (k) { goto L_0603D77E; } }  // 0603D770 bt/s 0x0603D77E ; add #60,r10
    c.r[2] = 0x1u;  // 0603D774 mov #1,r2
    st8(c.r[10], c.r[2]);  // 0603D776 mov.b r2,@r10
    c.r[1] = ld32(0x0603D79Cu);  // 0603D778 mov.l 0x0603D79C,r1
    st8(c.r[1], c.r[2]); goto L_0603D780;  // 0603D77A bra 0x0603D780 ; mov.b r2,@r1
L_0603D77E:
    c.r[9] += 2;  // 0603D77E add #2,r9
L_0603D780:
    c.r[0] = c.r[9];  // 0603D780 mov r9,r0
    c.r[15] = c.r[14];  // 0603D782 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603D784 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603D786 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0603D788 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0603D78A mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603D78C rts ; mov.l @r15+,r8
}

void f_0603D7A0(SH2Context& c) {
    ran[971] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603D7A0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0603D7A2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603D7A4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603D7A6 sts.l pr,@-r15
    c.r[9] = c.r[5];  // 0603D7A8 mov r5,r9
    c.r[1] = c.r[9];  // 0603D7AA mov r9,r1
    c.r[1] += 1;  // 0603D7AC add #1,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603D7AE mov.b @r1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603D81Au);  // 0603D7B0 mov.w 0x0603D81A,r1
    c.r[1] &= c.r[0];  // 0603D7B2 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603D7B4 tst r1,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0603D7D6; } }  // 0603D7B6 bt/s 0x0603D7D6 ; mov r15,r14
    c.r[8] = ld32(0x0603D81Cu);  // 0603D7BA mov.l 0x0603D81C,r8
    c.r[1] = 0x1Fu;  // 0603D7BC mov #31,r1
    c.r[1] &= c.r[0];  // 0603D7BE and r0,r1
    c.r[0] = ld32(0x0603D820u);  // 0603D7C0 mov.l 0x0603D820,r0
    c.r[5] = c.r[1];  // 0603D7C2 mov r1,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0603D7C8u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603D7C8u) return; }  // 0603D7C4 jsr @r0 ; mov #1,r4
    c.r[1] = ld32(c.r[8]);  // 0603D7C8 mov.l @r8,r1
    c.r[1] &= c.r[0];  // 0603D7CA and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603D7CC tst r1,r1
    if (!c.t) { goto L_0603D7F2; }  // 0603D7CE bf 0x0603D7F2
    c.r[9] += 4;  // 0603D7D0 add #4,r9
    c.r[15] = c.r[14]; goto L_0603D80E;  // 0603D7D2 bra 0x0603D80E ; mov r14,r15
L_0603D7D6:
    c.r[8] = ld32(0x0603D81Cu);  // 0603D7D6 mov.l 0x0603D81C,r8
    c.r[1] = 0x1Fu;  // 0603D7D8 mov #31,r1
    c.r[1] &= c.r[0];  // 0603D7DA and r0,r1
    c.r[0] = ld32(0x0603D820u);  // 0603D7DC mov.l 0x0603D820,r0
    c.r[5] = c.r[1];  // 0603D7DE mov r1,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0603D7E4u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603D7E4u) return; }  // 0603D7E0 jsr @r0 ; mov #1,r4
    c.r[1] = ld32(c.r[8]);  // 0603D7E4 mov.l @r8,r1
    c.r[1] &= c.r[0];  // 0603D7E6 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603D7E8 tst r1,r1
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_0603D7F4; } }  // 0603D7EA bt/s 0x0603D7F4 ; mov r9,r1
    c.r[9] += 4; goto L_0603D80C;  // 0603D7EE bra 0x0603D80C ; add #4,r9
L_0603D7F2:
    c.r[1] = c.r[9];  // 0603D7F2 mov r9,r1
L_0603D7F4:
    c.r[1] += 2;  // 0603D7F4 add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603D7F6 mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0603D7F8 extu.b r2,r2
    c.r[1] = c.r[9];  // 0603D7FA mov r9,r1
    c.r[1] += 3;  // 0603D7FC add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603D7FE mov.b @r1,r1
    c.r[2] <<= 8;  // 0603D800 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603D802 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0603D804 or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0603D806 exts.w r2,r2
    c.r[2] += 2;  // 0603D808 add #2,r2
    c.r[9] += c.r[2];  // 0603D80A add r2,r9
L_0603D80C:
    c.r[15] = c.r[14];  // 0603D80C mov r14,r15
L_0603D80E:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603D80E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603D810 mov.l @r15+,r14
    c.r[0] = c.r[9];  // 0603D812 mov r9,r0
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0603D814 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603D816 rts ; mov.l @r15+,r8
}

void f_0603D824(SH2Context& c) {
    ran[972] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603D824 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0603D826 mov r15,r14
    c.r[7] = c.r[4];  // 0603D828 mov r4,r7
    c.r[7] += 66;  // 0603D82A add #66,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0603D82C mov.b @r7,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0603D82E extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603D830 tst r1,r1
    { const bool k = !c.t; c.r[0] = c.r[5]; if (k) { goto L_0603D846; } }  // 0603D832 bf/s 0x0603D846 ; mov r5,r0
    c.r[1] = c.r[0];  // 0603D836 mov r0,r1
    c.r[1] += 1;  // 0603D838 add #1,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603D83A mov.b @r1,r3
    c.r[2] = c.r[3] & 0xFFu;  // 0603D83C extu.b r3,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0603D87Au);  // 0603D83E mov.w 0x0603D87A,r1
    c.t = c.r[2] == c.r[1];  // 0603D840 cmp/eq r1,r2
    if (c.t) { goto L_0603D846; }  // 0603D842 bt 0x0603D846
    st8(c.r[7], c.r[3]);  // 0603D844 mov.b r3,@r7
L_0603D846:
    c.r[2] = c.r[4];  // 0603D846 mov r4,r2
    c.r[2] += 66;  // 0603D848 add #66,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0603D84A mov.b @r2,r1
    c.r[1] -= 1;  // 0603D84C add #-1,r1
    st8(c.r[2], c.r[1]);  // 0603D84E mov.b r1,@r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603D850 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0603D852 tst r1,r1
    { const bool k = c.t; c.r[1] = c.r[0]; if (k) { goto L_0603D872; } }  // 0603D854 bt/s 0x0603D872 ; mov r0,r1
    c.r[1] += 2;  // 0603D858 add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603D85A mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0603D85C extu.b r2,r2
    c.r[1] = c.r[0];  // 0603D85E mov r0,r1
    c.r[1] += 3;  // 0603D860 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603D862 mov.b @r1,r1
    c.r[2] <<= 8;  // 0603D864 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603D866 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0603D868 or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0603D86A exts.w r2,r2
    c.r[2] += 2;  // 0603D86C add #2,r2
    c.r[0] += c.r[2]; goto L_0603D874;  // 0603D86E bra 0x0603D874 ; add r2,r0
L_0603D872:
    c.r[0] += 4;  // 0603D872 add #4,r0
L_0603D874:
    c.r[15] = c.r[14];  // 0603D874 mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603D876 rts ; mov.l @r15+,r14
}

void f_0603D87C(SH2Context& c) {
    ran[973] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603D87C mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0603D87E mov r15,r14
    c.r[1] = c.r[5];  // 0603D880 mov r5,r1
    c.r[1] += 1;  // 0603D882 add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603D884 mov.b @r1,r2
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603D886 mov.l @r15+,r14
    c.r[2] = c.r[2] & 0xFFu;  // 0603D888 extu.b r2,r2
    c.r[1] = c.r[5];  // 0603D88A mov r5,r1
    c.r[1] += 2;  // 0603D88C add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603D88E mov.b @r1,r1
    c.r[2] <<= 8;  // 0603D890 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0603D892 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0603D894 or r1,r2
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0603D896 exts.w r2,r0
    c.r[0] += 1;  // 0603D898 add #1,r0
    { const uint32_t x = c.pr; c.r[0] += c.r[5]; c.pc = x; return; }  // 0603D89A rts ; add r5,r0
}

void f_0603D8A0(SH2Context& c) {
    ran[974] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0603D8A0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603D8A2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603D8A4 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0603D8A6 mov r15,r14
    c.r[8] = c.r[5];  // 0603D8A8 mov r5,r8
    c.r[7] = (uint32_t)(int16_t)ld16(0x0603D8D6u);  // 0603D8AA mov.w 0x0603D8D6,r7
    c.r[6] = (uint32_t)(int16_t)ld16(0x0603D8D8u);  // 0603D8AC mov.w 0x0603D8D8,r6
    c.r[1] = ld32(0x0603D8DCu);  // 0603D8AE mov.l 0x0603D8DC,r1
    c.r[5] = 0x0u;  // 0603D8B0 mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0603D8B6u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603D8B6u) return; }  // 0603D8B2 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x0603D8E0u);  // 0603D8B6 mov.l 0x0603D8E0,r1
    c.r[2] = 0x0u;  // 0603D8B8 mov #0,r2
    st16(c.r[1], c.r[2]);  // 0603D8BA mov.w r2,@r1
    c.r[1] = ld32(0x0603D8E4u);  // 0603D8BC mov.l 0x0603D8E4,r1
    st16(c.r[1], c.r[2]);  // 0603D8BE mov.w r2,@r1
    c.r[1] = ld32(0x0603D8E8u);  // 0603D8C0 mov.l 0x0603D8E8,r1
    st16(c.r[1], c.r[2]);  // 0603D8C2 mov.w r2,@r1
    c.r[1] = ld32(0x0603D8ECu);  // 0603D8C4 mov.l 0x0603D8EC,r1
    st16(c.r[1], c.r[2]);  // 0603D8C6 mov.w r2,@r1
    c.r[15] = c.r[14];  // 0603D8C8 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603D8CA lds.l @r15+,pr
    c.r[8] += 1;  // 0603D8CC add #1,r8
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0603D8CE mov.l @r15+,r14
    c.r[0] = c.r[8];  // 0603D8D0 mov r8,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603D8D2 rts ; mov.l @r15+,r8
}

void f_0603D8F0(SH2Context& c) {
    ran[975] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603D8F0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603D8F2 sts.l pr,@-r15
    c.r[1] = c.r[5];  // 0603D8F4 mov r5,r1
    c.r[1] += 1;  // 0603D8F6 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603D8F8 mov.b @r1,r1
    c.r[14] = c.r[15];  // 0603D8FA mov r15,r14
    c.r[0] = c.r[1] & 0xFFu;  // 0603D8FC extu.b r1,r0
    c.r[0] <<= 2;  // 0603D8FE shll2 r0
    c.r[1] = ld32(0x0603D910u);  // 0603D900 mov.l 0x0603D910,r1
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 0603D902 mov.l @(r0,r1),r0
    { const uint32_t x = c.r[0]; c.pr = 0x0603D908u; c.r[5] += 2; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603D908u) return; }  // 0603D904 jsr @r0 ; add #2,r5
    c.r[15] = c.r[14];  // 0603D908 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603D90A lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603D90C rts ; mov.l @r15+,r14
}

void f_0603D914(SH2Context& c) {
    ran[976] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0603D914 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0603D916 sts.l pr,@-r15
    c.r[1] = c.r[5];  // 0603D918 mov r5,r1
    c.r[1] += 1;  // 0603D91A add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0603D91C mov.b @r1,r1
    c.r[14] = c.r[15];  // 0603D91E mov r15,r14
    c.r[0] = c.r[1] & 0xFFu;  // 0603D920 extu.b r1,r0
    c.r[0] <<= 2;  // 0603D922 shll2 r0
    c.r[1] = ld32(0x0603D934u);  // 0603D924 mov.l 0x0603D934,r1
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 0603D926 mov.l @(r0,r1),r0
    { const uint32_t x = c.r[0]; c.pr = 0x0603D92Cu; c.r[5] += 2; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0603D92Cu) return; }  // 0603D928 jsr @r0 ; add #2,r5
    c.r[15] = c.r[14];  // 0603D92C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0603D92E lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0603D930 rts ; mov.l @r15+,r14
}

}  // namespace p_srwfin_installed
