#include "p_srwfin_installed_funcs.h"

namespace p_srwfin_installed {

void f_060AB748(SH2Context& c) {
    ran[2810] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060AB748 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060AB74A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060AB74C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060AB74E sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060AB750 mov r15,r14
    c.r[9] = c.r[4];  // 060AB752 mov r4,r9
    c.r[4] = c.r[5];  // 060AB754 mov r5,r4
    c.r[5] = c.r[6];  // 060AB756 mov r6,r5
    c.r[8] = ld32(0x060AB778u);  // 060AB758 mov.l 0x060AB778,r8
    c.r[1] = 0x0u;  // 060AB75A mov #0,r1
    st32(c.r[8], c.r[1]);  // 060AB75C mov.l r1,@r8
    c.r[0] = ld32(0x060AB77Cu);  // 060AB75E mov.l 0x060AB77C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060AB764u; c.r[6] = c.r[7]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AB764u) return; }  // 060AB760 jsr @r0 ; mov r7,r6
    c.r[8] = ld32(c.r[8]);  // 060AB764 mov.l @r8,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 060AB766 tst r8,r8
    if (c.t) { goto L_060AB76C; }  // 060AB768 bt 0x060AB76C
    st32(c.r[9], c.r[8]);  // 060AB76A mov.l r8,@r9
L_060AB76C:
    c.r[15] = c.r[14];  // 060AB76C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060AB76E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060AB770 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060AB772 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060AB774 rts ; mov.l @r15+,r8
}

void f_060AB780(SH2Context& c) {
    ran[2811] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060AB780 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060AB782 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060AB784 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060AB786 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060AB788 mov r15,r14
    c.r[9] = c.r[4];  // 060AB78A mov r4,r9
    c.r[4] = c.r[5];  // 060AB78C mov r5,r4
    c.r[5] = c.r[6];  // 060AB78E mov r6,r5
    c.r[8] = ld32(0x060AB7B0u);  // 060AB790 mov.l 0x060AB7B0,r8
    c.r[1] = 0x0u;  // 060AB792 mov #0,r1
    st32(c.r[8], c.r[1]);  // 060AB794 mov.l r1,@r8
    c.r[0] = ld32(0x060AB7B4u);  // 060AB796 mov.l 0x060AB7B4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060AB79Cu; c.r[6] = c.r[7]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AB79Cu) return; }  // 060AB798 jsr @r0 ; mov r7,r6
    c.r[8] = ld32(c.r[8]);  // 060AB79C mov.l @r8,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 060AB79E tst r8,r8
    if (c.t) { goto L_060AB7A4; }  // 060AB7A0 bt 0x060AB7A4
    st32(c.r[9], c.r[8]);  // 060AB7A2 mov.l r8,@r9
L_060AB7A4:
    c.r[15] = c.r[14];  // 060AB7A4 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060AB7A6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060AB7A8 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060AB7AA mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060AB7AC rts ; mov.l @r15+,r8
}

void f_060AB7B8(SH2Context& c) {
    ran[2812] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060AB7B8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060AB7BA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060AB7BC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060AB7BE sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060AB7C0 mov r15,r14
    c.r[9] = c.r[4];  // 060AB7C2 mov r4,r9
    c.r[4] = c.r[5];  // 060AB7C4 mov r5,r4
    c.r[8] = ld32(0x060AB7E8u);  // 060AB7C6 mov.l 0x060AB7E8,r8
    c.r[1] = 0x0u;  // 060AB7C8 mov #0,r1
    st32(c.r[8], c.r[1]);  // 060AB7CA mov.l r1,@r8
    c.r[0] = ld32(0x060AB7ECu);  // 060AB7CC mov.l 0x060AB7EC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060AB7D2u; c.r[5] = c.r[6]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AB7D2u) return; }  // 060AB7CE jsr @r0 ; mov r6,r5
    c.r[8] = ld32(c.r[8]);  // 060AB7D2 mov.l @r8,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 060AB7D4 tst r8,r8
    if (c.t) { goto L_060AB7DA; }  // 060AB7D6 bt 0x060AB7DA
    st32(c.r[9], c.r[8]);  // 060AB7D8 mov.l r8,@r9
L_060AB7DA:
    c.r[15] = c.r[14];  // 060AB7DA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060AB7DC lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060AB7DE mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060AB7E0 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060AB7E2 rts ; mov.l @r15+,r8
}

void f_060AB7F0(SH2Context& c) {
    ran[2813] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060AB7F0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060AB7F2 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060AB7F4 mov r15,r14
    c.r[7] = c.r[6];  // 060AB7F6 mov r6,r7
    c.r[0] = ld32(0x060AB80Cu);  // 060AB7F8 mov.l 0x060AB80C,r0
    c.r[6] = c.r[5];  // 060AB7FA mov r5,r6
    c.r[5] = c.r[4];  // 060AB7FC mov r4,r5
    { const uint32_t x = c.r[0]; c.pr = 0x060AB802u; c.r[4] = 0x3u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AB802u) return; }  // 060AB7FE jsr @r0 ; mov #3,r4
    c.r[15] = c.r[14];  // 060AB802 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060AB804 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060AB806 rts ; mov.l @r15+,r14
}

void f_060AB810(SH2Context& c) {
    ran[2814] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060AB810 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060AB812 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060AB814 mov r15,r14
    c.r[7] = c.r[6];  // 060AB816 mov r6,r7
    c.r[0] = ld32(0x060AB82Cu);  // 060AB818 mov.l 0x060AB82C,r0
    c.r[6] = c.r[5];  // 060AB81A mov r5,r6
    c.r[5] = c.r[4];  // 060AB81C mov r4,r5
    { const uint32_t x = c.r[0]; c.pr = 0x060AB822u; c.r[4] = 0x13u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AB822u) return; }  // 060AB81E jsr @r0 ; mov #19,r4
    c.r[15] = c.r[14];  // 060AB822 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060AB824 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060AB826 rts ; mov.l @r15+,r14
}

void f_060AB830(SH2Context& c) {
    ran[2815] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060AB830 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060AB832 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060AB834 mov r15,r14
    c.r[7] = c.r[6];  // 060AB836 mov r6,r7
    c.r[0] = ld32(0x060AB84Cu);  // 060AB838 mov.l 0x060AB84C,r0
    c.r[6] = c.r[5];  // 060AB83A mov r5,r6
    c.r[5] = c.r[4];  // 060AB83C mov r4,r5
    { const uint32_t x = c.r[0]; c.pr = 0x060AB842u; c.r[4] = 0x4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AB842u) return; }  // 060AB83E jsr @r0 ; mov #4,r4
    c.r[15] = c.r[14];  // 060AB842 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060AB844 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060AB846 rts ; mov.l @r15+,r14
}

void f_060AB850(SH2Context& c) {
    ran[2816] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060AB850 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060AB852 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060AB854 mov r15,r14
    c.r[5] = c.r[4];  // 060AB856 mov r4,r5
    c.r[0] = ld32(0x060AB86Cu);  // 060AB858 mov.l 0x060AB86C,r0
    c.r[7] = 0x0u;  // 060AB85A mov #0,r7
    c.r[6] = 0x0u;  // 060AB85C mov #0,r6
    { const uint32_t x = c.r[0]; c.pr = 0x060AB862u; c.r[4] = 0x6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AB862u) return; }  // 060AB85E jsr @r0 ; mov #6,r4
    c.r[15] = c.r[14];  // 060AB862 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060AB864 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060AB866 rts ; mov.l @r15+,r14
}

void f_060AB88C(SH2Context& c) {
    ran[2817] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060AB88C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060AB88E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060AB890 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060AB892 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060AB894 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060AB896 mov r15,r14
    c.r[8] = ld32(0x060AB8D4u);  // 060AB898 mov.l 0x060AB8D4,r8
    c.r[1] = ld32(c.r[8]);  // 060AB89A mov.l @r8,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060AB89C tst r1,r1
    { const bool k = !c.t; c.r[10] = c.r[4]; if (k) { goto L_060AB8A6; } }  // 060AB89E bf/s 0x060AB8A6 ; mov r4,r10
    c.r[1] = ld32(0x060AB8D8u);  // 060AB8A2 mov.l 0x060AB8D8,r1
    st32(c.r[8], c.r[1]);  // 060AB8A4 mov.l r1,@r8
L_060AB8A6:
    c.r[9] = ld32(c.r[8]);  // 060AB8A6 mov.l @r8,r9
    c.t = c.r[9] > c.r[15];  // 060AB8A8 cmp/hi r15,r9
    { const bool k = !c.t; c.r[6] = 0x19u; if (k) { goto L_060AB8BC; } }  // 060AB8AA bf/s 0x060AB8BC ; mov #25,r6
    c.r[5] = ld32(0x060AB8DCu);  // 060AB8AE mov.l 0x060AB8DC,r5
    c.r[0] = ld32(0x060AB8E0u);  // 060AB8B0 mov.l 0x060AB8E0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060AB8B6u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AB8B6u) return; }  // 060AB8B2 jsr @r0 ; mov #1,r4
    c.r[0] = ld32(0x060AB8E4u);  // 060AB8B6 mov.l 0x060AB8E4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060AB8BCu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AB8BCu) return; }  // 060AB8B8 jsr @r0 ; nop
L_060AB8BC:
    c.r[1] = ld32(c.r[8]);  // 060AB8BC mov.l @r8,r1
    c.r[15] = c.r[14];  // 060AB8BE mov r14,r15
    c.r[1] += c.r[10];  // 060AB8C0 add r10,r1
    st32(c.r[8], c.r[1]);  // 060AB8C2 mov.l r1,@r8
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060AB8C4 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060AB8C6 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060AB8C8 mov.l @r15+,r10
    c.r[0] = c.r[9];  // 060AB8CA mov r9,r0
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060AB8CC mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060AB8CE rts ; mov.l @r15+,r8
}

void f_060AB8E8(SH2Context& c) {
    ran[2818] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060AB8E8 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 060AB8EA mov r15,r14
    c.r[1] = (uint32_t)(int16_t)ld16(0x060AB8F6u);  // 060AB8EC mov.w 0x060AB8F6,r1
    st32(c.r[5] + 4, c.r[1]);  // 060AB8EE mov.l r1,@(4,r5)
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060AB8F0 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = 0x0u; c.pc = x; return; }  // 060AB8F2 rts ; mov #0,r0
}

void f_060AB8F8(SH2Context& c) {
    ran[2819] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060AB8F8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060AB8FA sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060AB8FC mov r15,r14
    c.r[6] = c.r[5];  // 060AB8FE mov r5,r6
    c.r[0] = ld32(0x060AB914u);  // 060AB900 mov.l 0x060AB914,r0
    c.r[7] = 0x0u;  // 060AB902 mov #0,r7
    c.r[5] = c.r[4];  // 060AB904 mov r4,r5
    { const uint32_t x = c.r[0]; c.pr = 0x060AB90Au; c.r[4] = 0x5u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AB90Au) return; }  // 060AB906 jsr @r0 ; mov #5,r4
    c.r[15] = c.r[14];  // 060AB90A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060AB90C lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060AB90E rts ; mov.l @r15+,r14
}

void f_060AB918(SH2Context& c) {
    ran[2820] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060AB918 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060AB91A sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060AB91C mov r15,r14
    c.r[6] = c.r[5];  // 060AB91E mov r5,r6
    c.r[0] = ld32(0x060AB934u);  // 060AB920 mov.l 0x060AB934,r0
    c.r[7] = 0x0u;  // 060AB922 mov #0,r7
    c.r[5] = c.r[4];  // 060AB924 mov r4,r5
    { const uint32_t x = c.r[0]; c.pr = 0x060AB92Au; c.r[4] = 0x8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AB92Au) return; }  // 060AB926 jsr @r0 ; mov #8,r4
    c.r[15] = c.r[14];  // 060AB92A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060AB92C lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060AB92E rts ; mov.l @r15+,r14
}

void f_060AB938(SH2Context& c) {
    ran[2821] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060AB938 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 060AB93A mov r15,r14
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060AB93C mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = 0xFFFFFFFFu; c.pc = x; return; }  // 060AB93E rts ; mov #-1,r0
}

void f_060AB944(SH2Context& c) {
    ran[2822] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060AB944 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 060AB946 mov r15,r14
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060AB948 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 060AB94A rts ; mov #1,r0
}

void f_060AB950(SH2Context& c) {
    ran[2823] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060AB950 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060AB952 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060AB954 mov r15,r14
    c.r[5] = c.r[4];  // 060AB956 mov r4,r5
    c.r[0] = ld32(0x060AB96Cu);  // 060AB958 mov.l 0x060AB96C,r0
    c.r[7] = 0x0u;  // 060AB95A mov #0,r7
    c.r[6] = 0x0u;  // 060AB95C mov #0,r6
    { const uint32_t x = c.r[0]; c.pr = 0x060AB962u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AB962u) return; }  // 060AB95E jsr @r0 ; mov #1,r4
    c.r[15] = c.r[14];  // 060AB962 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060AB964 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060AB966 rts ; mov.l @r15+,r14
}

void f_060AB970(SH2Context& c) {
    ran[2824] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060AB970 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060AB972 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060AB974 mov r15,r14
    c.r[5] = ld32(0x060AB98Cu);  // 060AB976 mov.l 0x060AB98C,r5
    c.r[0] = ld32(0x060AB990u);  // 060AB978 mov.l 0x060AB990,r0
    c.r[7] = 0x0u;  // 060AB97A mov #0,r7
    c.r[6] = 0x0u;  // 060AB97C mov #0,r6
    { const uint32_t x = c.r[0]; c.pr = 0x060AB982u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AB982u) return; }  // 060AB97E jsr @r0 ; mov #1,r4
    c.r[15] = c.r[14];  // 060AB982 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060AB984 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060AB986 rts ; mov.l @r15+,r14
}

void f_060AB994(SH2Context& c) {
    ran[2825] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060AB994 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 060AB996 mov r15,r14
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060AB998 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 060AB99A rts ; mov #1,r0
}

void f_060AB9A0(SH2Context& c) {
    ran[2826] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060AB9A0 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 060AB9A2 mov r15,r14
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060AB9A4 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060AB9A6 rts ; nop
}

void f_060AB9AC(SH2Context& c) {
    ran[2827] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060AB9AC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060AB9AE sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060AB9B0 mov r15,r14
    c.r[6] = c.r[5];  // 060AB9B2 mov r5,r6
    c.r[0] = ld32(0x060AB9C8u);  // 060AB9B4 mov.l 0x060AB9C8,r0
    c.r[7] = 0x0u;  // 060AB9B6 mov #0,r7
    c.r[5] = c.r[4];  // 060AB9B8 mov r4,r5
    { const uint32_t x = c.r[0]; c.pr = 0x060AB9BEu; c.r[4] = 0x26u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AB9BEu) return; }  // 060AB9BA jsr @r0 ; mov #38,r4
    c.r[15] = c.r[14];  // 060AB9BE mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060AB9C0 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060AB9C2 rts ; mov.l @r15+,r14
}

void f_060AB9E8(SH2Context& c) {
    ran[2828] = 1;
    c.r[6] = c.mach;  // 060AB9E8 sts mach,r6
    c.r[0] = ld32(c.gbr + 800);  // 060AB9EA mov.l @(800,gbr),r0
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060AB9EC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060AB9EE sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060AB9F0 mov r15,r14
    c.r[7] = c.r[6];  // 060AB9F2 mov r6,r7
    c.r[5] = (uint32_t)(int32_t)(int16_t)c.r[5];  // 060AB9F4 exts.w r5,r5
    c.r[7] = (uint32_t)(int32_t)(int16_t)c.r[7];  // 060AB9F6 exts.w r7,r7
    c.r[0] = ld32(0x060ABA0Cu);  // 060AB9F8 mov.l 0x060ABA0C,r0
    c.r[6] = c.r[5];  // 060AB9FA mov r5,r6
    c.r[5] = c.r[4];  // 060AB9FC mov r4,r5
    { const uint32_t x = c.r[0]; c.pr = 0x060ABA02u; c.r[4] = 0x10u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060ABA02u) return; }  // 060AB9FE jsr @r0 ; mov #16,r4
    c.r[15] = c.r[14];  // 060ABA02 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060ABA04 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060ABA06 rts ; mov.l @r15+,r14
}

void f_060ABA10(SH2Context& c) {
    ran[2829] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060ABA10 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060ABA12 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060ABA14 mov r15,r14
    c.r[1] = c.r[4];  // 060ABA16 mov r4,r1
    c.r[6] = c.r[5];  // 060ABA18 mov r5,r6
    c.r[4] = (uint32_t)(int16_t)ld16(0x060ABA2Au);  // 060ABA1A mov.w 0x060ABA2A,r4
    c.r[0] = ld32(0x060ABA2Cu);  // 060ABA1C mov.l 0x060ABA2C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060ABA22u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060ABA22u) return; }  // 060ABA1E jsr @r0 ; mov r1,r5
    c.r[15] = c.r[14];  // 060ABA22 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060ABA24 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060ABA26 rts ; mov.l @r15+,r14
}

void f_060ABA44(SH2Context& c) {
    ran[2830] = 1;
    c.r[6] = c.mach;  // 060ABA44 sts mach,r6
    c.r[0] = ld32(c.gbr + 800);  // 060ABA46 mov.l @(800,gbr),r0
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060ABA48 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060ABA4A sts.l pr,@-r15
    c.r[4] = (uint32_t)(int16_t)ld16(0x060ABA5Cu);  // 060ABA4C mov.w 0x060ABA5C,r4
    c.r[0] = ld32(0x060ABA60u);  // 060ABA4E mov.l 0x060ABA60,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060ABA54u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060ABA54u) return; }  // 060ABA50 jsr @r0 ; mov r15,r14
    c.r[15] = c.r[14];  // 060ABA54 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060ABA56 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060ABA58 rts ; mov.l @r15+,r14
}

void f_060ABA80(SH2Context& c) {
    ran[2831] = 1;
    c.r[6] = c.mach;  // 060ABA80 sts mach,r6
    c.r[0] = ld32(c.gbr + 800);  // 060ABA82 mov.l @(800,gbr),r0
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060ABA84 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060ABA86 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060ABA88 mov r15,r14
    c.r[6] = c.r[5];  // 060ABA8A mov r5,r6
    c.r[0] = ld32(0x060ABA9Cu);  // 060ABA8C mov.l 0x060ABA9C,r0
    c.r[5] = c.r[4];  // 060ABA8E mov r4,r5
    { const uint32_t x = c.r[0]; c.pr = 0x060ABA94u; c.r[4] = 0xBu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060ABA94u) return; }  // 060ABA90 jsr @r0 ; mov #11,r4
    c.r[15] = c.r[14];  // 060ABA94 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060ABA96 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060ABA98 rts ; mov.l @r15+,r14
}

void f_060ABAA0(SH2Context& c) {
    ran[2832] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060ABAA0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060ABAA2 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060ABAA4 mov r15,r14
    c.r[5] = c.r[4];  // 060ABAA6 mov r4,r5
    c.r[0] = ld32(0x060ABAB8u);  // 060ABAA8 mov.l 0x060ABAB8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060ABAAEu; c.r[4] = 0x2Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060ABAAEu) return; }  // 060ABAAA jsr @r0 ; mov #42,r4
    c.r[15] = c.r[14];  // 060ABAAE mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060ABAB0 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060ABAB2 rts ; mov.l @r15+,r14
}

void f_060ABABC(SH2Context& c) {
    ran[2833] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060ABABC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060ABABE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060ABAC0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060ABAC2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060ABAC4 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060ABAC6 mov r15,r14
    c.r[8] = c.r[4];  // 060ABAC8 mov r4,r8
    c.r[9] = c.r[8];  // 060ABACA mov r8,r9
    c.r[9] += 112;  // 060ABACC add #112,r9
    c.r[1] = ld32(c.r[9]);  // 060ABACE mov.l @r9,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060ABAD0 tst r1,r1
    { const bool k = !c.t; c.r[10] = c.r[5]; if (k) { goto L_060ABAE4; } }  // 060ABAD2 bf/s 0x060ABAE4 ; mov r5,r10
    c.r[0] = ld32(0x060ABB38u);  // 060ABAD6 mov.l 0x060ABB38,r0
    c.r[6] = 0x10u;  // 060ABAD8 mov #16,r6
    { const uint32_t x = c.r[0]; c.pr = 0x060ABADEu; c.r[5] = 0x4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060ABADEu) return; }  // 060ABADA jsr @r0 ; mov #4,r5
    c.t = (c.r[0] & c.r[0]) == 0;  // 060ABADE tst r0,r0
    { const bool k = c.t; st32(c.r[9], c.r[0]); if (k) { goto L_060ABB1A; } }  // 060ABAE0 bt/s 0x060ABB1A ; mov.l r0,@r9
L_060ABAE4:
    c.r[1] = c.r[8];  // 060ABAE4 mov r8,r1
    c.r[1] += 112;  // 060ABAE6 add #112,r1
    c.r[2] = c.r[10];  // 060ABAE8 mov r10,r2
    c.r[2] <<= 2;  // 060ABAEA shll2 r2
    c.r[3] = ld32(c.r[1]);  // 060ABAEC mov.l @r1,r3
    c.r[0] = c.r[2];  // 060ABAEE mov r2,r0
    c.r[7] = ld32(c.r[0] + c.r[3]);  // 060ABAF0 mov.l @(r0,r3),r7
    c.t = (c.r[7] & c.r[7]) == 0;  // 060ABAF2 tst r7,r7
    { const bool k = c.t; c.r[5] = c.r[10]; if (k) { goto L_060ABAFE; } }  // 060ABAF4 bt/s 0x060ABAFE ; mov r10,r5
    c.r[1] = ld32(c.r[7]);  // 060ABAF8 mov.l @r7,r1
    st32(c.r[0] + c.r[3], c.r[1]); goto L_060ABB22;  // 060ABAFA bra 0x060ABB22 ; mov.l r1,@(r0,r3)
L_060ABAFE:
    c.r[0] = ld32(0x060ABB3Cu);  // 060ABAFE mov.l 0x060ABB3C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060ABB04u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060ABB04u) return; }  // 060ABB00 jsr @r0 ; mov #1,r4
    c.r[9] = c.r[0];  // 060ABB04 mov r0,r9
    c.r[6] = c.r[9];  // 060ABB06 mov r9,r6
    c.r[6] <<= 2;  // 060ABB08 shll2 r6
    c.r[6] += 20;  // 060ABB0A add #20,r6
    c.r[0] = ld32(0x060ABB38u);  // 060ABB0C mov.l 0x060ABB38,r0
    c.r[5] = 0x1u;  // 060ABB0E mov #1,r5
    { const uint32_t x = c.r[0]; c.pr = 0x060ABB14u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060ABB14u) return; }  // 060ABB10 jsr @r0 ; mov r8,r4
    c.r[7] = c.r[0];  // 060ABB14 mov r0,r7
    c.t = (c.r[7] & c.r[7]) == 0;  // 060ABB16 tst r7,r7
    if (!c.t) { goto L_060ABB1E; }  // 060ABB18 bf 0x060ABB1E
L_060ABB1A:
    c.r[0] = 0x0u; goto L_060ABB2A;  // 060ABB1A bra 0x060ABB2A ; mov #0,r0
L_060ABB1E:
    st32(c.r[7] + 4, c.r[10]);  // 060ABB1E mov.l r10,@(4,r7)
    st32(c.r[7] + 8, c.r[9]);  // 060ABB20 mov.l r9,@(8,r7)
L_060ABB22:
    c.r[1] = 0x0u;  // 060ABB22 mov #0,r1
    st32(c.r[7] + 16, c.r[1]);  // 060ABB24 mov.l r1,@(16,r7)
    st32(c.r[7] + 12, c.r[1]);  // 060ABB26 mov.l r1,@(12,r7)
    c.r[0] = c.r[7];  // 060ABB28 mov r7,r0
L_060ABB2A:
    c.r[15] = c.r[14];  // 060ABB2A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060ABB2C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060ABB2E mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060ABB30 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060ABB32 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060ABB34 rts ; mov.l @r15+,r8
}

void f_060ABB40(SH2Context& c) {
    ran[2834] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060ABB40 mov.l r14,@-r15
    c.t = (c.r[5] & c.r[5]) == 0;  // 060ABB42 tst r5,r5
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_060ABB62; } }  // 060ABB44 bt/s 0x060ABB62 ; mov r15,r14
    c.r[3] = c.r[4];  // 060ABB48 mov r4,r3
    c.r[2] = ld32(c.r[5] + 4);  // 060ABB4A mov.l @(4,r5),r2
    c.r[3] += 112;  // 060ABB4C add #112,r3
    c.r[1] = ld32(c.r[3]);  // 060ABB4E mov.l @r3,r1
    c.r[2] <<= 2;  // 060ABB50 shll2 r2
    c.r[0] = c.r[2];  // 060ABB52 mov r2,r0
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 060ABB54 mov.l @(r0,r1),r1
    c.r[2] = ld32(c.r[5] + 4);  // 060ABB56 mov.l @(4,r5),r2
    st32(c.r[5], c.r[1]);  // 060ABB58 mov.l r1,@r5
    c.r[1] = ld32(c.r[3]);  // 060ABB5A mov.l @r3,r1
    c.r[2] <<= 2;  // 060ABB5C shll2 r2
    c.r[0] = c.r[2];  // 060ABB5E mov r2,r0
    st32(c.r[0] + c.r[1], c.r[5]);  // 060ABB60 mov.l r5,@(r0,r1)
L_060ABB62:
    c.r[15] = c.r[14];  // 060ABB62 mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060ABB64 rts ; mov.l @r15+,r14
}

void f_060ABB68(SH2Context& c) {
    ran[2835] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060ABB68 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060ABB6A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060ABB6C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060ABB6E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060ABB70 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060ABB72 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060ABB74 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060ABB76 mov r15,r14
    c.r[12] = c.r[4];  // 060ABB78 mov r4,r12
    c.r[8] = c.r[5];  // 060ABB7A mov r5,r8
    c.r[10] = c.r[7];  // 060ABB7C mov r7,r10
    c.r[9] = ld32(c.r[8] + 16);  // 060ABB7E mov.l @(16,r8),r9
    c.r[7] = c.r[8];  // 060ABB80 mov r8,r7
    c.r[7] += 20;  // 060ABB82 add #20,r7
    c.r[5] = 0x0u;  // 060ABB84 mov #0,r5
    c.r[4] = ld32(0x060ABC08u);  // 060ABB86 mov.l 0x060ABC08,r4
L_060ABB88:
    c.r[2] = ld32(c.r[7]);  // 060ABB88 mov.l @r7,r2
    c.r[1] = c.r[2];  // 060ABB8A mov r2,r1
    c.r[1] &= c.r[4];  // 060ABB8C and r4,r1
    c.macl = c.r[1] * c.r[6];  // 060ABB8E mul.l r6,r1
    c.r[5] += 1;  // 060ABB90 add #1,r5
    c.r[2] >>= 16;  // 060ABB92 shlr16 r2
    c.r[3] = c.macl;  // 060ABB94 sts macl,r3
    c.r[3] += c.r[10];  // 060ABB96 add r10,r3
    c.r[1] = c.r[3];  // 060ABB98 mov r3,r1
    c.macl = c.r[2] * c.r[6];  // 060ABB9A mul.l r6,r2
    c.r[1] >>= 16;  // 060ABB9C shlr16 r1
    c.r[3] &= c.r[4];  // 060ABB9E and r4,r3
    c.r[2] = c.macl;  // 060ABBA0 sts macl,r2
    c.r[2] += c.r[1];  // 060ABBA2 add r1,r2
    c.r[10] = c.r[2];  // 060ABBA4 mov r2,r10
    c.r[10] >>= 16;  // 060ABBA6 shlr16 r10
    c.r[2] <<= 16;  // 060ABBA8 shll16 r2
    c.r[2] += c.r[3];  // 060ABBAA add r3,r2
    st32(c.r[7], c.r[2]);  // 060ABBAC mov.l r2,@r7
    c.t = (int32_t)c.r[5] >= (int32_t)c.r[9];  // 060ABBAE cmp/ge r9,r5
    { const bool k = !c.t; c.r[7] += 4; if (k) { SH2_POLL(c); goto L_060ABB88; } }  // 060ABBB0 bf/s 0x060ABB88 ; add #4,r7
    c.t = (c.r[10] & c.r[10]) == 0;  // 060ABBB4 tst r10,r10
    if (c.t) { goto L_060ABBF2; }  // 060ABBB6 bt 0x060ABBF2
    c.r[1] = ld32(c.r[8] + 8);  // 060ABBB8 mov.l @(8,r8),r1
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[1];  // 060ABBBA cmp/ge r1,r9
    if (!c.t) { goto L_060ABBE6; }  // 060ABBBC bf 0x060ABBE6
    c.r[5] = ld32(c.r[8] + 4);  // 060ABBBE mov.l @(4,r8),r5
    c.r[0] = ld32(0x060ABC0Cu);  // 060ABBC0 mov.l 0x060ABC0C,r0
    c.r[4] = c.r[12];  // 060ABBC2 mov r12,r4
    { const uint32_t x = c.r[0]; c.pr = 0x060ABBC8u; c.r[5] += 1; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060ABBC8u) return; }  // 060ABBC4 jsr @r0 ; add #1,r5
    c.r[11] = c.r[0];  // 060ABBC8 mov r0,r11
    c.r[5] = c.r[8];  // 060ABBCA mov r8,r5
    c.r[5] += 12;  // 060ABBCC add #12,r5
    c.r[4] = c.r[11];  // 060ABBCE mov r11,r4
    c.r[4] += 12;  // 060ABBD0 add #12,r4
    c.r[6] = ld32(c.r[8] + 16);  // 060ABBD2 mov.l @(16,r8),r6
    c.r[0] = ld32(0x060ABC10u);  // 060ABBD4 mov.l 0x060ABC10,r0
    c.r[6] <<= 2;  // 060ABBD6 shll2 r6
    { const uint32_t x = c.r[0]; c.pr = 0x060ABBDCu; c.r[6] += 8; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060ABBDCu) return; }  // 060ABBD8 jsr @r0 ; add #8,r6
    c.r[1] = ld32(0x060ABC14u);  // 060ABBDC mov.l 0x060ABC14,r1
    c.r[5] = c.r[8];  // 060ABBDE mov r8,r5
    { const uint32_t x = c.r[1]; c.pr = 0x060ABBE4u; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060ABBE4u) return; }  // 060ABBE0 jsr @r1 ; mov r12,r4
    c.r[8] = c.r[11];  // 060ABBE4 mov r11,r8
L_060ABBE6:
    c.r[1] = c.r[9];  // 060ABBE6 mov r9,r1
    c.r[1] <<= 2;  // 060ABBE8 shll2 r1
    c.r[1] += c.r[8];  // 060ABBEA add r8,r1
    st32(c.r[1] + 20, c.r[10]);  // 060ABBEC mov.l r10,@(20,r1)
    c.r[9] += 1;  // 060ABBEE add #1,r9
    st32(c.r[8] + 16, c.r[9]);  // 060ABBF0 mov.l r9,@(16,r8)
L_060ABBF2:
    c.r[15] = c.r[14];  // 060ABBF2 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060ABBF4 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060ABBF6 mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060ABBF8 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060ABBFA mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060ABBFC mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060ABBFE mov.l @r15+,r9
    c.r[0] = c.r[8];  // 060ABC00 mov r8,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060ABC02 rts ; mov.l @r15+,r8
}

void f_060ABC18(SH2Context& c) {
    ran[2836] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060ABC18 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060ABC1A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060ABC1C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060ABC1E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060ABC20 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060ABC22 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060ABC24 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060ABC26 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060ABC28 mov r15,r14
    c.r[10] = c.r[4];  // 060ABC2A mov r4,r10
    c.r[8] = c.r[5];  // 060ABC2C mov r5,r8
    c.r[11] = c.r[6];  // 060ABC2E mov r6,r11
    c.r[12] = c.r[7];  // 060ABC30 mov r7,r12
    c.r[2] = c.r[12];  // 060ABC32 mov r12,r2
    c.r[2] += 8;  // 060ABC34 add #8,r2
    c.r[1] = ld32(0x060ABCB4u);  // 060ABC36 mov.l 0x060ABCB4,r1
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[2] * (int32_t)c.r[1]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060ABC38 dmuls.l r1,r2
    c.r[9] = ld32(c.r[14] + 32);  // 060ABC3A mov.l @(32,r14),r9
    c.r[3] = c.mach;  // 060ABC3C sts mach,r3
    c.t = c.r[3] & 1; c.r[3] = (uint32_t)((int32_t)c.r[3] >> 1);  // 060ABC3E shar r3
    c.t = c.r[2] >> 31; c.r[2] <<= 1;  // 060ABC40 shll r2
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060ABC42 subc r2,r2
    c.r[3] -= c.r[2];  // 060ABC44 sub r2,r3
    c.r[1] = 0x1u;  // 060ABC46 mov #1,r1
    c.t = (int32_t)c.r[3] > (int32_t)c.r[1];  // 060ABC48 cmp/gt r1,r3
    { const bool k = !c.t; c.r[5] = 0x0u; if (k) { goto L_060ABC56; } }  // 060ABC4A bf/s 0x060ABC56 ; mov #0,r5
L_060ABC4E:
    c.r[1] += c.r[1];  // 060ABC4E add r1,r1
    c.t = (int32_t)c.r[3] > (int32_t)c.r[1];  // 060ABC50 cmp/gt r1,r3
    { const bool k = c.t; c.r[5] += 1; if (k) { SH2_POLL(c); goto L_060ABC4E; } }  // 060ABC52 bt/s 0x060ABC4E ; add #1,r5
L_060ABC56:
    c.r[0] = ld32(0x060ABCB8u);  // 060ABC56 mov.l 0x060ABCB8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060ABC5Cu; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060ABC5Cu) return; }  // 060ABC58 jsr @r0 ; mov r10,r4
    st32(c.r[0] + 20, c.r[9]);  // 060ABC5C mov.l r9,@(20,r0)
    c.r[1] = 0x1u;  // 060ABC5E mov #1,r1
    c.r[9] = 0x9u;  // 060ABC60 mov #9,r9
    c.t = (int32_t)c.r[11] > (int32_t)c.r[9];  // 060ABC62 cmp/gt r9,r11
    { const bool k = !c.t; st32(c.r[0] + 16, c.r[1]); if (k) { goto L_060ABC84; } }  // 060ABC64 bf/s 0x060ABC84 ; mov.l r1,@(16,r0)
    c.r[8] += 9;  // 060ABC68 add #9,r8
    c.r[13] = ld32(0x060ABCBCu);  // 060ABC6A mov.l 0x060ABCBC,r13
L_060ABC6C:
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[8]); c.r[8] += 1;  // 060ABC6C mov.b @r8+,r7
    c.r[6] = 0xAu;  // 060ABC6E mov #10,r6
    c.r[5] = c.r[0];  // 060ABC70 mov r0,r5
    c.r[4] = c.r[10];  // 060ABC72 mov r10,r4
    { const uint32_t x = c.r[13]; c.pr = 0x060ABC78u; c.r[7] -= 48; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060ABC78u) return; }  // 060ABC74 jsr @r13 ; add #-48,r7
    c.r[9] += 1;  // 060ABC78 add #1,r9
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[11];  // 060ABC7A cmp/ge r11,r9
    if (!c.t) { SH2_POLL(c); goto L_060ABC6C; }  // 060ABC7C bf 0x060ABC6C
    c.r[8] += 1;  // 060ABC7E add #1,r8
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[12]; goto L_060ABC88;  // 060ABC80 bra 0x060ABC88 ; cmp/ge r12,r9
L_060ABC84:
    c.r[8] += 10;  // 060ABC84 add #10,r8
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[12];  // 060ABC86 cmp/ge r12,r9
L_060ABC88:
    if (c.t) { goto L_060ABC9E; }  // 060ABC88 bt 0x060ABC9E
    c.r[11] = ld32(0x060ABCBCu);  // 060ABC8A mov.l 0x060ABCBC,r11
L_060ABC8C:
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[8]); c.r[8] += 1;  // 060ABC8C mov.b @r8+,r7
    c.r[6] = 0xAu;  // 060ABC8E mov #10,r6
    c.r[5] = c.r[0];  // 060ABC90 mov r0,r5
    c.r[4] = c.r[10];  // 060ABC92 mov r10,r4
    { const uint32_t x = c.r[11]; c.pr = 0x060ABC98u; c.r[7] -= 48; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060ABC98u) return; }  // 060ABC94 jsr @r11 ; add #-48,r7
    c.r[9] += 1;  // 060ABC98 add #1,r9
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[12];  // 060ABC9A cmp/ge r12,r9
    if (!c.t) { SH2_POLL(c); goto L_060ABC8C; }  // 060ABC9C bf 0x060ABC8C
L_060ABC9E:
    c.r[15] = c.r[14];  // 060ABC9E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060ABCA0 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060ABCA2 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060ABCA4 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060ABCA6 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060ABCA8 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060ABCAA mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060ABCAC mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060ABCAE rts ; mov.l @r15+,r8
}

void f_060ABCC0(SH2Context& c) {
    ran[2837] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060ABCC0 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 060ABCC2 mov r15,r14
    c.r[1] = ld32(0x060ABD14u);  // 060ABCC4 mov.l 0x060ABD14,r1
    c.r[1] &= c.r[4];  // 060ABCC6 and r4,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060ABCC8 tst r1,r1
    { const bool k = !c.t; c.r[0] = 0x0u; if (k) { goto L_060ABCD2; } }  // 060ABCCA bf/s 0x060ABCD2 ; mov #0,r0
    c.r[0] = 0x10u;  // 060ABCCE mov #16,r0
    c.r[4] <<= 16;  // 060ABCD0 shll16 r4
L_060ABCD2:
    c.r[1] = ld32(0x060ABD18u);  // 060ABCD2 mov.l 0x060ABD18,r1
    c.r[1] &= c.r[4];  // 060ABCD4 and r4,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060ABCD6 tst r1,r1
    if (!c.t) { goto L_060ABCDE; }  // 060ABCD8 bf 0x060ABCDE
    c.r[0] += 8;  // 060ABCDA add #8,r0
    c.r[4] <<= 8;  // 060ABCDC shll8 r4
L_060ABCDE:
    c.r[1] = ld32(0x060ABD1Cu);  // 060ABCDE mov.l 0x060ABD1C,r1
    c.r[1] &= c.r[4];  // 060ABCE0 and r4,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060ABCE2 tst r1,r1
    if (!c.t) { goto L_060ABCEC; }  // 060ABCE4 bf 0x060ABCEC
    c.r[0] += 4;  // 060ABCE6 add #4,r0
    c.r[4] <<= 2;  // 060ABCE8 shll2 r4
    c.r[4] <<= 2;  // 060ABCEA shll2 r4
L_060ABCEC:
    c.r[1] = ld32(0x060ABD20u);  // 060ABCEC mov.l 0x060ABD20,r1
    c.r[1] &= c.r[4];  // 060ABCEE and r4,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060ABCF0 tst r1,r1
    if (!c.t) { goto L_060ABCF8; }  // 060ABCF2 bf 0x060ABCF8
    c.r[0] += 2;  // 060ABCF4 add #2,r0
    c.r[4] <<= 2;  // 060ABCF6 shll2 r4
L_060ABCF8:
    c.r[1] = ld32(0x060ABD24u);  // 060ABCF8 mov.l 0x060ABD24,r1
    c.r[1] &= c.r[4];  // 060ABCFA and r4,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060ABCFC tst r1,r1
    { const bool k = !c.t; c.r[15] = c.r[14]; if (k) { goto L_060ABD10; } }  // 060ABCFE bf/s 0x060ABD10 ; mov r14,r15
    c.r[1] = ld32(0x060ABD28u);  // 060ABD02 mov.l 0x060ABD28,r1
    c.r[4] &= c.r[1];  // 060ABD04 and r1,r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 060ABD06 tst r4,r4
    { const bool k = !c.t; c.r[0] += 1; if (k) { goto L_060ABD10; } }  // 060ABD08 bf/s 0x060ABD10 ; add #1,r0
    c.r[0] = 0x20u;  // 060ABD0C mov #32,r0
    c.r[15] = c.r[14];  // 060ABD0E mov r14,r15
L_060ABD10:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060ABD10 rts ; mov.l @r15+,r14
}

void f_060ABD2C(SH2Context& c) {
    ran[2838] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060ABD2C mov.l r14,@-r15
    c.r[2] = ld32(c.r[4]);  // 060ABD2E mov.l @r4,r2
    c.r[1] = 0x7u;  // 060ABD30 mov #7,r1
    c.r[1] &= c.r[2];  // 060ABD32 and r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060ABD34 tst r1,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_060ABD5E; } }  // 060ABD36 bt/s 0x060ABD5E ; mov r15,r14
    c.r[1] = 0x1u;  // 060ABD3A mov #1,r1
    c.r[1] &= c.r[2];  // 060ABD3C and r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060ABD3E tst r1,r1
    { const bool k = c.t; c.r[1] = 0x2u; if (k) { goto L_060ABD48; } }  // 060ABD40 bt/s 0x060ABD48 ; mov #2,r1
    c.r[0] = 0x0u; goto L_060ABDA4;  // 060ABD44 bra 0x060ABDA4 ; mov #0,r0
L_060ABD48:
    c.r[1] &= c.r[2];  // 060ABD48 and r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060ABD4A tst r1,r1
    if (c.t) { goto L_060ABD56; }  // 060ABD4C bt 0x060ABD56
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 060ABD4E shlr r2
    st32(c.r[4], c.r[2]);  // 060ABD50 mov.l r2,@r4
    c.r[0] = 0x1u; goto L_060ABDA4;  // 060ABD52 bra 0x060ABDA4 ; mov #1,r0
L_060ABD56:
    c.r[2] >>= 2;  // 060ABD56 shlr2 r2
    st32(c.r[4], c.r[2]);  // 060ABD58 mov.l r2,@r4
    c.r[0] = 0x2u; goto L_060ABDA4;  // 060ABD5A bra 0x060ABDA4 ; mov #2,r0
L_060ABD5E:
    c.r[1] = c.r[2] & 0xFFFFu;  // 060ABD5E extu.w r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060ABD60 tst r1,r1
    { const bool k = !c.t; c.r[0] = 0x0u; if (k) { goto L_060ABD6A; } }  // 060ABD62 bf/s 0x060ABD6A ; mov #0,r0
    c.r[0] = 0x10u;  // 060ABD66 mov #16,r0
    c.r[2] >>= 16;  // 060ABD68 shlr16 r2
L_060ABD6A:
    c.r[1] = c.r[2] & 0xFFu;  // 060ABD6A extu.b r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060ABD6C tst r1,r1
    if (!c.t) { goto L_060ABD74; }  // 060ABD6E bf 0x060ABD74
    c.r[0] += 8;  // 060ABD70 add #8,r0
    c.r[2] >>= 8;  // 060ABD72 shlr8 r2
L_060ABD74:
    c.r[1] = 0xFu;  // 060ABD74 mov #15,r1
    c.r[1] &= c.r[2];  // 060ABD76 and r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060ABD78 tst r1,r1
    if (!c.t) { goto L_060ABD82; }  // 060ABD7A bf 0x060ABD82
    c.r[0] += 4;  // 060ABD7C add #4,r0
    c.r[2] >>= 2;  // 060ABD7E shlr2 r2
    c.r[2] >>= 2;  // 060ABD80 shlr2 r2
L_060ABD82:
    c.r[1] = 0x3u;  // 060ABD82 mov #3,r1
    c.r[1] &= c.r[2];  // 060ABD84 and r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060ABD86 tst r1,r1
    if (!c.t) { goto L_060ABD8E; }  // 060ABD88 bf 0x060ABD8E
    c.r[0] += 2;  // 060ABD8A add #2,r0
    c.r[2] >>= 2;  // 060ABD8C shlr2 r2
L_060ABD8E:
    c.r[1] = 0x1u;  // 060ABD8E mov #1,r1
    c.r[1] &= c.r[2];  // 060ABD90 and r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060ABD92 tst r1,r1
    if (!c.t) { goto L_060ABDA2; }  // 060ABD94 bf 0x060ABDA2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 060ABD96 shlr r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 060ABD98 tst r2,r2
    { const bool k = !c.t; c.r[0] += 1; if (k) { goto L_060ABDA2; } }  // 060ABD9A bf/s 0x060ABDA2 ; add #1,r0
    c.r[0] = 0x20u; goto L_060ABDA4;  // 060ABD9E bra 0x060ABDA4 ; mov #32,r0
L_060ABDA2:
    st32(c.r[4], c.r[2]);  // 060ABDA2 mov.l r2,@r4
L_060ABDA4:
    c.r[15] = c.r[14];  // 060ABDA4 mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060ABDA6 rts ; mov.l @r15+,r14
}

void f_060ABDAC(SH2Context& c) {
    ran[2839] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060ABDAC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060ABDAE mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060ABDB0 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060ABDB2 mov r15,r14
    c.r[8] = c.r[5];  // 060ABDB4 mov r5,r8
    c.r[0] = ld32(0x060ABDCCu);  // 060ABDB6 mov.l 0x060ABDCC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060ABDBCu; c.r[5] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060ABDBCu) return; }  // 060ABDB8 jsr @r0 ; mov #1,r5
    st32(c.r[0] + 20, c.r[8]);  // 060ABDBC mov.l r8,@(20,r0)
    c.r[1] = 0x1u;  // 060ABDBE mov #1,r1
    st32(c.r[0] + 16, c.r[1]);  // 060ABDC0 mov.l r1,@(16,r0)
    c.r[15] = c.r[14];  // 060ABDC2 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060ABDC4 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060ABDC6 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060ABDC8 rts ; mov.l @r15+,r8
}

void f_060ABDD0(SH2Context& c) {
    ran[2840] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060ABDD0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060ABDD2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060ABDD4 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060ABDD6 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060ABDD8 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060ABDDA mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060ABDDC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060ABDDE sts.l pr,@-r15
    c.r[15] -= 20;  // 060ABDE0 add #-20,r15
    c.r[8] = c.r[5];  // 060ABDE2 mov r5,r8
    c.r[2] = ld32(c.r[8] + 16);  // 060ABDE4 mov.l @(16,r8),r2
    c.r[9] = c.r[6];  // 060ABDE6 mov r6,r9
    c.r[1] = ld32(c.r[9] + 16);  // 060ABDE8 mov.l @(16,r9),r1
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[1];  // 060ABDEA cmp/ge r1,r2
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_060ABDF6; } }  // 060ABDEC bt/s 0x060ABDF6 ; mov r15,r14
    st32(c.r[14], c.r[8]);  // 060ABDF0 mov.l r8,@r14
    c.r[8] = c.r[9];  // 060ABDF2 mov r9,r8
    c.r[9] = ld32(c.r[14]);  // 060ABDF4 mov.l @r14,r9
L_060ABDF6:
    c.r[5] = ld32(c.r[8] + 4);  // 060ABDF6 mov.l @(4,r8),r5
    c.r[10] = ld32(c.r[8] + 16);  // 060ABDF8 mov.l @(16,r8),r10
    c.r[13] = ld32(c.r[9] + 16);  // 060ABDFA mov.l @(16,r9),r13
    c.r[1] = ld32(c.r[8] + 8);  // 060ABDFC mov.l @(8,r8),r1
    c.r[11] = c.r[10];  // 060ABDFE mov r10,r11
    c.r[11] += c.r[13];  // 060ABE00 add r13,r11
    c.t = (int32_t)c.r[11] > (int32_t)c.r[1];  // 060ABE02 cmp/gt r1,r11
    { const bool k = !c.t; st32(c.r[14] + 16, c.r[10]); if (k) { goto L_060ABE0A; } }  // 060ABE04 bf/s 0x060ABE0A ; mov.l r10,@(16,r14)
    c.r[5] += 1;  // 060ABE08 add #1,r5
L_060ABE0A:
    c.r[0] = ld32(0x060ABF30u);  // 060ABE0A mov.l 0x060ABF30,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060ABE10u; c.r[12] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060ABE10u) return; }  // 060ABE0C jsr @r0 ; mov r11,r12
    st32(c.r[14], c.r[0]);  // 060ABE10 mov.l r0,@r14
    c.r[5] = c.r[0];  // 060ABE12 mov r0,r5
    c.r[5] += 20;  // 060ABE14 add #20,r5
    c.r[12] <<= 2;  // 060ABE16 shll2 r12
    c.r[12] += c.r[5];  // 060ABE18 add r5,r12
    c.t = c.r[5] >= c.r[12];  // 060ABE1A cmp/hs r12,r5
    { const bool k = c.t; st32(c.r[14] + 12, c.r[12]); if (k) { goto L_060ABE2C; } }  // 060ABE1C bt/s 0x060ABE2C ; mov.l r12,@(12,r14)
    c.r[1] = 0x0u;  // 060ABE20 mov #0,r1
L_060ABE22:
    st32(c.r[5], c.r[1]);  // 060ABE22 mov.l r1,@r5
    c.r[10] = ld32(c.r[14] + 12);  // 060ABE24 mov.l @(12,r14),r10
    c.r[5] += 4;  // 060ABE26 add #4,r5
    c.t = c.r[5] >= c.r[10];  // 060ABE28 cmp/hs r10,r5
    if (!c.t) { SH2_POLL(c); goto L_060ABE22; }  // 060ABE2A bf 0x060ABE22
L_060ABE2C:
    c.r[8] += 20;  // 060ABE2C add #20,r8
    st32(c.r[14] + 12, c.r[8]);  // 060ABE2E mov.l r8,@(12,r14)
    c.r[12] = ld32(c.r[14] + 16);  // 060ABE30 mov.l @(16,r14),r12
    c.r[9] += 20;  // 060ABE32 add #20,r9
    c.r[12] <<= 2;  // 060ABE34 shll2 r12
    c.r[12] += c.r[8];  // 060ABE36 add r8,r12
    st32(c.r[14] + 4, c.r[12]);  // 060ABE38 mov.l r12,@(4,r14)
    c.r[13] <<= 2;  // 060ABE3A shll2 r13
    st32(c.r[14] + 8, c.r[13]);  // 060ABE3C mov.l r13,@(8,r14)
    c.r[10] = c.r[13];  // 060ABE3E mov r13,r10
    c.r[10] += c.r[9];  // 060ABE40 add r9,r10
    st32(c.r[14] + 8, c.r[10]);  // 060ABE42 mov.l r10,@(8,r14)
    c.r[12] = ld32(c.r[14]);  // 060ABE44 mov.l @r14,r12
    c.t = c.r[9] >= c.r[10];  // 060ABE46 cmp/hs r10,r9
    c.r[12] += 20;  // 060ABE48 add #20,r12
    { const bool k = c.t; st32(c.r[14] + 16, c.r[12]); if (k) { goto L_060ABEF6; } }  // 060ABE4A bt/s 0x060ABEF6 ; mov.l r12,@(16,r14)
    c.r[13] = ld32(0x060ABF34u);  // 060ABE4E mov.l 0x060ABF34,r13
L_060ABE50:
    c.r[8] = ld32(c.r[9]);  // 060ABE50 mov.l @r9,r8
    c.r[8] &= c.r[13];  // 060ABE52 and r13,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 060ABE54 tst r8,r8
    { const bool k = c.t; c.r[4] = ld32(c.r[14] + 16); if (k) { goto L_060ABE9A; } }  // 060ABE56 bt/s 0x060ABE9A ; mov.l @(16,r14),r4
    c.r[6] = 0x0u;  // 060ABE5A mov #0,r6
    c.r[5] = ld32(c.r[14] + 12);  // 060ABE5C mov.l @(12,r14),r5
    c.r[0] = c.r[4];  // 060ABE5E mov r4,r0
    c.r[0] += 2;  // 060ABE60 add #2,r0
L_060ABE62:
    c.r[3] = ld32(c.r[5]); c.r[5] += 4;  // 060ABE62 mov.l @r5+,r3
    c.r[1] = c.r[3];  // 060ABE64 mov r3,r1
    c.r[1] &= c.r[13];  // 060ABE66 and r13,r1
    c.macl = c.r[1] * c.r[8];  // 060ABE68 mul.l r8,r1
    c.r[2] = ld32(c.r[4]);  // 060ABE6A mov.l @r4,r2
    c.r[7] = c.macl;  // 060ABE6C sts macl,r7
    c.r[1] = c.r[2];  // 060ABE6E mov r2,r1
    c.r[1] &= c.r[13];  // 060ABE70 and r13,r1
    c.r[7] += c.r[1];  // 060ABE72 add r1,r7
    c.r[7] += c.r[6];  // 060ABE74 add r6,r7
    c.r[6] = c.r[7];  // 060ABE76 mov r7,r6
    c.r[6] >>= 16;  // 060ABE78 shlr16 r6
    c.r[3] >>= 16;  // 060ABE7A shlr16 r3
    c.macl = c.r[3] * c.r[8];  // 060ABE7C mul.l r8,r3
    c.r[2] >>= 16;  // 060ABE7E shlr16 r2
    c.r[3] = c.macl;  // 060ABE80 sts macl,r3
    c.r[3] += c.r[2];  // 060ABE82 add r2,r3
    c.r[3] += c.r[6];  // 060ABE84 add r6,r3
    c.r[6] = c.r[3];  // 060ABE86 mov r3,r6
    c.r[6] >>= 16;  // 060ABE88 shlr16 r6
    st16(c.r[4], c.r[3]);  // 060ABE8A mov.w r3,@r4
    st16(c.r[0], c.r[7]);  // 060ABE8C mov.w r7,@r0
    c.r[0] += 4;  // 060ABE8E add #4,r0
    c.r[10] = ld32(c.r[14] + 4);  // 060ABE90 mov.l @(4,r14),r10
    c.t = c.r[5] >= c.r[10];  // 060ABE92 cmp/hs r10,r5
    { const bool k = !c.t; c.r[4] += 4; if (k) { SH2_POLL(c); goto L_060ABE62; } }  // 060ABE94 bf/s 0x060ABE62 ; add #4,r4
    st32(c.r[4], c.r[6]);  // 060ABE98 mov.l r6,@r4
L_060ABE9A:
    c.r[8] = ld32(c.r[9]);  // 060ABE9A mov.l @r9,r8
    c.r[8] >>= 16;  // 060ABE9C shlr16 r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 060ABE9E tst r8,r8
    { const bool k = c.t; c.r[10] = ld32(c.r[14] + 16); if (k) { goto L_060ABEEA; } }  // 060ABEA0 bt/s 0x060ABEEA ; mov.l @(16,r14),r10
    c.r[4] = ld32(c.r[14] + 16);  // 060ABEA4 mov.l @(16,r14),r4
    c.r[6] = 0x0u;  // 060ABEA6 mov #0,r6
    c.r[5] = ld32(c.r[14] + 12);  // 060ABEA8 mov.l @(12,r14),r5
    c.r[2] = c.r[4];  // 060ABEAA mov r4,r2
    c.r[2] += 2;  // 060ABEAC add #2,r2
    c.r[3] = ld32(c.r[4]);  // 060ABEAE mov.l @r4,r3
L_060ABEB0:
    c.r[1] = ld32(c.r[5]);  // 060ABEB0 mov.l @r5,r1
    c.r[1] &= c.r[13];  // 060ABEB2 and r13,r1
    c.macl = c.r[1] * c.r[8];  // 060ABEB4 mul.l r8,r1
    c.r[1] = ld32(c.r[4]);  // 060ABEB6 mov.l @r4,r1
    c.r[7] = c.macl;  // 060ABEB8 sts macl,r7
    c.r[1] >>= 16;  // 060ABEBA shlr16 r1
    c.r[7] += c.r[1];  // 060ABEBC add r1,r7
    c.r[7] += c.r[6];  // 060ABEBE add r6,r7
    c.r[6] = c.r[7];  // 060ABEC0 mov r7,r6
    c.r[6] >>= 16;  // 060ABEC2 shlr16 r6
    st16(c.r[4], c.r[7]);  // 060ABEC4 mov.w r7,@r4
    st16(c.r[2], c.r[3]);  // 060ABEC6 mov.w r3,@r2
    c.r[1] = ld32(c.r[5]); c.r[5] += 4;  // 060ABEC8 mov.l @r5+,r1
    c.r[1] >>= 16;  // 060ABECA shlr16 r1
    c.macl = c.r[1] * c.r[8];  // 060ABECC mul.l r8,r1
    c.r[12] = ld32(c.r[14] + 4);  // 060ABECE mov.l @(4,r14),r12
    c.r[4] += 4;  // 060ABED0 add #4,r4
    c.r[1] = ld32(c.r[4]);  // 060ABED2 mov.l @r4,r1
    c.r[3] = c.macl;  // 060ABED4 sts macl,r3
    c.r[1] &= c.r[13];  // 060ABED6 and r13,r1
    c.r[3] += c.r[1];  // 060ABED8 add r1,r3
    c.r[3] += c.r[6];  // 060ABEDA add r6,r3
    c.r[6] = c.r[3];  // 060ABEDC mov r3,r6
    c.r[6] >>= 16;  // 060ABEDE shlr16 r6
    c.t = c.r[5] >= c.r[12];  // 060ABEE0 cmp/hs r12,r5
    { const bool k = !c.t; c.r[2] += 4; if (k) { SH2_POLL(c); goto L_060ABEB0; } }  // 060ABEE2 bf/s 0x060ABEB0 ; add #4,r2
    st32(c.r[4], c.r[3]);  // 060ABEE6 mov.l r3,@r4
    c.r[10] = ld32(c.r[14] + 16);  // 060ABEE8 mov.l @(16,r14),r10
L_060ABEEA:
    c.r[9] += 4;  // 060ABEEA add #4,r9
    c.r[12] = ld32(c.r[14] + 8);  // 060ABEEC mov.l @(8,r14),r12
    c.r[10] += 4;  // 060ABEEE add #4,r10
    c.t = c.r[9] >= c.r[12];  // 060ABEF0 cmp/hs r12,r9
    { const bool k = !c.t; st32(c.r[14] + 16, c.r[10]); if (k) { SH2_POLL(c); goto L_060ABE50; } }  // 060ABEF2 bf/s 0x060ABE50 ; mov.l r10,@(16,r14)
L_060ABEF6:
    c.r[4] = ld32(c.r[14]);  // 060ABEF6 mov.l @r14,r4
    c.r[1] = c.r[11];  // 060ABEF8 mov r11,r1
    c.r[1] <<= 2;  // 060ABEFA shll2 r1
    c.t = (int32_t)c.r[11] > 0;  // 060ABEFC cmp/pl r11
    c.r[4] += 20;  // 060ABEFE add #20,r4
    c.r[4] += c.r[1];  // 060ABF00 add r1,r4
L_060ABF02:
    { const bool k = !c.t; c.r[4] -= 4; if (k) { goto L_060ABF12; } }  // 060ABF02 bf/s 0x060ABF12 ; add #-4,r4
    c.r[1] = ld32(c.r[4]);  // 060ABF06 mov.l @r4,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060ABF08 tst r1,r1
    if (!c.t) { goto L_060ABF12; }  // 060ABF0A bf 0x060ABF12
    c.r[11] -= 1;  // 060ABF0C add #-1,r11
    c.t = (int32_t)c.r[11] > 0; SH2_POLL(c); goto L_060ABF02;  // 060ABF0E bra 0x060ABF02 ; cmp/pl r11
L_060ABF12:
    c.r[10] = ld32(c.r[14]);  // 060ABF12 mov.l @r14,r10
    c.r[0] = ld32(c.r[14]);  // 060ABF14 mov.l @r14,r0
    st32(c.r[10] + 16, c.r[11]);  // 060ABF16 mov.l r11,@(16,r10)
    c.r[14] += 20;  // 060ABF18 add #20,r14
    c.r[15] = c.r[14];  // 060ABF1A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060ABF1C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060ABF1E mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060ABF20 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060ABF22 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060ABF24 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060ABF26 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060ABF28 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060ABF2A rts ; mov.l @r15+,r8
}

void f_060ABF44(SH2Context& c) {
    ran[2841] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060ABF44 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060ABF46 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060ABF48 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060ABF4A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060ABF4C mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060ABF4E mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060ABF50 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060ABF52 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060ABF54 mov r15,r14
    c.r[12] = c.r[4];  // 060ABF56 mov r4,r12
    c.r[10] = c.r[6];  // 060ABF58 mov r6,r10
    c.r[0] = c.r[10];  // 060ABF5A mov r10,r0
    c.r[0] &= 0x3u;  // 060ABF5C and #3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060ABF5E tst r0,r0
    { const bool k = c.t; c.r[11] = c.r[5]; if (k) { goto L_060ABF72; } }  // 060ABF60 bt/s 0x060ABF72 ; mov r5,r11
    c.r[0] <<= 2;  // 060ABF64 shll2 r0
    c.r[1] = ld32(0x060ABFECu);  // 060ABF66 mov.l 0x060ABFEC,r1
    c.r[6] = ld32(c.r[0] + c.r[1]);  // 060ABF68 mov.l @(r0,r1),r6
    c.r[0] = ld32(0x060ABFF0u);  // 060ABF6A mov.l 0x060ABFF0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060ABF70u; c.r[7] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060ABF70u) return; }  // 060ABF6C jsr @r0 ; mov #0,r7
    c.r[11] = c.r[0];  // 060ABF70 mov r0,r11
L_060ABF72:
    c.t = c.r[10] & 1; c.r[10] = (uint32_t)((int32_t)c.r[10] >> 1);  // 060ABF72 shar r10
    c.t = c.r[10] & 1; c.r[10] = (uint32_t)((int32_t)c.r[10] >> 1);  // 060ABF74 shar r10
    c.t = (c.r[10] & c.r[10]) == 0;  // 060ABF76 tst r10,r10
    { const bool k = c.t; c.r[0] = c.r[11]; if (k) { goto L_060ABFD4; } }  // 060ABF78 bt/s 0x060ABFD4 ; mov r11,r0
    c.r[9] = c.r[12];  // 060ABF7C mov r12,r9
    c.r[9] += 108;  // 060ABF7E add #108,r9
    c.r[8] = ld32(c.r[9]);  // 060ABF80 mov.l @r9,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 060ABF82 tst r8,r8
    { const bool k = !c.t; c.r[13] = c.r[8]; if (k) { goto L_060ABF96; } }  // 060ABF84 bf/s 0x060ABF96 ; mov r8,r13
    c.r[5] = (uint32_t)(int16_t)ld16(0x060ABFE8u);  // 060ABF88 mov.w 0x060ABFE8,r5
    c.r[0] = ld32(0x060ABFF4u);  // 060ABF8A mov.l 0x060ABFF4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060ABF90u; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060ABF90u) return; }  // 060ABF8C jsr @r0 ; mov r12,r4
    st32(c.r[9], c.r[0]);  // 060ABF90 mov.l r0,@r9
    c.r[8] = c.r[0];  // 060ABF92 mov r0,r8
    st32(c.r[8], c.r[13]);  // 060ABF94 mov.l r13,@r8
L_060ABF96:
    c.r[13] = ld32(0x060ABFF8u);  // 060ABF96 mov.l 0x060ABFF8,r13
L_060ABF98:
    c.r[1] = 0x1u;  // 060ABF98 mov #1,r1
    c.r[1] &= c.r[10];  // 060ABF9A and r10,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060ABF9C tst r1,r1
    { const bool k = c.t; c.r[6] = c.r[8]; if (k) { goto L_060ABFB4; } }  // 060ABF9E bt/s 0x060ABFB4 ; mov r8,r6
    c.r[5] = c.r[11];  // 060ABFA2 mov r11,r5
    { const uint32_t x = c.r[13]; c.pr = 0x060ABFA8u; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060ABFA8u) return; }  // 060ABFA4 jsr @r13 ; mov r12,r4
    c.r[9] = c.r[0];  // 060ABFA8 mov r0,r9
    c.r[5] = c.r[11];  // 060ABFAA mov r11,r5
    c.r[2] = ld32(0x060ABFFCu);  // 060ABFAC mov.l 0x060ABFFC,r2
    { const uint32_t x = c.r[2]; c.pr = 0x060ABFB2u; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060ABFB2u) return; }  // 060ABFAE jsr @r2 ; mov r12,r4
    c.r[11] = c.r[9];  // 060ABFB2 mov r9,r11
L_060ABFB4:
    c.t = c.r[10] & 1; c.r[10] = (uint32_t)((int32_t)c.r[10] >> 1);  // 060ABFB4 shar r10
    c.t = (c.r[10] & c.r[10]) == 0;  // 060ABFB6 tst r10,r10
    if (c.t) { goto L_060ABFD2; }  // 060ABFB8 bt 0x060ABFD2
    c.r[0] = ld32(c.r[8]);  // 060ABFBA mov.l @r8,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060ABFBC tst r0,r0
    { const bool k = !c.t; c.r[9] = c.r[0]; if (k) { goto L_060ABFCE; } }  // 060ABFBE bf/s 0x060ABFCE ; mov r0,r9
    c.r[6] = c.r[8];  // 060ABFC2 mov r8,r6
    c.r[5] = c.r[8];  // 060ABFC4 mov r8,r5
    { const uint32_t x = c.r[13]; c.pr = 0x060ABFCAu; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060ABFCAu) return; }  // 060ABFC6 jsr @r13 ; mov r12,r4
    st32(c.r[8], c.r[0]);  // 060ABFCA mov.l r0,@r8
    st32(c.r[0], c.r[9]);  // 060ABFCC mov.l r9,@r0
L_060ABFCE:
    c.r[8] = c.r[0]; SH2_POLL(c); goto L_060ABF98;  // 060ABFCE bra 0x060ABF98 ; mov r0,r8
L_060ABFD2:
    c.r[0] = c.r[11];  // 060ABFD2 mov r11,r0
L_060ABFD4:
    c.r[15] = c.r[14];  // 060ABFD4 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060ABFD6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060ABFD8 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060ABFDA mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060ABFDC mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060ABFDE mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060ABFE0 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060ABFE2 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060ABFE4 rts ; mov.l @r15+,r8
}

void f_060AC000(SH2Context& c) {
    ran[2842] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060AC000 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060AC002 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060AC004 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060AC006 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060AC008 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060AC00A mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060AC00C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060AC00E sts.l pr,@-r15
    c.r[15] -= 16;  // 060AC010 add #-16,r15
    c.r[14] = c.r[15];  // 060AC012 mov r15,r14
    st32(c.r[14], c.r[4]);  // 060AC014 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 060AC016 mov.l r5,@(4,r14)
    c.r[12] = c.r[6];  // 060AC018 mov r6,r12
    c.r[8] = c.r[12];  // 060AC01A mov r12,r8
    c.t = c.r[8] & 1; c.r[8] = (uint32_t)((int32_t)c.r[8] >> 1);  // 060AC01C shar r8
    c.t = c.r[8] & 1; c.r[8] = (uint32_t)((int32_t)c.r[8] >> 1);  // 060AC01E shar r8
    c.t = c.r[8] & 1; c.r[8] = (uint32_t)((int32_t)c.r[8] >> 1);  // 060AC020 shar r8
    c.r[11] = ld32(c.r[5] + 4);  // 060AC022 mov.l @(4,r5),r11
    c.t = c.r[8] & 1; c.r[8] = (uint32_t)((int32_t)c.r[8] >> 1);  // 060AC024 shar r8
    c.r[3] = ld32(c.r[5] + 16);  // 060AC026 mov.l @(16,r5),r3
    c.t = c.r[8] & 1; c.r[8] = (uint32_t)((int32_t)c.r[8] >> 1);  // 060AC028 shar r8
    c.r[1] = ld32(c.r[5] + 8);  // 060AC02A mov.l @(8,r5),r1
    c.r[3] += c.r[8];  // 060AC02C add r8,r3
    c.r[3] += 1;  // 060AC02E add #1,r3
    c.t = (int32_t)c.r[3] > (int32_t)c.r[1];  // 060AC030 cmp/gt r1,r3
    { const bool k = !c.t; st32(c.r[14] + 8, c.r[3]); if (k) { goto L_060AC040; } }  // 060AC032 bf/s 0x060AC040 ; mov.l r3,@(8,r14)
    c.r[7] = ld32(c.r[14] + 8);  // 060AC036 mov.l @(8,r14),r7
L_060AC038:
    c.r[1] += c.r[1];  // 060AC038 add r1,r1
    c.t = (int32_t)c.r[7] > (int32_t)c.r[1];  // 060AC03A cmp/gt r1,r7
    { const bool k = c.t; c.r[11] += 1; if (k) { SH2_POLL(c); goto L_060AC038; } }  // 060AC03C bt/s 0x060AC038 ; add #1,r11
L_060AC040:
    c.r[0] = ld32(0x060AC0D8u);  // 060AC040 mov.l 0x060AC0D8,r0
    c.r[4] = ld32(c.r[14]);  // 060AC042 mov.l @r14,r4
    { const uint32_t x = c.r[0]; c.pr = 0x060AC048u; c.r[5] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AC048u) return; }  // 060AC044 jsr @r0 ; mov r11,r5
    st32(c.r[14] + 12, c.r[0]);  // 060AC048 mov.l r0,@(12,r14)
    c.r[9] = c.r[0];  // 060AC04A mov r0,r9
    c.r[1] = 0x0u;  // 060AC04C mov #0,r1
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[8];  // 060AC04E cmp/ge r8,r1
    { const bool k = c.t; c.r[9] += 20; if (k) { goto L_060AC060; } }  // 060AC050 bt/s 0x060AC060 ; add #20,r9
    c.r[2] = 0x0u;  // 060AC054 mov #0,r2
L_060AC056:
    st32(c.r[9], c.r[2]);  // 060AC056 mov.l r2,@r9
    c.r[1] += 1;  // 060AC058 add #1,r1
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[8];  // 060AC05A cmp/ge r8,r1
    { const bool k = !c.t; c.r[9] += 4; if (k) { SH2_POLL(c); goto L_060AC056; } }  // 060AC05C bf/s 0x060AC056 ; add #4,r9
L_060AC060:
    c.r[8] = ld32(c.r[14] + 4);  // 060AC060 mov.l @(4,r14),r8
    c.r[7] = 0x1Fu;  // 060AC062 mov #31,r7
    c.r[3] = ld32(c.r[14] + 4);  // 060AC064 mov.l @(4,r14),r3
    c.r[12] &= c.r[7];  // 060AC066 and r7,r12
    c.r[13] = ld32(c.r[3] + 16);  // 060AC068 mov.l @(16,r3),r13
    c.r[8] += 20;  // 060AC06A add #20,r8
    c.r[13] <<= 2;  // 060AC06C shll2 r13
    c.t = (c.r[12] & c.r[12]) == 0;  // 060AC06E tst r12,r12
    { const bool k = c.t; c.r[13] += c.r[8]; if (k) { goto L_060AC0A4; } }  // 060AC070 bt/s 0x060AC0A4 ; add r8,r13
    c.r[11] = 0u - c.r[12];  // 060AC074 neg r12,r11
    c.r[11] += 32;  // 060AC076 add #32,r11
    c.r[10] = 0x0u;  // 060AC078 mov #0,r10
L_060AC07A:
    c.r[5] = c.r[12];  // 060AC07A mov r12,r5
    c.r[3] = ld32(0x060AC0DCu);  // 060AC07C mov.l 0x060AC0DC,r3
    { const uint32_t x = c.r[3]; c.pr = 0x060AC082u; c.r[4] = ld32(c.r[8]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AC082u) return; }  // 060AC07E jsr @r3 ; mov.l @r8,r4
    c.r[0] |= c.r[10];  // 060AC082 or r10,r0
    st32(c.r[9], c.r[0]);  // 060AC084 mov.l r0,@r9
    c.r[9] += 4;  // 060AC086 add #4,r9
    c.r[5] = c.r[11];  // 060AC088 mov r11,r5
    c.r[7] = ld32(0x060AC0E0u);  // 060AC08A mov.l 0x060AC0E0,r7
    { const uint32_t x = c.r[7]; c.pr = 0x060AC090u; c.r[4] = ld32(c.r[8]); c.r[8] += 4; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AC090u) return; }  // 060AC08C jsr @r7 ; mov.l @r8+,r4
    c.t = c.r[8] >= c.r[13];  // 060AC090 cmp/hs r13,r8
    { const bool k = !c.t; c.r[10] = c.r[0]; if (k) { SH2_POLL(c); goto L_060AC07A; } }  // 060AC092 bf/s 0x060AC07A ; mov r0,r10
    c.t = (c.r[10] & c.r[10]) == 0;  // 060AC096 tst r10,r10
    { const bool k = c.t; st32(c.r[9], c.r[10]); if (k) { goto L_060AC0AE; } }  // 060AC098 bt/s 0x060AC0AE ; mov.l r10,@r9
    c.r[3] = ld32(c.r[14] + 8);  // 060AC09C mov.l @(8,r14),r3
    c.r[3] += 1;  // 060AC09E add #1,r3
    st32(c.r[14] + 8, c.r[3]); goto L_060AC0AE;  // 060AC0A0 bra 0x060AC0AE ; mov.l r3,@(8,r14)
L_060AC0A4:
    c.r[1] = ld32(c.r[8]); c.r[8] += 4;  // 060AC0A4 mov.l @r8+,r1
    st32(c.r[9], c.r[1]);  // 060AC0A6 mov.l r1,@r9
    c.t = c.r[8] >= c.r[13];  // 060AC0A8 cmp/hs r13,r8
    { const bool k = !c.t; c.r[9] += 4; if (k) { SH2_POLL(c); goto L_060AC0A4; } }  // 060AC0AA bf/s 0x060AC0A4 ; add #4,r9
L_060AC0AE:
    c.r[7] = ld32(c.r[14] + 8);  // 060AC0AE mov.l @(8,r14),r7
    c.r[3] = ld32(c.r[14] + 12);  // 060AC0B0 mov.l @(12,r14),r3
    c.r[5] = ld32(c.r[14] + 4);  // 060AC0B2 mov.l @(4,r14),r5
    c.r[1] = ld32(0x060AC0E4u);  // 060AC0B4 mov.l 0x060AC0E4,r1
    c.r[4] = ld32(c.r[14]);  // 060AC0B6 mov.l @r14,r4
    c.r[7] -= 1;  // 060AC0B8 add #-1,r7
    st32(c.r[14] + 8, c.r[7]);  // 060AC0BA mov.l r7,@(8,r14)
    { const uint32_t x = c.r[1]; c.pr = 0x060AC0C0u; st32(c.r[3] + 16, c.r[7]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AC0C0u) return; }  // 060AC0BC jsr @r1 ; mov.l r7,@(16,r3)
    c.r[0] = ld32(c.r[14] + 12);  // 060AC0C0 mov.l @(12,r14),r0
    c.r[14] += 16;  // 060AC0C2 add #16,r14
    c.r[15] = c.r[14];  // 060AC0C4 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060AC0C6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060AC0C8 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060AC0CA mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060AC0CC mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060AC0CE mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060AC0D0 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060AC0D2 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060AC0D4 rts ; mov.l @r15+,r8
}

void f_060AC0E8(SH2Context& c) {
    ran[2843] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060AC0E8 mov.l r14,@-r15
    c.r[0] = ld32(c.r[4] + 16);  // 060AC0EA mov.l @(16,r4),r0
    c.r[1] = ld32(c.r[5] + 16);  // 060AC0EC mov.l @(16,r5),r1
    c.r[0] -= c.r[1];  // 060AC0EE sub r1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060AC0F0 tst r0,r0
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_060AC120; } }  // 060AC0F2 bf/s 0x060AC120 ; mov r15,r14
    c.r[4] += 20;  // 060AC0F6 add #20,r4
    c.r[1] <<= 2;  // 060AC0F8 shll2 r1
    c.r[3] = c.r[4];  // 060AC0FA mov r4,r3
    c.r[3] += c.r[1];  // 060AC0FC add r1,r3
    c.r[5] += 20;  // 060AC0FE add #20,r5
    c.r[5] += c.r[1];  // 060AC100 add r1,r5
    c.r[3] -= 4;  // 060AC102 add #-4,r3
L_060AC104:
    c.r[2] = ld32(c.r[3]);  // 060AC104 mov.l @r3,r2
    c.r[5] -= 4;  // 060AC106 add #-4,r5
    c.r[1] = ld32(c.r[5]);  // 060AC108 mov.l @r5,r1
    c.t = c.r[2] == c.r[1];  // 060AC10A cmp/eq r1,r2
    { const bool k = c.t; c.t = c.r[3] > c.r[4]; if (k) { goto L_060AC11A; } }  // 060AC10C bt/s 0x060AC11A ; cmp/hi r4,r3
    c.t = c.r[2] >= c.r[1];  // 060AC110 cmp/hs r1,r2
    { const bool k = c.t; c.r[0] = 0x1u; if (k) { goto L_060AC120; } }  // 060AC112 bt/s 0x060AC120 ; mov #1,r0
    c.r[0] = 0xFFFFFFFFu; goto L_060AC120;  // 060AC116 bra 0x060AC120 ; mov #-1,r0
L_060AC11A:
    { const bool k = c.t; c.r[3] -= 4; if (k) { SH2_POLL(c); goto L_060AC104; } }  // 060AC11A bt/s 0x060AC104 ; add #-4,r3
    c.r[0] = 0x0u;  // 060AC11E mov #0,r0
L_060AC120:
    c.r[15] = c.r[14];  // 060AC120 mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060AC122 rts ; mov.l @r15+,r14
}

void f_060AC128(SH2Context& c) {
    ran[2844] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060AC128 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060AC12A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060AC12C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060AC12E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060AC130 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060AC132 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060AC134 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060AC136 sts.l pr,@-r15
    c.r[15] -= 8;  // 060AC138 add #-8,r15
    c.r[14] = c.r[15];  // 060AC13A mov r15,r14
    c.r[12] = c.r[4];  // 060AC13C mov r4,r12
    c.r[9] = c.r[5];  // 060AC13E mov r5,r9
    c.r[11] = c.r[6];  // 060AC140 mov r6,r11
    c.r[0] = ld32(0x060AC22Cu);  // 060AC142 mov.l 0x060AC22C,r0
    c.r[5] = c.r[11];  // 060AC144 mov r11,r5
    { const uint32_t x = c.r[0]; c.pr = 0x060AC14Au; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AC14Au) return; }  // 060AC146 jsr @r0 ; mov r9,r4
    c.r[8] = c.r[0];  // 060AC14A mov r0,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 060AC14C tst r8,r8
    { const bool k = !c.t; c.r[5] = 0x0u; if (k) { goto L_060AC162; } }  // 060AC14E bf/s 0x060AC162 ; mov #0,r5
    c.r[0] = ld32(0x060AC230u);  // 060AC152 mov.l 0x060AC230,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060AC158u; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AC158u) return; }  // 060AC154 jsr @r0 ; mov r12,r4
    c.r[10] = c.r[0];  // 060AC158 mov r0,r10
    c.r[1] = 0x1u;  // 060AC15A mov #1,r1
    st32(c.r[10] + 16, c.r[1]);  // 060AC15C mov.l r1,@(16,r10)
    st32(c.r[10] + 20, c.r[8]); goto L_060AC214;  // 060AC15E bra 0x060AC214 ; mov.l r8,@(20,r10)
L_060AC162:
    c.t = (int32_t)c.r[8] >= 0;  // 060AC162 cmp/pz r8
    { const bool k = c.t; c.r[8] = 0x0u; if (k) { goto L_060AC170; } }  // 060AC164 bt/s 0x060AC170 ; mov #0,r8
    c.r[10] = c.r[9];  // 060AC168 mov r9,r10
    c.r[9] = c.r[11];  // 060AC16A mov r11,r9
    c.r[11] = c.r[10];  // 060AC16C mov r10,r11
    c.r[8] = 0x1u;  // 060AC16E mov #1,r8
L_060AC170:
    c.r[0] = ld32(0x060AC230u);  // 060AC170 mov.l 0x060AC230,r0
    c.r[5] = ld32(c.r[9] + 4);  // 060AC172 mov.l @(4,r9),r5
    { const uint32_t x = c.r[0]; c.pr = 0x060AC178u; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AC178u) return; }  // 060AC174 jsr @r0 ; mov r12,r4
    c.r[10] = c.r[0];  // 060AC178 mov r0,r10
    st32(c.r[10] + 12, c.r[8]);  // 060AC17A mov.l r8,@(12,r10)
    c.r[4] = c.r[9];  // 060AC17C mov r9,r4
    c.r[4] += 20;  // 060AC17E add #20,r4
    c.r[0] = c.r[11];  // 060AC180 mov r11,r0
    c.r[0] += 20;  // 060AC182 add #20,r0
    c.r[5] = c.r[10];  // 060AC184 mov r10,r5
    c.r[5] += 20;  // 060AC186 add #20,r5
    c.r[6] = 0x0u;  // 060AC188 mov #0,r6
    c.r[8] = c.r[10];  // 060AC18A mov r10,r8
    c.r[12] = ld32(c.r[9] + 16);  // 060AC18C mov.l @(16,r9),r12
    c.r[8] += 22;  // 060AC18E add #22,r8
    c.r[13] = c.r[12];  // 060AC190 mov r12,r13
    c.r[13] <<= 2;  // 060AC192 shll2 r13
    c.r[13] += c.r[4];  // 060AC194 add r4,r13
    st32(c.r[14] + 4, c.r[13]);  // 060AC196 mov.l r13,@(4,r14)
    c.r[13] = ld32(c.r[11] + 16);  // 060AC198 mov.l @(16,r11),r13
    c.r[9] = ld32(0x060AC234u);  // 060AC19A mov.l 0x060AC234,r9
    c.r[13] <<= 2;  // 060AC19C shll2 r13
    c.r[13] += c.r[0];  // 060AC19E add r0,r13
    st32(c.r[14], c.r[13]);  // 060AC1A0 mov.l r13,@r14
L_060AC1A2:
    c.r[1] = ld32(c.r[4]); c.r[4] += 4;  // 060AC1A2 mov.l @r4+,r1
    c.r[3] = ld32(c.r[0]); c.r[0] += 4;  // 060AC1A4 mov.l @r0+,r3
    c.r[7] = c.r[1];  // 060AC1A6 mov r1,r7
    c.r[7] &= c.r[9];  // 060AC1A8 and r9,r7
    c.r[2] = c.r[3];  // 060AC1AA mov r3,r2
    c.r[2] &= c.r[9];  // 060AC1AC and r9,r2
    c.r[7] -= c.r[2];  // 060AC1AE sub r2,r7
    c.r[7] += c.r[6];  // 060AC1B0 add r6,r7
    c.r[6] = c.r[7] << 16 | c.r[7] >> 16;  // 060AC1B2 swap.w r7,r6
    c.r[6] = (uint32_t)(int32_t)(int16_t)c.r[6];  // 060AC1B4 exts.w r6,r6
    c.r[1] >>= 16;  // 060AC1B6 shlr16 r1
    c.r[3] >>= 16;  // 060AC1B8 shlr16 r3
    c.r[1] -= c.r[3];  // 060AC1BA sub r3,r1
    c.r[1] += c.r[6];  // 060AC1BC add r6,r1
    c.r[6] = c.r[1] << 16 | c.r[1] >> 16;  // 060AC1BE swap.w r1,r6
    c.r[6] = (uint32_t)(int32_t)(int16_t)c.r[6];  // 060AC1C0 exts.w r6,r6
    st16(c.r[5], c.r[1]);  // 060AC1C2 mov.w r1,@r5
    st16(c.r[8], c.r[7]);  // 060AC1C4 mov.w r7,@r8
    c.r[8] += 4;  // 060AC1C6 add #4,r8
    c.r[13] = ld32(c.r[14]);  // 060AC1C8 mov.l @r14,r13
    c.t = c.r[0] >= c.r[13];  // 060AC1CA cmp/hs r13,r0
    { const bool k = !c.t; c.r[5] += 4; if (k) { SH2_POLL(c); goto L_060AC1A2; } }  // 060AC1CC bf/s 0x060AC1A2 ; add #4,r5
    c.r[13] = ld32(c.r[14] + 4);  // 060AC1D0 mov.l @(4,r14),r13
    c.t = c.r[4] >= c.r[13];  // 060AC1D2 cmp/hs r13,r4
    if (c.t) { goto L_060AC1FE; }  // 060AC1D4 bt 0x060AC1FE
    c.r[2] = c.r[5];  // 060AC1D6 mov r5,r2
    c.r[3] = ld32(0x060AC234u);  // 060AC1D8 mov.l 0x060AC234,r3
    c.r[2] += 2;  // 060AC1DA add #2,r2
L_060AC1DC:
    c.r[1] = ld32(c.r[4]); c.r[4] += 4;  // 060AC1DC mov.l @r4+,r1
    c.r[7] = c.r[1];  // 060AC1DE mov r1,r7
    c.r[7] &= c.r[3];  // 060AC1E0 and r3,r7
    c.r[7] += c.r[6];  // 060AC1E2 add r6,r7
    c.r[6] = c.r[7] << 16 | c.r[7] >> 16;  // 060AC1E4 swap.w r7,r6
    c.r[6] = (uint32_t)(int32_t)(int16_t)c.r[6];  // 060AC1E6 exts.w r6,r6
    c.r[1] >>= 16;  // 060AC1E8 shlr16 r1
    c.r[1] += c.r[6];  // 060AC1EA add r6,r1
    c.r[6] = c.r[1] << 16 | c.r[1] >> 16;  // 060AC1EC swap.w r1,r6
    c.r[6] = (uint32_t)(int32_t)(int16_t)c.r[6];  // 060AC1EE exts.w r6,r6
    st16(c.r[5], c.r[1]);  // 060AC1F0 mov.w r1,@r5
    st16(c.r[2], c.r[7]);  // 060AC1F2 mov.w r7,@r2
    c.r[2] += 4;  // 060AC1F4 add #4,r2
    c.r[13] = ld32(c.r[14] + 4);  // 060AC1F6 mov.l @(4,r14),r13
    c.t = c.r[4] >= c.r[13];  // 060AC1F8 cmp/hs r13,r4
    { const bool k = !c.t; c.r[5] += 4; if (k) { SH2_POLL(c); goto L_060AC1DC; } }  // 060AC1FA bf/s 0x060AC1DC ; add #4,r5
L_060AC1FE:
    c.r[5] -= 4;  // 060AC1FE add #-4,r5
    c.r[1] = ld32(c.r[5]);  // 060AC200 mov.l @r5,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060AC202 tst r1,r1
    if (!c.t) { goto L_060AC210; }  // 060AC204 bf 0x060AC210
L_060AC206:
    c.r[5] -= 4;  // 060AC206 add #-4,r5
    c.r[1] = ld32(c.r[5]);  // 060AC208 mov.l @r5,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060AC20A tst r1,r1
    { const bool k = c.t; c.r[12] -= 1; if (k) { SH2_POLL(c); goto L_060AC206; } }  // 060AC20C bt/s 0x060AC206 ; add #-1,r12
L_060AC210:
    st32(c.r[10] + 16, c.r[12]);  // 060AC210 mov.l r12,@(16,r10)
    c.r[0] = c.r[10];  // 060AC212 mov r10,r0
L_060AC214:
    c.r[14] += 8;  // 060AC214 add #8,r14
    c.r[15] = c.r[14];  // 060AC216 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060AC218 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060AC21A mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060AC21C mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060AC21E mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060AC220 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060AC222 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060AC224 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060AC226 rts ; mov.l @r15+,r8
}

void f_060AC238(SH2Context& c) {
    ran[2845] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060AC238 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060AC23A sts.l pr,@-r15
    c.r[15] -= 16;  // 060AC23C add #-16,r15
    c.r[14] = c.r[15];  // 060AC23E mov r15,r14
    st32(c.r[14], c.r[4]);  // 060AC240 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 060AC242 mov.l r5,@(4,r14)
    c.r[5] = ld32(c.r[14]);  // 060AC244 mov.l @r14,r5
    c.r[1] = ld32(0x060AC2A0u);  // 060AC246 mov.l 0x060AC2A0,r1
    c.r[5] &= c.r[1];  // 060AC248 and r1,r5
    c.r[1] = ld32(0x060AC2A4u);  // 060AC24A mov.l 0x060AC2A4,r1
    c.r[5] += c.r[1];  // 060AC24C add r1,r5
    c.t = (int32_t)c.r[5] > 0;  // 060AC24E cmp/pl r5
    if (!c.t) { goto L_060AC258; }  // 060AC250 bf 0x060AC258
    st32(c.r[14] + 8, c.r[5]);  // 060AC252 mov.l r5,@(8,r14)
    c.r[1] = 0x0u; goto L_060AC290;  // 060AC254 bra 0x060AC290 ; mov #0,r1
L_060AC258:
    c.r[1] = ld32(0x060AC2A8u);  // 060AC258 mov.l 0x060AC2A8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060AC25Eu; c.r[4] = 0u - c.r[5]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AC25Eu) return; }  // 060AC25A jsr @r1 ; neg r5,r4
    c.r[5] = c.r[4];  // 060AC25E mov r4,r5
    c.r[1] = 0x13u;  // 060AC260 mov #19,r1
    c.t = (int32_t)c.r[5] > (int32_t)c.r[1];  // 060AC262 cmp/gt r1,r5
    { const bool k = c.t; c.r[1] = 0x0u; if (k) { goto L_060AC276; } }  // 060AC264 bt/s 0x060AC276 ; mov #0,r1
    c.r[4] = ld32(0x060AC2ACu);  // 060AC268 mov.l 0x060AC2AC,r4
    c.r[0] = ld32(0x060AC2B0u);  // 060AC26A mov.l 0x060AC2B0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060AC270u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AC270u) return; }  // 060AC26C jsr @r0 ; nop
    st32(c.r[14] + 8, c.r[0]);  // 060AC270 mov.l r0,@(8,r14)
    c.r[1] = 0x0u; goto L_060AC290;  // 060AC272 bra 0x060AC290 ; mov #0,r1
L_060AC276:
    st32(c.r[14] + 8, c.r[1]);  // 060AC276 mov.l r1,@(8,r14)
    c.r[5] -= 20;  // 060AC278 add #-20,r5
    c.r[1] = 0x1Eu;  // 060AC27A mov #30,r1
    c.t = (int32_t)c.r[5] > (int32_t)c.r[1];  // 060AC27C cmp/gt r1,r5
    { const bool k = c.t; c.r[1] = 0x1u; if (k) { goto L_060AC290; } }  // 060AC27E bt/s 0x060AC290 ; mov #1,r1
    c.r[5] = 0u - c.r[5];  // 060AC282 neg r5,r5
    c.r[5] += 31;  // 060AC284 add #31,r5
    c.r[0] = ld32(0x060AC2B4u);  // 060AC286 mov.l 0x060AC2B4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060AC28Cu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AC28Cu) return; }  // 060AC288 jsr @r0 ; mov #1,r4
    st32(c.r[14] + 12, c.r[0]); goto L_060AC292;  // 060AC28C bra 0x060AC292 ; mov.l r0,@(12,r14)
L_060AC290:
    st32(c.r[14] + 12, c.r[1]);  // 060AC290 mov.l r1,@(12,r14)
L_060AC292:
    c.r[0] = ld32(c.r[14] + 8);  // 060AC292 mov.l @(8,r14),r0
    c.r[1] = ld32(c.r[14] + 12);  // 060AC294 mov.l @(12,r14),r1
    c.r[14] += 16;  // 060AC296 add #16,r14
    c.r[15] = c.r[14];  // 060AC298 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060AC29A lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060AC29C rts ; mov.l @r15+,r14
}

void f_060AC2B8(SH2Context& c) {
    ran[2846] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060AC2B8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060AC2BA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060AC2BC mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060AC2BE mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060AC2C0 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060AC2C2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060AC2C4 sts.l pr,@-r15
    c.r[15] -= 8;  // 060AC2C6 add #-8,r15
    c.r[14] = c.r[15];  // 060AC2C8 mov r15,r14
    c.r[8] = c.r[5];  // 060AC2CA mov r5,r8
    c.r[12] = c.r[4];  // 060AC2CC mov r4,r12
    c.r[9] = ld32(c.r[4] + 16);  // 060AC2CE mov.l @(16,r4),r9
    c.r[12] += 20;  // 060AC2D0 add #20,r12
    c.r[9] <<= 2;  // 060AC2D2 shll2 r9
    c.r[9] += c.r[12];  // 060AC2D4 add r12,r9
    c.r[9] -= 4;  // 060AC2D6 add #-4,r9
    c.r[11] = ld32(c.r[9]);  // 060AC2D8 mov.l @r9,r11
    c.r[0] = ld32(0x060AC398u);  // 060AC2DA mov.l 0x060AC398,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060AC2E0u; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AC2E0u) return; }  // 060AC2DC jsr @r0 ; mov r11,r4
    c.r[10] = c.r[0];  // 060AC2E0 mov r0,r10
    c.r[1] = 0u - c.r[10];  // 060AC2E2 neg r10,r1
    c.r[1] += 32;  // 060AC2E4 add #32,r1
    st32(c.r[8], c.r[1]);  // 060AC2E6 mov.l r1,@r8
    c.r[1] = 0xAu;  // 060AC2E8 mov #10,r1
    c.t = (int32_t)c.r[10] > (int32_t)c.r[1];  // 060AC2EA cmp/gt r1,r10
    { const bool k = c.t; c.t = c.r[9] > c.r[12]; if (k) { goto L_060AC326; } }  // 060AC2EC bt/s 0x060AC326 ; cmp/hi r12,r9
    c.r[5] = 0u - c.r[10];  // 060AC2F0 neg r10,r5
    c.r[5] += 11;  // 060AC2F2 add #11,r5
    c.r[0] = ld32(0x060AC39Cu);  // 060AC2F4 mov.l 0x060AC39C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060AC2FAu; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AC2FAu) return; }  // 060AC2F6 jsr @r0 ; mov r11,r4
    c.r[1] = ld32(0x060AC3A0u);  // 060AC2FA mov.l 0x060AC3A0,r1
    c.r[0] |= c.r[1];  // 060AC2FC or r1,r0
    c.t = c.r[9] > c.r[12];  // 060AC2FE cmp/hi r12,r9
    { const bool k = !c.t; st32(c.r[14], c.r[0]); if (k) { goto L_060AC30A; } }  // 060AC300 bf/s 0x060AC30A ; mov.l r0,@r14
    c.r[9] -= 4;  // 060AC304 add #-4,r9
    c.r[9] = ld32(c.r[9]); goto L_060AC30C;  // 060AC306 bra 0x060AC30C ; mov.l @r9,r9
L_060AC30A:
    c.r[9] = 0x0u;  // 060AC30A mov #0,r9
L_060AC30C:
    c.r[5] = c.r[10];  // 060AC30C mov r10,r5
    c.r[5] += 21;  // 060AC30E add #21,r5
    c.r[0] = ld32(0x060AC3A4u);  // 060AC310 mov.l 0x060AC3A4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060AC316u; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AC316u) return; }  // 060AC312 jsr @r0 ; mov r11,r4
    c.r[8] = c.r[0];  // 060AC316 mov r0,r8
    c.r[5] = 0u - c.r[10];  // 060AC318 neg r10,r5
    c.r[5] += 11;  // 060AC31A add #11,r5
    c.r[0] = ld32(0x060AC39Cu);  // 060AC31C mov.l 0x060AC39C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060AC322u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AC322u) return; }  // 060AC31E jsr @r0 ; mov r9,r4
    c.r[8] |= c.r[0]; goto L_060AC37C;  // 060AC322 bra 0x060AC37C ; or r0,r8
L_060AC326:
    if (!c.t) { goto L_060AC32E; }  // 060AC326 bf 0x060AC32E
    c.r[9] -= 4;  // 060AC328 add #-4,r9
    c.r[8] = ld32(c.r[9]); goto L_060AC330;  // 060AC32A bra 0x060AC330 ; mov.l @r9,r8
L_060AC32E:
    c.r[8] = 0x0u;  // 060AC32E mov #0,r8
L_060AC330:
    c.r[10] -= 11;  // 060AC330 add #-11,r10
    c.t = (c.r[10] & c.r[10]) == 0;  // 060AC332 tst r10,r10
    { const bool k = c.t; c.r[5] = c.r[10]; if (k) { goto L_060AC376; } }  // 060AC334 bt/s 0x060AC376 ; mov r10,r5
    c.r[0] = ld32(0x060AC3A4u);  // 060AC338 mov.l 0x060AC3A4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060AC33Eu; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AC33Eu) return; }  // 060AC33A jsr @r0 ; mov r11,r4
    c.r[11] = c.r[0];  // 060AC33E mov r0,r11
    c.r[5] = 0u - c.r[10];  // 060AC340 neg r10,r5
    c.r[5] += 32;  // 060AC342 add #32,r5
    c.r[0] = ld32(0x060AC39Cu);  // 060AC344 mov.l 0x060AC39C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060AC34Au; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AC34Au) return; }  // 060AC346 jsr @r0 ; mov r8,r4
    c.r[1] = ld32(0x060AC3A0u);  // 060AC34A mov.l 0x060AC3A0,r1
    c.r[0] |= c.r[1];  // 060AC34C or r1,r0
    c.r[11] |= c.r[0];  // 060AC34E or r0,r11
    c.t = c.r[9] > c.r[12];  // 060AC350 cmp/hi r12,r9
    { const bool k = !c.t; st32(c.r[14], c.r[11]); if (k) { goto L_060AC35C; } }  // 060AC352 bf/s 0x060AC35C ; mov.l r11,@r14
    c.r[9] -= 4;  // 060AC356 add #-4,r9
    c.r[11] = ld32(c.r[9]); goto L_060AC35E;  // 060AC358 bra 0x060AC35E ; mov.l @r9,r11
L_060AC35C:
    c.r[11] = 0x0u;  // 060AC35C mov #0,r11
L_060AC35E:
    c.r[0] = ld32(0x060AC3A4u);  // 060AC35E mov.l 0x060AC3A4,r0
    c.r[5] = c.r[10];  // 060AC360 mov r10,r5
    { const uint32_t x = c.r[0]; c.pr = 0x060AC366u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AC366u) return; }  // 060AC362 jsr @r0 ; mov r8,r4
    c.r[8] = c.r[0];  // 060AC366 mov r0,r8
    c.r[5] = 0u - c.r[10];  // 060AC368 neg r10,r5
    c.r[5] += 32;  // 060AC36A add #32,r5
    c.r[0] = ld32(0x060AC39Cu);  // 060AC36C mov.l 0x060AC39C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060AC372u; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AC372u) return; }  // 060AC36E jsr @r0 ; mov r11,r4
    c.r[8] |= c.r[0]; goto L_060AC37C;  // 060AC372 bra 0x060AC37C ; or r0,r8
L_060AC376:
    c.r[1] = ld32(0x060AC3A0u);  // 060AC376 mov.l 0x060AC3A0,r1
    c.r[11] |= c.r[1];  // 060AC378 or r1,r11
    st32(c.r[14], c.r[11]);  // 060AC37A mov.l r11,@r14
L_060AC37C:
    st32(c.r[14] + 4, c.r[8]);  // 060AC37C mov.l r8,@(4,r14)
    c.r[0] = ld32(c.r[14]);  // 060AC37E mov.l @r14,r0
    c.r[1] = ld32(c.r[14] + 4);  // 060AC380 mov.l @(4,r14),r1
    c.r[14] += 8;  // 060AC382 add #8,r14
    c.r[15] = c.r[14];  // 060AC384 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060AC386 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060AC388 mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060AC38A mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060AC38C mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060AC38E mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060AC390 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060AC392 rts ; mov.l @r15+,r8
}

void f_060AC3A8(SH2Context& c) {
    ran[2847] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060AC3A8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060AC3AA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060AC3AC mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060AC3AE mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060AC3B0 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060AC3B2 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060AC3B4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060AC3B6 sts.l pr,@-r15
    c.r[15] -= 16;  // 060AC3B8 add #-16,r15
    c.r[14] = c.r[15];  // 060AC3BA mov r15,r14
    st32(c.r[14], c.r[5]);  // 060AC3BC mov.l r5,@r14
    st32(c.r[14] + 4, c.r[6]);  // 060AC3BE mov.l r6,@(4,r14)
    c.r[13] = c.r[7];  // 060AC3C0 mov r7,r13
    c.r[0] = ld32(0x060AC49Cu);  // 060AC3C2 mov.l 0x060AC49C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060AC3C8u; c.r[5] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AC3C8u) return; }  // 060AC3C4 jsr @r0 ; mov #1,r5
    c.r[10] = c.r[0];  // 060AC3C8 mov r0,r10
    c.r[12] = c.r[10];  // 060AC3CA mov r10,r12
    c.r[12] += 20;  // 060AC3CC add #20,r12
    c.r[2] = ld32(c.r[14]);  // 060AC3CE mov.l @r14,r2
    c.r[7] = ld32(0x060AC4A0u);  // 060AC3D0 mov.l 0x060AC4A0,r7
    c.r[1] = ld32(0x060AC4A4u);  // 060AC3D2 mov.l 0x060AC4A4,r1
    c.r[7] &= c.r[2];  // 060AC3D4 and r2,r7
    st32(c.r[14] + 12, c.r[7]);  // 060AC3D6 mov.l r7,@(12,r14)
    c.r[1] &= c.r[2];  // 060AC3D8 and r2,r1
    c.r[11] = c.r[1];  // 060AC3DA mov r1,r11
    c.r[11] >>= 16;  // 060AC3DC shlr16 r11
    c.r[11] >>= 2;  // 060AC3DE shlr2 r11
    c.r[11] >>= 2;  // 060AC3E0 shlr2 r11
    c.t = (c.r[11] & c.r[11]) == 0;  // 060AC3E2 tst r11,r11
    { const bool k = c.t; st32(c.r[14], c.r[1]); if (k) { goto L_060AC3EE; } }  // 060AC3E4 bt/s 0x060AC3EE ; mov.l r1,@r14
    c.r[1] = ld32(0x060AC4A8u);  // 060AC3E8 mov.l 0x060AC4A8,r1
    c.r[7] |= c.r[1];  // 060AC3EA or r1,r7
    st32(c.r[14] + 12, c.r[7]);  // 060AC3EC mov.l r7,@(12,r14)
L_060AC3EE:
    c.r[1] = ld32(c.r[14] + 4);  // 060AC3EE mov.l @(4,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060AC3F0 tst r1,r1
    { const bool k = c.t; st32(c.r[14] + 8, c.r[1]); if (k) { goto L_060AC432; } }  // 060AC3F2 bt/s 0x060AC432 ; mov.l r1,@(8,r14)
    c.r[4] = c.r[14];  // 060AC3F6 mov r14,r4
    c.r[0] = ld32(0x060AC4ACu);  // 060AC3F8 mov.l 0x060AC4AC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060AC3FEu; c.r[4] += 8; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AC3FEu) return; }  // 060AC3FA jsr @r0 ; add #8,r4
    c.r[8] = c.r[0];  // 060AC3FE mov r0,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 060AC400 tst r8,r8
    { const bool k = c.t; c.r[5] = 0u - c.r[8]; if (k) { goto L_060AC420; } }  // 060AC402 bt/s 0x060AC420 ; neg r8,r5
    c.r[5] += 32;  // 060AC406 add #32,r5
    c.r[0] = ld32(0x060AC4B0u);  // 060AC408 mov.l 0x060AC4B0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060AC40Eu; c.r[4] = ld32(c.r[14] + 12); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AC40Eu) return; }  // 060AC40A jsr @r0 ; mov.l @(12,r14),r4
    c.r[1] = ld32(c.r[14] + 8);  // 060AC40E mov.l @(8,r14),r1
    c.r[5] = c.r[8];  // 060AC410 mov r8,r5
    c.r[1] |= c.r[0];  // 060AC412 or r0,r1
    st32(c.r[10] + 20, c.r[1]);  // 060AC414 mov.l r1,@(20,r10)
    c.r[0] = ld32(0x060AC4B4u);  // 060AC416 mov.l 0x060AC4B4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060AC41Cu; c.r[4] = ld32(c.r[14] + 12); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AC41Cu) return; }  // 060AC418 jsr @r0 ; mov.l @(12,r14),r4
    st32(c.r[14] + 12, c.r[0]); goto L_060AC424;  // 060AC41C bra 0x060AC424 ; mov.l r0,@(12,r14)
L_060AC420:
    c.r[1] = ld32(c.r[14] + 8);  // 060AC420 mov.l @(8,r14),r1
    st32(c.r[10] + 20, c.r[1]);  // 060AC422 mov.l r1,@(20,r10)
L_060AC424:
    c.r[1] = ld32(c.r[14] + 12);  // 060AC424 mov.l @(12,r14),r1
    st32(c.r[12] + 4, c.r[1]);  // 060AC426 mov.l r1,@(4,r12)
    c.t = (c.r[1] & c.r[1]) == 0;  // 060AC428 tst r1,r1
    { const bool k = c.t; c.r[1] = 0x1u; if (k) { goto L_060AC444; } }  // 060AC42A bt/s 0x060AC444 ; mov #1,r1
    c.r[1] = 0x2u; goto L_060AC444;  // 060AC42E bra 0x060AC444 ; mov #2,r1
L_060AC432:
    c.r[4] = c.r[14];  // 060AC432 mov r14,r4
    c.r[0] = ld32(0x060AC4ACu);  // 060AC434 mov.l 0x060AC4AC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060AC43Au; c.r[4] += 12; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AC43Au) return; }  // 060AC436 jsr @r0 ; add #12,r4
    c.r[8] = c.r[0];  // 060AC43A mov r0,r8
    c.r[1] = ld32(c.r[14] + 12);  // 060AC43C mov.l @(12,r14),r1
    c.r[8] += 32;  // 060AC43E add #32,r8
    st32(c.r[10] + 20, c.r[1]);  // 060AC440 mov.l r1,@(20,r10)
    c.r[1] = 0x1u;  // 060AC442 mov #1,r1
L_060AC444:
    st32(c.r[10] + 16, c.r[1]);  // 060AC444 mov.l r1,@(16,r10)
    c.t = (c.r[11] & c.r[11]) == 0;  // 060AC446 tst r11,r11
    { const bool k = c.t; c.r[9] = c.r[1]; if (k) { goto L_060AC45E; } }  // 060AC448 bt/s 0x060AC45E ; mov r1,r9
    c.r[1] = (uint32_t)(int16_t)ld16(0x060AC496u);  // 060AC44C mov.w 0x060AC496,r1
    c.r[1] += c.r[8];  // 060AC44E add r8,r1
    c.r[11] += c.r[1];  // 060AC450 add r1,r11
    st32(c.r[13], c.r[11]);  // 060AC452 mov.l r11,@r13
    c.r[1] = 0u - c.r[8];  // 060AC454 neg r8,r1
    c.r[3] = ld32(c.r[14] + 48);  // 060AC456 mov.l @(48,r14),r3
    c.r[1] += 53;  // 060AC458 add #53,r1
    st32(c.r[3], c.r[1]); goto L_060AC47E;  // 060AC45A bra 0x060AC47E ; mov.l r1,@r3
L_060AC45E:
    c.r[1] = (uint32_t)(int16_t)ld16(0x060AC498u);  // 060AC45E mov.w 0x060AC498,r1
    c.r[8] += c.r[1];  // 060AC460 add r1,r8
    st32(c.r[13], c.r[8]);  // 060AC462 mov.l r8,@r13
    c.r[1] = c.r[9];  // 060AC464 mov r9,r1
    c.r[1] <<= 2;  // 060AC466 shll2 r1
    c.r[1] += c.r[12];  // 060AC468 add r12,r1
    c.r[1] -= 4;  // 060AC46A add #-4,r1
    c.r[0] = ld32(0x060AC4B8u);  // 060AC46C mov.l 0x060AC4B8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060AC472u; c.r[4] = ld32(c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AC472u) return; }  // 060AC46E jsr @r0 ; mov.l @r1,r4
    c.r[9] <<= 2;  // 060AC472 shll2 r9
    c.r[9] += c.r[9];  // 060AC474 add r9,r9
    c.r[9] <<= 2;  // 060AC476 shll2 r9
    c.r[3] = ld32(c.r[14] + 48);  // 060AC478 mov.l @(48,r14),r3
    c.r[9] -= c.r[0];  // 060AC47A sub r0,r9
    st32(c.r[3], c.r[9]);  // 060AC47C mov.l r9,@r3
L_060AC47E:
    c.r[14] += 16;  // 060AC47E add #16,r14
    c.r[15] = c.r[14];  // 060AC480 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060AC482 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060AC484 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060AC486 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060AC488 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060AC48A mov.l @r15+,r11
    c.r[0] = c.r[10];  // 060AC48C mov r10,r0
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060AC48E mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060AC490 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060AC492 rts ; mov.l @r15+,r8
}

void f_060AC4BC(SH2Context& c) {
    ran[2848] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060AC4BC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060AC4BE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060AC4C0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060AC4C2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060AC4C4 sts.l pr,@-r15
    c.r[15] -= 24;  // 060AC4C6 add #-24,r15
    c.r[14] = c.r[15];  // 060AC4C8 mov r15,r14
    c.r[9] = c.r[4];  // 060AC4CA mov r4,r9
    c.r[10] = c.r[5];  // 060AC4CC mov r5,r10
    c.r[8] = ld32(0x060AC534u);  // 060AC4CE mov.l 0x060AC534,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060AC4D4u; c.r[5] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AC4D4u) return; }  // 060AC4D0 jsr @r8 ; mov r14,r5
    st32(c.r[14] + 8, c.r[0]);  // 060AC4D4 mov.l r0,@(8,r14)
    st32(c.r[14] + 12, c.r[1]);  // 060AC4D6 mov.l r1,@(12,r14)
    c.r[5] = c.r[14];  // 060AC4D8 mov r14,r5
    c.r[5] += 4;  // 060AC4DA add #4,r5
    { const uint32_t x = c.r[8]; c.pr = 0x060AC4E0u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AC4E0u) return; }  // 060AC4DC jsr @r8 ; mov r10,r4
    c.r[3] = ld32(c.r[14]);  // 060AC4E0 mov.l @r14,r3
    st32(c.r[14] + 16, c.r[0]);  // 060AC4E2 mov.l r0,@(16,r14)
    st32(c.r[14] + 20, c.r[1]);  // 060AC4E4 mov.l r1,@(20,r14)
    c.r[1] = ld32(c.r[14] + 4);  // 060AC4E6 mov.l @(4,r14),r1
    c.r[2] = ld32(c.r[9] + 16);  // 060AC4E8 mov.l @(16,r9),r2
    c.r[3] -= c.r[1];  // 060AC4EA sub r1,r3
    c.r[1] = ld32(c.r[10] + 16);  // 060AC4EC mov.l @(16,r10),r1
    c.r[2] -= c.r[1];  // 060AC4EE sub r1,r2
    c.r[2] <<= 2;  // 060AC4F0 shll2 r2
    c.r[2] += c.r[2];  // 060AC4F2 add r2,r2
    c.r[2] <<= 2;  // 060AC4F4 shll2 r2
    c.r[3] += c.r[2];  // 060AC4F6 add r2,r3
    c.t = (int32_t)c.r[3] > 0;  // 060AC4F8 cmp/pl r3
    { const bool k = !c.t; c.r[1] = ld32(c.r[14] + 8); if (k) { goto L_060AC50A; } }  // 060AC4FA bf/s 0x060AC50A ; mov.l @(8,r14),r1
    c.r[3] <<= 16;  // 060AC4FE shll16 r3
    c.r[3] <<= 2;  // 060AC500 shll2 r3
    c.r[3] <<= 2;  // 060AC502 shll2 r3
    c.r[1] += c.r[3];  // 060AC504 add r3,r1
    st32(c.r[14] + 8, c.r[1]); goto L_060AC516;  // 060AC506 bra 0x060AC516 ; mov.l r1,@(8,r14)
L_060AC50A:
    c.r[1] = ld32(c.r[14] + 16);  // 060AC50A mov.l @(16,r14),r1
    c.r[3] <<= 16;  // 060AC50C shll16 r3
    c.r[3] <<= 2;  // 060AC50E shll2 r3
    c.r[3] <<= 2;  // 060AC510 shll2 r3
    c.r[1] -= c.r[3];  // 060AC512 sub r3,r1
    st32(c.r[14] + 16, c.r[1]);  // 060AC514 mov.l r1,@(16,r14)
L_060AC516:
    c.r[4] = ld32(c.r[14] + 8);  // 060AC516 mov.l @(8,r14),r4
    c.r[5] = ld32(c.r[14] + 12);  // 060AC518 mov.l @(12,r14),r5
    c.r[6] = ld32(c.r[14] + 16);  // 060AC51A mov.l @(16,r14),r6
    c.r[1] = ld32(0x060AC538u);  // 060AC51C mov.l 0x060AC538,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060AC522u; c.r[7] = ld32(c.r[14] + 20); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AC522u) return; }  // 060AC51E jsr @r1 ; mov.l @(20,r14),r7
    c.r[14] += 24;  // 060AC522 add #24,r14
    c.r[15] = c.r[14];  // 060AC524 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060AC526 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060AC528 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060AC52A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060AC52C mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060AC52E rts ; mov.l @r15+,r8
}

void f_060AC664(SH2Context& c) {
    ran[2849] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060AC664 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060AC666 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060AC668 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060AC66A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060AC66C sts.l pr,@-r15
    c.r[8] = c.r[4];  // 060AC66E mov r4,r8
    c.r[1] = ld32(0x060AC6B8u);  // 060AC670 mov.l 0x060AC6B8,r1
    c.r[4] = ld32(c.r[1]);  // 060AC672 mov.l @r1,r4
    c.r[5] = ld32(c.r[1] + 4);  // 060AC674 mov.l @(4,r1),r5
    c.r[1] = 0x17u;  // 060AC676 mov #23,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 060AC678 cmp/gt r1,r8
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_060AC68C; } }  // 060AC67A bt/s 0x060AC68C ; mov r15,r14
    c.r[8] <<= 2;  // 060AC67E shll2 r8
    c.r[8] += c.r[8];  // 060AC680 add r8,r8
    c.r[1] = ld32(0x060AC6BCu);  // 060AC682 mov.l 0x060AC6BC,r1
    c.r[8] += c.r[1];  // 060AC684 add r1,r8
    c.r[0] = ld32(c.r[8]);  // 060AC686 mov.l @r8,r0
    c.r[1] = ld32(c.r[8] + 4); goto L_060AC6AA;  // 060AC688 bra 0x060AC6AA ; mov.l @(4,r8),r1
L_060AC68C:
    c.t = (int32_t)c.r[8] > 0;  // 060AC68C cmp/pl r8
    { const bool k = !c.t; c.r[0] = c.r[4]; if (k) { goto L_060AC6A8; } }  // 060AC68E bf/s 0x060AC6A8 ; mov r4,r0
    c.r[10] = ld32(0x060AC6C0u);  // 060AC692 mov.l 0x060AC6C0,r10
    c.r[9] = ld32(0x060AC6C4u);  // 060AC694 mov.l 0x060AC6C4,r9
L_060AC696:
    c.r[6] = ld32(c.r[10]);  // 060AC696 mov.l @r10,r6
    { const uint32_t x = c.r[9]; c.pr = 0x060AC69Cu; c.r[7] = ld32(c.r[10] + 4); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AC69Cu) return; }  // 060AC698 jsr @r9 ; mov.l @(4,r10),r7
    c.r[4] = c.r[0];  // 060AC69C mov r0,r4
    c.r[8] -= 1;  // 060AC69E add #-1,r8
    c.t = (int32_t)c.r[8] > 0;  // 060AC6A0 cmp/pl r8
    { const bool k = c.t; c.r[5] = c.r[1]; if (k) { SH2_POLL(c); goto L_060AC696; } }  // 060AC6A2 bt/s 0x060AC696 ; mov r1,r5
    c.r[0] = c.r[4];  // 060AC6A6 mov r4,r0
L_060AC6A8:
    c.r[1] = c.r[5];  // 060AC6A8 mov r5,r1
L_060AC6AA:
    c.r[15] = c.r[14];  // 060AC6AA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060AC6AC lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060AC6AE mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060AC6B0 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060AC6B2 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060AC6B4 rts ; mov.l @r15+,r8
}

void f_060AC6C8(SH2Context& c) {
    ran[2850] = 1;
    sh2_trapa(c, 34, 0x060AC6CAu);  // 060AC6C8 trapa #34
    c.t = (c.r[1] & c.r[1]) == 0;  // 060AC6CA tst r1,r1
    if (c.t) { goto L_060AC6D2; }  // 060AC6CC bt 0x060AC6D2
    c.r[2] = ld32(0x060AC6D8u);  // 060AC6CE mov.l 0x060AC6D8,r2
    st32(c.r[2], c.r[1]);  // 060AC6D0 mov.l r1,@r2
L_060AC6D2:
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060AC6D2 rts ; nop
}

void f_060AC6DC(SH2Context& c) {
    ran[2851] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060AC6DC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060AC6DE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060AC6E0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060AC6E2 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060AC6E4 mov r15,r14
    c.r[9] = ld32(0x060AC6F8u);  // 060AC6E6 mov.l 0x060AC6F8,r9
    c.r[8] = ld32(0x060AC6FCu);  // 060AC6E8 mov.l 0x060AC6FC,r8
L_060AC6EA:
    { const uint32_t x = c.r[9]; c.pr = 0x060AC6EEu; c.r[4] = 0x6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AC6EEu) return; }  // 060AC6EA jsr @r9 ; mov #6,r4
    { const uint32_t x = c.r[8]; c.pr = 0x060AC6F2u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AC6F2u) return; }  // 060AC6EE jsr @r8 ; mov #1,r4
    SH2_POLL(c); goto L_060AC6EA;  // 060AC6F2 bra 0x060AC6EA ; nop
}

void f_060AC700(SH2Context& c) {
    ran[2852] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060AC700 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060AC702 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060AC704 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060AC706 sts.l pr,@-r15
    c.r[9] = c.r[5];  // 060AC708 mov r5,r9
    c.macl = c.r[9] * c.r[6];  // 060AC70A mul.l r6,r9
    c.r[14] = c.r[15];  // 060AC70C mov r15,r14
    c.r[0] = ld32(0x060AC738u);  // 060AC70E mov.l 0x060AC738,r0
    c.r[9] = c.macl;  // 060AC710 sts macl,r9
    { const uint32_t x = c.r[0]; c.pr = 0x060AC716u; c.r[5] = c.macl; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AC716u) return; }  // 060AC712 jsr @r0 ; sts macl,r5
    c.r[8] = c.r[0];  // 060AC716 mov r0,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 060AC718 tst r8,r8
    { const bool k = c.t; c.r[6] = c.r[9]; if (k) { goto L_060AC72A; } }  // 060AC71A bt/s 0x060AC72A ; mov r9,r6
    c.r[0] = ld32(0x060AC73Cu);  // 060AC71E mov.l 0x060AC73C,r0
    c.r[5] = 0x0u;  // 060AC720 mov #0,r5
    { const uint32_t x = c.r[0]; c.pr = 0x060AC726u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AC726u) return; }  // 060AC722 jsr @r0 ; mov r8,r4
    c.r[0] = c.r[8]; goto L_060AC72C;  // 060AC726 bra 0x060AC72C ; mov r8,r0
L_060AC72A:
    c.r[0] = 0x0u;  // 060AC72A mov #0,r0
L_060AC72C:
    c.r[15] = c.r[14];  // 060AC72C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060AC72E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060AC730 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060AC732 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060AC734 rts ; mov.l @r15+,r8
}

void f_060AC740(SH2Context& c) {
    ran[2853] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060AC740 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060AC742 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060AC744 mov r15,r14
    c.r[5] = c.r[4];  // 060AC746 mov r4,r5
    c.r[1] = ld32(0x060AC758u);  // 060AC748 mov.l 0x060AC758,r1
    c.r[0] = ld32(0x060AC75Cu);  // 060AC74A mov.l 0x060AC75C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060AC750u; c.r[4] = ld32(c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AC750u) return; }  // 060AC74C jsr @r0 ; mov.l @r1,r4
    c.r[15] = c.r[14];  // 060AC750 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060AC752 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060AC754 rts ; mov.l @r15+,r14
}

void f_060AC760(SH2Context& c) {
    ran[2854] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060AC760 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060AC762 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060AC764 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060AC766 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060AC768 mov r15,r14
    c.r[8] = c.r[4];  // 060AC76A mov r4,r8
    c.r[0] = ld32(0x060AC78Cu);  // 060AC76C mov.l 0x060AC78C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060AC772u; c.r[9] = c.r[5]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AC772u) return; }  // 060AC76E jsr @r0 ; mov r5,r9
    c.r[1] = c.r[0];  // 060AC772 mov r0,r1
    c.r[0] = ld32(0x060AC790u);  // 060AC774 mov.l 0x060AC790,r0
    c.r[6] = c.r[9];  // 060AC776 mov r9,r6
    c.r[5] = c.r[1];  // 060AC778 mov r1,r5
    { const uint32_t x = c.r[0]; c.pr = 0x060AC77Eu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AC77Eu) return; }  // 060AC77A jsr @r0 ; mov r8,r4
    c.r[15] = c.r[14];  // 060AC77E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060AC780 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060AC782 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060AC784 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060AC786 rts ; mov.l @r15+,r8
}

void f_060AC794(SH2Context& c) {
    ran[2855] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060AC794 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060AC796 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060AC798 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060AC79A sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060AC79C mov r15,r14
    c.r[9] = c.r[4];  // 060AC79E mov r4,r9
    c.r[4] = c.r[5];  // 060AC7A0 mov r5,r4
    c.r[8] = ld32(0x060AC7C4u);  // 060AC7A2 mov.l 0x060AC7C4,r8
    c.r[1] = 0x0u;  // 060AC7A4 mov #0,r1
    st32(c.r[8], c.r[1]);  // 060AC7A6 mov.l r1,@r8
    c.r[0] = ld32(0x060AC7C8u);  // 060AC7A8 mov.l 0x060AC7C8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060AC7AEu; c.r[5] = c.r[6]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AC7AEu) return; }  // 060AC7AA jsr @r0 ; mov r6,r5
    c.r[8] = ld32(c.r[8]);  // 060AC7AE mov.l @r8,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 060AC7B0 tst r8,r8
    if (c.t) { goto L_060AC7B6; }  // 060AC7B2 bt 0x060AC7B6
    st32(c.r[9], c.r[8]);  // 060AC7B4 mov.l r8,@r9
L_060AC7B6:
    c.r[15] = c.r[14];  // 060AC7B6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060AC7B8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060AC7BA mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060AC7BC mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060AC7BE rts ; mov.l @r15+,r8
}

void f_060AC7CC(SH2Context& c) {
    ran[2856] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060AC7CC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060AC7CE sts.l pr,@-r15
    c.r[0] = ld32(0x060AC7E0u);  // 060AC7D0 mov.l 0x060AC7E0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060AC7D6u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AC7D6u) return; }  // 060AC7D2 jsr @r0 ; mov r15,r14
    c.r[15] = c.r[14];  // 060AC7D6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060AC7D8 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060AC7DA rts ; mov.l @r15+,r14
}

void f_060AC800(SH2Context& c) {
    ran[2857] = 1;
    c.t = (c.r[4] & c.r[4]) == 0;  // 060AC800 tst r4,r4
    { const bool k = !c.t; c.r[0] = c.r[4]; if (k) { goto L_060AC808; } }  // 060AC802 bf/s 0x060AC808 ; mov r4,r0
    c.r[0] = 0x060AC80Cu;  // 060AC806 mova 0x060AC80C,r0
L_060AC808:
    { const uint32_t x = c.pr; st32(c.gbr + 20, c.r[0]); c.pc = x; return; }  // 060AC808 rts ; mov.l r0,@(20,gbr)
}

void f_060AC80C(SH2Context& c) {
    ran[2858] = 1;
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060AC80C rts ; nop
}

void f_060AC810(SH2Context& c) {
    ran[2859] = 1;
    c.r[2] = ld32(0x060AC948u);  // 060AC810 mov.l 0x060AC948,r2
L_060AC812:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[2]);  // 060AC812 mov.w @r2,r0
    c.t = (c.r[0] & 0x2u) == 0;  // 060AC814 tst #2,r0
    if (c.t) { SH2_POLL(c); goto L_060AC812; }  // 060AC816 bt 0x060AC812
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 18);  // 060AC818 mov.b @(18,gbr),r0
    c.r[0] -= 1;  // 060AC81A add #-1,r0
    st8(c.gbr + 19, c.r[0]);  // 060AC81C mov.b r0,@(19,gbr)
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 176);  // 060AC81E mov.b @(176,gbr),r0
    c.t = (c.r[0] & 0x10u) == 0;  // 060AC820 tst #16,r0
    if (!c.t) { goto L_060AC82A; }  // 060AC822 bf 0x060AC82A
    c.r[1] = ld32(0x060AC91Cu);  // 060AC824 mov.l 0x060AC91C,r1
    c.r[0] = 0x0u;  // 060AC826 mov #0,r0
    st16(c.r[1] + 2, c.r[0]);  // 060AC828 mov.w r0,@(2,r1)
L_060AC82A:
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060AC82A sts.l pr,@-r15
    c.r[0] = 0x0u;  // 060AC82C mov #0,r0
    st8(c.gbr + 168, c.r[0]);  // 060AC82E mov.b r0,@(168,gbr)
    st8(c.gbr + 166, c.r[0]);  // 060AC830 mov.b r0,@(166,gbr)
    c.r[0] = ld32(c.gbr + 72);  // 060AC832 mov.l @(72,gbr),r0
    c.r[5] = 0x0u;  // 060AC834 mov #0,r5
    c.r[1] = 0x30u;  // 060AC836 mov #48,r1
    c.r[2] = ld32(0x060AC924u);  // 060AC838 mov.l 0x060AC924,r2
    st32(c.r[0] + 8, c.r[5]);  // 060AC83A mov.l r5,@(8,r0)
    st32(c.r[0], c.r[1]);  // 060AC83C mov.l r1,@(0,r0)
    st32(c.r[0] + 4, c.r[2]);  // 060AC83E mov.l r2,@(4,r0)
    c.r[0] += 12;  // 060AC840 add #12,r0
    c.r[1] = 0x4u;  // 060AC842 mov #4,r1
    st32(c.r[0], c.r[1]);  // 060AC844 mov.l r1,@r0
    c.r[1] = 0x2Cu;  // 060AC846 mov #44,r1
    st32(c.r[0] + 4, c.r[1]);  // 060AC848 mov.l r1,@(4,r0)
    c.r[1] = ld32(0x060AC920u);  // 060AC84A mov.l 0x060AC920,r1
    c.r[0] += 4;  // 060AC84C add #4,r0
    st32(c.gbr + 72, c.r[0]);  // 060AC84E mov.l r0,@(72,gbr)
    st16(c.r[1], c.r[0]);  // 060AC850 mov.w r0,@r1
    c.pr = 0x060AC856u; SH2_POLL(c); sh2_call(c, 0x060AC928u); if (c.pc != 0x060AC856u) return;  // 060AC852 bsr 0x060AC928 ; nop
L_060AC856:
    c.r[0] = ld32(c.gbr + 972);  // 060AC856 mov.l @(972,gbr),r0
    { const uint32_t x = c.r[0]; c.pr = 0x060AC85Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AC85Cu) return; }  // 060AC858 jsr @r0 ; nop
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 19);  // 060AC85C mov.b @(19,gbr),r0
    c.t = (int32_t)c.r[0] >= 0;  // 060AC85E cmp/pz r0
    if (c.t) { SH2_POLL(c); goto L_060AC856; }  // 060AC860 bt 0x060AC856
    c.r[2] = ld32(0x060AC964u);  // 060AC862 mov.l 0x060AC964,r2
    c.r[1] = ld32(0x060AC968u);  // 060AC864 mov.l 0x060AC968,r1
    c.r[0] = ld32(c.gbr + 64);  // 060AC866 mov.l @(64,gbr),r0
    c.r[2] = ld32(c.r[2]);  // 060AC868 mov.l @r2,r2
    c.r[1] = ld32(c.r[1]);  // 060AC86A mov.l @r1,r1
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 060AC86C shlr r2
    c.r[0] ^= c.r[2];  // 060AC86E xor r2,r0
    st32(c.gbr + 64, c.r[0]);  // 060AC870 mov.l r0,@(64,gbr)
    c.r[1] += c.r[2];  // 060AC872 add r2,r1
    c.r[0] += c.r[1];  // 060AC874 add r1,r0
    c.r[0] -= 36;  // 060AC876 add #-36,r0
    st32(c.gbr + 48, c.r[0]);  // 060AC878 mov.l r0,@(48,gbr)
    c.r[0] = ld32(0x060AC94Cu);  // 060AC87A mov.l 0x060AC94C,r0
    c.r[0] = ld32(c.r[0]);  // 060AC87C mov.l @r0,r0
    c.r[0] += 16;  // 060AC87E add #16,r0
    st32(c.gbr + 36, c.r[0]);  // 060AC880 mov.l r0,@(36,gbr)
    c.r[0] = ld32(0x060AC95Cu);  // 060AC882 mov.l 0x060AC95C,r0
    c.r[1] = ld32(0x060AC960u);  // 060AC884 mov.l 0x060AC960,r1
    c.r[0] = ld32(c.r[0]);  // 060AC886 mov.l @r0,r0
    c.r[0] |= c.r[1];  // 060AC888 or r1,r0
    c.r[1] = ld32(0x060AC920u);  // 060AC88A mov.l 0x060AC920,r1
    st32(c.gbr + 72, c.r[0]);  // 060AC88C mov.l r0,@(72,gbr)
    st16(c.r[1], c.r[0]);  // 060AC88E mov.w r0,@r1
    c.r[0] = 0x0u;  // 060AC890 mov #0,r0
    st32(c.gbr + 116, c.r[0]);  // 060AC892 mov.l r0,@(116,gbr)
    st16(c.gbr + 170, c.r[0]);  // 060AC894 mov.w r0,@(170,gbr)
    c.r[0] = ld32(0x060AC94Cu);  // 060AC896 mov.l 0x060AC94C,r0
    c.r[2] = ld32(0x060AC950u);  // 060AC898 mov.l 0x060AC950,r2
    c.r[0] = ld32(c.r[0]);  // 060AC89A mov.l @r0,r0
    c.r[0] += 16;  // 060AC89C add #16,r0
    st32(c.gbr + 36, c.r[0]);  // 060AC89E mov.l r0,@(36,gbr)
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[2] + 30);  // 060AC8A0 mov.w @(30,r2),r0
    c.r[4] = ld32(c.r[2] + 12);  // 060AC8A2 mov.l @(12,r2),r4
    st8(c.gbr + 172, c.r[0]);  // 060AC8A4 mov.b r0,@(172,gbr)
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[2] + 28);  // 060AC8A6 mov.w @(28,r2),r0
    c.r[5] = ld32(c.r[2] + 20);  // 060AC8A8 mov.l @(20,r2),r5
    st16(c.gbr + 112, c.r[0]);  // 060AC8AA mov.w r0,@(112,gbr)
    c.r[0] = ld32(c.r[2] + 36);  // 060AC8AC mov.l @(36,r2),r0
    c.r[2] = ld32(c.r[2] + 56);  // 060AC8AE mov.l @(56,r2),r2
    st32(c.gbr + 104, c.r[0]);  // 060AC8B0 mov.l r0,@(104,gbr)
    c.r[0] = ld32(c.gbr + 772);  // 060AC8B2 mov.l @(772,gbr),r0
    c.r[1] = c.r[2];  // 060AC8B4 mov r2,r1
    c.r[6] = c.r[0];  // 060AC8B6 mov r0,r6
    c.r[1] -= c.r[4];  // 060AC8B8 sub r4,r1
    c.r[1] <<= 16;  // 060AC8BA shll16 r1
    c.r[3] = c.r[2] << 16 | c.r[2] >> 16;  // 060AC8BC swap.w r2,r3
    c.r[0] = c.r[4] << 16 | c.r[4] >> 16;  // 060AC8BE swap.w r4,r0
    c.r[3] -= c.r[0];  // 060AC8C0 sub r0,r3
    c.r[0] = c.r[1];  // 060AC8C2 mov r1,r0
    c.r[0] = c.r[3] << 16 | c.r[0] >> 16;  // 060AC8C4 xtrct r3,r0
    st32(c.gbr + 144, c.r[0]);  // 060AC8C6 mov.l r0,@(144,gbr)
    c.r[0] = c.r[6];  // 060AC8C8 mov r6,r0
    c.r[0] += c.r[1];  // 060AC8CA add r1,r0
    c.r[3] += c.r[6];  // 060AC8CC add r6,r3
    c.r[0] = c.r[3] << 16 | c.r[0] >> 16;  // 060AC8CE xtrct r3,r0
    st32(c.gbr + 152, c.r[0]);  // 060AC8D0 mov.l r0,@(152,gbr)
    c.r[0] = 0x1u;  // 060AC8D2 mov #1,r0
    c.r[0] <<= 16;  // 060AC8D4 shll16 r0
    c.r[0] |= 0x1u;  // 060AC8D6 or #1,r0
    c.r[0] += c.r[5];  // 060AC8D8 add r5,r0
    c.r[0] -= c.r[4];  // 060AC8DA sub r4,r0
    st32(c.gbr + 132, c.r[0]);  // 060AC8DC mov.l r0,@(132,gbr)
    c.r[6] = c.r[6] << 16 | c.r[6] >> 16;  // 060AC8DE swap.w r6,r6
    c.r[6] += c.r[6];  // 060AC8E0 add r6,r6
    c.r[0] += c.r[6];  // 060AC8E2 add r6,r0
    st32(c.gbr + 140, c.r[0]);  // 060AC8E4 mov.l r0,@(140,gbr)
    c.r[1] = c.r[5] << 16 | c.r[5] >> 16;  // 060AC8E6 swap.w r5,r1
    c.r[0] = c.r[2] << 16 | c.r[2] >> 16;  // 060AC8E8 swap.w r2,r0
    c.r[1] -= c.r[0];  // 060AC8EA sub r0,r1
    c.r[5] -= c.r[2];  // 060AC8EC sub r2,r5
    c.r[0] = c.r[5] << 16 | c.r[5] >> 16;  // 060AC8EE swap.w r5,r0
    c.r[0] = c.r[1] << 16 | c.r[0] >> 16;  // 060AC8F0 xtrct r1,r0
    st32(c.gbr + 124, c.r[0]);  // 060AC8F2 mov.l r0,@(124,gbr)
    c.r[1] = c.r[4] << 16 | c.r[4] >> 16;  // 060AC8F4 swap.w r4,r1
    c.r[0] = c.r[2] << 16 | c.r[2] >> 16;  // 060AC8F6 swap.w r2,r0
    c.r[1] -= c.r[0];  // 060AC8F8 sub r0,r1
    c.r[4] -= c.r[2];  // 060AC8FA sub r2,r4
    c.r[0] = c.r[4] << 16 | c.r[4] >> 16;  // 060AC8FC swap.w r4,r0
    c.r[0] = c.r[1] << 16 | c.r[0] >> 16;  // 060AC8FE xtrct r1,r0
    st32(c.gbr + 120, c.r[0]);  // 060AC900 mov.l r0,@(120,gbr)
    c.r[0] = 0x0u;  // 060AC902 mov #0,r0
    st16(c.gbr + 114, c.r[0]);  // 060AC904 mov.w r0,@(114,gbr)
    st16(c.gbr + 162, c.r[0]);  // 060AC906 mov.w r0,@(162,gbr)
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060AC908 lds.l @r15+,pr
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 18);  // 060AC90A mov.b @(18,gbr),r0
    c.r[1] = c.r[0];  // 060AC90C mov r0,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 19);  // 060AC90E mov.b @(19,gbr),r0
    c.r[0] += c.r[1];  // 060AC910 add r1,r0
    { const uint32_t x = c.pr; st8(c.gbr + 19, c.r[0]); c.pc = x; return; }  // 060AC912 rts ; mov.b r0,@(19,gbr)
}

void f_060AC82A(SH2Context& c) {
    ran[2860] = 1;
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060AC82A sts.l pr,@-r15
    c.r[0] = 0x0u;  // 060AC82C mov #0,r0
    st8(c.gbr + 168, c.r[0]);  // 060AC82E mov.b r0,@(168,gbr)
    st8(c.gbr + 166, c.r[0]);  // 060AC830 mov.b r0,@(166,gbr)
    c.r[0] = ld32(c.gbr + 72);  // 060AC832 mov.l @(72,gbr),r0
    c.r[5] = 0x0u;  // 060AC834 mov #0,r5
    c.r[1] = 0x30u;  // 060AC836 mov #48,r1
    c.r[2] = ld32(0x060AC924u);  // 060AC838 mov.l 0x060AC924,r2
    st32(c.r[0] + 8, c.r[5]);  // 060AC83A mov.l r5,@(8,r0)
    st32(c.r[0], c.r[1]);  // 060AC83C mov.l r1,@(0,r0)
    st32(c.r[0] + 4, c.r[2]);  // 060AC83E mov.l r2,@(4,r0)
    c.r[0] += 12;  // 060AC840 add #12,r0
    c.r[1] = 0x4u;  // 060AC842 mov #4,r1
    st32(c.r[0], c.r[1]);  // 060AC844 mov.l r1,@r0
    c.r[1] = 0x2Cu;  // 060AC846 mov #44,r1
    st32(c.r[0] + 4, c.r[1]);  // 060AC848 mov.l r1,@(4,r0)
    c.r[1] = ld32(0x060AC920u);  // 060AC84A mov.l 0x060AC920,r1
    c.r[0] += 4;  // 060AC84C add #4,r0
    st32(c.gbr + 72, c.r[0]);  // 060AC84E mov.l r0,@(72,gbr)
    st16(c.r[1], c.r[0]);  // 060AC850 mov.w r0,@r1
    c.pr = 0x060AC856u; SH2_POLL(c); sh2_call(c, 0x060AC928u); if (c.pc != 0x060AC856u) return;  // 060AC852 bsr 0x060AC928 ; nop
L_060AC856:
    c.r[0] = ld32(c.gbr + 972);  // 060AC856 mov.l @(972,gbr),r0
    { const uint32_t x = c.r[0]; c.pr = 0x060AC85Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AC85Cu) return; }  // 060AC858 jsr @r0 ; nop
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 19);  // 060AC85C mov.b @(19,gbr),r0
    c.t = (int32_t)c.r[0] >= 0;  // 060AC85E cmp/pz r0
    if (c.t) { SH2_POLL(c); goto L_060AC856; }  // 060AC860 bt 0x060AC856
    c.r[2] = ld32(0x060AC964u);  // 060AC862 mov.l 0x060AC964,r2
    c.r[1] = ld32(0x060AC968u);  // 060AC864 mov.l 0x060AC968,r1
    c.r[0] = ld32(c.gbr + 64);  // 060AC866 mov.l @(64,gbr),r0
    c.r[2] = ld32(c.r[2]);  // 060AC868 mov.l @r2,r2
    c.r[1] = ld32(c.r[1]);  // 060AC86A mov.l @r1,r1
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 060AC86C shlr r2
    c.r[0] ^= c.r[2];  // 060AC86E xor r2,r0
    st32(c.gbr + 64, c.r[0]);  // 060AC870 mov.l r0,@(64,gbr)
    c.r[1] += c.r[2];  // 060AC872 add r2,r1
    c.r[0] += c.r[1];  // 060AC874 add r1,r0
    c.r[0] -= 36;  // 060AC876 add #-36,r0
    st32(c.gbr + 48, c.r[0]);  // 060AC878 mov.l r0,@(48,gbr)
    c.r[0] = ld32(0x060AC94Cu);  // 060AC87A mov.l 0x060AC94C,r0
    c.r[0] = ld32(c.r[0]);  // 060AC87C mov.l @r0,r0
    c.r[0] += 16;  // 060AC87E add #16,r0
    st32(c.gbr + 36, c.r[0]);  // 060AC880 mov.l r0,@(36,gbr)
    c.r[0] = ld32(0x060AC95Cu);  // 060AC882 mov.l 0x060AC95C,r0
    c.r[1] = ld32(0x060AC960u);  // 060AC884 mov.l 0x060AC960,r1
    c.r[0] = ld32(c.r[0]);  // 060AC886 mov.l @r0,r0
    c.r[0] |= c.r[1];  // 060AC888 or r1,r0
    c.r[1] = ld32(0x060AC920u);  // 060AC88A mov.l 0x060AC920,r1
    st32(c.gbr + 72, c.r[0]);  // 060AC88C mov.l r0,@(72,gbr)
    st16(c.r[1], c.r[0]);  // 060AC88E mov.w r0,@r1
    c.r[0] = 0x0u;  // 060AC890 mov #0,r0
    st32(c.gbr + 116, c.r[0]);  // 060AC892 mov.l r0,@(116,gbr)
    st16(c.gbr + 170, c.r[0]);  // 060AC894 mov.w r0,@(170,gbr)
    c.r[0] = ld32(0x060AC94Cu);  // 060AC896 mov.l 0x060AC94C,r0
    c.r[2] = ld32(0x060AC950u);  // 060AC898 mov.l 0x060AC950,r2
    c.r[0] = ld32(c.r[0]);  // 060AC89A mov.l @r0,r0
    c.r[0] += 16;  // 060AC89C add #16,r0
    st32(c.gbr + 36, c.r[0]);  // 060AC89E mov.l r0,@(36,gbr)
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[2] + 30);  // 060AC8A0 mov.w @(30,r2),r0
    c.r[4] = ld32(c.r[2] + 12);  // 060AC8A2 mov.l @(12,r2),r4
    st8(c.gbr + 172, c.r[0]);  // 060AC8A4 mov.b r0,@(172,gbr)
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[2] + 28);  // 060AC8A6 mov.w @(28,r2),r0
    c.r[5] = ld32(c.r[2] + 20);  // 060AC8A8 mov.l @(20,r2),r5
    st16(c.gbr + 112, c.r[0]);  // 060AC8AA mov.w r0,@(112,gbr)
    c.r[0] = ld32(c.r[2] + 36);  // 060AC8AC mov.l @(36,r2),r0
    c.r[2] = ld32(c.r[2] + 56);  // 060AC8AE mov.l @(56,r2),r2
    st32(c.gbr + 104, c.r[0]);  // 060AC8B0 mov.l r0,@(104,gbr)
    c.r[0] = ld32(c.gbr + 772);  // 060AC8B2 mov.l @(772,gbr),r0
    c.r[1] = c.r[2];  // 060AC8B4 mov r2,r1
    c.r[6] = c.r[0];  // 060AC8B6 mov r0,r6
    c.r[1] -= c.r[4];  // 060AC8B8 sub r4,r1
    c.r[1] <<= 16;  // 060AC8BA shll16 r1
    c.r[3] = c.r[2] << 16 | c.r[2] >> 16;  // 060AC8BC swap.w r2,r3
    c.r[0] = c.r[4] << 16 | c.r[4] >> 16;  // 060AC8BE swap.w r4,r0
    c.r[3] -= c.r[0];  // 060AC8C0 sub r0,r3
    c.r[0] = c.r[1];  // 060AC8C2 mov r1,r0
    c.r[0] = c.r[3] << 16 | c.r[0] >> 16;  // 060AC8C4 xtrct r3,r0
    st32(c.gbr + 144, c.r[0]);  // 060AC8C6 mov.l r0,@(144,gbr)
    c.r[0] = c.r[6];  // 060AC8C8 mov r6,r0
    c.r[0] += c.r[1];  // 060AC8CA add r1,r0
    c.r[3] += c.r[6];  // 060AC8CC add r6,r3
    c.r[0] = c.r[3] << 16 | c.r[0] >> 16;  // 060AC8CE xtrct r3,r0
    st32(c.gbr + 152, c.r[0]);  // 060AC8D0 mov.l r0,@(152,gbr)
    c.r[0] = 0x1u;  // 060AC8D2 mov #1,r0
    c.r[0] <<= 16;  // 060AC8D4 shll16 r0
    c.r[0] |= 0x1u;  // 060AC8D6 or #1,r0
    c.r[0] += c.r[5];  // 060AC8D8 add r5,r0
    c.r[0] -= c.r[4];  // 060AC8DA sub r4,r0
    st32(c.gbr + 132, c.r[0]);  // 060AC8DC mov.l r0,@(132,gbr)
    c.r[6] = c.r[6] << 16 | c.r[6] >> 16;  // 060AC8DE swap.w r6,r6
    c.r[6] += c.r[6];  // 060AC8E0 add r6,r6
    c.r[0] += c.r[6];  // 060AC8E2 add r6,r0
    st32(c.gbr + 140, c.r[0]);  // 060AC8E4 mov.l r0,@(140,gbr)
    c.r[1] = c.r[5] << 16 | c.r[5] >> 16;  // 060AC8E6 swap.w r5,r1
    c.r[0] = c.r[2] << 16 | c.r[2] >> 16;  // 060AC8E8 swap.w r2,r0
    c.r[1] -= c.r[0];  // 060AC8EA sub r0,r1
    c.r[5] -= c.r[2];  // 060AC8EC sub r2,r5
    c.r[0] = c.r[5] << 16 | c.r[5] >> 16;  // 060AC8EE swap.w r5,r0
    c.r[0] = c.r[1] << 16 | c.r[0] >> 16;  // 060AC8F0 xtrct r1,r0
    st32(c.gbr + 124, c.r[0]);  // 060AC8F2 mov.l r0,@(124,gbr)
    c.r[1] = c.r[4] << 16 | c.r[4] >> 16;  // 060AC8F4 swap.w r4,r1
    c.r[0] = c.r[2] << 16 | c.r[2] >> 16;  // 060AC8F6 swap.w r2,r0
    c.r[1] -= c.r[0];  // 060AC8F8 sub r0,r1
    c.r[4] -= c.r[2];  // 060AC8FA sub r2,r4
    c.r[0] = c.r[4] << 16 | c.r[4] >> 16;  // 060AC8FC swap.w r4,r0
    c.r[0] = c.r[1] << 16 | c.r[0] >> 16;  // 060AC8FE xtrct r1,r0
    st32(c.gbr + 120, c.r[0]);  // 060AC900 mov.l r0,@(120,gbr)
    c.r[0] = 0x0u;  // 060AC902 mov #0,r0
    st16(c.gbr + 114, c.r[0]);  // 060AC904 mov.w r0,@(114,gbr)
    st16(c.gbr + 162, c.r[0]);  // 060AC906 mov.w r0,@(162,gbr)
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060AC908 lds.l @r15+,pr
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 18);  // 060AC90A mov.b @(18,gbr),r0
    c.r[1] = c.r[0];  // 060AC90C mov r0,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 19);  // 060AC90E mov.b @(19,gbr),r0
    c.r[0] += c.r[1];  // 060AC910 add r1,r0
    { const uint32_t x = c.pr; st8(c.gbr + 19, c.r[0]); c.pc = x; return; }  // 060AC912 rts ; mov.b r0,@(19,gbr)
}

void f_060AC928(SH2Context& c) {
    ran[2861] = 1;
    c.r[1] = ld32(0x060AC970u);  // 060AC928 mov.l 0x060AC970,r1
    c.r[0] = ld32(c.gbr + 828);  // 060AC92A mov.l @(828,gbr),r0
    c.r[3] = c.macl;  // 060AC92C sts macl,r3
    c.macl = c.r[0] * c.r[1];  // 060AC92E mul.l r1,r0
    c.r[1] = ld32(0x060AC96Cu);  // 060AC930 mov.l 0x060AC96C,r1
    c.r[0] = c.macl;  // 060AC932 sts macl,r0
    c.r[0] += c.r[1];  // 060AC934 add r1,r0
    st32(c.gbr + 828, c.r[0]);  // 060AC936 mov.l r0,@(828,gbr)
    c.r[1] = c.r[0] << 16 | c.r[0] >> 16;  // 060AC938 swap.w r0,r1
    c.r[0] >>= 16;  // 060AC93A shlr16 r0
    c.macl = c.r[3];  // 060AC93C lds r3,macl
    c.t = c.r[1] >> 31; c.r[1] <<= 1;  // 060AC93E shll r1
    c.r[1] = 0x0u;  // 060AC940 mov #0,r1
    { const uint32_t x = c.pr; { uint64_t s = (uint64_t)c.r[0] + c.r[1] + c.t; c.t = (uint32_t)(s >> 32); c.r[0] = (uint32_t)s; } c.pc = x; return; }  // 060AC942 rts ; addc r1,r0
}

void f_060AC974(SH2Context& c) {
    ran[2862] = 1;
    c.r[3] = ld32(0x060AC988u);  // 060AC974 mov.l 0x060AC988,r3
    { uint32_t a = c.r[3], v = ld8(a); c.t = v == 0; st8(a, v | 0x80u); }  // 060AC976 tas.b @r3
    c.r[0] = c.t;  // 060AC978 movt r0
    { const uint32_t x = c.pr; c.r[0] -= 1; c.pc = x; return; }  // 060AC97A rts ; add #-1,r0
}

void f_060AC97E(SH2Context& c) {
    ran[2863] = 1;
    c.r[3] = ld32(0x060AC988u);  // 060AC97E mov.l 0x060AC988,r3
    c.r[1] ^= c.r[1];  // 060AC980 xor r1,r1
    st8(c.r[3], c.r[1]);  // 060AC982 mov.b r1,@r3
    { const uint32_t x = c.pr; c.r[0] = c.r[4]; c.pc = x; return; }  // 060AC984 rts ; mov r4,r0
}

void f_060AC98C(SH2Context& c) {
    ran[2864] = 1;
    c.r[2] = ld32(0x060AC9F0u);  // 060AC98C mov.l 0x060AC9F0,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060AC98E mov.b @r2,r0
    { const uint32_t x = c.pr; c.r[0] &= 0x7Fu; c.pc = x; return; }  // 060AC990 rts ; and #127,r0
}

void f_060AC994(SH2Context& c) {
    ran[2865] = 1;
    c.r[2] = ld32(0x060AC9F4u);  // 060AC994 mov.l 0x060AC9F4,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060AC996 mov.b @r2,r0
    { const uint32_t x = c.pr; c.r[0] &= 0x7Fu; c.pc = x; return; }  // 060AC998 rts ; and #127,r0
}

void f_060AC99C(SH2Context& c) {
    ran[2866] = 1;
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060AC99C sts.l pr,@-r15
    c.pr = 0x060AC9A2u; SH2_POLL(c); sh2_call(c, 0x060AC974u); if (c.pc != 0x060AC9A2u) return;  // 060AC99E bsr 0x060AC974 ; nop
    c.t = c.r[0] == 0x0u;  // 060AC9A2 cmp/eq #0,r0
    if (!c.t) { goto L_060AC9C0; }  // 060AC9A4 bf 0x060AC9C0
    c.pr = 0x060AC9AAu; SH2_POLL(c); sh2_call(c, 0x060ACE06u); if (c.pc != 0x060AC9AAu) return;  // 060AC9A6 bsr 0x060ACE06 ; nop
    c.t = c.r[0] == 0x0u;  // 060AC9AA cmp/eq #0,r0
    if (!c.t) { goto L_060AC9BC; }  // 060AC9AC bf 0x060AC9BC
    c.r[0] = c.r[4];  // 060AC9AE mov r4,r0
    c.r[2] = ld32(0x060AC9F0u);  // 060AC9B0 mov.l 0x060AC9F0,r2
    c.r[0] &= 0x7Fu;  // 060AC9B2 and #127,r0
    c.r[3] = ld32(0x060AC9F8u);  // 060AC9B4 mov.l 0x060AC9F8,r3
    st8(c.r[2], c.r[0]);  // 060AC9B6 mov.b r0,@r2
    st8(c.r[3], c.r[0]);  // 060AC9B8 mov.b r0,@r3
    c.r[0] = 0x0u;  // 060AC9BA mov #0,r0
L_060AC9BC:
    c.pr = 0x060AC9C0u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, 0x060AC97Eu); if (c.pc != 0x060AC9C0u) return;  // 060AC9BC bsr 0x060AC97E ; mov r0,r4
L_060AC9C0:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060AC9C0 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060AC9C2 rts ; nop
}

void f_060AC9C6(SH2Context& c) {
    ran[2867] = 1;
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060AC9C6 sts.l pr,@-r15
    c.pr = 0x060AC9CCu; SH2_POLL(c); sh2_call(c, 0x060AC974u); if (c.pc != 0x060AC9CCu) return;  // 060AC9C8 bsr 0x060AC974 ; nop
    c.t = c.r[0] == 0x0u;  // 060AC9CC cmp/eq #0,r0
    if (!c.t) { goto L_060AC9EA; }  // 060AC9CE bf 0x060AC9EA
    c.pr = 0x060AC9D4u; SH2_POLL(c); sh2_call(c, 0x060ACE06u); if (c.pc != 0x060AC9D4u) return;  // 060AC9D0 bsr 0x060ACE06 ; nop
    c.t = c.r[0] == 0x0u;  // 060AC9D4 cmp/eq #0,r0
    if (!c.t) { goto L_060AC9E6; }  // 060AC9D6 bf 0x060AC9E6
    c.r[0] = c.r[4];  // 060AC9D8 mov r4,r0
    c.r[2] = ld32(0x060AC9F4u);  // 060AC9DA mov.l 0x060AC9F4,r2
    c.r[0] &= 0x7Fu;  // 060AC9DC and #127,r0
    c.r[3] = ld32(0x060AC9FCu);  // 060AC9DE mov.l 0x060AC9FC,r3
    st8(c.r[2], c.r[0]);  // 060AC9E0 mov.b r0,@r2
    st8(c.r[3], c.r[0]);  // 060AC9E2 mov.b r0,@r3
    c.r[0] = 0x0u;  // 060AC9E4 mov #0,r0
L_060AC9E6:
    c.pr = 0x060AC9EAu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, 0x060AC97Eu); if (c.pc != 0x060AC9EAu) return;  // 060AC9E6 bsr 0x060AC97E ; mov r0,r4
L_060AC9EA:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060AC9EA lds.l @r15+,pr
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060AC9EC rts ; nop
}

void f_060ACA00(SH2Context& c) {
    ran[2868] = 1;
    c.r[2] = ld32(0x060ACA24u);  // 060ACA00 mov.l 0x060ACA24,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060ACA02 mov.b @r2,r0
    { const uint32_t x = c.pr; c.r[0] &= 0x7Fu; c.pc = x; return; }  // 060ACA04 rts ; and #127,r0
}

void f_060ACA08(SH2Context& c) {
    ran[2869] = 1;
    c.r[2] = ld32(0x060ACA28u);  // 060ACA08 mov.l 0x060ACA28,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060ACA0A mov.b @r2,r0
    { const uint32_t x = c.pr; c.r[0] &= 0x7Fu; c.pc = x; return; }  // 060ACA0C rts ; and #127,r0
}

void f_060ACA2C(SH2Context& c) {
    ran[2870] = 1;
    c.r[2] = ld32(0x060ACAA8u);  // 060ACA2C mov.l 0x060ACAA8,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060ACA2E mov.b @r2,r0
    c.t = (c.r[0] & 0x1u) == 0;  // 060ACA30 tst #1,r0
    { const uint32_t x = c.pr; c.r[0] = c.t; c.pc = x; return; }  // 060ACA32 rts ; movt r0
}

void f_060ACA36(SH2Context& c) {
    ran[2871] = 1;
    c.r[2] = ld32(0x060ACAA8u);  // 060ACA36 mov.l 0x060ACAA8,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060ACA38 mov.b @r2,r0
    c.t = (c.r[0] & 0x2u) == 0;  // 060ACA3A tst #2,r0
    { const uint32_t x = c.pr; c.r[0] = c.t; c.pc = x; return; }  // 060ACA3C rts ; movt r0
}

void f_060ACA40(SH2Context& c) {
    ran[2872] = 1;
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060ACA40 sts.l pr,@-r15
    c.pr = 0x060ACA46u; SH2_POLL(c); sh2_call(c, 0x060AC974u); if (c.pc != 0x060ACA46u) return;  // 060ACA42 bsr 0x060AC974 ; nop
    c.t = c.r[0] == 0x0u;  // 060ACA46 cmp/eq #0,r0
    if (!c.t) { goto L_060ACA6E; }  // 060ACA48 bf 0x060ACA6E
    c.pr = 0x060ACA4Eu; SH2_POLL(c); sh2_call(c, 0x060ACE06u); if (c.pc != 0x060ACA4Eu) return;  // 060ACA4A bsr 0x060ACE06 ; nop
    c.t = c.r[0] == 0x0u;  // 060ACA4E cmp/eq #0,r0
    if (!c.t) { goto L_060ACA6A; }  // 060ACA50 bf 0x060ACA6A
    c.r[3] = ld32(0x060ACAACu);  // 060ACA52 mov.l 0x060ACAAC,r3
    c.r[1] = 0x0u;  // 060ACA54 mov #0,r1
    c.r[2] = ld32(0x060ACAA8u);  // 060ACA56 mov.l 0x060ACAA8,r2
    c.r[4] = c.r[4] & 0xFFu;  // 060ACA58 extu.b r4,r4
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060ACA5A mov.b @r2,r0
    c.t = c.r[4] == c.r[1];  // 060ACA5C cmp/eq r1,r4
    { const bool k = c.t; c.r[0] |= 0x1u; if (k) { goto L_060ACA64; } }  // 060ACA5E bt/s 0x060ACA64 ; or #1,r0
    c.r[0] ^= 0x1u;  // 060ACA62 xor #1,r0
L_060ACA64:
    st8(c.r[2], c.r[0]);  // 060ACA64 mov.b r0,@r2
    st8(c.r[3], c.r[0]);  // 060ACA66 mov.b r0,@r3
    c.r[0] = 0x0u;  // 060ACA68 mov #0,r0
L_060ACA6A:
    c.pr = 0x060ACA6Eu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, 0x060AC97Eu); if (c.pc != 0x060ACA6Eu) return;  // 060ACA6A bsr 0x060AC97E ; mov r0,r4
L_060ACA6E:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060ACA6E lds.l @r15+,pr
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060ACA70 rts ; nop
}

void f_060ACA74(SH2Context& c) {
    ran[2873] = 1;
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060ACA74 sts.l pr,@-r15
    c.pr = 0x060ACA7Au; SH2_POLL(c); sh2_call(c, 0x060AC974u); if (c.pc != 0x060ACA7Au) return;  // 060ACA76 bsr 0x060AC974 ; nop
    c.t = c.r[0] == 0x0u;  // 060ACA7A cmp/eq #0,r0
    if (!c.t) { goto L_060ACAA2; }  // 060ACA7C bf 0x060ACAA2
    c.pr = 0x060ACA82u; SH2_POLL(c); sh2_call(c, 0x060ACE06u); if (c.pc != 0x060ACA82u) return;  // 060ACA7E bsr 0x060ACE06 ; nop
    c.t = c.r[0] == 0x0u;  // 060ACA82 cmp/eq #0,r0
    if (!c.t) { goto L_060ACA9E; }  // 060ACA84 bf 0x060ACA9E
    c.r[3] = ld32(0x060ACAACu);  // 060ACA86 mov.l 0x060ACAAC,r3
    c.r[1] = 0x0u;  // 060ACA88 mov #0,r1
    c.r[2] = ld32(0x060ACAA8u);  // 060ACA8A mov.l 0x060ACAA8,r2
    c.r[4] = c.r[4] & 0xFFu;  // 060ACA8C extu.b r4,r4
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060ACA8E mov.b @r2,r0
    c.t = c.r[4] == c.r[1];  // 060ACA90 cmp/eq r1,r4
    { const bool k = c.t; c.r[0] |= 0x2u; if (k) { goto L_060ACA98; } }  // 060ACA92 bt/s 0x060ACA98 ; or #2,r0
    c.r[0] ^= 0x2u;  // 060ACA96 xor #2,r0
L_060ACA98:
    st8(c.r[2], c.r[0]);  // 060ACA98 mov.b r0,@r2
    st8(c.r[3], c.r[0]);  // 060ACA9A mov.b r0,@r3
    c.r[0] = 0x0u;  // 060ACA9C mov #0,r0
L_060ACA9E:
    c.pr = 0x060ACAA2u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, 0x060AC97Eu); if (c.pc != 0x060ACAA2u) return;  // 060ACA9E bsr 0x060AC97E ; mov r0,r4
L_060ACAA2:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060ACAA2 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060ACAA4 rts ; nop
}

void f_060ACAB0(SH2Context& c) {
    ran[2874] = 1;
    c.r[2] = ld32(0x060ACB24u);  // 060ACAB0 mov.l 0x060ACB24,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060ACAB2 mov.b @r2,r0
    c.t = (c.r[0] & 0x1u) == 0;  // 060ACAB4 tst #1,r0
    { const uint32_t x = c.pr; c.r[0] = c.t; c.pc = x; return; }  // 060ACAB6 rts ; movt r0
}

void f_060ACABA(SH2Context& c) {
    ran[2875] = 1;
    c.r[2] = ld32(0x060ACB24u);  // 060ACABA mov.l 0x060ACB24,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060ACABC mov.b @r2,r0
    c.t = (c.r[0] & 0x2u) == 0;  // 060ACABE tst #2,r0
    { const uint32_t x = c.pr; c.r[0] = c.t; c.pc = x; return; }  // 060ACAC0 rts ; movt r0
}

void f_060ACAC4(SH2Context& c) {
    ran[2876] = 1;
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060ACAC4 sts.l pr,@-r15
    c.pr = 0x060ACACAu; SH2_POLL(c); sh2_call(c, 0x060AC974u); if (c.pc != 0x060ACACAu) return;  // 060ACAC6 bsr 0x060AC974 ; nop
    c.t = c.r[0] == 0x0u;  // 060ACACA cmp/eq #0,r0
    if (!c.t) { goto L_060ACAEE; }  // 060ACACC bf 0x060ACAEE
    c.pr = 0x060ACAD2u; SH2_POLL(c); sh2_call(c, 0x060ACE06u); if (c.pc != 0x060ACAD2u) return;  // 060ACACE bsr 0x060ACE06 ; nop
    c.r[3] = ld32(0x060ACB28u);  // 060ACAD2 mov.l 0x060ACB28,r3
    c.r[1] = 0x0u;  // 060ACAD4 mov #0,r1
    c.r[2] = ld32(0x060ACB24u);  // 060ACAD6 mov.l 0x060ACB24,r2
    c.r[4] = c.r[4] & 0xFFu;  // 060ACAD8 extu.b r4,r4
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060ACADA mov.b @r2,r0
    c.t = c.r[4] == c.r[1];  // 060ACADC cmp/eq r1,r4
    { const bool k = c.t; c.r[0] |= 0x1u; if (k) { goto L_060ACAE4; } }  // 060ACADE bt/s 0x060ACAE4 ; or #1,r0
    c.r[0] ^= 0x1u;  // 060ACAE2 xor #1,r0
L_060ACAE4:
    st8(c.r[2], c.r[0]);  // 060ACAE4 mov.b r0,@r2
    st8(c.r[3], c.r[0]);  // 060ACAE6 mov.b r0,@r3
    c.r[0] = 0x0u;  // 060ACAE8 mov #0,r0
    c.pr = 0x060ACAEEu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, 0x060AC97Eu); if (c.pc != 0x060ACAEEu) return;  // 060ACAEA bsr 0x060AC97E ; mov r0,r4
L_060ACAEE:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060ACAEE lds.l @r15+,pr
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060ACAF0 rts ; nop
}

void f_060ACAF4(SH2Context& c) {
    ran[2877] = 1;
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060ACAF4 sts.l pr,@-r15
    c.pr = 0x060ACAFAu; SH2_POLL(c); sh2_call(c, 0x060AC974u); if (c.pc != 0x060ACAFAu) return;  // 060ACAF6 bsr 0x060AC974 ; nop
    c.t = c.r[0] == 0x0u;  // 060ACAFA cmp/eq #0,r0
    if (!c.t) { goto L_060ACB1E; }  // 060ACAFC bf 0x060ACB1E
    c.pr = 0x060ACB02u; SH2_POLL(c); sh2_call(c, 0x060ACE06u); if (c.pc != 0x060ACB02u) return;  // 060ACAFE bsr 0x060ACE06 ; nop
    c.r[3] = ld32(0x060ACB28u);  // 060ACB02 mov.l 0x060ACB28,r3
    c.r[1] = 0x0u;  // 060ACB04 mov #0,r1
    c.r[2] = ld32(0x060ACB24u);  // 060ACB06 mov.l 0x060ACB24,r2
    c.r[4] = c.r[4] & 0xFFu;  // 060ACB08 extu.b r4,r4
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060ACB0A mov.b @r2,r0
    c.t = c.r[4] == c.r[1];  // 060ACB0C cmp/eq r1,r4
    { const bool k = c.t; c.r[0] |= 0x2u; if (k) { goto L_060ACB14; } }  // 060ACB0E bt/s 0x060ACB14 ; or #2,r0
    c.r[0] ^= 0x2u;  // 060ACB12 xor #2,r0
L_060ACB14:
    st8(c.r[2], c.r[0]);  // 060ACB14 mov.b r0,@r2
    st8(c.r[3], c.r[0]);  // 060ACB16 mov.b r0,@r3
    c.r[0] = 0x0u;  // 060ACB18 mov #0,r0
    c.pr = 0x060ACB1Eu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, 0x060AC97Eu); if (c.pc != 0x060ACB1Eu) return;  // 060ACB1A bsr 0x060AC97E ; mov r0,r4
L_060ACB1E:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060ACB1E lds.l @r15+,pr
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060ACB20 rts ; nop
}

void f_060ACB2C(SH2Context& c) {
    ran[2878] = 1;
    c.r[4] = c.r[4] & 0xFFu;  // 060ACB2C extu.b r4,r4
    c.r[0] = 0x060ACB3Cu;  // 060ACB2E mova 0x060ACB3C,r0
    c.r[1] = 0x4u;  // 060ACB30 mov #4,r1
    c.r[2] = c.r[0];  // 060ACB32 mov r0,r2
    c.macl = (c.r[1] & 0xFFFFu) * (c.r[4] & 0xFFFFu);  // 060ACB34 mulu.w r4,r1
    c.r[0] = c.macl;  // 060ACB36 sts macl,r0
    { const uint32_t x = c.pr; c.r[0] += c.r[2]; c.pc = x; return; }  // 060ACB38 rts ; add r2,r0
}

void f_060ACB80(SH2Context& c) {
    ran[2879] = 1;
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060ACB80 sts.l pr,@-r15
    c.pr = 0x060ACB86u; SH2_POLL(c); sh2_call(c, 0x060ACA2Cu); if (c.pc != 0x060ACB86u) return;  // 060ACB82 bsr 0x060ACA2C ; nop
    c.t = c.r[0] == 0x1u;  // 060ACB86 cmp/eq #1,r0
    if (!c.t) { goto L_060ACB9E; }  // 060ACB88 bf 0x060ACB9E
    c.pr = 0x060ACB8Eu; SH2_POLL(c); sh2_call(c, 0x060AC98Cu); if (c.pc != 0x060ACB8Eu) return;  // 060ACB8A bsr 0x060AC98C ; nop
    c.t = (c.r[0] & c.r[0]) == 0;  // 060ACB8E tst r0,r0
    { const bool k = !c.t; c.r[0] = 0xFFFFFFFFu; if (k) { goto L_060ACBBC; } }  // 060ACB90 bf/s 0x060ACBBC ; mov #-1,r0
    c.pr = 0x060ACB98u; SH2_POLL(c); sh2_call(c, 0x060ACAB0u); if (c.pc != 0x060ACB98u) return;  // 060ACB94 bsr 0x060ACAB0 ; nop
    c.t = c.r[0] == 0x1u;  // 060ACB98 cmp/eq #1,r0
    { const bool k = !c.t; c.r[0] = 0xFFFFFFFFu; if (k) { goto L_060ACBBC; } }  // 060ACB9A bf/s 0x060ACBBC ; mov #-1,r0
L_060ACB9E:
    c.pr = 0x060ACBA2u; SH2_POLL(c); sh2_call(c, 0x060ACA36u); if (c.pc != 0x060ACBA2u) return;  // 060ACB9E bsr 0x060ACA36 ; nop
    c.t = c.r[0] == 0x1u;  // 060ACBA2 cmp/eq #1,r0
    if (!c.t) { goto L_060ACBBA; }  // 060ACBA4 bf 0x060ACBBA
    c.pr = 0x060ACBAAu; SH2_POLL(c); sh2_call(c, 0x060AC994u); if (c.pc != 0x060ACBAAu) return;  // 060ACBA6 bsr 0x060AC994 ; nop
    c.t = (c.r[0] & c.r[0]) == 0;  // 060ACBAA tst r0,r0
    { const bool k = !c.t; c.r[0] = 0xFFFFFFFFu; if (k) { goto L_060ACBBC; } }  // 060ACBAC bf/s 0x060ACBBC ; mov #-1,r0
    c.pr = 0x060ACBB4u; SH2_POLL(c); sh2_call(c, 0x060ACABAu); if (c.pc != 0x060ACBB4u) return;  // 060ACBB0 bsr 0x060ACABA ; nop
    c.t = c.r[0] == 0x1u;  // 060ACBB4 cmp/eq #1,r0
    { const bool k = !c.t; c.r[0] = 0xFFFFFFFFu; if (k) { goto L_060ACBBC; } }  // 060ACBB6 bf/s 0x060ACBBC ; mov #-1,r0
L_060ACBBA:
    c.r[0] = 0x0u;  // 060ACBBA mov #0,r0
L_060ACBBC:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060ACBBC lds.l @r15+,pr
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060ACBBE rts ; nop
}

void f_060ACBC2(SH2Context& c) {
    ran[2880] = 1;
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060ACBC2 sts.l pr,@-r15
    c.pr = 0x060ACBC8u; SH2_POLL(c); sh2_call(c, 0x060ACA2Cu); if (c.pc != 0x060ACBC8u) return;  // 060ACBC4 bsr 0x060ACA2C ; nop
    c.t = c.r[0] == 0x1u;  // 060ACBC8 cmp/eq #1,r0
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_060ACBDA; } }  // 060ACBCA bt/s 0x060ACBDA ; mov #0,r0
    c.pr = 0x060ACBD2u; SH2_POLL(c); sh2_call(c, 0x060ACA36u); if (c.pc != 0x060ACBD2u) return;  // 060ACBCE bsr 0x060ACA36 ; nop
    c.t = c.r[0] == 0x1u;  // 060ACBD2 cmp/eq #1,r0
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_060ACBDA; } }  // 060ACBD4 bt/s 0x060ACBDA ; mov #0,r0
    c.r[0] = 0xFFFFFFFFu;  // 060ACBD8 mov #-1,r0
L_060ACBDA:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060ACBDA lds.l @r15+,pr
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060ACBDC rts ; nop
}

void f_060ACBE0(SH2Context& c) {
    ran[2881] = 1;
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060ACBE0 sts.l pr,@-r15
    c.pr = 0x060ACBE6u; SH2_POLL(c); sh2_call(c, 0x060ACA2Cu); if (c.pc != 0x060ACBE6u) return;  // 060ACBE2 bsr 0x060ACA2C ; nop
    c.t = c.r[0] == 0x1u;  // 060ACBE6 cmp/eq #1,r0
    if (c.t) { goto L_060ACBEE; }  // 060ACBE8 bt 0x060ACBEE
    c.r[0] = 0x30u;  // 060ACBEA mov #48,r0
    c.r[4] |= c.r[0];  // 060ACBEC or r0,r4
L_060ACBEE:
    c.pr = 0x060ACBF2u; SH2_POLL(c); sh2_call(c, 0x060ACA36u); if (c.pc != 0x060ACBF2u) return;  // 060ACBEE bsr 0x060ACA36 ; nop
    c.t = c.r[0] == 0x1u;  // 060ACBF2 cmp/eq #1,r0
    if (c.t) { goto L_060ACBFA; }  // 060ACBF4 bt 0x060ACBFA
    c.r[0] = 0xFFFFFFC0u;  // 060ACBF6 mov #-64,r0
    c.r[4] |= c.r[0];  // 060ACBF8 or r0,r4
L_060ACBFA:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060ACBFA lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[0] = c.r[4]; c.pc = x; return; }  // 060ACBFC rts ; mov r4,r0
}

void f_060ACC00(SH2Context& c) {
    ran[2882] = 1;
    c.r[1] = ld32(0x060ACC54u);  // 060ACC00 mov.l 0x060ACC54,r1
    c.r[3] = ld32(0x060ACDE8u);  // 060ACC02 mov.l 0x060ACDE8,r3
    c.r[0] = ld32(c.r[1]);  // 060ACC04 mov.l @r1,r0
    c.r[2] = ld32(0x060ACC50u);  // 060ACC06 mov.l 0x060ACC50,r2
    c.r[3] = ld32(c.r[3]);  // 060ACC08 mov.l @r3,r3
    c.r[0] += 7;  // 060ACC0A add #7,r0
    st32(c.r[1], c.r[0]);  // 060ACC0C mov.l r0,@r1
    c.r[3] += c.r[0];  // 060ACC0E add r0,r3
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 060ACC10 shlr r2
    c.r[3] += c.r[2];  // 060ACC12 add r2,r3
    c.r[2] = ld32(0x060ACC58u);  // 060ACC14 mov.l 0x060ACC58,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x060ACC64u);  // 060ACC16 mov.w 0x060ACC64,r1
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[2]);  // 060ACC18 mov.w @r2,r0
    c.t = (c.r[0] & c.r[1]) == 0;  // 060ACC1A tst r1,r0
    { const bool k = !c.t; c.r[0] ^= c.r[0]; if (k) { goto L_060ACC2A; } }  // 060ACC1C bf/s 0x060ACC2A ; xor r0,r0
    c.r[3] -= 1; st8(c.r[3], c.r[0]);  // 060ACC20 mov.b r0,@-r3
    c.r[3] -= 1; st8(c.r[3], c.r[0]);  // 060ACC22 mov.b r0,@-r3
    c.r[3] -= 1; st8(c.r[3], c.r[0]);  // 060ACC24 mov.b r0,@-r3
    c.r[3] -= 1; st8(c.r[3], c.r[0]); goto L_060ACC44;  // 060ACC26 bra 0x060ACC44 ; mov.b r0,@-r3
L_060ACC2A:
    c.r[2] = ld32(0x060ACC60u);  // 060ACC2A mov.l 0x060ACC60,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x060ACC66u);  // 060ACC2C mov.w 0x060ACC66,r1
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[2]);  // 060ACC2E mov.w @r2,r0
    c.r[2] = ld32(0x060ACC5Cu);  // 060ACC30 mov.l 0x060ACC5C,r2
    c.r[0] &= c.r[1];  // 060ACC32 and r1,r0
    c.r[3] -= 1; st8(c.r[3], c.r[0]);  // 060ACC34 mov.b r0,@-r3
    c.r[0] >>= 8;  // 060ACC36 shlr8 r0
    c.r[3] -= 1; st8(c.r[3], c.r[0]);  // 060ACC38 mov.b r0,@-r3
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[2]);  // 060ACC3A mov.w @r2,r0
    c.r[0] &= c.r[1];  // 060ACC3C and r1,r0
    c.r[3] -= 1; st8(c.r[3], c.r[0]);  // 060ACC3E mov.b r0,@-r3
    c.r[0] >>= 8;  // 060ACC40 shlr8 r0
    c.r[3] -= 1; st8(c.r[3], c.r[0]);  // 060ACC42 mov.b r0,@-r3
L_060ACC44:
    c.r[3] -= 1; st8(c.r[3], c.r[4]);  // 060ACC44 mov.b r4,@-r3
    c.r[0] = 0x25u;  // 060ACC46 mov #37,r0
    c.r[3] -= 1; st8(c.r[3], c.r[0]);  // 060ACC48 mov.b r0,@-r3
    c.r[0] = 0xFFFFFFF1u;  // 060ACC4A mov #-15,r0
    { const uint32_t x = c.pr; c.r[3] -= 1; st8(c.r[3], c.r[0]); c.pc = x; return; }  // 060ACC4C rts ; mov.b r0,@-r3
}

void f_060ACC68(SH2Context& c) {
    ran[2883] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[4]);  // 060ACC68 mov.l r4,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060ACC6A sts.l pr,@-r15
    c.r[2] = ld32(0x060ACCCCu);  // 060ACC6C mov.l 0x060ACCCC,r2
    c.pr = 0x060ACC72u; c.r[4] = (uint32_t)(int8_t)ld8(c.r[2]); SH2_POLL(c); sh2_call(c, 0x060ACA2Cu); if (c.pc != 0x060ACC72u) return;  // 060ACC6E bsr 0x060ACA2C ; mov.b @r2,r4
    c.t = c.r[0] == 0x1u;  // 060ACC72 cmp/eq #1,r0
    { const bool k = c.t; c.r[0] = c.r[4]; if (k) { goto L_060ACC9A; } }  // 060ACC74 bt/s 0x060ACC9A ; mov r4,r0
    c.t = c.r[0] == 0x0u;  // 060ACC78 cmp/eq #0,r0
    if (c.t) { goto L_060ACC8E; }  // 060ACC7A bt 0x060ACC8E
    c.r[15] -= 4; st32(c.r[15], c.r[4]);  // 060ACC7C mov.l r4,@-r15
    c.pr = 0x060ACC82u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, 0x060ACAC4u); if (c.pc != 0x060ACC82u) return;  // 060ACC7E bsr 0x060ACAC4 ; mov #1,r4
    c.pr = 0x060ACC86u; SH2_POLL(c); sh2_call(c, 0x060ACA00u); if (c.pc != 0x060ACC86u) return;  // 060ACC82 bsr 0x060ACA00 ; nop
    c.pr = 0x060ACC8Au; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, 0x060ACC00u); if (c.pc != 0x060ACC8Au) return;  // 060ACC86 bsr 0x060ACC00 ; mov r0,r4
    c.r[4] = ld32(c.r[15]); c.r[15] += 4; goto L_060ACC9A;  // 060ACC8A bra 0x060ACC9A ; mov.l @r15+,r4
L_060ACC8E:
    c.t = c.r[0] == 0x1u;  // 060ACC8E cmp/eq #1,r0
    if (c.t) { goto L_060ACC9A; }  // 060ACC90 bt 0x060ACC9A
    c.r[15] -= 4; st32(c.r[15], c.r[4]);  // 060ACC92 mov.l r4,@-r15
    c.pr = 0x060ACC98u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, 0x060ACAC4u); if (c.pc != 0x060ACC98u) return;  // 060ACC94 bsr 0x060ACAC4 ; mov #0,r4
    c.r[4] = ld32(c.r[15]); c.r[15] += 4;  // 060ACC98 mov.l @r15+,r4
L_060ACC9A:
    c.pr = 0x060ACC9Eu; SH2_POLL(c); sh2_call(c, 0x060ACA36u); if (c.pc != 0x060ACC9Eu) return;  // 060ACC9A bsr 0x060ACA36 ; nop
    c.t = c.r[0] == 0x1u;  // 060ACC9E cmp/eq #1,r0
    { const bool k = c.t; c.r[0] = c.r[4]; if (k) { goto L_060ACCC6; } }  // 060ACCA0 bt/s 0x060ACCC6 ; mov r4,r0
    c.t = c.r[0] == 0x1u;  // 060ACCA4 cmp/eq #1,r0
    if (c.t) { goto L_060ACCBA; }  // 060ACCA6 bt 0x060ACCBA
    c.r[15] -= 4; st32(c.r[15], c.r[4]);  // 060ACCA8 mov.l r4,@-r15
    c.pr = 0x060ACCAEu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, 0x060ACAF4u); if (c.pc != 0x060ACCAEu) return;  // 060ACCAA bsr 0x060ACAF4 ; mov #1,r4
    c.pr = 0x060ACCB2u; SH2_POLL(c); sh2_call(c, 0x060ACA08u); if (c.pc != 0x060ACCB2u) return;  // 060ACCAE bsr 0x060ACA08 ; nop
    c.pr = 0x060ACCB6u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, 0x060ACC00u); if (c.pc != 0x060ACCB6u) return;  // 060ACCB2 bsr 0x060ACC00 ; mov r0,r4
    c.r[4] = ld32(c.r[15]); c.r[15] += 4; goto L_060ACCC6;  // 060ACCB6 bra 0x060ACCC6 ; mov.l @r15+,r4
L_060ACCBA:
    c.t = c.r[0] == 0x0u;  // 060ACCBA cmp/eq #0,r0
    if (c.t) { goto L_060ACCC6; }  // 060ACCBC bt 0x060ACCC6
    c.r[15] -= 4; st32(c.r[15], c.r[4]);  // 060ACCBE mov.l r4,@-r15
    c.pr = 0x060ACCC4u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, 0x060ACAF4u); if (c.pc != 0x060ACCC4u) return;  // 060ACCC0 bsr 0x060ACAF4 ; mov #0,r4
    c.r[4] = ld32(c.r[15]); c.r[15] += 4;  // 060ACCC4 mov.l @r15+,r4
L_060ACCC6:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060ACCC6 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[4] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060ACCC8 rts ; mov.l @r15+,r4
}

void f_060ACCD0(SH2Context& c) {
    ran[2884] = 1;
    c.r[3] = ld32(0x060AD004u);  // 060ACCD0 mov.l 0x060AD004,r3
    c.r[2] = ld32(0x060AD008u);  // 060ACCD2 mov.l 0x060AD008,r2
    c.r[3] = ld32(c.r[3]);  // 060ACCD4 mov.l @r3,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[2]);  // 060ACCD6 mov.w @r2,r2
    c.r[1] = 0x1Eu;  // 060ACCD8 mov #30,r1
    c.r[0] = 0xFFFFFFFFu;  // 060ACCDA mov #-1,r0
L_060ACCDC:
    st8(c.r[3], c.r[0]);  // 060ACCDC mov.b r0,@(0,r3)
    c.r[1] -= 1; c.t = c.r[1] == 0;  // 060ACCDE dt r1
    { const bool k = !c.t; c.r[3] += c.r[2]; if (k) { SH2_POLL(c); goto L_060ACCDC; } }  // 060ACCE0 bf/s 0x060ACCDC ; add r2,r3
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060ACCE4 rts ; nop
}

void f_060ACCE8(SH2Context& c) {
    ran[2885] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[4]);  // 060ACCE8 mov.l r4,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060ACCEA sts.l pr,@-r15
    c.r[2] = ld32(0x060ACDE4u);  // 060ACCEC mov.l 0x060ACDE4,r2
    c.r[3] = ld32(0x060ACDE8u);  // 060ACCEE mov.l 0x060ACDE8,r3
    c.r[0] = ld32(0x060ACDECu);  // 060ACCF0 mov.l 0x060ACDEC,r0
    c.r[1] = ld32(0x060ACDF0u);  // 060ACCF2 mov.l 0x060ACDF0,r1
    st32(c.r[2], c.r[0]);  // 060ACCF4 mov.l r0,@r2
    st32(c.r[3], c.r[1]);  // 060ACCF6 mov.l r1,@r3
    c.r[2] = ld32(0x060AD004u);  // 060ACCF8 mov.l 0x060AD004,r2
    c.r[3] = ld32(0x060AD008u);  // 060ACCFA mov.l 0x060AD008,r3
    c.r[0] = ld32(0x060ACDF4u);  // 060ACCFC mov.l 0x060ACDF4,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x060ACDF8u);  // 060ACCFE mov.w 0x060ACDF8,r1
    st32(c.r[2], c.r[0]);  // 060ACD00 mov.l r0,@r2
    st16(c.r[3], c.r[1]);  // 060ACD02 mov.w r1,@r3
    c.r[2] = ld32(0x060ACDE0u);  // 060ACD04 mov.l 0x060ACDE0,r2
    c.r[0] = 0xFFFFFF80u;  // 060ACD06 mov #-128,r0
    c.r[3] = ld32(0x060ACDDCu);  // 060ACD08 mov.l 0x060ACDDC,r3
    st8(c.r[2], c.r[0]);  // 060ACD0A mov.b r0,@(0,r2)
    c.r[1] = ld32(0x060AD0C0u);  // 060ACD0C mov.l 0x060AD0C0,r1
    c.r[0] ^= c.r[0];  // 060ACD0E xor r0,r0
    st8(c.r[1], c.r[0]);  // 060ACD10 mov.b r0,@r1
    c.r[4] ^= c.r[4];  // 060ACD12 xor r4,r4
    st8(c.r[2] + 1, c.r[0]);  // 060ACD14 mov.b r0,@(1,r2)
    c.r[1] = ld32(0x060AD0C4u);  // 060ACD16 mov.l 0x060AD0C4,r1
    st8(c.r[2] + 2, c.r[0]);  // 060ACD18 mov.b r0,@(2,r2)
    st8(c.r[1], c.r[0]);  // 060ACD1A mov.b r0,@r1
    st8(c.r[2] + 3, c.r[0]);  // 060ACD1C mov.b r0,@(3,r2)
    st32(c.r[3], c.r[4]);  // 060ACD1E mov.l r4,@(0,r3)
    st8(c.r[2] + 4, c.r[0]);  // 060ACD20 mov.b r0,@(4,r2)
    st32(c.r[3] + 4, c.r[4]);  // 060ACD22 mov.l r4,@(4,r3)
    st8(c.r[2] + 5, c.r[0]);  // 060ACD24 mov.b r0,@(5,r2)
    st32(c.r[3] + 8, c.r[4]);  // 060ACD26 mov.l r4,@(8,r3)
    st8(c.r[2] + 6, c.r[0]);  // 060ACD28 mov.b r0,@(6,r2)
    st32(c.r[3] + 12, c.r[4]);  // 060ACD2A mov.l r4,@(12,r3)
    st8(c.r[2] + 7, c.r[0]);  // 060ACD2C mov.b r0,@(7,r2)
    st32(c.r[3] + 16, c.r[4]);  // 060ACD2E mov.l r4,@(16,r3)
    st8(c.r[2] + 8, c.r[0]);  // 060ACD30 mov.b r0,@(8,r2)
    st32(c.r[3] + 20, c.r[4]);  // 060ACD32 mov.l r4,@(20,r3)
    st8(c.r[2] + 9, c.r[0]);  // 060ACD34 mov.b r0,@(9,r2)
    st32(c.r[3] + 24, c.r[4]);  // 060ACD36 mov.l r4,@(24,r3)
    st8(c.r[2] + 10, c.r[0]);  // 060ACD38 mov.b r0,@(10,r2)
    st32(c.r[3] + 28, c.r[4]);  // 060ACD3A mov.l r4,@(28,r3)
    st8(c.r[2] + 11, c.r[0]);  // 060ACD3C mov.b r0,@(11,r2)
    st32(c.r[3] + 32, c.r[4]);  // 060ACD3E mov.l r4,@(32,r3)
    st8(c.r[2] + 12, c.r[0]);  // 060ACD40 mov.b r0,@(12,r2)
    st32(c.r[3] + 36, c.r[4]);  // 060ACD42 mov.l r4,@(36,r3)
    c.r[1] = ld32(0x060AD118u);  // 060ACD44 mov.l 0x060AD118,r1
    c.r[2] = 0xFFFFFFFFu;  // 060ACD46 mov #-1,r2
    c.pr = 0x060ACD4Cu; st8(c.r[0] + c.r[1], c.r[2]); SH2_POLL(c); sh2_call(c, 0x060ACCD0u); if (c.pc != 0x060ACD4Cu) return;  // 060ACD48 bsr 0x060ACCD0 ; mov.b r2,@(r0,r1)
    c.pr = 0x060ACD50u; SH2_POLL(c); sh2_call(c, 0x060AC97Eu); if (c.pc != 0x060ACD50u) return;  // 060ACD4C bsr 0x060AC97E ; nop
    c.pr = 0x060ACD54u; c.r[4] ^= c.r[4]; SH2_POLL(c); sh2_call(c, 0x060AC99Cu); if (c.pc != 0x060ACD54u) return;  // 060ACD50 bsr 0x060AC99C ; xor r4,r4
    c.pr = 0x060ACD58u; c.r[4] ^= c.r[4]; SH2_POLL(c); sh2_call(c, 0x060AC9C6u); if (c.pc != 0x060ACD58u) return;  // 060ACD54 bsr 0x060AC9C6 ; xor r4,r4
    c.pr = 0x060ACD5Cu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, 0x060ACA40u); if (c.pc != 0x060ACD5Cu) return;  // 060ACD58 bsr 0x060ACA40 ; mov #1,r4
    c.pr = 0x060ACD60u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, 0x060ACA74u); if (c.pc != 0x060ACD60u) return;  // 060ACD5C bsr 0x060ACA74 ; mov #1,r4
    c.pr = 0x060ACD64u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, 0x060ACAC4u); if (c.pc != 0x060ACD64u) return;  // 060ACD60 bsr 0x060ACAC4 ; mov #1,r4
    c.pr = 0x060ACD68u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, 0x060ACAF4u); if (c.pc != 0x060ACD68u) return;  // 060ACD64 bsr 0x060ACAF4 ; mov #1,r4
    c.pr = 0x060ACD6Cu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, 0x060AD1AEu); if (c.pc != 0x060ACD6Cu) return;  // 060ACD68 bsr 0x060AD1AE ; mov #1,r4
    c.pr = 0x060ACD70u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, 0x060AD1EEu); if (c.pc != 0x060ACD70u) return;  // 060ACD6C bsr 0x060AD1EE ; mov #0,r4
    c.pr = 0x060ACD74u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, 0x060AD22Cu); if (c.pc != 0x060ACD74u) return;  // 060ACD70 bsr 0x060AD22C ; mov #0,r4
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060ACD74 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[4] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060ACD76 rts ; mov.l @r15+,r4
}

void f_060ACD7A(SH2Context& c) {
    ran[2886] = 1;
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060ACD7A sts.l pr,@-r15
    c.pr = 0x060ACD80u; SH2_POLL(c); sh2_call(c, 0x060AC974u); if (c.pc != 0x060ACD80u) return;  // 060ACD7C bsr 0x060AC974 ; nop
    c.t = c.r[0] == 0x0u;  // 060ACD80 cmp/eq #0,r0
    if (!c.t) { goto L_060ACDA0; }  // 060ACD82 bf 0x060ACDA0
    c.pr = 0x060ACD88u; SH2_POLL(c); sh2_call(c, 0x060ACE06u); if (c.pc != 0x060ACD88u) return;  // 060ACD84 bsr 0x060ACE06 ; nop
    c.t = c.r[0] == 0x0u;  // 060ACD88 cmp/eq #0,r0
    if (!c.t) { goto L_060ACD9C; }  // 060ACD8A bf 0x060ACD9C
    c.r[1] = ld32(0x060ACDE8u);  // 060ACD8C mov.l 0x060ACDE8,r1
    c.r[2] = ld32(0x060AD004u);  // 060ACD8E mov.l 0x060AD004,r2
    c.r[3] = ld32(0x060AD008u);  // 060ACD90 mov.l 0x060AD008,r3
    st32(c.r[1], c.r[4]);  // 060ACD92 mov.l r4,@r1
    st32(c.r[2], c.r[5]);  // 060ACD94 mov.l r5,@r2
    c.pr = 0x060ACD9Au; st16(c.r[3], c.r[6]); SH2_POLL(c); sh2_call(c, 0x060ACCD0u); if (c.pc != 0x060ACD9Au) return;  // 060ACD96 bsr 0x060ACCD0 ; mov.w r6,@r3
    c.r[0] = 0x0u;  // 060ACD9A mov #0,r0
L_060ACD9C:
    c.pr = 0x060ACDA0u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, 0x060AC97Eu); if (c.pc != 0x060ACDA0u) return;  // 060ACD9C bsr 0x060AC97E ; mov r0,r4
L_060ACDA0:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060ACDA0 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060ACDA2 rts ; nop
}

void f_060ACDA6(SH2Context& c) {
    ran[2887] = 1;
    c.r[1] = 0x0u;  // 060ACDA6 mov #0,r1
    c.t = c.r[5] == c.r[1];  // 060ACDA8 cmp/eq r1,r5
    { const bool k = !c.t; c.r[5] = 0xFFFFFFFFu; if (k) { goto L_060ACDD6; } }  // 060ACDAA bf/s 0x060ACDD6 ; mov #-1,r5
    c.r[3] = ld32(0x060AD120u);  // 060ACDAE mov.l 0x060AD120,r3
    c.r[2] = ld32(0x060AD11Cu);  // 060ACDB0 mov.l 0x060AD11C,r2
    c.r[0] = ld32(c.r[3]);  // 060ACDB2 mov.l @r3,r0
    c.r[1] = ld32(c.r[2]);  // 060ACDB4 mov.l @r2,r1
    c.r[4] = c.r[0];  // 060ACDB6 mov r0,r4
    c.r[0] += 1;  // 060ACDB8 add #1,r0
    c.r[0] &= 0x1Fu;  // 060ACDBA and #31,r0
    c.t = c.r[0] == c.r[1];  // 060ACDBC cmp/eq r1,r0
    { const bool k = c.t; c.r[5] = 0xFFFFFFFFu; if (k) { goto L_060ACDD6; } }  // 060ACDBE bt/s 0x060ACDD6 ; mov #-1,r5
    c.r[2] = ld32(0x060AD118u);  // 060ACDC2 mov.l 0x060AD118,r2
    st32(c.r[3], c.r[0]);  // 060ACDC4 mov.l r0,@r3
    c.r[1] = 0xFFFFFFFFu;  // 060ACDC6 mov #-1,r1
    c.r[5] = ld32(0x060ACDE0u);  // 060ACDC8 mov.l 0x060ACDE0,r5
    st8(c.r[0] + c.r[2], c.r[1]);  // 060ACDCA mov.b r1,@(r0,r2)
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[5] + 4);  // 060ACDCC mov.b @(4,r5),r0
    c.r[5] = 0x0u;  // 060ACDCE mov #0,r5
    c.r[1] = c.r[0];  // 060ACDD0 mov r0,r1
    c.r[0] = c.r[4];  // 060ACDD2 mov r4,r0
    st8(c.r[0] + c.r[2], c.r[1]);  // 060ACDD4 mov.b r1,@(r0,r2)
L_060ACDD6:
    { const uint32_t x = c.pr; c.r[0] = c.r[5]; c.pc = x; return; }  // 060ACDD6 rts ; mov r5,r0
}

void f_060ACDFA(SH2Context& c) {
    ran[2888] = 1;
    c.r[2] = ld32(0x060AD140u);  // 060ACDFA mov.l 0x060AD140,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060ACDFC mov.b @r2,r0
    c.t = (c.r[0] & 0x4u) == 0;  // 060ACDFE tst #4,r0
    c.r[0] = c.t;  // 060ACE00 movt r0
    { const uint32_t x = c.pr; c.r[0] -= 1; c.pc = x; return; }  // 060ACE02 rts ; add #-1,r0
}

void f_060ACE06(SH2Context& c) {
    ran[2889] = 1;
    c.r[2] = ld32(0x060AD140u);  // 060ACE06 mov.l 0x060AD140,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060ACE08 mov.b @r2,r0
    c.t = (c.r[0] & 0x2u) == 0;  // 060ACE0A tst #2,r0
    c.r[0] = c.t;  // 060ACE0C movt r0
    { const uint32_t x = c.pr; c.r[0] -= 1; c.pc = x; return; }  // 060ACE0E rts ; add #-1,r0
}

void f_060ACE12(SH2Context& c) {
    ran[2890] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[4]);  // 060ACE12 mov.l r4,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060ACE14 sts.l pr,@-r15
    c.pr = 0x060ACE1Au; SH2_POLL(c); sh2_call(c, 0x060AC974u); if (c.pc != 0x060ACE1Au) return;  // 060ACE16 bsr 0x060AC974 ; nop
    c.t = c.r[0] == 0x0u;  // 060ACE1A cmp/eq #0,r0
    if (!c.t) { goto L_060ACE2C; }  // 060ACE1C bf 0x060ACE2C
    c.r[2] = ld32(0x060AD140u);  // 060ACE1E mov.l 0x060AD140,r2
    c.r[4] = c.r[0];  // 060ACE20 mov r0,r4
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060ACE22 mov.b @r2,r0
    c.r[0] |= 0x2u;  // 060ACE24 or #2,r0
    c.r[0] ^= 0x2u;  // 060ACE26 xor #2,r0
    c.pr = 0x060ACE2Cu; st8(c.r[2], c.r[0]); SH2_POLL(c); sh2_call(c, 0x060AC97Eu); if (c.pc != 0x060ACE2Cu) return;  // 060ACE28 bsr 0x060AC97E ; mov.b r0,@r2
L_060ACE2C:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060ACE2C lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[4] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060ACE2E rts ; mov.l @r15+,r4
}

void f_060ACE32(SH2Context& c) {
    ran[2891] = 1;
    c.r[2] = ld32(0x060AD140u);  // 060ACE32 mov.l 0x060AD140,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060ACE34 mov.b @r2,r0
    c.r[0] |= 0x2u;  // 060ACE36 or #2,r0
    { const uint32_t x = c.pr; st8(c.r[2], c.r[0]); c.pc = x; return; }  // 060ACE38 rts ; mov.b r0,@r2
}

void f_060ACE46(SH2Context& c) {
    ran[2892] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[4]);  // 060ACE46 mov.l r4,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060ACE48 sts.l pr,@-r15
    c.pr = 0x060ACE4Eu; SH2_POLL(c); sh2_call(c, 0x060AC974u); if (c.pc != 0x060ACE4Eu) return;  // 060ACE4A bsr 0x060AC974 ; nop
    c.t = c.r[0] == 0x0u;  // 060ACE4E cmp/eq #0,r0
    if (!c.t) { goto L_060ACE66; }  // 060ACE50 bf 0x060ACE66
    c.r[4] = c.r[0];  // 060ACE52 mov r0,r4
    c.r[2] = ld32(0x060AD140u);  // 060ACE54 mov.l 0x060AD140,r2
    c.r[1] ^= c.r[1];  // 060ACE56 xor r1,r1
    c.r[3] = ld32(0x060ACE90u);  // 060ACE58 mov.l 0x060ACE90,r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060ACE5A mov.b @r2,r0
    st8(c.r[3], c.r[1]);  // 060ACE5C mov.b r1,@r3
    c.r[0] |= 0x1u;  // 060ACE5E or #1,r0
    c.r[0] ^= 0x1u;  // 060ACE60 xor #1,r0
    c.pr = 0x060ACE66u; st8(c.r[2], c.r[0]); SH2_POLL(c); sh2_call(c, 0x060AC97Eu); if (c.pc != 0x060ACE66u) return;  // 060ACE62 bsr 0x060AC97E ; mov.b r0,@r2
L_060ACE66:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060ACE66 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[4] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060ACE68 rts ; mov.l @r15+,r4
}

void f_060ACE6C(SH2Context& c) {
    ran[2893] = 1;
    c.r[2] = ld32(0x060AD130u);  // 060ACE6C mov.l 0x060AD130,r2
    c.r[3] = ld32(0x060ACE90u);  // 060ACE6E mov.l 0x060ACE90,r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060ACE70 mov.b @r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060ACE72 mov.b @r3,r1
    c.t = (c.r[0] & 0x10u) == 0;  // 060ACE74 tst #16,r0
    if (c.t) { goto L_060ACE8C; }  // 060ACE76 bt 0x060ACE8C
    c.r[0] = 0x3u;  // 060ACE78 mov #3,r0
    c.r[1] += 1;  // 060ACE7A add #1,r1
    c.r[2] = ld32(0x060AD140u);  // 060ACE7C mov.l 0x060AD140,r2
    c.t = c.r[0] > c.r[1];  // 060ACE7E cmp/hi r1,r0
    if (c.t) { goto L_060ACE8A; }  // 060ACE80 bt 0x060ACE8A
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060ACE82 mov.b @r2,r0
    c.r[1] ^= c.r[1];  // 060ACE84 xor r1,r1
    c.r[0] |= 0x1u;  // 060ACE86 or #1,r0
    st8(c.r[2], c.r[0]);  // 060ACE88 mov.b r0,@r2
L_060ACE8A:
    st8(c.r[3], c.r[1]);  // 060ACE8A mov.b r1,@r3
L_060ACE8C:
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060ACE8C rts ; nop
}

void f_060ACE94(SH2Context& c) {
    ran[2894] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[6]);  // 060ACE94 mov.l r6,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060ACE96 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060ACE98 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 060ACE9A mov.l r7,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060ACE9C sts.l pr,@-r15
    c.r[8] ^= c.r[8];  // 060ACE9E xor r8,r8
    c.r[15] -= 4; st32(c.r[15], c.r[5]);  // 060ACEA0 mov.l r5,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[4]);  // 060ACEA2 mov.l r4,@-r15
    c.r[4] = ld32(c.r[4]);  // 060ACEA4 mov.l @r4,r4
    c.r[5] = ld32(c.r[5]);  // 060ACEA6 mov.l @r5,r5
    c.r[2] = ld32(0x060AD008u);  // 060ACEA8 mov.l 0x060AD008,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 060ACEAA mov.b @r4+,r0
    c.r[9] = (uint32_t)(int16_t)ld16(c.r[2]);  // 060ACEAC mov.w @r2,r9
    c.t = c.r[0] == 0xFFFFFFF0u;  // 060ACEAE cmp/eq #-16,r0
    { const bool k = c.t; c.r[0] &= 0xFu; if (k) { goto L_060ACEC8; } }  // 060ACEB0 bt/s 0x060ACEC8 ; and #15,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060ACEB4 tst r0,r0
    if (!c.t) { goto L_060ACEC8; }  // 060ACEB6 bf 0x060ACEC8
    c.r[4] -= 1;  // 060ACEB8 add #-1,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]);  // 060ACEBA mov.b @r4,r1
    c.r[2] = 0xFFFFFFF0u;  // 060ACEBC mov #-16,r2
    c.r[1] >>= 2;  // 060ACEBE shlr2 r1
    c.r[1] >>= 2;  // 060ACEC0 shlr2 r1
    c.r[1] |= c.r[2];  // 060ACEC2 or r2,r1
    st8(c.r[4], c.r[1]);  // 060ACEC4 mov.b r1,@r4
    c.r[0] += 1;  // 060ACEC6 add #1,r0
L_060ACEC8:
    c.r[6] = c.r[0];  // 060ACEC8 mov r0,r6
    c.r[7] = 0xFu;  // 060ACECA mov #15,r7
L_060ACECC:
    c.t = (c.r[6] & c.r[6]) == 0;  // 060ACECC tst r6,r6
    if (c.t) { goto L_060ACEDC; }  // 060ACECE bt 0x060ACEDC
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4]);  // 060ACED0 mov.b @r4,r0
    c.r[6] -= 1;  // 060ACED2 add #-1,r6
    c.t = c.r[0] == 0xFFFFFFFFu;  // 060ACED4 cmp/eq #-1,r0
    if (c.t) { goto L_060ACEE2; }  // 060ACED6 bt 0x060ACEE2
    c.r[8] += 1; goto L_060ACEE2;  // 060ACED8 bra 0x060ACEE2 ; add #1,r8
L_060ACEDC:
    c.r[4] -= 1;  // 060ACEDC add #-1,r4
    c.r[0] = 0xFFFFFFFFu;  // 060ACEDE mov #-1,r0
    st8(c.r[4], c.r[0]);  // 060ACEE0 mov.b r0,@r4
L_060ACEE2:
    c.r[1] = c.r[0];  // 060ACEE2 mov r0,r1
    c.r[2] = 0xFFFFFFF0u;  // 060ACEE4 mov #-16,r2
    c.r[2] = c.r[2] & 0xFFu;  // 060ACEE6 extu.b r2,r2
    c.r[2] &= c.r[1];  // 060ACEE8 and r1,r2
    c.r[0] = ld32(0x060ACF30u);  // 060ACEEA mov.l 0x060ACF30,r0
    c.r[2] >>= 2;  // 060ACEEC shlr2 r2
    c.r[0] = ld32(c.r[0] + c.r[2]);  // 060ACEEE mov.l @(r0,r2),r0
    c.r[2] = 0xFu;  // 060ACEF0 mov #15,r2
    c.r[2] &= c.r[1];  // 060ACEF2 and r1,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 060ACEF4 mov.b @(r0,r2),r2
    c.r[0] = ld32(0x060ACF2Cu);  // 060ACEF6 mov.l 0x060ACF2C,r0
    c.r[2] = c.r[2] & 0xFFu;  // 060ACEF8 extu.b r2,r2
    c.r[0] = ld32(c.r[0] + c.r[2]);  // 060ACEFA mov.l @(r0,r2),r0
    c.r[15] -= 4; st32(c.r[15], c.r[6]);  // 060ACEFC mov.l r6,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[5]);  // 060ACEFE mov.l r5,@-r15
    { const uint32_t x = c.r[0]; c.pr = 0x060ACF04u; c.r[6] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060ACF04u) return; }  // 060ACF00 jsr @r0 ; mov r9,r6
    c.r[5] = ld32(c.r[15]); c.r[15] += 4;  // 060ACF04 mov.l @r15+,r5
    c.r[6] = ld32(c.r[15]); c.r[15] += 4;  // 060ACF06 mov.l @r15+,r6
    c.r[5] += c.r[9];  // 060ACF08 add r9,r5
    c.r[7] -= 1; c.t = c.r[7] == 0;  // 060ACF0A dt r7
    { const bool k = !c.t; c.r[4] = c.r[0]; if (k) { SH2_POLL(c); goto L_060ACECC; } }  // 060ACF0C bf/s 0x060ACECC ; mov r0,r4
    c.r[0] = c.r[4];  // 060ACF10 mov r4,r0
    c.r[1] = c.r[5];  // 060ACF12 mov r5,r1
    c.r[4] = ld32(c.r[15]); c.r[15] += 4;  // 060ACF14 mov.l @r15+,r4
    c.r[5] = ld32(c.r[15]); c.r[15] += 4;  // 060ACF16 mov.l @r15+,r5
    st32(c.r[4], c.r[0]);  // 060ACF18 mov.l r0,@r4
    st32(c.r[5], c.r[1]);  // 060ACF1A mov.l r1,@r5
    c.r[0] = c.r[8];  // 060ACF1C mov r8,r0
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060ACF1E lds.l @r15+,pr
    c.r[7] = ld32(c.r[15]); c.r[15] += 4;  // 060ACF20 mov.l @r15+,r7
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060ACF22 mov.l @r15+,r8
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060ACF24 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[6] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060ACF26 rts ; mov.l @r15+,r6
}

void f_060ACF34(SH2Context& c) {
    ran[2895] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[4]);  // 060ACF34 mov.l r4,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[5]);  // 060ACF36 mov.l r5,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060ACF38 sts.l pr,@-r15
    c.r[4] = ld32(0x060ACFFCu);  // 060ACF3A mov.l 0x060ACFFC,r4
    c.r[5] = ld32(0x060AD000u);  // 060ACF3C mov.l 0x060AD000,r5
    c.r[0] = ld32(0x060AD12Cu);  // 060ACF3E mov.l 0x060AD12C,r0
    c.r[1] = ld32(0x060AD004u);  // 060ACF40 mov.l 0x060AD004,r1
    c.r[0] = ld32(c.r[0]);  // 060ACF42 mov.l @r0,r0
    c.r[1] = ld32(c.r[1]);  // 060ACF44 mov.l @r1,r1
    st32(c.r[4], c.r[0]);  // 060ACF46 mov.l r0,@r4
    c.r[2] = ld32(0x060AD008u);  // 060ACF48 mov.l 0x060AD008,r2
    st32(c.r[5], c.r[1]);  // 060ACF4A mov.l r1,@r5
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[2]);  // 060ACF4C mov.w @r2,r2
    c.r[3] = 0xFu;  // 060ACF4E mov #15,r3
    c.macl = (c.r[3] & 0xFFFFu) * (c.r[2] & 0xFFFFu);  // 060ACF50 mulu.w r2,r3
    c.r[2] = ld32(0x060AD144u);  // 060ACF52 mov.l 0x060AD144,r2
    c.r[3] = c.macl;  // 060ACF54 sts macl,r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060ACF56 mov.b @r2,r0
    c.r[1] += c.r[3];  // 060ACF58 add r3,r1
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 060ACF5A mov.l r0,@-r15
    c.r[0] &= 0x3u;  // 060ACF5C and #3,r0
    c.t = c.r[0] == 0x3u;  // 060ACF5E cmp/eq #3,r0
    { const bool k = c.t; c.r[0] ^= c.r[0]; if (k) { goto L_060ACF70; } }  // 060ACF60 bt/s 0x060ACF70 ; xor r0,r0
    c.r[15] -= 4; st32(c.r[15], c.r[4]);  // 060ACF64 mov.l r4,@-r15
    c.pr = 0x060ACF6Au; c.r[15] -= 4; st32(c.r[15], c.r[5]); SH2_POLL(c); sh2_call(c, 0x060ACE94u); if (c.pc != 0x060ACF6Au) return;  // 060ACF66 bsr 0x060ACE94 ; mov.l r5,@-r15
    c.r[5] = ld32(c.r[15]); c.r[15] += 4;  // 060ACF6A mov.l @r15+,r5
    c.r[4] = ld32(c.r[15]); c.r[15] += 4;  // 060ACF6C mov.l @r15+,r4
    c.r[1] = ld32(c.r[5]);  // 060ACF6E mov.l @r5,r1
L_060ACF70:
    c.r[3] = ld32(0x060AD0C0u);  // 060ACF70 mov.l 0x060AD0C0,r3
    st32(c.r[5], c.r[1]);  // 060ACF72 mov.l r1,@r5
    st8(c.r[3], c.r[0]);  // 060ACF74 mov.b r0,@r3
    c.r[0] = ld32(c.r[15]); c.r[15] += 4;  // 060ACF76 mov.l @r15+,r0
    c.r[0] &= 0xCu;  // 060ACF78 and #12,r0
    c.t = c.r[0] == 0xCu;  // 060ACF7A cmp/eq #12,r0
    { const bool k = c.t; c.r[0] ^= c.r[0]; if (k) { goto L_060ACF8A; } }  // 060ACF7C bt/s 0x060ACF8A ; xor r0,r0
    c.r[15] -= 4; st32(c.r[15], c.r[4]);  // 060ACF80 mov.l r4,@-r15
    c.pr = 0x060ACF86u; c.r[15] -= 4; st32(c.r[15], c.r[5]); SH2_POLL(c); sh2_call(c, 0x060ACE94u); if (c.pc != 0x060ACF86u) return;  // 060ACF82 bsr 0x060ACE94 ; mov.l r5,@-r15
    c.r[5] = ld32(c.r[15]); c.r[15] += 4;  // 060ACF86 mov.l @r15+,r5
    c.r[4] = ld32(c.r[15]); c.r[15] += 4;  // 060ACF88 mov.l @r15+,r4
L_060ACF8A:
    c.r[3] = ld32(0x060AD0C4u);  // 060ACF8A mov.l 0x060AD0C4,r3
    st8(c.r[3], c.r[0]);  // 060ACF8C mov.b r0,@r3
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060ACF8E lds.l @r15+,pr
    c.r[5] = ld32(c.r[15]); c.r[15] += 4;  // 060ACF90 mov.l @r15+,r5
    { const uint32_t x = c.pr; c.r[4] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060ACF92 rts ; mov.l @r15+,r4
}

void f_060ACF96(SH2Context& c) {
    ran[2896] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[4]);  // 060ACF96 mov.l r4,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[5]);  // 060ACF98 mov.l r5,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060ACF9A sts.l pr,@-r15
    c.r[4] = ld32(0x060ACFFCu);  // 060ACF9C mov.l 0x060ACFFC,r4
    c.r[5] = ld32(0x060AD000u);  // 060ACF9E mov.l 0x060AD000,r5
    c.r[0] = ld32(0x060AD12Cu);  // 060ACFA0 mov.l 0x060AD12C,r0
    c.r[1] = ld32(0x060AD004u);  // 060ACFA2 mov.l 0x060AD004,r1
    c.r[0] = ld32(c.r[0]);  // 060ACFA4 mov.l @r0,r0
    c.r[2] = ld32(0x060ACFF8u);  // 060ACFA6 mov.l 0x060ACFF8,r2
    c.r[1] = ld32(c.r[1]);  // 060ACFA8 mov.l @r1,r1
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 060ACFAA shlr r2
    c.r[0] += c.r[2];  // 060ACFAC add r2,r0
    st32(c.r[4], c.r[0]);  // 060ACFAE mov.l r0,@r4
    c.r[2] = ld32(0x060AD008u);  // 060ACFB0 mov.l 0x060AD008,r2
    st32(c.r[5], c.r[1]);  // 060ACFB2 mov.l r1,@r5
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[2]);  // 060ACFB4 mov.w @r2,r2
    c.r[3] = 0xFu;  // 060ACFB6 mov #15,r3
    c.macl = (c.r[3] & 0xFFFFu) * (c.r[2] & 0xFFFFu);  // 060ACFB8 mulu.w r2,r3
    c.r[3] = c.macl;  // 060ACFBA sts macl,r3
    c.r[1] += c.r[3];  // 060ACFBC add r3,r1
    c.pr = 0x060ACFC2u; c.r[15] -= 4; st32(c.r[15], c.r[1]); SH2_POLL(c); sh2_call(c, 0x060ACA2Cu); if (c.pc != 0x060ACFC2u) return;  // 060ACFBE bsr 0x060ACA2C ; mov.l r1,@-r15
    c.r[1] = ld32(c.r[15]); c.r[15] += 4;  // 060ACFC2 mov.l @r15+,r1
    c.t = c.r[0] == 0x1u;  // 060ACFC4 cmp/eq #1,r0
    if (c.t) { goto L_060ACFD8; }  // 060ACFC6 bt 0x060ACFD8
    c.r[15] -= 4; st32(c.r[15], c.r[4]);  // 060ACFC8 mov.l r4,@-r15
    c.pr = 0x060ACFCEu; c.r[15] -= 4; st32(c.r[15], c.r[5]); SH2_POLL(c); sh2_call(c, 0x060ACE94u); if (c.pc != 0x060ACFCEu) return;  // 060ACFCA bsr 0x060ACE94 ; mov.l r5,@-r15
    c.r[5] = ld32(c.r[15]); c.r[15] += 4;  // 060ACFCE mov.l @r15+,r5
    c.r[4] = ld32(c.r[15]); c.r[15] += 4;  // 060ACFD0 mov.l @r15+,r4
    c.r[3] = ld32(0x060AD0C0u);  // 060ACFD2 mov.l 0x060AD0C0,r3
    c.r[1] = ld32(c.r[5]);  // 060ACFD4 mov.l @r5,r1
    st8(c.r[3], c.r[0]);  // 060ACFD6 mov.b r0,@r3
L_060ACFD8:
    c.pr = 0x060ACFDCu; st32(c.r[5], c.r[1]); SH2_POLL(c); sh2_call(c, 0x060ACA36u); if (c.pc != 0x060ACFDCu) return;  // 060ACFD8 bsr 0x060ACA36 ; mov.l r1,@r5
    c.t = c.r[0] == 0x1u;  // 060ACFDC cmp/eq #1,r0
    if (c.t) { goto L_060ACFEE; }  // 060ACFDE bt 0x060ACFEE
    c.r[15] -= 4; st32(c.r[15], c.r[4]);  // 060ACFE0 mov.l r4,@-r15
    c.pr = 0x060ACFE6u; c.r[15] -= 4; st32(c.r[15], c.r[5]); SH2_POLL(c); sh2_call(c, 0x060ACE94u); if (c.pc != 0x060ACFE6u) return;  // 060ACFE2 bsr 0x060ACE94 ; mov.l r5,@-r15
    c.r[5] = ld32(c.r[15]); c.r[15] += 4;  // 060ACFE6 mov.l @r15+,r5
    c.r[3] = ld32(0x060AD0C4u);  // 060ACFE8 mov.l 0x060AD0C4,r3
    c.r[4] = ld32(c.r[15]); c.r[15] += 4;  // 060ACFEA mov.l @r15+,r4
    st8(c.r[3], c.r[0]);  // 060ACFEC mov.b r0,@r3
L_060ACFEE:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060ACFEE lds.l @r15+,pr
    c.r[5] = ld32(c.r[15]); c.r[15] += 4;  // 060ACFF0 mov.l @r15+,r5
    { const uint32_t x = c.pr; c.r[4] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060ACFF2 rts ; mov.l @r15+,r4
}

void f_060AD00C(SH2Context& c) {
    ran[2897] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[4]);  // 060AD00C mov.l r4,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[6]);  // 060AD00E mov.l r6,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[5]);  // 060AD010 mov.l r5,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060AD012 sts.l pr,@-r15
    c.r[0] = ld32(0x060AD124u);  // 060AD014 mov.l 0x060AD124,r0
    c.r[4] = (uint32_t)(int16_t)ld16(0x060AD128u);  // 060AD016 mov.w 0x060AD128,r4
    c.r[0] = ld32(c.r[0]);  // 060AD018 mov.l @r0,r0
    c.r[5] = (uint32_t)(int16_t)ld16(0x060AD12Au);  // 060AD01A mov.w 0x060AD12A,r5
    { const uint32_t x = c.r[0]; c.pr = 0x060AD020u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AD020u) return; }  // 060AD01C jsr @r0 ; nop
    c.r[6] = ld32(0x060AD11Cu);  // 060AD020 mov.l 0x060AD11C,r6
    c.pr = 0x060AD026u; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, 0x060AC974u); if (c.pc != 0x060AD026u) return;  // 060AD022 bsr 0x060AC974 ; mov #0,r5
    c.t = c.r[0] == 0x0u;  // 060AD026 cmp/eq #0,r0
    if (!c.t) { goto L_060AD0B6; }  // 060AD028 bf 0x060AD0B6
    c.r[0] = ld32(c.r[6]);  // 060AD02A mov.l @r6,r0
L_060AD02C:
    c.r[2] = ld32(0x060AD118u);  // 060AD02C mov.l 0x060AD118,r2
    c.r[1] = 0xFFFFFFFFu;  // 060AD02E mov #-1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 060AD030 mov.b @(r0,r2),r4
    c.t = c.r[4] == c.r[1];  // 060AD032 cmp/eq r1,r4
    if (c.t) { goto L_060AD05C; }  // 060AD034 bt 0x060AD05C
    c.r[0] += 1;  // 060AD036 add #1,r0
    c.r[0] &= 0x1Fu;  // 060AD038 and #31,r0
    c.pr = 0x060AD03Eu; st32(c.r[6], c.r[0]); SH2_POLL(c); sh2_call(c, 0x060ACB2Cu); if (c.pc != 0x060AD03Eu) return;  // 060AD03A bsr 0x060ACB2C ; mov.l r0,@r6
    c.pr = 0x060AD042u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, 0x060AD14Cu); if (c.pc != 0x060AD042u) return;  // 060AD03E bsr 0x060AD14C ; mov r0,r4
    c.r[2] = 0xFFFFFF84u;  // 060AD042 mov #-124,r2
    c.r[2] <<= 2;  // 060AD044 shll2 r2
    c.r[2] += 2;  // 060AD046 add #2,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]); c.r[2] += 1;  // 060AD048 mov.b @r2+,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060AD04A mov.b @r2+,r2
    c.r[0] <<= 8;  // 060AD04C shll8 r0
    c.r[2] = c.r[2] & 0xFFu;  // 060AD04E extu.b r2,r2
    c.r[0] |= c.r[2];  // 060AD050 or r2,r0
    c.r[1] = 0xFFFFFFCCu;  // 060AD052 mov #-52,r1
    c.t = (int32_t)c.r[0] >= (int32_t)c.r[1];  // 060AD054 cmp/ge r1,r0
    if (c.t) { goto L_060AD05C; }  // 060AD056 bt 0x060AD05C
    c.r[0] = ld32(c.r[6]); SH2_POLL(c); goto L_060AD02C;  // 060AD058 bra 0x060AD02C ; mov.l @r6,r0
L_060AD05C:
    c.r[6] = ld32(0x060AD140u);  // 060AD05C mov.l 0x060AD140,r6
    c.pr = 0x060AD062u; SH2_POLL(c); sh2_call(c, 0x060ACDFAu); if (c.pc != 0x060AD062u) return;  // 060AD05E bsr 0x060ACDFA ; nop
    c.r[3] = ld32(0x060AD13Cu);  // 060AD062 mov.l 0x060AD13C,r3
    c.r[2] ^= c.r[2];  // 060AD064 xor r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060AD066 mov.b @r3,r1
    c.t = c.r[0] == 0x0u;  // 060AD068 cmp/eq #0,r0
    { const bool k = c.t; st8(c.r[3], c.r[2]); if (k) { goto L_060AD088; } }  // 060AD06A bt/s 0x060AD088 ; mov.b r2,@r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[6]);  // 060AD06E mov.b @r6,r0
    c.r[0] ^= 0x4u;  // 060AD070 xor #4,r0
    c.t = (c.r[1] & c.r[1]) == 0;  // 060AD072 tst r1,r1
    { const bool k = !c.t; st8(c.r[6], c.r[0]); if (k) { goto L_060AD084; } }  // 060AD074 bf/s 0x060AD084 ; mov.b r0,@r6
    c.r[3] = ld32(0x060AD0C0u);  // 060AD078 mov.l 0x060AD0C0,r3
    c.r[1] ^= c.r[1];  // 060AD07A xor r1,r1
    st8(c.r[3], c.r[1]);  // 060AD07C mov.b r1,@r3
    c.r[3] = ld32(0x060AD0C4u);  // 060AD07E mov.l 0x060AD0C4,r3
    st8(c.r[3], c.r[1]); goto L_060AD0B2;  // 060AD080 bra 0x060AD0B2 ; mov.b r1,@r3
L_060AD084:
    c.pr = 0x060AD088u; SH2_POLL(c); sh2_call(c, 0x060ACF34u); if (c.pc != 0x060AD088u) return;  // 060AD084 bsr 0x060ACF34 ; nop
L_060AD088:
    c.r[2] = ld32(0x060AD138u);  // 060AD088 mov.l 0x060AD138,r2
    c.r[0] ^= c.r[0];  // 060AD08A xor r0,r0
    c.pr = 0x060AD090u; st32(c.r[2], c.r[0]); SH2_POLL(c); sh2_call(c, 0x060ACF96u); if (c.pc != 0x060AD090u) return;  // 060AD08C bsr 0x060ACF96 ; mov.l r0,@r2
    c.pr = 0x060AD094u; SH2_POLL(c); sh2_call(c, 0x060ACE06u); if (c.pc != 0x060AD094u) return;  // 060AD090 bsr 0x060ACE06 ; nop
    c.t = c.r[0] == 0x0u;  // 060AD094 cmp/eq #0,r0
    if (c.t) { goto L_060AD0B2; }  // 060AD096 bt 0x060AD0B2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[6]);  // 060AD098 mov.b @r6,r0
    c.r[1] ^= c.r[1];  // 060AD09A xor r1,r1
    c.r[0] |= 0x4u;  // 060AD09C or #4,r0
    st8(c.r[6], c.r[0]);  // 060AD09E mov.b r0,@r6
    c.r[2] = ld32(0x060AD134u);  // 060AD0A0 mov.l 0x060AD134,r2
    c.r[3] = ld32(0x060AD148u);  // 060AD0A2 mov.l 0x060AD148,r3
    st32(c.r[2], c.r[1]);  // 060AD0A4 mov.l r1,@r2
    st8(c.r[3], c.r[1]);  // 060AD0A6 mov.b r1,@r3
    c.r[2] = ld32(0x060AD354u);  // 060AD0A8 mov.l 0x060AD354,r2
    c.pr = 0x060AD0AEu; c.r[4] = (uint32_t)(int8_t)ld8(c.r[2]); SH2_POLL(c); sh2_call(c, 0x060ACB2Cu); if (c.pc != 0x060AD0AEu) return;  // 060AD0AA bsr 0x060ACB2C ; mov.b @r2,r4
    c.pr = 0x060AD0B2u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, 0x060AD14Cu); if (c.pc != 0x060AD0B2u) return;  // 060AD0AE bsr 0x060AD14C ; mov r0,r4
L_060AD0B2:
    c.pr = 0x060AD0B6u; SH2_POLL(c); sh2_call(c, 0x060AC97Eu); if (c.pc != 0x060AD0B6u) return;  // 060AD0B2 bsr 0x060AC97E ; nop
L_060AD0B6:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060AD0B6 lds.l @r15+,pr
    c.r[5] = ld32(c.r[15]); c.r[15] += 4;  // 060AD0B8 mov.l @r15+,r5
    c.r[6] = ld32(c.r[15]); c.r[15] += 4;  // 060AD0BA mov.l @r15+,r6
    { const uint32_t x = c.pr; c.r[4] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060AD0BC rts ; mov.l @r15+,r4
}

void f_060AD0C8(SH2Context& c) {
    ran[2898] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[4]);  // 060AD0C8 mov.l r4,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[6]);  // 060AD0CA mov.l r6,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[5]);  // 060AD0CC mov.l r5,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060AD0CE sts.l pr,@-r15
    c.r[6] = ld32(0x060AD11Cu);  // 060AD0D0 mov.l 0x060AD11C,r6
    c.pr = 0x060AD0D6u; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, 0x060AC974u); if (c.pc != 0x060AD0D6u) return;  // 060AD0D2 bsr 0x060AC974 ; mov #0,r5
    c.t = c.r[0] == 0x0u;  // 060AD0D6 cmp/eq #0,r0
    if (!c.t) { goto L_060AD10E; }  // 060AD0D8 bf 0x060AD10E
    c.pr = 0x060AD0DEu; SH2_POLL(c); sh2_call(c, 0x060ACDFAu); if (c.pc != 0x060AD0DEu) return;  // 060AD0DA bsr 0x060ACDFA ; nop
    c.t = c.r[0] == 0x0u;  // 060AD0DE cmp/eq #0,r0
    { const bool k = c.t; c.r[0] = ld32(c.r[6]); if (k) { goto L_060AD0EC; } }  // 060AD0E0 bt/s 0x060AD0EC ; mov.l @r6,r0
    c.r[3] = ld32(0x060AD13Cu);  // 060AD0E4 mov.l 0x060AD13C,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060AD0E6 mov.b @r3,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060AD0E8 tst r1,r1
    if (c.t) { goto L_060AD106; }  // 060AD0EA bt 0x060AD106
L_060AD0EC:
    c.r[2] = ld32(0x060AD118u);  // 060AD0EC mov.l 0x060AD118,r2
    c.r[1] = 0xFFFFFFFFu;  // 060AD0EE mov #-1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 060AD0F0 mov.b @(r0,r2),r4
    c.t = c.r[4] == c.r[1];  // 060AD0F2 cmp/eq r1,r4
    if (c.t) { goto L_060AD106; }  // 060AD0F4 bt 0x060AD106
    c.r[0] += 1;  // 060AD0F6 add #1,r0
    c.r[0] &= 0x1Fu;  // 060AD0F8 and #31,r0
    c.pr = 0x060AD0FEu; st32(c.r[6], c.r[0]); SH2_POLL(c); sh2_call(c, 0x060ACB2Cu); if (c.pc != 0x060AD0FEu) return;  // 060AD0FA bsr 0x060ACB2C ; mov.l r0,@r6
    c.pr = 0x060AD102u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, 0x060AD14Cu); if (c.pc != 0x060AD102u) return;  // 060AD0FE bsr 0x060AD14C ; mov r0,r4
    c.r[0] = ld32(c.r[6]); SH2_POLL(c); goto L_060AD0EC;  // 060AD102 bra 0x060AD0EC ; mov.l @r6,r0
L_060AD106:
    c.pr = 0x060AD10Au; SH2_POLL(c); sh2_call(c, 0x060ACE6Cu); if (c.pc != 0x060AD10Au) return;  // 060AD106 bsr 0x060ACE6C ; nop
    c.pr = 0x060AD10Eu; SH2_POLL(c); sh2_call(c, 0x060AC97Eu); if (c.pc != 0x060AD10Eu) return;  // 060AD10A bsr 0x060AC97E ; nop
L_060AD10E:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060AD10E lds.l @r15+,pr
    c.r[5] = ld32(c.r[15]); c.r[15] += 4;  // 060AD110 mov.l @r15+,r5
    c.r[6] = ld32(c.r[15]); c.r[15] += 4;  // 060AD112 mov.l @r15+,r6
    { const uint32_t x = c.pr; c.r[4] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060AD114 rts ; mov.l @r15+,r4
}

void f_060AD14C(SH2Context& c) {
    ran[2899] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[6]);  // 060AD14C mov.l r6,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060AD14E sts.l pr,@-r15
    c.r[6] = ld32(0x060AD198u);  // 060AD150 mov.l 0x060AD198,r6
L_060AD152:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[6]);  // 060AD152 mov.b @r6,r0
    c.t = (c.r[0] & 0x1u) == 0;  // 060AD154 tst #1,r0
    if (!c.t) { SH2_POLL(c); goto L_060AD152; }  // 060AD156 bf 0x060AD152
    c.r[0] = 0x060AD188u;  // 060AD158 mova 0x060AD188,r0
    c.r[1] = 0x1u;  // 060AD15A mov #1,r1
    c.r[2] = c.r[0];  // 060AD15C mov r0,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4] + 2);  // 060AD15E mov.b @(2,r4),r0
    st8(c.r[6], c.r[1]);  // 060AD160 mov.b r1,@r6
    c.r[1] = ld32(c.r[0] + c.r[2]);  // 060AD162 mov.l @(r0,r2),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060AD164 tst r1,r1
    if (c.t) { goto L_060AD16C; }  // 060AD166 bt 0x060AD16C
    { const uint32_t x = c.r[1]; c.pr = 0x060AD16Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AD16Cu) return; }  // 060AD168 jsr @r1 ; nop
L_060AD16C:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4]);  // 060AD16C mov.b @(0,r4),r0
    c.r[2] = ld32(0x060AD1A0u);  // 060AD16E mov.l 0x060AD1A0,r2
    c.r[1] = 0x0u;  // 060AD170 mov #0,r1
    c.r[5] = c.r[5] & 0xFFu;  // 060AD172 extu.b r5,r5
    st8(c.r[2], c.r[0]);  // 060AD174 mov.b r0,@r2
    c.t = c.r[5] == c.r[1];  // 060AD176 cmp/eq r1,r5
    if (c.t) { goto L_060AD180; }  // 060AD178 bt 0x060AD180
L_060AD17A:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[6]);  // 060AD17A mov.b @r6,r0
    c.t = (c.r[0] & 0x1u) == 0;  // 060AD17C tst #1,r0
    if (!c.t) { SH2_POLL(c); goto L_060AD17A; }  // 060AD17E bf 0x060AD17A
L_060AD180:
    c.r[0] = 0x0u;  // 060AD180 mov #0,r0
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060AD182 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[6] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060AD184 rts ; mov.l @r15+,r6
}

void f_060AD1AE(SH2Context& c) {
    ran[2900] = 1;
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060AD1AE sts.l pr,@-r15
    c.pr = 0x060AD1B4u; SH2_POLL(c); sh2_call(c, 0x060AC974u); if (c.pc != 0x060AD1B4u) return;  // 060AD1B0 bsr 0x060AC974 ; nop
    c.t = c.r[0] == 0x0u;  // 060AD1B4 cmp/eq #0,r0
    if (!c.t) { goto L_060AD1CE; }  // 060AD1B6 bf 0x060AD1CE
    c.r[2] = ld32(0x060AD35Cu);  // 060AD1B8 mov.l 0x060AD35C,r2
    c.r[1] = 0x0u;  // 060AD1BA mov #0,r1
    c.r[4] = c.r[4] & 0xFFu;  // 060AD1BC extu.b r4,r4
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060AD1BE mov.b @r2,r0
    c.t = c.r[4] == c.r[1];  // 060AD1C0 cmp/eq r1,r4
    { const bool k = c.t; c.r[0] |= 0x2u; if (k) { goto L_060AD1C8; } }  // 060AD1C2 bt/s 0x060AD1C8 ; or #2,r0
    c.r[0] ^= 0x2u;  // 060AD1C6 xor #2,r0
L_060AD1C8:
    st8(c.r[2], c.r[0]);  // 060AD1C8 mov.b r0,@r2
    c.pr = 0x060AD1CEu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, 0x060AC97Eu); if (c.pc != 0x060AD1CEu) return;  // 060AD1CA bsr 0x060AC97E ; mov #0,r4
L_060AD1CE:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060AD1CE lds.l @r15+,pr
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060AD1D0 rts ; nop
}

void f_060AD1EE(SH2Context& c) {
    ran[2901] = 1;
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060AD1EE sts.l pr,@-r15
    c.pr = 0x060AD1F4u; SH2_POLL(c); sh2_call(c, 0x060AC974u); if (c.pc != 0x060AD1F4u) return;  // 060AD1F0 bsr 0x060AC974 ; nop
    c.t = c.r[0] == 0x0u;  // 060AD1F4 cmp/eq #0,r0
    if (!c.t) { goto L_060AD226; }  // 060AD1F6 bf 0x060AD226
    c.r[1] = 0x2u;  // 060AD1F8 mov #2,r1
    c.r[4] = c.r[4] & 0xFFu;  // 060AD1FA extu.b r4,r4
    c.t = c.r[4] == c.r[1];  // 060AD1FC cmp/eq r1,r4
    { const bool k = c.t; c.r[0] = 0xFFFFFFFFu; if (k) { goto L_060AD222; } }  // 060AD1FE bt/s 0x060AD222 ; mov #-1,r0
    c.r[4] = c.r[4] & 0xFFu;  // 060AD202 extu.b r4,r4
    c.r[1] = 0x3u;  // 060AD204 mov #3,r1
    c.t = c.r[4] > c.r[1];  // 060AD206 cmp/hi r1,r4
    if (!c.t) { goto L_060AD20C; }  // 060AD208 bf 0x060AD20C
    c.r[4] = 0x0u;  // 060AD20A mov #0,r4
L_060AD20C:
    c.r[4] <<= 2;  // 060AD20C shll2 r4
    c.r[2] = ld32(0x060AD35Cu);  // 060AD20E mov.l 0x060AD35C,r2
    c.r[4] <<= 2;  // 060AD210 shll2 r4
    c.r[1] = 0x30u;  // 060AD212 mov #48,r1
    c.r[4] &= c.r[1];  // 060AD214 and r1,r4
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060AD216 mov.b @r2,r0
    c.r[1] = ~c.r[1];  // 060AD218 not r1,r1
    c.r[0] &= c.r[1];  // 060AD21A and r1,r0
    c.r[0] |= c.r[4];  // 060AD21C or r4,r0
    st8(c.r[2], c.r[0]);  // 060AD21E mov.b r0,@r2
    c.r[0] = 0x0u;  // 060AD220 mov #0,r0
L_060AD222:
    c.pr = 0x060AD226u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, 0x060AC97Eu); if (c.pc != 0x060AD226u) return;  // 060AD222 bsr 0x060AC97E ; mov r0,r4
L_060AD226:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060AD226 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060AD228 rts ; nop
}

void f_060AD22C(SH2Context& c) {
    ran[2902] = 1;
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060AD22C sts.l pr,@-r15
    c.pr = 0x060AD232u; SH2_POLL(c); sh2_call(c, 0x060AC974u); if (c.pc != 0x060AD232u) return;  // 060AD22E bsr 0x060AC974 ; nop
    c.t = c.r[0] == 0x0u;  // 060AD232 cmp/eq #0,r0
    if (!c.t) { goto L_060AD266; }  // 060AD234 bf 0x060AD266
    c.r[1] = 0x2u;  // 060AD236 mov #2,r1
    c.r[4] = c.r[4] & 0xFFu;  // 060AD238 extu.b r4,r4
    c.t = c.r[4] == c.r[1];  // 060AD23A cmp/eq r1,r4
    { const bool k = c.t; c.r[0] = 0xFFFFFFFFu; if (k) { goto L_060AD262; } }  // 060AD23C bt/s 0x060AD262 ; mov #-1,r0
    c.r[4] = c.r[4] & 0xFFu;  // 060AD240 extu.b r4,r4
    c.r[1] = 0x3u;  // 060AD242 mov #3,r1
    c.t = c.r[4] > c.r[1];  // 060AD244 cmp/hi r1,r4
    if (!c.t) { goto L_060AD24A; }  // 060AD246 bf 0x060AD24A
    c.r[4] = 0x0u;  // 060AD248 mov #0,r4
L_060AD24A:
    c.r[4] <<= 2;  // 060AD24A shll2 r4
    c.r[2] = ld32(0x060AD35Cu);  // 060AD24C mov.l 0x060AD35C,r2
    c.r[4] <<= 2;  // 060AD24E shll2 r4
    c.r[1] = 0xFFFFFFC0u;  // 060AD250 mov #-64,r1
    c.r[4] <<= 2;  // 060AD252 shll2 r4
    c.r[4] &= c.r[1];  // 060AD254 and r1,r4
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060AD256 mov.b @r2,r0
    c.r[1] = ~c.r[1];  // 060AD258 not r1,r1
    c.r[0] &= c.r[1];  // 060AD25A and r1,r0
    c.r[0] |= c.r[4];  // 060AD25C or r4,r0
    st8(c.r[2], c.r[0]);  // 060AD25E mov.b r0,@r2
    c.r[0] = 0x0u;  // 060AD260 mov #0,r0
L_060AD262:
    c.pr = 0x060AD266u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, 0x060AC97Eu); if (c.pc != 0x060AD266u) return;  // 060AD262 bsr 0x060AC97E ; mov r0,r4
L_060AD266:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060AD266 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060AD268 rts ; nop
}

void f_060AD26C(SH2Context& c) {
    ran[2903] = 1;
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060AD26C sts.l pr,@-r15
    c.pr = 0x060AD272u; SH2_POLL(c); sh2_call(c, 0x060ACDFAu); if (c.pc != 0x060AD272u) return;  // 060AD26E bsr 0x060ACDFA ; nop
    c.t = c.r[0] == 0x0u;  // 060AD272 cmp/eq #0,r0
    if (c.t) { goto L_060AD27E; }  // 060AD274 bt 0x060AD27E
    c.pr = 0x060AD27Au; SH2_POLL(c); sh2_call(c, 0x060ACDA6u); if (c.pc != 0x060AD27Au) return;  // 060AD276 bsr 0x060ACDA6 ; nop
    goto L_060AD282;  // 060AD27A bra 0x060AD282 ; nop
L_060AD27E:
    c.pr = 0x060AD282u; SH2_POLL(c); sh2_call(c, 0x060AD14Cu); if (c.pc != 0x060AD282u) return;  // 060AD27E bsr 0x060AD14C ; nop
L_060AD282:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060AD282 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060AD284 rts ; nop
}

void f_060AD288(SH2Context& c) {
    ran[2904] = 1;
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060AD288 sts.l pr,@-r15
    c.pr = 0x060AD28Eu; SH2_POLL(c); sh2_call(c, 0x060ACDFAu); if (c.pc != 0x060AD28Eu) return;  // 060AD28A bsr 0x060ACDFA ; nop
    c.t = c.r[0] == 0x0u;  // 060AD28E cmp/eq #0,r0
    if (c.t) { goto L_060AD29A; }  // 060AD290 bt 0x060AD29A
    c.pr = 0x060AD296u; SH2_POLL(c); sh2_call(c, 0x060ACDA6u); if (c.pc != 0x060AD296u) return;  // 060AD292 bsr 0x060ACDA6 ; nop
    goto L_060AD2A2;  // 060AD296 bra 0x060AD2A2 ; nop
L_060AD29A:
    c.pr = 0x060AD29Eu; SH2_POLL(c); sh2_call(c, 0x060AD14Cu); if (c.pc != 0x060AD29Eu) return;  // 060AD29A bsr 0x060AD14C ; nop
L_060AD29E:
    SH2_POLL(c); goto L_060AD29E;  // 060AD29E bra 0x060AD29E ; nop
L_060AD2A2:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060AD2A2 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060AD2A4 rts ; nop
}

void f_060AD2A8(SH2Context& c) {
    ran[2905] = 1;
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060AD2A8 sts.l pr,@-r15
    c.pr = 0x060AD2AEu; SH2_POLL(c); sh2_call(c, 0x060ACDFAu); if (c.pc != 0x060AD2AEu) return;  // 060AD2AA bsr 0x060ACDFA ; nop
    c.t = c.r[0] == 0x0u;  // 060AD2AE cmp/eq #0,r0
    if (c.t) { goto L_060AD2BA; }  // 060AD2B0 bt 0x060AD2BA
    c.pr = 0x060AD2B6u; c.r[5] = 0x1u; SH2_POLL(c); sh2_call(c, 0x060ACDA6u); if (c.pc != 0x060AD2B6u) return;  // 060AD2B2 bsr 0x060ACDA6 ; mov #1,r5
    goto L_060AD2D0;  // 060AD2B6 bra 0x060AD2D0 ; nop
L_060AD2BA:
    c.r[2] = ld32(0x060AD420u);  // 060AD2BA mov.l 0x060AD420,r2
    c.r[3] = ld32(0x060AD2D8u);  // 060AD2BC mov.l 0x060AD2D8,r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060AD2BE mov.b @r2,r0
    c.r[1] = ld32(c.r[3]);  // 060AD2C0 mov.l @r3,r1
    c.t = c.r[0] == 0x8u;  // 060AD2C2 cmp/eq #8,r0
    { const bool k = c.t; c.r[4] = 0x1u; if (k) { goto L_060AD2CA; } }  // 060AD2C4 bt/s 0x060AD2CA ; mov #1,r4
    c.r[4] = 0x0u;  // 060AD2C8 mov #0,r4
L_060AD2CA:
    { const uint32_t x = c.r[1]; c.pr = 0x060AD2CEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AD2CEu) return; }  // 060AD2CA jsr @r1 ; nop
    c.r[0] = 0x0u;  // 060AD2CE mov #0,r0
L_060AD2D0:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060AD2D0 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060AD2D2 rts ; nop
}

void f_060AD2DC(SH2Context& c) {
    ran[2906] = 1;
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060AD2DC sts.l pr,@-r15
    c.pr = 0x060AD2E2u; SH2_POLL(c); sh2_call(c, 0x060ACB80u); if (c.pc != 0x060AD2E2u) return;  // 060AD2DE bsr 0x060ACB80 ; nop
    c.t = c.r[0] == 0x0u;  // 060AD2E2 cmp/eq #0,r0
    if (!c.t) { goto L_060AD30E; }  // 060AD2E4 bf 0x060AD30E
    c.r[4] = ld32(0x060AD420u);  // 060AD2E6 mov.l 0x060AD420,r4
    c.r[5] = ld32(0x060AD354u);  // 060AD2E8 mov.l 0x060AD354,r5
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4]);  // 060AD2EA mov.b @r4,r0
    c.r[2] = ld32(0x060AD35Cu);  // 060AD2EC mov.l 0x060AD35C,r2
    st8(c.r[5], c.r[0]);  // 060AD2EE mov.b r0,@r5
    c.r[1] = 0x1u;  // 060AD2F0 mov #1,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060AD2F2 mov.b @r2,r0
    c.r[1] <<= 8;  // 060AD2F4 shll8 r1
    c.r[0] = c.r[0] & 0xFFu;  // 060AD2F6 extu.b r0,r0
    c.r[0] |= c.r[1];  // 060AD2F8 or r1,r0
    c.r[0] |= 0x8u;  // 060AD2FA or #8,r0
    c.pr = 0x060AD300u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, 0x060ACBE0u); if (c.pc != 0x060AD300u) return;  // 060AD2FC bsr 0x060ACBE0 ; mov r0,r4
    c.r[0] <<= 8;  // 060AD300 shll8 r0
    c.r[0] |= 0xF0u;  // 060AD302 or #240,r0
    c.r[0] <<= 8;  // 060AD304 shll8 r0
    c.r[2] = ld32(0x060AD358u);  // 060AD306 mov.l 0x060AD358,r2
    c.pr = 0x060AD30Cu; st32(c.r[2], c.r[0]); SH2_POLL(c); sh2_call(c, 0x060ACE32u); if (c.pc != 0x060AD30Cu) return;  // 060AD308 bsr 0x060ACE32 ; mov.l r0,@r2
    c.r[0] = 0x0u;  // 060AD30C mov #0,r0
L_060AD30E:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060AD30E lds.l @r15+,pr
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060AD310 rts ; nop
}

void f_060AD314(SH2Context& c) {
    ran[2907] = 1;
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060AD314 sts.l pr,@-r15
    c.pr = 0x060AD31Au; SH2_POLL(c); sh2_call(c, 0x060ACB80u); if (c.pc != 0x060AD31Au) return;  // 060AD316 bsr 0x060ACB80 ; nop
    c.t = c.r[0] == 0x0u;  // 060AD31A cmp/eq #0,r0
    if (!c.t) { goto L_060AD34E; }  // 060AD31C bf 0x060AD34E
    c.pr = 0x060AD322u; SH2_POLL(c); sh2_call(c, 0x060ACBC2u); if (c.pc != 0x060AD322u) return;  // 060AD31E bsr 0x060ACBC2 ; nop
    c.t = c.r[0] == 0x0u;  // 060AD322 cmp/eq #0,r0
    if (!c.t) { goto L_060AD34E; }  // 060AD324 bf 0x060AD34E
    c.r[4] = ld32(0x060AD420u);  // 060AD326 mov.l 0x060AD420,r4
    c.r[5] = ld32(0x060AD354u);  // 060AD328 mov.l 0x060AD354,r5
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4]);  // 060AD32A mov.b @r4,r0
    c.r[2] = ld32(0x060AD35Cu);  // 060AD32C mov.l 0x060AD35C,r2
    st8(c.r[5], c.r[0]);  // 060AD32E mov.b r0,@r5
    c.r[1] = 0x0u;  // 060AD330 mov #0,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060AD332 mov.b @r2,r0
    c.r[1] <<= 8;  // 060AD334 shll8 r1
    c.r[0] = c.r[0] & 0xFFu;  // 060AD336 extu.b r0,r0
    c.r[0] |= c.r[1];  // 060AD338 or r1,r0
    c.r[0] |= 0x8u;  // 060AD33A or #8,r0
    c.pr = 0x060AD340u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, 0x060ACBE0u); if (c.pc != 0x060AD340u) return;  // 060AD33C bsr 0x060ACBE0 ; mov r0,r4
    c.r[0] <<= 8;  // 060AD340 shll8 r0
    c.r[0] |= 0xF0u;  // 060AD342 or #240,r0
    c.r[0] <<= 8;  // 060AD344 shll8 r0
    c.r[2] = ld32(0x060AD358u);  // 060AD346 mov.l 0x060AD358,r2
    c.pr = 0x060AD34Cu; st32(c.r[2], c.r[0]); SH2_POLL(c); sh2_call(c, 0x060ACE32u); if (c.pc != 0x060AD34Cu) return;  // 060AD348 bsr 0x060ACE32 ; mov.l r0,@r2
    c.r[0] = 0x0u;  // 060AD34C mov #0,r0
L_060AD34E:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060AD34E lds.l @r15+,pr
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060AD350 rts ; nop
}

void f_060AD360(SH2Context& c) {
    ran[2908] = 1;
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060AD360 sts.l pr,@-r15
    c.r[2] = ld32(0x060AD3B4u);  // 060AD362 mov.l 0x060AD3B4,r2
    c.r[3] = ld32(0x060AD3ACu);  // 060AD364 mov.l 0x060AD3AC,r3
    c.r[0] = ld32(c.r[2] + 16);  // 060AD366 mov.l @(16,r2),r0
    c.pr = 0x060AD36Cu; st32(c.r[3], c.r[0]); SH2_POLL(c); sh2_call(c, 0x060ACDFAu); if (c.pc != 0x060AD36Cu) return;  // 060AD368 bsr 0x060ACDFA ; mov.l r0,@r3
    c.t = c.r[0] == 0x0u;  // 060AD36C cmp/eq #0,r0
    if (c.t) { goto L_060AD378; }  // 060AD36E bt 0x060AD378
    c.pr = 0x060AD374u; SH2_POLL(c); sh2_call(c, 0x060ACDA6u); if (c.pc != 0x060AD374u) return;  // 060AD370 bsr 0x060ACDA6 ; nop
    goto L_060AD37C;  // 060AD374 bra 0x060AD37C ; nop
L_060AD378:
    c.pr = 0x060AD37Cu; SH2_POLL(c); sh2_call(c, 0x060AD14Cu); if (c.pc != 0x060AD37Cu) return;  // 060AD378 bsr 0x060AD14C ; nop
L_060AD37C:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060AD37C lds.l @r15+,pr
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060AD37E rts ; nop
}

void f_060AD382(SH2Context& c) {
    ran[2909] = 1;
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060AD382 sts.l pr,@-r15
    c.r[2] = ld32(0x060AD3B4u);  // 060AD384 mov.l 0x060AD3B4,r2
    c.r[3] = ld32(0x060AD3B0u);  // 060AD386 mov.l 0x060AD3B0,r3
    c.r[2] += 4;  // 060AD388 add #4,r2
    c.r[0] = ld32(c.r[2]); c.r[2] += 4;  // 060AD38A mov.l @r2+,r0
    c.r[1] = ld32(c.r[2]); c.r[2] += 4;  // 060AD38C mov.l @r2+,r1
    st32(c.r[3], c.r[0]);  // 060AD38E mov.l r0,@r3
    c.r[3] += 4;  // 060AD390 add #4,r3
    c.pr = 0x060AD396u; st32(c.r[3], c.r[1]); SH2_POLL(c); sh2_call(c, 0x060ACDFAu); if (c.pc != 0x060AD396u) return;  // 060AD392 bsr 0x060ACDFA ; mov.l r1,@r3
    c.t = c.r[0] == 0x0u;  // 060AD396 cmp/eq #0,r0
    if (c.t) { goto L_060AD3A2; }  // 060AD398 bt 0x060AD3A2
    c.pr = 0x060AD39Eu; SH2_POLL(c); sh2_call(c, 0x060ACDA6u); if (c.pc != 0x060AD39Eu) return;  // 060AD39A bsr 0x060ACDA6 ; nop
    goto L_060AD3A6;  // 060AD39E bra 0x060AD3A6 ; nop
L_060AD3A2:
    c.pr = 0x060AD3A6u; SH2_POLL(c); sh2_call(c, 0x060AD14Cu); if (c.pc != 0x060AD3A6u) return;  // 060AD3A2 bsr 0x060AD14C ; nop
L_060AD3A6:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060AD3A6 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060AD3A8 rts ; nop
}

void f_060AD3B8(SH2Context& c) {
    ran[2910] = 1;
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060AD3B8 sts.l pr,@-r15
    c.pr = 0x060AD3BEu; SH2_POLL(c); sh2_call(c, 0x060AC974u); if (c.pc != 0x060AD3BEu) return;  // 060AD3BA bsr 0x060AC974 ; nop
    c.t = c.r[0] == 0x0u;  // 060AD3BE cmp/eq #0,r0
    if (!c.t) { goto L_060AD3FC; }  // 060AD3C0 bf 0x060AD3FC
    c.r[1] = 0x11u;  // 060AD3C2 mov #17,r1
    c.t = c.r[4] >= c.r[1];  // 060AD3C4 cmp/hs r1,r4
    { const bool k = c.t; c.r[0] = 0xFFFFFFFFu; if (k) { goto L_060AD3F8; } }  // 060AD3C6 bt/s 0x060AD3F8 ; mov #-1,r0
    c.r[2] = ld32(0x060AD420u);  // 060AD3CA mov.l 0x060AD420,r2
    c.pr = 0x060AD3D0u; st8(c.r[2], c.r[4]); SH2_POLL(c); sh2_call(c, 0x060ACB2Cu); if (c.pc != 0x060AD3D0u) return;  // 060AD3CC bsr 0x060ACB2C ; mov.b r4,@r2
    c.r[4] = c.r[0];  // 060AD3D0 mov r0,r4
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4] + 3);  // 060AD3D2 mov.b @(3,r4),r0
    c.t = (c.r[0] & 0x1u) == 0;  // 060AD3D4 tst #1,r0
    { const bool k = c.t; c.r[0] = 0xFFFFFFFFu; if (k) { goto L_060AD3F8; } }  // 060AD3D6 bt/s 0x060AD3F8 ; mov #-1,r0
    c.r[3] = ld32(0x060AD424u);  // 060AD3DA mov.l 0x060AD424,r3
    c.r[2] = 0xFFFFFFE0u;  // 060AD3DC mov #-32,r2
    c.r[1] = ld32(c.r[2]);  // 060AD3DE mov.l @r2,r1
    c.t = (c.r[1] & c.r[3]) == 0;  // 060AD3E0 tst r3,r1
    if (c.t) { goto L_060AD3EC; }  // 060AD3E2 bt 0x060AD3EC
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4] + 3);  // 060AD3E4 mov.b @(3,r4),r0
    c.t = (c.r[0] & 0x2u) == 0;  // 060AD3E6 tst #2,r0
    { const bool k = c.t; c.r[0] = 0xFFFFFFFFu; if (k) { goto L_060AD3F8; } }  // 060AD3E8 bt/s 0x060AD3F8 ; mov #-1,r0
L_060AD3EC:
    c.r[0] = 0x060AD404u;  // 060AD3EC mova 0x060AD404,r0
    c.r[2] = c.r[0];  // 060AD3EE mov r0,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4] + 1);  // 060AD3F0 mov.b @(1,r4),r0
    c.r[1] = ld32(c.r[0] + c.r[2]);  // 060AD3F2 mov.l @(r0,r2),r1
    { const uint32_t x = c.r[1]; c.pr = 0x060AD3F8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AD3F8u) return; }  // 060AD3F4 jsr @r1 ; nop
L_060AD3F8:
    c.pr = 0x060AD3FCu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, 0x060AC97Eu); if (c.pc != 0x060AD3FCu) return;  // 060AD3F8 bsr 0x060AC97E ; mov r0,r4
L_060AD3FC:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060AD3FC lds.l @r15+,pr
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060AD3FE rts ; nop
}

void f_060AD500(SH2Context& c) {
    ran[2911] = 1;
L_060AD500:
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 060AD500 mov.l r0,@-r15
L_060AD502:
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060AD502 mov.l r1,@-r15
L_060AD504:
    c.r[0] = ld32(0x060AD620u);  // 060AD504 mov.l 0x060AD620,r0
L_060AD506:
    c.t = c.r[2] == c.r[0];  // 060AD506 cmp/eq r0,r2
L_060AD508:
    if (c.t) { goto L_060AD562; }  // 060AD508 bt 0x060AD562
L_060AD50A:
    c.r[0] = ld32(0x060AD624u);  // 060AD50A mov.l 0x060AD624,r0
L_060AD50C:
    c.t = c.r[2] == c.r[0];  // 060AD50C cmp/eq r0,r2
L_060AD50E:
    if (c.t) { goto L_060AD562; }  // 060AD50E bt 0x060AD562
L_060AD510:
    c.r[0] = ld32(0x060AD628u);  // 060AD510 mov.l 0x060AD628,r0
L_060AD512:
    c.t = c.r[2] == c.r[0];  // 060AD512 cmp/eq r0,r2
L_060AD514:
    if (c.t) { goto L_060AD562; }  // 060AD514 bt 0x060AD562
L_060AD516:
    c.r[0] = ld32(0x060AD62Cu);  // 060AD516 mov.l 0x060AD62C,r0
L_060AD518:
    c.t = c.r[2] == c.r[0];  // 060AD518 cmp/eq r0,r2
L_060AD51A:
    if (c.t) { goto L_060AD562; }  // 060AD51A bt 0x060AD562
L_060AD51C:
    c.r[0] = ld32(0x060AD630u);  // 060AD51C mov.l 0x060AD630,r0
L_060AD51E:
    c.t = c.r[2] == c.r[0];  // 060AD51E cmp/eq r0,r2
L_060AD520:
    if (c.t) { goto L_060AD586; }  // 060AD520 bt 0x060AD586
L_060AD522:
    c.r[0] = ld32(0x060AD634u);  // 060AD522 mov.l 0x060AD634,r0
L_060AD524:
    c.t = c.r[2] == c.r[0];  // 060AD524 cmp/eq r0,r2
L_060AD526:
    if (c.t) { goto L_060AD586; }  // 060AD526 bt 0x060AD586
L_060AD528:
    c.r[0] = ld32(0x060AD638u);  // 060AD528 mov.l 0x060AD638,r0
L_060AD52A:
    c.t = c.r[2] == c.r[0];  // 060AD52A cmp/eq r0,r2
L_060AD52C:
    if (c.t) { goto L_060AD5AC; }  // 060AD52C bt 0x060AD5AC
L_060AD52E:
    c.r[0] = ld32(0x060AD63Cu);  // 060AD52E mov.l 0x060AD63C,r0
L_060AD530:
    c.t = c.r[2] == c.r[0];  // 060AD530 cmp/eq r0,r2
L_060AD532:
    if (c.t) { goto L_060AD5AC; }  // 060AD532 bt 0x060AD5AC
L_060AD534:
    c.r[0] = ld32(0x060AD640u);  // 060AD534 mov.l 0x060AD640,r0
L_060AD536:
    c.t = c.r[2] == c.r[0];  // 060AD536 cmp/eq r0,r2
L_060AD538:
    if (c.t) { goto L_060AD5AC; }  // 060AD538 bt 0x060AD5AC
L_060AD53A:
    c.r[0] = ld32(0x060AD644u);  // 060AD53A mov.l 0x060AD644,r0
L_060AD53C:
    c.t = c.r[2] == c.r[0];  // 060AD53C cmp/eq r0,r2
L_060AD53E:
    if (c.t) { goto L_060AD5D0; }  // 060AD53E bt 0x060AD5D0
L_060AD540:
    c.r[0] = ld32(0x060AD648u);  // 060AD540 mov.l 0x060AD648,r0
L_060AD542:
    c.t = c.r[2] == c.r[0];  // 060AD542 cmp/eq r0,r2
L_060AD544:
    if (c.t) { goto L_060AD5D0; }  // 060AD544 bt 0x060AD5D0
L_060AD546:
    c.r[0] = ld32(0x060AD64Cu);  // 060AD546 mov.l 0x060AD64C,r0
L_060AD548:
    c.t = c.r[2] == c.r[0];  // 060AD548 cmp/eq r0,r2
L_060AD54A:
    if (c.t) { goto L_060AD5D0; }  // 060AD54A bt 0x060AD5D0
L_060AD54C:
    c.r[0] = ld32(0x060AD650u);  // 060AD54C mov.l 0x060AD650,r0
L_060AD54E:
    c.t = c.r[2] == c.r[0];  // 060AD54E cmp/eq r0,r2
L_060AD550:
    if (c.t) { goto L_060AD5F4; }  // 060AD550 bt 0x060AD5F4
L_060AD552:
    c.r[0] = ld32(0x060AD654u);  // 060AD552 mov.l 0x060AD654,r0
L_060AD554:
    c.t = c.r[2] == c.r[0];  // 060AD554 cmp/eq r0,r2
L_060AD556:
    if (c.t) { goto L_060AD5F4; }  // 060AD556 bt 0x060AD5F4
L_060AD558:
    c.r[1] = ld32(c.r[15]); c.r[15] += 4;  // 060AD558 mov.l @r15+,r1
L_060AD55A:
    c.r[0] = ld32(c.r[15]); c.r[15] += 4;  // 060AD55A mov.l @r15+,r0
L_060AD55C:
    c.r[3] = ld32(0x060AD618u);  // 060AD55C mov.l 0x060AD618,r3
L_060AD55E:
    { const uint32_t x = c.r[3]; SH2_POLL(c); switch (x) { case 0x060AD500u: goto L_060AD500; case 0x060AD502u: goto L_060AD502; case 0x060AD504u: goto L_060AD504; case 0x060AD506u: goto L_060AD506; case 0x060AD508u: goto L_060AD508; case 0x060AD50Au: goto L_060AD50A; case 0x060AD50Cu: goto L_060AD50C; case 0x060AD50Eu: goto L_060AD50E; case 0x060AD510u: goto L_060AD510; case 0x060AD512u: goto L_060AD512; case 0x060AD514u: goto L_060AD514; case 0x060AD516u: goto L_060AD516; case 0x060AD518u: goto L_060AD518; case 0x060AD51Au: goto L_060AD51A; case 0x060AD51Cu: goto L_060AD51C; case 0x060AD51Eu: goto L_060AD51E; case 0x060AD520u: goto L_060AD520; case 0x060AD522u: goto L_060AD522; case 0x060AD524u: goto L_060AD524; case 0x060AD526u: goto L_060AD526; case 0x060AD528u: goto L_060AD528; case 0x060AD52Au: goto L_060AD52A; case 0x060AD52Cu: goto L_060AD52C; case 0x060AD52Eu: goto L_060AD52E; case 0x060AD530u: goto L_060AD530; case 0x060AD532u: goto L_060AD532; case 0x060AD534u: goto L_060AD534; case 0x060AD536u: goto L_060AD536; case 0x060AD538u: goto L_060AD538; case 0x060AD53Au: goto L_060AD53A; case 0x060AD53Cu: goto L_060AD53C; case 0x060AD53Eu: goto L_060AD53E; case 0x060AD540u: goto L_060AD540; case 0x060AD542u: goto L_060AD542; case 0x060AD544u: goto L_060AD544; case 0x060AD546u: goto L_060AD546; case 0x060AD548u: goto L_060AD548; case 0x060AD54Au: goto L_060AD54A; case 0x060AD54Cu: goto L_060AD54C; case 0x060AD54Eu: goto L_060AD54E; case 0x060AD550u: goto L_060AD550; case 0x060AD552u: goto L_060AD552; case 0x060AD554u: goto L_060AD554; case 0x060AD556u: goto L_060AD556; case 0x060AD558u: goto L_060AD558; case 0x060AD55Au: goto L_060AD55A; case 0x060AD55Cu: goto L_060AD55C; case 0x060AD55Eu: goto L_060AD55E; case 0x060AD562u: goto L_060AD562; case 0x060AD564u: goto L_060AD564; case 0x060AD566u: goto L_060AD566; case 0x060AD568u: goto L_060AD568; case 0x060AD56Au: goto L_060AD56A; case 0x060AD56Cu: goto L_060AD56C; case 0x060AD56Eu: goto L_060AD56E; case 0x060AD570u: goto L_060AD570; case 0x060AD572u: goto L_060AD572; case 0x060AD576u: goto L_060AD576; case 0x060AD578u: goto L_060AD578; case 0x060AD57Au: goto L_060AD57A; case 0x060AD57Cu: goto L_060AD57C; case 0x060AD57Eu: goto L_060AD57E; case 0x060AD580u: goto L_060AD580; case 0x060AD582u: goto L_060AD582; case 0x060AD586u: goto L_060AD586; case 0x060AD588u: goto L_060AD588; case 0x060AD58Au: goto L_060AD58A; case 0x060AD58Cu: goto L_060AD58C; case 0x060AD58Eu: goto L_060AD58E; case 0x060AD590u: goto L_060AD590; case 0x060AD592u: goto L_060AD592; case 0x060AD594u: goto L_060AD594; case 0x060AD596u: goto L_060AD596; case 0x060AD59Au: goto L_060AD59A; case 0x060AD59Cu: goto L_060AD59C; case 0x060AD59Eu: goto L_060AD59E; case 0x060AD5A0u: goto L_060AD5A0; case 0x060AD5A2u: goto L_060AD5A2; case 0x060AD5A4u: goto L_060AD5A4; case 0x060AD5A6u: goto L_060AD5A6; case 0x060AD5A8u: goto L_060AD5A8; case 0x060AD5ACu: goto L_060AD5AC; case 0x060AD5AEu: goto L_060AD5AE; case 0x060AD5B0u: goto L_060AD5B0; case 0x060AD5B2u: goto L_060AD5B2; case 0x060AD5B4u: goto L_060AD5B4; case 0x060AD5B6u: goto L_060AD5B6; case 0x060AD5B8u: goto L_060AD5B8; case 0x060AD5BAu: goto L_060AD5BA; case 0x060AD5BCu: goto L_060AD5BC; case 0x060AD5C0u: goto L_060AD5C0; case 0x060AD5C2u: goto L_060AD5C2; case 0x060AD5C4u: goto L_060AD5C4; case 0x060AD5C6u: goto L_060AD5C6; case 0x060AD5C8u: goto L_060AD5C8; case 0x060AD5CAu: goto L_060AD5CA; case 0x060AD5CCu: goto L_060AD5CC; case 0x060AD5D0u: goto L_060AD5D0; case 0x060AD5D2u: goto L_060AD5D2; case 0x060AD5D4u: goto L_060AD5D4; case 0x060AD5D6u: goto L_060AD5D6; case 0x060AD5D8u: goto L_060AD5D8; case 0x060AD5DAu: goto L_060AD5DA; case 0x060AD5DCu: goto L_060AD5DC; case 0x060AD5DEu: goto L_060AD5DE; case 0x060AD5E0u: goto L_060AD5E0; case 0x060AD5E4u: goto L_060AD5E4; case 0x060AD5E6u: goto L_060AD5E6; case 0x060AD5E8u: goto L_060AD5E8; case 0x060AD5EAu: goto L_060AD5EA; case 0x060AD5ECu: goto L_060AD5EC; case 0x060AD5EEu: goto L_060AD5EE; case 0x060AD5F0u: goto L_060AD5F0; case 0x060AD5F4u: goto L_060AD5F4; case 0x060AD5F6u: goto L_060AD5F6; case 0x060AD5F8u: goto L_060AD5F8; case 0x060AD5FAu: goto L_060AD5FA; case 0x060AD5FCu: goto L_060AD5FC; case 0x060AD5FEu: goto L_060AD5FE; case 0x060AD600u: goto L_060AD600; case 0x060AD602u: goto L_060AD602; case 0x060AD604u: goto L_060AD604; case 0x060AD608u: goto L_060AD608; case 0x060AD60Au: goto L_060AD60A; case 0x060AD60Cu: goto L_060AD60C; case 0x060AD60Eu: goto L_060AD60E; case 0x060AD610u: goto L_060AD610; case 0x060AD612u: goto L_060AD612; case 0x060AD614u: goto L_060AD614; case 0x060AE460u: goto L_060AE460; case 0x060AE462u: goto L_060AE462; case 0x060AE464u: goto L_060AE464; case 0x060AE466u: goto L_060AE466; case 0x060AE468u: goto L_060AE468; case 0x060AE46Au: goto L_060AE46A; case 0x060AE46Cu: goto L_060AE46C; case 0x060AE46Eu: goto L_060AE46E; case 0x060AE472u: goto L_060AE472; case 0x060AE474u: goto L_060AE474; case 0x060AE476u: goto L_060AE476; case 0x060AE478u: goto L_060AE478; case 0x060AE47Au: goto L_060AE47A; case 0x060AE47Cu: goto L_060AE47C; case 0x060AE47Eu: goto L_060AE47E; case 0x060AE482u: goto L_060AE482; case 0x060AE484u: goto L_060AE484; case 0x060AE486u: goto L_060AE486; case 0x060AE48Au: goto L_060AE48A; case 0x060AE48Cu: goto L_060AE48C; case 0x060AE48Eu: goto L_060AE48E; case 0x060AE490u: goto L_060AE490; case 0x060AE492u: goto L_060AE492; case 0x060AE494u: goto L_060AE494; case 0x060AE496u: goto L_060AE496; case 0x060AE498u: goto L_060AE498; default: sh2_call(c, x); return; } }  // 060AD55E jmp @r3 ; nop
L_060AD562:
    c.r[1] = ld32(0x060AD61Cu);  // 060AD562 mov.l 0x060AD61C,r1
L_060AD564:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060AD564 mov.b @r1,r0
L_060AD566:
    c.r[0] = c.r[0] & 0xFFu;  // 060AD566 extu.b r0,r0
L_060AD568:
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 060AD568 mov.l r0,@-r15
L_060AD56A:
    c.r[0] -= 1;  // 060AD56A add #-1,r0
L_060AD56C:
    st8(c.r[1], c.r[0]);  // 060AD56C mov.b r0,@r1
L_060AD56E:
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060AD56E sts.l pr,@-r15
L_060AD570:
    c.r[1] = ld32(0x060AD618u);  // 060AD570 mov.l 0x060AD618,r1
L_060AD572:
    { const uint32_t x = c.r[1]; c.pr = 0x060AD576u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AD576u) return; }  // 060AD572 jsr @r1 ; nop
L_060AD576:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060AD576 lds.l @r15+,pr
L_060AD578:
    c.r[0] = ld32(c.r[15]); c.r[15] += 4;  // 060AD578 mov.l @r15+,r0
L_060AD57A:
    c.r[1] = ld32(0x060AD61Cu);  // 060AD57A mov.l 0x060AD61C,r1
L_060AD57C:
    st8(c.r[1], c.r[0]);  // 060AD57C mov.b r0,@r1
L_060AD57E:
    c.r[1] = ld32(c.r[15]); c.r[15] += 4;  // 060AD57E mov.l @r15+,r1
L_060AD580:
    c.r[0] = ld32(c.r[15]); c.r[15] += 4;  // 060AD580 mov.l @r15+,r0
L_060AD582:
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060AD582 rts ; nop
L_060AD586:
    c.r[1] = ld32(0x060AD61Cu);  // 060AD586 mov.l 0x060AD61C,r1
L_060AD588:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060AD588 mov.b @r1,r0
L_060AD58A:
    c.r[0] = c.r[0] & 0xFFu;  // 060AD58A extu.b r0,r0
L_060AD58C:
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 060AD58C mov.l r0,@-r15
L_060AD58E:
    c.r[0] -= 1;  // 060AD58E add #-1,r0
L_060AD590:
    st8(c.r[1], c.r[0]);  // 060AD590 mov.b r0,@r1
L_060AD592:
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060AD592 sts.l pr,@-r15
L_060AD594:
    c.r[1] = ld32(0x060AD618u);  // 060AD594 mov.l 0x060AD618,r1
L_060AD596:
    { const uint32_t x = c.r[1]; c.pr = 0x060AD59Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AD59Au) return; }  // 060AD596 jsr @r1 ; nop
L_060AD59A:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060AD59A lds.l @r15+,pr
L_060AD59C:
    c.r[0] = ld32(c.r[15]); c.r[15] += 4;  // 060AD59C mov.l @r15+,r0
L_060AD59E:
    c.r[0] += 1;  // 060AD59E add #1,r0
L_060AD5A0:
    c.r[1] = ld32(0x060AD61Cu);  // 060AD5A0 mov.l 0x060AD61C,r1
L_060AD5A2:
    st8(c.r[1], c.r[0]);  // 060AD5A2 mov.b r0,@r1
L_060AD5A4:
    c.r[1] = ld32(c.r[15]); c.r[15] += 4;  // 060AD5A4 mov.l @r15+,r1
L_060AD5A6:
    c.r[0] = ld32(c.r[15]); c.r[15] += 4;  // 060AD5A6 mov.l @r15+,r0
L_060AD5A8:
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060AD5A8 rts ; nop
L_060AD5AC:
    c.r[1] = ld32(0x060AD61Cu);  // 060AD5AC mov.l 0x060AD61C,r1
L_060AD5AE:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060AD5AE mov.b @r1,r0
L_060AD5B0:
    c.r[0] = c.r[0] & 0xFFu;  // 060AD5B0 extu.b r0,r0
L_060AD5B2:
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 060AD5B2 mov.l r0,@-r15
L_060AD5B4:
    c.r[0] -= 2;  // 060AD5B4 add #-2,r0
L_060AD5B6:
    st8(c.r[1], c.r[0]);  // 060AD5B6 mov.b r0,@r1
L_060AD5B8:
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060AD5B8 sts.l pr,@-r15
L_060AD5BA:
    c.r[1] = ld32(0x060AD618u);  // 060AD5BA mov.l 0x060AD618,r1
L_060AD5BC:
    { const uint32_t x = c.r[1]; c.pr = 0x060AD5C0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AD5C0u) return; }  // 060AD5BC jsr @r1 ; nop
L_060AD5C0:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060AD5C0 lds.l @r15+,pr
L_060AD5C2:
    c.r[0] = ld32(c.r[15]); c.r[15] += 4;  // 060AD5C2 mov.l @r15+,r0
L_060AD5C4:
    c.r[1] = ld32(0x060AD61Cu);  // 060AD5C4 mov.l 0x060AD61C,r1
L_060AD5C6:
    st8(c.r[1], c.r[0]);  // 060AD5C6 mov.b r0,@r1
L_060AD5C8:
    c.r[1] = ld32(c.r[15]); c.r[15] += 4;  // 060AD5C8 mov.l @r15+,r1
L_060AD5CA:
    c.r[0] = ld32(c.r[15]); c.r[15] += 4;  // 060AD5CA mov.l @r15+,r0
L_060AD5CC:
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060AD5CC rts ; nop
L_060AD5D0:
    c.r[1] = ld32(0x060AD61Cu);  // 060AD5D0 mov.l 0x060AD61C,r1
L_060AD5D2:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060AD5D2 mov.b @r1,r0
L_060AD5D4:
    c.r[0] = c.r[0] & 0xFFu;  // 060AD5D4 extu.b r0,r0
L_060AD5D6:
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 060AD5D6 mov.l r0,@-r15
L_060AD5D8:
    c.r[0] += 2;  // 060AD5D8 add #2,r0
L_060AD5DA:
    st8(c.r[1], c.r[0]);  // 060AD5DA mov.b r0,@r1
L_060AD5DC:
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060AD5DC sts.l pr,@-r15
L_060AD5DE:
    c.r[1] = ld32(0x060AD618u);  // 060AD5DE mov.l 0x060AD618,r1
L_060AD5E0:
    { const uint32_t x = c.r[1]; c.pr = 0x060AD5E4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AD5E4u) return; }  // 060AD5E0 jsr @r1 ; nop
L_060AD5E4:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060AD5E4 lds.l @r15+,pr
L_060AD5E6:
    c.r[0] = ld32(c.r[15]); c.r[15] += 4;  // 060AD5E6 mov.l @r15+,r0
L_060AD5E8:
    c.r[1] = ld32(0x060AD61Cu);  // 060AD5E8 mov.l 0x060AD61C,r1
L_060AD5EA:
    st8(c.r[1], c.r[0]);  // 060AD5EA mov.b r0,@r1
L_060AD5EC:
    c.r[1] = ld32(c.r[15]); c.r[15] += 4;  // 060AD5EC mov.l @r15+,r1
L_060AD5EE:
    c.r[0] = ld32(c.r[15]); c.r[15] += 4;  // 060AD5EE mov.l @r15+,r0
L_060AD5F0:
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060AD5F0 rts ; nop
L_060AD5F4:
    c.r[1] = ld32(0x060AD61Cu);  // 060AD5F4 mov.l 0x060AD61C,r1
L_060AD5F6:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060AD5F6 mov.b @r1,r0
L_060AD5F8:
    c.r[0] = c.r[0] & 0xFFu;  // 060AD5F8 extu.b r0,r0
L_060AD5FA:
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 060AD5FA mov.l r0,@-r15
L_060AD5FC:
    c.r[0] -= 4;  // 060AD5FC add #-4,r0
L_060AD5FE:
    st8(c.r[1], c.r[0]);  // 060AD5FE mov.b r0,@r1
L_060AD600:
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060AD600 sts.l pr,@-r15
L_060AD602:
    c.r[1] = ld32(0x060AD618u);  // 060AD602 mov.l 0x060AD618,r1
L_060AD604:
    { const uint32_t x = c.r[1]; c.pr = 0x060AD608u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AD608u) return; }  // 060AD604 jsr @r1 ; nop
L_060AD608:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060AD608 lds.l @r15+,pr
L_060AD60A:
    c.r[0] = ld32(c.r[15]); c.r[15] += 4;  // 060AD60A mov.l @r15+,r0
L_060AD60C:
    c.r[1] = ld32(0x060AD61Cu);  // 060AD60C mov.l 0x060AD61C,r1
L_060AD60E:
    st8(c.r[1], c.r[0]);  // 060AD60E mov.b r0,@r1
L_060AD610:
    c.r[1] = ld32(c.r[15]); c.r[15] += 4;  // 060AD610 mov.l @r15+,r1
L_060AD612:
    c.r[0] = ld32(c.r[15]); c.r[15] += 4;  // 060AD612 mov.l @r15+,r0
L_060AD614:
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060AD614 rts ; nop
L_060AE460:
    c.r[1] = ld32(0x060AE49Cu);  // 060AE460 mov.l 0x060AE49C,r1
L_060AE462:
    c.t = c.r[2] == c.r[1];  // 060AE462 cmp/eq r1,r2
L_060AE464:
    if (c.t) { goto L_060AE472; }  // 060AE464 bt 0x060AE472
L_060AE466:
    c.r[1] = ld32(0x060AE4A0u);  // 060AE466 mov.l 0x060AE4A0,r1
L_060AE468:
    c.t = c.r[2] == c.r[1];  // 060AE468 cmp/eq r1,r2
L_060AE46A:
    if (c.t) { goto L_060AE482; }  // 060AE46A bt 0x060AE482
L_060AE46C:
    c.r[1] = ld32(0x060AE4A4u);  // 060AE46C mov.l 0x060AE4A4,r1
L_060AE46E:
    { const uint32_t x = c.r[1]; SH2_POLL(c); switch (x) { case 0x060AD500u: goto L_060AD500; case 0x060AD502u: goto L_060AD502; case 0x060AD504u: goto L_060AD504; case 0x060AD506u: goto L_060AD506; case 0x060AD508u: goto L_060AD508; case 0x060AD50Au: goto L_060AD50A; case 0x060AD50Cu: goto L_060AD50C; case 0x060AD50Eu: goto L_060AD50E; case 0x060AD510u: goto L_060AD510; case 0x060AD512u: goto L_060AD512; case 0x060AD514u: goto L_060AD514; case 0x060AD516u: goto L_060AD516; case 0x060AD518u: goto L_060AD518; case 0x060AD51Au: goto L_060AD51A; case 0x060AD51Cu: goto L_060AD51C; case 0x060AD51Eu: goto L_060AD51E; case 0x060AD520u: goto L_060AD520; case 0x060AD522u: goto L_060AD522; case 0x060AD524u: goto L_060AD524; case 0x060AD526u: goto L_060AD526; case 0x060AD528u: goto L_060AD528; case 0x060AD52Au: goto L_060AD52A; case 0x060AD52Cu: goto L_060AD52C; case 0x060AD52Eu: goto L_060AD52E; case 0x060AD530u: goto L_060AD530; case 0x060AD532u: goto L_060AD532; case 0x060AD534u: goto L_060AD534; case 0x060AD536u: goto L_060AD536; case 0x060AD538u: goto L_060AD538; case 0x060AD53Au: goto L_060AD53A; case 0x060AD53Cu: goto L_060AD53C; case 0x060AD53Eu: goto L_060AD53E; case 0x060AD540u: goto L_060AD540; case 0x060AD542u: goto L_060AD542; case 0x060AD544u: goto L_060AD544; case 0x060AD546u: goto L_060AD546; case 0x060AD548u: goto L_060AD548; case 0x060AD54Au: goto L_060AD54A; case 0x060AD54Cu: goto L_060AD54C; case 0x060AD54Eu: goto L_060AD54E; case 0x060AD550u: goto L_060AD550; case 0x060AD552u: goto L_060AD552; case 0x060AD554u: goto L_060AD554; case 0x060AD556u: goto L_060AD556; case 0x060AD558u: goto L_060AD558; case 0x060AD55Au: goto L_060AD55A; case 0x060AD55Cu: goto L_060AD55C; case 0x060AD55Eu: goto L_060AD55E; case 0x060AD562u: goto L_060AD562; case 0x060AD564u: goto L_060AD564; case 0x060AD566u: goto L_060AD566; case 0x060AD568u: goto L_060AD568; case 0x060AD56Au: goto L_060AD56A; case 0x060AD56Cu: goto L_060AD56C; case 0x060AD56Eu: goto L_060AD56E; case 0x060AD570u: goto L_060AD570; case 0x060AD572u: goto L_060AD572; case 0x060AD576u: goto L_060AD576; case 0x060AD578u: goto L_060AD578; case 0x060AD57Au: goto L_060AD57A; case 0x060AD57Cu: goto L_060AD57C; case 0x060AD57Eu: goto L_060AD57E; case 0x060AD580u: goto L_060AD580; case 0x060AD582u: goto L_060AD582; case 0x060AD586u: goto L_060AD586; case 0x060AD588u: goto L_060AD588; case 0x060AD58Au: goto L_060AD58A; case 0x060AD58Cu: goto L_060AD58C; case 0x060AD58Eu: goto L_060AD58E; case 0x060AD590u: goto L_060AD590; case 0x060AD592u: goto L_060AD592; case 0x060AD594u: goto L_060AD594; case 0x060AD596u: goto L_060AD596; case 0x060AD59Au: goto L_060AD59A; case 0x060AD59Cu: goto L_060AD59C; case 0x060AD59Eu: goto L_060AD59E; case 0x060AD5A0u: goto L_060AD5A0; case 0x060AD5A2u: goto L_060AD5A2; case 0x060AD5A4u: goto L_060AD5A4; case 0x060AD5A6u: goto L_060AD5A6; case 0x060AD5A8u: goto L_060AD5A8; case 0x060AD5ACu: goto L_060AD5AC; case 0x060AD5AEu: goto L_060AD5AE; case 0x060AD5B0u: goto L_060AD5B0; case 0x060AD5B2u: goto L_060AD5B2; case 0x060AD5B4u: goto L_060AD5B4; case 0x060AD5B6u: goto L_060AD5B6; case 0x060AD5B8u: goto L_060AD5B8; case 0x060AD5BAu: goto L_060AD5BA; case 0x060AD5BCu: goto L_060AD5BC; case 0x060AD5C0u: goto L_060AD5C0; case 0x060AD5C2u: goto L_060AD5C2; case 0x060AD5C4u: goto L_060AD5C4; case 0x060AD5C6u: goto L_060AD5C6; case 0x060AD5C8u: goto L_060AD5C8; case 0x060AD5CAu: goto L_060AD5CA; case 0x060AD5CCu: goto L_060AD5CC; case 0x060AD5D0u: goto L_060AD5D0; case 0x060AD5D2u: goto L_060AD5D2; case 0x060AD5D4u: goto L_060AD5D4; case 0x060AD5D6u: goto L_060AD5D6; case 0x060AD5D8u: goto L_060AD5D8; case 0x060AD5DAu: goto L_060AD5DA; case 0x060AD5DCu: goto L_060AD5DC; case 0x060AD5DEu: goto L_060AD5DE; case 0x060AD5E0u: goto L_060AD5E0; case 0x060AD5E4u: goto L_060AD5E4; case 0x060AD5E6u: goto L_060AD5E6; case 0x060AD5E8u: goto L_060AD5E8; case 0x060AD5EAu: goto L_060AD5EA; case 0x060AD5ECu: goto L_060AD5EC; case 0x060AD5EEu: goto L_060AD5EE; case 0x060AD5F0u: goto L_060AD5F0; case 0x060AD5F4u: goto L_060AD5F4; case 0x060AD5F6u: goto L_060AD5F6; case 0x060AD5F8u: goto L_060AD5F8; case 0x060AD5FAu: goto L_060AD5FA; case 0x060AD5FCu: goto L_060AD5FC; case 0x060AD5FEu: goto L_060AD5FE; case 0x060AD600u: goto L_060AD600; case 0x060AD602u: goto L_060AD602; case 0x060AD604u: goto L_060AD604; case 0x060AD608u: goto L_060AD608; case 0x060AD60Au: goto L_060AD60A; case 0x060AD60Cu: goto L_060AD60C; case 0x060AD60Eu: goto L_060AD60E; case 0x060AD610u: goto L_060AD610; case 0x060AD612u: goto L_060AD612; case 0x060AD614u: goto L_060AD614; case 0x060AE460u: goto L_060AE460; case 0x060AE462u: goto L_060AE462; case 0x060AE464u: goto L_060AE464; case 0x060AE466u: goto L_060AE466; case 0x060AE468u: goto L_060AE468; case 0x060AE46Au: goto L_060AE46A; case 0x060AE46Cu: goto L_060AE46C; case 0x060AE46Eu: goto L_060AE46E; case 0x060AE472u: goto L_060AE472; case 0x060AE474u: goto L_060AE474; case 0x060AE476u: goto L_060AE476; case 0x060AE478u: goto L_060AE478; case 0x060AE47Au: goto L_060AE47A; case 0x060AE47Cu: goto L_060AE47C; case 0x060AE47Eu: goto L_060AE47E; case 0x060AE482u: goto L_060AE482; case 0x060AE484u: goto L_060AE484; case 0x060AE486u: goto L_060AE486; case 0x060AE48Au: goto L_060AE48A; case 0x060AE48Cu: goto L_060AE48C; case 0x060AE48Eu: goto L_060AE48E; case 0x060AE490u: goto L_060AE490; case 0x060AE492u: goto L_060AE492; case 0x060AE494u: goto L_060AE494; case 0x060AE496u: goto L_060AE496; case 0x060AE498u: goto L_060AE498; default: sh2_call(c, x); return; } }  // 060AE46E jmp @r1 ; nop
L_060AE472:
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 060AE472 mov.l r0,@-r15
L_060AE474:
    c.r[1] = ld32(0x060AE4A8u);  // 060AE474 mov.l 0x060AE4A8,r1
L_060AE476:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060AE476 mov.b @r1,r0
L_060AE478:
    c.r[0] ^= 0x4u;  // 060AE478 xor #4,r0
L_060AE47A:
    st8(c.r[1], c.r[0]);  // 060AE47A mov.b r0,@r1
L_060AE47C:
    c.r[0] = ld32(c.r[15]); c.r[15] += 4;  // 060AE47C mov.l @r15+,r0
L_060AE47E:
    SH2_POLL(c); goto L_060AE46C;  // 060AE47E bra 0x060AE46C ; nop
L_060AE482:
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060AE482 sts.l pr,@-r15
L_060AE484:
    c.r[1] = ld32(0x060AE4A4u);  // 060AE484 mov.l 0x060AE4A4,r1
L_060AE486:
    { const uint32_t x = c.r[1]; c.pr = 0x060AE48Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AE48Au) return; }  // 060AE486 jsr @r1 ; nop
L_060AE48A:
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 060AE48A mov.l r0,@-r15
L_060AE48C:
    c.r[1] = ld32(0x060AE4A8u);  // 060AE48C mov.l 0x060AE4A8,r1
L_060AE48E:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060AE48E mov.b @r1,r0
L_060AE490:
    c.r[0] ^= 0x4u;  // 060AE490 xor #4,r0
L_060AE492:
    st8(c.r[1], c.r[0]);  // 060AE492 mov.b r0,@r1
L_060AE494:
    c.r[0] = ld32(c.r[15]); c.r[15] += 4;  // 060AE494 mov.l @r15+,r0
L_060AE496:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060AE496 lds.l @r15+,pr
L_060AE498:
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060AE498 rts ; nop
}

void f_060AD93C(SH2Context& c) {
    ran[2912] = 1;
    c.r[0] = c.r[4];  // 060AD93C mov r4,r0
    st16(c.gbr + 468, c.r[0]);  // 060AD93E mov.w r0,@(468,gbr)
    c.r[0] = c.r[5];  // 060AD940 mov r5,r0
    st16(c.gbr + 470, c.r[0]);  // 060AD942 mov.w r0,@(470,gbr)
    c.r[0] = c.r[6];  // 060AD944 mov r6,r0
    { const uint32_t x = c.pr; st16(c.gbr + 472, c.r[0]); c.pc = x; return; }  // 060AD946 rts ; mov.w r0,@(472,gbr)
}

void f_060AD94C(SH2Context& c) {
    ran[2913] = 1;
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 192);  // 060AD94C mov.w @(192,gbr),r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x060AD964u);  // 060AD94E mov.w 0x060AD964,r1
    c.r[0] |= c.r[1];  // 060AD950 or r1,r0
    { const uint32_t x = c.pr; st16(c.gbr + 192, c.r[0]); c.pc = x; return; }  // 060AD952 rts ; mov.w r0,@(192,gbr)
}

void f_060AD956(SH2Context& c) {
    ran[2914] = 1;
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 192);  // 060AD956 mov.w @(192,gbr),r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x060AD966u);  // 060AD958 mov.w 0x060AD966,r1
    c.r[0] &= c.r[1];  // 060AD95A and r1,r0
    c.r[1] = ld32(0x060AD968u);  // 060AD95C mov.l 0x060AD968,r1
    st16(c.gbr + 192, c.r[0]);  // 060AD95E mov.w r0,@(192,gbr)
    { const uint32_t x = c.pr; st16(c.r[1], c.r[0]); c.pc = x; return; }  // 060AD960 rts ; mov.w r0,@r1
}

void f_060AD96C(SH2Context& c) {
    ran[2915] = 1;
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 206);  // 060AD96C mov.b @(206,gbr),r0
    c.r[0] &= 0xFCu;  // 060AD96E and #252,r0
    c.r[0] |= c.r[4];  // 060AD970 or r4,r0
    { const uint32_t x = c.pr; st8(c.gbr + 206, c.r[0]); c.pc = x; return; }  // 060AD972 rts ; mov.b r0,@(206,gbr)
}

void f_060AD978(SH2Context& c) {
    ran[2916] = 1;
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 206);  // 060AD978 mov.w @(206,gbr),r0
    c.r[3] = (uint32_t)(int16_t)ld16(0x060AD994u);  // 060AD97A mov.w 0x060AD994,r3
    c.r[0] &= c.r[3];  // 060AD97C and r3,r0
    c.r[4] <<= 8;  // 060AD97E shll8 r4
    c.r[4] <<= 2;  // 060AD980 shll2 r4
    c.r[4] <<= 2;  // 060AD982 shll2 r4
    c.r[0] |= c.r[4];  // 060AD984 or r4,r0
    c.r[1] = ld32(0x060AD990u);  // 060AD986 mov.l 0x060AD990,r1
    st16(c.gbr + 206, c.r[0]);  // 060AD988 mov.w r0,@(206,gbr)
    { const uint32_t x = c.pr; st16(c.r[1], c.r[0]); c.pc = x; return; }  // 060AD98A rts ; mov.w r0,@r1
}

void f_060AD998(SH2Context& c) {
    ran[2917] = 1;
    c.r[0] = c.r[4];  // 060AD998 mov r4,r0
    st16(c.r[0], c.r[5]);  // 060AD99A mov.w r5,@r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060AD99C shlr r0
    { const uint32_t x = c.pr; st32(c.gbr + 364, c.r[0]); c.pc = x; return; }  // 060AD99E rts ; mov.l r0,@(364,gbr)
}

void f_060AD9A4(SH2Context& c) {
    ran[2918] = 1;
    c.r[0] = ld32(c.gbr + 464);  // 060AD9A4 mov.l @(464,gbr),r0
    c.r[4] = c.r[4] & 0xFFFFu;  // 060AD9A6 extu.w r4,r4
    c.r[1] = ~c.r[4];  // 060AD9A8 not r4,r1
    c.r[0] &= c.r[1];  // 060AD9AA and r1,r0
    c.r[4] <<= 16;  // 060AD9AC shll16 r4
    c.r[0] |= c.r[4];  // 060AD9AE or r4,r0
    { const uint32_t x = c.pr; st32(c.gbr + 464, c.r[0]); c.pc = x; return; }  // 060AD9B0 rts ; mov.l r0,@(464,gbr)
}

void f_060AD9B4(SH2Context& c) {
    ran[2919] = 1;
    c.r[0] = ld32(c.gbr + 464);  // 060AD9B4 mov.l @(464,gbr),r0
    c.r[4] = c.r[4] & 0xFFFFu;  // 060AD9B6 extu.w r4,r4
    c.r[0] |= c.r[4];  // 060AD9B8 or r4,r0
    c.r[4] <<= 16;  // 060AD9BA shll16 r4
    c.r[0] |= c.r[4];  // 060AD9BC or r4,r0
    { const uint32_t x = c.pr; st32(c.gbr + 464, c.r[0]); c.pc = x; return; }  // 060AD9BE rts ; mov.l r0,@(464,gbr)
}

void f_060AD9C4(SH2Context& c) {
    ran[2920] = 1;
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 416);  // 060AD9C4 mov.w @(416,gbr),r0
    c.r[1] = 0xFFFFFFDFu;  // 060AD9C6 mov #-33,r1
    c.r[0] &= c.r[1];  // 060AD9C8 and r1,r0
    c.r[4] <<= 2;  // 060AD9CA shll2 r4
    c.r[4] <<= 2;  // 060AD9CC shll2 r4
    c.t = c.r[4] >> 31; c.r[4] <<= 1;  // 060AD9CE shll r4
    c.r[0] |= c.r[4];  // 060AD9D0 or r4,r0
    { const uint32_t x = c.pr; st16(c.gbr + 416, c.r[0]); c.pc = x; return; }  // 060AD9D2 rts ; mov.w r0,@(416,gbr)
}

void f_060AD9D8(SH2Context& c) {
    ran[2921] = 1;
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 416);  // 060AD9D8 mov.w @(416,gbr),r0
    c.r[1] = 0xFFFFFFF0u;  // 060AD9DA mov #-16,r1
    c.r[0] &= c.r[1];  // 060AD9DC and r1,r0
    c.r[0] |= c.r[4];  // 060AD9DE or r4,r0
    { const uint32_t x = c.pr; st16(c.gbr + 416, c.r[0]); c.pc = x; return; }  // 060AD9E0 rts ; mov.w r0,@(416,gbr)
}

void f_060AD9E4(SH2Context& c) {
    ran[2922] = 1;
    c.r[0] = 0x16u;  // 060AD9E4 mov #22,r0
    c.t = c.r[7] >= c.r[0];  // 060AD9E6 cmp/hs r0,r7
    { const bool k = c.t; c.r[1] = 0xFFFFFFFFu; if (k) { goto L_060ADA4E; } }  // 060AD9E8 bt/s 0x060ADA4E ; mov #-1,r1
    c.r[0] = 0x7u;  // 060AD9EC mov #7,r0
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[0];  // 060AD9EE cmp/ge r0,r7
    { const bool k = !c.t; c.r[0] = 0xEu; if (k) { goto L_060ADA00; } }  // 060AD9F0 bf/s 0x060ADA00 ; mov #14,r0
    c.r[1] += c.r[1];  // 060AD9F4 add r1,r1
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[0];  // 060AD9F6 cmp/ge r0,r7
    { const bool k = !c.t; c.t = c.r[6] & 1; c.r[6] >>= 1; if (k) { goto L_060ADA00; } }  // 060AD9F8 bf/s 0x060ADA00 ; shlr r6
    c.t = c.r[6] & 1; c.r[6] >>= 1;  // 060AD9FC shlr r6
    c.r[1] += c.r[1];  // 060AD9FE add r1,r1
L_060ADA00:
    c.r[0] = 0x060ADA58u;  // 060ADA00 mova 0x060ADA58,r0
    c.t = c.r[7] >> 31; c.r[7] <<= 1;  // 060ADA02 shll r7
    c.r[7] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[7]);  // 060ADA04 mov.w @(r0,r7),r7
    c.r[4] &= c.r[1];  // 060ADA06 and r1,r4
    c.r[5] &= c.r[1];  // 060ADA08 and r1,r5
    c.r[3] = 0xFFFFFF80u;  // 060ADA0A mov #-128,r3
L_060ADA0C:
    c.r[0] = ld32(c.r[3] + 12);  // 060ADA0C mov.l @(12,r3),r0
    c.r[0] &= 0x3u;  // 060ADA0E and #3,r0
    c.t = c.r[0] == 0x1u;  // 060ADA10 cmp/eq #1,r0
    if (c.t) { SH2_POLL(c); goto L_060ADA0C; }  // 060ADA12 bt 0x060ADA0C
    c.r[0] = ld32(c.r[3] + 48);  // 060ADA14 mov.l @(48,r3),r0
    c.r[0] = 0x0u;  // 060ADA16 mov #0,r0
    st32(c.r[3] + 12, c.r[0]);  // 060ADA18 mov.l r0,@(12,r3)
    c.r[1] = 0xFFFFFF9Cu;  // 060ADA1A mov #-100,r1
    c.r[1] <<= 2;  // 060ADA1C shll2 r1
    st8(c.r[1] + 1, c.r[0]);  // 060ADA1E mov.b r0,@(1,r1)
    st32(c.r[3], c.r[4]);  // 060ADA20 mov.l r4,@(0,r3)
    st32(c.r[3] + 4, c.r[5]);  // 060ADA22 mov.l r5,@(4,r3)
    st32(c.r[3] + 8, c.r[6]);  // 060ADA24 mov.l r6,@(8,r3)
    st32(c.r[3] + 12, c.r[7]);  // 060ADA26 mov.l r7,@(12,r3)
    c.r[0] = 0x10u;  // 060ADA28 mov #16,r0
    st8(c.gbr + 185, c.r[0]);  // 060ADA2A mov.b r0,@(185,gbr)
    c.r[1] = ld32(0x060ADA54u);  // 060ADA2C mov.l 0x060ADA54,r1
    c.r[0] = 0x9u;  // 060ADA2E mov #9,r0
    st32(c.r[3] + 48, c.r[0]);  // 060ADA30 mov.l r0,@(48,r3)
    c.t = c.r[5] >= c.r[1];  // 060ADA32 cmp/hs r1,r5
    { const bool k = c.t; c.r[1] = 0xFFFFFFA4u; if (k) { goto L_060ADA4A; } }  // 060ADA34 bt/s 0x060ADA4A ; mov #-92,r1
    c.r[1] <<= 2;  // 060ADA38 shll2 r1
    c.r[0] = 0x11u;  // 060ADA3A mov #17,r0
    st8(c.r[1] + 2, c.r[0]);  // 060ADA3C mov.b r0,@(2,r1)
    ;  // 060ADA3E nop
    ;  // 060ADA40 nop
    ;  // 060ADA42 nop
    ;  // 060ADA44 nop
    ;  // 060ADA46 nop
    ;  // 060ADA48 nop
L_060ADA4A:
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 060ADA4A rts ; mov #1,r0
L_060ADA4E:
    { const uint32_t x = c.pr; c.r[0] = 0x0u; c.pc = x; return; }  // 060ADA4E rts ; mov #0,r0
}

void f_060ADA84(SH2Context& c) {
    ran[2923] = 1;
    c.r[1] = 0xFFFFFF80u;  // 060ADA84 mov #-128,r1
L_060ADA86:
    c.r[0] = ld32(c.r[1] + 12);  // 060ADA86 mov.l @(12,r1),r0
    c.r[0] &= 0x3u;  // 060ADA88 and #3,r0
    c.t = c.r[0] == 0x1u;  // 060ADA8A cmp/eq #1,r0
    if (c.t) { SH2_POLL(c); goto L_060ADA86; }  // 060ADA8C bt 0x060ADA86
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060ADA8E rts ; nop
}

void f_060ADA94(SH2Context& c) {
    ran[2924] = 1;
    c.r[0] = c.r[4];  // 060ADA94 mov r4,r0
    st16(c.gbr + 474, c.r[0]);  // 060ADA96 mov.w r0,@(474,gbr)
    c.r[0] = c.r[5];  // 060ADA98 mov r5,r0
    st16(c.gbr + 476, c.r[0]);  // 060ADA9A mov.w r0,@(476,gbr)
    c.r[0] = c.r[6];  // 060ADA9C mov r6,r0
    { const uint32_t x = c.pr; st16(c.gbr + 478, c.r[0]); c.pc = x; return; }  // 060ADA9E rts ; mov.w r0,@(478,gbr)
}

void f_060ADAA4(SH2Context& c) {
    ran[2925] = 1;
    c.r[1] = 0x7u;  // 060ADAA4 mov #7,r1
    c.r[1] &= c.r[4];  // 060ADAA6 and r4,r1
    c.r[0] = 0x060ADADCu;  // 060ADAA8 mova 0x060ADADC,r0
    c.t = c.r[1] >> 31; c.r[1] <<= 1;  // 060ADAAA shll r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 060ADAAC mov.w @(r0,r1),r1
    c.r[0] = 0x060ADAF0u;  // 060ADAAE mova 0x060ADAF0,r0
    { const uint32_t x = c.pr; st16(c.r[0], c.r[1]); c.pc = x; return; }  // 060ADAB0 rts ; mov.w r1,@r0
}

void f_060ADABE(SH2Context& c) {
    ran[2926] = 1;
    c.r[1] = (uint32_t)(int16_t)ld16(0x060ADAF0u);  // 060ADABE mov.w 0x060ADAF0,r1
    c.r[0] = c.gbr;  // 060ADAC0 stc gbr,r0
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 060ADAC2 mov.w @(r0,r1),r0
    c.t = c.r[4] >> 31; c.r[4] <<= 1;  // 060ADAC4 shll r4
    c.r[5] <<= 8;  // 060ADAC6 shll8 r5
    c.t = c.r[5] & 1; c.r[5] >>= 1;  // 060ADAC8 shlr r5
    c.r[1] = c.r[0] & 0xFFu;  // 060ADACA extu.b r0,r1
    c.r[0] = ld32(0x060ADAECu);  // 060ADACC mov.l 0x060ADAEC,r0
    c.r[1] <<= 16;  // 060ADACE shll16 r1
    c.r[1] >>= 2;  // 060ADAD0 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060ADAD2 shlr r1
    c.r[0] += c.r[1];  // 060ADAD4 add r1,r0
    c.r[0] += c.r[4];  // 060ADAD6 add r4,r0
    { const uint32_t x = c.pr; c.r[0] += c.r[5]; c.pc = x; return; }  // 060ADAD8 rts ; add r5,r0
}

void f_060ADAF4(SH2Context& c) {
    ran[2927] = 1;
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 33);  // 060ADAF4 mov.b @(33,gbr),r0
    c.r[0] <<= 8;  // 060ADAF6 shll8 r0
    c.r[1] = c.r[0];  // 060ADAF8 mov r0,r1
L_060ADAFA:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 060ADAFA mov.b @r4+,r0
    c.r[0] = c.r[0] & 0xFFu;  // 060ADAFC extu.b r0,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060ADAFE tst r0,r0
    { const bool k = c.t; c.r[0] += c.r[0]; if (k) { goto L_060ADB0C; } }  // 060ADB00 bt/s 0x060ADB0C ; add r0,r0
    c.r[0] |= c.r[1];  // 060ADB04 or r1,r0
    st16(c.r[5], c.r[0]);  // 060ADB06 mov.w r0,@r5
    c.r[5] += 2; SH2_POLL(c); goto L_060ADAFA;  // 060ADB08 bra 0x060ADAFA ; add #2,r5
L_060ADB0C:
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060ADB0C rts ; nop
}

void f_060ADB10(SH2Context& c) {
    ran[2928] = 1;
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 33);  // 060ADB10 mov.b @(33,gbr),r0
    c.r[1] = 0x8u;  // 060ADB12 mov #8,r1
    c.r[0] <<= 8;  // 060ADB14 shll8 r0
    c.r[0] += 96;  // 060ADB16 add #96,r0
    c.r[7] = c.r[0];  // 060ADB18 mov r0,r7
    c.r[5] += 16;  // 060ADB1A add #16,r5
    c.r[2] = 0xAu;  // 060ADB1C mov #10,r2
L_060ADB1E:
    c.r[0] = c.r[4];  // 060ADB1E mov r4,r0
    c.r[0] &= 0xFu;  // 060ADB20 and #15,r0
    c.t = (int32_t)c.r[0] >= (int32_t)c.r[2];  // 060ADB22 cmp/ge r2,r0
    if (!c.t) { goto L_060ADB28; }  // 060ADB24 bf 0x060ADB28
    c.r[0] += 7;  // 060ADB26 add #7,r0
L_060ADB28:
    c.r[0] += c.r[0];  // 060ADB28 add r0,r0
    c.r[0] += c.r[7];  // 060ADB2A add r7,r0
    c.r[5] -= 2; st16(c.r[5], c.r[0]);  // 060ADB2C mov.w r0,@-r5
    c.r[4] >>= 2;  // 060ADB2E shlr2 r4
    c.r[4] >>= 2;  // 060ADB30 shlr2 r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 060ADB32 tst r4,r4
    { const bool k = c.t; c.r[1] -= 1; c.t = c.r[1] == 0; if (k) { goto L_060ADB3E; } }  // 060ADB34 bt/s 0x060ADB3E ; dt r1
    if (!c.t) { SH2_POLL(c); goto L_060ADB1E; }  // 060ADB38 bf 0x060ADB1E
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060ADB3A rts ; nop
L_060ADB3E:
    c.t = (c.r[1] & c.r[1]) == 0;  // 060ADB3E tst r1,r1
    if (c.t) { goto L_060ADB48; }  // 060ADB40 bt 0x060ADB48
L_060ADB42:
    c.r[1] -= 1; c.t = c.r[1] == 0;  // 060ADB42 dt r1
    { const bool k = !c.t; c.r[5] -= 2; st16(c.r[5], c.r[4]); if (k) { SH2_POLL(c); goto L_060ADB42; } }  // 060ADB44 bf/s 0x060ADB42 ; mov.w r4,@-r5
L_060ADB48:
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060ADB48 rts ; nop
}

void f_060ADBA0(SH2Context& c) {
    ran[2929] = 1;
    c.r[2] = ld32(0x060ADBF0u);  // 060ADBA0 mov.l 0x060ADBF0,r2
    c.r[1] = ld32(0x060ADBC4u);  // 060ADBA2 mov.l 0x060ADBC4,r1
    c.r[0] = ld32(c.r[2] + 16);  // 060ADBA4 mov.l @(16,r2),r0
    c.t = (c.r[0] & c.r[1]) == 0;  // 060ADBA6 tst r1,r0
    { const uint32_t x = c.pr; c.r[0] = c.t; c.pc = x; return; }  // 060ADBA8 rts ; movt r0
}

void f_060ADBAC(SH2Context& c) {
    ran[2930] = 1;
    c.r[2] = ld32(0x060ADBF0u);  // 060ADBAC mov.l 0x060ADBF0,r2
    c.r[1] = ld32(0x060ADBC4u);  // 060ADBAE mov.l 0x060ADBC4,r1
    c.r[0] = ld32(c.r[2] + 16);  // 060ADBB0 mov.l @(16,r2),r0
    c.r[3] = 0x0u;  // 060ADBB2 mov #0,r3
    c.r[4] = c.r[4] & 0xFFu;  // 060ADBB4 extu.b r4,r4
    c.t = c.r[4] == c.r[3];  // 060ADBB6 cmp/eq r3,r4
    { const bool k = c.t; c.r[0] |= c.r[1]; if (k) { goto L_060ADBBE; } }  // 060ADBB8 bt/s 0x060ADBBE ; or r1,r0
    c.r[0] ^= c.r[1];  // 060ADBBC xor r1,r0
L_060ADBBE:
    { const uint32_t x = c.pr; st32(c.r[2] + 16, c.r[0]); c.pc = x; return; }  // 060ADBBE rts ; mov.l r0,@(16,r2)
}

void f_060ADBF4(SH2Context& c) {
    ran[2931] = 1;
    c.t = (c.r[6] & c.r[6]) == 0;  // 060ADBF4 tst r6,r6
    { const bool k = c.t; c.r[1] = 0xFFFFFF80u; if (k) { goto L_060ADC68; } }  // 060ADBF6 bt/s 0x060ADC68 ; mov #-128,r1
L_060ADBFA:
    c.r[0] = ld32(c.r[1] + 12);  // 060ADBFA mov.l @(12,r1),r0
    c.r[0] &= 0x3u;  // 060ADBFC and #3,r0
    c.t = c.r[0] == 0x1u;  // 060ADBFE cmp/eq #1,r0
    if (c.t) { SH2_POLL(c); goto L_060ADBFA; }  // 060ADC00 bt 0x060ADBFA
    c.r[0] = c.r[4];  // 060ADC02 mov r4,r0
    c.r[0] |= c.r[5];  // 060ADC04 or r5,r0
    c.r[0] |= c.r[6];  // 060ADC06 or r6,r0
    c.t = (c.r[0] & 0xFu) == 0;  // 060ADC08 tst #15,r0
    { const bool k = c.t; c.t = (c.r[0] & 0x3u) == 0; if (k) { goto L_060ADC1A; } }  // 060ADC0A bt/s 0x060ADC1A ; tst #3,r0
    { const bool k = c.t; c.t = (c.r[0] & 0x1u) == 0; if (k) { goto L_060ADC26; } }  // 060ADC0E bt/s 0x060ADC26 ; tst #1,r0
    if (c.t) { goto L_060ADC20; }  // 060ADC12 bt 0x060ADC20
    c.r[2] = (uint32_t)(int16_t)ld16(0x060ADC6Cu);  // 060ADC14 mov.w 0x060ADC6C,r2
    goto L_060ADC2A;  // 060ADC16 bra 0x060ADC2A ; nop
L_060ADC1A:
    c.r[2] = (uint32_t)(int16_t)ld16(0x060ADC72u);  // 060ADC1A mov.w 0x060ADC72,r2
    c.r[6] >>= 2; goto L_060ADC2A;  // 060ADC1C bra 0x060ADC2A ; shlr2 r6
L_060ADC20:
    c.r[2] = (uint32_t)(int16_t)ld16(0x060ADC6Eu);  // 060ADC20 mov.w 0x060ADC6E,r2
    c.t = c.r[6] & 1; c.r[6] >>= 1; goto L_060ADC2A;  // 060ADC22 bra 0x060ADC2A ; shlr r6
L_060ADC26:
    c.r[2] = (uint32_t)(int16_t)ld16(0x060ADC70u);  // 060ADC26 mov.w 0x060ADC70,r2
    c.r[6] >>= 2;  // 060ADC28 shlr2 r6
L_060ADC2A:
    c.r[3] = 0xFFFFFF80u;  // 060ADC2A mov #-128,r3
    c.r[1] = 0xFFFFFF9Cu;  // 060ADC2C mov #-100,r1
    c.r[1] <<= 2;  // 060ADC2E shll2 r1
    c.r[0] = ld32(c.r[3] + 48);  // 060ADC30 mov.l @(48,r3),r0
    c.r[0] = 0x0u;  // 060ADC32 mov #0,r0
    st32(c.r[3] + 12, c.r[0]);  // 060ADC34 mov.l r0,@(12,r3)
    st8(c.r[1] + 1, c.r[0]);  // 060ADC36 mov.b r0,@(1,r1)
    st32(c.r[3], c.r[4]);  // 060ADC38 mov.l r4,@(0,r3)
    st32(c.r[3] + 4, c.r[5]);  // 060ADC3A mov.l r5,@(4,r3)
    st32(c.r[3] + 8, c.r[6]);  // 060ADC3C mov.l r6,@(8,r3)
    c.r[0] = 0x10u;  // 060ADC3E mov #16,r0
    st8(c.gbr + 185, c.r[0]);  // 060ADC40 mov.b r0,@(185,gbr)
    st32(c.r[3] + 12, c.r[2]);  // 060ADC42 mov.l r2,@(12,r3)
    c.r[0] = 0x9u;  // 060ADC44 mov #9,r0
    st32(c.r[3] + 48, c.r[0]);  // 060ADC46 mov.l r0,@(48,r3)
    c.r[1] = ld32(0x060ADC74u);  // 060ADC48 mov.l 0x060ADC74,r1
    c.t = c.r[5] >= c.r[1];  // 060ADC4A cmp/hs r1,r5
    { const bool k = c.t; c.r[1] = 0xFFFFFFA4u; if (k) { goto L_060ADC68; } }  // 060ADC4C bt/s 0x060ADC68 ; mov #-92,r1
    c.r[1] <<= 2;  // 060ADC50 shll2 r1
    c.r[0] = 0x11u;  // 060ADC52 mov #17,r0
    st8(c.r[1] + 2, c.r[0]);  // 060ADC54 mov.b r0,@(2,r1)
    ;  // 060ADC56 nop
    ;  // 060ADC58 nop
    ;  // 060ADC5A nop
    ;  // 060ADC5C nop
    ;  // 060ADC5E nop
    ;  // 060ADC60 nop
    ;  // 060ADC62 nop
    ;  // 060ADC64 nop
    ;  // 060ADC66 nop
L_060ADC68:
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060ADC68 rts ; nop
}

void f_060ADC4E(SH2Context& c) {
    ran[2932] = 1;
    c.r[1] = 0xFFFFFFA4u;  // 060ADC4E mov #-92,r1
    c.r[1] <<= 2;  // 060ADC50 shll2 r1
    c.r[0] = 0x11u;  // 060ADC52 mov #17,r0
    st8(c.r[1] + 2, c.r[0]);  // 060ADC54 mov.b r0,@(2,r1)
    ;  // 060ADC56 nop
    ;  // 060ADC58 nop
    ;  // 060ADC5A nop
    ;  // 060ADC5C nop
    ;  // 060ADC5E nop
    ;  // 060ADC60 nop
    ;  // 060ADC62 nop
    ;  // 060ADC64 nop
    ;  // 060ADC66 nop
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060ADC68 rts ; nop
}

void f_060ADC78(SH2Context& c) {
    ran[2933] = 1;
    c.r[0] = ld32(0x060ADD54u);  // 060ADC78 mov.l 0x060ADD54,r0
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060ADC7A sts.l pr,@-r15
    { const uint32_t x = c.r[0]; c.pr = 0x060ADC80u; c.r[2] = ld32(c.r[4] + 8); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060ADC80u) return; }  // 060ADC7C jsr @r0 ; mov.l @(8,r4),r2
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060ADC80 lds.l @r15+,pr
    c.r[1] = ld32(c.r[4] + 12);  // 060ADC82 mov.l @(12,r4),r1
    c.r[0] = ld32(c.gbr + 72);  // 060ADC84 mov.l @(72,gbr),r0
    c.t = (c.r[1] & c.r[1]) == 0;  // 060ADC86 tst r1,r1
    { const bool k = c.t; c.r[7] = c.r[0]; if (k) { goto L_060ADD50; } }  // 060ADC88 bt/s 0x060ADD50 ; mov r0,r7
    c.r[0] = 0xFFFFFFFEu;  // 060ADC8C mov #-2,r0
    c.r[5] &= c.r[0];  // 060ADC8E and r0,r5
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[5] + 8);  // 060ADC90 mov.w @(8,r5),r0
    c.r[3] = c.r[2];  // 060ADC92 mov r2,r3
    c.r[3] = c.r[0] << 16 | c.r[3] >> 16;  // 060ADC94 xtrct r0,r3
    c.t = (int32_t)c.r[1] > 0;  // 060ADC96 cmp/pl r1
    { const bool k = c.t; st32(c.r[7] + 4, c.r[3]); if (k) { goto L_060ADCD4; } }  // 060ADC98 bt/s 0x060ADCD4 ; mov.l r3,@(4,r7)
    c.r[0] = ld32(c.gbr + 104);  // 060ADC9C mov.l @(104,gbr),r0
    c.r[3] = 0u - c.r[1];  // 060ADC9E neg r1,r3
    { uint64_t p = (uint64_t)c.r[3] * c.r[0]; c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060ADCA0 dmulu.l r0,r3
    c.r[1] = 0xFFFFFFFFu;  // 060ADCA2 mov #-1,r1
    c.r[1] <<= 8;  // 060ADCA4 shll8 r1
    c.r[0] = c.mach;  // 060ADCA6 sts mach,r0
    c.r[3] = c.macl;  // 060ADCA8 sts macl,r3
    c.r[3] = c.r[0] << 16 | c.r[3] >> 16;  // 060ADCAA xtrct r0,r3
    st32(c.r[1], c.r[2]);  // 060ADCAC mov.l r2,@(0,r1)
    c.r[0] = c.r[3] << 16 | c.r[3] >> 16;  // 060ADCAE swap.w r3,r0
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060ADCB0 exts.w r0,r0
    st32(c.r[1] + 16, c.r[0]);  // 060ADCB2 mov.l r0,@(16,r1)
    c.r[3] <<= 16;  // 060ADCB4 shll16 r3
    st32(c.r[1] + 20, c.r[3]);  // 060ADCB6 mov.l r3,@(20,r1)
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[5]); c.r[5] += 2;  // 060ADCB8 mov.w @r5+,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[5]); c.r[5] += 2;  // 060ADCBA mov.w @r5+,r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[5]); c.r[5] += 2;  // 060ADCBC mov.w @r5+,r3
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[5]); c.r[5] += 2;  // 060ADCBE mov.w @r5+,r0
    c.r[3] <<= 16;  // 060ADCC0 shll16 r3
    c.r[3] = c.r[2] << 16 | c.r[3] >> 16;  // 060ADCC2 xtrct r2,r3
    st32(c.r[7] + 12, c.r[3]);  // 060ADCC4 mov.l r3,@(12,r7)
    c.r[0] <<= 16;  // 060ADCC6 shll16 r0
    c.r[0] = c.r[1] << 16 | c.r[0] >> 16;  // 060ADCC8 xtrct r1,r0
    st32(c.r[7] + 8, c.r[0]);  // 060ADCCA mov.l r0,@(8,r7)
    c.r[1] = 0xFFFFFFFFu;  // 060ADCCC mov #-1,r1
    c.r[1] <<= 8;  // 060ADCCE shll8 r1
    c.r[1] = ld32(c.r[1] + 28);  // 060ADCD0 mov.l @(28,r1),r1
    st32(c.r[7] + 24, c.r[1]); goto L_060ADCEA;  // 060ADCD2 bra 0x060ADCEA ; mov.l r1,@(24,r7)
L_060ADCD4:
    st32(c.r[7] + 24, c.r[1]);  // 060ADCD4 mov.l r1,@(24,r7)
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[5]); c.r[5] += 2;  // 060ADCD6 mov.w @r5+,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[5]); c.r[5] += 2;  // 060ADCD8 mov.w @r5+,r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[5]); c.r[5] += 2;  // 060ADCDA mov.w @r5+,r3
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[5]); c.r[5] += 2;  // 060ADCDC mov.w @r5+,r0
    c.r[3] <<= 16;  // 060ADCDE shll16 r3
    c.r[3] = c.r[2] << 16 | c.r[3] >> 16;  // 060ADCE0 xtrct r2,r3
    st32(c.r[7] + 12, c.r[3]);  // 060ADCE2 mov.l r3,@(12,r7)
    c.r[0] <<= 16;  // 060ADCE4 shll16 r0
    c.r[0] = c.r[1] << 16 | c.r[0] >> 16;  // 060ADCE6 xtrct r1,r0
    st32(c.r[7] + 8, c.r[0]);  // 060ADCE8 mov.l r0,@(8,r7)
L_060ADCEA:
    c.r[0] = ld32(c.r[4]);  // 060ADCEA mov.l @(0,r4),r0
    c.r[1] = ld32(c.r[4] + 4);  // 060ADCEC mov.l @(4,r4),r1
    st32(c.r[7] + 16, c.r[0]);  // 060ADCEE mov.l r0,@(16,r7)
    c.r[6] = c.r[6] & 0xFFFFu;  // 060ADCF0 extu.w r6,r6
    c.t = (c.r[6] & c.r[6]) == 0;  // 060ADCF2 tst r6,r6
    { const bool k = c.t; st32(c.r[7] + 20, c.r[1]); if (k) { goto L_060ADD40; } }  // 060ADCF4 bt/s 0x060ADD40 ; mov.l r1,@(20,r7)
    c.r[0] = (c.r[6] & 0xFFFF0000u) | (c.r[6] & 0xFFu) << 8 | (c.r[6] >> 8 & 0xFFu);  // 060ADCF8 swap.b r6,r0
    c.r[0] >>= 2;  // 060ADCFA shlr2 r0
    c.r[0] >>= 2;  // 060ADCFC shlr2 r0
    c.r[2] = 0xCu;  // 060ADCFE mov #12,r2
    c.r[2] &= c.r[0];  // 060ADD00 and r0,r2
    c.r[0] = 0x060ADD60u;  // 060ADD02 mova 0x060ADD60,r0
    c.r[2] += c.r[0];  // 060ADD04 add r0,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]); c.r[2] += 1;  // 060ADD06 mov.b @r2+,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]); c.r[2] += 1;  // 060ADD08 mov.b @r2+,r0
    c.r[5] = c.r[6];  // 060ADD0A mov r6,r5
    c.r[6] ^= c.r[1];  // 060ADD0C xor r1,r6
    c.r[1] = (uint32_t)(int16_t)ld16(0x060ADD70u);  // 060ADD0E mov.w 0x060ADD70,r1
    c.r[5] ^= c.r[0];  // 060ADD10 xor r0,r5
    c.r[0] = ld32(0x060ADD5Cu);  // 060ADD12 mov.l 0x060ADD5C,r0
    c.r[6] &= c.r[1];  // 060ADD14 and r1,r6
    c.r[5] &= c.r[1];  // 060ADD16 and r1,r5
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[6]);  // 060ADD18 mov.w @(r0,r6),r6
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[5]);  // 060ADD1A mov.w @(r0,r5),r5
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]); c.r[2] += 1;  // 060ADD1C mov.b @r2+,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]); c.r[2] += 1;  // 060ADD1E mov.b @r2+,r1
    c.r[6] = c.r[6] & 0xFFFFu;  // 060ADD20 extu.w r6,r6
    c.r[5] = c.r[5] & 0xFFFFu;  // 060ADD22 extu.w r5,r5
    c.r[6] += 2;  // 060ADD24 add #2,r6
    c.r[5] += 2;  // 060ADD26 add #2,r5
    c.r[6] ^= c.r[0];  // 060ADD28 xor r0,r6
    c.r[5] ^= c.r[1];  // 060ADD2A xor r1,r5
    st32(c.r[7] + 28, c.r[6]);  // 060ADD2C mov.l r6,@(28,r7)
    st32(c.r[7] + 32, c.r[5]);  // 060ADD2E mov.l r5,@(32,r7)
    c.r[0] = 0x18u;  // 060ADD30 mov #24,r0
    st32(c.r[7], c.r[0]);  // 060ADD32 mov.l r0,@(0,r7)
    c.r[0] = 0x24u;  // 060ADD34 mov #36,r0
    c.r[0] += c.r[7];  // 060ADD36 add r7,r0
    c.r[1] = ld32(0x060ADD58u);  // 060ADD38 mov.l 0x060ADD58,r1
    st32(c.gbr + 72, c.r[0]);  // 060ADD3A mov.l r0,@(72,gbr)
    { const uint32_t x = c.pr; st16(c.r[1], c.r[0]); c.pc = x; return; }  // 060ADD3C rts ; mov.w r0,@r1
L_060ADD40:
    c.r[0] = 0x1Cu;  // 060ADD40 mov #28,r0
    st32(c.r[7], c.r[0]);  // 060ADD42 mov.l r0,@(0,r7)
    c.r[0] = 0x1Cu;  // 060ADD44 mov #28,r0
    c.r[0] += c.r[7];  // 060ADD46 add r7,r0
    c.r[1] = ld32(0x060ADD58u);  // 060ADD48 mov.l 0x060ADD58,r1
    st32(c.gbr + 72, c.r[0]);  // 060ADD4A mov.l r0,@(72,gbr)
    { const uint32_t x = c.pr; st16(c.r[1], c.r[0]); c.pc = x; return; }  // 060ADD4C rts ; mov.w r0,@r1
L_060ADD50:
    { const uint32_t x = c.pr; c.r[0] = 0x0u; c.pc = x; return; }  // 060ADD50 rts ; mov #0,r0
}

void f_060ADD74(SH2Context& c) {
    ran[2934] = 1;
    c.r[0] = ld32(0x060ADDE4u);  // 060ADD74 mov.l 0x060ADDE4,r0
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060ADD76 sts.l pr,@-r15
    { const uint32_t x = c.r[0]; c.pr = 0x060ADD7Cu; c.r[2] = c.r[5]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060ADD7Cu) return; }  // 060ADD78 jsr @r0 ; mov r5,r2
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060ADD7C lds.l @r15+,pr
    c.r[0] = ld32(c.gbr + 48);  // 060ADD7E mov.l @(48,gbr),r0
    c.r[1] = 0x28u;  // 060ADD80 mov #40,r1
    c.r[7] = c.r[0];  // 060ADD82 mov r0,r7
    c.r[0] = ld32(c.gbr + 72);  // 060ADD84 mov.l @(72,gbr),r0
    c.r[3] = 0x1u;  // 060ADD86 mov #1,r3
    st32(c.r[0], c.r[1]);  // 060ADD88 mov.l r1,@(0,r0)
    st32(c.r[0] + 4, c.r[7]);  // 060ADD8A mov.l r7,@(4,r0)
    st32(c.r[0] + 8, c.r[3]);  // 060ADD8C mov.l r3,@(8,r0)
    c.r[1] = 0x0u;  // 060ADD8E mov #0,r1
    st32(c.r[0] + 12, c.r[1]);  // 060ADD90 mov.l r1,@(12,r0)
    c.r[0] += 16;  // 060ADD92 add #16,r0
    c.r[6] = c.r[0];  // 060ADD94 mov r0,r6
    c.r[0] = c.r[2] << 16 | c.r[2] >> 16;  // 060ADD96 swap.w r2,r0
    st16(c.r[7] + 30, c.r[0]);  // 060ADD98 mov.w r0,@(30,r7)
    c.r[5] = 0xFu;  // 060ADD9A mov #15,r5
    c.r[3] = 0xFFFFFF80u;  // 060ADD9C mov #-128,r3
L_060ADD9E:
    c.r[0] = ld32(c.r[3] + 12);  // 060ADD9E mov.l @(12,r3),r0
    c.r[0] &= 0x3u;  // 060ADDA0 and #3,r0
    c.t = c.r[0] == 0x1u;  // 060ADDA2 cmp/eq #1,r0
    if (c.t) { SH2_POLL(c); goto L_060ADD9E; }  // 060ADDA4 bt 0x060ADD9E
    c.r[0] = ld32(c.r[3] + 48);  // 060ADDA6 mov.l @(48,r3),r0
    c.r[0] = 0x0u;  // 060ADDA8 mov #0,r0
    st32(c.r[3] + 12, c.r[0]);  // 060ADDAA mov.l r0,@(12,r3)
    c.r[3] = 0xFFFFFF9Cu;  // 060ADDAC mov #-100,r3
    c.r[3] <<= 2;  // 060ADDAE shll2 r3
    st8(c.r[3] + 1, c.r[0]);  // 060ADDB0 mov.b r0,@(1,r3)
    c.r[3] = 0xFFFFFF80u;  // 060ADDB2 mov #-128,r3
    st32(c.r[3], c.r[4]);  // 060ADDB4 mov.l r4,@(0,r3)
    st32(c.r[3] + 4, c.r[7]);  // 060ADDB6 mov.l r7,@(4,r3)
    st32(c.r[3] + 8, c.r[5]);  // 060ADDB8 mov.l r5,@(8,r3)
    c.r[0] = (uint32_t)(int16_t)ld16(0x060ADDE2u);  // 060ADDBA mov.w 0x060ADDE2,r0
    st32(c.r[3] + 12, c.r[0]);  // 060ADDBC mov.l r0,@(12,r3)
    c.r[0] = 0x9u;  // 060ADDBE mov #9,r0
    st32(c.r[3] + 48, c.r[0]);  // 060ADDC0 mov.l r0,@(48,r3)
    c.r[1] = 0xFFFFFF80u;  // 060ADDC2 mov #-128,r1
L_060ADDC4:
    c.r[0] = ld32(c.r[1] + 12);  // 060ADDC4 mov.l @(12,r1),r0
    c.r[0] &= 0x3u;  // 060ADDC6 and #3,r0
    c.t = c.r[0] == 0x1u;  // 060ADDC8 cmp/eq #1,r0
    if (c.t) { SH2_POLL(c); goto L_060ADDC4; }  // 060ADDCA bt 0x060ADDC4
    c.r[0] = c.r[6];  // 060ADDCC mov r6,r0
    c.r[6] = ld32(0x060ADDE8u);  // 060ADDCE mov.l 0x060ADDE8,r6
    st32(c.gbr + 72, c.r[0]);  // 060ADDD0 mov.l r0,@(72,gbr)
    st16(c.r[6], c.r[0]);  // 060ADDD2 mov.w r0,@r6
    c.r[0] = 0xFFFFFFDCu;  // 060ADDD4 mov #-36,r0
    c.r[0] += c.r[7];  // 060ADDD6 add r7,r0
    st32(c.gbr + 48, c.r[0]);  // 060ADDD8 mov.l r0,@(48,gbr)
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 060ADDDA rts ; mov #1,r0
}

void f_060ADDEC(SH2Context& c) {
    ran[2935] = 1;
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 224);  // 060ADDEC mov.w @(224,gbr),r0
    c.r[0] |= c.r[4];  // 060ADDEE or r4,r0
    c.r[4] >>= 16;  // 060ADDF0 shlr16 r4
    c.r[4] = ~c.r[4];  // 060ADDF2 not r4,r4
    c.r[0] &= c.r[4];  // 060ADDF4 and r4,r0
    { const uint32_t x = c.pr; st16(c.gbr + 224, c.r[0]); c.pc = x; return; }  // 060ADDF6 rts ; mov.w r0,@(224,gbr)
}

void f_060ADDFC(SH2Context& c) {
    ran[2936] = 1;
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 420);  // 060ADDFC mov.w @(420,gbr),r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x060ADE0Cu);  // 060ADDFE mov.w 0x060ADE0C,r1
    c.r[0] &= c.r[1];  // 060ADE00 and r1,r0
    c.r[4] <<= 2;  // 060ADE02 shll2 r4
    c.r[4] <<= 2;  // 060ADE04 shll2 r4
    c.r[0] |= c.r[4];  // 060ADE06 or r4,r0
    { const uint32_t x = c.pr; st16(c.gbr + 420, c.r[0]); c.pc = x; return; }  // 060ADE08 rts ; mov.w r0,@(420,gbr)
}

void f_060ADE10(SH2Context& c) {
    ran[2937] = 1;
    c.r[4] |= c.r[5];  // 060ADE10 or r5,r4
    c.r[0] = c.r[4];  // 060ADE12 mov r4,r0
    st8(c.gbr + 234, c.r[0]);  // 060ADE14 mov.b r0,@(234,gbr)
    c.r[1] = 0x14u;  // 060ADE16 mov #20,r1
    c.r[2] = 0x38u; goto L_060ADEE0;  // 060ADE18 bra 0x060ADEE0 ; mov #56,r2
L_060ADEE0:
    c.r[3] = ld32(0x060ADF18u);  // 060ADEE0 mov.l 0x060ADF18,r3
    c.t = (c.r[0] & 0x1u) == 0;  // 060ADEE2 tst #1,r0
    { const bool k = !c.t; c.r[2] += c.r[3]; if (k) { goto L_060ADEFE; } }  // 060ADEE4 bf/s 0x060ADEFE ; add r3,r2
    c.r[0] = ld32(0x060ADF1Cu);  // 060ADEE8 mov.l 0x060ADF1C,r0
    c.r[3] = ld32(c.r[0] + c.r[1]);  // 060ADEEA mov.l @(r0,r1),r3
    c.r[1] = 0x1Fu;  // 060ADEEC mov #31,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2] + 1);  // 060ADEEE mov.b @(1,r2),r0
    c.t = c.r[3] >> 31; c.r[3] <<= 1;  // 060ADEF0 shll r3
    c.r[3] >>= 16;  // 060ADEF2 shlr16 r3
    c.r[0] &= 0xE0u;  // 060ADEF4 and #224,r0
    c.r[1] &= c.r[3];  // 060ADEF6 and r3,r1
    c.r[0] |= c.r[1];  // 060ADEF8 or r1,r0
    { const uint32_t x = c.pr; st8(c.r[2] + 1, c.r[0]); c.pc = x; return; }  // 060ADEFA rts ; mov.b r0,@(1,r2)
L_060ADEFE:
    c.r[0] = ld32(0x060ADF1Cu);  // 060ADEFE mov.l 0x060ADF1C,r0
    c.r[3] = ld32(c.r[0] + c.r[1]);  // 060ADF00 mov.l @(r0,r1),r3
    c.r[1] = 0x3u;  // 060ADF02 mov #3,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2] + 1);  // 060ADF04 mov.b @(1,r2),r0
    c.r[3] >>= 2;  // 060ADF06 shlr2 r3
    c.r[3] >>= 2;  // 060ADF08 shlr2 r3
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 060ADF0A shlr r3
    c.r[0] &= 0xFCu;  // 060ADF0C and #252,r0
    c.r[1] &= c.r[3];  // 060ADF0E and r3,r1
    c.r[0] |= c.r[1];  // 060ADF10 or r1,r0
    { const uint32_t x = c.pr; st8(c.r[2] + 1, c.r[0]); c.pc = x; return; }  // 060ADF12 rts ; mov.b r0,@(1,r2)
}

void f_060ADE1C(SH2Context& c) {
    ran[2938] = 1;
    c.r[4] |= c.r[5];  // 060ADE1C or r5,r4
    c.r[0] = c.r[4];  // 060ADE1E mov r4,r0
    st8(c.gbr + 233, c.r[0]);  // 060ADE20 mov.b r0,@(233,gbr)
    c.r[1] = 0x4u;  // 060ADE22 mov #4,r1
    c.r[2] = 0x30u; goto L_060ADEE0;  // 060ADE24 bra 0x060ADEE0 ; mov #48,r2
L_060ADEE0:
    c.r[3] = ld32(0x060ADF18u);  // 060ADEE0 mov.l 0x060ADF18,r3
    c.t = (c.r[0] & 0x1u) == 0;  // 060ADEE2 tst #1,r0
    { const bool k = !c.t; c.r[2] += c.r[3]; if (k) { goto L_060ADEFE; } }  // 060ADEE4 bf/s 0x060ADEFE ; add r3,r2
    c.r[0] = ld32(0x060ADF1Cu);  // 060ADEE8 mov.l 0x060ADF1C,r0
    c.r[3] = ld32(c.r[0] + c.r[1]);  // 060ADEEA mov.l @(r0,r1),r3
    c.r[1] = 0x1Fu;  // 060ADEEC mov #31,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2] + 1);  // 060ADEEE mov.b @(1,r2),r0
    c.t = c.r[3] >> 31; c.r[3] <<= 1;  // 060ADEF0 shll r3
    c.r[3] >>= 16;  // 060ADEF2 shlr16 r3
    c.r[0] &= 0xE0u;  // 060ADEF4 and #224,r0
    c.r[1] &= c.r[3];  // 060ADEF6 and r3,r1
    c.r[0] |= c.r[1];  // 060ADEF8 or r1,r0
    { const uint32_t x = c.pr; st8(c.r[2] + 1, c.r[0]); c.pc = x; return; }  // 060ADEFA rts ; mov.b r0,@(1,r2)
L_060ADEFE:
    c.r[0] = ld32(0x060ADF1Cu);  // 060ADEFE mov.l 0x060ADF1C,r0
    c.r[3] = ld32(c.r[0] + c.r[1]);  // 060ADF00 mov.l @(r0,r1),r3
    c.r[1] = 0x3u;  // 060ADF02 mov #3,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2] + 1);  // 060ADF04 mov.b @(1,r2),r0
    c.r[3] >>= 2;  // 060ADF06 shlr2 r3
    c.r[3] >>= 2;  // 060ADF08 shlr2 r3
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 060ADF0A shlr r3
    c.r[0] &= 0xFCu;  // 060ADF0C and #252,r0
    c.r[1] &= c.r[3];  // 060ADF0E and r3,r1
    c.r[0] |= c.r[1];  // 060ADF10 or r1,r0
    { const uint32_t x = c.pr; st8(c.r[2] + 1, c.r[0]); c.pc = x; return; }  // 060ADF12 rts ; mov.b r0,@(1,r2)
}

void f_060ADE28(SH2Context& c) {
    ran[2939] = 1;
    c.r[4] |= c.r[5];  // 060ADE28 or r5,r4
    c.r[0] = c.r[4];  // 060ADE2A mov r4,r0
    st8(c.gbr + 232, c.r[0]);  // 060ADE2C mov.b r0,@(232,gbr)
    c.r[1] = 0x8u;  // 060ADE2E mov #8,r1
    c.r[2] = 0x32u; goto L_060ADEE0;  // 060ADE30 bra 0x060ADEE0 ; mov #50,r2
L_060ADEE0:
    c.r[3] = ld32(0x060ADF18u);  // 060ADEE0 mov.l 0x060ADF18,r3
    c.t = (c.r[0] & 0x1u) == 0;  // 060ADEE2 tst #1,r0
    { const bool k = !c.t; c.r[2] += c.r[3]; if (k) { goto L_060ADEFE; } }  // 060ADEE4 bf/s 0x060ADEFE ; add r3,r2
    c.r[0] = ld32(0x060ADF1Cu);  // 060ADEE8 mov.l 0x060ADF1C,r0
    c.r[3] = ld32(c.r[0] + c.r[1]);  // 060ADEEA mov.l @(r0,r1),r3
    c.r[1] = 0x1Fu;  // 060ADEEC mov #31,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2] + 1);  // 060ADEEE mov.b @(1,r2),r0
    c.t = c.r[3] >> 31; c.r[3] <<= 1;  // 060ADEF0 shll r3
    c.r[3] >>= 16;  // 060ADEF2 shlr16 r3
    c.r[0] &= 0xE0u;  // 060ADEF4 and #224,r0
    c.r[1] &= c.r[3];  // 060ADEF6 and r3,r1
    c.r[0] |= c.r[1];  // 060ADEF8 or r1,r0
    { const uint32_t x = c.pr; st8(c.r[2] + 1, c.r[0]); c.pc = x; return; }  // 060ADEFA rts ; mov.b r0,@(1,r2)
L_060ADEFE:
    c.r[0] = ld32(0x060ADF1Cu);  // 060ADEFE mov.l 0x060ADF1C,r0
    c.r[3] = ld32(c.r[0] + c.r[1]);  // 060ADF00 mov.l @(r0,r1),r3
    c.r[1] = 0x3u;  // 060ADF02 mov #3,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2] + 1);  // 060ADF04 mov.b @(1,r2),r0
    c.r[3] >>= 2;  // 060ADF06 shlr2 r3
    c.r[3] >>= 2;  // 060ADF08 shlr2 r3
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 060ADF0A shlr r3
    c.r[0] &= 0xFCu;  // 060ADF0C and #252,r0
    c.r[1] &= c.r[3];  // 060ADF0E and r3,r1
    c.r[0] |= c.r[1];  // 060ADF10 or r1,r0
    { const uint32_t x = c.pr; st8(c.r[2] + 1, c.r[0]); c.pc = x; return; }  // 060ADF12 rts ; mov.b r0,@(1,r2)
}

void f_060ADE34(SH2Context& c) {
    ran[2940] = 1;
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 235);  // 060ADE34 mov.b @(235,gbr),r0
    c.r[1] = 0xFFFFFFF0u;  // 060ADE36 mov #-16,r1
    c.r[0] &= c.r[1];  // 060ADE38 and r1,r0
    c.r[4] >>= 2;  // 060ADE3A shlr2 r4
    c.t = c.r[4] & 1; c.r[4] >>= 1;  // 060ADE3C shlr r4
    c.r[0] |= c.r[4];  // 060ADE3E or r4,r0
    c.r[0] |= c.r[5];  // 060ADE40 or r5,r0
    st8(c.gbr + 235, c.r[0]);  // 060ADE42 mov.b r0,@(235,gbr)
    c.r[1] = 0xCu;  // 060ADE44 mov #12,r1
    c.r[2] = 0x34u; goto L_060ADEE0;  // 060ADE46 bra 0x060ADEE0 ; mov #52,r2
L_060ADEE0:
    c.r[3] = ld32(0x060ADF18u);  // 060ADEE0 mov.l 0x060ADF18,r3
    c.t = (c.r[0] & 0x1u) == 0;  // 060ADEE2 tst #1,r0
    { const bool k = !c.t; c.r[2] += c.r[3]; if (k) { goto L_060ADEFE; } }  // 060ADEE4 bf/s 0x060ADEFE ; add r3,r2
    c.r[0] = ld32(0x060ADF1Cu);  // 060ADEE8 mov.l 0x060ADF1C,r0
    c.r[3] = ld32(c.r[0] + c.r[1]);  // 060ADEEA mov.l @(r0,r1),r3
    c.r[1] = 0x1Fu;  // 060ADEEC mov #31,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2] + 1);  // 060ADEEE mov.b @(1,r2),r0
    c.t = c.r[3] >> 31; c.r[3] <<= 1;  // 060ADEF0 shll r3
    c.r[3] >>= 16;  // 060ADEF2 shlr16 r3
    c.r[0] &= 0xE0u;  // 060ADEF4 and #224,r0
    c.r[1] &= c.r[3];  // 060ADEF6 and r3,r1
    c.r[0] |= c.r[1];  // 060ADEF8 or r1,r0
    { const uint32_t x = c.pr; st8(c.r[2] + 1, c.r[0]); c.pc = x; return; }  // 060ADEFA rts ; mov.b r0,@(1,r2)
L_060ADEFE:
    c.r[0] = ld32(0x060ADF1Cu);  // 060ADEFE mov.l 0x060ADF1C,r0
    c.r[3] = ld32(c.r[0] + c.r[1]);  // 060ADF00 mov.l @(r0,r1),r3
    c.r[1] = 0x3u;  // 060ADF02 mov #3,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2] + 1);  // 060ADF04 mov.b @(1,r2),r0
    c.r[3] >>= 2;  // 060ADF06 shlr2 r3
    c.r[3] >>= 2;  // 060ADF08 shlr2 r3
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 060ADF0A shlr r3
    c.r[0] &= 0xFCu;  // 060ADF0C and #252,r0
    c.r[1] &= c.r[3];  // 060ADF0E and r3,r1
    c.r[0] |= c.r[1];  // 060ADF10 or r1,r0
    { const uint32_t x = c.pr; st8(c.r[2] + 1, c.r[0]); c.pc = x; return; }  // 060ADF12 rts ; mov.b r0,@(1,r2)
}

void f_060ADE4A(SH2Context& c) {
    ran[2941] = 1;
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 235);  // 060ADE4A mov.b @(235,gbr),r0
    c.t = c.r[4] >> 31; c.r[4] <<= 1;  // 060ADE4C shll r4
    c.r[0] &= 0xFu;  // 060ADE4E and #15,r0
    c.r[5] <<= 2;  // 060ADE50 shll2 r5
    c.r[5] <<= 2;  // 060ADE52 shll2 r5
    c.r[4] |= c.r[5];  // 060ADE54 or r5,r4
    c.r[0] |= c.r[4];  // 060ADE56 or r4,r0
    st8(c.gbr + 235, c.r[0]);  // 060ADE58 mov.b r0,@(235,gbr)
    c.r[0] = c.r[5];  // 060ADE5A mov r5,r0
    c.r[1] = 0x10u;  // 060ADE5C mov #16,r1
    c.r[2] = 0x36u; goto L_060ADEE0;  // 060ADE5E bra 0x060ADEE0 ; mov #54,r2
L_060ADEE0:
    c.r[3] = ld32(0x060ADF18u);  // 060ADEE0 mov.l 0x060ADF18,r3
    c.t = (c.r[0] & 0x1u) == 0;  // 060ADEE2 tst #1,r0
    { const bool k = !c.t; c.r[2] += c.r[3]; if (k) { goto L_060ADEFE; } }  // 060ADEE4 bf/s 0x060ADEFE ; add r3,r2
    c.r[0] = ld32(0x060ADF1Cu);  // 060ADEE8 mov.l 0x060ADF1C,r0
    c.r[3] = ld32(c.r[0] + c.r[1]);  // 060ADEEA mov.l @(r0,r1),r3
    c.r[1] = 0x1Fu;  // 060ADEEC mov #31,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2] + 1);  // 060ADEEE mov.b @(1,r2),r0
    c.t = c.r[3] >> 31; c.r[3] <<= 1;  // 060ADEF0 shll r3
    c.r[3] >>= 16;  // 060ADEF2 shlr16 r3
    c.r[0] &= 0xE0u;  // 060ADEF4 and #224,r0
    c.r[1] &= c.r[3];  // 060ADEF6 and r3,r1
    c.r[0] |= c.r[1];  // 060ADEF8 or r1,r0
    { const uint32_t x = c.pr; st8(c.r[2] + 1, c.r[0]); c.pc = x; return; }  // 060ADEFA rts ; mov.b r0,@(1,r2)
L_060ADEFE:
    c.r[0] = ld32(0x060ADF1Cu);  // 060ADEFE mov.l 0x060ADF1C,r0
    c.r[3] = ld32(c.r[0] + c.r[1]);  // 060ADF00 mov.l @(r0,r1),r3
    c.r[1] = 0x3u;  // 060ADF02 mov #3,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2] + 1);  // 060ADF04 mov.b @(1,r2),r0
    c.r[3] >>= 2;  // 060ADF06 shlr2 r3
    c.r[3] >>= 2;  // 060ADF08 shlr2 r3
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 060ADF0A shlr r3
    c.r[0] &= 0xFCu;  // 060ADF0C and #252,r0
    c.r[1] &= c.r[3];  // 060ADF0E and r3,r1
    c.r[0] |= c.r[1];  // 060ADF10 or r1,r0
    { const uint32_t x = c.pr; st8(c.r[2] + 1, c.r[0]); c.pc = x; return; }  // 060ADF12 rts ; mov.b r0,@(1,r2)
}

void f_060ADE62(SH2Context& c) {
    ran[2942] = 1;
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060ADE62 sts.l pr,@-r15
    c.r[0] = ld32(0x060ADF20u);  // 060ADE64 mov.l 0x060ADF20,r0
    c.r[15] -= 4; st32(c.r[15], c.r[5]);  // 060ADE66 mov.l r5,@-r15
    { const uint32_t x = c.r[0]; c.pr = 0x060ADE6Cu; c.r[5] = 0x3u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060ADE6Cu) return; }  // 060ADE68 jsr @r0 ; mov #3,r5
    c.r[5] = ld32(c.r[15]); c.r[15] += 4;  // 060ADE6C mov.l @r15+,r5
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060ADE6E lds.l @r15+,pr
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 234);  // 060ADE70 mov.b @(234,gbr),r0
    c.r[1] = 0x14u;  // 060ADE72 mov #20,r1
    c.r[2] = 0x38u; goto L_060ADE9A;  // 060ADE74 bra 0x060ADE9A ; mov #56,r2
L_060ADE9A:
    c.r[3] = c.r[0];  // 060ADE9A mov r0,r3
    c.r[0] = ld32(0x060ADF1Cu);  // 060ADE9C mov.l 0x060ADF1C,r0
    st32(c.r[0] + c.r[1], c.r[4]);  // 060ADE9E mov.l r4,@(r0,r1)
    c.r[0] = 0x1u;  // 060ADEA0 mov #1,r0
    c.t = (c.r[3] & c.r[0]) == 0;  // 060ADEA2 tst r0,r3
    { const bool k = c.t; c.r[1] = 0x1Fu; if (k) { goto L_060ADEB8; } }  // 060ADEA4 bt/s 0x060ADEB8 ; mov #31,r1
    c.r[3] = c.r[4];  // 060ADEA8 mov r4,r3
    c.r[3] >>= 2;  // 060ADEAA shlr2 r3
    c.r[3] >>= 2;  // 060ADEAC shlr2 r3
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 060ADEAE shlr r3
    c.r[0] = 0x3u;  // 060ADEB0 mov #3,r0
    c.r[0] &= c.r[3];  // 060ADEB2 and r3,r0
    c.r[6] |= c.r[0];  // 060ADEB4 or r0,r6
    c.r[1] = 0x1Cu;  // 060ADEB6 mov #28,r1
L_060ADEB8:
    c.t = c.r[4] >> 31; c.r[4] <<= 1;  // 060ADEB8 shll r4
    c.r[4] >>= 16;  // 060ADEBA shlr16 r4
    c.r[1] &= c.r[4];  // 060ADEBC and r4,r1
    c.r[1] |= c.r[6];  // 060ADEBE or r6,r1
    c.r[5] >>= 8;  // 060ADEC0 shlr8 r5
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 206);  // 060ADEC2 mov.w @(206,gbr),r0
    c.r[0] >>= 8;  // 060ADEC4 shlr8 r0
    c.t = (c.r[0] & 0x20u) == 0;  // 060ADEC6 tst #32,r0
    { const bool k = c.t; c.t = c.r[5] & 1; c.r[5] >>= 1; if (k) { goto L_060ADECE; } }  // 060ADEC8 bt/s 0x060ADECE ; shlr r5
    c.t = c.r[5] & 1; c.r[5] >>= 1;  // 060ADECC shlr r5
L_060ADECE:
    c.r[0] = 0x7u;  // 060ADECE mov #7,r0
    c.r[5] &= c.r[0];  // 060ADED0 and r0,r5
    c.t = c.r[5] >> 31; c.r[5] <<= 1;  // 060ADED2 shll r5
    c.r[5] <<= 2;  // 060ADED4 shll2 r5
    c.r[5] <<= 2;  // 060ADED6 shll2 r5
    c.r[1] |= c.r[5];  // 060ADED8 or r5,r1
    c.r[0] = ld32(0x060ADF18u);  // 060ADEDA mov.l 0x060ADF18,r0
    { const uint32_t x = c.pr; st16(c.r[0] + c.r[2], c.r[1]); c.pc = x; return; }  // 060ADEDC rts ; mov.w r1,@(r0,r2)
}

void f_060ADE78(SH2Context& c) {
    ran[2943] = 1;
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 232);  // 060ADE78 mov.b @(232,gbr),r0
    c.r[1] = 0x8u;  // 060ADE7A mov #8,r1
    c.r[2] = 0x32u; goto L_060ADE9A;  // 060ADE7C bra 0x060ADE9A ; mov #50,r2
L_060ADE9A:
    c.r[3] = c.r[0];  // 060ADE9A mov r0,r3
    c.r[0] = ld32(0x060ADF1Cu);  // 060ADE9C mov.l 0x060ADF1C,r0
    st32(c.r[0] + c.r[1], c.r[4]);  // 060ADE9E mov.l r4,@(r0,r1)
    c.r[0] = 0x1u;  // 060ADEA0 mov #1,r0
    c.t = (c.r[3] & c.r[0]) == 0;  // 060ADEA2 tst r0,r3
    { const bool k = c.t; c.r[1] = 0x1Fu; if (k) { goto L_060ADEB8; } }  // 060ADEA4 bt/s 0x060ADEB8 ; mov #31,r1
    c.r[3] = c.r[4];  // 060ADEA8 mov r4,r3
    c.r[3] >>= 2;  // 060ADEAA shlr2 r3
    c.r[3] >>= 2;  // 060ADEAC shlr2 r3
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 060ADEAE shlr r3
    c.r[0] = 0x3u;  // 060ADEB0 mov #3,r0
    c.r[0] &= c.r[3];  // 060ADEB2 and r3,r0
    c.r[6] |= c.r[0];  // 060ADEB4 or r0,r6
    c.r[1] = 0x1Cu;  // 060ADEB6 mov #28,r1
L_060ADEB8:
    c.t = c.r[4] >> 31; c.r[4] <<= 1;  // 060ADEB8 shll r4
    c.r[4] >>= 16;  // 060ADEBA shlr16 r4
    c.r[1] &= c.r[4];  // 060ADEBC and r4,r1
    c.r[1] |= c.r[6];  // 060ADEBE or r6,r1
    c.r[5] >>= 8;  // 060ADEC0 shlr8 r5
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 206);  // 060ADEC2 mov.w @(206,gbr),r0
    c.r[0] >>= 8;  // 060ADEC4 shlr8 r0
    c.t = (c.r[0] & 0x20u) == 0;  // 060ADEC6 tst #32,r0
    { const bool k = c.t; c.t = c.r[5] & 1; c.r[5] >>= 1; if (k) { goto L_060ADECE; } }  // 060ADEC8 bt/s 0x060ADECE ; shlr r5
    c.t = c.r[5] & 1; c.r[5] >>= 1;  // 060ADECC shlr r5
L_060ADECE:
    c.r[0] = 0x7u;  // 060ADECE mov #7,r0
    c.r[5] &= c.r[0];  // 060ADED0 and r0,r5
    c.t = c.r[5] >> 31; c.r[5] <<= 1;  // 060ADED2 shll r5
    c.r[5] <<= 2;  // 060ADED4 shll2 r5
    c.r[5] <<= 2;  // 060ADED6 shll2 r5
    c.r[1] |= c.r[5];  // 060ADED8 or r5,r1
    c.r[0] = ld32(0x060ADF18u);  // 060ADEDA mov.l 0x060ADF18,r0
    { const uint32_t x = c.pr; st16(c.r[0] + c.r[2], c.r[1]); c.pc = x; return; }  // 060ADEDC rts ; mov.w r1,@(r0,r2)
}

void f_060ADE80(SH2Context& c) {
    ran[2944] = 1;
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 235);  // 060ADE80 mov.b @(235,gbr),r0
    c.r[1] = 0xCu;  // 060ADE82 mov #12,r1
    c.r[2] = 0x34u; goto L_060ADE9A;  // 060ADE84 bra 0x060ADE9A ; mov #52,r2
L_060ADE9A:
    c.r[3] = c.r[0];  // 060ADE9A mov r0,r3
    c.r[0] = ld32(0x060ADF1Cu);  // 060ADE9C mov.l 0x060ADF1C,r0
    st32(c.r[0] + c.r[1], c.r[4]);  // 060ADE9E mov.l r4,@(r0,r1)
    c.r[0] = 0x1u;  // 060ADEA0 mov #1,r0
    c.t = (c.r[3] & c.r[0]) == 0;  // 060ADEA2 tst r0,r3
    { const bool k = c.t; c.r[1] = 0x1Fu; if (k) { goto L_060ADEB8; } }  // 060ADEA4 bt/s 0x060ADEB8 ; mov #31,r1
    c.r[3] = c.r[4];  // 060ADEA8 mov r4,r3
    c.r[3] >>= 2;  // 060ADEAA shlr2 r3
    c.r[3] >>= 2;  // 060ADEAC shlr2 r3
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 060ADEAE shlr r3
    c.r[0] = 0x3u;  // 060ADEB0 mov #3,r0
    c.r[0] &= c.r[3];  // 060ADEB2 and r3,r0
    c.r[6] |= c.r[0];  // 060ADEB4 or r0,r6
    c.r[1] = 0x1Cu;  // 060ADEB6 mov #28,r1
L_060ADEB8:
    c.t = c.r[4] >> 31; c.r[4] <<= 1;  // 060ADEB8 shll r4
    c.r[4] >>= 16;  // 060ADEBA shlr16 r4
    c.r[1] &= c.r[4];  // 060ADEBC and r4,r1
    c.r[1] |= c.r[6];  // 060ADEBE or r6,r1
    c.r[5] >>= 8;  // 060ADEC0 shlr8 r5
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 206);  // 060ADEC2 mov.w @(206,gbr),r0
    c.r[0] >>= 8;  // 060ADEC4 shlr8 r0
    c.t = (c.r[0] & 0x20u) == 0;  // 060ADEC6 tst #32,r0
    { const bool k = c.t; c.t = c.r[5] & 1; c.r[5] >>= 1; if (k) { goto L_060ADECE; } }  // 060ADEC8 bt/s 0x060ADECE ; shlr r5
    c.t = c.r[5] & 1; c.r[5] >>= 1;  // 060ADECC shlr r5
L_060ADECE:
    c.r[0] = 0x7u;  // 060ADECE mov #7,r0
    c.r[5] &= c.r[0];  // 060ADED0 and r0,r5
    c.t = c.r[5] >> 31; c.r[5] <<= 1;  // 060ADED2 shll r5
    c.r[5] <<= 2;  // 060ADED4 shll2 r5
    c.r[5] <<= 2;  // 060ADED6 shll2 r5
    c.r[1] |= c.r[5];  // 060ADED8 or r5,r1
    c.r[0] = ld32(0x060ADF18u);  // 060ADEDA mov.l 0x060ADF18,r0
    { const uint32_t x = c.pr; st16(c.r[0] + c.r[2], c.r[1]); c.pc = x; return; }  // 060ADEDC rts ; mov.w r1,@(r0,r2)
}

void f_060ADE88(SH2Context& c) {
    ran[2945] = 1;
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 235);  // 060ADE88 mov.b @(235,gbr),r0
    c.r[1] = 0x10u;  // 060ADE8A mov #16,r1
    c.r[0] >>= 2;  // 060ADE8C shlr2 r0
    c.r[0] >>= 2;  // 060ADE8E shlr2 r0
    c.r[2] = 0x36u; goto L_060ADE9A;  // 060ADE90 bra 0x060ADE9A ; mov #54,r2
L_060ADE9A:
    c.r[3] = c.r[0];  // 060ADE9A mov r0,r3
    c.r[0] = ld32(0x060ADF1Cu);  // 060ADE9C mov.l 0x060ADF1C,r0
    st32(c.r[0] + c.r[1], c.r[4]);  // 060ADE9E mov.l r4,@(r0,r1)
    c.r[0] = 0x1u;  // 060ADEA0 mov #1,r0
    c.t = (c.r[3] & c.r[0]) == 0;  // 060ADEA2 tst r0,r3
    { const bool k = c.t; c.r[1] = 0x1Fu; if (k) { goto L_060ADEB8; } }  // 060ADEA4 bt/s 0x060ADEB8 ; mov #31,r1
    c.r[3] = c.r[4];  // 060ADEA8 mov r4,r3
    c.r[3] >>= 2;  // 060ADEAA shlr2 r3
    c.r[3] >>= 2;  // 060ADEAC shlr2 r3
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 060ADEAE shlr r3
    c.r[0] = 0x3u;  // 060ADEB0 mov #3,r0
    c.r[0] &= c.r[3];  // 060ADEB2 and r3,r0
    c.r[6] |= c.r[0];  // 060ADEB4 or r0,r6
    c.r[1] = 0x1Cu;  // 060ADEB6 mov #28,r1
L_060ADEB8:
    c.t = c.r[4] >> 31; c.r[4] <<= 1;  // 060ADEB8 shll r4
    c.r[4] >>= 16;  // 060ADEBA shlr16 r4
    c.r[1] &= c.r[4];  // 060ADEBC and r4,r1
    c.r[1] |= c.r[6];  // 060ADEBE or r6,r1
    c.r[5] >>= 8;  // 060ADEC0 shlr8 r5
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 206);  // 060ADEC2 mov.w @(206,gbr),r0
    c.r[0] >>= 8;  // 060ADEC4 shlr8 r0
    c.t = (c.r[0] & 0x20u) == 0;  // 060ADEC6 tst #32,r0
    { const bool k = c.t; c.t = c.r[5] & 1; c.r[5] >>= 1; if (k) { goto L_060ADECE; } }  // 060ADEC8 bt/s 0x060ADECE ; shlr r5
    c.t = c.r[5] & 1; c.r[5] >>= 1;  // 060ADECC shlr r5
L_060ADECE:
    c.r[0] = 0x7u;  // 060ADECE mov #7,r0
    c.r[5] &= c.r[0];  // 060ADED0 and r0,r5
    c.t = c.r[5] >> 31; c.r[5] <<= 1;  // 060ADED2 shll r5
    c.r[5] <<= 2;  // 060ADED4 shll2 r5
    c.r[5] <<= 2;  // 060ADED6 shll2 r5
    c.r[1] |= c.r[5];  // 060ADED8 or r5,r1
    c.r[0] = ld32(0x060ADF18u);  // 060ADEDA mov.l 0x060ADF18,r0
    { const uint32_t x = c.pr; st16(c.r[0] + c.r[2], c.r[1]); c.pc = x; return; }  // 060ADEDC rts ; mov.w r1,@(r0,r2)
}

void f_060ADE94(SH2Context& c) {
    ran[2946] = 1;
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 233);  // 060ADE94 mov.b @(233,gbr),r0
    c.r[1] = 0x4u;  // 060ADE96 mov #4,r1
    c.r[2] = 0x30u;  // 060ADE98 mov #48,r2
    c.r[3] = c.r[0];  // 060ADE9A mov r0,r3
    c.r[0] = ld32(0x060ADF1Cu);  // 060ADE9C mov.l 0x060ADF1C,r0
    st32(c.r[0] + c.r[1], c.r[4]);  // 060ADE9E mov.l r4,@(r0,r1)
    c.r[0] = 0x1u;  // 060ADEA0 mov #1,r0
    c.t = (c.r[3] & c.r[0]) == 0;  // 060ADEA2 tst r0,r3
    { const bool k = c.t; c.r[1] = 0x1Fu; if (k) { goto L_060ADEB8; } }  // 060ADEA4 bt/s 0x060ADEB8 ; mov #31,r1
    c.r[3] = c.r[4];  // 060ADEA8 mov r4,r3
    c.r[3] >>= 2;  // 060ADEAA shlr2 r3
    c.r[3] >>= 2;  // 060ADEAC shlr2 r3
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 060ADEAE shlr r3
    c.r[0] = 0x3u;  // 060ADEB0 mov #3,r0
    c.r[0] &= c.r[3];  // 060ADEB2 and r3,r0
    c.r[6] |= c.r[0];  // 060ADEB4 or r0,r6
    c.r[1] = 0x1Cu;  // 060ADEB6 mov #28,r1
L_060ADEB8:
    c.t = c.r[4] >> 31; c.r[4] <<= 1;  // 060ADEB8 shll r4
    c.r[4] >>= 16;  // 060ADEBA shlr16 r4
    c.r[1] &= c.r[4];  // 060ADEBC and r4,r1
    c.r[1] |= c.r[6];  // 060ADEBE or r6,r1
    c.r[5] >>= 8;  // 060ADEC0 shlr8 r5
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 206);  // 060ADEC2 mov.w @(206,gbr),r0
    c.r[0] >>= 8;  // 060ADEC4 shlr8 r0
    c.t = (c.r[0] & 0x20u) == 0;  // 060ADEC6 tst #32,r0
    { const bool k = c.t; c.t = c.r[5] & 1; c.r[5] >>= 1; if (k) { goto L_060ADECE; } }  // 060ADEC8 bt/s 0x060ADECE ; shlr r5
    c.t = c.r[5] & 1; c.r[5] >>= 1;  // 060ADECC shlr r5
L_060ADECE:
    c.r[0] = 0x7u;  // 060ADECE mov #7,r0
    c.r[5] &= c.r[0];  // 060ADED0 and r0,r5
    c.t = c.r[5] >> 31; c.r[5] <<= 1;  // 060ADED2 shll r5
    c.r[5] <<= 2;  // 060ADED4 shll2 r5
    c.r[5] <<= 2;  // 060ADED6 shll2 r5
    c.r[1] |= c.r[5];  // 060ADED8 or r5,r1
    c.r[0] = ld32(0x060ADF18u);  // 060ADEDA mov.l 0x060ADF18,r0
    { const uint32_t x = c.pr; st16(c.r[0] + c.r[2], c.r[1]); c.pc = x; return; }  // 060ADEDC rts ; mov.w r1,@(r0,r2)
}

void f_060ADF24(SH2Context& c) {
    ran[2947] = 1;
    c.r[0] = c.r[4];  // 060ADF24 mov r4,r0
    st32(c.gbr + 512, c.r[0]);  // 060ADF26 mov.l r0,@(512,gbr)
    c.r[3] = 0xBu;  // 060ADF28 mov #11,r3
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 242);  // 060ADF2A mov.w @(242,gbr),r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x060ADFD6u);  // 060ADF2C mov.w 0x060ADFD6,r1
    c.t = (c.r[0] & c.r[1]) == 0;  // 060ADF2E tst r1,r0
    if (!c.t) { goto L_060ADF34; }  // 060ADF30 bf 0x060ADF34
    c.r[3] += 1;  // 060ADF32 add #1,r3
L_060ADF34:
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 232);  // 060ADF34 mov.w @(232,gbr),r0
    c.r[0] >>= 8;  // 060ADF36 shlr8 r0
    c.t = (c.r[0] & 0x1u) == 0;  // 060ADF38 tst #1,r0
    if (!c.t) { goto L_060ADF3E; }  // 060ADF3A bf 0x060ADF3E
    c.r[3] += 2;  // 060ADF3C add #2,r3
L_060ADF3E:
    c.r[0] = c.r[3];  // 060ADF3E mov r3,r0
    c.r[0] += 6;  // 060ADF40 add #6,r0
    c.r[2] = c.r[4];  // 060ADF42 mov r4,r2
    c.t = (c.r[0] & 0x10u) == 0;  // 060ADF44 tst #16,r0
    if (c.t) { goto L_060ADF4A; }  // 060ADF46 bt 0x060ADF4A
    c.r[2] >>= 16;  // 060ADF48 shlr16 r2
L_060ADF4A:
    c.t = (c.r[0] & 0x8u) == 0;  // 060ADF4A tst #8,r0
    if (c.t) { goto L_060ADF50; }  // 060ADF4C bt 0x060ADF50
    c.r[2] >>= 8;  // 060ADF4E shlr8 r2
L_060ADF50:
    c.t = (c.r[0] & 0x4u) == 0;  // 060ADF50 tst #4,r0
    if (c.t) { goto L_060ADF58; }  // 060ADF52 bt 0x060ADF58
    c.r[2] >>= 2;  // 060ADF54 shlr2 r2
    c.r[2] >>= 2;  // 060ADF56 shlr2 r2
L_060ADF58:
    c.t = (c.r[0] & 0x2u) == 0;  // 060ADF58 tst #2,r0
    if (c.t) { goto L_060ADF5E; }  // 060ADF5A bt 0x060ADF5E
    c.r[2] >>= 2;  // 060ADF5C shlr2 r2
L_060ADF5E:
    c.t = (c.r[0] & 0x1u) == 0;  // 060ADF5E tst #1,r0
    if (c.t) { goto L_060ADF64; }  // 060ADF60 bt 0x060ADF64
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 060ADF62 shlr r2
L_060ADF64:
    c.r[1] = 0x7u;  // 060ADF64 mov #7,r1
    c.r[2] &= c.r[1];  // 060ADF66 and r1,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 253);  // 060ADF68 mov.b @(253,gbr),r0
    c.r[2] <<= 2;  // 060ADF6A shll2 r2
    c.r[0] &= 0xFu;  // 060ADF6C and #15,r0
    c.r[2] <<= 2;  // 060ADF6E shll2 r2
    c.r[0] |= c.r[2];  // 060ADF70 or r2,r0
    st8(c.gbr + 253, c.r[0]);  // 060ADF72 mov.b r0,@(253,gbr)
    c.r[0] = c.r[3];  // 060ADF74 mov r3,r0
    c.t = (c.r[0] & 0x10u) == 0;  // 060ADF76 tst #16,r0
    if (c.t) { goto L_060ADF82; }  // 060ADF78 bt 0x060ADF82
    c.r[4] >>= 16;  // 060ADF7A shlr16 r4
    c.r[5] >>= 16;  // 060ADF7C shlr16 r5
    c.r[6] >>= 16;  // 060ADF7E shlr16 r6
    c.r[7] >>= 16;  // 060ADF80 shlr16 r7
L_060ADF82:
    c.t = (c.r[0] & 0x8u) == 0;  // 060ADF82 tst #8,r0
    if (c.t) { goto L_060ADF8E; }  // 060ADF84 bt 0x060ADF8E
    c.r[4] >>= 8;  // 060ADF86 shlr8 r4
    c.r[5] >>= 8;  // 060ADF88 shlr8 r5
    c.r[6] >>= 8;  // 060ADF8A shlr8 r6
    c.r[7] >>= 8;  // 060ADF8C shlr8 r7
L_060ADF8E:
    c.t = (c.r[0] & 0x4u) == 0;  // 060ADF8E tst #4,r0
    if (c.t) { goto L_060ADFA2; }  // 060ADF90 bt 0x060ADFA2
    c.r[4] >>= 2;  // 060ADF92 shlr2 r4
    c.r[4] >>= 2;  // 060ADF94 shlr2 r4
    c.r[5] >>= 2;  // 060ADF96 shlr2 r5
    c.r[5] >>= 2;  // 060ADF98 shlr2 r5
    c.r[6] >>= 2;  // 060ADF9A shlr2 r6
    c.r[6] >>= 2;  // 060ADF9C shlr2 r6
    c.r[7] >>= 2;  // 060ADF9E shlr2 r7
    c.r[7] >>= 2;  // 060ADFA0 shlr2 r7
L_060ADFA2:
    c.t = (c.r[0] & 0x2u) == 0;  // 060ADFA2 tst #2,r0
    if (c.t) { goto L_060ADFAE; }  // 060ADFA4 bt 0x060ADFAE
    c.r[4] >>= 2;  // 060ADFA6 shlr2 r4
    c.r[5] >>= 2;  // 060ADFA8 shlr2 r5
    c.r[6] >>= 2;  // 060ADFAA shlr2 r6
    c.r[7] >>= 2;  // 060ADFAC shlr2 r7
L_060ADFAE:
    c.t = (c.r[0] & 0x1u) == 0;  // 060ADFAE tst #1,r0
    if (c.t) { goto L_060ADFBA; }  // 060ADFB0 bt 0x060ADFBA
    c.t = c.r[4] & 1; c.r[4] >>= 1;  // 060ADFB2 shlr r4
    c.t = c.r[5] & 1; c.r[5] >>= 1;  // 060ADFB4 shlr r5
    c.t = c.r[6] & 1; c.r[6] >>= 1;  // 060ADFB6 shlr r6
    c.t = c.r[7] & 1; c.r[7] >>= 1;  // 060ADFB8 shlr r7
L_060ADFBA:
    c.r[1] = 0x3Fu;  // 060ADFBA mov #63,r1
    c.r[4] &= c.r[1];  // 060ADFBC and r1,r4
    c.r[5] &= c.r[1];  // 060ADFBE and r1,r5
    c.r[6] &= c.r[1];  // 060ADFC0 and r1,r6
    c.r[7] &= c.r[1];  // 060ADFC2 and r1,r7
    c.r[5] <<= 8;  // 060ADFC4 shll8 r5
    c.r[4] |= c.r[5];  // 060ADFC6 or r5,r4
    c.r[0] = c.r[4];  // 060ADFC8 mov r4,r0
    st16(c.gbr + 260, c.r[0]);  // 060ADFCA mov.w r0,@(260,gbr)
    c.r[7] <<= 8;  // 060ADFCC shll8 r7
    c.r[6] |= c.r[7];  // 060ADFCE or r7,r6
    c.r[0] = c.r[6];  // 060ADFD0 mov r6,r0
    { const uint32_t x = c.pr; st16(c.gbr + 262, c.r[0]); c.pc = x; return; }  // 060ADFD2 rts ; mov.w r0,@(262,gbr)
}

void f_060ADFD8(SH2Context& c) {
    ran[2948] = 1;
    c.r[0] = c.r[4];  // 060ADFD8 mov r4,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060ADFDA shlr r0
    { const uint32_t x = c.pr; st32(c.gbr + 352, c.r[0]); c.pc = x; return; }  // 060ADFDC rts ; mov.l r0,@(352,gbr)
}

void f_060ADFF0(SH2Context& c) {
    ran[2949] = 1;
    c.r[0] = c.r[4];  // 060ADFF0 mov r4,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060ADFF2 shlr r0
    { const uint32_t x = c.pr; st32(c.gbr + 356, c.r[0]); c.pc = x; return; }  // 060ADFF4 rts ; mov.l r0,@(356,gbr)
}

void f_060ADFF8(SH2Context& c) {
    ran[2950] = 1;
    c.r[0] = ld32(0x060AE000u);  // 060ADFF8 mov.l 0x060AE000,r0
    { const uint32_t x = c.pr; st8(c.r[0] + c.r[4], c.r[5]); c.pc = x; return; }  // 060ADFFA rts ; mov.b r5,@(r0,r4)
}

void f_060AE004(SH2Context& c) {
    ran[2951] = 1;
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 192);  // 060AE004 mov.w @(192,gbr),r0
    c.t = (c.r[0] & 0x2u) == 0;  // 060AE006 tst #2,r0
    if (!c.t) { goto L_060AE00E; }  // 060AE008 bf 0x060AE00E
    c.t = c.r[4] >> 31; c.r[4] <<= 1;  // 060AE00A shll r4
    c.t = c.r[6] >> 31; c.r[6] <<= 1;  // 060AE00C shll r6
L_060AE00E:
    c.r[0] = c.r[5] << 16 | c.r[5] >> 16;  // 060AE00E swap.w r5,r0
    c.r[0] = c.r[4] << 16 | c.r[0] >> 16;  // 060AE010 xtrct r4,r0
    st32(c.gbr + 384, c.r[0]);  // 060AE012 mov.l r0,@(384,gbr)
    c.r[0] = c.r[7] << 16 | c.r[7] >> 16;  // 060AE014 swap.w r7,r0
    c.r[0] = c.r[6] << 16 | c.r[0] >> 16;  // 060AE016 xtrct r6,r0
    st32(c.gbr + 388, c.r[0]);  // 060AE018 mov.l r0,@(388,gbr)
    c.r[0] = 0x0u;  // 060AE01A mov #0,r0
    { const uint32_t x = c.pr; st32(c.gbr + 408, c.r[0]); c.pc = x; return; }  // 060AE01C rts ; mov.l r0,@(408,gbr)
}

void f_060AE020(SH2Context& c) {
    ran[2952] = 1;
    c.r[0] = c.r[4];  // 060AE020 mov r4,r0
    { const uint32_t x = c.pr; st16(c.gbr + 464, c.r[0]); c.pc = x; return; }  // 060AE022 rts ; mov.w r0,@(464,gbr)
}

void f_060AE028(SH2Context& c) {
    ran[2953] = 1;
    c.r[0] = ld32(0x060AE030u);  // 060AE028 mov.l 0x060AE030,r0
    { const uint32_t x = c.pr; st8(c.r[0] + c.r[4], c.r[5]); c.pc = x; return; }  // 060AE02A rts ; mov.b r5,@(r0,r4)
}

void f_060AE034(SH2Context& c) {
    ran[2954] = 1;
    c.r[0] = c.r[4];  // 060AE034 mov r4,r0
    st32(c.gbr + 304, c.r[0]);  // 060AE036 mov.l r0,@(304,gbr)
    c.r[0] = c.r[5];  // 060AE038 mov r5,r0
    { const uint32_t x = c.pr; st32(c.gbr + 308, c.r[0]); c.pc = x; return; }  // 060AE03A rts ; mov.l r0,@(308,gbr)
}

void f_060AE068(SH2Context& c) {
    ran[2955] = 1;
    c.r[0] = c.r[4];  // 060AE068 mov r4,r0
    st32(c.gbr + 320, c.r[0]);  // 060AE06A mov.l r0,@(320,gbr)
    c.r[0] = c.r[5];  // 060AE06C mov r5,r0
    { const uint32_t x = c.pr; st32(c.gbr + 324, c.r[0]); c.pc = x; return; }  // 060AE06E rts ; mov.l r0,@(324,gbr)
}

void f_060AE074(SH2Context& c) {
    ran[2956] = 1;
    c.r[0] = c.r[4];  // 060AE074 mov r4,r0
    st32(c.gbr + 748, c.r[0]);  // 060AE076 mov.l r0,@(748,gbr)
    c.r[0] = c.r[5];  // 060AE078 mov r5,r0
    st32(c.gbr + 752, c.r[0]);  // 060AE07A mov.l r0,@(752,gbr)
    c.r[4] >>= 16;  // 060AE07C shlr16 r4
    c.r[0] = c.r[4] << 16 | c.r[0] >> 16;  // 060AE07E xtrct r4,r0
    { const uint32_t x = c.pr; st32(c.gbr + 336, c.r[0]); c.pc = x; return; }  // 060AE080 rts ; mov.l r0,@(336,gbr)
}

void f_060AE084(SH2Context& c) {
    ran[2957] = 1;
    c.r[0] = 0x0u;  // 060AE084 mov #0,r0
    st8(c.gbr + 32, c.r[0]);  // 060AE086 mov.b r0,@(32,gbr)
    c.r[0] = 0x060AE0F0u;  // 060AE088 mova 0x060AE0F0,r0
    st32(c.gbr + 28, c.r[0]); goto L_060AE0AA;  // 060AE08A bra 0x060AE0AA ; mov.l r0,@(28,gbr)
L_060AE0AA:
    c.r[1] = 0x1u;  // 060AE0AA mov #1,r1
    c.r[1] <<= 16;  // 060AE0AC shll16 r1
    c.r[2] = 0x0u;  // 060AE0AE mov #0,r2
    st32(c.r[0], c.r[1]);  // 060AE0B0 mov.l r1,@(0,r0)
    st32(c.r[0] + 16, c.r[2]);  // 060AE0B2 mov.l r2,@(16,r0)
    st32(c.r[0] + 32, c.r[2]);  // 060AE0B4 mov.l r2,@(32,r0)
    st32(c.r[0] + 4, c.r[2]);  // 060AE0B6 mov.l r2,@(4,r0)
    st32(c.r[0] + 20, c.r[1]);  // 060AE0B8 mov.l r1,@(20,r0)
    st32(c.r[0] + 36, c.r[2]);  // 060AE0BA mov.l r2,@(36,r0)
    st32(c.r[0] + 8, c.r[2]);  // 060AE0BC mov.l r2,@(8,r0)
    st32(c.r[0] + 24, c.r[2]);  // 060AE0BE mov.l r2,@(24,r0)
    st32(c.r[0] + 40, c.r[1]);  // 060AE0C0 mov.l r1,@(40,r0)
    st32(c.r[0] + 12, c.r[2]);  // 060AE0C2 mov.l r2,@(12,r0)
    st32(c.r[0] + 28, c.r[2]);  // 060AE0C4 mov.l r2,@(28,r0)
    st32(c.r[0] + 44, c.r[2]);  // 060AE0C6 mov.l r2,@(44,r0)
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 060AE0C8 rts ; mov #1,r0
}

void f_060AE0A2(SH2Context& c) {
    ran[2958] = 1;
    c.t = (c.r[4] & c.r[4]) == 0;  // 060AE0A2 tst r4,r4
    { const bool k = !c.t; c.r[0] = c.r[4]; if (k) { goto L_060AE0CC; } }  // 060AE0A4 bf/s 0x060AE0CC ; mov r4,r0
    c.r[0] = ld32(c.gbr + 28);  // 060AE0A8 mov.l @(28,gbr),r0
    c.r[1] = 0x1u;  // 060AE0AA mov #1,r1
    c.r[1] <<= 16;  // 060AE0AC shll16 r1
    c.r[2] = 0x0u;  // 060AE0AE mov #0,r2
    st32(c.r[0], c.r[1]);  // 060AE0B0 mov.l r1,@(0,r0)
    st32(c.r[0] + 16, c.r[2]);  // 060AE0B2 mov.l r2,@(16,r0)
    st32(c.r[0] + 32, c.r[2]);  // 060AE0B4 mov.l r2,@(32,r0)
    st32(c.r[0] + 4, c.r[2]);  // 060AE0B6 mov.l r2,@(4,r0)
    st32(c.r[0] + 20, c.r[1]);  // 060AE0B8 mov.l r1,@(20,r0)
    st32(c.r[0] + 36, c.r[2]);  // 060AE0BA mov.l r2,@(36,r0)
    st32(c.r[0] + 8, c.r[2]);  // 060AE0BC mov.l r2,@(8,r0)
    st32(c.r[0] + 24, c.r[2]);  // 060AE0BE mov.l r2,@(24,r0)
    st32(c.r[0] + 40, c.r[1]);  // 060AE0C0 mov.l r1,@(40,r0)
    st32(c.r[0] + 12, c.r[2]);  // 060AE0C2 mov.l r2,@(12,r0)
    st32(c.r[0] + 28, c.r[2]);  // 060AE0C4 mov.l r2,@(28,r0)
    st32(c.r[0] + 44, c.r[2]);  // 060AE0C6 mov.l r2,@(44,r0)
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 060AE0C8 rts ; mov #1,r0
L_060AE0CC:
    c.r[1] = 0x1u;  // 060AE0CC mov #1,r1
    c.r[1] <<= 16;  // 060AE0CE shll16 r1
    c.r[2] = 0x0u;  // 060AE0D0 mov #0,r2
    st32(c.r[0], c.r[1]);  // 060AE0D2 mov.l r1,@(0,r0)
    st32(c.r[0] + 4, c.r[2]);  // 060AE0D4 mov.l r2,@(4,r0)
    st32(c.r[0] + 8, c.r[2]);  // 060AE0D6 mov.l r2,@(8,r0)
    st32(c.r[0] + 12, c.r[2]);  // 060AE0D8 mov.l r2,@(12,r0)
    st32(c.r[0] + 16, c.r[1]);  // 060AE0DA mov.l r1,@(16,r0)
    st32(c.r[0] + 20, c.r[2]);  // 060AE0DC mov.l r2,@(20,r0)
    st32(c.r[0] + 24, c.r[2]);  // 060AE0DE mov.l r2,@(24,r0)
    st32(c.r[0] + 28, c.r[2]);  // 060AE0E0 mov.l r2,@(28,r0)
    st32(c.r[0] + 32, c.r[1]);  // 060AE0E2 mov.l r1,@(32,r0)
    st32(c.r[0] + 36, c.r[2]);  // 060AE0E4 mov.l r2,@(36,r0)
    st32(c.r[0] + 40, c.r[2]);  // 060AE0E6 mov.l r2,@(40,r0)
    { const uint32_t x = c.pr; st32(c.r[0] + 44, c.r[2]); c.pc = x; return; }  // 060AE0E8 rts ; mov.l r2,@(44,r0)
}

void f_060AE120(SH2Context& c) {
    ran[2959] = 1;
L_060AE120:
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 060AE120 mov.l r0,@-r15
L_060AE122:
    c.r[3] = ld32(0x060AE190u);  // 060AE122 mov.l 0x060AE190,r3
L_060AE124:
    c.t = c.r[2] == c.r[3];  // 060AE124 cmp/eq r3,r2
L_060AE126:
    if (c.t) { goto L_060AE172; }  // 060AE126 bt 0x060AE172
L_060AE128:
    c.r[1] = c.pr;  // 060AE128 sts pr,r1
L_060AE12A:
    c.r[0] = ld32(0x060AE184u);  // 060AE12A mov.l 0x060AE184,r0
L_060AE12C:
    c.t = c.r[1] == c.r[0];  // 060AE12C cmp/eq r0,r1
L_060AE12E:
    if (!c.t) { goto L_060AE168; }  // 060AE12E bf 0x060AE168
L_060AE130:
    c.t = (c.r[4] & c.r[4]) == 0;  // 060AE130 tst r4,r4
L_060AE132:
    if (!c.t) { goto L_060AE168; }  // 060AE132 bf 0x060AE168
L_060AE134:
    c.r[3] = ld32(0x060AE188u);  // 060AE134 mov.l 0x060AE188,r3
L_060AE136:
    c.t = c.r[2] >= c.r[3];  // 060AE136 cmp/hs r3,r2
L_060AE138:
    if (!c.t) { goto L_060AE140; }  // 060AE138 bf 0x060AE140
L_060AE13A:
    c.r[3] += 22;  // 060AE13A add #22,r3
L_060AE13C:
    c.t = c.r[3] > c.r[2];  // 060AE13C cmp/hi r2,r3
L_060AE13E:
    if (c.t) { goto L_060AE168; }  // 060AE13E bt 0x060AE168
L_060AE140:
    c.r[3] = ld32(0x060AE18Cu);  // 060AE140 mov.l 0x060AE18C,r3
L_060AE142:
    c.t = c.r[2] >= c.r[3];  // 060AE142 cmp/hs r3,r2
L_060AE144:
    if (!c.t) { goto L_060AE14C; }  // 060AE144 bf 0x060AE14C
L_060AE146:
    c.r[3] += 3;  // 060AE146 add #3,r3
L_060AE148:
    c.t = c.r[3] > c.r[2];  // 060AE148 cmp/hi r2,r3
L_060AE14A:
    if (c.t) { goto L_060AE168; }  // 060AE14A bt 0x060AE168
L_060AE14C:
    c.r[0] = ld32(c.r[15]); c.r[15] += 4;  // 060AE14C mov.l @r15+,r0
L_060AE14E:
    c.r[2] = ld32(0x060AE184u);  // 060AE14E mov.l 0x060AE184,r2
L_060AE150:
    c.r[3] = ld32(0x060AE194u);  // 060AE150 mov.l 0x060AE194,r3
L_060AE152:
    { const uint32_t x = c.r[3]; c.pr = 0x060AE156u; c.r[15] -= 4; st32(c.r[15], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AE156u) return; }  // 060AE152 jsr @r3 ; mov.l r1,@-r15
L_060AE156:
    c.r[1] = ld32(0x060AE198u);  // 060AE156 mov.l 0x060AE198,r1
L_060AE158:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060AE158 mov.b @r1,r0
L_060AE15A:
    c.r[0] = c.r[0] & 0xFFu;  // 060AE15A extu.b r0,r0
L_060AE15C:
    c.r[0] += 1;  // 060AE15C add #1,r0
L_060AE15E:
    st8(c.r[1], c.r[0]);  // 060AE15E mov.b r0,@r1
L_060AE160:
    c.r[1] = ld32(c.r[15]); c.r[15] += 4;  // 060AE160 mov.l @r15+,r1
L_060AE162:
    c.pr = c.r[1];  // 060AE162 lds r1,pr
L_060AE164:
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060AE164 rts ; nop
L_060AE168:
    c.r[0] = ld32(c.r[15]); c.r[15] += 4;  // 060AE168 mov.l @r15+,r0
L_060AE16A:
    c.r[2] = ld32(0x060AE184u);  // 060AE16A mov.l 0x060AE184,r2
L_060AE16C:
    c.r[3] = ld32(0x060AE194u);  // 060AE16C mov.l 0x060AE194,r3
L_060AE16E:
    { const uint32_t x = c.r[3]; SH2_POLL(c); switch (x) { case 0x060AE120u: goto L_060AE120; case 0x060AE122u: goto L_060AE122; case 0x060AE124u: goto L_060AE124; case 0x060AE126u: goto L_060AE126; case 0x060AE128u: goto L_060AE128; case 0x060AE12Au: goto L_060AE12A; case 0x060AE12Cu: goto L_060AE12C; case 0x060AE12Eu: goto L_060AE12E; case 0x060AE130u: goto L_060AE130; case 0x060AE132u: goto L_060AE132; case 0x060AE134u: goto L_060AE134; case 0x060AE136u: goto L_060AE136; case 0x060AE138u: goto L_060AE138; case 0x060AE13Au: goto L_060AE13A; case 0x060AE13Cu: goto L_060AE13C; case 0x060AE13Eu: goto L_060AE13E; case 0x060AE140u: goto L_060AE140; case 0x060AE142u: goto L_060AE142; case 0x060AE144u: goto L_060AE144; case 0x060AE146u: goto L_060AE146; case 0x060AE148u: goto L_060AE148; case 0x060AE14Au: goto L_060AE14A; case 0x060AE14Cu: goto L_060AE14C; case 0x060AE14Eu: goto L_060AE14E; case 0x060AE150u: goto L_060AE150; case 0x060AE152u: goto L_060AE152; case 0x060AE156u: goto L_060AE156; case 0x060AE158u: goto L_060AE158; case 0x060AE15Au: goto L_060AE15A; case 0x060AE15Cu: goto L_060AE15C; case 0x060AE15Eu: goto L_060AE15E; case 0x060AE160u: goto L_060AE160; case 0x060AE162u: goto L_060AE162; case 0x060AE164u: goto L_060AE164; case 0x060AE168u: goto L_060AE168; case 0x060AE16Au: goto L_060AE16A; case 0x060AE16Cu: goto L_060AE16C; case 0x060AE16Eu: goto L_060AE16E; case 0x060AE172u: goto L_060AE172; case 0x060AE174u: goto L_060AE174; case 0x060AE176u: goto L_060AE176; case 0x060AE178u: goto L_060AE178; case 0x060AE17Au: goto L_060AE17A; case 0x060AE17Cu: goto L_060AE17C; case 0x060AE17Eu: goto L_060AE17E; case 0x060AE1A0u: goto L_060AE1A0; case 0x060AE1A2u: goto L_060AE1A2; case 0x060AE1A4u: goto L_060AE1A4; case 0x060AE1A6u: goto L_060AE1A6; case 0x060AE1A8u: goto L_060AE1A8; case 0x060AE1AAu: goto L_060AE1AA; case 0x060AE1ACu: goto L_060AE1AC; case 0x060AE1AEu: goto L_060AE1AE; case 0x060AE1B0u: goto L_060AE1B0; case 0x060AE1B2u: goto L_060AE1B2; case 0x060AE1B4u: goto L_060AE1B4; case 0x060AE1B6u: goto L_060AE1B6; case 0x060AE1B8u: goto L_060AE1B8; case 0x060AE1BAu: goto L_060AE1BA; case 0x060AE1BCu: goto L_060AE1BC; case 0x060AE1BEu: goto L_060AE1BE; case 0x060AE1C0u: goto L_060AE1C0; case 0x060AE1C2u: goto L_060AE1C2; case 0x060AE1C4u: goto L_060AE1C4; case 0x060AE1C6u: goto L_060AE1C6; case 0x060AE1C8u: goto L_060AE1C8; case 0x060AE1CAu: goto L_060AE1CA; case 0x060AE1CCu: goto L_060AE1CC; case 0x060AE1CEu: goto L_060AE1CE; case 0x060AE1D0u: goto L_060AE1D0; case 0x060AE1D2u: goto L_060AE1D2; case 0x060AE1D4u: goto L_060AE1D4; case 0x060AE1D6u: goto L_060AE1D6; case 0x060AE1D8u: goto L_060AE1D8; case 0x060AE1DAu: goto L_060AE1DA; case 0x060AE1DCu: goto L_060AE1DC; case 0x060AE1DEu: goto L_060AE1DE; case 0x060AE1E2u: goto L_060AE1E2; case 0x060AE1F0u: goto L_060AE1F0; case 0x060AE1F2u: goto L_060AE1F2; case 0x060AE1F4u: goto L_060AE1F4; case 0x060AE1F6u: goto L_060AE1F6; case 0x060AE1F8u: goto L_060AE1F8; case 0x060AE1FAu: goto L_060AE1FA; case 0x060AE1FCu: goto L_060AE1FC; case 0x060AE1FEu: goto L_060AE1FE; case 0x060AE200u: goto L_060AE200; case 0x060AE202u: goto L_060AE202; case 0x060AE204u: goto L_060AE204; case 0x060AE206u: goto L_060AE206; case 0x060AE208u: goto L_060AE208; case 0x060AE20Au: goto L_060AE20A; case 0x060AE20Cu: goto L_060AE20C; case 0x060AE20Eu: goto L_060AE20E; case 0x060AE210u: goto L_060AE210; case 0x060AE212u: goto L_060AE212; case 0x060AE214u: goto L_060AE214; case 0x060AE216u: goto L_060AE216; case 0x060AE218u: goto L_060AE218; case 0x060AE21Au: goto L_060AE21A; case 0x060AE21Cu: goto L_060AE21C; case 0x060AE21Eu: goto L_060AE21E; case 0x060AE220u: goto L_060AE220; case 0x060AE222u: goto L_060AE222; case 0x060AE224u: goto L_060AE224; case 0x060AE226u: goto L_060AE226; case 0x060AE228u: goto L_060AE228; case 0x060AE22Au: goto L_060AE22A; case 0x060AE22Cu: goto L_060AE22C; case 0x060AE22Eu: goto L_060AE22E; case 0x060AE230u: goto L_060AE230; case 0x060AE232u: goto L_060AE232; case 0x060AE234u: goto L_060AE234; case 0x060AE236u: goto L_060AE236; case 0x060AE238u: goto L_060AE238; case 0x060AE23Au: goto L_060AE23A; case 0x060AE23Cu: goto L_060AE23C; case 0x060AE23Eu: goto L_060AE23E; case 0x060AE240u: goto L_060AE240; case 0x060AE242u: goto L_060AE242; case 0x060AE244u: goto L_060AE244; case 0x060AE246u: goto L_060AE246; case 0x060AE248u: goto L_060AE248; case 0x060AE24Au: goto L_060AE24A; case 0x060AE24Cu: goto L_060AE24C; case 0x060AE24Eu: goto L_060AE24E; case 0x060AE250u: goto L_060AE250; case 0x060AE252u: goto L_060AE252; case 0x060AE254u: goto L_060AE254; case 0x060AE256u: goto L_060AE256; case 0x060AE258u: goto L_060AE258; case 0x060AE25Au: goto L_060AE25A; case 0x060AE25Cu: goto L_060AE25C; case 0x060AE25Eu: goto L_060AE25E; case 0x060AE260u: goto L_060AE260; case 0x060AE262u: goto L_060AE262; case 0x060AE266u: goto L_060AE266; case 0x060AE268u: goto L_060AE268; case 0x060AE26Au: goto L_060AE26A; case 0x060AE26Cu: goto L_060AE26C; case 0x060AE26Eu: goto L_060AE26E; case 0x060AE270u: goto L_060AE270; case 0x060AE272u: goto L_060AE272; case 0x060AE274u: goto L_060AE274; case 0x060AE278u: goto L_060AE278; case 0x060AE27Au: goto L_060AE27A; case 0x060AE27Cu: goto L_060AE27C; case 0x060AE27Eu: goto L_060AE27E; case 0x060AE280u: goto L_060AE280; case 0x060AE282u: goto L_060AE282; case 0x060AE284u: goto L_060AE284; case 0x060AE286u: goto L_060AE286; case 0x060AE288u: goto L_060AE288; case 0x060AE28Cu: goto L_060AE28C; case 0x060AE28Eu: goto L_060AE28E; case 0x060AE290u: goto L_060AE290; case 0x060AE292u: goto L_060AE292; case 0x060AE294u: goto L_060AE294; case 0x060AE298u: goto L_060AE298; case 0x060AE29Au: goto L_060AE29A; case 0x060AE29Cu: goto L_060AE29C; case 0x060AE29Eu: goto L_060AE29E; case 0x060AE2A0u: goto L_060AE2A0; case 0x060AE2A2u: goto L_060AE2A2; case 0x060AE2A4u: goto L_060AE2A4; case 0x060AE2A6u: goto L_060AE2A6; case 0x060AE2A8u: goto L_060AE2A8; case 0x060AE2AAu: goto L_060AE2AA; case 0x060AE2ACu: goto L_060AE2AC; case 0x060AE2AEu: goto L_060AE2AE; case 0x060AE2B0u: goto L_060AE2B0; case 0x060AE2B2u: goto L_060AE2B2; case 0x060AE302u: goto L_060AE302; case 0x060AE304u: goto L_060AE304; case 0x060AE306u: goto L_060AE306; case 0x060AE308u: goto L_060AE308; case 0x060AE30Au: goto L_060AE30A; case 0x060AE30Cu: goto L_060AE30C; case 0x060AE30Eu: goto L_060AE30E; case 0x060AE310u: goto L_060AE310; case 0x060AE312u: goto L_060AE312; case 0x060AE314u: goto L_060AE314; case 0x060AE318u: goto L_060AE318; case 0x060AE31Au: goto L_060AE31A; case 0x060AE31Eu: goto L_060AE31E; case 0x060AE320u: goto L_060AE320; case 0x060AE322u: goto L_060AE322; case 0x060AE324u: goto L_060AE324; case 0x060AE326u: goto L_060AE326; case 0x060AE328u: goto L_060AE328; case 0x060AE32Au: goto L_060AE32A; case 0x060AE32Cu: goto L_060AE32C; case 0x060AE32Eu: goto L_060AE32E; case 0x060AE330u: goto L_060AE330; case 0x060AE332u: goto L_060AE332; case 0x060AE334u: goto L_060AE334; case 0x060AE336u: goto L_060AE336; case 0x060AE33Au: goto L_060AE33A; case 0x060AE33Cu: goto L_060AE33C; case 0x060AE33Eu: goto L_060AE33E; case 0x060AE340u: goto L_060AE340; case 0x060AE342u: goto L_060AE342; case 0x060AE344u: goto L_060AE344; case 0x060AE346u: goto L_060AE346; case 0x060AE348u: goto L_060AE348; case 0x060AE34Au: goto L_060AE34A; case 0x060AE34Cu: goto L_060AE34C; case 0x060AE368u: goto L_060AE368; case 0x060AE36Au: goto L_060AE36A; default: sh2_call(c, x); return; } }  // 060AE16E jmp @r3 ; nop
L_060AE172:
    c.r[1] = ld32(0x060AE19Cu);  // 060AE172 mov.l 0x060AE19C,r1
L_060AE174:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060AE174 mov.b @r1,r0
L_060AE176:
    c.r[0] &= 0xFBu;  // 060AE176 and #251,r0
L_060AE178:
    st8(c.r[1], c.r[0]);  // 060AE178 mov.b r0,@r1
L_060AE17A:
    c.r[0] = ld32(c.r[15]); c.r[15] += 4;  // 060AE17A mov.l @r15+,r0
L_060AE17C:
    c.r[3] = ld32(0x060AE194u);  // 060AE17C mov.l 0x060AE194,r3
L_060AE17E:
    { const uint32_t x = c.r[3]; SH2_POLL(c); switch (x) { case 0x060AE120u: goto L_060AE120; case 0x060AE122u: goto L_060AE122; case 0x060AE124u: goto L_060AE124; case 0x060AE126u: goto L_060AE126; case 0x060AE128u: goto L_060AE128; case 0x060AE12Au: goto L_060AE12A; case 0x060AE12Cu: goto L_060AE12C; case 0x060AE12Eu: goto L_060AE12E; case 0x060AE130u: goto L_060AE130; case 0x060AE132u: goto L_060AE132; case 0x060AE134u: goto L_060AE134; case 0x060AE136u: goto L_060AE136; case 0x060AE138u: goto L_060AE138; case 0x060AE13Au: goto L_060AE13A; case 0x060AE13Cu: goto L_060AE13C; case 0x060AE13Eu: goto L_060AE13E; case 0x060AE140u: goto L_060AE140; case 0x060AE142u: goto L_060AE142; case 0x060AE144u: goto L_060AE144; case 0x060AE146u: goto L_060AE146; case 0x060AE148u: goto L_060AE148; case 0x060AE14Au: goto L_060AE14A; case 0x060AE14Cu: goto L_060AE14C; case 0x060AE14Eu: goto L_060AE14E; case 0x060AE150u: goto L_060AE150; case 0x060AE152u: goto L_060AE152; case 0x060AE156u: goto L_060AE156; case 0x060AE158u: goto L_060AE158; case 0x060AE15Au: goto L_060AE15A; case 0x060AE15Cu: goto L_060AE15C; case 0x060AE15Eu: goto L_060AE15E; case 0x060AE160u: goto L_060AE160; case 0x060AE162u: goto L_060AE162; case 0x060AE164u: goto L_060AE164; case 0x060AE168u: goto L_060AE168; case 0x060AE16Au: goto L_060AE16A; case 0x060AE16Cu: goto L_060AE16C; case 0x060AE16Eu: goto L_060AE16E; case 0x060AE172u: goto L_060AE172; case 0x060AE174u: goto L_060AE174; case 0x060AE176u: goto L_060AE176; case 0x060AE178u: goto L_060AE178; case 0x060AE17Au: goto L_060AE17A; case 0x060AE17Cu: goto L_060AE17C; case 0x060AE17Eu: goto L_060AE17E; case 0x060AE1A0u: goto L_060AE1A0; case 0x060AE1A2u: goto L_060AE1A2; case 0x060AE1A4u: goto L_060AE1A4; case 0x060AE1A6u: goto L_060AE1A6; case 0x060AE1A8u: goto L_060AE1A8; case 0x060AE1AAu: goto L_060AE1AA; case 0x060AE1ACu: goto L_060AE1AC; case 0x060AE1AEu: goto L_060AE1AE; case 0x060AE1B0u: goto L_060AE1B0; case 0x060AE1B2u: goto L_060AE1B2; case 0x060AE1B4u: goto L_060AE1B4; case 0x060AE1B6u: goto L_060AE1B6; case 0x060AE1B8u: goto L_060AE1B8; case 0x060AE1BAu: goto L_060AE1BA; case 0x060AE1BCu: goto L_060AE1BC; case 0x060AE1BEu: goto L_060AE1BE; case 0x060AE1C0u: goto L_060AE1C0; case 0x060AE1C2u: goto L_060AE1C2; case 0x060AE1C4u: goto L_060AE1C4; case 0x060AE1C6u: goto L_060AE1C6; case 0x060AE1C8u: goto L_060AE1C8; case 0x060AE1CAu: goto L_060AE1CA; case 0x060AE1CCu: goto L_060AE1CC; case 0x060AE1CEu: goto L_060AE1CE; case 0x060AE1D0u: goto L_060AE1D0; case 0x060AE1D2u: goto L_060AE1D2; case 0x060AE1D4u: goto L_060AE1D4; case 0x060AE1D6u: goto L_060AE1D6; case 0x060AE1D8u: goto L_060AE1D8; case 0x060AE1DAu: goto L_060AE1DA; case 0x060AE1DCu: goto L_060AE1DC; case 0x060AE1DEu: goto L_060AE1DE; case 0x060AE1E2u: goto L_060AE1E2; case 0x060AE1F0u: goto L_060AE1F0; case 0x060AE1F2u: goto L_060AE1F2; case 0x060AE1F4u: goto L_060AE1F4; case 0x060AE1F6u: goto L_060AE1F6; case 0x060AE1F8u: goto L_060AE1F8; case 0x060AE1FAu: goto L_060AE1FA; case 0x060AE1FCu: goto L_060AE1FC; case 0x060AE1FEu: goto L_060AE1FE; case 0x060AE200u: goto L_060AE200; case 0x060AE202u: goto L_060AE202; case 0x060AE204u: goto L_060AE204; case 0x060AE206u: goto L_060AE206; case 0x060AE208u: goto L_060AE208; case 0x060AE20Au: goto L_060AE20A; case 0x060AE20Cu: goto L_060AE20C; case 0x060AE20Eu: goto L_060AE20E; case 0x060AE210u: goto L_060AE210; case 0x060AE212u: goto L_060AE212; case 0x060AE214u: goto L_060AE214; case 0x060AE216u: goto L_060AE216; case 0x060AE218u: goto L_060AE218; case 0x060AE21Au: goto L_060AE21A; case 0x060AE21Cu: goto L_060AE21C; case 0x060AE21Eu: goto L_060AE21E; case 0x060AE220u: goto L_060AE220; case 0x060AE222u: goto L_060AE222; case 0x060AE224u: goto L_060AE224; case 0x060AE226u: goto L_060AE226; case 0x060AE228u: goto L_060AE228; case 0x060AE22Au: goto L_060AE22A; case 0x060AE22Cu: goto L_060AE22C; case 0x060AE22Eu: goto L_060AE22E; case 0x060AE230u: goto L_060AE230; case 0x060AE232u: goto L_060AE232; case 0x060AE234u: goto L_060AE234; case 0x060AE236u: goto L_060AE236; case 0x060AE238u: goto L_060AE238; case 0x060AE23Au: goto L_060AE23A; case 0x060AE23Cu: goto L_060AE23C; case 0x060AE23Eu: goto L_060AE23E; case 0x060AE240u: goto L_060AE240; case 0x060AE242u: goto L_060AE242; case 0x060AE244u: goto L_060AE244; case 0x060AE246u: goto L_060AE246; case 0x060AE248u: goto L_060AE248; case 0x060AE24Au: goto L_060AE24A; case 0x060AE24Cu: goto L_060AE24C; case 0x060AE24Eu: goto L_060AE24E; case 0x060AE250u: goto L_060AE250; case 0x060AE252u: goto L_060AE252; case 0x060AE254u: goto L_060AE254; case 0x060AE256u: goto L_060AE256; case 0x060AE258u: goto L_060AE258; case 0x060AE25Au: goto L_060AE25A; case 0x060AE25Cu: goto L_060AE25C; case 0x060AE25Eu: goto L_060AE25E; case 0x060AE260u: goto L_060AE260; case 0x060AE262u: goto L_060AE262; case 0x060AE266u: goto L_060AE266; case 0x060AE268u: goto L_060AE268; case 0x060AE26Au: goto L_060AE26A; case 0x060AE26Cu: goto L_060AE26C; case 0x060AE26Eu: goto L_060AE26E; case 0x060AE270u: goto L_060AE270; case 0x060AE272u: goto L_060AE272; case 0x060AE274u: goto L_060AE274; case 0x060AE278u: goto L_060AE278; case 0x060AE27Au: goto L_060AE27A; case 0x060AE27Cu: goto L_060AE27C; case 0x060AE27Eu: goto L_060AE27E; case 0x060AE280u: goto L_060AE280; case 0x060AE282u: goto L_060AE282; case 0x060AE284u: goto L_060AE284; case 0x060AE286u: goto L_060AE286; case 0x060AE288u: goto L_060AE288; case 0x060AE28Cu: goto L_060AE28C; case 0x060AE28Eu: goto L_060AE28E; case 0x060AE290u: goto L_060AE290; case 0x060AE292u: goto L_060AE292; case 0x060AE294u: goto L_060AE294; case 0x060AE298u: goto L_060AE298; case 0x060AE29Au: goto L_060AE29A; case 0x060AE29Cu: goto L_060AE29C; case 0x060AE29Eu: goto L_060AE29E; case 0x060AE2A0u: goto L_060AE2A0; case 0x060AE2A2u: goto L_060AE2A2; case 0x060AE2A4u: goto L_060AE2A4; case 0x060AE2A6u: goto L_060AE2A6; case 0x060AE2A8u: goto L_060AE2A8; case 0x060AE2AAu: goto L_060AE2AA; case 0x060AE2ACu: goto L_060AE2AC; case 0x060AE2AEu: goto L_060AE2AE; case 0x060AE2B0u: goto L_060AE2B0; case 0x060AE2B2u: goto L_060AE2B2; case 0x060AE302u: goto L_060AE302; case 0x060AE304u: goto L_060AE304; case 0x060AE306u: goto L_060AE306; case 0x060AE308u: goto L_060AE308; case 0x060AE30Au: goto L_060AE30A; case 0x060AE30Cu: goto L_060AE30C; case 0x060AE30Eu: goto L_060AE30E; case 0x060AE310u: goto L_060AE310; case 0x060AE312u: goto L_060AE312; case 0x060AE314u: goto L_060AE314; case 0x060AE318u: goto L_060AE318; case 0x060AE31Au: goto L_060AE31A; case 0x060AE31Eu: goto L_060AE31E; case 0x060AE320u: goto L_060AE320; case 0x060AE322u: goto L_060AE322; case 0x060AE324u: goto L_060AE324; case 0x060AE326u: goto L_060AE326; case 0x060AE328u: goto L_060AE328; case 0x060AE32Au: goto L_060AE32A; case 0x060AE32Cu: goto L_060AE32C; case 0x060AE32Eu: goto L_060AE32E; case 0x060AE330u: goto L_060AE330; case 0x060AE332u: goto L_060AE332; case 0x060AE334u: goto L_060AE334; case 0x060AE336u: goto L_060AE336; case 0x060AE33Au: goto L_060AE33A; case 0x060AE33Cu: goto L_060AE33C; case 0x060AE33Eu: goto L_060AE33E; case 0x060AE340u: goto L_060AE340; case 0x060AE342u: goto L_060AE342; case 0x060AE344u: goto L_060AE344; case 0x060AE346u: goto L_060AE346; case 0x060AE348u: goto L_060AE348; case 0x060AE34Au: goto L_060AE34A; case 0x060AE34Cu: goto L_060AE34C; case 0x060AE368u: goto L_060AE368; case 0x060AE36Au: goto L_060AE36A; default: sh2_call(c, x); return; } }  // 060AE17E jmp @r3 ; nop
L_060AE1A0:
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060AE1A0 mov.l r8,@-r15
L_060AE1A2:
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060AE1A2 mov.l r9,@-r15
L_060AE1A4:
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060AE1A4 mov.l r10,@-r15
L_060AE1A6:
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060AE1A6 mov.l r11,@-r15
L_060AE1A8:
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060AE1A8 mov.l r12,@-r15
L_060AE1AA:
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060AE1AA mov.l r13,@-r15
L_060AE1AC:
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060AE1AC mov.l r14,@-r15
L_060AE1AE:
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060AE1AE sts.l pr,@-r15
L_060AE1B0:
    c.r[2] = ld32(0x060AE1ECu);  // 060AE1B0 mov.l 0x060AE1EC,r2
L_060AE1B2:
    c.r[1] = c.r[2];  // 060AE1B2 mov r2,r1
L_060AE1B4:
    c.r[1] += 32;  // 060AE1B4 add #32,r1
L_060AE1B6:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060AE1B6 mov.b @r1,r1
L_060AE1B8:
    c.r[0] = 0x1u;  // 060AE1B8 mov #1,r0
L_060AE1BA:
    c.r[3] = c.r[1];  // 060AE1BA mov r1,r3
L_060AE1BC:
    c.r[3] >>= 2;  // 060AE1BC shlr2 r3
L_060AE1BE:
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 060AE1BE shlr r3
L_060AE1C0:
    c.r[3] &= c.r[0];  // 060AE1C0 and r0,r3
L_060AE1C2:
    c.r[1] = (uint32_t)(int16_t)ld16(0x060AE1E6u);  // 060AE1C2 mov.w 0x060AE1E6,r1
L_060AE1C4:
    c.macl = (c.r[3] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 060AE1C4 mulu.w r1,r3
L_060AE1C6:
    c.r[15] -= 12;  // 060AE1C6 add #-12,r15
L_060AE1C8:
    c.r[1] = c.macl;  // 060AE1C8 sts macl,r1
L_060AE1CA:
    c.r[1] += c.r[2];  // 060AE1CA add r2,r1
L_060AE1CC:
    c.r[1] += 65;  // 060AE1CC add #65,r1
L_060AE1CE:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060AE1CE mov.b @r1,r1
L_060AE1D0:
    c.r[14] = c.r[15];  // 060AE1D0 mov r15,r14
L_060AE1D2:
    c.r[1] = c.r[1] & 0xFFu;  // 060AE1D2 extu.b r1,r1
L_060AE1D4:
    st32(c.r[14] + 4, c.r[1]);  // 060AE1D4 mov.l r1,@(4,r14)
L_060AE1D6:
    c.r[0] = c.r[1];  // 060AE1D6 mov r1,r0
L_060AE1D8:
    c.r[0] <<= 2;  // 060AE1D8 shll2 r0
L_060AE1DA:
    c.r[1] = (uint32_t)(int16_t)ld16(0x060AE1E8u);  // 060AE1DA mov.w 0x060AE1E8,r1
L_060AE1DC:
    c.t = (int32_t)c.r[4] > (int32_t)c.r[1];  // 060AE1DC cmp/gt r1,r4
L_060AE1DE:
    { const bool k = !c.t; st32(c.r[14] + 4, c.r[0]); if (k) { goto L_060AE1F0; } }  // 060AE1DE bf/s 0x060AE1F0 ; mov.l r0,@(4,r14)
L_060AE1E2:
    c.r[13] = 0x2u; goto L_060AE1F2;  // 060AE1E2 bra 0x060AE1F2 ; mov #2,r13
L_060AE1F0:
    c.r[13] = 0x1u;  // 060AE1F0 mov #1,r13
L_060AE1F2:
    c.r[0] = (uint32_t)(int16_t)ld16(0x060AE350u);  // 060AE1F2 mov.w 0x060AE350,r0
L_060AE1F4:
    c.r[12] = ld32(c.r[0] + c.r[2]);  // 060AE1F4 mov.l @(r0,r2),r12
L_060AE1F6:
    c.r[4] <<= 2;  // 060AE1F6 shll2 r4
L_060AE1F8:
    c.r[4] += c.r[4];  // 060AE1F8 add r4,r4
L_060AE1FA:
    c.r[4] <<= 2;  // 060AE1FA shll2 r4
L_060AE1FC:
    c.r[8] = ld32(0x060AE358u);  // 060AE1FC mov.l 0x060AE358,r8
L_060AE1FE:
    c.r[1] = c.r[8];  // 060AE1FE mov r8,r1
L_060AE200:
    c.r[1] += 60;  // 060AE200 add #60,r1
L_060AE202:
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060AE202 mov.b @r1,r2
L_060AE204:
    c.r[3] = 0xFu;  // 060AE204 mov #15,r3
L_060AE206:
    c.r[3] &= c.r[2];  // 060AE206 and r2,r3
L_060AE208:
    c.r[7] = c.r[3];  // 060AE208 mov r3,r7
L_060AE20A:
    c.r[7] <<= 2;  // 060AE20A shll2 r7
L_060AE20C:
    c.r[7] <<= 2;  // 060AE20C shll2 r7
L_060AE20E:
    c.r[1] = c.r[7];  // 060AE20E mov r7,r1
L_060AE210:
    c.r[1] |= c.r[3];  // 060AE210 or r3,r1
L_060AE212:
    st8(c.r[14], c.r[1]);  // 060AE212 mov.b r1,@r14
L_060AE214:
    c.r[1] = c.r[14];  // 060AE214 mov r14,r1
L_060AE216:
    c.r[1] += 1;  // 060AE216 add #1,r1
L_060AE218:
    c.r[2] = c.r[2] & 0xFFu;  // 060AE218 extu.b r2,r2
L_060AE21A:
    c.r[2] >>= 2;  // 060AE21A shlr2 r2
L_060AE21C:
    c.r[2] >>= 2;  // 060AE21C shlr2 r2
L_060AE21E:
    c.r[7] |= c.r[2];  // 060AE21E or r2,r7
L_060AE220:
    st8(c.r[1], c.r[7]);  // 060AE220 mov.b r7,@r1
L_060AE222:
    c.r[1] = c.r[14];  // 060AE222 mov r14,r1
L_060AE224:
    c.r[1] += 2;  // 060AE224 add #2,r1
L_060AE226:
    c.r[7] = c.r[2];  // 060AE226 mov r2,r7
L_060AE228:
    c.r[7] <<= 2;  // 060AE228 shll2 r7
L_060AE22A:
    c.r[7] <<= 2;  // 060AE22A shll2 r7
L_060AE22C:
    c.r[3] |= c.r[7];  // 060AE22C or r7,r3
L_060AE22E:
    st8(c.r[1], c.r[3]);  // 060AE22E mov.b r3,@r1
L_060AE230:
    c.r[1] = c.r[14];  // 060AE230 mov r14,r1
L_060AE232:
    c.r[1] += 3;  // 060AE232 add #3,r1
L_060AE234:
    c.r[7] |= c.r[2];  // 060AE234 or r2,r7
L_060AE236:
    st8(c.r[1], c.r[7]);  // 060AE236 mov.b r7,@r1
L_060AE238:
    c.r[2] = c.r[8];  // 060AE238 mov r8,r2
L_060AE23A:
    c.r[1] = c.r[8];  // 060AE23A mov r8,r1
L_060AE23C:
    c.r[1] += 32;  // 060AE23C add #32,r1
L_060AE23E:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060AE23E mov.b @r1,r1
L_060AE240:
    c.r[2] += 58;  // 060AE240 add #58,r2
L_060AE242:
    c.r[10] = c.r[1] & 0xFFu;  // 060AE242 extu.b r1,r10
L_060AE244:
    c.r[0] = c.r[10];  // 060AE244 mov r10,r0
L_060AE246:
    c.r[0] >>= 2;  // 060AE246 shlr2 r0
L_060AE248:
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060AE248 shlr r0
L_060AE24A:
    c.r[0] &= 0x1u;  // 060AE24A and #1,r0
L_060AE24C:
    c.r[1] = (uint32_t)(int16_t)ld16(0x060AE352u);  // 060AE24C mov.w 0x060AE352,r1
L_060AE24E:
    c.macl = (c.r[0] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 060AE24E mulu.w r1,r0
L_060AE250:
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060AE250 mov.b @r2,r2
L_060AE252:
    c.r[7] = c.macl;  // 060AE252 sts macl,r7
L_060AE254:
    c.r[7] += c.r[8];  // 060AE254 add r8,r7
L_060AE256:
    c.r[1] = c.r[7];  // 060AE256 mov r7,r1
L_060AE258:
    c.r[1] += 67;  // 060AE258 add #67,r1
L_060AE25A:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060AE25A mov.b @r1,r1
L_060AE25C:
    c.r[5] = c.r[2] & 0xFFu;  // 060AE25C extu.b r2,r5
L_060AE25E:
    c.r[6] = c.r[1] & 0xFFu;  // 060AE25E extu.b r1,r6
L_060AE260:
    c.t = c.r[5] >= c.r[6];  // 060AE260 cmp/hs r6,r5
L_060AE262:
    { const bool k = !c.t; c.r[12] += c.r[4]; if (k) { goto L_060AE302; } }  // 060AE262 bf/s 0x060AE302 ; add r4,r12
L_060AE266:
    c.r[1] = c.r[7];  // 060AE266 mov r7,r1
L_060AE268:
    c.r[1] += 65;  // 060AE268 add #65,r1
L_060AE26A:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060AE26A mov.b @r1,r1
L_060AE26C:
    c.r[4] = c.r[1] & 0xFFu;  // 060AE26C extu.b r1,r4
L_060AE26E:
    c.r[1] = c.r[6];  // 060AE26E mov r6,r1
L_060AE270:
    c.r[1] += c.r[4];  // 060AE270 add r4,r1
L_060AE272:
    c.t = (int32_t)c.r[5] >= (int32_t)c.r[1];  // 060AE272 cmp/ge r1,r5
L_060AE274:
    { const bool k = c.t; c.r[1] = c.r[8]; if (k) { goto L_060AE302; } }  // 060AE274 bt/s 0x060AE302 ; mov r8,r1
L_060AE278:
    c.r[1] += 59;  // 060AE278 add #59,r1
L_060AE27A:
    c.r[2] = c.r[7];  // 060AE27A mov r7,r2
L_060AE27C:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060AE27C mov.b @r1,r1
L_060AE27E:
    c.r[2] += 68;  // 060AE27E add #68,r2
L_060AE280:
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060AE280 mov.b @r2,r2
L_060AE282:
    c.r[3] = c.r[1] & 0xFFu;  // 060AE282 extu.b r1,r3
L_060AE284:
    c.r[2] = c.r[2] & 0xFFu;  // 060AE284 extu.b r2,r2
L_060AE286:
    c.t = c.r[3] >= c.r[2];  // 060AE286 cmp/hs r2,r3
L_060AE288:
    { const bool k = !c.t; c.r[7] += 66; if (k) { goto L_060AE302; } }  // 060AE288 bf/s 0x060AE302 ; add #66,r7
L_060AE28C:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 060AE28C mov.b @r7,r1
L_060AE28E:
    c.r[1] = c.r[1] & 0xFFu;  // 060AE28E extu.b r1,r1
L_060AE290:
    c.r[1] += c.r[2];  // 060AE290 add r2,r1
L_060AE292:
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[1];  // 060AE292 cmp/ge r1,r3
L_060AE294:
    { const bool k = c.t; c.r[0] = c.r[13]; if (k) { goto L_060AE304; } }  // 060AE294 bt/s 0x060AE304 ; mov r13,r0
L_060AE298:
    c.r[7] = (uint32_t)(int16_t)ld16(0x060AE354u);  // 060AE298 mov.w 0x060AE354,r7
L_060AE29A:
    c.r[3] -= c.r[2];  // 060AE29A sub r2,r3
L_060AE29C:
    c.r[0] = c.r[8];  // 060AE29C mov r8,r0
L_060AE29E:
    c.r[9] = ld32(c.r[0] + c.r[7]);  // 060AE29E mov.l @(r0,r7),r9
L_060AE2A0:
    c.r[5] -= c.r[6];  // 060AE2A0 sub r6,r5
L_060AE2A2:
    c.r[11] = 0x0u;  // 060AE2A2 mov #0,r11
L_060AE2A4:
    c.macl = c.r[3] * c.r[4];  // 060AE2A4 mul.l r4,r3
L_060AE2A6:
    c.r[2] = ld32(0x060AE35Cu);  // 060AE2A6 mov.l 0x060AE35C,r2
L_060AE2A8:
    c.r[0] = 0x2u;  // 060AE2A8 mov #2,r0
L_060AE2AA:
    c.r[1] = c.macl;  // 060AE2AA sts macl,r1
L_060AE2AC:
    c.r[1] <<= 2;  // 060AE2AC shll2 r1
L_060AE2AE:
    c.r[1] += c.r[1];  // 060AE2AE add r1,r1
L_060AE2B0:
    c.r[1] <<= 2;  // 060AE2B0 shll2 r1
L_060AE2B2:
    c.r[5] <<= 2; goto L_060AE368;  // 060AE2B2 bra 0x060AE368 ; shll2 r5
L_060AE302:
    c.r[0] = c.r[13];  // 060AE302 mov r13,r0
L_060AE304:
    c.t = c.r[0] == 0x2u;  // 060AE304 cmp/eq #2,r0
L_060AE306:
    if (!c.t) { goto L_060AE334; }  // 060AE306 bf 0x060AE334
L_060AE308:
    c.r[8] = ld32(0x060AE360u);  // 060AE308 mov.l 0x060AE360,r8
L_060AE30A:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 060AE30A mov.b @r8,r1
L_060AE30C:
    c.r[0] = c.r[1];  // 060AE30C mov r1,r0
L_060AE30E:
    c.r[0] >>= 2;  // 060AE30E shlr2 r0
L_060AE310:
    c.r[0] &= 0x1u;  // 060AE310 and #1,r0
L_060AE312:
    c.t = (c.r[0] & c.r[0]) == 0;  // 060AE312 tst r0,r0
L_060AE314:
    { const bool k = c.t; c.r[0] = 0x1u; if (k) { goto L_060AE322; } }  // 060AE314 bt/s 0x060AE322 ; mov #1,r0
L_060AE318:
    c.r[1] = ld32(0x060AE364u);  // 060AE318 mov.l 0x060AE364,r1
L_060AE31A:
    { const uint32_t x = c.r[1]; c.pr = 0x060AE31Eu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AE31Eu) return; }  // 060AE31A jsr @r1 ; mov #1,r4
L_060AE31E:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 060AE31E mov.b @r8,r1
L_060AE320:
    c.r[0] = 0x1u;  // 060AE320 mov #1,r0
L_060AE322:
    c.r[2] = c.r[1];  // 060AE322 mov r1,r2
L_060AE324:
    c.r[2] >>= 2;  // 060AE324 shlr2 r2
L_060AE326:
    c.r[2] &= c.r[0];  // 060AE326 and r0,r2
L_060AE328:
    c.r[2] ^= c.r[0];  // 060AE328 xor r0,r2
L_060AE32A:
    c.r[2] <<= 2;  // 060AE32A shll2 r2
L_060AE32C:
    c.r[0] = (uint32_t)(int16_t)ld16(0x060AE356u);  // 060AE32C mov.w 0x060AE356,r0
L_060AE32E:
    c.r[1] &= c.r[0];  // 060AE32E and r0,r1
L_060AE330:
    c.r[1] |= c.r[2];  // 060AE330 or r2,r1
L_060AE332:
    st8(c.r[8], c.r[1]);  // 060AE332 mov.b r1,@r8
L_060AE334:
    c.r[1] = ld32(0x060AE364u);  // 060AE334 mov.l 0x060AE364,r1
L_060AE336:
    { const uint32_t x = c.r[1]; c.pr = 0x060AE33Au; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AE33Au) return; }  // 060AE336 jsr @r1 ; mov #1,r4
L_060AE33A:
    c.r[14] += 12;  // 060AE33A add #12,r14
L_060AE33C:
    c.r[15] = c.r[14];  // 060AE33C mov r14,r15
L_060AE33E:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060AE33E lds.l @r15+,pr
L_060AE340:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060AE340 mov.l @r15+,r14
L_060AE342:
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060AE342 mov.l @r15+,r13
L_060AE344:
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060AE344 mov.l @r15+,r12
L_060AE346:
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060AE346 mov.l @r15+,r11
L_060AE348:
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060AE348 mov.l @r15+,r10
L_060AE34A:
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060AE34A mov.l @r15+,r9
L_060AE34C:
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060AE34C rts ; mov.l @r15+,r8
L_060AE368:
    c.r[3] = ld32(0x060AE370u);  // 060AE368 mov.l 0x060AE370,r3
L_060AE36A:
    { const uint32_t x = c.r[3]; SH2_POLL(c); switch (x) { case 0x060AE120u: goto L_060AE120; case 0x060AE122u: goto L_060AE122; case 0x060AE124u: goto L_060AE124; case 0x060AE126u: goto L_060AE126; case 0x060AE128u: goto L_060AE128; case 0x060AE12Au: goto L_060AE12A; case 0x060AE12Cu: goto L_060AE12C; case 0x060AE12Eu: goto L_060AE12E; case 0x060AE130u: goto L_060AE130; case 0x060AE132u: goto L_060AE132; case 0x060AE134u: goto L_060AE134; case 0x060AE136u: goto L_060AE136; case 0x060AE138u: goto L_060AE138; case 0x060AE13Au: goto L_060AE13A; case 0x060AE13Cu: goto L_060AE13C; case 0x060AE13Eu: goto L_060AE13E; case 0x060AE140u: goto L_060AE140; case 0x060AE142u: goto L_060AE142; case 0x060AE144u: goto L_060AE144; case 0x060AE146u: goto L_060AE146; case 0x060AE148u: goto L_060AE148; case 0x060AE14Au: goto L_060AE14A; case 0x060AE14Cu: goto L_060AE14C; case 0x060AE14Eu: goto L_060AE14E; case 0x060AE150u: goto L_060AE150; case 0x060AE152u: goto L_060AE152; case 0x060AE156u: goto L_060AE156; case 0x060AE158u: goto L_060AE158; case 0x060AE15Au: goto L_060AE15A; case 0x060AE15Cu: goto L_060AE15C; case 0x060AE15Eu: goto L_060AE15E; case 0x060AE160u: goto L_060AE160; case 0x060AE162u: goto L_060AE162; case 0x060AE164u: goto L_060AE164; case 0x060AE168u: goto L_060AE168; case 0x060AE16Au: goto L_060AE16A; case 0x060AE16Cu: goto L_060AE16C; case 0x060AE16Eu: goto L_060AE16E; case 0x060AE172u: goto L_060AE172; case 0x060AE174u: goto L_060AE174; case 0x060AE176u: goto L_060AE176; case 0x060AE178u: goto L_060AE178; case 0x060AE17Au: goto L_060AE17A; case 0x060AE17Cu: goto L_060AE17C; case 0x060AE17Eu: goto L_060AE17E; case 0x060AE1A0u: goto L_060AE1A0; case 0x060AE1A2u: goto L_060AE1A2; case 0x060AE1A4u: goto L_060AE1A4; case 0x060AE1A6u: goto L_060AE1A6; case 0x060AE1A8u: goto L_060AE1A8; case 0x060AE1AAu: goto L_060AE1AA; case 0x060AE1ACu: goto L_060AE1AC; case 0x060AE1AEu: goto L_060AE1AE; case 0x060AE1B0u: goto L_060AE1B0; case 0x060AE1B2u: goto L_060AE1B2; case 0x060AE1B4u: goto L_060AE1B4; case 0x060AE1B6u: goto L_060AE1B6; case 0x060AE1B8u: goto L_060AE1B8; case 0x060AE1BAu: goto L_060AE1BA; case 0x060AE1BCu: goto L_060AE1BC; case 0x060AE1BEu: goto L_060AE1BE; case 0x060AE1C0u: goto L_060AE1C0; case 0x060AE1C2u: goto L_060AE1C2; case 0x060AE1C4u: goto L_060AE1C4; case 0x060AE1C6u: goto L_060AE1C6; case 0x060AE1C8u: goto L_060AE1C8; case 0x060AE1CAu: goto L_060AE1CA; case 0x060AE1CCu: goto L_060AE1CC; case 0x060AE1CEu: goto L_060AE1CE; case 0x060AE1D0u: goto L_060AE1D0; case 0x060AE1D2u: goto L_060AE1D2; case 0x060AE1D4u: goto L_060AE1D4; case 0x060AE1D6u: goto L_060AE1D6; case 0x060AE1D8u: goto L_060AE1D8; case 0x060AE1DAu: goto L_060AE1DA; case 0x060AE1DCu: goto L_060AE1DC; case 0x060AE1DEu: goto L_060AE1DE; case 0x060AE1E2u: goto L_060AE1E2; case 0x060AE1F0u: goto L_060AE1F0; case 0x060AE1F2u: goto L_060AE1F2; case 0x060AE1F4u: goto L_060AE1F4; case 0x060AE1F6u: goto L_060AE1F6; case 0x060AE1F8u: goto L_060AE1F8; case 0x060AE1FAu: goto L_060AE1FA; case 0x060AE1FCu: goto L_060AE1FC; case 0x060AE1FEu: goto L_060AE1FE; case 0x060AE200u: goto L_060AE200; case 0x060AE202u: goto L_060AE202; case 0x060AE204u: goto L_060AE204; case 0x060AE206u: goto L_060AE206; case 0x060AE208u: goto L_060AE208; case 0x060AE20Au: goto L_060AE20A; case 0x060AE20Cu: goto L_060AE20C; case 0x060AE20Eu: goto L_060AE20E; case 0x060AE210u: goto L_060AE210; case 0x060AE212u: goto L_060AE212; case 0x060AE214u: goto L_060AE214; case 0x060AE216u: goto L_060AE216; case 0x060AE218u: goto L_060AE218; case 0x060AE21Au: goto L_060AE21A; case 0x060AE21Cu: goto L_060AE21C; case 0x060AE21Eu: goto L_060AE21E; case 0x060AE220u: goto L_060AE220; case 0x060AE222u: goto L_060AE222; case 0x060AE224u: goto L_060AE224; case 0x060AE226u: goto L_060AE226; case 0x060AE228u: goto L_060AE228; case 0x060AE22Au: goto L_060AE22A; case 0x060AE22Cu: goto L_060AE22C; case 0x060AE22Eu: goto L_060AE22E; case 0x060AE230u: goto L_060AE230; case 0x060AE232u: goto L_060AE232; case 0x060AE234u: goto L_060AE234; case 0x060AE236u: goto L_060AE236; case 0x060AE238u: goto L_060AE238; case 0x060AE23Au: goto L_060AE23A; case 0x060AE23Cu: goto L_060AE23C; case 0x060AE23Eu: goto L_060AE23E; case 0x060AE240u: goto L_060AE240; case 0x060AE242u: goto L_060AE242; case 0x060AE244u: goto L_060AE244; case 0x060AE246u: goto L_060AE246; case 0x060AE248u: goto L_060AE248; case 0x060AE24Au: goto L_060AE24A; case 0x060AE24Cu: goto L_060AE24C; case 0x060AE24Eu: goto L_060AE24E; case 0x060AE250u: goto L_060AE250; case 0x060AE252u: goto L_060AE252; case 0x060AE254u: goto L_060AE254; case 0x060AE256u: goto L_060AE256; case 0x060AE258u: goto L_060AE258; case 0x060AE25Au: goto L_060AE25A; case 0x060AE25Cu: goto L_060AE25C; case 0x060AE25Eu: goto L_060AE25E; case 0x060AE260u: goto L_060AE260; case 0x060AE262u: goto L_060AE262; case 0x060AE266u: goto L_060AE266; case 0x060AE268u: goto L_060AE268; case 0x060AE26Au: goto L_060AE26A; case 0x060AE26Cu: goto L_060AE26C; case 0x060AE26Eu: goto L_060AE26E; case 0x060AE270u: goto L_060AE270; case 0x060AE272u: goto L_060AE272; case 0x060AE274u: goto L_060AE274; case 0x060AE278u: goto L_060AE278; case 0x060AE27Au: goto L_060AE27A; case 0x060AE27Cu: goto L_060AE27C; case 0x060AE27Eu: goto L_060AE27E; case 0x060AE280u: goto L_060AE280; case 0x060AE282u: goto L_060AE282; case 0x060AE284u: goto L_060AE284; case 0x060AE286u: goto L_060AE286; case 0x060AE288u: goto L_060AE288; case 0x060AE28Cu: goto L_060AE28C; case 0x060AE28Eu: goto L_060AE28E; case 0x060AE290u: goto L_060AE290; case 0x060AE292u: goto L_060AE292; case 0x060AE294u: goto L_060AE294; case 0x060AE298u: goto L_060AE298; case 0x060AE29Au: goto L_060AE29A; case 0x060AE29Cu: goto L_060AE29C; case 0x060AE29Eu: goto L_060AE29E; case 0x060AE2A0u: goto L_060AE2A0; case 0x060AE2A2u: goto L_060AE2A2; case 0x060AE2A4u: goto L_060AE2A4; case 0x060AE2A6u: goto L_060AE2A6; case 0x060AE2A8u: goto L_060AE2A8; case 0x060AE2AAu: goto L_060AE2AA; case 0x060AE2ACu: goto L_060AE2AC; case 0x060AE2AEu: goto L_060AE2AE; case 0x060AE2B0u: goto L_060AE2B0; case 0x060AE2B2u: goto L_060AE2B2; case 0x060AE302u: goto L_060AE302; case 0x060AE304u: goto L_060AE304; case 0x060AE306u: goto L_060AE306; case 0x060AE308u: goto L_060AE308; case 0x060AE30Au: goto L_060AE30A; case 0x060AE30Cu: goto L_060AE30C; case 0x060AE30Eu: goto L_060AE30E; case 0x060AE310u: goto L_060AE310; case 0x060AE312u: goto L_060AE312; case 0x060AE314u: goto L_060AE314; case 0x060AE318u: goto L_060AE318; case 0x060AE31Au: goto L_060AE31A; case 0x060AE31Eu: goto L_060AE31E; case 0x060AE320u: goto L_060AE320; case 0x060AE322u: goto L_060AE322; case 0x060AE324u: goto L_060AE324; case 0x060AE326u: goto L_060AE326; case 0x060AE328u: goto L_060AE328; case 0x060AE32Au: goto L_060AE32A; case 0x060AE32Cu: goto L_060AE32C; case 0x060AE32Eu: goto L_060AE32E; case 0x060AE330u: goto L_060AE330; case 0x060AE332u: goto L_060AE332; case 0x060AE334u: goto L_060AE334; case 0x060AE336u: goto L_060AE336; case 0x060AE33Au: goto L_060AE33A; case 0x060AE33Cu: goto L_060AE33C; case 0x060AE33Eu: goto L_060AE33E; case 0x060AE340u: goto L_060AE340; case 0x060AE342u: goto L_060AE342; case 0x060AE344u: goto L_060AE344; case 0x060AE346u: goto L_060AE346; case 0x060AE348u: goto L_060AE348; case 0x060AE34Au: goto L_060AE34A; case 0x060AE34Cu: goto L_060AE34C; case 0x060AE368u: goto L_060AE368; case 0x060AE36Au: goto L_060AE36A; default: sh2_call(c, x); return; } }  // 060AE36A jmp @r3 ; nop
}

void f_060AE1A0(SH2Context& c) {
    ran[2960] = 1;
L_060AE1A0:
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060AE1A0 mov.l r8,@-r15
L_060AE1A2:
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060AE1A2 mov.l r9,@-r15
L_060AE1A4:
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060AE1A4 mov.l r10,@-r15
L_060AE1A6:
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060AE1A6 mov.l r11,@-r15
L_060AE1A8:
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060AE1A8 mov.l r12,@-r15
L_060AE1AA:
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060AE1AA mov.l r13,@-r15
L_060AE1AC:
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060AE1AC mov.l r14,@-r15
L_060AE1AE:
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060AE1AE sts.l pr,@-r15
L_060AE1B0:
    c.r[2] = ld32(0x060AE1ECu);  // 060AE1B0 mov.l 0x060AE1EC,r2
L_060AE1B2:
    c.r[1] = c.r[2];  // 060AE1B2 mov r2,r1
L_060AE1B4:
    c.r[1] += 32;  // 060AE1B4 add #32,r1
L_060AE1B6:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060AE1B6 mov.b @r1,r1
L_060AE1B8:
    c.r[0] = 0x1u;  // 060AE1B8 mov #1,r0
L_060AE1BA:
    c.r[3] = c.r[1];  // 060AE1BA mov r1,r3
L_060AE1BC:
    c.r[3] >>= 2;  // 060AE1BC shlr2 r3
L_060AE1BE:
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 060AE1BE shlr r3
L_060AE1C0:
    c.r[3] &= c.r[0];  // 060AE1C0 and r0,r3
L_060AE1C2:
    c.r[1] = (uint32_t)(int16_t)ld16(0x060AE1E6u);  // 060AE1C2 mov.w 0x060AE1E6,r1
L_060AE1C4:
    c.macl = (c.r[3] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 060AE1C4 mulu.w r1,r3
L_060AE1C6:
    c.r[15] -= 12;  // 060AE1C6 add #-12,r15
L_060AE1C8:
    c.r[1] = c.macl;  // 060AE1C8 sts macl,r1
L_060AE1CA:
    c.r[1] += c.r[2];  // 060AE1CA add r2,r1
L_060AE1CC:
    c.r[1] += 65;  // 060AE1CC add #65,r1
L_060AE1CE:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060AE1CE mov.b @r1,r1
L_060AE1D0:
    c.r[14] = c.r[15];  // 060AE1D0 mov r15,r14
L_060AE1D2:
    c.r[1] = c.r[1] & 0xFFu;  // 060AE1D2 extu.b r1,r1
L_060AE1D4:
    st32(c.r[14] + 4, c.r[1]);  // 060AE1D4 mov.l r1,@(4,r14)
L_060AE1D6:
    c.r[0] = c.r[1];  // 060AE1D6 mov r1,r0
L_060AE1D8:
    c.r[0] <<= 2;  // 060AE1D8 shll2 r0
L_060AE1DA:
    c.r[1] = (uint32_t)(int16_t)ld16(0x060AE1E8u);  // 060AE1DA mov.w 0x060AE1E8,r1
L_060AE1DC:
    c.t = (int32_t)c.r[4] > (int32_t)c.r[1];  // 060AE1DC cmp/gt r1,r4
L_060AE1DE:
    { const bool k = !c.t; st32(c.r[14] + 4, c.r[0]); if (k) { goto L_060AE1F0; } }  // 060AE1DE bf/s 0x060AE1F0 ; mov.l r0,@(4,r14)
L_060AE1E2:
    c.r[13] = 0x2u; goto L_060AE1F2;  // 060AE1E2 bra 0x060AE1F2 ; mov #2,r13
L_060AE1F0:
    c.r[13] = 0x1u;  // 060AE1F0 mov #1,r13
L_060AE1F2:
    c.r[0] = (uint32_t)(int16_t)ld16(0x060AE350u);  // 060AE1F2 mov.w 0x060AE350,r0
L_060AE1F4:
    c.r[12] = ld32(c.r[0] + c.r[2]);  // 060AE1F4 mov.l @(r0,r2),r12
L_060AE1F6:
    c.r[4] <<= 2;  // 060AE1F6 shll2 r4
L_060AE1F8:
    c.r[4] += c.r[4];  // 060AE1F8 add r4,r4
L_060AE1FA:
    c.r[4] <<= 2;  // 060AE1FA shll2 r4
L_060AE1FC:
    c.r[8] = ld32(0x060AE358u);  // 060AE1FC mov.l 0x060AE358,r8
L_060AE1FE:
    c.r[1] = c.r[8];  // 060AE1FE mov r8,r1
L_060AE200:
    c.r[1] += 60;  // 060AE200 add #60,r1
L_060AE202:
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060AE202 mov.b @r1,r2
L_060AE204:
    c.r[3] = 0xFu;  // 060AE204 mov #15,r3
L_060AE206:
    c.r[3] &= c.r[2];  // 060AE206 and r2,r3
L_060AE208:
    c.r[7] = c.r[3];  // 060AE208 mov r3,r7
L_060AE20A:
    c.r[7] <<= 2;  // 060AE20A shll2 r7
L_060AE20C:
    c.r[7] <<= 2;  // 060AE20C shll2 r7
L_060AE20E:
    c.r[1] = c.r[7];  // 060AE20E mov r7,r1
L_060AE210:
    c.r[1] |= c.r[3];  // 060AE210 or r3,r1
L_060AE212:
    st8(c.r[14], c.r[1]);  // 060AE212 mov.b r1,@r14
L_060AE214:
    c.r[1] = c.r[14];  // 060AE214 mov r14,r1
L_060AE216:
    c.r[1] += 1;  // 060AE216 add #1,r1
L_060AE218:
    c.r[2] = c.r[2] & 0xFFu;  // 060AE218 extu.b r2,r2
L_060AE21A:
    c.r[2] >>= 2;  // 060AE21A shlr2 r2
L_060AE21C:
    c.r[2] >>= 2;  // 060AE21C shlr2 r2
L_060AE21E:
    c.r[7] |= c.r[2];  // 060AE21E or r2,r7
L_060AE220:
    st8(c.r[1], c.r[7]);  // 060AE220 mov.b r7,@r1
L_060AE222:
    c.r[1] = c.r[14];  // 060AE222 mov r14,r1
L_060AE224:
    c.r[1] += 2;  // 060AE224 add #2,r1
L_060AE226:
    c.r[7] = c.r[2];  // 060AE226 mov r2,r7
L_060AE228:
    c.r[7] <<= 2;  // 060AE228 shll2 r7
L_060AE22A:
    c.r[7] <<= 2;  // 060AE22A shll2 r7
L_060AE22C:
    c.r[3] |= c.r[7];  // 060AE22C or r7,r3
L_060AE22E:
    st8(c.r[1], c.r[3]);  // 060AE22E mov.b r3,@r1
L_060AE230:
    c.r[1] = c.r[14];  // 060AE230 mov r14,r1
L_060AE232:
    c.r[1] += 3;  // 060AE232 add #3,r1
L_060AE234:
    c.r[7] |= c.r[2];  // 060AE234 or r2,r7
L_060AE236:
    st8(c.r[1], c.r[7]);  // 060AE236 mov.b r7,@r1
L_060AE238:
    c.r[2] = c.r[8];  // 060AE238 mov r8,r2
L_060AE23A:
    c.r[1] = c.r[8];  // 060AE23A mov r8,r1
L_060AE23C:
    c.r[1] += 32;  // 060AE23C add #32,r1
L_060AE23E:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060AE23E mov.b @r1,r1
L_060AE240:
    c.r[2] += 58;  // 060AE240 add #58,r2
L_060AE242:
    c.r[10] = c.r[1] & 0xFFu;  // 060AE242 extu.b r1,r10
L_060AE244:
    c.r[0] = c.r[10];  // 060AE244 mov r10,r0
L_060AE246:
    c.r[0] >>= 2;  // 060AE246 shlr2 r0
L_060AE248:
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060AE248 shlr r0
L_060AE24A:
    c.r[0] &= 0x1u;  // 060AE24A and #1,r0
L_060AE24C:
    c.r[1] = (uint32_t)(int16_t)ld16(0x060AE352u);  // 060AE24C mov.w 0x060AE352,r1
L_060AE24E:
    c.macl = (c.r[0] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 060AE24E mulu.w r1,r0
L_060AE250:
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060AE250 mov.b @r2,r2
L_060AE252:
    c.r[7] = c.macl;  // 060AE252 sts macl,r7
L_060AE254:
    c.r[7] += c.r[8];  // 060AE254 add r8,r7
L_060AE256:
    c.r[1] = c.r[7];  // 060AE256 mov r7,r1
L_060AE258:
    c.r[1] += 67;  // 060AE258 add #67,r1
L_060AE25A:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060AE25A mov.b @r1,r1
L_060AE25C:
    c.r[5] = c.r[2] & 0xFFu;  // 060AE25C extu.b r2,r5
L_060AE25E:
    c.r[6] = c.r[1] & 0xFFu;  // 060AE25E extu.b r1,r6
L_060AE260:
    c.t = c.r[5] >= c.r[6];  // 060AE260 cmp/hs r6,r5
L_060AE262:
    { const bool k = !c.t; c.r[12] += c.r[4]; if (k) { goto L_060AE302; } }  // 060AE262 bf/s 0x060AE302 ; add r4,r12
L_060AE266:
    c.r[1] = c.r[7];  // 060AE266 mov r7,r1
L_060AE268:
    c.r[1] += 65;  // 060AE268 add #65,r1
L_060AE26A:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060AE26A mov.b @r1,r1
L_060AE26C:
    c.r[4] = c.r[1] & 0xFFu;  // 060AE26C extu.b r1,r4
L_060AE26E:
    c.r[1] = c.r[6];  // 060AE26E mov r6,r1
L_060AE270:
    c.r[1] += c.r[4];  // 060AE270 add r4,r1
L_060AE272:
    c.t = (int32_t)c.r[5] >= (int32_t)c.r[1];  // 060AE272 cmp/ge r1,r5
L_060AE274:
    { const bool k = c.t; c.r[1] = c.r[8]; if (k) { goto L_060AE302; } }  // 060AE274 bt/s 0x060AE302 ; mov r8,r1
L_060AE278:
    c.r[1] += 59;  // 060AE278 add #59,r1
L_060AE27A:
    c.r[2] = c.r[7];  // 060AE27A mov r7,r2
L_060AE27C:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060AE27C mov.b @r1,r1
L_060AE27E:
    c.r[2] += 68;  // 060AE27E add #68,r2
L_060AE280:
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060AE280 mov.b @r2,r2
L_060AE282:
    c.r[3] = c.r[1] & 0xFFu;  // 060AE282 extu.b r1,r3
L_060AE284:
    c.r[2] = c.r[2] & 0xFFu;  // 060AE284 extu.b r2,r2
L_060AE286:
    c.t = c.r[3] >= c.r[2];  // 060AE286 cmp/hs r2,r3
L_060AE288:
    { const bool k = !c.t; c.r[7] += 66; if (k) { goto L_060AE302; } }  // 060AE288 bf/s 0x060AE302 ; add #66,r7
L_060AE28C:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 060AE28C mov.b @r7,r1
L_060AE28E:
    c.r[1] = c.r[1] & 0xFFu;  // 060AE28E extu.b r1,r1
L_060AE290:
    c.r[1] += c.r[2];  // 060AE290 add r2,r1
L_060AE292:
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[1];  // 060AE292 cmp/ge r1,r3
L_060AE294:
    { const bool k = c.t; c.r[0] = c.r[13]; if (k) { goto L_060AE304; } }  // 060AE294 bt/s 0x060AE304 ; mov r13,r0
L_060AE298:
    c.r[7] = (uint32_t)(int16_t)ld16(0x060AE354u);  // 060AE298 mov.w 0x060AE354,r7
L_060AE29A:
    c.r[3] -= c.r[2];  // 060AE29A sub r2,r3
L_060AE29C:
    c.r[0] = c.r[8];  // 060AE29C mov r8,r0
L_060AE29E:
    c.r[9] = ld32(c.r[0] + c.r[7]);  // 060AE29E mov.l @(r0,r7),r9
L_060AE2A0:
    c.r[5] -= c.r[6];  // 060AE2A0 sub r6,r5
L_060AE2A2:
    c.r[11] = 0x0u;  // 060AE2A2 mov #0,r11
L_060AE2A4:
    c.macl = c.r[3] * c.r[4];  // 060AE2A4 mul.l r4,r3
L_060AE2A6:
    c.r[2] = ld32(0x060AE35Cu);  // 060AE2A6 mov.l 0x060AE35C,r2
L_060AE2A8:
    c.r[0] = 0x2u;  // 060AE2A8 mov #2,r0
L_060AE2AA:
    c.r[1] = c.macl;  // 060AE2AA sts macl,r1
L_060AE2AC:
    c.r[1] <<= 2;  // 060AE2AC shll2 r1
L_060AE2AE:
    c.r[1] += c.r[1];  // 060AE2AE add r1,r1
L_060AE2B0:
    c.r[1] <<= 2;  // 060AE2B0 shll2 r1
L_060AE2B2:
    c.r[5] <<= 2; goto L_060AE368;  // 060AE2B2 bra 0x060AE368 ; shll2 r5
L_060AE302:
    c.r[0] = c.r[13];  // 060AE302 mov r13,r0
L_060AE304:
    c.t = c.r[0] == 0x2u;  // 060AE304 cmp/eq #2,r0
L_060AE306:
    if (!c.t) { goto L_060AE334; }  // 060AE306 bf 0x060AE334
L_060AE308:
    c.r[8] = ld32(0x060AE360u);  // 060AE308 mov.l 0x060AE360,r8
L_060AE30A:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 060AE30A mov.b @r8,r1
L_060AE30C:
    c.r[0] = c.r[1];  // 060AE30C mov r1,r0
L_060AE30E:
    c.r[0] >>= 2;  // 060AE30E shlr2 r0
L_060AE310:
    c.r[0] &= 0x1u;  // 060AE310 and #1,r0
L_060AE312:
    c.t = (c.r[0] & c.r[0]) == 0;  // 060AE312 tst r0,r0
L_060AE314:
    { const bool k = c.t; c.r[0] = 0x1u; if (k) { goto L_060AE322; } }  // 060AE314 bt/s 0x060AE322 ; mov #1,r0
L_060AE318:
    c.r[1] = ld32(0x060AE364u);  // 060AE318 mov.l 0x060AE364,r1
L_060AE31A:
    { const uint32_t x = c.r[1]; c.pr = 0x060AE31Eu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AE31Eu) return; }  // 060AE31A jsr @r1 ; mov #1,r4
L_060AE31E:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 060AE31E mov.b @r8,r1
L_060AE320:
    c.r[0] = 0x1u;  // 060AE320 mov #1,r0
L_060AE322:
    c.r[2] = c.r[1];  // 060AE322 mov r1,r2
L_060AE324:
    c.r[2] >>= 2;  // 060AE324 shlr2 r2
L_060AE326:
    c.r[2] &= c.r[0];  // 060AE326 and r0,r2
L_060AE328:
    c.r[2] ^= c.r[0];  // 060AE328 xor r0,r2
L_060AE32A:
    c.r[2] <<= 2;  // 060AE32A shll2 r2
L_060AE32C:
    c.r[0] = (uint32_t)(int16_t)ld16(0x060AE356u);  // 060AE32C mov.w 0x060AE356,r0
L_060AE32E:
    c.r[1] &= c.r[0];  // 060AE32E and r0,r1
L_060AE330:
    c.r[1] |= c.r[2];  // 060AE330 or r2,r1
L_060AE332:
    st8(c.r[8], c.r[1]);  // 060AE332 mov.b r1,@r8
L_060AE334:
    c.r[1] = ld32(0x060AE364u);  // 060AE334 mov.l 0x060AE364,r1
L_060AE336:
    { const uint32_t x = c.r[1]; c.pr = 0x060AE33Au; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AE33Au) return; }  // 060AE336 jsr @r1 ; mov #1,r4
L_060AE33A:
    c.r[14] += 12;  // 060AE33A add #12,r14
L_060AE33C:
    c.r[15] = c.r[14];  // 060AE33C mov r14,r15
L_060AE33E:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060AE33E lds.l @r15+,pr
L_060AE340:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060AE340 mov.l @r15+,r14
L_060AE342:
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060AE342 mov.l @r15+,r13
L_060AE344:
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060AE344 mov.l @r15+,r12
L_060AE346:
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060AE346 mov.l @r15+,r11
L_060AE348:
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060AE348 mov.l @r15+,r10
L_060AE34A:
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060AE34A mov.l @r15+,r9
L_060AE34C:
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060AE34C rts ; mov.l @r15+,r8
L_060AE368:
    c.r[3] = ld32(0x060AE370u);  // 060AE368 mov.l 0x060AE370,r3
L_060AE36A:
    { const uint32_t x = c.r[3]; SH2_POLL(c); switch (x) { case 0x060AE1A0u: goto L_060AE1A0; case 0x060AE1A2u: goto L_060AE1A2; case 0x060AE1A4u: goto L_060AE1A4; case 0x060AE1A6u: goto L_060AE1A6; case 0x060AE1A8u: goto L_060AE1A8; case 0x060AE1AAu: goto L_060AE1AA; case 0x060AE1ACu: goto L_060AE1AC; case 0x060AE1AEu: goto L_060AE1AE; case 0x060AE1B0u: goto L_060AE1B0; case 0x060AE1B2u: goto L_060AE1B2; case 0x060AE1B4u: goto L_060AE1B4; case 0x060AE1B6u: goto L_060AE1B6; case 0x060AE1B8u: goto L_060AE1B8; case 0x060AE1BAu: goto L_060AE1BA; case 0x060AE1BCu: goto L_060AE1BC; case 0x060AE1BEu: goto L_060AE1BE; case 0x060AE1C0u: goto L_060AE1C0; case 0x060AE1C2u: goto L_060AE1C2; case 0x060AE1C4u: goto L_060AE1C4; case 0x060AE1C6u: goto L_060AE1C6; case 0x060AE1C8u: goto L_060AE1C8; case 0x060AE1CAu: goto L_060AE1CA; case 0x060AE1CCu: goto L_060AE1CC; case 0x060AE1CEu: goto L_060AE1CE; case 0x060AE1D0u: goto L_060AE1D0; case 0x060AE1D2u: goto L_060AE1D2; case 0x060AE1D4u: goto L_060AE1D4; case 0x060AE1D6u: goto L_060AE1D6; case 0x060AE1D8u: goto L_060AE1D8; case 0x060AE1DAu: goto L_060AE1DA; case 0x060AE1DCu: goto L_060AE1DC; case 0x060AE1DEu: goto L_060AE1DE; case 0x060AE1E2u: goto L_060AE1E2; case 0x060AE1F0u: goto L_060AE1F0; case 0x060AE1F2u: goto L_060AE1F2; case 0x060AE1F4u: goto L_060AE1F4; case 0x060AE1F6u: goto L_060AE1F6; case 0x060AE1F8u: goto L_060AE1F8; case 0x060AE1FAu: goto L_060AE1FA; case 0x060AE1FCu: goto L_060AE1FC; case 0x060AE1FEu: goto L_060AE1FE; case 0x060AE200u: goto L_060AE200; case 0x060AE202u: goto L_060AE202; case 0x060AE204u: goto L_060AE204; case 0x060AE206u: goto L_060AE206; case 0x060AE208u: goto L_060AE208; case 0x060AE20Au: goto L_060AE20A; case 0x060AE20Cu: goto L_060AE20C; case 0x060AE20Eu: goto L_060AE20E; case 0x060AE210u: goto L_060AE210; case 0x060AE212u: goto L_060AE212; case 0x060AE214u: goto L_060AE214; case 0x060AE216u: goto L_060AE216; case 0x060AE218u: goto L_060AE218; case 0x060AE21Au: goto L_060AE21A; case 0x060AE21Cu: goto L_060AE21C; case 0x060AE21Eu: goto L_060AE21E; case 0x060AE220u: goto L_060AE220; case 0x060AE222u: goto L_060AE222; case 0x060AE224u: goto L_060AE224; case 0x060AE226u: goto L_060AE226; case 0x060AE228u: goto L_060AE228; case 0x060AE22Au: goto L_060AE22A; case 0x060AE22Cu: goto L_060AE22C; case 0x060AE22Eu: goto L_060AE22E; case 0x060AE230u: goto L_060AE230; case 0x060AE232u: goto L_060AE232; case 0x060AE234u: goto L_060AE234; case 0x060AE236u: goto L_060AE236; case 0x060AE238u: goto L_060AE238; case 0x060AE23Au: goto L_060AE23A; case 0x060AE23Cu: goto L_060AE23C; case 0x060AE23Eu: goto L_060AE23E; case 0x060AE240u: goto L_060AE240; case 0x060AE242u: goto L_060AE242; case 0x060AE244u: goto L_060AE244; case 0x060AE246u: goto L_060AE246; case 0x060AE248u: goto L_060AE248; case 0x060AE24Au: goto L_060AE24A; case 0x060AE24Cu: goto L_060AE24C; case 0x060AE24Eu: goto L_060AE24E; case 0x060AE250u: goto L_060AE250; case 0x060AE252u: goto L_060AE252; case 0x060AE254u: goto L_060AE254; case 0x060AE256u: goto L_060AE256; case 0x060AE258u: goto L_060AE258; case 0x060AE25Au: goto L_060AE25A; case 0x060AE25Cu: goto L_060AE25C; case 0x060AE25Eu: goto L_060AE25E; case 0x060AE260u: goto L_060AE260; case 0x060AE262u: goto L_060AE262; case 0x060AE266u: goto L_060AE266; case 0x060AE268u: goto L_060AE268; case 0x060AE26Au: goto L_060AE26A; case 0x060AE26Cu: goto L_060AE26C; case 0x060AE26Eu: goto L_060AE26E; case 0x060AE270u: goto L_060AE270; case 0x060AE272u: goto L_060AE272; case 0x060AE274u: goto L_060AE274; case 0x060AE278u: goto L_060AE278; case 0x060AE27Au: goto L_060AE27A; case 0x060AE27Cu: goto L_060AE27C; case 0x060AE27Eu: goto L_060AE27E; case 0x060AE280u: goto L_060AE280; case 0x060AE282u: goto L_060AE282; case 0x060AE284u: goto L_060AE284; case 0x060AE286u: goto L_060AE286; case 0x060AE288u: goto L_060AE288; case 0x060AE28Cu: goto L_060AE28C; case 0x060AE28Eu: goto L_060AE28E; case 0x060AE290u: goto L_060AE290; case 0x060AE292u: goto L_060AE292; case 0x060AE294u: goto L_060AE294; case 0x060AE298u: goto L_060AE298; case 0x060AE29Au: goto L_060AE29A; case 0x060AE29Cu: goto L_060AE29C; case 0x060AE29Eu: goto L_060AE29E; case 0x060AE2A0u: goto L_060AE2A0; case 0x060AE2A2u: goto L_060AE2A2; case 0x060AE2A4u: goto L_060AE2A4; case 0x060AE2A6u: goto L_060AE2A6; case 0x060AE2A8u: goto L_060AE2A8; case 0x060AE2AAu: goto L_060AE2AA; case 0x060AE2ACu: goto L_060AE2AC; case 0x060AE2AEu: goto L_060AE2AE; case 0x060AE2B0u: goto L_060AE2B0; case 0x060AE2B2u: goto L_060AE2B2; case 0x060AE302u: goto L_060AE302; case 0x060AE304u: goto L_060AE304; case 0x060AE306u: goto L_060AE306; case 0x060AE308u: goto L_060AE308; case 0x060AE30Au: goto L_060AE30A; case 0x060AE30Cu: goto L_060AE30C; case 0x060AE30Eu: goto L_060AE30E; case 0x060AE310u: goto L_060AE310; case 0x060AE312u: goto L_060AE312; case 0x060AE314u: goto L_060AE314; case 0x060AE318u: goto L_060AE318; case 0x060AE31Au: goto L_060AE31A; case 0x060AE31Eu: goto L_060AE31E; case 0x060AE320u: goto L_060AE320; case 0x060AE322u: goto L_060AE322; case 0x060AE324u: goto L_060AE324; case 0x060AE326u: goto L_060AE326; case 0x060AE328u: goto L_060AE328; case 0x060AE32Au: goto L_060AE32A; case 0x060AE32Cu: goto L_060AE32C; case 0x060AE32Eu: goto L_060AE32E; case 0x060AE330u: goto L_060AE330; case 0x060AE332u: goto L_060AE332; case 0x060AE334u: goto L_060AE334; case 0x060AE336u: goto L_060AE336; case 0x060AE33Au: goto L_060AE33A; case 0x060AE33Cu: goto L_060AE33C; case 0x060AE33Eu: goto L_060AE33E; case 0x060AE340u: goto L_060AE340; case 0x060AE342u: goto L_060AE342; case 0x060AE344u: goto L_060AE344; case 0x060AE346u: goto L_060AE346; case 0x060AE348u: goto L_060AE348; case 0x060AE34Au: goto L_060AE34A; case 0x060AE34Cu: goto L_060AE34C; case 0x060AE368u: goto L_060AE368; case 0x060AE36Au: goto L_060AE36A; default: sh2_call(c, x); return; } }  // 060AE36A jmp @r3 ; nop
}

void f_060AE374(SH2Context& c) {
    ran[2961] = 1;
    goto L_060AE374;
L_060AE2B6:
    c.r[9] += c.r[5];  // 060AE2B6 add r5,r9
    c.t = c.r[10] & 1; c.r[10] >>= 1;  // 060AE2B8 shlr r10
    c.r[10] &= c.r[0];  // 060AE2BA and r0,r10
    c.r[9] += c.r[10];  // 060AE2BC add r10,r9
L_060AE2BE:
    c.r[10] = 0x0u;  // 060AE2BE mov #0,r10
    c.t = (int32_t)c.r[10] >= (int32_t)c.r[13];  // 060AE2C0 cmp/ge r13,r10
    if (c.t) { goto L_060AE2EE; }  // 060AE2C2 bt 0x060AE2EE
L_060AE2C4:
    c.r[8] = 0x7u;  // 060AE2C4 mov #7,r8
L_060AE2C6:
    c.r[5] = c.r[8];  // 060AE2C6 mov r8,r5
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[12]);  // 060AE2C8 mov.b @r12,r4
    c.r[5] -= 1;  // 060AE2CA add #-1,r5
    c.r[4] = c.r[4] & 0xFFu;  // 060AE2CC extu.b r4,r4
    { const uint32_t x = c.r[2]; c.pr = 0x060AE2D2u; st32(c.r[14] + 8, c.r[2]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AE2D2u) return; }  // 060AE2CE jsr @r2 ; mov.l r2,@(8,r14)
    c.r[0] &= 0x3u;  // 060AE2D2 and #3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 060AE2D4 mov.b @(r0,r14),r1
    c.r[8] -= 2;  // 060AE2D6 add #-2,r8
    st8(c.r[9], c.r[1]);  // 060AE2D8 mov.b r1,@r9
    c.r[9] += 1;  // 060AE2DA add #1,r9
    c.r[1] = 0xFFFFFFFFu;  // 060AE2DC mov #-1,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 060AE2DE cmp/gt r1,r8
    { const bool k = c.t; c.r[2] = ld32(c.r[14] + 8); if (k) { SH2_POLL(c); goto L_060AE2C6; } }  // 060AE2E0 bt/s 0x060AE2C6 ; mov.l @(8,r14),r2
    c.r[12] += 3;  // 060AE2E4 add #3,r12
    c.r[10] += 1;  // 060AE2E6 add #1,r10
    c.t = (int32_t)c.r[10] >= (int32_t)c.r[13];  // 060AE2E8 cmp/ge r13,r10
    { const bool k = !c.t; c.r[12] -= c.r[13]; if (k) { SH2_POLL(c); goto L_060AE2C4; } }  // 060AE2EA bf/s 0x060AE2C4 ; sub r13,r12
L_060AE2EE:
    c.r[11] += 1;  // 060AE2EE add #1,r11
    c.r[1] = c.r[13];  // 060AE2F0 mov r13,r1
    c.r[0] = ld32(c.r[14] + 4);  // 060AE2F2 mov.l @(4,r14),r0
    c.r[1] <<= 2;  // 060AE2F4 shll2 r1
    c.r[0] -= c.r[1];  // 060AE2F6 sub r1,r0
    c.r[1] = c.r[0];  // 060AE2F8 mov r0,r1
    c.r[9] += c.r[1];  // 060AE2FA add r1,r9
    c.r[1] = 0xFu;  // 060AE2FC mov #15,r1
    c.t = (int32_t)c.r[11] > (int32_t)c.r[1];  // 060AE2FE cmp/gt r1,r11
    if (!c.t) { SH2_POLL(c); goto L_060AE2BE; }  // 060AE300 bf 0x060AE2BE
    c.r[0] = c.r[13];  // 060AE302 mov r13,r0
    c.t = c.r[0] == 0x2u;  // 060AE304 cmp/eq #2,r0
    if (!c.t) { goto L_060AE334; }  // 060AE306 bf 0x060AE334
    c.r[8] = ld32(0x060AE360u);  // 060AE308 mov.l 0x060AE360,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 060AE30A mov.b @r8,r1
    c.r[0] = c.r[1];  // 060AE30C mov r1,r0
    c.r[0] >>= 2;  // 060AE30E shlr2 r0
    c.r[0] &= 0x1u;  // 060AE310 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060AE312 tst r0,r0
    { const bool k = c.t; c.r[0] = 0x1u; if (k) { goto L_060AE322; } }  // 060AE314 bt/s 0x060AE322 ; mov #1,r0
    c.r[1] = ld32(0x060AE364u);  // 060AE318 mov.l 0x060AE364,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060AE31Eu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AE31Eu) return; }  // 060AE31A jsr @r1 ; mov #1,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 060AE31E mov.b @r8,r1
    c.r[0] = 0x1u;  // 060AE320 mov #1,r0
L_060AE322:
    c.r[2] = c.r[1];  // 060AE322 mov r1,r2
    c.r[2] >>= 2;  // 060AE324 shlr2 r2
    c.r[2] &= c.r[0];  // 060AE326 and r0,r2
    c.r[2] ^= c.r[0];  // 060AE328 xor r0,r2
    c.r[2] <<= 2;  // 060AE32A shll2 r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x060AE356u);  // 060AE32C mov.w 0x060AE356,r0
    c.r[1] &= c.r[0];  // 060AE32E and r0,r1
    c.r[1] |= c.r[2];  // 060AE330 or r2,r1
    st8(c.r[8], c.r[1]);  // 060AE332 mov.b r1,@r8
L_060AE334:
    c.r[1] = ld32(0x060AE364u);  // 060AE334 mov.l 0x060AE364,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060AE33Au; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AE33Au) return; }  // 060AE336 jsr @r1 ; mov #1,r4
    c.r[14] += 12;  // 060AE33A add #12,r14
    c.r[15] = c.r[14];  // 060AE33C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060AE33E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060AE340 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060AE342 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060AE344 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060AE346 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060AE348 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060AE34A mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060AE34C rts ; mov.l @r15+,r8
L_060AE374:
    c.r[0] = c.r[0] & 0xFFu;  // 060AE374 extu.b r0,r0
    c.r[2] = c.r[0];  // 060AE376 mov r0,r2
    c.t = c.r[2] == c.r[0];  // 060AE378 cmp/eq r0,r2
    ;  // 060AE37A nop
    c.r[1] = c.r[8];  // 060AE37C mov r8,r1
    c.r[1] += 58;  // 060AE37E add #58,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060AE380 mov.b @r1,r0
    c.r[0] = c.r[0] & 0xFFu;  // 060AE382 extu.b r0,r0
    ;  // 060AE384 nop
    c.t = c.r[2] == c.r[0];  // 060AE386 cmp/eq r0,r2
    if (!c.t) { goto L_060AE390; }  // 060AE388 bf 0x060AE390
    c.r[1] = ld32(0x060AE3A0u);  // 060AE38A mov.l 0x060AE3A0,r1
    c.r[0] = 0x0u;  // 060AE38C mov #0,r0
    st8(c.r[1], c.r[0]);  // 060AE38E mov.b r0,@r1
L_060AE390:
    c.r[1] = ld32(0x060AE3A0u);  // 060AE390 mov.l 0x060AE3A0,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060AE392 mov.b @r1,r0
    c.r[0] = c.r[0] & 0xFFu;  // 060AE394 extu.b r0,r0
    c.r[9] -= c.r[0];  // 060AE396 sub r0,r9
    c.r[2] = ld32(c.r[15]); c.r[15] += 4;  // 060AE398 mov.l @r15+,r2
    c.r[0] = ld32(c.r[15]); c.r[15] += 4;  // 060AE39A mov.l @r15+,r0
    SH2_POLL(c); goto L_060AE2B6;  // 060AE39C bra 0x060AE2B6 ; nop
}

void f_060AE3A8(SH2Context& c) {
    ran[2962] = 1;
L_060AE3A8:
    c.r[0] = 0x7u;  // 060AE3A8 mov #7,r0
L_060AE3AA:
    c.t = c.r[4] == c.r[0];  // 060AE3AA cmp/eq r0,r4
L_060AE3AC:
    if (!c.t) { goto L_060AE3DE; }  // 060AE3AC bf 0x060AE3DE
L_060AE3AE:
    c.r[0] = ld32(0x060AE3E4u);  // 060AE3AE mov.l 0x060AE3E4,r0
L_060AE3B0:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 060AE3B0 mov.b @r0,r1
L_060AE3B2:
    c.r[1] = c.r[1] & 0xFFu;  // 060AE3B2 extu.b r1,r1
L_060AE3B4:
    c.r[0] = 0xDu;  // 060AE3B4 mov #13,r0
L_060AE3B6:
    c.t = c.r[1] == c.r[0];  // 060AE3B6 cmp/eq r0,r1
L_060AE3B8:
    if (!c.t) { goto L_060AE3DE; }  // 060AE3B8 bf 0x060AE3DE
L_060AE3BA:
    c.r[0] = ld32(0x060AE3E8u);  // 060AE3BA mov.l 0x060AE3E8,r0
L_060AE3BC:
    c.t = c.r[5] == c.r[0];  // 060AE3BC cmp/eq r0,r5
L_060AE3BE:
    if (!c.t) { goto L_060AE3DE; }  // 060AE3BE bf 0x060AE3DE
L_060AE3C0:
    c.r[0] = ld32(0x060AE3ECu);  // 060AE3C0 mov.l 0x060AE3EC,r0
L_060AE3C2:
    c.t = c.r[6] == c.r[0];  // 060AE3C2 cmp/eq r0,r6
L_060AE3C4:
    if (!c.t) { goto L_060AE3DE; }  // 060AE3C4 bf 0x060AE3DE
L_060AE3C6:
    c.r[0] = ld32(0x060AE3F0u);  // 060AE3C6 mov.l 0x060AE3F0,r0
L_060AE3C8:
    c.r[1] = ld32(c.r[0]);  // 060AE3C8 mov.l @r0,r1
L_060AE3CA:
    c.r[2] = ld32(0x060AE3F4u);  // 060AE3CA mov.l 0x060AE3F4,r2
L_060AE3CC:
    c.t = c.r[1] == c.r[2];  // 060AE3CC cmp/eq r2,r1
L_060AE3CE:
    if (!c.t) { goto L_060AE3DE; }  // 060AE3CE bf 0x060AE3DE
L_060AE3D0:
    c.r[1] = ld32(c.r[0] + 4);  // 060AE3D0 mov.l @(4,r0),r1
L_060AE3D2:
    c.r[2] = ld32(0x060AE3F8u);  // 060AE3D2 mov.l 0x060AE3F8,r2
L_060AE3D4:
    c.t = c.r[1] == c.r[2];  // 060AE3D4 cmp/eq r2,r1
L_060AE3D6:
    if (!c.t) { goto L_060AE3DE; }  // 060AE3D6 bf 0x060AE3DE
L_060AE3D8:
    c.r[0] = ld32(0x060AE3FCu);  // 060AE3D8 mov.l 0x060AE3FC,r0
L_060AE3DA:
    st32(c.r[8] + 16, c.r[0]);  // 060AE3DA mov.l r0,@(16,r8)
L_060AE3DC:
    c.r[6] = ld32(0x060AE400u);  // 060AE3DC mov.l 0x060AE400,r6
L_060AE3DE:
    c.r[0] = ld32(0x060AE404u);  // 060AE3DE mov.l 0x060AE404,r0
L_060AE3E0:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x060AE3A8u: goto L_060AE3A8; case 0x060AE3AAu: goto L_060AE3AA; case 0x060AE3ACu: goto L_060AE3AC; case 0x060AE3AEu: goto L_060AE3AE; case 0x060AE3B0u: goto L_060AE3B0; case 0x060AE3B2u: goto L_060AE3B2; case 0x060AE3B4u: goto L_060AE3B4; case 0x060AE3B6u: goto L_060AE3B6; case 0x060AE3B8u: goto L_060AE3B8; case 0x060AE3BAu: goto L_060AE3BA; case 0x060AE3BCu: goto L_060AE3BC; case 0x060AE3BEu: goto L_060AE3BE; case 0x060AE3C0u: goto L_060AE3C0; case 0x060AE3C2u: goto L_060AE3C2; case 0x060AE3C4u: goto L_060AE3C4; case 0x060AE3C6u: goto L_060AE3C6; case 0x060AE3C8u: goto L_060AE3C8; case 0x060AE3CAu: goto L_060AE3CA; case 0x060AE3CCu: goto L_060AE3CC; case 0x060AE3CEu: goto L_060AE3CE; case 0x060AE3D0u: goto L_060AE3D0; case 0x060AE3D2u: goto L_060AE3D2; case 0x060AE3D4u: goto L_060AE3D4; case 0x060AE3D6u: goto L_060AE3D6; case 0x060AE3D8u: goto L_060AE3D8; case 0x060AE3DAu: goto L_060AE3DA; case 0x060AE3DCu: goto L_060AE3DC; case 0x060AE3DEu: goto L_060AE3DE; case 0x060AE3E0u: goto L_060AE3E0; default: sh2_call(c, x); return; } }  // 060AE3E0 jmp @r0 ; nop
}

void f_060AE408(SH2Context& c) {
    ran[2963] = 1;
L_060AE408:
    c.r[1] = ld32(0x060AE430u);  // 060AE408 mov.l 0x060AE430,r1
L_060AE40A:
    c.r[2] = ld32(0x060AE434u);  // 060AE40A mov.l 0x060AE434,r2
L_060AE40C:
    c.r[0] = 0x6u;  // 060AE40C mov #6,r0
L_060AE40E:
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 060AE40E mov.b @r1+,r3
L_060AE410:
    c.r[3] = c.r[3] & 0xFFu;  // 060AE410 extu.b r3,r3
L_060AE412:
    c.t = c.r[7] == c.r[3];  // 060AE412 cmp/eq r3,r7
L_060AE414:
    if (c.t) { goto L_060AE422; }  // 060AE414 bt 0x060AE422
L_060AE416:
    c.r[2] += 8;  // 060AE416 add #8,r2
L_060AE418:
    c.r[0] -= 1; c.t = c.r[0] == 0;  // 060AE418 dt r0
L_060AE41A:
    if (!c.t) { SH2_POLL(c); goto L_060AE40E; }  // 060AE41A bf 0x060AE40E
L_060AE41C:
    c.r[0] = ld32(0x060AE438u);  // 060AE41C mov.l 0x060AE438,r0
L_060AE41E:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x060AE408u: goto L_060AE408; case 0x060AE40Au: goto L_060AE40A; case 0x060AE40Cu: goto L_060AE40C; case 0x060AE40Eu: goto L_060AE40E; case 0x060AE410u: goto L_060AE410; case 0x060AE412u: goto L_060AE412; case 0x060AE414u: goto L_060AE414; case 0x060AE416u: goto L_060AE416; case 0x060AE418u: goto L_060AE418; case 0x060AE41Au: goto L_060AE41A; case 0x060AE41Cu: goto L_060AE41C; case 0x060AE41Eu: goto L_060AE41E; case 0x060AE422u: goto L_060AE422; case 0x060AE424u: goto L_060AE424; case 0x060AE426u: goto L_060AE426; case 0x060AE428u: goto L_060AE428; case 0x060AE42Au: goto L_060AE42A; case 0x060AE42Cu: goto L_060AE42C; default: sh2_call(c, x); return; } }  // 060AE41E jmp @r0 ; nop
L_060AE422:
    c.r[0] = c.r[7];  // 060AE422 mov r7,r0
L_060AE424:
    c.r[0] <<= 2;  // 060AE424 shll2 r0
L_060AE426:
    c.t = c.r[0] >> 31; c.r[0] <<= 1;  // 060AE426 shll r0
L_060AE428:
    c.r[2] -= c.r[0];  // 060AE428 sub r0,r2
L_060AE42A:
    c.r[5] = c.r[2];  // 060AE42A mov r2,r5
L_060AE42C:
    SH2_POLL(c); goto L_060AE41C;  // 060AE42C bra 0x060AE41C ; nop
}

void f_060AE440(SH2Context& c) {
    ran[2964] = 1;
L_060AE440:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]); c.r[3] += 1;  // 060AE440 mov.b @r3+,r1
    c.t = c.r[1] == c.r[4];  // 060AE442 cmp/eq r4,r1
    if (c.t) { goto L_060AE45C; }  // 060AE444 bt 0x060AE45C
    c.t = c.r[1] > c.r[2];  // 060AE446 cmp/hi r2,r1
    if (!c.t) { goto L_060AE454; }  // 060AE448 bf 0x060AE454
    c.t = c.r[3] >= c.r[6];  // 060AE44A cmp/hs r6,r3
    if (c.t) { goto L_060AE45C; }  // 060AE44C bt 0x060AE45C
    st8(c.r[0] + c.r[5], c.r[1]);  // 060AE44E mov.b r1,@(r0,r5)
    c.r[0] += 1;  // 060AE450 add #1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]); c.r[3] += 1;  // 060AE452 mov.b @r3+,r1
L_060AE454:
    st8(c.r[0] + c.r[5], c.r[1]);  // 060AE454 mov.b r1,@(r0,r5)
    c.r[0] += 1;  // 060AE456 add #1,r0
    c.t = c.r[3] >= c.r[6];  // 060AE458 cmp/hs r6,r3
    if (!c.t) { SH2_POLL(c); goto L_060AE440; }  // 060AE45A bf 0x060AE440
L_060AE45C:
    { const uint32_t x = c.pr; st8(c.r[0] + c.r[5], c.r[4]); c.pc = x; return; }  // 060AE45C rts ; mov.b r4,@(r0,r5)
}

void f_060AE460(SH2Context& c) {
    ran[2965] = 1;
L_060AE460:
    c.r[1] = ld32(0x060AE49Cu);  // 060AE460 mov.l 0x060AE49C,r1
L_060AE462:
    c.t = c.r[2] == c.r[1];  // 060AE462 cmp/eq r1,r2
L_060AE464:
    if (c.t) { goto L_060AE472; }  // 060AE464 bt 0x060AE472
L_060AE466:
    c.r[1] = ld32(0x060AE4A0u);  // 060AE466 mov.l 0x060AE4A0,r1
L_060AE468:
    c.t = c.r[2] == c.r[1];  // 060AE468 cmp/eq r1,r2
L_060AE46A:
    if (c.t) { goto L_060AE482; }  // 060AE46A bt 0x060AE482
L_060AE46C:
    c.r[1] = ld32(0x060AE4A4u);  // 060AE46C mov.l 0x060AE4A4,r1
L_060AE46E:
    { const uint32_t x = c.r[1]; SH2_POLL(c); switch (x) { case 0x060AE460u: goto L_060AE460; case 0x060AE462u: goto L_060AE462; case 0x060AE464u: goto L_060AE464; case 0x060AE466u: goto L_060AE466; case 0x060AE468u: goto L_060AE468; case 0x060AE46Au: goto L_060AE46A; case 0x060AE46Cu: goto L_060AE46C; case 0x060AE46Eu: goto L_060AE46E; case 0x060AE472u: goto L_060AE472; case 0x060AE474u: goto L_060AE474; case 0x060AE476u: goto L_060AE476; case 0x060AE478u: goto L_060AE478; case 0x060AE47Au: goto L_060AE47A; case 0x060AE47Cu: goto L_060AE47C; case 0x060AE47Eu: goto L_060AE47E; case 0x060AE482u: goto L_060AE482; case 0x060AE484u: goto L_060AE484; case 0x060AE486u: goto L_060AE486; case 0x060AE48Au: goto L_060AE48A; case 0x060AE48Cu: goto L_060AE48C; case 0x060AE48Eu: goto L_060AE48E; case 0x060AE490u: goto L_060AE490; case 0x060AE492u: goto L_060AE492; case 0x060AE494u: goto L_060AE494; case 0x060AE496u: goto L_060AE496; case 0x060AE498u: goto L_060AE498; default: sh2_call(c, x); return; } }  // 060AE46E jmp @r1 ; nop
L_060AE472:
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 060AE472 mov.l r0,@-r15
L_060AE474:
    c.r[1] = ld32(0x060AE4A8u);  // 060AE474 mov.l 0x060AE4A8,r1
L_060AE476:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060AE476 mov.b @r1,r0
L_060AE478:
    c.r[0] ^= 0x4u;  // 060AE478 xor #4,r0
L_060AE47A:
    st8(c.r[1], c.r[0]);  // 060AE47A mov.b r0,@r1
L_060AE47C:
    c.r[0] = ld32(c.r[15]); c.r[15] += 4;  // 060AE47C mov.l @r15+,r0
L_060AE47E:
    SH2_POLL(c); goto L_060AE46C;  // 060AE47E bra 0x060AE46C ; nop
L_060AE482:
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060AE482 sts.l pr,@-r15
L_060AE484:
    c.r[1] = ld32(0x060AE4A4u);  // 060AE484 mov.l 0x060AE4A4,r1
L_060AE486:
    { const uint32_t x = c.r[1]; c.pr = 0x060AE48Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AE48Au) return; }  // 060AE486 jsr @r1 ; nop
L_060AE48A:
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 060AE48A mov.l r0,@-r15
L_060AE48C:
    c.r[1] = ld32(0x060AE4A8u);  // 060AE48C mov.l 0x060AE4A8,r1
L_060AE48E:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060AE48E mov.b @r1,r0
L_060AE490:
    c.r[0] ^= 0x4u;  // 060AE490 xor #4,r0
L_060AE492:
    st8(c.r[1], c.r[0]);  // 060AE492 mov.b r0,@r1
L_060AE494:
    c.r[0] = ld32(c.r[15]); c.r[15] += 4;  // 060AE494 mov.l @r15+,r0
L_060AE496:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060AE496 lds.l @r15+,pr
L_060AE498:
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060AE498 rts ; nop
}

void f_060AE4B6(SH2Context& c) {
    ran[2966] = 1;
    goto L_060AE4B6;
L_060AE4B0:
    c.r[0] = 0x1u;  // 060AE4B0 mov #1,r0
    { const uint32_t x = c.pr; st8(c.gbr + 115, c.r[0]); c.pc = x; return; }  // 060AE4B2 rts ; mov.b r0,@(115,gbr)
L_060AE4B6:
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 170);  // 060AE4B6 mov.w @(170,gbr),r0
    c.r[0] += 1;  // 060AE4B8 add #1,r0
    st16(c.gbr + 170, c.r[0]);  // 060AE4BA mov.w r0,@(170,gbr)
    c.r[0] = ld32(c.gbr + 28);  // 060AE4BC mov.l @(28,gbr),r0
    c.r[1] = 0xFFFFFFFCu;  // 060AE4BE mov #-4,r1
    c.r[4] &= c.r[1];  // 060AE4C0 and r1,r4
    c.mach = c.macl = 0;  // 060AE4C2 clrmac
    c.r[0] += 32;  // 060AE4C4 add #32,r0
    sh2_mac_l(c, 0, 4);  // 060AE4C6 mac.l @r4+,@r0+
    c.r[2] = c.r[0];  // 060AE4C8 mov r0,r2
    c.r[0] = ld32(c.gbr + 104);  // 060AE4CA mov.l @(104,gbr),r0
    sh2_mac_l(c, 2, 4);  // 060AE4CC mac.l @r4+,@r2+
    c.r[3] = c.r[0];  // 060AE4CE mov r0,r3
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 112);  // 060AE4D0 mov.w @(112,gbr),r0
    sh2_mac_l(c, 2, 4);  // 060AE4D2 mac.l @r4+,@r2+
    c.r[2] = ld32(c.r[2]);  // 060AE4D4 mov.l @r2,r2
    c.r[7] = c.r[0];  // 060AE4D6 mov r0,r7
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 172);  // 060AE4D8 mov.b @(172,gbr),r0
    c.r[1] = c.mach;  // 060AE4DA sts mach,r1
L_060AE4DC:
    c.r[0] -= 1; c.t = c.r[0] == 0;  // 060AE4DC dt r0
    { const bool k = !c.t; c.t = c.r[3] & 1; c.r[3] >>= 1; if (k) { SH2_POLL(c); goto L_060AE4DC; } }  // 060AE4DE bf/s 0x060AE4DC ; shlr r3
    c.r[0] = c.r[7];  // 060AE4E2 mov r7,r0
    c.r[7] = c.macl;  // 060AE4E4 sts macl,r7
    c.r[3] = 0u - c.r[3];  // 060AE4E6 neg r3,r3
    c.r[7] = c.r[1] << 16 | c.r[7] >> 16;  // 060AE4E8 xtrct r1,r7
    c.r[7] += c.r[2];  // 060AE4EA add r2,r7
    c.r[3] += c.r[7];  // 060AE4EC add r7,r3
    c.r[0] <<= 16;  // 060AE4EE shll16 r0
    c.t = c.r[3] > c.r[0];  // 060AE4F0 cmp/hi r0,r3
    { const bool k = c.t; c.r[4] -= 12; if (k) { SH2_POLL(c); goto L_060AE4B0; } }  // 060AE4F2 bt/s 0x060AE4B0 ; add #-12,r4
    c.r[0] = ld32(c.gbr + 104);  // 060AE4F6 mov.l @(104,gbr),r0
    c.r[1] = 0xFFFFFFFFu;  // 060AE4F8 mov #-1,r1
    c.r[1] <<= 8;  // 060AE4FA shll8 r1
    c.r[1] = 0xFFFFFFFFu;  // 060AE4FC mov #-1,r1
    c.r[1] <<= 8;  // 060AE4FE shll8 r1
    st32(c.r[1], c.r[7]);  // 060AE500 mov.l r7,@(0,r1)
    c.r[7] = c.r[0] << 16 | c.r[0] >> 16;  // 060AE502 swap.w r0,r7
    c.r[7] = (uint32_t)(int32_t)(int16_t)c.r[7];  // 060AE504 exts.w r7,r7
    st32(c.r[1] + 16, c.r[7]);  // 060AE506 mov.l r7,@(16,r1)
    c.r[0] <<= 16;  // 060AE508 shll16 r0
    st32(c.r[1] + 20, c.r[0]);  // 060AE50A mov.l r0,@(20,r1)
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 136);  // 060AE50C mov.w @(136,gbr),r0
    c.r[1] = c.r[0] & 0xFFFFu;  // 060AE50E extu.w r0,r1
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 116);  // 060AE510 mov.w @(116,gbr),r0
    c.r[0] = c.r[0] & 0xFFFFu;  // 060AE512 extu.w r0,r0
    c.t = c.r[0] >= c.r[1];  // 060AE514 cmp/hs r1,r0
    { const bool k = c.t; c.r[1] = 0xFFFFFFFEu; if (k) { goto L_060AE5F0; } }  // 060AE516 bt/s 0x060AE5F0 ; mov #-2,r1
    c.r[0] += 1;  // 060AE51A add #1,r0
    st16(c.gbr + 116, c.r[0]);  // 060AE51C mov.w r0,@(116,gbr)
    c.r[5] &= c.r[1];  // 060AE51E and r1,r5
    c.r[0] = ld32(c.gbr + 28);  // 060AE520 mov.l @(28,gbr),r0
    c.mach = c.macl = 0;  // 060AE522 clrmac
    c.r[2] = c.r[0];  // 060AE524 mov r0,r2
    c.r[0] = ld32(c.gbr + 72);  // 060AE526 mov.l @(72,gbr),r0
    sh2_mac_l(c, 2, 4);  // 060AE528 mac.l @r4+,@r2+
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060AE52A mov.l r9,@-r15
    c.r[9] = c.r[0];  // 060AE52C mov r0,r9
    sh2_mac_l(c, 2, 4);  // 060AE52E mac.l @r4+,@r2+
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[5] + 8);  // 060AE530 mov.w @(8,r5),r0
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060AE532 mov.l r8,@-r15
    sh2_mac_l(c, 2, 4);  // 060AE534 mac.l @r4+,@r2+
    c.r[7] = ld32(c.r[2]); c.r[2] += 4;  // 060AE536 mov.l @r2+,r7
    c.r[4] -= 12;  // 060AE538 add #-12,r4
    c.r[3] = c.r[0] << 16 | c.r[3] >> 16;  // 060AE53A xtrct r0,r3
    st32(c.r[9] + 4, c.r[3]);  // 060AE53C mov.l r3,@(4,r9)
    c.r[1] = c.mach;  // 060AE53E sts mach,r1
    c.r[8] = c.macl;  // 060AE540 sts macl,r8
    c.mach = c.macl = 0;  // 060AE542 clrmac
    c.r[8] = c.r[1] << 16 | c.r[8] >> 16;  // 060AE544 xtrct r1,r8
    sh2_mac_l(c, 2, 4);  // 060AE546 mac.l @r4+,@r2+
    c.r[8] += c.r[7];  // 060AE548 add r7,r8
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[5]); c.r[5] += 2;  // 060AE54A mov.w @r5+,r0
    sh2_mac_l(c, 2, 4);  // 060AE54C mac.l @r4+,@r2+
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[5]); c.r[5] += 2;  // 060AE54E mov.w @r5+,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[5]); c.r[5] += 2;  // 060AE550 mov.w @r5+,r1
    sh2_mac_l(c, 2, 4);  // 060AE552 mac.l @r4+,@r2+
    c.r[1] <<= 16;  // 060AE554 shll16 r1
    c.r[1] = c.r[3] << 16 | c.r[1] >> 16;  // 060AE556 xtrct r3,r1
    c.r[3] = ld32(c.r[2]);  // 060AE558 mov.l @r2,r3
    c.r[2] = c.mach;  // 060AE55A sts mach,r2
    c.r[7] = c.macl;  // 060AE55C sts macl,r7
    c.r[4] = ld32(c.r[4]);  // 060AE55E mov.l @r4,r4
    c.r[7] = c.r[2] << 16 | c.r[7] >> 16;  // 060AE560 xtrct r2,r7
    c.r[7] += c.r[3];  // 060AE562 add r3,r7
    c.t = (int32_t)c.r[4] >= 0;  // 060AE564 cmp/pz r4
    { const bool k = c.t; c.r[3] = (uint32_t)(int16_t)ld16(c.r[5]); c.r[5] += 2; if (k) { goto L_060AE56C; } }  // 060AE566 bt/s 0x060AE56C ; mov.w @r5+,r3
    c.r[4] = 0u - c.r[4];  // 060AE56A neg r4,r4
L_060AE56C:
    st32(c.r[9] + 12, c.r[1]);  // 060AE56C mov.l r1,@(12,r9)
    c.r[3] <<= 16;  // 060AE56E shll16 r3
    c.r[3] = c.r[0] << 16 | c.r[3] >> 16;  // 060AE570 xtrct r0,r3
    c.r[1] = 0xFFFFFFFFu;  // 060AE572 mov #-1,r1
    c.r[1] <<= 8;  // 060AE574 shll8 r1
    c.r[1] = ld32(c.r[1] + 28);  // 060AE576 mov.l @(28,r1),r1
    st32(c.r[9] + 8, c.r[3]);  // 060AE578 mov.l r3,@(8,r9)
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[4] * (int32_t)c.r[1]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060AE57A dmuls.l r1,r4
    c.r[2] = c.mach;  // 060AE57C sts mach,r2
    c.r[4] = c.macl;  // 060AE57E sts macl,r4
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[8] * (int32_t)c.r[1]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060AE580 dmuls.l r1,r8
    c.r[4] = c.r[2] << 16 | c.r[4] >> 16;  // 060AE582 xtrct r2,r4
    st32(c.r[9] + 24, c.r[4]);  // 060AE584 mov.l r4,@(24,r9)
    c.r[2] = c.mach;  // 060AE586 sts mach,r2
    c.r[3] = c.macl;  // 060AE588 sts macl,r3
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[7] * (int32_t)c.r[1]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060AE58A dmuls.l r1,r7
    c.r[3] = c.r[2] << 16 | c.r[3] >> 16;  // 060AE58C xtrct r2,r3
    st32(c.r[9] + 16, c.r[3]);  // 060AE58E mov.l r3,@(16,r9)
    c.r[2] = c.mach;  // 060AE590 sts mach,r2
    c.r[3] = c.macl;  // 060AE592 sts macl,r3
    c.r[4] = c.r[6] & 0xFFFFu;  // 060AE594 extu.w r6,r4
    c.r[3] = c.r[2] << 16 | c.r[3] >> 16;  // 060AE596 xtrct r2,r3
    c.t = (c.r[4] & c.r[4]) == 0;  // 060AE598 tst r4,r4
    { const bool k = c.t; st32(c.r[9] + 20, c.r[3]); if (k) { goto L_060AE5DE; } }  // 060AE59A bt/s 0x060AE5DE ; mov.l r3,@(20,r9)
    c.r[0] = (c.r[4] & 0xFFFF0000u) | (c.r[4] & 0xFFu) << 8 | (c.r[4] >> 8 & 0xFFu);  // 060AE59E swap.b r4,r0
    c.r[0] >>= 2;  // 060AE5A0 shlr2 r0
    c.r[0] >>= 2;  // 060AE5A2 shlr2 r0
    c.r[2] = 0xCu;  // 060AE5A4 mov #12,r2
    c.r[2] &= c.r[0];  // 060AE5A6 and r0,r2
    c.r[0] = 0x060AE600u;  // 060AE5A8 mova 0x060AE600,r0
    c.r[2] += c.r[0];  // 060AE5AA add r0,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]); c.r[2] += 1;  // 060AE5AC mov.b @r2+,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]); c.r[2] += 1;  // 060AE5AE mov.b @r2+,r0
    c.r[5] = c.r[4];  // 060AE5B0 mov r4,r5
    c.r[4] ^= c.r[1];  // 060AE5B2 xor r1,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x060AE610u);  // 060AE5B4 mov.w 0x060AE610,r1
    c.r[5] ^= c.r[0];  // 060AE5B6 xor r0,r5
    c.r[0] = ld32(0x060AE5FCu);  // 060AE5B8 mov.l 0x060AE5FC,r0
    c.r[4] &= c.r[1];  // 060AE5BA and r1,r4
    c.r[5] &= c.r[1];  // 060AE5BC and r1,r5
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[4]);  // 060AE5BE mov.w @(r0,r4),r4
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[5]);  // 060AE5C0 mov.w @(r0,r5),r5
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]); c.r[2] += 1;  // 060AE5C2 mov.b @r2+,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]); c.r[2] += 1;  // 060AE5C4 mov.b @r2+,r1
    c.r[4] = c.r[4] & 0xFFFFu;  // 060AE5C6 extu.w r4,r4
    c.r[5] = c.r[5] & 0xFFFFu;  // 060AE5C8 extu.w r5,r5
    c.r[4] += 2;  // 060AE5CA add #2,r4
    c.r[5] += 2;  // 060AE5CC add #2,r5
    c.r[4] ^= c.r[0];  // 060AE5CE xor r0,r4
    c.r[5] ^= c.r[1];  // 060AE5D0 xor r1,r5
    st32(c.r[9] + 28, c.r[4]);  // 060AE5D2 mov.l r4,@(28,r9)
    st32(c.r[9] + 32, c.r[5]);  // 060AE5D4 mov.l r5,@(32,r9)
    c.r[0] = 0x18u;  // 060AE5D6 mov #24,r0
    st32(c.r[9], c.r[0]);  // 060AE5D8 mov.l r0,@(0,r9)
    c.r[0] = 0x24u; goto L_060AE5E4;  // 060AE5DA bra 0x060AE5E4 ; mov #36,r0
L_060AE5DE:
    c.r[0] = 0x1Cu;  // 060AE5DE mov #28,r0
    st32(c.r[9], c.r[0]);  // 060AE5E0 mov.l r0,@(0,r9)
    c.r[0] = 0x1Cu;  // 060AE5E2 mov #28,r0
L_060AE5E4:
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060AE5E4 mov.l @r15+,r8
    c.r[0] += c.r[9];  // 060AE5E6 add r9,r0
    c.r[1] = ld32(0x060AE5F8u);  // 060AE5E8 mov.l 0x060AE5F8,r1
    st32(c.gbr + 72, c.r[0]);  // 060AE5EA mov.l r0,@(72,gbr)
    st16(c.r[1], c.r[0]);  // 060AE5EC mov.w r0,@r1
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060AE5EE mov.l @r15+,r9
L_060AE5F0:
    c.r[0] = 0x1u;  // 060AE5F0 mov #1,r0
    { const uint32_t x = c.pr; st8(c.gbr + 115, c.r[0]); c.pc = x; return; }  // 060AE5F2 rts ; mov.b r0,@(115,gbr)
}

void f_060AE614(SH2Context& c) {
    ran[2967] = 1;
L_060AE614:
    c.r[0] = ld32(0x060AE658u);  // 060AE614 mov.l 0x060AE658,r0
L_060AE616:
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060AE616 sts.l pr,@-r15
L_060AE618:
    { const uint32_t x = c.r[0]; c.pr = 0x060AE61Cu; c.r[2] = ld32(c.r[4] + 8); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AE61Cu) return; }  // 060AE618 jsr @r0 ; mov.l @(8,r4),r2
L_060AE61C:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060AE61C lds.l @r15+,pr
L_060AE61E:
    c.r[0] = ld32(c.gbr + 48);  // 060AE61E mov.l @(48,gbr),r0
L_060AE620:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[5]); c.r[5] += 2;  // 060AE620 mov.w @r5+,r1
L_060AE622:
    c.r[7] = c.r[0];  // 060AE622 mov r0,r7
L_060AE624:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[5] + 4);  // 060AE624 mov.w @(4,r5),r0
L_060AE626:
    c.r[1] <<= 2;  // 060AE626 shll2 r1
L_060AE628:
    c.r[2] = c.r[0] << 16 | c.r[2] >> 16;  // 060AE628 xtrct r0,r2
L_060AE62A:
    st32(c.r[7] + 28, c.r[2]);  // 060AE62A mov.l r2,@(28,r7)
L_060AE62C:
    c.r[0] = ld32(c.gbr + 60);  // 060AE62C mov.l @(60,gbr),r0
L_060AE62E:
    c.t = c.r[1] >> 31; c.r[1] <<= 1;  // 060AE62E shll r1
L_060AE630:
    c.r[1] += c.r[0];  // 060AE630 add r0,r1
L_060AE632:
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 060AE632 mov.w @r1+,r2
L_060AE634:
    c.r[0] = ld32(c.r[4] + 12);  // 060AE634 mov.l @(12,r4),r0
L_060AE636:
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 060AE636 mov.w @r1+,r3
L_060AE638:
    c.macl = c.r[2] * c.r[0];  // 060AE638 mul.l r0,r2
L_060AE63A:
    c.r[0] = ld32(c.r[4] + 16);  // 060AE63A mov.l @(16,r4),r0
L_060AE63C:
    c.r[1] = ld32(c.r[1]);  // 060AE63C mov.l @r1,r1
L_060AE63E:
    c.r[2] = c.macl;  // 060AE63E sts macl,r2
L_060AE640:
    c.macl = c.r[3] * c.r[0];  // 060AE640 mul.l r0,r3
L_060AE642:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[5]); c.r[5] += 2;  // 060AE642 mov.w @r5+,r0
L_060AE644:
    st32(c.r[7] + 8, c.r[1]);  // 060AE644 mov.l r1,@(8,r7)
L_060AE646:
    c.r[3] = c.macl;  // 060AE646 sts macl,r3
L_060AE648:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[5]); c.r[5] += 2;  // 060AE648 mov.w @r5+,r1
L_060AE64A:
    c.r[5] += 2;  // 060AE64A add #2,r5
L_060AE64C:
    c.r[1] <<= 16;  // 060AE64C shll16 r1
L_060AE64E:
    c.r[1] = c.r[0] << 16 | c.r[1] >> 16;  // 060AE64E xtrct r0,r1
L_060AE650:
    c.r[0] = ld32(0x060AE65Cu);  // 060AE650 mov.l 0x060AE65C,r0
L_060AE652:
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[5]);  // 060AE652 mov.w @r5,r5
L_060AE654:
    { const uint32_t x = c.r[0]; st32(c.r[7] + 4, c.r[1]); SH2_POLL(c); switch (x) { case 0x060AE614u: goto L_060AE614; case 0x060AE616u: goto L_060AE616; case 0x060AE618u: goto L_060AE618; case 0x060AE61Cu: goto L_060AE61C; case 0x060AE61Eu: goto L_060AE61E; case 0x060AE620u: goto L_060AE620; case 0x060AE622u: goto L_060AE622; case 0x060AE624u: goto L_060AE624; case 0x060AE626u: goto L_060AE626; case 0x060AE628u: goto L_060AE628; case 0x060AE62Au: goto L_060AE62A; case 0x060AE62Cu: goto L_060AE62C; case 0x060AE62Eu: goto L_060AE62E; case 0x060AE630u: goto L_060AE630; case 0x060AE632u: goto L_060AE632; case 0x060AE634u: goto L_060AE634; case 0x060AE636u: goto L_060AE636; case 0x060AE638u: goto L_060AE638; case 0x060AE63Au: goto L_060AE63A; case 0x060AE63Cu: goto L_060AE63C; case 0x060AE63Eu: goto L_060AE63E; case 0x060AE640u: goto L_060AE640; case 0x060AE642u: goto L_060AE642; case 0x060AE644u: goto L_060AE644; case 0x060AE646u: goto L_060AE646; case 0x060AE648u: goto L_060AE648; case 0x060AE64Au: goto L_060AE64A; case 0x060AE64Cu: goto L_060AE64C; case 0x060AE64Eu: goto L_060AE64E; case 0x060AE650u: goto L_060AE650; case 0x060AE652u: goto L_060AE652; case 0x060AE654u: goto L_060AE654; case 0x060B64A0u: goto L_060B64A0; case 0x060B64A2u: goto L_060B64A2; case 0x060B64A4u: goto L_060B64A4; case 0x060B64A6u: goto L_060B64A6; case 0x060B64A8u: goto L_060B64A8; case 0x060B64AAu: goto L_060B64AA; case 0x060B64ACu: goto L_060B64AC; case 0x060B64AEu: goto L_060B64AE; case 0x060B64B2u: goto L_060B64B2; case 0x060B64B4u: goto L_060B64B4; case 0x060B64B6u: goto L_060B64B6; case 0x060B64B8u: goto L_060B64B8; case 0x060B64BAu: goto L_060B64BA; case 0x060B64BCu: goto L_060B64BC; case 0x060B64BEu: goto L_060B64BE; case 0x060B64C2u: goto L_060B64C2; case 0x060B64C4u: goto L_060B64C4; case 0x060B64C6u: goto L_060B64C6; case 0x060B64CAu: goto L_060B64CA; case 0x060B64CCu: goto L_060B64CC; case 0x060B64CEu: goto L_060B64CE; case 0x060B64D0u: goto L_060B64D0; case 0x060B64D2u: goto L_060B64D2; case 0x060B64D6u: goto L_060B64D6; case 0x060B64D8u: goto L_060B64D8; case 0x060B64DAu: goto L_060B64DA; case 0x060B64DCu: goto L_060B64DC; case 0x060B64DEu: goto L_060B64DE; case 0x060B64E2u: goto L_060B64E2; case 0x060B64E4u: goto L_060B64E4; case 0x060B64E6u: goto L_060B64E6; case 0x060B64EAu: goto L_060B64EA; case 0x060B64ECu: goto L_060B64EC; case 0x060B64EEu: goto L_060B64EE; case 0x060B64F0u: goto L_060B64F0; case 0x060B64F2u: goto L_060B64F2; case 0x060B64F4u: goto L_060B64F4; case 0x060B64F6u: goto L_060B64F6; case 0x060B64F8u: goto L_060B64F8; case 0x060B64FAu: goto L_060B64FA; case 0x060B64FCu: goto L_060B64FC; case 0x060B64FEu: goto L_060B64FE; case 0x060B6500u: goto L_060B6500; case 0x060B6502u: goto L_060B6502; case 0x060B6504u: goto L_060B6504; case 0x060B6506u: goto L_060B6506; case 0x060B6508u: goto L_060B6508; case 0x060B650Au: goto L_060B650A; case 0x060B650Cu: goto L_060B650C; case 0x060B650Eu: goto L_060B650E; case 0x060B6510u: goto L_060B6510; case 0x060B6512u: goto L_060B6512; case 0x060B6514u: goto L_060B6514; case 0x060B6516u: goto L_060B6516; case 0x060B6518u: goto L_060B6518; case 0x060B651Au: goto L_060B651A; case 0x060B651Cu: goto L_060B651C; case 0x060B651Eu: goto L_060B651E; case 0x060B6520u: goto L_060B6520; case 0x060B6524u: goto L_060B6524; case 0x060B6528u: goto L_060B6528; case 0x060B652Au: goto L_060B652A; case 0x060B652Eu: goto L_060B652E; case 0x060B6530u: goto L_060B6530; case 0x060B6532u: goto L_060B6532; case 0x060B6534u: goto L_060B6534; case 0x060B6536u: goto L_060B6536; case 0x060B6538u: goto L_060B6538; case 0x060B653Au: goto L_060B653A; case 0x060B653Cu: goto L_060B653C; case 0x060B653Eu: goto L_060B653E; case 0x060B6540u: goto L_060B6540; case 0x060B6542u: goto L_060B6542; case 0x060B6544u: goto L_060B6544; case 0x060B6546u: goto L_060B6546; case 0x060B6548u: goto L_060B6548; case 0x060B654Au: goto L_060B654A; case 0x060B654Cu: goto L_060B654C; case 0x060B654Eu: goto L_060B654E; case 0x060B6550u: goto L_060B6550; case 0x060B6552u: goto L_060B6552; case 0x060B6554u: goto L_060B6554; case 0x060B6556u: goto L_060B6556; case 0x060B6558u: goto L_060B6558; case 0x060B655Au: goto L_060B655A; case 0x060B655Cu: goto L_060B655C; case 0x060B655Eu: goto L_060B655E; case 0x060B6560u: goto L_060B6560; case 0x060B6562u: goto L_060B6562; case 0x060B6564u: goto L_060B6564; case 0x060B6566u: goto L_060B6566; case 0x060B6568u: goto L_060B6568; case 0x060B656Au: goto L_060B656A; case 0x060B656Cu: goto L_060B656C; case 0x060B656Eu: goto L_060B656E; case 0x060B6570u: goto L_060B6570; case 0x060B6572u: goto L_060B6572; case 0x060B6574u: goto L_060B6574; case 0x060B6576u: goto L_060B6576; case 0x060B6578u: goto L_060B6578; case 0x060B657Au: goto L_060B657A; case 0x060B657Cu: goto L_060B657C; case 0x060B657Eu: goto L_060B657E; case 0x060B6580u: goto L_060B6580; case 0x060B6582u: goto L_060B6582; case 0x060B6584u: goto L_060B6584; case 0x060B6586u: goto L_060B6586; case 0x060B6588u: goto L_060B6588; case 0x060B658Au: goto L_060B658A; case 0x060B658Cu: goto L_060B658C; case 0x060B658Eu: goto L_060B658E; case 0x060B6590u: goto L_060B6590; case 0x060B6592u: goto L_060B6592; case 0x060B6594u: goto L_060B6594; case 0x060B6596u: goto L_060B6596; case 0x060B6598u: goto L_060B6598; case 0x060B659Au: goto L_060B659A; case 0x060B659Cu: goto L_060B659C; case 0x060B659Eu: goto L_060B659E; case 0x060B65A0u: goto L_060B65A0; case 0x060B65A2u: goto L_060B65A2; case 0x060B65A4u: goto L_060B65A4; case 0x060B65A6u: goto L_060B65A6; case 0x060B65A8u: goto L_060B65A8; case 0x060B65AAu: goto L_060B65AA; case 0x060B65ACu: goto L_060B65AC; case 0x060B65AEu: goto L_060B65AE; case 0x060B65B0u: goto L_060B65B0; case 0x060B65B4u: goto L_060B65B4; case 0x060B65B6u: goto L_060B65B6; case 0x060B65B8u: goto L_060B65B8; case 0x060B65BAu: goto L_060B65BA; case 0x060B65BCu: goto L_060B65BC; case 0x060B65BEu: goto L_060B65BE; case 0x060B65C0u: goto L_060B65C0; case 0x060B65C2u: goto L_060B65C2; case 0x060B65C4u: goto L_060B65C4; case 0x060B65C6u: goto L_060B65C6; case 0x060B65C8u: goto L_060B65C8; case 0x060B65CAu: goto L_060B65CA; case 0x060B65CEu: goto L_060B65CE; case 0x060B65D0u: goto L_060B65D0; case 0x060B65D2u: goto L_060B65D2; case 0x060B65D4u: goto L_060B65D4; case 0x060B65D6u: goto L_060B65D6; case 0x060B65DAu: goto L_060B65DA; case 0x060B65DCu: goto L_060B65DC; case 0x060B65DEu: goto L_060B65DE; case 0x060B65E2u: goto L_060B65E2; case 0x060B65E4u: goto L_060B65E4; case 0x060B65E6u: goto L_060B65E6; case 0x060B65E8u: goto L_060B65E8; case 0x060B65ECu: goto L_060B65EC; case 0x060B65EEu: goto L_060B65EE; case 0x060B65F0u: goto L_060B65F0; case 0x060B65F4u: goto L_060B65F4; case 0x060B65F6u: goto L_060B65F6; case 0x060B65F8u: goto L_060B65F8; case 0x060B65FAu: goto L_060B65FA; case 0x060B65FEu: goto L_060B65FE; case 0x060B6600u: goto L_060B6600; case 0x060B6602u: goto L_060B6602; case 0x060B6606u: goto L_060B6606; case 0x060B6608u: goto L_060B6608; case 0x060B660Au: goto L_060B660A; case 0x060B660Cu: goto L_060B660C; case 0x060B6610u: goto L_060B6610; case 0x060B6612u: goto L_060B6612; case 0x060B6614u: goto L_060B6614; case 0x060B6616u: goto L_060B6616; case 0x060B6618u: goto L_060B6618; case 0x060B661Au: goto L_060B661A; case 0x060B661Cu: goto L_060B661C; case 0x060B661Eu: goto L_060B661E; case 0x060B6620u: goto L_060B6620; case 0x060B6622u: goto L_060B6622; case 0x060B6624u: goto L_060B6624; case 0x060B6626u: goto L_060B6626; case 0x060B6628u: goto L_060B6628; case 0x060B662Au: goto L_060B662A; case 0x060B662Cu: goto L_060B662C; case 0x060B662Eu: goto L_060B662E; case 0x060B6630u: goto L_060B6630; case 0x060B6632u: goto L_060B6632; case 0x060B6634u: goto L_060B6634; case 0x060B6636u: goto L_060B6636; case 0x060B6638u: goto L_060B6638; case 0x060B663Au: goto L_060B663A; case 0x060B663Cu: goto L_060B663C; case 0x060B663Eu: goto L_060B663E; case 0x060B6640u: goto L_060B6640; case 0x060B6642u: goto L_060B6642; case 0x060B6644u: goto L_060B6644; case 0x060B6648u: goto L_060B6648; case 0x060B664Au: goto L_060B664A; case 0x060B664Cu: goto L_060B664C; case 0x060B664Eu: goto L_060B664E; case 0x060B6650u: goto L_060B6650; case 0x060B6652u: goto L_060B6652; case 0x060B6654u: goto L_060B6654; case 0x060B6656u: goto L_060B6656; case 0x060B6658u: goto L_060B6658; case 0x060B665Au: goto L_060B665A; case 0x060B665Cu: goto L_060B665C; case 0x060B665Eu: goto L_060B665E; case 0x060B6660u: goto L_060B6660; case 0x060B6662u: goto L_060B6662; case 0x060B6666u: goto L_060B6666; case 0x060B6668u: goto L_060B6668; case 0x060B666Au: goto L_060B666A; case 0x060B666Cu: goto L_060B666C; case 0x060B666Eu: goto L_060B666E; case 0x060B6670u: goto L_060B6670; case 0x060B6672u: goto L_060B6672; case 0x060B6674u: goto L_060B6674; case 0x060B6676u: goto L_060B6676; case 0x060B6678u: goto L_060B6678; case 0x060B667Au: goto L_060B667A; case 0x060B667Cu: goto L_060B667C; case 0x060B667Eu: goto L_060B667E; case 0x060B6680u: goto L_060B6680; case 0x060B6684u: goto L_060B6684; case 0x060B6686u: goto L_060B6686; case 0x060B6688u: goto L_060B6688; case 0x060B668Au: goto L_060B668A; case 0x060B668Cu: goto L_060B668C; case 0x060B668Eu: goto L_060B668E; case 0x060B6690u: goto L_060B6690; case 0x060B6694u: goto L_060B6694; case 0x060B6696u: goto L_060B6696; case 0x060B6698u: goto L_060B6698; case 0x060B669Au: goto L_060B669A; case 0x060B669Cu: goto L_060B669C; case 0x060B669Eu: goto L_060B669E; case 0x060B66A0u: goto L_060B66A0; case 0x060B66A4u: goto L_060B66A4; case 0x060B66A6u: goto L_060B66A6; case 0x060B66A8u: goto L_060B66A8; case 0x060B66AAu: goto L_060B66AA; case 0x060B66ACu: goto L_060B66AC; case 0x060B66AEu: goto L_060B66AE; case 0x060B66B0u: goto L_060B66B0; case 0x060B66B4u: goto L_060B66B4; case 0x060B66B6u: goto L_060B66B6; case 0x060B66B8u: goto L_060B66B8; case 0x060B66BAu: goto L_060B66BA; case 0x060B66BCu: goto L_060B66BC; case 0x060B66BEu: goto L_060B66BE; case 0x060B66C0u: goto L_060B66C0; case 0x060B66C2u: goto L_060B66C2; case 0x060B66C4u: goto L_060B66C4; case 0x060B66C6u: goto L_060B66C6; case 0x060B66C8u: goto L_060B66C8; case 0x060B66CAu: goto L_060B66CA; case 0x060B66CCu: goto L_060B66CC; case 0x060B66CEu: goto L_060B66CE; case 0x060B66D0u: goto L_060B66D0; case 0x060B66D2u: goto L_060B66D2; case 0x060B66D4u: goto L_060B66D4; case 0x060B66D6u: goto L_060B66D6; case 0x060B66D8u: goto L_060B66D8; case 0x060B66DAu: goto L_060B66DA; case 0x060B66DCu: goto L_060B66DC; case 0x060B66DEu: goto L_060B66DE; case 0x060B66E0u: goto L_060B66E0; case 0x060B66E2u: goto L_060B66E2; case 0x060B66E4u: goto L_060B66E4; case 0x060B66E6u: goto L_060B66E6; case 0x060B66E8u: goto L_060B66E8; case 0x060B6748u: goto L_060B6748; case 0x060B674Au: goto L_060B674A; case 0x060B674Cu: goto L_060B674C; case 0x060B674Eu: goto L_060B674E; case 0x060B6750u: goto L_060B6750; case 0x060B6752u: goto L_060B6752; case 0x060B6754u: goto L_060B6754; case 0x060B6756u: goto L_060B6756; case 0x060B6758u: goto L_060B6758; case 0x060B675Au: goto L_060B675A; case 0x060B675Cu: goto L_060B675C; case 0x060B675Eu: goto L_060B675E; case 0x060B6760u: goto L_060B6760; case 0x060B6762u: goto L_060B6762; case 0x060B6764u: goto L_060B6764; case 0x060B6768u: goto L_060B6768; case 0x060B676Au: goto L_060B676A; case 0x060B676Cu: goto L_060B676C; case 0x060B676Eu: goto L_060B676E; case 0x060B6770u: goto L_060B6770; case 0x060B6772u: goto L_060B6772; case 0x060B6774u: goto L_060B6774; case 0x060B6776u: goto L_060B6776; case 0x060B6778u: goto L_060B6778; case 0x060B677Cu: goto L_060B677C; case 0x060B677Eu: goto L_060B677E; case 0x060B6780u: goto L_060B6780; case 0x060B6782u: goto L_060B6782; case 0x060B6784u: goto L_060B6784; case 0x060B6788u: goto L_060B6788; case 0x060B678Au: goto L_060B678A; case 0x060B678Cu: goto L_060B678C; case 0x060B678Eu: goto L_060B678E; case 0x060B6790u: goto L_060B6790; case 0x060B6792u: goto L_060B6792; case 0x060B6796u: goto L_060B6796; case 0x060B6798u: goto L_060B6798; case 0x060B679Au: goto L_060B679A; case 0x060B679Cu: goto L_060B679C; case 0x060B679Eu: goto L_060B679E; case 0x060B67A0u: goto L_060B67A0; case 0x060B67A2u: goto L_060B67A2; case 0x060B67A4u: goto L_060B67A4; case 0x060B67A8u: goto L_060B67A8; case 0x060B67AAu: goto L_060B67AA; case 0x060B67ACu: goto L_060B67AC; case 0x060B67AEu: goto L_060B67AE; case 0x060B67B2u: goto L_060B67B2; case 0x060B67B4u: goto L_060B67B4; case 0x060B67B6u: goto L_060B67B6; case 0x060B67B8u: goto L_060B67B8; case 0x060B67BCu: goto L_060B67BC; case 0x060B67BEu: goto L_060B67BE; case 0x060B67C0u: goto L_060B67C0; case 0x060B67C2u: goto L_060B67C2; case 0x060B67C6u: goto L_060B67C6; case 0x060B67CAu: goto L_060B67CA; case 0x060B67CCu: goto L_060B67CC; case 0x060B67CEu: goto L_060B67CE; case 0x060B67D2u: goto L_060B67D2; case 0x060B67D4u: goto L_060B67D4; case 0x060B67D6u: goto L_060B67D6; case 0x060B67DAu: goto L_060B67DA; case 0x060B67DCu: goto L_060B67DC; case 0x060B67DEu: goto L_060B67DE; case 0x060B67E0u: goto L_060B67E0; case 0x060B67E2u: goto L_060B67E2; case 0x060B67E4u: goto L_060B67E4; case 0x060B67E6u: goto L_060B67E6; case 0x060B67E8u: goto L_060B67E8; case 0x060B67ECu: goto L_060B67EC; case 0x060B67EEu: goto L_060B67EE; case 0x060B67F0u: goto L_060B67F0; case 0x060B67F4u: goto L_060B67F4; case 0x060B67F6u: goto L_060B67F6; case 0x060B67F8u: goto L_060B67F8; case 0x060B67FAu: goto L_060B67FA; case 0x060B67FCu: goto L_060B67FC; case 0x060B6800u: goto L_060B6800; case 0x060B6802u: goto L_060B6802; case 0x060B6804u: goto L_060B6804; case 0x060B6806u: goto L_060B6806; case 0x060B6808u: goto L_060B6808; case 0x060B680Au: goto L_060B680A; case 0x060B680Eu: goto L_060B680E; case 0x060B6810u: goto L_060B6810; case 0x060B6812u: goto L_060B6812; case 0x060B6814u: goto L_060B6814; case 0x060B6816u: goto L_060B6816; case 0x060B6818u: goto L_060B6818; case 0x060B681Au: goto L_060B681A; case 0x060B681Cu: goto L_060B681C; case 0x060B6820u: goto L_060B6820; case 0x060B6822u: goto L_060B6822; case 0x060B6824u: goto L_060B6824; case 0x060B6826u: goto L_060B6826; case 0x060B682Au: goto L_060B682A; case 0x060B682Cu: goto L_060B682C; case 0x060B682Eu: goto L_060B682E; case 0x060B6830u: goto L_060B6830; case 0x060B6834u: goto L_060B6834; case 0x060B6836u: goto L_060B6836; case 0x060B6838u: goto L_060B6838; case 0x060B683Au: goto L_060B683A; case 0x060B683Eu: goto L_060B683E; case 0x060B6842u: goto L_060B6842; case 0x060B6844u: goto L_060B6844; case 0x060B6846u: goto L_060B6846; case 0x060B6848u: goto L_060B6848; case 0x060B684Au: goto L_060B684A; case 0x060B684Cu: goto L_060B684C; case 0x060B684Eu: goto L_060B684E; case 0x060B6850u: goto L_060B6850; case 0x060B6854u: goto L_060B6854; case 0x060B6856u: goto L_060B6856; case 0x060B6858u: goto L_060B6858; case 0x060B685Au: goto L_060B685A; case 0x060B685Cu: goto L_060B685C; case 0x060B685Eu: goto L_060B685E; case 0x060B6860u: goto L_060B6860; case 0x060B6862u: goto L_060B6862; case 0x060B6864u: goto L_060B6864; case 0x060B6866u: goto L_060B6866; case 0x060B6868u: goto L_060B6868; case 0x060B686Cu: goto L_060B686C; case 0x060B686Eu: goto L_060B686E; case 0x060B6870u: goto L_060B6870; case 0x060B6872u: goto L_060B6872; case 0x060B6874u: goto L_060B6874; case 0x060B6876u: goto L_060B6876; case 0x060B687Au: goto L_060B687A; case 0x060B687Cu: goto L_060B687C; case 0x060B687Eu: goto L_060B687E; case 0x060B6880u: goto L_060B6880; case 0x060B6882u: goto L_060B6882; case 0x060B6886u: goto L_060B6886; case 0x060B6888u: goto L_060B6888; case 0x060B688Au: goto L_060B688A; case 0x060B688Cu: goto L_060B688C; case 0x060B688Eu: goto L_060B688E; case 0x060B6890u: goto L_060B6890; case 0x060B6894u: goto L_060B6894; case 0x060B6896u: goto L_060B6896; case 0x060B6898u: goto L_060B6898; case 0x060B689Au: goto L_060B689A; case 0x060B689Cu: goto L_060B689C; case 0x060B689Eu: goto L_060B689E; case 0x060B68A0u: goto L_060B68A0; case 0x060B68A2u: goto L_060B68A2; case 0x060B68A6u: goto L_060B68A6; case 0x060B68A8u: goto L_060B68A8; case 0x060B68AAu: goto L_060B68AA; case 0x060B68ACu: goto L_060B68AC; case 0x060B68B0u: goto L_060B68B0; case 0x060B68B2u: goto L_060B68B2; case 0x060B68B4u: goto L_060B68B4; case 0x060B68B6u: goto L_060B68B6; case 0x060B68BAu: goto L_060B68BA; case 0x060B68BCu: goto L_060B68BC; case 0x060B68BEu: goto L_060B68BE; case 0x060B68C0u: goto L_060B68C0; case 0x060B68C4u: goto L_060B68C4; case 0x060B68C8u: goto L_060B68C8; case 0x060B68CAu: goto L_060B68CA; case 0x060B68CCu: goto L_060B68CC; case 0x060B68CEu: goto L_060B68CE; case 0x060B68D0u: goto L_060B68D0; case 0x060B68D2u: goto L_060B68D2; case 0x060B68D4u: goto L_060B68D4; case 0x060B68D6u: goto L_060B68D6; case 0x060B68D8u: goto L_060B68D8; case 0x060B68DAu: goto L_060B68DA; case 0x060B68DCu: goto L_060B68DC; case 0x060B68E0u: goto L_060B68E0; case 0x060B68E2u: goto L_060B68E2; case 0x060B68E4u: goto L_060B68E4; case 0x060B68E6u: goto L_060B68E6; case 0x060B68E8u: goto L_060B68E8; case 0x060B68EAu: goto L_060B68EA; case 0x060B68EEu: goto L_060B68EE; case 0x060B68F0u: goto L_060B68F0; case 0x060B68F2u: goto L_060B68F2; case 0x060B68F4u: goto L_060B68F4; case 0x060B68F6u: goto L_060B68F6; case 0x060B68FAu: goto L_060B68FA; case 0x060B68FCu: goto L_060B68FC; case 0x060B68FEu: goto L_060B68FE; case 0x060B6900u: goto L_060B6900; case 0x060B6902u: goto L_060B6902; case 0x060B6904u: goto L_060B6904; case 0x060B6908u: goto L_060B6908; case 0x060B690Au: goto L_060B690A; case 0x060B690Cu: goto L_060B690C; case 0x060B690Eu: goto L_060B690E; case 0x060B6910u: goto L_060B6910; case 0x060B6912u: goto L_060B6912; case 0x060B6914u: goto L_060B6914; case 0x060B6916u: goto L_060B6916; case 0x060B691Au: goto L_060B691A; case 0x060B691Cu: goto L_060B691C; case 0x060B691Eu: goto L_060B691E; case 0x060B6920u: goto L_060B6920; case 0x060B6924u: goto L_060B6924; case 0x060B6926u: goto L_060B6926; case 0x060B6928u: goto L_060B6928; case 0x060B692Au: goto L_060B692A; case 0x060B692Eu: goto L_060B692E; case 0x060B6930u: goto L_060B6930; case 0x060B6932u: goto L_060B6932; case 0x060B6934u: goto L_060B6934; case 0x060B6938u: goto L_060B6938; case 0x060B693Cu: goto L_060B693C; case 0x060B693Eu: goto L_060B693E; case 0x060B6940u: goto L_060B6940; case 0x060B6942u: goto L_060B6942; case 0x060B6944u: goto L_060B6944; case 0x060B6946u: goto L_060B6946; case 0x060B6948u: goto L_060B6948; case 0x060B694Au: goto L_060B694A; default: sh2_call(c, x); return; } }  // 060AE654 jmp @r0 ; mov.l r1,@(4,r7)
L_060B64A0:
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[4]);  // 060B64A0 mov.w @r4,r6
L_060B64A2:
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 152);  // 060B64A2 mov.w @(152,gbr),r0
L_060B64A4:
    c.r[1] = c.r[6];  // 060B64A4 mov r6,r1
L_060B64A6:
    c.r[1] += c.r[0];  // 060B64A6 add r0,r1
L_060B64A8:
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 140);  // 060B64A8 mov.w @(140,gbr),r0
L_060B64AA:
    c.r[4] = ld32(c.r[4] + 4);  // 060B64AA mov.l @(4,r4),r4
L_060B64AC:
    c.t = c.r[1] > c.r[0];  // 060B64AC cmp/hi r0,r1
L_060B64AE:
    { const bool k = c.t; c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 154); if (k) { goto L_060B6524; } }  // 060B64AE bt/s 0x060B6524 ; mov.w @(154,gbr),r0
L_060B64B2:
    c.r[1] = c.r[4];  // 060B64B2 mov r4,r1
L_060B64B4:
    c.r[0] <<= 16;  // 060B64B4 shll16 r0
L_060B64B6:
    c.r[1] += c.r[0];  // 060B64B6 add r0,r1
L_060B64B8:
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 142);  // 060B64B8 mov.w @(142,gbr),r0
L_060B64BA:
    c.r[0] <<= 16;  // 060B64BA shll16 r0
L_060B64BC:
    c.t = c.r[1] > c.r[0];  // 060B64BC cmp/hi r0,r1
L_060B64BE:
    { const bool k = c.t; c.r[0] = 0x3u; if (k) { goto L_060B6524; } }  // 060B64BE bt/s 0x060B6524 ; mov #3,r0
L_060B64C2:
    c.r[5] ^= c.r[0];  // 060B64C2 xor r0,r5
L_060B64C4:
    c.t = (int32_t)c.r[2] >= 0;  // 060B64C4 cmp/pz r2
L_060B64C6:
    { const bool k = c.t; c.r[1] = 0x1u; if (k) { goto L_060B64D0; } }  // 060B64C6 bt/s 0x060B64D0 ; mov #1,r1
L_060B64CA:
    c.r[2] = 0u - c.r[2];  // 060B64CA neg r2,r2
L_060B64CC:
    c.r[0] = 0x10u;  // 060B64CC mov #16,r0
L_060B64CE:
    c.r[5] ^= c.r[0];  // 060B64CE xor r0,r5
L_060B64D0:
    c.t = (int32_t)c.r[3] >= 0;  // 060B64D0 cmp/pz r3
L_060B64D2:
    { const bool k = c.t; c.r[1] <<= 16; if (k) { goto L_060B64DC; } }  // 060B64D2 bt/s 0x060B64DC ; shll16 r1
L_060B64D6:
    c.r[3] = 0u - c.r[3];  // 060B64D6 neg r3,r3
L_060B64D8:
    c.r[0] = 0x20u;  // 060B64D8 mov #32,r0
L_060B64DA:
    c.r[5] ^= c.r[0];  // 060B64DA xor r0,r5
L_060B64DC:
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[1];  // 060B64DC cmp/ge r1,r2
L_060B64DE:
    { const bool k = c.t; c.r[2] -= c.r[1]; if (k) { goto L_060B64E4; } }  // 060B64DE bt/s 0x060B64E4 ; sub r1,r2
L_060B64E2:
    c.r[2] = 0x0u;  // 060B64E2 mov #0,r2
L_060B64E4:
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[1];  // 060B64E4 cmp/ge r1,r3
L_060B64E6:
    { const bool k = c.t; c.r[3] -= c.r[1]; if (k) { goto L_060B64EC; } }  // 060B64E6 bt/s 0x060B64EC ; sub r1,r3
L_060B64EA:
    c.r[3] = 0x0u;  // 060B64EA mov #0,r3
L_060B64EC:
    c.r[2] = c.r[2] << 16 | c.r[2] >> 16;  // 060B64EC swap.w r2,r2
L_060B64EE:
    c.r[3] = c.r[2] << 16 | c.r[3] >> 16;  // 060B64EE xtrct r2,r3
L_060B64F0:
    st32(c.r[7] + 16, c.r[3]);  // 060B64F0 mov.l r3,@(16,r7)
L_060B64F2:
    c.r[0] = (c.r[5] & 0xFFFF0000u) | (c.r[5] & 0xFFu) << 8 | (c.r[5] >> 8 & 0xFFu);  // 060B64F2 swap.b r5,r0
L_060B64F4:
    c.t = (c.r[0] & 0xFu) == 0;  // 060B64F4 tst #15,r0
L_060B64F6:
    if (!c.t) { goto L_060B64FA; }  // 060B64F6 bf 0x060B64FA
L_060B64F8:
    c.r[0] |= 0xAu;  // 060B64F8 or #10,r0
L_060B64FA:
    c.r[0] = (c.r[0] & 0xFFFF0000u) | (c.r[0] & 0xFFu) << 8 | (c.r[0] >> 8 & 0xFFu);  // 060B64FA swap.b r0,r0
L_060B64FC:
    st16(c.r[7], c.r[0]);  // 060B64FC mov.w r0,@(0,r7)
L_060B64FE:
    c.r[4] = c.r[6] << 16 | c.r[4] >> 16;  // 060B64FE xtrct r6,r4
L_060B6500:
    st32(c.r[7] + 12, c.r[4]);  // 060B6500 mov.l r4,@(12,r7)
L_060B6502:
    c.r[0] = ld32(c.gbr + 72);  // 060B6502 mov.l @(72,gbr),r0
L_060B6504:
    c.r[1] = 0x28u;  // 060B6504 mov #40,r1
L_060B6506:
    st32(c.r[0], c.r[1]);  // 060B6506 mov.l r1,@(0,r0)
L_060B6508:
    st32(c.r[0] + 4, c.r[7]);  // 060B6508 mov.l r7,@(4,r0)
L_060B650A:
    c.r[1] = 0x1u;  // 060B650A mov #1,r1
L_060B650C:
    st32(c.r[0] + 8, c.r[1]);  // 060B650C mov.l r1,@(8,r0)
L_060B650E:
    c.r[1] = 0x0u;  // 060B650E mov #0,r1
L_060B6510:
    st32(c.r[0] + 12, c.r[1]);  // 060B6510 mov.l r1,@(12,r0)
L_060B6512:
    c.r[0] += 16;  // 060B6512 add #16,r0
L_060B6514:
    c.r[1] = ld32(0x060B6704u);  // 060B6514 mov.l 0x060B6704,r1
L_060B6516:
    st32(c.gbr + 72, c.r[0]);  // 060B6516 mov.l r0,@(72,gbr)
L_060B6518:
    st16(c.r[1], c.r[0]);  // 060B6518 mov.w r0,@r1
L_060B651A:
    c.r[7] -= 36;  // 060B651A add #-36,r7
L_060B651C:
    c.r[0] = c.r[7];  // 060B651C mov r7,r0
L_060B651E:
    st32(c.gbr + 48, c.r[0]);  // 060B651E mov.l r0,@(48,gbr)
L_060B6520:
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 060B6520 rts ; mov #1,r0
L_060B6524:
    { const uint32_t x = c.pr; c.r[0] = 0x0u; c.pc = x; return; }  // 060B6524 rts ; mov #0,r0
L_060B6528:
    c.t = (c.r[6] & c.r[6]) == 0;  // 060B6528 tst r6,r6
L_060B652A:
    { const bool k = c.t; c.r[0] = (c.r[6] & 0xFFFF0000u) | (c.r[6] & 0xFFu) << 8 | (c.r[6] >> 8 & 0xFFu); if (k) { SH2_POLL(c); goto L_060B64A0; } }  // 060B652A bt/s 0x060B64A0 ; swap.b r6,r0
L_060B652E:
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060B652E mov.l r14,@-r15
L_060B6530:
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060B6530 mov.l r13,@-r15
L_060B6532:
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060B6532 mov.l r12,@-r15
L_060B6534:
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060B6534 mov.l r11,@-r15
L_060B6536:
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060B6536 mov.l r10,@-r15
L_060B6538:
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060B6538 mov.l r9,@-r15
L_060B653A:
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060B653A mov.l r8,@-r15
L_060B653C:
    c.r[0] >>= 2;  // 060B653C shlr2 r0
L_060B653E:
    c.r[0] >>= 2;  // 060B653E shlr2 r0
L_060B6540:
    c.r[8] = 0xCu;  // 060B6540 mov #12,r8
L_060B6542:
    c.r[8] &= c.r[0];  // 060B6542 and r0,r8
L_060B6544:
    c.r[0] = 0x060B66F4u;  // 060B6544 mova 0x060B66F4,r0
L_060B6546:
    c.r[8] += c.r[0];  // 060B6546 add r0,r8
L_060B6548:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]); c.r[8] += 1;  // 060B6548 mov.b @r8+,r1
L_060B654A:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[8]); c.r[8] += 1;  // 060B654A mov.b @r8+,r0
L_060B654C:
    c.r[13] = c.r[6];  // 060B654C mov r6,r13
L_060B654E:
    c.r[6] ^= c.r[1];  // 060B654E xor r1,r6
L_060B6550:
    c.r[1] = (uint32_t)(int16_t)ld16(0x060B66ECu);  // 060B6550 mov.w 0x060B66EC,r1
L_060B6552:
    c.r[13] ^= c.r[0];  // 060B6552 xor r0,r13
L_060B6554:
    c.r[0] = ld32(0x060B66F0u);  // 060B6554 mov.l 0x060B66F0,r0
L_060B6556:
    c.r[6] &= c.r[1];  // 060B6556 and r1,r6
L_060B6558:
    c.r[13] &= c.r[1];  // 060B6558 and r1,r13
L_060B655A:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]); c.r[8] += 1;  // 060B655A mov.b @r8+,r1
L_060B655C:
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[6]);  // 060B655C mov.w @(r0,r6),r6
L_060B655E:
    c.r[13] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[13]);  // 060B655E mov.w @(r0,r13),r13
L_060B6560:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[8]);  // 060B6560 mov.b @r8,r0
L_060B6562:
    c.r[6] = c.r[6] & 0xFFFFu;  // 060B6562 extu.w r6,r6
L_060B6564:
    c.r[6] += 2;  // 060B6564 add #2,r6
L_060B6566:
    c.r[6] ^= c.r[1];  // 060B6566 xor r1,r6
L_060B6568:
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[6] * (int32_t)c.r[2]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060B6568 dmuls.l r2,r6
L_060B656A:
    c.r[13] = c.r[13] & 0xFFFFu;  // 060B656A extu.w r13,r13
L_060B656C:
    c.r[13] += 2;  // 060B656C add #2,r13
L_060B656E:
    c.r[13] ^= c.r[0];  // 060B656E xor r0,r13
L_060B6570:
    c.r[1] = c.mach;  // 060B6570 sts mach,r1
L_060B6572:
    c.r[8] = c.macl;  // 060B6572 sts macl,r8
L_060B6574:
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[6] * (int32_t)c.r[3]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060B6574 dmuls.l r3,r6
L_060B6576:
    c.r[0] = ld32(c.gbr + 152);  // 060B6576 mov.l @(152,gbr),r0
L_060B6578:
    c.r[8] = c.r[1] << 16 | c.r[8] >> 16;  // 060B6578 xtrct r1,r8
L_060B657A:
    c.r[11] = c.r[0];  // 060B657A mov r0,r11
L_060B657C:
    c.r[11] <<= 16;  // 060B657C shll16 r11
L_060B657E:
    c.r[1] = c.mach;  // 060B657E sts mach,r1
L_060B6580:
    c.r[9] = c.macl;  // 060B6580 sts macl,r9
L_060B6582:
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[13] * (int32_t)c.r[2]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060B6582 dmuls.l r2,r13
L_060B6584:
    c.r[9] = c.r[1] << 16 | c.r[9] >> 16;  // 060B6584 xtrct r1,r9
L_060B6586:
    c.r[10] = c.r[0] << 16 | c.r[0] >> 16;  // 060B6586 swap.w r0,r10
L_060B6588:
    c.r[10] <<= 16;  // 060B6588 shll16 r10
L_060B658A:
    c.r[1] = c.mach;  // 060B658A sts mach,r1
L_060B658C:
    c.r[2] = c.macl;  // 060B658C sts macl,r2
L_060B658E:
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[13] * (int32_t)c.r[3]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060B658E dmuls.l r3,r13
L_060B6590:
    c.r[0] = ld32(c.gbr + 140);  // 060B6590 mov.l @(140,gbr),r0
L_060B6592:
    c.r[2] = c.r[1] << 16 | c.r[2] >> 16;  // 060B6592 xtrct r1,r2
L_060B6594:
    c.r[13] = c.r[0];  // 060B6594 mov r0,r13
L_060B6596:
    c.r[13] <<= 16;  // 060B6596 shll16 r13
L_060B6598:
    c.r[1] = c.mach;  // 060B6598 sts mach,r1
L_060B659A:
    c.r[3] = c.macl;  // 060B659A sts macl,r3
L_060B659C:
    c.r[12] = c.r[0] << 16 | c.r[0] >> 16;  // 060B659C swap.w r0,r12
L_060B659E:
    c.r[12] <<= 16;  // 060B659E shll16 r12
L_060B65A0:
    c.r[0] = (c.r[5] & 0xFFFF0000u) | (c.r[5] & 0xFFu) << 8 | (c.r[5] >> 8 & 0xFFu);  // 060B65A0 swap.b r5,r0
L_060B65A2:
    c.r[3] = c.r[1] << 16 | c.r[3] >> 16;  // 060B65A2 xtrct r1,r3
L_060B65A4:
    c.r[0] &= 0xFu;  // 060B65A4 and #15,r0
L_060B65A6:
    c.r[0] <<= 2;  // 060B65A6 shll2 r0
L_060B65A8:
    c.r[1] = c.r[0];  // 060B65A8 mov r0,r1
L_060B65AA:
    c.r[0] = 0x060B6708u;  // 060B65AA mova 0x060B6708,r0
L_060B65AC:
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 060B65AC mov.l @(r0,r1),r1
L_060B65AE:
    c.r[6] = ld32(c.r[4] + 4);  // 060B65AE mov.l @(4,r4),r6
L_060B65B0:
    { const uint32_t x = c.r[1]; c.r[4] = ld32(c.r[4]); switch (x) { case 0x060B6748u: goto L_060B6748; case 0x060B67E2u: goto L_060B67E2; case 0x060B68D0u: goto L_060B68D0; case 0x060B67DAu: goto L_060B67DA; case 0x060B685Cu: goto L_060B685C; case 0x060B6752u: goto L_060B6752; case 0x060B6854u: goto L_060B6854; case 0x060B67CAu: goto L_060B67CA; case 0x060B68C8u: goto L_060B68C8; case 0x060B67D2u: goto L_060B67D2; default: sh2_call(c, x); return; } }  // 060B65B0 jmp @r1 ; mov.l @(0,r4),r4
L_060B65B4:
    c.r[9] = c.r[3] << 16 | c.r[9] >> 16;  // 060B65B4 xtrct r3,r9
L_060B65B6:
    c.r[0] = ld32(c.gbr + 144);  // 060B65B6 mov.l @(144,gbr),r0
L_060B65B8:
    c.r[3] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B65B8 exts.w r0,r3
L_060B65BA:
    c.r[2] = c.r[0] << 16 | c.r[0] >> 16;  // 060B65BA swap.w r0,r2
L_060B65BC:
    c.r[0] = ld32(c.gbr + 132);  // 060B65BC mov.l @(132,gbr),r0
L_060B65BE:
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 060B65BE exts.w r2,r2
L_060B65C0:
    c.r[13] = c.r[0] & 0xFFFFu;  // 060B65C0 extu.w r0,r13
L_060B65C2:
    c.r[12] = c.r[0] << 16 | c.r[0] >> 16;  // 060B65C2 swap.w r0,r12
L_060B65C4:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[5];  // 060B65C4 exts.w r5,r0
L_060B65C6:
    c.r[0] += c.r[3];  // 060B65C6 add r3,r0
L_060B65C8:
    c.t = c.r[0] >= c.r[13];  // 060B65C8 cmp/hs r13,r0
L_060B65CA:
    { const bool k = c.t; c.r[12] = c.r[12] & 0xFFFFu; if (k) { goto L_060B65D8; } }  // 060B65CA bt/s 0x060B65D8 ; extu.w r12,r12
L_060B65CE:
    c.r[0] = c.r[5] << 16 | c.r[5] >> 16;  // 060B65CE swap.w r5,r0
L_060B65D0:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B65D0 exts.w r0,r0
L_060B65D2:
    c.r[0] += c.r[2];  // 060B65D2 add r2,r0
L_060B65D4:
    c.t = c.r[12] > c.r[0];  // 060B65D4 cmp/hi r0,r12
L_060B65D6:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[1]; if (k) { goto L_060B66B4; } }  // 060B65D6 bt/s 0x060B66B4 ; exts.w r1,r0
    goto L_060B65DA;
L_060B65D8:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 060B65D8 exts.w r1,r0
L_060B65DA:
    c.r[0] += c.r[3];  // 060B65DA add r3,r0
L_060B65DC:
    c.t = c.r[0] >= c.r[13];  // 060B65DC cmp/hs r13,r0
L_060B65DE:
    { const bool k = c.t; c.r[0] = c.r[1] << 16 | c.r[1] >> 16; if (k) { goto L_060B65EA; } }  // 060B65DE bt/s 0x060B65EA ; swap.w r1,r0
L_060B65E2:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B65E2 exts.w r0,r0
L_060B65E4:
    c.r[0] += c.r[2];  // 060B65E4 add r2,r0
L_060B65E6:
    c.t = c.r[12] > c.r[0];  // 060B65E6 cmp/hi r0,r12
L_060B65E8:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[9]; if (k) { goto L_060B6684; } }  // 060B65E8 bt/s 0x060B6684 ; exts.w r9,r0
    goto L_060B65EC;
L_060B65EA:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[9];  // 060B65EA exts.w r9,r0
L_060B65EC:
    c.r[0] += c.r[3];  // 060B65EC add r3,r0
L_060B65EE:
    c.t = c.r[0] >= c.r[13];  // 060B65EE cmp/hs r13,r0
L_060B65F0:
    { const bool k = c.t; c.r[0] = c.r[9] << 16 | c.r[9] >> 16; if (k) { goto L_060B65FC; } }  // 060B65F0 bt/s 0x060B65FC ; swap.w r9,r0
L_060B65F4:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B65F4 exts.w r0,r0
L_060B65F6:
    c.r[0] += c.r[2];  // 060B65F6 add r2,r0
L_060B65F8:
    c.t = c.r[12] > c.r[0];  // 060B65F8 cmp/hi r0,r12
L_060B65FA:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[6]; if (k) { goto L_060B6694; } }  // 060B65FA bt/s 0x060B6694 ; exts.w r6,r0
    goto L_060B65FE;
L_060B65FC:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[6];  // 060B65FC exts.w r6,r0
L_060B65FE:
    c.r[0] += c.r[3];  // 060B65FE add r3,r0
L_060B6600:
    c.t = c.r[0] >= c.r[13];  // 060B6600 cmp/hs r13,r0
L_060B6602:
    { const bool k = c.t; c.r[0] = c.r[6] << 16 | c.r[6] >> 16; if (k) { goto L_060B660E; } }  // 060B6602 bt/s 0x060B660E ; swap.w r6,r0
L_060B6606:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B6606 exts.w r0,r0
L_060B6608:
    c.r[0] += c.r[2];  // 060B6608 add r2,r0
L_060B660A:
    c.t = c.r[12] > c.r[0];  // 060B660A cmp/hi r0,r12
L_060B660C:
    { const bool k = c.t; c.r[8] = 0x1u; if (k) { goto L_060B66A4; } }  // 060B660C bt/s 0x060B66A4 ; mov #1,r8
    goto L_060B6610;
L_060B660E:
    c.r[8] = 0x1u;  // 060B660E mov #1,r8
L_060B6610:
    c.r[8] <<= 16;  // 060B6610 shll16 r8
L_060B6612:
    c.t = c.r[8] & 1; c.r[8] >>= 1;  // 060B6612 shlr r8
L_060B6614:
    c.r[2] = c.r[6] << 16 | c.r[6] >> 16;  // 060B6614 swap.w r6,r2
L_060B6616:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B6616 tst r8,r2
L_060B6618:
    { uint32_t a = c.r[13], b = c.r[13], t = c.t; c.r[13] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B6618 subc r13,r13
L_060B661A:
    c.r[13] = ~c.r[13];  // 060B661A not r13,r13
L_060B661C:
    c.r[13] ^= c.r[2];  // 060B661C xor r2,r13
L_060B661E:
    c.t = (c.r[6] & c.r[8]) == 0;  // 060B661E tst r8,r6
L_060B6620:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B6620 subc r2,r2
L_060B6622:
    c.r[2] = ~c.r[2];  // 060B6622 not r2,r2
L_060B6624:
    c.r[2] ^= c.r[6];  // 060B6624 xor r6,r2
L_060B6626:
    c.r[13] += c.r[2];  // 060B6626 add r2,r13
L_060B6628:
    c.r[13] = c.r[13] & 0xFFFFu;  // 060B6628 extu.w r13,r13
L_060B662A:
    c.r[0] = 0x060B66A4u;  // 060B662A mova 0x060B66A4,r0
L_060B662C:
    c.r[2] = c.r[9] << 16 | c.r[9] >> 16;  // 060B662C swap.w r9,r2
L_060B662E:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B662E tst r8,r2
L_060B6630:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B6630 subc r12,r12
L_060B6632:
    c.r[12] = ~c.r[12];  // 060B6632 not r12,r12
L_060B6634:
    c.r[12] ^= c.r[2];  // 060B6634 xor r2,r12
L_060B6636:
    c.t = (c.r[9] & c.r[8]) == 0;  // 060B6636 tst r8,r9
L_060B6638:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B6638 subc r2,r2
L_060B663A:
    c.r[2] = ~c.r[2];  // 060B663A not r2,r2
L_060B663C:
    c.r[2] ^= c.r[9];  // 060B663C xor r9,r2
L_060B663E:
    c.r[12] += c.r[2];  // 060B663E add r2,r12
L_060B6640:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B6640 extu.w r12,r12
L_060B6642:
    c.t = (int32_t)c.r[12] > (int32_t)c.r[13];  // 060B6642 cmp/gt r13,r12
L_060B6644:
    { const bool k = c.t; c.r[2] = c.r[1] << 16 | c.r[1] >> 16; if (k) { goto L_060B664C; } }  // 060B6644 bt/s 0x060B664C ; swap.w r1,r2
L_060B6648:
    c.r[13] = c.r[12];  // 060B6648 mov r12,r13
L_060B664A:
    c.r[0] = 0x060B6694u;  // 060B664A mova 0x060B6694,r0
L_060B664C:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B664C tst r8,r2
L_060B664E:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B664E subc r12,r12
L_060B6650:
    c.r[12] = ~c.r[12];  // 060B6650 not r12,r12
L_060B6652:
    c.r[12] ^= c.r[2];  // 060B6652 xor r2,r12
L_060B6654:
    c.t = (c.r[1] & c.r[8]) == 0;  // 060B6654 tst r8,r1
L_060B6656:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B6656 subc r2,r2
L_060B6658:
    c.r[2] = ~c.r[2];  // 060B6658 not r2,r2
L_060B665A:
    c.r[2] ^= c.r[1];  // 060B665A xor r1,r2
L_060B665C:
    c.r[12] += c.r[2];  // 060B665C add r2,r12
L_060B665E:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B665E extu.w r12,r12
L_060B6660:
    c.t = (int32_t)c.r[12] > (int32_t)c.r[13];  // 060B6660 cmp/gt r13,r12
L_060B6662:
    { const bool k = c.t; c.r[2] = c.r[5] << 16 | c.r[5] >> 16; if (k) { goto L_060B666A; } }  // 060B6662 bt/s 0x060B666A ; swap.w r5,r2
L_060B6666:
    c.r[13] = c.r[12];  // 060B6666 mov r12,r13
L_060B6668:
    c.r[0] = 0x060B6684u;  // 060B6668 mova 0x060B6684,r0
L_060B666A:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B666A tst r8,r2
L_060B666C:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B666C subc r12,r12
L_060B666E:
    c.r[12] = ~c.r[12];  // 060B666E not r12,r12
L_060B6670:
    c.r[12] ^= c.r[2];  // 060B6670 xor r2,r12
L_060B6672:
    c.t = (c.r[5] & c.r[8]) == 0;  // 060B6672 tst r8,r5
L_060B6674:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B6674 subc r2,r2
L_060B6676:
    c.r[2] = ~c.r[2];  // 060B6676 not r2,r2
L_060B6678:
    c.r[2] ^= c.r[5];  // 060B6678 xor r5,r2
L_060B667A:
    c.r[12] += c.r[2];  // 060B667A add r2,r12
L_060B667C:
    c.t = (int32_t)c.r[13] >= (int32_t)c.r[12];  // 060B667C cmp/ge r12,r13
L_060B667E:
    if (c.t) { goto L_060B66B4; }  // 060B667E bt 0x060B66B4
L_060B6680:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x060AE614u: goto L_060AE614; case 0x060AE616u: goto L_060AE616; case 0x060AE618u: goto L_060AE618; case 0x060AE61Cu: goto L_060AE61C; case 0x060AE61Eu: goto L_060AE61E; case 0x060AE620u: goto L_060AE620; case 0x060AE622u: goto L_060AE622; case 0x060AE624u: goto L_060AE624; case 0x060AE626u: goto L_060AE626; case 0x060AE628u: goto L_060AE628; case 0x060AE62Au: goto L_060AE62A; case 0x060AE62Cu: goto L_060AE62C; case 0x060AE62Eu: goto L_060AE62E; case 0x060AE630u: goto L_060AE630; case 0x060AE632u: goto L_060AE632; case 0x060AE634u: goto L_060AE634; case 0x060AE636u: goto L_060AE636; case 0x060AE638u: goto L_060AE638; case 0x060AE63Au: goto L_060AE63A; case 0x060AE63Cu: goto L_060AE63C; case 0x060AE63Eu: goto L_060AE63E; case 0x060AE640u: goto L_060AE640; case 0x060AE642u: goto L_060AE642; case 0x060AE644u: goto L_060AE644; case 0x060AE646u: goto L_060AE646; case 0x060AE648u: goto L_060AE648; case 0x060AE64Au: goto L_060AE64A; case 0x060AE64Cu: goto L_060AE64C; case 0x060AE64Eu: goto L_060AE64E; case 0x060AE650u: goto L_060AE650; case 0x060AE652u: goto L_060AE652; case 0x060AE654u: goto L_060AE654; case 0x060B64A0u: goto L_060B64A0; case 0x060B64A2u: goto L_060B64A2; case 0x060B64A4u: goto L_060B64A4; case 0x060B64A6u: goto L_060B64A6; case 0x060B64A8u: goto L_060B64A8; case 0x060B64AAu: goto L_060B64AA; case 0x060B64ACu: goto L_060B64AC; case 0x060B64AEu: goto L_060B64AE; case 0x060B64B2u: goto L_060B64B2; case 0x060B64B4u: goto L_060B64B4; case 0x060B64B6u: goto L_060B64B6; case 0x060B64B8u: goto L_060B64B8; case 0x060B64BAu: goto L_060B64BA; case 0x060B64BCu: goto L_060B64BC; case 0x060B64BEu: goto L_060B64BE; case 0x060B64C2u: goto L_060B64C2; case 0x060B64C4u: goto L_060B64C4; case 0x060B64C6u: goto L_060B64C6; case 0x060B64CAu: goto L_060B64CA; case 0x060B64CCu: goto L_060B64CC; case 0x060B64CEu: goto L_060B64CE; case 0x060B64D0u: goto L_060B64D0; case 0x060B64D2u: goto L_060B64D2; case 0x060B64D6u: goto L_060B64D6; case 0x060B64D8u: goto L_060B64D8; case 0x060B64DAu: goto L_060B64DA; case 0x060B64DCu: goto L_060B64DC; case 0x060B64DEu: goto L_060B64DE; case 0x060B64E2u: goto L_060B64E2; case 0x060B64E4u: goto L_060B64E4; case 0x060B64E6u: goto L_060B64E6; case 0x060B64EAu: goto L_060B64EA; case 0x060B64ECu: goto L_060B64EC; case 0x060B64EEu: goto L_060B64EE; case 0x060B64F0u: goto L_060B64F0; case 0x060B64F2u: goto L_060B64F2; case 0x060B64F4u: goto L_060B64F4; case 0x060B64F6u: goto L_060B64F6; case 0x060B64F8u: goto L_060B64F8; case 0x060B64FAu: goto L_060B64FA; case 0x060B64FCu: goto L_060B64FC; case 0x060B64FEu: goto L_060B64FE; case 0x060B6500u: goto L_060B6500; case 0x060B6502u: goto L_060B6502; case 0x060B6504u: goto L_060B6504; case 0x060B6506u: goto L_060B6506; case 0x060B6508u: goto L_060B6508; case 0x060B650Au: goto L_060B650A; case 0x060B650Cu: goto L_060B650C; case 0x060B650Eu: goto L_060B650E; case 0x060B6510u: goto L_060B6510; case 0x060B6512u: goto L_060B6512; case 0x060B6514u: goto L_060B6514; case 0x060B6516u: goto L_060B6516; case 0x060B6518u: goto L_060B6518; case 0x060B651Au: goto L_060B651A; case 0x060B651Cu: goto L_060B651C; case 0x060B651Eu: goto L_060B651E; case 0x060B6520u: goto L_060B6520; case 0x060B6524u: goto L_060B6524; case 0x060B6528u: goto L_060B6528; case 0x060B652Au: goto L_060B652A; case 0x060B652Eu: goto L_060B652E; case 0x060B6530u: goto L_060B6530; case 0x060B6532u: goto L_060B6532; case 0x060B6534u: goto L_060B6534; case 0x060B6536u: goto L_060B6536; case 0x060B6538u: goto L_060B6538; case 0x060B653Au: goto L_060B653A; case 0x060B653Cu: goto L_060B653C; case 0x060B653Eu: goto L_060B653E; case 0x060B6540u: goto L_060B6540; case 0x060B6542u: goto L_060B6542; case 0x060B6544u: goto L_060B6544; case 0x060B6546u: goto L_060B6546; case 0x060B6548u: goto L_060B6548; case 0x060B654Au: goto L_060B654A; case 0x060B654Cu: goto L_060B654C; case 0x060B654Eu: goto L_060B654E; case 0x060B6550u: goto L_060B6550; case 0x060B6552u: goto L_060B6552; case 0x060B6554u: goto L_060B6554; case 0x060B6556u: goto L_060B6556; case 0x060B6558u: goto L_060B6558; case 0x060B655Au: goto L_060B655A; case 0x060B655Cu: goto L_060B655C; case 0x060B655Eu: goto L_060B655E; case 0x060B6560u: goto L_060B6560; case 0x060B6562u: goto L_060B6562; case 0x060B6564u: goto L_060B6564; case 0x060B6566u: goto L_060B6566; case 0x060B6568u: goto L_060B6568; case 0x060B656Au: goto L_060B656A; case 0x060B656Cu: goto L_060B656C; case 0x060B656Eu: goto L_060B656E; case 0x060B6570u: goto L_060B6570; case 0x060B6572u: goto L_060B6572; case 0x060B6574u: goto L_060B6574; case 0x060B6576u: goto L_060B6576; case 0x060B6578u: goto L_060B6578; case 0x060B657Au: goto L_060B657A; case 0x060B657Cu: goto L_060B657C; case 0x060B657Eu: goto L_060B657E; case 0x060B6580u: goto L_060B6580; case 0x060B6582u: goto L_060B6582; case 0x060B6584u: goto L_060B6584; case 0x060B6586u: goto L_060B6586; case 0x060B6588u: goto L_060B6588; case 0x060B658Au: goto L_060B658A; case 0x060B658Cu: goto L_060B658C; case 0x060B658Eu: goto L_060B658E; case 0x060B6590u: goto L_060B6590; case 0x060B6592u: goto L_060B6592; case 0x060B6594u: goto L_060B6594; case 0x060B6596u: goto L_060B6596; case 0x060B6598u: goto L_060B6598; case 0x060B659Au: goto L_060B659A; case 0x060B659Cu: goto L_060B659C; case 0x060B659Eu: goto L_060B659E; case 0x060B65A0u: goto L_060B65A0; case 0x060B65A2u: goto L_060B65A2; case 0x060B65A4u: goto L_060B65A4; case 0x060B65A6u: goto L_060B65A6; case 0x060B65A8u: goto L_060B65A8; case 0x060B65AAu: goto L_060B65AA; case 0x060B65ACu: goto L_060B65AC; case 0x060B65AEu: goto L_060B65AE; case 0x060B65B0u: goto L_060B65B0; case 0x060B65B4u: goto L_060B65B4; case 0x060B65B6u: goto L_060B65B6; case 0x060B65B8u: goto L_060B65B8; case 0x060B65BAu: goto L_060B65BA; case 0x060B65BCu: goto L_060B65BC; case 0x060B65BEu: goto L_060B65BE; case 0x060B65C0u: goto L_060B65C0; case 0x060B65C2u: goto L_060B65C2; case 0x060B65C4u: goto L_060B65C4; case 0x060B65C6u: goto L_060B65C6; case 0x060B65C8u: goto L_060B65C8; case 0x060B65CAu: goto L_060B65CA; case 0x060B65CEu: goto L_060B65CE; case 0x060B65D0u: goto L_060B65D0; case 0x060B65D2u: goto L_060B65D2; case 0x060B65D4u: goto L_060B65D4; case 0x060B65D6u: goto L_060B65D6; case 0x060B65DAu: goto L_060B65DA; case 0x060B65DCu: goto L_060B65DC; case 0x060B65DEu: goto L_060B65DE; case 0x060B65E2u: goto L_060B65E2; case 0x060B65E4u: goto L_060B65E4; case 0x060B65E6u: goto L_060B65E6; case 0x060B65E8u: goto L_060B65E8; case 0x060B65ECu: goto L_060B65EC; case 0x060B65EEu: goto L_060B65EE; case 0x060B65F0u: goto L_060B65F0; case 0x060B65F4u: goto L_060B65F4; case 0x060B65F6u: goto L_060B65F6; case 0x060B65F8u: goto L_060B65F8; case 0x060B65FAu: goto L_060B65FA; case 0x060B65FEu: goto L_060B65FE; case 0x060B6600u: goto L_060B6600; case 0x060B6602u: goto L_060B6602; case 0x060B6606u: goto L_060B6606; case 0x060B6608u: goto L_060B6608; case 0x060B660Au: goto L_060B660A; case 0x060B660Cu: goto L_060B660C; case 0x060B6610u: goto L_060B6610; case 0x060B6612u: goto L_060B6612; case 0x060B6614u: goto L_060B6614; case 0x060B6616u: goto L_060B6616; case 0x060B6618u: goto L_060B6618; case 0x060B661Au: goto L_060B661A; case 0x060B661Cu: goto L_060B661C; case 0x060B661Eu: goto L_060B661E; case 0x060B6620u: goto L_060B6620; case 0x060B6622u: goto L_060B6622; case 0x060B6624u: goto L_060B6624; case 0x060B6626u: goto L_060B6626; case 0x060B6628u: goto L_060B6628; case 0x060B662Au: goto L_060B662A; case 0x060B662Cu: goto L_060B662C; case 0x060B662Eu: goto L_060B662E; case 0x060B6630u: goto L_060B6630; case 0x060B6632u: goto L_060B6632; case 0x060B6634u: goto L_060B6634; case 0x060B6636u: goto L_060B6636; case 0x060B6638u: goto L_060B6638; case 0x060B663Au: goto L_060B663A; case 0x060B663Cu: goto L_060B663C; case 0x060B663Eu: goto L_060B663E; case 0x060B6640u: goto L_060B6640; case 0x060B6642u: goto L_060B6642; case 0x060B6644u: goto L_060B6644; case 0x060B6648u: goto L_060B6648; case 0x060B664Au: goto L_060B664A; case 0x060B664Cu: goto L_060B664C; case 0x060B664Eu: goto L_060B664E; case 0x060B6650u: goto L_060B6650; case 0x060B6652u: goto L_060B6652; case 0x060B6654u: goto L_060B6654; case 0x060B6656u: goto L_060B6656; case 0x060B6658u: goto L_060B6658; case 0x060B665Au: goto L_060B665A; case 0x060B665Cu: goto L_060B665C; case 0x060B665Eu: goto L_060B665E; case 0x060B6660u: goto L_060B6660; case 0x060B6662u: goto L_060B6662; case 0x060B6666u: goto L_060B6666; case 0x060B6668u: goto L_060B6668; case 0x060B666Au: goto L_060B666A; case 0x060B666Cu: goto L_060B666C; case 0x060B666Eu: goto L_060B666E; case 0x060B6670u: goto L_060B6670; case 0x060B6672u: goto L_060B6672; case 0x060B6674u: goto L_060B6674; case 0x060B6676u: goto L_060B6676; case 0x060B6678u: goto L_060B6678; case 0x060B667Au: goto L_060B667A; case 0x060B667Cu: goto L_060B667C; case 0x060B667Eu: goto L_060B667E; case 0x060B6680u: goto L_060B6680; case 0x060B6684u: goto L_060B6684; case 0x060B6686u: goto L_060B6686; case 0x060B6688u: goto L_060B6688; case 0x060B668Au: goto L_060B668A; case 0x060B668Cu: goto L_060B668C; case 0x060B668Eu: goto L_060B668E; case 0x060B6690u: goto L_060B6690; case 0x060B6694u: goto L_060B6694; case 0x060B6696u: goto L_060B6696; case 0x060B6698u: goto L_060B6698; case 0x060B669Au: goto L_060B669A; case 0x060B669Cu: goto L_060B669C; case 0x060B669Eu: goto L_060B669E; case 0x060B66A0u: goto L_060B66A0; case 0x060B66A4u: goto L_060B66A4; case 0x060B66A6u: goto L_060B66A6; case 0x060B66A8u: goto L_060B66A8; case 0x060B66AAu: goto L_060B66AA; case 0x060B66ACu: goto L_060B66AC; case 0x060B66AEu: goto L_060B66AE; case 0x060B66B0u: goto L_060B66B0; case 0x060B66B4u: goto L_060B66B4; case 0x060B66B6u: goto L_060B66B6; case 0x060B66B8u: goto L_060B66B8; case 0x060B66BAu: goto L_060B66BA; case 0x060B66BCu: goto L_060B66BC; case 0x060B66BEu: goto L_060B66BE; case 0x060B66C0u: goto L_060B66C0; case 0x060B66C2u: goto L_060B66C2; case 0x060B66C4u: goto L_060B66C4; case 0x060B66C6u: goto L_060B66C6; case 0x060B66C8u: goto L_060B66C8; case 0x060B66CAu: goto L_060B66CA; case 0x060B66CCu: goto L_060B66CC; case 0x060B66CEu: goto L_060B66CE; case 0x060B66D0u: goto L_060B66D0; case 0x060B66D2u: goto L_060B66D2; case 0x060B66D4u: goto L_060B66D4; case 0x060B66D6u: goto L_060B66D6; case 0x060B66D8u: goto L_060B66D8; case 0x060B66DAu: goto L_060B66DA; case 0x060B66DCu: goto L_060B66DC; case 0x060B66DEu: goto L_060B66DE; case 0x060B66E0u: goto L_060B66E0; case 0x060B66E2u: goto L_060B66E2; case 0x060B66E4u: goto L_060B66E4; case 0x060B66E6u: goto L_060B66E6; case 0x060B66E8u: goto L_060B66E8; case 0x060B6748u: goto L_060B6748; case 0x060B674Au: goto L_060B674A; case 0x060B674Cu: goto L_060B674C; case 0x060B674Eu: goto L_060B674E; case 0x060B6750u: goto L_060B6750; case 0x060B6752u: goto L_060B6752; case 0x060B6754u: goto L_060B6754; case 0x060B6756u: goto L_060B6756; case 0x060B6758u: goto L_060B6758; case 0x060B675Au: goto L_060B675A; case 0x060B675Cu: goto L_060B675C; case 0x060B675Eu: goto L_060B675E; case 0x060B6760u: goto L_060B6760; case 0x060B6762u: goto L_060B6762; case 0x060B6764u: goto L_060B6764; case 0x060B6768u: goto L_060B6768; case 0x060B676Au: goto L_060B676A; case 0x060B676Cu: goto L_060B676C; case 0x060B676Eu: goto L_060B676E; case 0x060B6770u: goto L_060B6770; case 0x060B6772u: goto L_060B6772; case 0x060B6774u: goto L_060B6774; case 0x060B6776u: goto L_060B6776; case 0x060B6778u: goto L_060B6778; case 0x060B677Cu: goto L_060B677C; case 0x060B677Eu: goto L_060B677E; case 0x060B6780u: goto L_060B6780; case 0x060B6782u: goto L_060B6782; case 0x060B6784u: goto L_060B6784; case 0x060B6788u: goto L_060B6788; case 0x060B678Au: goto L_060B678A; case 0x060B678Cu: goto L_060B678C; case 0x060B678Eu: goto L_060B678E; case 0x060B6790u: goto L_060B6790; case 0x060B6792u: goto L_060B6792; case 0x060B6796u: goto L_060B6796; case 0x060B6798u: goto L_060B6798; case 0x060B679Au: goto L_060B679A; case 0x060B679Cu: goto L_060B679C; case 0x060B679Eu: goto L_060B679E; case 0x060B67A0u: goto L_060B67A0; case 0x060B67A2u: goto L_060B67A2; case 0x060B67A4u: goto L_060B67A4; case 0x060B67A8u: goto L_060B67A8; case 0x060B67AAu: goto L_060B67AA; case 0x060B67ACu: goto L_060B67AC; case 0x060B67AEu: goto L_060B67AE; case 0x060B67B2u: goto L_060B67B2; case 0x060B67B4u: goto L_060B67B4; case 0x060B67B6u: goto L_060B67B6; case 0x060B67B8u: goto L_060B67B8; case 0x060B67BCu: goto L_060B67BC; case 0x060B67BEu: goto L_060B67BE; case 0x060B67C0u: goto L_060B67C0; case 0x060B67C2u: goto L_060B67C2; case 0x060B67C6u: goto L_060B67C6; case 0x060B67CAu: goto L_060B67CA; case 0x060B67CCu: goto L_060B67CC; case 0x060B67CEu: goto L_060B67CE; case 0x060B67D2u: goto L_060B67D2; case 0x060B67D4u: goto L_060B67D4; case 0x060B67D6u: goto L_060B67D6; case 0x060B67DAu: goto L_060B67DA; case 0x060B67DCu: goto L_060B67DC; case 0x060B67DEu: goto L_060B67DE; case 0x060B67E0u: goto L_060B67E0; case 0x060B67E2u: goto L_060B67E2; case 0x060B67E4u: goto L_060B67E4; case 0x060B67E6u: goto L_060B67E6; case 0x060B67E8u: goto L_060B67E8; case 0x060B67ECu: goto L_060B67EC; case 0x060B67EEu: goto L_060B67EE; case 0x060B67F0u: goto L_060B67F0; case 0x060B67F4u: goto L_060B67F4; case 0x060B67F6u: goto L_060B67F6; case 0x060B67F8u: goto L_060B67F8; case 0x060B67FAu: goto L_060B67FA; case 0x060B67FCu: goto L_060B67FC; case 0x060B6800u: goto L_060B6800; case 0x060B6802u: goto L_060B6802; case 0x060B6804u: goto L_060B6804; case 0x060B6806u: goto L_060B6806; case 0x060B6808u: goto L_060B6808; case 0x060B680Au: goto L_060B680A; case 0x060B680Eu: goto L_060B680E; case 0x060B6810u: goto L_060B6810; case 0x060B6812u: goto L_060B6812; case 0x060B6814u: goto L_060B6814; case 0x060B6816u: goto L_060B6816; case 0x060B6818u: goto L_060B6818; case 0x060B681Au: goto L_060B681A; case 0x060B681Cu: goto L_060B681C; case 0x060B6820u: goto L_060B6820; case 0x060B6822u: goto L_060B6822; case 0x060B6824u: goto L_060B6824; case 0x060B6826u: goto L_060B6826; case 0x060B682Au: goto L_060B682A; case 0x060B682Cu: goto L_060B682C; case 0x060B682Eu: goto L_060B682E; case 0x060B6830u: goto L_060B6830; case 0x060B6834u: goto L_060B6834; case 0x060B6836u: goto L_060B6836; case 0x060B6838u: goto L_060B6838; case 0x060B683Au: goto L_060B683A; case 0x060B683Eu: goto L_060B683E; case 0x060B6842u: goto L_060B6842; case 0x060B6844u: goto L_060B6844; case 0x060B6846u: goto L_060B6846; case 0x060B6848u: goto L_060B6848; case 0x060B684Au: goto L_060B684A; case 0x060B684Cu: goto L_060B684C; case 0x060B684Eu: goto L_060B684E; case 0x060B6850u: goto L_060B6850; case 0x060B6854u: goto L_060B6854; case 0x060B6856u: goto L_060B6856; case 0x060B6858u: goto L_060B6858; case 0x060B685Au: goto L_060B685A; case 0x060B685Cu: goto L_060B685C; case 0x060B685Eu: goto L_060B685E; case 0x060B6860u: goto L_060B6860; case 0x060B6862u: goto L_060B6862; case 0x060B6864u: goto L_060B6864; case 0x060B6866u: goto L_060B6866; case 0x060B6868u: goto L_060B6868; case 0x060B686Cu: goto L_060B686C; case 0x060B686Eu: goto L_060B686E; case 0x060B6870u: goto L_060B6870; case 0x060B6872u: goto L_060B6872; case 0x060B6874u: goto L_060B6874; case 0x060B6876u: goto L_060B6876; case 0x060B687Au: goto L_060B687A; case 0x060B687Cu: goto L_060B687C; case 0x060B687Eu: goto L_060B687E; case 0x060B6880u: goto L_060B6880; case 0x060B6882u: goto L_060B6882; case 0x060B6886u: goto L_060B6886; case 0x060B6888u: goto L_060B6888; case 0x060B688Au: goto L_060B688A; case 0x060B688Cu: goto L_060B688C; case 0x060B688Eu: goto L_060B688E; case 0x060B6890u: goto L_060B6890; case 0x060B6894u: goto L_060B6894; case 0x060B6896u: goto L_060B6896; case 0x060B6898u: goto L_060B6898; case 0x060B689Au: goto L_060B689A; case 0x060B689Cu: goto L_060B689C; case 0x060B689Eu: goto L_060B689E; case 0x060B68A0u: goto L_060B68A0; case 0x060B68A2u: goto L_060B68A2; case 0x060B68A6u: goto L_060B68A6; case 0x060B68A8u: goto L_060B68A8; case 0x060B68AAu: goto L_060B68AA; case 0x060B68ACu: goto L_060B68AC; case 0x060B68B0u: goto L_060B68B0; case 0x060B68B2u: goto L_060B68B2; case 0x060B68B4u: goto L_060B68B4; case 0x060B68B6u: goto L_060B68B6; case 0x060B68BAu: goto L_060B68BA; case 0x060B68BCu: goto L_060B68BC; case 0x060B68BEu: goto L_060B68BE; case 0x060B68C0u: goto L_060B68C0; case 0x060B68C4u: goto L_060B68C4; case 0x060B68C8u: goto L_060B68C8; case 0x060B68CAu: goto L_060B68CA; case 0x060B68CCu: goto L_060B68CC; case 0x060B68CEu: goto L_060B68CE; case 0x060B68D0u: goto L_060B68D0; case 0x060B68D2u: goto L_060B68D2; case 0x060B68D4u: goto L_060B68D4; case 0x060B68D6u: goto L_060B68D6; case 0x060B68D8u: goto L_060B68D8; case 0x060B68DAu: goto L_060B68DA; case 0x060B68DCu: goto L_060B68DC; case 0x060B68E0u: goto L_060B68E0; case 0x060B68E2u: goto L_060B68E2; case 0x060B68E4u: goto L_060B68E4; case 0x060B68E6u: goto L_060B68E6; case 0x060B68E8u: goto L_060B68E8; case 0x060B68EAu: goto L_060B68EA; case 0x060B68EEu: goto L_060B68EE; case 0x060B68F0u: goto L_060B68F0; case 0x060B68F2u: goto L_060B68F2; case 0x060B68F4u: goto L_060B68F4; case 0x060B68F6u: goto L_060B68F6; case 0x060B68FAu: goto L_060B68FA; case 0x060B68FCu: goto L_060B68FC; case 0x060B68FEu: goto L_060B68FE; case 0x060B6900u: goto L_060B6900; case 0x060B6902u: goto L_060B6902; case 0x060B6904u: goto L_060B6904; case 0x060B6908u: goto L_060B6908; case 0x060B690Au: goto L_060B690A; case 0x060B690Cu: goto L_060B690C; case 0x060B690Eu: goto L_060B690E; case 0x060B6910u: goto L_060B6910; case 0x060B6912u: goto L_060B6912; case 0x060B6914u: goto L_060B6914; case 0x060B6916u: goto L_060B6916; case 0x060B691Au: goto L_060B691A; case 0x060B691Cu: goto L_060B691C; case 0x060B691Eu: goto L_060B691E; case 0x060B6920u: goto L_060B6920; case 0x060B6924u: goto L_060B6924; case 0x060B6926u: goto L_060B6926; case 0x060B6928u: goto L_060B6928; case 0x060B692Au: goto L_060B692A; case 0x060B692Eu: goto L_060B692E; case 0x060B6930u: goto L_060B6930; case 0x060B6932u: goto L_060B6932; case 0x060B6934u: goto L_060B6934; case 0x060B6938u: goto L_060B6938; case 0x060B693Cu: goto L_060B693C; case 0x060B693Eu: goto L_060B693E; case 0x060B6940u: goto L_060B6940; case 0x060B6942u: goto L_060B6942; case 0x060B6944u: goto L_060B6944; case 0x060B6946u: goto L_060B6946; case 0x060B6948u: goto L_060B6948; case 0x060B694Au: goto L_060B694A; default: sh2_call(c, x); return; } }  // 060B6680 jmp @r0 ; nop
L_060B6684:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[7]);  // 060B6684 mov.w @(0,r7),r0
L_060B6686:
    st32(c.r[7] + 16, c.r[5]);  // 060B6686 mov.l r5,@(16,r7)
L_060B6688:
    c.r[0] ^= 0x10u;  // 060B6688 xor #16,r0
L_060B668A:
    st16(c.r[7], c.r[0]);  // 060B668A mov.w r0,@(0,r7)
L_060B668C:
    st32(c.r[7] + 12, c.r[1]);  // 060B668C mov.l r1,@(12,r7)
L_060B668E:
    st32(c.r[7] + 24, c.r[9]);  // 060B668E mov.l r9,@(24,r7)
L_060B6690:
    st32(c.r[7] + 20, c.r[6]); goto L_060B66BC;  // 060B6690 bra 0x060B66BC ; mov.l r6,@(20,r7)
L_060B6694:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[7]);  // 060B6694 mov.w @(0,r7),r0
L_060B6696:
    st32(c.r[7] + 20, c.r[5]);  // 060B6696 mov.l r5,@(20,r7)
L_060B6698:
    c.r[0] ^= 0x30u;  // 060B6698 xor #48,r0
L_060B669A:
    st16(c.r[7], c.r[0]);  // 060B669A mov.w r0,@(0,r7)
L_060B669C:
    st32(c.r[7] + 24, c.r[1]);  // 060B669C mov.l r1,@(24,r7)
L_060B669E:
    st32(c.r[7] + 12, c.r[9]);  // 060B669E mov.l r9,@(12,r7)
L_060B66A0:
    st32(c.r[7] + 16, c.r[6]); goto L_060B66BC;  // 060B66A0 bra 0x060B66BC ; mov.l r6,@(16,r7)
L_060B66A4:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[7]);  // 060B66A4 mov.w @(0,r7),r0
L_060B66A6:
    st32(c.r[7] + 24, c.r[5]);  // 060B66A6 mov.l r5,@(24,r7)
L_060B66A8:
    c.r[0] ^= 0x20u;  // 060B66A8 xor #32,r0
L_060B66AA:
    st16(c.r[7], c.r[0]);  // 060B66AA mov.w r0,@(0,r7)
L_060B66AC:
    st32(c.r[7] + 20, c.r[1]);  // 060B66AC mov.l r1,@(20,r7)
L_060B66AE:
    st32(c.r[7] + 16, c.r[9]);  // 060B66AE mov.l r9,@(16,r7)
L_060B66B0:
    st32(c.r[7] + 12, c.r[6]); goto L_060B66BC;  // 060B66B0 bra 0x060B66BC ; mov.l r6,@(12,r7)
L_060B66B4:
    st32(c.r[7] + 12, c.r[5]);  // 060B66B4 mov.l r5,@(12,r7)
L_060B66B6:
    st32(c.r[7] + 16, c.r[1]);  // 060B66B6 mov.l r1,@(16,r7)
L_060B66B8:
    st32(c.r[7] + 20, c.r[9]);  // 060B66B8 mov.l r9,@(20,r7)
L_060B66BA:
    st32(c.r[7] + 24, c.r[6]);  // 060B66BA mov.l r6,@(24,r7)
L_060B66BC:
    c.r[0] = ld32(c.gbr + 72);  // 060B66BC mov.l @(72,gbr),r0
L_060B66BE:
    c.r[1] = 0x28u;  // 060B66BE mov #40,r1
L_060B66C0:
    st32(c.r[0], c.r[1]);  // 060B66C0 mov.l r1,@(0,r0)
L_060B66C2:
    st32(c.r[0] + 4, c.r[7]);  // 060B66C2 mov.l r7,@(4,r0)
L_060B66C4:
    c.r[1] = 0x1u;  // 060B66C4 mov #1,r1
L_060B66C6:
    st32(c.r[0] + 8, c.r[1]);  // 060B66C6 mov.l r1,@(8,r0)
L_060B66C8:
    c.r[1] = 0x0u;  // 060B66C8 mov #0,r1
L_060B66CA:
    st32(c.r[0] + 12, c.r[1]);  // 060B66CA mov.l r1,@(12,r0)
L_060B66CC:
    c.r[0] += 16;  // 060B66CC add #16,r0
L_060B66CE:
    c.r[1] = ld32(0x060B6704u);  // 060B66CE mov.l 0x060B6704,r1
L_060B66D0:
    st32(c.gbr + 72, c.r[0]);  // 060B66D0 mov.l r0,@(72,gbr)
L_060B66D2:
    st16(c.r[1], c.r[0]);  // 060B66D2 mov.w r0,@r1
L_060B66D4:
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060B66D4 mov.l @r15+,r8
L_060B66D6:
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060B66D6 mov.l @r15+,r9
L_060B66D8:
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060B66D8 mov.l @r15+,r10
L_060B66DA:
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060B66DA mov.l @r15+,r11
L_060B66DC:
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060B66DC mov.l @r15+,r12
L_060B66DE:
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060B66DE mov.l @r15+,r13
L_060B66E0:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060B66E0 mov.l @r15+,r14
L_060B66E2:
    c.r[7] -= 36;  // 060B66E2 add #-36,r7
L_060B66E4:
    c.r[0] = c.r[7];  // 060B66E4 mov r7,r0
L_060B66E6:
    st32(c.gbr + 48, c.r[0]);  // 060B66E6 mov.l r0,@(48,gbr)
L_060B66E8:
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 060B66E8 rts ; mov #1,r0
L_060B6748:
    c.r[5] = (c.r[5] & 0xFFFF0000u) | (c.r[5] & 0xFFu) << 8 | (c.r[5] >> 8 & 0xFFu);  // 060B6748 swap.b r5,r5
L_060B674A:
    c.r[0] = 0xFFFFFFF0u;  // 060B674A mov #-16,r0
L_060B674C:
    c.r[0] &= c.r[5];  // 060B674C and r5,r0
L_060B674E:
    c.r[0] |= 0xAu;  // 060B674E or #10,r0
L_060B6750:
    c.r[5] = (c.r[0] & 0xFFFF0000u) | (c.r[0] & 0xFFu) << 8 | (c.r[0] >> 8 & 0xFFu);  // 060B6750 swap.b r0,r5
L_060B6752:
    c.r[0] = c.r[2];  // 060B6752 mov r2,r0
L_060B6754:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B6754 shar r0
L_060B6756:
    c.r[4] -= c.r[0];  // 060B6756 sub r0,r4
L_060B6758:
    c.r[0] = c.r[9];  // 060B6758 mov r9,r0
L_060B675A:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B675A shar r0
L_060B675C:
    c.r[4] += c.r[0];  // 060B675C add r0,r4
L_060B675E:
    c.r[0] = c.r[4];  // 060B675E mov r4,r0
L_060B6760:
    c.r[0] += c.r[10];  // 060B6760 add r10,r0
L_060B6762:
    c.t = c.r[0] > c.r[12];  // 060B6762 cmp/hi r12,r0
L_060B6764:
    { const bool k = c.t; c.r[0] = c.r[3]; if (k) { goto L_060B6842; } }  // 060B6764 bt/s 0x060B6842 ; mov r3,r0
L_060B6768:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B6768 shar r0
L_060B676A:
    c.r[6] -= c.r[0];  // 060B676A sub r0,r6
L_060B676C:
    c.r[0] = c.r[8];  // 060B676C mov r8,r0
L_060B676E:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B676E shar r0
L_060B6770:
    c.r[6] -= c.r[0];  // 060B6770 sub r0,r6
L_060B6772:
    c.r[0] = c.r[6];  // 060B6772 mov r6,r0
L_060B6774:
    c.r[0] += c.r[11];  // 060B6774 add r11,r0
L_060B6776:
    c.t = c.r[0] > c.r[13];  // 060B6776 cmp/hi r13,r0
L_060B6778:
    { const bool k = c.t; c.r[1] = c.r[4] << 16 | c.r[4] >> 16; if (k) { goto L_060B6842; } }  // 060B6778 bt/s 0x060B6842 ; swap.w r4,r1
L_060B677C:
    c.r[4] += c.r[2];  // 060B677C add r2,r4
L_060B677E:
    c.r[0] = c.r[4];  // 060B677E mov r4,r0
L_060B6780:
    c.r[0] += c.r[10];  // 060B6780 add r10,r0
L_060B6782:
    c.t = c.r[0] > c.r[12];  // 060B6782 cmp/hi r12,r0
L_060B6784:
    { const bool k = c.t; st16(c.r[7], c.r[5]); if (k) { goto L_060B6842; } }  // 060B6784 bt/s 0x060B6842 ; mov.w r5,@r7
L_060B6788:
    c.r[5] = c.r[6];  // 060B6788 mov r6,r5
L_060B678A:
    c.r[6] += c.r[8];  // 060B678A add r8,r6
L_060B678C:
    c.r[0] = c.r[6];  // 060B678C mov r6,r0
L_060B678E:
    c.r[0] += c.r[11];  // 060B678E add r11,r0
L_060B6790:
    c.t = c.r[0] > c.r[13];  // 060B6790 cmp/hi r13,r0
L_060B6792:
    { const bool k = c.t; c.r[5] = c.r[1] << 16 | c.r[5] >> 16; if (k) { goto L_060B6842; } }  // 060B6792 bt/s 0x060B6842 ; xtrct r1,r5
L_060B6796:
    c.r[0] = c.r[4] << 16 | c.r[4] >> 16;  // 060B6796 swap.w r4,r0
L_060B6798:
    c.r[1] = c.r[6];  // 060B6798 mov r6,r1
L_060B679A:
    c.r[1] = c.r[0] << 16 | c.r[1] >> 16;  // 060B679A xtrct r0,r1
L_060B679C:
    c.r[4] -= c.r[9];  // 060B679C sub r9,r4
L_060B679E:
    c.r[0] = c.r[4];  // 060B679E mov r4,r0
L_060B67A0:
    c.r[0] += c.r[10];  // 060B67A0 add r10,r0
L_060B67A2:
    c.t = c.r[0] > c.r[12];  // 060B67A2 cmp/hi r12,r0
L_060B67A4:
    { const bool k = c.t; c.r[6] += c.r[3]; if (k) { goto L_060B6842; } }  // 060B67A4 bt/s 0x060B6842 ; add r3,r6
L_060B67A8:
    c.r[0] = c.r[6];  // 060B67A8 mov r6,r0
L_060B67AA:
    c.r[0] += c.r[11];  // 060B67AA add r11,r0
L_060B67AC:
    c.t = c.r[0] > c.r[13];  // 060B67AC cmp/hi r13,r0
L_060B67AE:
    { const bool k = c.t; c.r[3] = c.r[4] << 16 | c.r[4] >> 16; if (k) { goto L_060B6842; } }  // 060B67AE bt/s 0x060B6842 ; swap.w r4,r3
L_060B67B2:
    c.r[4] -= c.r[2];  // 060B67B2 sub r2,r4
L_060B67B4:
    c.r[10] += c.r[4];  // 060B67B4 add r4,r10
L_060B67B6:
    c.t = c.r[10] > c.r[12];  // 060B67B6 cmp/hi r12,r10
L_060B67B8:
    { const bool k = c.t; c.r[9] = c.r[6]; if (k) { goto L_060B6842; } }  // 060B67B8 bt/s 0x060B6842 ; mov r6,r9
L_060B67BC:
    c.r[6] -= c.r[8];  // 060B67BC sub r8,r6
L_060B67BE:
    c.r[11] += c.r[6];  // 060B67BE add r6,r11
L_060B67C0:
    c.t = c.r[11] > c.r[13];  // 060B67C0 cmp/hi r13,r11
L_060B67C2:
    { const bool k = c.t; c.r[4] = c.r[4] << 16 | c.r[4] >> 16; if (k) { goto L_060B6842; } }  // 060B67C2 bt/s 0x060B6842 ; swap.w r4,r4
L_060B67C6:
    c.r[6] = c.r[4] << 16 | c.r[6] >> 16; SH2_POLL(c); goto L_060B65B4;  // 060B67C6 bra 0x060B65B4 ; xtrct r4,r6
L_060B67CA:
    c.r[1] = 0x20u;  // 060B67CA mov #32,r1
L_060B67CC:
    c.r[3] = 0u - c.r[3];  // 060B67CC neg r3,r3
L_060B67CE:
    c.r[9] = 0u - c.r[9]; goto L_060B67E0;  // 060B67CE bra 0x060B67E0 ; neg r9,r9
L_060B67D2:
    c.r[1] = 0x30u;  // 060B67D2 mov #48,r1
L_060B67D4:
    c.r[3] = 0u - c.r[3];  // 060B67D4 neg r3,r3
L_060B67D6:
    c.r[9] = 0u - c.r[9]; goto L_060B67DC;  // 060B67D6 bra 0x060B67DC ; neg r9,r9
L_060B67DA:
    c.r[1] = 0x10u;  // 060B67DA mov #16,r1
L_060B67DC:
    c.r[2] = 0u - c.r[2];  // 060B67DC neg r2,r2
L_060B67DE:
    c.r[8] = 0u - c.r[8];  // 060B67DE neg r8,r8
L_060B67E0:
    c.r[5] ^= c.r[1];  // 060B67E0 xor r1,r5
L_060B67E2:
    c.r[0] = c.r[4];  // 060B67E2 mov r4,r0
L_060B67E4:
    c.r[0] += c.r[10];  // 060B67E4 add r10,r0
L_060B67E6:
    c.t = c.r[0] > c.r[12];  // 060B67E6 cmp/hi r12,r0
L_060B67E8:
    { const bool k = c.t; c.r[0] = c.r[6]; if (k) { goto L_060B6842; } }  // 060B67E8 bt/s 0x060B6842 ; mov r6,r0
L_060B67EC:
    c.r[0] += c.r[11];  // 060B67EC add r11,r0
L_060B67EE:
    c.t = c.r[0] > c.r[13];  // 060B67EE cmp/hi r13,r0
L_060B67F0:
    { const bool k = c.t; c.r[1] = c.r[4] << 16 | c.r[4] >> 16; if (k) { goto L_060B6842; } }  // 060B67F0 bt/s 0x060B6842 ; swap.w r4,r1
L_060B67F4:
    c.r[4] += c.r[2];  // 060B67F4 add r2,r4
L_060B67F6:
    c.r[0] = c.r[4];  // 060B67F6 mov r4,r0
L_060B67F8:
    c.r[0] += c.r[10];  // 060B67F8 add r10,r0
L_060B67FA:
    c.t = c.r[0] > c.r[12];  // 060B67FA cmp/hi r12,r0
L_060B67FC:
    { const bool k = c.t; st16(c.r[7], c.r[5]); if (k) { goto L_060B6842; } }  // 060B67FC bt/s 0x060B6842 ; mov.w r5,@r7
L_060B6800:
    c.r[5] = c.r[6];  // 060B6800 mov r6,r5
L_060B6802:
    c.r[6] += c.r[8];  // 060B6802 add r8,r6
L_060B6804:
    c.r[0] = c.r[6];  // 060B6804 mov r6,r0
L_060B6806:
    c.r[0] += c.r[11];  // 060B6806 add r11,r0
L_060B6808:
    c.t = c.r[0] > c.r[13];  // 060B6808 cmp/hi r13,r0
L_060B680A:
    { const bool k = c.t; c.r[0] = c.r[4] << 16 | c.r[4] >> 16; if (k) { goto L_060B6842; } }  // 060B680A bt/s 0x060B6842 ; swap.w r4,r0
L_060B680E:
    c.r[5] = c.r[1] << 16 | c.r[5] >> 16;  // 060B680E xtrct r1,r5
L_060B6810:
    c.r[1] = c.r[6];  // 060B6810 mov r6,r1
L_060B6812:
    c.r[1] = c.r[0] << 16 | c.r[1] >> 16;  // 060B6812 xtrct r0,r1
L_060B6814:
    c.r[4] -= c.r[9];  // 060B6814 sub r9,r4
L_060B6816:
    c.r[0] = c.r[4];  // 060B6816 mov r4,r0
L_060B6818:
    c.r[0] += c.r[10];  // 060B6818 add r10,r0
L_060B681A:
    c.t = c.r[0] > c.r[12];  // 060B681A cmp/hi r12,r0
L_060B681C:
    { const bool k = c.t; c.r[6] += c.r[3]; if (k) { goto L_060B6842; } }  // 060B681C bt/s 0x060B6842 ; add r3,r6
L_060B6820:
    c.r[0] = c.r[6];  // 060B6820 mov r6,r0
L_060B6822:
    c.r[0] += c.r[11];  // 060B6822 add r11,r0
L_060B6824:
    c.t = c.r[0] > c.r[13];  // 060B6824 cmp/hi r13,r0
L_060B6826:
    { const bool k = c.t; c.r[3] = c.r[4] << 16 | c.r[4] >> 16; if (k) { goto L_060B6842; } }  // 060B6826 bt/s 0x060B6842 ; swap.w r4,r3
L_060B682A:
    c.r[4] -= c.r[2];  // 060B682A sub r2,r4
L_060B682C:
    c.r[10] += c.r[4];  // 060B682C add r4,r10
L_060B682E:
    c.t = c.r[10] > c.r[12];  // 060B682E cmp/hi r12,r10
L_060B6830:
    { const bool k = c.t; c.r[9] = c.r[6]; if (k) { goto L_060B6842; } }  // 060B6830 bt/s 0x060B6842 ; mov r6,r9
L_060B6834:
    c.r[6] -= c.r[8];  // 060B6834 sub r8,r6
L_060B6836:
    c.r[11] += c.r[6];  // 060B6836 add r6,r11
L_060B6838:
    c.t = c.r[11] > c.r[13];  // 060B6838 cmp/hi r13,r11
L_060B683A:
    { const bool k = c.t; c.r[4] = c.r[4] << 16 | c.r[4] >> 16; if (k) { goto L_060B6842; } }  // 060B683A bt/s 0x060B6842 ; swap.w r4,r4
L_060B683E:
    c.r[6] = c.r[4] << 16 | c.r[6] >> 16; SH2_POLL(c); goto L_060B65B4;  // 060B683E bra 0x060B65B4 ; xtrct r4,r6
L_060B6842:
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060B6842 mov.l @r15+,r8
L_060B6844:
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060B6844 mov.l @r15+,r9
L_060B6846:
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060B6846 mov.l @r15+,r10
L_060B6848:
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060B6848 mov.l @r15+,r11
L_060B684A:
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060B684A mov.l @r15+,r12
L_060B684C:
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060B684C mov.l @r15+,r13
L_060B684E:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060B684E mov.l @r15+,r14
L_060B6850:
    { const uint32_t x = c.pr; c.r[0] = 0x0u; c.pc = x; return; }  // 060B6850 rts ; mov #0,r0
L_060B6854:
    c.r[1] = 0x10u;  // 060B6854 mov #16,r1
L_060B6856:
    c.r[5] ^= c.r[1];  // 060B6856 xor r1,r5
L_060B6858:
    c.r[2] = 0u - c.r[2];  // 060B6858 neg r2,r2
L_060B685A:
    c.r[8] = 0u - c.r[8];  // 060B685A neg r8,r8
L_060B685C:
    c.r[0] = c.r[9];  // 060B685C mov r9,r0
L_060B685E:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B685E shar r0
L_060B6860:
    c.r[4] += c.r[0];  // 060B6860 add r0,r4
L_060B6862:
    c.r[0] = c.r[4];  // 060B6862 mov r4,r0
L_060B6864:
    c.r[0] += c.r[10];  // 060B6864 add r10,r0
L_060B6866:
    c.t = c.r[0] > c.r[12];  // 060B6866 cmp/hi r12,r0
L_060B6868:
    { const bool k = c.t; c.r[0] = c.r[3]; if (k) { goto L_060B693C; } }  // 060B6868 bt/s 0x060B693C ; mov r3,r0
L_060B686C:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B686C shar r0
L_060B686E:
    c.r[6] -= c.r[0];  // 060B686E sub r0,r6
L_060B6870:
    c.r[0] = c.r[6];  // 060B6870 mov r6,r0
L_060B6872:
    c.r[0] += c.r[11];  // 060B6872 add r11,r0
L_060B6874:
    c.t = c.r[0] > c.r[13];  // 060B6874 cmp/hi r13,r0
L_060B6876:
    { const bool k = c.t; c.r[1] = c.r[4] << 16 | c.r[4] >> 16; if (k) { goto L_060B693C; } }  // 060B6876 bt/s 0x060B693C ; swap.w r4,r1
L_060B687A:
    c.r[4] += c.r[2];  // 060B687A add r2,r4
L_060B687C:
    c.r[0] = c.r[4];  // 060B687C mov r4,r0
L_060B687E:
    c.r[0] += c.r[10];  // 060B687E add r10,r0
L_060B6880:
    c.t = c.r[0] > c.r[12];  // 060B6880 cmp/hi r12,r0
L_060B6882:
    { const bool k = c.t; st16(c.r[7], c.r[5]); if (k) { goto L_060B693C; } }  // 060B6882 bt/s 0x060B693C ; mov.w r5,@r7
L_060B6886:
    c.r[5] = c.r[6];  // 060B6886 mov r6,r5
L_060B6888:
    c.r[6] += c.r[8];  // 060B6888 add r8,r6
L_060B688A:
    c.r[0] = c.r[6];  // 060B688A mov r6,r0
L_060B688C:
    c.r[0] += c.r[11];  // 060B688C add r11,r0
L_060B688E:
    c.t = c.r[0] > c.r[13];  // 060B688E cmp/hi r13,r0
L_060B6890:
    { const bool k = c.t; c.r[0] = c.r[4] << 16 | c.r[4] >> 16; if (k) { goto L_060B693C; } }  // 060B6890 bt/s 0x060B693C ; swap.w r4,r0
L_060B6894:
    c.r[5] = c.r[1] << 16 | c.r[5] >> 16;  // 060B6894 xtrct r1,r5
L_060B6896:
    c.r[1] = c.r[6];  // 060B6896 mov r6,r1
L_060B6898:
    c.r[1] = c.r[0] << 16 | c.r[1] >> 16;  // 060B6898 xtrct r0,r1
L_060B689A:
    c.r[4] -= c.r[9];  // 060B689A sub r9,r4
L_060B689C:
    c.r[0] = c.r[4];  // 060B689C mov r4,r0
L_060B689E:
    c.r[0] += c.r[10];  // 060B689E add r10,r0
L_060B68A0:
    c.t = c.r[0] > c.r[12];  // 060B68A0 cmp/hi r12,r0
L_060B68A2:
    { const bool k = c.t; c.r[6] += c.r[3]; if (k) { goto L_060B693C; } }  // 060B68A2 bt/s 0x060B693C ; add r3,r6
L_060B68A6:
    c.r[0] = c.r[6];  // 060B68A6 mov r6,r0
L_060B68A8:
    c.r[0] += c.r[11];  // 060B68A8 add r11,r0
L_060B68AA:
    c.t = c.r[0] > c.r[13];  // 060B68AA cmp/hi r13,r0
L_060B68AC:
    { const bool k = c.t; c.r[3] = c.r[4] << 16 | c.r[4] >> 16; if (k) { goto L_060B693C; } }  // 060B68AC bt/s 0x060B693C ; swap.w r4,r3
L_060B68B0:
    c.r[4] -= c.r[2];  // 060B68B0 sub r2,r4
L_060B68B2:
    c.r[10] += c.r[4];  // 060B68B2 add r4,r10
L_060B68B4:
    c.t = c.r[10] > c.r[12];  // 060B68B4 cmp/hi r12,r10
L_060B68B6:
    { const bool k = c.t; c.r[9] = c.r[6]; if (k) { goto L_060B693C; } }  // 060B68B6 bt/s 0x060B693C ; mov r6,r9
L_060B68BA:
    c.r[6] -= c.r[8];  // 060B68BA sub r8,r6
L_060B68BC:
    c.r[11] += c.r[6];  // 060B68BC add r6,r11
L_060B68BE:
    c.t = c.r[11] > c.r[13];  // 060B68BE cmp/hi r13,r11
L_060B68C0:
    { const bool k = c.t; c.r[4] = c.r[4] << 16 | c.r[4] >> 16; if (k) { goto L_060B693C; } }  // 060B68C0 bt/s 0x060B693C ; swap.w r4,r4
L_060B68C4:
    c.r[6] = c.r[4] << 16 | c.r[6] >> 16; SH2_POLL(c); goto L_060B65B4;  // 060B68C4 bra 0x060B65B4 ; xtrct r4,r6
L_060B68C8:
    c.r[1] = 0x20u;  // 060B68C8 mov #32,r1
L_060B68CA:
    c.r[5] ^= c.r[1];  // 060B68CA xor r1,r5
L_060B68CC:
    c.r[3] = 0u - c.r[3];  // 060B68CC neg r3,r3
L_060B68CE:
    c.r[9] = 0u - c.r[9];  // 060B68CE neg r9,r9
L_060B68D0:
    c.r[0] = c.r[2];  // 060B68D0 mov r2,r0
L_060B68D2:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B68D2 shar r0
L_060B68D4:
    c.r[4] -= c.r[0];  // 060B68D4 sub r0,r4
L_060B68D6:
    c.r[0] = c.r[4];  // 060B68D6 mov r4,r0
L_060B68D8:
    c.r[0] += c.r[10];  // 060B68D8 add r10,r0
L_060B68DA:
    c.t = c.r[0] > c.r[12];  // 060B68DA cmp/hi r12,r0
L_060B68DC:
    { const bool k = c.t; c.r[0] = c.r[8]; if (k) { goto L_060B693C; } }  // 060B68DC bt/s 0x060B693C ; mov r8,r0
L_060B68E0:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B68E0 shar r0
L_060B68E2:
    c.r[6] -= c.r[0];  // 060B68E2 sub r0,r6
L_060B68E4:
    c.r[0] = c.r[6];  // 060B68E4 mov r6,r0
L_060B68E6:
    c.r[0] += c.r[11];  // 060B68E6 add r11,r0
L_060B68E8:
    c.t = c.r[0] > c.r[13];  // 060B68E8 cmp/hi r13,r0
L_060B68EA:
    { const bool k = c.t; c.r[1] = c.r[4] << 16 | c.r[4] >> 16; if (k) { goto L_060B693C; } }  // 060B68EA bt/s 0x060B693C ; swap.w r4,r1
L_060B68EE:
    c.r[4] += c.r[2];  // 060B68EE add r2,r4
L_060B68F0:
    c.r[0] = c.r[4];  // 060B68F0 mov r4,r0
L_060B68F2:
    c.r[0] += c.r[10];  // 060B68F2 add r10,r0
L_060B68F4:
    c.t = c.r[0] > c.r[12];  // 060B68F4 cmp/hi r12,r0
L_060B68F6:
    { const bool k = c.t; st16(c.r[7], c.r[5]); if (k) { goto L_060B693C; } }  // 060B68F6 bt/s 0x060B693C ; mov.w r5,@r7
L_060B68FA:
    c.r[5] = c.r[6];  // 060B68FA mov r6,r5
L_060B68FC:
    c.r[6] += c.r[8];  // 060B68FC add r8,r6
L_060B68FE:
    c.r[0] = c.r[6];  // 060B68FE mov r6,r0
L_060B6900:
    c.r[0] += c.r[11];  // 060B6900 add r11,r0
L_060B6902:
    c.t = c.r[0] > c.r[13];  // 060B6902 cmp/hi r13,r0
L_060B6904:
    { const bool k = c.t; c.r[0] = c.r[4] << 16 | c.r[4] >> 16; if (k) { goto L_060B693C; } }  // 060B6904 bt/s 0x060B693C ; swap.w r4,r0
L_060B6908:
    c.r[5] = c.r[1] << 16 | c.r[5] >> 16;  // 060B6908 xtrct r1,r5
L_060B690A:
    c.r[1] = c.r[6];  // 060B690A mov r6,r1
L_060B690C:
    c.r[1] = c.r[0] << 16 | c.r[1] >> 16;  // 060B690C xtrct r0,r1
L_060B690E:
    c.r[4] -= c.r[9];  // 060B690E sub r9,r4
L_060B6910:
    c.r[0] = c.r[4];  // 060B6910 mov r4,r0
L_060B6912:
    c.r[0] += c.r[10];  // 060B6912 add r10,r0
L_060B6914:
    c.t = c.r[0] > c.r[12];  // 060B6914 cmp/hi r12,r0
L_060B6916:
    { const bool k = c.t; c.r[6] += c.r[3]; if (k) { goto L_060B693C; } }  // 060B6916 bt/s 0x060B693C ; add r3,r6
L_060B691A:
    c.r[0] = c.r[6];  // 060B691A mov r6,r0
L_060B691C:
    c.r[0] += c.r[11];  // 060B691C add r11,r0
L_060B691E:
    c.t = c.r[0] > c.r[13];  // 060B691E cmp/hi r13,r0
L_060B6920:
    { const bool k = c.t; c.r[3] = c.r[4] << 16 | c.r[4] >> 16; if (k) { goto L_060B693C; } }  // 060B6920 bt/s 0x060B693C ; swap.w r4,r3
L_060B6924:
    c.r[4] -= c.r[2];  // 060B6924 sub r2,r4
L_060B6926:
    c.r[10] += c.r[4];  // 060B6926 add r4,r10
L_060B6928:
    c.t = c.r[10] > c.r[12];  // 060B6928 cmp/hi r12,r10
L_060B692A:
    { const bool k = c.t; c.r[9] = c.r[6]; if (k) { goto L_060B693C; } }  // 060B692A bt/s 0x060B693C ; mov r6,r9
L_060B692E:
    c.r[6] -= c.r[8];  // 060B692E sub r8,r6
L_060B6930:
    c.r[11] += c.r[6];  // 060B6930 add r6,r11
L_060B6932:
    c.t = c.r[11] > c.r[13];  // 060B6932 cmp/hi r13,r11
L_060B6934:
    { const bool k = c.t; c.r[4] = c.r[4] << 16 | c.r[4] >> 16; if (k) { goto L_060B693C; } }  // 060B6934 bt/s 0x060B693C ; swap.w r4,r4
L_060B6938:
    c.r[6] = c.r[4] << 16 | c.r[6] >> 16; SH2_POLL(c); goto L_060B65B4;  // 060B6938 bra 0x060B65B4 ; xtrct r4,r6
L_060B693C:
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060B693C mov.l @r15+,r8
L_060B693E:
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060B693E mov.l @r15+,r9
L_060B6940:
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060B6940 mov.l @r15+,r10
L_060B6942:
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060B6942 mov.l @r15+,r11
L_060B6944:
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060B6944 mov.l @r15+,r12
L_060B6946:
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060B6946 mov.l @r15+,r13
L_060B6948:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060B6948 mov.l @r15+,r14
L_060B694A:
    { const uint32_t x = c.pr; c.r[0] = 0x0u; c.pc = x; return; }  // 060B694A rts ; mov #0,r0
}

void f_060AE660(SH2Context& c) {
    ran[2968] = 1;
    c.r[0] = c.r[4];  // 060AE660 mov r4,r0
    c.r[0] &= 0x40u;  // 060AE662 and #64,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060AE664 shlr r0
    c.r[0] |= c.r[4];  // 060AE666 or r4,r0
    { const uint32_t x = c.pr; st16(c.gbr + 424, c.r[0]); c.pc = x; return; }  // 060AE668 rts ; mov.w r0,@(424,gbr)
}

void f_060AE66C(SH2Context& c) {
    ran[2969] = 1;
    c.r[0] = ld32(0x060AE674u);  // 060AE66C mov.l 0x060AE674,r0
    { const uint32_t x = c.pr; st8(c.r[0] + c.r[4], c.r[5]); c.pc = x; return; }  // 060AE66E rts ; mov.b r5,@(r0,r4)
}

void f_060AE678(SH2Context& c) {
    ran[2970] = 1;
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 428);  // 060AE678 mov.w @(428,gbr),r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x060AE684u);  // 060AE67A mov.w 0x060AE684,r1
    c.r[0] &= c.r[1];  // 060AE67C and r1,r0
    c.r[0] |= c.r[4];  // 060AE67E or r4,r0
    { const uint32_t x = c.pr; st16(c.gbr + 428, c.r[0]); c.pc = x; return; }  // 060AE680 rts ; mov.w r0,@(428,gbr)
}

void f_060AE688(SH2Context& c) {
    ran[2971] = 1;
    c.r[1] = ld32(0x060AE690u);  // 060AE688 mov.l 0x060AE690,r1
    c.r[0] = c.r[4];  // 060AE68A mov r4,r0
    { const uint32_t x = c.pr; st8(c.r[1] + 1, c.r[0]); c.pc = x; return; }  // 060AE68C rts ; mov.b r0,@(1,r1)
}

void f_060AE694(SH2Context& c) {
    ran[2972] = 1;
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 416);  // 060AE694 mov.w @(416,gbr),r0
    c.r[1] = 0xFFFFFFF8u;  // 060AE696 mov #-8,r1
    c.r[0] = (c.r[0] & 0xFFFF0000u) | (c.r[0] & 0xFFu) << 8 | (c.r[0] >> 8 & 0xFFu);  // 060AE698 swap.b r0,r0
    c.r[0] &= c.r[1];  // 060AE69A and r1,r0
    c.r[0] |= c.r[4];  // 060AE69C or r4,r0
    c.r[0] = (c.r[0] & 0xFFFF0000u) | (c.r[0] & 0xFFu) << 8 | (c.r[0] >> 8 & 0xFFu);  // 060AE69E swap.b r0,r0
    { const uint32_t x = c.pr; st16(c.gbr + 416, c.r[0]); c.pc = x; return; }  // 060AE6A0 rts ; mov.w r0,@(416,gbr)
}

void f_060AE6A4(SH2Context& c) {
    ran[2973] = 1;
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 416);  // 060AE6A4 mov.w @(416,gbr),r0
    c.r[1] = 0xFFFFFFCFu;  // 060AE6A6 mov #-49,r1
    c.r[0] = (c.r[0] & 0xFFFF0000u) | (c.r[0] & 0xFFu) << 8 | (c.r[0] >> 8 & 0xFFu);  // 060AE6A8 swap.b r0,r0
    c.r[0] &= c.r[1];  // 060AE6AA and r1,r0
    c.r[4] <<= 2;  // 060AE6AC shll2 r4
    c.r[4] <<= 2;  // 060AE6AE shll2 r4
    c.r[0] |= c.r[4];  // 060AE6B0 or r4,r0
    c.r[0] = (c.r[0] & 0xFFFF0000u) | (c.r[0] & 0xFFu) << 8 | (c.r[0] >> 8 & 0xFFu);  // 060AE6B2 swap.b r0,r0
    { const uint32_t x = c.pr; st16(c.gbr + 416, c.r[0]); c.pc = x; return; }  // 060AE6B4 rts ; mov.w r0,@(416,gbr)
}

void f_060AE6B8(SH2Context& c) {
    ran[2974] = 1;
    c.r[1] = ld32(0x060AE6C8u);  // 060AE6B8 mov.l 0x060AE6C8,r1
    c.r[1] += c.r[4];  // 060AE6BA add r4,r1
    st16(c.r[1], c.r[5]);  // 060AE6BC mov.w r5,@r1
    c.t = c.r[4] & 1; c.r[4] >>= 1;  // 060AE6BE shlr r4
    c.r[0] = c.r[4];  // 060AE6C0 mov r4,r0
    { const uint32_t x = c.pr; st32(c.gbr + 360, c.r[0]); c.pc = x; return; }  // 060AE6C2 rts ; mov.l r0,@(360,gbr)
}

void f_060AE6CC(SH2Context& c) {
    ran[2975] = 1;
    c.t = 1;  // 060AE6CC sett
    { uint32_t t = c.r[4] & 1; c.r[4] = c.r[4] >> 1 | c.t << 31; c.t = t; }  // 060AE6CE rotcr r4
    c.r[0] = c.r[4];  // 060AE6D0 mov r4,r0
    { const uint32_t x = c.pr; st32(c.gbr + 360, c.r[0]); c.pc = x; return; }  // 060AE6D2 rts ; mov.l r0,@(360,gbr)
}

void f_060AE6D8(SH2Context& c) {
    ran[2976] = 1;
    c.r[0] = c.r[4];  // 060AE6D8 mov r4,r0
    st32(c.gbr + 756, c.r[0]);  // 060AE6DA mov.l r0,@(756,gbr)
    c.r[0] = c.r[5];  // 060AE6DC mov r5,r0
    st32(c.gbr + 760, c.r[0]);  // 060AE6DE mov.l r0,@(760,gbr)
    c.r[4] >>= 16;  // 060AE6E0 shlr16 r4
    c.r[0] = c.r[4] << 16 | c.r[0] >> 16;  // 060AE6E2 xtrct r4,r0
    { const uint32_t x = c.pr; st32(c.gbr + 340, c.r[0]); c.pc = x; return; }  // 060AE6E4 rts ; mov.l r0,@(340,gbr)
}

void f_060AE6E8(SH2Context& c) {
    ran[2977] = 1;
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060AE6E8 sts.l pr,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060AE6EA mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060AE6EC mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060AE6EE mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060AE6F0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060AE6F2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060AE6F4 mov.l r8,@-r15
    c.r[12] = c.r[4];  // 060AE6F6 mov r4,r12
    c.r[0] = (uint32_t)(int16_t)ld16(0x060AE770u);  // 060AE6F8 mov.w 0x060AE770,r0
    c.r[15] -= c.r[0];  // 060AE6FA sub r0,r15
    c.r[11] = c.r[15];  // 060AE6FC mov r15,r11
    c.r[0] = 0x24u;  // 060AE6FE mov #36,r0
    c.r[11] += c.r[0];  // 060AE700 add r0,r11
    c.r[10] = c.r[11];  // 060AE702 mov r11,r10
    c.r[0] = 0xFFFFFFFFu;  // 060AE704 mov #-1,r0
    c.r[1] = c.r[11];  // 060AE706 mov r11,r1
    c.r[1] -= 4;  // 060AE708 add #-4,r1
    st32(c.r[1], c.r[0]);  // 060AE70A mov.l r0,@r1
    c.r[8] = c.r[11];  // 060AE70C mov r11,r8
    c.r[8] -= 4;  // 060AE70E add #-4,r8
    c.r[0] = ld32(0x060AEAA4u);  // 060AE710 mov.l 0x060AEAA4,r0
    c.r[1] = ld32(0x060AEAA4u);  // 060AE712 mov.l 0x060AEAA4,r1
    c.r[3] = 0x4u;  // 060AE714 mov #4,r3
L_060AE716:
    c.r[8] -= 4; st32(c.r[8], c.r[1]);  // 060AE716 mov.l r1,@-r8
    c.r[3] -= 1; c.t = c.r[3] == 0;  // 060AE718 dt r3
    { const bool k = !c.t; c.r[8] -= 4; st32(c.r[8], c.r[0]); if (k) { SH2_POLL(c); goto L_060AE716; } }  // 060AE71A bf/s 0x060AE716 ; mov.l r0,@-r8
    c.r[0] = 0x1u;  // 060AE71E mov #1,r0
    c.t = (c.r[12] & c.r[0]) == 0;  // 060AE720 tst r0,r12
    if (c.t) { goto L_060AE77A; }  // 060AE722 bt 0x060AE77A
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 344);  // 060AE724 mov.w @(344,gbr),r0
    c.r[1] = 0x3u;  // 060AE726 mov #3,r1
    c.r[1] &= c.r[0];  // 060AE728 and r0,r1
    c.r[0] = 0x060AEABCu;  // 060AE72A mova 0x060AEABC,r0
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060AE72C mov.b @(r0,r1),r4
    c.r[1] = c.r[0];  // 060AE72E mov r0,r1
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 232);  // 060AE730 mov.w @(232,gbr),r0
    c.r[1] += 4;  // 060AE732 add #4,r1
    c.r[0] >>= 2;  // 060AE734 shlr2 r0
    c.r[0] >>= 2;  // 060AE736 shlr2 r0
    c.r[0] &= 0x7u;  // 060AE738 and #7,r0
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060AE73A mov.b @(r0,r1),r5
    c.r[6] = 0x0u;  // 060AE73C mov #0,r6
    c.r[0] = ld32(c.gbr + 508);  // 060AE73E mov.l @(508,gbr),r0
    c.r[1] -= 20;  // 060AE740 add #-20,r1
    c.r[0] >>= 16;  // 060AE742 shlr16 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060AE744 shlr r0
    c.r[0] &= 0x3u;  // 060AE746 and #3,r0
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060AE748 mov.b @(r0,r1),r7
    c.r[0] = ld32(c.gbr + 484);  // 060AE74A mov.l @(484,gbr),r0
    c.r[0] >>= 16;  // 060AE74C shlr16 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060AE74E shlr r0
    c.r[0] &= 0x3u;  // 060AE750 and #3,r0
    c.r[9] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060AE752 mov.b @(r0,r1),r9
    c.r[8] = 0x4u;  // 060AE754 mov #4,r8
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 346);  // 060AE756 mov.w @(346,gbr),r0
    c.t = (c.r[0] & 0x1u) == 0;  // 060AE758 tst #1,r0
    if (c.t) { goto L_060AE762; }  // 060AE75A bt 0x060AE762
    c.r[1] = 0xFFFFFFFCu;  // 060AE75C mov #-4,r1
    c.pr = 0x060AE762u; c.r[0] = 0xCu; SH2_POLL(c); sh2_call(c, 0x060AEA8Au); if (c.pc != 0x060AE762u) return;  // 060AE75E bsr 0x060AEA8A ; mov #12,r0
L_060AE762:
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 232);  // 060AE762 mov.w @(232,gbr),r0
    c.t = (c.r[0] & 0x2u) == 0;  // 060AE764 tst #2,r0
    if (!c.t) { goto L_060AE772; }  // 060AE766 bf 0x060AE772
    c.pr = 0x060AE76Cu; SH2_POLL(c); sh2_call(c, 0x060AEA1Eu); if (c.pc != 0x060AE76Cu) return;  // 060AE768 bsr 0x060AEA1E ; nop
    goto L_060AE77A;  // 060AE76C bra 0x060AE77A ; nop
L_060AE772:
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 232);  // 060AE772 mov.w @(232,gbr),r0
    c.r[0] >>= 2;  // 060AE774 shlr2 r0
    c.pr = 0x060AE77Au; c.r[0] &= 0x1Fu; SH2_POLL(c); sh2_call(c, 0x060AEA56u); if (c.pc != 0x060AE77Au) return;  // 060AE776 bsr 0x060AEA56 ; and #31,r0
L_060AE77A:
    c.r[0] = 0x2u;  // 060AE77A mov #2,r0
    c.t = (c.r[12] & c.r[0]) == 0;  // 060AE77C tst r0,r12
    if (c.t) { goto L_060AE7DE; }  // 060AE77E bt 0x060AE7DE
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 344);  // 060AE780 mov.w @(344,gbr),r0
    c.r[1] = 0x3u;  // 060AE782 mov #3,r1
    c.r[0] >>= 8;  // 060AE784 shlr8 r0
    c.r[1] &= c.r[0];  // 060AE786 and r0,r1
    c.r[0] = 0x060AEABCu;  // 060AE788 mova 0x060AEABC,r0
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060AE78A mov.b @(r0,r1),r4
    c.r[1] = c.r[0];  // 060AE78C mov r0,r1
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 232);  // 060AE78E mov.w @(232,gbr),r0
    c.r[1] += 4;  // 060AE790 add #4,r1
    c.r[0] >>= 8;  // 060AE792 shlr8 r0
    c.r[0] >>= 2;  // 060AE794 shlr2 r0
    c.r[0] >>= 2;  // 060AE796 shlr2 r0
    c.r[0] &= 0x7u;  // 060AE798 and #7,r0
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060AE79A mov.b @(r0,r1),r5
    c.r[6] = 0x1u;  // 060AE79C mov #1,r6
    c.r[0] = ld32(c.gbr + 512);  // 060AE79E mov.l @(512,gbr),r0
    c.r[1] -= 20;  // 060AE7A0 add #-20,r1
    c.r[0] >>= 16;  // 060AE7A2 shlr16 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060AE7A4 shlr r0
    c.r[0] &= 0x3u;  // 060AE7A6 and #3,r0
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060AE7A8 mov.b @(r0,r1),r7
    c.r[0] = ld32(c.gbr + 488);  // 060AE7AA mov.l @(488,gbr),r0
    c.r[0] >>= 16;  // 060AE7AC shlr16 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060AE7AE shlr r0
    c.r[0] &= 0x3u;  // 060AE7B0 and #3,r0
    c.r[9] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060AE7B2 mov.b @(r0,r1),r9
    c.r[8] = 0x5u;  // 060AE7B4 mov #5,r8
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 346);  // 060AE7B6 mov.w @(346,gbr),r0
    c.r[0] >>= 8;  // 060AE7B8 shlr8 r0
    c.t = (c.r[0] & 0x1u) == 0;  // 060AE7BA tst #1,r0
    if (c.t) { goto L_060AE7C4; }  // 060AE7BC bt 0x060AE7C4
    c.r[0] = 0xFFFFFFFBu;  // 060AE7BE mov #-5,r0
    c.pr = 0x060AE7C4u; c.r[0] = 0xDu; SH2_POLL(c); sh2_call(c, 0x060AEA8Au); if (c.pc != 0x060AE7C4u) return;  // 060AE7C0 bsr 0x060AEA8A ; mov #13,r0
L_060AE7C4:
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 232);  // 060AE7C4 mov.w @(232,gbr),r0
    c.r[0] >>= 8;  // 060AE7C6 shlr8 r0
    c.t = (c.r[0] & 0x2u) == 0;  // 060AE7C8 tst #2,r0
    if (!c.t) { goto L_060AE7D4; }  // 060AE7CA bf 0x060AE7D4
    c.pr = 0x060AE7D0u; SH2_POLL(c); sh2_call(c, 0x060AEA1Eu); if (c.pc != 0x060AE7D0u) return;  // 060AE7CC bsr 0x060AEA1E ; nop
    goto L_060AE7DE;  // 060AE7D0 bra 0x060AE7DE ; nop
L_060AE7D4:
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 232);  // 060AE7D4 mov.w @(232,gbr),r0
    c.r[0] >>= 8;  // 060AE7D6 shlr8 r0
    c.r[0] >>= 2;  // 060AE7D8 shlr2 r0
    c.pr = 0x060AE7DEu; c.r[0] &= 0xFu; SH2_POLL(c); sh2_call(c, 0x060AEA56u); if (c.pc != 0x060AE7DEu) return;  // 060AE7DA bsr 0x060AEA56 ; and #15,r0
L_060AE7DE:
    c.r[0] = 0x4u;  // 060AE7DE mov #4,r0
    c.t = (c.r[12] & c.r[0]) == 0;  // 060AE7E0 tst r0,r12
    if (c.t) { goto L_060AE810; }  // 060AE7E2 bt 0x060AE810
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 234);  // 060AE7E4 mov.w @(234,gbr),r0
    c.r[4] = 0x1u;  // 060AE7E6 mov #1,r4
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060AE7E8 shlr r0
    c.r[0] &= 0x1u;  // 060AE7EA and #1,r0
    c.r[1] = c.r[0];  // 060AE7EC mov r0,r1
    c.r[0] = 0x060AEAC0u;  // 060AE7EE mova 0x060AEAC0,r0
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060AE7F0 mov.b @(r0,r1),r5
    c.r[1] = c.r[0];  // 060AE7F2 mov r0,r1
    c.r[6] = 0x2u;  // 060AE7F4 mov #2,r6
    c.r[0] = ld32(c.gbr + 516);  // 060AE7F6 mov.l @(516,gbr),r0
    c.r[1] -= 20;  // 060AE7F8 add #-20,r1
    c.r[0] >>= 16;  // 060AE7FA shlr16 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060AE7FC shlr r0
    c.r[0] &= 0x3u;  // 060AE7FE and #3,r0
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060AE800 mov.b @(r0,r1),r7
    c.r[0] = ld32(c.gbr + 492);  // 060AE802 mov.l @(492,gbr),r0
    c.r[0] >>= 16;  // 060AE804 shlr16 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060AE806 shlr r0
    c.r[0] &= 0x3u;  // 060AE808 and #3,r0
    c.r[9] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060AE80A mov.b @(r0,r1),r9
    c.pr = 0x060AE810u; c.r[8] = 0x6u; SH2_POLL(c); sh2_call(c, 0x060AEA1Eu); if (c.pc != 0x060AE810u) return;  // 060AE80C bsr 0x060AEA1E ; mov #6,r8
L_060AE810:
    c.r[0] = 0x8u;  // 060AE810 mov #8,r0
    c.t = (c.r[12] & c.r[0]) == 0;  // 060AE812 tst r0,r12
    if (c.t) { goto L_060AE846; }  // 060AE814 bt 0x060AE846
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 234);  // 060AE816 mov.w @(234,gbr),r0
    c.r[4] = 0x1u;  // 060AE818 mov #1,r4
    c.r[0] >>= 2;  // 060AE81A shlr2 r0
    c.r[0] >>= 2;  // 060AE81C shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060AE81E shlr r0
    c.r[0] &= 0x1u;  // 060AE820 and #1,r0
    c.r[1] = c.r[0];  // 060AE822 mov r0,r1
    c.r[0] = 0x060AEAC0u;  // 060AE824 mova 0x060AEAC0,r0
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060AE826 mov.b @(r0,r1),r5
    c.r[1] = c.r[0];  // 060AE828 mov r0,r1
    c.r[6] = 0x3u;  // 060AE82A mov #3,r6
    c.r[0] = ld32(c.gbr + 520);  // 060AE82C mov.l @(520,gbr),r0
    c.r[1] -= 20;  // 060AE82E add #-20,r1
    c.r[0] >>= 16;  // 060AE830 shlr16 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060AE832 shlr r0
    c.r[0] &= 0x3u;  // 060AE834 and #3,r0
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060AE836 mov.b @(r0,r1),r7
    c.r[0] = ld32(c.gbr + 496);  // 060AE838 mov.l @(496,gbr),r0
    c.r[0] >>= 16;  // 060AE83A shlr16 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060AE83C shlr r0
    c.r[0] &= 0x3u;  // 060AE83E and #3,r0
    c.r[9] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060AE840 mov.b @(r0,r1),r9
    c.pr = 0x060AE846u; c.r[8] = 0x7u; SH2_POLL(c); sh2_call(c, 0x060AEA1Eu); if (c.pc != 0x060AE846u) return;  // 060AE842 bsr 0x060AEA1E ; mov #7,r8
L_060AE846:
    c.r[0] = 0xFFFFFFFFu;  // 060AE846 mov #-1,r0
    st8(c.r[10], c.r[0]);  // 060AE848 mov.b r0,@(0,r10)
    c.r[10] = c.r[11];  // 060AE84A mov r11,r10
    c.r[9] = c.r[11];  // 060AE84C mov r11,r9
    c.r[8] = c.r[11];  // 060AE84E mov r11,r8
    c.r[9] -= 4;  // 060AE850 add #-4,r9
    c.r[8] -= 36;  // 060AE852 add #-36,r8
L_060AE854:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[10] + 2);  // 060AE854 mov.b @(2,r10),r0
    c.r[6] = 0xFu;  // 060AE856 mov #15,r6
    c.r[5] = c.r[0];  // 060AE858 mov r0,r5
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 176);  // 060AE85A mov.b @(176,gbr),r0
    c.t = (c.r[0] & 0x8u) == 0;  // 060AE85C tst #8,r0
    if (!c.t) { goto L_060AE866; }  // 060AE85E bf 0x060AE866
    c.r[6] <<= 2;  // 060AE860 shll2 r6
    c.r[6] <<= 2;  // 060AE862 shll2 r6
    c.r[6] += 15;  // 060AE864 add #15,r6
L_060AE866:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[10]);  // 060AE866 mov.b @(0,r10),r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 060AE868 cmp/eq #-1,r0
    if (!c.t) { goto L_060AE870; }  // 060AE86A bf 0x060AE870
    goto L_060AE966;  // 060AE86C bra 0x060AE966 ; nop
L_060AE870:
    c.r[4] = c.r[0];  // 060AE870 mov r0,r4
    c.t = (c.r[0] & 0x80u) == 0;  // 060AE872 tst #128,r0
    if (c.t) { goto L_060AE894; }  // 060AE874 bt 0x060AE894
    c.t = c.r[0] == 0xFFFFFFFCu;  // 060AE876 cmp/eq #-4,r0
    if (c.t) { goto L_060AE88E; }  // 060AE878 bt 0x060AE88E
    c.t = c.r[0] == 0xFFFFFFFBu;  // 060AE87A cmp/eq #-5,r0
    if (!c.t) { goto L_060AE8CC; }  // 060AE87C bf 0x060AE8CC
    c.r[1] = 0x7u;  // 060AE87E mov #7,r1
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 346);  // 060AE880 mov.w @(346,gbr),r0
    c.t = (c.r[0] & 0x1u) == 0;  // 060AE882 tst #1,r0
    if (c.t) { goto L_060AE888; }  // 060AE884 bt 0x060AE888
    c.r[1] = 0x6u;  // 060AE886 mov #6,r1
L_060AE888:
    c.r[6] &= c.r[1];  // 060AE888 and r1,r6
    goto L_060AE8CC;  // 060AE88A bra 0x060AE8CC ; nop
L_060AE88E:
    c.r[1] = 0x3u;  // 060AE88E mov #3,r1
    c.r[6] &= c.r[1]; goto L_060AE8CC;  // 060AE890 bra 0x060AE8CC ; and r1,r6
L_060AE894:
    c.r[1] = c.r[0];  // 060AE894 mov r0,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 176);  // 060AE896 mov.b @(176,gbr),r0
    c.r[1] += c.r[11];  // 060AE898 add r11,r1
    c.r[2] = c.r[10];  // 060AE89A mov r10,r2
    c.r[1] += 3;  // 060AE89C add #3,r1
    c.r[2] += 1;  // 060AE89E add #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060AE8A0 mov.b @r1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060AE8A2 mov.b @r2,r2
    c.t = (c.r[1] & c.r[1]) == 0;  // 060AE8A4 tst r1,r1
    { const bool k = !c.t; c.r[3] = 0x4u; if (k) { goto L_060AE8C2; } }  // 060AE8A6 bf/s 0x060AE8C2 ; mov #4,r3
    c.t = c.r[2] == c.r[3];  // 060AE8AA cmp/eq r3,r2
    { const bool k = c.t; c.r[3] = 0x5u; if (k) { goto L_060AE8B4; } }  // 060AE8AC bt/s 0x060AE8B4 ; mov #5,r3
    c.t = c.r[2] == c.r[3];  // 060AE8B0 cmp/eq r3,r2
    { const bool k = !c.t; c.r[2] = 0xFFFFFFFFu; if (k) { goto L_060AE8C2; } }  // 060AE8B2 bf/s 0x060AE8C2 ; mov #-1,r2
    goto L_060AE8B6;
L_060AE8B4:
    c.r[2] = 0xFFFFFFFFu;  // 060AE8B4 mov #-1,r2
L_060AE8B6:
    c.t = (c.r[0] & 0x8u) == 0;  // 060AE8B6 tst #8,r0
    { const bool k = c.t; c.r[2] = c.r[2] & 0xFFu; if (k) { goto L_060AE8CA; } }  // 060AE8B8 bt/s 0x060AE8CA ; extu.b r2,r2
    c.r[2] >>= 2;  // 060AE8BC shlr2 r2
    c.r[2] >>= 2; goto L_060AE8CA;  // 060AE8BE bra 0x060AE8CA ; shlr2 r2
L_060AE8C2:
    c.r[0] &= 0x8u;  // 060AE8C2 and #8,r0
    c.r[1] += c.r[0];  // 060AE8C4 add r0,r1
    c.r[0] = 0x060AEAC8u;  // 060AE8C6 mova 0x060AEAC8,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060AE8C8 mov.b @(r0,r1),r2
L_060AE8CA:
    c.r[6] &= c.r[2];  // 060AE8CA and r2,r6
L_060AE8CC:
    c.r[1] = 0x1u;  // 060AE8CC mov #1,r1
    c.r[0] = 0x0u;  // 060AE8CE mov #0,r0
L_060AE8D0:
    c.t = (c.r[5] & c.r[1]) == 0;  // 060AE8D0 tst r1,r5
    if (c.t) { goto L_060AE8D8; }  // 060AE8D2 bt 0x060AE8D8
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 060AE8D4 mov.b @(r0,r9),r2
    c.r[6] &= c.r[2];  // 060AE8D6 and r2,r6
L_060AE8D8:
    c.t = c.r[1] >> 31; c.r[1] <<= 1;  // 060AE8D8 shll r1
    c.t = c.r[0] == 0x3u;  // 060AE8DA cmp/eq #3,r0
    { const bool k = !c.t; c.r[0] += 1; if (k) { SH2_POLL(c); goto L_060AE8D0; } }  // 060AE8DC bf/s 0x060AE8D0 ; add #1,r0
    c.t = (c.r[6] & c.r[6]) == 0;  // 060AE8E0 tst r6,r6
    if (c.t) { goto L_060AE924; }  // 060AE8E2 bt 0x060AE924
    c.r[7] = 0x0u;  // 060AE8E4 mov #0,r7
L_060AE8E6:
    c.t = c.r[6] & 1; c.r[6] >>= 1;  // 060AE8E6 shlr r6
    if (c.t) { goto L_060AE8EE; }  // 060AE8E8 bt 0x060AE8EE
    c.r[7] += 1; SH2_POLL(c); goto L_060AE8E6;  // 060AE8EA bra 0x060AE8E6 ; add #1,r7
L_060AE8EE:
    c.r[0] = c.r[7];  // 060AE8EE mov r7,r0
    st8(c.r[10] + 3, c.r[0]);  // 060AE8F0 mov.b r0,@(3,r10)
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[10] + 1);  // 060AE8F2 mov.b @(1,r10),r0
    c.r[3] = c.r[0];  // 060AE8F4 mov r0,r3
    c.r[0] = 0x060AEAACu;  // 060AE8F6 mova 0x060AEAAC,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 060AE8F8 mov.b @(r0,r7),r1
    c.r[2] = ~c.r[1];  // 060AE8FA not r1,r2
    c.r[1] = 0x1u;  // 060AE8FC mov #1,r1
    c.r[0] = 0x0u;  // 060AE8FE mov #0,r0
    c.r[4] = c.r[8];  // 060AE900 mov r8,r4
    c.r[4] += c.r[7];  // 060AE902 add r7,r4
L_060AE904:
    c.t = (c.r[5] & c.r[1]) == 0;  // 060AE904 tst r1,r5
    if (c.t) { goto L_060AE918; }  // 060AE906 bt 0x060AE918
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 060AE908 mov.b @(r0,r9),r6
    c.r[6] &= c.r[2];  // 060AE90A and r2,r6
    st8(c.r[0] + c.r[9], c.r[6]);  // 060AE90C mov.b r6,@(r0,r9)
    c.r[6] = c.r[0];  // 060AE90E mov r0,r6
    c.r[6] <<= 2;  // 060AE910 shll2 r6
    c.t = c.r[6] >> 31; c.r[6] <<= 1;  // 060AE912 shll r6
    c.r[6] += c.r[4];  // 060AE914 add r4,r6
    st8(c.r[6], c.r[3]);  // 060AE916 mov.b r3,@r6
L_060AE918:
    c.t = c.r[1] >> 31; c.r[1] <<= 1;  // 060AE918 shll r1
    c.t = c.r[0] == 0x3u;  // 060AE91A cmp/eq #3,r0
    { const bool k = !c.t; c.r[0] += 1; if (k) { SH2_POLL(c); goto L_060AE904; } }  // 060AE91C bf/s 0x060AE904 ; add #1,r0
    c.r[10] += 4; SH2_POLL(c); goto L_060AE854;  // 060AE920 bra 0x060AE854 ; add #4,r10
L_060AE924:
    c.t = c.r[10] == c.r[11];  // 060AE924 cmp/eq r11,r10
    { const bool k = c.t; c.r[10] -= 4; if (k) { goto L_060AE962; } }  // 060AE926 bt/s 0x060AE962 ; add #-4,r10
    c.r[0] = 0x060AEAACu;  // 060AE92A mova 0x060AEAAC,r0
    c.r[1] = c.r[0];  // 060AE92C mov r0,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[10] + 3);  // 060AE92E mov.b @(3,r10),r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060AE930 mov.b @(r0,r1),r2
    c.r[1] += 44;  // 060AE932 add #44,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060AE934 mov.b @(r0,r1),r6
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 176);  // 060AE936 mov.b @(176,gbr),r0
    c.t = (c.r[0] & 0x8u) == 0;  // 060AE938 tst #8,r0
    { const bool k = c.t; c.r[0] = 0xFu; if (k) { goto L_060AE940; } }  // 060AE93A bt/s 0x060AE940 ; mov #15,r0
    c.r[6] &= c.r[0];  // 060AE93E and r0,r6
L_060AE940:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[10] + 2);  // 060AE940 mov.b @(2,r10),r0
    c.r[5] = c.r[0];  // 060AE942 mov r0,r5
    c.r[1] = 0x1u;  // 060AE944 mov #1,r1
    c.r[0] = 0x0u;  // 060AE946 mov #0,r0
L_060AE948:
    c.t = (c.r[5] & c.r[1]) == 0;  // 060AE948 tst r1,r5
    if (c.t) { goto L_060AE952; }  // 060AE94A bt 0x060AE952
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 060AE94C mov.b @(r0,r9),r3
    c.r[3] |= c.r[2];  // 060AE94E or r2,r3
    st8(c.r[0] + c.r[9], c.r[3]);  // 060AE950 mov.b r3,@(r0,r9)
L_060AE952:
    c.t = c.r[1] >> 31; c.r[1] <<= 1;  // 060AE952 shll r1
    c.t = c.r[0] == 0x3u;  // 060AE954 cmp/eq #3,r0
    { const bool k = !c.t; c.r[0] += 1; if (k) { SH2_POLL(c); goto L_060AE948; } }  // 060AE956 bf/s 0x060AE948 ; add #1,r0
    c.t = (c.r[6] & c.r[6]) == 0;  // 060AE95A tst r6,r6
    if (c.t) { SH2_POLL(c); goto L_060AE924; }  // 060AE95C bt 0x060AE924
    SH2_POLL(c); goto L_060AE866;  // 060AE95E bra 0x060AE866 ; nop
L_060AE962:
    c.r[0] = 0xFFFFFFFFu; goto L_060AEA04;  // 060AE962 bra 0x060AEA04 ; mov #-1,r0
L_060AE966:
    c.r[9] = ld32(0x060AEAA8u);  // 060AE966 mov.l 0x060AEAA8,r9
    c.r[7] = 0x8u;  // 060AE968 mov #8,r7
L_060AE96A:
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[8]); c.r[8] += 1;  // 060AE96A mov.b @r8+,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]); c.r[8] += 1;  // 060AE96C mov.b @r8+,r1
    c.r[2] <<= 2;  // 060AE96E shll2 r2
    c.r[2] <<= 2;  // 060AE970 shll2 r2
    c.r[2] |= c.r[1];  // 060AE972 or r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]); c.r[8] += 1;  // 060AE974 mov.b @r8+,r1
    c.r[2] <<= 2;  // 060AE976 shll2 r2
    c.r[2] <<= 2;  // 060AE978 shll2 r2
    c.r[2] |= c.r[1];  // 060AE97A or r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]); c.r[8] += 1;  // 060AE97C mov.b @r8+,r1
    c.r[2] <<= 2;  // 060AE97E shll2 r2
    c.r[2] <<= 2;  // 060AE980 shll2 r2
    c.r[2] |= c.r[1];  // 060AE982 or r1,r2
    st16(c.r[9], c.r[2]);  // 060AE984 mov.w r2,@r9
    c.r[7] -= 1; c.t = c.r[7] == 0;  // 060AE986 dt r7
    { const bool k = !c.t; c.r[9] += 2; if (k) { SH2_POLL(c); goto L_060AE96A; } }  // 060AE988 bf/s 0x060AE96A ; add #2,r9
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 206);  // 060AE98C mov.b @(206,gbr),r0
    c.r[6] = ld32(0x060AEAA8u);  // 060AE98E mov.l 0x060AEAA8,r6
    c.r[8] = c.r[0];  // 060AE990 mov r0,r8
    c.r[9] = 0x1u;  // 060AE992 mov #1,r9
L_060AE994:
    c.t = (c.r[8] & c.r[9]) == 0;  // 060AE994 tst r9,r8
    { const bool k = c.t; c.t = c.r[9] >> 31; c.r[9] <<= 1; if (k) { goto L_060AE9F6; } }  // 060AE996 bt/s 0x060AE9F6 ; shll r9
    c.r[4] = ld32(c.r[6]);  // 060AE99A mov.l @(0,r6),r4
    c.r[5] = ld32(c.r[6] + 4);  // 060AE99C mov.l @(4,r6),r5
    c.r[7] = 0xFu;  // 060AE99E mov #15,r7
    c.r[1] = 0x8u;  // 060AE9A0 mov #8,r1
    c.r[3] = 0xEu;  // 060AE9A2 mov #14,r3
    c.r[0] = 0x0u;  // 060AE9A4 mov #0,r0
L_060AE9A6:
    c.r[2] = c.r[4];  // 060AE9A6 mov r4,r2
    c.r[2] &= c.r[7];  // 060AE9A8 and r7,r2
    c.t = c.r[2] == c.r[3];  // 060AE9AA cmp/eq r3,r2
    { const bool k = c.t; c.r[2] = c.r[5]; if (k) { goto L_060AE9BA; } }  // 060AE9AC bt/s 0x060AE9BA ; mov r5,r2
    c.r[2] &= c.r[7];  // 060AE9B0 and r7,r2
    c.t = c.r[2] == c.r[3];  // 060AE9B2 cmp/eq r3,r2
    if (!c.t) { goto L_060AE9C2; }  // 060AE9B4 bf 0x060AE9C2
    c.r[5] |= c.r[7]; goto L_060AE9C2;  // 060AE9B6 bra 0x060AE9C2 ; or r7,r5
L_060AE9BA:
    c.r[2] &= c.r[7];  // 060AE9BA and r7,r2
    c.t = c.r[2] == c.r[3];  // 060AE9BC cmp/eq r3,r2
    if (c.t) { goto L_060AE9C2; }  // 060AE9BE bt 0x060AE9C2
    c.r[4] |= c.r[7];  // 060AE9C0 or r7,r4
L_060AE9C2:
    c.r[7] <<= 2;  // 060AE9C2 shll2 r7
    c.r[7] <<= 2;  // 060AE9C4 shll2 r7
    c.r[3] <<= 2;  // 060AE9C6 shll2 r3
    c.r[1] -= 1; c.t = c.r[1] == 0;  // 060AE9C8 dt r1
    { const bool k = !c.t; c.r[3] <<= 2; if (k) { SH2_POLL(c); goto L_060AE9A6; } }  // 060AE9CA bf/s 0x060AE9A6 ; shll2 r3
    c.r[0] = ld32(0x060AEAB4u);  // 060AE9CE mov.l 0x060AEAB4,r0
    c.r[7] = 0xFFFFFFFFu;  // 060AE9D0 mov #-1,r7
    c.r[3] = ld32(0x060AEAB8u);  // 060AE9D2 mov.l 0x060AEAB8,r3
    c.r[1] = 0x8u;  // 060AE9D4 mov #8,r1
    c.r[2] = c.r[4];  // 060AE9D6 mov r4,r2
L_060AE9D8:
    c.r[2] &= c.r[7];  // 060AE9D8 and r7,r2
    c.r[3] &= c.r[7];  // 060AE9DA and r7,r3
    c.t = c.r[3] == c.r[2];  // 060AE9DC cmp/eq r2,r3
    { const bool k = !c.t; c.r[7] >>= 2; if (k) { goto L_060AE9E8; } }  // 060AE9DE bf/s 0x060AE9E8 ; shlr2 r7
    c.r[4] |= c.r[0];  // 060AE9E2 or r0,r4
    c.r[5] |= c.r[0]; goto L_060AE9F2;  // 060AE9E4 bra 0x060AE9F2 ; or r0,r5
L_060AE9E8:
    c.r[0] >>= 2;  // 060AE9E8 shlr2 r0
    c.r[0] >>= 2;  // 060AE9EA shlr2 r0
    c.r[1] -= 1; c.t = c.r[1] == 0;  // 060AE9EC dt r1
    { const bool k = !c.t; c.r[7] >>= 2; if (k) { SH2_POLL(c); goto L_060AE9D8; } }  // 060AE9EE bf/s 0x060AE9D8 ; shlr2 r7
L_060AE9F2:
    st32(c.r[6], c.r[4]);  // 060AE9F2 mov.l r4,@(0,r6)
    st32(c.r[6] + 4, c.r[5]);  // 060AE9F4 mov.l r5,@(4,r6)
L_060AE9F6:
    c.r[0] = 0x2u;  // 060AE9F6 mov #2,r0
    c.t = c.r[9] == c.r[0];  // 060AE9F8 cmp/eq r0,r9
    { const bool k = c.t; c.r[6] += 8; if (k) { SH2_POLL(c); goto L_060AE994; } }  // 060AE9FA bt/s 0x060AE994 ; add #8,r6
    c.r[0] = c.r[12];  // 060AE9FE mov r12,r0
    st8(c.gbr + 225, c.r[0]);  // 060AEA00 mov.b r0,@(225,gbr)
    c.r[0] = 0x0u;  // 060AEA02 mov #0,r0
L_060AEA04:
    c.r[1] = (uint32_t)(int16_t)ld16(0x060AEA1Cu);  // 060AEA04 mov.w 0x060AEA1C,r1
    c.r[15] += c.r[1];  // 060AEA06 add r1,r15
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060AEA08 mov.l @r15+,r8
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060AEA0A mov.l @r15+,r9
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060AEA0C mov.l @r15+,r10
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060AEA0E mov.l @r15+,r11
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060AEA10 mov.l @r15+,r12
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060AEA12 mov.l @r15+,r13
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060AEA14 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060AEA16 rts ; nop
}

void f_060AEA1E(SH2Context& c) {
    ran[2978] = 1;
    c.r[13] = c.r[10];  // 060AEA1E mov r10,r13
    c.r[3] = c.r[4];  // 060AEA20 mov r4,r3
L_060AEA22:
    c.r[0] = 0xFFFFFFFEu;  // 060AEA22 mov #-2,r0
    st8(c.r[10], c.r[0]);  // 060AEA24 mov.b r0,@(0,r10)
    c.r[0] = c.r[6];  // 060AEA26 mov r6,r0
    st8(c.r[10] + 1, c.r[0]);  // 060AEA28 mov.b r0,@(1,r10)
    c.r[0] = c.r[7];  // 060AEA2A mov r7,r0
    st8(c.r[10] + 2, c.r[0]);  // 060AEA2C mov.b r0,@(2,r10)
    c.r[3] -= 1; c.t = c.r[3] == 0;  // 060AEA2E dt r3
    { const bool k = !c.t; c.r[10] += 4; if (k) { SH2_POLL(c); goto L_060AEA22; } }  // 060AEA30 bf/s 0x060AEA22 ; add #4,r10
    c.r[3] = c.r[4];  // 060AEA34 mov r4,r3
L_060AEA36:
    c.r[2] = c.r[5];  // 060AEA36 mov r5,r2
L_060AEA38:
    c.r[0] = c.r[13];  // 060AEA38 mov r13,r0
    c.r[0] -= c.r[11];  // 060AEA3A sub r11,r0
    st8(c.r[10], c.r[0]);  // 060AEA3C mov.b r0,@(0,r10)
    c.r[0] = c.r[8];  // 060AEA3E mov r8,r0
    st8(c.r[10] + 1, c.r[0]);  // 060AEA40 mov.b r0,@(1,r10)
    c.r[0] = c.r[9];  // 060AEA42 mov r9,r0
    st8(c.r[10] + 2, c.r[0]);  // 060AEA44 mov.b r0,@(2,r10)
    c.r[2] -= 1; c.t = c.r[2] == 0;  // 060AEA46 dt r2
    { const bool k = !c.t; c.r[10] += 4; if (k) { SH2_POLL(c); goto L_060AEA38; } }  // 060AEA48 bf/s 0x060AEA38 ; add #4,r10
    c.r[3] -= 1; c.t = c.r[3] == 0;  // 060AEA4C dt r3
    { const bool k = !c.t; c.r[13] += 4; if (k) { SH2_POLL(c); goto L_060AEA36; } }  // 060AEA4E bf/s 0x060AEA36 ; add #4,r13
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060AEA52 rts ; nop
}

void f_060AEA56(SH2Context& c) {
    ran[2979] = 1;
    c.r[1] = ld32(0x060AEA68u);  // 060AEA56 mov.l 0x060AEA68,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060AEA58 mov.b @(r0,r1),r2
    c.r[0] = c.r[7];  // 060AEA5A mov r7,r0
L_060AEA5C:
    c.r[2] -= 1; c.t = c.r[2] == 0;  // 060AEA5C dt r2
    { const bool k = c.t; c.t = c.r[0] >> 31; c.r[0] <<= 1; if (k) { goto L_060AEA6C; } }  // 060AEA5E bt/s 0x060AEA6C ; shll r0
    c.r[7] |= c.r[0]; SH2_POLL(c); goto L_060AEA5C;  // 060AEA62 bra 0x060AEA5C ; or r0,r7
L_060AEA6C:
    c.r[3] = c.r[4];  // 060AEA6C mov r4,r3
L_060AEA6E:
    c.r[2] = c.r[5];  // 060AEA6E mov r5,r2
L_060AEA70:
    c.r[0] = 0xFFFFFFFDu;  // 060AEA70 mov #-3,r0
    st8(c.r[10], c.r[0]);  // 060AEA72 mov.b r0,@(0,r10)
    c.r[0] = c.r[8];  // 060AEA74 mov r8,r0
    st8(c.r[10] + 1, c.r[0]);  // 060AEA76 mov.b r0,@(1,r10)
    c.r[0] = c.r[7];  // 060AEA78 mov r7,r0
    st8(c.r[10] + 2, c.r[0]);  // 060AEA7A mov.b r0,@(2,r10)
    c.r[2] -= 1; c.t = c.r[2] == 0;  // 060AEA7C dt r2
    { const bool k = !c.t; c.r[10] += 4; if (k) { SH2_POLL(c); goto L_060AEA70; } }  // 060AEA7E bf/s 0x060AEA70 ; add #4,r10
    c.r[3] -= 1; c.t = c.r[3] == 0;  // 060AEA82 dt r3
    if (!c.t) { SH2_POLL(c); goto L_060AEA6E; }  // 060AEA84 bf 0x060AEA6E
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060AEA86 rts ; nop
}

void f_060AEA8A(SH2Context& c) {
    ran[2980] = 1;
    st8(c.r[10] + 1, c.r[0]);  // 060AEA8A mov.b r0,@(1,r10)
    c.r[0] = c.r[1];  // 060AEA8C mov r1,r0
    st8(c.r[10], c.r[0]);  // 060AEA8E mov.b r0,@(0,r10)
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 348);  // 060AEA90 mov.w @(348,gbr),r0
    c.r[0] &= 0x3u;  // 060AEA92 and #3,r0
    c.r[1] = ld32(0x060AEAA0u);  // 060AEA94 mov.l 0x060AEAA0,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060AEA96 mov.b @(r0,r1),r0
    st8(c.r[10] + 2, c.r[0]);  // 060AEA98 mov.b r0,@(2,r10)
    c.r[10] += 4;  // 060AEA9A add #4,r10
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060AEA9C rts ; nop
}

void f_060AEAF4(SH2Context& c) {
    ran[2981] = 1;
    c.r[1] = ld32(0x060AEB0Cu);  // 060AEAF4 mov.l 0x060AEB0C,r1
    c.r[2] = ld32(0x060AEB10u);  // 060AEAF6 mov.l 0x060AEB10,r2
    st32(c.r[1], c.r[4]);  // 060AEAF8 mov.l r4,@r1
    st32(c.r[1] + 4, c.r[5]);  // 060AEAFA mov.l r5,@(4,r1)
    st32(c.r[1] + 8, c.r[6]);  // 060AEAFC mov.l r6,@(8,r1)
    st32(c.r[1] + 12, c.r[7]);  // 060AEAFE mov.l r7,@(12,r1)
    st32(c.r[2], c.r[4]);  // 060AEB00 mov.l r4,@r2
    st32(c.r[2] + 4, c.r[5]);  // 060AEB02 mov.l r5,@(4,r2)
    st32(c.r[2] + 8, c.r[6]);  // 060AEB04 mov.l r6,@(8,r2)
    { const uint32_t x = c.pr; st32(c.r[2] + 12, c.r[7]); c.pc = x; return; }  // 060AEB06 rts ; mov.l r7,@(12,r2)
}

void f_060AEB14(SH2Context& c) {
    ran[2982] = 1;
    c.r[0] = c.r[4];  // 060AEB14 mov r4,r0
    c.t = c.r[4] >> 31; c.r[4] <<= 1;  // 060AEB16 shll r4
    { uint32_t t = c.r[0] & 1; c.r[0] = c.r[0] >> 1 | c.t << 31; c.t = t; }  // 060AEB18 rotcr r0
    { const uint32_t x = c.pr; st32(c.gbr + 408, c.r[0]); c.pc = x; return; }  // 060AEB1A rts ; mov.l r0,@(408,gbr)
}

void f_060AEB20(SH2Context& c) {
    ran[2983] = 1;
    c.r[0] = c.r[4];  // 060AEB20 mov r4,r0
    c.t = c.r[4] >> 31; c.r[4] <<= 1;  // 060AEB22 shll r4
    { uint32_t t = c.r[0] & 1; c.r[0] = c.r[0] >> 1 | c.t << 31; c.t = t; }  // 060AEB24 rotcr r0
    { const uint32_t x = c.pr; st32(c.gbr + 412, c.r[0]); c.pc = x; return; }  // 060AEB26 rts ; mov.l r0,@(412,gbr)
}

void f_060AEB2C(SH2Context& c) {
    ran[2984] = 1;
    c.r[0] = ld32(0x060AEB34u);  // 060AEB2C mov.l 0x060AEB34,r0
    { const uint32_t x = c.pr; st8(c.r[0] + c.r[4], c.r[5]); c.pc = x; return; }  // 060AEB2E rts ; mov.b r5,@(r0,r4)
}

void f_060AEB38(SH2Context& c) {
    ran[2985] = 1;
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 420);  // 060AEB38 mov.w @(420,gbr),r0
    c.r[1] = 0xFFFFFFF0u;  // 060AEB3A mov #-16,r1
    c.r[0] &= c.r[1];  // 060AEB3C and r1,r0
    c.r[0] |= c.r[4];  // 060AEB3E or r4,r0
    { const uint32_t x = c.pr; st16(c.gbr + 420, c.r[0]); c.pc = x; return; }  // 060AEB40 rts ; mov.w r0,@(420,gbr)
}

void f_060AEB44(SH2Context& c) {
    ran[2986] = 1;
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 251);  // 060AEB44 mov.b @(251,gbr),r0
    c.r[0] &= 0xFCu;  // 060AEB46 and #252,r0
    c.r[0] |= c.r[4];  // 060AEB48 or r4,r0
    { const uint32_t x = c.pr; st8(c.gbr + 251, c.r[0]); c.pc = x; return; }  // 060AEB4A rts ; mov.b r0,@(251,gbr)
}

void f_060AEB50(SH2Context& c) {
    ran[2987] = 1;
    c.r[0] = c.r[4];  // 060AEB50 mov r4,r0
    st32(c.gbr + 508, c.r[0]);  // 060AEB52 mov.l r0,@(508,gbr)
    c.r[3] = 0xBu;  // 060AEB54 mov #11,r3
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 240);  // 060AEB56 mov.w @(240,gbr),r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x060AEBFCu);  // 060AEB58 mov.w 0x060AEBFC,r1
    c.t = (c.r[0] & c.r[1]) == 0;  // 060AEB5A tst r1,r0
    if (!c.t) { goto L_060AEB60; }  // 060AEB5C bf 0x060AEB60
    c.r[3] += 1;  // 060AEB5E add #1,r3
L_060AEB60:
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 232);  // 060AEB60 mov.w @(232,gbr),r0
    c.t = (c.r[0] & 0x1u) == 0;  // 060AEB62 tst #1,r0
    if (!c.t) { goto L_060AEB68; }  // 060AEB64 bf 0x060AEB68
    c.r[3] += 2;  // 060AEB66 add #2,r3
L_060AEB68:
    c.r[0] = c.r[3];  // 060AEB68 mov r3,r0
    c.r[0] += 6;  // 060AEB6A add #6,r0
    c.r[2] = c.r[4];  // 060AEB6C mov r4,r2
    c.t = (c.r[0] & 0x10u) == 0;  // 060AEB6E tst #16,r0
    if (c.t) { goto L_060AEB74; }  // 060AEB70 bt 0x060AEB74
    c.r[2] >>= 16;  // 060AEB72 shlr16 r2
L_060AEB74:
    c.t = (c.r[0] & 0x8u) == 0;  // 060AEB74 tst #8,r0
    if (c.t) { goto L_060AEB7A; }  // 060AEB76 bt 0x060AEB7A
    c.r[2] >>= 8;  // 060AEB78 shlr8 r2
L_060AEB7A:
    c.t = (c.r[0] & 0x4u) == 0;  // 060AEB7A tst #4,r0
    if (c.t) { goto L_060AEB82; }  // 060AEB7C bt 0x060AEB82
    c.r[2] >>= 2;  // 060AEB7E shlr2 r2
    c.r[2] >>= 2;  // 060AEB80 shlr2 r2
L_060AEB82:
    c.t = (c.r[0] & 0x2u) == 0;  // 060AEB82 tst #2,r0
    if (c.t) { goto L_060AEB88; }  // 060AEB84 bt 0x060AEB88
    c.r[2] >>= 2;  // 060AEB86 shlr2 r2
L_060AEB88:
    c.t = (c.r[0] & 0x1u) == 0;  // 060AEB88 tst #1,r0
    if (c.t) { goto L_060AEB8E; }  // 060AEB8A bt 0x060AEB8E
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 060AEB8C shlr r2
L_060AEB8E:
    c.r[1] = 0x7u;  // 060AEB8E mov #7,r1
    c.r[2] &= c.r[1];  // 060AEB90 and r1,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 253);  // 060AEB92 mov.b @(253,gbr),r0
    c.r[0] &= 0xF0u;  // 060AEB94 and #240,r0
    c.r[0] |= c.r[2];  // 060AEB96 or r2,r0
    st8(c.gbr + 253, c.r[0]);  // 060AEB98 mov.b r0,@(253,gbr)
    c.r[0] = c.r[3];  // 060AEB9A mov r3,r0
    c.t = (c.r[0] & 0x10u) == 0;  // 060AEB9C tst #16,r0
    if (c.t) { goto L_060AEBA8; }  // 060AEB9E bt 0x060AEBA8
    c.r[4] >>= 16;  // 060AEBA0 shlr16 r4
    c.r[5] >>= 16;  // 060AEBA2 shlr16 r5
    c.r[6] >>= 16;  // 060AEBA4 shlr16 r6
    c.r[7] >>= 16;  // 060AEBA6 shlr16 r7
L_060AEBA8:
    c.t = (c.r[0] & 0x8u) == 0;  // 060AEBA8 tst #8,r0
    if (c.t) { goto L_060AEBB4; }  // 060AEBAA bt 0x060AEBB4
    c.r[4] >>= 8;  // 060AEBAC shlr8 r4
    c.r[5] >>= 8;  // 060AEBAE shlr8 r5
    c.r[6] >>= 8;  // 060AEBB0 shlr8 r6
    c.r[7] >>= 8;  // 060AEBB2 shlr8 r7
L_060AEBB4:
    c.t = (c.r[0] & 0x4u) == 0;  // 060AEBB4 tst #4,r0
    if (c.t) { goto L_060AEBC8; }  // 060AEBB6 bt 0x060AEBC8
    c.r[4] >>= 2;  // 060AEBB8 shlr2 r4
    c.r[4] >>= 2;  // 060AEBBA shlr2 r4
    c.r[5] >>= 2;  // 060AEBBC shlr2 r5
    c.r[5] >>= 2;  // 060AEBBE shlr2 r5
    c.r[6] >>= 2;  // 060AEBC0 shlr2 r6
    c.r[6] >>= 2;  // 060AEBC2 shlr2 r6
    c.r[7] >>= 2;  // 060AEBC4 shlr2 r7
    c.r[7] >>= 2;  // 060AEBC6 shlr2 r7
L_060AEBC8:
    c.t = (c.r[0] & 0x2u) == 0;  // 060AEBC8 tst #2,r0
    if (c.t) { goto L_060AEBD4; }  // 060AEBCA bt 0x060AEBD4
    c.r[4] >>= 2;  // 060AEBCC shlr2 r4
    c.r[5] >>= 2;  // 060AEBCE shlr2 r5
    c.r[6] >>= 2;  // 060AEBD0 shlr2 r6
    c.r[7] >>= 2;  // 060AEBD2 shlr2 r7
L_060AEBD4:
    c.t = (c.r[0] & 0x1u) == 0;  // 060AEBD4 tst #1,r0
    if (c.t) { goto L_060AEBE0; }  // 060AEBD6 bt 0x060AEBE0
    c.t = c.r[4] & 1; c.r[4] >>= 1;  // 060AEBD8 shlr r4
    c.t = c.r[5] & 1; c.r[5] >>= 1;  // 060AEBDA shlr r5
    c.t = c.r[6] & 1; c.r[6] >>= 1;  // 060AEBDC shlr r6
    c.t = c.r[7] & 1; c.r[7] >>= 1;  // 060AEBDE shlr r7
L_060AEBE0:
    c.r[1] = 0x3Fu;  // 060AEBE0 mov #63,r1
    c.r[4] &= c.r[1];  // 060AEBE2 and r1,r4
    c.r[5] &= c.r[1];  // 060AEBE4 and r1,r5
    c.r[6] &= c.r[1];  // 060AEBE6 and r1,r6
    c.r[7] &= c.r[1];  // 060AEBE8 and r1,r7
    c.r[5] <<= 8;  // 060AEBEA shll8 r5
    c.r[4] |= c.r[5];  // 060AEBEC or r5,r4
    c.r[0] = c.r[4];  // 060AEBEE mov r4,r0
    st16(c.gbr + 256, c.r[0]);  // 060AEBF0 mov.w r0,@(256,gbr)
    c.r[7] <<= 8;  // 060AEBF2 shll8 r7
    c.r[6] |= c.r[7];  // 060AEBF4 or r7,r6
    c.r[0] = c.r[6];  // 060AEBF6 mov r6,r0
    { const uint32_t x = c.pr; st16(c.gbr + 258, c.r[0]); c.pc = x; return; }  // 060AEBF8 rts ; mov.w r0,@(258,gbr)
}

void f_060AEC00(SH2Context& c) {
    ran[2988] = 1;
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 251);  // 060AEC00 mov.b @(251,gbr),r0
    c.r[4] <<= 2;  // 060AEC02 shll2 r4
    c.r[0] &= 0xF3u;  // 060AEC04 and #243,r0
    c.r[0] |= c.r[4];  // 060AEC06 or r4,r0
    { const uint32_t x = c.pr; st8(c.gbr + 251, c.r[0]); c.pc = x; return; }  // 060AEC08 rts ; mov.b r0,@(251,gbr)
}

void f_060AEC0C(SH2Context& c) {
    ran[2989] = 1;
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 420);  // 060AEC0C mov.w @(420,gbr),r0
    c.r[1] = 0xFFFFFFF0u;  // 060AEC0E mov #-16,r1
    c.r[0] = (c.r[0] & 0xFFFF0000u) | (c.r[0] & 0xFFu) << 8 | (c.r[0] >> 8 & 0xFFu);  // 060AEC10 swap.b r0,r0
    c.r[0] &= c.r[1];  // 060AEC12 and r1,r0
    c.r[0] |= c.r[4];  // 060AEC14 or r4,r0
    c.r[0] = (c.r[0] & 0xFFFF0000u) | (c.r[0] & 0xFFu) << 8 | (c.r[0] >> 8 & 0xFFu);  // 060AEC16 swap.b r0,r0
    { const uint32_t x = c.pr; st16(c.gbr + 420, c.r[0]); c.pc = x; return; }  // 060AEC18 rts ; mov.w r0,@(420,gbr)
}

void f_060AEC1C(SH2Context& c) {
    ran[2990] = 1;
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 251);  // 060AEC1C mov.b @(251,gbr),r0
    c.r[4] <<= 2;  // 060AEC1E shll2 r4
    c.r[0] &= 0xCFu;  // 060AEC20 and #207,r0
    c.r[4] <<= 2;  // 060AEC22 shll2 r4
    c.r[0] |= c.r[4];  // 060AEC24 or r4,r0
    { const uint32_t x = c.pr; st8(c.gbr + 251, c.r[0]); c.pc = x; return; }  // 060AEC26 rts ; mov.b r0,@(251,gbr)
}

void f_060AEC2C(SH2Context& c) {
    ran[2991] = 1;
    c.r[0] = c.r[4];  // 060AEC2C mov r4,r0
    st32(c.gbr + 516, c.r[0]);  // 060AEC2E mov.l r0,@(516,gbr)
    c.r[3] = 0xBu;  // 060AEC30 mov #11,r3
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 244);  // 060AEC32 mov.w @(244,gbr),r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x060AECD8u);  // 060AEC34 mov.w 0x060AECD8,r1
    c.t = (c.r[0] & c.r[1]) == 0;  // 060AEC36 tst r1,r0
    if (!c.t) { goto L_060AEC3C; }  // 060AEC38 bf 0x060AEC3C
    c.r[3] += 1;  // 060AEC3A add #1,r3
L_060AEC3C:
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 234);  // 060AEC3C mov.w @(234,gbr),r0
    c.t = (c.r[0] & 0x1u) == 0;  // 060AEC3E tst #1,r0
    if (!c.t) { goto L_060AEC44; }  // 060AEC40 bf 0x060AEC44
    c.r[3] += 2;  // 060AEC42 add #2,r3
L_060AEC44:
    c.r[0] = c.r[3];  // 060AEC44 mov r3,r0
    c.r[0] += 6;  // 060AEC46 add #6,r0
    c.r[2] = c.r[4];  // 060AEC48 mov r4,r2
    c.t = (c.r[0] & 0x10u) == 0;  // 060AEC4A tst #16,r0
    if (c.t) { goto L_060AEC50; }  // 060AEC4C bt 0x060AEC50
    c.r[2] >>= 16;  // 060AEC4E shlr16 r2
L_060AEC50:
    c.t = (c.r[0] & 0x8u) == 0;  // 060AEC50 tst #8,r0
    if (c.t) { goto L_060AEC56; }  // 060AEC52 bt 0x060AEC56
    c.r[2] >>= 8;  // 060AEC54 shlr8 r2
L_060AEC56:
    c.t = (c.r[0] & 0x4u) == 0;  // 060AEC56 tst #4,r0
    if (c.t) { goto L_060AEC5E; }  // 060AEC58 bt 0x060AEC5E
    c.r[2] >>= 2;  // 060AEC5A shlr2 r2
    c.r[2] >>= 2;  // 060AEC5C shlr2 r2
L_060AEC5E:
    c.t = (c.r[0] & 0x2u) == 0;  // 060AEC5E tst #2,r0
    if (c.t) { goto L_060AEC64; }  // 060AEC60 bt 0x060AEC64
    c.r[2] >>= 2;  // 060AEC62 shlr2 r2
L_060AEC64:
    c.t = (c.r[0] & 0x1u) == 0;  // 060AEC64 tst #1,r0
    if (c.t) { goto L_060AEC6A; }  // 060AEC66 bt 0x060AEC6A
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 060AEC68 shlr r2
L_060AEC6A:
    c.r[1] = 0x7u;  // 060AEC6A mov #7,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 252);  // 060AEC6C mov.b @(252,gbr),r0
    c.r[2] &= c.r[1];  // 060AEC6E and r1,r2
    c.r[0] &= 0xF0u;  // 060AEC70 and #240,r0
    c.r[0] |= c.r[2];  // 060AEC72 or r2,r0
    st8(c.gbr + 252, c.r[0]);  // 060AEC74 mov.b r0,@(252,gbr)
    c.r[0] = c.r[3];  // 060AEC76 mov r3,r0
    c.t = (c.r[0] & 0x10u) == 0;  // 060AEC78 tst #16,r0
    if (c.t) { goto L_060AEC84; }  // 060AEC7A bt 0x060AEC84
    c.r[4] >>= 16;  // 060AEC7C shlr16 r4
    c.r[5] >>= 16;  // 060AEC7E shlr16 r5
    c.r[6] >>= 16;  // 060AEC80 shlr16 r6
    c.r[7] >>= 16;  // 060AEC82 shlr16 r7
L_060AEC84:
    c.t = (c.r[0] & 0x8u) == 0;  // 060AEC84 tst #8,r0
    if (c.t) { goto L_060AEC90; }  // 060AEC86 bt 0x060AEC90
    c.r[4] >>= 8;  // 060AEC88 shlr8 r4
    c.r[5] >>= 8;  // 060AEC8A shlr8 r5
    c.r[6] >>= 8;  // 060AEC8C shlr8 r6
    c.r[7] >>= 8;  // 060AEC8E shlr8 r7
L_060AEC90:
    c.t = (c.r[0] & 0x4u) == 0;  // 060AEC90 tst #4,r0
    if (c.t) { goto L_060AECA4; }  // 060AEC92 bt 0x060AECA4
    c.r[4] >>= 2;  // 060AEC94 shlr2 r4
    c.r[4] >>= 2;  // 060AEC96 shlr2 r4
    c.r[5] >>= 2;  // 060AEC98 shlr2 r5
    c.r[5] >>= 2;  // 060AEC9A shlr2 r5
    c.r[6] >>= 2;  // 060AEC9C shlr2 r6
    c.r[6] >>= 2;  // 060AEC9E shlr2 r6
    c.r[7] >>= 2;  // 060AECA0 shlr2 r7
    c.r[7] >>= 2;  // 060AECA2 shlr2 r7
L_060AECA4:
    c.t = (c.r[0] & 0x2u) == 0;  // 060AECA4 tst #2,r0
    if (c.t) { goto L_060AECB0; }  // 060AECA6 bt 0x060AECB0
    c.r[4] >>= 2;  // 060AECA8 shlr2 r4
    c.r[5] >>= 2;  // 060AECAA shlr2 r5
    c.r[6] >>= 2;  // 060AECAC shlr2 r6
    c.r[7] >>= 2;  // 060AECAE shlr2 r7
L_060AECB0:
    c.t = (c.r[0] & 0x1u) == 0;  // 060AECB0 tst #1,r0
    if (c.t) { goto L_060AECBC; }  // 060AECB2 bt 0x060AECBC
    c.t = c.r[4] & 1; c.r[4] >>= 1;  // 060AECB4 shlr r4
    c.t = c.r[5] & 1; c.r[5] >>= 1;  // 060AECB6 shlr r5
    c.t = c.r[6] & 1; c.r[6] >>= 1;  // 060AECB8 shlr r6
    c.t = c.r[7] & 1; c.r[7] >>= 1;  // 060AECBA shlr r7
L_060AECBC:
    c.r[1] = 0x3Fu;  // 060AECBC mov #63,r1
    c.r[4] &= c.r[1];  // 060AECBE and r1,r4
    c.r[5] &= c.r[1];  // 060AECC0 and r1,r5
    c.r[6] &= c.r[1];  // 060AECC2 and r1,r6
    c.r[7] &= c.r[1];  // 060AECC4 and r1,r7
    c.r[5] <<= 8;  // 060AECC6 shll8 r5
    c.r[4] |= c.r[5];  // 060AECC8 or r5,r4
    c.r[0] = c.r[4];  // 060AECCA mov r4,r0
    st16(c.gbr + 264, c.r[0]);  // 060AECCC mov.w r0,@(264,gbr)
    c.r[7] <<= 8;  // 060AECCE shll8 r7
    c.r[6] |= c.r[7];  // 060AECD0 or r7,r6
    c.r[0] = c.r[6];  // 060AECD2 mov r6,r0
    { const uint32_t x = c.pr; st16(c.gbr + 266, c.r[0]); c.pc = x; return; }  // 060AECD4 rts ; mov.w r0,@(266,gbr)
}

void f_060AECDC(SH2Context& c) {
    ran[2992] = 1;
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 420);  // 060AECDC mov.w @(420,gbr),r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x060AECF0u);  // 060AECDE mov.w 0x060AECF0,r1
    c.r[0] = (c.r[0] & 0xFFFF0000u) | (c.r[0] & 0xFFu) << 8 | (c.r[0] >> 8 & 0xFFu);  // 060AECE0 swap.b r0,r0
    c.r[0] &= c.r[1];  // 060AECE2 and r1,r0
    c.r[4] <<= 2;  // 060AECE4 shll2 r4
    c.r[4] <<= 2;  // 060AECE6 shll2 r4
    c.r[0] |= c.r[4];  // 060AECE8 or r4,r0
    c.r[0] = (c.r[0] & 0xFFFF0000u) | (c.r[0] & 0xFFu) << 8 | (c.r[0] >> 8 & 0xFFu);  // 060AECEA swap.b r0,r0
    { const uint32_t x = c.pr; st16(c.gbr + 420, c.r[0]); c.pc = x; return; }  // 060AECEC rts ; mov.w r0,@(420,gbr)
}

void f_060AECF4(SH2Context& c) {
    ran[2993] = 1;
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 251);  // 060AECF4 mov.b @(251,gbr),r0
    c.r[4] <<= 8;  // 060AECF6 shll8 r4
    c.r[0] &= 0x3Fu;  // 060AECF8 and #63,r0
    c.r[4] >>= 2;  // 060AECFA shlr2 r4
    c.r[0] |= c.r[4];  // 060AECFC or r4,r0
    { const uint32_t x = c.pr; st8(c.gbr + 251, c.r[0]); c.pc = x; return; }  // 060AECFE rts ; mov.b r0,@(251,gbr)
}

void f_060AED04(SH2Context& c) {
    ran[2994] = 1;
    c.r[0] = c.r[4];  // 060AED04 mov r4,r0
    st32(c.gbr + 520, c.r[0]);  // 060AED06 mov.l r0,@(520,gbr)
    c.r[3] = 0xBu;  // 060AED08 mov #11,r3
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 246);  // 060AED0A mov.w @(246,gbr),r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x060AEDB4u);  // 060AED0C mov.w 0x060AEDB4,r1
    c.t = (c.r[0] & c.r[1]) == 0;  // 060AED0E tst r1,r0
    if (!c.t) { goto L_060AED14; }  // 060AED10 bf 0x060AED14
    c.r[3] += 1;  // 060AED12 add #1,r3
L_060AED14:
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 234);  // 060AED14 mov.w @(234,gbr),r0
    c.t = (c.r[0] & 0x10u) == 0;  // 060AED16 tst #16,r0
    if (!c.t) { goto L_060AED1C; }  // 060AED18 bf 0x060AED1C
    c.r[3] += 2;  // 060AED1A add #2,r3
L_060AED1C:
    c.r[0] = c.r[3];  // 060AED1C mov r3,r0
    c.r[0] += 6;  // 060AED1E add #6,r0
    c.r[2] = c.r[4];  // 060AED20 mov r4,r2
    c.t = (c.r[0] & 0x10u) == 0;  // 060AED22 tst #16,r0
    if (c.t) { goto L_060AED28; }  // 060AED24 bt 0x060AED28
    c.r[2] >>= 16;  // 060AED26 shlr16 r2
L_060AED28:
    c.t = (c.r[0] & 0x8u) == 0;  // 060AED28 tst #8,r0
    if (c.t) { goto L_060AED2E; }  // 060AED2A bt 0x060AED2E
    c.r[2] >>= 8;  // 060AED2C shlr8 r2
L_060AED2E:
    c.t = (c.r[0] & 0x4u) == 0;  // 060AED2E tst #4,r0
    if (c.t) { goto L_060AED36; }  // 060AED30 bt 0x060AED36
    c.r[2] >>= 2;  // 060AED32 shlr2 r2
    c.r[2] >>= 2;  // 060AED34 shlr2 r2
L_060AED36:
    c.t = (c.r[0] & 0x2u) == 0;  // 060AED36 tst #2,r0
    if (c.t) { goto L_060AED3C; }  // 060AED38 bt 0x060AED3C
    c.r[2] >>= 2;  // 060AED3A shlr2 r2
L_060AED3C:
    c.t = (c.r[0] & 0x1u) == 0;  // 060AED3C tst #1,r0
    if (c.t) { goto L_060AED42; }  // 060AED3E bt 0x060AED42
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 060AED40 shlr r2
L_060AED42:
    c.r[1] = 0x7u;  // 060AED42 mov #7,r1
    c.r[2] &= c.r[1];  // 060AED44 and r1,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 252);  // 060AED46 mov.b @(252,gbr),r0
    c.r[2] <<= 2;  // 060AED48 shll2 r2
    c.r[0] &= 0xFu;  // 060AED4A and #15,r0
    c.r[2] <<= 2;  // 060AED4C shll2 r2
    c.r[0] |= c.r[2];  // 060AED4E or r2,r0
    st8(c.gbr + 252, c.r[0]);  // 060AED50 mov.b r0,@(252,gbr)
    c.r[0] = c.r[3];  // 060AED52 mov r3,r0
    c.t = (c.r[0] & 0x10u) == 0;  // 060AED54 tst #16,r0
    if (c.t) { goto L_060AED60; }  // 060AED56 bt 0x060AED60
    c.r[4] >>= 16;  // 060AED58 shlr16 r4
    c.r[5] >>= 16;  // 060AED5A shlr16 r5
    c.r[6] >>= 16;  // 060AED5C shlr16 r6
    c.r[7] >>= 16;  // 060AED5E shlr16 r7
L_060AED60:
    c.t = (c.r[0] & 0x8u) == 0;  // 060AED60 tst #8,r0
    if (c.t) { goto L_060AED6C; }  // 060AED62 bt 0x060AED6C
    c.r[4] >>= 8;  // 060AED64 shlr8 r4
    c.r[5] >>= 8;  // 060AED66 shlr8 r5
    c.r[6] >>= 8;  // 060AED68 shlr8 r6
    c.r[7] >>= 8;  // 060AED6A shlr8 r7
L_060AED6C:
    c.t = (c.r[0] & 0x4u) == 0;  // 060AED6C tst #4,r0
    if (c.t) { goto L_060AED80; }  // 060AED6E bt 0x060AED80
    c.r[4] >>= 2;  // 060AED70 shlr2 r4
    c.r[4] >>= 2;  // 060AED72 shlr2 r4
    c.r[5] >>= 2;  // 060AED74 shlr2 r5
    c.r[5] >>= 2;  // 060AED76 shlr2 r5
    c.r[6] >>= 2;  // 060AED78 shlr2 r6
    c.r[6] >>= 2;  // 060AED7A shlr2 r6
    c.r[7] >>= 2;  // 060AED7C shlr2 r7
    c.r[7] >>= 2;  // 060AED7E shlr2 r7
L_060AED80:
    c.t = (c.r[0] & 0x2u) == 0;  // 060AED80 tst #2,r0
    if (c.t) { goto L_060AED8C; }  // 060AED82 bt 0x060AED8C
    c.r[4] >>= 2;  // 060AED84 shlr2 r4
    c.r[5] >>= 2;  // 060AED86 shlr2 r5
    c.r[6] >>= 2;  // 060AED88 shlr2 r6
    c.r[7] >>= 2;  // 060AED8A shlr2 r7
L_060AED8C:
    c.t = (c.r[0] & 0x1u) == 0;  // 060AED8C tst #1,r0
    if (c.t) { goto L_060AED98; }  // 060AED8E bt 0x060AED98
    c.t = c.r[4] & 1; c.r[4] >>= 1;  // 060AED90 shlr r4
    c.t = c.r[5] & 1; c.r[5] >>= 1;  // 060AED92 shlr r5
    c.t = c.r[6] & 1; c.r[6] >>= 1;  // 060AED94 shlr r6
    c.t = c.r[7] & 1; c.r[7] >>= 1;  // 060AED96 shlr r7
L_060AED98:
    c.r[1] = 0x3Fu;  // 060AED98 mov #63,r1
    c.r[4] &= c.r[1];  // 060AED9A and r1,r4
    c.r[5] &= c.r[1];  // 060AED9C and r1,r5
    c.r[6] &= c.r[1];  // 060AED9E and r1,r6
    c.r[7] &= c.r[1];  // 060AEDA0 and r1,r7
    c.r[5] <<= 8;  // 060AEDA2 shll8 r5
    c.r[4] |= c.r[5];  // 060AEDA4 or r5,r4
    c.r[0] = c.r[4];  // 060AEDA6 mov r4,r0
    st16(c.gbr + 268, c.r[0]);  // 060AEDA8 mov.w r0,@(268,gbr)
    c.r[7] <<= 8;  // 060AEDAA shll8 r7
    c.r[6] |= c.r[7];  // 060AEDAC or r7,r6
    c.r[0] = c.r[6];  // 060AEDAE mov r6,r0
    { const uint32_t x = c.pr; st16(c.gbr + 270, c.r[0]); c.pc = x; return; }  // 060AEDB0 rts ; mov.w r0,@(270,gbr)
}

void f_060AEDB8(SH2Context& c) {
    ran[2995] = 1;
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060AEDB8 sts.l pr,@-r15
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 176);  // 060AEDBA mov.b @(176,gbr),r0
    c.r[1] = 0x1Fu;  // 060AEDBC mov #31,r1
    c.r[1] &= c.r[4];  // 060AEDBE and r4,r1
    c.r[0] &= 0x80u;  // 060AEDC0 and #128,r0
    c.r[0] |= c.r[1];  // 060AEDC2 or r1,r0
    st8(c.gbr + 176, c.r[0]);  // 060AEDC4 mov.b r0,@(176,gbr)
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060AEDC6 mov.l r1,@-r15
    c.r[0] = 0x060AF018u;  // 060AEDC8 mova 0x060AF018,r0
    c.r[1] <<= 2;  // 060AEDCA shll2 r1
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 060AEDCC mov.l @(r0,r1),r0
    st32(c.gbr + 128, c.r[0]);  // 060AEDCE mov.l r0,@(128,gbr)
    c.r[5] = ld32(0x060AEFC8u);  // 060AEDD0 mov.l 0x060AEFC8,r5
    c.r[0] = 0x060AF118u;  // 060AEDD2 mova 0x060AF118,r0
    c.r[6] = (uint32_t)(int16_t)ld16(0x060AEED6u);  // 060AEDD4 mov.w 0x060AEED6,r6
    c.pr = 0x060AEDDAu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, 0x060AEF9Cu); if (c.pc != 0x060AEDDAu) return;  // 060AEDD6 bsr 0x060AEF9C ; mov r0,r4
    c.r[0] = 0x060AF0B8u;  // 060AEDDA mova 0x060AF0B8,r0
    c.r[5] = ld32(0x060AEFD4u);  // 060AEDDC mov.l 0x060AEFD4,r5
    c.r[6] = 0x30u;  // 060AEDDE mov #48,r6
    c.pr = 0x060AEDE4u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, 0x060AEF38u); if (c.pc != 0x060AEDE4u) return;  // 060AEDE0 bsr 0x060AEF38 ; mov r0,r4
    c.pr = 0x060AEDE8u; c.r[5] += 104; SH2_POLL(c); sh2_call(c, 0x060AEF38u); if (c.pc != 0x060AEDE8u) return;  // 060AEDE4 bsr 0x060AEF38 ; add #104,r5
    c.r[0] = ld32(0x060AEFCCu);  // 060AEDE8 mov.l 0x060AEFCC,r0
    st32(c.gbr + 532, c.r[0]);  // 060AEDEA mov.l r0,@(532,gbr)
    c.r[0] = ld32(0x060AEFD4u);  // 060AEDEC mov.l 0x060AEFD4,r0
    st32(c.gbr + 480, c.r[0]);  // 060AEDEE mov.l r0,@(480,gbr)
    c.r[1] = ld32(c.r[15]); c.r[15] += 4;  // 060AEDF0 mov.l @r15+,r1
    c.r[0] = 0x060AF098u;  // 060AEDF2 mova 0x060AF098,r0
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060AEDF4 mov.b @(r0,r1),r0
    st8(c.gbr + 193, c.r[0]);  // 060AEDF6 mov.b r0,@(193,gbr)
    c.r[0] = 0x8u;  // 060AEDF8 mov #8,r0
    c.t = (c.r[1] & c.r[0]) == 0;  // 060AEDFA tst r0,r1
    { const bool k = c.t; c.r[0] = 0xCu; if (k) { goto L_060AEE02; } }  // 060AEDFC bt/s 0x060AEE02 ; mov #12,r0
    st16(c.gbr + 416, c.r[0]);  // 060AEE00 mov.w r0,@(416,gbr)
L_060AEE02:
    c.r[4] = ld32(0x060AEFC8u);  // 060AEE02 mov.l 0x060AEFC8,r4
    c.r[5] = ld32(0x060AEFD0u);  // 060AEE04 mov.l 0x060AEFD0,r5
    c.r[6] = (uint32_t)(int16_t)ld16(0x060AEED6u);  // 060AEE06 mov.w 0x060AEED6,r6
    c.pr = 0x060AEE0Cu; SH2_POLL(c); sh2_call(c, 0x060AEF9Cu); if (c.pc != 0x060AEE0Cu) return;  // 060AEE08 bsr 0x060AEF9C ; nop
    c.r[1] = 0xFFFFFF80u;  // 060AEE0C mov #-128,r1
L_060AEE0E:
    c.r[0] = ld32(c.r[1] + 12);  // 060AEE0E mov.l @(12,r1),r0
    c.r[0] &= 0x3u;  // 060AEE10 and #3,r0
    c.t = c.r[0] == 0x1u;  // 060AEE12 cmp/eq #1,r0
    if (c.t) { SH2_POLL(c); goto L_060AEE0E; }  // 060AEE14 bt 0x060AEE0E
    c.r[0] = 0x060AF00Cu;  // 060AEE16 mova 0x060AF00C,r0
    c.r[4] = c.r[0];  // 060AEE18 mov r0,r4
    c.r[5] = ld32(0x060AEFD8u);  // 060AEE1A mov.l 0x060AEFD8,r5
    c.r[6] = ld32(0x060AEFDCu);  // 060AEE1C mov.l 0x060AEFDC,r6
    c.r[3] = 0xFFFFFF80u;  // 060AEE1E mov #-128,r3
L_060AEE20:
    c.r[0] = ld32(c.r[3] + 12);  // 060AEE20 mov.l @(12,r3),r0
    c.r[0] &= 0x3u;  // 060AEE22 and #3,r0
    c.t = c.r[0] == 0x1u;  // 060AEE24 cmp/eq #1,r0
    if (c.t) { SH2_POLL(c); goto L_060AEE20; }  // 060AEE26 bt 0x060AEE20
    c.r[0] = ld32(c.r[3] + 48);  // 060AEE28 mov.l @(48,r3),r0
    c.r[0] = 0x0u;  // 060AEE2A mov #0,r0
    st32(c.r[3] + 12, c.r[0]);  // 060AEE2C mov.l r0,@(12,r3)
    c.r[3] = 0xFFFFFF9Cu;  // 060AEE2E mov #-100,r3
    c.r[3] <<= 2;  // 060AEE30 shll2 r3
    st8(c.r[3] + 1, c.r[0]);  // 060AEE32 mov.b r0,@(1,r3)
    c.r[3] = 0xFFFFFF80u;  // 060AEE34 mov #-128,r3
    st32(c.r[3], c.r[4]);  // 060AEE36 mov.l r4,@(0,r3)
    st32(c.r[3] + 4, c.r[5]);  // 060AEE38 mov.l r5,@(4,r3)
    st32(c.r[3] + 8, c.r[6]);  // 060AEE3A mov.l r6,@(8,r3)
    c.r[0] = (uint32_t)(int16_t)ld16(0x060AF012u);  // 060AEE3C mov.w 0x060AF012,r0
    st32(c.r[3] + 12, c.r[0]);  // 060AEE3E mov.l r0,@(12,r3)
    c.r[0] = 0x9u;  // 060AEE40 mov #9,r0
    st32(c.r[3] + 48, c.r[0]);  // 060AEE42 mov.l r0,@(48,r3)
    c.r[1] = 0xFFFFFF80u;  // 060AEE44 mov #-128,r1
L_060AEE46:
    c.r[0] = ld32(c.r[1] + 12);  // 060AEE46 mov.l @(12,r1),r0
    c.r[0] &= 0x3u;  // 060AEE48 and #3,r0
    c.t = c.r[0] == 0x1u;  // 060AEE4A cmp/eq #1,r0
    if (c.t) { SH2_POLL(c); goto L_060AEE46; }  // 060AEE4C bt 0x060AEE46
    c.r[4] = ld32(0x060AEFE0u);  // 060AEE4E mov.l 0x060AEFE0,r4
    c.r[5] = 0xFFFFFF80u;  // 060AEE50 mov #-128,r5
    c.r[5] = c.r[5] & 0xFFu;  // 060AEE52 extu.b r5,r5
    c.r[0] = ld32(0x060AEFE4u);  // 060AEE54 mov.l 0x060AEFE4,r0
    st32(c.gbr + 484, c.r[0]);  // 060AEE56 mov.l r0,@(484,gbr)
    st32(c.gbr + 488, c.r[0]);  // 060AEE58 mov.l r0,@(488,gbr)
    c.r[6] = c.r[0];  // 060AEE5A mov r0,r6
    c.pr = 0x060AEE60u; c.r[7] = 0x0u; SH2_POLL(c); sh2_call(c, 0x060AEED8u); if (c.pc != 0x060AEE60u) return;  // 060AEE5C bsr 0x060AEED8 ; mov #0,r7
    c.r[4] = ld32(0x060AEFE8u);  // 060AEE60 mov.l 0x060AEFE8,r4
    c.r[5] = 0x18u;  // 060AEE62 mov #24,r5
    c.pr = 0x060AEE68u; c.r[7] = 0x0u; SH2_POLL(c); sh2_call(c, 0x060AEF08u); if (c.pc != 0x060AEE68u) return;  // 060AEE64 bsr 0x060AEF08 ; mov #0,r7
    c.r[4] = ld32(0x060AEFECu);  // 060AEE68 mov.l 0x060AEFEC,r4
    c.r[5] = 0x3u;  // 060AEE6A mov #3,r5
    c.r[6] = ld32(0x060AEFF0u);  // 060AEE6C mov.l 0x060AEFF0,r6
    c.pr = 0x060AEE72u; c.r[7] = 0x0u; SH2_POLL(c); sh2_call(c, 0x060AEED8u); if (c.pc != 0x060AEE72u) return;  // 060AEE6E bsr 0x060AEED8 ; mov #0,r7
    c.r[4] = ld32(0x060AEFE4u);  // 060AEE72 mov.l 0x060AEFE4,r4
    c.r[5] = ld32(0x060AEFF4u);  // 060AEE74 mov.l 0x060AEFF4,r5
    c.r[6] = (uint32_t)(int16_t)ld16(0x060AF00Eu);  // 060AEE76 mov.w 0x060AF00E,r6
    c.r[0] = c.r[5];  // 060AEE78 mov r5,r0
    st32(c.gbr + 500, c.r[0]);  // 060AEE7A mov.l r0,@(500,gbr)
    st32(c.gbr + 504, c.r[0]);  // 060AEE7C mov.l r0,@(504,gbr)
    c.r[3] = 0xFFFFFF80u;  // 060AEE7E mov #-128,r3
L_060AEE80:
    c.r[0] = ld32(c.r[3] + 12);  // 060AEE80 mov.l @(12,r3),r0
    c.r[0] &= 0x3u;  // 060AEE82 and #3,r0
    c.t = c.r[0] == 0x1u;  // 060AEE84 cmp/eq #1,r0
    if (c.t) { SH2_POLL(c); goto L_060AEE80; }  // 060AEE86 bt 0x060AEE80
    c.r[0] = ld32(c.r[3] + 48);  // 060AEE88 mov.l @(48,r3),r0
    c.r[0] = 0x0u;  // 060AEE8A mov #0,r0
    st32(c.r[3] + 12, c.r[0]);  // 060AEE8C mov.l r0,@(12,r3)
    c.r[3] = 0xFFFFFF9Cu;  // 060AEE8E mov #-100,r3
    c.r[3] <<= 2;  // 060AEE90 shll2 r3
    st8(c.r[3] + 1, c.r[0]);  // 060AEE92 mov.b r0,@(1,r3)
    c.r[3] = 0xFFFFFF80u;  // 060AEE94 mov #-128,r3
    st32(c.r[3], c.r[4]);  // 060AEE96 mov.l r4,@(0,r3)
    st32(c.r[3] + 4, c.r[5]);  // 060AEE98 mov.l r5,@(4,r3)
    st32(c.r[3] + 8, c.r[6]);  // 060AEE9A mov.l r6,@(8,r3)
    c.r[0] = (uint32_t)(int16_t)ld16(0x060AF014u);  // 060AEE9C mov.w 0x060AF014,r0
    st32(c.r[3] + 12, c.r[0]);  // 060AEE9E mov.l r0,@(12,r3)
    c.r[0] = 0x9u;  // 060AEEA0 mov #9,r0
    st32(c.r[3] + 48, c.r[0]);  // 060AEEA2 mov.l r0,@(48,r3)
    c.r[0] = ld32(0x060AEFF8u);  // 060AEEA4 mov.l 0x060AEFF8,r0
    st32(c.gbr + 508, c.r[0]);  // 060AEEA6 mov.l r0,@(508,gbr)
    c.r[0] = ld32(0x060AEFFCu);  // 060AEEA8 mov.l 0x060AEFFC,r0
    st32(c.gbr + 512, c.r[0]);  // 060AEEAA mov.l r0,@(512,gbr)
    c.r[0] = ld32(0x060AF000u);  // 060AEEAC mov.l 0x060AF000,r0
    st32(c.gbr + 524, c.r[0]);  // 060AEEAE mov.l r0,@(524,gbr)
    c.r[0] = ld32(0x060AF004u);  // 060AEEB0 mov.l 0x060AF004,r0
    st32(c.gbr + 528, c.r[0]);  // 060AEEB2 mov.l r0,@(528,gbr)
    c.r[0] = 0x0u;  // 060AEEB4 mov #0,r0
    st32(c.gbr + 748, c.r[0]);  // 060AEEB6 mov.l r0,@(748,gbr)
    st32(c.gbr + 752, c.r[0]);  // 060AEEB8 mov.l r0,@(752,gbr)
    st32(c.gbr + 756, c.r[0]);  // 060AEEBA mov.l r0,@(756,gbr)
    st32(c.gbr + 760, c.r[0]);  // 060AEEBC mov.l r0,@(760,gbr)
    c.r[1] = ld32(0x060AF008u);  // 060AEEBE mov.l 0x060AF008,r1
    c.r[0] = 0x0u;  // 060AEEC0 mov #0,r0
    st8(c.gbr + 33, c.r[0]);  // 060AEEC2 mov.b r0,@(33,gbr)
    c.pr = 0x060AEEC8u; st16(c.r[1], c.r[0]); SH2_POLL(c); sh2_call(c, 0x060AF238u); if (c.pc != 0x060AEEC8u) return;  // 060AEEC4 bsr 0x060AF238 ; mov.w r0,@r1
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 192);  // 060AEEC8 mov.w @(192,gbr),r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x060AEED4u);  // 060AEECA mov.w 0x060AEED4,r1
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060AEECC lds.l @r15+,pr
    c.r[0] |= c.r[1];  // 060AEECE or r1,r0
    { const uint32_t x = c.pr; st16(c.gbr + 192, c.r[0]); c.pc = x; return; }  // 060AEED0 rts ; mov.w r0,@(192,gbr)
}

void f_060AEED8(SH2Context& c) {
    ran[2996] = 1;
    c.r[7] = c.r[7] & 0xFFu;  // 060AEED8 extu.b r7,r7
L_060AEEDA:
    c.r[3] = 0x8u;  // 060AEEDA mov #8,r3
L_060AEEDC:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 060AEEDC mov.b @r4+,r0
    c.r[1] = 0x4u;  // 060AEEDE mov #4,r1
    c.r[0] <<= 8;  // 060AEEE0 shll8 r0
    c.r[0] <<= 16;  // 060AEEE2 shll16 r0
L_060AEEE4:
    c.t = c.r[0] >> 31; c.r[0] <<= 1;  // 060AEEE4 shll r0
    c.r[2] = c.t;  // 060AEEE6 movt r2
    c.r[2] += c.r[7];  // 060AEEE8 add r7,r2
    c.r[2] <<= 8;  // 060AEEEA shll8 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 060AEEEC shlr r2
    c.t = c.r[0] >> 31; c.r[0] <<= 1;  // 060AEEEE shll r0
    { uint64_t s = (uint64_t)c.r[2] + c.r[2] + c.t; c.t = (uint32_t)(s >> 32); c.r[2] = (uint32_t)s; }  // 060AEEF0 addc r2,r2
    c.r[2] += c.r[7];  // 060AEEF2 add r7,r2
    st16(c.r[6], c.r[2]);  // 060AEEF4 mov.w r2,@r6
    c.r[1] -= 1; c.t = c.r[1] == 0;  // 060AEEF6 dt r1
    { const bool k = !c.t; c.r[6] += 2; if (k) { SH2_POLL(c); goto L_060AEEE4; } }  // 060AEEF8 bf/s 0x060AEEE4 ; add #2,r6
    c.r[3] -= 1; c.t = c.r[3] == 0;  // 060AEEFC dt r3
    if (!c.t) { SH2_POLL(c); goto L_060AEEDC; }  // 060AEEFE bf 0x060AEEDC
    c.r[5] -= 1; c.t = c.r[5] == 0;  // 060AEF00 dt r5
    if (!c.t) { SH2_POLL(c); goto L_060AEEDA; }  // 060AEF02 bf 0x060AEEDA
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060AEF04 rts ; nop
}

void f_060AEF08(SH2Context& c) {
    ran[2997] = 1;
    c.r[7] = c.r[7] & 0xFFu;  // 060AEF08 extu.b r7,r7
    c.r[0] = c.r[7];  // 060AEF0A mov r7,r0
    c.r[7] <<= 8;  // 060AEF0C shll8 r7
    c.r[7] |= c.r[0];  // 060AEF0E or r0,r7
L_060AEF10:
    c.r[3] = 0x8u;  // 060AEF10 mov #8,r3
L_060AEF12:
    c.r[1] = 0x4u;  // 060AEF12 mov #4,r1
L_060AEF14:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 060AEF14 mov.b @r4+,r0
    c.r[2] = c.r[0] & 0xFFu;  // 060AEF16 extu.b r0,r2
    c.r[2] >>= 2;  // 060AEF18 shlr2 r2
    c.r[2] >>= 2;  // 060AEF1A shlr2 r2
    c.r[2] <<= 8;  // 060AEF1C shll8 r2
    c.r[0] &= 0xFu;  // 060AEF1E and #15,r0
    c.r[0] |= c.r[2];  // 060AEF20 or r2,r0
    c.r[0] += c.r[7];  // 060AEF22 add r7,r0
    st16(c.r[6], c.r[0]);  // 060AEF24 mov.w r0,@r6
    c.r[1] -= 1; c.t = c.r[1] == 0;  // 060AEF26 dt r1
    { const bool k = !c.t; c.r[6] += 2; if (k) { SH2_POLL(c); goto L_060AEF14; } }  // 060AEF28 bf/s 0x060AEF14 ; add #2,r6
    c.r[3] -= 1; c.t = c.r[3] == 0;  // 060AEF2C dt r3
    if (!c.t) { SH2_POLL(c); goto L_060AEF12; }  // 060AEF2E bf 0x060AEF12
    c.r[5] -= 1; c.t = c.r[5] == 0;  // 060AEF30 dt r5
    if (!c.t) { SH2_POLL(c); goto L_060AEF10; }  // 060AEF32 bf 0x060AEF10
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060AEF34 rts ; nop
}

void f_060AEF38(SH2Context& c) {
    ran[2998] = 1;
    c.r[3] = 0xFFFFFF80u;  // 060AEF38 mov #-128,r3
L_060AEF3A:
    c.r[0] = ld32(c.r[3] + 12);  // 060AEF3A mov.l @(12,r3),r0
    c.r[0] &= 0x3u;  // 060AEF3C and #3,r0
    c.t = c.r[0] == 0x1u;  // 060AEF3E cmp/eq #1,r0
    if (c.t) { SH2_POLL(c); goto L_060AEF3A; }  // 060AEF40 bt 0x060AEF3A
    c.r[0] = ld32(c.r[3] + 48);  // 060AEF42 mov.l @(48,r3),r0
    c.r[0] = 0x0u;  // 060AEF44 mov #0,r0
    st32(c.r[3] + 12, c.r[0]);  // 060AEF46 mov.l r0,@(12,r3)
    c.r[3] = 0xFFFFFF9Cu;  // 060AEF48 mov #-100,r3
    c.r[3] <<= 2;  // 060AEF4A shll2 r3
    st8(c.r[3] + 1, c.r[0]);  // 060AEF4C mov.b r0,@(1,r3)
    c.r[3] = 0xFFFFFF80u;  // 060AEF4E mov #-128,r3
    st32(c.r[3], c.r[4]);  // 060AEF50 mov.l r4,@(0,r3)
    st32(c.r[3] + 4, c.r[5]);  // 060AEF52 mov.l r5,@(4,r3)
    st32(c.r[3] + 8, c.r[6]);  // 060AEF54 mov.l r6,@(8,r3)
    c.r[0] = (uint32_t)(int16_t)ld16(0x060AF010u);  // 060AEF56 mov.w 0x060AF010,r0
    st32(c.r[3] + 12, c.r[0]);  // 060AEF58 mov.l r0,@(12,r3)
    c.r[0] = 0x9u;  // 060AEF5A mov #9,r0
    st32(c.r[3] + 48, c.r[0]);  // 060AEF5C mov.l r0,@(48,r3)
    c.r[1] = 0xFFFFFF80u;  // 060AEF5E mov #-128,r1
L_060AEF60:
    c.r[0] = ld32(c.r[1] + 12);  // 060AEF60 mov.l @(12,r1),r0
    c.r[0] &= 0x3u;  // 060AEF62 and #3,r0
    c.t = c.r[0] == 0x1u;  // 060AEF64 cmp/eq #1,r0
    if (c.t) { SH2_POLL(c); goto L_060AEF60; }  // 060AEF66 bt 0x060AEF60
    c.r[0] = ld32(c.gbr + 128);  // 060AEF68 mov.l @(128,gbr),r0
    c.r[2] = 0x1u;  // 060AEF6A mov #1,r2
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060AEF6C shlr r0
    c.r[1] = c.r[0];  // 060AEF6E mov r0,r1
    c.r[2] <<= 8;  // 060AEF70 shll8 r2
    c.r[3] = c.r[2] << 16 | c.r[2] >> 16;  // 060AEF72 swap.w r2,r3
    c.r[3] |= c.r[2];  // 060AEF74 or r2,r3
    st32(c.r[5] + 52, c.r[3]);  // 060AEF76 mov.l r3,@(52,r5)
    st32(c.r[5] + 60, c.r[3]);  // 060AEF78 mov.l r3,@(60,r5)
    c.r[0] = 0x38u;  // 060AEF7A mov #56,r0
    st16(c.r[0] + c.r[5], c.r[2]);  // 060AEF7C mov.w r2,@(r0,r5)
    c.r[0] = 0x40u;  // 060AEF7E mov #64,r0
    st16(c.r[0] + c.r[5], c.r[2]);  // 060AEF80 mov.w r2,@(r0,r5)
    c.r[0] = c.r[1] << 16 | c.r[1] >> 16;  // 060AEF82 swap.w r1,r0
    c.r[3] = c.r[2];  // 060AEF84 mov r2,r3
    c.r[3] -= c.r[0];  // 060AEF86 sub r0,r3
    c.r[2] -= c.r[1];  // 060AEF88 sub r1,r2
    c.r[2] <<= 16;  // 060AEF8A shll16 r2
    c.r[2] = c.r[3] << 16 | c.r[2] >> 16;  // 060AEF8C xtrct r3,r2
    c.r[0] = c.r[2];  // 060AEF8E mov r2,r0
    c.r[0] <<= 16;  // 060AEF90 shll16 r0
    st32(c.r[5] + 4, c.r[0]);  // 060AEF92 mov.l r0,@(4,r5)
    c.r[2] >>= 16;  // 060AEF94 shlr16 r2
    c.r[2] <<= 16;  // 060AEF96 shll16 r2
    { const uint32_t x = c.pr; st32(c.r[5], c.r[2]); c.pc = x; return; }  // 060AEF98 rts ; mov.l r2,@(0,r5)
}

void f_060AEF9C(SH2Context& c) {
    ran[2999] = 1;
    c.r[3] = 0xFFFFFF80u;  // 060AEF9C mov #-128,r3
L_060AEF9E:
    c.r[0] = ld32(c.r[3] + 12);  // 060AEF9E mov.l @(12,r3),r0
    c.r[0] &= 0x3u;  // 060AEFA0 and #3,r0
    c.t = c.r[0] == 0x1u;  // 060AEFA2 cmp/eq #1,r0
    if (c.t) { SH2_POLL(c); goto L_060AEF9E; }  // 060AEFA4 bt 0x060AEF9E
    c.r[0] = ld32(c.r[3] + 48);  // 060AEFA6 mov.l @(48,r3),r0
    c.r[0] = 0x0u;  // 060AEFA8 mov #0,r0
    st32(c.r[3] + 12, c.r[0]);  // 060AEFAA mov.l r0,@(12,r3)
    c.r[3] = 0xFFFFFF9Cu;  // 060AEFAC mov #-100,r3
    c.r[3] <<= 2;  // 060AEFAE shll2 r3
    st8(c.r[3] + 1, c.r[0]);  // 060AEFB0 mov.b r0,@(1,r3)
    c.r[3] = 0xFFFFFF80u;  // 060AEFB2 mov #-128,r3
    st32(c.r[3], c.r[4]);  // 060AEFB4 mov.l r4,@(0,r3)
    st32(c.r[3] + 4, c.r[5]);  // 060AEFB6 mov.l r5,@(4,r3)
    st32(c.r[3] + 8, c.r[6]);  // 060AEFB8 mov.l r6,@(8,r3)
    c.r[0] = (uint32_t)(int16_t)ld16(0x060AF010u);  // 060AEFBA mov.w 0x060AF010,r0
    st32(c.r[3] + 12, c.r[0]);  // 060AEFBC mov.l r0,@(12,r3)
    c.r[0] = 0x9u;  // 060AEFBE mov #9,r0
    st32(c.r[3] + 48, c.r[0]);  // 060AEFC0 mov.l r0,@(48,r3)
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060AEFC2 rts ; nop
}

void f_060AF238(SH2Context& c) {
    ran[3000] = 1;
    c.r[0] = 0x060AF250u;  // 060AF238 mova 0x060AF250,r0
    c.r[3] = ld32(0x060AF24Cu);  // 060AF23A mov.l 0x060AF24C,r3
    c.r[1] = 0x8u;  // 060AF23C mov #8,r1
L_060AF23E:
    c.r[2] = ld32(c.r[0]); c.r[0] += 4;  // 060AF23E mov.l @r0+,r2
    c.r[3] += 4;  // 060AF240 add #4,r3
    c.r[1] -= 1; c.t = c.r[1] == 0;  // 060AF242 dt r1
    { const bool k = !c.t; st32(c.r[3], c.r[2]); if (k) { SH2_POLL(c); goto L_060AF23E; } }  // 060AF244 bf/s 0x060AF23E ; mov.l r2,@r3
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060AF248 rts ; nop
}

void f_060AF988(SH2Context& c) {
    ran[3001] = 1;
    c.r[0] = 0xFu;  // 060AF988 mov #15,r0
    c.r[7] &= c.r[0];  // 060AF98A and r0,r7
    c.r[0] = c.r[7];  // 060AF98C mov r7,r0
    c.r[7] <<= 2;  // 060AF98E shll2 r7
    c.r[7] <<= 2;  // 060AF990 shll2 r7
    c.r[7] |= c.r[0];  // 060AF992 or r0,r7
    c.r[0] = (c.r[7] & 0xFFFF0000u) | (c.r[7] & 0xFFu) << 8 | (c.r[7] >> 8 & 0xFFu);  // 060AF994 swap.b r7,r0
    c.r[7] |= c.r[0];  // 060AF996 or r0,r7
    c.r[3] = ld32(c.r[15]);  // 060AF998 mov.l @r15,r3
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060AF99A mov.l r8,@-r15
L_060AF99C:
    c.r[8] = 0x8u;  // 060AF99C mov #8,r8
L_060AF99E:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 060AF99E mov.b @r4+,r0
    c.r[1] = 0x2u;  // 060AF9A0 mov #2,r1
    c.r[0] <<= 8;  // 060AF9A2 shll8 r0
    c.r[0] <<= 16;  // 060AF9A4 shll16 r0
L_060AF9A6:
    c.t = c.r[0] >> 31; c.r[0] <<= 1;  // 060AF9A6 shll r0
    c.r[2] = c.t;  // 060AF9A8 movt r2
    c.r[2] <<= 2;  // 060AF9AA shll2 r2
    c.t = c.r[2] >> 31; c.r[2] <<= 1;  // 060AF9AC shll r2
    c.t = c.r[0] >> 31; c.r[0] <<= 1;  // 060AF9AE shll r0
    { uint64_t s = (uint64_t)c.r[2] + c.r[2] + c.t; c.t = (uint32_t)(s >> 32); c.r[2] = (uint32_t)s; }  // 060AF9B0 addc r2,r2
    c.r[2] <<= 2;  // 060AF9B2 shll2 r2
    c.t = c.r[2] >> 31; c.r[2] <<= 1;  // 060AF9B4 shll r2
    c.t = c.r[0] >> 31; c.r[0] <<= 1;  // 060AF9B6 shll r0
    { uint64_t s = (uint64_t)c.r[2] + c.r[2] + c.t; c.t = (uint32_t)(s >> 32); c.r[2] = (uint32_t)s; }  // 060AF9B8 addc r2,r2
    c.r[2] <<= 2;  // 060AF9BA shll2 r2
    c.r[2] <<= 2;  // 060AF9BC shll2 r2
    c.t = c.r[0] >> 31; c.r[0] <<= 1;  // 060AF9BE shll r0
    { uint64_t s = (uint64_t)c.r[2] + c.r[7] + c.t; c.t = (uint32_t)(s >> 32); c.r[2] = (uint32_t)s; }  // 060AF9C0 addc r7,r2
    st16(c.r[5], c.r[2]);  // 060AF9C2 mov.w r2,@r5
    c.r[1] -= 1; c.t = c.r[1] == 0;  // 060AF9C4 dt r1
    { const bool k = !c.t; c.r[5] += 2; if (k) { SH2_POLL(c); goto L_060AF9A6; } }  // 060AF9C6 bf/s 0x060AF9A6 ; add #2,r5
    c.r[8] -= 1; c.t = c.r[8] == 0;  // 060AF9CA dt r8
    if (!c.t) { SH2_POLL(c); goto L_060AF99E; }  // 060AF9CC bf 0x060AF99E
    c.r[6] -= 1; c.t = c.r[6] == 0;  // 060AF9CE dt r6
    { const bool k = !c.t; c.r[5] += c.r[3]; if (k) { SH2_POLL(c); goto L_060AF99C; } }  // 060AF9D0 bf/s 0x060AF99C ; add r3,r5
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060AF9D4 rts ; mov.l @r15+,r8
}

void f_060AF9D8(SH2Context& c) {
    ran[3002] = 1;
    c.r[1] = 0xFFFFFFFCu; goto L_060AF9F8;  // 060AF9D8 bra 0x060AF9F8 ; mov #-4,r1
L_060AF9F8:
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 426);  // 060AF9F8 mov.w @(426,gbr),r0
    c.r[0] &= c.r[1];  // 060AF9FA and r1,r0
    c.r[0] |= c.r[4];  // 060AF9FC or r4,r0
    { const uint32_t x = c.pr; st16(c.gbr + 426, c.r[0]); c.pc = x; return; }  // 060AF9FE rts ; mov.w r0,@(426,gbr)
}

void f_060AF9DC(SH2Context& c) {
    ran[3003] = 1;
    c.r[1] = 0xFFFFFFF3u; goto L_060AF9F6;  // 060AF9DC bra 0x060AF9F6 ; mov #-13,r1
L_060AF9F6:
    c.r[4] <<= 2;  // 060AF9F6 shll2 r4
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 426);  // 060AF9F8 mov.w @(426,gbr),r0
    c.r[0] &= c.r[1];  // 060AF9FA and r1,r0
    c.r[0] |= c.r[4];  // 060AF9FC or r4,r0
    { const uint32_t x = c.pr; st16(c.gbr + 426, c.r[0]); c.pc = x; return; }  // 060AF9FE rts ; mov.w r0,@(426,gbr)
}

void f_060AFA04(SH2Context& c) {
    ran[3004] = 1;
    c.r[2] = ld32(0x060AFA0Cu);  // 060AFA04 mov.l 0x060AFA0C,r2
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[2] + 2);  // 060AFA06 mov.w @(2,r2),r0
    { const uint32_t x = c.pr; c.r[0] = (uint32_t)(int16_t)ld16(c.r[2] + 8); c.pc = x; return; }  // 060AFA08 rts ; mov.w @(8,r2),r0
}

void f_060AFA10(SH2Context& c) {
    ran[3005] = 1;
    c.r[0] = 0x0u;  // 060AFA10 mov #0,r0
    st8(c.gbr + 204, c.r[0]);  // 060AFA12 mov.b r0,@(204,gbr)
    c.r[0] = ld32(c.gbr + 480);  // 060AFA14 mov.l @(480,gbr),r0
    c.r[1] = ld32(0x060AFA30u);  // 060AFA16 mov.l 0x060AFA30,r1
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060AFA18 sts.l pr,@-r15
    { const uint32_t x = c.r[1]; c.pr = 0x060AFA1Eu; c.r[7] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AFA1Eu) return; }  // 060AFA1A jsr @r1 ; mov r0,r7
    st32(c.r[7] + 40, c.r[4]);  // 060AFA1E mov.l r4,@(40,r7)
    c.r[4] = 0u - c.r[4];  // 060AFA20 neg r4,r4
    st32(c.r[7] + 32, c.r[4]);  // 060AFA22 mov.l r4,@(32,r7)
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060AFA24 lds.l @r15+,pr
    st32(c.r[7] + 28, c.r[5]);  // 060AFA26 mov.l r5,@(28,r7)
    c.r[0] = 0x1u;  // 060AFA28 mov #1,r0
    st8(c.gbr + 204, c.r[0]);  // 060AFA2A mov.b r0,@(204,gbr)
    { const uint32_t x = c.pr; st32(c.r[7] + 44, c.r[5]); c.pc = x; return; }  // 060AFA2C rts ; mov.l r5,@(44,r7)
}

void f_060AFA34(SH2Context& c) {
    ran[3006] = 1;
    c.r[0] = ld32(c.gbr + 480);  // 060AFA34 mov.l @(480,gbr),r0
    c.r[15] -= 4; st32(c.r[15], c.gbr);  // 060AFA36 stc.l gbr,@-r15
    c.gbr = c.r[0];  // 060AFA38 ldc r0,gbr
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 60);  // 060AFA3A mov.w @(60,gbr),r0
    c.r[0] <<= 16;  // 060AFA3C shll16 r0
    c.r[4] -= c.r[0];  // 060AFA3E sub r0,r4
    c.r[0] = c.r[4];  // 060AFA40 mov r4,r0
    st32(c.gbr + 68, c.r[0]);  // 060AFA42 mov.l r0,@(68,gbr)
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 62);  // 060AFA44 mov.w @(62,gbr),r0
    c.r[0] <<= 16;  // 060AFA46 shll16 r0
    c.r[5] -= c.r[0];  // 060AFA48 sub r0,r5
    c.r[0] = c.r[5];  // 060AFA4A mov r5,r0
    st32(c.gbr + 72, c.r[0]);  // 060AFA4C mov.l r0,@(72,gbr)
    { const uint32_t x = c.pr; { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.gbr = v; } c.pc = x; return; }  // 060AFA4E rts ; ldc.l @r15+,gbr
}

void f_060AFA54(SH2Context& c) {
    ran[3007] = 1;
    c.r[0] = ld32(c.gbr + 480);  // 060AFA54 mov.l @(480,gbr),r0
    c.r[1] = 0x4Cu;  // 060AFA56 mov #76,r1
    st32(c.r[0] + c.r[1], c.r[4]);  // 060AFA58 mov.l r4,@(r0,r1)
    c.r[1] = 0x50u;  // 060AFA5A mov #80,r1
    { const uint32_t x = c.pr; st32(c.r[0] + c.r[1], c.r[5]); c.pc = x; return; }  // 060AFA5C rts ; mov.l r5,@(r0,r1)
}

void f_060AFA60(SH2Context& c) {
    ran[3008] = 1;
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 422);  // 060AFA60 mov.w @(422,gbr),r0
    c.r[1] = 0xFFFFFFF0u;  // 060AFA62 mov #-16,r1
    c.r[0] &= c.r[1];  // 060AFA64 and r1,r0
    c.r[0] |= c.r[4];  // 060AFA66 or r4,r0
    { const uint32_t x = c.pr; st16(c.gbr + 422, c.r[0]); c.pc = x; return; }  // 060AFA68 rts ; mov.w r0,@(422,gbr)
}

void f_060AFA6C(SH2Context& c) {
    ran[3009] = 1;
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060AFA6C sts.l pr,@-r15
    c.r[15] -= 4; st32(c.r[15], c.gbr);  // 060AFA6E stc.l gbr,@-r15
    c.r[0] = c.r[4];  // 060AFA70 mov r4,r0
    st32(c.gbr + 532, c.r[0]);  // 060AFA72 mov.l r0,@(532,gbr)
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060AFA74 shlr r0
    st32(c.gbr + 380, c.r[0]);  // 060AFA76 mov.l r0,@(380,gbr)
    c.r[0] = ld32(c.gbr + 128);  // 060AFA78 mov.l @(128,gbr),r0
    c.r[2] = c.r[0];  // 060AFA7A mov r0,r2
    c.r[0] = ld32(c.gbr + 104);  // 060AFA7C mov.l @(104,gbr),r0
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 060AFA7E shlr r2
    c.r[3] = c.r[0];  // 060AFA80 mov r0,r3
    c.r[0] = ld32(0x060AFA98u);  // 060AFA82 mov.l 0x060AFA98,r0
    c.pr = 0x060AFA88u; st32(c.gbr + 480, c.r[0]); SH2_POLL(c); sh2_call(c, 0x060AFAA0u); if (c.pc != 0x060AFA88u) return;  // 060AFA84 bsr 0x060AFAA0 ; mov.l r0,@(480,gbr)
    c.r[0] = ld32(0x060AFA9Cu);  // 060AFA88 mov.l 0x060AFA9C,r0
    c.pr = 0x060AFA8Eu; SH2_POLL(c); sh2_call(c, 0x060AFAA0u); if (c.pc != 0x060AFA8Eu) return;  // 060AFA8A bsr 0x060AFAA0 ; nop
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.gbr = v; }  // 060AFA8E ldc.l @r15+,gbr
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060AFA90 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060AFA92 rts ; nop
}

void f_060AFAA0(SH2Context& c) {
    ran[3010] = 1;
    c.gbr = c.r[0];  // 060AFAA0 ldc r0,gbr
    c.r[0] = 0x0u;  // 060AFAA2 mov #0,r0
    st32(c.gbr, c.r[0]);  // 060AFAA4 mov.l r0,@(0,gbr)
    st32(c.gbr + 4, c.r[0]);  // 060AFAA6 mov.l r0,@(4,gbr)
    st32(c.gbr + 8, c.r[0]);  // 060AFAA8 mov.l r0,@(8,gbr)
    st32(c.gbr + 12, c.r[0]);  // 060AFAAA mov.l r0,@(12,gbr)
    st32(c.gbr + 24, c.r[0]);  // 060AFAAC mov.l r0,@(24,gbr)
    st32(c.gbr + 32, c.r[0]);  // 060AFAAE mov.l r0,@(32,gbr)
    st32(c.gbr + 36, c.r[0]);  // 060AFAB0 mov.l r0,@(36,gbr)
    st32(c.gbr + 40, c.r[0]);  // 060AFAB2 mov.l r0,@(40,gbr)
    st32(c.gbr + 48, c.r[0]);  // 060AFAB4 mov.l r0,@(48,gbr)
    st32(c.gbr + 68, c.r[0]);  // 060AFAB6 mov.l r0,@(68,gbr)
    st32(c.gbr + 72, c.r[0]);  // 060AFAB8 mov.l r0,@(72,gbr)
    c.r[0] = 0x1u;  // 060AFABA mov #1,r0
    c.r[0] <<= 16;  // 060AFABC shll16 r0
    st32(c.gbr + 16, c.r[0]);  // 060AFABE mov.l r0,@(16,gbr)
    st32(c.gbr + 20, c.r[0]);  // 060AFAC0 mov.l r0,@(20,gbr)
    st32(c.gbr + 28, c.r[0]);  // 060AFAC2 mov.l r0,@(28,gbr)
    st32(c.gbr + 44, c.r[0]);  // 060AFAC4 mov.l r0,@(44,gbr)
    st32(c.gbr + 76, c.r[0]);  // 060AFAC6 mov.l r0,@(76,gbr)
    st32(c.gbr + 80, c.r[0]);  // 060AFAC8 mov.l r0,@(80,gbr)
    c.r[0] = c.r[2];  // 060AFACA mov r2,r0
    st32(c.gbr + 52, c.r[0]);  // 060AFACC mov.l r0,@(52,gbr)
    st32(c.gbr + 60, c.r[0]);  // 060AFACE mov.l r0,@(60,gbr)
    c.r[0] = c.r[3] << 16 | c.r[3] >> 16;  // 060AFAD0 swap.w r3,r0
    st16(c.gbr + 56, c.r[0]);  // 060AFAD2 mov.w r0,@(56,gbr)
    st16(c.gbr + 64, c.r[0]);  // 060AFAD4 mov.w r0,@(64,gbr)
    c.r[0] = 0x0u;  // 060AFAD6 mov #0,r0
    { const uint32_t x = c.pr; st16(c.gbr + 100, c.r[0]); c.pc = x; return; }  // 060AFAD8 rts ; mov.w r0,@(100,gbr)
}

void f_060AFADC(SH2Context& c) {
    ran[3011] = 1;
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 250);  // 060AFADC mov.b @(250,gbr),r0
    c.r[0] &= 0xFCu;  // 060AFADE and #252,r0
    c.r[0] |= c.r[4];  // 060AFAE0 or r4,r0
    { const uint32_t x = c.pr; st8(c.gbr + 250, c.r[0]); c.pc = x; return; }  // 060AFAE2 rts ; mov.b r0,@(250,gbr)
}

void f_060AFAE8(SH2Context& c) {
    ran[3012] = 1;
    c.r[6] = c.r[4];  // 060AFAE8 mov r4,r6
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[4]);  // 060AFAEA mov.b @r4,r4
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060AFAEC sts.l pr,@-r15
    c.r[1] = ld32(0x060AFB50u);  // 060AFAEE mov.l 0x060AFB50,r1
    c.r[4] <<= 8;  // 060AFAF0 shll8 r4
    c.r[4] <<= 2;  // 060AFAF2 shll2 r4
    { const uint32_t x = c.r[1]; c.pr = 0x060AFAF8u; c.t = c.r[4] >> 31; c.r[4] <<= 1; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AFAF8u) return; }  // 060AFAF4 jsr @r1 ; shll r4
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060AFAF8 lds.l @r15+,pr
    c.r[3] = ld32(0x060AFB54u);  // 060AFAFA mov.l 0x060AFB54,r3
    c.r[3] += 16; goto L_060AFB16;  // 060AFAFC bra 0x060AFB16 ; add #16,r3
L_060AFB16:
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 248);  // 060AFB16 mov.w @(248,gbr),r0
    c.r[1] = c.r[0] << 16 | c.r[0] >> 16;  // 060AFB18 swap.w r0,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 234);  // 060AFB1A mov.b @(234,gbr),r0
    c.t = c.r[1] >> 31; c.r[1] <<= 1;  // 060AFB1C shll r1
    { uint32_t t = c.r[0] >> 31; c.r[0] = c.r[0] << 1 | c.t; c.t = t; }  // 060AFB1E rotcl r0
    c.r[1] = 0x8u;  // 060AFB20 mov #8,r1
L_060AFB22:
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[6]); c.r[6] += 1;  // 060AFB22 mov.b @r6+,r2
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[6]); c.r[6] += 1;  // 060AFB24 mov.b @r6+,r4
    c.r[2] = c.r[2] & 0xFFu;  // 060AFB26 extu.b r2,r2
    c.t = (c.r[0] & 0x2u) == 0;  // 060AFB28 tst #2,r0
    { const bool k = !c.t; c.r[4] = c.r[4] & 0xFFu; if (k) { goto L_060AFB32; } }  // 060AFB2A bf/s 0x060AFB32 ; extu.b r4,r4
    c.r[2] >>= 2;  // 060AFB2E shlr2 r2
    c.r[4] >>= 2;  // 060AFB30 shlr2 r4
L_060AFB32:
    c.t = (c.r[0] & 0x1u) == 0;  // 060AFB32 tst #1,r0
    if (!c.t) { goto L_060AFB3A; }  // 060AFB34 bf 0x060AFB3A
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 060AFB36 shlr r2
    c.t = c.r[4] & 1; c.r[4] >>= 1;  // 060AFB38 shlr r4
L_060AFB3A:
    c.r[4] <<= 8;  // 060AFB3A shll8 r4
    c.r[2] |= c.r[4];  // 060AFB3C or r4,r2
    st16(c.r[3], c.r[2]);  // 060AFB3E mov.w r2,@r3
    c.r[1] -= 1; c.t = c.r[1] == 0;  // 060AFB40 dt r1
    { const bool k = !c.t; c.r[3] += 2; if (k) { SH2_POLL(c); goto L_060AFB22; } }  // 060AFB42 bf/s 0x060AFB22 ; add #2,r3
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060AFB46 rts ; nop
}

void f_060AFB00(SH2Context& c) {
    ran[3013] = 1;
    c.r[6] = c.r[4];  // 060AFB00 mov r4,r6
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[4]);  // 060AFB02 mov.b @r4,r4
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060AFB04 sts.l pr,@-r15
    c.r[1] = ld32(0x060AFB4Cu);  // 060AFB06 mov.l 0x060AFB4C,r1
    c.r[4] = c.r[4] & 0xFFu;  // 060AFB08 extu.b r4,r4
    c.r[4] <<= 8;  // 060AFB0A shll8 r4
    c.r[4] <<= 2;  // 060AFB0C shll2 r4
    { const uint32_t x = c.r[1]; c.pr = 0x060AFB12u; c.t = c.r[4] >> 31; c.r[4] <<= 1; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AFB12u) return; }  // 060AFB0E jsr @r1 ; shll r4
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060AFB12 lds.l @r15+,pr
    c.r[3] = ld32(0x060AFB54u);  // 060AFB14 mov.l 0x060AFB54,r3
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 248);  // 060AFB16 mov.w @(248,gbr),r0
    c.r[1] = c.r[0] << 16 | c.r[0] >> 16;  // 060AFB18 swap.w r0,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 234);  // 060AFB1A mov.b @(234,gbr),r0
    c.t = c.r[1] >> 31; c.r[1] <<= 1;  // 060AFB1C shll r1
    { uint32_t t = c.r[0] >> 31; c.r[0] = c.r[0] << 1 | c.t; c.t = t; }  // 060AFB1E rotcl r0
    c.r[1] = 0x8u;  // 060AFB20 mov #8,r1
L_060AFB22:
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[6]); c.r[6] += 1;  // 060AFB22 mov.b @r6+,r2
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[6]); c.r[6] += 1;  // 060AFB24 mov.b @r6+,r4
    c.r[2] = c.r[2] & 0xFFu;  // 060AFB26 extu.b r2,r2
    c.t = (c.r[0] & 0x2u) == 0;  // 060AFB28 tst #2,r0
    { const bool k = !c.t; c.r[4] = c.r[4] & 0xFFu; if (k) { goto L_060AFB32; } }  // 060AFB2A bf/s 0x060AFB32 ; extu.b r4,r4
    c.r[2] >>= 2;  // 060AFB2E shlr2 r2
    c.r[4] >>= 2;  // 060AFB30 shlr2 r4
L_060AFB32:
    c.t = (c.r[0] & 0x1u) == 0;  // 060AFB32 tst #1,r0
    if (!c.t) { goto L_060AFB3A; }  // 060AFB34 bf 0x060AFB3A
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 060AFB36 shlr r2
    c.t = c.r[4] & 1; c.r[4] >>= 1;  // 060AFB38 shlr r4
L_060AFB3A:
    c.r[4] <<= 8;  // 060AFB3A shll8 r4
    c.r[2] |= c.r[4];  // 060AFB3C or r4,r2
    st16(c.r[3], c.r[2]);  // 060AFB3E mov.w r2,@r3
    c.r[1] -= 1; c.t = c.r[1] == 0;  // 060AFB40 dt r1
    { const bool k = !c.t; c.r[3] += 2; if (k) { SH2_POLL(c); goto L_060AFB22; } }  // 060AFB42 bf/s 0x060AFB22 ; add #2,r3
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060AFB46 rts ; nop
}

void f_060AFB58(SH2Context& c) {
    ran[3014] = 1;
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 250);  // 060AFB58 mov.b @(250,gbr),r0
    c.r[4] <<= 2;  // 060AFB5A shll2 r4
    c.r[0] &= 0xF3u;  // 060AFB5C and #243,r0
    c.r[0] |= c.r[4];  // 060AFB5E or r4,r0
    { const uint32_t x = c.pr; st8(c.gbr + 250, c.r[0]); c.pc = x; return; }  // 060AFB60 rts ; mov.b r0,@(250,gbr)
}

void f_060AFB64(SH2Context& c) {
    ran[3015] = 1;
    c.r[0] = ld32(c.gbr + 480);  // 060AFB64 mov.l @(480,gbr),r0
    c.r[15] -= 4; st32(c.r[15], c.gbr);  // 060AFB66 stc.l gbr,@-r15
    c.gbr = c.r[0];  // 060AFB68 ldc r0,gbr
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 60);  // 060AFB6A mov.w @(60,gbr),r0
    c.r[1] = c.r[0];  // 060AFB6C mov r0,r1
    c.r[0] = c.r[4] << 16 | c.r[4] >> 16;  // 060AFB6E swap.w r4,r0
    st16(c.gbr + 60, c.r[0]);  // 060AFB70 mov.w r0,@(60,gbr)
    st16(c.gbr + 52, c.r[0]);  // 060AFB72 mov.w r0,@(52,gbr)
    c.r[1] -= c.r[0];  // 060AFB74 sub r0,r1
    c.r[0] = ld32(c.gbr + 68);  // 060AFB76 mov.l @(68,gbr),r0
    c.r[1] <<= 16;  // 060AFB78 shll16 r1
    c.r[0] += c.r[1];  // 060AFB7A add r1,r0
    st32(c.gbr + 68, c.r[0]);  // 060AFB7C mov.l r0,@(68,gbr)
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 62);  // 060AFB7E mov.w @(62,gbr),r0
    c.r[1] = c.r[0];  // 060AFB80 mov r0,r1
    c.r[0] = c.r[5] << 16 | c.r[5] >> 16;  // 060AFB82 swap.w r5,r0
    st16(c.gbr + 62, c.r[0]);  // 060AFB84 mov.w r0,@(62,gbr)
    st16(c.gbr + 54, c.r[0]);  // 060AFB86 mov.w r0,@(54,gbr)
    c.r[1] -= c.r[0];  // 060AFB88 sub r0,r1
    c.r[0] = ld32(c.gbr + 72);  // 060AFB8A mov.l @(72,gbr),r0
    c.r[1] <<= 16;  // 060AFB8C shll16 r1
    c.r[0] += c.r[1];  // 060AFB8E add r1,r0
    st32(c.gbr + 72, c.r[0]);  // 060AFB90 mov.l r0,@(72,gbr)
    { const uint32_t x = c.pr; { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.gbr = v; } c.pc = x; return; }  // 060AFB92 rts ; ldc.l @r15+,gbr
}

void f_060AFB98(SH2Context& c) {
    ran[3016] = 1;
    c.r[0] = ld32(0x060AFC0Cu);  // 060AFB98 mov.l 0x060AFC0C,r0
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060AFB9A sts.l pr,@-r15
    { const uint32_t x = c.r[0]; c.pr = 0x060AFBA0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AFBA0u) return; }  // 060AFB9C jsr @r0 ; nop
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060AFBA0 lds.l @r15+,pr
    c.r[15] -= 4; st32(c.r[15], c.r[5]);  // 060AFBA2 mov.l r5,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[4]);  // 060AFBA4 mov.l r4,@-r15
    c.r[0] = ld32(c.gbr + 28);  // 060AFBA6 mov.l @(28,gbr),r0
    c.r[1] = c.r[15];  // 060AFBA8 mov r15,r1
    c.r[7] = ld32(c.r[0] + 8);  // 060AFBAA mov.l @(8,r0),r7
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[7] * (int32_t)c.r[5]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060AFBAC dmuls.l r5,r7
    c.r[4] = 0u - c.r[4];  // 060AFBAE neg r4,r4
    c.r[6] = c.r[0];  // 060AFBB0 mov r0,r6
    sh2_mac_l(c, 0, 1);  // 060AFBB2 mac.l @r1+,@r0+
    c.r[0] -= 4;  // 060AFBB4 add #-4,r0
    c.r[2] = c.mach;  // 060AFBB6 sts mach,r2
    c.r[3] = c.macl;  // 060AFBB8 sts macl,r3
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[7] * (int32_t)c.r[4]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060AFBBA dmuls.l r4,r7
    c.r[3] = c.r[2] << 16 | c.r[3] >> 16;  // 060AFBBC xtrct r2,r3
    c.r[7] = ld32(c.r[6] + 24);  // 060AFBBE mov.l @(24,r6),r7
    sh2_mac_l(c, 0, 1);  // 060AFBC0 mac.l @r1+,@r0+
    st32(c.r[6] + 8, c.r[3]);  // 060AFBC2 mov.l r3,@(8,r6)
    c.r[0] += 12;  // 060AFBC4 add #12,r0
    c.r[1] = c.r[15];  // 060AFBC6 mov r15,r1
    c.r[2] = c.mach;  // 060AFBC8 sts mach,r2
    c.r[3] = c.macl;  // 060AFBCA sts macl,r3
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[7] * (int32_t)c.r[5]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060AFBCC dmuls.l r5,r7
    c.r[3] = c.r[2] << 16 | c.r[3] >> 16;  // 060AFBCE xtrct r2,r3
    st32(c.r[6], c.r[3]);  // 060AFBD0 mov.l r3,@(0,r6)
    sh2_mac_l(c, 0, 1);  // 060AFBD2 mac.l @r1+,@r0+
    c.r[0] -= 4;  // 060AFBD4 add #-4,r0
    c.r[2] = c.mach;  // 060AFBD6 sts mach,r2
    c.r[3] = c.macl;  // 060AFBD8 sts macl,r3
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[7] * (int32_t)c.r[4]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060AFBDA dmuls.l r4,r7
    c.r[3] = c.r[2] << 16 | c.r[3] >> 16;  // 060AFBDC xtrct r2,r3
    st32(c.r[6] + 24, c.r[3]);  // 060AFBDE mov.l r3,@(24,r6)
    sh2_mac_l(c, 0, 1);  // 060AFBE0 mac.l @r1+,@r0+
    c.r[0] += 12;  // 060AFBE2 add #12,r0
    c.r[7] = ld32(c.r[6] + 40);  // 060AFBE4 mov.l @(40,r6),r7
    c.r[2] = c.mach;  // 060AFBE6 sts mach,r2
    c.r[3] = c.macl;  // 060AFBE8 sts macl,r3
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[7] * (int32_t)c.r[5]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060AFBEA dmuls.l r5,r7
    c.r[3] = c.r[2] << 16 | c.r[3] >> 16;  // 060AFBEC xtrct r2,r3
    st32(c.r[6] + 16, c.r[3]);  // 060AFBEE mov.l r3,@(16,r6)
    sh2_mac_l(c, 0, 15);  // 060AFBF0 mac.l @r15+,@r0+
    c.r[0] -= 4;  // 060AFBF2 add #-4,r0
    c.r[2] = c.mach;  // 060AFBF4 sts mach,r2
    c.r[3] = c.macl;  // 060AFBF6 sts macl,r3
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[7] * (int32_t)c.r[4]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060AFBF8 dmuls.l r4,r7
    c.r[3] = c.r[2] << 16 | c.r[3] >> 16;  // 060AFBFA xtrct r2,r3
    st32(c.r[6] + 40, c.r[3]);  // 060AFBFC mov.l r3,@(40,r6)
    sh2_mac_l(c, 0, 15);  // 060AFBFE mac.l @r15+,@r0+
    c.r[2] = c.mach;  // 060AFC00 sts mach,r2
    c.r[3] = c.macl;  // 060AFC02 sts macl,r3
    c.r[3] = c.r[2] << 16 | c.r[3] >> 16;  // 060AFC04 xtrct r2,r3
    { const uint32_t x = c.pr; st32(c.r[6] + 32, c.r[3]); c.pc = x; return; }  // 060AFC06 rts ; mov.l r3,@(32,r6)
}

void f_060AFBA2(SH2Context& c) {
    ran[3017] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[5]);  // 060AFBA2 mov.l r5,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[4]);  // 060AFBA4 mov.l r4,@-r15
    c.r[0] = ld32(c.gbr + 28);  // 060AFBA6 mov.l @(28,gbr),r0
    c.r[1] = c.r[15];  // 060AFBA8 mov r15,r1
    c.r[7] = ld32(c.r[0] + 8);  // 060AFBAA mov.l @(8,r0),r7
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[7] * (int32_t)c.r[5]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060AFBAC dmuls.l r5,r7
    c.r[4] = 0u - c.r[4];  // 060AFBAE neg r4,r4
    c.r[6] = c.r[0];  // 060AFBB0 mov r0,r6
    sh2_mac_l(c, 0, 1);  // 060AFBB2 mac.l @r1+,@r0+
    c.r[0] -= 4;  // 060AFBB4 add #-4,r0
    c.r[2] = c.mach;  // 060AFBB6 sts mach,r2
    c.r[3] = c.macl;  // 060AFBB8 sts macl,r3
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[7] * (int32_t)c.r[4]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060AFBBA dmuls.l r4,r7
    c.r[3] = c.r[2] << 16 | c.r[3] >> 16;  // 060AFBBC xtrct r2,r3
    c.r[7] = ld32(c.r[6] + 24);  // 060AFBBE mov.l @(24,r6),r7
    sh2_mac_l(c, 0, 1);  // 060AFBC0 mac.l @r1+,@r0+
    st32(c.r[6] + 8, c.r[3]);  // 060AFBC2 mov.l r3,@(8,r6)
    c.r[0] += 12;  // 060AFBC4 add #12,r0
    c.r[1] = c.r[15];  // 060AFBC6 mov r15,r1
    c.r[2] = c.mach;  // 060AFBC8 sts mach,r2
    c.r[3] = c.macl;  // 060AFBCA sts macl,r3
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[7] * (int32_t)c.r[5]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060AFBCC dmuls.l r5,r7
    c.r[3] = c.r[2] << 16 | c.r[3] >> 16;  // 060AFBCE xtrct r2,r3
    st32(c.r[6], c.r[3]);  // 060AFBD0 mov.l r3,@(0,r6)
    sh2_mac_l(c, 0, 1);  // 060AFBD2 mac.l @r1+,@r0+
    c.r[0] -= 4;  // 060AFBD4 add #-4,r0
    c.r[2] = c.mach;  // 060AFBD6 sts mach,r2
    c.r[3] = c.macl;  // 060AFBD8 sts macl,r3
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[7] * (int32_t)c.r[4]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060AFBDA dmuls.l r4,r7
    c.r[3] = c.r[2] << 16 | c.r[3] >> 16;  // 060AFBDC xtrct r2,r3
    st32(c.r[6] + 24, c.r[3]);  // 060AFBDE mov.l r3,@(24,r6)
    sh2_mac_l(c, 0, 1);  // 060AFBE0 mac.l @r1+,@r0+
    c.r[0] += 12;  // 060AFBE2 add #12,r0
    c.r[7] = ld32(c.r[6] + 40);  // 060AFBE4 mov.l @(40,r6),r7
    c.r[2] = c.mach;  // 060AFBE6 sts mach,r2
    c.r[3] = c.macl;  // 060AFBE8 sts macl,r3
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[7] * (int32_t)c.r[5]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060AFBEA dmuls.l r5,r7
    c.r[3] = c.r[2] << 16 | c.r[3] >> 16;  // 060AFBEC xtrct r2,r3
    st32(c.r[6] + 16, c.r[3]);  // 060AFBEE mov.l r3,@(16,r6)
    sh2_mac_l(c, 0, 15);  // 060AFBF0 mac.l @r15+,@r0+
    c.r[0] -= 4;  // 060AFBF2 add #-4,r0
    c.r[2] = c.mach;  // 060AFBF4 sts mach,r2
    c.r[3] = c.macl;  // 060AFBF6 sts macl,r3
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[7] * (int32_t)c.r[4]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060AFBF8 dmuls.l r4,r7
    c.r[3] = c.r[2] << 16 | c.r[3] >> 16;  // 060AFBFA xtrct r2,r3
    st32(c.r[6] + 40, c.r[3]);  // 060AFBFC mov.l r3,@(40,r6)
    sh2_mac_l(c, 0, 15);  // 060AFBFE mac.l @r15+,@r0+
    c.r[2] = c.mach;  // 060AFC00 sts mach,r2
    c.r[3] = c.macl;  // 060AFC02 sts macl,r3
    c.r[3] = c.r[2] << 16 | c.r[3] >> 16;  // 060AFC04 xtrct r2,r3
    { const uint32_t x = c.pr; st32(c.r[6] + 32, c.r[3]); c.pc = x; return; }  // 060AFC06 rts ; mov.l r3,@(32,r6)
}

void f_060AFC10(SH2Context& c) {
    ran[3018] = 1;
    c.r[0] = ld32(0x060AFC84u);  // 060AFC10 mov.l 0x060AFC84,r0
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060AFC12 sts.l pr,@-r15
    { const uint32_t x = c.r[0]; c.pr = 0x060AFC18u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AFC18u) return; }  // 060AFC14 jsr @r0 ; nop
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060AFC18 lds.l @r15+,pr
    c.r[15] -= 4; st32(c.r[15], c.r[5]);  // 060AFC1A mov.l r5,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[4]);  // 060AFC1C mov.l r4,@-r15
    c.r[0] = ld32(c.gbr + 28);  // 060AFC1E mov.l @(28,gbr),r0
    c.r[1] = c.r[15];  // 060AFC20 mov r15,r1
    c.r[7] = ld32(c.r[0] + 4);  // 060AFC22 mov.l @(4,r0),r7
    c.r[6] = c.r[0];  // 060AFC24 mov r0,r6
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[7] * (int32_t)c.r[5]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060AFC26 dmuls.l r5,r7
    c.r[4] = 0u - c.r[4];  // 060AFC28 neg r4,r4
    c.r[0] += 8;  // 060AFC2A add #8,r0
    sh2_mac_l(c, 0, 1);  // 060AFC2C mac.l @r1+,@r0+
    c.r[0] -= 4;  // 060AFC2E add #-4,r0
    c.r[2] = c.mach;  // 060AFC30 sts mach,r2
    c.r[3] = c.macl;  // 060AFC32 sts macl,r3
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[7] * (int32_t)c.r[4]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060AFC34 dmuls.l r4,r7
    c.r[3] = c.r[2] << 16 | c.r[3] >> 16;  // 060AFC36 xtrct r2,r3
    st32(c.r[6] + 4, c.r[3]);  // 060AFC38 mov.l r3,@(4,r6)
    sh2_mac_l(c, 0, 1);  // 060AFC3A mac.l @r1+,@r0+
    c.r[7] = ld32(c.r[6] + 20);  // 060AFC3C mov.l @(20,r6),r7
    c.r[0] += 12;  // 060AFC3E add #12,r0
    c.r[1] = c.r[15];  // 060AFC40 mov r15,r1
    c.r[2] = c.mach;  // 060AFC42 sts mach,r2
    c.r[3] = c.macl;  // 060AFC44 sts macl,r3
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[7] * (int32_t)c.r[5]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060AFC46 dmuls.l r5,r7
    c.r[3] = c.r[2] << 16 | c.r[3] >> 16;  // 060AFC48 xtrct r2,r3
    st32(c.r[6] + 8, c.r[3]);  // 060AFC4A mov.l r3,@(8,r6)
    sh2_mac_l(c, 0, 1);  // 060AFC4C mac.l @r1+,@r0+
    c.r[0] -= 4;  // 060AFC4E add #-4,r0
    c.r[2] = c.mach;  // 060AFC50 sts mach,r2
    c.r[3] = c.macl;  // 060AFC52 sts macl,r3
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[7] * (int32_t)c.r[4]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060AFC54 dmuls.l r4,r7
    c.r[3] = c.r[2] << 16 | c.r[3] >> 16;  // 060AFC56 xtrct r2,r3
    st32(c.r[6] + 20, c.r[3]);  // 060AFC58 mov.l r3,@(20,r6)
    sh2_mac_l(c, 0, 1);  // 060AFC5A mac.l @r1+,@r0+
    c.r[7] = ld32(c.r[6] + 36);  // 060AFC5C mov.l @(36,r6),r7
    c.r[0] += 12;  // 060AFC5E add #12,r0
    c.r[2] = c.mach;  // 060AFC60 sts mach,r2
    c.r[3] = c.macl;  // 060AFC62 sts macl,r3
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[7] * (int32_t)c.r[5]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060AFC64 dmuls.l r5,r7
    c.r[3] = c.r[2] << 16 | c.r[3] >> 16;  // 060AFC66 xtrct r2,r3
    st32(c.r[6] + 24, c.r[3]);  // 060AFC68 mov.l r3,@(24,r6)
    sh2_mac_l(c, 0, 15);  // 060AFC6A mac.l @r15+,@r0+
    c.r[0] -= 4;  // 060AFC6C add #-4,r0
    c.r[2] = c.mach;  // 060AFC6E sts mach,r2
    c.r[3] = c.macl;  // 060AFC70 sts macl,r3
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[7] * (int32_t)c.r[4]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060AFC72 dmuls.l r4,r7
    c.r[3] = c.r[2] << 16 | c.r[3] >> 16;  // 060AFC74 xtrct r2,r3
    st32(c.r[6] + 36, c.r[3]);  // 060AFC76 mov.l r3,@(36,r6)
    sh2_mac_l(c, 0, 15);  // 060AFC78 mac.l @r15+,@r0+
    c.r[2] = c.mach;  // 060AFC7A sts mach,r2
    c.r[3] = c.macl;  // 060AFC7C sts macl,r3
    c.r[3] = c.r[2] << 16 | c.r[3] >> 16;  // 060AFC7E xtrct r2,r3
    { const uint32_t x = c.pr; st32(c.r[6] + 40, c.r[3]); c.pc = x; return; }  // 060AFC80 rts ; mov.l r3,@(40,r6)
}

void f_060AFC1A(SH2Context& c) {
    ran[3019] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[5]);  // 060AFC1A mov.l r5,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[4]);  // 060AFC1C mov.l r4,@-r15
    c.r[0] = ld32(c.gbr + 28);  // 060AFC1E mov.l @(28,gbr),r0
    c.r[1] = c.r[15];  // 060AFC20 mov r15,r1
    c.r[7] = ld32(c.r[0] + 4);  // 060AFC22 mov.l @(4,r0),r7
    c.r[6] = c.r[0];  // 060AFC24 mov r0,r6
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[7] * (int32_t)c.r[5]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060AFC26 dmuls.l r5,r7
    c.r[4] = 0u - c.r[4];  // 060AFC28 neg r4,r4
    c.r[0] += 8;  // 060AFC2A add #8,r0
    sh2_mac_l(c, 0, 1);  // 060AFC2C mac.l @r1+,@r0+
    c.r[0] -= 4;  // 060AFC2E add #-4,r0
    c.r[2] = c.mach;  // 060AFC30 sts mach,r2
    c.r[3] = c.macl;  // 060AFC32 sts macl,r3
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[7] * (int32_t)c.r[4]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060AFC34 dmuls.l r4,r7
    c.r[3] = c.r[2] << 16 | c.r[3] >> 16;  // 060AFC36 xtrct r2,r3
    st32(c.r[6] + 4, c.r[3]);  // 060AFC38 mov.l r3,@(4,r6)
    sh2_mac_l(c, 0, 1);  // 060AFC3A mac.l @r1+,@r0+
    c.r[7] = ld32(c.r[6] + 20);  // 060AFC3C mov.l @(20,r6),r7
    c.r[0] += 12;  // 060AFC3E add #12,r0
    c.r[1] = c.r[15];  // 060AFC40 mov r15,r1
    c.r[2] = c.mach;  // 060AFC42 sts mach,r2
    c.r[3] = c.macl;  // 060AFC44 sts macl,r3
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[7] * (int32_t)c.r[5]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060AFC46 dmuls.l r5,r7
    c.r[3] = c.r[2] << 16 | c.r[3] >> 16;  // 060AFC48 xtrct r2,r3
    st32(c.r[6] + 8, c.r[3]);  // 060AFC4A mov.l r3,@(8,r6)
    sh2_mac_l(c, 0, 1);  // 060AFC4C mac.l @r1+,@r0+
    c.r[0] -= 4;  // 060AFC4E add #-4,r0
    c.r[2] = c.mach;  // 060AFC50 sts mach,r2
    c.r[3] = c.macl;  // 060AFC52 sts macl,r3
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[7] * (int32_t)c.r[4]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060AFC54 dmuls.l r4,r7
    c.r[3] = c.r[2] << 16 | c.r[3] >> 16;  // 060AFC56 xtrct r2,r3
    st32(c.r[6] + 20, c.r[3]);  // 060AFC58 mov.l r3,@(20,r6)
    sh2_mac_l(c, 0, 1);  // 060AFC5A mac.l @r1+,@r0+
    c.r[7] = ld32(c.r[6] + 36);  // 060AFC5C mov.l @(36,r6),r7
    c.r[0] += 12;  // 060AFC5E add #12,r0
    c.r[2] = c.mach;  // 060AFC60 sts mach,r2
    c.r[3] = c.macl;  // 060AFC62 sts macl,r3
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[7] * (int32_t)c.r[5]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060AFC64 dmuls.l r5,r7
    c.r[3] = c.r[2] << 16 | c.r[3] >> 16;  // 060AFC66 xtrct r2,r3
    st32(c.r[6] + 24, c.r[3]);  // 060AFC68 mov.l r3,@(24,r6)
    sh2_mac_l(c, 0, 15);  // 060AFC6A mac.l @r15+,@r0+
    c.r[0] -= 4;  // 060AFC6C add #-4,r0
    c.r[2] = c.mach;  // 060AFC6E sts mach,r2
    c.r[3] = c.macl;  // 060AFC70 sts macl,r3
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[7] * (int32_t)c.r[4]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060AFC72 dmuls.l r4,r7
    c.r[3] = c.r[2] << 16 | c.r[3] >> 16;  // 060AFC74 xtrct r2,r3
    st32(c.r[6] + 36, c.r[3]);  // 060AFC76 mov.l r3,@(36,r6)
    sh2_mac_l(c, 0, 15);  // 060AFC78 mac.l @r15+,@r0+
    c.r[2] = c.mach;  // 060AFC7A sts mach,r2
    c.r[3] = c.macl;  // 060AFC7C sts macl,r3
    c.r[3] = c.r[2] << 16 | c.r[3] >> 16;  // 060AFC7E xtrct r2,r3
    { const uint32_t x = c.pr; st32(c.r[6] + 40, c.r[3]); c.pc = x; return; }  // 060AFC80 rts ; mov.l r3,@(40,r6)
}

void f_060AFC88(SH2Context& c) {
    ran[3020] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[6]);  // 060AFC88 mov.l r6,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[5]);  // 060AFC8A mov.l r5,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[4]);  // 060AFC8C mov.l r4,@-r15
    c.r[0] = ld32(c.gbr + 28);  // 060AFC8E mov.l @(28,gbr),r0
    c.r[4] = c.r[15];  // 060AFC90 mov r15,r4
    c.r[1] = 0x3u;  // 060AFC92 mov #3,r1
L_060AFC94:
    c.mach = c.macl = 0;  // 060AFC94 clrmac
    sh2_mac_l(c, 0, 4);  // 060AFC96 mac.l @r4+,@r0+
    sh2_mac_l(c, 0, 4);  // 060AFC98 mac.l @r4+,@r0+
    sh2_mac_l(c, 0, 4);  // 060AFC9A mac.l @r4+,@r0+
    c.r[5] = ld32(c.r[0]); c.r[0] += 4;  // 060AFC9C mov.l @r0+,r5
    c.r[2] = c.mach;  // 060AFC9E sts mach,r2
    c.r[3] = c.macl;  // 060AFCA0 sts macl,r3
    c.r[3] = c.r[2] << 16 | c.r[3] >> 16;  // 060AFCA2 xtrct r2,r3
    c.r[3] += c.r[5];  // 060AFCA4 add r5,r3
    st32(c.r[7], c.r[3]);  // 060AFCA6 mov.l r3,@r7
    c.r[7] += 4;  // 060AFCA8 add #4,r7
    c.r[1] -= 1; c.t = c.r[1] == 0;  // 060AFCAA dt r1
    { const bool k = !c.t; c.r[4] = c.r[15]; if (k) { SH2_POLL(c); goto L_060AFC94; } }  // 060AFCAC bf/s 0x060AFC94 ; mov r15,r4
    { const uint32_t x = c.pr; c.r[15] += 12; c.pc = x; return; }  // 060AFCB0 rts ; add #12,r15
}

void f_060AFCB4(SH2Context& c) {
    ran[3021] = 1;
    c.r[0] = ld32(c.gbr + 28);  // 060AFCB4 mov.l @(28,gbr),r0
    c.r[7] = 0x4u;  // 060AFCB6 mov #4,r7
L_060AFCB8:
    c.r[1] = ld32(c.r[4]); c.r[4] += 4;  // 060AFCB8 mov.l @r4+,r1
    c.r[2] = ld32(c.r[4]); c.r[4] += 4;  // 060AFCBA mov.l @r4+,r2
    c.r[3] = ld32(c.r[4]); c.r[4] += 4;  // 060AFCBC mov.l @r4+,r3
    st32(c.r[0], c.r[1]);  // 060AFCBE mov.l r1,@(0,r0)
    st32(c.r[0] + 16, c.r[2]);  // 060AFCC0 mov.l r2,@(16,r0)
    st32(c.r[0] + 32, c.r[3]);  // 060AFCC2 mov.l r3,@(32,r0)
    c.r[7] -= 1; c.t = c.r[7] == 0;  // 060AFCC4 dt r7
    { const bool k = !c.t; c.r[0] += 4; if (k) { SH2_POLL(c); goto L_060AFCB8; } }  // 060AFCC6 bf/s 0x060AFCB8 ; add #4,r0
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060AFCCA rts ; nop
}

void f_060AFCD0(SH2Context& c) {
    ran[3022] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[6]);  // 060AFCD0 mov.l r6,@-r15
    c.r[0] = ld32(c.gbr + 28);  // 060AFCD2 mov.l @(28,gbr),r0
    c.r[15] -= 4; st32(c.r[15], c.r[5]);  // 060AFCD4 mov.l r5,@-r15
    c.r[7] = ld32(c.r[0]); c.r[0] += 4;  // 060AFCD6 mov.l @r0+,r7
    c.r[5] = c.r[15];  // 060AFCD8 mov r15,r5
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[7] * (int32_t)c.r[4]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060AFCDA dmuls.l r4,r7
    sh2_mac_l(c, 0, 5);  // 060AFCDC mac.l @r5+,@r0+
    c.r[7] = ld32(c.r[0] + 4);  // 060AFCDE mov.l @(4,r0),r7
    sh2_mac_l(c, 0, 5);  // 060AFCE0 mac.l @r5+,@r0+
    c.r[5] = c.r[15];  // 060AFCE2 mov r15,r5
    c.r[0] += 4;  // 060AFCE4 add #4,r0
    c.r[1] = c.r[0];  // 060AFCE6 mov r0,r1
    c.r[2] = c.mach;  // 060AFCE8 sts mach,r2
    c.r[3] = c.macl;  // 060AFCEA sts macl,r3
    c.r[6] = ld32(c.r[0]); c.r[0] += 4;  // 060AFCEC mov.l @r0+,r6
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[6] * (int32_t)c.r[4]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060AFCEE dmuls.l r4,r6
    c.r[3] = c.r[2] << 16 | c.r[3] >> 16;  // 060AFCF0 xtrct r2,r3
    c.r[3] += c.r[7];  // 060AFCF2 add r7,r3
    sh2_mac_l(c, 0, 5);  // 060AFCF4 mac.l @r5+,@r0+
    c.r[1] -= 4;  // 060AFCF6 add #-4,r1
    st32(c.r[1], c.r[3]);  // 060AFCF8 mov.l r3,@r1
    sh2_mac_l(c, 0, 5);  // 060AFCFA mac.l @r5+,@r0+
    c.r[7] = ld32(c.r[0]); c.r[0] += 4;  // 060AFCFC mov.l @r0+,r7
    c.r[6] = ld32(c.r[0]); c.r[0] += 4;  // 060AFCFE mov.l @r0+,r6
    c.r[2] = c.mach;  // 060AFD00 sts mach,r2
    c.r[3] = c.macl;  // 060AFD02 sts macl,r3
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[6] * (int32_t)c.r[4]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060AFD04 dmuls.l r4,r6
    c.r[3] = c.r[2] << 16 | c.r[3] >> 16;  // 060AFD06 xtrct r2,r3
    c.r[3] += c.r[7];  // 060AFD08 add r7,r3
    sh2_mac_l(c, 0, 15);  // 060AFD0A mac.l @r15+,@r0+
    c.r[1] += 16;  // 060AFD0C add #16,r1
    st32(c.r[1], c.r[3]);  // 060AFD0E mov.l r3,@r1
    sh2_mac_l(c, 0, 15);  // 060AFD10 mac.l @r15+,@r0+
    c.r[1] = ld32(c.r[0]);  // 060AFD12 mov.l @r0,r1
    c.r[2] = c.mach;  // 060AFD14 sts mach,r2
    c.r[3] = c.macl;  // 060AFD16 sts macl,r3
    c.r[3] = c.r[2] << 16 | c.r[3] >> 16;  // 060AFD18 xtrct r2,r3
    c.r[3] += c.r[1];  // 060AFD1A add r1,r3
    { const uint32_t x = c.pr; st32(c.r[0], c.r[3]); c.pc = x; return; }  // 060AFD1C rts ; mov.l r3,@r0
}

void f_060AFD20(SH2Context& c) {
    ran[3023] = 1;
    c.r[0] = ld32(c.gbr + 28);  // 060AFD20 mov.l @(28,gbr),r0
    c.r[2] = ld32(c.r[0]);  // 060AFD22 mov.l @(0,r0),r2
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[2] * (int32_t)c.r[4]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060AFD24 dmuls.l r4,r2
    c.r[7] = ld32(c.r[0] + 4);  // 060AFD26 mov.l @(4,r0),r7
    c.r[2] = c.mach;  // 060AFD28 sts mach,r2
    c.r[3] = c.macl;  // 060AFD2A sts macl,r3
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[7] * (int32_t)c.r[5]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060AFD2C dmuls.l r5,r7
    c.r[3] = c.r[2] << 16 | c.r[3] >> 16;  // 060AFD2E xtrct r2,r3
    st32(c.r[0], c.r[3]);  // 060AFD30 mov.l r3,@(0,r0)
    c.r[7] = ld32(c.r[0] + 8);  // 060AFD32 mov.l @(8,r0),r7
    c.r[2] = c.mach;  // 060AFD34 sts mach,r2
    c.r[3] = c.macl;  // 060AFD36 sts macl,r3
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[7] * (int32_t)c.r[6]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060AFD38 dmuls.l r6,r7
    c.r[3] = c.r[2] << 16 | c.r[3] >> 16;  // 060AFD3A xtrct r2,r3
    st32(c.r[0] + 4, c.r[3]);  // 060AFD3C mov.l r3,@(4,r0)
    c.r[7] = ld32(c.r[0] + 16);  // 060AFD3E mov.l @(16,r0),r7
    c.r[2] = c.mach;  // 060AFD40 sts mach,r2
    c.r[3] = c.macl;  // 060AFD42 sts macl,r3
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[7] * (int32_t)c.r[4]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060AFD44 dmuls.l r4,r7
    c.r[3] = c.r[2] << 16 | c.r[3] >> 16;  // 060AFD46 xtrct r2,r3
    st32(c.r[0] + 8, c.r[3]);  // 060AFD48 mov.l r3,@(8,r0)
    c.r[7] = ld32(c.r[0] + 20);  // 060AFD4A mov.l @(20,r0),r7
    c.r[2] = c.mach;  // 060AFD4C sts mach,r2
    c.r[3] = c.macl;  // 060AFD4E sts macl,r3
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[7] * (int32_t)c.r[5]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060AFD50 dmuls.l r5,r7
    c.r[3] = c.r[2] << 16 | c.r[3] >> 16;  // 060AFD52 xtrct r2,r3
    st32(c.r[0] + 16, c.r[3]);  // 060AFD54 mov.l r3,@(16,r0)
    c.r[7] = ld32(c.r[0] + 24);  // 060AFD56 mov.l @(24,r0),r7
    c.r[2] = c.mach;  // 060AFD58 sts mach,r2
    c.r[3] = c.macl;  // 060AFD5A sts macl,r3
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[7] * (int32_t)c.r[6]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060AFD5C dmuls.l r6,r7
    c.r[3] = c.r[2] << 16 | c.r[3] >> 16;  // 060AFD5E xtrct r2,r3
    st32(c.r[0] + 20, c.r[3]);  // 060AFD60 mov.l r3,@(20,r0)
    c.r[7] = ld32(c.r[0] + 32);  // 060AFD62 mov.l @(32,r0),r7
    c.r[2] = c.mach;  // 060AFD64 sts mach,r2
    c.r[3] = c.macl;  // 060AFD66 sts macl,r3
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[7] * (int32_t)c.r[4]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060AFD68 dmuls.l r4,r7
    c.r[3] = c.r[2] << 16 | c.r[3] >> 16;  // 060AFD6A xtrct r2,r3
    st32(c.r[0] + 24, c.r[3]);  // 060AFD6C mov.l r3,@(24,r0)
    c.r[7] = ld32(c.r[0] + 36);  // 060AFD6E mov.l @(36,r0),r7
    c.r[2] = c.mach;  // 060AFD70 sts mach,r2
    c.r[3] = c.macl;  // 060AFD72 sts macl,r3
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[7] * (int32_t)c.r[5]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060AFD74 dmuls.l r5,r7
    c.r[3] = c.r[2] << 16 | c.r[3] >> 16;  // 060AFD76 xtrct r2,r3
    st32(c.r[0] + 32, c.r[3]);  // 060AFD78 mov.l r3,@(32,r0)
    c.r[7] = ld32(c.r[0] + 40);  // 060AFD7A mov.l @(40,r0),r7
    c.r[2] = c.mach;  // 060AFD7C sts mach,r2
    c.r[3] = c.macl;  // 060AFD7E sts macl,r3
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[7] * (int32_t)c.r[6]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060AFD80 dmuls.l r6,r7
    c.r[3] = c.r[2] << 16 | c.r[3] >> 16;  // 060AFD82 xtrct r2,r3
    st32(c.r[0] + 36, c.r[3]);  // 060AFD84 mov.l r3,@(36,r0)
    c.r[2] = c.mach;  // 060AFD86 sts mach,r2
    c.r[3] = c.macl;  // 060AFD88 sts macl,r3
    c.r[3] = c.r[2] << 16 | c.r[3] >> 16;  // 060AFD8A xtrct r2,r3
    { const uint32_t x = c.pr; st32(c.r[0] + 40, c.r[3]); c.pc = x; return; }  // 060AFD8C rts ; mov.l r3,@(40,r0)
}

void f_060AFD90(SH2Context& c) {
    ran[3024] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060AFD90 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060AFD92 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060AFD94 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060AFD96 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060AFD98 sts.l pr,@-r15
    c.r[8] = c.r[4];  // 060AFD9A mov r4,r8
    c.r[0] = ld32(0x060AFE4Cu);  // 060AFD9C mov.l 0x060AFE4C,r0
    c.r[9] = c.r[5];  // 060AFD9E mov r5,r9
    { const uint32_t x = c.r[0]; c.pr = 0x060AFDA4u; c.r[4] = c.r[6]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AFDA4u) return; }  // 060AFDA0 jsr @r0 ; mov r6,r4
    c.r[10] = ld32(c.r[8]);  // 060AFDA4 mov.l @(0,r8),r10
    c.r[0] = ld32(c.r[9]);  // 060AFDA6 mov.l @(0,r9),r0
    c.r[10] -= c.r[0];  // 060AFDA8 sub r0,r10
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[10] * (int32_t)c.r[10]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060AFDAA dmuls.l r10,r10
    c.r[2] = ld32(c.r[8] + 8);  // 060AFDAC mov.l @(8,r8),r2
    c.r[11] = ld32(c.r[9] + 8);  // 060AFDAE mov.l @(8,r9),r11
    c.r[0] = c.mach;  // 060AFDB0 sts mach,r0
    c.r[11] -= c.r[2];  // 060AFDB2 sub r2,r11
    c.r[1] = c.macl;  // 060AFDB4 sts macl,r1
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[11] * (int32_t)c.r[11]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060AFDB6 dmuls.l r11,r11
    c.t = 0;  // 060AFDB8 clrt
    c.r[7] = c.macl;  // 060AFDBA sts macl,r7
    c.r[6] = c.mach;  // 060AFDBC sts mach,r6
    { uint64_t s = (uint64_t)c.r[7] + c.r[1] + c.t; c.t = (uint32_t)(s >> 32); c.r[7] = (uint32_t)s; }  // 060AFDBE addc r1,r7
    c.r[9] = ld32(c.r[9] + 4);  // 060AFDC0 mov.l @(4,r9),r9
    { uint64_t s = (uint64_t)c.r[6] + c.r[0] + c.t; c.t = (uint32_t)(s >> 32); c.r[6] = (uint32_t)s; }  // 060AFDC2 addc r0,r6
    c.r[0] = ld32(c.r[8] + 4);  // 060AFDC4 mov.l @(4,r8),r0
    c.r[9] -= c.r[0];  // 060AFDC6 sub r0,r9
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[9] * (int32_t)c.r[9]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060AFDC8 dmuls.l r9,r9
    c.t = 0;  // 060AFDCA clrt
    c.r[5] = c.macl;  // 060AFDCC sts macl,r5
    c.r[4] = c.mach;  // 060AFDCE sts mach,r4
    c.r[2] = ld32(0x060AFE50u);  // 060AFDD0 mov.l 0x060AFE50,r2
    { uint64_t s = (uint64_t)c.r[5] + c.r[7] + c.t; c.t = (uint32_t)(s >> 32); c.r[5] = (uint32_t)s; }  // 060AFDD2 addc r7,r5
    { const uint32_t x = c.r[2]; c.pr = 0x060AFDD8u; { uint64_t s = (uint64_t)c.r[4] + c.r[6] + c.t; c.t = (uint32_t)(s >> 32); c.r[4] = (uint32_t)s; } SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AFDD8u) return; }  // 060AFDD4 jsr @r2 ; addc r6,r4
    c.r[1] = c.r[9];  // 060AFDD8 mov r9,r1
    c.r[9] = 0xFFFFFFFFu;  // 060AFDDA mov #-1,r9
    c.r[9] <<= 8;  // 060AFDDC shll8 r9
    st32(c.r[9], c.r[0]);  // 060AFDDE mov.l r0,@(0,r9)
    c.r[2] = c.r[1] << 16 | c.r[1] >> 16;  // 060AFDE0 swap.w r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 060AFDE2 exts.w r2,r2
    st32(c.r[9] + 16, c.r[2]);  // 060AFDE4 mov.l r2,@(16,r9)
    c.r[1] <<= 16;  // 060AFDE6 shll16 r1
    st32(c.r[9] + 20, c.r[1]);  // 060AFDE8 mov.l r1,@(20,r9)
    c.r[4] = c.r[6];  // 060AFDEA mov r6,r4
    c.r[2] = ld32(0x060AFE50u);  // 060AFDEC mov.l 0x060AFE50,r2
    c.r[6] = c.r[0];  // 060AFDEE mov r0,r6
    { const uint32_t x = c.r[2]; c.pr = 0x060AFDF4u; c.r[5] = c.r[7]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AFDF4u) return; }  // 060AFDF0 jsr @r2 ; mov r7,r5
    c.r[7] = c.r[0];  // 060AFDF4 mov r0,r7
    c.r[4] = ld32(c.r[9] + 28);  // 060AFDF6 mov.l @(28,r9),r4
    st32(c.r[9], c.r[6]);  // 060AFDF8 mov.l r6,@(0,r9)
    c.r[2] = c.r[0] << 16 | c.r[0] >> 16;  // 060AFDFA swap.w r0,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 060AFDFC exts.w r2,r2
    st32(c.r[9] + 16, c.r[2]);  // 060AFDFE mov.l r2,@(16,r9)
    c.r[0] <<= 16;  // 060AFE00 shll16 r0
    st32(c.r[9] + 20, c.r[0]);  // 060AFE02 mov.l r0,@(20,r9)
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 060AFE04 mov.l r7,@-r15
    c.r[5] = ld32(c.r[9] + 28);  // 060AFE06 mov.l @(28,r9),r5
    c.r[0] = ld32(0x060AFE54u);  // 060AFE08 mov.l 0x060AFE54,r0
    st32(c.r[9], c.r[7]);  // 060AFE0A mov.l r7,@(0,r9)
    c.r[2] = c.r[10] << 16 | c.r[10] >> 16;  // 060AFE0C swap.w r10,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 060AFE0E exts.w r2,r2
    st32(c.r[9] + 16, c.r[2]);  // 060AFE10 mov.l r2,@(16,r9)
    c.r[10] <<= 16;  // 060AFE12 shll16 r10
    st32(c.r[9] + 20, c.r[10]);  // 060AFE14 mov.l r10,@(20,r9)
    { const uint32_t x = c.r[0]; c.pr = 0x060AFE1Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AFE1Au) return; }  // 060AFE16 jsr @r0 ; nop
    c.r[0] = ld32(c.r[15]); c.r[15] += 4;  // 060AFE1A mov.l @r15+,r0
    c.r[4] = ld32(c.r[9] + 28);  // 060AFE1C mov.l @(28,r9),r4
    c.r[1] = ld32(0x060AFE58u);  // 060AFE1E mov.l 0x060AFE58,r1
    st32(c.r[9], c.r[0]);  // 060AFE20 mov.l r0,@(0,r9)
    c.r[2] = c.r[11] << 16 | c.r[11] >> 16;  // 060AFE22 swap.w r11,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 060AFE24 exts.w r2,r2
    st32(c.r[9] + 16, c.r[2]);  // 060AFE26 mov.l r2,@(16,r9)
    c.r[11] <<= 16;  // 060AFE28 shll16 r11
    st32(c.r[9] + 20, c.r[11]);  // 060AFE2A mov.l r11,@(20,r9)
    { const uint32_t x = c.r[1]; c.pr = 0x060AFE30u; c.r[5] = ld32(c.r[9] + 28); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AFE30u) return; }  // 060AFE2C jsr @r1 ; mov.l @(28,r9),r5
    c.r[6] = ld32(c.r[8] + 8);  // 060AFE30 mov.l @(8,r8),r6
    c.r[5] = ld32(c.r[8] + 4);  // 060AFE32 mov.l @(4,r8),r5
    c.r[6] = 0u - c.r[6];  // 060AFE34 neg r6,r6
    c.r[4] = ld32(c.r[8]);  // 060AFE36 mov.l @(0,r8),r4
    c.r[0] = ld32(0x060AFE5Cu);  // 060AFE38 mov.l 0x060AFE5C,r0
    c.r[5] = 0u - c.r[5];  // 060AFE3A neg r5,r5
    { const uint32_t x = c.r[0]; c.pr = 0x060AFE40u; c.r[4] = 0u - c.r[4]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060AFE40u) return; }  // 060AFE3C jsr @r0 ; neg r4,r4
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060AFE40 lds.l @r15+,pr
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060AFE42 mov.l @r15+,r9
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060AFE44 mov.l @r15+,r10
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060AFE46 mov.l @r15+,r11
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060AFE48 rts ; mov.l @r15+,r8
}

void f_060AFE60(SH2Context& c) {
    ran[3025] = 1;
    c.r[0] = ld32(c.gbr + 28);  // 060AFE60 mov.l @(28,gbr),r0
    c.r[7] = 0x3u;  // 060AFE62 mov #3,r7
L_060AFE64:
    c.r[1] = ld32(c.r[0]); c.r[0] += 4;  // 060AFE64 mov.l @r0+,r1
    c.r[2] = ld32(c.r[0]); c.r[0] += 4;  // 060AFE66 mov.l @r0+,r2
    c.r[3] = ld32(c.r[0]); c.r[0] += 4;  // 060AFE68 mov.l @r0+,r3
    c.r[5] = ld32(c.r[0]); c.r[0] += 4;  // 060AFE6A mov.l @r0+,r5
    st32(c.r[4], c.r[1]);  // 060AFE6C mov.l r1,@(0,r4)
    st32(c.r[4] + 12, c.r[2]);  // 060AFE6E mov.l r2,@(12,r4)
    st32(c.r[4] + 24, c.r[3]);  // 060AFE70 mov.l r3,@(24,r4)
    st32(c.r[4] + 36, c.r[5]);  // 060AFE72 mov.l r5,@(36,r4)
    c.r[7] -= 1; c.t = c.r[7] == 0;  // 060AFE74 dt r7
    { const bool k = !c.t; c.r[4] += 4; if (k) { SH2_POLL(c); goto L_060AFE64; } }  // 060AFE76 bf/s 0x060AFE64 ; add #4,r4
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060AFE7A rts ; nop
}

void f_060AFE80(SH2Context& c) {
    ran[3026] = 1;
L_060AFE80:
    c.r[0] = 0x1u;  // 060AFE80 mov #1,r0
L_060AFE82:
    st8(c.gbr + 115, c.r[0]);  // 060AFE82 mov.b r0,@(115,gbr)
L_060AFE84:
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 170);  // 060AFE84 mov.w @(170,gbr),r0
L_060AFE86:
    c.r[0] += 1;  // 060AFE86 add #1,r0
L_060AFE88:
    st16(c.gbr + 170, c.r[0]);  // 060AFE88 mov.w r0,@(170,gbr)
L_060AFE8A:
    c.r[0] = ld32(c.gbr + 136);  // 060AFE8A mov.l @(136,gbr),r0
L_060AFE8C:
    c.r[1] = ld32(c.r[4] + 4);  // 060AFE8C mov.l @(4,r4),r1
L_060AFE8E:
    c.r[3] = c.r[0];  // 060AFE8E mov r0,r3
L_060AFE90:
    c.r[0] = ld32(c.gbr + 116);  // 060AFE90 mov.l @(116,gbr),r0
L_060AFE92:
    c.r[5] = c.r[3] & 0xFFFFu;  // 060AFE92 extu.w r3,r5
L_060AFE94:
    c.r[2] = c.r[0] & 0xFFFFu;  // 060AFE94 extu.w r0,r2
L_060AFE96:
    c.r[2] += c.r[1];  // 060AFE96 add r1,r2
L_060AFE98:
    c.t = c.r[2] > c.r[5];  // 060AFE98 cmp/hi r5,r2
L_060AFE9A:
    { const bool k = c.t; c.r[5] = c.r[2] << 16 | c.r[2] >> 16; if (k) { goto L_060AFF2A; } }  // 060AFE9A bt/s 0x060AFF2A ; swap.w r2,r5
L_060AFE9E:
    c.r[2] = ld32(c.r[4] + 12);  // 060AFE9E mov.l @(12,r4),r2
L_060AFEA0:
    c.r[3] >>= 16;  // 060AFEA0 shlr16 r3
L_060AFEA2:
    c.r[0] >>= 16;  // 060AFEA2 shlr16 r0
L_060AFEA4:
    c.r[0] += c.r[2];  // 060AFEA4 add r2,r0
L_060AFEA6:
    c.t = c.r[0] > c.r[3];  // 060AFEA6 cmp/hi r3,r0
L_060AFEA8:
    { const bool k = c.t; c.r[5] = c.r[0] << 16 | c.r[5] >> 16; if (k) { goto L_060AFF2A; } }  // 060AFEA8 bt/s 0x060AFF2A ; xtrct r0,r5
L_060AFEAC:
    c.r[6] = ld32(0x060B009Cu);  // 060AFEAC mov.l 0x060B009C,r6
L_060AFEAE:
    c.r[0] = ld32(c.gbr + 72);  // 060AFEAE mov.l @(72,gbr),r0
L_060AFEB0:
    c.r[3] = ld32(c.r[6]);  // 060AFEB0 mov.l @r6,r3
L_060AFEB2:
    c.r[7] = c.r[0];  // 060AFEB2 mov r0,r7
L_060AFEB4:
    c.t = c.r[0] == c.r[3];  // 060AFEB4 cmp/eq r3,r0
L_060AFEB6:
    { const bool k = !c.t; c.r[0] = ld32(c.gbr + 28); if (k) { goto L_060AFF2E; } }  // 060AFEB6 bf/s 0x060AFF2E ; mov.l @(28,gbr),r0
L_060AFEBA:
    st32(c.r[7] + 4, c.r[1]);  // 060AFEBA mov.l r1,@(4,r7)
L_060AFEBC:
    st32(c.r[7] + 12, c.r[2]);  // 060AFEBC mov.l r2,@(12,r7)
L_060AFEBE:
    c.r[6] = c.r[0];  // 060AFEBE mov r0,r6
L_060AFEC0:
    c.r[0] = ld32(c.gbr + 36);  // 060AFEC0 mov.l @(36,gbr),r0
L_060AFEC2:
    c.r[1] <<= 2;  // 060AFEC2 shll2 r1
L_060AFEC4:
    c.r[1] <<= 2;  // 060AFEC4 shll2 r1
L_060AFEC6:
    c.r[0] += c.r[1];  // 060AFEC6 add r1,r0
L_060AFEC8:
    st32(c.gbr + 36, c.r[0]);  // 060AFEC8 mov.l r0,@(36,gbr)
L_060AFECA:
    c.r[0] = 0xFFFFFFFCu;  // 060AFECA mov #-4,r0
L_060AFECC:
    c.r[4] &= c.r[0];  // 060AFECC and r0,r4
L_060AFECE:
    c.r[1] = ld32(c.r[4]);  // 060AFECE mov.l @(0,r4),r1
L_060AFED0:
    c.r[2] = ld32(c.r[4] + 8);  // 060AFED0 mov.l @(8,r4),r2
L_060AFED2:
    c.r[3] = ld32(c.r[4] + 16);  // 060AFED2 mov.l @(16,r4),r3
L_060AFED4:
    c.r[1] &= c.r[0];  // 060AFED4 and r0,r1
L_060AFED6:
    c.r[2] &= c.r[0];  // 060AFED6 and r0,r2
L_060AFED8:
    c.r[0] = 0xFFFFFFFEu;  // 060AFED8 mov #-2,r0
L_060AFEDA:
    c.r[3] &= c.r[0];  // 060AFEDA and r0,r3
L_060AFEDC:
    st32(c.r[7] + 8, c.r[1]);  // 060AFEDC mov.l r1,@(8,r7)
L_060AFEDE:
    st32(c.r[7] + 16, c.r[2]);  // 060AFEDE mov.l r2,@(16,r7)
L_060AFEE0:
    st32(c.r[7] + 20, c.r[3]);  // 060AFEE0 mov.l r3,@(20,r7)
L_060AFEE2:
    c.r[1] = 0x14u;  // 060AFEE2 mov #20,r1
L_060AFEE4:
    st32(c.r[7], c.r[1]);  // 060AFEE4 mov.l r1,@(0,r7)
L_060AFEE6:
    c.r[0] = c.r[5];  // 060AFEE6 mov r5,r0
L_060AFEE8:
    st32(c.gbr + 116, c.r[0]);  // 060AFEE8 mov.l r0,@(116,gbr)
L_060AFEEA:
    c.r[7] += 24;  // 060AFEEA add #24,r7
L_060AFEEC:
    c.r[0] = ld32(c.r[6]);  // 060AFEEC mov.l @(0,r6),r0
L_060AFEEE:
    c.r[1] = ld32(c.r[6] + 4);  // 060AFEEE mov.l @(4,r6),r1
L_060AFEF0:
    c.r[2] = ld32(c.r[6] + 8);  // 060AFEF0 mov.l @(8,r6),r2
L_060AFEF2:
    c.r[3] = ld32(c.r[6] + 12);  // 060AFEF2 mov.l @(12,r6),r3
L_060AFEF4:
    st32(c.r[7], c.r[0]);  // 060AFEF4 mov.l r0,@(0,r7)
L_060AFEF6:
    st32(c.r[7] + 4, c.r[1]);  // 060AFEF6 mov.l r1,@(4,r7)
L_060AFEF8:
    st32(c.r[7] + 8, c.r[2]);  // 060AFEF8 mov.l r2,@(8,r7)
L_060AFEFA:
    st32(c.r[7] + 12, c.r[3]);  // 060AFEFA mov.l r3,@(12,r7)
L_060AFEFC:
    c.r[0] = ld32(c.r[6] + 16);  // 060AFEFC mov.l @(16,r6),r0
L_060AFEFE:
    c.r[1] = ld32(c.r[6] + 20);  // 060AFEFE mov.l @(20,r6),r1
L_060AFF00:
    c.r[2] = ld32(c.r[6] + 24);  // 060AFF00 mov.l @(24,r6),r2
L_060AFF02:
    c.r[3] = ld32(c.r[6] + 28);  // 060AFF02 mov.l @(28,r6),r3
L_060AFF04:
    st32(c.r[7] + 16, c.r[0]);  // 060AFF04 mov.l r0,@(16,r7)
L_060AFF06:
    st32(c.r[7] + 20, c.r[1]);  // 060AFF06 mov.l r1,@(20,r7)
L_060AFF08:
    st32(c.r[7] + 24, c.r[2]);  // 060AFF08 mov.l r2,@(24,r7)
L_060AFF0A:
    st32(c.r[7] + 28, c.r[3]);  // 060AFF0A mov.l r3,@(28,r7)
L_060AFF0C:
    c.r[0] = ld32(c.r[6] + 32);  // 060AFF0C mov.l @(32,r6),r0
L_060AFF0E:
    c.r[1] = ld32(c.r[6] + 36);  // 060AFF0E mov.l @(36,r6),r1
L_060AFF10:
    c.r[2] = ld32(c.r[6] + 40);  // 060AFF10 mov.l @(40,r6),r2
L_060AFF12:
    c.r[3] = ld32(c.r[6] + 44);  // 060AFF12 mov.l @(44,r6),r3
L_060AFF14:
    st32(c.r[7] + 32, c.r[0]);  // 060AFF14 mov.l r0,@(32,r7)
L_060AFF16:
    st32(c.r[7] + 36, c.r[1]);  // 060AFF16 mov.l r1,@(36,r7)
L_060AFF18:
    st32(c.r[7] + 40, c.r[2]);  // 060AFF18 mov.l r2,@(40,r7)
L_060AFF1A:
    st32(c.r[7] + 44, c.r[3]);  // 060AFF1A mov.l r3,@(44,r7)
L_060AFF1C:
    c.r[0] = 0x30u;  // 060AFF1C mov #48,r0
L_060AFF1E:
    c.r[0] += c.r[7];  // 060AFF1E add r7,r0
L_060AFF20:
    c.r[1] = ld32(0x060B00A0u);  // 060AFF20 mov.l 0x060B00A0,r1
L_060AFF22:
    st32(c.gbr + 72, c.r[0]);  // 060AFF22 mov.l r0,@(72,gbr)
L_060AFF24:
    st16(c.r[1], c.r[0]);  // 060AFF24 mov.w r0,@r1
L_060AFF26:
    { const uint32_t x = c.pr; c.r[0] = 0x1u; c.pc = x; return; }  // 060AFF26 rts ; mov #1,r0
L_060AFF2A:
    { const uint32_t x = c.pr; c.r[0] = 0x0u; c.pc = x; return; }  // 060AFF2A rts ; mov #0,r0
L_060AFF2E:
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060AFF2E mov.l r8,@-r15
L_060AFF30:
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060AFF30 mov.l r14,@-r15
L_060AFF32:
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060AFF32 mov.l r13,@-r15
L_060AFF34:
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060AFF34 mov.l r12,@-r15
L_060AFF36:
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060AFF36 mov.l r11,@-r15
L_060AFF38:
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060AFF38 mov.l r10,@-r15
L_060AFF3A:
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060AFF3A sts.l pr,@-r15
L_060AFF3C:
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060AFF3C mov.l r9,@-r15
L_060AFF3E:
    c.r[6] = c.r[0];  // 060AFF3E mov r0,r6
L_060AFF40:
    c.r[0] = ld32(c.gbr + 36);  // 060AFF40 mov.l @(36,gbr),r0
L_060AFF42:
    c.r[9] = c.r[1];  // 060AFF42 mov r1,r9
L_060AFF44:
    c.r[1] = 0xFFFFFFFCu;  // 060AFF44 mov #-4,r1
L_060AFF46:
    c.r[4] &= c.r[1];  // 060AFF46 and r1,r4
L_060AFF48:
    c.r[10] = ld32(c.r[4]);  // 060AFF48 mov.l @(0,r4),r10
L_060AFF4A:
    c.r[15] -= 4; st32(c.r[15], c.r[5]);  // 060AFF4A mov.l r5,@-r15
L_060AFF4C:
    c.r[15] -= 4; st32(c.r[15], c.r[4]);  // 060AFF4C mov.l r4,@-r15
L_060AFF4E:
    c.pr = 0x060AFF52u; c.r[11] = c.r[0]; SH2_POLL(c); sh2_call(c, 0x060B0CE4u); if (c.pc != 0x060AFF52u) return;  // 060AFF4E bsr 0x060B0CE4 ; mov r0,r11
L_060AFF52:
    c.r[2] = ld32(0x060B009Cu);  // 060AFF52 mov.l 0x060B009C,r2
L_060AFF54:
    c.r[4] = ld32(c.r[15]); c.r[15] += 4;  // 060AFF54 mov.l @r15+,r4
L_060AFF56:
    c.r[1] = ld32(c.r[2]);  // 060AFF56 mov.l @r2,r1
L_060AFF58:
    c.r[3] = c.r[7];  // 060AFF58 mov r7,r3
L_060AFF5A:
    c.r[3] -= 72;  // 060AFF5A add #-72,r3
L_060AFF5C:
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[3];  // 060AFF5C cmp/ge r3,r1
L_060AFF5E:
    { const bool k = !c.t; c.r[6] -= 32; if (k) { goto L_060AFFC8; } }  // 060AFF5E bf/s 0x060AFFC8 ; add #-32,r6
L_060AFF62:
    c.r[2] = ld32(c.r[4] + 4);  // 060AFF62 mov.l @(4,r4),r2
L_060AFF64:
    c.r[1] = 0x20u;  // 060AFF64 mov #32,r1
L_060AFF66:
    c.r[3] = ld32(c.r[4] + 8);  // 060AFF66 mov.l @(8,r4),r3
L_060AFF68:
    st32(c.r[7] + 8, c.r[0]);  // 060AFF68 mov.l r0,@(8,r7)
L_060AFF6A:
    st32(c.r[7], c.r[1]);  // 060AFF6A mov.l r1,@(0,r7)
L_060AFF6C:
    st32(c.r[7] + 4, c.r[2]);  // 060AFF6C mov.l r2,@(4,r7)
L_060AFF6E:
    c.r[1] = 0xFFFFFFFCu;  // 060AFF6E mov #-4,r1
L_060AFF70:
    c.r[0] = ld32(c.r[15]); c.r[15] += 4;  // 060AFF70 mov.l @r15+,r0
L_060AFF72:
    c.r[3] &= c.r[1];  // 060AFF72 and r1,r3
L_060AFF74:
    st32(c.r[7] + 16, c.r[3]);  // 060AFF74 mov.l r3,@(16,r7)
L_060AFF76:
    c.r[2] = ld32(c.r[4] + 12);  // 060AFF76 mov.l @(12,r4),r2
L_060AFF78:
    c.r[3] = ld32(c.r[4] + 16);  // 060AFF78 mov.l @(16,r4),r3
L_060AFF7A:
    c.r[1] = 0xFFFFFFFEu;  // 060AFF7A mov #-2,r1
L_060AFF7C:
    c.r[3] &= c.r[1];  // 060AFF7C and r1,r3
L_060AFF7E:
    st32(c.r[7] + 12, c.r[2]);  // 060AFF7E mov.l r2,@(12,r7)
L_060AFF80:
    st32(c.r[7] + 20, c.r[3]);  // 060AFF80 mov.l r3,@(20,r7)
L_060AFF82:
    st32(c.gbr + 116, c.r[0]);  // 060AFF82 mov.l r0,@(116,gbr)
L_060AFF84:
    c.r[1] = ld32(c.r[6] + 32);  // 060AFF84 mov.l @(32,r6),r1
L_060AFF86:
    c.r[2] = ld32(c.r[6] + 36);  // 060AFF86 mov.l @(36,r6),r2
L_060AFF88:
    c.r[3] = ld32(c.r[6] + 40);  // 060AFF88 mov.l @(40,r6),r3
L_060AFF8A:
    c.r[7] += 24;  // 060AFF8A add #24,r7
L_060AFF8C:
    st32(c.r[7] + 32, c.r[1]);  // 060AFF8C mov.l r1,@(32,r7)
L_060AFF8E:
    st32(c.r[7] + 36, c.r[2]);  // 060AFF8E mov.l r2,@(36,r7)
L_060AFF90:
    st32(c.r[7] + 40, c.r[3]);  // 060AFF90 mov.l r3,@(40,r7)
L_060AFF92:
    c.r[1] = ld32(c.r[6] + 16);  // 060AFF92 mov.l @(16,r6),r1
L_060AFF94:
    c.r[2] = ld32(c.r[6] + 20);  // 060AFF94 mov.l @(20,r6),r2
L_060AFF96:
    c.r[3] = ld32(c.r[6] + 24);  // 060AFF96 mov.l @(24,r6),r3
L_060AFF98:
    st32(c.r[7] + 16, c.r[1]);  // 060AFF98 mov.l r1,@(16,r7)
L_060AFF9A:
    st32(c.r[7] + 20, c.r[2]);  // 060AFF9A mov.l r2,@(20,r7)
L_060AFF9C:
    st32(c.r[7] + 24, c.r[3]);  // 060AFF9C mov.l r3,@(24,r7)
L_060AFF9E:
    c.r[1] = ld32(c.r[6]);  // 060AFF9E mov.l @(0,r6),r1
L_060AFFA0:
    c.r[2] = ld32(c.r[6] + 4);  // 060AFFA0 mov.l @(4,r6),r2
L_060AFFA2:
    c.r[3] = ld32(c.r[6] + 8);  // 060AFFA2 mov.l @(8,r6),r3
L_060AFFA4:
    st32(c.r[7], c.r[1]);  // 060AFFA4 mov.l r1,@(0,r7)
L_060AFFA6:
    st32(c.r[7] + 4, c.r[2]);  // 060AFFA6 mov.l r2,@(4,r7)
L_060AFFA8:
    st32(c.r[7] + 8, c.r[3]);  // 060AFFA8 mov.l r3,@(8,r7)
L_060AFFAA:
    c.r[0] = 0x30u;  // 060AFFAA mov #48,r0
L_060AFFAC:
    c.r[0] += c.r[7];  // 060AFFAC add r7,r0
L_060AFFAE:
    c.r[1] = ld32(0x060B00A0u);  // 060AFFAE mov.l 0x060B00A0,r1
L_060AFFB0:
    st32(c.gbr + 72, c.r[0]);  // 060AFFB0 mov.l r0,@(72,gbr)
L_060AFFB2:
    st16(c.r[1], c.r[1]);  // 060AFFB2 mov.w r1,@r1
L_060AFFB4:
    c.r[0] = 0x1u;  // 060AFFB4 mov #1,r0
L_060AFFB6:
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060AFFB6 mov.l @r15+,r9
L_060AFFB8:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060AFFB8 lds.l @r15+,pr
L_060AFFBA:
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060AFFBA mov.l @r15+,r10
L_060AFFBC:
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060AFFBC mov.l @r15+,r11
L_060AFFBE:
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060AFFBE mov.l @r15+,r12
L_060AFFC0:
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060AFFC0 mov.l @r15+,r13
L_060AFFC2:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060AFFC2 mov.l @r15+,r14
L_060AFFC4:
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060AFFC4 rts ; mov.l @r15+,r8
L_060AFFC8:
    c.r[10] = c.r[0];  // 060AFFC8 mov r0,r10
L_060AFFCA:
    c.r[0] = ld32(c.gbr + 60);  // 060AFFCA mov.l @(60,gbr),r0
L_060AFFCC:
    c.r[1] = 0x0u;  // 060AFFCC mov #0,r1
L_060AFFCE:
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060AFFCE mov.l r1,@-r15
L_060AFFD0:
    c.r[0] += 4;  // 060AFFD0 add #4,r0
L_060AFFD2:
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 060AFFD2 mov.l r0,@-r15
L_060AFFD4:
    c.r[13] = ld32(c.r[4] + 12);  // 060AFFD4 mov.l @(12,r4),r13
L_060AFFD6:
    c.r[1] = ld32(c.r[4] + 4);  // 060AFFD6 mov.l @(4,r4),r1
L_060AFFD8:
    c.r[0] = ld32(c.gbr + 48);  // 060AFFD8 mov.l @(48,gbr),r0
L_060AFFDA:
    st32(c.r[7] + 12, c.r[1]);  // 060AFFDA mov.l r1,@(12,r7)
L_060AFFDC:
    c.r[11] = c.r[0];  // 060AFFDC mov r0,r11
L_060AFFDE:
    st32(c.r[7] + 4, c.r[0]);  // 060AFFDE mov.l r0,@(4,r7)
L_060AFFE0:
    c.r[7] = ld32(c.r[4] + 8);  // 060AFFE0 mov.l @(8,r4),r7
L_060AFFE2:
    c.r[8] = ld32(c.r[4] + 16);  // 060AFFE2 mov.l @(16,r4),r8
L_060AFFE4:
    c.r[0] = 0xFFFFFFFCu;  // 060AFFE4 mov #-4,r0
L_060AFFE6:
    c.r[7] &= c.r[0];  // 060AFFE6 and r0,r7
L_060AFFE8:
    c.r[0] = 0xFFFFFFFEu;  // 060AFFE8 mov #-2,r0
L_060AFFEA:
    c.r[8] &= c.r[0];  // 060AFFEA and r0,r8
L_060AFFEC:
    c.r[0] = ld32(c.gbr + 104);  // 060AFFEC mov.l @(104,gbr),r0
L_060AFFEE:
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060AFFEE mov.l r13,@-r15
L_060AFFF0:
    c.r[1] = c.r[0];  // 060AFFF0 mov r0,r1
L_060AFFF2:
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 172);  // 060AFFF2 mov.b @(172,gbr),r0
L_060AFFF4:
    c.r[1] >>= 16;  // 060AFFF4 shlr16 r1
L_060AFFF6:
    c.r[0] -= 1; c.t = c.r[0] == 0;  // 060AFFF6 dt r0
L_060AFFF8:
    { const bool k = !c.t; c.t = c.r[1] & 1; c.r[1] >>= 1; if (k) { SH2_POLL(c); goto L_060AFFF6; } }  // 060AFFF8 bf/s 0x060AFFF6 ; shlr r1
L_060AFFFC:
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060AFFFC mov.l r1,@-r15
L_060AFFFE:
    c.r[15] -= 12;  // 060AFFFE add #-12,r15
L_060B0000:
    c.r[14] = 0xFFFFFFFFu;  // 060B0000 mov #-1,r14
L_060B0002:
    c.r[0] = 0x060B00B8u;  // 060B0002 mova 0x060B00B8,r0
L_060B0004:
    c.pr = c.r[0];  // 060B0004 lds r0,pr
L_060B0006:
    c.mach = c.macl = 0;  // 060B0006 clrmac
L_060B0008:
    sh2_mac_l(c, 6, 7);  // 060B0008 mac.l @r7+,@r6+
L_060B000A:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[7] + 8);  // 060B000A mov.w @(8,r7),r0
L_060B000C:
    c.r[5] = c.r[15];  // 060B000C mov r15,r5
L_060B000E:
    sh2_mac_l(c, 6, 7);  // 060B000E mac.l @r7+,@r6+
L_060B0010:
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B0010 exts.w r0,r1
L_060B0012:
    c.r[1] <<= 2;  // 060B0012 shll2 r1
L_060B0014:
    sh2_mac_l(c, 6, 7);  // 060B0014 mac.l @r7+,@r6+
L_060B0016:
    c.r[6] += 4;  // 060B0016 add #4,r6
L_060B0018:
    c.r[7] -= 12;  // 060B0018 add #-12,r7
L_060B001A:
    c.r[1] <<= 2;  // 060B001A shll2 r1
L_060B001C:
    c.r[0] = c.mach;  // 060B001C sts mach,r0
L_060B001E:
    c.r[13] = c.macl;  // 060B001E sts macl,r13
L_060B0020:
    c.mach = c.macl = 0;  // 060B0020 clrmac
L_060B0022:
    sh2_mac_l(c, 6, 7);  // 060B0022 mac.l @r7+,@r6+
L_060B0024:
    c.r[13] = c.r[0] << 16 | c.r[13] >> 16;  // 060B0024 xtrct r0,r13
L_060B0026:
    st32(c.r[5], c.r[13]);  // 060B0026 mov.l r13,@(0,r5)
L_060B0028:
    sh2_mac_l(c, 6, 7);  // 060B0028 mac.l @r7+,@r6+
L_060B002A:
    c.r[1] += c.r[10];  // 060B002A add r10,r1
L_060B002C:
    c.r[4] = 0x4u;  // 060B002C mov #4,r4
L_060B002E:
    sh2_mac_l(c, 6, 7);  // 060B002E mac.l @r7+,@r6+
L_060B0030:
    c.r[6] += 4;  // 060B0030 add #4,r6
L_060B0032:
    c.r[7] -= 12;  // 060B0032 add #-12,r7
L_060B0034:
    c.r[4] += c.r[1];  // 060B0034 add r1,r4
L_060B0036:
    c.r[0] = c.mach;  // 060B0036 sts mach,r0
L_060B0038:
    c.r[2] = c.macl;  // 060B0038 sts macl,r2
L_060B003A:
    c.mach = c.macl = 0;  // 060B003A clrmac
L_060B003C:
    sh2_mac_l(c, 6, 7);  // 060B003C mac.l @r7+,@r6+
L_060B003E:
    c.r[2] = c.r[0] << 16 | c.r[2] >> 16;  // 060B003E xtrct r0,r2
L_060B0040:
    st32(c.r[5] + 4, c.r[2]);  // 060B0040 mov.l r2,@(4,r5)
L_060B0042:
    sh2_mac_l(c, 6, 7);  // 060B0042 mac.l @r7+,@r6+
L_060B0044:
    c.r[12] = (uint32_t)(int16_t)ld16(c.r[8]);  // 060B0044 mov.w @r8,r12
L_060B0046:
    c.r[9] = 0x7Fu;  // 060B0046 mov #127,r9
L_060B0048:
    sh2_mac_l(c, 6, 7);  // 060B0048 mac.l @r7+,@r6+
L_060B004A:
    c.r[6] -= 44;  // 060B004A add #-44,r6
L_060B004C:
    c.r[9] &= c.r[12];  // 060B004C and r12,r9
L_060B004E:
    c.r[9] <<= 2;  // 060B004E shll2 r9
L_060B0050:
    c.r[0] = c.mach;  // 060B0050 sts mach,r0
L_060B0052:
    c.r[3] = c.macl;  // 060B0052 sts macl,r3
L_060B0054:
    c.mach = c.macl = 0;  // 060B0054 clrmac
L_060B0056:
    sh2_mac_l(c, 5, 4);  // 060B0056 mac.l @r4+,@r5+
L_060B0058:
    c.r[3] = c.r[0] << 16 | c.r[3] >> 16;  // 060B0058 xtrct r0,r3
L_060B005A:
    c.r[0] = 0x060B0104u;  // 060B005A mova 0x060B0104,r0
L_060B005C:
    sh2_mac_l(c, 5, 4);  // 060B005C mac.l @r4+,@r5+
L_060B005E:
    st32(c.r[5], c.r[3]);  // 060B005E mov.l r3,@r5
L_060B0060:
    c.r[9] <<= 2;  // 060B0060 shll2 r9
L_060B0062:
    sh2_mac_l(c, 5, 4);  // 060B0062 mac.l @r4+,@r5+
L_060B0064:
    c.r[9] += c.r[0];  // 060B0064 add r0,r9
L_060B0066:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[8] + 10);  // 060B0066 mov.w @(10,r8),r0
L_060B0068:
    c.r[7] += 2;  // 060B0068 add #2,r7
L_060B006A:
    c.r[4] = c.mach;  // 060B006A sts mach,r4
L_060B006C:
    st16(c.r[11], c.r[0]);  // 060B006C mov.w r0,@(0,r11)
L_060B006E:
    c.r[0] = ld32(c.gbr + 896);  // 060B006E mov.l @(896,gbr),r0
L_060B0070:
    c.t = (int32_t)c.r[4] >= (int32_t)c.r[0];  // 060B0070 cmp/ge r0,r4
L_060B0072:
    { const bool k = c.t; c.r[0] = (c.r[12] & 0xFFFF0000u) | (c.r[12] & 0xFFu) << 8 | (c.r[12] >> 8 & 0xFFu); if (k) { goto L_060B007E; } }  // 060B0072 bt/s 0x060B007E ; swap.b r12,r0
L_060B0076:
    c.r[4] = ld32(c.r[9]); c.r[9] += 4;  // 060B0076 mov.l @r9+,r4
L_060B0078:
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 060B0078 mov.w @r7+,r2
L_060B007A:
    { const uint32_t x = c.r[4]; c.r[2] <<= 2; SH2_POLL(c); switch (x) { case 0x060AFE80u: goto L_060AFE80; case 0x060AFE82u: goto L_060AFE82; case 0x060AFE84u: goto L_060AFE84; case 0x060AFE86u: goto L_060AFE86; case 0x060AFE88u: goto L_060AFE88; case 0x060AFE8Au: goto L_060AFE8A; case 0x060AFE8Cu: goto L_060AFE8C; case 0x060AFE8Eu: goto L_060AFE8E; case 0x060AFE90u: goto L_060AFE90; case 0x060AFE92u: goto L_060AFE92; case 0x060AFE94u: goto L_060AFE94; case 0x060AFE96u: goto L_060AFE96; case 0x060AFE98u: goto L_060AFE98; case 0x060AFE9Au: goto L_060AFE9A; case 0x060AFE9Eu: goto L_060AFE9E; case 0x060AFEA0u: goto L_060AFEA0; case 0x060AFEA2u: goto L_060AFEA2; case 0x060AFEA4u: goto L_060AFEA4; case 0x060AFEA6u: goto L_060AFEA6; case 0x060AFEA8u: goto L_060AFEA8; case 0x060AFEACu: goto L_060AFEAC; case 0x060AFEAEu: goto L_060AFEAE; case 0x060AFEB0u: goto L_060AFEB0; case 0x060AFEB2u: goto L_060AFEB2; case 0x060AFEB4u: goto L_060AFEB4; case 0x060AFEB6u: goto L_060AFEB6; case 0x060AFEBAu: goto L_060AFEBA; case 0x060AFEBCu: goto L_060AFEBC; case 0x060AFEBEu: goto L_060AFEBE; case 0x060AFEC0u: goto L_060AFEC0; case 0x060AFEC2u: goto L_060AFEC2; case 0x060AFEC4u: goto L_060AFEC4; case 0x060AFEC6u: goto L_060AFEC6; case 0x060AFEC8u: goto L_060AFEC8; case 0x060AFECAu: goto L_060AFECA; case 0x060AFECCu: goto L_060AFECC; case 0x060AFECEu: goto L_060AFECE; case 0x060AFED0u: goto L_060AFED0; case 0x060AFED2u: goto L_060AFED2; case 0x060AFED4u: goto L_060AFED4; case 0x060AFED6u: goto L_060AFED6; case 0x060AFED8u: goto L_060AFED8; case 0x060AFEDAu: goto L_060AFEDA; case 0x060AFEDCu: goto L_060AFEDC; case 0x060AFEDEu: goto L_060AFEDE; case 0x060AFEE0u: goto L_060AFEE0; case 0x060AFEE2u: goto L_060AFEE2; case 0x060AFEE4u: goto L_060AFEE4; case 0x060AFEE6u: goto L_060AFEE6; case 0x060AFEE8u: goto L_060AFEE8; case 0x060AFEEAu: goto L_060AFEEA; case 0x060AFEECu: goto L_060AFEEC; case 0x060AFEEEu: goto L_060AFEEE; case 0x060AFEF0u: goto L_060AFEF0; case 0x060AFEF2u: goto L_060AFEF2; case 0x060AFEF4u: goto L_060AFEF4; case 0x060AFEF6u: goto L_060AFEF6; case 0x060AFEF8u: goto L_060AFEF8; case 0x060AFEFAu: goto L_060AFEFA; case 0x060AFEFCu: goto L_060AFEFC; case 0x060AFEFEu: goto L_060AFEFE; case 0x060AFF00u: goto L_060AFF00; case 0x060AFF02u: goto L_060AFF02; case 0x060AFF04u: goto L_060AFF04; case 0x060AFF06u: goto L_060AFF06; case 0x060AFF08u: goto L_060AFF08; case 0x060AFF0Au: goto L_060AFF0A; case 0x060AFF0Cu: goto L_060AFF0C; case 0x060AFF0Eu: goto L_060AFF0E; case 0x060AFF10u: goto L_060AFF10; case 0x060AFF12u: goto L_060AFF12; case 0x060AFF14u: goto L_060AFF14; case 0x060AFF16u: goto L_060AFF16; case 0x060AFF18u: goto L_060AFF18; case 0x060AFF1Au: goto L_060AFF1A; case 0x060AFF1Cu: goto L_060AFF1C; case 0x060AFF1Eu: goto L_060AFF1E; case 0x060AFF20u: goto L_060AFF20; case 0x060AFF22u: goto L_060AFF22; case 0x060AFF24u: goto L_060AFF24; case 0x060AFF26u: goto L_060AFF26; case 0x060AFF2Au: goto L_060AFF2A; case 0x060AFF2Eu: goto L_060AFF2E; case 0x060AFF30u: goto L_060AFF30; case 0x060AFF32u: goto L_060AFF32; case 0x060AFF34u: goto L_060AFF34; case 0x060AFF36u: goto L_060AFF36; case 0x060AFF38u: goto L_060AFF38; case 0x060AFF3Au: goto L_060AFF3A; case 0x060AFF3Cu: goto L_060AFF3C; case 0x060AFF3Eu: goto L_060AFF3E; case 0x060AFF40u: goto L_060AFF40; case 0x060AFF42u: goto L_060AFF42; case 0x060AFF44u: goto L_060AFF44; case 0x060AFF46u: goto L_060AFF46; case 0x060AFF48u: goto L_060AFF48; case 0x060AFF4Au: goto L_060AFF4A; case 0x060AFF4Cu: goto L_060AFF4C; case 0x060AFF4Eu: goto L_060AFF4E; case 0x060AFF52u: goto L_060AFF52; case 0x060AFF54u: goto L_060AFF54; case 0x060AFF56u: goto L_060AFF56; case 0x060AFF58u: goto L_060AFF58; case 0x060AFF5Au: goto L_060AFF5A; case 0x060AFF5Cu: goto L_060AFF5C; case 0x060AFF5Eu: goto L_060AFF5E; case 0x060AFF62u: goto L_060AFF62; case 0x060AFF64u: goto L_060AFF64; case 0x060AFF66u: goto L_060AFF66; case 0x060AFF68u: goto L_060AFF68; case 0x060AFF6Au: goto L_060AFF6A; case 0x060AFF6Cu: goto L_060AFF6C; case 0x060AFF6Eu: goto L_060AFF6E; case 0x060AFF70u: goto L_060AFF70; case 0x060AFF72u: goto L_060AFF72; case 0x060AFF74u: goto L_060AFF74; case 0x060AFF76u: goto L_060AFF76; case 0x060AFF78u: goto L_060AFF78; case 0x060AFF7Au: goto L_060AFF7A; case 0x060AFF7Cu: goto L_060AFF7C; case 0x060AFF7Eu: goto L_060AFF7E; case 0x060AFF80u: goto L_060AFF80; case 0x060AFF82u: goto L_060AFF82; case 0x060AFF84u: goto L_060AFF84; case 0x060AFF86u: goto L_060AFF86; case 0x060AFF88u: goto L_060AFF88; case 0x060AFF8Au: goto L_060AFF8A; case 0x060AFF8Cu: goto L_060AFF8C; case 0x060AFF8Eu: goto L_060AFF8E; case 0x060AFF90u: goto L_060AFF90; case 0x060AFF92u: goto L_060AFF92; case 0x060AFF94u: goto L_060AFF94; case 0x060AFF96u: goto L_060AFF96; case 0x060AFF98u: goto L_060AFF98; case 0x060AFF9Au: goto L_060AFF9A; case 0x060AFF9Cu: goto L_060AFF9C; case 0x060AFF9Eu: goto L_060AFF9E; case 0x060AFFA0u: goto L_060AFFA0; case 0x060AFFA2u: goto L_060AFFA2; case 0x060AFFA4u: goto L_060AFFA4; case 0x060AFFA6u: goto L_060AFFA6; case 0x060AFFA8u: goto L_060AFFA8; case 0x060AFFAAu: goto L_060AFFAA; case 0x060AFFACu: goto L_060AFFAC; case 0x060AFFAEu: goto L_060AFFAE; case 0x060AFFB0u: goto L_060AFFB0; case 0x060AFFB2u: goto L_060AFFB2; case 0x060AFFB4u: goto L_060AFFB4; case 0x060AFFB6u: goto L_060AFFB6; case 0x060AFFB8u: goto L_060AFFB8; case 0x060AFFBAu: goto L_060AFFBA; case 0x060AFFBCu: goto L_060AFFBC; case 0x060AFFBEu: goto L_060AFFBE; case 0x060AFFC0u: goto L_060AFFC0; case 0x060AFFC2u: goto L_060AFFC2; case 0x060AFFC4u: goto L_060AFFC4; case 0x060AFFC8u: goto L_060AFFC8; case 0x060AFFCAu: goto L_060AFFCA; case 0x060AFFCCu: goto L_060AFFCC; case 0x060AFFCEu: goto L_060AFFCE; case 0x060AFFD0u: goto L_060AFFD0; case 0x060AFFD2u: goto L_060AFFD2; case 0x060AFFD4u: goto L_060AFFD4; case 0x060AFFD6u: goto L_060AFFD6; case 0x060AFFD8u: goto L_060AFFD8; case 0x060AFFDAu: goto L_060AFFDA; case 0x060AFFDCu: goto L_060AFFDC; case 0x060AFFDEu: goto L_060AFFDE; case 0x060AFFE0u: goto L_060AFFE0; case 0x060AFFE2u: goto L_060AFFE2; case 0x060AFFE4u: goto L_060AFFE4; case 0x060AFFE6u: goto L_060AFFE6; case 0x060AFFE8u: goto L_060AFFE8; case 0x060AFFEAu: goto L_060AFFEA; case 0x060AFFECu: goto L_060AFFEC; case 0x060AFFEEu: goto L_060AFFEE; case 0x060AFFF0u: goto L_060AFFF0; case 0x060AFFF2u: goto L_060AFFF2; case 0x060AFFF4u: goto L_060AFFF4; case 0x060AFFF6u: goto L_060AFFF6; case 0x060AFFF8u: goto L_060AFFF8; case 0x060AFFFCu: goto L_060AFFFC; case 0x060AFFFEu: goto L_060AFFFE; case 0x060B0000u: goto L_060B0000; case 0x060B0002u: goto L_060B0002; case 0x060B0004u: goto L_060B0004; case 0x060B0006u: goto L_060B0006; case 0x060B0008u: goto L_060B0008; case 0x060B000Au: goto L_060B000A; case 0x060B000Cu: goto L_060B000C; case 0x060B000Eu: goto L_060B000E; case 0x060B0010u: goto L_060B0010; case 0x060B0012u: goto L_060B0012; case 0x060B0014u: goto L_060B0014; case 0x060B0016u: goto L_060B0016; case 0x060B0018u: goto L_060B0018; case 0x060B001Au: goto L_060B001A; case 0x060B001Cu: goto L_060B001C; case 0x060B001Eu: goto L_060B001E; case 0x060B0020u: goto L_060B0020; case 0x060B0022u: goto L_060B0022; case 0x060B0024u: goto L_060B0024; case 0x060B0026u: goto L_060B0026; case 0x060B0028u: goto L_060B0028; case 0x060B002Au: goto L_060B002A; case 0x060B002Cu: goto L_060B002C; case 0x060B002Eu: goto L_060B002E; case 0x060B0030u: goto L_060B0030; case 0x060B0032u: goto L_060B0032; case 0x060B0034u: goto L_060B0034; case 0x060B0036u: goto L_060B0036; case 0x060B0038u: goto L_060B0038; case 0x060B003Au: goto L_060B003A; case 0x060B003Cu: goto L_060B003C; case 0x060B003Eu: goto L_060B003E; case 0x060B0040u: goto L_060B0040; case 0x060B0042u: goto L_060B0042; case 0x060B0044u: goto L_060B0044; case 0x060B0046u: goto L_060B0046; case 0x060B0048u: goto L_060B0048; case 0x060B004Au: goto L_060B004A; case 0x060B004Cu: goto L_060B004C; case 0x060B004Eu: goto L_060B004E; case 0x060B0050u: goto L_060B0050; case 0x060B0052u: goto L_060B0052; case 0x060B0054u: goto L_060B0054; case 0x060B0056u: goto L_060B0056; case 0x060B0058u: goto L_060B0058; case 0x060B005Au: goto L_060B005A; case 0x060B005Cu: goto L_060B005C; case 0x060B005Eu: goto L_060B005E; case 0x060B0060u: goto L_060B0060; case 0x060B0062u: goto L_060B0062; case 0x060B0064u: goto L_060B0064; case 0x060B0066u: goto L_060B0066; case 0x060B0068u: goto L_060B0068; case 0x060B006Au: goto L_060B006A; case 0x060B006Cu: goto L_060B006C; case 0x060B006Eu: goto L_060B006E; case 0x060B0070u: goto L_060B0070; case 0x060B0072u: goto L_060B0072; case 0x060B0076u: goto L_060B0076; case 0x060B0078u: goto L_060B0078; case 0x060B007Au: goto L_060B007A; case 0x060B007Eu: goto L_060B007E; case 0x060B0080u: goto L_060B0080; case 0x060B0084u: goto L_060B0084; case 0x060B0086u: goto L_060B0086; case 0x060B0088u: goto L_060B0088; case 0x060B008Au: goto L_060B008A; case 0x060B008Cu: goto L_060B008C; case 0x060B008Eu: goto L_060B008E; case 0x060B0090u: goto L_060B0090; case 0x060B0092u: goto L_060B0092; case 0x060B0096u: goto L_060B0096; case 0x060B00C4u: goto L_060B00C4; case 0x060B00C6u: goto L_060B00C6; case 0x060B00C8u: goto L_060B00C8; case 0x060B00CAu: goto L_060B00CA; case 0x060B00CEu: goto L_060B00CE; case 0x060B00D0u: goto L_060B00D0; case 0x060B00D2u: goto L_060B00D2; case 0x060B00D4u: goto L_060B00D4; case 0x060B00D6u: goto L_060B00D6; case 0x060B00D8u: goto L_060B00D8; case 0x060B00DAu: goto L_060B00DA; case 0x060B00DCu: goto L_060B00DC; case 0x060B00DEu: goto L_060B00DE; case 0x060B00E0u: goto L_060B00E0; case 0x060B00E2u: goto L_060B00E2; case 0x060B00E4u: goto L_060B00E4; case 0x060B00E6u: goto L_060B00E6; case 0x060B00E8u: goto L_060B00E8; case 0x060B00EAu: goto L_060B00EA; case 0x060B00ECu: goto L_060B00EC; case 0x060B00EEu: goto L_060B00EE; case 0x060B00F0u: goto L_060B00F0; case 0x060B00F2u: goto L_060B00F2; case 0x060B00F4u: goto L_060B00F4; case 0x060B00F6u: goto L_060B00F6; case 0x060B00F8u: goto L_060B00F8; case 0x060B00FAu: goto L_060B00FA; case 0x060B00FCu: goto L_060B00FC; default: sh2_call(c, x); return; } }  // 060B007A jmp @r4 ; shll2 r2
L_060B007E:
    c.t = (c.r[0] & 0x1u) == 0;  // 060B007E tst #1,r0
L_060B0080:
    { const bool k = c.t; c.r[3] = 0u - c.r[3]; if (k) { goto L_060B0096; } }  // 060B0080 bt/s 0x060B0096 ; neg r3,r3
L_060B0084:
    c.r[5] -= 4; st32(c.r[5], c.r[3]);  // 060B0084 mov.l r3,@-r5
L_060B0086:
    c.r[2] = 0u - c.r[2];  // 060B0086 neg r2,r2
L_060B0088:
    c.r[5] -= 4; st32(c.r[5], c.r[2]);  // 060B0088 mov.l r2,@-r5
L_060B008A:
    c.r[13] = 0u - c.r[13];  // 060B008A neg r13,r13
L_060B008C:
    c.r[5] -= 4; st32(c.r[5], c.r[13]);  // 060B008C mov.l r13,@-r5
L_060B008E:
    c.r[4] = ld32(c.r[9]); c.r[9] += 4;  // 060B008E mov.l @r9+,r4
L_060B0090:
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 060B0090 mov.w @r7+,r2
L_060B0092:
    { const uint32_t x = c.r[4]; c.r[2] <<= 2; SH2_POLL(c); switch (x) { case 0x060AFE80u: goto L_060AFE80; case 0x060AFE82u: goto L_060AFE82; case 0x060AFE84u: goto L_060AFE84; case 0x060AFE86u: goto L_060AFE86; case 0x060AFE88u: goto L_060AFE88; case 0x060AFE8Au: goto L_060AFE8A; case 0x060AFE8Cu: goto L_060AFE8C; case 0x060AFE8Eu: goto L_060AFE8E; case 0x060AFE90u: goto L_060AFE90; case 0x060AFE92u: goto L_060AFE92; case 0x060AFE94u: goto L_060AFE94; case 0x060AFE96u: goto L_060AFE96; case 0x060AFE98u: goto L_060AFE98; case 0x060AFE9Au: goto L_060AFE9A; case 0x060AFE9Eu: goto L_060AFE9E; case 0x060AFEA0u: goto L_060AFEA0; case 0x060AFEA2u: goto L_060AFEA2; case 0x060AFEA4u: goto L_060AFEA4; case 0x060AFEA6u: goto L_060AFEA6; case 0x060AFEA8u: goto L_060AFEA8; case 0x060AFEACu: goto L_060AFEAC; case 0x060AFEAEu: goto L_060AFEAE; case 0x060AFEB0u: goto L_060AFEB0; case 0x060AFEB2u: goto L_060AFEB2; case 0x060AFEB4u: goto L_060AFEB4; case 0x060AFEB6u: goto L_060AFEB6; case 0x060AFEBAu: goto L_060AFEBA; case 0x060AFEBCu: goto L_060AFEBC; case 0x060AFEBEu: goto L_060AFEBE; case 0x060AFEC0u: goto L_060AFEC0; case 0x060AFEC2u: goto L_060AFEC2; case 0x060AFEC4u: goto L_060AFEC4; case 0x060AFEC6u: goto L_060AFEC6; case 0x060AFEC8u: goto L_060AFEC8; case 0x060AFECAu: goto L_060AFECA; case 0x060AFECCu: goto L_060AFECC; case 0x060AFECEu: goto L_060AFECE; case 0x060AFED0u: goto L_060AFED0; case 0x060AFED2u: goto L_060AFED2; case 0x060AFED4u: goto L_060AFED4; case 0x060AFED6u: goto L_060AFED6; case 0x060AFED8u: goto L_060AFED8; case 0x060AFEDAu: goto L_060AFEDA; case 0x060AFEDCu: goto L_060AFEDC; case 0x060AFEDEu: goto L_060AFEDE; case 0x060AFEE0u: goto L_060AFEE0; case 0x060AFEE2u: goto L_060AFEE2; case 0x060AFEE4u: goto L_060AFEE4; case 0x060AFEE6u: goto L_060AFEE6; case 0x060AFEE8u: goto L_060AFEE8; case 0x060AFEEAu: goto L_060AFEEA; case 0x060AFEECu: goto L_060AFEEC; case 0x060AFEEEu: goto L_060AFEEE; case 0x060AFEF0u: goto L_060AFEF0; case 0x060AFEF2u: goto L_060AFEF2; case 0x060AFEF4u: goto L_060AFEF4; case 0x060AFEF6u: goto L_060AFEF6; case 0x060AFEF8u: goto L_060AFEF8; case 0x060AFEFAu: goto L_060AFEFA; case 0x060AFEFCu: goto L_060AFEFC; case 0x060AFEFEu: goto L_060AFEFE; case 0x060AFF00u: goto L_060AFF00; case 0x060AFF02u: goto L_060AFF02; case 0x060AFF04u: goto L_060AFF04; case 0x060AFF06u: goto L_060AFF06; case 0x060AFF08u: goto L_060AFF08; case 0x060AFF0Au: goto L_060AFF0A; case 0x060AFF0Cu: goto L_060AFF0C; case 0x060AFF0Eu: goto L_060AFF0E; case 0x060AFF10u: goto L_060AFF10; case 0x060AFF12u: goto L_060AFF12; case 0x060AFF14u: goto L_060AFF14; case 0x060AFF16u: goto L_060AFF16; case 0x060AFF18u: goto L_060AFF18; case 0x060AFF1Au: goto L_060AFF1A; case 0x060AFF1Cu: goto L_060AFF1C; case 0x060AFF1Eu: goto L_060AFF1E; case 0x060AFF20u: goto L_060AFF20; case 0x060AFF22u: goto L_060AFF22; case 0x060AFF24u: goto L_060AFF24; case 0x060AFF26u: goto L_060AFF26; case 0x060AFF2Au: goto L_060AFF2A; case 0x060AFF2Eu: goto L_060AFF2E; case 0x060AFF30u: goto L_060AFF30; case 0x060AFF32u: goto L_060AFF32; case 0x060AFF34u: goto L_060AFF34; case 0x060AFF36u: goto L_060AFF36; case 0x060AFF38u: goto L_060AFF38; case 0x060AFF3Au: goto L_060AFF3A; case 0x060AFF3Cu: goto L_060AFF3C; case 0x060AFF3Eu: goto L_060AFF3E; case 0x060AFF40u: goto L_060AFF40; case 0x060AFF42u: goto L_060AFF42; case 0x060AFF44u: goto L_060AFF44; case 0x060AFF46u: goto L_060AFF46; case 0x060AFF48u: goto L_060AFF48; case 0x060AFF4Au: goto L_060AFF4A; case 0x060AFF4Cu: goto L_060AFF4C; case 0x060AFF4Eu: goto L_060AFF4E; case 0x060AFF52u: goto L_060AFF52; case 0x060AFF54u: goto L_060AFF54; case 0x060AFF56u: goto L_060AFF56; case 0x060AFF58u: goto L_060AFF58; case 0x060AFF5Au: goto L_060AFF5A; case 0x060AFF5Cu: goto L_060AFF5C; case 0x060AFF5Eu: goto L_060AFF5E; case 0x060AFF62u: goto L_060AFF62; case 0x060AFF64u: goto L_060AFF64; case 0x060AFF66u: goto L_060AFF66; case 0x060AFF68u: goto L_060AFF68; case 0x060AFF6Au: goto L_060AFF6A; case 0x060AFF6Cu: goto L_060AFF6C; case 0x060AFF6Eu: goto L_060AFF6E; case 0x060AFF70u: goto L_060AFF70; case 0x060AFF72u: goto L_060AFF72; case 0x060AFF74u: goto L_060AFF74; case 0x060AFF76u: goto L_060AFF76; case 0x060AFF78u: goto L_060AFF78; case 0x060AFF7Au: goto L_060AFF7A; case 0x060AFF7Cu: goto L_060AFF7C; case 0x060AFF7Eu: goto L_060AFF7E; case 0x060AFF80u: goto L_060AFF80; case 0x060AFF82u: goto L_060AFF82; case 0x060AFF84u: goto L_060AFF84; case 0x060AFF86u: goto L_060AFF86; case 0x060AFF88u: goto L_060AFF88; case 0x060AFF8Au: goto L_060AFF8A; case 0x060AFF8Cu: goto L_060AFF8C; case 0x060AFF8Eu: goto L_060AFF8E; case 0x060AFF90u: goto L_060AFF90; case 0x060AFF92u: goto L_060AFF92; case 0x060AFF94u: goto L_060AFF94; case 0x060AFF96u: goto L_060AFF96; case 0x060AFF98u: goto L_060AFF98; case 0x060AFF9Au: goto L_060AFF9A; case 0x060AFF9Cu: goto L_060AFF9C; case 0x060AFF9Eu: goto L_060AFF9E; case 0x060AFFA0u: goto L_060AFFA0; case 0x060AFFA2u: goto L_060AFFA2; case 0x060AFFA4u: goto L_060AFFA4; case 0x060AFFA6u: goto L_060AFFA6; case 0x060AFFA8u: goto L_060AFFA8; case 0x060AFFAAu: goto L_060AFFAA; case 0x060AFFACu: goto L_060AFFAC; case 0x060AFFAEu: goto L_060AFFAE; case 0x060AFFB0u: goto L_060AFFB0; case 0x060AFFB2u: goto L_060AFFB2; case 0x060AFFB4u: goto L_060AFFB4; case 0x060AFFB6u: goto L_060AFFB6; case 0x060AFFB8u: goto L_060AFFB8; case 0x060AFFBAu: goto L_060AFFBA; case 0x060AFFBCu: goto L_060AFFBC; case 0x060AFFBEu: goto L_060AFFBE; case 0x060AFFC0u: goto L_060AFFC0; case 0x060AFFC2u: goto L_060AFFC2; case 0x060AFFC4u: goto L_060AFFC4; case 0x060AFFC8u: goto L_060AFFC8; case 0x060AFFCAu: goto L_060AFFCA; case 0x060AFFCCu: goto L_060AFFCC; case 0x060AFFCEu: goto L_060AFFCE; case 0x060AFFD0u: goto L_060AFFD0; case 0x060AFFD2u: goto L_060AFFD2; case 0x060AFFD4u: goto L_060AFFD4; case 0x060AFFD6u: goto L_060AFFD6; case 0x060AFFD8u: goto L_060AFFD8; case 0x060AFFDAu: goto L_060AFFDA; case 0x060AFFDCu: goto L_060AFFDC; case 0x060AFFDEu: goto L_060AFFDE; case 0x060AFFE0u: goto L_060AFFE0; case 0x060AFFE2u: goto L_060AFFE2; case 0x060AFFE4u: goto L_060AFFE4; case 0x060AFFE6u: goto L_060AFFE6; case 0x060AFFE8u: goto L_060AFFE8; case 0x060AFFEAu: goto L_060AFFEA; case 0x060AFFECu: goto L_060AFFEC; case 0x060AFFEEu: goto L_060AFFEE; case 0x060AFFF0u: goto L_060AFFF0; case 0x060AFFF2u: goto L_060AFFF2; case 0x060AFFF4u: goto L_060AFFF4; case 0x060AFFF6u: goto L_060AFFF6; case 0x060AFFF8u: goto L_060AFFF8; case 0x060AFFFCu: goto L_060AFFFC; case 0x060AFFFEu: goto L_060AFFFE; case 0x060B0000u: goto L_060B0000; case 0x060B0002u: goto L_060B0002; case 0x060B0004u: goto L_060B0004; case 0x060B0006u: goto L_060B0006; case 0x060B0008u: goto L_060B0008; case 0x060B000Au: goto L_060B000A; case 0x060B000Cu: goto L_060B000C; case 0x060B000Eu: goto L_060B000E; case 0x060B0010u: goto L_060B0010; case 0x060B0012u: goto L_060B0012; case 0x060B0014u: goto L_060B0014; case 0x060B0016u: goto L_060B0016; case 0x060B0018u: goto L_060B0018; case 0x060B001Au: goto L_060B001A; case 0x060B001Cu: goto L_060B001C; case 0x060B001Eu: goto L_060B001E; case 0x060B0020u: goto L_060B0020; case 0x060B0022u: goto L_060B0022; case 0x060B0024u: goto L_060B0024; case 0x060B0026u: goto L_060B0026; case 0x060B0028u: goto L_060B0028; case 0x060B002Au: goto L_060B002A; case 0x060B002Cu: goto L_060B002C; case 0x060B002Eu: goto L_060B002E; case 0x060B0030u: goto L_060B0030; case 0x060B0032u: goto L_060B0032; case 0x060B0034u: goto L_060B0034; case 0x060B0036u: goto L_060B0036; case 0x060B0038u: goto L_060B0038; case 0x060B003Au: goto L_060B003A; case 0x060B003Cu: goto L_060B003C; case 0x060B003Eu: goto L_060B003E; case 0x060B0040u: goto L_060B0040; case 0x060B0042u: goto L_060B0042; case 0x060B0044u: goto L_060B0044; case 0x060B0046u: goto L_060B0046; case 0x060B0048u: goto L_060B0048; case 0x060B004Au: goto L_060B004A; case 0x060B004Cu: goto L_060B004C; case 0x060B004Eu: goto L_060B004E; case 0x060B0050u: goto L_060B0050; case 0x060B0052u: goto L_060B0052; case 0x060B0054u: goto L_060B0054; case 0x060B0056u: goto L_060B0056; case 0x060B0058u: goto L_060B0058; case 0x060B005Au: goto L_060B005A; case 0x060B005Cu: goto L_060B005C; case 0x060B005Eu: goto L_060B005E; case 0x060B0060u: goto L_060B0060; case 0x060B0062u: goto L_060B0062; case 0x060B0064u: goto L_060B0064; case 0x060B0066u: goto L_060B0066; case 0x060B0068u: goto L_060B0068; case 0x060B006Au: goto L_060B006A; case 0x060B006Cu: goto L_060B006C; case 0x060B006Eu: goto L_060B006E; case 0x060B0070u: goto L_060B0070; case 0x060B0072u: goto L_060B0072; case 0x060B0076u: goto L_060B0076; case 0x060B0078u: goto L_060B0078; case 0x060B007Au: goto L_060B007A; case 0x060B007Eu: goto L_060B007E; case 0x060B0080u: goto L_060B0080; case 0x060B0084u: goto L_060B0084; case 0x060B0086u: goto L_060B0086; case 0x060B0088u: goto L_060B0088; case 0x060B008Au: goto L_060B008A; case 0x060B008Cu: goto L_060B008C; case 0x060B008Eu: goto L_060B008E; case 0x060B0090u: goto L_060B0090; case 0x060B0092u: goto L_060B0092; case 0x060B0096u: goto L_060B0096; case 0x060B00C4u: goto L_060B00C4; case 0x060B00C6u: goto L_060B00C6; case 0x060B00C8u: goto L_060B00C8; case 0x060B00CAu: goto L_060B00CA; case 0x060B00CEu: goto L_060B00CE; case 0x060B00D0u: goto L_060B00D0; case 0x060B00D2u: goto L_060B00D2; case 0x060B00D4u: goto L_060B00D4; case 0x060B00D6u: goto L_060B00D6; case 0x060B00D8u: goto L_060B00D8; case 0x060B00DAu: goto L_060B00DA; case 0x060B00DCu: goto L_060B00DC; case 0x060B00DEu: goto L_060B00DE; case 0x060B00E0u: goto L_060B00E0; case 0x060B00E2u: goto L_060B00E2; case 0x060B00E4u: goto L_060B00E4; case 0x060B00E6u: goto L_060B00E6; case 0x060B00E8u: goto L_060B00E8; case 0x060B00EAu: goto L_060B00EA; case 0x060B00ECu: goto L_060B00EC; case 0x060B00EEu: goto L_060B00EE; case 0x060B00F0u: goto L_060B00F0; case 0x060B00F2u: goto L_060B00F2; case 0x060B00F4u: goto L_060B00F4; case 0x060B00F6u: goto L_060B00F6; case 0x060B00F8u: goto L_060B00F8; case 0x060B00FAu: goto L_060B00FA; case 0x060B00FCu: goto L_060B00FC; default: sh2_call(c, x); return; } }  // 060B0092 jmp @r4 ; shll2 r2
L_060B0096:
    c.r[7] += 6; goto L_060B00C4;  // 060B0096 bra 0x060B00C4 ; add #6,r7
L_060B00C4:
    c.r[0] = ld32(c.r[15] + 16);  // 060B00C4 mov.l @(16,r15),r0
L_060B00C6:
    c.r[8] += 12;  // 060B00C6 add #12,r8
L_060B00C8:
    c.r[0] -= 1; c.t = c.r[0] == 0;  // 060B00C8 dt r0
L_060B00CA:
    { const bool k = !c.t; st32(c.r[15] + 16, c.r[0]); if (k) { SH2_POLL(c); goto L_060B0006; } }  // 060B00CA bf/s 0x060B0006 ; mov.l r0,@(16,r15)
L_060B00CE:
    c.r[0] = c.r[11];  // 060B00CE mov r11,r0
L_060B00D0:
    st32(c.gbr + 48, c.r[0]);  // 060B00D0 mov.l r0,@(48,gbr)
L_060B00D2:
    c.r[15] += 24;  // 060B00D2 add #24,r15
L_060B00D4:
    c.r[1] = ld32(c.r[15]); c.r[15] += 4;  // 060B00D4 mov.l @r15+,r1
L_060B00D6:
    c.r[2] = ld32(c.r[15]); c.r[15] += 4;  // 060B00D6 mov.l @r15+,r2
L_060B00D8:
    c.r[0] = ld32(c.gbr + 72);  // 060B00D8 mov.l @(72,gbr),r0
L_060B00DA:
    st32(c.r[0] + 8, c.r[1]);  // 060B00DA mov.l r1,@(8,r0)
L_060B00DC:
    c.r[1] = 0x28u;  // 060B00DC mov #40,r1
L_060B00DE:
    st32(c.r[0], c.r[1]);  // 060B00DE mov.l r1,@(0,r0)
L_060B00E0:
    c.r[0] += 16;  // 060B00E0 add #16,r0
L_060B00E2:
    c.r[1] = ld32(0x060B0100u);  // 060B00E2 mov.l 0x060B0100,r1
L_060B00E4:
    st32(c.gbr + 72, c.r[0]);  // 060B00E4 mov.l r0,@(72,gbr)
L_060B00E6:
    st16(c.r[1], c.r[0]);  // 060B00E6 mov.w r0,@r1
L_060B00E8:
    c.r[0] = c.r[2];  // 060B00E8 mov r2,r0
L_060B00EA:
    st32(c.gbr + 116, c.r[0]);  // 060B00EA mov.l r0,@(116,gbr)
L_060B00EC:
    c.r[0] = 0x1u;  // 060B00EC mov #1,r0
L_060B00EE:
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060B00EE mov.l @r15+,r9
L_060B00F0:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060B00F0 lds.l @r15+,pr
L_060B00F2:
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060B00F2 mov.l @r15+,r10
L_060B00F4:
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060B00F4 mov.l @r15+,r11
L_060B00F6:
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060B00F6 mov.l @r15+,r12
L_060B00F8:
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060B00F8 mov.l @r15+,r13
L_060B00FA:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060B00FA mov.l @r15+,r14
L_060B00FC:
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060B00FC rts ; mov.l @r15+,r8
}

void f_060B00A4(SH2Context& c) {
    ran[3027] = 1;
    goto L_060B00A4;
L_060B0006:
    c.mach = c.macl = 0;  // 060B0006 clrmac
L_060B0008:
    sh2_mac_l(c, 6, 7);  // 060B0008 mac.l @r7+,@r6+
L_060B000A:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[7] + 8);  // 060B000A mov.w @(8,r7),r0
L_060B000C:
    c.r[5] = c.r[15];  // 060B000C mov r15,r5
L_060B000E:
    sh2_mac_l(c, 6, 7);  // 060B000E mac.l @r7+,@r6+
L_060B0010:
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B0010 exts.w r0,r1
L_060B0012:
    c.r[1] <<= 2;  // 060B0012 shll2 r1
L_060B0014:
    sh2_mac_l(c, 6, 7);  // 060B0014 mac.l @r7+,@r6+
L_060B0016:
    c.r[6] += 4;  // 060B0016 add #4,r6
L_060B0018:
    c.r[7] -= 12;  // 060B0018 add #-12,r7
L_060B001A:
    c.r[1] <<= 2;  // 060B001A shll2 r1
L_060B001C:
    c.r[0] = c.mach;  // 060B001C sts mach,r0
L_060B001E:
    c.r[13] = c.macl;  // 060B001E sts macl,r13
L_060B0020:
    c.mach = c.macl = 0;  // 060B0020 clrmac
L_060B0022:
    sh2_mac_l(c, 6, 7);  // 060B0022 mac.l @r7+,@r6+
L_060B0024:
    c.r[13] = c.r[0] << 16 | c.r[13] >> 16;  // 060B0024 xtrct r0,r13
L_060B0026:
    st32(c.r[5], c.r[13]);  // 060B0026 mov.l r13,@(0,r5)
L_060B0028:
    sh2_mac_l(c, 6, 7);  // 060B0028 mac.l @r7+,@r6+
L_060B002A:
    c.r[1] += c.r[10];  // 060B002A add r10,r1
L_060B002C:
    c.r[4] = 0x4u;  // 060B002C mov #4,r4
L_060B002E:
    sh2_mac_l(c, 6, 7);  // 060B002E mac.l @r7+,@r6+
L_060B0030:
    c.r[6] += 4;  // 060B0030 add #4,r6
L_060B0032:
    c.r[7] -= 12;  // 060B0032 add #-12,r7
L_060B0034:
    c.r[4] += c.r[1];  // 060B0034 add r1,r4
L_060B0036:
    c.r[0] = c.mach;  // 060B0036 sts mach,r0
L_060B0038:
    c.r[2] = c.macl;  // 060B0038 sts macl,r2
L_060B003A:
    c.mach = c.macl = 0;  // 060B003A clrmac
L_060B003C:
    sh2_mac_l(c, 6, 7);  // 060B003C mac.l @r7+,@r6+
L_060B003E:
    c.r[2] = c.r[0] << 16 | c.r[2] >> 16;  // 060B003E xtrct r0,r2
L_060B0040:
    st32(c.r[5] + 4, c.r[2]);  // 060B0040 mov.l r2,@(4,r5)
L_060B0042:
    sh2_mac_l(c, 6, 7);  // 060B0042 mac.l @r7+,@r6+
L_060B0044:
    c.r[12] = (uint32_t)(int16_t)ld16(c.r[8]);  // 060B0044 mov.w @r8,r12
L_060B0046:
    c.r[9] = 0x7Fu;  // 060B0046 mov #127,r9
L_060B0048:
    sh2_mac_l(c, 6, 7);  // 060B0048 mac.l @r7+,@r6+
L_060B004A:
    c.r[6] -= 44;  // 060B004A add #-44,r6
L_060B004C:
    c.r[9] &= c.r[12];  // 060B004C and r12,r9
L_060B004E:
    c.r[9] <<= 2;  // 060B004E shll2 r9
L_060B0050:
    c.r[0] = c.mach;  // 060B0050 sts mach,r0
L_060B0052:
    c.r[3] = c.macl;  // 060B0052 sts macl,r3
L_060B0054:
    c.mach = c.macl = 0;  // 060B0054 clrmac
L_060B0056:
    sh2_mac_l(c, 5, 4);  // 060B0056 mac.l @r4+,@r5+
L_060B0058:
    c.r[3] = c.r[0] << 16 | c.r[3] >> 16;  // 060B0058 xtrct r0,r3
L_060B005A:
    c.r[0] = 0x060B0104u;  // 060B005A mova 0x060B0104,r0
L_060B005C:
    sh2_mac_l(c, 5, 4);  // 060B005C mac.l @r4+,@r5+
L_060B005E:
    st32(c.r[5], c.r[3]);  // 060B005E mov.l r3,@r5
L_060B0060:
    c.r[9] <<= 2;  // 060B0060 shll2 r9
L_060B0062:
    sh2_mac_l(c, 5, 4);  // 060B0062 mac.l @r4+,@r5+
L_060B0064:
    c.r[9] += c.r[0];  // 060B0064 add r0,r9
L_060B0066:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[8] + 10);  // 060B0066 mov.w @(10,r8),r0
L_060B0068:
    c.r[7] += 2;  // 060B0068 add #2,r7
L_060B006A:
    c.r[4] = c.mach;  // 060B006A sts mach,r4
L_060B006C:
    st16(c.r[11], c.r[0]);  // 060B006C mov.w r0,@(0,r11)
L_060B006E:
    c.r[0] = ld32(c.gbr + 896);  // 060B006E mov.l @(896,gbr),r0
L_060B0070:
    c.t = (int32_t)c.r[4] >= (int32_t)c.r[0];  // 060B0070 cmp/ge r0,r4
L_060B0072:
    { const bool k = c.t; c.r[0] = (c.r[12] & 0xFFFF0000u) | (c.r[12] & 0xFFu) << 8 | (c.r[12] >> 8 & 0xFFu); if (k) { goto L_060B007E; } }  // 060B0072 bt/s 0x060B007E ; swap.b r12,r0
L_060B0076:
    c.r[4] = ld32(c.r[9]); c.r[9] += 4;  // 060B0076 mov.l @r9+,r4
L_060B0078:
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 060B0078 mov.w @r7+,r2
L_060B007A:
    { const uint32_t x = c.r[4]; c.r[2] <<= 2; SH2_POLL(c); switch (x) { case 0x060B0006u: goto L_060B0006; case 0x060B0008u: goto L_060B0008; case 0x060B000Au: goto L_060B000A; case 0x060B000Cu: goto L_060B000C; case 0x060B000Eu: goto L_060B000E; case 0x060B0010u: goto L_060B0010; case 0x060B0012u: goto L_060B0012; case 0x060B0014u: goto L_060B0014; case 0x060B0016u: goto L_060B0016; case 0x060B0018u: goto L_060B0018; case 0x060B001Au: goto L_060B001A; case 0x060B001Cu: goto L_060B001C; case 0x060B001Eu: goto L_060B001E; case 0x060B0020u: goto L_060B0020; case 0x060B0022u: goto L_060B0022; case 0x060B0024u: goto L_060B0024; case 0x060B0026u: goto L_060B0026; case 0x060B0028u: goto L_060B0028; case 0x060B002Au: goto L_060B002A; case 0x060B002Cu: goto L_060B002C; case 0x060B002Eu: goto L_060B002E; case 0x060B0030u: goto L_060B0030; case 0x060B0032u: goto L_060B0032; case 0x060B0034u: goto L_060B0034; case 0x060B0036u: goto L_060B0036; case 0x060B0038u: goto L_060B0038; case 0x060B003Au: goto L_060B003A; case 0x060B003Cu: goto L_060B003C; case 0x060B003Eu: goto L_060B003E; case 0x060B0040u: goto L_060B0040; case 0x060B0042u: goto L_060B0042; case 0x060B0044u: goto L_060B0044; case 0x060B0046u: goto L_060B0046; case 0x060B0048u: goto L_060B0048; case 0x060B004Au: goto L_060B004A; case 0x060B004Cu: goto L_060B004C; case 0x060B004Eu: goto L_060B004E; case 0x060B0050u: goto L_060B0050; case 0x060B0052u: goto L_060B0052; case 0x060B0054u: goto L_060B0054; case 0x060B0056u: goto L_060B0056; case 0x060B0058u: goto L_060B0058; case 0x060B005Au: goto L_060B005A; case 0x060B005Cu: goto L_060B005C; case 0x060B005Eu: goto L_060B005E; case 0x060B0060u: goto L_060B0060; case 0x060B0062u: goto L_060B0062; case 0x060B0064u: goto L_060B0064; case 0x060B0066u: goto L_060B0066; case 0x060B0068u: goto L_060B0068; case 0x060B006Au: goto L_060B006A; case 0x060B006Cu: goto L_060B006C; case 0x060B006Eu: goto L_060B006E; case 0x060B0070u: goto L_060B0070; case 0x060B0072u: goto L_060B0072; case 0x060B0076u: goto L_060B0076; case 0x060B0078u: goto L_060B0078; case 0x060B007Au: goto L_060B007A; case 0x060B007Eu: goto L_060B007E; case 0x060B0080u: goto L_060B0080; case 0x060B0084u: goto L_060B0084; case 0x060B0086u: goto L_060B0086; case 0x060B0088u: goto L_060B0088; case 0x060B008Au: goto L_060B008A; case 0x060B008Cu: goto L_060B008C; case 0x060B008Eu: goto L_060B008E; case 0x060B0090u: goto L_060B0090; case 0x060B0092u: goto L_060B0092; case 0x060B0096u: goto L_060B0096; case 0x060B00A4u: goto L_060B00A4; case 0x060B00A6u: goto L_060B00A6; case 0x060B00A8u: goto L_060B00A8; case 0x060B00AAu: goto L_060B00AA; case 0x060B00ACu: goto L_060B00AC; case 0x060B00AEu: goto L_060B00AE; case 0x060B00B0u: goto L_060B00B0; case 0x060B00B2u: goto L_060B00B2; case 0x060B00B4u: goto L_060B00B4; case 0x060B00B6u: goto L_060B00B6; case 0x060B00B8u: goto L_060B00B8; case 0x060B00BAu: goto L_060B00BA; case 0x060B00BCu: goto L_060B00BC; case 0x060B00BEu: goto L_060B00BE; case 0x060B00C0u: goto L_060B00C0; case 0x060B00C2u: goto L_060B00C2; case 0x060B00C4u: goto L_060B00C4; case 0x060B00C6u: goto L_060B00C6; case 0x060B00C8u: goto L_060B00C8; case 0x060B00CAu: goto L_060B00CA; case 0x060B00CEu: goto L_060B00CE; case 0x060B00D0u: goto L_060B00D0; case 0x060B00D2u: goto L_060B00D2; case 0x060B00D4u: goto L_060B00D4; case 0x060B00D6u: goto L_060B00D6; case 0x060B00D8u: goto L_060B00D8; case 0x060B00DAu: goto L_060B00DA; case 0x060B00DCu: goto L_060B00DC; case 0x060B00DEu: goto L_060B00DE; case 0x060B00E0u: goto L_060B00E0; case 0x060B00E2u: goto L_060B00E2; case 0x060B00E4u: goto L_060B00E4; case 0x060B00E6u: goto L_060B00E6; case 0x060B00E8u: goto L_060B00E8; case 0x060B00EAu: goto L_060B00EA; case 0x060B00ECu: goto L_060B00EC; case 0x060B00EEu: goto L_060B00EE; case 0x060B00F0u: goto L_060B00F0; case 0x060B00F2u: goto L_060B00F2; case 0x060B00F4u: goto L_060B00F4; case 0x060B00F6u: goto L_060B00F6; case 0x060B00F8u: goto L_060B00F8; case 0x060B00FAu: goto L_060B00FA; case 0x060B00FCu: goto L_060B00FC; default: sh2_call(c, x); return; } }  // 060B007A jmp @r4 ; shll2 r2
L_060B007E:
    c.t = (c.r[0] & 0x1u) == 0;  // 060B007E tst #1,r0
L_060B0080:
    { const bool k = c.t; c.r[3] = 0u - c.r[3]; if (k) { goto L_060B0096; } }  // 060B0080 bt/s 0x060B0096 ; neg r3,r3
L_060B0084:
    c.r[5] -= 4; st32(c.r[5], c.r[3]);  // 060B0084 mov.l r3,@-r5
L_060B0086:
    c.r[2] = 0u - c.r[2];  // 060B0086 neg r2,r2
L_060B0088:
    c.r[5] -= 4; st32(c.r[5], c.r[2]);  // 060B0088 mov.l r2,@-r5
L_060B008A:
    c.r[13] = 0u - c.r[13];  // 060B008A neg r13,r13
L_060B008C:
    c.r[5] -= 4; st32(c.r[5], c.r[13]);  // 060B008C mov.l r13,@-r5
L_060B008E:
    c.r[4] = ld32(c.r[9]); c.r[9] += 4;  // 060B008E mov.l @r9+,r4
L_060B0090:
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 060B0090 mov.w @r7+,r2
L_060B0092:
    { const uint32_t x = c.r[4]; c.r[2] <<= 2; SH2_POLL(c); switch (x) { case 0x060B0006u: goto L_060B0006; case 0x060B0008u: goto L_060B0008; case 0x060B000Au: goto L_060B000A; case 0x060B000Cu: goto L_060B000C; case 0x060B000Eu: goto L_060B000E; case 0x060B0010u: goto L_060B0010; case 0x060B0012u: goto L_060B0012; case 0x060B0014u: goto L_060B0014; case 0x060B0016u: goto L_060B0016; case 0x060B0018u: goto L_060B0018; case 0x060B001Au: goto L_060B001A; case 0x060B001Cu: goto L_060B001C; case 0x060B001Eu: goto L_060B001E; case 0x060B0020u: goto L_060B0020; case 0x060B0022u: goto L_060B0022; case 0x060B0024u: goto L_060B0024; case 0x060B0026u: goto L_060B0026; case 0x060B0028u: goto L_060B0028; case 0x060B002Au: goto L_060B002A; case 0x060B002Cu: goto L_060B002C; case 0x060B002Eu: goto L_060B002E; case 0x060B0030u: goto L_060B0030; case 0x060B0032u: goto L_060B0032; case 0x060B0034u: goto L_060B0034; case 0x060B0036u: goto L_060B0036; case 0x060B0038u: goto L_060B0038; case 0x060B003Au: goto L_060B003A; case 0x060B003Cu: goto L_060B003C; case 0x060B003Eu: goto L_060B003E; case 0x060B0040u: goto L_060B0040; case 0x060B0042u: goto L_060B0042; case 0x060B0044u: goto L_060B0044; case 0x060B0046u: goto L_060B0046; case 0x060B0048u: goto L_060B0048; case 0x060B004Au: goto L_060B004A; case 0x060B004Cu: goto L_060B004C; case 0x060B004Eu: goto L_060B004E; case 0x060B0050u: goto L_060B0050; case 0x060B0052u: goto L_060B0052; case 0x060B0054u: goto L_060B0054; case 0x060B0056u: goto L_060B0056; case 0x060B0058u: goto L_060B0058; case 0x060B005Au: goto L_060B005A; case 0x060B005Cu: goto L_060B005C; case 0x060B005Eu: goto L_060B005E; case 0x060B0060u: goto L_060B0060; case 0x060B0062u: goto L_060B0062; case 0x060B0064u: goto L_060B0064; case 0x060B0066u: goto L_060B0066; case 0x060B0068u: goto L_060B0068; case 0x060B006Au: goto L_060B006A; case 0x060B006Cu: goto L_060B006C; case 0x060B006Eu: goto L_060B006E; case 0x060B0070u: goto L_060B0070; case 0x060B0072u: goto L_060B0072; case 0x060B0076u: goto L_060B0076; case 0x060B0078u: goto L_060B0078; case 0x060B007Au: goto L_060B007A; case 0x060B007Eu: goto L_060B007E; case 0x060B0080u: goto L_060B0080; case 0x060B0084u: goto L_060B0084; case 0x060B0086u: goto L_060B0086; case 0x060B0088u: goto L_060B0088; case 0x060B008Au: goto L_060B008A; case 0x060B008Cu: goto L_060B008C; case 0x060B008Eu: goto L_060B008E; case 0x060B0090u: goto L_060B0090; case 0x060B0092u: goto L_060B0092; case 0x060B0096u: goto L_060B0096; case 0x060B00A4u: goto L_060B00A4; case 0x060B00A6u: goto L_060B00A6; case 0x060B00A8u: goto L_060B00A8; case 0x060B00AAu: goto L_060B00AA; case 0x060B00ACu: goto L_060B00AC; case 0x060B00AEu: goto L_060B00AE; case 0x060B00B0u: goto L_060B00B0; case 0x060B00B2u: goto L_060B00B2; case 0x060B00B4u: goto L_060B00B4; case 0x060B00B6u: goto L_060B00B6; case 0x060B00B8u: goto L_060B00B8; case 0x060B00BAu: goto L_060B00BA; case 0x060B00BCu: goto L_060B00BC; case 0x060B00BEu: goto L_060B00BE; case 0x060B00C0u: goto L_060B00C0; case 0x060B00C2u: goto L_060B00C2; case 0x060B00C4u: goto L_060B00C4; case 0x060B00C6u: goto L_060B00C6; case 0x060B00C8u: goto L_060B00C8; case 0x060B00CAu: goto L_060B00CA; case 0x060B00CEu: goto L_060B00CE; case 0x060B00D0u: goto L_060B00D0; case 0x060B00D2u: goto L_060B00D2; case 0x060B00D4u: goto L_060B00D4; case 0x060B00D6u: goto L_060B00D6; case 0x060B00D8u: goto L_060B00D8; case 0x060B00DAu: goto L_060B00DA; case 0x060B00DCu: goto L_060B00DC; case 0x060B00DEu: goto L_060B00DE; case 0x060B00E0u: goto L_060B00E0; case 0x060B00E2u: goto L_060B00E2; case 0x060B00E4u: goto L_060B00E4; case 0x060B00E6u: goto L_060B00E6; case 0x060B00E8u: goto L_060B00E8; case 0x060B00EAu: goto L_060B00EA; case 0x060B00ECu: goto L_060B00EC; case 0x060B00EEu: goto L_060B00EE; case 0x060B00F0u: goto L_060B00F0; case 0x060B00F2u: goto L_060B00F2; case 0x060B00F4u: goto L_060B00F4; case 0x060B00F6u: goto L_060B00F6; case 0x060B00F8u: goto L_060B00F8; case 0x060B00FAu: goto L_060B00FA; case 0x060B00FCu: goto L_060B00FC; default: sh2_call(c, x); return; } }  // 060B0092 jmp @r4 ; shll2 r2
L_060B0096:
    c.r[7] += 6; goto L_060B00C4;  // 060B0096 bra 0x060B00C4 ; add #6,r7
L_060B00A4:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[8] + 2);  // 060B00A4 mov.w @(2,r8),r0
L_060B00A6:
    c.r[5] = ld32(c.r[15] + 20);  // 060B00A6 mov.l @(20,r15),r5
L_060B00A8:
    c.r[0] <<= 2;  // 060B00A8 shll2 r0
L_060B00AA:
    c.r[0] += c.r[0];  // 060B00AA add r0,r0
L_060B00AC:
    c.r[0] = ld32(c.r[0] + c.r[5]);  // 060B00AC mov.l @(r0,r5),r0
L_060B00AE:
    st32(c.r[11] + 8, c.r[0]);  // 060B00AE mov.l r0,@(8,r11)
L_060B00B0:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[8] + 8);  // 060B00B0 mov.w @(8,r8),r0
L_060B00B2:
    c.r[5] = ld32(c.r[8] + 4);  // 060B00B2 mov.l @(4,r8),r5
L_060B00B4:
    st16(c.r[11] + 28, c.r[0]);  // 060B00B4 mov.w r0,@(28,r11)
L_060B00B6:
    st32(c.r[11] + 4, c.r[5]);  // 060B00B6 mov.l r5,@(4,r11)
L_060B00B8:
    c.r[0] = c.r[14];  // 060B00B8 mov r14,r0
L_060B00BA:
    st16(c.r[11] + 30, c.r[0]);  // 060B00BA mov.w r0,@(30,r11)
L_060B00BC:
    c.r[0] = ld32(c.r[15] + 24);  // 060B00BC mov.l @(24,r15),r0
L_060B00BE:
    c.r[11] -= 36;  // 060B00BE add #-36,r11
L_060B00C0:
    c.r[0] += 1;  // 060B00C0 add #1,r0
L_060B00C2:
    st32(c.r[15] + 24, c.r[0]);  // 060B00C2 mov.l r0,@(24,r15)
L_060B00C4:
    c.r[0] = ld32(c.r[15] + 16);  // 060B00C4 mov.l @(16,r15),r0
L_060B00C6:
    c.r[8] += 12;  // 060B00C6 add #12,r8
L_060B00C8:
    c.r[0] -= 1; c.t = c.r[0] == 0;  // 060B00C8 dt r0
L_060B00CA:
    { const bool k = !c.t; st32(c.r[15] + 16, c.r[0]); if (k) { SH2_POLL(c); goto L_060B0006; } }  // 060B00CA bf/s 0x060B0006 ; mov.l r0,@(16,r15)
L_060B00CE:
    c.r[0] = c.r[11];  // 060B00CE mov r11,r0
L_060B00D0:
    st32(c.gbr + 48, c.r[0]);  // 060B00D0 mov.l r0,@(48,gbr)
L_060B00D2:
    c.r[15] += 24;  // 060B00D2 add #24,r15
L_060B00D4:
    c.r[1] = ld32(c.r[15]); c.r[15] += 4;  // 060B00D4 mov.l @r15+,r1
L_060B00D6:
    c.r[2] = ld32(c.r[15]); c.r[15] += 4;  // 060B00D6 mov.l @r15+,r2
L_060B00D8:
    c.r[0] = ld32(c.gbr + 72);  // 060B00D8 mov.l @(72,gbr),r0
L_060B00DA:
    st32(c.r[0] + 8, c.r[1]);  // 060B00DA mov.l r1,@(8,r0)
L_060B00DC:
    c.r[1] = 0x28u;  // 060B00DC mov #40,r1
L_060B00DE:
    st32(c.r[0], c.r[1]);  // 060B00DE mov.l r1,@(0,r0)
L_060B00E0:
    c.r[0] += 16;  // 060B00E0 add #16,r0
L_060B00E2:
    c.r[1] = ld32(0x060B0100u);  // 060B00E2 mov.l 0x060B0100,r1
L_060B00E4:
    st32(c.gbr + 72, c.r[0]);  // 060B00E4 mov.l r0,@(72,gbr)
L_060B00E6:
    st16(c.r[1], c.r[0]);  // 060B00E6 mov.w r0,@r1
L_060B00E8:
    c.r[0] = c.r[2];  // 060B00E8 mov r2,r0
L_060B00EA:
    st32(c.gbr + 116, c.r[0]);  // 060B00EA mov.l r0,@(116,gbr)
L_060B00EC:
    c.r[0] = 0x1u;  // 060B00EC mov #1,r0
L_060B00EE:
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060B00EE mov.l @r15+,r9
L_060B00F0:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060B00F0 lds.l @r15+,pr
L_060B00F2:
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060B00F2 mov.l @r15+,r10
L_060B00F4:
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060B00F4 mov.l @r15+,r11
L_060B00F6:
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060B00F6 mov.l @r15+,r12
L_060B00F8:
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060B00F8 mov.l @r15+,r13
L_060B00FA:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060B00FA mov.l @r15+,r14
L_060B00FC:
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060B00FC rts ; mov.l @r15+,r8
}

void f_060B00B0(SH2Context& c) {
    ran[3028] = 1;
    goto L_060B00B0;
L_060B0006:
    c.mach = c.macl = 0;  // 060B0006 clrmac
L_060B0008:
    sh2_mac_l(c, 6, 7);  // 060B0008 mac.l @r7+,@r6+
L_060B000A:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[7] + 8);  // 060B000A mov.w @(8,r7),r0
L_060B000C:
    c.r[5] = c.r[15];  // 060B000C mov r15,r5
L_060B000E:
    sh2_mac_l(c, 6, 7);  // 060B000E mac.l @r7+,@r6+
L_060B0010:
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B0010 exts.w r0,r1
L_060B0012:
    c.r[1] <<= 2;  // 060B0012 shll2 r1
L_060B0014:
    sh2_mac_l(c, 6, 7);  // 060B0014 mac.l @r7+,@r6+
L_060B0016:
    c.r[6] += 4;  // 060B0016 add #4,r6
L_060B0018:
    c.r[7] -= 12;  // 060B0018 add #-12,r7
L_060B001A:
    c.r[1] <<= 2;  // 060B001A shll2 r1
L_060B001C:
    c.r[0] = c.mach;  // 060B001C sts mach,r0
L_060B001E:
    c.r[13] = c.macl;  // 060B001E sts macl,r13
L_060B0020:
    c.mach = c.macl = 0;  // 060B0020 clrmac
L_060B0022:
    sh2_mac_l(c, 6, 7);  // 060B0022 mac.l @r7+,@r6+
L_060B0024:
    c.r[13] = c.r[0] << 16 | c.r[13] >> 16;  // 060B0024 xtrct r0,r13
L_060B0026:
    st32(c.r[5], c.r[13]);  // 060B0026 mov.l r13,@(0,r5)
L_060B0028:
    sh2_mac_l(c, 6, 7);  // 060B0028 mac.l @r7+,@r6+
L_060B002A:
    c.r[1] += c.r[10];  // 060B002A add r10,r1
L_060B002C:
    c.r[4] = 0x4u;  // 060B002C mov #4,r4
L_060B002E:
    sh2_mac_l(c, 6, 7);  // 060B002E mac.l @r7+,@r6+
L_060B0030:
    c.r[6] += 4;  // 060B0030 add #4,r6
L_060B0032:
    c.r[7] -= 12;  // 060B0032 add #-12,r7
L_060B0034:
    c.r[4] += c.r[1];  // 060B0034 add r1,r4
L_060B0036:
    c.r[0] = c.mach;  // 060B0036 sts mach,r0
L_060B0038:
    c.r[2] = c.macl;  // 060B0038 sts macl,r2
L_060B003A:
    c.mach = c.macl = 0;  // 060B003A clrmac
L_060B003C:
    sh2_mac_l(c, 6, 7);  // 060B003C mac.l @r7+,@r6+
L_060B003E:
    c.r[2] = c.r[0] << 16 | c.r[2] >> 16;  // 060B003E xtrct r0,r2
L_060B0040:
    st32(c.r[5] + 4, c.r[2]);  // 060B0040 mov.l r2,@(4,r5)
L_060B0042:
    sh2_mac_l(c, 6, 7);  // 060B0042 mac.l @r7+,@r6+
L_060B0044:
    c.r[12] = (uint32_t)(int16_t)ld16(c.r[8]);  // 060B0044 mov.w @r8,r12
L_060B0046:
    c.r[9] = 0x7Fu;  // 060B0046 mov #127,r9
L_060B0048:
    sh2_mac_l(c, 6, 7);  // 060B0048 mac.l @r7+,@r6+
L_060B004A:
    c.r[6] -= 44;  // 060B004A add #-44,r6
L_060B004C:
    c.r[9] &= c.r[12];  // 060B004C and r12,r9
L_060B004E:
    c.r[9] <<= 2;  // 060B004E shll2 r9
L_060B0050:
    c.r[0] = c.mach;  // 060B0050 sts mach,r0
L_060B0052:
    c.r[3] = c.macl;  // 060B0052 sts macl,r3
L_060B0054:
    c.mach = c.macl = 0;  // 060B0054 clrmac
L_060B0056:
    sh2_mac_l(c, 5, 4);  // 060B0056 mac.l @r4+,@r5+
L_060B0058:
    c.r[3] = c.r[0] << 16 | c.r[3] >> 16;  // 060B0058 xtrct r0,r3
L_060B005A:
    c.r[0] = 0x060B0104u;  // 060B005A mova 0x060B0104,r0
L_060B005C:
    sh2_mac_l(c, 5, 4);  // 060B005C mac.l @r4+,@r5+
L_060B005E:
    st32(c.r[5], c.r[3]);  // 060B005E mov.l r3,@r5
L_060B0060:
    c.r[9] <<= 2;  // 060B0060 shll2 r9
L_060B0062:
    sh2_mac_l(c, 5, 4);  // 060B0062 mac.l @r4+,@r5+
L_060B0064:
    c.r[9] += c.r[0];  // 060B0064 add r0,r9
L_060B0066:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[8] + 10);  // 060B0066 mov.w @(10,r8),r0
L_060B0068:
    c.r[7] += 2;  // 060B0068 add #2,r7
L_060B006A:
    c.r[4] = c.mach;  // 060B006A sts mach,r4
L_060B006C:
    st16(c.r[11], c.r[0]);  // 060B006C mov.w r0,@(0,r11)
L_060B006E:
    c.r[0] = ld32(c.gbr + 896);  // 060B006E mov.l @(896,gbr),r0
L_060B0070:
    c.t = (int32_t)c.r[4] >= (int32_t)c.r[0];  // 060B0070 cmp/ge r0,r4
L_060B0072:
    { const bool k = c.t; c.r[0] = (c.r[12] & 0xFFFF0000u) | (c.r[12] & 0xFFu) << 8 | (c.r[12] >> 8 & 0xFFu); if (k) { goto L_060B007E; } }  // 060B0072 bt/s 0x060B007E ; swap.b r12,r0
L_060B0076:
    c.r[4] = ld32(c.r[9]); c.r[9] += 4;  // 060B0076 mov.l @r9+,r4
L_060B0078:
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 060B0078 mov.w @r7+,r2
L_060B007A:
    { const uint32_t x = c.r[4]; c.r[2] <<= 2; SH2_POLL(c); switch (x) { case 0x060B0006u: goto L_060B0006; case 0x060B0008u: goto L_060B0008; case 0x060B000Au: goto L_060B000A; case 0x060B000Cu: goto L_060B000C; case 0x060B000Eu: goto L_060B000E; case 0x060B0010u: goto L_060B0010; case 0x060B0012u: goto L_060B0012; case 0x060B0014u: goto L_060B0014; case 0x060B0016u: goto L_060B0016; case 0x060B0018u: goto L_060B0018; case 0x060B001Au: goto L_060B001A; case 0x060B001Cu: goto L_060B001C; case 0x060B001Eu: goto L_060B001E; case 0x060B0020u: goto L_060B0020; case 0x060B0022u: goto L_060B0022; case 0x060B0024u: goto L_060B0024; case 0x060B0026u: goto L_060B0026; case 0x060B0028u: goto L_060B0028; case 0x060B002Au: goto L_060B002A; case 0x060B002Cu: goto L_060B002C; case 0x060B002Eu: goto L_060B002E; case 0x060B0030u: goto L_060B0030; case 0x060B0032u: goto L_060B0032; case 0x060B0034u: goto L_060B0034; case 0x060B0036u: goto L_060B0036; case 0x060B0038u: goto L_060B0038; case 0x060B003Au: goto L_060B003A; case 0x060B003Cu: goto L_060B003C; case 0x060B003Eu: goto L_060B003E; case 0x060B0040u: goto L_060B0040; case 0x060B0042u: goto L_060B0042; case 0x060B0044u: goto L_060B0044; case 0x060B0046u: goto L_060B0046; case 0x060B0048u: goto L_060B0048; case 0x060B004Au: goto L_060B004A; case 0x060B004Cu: goto L_060B004C; case 0x060B004Eu: goto L_060B004E; case 0x060B0050u: goto L_060B0050; case 0x060B0052u: goto L_060B0052; case 0x060B0054u: goto L_060B0054; case 0x060B0056u: goto L_060B0056; case 0x060B0058u: goto L_060B0058; case 0x060B005Au: goto L_060B005A; case 0x060B005Cu: goto L_060B005C; case 0x060B005Eu: goto L_060B005E; case 0x060B0060u: goto L_060B0060; case 0x060B0062u: goto L_060B0062; case 0x060B0064u: goto L_060B0064; case 0x060B0066u: goto L_060B0066; case 0x060B0068u: goto L_060B0068; case 0x060B006Au: goto L_060B006A; case 0x060B006Cu: goto L_060B006C; case 0x060B006Eu: goto L_060B006E; case 0x060B0070u: goto L_060B0070; case 0x060B0072u: goto L_060B0072; case 0x060B0076u: goto L_060B0076; case 0x060B0078u: goto L_060B0078; case 0x060B007Au: goto L_060B007A; case 0x060B007Eu: goto L_060B007E; case 0x060B0080u: goto L_060B0080; case 0x060B0084u: goto L_060B0084; case 0x060B0086u: goto L_060B0086; case 0x060B0088u: goto L_060B0088; case 0x060B008Au: goto L_060B008A; case 0x060B008Cu: goto L_060B008C; case 0x060B008Eu: goto L_060B008E; case 0x060B0090u: goto L_060B0090; case 0x060B0092u: goto L_060B0092; case 0x060B0096u: goto L_060B0096; case 0x060B00B0u: goto L_060B00B0; case 0x060B00B2u: goto L_060B00B2; case 0x060B00B4u: goto L_060B00B4; case 0x060B00B6u: goto L_060B00B6; case 0x060B00B8u: goto L_060B00B8; case 0x060B00BAu: goto L_060B00BA; case 0x060B00BCu: goto L_060B00BC; case 0x060B00BEu: goto L_060B00BE; case 0x060B00C0u: goto L_060B00C0; case 0x060B00C2u: goto L_060B00C2; case 0x060B00C4u: goto L_060B00C4; case 0x060B00C6u: goto L_060B00C6; case 0x060B00C8u: goto L_060B00C8; case 0x060B00CAu: goto L_060B00CA; case 0x060B00CEu: goto L_060B00CE; case 0x060B00D0u: goto L_060B00D0; case 0x060B00D2u: goto L_060B00D2; case 0x060B00D4u: goto L_060B00D4; case 0x060B00D6u: goto L_060B00D6; case 0x060B00D8u: goto L_060B00D8; case 0x060B00DAu: goto L_060B00DA; case 0x060B00DCu: goto L_060B00DC; case 0x060B00DEu: goto L_060B00DE; case 0x060B00E0u: goto L_060B00E0; case 0x060B00E2u: goto L_060B00E2; case 0x060B00E4u: goto L_060B00E4; case 0x060B00E6u: goto L_060B00E6; case 0x060B00E8u: goto L_060B00E8; case 0x060B00EAu: goto L_060B00EA; case 0x060B00ECu: goto L_060B00EC; case 0x060B00EEu: goto L_060B00EE; case 0x060B00F0u: goto L_060B00F0; case 0x060B00F2u: goto L_060B00F2; case 0x060B00F4u: goto L_060B00F4; case 0x060B00F6u: goto L_060B00F6; case 0x060B00F8u: goto L_060B00F8; case 0x060B00FAu: goto L_060B00FA; case 0x060B00FCu: goto L_060B00FC; default: sh2_call(c, x); return; } }  // 060B007A jmp @r4 ; shll2 r2
L_060B007E:
    c.t = (c.r[0] & 0x1u) == 0;  // 060B007E tst #1,r0
L_060B0080:
    { const bool k = c.t; c.r[3] = 0u - c.r[3]; if (k) { goto L_060B0096; } }  // 060B0080 bt/s 0x060B0096 ; neg r3,r3
L_060B0084:
    c.r[5] -= 4; st32(c.r[5], c.r[3]);  // 060B0084 mov.l r3,@-r5
L_060B0086:
    c.r[2] = 0u - c.r[2];  // 060B0086 neg r2,r2
L_060B0088:
    c.r[5] -= 4; st32(c.r[5], c.r[2]);  // 060B0088 mov.l r2,@-r5
L_060B008A:
    c.r[13] = 0u - c.r[13];  // 060B008A neg r13,r13
L_060B008C:
    c.r[5] -= 4; st32(c.r[5], c.r[13]);  // 060B008C mov.l r13,@-r5
L_060B008E:
    c.r[4] = ld32(c.r[9]); c.r[9] += 4;  // 060B008E mov.l @r9+,r4
L_060B0090:
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 060B0090 mov.w @r7+,r2
L_060B0092:
    { const uint32_t x = c.r[4]; c.r[2] <<= 2; SH2_POLL(c); switch (x) { case 0x060B0006u: goto L_060B0006; case 0x060B0008u: goto L_060B0008; case 0x060B000Au: goto L_060B000A; case 0x060B000Cu: goto L_060B000C; case 0x060B000Eu: goto L_060B000E; case 0x060B0010u: goto L_060B0010; case 0x060B0012u: goto L_060B0012; case 0x060B0014u: goto L_060B0014; case 0x060B0016u: goto L_060B0016; case 0x060B0018u: goto L_060B0018; case 0x060B001Au: goto L_060B001A; case 0x060B001Cu: goto L_060B001C; case 0x060B001Eu: goto L_060B001E; case 0x060B0020u: goto L_060B0020; case 0x060B0022u: goto L_060B0022; case 0x060B0024u: goto L_060B0024; case 0x060B0026u: goto L_060B0026; case 0x060B0028u: goto L_060B0028; case 0x060B002Au: goto L_060B002A; case 0x060B002Cu: goto L_060B002C; case 0x060B002Eu: goto L_060B002E; case 0x060B0030u: goto L_060B0030; case 0x060B0032u: goto L_060B0032; case 0x060B0034u: goto L_060B0034; case 0x060B0036u: goto L_060B0036; case 0x060B0038u: goto L_060B0038; case 0x060B003Au: goto L_060B003A; case 0x060B003Cu: goto L_060B003C; case 0x060B003Eu: goto L_060B003E; case 0x060B0040u: goto L_060B0040; case 0x060B0042u: goto L_060B0042; case 0x060B0044u: goto L_060B0044; case 0x060B0046u: goto L_060B0046; case 0x060B0048u: goto L_060B0048; case 0x060B004Au: goto L_060B004A; case 0x060B004Cu: goto L_060B004C; case 0x060B004Eu: goto L_060B004E; case 0x060B0050u: goto L_060B0050; case 0x060B0052u: goto L_060B0052; case 0x060B0054u: goto L_060B0054; case 0x060B0056u: goto L_060B0056; case 0x060B0058u: goto L_060B0058; case 0x060B005Au: goto L_060B005A; case 0x060B005Cu: goto L_060B005C; case 0x060B005Eu: goto L_060B005E; case 0x060B0060u: goto L_060B0060; case 0x060B0062u: goto L_060B0062; case 0x060B0064u: goto L_060B0064; case 0x060B0066u: goto L_060B0066; case 0x060B0068u: goto L_060B0068; case 0x060B006Au: goto L_060B006A; case 0x060B006Cu: goto L_060B006C; case 0x060B006Eu: goto L_060B006E; case 0x060B0070u: goto L_060B0070; case 0x060B0072u: goto L_060B0072; case 0x060B0076u: goto L_060B0076; case 0x060B0078u: goto L_060B0078; case 0x060B007Au: goto L_060B007A; case 0x060B007Eu: goto L_060B007E; case 0x060B0080u: goto L_060B0080; case 0x060B0084u: goto L_060B0084; case 0x060B0086u: goto L_060B0086; case 0x060B0088u: goto L_060B0088; case 0x060B008Au: goto L_060B008A; case 0x060B008Cu: goto L_060B008C; case 0x060B008Eu: goto L_060B008E; case 0x060B0090u: goto L_060B0090; case 0x060B0092u: goto L_060B0092; case 0x060B0096u: goto L_060B0096; case 0x060B00B0u: goto L_060B00B0; case 0x060B00B2u: goto L_060B00B2; case 0x060B00B4u: goto L_060B00B4; case 0x060B00B6u: goto L_060B00B6; case 0x060B00B8u: goto L_060B00B8; case 0x060B00BAu: goto L_060B00BA; case 0x060B00BCu: goto L_060B00BC; case 0x060B00BEu: goto L_060B00BE; case 0x060B00C0u: goto L_060B00C0; case 0x060B00C2u: goto L_060B00C2; case 0x060B00C4u: goto L_060B00C4; case 0x060B00C6u: goto L_060B00C6; case 0x060B00C8u: goto L_060B00C8; case 0x060B00CAu: goto L_060B00CA; case 0x060B00CEu: goto L_060B00CE; case 0x060B00D0u: goto L_060B00D0; case 0x060B00D2u: goto L_060B00D2; case 0x060B00D4u: goto L_060B00D4; case 0x060B00D6u: goto L_060B00D6; case 0x060B00D8u: goto L_060B00D8; case 0x060B00DAu: goto L_060B00DA; case 0x060B00DCu: goto L_060B00DC; case 0x060B00DEu: goto L_060B00DE; case 0x060B00E0u: goto L_060B00E0; case 0x060B00E2u: goto L_060B00E2; case 0x060B00E4u: goto L_060B00E4; case 0x060B00E6u: goto L_060B00E6; case 0x060B00E8u: goto L_060B00E8; case 0x060B00EAu: goto L_060B00EA; case 0x060B00ECu: goto L_060B00EC; case 0x060B00EEu: goto L_060B00EE; case 0x060B00F0u: goto L_060B00F0; case 0x060B00F2u: goto L_060B00F2; case 0x060B00F4u: goto L_060B00F4; case 0x060B00F6u: goto L_060B00F6; case 0x060B00F8u: goto L_060B00F8; case 0x060B00FAu: goto L_060B00FA; case 0x060B00FCu: goto L_060B00FC; default: sh2_call(c, x); return; } }  // 060B0092 jmp @r4 ; shll2 r2
L_060B0096:
    c.r[7] += 6; goto L_060B00C4;  // 060B0096 bra 0x060B00C4 ; add #6,r7
L_060B00B0:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[8] + 8);  // 060B00B0 mov.w @(8,r8),r0
L_060B00B2:
    c.r[5] = ld32(c.r[8] + 4);  // 060B00B2 mov.l @(4,r8),r5
L_060B00B4:
    st16(c.r[11] + 28, c.r[0]);  // 060B00B4 mov.w r0,@(28,r11)
L_060B00B6:
    st32(c.r[11] + 4, c.r[5]);  // 060B00B6 mov.l r5,@(4,r11)
L_060B00B8:
    c.r[0] = c.r[14];  // 060B00B8 mov r14,r0
L_060B00BA:
    st16(c.r[11] + 30, c.r[0]);  // 060B00BA mov.w r0,@(30,r11)
L_060B00BC:
    c.r[0] = ld32(c.r[15] + 24);  // 060B00BC mov.l @(24,r15),r0
L_060B00BE:
    c.r[11] -= 36;  // 060B00BE add #-36,r11
L_060B00C0:
    c.r[0] += 1;  // 060B00C0 add #1,r0
L_060B00C2:
    st32(c.r[15] + 24, c.r[0]);  // 060B00C2 mov.l r0,@(24,r15)
L_060B00C4:
    c.r[0] = ld32(c.r[15] + 16);  // 060B00C4 mov.l @(16,r15),r0
L_060B00C6:
    c.r[8] += 12;  // 060B00C6 add #12,r8
L_060B00C8:
    c.r[0] -= 1; c.t = c.r[0] == 0;  // 060B00C8 dt r0
L_060B00CA:
    { const bool k = !c.t; st32(c.r[15] + 16, c.r[0]); if (k) { SH2_POLL(c); goto L_060B0006; } }  // 060B00CA bf/s 0x060B0006 ; mov.l r0,@(16,r15)
L_060B00CE:
    c.r[0] = c.r[11];  // 060B00CE mov r11,r0
L_060B00D0:
    st32(c.gbr + 48, c.r[0]);  // 060B00D0 mov.l r0,@(48,gbr)
L_060B00D2:
    c.r[15] += 24;  // 060B00D2 add #24,r15
L_060B00D4:
    c.r[1] = ld32(c.r[15]); c.r[15] += 4;  // 060B00D4 mov.l @r15+,r1
L_060B00D6:
    c.r[2] = ld32(c.r[15]); c.r[15] += 4;  // 060B00D6 mov.l @r15+,r2
L_060B00D8:
    c.r[0] = ld32(c.gbr + 72);  // 060B00D8 mov.l @(72,gbr),r0
L_060B00DA:
    st32(c.r[0] + 8, c.r[1]);  // 060B00DA mov.l r1,@(8,r0)
L_060B00DC:
    c.r[1] = 0x28u;  // 060B00DC mov #40,r1
L_060B00DE:
    st32(c.r[0], c.r[1]);  // 060B00DE mov.l r1,@(0,r0)
L_060B00E0:
    c.r[0] += 16;  // 060B00E0 add #16,r0
L_060B00E2:
    c.r[1] = ld32(0x060B0100u);  // 060B00E2 mov.l 0x060B0100,r1
L_060B00E4:
    st32(c.gbr + 72, c.r[0]);  // 060B00E4 mov.l r0,@(72,gbr)
L_060B00E6:
    st16(c.r[1], c.r[0]);  // 060B00E6 mov.w r0,@r1
L_060B00E8:
    c.r[0] = c.r[2];  // 060B00E8 mov r2,r0
L_060B00EA:
    st32(c.gbr + 116, c.r[0]);  // 060B00EA mov.l r0,@(116,gbr)
L_060B00EC:
    c.r[0] = 0x1u;  // 060B00EC mov #1,r0
L_060B00EE:
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060B00EE mov.l @r15+,r9
L_060B00F0:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060B00F0 lds.l @r15+,pr
L_060B00F2:
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060B00F2 mov.l @r15+,r10
L_060B00F4:
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060B00F4 mov.l @r15+,r11
L_060B00F6:
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060B00F6 mov.l @r15+,r12
L_060B00F8:
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060B00F8 mov.l @r15+,r13
L_060B00FA:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060B00FA mov.l @r15+,r14
L_060B00FC:
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060B00FC rts ; mov.l @r15+,r8
}

}  // namespace p_srwfin_installed
