#include "p_srwfin_installed_funcs.h"

namespace p_srwfin_installed {

void f_06064C54(SH2Context& c) {
    ran[1489] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06064C54 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06064C56 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06064C58 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06064C5A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06064C5C mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06064C5E mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06064C60 mov.l r14,@-r15
    c.r[15] -= 4;  // 06064C62 add #-4,r15
    c.r[1] = ld32(0x06064DD4u);  // 06064C64 mov.l 0x06064DD4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06064C66 mov.b @r1,r1
    c.r[2] = 0x1u;  // 06064C68 mov #1,r2
    c.r[1] -= 4;  // 06064C6A add #-4,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06064C6C extu.b r1,r1
    c.t = c.r[1] > c.r[2];  // 06064C6E cmp/hi r2,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06064C80; } }  // 06064C70 bt/s 0x06064C80 ; mov r15,r14
    c.r[1] = ld32(0x06064DD8u);  // 06064C74 mov.l 0x06064DD8,r1
    c.r[1] = ld32(c.r[1]);  // 06064C76 mov.l @r1,r1
    c.r[1] += 9;  // 06064C78 add #9,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06064C7A mov.b @r1,r1
    c.r[0] = c.r[1]; goto L_06064C8E;  // 06064C7C bra 0x06064C8E ; mov r1,r0
L_06064C80:
    c.r[1] = ld32(0x06064DD8u);  // 06064C80 mov.l 0x06064DD8,r1
    c.r[1] = ld32(c.r[1]);  // 06064C82 mov.l @r1,r1
    c.r[1] += 9;  // 06064C84 add #9,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06064C86 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06064C88 mov r1,r0
    c.r[0] >>= 2;  // 06064C8A shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06064C8C shlr r0
L_06064C8E:
    c.r[0] &= 0x3u;  // 06064C8E and #3,r0
    st32(c.r[14], c.r[0]);  // 06064C90 mov.l r0,@r14
    c.r[1] = ld32(0x06064DD4u);  // 06064C92 mov.l 0x06064DD4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06064C94 mov.b @r1,r1
    c.r[2] = 0x1u;  // 06064C96 mov #1,r2
    c.r[0] = ld32(c.r[14]);  // 06064C98 mov.l @r14,r0
    c.r[1] -= 4;  // 06064C9A add #-4,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06064C9C extu.b r1,r1
    c.t = c.r[2] >= c.r[1];  // 06064C9E cmp/hs r1,r2
    c.r[12] = c.t;  // 06064CA0 movt r12
    c.t = c.r[0] == 0x1u;  // 06064CA2 cmp/eq #1,r0
    { const bool k = c.t; c.r[10] = 0x0u; if (k) { goto L_06064CB4; } }  // 06064CA4 bt/s 0x06064CB4 ; mov #0,r10
    c.t = c.r[0] == 0x2u;  // 06064CA8 cmp/eq #2,r0
    if (c.t) { goto L_06064CB0; }  // 06064CAA bt 0x06064CB0
    goto L_06064F5C;  // 06064CAC bra 0x06064F5C ; nop
L_06064CB0:
    goto L_06064DE8;  // 06064CB0 bra 0x06064DE8 ; nop
L_06064CB4:
    c.r[3] = ld32(0x06064DDCu);  // 06064CB4 mov.l 0x06064DDC,r3
    c.r[1] = ld32(c.r[3]);  // 06064CB6 mov.l @r3,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06064DD0u);  // 06064CB8 mov.w 0x06064DD0,r2
    c.r[0] = c.r[1];  // 06064CBA mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06064CBC mov.b @(r0,r2),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06064CBE extu.b r1,r1
    c.r[1] -= 1;  // 06064CC0 add #-1,r1
    c.t = (int32_t)c.r[10] >= (int32_t)c.r[1];  // 06064CC2 cmp/ge r1,r10
    { const bool k = !c.t; c.r[9] = c.r[3]; if (k) { goto L_06064CCC; } }  // 06064CC4 bf/s 0x06064CCC ; mov r3,r9
    goto L_060650E0;  // 06064CC8 bra 0x060650E0 ; nop
L_06064CCC:
    c.r[11] = 0x1Eu;  // 06064CCC mov #30,r11
L_06064CCE:
    c.r[0] = ld32(c.r[9]);  // 06064CCE mov.l @r9,r0
    c.r[8] = c.r[10];  // 06064CD0 mov r10,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06064CD2 mov.b @(r0,r2),r1
    c.r[8] += 1;  // 06064CD4 add #1,r8
    c.r[1] = c.r[1] & 0xFFu;  // 06064CD6 extu.b r1,r1
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 06064CD8 cmp/ge r1,r8
    if (c.t) { goto L_06064DB6; }  // 06064CDA bt 0x06064DB6
    c.r[6] = c.r[10];  // 06064CDC mov r10,r6
    c.r[6] += c.r[6];  // 06064CDE add r6,r6
L_06064CE0:
    c.r[2] = ld32(c.r[9]);  // 06064CE0 mov.l @r9,r2
    c.r[1] = c.r[2];  // 06064CE2 mov r2,r1
    c.r[1] += c.r[6];  // 06064CE4 add r6,r1
    c.r[1] += 1;  // 06064CE6 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06064CE8 mov.b @r1,r1
    c.r[4] = c.r[1] & 0xFFu;  // 06064CEA extu.b r1,r4
    c.r[1] = c.r[8];  // 06064CEC mov r8,r1
    c.r[1] += c.r[1];  // 06064CEE add r1,r1
    c.r[2] += c.r[1];  // 06064CF0 add r1,r2
    c.r[2] += 1;  // 06064CF2 add #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06064CF4 mov.b @r2,r1
    c.t = (c.r[12] & c.r[12]) == 0;  // 06064CF6 tst r12,r12
    { const bool k = !c.t; c.r[5] = c.r[1] & 0xFFu; if (k) { goto L_06064D10; } }  // 06064CF8 bf/s 0x06064D10 ; extu.b r1,r5
    c.r[1] = ld32(0x06064DE0u);  // 06064CFC mov.l 0x06064DE0,r1
    c.r[2] = c.r[4];  // 06064CFE mov r4,r2
    c.r[1] = ld32(c.r[1]);  // 06064D00 mov.l @r1,r1
    c.r[2] <<= 2;  // 06064D02 shll2 r2
    c.r[2] <<= 2;  // 06064D04 shll2 r2
    c.r[2] += c.r[1];  // 06064D06 add r1,r2
    c.r[2] += 2;  // 06064D08 add #2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06064D0A mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu; goto L_06064D12;  // 06064D0C bra 0x06064D12 ; extu.b r1,r1
L_06064D10:
    c.r[1] = c.r[4];  // 06064D10 mov r4,r1
L_06064D12:
    c.t = (c.r[12] & c.r[12]) == 0;  // 06064D12 tst r12,r12
    { const bool k = !c.t; st32(c.r[14], c.r[1]); if (k) { goto L_06064D2C; } }  // 06064D14 bf/s 0x06064D2C ; mov.l r1,@r14
    c.r[1] = ld32(0x06064DE0u);  // 06064D18 mov.l 0x06064DE0,r1
    c.r[2] = c.r[5];  // 06064D1A mov r5,r2
    c.r[1] = ld32(c.r[1]);  // 06064D1C mov.l @r1,r1
    c.r[2] <<= 2;  // 06064D1E shll2 r2
    c.r[2] <<= 2;  // 06064D20 shll2 r2
    c.r[2] += c.r[1];  // 06064D22 add r1,r2
    c.r[2] += 2;  // 06064D24 add #2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06064D26 mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu; goto L_06064D2E;  // 06064D28 bra 0x06064D2E ; extu.b r1,r1
L_06064D2C:
    c.r[1] = c.r[5];  // 06064D2C mov r5,r1
L_06064D2E:
    c.r[0] = ld32(c.r[14]);  // 06064D2E mov.l @r14,r0
    c.r[3] = c.r[1];  // 06064D30 mov r1,r3
    c.macl = c.r[0] * c.r[11];  // 06064D32 mul.l r11,r0
    c.r[1] = ld32(0x06064DE4u);  // 06064D34 mov.l 0x06064DE4,r1
    c.r[1] = ld32(c.r[1]);  // 06064D36 mov.l @r1,r1
    c.r[2] = c.macl;  // 06064D38 sts macl,r2
    c.r[2] += c.r[1];  // 06064D3A add r1,r2
    c.macl = c.r[3] * c.r[11];  // 06064D3C mul.l r11,r3
    c.r[2] += 22;  // 06064D3E add #22,r2
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06064D40 mov.w @r2,r2
    c.r[3] = c.macl;  // 06064D42 sts macl,r3
    c.r[3] += c.r[1];  // 06064D44 add r1,r3
    c.r[3] += 22;  // 06064D46 add #22,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06064D48 mov.w @r3,r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 06064D4A extu.w r2,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 06064D4C extu.w r1,r1
    c.t = c.r[2] >= c.r[1];  // 06064D4E cmp/hs r1,r2
    if (c.t) { goto L_06064DA6; }  // 06064D50 bt 0x06064DA6
    c.r[1] = ld32(c.r[9]);  // 06064D52 mov.l @r9,r1
    c.r[0] = c.r[1];  // 06064D54 mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 06064D56 mov.b @(r0,r6),r2
    c.r[3] = c.r[8];  // 06064D58 mov r8,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x06064DD2u);  // 06064D5A mov.w 0x06064DD2,r0
    c.r[2] &= c.r[0];  // 06064D5C and r0,r2
    c.r[0] = c.r[1];  // 06064D5E mov r1,r0
    st8(c.r[0] + c.r[6], c.r[2]);  // 06064D60 mov.b r2,@(r0,r6)
    c.r[1] += c.r[6];  // 06064D62 add r6,r1
    c.r[1] += 1;  // 06064D64 add #1,r1
    st8(c.r[1], c.r[5]);  // 06064D66 mov.b r5,@r1
    c.r[1] = ld32(c.r[9]);  // 06064D68 mov.l @r9,r1
    c.r[3] += c.r[3];  // 06064D6A add r3,r3
    c.r[0] = c.r[1];  // 06064D6C mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06064D6E mov.b @(r0,r3),r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06064DD2u);  // 06064D70 mov.w 0x06064DD2,r0
    c.r[2] &= c.r[0];  // 06064D72 and r0,r2
    c.r[0] = c.r[1];  // 06064D74 mov r1,r0
    st8(c.r[0] + c.r[3], c.r[2]);  // 06064D76 mov.b r2,@(r0,r3)
    c.r[1] += c.r[3];  // 06064D78 add r3,r1
    c.r[1] += 1;  // 06064D7A add #1,r1
    st8(c.r[1], c.r[4]);  // 06064D7C mov.b r4,@r1
    c.r[1] = ld32(c.r[9]);  // 06064D7E mov.l @r9,r1
    c.r[0] = c.r[1];  // 06064D80 mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06064D82 mov.b @(r0,r3),r2
    c.r[5] = (uint32_t)(int16_t)ld16(0x06064DD2u);  // 06064D84 mov.w 0x06064DD2,r5
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 06064D86 mov.b @(r0,r6),r7
    c.r[5] &= c.r[2];  // 06064D88 and r2,r5
    c.r[2] = 0x7Fu;  // 06064D8A mov #127,r2
    c.r[2] &= c.r[7];  // 06064D8C and r7,r2
    c.r[2] |= c.r[5];  // 06064D8E or r5,r2
    st8(c.r[0] + c.r[6], c.r[2]);  // 06064D90 mov.b r2,@(r0,r6)
    c.r[2] = (uint32_t)(int16_t)ld16(0x06064DD2u);  // 06064D92 mov.w 0x06064DD2,r2
    c.r[1] = ld32(c.r[9]);  // 06064D94 mov.l @r9,r1
    c.r[2] &= c.r[7];  // 06064D96 and r7,r2
    c.r[0] = c.r[1];  // 06064D98 mov r1,r0
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06064D9A mov.b @(r0,r3),r7
    c.r[0] = 0x7Fu;  // 06064D9C mov #127,r0
    c.r[7] &= c.r[0];  // 06064D9E and r0,r7
    c.r[7] |= c.r[2];  // 06064DA0 or r2,r7
    c.r[0] = c.r[1];  // 06064DA2 mov r1,r0
    st8(c.r[0] + c.r[3], c.r[7]);  // 06064DA4 mov.b r7,@(r0,r3)
L_06064DA6:
    c.r[1] = ld32(0x06064DDCu);  // 06064DA6 mov.l 0x06064DDC,r1
    c.r[1] = ld32(c.r[1]);  // 06064DA8 mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06064DD0u);  // 06064DAA mov.w 0x06064DD0,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06064DAC mov.b @(r0,r1),r1
    c.r[8] += 1;  // 06064DAE add #1,r8
    c.r[1] = c.r[1] & 0xFFu;  // 06064DB0 extu.b r1,r1
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 06064DB2 cmp/ge r1,r8
    if (!c.t) { SH2_POLL(c); goto L_06064CE0; }  // 06064DB4 bf 0x06064CE0
L_06064DB6:
    c.r[3] = ld32(0x06064DDCu);  // 06064DB6 mov.l 0x06064DDC,r3
    c.r[1] = ld32(c.r[3]);  // 06064DB8 mov.l @r3,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06064DD0u);  // 06064DBA mov.w 0x06064DD0,r2
    c.r[0] = c.r[1];  // 06064DBC mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06064DBE mov.b @(r0,r2),r1
    c.r[10] += 1;  // 06064DC0 add #1,r10
    c.r[1] = c.r[1] & 0xFFu;  // 06064DC2 extu.b r1,r1
    c.r[1] -= 1;  // 06064DC4 add #-1,r1
    c.t = (int32_t)c.r[10] >= (int32_t)c.r[1];  // 06064DC6 cmp/ge r1,r10
    if (!c.t) { SH2_POLL(c); goto L_06064CCE; }  // 06064DC8 bf 0x06064CCE
    c.r[14] += 4;  // 06064DCA add #4,r14
    c.r[15] = c.r[14]; goto L_060650E4;  // 06064DCC bra 0x060650E4 ; mov r14,r15
L_06064DE8:
    c.r[2] = ld32(0x06064F4Cu);  // 06064DE8 mov.l 0x06064F4C,r2
    c.r[1] = ld32(c.r[2]);  // 06064DEA mov.l @r2,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x06064F48u);  // 06064DEC mov.w 0x06064F48,r3
    c.r[0] = c.r[1];  // 06064DEE mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06064DF0 mov.b @(r0,r3),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06064DF2 extu.b r1,r1
    c.r[1] -= 1;  // 06064DF4 add #-1,r1
    c.t = (int32_t)c.r[10] >= (int32_t)c.r[1];  // 06064DF6 cmp/ge r1,r10
    { const bool k = !c.t; c.r[9] = c.r[2]; if (k) { goto L_06064E00; } }  // 06064DF8 bf/s 0x06064E00 ; mov r2,r9
    goto L_060650E0;  // 06064DFC bra 0x060650E0 ; nop
L_06064E00:
    c.r[13] = ld32(0x06064F50u);  // 06064E00 mov.l 0x06064F50,r13
    c.r[11] = 0x1Eu;  // 06064E02 mov #30,r11
L_06064E04:
    c.r[0] = ld32(c.r[9]);  // 06064E04 mov.l @r9,r0
    c.r[8] = c.r[10];  // 06064E06 mov r10,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06064E08 mov.b @(r0,r3),r1
    c.r[8] += 1;  // 06064E0A add #1,r8
    c.r[1] = c.r[1] & 0xFFu;  // 06064E0C extu.b r1,r1
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 06064E0E cmp/ge r1,r8
    if (!c.t) { goto L_06064E16; }  // 06064E10 bf 0x06064E16
    goto L_06064F2A;  // 06064E12 bra 0x06064F2A ; nop
L_06064E16:
    c.r[6] = c.r[10];  // 06064E16 mov r10,r6
    c.r[6] += c.r[6];  // 06064E18 add r6,r6
L_06064E1A:
    c.r[2] = ld32(c.r[9]);  // 06064E1A mov.l @r9,r2
    c.r[1] = c.r[2];  // 06064E1C mov r2,r1
    c.r[1] += c.r[6];  // 06064E1E add r6,r1
    c.r[1] += 1;  // 06064E20 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06064E22 mov.b @r1,r1
    c.r[4] = c.r[1] & 0xFFu;  // 06064E24 extu.b r1,r4
    c.r[1] = c.r[8];  // 06064E26 mov r8,r1
    c.r[1] += c.r[1];  // 06064E28 add r1,r1
    c.r[2] += c.r[1];  // 06064E2A add r1,r2
    c.r[2] += 1;  // 06064E2C add #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06064E2E mov.b @r2,r1
    c.t = (c.r[12] & c.r[12]) == 0;  // 06064E30 tst r12,r12
    { const bool k = c.t; c.r[5] = c.r[1] & 0xFFu; if (k) { goto L_06064E44; } }  // 06064E32 bt/s 0x06064E44 ; extu.b r1,r5
    c.macl = c.r[4] * c.r[11];  // 06064E36 mul.l r11,r4
    c.r[1] = ld32(c.r[13]);  // 06064E38 mov.l @r13,r1
    c.r[2] = c.macl;  // 06064E3A sts macl,r2
    c.r[2] += c.r[1];  // 06064E3C add r1,r2
    c.r[2] += 15;  // 06064E3E add #15,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]); goto L_06064E62;  // 06064E40 bra 0x06064E62 ; mov.b @r2,r1
L_06064E44:
    c.r[1] = ld32(0x06064F54u);  // 06064E44 mov.l 0x06064F54,r1
    c.r[2] = c.r[4];  // 06064E46 mov r4,r2
    c.r[1] = ld32(c.r[1]);  // 06064E48 mov.l @r1,r1
    c.r[2] <<= 2;  // 06064E4A shll2 r2
    c.r[2] <<= 2;  // 06064E4C shll2 r2
    c.r[2] += c.r[1];  // 06064E4E add r1,r2
    c.r[2] += 2;  // 06064E50 add #2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06064E52 mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06064E54 extu.b r1,r1
    c.macl = c.r[1] * c.r[11];  // 06064E56 mul.l r11,r1
    c.r[2] = ld32(c.r[13]);  // 06064E58 mov.l @r13,r2
    c.r[1] = c.macl;  // 06064E5A sts macl,r1
    c.r[1] += c.r[2];  // 06064E5C add r2,r1
    c.r[1] += 15;  // 06064E5E add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06064E60 mov.b @r1,r1
L_06064E62:
    c.r[1] = c.r[1] & 0xFFu;  // 06064E62 extu.b r1,r1
    c.t = (c.r[12] & c.r[12]) == 0;  // 06064E64 tst r12,r12
    { const bool k = c.t; st32(c.r[14], c.r[1]); if (k) { goto L_06064E78; } }  // 06064E66 bt/s 0x06064E78 ; mov.l r1,@r14
    c.macl = c.r[5] * c.r[11];  // 06064E6A mul.l r11,r5
    c.r[1] = ld32(c.r[13]);  // 06064E6C mov.l @r13,r1
    c.r[2] = c.macl;  // 06064E6E sts macl,r2
    c.r[2] += c.r[1];  // 06064E70 add r1,r2
    c.r[2] += 15;  // 06064E72 add #15,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]); goto L_06064E96;  // 06064E74 bra 0x06064E96 ; mov.b @r2,r1
L_06064E78:
    c.r[1] = ld32(0x06064F54u);  // 06064E78 mov.l 0x06064F54,r1
    c.r[2] = c.r[5];  // 06064E7A mov r5,r2
    c.r[1] = ld32(c.r[1]);  // 06064E7C mov.l @r1,r1
    c.r[2] <<= 2;  // 06064E7E shll2 r2
    c.r[2] <<= 2;  // 06064E80 shll2 r2
    c.r[2] += c.r[1];  // 06064E82 add r1,r2
    c.r[2] += 2;  // 06064E84 add #2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06064E86 mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06064E88 extu.b r1,r1
    c.macl = c.r[1] * c.r[11];  // 06064E8A mul.l r11,r1
    c.r[2] = ld32(c.r[13]);  // 06064E8C mov.l @r13,r2
    c.r[1] = c.macl;  // 06064E8E sts macl,r1
    c.r[1] += c.r[2];  // 06064E90 add r2,r1
    c.r[1] += 15;  // 06064E92 add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06064E94 mov.b @r1,r1
L_06064E96:
    c.r[7] = c.r[1] & 0xFFu;  // 06064E96 extu.b r1,r7
    c.r[1] = ld32(0x06064F58u);  // 06064E98 mov.l 0x06064F58,r1
    c.r[3] = c.r[7];  // 06064E9A mov r7,r3
    c.r[1] = ld32(c.r[1]);  // 06064E9C mov.l @r1,r1
    c.r[3] += c.r[3];  // 06064E9E add r3,r3
    c.r[2] = ld32(c.r[14]);  // 06064EA0 mov.l @r14,r2
    c.r[3] += c.r[7];  // 06064EA2 add r7,r3
    c.r[0] = ld32(c.r[14]);  // 06064EA4 mov.l @r14,r0
    c.r[2] += c.r[2];  // 06064EA6 add r2,r2
    c.r[2] += c.r[0];  // 06064EA8 add r0,r2
    c.r[2] <<= 2;  // 06064EAA shll2 r2
    c.r[2] += c.r[1];  // 06064EAC add r1,r2
    c.r[2] += 9;  // 06064EAE add #9,r2
    c.r[3] <<= 2;  // 06064EB0 shll2 r3
    c.r[3] += c.r[1];  // 06064EB2 add r1,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06064EB4 mov.b @r2,r2
    c.r[3] += 9;  // 06064EB6 add #9,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06064EB8 mov.b @r3,r1
    c.r[2] = c.r[2] & 0xFFu;  // 06064EBA extu.b r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06064EBC extu.b r1,r1
    c.t = c.r[2] >= c.r[1];  // 06064EBE cmp/hs r1,r2
    if (c.t) { goto L_06064F16; }  // 06064EC0 bt 0x06064F16
    c.r[1] = ld32(c.r[9]);  // 06064EC2 mov.l @r9,r1
    c.r[0] = c.r[1];  // 06064EC4 mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 06064EC6 mov.b @(r0,r6),r2
    c.r[3] = c.r[8];  // 06064EC8 mov r8,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x06064F4Au);  // 06064ECA mov.w 0x06064F4A,r0
    c.r[2] &= c.r[0];  // 06064ECC and r0,r2
    c.r[0] = c.r[1];  // 06064ECE mov r1,r0
    st8(c.r[0] + c.r[6], c.r[2]);  // 06064ED0 mov.b r2,@(r0,r6)
    c.r[1] += c.r[6];  // 06064ED2 add r6,r1
    c.r[1] += 1;  // 06064ED4 add #1,r1
    st8(c.r[1], c.r[5]);  // 06064ED6 mov.b r5,@r1
    c.r[1] = ld32(c.r[9]);  // 06064ED8 mov.l @r9,r1
    c.r[3] += c.r[3];  // 06064EDA add r3,r3
    c.r[0] = c.r[1];  // 06064EDC mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06064EDE mov.b @(r0,r3),r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06064F4Au);  // 06064EE0 mov.w 0x06064F4A,r0
    c.r[2] &= c.r[0];  // 06064EE2 and r0,r2
    c.r[0] = c.r[1];  // 06064EE4 mov r1,r0
    st8(c.r[0] + c.r[3], c.r[2]);  // 06064EE6 mov.b r2,@(r0,r3)
    c.r[1] += c.r[3];  // 06064EE8 add r3,r1
    c.r[1] += 1;  // 06064EEA add #1,r1
    st8(c.r[1], c.r[4]);  // 06064EEC mov.b r4,@r1
    c.r[1] = ld32(c.r[9]);  // 06064EEE mov.l @r9,r1
    c.r[0] = c.r[1];  // 06064EF0 mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06064EF2 mov.b @(r0,r3),r2
    c.r[5] = (uint32_t)(int16_t)ld16(0x06064F4Au);  // 06064EF4 mov.w 0x06064F4A,r5
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 06064EF6 mov.b @(r0,r6),r7
    c.r[5] &= c.r[2];  // 06064EF8 and r2,r5
    c.r[2] = 0x7Fu;  // 06064EFA mov #127,r2
    c.r[2] &= c.r[7];  // 06064EFC and r7,r2
    c.r[2] |= c.r[5];  // 06064EFE or r5,r2
    st8(c.r[0] + c.r[6], c.r[2]);  // 06064F00 mov.b r2,@(r0,r6)
    c.r[2] = (uint32_t)(int16_t)ld16(0x06064F4Au);  // 06064F02 mov.w 0x06064F4A,r2
    c.r[1] = ld32(c.r[9]);  // 06064F04 mov.l @r9,r1
    c.r[2] &= c.r[7];  // 06064F06 and r7,r2
    c.r[0] = c.r[1];  // 06064F08 mov r1,r0
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06064F0A mov.b @(r0,r3),r7
    c.r[0] = 0x7Fu;  // 06064F0C mov #127,r0
    c.r[7] &= c.r[0];  // 06064F0E and r0,r7
    c.r[7] |= c.r[2];  // 06064F10 or r2,r7
    c.r[0] = c.r[1];  // 06064F12 mov r1,r0
    st8(c.r[0] + c.r[3], c.r[7]);  // 06064F14 mov.b r7,@(r0,r3)
L_06064F16:
    c.r[1] = ld32(0x06064F4Cu);  // 06064F16 mov.l 0x06064F4C,r1
    c.r[1] = ld32(c.r[1]);  // 06064F18 mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06064F48u);  // 06064F1A mov.w 0x06064F48,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06064F1C mov.b @(r0,r1),r1
    c.r[8] += 1;  // 06064F1E add #1,r8
    c.r[1] = c.r[1] & 0xFFu;  // 06064F20 extu.b r1,r1
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 06064F22 cmp/ge r1,r8
    if (c.t) { goto L_06064F2A; }  // 06064F24 bt 0x06064F2A
    SH2_POLL(c); goto L_06064E1A;  // 06064F26 bra 0x06064E1A ; nop
L_06064F2A:
    c.r[2] = ld32(0x06064F4Cu);  // 06064F2A mov.l 0x06064F4C,r2
    c.r[1] = ld32(c.r[2]);  // 06064F2C mov.l @r2,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x06064F48u);  // 06064F2E mov.w 0x06064F48,r3
    c.r[0] = c.r[1];  // 06064F30 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06064F32 mov.b @(r0,r3),r1
    c.r[10] += 1;  // 06064F34 add #1,r10
    c.r[1] = c.r[1] & 0xFFu;  // 06064F36 extu.b r1,r1
    c.r[1] -= 1;  // 06064F38 add #-1,r1
    c.t = (int32_t)c.r[10] >= (int32_t)c.r[1];  // 06064F3A cmp/ge r1,r10
    if (c.t) { goto L_06064F42; }  // 06064F3C bt 0x06064F42
    SH2_POLL(c); goto L_06064E04;  // 06064F3E bra 0x06064E04 ; nop
L_06064F42:
    c.r[14] += 4;  // 06064F42 add #4,r14
    c.r[15] = c.r[14]; goto L_060650E4;  // 06064F44 bra 0x060650E4 ; mov r14,r15
L_06064F5C:
    c.r[2] = ld32(0x06064FF4u);  // 06064F5C mov.l 0x06064FF4,r2
    c.r[1] = ld32(c.r[2]);  // 06064F5E mov.l @r2,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x06064FF0u);  // 06064F60 mov.w 0x06064FF0,r3
    c.r[0] = c.r[1];  // 06064F62 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06064F64 mov.b @(r0,r3),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06064F66 extu.b r1,r1
    c.r[1] -= 1;  // 06064F68 add #-1,r1
    c.t = (int32_t)c.r[10] >= (int32_t)c.r[1];  // 06064F6A cmp/ge r1,r10
    { const bool k = !c.t; c.r[11] = c.r[2]; if (k) { goto L_06064F74; } }  // 06064F6C bf/s 0x06064F74 ; mov r2,r11
    goto L_060650E0;  // 06064F70 bra 0x060650E0 ; nop
L_06064F74:
    c.r[13] = 0x1Eu;  // 06064F74 mov #30,r13
L_06064F76:
    c.r[0] = ld32(c.r[11]);  // 06064F76 mov.l @r11,r0
    c.r[8] = c.r[10];  // 06064F78 mov r10,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06064F7A mov.b @(r0,r3),r1
    c.r[8] += 1;  // 06064F7C add #1,r8
    c.r[1] = c.r[1] & 0xFFu;  // 06064F7E extu.b r1,r1
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 06064F80 cmp/ge r1,r8
    if (!c.t) { goto L_06064F88; }  // 06064F82 bf 0x06064F88
    goto L_060650C8;  // 06064F84 bra 0x060650C8 ; nop
L_06064F88:
    c.r[9] = c.r[10];  // 06064F88 mov r10,r9
    c.r[9] += c.r[9];  // 06064F8A add r9,r9
L_06064F8C:
    c.r[2] = ld32(c.r[11]);  // 06064F8C mov.l @r11,r2
    c.r[1] = c.r[2];  // 06064F8E mov r2,r1
    c.r[1] += c.r[9];  // 06064F90 add r9,r1
    c.r[1] += 1;  // 06064F92 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06064F94 mov.b @r1,r1
    c.r[4] = c.r[1] & 0xFFu;  // 06064F96 extu.b r1,r4
    c.r[1] = c.r[8];  // 06064F98 mov r8,r1
    c.r[1] += c.r[1];  // 06064F9A add r1,r1
    c.r[2] += c.r[1];  // 06064F9C add r1,r2
    c.r[2] += 1;  // 06064F9E add #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06064FA0 mov.b @r2,r1
    c.t = (c.r[12] & c.r[12]) == 0;  // 06064FA2 tst r12,r12
    { const bool k = c.t; c.r[5] = c.r[1] & 0xFFu; if (k) { goto L_06064FB8; } }  // 06064FA4 bt/s 0x06064FB8 ; extu.b r1,r5
    c.r[0] = ld32(0x06064FF8u);  // 06064FA8 mov.l 0x06064FF8,r0
    c.macl = c.r[4] * c.r[13];  // 06064FAA mul.l r13,r4
    c.r[1] = ld32(c.r[0]);  // 06064FAC mov.l @r0,r1
    c.r[2] = c.macl;  // 06064FAE sts macl,r2
    c.r[2] += c.r[1];  // 06064FB0 add r1,r2
    c.r[2] += 15;  // 06064FB2 add #15,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]); goto L_06064FD8;  // 06064FB4 bra 0x06064FD8 ; mov.b @r2,r1
L_06064FB8:
    c.r[1] = ld32(0x06064FFCu);  // 06064FB8 mov.l 0x06064FFC,r1
    c.r[2] = c.r[4];  // 06064FBA mov r4,r2
    c.r[1] = ld32(c.r[1]);  // 06064FBC mov.l @r1,r1
    c.r[2] <<= 2;  // 06064FBE shll2 r2
    c.r[2] <<= 2;  // 06064FC0 shll2 r2
    c.r[2] += c.r[1];  // 06064FC2 add r1,r2
    c.r[2] += 2;  // 06064FC4 add #2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06064FC6 mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06064FC8 extu.b r1,r1
    c.macl = c.r[1] * c.r[13];  // 06064FCA mul.l r13,r1
    c.r[0] = ld32(0x06064FF8u);  // 06064FCC mov.l 0x06064FF8,r0
    c.r[2] = ld32(c.r[0]);  // 06064FCE mov.l @r0,r2
    c.r[1] = c.macl;  // 06064FD0 sts macl,r1
    c.r[1] += c.r[2];  // 06064FD2 add r2,r1
    c.r[1] += 15;  // 06064FD4 add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06064FD6 mov.b @r1,r1
L_06064FD8:
    c.r[1] = c.r[1] & 0xFFu;  // 06064FD8 extu.b r1,r1
    c.t = (c.r[12] & c.r[12]) == 0;  // 06064FDA tst r12,r12
    { const bool k = c.t; st32(c.r[14], c.r[1]); if (k) { goto L_06065000; } }  // 06064FDC bt/s 0x06065000 ; mov.l r1,@r14
    c.r[0] = ld32(0x06064FF8u);  // 06064FE0 mov.l 0x06064FF8,r0
    c.macl = c.r[5] * c.r[13];  // 06064FE2 mul.l r13,r5
    c.r[1] = ld32(c.r[0]);  // 06064FE4 mov.l @r0,r1
    c.r[2] = c.macl;  // 06064FE6 sts macl,r2
    c.r[2] += c.r[1];  // 06064FE8 add r1,r2
    c.r[2] += 15;  // 06064FEA add #15,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]); goto L_06065020;  // 06064FEC bra 0x06065020 ; mov.b @r2,r1
L_06065000:
    c.r[1] = ld32(0x060650FCu);  // 06065000 mov.l 0x060650FC,r1
    c.r[2] = c.r[5];  // 06065002 mov r5,r2
    c.r[1] = ld32(c.r[1]);  // 06065004 mov.l @r1,r1
    c.r[2] <<= 2;  // 06065006 shll2 r2
    c.r[2] <<= 2;  // 06065008 shll2 r2
    c.r[2] += c.r[1];  // 0606500A add r1,r2
    c.r[2] += 2;  // 0606500C add #2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606500E mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06065010 extu.b r1,r1
    c.macl = c.r[1] * c.r[13];  // 06065012 mul.l r13,r1
    c.r[0] = ld32(0x06065100u);  // 06065014 mov.l 0x06065100,r0
    c.r[2] = ld32(c.r[0]);  // 06065016 mov.l @r0,r2
    c.r[1] = c.macl;  // 06065018 sts macl,r1
    c.r[1] += c.r[2];  // 0606501A add r2,r1
    c.r[1] += 15;  // 0606501C add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606501E mov.b @r1,r1
L_06065020:
    c.r[3] = c.r[1] & 0xFFu;  // 06065020 extu.b r1,r3
    c.r[1] = ld32(0x06065104u);  // 06065022 mov.l 0x06065104,r1
    c.r[7] = c.r[3];  // 06065024 mov r3,r7
    c.r[1] = ld32(c.r[1]);  // 06065026 mov.l @r1,r1
    c.r[7] += c.r[7];  // 06065028 add r7,r7
    c.r[6] = ld32(c.r[14]);  // 0606502A mov.l @r14,r6
    c.r[7] += c.r[3];  // 0606502C add r3,r7
    c.r[0] = ld32(c.r[14]);  // 0606502E mov.l @r14,r0
    c.r[6] += c.r[6];  // 06065030 add r6,r6
    c.r[6] += c.r[0];  // 06065032 add r0,r6
    c.r[6] <<= 2;  // 06065034 shll2 r6
    c.r[6] += c.r[1];  // 06065036 add r1,r6
    c.r[2] = c.r[6];  // 06065038 mov r6,r2
    c.r[2] += 2;  // 0606503A add #2,r2
    c.r[7] <<= 2;  // 0606503C shll2 r7
    c.r[7] += c.r[1];  // 0606503E add r1,r7
    c.r[1] = c.r[7];  // 06065040 mov r7,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06065042 mov.b @r2,r2
    c.r[1] += 2;  // 06065044 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06065046 mov.b @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 06065048 extu.b r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0606504A extu.b r1,r1
    c.t = c.r[2] >= c.r[1];  // 0606504C cmp/hs r1,r2
    { const bool k = !c.t; c.t = c.r[2] == c.r[1]; if (k) { goto L_06065060; } }  // 0606504E bf/s 0x06065060 ; cmp/eq r1,r2
    { const bool k = !c.t; c.r[6] += 4; if (k) { goto L_060650B4; } }  // 06065052 bf/s 0x060650B4 ; add #4,r6
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[6]);  // 06065056 mov.w @r6,r2
    c.r[7] += 4;  // 06065058 add #4,r7
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[7]);  // 0606505A mov.w @r7,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0606505C cmp/gt r1,r2
    if (!c.t) { goto L_060650B4; }  // 0606505E bf 0x060650B4
L_06065060:
    c.r[1] = ld32(c.r[11]);  // 06065060 mov.l @r11,r1
    c.r[0] = c.r[1];  // 06065062 mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 06065064 mov.b @(r0,r9),r2
    c.r[3] = c.r[8];  // 06065066 mov r8,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x060650F6u);  // 06065068 mov.w 0x060650F6,r0
    c.r[2] &= c.r[0];  // 0606506A and r0,r2
    c.r[0] = c.r[1];  // 0606506C mov r1,r0
    st8(c.r[0] + c.r[9], c.r[2]);  // 0606506E mov.b r2,@(r0,r9)
    c.r[1] += c.r[9];  // 06065070 add r9,r1
    c.r[1] += 1;  // 06065072 add #1,r1
    st8(c.r[1], c.r[5]);  // 06065074 mov.b r5,@r1
    c.r[1] = ld32(c.r[11]);  // 06065076 mov.l @r11,r1
    c.r[3] += c.r[3];  // 06065078 add r3,r3
    c.r[0] = c.r[1];  // 0606507A mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0606507C mov.b @(r0,r3),r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x060650F6u);  // 0606507E mov.w 0x060650F6,r0
    c.r[2] &= c.r[0];  // 06065080 and r0,r2
    c.r[0] = c.r[1];  // 06065082 mov r1,r0
    st8(c.r[0] + c.r[3], c.r[2]);  // 06065084 mov.b r2,@(r0,r3)
    c.r[1] += c.r[3];  // 06065086 add r3,r1
    c.r[1] += 1;  // 06065088 add #1,r1
    st8(c.r[1], c.r[4]);  // 0606508A mov.b r4,@r1
    c.r[1] = ld32(c.r[11]);  // 0606508C mov.l @r11,r1
    c.r[0] = c.r[1];  // 0606508E mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06065090 mov.b @(r0,r3),r2
    c.r[6] = (uint32_t)(int16_t)ld16(0x060650F6u);  // 06065092 mov.w 0x060650F6,r6
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 06065094 mov.b @(r0,r9),r7
    c.r[6] &= c.r[2];  // 06065096 and r2,r6
    c.r[2] = 0x7Fu;  // 06065098 mov #127,r2
    c.r[2] &= c.r[7];  // 0606509A and r7,r2
    c.r[2] |= c.r[6];  // 0606509C or r6,r2
    st8(c.r[0] + c.r[9], c.r[2]);  // 0606509E mov.b r2,@(r0,r9)
    c.r[2] = (uint32_t)(int16_t)ld16(0x060650F6u);  // 060650A0 mov.w 0x060650F6,r2
    c.r[1] = ld32(c.r[11]);  // 060650A2 mov.l @r11,r1
    c.r[2] &= c.r[7];  // 060650A4 and r7,r2
    c.r[0] = c.r[1];  // 060650A6 mov r1,r0
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 060650A8 mov.b @(r0,r3),r7
    c.r[0] = 0x7Fu;  // 060650AA mov #127,r0
    c.r[7] &= c.r[0];  // 060650AC and r0,r7
    c.r[7] |= c.r[2];  // 060650AE or r2,r7
    c.r[0] = c.r[1];  // 060650B0 mov r1,r0
    st8(c.r[0] + c.r[3], c.r[7]);  // 060650B2 mov.b r7,@(r0,r3)
L_060650B4:
    c.r[1] = ld32(0x06065108u);  // 060650B4 mov.l 0x06065108,r1
    c.r[1] = ld32(c.r[1]);  // 060650B6 mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060650F8u);  // 060650B8 mov.w 0x060650F8,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060650BA mov.b @(r0,r1),r1
    c.r[8] += 1;  // 060650BC add #1,r8
    c.r[1] = c.r[1] & 0xFFu;  // 060650BE extu.b r1,r1
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 060650C0 cmp/ge r1,r8
    if (c.t) { goto L_060650C8; }  // 060650C2 bt 0x060650C8
    SH2_POLL(c); goto L_06064F8C;  // 060650C4 bra 0x06064F8C ; nop
L_060650C8:
    c.r[2] = ld32(0x06065108u);  // 060650C8 mov.l 0x06065108,r2
    c.r[1] = ld32(c.r[2]);  // 060650CA mov.l @r2,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x060650F8u);  // 060650CC mov.w 0x060650F8,r3
    c.r[0] = c.r[1];  // 060650CE mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 060650D0 mov.b @(r0,r3),r1
    c.r[10] += 1;  // 060650D2 add #1,r10
    c.r[1] = c.r[1] & 0xFFu;  // 060650D4 extu.b r1,r1
    c.r[1] -= 1;  // 060650D6 add #-1,r1
    c.t = (int32_t)c.r[10] >= (int32_t)c.r[1];  // 060650D8 cmp/ge r1,r10
    if (c.t) { goto L_060650E0; }  // 060650DA bt 0x060650E0
    SH2_POLL(c); goto L_06064F76;  // 060650DC bra 0x06064F76 ; nop
L_060650E0:
    c.r[14] += 4;  // 060650E0 add #4,r14
    c.r[15] = c.r[14];  // 060650E2 mov r14,r15
L_060650E4:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060650E4 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060650E6 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060650E8 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060650EA mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060650EC mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060650EE mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x060650FAu);  // 060650F0 mov.w 0x060650FA,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060650F2 rts ; mov.l @r15+,r8
}

void f_0606510C(SH2Context& c) {
    ran[1490] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0606510C mov.l r14,@-r15
    c.r[1] = ld32(0x06065218u);  // 0606510E mov.l 0x06065218,r1
    c.r[1] = ld32(c.r[1]);  // 06065110 mov.l @r1,r1
    c.r[1] += 1;  // 06065112 add #1,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06065114 mov.b @r1,r0
    c.r[14] = c.r[15];  // 06065116 mov r15,r14
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606520Au);  // 06065118 mov.w 0x0606520A,r1
    c.r[1] &= c.r[0];  // 0606511A and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606511C tst r1,r1
    { const bool k = c.t; c.r[0] &= 0xFu; if (k) { goto L_060651A0; } }  // 0606511E bt/s 0x060651A0 ; and #15,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06065122 tst r0,r0
    if (c.t) { goto L_06065160; }  // 06065124 bt 0x06065160
    c.r[2] = ld32(0x0606521Cu);  // 06065126 mov.l 0x0606521C,r2
    c.r[1] = ld32(c.r[2]);  // 06065128 mov.l @r2,r1
    c.r[1] += 9;  // 0606512A add #9,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606512C mov.b @r1,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x0606520Cu);  // 0606512E mov.w 0x0606520C,r7
    c.r[0] = c.r[3];  // 06065130 mov r3,r0
    c.r[0] >>= 2;  // 06065132 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06065134 shlr r0
    c.r[0] &= 0x3u;  // 06065136 and #3,r0
    c.r[0] += 1;  // 06065138 add #1,r0
    c.r[0] &= 0x3u;  // 0606513A and #3,r0
    c.r[0] <<= 2;  // 0606513C shll2 r0
    c.r[0] += c.r[0];  // 0606513E add r0,r0
    c.r[3] &= c.r[7];  // 06065140 and r7,r3
    c.r[3] |= c.r[0];  // 06065142 or r0,r3
    st8(c.r[1], c.r[3]);  // 06065144 mov.b r3,@r1
    c.r[2] = ld32(c.r[2]);  // 06065146 mov.l @r2,r2
    c.r[2] += 9;  // 06065148 add #9,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606514A mov.b @r2,r1
    c.r[0] = c.r[1];  // 0606514C mov r1,r0
    c.r[0] >>= 2;  // 0606514E shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06065150 shlr r0
    c.r[0] &= 0x3u;  // 06065152 and #3,r0
    c.t = c.r[0] == 0x3u;  // 06065154 cmp/eq #3,r0
    { const bool k = !c.t; c.r[0] = c.r[1]; if (k) { goto L_06065202; } }  // 06065156 bf/s 0x06065202 ; mov r1,r0
    c.r[0] &= 0xE7u;  // 0606515A and #231,r0
    st8(c.r[2], c.r[0]); goto L_06065202;  // 0606515C bra 0x06065202 ; mov.b r0,@r2
L_06065160:
    c.r[2] = ld32(0x0606521Cu);  // 06065160 mov.l 0x0606521C,r2
    c.r[1] = ld32(c.r[2]);  // 06065162 mov.l @r2,r1
    c.r[1] += 9;  // 06065164 add #9,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06065166 mov.b @r1,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x0606520Eu);  // 06065168 mov.w 0x0606520E,r7
    c.r[0] = c.r[3];  // 0606516A mov r3,r0
    c.r[0] >>= 2;  // 0606516C shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0606516E shlr r0
    c.r[0] >>= 2;  // 06065170 shlr2 r0
    c.r[0] &= 0x3u;  // 06065172 and #3,r0
    c.r[0] += 1;  // 06065174 add #1,r0
    c.r[0] &= 0x3u;  // 06065176 and #3,r0
    c.r[0] <<= 2;  // 06065178 shll2 r0
    c.r[0] += c.r[0];  // 0606517A add r0,r0
    c.r[0] <<= 2;  // 0606517C shll2 r0
    c.r[3] &= c.r[7];  // 0606517E and r7,r3
    c.r[3] |= c.r[0];  // 06065180 or r0,r3
    st8(c.r[1], c.r[3]);  // 06065182 mov.b r3,@r1
    c.r[2] = ld32(c.r[2]);  // 06065184 mov.l @r2,r2
    c.r[2] += 9;  // 06065186 add #9,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06065188 mov.b @r2,r1
    c.r[0] = c.r[1];  // 0606518A mov r1,r0
    c.r[0] >>= 2;  // 0606518C shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0606518E shlr r0
    c.r[0] >>= 2;  // 06065190 shlr2 r0
    c.r[0] &= 0x3u;  // 06065192 and #3,r0
    c.t = c.r[0] == 0x3u;  // 06065194 cmp/eq #3,r0
    { const bool k = !c.t; c.r[0] = c.r[1]; if (k) { goto L_06065202; } }  // 06065196 bf/s 0x06065202 ; mov r1,r0
    c.r[0] &= 0x9Fu;  // 0606519A and #159,r0
    st8(c.r[2], c.r[0]); goto L_06065202;  // 0606519C bra 0x06065202 ; mov.b r0,@r2
L_060651A0:
    c.t = (c.r[0] & c.r[0]) == 0;  // 060651A0 tst r0,r0
    if (c.t) { goto L_060651E8; }  // 060651A2 bt 0x060651E8
    c.r[3] = ld32(0x0606521Cu);  // 060651A4 mov.l 0x0606521C,r3
    c.r[1] = ld32(c.r[3]);  // 060651A6 mov.l @r3,r1
    c.r[1] += 9;  // 060651A8 add #9,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060651AA mov.b @r1,r2
    c.r[7] = (uint32_t)(int16_t)ld16(0x06065210u);  // 060651AC mov.w 0x06065210,r7
    c.r[0] = c.r[2];  // 060651AE mov r2,r0
    c.r[0] &= 0x3u;  // 060651B0 and #3,r0
    c.r[0] += 1;  // 060651B2 add #1,r0
    c.r[0] &= 0x3u;  // 060651B4 and #3,r0
    c.r[2] &= c.r[7];  // 060651B6 and r7,r2
    c.r[2] |= c.r[0];  // 060651B8 or r0,r2
    st8(c.r[1], c.r[2]);  // 060651BA mov.b r2,@r1
    c.r[2] = ld32(c.r[3]);  // 060651BC mov.l @r3,r2
    c.r[2] += 9;  // 060651BE add #9,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060651C0 mov.b @r2,r1
    c.r[0] = c.r[1];  // 060651C2 mov r1,r0
    c.r[0] &= 0x3u;  // 060651C4 and #3,r0
    c.t = c.r[0] == 0x3u;  // 060651C6 cmp/eq #3,r0
    { const bool k = !c.t; c.r[0] = c.r[1]; if (k) { goto L_060651D0; } }  // 060651C8 bf/s 0x060651D0 ; mov r1,r0
    c.r[0] &= 0xFCu;  // 060651CC and #252,r0
    st8(c.r[2], c.r[0]);  // 060651CE mov.b r0,@r2
L_060651D0:
    c.r[1] = ld32(c.r[3]);  // 060651D0 mov.l @r3,r1
    c.r[1] += 9;  // 060651D2 add #9,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060651D4 mov.b @r1,r2
    c.r[0] = c.r[2];  // 060651D6 mov r2,r0
    c.r[0] &= 0x3u;  // 060651D8 and #3,r0
    c.t = c.r[0] == 0x1u;  // 060651DA cmp/eq #1,r0
    { const bool k = !c.t; c.r[0] = c.r[2]; if (k) { goto L_06065202; } }  // 060651DC bf/s 0x06065202 ; mov r2,r0
    c.r[0] &= 0xFCu;  // 060651E0 and #252,r0
    c.r[0] |= 0x2u;  // 060651E2 or #2,r0
    st8(c.r[1], c.r[0]); goto L_06065202;  // 060651E4 bra 0x06065202 ; mov.b r0,@r1
L_060651E8:
    c.r[1] = ld32(0x0606521Cu);  // 060651E8 mov.l 0x0606521C,r1
    c.r[1] = ld32(c.r[1]);  // 060651EA mov.l @r1,r1
    c.r[1] += 9;  // 060651EC add #9,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060651EE mov.b @r1,r2
    c.r[7] = (uint32_t)(int16_t)ld16(0x06065212u);  // 060651F0 mov.w 0x06065212,r7
    c.r[0] = c.r[2];  // 060651F2 mov r2,r0
    c.r[0] >>= 2;  // 060651F4 shlr2 r0
    c.r[0] &= 0x1u;  // 060651F6 and #1,r0
    c.r[0] ^= 0x1u;  // 060651F8 xor #1,r0
    c.r[0] <<= 2;  // 060651FA shll2 r0
    c.r[2] &= c.r[7];  // 060651FC and r7,r2
    c.r[2] |= c.r[0];  // 060651FE or r0,r2
    st8(c.r[1], c.r[2]);  // 06065200 mov.b r2,@r1
L_06065202:
    c.r[15] = c.r[14];  // 06065202 mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x06065214u);  // 06065204 mov.w 0x06065214,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06065206 rts ; mov.l @r15+,r14
}

void f_06065220(SH2Context& c) {
    ran[1491] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06065220 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06065222 sts.l pr,@-r15
    c.r[1] = ld32(0x06065254u);  // 06065224 mov.l 0x06065254,r1
    c.r[1] = ld32(c.r[1]);  // 06065226 mov.l @r1,r1
    c.r[1] += 1;  // 06065228 add #1,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606522A mov.b @r1,r0
    c.r[1] = c.r[0] & 0xFFu;  // 0606522C extu.b r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606522E tst r1,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0606523C; } }  // 06065230 bt/s 0x0606523C ; mov r15,r14
    c.r[0] &= 0x7Fu;  // 06065234 and #127,r0
    c.r[1] = ld32(0x06065258u);  // 06065236 mov.l 0x06065258,r1
    c.r[4] = c.r[0]; goto L_06065244;  // 06065238 bra 0x06065244 ; mov r0,r4
L_0606523C:
    c.r[1] = ld32(0x0606525Cu);  // 0606523C mov.l 0x0606525C,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606523E mov.b @r1,r4
    c.r[4] = c.r[4] & 0xFFu;  // 06065240 extu.b r4,r4
    c.r[1] = ld32(0x06065260u);  // 06065242 mov.l 0x06065260,r1
L_06065244:
    { const uint32_t x = c.r[1]; c.pr = 0x06065248u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06065248u) return; }  // 06065244 jsr @r1 ; nop
    c.r[15] = c.r[14];  // 06065248 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0606524A lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x06065252u);  // 0606524C mov.w 0x06065252,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0606524E rts ; mov.l @r15+,r14
}

void f_06065264(SH2Context& c) {
    ran[1492] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06065264 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06065266 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06065268 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0606526A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0606526C mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0606526E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06065270 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06065272 mov r15,r14
    c.r[3] = ld32(0x06065380u);  // 06065274 mov.l 0x06065380,r3
    c.r[2] = ld32(c.r[3]);  // 06065276 mov.l @r3,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06065378u);  // 06065278 mov.w 0x06065378,r0
    c.r[1] = 0x1Eu;  // 0606527A mov #30,r1
    c.r[9] = 0x0u;  // 0606527C mov #0,r9
    c.r[6] = 0x49u;  // 0606527E mov #73,r6
    c.r[7] = 0x0u;  // 06065280 mov #0,r7
    st8(c.r[0] + c.r[2], c.r[1]);  // 06065282 mov.b r1,@(r0,r2)
L_06065284:
    c.r[2] = c.r[9];  // 06065284 mov r9,r2
    c.r[1] = ld32(c.r[3]);  // 06065286 mov.l @r3,r1
    c.r[2] += c.r[2];  // 06065288 add r2,r2
    c.r[0] = c.r[1];  // 0606528A mov r1,r0
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0606528C mov.b @(r0,r2),r5
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606537Au);  // 0606528E mov.w 0x0606537A,r0
    c.r[5] &= c.r[0];  // 06065290 and r0,r5
    c.r[0] = c.r[1];  // 06065292 mov r1,r0
    st8(c.r[0] + c.r[2], c.r[5]);  // 06065294 mov.b r5,@(r0,r2)
    c.r[1] += c.r[2];  // 06065296 add r2,r1
    c.r[1] += 1;  // 06065298 add #1,r1
    st8(c.r[1], c.r[7]);  // 0606529A mov.b r7,@r1
    c.r[1] = ld32(c.r[3]);  // 0606529C mov.l @r3,r1
    c.r[9] += 1;  // 0606529E add #1,r9
    c.r[0] = c.r[1];  // 060652A0 mov r1,r0
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 060652A2 mov.b @(r0,r2),r5
    c.t = (int32_t)c.r[9] > (int32_t)c.r[6];  // 060652A4 cmp/gt r6,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606537Au);  // 060652A6 mov.w 0x0606537A,r0
    c.r[5] |= c.r[0];  // 060652A8 or r0,r5
    c.r[0] = c.r[1];  // 060652AA mov r1,r0
    { const bool k = !c.t; st8(c.r[0] + c.r[2], c.r[5]); if (k) { SH2_POLL(c); goto L_06065284; } }  // 060652AC bf/s 0x06065284 ; mov.b r5,@(r0,r2)
    c.r[9] = 0x0u;  // 060652B0 mov #0,r9
    c.r[11] = (uint32_t)(int16_t)ld16(0x0606537Cu);  // 060652B2 mov.w 0x0606537C,r11
    c.r[12] = ld32(0x06065384u);  // 060652B4 mov.l 0x06065384,r12
    c.r[10] = 0x0u;  // 060652B6 mov #0,r10
L_060652B8:
    c.r[1] = ld32(0x06065388u);  // 060652B8 mov.l 0x06065388,r1
    c.r[0] = ld32(c.r[1]);  // 060652BA mov.l @r1,r0
    c.r[2] = c.r[10];  // 060652BC mov r10,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 060652BE mov.b @(r0,r10),r1
    c.r[1] = c.r[1] & 0xFFu;  // 060652C0 extu.b r1,r1
    c.t = c.r[1] == c.r[11];  // 060652C2 cmp/eq r11,r1
    { const bool k = c.t; c.r[2] += c.r[0]; if (k) { goto L_06065326; } }  // 060652C4 bt/s 0x06065326 ; add r0,r2
    c.r[1] = c.r[2];  // 060652C8 mov r2,r1
    c.r[1] += 7;  // 060652CA add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060652CC mov.b @r1,r1
    c.r[0] = c.r[1];  // 060652CE mov r1,r0
    c.r[0] >>= 2;  // 060652D0 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060652D2 shlr r0
    c.r[0] &= 0x1u;  // 060652D4 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060652D6 tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[2]; if (k) { goto L_06065326; } }  // 060652D8 bf/s 0x06065326 ; mov r2,r1
    c.r[1] += 3;  // 060652DC add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060652DE mov.b @r1,r1
    c.r[0] = c.r[1];  // 060652E0 mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060652E2 shlr r0
    c.r[0] &= 0x3u;  // 060652E4 and #3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060652E6 tst r0,r0
    if (!c.t) { goto L_06065326; }  // 060652E8 bf 0x06065326
    c.r[1] = ld32(c.r[2] + 12);  // 060652EA mov.l @(12,r2),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060652EC tst r1,r1
    { const bool k = !c.t; c.r[2] += 2; if (k) { goto L_06065326; } }  // 060652EE bf/s 0x06065326 ; add #2,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060652F2 mov.b @r2,r2
    c.r[1] = ld32(0x0606538Cu);  // 060652F4 mov.l 0x0606538C,r1
    c.r[3] = ld32(c.r[1]);  // 060652F6 mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 060652F8 extu.b r2,r2
    c.r[1] = 0x1Eu;  // 060652FA mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 060652FC mul.l r1,r2
    c.r[1] = c.macl;  // 060652FE sts macl,r1
    c.r[1] += c.r[3];  // 06065300 add r3,r1
    c.r[1] += 15;  // 06065302 add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]); goto L_0606531E;  // 06065304 bra 0x0606531E ; mov.b @r1,r1
L_06065308:
    { const uint32_t x = c.r[12]; c.pr = 0x0606530Cu; c.r[4] = c.r[9] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606530Cu) return; }  // 06065308 jsr @r12 ; extu.b r9,r4
    c.r[1] = ld32(0x06065390u);  // 0606530C mov.l 0x06065390,r1
    c.r[2] = c.r[8];  // 0606530E mov r8,r2
    c.r[2] += c.r[2];  // 06065310 add r2,r2
    c.r[2] += c.r[8];  // 06065312 add r8,r2
    c.r[1] = ld32(c.r[1]);  // 06065314 mov.l @r1,r1
    c.r[2] <<= 2;  // 06065316 shll2 r2
    c.r[2] += c.r[1];  // 06065318 add r1,r2
    c.r[2] += 8;  // 0606531A add #8,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606531C mov.b @r2,r1
L_0606531E:
    c.r[8] = c.r[1] & 0xFFu;  // 0606531E extu.b r1,r8
    c.t = c.r[8] == c.r[11];  // 06065320 cmp/eq r11,r8
    { const bool k = !c.t; c.r[5] = c.r[8]; if (k) { SH2_POLL(c); goto L_06065308; } }  // 06065322 bf/s 0x06065308 ; mov r8,r5
L_06065326:
    c.r[9] += 1;  // 06065326 add #1,r9
    c.r[1] = 0x49u;  // 06065328 mov #73,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 0606532A cmp/gt r1,r9
    { const bool k = !c.t; c.r[10] += 16; if (k) { SH2_POLL(c); goto L_060652B8; } }  // 0606532C bf/s 0x060652B8 ; add #16,r10
    c.r[9] = 0x0u;  // 06065330 mov #0,r9
    c.r[5] = ld32(0x06065380u);  // 06065332 mov.l 0x06065380,r5
    c.r[6] = 0x5u;  // 06065334 mov #5,r6
    c.r[3] = c.r[9];  // 06065336 mov r9,r3
L_06065338:
    c.r[3] += c.r[3];  // 06065338 add r3,r3
    c.r[7] = ld32(c.r[5]);  // 0606533A mov.l @r5,r7
    c.r[2] = 0x7Fu;  // 0606533C mov #127,r2
    c.r[0] = c.r[7];  // 0606533E mov r7,r0
    c.r[1] = c.r[7];  // 06065340 mov r7,r1
    c.r[1] += c.r[3];  // 06065342 add r3,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06065344 mov.b @(r0,r3),r4
    c.r[1] += 1;  // 06065346 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06065348 mov.b @r1,r1
    c.r[2] &= c.r[4];  // 0606534A and r4,r2
    c.r[2] <<= 8;  // 0606534C shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0606534E extu.b r1,r1
    c.r[1] |= c.r[2];  // 06065350 or r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06065352 tst r1,r1
    { const bool k = !c.t; c.r[1] = 0x7Fu; if (k) { goto L_0606535C; } }  // 06065354 bf/s 0x0606535C ; mov #127,r1
    c.r[1] &= c.r[4];  // 06065358 and r4,r1
    st8(c.r[0] + c.r[3], c.r[1]);  // 0606535A mov.b r1,@(r0,r3)
L_0606535C:
    c.r[9] += 1;  // 0606535C add #1,r9
    c.t = (int32_t)c.r[9] > (int32_t)c.r[6];  // 0606535E cmp/gt r6,r9
    { const bool k = !c.t; c.r[3] = c.r[9]; if (k) { SH2_POLL(c); goto L_06065338; } }  // 06065360 bf/s 0x06065338 ; mov r9,r3
    c.r[15] = c.r[14];  // 06065364 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06065366 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06065368 mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0606536A mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0606536C mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0606536E mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06065370 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606537Eu);  // 06065372 mov.w 0x0606537E,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06065374 rts ; mov.l @r15+,r8
}

void f_06065394(SH2Context& c) {
    ran[1493] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06065394 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06065396 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06065398 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0606539A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0606539C mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0606539E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060653A0 sts.l pr,@-r15
    c.r[15] -= 48;  // 060653A2 add #-48,r15
    c.r[14] = c.r[15];  // 060653A4 mov r15,r14
    c.r[10] = c.r[4] & 0xFFu;  // 060653A6 extu.b r4,r10
    c.r[5] = c.r[5] & 0xFFu;  // 060653A8 extu.b r5,r5
    c.r[1] = ld32(0x06065468u);  // 060653AA mov.l 0x06065468,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060653B0u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060653B0u) return; }  // 060653AC jsr @r1 ; mov r14,r4
    c.r[9] = 0x0u;  // 060653B0 mov #0,r9
    c.r[12] = ld32(0x0606546Cu);  // 060653B2 mov.l 0x0606546C,r12
    c.r[11] = ld32(0x06065470u);  // 060653B4 mov.l 0x06065470,r11
    c.r[1] = c.r[14];  // 060653B6 mov r14,r1
L_060653B8:
    c.r[1] += 24;  // 060653B8 add #24,r1
    c.r[0] = c.r[1];  // 060653BA mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 060653BC mov.b @(r0,r9),r1
    c.r[4] = c.r[1] & 0xFFu;  // 060653BE extu.b r1,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x06065464u);  // 060653C0 mov.w 0x06065464,r1
    c.t = c.r[4] == c.r[1];  // 060653C2 cmp/eq r1,r4
    { const bool k = c.t; c.t = (c.r[4] & c.r[4]) == 0; if (k) { goto L_06065450; } }  // 060653C4 bt/s 0x06065450 ; tst r4,r4
    { const bool k = c.t; c.r[8] = c.r[4]; if (k) { goto L_06065446; } }  // 060653C8 bt/s 0x06065446 ; mov r4,r8
    c.r[8] -= 1;  // 060653CC add #-1,r8
    c.r[1] = ld32(c.r[12]);  // 060653CE mov.l @r12,r1
    c.r[8] += c.r[8];  // 060653D0 add r8,r8
    c.r[0] = c.r[1];  // 060653D2 mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 060653D4 mov.b @(r0,r8),r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06065466u);  // 060653D6 mov.w 0x06065466,r0
    c.r[2] &= c.r[0];  // 060653D8 and r0,r2
    c.r[0] = c.r[1];  // 060653DA mov r1,r0
    st8(c.r[0] + c.r[8], c.r[2]);  // 060653DC mov.b r2,@(r0,r8)
    c.r[1] += c.r[8];  // 060653DE add r8,r1
    c.r[1] += 1;  // 060653E0 add #1,r1
    st8(c.r[1], c.r[4]);  // 060653E2 mov.b r4,@r1
    c.r[2] = c.r[10];  // 060653E4 mov r10,r2
    c.r[1] = ld32(c.r[11]);  // 060653E6 mov.l @r11,r1
    c.r[2] <<= 2;  // 060653E8 shll2 r2
    c.r[2] <<= 2;  // 060653EA shll2 r2
    c.r[2] += c.r[1];  // 060653EC add r1,r2
    c.r[1] = c.r[2];  // 060653EE mov r2,r1
    c.r[1] += 4;  // 060653F0 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060653F2 mov.b @r1,r1
    c.r[0] = 0x1u;  // 060653F4 mov #1,r0
    c.r[1] >>= 2;  // 060653F6 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060653F8 shlr r1
    c.r[1] >>= 2;  // 060653FA shlr2 r1
    c.r[1] &= c.r[0];  // 060653FC and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060653FE tst r1,r1
    { const bool k = c.t; c.r[2] += 6; if (k) { goto L_06065408; } }  // 06065400 bt/s 0x06065408 ; add #6,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06065404 mov.b @r2,r1
    c.r[10] = c.r[1] & 0xFFu;  // 06065406 extu.b r1,r10
L_06065408:
    c.r[0] = ld32(0x06065474u);  // 06065408 mov.l 0x06065474,r0
    c.r[6] = 0x0u;  // 0606540A mov #0,r6
    { const uint32_t x = c.r[0]; c.pr = 0x06065410u; c.r[5] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06065410u) return; }  // 0606540C jsr @r0 ; mov r14,r5
    c.r[1] = c.r[14];  // 06065410 mov r14,r1
    c.r[1] += 10;  // 06065412 add #10,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06065414 mov.w @r1,r1
    c.r[2] = c.r[0] & 0xFFu;  // 06065416 extu.b r0,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 06065418 extu.w r1,r1
    c.t = c.r[2] > c.r[1];  // 0606541A cmp/hi r1,r2
    { const bool k = c.t; c.r[2] = c.r[10]; if (k) { goto L_06065446; } }  // 0606541C bt/s 0x06065446 ; mov r10,r2
    c.r[1] = ld32(c.r[11]);  // 06065420 mov.l @r11,r1
    c.r[2] <<= 2;  // 06065422 shll2 r2
    c.r[2] <<= 2;  // 06065424 shll2 r2
    c.r[2] += c.r[1];  // 06065426 add r1,r2
    c.r[2] += 7;  // 06065428 add #7,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606542A mov.b @r2,r1
    c.r[0] = c.r[1];  // 0606542C mov r1,r0
    c.r[0] >>= 2;  // 0606542E shlr2 r0
    c.r[0] >>= 2;  // 06065430 shlr2 r0
    c.r[0] &= 0x1u;  // 06065432 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06065434 tst r0,r0
    if (!c.t) { goto L_06065446; }  // 06065436 bf 0x06065446
    c.r[1] = ld32(c.r[12]);  // 06065438 mov.l @r12,r1
    c.r[0] = c.r[1];  // 0606543A mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0606543C mov.b @(r0,r8),r2
    c.r[0] = 0x7Fu;  // 0606543E mov #127,r0
    c.r[2] &= c.r[0];  // 06065440 and r0,r2
    c.r[0] = c.r[1];  // 06065442 mov r1,r0
    st8(c.r[0] + c.r[8], c.r[2]);  // 06065444 mov.b r2,@(r0,r8)
L_06065446:
    c.r[9] += 1;  // 06065446 add #1,r9
    c.r[1] = 0x5u;  // 06065448 mov #5,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 0606544A cmp/gt r1,r9
    { const bool k = !c.t; c.r[1] = c.r[14]; if (k) { SH2_POLL(c); goto L_060653B8; } }  // 0606544C bf/s 0x060653B8 ; mov r14,r1
L_06065450:
    c.r[14] += 48;  // 06065450 add #48,r14
    c.r[15] = c.r[14];  // 06065452 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06065454 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06065456 mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06065458 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0606545A mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0606545C mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0606545E mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06065460 rts ; mov.l @r15+,r8
}

void f_06065478(SH2Context& c) {
    ran[1494] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06065478 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0606547A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0606547C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0606547E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06065480 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06065482 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06065484 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06065486 sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x060655D0u);  // 06065488 mov.w 0x060655D0,r3
    c.r[15] += c.r[3];  // 0606548A add r3,r15
    c.r[14] = c.r[15];  // 0606548C mov r15,r14
    c.r[1] = ld32(0x060655D8u);  // 0606548E mov.l 0x060655D8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06065494u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06065494u) return; }  // 06065490 jsr @r1 ; mov #0,r4
    c.r[2] = ld32(0x060655DCu);  // 06065494 mov.l 0x060655DC,r2
    c.r[1] = ld32(c.r[2]);  // 06065496 mov.l @r2,r1
    c.r[6] = (uint32_t)(int16_t)ld16(0x060655D2u);  // 06065498 mov.w 0x060655D2,r6
    c.r[0] = c.r[1];  // 0606549A mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 0606549C mov.b @(r0,r6),r1
    c.r[12] = 0x0u;  // 0606549E mov #0,r12
    c.r[1] = c.r[1] & 0xFFu;  // 060654A0 extu.b r1,r1
    c.t = (int32_t)c.r[12] >= (int32_t)c.r[1];  // 060654A2 cmp/ge r1,r12
    { const bool k = c.t; c.r[7] = c.r[14]; if (k) { goto L_060654CC; } }  // 060654A4 bt/s 0x060654CC ; mov r14,r7
    c.r[7] += 48;  // 060654A8 add #48,r7
    c.r[3] = c.r[2];  // 060654AA mov r2,r3
    c.r[1] = c.r[12];  // 060654AC mov r12,r1
L_060654AE:
    c.r[2] = ld32(c.r[3]);  // 060654AE mov.l @r3,r2
    c.r[1] += c.r[1];  // 060654B0 add r1,r1
    c.r[2] += c.r[1];  // 060654B2 add r1,r2
    c.r[2] += 1;  // 060654B4 add #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060654B6 mov.b @r2,r1
    c.r[0] = c.r[7];  // 060654B8 mov r7,r0
    st8(c.r[0] + c.r[12], c.r[1]);  // 060654BA mov.b r1,@(r0,r12)
    c.r[1] = ld32(c.r[3]);  // 060654BC mov.l @r3,r1
    c.r[0] = c.r[1];  // 060654BE mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 060654C0 mov.b @(r0,r6),r1
    c.r[12] += 1;  // 060654C2 add #1,r12
    c.r[1] = c.r[1] & 0xFFu;  // 060654C4 extu.b r1,r1
    c.t = (int32_t)c.r[12] >= (int32_t)c.r[1];  // 060654C6 cmp/ge r1,r12
    { const bool k = !c.t; c.r[1] = c.r[12]; if (k) { SH2_POLL(c); goto L_060654AE; } }  // 060654C8 bf/s 0x060654AE ; mov r12,r1
L_060654CC:
    c.r[3] = ld32(0x060655DCu);  // 060654CC mov.l 0x060655DC,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x060655D2u);  // 060654CE mov.w 0x060655D2,r7
    c.r[1] = ld32(c.r[3]);  // 060654D0 mov.l @r3,r1
    c.r[11] = (uint32_t)(int16_t)ld16(0x060655D4u);  // 060654D2 mov.w 0x060655D4,r11
    c.r[0] = c.r[1];  // 060654D4 mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 060654D6 mov.b @(r0,r7),r2
    c.r[11] += c.r[14];  // 060654D8 add r14,r11
    c.r[2] = c.r[2] & 0xFFu;  // 060654DA extu.b r2,r2
    st32(c.r[11], c.r[2]);  // 060654DC mov.l r2,@r11
    c.r[2] = 0x0u;  // 060654DE mov #0,r2
    st8(c.r[0] + c.r[7], c.r[2]);  // 060654E0 mov.b r2,@(r0,r7)
    c.r[0] = (uint32_t)(int16_t)ld16(0x060655D4u);  // 060654E2 mov.w 0x060655D4,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 060654E4 mov.l @(r0,r14),r0
    c.r[12] = 0x0u;  // 060654E6 mov #0,r12
    c.t = (int32_t)c.r[12] >= (int32_t)c.r[0];  // 060654E8 cmp/ge r0,r12
    { const bool k = !c.t; c.r[13] = c.r[3]; if (k) { goto L_060654F2; } }  // 060654EA bf/s 0x060654F2 ; mov r3,r13
    goto L_060656B4;  // 060654EE bra 0x060656B4 ; nop
L_060654F2:
    c.r[10] = c.r[7];  // 060654F2 mov r7,r10
    c.r[1] = c.r[14];  // 060654F4 mov r14,r1
L_060654F6:
    c.r[1] += 48;  // 060654F6 add #48,r1
    c.r[0] = c.r[1];  // 060654F8 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[12]);  // 060654FA mov.b @(r0,r12),r1
    c.r[4] = c.r[14];  // 060654FC mov r14,r4
    c.r[8] = c.r[1] & 0xFFu;  // 060654FE extu.b r1,r8
    c.r[1] = ld32(0x060655E0u);  // 06065500 mov.l 0x060655E0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06065506u; c.r[5] = c.r[8] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06065506u) return; }  // 06065502 jsr @r1 ; extu.b r8,r5
    c.r[2] = c.r[14];  // 06065506 mov r14,r2
    c.r[2] += 24;  // 06065508 add #24,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606550A mov.b @r2,r1
    c.r[11] = (uint32_t)(int16_t)ld16(0x060655D6u);  // 0606550C mov.w 0x060655D6,r11
    c.r[1] = c.r[1] & 0xFFu;  // 0606550E extu.b r1,r1
    c.t = c.r[1] == c.r[11];  // 06065510 cmp/eq r11,r1
    { const bool k = c.t; c.r[6] = 0x0u; if (k) { goto L_0606553E; } }  // 06065512 bt/s 0x0606553E ; mov #0,r6
    c.r[0] = ld32(0x060655E4u);  // 06065516 mov.l 0x060655E4,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06065518 mov.b @r0,r1
    c.r[5] = (uint32_t)(int16_t)ld16(0x060655D6u);  // 0606551A mov.w 0x060655D6,r5
    c.r[7] = c.r[1] & 0xFFu;  // 0606551C extu.b r1,r7
    c.r[0] = c.r[2];  // 0606551E mov r2,r0
L_06065520:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 06065520 mov.b @(r0,r6),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06065522 extu.b r1,r1
    c.t = c.r[1] == c.r[7];  // 06065524 cmp/eq r7,r1
    { const bool k = c.t; c.r[3] = c.r[2]; if (k) { goto L_0606553E; } }  // 06065526 bt/s 0x0606553E ; mov r2,r3
    c.r[6] += 1;  // 0606552A add #1,r6
    c.r[11] = 0x5u;  // 0606552C mov #5,r11
    c.t = (int32_t)c.r[6] > (int32_t)c.r[11];  // 0606552E cmp/gt r11,r6
    { const bool k = c.t; c.r[0] = c.r[3]; if (k) { goto L_0606553E; } }  // 06065530 bt/s 0x0606553E ; mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 06065534 mov.b @(r0,r6),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06065536 extu.b r1,r1
    c.t = c.r[1] == c.r[5];  // 06065538 cmp/eq r5,r1
    { const bool k = !c.t; c.r[0] = c.r[2]; if (k) { SH2_POLL(c); goto L_06065520; } }  // 0606553A bf/s 0x06065520 ; mov r2,r0
L_0606553E:
    c.r[0] = c.r[6];  // 0606553E mov r6,r0
    c.t = c.r[0] == 0x6u;  // 06065540 cmp/eq #6,r0
    { const bool k = !c.t; c.r[1] = c.r[14]; if (k) { goto L_0606554A; } }  // 06065542 bf/s 0x0606554A ; mov r14,r1
    goto L_060656A4;  // 06065546 bra 0x060656A4 ; nop
L_0606554A:
    c.r[1] += 24;  // 0606554A add #24,r1
    c.r[0] = c.r[1];  // 0606554C mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 0606554E mov.b @(r0,r6),r1
    c.r[11] = (uint32_t)(int16_t)ld16(0x060655D6u);  // 06065550 mov.w 0x060655D6,r11
    c.r[1] = c.r[1] & 0xFFu;  // 06065552 extu.b r1,r1
    c.t = c.r[1] == c.r[11];  // 06065554 cmp/eq r11,r1
    if (!c.t) { goto L_0606555C; }  // 06065556 bf 0x0606555C
    goto L_060656A4;  // 06065558 bra 0x060656A4 ; nop
L_0606555C:
    c.r[2] = ld32(c.r[13]);  // 0606555C mov.l @r13,r2
    c.r[0] = c.r[2];  // 0606555E mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 06065560 mov.b @(r0,r10),r1
    c.r[6] = 0x0u;  // 06065562 mov #0,r6
    c.r[1] = c.r[1] & 0xFFu;  // 06065564 extu.b r1,r1
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[1];  // 06065566 cmp/ge r1,r6
    if (c.t) { goto L_06065594; }  // 06065568 bt 0x06065594
    c.r[7] = c.r[2];  // 0606556A mov r2,r7
    c.r[5] = c.r[1];  // 0606556C mov r1,r5
    c.r[3] = c.r[7];  // 0606556E mov r7,r3
    c.r[2] = 0x0u;  // 06065570 mov #0,r2
L_06065572:
    c.r[0] = c.r[2];  // 06065572 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06065574 mov.b @(r0,r7),r1
    c.r[4] = 0x7Fu;  // 06065576 mov #127,r4
    c.r[4] &= c.r[1];  // 06065578 and r1,r4
    c.r[1] = c.r[3];  // 0606557A mov r3,r1
    c.r[1] += 1;  // 0606557C add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606557E mov.b @r1,r1
    c.r[4] <<= 8;  // 06065580 shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 06065582 extu.b r1,r1
    c.r[1] |= c.r[4];  // 06065584 or r4,r1
    c.t = c.r[1] == c.r[8];  // 06065586 cmp/eq r8,r1
    if (c.t) { goto L_06065594; }  // 06065588 bt 0x06065594
    c.r[3] += 2;  // 0606558A add #2,r3
    c.r[6] += 1;  // 0606558C add #1,r6
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[5];  // 0606558E cmp/ge r5,r6
    { const bool k = !c.t; c.r[2] += 2; if (k) { SH2_POLL(c); goto L_06065572; } }  // 06065590 bf/s 0x06065572 ; add #2,r2
L_06065594:
    c.r[1] = ld32(c.r[13]);  // 06065594 mov.l @r13,r1
    c.r[0] = c.r[1];  // 06065596 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 06065598 mov.b @(r0,r10),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606559A extu.b r1,r1
    c.t = c.r[6] == c.r[1];  // 0606559C cmp/eq r1,r6
    if (c.t) { goto L_060655A4; }  // 0606559E bt 0x060655A4
    goto L_060656A4;  // 060655A0 bra 0x060656A4 ; nop
L_060655A4:
    c.r[11] = ld32(0x060655E8u);  // 060655A4 mov.l 0x060655E8,r11
    { const uint32_t x = c.r[11]; c.pr = 0x060655AAu; c.r[4] = c.r[8] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060655AAu) return; }  // 060655A6 jsr @r11 ; extu.b r8,r4
    c.r[1] = c.r[0];  // 060655AA mov r0,r1
    c.r[9] = c.r[1] & 0xFFu;  // 060655AC extu.b r1,r9
    c.r[3] = ld32(0x060655ECu);  // 060655AE mov.l 0x060655EC,r3
    c.r[2] = c.r[9];  // 060655B0 mov r9,r2
    c.r[1] = ld32(c.r[3]);  // 060655B2 mov.l @r3,r1
    c.r[2] <<= 2;  // 060655B4 shll2 r2
    c.r[2] <<= 2;  // 060655B6 shll2 r2
    c.r[2] += c.r[1];  // 060655B8 add r1,r2
    c.r[1] = c.r[2];  // 060655BA mov r2,r1
    c.r[1] += 3;  // 060655BC add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060655BE mov.b @r1,r1
    c.r[0] = 0x3u;  // 060655C0 mov #3,r0
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060655C2 shlr r1
    c.r[1] &= c.r[0];  // 060655C4 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060655C6 tst r1,r1
    if (!c.t) { goto L_060655F2; }  // 060655C8 bf 0x060655F2
    c.r[1] = ld32(c.r[2] + 12);  // 060655CA mov.l @(12,r2),r1
    c.t = (c.r[1] & c.r[1]) == 0; goto L_060655F0;  // 060655CC bra 0x060655F0 ; tst r1,r1
L_060655F0:
    if (!c.t) { goto L_060656A4; }  // 060655F0 bf 0x060656A4
L_060655F2:
    c.r[1] = c.r[2];  // 060655F2 mov r2,r1
    c.r[1] += 4;  // 060655F4 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060655F6 mov.b @r1,r1
    c.r[0] = c.r[1];  // 060655F8 mov r1,r0
    c.r[0] >>= 2;  // 060655FA shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060655FC shlr r0
    c.r[0] >>= 2;  // 060655FE shlr2 r0
    c.r[0] &= 0x1u;  // 06065600 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06065602 tst r0,r0
    { const bool k = c.t; c.r[2] += 6; if (k) { goto L_0606560C; } }  // 06065604 bt/s 0x0606560C ; add #6,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06065608 mov.b @r2,r1
    c.r[9] = c.r[1] & 0xFFu;  // 0606560A extu.b r1,r9
L_0606560C:
    c.r[11] = ld32(0x06065668u);  // 0606560C mov.l 0x06065668,r11
    c.r[6] = 0x0u;  // 0606560E mov #0,r6
    c.r[5] = c.r[14];  // 06065610 mov r14,r5
    c.r[0] = (uint32_t)(int16_t)ld16(0x06065662u);  // 06065612 mov.w 0x06065662,r0
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[11]);  // 06065614 mov.b @r11,r4
    c.r[0] += c.r[14];  // 06065616 add r14,r0
    c.r[4] = c.r[4] & 0xFFu;  // 06065618 extu.b r4,r4
    c.r[11] = ld32(0x0606566Cu);  // 0606561A mov.l 0x0606566C,r11
    { const uint32_t x = c.r[11]; c.pr = 0x06065620u; st32(c.r[0], c.r[3]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06065620u) return; }  // 0606561C jsr @r11 ; mov.l r3,@r0
    c.r[2] = c.r[0];  // 06065620 mov r0,r2
    c.r[1] = c.r[14];  // 06065622 mov r14,r1
    c.r[1] += 10;  // 06065624 add #10,r1
    c.r[2] = c.r[2] & 0xFFu;  // 06065626 extu.b r2,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06065662u);  // 06065628 mov.w 0x06065662,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606562A mov.w @r1,r1
    c.r[0] += c.r[14];  // 0606562C add r14,r0
    c.r[1] = c.r[1] & 0xFFFFu;  // 0606562E extu.w r1,r1
    c.t = c.r[2] > c.r[1];  // 06065630 cmp/hi r1,r2
    { const bool k = c.t; c.r[3] = ld32(c.r[0]); if (k) { goto L_06065650; } }  // 06065632 bt/s 0x06065650 ; mov.l @r0,r3
    c.r[1] = ld32(c.r[3]);  // 06065636 mov.l @r3,r1
    c.r[9] <<= 2;  // 06065638 shll2 r9
    c.r[9] <<= 2;  // 0606563A shll2 r9
    c.r[9] += c.r[1];  // 0606563C add r1,r9
    c.r[9] += 7;  // 0606563E add #7,r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06065640 mov.b @r9,r1
    c.r[0] = c.r[1];  // 06065642 mov r1,r0
    c.r[0] >>= 2;  // 06065644 shlr2 r0
    c.r[0] >>= 2;  // 06065646 shlr2 r0
    c.r[0] &= 0x1u;  // 06065648 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606564A tst r0,r0
    { const bool k = c.t; c.r[11] = 0x7Fu; if (k) { goto L_06065670; } }  // 0606564C bt/s 0x06065670 ; mov #127,r11
L_06065650:
    c.r[2] = ld32(c.r[13]);  // 06065650 mov.l @r13,r2
    c.r[0] = c.r[2];  // 06065652 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 06065654 mov.b @(r0,r10),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06065656 extu.b r1,r1
    c.r[1] += c.r[1];  // 06065658 add r1,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606565A mov.b @(r0,r1),r3
    c.r[11] = (uint32_t)(int16_t)ld16(0x06065664u);  // 0606565C mov.w 0x06065664,r11
    c.r[3] |= c.r[11]; goto L_0606567E;  // 0606565E bra 0x0606567E ; or r11,r3
L_06065670:
    c.r[2] = ld32(c.r[13]);  // 06065670 mov.l @r13,r2
    c.r[0] = c.r[2];  // 06065672 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 06065674 mov.b @(r0,r10),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06065676 extu.b r1,r1
    c.r[1] += c.r[1];  // 06065678 add r1,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606567A mov.b @(r0,r1),r3
    c.r[3] &= c.r[11];  // 0606567C and r11,r3
L_0606567E:
    st8(c.r[0] + c.r[1], c.r[3]);  // 0606567E mov.b r3,@(r0,r1)
    c.r[3] = ld32(c.r[13]);  // 06065680 mov.l @r13,r3
    c.r[0] = c.r[3];  // 06065682 mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 06065684 mov.b @(r0,r10),r2
    c.r[11] = (uint32_t)(int16_t)ld16(0x06065802u);  // 06065686 mov.w 0x06065802,r11
    c.r[1] = c.r[2];  // 06065688 mov r2,r1
    c.r[1] += 1;  // 0606568A add #1,r1
    st8(c.r[0] + c.r[10], c.r[1]);  // 0606568C mov.b r1,@(r0,r10)
    c.r[2] = c.r[2] & 0xFFu;  // 0606568E extu.b r2,r2
    c.r[2] += c.r[2];  // 06065690 add r2,r2
    c.r[1] = c.r[8];  // 06065692 mov r8,r1
    c.r[1] >>= 8;  // 06065694 shlr8 r1
    c.r[3] += c.r[2];  // 06065696 add r2,r3
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06065698 mov.b @(r0,r2),r7
    c.r[3] += 1;  // 0606569A add #1,r3
    c.r[7] &= c.r[11];  // 0606569C and r11,r7
    c.r[7] |= c.r[1];  // 0606569E or r1,r7
    st8(c.r[0] + c.r[2], c.r[7]);  // 060656A0 mov.b r7,@(r0,r2)
    st8(c.r[3], c.r[8]);  // 060656A2 mov.b r8,@r3
L_060656A4:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06065804u);  // 060656A4 mov.w 0x06065804,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 060656A6 mov.l @(r0,r14),r0
    c.r[12] += 1;  // 060656A8 add #1,r12
    c.t = (int32_t)c.r[12] >= (int32_t)c.r[0];  // 060656AA cmp/ge r0,r12
    { const bool k = c.t; c.r[1] = c.r[14]; if (k) { goto L_060656B4; } }  // 060656AC bt/s 0x060656B4 ; mov r14,r1
    SH2_POLL(c); goto L_060654F6;  // 060656B0 bra 0x060654F6 ; nop
L_060656B4:
    c.r[2] = ld32(0x06065814u);  // 060656B4 mov.l 0x06065814,r2
    c.r[1] = ld32(c.r[2]);  // 060656B6 mov.l @r2,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x06065806u);  // 060656B8 mov.w 0x06065806,r3
    c.r[0] = c.r[1];  // 060656BA mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 060656BC mov.b @(r0,r3),r1
    c.r[12] = 0x0u;  // 060656BE mov #0,r12
    c.r[1] = c.r[1] & 0xFFu;  // 060656C0 extu.b r1,r1
    c.r[1] -= 1;  // 060656C2 add #-1,r1
    c.t = (int32_t)c.r[12] >= (int32_t)c.r[1];  // 060656C4 cmp/ge r1,r12
    { const bool k = !c.t; c.r[13] = c.r[2]; if (k) { goto L_060656CE; } }  // 060656C6 bf/s 0x060656CE ; mov r2,r13
    goto L_060657E8;  // 060656CA bra 0x060657E8 ; nop
L_060656CE:
    c.r[11] = (uint32_t)(int16_t)ld16(0x06065808u);  // 060656CE mov.w 0x06065808,r11
    c.r[11] += c.r[14];  // 060656D0 add r14,r11
    st32(c.r[11], c.r[3]);  // 060656D2 mov.l r3,@r11
L_060656D4:
    c.r[11] = (uint32_t)(int16_t)ld16(0x06065808u);  // 060656D4 mov.w 0x06065808,r11
    c.r[1] = ld32(c.r[13]);  // 060656D6 mov.l @r13,r1
    c.r[11] += c.r[14];  // 060656D8 add r14,r11
    c.r[0] = ld32(c.r[11]);  // 060656DA mov.l @r11,r0
    c.r[6] = c.r[12];  // 060656DC mov r12,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060656DE mov.b @(r0,r1),r1
    c.r[6] += 1;  // 060656E0 add #1,r6
    c.r[1] = c.r[1] & 0xFFu;  // 060656E2 extu.b r1,r1
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[1];  // 060656E4 cmp/ge r1,r6
    if (c.t) { goto L_060657D0; }  // 060656E6 bt 0x060657D0
    c.r[9] = c.r[12];  // 060656E8 mov r12,r9
    c.r[9] += c.r[9];  // 060656EA add r9,r9
    c.r[2] = 0x7Fu;  // 060656EC mov #127,r2
L_060656EE:
    c.r[11] = (uint32_t)(int16_t)ld16(0x0606580Au);  // 060656EE mov.w 0x0606580A,r11
    c.r[4] = ld32(c.r[13]);  // 060656F0 mov.l @r13,r4
    c.r[11] += c.r[14];  // 060656F2 add r14,r11
    c.r[0] = c.r[4];  // 060656F4 mov r4,r0
    c.r[10] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 060656F6 mov.b @(r0,r9),r10
    c.r[5] = c.r[6];  // 060656F8 mov r6,r5
    c.r[0] += c.r[9];  // 060656FA add r9,r0
    st32(c.r[11], c.r[0]);  // 060656FC mov.l r0,@r11
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606580Au);  // 060656FE mov.w 0x0606580A,r0
    c.r[0] += c.r[14];  // 06065700 add r14,r0
    c.r[11] = ld32(c.r[0]);  // 06065702 mov.l @r0,r11
    c.r[2] &= c.r[10];  // 06065704 and r10,r2
    c.r[11] += 1;  // 06065706 add #1,r11
    st32(c.r[0], c.r[11]);  // 06065708 mov.l r11,@r0
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606580Au);  // 0606570A mov.w 0x0606580A,r0
    c.r[11] = ld32(c.r[0] + c.r[14]);  // 0606570C mov.l @(r0,r14),r11
    c.r[2] <<= 8;  // 0606570E shll8 r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[11]);  // 06065710 mov.b @r11,r1
    c.r[0] = c.r[4];  // 06065712 mov r4,r0
    c.r[8] = c.r[1] & 0xFFu;  // 06065714 extu.b r1,r8
    c.r[8] |= c.r[2];  // 06065716 or r2,r8
    c.r[1] = ld32(0x06065818u);  // 06065718 mov.l 0x06065818,r1
    c.r[3] = c.r[8];  // 0606571A mov r8,r3
    c.r[3] += c.r[3];  // 0606571C add r3,r3
    c.r[3] += c.r[8];  // 0606571E add r8,r3
    c.r[3] <<= 2;  // 06065720 shll2 r3
    c.r[5] += c.r[5];  // 06065722 add r5,r5
    c.r[11] = (uint32_t)(int16_t)ld16(0x0606580Cu);  // 06065724 mov.w 0x0606580C,r11
    c.r[2] = ld32(c.r[1]);  // 06065726 mov.l @r1,r2
    c.r[11] += c.r[14];  // 06065728 add r14,r11
    c.r[3] += c.r[2];  // 0606572A add r2,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 0606572C mov.b @(r0,r5),r1
    c.r[3] += 10;  // 0606572E add #10,r3
    c.r[0] = c.r[1];  // 06065730 mov r1,r0
    c.r[0] &= 0x7Fu;  // 06065732 and #127,r0
    st32(c.r[11], c.r[0]);  // 06065734 mov.l r0,@r11
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606580Cu);  // 06065736 mov.w 0x0606580C,r0
    c.r[0] += c.r[14];  // 06065738 add r14,r0
    c.r[1] = c.r[4];  // 0606573A mov r4,r1
    c.r[1] += c.r[5];  // 0606573C add r5,r1
    c.r[11] = ld32(c.r[0]);  // 0606573E mov.l @r0,r11
    c.r[1] += 1;  // 06065740 add #1,r1
    c.r[11] <<= 8;  // 06065742 shll8 r11
    st32(c.r[0], c.r[11]);  // 06065744 mov.l r11,@r0
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606580Cu);  // 06065746 mov.w 0x0606580C,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06065748 mov.b @r1,r1
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 0606574A mov.l @(r0,r14),r0
    c.r[7] = c.r[1] & 0xFFu;  // 0606574C extu.b r1,r7
    c.r[7] |= c.r[0];  // 0606574E or r0,r7
    c.r[1] = c.r[7];  // 06065750 mov r7,r1
    c.r[1] += c.r[1];  // 06065752 add r1,r1
    c.r[1] += c.r[7];  // 06065754 add r7,r1
    c.r[1] <<= 2;  // 06065756 shll2 r1
    c.r[1] += c.r[2];  // 06065758 add r2,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0606575A mov.w @r3,r2
    c.r[1] += 10;  // 0606575C add #10,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606575E mov.w @r1,r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 06065760 extu.w r2,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 06065762 extu.w r1,r1
    c.t = c.r[2] >= c.r[1];  // 06065764 cmp/hs r1,r2
    { const bool k = c.t; c.r[1] = c.r[7]; if (k) { goto L_060657BC; } }  // 06065766 bt/s 0x060657BC ; mov r7,r1
    c.r[1] >>= 8;  // 0606576A shlr8 r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06065802u);  // 0606576C mov.w 0x06065802,r2
    c.r[2] &= c.r[10];  // 0606576E and r10,r2
    c.r[2] |= c.r[1];  // 06065770 or r1,r2
    c.r[0] = c.r[4];  // 06065772 mov r4,r0
    st8(c.r[0] + c.r[9], c.r[2]);  // 06065774 mov.b r2,@(r0,r9)
    c.r[11] = (uint32_t)(int16_t)ld16(0x0606580Au);  // 06065776 mov.w 0x0606580A,r11
    c.r[11] += c.r[14];  // 06065778 add r14,r11
    c.r[2] = c.r[8];  // 0606577A mov r8,r2
    c.r[0] = ld32(c.r[11]);  // 0606577C mov.l @r11,r0
    c.r[2] >>= 8;  // 0606577E shlr8 r2
    st8(c.r[0], c.r[7]);  // 06065780 mov.b r7,@r0
    c.r[1] = ld32(c.r[13]);  // 06065782 mov.l @r13,r1
    c.r[11] = (uint32_t)(int16_t)ld16(0x06065802u);  // 06065784 mov.w 0x06065802,r11
    c.r[0] = c.r[1];  // 06065786 mov r1,r0
    c.r[1] += c.r[5];  // 06065788 add r5,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 0606578A mov.b @(r0,r5),r3
    c.r[1] += 1;  // 0606578C add #1,r1
    c.r[3] &= c.r[11];  // 0606578E and r11,r3
    c.r[3] |= c.r[2];  // 06065790 or r2,r3
    st8(c.r[0] + c.r[5], c.r[3]);  // 06065792 mov.b r3,@(r0,r5)
    st8(c.r[1], c.r[8]);  // 06065794 mov.b r8,@r1
    c.r[1] = ld32(c.r[13]);  // 06065796 mov.l @r13,r1
    c.r[0] = c.r[1];  // 06065798 mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 0606579A mov.b @(r0,r5),r2
    c.r[7] = (uint32_t)(int16_t)ld16(0x06065802u);  // 0606579C mov.w 0x06065802,r7
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 0606579E mov.b @(r0,r9),r3
    c.r[7] &= c.r[2];  // 060657A0 and r2,r7
    c.r[2] = 0x7Fu;  // 060657A2 mov #127,r2
    c.r[2] &= c.r[3];  // 060657A4 and r3,r2
    c.r[2] |= c.r[7];  // 060657A6 or r7,r2
    st8(c.r[0] + c.r[9], c.r[2]);  // 060657A8 mov.b r2,@(r0,r9)
    c.r[2] = (uint32_t)(int16_t)ld16(0x06065802u);  // 060657AA mov.w 0x06065802,r2
    c.r[1] = ld32(c.r[13]);  // 060657AC mov.l @r13,r1
    c.r[2] &= c.r[3];  // 060657AE and r3,r2
    c.r[0] = c.r[1];  // 060657B0 mov r1,r0
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 060657B2 mov.b @(r0,r5),r3
    c.r[11] = 0x7Fu;  // 060657B4 mov #127,r11
    c.r[3] &= c.r[11];  // 060657B6 and r11,r3
    c.r[3] |= c.r[2];  // 060657B8 or r2,r3
    st8(c.r[0] + c.r[5], c.r[3]);  // 060657BA mov.b r3,@(r0,r5)
L_060657BC:
    c.r[11] = (uint32_t)(int16_t)ld16(0x06065808u);  // 060657BC mov.w 0x06065808,r11
    c.r[1] = ld32(c.r[13]);  // 060657BE mov.l @r13,r1
    c.r[11] += c.r[14];  // 060657C0 add r14,r11
    c.r[0] = ld32(c.r[11]);  // 060657C2 mov.l @r11,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060657C4 mov.b @(r0,r1),r1
    c.r[6] += 1;  // 060657C6 add #1,r6
    c.r[1] = c.r[1] & 0xFFu;  // 060657C8 extu.b r1,r1
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[1];  // 060657CA cmp/ge r1,r6
    { const bool k = !c.t; c.r[2] = 0x7Fu; if (k) { SH2_POLL(c); goto L_060656EE; } }  // 060657CC bf/s 0x060656EE ; mov #127,r2
L_060657D0:
    c.r[2] = ld32(0x06065814u);  // 060657D0 mov.l 0x06065814,r2
    c.r[1] = ld32(c.r[2]);  // 060657D2 mov.l @r2,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x06065806u);  // 060657D4 mov.w 0x06065806,r3
    c.r[0] = c.r[1];  // 060657D6 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 060657D8 mov.b @(r0,r3),r1
    c.r[12] += 1;  // 060657DA add #1,r12
    c.r[1] = c.r[1] & 0xFFu;  // 060657DC extu.b r1,r1
    c.r[1] -= 1;  // 060657DE add #-1,r1
    c.t = (int32_t)c.r[12] >= (int32_t)c.r[1];  // 060657E0 cmp/ge r1,r12
    if (c.t) { goto L_060657E8; }  // 060657E2 bt 0x060657E8
    SH2_POLL(c); goto L_060656D4;  // 060657E4 bra 0x060656D4 ; nop
L_060657E8:
    c.r[3] = (uint32_t)(int16_t)ld16(0x0606580Eu);  // 060657E8 mov.w 0x0606580E,r3
    c.r[14] += c.r[3];  // 060657EA add r3,r14
    c.r[15] = c.r[14];  // 060657EC mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060657EE lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060657F0 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060657F2 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060657F4 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060657F6 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060657F8 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060657FA mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06065810u);  // 060657FC mov.w 0x06065810,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060657FE rts ; mov.l @r15+,r8
}

void f_0606581C(SH2Context& c) {
    ran[1495] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0606581C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0606581E sts.l pr,@-r15
    c.r[1] = ld32(0x060658D4u);  // 06065820 mov.l 0x060658D4,r1
    c.r[1] = ld32(c.r[1]);  // 06065822 mov.l @r1,r1
    c.r[1] += 1;  // 06065824 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06065826 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06065828 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606582A tst r1,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06065864; } }  // 0606582C bt/s 0x06065864 ; mov r15,r14
    c.r[1] = ld32(0x060658D8u);  // 06065830 mov.l 0x060658D8,r1
    c.r[3] = ld32(c.r[1]);  // 06065832 mov.l @r1,r3
    c.r[1] = ld32(0x060658DCu);  // 06065834 mov.l 0x060658DC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06065836 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06065838 extu.b r1,r0
    c.r[1] = ld32(0x060658E0u);  // 0606583A mov.l 0x060658E0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606583C mov.b @(r0,r1),r1
    c.r[2] = 0x16u;  // 0606583E mov #22,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06065840 extu.b r1,r1
    c.r[1] -= 1;  // 06065842 add #-1,r1
    c.macl = c.r[1] * c.r[2];  // 06065844 mul.l r2,r1
    c.r[1] = ld32(0x060658E4u);  // 06065846 mov.l 0x060658E4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06065848 mov.b @(r0,r1),r1
    c.r[2] = c.macl;  // 0606584A sts macl,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0606584C extu.b r1,r1
    c.r[2] += c.r[1];  // 0606584E add r1,r2
    c.r[2] += c.r[2];  // 06065850 add r2,r2
    c.r[3] += c.r[2];  // 06065852 add r2,r3
    c.r[3] += 1;  // 06065854 add #1,r3
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06065856 mov.b @r3,r4
    c.r[0] = ld32(0x060658E8u);  // 06065858 mov.l 0x060658E8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0606585Eu; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606585Eu) return; }  // 0606585A jsr @r0 ; extu.b r4,r4
    c.r[1] = ld32(0x060658ECu);  // 0606585E mov.l 0x060658EC,r1
    st8(c.r[1], c.r[0]); goto L_0606587A;  // 06065860 bra 0x0606587A ; mov.b r0,@r1
L_06065864:
    c.r[1] = ld32(0x060658D8u);  // 06065864 mov.l 0x060658D8,r1
    c.r[2] = ld32(c.r[1]);  // 06065866 mov.l @r1,r2
    c.r[1] = ld32(0x060658F0u);  // 06065868 mov.l 0x060658F0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606586A mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606586C extu.b r1,r1
    c.r[1] += c.r[1];  // 0606586E add r1,r1
    c.r[2] += c.r[1];  // 06065870 add r1,r2
    c.r[2] += 1;  // 06065872 add #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06065874 mov.b @r2,r1
    c.r[3] = ld32(0x060658ECu);  // 06065876 mov.l 0x060658EC,r3
    st8(c.r[3], c.r[1]);  // 06065878 mov.b r1,@r3
L_0606587A:
    c.r[7] = ld32(0x060658ECu);  // 0606587A mov.l 0x060658EC,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0606587C mov.b @r7,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0606587E extu.b r1,r2
    c.r[1] = ld32(0x060658F4u);  // 06065880 mov.l 0x060658F4,r1
    c.r[3] = ld32(c.r[1]);  // 06065882 mov.l @r1,r3
    c.r[2] <<= 2;  // 06065884 shll2 r2
    c.r[2] <<= 2;  // 06065886 shll2 r2
    c.r[2] += c.r[3];  // 06065888 add r3,r2
    c.r[1] = c.r[2];  // 0606588A mov r2,r1
    c.r[1] += 4;  // 0606588C add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606588E mov.b @r1,r1
    c.r[0] = c.r[1];  // 06065890 mov r1,r0
    c.r[0] >>= 2;  // 06065892 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06065894 shlr r0
    c.r[0] >>= 2;  // 06065896 shlr2 r0
    c.r[0] &= 0x1u;  // 06065898 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606589A tst r0,r0
    { const bool k = c.t; c.r[2] += 6; if (k) { goto L_060658A4; } }  // 0606589C bt/s 0x060658A4 ; add #6,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060658A0 mov.b @r2,r1
    st8(c.r[7], c.r[1]);  // 060658A2 mov.b r1,@r7
L_060658A4:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 060658A4 mov.b @r7,r1
    c.r[2] = c.r[1] & 0xFFu;  // 060658A6 extu.b r1,r2
    c.r[2] <<= 2;  // 060658A8 shll2 r2
    c.r[2] <<= 2;  // 060658AA shll2 r2
    c.r[2] += c.r[3];  // 060658AC add r3,r2
    c.r[1] = c.r[2];  // 060658AE mov r2,r1
    c.r[1] += 4;  // 060658B0 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060658B2 mov.b @r1,r1
    c.r[0] = c.r[1];  // 060658B4 mov r1,r0
    c.r[0] >>= 2;  // 060658B6 shlr2 r0
    c.r[0] >>= 2;  // 060658B8 shlr2 r0
    c.r[0] >>= 2;  // 060658BA shlr2 r0
    c.r[0] &= 0x1u;  // 060658BC and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060658BE tst r0,r0
    { const bool k = c.t; c.r[2] += 5; if (k) { goto L_060658C8; } }  // 060658C0 bt/s 0x060658C8 ; add #5,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060658C4 mov.b @r2,r1
    st8(c.r[7], c.r[1]);  // 060658C6 mov.b r1,@r7
L_060658C8:
    c.r[15] = c.r[14];  // 060658C8 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060658CA lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x060658D2u);  // 060658CC mov.w 0x060658D2,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060658CE rts ; mov.l @r15+,r14
}

void f_060658F8(SH2Context& c) {
    ran[1496] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060658F8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060658FA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060658FC mov.l r14,@-r15
    c.r[14] = c.r[15];  // 060658FE mov r15,r14
    c.r[8] = 0x0u;  // 06065900 mov #0,r8
    c.r[1] = ld32(0x060659FCu);  // 06065902 mov.l 0x060659FC,r1
    c.r[1] = ld32(c.r[1]);  // 06065904 mov.l @r1,r1
    c.r[4] = (uint32_t)(int16_t)ld16(0x060659F2u);  // 06065906 mov.w 0x060659F2,r4
    c.r[1] += 1;  // 06065908 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606590A mov.b @r1,r1
    c.r[6] = 0xFu;  // 0606590C mov #15,r6
    c.r[4] &= c.r[1];  // 0606590E and r1,r4
    c.r[4] >>= 2;  // 06065910 shlr2 r4
    c.r[4] >>= 2;  // 06065912 shlr2 r4
    c.r[0] = c.r[4];  // 06065914 mov r4,r0
    c.t = c.r[0] == 0x2u;  // 06065916 cmp/eq #2,r0
    { const bool k = c.t; c.r[6] &= c.r[1]; if (k) { goto L_0606592E; } }  // 06065918 bt/s 0x0606592E ; and r1,r6
    c.r[1] = 0x2u;  // 0606591C mov #2,r1
    c.t = (int32_t)c.r[4] > (int32_t)c.r[1];  // 0606591E cmp/gt r1,r4
    { const bool k = c.t; c.t = c.r[0] == 0x1u; if (k) { goto L_0606594A; } }  // 06065920 bt/s 0x0606594A ; cmp/eq #1,r0
    if (!c.t) { goto L_0606594A; }  // 06065924 bf 0x0606594A
    c.r[1] = ld32(0x06065A00u);  // 06065926 mov.l 0x06065A00,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060659F4u);  // 06065928 mov.w 0x060659F4,r0
    c.r[1] = ld32(c.r[1]); goto L_06065950;  // 0606592A bra 0x06065950 ; mov.l @r1,r1
L_0606592E:
    c.r[1] = ld32(0x06065A04u);  // 0606592E mov.l 0x06065A04,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06065930 mov.b @r1,r2
    c.r[1] = ld32(0x06065A00u);  // 06065932 mov.l 0x06065A00,r1
    c.r[7] = ld32(c.r[1]);  // 06065934 mov.l @r1,r7
    c.r[2] = c.r[2] & 0xFFu;  // 06065936 extu.b r2,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x060659F6u);  // 06065938 mov.w 0x060659F6,r1
    c.macl = c.r[2] * c.r[1];  // 0606593A mul.l r1,r2
    c.r[3] = c.macl;  // 0606593C sts macl,r3
    c.r[3] += c.r[7];  // 0606593E add r7,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x060659F4u);  // 06065940 mov.w 0x060659F4,r1
    c.r[0] = c.r[3];  // 06065942 mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06065944 mov.b @(r0,r1),r1
    c.r[8] = c.r[2]; goto L_06065952;  // 06065946 bra 0x06065952 ; mov r2,r8
L_0606594A:
    c.r[1] = ld32(0x06065A08u);  // 0606594A mov.l 0x06065A08,r1
    c.r[1] = ld32(c.r[1]);  // 0606594C mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060659F8u);  // 0606594E mov.w 0x060659F8,r0
L_06065950:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06065950 mov.b @(r0,r1),r1
L_06065952:
    c.r[7] = c.r[1] & 0xFFu;  // 06065952 extu.b r1,r7
    c.t = (c.r[7] & c.r[7]) == 0;  // 06065954 tst r7,r7
    { const bool k = !c.t; c.r[1] = 0x3u; if (k) { goto L_0606595E; } }  // 06065956 bf/s 0x0606595E ; mov #3,r1
    goto L_06065B40;  // 0606595A bra 0x06065B40 ; nop
L_0606595E:
    c.r[2] = c.r[6];  // 0606595E mov r6,r2
    c.r[2] -= 1;  // 06065960 add #-1,r2
    c.t = c.r[2] > c.r[1];  // 06065962 cmp/hi r1,r2
    { const bool k = !c.t; c.r[1] = 0x0u; if (k) { goto L_0606596C; } }  // 06065964 bf/s 0x0606596C ; mov #0,r1
    goto L_06065A84;  // 06065968 bra 0x06065A84 ; nop
L_0606596C:
    c.r[1] = c.r[2];  // 0606596C mov r2,r1
    c.r[1] += c.r[1];  // 0606596E add r1,r1
    c.r[0] = 0x0606597Cu;  // 06065970 mova 0x0606597C,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06065972 mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 06065974 add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x06065984u: goto L_06065984; case 0x06065A14u: goto L_06065A14; case 0x06065A50u: goto L_06065A50; case 0x06065A70u: goto L_06065A70; default: sh2_call(c, x); return; } }  // 06065976 jmp @r0 ; nop
L_06065984:
    c.r[3] = 0x0u;  // 06065984 mov #0,r3
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[7];  // 06065986 cmp/ge r7,r3
    { const bool k = c.t; c.t = c.r[3] == c.r[7]; if (k) { goto L_060659E8; } }  // 06065988 bt/s 0x060659E8 ; cmp/eq r7,r3
    c.r[1] = ld32(0x06065A0Cu);  // 0606598C mov.l 0x06065A0C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606598E mov.b @r1,r1
    c.r[6] = 0x0u;  // 06065990 mov #0,r6
    c.r[5] = c.r[1] & 0xFFu;  // 06065992 extu.b r1,r5
L_06065994:
    c.t = (c.r[4] & c.r[4]) == 0;  // 06065994 tst r4,r4
    { const bool k = c.t; c.r[0] = c.r[4]; if (k) { goto L_0606599E; } }  // 06065996 bt/s 0x0606599E ; mov r4,r0
    c.t = c.r[0] == 0x3u;  // 0606599A cmp/eq #3,r0
    if (!c.t) { goto L_060659C4; }  // 0606599C bf 0x060659C4
L_0606599E:
    c.r[1] = ld32(0x06065A08u);  // 0606599E mov.l 0x06065A08,r1
    c.r[2] = c.r[3];  // 060659A0 mov r3,r2
    c.r[1] = ld32(c.r[1]);  // 060659A2 mov.l @r1,r1
    c.r[2] += c.r[2];  // 060659A4 add r2,r2
    c.r[0] = c.r[1];  // 060659A6 mov r1,r0
    c.r[1] += c.r[2];  // 060659A8 add r2,r1
    c.r[9] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 060659AA mov.b @(r0,r2),r9
    c.r[1] += 1;  // 060659AC add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060659AE mov.b @r1,r1
    c.r[0] = 0x7Fu;  // 060659B0 mov #127,r0
    c.r[9] &= c.r[0];  // 060659B2 and r0,r9
    c.r[9] <<= 8;  // 060659B4 shll8 r9
    c.r[1] = c.r[1] & 0xFFu;  // 060659B6 extu.b r1,r1
    c.r[1] |= c.r[9];  // 060659B8 or r9,r1
    c.t = c.r[5] == c.r[1];  // 060659BA cmp/eq r1,r5
    { const bool k = !c.t; c.t = c.r[3] == c.r[7]; if (k) { goto L_060659DE; } }  // 060659BC bf/s 0x060659DE ; cmp/eq r7,r3
    goto L_060659E8;  // 060659C0 bra 0x060659E8 ; nop
L_060659C4:
    c.r[1] = ld32(0x06065A00u);  // 060659C4 mov.l 0x06065A00,r1
    c.r[2] = ld32(c.r[1]);  // 060659C6 mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x060659F6u);  // 060659C8 mov.w 0x060659F6,r1
    c.macl = c.r[8] * c.r[1];  // 060659CA mul.l r1,r8
    c.r[1] = c.macl;  // 060659CC sts macl,r1
    c.r[1] += c.r[2];  // 060659CE add r2,r1
    c.r[1] += c.r[6];  // 060659D0 add r6,r1
    c.r[1] += 4;  // 060659D2 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060659D4 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060659D6 extu.b r1,r1
    c.t = c.r[5] == c.r[1];  // 060659D8 cmp/eq r1,r5
    { const bool k = c.t; c.t = c.r[3] == c.r[7]; if (k) { goto L_060659E8; } }  // 060659DA bt/s 0x060659E8 ; cmp/eq r7,r3
L_060659DE:
    c.r[3] += 1;  // 060659DE add #1,r3
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[7];  // 060659E0 cmp/ge r7,r3
    { const bool k = !c.t; c.r[6] += 8; if (k) { SH2_POLL(c); goto L_06065994; } }  // 060659E2 bf/s 0x06065994 ; add #8,r6
    c.t = c.r[3] == c.r[7];  // 060659E6 cmp/eq r7,r3
L_060659E8:
    { const bool k = c.t; c.t = (c.r[4] & c.r[4]) == 0; if (k) { goto L_06065A8A; } }  // 060659E8 bt/s 0x06065A8A ; tst r4,r4
    c.r[1] = ld32(0x06065A10u);  // 060659EC mov.l 0x06065A10,r1
    st8(c.r[1], c.r[3]); goto L_06065A8A;  // 060659EE bra 0x06065A8A ; mov.b r3,@r1
L_06065A14:
    c.r[1] = ld32(0x06065B58u);  // 06065A14 mov.l 0x06065B58,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06065A16 mov.b @r1,r1
    c.r[3] = c.r[1] & 0xFFu;  // 06065A18 extu.b r1,r3
    c.t = c.r[3] >= c.r[7];  // 06065A1A cmp/hs r7,r3
    { const bool k = c.t; c.t = (c.r[4] & c.r[4]) == 0; if (k) { goto L_06065A8A; } }  // 06065A1C bt/s 0x06065A8A ; tst r4,r4
    c.r[7] = ld32(0x06065B5Cu);  // 06065A20 mov.l 0x06065B5C,r7
    { const bool k = c.t; c.r[0] = c.r[4]; if (k) { goto L_06065A2A; } }  // 06065A22 bt/s 0x06065A2A ; mov r4,r0
    c.t = c.r[0] == 0x3u;  // 06065A26 cmp/eq #3,r0
    if (!c.t) { goto L_06065A36; }  // 06065A28 bf 0x06065A36
L_06065A2A:
    c.r[1] = ld32(0x06065B60u);  // 06065A2A mov.l 0x06065B60,r1
    c.r[1] = ld32(c.r[1]);  // 06065A2C mov.l @r1,r1
    c.r[3] += c.r[3];  // 06065A2E add r3,r3
    c.r[1] += c.r[3];  // 06065A30 add r3,r1
    c.r[1] += 1; goto L_06065A4A;  // 06065A32 bra 0x06065A4A ; add #1,r1
L_06065A36:
    c.r[1] = ld32(0x06065B64u);  // 06065A36 mov.l 0x06065B64,r1
    c.r[2] = ld32(c.r[1]);  // 06065A38 mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06065B52u);  // 06065A3A mov.w 0x06065B52,r1
    c.macl = c.r[8] * c.r[1];  // 06065A3C mul.l r1,r8
    c.r[3] <<= 2;  // 06065A3E shll2 r3
    c.r[3] += c.r[3];  // 06065A40 add r3,r3
    c.r[1] = c.macl;  // 06065A42 sts macl,r1
    c.r[1] += c.r[2];  // 06065A44 add r2,r1
    c.r[1] += c.r[3];  // 06065A46 add r3,r1
    c.r[1] += 4;  // 06065A48 add #4,r1
L_06065A4A:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06065A4A mov.b @r1,r1
    st8(c.r[7], c.r[1]); goto L_06065A88;  // 06065A4C bra 0x06065A88 ; mov.b r1,@r7
L_06065A50:
    c.r[6] = ld32(0x06065B58u);  // 06065A50 mov.l 0x06065B58,r6
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[6]);  // 06065A52 mov.b @r6,r3
    c.r[2] = c.r[3] & 0xFFu;  // 06065A54 extu.b r3,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06065A56 tst r2,r2
    { const bool k = c.t; c.r[1] = c.r[7]; if (k) { goto L_06065A64; } }  // 06065A58 bt/s 0x06065A64 ; mov r7,r1
    c.r[1] -= 1;  // 06065A5C add #-1,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 06065A5E cmp/gt r1,r2
    { const bool k = !c.t; c.r[1] = c.r[3]; if (k) { goto L_06065A6A; } }  // 06065A60 bf/s 0x06065A6A ; mov r3,r1
L_06065A64:
    c.r[7] -= 1;  // 06065A64 add #-1,r7
    st8(c.r[6], c.r[7]); goto L_06065A88;  // 06065A66 bra 0x06065A88 ; mov.b r7,@r6
L_06065A6A:
    c.r[1] -= 1;  // 06065A6A add #-1,r1
    st8(c.r[6], c.r[1]); goto L_06065A88;  // 06065A6C bra 0x06065A88 ; mov.b r1,@r6
L_06065A70:
    c.r[2] = ld32(0x06065B58u);  // 06065A70 mov.l 0x06065B58,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06065A72 mov.b @r2,r1
    c.r[1] += 1;  // 06065A74 add #1,r1
    st8(c.r[2], c.r[1]);  // 06065A76 mov.b r1,@r2
    c.r[1] = c.r[1] & 0xFFu;  // 06065A78 extu.b r1,r1
    c.t = c.r[1] >= c.r[7];  // 06065A7A cmp/hs r7,r1
    { const bool k = !c.t; c.r[1] = 0x0u; if (k) { goto L_06065A88; } }  // 06065A7C bf/s 0x06065A88 ; mov #0,r1
    st8(c.r[2], c.r[1]); goto L_06065A88;  // 06065A80 bra 0x06065A88 ; mov.b r1,@r2
L_06065A84:
    c.r[2] = ld32(0x06065B58u);  // 06065A84 mov.l 0x06065B58,r2
    st8(c.r[2], c.r[1]);  // 06065A86 mov.b r1,@r2
L_06065A88:
    c.t = (c.r[4] & c.r[4]) == 0;  // 06065A88 tst r4,r4
L_06065A8A:
    { const bool k = c.t; c.r[0] = c.r[4]; if (k) { goto L_06065A92; } }  // 06065A8A bt/s 0x06065A92 ; mov r4,r0
    c.t = c.r[0] == 0x3u;  // 06065A8E cmp/eq #3,r0
    if (!c.t) { goto L_06065AB8; }  // 06065A90 bf 0x06065AB8
L_06065A92:
    c.r[1] = ld32(0x06065B60u);  // 06065A92 mov.l 0x06065B60,r1
    c.r[2] = ld32(c.r[1]);  // 06065A94 mov.l @r1,r2
    c.r[3] = ld32(0x06065B68u);  // 06065A96 mov.l 0x06065B68,r3
    c.r[3] = ld32(c.r[3]);  // 06065A98 mov.l @r3,r3
    c.r[1] = ld32(0x06065B58u);  // 06065A9A mov.l 0x06065B58,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06065A9C mov.b @r1,r1
    c.r[0] = c.r[2];  // 06065A9E mov r2,r0
    c.r[1] = c.r[1] & 0xFFu;  // 06065AA0 extu.b r1,r1
    c.r[1] += c.r[1];  // 06065AA2 add r1,r1
    c.r[2] += c.r[1];  // 06065AA4 add r1,r2
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06065AA6 mov.b @(r0,r1),r7
    c.r[2] += 1;  // 06065AA8 add #1,r2
    c.r[0] = 0x7Fu;  // 06065AAA mov #127,r0
    c.r[7] &= c.r[0];  // 06065AAC and r0,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06065AAE mov.b @r2,r1
    c.r[7] <<= 8;  // 06065AB0 shll8 r7
    c.r[1] = c.r[1] & 0xFFu;  // 06065AB2 extu.b r1,r1
    c.r[1] |= c.r[7]; goto L_06065ADA;  // 06065AB4 bra 0x06065ADA ; or r7,r1
L_06065AB8:
    c.r[1] = ld32(0x06065B64u);  // 06065AB8 mov.l 0x06065B64,r1
    c.r[2] = ld32(c.r[1]);  // 06065ABA mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06065B52u);  // 06065ABC mov.w 0x06065B52,r1
    c.macl = c.r[8] * c.r[1];  // 06065ABE mul.l r1,r8
    c.r[3] = c.macl;  // 06065AC0 sts macl,r3
    c.r[1] = ld32(0x06065B58u);  // 06065AC2 mov.l 0x06065B58,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06065AC4 mov.b @r1,r1
    c.r[3] += c.r[2];  // 06065AC6 add r2,r3
    c.r[1] = c.r[1] & 0xFFu;  // 06065AC8 extu.b r1,r1
    c.r[1] <<= 2;  // 06065ACA shll2 r1
    c.r[1] += c.r[1];  // 06065ACC add r1,r1
    c.r[3] += c.r[1];  // 06065ACE add r1,r3
    c.r[3] += 4;  // 06065AD0 add #4,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06065AD2 mov.b @r3,r1
    c.r[7] = ld32(0x06065B68u);  // 06065AD4 mov.l 0x06065B68,r7
    c.r[1] = c.r[1] & 0xFFu;  // 06065AD6 extu.b r1,r1
    c.r[3] = ld32(c.r[7]);  // 06065AD8 mov.l @r7,r3
L_06065ADA:
    c.r[1] <<= 2;  // 06065ADA shll2 r1
    c.r[1] <<= 2;  // 06065ADC shll2 r1
    c.r[3] += c.r[1];  // 06065ADE add r1,r3
    c.r[3] += 3;  // 06065AE0 add #3,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06065AE2 mov.b @r3,r1
    c.r[0] = 0x3u;  // 06065AE4 mov #3,r0
    c.r[6] = c.r[1];  // 06065AE6 mov r1,r6
    c.t = c.r[6] & 1; c.r[6] >>= 1;  // 06065AE8 shlr r6
    c.r[1] = ld32(0x06065B6Cu);  // 06065AEA mov.l 0x06065B6C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06065AEC mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06065AEE extu.b r1,r1
    c.t = c.r[1] == c.r[4];  // 06065AF0 cmp/eq r4,r1
    { const bool k = !c.t; c.r[6] &= c.r[0]; if (k) { goto L_06065B32; } }  // 06065AF2 bf/s 0x06065B32 ; and r0,r6
    c.r[1] = ld32(0x06065B70u);  // 06065AF6 mov.l 0x06065B70,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06065AF8 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06065AFA extu.b r1,r1
    c.t = c.r[1] == c.r[6];  // 06065AFC cmp/eq r6,r1
    { const bool k = c.t; c.t = (c.r[1] & c.r[1]) == 0; if (k) { goto L_06065B38; } }  // 06065AFE bt/s 0x06065B38 ; tst r1,r1
    { const bool k = c.t; c.r[0] = c.r[4]; if (k) { goto L_06065B0A; } }  // 06065B02 bt/s 0x06065B0A ; mov r4,r0
    c.t = (c.r[6] & c.r[6]) == 0;  // 06065B06 tst r6,r6
    if (!c.t) { goto L_06065B38; }  // 06065B08 bf 0x06065B38
L_06065B0A:
    c.t = c.r[0] == 0x2u;  // 06065B0A cmp/eq #2,r0
    if (!c.t) { goto L_06065B32; }  // 06065B0C bf 0x06065B32
    c.r[1] = ld32(0x06065B74u);  // 06065B0E mov.l 0x06065B74,r1
    c.r[3] = ld32(c.r[1]);  // 06065B10 mov.l @r1,r3
    c.r[1] = ld32(0x06065B78u);  // 06065B12 mov.l 0x06065B78,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06065B14 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06065B16 extu.b r1,r1
    c.r[2] = c.r[1];  // 06065B18 mov r1,r2
    c.r[2] <<= 2;  // 06065B1A shll2 r2
    c.r[2] += c.r[1];  // 06065B1C add r1,r2
    c.r[2] <<= 2;  // 06065B1E shll2 r2
    c.r[3] += c.r[2];  // 06065B20 add r2,r3
    c.r[3] += 50;  // 06065B22 add #50,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06065B24 mov.b @r3,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06065B26 extu.b r1,r0
    c.r[0] >>= 2;  // 06065B28 shlr2 r0
    c.r[0] >>= 2;  // 06065B2A shlr2 r0
    c.r[0] >>= 2;  // 06065B2C shlr2 r0
    c.t = c.r[0] == 0x2u;  // 06065B2E cmp/eq #2,r0
    if (c.t) { goto L_06065B38; }  // 06065B30 bt 0x06065B38
L_06065B32:
    c.r[2] = ld32(0x06065B58u);  // 06065B32 mov.l 0x06065B58,r2
    c.r[1] = 0x0u;  // 06065B34 mov #0,r1
    st8(c.r[2], c.r[1]);  // 06065B36 mov.b r1,@r2
L_06065B38:
    c.r[1] = ld32(0x06065B70u);  // 06065B38 mov.l 0x06065B70,r1
    st8(c.r[1], c.r[6]);  // 06065B3A mov.b r6,@r1
    c.r[1] = ld32(0x06065B6Cu);  // 06065B3C mov.l 0x06065B6C,r1
    st8(c.r[1], c.r[4]);  // 06065B3E mov.b r4,@r1
L_06065B40:
    c.r[2] = ld32(0x06065B7Cu);  // 06065B40 mov.l 0x06065B7C,r2
    c.r[1] = 0xFFFFFFFFu;  // 06065B42 mov #-1,r1
    st8(c.r[2], c.r[1]);  // 06065B44 mov.b r1,@r2
    c.r[15] = c.r[14];  // 06065B46 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06065B48 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06065B4A mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06065B54u);  // 06065B4C mov.w 0x06065B54,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06065B4E rts ; mov.l @r15+,r8
}

void f_06065B80(SH2Context& c) {
    ran[1497] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06065B80 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06065B82 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06065B84 mov r15,r14
    c.r[0] = ld32(0x06065B98u);  // 06065B86 mov.l 0x06065B98,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06065B8Cu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06065B8Cu) return; }  // 06065B88 jsr @r0 ; mov #1,r4
    c.r[15] = c.r[14];  // 06065B8C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06065B8E lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x06065B96u);  // 06065B90 mov.w 0x06065B96,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06065B92 rts ; mov.l @r15+,r14
}

void f_06065B9C(SH2Context& c) {
    ran[1498] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06065B9C mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06065B9E mov r15,r14
    c.r[3] = ld32(0x06065C10u);  // 06065BA0 mov.l 0x06065C10,r3
    c.r[2] = ld32(c.r[3]);  // 06065BA2 mov.l @r3,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06065C0Au);  // 06065BA4 mov.w 0x06065C0A,r1
    c.r[0] = c.r[2];  // 06065BA6 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06065BA8 mov.b @(r0,r1),r1
    c.r[5] = 0x0u; goto L_06065BFA;  // 06065BAA bra 0x06065BFA ; mov #0,r5
L_06065BAE:
    c.r[2] = ld32(c.r[3]);  // 06065BAE mov.l @r3,r2
    c.r[1] += c.r[1];  // 06065BB0 add r1,r1
    c.r[2] += c.r[1];  // 06065BB2 add r1,r2
    c.r[2] += 1;  // 06065BB4 add #1,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06065BB6 mov.b @r2,r2
    c.r[1] = ld32(0x06065C14u);  // 06065BB8 mov.l 0x06065C14,r1
    c.r[3] = ld32(c.r[1]);  // 06065BBA mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06065BBC extu.b r2,r2
    c.r[1] = c.r[2];  // 06065BBE mov r2,r1
    c.r[1] <<= 2;  // 06065BC0 shll2 r1
    c.r[1] += c.r[2];  // 06065BC2 add r2,r1
    c.r[1] <<= 2;  // 06065BC4 shll2 r1
    c.r[3] += c.r[1];  // 06065BC6 add r1,r3
    c.r[6] = c.r[3];  // 06065BC8 mov r3,r6
    c.r[6] += 51;  // 06065BCA add #51,r6
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[6]);  // 06065BCC mov.b @r6,r7
    c.r[0] = c.r[7];  // 06065BCE mov r7,r0
    c.r[0] >>= 2;  // 06065BD0 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06065BD2 shlr r0
    c.r[0] &= 0x1u;  // 06065BD4 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06065BD6 tst r0,r0
    { const bool k = !c.t; c.r[3] += 50; if (k) { goto L_06065BF0; } }  // 06065BD8 bf/s 0x06065BF0 ; add #50,r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06065BDC mov.b @r3,r0
    c.r[1] = 0x1u;  // 06065BDE mov #1,r1
    c.r[0] &= 0x3Fu;  // 06065BE0 and #63,r0
    c.r[0] -= 62;  // 06065BE2 add #-62,r0
    c.r[2] = c.r[0] & 0xFFFFu;  // 06065BE4 extu.w r0,r2
    c.t = c.r[2] > c.r[1];  // 06065BE6 cmp/hi r1,r2
    { const bool k = c.t; c.r[0] = c.r[7]; if (k) { goto L_06065BF0; } }  // 06065BE8 bt/s 0x06065BF0 ; mov r7,r0
    c.r[0] |= 0x8u;  // 06065BEC or #8,r0
    st8(c.r[6], c.r[0]);  // 06065BEE mov.b r0,@r6
L_06065BF0:
    c.r[3] = ld32(0x06065C10u);  // 06065BF0 mov.l 0x06065C10,r3
    c.r[1] = ld32(c.r[3]);  // 06065BF2 mov.l @r3,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06065C0Au);  // 06065BF4 mov.w 0x06065C0A,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06065BF6 mov.b @(r0,r1),r1
    c.r[5] += 1;  // 06065BF8 add #1,r5
L_06065BFA:
    c.r[1] = c.r[1] & 0xFFu;  // 06065BFA extu.b r1,r1
    c.t = (int32_t)c.r[5] >= (int32_t)c.r[1];  // 06065BFC cmp/ge r1,r5
    { const bool k = !c.t; c.r[1] = c.r[5]; if (k) { SH2_POLL(c); goto L_06065BAE; } }  // 06065BFE bf/s 0x06065BAE ; mov r5,r1
    c.r[15] = c.r[14];  // 06065C02 mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x06065C0Cu);  // 06065C04 mov.w 0x06065C0C,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06065C06 rts ; mov.l @r15+,r14
}

void f_06065C18(SH2Context& c) {
    ran[1499] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06065C18 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06065C1A sts.l pr,@-r15
    c.r[1] = ld32(0x06065C38u);  // 06065C1C mov.l 0x06065C38,r1
    c.r[1] = ld32(c.r[1]);  // 06065C1E mov.l @r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06065C20 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06065C22 extu.b r1,r0
    c.r[0] <<= 2;  // 06065C24 shll2 r0
    c.r[1] = ld32(0x06065C3Cu);  // 06065C26 mov.l 0x06065C3C,r1
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 06065C28 mov.l @(r0,r1),r0
    { const uint32_t x = c.r[0]; c.pr = 0x06065C2Eu; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06065C2Eu) return; }  // 06065C2A jsr @r0 ; mov r15,r14
    c.r[15] = c.r[14];  // 06065C2E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06065C30 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06065C32 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[0] & 0xFFFFu; c.pc = x; return; }  // 06065C34 rts ; extu.w r0,r0
}

void f_06065C40(SH2Context& c) {
    ran[1500] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06065C40 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06065C42 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06065C44 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06065C46 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06065C48 mov r15,r14
    c.r[1] = ld32(0x06065D64u);  // 06065C4A mov.l 0x06065D64,r1
    c.r[5] = ld32(c.r[1] + 4);  // 06065C4C mov.l @(4,r1),r5
    c.r[9] = 0x0u;  // 06065C4E mov #0,r9
    c.r[2] = (uint32_t)(int16_t)ld16(0x06065D5Eu);  // 06065C50 mov.w 0x06065D5E,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[5]); goto L_06065C5E;  // 06065C52 bra 0x06065C5E ; mov.b @r5,r1
L_06065C56:
    c.r[1] += 1;  // 06065C56 add #1,r1
    c.r[9] = c.r[1] & 0xFFu;  // 06065C58 extu.b r1,r9
    c.r[5] += 2;  // 06065C5A add #2,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[5]);  // 06065C5C mov.b @r5,r1
L_06065C5E:
    c.r[1] = c.r[1] & 0xFFu;  // 06065C5E extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 06065C60 cmp/eq r2,r1
    { const bool k = !c.t; c.r[1] = c.r[9]; if (k) { SH2_POLL(c); goto L_06065C56; } }  // 06065C62 bf/s 0x06065C56 ; mov r9,r1
    c.r[1] = ld32(0x06065D68u);  // 06065C66 mov.l 0x06065D68,r1
    c.r[2] = ld32(c.r[1]);  // 06065C68 mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06065D60u);  // 06065C6A mov.w 0x06065D60,r1
    c.r[0] = c.r[2];  // 06065C6C mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06065C6E mov.b @(r0,r1),r1
    c.r[7] = 0x0u;  // 06065C70 mov #0,r7
    c.r[3] = c.r[1] & 0xFFu;  // 06065C72 extu.b r1,r3
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[3];  // 06065C74 cmp/ge r3,r7
    if (c.t) { goto L_06065CC4; }  // 06065C76 bt 0x06065CC4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06065C78 mov.b @(r0,r7),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06065C7A extu.b r1,r1
    c.r[1] >>= 2;  // 06065C7C shlr2 r1
    c.r[1] >>= 2;  // 06065C7E shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06065C80 shlr r1
    c.r[1] >>= 2;  // 06065C82 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06065C84 tst r1,r1
    if (!c.t) { goto L_06065CC4; }  // 06065C86 bf 0x06065CC4
    c.r[7] = 0x1u;  // 06065C88 mov #1,r7
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[3];  // 06065C8A cmp/ge r3,r7
    { const bool k = c.t; c.r[5] = 0x2u; if (k) { goto L_06065CC4; } }  // 06065C8C bt/s 0x06065CC4 ; mov #2,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 06065C90 mov.b @(r0,r5),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06065C92 extu.b r1,r1
    c.r[1] >>= 2;  // 06065C94 shlr2 r1
    c.r[1] >>= 2;  // 06065C96 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06065C98 shlr r1
    c.r[1] >>= 2;  // 06065C9A shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06065C9C tst r1,r1
    if (!c.t) { goto L_06065CC4; }  // 06065C9E bf 0x06065CC4
    c.r[6] = c.r[2];  // 06065CA0 mov r2,r6
    c.r[2] = c.r[3];  // 06065CA2 mov r3,r2
    c.r[3] = c.r[5];  // 06065CA4 mov r5,r3
    c.r[7] += 1;  // 06065CA6 add #1,r7
L_06065CA8:
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[2];  // 06065CA8 cmp/ge r2,r7
    { const bool k = c.t; c.r[3] += 2; if (k) { goto L_06065CC4; } }  // 06065CAA bt/s 0x06065CC4 ; add #2,r3
    c.r[0] = c.r[3];  // 06065CAE mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 06065CB0 mov.b @(r0,r6),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06065CB2 extu.b r1,r1
    c.r[1] >>= 2;  // 06065CB4 shlr2 r1
    c.r[1] >>= 2;  // 06065CB6 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06065CB8 shlr r1
    c.r[1] >>= 2;  // 06065CBA shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06065CBC tst r1,r1
    { const bool k = c.t; c.r[7] += 1; if (k) { SH2_POLL(c); goto L_06065CA8; } }  // 06065CBE bt/s 0x06065CA8 ; add #1,r7
    c.r[7] -= 1;  // 06065CC2 add #-1,r7
L_06065CC4:
    c.r[1] = ld32(0x06065D68u);  // 06065CC4 mov.l 0x06065D68,r1
    c.r[3] = ld32(c.r[1]);  // 06065CC6 mov.l @r1,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x06065D60u);  // 06065CC8 mov.w 0x06065D60,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06065CCA mov.b @(r0,r3),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06065CCC extu.b r1,r1
    c.t = c.r[7] == c.r[1];  // 06065CCE cmp/eq r1,r7
    { const bool k = !c.t; c.r[2] = c.r[7]; if (k) { goto L_06065CD8; } }  // 06065CD0 bf/s 0x06065CD8 ; mov r7,r2
    goto L_06065E3E;  // 06065CD4 bra 0x06065E3E ; nop
L_06065CD8:
    c.r[2] += c.r[2];  // 06065CD8 add r2,r2
    c.r[1] = c.r[3];  // 06065CDA mov r3,r1
    c.r[1] += c.r[2];  // 06065CDC add r2,r1
    c.r[1] += 1;  // 06065CDE add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06065CE0 mov.b @r1,r1
    c.r[0] = c.r[3];  // 06065CE2 mov r3,r0
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06065CE4 mov.b @(r0,r2),r7
    c.r[8] = c.r[1] & 0xFFu;  // 06065CE6 extu.b r1,r8
    c.r[1] = 0x7Fu;  // 06065CE8 mov #127,r1
    c.r[1] &= c.r[7];  // 06065CEA and r7,r1
    st8(c.r[0] + c.r[2], c.r[1]);  // 06065CEC mov.b r1,@(r0,r2)
    c.r[1] = ld32(0x06065D6Cu);  // 06065CEE mov.l 0x06065D6C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06065CF0 mov.b @r1,r1
    c.r[4] = c.r[1] & 0xFFu;  // 06065CF2 extu.b r1,r4
    c.t = c.r[4] >= c.r[9];  // 06065CF4 cmp/hs r9,r4
    { const bool k = c.t; c.r[4] += c.r[4]; if (k) { goto L_06065D84; } }  // 06065CF6 bt/s 0x06065D84 ; add r4,r4
    c.r[1] = ld32(0x06065D64u);  // 06065CFA mov.l 0x06065D64,r1
    c.r[7] = ld32(c.r[1] + 4);  // 06065CFC mov.l @(4,r1),r7
    c.r[5] = c.r[7];  // 06065CFE mov r7,r5
    c.r[1] = ld32(0x06065D70u);  // 06065D00 mov.l 0x06065D70,r1
    c.r[2] = ld32(c.r[1]);  // 06065D02 mov.l @r1,r2
    c.r[5] += c.r[4];  // 06065D04 add r4,r5
    c.r[1] = 0x1Eu;  // 06065D06 mov #30,r1
    c.macl = c.r[8] * c.r[1];  // 06065D08 mul.l r1,r8
    c.r[5] += 1;  // 06065D0A add #1,r5
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[5]);  // 06065D0C mov.b @r5,r5
    c.r[1] = c.macl;  // 06065D0E sts macl,r1
    c.r[1] += c.r[2];  // 06065D10 add r2,r1
    c.r[1] += 15;  // 06065D12 add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06065D14 mov.b @r1,r1
    c.r[2] = ld32(0x06065D74u);  // 06065D16 mov.l 0x06065D74,r2
    c.r[3] = ld32(c.r[2]);  // 06065D18 mov.l @r2,r3
    c.r[1] = c.r[1] & 0xFFu;  // 06065D1A extu.b r1,r1
    c.r[2] = c.r[1];  // 06065D1C mov r1,r2
    c.r[2] += c.r[2];  // 06065D1E add r2,r2
    c.r[2] += c.r[1];  // 06065D20 add r1,r2
    c.r[2] <<= 2;  // 06065D22 shll2 r2
    c.r[0] = c.r[2];  // 06065D24 mov r2,r0
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 06065D26 mov.w @(r0,r3),r6
    c.r[5] = c.r[5] & 0xFFu;  // 06065D28 extu.b r5,r5
    c.r[0] = c.r[7];  // 06065D2A mov r7,r0
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[4]);  // 06065D2C mov.b @(r0,r4),r4
    c.r[6] = c.r[6] & 0xFFFFu;  // 06065D2E extu.w r6,r6
    c.r[0] = ld32(0x06065D78u);  // 06065D30 mov.l 0x06065D78,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06065D36u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06065D36u) return; }  // 06065D32 jsr @r0 ; extu.b r4,r4
    c.r[1] = c.r[0];  // 06065D36 mov r0,r1
    c.r[8] = c.r[1] & 0xFFu;  // 06065D38 extu.b r1,r8
    c.r[1] = ld32(0x06065D7Cu);  // 06065D3A mov.l 0x06065D7C,r1
    c.r[2] = c.r[8];  // 06065D3C mov r8,r2
    c.r[2] <<= 2;  // 06065D3E shll2 r2
    c.r[2] <<= 2;  // 06065D40 shll2 r2
    c.r[0] = 0x7Fu;  // 06065D42 mov #127,r0
    c.r[4] = (uint32_t)(int32_t)(int16_t)c.r[8];  // 06065D44 exts.w r8,r4
    c.r[1] = ld32(c.r[1]);  // 06065D46 mov.l @r1,r1
    c.r[6] = 0x0u;  // 06065D48 mov #0,r6
    c.r[2] += c.r[1];  // 06065D4A add r1,r2
    c.r[2] += 3;  // 06065D4C add #3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06065D4E mov.b @r2,r1
    c.r[1] &= c.r[0];  // 06065D50 and r0,r1
    st8(c.r[2], c.r[1]);  // 06065D52 mov.b r1,@r2
    c.r[1] = ld32(0x06065D80u);  // 06065D54 mov.l 0x06065D80,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06065D5Au; c.r[5] = 0xEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06065D5Au) return; }  // 06065D56 jsr @r1 ; mov #14,r5
    goto L_06065E32;  // 06065D5A bra 0x06065E32 ; nop
L_06065D84:
    c.r[0] = ld32(0x06065E54u);  // 06065D84 mov.l 0x06065E54,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06065D8Au; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06065D8Au) return; }  // 06065D86 jsr @r0 ; mov #0,r4
    c.r[1] = ld32(0x06065E58u);  // 06065D8A mov.l 0x06065E58,r1
    c.r[2] = ld32(c.r[1]);  // 06065D8C mov.l @r1,r2
    c.r[7] = c.r[0];  // 06065D8E mov r0,r7
    c.r[1] = (uint32_t)(int16_t)ld16(0x06065E4Cu);  // 06065D90 mov.w 0x06065E4C,r1
    c.r[0] = c.r[2];  // 06065D92 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06065D94 mov.b @(r0,r1),r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06065E4Eu);  // 06065D96 mov.w 0x06065E4E,r0
    c.r[1] &= c.r[0];  // 06065D98 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06065D9A tst r1,r1
    { const bool k = c.t; c.t = (int32_t)c.r[7] >= 0; if (k) { goto L_06065DEA; } }  // 06065D9C bt/s 0x06065DEA ; cmp/pz r7
    if (!c.t) { goto L_06065DEA; }  // 06065DA0 bf 0x06065DEA
    c.r[1] = ld32(0x06065E5Cu);  // 06065DA2 mov.l 0x06065E5C,r1
    c.r[2] = ld32(c.r[1]);  // 06065DA4 mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 06065DA6 mov #30,r1
    c.macl = c.r[8] * c.r[1];  // 06065DA8 mul.l r1,r8
    c.r[1] = c.macl;  // 06065DAA sts macl,r1
    c.r[1] += c.r[2];  // 06065DAC add r2,r1
    c.r[1] += 15;  // 06065DAE add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06065DB0 mov.b @r1,r1
    c.r[2] = ld32(0x06065E60u);  // 06065DB2 mov.l 0x06065E60,r2
    c.r[3] = ld32(c.r[2]);  // 06065DB4 mov.l @r2,r3
    c.r[1] = c.r[1] & 0xFFu;  // 06065DB6 extu.b r1,r1
    c.r[2] = c.r[1];  // 06065DB8 mov r1,r2
    c.r[2] += c.r[2];  // 06065DBA add r2,r2
    c.r[2] += c.r[1];  // 06065DBC add r1,r2
    c.r[2] <<= 2;  // 06065DBE shll2 r2
    c.r[0] = c.r[2];  // 06065DC0 mov r2,r0
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 06065DC2 mov.w @(r0,r3),r6
    c.r[1] = ld32(0x06065E64u);  // 06065DC4 mov.l 0x06065E64,r1
    c.r[6] = c.r[6] & 0xFFFFu;  // 06065DC6 extu.w r6,r6
    c.r[2] = c.r[7];  // 06065DC8 mov r7,r2
    c.r[3] = ld32(c.r[1]);  // 06065DCA mov.l @r1,r3
    c.r[2] <<= 2;  // 06065DCC shll2 r2
    c.r[2] <<= 2;  // 06065DCE shll2 r2
    c.r[1] = c.r[2];  // 06065DD0 mov r2,r1
    c.r[1] += c.r[3];  // 06065DD2 add r3,r1
    c.r[1] += 1;  // 06065DD4 add #1,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06065DD6 mov.b @r1,r5
    c.r[0] = c.r[2];  // 06065DD8 mov r2,r0
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06065DDA mov.b @(r0,r3),r4
    c.r[5] = c.r[5] & 0xFFu;  // 06065DDC extu.b r5,r5
    c.r[0] = ld32(0x06065E68u);  // 06065DDE mov.l 0x06065E68,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06065DE4u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06065DE4u) return; }  // 06065DE0 jsr @r0 ; extu.b r4,r4
    c.r[1] = c.r[0];  // 06065DE4 mov r0,r1
    c.r[8] = c.r[1] & 0xFFu; goto L_06065E32;  // 06065DE6 bra 0x06065E32 ; extu.b r1,r8
L_06065DEA:
    c.r[1] = ld32(0x06065E5Cu);  // 06065DEA mov.l 0x06065E5C,r1
    c.r[2] = ld32(c.r[1]);  // 06065DEC mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 06065DEE mov #30,r1
    c.macl = c.r[8] * c.r[1];  // 06065DF0 mul.l r1,r8
    c.r[4] = (uint32_t)(int16_t)ld16(0x06065E50u);  // 06065DF2 mov.w 0x06065E50,r4
    c.r[1] = c.macl;  // 06065DF4 sts macl,r1
    c.r[1] += c.r[2];  // 06065DF6 add r2,r1
    c.r[1] += 15;  // 06065DF8 add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06065DFA mov.b @r1,r1
    c.r[2] = ld32(0x06065E60u);  // 06065DFC mov.l 0x06065E60,r2
    c.r[3] = ld32(c.r[2]);  // 06065DFE mov.l @r2,r3
    c.r[1] = c.r[1] & 0xFFu;  // 06065E00 extu.b r1,r1
    c.r[2] = c.r[1];  // 06065E02 mov r1,r2
    c.r[2] += c.r[2];  // 06065E04 add r2,r2
    c.r[2] += c.r[1];  // 06065E06 add r1,r2
    c.r[2] <<= 2;  // 06065E08 shll2 r2
    c.r[0] = c.r[2];  // 06065E0A mov r2,r0
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 06065E0C mov.w @(r0,r3),r6
    c.r[5] = c.r[4];  // 06065E0E mov r4,r5
    c.r[0] = ld32(0x06065E68u);  // 06065E10 mov.l 0x06065E68,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06065E16u; c.r[6] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06065E16u) return; }  // 06065E12 jsr @r0 ; extu.w r6,r6
    c.r[1] = c.r[0];  // 06065E16 mov r0,r1
    c.r[8] = c.r[1] & 0xFFu;  // 06065E18 extu.b r1,r8
    c.r[2] = ld32(0x06065E64u);  // 06065E1A mov.l 0x06065E64,r2
    c.r[7] = c.r[8];  // 06065E1C mov r8,r7
    c.r[7] <<= 2;  // 06065E1E shll2 r7
    c.r[7] <<= 2;  // 06065E20 shll2 r7
    c.r[3] = 0x40u;  // 06065E22 mov #64,r3
    c.r[1] = ld32(c.r[2]);  // 06065E24 mov.l @r2,r1
    c.r[0] = c.r[7];  // 06065E26 mov r7,r0
    st8(c.r[0] + c.r[1], c.r[3]);  // 06065E28 mov.b r3,@(r0,r1)
    c.r[1] = ld32(c.r[2]);  // 06065E2A mov.l @r2,r1
    c.r[7] += c.r[1];  // 06065E2C add r1,r7
    c.r[7] += 1;  // 06065E2E add #1,r7
    st8(c.r[7], c.r[3]);  // 06065E30 mov.b r3,@r7
L_06065E32:
    c.r[1] = ld32(0x06065E6Cu);  // 06065E32 mov.l 0x06065E6C,r1
    st8(c.r[1], c.r[8]);  // 06065E34 mov.b r8,@r1
    c.r[5] = c.r[8];  // 06065E36 mov r8,r5
    c.r[1] = ld32(0x06065E70u);  // 06065E38 mov.l 0x06065E70,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06065E3Eu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06065E3Eu) return; }  // 06065E3A jsr @r1 ; mov #0,r4
L_06065E3E:
    c.r[15] = c.r[14];  // 06065E3E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06065E40 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06065E42 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06065E44 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06065E52u);  // 06065E46 mov.w 0x06065E52,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06065E48 rts ; mov.l @r15+,r8
}

void f_06065E74(SH2Context& c) {
    ran[1501] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06065E74 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06065E76 sts.l pr,@-r15
    c.r[1] = ld32(0x06065E94u);  // 06065E78 mov.l 0x06065E94,r1
    c.r[1] = ld32(c.r[1]);  // 06065E7A mov.l @r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06065E7C mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06065E7E extu.b r1,r0
    c.r[0] <<= 2;  // 06065E80 shll2 r0
    c.r[1] = ld32(0x06065E98u);  // 06065E82 mov.l 0x06065E98,r1
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 06065E84 mov.l @(r0,r1),r0
    { const uint32_t x = c.r[0]; c.pr = 0x06065E8Au; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06065E8Au) return; }  // 06065E86 jsr @r0 ; mov r15,r14
    c.r[15] = c.r[14];  // 06065E8A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06065E8C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06065E8E mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[0] & 0xFFFFu; c.pc = x; return; }  // 06065E90 rts ; extu.w r0,r0
}

void f_06065E9C(SH2Context& c) {
    ran[1502] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06065E9C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06065E9E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06065EA0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06065EA2 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06065EA4 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06065EA6 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06065EA8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06065EAA sts.l pr,@-r15
    c.r[15] -= 72;  // 06065EAC add #-72,r15
    c.r[14] = c.r[15];  // 06065EAE mov r15,r14
    c.r[0] = 0x0u;  // 06065EB0 mov #0,r0
    st32(c.r[14] + 32, c.r[0]);  // 06065EB2 mov.l r0,@(32,r14)
    c.r[1] = ld32(0x06066060u);  // 06065EB4 mov.l 0x06066060,r1
    c.r[2] = ld32(c.r[1]);  // 06065EB6 mov.l @r1,r2
    c.r[9] = 0x0u;  // 06065EB8 mov #0,r9
    c.r[2] += 1;  // 06065EBA add #1,r2
    st32(c.r[1], c.r[2]);  // 06065EBC mov.l r2,@r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06065EBE mov.b @r2,r2
    c.r[1] = 0x10u;  // 06065EC0 mov #16,r1
    c.r[1] &= c.r[2];  // 06065EC2 and r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06065EC4 tst r1,r1
    { const bool k = c.t; st32(c.r[14] + 24, c.r[9]); if (k) { goto L_06065ECE; } }  // 06065EC6 bt/s 0x06065ECE ; mov.l r9,@(24,r14)
    c.r[0] = 0x1u;  // 06065ECA mov #1,r0
    st32(c.r[14] + 24, c.r[0]);  // 06065ECC mov.l r0,@(24,r14)
L_06065ECE:
    c.r[1] = 0x20u;  // 06065ECE mov #32,r1
    c.r[1] &= c.r[2];  // 06065ED0 and r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06065ED2 tst r1,r1
    c.r[9] = 0x0u;  // 06065ED4 mov #0,r9
    { const bool k = c.t; st32(c.r[14] + 20, c.r[9]); if (k) { goto L_06065EDE; } }  // 06065ED6 bt/s 0x06065EDE ; mov.l r9,@(20,r14)
    c.r[0] = 0x1u;  // 06065EDA mov #1,r0
    st32(c.r[14] + 20, c.r[0]);  // 06065EDC mov.l r0,@(20,r14)
L_06065EDE:
    c.r[0] = c.r[2];  // 06065EDE mov r2,r0
    c.r[0] &= 0x1u;  // 06065EE0 and #1,r0
    st32(c.r[14] + 28, c.r[0]);  // 06065EE2 mov.l r0,@(28,r14)
    c.r[9] = ld32(0x06066064u);  // 06065EE4 mov.l 0x06066064,r9
    st32(c.r[14] + 40, c.r[9]);  // 06065EE6 mov.l r9,@(40,r14)
    c.r[10] = ld32(0x06066068u);  // 06065EE8 mov.l 0x06066068,r10
    c.r[5] = 0x22u;  // 06065EEA mov #34,r5
    c.r[4] = c.r[10];  // 06065EEC mov r10,r4
    c.r[0] = ld32(c.r[14] + 40);  // 06065EEE mov.l @(40,r14),r0
    c.r[9] = ld32(0x0606606Cu);  // 06065EF0 mov.l 0x0606606C,r9
    { const uint32_t x = c.r[9]; c.pr = 0x06065EF6u; st32(c.r[14] + 36, c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06065EF6u) return; }  // 06065EF2 jsr @r9 ; mov.l r0,@(36,r14)
    c.r[1] = c.r[0];  // 06065EF6 mov r0,r1
    c.r[5] = 0x0u;  // 06065EF8 mov #0,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06065EFEu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06065EFEu) return; }  // 06065EFA jsr @r9 ; mov r1,r4
    c.r[7] = c.r[0];  // 06065EFE mov r0,r7
    c.r[11] = ld32(0x06066070u);  // 06065F00 mov.l 0x06066070,r11
    c.r[13] = ld32(0x06066074u);  // 06065F02 mov.l 0x06066074,r13
    c.r[1] = ld32(c.r[11]);  // 06065F04 mov.l @r11,r1
    c.r[12] = ld32(0x06066078u);  // 06065F06 mov.l 0x06066078,r12
    c.r[1] += 37;  // 06065F08 add #37,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06065F0A mov.b @r1,r3
    c.r[0] = 0x3u;  // 06065F0C mov #3,r0
    c.r[2] = ld32(c.r[12]);  // 06065F0E mov.l @r12,r2
    c.r[3] = c.r[3] & 0xFFu;  // 06065F10 extu.b r3,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 06065F12 mov.b @r13,r1
    c.r[3] >>= 2;  // 06065F14 shlr2 r3
    c.r[3] >>= 2;  // 06065F16 shlr2 r3
    c.r[1] = c.r[1] & 0xFFu;  // 06065F18 extu.b r1,r1
    c.r[1] <<= 2;  // 06065F1A shll2 r1
    c.r[1] <<= 2;  // 06065F1C shll2 r1
    c.r[1] += c.r[2];  // 06065F1E add r2,r1
    c.r[1] += 3;  // 06065F20 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06065F22 mov.b @r1,r1
    c.r[5] = 0x22u;  // 06065F24 mov #34,r5
    c.r[2] = c.r[1];  // 06065F26 mov r1,r2
    c.r[2] >>= 2;  // 06065F28 shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 06065F2A shlr r2
    c.r[2] &= c.r[0];  // 06065F2C and r0,r2
    c.r[1] = c.r[3];  // 06065F2E mov r3,r1
    c.r[1] <<= 2;  // 06065F30 shll2 r1
    c.r[1] += c.r[3];  // 06065F32 add r3,r1
    c.r[1] += c.r[7];  // 06065F34 add r7,r1
    c.r[1] += c.r[2];  // 06065F36 add r2,r1
    c.r[1] += 2;  // 06065F38 add #2,r1
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06065F3A mov.b @r1,r8
    c.r[4] = c.r[10];  // 06065F3C mov r10,r4
    { const uint32_t x = c.r[9]; c.pr = 0x06065F42u; c.r[8] = c.r[8] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06065F42u) return; }  // 06065F3E jsr @r9 ; extu.b r8,r8
    c.r[1] = c.r[0];  // 06065F42 mov r0,r1
    c.r[5] = 0x1u;  // 06065F44 mov #1,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06065F4Au; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06065F4Au) return; }  // 06065F46 jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 06065F4A mov r0,r1
    c.r[5] = c.r[8];  // 06065F4C mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06065F52u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06065F52u) return; }  // 06065F4E jsr @r9 ; mov r1,r4
    st32(c.r[14] + 44, c.r[0]);  // 06065F52 mov.l r0,@(44,r14)
    c.r[1] = ld32(c.r[11]);  // 06065F54 mov.l @r11,r1
    c.r[1] += 36;  // 06065F56 add #36,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06065F58 mov.b @r1,r1
    c.r[9] = ld32(c.r[14] + 28);  // 06065F5A mov.l @(28,r14),r9
    c.r[1] = c.r[1] & 0xFFu;  // 06065F5C extu.b r1,r1
    st32(c.r[14] + 52, c.r[1]);  // 06065F5E mov.l r1,@(52,r14)
    c.r[0] = ld32(c.r[14] + 52);  // 06065F60 mov.l @(52,r14),r0
    c.t = (c.r[9] & c.r[9]) == 0;  // 06065F62 tst r9,r9
    { const bool k = c.t; st32(c.r[14] + 48, c.r[0]); if (k) { goto L_06065F6C; } }  // 06065F64 bt/s 0x06065F6C ; mov.l r0,@(48,r14)
    c.r[9] = ld32(0x0606607Cu);  // 06065F68 mov.l 0x0606607C,r9
    st32(c.r[14] + 48, c.r[9]);  // 06065F6A mov.l r9,@(48,r14)
L_06065F6C:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 06065F6C mov.b @r13,r1
    c.r[4] = (uint32_t)(int16_t)ld16(0x06066058u);  // 06065F6E mov.w 0x06066058,r4
    c.r[2] = ld32(c.r[12]);  // 06065F70 mov.l @r12,r2
    c.r[6] = 0x3Fu;  // 06065F72 mov #63,r6
    c.r[8] = ld32(c.r[14] + 28);  // 06065F74 mov.l @(28,r14),r8
    c.r[3] = ld32(0x06066080u);  // 06065F76 mov.l 0x06066080,r3
    c.r[9] = ld32(c.r[14] + 20);  // 06065F78 mov.l @(20,r14),r9
    c.r[1] = c.r[1] & 0xFFu;  // 06065F7A extu.b r1,r1
    c.r[1] <<= 2;  // 06065F7C shll2 r1
    c.r[1] <<= 2;  // 06065F7E shll2 r1
    c.r[1] += c.r[2];  // 06065F80 add r2,r1
    c.r[1] += 3;  // 06065F82 add #3,r1
    c.r[13] = 0x0u;  // 06065F84 mov #0,r13
    c.r[8] |= c.r[9];  // 06065F86 or r9,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06065F88 mov.b @r1,r1
    c.r[2] = ld32(0x06066084u);  // 06065F8A mov.l 0x06066084,r2
    c.r[0] = c.r[1];  // 06065F8C mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06065F8E shlr r0
    c.r[0] &= 0x3u;  // 06065F90 and #3,r0
    st32(c.r[14] + 16, c.r[0]);  // 06065F92 mov.l r0,@(16,r14)
L_06065F94:
    c.r[10] = 0x0u;  // 06065F94 mov #0,r10
    c.r[7] = c.r[8] & 0xFFu;  // 06065F96 extu.b r8,r7
    c.r[0] = c.r[10];  // 06065F98 mov r10,r0
L_06065F9A:
    c.r[0] += c.r[0];  // 06065F9A add r0,r0
    c.t = (c.r[7] & c.r[7]) == 0;  // 06065F9C tst r7,r7
    { const bool k = !c.t; st16(c.r[0] + c.r[3], c.r[4]); if (k) { goto L_06065FA6; } }  // 06065F9E bf/s 0x06065FA6 ; mov.w r4,@(r0,r3)
    c.r[1] = 0xFFFFFFFFu; goto L_06065FA8;  // 06065FA2 bra 0x06065FA8 ; mov #-1,r1
L_06065FA6:
    c.r[1] = 0x0u;  // 06065FA6 mov #0,r1
L_06065FA8:
    c.r[0] = c.r[2];  // 06065FA8 mov r2,r0
    st8(c.r[0] + c.r[10], c.r[1]);  // 06065FAA mov.b r1,@(r0,r10)
    c.r[10] += 1;  // 06065FAC add #1,r10
    c.t = (int32_t)c.r[10] > (int32_t)c.r[6];  // 06065FAE cmp/gt r6,r10
    { const bool k = !c.t; c.r[0] = c.r[10]; if (k) { SH2_POLL(c); goto L_06065F9A; } }  // 06065FB0 bf/s 0x06065F9A ; mov r10,r0
    c.r[2] += 64;  // 06065FB4 add #64,r2
    c.r[5] = (uint32_t)(int16_t)ld16(0x0606605Au);  // 06065FB6 mov.w 0x0606605A,r5
    c.r[13] += 1;  // 06065FB8 add #1,r13
    c.t = (int32_t)c.r[13] > (int32_t)c.r[6];  // 06065FBA cmp/gt r6,r13
    { const bool k = !c.t; c.r[3] += c.r[5]; if (k) { SH2_POLL(c); goto L_06065F94; } }  // 06065FBC bf/s 0x06065F94 ; add r5,r3
    c.r[7] = ld32(0x06066088u);  // 06065FC0 mov.l 0x06066088,r7
    c.r[4] = ld32(0x06066074u);  // 06065FC2 mov.l 0x06066074,r4
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[4]);  // 06065FC4 mov.b @r4,r2
    c.r[1] = ld32(0x06066078u);  // 06065FC6 mov.l 0x06066078,r1
    c.r[1] = ld32(c.r[1]);  // 06065FC8 mov.l @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 06065FCA extu.b r2,r2
    c.r[2] <<= 2;  // 06065FCC shll2 r2
    c.r[2] <<= 2;  // 06065FCE shll2 r2
    c.r[3] = c.r[2];  // 06065FD0 mov r2,r3
    c.r[3] += c.r[1];  // 06065FD2 add r1,r3
    c.r[0] = c.r[2];  // 06065FD4 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06065FD6 mov.b @(r0,r1),r1
    c.r[3] += 1;  // 06065FD8 add #1,r3
    c.r[9] = c.r[1] & 0xFFu;  // 06065FDA extu.b r1,r9
    st32(c.r[14] + 8, c.r[9]);  // 06065FDC mov.l r9,@(8,r14)
    st8(c.r[7], c.r[1]);  // 06065FDE mov.b r1,@r7
    c.r[2] = ld32(0x0606608Cu);  // 06065FE0 mov.l 0x0606608C,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06065FE2 mov.b @r3,r1
    c.r[9] = ld32(0x06066080u);  // 06065FE4 mov.l 0x06066080,r9
    c.r[0] = c.r[1] & 0xFFu;  // 06065FE6 extu.b r1,r0
    st32(c.r[14] + 12, c.r[0]);  // 06065FE8 mov.l r0,@(12,r14)
    st8(c.r[2], c.r[1]);  // 06065FEA mov.b r1,@r2
    c.macl = c.r[0] * c.r[5];  // 06065FEC mul.l r5,r0
    c.r[3] = ld32(c.r[14] + 8);  // 06065FEE mov.l @(8,r14),r3
    c.r[1] = 0x0u;  // 06065FF0 mov #0,r1
    c.r[3] += c.r[3];  // 06065FF2 add r3,r3
    c.r[2] = c.macl;  // 06065FF4 sts macl,r2
    c.r[2] += c.r[9];  // 06065FF6 add r9,r2
    c.r[0] = c.r[3];  // 06065FF8 mov r3,r0
    st16(c.r[0] + c.r[2], c.r[1]);  // 06065FFA mov.w r1,@(r0,r2)
    c.r[9] = ld32(0x06066084u);  // 06065FFC mov.l 0x06066084,r9
    c.r[2] = ld32(c.r[14] + 12);  // 06065FFE mov.l @(12,r14),r2
    c.r[1] = 0x0u;  // 06066000 mov #0,r1
    c.r[0] = ld32(c.r[14] + 8);  // 06066002 mov.l @(8,r14),r0
    c.r[2] <<= 2;  // 06066004 shll2 r2
    c.r[2] <<= 2;  // 06066006 shll2 r2
    c.r[2] <<= 2;  // 06066008 shll2 r2
    c.r[2] += c.r[9];  // 0606600A add r9,r2
    st8(c.r[0] + c.r[2], c.r[1]);  // 0606600C mov.b r1,@(r0,r2)
    c.r[1] = ld32(0x06066060u);  // 0606600E mov.l 0x06066060,r1
    c.r[1] = ld32(c.r[1]);  // 06066010 mov.l @r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06066012 mov.b @r1,r1
    c.r[9] = 0x40u;  // 06066014 mov #64,r9
    c.r[1] &= c.r[9];  // 06066016 and r9,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06066018 tst r1,r1
    if (!c.t) { goto L_060660E0; }  // 0606601A bf 0x060660E0
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[4]);  // 0606601C mov.b @r4,r4
    c.r[1] = ld32(0x06066090u);  // 0606601E mov.l 0x06066090,r1
    c.r[5] = c.r[14];  // 06066020 mov r14,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06066026u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06066026u) return; }  // 06066022 jsr @r1 ; extu.b r4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[14]);  // 06066026 mov.b @r14,r1
    c.r[2] = c.r[1] & 0xFFu;  // 06066028 extu.b r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606605Cu);  // 0606602A mov.w 0x0606605C,r1
    c.t = c.r[2] == c.r[1];  // 0606602C cmp/eq r1,r2
    { const bool k = c.t; c.r[9] = ld32(c.r[14] + 8); if (k) { goto L_060660E2; } }  // 0606602E bt/s 0x060660E2 ; mov.l @(8,r14),r9
    c.r[0] = 0x1u;  // 06066032 mov #1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606605Eu);  // 06066034 mov.w 0x0606605E,r1
    c.t = c.r[2] == c.r[1];  // 06066036 cmp/eq r1,r2
    { const bool k = !c.t; st32(c.r[14] + 32, c.r[0]); if (k) { goto L_060660A0; } }  // 06066038 bf/s 0x060660A0 ; mov.l r0,@(32,r14)
    c.r[7] = ld32(0x06066094u);  // 0606603C mov.l 0x06066094,r7
    c.r[1] = c.r[14];  // 0606603E mov r14,r1
    c.r[1] += 2;  // 06066040 add #2,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06066042 mov.b @r1,r5
    c.r[6] = ld32(0x06066098u);  // 06066044 mov.l 0x06066098,r6
    c.r[1] = c.r[14];  // 06066046 mov r14,r1
    c.r[1] += 1;  // 06066048 add #1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606604A mov.b @r1,r4
    c.r[5] = c.r[5] & 0xFFu;  // 0606604C extu.b r5,r5
    c.r[1] = ld32(0x0606609Cu);  // 0606604E mov.l 0x0606609C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06066054u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06066054u) return; }  // 06066050 jsr @r1 ; extu.b r4,r4
    c.r[9] = ld32(c.r[14] + 8); goto L_060660E2;  // 06066054 bra 0x060660E2 ; mov.l @(8,r14),r9
L_060660A0:
    c.r[13] = 0x0u;  // 060660A0 mov #0,r13
    c.r[10] = ld32(0x060661A8u);  // 060660A2 mov.l 0x060661A8,r10
    c.r[8] = 0x0u;  // 060660A4 mov #0,r8
    c.r[0] = c.r[14];  // 060660A6 mov r14,r0
L_060660A8:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[13]);  // 060660A8 mov.b @(r0,r13),r1
    c.r[3] = c.r[1] & 0xFFu;  // 060660AA extu.b r1,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x060661A0u);  // 060660AC mov.w 0x060661A0,r1
    c.t = c.r[3] == c.r[1];  // 060660AE cmp/eq r1,r3
    { const bool k = c.t; c.r[0] = c.r[3]; if (k) { goto L_060660D2; } }  // 060660B0 bt/s 0x060660D2 ; mov r3,r0
    c.r[6] = ld32(0x060661ACu);  // 060660B4 mov.l 0x060661AC,r6
    c.r[6] += c.r[8];  // 060660B6 add r8,r6
    c.r[1] = ld32(0x060661B0u);  // 060660B8 mov.l 0x060661B0,r1
    c.r[2] = ld32(c.r[1]);  // 060660BA mov.l @r1,r2
    c.r[0] <<= 2;  // 060660BC shll2 r0
    c.r[0] <<= 2;  // 060660BE shll2 r0
    c.r[1] = c.r[0];  // 060660C0 mov r0,r1
    c.r[1] += c.r[2];  // 060660C2 add r2,r1
    c.r[1] += 1;  // 060660C4 add #1,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060660C6 mov.b @r1,r5
    c.r[7] = ld32(0x060661B4u);  // 060660C8 mov.l 0x060661B4,r7
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 060660CA mov.b @(r0,r2),r4
    c.r[5] = c.r[5] & 0xFFu;  // 060660CC extu.b r5,r5
    { const uint32_t x = c.r[10]; c.pr = 0x060660D2u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060660D2u) return; }  // 060660CE jsr @r10 ; extu.b r4,r4
L_060660D2:
    c.r[1] = (uint32_t)(int16_t)ld16(0x060661A2u);  // 060660D2 mov.w 0x060661A2,r1
    c.r[8] += c.r[1];  // 060660D4 add r1,r8
    c.r[13] += 1;  // 060660D6 add #1,r13
    c.r[1] = 0x4u;  // 060660D8 mov #4,r1
    c.t = (int32_t)c.r[13] > (int32_t)c.r[1];  // 060660DA cmp/gt r1,r13
    { const bool k = !c.t; c.r[0] = c.r[14]; if (k) { SH2_POLL(c); goto L_060660A8; } }  // 060660DC bf/s 0x060660A8 ; mov r14,r0
L_060660E0:
    c.r[9] = ld32(c.r[14] + 8);  // 060660E0 mov.l @(8,r14),r9
L_060660E2:
    c.r[13] = 0x1u;  // 060660E2 mov #1,r13
    c.r[9] += c.r[9];  // 060660E4 add r9,r9
    st32(c.r[14] + 56, c.r[9]);  // 060660E6 mov.l r9,@(56,r14)
    c.r[2] = c.r[13];  // 060660E8 mov r13,r2
L_060660EA:
    c.r[2] >>= 2;  // 060660EA shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 060660EC shlr r2
    c.r[0] = 0x1u;  // 060660EE mov #1,r0
    c.r[2] &= c.r[0];  // 060660F0 and r0,r2
    c.r[1] = c.r[13];  // 060660F2 mov r13,r1
    c.r[1] >>= 2;  // 060660F4 shlr2 r1
    c.r[9] = ld32(c.r[14] + 12);  // 060660F6 mov.l @(12,r14),r9
    c.r[1] &= c.r[0];  // 060660F8 and r0,r1
    c.r[0] = ld32(c.r[14] + 8);  // 060660FA mov.l @(8,r14),r0
    c.r[2] += c.r[9];  // 060660FC add r9,r2
    c.r[2] -= c.r[1];  // 060660FE sub r1,r2
    c.r[12] = c.r[2] & 0xFFu;  // 06066100 extu.b r2,r12
    c.r[2] = 0x2u;  // 06066102 mov #2,r2
    c.r[2] &= c.r[13];  // 06066104 and r13,r2
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 06066106 shar r2
    c.r[2] += c.r[0];  // 06066108 add r0,r2
    c.r[1] = 0x1u;  // 0606610A mov #1,r1
    c.r[1] &= c.r[13];  // 0606610C and r13,r1
    c.r[2] -= c.r[1];  // 0606610E sub r1,r2
    c.r[1] = ld32(0x060661B8u);  // 06066110 mov.l 0x060661B8,r1
    c.r[1] += 76;  // 06066112 add #76,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06066114 mov.b @r1,r1
    c.r[11] = c.r[2] & 0xFFu;  // 06066116 extu.b r2,r11
    c.r[1] = c.r[1] & 0xFFu;  // 06066118 extu.b r1,r1
    c.t = c.r[11] > c.r[1];  // 0606611A cmp/hi r1,r11
    if (!c.t) { goto L_06066122; }  // 0606611C bf 0x06066122
    goto L_060662CC;  // 0606611E bra 0x060662CC ; nop
L_06066122:
    c.r[1] = ld32(0x060661B8u);  // 06066122 mov.l 0x060661B8,r1
    c.r[1] += 77;  // 06066124 add #77,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06066126 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06066128 extu.b r1,r1
    c.t = c.r[12] > c.r[1];  // 0606612A cmp/hi r1,r12
    { const bool k = !c.t; c.r[9] = 0x40u; if (k) { goto L_06066134; } }  // 0606612C bf/s 0x06066134 ; mov #64,r9
    goto L_060662CC;  // 06066130 bra 0x060662CC ; nop
L_06066134:
    c.r[1] = (uint32_t)(int16_t)ld16(0x060661A4u);  // 06066134 mov.w 0x060661A4,r1
    c.macl = c.r[12] * c.r[9];  // 06066136 mul.l r9,r12
    c.r[0] = ld32(0x060661B8u);  // 06066138 mov.l 0x060661B8,r0
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 0606613A mov.l @(r0,r1),r1
    c.r[2] = c.macl;  // 0606613C sts macl,r2
    c.r[2] += c.r[1];  // 0606613E add r1,r2
    c.r[0] = c.r[2];  // 06066140 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 06066142 mov.b @(r0,r11),r1
    c.r[8] = c.r[1] & 0xFFu;  // 06066144 extu.b r1,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 06066146 tst r8,r8
    { const bool k = c.t; c.r[0] = ld32(c.r[14] + 44); if (k) { goto L_06066150; } }  // 06066148 bt/s 0x06066150 ; mov.l @(44,r14),r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0606614C mov.b @(r0,r8),r1
    c.r[8] = c.r[1] & 0xFFu;  // 0606614E extu.b r1,r8
L_06066150:
    c.r[1] = ld32(0x060661BCu);  // 06066150 mov.l 0x060661BC,r1
    c.r[1] = ld32(c.r[1]);  // 06066152 mov.l @r1,r1
    c.r[0] = c.macl;  // 06066154 sts macl,r0
    c.r[0] += c.r[1];  // 06066156 add r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 06066158 mov.b @(r0,r11),r1
    c.t = (c.r[8] & c.r[8]) == 0;  // 0606615A tst r8,r8
    { const bool k = c.t; c.r[2] = c.r[1] & 0xFFu; if (k) { goto L_0606618C; } }  // 0606615C bt/s 0x0606618C ; extu.b r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x060661A0u);  // 06066160 mov.w 0x060661A0,r1
    c.t = c.r[2] == c.r[1];  // 06066162 cmp/eq r1,r2
    { const bool k = c.t; c.r[9] = ld32(c.r[14] + 12); if (k) { goto L_060661C4; } }  // 06066164 bt/s 0x060661C4 ; mov.l @(12,r14),r9
    c.r[1] = ld32(0x060661B0u);  // 06066168 mov.l 0x060661B0,r1
    c.r[1] = ld32(c.r[1]);  // 0606616A mov.l @r1,r1
    c.r[2] <<= 2;  // 0606616C shll2 r2
    c.r[2] <<= 2;  // 0606616E shll2 r2
    c.r[2] += c.r[1];  // 06066170 add r1,r2
    c.r[2] += 3;  // 06066172 add #3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06066174 mov.b @r2,r1
    c.r[9] = 0x3u;  // 06066176 mov #3,r9
    c.r[0] = ld32(c.r[14] + 16);  // 06066178 mov.l @(16,r14),r0
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0606617A shlr r1
    c.r[1] &= c.r[9];  // 0606617C and r9,r1
    c.t = c.r[1] == c.r[0];  // 0606617E cmp/eq r0,r1
    { const bool k = c.t; c.r[9] = ld32(c.r[14] + 12); if (k) { goto L_060661C4; } }  // 06066180 bt/s 0x060661C4 ; mov.l @(12,r14),r9
    c.r[9] = ld32(c.r[14] + 24);  // 06066184 mov.l @(24,r14),r9
    c.t = (c.r[9] & c.r[9]) == 0;  // 06066186 tst r9,r9
    { const bool k = !c.t; c.r[9] = ld32(c.r[14] + 12); if (k) { goto L_060661C4; } }  // 06066188 bf/s 0x060661C4 ; mov.l @(12,r14),r9
L_0606618C:
    c.r[11] += c.r[11];  // 0606618C add r11,r11
    c.r[0] = (uint32_t)(int16_t)ld16(0x060661A6u);  // 0606618E mov.w 0x060661A6,r0
    c.macl = c.r[12] * c.r[0];  // 06066190 mul.l r0,r12
    c.r[9] = ld32(0x060661C0u);  // 06066192 mov.l 0x060661C0,r9
    c.r[1] = 0x0u;  // 06066194 mov #0,r1
    c.r[2] = c.macl;  // 06066196 sts macl,r2
    c.r[2] += c.r[9];  // 06066198 add r9,r2
    c.r[0] = c.r[11];  // 0606619A mov r11,r0
    st16(c.r[0] + c.r[2], c.r[1]); goto L_060662CC;  // 0606619C bra 0x060662CC ; mov.w r1,@(r0,r2)
L_060661C4:
    c.r[0] = 0x40u;  // 060661C4 mov #64,r0
    c.macl = c.r[9] * c.r[0];  // 060661C6 mul.l r0,r9
    c.r[2] = (uint32_t)(int16_t)ld16(0x06066284u);  // 060661C8 mov.w 0x06066284,r2
    c.r[2] &= c.r[8];  // 060661CA and r8,r2
    c.r[1] = c.macl;  // 060661CC sts macl,r1
    c.r[9] = ld32(0x06066288u);  // 060661CE mov.l 0x06066288,r9
    c.r[0] = ld32(c.r[14] + 8);  // 060661D0 mov.l @(8,r14),r0
    c.r[1] += c.r[9];  // 060661D2 add r9,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060661D4 mov.b @(r0,r1),r1
    c.r[2] >>= 2;  // 060661D6 shlr2 r2
    c.r[2] >>= 2;  // 060661D8 shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 060661DA shlr r2
    c.r[2] >>= 2;  // 060661DC shlr2 r2
    c.r[9] = ld32(c.r[14] + 12);  // 060661DE mov.l @(12,r14),r9
    c.r[1] = c.r[1] & 0xFFu;  // 060661E0 extu.b r1,r1
    c.r[2] += c.r[1];  // 060661E2 add r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06066284u);  // 060661E4 mov.w 0x06066284,r0
    c.macl = c.r[9] * c.r[0];  // 060661E6 mul.l r0,r9
    c.r[10] = c.r[2] & 0xFFFFu;  // 060661E8 extu.w r2,r10
    c.r[2] = 0x3Fu;  // 060661EA mov #63,r2
    c.r[9] = c.macl;  // 060661EC sts macl,r9
    c.r[0] = ld32(0x0606628Cu);  // 060661EE mov.l 0x0606628C,r0
    c.r[9] += c.r[0];  // 060661F0 add r0,r9
    c.r[0] = ld32(c.r[14] + 56);  // 060661F2 mov.l @(56,r14),r0
    c.r[2] &= c.r[8];  // 060661F4 and r8,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[9]);  // 060661F6 mov.w @(r0,r9),r1
    st32(c.r[14] + 60, c.r[9]);  // 060661F8 mov.l r9,@(60,r14)
    c.r[2] += c.r[1];  // 060661FA add r1,r2
    c.r[9] = ld32(c.r[14] + 48);  // 060661FC mov.l @(48,r14),r9
    c.r[8] = c.r[2] & 0xFFFFu;  // 060661FE extu.w r2,r8
    c.t = c.r[8] > c.r[9];  // 06066200 cmp/hi r9,r8
    { const bool k = c.t; c.r[1] = c.r[11]; if (k) { goto L_060662CC; } }  // 06066202 bt/s 0x060662CC ; mov r11,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06066284u);  // 06066206 mov.w 0x06066284,r0
    c.macl = c.r[12] * c.r[0];  // 06066208 mul.l r0,r12
    c.r[1] += c.r[1];  // 0606620A add r1,r1
    c.r[9] = ld32(0x0606628Cu);  // 0606620C mov.l 0x0606628C,r9
    c.r[2] = c.macl;  // 0606620E sts macl,r2
    c.r[2] += c.r[9];  // 06066210 add r9,r2
    c.r[0] = c.r[1];  // 06066212 mov r1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 06066214 mov.w @(r0,r2),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06066216 extu.w r1,r1
    c.t = c.r[1] > c.r[8];  // 06066218 cmp/hi r8,r1
    { const bool k = !c.t; c.r[9] = ld32(c.r[14] + 32); if (k) { goto L_060662CC; } }  // 0606621A bf/s 0x060662CC ; mov.l @(32,r14),r9
    c.t = (c.r[9] & c.r[9]) == 0;  // 0606621E tst r9,r9
    { const bool k = c.t; c.r[0] = ld32(c.r[14] + 28); if (k) { goto L_06066236; } }  // 06066220 bt/s 0x06066236 ; mov.l @(28,r14),r0
    c.r[0] = ld32(0x06066290u);  // 06066224 mov.l 0x06066290,r0
    c.r[6] = c.r[14];  // 06066226 mov r14,r6
    c.r[5] = c.r[12];  // 06066228 mov r12,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0606622Eu; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606622Eu) return; }  // 0606622A jsr @r0 ; mov r11,r4
    c.r[1] = c.r[0] & 0xFFu;  // 0606622E extu.b r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06066230 tst r1,r1
    { const bool k = c.t; c.r[0] = ld32(c.r[14] + 28); if (k) { goto L_060662CC; } }  // 06066232 bt/s 0x060662CC ; mov.l @(28,r14),r0
L_06066236:
    c.t = (c.r[0] & c.r[0]) == 0;  // 06066236 tst r0,r0
    { const bool k = c.t; c.r[0] = ld32(c.r[14] + 20); if (k) { goto L_0606629C; } }  // 06066238 bt/s 0x0606629C ; mov.l @(20,r14),r0
    c.r[4] = c.r[8];  // 0606623C mov r8,r4
    c.r[4] -= 1;  // 0606623E add #-1,r4
    c.r[5] = ld32(c.r[14] + 52);  // 06066240 mov.l @(52,r14),r5
    c.r[7] = ld32(0x06066294u);  // 06066242 mov.l 0x06066294,r7
    { const uint32_t x = c.r[7]; c.pr = 0x06066248u; c.r[9] = ld32(c.r[14] + 60); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06066248u) return; }  // 06066244 jsr @r7 ; mov.l @(60,r14),r9
    c.r[10] = c.r[0];  // 06066248 mov r0,r10
    c.r[0] = ld32(c.r[14] + 56);  // 0606624A mov.l @(56,r14),r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[9]);  // 0606624C mov.w @(r0,r9),r1
    c.r[5] = ld32(c.r[14] + 52);  // 0606624E mov.l @(52,r14),r5
    c.r[6] = c.r[1] & 0xFFFFu;  // 06066250 extu.w r1,r6
    c.r[4] = c.r[6];  // 06066252 mov r6,r4
    { const uint32_t x = c.r[7]; c.pr = 0x06066258u; c.r[4] -= 1; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06066258u) return; }  // 06066254 jsr @r7 ; add #-1,r4
    c.r[7] = c.r[0];  // 06066258 mov r0,r7
    c.t = c.r[10] == c.r[7];  // 0606625A cmp/eq r7,r10
    { const bool k = c.t; c.r[1] = c.r[11]; if (k) { goto L_060662B0; } }  // 0606625C bt/s 0x060662B0 ; mov r11,r1
    c.r[10] = c.r[8];  // 06066260 mov r8,r10
    c.r[4] = c.r[8];  // 06066262 mov r8,r4
    c.r[1] = ld32(0x06066298u);  // 06066264 mov.l 0x06066298,r1
    c.r[9] = 0x36u;  // 06066266 mov #54,r9
    c.r[5] = ld32(c.r[14] + 52);  // 06066268 mov.l @(52,r14),r5
    c.r[9] += c.r[14];  // 0606626A add r14,r9
    { const uint32_t x = c.r[1]; c.pr = 0x06066270u; c.r[9] = (uint32_t)(int16_t)ld16(c.r[9]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06066270u) return; }  // 0606626C jsr @r1 ; mov.w @r9,r9
    c.r[1] = c.r[0];  // 06066270 mov r0,r1
    c.macl = (c.r[1] & 0xFFFFu) * (c.r[9] & 0xFFFFu);  // 06066272 mulu.w r9,r1
    c.r[0] = ld32(c.r[14] + 56);  // 06066274 mov.l @(56,r14),r0
    c.r[10] -= c.r[6];  // 06066276 sub r6,r10
    c.r[9] = ld32(c.r[14] + 60);  // 06066278 mov.l @(60,r14),r9
    c.r[1] = c.macl;  // 0606627A sts macl,r1
    st16(c.r[0] + c.r[9], c.r[1]);  // 0606627C mov.w r1,@(r0,r9)
    c.r[1] += c.r[10];  // 0606627E add r10,r1
    c.r[8] = c.r[1] & 0xFFFFu; goto L_060662AE;  // 06066280 bra 0x060662AE ; extu.w r1,r8
L_0606629C:
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606629C tst r0,r0
    { const bool k = !c.t; c.r[9] = 0x40u; if (k) { goto L_060662AE; } }  // 0606629E bf/s 0x060662AE ; mov #64,r9
    c.macl = c.r[12] * c.r[9];  // 060662A2 mul.l r9,r12
    c.r[0] = ld32(0x06066420u);  // 060662A4 mov.l 0x06066420,r0
    c.r[1] = c.macl;  // 060662A6 sts macl,r1
    c.r[1] += c.r[0];  // 060662A8 add r0,r1
    c.r[0] = c.r[1];  // 060662AA mov r1,r0
    st8(c.r[0] + c.r[11], c.r[10]);  // 060662AC mov.b r10,@(r0,r11)
L_060662AE:
    c.r[1] = c.r[11];  // 060662AE mov r11,r1
L_060662B0:
    c.r[9] = (uint32_t)(int16_t)ld16(0x0606641Au);  // 060662B0 mov.w 0x0606641A,r9
    c.macl = c.r[12] * c.r[9];  // 060662B2 mul.l r9,r12
    c.r[1] += c.r[1];  // 060662B4 add r1,r1
    c.r[0] = ld32(0x06066424u);  // 060662B6 mov.l 0x06066424,r0
    c.r[2] = c.macl;  // 060662B8 sts macl,r2
    c.r[2] += c.r[0];  // 060662BA add r0,r2
    c.r[0] = c.r[1];  // 060662BC mov r1,r0
    st16(c.r[0] + c.r[2], c.r[8]);  // 060662BE mov.w r8,@(r0,r2)
    c.r[12] <<= 8;  // 060662C0 shll8 r12
    c.r[9] = ld32(c.r[14] + 36);  // 060662C2 mov.l @(36,r14),r9
    c.r[12] |= c.r[11];  // 060662C4 or r11,r12
    st16(c.r[9], c.r[12]);  // 060662C6 mov.w r12,@r9
    c.r[9] += 2;  // 060662C8 add #2,r9
    st32(c.r[14] + 36, c.r[9]);  // 060662CA mov.l r9,@(36,r14)
L_060662CC:
    c.r[13] += c.r[13];  // 060662CC add r13,r13
    c.r[1] = 0xFu;  // 060662CE mov #15,r1
    c.t = (int32_t)c.r[13] > (int32_t)c.r[1];  // 060662D0 cmp/gt r1,r13
    { const bool k = c.t; c.r[2] = c.r[13]; if (k) { goto L_060662DA; } }  // 060662D2 bt/s 0x060662DA ; mov r13,r2
    SH2_POLL(c); goto L_060660EA;  // 060662D6 bra 0x060660EA ; nop
L_060662DA:
    c.r[1] = ld32(c.r[14] + 40);  // 060662DA mov.l @(40,r14),r1
    c.r[1] += 1;  // 060662DC add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060662DE mov.b @r1,r1
    c.r[0] = ld32(c.r[14] + 40);  // 060662E0 mov.l @(40,r14),r0
    c.r[1] = c.r[1] & 0xFFu;  // 060662E2 extu.b r1,r1
    st32(c.r[14] + 8, c.r[1]);  // 060662E4 mov.l r1,@(8,r14)
    c.r[0] += 2;  // 060662E6 add #2,r0
    st32(c.r[14] + 40, c.r[0]);  // 060662E8 mov.l r0,@(40,r14)
    c.r[0] -= 2;  // 060662EA add #-2,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0]);  // 060662EC mov.w @r0,r1
    c.r[9] = ld32(c.r[14] + 36);  // 060662EE mov.l @(36,r14),r9
    c.r[1] >>= 8;  // 060662F0 shlr8 r1
    c.r[1] = c.r[1] & 0xFFu;  // 060662F2 extu.b r1,r1
    st32(c.r[14] + 12, c.r[1]);  // 060662F4 mov.l r1,@(12,r14)
    c.r[1] = ld32(0x06066428u);  // 060662F6 mov.l 0x06066428,r1
    c.t = c.r[9] > c.r[1];  // 060662F8 cmp/hi r1,r9
    { const bool k = !c.t; c.r[9] = ld32(c.r[14] + 40); if (k) { goto L_06066304; } }  // 060662FA bf/s 0x06066304 ; mov.l @(40,r14),r9
    c.r[0] = ld32(0x0606642Cu);  // 060662FE mov.l 0x0606642C,r0
    st32(c.r[14] + 36, c.r[0]);  // 06066300 mov.l r0,@(36,r14)
    c.r[9] = ld32(c.r[14] + 40);  // 06066302 mov.l @(40,r14),r9
L_06066304:
    c.t = c.r[9] > c.r[1];  // 06066304 cmp/hi r1,r9
    { const bool k = !c.t; c.r[1] = ld32(c.r[14] + 36); if (k) { goto L_06066310; } }  // 06066306 bf/s 0x06066310 ; mov.l @(36,r14),r1
    c.r[0] = ld32(0x0606642Cu);  // 0606630A mov.l 0x0606642C,r0
    st32(c.r[14] + 40, c.r[0]);  // 0606630C mov.l r0,@(40,r14)
    c.r[1] = ld32(c.r[14] + 36);  // 0606630E mov.l @(36,r14),r1
L_06066310:
    c.r[0] = ld32(c.r[14] + 40);  // 06066310 mov.l @(40,r14),r0
    c.r[1] += 2;  // 06066312 add #2,r1
    c.t = c.r[0] == c.r[1];  // 06066314 cmp/eq r1,r0
    { const bool k = c.t; c.r[9] = ld32(c.r[14] + 8); if (k) { goto L_0606631E; } }  // 06066316 bt/s 0x0606631E ; mov.l @(8,r14),r9
    SH2_POLL(c); goto L_060660E2;  // 0606631A bra 0x060660E2 ; nop
L_0606631E:
    c.r[13] = 0x0u;  // 0606631E mov #0,r13
    c.r[0] = ld32(0x06066420u);  // 06066320 mov.l 0x06066420,r0
    c.r[9] = 0x40u;  // 06066322 mov #64,r9
    c.r[9] += c.r[14];  // 06066324 add r14,r9
    st32(c.r[9], c.r[0]);  // 06066326 mov.l r0,@r9
    c.r[0] = 0x0u;  // 06066328 mov #0,r0
    c.r[9] = 0x44u;  // 0606632A mov #68,r9
    c.r[9] += c.r[14];  // 0606632C add r14,r9
    st32(c.r[9], c.r[0]);  // 0606632E mov.l r0,@r9
    c.r[12] = ld32(0x06066424u);  // 06066330 mov.l 0x06066424,r12
L_06066332:
    c.r[10] = 0x0u;  // 06066332 mov #0,r10
    c.r[11] = 0x0u;  // 06066334 mov #0,r11
L_06066336:
    c.r[1] = ld32(0x06066430u);  // 06066336 mov.l 0x06066430,r1
    c.r[9] = 0x44u;  // 06066338 mov #68,r9
    c.r[1] = ld32(c.r[1]);  // 0606633A mov.l @r1,r1
    c.r[9] += c.r[14];  // 0606633C add r14,r9
    c.r[9] = ld32(c.r[9]);  // 0606633E mov.l @r9,r9
    c.r[1] += c.r[9];  // 06066340 add r9,r1
    c.r[0] = c.r[1];  // 06066342 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 06066344 mov.b @(r0,r10),r1
    c.r[2] = c.r[1] & 0xFFu;  // 06066346 extu.b r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606641Cu);  // 06066348 mov.w 0x0606641C,r1
    c.t = c.r[2] == c.r[1];  // 0606634A cmp/eq r1,r2
    { const bool k = !c.t; c.r[0] = c.r[11]; if (k) { goto L_06066354; } }  // 0606634C bf/s 0x06066354 ; mov r11,r0
    goto L_060664FA;  // 06066350 bra 0x060664FA ; nop
L_06066354:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[12]);  // 06066354 mov.w @(r0,r12),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06066356 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06066358 tst r1,r1
    if (c.t) { goto L_06066360; }  // 0606635A bt 0x06066360
    goto L_060664FA;  // 0606635C bra 0x060664FA ; nop
L_06066360:
    c.r[1] = ld32(0x06066434u);  // 06066360 mov.l 0x06066434,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06066362 mov.b @r1,r1
    c.r[6] = c.r[1] & 0xFFu;  // 06066364 extu.b r1,r6
    c.t = c.r[2] == c.r[6];  // 06066366 cmp/eq r6,r2
    if (!c.t) { goto L_0606636E; }  // 06066368 bf 0x0606636E
    goto L_060664FA;  // 0606636A bra 0x060664FA ; nop
L_0606636E:
    c.r[2] <<= 2;  // 0606636E shll2 r2
    c.r[1] = ld32(0x06066438u);  // 06066370 mov.l 0x06066438,r1
    c.r[7] = ld32(c.r[1]);  // 06066372 mov.l @r1,r7
    c.r[2] <<= 2;  // 06066374 shll2 r2
    c.r[2] += c.r[7];  // 06066376 add r7,r2
    c.r[1] = c.r[2];  // 06066378 mov r2,r1
    c.r[1] += 3;  // 0606637A add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606637C mov.b @r1,r1
    c.r[9] = 0x3u;  // 0606637E mov #3,r9
    c.r[3] = c.r[1];  // 06066380 mov r1,r3
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 06066382 shlr r3
    c.r[3] &= c.r[9];  // 06066384 and r9,r3
    c.t = (c.r[3] & c.r[3]) == 0;  // 06066386 tst r3,r3
    if (!c.t) { goto L_06066394; }  // 06066388 bf 0x06066394
    c.r[1] = ld32(c.r[2] + 12);  // 0606638A mov.l @(12,r2),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606638C tst r1,r1
    if (c.t) { goto L_06066394; }  // 0606638E bt 0x06066394
    goto L_060664FA;  // 06066390 bra 0x060664FA ; nop
L_06066394:
    c.r[6] <<= 2;  // 06066394 shll2 r6
    c.r[6] <<= 2;  // 06066396 shll2 r6
    c.r[6] += c.r[7];  // 06066398 add r7,r6
    c.r[1] = c.r[6];  // 0606639A mov r6,r1
    c.r[1] += 3;  // 0606639C add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606639E mov.b @r1,r1
    c.r[0] = c.r[1];  // 060663A0 mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060663A2 shlr r0
    c.r[0] &= 0x3u;  // 060663A4 and #3,r0
    c.t = c.r[3] == c.r[0];  // 060663A6 cmp/eq r0,r3
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_060663B0; } }  // 060663A8 bt/s 0x060663B0 ; mov r2,r1
    goto L_060664FA;  // 060663AC bra 0x060664FA ; nop
L_060663B0:
    c.r[1] += 7;  // 060663B0 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060663B2 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060663B4 extu.b r1,r1
    c.r[1] >>= 2;  // 060663B6 shlr2 r1
    c.r[1] >>= 2;  // 060663B8 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060663BA shlr r1
    c.r[1] >>= 2;  // 060663BC shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060663BE tst r1,r1
    { const bool k = c.t; c.r[6] += 7; if (k) { goto L_060663D4; } }  // 060663C0 bt/s 0x060663D4 ; add #7,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 060663C4 mov.b @r6,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060663C6 extu.b r1,r1
    c.r[1] >>= 2;  // 060663C8 shlr2 r1
    c.r[1] >>= 2;  // 060663CA shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060663CC shlr r1
    c.r[1] >>= 2;  // 060663CE shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060663D0 tst r1,r1
    if (c.t) { goto L_0606644E; }  // 060663D2 bt 0x0606644E
L_060663D4:
    c.r[1] = ld32(0x0606643Cu);  // 060663D4 mov.l 0x0606643C,r1
    c.r[1] = ld32(c.r[1]);  // 060663D6 mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606641Eu);  // 060663D8 mov.w 0x0606641E,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060663DA mov.b @(r0,r1),r1
    c.r[0] = c.r[1];  // 060663DC mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060663DE shlr r0
    c.r[0] &= 0xFu;  // 060663E0 and #15,r0
    c.t = c.r[0] == 0x9u;  // 060663E2 cmp/eq #9,r0
    if (c.t) { goto L_060663EA; }  // 060663E4 bt 0x060663EA
    goto L_060664FA;  // 060663E6 bra 0x060664FA ; nop
L_060663EA:
    c.r[2] += 2;  // 060663EA add #2,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060663EC mov.b @r2,r2
    c.r[1] = ld32(0x06066440u);  // 060663EE mov.l 0x06066440,r1
    c.r[3] = ld32(c.r[1]);  // 060663F0 mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 060663F2 extu.b r2,r2
    c.r[1] = 0x1Eu;  // 060663F4 mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 060663F6 mul.l r1,r2
    c.r[9] = ld32(0x06066444u);  // 060663F8 mov.l 0x06066444,r9
    c.r[5] = 0x1Bu;  // 060663FA mov #27,r5
    c.r[0] = c.macl;  // 060663FC sts macl,r0
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 060663FE mov.w @(r0,r3),r8
    c.r[4] = ld32(0x06066448u);  // 06066400 mov.l 0x06066448,r4
    { const uint32_t x = c.r[9]; c.pr = 0x06066406u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06066406u) return; }  // 06066402 jsr @r9 ; extu.w r8,r8
    c.r[5] = c.r[8];  // 06066406 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0606640Cu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606640Cu) return; }  // 06066408 jsr @r9 ; mov r0,r4
    c.r[0] += 7;  // 0606640C add #7,r0
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0606640E mov.b @r0,r0
    c.r[0] &= 0x78u;  // 06066410 and #120,r0
    c.r[0] >>= 2;  // 06066412 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06066414 shlr r0
    c.t = c.r[0] == 0x9u; goto L_0606644C;  // 06066416 bra 0x0606644C ; cmp/eq #9,r0
L_0606644C:
    if (!c.t) { goto L_060664FA; }  // 0606644C bf 0x060664FA
L_0606644E:
    c.r[8] = (uint32_t)(int16_t)ld16(0x06066544u);  // 0606644E mov.w 0x06066544,r8
    c.t = (c.r[10] & c.r[10]) == 0;  // 06066450 tst r10,r10
    { const bool k = c.t; c.r[1] = 0x3Eu; if (k) { goto L_06066474; } }  // 06066452 bt/s 0x06066474 ; mov #62,r1
    c.r[1] = c.r[10];  // 06066456 mov r10,r1
    c.r[1] -= 1;  // 06066458 add #-1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606645A extu.b r1,r1
    st32(c.r[14] + 8, c.r[1]);  // 0606645C mov.l r1,@(8,r14)
    c.r[0] = c.r[1];  // 0606645E mov r1,r0
    c.r[0] += c.r[0];  // 06066460 add r0,r0
    st32(c.r[14] + 8, c.r[0]);  // 06066462 mov.l r0,@(8,r14)
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[12]);  // 06066464 mov.w @(r0,r12),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06066466 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06066468 tst r1,r1
    { const bool k = c.t; c.t = c.r[8] > c.r[1]; if (k) { goto L_06066472; } }  // 0606646A bt/s 0x06066472 ; cmp/hi r1,r8
    if (!c.t) { goto L_06066472; }  // 0606646E bf 0x06066472
    c.r[8] = c.r[1];  // 06066470 mov r1,r8
L_06066472:
    c.r[1] = 0x3Eu;  // 06066472 mov #62,r1
L_06066474:
    c.t = (int32_t)c.r[10] > (int32_t)c.r[1];  // 06066474 cmp/gt r1,r10
    { const bool k = c.t; c.t = (c.r[13] & c.r[13]) == 0; if (k) { goto L_0606649C; } }  // 06066476 bt/s 0x0606649C ; tst r13,r13
    c.r[1] = c.r[10];  // 0606647A mov r10,r1
    c.r[1] += 1;  // 0606647C add #1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606647E extu.b r1,r1
    st32(c.r[14] + 8, c.r[1]);  // 06066480 mov.l r1,@(8,r14)
    c.r[9] = c.r[1];  // 06066482 mov r1,r9
    c.r[9] += c.r[9];  // 06066484 add r9,r9
    st32(c.r[14] + 8, c.r[9]);  // 06066486 mov.l r9,@(8,r14)
    c.r[0] = c.r[9];  // 06066488 mov r9,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[12]);  // 0606648A mov.w @(r0,r12),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0606648C extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606648E tst r1,r1
    { const bool k = c.t; c.t = (c.r[13] & c.r[13]) == 0; if (k) { goto L_0606649C; } }  // 06066490 bt/s 0x0606649C ; tst r13,r13
    c.t = c.r[8] > c.r[1];  // 06066494 cmp/hi r1,r8
    if (!c.t) { goto L_0606649A; }  // 06066496 bf 0x0606649A
    c.r[8] = c.r[1];  // 06066498 mov r1,r8
L_0606649A:
    c.t = (c.r[13] & c.r[13]) == 0;  // 0606649A tst r13,r13
L_0606649C:
    { const bool k = c.t; c.r[1] = 0x3Eu; if (k) { goto L_060664C4; } }  // 0606649C bt/s 0x060664C4 ; mov #62,r1
    c.r[1] = c.r[13];  // 060664A0 mov r13,r1
    c.r[1] -= 1;  // 060664A2 add #-1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060664A4 extu.b r1,r1
    st32(c.r[14] + 12, c.r[1]);  // 060664A6 mov.l r1,@(12,r14)
    c.r[9] = (uint32_t)(int16_t)ld16(0x06066546u);  // 060664A8 mov.w 0x06066546,r9
    c.macl = c.r[1] * c.r[9];  // 060664AA mul.l r9,r1
    c.r[0] = ld32(0x0606654Cu);  // 060664AC mov.l 0x0606654C,r0
    c.r[1] = c.macl;  // 060664AE sts macl,r1
    c.r[1] += c.r[0];  // 060664B0 add r0,r1
    c.r[0] = c.r[11];  // 060664B2 mov r11,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 060664B4 mov.w @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 060664B6 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060664B8 tst r1,r1
    { const bool k = c.t; c.t = c.r[8] > c.r[1]; if (k) { goto L_060664C2; } }  // 060664BA bt/s 0x060664C2 ; cmp/hi r1,r8
    if (!c.t) { goto L_060664C2; }  // 060664BE bf 0x060664C2
    c.r[8] = c.r[1];  // 060664C0 mov r1,r8
L_060664C2:
    c.r[1] = 0x3Eu;  // 060664C2 mov #62,r1
L_060664C4:
    c.t = (int32_t)c.r[13] > (int32_t)c.r[1];  // 060664C4 cmp/gt r1,r13
    { const bool k = c.t; c.r[1] = c.r[13]; if (k) { goto L_060664EA; } }  // 060664C6 bt/s 0x060664EA ; mov r13,r1
    c.r[1] += 1;  // 060664CA add #1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060664CC extu.b r1,r1
    st32(c.r[14] + 12, c.r[1]);  // 060664CE mov.l r1,@(12,r14)
    c.r[9] = (uint32_t)(int16_t)ld16(0x06066546u);  // 060664D0 mov.w 0x06066546,r9
    c.macl = c.r[1] * c.r[9];  // 060664D2 mul.l r9,r1
    c.r[0] = ld32(0x0606654Cu);  // 060664D4 mov.l 0x0606654C,r0
    c.r[1] = c.macl;  // 060664D6 sts macl,r1
    c.r[1] += c.r[0];  // 060664D8 add r0,r1
    c.r[0] = c.r[11];  // 060664DA mov r11,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 060664DC mov.w @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 060664DE extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060664E0 tst r1,r1
    { const bool k = c.t; c.t = c.r[8] > c.r[1]; if (k) { goto L_060664EA; } }  // 060664E2 bt/s 0x060664EA ; cmp/hi r1,r8
    if (!c.t) { goto L_060664EA; }  // 060664E6 bf 0x060664EA
    c.r[8] = c.r[1];  // 060664E8 mov r1,r8
L_060664EA:
    c.r[8] += 1;  // 060664EA add #1,r8
    c.r[0] = c.r[11];  // 060664EC mov r11,r0
    st16(c.r[0] + c.r[12], c.r[8]);  // 060664EE mov.w r8,@(r0,r12)
    c.r[9] = 0x40u;  // 060664F0 mov #64,r9
    c.r[9] += c.r[14];  // 060664F2 add r14,r9
    c.r[0] = ld32(c.r[9]);  // 060664F4 mov.l @r9,r0
    c.r[1] = 0x0u;  // 060664F6 mov #0,r1
    st8(c.r[0] + c.r[10], c.r[1]);  // 060664F8 mov.b r1,@(r0,r10)
L_060664FA:
    c.r[10] += 1;  // 060664FA add #1,r10
    c.r[0] = 0x3Fu;  // 060664FC mov #63,r0
    c.t = (int32_t)c.r[10] > (int32_t)c.r[0];  // 060664FE cmp/gt r0,r10
    { const bool k = c.t; c.r[11] += 2; if (k) { goto L_06066508; } }  // 06066500 bt/s 0x06066508 ; add #2,r11
    SH2_POLL(c); goto L_06066336;  // 06066504 bra 0x06066336 ; nop
L_06066508:
    c.r[9] = 0x40u;  // 06066508 mov #64,r9
    c.r[9] += c.r[14];  // 0606650A add r14,r9
    c.r[0] = ld32(c.r[9]);  // 0606650C mov.l @r9,r0
    c.r[0] += 64;  // 0606650E add #64,r0
    st32(c.r[9], c.r[0]);  // 06066510 mov.l r0,@r9
    c.r[9] = 0x44u;  // 06066512 mov #68,r9
    c.r[9] += c.r[14];  // 06066514 add r14,r9
    c.r[0] = ld32(c.r[9]);  // 06066516 mov.l @r9,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06066546u);  // 06066518 mov.w 0x06066546,r1
    c.r[13] += 1;  // 0606651A add #1,r13
    c.r[0] += 64;  // 0606651C add #64,r0
    st32(c.r[9], c.r[0]);  // 0606651E mov.l r0,@r9
    c.r[9] = 0x3Fu;  // 06066520 mov #63,r9
    c.t = (int32_t)c.r[13] > (int32_t)c.r[9];  // 06066522 cmp/gt r9,r13
    { const bool k = c.t; c.r[12] += c.r[1]; if (k) { goto L_0606652C; } }  // 06066524 bt/s 0x0606652C ; add r1,r12
    SH2_POLL(c); goto L_06066332;  // 06066528 bra 0x06066332 ; nop
L_0606652C:
    c.r[14] += 72;  // 0606652C add #72,r14
    c.r[15] = c.r[14];  // 0606652E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06066530 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06066532 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06066534 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06066536 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06066538 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0606653A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0606653C mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06066548u);  // 0606653E mov.w 0x06066548,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06066540 rts ; mov.l @r15+,r8
}

void f_06066550(SH2Context& c) {
    ran[1503] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06066550 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06066552 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06066554 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06066556 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06066558 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0606655A mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0606655C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0606655E sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x06066634u);  // 06066560 mov.w 0x06066634,r3
    c.r[15] += c.r[3];  // 06066562 add r3,r15
    c.r[14] = c.r[15];  // 06066564 mov r15,r14
    c.r[11] = 0x0u;  // 06066566 mov #0,r11
    c.r[0] = (uint32_t)(int16_t)ld16(0x06066636u);  // 06066568 mov.w 0x06066636,r0
    st32(c.r[0] + c.r[14], c.r[11]);  // 0606656A mov.l r11,@(r0,r14)
    c.r[1] = ld32(0x06066644u);  // 0606656C mov.l 0x06066644,r1
    c.r[1] = ld32(c.r[1]);  // 0606656E mov.l @r1,r1
    c.r[11] = (uint32_t)(int16_t)ld16(0x06066638u);  // 06066570 mov.w 0x06066638,r11
    c.r[1] += 1;  // 06066572 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06066574 mov.b @r1,r1
    c.r[11] += c.r[14];  // 06066576 add r14,r11
    c.r[0] = c.r[1];  // 06066578 mov r1,r0
    c.r[0] &= 0xFu;  // 0606657A and #15,r0
    st32(c.r[11], c.r[0]);  // 0606657C mov.l r0,@r11
    c.r[0] = (uint32_t)(int16_t)ld16(0x06066638u);  // 0606657E mov.w 0x06066638,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06066580 mov.l @(r0,r14),r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06066582 tst r0,r0
    if (!c.t) { goto L_06066590; }  // 06066584 bf 0x06066590
    c.r[1] = ld32(0x06066648u);  // 06066586 mov.l 0x06066648,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06066588 mov.b @r1,r0
    c.r[0] &= 0xFBu;  // 0606658A and #251,r0
    st8(c.r[1], c.r[0]); goto L_060665BA;  // 0606658C bra 0x060665BA ; mov.b r0,@r1
L_06066590:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06066638u);  // 06066590 mov.w 0x06066638,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06066592 mov.l @(r0,r14),r0
    c.t = c.r[0] == 0x1u;  // 06066594 cmp/eq #1,r0
    { const bool k = !c.t; c.r[11] = 0x1u; if (k) { goto L_060665A4; } }  // 06066596 bf/s 0x060665A4 ; mov #1,r11
    c.r[1] = ld32(0x06066648u);  // 0606659A mov.l 0x06066648,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606659C mov.b @r1,r0
    c.r[0] |= 0x4u;  // 0606659E or #4,r0
    st8(c.r[1], c.r[0]); goto L_060665BA;  // 060665A0 bra 0x060665BA ; mov.b r0,@r1
L_060665A4:
    c.r[1] = ld32(0x06066648u);  // 060665A4 mov.l 0x06066648,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060665A6 mov.b @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606663Au);  // 060665A8 mov.w 0x0606663A,r0
    c.r[3] = c.r[2];  // 060665AA mov r2,r3
    c.r[3] >>= 2;  // 060665AC shlr2 r3
    c.r[3] &= c.r[11];  // 060665AE and r11,r3
    c.r[3] ^= c.r[11];  // 060665B0 xor r11,r3
    c.r[3] <<= 2;  // 060665B2 shll2 r3
    c.r[2] &= c.r[0];  // 060665B4 and r0,r2
    c.r[2] |= c.r[3];  // 060665B6 or r3,r2
    st8(c.r[1], c.r[2]);  // 060665B8 mov.b r2,@r1
L_060665BA:
    c.r[1] = ld32(0x06066644u);  // 060665BA mov.l 0x06066644,r1
    c.r[1] = ld32(c.r[1]);  // 060665BC mov.l @r1,r1
    c.r[11] = (uint32_t)(int16_t)ld16(0x06066638u);  // 060665BE mov.w 0x06066638,r11
    c.r[1] += 1;  // 060665C0 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060665C2 mov.b @r1,r1
    c.r[11] += c.r[14];  // 060665C4 add r14,r11
    c.r[0] = c.r[1];  // 060665C6 mov r1,r0
    c.r[0] &= 0xF0u;  // 060665C8 and #240,r0
    st32(c.r[11], c.r[0]);  // 060665CA mov.l r0,@r11
    c.r[0] = (uint32_t)(int16_t)ld16(0x06066638u);  // 060665CC mov.w 0x06066638,r0
    c.r[0] += c.r[14];  // 060665CE add r14,r0
    c.r[11] = ld32(c.r[0]);  // 060665D0 mov.l @r0,r11
    c.r[1] = ld32(0x06066648u);  // 060665D2 mov.l 0x06066648,r1
    c.r[11] >>= 2;  // 060665D4 shlr2 r11
    c.r[11] >>= 2;  // 060665D6 shlr2 r11
    st32(c.r[0], c.r[11]);  // 060665D8 mov.l r11,@r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060665DA mov.b @r1,r1
    c.r[0] = 0x1u;  // 060665DC mov #1,r0
    c.r[1] >>= 2;  // 060665DE shlr2 r1
    c.r[1] &= c.r[0];  // 060665E0 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060665E2 tst r1,r1
    { const bool k = c.t; c.r[7] = 0x0u; if (k) { goto L_06066616; } }  // 060665E4 bt/s 0x06066616 ; mov #0,r7
    c.r[3] = (uint32_t)(int16_t)ld16(0x0606663Cu);  // 060665E8 mov.w 0x0606663C,r3
    c.r[1] = ld32(0x0606664Cu);  // 060665EA mov.l 0x0606664C,r1
    c.r[2] = 0x0u;  // 060665EC mov #0,r2
L_060665EE:
    c.r[0] = c.r[7];  // 060665EE mov r7,r0
    c.r[7] += 1;  // 060665F0 add #1,r7
    c.t = (int32_t)c.r[7] > (int32_t)c.r[3];  // 060665F2 cmp/gt r3,r7
    { const bool k = !c.t; st8(c.r[0] + c.r[1], c.r[2]); if (k) { SH2_POLL(c); goto L_060665EE; } }  // 060665F4 bf/s 0x060665EE ; mov.b r2,@(r0,r1)
    c.r[3] = ld32(0x06066648u);  // 060665F8 mov.l 0x06066648,r3
    c.r[11] = (uint32_t)(int16_t)ld16(0x06066638u);  // 060665FA mov.w 0x06066638,r11
    c.r[11] += c.r[14];  // 060665FC add r14,r11
    c.r[7] = ld32(c.r[11]);  // 060665FE mov.l @r11,r7
    c.r[2] = (uint32_t)(int16_t)ld16(0x0606663Eu);  // 06066600 mov.w 0x0606663E,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06066602 mov.w @r3,r1
    c.r[11] = 0x7u;  // 06066604 mov #7,r11
    c.r[7] &= c.r[11];  // 06066606 and r11,r7
    c.r[7] <<= 2;  // 06066608 shll2 r7
    c.r[7] <<= 2;  // 0606660A shll2 r7
    c.r[7] += c.r[7];  // 0606660C add r7,r7
    c.r[7] <<= 2;  // 0606660E shll2 r7
    c.r[1] &= c.r[2];  // 06066610 and r2,r1
    c.r[1] |= c.r[7];  // 06066612 or r7,r1
    st16(c.r[3], c.r[1]);  // 06066614 mov.w r1,@r3
L_06066616:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06066638u);  // 06066616 mov.w 0x06066638,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06066618 mov.l @(r0,r14),r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606661A tst r0,r0
    if (c.t) { goto L_0606662A; }  // 0606661C bt 0x0606662A
    c.r[0] = (uint32_t)(int16_t)ld16(0x06066638u);  // 0606661E mov.w 0x06066638,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06066620 mov.l @(r0,r14),r0
    c.t = c.r[0] == 0x1u;  // 06066622 cmp/eq #1,r0
    if (!c.t) { goto L_0606668E; }  // 06066624 bf 0x0606668E
    goto L_06066654;  // 06066626 bra 0x06066654 ; nop
L_0606662A:
    c.r[0] = ld32(0x06066650u);  // 0606662A mov.l 0x06066650,r0
    c.r[11] = (uint32_t)(int16_t)ld16(0x06066640u);  // 0606662C mov.w 0x06066640,r11
    c.r[11] += c.r[14];  // 0606662E add r14,r11
    st32(c.r[11], c.r[0]); goto L_06066694;  // 06066630 bra 0x06066694 ; mov.l r0,@r11
L_06066654:
    c.r[1] = ld32(0x060667A8u);  // 06066654 mov.l 0x060667A8,r1
    c.r[8] = (uint32_t)(int16_t)ld16(0x06066794u);  // 06066656 mov.w 0x06066794,r8
    c.r[2] = ld32(c.r[1]);  // 06066658 mov.l @r1,r2
    c.r[8] += c.r[14];  // 0606665A add r14,r8
    c.r[1] = ld32(0x060667ACu);  // 0606665C mov.l 0x060667AC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606665E mov.b @r1,r1
    c.r[4] = c.r[8];  // 06066660 mov r8,r4
    c.r[1] = c.r[1] & 0xFFu;  // 06066662 extu.b r1,r1
    c.r[1] += c.r[1];  // 06066664 add r1,r1
    c.r[2] += c.r[1];  // 06066666 add r1,r2
    c.r[2] += 1;  // 06066668 add #1,r2
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606666A mov.b @r2,r5
    c.r[1] = ld32(0x060667B0u);  // 0606666C mov.l 0x060667B0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06066672u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06066672u) return; }  // 0606666E jsr @r1 ; extu.b r5,r5
    c.r[1] = ld32(0x060667B4u);  // 06066672 mov.l 0x060667B4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06066674 mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 06066676 extu.b r1,r2
    c.r[1] = ld32(0x060667B8u);  // 06066678 mov.l 0x060667B8,r1
    c.r[0] = c.r[2];  // 0606667A mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606667C mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606667E extu.b r1,r1
    c.r[8] += c.r[1];  // 06066680 add r1,r8
    c.r[8] += 24;  // 06066682 add #24,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06066684 mov.b @r8,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06066686 extu.b r1,r1
    c.r[11] = (uint32_t)(int16_t)ld16(0x06066796u);  // 06066688 mov.w 0x06066796,r11
    c.r[11] += c.r[14];  // 0606668A add r14,r11
    st32(c.r[11], c.r[1]);  // 0606668C mov.l r1,@r11
L_0606668E:
    c.r[11] = ld32(0x060667BCu);  // 0606668E mov.l 0x060667BC,r11
    c.r[0] = (uint32_t)(int16_t)ld16(0x06066798u);  // 06066690 mov.w 0x06066798,r0
    st32(c.r[0] + c.r[14], c.r[11]);  // 06066692 mov.l r11,@(r0,r14)
L_06066694:
    c.r[1] = ld32(0x060667C0u);  // 06066694 mov.l 0x060667C0,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606679Au);  // 06066696 mov.w 0x0606679A,r0
    c.r[0] += c.r[14];  // 06066698 add r14,r0
    c.r[1] = ld32(c.r[1]);  // 0606669A mov.l @r1,r1
    c.r[7] = ld32(0x060667C4u);  // 0606669C mov.l 0x060667C4,r7
    c.r[1] += 24;  // 0606669E add #24,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060666A0 mov.w @r1,r1
    c.r[11] = (uint32_t)(int16_t)ld16(0x0606679Cu);  // 060666A2 mov.w 0x0606679C,r11
    c.r[1] = c.r[1] & 0xFFFFu;  // 060666A4 extu.w r1,r1
    st32(c.r[0], c.r[1]);  // 060666A6 mov.l r1,@r0
    c.r[1] = ld32(0x060667C8u);  // 060666A8 mov.l 0x060667C8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060666AA mov.b @r1,r1
    c.r[11] += c.r[14];  // 060666AC add r14,r11
    c.r[2] = ld32(c.r[7]);  // 060666AE mov.l @r7,r2
    c.r[1] = c.r[1] & 0xFFu;  // 060666B0 extu.b r1,r1
    c.r[1] <<= 2;  // 060666B2 shll2 r1
    c.r[1] <<= 2;  // 060666B4 shll2 r1
    c.r[3] = c.r[1];  // 060666B6 mov r1,r3
    c.r[3] += c.r[2];  // 060666B8 add r2,r3
    c.r[0] = c.r[1];  // 060666BA mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 060666BC mov.b @(r0,r2),r1
    c.r[3] += 1;  // 060666BE add #1,r3
    c.r[1] = c.r[1] & 0xFFu;  // 060666C0 extu.b r1,r1
    st32(c.r[11], c.r[1]);  // 060666C2 mov.l r1,@r11
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606679Eu);  // 060666C4 mov.w 0x0606679E,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060666C6 mov.b @r3,r1
    c.r[0] += c.r[14];  // 060666C8 add r14,r0
    c.r[1] = c.r[1] & 0xFFu;  // 060666CA extu.b r1,r1
    st32(c.r[0], c.r[1]);  // 060666CC mov.l r1,@r0
    c.r[0] = (uint32_t)(int16_t)ld16(0x060667A0u);  // 060666CE mov.w 0x060667A0,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 060666D0 mov.l @(r0,r14),r0
    c.t = c.r[0] == 0x3u;  // 060666D2 cmp/eq #3,r0
    { const bool k = !c.t; c.r[12] = 0x0u; if (k) { goto L_060666E2; } }  // 060666D4 bf/s 0x060666E2 ; mov #0,r12
    c.r[1] = ld32(0x060667A8u);  // 060666D8 mov.l 0x060667A8,r1
    c.r[2] = ld32(c.r[1]);  // 060666DA mov.l @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x060667A2u);  // 060666DC mov.w 0x060667A2,r0
    c.r[1] = 0x0u;  // 060666DE mov #0,r1
    st8(c.r[0] + c.r[2], c.r[1]);  // 060666E0 mov.b r1,@(r0,r2)
L_060666E2:
    c.r[13] = ld32(0x060667CCu);  // 060666E2 mov.l 0x060667CC,r13
    c.r[10] = 0x0u;  // 060666E4 mov #0,r10
L_060666E6:
    c.r[0] = ld32(0x060667D0u);  // 060666E6 mov.l 0x060667D0,r0
    c.r[11] = (uint32_t)(int16_t)ld16(0x060667A4u);  // 060666E8 mov.w 0x060667A4,r11
    c.r[11] += c.r[14];  // 060666EA add r14,r11
    st32(c.r[11], c.r[0]);  // 060666EC mov.l r0,@r11
L_060666EE:
    c.r[1] = ld32(0x060667D4u);  // 060666EE mov.l 0x060667D4,r1
    c.r[8] = c.r[12];  // 060666F0 mov r12,r8
    c.r[1] = ld32(c.r[1]);  // 060666F2 mov.l @r1,r1
    c.r[8] <<= 2;  // 060666F4 shll2 r8
    c.r[8] <<= 2;  // 060666F6 shll2 r8
    c.r[8] <<= 2;  // 060666F8 shll2 r8
    c.r[1] += c.r[8];  // 060666FA add r8,r1
    c.r[0] = c.r[1];  // 060666FC mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 060666FE mov.b @(r0,r10),r1
    c.r[11] = (uint32_t)(int16_t)ld16(0x060667A6u);  // 06066700 mov.w 0x060667A6,r11
    c.r[9] = c.r[1] & 0xFFu;  // 06066702 extu.b r1,r9
    c.t = c.r[9] == c.r[11];  // 06066704 cmp/eq r11,r9
    { const bool k = c.t; c.r[2] = c.r[9]; if (k) { goto L_06066722; } }  // 06066706 bt/s 0x06066722 ; mov r9,r2
    c.r[0] = ld32(0x060667C4u);  // 0606670A mov.l 0x060667C4,r0
    c.r[2] <<= 2;  // 0606670C shll2 r2
    c.r[2] <<= 2;  // 0606670E shll2 r2
    c.r[6] = (uint32_t)(int16_t)ld16(0x060667A6u);  // 06066710 mov.w 0x060667A6,r6
    c.r[1] = ld32(c.r[0]);  // 06066712 mov.l @r0,r1
    c.r[4] = c.r[14];  // 06066714 mov r14,r4
    c.r[2] += c.r[1];  // 06066716 add r1,r2
    c.r[2] += 2;  // 06066718 add #2,r2
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606671A mov.b @r2,r5
    c.r[1] = ld32(0x060667D8u);  // 0606671C mov.l 0x060667D8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06066722u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06066722u) return; }  // 0606671E jsr @r1 ; extu.b r5,r5
L_06066722:
    c.r[11] = (uint32_t)(int16_t)ld16(0x060667A0u);  // 06066722 mov.w 0x060667A0,r11
    c.r[11] += c.r[14];  // 06066724 add r14,r11
    c.r[2] = ld32(c.r[11]);  // 06066726 mov.l @r11,r2
    c.r[1] = 0x3u;  // 06066728 mov #3,r1
    c.r[2] -= 1;  // 0606672A add #-1,r2
    c.t = c.r[2] > c.r[1];  // 0606672C cmp/hi r1,r2
    { const bool k = !c.t; c.r[1] = c.r[2]; if (k) { goto L_06066736; } }  // 0606672E bf/s 0x06066736 ; mov r2,r1
    goto L_060669F0;  // 06066732 bra 0x060669F0 ; nop
L_06066736:
    c.r[1] += c.r[1];  // 06066736 add r1,r1
    c.r[0] = 0x06066744u;  // 06066738 mova 0x06066744,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0606673A mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 0606673C add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x0606674Cu: goto L_0606674C; case 0x0606676Eu: goto L_0606676E; case 0x060667E4u: goto L_060667E4; default: sh2_call(c, x); return; } }  // 0606673E jmp @r0 ; nop
L_0606674C:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 0606674C mov.b @r13,r1
    c.r[0] = c.r[1];  // 0606674E mov r1,r0
    c.r[0] >>= 2;  // 06066750 shlr2 r0
    c.r[0] &= 0x1u;  // 06066752 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06066754 tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[10]; if (k) { goto L_0606675E; } }  // 06066756 bf/s 0x0606675E ; mov r10,r1
    goto L_06066DA2;  // 0606675A bra 0x06066DA2 ; nop
L_0606675E:
    c.r[1] = ld32(0x060667DCu);  // 0606675E mov.l 0x060667DC,r1
    c.r[6] = c.r[12];  // 06066760 mov r12,r6
    c.r[0] = (uint32_t)(int16_t)ld16(0x06066796u);  // 06066762 mov.w 0x06066796,r0
    c.r[4] = ld32(c.r[0] + c.r[14]);  // 06066764 mov.l @(r0,r14),r4
    { const uint32_t x = c.r[1]; c.pr = 0x0606676Au; c.r[5] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606676Au) return; }  // 06066766 jsr @r1 ; mov r10,r5
    c.r[1] = c.r[10]; goto L_06066DA2;  // 0606676A bra 0x06066DA2 ; mov r10,r1
L_0606676E:
    c.r[1] = ld32(0x060667C8u);  // 0606676E mov.l 0x060667C8,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060667A0u);  // 06066770 mov.w 0x060667A0,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06066772 mov.b @r1,r1
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06066774 mov.l @(r0,r14),r0
    c.r[4] = c.r[1] & 0xFFu;  // 06066776 extu.b r1,r4
    c.t = c.r[0] == 0x4u;  // 06066778 cmp/eq #4,r0
    { const bool k = !c.t; c.r[1] = 0x0u; if (k) { goto L_06066780; } }  // 0606677A bf/s 0x06066780 ; mov #0,r1
    c.r[1] = 0x2u;  // 0606677E mov #2,r1
L_06066780:
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06066780 mov.l r1,@-r15
    c.r[1] = ld32(0x060667E0u);  // 06066782 mov.l 0x060667E0,r1
    c.r[11] = (uint32_t)(int16_t)ld16(0x06066798u);  // 06066784 mov.w 0x06066798,r11
    c.r[11] += c.r[14];  // 06066786 add r14,r11
    c.r[7] = ld32(c.r[11]);  // 06066788 mov.l @r11,r7
    c.r[6] = c.r[12];  // 0606678A mov r12,r6
    { const uint32_t x = c.r[1]; c.pr = 0x06066790u; c.r[5] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06066790u) return; }  // 0606678C jsr @r1 ; mov r10,r5
    c.r[15] += 4; goto L_06066DA0;  // 06066790 bra 0x06066DA0 ; add #4,r15
L_060667E4:
    c.r[1] = c.r[10];  // 060667E4 mov r10,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06066890u);  // 060667E6 mov.w 0x06066890,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 060667E8 mov.l @(r0,r14),r0
    c.r[1] -= 1;  // 060667EA add #-1,r1
    c.t = (int32_t)c.r[0] >= (int32_t)c.r[1];  // 060667EC cmp/ge r1,r0
    { const bool k = !c.t; c.r[1] = c.r[10]; if (k) { goto L_06066808; } }  // 060667EE bf/s 0x06066808 ; mov r10,r1
    c.r[11] = (uint32_t)(int16_t)ld16(0x06066890u);  // 060667F2 mov.w 0x06066890,r11
    c.r[11] += c.r[14];  // 060667F4 add r14,r11
    c.r[11] = ld32(c.r[11]);  // 060667F6 mov.l @r11,r11
    c.r[1] += 1;  // 060667F8 add #1,r1
    c.t = (int32_t)c.r[11] > (int32_t)c.r[1];  // 060667FA cmp/gt r1,r11
    { const bool k = c.t; c.r[1] = c.r[12]; if (k) { goto L_0606680A; } }  // 060667FC bt/s 0x0606680A ; mov r12,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06066892u);  // 06066800 mov.w 0x06066892,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06066802 mov.l @(r0,r14),r0
    c.t = c.r[0] == c.r[12];  // 06066804 cmp/eq r12,r0
    if (c.t) { goto L_06066836; }  // 06066806 bt 0x06066836
L_06066808:
    c.r[1] = c.r[12];  // 06066808 mov r12,r1
L_0606680A:
    c.r[11] = (uint32_t)(int16_t)ld16(0x06066892u);  // 0606680A mov.w 0x06066892,r11
    c.r[11] += c.r[14];  // 0606680C add r14,r11
    c.r[11] = ld32(c.r[11]);  // 0606680E mov.l @r11,r11
    c.r[1] -= 1;  // 06066810 add #-1,r1
    c.t = (int32_t)c.r[11] >= (int32_t)c.r[1];  // 06066812 cmp/ge r1,r11
    { const bool k = c.t; c.r[1] = c.r[12]; if (k) { goto L_0606681C; } }  // 06066814 bt/s 0x0606681C ; mov r12,r1
    goto L_06066960;  // 06066818 bra 0x06066960 ; nop
L_0606681C:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06066892u);  // 0606681C mov.w 0x06066892,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 0606681E mov.l @(r0,r14),r0
    c.r[1] += 1;  // 06066820 add #1,r1
    c.t = (int32_t)c.r[0] > (int32_t)c.r[1];  // 06066822 cmp/gt r1,r0
    if (!c.t) { goto L_0606682A; }  // 06066824 bf 0x0606682A
    goto L_06066960;  // 06066826 bra 0x06066960 ; nop
L_0606682A:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06066890u);  // 0606682A mov.w 0x06066890,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 0606682C mov.l @(r0,r14),r0
    c.t = c.r[0] == c.r[10];  // 0606682E cmp/eq r10,r0
    if (c.t) { goto L_06066836; }  // 06066830 bt 0x06066836
    goto L_06066960;  // 06066832 bra 0x06066960 ; nop
L_06066836:
    c.r[1] = ld32(0x06066898u);  // 06066836 mov.l 0x06066898,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06066838 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606683A extu.b r1,r1
    c.t = c.r[9] == c.r[1];  // 0606683C cmp/eq r1,r9
    if (!c.t) { goto L_060668A0; }  // 0606683E bf 0x060668A0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 06066840 mov.b @r13,r1
    c.r[0] = c.r[1];  // 06066842 mov r1,r0
    c.r[0] >>= 2;  // 06066844 shlr2 r0
    c.r[0] &= 0x1u;  // 06066846 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06066848 tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[10]; if (k) { goto L_06066852; } }  // 0606684A bf/s 0x06066852 ; mov r10,r1
    goto L_06066DA2;  // 0606684E bra 0x06066DA2 ; nop
L_06066852:
    c.r[1] = c.r[12];  // 06066852 mov r12,r1
    c.r[1] <<= 2;  // 06066854 shll2 r1
    c.r[1] <<= 2;  // 06066856 shll2 r1
    c.r[1] <<= 2;  // 06066858 shll2 r1
    c.r[1] += c.r[10];  // 0606685A add r10,r1
    c.t = (int32_t)c.r[1] >= 0;  // 0606685C cmp/pz r1
    { const bool k = c.t; c.r[5] = c.r[1]; if (k) { goto L_06066864; } }  // 0606685E bt/s 0x06066864 ; mov r1,r5
    c.r[5] += 7;  // 06066862 add #7,r5
L_06066864:
    c.r[8] = c.r[5];  // 06066864 mov r5,r8
    c.t = c.r[8] & 1; c.r[8] = (uint32_t)((int32_t)c.r[8] >> 1);  // 06066866 shar r8
    c.t = c.r[8] & 1; c.r[8] = (uint32_t)((int32_t)c.r[8] >> 1);  // 06066868 shar r8
    c.t = c.r[8] & 1; c.r[8] = (uint32_t)((int32_t)c.r[8] >> 1);  // 0606686A shar r8
    c.r[5] = c.r[8];  // 0606686C mov r8,r5
    c.r[5] <<= 2;  // 0606686E shll2 r5
    c.r[5] += c.r[5];  // 06066870 add r5,r5
    c.r[5] -= c.r[1];  // 06066872 sub r1,r5
    c.r[5] += 7;  // 06066874 add #7,r5
    c.r[11] = ld32(0x0606689Cu);  // 06066876 mov.l 0x0606689C,r11
    { const uint32_t x = c.r[11]; c.pr = 0x0606687Cu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606687Cu) return; }  // 06066878 jsr @r11 ; mov #1,r4
    c.r[2] = c.r[0];  // 0606687C mov r0,r2
    c.r[11] = (uint32_t)(int16_t)ld16(0x06066894u);  // 0606687E mov.w 0x06066894,r11
    c.r[11] += c.r[14];  // 06066880 add r14,r11
    c.r[0] = ld32(c.r[11]);  // 06066882 mov.l @r11,r0
    c.r[11] = (uint32_t)(int16_t)ld16(0x06066894u);  // 06066884 mov.w 0x06066894,r11
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 06066886 mov.b @(r0,r8),r1
    c.r[11] += c.r[14];  // 06066888 add r14,r11
    c.r[2] |= c.r[1];  // 0606688A or r1,r2
    st8(c.r[0] + c.r[8], c.r[2]); goto L_06066DA0;  // 0606688C bra 0x06066DA0 ; mov.b r2,@(r0,r8)
L_060668A0:
    c.r[0] = (uint32_t)(int16_t)ld16(0x060669CEu);  // 060668A0 mov.w 0x060669CE,r0
    c.t = c.r[9] == c.r[0];  // 060668A2 cmp/eq r0,r9
    { const bool k = !c.t; c.r[1] = c.r[10]; if (k) { goto L_060668AC; } }  // 060668A4 bf/s 0x060668AC ; mov r10,r1
    goto L_06066DA2;  // 060668A8 bra 0x06066DA2 ; nop
L_060668AC:
    c.r[1] = c.r[12];  // 060668AC mov r12,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060669D0u);  // 060668AE mov.w 0x060669D0,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 060668B0 mov.l @(r0,r14),r0
    c.r[1] -= 1;  // 060668B2 add #-1,r1
    c.t = c.r[0] == c.r[1];  // 060668B4 cmp/eq r1,r0
    { const bool k = !c.t; c.r[1] = c.r[10]; if (k) { goto L_060668C4; } }  // 060668B6 bf/s 0x060668C4 ; mov r10,r1
    c.r[1] = ld32(0x060669DCu);  // 060668BA mov.l 0x060669DC,r1
    c.r[1] = ld32(c.r[1]);  // 060668BC mov.l @r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060668BE tst r1,r1
    { const bool k = !c.t; c.r[1] = c.r[10]; if (k) { goto L_0606690E; } }  // 060668C0 bf/s 0x0606690E ; mov r10,r1
L_060668C4:
    c.r[0] = (uint32_t)(int16_t)ld16(0x060669D2u);  // 060668C4 mov.w 0x060669D2,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 060668C6 mov.l @(r0,r14),r0
    c.r[1] += 1;  // 060668C8 add #1,r1
    c.t = c.r[0] == c.r[1];  // 060668CA cmp/eq r1,r0
    { const bool k = !c.t; c.r[1] = c.r[12]; if (k) { goto L_060668DA; } }  // 060668CC bf/s 0x060668DA ; mov r12,r1
    c.r[1] = ld32(0x060669DCu);  // 060668D0 mov.l 0x060669DC,r1
    c.r[1] = ld32(c.r[1] + 4);  // 060668D2 mov.l @(4,r1),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060668D4 tst r1,r1
    { const bool k = !c.t; c.r[1] = c.r[12]; if (k) { goto L_0606690E; } }  // 060668D6 bf/s 0x0606690E ; mov r12,r1
L_060668DA:
    c.r[0] = (uint32_t)(int16_t)ld16(0x060669D0u);  // 060668DA mov.w 0x060669D0,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 060668DC mov.l @(r0,r14),r0
    c.r[1] += 1;  // 060668DE add #1,r1
    c.t = c.r[0] == c.r[1];  // 060668E0 cmp/eq r1,r0
    { const bool k = !c.t; c.r[1] = c.r[10]; if (k) { goto L_060668F0; } }  // 060668E2 bf/s 0x060668F0 ; mov r10,r1
    c.r[1] = ld32(0x060669DCu);  // 060668E6 mov.l 0x060669DC,r1
    c.r[1] = ld32(c.r[1] + 8);  // 060668E8 mov.l @(8,r1),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060668EA tst r1,r1
    { const bool k = !c.t; c.r[1] = c.r[10]; if (k) { goto L_0606690E; } }  // 060668EC bf/s 0x0606690E ; mov r10,r1
L_060668F0:
    c.r[0] = (uint32_t)(int16_t)ld16(0x060669D2u);  // 060668F0 mov.w 0x060669D2,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 060668F2 mov.l @(r0,r14),r0
    c.r[1] -= 1;  // 060668F4 add #-1,r1
    c.t = c.r[0] == c.r[1];  // 060668F6 cmp/eq r1,r0
    { const bool k = c.t; c.r[1] = c.r[10]; if (k) { goto L_06066900; } }  // 060668F8 bt/s 0x06066900 ; mov r10,r1
    goto L_06066DA2;  // 060668FC bra 0x06066DA2 ; nop
L_06066900:
    c.r[1] = ld32(0x060669DCu);  // 06066900 mov.l 0x060669DC,r1
    c.r[1] = ld32(c.r[1] + 12);  // 06066902 mov.l @(12,r1),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06066904 tst r1,r1
    { const bool k = !c.t; c.r[1] = c.r[10]; if (k) { goto L_0606690E; } }  // 06066906 bf/s 0x0606690E ; mov r10,r1
    goto L_06066DA2;  // 0606690A bra 0x06066DA2 ; nop
L_0606690E:
    c.r[1] = ld32(0x060669E0u);  // 0606690E mov.l 0x060669E0,r1
    c.r[3] = ld32(c.r[1]);  // 06066910 mov.l @r1,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x060669D4u);  // 06066912 mov.w 0x060669D4,r7
    c.r[0] = c.r[3];  // 06066914 mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06066916 mov.b @(r0,r7),r2
    c.r[11] = (uint32_t)(int16_t)ld16(0x060669D6u);  // 06066918 mov.w 0x060669D6,r11
    c.r[1] = c.r[2];  // 0606691A mov r2,r1
    c.r[1] += 1;  // 0606691C add #1,r1
    st8(c.r[0] + c.r[7], c.r[1]);  // 0606691E mov.b r1,@(r0,r7)
    c.r[1] = c.r[2] & 0xFFu;  // 06066920 extu.b r2,r1
    c.r[1] += c.r[1];  // 06066922 add r1,r1
    c.r[3] += c.r[1];  // 06066924 add r1,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06066926 mov.b @(r0,r1),r2
    c.r[3] += 1;  // 06066928 add #1,r3
    c.r[2] &= c.r[11];  // 0606692A and r11,r2
    st8(c.r[0] + c.r[1], c.r[2]);  // 0606692C mov.b r2,@(r0,r1)
    st8(c.r[3], c.r[9]);  // 0606692E mov.b r9,@r3
    c.r[0] = ld32(0x060669E4u);  // 06066930 mov.l 0x060669E4,r0
    c.r[2] = c.r[9];  // 06066932 mov r9,r2
    c.r[1] = ld32(c.r[0]);  // 06066934 mov.l @r0,r1
    c.r[2] <<= 2;  // 06066936 shll2 r2
    c.r[2] <<= 2;  // 06066938 shll2 r2
    c.r[2] += c.r[1];  // 0606693A add r1,r2
    c.r[2] += 7;  // 0606693C add #7,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606693E mov.b @r2,r1
    c.r[11] = 0x1u;  // 06066940 mov #1,r11
    c.r[1] >>= 2;  // 06066942 shlr2 r1
    c.r[1] >>= 2;  // 06066944 shlr2 r1
    c.r[1] &= c.r[11];  // 06066946 and r11,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06066948 tst r1,r1
    { const bool k = !c.t; c.r[1] = c.r[10]; if (k) { goto L_06066952; } }  // 0606694A bf/s 0x06066952 ; mov r10,r1
    goto L_06066DA2;  // 0606694E bra 0x06066DA2 ; nop
L_06066952:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 06066952 mov.b @r13,r1
    c.r[4] = c.r[9];  // 06066954 mov r9,r4
    c.r[0] = ld32(0x060669E8u);  // 06066956 mov.l 0x060669E8,r0
    c.r[1] >>= 2;  // 06066958 shlr2 r1
    c.r[1] &= c.r[11];  // 0606695A and r11,r1
    c.r[5] = c.r[1]; goto L_06066D9C;  // 0606695C bra 0x06066D9C ; mov r1,r5
L_06066960:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 06066960 mov.b @r13,r1
    c.r[0] = c.r[1];  // 06066962 mov r1,r0
    c.r[0] >>= 2;  // 06066964 shlr2 r0
    c.r[0] &= 0x1u;  // 06066966 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06066968 tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[12]; if (k) { goto L_060669A8; } }  // 0606696A bt/s 0x060669A8 ; mov r12,r1
    c.r[1] <<= 2;  // 0606696E shll2 r1
    c.r[1] <<= 2;  // 06066970 shll2 r1
    c.r[1] <<= 2;  // 06066972 shll2 r1
    c.r[1] += c.r[10];  // 06066974 add r10,r1
    c.t = (int32_t)c.r[1] >= 0;  // 06066976 cmp/pz r1
    { const bool k = c.t; c.r[5] = c.r[1]; if (k) { goto L_0606697E; } }  // 06066978 bt/s 0x0606697E ; mov r1,r5
    c.r[5] += 7;  // 0606697C add #7,r5
L_0606697E:
    c.r[8] = c.r[5];  // 0606697E mov r5,r8
    c.t = c.r[8] & 1; c.r[8] = (uint32_t)((int32_t)c.r[8] >> 1);  // 06066980 shar r8
    c.t = c.r[8] & 1; c.r[8] = (uint32_t)((int32_t)c.r[8] >> 1);  // 06066982 shar r8
    c.t = c.r[8] & 1; c.r[8] = (uint32_t)((int32_t)c.r[8] >> 1);  // 06066984 shar r8
    c.r[5] = c.r[8];  // 06066986 mov r8,r5
    c.r[5] <<= 2;  // 06066988 shll2 r5
    c.r[5] += c.r[5];  // 0606698A add r5,r5
    c.r[5] -= c.r[1];  // 0606698C sub r1,r5
    c.r[5] += 7;  // 0606698E add #7,r5
    c.r[11] = ld32(0x060669ECu);  // 06066990 mov.l 0x060669EC,r11
    { const uint32_t x = c.r[11]; c.pr = 0x06066996u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06066996u) return; }  // 06066992 jsr @r11 ; mov #1,r4
    c.r[2] = c.r[0];  // 06066996 mov r0,r2
    c.r[11] = (uint32_t)(int16_t)ld16(0x060669D8u);  // 06066998 mov.w 0x060669D8,r11
    c.r[11] += c.r[14];  // 0606699A add r14,r11
    c.r[0] = ld32(c.r[11]);  // 0606699C mov.l @r11,r0
    c.r[11] = (uint32_t)(int16_t)ld16(0x060669D8u);  // 0606699E mov.w 0x060669D8,r11
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 060669A0 mov.b @(r0,r8),r1
    c.r[11] += c.r[14];  // 060669A2 add r14,r11
    c.r[2] |= c.r[1];  // 060669A4 or r1,r2
    st8(c.r[0] + c.r[8], c.r[2]);  // 060669A6 mov.b r2,@(r0,r8)
L_060669A8:
    c.r[0] = ld32(0x060669E4u);  // 060669A8 mov.l 0x060669E4,r0
    c.r[2] = c.r[9];  // 060669AA mov r9,r2
    c.r[1] = ld32(c.r[0]);  // 060669AC mov.l @r0,r1
    c.r[2] <<= 2;  // 060669AE shll2 r2
    c.r[2] <<= 2;  // 060669B0 shll2 r2
    c.r[2] += c.r[1];  // 060669B2 add r1,r2
    c.r[2] += 7;  // 060669B4 add #7,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060669B6 mov.b @r2,r1
    c.r[11] = 0x1u;  // 060669B8 mov #1,r11
    c.r[1] >>= 2;  // 060669BA shlr2 r1
    c.r[1] >>= 2;  // 060669BC shlr2 r1
    c.r[1] &= c.r[11];  // 060669BE and r11,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060669C0 tst r1,r1
    { const bool k = c.t; c.r[1] = c.r[10]; if (k) { goto L_060669CA; } }  // 060669C2 bt/s 0x060669CA ; mov r10,r1
    goto L_06066DA2;  // 060669C6 bra 0x06066DA2 ; nop
L_060669CA:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]); goto L_06066D90;  // 060669CA bra 0x06066D90 ; mov.b @r13,r1
L_060669F0:
    c.r[11] = ld32(0x06066B18u);  // 060669F0 mov.l 0x06066B18,r11
    c.r[8] += c.r[11];  // 060669F2 add r11,r8
    c.r[0] = c.r[8];  // 060669F4 mov r8,r0
    c.r[11] = (uint32_t)(int16_t)ld16(0x06066B0Eu);  // 060669F6 mov.w 0x06066B0E,r11
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 060669F8 mov.b @(r0,r10),r2
    c.r[11] += c.r[14];  // 060669FA add r14,r11
    c.r[11] = ld32(c.r[11]);  // 060669FC mov.l @r11,r11
    c.r[1] = c.r[2] & 0xFFu;  // 060669FE extu.b r2,r1
    c.t = c.r[1] > c.r[11];  // 06066A00 cmp/hi r11,r1
    { const bool k = c.t; c.r[3] = 0x0u; if (k) { goto L_06066A34; } }  // 06066A02 bt/s 0x06066A34 ; mov #0,r3
    c.r[1] = c.r[2] & 0xFFu;  // 06066A06 extu.b r2,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06066B10u);  // 06066A08 mov.w 0x06066B10,r0
    c.t = c.r[1] == c.r[0];  // 06066A0A cmp/eq r0,r1
    { const bool k = c.t; c.r[1] = c.r[10]; if (k) { goto L_06066A34; } }  // 06066A0C bt/s 0x06066A34 ; mov r10,r1
    c.r[1] += c.r[1];  // 06066A10 add r1,r1
    c.r[2] = c.r[12];  // 06066A12 mov r12,r2
    c.r[2] <<= 2;  // 06066A14 shll2 r2
    c.r[2] <<= 2;  // 06066A16 shll2 r2
    c.r[2] += c.r[2];  // 06066A18 add r2,r2
    c.r[2] <<= 2;  // 06066A1A shll2 r2
    c.r[11] = (uint32_t)(int16_t)ld16(0x06066B12u);  // 06066A1C mov.w 0x06066B12,r11
    c.r[11] += c.r[14];  // 06066A1E add r14,r11
    c.r[11] = ld32(c.r[11]);  // 06066A20 mov.l @r11,r11
    c.r[0] = c.r[1];  // 06066A22 mov r1,r0
    c.r[2] += c.r[11];  // 06066A24 add r11,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 06066A26 mov.w @(r0,r2),r1
    c.r[2] = c.r[1] & 0xFFFFu;  // 06066A28 extu.w r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06066A2A tst r2,r2
    if (c.t) { goto L_06066A34; }  // 06066A2C bt 0x06066A34
    c.r[1] = ld32(0x06066B1Cu);  // 06066A2E mov.l 0x06066B1C,r1
    c.t = c.r[2] == c.r[1];  // 06066A30 cmp/eq r1,r2
    if (!c.t) { goto L_06066A36; }  // 06066A32 bf 0x06066A36
L_06066A34:
    c.r[3] = 0x1u;  // 06066A34 mov #1,r3
L_06066A36:
    c.r[11] = (uint32_t)(int16_t)ld16(0x06066B14u);  // 06066A36 mov.w 0x06066B14,r11
    c.r[11] += c.r[14];  // 06066A38 add r14,r11
    c.r[0] = (uint32_t)(int16_t)ld16(0x06066B10u);  // 06066A3A mov.w 0x06066B10,r0
    c.t = c.r[9] == c.r[0];  // 06066A3C cmp/eq r0,r9
    { const bool k = c.t; st32(c.r[11], c.r[3]); if (k) { goto L_06066AE8; } }  // 06066A3E bt/s 0x06066AE8 ; mov.l r3,@r11
    c.r[11] = ld32(0x06066B20u);  // 06066A42 mov.l 0x06066B20,r11
    c.r[6] = c.r[9];  // 06066A44 mov r9,r6
    c.r[2] = ld32(c.r[11]);  // 06066A46 mov.l @r11,r2
    c.r[6] <<= 2;  // 06066A48 shll2 r6
    c.r[6] <<= 2;  // 06066A4A shll2 r6
    c.r[6] += c.r[2];  // 06066A4C add r2,r6
    c.r[1] = c.r[6];  // 06066A4E mov r6,r1
    c.r[1] += 3;  // 06066A50 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06066A52 mov.b @r1,r1
    c.r[0] = 0x3u;  // 06066A54 mov #3,r0
    c.r[5] = c.r[1];  // 06066A56 mov r1,r5
    c.t = c.r[5] & 1; c.r[5] >>= 1;  // 06066A58 shlr r5
    c.r[5] &= c.r[0];  // 06066A5A and r0,r5
    c.t = (c.r[5] & c.r[5]) == 0;  // 06066A5C tst r5,r5
    { const bool k = !c.t; c.r[4] = 0x0u; if (k) { goto L_06066A68; } }  // 06066A5E bf/s 0x06066A68 ; mov #0,r4
    c.r[1] = ld32(c.r[6] + 12);  // 06066A62 mov.l @(12,r6),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06066A64 tst r1,r1
    if (!c.t) { goto L_06066AD8; }  // 06066A66 bf 0x06066AD8
L_06066A68:
    c.r[1] = ld32(0x06066B24u);  // 06066A68 mov.l 0x06066B24,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06066A6A mov.b @r1,r1
    c.r[7] = c.r[1] & 0xFFu;  // 06066A6C extu.b r1,r7
    c.r[7] <<= 2;  // 06066A6E shll2 r7
    c.r[7] <<= 2;  // 06066A70 shll2 r7
    c.r[7] += c.r[2];  // 06066A72 add r2,r7
    c.r[1] = c.r[7];  // 06066A74 mov r7,r1
    c.r[1] += 3;  // 06066A76 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06066A78 mov.b @r1,r1
    c.r[11] = 0x3u;  // 06066A7A mov #3,r11
    c.r[3] = c.r[1];  // 06066A7C mov r1,r3
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 06066A7E shlr r3
    c.r[3] &= c.r[11];  // 06066A80 and r11,r3
    c.t = (c.r[3] & c.r[3]) == 0;  // 06066A82 tst r3,r3
    if (!c.t) { goto L_06066A8C; }  // 06066A84 bf 0x06066A8C
    c.r[1] = ld32(c.r[7] + 12);  // 06066A86 mov.l @(12,r7),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06066A88 tst r1,r1
    if (!c.t) { goto L_06066AD8; }  // 06066A8A bf 0x06066AD8
L_06066A8C:
    c.r[1] = ld32(0x06066B28u);  // 06066A8C mov.l 0x06066B28,r1
    c.r[1] = ld32(c.r[1]);  // 06066A8E mov.l @r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06066B16u);  // 06066A90 mov.w 0x06066B16,r2
    c.r[0] = c.r[1];  // 06066A92 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06066A94 mov.b @(r0,r2),r1
    c.r[11] = 0xFu;  // 06066A96 mov #15,r11
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06066A98 shlr r1
    c.r[1] &= c.r[11];  // 06066A9A and r11,r1
    c.r[0] = c.r[1];  // 06066A9C mov r1,r0
    c.t = c.r[0] == 0x9u;  // 06066A9E cmp/eq #9,r0
    if (!c.t) { goto L_06066AB0; }  // 06066AA0 bf 0x06066AB0
    c.r[0] = c.r[14];  // 06066AA2 mov r14,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06066AA4 mov.b @(r0,r2),r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06066AA6 shlr r1
    c.r[1] &= c.r[11];  // 06066AA8 and r11,r1
    c.r[0] = c.r[1];  // 06066AAA mov r1,r0
    c.t = c.r[0] == 0x9u;  // 06066AAC cmp/eq #9,r0
    if (c.t) { goto L_06066ADA; }  // 06066AAE bt 0x06066ADA
L_06066AB0:
    c.t = c.r[5] == c.r[3];  // 06066AB0 cmp/eq r3,r5
    { const bool k = !c.t; c.r[6] += 7; if (k) { goto L_06066AD8; } }  // 06066AB2 bf/s 0x06066AD8 ; add #7,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 06066AB6 mov.b @r6,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06066AB8 extu.b r1,r1
    c.r[1] >>= 2;  // 06066ABA shlr2 r1
    c.r[1] >>= 2;  // 06066ABC shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06066ABE shlr r1
    c.r[1] >>= 2;  // 06066AC0 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06066AC2 tst r1,r1
    { const bool k = c.t; c.r[7] += 7; if (k) { goto L_06066AD8; } }  // 06066AC4 bt/s 0x06066AD8 ; add #7,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06066AC8 mov.b @r7,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06066ACA extu.b r1,r1
    c.r[1] >>= 2;  // 06066ACC shlr2 r1
    c.r[1] >>= 2;  // 06066ACE shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06066AD0 shlr r1
    c.r[1] >>= 2;  // 06066AD2 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06066AD4 tst r1,r1
    if (c.t) { goto L_06066ADA; }  // 06066AD6 bt 0x06066ADA
L_06066AD8:
    c.r[4] = 0x1u;  // 06066AD8 mov #1,r4
L_06066ADA:
    c.r[11] = (uint32_t)(int16_t)ld16(0x06066B14u);  // 06066ADA mov.w 0x06066B14,r11
    c.r[11] += c.r[14];  // 06066ADC add r14,r11
    c.r[1] = ld32(c.r[11]);  // 06066ADE mov.l @r11,r1
    c.r[1] |= c.r[4];  // 06066AE0 or r4,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06066AE2 extu.b r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06066B14u);  // 06066AE4 mov.w 0x06066B14,r0
    st32(c.r[0] + c.r[14], c.r[1]);  // 06066AE6 mov.l r1,@(r0,r14)
L_06066AE8:
    c.r[11] = (uint32_t)(int16_t)ld16(0x06066B14u);  // 06066AE8 mov.w 0x06066B14,r11
    c.r[11] += c.r[14];  // 06066AEA add r14,r11
    c.r[11] = ld32(c.r[11]);  // 06066AEC mov.l @r11,r11
    c.t = (c.r[11] & c.r[11]) == 0;  // 06066AEE tst r11,r11
    if (c.t) { goto L_06066B5A; }  // 06066AF0 bt 0x06066B5A
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 06066AF2 mov.b @r13,r1
    c.r[0] = c.r[1];  // 06066AF4 mov r1,r0
    c.r[0] >>= 2;  // 06066AF6 shlr2 r0
    c.r[0] &= 0x1u;  // 06066AF8 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06066AFA tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[12]; if (k) { goto L_06066B5A; } }  // 06066AFC bt/s 0x06066B5A ; mov r12,r1
    c.r[1] <<= 2;  // 06066B00 shll2 r1
    c.r[1] <<= 2;  // 06066B02 shll2 r1
    c.r[1] <<= 2;  // 06066B04 shll2 r1
    c.r[1] += c.r[10];  // 06066B06 add r10,r1
    c.t = (int32_t)c.r[1] >= 0;  // 06066B08 cmp/pz r1
    c.r[5] = c.r[1]; goto L_06066B2C;  // 06066B0A bra 0x06066B2C ; mov r1,r5
L_06066B2C:
    if (c.t) { goto L_06066B30; }  // 06066B2C bt 0x06066B30
    c.r[5] += 7;  // 06066B2E add #7,r5
L_06066B30:
    c.r[8] = c.r[5];  // 06066B30 mov r5,r8
    c.t = c.r[8] & 1; c.r[8] = (uint32_t)((int32_t)c.r[8] >> 1);  // 06066B32 shar r8
    c.t = c.r[8] & 1; c.r[8] = (uint32_t)((int32_t)c.r[8] >> 1);  // 06066B34 shar r8
    c.t = c.r[8] & 1; c.r[8] = (uint32_t)((int32_t)c.r[8] >> 1);  // 06066B36 shar r8
    c.r[5] = c.r[8];  // 06066B38 mov r8,r5
    c.r[5] <<= 2;  // 06066B3A shll2 r5
    c.r[5] += c.r[5];  // 06066B3C add r5,r5
    c.r[5] -= c.r[1];  // 06066B3E sub r1,r5
    c.r[5] += 7;  // 06066B40 add #7,r5
    c.r[0] = ld32(0x06066C44u);  // 06066B42 mov.l 0x06066C44,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06066B48u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06066B48u) return; }  // 06066B44 jsr @r0 ; mov #1,r4
    c.r[2] = c.r[0];  // 06066B48 mov r0,r2
    c.r[11] = (uint32_t)(int16_t)ld16(0x06066C3Eu);  // 06066B4A mov.w 0x06066C3E,r11
    c.r[11] += c.r[14];  // 06066B4C add r14,r11
    c.r[0] = ld32(c.r[11]);  // 06066B4E mov.l @r11,r0
    c.r[11] = (uint32_t)(int16_t)ld16(0x06066C3Eu);  // 06066B50 mov.w 0x06066C3E,r11
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 06066B52 mov.b @(r0,r8),r1
    c.r[11] += c.r[14];  // 06066B54 add r14,r11
    c.r[2] |= c.r[1];  // 06066B56 or r1,r2
    st8(c.r[0] + c.r[8], c.r[2]);  // 06066B58 mov.b r2,@(r0,r8)
L_06066B5A:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06066C40u);  // 06066B5A mov.w 0x06066C40,r0
    c.t = c.r[9] == c.r[0];  // 06066B5C cmp/eq r0,r9
    { const bool k = !c.t; c.r[1] = c.r[10]; if (k) { goto L_06066B66; } }  // 06066B5E bf/s 0x06066B66 ; mov r10,r1
    goto L_06066DA2;  // 06066B62 bra 0x06066DA2 ; nop
L_06066B66:
    c.r[1] = ld32(0x06066C48u);  // 06066B66 mov.l 0x06066C48,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06066B68 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06066B6A extu.b r1,r1
    c.t = c.r[9] == c.r[1];  // 06066B6C cmp/eq r1,r9
    { const bool k = !c.t; c.r[2] = c.r[9]; if (k) { goto L_06066B96; } }  // 06066B6E bf/s 0x06066B96 ; mov r9,r2
    c.r[11] = ld32(0x06066C4Cu);  // 06066B72 mov.l 0x06066C4C,r11
    c.r[1] = ld32(c.r[11]);  // 06066B74 mov.l @r11,r1
    c.r[2] <<= 2;  // 06066B76 shll2 r2
    c.r[2] <<= 2;  // 06066B78 shll2 r2
    c.r[2] += c.r[1];  // 06066B7A add r1,r2
    c.r[2] += 7;  // 06066B7C add #7,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06066B7E mov.b @r2,r1
    c.r[0] = 0x1u;  // 06066B80 mov #1,r0
    c.r[1] >>= 2;  // 06066B82 shlr2 r1
    c.r[1] >>= 2;  // 06066B84 shlr2 r1
    c.r[1] &= c.r[0];  // 06066B86 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06066B88 tst r1,r1
    { const bool k = !c.t; c.r[1] = c.r[10]; if (k) { goto L_06066B92; } }  // 06066B8A bf/s 0x06066B92 ; mov r10,r1
    goto L_06066DA2;  // 06066B8E bra 0x06066DA2 ; nop
L_06066B92:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]); goto L_06066CCA;  // 06066B92 bra 0x06066CCA ; mov.b @r13,r1
L_06066B96:
    c.r[0] = ld32(0x06066C4Cu);  // 06066B96 mov.l 0x06066C4C,r0
    c.r[7] = c.r[1];  // 06066B98 mov r1,r7
    c.r[7] <<= 2;  // 06066B9A shll2 r7
    c.r[7] <<= 2;  // 06066B9C shll2 r7
    c.r[2] = ld32(c.r[0]);  // 06066B9E mov.l @r0,r2
    c.r[3] = c.r[9];  // 06066BA0 mov r9,r3
    c.r[7] += c.r[2];  // 06066BA2 add r2,r7
    c.r[1] = c.r[7];  // 06066BA4 mov r7,r1
    c.r[1] += 3;  // 06066BA6 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06066BA8 mov.b @r1,r1
    c.r[11] = 0x3u;  // 06066BAA mov #3,r11
    c.r[6] = c.r[1];  // 06066BAC mov r1,r6
    c.t = c.r[6] & 1; c.r[6] >>= 1;  // 06066BAE shlr r6
    c.r[3] <<= 2;  // 06066BB0 shll2 r3
    c.r[3] <<= 2;  // 06066BB2 shll2 r3
    c.r[3] += c.r[2];  // 06066BB4 add r2,r3
    c.r[1] = c.r[3];  // 06066BB6 mov r3,r1
    c.r[1] += 3;  // 06066BB8 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06066BBA mov.b @r1,r1
    c.r[6] &= c.r[11];  // 06066BBC and r11,r6
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06066BBE shlr r1
    c.r[1] &= c.r[11];  // 06066BC0 and r11,r1
    c.t = c.r[6] == c.r[1];  // 06066BC2 cmp/eq r1,r6
    { const bool k = !c.t; c.r[3] += 7; if (k) { goto L_06066C54; } }  // 06066BC4 bf/s 0x06066C54 ; add #7,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06066BC8 mov.b @r3,r1
    c.r[2] = c.r[1] & 0xFFu;  // 06066BCA extu.b r1,r2
    c.r[1] = c.r[2];  // 06066BCC mov r2,r1
    c.r[1] >>= 2;  // 06066BCE shlr2 r1
    c.r[1] >>= 2;  // 06066BD0 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06066BD2 shlr r1
    c.r[1] >>= 2;  // 06066BD4 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06066BD6 tst r1,r1
    if (c.t) { goto L_06066C54; }  // 06066BD8 bt 0x06066C54
    c.r[0] = (uint32_t)(int16_t)ld16(0x06066C42u);  // 06066BDA mov.w 0x06066C42,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06066BDC mov.l @(r0,r14),r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06066BDE tst r0,r0
    { const bool k = !c.t; c.r[7] += 7; if (k) { goto L_06066C28; } }  // 06066BE0 bf/s 0x06066C28 ; add #7,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06066BE4 mov.b @r7,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06066BE6 extu.b r1,r1
    c.r[1] >>= 2;  // 06066BE8 shlr2 r1
    c.r[1] >>= 2;  // 06066BEA shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06066BEC shlr r1
    c.r[1] >>= 2;  // 06066BEE shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06066BF0 tst r1,r1
    { const bool k = c.t; c.r[11] = 0x1u; if (k) { goto L_06066C0A; } }  // 06066BF2 bt/s 0x06066C0A ; mov #1,r11
    c.r[2] >>= 2;  // 06066BF6 shlr2 r2
    c.r[2] >>= 2;  // 06066BF8 shlr2 r2
    c.r[2] &= c.r[11];  // 06066BFA and r11,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06066BFC tst r2,r2
    { const bool k = c.t; c.r[1] = c.r[10]; if (k) { goto L_06066C06; } }  // 06066BFE bt/s 0x06066C06 ; mov r10,r1
    goto L_06066DA2;  // 06066C02 bra 0x06066DA2 ; nop
L_06066C06:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]); goto L_06066D90;  // 06066C06 bra 0x06066D90 ; mov.b @r13,r1
L_06066C0A:
    c.r[2] >>= 2;  // 06066C0A shlr2 r2
    c.r[2] >>= 2;  // 06066C0C shlr2 r2
    c.r[2] &= c.r[11];  // 06066C0E and r11,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06066C10 tst r2,r2
    { const bool k = !c.t; c.r[1] = c.r[10]; if (k) { goto L_06066C1A; } }  // 06066C12 bf/s 0x06066C1A ; mov r10,r1
    goto L_06066DA2;  // 06066C16 bra 0x06066DA2 ; nop
L_06066C1A:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 06066C1A mov.b @r13,r1
    c.r[4] = c.r[9];  // 06066C1C mov r9,r4
    c.r[0] = ld32(0x06066C50u);  // 06066C1E mov.l 0x06066C50,r0
    c.r[1] >>= 2;  // 06066C20 shlr2 r1
    c.r[1] &= c.r[11];  // 06066C22 and r11,r1
    c.r[5] = c.r[1]; goto L_06066D9C;  // 06066C24 bra 0x06066D9C ; mov r1,r5
L_06066C28:
    c.r[2] >>= 2;  // 06066C28 shlr2 r2
    c.r[2] >>= 2;  // 06066C2A shlr2 r2
    c.r[11] = 0x1u;  // 06066C2C mov #1,r11
    c.r[2] &= c.r[11];  // 06066C2E and r11,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06066C30 tst r2,r2
    { const bool k = c.t; c.r[1] = c.r[10]; if (k) { goto L_06066C3A; } }  // 06066C32 bt/s 0x06066C3A ; mov r10,r1
    goto L_06066DA2;  // 06066C36 bra 0x06066DA2 ; nop
L_06066C3A:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]); goto L_06066D90;  // 06066C3A bra 0x06066D90 ; mov.b @r13,r1
L_06066C54:
    c.r[1] = ld32(0x06066D04u);  // 06066C54 mov.l 0x06066D04,r1
    c.r[11] = ld32(0x06066D08u);  // 06066C56 mov.l 0x06066D08,r11
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06066C58 mov.b @r1,r1
    c.r[3] = c.r[9];  // 06066C5A mov r9,r3
    c.r[2] = ld32(c.r[11]);  // 06066C5C mov.l @r11,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06066C5E extu.b r1,r1
    c.r[1] <<= 2;  // 06066C60 shll2 r1
    c.r[1] <<= 2;  // 06066C62 shll2 r1
    c.r[1] += c.r[2];  // 06066C64 add r2,r1
    c.r[1] += 3;  // 06066C66 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06066C68 mov.b @r1,r1
    c.r[0] = 0x3u;  // 06066C6A mov #3,r0
    c.r[7] = c.r[1];  // 06066C6C mov r1,r7
    c.t = c.r[7] & 1; c.r[7] >>= 1;  // 06066C6E shlr r7
    c.r[3] <<= 2;  // 06066C70 shll2 r3
    c.r[3] <<= 2;  // 06066C72 shll2 r3
    c.r[3] += c.r[2];  // 06066C74 add r2,r3
    c.r[1] = c.r[3];  // 06066C76 mov r3,r1
    c.r[1] += 3;  // 06066C78 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06066C7A mov.b @r1,r1
    c.r[7] &= c.r[0];  // 06066C7C and r0,r7
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06066C7E shlr r1
    c.r[1] &= c.r[0];  // 06066C80 and r0,r1
    c.t = c.r[7] == c.r[1];  // 06066C82 cmp/eq r1,r7
    { const bool k = !c.t; c.r[11] = 0xFu; if (k) { goto L_06066D14; } }  // 06066C84 bf/s 0x06066D14 ; mov #15,r11
    c.r[1] = ld32(0x06066D0Cu);  // 06066C88 mov.l 0x06066D0C,r1
    c.r[1] = ld32(c.r[1]);  // 06066C8A mov.l @r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06066D00u);  // 06066C8C mov.w 0x06066D00,r2
    c.r[0] = c.r[1];  // 06066C8E mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06066C90 mov.b @(r0,r2),r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06066C92 shlr r1
    c.r[1] &= c.r[11];  // 06066C94 and r11,r1
    c.r[0] = c.r[1];  // 06066C96 mov r1,r0
    c.t = c.r[0] == 0x9u;  // 06066C98 cmp/eq #9,r0
    { const bool k = !c.t; c.r[0] = c.r[14]; if (k) { goto L_06066D14; } }  // 06066C9A bf/s 0x06066D14 ; mov r14,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06066C9E mov.b @(r0,r2),r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06066CA0 shlr r1
    c.r[1] &= c.r[11];  // 06066CA2 and r11,r1
    c.r[0] = c.r[1];  // 06066CA4 mov r1,r0
    c.t = c.r[0] == 0x9u;  // 06066CA6 cmp/eq #9,r0
    if (!c.t) { goto L_06066D14; }  // 06066CA8 bf 0x06066D14
    c.r[11] = (uint32_t)(int16_t)ld16(0x06066D02u);  // 06066CAA mov.w 0x06066D02,r11
    c.r[11] += c.r[14];  // 06066CAC add r14,r11
    c.r[11] = ld32(c.r[11]);  // 06066CAE mov.l @r11,r11
    c.t = (c.r[11] & c.r[11]) == 0;  // 06066CB0 tst r11,r11
    { const bool k = !c.t; c.r[3] += 7; if (k) { goto L_06066CDA; } }  // 06066CB2 bf/s 0x06066CDA ; add #7,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06066CB6 mov.b @r3,r1
    c.r[0] = c.r[1];  // 06066CB8 mov r1,r0
    c.r[0] >>= 2;  // 06066CBA shlr2 r0
    c.r[0] >>= 2;  // 06066CBC shlr2 r0
    c.r[0] &= 0x1u;  // 06066CBE and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06066CC0 tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[10]; if (k) { goto L_06066DA2; } }  // 06066CC2 bt/s 0x06066DA2 ; mov r10,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 06066CC6 mov.b @r13,r1
    c.r[0] = 0x1u;  // 06066CC8 mov #1,r0
L_06066CCA:
    c.r[4] = c.r[9];  // 06066CCA mov r9,r4
    c.r[11] = ld32(0x06066D10u);  // 06066CCC mov.l 0x06066D10,r11
    c.r[1] >>= 2;  // 06066CCE shlr2 r1
    c.r[1] &= c.r[0];  // 06066CD0 and r0,r1
    { const uint32_t x = c.r[11]; c.pr = 0x06066CD6u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06066CD6u) return; }  // 06066CD2 jsr @r11 ; mov r1,r5
    c.r[1] = c.r[10]; goto L_06066DA2;  // 06066CD6 bra 0x06066DA2 ; mov r10,r1
L_06066CDA:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06066CDA mov.b @r3,r1
    c.r[0] = c.r[1];  // 06066CDC mov r1,r0
    c.r[0] >>= 2;  // 06066CDE shlr2 r0
    c.r[0] >>= 2;  // 06066CE0 shlr2 r0
    c.r[0] &= 0x1u;  // 06066CE2 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06066CE4 tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[10]; if (k) { goto L_06066DA2; } }  // 06066CE6 bf/s 0x06066DA2 ; mov r10,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 06066CEA mov.b @r13,r1
    c.r[0] = 0x1u;  // 06066CEC mov #1,r0
    c.r[4] = c.r[9];  // 06066CEE mov r9,r4
    c.r[11] = ld32(0x06066D10u);  // 06066CF0 mov.l 0x06066D10,r11
    c.r[1] >>= 2;  // 06066CF2 shlr2 r1
    c.r[1] &= c.r[0];  // 06066CF4 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06066CF6 tst r1,r1
    { const uint32_t x = c.r[11]; c.pr = 0x06066CFCu; c.r[5] = c.t; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06066CFCu) return; }  // 06066CF8 jsr @r11 ; movt r5
    c.r[1] = c.r[10]; goto L_06066DA2;  // 06066CFC bra 0x06066DA2 ; mov r10,r1
L_06066D14:
    c.r[0] = ld32(0x06066E08u);  // 06066D14 mov.l 0x06066E08,r0
    c.r[2] = c.r[9];  // 06066D16 mov r9,r2
    c.r[3] = ld32(c.r[0]);  // 06066D18 mov.l @r0,r3
    c.r[2] <<= 2;  // 06066D1A shll2 r2
    c.r[2] <<= 2;  // 06066D1C shll2 r2
    c.r[2] += c.r[3];  // 06066D1E add r3,r2
    c.r[1] = c.r[2];  // 06066D20 mov r2,r1
    c.r[1] += 7;  // 06066D22 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06066D24 mov.b @r1,r1
    c.r[11] = 0x1u;  // 06066D26 mov #1,r11
    c.r[1] >>= 2;  // 06066D28 shlr2 r1
    c.r[1] >>= 2;  // 06066D2A shlr2 r1
    c.r[1] &= c.r[11];  // 06066D2C and r11,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06066D2E tst r1,r1
    { const bool k = !c.t; c.r[1] = c.r[10]; if (k) { goto L_06066DA2; } }  // 06066D30 bf/s 0x06066DA2 ; mov r10,r1
    c.r[2] += 3;  // 06066D34 add #3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06066D36 mov.b @r2,r1
    c.r[2] = c.r[1];  // 06066D38 mov r1,r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 06066D3A shlr r2
    c.r[1] = ld32(0x06066E0Cu);  // 06066D3C mov.l 0x06066E0C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06066D3E mov.b @r1,r1
    c.r[0] = 0x3u;  // 06066D40 mov #3,r0
    c.r[1] = c.r[1] & 0xFFu;  // 06066D42 extu.b r1,r1
    c.r[1] <<= 2;  // 06066D44 shll2 r1
    c.r[1] <<= 2;  // 06066D46 shll2 r1
    c.r[1] += c.r[3];  // 06066D48 add r3,r1
    c.r[1] += 3;  // 06066D4A add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06066D4C mov.b @r1,r1
    c.r[2] &= c.r[0];  // 06066D4E and r0,r2
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06066D50 shlr r1
    c.r[1] &= c.r[0];  // 06066D52 and r0,r1
    c.t = c.r[2] == c.r[1];  // 06066D54 cmp/eq r1,r2
    { const bool k = c.t; c.r[1] = c.r[10]; if (k) { goto L_06066D8C; } }  // 06066D56 bt/s 0x06066D8C ; mov r10,r1
    c.r[1] += c.r[1];  // 06066D5A add r1,r1
    c.r[2] = c.r[12];  // 06066D5C mov r12,r2
    c.r[2] <<= 2;  // 06066D5E shll2 r2
    c.r[2] <<= 2;  // 06066D60 shll2 r2
    c.r[2] += c.r[2];  // 06066D62 add r2,r2
    c.r[2] <<= 2;  // 06066D64 shll2 r2
    c.r[11] = (uint32_t)(int16_t)ld16(0x06066E00u);  // 06066D66 mov.w 0x06066E00,r11
    c.r[11] += c.r[14];  // 06066D68 add r14,r11
    c.r[11] = ld32(c.r[11]);  // 06066D6A mov.l @r11,r11
    c.r[0] = c.r[1];  // 06066D6C mov r1,r0
    c.r[2] += c.r[11];  // 06066D6E add r11,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 06066D70 mov.w @(r0,r2),r1
    c.r[2] = c.r[1] & 0xFFFFu;  // 06066D72 extu.w r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06066D74 tst r2,r2
    if (c.t) { goto L_06066D8C; }  // 06066D76 bt 0x06066D8C
    c.r[1] = ld32(0x06066E10u);  // 06066D78 mov.l 0x06066E10,r1
    c.t = c.r[2] == c.r[1];  // 06066D7A cmp/eq r1,r2
    { const bool k = c.t; c.r[1] = c.r[14]; if (k) { goto L_06066D8C; } }  // 06066D7C bt/s 0x06066D8C ; mov r14,r1
    c.r[1] += 36;  // 06066D80 add #36,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06066D82 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06066D84 extu.b r1,r1
    c.t = c.r[2] > c.r[1];  // 06066D86 cmp/hi r1,r2
    { const bool k = !c.t; c.r[1] = c.r[10]; if (k) { goto L_06066DA2; } }  // 06066D88 bf/s 0x06066DA2 ; mov r10,r1
L_06066D8C:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 06066D8C mov.b @r13,r1
    c.r[11] = 0x1u;  // 06066D8E mov #1,r11
L_06066D90:
    c.r[4] = c.r[9];  // 06066D90 mov r9,r4
    c.r[0] = ld32(0x06066E14u);  // 06066D92 mov.l 0x06066E14,r0
    c.r[1] >>= 2;  // 06066D94 shlr2 r1
    c.r[1] &= c.r[11];  // 06066D96 and r11,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06066D98 tst r1,r1
    c.r[5] = c.t;  // 06066D9A movt r5
L_06066D9C:
    { const uint32_t x = c.r[0]; c.pr = 0x06066DA0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06066DA0u) return; }  // 06066D9C jsr @r0 ; nop
L_06066DA0:
    c.r[1] = c.r[10];  // 06066DA0 mov r10,r1
L_06066DA2:
    c.r[1] += 1;  // 06066DA2 add #1,r1
    c.r[10] = c.r[1] & 0xFFu;  // 06066DA4 extu.b r1,r10
    c.r[2] = 0x3Fu;  // 06066DA6 mov #63,r2
    c.t = c.r[10] > c.r[2];  // 06066DA8 cmp/hi r2,r10
    { const bool k = c.t; c.r[1] = c.r[12]; if (k) { goto L_06066DB2; } }  // 06066DAA bt/s 0x06066DB2 ; mov r12,r1
    SH2_POLL(c); goto L_060666EE;  // 06066DAE bra 0x060666EE ; nop
L_06066DB2:
    c.r[1] += 1;  // 06066DB2 add #1,r1
    c.r[12] = c.r[1] & 0xFFu;  // 06066DB4 extu.b r1,r12
    c.r[1] = c.r[2];  // 06066DB6 mov r2,r1
    c.t = c.r[12] > c.r[1];  // 06066DB8 cmp/hi r1,r12
    { const bool k = c.t; c.r[10] = 0x0u; if (k) { goto L_06066DC2; } }  // 06066DBA bt/s 0x06066DC2 ; mov #0,r10
    SH2_POLL(c); goto L_060666E6;  // 06066DBE bra 0x060666E6 ; nop
L_06066DC2:
    c.r[2] = ld32(0x06066E18u);  // 06066DC2 mov.l 0x06066E18,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06066DC4 mov.w @r2,r1
    c.r[4] = 0x0u;  // 06066DC6 mov #0,r4
    c.r[0] = c.r[1];  // 06066DC8 mov r1,r0
    c.r[0] >>= 2;  // 06066DCA shlr2 r0
    c.r[0] >>= 2;  // 06066DCC shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06066DCE shlr r0
    c.r[0] >>= 2;  // 06066DD0 shlr2 r0
    c.r[0] &= 0x7u;  // 06066DD2 and #7,r0
    c.r[0] += 1;  // 06066DD4 add #1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06066DD6 mov.b @r2,r1
    c.r[6] = c.r[0] & 0xFFu;  // 06066DD8 extu.b r0,r6
    c.r[0] = c.r[1];  // 06066DDA mov r1,r0
    c.r[0] >>= 2;  // 06066DDC shlr2 r0
    c.r[0] &= 0x1u;  // 06066DDE and #1,r0
    c.r[1] = ld32(0x06066E1Cu);  // 06066DE0 mov.l 0x06066E1C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06066DE6u; c.r[5] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06066DE6u) return; }  // 06066DE2 jsr @r1 ; mov r0,r5
    c.r[3] = (uint32_t)(int16_t)ld16(0x06066E02u);  // 06066DE6 mov.w 0x06066E02,r3
    c.r[14] += c.r[3];  // 06066DE8 add r3,r14
    c.r[15] = c.r[14];  // 06066DEA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06066DEC lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06066DEE mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06066DF0 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06066DF2 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06066DF4 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06066DF6 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06066DF8 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06066E04u);  // 06066DFA mov.w 0x06066E04,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06066DFC rts ; mov.l @r15+,r8
}

void f_06066E20(SH2Context& c) {
    ran[1504] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06066E20 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06066E22 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06066E24 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06066E26 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06066E28 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06066E2A mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06066E2C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06066E2E sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x06066F66u);  // 06066E30 mov.w 0x06066F66,r3
    c.r[15] += c.r[3];  // 06066E32 add r3,r15
    c.r[14] = c.r[15];  // 06066E34 mov r15,r14
    c.r[5] = c.r[5] & 0xFFu;  // 06066E36 extu.b r5,r5
    c.r[0] = (uint32_t)(int16_t)ld16(0x06066F68u);  // 06066E38 mov.w 0x06066F68,r0
    st32(c.r[0] + c.r[14], c.r[5]);  // 06066E3A mov.l r5,@(r0,r14)
    c.r[6] = c.r[6] & 0xFFu;  // 06066E3C extu.b r6,r6
    c.r[13] = (uint32_t)(int16_t)ld16(0x06066F6Au);  // 06066E3E mov.w 0x06066F6A,r13
    c.r[13] += c.r[14];  // 06066E40 add r14,r13
    st32(c.r[13], c.r[6]);  // 06066E42 mov.l r6,@r13
    c.r[1] = ld32(0x06066F70u);  // 06066E44 mov.l 0x06066F70,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06066F6Au);  // 06066E46 mov.w 0x06066F6A,r0
    c.r[2] = ld32(c.r[1]);  // 06066E48 mov.l @r1,r2
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06066E4A mov.l @(r0,r14),r0
    c.r[1] = 0x40u;  // 06066E4C mov #64,r1
    c.macl = c.r[0] * c.r[1];  // 06066E4E mul.l r1,r0
    c.r[13] = (uint32_t)(int16_t)ld16(0x06066F68u);  // 06066E50 mov.w 0x06066F68,r13
    c.r[13] += c.r[14];  // 06066E52 add r14,r13
    c.r[1] = c.macl;  // 06066E54 sts macl,r1
    c.r[0] = ld32(c.r[13]);  // 06066E56 mov.l @r13,r0
    c.r[1] += c.r[2];  // 06066E58 add r2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06066E5A mov.b @(r0,r1),r1
    c.r[11] = c.r[1] & 0xFFu;  // 06066E5C extu.b r1,r11
    c.r[1] = (uint32_t)(int16_t)ld16(0x06066F6Cu);  // 06066E5E mov.w 0x06066F6C,r1
    c.t = c.r[11] == c.r[1];  // 06066E60 cmp/eq r1,r11
    { const bool k = !c.t; c.r[8] = c.r[4] & 0xFFu; if (k) { goto L_06066E88; } }  // 06066E62 bf/s 0x06066E88 ; extu.b r4,r8
    c.r[0] = (uint32_t)(int16_t)ld16(0x06066F68u);  // 06066E66 mov.w 0x06066F68,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06066E68 mov.l @(r0,r14),r0
    c.r[1] = c.macl;  // 06066E6A sts macl,r1
    c.r[1] += c.r[0];  // 06066E6C add r0,r1
    c.t = (int32_t)c.r[1] >= 0;  // 06066E6E cmp/pz r1
    c.r[9] = ld32(0x06066F74u);  // 06066E70 mov.l 0x06066F74,r9
    { const bool k = c.t; c.r[5] = c.r[1]; if (k) { goto L_06066E78; } }  // 06066E72 bt/s 0x06066E78 ; mov r1,r5
    c.r[5] += 7;  // 06066E76 add #7,r5
L_06066E78:
    c.r[8] = c.r[5];  // 06066E78 mov r5,r8
    c.r[8] >>= 2;  // 06066E7A shlr2 r8
    c.t = c.r[8] & 1; c.r[8] >>= 1;  // 06066E7C shlr r8
    c.r[5] = c.r[8];  // 06066E7E mov r8,r5
    c.r[5] <<= 2;  // 06066E80 shll2 r5
    c.r[5] += c.r[5];  // 06066E82 add r5,r5
    c.r[5] -= c.r[1]; goto L_060673DE;  // 06066E84 bra 0x060673DE ; sub r1,r5
L_06066E88:
    c.r[1] = ld32(0x06066F78u);  // 06066E88 mov.l 0x06066F78,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06066E8A mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06066E8C extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06066E8E tst r1,r1
    if (c.t) { goto L_06066E98; }  // 06066E90 bt 0x06066E98
    c.r[1] = ld32(0x06066F7Cu);  // 06066E92 mov.l 0x06066F7C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]); goto L_06066E9C;  // 06066E94 bra 0x06066E9C ; mov.b @r1,r1
L_06066E98:
    c.r[1] = ld32(0x06066F80u);  // 06066E98 mov.l 0x06066F80,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06066E9A mov.b @r1,r1
L_06066E9C:
    c.r[10] = c.r[1] & 0xFFu;  // 06066E9C extu.b r1,r10
    c.r[1] = 0x1Cu;  // 06066E9E mov #28,r1
    c.r[2] = c.r[8];  // 06066EA0 mov r8,r2
    c.r[2] -= 2;  // 06066EA2 add #-2,r2
    c.t = c.r[2] > c.r[1];  // 06066EA4 cmp/hi r1,r2
    { const bool k = !c.t; c.r[1] = c.r[2]; if (k) { goto L_06066EAE; } }  // 06066EA6 bf/s 0x06066EAE ; mov r2,r1
    goto L_060673F0;  // 06066EAA bra 0x060673F0 ; nop
L_06066EAE:
    c.r[1] += c.r[1];  // 06066EAE add r1,r1
    c.r[0] = 0x06066EBCu;  // 06066EB0 mova 0x06066EBC,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06066EB2 mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 06066EB4 add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x06066EF6u: goto L_06066EF6; case 0x060673F0u: goto L_060673F0; case 0x06066F90u: goto L_06066F90; case 0x0606702Cu: goto L_0606702C; case 0x060670E8u: goto L_060670E8; case 0x06067170u: goto L_06067170; case 0x060671E2u: goto L_060671E2; case 0x0606727Cu: goto L_0606727C; case 0x060672D8u: goto L_060672D8; case 0x0606739Cu: goto L_0606739C; default: sh2_call(c, x); return; } }  // 06066EB6 jmp @r0 ; nop
L_06066EF6:
    c.r[1] = ld32(0x06066F84u);  // 06066EF6 mov.l 0x06066F84,r1
    c.r[2] = ld32(c.r[1]);  // 06066EF8 mov.l @r1,r2
    c.r[1] = c.r[11];  // 06066EFA mov r11,r1
    c.r[1] <<= 2;  // 06066EFC shll2 r1
    c.r[1] <<= 2;  // 06066EFE shll2 r1
    c.r[1] += c.r[2];  // 06066F00 add r2,r1
    c.r[1] += 3;  // 06066F02 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06066F04 mov.b @r1,r1
    c.r[13] = 0x3u;  // 06066F06 mov #3,r13
    c.r[3] = c.r[1];  // 06066F08 mov r1,r3
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 06066F0A shlr r3
    c.r[10] <<= 2;  // 06066F0C shll2 r10
    c.r[10] <<= 2;  // 06066F0E shll2 r10
    c.r[10] += c.r[2];  // 06066F10 add r2,r10
    c.r[10] += 3;  // 06066F12 add #3,r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 06066F14 mov.b @r10,r1
    c.r[3] &= c.r[13];  // 06066F16 and r13,r3
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06066F18 shlr r1
    c.r[1] &= c.r[13];  // 06066F1A and r13,r1
    c.t = c.r[3] == c.r[1];  // 06066F1C cmp/eq r1,r3
    if (!c.t) { goto L_06066F2E; }  // 06066F1E bf 0x06066F2E
    c.r[0] = ld32(0x06066F88u);  // 06066F20 mov.l 0x06066F88,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06066F26u; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06066F26u) return; }  // 06066F22 jsr @r0 ; mov r11,r4
    c.t = c.r[0] == 0xFFFFFFFFu;  // 06066F26 cmp/eq #-1,r0
    if (c.t) { goto L_06066F2E; }  // 06066F28 bt 0x06066F2E
    goto L_060673F0;  // 06066F2A bra 0x060673F0 ; nop
L_06066F2E:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06066F6Au);  // 06066F2E mov.w 0x06066F6A,r0
    c.r[0] += c.r[14];  // 06066F30 add r14,r0
    c.r[13] = (uint32_t)(int16_t)ld16(0x06066F68u);  // 06066F32 mov.w 0x06066F68,r13
    c.r[6] = ld32(c.r[0]);  // 06066F34 mov.l @r0,r6
    c.r[13] += c.r[14];  // 06066F36 add r14,r13
    c.r[13] = ld32(c.r[13]);  // 06066F38 mov.l @r13,r13
    c.r[6] <<= 2;  // 06066F3A shll2 r6
    c.r[6] <<= 2;  // 06066F3C shll2 r6
    c.r[6] <<= 2;  // 06066F3E shll2 r6
    c.r[6] += c.r[13];  // 06066F40 add r13,r6
    c.t = (int32_t)c.r[6] >= 0;  // 06066F42 cmp/pz r6
    c.r[9] = ld32(0x06066F74u);  // 06066F44 mov.l 0x06066F74,r9
    { const bool k = c.t; c.r[5] = c.r[6]; if (k) { goto L_06066F4C; } }  // 06066F46 bt/s 0x06066F4C ; mov r6,r5
    c.r[5] += 7;  // 06066F4A add #7,r5
L_06066F4C:
    c.r[8] = c.r[5];  // 06066F4C mov r5,r8
    c.r[8] >>= 2;  // 06066F4E shlr2 r8
    c.t = c.r[8] & 1; c.r[8] >>= 1;  // 06066F50 shlr r8
    c.r[5] = c.r[8];  // 06066F52 mov r8,r5
    c.r[5] <<= 2;  // 06066F54 shll2 r5
    c.r[5] += c.r[5];  // 06066F56 add r5,r5
    c.r[5] -= c.r[6];  // 06066F58 sub r6,r5
    c.r[5] += 7;  // 06066F5A add #7,r5
    c.r[0] = ld32(0x06066F8Cu);  // 06066F5C mov.l 0x06066F8C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06066F62u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06066F62u) return; }  // 06066F5E jsr @r0 ; mov #1,r4
    c.r[2] = c.r[0]; goto L_060673E8;  // 06066F62 bra 0x060673E8 ; mov r0,r2
L_06066F90:
    c.r[6] = (uint32_t)(int16_t)ld16(0x060670C6u);  // 06066F90 mov.w 0x060670C6,r6
    c.r[9] = ld32(0x060670D0u);  // 06066F92 mov.l 0x060670D0,r9
    c.r[8] = c.r[11];  // 06066F94 mov r11,r8
    c.r[1] = ld32(c.r[9]);  // 06066F96 mov.l @r9,r1
    c.r[8] <<= 2;  // 06066F98 shll2 r8
    c.r[8] <<= 2;  // 06066F9A shll2 r8
    c.r[1] += c.r[8];  // 06066F9C add r8,r1
    c.r[1] += 2;  // 06066F9E add #2,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06066FA0 mov.b @r1,r5
    c.r[4] = c.r[14];  // 06066FA2 mov r14,r4
    c.r[1] = ld32(0x060670D4u);  // 06066FA4 mov.l 0x060670D4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06066FAAu; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06066FAAu) return; }  // 06066FA6 jsr @r1 ; extu.b r5,r5
    c.r[2] = ld32(c.r[9]);  // 06066FAA mov.l @r9,r2
    c.r[8] += c.r[2];  // 06066FAC add r2,r8
    c.r[1] = c.r[8];  // 06066FAE mov r8,r1
    c.r[1] += 3;  // 06066FB0 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06066FB2 mov.b @r1,r1
    c.r[13] = 0x3u;  // 06066FB4 mov #3,r13
    c.r[7] = c.r[1];  // 06066FB6 mov r1,r7
    c.t = c.r[7] & 1; c.r[7] >>= 1;  // 06066FB8 shlr r7
    c.r[10] <<= 2;  // 06066FBA shll2 r10
    c.r[10] <<= 2;  // 06066FBC shll2 r10
    c.r[10] += c.r[2];  // 06066FBE add r2,r10
    c.r[10] += 3;  // 06066FC0 add #3,r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 06066FC2 mov.b @r10,r1
    c.r[7] &= c.r[13];  // 06066FC4 and r13,r7
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06066FC6 shlr r1
    c.r[1] &= c.r[13];  // 06066FC8 and r13,r1
    c.t = c.r[7] == c.r[1];  // 06066FCA cmp/eq r1,r7
    { const bool k = !c.t; c.r[1] = c.r[14]; if (k) { goto L_06066FF4; } }  // 06066FCC bf/s 0x06066FF4 ; mov r14,r1
    c.r[1] += 22;  // 06066FD0 add #22,r1
    c.r[3] = c.r[14];  // 06066FD2 mov r14,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06066FD4 mov.w @r1,r2
    c.r[3] += 26;  // 06066FD6 add #26,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06066FD8 mov.w @r3,r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 06066FDA extu.w r2,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 06066FDC extu.w r1,r1
    c.t = c.r[2] == c.r[1];  // 06066FDE cmp/eq r1,r2
    { const bool k = c.t; c.t = (c.r[7] & c.r[7]) == 0; if (k) { goto L_06066FF4; } }  // 06066FE0 bt/s 0x06066FF4 ; tst r7,r7
    if (c.t) { goto L_06066FEA; }  // 06066FE4 bt 0x06066FEA
    goto L_060673F0;  // 06066FE6 bra 0x060673F0 ; nop
L_06066FEA:
    c.r[1] = ld32(c.r[8] + 12);  // 06066FEA mov.l @(12,r8),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06066FEC tst r1,r1
    if (!c.t) { goto L_06066FF4; }  // 06066FEE bf 0x06066FF4
    goto L_060673F0;  // 06066FF0 bra 0x060673F0 ; nop
L_06066FF4:
    c.r[0] = (uint32_t)(int16_t)ld16(0x060670C8u);  // 06066FF4 mov.w 0x060670C8,r0
    c.r[0] += c.r[14];  // 06066FF6 add r14,r0
    c.r[13] = (uint32_t)(int16_t)ld16(0x060670CAu);  // 06066FF8 mov.w 0x060670CA,r13
    c.r[6] = ld32(c.r[0]);  // 06066FFA mov.l @r0,r6
    c.r[13] += c.r[14];  // 06066FFC add r14,r13
    c.r[13] = ld32(c.r[13]);  // 06066FFE mov.l @r13,r13
    c.r[6] <<= 2;  // 06067000 shll2 r6
    c.r[6] <<= 2;  // 06067002 shll2 r6
    c.r[6] <<= 2;  // 06067004 shll2 r6
    c.r[6] += c.r[13];  // 06067006 add r13,r6
    c.t = (int32_t)c.r[6] >= 0;  // 06067008 cmp/pz r6
    c.r[9] = ld32(0x060670D8u);  // 0606700A mov.l 0x060670D8,r9
    { const bool k = c.t; c.r[5] = c.r[6]; if (k) { goto L_06067012; } }  // 0606700C bt/s 0x06067012 ; mov r6,r5
    c.r[5] += 7;  // 06067010 add #7,r5
L_06067012:
    c.r[8] = c.r[5];  // 06067012 mov r5,r8
    c.r[8] >>= 2;  // 06067014 shlr2 r8
    c.t = c.r[8] & 1; c.r[8] >>= 1;  // 06067016 shlr r8
    c.r[5] = c.r[8];  // 06067018 mov r8,r5
    c.r[5] <<= 2;  // 0606701A shll2 r5
    c.r[5] += c.r[5];  // 0606701C add r5,r5
    c.r[5] -= c.r[6];  // 0606701E sub r6,r5
    c.r[5] += 7;  // 06067020 add #7,r5
    c.r[0] = ld32(0x060670DCu);  // 06067022 mov.l 0x060670DC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06067028u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06067028u) return; }  // 06067024 jsr @r0 ; mov #1,r4
    c.r[2] = c.r[0]; goto L_060673E8;  // 06067028 bra 0x060673E8 ; mov r0,r2
L_0606702C:
    c.r[1] = ld32(0x060670D0u);  // 0606702C mov.l 0x060670D0,r1
    c.r[7] = c.r[11];  // 0606702E mov r11,r7
    c.r[6] = ld32(c.r[1]);  // 06067030 mov.l @r1,r6
    c.r[7] <<= 2;  // 06067032 shll2 r7
    c.r[7] <<= 2;  // 06067034 shll2 r7
    c.r[7] += c.r[6];  // 06067036 add r6,r7
    c.r[1] = c.r[7];  // 06067038 mov r7,r1
    c.r[1] += 2;  // 0606703A add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606703C mov.b @r1,r2
    c.r[1] = ld32(0x060670E0u);  // 0606703E mov.l 0x060670E0,r1
    c.r[3] = ld32(c.r[1]);  // 06067040 mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06067042 extu.b r2,r2
    c.r[1] = 0x1Eu;  // 06067044 mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 06067046 mul.l r1,r2
    c.r[1] = c.macl;  // 06067048 sts macl,r1
    c.r[1] += c.r[3];  // 0606704A add r3,r1
    c.r[1] += 15;  // 0606704C add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606704E mov.b @r1,r1
    c.r[7] += 3;  // 06067050 add #3,r7
    c.r[8] = c.r[1] & 0xFFu;  // 06067052 extu.b r1,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06067054 mov.b @r7,r1
    c.r[13] = 0x3u;  // 06067056 mov #3,r13
    c.r[2] = c.r[1];  // 06067058 mov r1,r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 0606705A shlr r2
    c.r[10] <<= 2;  // 0606705C shll2 r10
    c.r[10] <<= 2;  // 0606705E shll2 r10
    c.r[10] += c.r[6];  // 06067060 add r6,r10
    c.r[10] += 3;  // 06067062 add #3,r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 06067064 mov.b @r10,r1
    c.r[2] &= c.r[13];  // 06067066 and r13,r2
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06067068 shlr r1
    c.r[1] &= c.r[13];  // 0606706A and r13,r1
    c.t = c.r[2] == c.r[1];  // 0606706C cmp/eq r1,r2
    { const bool k = !c.t; c.r[2] = c.r[8]; if (k) { goto L_0606708E; } }  // 0606706E bf/s 0x0606708E ; mov r8,r2
    c.r[1] = ld32(0x060670E4u);  // 06067072 mov.l 0x060670E4,r1
    c.r[2] += c.r[2];  // 06067074 add r2,r2
    c.r[2] += c.r[8];  // 06067076 add r8,r2
    c.r[1] = ld32(c.r[1]);  // 06067078 mov.l @r1,r1
    c.r[2] <<= 2;  // 0606707A shll2 r2
    c.r[2] += c.r[1];  // 0606707C add r1,r2
    c.r[2] += 9;  // 0606707E add #9,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06067080 mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06067082 extu.b r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x060670CCu);  // 06067084 mov.w 0x060670CC,r2
    c.t = c.r[1] > c.r[2];  // 06067086 cmp/hi r2,r1
    if (c.t) { goto L_0606708E; }  // 06067088 bt 0x0606708E
    goto L_060673F0;  // 0606708A bra 0x060673F0 ; nop
L_0606708E:
    c.r[0] = (uint32_t)(int16_t)ld16(0x060670C8u);  // 0606708E mov.w 0x060670C8,r0
    c.r[0] += c.r[14];  // 06067090 add r14,r0
    c.r[13] = (uint32_t)(int16_t)ld16(0x060670CAu);  // 06067092 mov.w 0x060670CA,r13
    c.r[6] = ld32(c.r[0]);  // 06067094 mov.l @r0,r6
    c.r[13] += c.r[14];  // 06067096 add r14,r13
    c.r[13] = ld32(c.r[13]);  // 06067098 mov.l @r13,r13
    c.r[6] <<= 2;  // 0606709A shll2 r6
    c.r[6] <<= 2;  // 0606709C shll2 r6
    c.r[6] <<= 2;  // 0606709E shll2 r6
    c.r[6] += c.r[13];  // 060670A0 add r13,r6
    c.t = (int32_t)c.r[6] >= 0;  // 060670A2 cmp/pz r6
    c.r[9] = ld32(0x060670D8u);  // 060670A4 mov.l 0x060670D8,r9
    { const bool k = c.t; c.r[5] = c.r[6]; if (k) { goto L_060670AC; } }  // 060670A6 bt/s 0x060670AC ; mov r6,r5
    c.r[5] += 7;  // 060670AA add #7,r5
L_060670AC:
    c.r[8] = c.r[5];  // 060670AC mov r5,r8
    c.r[8] >>= 2;  // 060670AE shlr2 r8
    c.t = c.r[8] & 1; c.r[8] >>= 1;  // 060670B0 shlr r8
    c.r[5] = c.r[8];  // 060670B2 mov r8,r5
    c.r[5] <<= 2;  // 060670B4 shll2 r5
    c.r[5] += c.r[5];  // 060670B6 add r5,r5
    c.r[5] -= c.r[6];  // 060670B8 sub r6,r5
    c.r[5] += 7;  // 060670BA add #7,r5
    c.r[0] = ld32(0x060670DCu);  // 060670BC mov.l 0x060670DC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060670C2u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060670C2u) return; }  // 060670BE jsr @r0 ; mov #1,r4
    c.r[2] = c.r[0]; goto L_060673E8;  // 060670C2 bra 0x060673E8 ; mov r0,r2
L_060670E8:
    c.r[1] = ld32(0x06067264u);  // 060670E8 mov.l 0x06067264,r1
    c.r[4] = c.r[11];  // 060670EA mov r11,r4
    c.r[2] = ld32(c.r[1]);  // 060670EC mov.l @r1,r2
    c.r[4] <<= 2;  // 060670EE shll2 r4
    c.r[4] <<= 2;  // 060670F0 shll2 r4
    c.r[4] += c.r[2];  // 060670F2 add r2,r4
    c.r[1] = c.r[4];  // 060670F4 mov r4,r1
    c.r[1] += 3;  // 060670F6 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060670F8 mov.b @r1,r1
    c.r[13] = 0x3u;  // 060670FA mov #3,r13
    c.r[3] = c.r[1];  // 060670FC mov r1,r3
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 060670FE shlr r3
    c.r[10] <<= 2;  // 06067100 shll2 r10
    c.r[10] <<= 2;  // 06067102 shll2 r10
    c.r[10] += c.r[2];  // 06067104 add r2,r10
    c.r[10] += 3;  // 06067106 add #3,r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 06067108 mov.b @r10,r1
    c.r[3] &= c.r[13];  // 0606710A and r13,r3
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0606710C shlr r1
    c.r[1] &= c.r[13];  // 0606710E and r13,r1
    c.t = c.r[3] == c.r[1];  // 06067110 cmp/eq r1,r3
    { const bool k = !c.t; c.r[1] = c.r[4]; if (k) { goto L_06067138; } }  // 06067112 bf/s 0x06067138 ; mov r4,r1
    c.r[1] += 7;  // 06067116 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06067118 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0606711A mov r1,r0
    c.r[0] >>= 2;  // 0606711C shlr2 r0
    c.r[0] >>= 2;  // 0606711E shlr2 r0
    c.r[0] &= 0x1u;  // 06067120 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06067122 tst r0,r0
    { const bool k = c.t; c.t = (c.r[3] & c.r[3]) == 0; if (k) { goto L_06067138; } }  // 06067124 bt/s 0x06067138 ; tst r3,r3
    if (c.t) { goto L_0606712E; }  // 06067128 bt 0x0606712E
    goto L_060673F0;  // 0606712A bra 0x060673F0 ; nop
L_0606712E:
    c.r[1] = ld32(c.r[4] + 12);  // 0606712E mov.l @(12,r4),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06067130 tst r1,r1
    if (!c.t) { goto L_06067138; }  // 06067132 bf 0x06067138
    goto L_060673F0;  // 06067134 bra 0x060673F0 ; nop
L_06067138:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606725Cu);  // 06067138 mov.w 0x0606725C,r0
    c.r[0] += c.r[14];  // 0606713A add r14,r0
    c.r[13] = (uint32_t)(int16_t)ld16(0x0606725Eu);  // 0606713C mov.w 0x0606725E,r13
    c.r[6] = ld32(c.r[0]);  // 0606713E mov.l @r0,r6
    c.r[13] += c.r[14];  // 06067140 add r14,r13
    c.r[13] = ld32(c.r[13]);  // 06067142 mov.l @r13,r13
    c.r[6] <<= 2;  // 06067144 shll2 r6
    c.r[6] <<= 2;  // 06067146 shll2 r6
    c.r[6] <<= 2;  // 06067148 shll2 r6
    c.r[6] += c.r[13];  // 0606714A add r13,r6
    c.t = (int32_t)c.r[6] >= 0;  // 0606714C cmp/pz r6
    c.r[9] = ld32(0x06067268u);  // 0606714E mov.l 0x06067268,r9
    { const bool k = c.t; c.r[5] = c.r[6]; if (k) { goto L_06067156; } }  // 06067150 bt/s 0x06067156 ; mov r6,r5
    c.r[5] += 7;  // 06067154 add #7,r5
L_06067156:
    c.r[8] = c.r[5];  // 06067156 mov r5,r8
    c.r[8] >>= 2;  // 06067158 shlr2 r8
    c.t = c.r[8] & 1; c.r[8] >>= 1;  // 0606715A shlr r8
    c.r[5] = c.r[8];  // 0606715C mov r8,r5
    c.r[5] <<= 2;  // 0606715E shll2 r5
    c.r[5] += c.r[5];  // 06067160 add r5,r5
    c.r[5] -= c.r[6];  // 06067162 sub r6,r5
    c.r[5] += 7;  // 06067164 add #7,r5
    c.r[0] = ld32(0x0606726Cu);  // 06067166 mov.l 0x0606726C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0606716Cu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606716Cu) return; }  // 06067168 jsr @r0 ; mov #1,r4
    c.r[2] = c.r[0]; goto L_060673E8;  // 0606716C bra 0x060673E8 ; mov r0,r2
L_06067170:
    c.r[1] = ld32(0x06067264u);  // 06067170 mov.l 0x06067264,r1
    c.r[7] = c.r[11];  // 06067172 mov r11,r7
    c.r[6] = ld32(c.r[1]);  // 06067174 mov.l @r1,r6
    c.r[7] <<= 2;  // 06067176 shll2 r7
    c.r[7] <<= 2;  // 06067178 shll2 r7
    c.r[7] += c.r[6];  // 0606717A add r6,r7
    c.r[1] = c.r[7];  // 0606717C mov r7,r1
    c.r[1] += 2;  // 0606717E add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06067180 mov.b @r1,r2
    c.r[1] = ld32(0x06067270u);  // 06067182 mov.l 0x06067270,r1
    c.r[3] = ld32(c.r[1]);  // 06067184 mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06067186 extu.b r2,r2
    c.r[1] = 0x1Eu;  // 06067188 mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 0606718A mul.l r1,r2
    c.r[13] = 0xFu;  // 0606718C mov #15,r13
    c.r[1] = c.macl;  // 0606718E sts macl,r1
    c.r[1] += c.r[3];  // 06067190 add r3,r1
    c.r[1] += 15;  // 06067192 add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06067194 mov.b @r1,r1
    c.r[7] += 4;  // 06067196 add #4,r7
    c.r[8] = c.r[1] & 0xFFu;  // 06067198 extu.b r1,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0606719A mov.b @r7,r1
    c.r[0] = 0x3u;  // 0606719C mov #3,r0
    c.r[2] = c.r[1];  // 0606719E mov r1,r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 060671A0 shlr r2
    c.r[2] &= c.r[13];  // 060671A2 and r13,r2
    c.r[10] <<= 2;  // 060671A4 shll2 r10
    c.r[10] <<= 2;  // 060671A6 shll2 r10
    c.r[10] += c.r[6];  // 060671A8 add r6,r10
    c.r[10] += 3;  // 060671AA add #3,r10
    c.r[4] = c.r[2];  // 060671AC mov r2,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 060671AE mov.b @r10,r1
    c.r[13] = ld32(0x06067274u);  // 060671B0 mov.l 0x06067274,r13
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060671B2 shlr r1
    c.r[1] &= c.r[0];  // 060671B4 and r0,r1
    { const uint32_t x = c.r[13]; c.pr = 0x060671BAu; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060671BAu) return; }  // 060671B6 jsr @r13 ; mov r1,r5
    c.r[1] = c.r[0];  // 060671BA mov r0,r1
    c.r[0] = 0x1u;  // 060671BC mov #1,r0
    c.r[1] &= c.r[0];  // 060671BE and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060671C0 tst r1,r1
    { const bool k = !c.t; c.r[2] = c.r[8]; if (k) { goto L_060671CA; } }  // 060671C2 bf/s 0x060671CA ; mov r8,r2
    goto L_060673B4;  // 060671C6 bra 0x060673B4 ; nop
L_060671CA:
    c.r[1] = ld32(0x06067278u);  // 060671CA mov.l 0x06067278,r1
    c.r[2] += c.r[2];  // 060671CC add r2,r2
    c.r[2] += c.r[8];  // 060671CE add r8,r2
    c.r[1] = ld32(c.r[1]);  // 060671D0 mov.l @r1,r1
    c.r[2] <<= 2;  // 060671D2 shll2 r2
    c.r[2] += c.r[1];  // 060671D4 add r1,r2
    c.r[2] += 9;  // 060671D6 add #9,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060671D8 mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060671DA extu.b r1,r1
    c.r[2] = 0x32u;  // 060671DC mov #50,r2
    c.t = c.r[1] > c.r[2]; goto L_060673B2;  // 060671DE bra 0x060673B2 ; cmp/hi r2,r1
L_060671E2:
    c.r[1] = ld32(0x06067264u);  // 060671E2 mov.l 0x06067264,r1
    c.r[3] = c.r[11];  // 060671E4 mov r11,r3
    c.r[2] = ld32(c.r[1]);  // 060671E6 mov.l @r1,r2
    c.r[3] <<= 2;  // 060671E8 shll2 r3
    c.r[3] <<= 2;  // 060671EA shll2 r3
    c.r[3] += c.r[2];  // 060671EC add r2,r3
    c.r[1] = c.r[3];  // 060671EE mov r3,r1
    c.r[1] += 3;  // 060671F0 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060671F2 mov.b @r1,r1
    c.r[13] = 0x3u;  // 060671F4 mov #3,r13
    c.r[7] = c.r[1];  // 060671F6 mov r1,r7
    c.t = c.r[7] & 1; c.r[7] >>= 1;  // 060671F8 shlr r7
    c.r[1] = c.r[10];  // 060671FA mov r10,r1
    c.r[1] <<= 2;  // 060671FC shll2 r1
    c.r[1] <<= 2;  // 060671FE shll2 r1
    c.r[1] += c.r[2];  // 06067200 add r2,r1
    c.r[1] += 3;  // 06067202 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06067204 mov.b @r1,r1
    c.r[7] &= c.r[13];  // 06067206 and r13,r7
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06067208 shlr r1
    c.r[1] &= c.r[13];  // 0606720A and r13,r1
    c.t = c.r[7] == c.r[1];  // 0606720C cmp/eq r1,r7
    { const bool k = !c.t; c.r[3] += 8; if (k) { goto L_06067224; } }  // 0606720E bf/s 0x06067224 ; add #8,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06067212 mov.b @r3,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06067260u);  // 06067214 mov.w 0x06067260,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06067216 extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 06067218 cmp/eq r2,r1
    { const bool k = !c.t; c.t = c.r[11] == c.r[10]; if (k) { goto L_06067224; } }  // 0606721A bf/s 0x06067224 ; cmp/eq r10,r11
    if (c.t) { goto L_06067224; }  // 0606721E bt 0x06067224
    goto L_060673F0;  // 06067220 bra 0x060673F0 ; nop
L_06067224:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606725Cu);  // 06067224 mov.w 0x0606725C,r0
    c.r[0] += c.r[14];  // 06067226 add r14,r0
    c.r[13] = (uint32_t)(int16_t)ld16(0x0606725Eu);  // 06067228 mov.w 0x0606725E,r13
    c.r[6] = ld32(c.r[0]);  // 0606722A mov.l @r0,r6
    c.r[13] += c.r[14];  // 0606722C add r14,r13
    c.r[13] = ld32(c.r[13]);  // 0606722E mov.l @r13,r13
    c.r[6] <<= 2;  // 06067230 shll2 r6
    c.r[6] <<= 2;  // 06067232 shll2 r6
    c.r[6] <<= 2;  // 06067234 shll2 r6
    c.r[6] += c.r[13];  // 06067236 add r13,r6
    c.t = (int32_t)c.r[6] >= 0;  // 06067238 cmp/pz r6
    c.r[9] = ld32(0x06067268u);  // 0606723A mov.l 0x06067268,r9
    { const bool k = c.t; c.r[5] = c.r[6]; if (k) { goto L_06067242; } }  // 0606723C bt/s 0x06067242 ; mov r6,r5
    c.r[5] += 7;  // 06067240 add #7,r5
L_06067242:
    c.r[8] = c.r[5];  // 06067242 mov r5,r8
    c.r[8] >>= 2;  // 06067244 shlr2 r8
    c.t = c.r[8] & 1; c.r[8] >>= 1;  // 06067246 shlr r8
    c.r[5] = c.r[8];  // 06067248 mov r8,r5
    c.r[5] <<= 2;  // 0606724A shll2 r5
    c.r[5] += c.r[5];  // 0606724C add r5,r5
    c.r[5] -= c.r[6];  // 0606724E sub r6,r5
    c.r[5] += 7;  // 06067250 add #7,r5
    c.r[0] = ld32(0x0606726Cu);  // 06067252 mov.l 0x0606726C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06067258u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06067258u) return; }  // 06067254 jsr @r0 ; mov #1,r4
    c.r[2] = c.r[0]; goto L_060673E8;  // 06067258 bra 0x060673E8 ; mov r0,r2
L_0606727C:
    c.r[1] = ld32(0x06067414u);  // 0606727C mov.l 0x06067414,r1
    c.r[8] = c.r[11];  // 0606727E mov r11,r8
    c.r[8] <<= 2;  // 06067280 shll2 r8
    c.r[8] <<= 2;  // 06067282 shll2 r8
    c.r[2] = ld32(c.r[1]);  // 06067284 mov.l @r1,r2
    c.r[13] = 0xFu;  // 06067286 mov #15,r13
    c.r[8] += c.r[2];  // 06067288 add r2,r8
    c.r[1] = c.r[8];  // 0606728A mov r8,r1
    c.r[1] += 4;  // 0606728C add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606728E mov.b @r1,r1
    c.r[0] = 0x3u;  // 06067290 mov #3,r0
    c.r[3] = c.r[1];  // 06067292 mov r1,r3
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 06067294 shlr r3
    c.r[3] &= c.r[13];  // 06067296 and r13,r3
    c.r[10] <<= 2;  // 06067298 shll2 r10
    c.r[10] <<= 2;  // 0606729A shll2 r10
    c.r[10] += c.r[2];  // 0606729C add r2,r10
    c.r[10] += 3;  // 0606729E add #3,r10
    c.r[4] = c.r[3];  // 060672A0 mov r3,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 060672A2 mov.b @r10,r1
    c.r[13] = ld32(0x06067418u);  // 060672A4 mov.l 0x06067418,r13
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060672A6 shlr r1
    c.r[1] &= c.r[0];  // 060672A8 and r0,r1
    { const uint32_t x = c.r[13]; c.pr = 0x060672AEu; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060672AEu) return; }  // 060672AA jsr @r13 ; mov r1,r5
    c.r[1] = c.r[0];  // 060672AE mov r0,r1
    c.r[0] = 0x1u;  // 060672B0 mov #1,r0
    c.r[1] &= c.r[0];  // 060672B2 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060672B4 tst r1,r1
    { const bool k = c.t; c.r[1] = c.r[8]; if (k) { goto L_060673B4; } }  // 060672B6 bt/s 0x060673B4 ; mov r8,r1
    c.r[1] += 7;  // 060672BA add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060672BC mov.b @r1,r1
    c.r[0] = c.r[1];  // 060672BE mov r1,r0
    c.r[0] >>= 2;  // 060672C0 shlr2 r0
    c.r[0] >>= 2;  // 060672C2 shlr2 r0
    c.r[0] >>= 2;  // 060672C4 shlr2 r0
    c.r[0] &= 0x1u;  // 060672C6 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060672C8 tst r0,r0
    { const bool k = !c.t; c.r[8] += 9; if (k) { goto L_060673B4; } }  // 060672CA bf/s 0x060673B4 ; add #9,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 060672CE mov.b @r8,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06067408u);  // 060672D0 mov.w 0x06067408,r2
    c.r[1] = c.r[1] & 0xFFu;  // 060672D2 extu.b r1,r1
    c.t = c.r[1] == c.r[2]; goto L_060673B2;  // 060672D4 bra 0x060673B2 ; cmp/eq r2,r1
L_060672D8:
    c.r[1] = ld32(0x06067414u);  // 060672D8 mov.l 0x06067414,r1
    c.r[2] = ld32(c.r[1]);  // 060672DA mov.l @r1,r2
    c.r[3] = c.r[10];  // 060672DC mov r10,r3
    c.r[1] = c.r[11];  // 060672DE mov r11,r1
    c.r[1] <<= 2;  // 060672E0 shll2 r1
    c.r[1] <<= 2;  // 060672E2 shll2 r1
    c.r[1] += c.r[2];  // 060672E4 add r2,r1
    c.r[1] += 3;  // 060672E6 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060672E8 mov.b @r1,r1
    c.r[13] = 0x3u;  // 060672EA mov #3,r13
    c.r[7] = c.r[1];  // 060672EC mov r1,r7
    c.t = c.r[7] & 1; c.r[7] >>= 1;  // 060672EE shlr r7
    c.r[3] <<= 2;  // 060672F0 shll2 r3
    c.r[3] <<= 2;  // 060672F2 shll2 r3
    c.r[3] += c.r[2];  // 060672F4 add r2,r3
    c.r[1] = c.r[3];  // 060672F6 mov r3,r1
    c.r[1] += 3;  // 060672F8 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060672FA mov.b @r1,r1
    c.r[7] &= c.r[13];  // 060672FC and r13,r7
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060672FE shlr r1
    c.r[1] &= c.r[13];  // 06067300 and r13,r1
    c.t = c.r[7] == c.r[1];  // 06067302 cmp/eq r1,r7
    { const bool k = !c.t; c.r[12] = 0x0u; if (k) { goto L_06067394; } }  // 06067304 bf/s 0x06067394 ; mov #0,r12
    c.r[3] += 2;  // 06067308 add #2,r3
    c.r[1] = ld32(0x0606741Cu);  // 0606730A mov.l 0x0606741C,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606740Au);  // 0606730C mov.w 0x0606740A,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0606730E mov.b @r3,r2
    c.r[0] += c.r[14];  // 06067310 add r14,r0
    c.r[3] = ld32(c.r[1]);  // 06067312 mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06067314 extu.b r2,r2
    c.r[1] = 0x1Eu;  // 06067316 mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 06067318 mul.l r1,r2
    c.r[8] = ld32(0x06067420u);  // 0606731A mov.l 0x06067420,r8
    c.r[13] = (uint32_t)(int16_t)ld16(0x0606740Au);  // 0606731C mov.w 0x0606740A,r13
    c.r[1] = c.macl;  // 0606731E sts macl,r1
    c.r[1] += c.r[3];  // 06067320 add r3,r1
    c.r[1] += 15;  // 06067322 add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06067324 mov.b @r1,r1
    c.r[13] += c.r[14];  // 06067326 add r14,r13
    c.r[1] = c.r[1] & 0xFFu;  // 06067328 extu.b r1,r1
    st32(c.r[0], c.r[1]);  // 0606732A mov.l r1,@r0
    c.r[4] = ld32(c.r[13]);  // 0606732C mov.l @r13,r4
    { const uint32_t x = c.r[8]; c.pr = 0x06067332u; c.r[5] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06067332u) return; }  // 0606732E jsr @r8 ; mov r11,r5
    c.r[1] = c.r[0];  // 06067332 mov r0,r1
    c.r[12] = c.r[1] & 0xFFu;  // 06067334 extu.b r1,r12
    c.r[10] = 0x0u;  // 06067336 mov #0,r10
    c.r[9] = 0x0u;  // 06067338 mov #0,r9
L_0606733A:
    c.r[1] = ld32(0x06067414u);  // 0606733A mov.l 0x06067414,r1
    c.r[3] = c.r[9];  // 0606733C mov r9,r3
    c.r[0] = ld32(c.r[1]);  // 0606733E mov.l @r1,r0
    c.r[2] = (uint32_t)(int16_t)ld16(0x06067408u);  // 06067340 mov.w 0x06067408,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 06067342 mov.b @(r0,r9),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06067344 extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 06067346 cmp/eq r2,r1
    { const bool k = c.t; c.r[3] += c.r[0]; if (k) { goto L_0606738A; } }  // 06067348 bt/s 0x0606738A ; add r0,r3
    c.r[1] = c.r[3];  // 0606734C mov r3,r1
    c.r[1] += 7;  // 0606734E add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06067350 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06067352 mov r1,r0
    c.r[0] >>= 2;  // 06067354 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06067356 shlr r0
    c.r[0] &= 0x1u;  // 06067358 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606735A tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[3]; if (k) { goto L_0606738A; } }  // 0606735C bf/s 0x0606738A ; mov r3,r1
    c.r[1] += 4;  // 06067360 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06067362 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06067364 mov r1,r0
    c.r[0] >>= 2;  // 06067366 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06067368 shlr r0
    c.r[0] >>= 2;  // 0606736A shlr2 r0
    c.r[0] &= 0x1u;  // 0606736C and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606736E tst r0,r0
    { const bool k = c.t; c.r[3] += 6; if (k) { goto L_0606738A; } }  // 06067370 bt/s 0x0606738A ; add #6,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06067374 mov.b @r3,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06067376 extu.b r1,r1
    c.t = c.r[1] == c.r[11];  // 06067378 cmp/eq r11,r1
    if (!c.t) { goto L_0606738A; }  // 0606737A bf 0x0606738A
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606740Au);  // 0606737C mov.w 0x0606740A,r0
    c.r[4] = ld32(c.r[0] + c.r[14]);  // 0606737E mov.l @(r0,r14),r4
    { const uint32_t x = c.r[8]; c.pr = 0x06067384u; c.r[5] = c.r[10] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06067384u) return; }  // 06067380 jsr @r8 ; extu.b r10,r5
    c.r[1] = c.r[0];  // 06067384 mov r0,r1
    c.r[1] += c.r[12];  // 06067386 add r12,r1
    c.r[12] = c.r[1] & 0xFFu;  // 06067388 extu.b r1,r12
L_0606738A:
    c.r[10] += 1;  // 0606738A add #1,r10
    c.r[1] = 0x49u;  // 0606738C mov #73,r1
    c.t = (int32_t)c.r[10] > (int32_t)c.r[1];  // 0606738E cmp/gt r1,r10
    { const bool k = !c.t; c.r[9] += 16; if (k) { SH2_POLL(c); goto L_0606733A; } }  // 06067390 bf/s 0x0606733A ; add #16,r9
L_06067394:
    c.t = (c.r[12] & c.r[12]) == 0;  // 06067394 tst r12,r12
    if (!c.t) { goto L_060673F0; }  // 06067396 bf 0x060673F0
    goto L_060673B4;  // 06067398 bra 0x060673B4 ; nop
L_0606739C:
    c.r[1] = ld32(0x06067414u);  // 0606739C mov.l 0x06067414,r1
    c.r[1] = ld32(c.r[1]);  // 0606739E mov.l @r1,r1
    c.r[11] <<= 2;  // 060673A0 shll2 r11
    c.r[11] <<= 2;  // 060673A2 shll2 r11
    c.r[11] += c.r[1];  // 060673A4 add r1,r11
    c.r[11] += 7;  // 060673A6 add #7,r11
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[11]);  // 060673A8 mov.b @r11,r1
    c.r[0] = c.r[1];  // 060673AA mov r1,r0
    c.r[0] >>= 2;  // 060673AC shlr2 r0
    c.r[0] &= 0x1u;  // 060673AE and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060673B0 tst r0,r0
L_060673B2:
    if (c.t) { goto L_060673F0; }  // 060673B2 bt 0x060673F0
L_060673B4:
    c.r[13] = (uint32_t)(int16_t)ld16(0x0606740Cu);  // 060673B4 mov.w 0x0606740C,r13
    c.r[13] += c.r[14];  // 060673B6 add r14,r13
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606740Eu);  // 060673B8 mov.w 0x0606740E,r0
    c.r[6] = ld32(c.r[13]);  // 060673BA mov.l @r13,r6
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 060673BC mov.l @(r0,r14),r0
    c.r[6] <<= 2;  // 060673BE shll2 r6
    c.r[6] <<= 2;  // 060673C0 shll2 r6
    c.r[6] <<= 2;  // 060673C2 shll2 r6
    c.r[6] += c.r[0];  // 060673C4 add r0,r6
    c.t = (int32_t)c.r[6] >= 0;  // 060673C6 cmp/pz r6
    c.r[9] = ld32(0x06067424u);  // 060673C8 mov.l 0x06067424,r9
    { const bool k = c.t; c.r[5] = c.r[6]; if (k) { goto L_060673D0; } }  // 060673CA bt/s 0x060673D0 ; mov r6,r5
    c.r[5] += 7;  // 060673CE add #7,r5
L_060673D0:
    c.r[8] = c.r[5];  // 060673D0 mov r5,r8
    c.r[8] >>= 2;  // 060673D2 shlr2 r8
    c.t = c.r[8] & 1; c.r[8] >>= 1;  // 060673D4 shlr r8
    c.r[5] = c.r[8];  // 060673D6 mov r8,r5
    c.r[5] <<= 2;  // 060673D8 shll2 r5
    c.r[5] += c.r[5];  // 060673DA add r5,r5
    c.r[5] -= c.r[6];  // 060673DC sub r6,r5
L_060673DE:
    c.r[5] += 7;  // 060673DE add #7,r5
    c.r[13] = ld32(0x06067428u);  // 060673E0 mov.l 0x06067428,r13
    { const uint32_t x = c.r[13]; c.pr = 0x060673E6u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060673E6u) return; }  // 060673E2 jsr @r13 ; mov #1,r4
    c.r[2] = c.r[0];  // 060673E6 mov r0,r2
L_060673E8:
    c.r[0] = c.r[8];  // 060673E8 mov r8,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 060673EA mov.b @(r0,r9),r1
    c.r[2] |= c.r[1];  // 060673EC or r1,r2
    st8(c.r[0] + c.r[9], c.r[2]);  // 060673EE mov.b r2,@(r0,r9)
L_060673F0:
    c.r[3] = (uint32_t)(int16_t)ld16(0x06067410u);  // 060673F0 mov.w 0x06067410,r3
    c.r[14] += c.r[3];  // 060673F2 add r3,r14
    c.r[15] = c.r[14];  // 060673F4 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060673F6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060673F8 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060673FA mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060673FC mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060673FE mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06067400 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06067402 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06067404 rts ; mov.l @r15+,r8
}

void f_0606742C(SH2Context& c) {
    ran[1505] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0606742C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0606742E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06067430 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06067432 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06067434 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06067436 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06067438 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0606743A sts.l pr,@-r15
    c.r[15] -= 52;  // 0606743C add #-52,r15
    c.r[14] = c.r[15];  // 0606743E mov r15,r14
    c.r[5] = c.r[5] & 0xFFu;  // 06067440 extu.b r5,r5
    c.r[1] = ld32(0x06067584u);  // 06067442 mov.l 0x06067584,r1
    c.r[1] = ld32(c.r[1]);  // 06067444 mov.l @r1,r1
    c.r[5] <<= 2;  // 06067446 shll2 r5
    c.r[5] <<= 2;  // 06067448 shll2 r5
    c.r[5] += c.r[1];  // 0606744A add r1,r5
    c.r[5] += 2;  // 0606744C add #2,r5
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[5]);  // 0606744E mov.b @r5,r2
    c.r[1] = ld32(0x06067588u);  // 06067450 mov.l 0x06067588,r1
    c.r[3] = ld32(c.r[1]);  // 06067452 mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06067454 extu.b r2,r2
    c.r[1] = 0x1Eu;  // 06067456 mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 06067458 mul.l r1,r2
    c.r[12] = c.r[4] & 0xFFu;  // 0606745A extu.b r4,r12
    c.r[11] = 0x0u;  // 0606745C mov #0,r11
    c.r[1] = c.macl;  // 0606745E sts macl,r1
    c.r[1] += c.r[3];  // 06067460 add r3,r1
    c.r[1] += 15;  // 06067462 add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06067464 mov.b @r1,r1
    c.r[4] = c.r[14];  // 06067466 mov r14,r4
    c.r[10] = c.r[1] & 0xFFu;  // 06067468 extu.b r1,r10
    c.r[1] = ld32(0x0606758Cu);  // 0606746A mov.l 0x0606758C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06067470u; c.r[5] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06067470u) return; }  // 0606746C jsr @r1 ; mov r10,r5
    c.r[9] = 0x0u;  // 06067470 mov #0,r9
    c.r[13] = c.r[12];  // 06067472 mov r12,r13
    c.r[13] += c.r[13];  // 06067474 add r13,r13
    c.r[13] += c.r[12];  // 06067476 add r12,r13
    c.r[13] <<= 2;  // 06067478 shll2 r13
    c.r[1] = c.r[14];  // 0606747A mov r14,r1
L_0606747C:
    c.r[1] += 24;  // 0606747C add #24,r1
    c.r[0] = c.r[1];  // 0606747E mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 06067480 mov.b @(r0,r9),r1
    c.r[2] = c.r[1] & 0xFFu;  // 06067482 extu.b r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06067484 tst r2,r2
    if (c.t) { goto L_060674B6; }  // 06067486 bt 0x060674B6
    c.r[1] = (uint32_t)(int16_t)ld16(0x06067582u);  // 06067488 mov.w 0x06067582,r1
    c.t = c.r[2] == c.r[1];  // 0606748A cmp/eq r1,r2
    { const bool k = c.t; c.r[0] = c.r[2]; if (k) { goto L_060674B6; } }  // 0606748C bt/s 0x060674B6 ; mov r2,r0
    c.t = c.r[0] == 0x1Cu;  // 06067490 cmp/eq #28,r0
    { const bool k = c.t; c.r[6] = 0x1u; if (k) { goto L_060674B6; } }  // 06067492 bt/s 0x060674B6 ; mov #1,r6
    c.r[1] = ld32(0x06067590u);  // 06067496 mov.l 0x06067590,r1
    c.r[0] = ld32(0x06067594u);  // 06067498 mov.l 0x06067594,r0
    c.r[5] = c.r[14];  // 0606749A mov r14,r5
    c.r[8] = ld32(c.r[1]);  // 0606749C mov.l @r1,r8
    c.r[4] = c.r[2];  // 0606749E mov r2,r4
    c.r[8] += c.r[13];  // 060674A0 add r13,r8
    { const uint32_t x = c.r[0]; c.pr = 0x060674A6u; c.r[8] += 10; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060674A6u) return; }  // 060674A2 jsr @r0 ; add #10,r8
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[8]);  // 060674A6 mov.w @r8,r1
    c.r[2] = c.r[0] & 0xFFu;  // 060674A8 extu.b r0,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 060674AA extu.w r1,r1
    c.t = c.r[1] >= c.r[2];  // 060674AC cmp/hs r2,r1
    { const bool k = !c.t; c.r[9] += 1; if (k) { goto L_060674B8; } }  // 060674AE bf/s 0x060674B8 ; add #1,r9
    c.r[11] = 0x1u; goto L_060674C0;  // 060674B2 bra 0x060674C0 ; mov #1,r11
L_060674B6:
    c.r[9] += 1;  // 060674B6 add #1,r9
L_060674B8:
    c.r[1] = 0x5u;  // 060674B8 mov #5,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 060674BA cmp/gt r1,r9
    { const bool k = !c.t; c.r[1] = c.r[14]; if (k) { SH2_POLL(c); goto L_0606747C; } }  // 060674BC bf/s 0x0606747C ; mov r14,r1
L_060674C0:
    c.r[7] = ld32(0x06067590u);  // 060674C0 mov.l 0x06067590,r7
    c.r[3] = c.r[10];  // 060674C2 mov r10,r3
    c.r[3] += c.r[3];  // 060674C4 add r3,r3
    c.r[2] = c.r[3];  // 060674C6 mov r3,r2
    c.r[2] += c.r[10];  // 060674C8 add r10,r2
    c.r[1] = ld32(c.r[7]);  // 060674CA mov.l @r7,r1
    c.r[2] <<= 2;  // 060674CC shll2 r2
    c.r[2] += c.r[1];  // 060674CE add r1,r2
    c.r[2] += 8;  // 060674D0 add #8,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060674D2 mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060674D4 extu.b r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06067582u);  // 060674D6 mov.w 0x06067582,r2
    c.t = c.r[1] == c.r[2];  // 060674D8 cmp/eq r2,r1
    { const bool k = c.t; c.r[13] = c.r[11]; if (k) { goto L_0606756A; } }  // 060674DA bt/s 0x0606756A ; mov r11,r13
    c.r[0] = c.r[12];  // 060674DE mov r12,r0
    c.r[0] += c.r[0];  // 060674E0 add r0,r0
    c.r[0] += c.r[12];  // 060674E2 add r12,r0
    st32(c.r[14] + 48, c.r[0]);  // 060674E4 mov.l r0,@(48,r14)
L_060674E6:
    c.r[3] += c.r[10];  // 060674E6 add r10,r3
    c.r[3] <<= 2;  // 060674E8 shll2 r3
    c.r[1] = ld32(c.r[7]);  // 060674EA mov.l @r7,r1
    c.r[11] = 0x0u;  // 060674EC mov #0,r11
    c.r[3] += c.r[1];  // 060674EE add r1,r3
    c.r[3] += 8;  // 060674F0 add #8,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060674F2 mov.b @r3,r1
    c.r[4] = c.r[14];  // 060674F4 mov r14,r4
    c.r[10] = c.r[1] & 0xFFu;  // 060674F6 extu.b r1,r10
    c.r[1] = ld32(0x0606758Cu);  // 060674F8 mov.l 0x0606758C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060674FEu; c.r[5] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060674FEu) return; }  // 060674FA jsr @r1 ; mov r10,r5
    c.r[12] = ld32(c.r[14] + 48);  // 060674FE mov.l @(48,r14),r12
    c.r[9] = 0x0u;  // 06067500 mov #0,r9
    c.r[12] <<= 2;  // 06067502 shll2 r12
    c.r[1] = c.r[14];  // 06067504 mov r14,r1
L_06067506:
    c.r[1] += 24;  // 06067506 add #24,r1
    c.r[0] = c.r[1];  // 06067508 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 0606750A mov.b @(r0,r9),r1
    c.r[2] = c.r[1] & 0xFFu;  // 0606750C extu.b r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0606750E tst r2,r2
    if (c.t) { goto L_06067540; }  // 06067510 bt 0x06067540
    c.r[1] = (uint32_t)(int16_t)ld16(0x06067582u);  // 06067512 mov.w 0x06067582,r1
    c.t = c.r[2] == c.r[1];  // 06067514 cmp/eq r1,r2
    { const bool k = c.t; c.r[0] = c.r[2]; if (k) { goto L_06067540; } }  // 06067516 bt/s 0x06067540 ; mov r2,r0
    c.t = c.r[0] == 0x1Cu;  // 0606751A cmp/eq #28,r0
    { const bool k = c.t; c.r[6] = 0x1u; if (k) { goto L_06067540; } }  // 0606751C bt/s 0x06067540 ; mov #1,r6
    c.r[1] = ld32(0x06067590u);  // 06067520 mov.l 0x06067590,r1
    c.r[0] = ld32(0x06067594u);  // 06067522 mov.l 0x06067594,r0
    c.r[5] = c.r[14];  // 06067524 mov r14,r5
    c.r[8] = ld32(c.r[1]);  // 06067526 mov.l @r1,r8
    c.r[4] = c.r[2];  // 06067528 mov r2,r4
    c.r[8] += c.r[12];  // 0606752A add r12,r8
    { const uint32_t x = c.r[0]; c.pr = 0x06067530u; c.r[8] += 10; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06067530u) return; }  // 0606752C jsr @r0 ; add #10,r8
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06067530 mov.w @r8,r1
    c.r[2] = c.r[0] & 0xFFu;  // 06067532 extu.b r0,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 06067534 extu.w r1,r1
    c.t = c.r[1] >= c.r[2];  // 06067536 cmp/hs r2,r1
    { const bool k = !c.t; c.r[9] += 1; if (k) { goto L_06067542; } }  // 06067538 bf/s 0x06067542 ; add #1,r9
    c.r[11] = 0x1u; goto L_0606754A;  // 0606753C bra 0x0606754A ; mov #1,r11
L_06067540:
    c.r[9] += 1;  // 06067540 add #1,r9
L_06067542:
    c.r[1] = 0x5u;  // 06067542 mov #5,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 06067544 cmp/gt r1,r9
    { const bool k = !c.t; c.r[1] = c.r[14]; if (k) { SH2_POLL(c); goto L_06067506; } }  // 06067546 bf/s 0x06067506 ; mov r14,r1
L_0606754A:
    c.r[11] += c.r[13];  // 0606754A add r13,r11
    c.r[7] = ld32(0x06067590u);  // 0606754C mov.l 0x06067590,r7
    c.r[3] = c.r[10];  // 0606754E mov r10,r3
    c.r[3] += c.r[3];  // 06067550 add r3,r3
    c.r[2] = c.r[3];  // 06067552 mov r3,r2
    c.r[2] += c.r[10];  // 06067554 add r10,r2
    c.r[1] = ld32(c.r[7]);  // 06067556 mov.l @r7,r1
    c.r[2] <<= 2;  // 06067558 shll2 r2
    c.r[2] += c.r[1];  // 0606755A add r1,r2
    c.r[2] += 8;  // 0606755C add #8,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606755E mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06067560 extu.b r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06067582u);  // 06067562 mov.w 0x06067582,r2
    c.t = c.r[1] == c.r[2];  // 06067564 cmp/eq r2,r1
    { const bool k = !c.t; c.r[13] = c.r[11] & 0xFFu; if (k) { SH2_POLL(c); goto L_060674E6; } }  // 06067566 bf/s 0x060674E6 ; extu.b r11,r13
L_0606756A:
    c.r[14] += 52;  // 0606756A add #52,r14
    c.r[15] = c.r[14];  // 0606756C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0606756E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06067570 mov.l @r15+,r14
    c.r[0] = c.r[13];  // 06067572 mov r13,r0
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06067574 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06067576 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06067578 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0606757A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0606757C mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0606757E rts ; mov.l @r15+,r8
}

void f_06067598(SH2Context& c) {
    ran[1506] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06067598 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0606759A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0606759C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0606759E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060675A0 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060675A2 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060675A4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060675A6 sts.l pr,@-r15
    c.r[15] -= 8;  // 060675A8 add #-8,r15
    c.r[14] = c.r[15];  // 060675AA mov r15,r14
    c.r[12] = c.r[4] & 0xFFu;  // 060675AC extu.b r4,r12
    c.r[5] = c.r[5] & 0xFFu;  // 060675AE extu.b r5,r5
    st32(c.r[14], c.r[5]);  // 060675B0 mov.l r5,@r14
    c.r[13] = c.r[6] & 0xFFu;  // 060675B2 extu.b r6,r13
    c.r[2] = c.r[13];  // 060675B4 mov r13,r2
    c.r[1] = ld32(c.r[14] + 40);  // 060675B6 mov.l @(40,r14),r1
    c.r[2] <<= 2;  // 060675B8 shll2 r2
    c.r[2] <<= 2;  // 060675BA shll2 r2
    c.r[2] <<= 2;  // 060675BC shll2 r2
    c.r[4] = c.r[1] & 0xFFu;  // 060675BE extu.b r1,r4
    c.r[1] = ld32(0x060676E8u);  // 060675C0 mov.l 0x060676E8,r1
    c.r[1] = ld32(c.r[1]);  // 060675C2 mov.l @r1,r1
    c.r[0] = c.r[5];  // 060675C4 mov r5,r0
    c.r[2] += c.r[1];  // 060675C6 add r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 060675C8 mov.b @(r0,r2),r1
    c.r[10] = c.r[1] & 0xFFu;  // 060675CA extu.b r1,r10
    c.r[1] = ld32(0x060676ECu);  // 060675CC mov.l 0x060676EC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060675CE mov.b @r1,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x060676E2u);  // 060675D0 mov.w 0x060676E2,r3
    c.r[8] = c.r[1] & 0xFFu;  // 060675D2 extu.b r1,r8
    c.r[1] = ld32(0x060676F0u);  // 060675D4 mov.l 0x060676F0,r1
    c.macl = c.r[8] * c.r[3];  // 060675D6 mul.l r3,r8
    c.r[2] = ld32(c.r[1]);  // 060675D8 mov.l @r1,r2
    c.r[11] = (uint32_t)(int16_t)ld16(0x060676E4u);  // 060675DA mov.w 0x060676E4,r11
    c.r[1] = c.macl;  // 060675DC sts macl,r1
    c.r[1] += c.r[2];  // 060675DE add r2,r1
    c.r[0] = c.r[1];  // 060675E0 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 060675E2 mov.b @(r0,r11),r1
    c.r[9] = 0x0u;  // 060675E4 mov #0,r9
    c.r[1] = c.r[1] & 0xFFu;  // 060675E6 extu.b r1,r1
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[1];  // 060675E8 cmp/ge r1,r9
    if (c.t) { goto L_06067614; }  // 060675EA bt 0x06067614
    c.r[6] = c.r[2];  // 060675EC mov r2,r6
    c.r[5] = c.r[3];  // 060675EE mov r3,r5
    c.r[3] = 0x0u;  // 060675F0 mov #0,r3
    c.macl = c.r[8] * c.r[5];  // 060675F2 mul.l r5,r8
L_060675F4:
    c.r[2] = c.macl;  // 060675F4 sts macl,r2
    c.r[2] += c.r[6];  // 060675F6 add r6,r2
    c.r[1] = c.r[2];  // 060675F8 mov r2,r1
    c.r[1] += c.r[3];  // 060675FA add r3,r1
    c.r[1] += 4;  // 060675FC add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060675FE mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06067600 extu.b r1,r1
    c.t = c.r[1] == c.r[10];  // 06067602 cmp/eq r10,r1
    { const bool k = c.t; c.r[0] = c.r[2]; if (k) { goto L_06067614; } }  // 06067604 bt/s 0x06067614 ; mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 06067608 mov.b @(r0,r11),r1
    c.r[9] += 1;  // 0606760A add #1,r9
    c.r[1] = c.r[1] & 0xFFu;  // 0606760C extu.b r1,r1
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[1];  // 0606760E cmp/ge r1,r9
    { const bool k = !c.t; c.r[3] += 8; if (k) { SH2_POLL(c); goto L_060675F4; } }  // 06067610 bf/s 0x060675F4 ; add #8,r3
L_06067614:
    c.r[1] = ld32(0x060676F0u);  // 06067614 mov.l 0x060676F0,r1
    c.r[3] = ld32(c.r[1]);  // 06067616 mov.l @r1,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x060676E2u);  // 06067618 mov.w 0x060676E2,r1
    c.macl = c.r[8] * c.r[1];  // 0606761A mul.l r1,r8
    c.r[2] = c.macl;  // 0606761C sts macl,r2
    c.r[2] += c.r[3];  // 0606761E add r3,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x060676E4u);  // 06067620 mov.w 0x060676E4,r1
    c.r[0] = c.r[2];  // 06067622 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06067624 mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06067626 extu.b r1,r1
    c.t = c.r[9] == c.r[1];  // 06067628 cmp/eq r1,r9
    { const bool k = !c.t; c.r[9] = 0x0u; if (k) { goto L_06067630; } }  // 0606762A bf/s 0x06067630 ; mov #0,r9
    c.r[9] = 0x1u;  // 0606762E mov #1,r9
L_06067630:
    c.r[11] = ld32(0x060676F4u);  // 06067630 mov.l 0x060676F4,r11
    c.r[5] = ld32(c.r[11]);  // 06067632 mov.l @r11,r5
    c.r[0] = c.r[4];  // 06067634 mov r4,r0
    c.t = c.r[0] == 0x2u;  // 06067636 cmp/eq #2,r0
    { const bool k = !c.t; c.r[1] = 0x40u; if (k) { goto L_0606763E; } }  // 06067638 bf/s 0x0606763E ; mov #64,r1
    c.r[1] = c.r[4];  // 0606763C mov r4,r1
L_0606763E:
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0606763E mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 06067640 mov.l r7,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06067642 mov.l r13,@-r15
    c.r[6] = c.r[8];  // 06067644 mov r8,r6
    c.r[4] = c.r[12];  // 06067646 mov r12,r4
    c.r[0] = ld32(0x060676F8u);  // 06067648 mov.l 0x060676F8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0606764Eu; c.r[7] = ld32(c.r[14]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606764Eu) return; }  // 0606764A jsr @r0 ; mov.l @r14,r7
    c.r[1] = c.r[0];  // 0606764E mov r0,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06067650 extu.b r1,r1
    st32(c.r[14] + 4, c.r[1]);  // 06067652 mov.l r1,@(4,r14)
    c.r[1] = c.r[8];  // 06067654 mov r8,r1
    c.r[1] <<= 2;  // 06067656 shll2 r1
    c.r[1] += c.r[8];  // 06067658 add r8,r1
    c.r[2] = ld32(c.r[11]);  // 0606765A mov.l @r11,r2
    c.r[1] <<= 2;  // 0606765C shll2 r1
    c.r[2] += c.r[1];  // 0606765E add r1,r2
    c.r[2] += 50;  // 06067660 add #50,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06067662 mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06067664 extu.b r1,r1
    c.r[1] >>= 2;  // 06067666 shlr2 r1
    c.r[1] >>= 2;  // 06067668 shlr2 r1
    c.r[1] >>= 2;  // 0606766A shlr2 r1
    c.r[0] = c.r[1];  // 0606766C mov r1,r0
    c.t = c.r[0] == 0x2u;  // 0606766E cmp/eq #2,r0
    { const bool k = c.t; c.r[15] += 12; if (k) { goto L_0606767E; } }  // 06067670 bt/s 0x0606767E ; add #12,r15
    c.t = c.r[0] == 0x3u;  // 06067674 cmp/eq #3,r0
    { const bool k = c.t; c.r[0] = ld32(c.r[14] + 4); if (k) { goto L_06067708; } }  // 06067676 bt/s 0x06067708 ; mov.l @(4,r14),r0
    c.t = (c.r[0] & c.r[0]) == 0; goto L_06067830;  // 0606767A bra 0x06067830 ; tst r0,r0
L_0606767E:
    c.r[0] = ld32(c.r[14] + 4);  // 0606767E mov.l @(4,r14),r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06067680 tst r0,r0
    if (c.t) { goto L_0606768E; }  // 06067682 bt 0x0606768E
    c.r[1] = (uint32_t)(int16_t)ld16(0x060676E6u);  // 06067684 mov.w 0x060676E6,r1
    c.t = c.r[10] == c.r[1];  // 06067686 cmp/eq r1,r10
    { const bool k = c.t; c.t = (c.r[9] & c.r[9]) == 0; if (k) { goto L_060676D6; } }  // 06067688 bt/s 0x060676D6 ; tst r9,r9
    if (c.t) { goto L_060676D6; }  // 0606768C bt 0x060676D6
L_0606768E:
    c.r[1] = ld32(0x060676FCu);  // 0606768E mov.l 0x060676FC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06067690 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06067692 mov r1,r0
    c.r[0] >>= 2;  // 06067694 shlr2 r0
    c.r[0] &= 0x1u;  // 06067696 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06067698 tst r0,r0
    { const bool k = c.t; c.t = (c.r[9] & c.r[9]) == 0; if (k) { goto L_060676D6; } }  // 0606769A bt/s 0x060676D6 ; tst r9,r9
    c.r[2] = c.r[13];  // 0606769E mov r13,r2
    c.r[0] = ld32(c.r[14]);  // 060676A0 mov.l @r14,r0
    c.r[2] <<= 2;  // 060676A2 shll2 r2
    c.r[2] <<= 2;  // 060676A4 shll2 r2
    c.r[2] <<= 2;  // 060676A6 shll2 r2
    c.r[2] += c.r[0];  // 060676A8 add r0,r2
    c.t = (int32_t)c.r[2] >= 0;  // 060676AA cmp/pz r2
    c.r[11] = ld32(0x06067700u);  // 060676AC mov.l 0x06067700,r11
    { const bool k = c.t; c.r[5] = c.r[2]; if (k) { goto L_060676B4; } }  // 060676AE bt/s 0x060676B4 ; mov r2,r5
    c.r[5] += 7;  // 060676B2 add #7,r5
L_060676B4:
    c.r[8] = c.r[5];  // 060676B4 mov r5,r8
    c.r[8] >>= 2;  // 060676B6 shlr2 r8
    c.t = c.r[8] & 1; c.r[8] >>= 1;  // 060676B8 shlr r8
    c.r[5] = c.r[8];  // 060676BA mov r8,r5
    c.r[5] <<= 2;  // 060676BC shll2 r5
    c.r[5] += c.r[5];  // 060676BE add r5,r5
    c.r[5] -= c.r[2];  // 060676C0 sub r2,r5
    c.r[5] += 7;  // 060676C2 add #7,r5
    c.r[0] = ld32(0x06067704u);  // 060676C4 mov.l 0x06067704,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060676CAu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060676CAu) return; }  // 060676C6 jsr @r0 ; mov #1,r4
    c.r[2] = c.r[0];  // 060676CA mov r0,r2
    c.r[0] = c.r[8];  // 060676CC mov r8,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 060676CE mov.b @(r0,r11),r1
    c.r[2] |= c.r[1];  // 060676D0 or r1,r2
    st8(c.r[0] + c.r[11], c.r[2]);  // 060676D2 mov.b r2,@(r0,r11)
    c.t = (c.r[9] & c.r[9]) == 0;  // 060676D4 tst r9,r9
L_060676D6:
    if (c.t) { goto L_060676DC; }  // 060676D6 bt 0x060676DC
    goto L_06067906;  // 060676D8 bra 0x06067906 ; nop
L_060676DC:
    c.r[0] = ld32(c.r[14] + 4);  // 060676DC mov.l @(4,r14),r0
    c.t = (c.r[0] & c.r[0]) == 0; goto L_06067904;  // 060676DE bra 0x06067904 ; tst r0,r0
L_06067708:
    c.t = (c.r[0] & c.r[0]) == 0;  // 06067708 tst r0,r0
    if (c.t) { goto L_06067752; }  // 0606770A bt 0x06067752
    c.r[1] = (uint32_t)(int16_t)ld16(0x06067816u);  // 0606770C mov.w 0x06067816,r1
    c.t = c.r[10] == c.r[1];  // 0606770E cmp/eq r1,r10
    if (c.t) { goto L_0606779E; }  // 06067710 bt 0x0606779E
    c.t = (c.r[9] & c.r[9]) == 0;  // 06067712 tst r9,r9
    { const bool k = !c.t; c.r[0] = 0xFu; if (k) { goto L_06067752; } }  // 06067714 bf/s 0x06067752 ; mov #15,r0
    c.r[1] = ld32(0x06067818u);  // 06067718 mov.l 0x06067818,r1
    c.r[2] = ld32(c.r[1]);  // 0606771A mov.l @r1,r2
    c.r[1] = c.r[12];  // 0606771C mov r12,r1
    c.r[1] <<= 2;  // 0606771E shll2 r1
    c.r[1] <<= 2;  // 06067720 shll2 r1
    c.r[1] += c.r[2];  // 06067722 add r2,r1
    c.r[1] += 4;  // 06067724 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06067726 mov.b @r1,r1
    c.r[3] = c.r[1];  // 06067728 mov r1,r3
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 0606772A shlr r3
    c.r[3] &= c.r[0];  // 0606772C and r0,r3
    c.r[1] = c.r[10];  // 0606772E mov r10,r1
    c.r[1] <<= 2;  // 06067730 shll2 r1
    c.r[1] <<= 2;  // 06067732 shll2 r1
    c.r[1] += c.r[2];  // 06067734 add r2,r1
    c.r[1] += 3;  // 06067736 add #3,r1
    c.r[0] = 0x3u;  // 06067738 mov #3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606773A mov.b @r1,r1
    c.r[4] = c.r[3];  // 0606773C mov r3,r4
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0606773E shlr r1
    c.r[1] &= c.r[0];  // 06067740 and r0,r1
    c.r[0] = ld32(0x0606781Cu);  // 06067742 mov.l 0x0606781C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06067748u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06067748u) return; }  // 06067744 jsr @r0 ; mov r1,r5
    c.r[1] = c.r[0];  // 06067748 mov r0,r1
    c.r[0] = 0x1u;  // 0606774A mov #1,r0
    c.r[1] &= c.r[0];  // 0606774C and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606774E tst r1,r1
    if (c.t) { goto L_0606779A; }  // 06067750 bt 0x0606779A
L_06067752:
    c.r[1] = ld32(0x06067820u);  // 06067752 mov.l 0x06067820,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06067754 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06067756 mov r1,r0
    c.r[0] >>= 2;  // 06067758 shlr2 r0
    c.r[0] &= 0x1u;  // 0606775A and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606775C tst r0,r0
    { const bool k = c.t; c.t = (c.r[9] & c.r[9]) == 0; if (k) { goto L_060677D4; } }  // 0606775E bt/s 0x060677D4 ; tst r9,r9
    c.r[2] = c.r[13];  // 06067762 mov r13,r2
    c.r[0] = ld32(c.r[14]);  // 06067764 mov.l @r14,r0
    c.r[2] <<= 2;  // 06067766 shll2 r2
    c.r[2] <<= 2;  // 06067768 shll2 r2
    c.r[2] <<= 2;  // 0606776A shll2 r2
    c.r[2] += c.r[0];  // 0606776C add r0,r2
    c.t = (int32_t)c.r[2] >= 0;  // 0606776E cmp/pz r2
    c.r[11] = ld32(0x06067824u);  // 06067770 mov.l 0x06067824,r11
    { const bool k = c.t; c.r[5] = c.r[2]; if (k) { goto L_06067778; } }  // 06067772 bt/s 0x06067778 ; mov r2,r5
    c.r[5] += 7;  // 06067776 add #7,r5
L_06067778:
    c.r[8] = c.r[5];  // 06067778 mov r5,r8
    c.r[8] >>= 2;  // 0606777A shlr2 r8
    c.t = c.r[8] & 1; c.r[8] >>= 1;  // 0606777C shlr r8
    c.r[5] = c.r[8];  // 0606777E mov r8,r5
    c.r[5] <<= 2;  // 06067780 shll2 r5
    c.r[5] += c.r[5];  // 06067782 add r5,r5
    c.r[5] -= c.r[2];  // 06067784 sub r2,r5
    c.r[5] += 7;  // 06067786 add #7,r5
    c.r[0] = ld32(0x06067828u);  // 06067788 mov.l 0x06067828,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0606778Eu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606778Eu) return; }  // 0606778A jsr @r0 ; mov #1,r4
    c.r[2] = c.r[0];  // 0606778E mov r0,r2
    c.r[0] = c.r[8];  // 06067790 mov r8,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 06067792 mov.b @(r0,r11),r1
    c.r[2] |= c.r[1];  // 06067794 or r1,r2
    st8(c.r[0] + c.r[11], c.r[2]); goto L_060677D2;  // 06067796 bra 0x060677D2 ; mov.b r2,@(r0,r11)
L_0606779A:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06067816u);  // 0606779A mov.w 0x06067816,r1
    c.t = c.r[10] == c.r[1];  // 0606779C cmp/eq r1,r10
L_0606779E:
    { const bool k = c.t; c.t = (c.r[9] & c.r[9]) == 0; if (k) { goto L_060677D4; } }  // 0606779E bt/s 0x060677D4 ; tst r9,r9
    c.r[1] = ld32(0x06067818u);  // 060677A2 mov.l 0x06067818,r1
    c.r[2] = c.r[10];  // 060677A4 mov r10,r2
    c.r[1] = ld32(c.r[1]);  // 060677A6 mov.l @r1,r1
    c.r[2] <<= 2;  // 060677A8 shll2 r2
    c.r[2] <<= 2;  // 060677AA shll2 r2
    c.r[2] += c.r[1];  // 060677AC add r1,r2
    c.r[2] += 7;  // 060677AE add #7,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060677B0 mov.b @r2,r1
    c.r[0] = c.r[1];  // 060677B2 mov r1,r0
    c.r[0] >>= 2;  // 060677B4 shlr2 r0
    c.r[0] >>= 2;  // 060677B6 shlr2 r0
    c.r[0] &= 0x1u;  // 060677B8 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060677BA tst r0,r0
    { const bool k = c.t; c.t = (c.r[9] & c.r[9]) == 0; if (k) { goto L_060677D4; } }  // 060677BC bt/s 0x060677D4 ; tst r9,r9
    c.r[1] = ld32(0x06067820u);  // 060677C0 mov.l 0x06067820,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060677C2 mov.b @r1,r1
    c.r[4] = c.r[10];  // 060677C4 mov r10,r4
    c.r[0] = c.r[1];  // 060677C6 mov r1,r0
    c.r[0] >>= 2;  // 060677C8 shlr2 r0
    c.r[0] &= 0x1u;  // 060677CA and #1,r0
    c.r[1] = ld32(0x0606782Cu);  // 060677CC mov.l 0x0606782C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060677D2u; c.r[5] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060677D2u) return; }  // 060677CE jsr @r1 ; mov r0,r5
L_060677D2:
    c.t = (c.r[9] & c.r[9]) == 0;  // 060677D2 tst r9,r9
L_060677D4:
    { const bool k = c.t; c.r[2] = c.r[12]; if (k) { goto L_060677DC; } }  // 060677D4 bt/s 0x060677DC ; mov r12,r2
    goto L_06067906;  // 060677D8 bra 0x06067906 ; nop
L_060677DC:
    c.r[1] = ld32(0x06067818u);  // 060677DC mov.l 0x06067818,r1
    c.r[2] <<= 2;  // 060677DE shll2 r2
    c.r[2] <<= 2;  // 060677E0 shll2 r2
    c.r[1] = ld32(c.r[1]);  // 060677E2 mov.l @r1,r1
    c.r[0] = 0xFu;  // 060677E4 mov #15,r0
    c.r[2] += c.r[1];  // 060677E6 add r1,r2
    c.r[1] = c.r[2];  // 060677E8 mov r2,r1
    c.r[1] += 4;  // 060677EA add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060677EC mov.b @r1,r1
    c.r[2] += 3;  // 060677EE add #3,r2
    c.r[3] = c.r[1];  // 060677F0 mov r1,r3
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 060677F2 shlr r3
    c.r[3] &= c.r[0];  // 060677F4 and r0,r3
    c.r[0] = 0x3u;  // 060677F6 mov #3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060677F8 mov.b @r2,r1
    c.r[4] = c.r[3];  // 060677FA mov r3,r4
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060677FC shlr r1
    c.r[1] &= c.r[0];  // 060677FE and r0,r1
    c.r[0] = ld32(0x0606781Cu);  // 06067800 mov.l 0x0606781C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06067806u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06067806u) return; }  // 06067802 jsr @r0 ; mov r1,r5
    c.r[1] = c.r[0];  // 06067806 mov r0,r1
    c.r[0] = 0x1u;  // 06067808 mov #1,r0
    c.r[1] &= c.r[0];  // 0606780A and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606780C tst r1,r1
    if (!c.t) { goto L_06067906; }  // 0606780E bf 0x06067906
    c.r[0] = ld32(c.r[14] + 4);  // 06067810 mov.l @(4,r14),r0
    c.t = (c.r[0] & c.r[0]) == 0; goto L_06067904;  // 06067812 bra 0x06067904 ; tst r0,r0
L_06067830:
    if (c.t) { goto L_0606787A; }  // 06067830 bt 0x0606787A
    c.r[1] = (uint32_t)(int16_t)ld16(0x06067956u);  // 06067832 mov.w 0x06067956,r1
    c.t = c.r[10] == c.r[1];  // 06067834 cmp/eq r1,r10
    { const bool k = c.t; c.t = (c.r[9] & c.r[9]) == 0; if (k) { goto L_060678C2; } }  // 06067836 bt/s 0x060678C2 ; tst r9,r9
    { const bool k = !c.t; c.r[0] = 0xFu; if (k) { goto L_0606787A; } }  // 0606783A bf/s 0x0606787A ; mov #15,r0
    c.r[1] = ld32(0x06067958u);  // 0606783E mov.l 0x06067958,r1
    c.r[2] = ld32(c.r[1]);  // 06067840 mov.l @r1,r2
    c.r[1] = c.r[12];  // 06067842 mov r12,r1
    c.r[1] <<= 2;  // 06067844 shll2 r1
    c.r[1] <<= 2;  // 06067846 shll2 r1
    c.r[1] += c.r[2];  // 06067848 add r2,r1
    c.r[1] += 4;  // 0606784A add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606784C mov.b @r1,r1
    c.r[3] = c.r[1];  // 0606784E mov r1,r3
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 06067850 shlr r3
    c.r[3] &= c.r[0];  // 06067852 and r0,r3
    c.r[1] = c.r[10];  // 06067854 mov r10,r1
    c.r[1] <<= 2;  // 06067856 shll2 r1
    c.r[1] <<= 2;  // 06067858 shll2 r1
    c.r[1] += c.r[2];  // 0606785A add r2,r1
    c.r[1] += 3;  // 0606785C add #3,r1
    c.r[0] = 0x3u;  // 0606785E mov #3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06067860 mov.b @r1,r1
    c.r[4] = c.r[3];  // 06067862 mov r3,r4
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06067864 shlr r1
    c.r[1] &= c.r[0];  // 06067866 and r0,r1
    c.r[0] = ld32(0x0606795Cu);  // 06067868 mov.l 0x0606795C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0606786Eu; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606786Eu) return; }  // 0606786A jsr @r0 ; mov r1,r5
    c.r[1] = c.r[0];  // 0606786E mov r0,r1
    c.r[0] = 0x1u;  // 06067870 mov #1,r0
    c.r[1] &= c.r[0];  // 06067872 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06067874 tst r1,r1
    { const bool k = !c.t; c.t = (c.r[9] & c.r[9]) == 0; if (k) { goto L_060678C2; } }  // 06067876 bf/s 0x060678C2 ; tst r9,r9
L_0606787A:
    c.r[1] = ld32(0x06067960u);  // 0606787A mov.l 0x06067960,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606787C mov.b @r1,r1
    c.r[0] = c.r[1];  // 0606787E mov r1,r0
    c.r[0] >>= 2;  // 06067880 shlr2 r0
    c.r[0] &= 0x1u;  // 06067882 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06067884 tst r0,r0
    { const bool k = c.t; c.t = (c.r[9] & c.r[9]) == 0; if (k) { goto L_060678C2; } }  // 06067886 bt/s 0x060678C2 ; tst r9,r9
    c.r[2] = c.r[13];  // 0606788A mov r13,r2
    c.r[0] = ld32(c.r[14]);  // 0606788C mov.l @r14,r0
    c.r[2] <<= 2;  // 0606788E shll2 r2
    c.r[2] <<= 2;  // 06067890 shll2 r2
    c.r[2] <<= 2;  // 06067892 shll2 r2
    c.r[2] += c.r[0];  // 06067894 add r0,r2
    c.t = (int32_t)c.r[2] >= 0;  // 06067896 cmp/pz r2
    c.r[11] = ld32(0x06067964u);  // 06067898 mov.l 0x06067964,r11
    { const bool k = c.t; c.r[5] = c.r[2]; if (k) { goto L_060678A0; } }  // 0606789A bt/s 0x060678A0 ; mov r2,r5
    c.r[5] += 7;  // 0606789E add #7,r5
L_060678A0:
    c.r[8] = c.r[5];  // 060678A0 mov r5,r8
    c.r[8] >>= 2;  // 060678A2 shlr2 r8
    c.t = c.r[8] & 1; c.r[8] >>= 1;  // 060678A4 shlr r8
    c.r[5] = c.r[8];  // 060678A6 mov r8,r5
    c.r[5] <<= 2;  // 060678A8 shll2 r5
    c.r[5] += c.r[5];  // 060678AA add r5,r5
    c.r[5] -= c.r[2];  // 060678AC sub r2,r5
    c.r[5] += 7;  // 060678AE add #7,r5
    c.r[0] = ld32(0x06067968u);  // 060678B0 mov.l 0x06067968,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060678B6u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060678B6u) return; }  // 060678B2 jsr @r0 ; mov #1,r4
    c.r[2] = c.r[0];  // 060678B6 mov r0,r2
    c.r[0] = c.r[8];  // 060678B8 mov r8,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 060678BA mov.b @(r0,r11),r1
    c.r[2] |= c.r[1];  // 060678BC or r1,r2
    st8(c.r[0] + c.r[11], c.r[2]);  // 060678BE mov.b r2,@(r0,r11)
    c.t = (c.r[9] & c.r[9]) == 0;  // 060678C0 tst r9,r9
L_060678C2:
    if (!c.t) { goto L_06067906; }  // 060678C2 bf 0x06067906
    c.r[0] = 0xFu;  // 060678C4 mov #15,r0
    c.r[1] = ld32(0x06067958u);  // 060678C6 mov.l 0x06067958,r1
    c.r[2] = ld32(c.r[1]);  // 060678C8 mov.l @r1,r2
    c.r[1] = c.r[12];  // 060678CA mov r12,r1
    c.r[1] <<= 2;  // 060678CC shll2 r1
    c.r[1] <<= 2;  // 060678CE shll2 r1
    c.r[1] += c.r[2];  // 060678D0 add r2,r1
    c.r[1] += 4;  // 060678D2 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060678D4 mov.b @r1,r1
    c.r[3] = c.r[1];  // 060678D6 mov r1,r3
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 060678D8 shlr r3
    c.r[3] &= c.r[0];  // 060678DA and r0,r3
    c.r[1] = c.r[10];  // 060678DC mov r10,r1
    c.r[1] <<= 2;  // 060678DE shll2 r1
    c.r[1] <<= 2;  // 060678E0 shll2 r1
    c.r[1] += c.r[2];  // 060678E2 add r2,r1
    c.r[1] += 3;  // 060678E4 add #3,r1
    c.r[0] = 0x3u;  // 060678E6 mov #3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060678E8 mov.b @r1,r1
    c.r[4] = c.r[3];  // 060678EA mov r3,r4
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060678EC shlr r1
    c.r[1] &= c.r[0];  // 060678EE and r0,r1
    c.r[0] = ld32(0x0606795Cu);  // 060678F0 mov.l 0x0606795C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060678F6u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060678F6u) return; }  // 060678F2 jsr @r0 ; mov r1,r5
    c.r[1] = c.r[0];  // 060678F6 mov r0,r1
    c.r[0] = 0x1u;  // 060678F8 mov #1,r0
    c.r[1] &= c.r[0];  // 060678FA and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060678FC tst r1,r1
    if (c.t) { goto L_06067906; }  // 060678FE bt 0x06067906
    c.r[0] = ld32(c.r[14] + 4);  // 06067900 mov.l @(4,r14),r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06067902 tst r0,r0
L_06067904:
    if (!c.t) { goto L_06067940; }  // 06067904 bf 0x06067940
L_06067906:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06067956u);  // 06067906 mov.w 0x06067956,r1
    c.t = c.r[10] == c.r[1];  // 06067908 cmp/eq r1,r10
    { const bool k = c.t; c.t = c.r[10] == c.r[12]; if (k) { goto L_06067940; } }  // 0606790A bt/s 0x06067940 ; cmp/eq r12,r10
    { const bool k = c.t; c.r[2] = c.r[10]; if (k) { goto L_06067940; } }  // 0606790E bt/s 0x06067940 ; mov r10,r2
    c.r[1] = ld32(0x06067958u);  // 06067912 mov.l 0x06067958,r1
    c.r[1] = ld32(c.r[1]);  // 06067914 mov.l @r1,r1
    c.r[2] <<= 2;  // 06067916 shll2 r2
    c.r[2] <<= 2;  // 06067918 shll2 r2
    c.r[2] += c.r[1];  // 0606791A add r1,r2
    c.r[2] += 7;  // 0606791C add #7,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606791E mov.b @r2,r1
    c.r[0] = c.r[1];  // 06067920 mov r1,r0
    c.r[0] >>= 2;  // 06067922 shlr2 r0
    c.r[0] >>= 2;  // 06067924 shlr2 r0
    c.r[0] &= 0x1u;  // 06067926 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06067928 tst r0,r0
    { const bool k = !c.t; c.r[4] = c.r[10]; if (k) { goto L_06067940; } }  // 0606792A bf/s 0x06067940 ; mov r10,r4
    c.r[1] = ld32(0x06067960u);  // 0606792E mov.l 0x06067960,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06067930 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06067932 mov r1,r0
    c.r[0] >>= 2;  // 06067934 shlr2 r0
    c.r[0] &= 0x1u;  // 06067936 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06067938 tst r0,r0
    c.r[1] = ld32(0x0606796Cu);  // 0606793A mov.l 0x0606796C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06067940u; c.r[5] = c.t; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06067940u) return; }  // 0606793C jsr @r1 ; movt r5
L_06067940:
    c.r[14] += 8;  // 06067940 add #8,r14
    c.r[15] = c.r[14];  // 06067942 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06067944 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06067946 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06067948 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0606794A mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0606794C mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0606794E mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06067950 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06067952 rts ; mov.l @r15+,r8
}

void f_06067970(SH2Context& c) {
    ran[1507] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06067970 mov.l r14,@-r15
    c.r[1] = ld32(0x060679C8u);  // 06067972 mov.l 0x060679C8,r1
    c.r[1] = ld32(c.r[1]);  // 06067974 mov.l @r1,r1
    c.r[1] += 1;  // 06067976 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06067978 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606797A extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606797C tst r1,r1
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_060679A8; } }  // 0606797E bf/s 0x060679A8 ; mov r15,r14
    c.r[3] = ld32(0x060679CCu);  // 06067982 mov.l 0x060679CC,r3
    c.r[1] = c.r[3];  // 06067984 mov r3,r1
    c.r[1] += 117;  // 06067986 add #117,r1
    c.r[2] = c.r[3];  // 06067988 mov r3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606798A mov.b @r1,r1
    c.r[2] += 79;  // 0606798C add #79,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606798E mov.b @r2,r2
    c.r[7] = ld32(0x060679D0u);  // 06067990 mov.l 0x060679D0,r7
    c.r[1] += c.r[2];  // 06067992 add r2,r1
    st8(c.r[7], c.r[1]);  // 06067994 mov.b r1,@r7
    c.r[1] = c.r[3];  // 06067996 mov r3,r1
    c.r[1] += 116;  // 06067998 add #116,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606799A mov.b @r1,r1
    c.r[3] += 78;  // 0606799C add #78,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0606799E mov.b @r3,r2
    c.r[7] = ld32(0x060679D4u);  // 060679A0 mov.l 0x060679D4,r7
    c.r[1] += c.r[2];  // 060679A2 add r2,r1
    st8(c.r[7], c.r[1]); goto L_060679BC;  // 060679A4 bra 0x060679BC ; mov.b r1,@r7
L_060679A8:
    c.r[2] = ld32(0x060679D4u);  // 060679A8 mov.l 0x060679D4,r2
    c.r[3] = ld32(0x060679D8u);  // 060679AA mov.l 0x060679D8,r3
    c.r[1] = c.r[3];  // 060679AC mov r3,r1
    c.r[1] += 15;  // 060679AE add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060679B0 mov.b @r1,r1
    c.r[3] += 19;  // 060679B2 add #19,r3
    st8(c.r[2], c.r[1]);  // 060679B4 mov.b r1,@r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060679B6 mov.b @r3,r1
    c.r[2] = ld32(0x060679D0u);  // 060679B8 mov.l 0x060679D0,r2
    st8(c.r[2], c.r[1]);  // 060679BA mov.b r1,@r2
L_060679BC:
    c.r[15] = c.r[14];  // 060679BC mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x060679C4u);  // 060679BE mov.w 0x060679C4,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060679C0 rts ; mov.l @r15+,r14
}

void f_060679DC(SH2Context& c) {
    ran[1508] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060679DC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060679DE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060679E0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060679E2 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060679E4 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060679E6 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060679E8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060679EA sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x06067A4Eu);  // 060679EC mov.w 0x06067A4E,r3
    c.r[15] += c.r[3];  // 060679EE add r3,r15
    c.r[1] = ld32(0x06067A50u);  // 060679F0 mov.l 0x06067A50,r1
    c.r[2] = ld32(c.r[1]);  // 060679F2 mov.l @r1,r2
    c.r[14] = c.r[15];  // 060679F4 mov r15,r14
    c.r[2] += 1;  // 060679F6 add #1,r2
    st32(c.r[1], c.r[2]);  // 060679F8 mov.l r2,@r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060679FA mov.b @r2,r1
    c.r[10] = ld32(0x06067A54u);  // 060679FC mov.l 0x06067A54,r10
    c.r[5] = ld32(c.r[10]);  // 060679FE mov.l @r10,r5
    c.r[13] = c.r[1] & 0xFFu;  // 06067A00 extu.b r1,r13
    c.r[1] = c.r[5];  // 06067A02 mov r5,r1
    c.r[1] += 24;  // 06067A04 add #24,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06067A06 mov.w @r1,r1
    c.r[9] = ld32(0x06067A58u);  // 06067A08 mov.l 0x06067A58,r9
    c.r[6] = c.r[1] & 0xFFFFu;  // 06067A0A extu.w r1,r6
    c.r[1] = ld32(0x06067A5Cu);  // 06067A0C mov.l 0x06067A5C,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06067A0E mov.b @r1,r4
    c.r[11] = 0x40u;  // 06067A10 mov #64,r11
    c.r[1] = ld32(0x06067A60u);  // 06067A12 mov.l 0x06067A60,r1
    c.macl = c.r[4] * c.r[11];  // 06067A14 mul.l r11,r4
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06067A16 mov.b @r1,r3
    c.r[2] = ld32(0x06067A64u);  // 06067A18 mov.l 0x06067A64,r2
    c.r[7] = ld32(c.r[2]);  // 06067A1A mov.l @r2,r7
    c.r[1] = c.macl;  // 06067A1C sts macl,r1
    c.r[1] += c.r[7];  // 06067A1E add r7,r1
    c.r[0] = c.r[1];  // 06067A20 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06067A22 mov.b @(r0,r3),r1
    c.r[12] = c.r[13];  // 06067A24 mov r13,r12
    c.r[0] = c.r[13];  // 06067A26 mov r13,r0
    c.t = c.r[0] == 0x1u;  // 06067A28 cmp/eq #1,r0
    { const bool k = !c.t; c.r[8] = c.r[1] & 0xFFu; if (k) { goto L_06067A32; } }  // 06067A2A bf/s 0x06067A32 ; extu.b r1,r8
    goto L_06067B54;  // 06067A2E bra 0x06067B54 ; nop
L_06067A32:
    c.r[7] = 0x1u;  // 06067A32 mov #1,r7
    c.t = (int32_t)c.r[13] > (int32_t)c.r[7];  // 06067A34 cmp/gt r7,r13
    { const bool k = c.t; c.t = c.r[0] == 0x2u; if (k) { goto L_06067A44; } }  // 06067A36 bt/s 0x06067A44 ; cmp/eq #2,r0
    c.t = (c.r[13] & c.r[13]) == 0;  // 06067A3A tst r13,r13
    { const bool k = c.t; c.r[1] = c.macl; if (k) { goto L_06067A68; } }  // 06067A3C bt/s 0x06067A68 ; sts macl,r1
    goto L_06067CE8;  // 06067A40 bra 0x06067CE8 ; nop
L_06067A44:
    if (c.t) { goto L_06067A4A; }  // 06067A44 bt 0x06067A4A
    goto L_06067CE8;  // 06067A46 bra 0x06067CE8 ; nop
L_06067A4A:
    goto L_06067BE4;  // 06067A4A bra 0x06067BE4 ; nop
L_06067A68:
    c.r[1] += c.r[9];  // 06067A68 add r9,r1
    c.r[0] = c.r[1];  // 06067A6A mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06067A6C mov.b @(r0,r3),r2
    c.r[5] = ld32(0x06067BC4u);  // 06067A6E mov.l 0x06067BC4,r5
    c.r[1] = c.r[2] & 0xFFu;  // 06067A70 extu.b r2,r1
    c.t = c.r[1] > c.r[6];  // 06067A72 cmp/hi r6,r1
    if (!c.t) { goto L_06067A7A; }  // 06067A74 bf 0x06067A7A
    goto L_06067CC4;  // 06067A76 bra 0x06067CC4 ; nop
L_06067A7A:
    c.r[6] = (uint32_t)(int16_t)ld16(0x06067BBEu);  // 06067A7A mov.w 0x06067BBE,r6
    c.t = c.r[1] == c.r[6];  // 06067A7C cmp/eq r6,r1
    { const bool k = !c.t; c.r[3] += c.r[3]; if (k) { goto L_06067A86; } }  // 06067A7E bf/s 0x06067A86 ; add r3,r3
    goto L_06067CC4;  // 06067A82 bra 0x06067CC4 ; nop
L_06067A86:
    c.r[4] <<= 2;  // 06067A86 shll2 r4
    c.r[4] <<= 2;  // 06067A88 shll2 r4
    c.r[4] += c.r[4];  // 06067A8A add r4,r4
    c.r[4] <<= 2;  // 06067A8C shll2 r4
    c.r[4] += c.r[5];  // 06067A8E add r5,r4
    c.r[0] = c.r[3];  // 06067A90 mov r3,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[4]);  // 06067A92 mov.w @(r0,r4),r1
    c.r[2] = c.r[1] & 0xFFFFu;  // 06067A94 extu.w r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06067A96 tst r2,r2
    if (!c.t) { goto L_06067A9E; }  // 06067A98 bf 0x06067A9E
    goto L_06067CC4;  // 06067A9A bra 0x06067CC4 ; nop
L_06067A9E:
    c.r[1] = ld32(0x06067BC8u);  // 06067A9E mov.l 0x06067BC8,r1
    c.t = c.r[2] == c.r[1];  // 06067AA0 cmp/eq r1,r2
    { const bool k = !c.t; c.t = c.r[8] == c.r[6]; if (k) { goto L_06067AAA; } }  // 06067AA2 bf/s 0x06067AAA ; cmp/eq r6,r8
    goto L_06067CC4;  // 06067AA6 bra 0x06067CC4 ; nop
L_06067AAA:
    { const bool k = !c.t; c.r[8] <<= 2; if (k) { goto L_06067AB2; } }  // 06067AAA bf/s 0x06067AB2 ; shll2 r8
    goto L_06067BBA;  // 06067AAE bra 0x06067BBA ; nop
L_06067AB2:
    c.r[9] = ld32(0x06067BCCu);  // 06067AB2 mov.l 0x06067BCC,r9
    c.r[1] = ld32(c.r[9]);  // 06067AB4 mov.l @r9,r1
    c.r[8] <<= 2;  // 06067AB6 shll2 r8
    c.r[1] += c.r[8];  // 06067AB8 add r8,r1
    c.r[1] += 2;  // 06067ABA add #2,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06067ABC mov.b @r1,r5
    c.r[4] = c.r[14];  // 06067ABE mov r14,r4
    c.r[1] = ld32(0x06067BD0u);  // 06067AC0 mov.l 0x06067BD0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06067AC6u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06067AC6u) return; }  // 06067AC2 jsr @r1 ; extu.b r5,r5
    c.r[9] = ld32(c.r[9]);  // 06067AC6 mov.l @r9,r9
    c.r[8] += c.r[9];  // 06067AC8 add r9,r8
    c.r[1] = c.r[8];  // 06067ACA mov r8,r1
    c.r[1] += 3;  // 06067ACC add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06067ACE mov.b @r1,r1
    c.r[0] = 0x3u;  // 06067AD0 mov #3,r0
    c.r[3] = c.r[1];  // 06067AD2 mov r1,r3
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 06067AD4 shlr r3
    c.r[3] &= c.r[0];  // 06067AD6 and r0,r3
    c.t = (c.r[3] & c.r[3]) == 0;  // 06067AD8 tst r3,r3
    if (!c.t) { goto L_06067AE6; }  // 06067ADA bf 0x06067AE6
    c.r[1] = ld32(c.r[8] + 12);  // 06067ADC mov.l @(12,r8),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06067ADE tst r1,r1
    if (c.t) { goto L_06067AE6; }  // 06067AE0 bt 0x06067AE6
    goto L_06067CC4;  // 06067AE2 bra 0x06067CC4 ; nop
L_06067AE6:
    c.r[1] = ld32(c.r[10]);  // 06067AE6 mov.l @r10,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06067BC0u);  // 06067AE8 mov.w 0x06067BC0,r2
    c.r[0] = c.r[1];  // 06067AEA mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06067AEC mov.b @(r0,r2),r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06067AEE shlr r1
    c.r[0] = 0xFu;  // 06067AF0 mov #15,r0
    c.r[1] &= c.r[0];  // 06067AF2 and r0,r1
    c.r[0] = c.r[1];  // 06067AF4 mov r1,r0
    c.t = c.r[0] == 0x9u;  // 06067AF6 cmp/eq #9,r0
    { const bool k = !c.t; c.r[0] = c.r[14]; if (k) { goto L_06067B0A; } }  // 06067AF8 bf/s 0x06067B0A ; mov r14,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06067AFC mov.b @(r0,r2),r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06067AFE shlr r1
    c.r[0] = 0xFu;  // 06067B00 mov #15,r0
    c.r[1] &= c.r[0];  // 06067B02 and r0,r1
    c.r[0] = c.r[1];  // 06067B04 mov r1,r0
    c.t = c.r[0] == 0x9u;  // 06067B06 cmp/eq #9,r0
    if (c.t) { goto L_06067BBA; }  // 06067B08 bt 0x06067BBA
L_06067B0A:
    c.r[1] = ld32(0x06067BD4u);  // 06067B0A mov.l 0x06067BD4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06067B0C mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 06067B0E extu.b r1,r2
    c.r[2] <<= 2;  // 06067B10 shll2 r2
    c.r[2] <<= 2;  // 06067B12 shll2 r2
    c.r[2] += c.r[9];  // 06067B14 add r9,r2
    c.r[1] = c.r[2];  // 06067B16 mov r2,r1
    c.r[1] += 3;  // 06067B18 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06067B1A mov.b @r1,r1
    c.r[0] = c.r[1];  // 06067B1C mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06067B1E shlr r0
    c.r[0] &= 0x3u;  // 06067B20 and #3,r0
    c.t = c.r[3] == c.r[0];  // 06067B22 cmp/eq r0,r3
    if (c.t) { goto L_06067B2A; }  // 06067B24 bt 0x06067B2A
    goto L_06067CC4;  // 06067B26 bra 0x06067CC4 ; nop
L_06067B2A:
    c.r[8] += 7;  // 06067B2A add #7,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06067B2C mov.b @r8,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06067B2E extu.b r1,r1
    c.r[1] >>= 2;  // 06067B30 shlr2 r1
    c.r[1] >>= 2;  // 06067B32 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06067B34 shlr r1
    c.r[1] >>= 2;  // 06067B36 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06067B38 tst r1,r1
    { const bool k = !c.t; c.r[8] = 0x0u; if (k) { goto L_06067B42; } }  // 06067B3A bf/s 0x06067B42 ; mov #0,r8
    goto L_06067DF8;  // 06067B3E bra 0x06067DF8 ; nop
L_06067B42:
    c.r[2] += 7;  // 06067B42 add #7,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06067B44 mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06067B46 extu.b r1,r1
    c.r[1] >>= 2;  // 06067B48 shlr2 r1
    c.r[1] >>= 2;  // 06067B4A shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06067B4C shlr r1
    c.r[1] >>= 2;  // 06067B4E shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0; goto L_06067BB4;  // 06067B50 bra 0x06067BB4 ; tst r1,r1
L_06067B54:
    c.r[3] = ld32(0x06067BD8u);  // 06067B54 mov.l 0x06067BD8,r3
    c.r[1] = c.r[3];  // 06067B56 mov r3,r1
    c.r[1] += 116;  // 06067B58 add #116,r1
    c.r[2] = c.r[3];  // 06067B5A mov r3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06067B5C mov.b @r1,r1
    c.r[2] += 78;  // 06067B5E add #78,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06067B60 mov.b @r2,r2
    c.r[1] += c.r[2];  // 06067B62 add r2,r1
    c.r[9] = c.r[1] & 0xFFu;  // 06067B64 extu.b r1,r9
    c.r[1] = c.r[3];  // 06067B66 mov r3,r1
    c.r[1] += 117;  // 06067B68 add #117,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06067B6A mov.b @r1,r1
    c.r[3] += 79;  // 06067B6C add #79,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06067B6E mov.b @r3,r2
    c.r[1] += c.r[2];  // 06067B70 add r2,r1
    c.r[10] = c.r[1] & 0xFFu;  // 06067B72 extu.b r1,r10
    c.macl = c.r[10] * c.r[11];  // 06067B74 mul.l r11,r10
    c.r[1] = c.macl;  // 06067B76 sts macl,r1
    c.r[1] += c.r[7];  // 06067B78 add r7,r1
    c.r[0] = c.r[1];  // 06067B7A mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 06067B7C mov.b @(r0,r9),r1
    c.r[8] = c.r[1] & 0xFFu;  // 06067B7E extu.b r1,r8
    c.r[1] = (uint32_t)(int16_t)ld16(0x06067BBEu);  // 06067B80 mov.w 0x06067BBE,r1
    c.t = c.r[8] == c.r[1];  // 06067B82 cmp/eq r1,r8
    { const bool k = !c.t; c.r[8] = 0x0u; if (k) { goto L_06067B8C; } }  // 06067B84 bf/s 0x06067B8C ; mov #0,r8
    goto L_06067DF8;  // 06067B88 bra 0x06067DF8 ; nop
L_06067B8C:
    c.r[2] = c.macl;  // 06067B8C sts macl,r2
    c.r[2] += c.r[9];  // 06067B8E add r9,r2
    c.r[3] = c.r[2];  // 06067B90 mov r2,r3
    c.r[3] >>= 2;  // 06067B92 shlr2 r3
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 06067B94 shlr r3
    c.r[1] = ld32(0x06067BDCu);  // 06067B96 mov.l 0x06067BDC,r1
    c.r[0] = c.r[3];  // 06067B98 mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06067B9A mov.b @(r0,r1),r1
    c.r[5] = c.r[2];  // 06067B9C mov r2,r5
    c.r[4] = c.r[1] & 0xFFu;  // 06067B9E extu.b r1,r4
    c.r[5] >>= 2;  // 06067BA0 shlr2 r5
    c.t = c.r[5] & 1; c.r[5] >>= 1;  // 06067BA2 shlr r5
    c.r[5] <<= 2;  // 06067BA4 shll2 r5
    c.r[5] += c.r[5];  // 06067BA6 add r5,r5
    c.r[5] -= c.r[2];  // 06067BA8 sub r2,r5
L_06067BAA:
    c.r[0] = ld32(0x06067BE0u);  // 06067BAA mov.l 0x06067BE0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06067BB0u; c.r[5] += 7; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06067BB0u) return; }  // 06067BAC jsr @r0 ; add #7,r5
    c.r[0] &= 0x1u;  // 06067BB0 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06067BB2 tst r0,r0
L_06067BB4:
    if (c.t) { goto L_06067BBA; }  // 06067BB4 bt 0x06067BBA
    goto L_06067CC4;  // 06067BB6 bra 0x06067CC4 ; nop
L_06067BBA:
    c.r[8] = 0x1u; goto L_06067DF8;  // 06067BBA bra 0x06067DF8 ; mov #1,r8
L_06067BE4:
    c.r[1] = ld32(0x06067CD0u);  // 06067BE4 mov.l 0x06067CD0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06067BE6 mov.b @r1,r1
    c.r[6] = c.r[1] & 0xFFu;  // 06067BE8 extu.b r1,r6
    c.r[1] = c.r[6];  // 06067BEA mov r6,r1
    c.r[1] <<= 2;  // 06067BEC shll2 r1
    c.r[1] += c.r[6];  // 06067BEE add r6,r1
    c.r[1] <<= 2;  // 06067BF0 shll2 r1
    c.r[5] += c.r[1];  // 06067BF2 add r1,r5
    c.r[5] += 50;  // 06067BF4 add #50,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[5]);  // 06067BF6 mov.b @r5,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06067BF8 extu.b r1,r0
    c.r[0] >>= 2;  // 06067BFA shlr2 r0
    c.r[0] >>= 2;  // 06067BFC shlr2 r0
    c.r[0] >>= 2;  // 06067BFE shlr2 r0
    c.t = c.r[0] == 0x2u;  // 06067C00 cmp/eq #2,r0
    { const bool k = !c.t; c.r[0] = c.r[1]; if (k) { goto L_06067C5E; } }  // 06067C02 bf/s 0x06067C5E ; mov r1,r0
    c.r[0] &= 0x3Fu;  // 06067C06 and #63,r0
    c.r[1] = ld32(0x06067CD4u);  // 06067C08 mov.l 0x06067CD4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06067C0A mov.b @(r0,r1),r1
    c.r[8] = c.r[1] & 0xFFu;  // 06067C0C extu.b r1,r8
    c.r[1] = c.r[8];  // 06067C0E mov r8,r1
    c.r[1] -= 2;  // 06067C10 add #-2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06067C12 extu.b r1,r1
    c.t = c.r[1] > c.r[7];  // 06067C14 cmp/hi r7,r1
    { const bool k = !c.t; c.r[0] = c.r[8]; if (k) { goto L_06067C22; } }  // 06067C16 bf/s 0x06067C22 ; mov r8,r0
    c.t = c.r[0] == 0x7u;  // 06067C1A cmp/eq #7,r0
    { const bool k = c.t; c.t = c.r[0] == 0xCu; if (k) { goto L_06067C22; } }  // 06067C1C bt/s 0x06067C22 ; cmp/eq #12,r0
    if (!c.t) { SH2_POLL(c); goto L_06067BBA; }  // 06067C20 bf 0x06067BBA
L_06067C22:
    c.r[1] = ld32(0x06067CD8u);  // 06067C22 mov.l 0x06067CD8,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06067C24 mov.b @r1,r3
    c.r[1] = ld32(0x06067CDCu);  // 06067C26 mov.l 0x06067CDC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06067C28 mov.b @r1,r1
    c.r[3] <<= 2;  // 06067C2A shll2 r3
    c.r[3] <<= 2;  // 06067C2C shll2 r3
    c.r[3] <<= 2;  // 06067C2E shll2 r3
    c.r[3] += c.r[1];  // 06067C30 add r1,r3
    c.t = (int32_t)c.r[3] >= 0;  // 06067C32 cmp/pz r3
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_06067C3A; } }  // 06067C34 bt/s 0x06067C3A ; mov r3,r1
    c.r[1] += 7;  // 06067C38 add #7,r1
L_06067C3A:
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06067C3A shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06067C3C shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06067C3E shar r1
    c.r[2] = ld32(0x06067CE0u);  // 06067C40 mov.l 0x06067CE0,r2
    c.r[0] = c.r[1];  // 06067C42 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06067C44 mov.b @(r0,r2),r1
    c.r[5] = c.r[3];  // 06067C46 mov r3,r5
    c.t = (int32_t)c.r[3] >= 0;  // 06067C48 cmp/pz r3
    { const bool k = c.t; c.r[4] = c.r[1] & 0xFFu; if (k) { goto L_06067C50; } }  // 06067C4A bt/s 0x06067C50 ; extu.b r1,r4
    c.r[5] += 7;  // 06067C4E add #7,r5
L_06067C50:
    c.t = c.r[5] & 1; c.r[5] = (uint32_t)((int32_t)c.r[5] >> 1);  // 06067C50 shar r5
    c.t = c.r[5] & 1; c.r[5] = (uint32_t)((int32_t)c.r[5] >> 1);  // 06067C52 shar r5
    c.t = c.r[5] & 1; c.r[5] = (uint32_t)((int32_t)c.r[5] >> 1);  // 06067C54 shar r5
    c.r[5] <<= 2;  // 06067C56 shll2 r5
    c.r[5] += c.r[5];  // 06067C58 add r5,r5
    c.r[5] -= c.r[3]; SH2_POLL(c); goto L_06067BAA;  // 06067C5A bra 0x06067BAA ; sub r3,r5
L_06067C5E:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06067CC8u);  // 06067C5E mov.w 0x06067CC8,r1
    c.t = c.r[8] == c.r[1];  // 06067C60 cmp/eq r1,r8
    { const bool k = c.t; c.r[7] = 0x0u; if (k) { goto L_06067CC4; } }  // 06067C62 bt/s 0x06067CC4 ; mov #0,r7
    c.r[1] = ld32(0x06067CE4u);  // 06067C66 mov.l 0x06067CE4,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x06067CCAu);  // 06067C68 mov.w 0x06067CCA,r3
    c.macl = c.r[6] * c.r[3];  // 06067C6A mul.l r3,r6
    c.r[2] = ld32(c.r[1]);  // 06067C6C mov.l @r1,r2
    c.r[9] = (uint32_t)(int16_t)ld16(0x06067CCCu);  // 06067C6E mov.w 0x06067CCC,r9
    c.r[1] = c.macl;  // 06067C70 sts macl,r1
    c.r[1] += c.r[2];  // 06067C72 add r2,r1
    c.r[0] = c.r[1];  // 06067C74 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 06067C76 mov.b @(r0,r9),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06067C78 extu.b r1,r1
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[1];  // 06067C7A cmp/ge r1,r7
    if (c.t) { goto L_06067CA6; }  // 06067C7C bt 0x06067CA6
    c.r[5] = c.r[2];  // 06067C7E mov r2,r5
    c.r[4] = c.r[3];  // 06067C80 mov r3,r4
    c.r[3] = 0x0u;  // 06067C82 mov #0,r3
    c.macl = c.r[6] * c.r[4];  // 06067C84 mul.l r4,r6
L_06067C86:
    c.r[2] = c.macl;  // 06067C86 sts macl,r2
    c.r[2] += c.r[5];  // 06067C88 add r5,r2
    c.r[1] = c.r[2];  // 06067C8A mov r2,r1
    c.r[1] += c.r[3];  // 06067C8C add r3,r1
    c.r[1] += 4;  // 06067C8E add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06067C90 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06067C92 extu.b r1,r1
    c.t = c.r[1] == c.r[8];  // 06067C94 cmp/eq r8,r1
    { const bool k = c.t; c.r[0] = c.r[2]; if (k) { goto L_06067CA6; } }  // 06067C96 bt/s 0x06067CA6 ; mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 06067C9A mov.b @(r0,r9),r1
    c.r[7] += 1;  // 06067C9C add #1,r7
    c.r[1] = c.r[1] & 0xFFu;  // 06067C9E extu.b r1,r1
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[1];  // 06067CA0 cmp/ge r1,r7
    { const bool k = !c.t; c.r[3] += 8; if (k) { SH2_POLL(c); goto L_06067C86; } }  // 06067CA2 bf/s 0x06067C86 ; add #8,r3
L_06067CA6:
    c.r[1] = ld32(0x06067CE4u);  // 06067CA6 mov.l 0x06067CE4,r1
    c.r[3] = ld32(c.r[1]);  // 06067CA8 mov.l @r1,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x06067CCAu);  // 06067CAA mov.w 0x06067CCA,r1
    c.macl = c.r[6] * c.r[1];  // 06067CAC mul.l r1,r6
    c.r[2] = c.macl;  // 06067CAE sts macl,r2
    c.r[2] += c.r[3];  // 06067CB0 add r3,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06067CCCu);  // 06067CB2 mov.w 0x06067CCC,r1
    c.r[0] = c.r[2];  // 06067CB4 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06067CB6 mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06067CB8 extu.b r1,r1
    c.t = c.r[7] == c.r[1];  // 06067CBA cmp/eq r1,r7
    { const bool k = c.t; c.r[8] = 0x1u; if (k) { goto L_06067CC4; } }  // 06067CBC bt/s 0x06067CC4 ; mov #1,r8
    goto L_06067DF8;  // 06067CC0 bra 0x06067DF8 ; nop
L_06067CC4:
    c.r[8] = 0x0u; goto L_06067DF8;  // 06067CC4 bra 0x06067DF8 ; mov #0,r8
L_06067CE8:
    c.r[3] = ld32(0x06067E20u);  // 06067CE8 mov.l 0x06067E20,r3
    c.r[1] = c.r[3];  // 06067CEA mov r3,r1
    c.r[1] += 116;  // 06067CEC add #116,r1
    c.r[2] = c.r[3];  // 06067CEE mov r3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06067CF0 mov.b @r1,r1
    c.r[2] += 78;  // 06067CF2 add #78,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06067CF4 mov.b @r2,r2
    c.r[1] += c.r[2];  // 06067CF6 add r2,r1
    c.r[9] = c.r[1] & 0xFFu;  // 06067CF8 extu.b r1,r9
    c.r[1] = c.r[3];  // 06067CFA mov r3,r1
    c.r[1] += 117;  // 06067CFC add #117,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06067CFE mov.b @r1,r1
    c.r[3] += 79;  // 06067D00 add #79,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06067D02 mov.b @r3,r2
    c.r[1] += c.r[2];  // 06067D04 add r2,r1
    c.r[10] = c.r[1] & 0xFFu;  // 06067D06 extu.b r1,r10
    c.r[1] = ld32(0x06067E24u);  // 06067D08 mov.l 0x06067E24,r1
    c.r[2] = ld32(c.r[1]);  // 06067D0A mov.l @r1,r2
    c.r[1] = 0x40u;  // 06067D0C mov #64,r1
    c.macl = c.r[10] * c.r[1];  // 06067D0E mul.l r1,r10
    c.r[1] = c.macl;  // 06067D10 sts macl,r1
    c.r[1] += c.r[2];  // 06067D12 add r2,r1
    c.r[0] = c.r[1];  // 06067D14 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 06067D16 mov.b @(r0,r9),r1
    c.r[6] = c.r[1] & 0xFFu;  // 06067D18 extu.b r1,r6
    c.r[1] = (uint32_t)(int16_t)ld16(0x06067E1Au);  // 06067D1A mov.w 0x06067E1A,r1
    c.t = c.r[6] == c.r[1];  // 06067D1C cmp/eq r1,r6
    { const bool k = c.t; c.r[8] = 0x0u; if (k) { goto L_06067DF8; } }  // 06067D1E bt/s 0x06067DF8 ; mov #0,r8
    c.r[2] = c.macl;  // 06067D22 sts macl,r2
    c.r[2] += c.r[9];  // 06067D24 add r9,r2
    c.r[3] = c.r[2];  // 06067D26 mov r2,r3
    c.r[3] >>= 2;  // 06067D28 shlr2 r3
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 06067D2A shlr r3
    c.r[1] = ld32(0x06067E28u);  // 06067D2C mov.l 0x06067E28,r1
    c.r[0] = c.r[3];  // 06067D2E mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06067D30 mov.b @(r0,r1),r1
    c.r[5] = c.r[2];  // 06067D32 mov r2,r5
    c.r[4] = c.r[1] & 0xFFu;  // 06067D34 extu.b r1,r4
    c.r[5] >>= 2;  // 06067D36 shlr2 r5
    c.t = c.r[5] & 1; c.r[5] >>= 1;  // 06067D38 shlr r5
    c.r[5] <<= 2;  // 06067D3A shll2 r5
    c.r[5] += c.r[5];  // 06067D3C add r5,r5
    c.r[5] -= c.r[2];  // 06067D3E sub r2,r5
    c.r[0] = ld32(0x06067E2Cu);  // 06067D40 mov.l 0x06067E2C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06067D46u; c.r[5] += 7; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06067D46u) return; }  // 06067D42 jsr @r0 ; add #7,r5
    c.r[0] &= 0x1u;  // 06067D46 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06067D48 tst r0,r0
    { const bool k = !c.t; c.r[0] = c.r[10]; if (k) { goto L_06067DF8; } }  // 06067D4A bf/s 0x06067DF8 ; mov r10,r0
    c.r[1] = ld32(0x06067E30u);  // 06067D4E mov.l 0x06067E30,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06067D50 mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 06067D52 extu.b r2,r2
    c.r[1] = ld32(0x06067E34u);  // 06067D54 mov.l 0x06067E34,r1
    c.r[1] = ld32(c.r[1]);  // 06067D56 mov.l @r1,r1
    c.r[2] <<= 2;  // 06067D58 shll2 r2
    c.r[2] <<= 2;  // 06067D5A shll2 r2
    c.r[2] += c.r[1];  // 06067D5C add r1,r2
    c.r[2] += 1;  // 06067D5E add #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06067D60 mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06067D62 extu.b r1,r1
    c.r[0] -= c.r[1];  // 06067D64 sub r1,r0
    c.r[1] = c.r[0];  // 06067D66 mov r0,r1
    c.t = (int32_t)c.r[1] > 0;  // 06067D68 cmp/pl r1
    if (!c.t) { goto L_06067D7A; }  // 06067D6A bf 0x06067D7A
    c.r[1] = ld32(0x06067E38u);  // 06067D6C mov.l 0x06067E38,r1
    c.r[2] = ld32(c.r[1]);  // 06067D6E mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06067D70 tst r2,r2
    if (c.t) { goto L_06067D7A; }  // 06067D72 bt 0x06067D7A
    c.r[8] = 0x1u;  // 06067D74 mov #1,r8
    c.r[1] = ld32(0x06067E3Cu);  // 06067D76 mov.l 0x06067E3C,r1
    st32(c.r[1] + 8, c.r[2]);  // 06067D78 mov.l r2,@(8,r1)
L_06067D7A:
    c.r[1] = ld32(0x06067E30u);  // 06067D7A mov.l 0x06067E30,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06067D7C mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 06067D7E extu.b r2,r2
    c.r[1] = ld32(0x06067E34u);  // 06067D80 mov.l 0x06067E34,r1
    c.r[1] = ld32(c.r[1]);  // 06067D82 mov.l @r1,r1
    c.r[2] <<= 2;  // 06067D84 shll2 r2
    c.r[2] <<= 2;  // 06067D86 shll2 r2
    c.r[2] += c.r[1];  // 06067D88 add r1,r2
    c.r[2] += 1;  // 06067D8A add #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06067D8C mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06067D8E extu.b r1,r1
    c.r[10] -= c.r[1];  // 06067D90 sub r1,r10
    c.t = (int32_t)c.r[10] >= 0;  // 06067D92 cmp/pz r10
    if (c.t) { goto L_06067DA4; }  // 06067D94 bt 0x06067DA4
    c.r[1] = ld32(0x06067E38u);  // 06067D96 mov.l 0x06067E38,r1
    c.r[2] = ld32(c.r[1] + 8);  // 06067D98 mov.l @(8,r1),r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06067D9A tst r2,r2
    if (c.t) { goto L_06067DA4; }  // 06067D9C bt 0x06067DA4
    c.r[8] = 0x1u;  // 06067D9E mov #1,r8
    c.r[1] = ld32(0x06067E3Cu);  // 06067DA0 mov.l 0x06067E3C,r1
    st32(c.r[1] + 8, c.r[2]);  // 06067DA2 mov.l r2,@(8,r1)
L_06067DA4:
    c.r[1] = ld32(0x06067E30u);  // 06067DA4 mov.l 0x06067E30,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06067DA6 mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 06067DA8 extu.b r2,r2
    c.r[1] = ld32(0x06067E34u);  // 06067DAA mov.l 0x06067E34,r1
    c.r[2] <<= 2;  // 06067DAC shll2 r2
    c.r[2] <<= 2;  // 06067DAE shll2 r2
    c.r[1] = ld32(c.r[1]);  // 06067DB0 mov.l @r1,r1
    c.r[0] = c.r[2];  // 06067DB2 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06067DB4 mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06067DB6 extu.b r1,r1
    c.r[0] = c.r[9];  // 06067DB8 mov r9,r0
    c.r[0] -= c.r[1];  // 06067DBA sub r1,r0
    c.r[1] = c.r[0];  // 06067DBC mov r0,r1
    c.t = (int32_t)c.r[1] > 0;  // 06067DBE cmp/pl r1
    if (!c.t) { goto L_06067DD0; }  // 06067DC0 bf 0x06067DD0
    c.r[1] = ld32(0x06067E38u);  // 06067DC2 mov.l 0x06067E38,r1
    c.r[2] = ld32(c.r[1] + 12);  // 06067DC4 mov.l @(12,r1),r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06067DC6 tst r2,r2
    if (c.t) { goto L_06067DD0; }  // 06067DC8 bt 0x06067DD0
    c.r[8] = 0x1u;  // 06067DCA mov #1,r8
    c.r[1] = ld32(0x06067E3Cu);  // 06067DCC mov.l 0x06067E3C,r1
    st32(c.r[1] + 8, c.r[2]);  // 06067DCE mov.l r2,@(8,r1)
L_06067DD0:
    c.r[1] = ld32(0x06067E30u);  // 06067DD0 mov.l 0x06067E30,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06067DD2 mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 06067DD4 extu.b r2,r2
    c.r[1] = ld32(0x06067E34u);  // 06067DD6 mov.l 0x06067E34,r1
    c.r[2] <<= 2;  // 06067DD8 shll2 r2
    c.r[2] <<= 2;  // 06067DDA shll2 r2
    c.r[1] = ld32(c.r[1]);  // 06067DDC mov.l @r1,r1
    c.r[0] = c.r[2];  // 06067DDE mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06067DE0 mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06067DE2 extu.b r1,r1
    c.r[9] -= c.r[1];  // 06067DE4 sub r1,r9
    c.t = (int32_t)c.r[9] >= 0;  // 06067DE6 cmp/pz r9
    if (c.t) { goto L_06067DF8; }  // 06067DE8 bt 0x06067DF8
    c.r[1] = ld32(0x06067E38u);  // 06067DEA mov.l 0x06067E38,r1
    c.r[2] = ld32(c.r[1] + 4);  // 06067DEC mov.l @(4,r1),r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06067DEE tst r2,r2
    if (c.t) { goto L_06067DF8; }  // 06067DF0 bt 0x06067DF8
    c.r[8] = 0x1u;  // 06067DF2 mov #1,r8
    c.r[1] = ld32(0x06067E3Cu);  // 06067DF4 mov.l 0x06067E3C,r1
    st32(c.r[1] + 8, c.r[2]);  // 06067DF6 mov.l r2,@(8,r1)
L_06067DF8:
    c.r[3] = (uint32_t)(int16_t)ld16(0x06067E1Cu);  // 06067DF8 mov.w 0x06067E1C,r3
    c.r[14] += c.r[3];  // 06067DFA add r3,r14
    c.r[15] = c.r[14];  // 06067DFC mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06067DFE lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06067E00 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06067E02 mov.l @r15+,r13
    c.r[8] += c.r[8];  // 06067E04 add r8,r8
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06067E06 mov.l @r15+,r12
    c.r[8] += 1;  // 06067E08 add #1,r8
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06067E0A mov.l @r15+,r11
    c.r[1] = (uint32_t)(int16_t)ld16(0x06067E1Eu);  // 06067E0C mov.w 0x06067E1E,r1
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06067E0E mov.l @r15+,r10
    c.r[8] |= c.r[1];  // 06067E10 or r1,r8
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06067E12 mov.l @r15+,r9
    c.r[0] = c.r[8];  // 06067E14 mov r8,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06067E16 rts ; mov.l @r15+,r8
}

void f_06067E40(SH2Context& c) {
    ran[1509] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06067E40 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06067E42 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06067E44 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06067E46 mov r15,r14
    c.r[1] = ld32(0x06067E94u);  // 06067E48 mov.l 0x06067E94,r1
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06067E4A mov.b @r1,r7
    c.r[8] = ld32(0x06067E98u);  // 06067E4C mov.l 0x06067E98,r8
    c.r[1] = ld32(0x06067E9Cu);  // 06067E4E mov.l 0x06067E9C,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06067E50 mov.b @r1,r6
    c.r[7] = c.r[7] & 0xFFu;  // 06067E52 extu.b r7,r7
    c.r[1] = ld32(0x06067EA0u);  // 06067E54 mov.l 0x06067EA0,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06067E56 mov.b @r1,r2
    c.r[6] = c.r[6] & 0xFFu;  // 06067E58 extu.b r6,r6
    c.r[2] = c.r[2] & 0xFFu;  // 06067E5A extu.b r2,r2
    c.r[1] = ld32(0x06067EA4u);  // 06067E5C mov.l 0x06067EA4,r1
    c.r[3] = ld32(c.r[1]);  // 06067E5E mov.l @r1,r3
    c.r[2] <<= 2;  // 06067E60 shll2 r2
    c.r[2] <<= 2;  // 06067E62 shll2 r2
    c.r[1] = c.r[2];  // 06067E64 mov r2,r1
    c.r[1] += c.r[3];  // 06067E66 add r3,r1
    c.r[1] += 1;  // 06067E68 add #1,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06067E6A mov.b @r1,r5
    c.r[0] = c.r[2];  // 06067E6C mov r2,r0
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06067E6E mov.b @(r0,r3),r4
    c.r[5] = c.r[5] & 0xFFu;  // 06067E70 extu.b r5,r5
    c.r[1] = ld32(0x06067EA8u);  // 06067E72 mov.l 0x06067EA8,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06067E74 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06067E76 mov.l r8,@-r15
    c.r[1] = ld32(0x06067EACu);  // 06067E78 mov.l 0x06067EAC,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06067E7A mov.l r1,@-r15
    c.r[1] = ld32(0x06067EB0u);  // 06067E7C mov.l 0x06067EB0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06067E82u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06067E82u) return; }  // 06067E7E jsr @r1 ; extu.b r4,r4
    c.r[1] = ld32(0x06067EB4u);  // 06067E82 mov.l 0x06067EB4,r1
    st32(c.r[1], c.r[8]);  // 06067E84 mov.l r8,@r1
    c.r[15] = c.r[14];  // 06067E86 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06067E88 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06067E8A mov.l @r15+,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x06067E92u);  // 06067E8C mov.w 0x06067E92,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06067E8E rts ; mov.l @r15+,r8
}

void f_06067EB8(SH2Context& c) {
    ran[1510] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06067EB8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06067EBA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06067EBC mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06067EBE mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06067EC0 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06067EC2 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06067EC4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06067EC6 sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x0606800Eu);  // 06067EC8 mov.w 0x0606800E,r3
    c.r[15] += c.r[3];  // 06067ECA add r3,r15
    c.r[11] = ld32(0x06068018u);  // 06067ECC mov.l 0x06068018,r11
    c.r[5] = ld32(0x0606801Cu);  // 06067ECE mov.l 0x0606801C,r5
    c.r[2] = ld32(c.r[5]);  // 06067ED0 mov.l @r5,r2
    c.r[1] = ld32(0x06068020u);  // 06067ED2 mov.l 0x06068020,r1
    c.t = c.r[2] == c.r[1];  // 06067ED4 cmp/eq r1,r2
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_06067F0A; } }  // 06067ED6 bf/s 0x06067F0A ; mov r15,r14
    c.r[1] = ld32(0x06068024u);  // 06067EDA mov.l 0x06068024,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06067EDC mov.b @r1,r2
    c.r[6] = ld32(0x06068028u);  // 06067EDE mov.l 0x06068028,r6
    c.r[2] = c.r[2] & 0xFFu;  // 06067EE0 extu.b r2,r2
    c.r[1] = ld32(0x0606802Cu);  // 06067EE2 mov.l 0x0606802C,r1
    c.r[7] = ld32(c.r[1]);  // 06067EE4 mov.l @r1,r7
    c.r[2] <<= 2;  // 06067EE6 shll2 r2
    c.r[2] <<= 2;  // 06067EE8 shll2 r2
    c.r[1] = c.r[2];  // 06067EEA mov r2,r1
    c.r[1] += c.r[7];  // 06067EEC add r7,r1
    c.r[1] += 1;  // 06067EEE add #1,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06067EF0 mov.b @r1,r3
    c.r[0] = c.r[2];  // 06067EF2 mov r2,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06067EF4 mov.b @(r0,r7),r2
    c.r[3] = c.r[3] & 0xFFu;  // 06067EF6 extu.b r3,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06067EF8 extu.b r2,r2
    c.r[1] = ld32(c.r[6]);  // 06067EFA mov.l @r6,r1
    c.r[3] <<= 2;  // 06067EFC shll2 r3
    c.r[3] <<= 2;  // 06067EFE shll2 r3
    c.r[3] <<= 2;  // 06067F00 shll2 r3
    c.r[3] += c.r[1];  // 06067F02 add r1,r3
    c.r[1] = 0xFFFFFFFFu;  // 06067F04 mov #-1,r1
    c.r[0] = c.r[3];  // 06067F06 mov r3,r0
    st8(c.r[0] + c.r[2], c.r[1]);  // 06067F08 mov.b r1,@(r0,r2)
L_06067F0A:
    c.r[8] = ld32(0x06068028u);  // 06067F0A mov.l 0x06068028,r8
    c.r[3] = c.r[8];  // 06067F0C mov r8,r3
    c.r[3] += 16;  // 06067F0E add #16,r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06067F10 mov.b @r3,r0
    c.r[7] = 0x4u;  // 06067F12 mov #4,r7
    c.r[7] |= c.r[0];  // 06067F14 or r0,r7
    st8(c.r[3], c.r[7]);  // 06067F16 mov.b r7,@r3
    c.r[2] = ld32(c.r[5]);  // 06067F18 mov.l @r5,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06067F1A mov.b @r2,r1
    c.r[4] = c.r[1] & 0xFFu;  // 06067F1C extu.b r1,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x06068010u);  // 06067F1E mov.w 0x06068010,r1
    c.t = c.r[4] == c.r[1];  // 06067F20 cmp/eq r1,r4
    { const bool k = c.t; c.r[2] += 1; if (k) { goto L_06067F2A; } }  // 06067F22 bt/s 0x06067F2A ; add #1,r2
    goto L_060680CE;  // 06067F26 bra 0x060680CE ; nop
L_06067F2A:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06068012u);  // 06067F2A mov.w 0x06068012,r0
    c.r[7] &= c.r[0];  // 06067F2C and r0,r7
    st8(c.r[3], c.r[7]);  // 06067F2E mov.b r7,@r3
    c.r[10] = ld32(0x06068024u);  // 06067F30 mov.l 0x06068024,r10
    c.r[9] = ld32(0x0606802Cu);  // 06067F32 mov.l 0x0606802C,r9
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[10]);  // 06067F34 mov.b @r10,r2
    c.r[6] = ld32(0x06068030u);  // 06067F36 mov.l 0x06068030,r6
    c.r[1] = ld32(c.r[9]);  // 06067F38 mov.l @r9,r1
    c.r[2] = c.r[2] & 0xFFu;  // 06067F3A extu.b r2,r2
    c.r[2] <<= 2;  // 06067F3C shll2 r2
    c.r[2] <<= 2;  // 06067F3E shll2 r2
    c.r[2] += c.r[1];  // 06067F40 add r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 06067F42 mov.b @r6,r1
    c.r[2] += 1;  // 06067F44 add #1,r2
    st8(c.r[2], c.r[1]);  // 06067F46 mov.b r1,@r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[10]);  // 06067F48 mov.b @r10,r2
    c.r[7] = ld32(c.r[9]);  // 06067F4A mov.l @r9,r7
    c.r[3] = ld32(0x06068034u);  // 06067F4C mov.l 0x06068034,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06067F4E mov.b @r3,r1
    c.r[2] = c.r[2] & 0xFFu;  // 06067F50 extu.b r2,r2
    c.r[2] <<= 2;  // 06067F52 shll2 r2
    c.r[2] <<= 2;  // 06067F54 shll2 r2
    c.r[0] = c.r[2];  // 06067F56 mov r2,r0
    st8(c.r[0] + c.r[7], c.r[1]);  // 06067F58 mov.b r1,@(r0,r7)
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[6]);  // 06067F5A mov.b @r6,r7
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06067F5C mov.b @r3,r2
    c.r[1] = ld32(c.r[8]);  // 06067F5E mov.l @r8,r1
    c.r[7] <<= 2;  // 06067F60 shll2 r7
    c.r[7] <<= 2;  // 06067F62 shll2 r7
    c.r[7] <<= 2;  // 06067F64 shll2 r7
    c.r[7] += c.r[1];  // 06067F66 add r1,r7
    c.r[0] = c.r[7];  // 06067F68 mov r7,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06067F6A mov.b @(r0,r2),r1
    c.r[8] = c.r[1] & 0xFFu;  // 06067F6C extu.b r1,r8
    c.t = c.r[8] == c.r[4];  // 06067F6E cmp/eq r4,r8
    if (c.t) { goto L_06068040; }  // 06067F70 bt 0x06068040
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 06067F72 mov.b @r10,r1
    c.r[5] = c.r[8];  // 06067F74 mov r8,r5
    c.r[2] = ld32(c.r[9]);  // 06067F76 mov.l @r9,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06067F78 extu.b r1,r1
    c.r[1] <<= 2;  // 06067F7A shll2 r1
    c.r[1] <<= 2;  // 06067F7C shll2 r1
    c.r[1] += c.r[2];  // 06067F7E add r2,r1
    c.r[1] += 3;  // 06067F80 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06067F82 mov.b @r1,r1
    c.r[0] = 0x3u;  // 06067F84 mov #3,r0
    c.r[3] = c.r[1];  // 06067F86 mov r1,r3
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 06067F88 shlr r3
    c.r[5] <<= 2;  // 06067F8A shll2 r5
    c.r[5] <<= 2;  // 06067F8C shll2 r5
    c.r[5] += c.r[2];  // 06067F8E add r2,r5
    c.r[1] = c.r[5];  // 06067F90 mov r5,r1
    c.r[1] += 3;  // 06067F92 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06067F94 mov.b @r1,r1
    c.r[3] &= c.r[0];  // 06067F96 and r0,r3
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06067F98 shlr r1
    c.r[1] &= c.r[0];  // 06067F9A and r0,r1
    c.t = c.r[3] == c.r[1];  // 06067F9C cmp/eq r1,r3
    { const bool k = !c.t; c.r[5] += 2; if (k) { goto L_06068040; } }  // 06067F9E bf/s 0x06068040 ; add #2,r5
    c.r[1] = ld32(0x06068038u);  // 06067FA2 mov.l 0x06068038,r1
    c.r[6] = c.r[4];  // 06067FA4 mov r4,r6
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[5]);  // 06067FA6 mov.b @r5,r5
    c.r[4] = c.r[14];  // 06067FA8 mov r14,r4
    { const uint32_t x = c.r[1]; c.pr = 0x06067FAEu; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06067FAEu) return; }  // 06067FAA jsr @r1 ; extu.b r5,r5
    c.r[1] = ld32(0x0606803Cu);  // 06067FAE mov.l 0x0606803C,r1
    c.r[1] = ld32(c.r[1]);  // 06067FB0 mov.l @r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06068014u);  // 06067FB2 mov.w 0x06068014,r2
    c.r[0] = c.r[1];  // 06067FB4 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06067FB6 mov.b @(r0,r2),r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06067FB8 shlr r1
    c.r[0] = 0xFu;  // 06067FBA mov #15,r0
    c.r[1] &= c.r[0];  // 06067FBC and r0,r1
    c.r[0] = c.r[1];  // 06067FBE mov r1,r0
    c.t = c.r[0] == 0x9u;  // 06067FC0 cmp/eq #9,r0
    { const bool k = !c.t; c.r[0] = c.r[14]; if (k) { goto L_06067FD4; } }  // 06067FC2 bf/s 0x06067FD4 ; mov r14,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06067FC6 mov.b @(r0,r2),r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06067FC8 shlr r1
    c.r[0] = 0xFu;  // 06067FCA mov #15,r0
    c.r[1] &= c.r[0];  // 06067FCC and r0,r1
    c.r[0] = c.r[1];  // 06067FCE mov r1,r0
    c.t = c.r[0] == 0x9u;  // 06067FD0 cmp/eq #9,r0
    if (c.t) { goto L_0606806E; }  // 06067FD2 bt 0x0606806E
L_06067FD4:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 06067FD4 mov.b @r10,r1
    c.r[2] = ld32(c.r[9]);  // 06067FD6 mov.l @r9,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06067FD8 extu.b r1,r1
    c.r[1] <<= 2;  // 06067FDA shll2 r1
    c.r[1] <<= 2;  // 06067FDC shll2 r1
    c.r[1] += c.r[2];  // 06067FDE add r2,r1
    c.r[1] += 3;  // 06067FE0 add #3,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06067FE2 mov.b @r1,r0
    c.r[0] &= 0x7Fu;  // 06067FE4 and #127,r0
    st8(c.r[1], c.r[0]);  // 06067FE6 mov.b r0,@r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 06067FE8 mov.b @r10,r1
    c.r[2] = ld32(c.r[9]);  // 06067FEA mov.l @r9,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06067FEC extu.b r1,r1
    c.r[1] <<= 2;  // 06067FEE shll2 r1
    c.r[1] <<= 2;  // 06067FF0 shll2 r1
    c.r[1] += c.r[2];  // 06067FF2 add r2,r1
    c.r[1] += 4;  // 06067FF4 add #4,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06067FF6 mov.b @r1,r0
    c.r[0] |= 0x40u;  // 06067FF8 or #64,r0
    st8(c.r[1], c.r[0]);  // 06067FFA mov.b r0,@r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 06067FFC mov.b @r10,r1
    c.r[2] = ld32(c.r[9]);  // 06067FFE mov.l @r9,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06068000 extu.b r1,r1
    c.r[1] <<= 2;  // 06068002 shll2 r1
    c.r[1] <<= 2;  // 06068004 shll2 r1
    c.r[1] += c.r[2];  // 06068006 add r2,r1
    c.r[1] += 5;  // 06068008 add #5,r1
    st8(c.r[1], c.r[8]); goto L_0606806E;  // 0606800A bra 0x0606806E ; mov.b r8,@r1
L_06068040:
    c.r[1] = ld32(0x060681B0u);  // 06068040 mov.l 0x060681B0,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06068042 mov.b @r1,r6
    c.r[5] = ld32(0x060681B4u);  // 06068044 mov.l 0x060681B4,r5
    c.r[7] = c.r[6] & 0xFFu;  // 06068046 extu.b r6,r7
    c.r[1] = ld32(0x060681B8u);  // 06068048 mov.l 0x060681B8,r1
    c.r[3] = ld32(c.r[1]);  // 0606804A mov.l @r1,r3
    c.r[7] <<= 2;  // 0606804C shll2 r7
    c.r[7] <<= 2;  // 0606804E shll2 r7
    c.r[1] = c.r[7];  // 06068050 mov r7,r1
    c.r[1] += c.r[3];  // 06068052 add r3,r1
    c.r[1] += 1;  // 06068054 add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06068056 mov.b @r1,r2
    c.r[0] = c.r[7];  // 06068058 mov r7,r0
    c.r[2] = c.r[2] & 0xFFu;  // 0606805A extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0606805C mov.b @(r0,r3),r1
    c.r[2] <<= 2;  // 0606805E shll2 r2
    c.r[2] <<= 2;  // 06068060 shll2 r2
    c.r[2] <<= 2;  // 06068062 shll2 r2
    c.r[3] = ld32(c.r[5]);  // 06068064 mov.l @r5,r3
    c.r[1] = c.r[1] & 0xFFu;  // 06068066 extu.b r1,r1
    c.r[2] += c.r[3];  // 06068068 add r3,r2
    c.r[0] = c.r[2];  // 0606806A mov r2,r0
    st8(c.r[0] + c.r[1], c.r[6]);  // 0606806C mov.b r6,@(r0,r1)
L_0606806E:
    c.r[1] = ld32(0x060681B0u);  // 0606806E mov.l 0x060681B0,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06068070 mov.b @r1,r3
    c.r[3] = c.r[3] & 0xFFu;  // 06068072 extu.b r3,r3
    c.r[1] = ld32(0x060681B8u);  // 06068074 mov.l 0x060681B8,r1
    c.r[3] <<= 2;  // 06068076 shll2 r3
    c.r[3] <<= 2;  // 06068078 shll2 r3
    c.r[7] = ld32(c.r[1]);  // 0606807A mov.l @r1,r7
    c.r[6] = c.r[3];  // 0606807C mov r3,r6
    c.r[6] += c.r[7];  // 0606807E add r7,r6
    c.r[1] = c.r[6];  // 06068080 mov r6,r1
    c.r[1] += 1;  // 06068082 add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06068084 mov.b @r1,r2
    c.r[0] = c.r[3];  // 06068086 mov r3,r0
    c.r[2] = c.r[2] & 0xFFu;  // 06068088 extu.b r2,r2
    c.r[2] <<= 2;  // 0606808A shll2 r2
    c.r[2] <<= 2;  // 0606808C shll2 r2
    c.r[2] <<= 2;  // 0606808E shll2 r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06068090 mov.b @(r0,r7),r1
    c.r[2] += c.r[11];  // 06068092 add r11,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06068094 extu.b r1,r1
    c.r[0] = c.r[2];  // 06068096 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06068098 mov.b @(r0,r1),r1
    c.r[7] = c.r[1] & 0xFFu;  // 0606809A extu.b r1,r7
    c.r[1] = (uint32_t)(int16_t)ld16(0x060681A6u);  // 0606809C mov.w 0x060681A6,r1
    c.t = c.r[7] == c.r[1];  // 0606809E cmp/eq r1,r7
    { const bool k = c.t; c.r[6] += 2; if (k) { goto L_060680C8; } }  // 060680A0 bt/s 0x060680C8 ; add #2,r6
    c.r[1] = ld32(0x060681BCu);  // 060680A4 mov.l 0x060681BC,r1
    c.r[2] = ld32(c.r[1]);  // 060680A6 mov.l @r1,r2
    c.r[2] += 24;  // 060680A8 add #24,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 060680AA mov.w @r2,r1
    c.r[1] -= c.r[7];  // 060680AC sub r7,r1
    st16(c.r[2], c.r[1]);  // 060680AE mov.w r1,@r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[6]);  // 060680B0 mov.b @r6,r2
    c.r[1] = ld32(0x060681C0u);  // 060680B2 mov.l 0x060681C0,r1
    c.r[3] = ld32(c.r[1]);  // 060680B4 mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 060680B6 extu.b r2,r2
    c.r[1] = 0x1Eu;  // 060680B8 mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 060680BA mul.l r1,r2
    c.r[2] = c.macl;  // 060680BC sts macl,r2
    c.r[2] += c.r[3];  // 060680BE add r3,r2
    c.r[2] += 24;  // 060680C0 add #24,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 060680C2 mov.w @r2,r1
    c.r[1] -= c.r[7];  // 060680C4 sub r7,r1
    st16(c.r[2], c.r[1]);  // 060680C6 mov.w r1,@r2
L_060680C8:
    c.r[0] = (uint32_t)(int16_t)ld16(0x060681A8u);  // 060680C8 mov.w 0x060681A8,r0
    goto L_0606818E;  // 060680CA bra 0x0606818E ; nop
L_060680CE:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060680CE mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060680D0 extu.b r1,r1
    c.t = c.r[4] == c.r[1];  // 060680D2 cmp/eq r1,r4
    { const bool k = !c.t; c.r[2] = 0x4u; if (k) { goto L_060680E2; } }  // 060680D4 bf/s 0x060680E2 ; mov #4,r2
    c.r[1] = ld32(0x060681C4u);  // 060680D8 mov.l 0x060681C4,r1
    c.r[3] = c.r[1];  // 060680DA mov r1,r3
    c.r[3] += 126;  // 060680DC add #126,r3
    c.r[1] += 127; goto L_060680EC;  // 060680DE bra 0x060680EC ; add #127,r1
L_060680E2:
    c.r[1] = ld32(0x060681C4u);  // 060680E2 mov.l 0x060681C4,r1
    c.r[3] = c.r[1];  // 060680E4 mov r1,r3
    c.r[3] += 126;  // 060680E6 add #126,r3
    c.r[1] += 127;  // 060680E8 add #127,r1
    c.r[2] = 0x2u;  // 060680EA mov #2,r2
L_060680EC:
    st8(c.r[1], c.r[2]);  // 060680EC mov.b r2,@r1
    st8(c.r[3], c.r[2]);  // 060680EE mov.b r2,@r3
    c.r[6] = ld32(0x060681C4u);  // 060680F0 mov.l 0x060681C4,r6
    c.r[9] = c.r[6];  // 060680F2 mov r6,r9
    c.r[9] += 120;  // 060680F4 add #120,r9
    c.r[11] = c.r[6];  // 060680F6 mov r6,r11
    c.r[11] += 124;  // 060680F8 add #124,r11
    c.r[10] = ld32(0x060681C8u);  // 060680FA mov.l 0x060681C8,r10
    c.r[12] = ld32(0x060681CCu);  // 060680FC mov.l 0x060681CC,r12
    c.r[1] = 0x0u;  // 060680FE mov #0,r1
    st8(c.r[12], c.r[1]);  // 06068100 mov.b r1,@r12
    st8(c.r[10], c.r[1]);  // 06068102 mov.b r1,@r10
    c.r[1] = c.r[6];  // 06068104 mov r6,r1
    c.r[1] += 122;  // 06068106 add #122,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06068108 mov.b @r1,r0
    c.r[2] = 0x0u;  // 0606810A mov #0,r2
    c.r[0] &= 0xBFu;  // 0606810C and #191,r0
    st8(c.r[1], c.r[0]);  // 0606810E mov.b r0,@r1
    st16(c.r[11], c.r[2]);  // 06068110 mov.w r2,@r11
    c.r[1] = c.r[6];  // 06068112 mov r6,r1
    c.r[1] += 118;  // 06068114 add #118,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06068116 mov.b @r1,r0
    c.r[13] = ld32(0x060681D0u);  // 06068118 mov.l 0x060681D0,r13
    c.r[0] &= 0xBFu;  // 0606811A and #191,r0
    st8(c.r[1], c.r[0]);  // 0606811C mov.b r0,@r1
    st16(c.r[9], c.r[2]);  // 0606811E mov.w r2,@r9
    c.r[8] = ld32(c.r[13]);  // 06068120 mov.l @r13,r8
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06068122 mov.b @r8,r0
    c.r[0] &= 0x8u;  // 06068124 and #8,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06068126 tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[6]; if (k) { goto L_0606813C; } }  // 06068128 bt/s 0x0606813C ; mov r6,r1
    c.r[1] += 126;  // 0606812C add #126,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606812E mov.b @r1,r5
    c.r[7] = ld32(0x060681D4u);  // 06068130 mov.l 0x060681D4,r7
    { const uint32_t x = c.r[7]; c.pr = 0x06068136u; c.r[4] = 0x10u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06068136u) return; }  // 06068132 jsr @r7 ; mov #16,r4
    st16(c.r[9], c.r[0]);  // 06068136 mov.w r0,@r9
    c.r[1] = 0x1u;  // 06068138 mov #1,r1
    st8(c.r[10], c.r[1]);  // 0606813A mov.b r1,@r10
L_0606813C:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0606813C mov.b @r8,r0
    c.r[0] &= 0x4u;  // 0606813E and #4,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06068140 tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[6]; if (k) { goto L_06068156; } }  // 06068142 bt/s 0x06068156 ; mov r6,r1
    c.r[1] += 126;  // 06068146 add #126,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06068148 mov.b @r1,r5
    c.r[7] = ld32(0x060681D4u);  // 0606814A mov.l 0x060681D4,r7
    { const uint32_t x = c.r[7]; c.pr = 0x06068150u; c.r[4] = 0xFFFFFFF0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06068150u) return; }  // 0606814C jsr @r7 ; mov #-16,r4
    st16(c.r[9], c.r[0]);  // 06068150 mov.w r0,@r9
    c.r[1] = 0xFFFFFFFFu;  // 06068152 mov #-1,r1
    st8(c.r[10], c.r[1]);  // 06068154 mov.b r1,@r10
L_06068156:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06068156 mov.b @r8,r0
    c.r[0] &= 0x2u;  // 06068158 and #2,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606815A tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[6]; if (k) { goto L_06068170; } }  // 0606815C bt/s 0x06068170 ; mov r6,r1
    c.r[1] += 127;  // 06068160 add #127,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06068162 mov.b @r1,r5
    c.r[7] = ld32(0x060681D4u);  // 06068164 mov.l 0x060681D4,r7
    { const uint32_t x = c.r[7]; c.pr = 0x0606816Au; c.r[4] = 0x10u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606816Au) return; }  // 06068166 jsr @r7 ; mov #16,r4
    st16(c.r[11], c.r[0]);  // 0606816A mov.w r0,@r11
    c.r[1] = 0x1u;  // 0606816C mov #1,r1
    st8(c.r[12], c.r[1]);  // 0606816E mov.b r1,@r12
L_06068170:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06068170 mov.b @r8,r0
    c.r[0] &= 0x1u;  // 06068172 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06068174 tst r0,r0
    { const bool k = c.t; c.r[6] += 127; if (k) { goto L_06068188; } }  // 06068176 bt/s 0x06068188 ; add #127,r6
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0606817A mov.b @r6,r5
    c.r[7] = ld32(0x060681D4u);  // 0606817C mov.l 0x060681D4,r7
    { const uint32_t x = c.r[7]; c.pr = 0x06068182u; c.r[4] = 0xFFFFFFF0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06068182u) return; }  // 0606817E jsr @r7 ; mov #-16,r4
    st16(c.r[11], c.r[0]);  // 06068182 mov.w r0,@r11
    c.r[1] = 0xFFFFFFFFu;  // 06068184 mov #-1,r1
    st8(c.r[12], c.r[1]);  // 06068186 mov.b r1,@r12
L_06068188:
    c.r[8] += 1;  // 06068188 add #1,r8
    st32(c.r[13], c.r[8]);  // 0606818A mov.l r8,@r13
    c.r[0] = (uint32_t)(int16_t)ld16(0x060681AAu);  // 0606818C mov.w 0x060681AA,r0
L_0606818E:
    c.r[3] = (uint32_t)(int16_t)ld16(0x060681ACu);  // 0606818E mov.w 0x060681AC,r3
    c.r[14] += c.r[3];  // 06068190 add r3,r14
    c.r[15] = c.r[14];  // 06068192 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06068194 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06068196 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06068198 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0606819A mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0606819C mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0606819E mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060681A0 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060681A2 rts ; mov.l @r15+,r8
}

void f_060681E0(SH2Context& c) {
    ran[1511] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060681E0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060681E2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060681E4 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060681E6 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060681E8 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060681EA mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060681EC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060681EE sts.l pr,@-r15
    c.r[15] -= 12;  // 060681F0 add #-12,r15
    c.r[1] = ld32(0x06068384u);  // 060681F2 mov.l 0x06068384,r1
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060681F4 mov.b @r1,r7
    c.r[5] = ld32(0x06068388u);  // 060681F6 mov.l 0x06068388,r5
    c.r[2] = c.r[7] & 0xFFu;  // 060681F8 extu.b r7,r2
    c.r[1] = c.r[5];  // 060681FA mov r5,r1
    c.r[1] += 22;  // 060681FC add #22,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060681FE mov.w @r1,r1
    c.r[7] = c.r[7] & 0xFFu;  // 06068200 extu.b r7,r7
    c.r[2] += c.r[1];  // 06068202 add r1,r2
    c.r[2] += 1;  // 06068204 add #1,r2
    c.r[10] = c.r[2] & 0xFFFFu;  // 06068206 extu.w r2,r10
    c.r[1] = ld32(0x0606838Cu);  // 06068208 mov.l 0x0606838C,r1
    c.r[2] = c.r[10];  // 0606820A mov r10,r2
    c.r[2] += c.r[2];  // 0606820C add r2,r2
    c.r[2] += c.r[10];  // 0606820E add r10,r2
    c.r[3] = ld32(c.r[1] + 12);  // 06068210 mov.l @(12,r1),r3
    c.r[2] <<= 2;  // 06068212 shll2 r2
    c.r[1] = c.r[2];  // 06068214 mov r2,r1
    c.r[1] += c.r[3];  // 06068216 add r3,r1
    c.r[4] = ld32(c.r[1] + 4);  // 06068218 mov.l @(4,r1),r4
    c.r[0] = c.r[2];  // 0606821A mov r2,r0
    c.r[1] = ld32(0x06068390u);  // 0606821C mov.l 0x06068390,r1
    c.r[1] = ld32(c.r[1]);  // 0606821E mov.l @r1,r1
    c.r[7] <<= 2;  // 06068220 shll2 r7
    c.r[7] <<= 2;  // 06068222 shll2 r7
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 06068224 mov.w @(r0,r3),r6
    c.r[7] += c.r[1];  // 06068226 add r1,r7
    c.r[7] += 3;  // 06068228 add #3,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0606822A mov.b @r7,r1
    c.r[0] = 0x3u;  // 0606822C mov #3,r0
    c.r[1] >>= 2;  // 0606822E shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06068230 shlr r1
    c.r[1] &= c.r[0];  // 06068232 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06068234 tst r1,r1
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0606823E; } }  // 06068236 bf/s 0x0606823E ; mov r15,r14
    c.r[1] = ld32(c.r[5] + 4);  // 0606823A mov.l @(4,r5),r1
    c.r[4] -= c.r[1];  // 0606823C sub r1,r4
L_0606823E:
    c.r[4] = c.r[4] << 16 | c.r[4] >> 16;  // 0606823E swap.w r4,r4
    c.r[4] = (uint32_t)(int32_t)(int16_t)c.r[4];  // 06068240 exts.w r4,r4
    st32(c.r[14], c.r[4]);  // 06068242 mov.l r4,@r14
    c.r[3] = ld32(0x06068394u);  // 06068244 mov.l 0x06068394,r3
    c.r[1] = c.r[3];  // 06068246 mov r3,r1
    c.r[1] += 120;  // 06068248 add #120,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606824A mov.w @r1,r1
    c.t = (int32_t)c.r[1] > 0;  // 0606824C cmp/pl r1
    { const bool k = !c.t; c.r[1] = c.r[3]; if (k) { goto L_060682BC; } }  // 0606824E bf/s 0x060682BC ; mov r3,r1
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606837Au);  // 06068252 mov.w 0x0606837A,r1
    c.r[1] += c.r[6];  // 06068254 add r6,r1
    c.t = (int32_t)c.r[1] >= 0;  // 06068256 cmp/pz r1
    if (c.t) { goto L_0606825C; }  // 06068258 bt 0x0606825C
    c.r[1] += 15;  // 0606825A add #15,r1
L_0606825C:
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0606825C shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0606825E shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06068260 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06068262 shar r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606837Cu);  // 06068264 mov.w 0x0606837C,r0
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06068266 mov.b @(r0,r3),r0
    c.r[2] = c.r[1] & 0xFFu;  // 06068268 extu.b r1,r2
    c.r[0] &= 0xFu;  // 0606826A and #15,r0
    c.r[1] = 0u - c.r[0];  // 0606826C neg r0,r1
    c.r[1] += 18;  // 0606826E add #18,r1
    c.t = c.r[2] == c.r[1];  // 06068270 cmp/eq r1,r2
    if (!c.t) { goto L_06068290; }  // 06068272 bf 0x06068290
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06068274 mov.b @r3,r1
    c.r[0] = c.r[1];  // 06068276 mov r1,r0
    c.r[0] >>= 2;  // 06068278 shlr2 r0
    c.r[0] >>= 2;  // 0606827A shlr2 r0
    c.r[0] >>= 2;  // 0606827C shlr2 r0
    c.r[0] &= 0x1u;  // 0606827E and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06068280 tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_06068290; } }  // 06068282 bt/s 0x06068290 ; mov r3,r1
    c.r[1] += 118;  // 06068286 add #118,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06068288 mov.b @r1,r0
    c.r[0] |= 0x40u;  // 0606828A or #64,r0
    st8(c.r[1], c.r[0]); goto L_060682B2;  // 0606828C bra 0x060682B2 ; mov.b r0,@r1
L_06068290:
    c.r[3] = ld32(0x06068394u);  // 06068290 mov.l 0x06068394,r3
    c.r[2] = c.r[3];  // 06068292 mov r3,r2
    c.r[2] += 120;  // 06068294 add #120,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06068296 mov.w @r2,r1
    c.r[3] += 118;  // 06068298 add #118,r3
    c.r[1] -= 1;  // 0606829A add #-1,r1
    st16(c.r[2], c.r[1]);  // 0606829C mov.w r1,@r2
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0606829E mov.w @r3,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606837Eu);  // 060682A0 mov.w 0x0606837E,r1
    c.r[7] = c.r[2];  // 060682A2 mov r2,r7
    c.r[7] &= c.r[1];  // 060682A4 and r1,r7
    c.r[7] += 1;  // 060682A6 add #1,r7
    c.r[7] &= c.r[1];  // 060682A8 and r1,r7
    c.r[1] = (uint32_t)(int16_t)ld16(0x06068380u);  // 060682AA mov.w 0x06068380,r1
    c.r[2] &= c.r[1];  // 060682AC and r1,r2
    c.r[2] |= c.r[7];  // 060682AE or r7,r2
    st16(c.r[3], c.r[2]);  // 060682B0 mov.w r2,@r3
L_060682B2:
    c.r[1] = ld32(0x06068398u);  // 060682B2 mov.l 0x06068398,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060682B4 mov.b @r1,r1
    c.r[6] += c.r[1];  // 060682B6 add r1,r6
    c.r[3] = ld32(0x06068394u);  // 060682B8 mov.l 0x06068394,r3
    c.r[1] = c.r[3];  // 060682BA mov r3,r1
L_060682BC:
    c.r[1] += 120;  // 060682BC add #120,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060682BE mov.w @r1,r1
    c.t = (int32_t)c.r[1] >= 0;  // 060682C0 cmp/pz r1
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_0606832C; } }  // 060682C2 bt/s 0x0606832C ; mov r3,r1
    c.r[1] += 126;  // 060682C6 add #126,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060682C8 mov.b @r1,r1
    c.r[6] -= c.r[1];  // 060682CA sub r1,r6
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606837Au);  // 060682CC mov.w 0x0606837A,r1
    c.r[1] += c.r[6];  // 060682CE add r6,r1
    c.t = (int32_t)c.r[1] >= 0;  // 060682D0 cmp/pz r1
    if (c.t) { goto L_060682D6; }  // 060682D2 bt 0x060682D6
    c.r[1] += 15;  // 060682D4 add #15,r1
L_060682D6:
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 060682D6 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 060682D8 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 060682DA shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 060682DC shar r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606837Cu);  // 060682DE mov.w 0x0606837C,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 060682E0 mov.b @(r0,r3),r2
    c.r[1] = c.r[1] & 0xFFu;  // 060682E2 extu.b r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 060682E4 extu.b r2,r2
    c.r[2] >>= 2;  // 060682E6 shlr2 r2
    c.r[2] >>= 2;  // 060682E8 shlr2 r2
    c.t = c.r[1] == c.r[2];  // 060682EA cmp/eq r2,r1
    if (!c.t) { goto L_0606830A; }  // 060682EC bf 0x0606830A
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060682EE mov.b @r3,r1
    c.r[0] = c.r[1];  // 060682F0 mov r1,r0
    c.r[0] >>= 2;  // 060682F2 shlr2 r0
    c.r[0] >>= 2;  // 060682F4 shlr2 r0
    c.r[0] >>= 2;  // 060682F6 shlr2 r0
    c.r[0] &= 0x1u;  // 060682F8 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060682FA tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_0606830A; } }  // 060682FC bt/s 0x0606830A ; mov r3,r1
    c.r[1] += 118;  // 06068300 add #118,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06068302 mov.b @r1,r0
    c.r[0] |= 0x40u;  // 06068304 or #64,r0
    st8(c.r[1], c.r[0]); goto L_0606832C;  // 06068306 bra 0x0606832C ; mov.b r0,@r1
L_0606830A:
    c.r[3] = ld32(0x06068394u);  // 0606830A mov.l 0x06068394,r3
    c.r[2] = c.r[3];  // 0606830C mov r3,r2
    c.r[2] += 120;  // 0606830E add #120,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06068310 mov.w @r2,r1
    c.r[3] += 118;  // 06068312 add #118,r3
    c.r[1] += 1;  // 06068314 add #1,r1
    st16(c.r[2], c.r[1]);  // 06068316 mov.w r1,@r2
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06068318 mov.w @r3,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606837Eu);  // 0606831A mov.w 0x0606837E,r1
    c.r[7] = c.r[2];  // 0606831C mov r2,r7
    c.r[7] &= c.r[1];  // 0606831E and r1,r7
    c.r[7] += 1;  // 06068320 add #1,r7
    c.r[7] &= c.r[1];  // 06068322 and r1,r7
    c.r[1] = (uint32_t)(int16_t)ld16(0x06068380u);  // 06068324 mov.w 0x06068380,r1
    c.r[2] &= c.r[1];  // 06068326 and r1,r2
    c.r[2] |= c.r[7];  // 06068328 or r7,r2
    st16(c.r[3], c.r[2]);  // 0606832A mov.w r2,@r3
L_0606832C:
    c.r[3] = ld32(0x06068394u);  // 0606832C mov.l 0x06068394,r3
    c.r[1] = c.r[3];  // 0606832E mov r3,r1
    c.r[1] += 124;  // 06068330 add #124,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06068332 mov.w @r1,r1
    c.t = (int32_t)c.r[1] > 0;  // 06068334 cmp/pl r1
    { const bool k = !c.t; c.r[1] = ld32(c.r[14]); if (k) { goto L_060683C8; } }  // 06068336 bf/s 0x060683C8 ; mov.l @r14,r1
    c.r[1] += 105;  // 0606833A add #105,r1
    c.t = (int32_t)c.r[1] >= 0;  // 0606833C cmp/pz r1
    { const bool k = c.t; c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1); if (k) { goto L_06068348; } }  // 0606833E bt/s 0x06068348 ; shar r1
    c.r[1] = ld32(c.r[14]);  // 06068342 mov.l @r14,r1
    c.r[1] += 120;  // 06068344 add #120,r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06068346 shar r1
L_06068348:
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06068348 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0606834A shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0606834C shar r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06068382u);  // 0606834E mov.w 0x06068382,r0
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06068350 mov.b @(r0,r3),r0
    c.r[2] = c.r[1] & 0xFFu;  // 06068352 extu.b r1,r2
    c.r[0] &= 0xFu;  // 06068354 and #15,r0
    c.r[1] = 0u - c.r[0];  // 06068356 neg r0,r1
    c.r[1] += 12;  // 06068358 add #12,r1
    c.t = c.r[2] == c.r[1];  // 0606835A cmp/eq r1,r2
    if (!c.t) { goto L_0606839C; }  // 0606835C bf 0x0606839C
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0606835E mov.b @r3,r1
    c.r[0] = c.r[1];  // 06068360 mov r1,r0
    c.r[0] >>= 2;  // 06068362 shlr2 r0
    c.r[0] >>= 2;  // 06068364 shlr2 r0
    c.r[0] >>= 2;  // 06068366 shlr2 r0
    c.r[0] &= 0x1u;  // 06068368 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606836A tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_0606839C; } }  // 0606836C bt/s 0x0606839C ; mov r3,r1
    c.r[1] += 122;  // 06068370 add #122,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06068372 mov.b @r1,r0
    c.r[0] |= 0x40u;  // 06068374 or #64,r0
    st8(c.r[1], c.r[0]); goto L_060683BE;  // 06068376 bra 0x060683BE ; mov.b r0,@r1
L_0606839C:
    c.r[3] = ld32(0x0606849Cu);  // 0606839C mov.l 0x0606849C,r3
    c.r[2] = c.r[3];  // 0606839E mov r3,r2
    c.r[2] += 124;  // 060683A0 add #124,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 060683A2 mov.w @r2,r1
    c.r[3] += 122;  // 060683A4 add #122,r3
    c.r[1] -= 1;  // 060683A6 add #-1,r1
    st16(c.r[2], c.r[1]);  // 060683A8 mov.w r1,@r2
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 060683AA mov.w @r3,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06068494u);  // 060683AC mov.w 0x06068494,r1
    c.r[7] = c.r[2];  // 060683AE mov r2,r7
    c.r[7] &= c.r[1];  // 060683B0 and r1,r7
    c.r[7] += 1;  // 060683B2 add #1,r7
    c.r[7] &= c.r[1];  // 060683B4 and r1,r7
    c.r[1] = (uint32_t)(int16_t)ld16(0x06068496u);  // 060683B6 mov.w 0x06068496,r1
    c.r[2] &= c.r[1];  // 060683B8 and r1,r2
    c.r[2] |= c.r[7];  // 060683BA or r7,r2
    st16(c.r[3], c.r[2]);  // 060683BC mov.w r2,@r3
L_060683BE:
    c.r[1] = ld32(0x060684A0u);  // 060683BE mov.l 0x060684A0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060683C0 mov.b @r1,r1
    c.r[0] = ld32(c.r[14]);  // 060683C2 mov.l @r14,r0
    c.r[0] += c.r[1];  // 060683C4 add r1,r0
    st32(c.r[14], c.r[0]);  // 060683C6 mov.l r0,@r14
L_060683C8:
    c.r[3] = ld32(0x0606849Cu);  // 060683C8 mov.l 0x0606849C,r3
    c.r[1] = c.r[3];  // 060683CA mov r3,r1
    c.r[1] += 124;  // 060683CC add #124,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060683CE mov.w @r1,r1
    c.t = (int32_t)c.r[1] >= 0;  // 060683D0 cmp/pz r1
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_06068442; } }  // 060683D2 bt/s 0x06068442 ; mov r3,r1
    c.r[1] += 127;  // 060683D6 add #127,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060683D8 mov.b @r1,r1
    c.r[0] = ld32(c.r[14]);  // 060683DA mov.l @r14,r0
    c.r[0] -= c.r[1];  // 060683DC sub r1,r0
    c.r[1] = c.r[0];  // 060683DE mov r0,r1
    c.r[1] += 105;  // 060683E0 add #105,r1
    c.t = (int32_t)c.r[1] >= 0;  // 060683E2 cmp/pz r1
    { const bool k = c.t; st32(c.r[14], c.r[0]); if (k) { goto L_060683EC; } }  // 060683E4 bt/s 0x060683EC ; mov.l r0,@r14
    c.r[1] = c.r[0];  // 060683E8 mov r0,r1
    c.r[1] += 120;  // 060683EA add #120,r1
L_060683EC:
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 060683EC shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 060683EE shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 060683F0 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 060683F2 shar r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06068498u);  // 060683F4 mov.w 0x06068498,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 060683F6 mov.b @(r0,r3),r2
    c.r[1] = c.r[1] & 0xFFu;  // 060683F8 extu.b r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 060683FA extu.b r2,r2
    c.r[2] >>= 2;  // 060683FC shlr2 r2
    c.r[2] >>= 2;  // 060683FE shlr2 r2
    c.t = c.r[1] == c.r[2];  // 06068400 cmp/eq r2,r1
    if (!c.t) { goto L_06068420; }  // 06068402 bf 0x06068420
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06068404 mov.b @r3,r1
    c.r[0] = c.r[1];  // 06068406 mov r1,r0
    c.r[0] >>= 2;  // 06068408 shlr2 r0
    c.r[0] >>= 2;  // 0606840A shlr2 r0
    c.r[0] >>= 2;  // 0606840C shlr2 r0
    c.r[0] &= 0x1u;  // 0606840E and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06068410 tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_06068420; } }  // 06068412 bt/s 0x06068420 ; mov r3,r1
    c.r[1] += 122;  // 06068416 add #122,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06068418 mov.b @r1,r0
    c.r[0] |= 0x40u;  // 0606841A or #64,r0
    st8(c.r[1], c.r[0]); goto L_06068442;  // 0606841C bra 0x06068442 ; mov.b r0,@r1
L_06068420:
    c.r[3] = ld32(0x0606849Cu);  // 06068420 mov.l 0x0606849C,r3
    c.r[2] = c.r[3];  // 06068422 mov r3,r2
    c.r[2] += 124;  // 06068424 add #124,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06068426 mov.w @r2,r1
    c.r[3] += 122;  // 06068428 add #122,r3
    c.r[1] += 1;  // 0606842A add #1,r1
    st16(c.r[2], c.r[1]);  // 0606842C mov.w r1,@r2
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0606842E mov.w @r3,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06068494u);  // 06068430 mov.w 0x06068494,r1
    c.r[7] = c.r[2];  // 06068432 mov r2,r7
    c.r[7] &= c.r[1];  // 06068434 and r1,r7
    c.r[7] += 1;  // 06068436 add #1,r7
    c.r[7] &= c.r[1];  // 06068438 and r1,r7
    c.r[1] = (uint32_t)(int16_t)ld16(0x06068496u);  // 0606843A mov.w 0x06068496,r1
    c.r[2] &= c.r[1];  // 0606843C and r1,r2
    c.r[2] |= c.r[7];  // 0606843E or r7,r2
    st16(c.r[3], c.r[2]);  // 06068440 mov.w r2,@r3
L_06068442:
    c.r[2] = ld32(0x0606849Cu);  // 06068442 mov.l 0x0606849C,r2
    c.r[1] = c.r[2];  // 06068444 mov r2,r1
    c.r[1] += 118;  // 06068446 add #118,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06068448 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0606844A mov r1,r0
    c.r[0] >>= 2;  // 0606844C shlr2 r0
    c.r[0] >>= 2;  // 0606844E shlr2 r0
    c.r[0] >>= 2;  // 06068450 shlr2 r0
    c.r[0] &= 0x1u;  // 06068452 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06068454 tst r0,r0
    { const bool k = !c.t; c.r[2] += 122; if (k) { goto L_0606846C; } }  // 06068456 bf/s 0x0606846C ; add #122,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606845A mov.b @r2,r1
    c.r[0] = c.r[1];  // 0606845C mov r1,r0
    c.r[0] >>= 2;  // 0606845E shlr2 r0
    c.r[0] >>= 2;  // 06068460 shlr2 r0
    c.r[0] >>= 2;  // 06068462 shlr2 r0
    c.r[0] &= 0x1u;  // 06068464 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06068466 tst r0,r0
    { const bool k = c.t; c.r[13] = c.r[10]; if (k) { goto L_060684AC; } }  // 06068468 bt/s 0x060684AC ; mov r10,r13
L_0606846C:
    c.r[9] = ld32(0x060684A4u);  // 0606846C mov.l 0x060684A4,r9
    c.r[8] = c.r[10];  // 0606846E mov r10,r8
    c.r[8] += c.r[8];  // 06068470 add r8,r8
    c.r[8] += c.r[10];  // 06068472 add r10,r8
    c.r[8] <<= 2;  // 06068474 shll2 r8
    c.r[2] = ld32(c.r[9] + 12);  // 06068476 mov.l @(12,r9),r2
    c.r[1] = c.r[8];  // 06068478 mov r8,r1
    c.r[1] += c.r[2];  // 0606847A add r2,r1
    c.r[11] = ld32(c.r[1] + 4);  // 0606847C mov.l @(4,r1),r11
    c.r[0] = c.r[8];  // 0606847E mov r8,r0
    c.r[1] = ld32(0x060684A8u);  // 06068480 mov.l 0x060684A8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06068486u; c.r[10] = ld32(c.r[0] + c.r[2]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06068486u) return; }  // 06068482 jsr @r1 ; mov.l @(r0,r2),r10
    c.r[1] = ld32(c.r[9] + 12);  // 06068486 mov.l @(12,r9),r1
    c.r[0] = c.r[8];  // 06068488 mov r8,r0
    st32(c.r[0] + c.r[1], c.r[10]);  // 0606848A mov.l r10,@(r0,r1)
    c.r[1] = ld32(c.r[9] + 12);  // 0606848C mov.l @(12,r9),r1
    c.r[8] += c.r[1];  // 0606848E add r1,r8
    st32(c.r[8] + 4, c.r[11]); goto L_06068526;  // 06068490 bra 0x06068526 ; mov.l r11,@(4,r8)
L_060684AC:
    c.r[0] = ld32(0x06068588u);  // 060684AC mov.l 0x06068588,r0
    c.r[13] += c.r[13];  // 060684AE add r13,r13
    c.r[13] += c.r[10];  // 060684B0 add r10,r13
    c.r[13] <<= 2;  // 060684B2 shll2 r13
    c.r[12] = ld32(0x0606858Cu);  // 060684B4 mov.l 0x0606858C,r12
    c.r[0] = ld32(c.r[0] + 12);  // 060684B6 mov.l @(12,r0),r0
    c.r[4] = c.r[6];  // 060684B8 mov r6,r4
    { const uint32_t x = c.r[12]; c.pr = 0x060684BEu; st32(c.r[14] + 8, c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060684BEu) return; }  // 060684BA jsr @r12 ; mov.l r0,@(8,r14)
    c.r[4] = c.r[0];  // 060684BE mov r0,r4
    c.r[5] = c.r[1];  // 060684C0 mov r1,r5
    c.r[1] = ld32(0x06068590u);  // 060684C2 mov.l 0x06068590,r1
    c.r[8] = ld32(c.r[1]);  // 060684C4 mov.l @r1,r8
    c.r[9] = ld32(c.r[1] + 4);  // 060684C6 mov.l @(4,r1),r9
    c.r[11] = ld32(0x06068594u);  // 060684C8 mov.l 0x06068594,r11
    c.r[6] = c.r[8];  // 060684CA mov r8,r6
    { const uint32_t x = c.r[11]; c.pr = 0x060684D0u; c.r[7] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060684D0u) return; }  // 060684CC jsr @r11 ; mov r9,r7
    c.r[4] = c.r[0];  // 060684D0 mov r0,r4
    c.r[10] = ld32(0x06068598u);  // 060684D2 mov.l 0x06068598,r10
    { const uint32_t x = c.r[10]; c.pr = 0x060684D8u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060684D8u) return; }  // 060684D4 jsr @r10 ; mov r1,r5
    c.r[1] = c.r[0];  // 060684D8 mov r0,r1
    c.r[0] = ld32(c.r[14] + 8);  // 060684DA mov.l @(8,r14),r0
    st32(c.r[0] + c.r[13], c.r[1]);  // 060684DC mov.l r1,@(r0,r13)
    c.r[0] = ld32(0x06068588u);  // 060684DE mov.l 0x06068588,r0
    c.r[0] = ld32(c.r[0] + 12);  // 060684E0 mov.l @(12,r0),r0
    c.r[4] = ld32(c.r[14]);  // 060684E2 mov.l @r14,r4
    c.r[0] += c.r[13];  // 060684E4 add r13,r0
    { const uint32_t x = c.r[12]; c.pr = 0x060684EAu; st32(c.r[14] + 4, c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060684EAu) return; }  // 060684E6 jsr @r12 ; mov.l r0,@(4,r14)
    c.r[4] = c.r[0];  // 060684EA mov r0,r4
    c.r[5] = c.r[1];  // 060684EC mov r1,r5
    c.r[6] = c.r[8];  // 060684EE mov r8,r6
    { const uint32_t x = c.r[11]; c.pr = 0x060684F4u; c.r[7] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060684F4u) return; }  // 060684F0 jsr @r11 ; mov r9,r7
    c.r[4] = c.r[0];  // 060684F4 mov r0,r4
    { const uint32_t x = c.r[10]; c.pr = 0x060684FAu; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060684FAu) return; }  // 060684F6 jsr @r10 ; mov r1,r5
    c.r[1] = ld32(0x0606859Cu);  // 060684FA mov.l 0x0606859C,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060684FC mov.b @r1,r2
    c.r[3] = c.r[0];  // 060684FE mov r0,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06068500 extu.b r2,r2
    c.r[1] = ld32(0x060685A0u);  // 06068502 mov.l 0x060685A0,r1
    c.r[1] = ld32(c.r[1]);  // 06068504 mov.l @r1,r1
    c.r[2] <<= 2;  // 06068506 shll2 r2
    c.r[2] <<= 2;  // 06068508 shll2 r2
    c.r[2] += c.r[1];  // 0606850A add r1,r2
    c.r[2] += 3;  // 0606850C add #3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606850E mov.b @r2,r1
    c.r[0] = 0x3u;  // 06068510 mov #3,r0
    c.r[1] >>= 2;  // 06068512 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06068514 shlr r1
    c.r[1] &= c.r[0];  // 06068516 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06068518 tst r1,r1
    { const bool k = !c.t; c.r[0] = ld32(c.r[14] + 4); if (k) { goto L_06068524; } }  // 0606851A bf/s 0x06068524 ; mov.l @(4,r14),r0
    c.r[1] = ld32(0x060685A4u);  // 0606851E mov.l 0x060685A4,r1
    c.r[1] = ld32(c.r[1] + 4);  // 06068520 mov.l @(4,r1),r1
    c.r[3] += c.r[1];  // 06068522 add r1,r3
L_06068524:
    st32(c.r[0] + 4, c.r[3]);  // 06068524 mov.l r3,@(4,r0)
L_06068526:
    c.r[2] = ld32(0x060685A8u);  // 06068526 mov.l 0x060685A8,r2
    c.r[1] = c.r[2];  // 06068528 mov r2,r1
    c.r[1] += 120;  // 0606852A add #120,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606852C mov.w @r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606852E tst r1,r1
    { const bool k = !c.t; c.r[2] += 124; if (k) { goto L_0606853A; } }  // 06068530 bf/s 0x0606853A ; add #124,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06068534 mov.w @r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06068536 tst r1,r1
    if (c.t) { goto L_0606853E; }  // 06068538 bt 0x0606853E
L_0606853A:
    c.r[0] = 0x0u; goto L_06068572;  // 0606853A bra 0x06068572 ; mov #0,r0
L_0606853E:
    c.r[5] = ld32(0x0606859Cu);  // 0606853E mov.l 0x0606859C,r5
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[5]);  // 06068540 mov.b @r5,r3
    c.r[6] = ld32(0x060685A0u);  // 06068542 mov.l 0x060685A0,r6
    c.r[7] = ld32(c.r[6]);  // 06068544 mov.l @r6,r7
    c.r[2] = ld32(0x060685ACu);  // 06068546 mov.l 0x060685AC,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06068548 mov.b @r2,r2
    c.r[3] = c.r[3] & 0xFFu;  // 0606854A extu.b r3,r3
    c.r[3] <<= 2;  // 0606854C shll2 r3
    c.r[3] <<= 2;  // 0606854E shll2 r3
    c.r[0] = c.r[3];  // 06068550 mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06068552 mov.b @(r0,r7),r1
    c.r[1] += c.r[2];  // 06068554 add r2,r1
    st8(c.r[0] + c.r[7], c.r[1]);  // 06068556 mov.b r1,@(r0,r7)
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[5]);  // 06068558 mov.b @r5,r3
    c.r[1] = ld32(c.r[6]);  // 0606855A mov.l @r6,r1
    c.r[2] = ld32(0x060685B0u);  // 0606855C mov.l 0x060685B0,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606855E mov.b @r2,r2
    c.r[3] = c.r[3] & 0xFFu;  // 06068560 extu.b r3,r3
    c.r[3] <<= 2;  // 06068562 shll2 r3
    c.r[3] <<= 2;  // 06068564 shll2 r3
    c.r[3] += c.r[1];  // 06068566 add r1,r3
    c.r[3] += 1;  // 06068568 add #1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0606856A mov.b @r3,r1
    c.r[0] = ld32(0x060685B4u);  // 0606856C mov.l 0x060685B4,r0
    c.r[1] += c.r[2];  // 0606856E add r2,r1
    st8(c.r[3], c.r[1]);  // 06068570 mov.b r1,@r3
L_06068572:
    c.r[14] += 12;  // 06068572 add #12,r14
    c.r[15] = c.r[14];  // 06068574 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06068576 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06068578 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0606857A mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0606857C mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0606857E mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06068580 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06068582 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06068584 rts ; mov.l @r15+,r8
}

void f_060685B8(SH2Context& c) {
    ran[1512] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060685B8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060685BA mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060685BC sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060685BE mov r15,r14
    c.r[4] = ld32(0x06068664u);  // 060685C0 mov.l 0x06068664,r4
    c.r[8] = ld32(0x06068668u);  // 060685C2 mov.l 0x06068668,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060685C8u; c.r[5] = 0x22u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060685C8u) return; }  // 060685C4 jsr @r8 ; mov #34,r5
    c.r[5] = 0x1u;  // 060685C8 mov #1,r5
    { const uint32_t x = c.r[8]; c.pr = 0x060685CEu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060685CEu) return; }  // 060685CA jsr @r8 ; mov r0,r4
    c.r[5] = 0x3u;  // 060685CE mov #3,r5
    { const uint32_t x = c.r[8]; c.pr = 0x060685D4u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060685D4u) return; }  // 060685D0 jsr @r8 ; mov r0,r4
    c.r[1] = ld32(0x0606866Cu);  // 060685D4 mov.l 0x0606866C,r1
    c.r[1] = ld32(c.r[1]);  // 060685D6 mov.l @r1,r1
    c.r[1] -= 1;  // 060685D8 add #-1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060685DA mov.b @r1,r1
    c.r[5] = c.r[1] & 0xFFu;  // 060685DC extu.b r1,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606865Cu);  // 060685DE mov.w 0x0606865C,r1
    c.t = c.r[5] == c.r[1];  // 060685E0 cmp/eq r1,r5
    { const bool k = c.t; c.r[4] = c.r[0]; if (k) { goto L_06068650; } }  // 060685E2 bt/s 0x06068650 ; mov r0,r4
    c.r[1] = ld32(0x06068670u);  // 060685E6 mov.l 0x06068670,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060685E8 mov.b @r1,r2
    c.r[6] = ld32(0x06068674u);  // 060685EA mov.l 0x06068674,r6
    c.r[2] = c.r[2] & 0xFFu;  // 060685EC extu.b r2,r2
    c.r[1] = ld32(0x06068678u);  // 060685EE mov.l 0x06068678,r1
    c.r[7] = ld32(c.r[1]);  // 060685F0 mov.l @r1,r7
    c.r[2] <<= 2;  // 060685F2 shll2 r2
    c.r[2] <<= 2;  // 060685F4 shll2 r2
    c.r[1] = c.r[2];  // 060685F6 mov r2,r1
    c.r[1] += c.r[7];  // 060685F8 add r7,r1
    c.r[1] += 1;  // 060685FA add #1,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060685FC mov.b @r1,r3
    c.r[0] = 0x1u;  // 060685FE mov #1,r0
    c.r[3] = c.r[3] & 0xFFu;  // 06068600 extu.b r3,r3
    c.r[1] = 0x1u;  // 06068602 mov #1,r1
    c.r[1] &= c.r[5];  // 06068604 and r5,r1
    c.r[3] -= c.r[1];  // 06068606 sub r1,r3
    c.r[1] = c.r[5];  // 06068608 mov r5,r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0606860A shlr r1
    c.r[1] &= c.r[0];  // 0606860C and r0,r1
    c.r[3] += c.r[1];  // 0606860E add r1,r3
    c.r[0] = c.r[2];  // 06068610 mov r2,r0
    c.r[1] = c.r[5];  // 06068612 mov r5,r1
    c.r[1] >>= 2;  // 06068614 shlr2 r1
    c.r[5] >>= 2;  // 06068616 shlr2 r5
    c.t = c.r[5] & 1; c.r[5] >>= 1;  // 06068618 shlr r5
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0606861A mov.b @(r0,r7),r2
    c.r[3] <<= 2;  // 0606861C shll2 r3
    c.r[3] <<= 2;  // 0606861E shll2 r3
    c.r[3] <<= 2;  // 06068620 shll2 r3
    c.r[2] = c.r[2] & 0xFFu;  // 06068622 extu.b r2,r2
    c.r[0] = 0x1u;  // 06068624 mov #1,r0
    c.r[1] &= c.r[0];  // 06068626 and r0,r1
    c.r[2] -= c.r[1];  // 06068628 sub r1,r2
    c.r[5] &= c.r[0];  // 0606862A and r0,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606865Eu);  // 0606862C mov.w 0x0606865E,r1
    c.r[0] = c.r[6];  // 0606862E mov r6,r0
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 06068630 mov.l @(r0,r1),r1
    c.r[2] += c.r[5];  // 06068632 add r5,r2
    c.r[3] += c.r[1];  // 06068634 add r1,r3
    c.r[0] = c.r[3];  // 06068636 mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06068638 mov.b @(r0,r2),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606863A extu.b r1,r1
    c.r[0] = c.r[4];  // 0606863C mov r4,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606863E mov.b @(r0,r1),r1
    c.r[0] = 0x40u;  // 06068640 mov #64,r0
    c.r[1] &= c.r[0];  // 06068642 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06068644 tst r1,r1
    if (!c.t) { goto L_06068650; }  // 06068646 bf 0x06068650
    c.r[15] = c.r[14];  // 06068648 mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x06068660u);  // 0606864A mov.w 0x06068660,r0
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; } goto L_06068656;  // 0606864C bra 0x06068656 ; lds.l @r15+,pr
L_06068650:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06068662u);  // 06068650 mov.w 0x06068662,r0
    c.r[15] = c.r[14];  // 06068652 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06068654 lds.l @r15+,pr
L_06068656:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06068656 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06068658 rts ; mov.l @r15+,r8
}

void f_0606867C(SH2Context& c) {
    ran[1513] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0606867C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0606867E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06068680 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06068682 sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x060687C2u);  // 06068684 mov.w 0x060687C2,r3
    c.r[15] += c.r[3];  // 06068686 add r3,r15
    c.r[1] = ld32(0x060687CCu);  // 06068688 mov.l 0x060687CC,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606868A mov.b @r1,r3
    c.r[6] = ld32(0x060687D0u);  // 0606868C mov.l 0x060687D0,r6
    c.r[3] = c.r[3] & 0xFFu;  // 0606868E extu.b r3,r3
    c.r[1] = ld32(0x060687D4u);  // 06068690 mov.l 0x060687D4,r1
    c.r[3] <<= 2;  // 06068692 shll2 r3
    c.r[3] <<= 2;  // 06068694 shll2 r3
    c.r[7] = ld32(c.r[1]);  // 06068696 mov.l @r1,r7
    c.r[5] = c.r[3];  // 06068698 mov r3,r5
    c.r[5] += c.r[7];  // 0606869A add r7,r5
    c.r[1] = c.r[5];  // 0606869C mov r5,r1
    c.r[1] += 1;  // 0606869E add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060686A0 mov.b @r1,r2
    c.r[0] = c.r[3];  // 060686A2 mov r3,r0
    c.r[2] = c.r[2] & 0xFFu;  // 060686A4 extu.b r2,r2
    c.r[2] <<= 2;  // 060686A6 shll2 r2
    c.r[2] <<= 2;  // 060686A8 shll2 r2
    c.r[2] <<= 2;  // 060686AA shll2 r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 060686AC mov.b @(r0,r7),r1
    c.r[2] += c.r[6];  // 060686AE add r6,r2
    c.r[1] = c.r[1] & 0xFFu;  // 060686B0 extu.b r1,r1
    c.r[0] = c.r[2];  // 060686B2 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060686B4 mov.b @(r0,r1),r1
    c.r[6] = c.r[1] & 0xFFu;  // 060686B6 extu.b r1,r6
    c.r[1] = (uint32_t)(int16_t)ld16(0x060687C4u);  // 060686B8 mov.w 0x060687C4,r1
    c.t = c.r[6] == c.r[1];  // 060686BA cmp/eq r1,r6
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0606870C; } }  // 060686BC bt/s 0x0606870C ; mov r15,r14
    c.r[1] = ld32(0x060687D8u);  // 060686C0 mov.l 0x060687D8,r1
    c.r[2] = ld32(c.r[1]);  // 060686C2 mov.l @r1,r2
    c.r[2] += 24;  // 060686C4 add #24,r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[2]);  // 060686C6 mov.w @r2,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x060687C6u);  // 060686C8 mov.w 0x060687C6,r7
    c.r[1] = c.r[3] & 0xFFFFu;  // 060686CA extu.w r3,r1
    c.r[1] += c.r[6];  // 060686CC add r6,r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[7];  // 060686CE cmp/gt r7,r1
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_060686F4; } }  // 060686D0 bt/s 0x060686F4 ; mov r3,r1
    c.r[1] += c.r[6];  // 060686D4 add r6,r1
    st16(c.r[2], c.r[1]);  // 060686D6 mov.w r1,@r2
    c.r[5] += 2;  // 060686D8 add #2,r5
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[5]);  // 060686DA mov.b @r5,r2
    c.r[1] = ld32(0x060687DCu);  // 060686DC mov.l 0x060687DC,r1
    c.r[3] = ld32(c.r[1]);  // 060686DE mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 060686E0 extu.b r2,r2
    c.r[1] = 0x1Eu;  // 060686E2 mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 060686E4 mul.l r1,r2
    c.r[2] = c.macl;  // 060686E6 sts macl,r2
    c.r[2] += c.r[3];  // 060686E8 add r3,r2
    c.r[2] += 24;  // 060686EA add #24,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 060686EC mov.w @r2,r1
    c.r[6] += c.r[1];  // 060686EE add r1,r6
    st16(c.r[2], c.r[6]); goto L_0606870C;  // 060686F0 bra 0x0606870C ; mov.w r6,@r2
L_060686F4:
    st16(c.r[2], c.r[7]);  // 060686F4 mov.w r7,@r2
    c.r[5] += 2;  // 060686F6 add #2,r5
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[5]);  // 060686F8 mov.b @r5,r2
    c.r[1] = ld32(0x060687DCu);  // 060686FA mov.l 0x060687DC,r1
    c.r[3] = ld32(c.r[1]);  // 060686FC mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 060686FE extu.b r2,r2
    c.r[1] = 0x1Eu;  // 06068700 mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 06068702 mul.l r1,r2
    c.r[1] = c.macl;  // 06068704 sts macl,r1
    c.r[1] += c.r[3];  // 06068706 add r3,r1
    c.r[1] += 24;  // 06068708 add #24,r1
    st16(c.r[1], c.r[7]);  // 0606870A mov.w r7,@r1
L_0606870C:
    c.r[1] = ld32(0x060687E0u);  // 0606870C mov.l 0x060687E0,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606870E mov.b @r1,r3
    c.r[1] = ld32(0x060687E4u);  // 06068710 mov.l 0x060687E4,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06068712 mov.b @r1,r2
    c.r[6] = ld32(0x060687E8u);  // 06068714 mov.l 0x060687E8,r6
    c.r[1] = ld32(c.r[6]);  // 06068716 mov.l @r6,r1
    c.r[3] <<= 2;  // 06068718 shll2 r3
    c.r[3] <<= 2;  // 0606871A shll2 r3
    c.r[3] <<= 2;  // 0606871C shll2 r3
    c.r[3] += c.r[1];  // 0606871E add r1,r3
    c.r[0] = c.r[3];  // 06068720 mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06068722 mov.b @(r0,r2),r1
    c.r[9] = ld32(0x060687CCu);  // 06068724 mov.l 0x060687CC,r9
    c.r[5] = c.r[1] & 0xFFu;  // 06068726 extu.b r1,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06068728 mov.b @r9,r1
    c.r[8] = ld32(0x060687D4u);  // 0606872A mov.l 0x060687D4,r8
    c.r[2] = ld32(c.r[8]);  // 0606872C mov.l @r8,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0606872E extu.b r1,r1
    c.r[1] <<= 2;  // 06068730 shll2 r1
    c.r[1] <<= 2;  // 06068732 shll2 r1
    c.r[1] += c.r[2];  // 06068734 add r2,r1
    c.r[1] += 3;  // 06068736 add #3,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06068738 mov.b @r1,r2
    c.r[0] = 0x20u;  // 0606873A mov #32,r0
    c.r[2] |= c.r[0];  // 0606873C or r0,r2
    st8(c.r[1], c.r[2]);  // 0606873E mov.b r2,@r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06068740 mov.b @r9,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06068742 extu.b r1,r1
    c.t = c.r[5] == c.r[1];  // 06068744 cmp/eq r1,r5
    { const bool k = c.t; c.r[7] = 0x40u; if (k) { goto L_060687F0; } }  // 06068746 bt/s 0x060687F0 ; mov #64,r7
    c.r[6] = (uint32_t)(int16_t)ld16(0x060687C4u);  // 0606874A mov.w 0x060687C4,r6
    c.r[5] <<= 2;  // 0606874C shll2 r5
    c.r[5] <<= 2;  // 0606874E shll2 r5
    c.r[1] = ld32(c.r[8]);  // 06068750 mov.l @r8,r1
    c.r[4] = c.r[14];  // 06068752 mov r14,r4
    c.r[5] += c.r[1];  // 06068754 add r1,r5
    c.r[5] += 2;  // 06068756 add #2,r5
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[5]);  // 06068758 mov.b @r5,r5
    c.r[1] = ld32(0x060687ECu);  // 0606875A mov.l 0x060687EC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06068760u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06068760u) return; }  // 0606875C jsr @r1 ; extu.b r5,r5
    c.r[1] = ld32(0x060687D8u);  // 06068760 mov.l 0x060687D8,r1
    c.r[1] = ld32(c.r[1]);  // 06068762 mov.l @r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x060687C8u);  // 06068764 mov.w 0x060687C8,r2
    c.r[0] = c.r[1];  // 06068766 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06068768 mov.b @(r0,r2),r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0606876A shlr r1
    c.r[0] = 0xFu;  // 0606876C mov #15,r0
    c.r[1] &= c.r[0];  // 0606876E and r0,r1
    c.r[0] = c.r[1];  // 06068770 mov r1,r0
    c.t = c.r[0] == 0x9u;  // 06068772 cmp/eq #9,r0
    { const bool k = !c.t; c.r[0] = c.r[14]; if (k) { goto L_06068786; } }  // 06068774 bf/s 0x06068786 ; mov r14,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06068778 mov.b @(r0,r2),r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0606877A shlr r1
    c.r[0] = 0xFu;  // 0606877C mov #15,r0
    c.r[1] &= c.r[0];  // 0606877E and r0,r1
    c.r[0] = c.r[1];  // 06068780 mov r1,r0
    c.t = c.r[0] == 0x9u;  // 06068782 cmp/eq #9,r0
    if (c.t) { goto L_06068816; }  // 06068784 bt 0x06068816
L_06068786:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06068786 mov.b @r9,r1
    c.r[2] = ld32(c.r[8]);  // 06068788 mov.l @r8,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0606878A extu.b r1,r1
    c.r[1] <<= 2;  // 0606878C shll2 r1
    c.r[1] <<= 2;  // 0606878E shll2 r1
    c.r[1] += c.r[2];  // 06068790 add r2,r1
    c.r[1] += 3;  // 06068792 add #3,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06068794 mov.b @r1,r0
    c.r[0] |= 0x80u;  // 06068796 or #128,r0
    st8(c.r[1], c.r[0]);  // 06068798 mov.b r0,@r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0606879A mov.b @r9,r1
    c.r[2] = ld32(c.r[8]);  // 0606879C mov.l @r8,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0606879E extu.b r1,r1
    c.r[1] <<= 2;  // 060687A0 shll2 r1
    c.r[1] <<= 2;  // 060687A2 shll2 r1
    c.r[1] += c.r[2];  // 060687A4 add r2,r1
    c.r[1] += 4;  // 060687A6 add #4,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060687A8 mov.b @r1,r0
    c.r[0] &= 0xBFu;  // 060687AA and #191,r0
    st8(c.r[1], c.r[0]);  // 060687AC mov.b r0,@r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[9]);  // 060687AE mov.b @r9,r2
    c.r[1] = ld32(c.r[8]);  // 060687B0 mov.l @r8,r1
    c.r[2] = c.r[2] & 0xFFu;  // 060687B2 extu.b r2,r2
    c.r[2] <<= 2;  // 060687B4 shll2 r2
    c.r[2] <<= 2;  // 060687B6 shll2 r2
    c.r[2] += c.r[1];  // 060687B8 add r1,r2
    c.r[2] += 5;  // 060687BA add #5,r2
    c.r[1] = 0x0u;  // 060687BC mov #0,r1
    st8(c.r[2], c.r[1]); goto L_06068816;  // 060687BE bra 0x06068816 ; mov.b r1,@r2
L_060687F0:
    c.r[2] = c.r[5];  // 060687F0 mov r5,r2
    c.r[2] <<= 2;  // 060687F2 shll2 r2
    c.r[2] <<= 2;  // 060687F4 shll2 r2
    c.r[3] = ld32(c.r[8]);  // 060687F6 mov.l @r8,r3
    c.r[1] = c.r[2];  // 060687F8 mov r2,r1
    c.r[1] += c.r[3];  // 060687FA add r3,r1
    c.r[1] += 1;  // 060687FC add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060687FE mov.b @r1,r1
    c.r[0] = c.r[2];  // 06068800 mov r2,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06068802 mov.b @(r0,r3),r2
    c.r[1] = c.r[1] & 0xFFu;  // 06068804 extu.b r1,r1
    c.macl = c.r[1] * c.r[7];  // 06068806 mul.l r7,r1
    c.r[2] = c.r[2] & 0xFFu;  // 06068808 extu.b r2,r2
    c.r[3] = ld32(c.r[6]);  // 0606880A mov.l @r6,r3
    c.r[7] = c.macl;  // 0606880C sts macl,r7
    c.r[7] += c.r[3];  // 0606880E add r3,r7
    c.r[1] = 0xFFFFFFFFu;  // 06068810 mov #-1,r1
    c.r[0] = c.r[7];  // 06068812 mov r7,r0
    st8(c.r[0] + c.r[2], c.r[1]);  // 06068814 mov.b r1,@(r0,r2)
L_06068816:
    c.r[5] = ld32(0x0606888Cu);  // 06068816 mov.l 0x0606888C,r5
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[5]);  // 06068818 mov.b @r5,r2
    c.r[7] = ld32(0x06068890u);  // 0606881A mov.l 0x06068890,r7
    c.r[1] = ld32(c.r[7]);  // 0606881C mov.l @r7,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0606881E extu.b r2,r2
    c.r[2] <<= 2;  // 06068820 shll2 r2
    c.r[2] <<= 2;  // 06068822 shll2 r2
    c.r[2] += c.r[1];  // 06068824 add r1,r2
    c.r[1] = ld32(0x06068894u);  // 06068826 mov.l 0x06068894,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06068828 mov.b @r1,r1
    c.r[2] += 1;  // 0606882A add #1,r2
    st8(c.r[2], c.r[1]);  // 0606882C mov.b r1,@r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[5]);  // 0606882E mov.b @r5,r2
    c.r[3] = ld32(c.r[7]);  // 06068830 mov.l @r7,r3
    c.r[1] = ld32(0x06068898u);  // 06068832 mov.l 0x06068898,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06068834 mov.b @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 06068836 extu.b r2,r2
    c.r[2] <<= 2;  // 06068838 shll2 r2
    c.r[2] <<= 2;  // 0606883A shll2 r2
    c.r[0] = c.r[2];  // 0606883C mov r2,r0
    st8(c.r[0] + c.r[3], c.r[1]);  // 0606883E mov.b r1,@(r0,r3)
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[5]);  // 06068840 mov.b @r5,r4
    c.r[3] = ld32(c.r[7]);  // 06068842 mov.l @r7,r3
    c.r[6] = c.r[4] & 0xFFu;  // 06068844 extu.b r4,r6
    c.r[6] <<= 2;  // 06068846 shll2 r6
    c.r[6] <<= 2;  // 06068848 shll2 r6
    c.r[1] = c.r[6];  // 0606884A mov r6,r1
    c.r[1] += c.r[3];  // 0606884C add r3,r1
    c.r[1] += 1;  // 0606884E add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06068850 mov.b @r1,r2
    c.r[0] = c.r[6];  // 06068852 mov r6,r0
    c.r[2] = c.r[2] & 0xFFu;  // 06068854 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06068856 mov.b @(r0,r3),r1
    c.r[2] <<= 2;  // 06068858 shll2 r2
    c.r[2] <<= 2;  // 0606885A shll2 r2
    c.r[2] <<= 2;  // 0606885C shll2 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0606885E extu.b r1,r1
    c.r[0] = ld32(0x0606889Cu);  // 06068860 mov.l 0x0606889C,r0
    c.r[3] = ld32(c.r[0]);  // 06068862 mov.l @r0,r3
    c.r[6] = 0x0u;  // 06068864 mov #0,r6
    c.r[2] += c.r[3];  // 06068866 add r3,r2
    c.r[0] = c.r[2];  // 06068868 mov r2,r0
    st8(c.r[0] + c.r[1], c.r[4]);  // 0606886A mov.b r4,@(r0,r1)
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[5]);  // 0606886C mov.b @r5,r4
    c.r[1] = ld32(0x060688A0u);  // 0606886E mov.l 0x060688A0,r1
    c.r[4] = c.r[4] & 0xFFu;  // 06068870 extu.b r4,r4
    { const uint32_t x = c.r[1]; c.pr = 0x06068876u; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06068876u) return; }  // 06068872 jsr @r1 ; mov #0,r5
    c.r[3] = (uint32_t)(int16_t)ld16(0x06068888u);  // 06068876 mov.w 0x06068888,r3
    c.r[14] += c.r[3];  // 06068878 add r3,r14
    c.r[15] = c.r[14];  // 0606887A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0606887C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0606887E mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06068880 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606888Au);  // 06068882 mov.w 0x0606888A,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06068884 rts ; mov.l @r15+,r8
}

void f_060688A4(SH2Context& c) {
    ran[1514] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060688A4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060688A6 sts.l pr,@-r15
    c.r[1] = ld32(0x060688E4u);  // 060688A8 mov.l 0x060688E4,r1
    c.r[1] = ld32(c.r[1]);  // 060688AA mov.l @r1,r1
    c.r[1] += 1;  // 060688AC add #1,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060688AE mov.b @r1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x060688DEu);  // 060688B0 mov.w 0x060688DE,r1
    c.r[1] &= c.r[0];  // 060688B2 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060688B4 tst r1,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_060688CC; } }  // 060688B6 bt/s 0x060688CC ; mov r15,r14
    c.r[1] = ld32(0x060688E8u);  // 060688BA mov.l 0x060688E8,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060688BC mov.b @r1,r5
    c.r[0] &= 0xFu;  // 060688BE and #15,r0
    c.r[4] = c.r[0];  // 060688C0 mov r0,r4
    c.r[1] = ld32(0x060688ECu);  // 060688C2 mov.l 0x060688EC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060688C8u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060688C8u) return; }  // 060688C4 jsr @r1 ; extu.b r5,r5
    c.r[15] = c.r[14]; goto L_060688D6;  // 060688C8 bra 0x060688D6 ; mov r14,r15
L_060688CC:
    c.r[0] &= 0xFu;  // 060688CC and #15,r0
    c.r[1] = ld32(0x060688F0u);  // 060688CE mov.l 0x060688F0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060688D4u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060688D4u) return; }  // 060688D0 jsr @r1 ; mov r0,r4
    c.r[15] = c.r[14];  // 060688D4 mov r14,r15
L_060688D6:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060688D6 lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x060688E0u);  // 060688D8 mov.w 0x060688E0,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060688DA rts ; mov.l @r15+,r14
}

void f_060688F4(SH2Context& c) {
    ran[1515] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060688F4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060688F6 sts.l pr,@-r15
    c.r[1] = ld32(0x06068934u);  // 060688F8 mov.l 0x06068934,r1
    c.r[1] = ld32(c.r[1]);  // 060688FA mov.l @r1,r1
    c.r[1] += 1;  // 060688FC add #1,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060688FE mov.b @r1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606892Eu);  // 06068900 mov.w 0x0606892E,r1
    c.r[1] &= c.r[0];  // 06068902 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06068904 tst r1,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0606891C; } }  // 06068906 bt/s 0x0606891C ; mov r15,r14
    c.r[1] = ld32(0x06068938u);  // 0606890A mov.l 0x06068938,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606890C mov.b @r1,r5
    c.r[0] &= 0xFu;  // 0606890E and #15,r0
    c.r[4] = c.r[0];  // 06068910 mov r0,r4
    c.r[1] = ld32(0x0606893Cu);  // 06068912 mov.l 0x0606893C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06068918u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06068918u) return; }  // 06068914 jsr @r1 ; extu.b r5,r5
    c.r[15] = c.r[14]; goto L_06068926;  // 06068918 bra 0x06068926 ; mov r14,r15
L_0606891C:
    c.r[0] &= 0xFu;  // 0606891C and #15,r0
    c.r[1] = ld32(0x06068940u);  // 0606891E mov.l 0x06068940,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06068924u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06068924u) return; }  // 06068920 jsr @r1 ; mov r0,r4
    c.r[15] = c.r[14];  // 06068924 mov r14,r15
L_06068926:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06068926 lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x06068930u);  // 06068928 mov.w 0x06068930,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0606892A rts ; mov.l @r15+,r14
}

void f_06068944(SH2Context& c) {
    ran[1516] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06068944 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06068946 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06068948 mov r15,r14
    c.r[1] = ld32(0x06068974u);  // 0606894A mov.l 0x06068974,r1
    c.r[5] = 0x1u;  // 0606894C mov #1,r5
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606894E mov.w @r1,r1
    c.r[4] = 0x0u;  // 06068950 mov #0,r4
    c.r[0] = c.r[1];  // 06068952 mov r1,r0
    c.r[0] >>= 2;  // 06068954 shlr2 r0
    c.r[0] >>= 2;  // 06068956 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06068958 shlr r0
    c.r[0] >>= 2;  // 0606895A shlr2 r0
    c.r[0] &= 0x7u;  // 0606895C and #7,r0
    c.r[0] += 1;  // 0606895E add #1,r0
    c.r[1] = ld32(0x06068978u);  // 06068960 mov.l 0x06068978,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06068966u; c.r[6] = c.r[0] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06068966u) return; }  // 06068962 jsr @r1 ; extu.b r0,r6
    c.r[15] = c.r[14];  // 06068966 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06068968 lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x06068970u);  // 0606896A mov.w 0x06068970,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0606896C rts ; mov.l @r15+,r14
}

void f_0606897C(SH2Context& c) {
    ran[1517] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0606897C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0606897E sts.l pr,@-r15
    c.r[1] = ld32(0x0606899Cu);  // 06068980 mov.l 0x0606899C,r1
    c.r[1] = ld32(c.r[1]);  // 06068982 mov.l @r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06068984 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06068986 extu.b r1,r0
    c.r[0] <<= 2;  // 06068988 shll2 r0
    c.r[1] = ld32(0x060689A0u);  // 0606898A mov.l 0x060689A0,r1
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 0606898C mov.l @(r0,r1),r0
    { const uint32_t x = c.r[0]; c.pr = 0x06068992u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06068992u) return; }  // 0606898E jsr @r0 ; mov r15,r14
    c.r[15] = c.r[14];  // 06068992 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06068994 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06068996 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[0] & 0xFFFFu; c.pc = x; return; }  // 06068998 rts ; extu.w r0,r0
}

void f_060689A4(SH2Context& c) {
    ran[1518] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060689A4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060689A6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060689A8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060689AA mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060689AC mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060689AE mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060689B0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060689B2 sts.l pr,@-r15
    c.r[15] -= 24;  // 060689B4 add #-24,r15
    c.r[14] = c.r[15];  // 060689B6 mov r15,r14
    c.r[11] = ld32(0x06068AD8u);  // 060689B8 mov.l 0x06068AD8,r11
    c.r[12] = c.r[11];  // 060689BA mov r11,r12
    c.r[10] = 0x0u;  // 060689BC mov #0,r10
    c.r[7] = 0x3Fu;  // 060689BE mov #63,r7
    c.r[3] = (uint32_t)(int16_t)ld16(0x06068AD0u);  // 060689C0 mov.w 0x06068AD0,r3
    c.r[2] = (uint32_t)(int16_t)ld16(0x06068AD2u);  // 060689C2 mov.w 0x06068AD2,r2
    c.r[9] = 0x0u;  // 060689C4 mov #0,r9
L_060689C6:
    c.r[1] = c.r[9];  // 060689C6 mov r9,r1
    c.macl = c.r[10] * c.r[3];  // 060689C8 mul.l r3,r10
    c.r[1] += c.r[1];  // 060689CA add r1,r1
    c.r[0] = ld32(0x06068ADCu);  // 060689CC mov.l 0x06068ADC,r0
    c.r[6] = c.macl;  // 060689CE sts macl,r6
    c.r[6] += c.r[0];  // 060689D0 add r0,r6
    c.r[0] = c.r[1];  // 060689D2 mov r1,r0
    c.r[1] = c.r[9];  // 060689D4 mov r9,r1
    c.r[1] += 1;  // 060689D6 add #1,r1
    c.r[9] = c.r[1] & 0xFFu;  // 060689D8 extu.b r1,r9
    c.t = c.r[9] > c.r[7];  // 060689DA cmp/hi r7,r9
    { const bool k = !c.t; st16(c.r[0] + c.r[6], c.r[2]); if (k) { SH2_POLL(c); goto L_060689C6; } }  // 060689DC bf/s 0x060689C6 ; mov.w r2,@(r0,r6)
    c.r[1] = c.r[10];  // 060689E0 mov r10,r1
    c.r[1] += 1;  // 060689E2 add #1,r1
    c.r[10] = c.r[1] & 0xFFu;  // 060689E4 extu.b r1,r10
    c.r[1] = 0x3Fu;  // 060689E6 mov #63,r1
    c.t = c.r[10] > c.r[1];  // 060689E8 cmp/hi r1,r10
    { const bool k = !c.t; c.r[9] = 0x0u; if (k) { SH2_POLL(c); goto L_060689C6; } }  // 060689EA bf/s 0x060689C6 ; mov #0,r9
    c.r[1] = ld32(0x06068AE0u);  // 060689EE mov.l 0x06068AE0,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060689F0 mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 060689F2 extu.b r2,r2
    c.r[1] = ld32(0x06068AE4u);  // 060689F4 mov.l 0x06068AE4,r1
    c.r[2] <<= 2;  // 060689F6 shll2 r2
    c.r[2] <<= 2;  // 060689F8 shll2 r2
    c.r[3] = c.r[2];  // 060689FA mov r2,r3
    c.r[1] = ld32(c.r[1]);  // 060689FC mov.l @r1,r1
    c.r[0] = c.r[2];  // 060689FE mov r2,r0
    c.r[3] += c.r[1];  // 06068A00 add r1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06068A02 mov.b @(r0,r1),r1
    c.r[3] += 1;  // 06068A04 add #1,r3
    c.r[9] = c.r[1] & 0xFFu;  // 06068A06 extu.b r1,r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06068A08 mov.b @r3,r1
    c.r[10] = c.r[1] & 0xFFu;  // 06068A0A extu.b r1,r10
    c.r[1] = ld32(0x06068AE8u);  // 06068A0C mov.l 0x06068AE8,r1
    c.r[1] = ld32(c.r[1]);  // 06068A0E mov.l @r1,r1
    c.r[1] += 1;  // 06068A10 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06068A12 mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 06068A14 extu.b r1,r2
    c.r[1] = 0x3u;  // 06068A16 mov #3,r1
    c.r[2] -= 1;  // 06068A18 add #-1,r2
    c.t = c.r[2] > c.r[1];  // 06068A1A cmp/hi r1,r2
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_06068B00; } }  // 06068A1C bt/s 0x06068B00 ; mov r2,r1
    c.r[1] += c.r[1];  // 06068A20 add r1,r1
    c.r[0] = 0x06068A2Cu;  // 06068A22 mova 0x06068A2C,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06068A24 mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 06068A26 add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x06068A34u: goto L_06068A34; case 0x06068A66u: goto L_06068A66; case 0x06068A70u: goto L_06068A70; default: sh2_call(c, x); return; } }  // 06068A28 jmp @r0 ; nop
L_06068A34:
    c.r[1] = ld32(0x06068AECu);  // 06068A34 mov.l 0x06068AEC,r1
    c.r[3] = ld32(c.r[1]);  // 06068A36 mov.l @r1,r3
    c.r[1] = ld32(0x06068AE8u);  // 06068A38 mov.l 0x06068AE8,r1
    c.r[1] = ld32(c.r[1]);  // 06068A3A mov.l @r1,r1
    c.r[1] += 1;  // 06068A3C add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06068A3E mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06068A40 extu.b r1,r0
    c.r[1] = ld32(0x06068AF0u);  // 06068A42 mov.l 0x06068AF0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06068A44 mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06068A46 extu.b r1,r1
    c.r[2] = c.r[1];  // 06068A48 mov r1,r2
    c.r[2] <<= 2;  // 06068A4A shll2 r2
    c.r[2] += c.r[1];  // 06068A4C add r1,r2
    c.r[2] <<= 2;  // 06068A4E shll2 r2
    c.r[3] += c.r[2];  // 06068A50 add r2,r3
    c.r[1] = c.r[3];  // 06068A52 mov r3,r1
    c.r[1] += 62;  // 06068A54 add #62,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06068A56 mov.b @r1,r1
    c.r[3] += 61;  // 06068A58 add #61,r3
    c.r[1] = c.r[1] & 0xFFu;  // 06068A5A extu.b r1,r1
    st32(c.r[14], c.r[1]);  // 06068A5C mov.l r1,@r14
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06068A5E mov.b @r3,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06068A60 extu.b r1,r1
    st32(c.r[14] + 4, c.r[1]); goto L_06068BFA;  // 06068A62 bra 0x06068BFA ; mov.l r1,@(4,r14)
L_06068A66:
    c.r[13] = (uint32_t)(int16_t)ld16(0x06068AD4u);  // 06068A66 mov.w 0x06068AD4,r13
    st32(c.r[14], c.r[13]);  // 06068A68 mov.l r13,@r14
    c.r[0] = 0x1u;  // 06068A6A mov #1,r0
    st32(c.r[14] + 4, c.r[0]); goto L_06068BFA;  // 06068A6C bra 0x06068BFA ; mov.l r0,@(4,r14)
L_06068A70:
    c.r[1] = ld32(0x06068AECu);  // 06068A70 mov.l 0x06068AEC,r1
    c.r[3] = ld32(c.r[1]);  // 06068A72 mov.l @r1,r3
    c.r[1] = ld32(0x06068AF4u);  // 06068A74 mov.l 0x06068AF4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06068A76 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06068A78 extu.b r1,r1
    c.r[2] = c.r[1];  // 06068A7A mov r1,r2
    c.r[2] <<= 2;  // 06068A7C shll2 r2
    c.r[2] += c.r[1];  // 06068A7E add r1,r2
    c.r[2] <<= 2;  // 06068A80 shll2 r2
    c.r[3] += c.r[2];  // 06068A82 add r2,r3
    c.r[3] += 50;  // 06068A84 add #50,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06068A86 mov.b @r3,r1
    c.r[2] = 0x3Fu;  // 06068A88 mov #63,r2
    c.r[2] &= c.r[1];  // 06068A8A and r1,r2
    c.r[1] = ld32(0x06068AF8u);  // 06068A8C mov.l 0x06068AF8,r1
    c.r[0] = c.r[2];  // 06068A8E mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06068A90 mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06068A92 extu.b r1,r1
    c.r[0] = c.r[1];  // 06068A94 mov r1,r0
    c.t = c.r[0] == 0x3u;  // 06068A96 cmp/eq #3,r0
    { const bool k = c.t; c.r[13] = 0x2u; if (k) { goto L_06068AA0; } }  // 06068A98 bt/s 0x06068AA0 ; mov #2,r13
    c.t = c.r[0] == 0xCu;  // 06068A9C cmp/eq #12,r0
    if (!c.t) { goto L_06068B00; }  // 06068A9E bf 0x06068B00
L_06068AA0:
    c.t = c.r[0] == 0xCu;  // 06068AA0 cmp/eq #12,r0
    { const bool k = !c.t; st32(c.r[14], c.r[13]); if (k) { goto L_06068AAA; } }  // 06068AA2 bf/s 0x06068AAA ; mov.l r13,@r14
    c.r[13] = 0x3u;  // 06068AA6 mov #3,r13
    st32(c.r[14], c.r[13]);  // 06068AA8 mov.l r13,@r14
L_06068AAA:
    c.r[0] = 0x1u;  // 06068AAA mov #1,r0
    st32(c.r[14] + 4, c.r[0]);  // 06068AAC mov.l r0,@(4,r14)
    c.r[3] = ld32(0x06068AFCu);  // 06068AAE mov.l 0x06068AFC,r3
    c.r[1] = c.r[3];  // 06068AB0 mov r3,r1
    c.r[1] += 116;  // 06068AB2 add #116,r1
    c.r[2] = c.r[3];  // 06068AB4 mov r3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06068AB6 mov.b @r1,r1
    c.r[2] += 78;  // 06068AB8 add #78,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06068ABA mov.b @r2,r2
    c.r[1] += c.r[2];  // 06068ABC add r2,r1
    c.r[9] = c.r[1] & 0xFFu;  // 06068ABE extu.b r1,r9
    c.r[1] = c.r[3];  // 06068AC0 mov r3,r1
    c.r[1] += 117;  // 06068AC2 add #117,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06068AC4 mov.b @r1,r1
    c.r[3] += 79;  // 06068AC6 add #79,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06068AC8 mov.b @r3,r2
    c.r[1] += c.r[2];  // 06068ACA add r2,r1
    c.r[10] = c.r[1] & 0xFFu; goto L_06068BFA;  // 06068ACC bra 0x06068BFA ; extu.b r1,r10
L_06068B00:
    c.r[13] = (uint32_t)(int16_t)ld16(0x06068C54u);  // 06068B00 mov.w 0x06068C54,r13
    st32(c.r[14] + 4, c.r[13]);  // 06068B02 mov.l r13,@(4,r14)
    c.r[0] = 0x0u;  // 06068B04 mov #0,r0
    st32(c.r[14], c.r[0]);  // 06068B06 mov.l r0,@r14
    c.r[1] = ld32(0x06068C5Cu);  // 06068B08 mov.l 0x06068C5C,r1
    c.r[2] = ld32(c.r[1]);  // 06068B0A mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06068C56u);  // 06068B0C mov.w 0x06068C56,r1
    c.r[0] = c.r[2];  // 06068B0E mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06068B10 mov.b @(r0,r1),r1
    c.r[6] = 0x0u;  // 06068B12 mov #0,r6
    c.r[1] = c.r[1] & 0xFFu;  // 06068B14 extu.b r1,r1
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[1];  // 06068B16 cmp/ge r1,r6
    if (c.t) { goto L_06068B7A; }  // 06068B18 bt 0x06068B7A
    c.r[4] = c.r[2];  // 06068B1A mov r2,r4
    c.r[1] = ld32(0x06068C60u);  // 06068B1C mov.l 0x06068C60,r1
    c.r[8] = ld32(c.r[1]);  // 06068B1E mov.l @r1,r8
    c.r[5] = c.r[4];  // 06068B20 mov r4,r5
    c.r[7] = 0x0u;  // 06068B22 mov #0,r7
L_06068B24:
    c.r[1] = c.r[5];  // 06068B24 mov r5,r1
    c.r[1] += 1;  // 06068B26 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06068B28 mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 06068B2A extu.b r1,r2
    c.r[3] = c.r[2];  // 06068B2C mov r2,r3
    c.r[3] <<= 2;  // 06068B2E shll2 r3
    c.r[3] += c.r[2];  // 06068B30 add r2,r3
    c.r[3] <<= 2;  // 06068B32 shll2 r3
    c.r[3] += c.r[8];  // 06068B34 add r8,r3
    c.r[1] = c.r[3];  // 06068B36 mov r3,r1
    c.r[1] += 51;  // 06068B38 add #51,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06068B3A mov.b @r1,r1
    c.r[0] = c.r[1];  // 06068B3C mov r1,r0
    c.r[0] >>= 2;  // 06068B3E shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06068B40 shlr r0
    c.r[0] &= 0x1u;  // 06068B42 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06068B44 tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[3]; if (k) { goto L_06068B66; } }  // 06068B46 bf/s 0x06068B66 ; mov r3,r1
    c.r[1] += 62;  // 06068B4A add #62,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06068B4C mov.b @r1,r1
    c.r[13] = ld32(c.r[14]);  // 06068B4E mov.l @r14,r13
    c.r[1] = c.r[1] & 0xFFu;  // 06068B50 extu.b r1,r1
    c.t = c.r[1] > c.r[13];  // 06068B52 cmp/hi r13,r1
    if (!c.t) { goto L_06068B58; }  // 06068B54 bf 0x06068B58
    st32(c.r[14], c.r[1]);  // 06068B56 mov.l r1,@r14
L_06068B58:
    c.r[3] += 61;  // 06068B58 add #61,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06068B5A mov.b @r3,r1
    c.r[0] = ld32(c.r[14] + 4);  // 06068B5C mov.l @(4,r14),r0
    c.r[1] = c.r[1] & 0xFFu;  // 06068B5E extu.b r1,r1
    c.t = c.r[1] >= c.r[0];  // 06068B60 cmp/hs r0,r1
    if (c.t) { goto L_06068B66; }  // 06068B62 bt 0x06068B66
    st32(c.r[14] + 4, c.r[1]);  // 06068B64 mov.l r1,@(4,r14)
L_06068B66:
    c.r[5] += 2;  // 06068B66 add #2,r5
    c.r[1] = ld32(0x06068C5Cu);  // 06068B68 mov.l 0x06068C5C,r1
    c.r[1] = ld32(c.r[1]);  // 06068B6A mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06068C56u);  // 06068B6C mov.w 0x06068C56,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06068B6E mov.b @(r0,r1),r1
    c.r[6] += 1;  // 06068B70 add #1,r6
    c.r[1] = c.r[1] & 0xFFu;  // 06068B72 extu.b r1,r1
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[1];  // 06068B74 cmp/ge r1,r6
    { const bool k = !c.t; c.r[7] += 2; if (k) { SH2_POLL(c); goto L_06068B24; } }  // 06068B76 bf/s 0x06068B24 ; add #2,r7
L_06068B7A:
    c.r[1] = ld32(0x06068C5Cu);  // 06068B7A mov.l 0x06068C5C,r1
    c.r[2] = ld32(c.r[1]);  // 06068B7C mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06068C56u);  // 06068B7E mov.w 0x06068C56,r1
    c.r[0] = c.r[2];  // 06068B80 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06068B82 mov.b @(r0,r1),r1
    c.r[6] = 0x0u;  // 06068B84 mov #0,r6
    c.r[3] = c.r[1] & 0xFFu;  // 06068B86 extu.b r1,r3
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[3];  // 06068B88 cmp/ge r3,r6
    if (c.t) { goto L_06068BE6; }  // 06068B8A bt 0x06068BE6
    c.r[5] = c.r[2];  // 06068B8C mov r2,r5
    c.r[1] = ld32(0x06068C60u);  // 06068B8E mov.l 0x06068C60,r1
    c.r[8] = ld32(c.r[1]);  // 06068B90 mov.l @r1,r8
    c.r[4] = c.r[3];  // 06068B92 mov r3,r4
    c.r[7] = c.r[5];  // 06068B94 mov r5,r7
    c.r[3] = 0x0u;  // 06068B96 mov #0,r3
L_06068B98:
    c.r[1] = c.r[7];  // 06068B98 mov r7,r1
    c.r[1] += 1;  // 06068B9A add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06068B9C mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 06068B9E extu.b r1,r2
    c.r[1] = c.r[2];  // 06068BA0 mov r2,r1
    c.r[1] <<= 2;  // 06068BA2 shll2 r1
    c.r[1] += c.r[2];  // 06068BA4 add r2,r1
    c.r[1] <<= 2;  // 06068BA6 shll2 r1
    c.r[1] += c.r[8];  // 06068BA8 add r8,r1
    c.r[1] += 50;  // 06068BAA add #50,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06068BAC mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06068BAE extu.b r1,r0
    c.r[0] >>= 2;  // 06068BB0 shlr2 r0
    c.r[0] >>= 2;  // 06068BB2 shlr2 r0
    c.r[0] >>= 2;  // 06068BB4 shlr2 r0
    c.t = c.r[0] == 0x2u;  // 06068BB6 cmp/eq #2,r0
    { const bool k = !c.t; c.r[2] = 0x3Fu; if (k) { goto L_06068BDC; } }  // 06068BB8 bf/s 0x06068BDC ; mov #63,r2
    c.r[2] &= c.r[1];  // 06068BBC and r1,r2
    c.r[1] = ld32(0x06068C64u);  // 06068BBE mov.l 0x06068C64,r1
    c.r[0] = c.r[2];  // 06068BC0 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06068BC2 mov.b @(r0,r1),r1
    c.r[13] = c.r[1] & 0xFFu;  // 06068BC4 extu.b r1,r13
    c.r[0] = c.r[13];  // 06068BC6 mov r13,r0
    c.t = c.r[0] == 0x8u;  // 06068BC8 cmp/eq #8,r0
    { const bool k = c.t; st32(c.r[14] + 20, c.r[13]); if (k) { goto L_06068BE6; } }  // 06068BCA bt/s 0x06068BE6 ; mov.l r13,@(20,r14)
    c.r[1] -= 10;  // 06068BCE add #-10,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06068BD0 extu.b r1,r1
    c.r[2] = 0x1u;  // 06068BD2 mov #1,r2
    c.t = c.r[1] > c.r[2];  // 06068BD4 cmp/hi r2,r1
    { const bool k = !c.t; c.t = c.r[0] == 0xDu; if (k) { goto L_06068BE6; } }  // 06068BD6 bf/s 0x06068BE6 ; cmp/eq #13,r0
    if (c.t) { goto L_06068BE6; }  // 06068BDA bt 0x06068BE6
L_06068BDC:
    c.r[7] += 2;  // 06068BDC add #2,r7
    c.r[6] += 1;  // 06068BDE add #1,r6
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[4];  // 06068BE0 cmp/ge r4,r6
    { const bool k = !c.t; c.r[3] += 2; if (k) { SH2_POLL(c); goto L_06068B98; } }  // 06068BE2 bf/s 0x06068B98 ; add #2,r3
L_06068BE6:
    c.r[1] = ld32(0x06068C5Cu);  // 06068BE6 mov.l 0x06068C5C,r1
    c.r[1] = ld32(c.r[1]);  // 06068BE8 mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06068C56u);  // 06068BEA mov.w 0x06068C56,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06068BEC mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06068BEE extu.b r1,r1
    c.t = c.r[6] == c.r[1];  // 06068BF0 cmp/eq r1,r6
    { const bool k = c.t; c.r[3] = c.r[9]; if (k) { goto L_06068BFC; } }  // 06068BF2 bt/s 0x06068BFC ; mov r9,r3
    c.r[13] = (uint32_t)(int16_t)ld16(0x06068C54u);  // 06068BF6 mov.w 0x06068C54,r13
    st32(c.r[14], c.r[13]);  // 06068BF8 mov.l r13,@r14
L_06068BFA:
    c.r[3] = c.r[9];  // 06068BFA mov r9,r3
L_06068BFC:
    c.r[3] += c.r[3];  // 06068BFC add r3,r3
    c.r[2] = c.r[10];  // 06068BFE mov r10,r2
    c.r[2] <<= 2;  // 06068C00 shll2 r2
    c.r[2] <<= 2;  // 06068C02 shll2 r2
    c.r[2] += c.r[2];  // 06068C04 add r2,r2
    c.r[2] <<= 2;  // 06068C06 shll2 r2
    c.r[0] = ld32(0x06068C68u);  // 06068C08 mov.l 0x06068C68,r0
    c.r[2] += c.r[0];  // 06068C0A add r0,r2
    c.r[1] = 0x0u;  // 06068C0C mov #0,r1
    c.r[0] = c.r[3];  // 06068C0E mov r3,r0
    st16(c.r[0] + c.r[2], c.r[1]);  // 06068C10 mov.w r1,@(r0,r2)
    c.r[4] = ld32(0x06068C6Cu);  // 06068C12 mov.l 0x06068C6C,r4
    c.r[8] = ld32(0x06068C70u);  // 06068C14 mov.l 0x06068C70,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06068C1Au; c.r[5] = 0x22u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06068C1Au) return; }  // 06068C16 jsr @r8 ; mov #34,r5
    c.r[1] = c.r[0];  // 06068C1A mov r0,r1
    c.r[5] = 0x1u;  // 06068C1C mov #1,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06068C22u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06068C22u) return; }  // 06068C1E jsr @r8 ; mov r1,r4
    c.r[1] = c.r[0];  // 06068C22 mov r0,r1
    c.r[5] = 0x0u;  // 06068C24 mov #0,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06068C2Au; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06068C2Au) return; }  // 06068C26 jsr @r8 ; mov r1,r4
    st32(c.r[14] + 8, c.r[0]);  // 06068C2A mov.l r0,@(8,r14)
    c.r[8] = (uint32_t)(int16_t)ld16(0x06068C58u);  // 06068C2C mov.w 0x06068C58,r8
    c.r[6] = 0x1u;  // 06068C2E mov #1,r6
L_06068C30:
    c.r[13] = c.r[9];  // 06068C30 mov r9,r13
    c.r[13] += c.r[13];  // 06068C32 add r13,r13
    st32(c.r[14] + 12, c.r[13]);  // 06068C34 mov.l r13,@(12,r14)
    c.r[2] = c.r[6];  // 06068C36 mov r6,r2
L_06068C38:
    c.r[2] >>= 2;  // 06068C38 shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 06068C3A shlr r2
    c.r[0] = 0x1u;  // 06068C3C mov #1,r0
    c.r[2] &= c.r[0];  // 06068C3E and r0,r2
    c.r[2] += c.r[10];  // 06068C40 add r10,r2
    c.r[1] = c.r[6];  // 06068C42 mov r6,r1
    c.r[1] >>= 2;  // 06068C44 shlr2 r1
    c.r[1] &= c.r[0];  // 06068C46 and r0,r1
    c.r[2] -= c.r[1];  // 06068C48 sub r1,r2
    c.r[7] = c.r[2] & 0xFFu;  // 06068C4A extu.b r2,r7
    c.r[4] = c.r[7];  // 06068C4C mov r7,r4
    c.r[2] = 0x2u;  // 06068C4E mov #2,r2
    c.r[2] &= c.r[6]; goto L_06068C74;  // 06068C50 bra 0x06068C74 ; and r6,r2
L_06068C74:
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 06068C74 shar r2
    c.r[2] += c.r[9];  // 06068C76 add r9,r2
    c.r[1] = 0x1u;  // 06068C78 mov #1,r1
    c.r[1] &= c.r[6];  // 06068C7A and r6,r1
    c.r[2] -= c.r[1];  // 06068C7C sub r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 06068C7E extu.b r2,r2
    c.r[1] = ld32(0x06068DA4u);  // 06068C80 mov.l 0x06068DA4,r1
    c.r[1] += 76;  // 06068C82 add #76,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06068C84 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06068C86 extu.b r1,r1
    c.t = c.r[2] > c.r[1];  // 06068C88 cmp/hi r1,r2
    { const bool k = c.t; c.r[5] = c.r[2]; if (k) { goto L_06068D0C; } }  // 06068C8A bt/s 0x06068D0C ; mov r2,r5
    c.r[1] = ld32(0x06068DA4u);  // 06068C8E mov.l 0x06068DA4,r1
    c.r[1] += 77;  // 06068C90 add #77,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06068C92 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06068C94 extu.b r1,r1
    c.t = c.r[7] > c.r[1];  // 06068C96 cmp/hi r1,r7
    { const bool k = c.t; c.r[3] = c.r[7]; if (k) { goto L_06068D0C; } }  // 06068C98 bt/s 0x06068D0C ; mov r7,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x06068D9Au);  // 06068C9C mov.w 0x06068D9A,r1
    c.r[0] = ld32(0x06068DA4u);  // 06068C9E mov.l 0x06068DA4,r0
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 06068CA0 mov.l @(r0,r1),r1
    c.r[3] <<= 2;  // 06068CA2 shll2 r3
    c.r[3] <<= 2;  // 06068CA4 shll2 r3
    c.r[3] <<= 2;  // 06068CA6 shll2 r3
    c.r[3] += c.r[1];  // 06068CA8 add r1,r3
    c.r[0] = c.r[3];  // 06068CAA mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06068CAC mov.b @(r0,r2),r1
    c.r[0] = ld32(c.r[14] + 8);  // 06068CAE mov.l @(8,r14),r0
    c.r[1] = c.r[1] & 0xFFu;  // 06068CB0 extu.b r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06068CB2 mov.b @(r0,r1),r1
    c.r[3] = c.r[1] & 0xFFu;  // 06068CB4 extu.b r1,r3
    c.t = (c.r[3] & c.r[3]) == 0;  // 06068CB6 tst r3,r3
    { const bool k = !c.t; c.r[2] += c.r[2]; if (k) { goto L_06068CCC; } }  // 06068CB8 bf/s 0x06068CCC ; add r2,r2
    c.r[13] = ld32(0x06068DA8u);  // 06068CBC mov.l 0x06068DA8,r13
    c.macl = c.r[7] * c.r[8];  // 06068CBE mul.l r8,r7
    c.r[1] = 0x0u;  // 06068CC0 mov #0,r1
    c.r[0] = c.r[2];  // 06068CC2 mov r2,r0
    c.r[3] = c.macl;  // 06068CC4 sts macl,r3
    c.r[3] += c.r[13];  // 06068CC6 add r13,r3
    st16(c.r[0] + c.r[3], c.r[1]); goto L_06068D0C;  // 06068CC8 bra 0x06068D0C ; mov.w r1,@(r0,r3)
L_06068CCC:
    c.r[13] = ld32(0x06068DA8u);  // 06068CCC mov.l 0x06068DA8,r13
    c.macl = c.r[10] * c.r[8];  // 06068CCE mul.l r8,r10
    c.r[2] = 0x3u;  // 06068CD0 mov #3,r2
    c.r[0] = ld32(c.r[14] + 12);  // 06068CD2 mov.l @(12,r14),r0
    c.r[1] = c.macl;  // 06068CD4 sts macl,r1
    c.r[1] += c.r[13];  // 06068CD6 add r13,r1
    c.r[1] += c.r[0];  // 06068CD8 add r0,r1
    c.r[1] += 1;  // 06068CDA add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06068CDC mov.b @r1,r1
    c.r[2] &= c.r[3];  // 06068CDE and r3,r2
    c.r[13] = ld32(c.r[14]);  // 06068CE0 mov.l @r14,r13
    c.r[2] += c.r[1];  // 06068CE2 add r1,r2
    c.r[3] = c.r[2] & 0xFFu;  // 06068CE4 extu.b r2,r3
    c.t = c.r[3] > c.r[13];  // 06068CE6 cmp/hi r13,r3
    { const bool k = c.t; c.r[7] = c.r[5]; if (k) { goto L_06068D0C; } }  // 06068CE8 bt/s 0x06068D0C ; mov r5,r7
    c.r[7] += c.r[7];  // 06068CEC add r7,r7
    c.macl = c.r[4] * c.r[8];  // 06068CEE mul.l r8,r4
    c.r[13] = ld32(0x06068DA8u);  // 06068CF0 mov.l 0x06068DA8,r13
    c.r[2] = c.r[3] & 0xFFFFu;  // 06068CF2 extu.w r3,r2
    c.r[0] = c.macl;  // 06068CF4 sts macl,r0
    c.r[0] += c.r[13];  // 06068CF6 add r13,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[7]);  // 06068CF8 mov.w @(r0,r7),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06068CFA extu.w r1,r1
    c.t = c.r[1] > c.r[2];  // 06068CFC cmp/hi r2,r1
    { const bool k = !c.t; st32(c.r[14] + 16, c.r[0]); if (k) { goto L_06068D0C; } }  // 06068CFE bf/s 0x06068D0C ; mov.l r0,@(16,r14)
    st16(c.r[0] + c.r[7], c.r[3]);  // 06068D02 mov.w r3,@(r0,r7)
    c.r[4] <<= 8;  // 06068D04 shll8 r4
    c.r[4] |= c.r[5];  // 06068D06 or r5,r4
    st16(c.r[12], c.r[4]);  // 06068D08 mov.w r4,@r12
    c.r[12] += 2;  // 06068D0A add #2,r12
L_06068D0C:
    c.r[6] += c.r[6];  // 06068D0C add r6,r6
    c.r[1] = 0xFu;  // 06068D0E mov #15,r1
    c.t = (int32_t)c.r[6] > (int32_t)c.r[1];  // 06068D10 cmp/gt r1,r6
    { const bool k = !c.t; c.r[2] = c.r[6]; if (k) { SH2_POLL(c); goto L_06068C38; } }  // 06068D12 bf/s 0x06068C38 ; mov r6,r2
    c.r[1] = c.r[11];  // 06068D16 mov r11,r1
    c.r[1] += 1;  // 06068D18 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06068D1A mov.b @r1,r1
    c.r[9] = c.r[1] & 0xFFu;  // 06068D1C extu.b r1,r9
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[11]); c.r[11] += 2;  // 06068D1E mov.w @r11+,r1
    c.r[1] >>= 8;  // 06068D20 shlr8 r1
    c.r[10] = c.r[1] & 0xFFu;  // 06068D22 extu.b r1,r10
    c.r[1] = ld32(0x06068DACu);  // 06068D24 mov.l 0x06068DAC,r1
    c.t = c.r[12] > c.r[1];  // 06068D26 cmp/hi r1,r12
    { const bool k = !c.t; c.t = c.r[11] > c.r[1]; if (k) { goto L_06068D2E; } }  // 06068D28 bf/s 0x06068D2E ; cmp/hi r1,r11
    c.r[12] = ld32(0x06068DB0u);  // 06068D2C mov.l 0x06068DB0,r12
L_06068D2E:
    { const bool k = !c.t; c.r[1] = c.r[12]; if (k) { goto L_06068D34; } }  // 06068D2E bf/s 0x06068D34 ; mov r12,r1
    c.r[11] = ld32(0x06068DB0u);  // 06068D32 mov.l 0x06068DB0,r11
L_06068D34:
    c.r[1] += 2;  // 06068D34 add #2,r1
    c.t = c.r[11] == c.r[1];  // 06068D36 cmp/eq r1,r11
    { const bool k = c.t; c.r[6] = 0x1u; if (k) { goto L_06068D40; } }  // 06068D38 bt/s 0x06068D40 ; mov #1,r6
    SH2_POLL(c); goto L_06068C30;  // 06068D3C bra 0x06068C30 ; nop
L_06068D40:
    c.r[10] = 0x0u;  // 06068D40 mov #0,r10
    c.r[5] = (uint32_t)(int16_t)ld16(0x06068D9Cu);  // 06068D42 mov.w 0x06068D9C,r5
    c.r[0] = 0x6u;  // 06068D44 mov #6,r0
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[14]);  // 06068D46 mov.w @(r0,r14),r0
    c.r[6] = (uint32_t)(int16_t)ld16(0x06068D9Eu);  // 06068D48 mov.w 0x06068D9E,r6
    c.r[3] = 0x3Fu;  // 06068D4A mov #63,r3
    c.r[7] = c.r[0] & 0xFFFFu;  // 06068D4C extu.w r0,r7
    c.r[9] = 0x0u;  // 06068D4E mov #0,r9
L_06068D50:
    c.r[2] = c.r[9];  // 06068D50 mov r9,r2
    c.r[2] += c.r[2];  // 06068D52 add r2,r2
    c.macl = c.r[10] * c.r[5];  // 06068D54 mul.l r5,r10
    c.r[13] = ld32(0x06068DA8u);  // 06068D56 mov.l 0x06068DA8,r13
    c.r[0] = c.r[2];  // 06068D58 mov r2,r0
    c.r[4] = c.macl;  // 06068D5A sts macl,r4
    c.r[4] += c.r[13];  // 06068D5C add r13,r4
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[4]);  // 06068D5E mov.w @(r0,r4),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06068D60 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06068D62 tst r1,r1
    { const bool k = c.t; c.t = c.r[1] >= c.r[7]; if (k) { goto L_06068D6C; } }  // 06068D64 bt/s 0x06068D6C ; cmp/hs r7,r1
    if (c.t) { goto L_06068D6C; }  // 06068D68 bt 0x06068D6C
    st16(c.r[0] + c.r[4], c.r[6]);  // 06068D6A mov.w r6,@(r0,r4)
L_06068D6C:
    c.r[1] = c.r[9];  // 06068D6C mov r9,r1
    c.r[1] += 1;  // 06068D6E add #1,r1
    c.r[9] = c.r[1] & 0xFFu;  // 06068D70 extu.b r1,r9
    c.t = c.r[9] > c.r[3];  // 06068D72 cmp/hi r3,r9
    { const bool k = !c.t; c.r[1] = c.r[10]; if (k) { SH2_POLL(c); goto L_06068D50; } }  // 06068D74 bf/s 0x06068D50 ; mov r10,r1
    c.r[1] += 1;  // 06068D78 add #1,r1
    c.r[10] = c.r[1] & 0xFFu;  // 06068D7A extu.b r1,r10
    c.t = c.r[10] > c.r[3];  // 06068D7C cmp/hi r3,r10
    { const bool k = !c.t; c.r[9] = 0x0u; if (k) { SH2_POLL(c); goto L_06068D50; } }  // 06068D7E bf/s 0x06068D50 ; mov #0,r9
    c.r[14] += 24;  // 06068D82 add #24,r14
    c.r[15] = c.r[14];  // 06068D84 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06068D86 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06068D88 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06068D8A mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06068D8C mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06068D8E mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06068D90 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06068D92 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06068DA0u);  // 06068D94 mov.w 0x06068DA0,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06068D96 rts ; mov.l @r15+,r8
}

void f_06068DB4(SH2Context& c) {
    ran[1519] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06068DB4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06068DB6 mov.l r14,@-r15
    c.r[1] = ld32(0x06068E70u);  // 06068DB8 mov.l 0x06068E70,r1
    c.r[1] = ld32(c.r[1]);  // 06068DBA mov.l @r1,r1
    c.r[1] += 1;  // 06068DBC add #1,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06068DBE mov.b @r1,r0
    c.r[4] = 0xFu;  // 06068DC0 mov #15,r4
    c.r[4] &= c.r[0];  // 06068DC2 and r0,r4
    c.r[0] &= 0xF0u;  // 06068DC4 and #240,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06068DC6 tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06068E04; } }  // 06068DC8 bt/s 0x06068E04 ; mov r15,r14
    c.r[2] = ld32(0x06068E74u);  // 06068DCC mov.l 0x06068E74,r2
    c.r[1] = c.r[2];  // 06068DCE mov r2,r1
    c.r[1] += 117;  // 06068DD0 add #117,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06068DD2 mov.b @r1,r3
    c.r[6] = ld32(0x06068E78u);  // 06068DD4 mov.l 0x06068E78,r6
    c.r[1] = c.r[2];  // 06068DD6 mov r2,r1
    c.r[1] += 79;  // 06068DD8 add #79,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06068DDA mov.b @r1,r1
    c.r[3] = c.r[3] & 0xFFu;  // 06068DDC extu.b r3,r3
    c.r[3] += c.r[1];  // 06068DDE add r1,r3
    c.r[1] = c.r[2];  // 06068DE0 mov r2,r1
    c.r[1] += 116;  // 06068DE2 add #116,r1
    c.r[2] += 78;  // 06068DE4 add #78,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06068DE6 mov.b @r1,r1
    c.r[3] <<= 2;  // 06068DE8 shll2 r3
    c.r[3] <<= 2;  // 06068DEA shll2 r3
    c.r[3] <<= 2;  // 06068DEC shll2 r3
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06068DEE mov.b @r2,r7
    c.r[1] = c.r[1] & 0xFFu;  // 06068DF0 extu.b r1,r1
    c.r[2] = ld32(c.r[6]);  // 06068DF2 mov.l @r6,r2
    c.r[1] += c.r[7];  // 06068DF4 add r7,r1
    c.r[3] += c.r[2];  // 06068DF6 add r2,r3
    c.r[0] = c.r[3];  // 06068DF8 mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06068DFA mov.b @(r0,r1),r1
    c.r[5] = ld32(0x06068E7Cu);  // 06068DFC mov.l 0x06068E7C,r5
    c.r[0] = c.r[4];  // 06068DFE mov r4,r0
    st8(c.r[0] + c.r[5], c.r[1]); goto L_06068E0E;  // 06068E00 bra 0x06068E0E ; mov.b r1,@(r0,r5)
L_06068E04:
    c.r[1] = ld32(0x06068E7Cu);  // 06068E04 mov.l 0x06068E7C,r1
    c.r[2] = ld32(0x06068E80u);  // 06068E06 mov.l 0x06068E80,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06068E08 mov.b @r2,r2
    c.r[0] = c.r[4];  // 06068E0A mov r4,r0
    st8(c.r[0] + c.r[1], c.r[2]);  // 06068E0C mov.b r2,@(r0,r1)
L_06068E0E:
    c.r[1] = ld32(0x06068E7Cu);  // 06068E0E mov.l 0x06068E7C,r1
    c.r[0] = c.r[4];  // 06068E10 mov r4,r0
    c.r[8] = c.r[4];  // 06068E12 mov r4,r8
    c.r[8] += c.r[8];  // 06068E14 add r8,r8
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06068E16 mov.b @(r0,r1),r7
    c.r[6] = 0x1Eu;  // 06068E18 mov #30,r6
    c.r[7] = c.r[7] & 0xFFu;  // 06068E1A extu.b r7,r7
    c.r[1] = ld32(0x06068E84u);  // 06068E1C mov.l 0x06068E84,r1
    c.r[1] = ld32(c.r[1]);  // 06068E1E mov.l @r1,r1
    c.r[7] <<= 2;  // 06068E20 shll2 r7
    c.r[7] <<= 2;  // 06068E22 shll2 r7
    c.r[7] += c.r[1];  // 06068E24 add r1,r7
    c.r[7] += 2;  // 06068E26 add #2,r7
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06068E28 mov.b @r7,r2
    c.r[1] = ld32(0x06068E88u);  // 06068E2A mov.l 0x06068E88,r1
    c.r[2] = c.r[2] & 0xFFu;  // 06068E2C extu.b r2,r2
    c.macl = c.r[2] * c.r[6];  // 06068E2E mul.l r6,r2
    c.r[5] = ld32(c.r[1]);  // 06068E30 mov.l @r1,r5
    c.r[1] = c.macl;  // 06068E32 sts macl,r1
    c.r[1] += c.r[5];  // 06068E34 add r5,r1
    c.r[1] += 15;  // 06068E36 add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06068E38 mov.b @r1,r1
    c.r[2] = ld32(0x06068E8Cu);  // 06068E3A mov.l 0x06068E8C,r2
    c.r[3] = ld32(c.r[2]);  // 06068E3C mov.l @r2,r3
    c.r[1] = c.r[1] & 0xFFu;  // 06068E3E extu.b r1,r1
    c.r[2] = c.r[1];  // 06068E40 mov r1,r2
    c.r[2] += c.r[2];  // 06068E42 add r2,r2
    c.r[2] += c.r[1];  // 06068E44 add r1,r2
    c.r[2] <<= 2;  // 06068E46 shll2 r2
    c.r[0] = c.r[2];  // 06068E48 mov r2,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 06068E4A mov.w @(r0,r3),r1
    c.r[4] = ld32(0x06068E90u);  // 06068E4C mov.l 0x06068E90,r4
    c.r[0] = c.r[8];  // 06068E4E mov r8,r0
    st16(c.r[0] + c.r[4], c.r[1]);  // 06068E50 mov.w r1,@(r0,r4)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06068E52 mov.b @r7,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06068E54 extu.b r1,r1
    c.macl = c.r[1] * c.r[6];  // 06068E56 mul.l r6,r1
    c.r[15] = c.r[14];  // 06068E58 mov r14,r15
    c.r[1] = c.macl;  // 06068E5A sts macl,r1
    c.r[0] = c.r[1];  // 06068E5C mov r1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[5]);  // 06068E5E mov.w @(r0,r5),r1
    c.r[2] = ld32(0x06068E94u);  // 06068E60 mov.l 0x06068E94,r2
    c.r[0] = c.r[8];  // 06068E62 mov r8,r0
    st16(c.r[0] + c.r[2], c.r[1]);  // 06068E64 mov.w r1,@(r0,r2)
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06068E66 mov.l @r15+,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x06068E6Eu);  // 06068E68 mov.w 0x06068E6E,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06068E6A rts ; mov.l @r15+,r8
}

void f_06068E98(SH2Context& c) {
    ran[1520] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06068E98 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06068E9A mov.l r14,@-r15
    c.r[1] = ld32(0x06068F0Cu);  // 06068E9C mov.l 0x06068F0C,r1
    c.r[2] = ld32(c.r[1]);  // 06068E9E mov.l @r1,r2
    c.r[1] = c.r[2];  // 06068EA0 mov r2,r1
    c.r[1] += 5;  // 06068EA2 add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06068EA4 mov.b @r1,r1
    c.r[2] += 4;  // 06068EA6 add #4,r2
    c.r[5] = c.r[1] & 0xFFu;  // 06068EA8 extu.b r1,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06068EAA mov.b @r2,r1
    c.r[6] = c.r[1] & 0xFFu;  // 06068EAC extu.b r1,r6
    c.r[1] = ld32(0x06068F10u);  // 06068EAE mov.l 0x06068F10,r1
    c.r[1] = ld32(c.r[1]);  // 06068EB0 mov.l @r1,r1
    c.r[1] += 1;  // 06068EB2 add #1,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06068EB4 mov.b @r1,r3
    c.r[2] = 0x1u;  // 06068EB6 mov #1,r2
    c.r[1] = c.r[3];  // 06068EB8 mov r3,r1
    c.r[1] += 4;  // 06068EBA add #4,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06068EBC extu.b r1,r1
    c.t = c.r[1] > c.r[2];  // 06068EBE cmp/hi r2,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06068ECA; } }  // 06068EC0 bt/s 0x06068ECA ; mov r15,r14
    c.r[1] = ld32(0x06068F14u);  // 06068EC4 mov.l 0x06068F14,r1
    st8(c.r[1], c.r[3]); goto L_06068EFE;  // 06068EC6 bra 0x06068EFE ; mov.b r3,@r1
L_06068ECA:
    c.r[4] = c.r[3] & 0xFFu;  // 06068ECA extu.b r3,r4
    c.r[1] = ld32(0x06068F18u);  // 06068ECC mov.l 0x06068F18,r1
    c.r[3] = ld32(c.r[1]);  // 06068ECE mov.l @r1,r3
    c.r[1] = ld32(0x06068F1Cu);  // 06068ED0 mov.l 0x06068F1C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06068ED2 mov.b @r1,r1
    c.r[8] = c.r[1] & 0xFFu;  // 06068ED4 extu.b r1,r8
    c.r[1] = ld32(0x06068F20u);  // 06068ED6 mov.l 0x06068F20,r1
    c.r[0] = c.r[8];  // 06068ED8 mov r8,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06068EDA mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06068EDC extu.b r1,r1
    c.r[1] -= 1;  // 06068EDE add #-1,r1
    c.macl = c.r[1] * c.r[5];  // 06068EE0 mul.l r5,r1
    c.r[1] = c.macl;  // 06068EE2 sts macl,r1
    c.macl = c.r[1] * c.r[6];  // 06068EE4 mul.l r6,r1
    c.r[7] = ld32(0x06068F24u);  // 06068EE6 mov.l 0x06068F24,r7
    c.r[1] = ld32(0x06068F28u);  // 06068EE8 mov.l 0x06068F28,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06068EEA mov.b @(r0,r1),r1
    c.r[2] = c.macl;  // 06068EEC sts macl,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06068EEE extu.b r1,r1
    c.r[2] += c.r[1];  // 06068EF0 add r1,r2
    c.r[2] += c.r[2];  // 06068EF2 add r2,r2
    c.r[3] += c.r[2];  // 06068EF4 add r2,r3
    c.r[3] += 1;  // 06068EF6 add #1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06068EF8 mov.b @r3,r1
    c.r[0] = c.r[4];  // 06068EFA mov r4,r0
    st8(c.r[0] + c.r[7], c.r[1]);  // 06068EFC mov.b r1,@(r0,r7)
L_06068EFE:
    c.r[15] = c.r[14];  // 06068EFE mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06068F00 mov.l @r15+,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x06068F08u);  // 06068F02 mov.w 0x06068F08,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06068F04 rts ; mov.l @r15+,r8
}

void f_06068F2C(SH2Context& c) {
    ran[1521] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06068F2C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06068F2E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06068F30 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06068F32 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06068F34 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06068F36 sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x0606900Au);  // 06068F38 mov.w 0x0606900A,r3
    c.r[15] += c.r[3];  // 06068F3A add r3,r15
    c.r[14] = c.r[15];  // 06068F3C mov r15,r14
    c.r[9] = ld32(0x06069010u);  // 06068F3E mov.l 0x06069010,r9
    c.r[10] = ld32(0x06069014u);  // 06068F40 mov.l 0x06069014,r10
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06068F42 mov.b @r9,r6
    c.r[4] = c.r[14];  // 06068F44 mov r14,r4
    c.r[1] = ld32(c.r[10]);  // 06068F46 mov.l @r10,r1
    c.r[6] = c.r[6] & 0xFFu;  // 06068F48 extu.b r6,r6
    c.r[2] = c.r[6];  // 06068F4A mov r6,r2
    c.r[2] <<= 2;  // 06068F4C shll2 r2
    c.r[2] <<= 2;  // 06068F4E shll2 r2
    c.r[2] += c.r[1];  // 06068F50 add r1,r2
    c.r[2] += 2;  // 06068F52 add #2,r2
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06068F54 mov.b @r2,r5
    c.r[1] = ld32(0x06069018u);  // 06068F56 mov.l 0x06069018,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06068F5Cu; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06068F5Cu) return; }  // 06068F58 jsr @r1 ; extu.b r5,r5
    c.r[8] = ld32(0x0606901Cu);  // 06068F5C mov.l 0x0606901C,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06068F5E mov.b @r8,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06068F60 extu.b r1,r1
    c.r[0] = c.r[1];  // 06068F62 mov r1,r0
    c.r[0] <<= 2;  // 06068F64 shll2 r0
    c.r[0] += c.r[1];  // 06068F66 add r1,r0
    c.r[0] <<= 2;  // 06068F68 shll2 r0
    c.r[1] = c.r[14];  // 06068F6A mov r14,r1
    c.r[1] += 50;  // 06068F6C add #50,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06068F6E mov.b @(r0,r1),r1
    c.r[0] = c.r[1] & 0xFFu;  // 06068F70 extu.b r1,r0
    c.r[0] >>= 2;  // 06068F72 shlr2 r0
    c.r[0] >>= 2;  // 06068F74 shlr2 r0
    c.r[0] >>= 2;  // 06068F76 shlr2 r0
    c.t = c.r[0] == 0x2u;  // 06068F78 cmp/eq #2,r0
    { const bool k = !c.t; c.r[1] = c.r[9]; if (k) { goto L_06068F86; } }  // 06068F7A bf/s 0x06068F86 ; mov r9,r1
    c.r[2] = ld32(0x06069020u);  // 06068F7E mov.l 0x06069020,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06068F80 mov.b @r2,r2
    c.r[1] += 1;  // 06068F82 add #1,r1
    st8(c.r[1], c.r[2]);  // 06068F84 mov.b r2,@r1
L_06068F86:
    c.r[1] = c.r[9];  // 06068F86 mov r9,r1
    c.r[1] += 1;  // 06068F88 add #1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06068F8A mov.b @r1,r4
    c.r[0] = ld32(0x06069024u);  // 06068F8C mov.l 0x06069024,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06068F92u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06068F92u) return; }  // 06068F8E jsr @r0 ; extu.b r4,r4
    c.r[1] = c.r[0] & 0xFFFFu;  // 06068F92 extu.w r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06068F94 tst r1,r1
    if (!c.t) { goto L_06068FA4; }  // 06068F96 bf 0x06068FA4
    c.r[8] += 1;  // 06068F98 add #1,r8
    c.r[1] = 0xFFFFFFFBu;  // 06068F9A mov #-5,r1
    st8(c.r[8], c.r[1]);  // 06068F9C mov.b r1,@r8
    c.r[2] = ld32(0x06069028u);  // 06068F9E mov.l 0x06069028,r2
    c.r[1] = 0x2u; goto L_0606925E;  // 06068FA0 bra 0x0606925E ; mov #2,r1
L_06068FA4:
    c.r[1] = c.r[14];  // 06068FA4 mov r14,r1
    c.r[1] += 14;  // 06068FA6 add #14,r1
    c.r[4] = (uint32_t)(int16_t)ld16(0x0606900Cu);  // 06068FA8 mov.w 0x0606900C,r4
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06068FAA mov.b @r1,r5
    c.r[4] += c.r[14];  // 06068FAC add r14,r4
    c.r[1] = ld32(0x0606902Cu);  // 06068FAE mov.l 0x0606902C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06068FB4u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06068FB4u) return; }  // 06068FB0 jsr @r1 ; extu.b r5,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06068FB4 mov.b @r9,r1
    c.r[6] = ld32(c.r[10]);  // 06068FB6 mov.l @r10,r6
    c.r[7] = c.r[1] & 0xFFu;  // 06068FB8 extu.b r1,r7
    c.r[7] <<= 2;  // 06068FBA shll2 r7
    c.r[7] <<= 2;  // 06068FBC shll2 r7
    c.r[2] = c.r[7];  // 06068FBE mov r7,r2
    c.r[2] += c.r[6];  // 06068FC0 add r6,r2
    c.r[1] = c.r[2];  // 06068FC2 mov r2,r1
    c.r[1] += 11;  // 06068FC4 add #11,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06068FC6 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06068FC8 extu.b r1,r1
    c.r[1] >>= 2;  // 06068FCA shlr2 r1
    c.r[1] >>= 2;  // 06068FCC shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06068FCE shlr r1
    c.r[1] >>= 2;  // 06068FD0 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06068FD2 tst r1,r1
    { const bool k = c.t; c.r[2] += 1; if (k) { goto L_06068FDC; } }  // 06068FD4 bt/s 0x06068FDC ; add #1,r2
    goto L_0606921E;  // 06068FD8 bra 0x0606921E ; nop
L_06068FDC:
    c.r[3] = ld32(0x06069030u);  // 06068FDC mov.l 0x06069030,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06068FDE mov.b @r2,r1
    c.r[0] = c.r[7];  // 06068FE0 mov r7,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 06068FE2 mov.b @(r0,r6),r2
    c.r[1] = c.r[1] & 0xFFu;  // 06068FE4 extu.b r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 06068FE6 extu.b r2,r2
    c.r[2] += c.r[2];  // 06068FE8 add r2,r2
    c.r[1] <<= 2;  // 06068FEA shll2 r1
    c.r[1] <<= 2;  // 06068FEC shll2 r1
    c.r[1] += c.r[1];  // 06068FEE add r1,r1
    c.r[1] <<= 2;  // 06068FF0 shll2 r1
    c.r[1] += c.r[3];  // 06068FF2 add r3,r1
    c.r[2] += c.r[1];  // 06068FF4 add r1,r2
    c.r[2] += 1;  // 06068FF6 add #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06068FF8 mov.b @r2,r1
    c.r[3] = ld32(0x06069034u);  // 06068FFA mov.l 0x06069034,r3
    c.r[6] = c.r[1] & 0xFFu;  // 06068FFC extu.b r1,r6
    c.r[2] = ld32(c.r[3]);  // 06068FFE mov.l @r3,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606900Eu);  // 06069000 mov.w 0x0606900E,r1
    c.r[0] = c.r[2];  // 06069002 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06069004 mov.b @(r0,r1),r1
    c.r[7] = 0x0u; goto L_0606907E;  // 06069006 bra 0x0606907E ; mov #0,r7
L_06069038:
    c.r[2] = ld32(c.r[3]);  // 06069038 mov.l @r3,r2
    c.r[1] += c.r[1];  // 0606903A add r1,r1
    c.r[2] += c.r[1];  // 0606903C add r1,r2
    c.r[2] += 1;  // 0606903E add #1,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06069040 mov.b @r2,r2
    c.r[1] = ld32(0x06069148u);  // 06069042 mov.l 0x06069148,r1
    c.r[3] = ld32(c.r[1]);  // 06069044 mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06069046 extu.b r2,r2
    c.r[1] = c.r[2];  // 06069048 mov r2,r1
    c.r[1] <<= 2;  // 0606904A shll2 r1
    c.r[1] += c.r[2];  // 0606904C add r2,r1
    c.r[1] <<= 2;  // 0606904E shll2 r1
    c.r[3] += c.r[1];  // 06069050 add r1,r3
    c.r[1] = c.r[3];  // 06069052 mov r3,r1
    c.r[1] += 61;  // 06069054 add #61,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06069056 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06069058 extu.b r1,r1
    c.t = c.r[6] >= c.r[1];  // 0606905A cmp/hs r1,r6
    { const bool k = !c.t; c.r[1] = c.r[3]; if (k) { goto L_0606906A; } }  // 0606905C bf/s 0x0606906A ; mov r3,r1
    c.r[1] += 62;  // 06069060 add #62,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06069062 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06069064 extu.b r1,r1
    c.t = c.r[6] > c.r[1];  // 06069066 cmp/hi r1,r6
    if (!c.t) { goto L_06069074; }  // 06069068 bf 0x06069074
L_0606906A:
    c.r[1] = c.r[3];  // 0606906A mov r3,r1
    c.r[1] += 51;  // 0606906C add #51,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606906E mov.b @r1,r0
    c.r[0] |= 0x8u;  // 06069070 or #8,r0
    st8(c.r[1], c.r[0]);  // 06069072 mov.b r0,@r1
L_06069074:
    c.r[3] = ld32(0x0606914Cu);  // 06069074 mov.l 0x0606914C,r3
    c.r[1] = ld32(c.r[3]);  // 06069076 mov.l @r3,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06069144u);  // 06069078 mov.w 0x06069144,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606907A mov.b @(r0,r1),r1
    c.r[7] += 1;  // 0606907C add #1,r7
L_0606907E:
    c.r[1] = c.r[1] & 0xFFu;  // 0606907E extu.b r1,r1
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[1];  // 06069080 cmp/ge r1,r7
    { const bool k = !c.t; c.r[1] = c.r[7]; if (k) { SH2_POLL(c); goto L_06069038; } }  // 06069082 bf/s 0x06069038 ; mov r7,r1
    c.r[9] = ld32(0x06069150u);  // 06069086 mov.l 0x06069150,r9
    c.r[11] = c.r[9];  // 06069088 mov r9,r11
    c.r[11] += 1;  // 0606908A add #1,r11
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[11]);  // 0606908C mov.b @r11,r1
    c.r[3] = 0x1u;  // 0606908E mov #1,r3
    c.r[5] = c.r[1] & 0xFFu;  // 06069090 extu.b r1,r5
    c.r[1] = ld32(0x06069154u);  // 06069092 mov.l 0x06069154,r1
    c.r[2] = c.r[5];  // 06069094 mov r5,r2
    c.r[1] = ld32(c.r[1]);  // 06069096 mov.l @r1,r1
    c.r[2] <<= 2;  // 06069098 shll2 r2
    c.r[2] <<= 2;  // 0606909A shll2 r2
    c.r[2] += c.r[1];  // 0606909C add r1,r2
    c.r[1] = c.r[2];  // 0606909E mov r2,r1
    c.r[1] += 3;  // 060690A0 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060690A2 mov.b @r1,r1
    c.r[2] += 4;  // 060690A4 add #4,r2
    c.r[3] &= c.r[1];  // 060690A6 and r1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060690A8 mov.b @r2,r1
    c.r[3] += c.r[3];  // 060690AA add r3,r3
    c.r[2] = c.r[1] & 0xFFu;  // 060690AC extu.b r1,r2
    c.r[2] >>= 2;  // 060690AE shlr2 r2
    c.r[2] >>= 2;  // 060690B0 shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 060690B2 shlr r2
    c.r[2] >>= 2;  // 060690B4 shlr2 r2
    c.r[2] |= c.r[3];  // 060690B6 or r3,r2
    c.r[0] = c.r[2];  // 060690B8 mov r2,r0
    c.t = c.r[0] == 0x2u;  // 060690BA cmp/eq #2,r0
    { const bool k = c.t; c.r[1] = 0x2u; if (k) { goto L_0606916C; } }  // 060690BC bt/s 0x0606916C ; mov #2,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 060690C0 cmp/gt r1,r2
    { const bool k = c.t; c.t = c.r[0] == 0x3u; if (k) { goto L_060690D4; } }  // 060690C2 bt/s 0x060690D4 ; cmp/eq #3,r0
    c.t = c.r[0] == 0x1u;  // 060690C6 cmp/eq #1,r0
    if (c.t) { goto L_060690CE; }  // 060690C8 bt 0x060690CE
    goto L_0606920A;  // 060690CA bra 0x0606920A ; nop
L_060690CE:
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[9]);  // 060690CE mov.b @r9,r4
    goto L_060690E0;  // 060690D0 bra 0x060690E0 ; nop
L_060690D4:
    if (c.t) { goto L_060690DA; }  // 060690D4 bt 0x060690DA
    goto L_0606920A;  // 060690D6 bra 0x0606920A ; nop
L_060690DA:
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[9]);  // 060690DA mov.b @r9,r4
    goto L_060691FA;  // 060690DC bra 0x060691FA ; nop
L_060690E0:
    c.r[8] = ld32(0x06069158u);  // 060690E0 mov.l 0x06069158,r8
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[8]);  // 060690E2 mov.b @r8,r6
    c.r[0] = ld32(0x0606915Cu);  // 060690E4 mov.l 0x0606915C,r0
    c.r[6] = c.r[6] & 0xFFu;  // 060690E6 extu.b r6,r6
    { const uint32_t x = c.r[0]; c.pr = 0x060690ECu; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060690ECu) return; }  // 060690E8 jsr @r0 ; extu.b r4,r4
    c.r[1] = c.r[0] & 0xFFu;  // 060690EC extu.b r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060690EE tst r1,r1
    if (c.t) { goto L_0606911E; }  // 060690F0 bt 0x0606911E
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[8]);  // 060690F2 mov.b @r8,r6
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[11]);  // 060690F4 mov.b @r11,r5
    c.r[0] = ld32(0x06069160u);  // 060690F6 mov.l 0x06069160,r0
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[9]);  // 060690F8 mov.b @r9,r4
    c.r[6] = c.r[6] & 0xFFu;  // 060690FA extu.b r6,r6
    c.r[5] = c.r[5] & 0xFFu;  // 060690FC extu.b r5,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06069102u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06069102u) return; }  // 060690FE jsr @r0 ; extu.b r4,r4
    c.r[1] = ld32(0x06069148u);  // 06069102 mov.l 0x06069148,r1
    c.r[1] = ld32(c.r[1]);  // 06069104 mov.l @r1,r1
    c.r[1] += 22;  // 06069106 add #22,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06069108 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0606910A extu.w r1,r1
    c.t = c.r[0] >= c.r[1];  // 0606910C cmp/hs r1,r0
    if (!c.t) { goto L_0606911E; }  // 0606910E bf 0x0606911E
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[8]); c.r[8] += 1;  // 06069110 mov.b @r8+,r6
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[11]);  // 06069112 mov.b @r11,r5
    c.r[0] = ld32(0x06069164u);  // 06069114 mov.l 0x06069164,r0
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06069116 mov.b @r9,r4
    c.r[6] = c.r[6] & 0xFFu;  // 06069118 extu.b r6,r6
    c.r[5] = c.r[5] & 0xFFu; goto L_06069202;  // 0606911A bra 0x06069202 ; extu.b r5,r5
L_0606911E:
    c.r[9] = ld32(0x06069150u);  // 0606911E mov.l 0x06069150,r9
    c.r[8] = c.r[9];  // 06069120 mov r9,r8
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[8]); c.r[8] += 1;  // 06069122 mov.b @r8+,r5
    c.r[0] = ld32(0x06069168u);  // 06069124 mov.l 0x06069168,r0
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06069126 mov.b @r8,r4
    c.r[5] = c.r[5] & 0xFFu;  // 06069128 extu.b r5,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0606912Eu; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606912Eu) return; }  // 0606912A jsr @r0 ; extu.b r4,r4
    c.r[6] = ld32(0x06069158u);  // 0606912E mov.l 0x06069158,r6
    c.r[10] = c.r[6];  // 06069130 mov r6,r10
    c.r[10] += 1;  // 06069132 add #1,r10
    c.r[2] = c.r[0] & 0xFFu;  // 06069134 extu.b r0,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06069146u);  // 06069136 mov.w 0x06069146,r1
    c.t = c.r[2] == c.r[1];  // 06069138 cmp/eq r1,r2
    { const bool k = !c.t; st8(c.r[10], c.r[0]); if (k) { goto L_06069224; } }  // 0606913A bf/s 0x06069224 ; mov.b r0,@r10
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0606913E mov.b @r6,r6
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[8]); goto L_060691EA;  // 06069140 bra 0x060691EA ; mov.b @r8,r5
L_0606916C:
    c.r[8] = ld32(0x06069280u);  // 0606916C mov.l 0x06069280,r8
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0606916E mov.b @r8,r6
    c.r[0] = ld32(0x06069284u);  // 06069170 mov.l 0x06069284,r0
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06069172 mov.b @r9,r4
    c.r[6] = c.r[6] & 0xFFu;  // 06069174 extu.b r6,r6
    { const uint32_t x = c.r[0]; c.pr = 0x0606917Au; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606917Au) return; }  // 06069176 jsr @r0 ; extu.b r4,r4
    c.r[1] = c.r[0] & 0xFFu;  // 0606917A extu.b r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606917C tst r1,r1
    if (c.t) { goto L_0606919E; }  // 0606917E bt 0x0606919E
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06069180 mov.b @r8,r6
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[11]);  // 06069182 mov.b @r11,r5
    c.r[0] = ld32(0x06069288u);  // 06069184 mov.l 0x06069288,r0
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06069186 mov.b @r9,r4
    c.r[6] = c.r[6] & 0xFFu;  // 06069188 extu.b r6,r6
    c.r[5] = c.r[5] & 0xFFu;  // 0606918A extu.b r5,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06069190u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06069190u) return; }  // 0606918C jsr @r0 ; extu.b r4,r4
    c.r[1] = ld32(0x0606928Cu);  // 06069190 mov.l 0x0606928C,r1
    c.r[1] = ld32(c.r[1]);  // 06069192 mov.l @r1,r1
    c.r[1] += 22;  // 06069194 add #22,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06069196 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06069198 extu.w r1,r1
    c.t = c.r[0] >= c.r[1];  // 0606919A cmp/hs r1,r0
    if (c.t) { goto L_060691B6; }  // 0606919C bt 0x060691B6
L_0606919E:
    c.r[1] = ld32(0x06069290u);  // 0606919E mov.l 0x06069290,r1
    c.r[2] = ld32(c.r[1]);  // 060691A0 mov.l @r1,r2
    c.r[2] += 2;  // 060691A2 add #2,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06069276u);  // 060691A4 mov.w 0x06069276,r1
    c.r[1] += c.r[14];  // 060691A6 add r14,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060691A8 mov.b @r2,r2
    c.r[1] += 2;  // 060691AA add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060691AC mov.b @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 060691AE extu.b r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 060691B0 extu.b r1,r1
    c.t = c.r[2] > c.r[1];  // 060691B2 cmp/hi r1,r2
    if (!c.t) { goto L_060691CC; }  // 060691B4 bf 0x060691CC
L_060691B6:
    c.r[8] = ld32(0x06069280u);  // 060691B6 mov.l 0x06069280,r8
    c.r[2] = ld32(0x06069294u);  // 060691B8 mov.l 0x06069294,r2
    c.r[1] = c.r[2];  // 060691BA mov r2,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[8]); c.r[8] += 1;  // 060691BC mov.b @r8+,r6
    c.r[1] += 1;  // 060691BE add #1,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060691C0 mov.b @r1,r5
    c.r[0] = ld32(0x06069298u);  // 060691C2 mov.l 0x06069298,r0
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060691C4 mov.b @r2,r4
    c.r[6] = c.r[6] & 0xFFu;  // 060691C6 extu.b r6,r6
    c.r[5] = c.r[5] & 0xFFu; goto L_06069202;  // 060691C8 bra 0x06069202 ; extu.b r5,r5
L_060691CC:
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[9]);  // 060691CC mov.b @r9,r5
    c.r[0] = ld32(0x0606929Cu);  // 060691CE mov.l 0x0606929C,r0
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[11]);  // 060691D0 mov.b @r11,r4
    c.r[5] = c.r[5] & 0xFFu;  // 060691D2 extu.b r5,r5
    { const uint32_t x = c.r[0]; c.pr = 0x060691D8u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060691D8u) return; }  // 060691D4 jsr @r0 ; extu.b r4,r4
    c.r[10] = c.r[8];  // 060691D8 mov r8,r10
    c.r[10] += 1;  // 060691DA add #1,r10
    c.r[2] = c.r[0] & 0xFFu;  // 060691DC extu.b r0,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06069278u);  // 060691DE mov.w 0x06069278,r1
    c.t = c.r[2] == c.r[1];  // 060691E0 cmp/eq r1,r2
    { const bool k = !c.t; st8(c.r[10], c.r[0]); if (k) { goto L_06069224; } }  // 060691E2 bf/s 0x06069224 ; mov.b r0,@r10
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[8]);  // 060691E6 mov.b @r8,r6
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[11]);  // 060691E8 mov.b @r11,r5
L_060691EA:
    c.r[0] = ld32(0x06069298u);  // 060691EA mov.l 0x06069298,r0
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[9]);  // 060691EC mov.b @r9,r4
    c.r[6] = c.r[6] & 0xFFu;  // 060691EE extu.b r6,r6
    c.r[5] = c.r[5] & 0xFFu;  // 060691F0 extu.b r5,r5
    { const uint32_t x = c.r[0]; c.pr = 0x060691F6u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060691F6u) return; }  // 060691F2 jsr @r0 ; extu.b r4,r4
    st8(c.r[10], c.r[0]); goto L_06069224;  // 060691F6 bra 0x06069224 ; mov.b r0,@r10
L_060691FA:
    c.r[8] = ld32(0x06069280u);  // 060691FA mov.l 0x06069280,r8
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[8]); c.r[8] += 1;  // 060691FC mov.b @r8+,r6
    c.r[0] = ld32(0x06069298u);  // 060691FE mov.l 0x06069298,r0
    c.r[6] = c.r[6] & 0xFFu;  // 06069200 extu.b r6,r6
L_06069202:
    { const uint32_t x = c.r[0]; c.pr = 0x06069206u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06069206u) return; }  // 06069202 jsr @r0 ; extu.b r4,r4
    st8(c.r[8], c.r[0]); goto L_06069224;  // 06069206 bra 0x06069224 ; mov.b r0,@r8
L_0606920A:
    c.r[1] = ld32(0x06069294u);  // 0606920A mov.l 0x06069294,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0606920C mov.b @r1+,r5
    c.r[0] = ld32(0x0606929Cu);  // 0606920E mov.l 0x0606929C,r0
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06069210 mov.b @r1,r4
    c.r[5] = c.r[5] & 0xFFu;  // 06069212 extu.b r5,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06069218u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06069218u) return; }  // 06069214 jsr @r0 ; extu.b r4,r4
    c.r[1] = ld32(0x060692A0u);  // 06069218 mov.l 0x060692A0,r1
    st8(c.r[1], c.r[0]); goto L_06069226;  // 0606921A bra 0x06069226 ; mov.b r0,@r1
L_0606921E:
    c.r[8] += 1;  // 0606921E add #1,r8
    c.r[1] = 0xFFFFFFFBu;  // 06069220 mov #-5,r1
    st8(c.r[8], c.r[1]);  // 06069222 mov.b r1,@r8
L_06069224:
    c.r[1] = ld32(0x060692A0u);  // 06069224 mov.l 0x060692A0,r1
L_06069226:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06069226 mov.b @r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06069278u);  // 06069228 mov.w 0x06069278,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0606922A extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 0606922C cmp/eq r2,r1
    { const bool k = !c.t; c.r[1] = 0x4u; if (k) { goto L_0606925A; } }  // 0606922E bf/s 0x0606925A ; mov #4,r1
    c.r[2] = ld32(0x060692A4u);  // 06069232 mov.l 0x060692A4,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06069234 mov.b @r2,r3
    c.r[1] &= c.r[3];  // 06069236 and r3,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06069238 tst r1,r1
    { const bool k = c.t; c.r[1] = 0x2u; if (k) { goto L_06069242; } }  // 0606923A bt/s 0x06069242 ; mov #2,r1
    c.r[1] = 0x3u; goto L_0606925E;  // 0606923E bra 0x0606925E ; mov #3,r1
L_06069242:
    c.r[1] &= c.r[3];  // 06069242 and r3,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06069244 tst r1,r1
    { const bool k = c.t; c.r[0] = c.r[3]; if (k) { goto L_0606924E; } }  // 06069246 bt/s 0x0606924E ; mov r3,r0
    c.r[1] = 0x2u; goto L_0606925E;  // 0606924A bra 0x0606925E ; mov #2,r1
L_0606924E:
    c.r[0] &= 0x1u;  // 0606924E and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06069250 tst r0,r0
    { const bool k = c.t; c.r[1] = 0x3u; if (k) { goto L_0606925E; } }  // 06069252 bt/s 0x0606925E ; mov #3,r1
    c.r[1] = 0x1u; goto L_0606925E;  // 06069256 bra 0x0606925E ; mov #1,r1
L_0606925A:
    c.r[2] = ld32(0x060692A4u);  // 0606925A mov.l 0x060692A4,r2
    c.r[1] = 0x0u;  // 0606925C mov #0,r1
L_0606925E:
    st8(c.r[2], c.r[1]);  // 0606925E mov.b r1,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0606927Au);  // 06069260 mov.w 0x0606927A,r3
    c.r[14] += c.r[3];  // 06069262 add r3,r14
    c.r[15] = c.r[14];  // 06069264 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06069266 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06069268 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0606926A mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0606926C mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0606926E mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606927Cu);  // 06069270 mov.w 0x0606927C,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06069272 rts ; mov.l @r15+,r8
}

void f_060692A8(SH2Context& c) {
    ran[1522] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060692A8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060692AA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060692AC mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060692AE mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060692B0 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060692B2 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060692B4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060692B6 sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x0606946Au);  // 060692B8 mov.w 0x0606946A,r3
    c.r[15] += c.r[3];  // 060692BA add r3,r15
    c.r[14] = c.r[15];  // 060692BC mov r15,r14
    c.r[7] = (uint32_t)(int16_t)ld16(0x0606946Cu);  // 060692BE mov.w 0x0606946C,r7
    c.r[3] = c.r[14];  // 060692C0 mov r14,r3
    c.r[3] += c.r[7];  // 060692C2 add r7,r3
    c.r[1] = 0x0u;  // 060692C4 mov #0,r1
    c.r[2] = 0x0u;  // 060692C6 mov #0,r2
    st32(c.r[3], c.r[1]);  // 060692C8 mov.l r1,@r3
    st32(c.r[3] + 4, c.r[2]);  // 060692CA mov.l r2,@(4,r3)
    c.r[1] = ld32(0x06069480u);  // 060692CC mov.l 0x06069480,r1
    c.r[0] = c.r[14];  // 060692CE mov r14,r0
    st32(c.r[0] + c.r[7], c.r[1]);  // 060692D0 mov.l r1,@(r0,r7)
    c.r[2] = (uint32_t)(int16_t)ld16(0x0606946Eu);  // 060692D2 mov.w 0x0606946E,r2
    c.r[1] = ld32(0x06069484u);  // 060692D4 mov.l 0x06069484,r1
    st32(c.r[0] + c.r[2], c.r[1]);  // 060692D6 mov.l r1,@(r0,r2)
    c.r[3] = (uint32_t)(int16_t)ld16(0x06069470u);  // 060692D8 mov.w 0x06069470,r3
    c.r[2] = c.r[14];  // 060692DA mov r14,r2
    c.r[2] += c.r[3];  // 060692DC add r3,r2
    c.r[1] = ld32(0x06069488u);  // 060692DE mov.l 0x06069488,r1
    st32(c.r[0] + c.r[3], c.r[1]);  // 060692E0 mov.l r1,@(r0,r3)
    c.r[1] = ld32(0x0606948Cu);  // 060692E2 mov.l 0x0606948C,r1
    st32(c.r[2] + 4, c.r[1]);  // 060692E4 mov.l r1,@(4,r2)
    c.r[3] = c.r[2];  // 060692E6 mov r2,r3
    c.r[3] += 8;  // 060692E8 add #8,r3
    c.r[1] = ld32(0x06069490u);  // 060692EA mov.l 0x06069490,r1
    st32(c.r[2] + 8, c.r[1]);  // 060692EC mov.l r1,@(8,r2)
    c.r[1] = ld32(0x06069494u);  // 060692EE mov.l 0x06069494,r1
    st32(c.r[3] + 4, c.r[1]);  // 060692F0 mov.l r1,@(4,r3)
    c.r[8] = 0x0u;  // 060692F2 mov #0,r8
    c.r[11] = ld32(0x06069498u);  // 060692F4 mov.l 0x06069498,r11
    c.r[9] = (uint32_t)(int16_t)ld16(0x06069472u);  // 060692F6 mov.w 0x06069472,r9
    c.r[9] += c.r[14];  // 060692F8 add r14,r9
    c.r[0] = c.r[8];  // 060692FA mov r8,r0
L_060692FC:
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 060692FC mov.b @(r0,r11),r4
    c.r[10] = ld32(0x0606949Cu);  // 060692FE mov.l 0x0606949C,r10
    { const uint32_t x = c.r[10]; c.pr = 0x06069304u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06069304u) return; }  // 06069300 jsr @r10 ; extu.b r4,r4
    c.r[1] = c.r[0];  // 06069304 mov r0,r1
    c.r[0] = c.r[9];  // 06069306 mov r9,r0
    st8(c.r[0] + c.r[8], c.r[1]);  // 06069308 mov.b r1,@(r0,r8)
    c.r[8] += 1;  // 0606930A add #1,r8
    c.r[1] = 0x1u;  // 0606930C mov #1,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 0606930E cmp/gt r1,r8
    { const bool k = !c.t; c.r[0] = c.r[8]; if (k) { SH2_POLL(c); goto L_060692FC; } }  // 06069310 bf/s 0x060692FC ; mov r8,r0
    c.r[11] = 0x0u;  // 06069314 mov #0,r11
    c.r[7] = c.r[1];  // 06069316 mov r1,r7
    c.r[6] = (uint32_t)(int16_t)ld16(0x06069470u);  // 06069318 mov.w 0x06069470,r6
    c.r[3] = 0x0u;  // 0606931A mov #0,r3
    c.r[12] = 0x0u;  // 0606931C mov #0,r12
L_0606931E:
    c.r[10] = (uint32_t)(int16_t)ld16(0x06069474u);  // 0606931E mov.w 0x06069474,r10
    c.r[10] += c.r[14];  // 06069320 add r14,r10
    st32(c.r[10], c.r[12]);  // 06069322 mov.l r12,@r10
    c.r[2] = c.r[11];  // 06069324 mov r11,r2
    c.r[2] <<= 2;  // 06069326 shll2 r2
    c.r[2] += c.r[2];  // 06069328 add r2,r2
    c.r[2] += c.r[14];  // 0606932A add r14,r2
    c.r[2] += c.r[6];  // 0606932C add r6,r2
L_0606932E:
    c.r[13] = (uint32_t)(int16_t)ld16(0x06069474u);  // 0606932E mov.w 0x06069474,r13
    c.r[13] += c.r[14];  // 06069330 add r14,r13
    c.r[5] = ld32(c.r[13]);  // 06069332 mov.l @r13,r5
    c.r[5] <<= 2;  // 06069334 shll2 r5
    c.r[0] = c.r[5];  // 06069336 mov r5,r0
    c.r[1] = ld32(c.r[0] + c.r[2]);  // 06069338 mov.l @(r0,r2),r1
    c.r[1] += 22;  // 0606933A add #22,r1
    st16(c.r[1], c.r[3]);  // 0606933C mov.w r3,@r1
    c.r[1] = ld32(c.r[0] + c.r[2]);  // 0606933E mov.l @(r0,r2),r1
    c.r[10] = (uint32_t)(int16_t)ld16(0x06069474u);  // 06069340 mov.w 0x06069474,r10
    c.r[1] += 24;  // 06069342 add #24,r1
    st16(c.r[1], c.r[3]);  // 06069344 mov.w r3,@r1
    c.r[1] = ld32(c.r[0] + c.r[2]);  // 06069346 mov.l @(r0,r2),r1
    c.r[10] += c.r[14];  // 06069348 add r14,r10
    c.r[1] += 26;  // 0606934A add #26,r1
    st8(c.r[1], c.r[3]);  // 0606934C mov.b r3,@r1
    c.r[1] = ld32(c.r[0] + c.r[2]);  // 0606934E mov.l @(r0,r2),r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x06069474u);  // 06069350 mov.w 0x06069474,r12
    c.r[1] += 27;  // 06069352 add #27,r1
    st8(c.r[1], c.r[3]);  // 06069354 mov.b r3,@r1
    c.r[1] = ld32(c.r[0] + c.r[2]);  // 06069356 mov.l @(r0,r2),r1
    c.r[12] += c.r[14];  // 06069358 add r14,r12
    c.r[1] += 10;  // 0606935A add #10,r1
    st16(c.r[1], c.r[3]);  // 0606935C mov.w r3,@r1
    c.r[1] = ld32(c.r[0] + c.r[2]);  // 0606935E mov.l @(r0,r2),r1
    c.r[13] = (uint32_t)(int16_t)ld16(0x06069474u);  // 06069360 mov.w 0x06069474,r13
    c.r[1] += 6;  // 06069362 add #6,r1
    st16(c.r[1], c.r[3]);  // 06069364 mov.w r3,@r1
    c.r[1] = ld32(c.r[10]);  // 06069366 mov.l @r10,r1
    c.r[13] += c.r[14];  // 06069368 add r14,r13
    c.r[1] += 1;  // 0606936A add #1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606936C extu.b r1,r1
    st32(c.r[12], c.r[1]);  // 0606936E mov.l r1,@r12
    c.r[13] = ld32(c.r[13]);  // 06069370 mov.l @r13,r13
    c.t = c.r[13] > c.r[7];  // 06069372 cmp/hi r7,r13
    { const bool k = !c.t; c.r[1] = c.r[11]; if (k) { SH2_POLL(c); goto L_0606932E; } }  // 06069374 bf/s 0x0606932E ; mov r11,r1
    c.r[1] += 1;  // 06069378 add #1,r1
    c.r[11] = c.r[1] & 0xFFu;  // 0606937A extu.b r1,r11
    c.r[1] = 0x1u;  // 0606937C mov #1,r1
    c.t = c.r[11] > c.r[1];  // 0606937E cmp/hi r1,r11
    { const bool k = !c.t; c.r[12] = 0x0u; if (k) { SH2_POLL(c); goto L_0606931E; } }  // 06069380 bf/s 0x0606931E ; mov #0,r12
    c.r[11] = 0x0u;  // 06069384 mov #0,r11
    c.r[10] = (uint32_t)(int16_t)ld16(0x0606946Cu);  // 06069386 mov.w 0x0606946C,r10
    c.r[0] = (uint32_t)(int16_t)ld16(0x06069476u);  // 06069388 mov.w 0x06069476,r0
    st32(c.r[0] + c.r[14], c.r[10]);  // 0606938A mov.l r10,@(r0,r14)
    c.r[1] = c.r[11];  // 0606938C mov r11,r1
L_0606938E:
    c.r[1] -= 1;  // 0606938E add #-1,r1
    c.t = (int32_t)c.r[1] >= 0;  // 06069390 cmp/pz r1
    if (c.t) { goto L_06069396; }  // 06069392 bt 0x06069396
    c.r[1] = 0u - c.r[1];  // 06069394 neg r1,r1
L_06069396:
    c.r[1] = c.r[1] & 0xFFu;  // 06069396 extu.b r1,r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x06069474u);  // 06069398 mov.w 0x06069474,r12
    c.r[12] += c.r[14];  // 0606939A add r14,r12
    st32(c.r[12], c.r[1]);  // 0606939C mov.l r1,@r12
    c.r[0] = ld32(0x06069498u);  // 0606939E mov.l 0x06069498,r0
    c.r[10] = ld32(0x060694A0u);  // 060693A0 mov.l 0x060694A0,r10
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 060693A2 mov.b @(r0,r11),r6
    c.r[4] = c.r[14];  // 060693A4 mov r14,r4
    c.r[1] = ld32(c.r[10]);  // 060693A6 mov.l @r10,r1
    c.r[6] = c.r[6] & 0xFFu;  // 060693A8 extu.b r6,r6
    c.r[2] = c.r[6];  // 060693AA mov r6,r2
    c.r[2] <<= 2;  // 060693AC shll2 r2
    c.r[2] <<= 2;  // 060693AE shll2 r2
    c.r[2] += c.r[1];  // 060693B0 add r1,r2
    c.r[2] += 2;  // 060693B2 add #2,r2
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060693B4 mov.b @r2,r5
    c.r[12] = ld32(0x060694A4u);  // 060693B6 mov.l 0x060694A4,r12
    { const uint32_t x = c.r[12]; c.pr = 0x060693BCu; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060693BCu) return; }  // 060693B8 jsr @r12 ; extu.b r5,r5
    c.r[10] = (uint32_t)(int16_t)ld16(0x06069474u);  // 060693BC mov.w 0x06069474,r10
    c.r[10] += c.r[14];  // 060693BE add r14,r10
    c.r[12] = ld32(0x06069498u);  // 060693C0 mov.l 0x06069498,r12
    c.r[13] = ld32(0x060694A0u);  // 060693C2 mov.l 0x060694A0,r13
    c.r[0] = ld32(c.r[10]);  // 060693C4 mov.l @r10,r0
    c.r[4] = (uint32_t)(int16_t)ld16(0x06069478u);  // 060693C6 mov.w 0x06069478,r4
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[12]);  // 060693C8 mov.b @(r0,r12),r6
    c.r[4] += c.r[14];  // 060693CA add r14,r4
    c.r[1] = ld32(c.r[13]);  // 060693CC mov.l @r13,r1
    c.r[6] = c.r[6] & 0xFFu;  // 060693CE extu.b r6,r6
    c.r[2] = c.r[6];  // 060693D0 mov r6,r2
    c.r[2] <<= 2;  // 060693D2 shll2 r2
    c.r[2] <<= 2;  // 060693D4 shll2 r2
    c.r[2] += c.r[1];  // 060693D6 add r1,r2
    c.r[2] += 2;  // 060693D8 add #2,r2
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060693DA mov.b @r2,r5
    c.r[0] = ld32(0x060694A4u);  // 060693DC mov.l 0x060694A4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060693E2u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060693E2u) return; }  // 060693DE jsr @r0 ; extu.b r5,r5
    c.r[0] = ld32(0x06069498u);  // 060693E2 mov.l 0x06069498,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 060693E4 mov.b @(r0,r11),r1
    c.r[9] = ld32(0x060694A8u);  // 060693E6 mov.l 0x060694A8,r9
    c.r[2] = ld32(c.r[13]);  // 060693E8 mov.l @r13,r2
    c.r[1] = c.r[1] & 0xFFu;  // 060693EA extu.b r1,r1
    c.r[1] <<= 2;  // 060693EC shll2 r1
    c.r[1] <<= 2;  // 060693EE shll2 r1
    c.r[1] += c.r[2];  // 060693F0 add r2,r1
    c.r[1] += 2;  // 060693F2 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060693F4 mov.b @r1,r1
    c.r[8] = 0x1Eu;  // 060693F6 mov #30,r8
    c.r[1] = c.r[1] & 0xFFu;  // 060693F8 extu.b r1,r1
    c.macl = c.r[1] * c.r[8];  // 060693FA mul.l r8,r1
    c.r[4] = c.r[14];  // 060693FC mov r14,r4
    c.r[2] = ld32(c.r[9]);  // 060693FE mov.l @r9,r2
    c.r[1] = c.macl;  // 06069400 sts macl,r1
    c.r[1] += c.r[2];  // 06069402 add r2,r1
    c.r[1] += 15;  // 06069404 add #15,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06069406 mov.b @r1,r5
    c.r[10] = ld32(0x060694ACu);  // 06069408 mov.l 0x060694AC,r10
    c.r[5] = c.r[5] & 0xFFu;  // 0606940A extu.b r5,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606947Au);  // 0606940C mov.w 0x0606947A,r1
    { const uint32_t x = c.r[10]; c.pr = 0x06069412u; c.r[4] += c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06069412u) return; }  // 0606940E jsr @r10 ; add r1,r4
    c.r[10] = (uint32_t)(int16_t)ld16(0x06069474u);  // 06069412 mov.w 0x06069474,r10
    c.r[10] += c.r[14];  // 06069414 add r14,r10
    c.r[0] = ld32(c.r[10]);  // 06069416 mov.l @r10,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[12]);  // 06069418 mov.b @(r0,r12),r1
    c.r[2] = ld32(c.r[13]);  // 0606941A mov.l @r13,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0606941C extu.b r1,r1
    c.r[1] <<= 2;  // 0606941E shll2 r1
    c.r[1] <<= 2;  // 06069420 shll2 r1
    c.r[1] += c.r[2];  // 06069422 add r2,r1
    c.r[1] += 2;  // 06069424 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06069426 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06069428 extu.b r1,r1
    c.macl = c.r[1] * c.r[8];  // 0606942A mul.l r8,r1
    c.r[4] = c.r[14];  // 0606942C mov r14,r4
    c.r[2] = ld32(c.r[9]);  // 0606942E mov.l @r9,r2
    c.r[1] = c.macl;  // 06069430 sts macl,r1
    c.r[1] += c.r[2];  // 06069432 add r2,r1
    c.r[1] += 15;  // 06069434 add #15,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06069436 mov.b @r1,r5
    c.r[13] = ld32(0x060694ACu);  // 06069438 mov.l 0x060694AC,r13
    c.r[5] = c.r[5] & 0xFFu;  // 0606943A extu.b r5,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606947Cu);  // 0606943C mov.w 0x0606947C,r1
    { const uint32_t x = c.r[13]; c.pr = 0x06069442u; c.r[4] += c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06069442u) return; }  // 0606943E jsr @r13 ; add r1,r4
    c.r[7] = c.r[11];  // 06069442 mov r11,r7
    c.r[7] <<= 2;  // 06069444 shll2 r7
    c.r[10] = (uint32_t)(int16_t)ld16(0x06069476u);  // 06069446 mov.w 0x06069476,r10
    c.r[10] += c.r[14];  // 06069448 add r14,r10
    c.r[0] = ld32(c.r[10]);  // 0606944A mov.l @r10,r0
    c.r[7] += c.r[14];  // 0606944C add r14,r7
    c.r[1] = ld32(c.r[0] + c.r[7]);  // 0606944E mov.l @(r0,r7),r1
    c.r[12] = 0x7Fu;  // 06069450 mov #127,r12
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06069452 mov.b @r1,r2
    c.r[0] = c.r[11];  // 06069454 mov r11,r0
    c.r[2] &= c.r[12];  // 06069456 and r12,r2
    st8(c.r[1], c.r[2]);  // 06069458 mov.b r2,@r1
    c.r[1] = ld32(0x060694B0u);  // 0606945A mov.l 0x060694B0,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606945C mov.b @(r0,r1),r2
    c.r[10] = 0x1u;  // 0606945E mov #1,r10
    c.r[1] = c.r[2];  // 06069460 mov r2,r1
    c.r[1] += 4;  // 06069462 add #4,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06069464 extu.b r1,r1
    c.t = c.r[1] > c.r[10]; goto L_060694B4;  // 06069466 bra 0x060694B4 ; cmp/hi r10,r1
L_060694B4:
    if (!c.t) { goto L_060694EE; }  // 060694B4 bf 0x060694EE
    c.r[3] = c.r[2] & 0xFFu;  // 060694B6 extu.b r2,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x060695C2u);  // 060694B8 mov.w 0x060695C2,r1
    c.t = c.r[3] == c.r[1];  // 060694BA cmp/eq r1,r3
    { const bool k = c.t; c.r[1] = c.r[14]; if (k) { goto L_060694EE; } }  // 060694BC bt/s 0x060694EE ; mov r14,r1
    c.r[10] = (uint32_t)(int16_t)ld16(0x060695C4u);  // 060694C0 mov.w 0x060695C4,r10
    c.r[10] += c.r[14];  // 060694C2 add r14,r10
    c.r[0] = ld32(c.r[10]);  // 060694C4 mov.l @r10,r0
    c.r[2] = ld32(c.r[0] + c.r[7]);  // 060694C6 mov.l @(r0,r7),r2
    c.r[1] += 50;  // 060694C8 add #50,r1
    c.r[7] = c.r[3];  // 060694CA mov r3,r7
    c.r[7] <<= 2;  // 060694CC shll2 r7
    c.r[7] += c.r[3];  // 060694CE add r3,r7
    c.r[7] <<= 2;  // 060694D0 shll2 r7
    c.r[0] = c.r[1];  // 060694D2 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 060694D4 mov.b @(r0,r7),r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060694D6 mov.b @r2,r3
    c.r[1] = c.r[1] & 0xFFu;  // 060694D8 extu.b r1,r1
    c.r[1] >>= 2;  // 060694DA shlr2 r1
    c.r[1] >>= 2;  // 060694DC shlr2 r1
    c.r[1] >>= 2;  // 060694DE shlr2 r1
    c.r[1] <<= 2;  // 060694E0 shll2 r1
    c.r[1] <<= 2;  // 060694E2 shll2 r1
    c.r[1] += c.r[1];  // 060694E4 add r1,r1
    c.r[1] <<= 2;  // 060694E6 shll2 r1
    c.r[3] &= c.r[12];  // 060694E8 and r12,r3
    c.r[3] |= c.r[1];  // 060694EA or r1,r3
    st8(c.r[2], c.r[3]);  // 060694EC mov.b r3,@r2
L_060694EE:
    c.r[1] = (uint32_t)(int16_t)ld16(0x060695C6u);  // 060694EE mov.w 0x060695C6,r1
    c.r[10] = (uint32_t)(int16_t)ld16(0x060695C8u);  // 060694F0 mov.w 0x060695C8,r10
    c.r[10] += c.r[14];  // 060694F2 add r14,r10
    c.r[0] = ld32(c.r[10]);  // 060694F4 mov.l @r10,r0
    c.r[1] += c.r[14];  // 060694F6 add r14,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060694F8 mov.b @(r0,r1),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x060695CAu);  // 060694FA mov.w 0x060695CA,r2
    c.r[1] = c.r[1] & 0xFFu;  // 060694FC extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 060694FE cmp/eq r2,r1
    { const bool k = c.t; c.r[13] = 0x1u; if (k) { goto L_0606952A; } }  // 06069500 bt/s 0x0606952A ; mov #1,r13
    c.r[1] = ld32(0x060695D8u);  // 06069504 mov.l 0x060695D8,r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x060695C8u);  // 06069506 mov.w 0x060695C8,r12
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06069508 mov.b @(r0,r1),r1
    c.r[1] += 4;  // 0606950A add #4,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606950C extu.b r1,r1
    c.t = c.r[1] > c.r[13];  // 0606950E cmp/hi r13,r1
    { const bool k = c.t; c.r[12] += c.r[14]; if (k) { goto L_060695E8; } }  // 06069510 bt/s 0x060695E8 ; add r14,r12
    c.r[1] = c.r[11];  // 06069514 mov r11,r1
    c.r[1] <<= 2;  // 06069516 shll2 r1
    c.r[10] = (uint32_t)(int16_t)ld16(0x060695C4u);  // 06069518 mov.w 0x060695C4,r10
    c.r[10] += c.r[14];  // 0606951A add r14,r10
    c.r[0] = ld32(c.r[10]);  // 0606951C mov.l @r10,r0
    c.r[1] += c.r[14];  // 0606951E add r14,r1
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 06069520 mov.l @(r0,r1),r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06069522 mov.b @r1,r2
    c.r[12] = 0xCu;  // 06069524 mov #12,r12
    c.r[2] |= c.r[12]; goto L_060695FC;  // 06069526 bra 0x060695FC ; or r12,r2
L_0606952A:
    c.r[10] = (uint32_t)(int16_t)ld16(0x060695C8u);  // 0606952A mov.w 0x060695C8,r10
    c.r[10] += c.r[14];  // 0606952C add r14,r10
    c.r[0] = ld32(c.r[10]);  // 0606952E mov.l @r10,r0
    c.r[1] = ld32(0x060695D8u);  // 06069530 mov.l 0x060695D8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06069532 mov.b @(r0,r1),r1
    c.r[2] = c.r[1] & 0xFFu;  // 06069534 extu.b r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x060695CCu);  // 06069536 mov.w 0x060695CC,r1
    c.t = c.r[2] == c.r[1];  // 06069538 cmp/eq r1,r2
    { const bool k = c.t; c.r[1] = c.r[11]; if (k) { goto L_0606954A; } }  // 0606953A bt/s 0x0606954A ; mov r11,r1
    c.r[1] = (uint32_t)(int16_t)ld16(0x060695CEu);  // 0606953E mov.w 0x060695CE,r1
    c.t = c.r[2] == c.r[1];  // 06069540 cmp/eq r1,r2
    { const bool k = c.t; c.r[1] = c.r[11]; if (k) { goto L_06069562; } }  // 06069542 bt/s 0x06069562 ; mov r11,r1
    c.r[12] = 0x1u; goto L_06069576;  // 06069546 bra 0x06069576 ; mov #1,r12
L_0606954A:
    c.r[1] <<= 2;  // 0606954A shll2 r1
    c.r[10] = (uint32_t)(int16_t)ld16(0x060695C4u);  // 0606954C mov.w 0x060695C4,r10
    c.r[10] += c.r[14];  // 0606954E add r14,r10
    c.r[0] = ld32(c.r[10]);  // 06069550 mov.l @r10,r0
    c.r[1] += c.r[14];  // 06069552 add r14,r1
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 06069554 mov.l @(r0,r1),r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x060695D0u);  // 06069556 mov.w 0x060695D0,r12
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06069558 mov.b @r1,r2
    c.r[13] = 0x8u;  // 0606955A mov #8,r13
    c.r[2] &= c.r[12];  // 0606955C and r12,r2
    c.r[2] |= c.r[13]; goto L_060695FC;  // 0606955E bra 0x060695FC ; or r13,r2
L_06069562:
    c.r[1] <<= 2;  // 06069562 shll2 r1
    c.r[10] = (uint32_t)(int16_t)ld16(0x060695C4u);  // 06069564 mov.w 0x060695C4,r10
    c.r[10] += c.r[14];  // 06069566 add r14,r10
    c.r[0] = ld32(c.r[10]);  // 06069568 mov.l @r10,r0
    c.r[1] += c.r[14];  // 0606956A add r14,r1
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 0606956C mov.l @(r0,r1),r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606956E mov.b @r1,r2
    c.r[12] = 0xCu;  // 06069570 mov #12,r12
    c.r[2] |= c.r[12]; goto L_060695FC;  // 06069572 bra 0x060695FC ; or r12,r2
L_06069576:
    c.r[0] = ld32(0x060695DCu);  // 06069576 mov.l 0x060695DC,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 06069578 mov.b @(r0,r11),r1
    c.r[10] = ld32(0x060695E0u);  // 0606957A mov.l 0x060695E0,r10
    c.r[2] = ld32(c.r[10]);  // 0606957C mov.l @r10,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0606957E extu.b r1,r1
    c.r[1] <<= 2;  // 06069580 shll2 r1
    c.r[1] <<= 2;  // 06069582 shll2 r1
    c.r[1] += c.r[2];  // 06069584 add r2,r1
    c.r[1] += 10;  // 06069586 add #10,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06069588 mov.b @r1,r1
    c.r[1] >>= 2;  // 0606958A shlr2 r1
    c.r[1] >>= 2;  // 0606958C shlr2 r1
    c.r[1] &= c.r[12];  // 0606958E and r12,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06069590 tst r1,r1
    if (!c.t) { goto L_060695E8; }  // 06069592 bf 0x060695E8
    c.r[5] = c.r[14];  // 06069594 mov r14,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x060695D2u);  // 06069596 mov.w 0x060695D2,r1
    c.r[0] = ld32(0x060695E4u);  // 06069598 mov.l 0x060695E4,r0
    c.r[5] += c.r[1];  // 0606959A add r1,r5
    c.r[4] = (uint32_t)(int16_t)ld16(0x060695D4u);  // 0606959C mov.w 0x060695D4,r4
    { const uint32_t x = c.r[0]; c.pr = 0x060695A2u; c.r[4] += c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060695A2u) return; }  // 0606959E jsr @r0 ; add r14,r4
    c.r[1] = c.r[0] & 0xFFu;  // 060695A2 extu.b r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060695A4 tst r1,r1
    { const bool k = c.t; c.r[1] = c.r[11]; if (k) { goto L_060695EA; } }  // 060695A6 bt/s 0x060695EA ; mov r11,r1
    c.r[1] <<= 2;  // 060695AA shll2 r1
    c.r[10] = (uint32_t)(int16_t)ld16(0x060695C4u);  // 060695AC mov.w 0x060695C4,r10
    c.r[10] += c.r[14];  // 060695AE add r14,r10
    c.r[0] = ld32(c.r[10]);  // 060695B0 mov.l @r10,r0
    c.r[1] += c.r[14];  // 060695B2 add r14,r1
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 060695B4 mov.l @(r0,r1),r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x060695D0u);  // 060695B6 mov.w 0x060695D0,r12
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060695B8 mov.b @r1,r2
    c.r[13] = 0x4u;  // 060695BA mov #4,r13
    c.r[2] &= c.r[12];  // 060695BC and r12,r2
    c.r[2] |= c.r[13]; goto L_060695FC;  // 060695BE bra 0x060695FC ; or r13,r2
L_060695E8:
    c.r[1] = c.r[11];  // 060695E8 mov r11,r1
L_060695EA:
    c.r[1] <<= 2;  // 060695EA shll2 r1
    c.r[10] = (uint32_t)(int16_t)ld16(0x060697D6u);  // 060695EC mov.w 0x060697D6,r10
    c.r[10] += c.r[14];  // 060695EE add r14,r10
    c.r[0] = ld32(c.r[10]);  // 060695F0 mov.l @r10,r0
    c.r[1] += c.r[14];  // 060695F2 add r14,r1
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 060695F4 mov.l @(r0,r1),r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060695F6 mov.b @r1,r2
    c.r[12] = (uint32_t)(int16_t)ld16(0x060697D8u);  // 060695F8 mov.w 0x060697D8,r12
    c.r[2] &= c.r[12];  // 060695FA and r12,r2
L_060695FC:
    st8(c.r[1], c.r[2]);  // 060695FC mov.b r2,@r1
    c.r[0] = c.r[11];  // 060695FE mov r11,r0
    c.r[0] <<= 2;  // 06069600 shll2 r0
    c.r[13] = (uint32_t)(int16_t)ld16(0x060697DAu);  // 06069602 mov.w 0x060697DA,r13
    c.r[13] += c.r[14];  // 06069604 add r14,r13
    st32(c.r[13], c.r[0]);  // 06069606 mov.l r0,@r13
    c.r[10] = (uint32_t)(int16_t)ld16(0x060697DAu);  // 06069608 mov.w 0x060697DA,r10
    c.r[10] += c.r[14];  // 0606960A add r14,r10
    c.r[7] = 0x0u;  // 0606960C mov #0,r7
    c.r[12] = ld32(c.r[10]);  // 0606960E mov.l @r10,r12
    c.r[6] = 0x3u;  // 06069610 mov #3,r6
    c.r[12] += c.r[14];  // 06069612 add r14,r12
    st32(c.r[10], c.r[12]);  // 06069614 mov.l r12,@r10
    c.r[10] = (uint32_t)(int16_t)ld16(0x060697DAu);  // 06069616 mov.w 0x060697DA,r10
    c.r[10] += c.r[14];  // 06069618 add r14,r10
    c.r[12] = (uint32_t)(int16_t)ld16(0x060697D6u);  // 0606961A mov.w 0x060697D6,r12
    c.r[0] = ld32(c.r[10]);  // 0606961C mov.l @r10,r0
    c.r[12] += c.r[14];  // 0606961E add r14,r12
    c.r[13] = ld32(c.r[12]);  // 06069620 mov.l @r12,r13
    c.r[10] = (uint32_t)(int16_t)ld16(0x060697DAu);  // 06069622 mov.w 0x060697DA,r10
    c.r[10] += c.r[14];  // 06069624 add r14,r10
    c.r[12] = (uint32_t)(int16_t)ld16(0x060697D6u);  // 06069626 mov.w 0x060697D6,r12
    c.r[12] += c.r[14];  // 06069628 add r14,r12
    c.r[1] = ld32(c.r[0] + c.r[13]);  // 0606962A mov.l @(r0,r13),r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x060697D6u);  // 0606962C mov.w 0x060697D6,r12
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606962E mov.b @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x060697DCu);  // 06069630 mov.w 0x060697DC,r0
    c.r[2] &= c.r[0];  // 06069632 and r0,r2
    st8(c.r[1], c.r[2]);  // 06069634 mov.b r2,@r1
    c.r[0] = ld32(c.r[10]);  // 06069636 mov.l @r10,r0
    c.r[12] += c.r[14];  // 06069638 add r14,r12
    c.r[10] = (uint32_t)(int16_t)ld16(0x060697DAu);  // 0606963A mov.w 0x060697DA,r10
    c.r[10] += c.r[14];  // 0606963C add r14,r10
    c.r[1] = ld32(c.r[0] + c.r[13]);  // 0606963E mov.l @(r0,r13),r1
    c.r[10] = (uint32_t)(int16_t)ld16(0x060697DAu);  // 06069640 mov.w 0x060697DA,r10
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06069642 mov.b @r1,r2
    c.r[13] = (uint32_t)(int16_t)ld16(0x060697DEu);  // 06069644 mov.w 0x060697DE,r13
    c.r[2] &= c.r[13];  // 06069646 and r13,r2
    st8(c.r[1], c.r[2]);  // 06069648 mov.b r2,@r1
    c.r[13] = ld32(c.r[12]);  // 0606964A mov.l @r12,r13
    c.r[10] += c.r[14];  // 0606964C add r14,r10
    c.r[12] = (uint32_t)(int16_t)ld16(0x060697D6u);  // 0606964E mov.w 0x060697D6,r12
    c.r[12] += c.r[14];  // 06069650 add r14,r12
    c.r[1] = ld32(c.r[0] + c.r[13]);  // 06069652 mov.l @(r0,r13),r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x060697D6u);  // 06069654 mov.w 0x060697D6,r12
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06069656 mov.b @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x060697E0u);  // 06069658 mov.w 0x060697E0,r0
    c.r[2] &= c.r[0];  // 0606965A and r0,r2
    st8(c.r[1], c.r[2]);  // 0606965C mov.b r2,@r1
    c.r[0] = ld32(c.r[10]);  // 0606965E mov.l @r10,r0
    c.r[12] += c.r[14];  // 06069660 add r14,r12
    c.r[10] = (uint32_t)(int16_t)ld16(0x060697DAu);  // 06069662 mov.w 0x060697DA,r10
    c.r[10] += c.r[14];  // 06069664 add r14,r10
    c.r[10] = (uint32_t)(int16_t)ld16(0x060697DAu);  // 06069666 mov.w 0x060697DA,r10
    c.r[10] += c.r[14];  // 06069668 add r14,r10
    c.r[10] = (uint32_t)(int16_t)ld16(0x060697DAu);  // 0606966A mov.w 0x060697DA,r10
    c.r[10] += c.r[14];  // 0606966C add r14,r10
    c.r[10] = (uint32_t)(int16_t)ld16(0x060697DAu);  // 0606966E mov.w 0x060697DA,r10
    c.r[10] += c.r[14];  // 06069670 add r14,r10
    c.r[10] = (uint32_t)(int16_t)ld16(0x060697DAu);  // 06069672 mov.w 0x060697DA,r10
    c.r[1] = ld32(c.r[0] + c.r[13]);  // 06069674 mov.l @(r0,r13),r1
    c.r[10] += c.r[14];  // 06069676 add r14,r10
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06069678 mov.b @r1,r2
    c.r[13] = (uint32_t)(int16_t)ld16(0x060697E2u);  // 0606967A mov.w 0x060697E2,r13
    c.r[2] &= c.r[13];  // 0606967C and r13,r2
    st8(c.r[1], c.r[2]);  // 0606967E mov.b r2,@r1
    c.r[13] = ld32(c.r[12]);  // 06069680 mov.l @r12,r13
    c.r[2] = (uint32_t)(int16_t)ld16(0x060697E4u);  // 06069682 mov.w 0x060697E4,r2
    c.r[12] = (uint32_t)(int16_t)ld16(0x060697D6u);  // 06069684 mov.w 0x060697D6,r12
    c.r[12] += c.r[14];  // 06069686 add r14,r12
    c.r[12] = (uint32_t)(int16_t)ld16(0x060697D6u);  // 06069688 mov.w 0x060697D6,r12
    c.r[12] += c.r[14];  // 0606968A add r14,r12
    c.r[3] = ld32(c.r[0] + c.r[13]);  // 0606968C mov.l @(r0,r13),r3
    c.r[12] = (uint32_t)(int16_t)ld16(0x060697D6u);  // 0606968E mov.w 0x060697D6,r12
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06069690 mov.w @r3,r1
    c.r[12] += c.r[14];  // 06069692 add r14,r12
    c.r[1] &= c.r[2];  // 06069694 and r2,r1
    st16(c.r[3], c.r[1]);  // 06069696 mov.w r1,@r3
    c.r[1] = ld32(c.r[0] + c.r[13]);  // 06069698 mov.l @(r0,r13),r1
    c.r[2] = 0x0u;  // 0606969A mov #0,r2
    c.r[1] += 2;  // 0606969C add #2,r1
    st16(c.r[1], c.r[2]);  // 0606969E mov.w r2,@r1
    c.r[1] = ld32(c.r[0] + c.r[13]);  // 060696A0 mov.l @(r0,r13),r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x060697D6u);  // 060696A2 mov.w 0x060697D6,r12
    c.r[1] += 4;  // 060696A4 add #4,r1
    st16(c.r[1], c.r[2]);  // 060696A6 mov.w r2,@r1
    c.r[1] = ld32(c.r[0] + c.r[13]);  // 060696A8 mov.l @(r0,r13),r1
    c.r[12] += c.r[14];  // 060696AA add r14,r12
    c.r[1] += 1;  // 060696AC add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060696AE mov.b @r1,r2
    c.r[13] = (uint32_t)(int16_t)ld16(0x060697DCu);  // 060696B0 mov.w 0x060697DC,r13
    c.r[2] &= c.r[13];  // 060696B2 and r13,r2
    st8(c.r[1], c.r[2]);  // 060696B4 mov.b r2,@r1
    c.r[13] = ld32(c.r[12]);  // 060696B6 mov.l @r12,r13
    c.r[10] = (uint32_t)(int16_t)ld16(0x060697E6u);  // 060696B8 mov.w 0x060697E6,r10
    c.r[2] = ld32(c.r[0] + c.r[13]);  // 060696BA mov.l @(r0,r13),r2
    c.r[12] = 0x10u;  // 060696BC mov #16,r12
    c.r[0] = (uint32_t)(int16_t)ld16(0x060697E8u);  // 060696BE mov.w 0x060697E8,r0
    st32(c.r[0] + c.r[14], c.r[10]);  // 060696C0 mov.l r10,@(r0,r14)
    c.r[10] = (uint32_t)(int16_t)ld16(0x060697E8u);  // 060696C2 mov.w 0x060697E8,r10
    c.r[10] += c.r[14];  // 060696C4 add r14,r10
    c.r[2] += 1;  // 060696C6 add #1,r2
    c.r[0] = ld32(c.r[10]);  // 060696C8 mov.l @r10,r0
    c.r[13] = (uint32_t)(int16_t)ld16(0x060697EAu);  // 060696CA mov.w 0x060697EA,r13
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 060696CC mov.b @(r0,r14),r1
    c.r[10] = 0x0u;  // 060696CE mov #0,r10
    c.r[3] = c.r[1];  // 060696D0 mov r1,r3
    c.r[3] <<= 2;  // 060696D2 shll2 r3
    c.r[3] &= c.r[12];  // 060696D4 and r12,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060696D6 mov.b @r2,r1
    c.r[0] = ld32(0x06069808u);  // 060696D8 mov.l 0x06069808,r0
    c.r[1] &= c.r[13];  // 060696DA and r13,r1
    c.r[1] |= c.r[3];  // 060696DC or r3,r1
    st8(c.r[2], c.r[1]);  // 060696DE mov.b r1,@r2
    c.r[5] = ld32(c.r[0]);  // 060696E0 mov.l @r0,r5
    c.r[12] = ld32(0x0606980Cu);  // 060696E2 mov.l 0x0606980C,r12
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[14]);  // 060696E4 mov.w @r14,r4
    c.r[5] += 20;  // 060696E6 add #20,r5
    c.r[4] = c.r[4] & 0xFFFFu;  // 060696E8 extu.w r4,r4
    { const uint32_t x = c.r[12]; c.pr = 0x060696EEu; c.r[15] -= 4; st32(c.r[15], c.r[10]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060696EEu) return; }  // 060696EA jsr @r12 ; mov.l r10,@-r15
    c.r[1] = c.r[0];  // 060696EE mov r0,r1
    c.r[10] = (uint32_t)(int16_t)ld16(0x060697DAu);  // 060696F0 mov.w 0x060697DA,r10
    c.r[10] += c.r[14];  // 060696F2 add r14,r10
    c.r[12] = (uint32_t)(int16_t)ld16(0x060697D6u);  // 060696F4 mov.w 0x060697D6,r12
    c.r[12] += c.r[14];  // 060696F6 add r14,r12
    c.r[15] += 4;  // 060696F8 add #4,r15
    c.r[1] = c.r[1] & 0xFFFFu;  // 060696FA extu.w r1,r1
    c.r[8] = (uint32_t)(int16_t)ld16(0x060697ECu);  // 060696FC mov.w 0x060697EC,r8
    c.r[0] = ld32(c.r[10]);  // 060696FE mov.l @r10,r0
    c.r[6] = 0x5Du;  // 06069700 mov #93,r6
    c.r[13] = ld32(c.r[12]);  // 06069702 mov.l @r12,r13
    c.r[7] = c.r[14];  // 06069704 mov r14,r7
    c.r[2] = ld32(c.r[0] + c.r[13]);  // 06069706 mov.l @(r0,r13),r2
    c.r[12] = (uint32_t)(int16_t)ld16(0x060697D8u);  // 06069708 mov.w 0x060697D8,r12
    c.r[0] = 0x1u;  // 0606970A mov #1,r0
    c.t = c.r[0] >= c.r[1];  // 0606970C cmp/hs r1,r0
    c.r[10] = c.t;  // 0606970E movt r10
    c.r[1] = c.r[10];  // 06069710 mov r10,r1
    c.r[2] += 1;  // 06069712 add #1,r2
    c.r[1] <<= 2;  // 06069714 shll2 r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060697EEu);  // 06069716 mov.w 0x060697EE,r0
    c.r[13] = (uint32_t)(int16_t)ld16(0x060697F0u);  // 06069718 mov.w 0x060697F0,r13
    c.r[13] += c.r[14];  // 0606971A add r14,r13
    c.r[10] = (uint32_t)(int16_t)ld16(0x060697F0u);  // 0606971C mov.w 0x060697F0,r10
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606971E mov.b @r2,r3
    c.r[10] += c.r[14];  // 06069720 add r14,r10
    c.r[3] &= c.r[12];  // 06069722 and r12,r3
    c.r[3] |= c.r[1];  // 06069724 or r1,r3
    st8(c.r[2], c.r[3]);  // 06069726 mov.b r3,@r2
    c.r[2] = (uint32_t)(int16_t)ld16(0x060697F2u);  // 06069728 mov.w 0x060697F2,r2
    st32(c.r[13], c.r[0]);  // 0606972A mov.l r0,@r13
    c.r[12] = ld32(c.r[10]);  // 0606972C mov.l @r10,r12
    c.r[7] += c.r[2];  // 0606972E add r2,r7
    c.r[12] += c.r[14];  // 06069730 add r14,r12
    st32(c.r[10], c.r[12]);  // 06069732 mov.l r12,@r10
    c.r[10] = (uint32_t)(int16_t)ld16(0x060697F0u);  // 06069734 mov.w 0x060697F0,r10
    c.r[10] += c.r[14];  // 06069736 add r14,r10
    c.r[12] = (uint32_t)(int16_t)ld16(0x060697F4u);  // 06069738 mov.w 0x060697F4,r12
    c.r[0] = ld32(c.r[10]);  // 0606973A mov.l @r10,r0
    c.r[12] += c.r[14];  // 0606973C add r14,r12
    c.r[13] = ld32(c.r[12]);  // 0606973E mov.l @r12,r13
    c.r[10] = (uint32_t)(int16_t)ld16(0x060697F6u);  // 06069740 mov.w 0x060697F6,r10
    c.r[12] = (uint32_t)(int16_t)ld16(0x060697F8u);  // 06069742 mov.w 0x060697F8,r12
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[13]);  // 06069744 mov.b @(r0,r13),r1
    c.r[12] += c.r[14];  // 06069746 add r14,r12
    c.r[1] = c.r[1] & 0xFFu;  // 06069748 extu.b r1,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0606974A mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0606974C mov.l r8,@-r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x060697F8u);  // 0606974E mov.w 0x060697F8,r0
    st32(c.r[0] + c.r[14], c.r[10]);  // 06069750 mov.l r10,@(r0,r14)
    c.r[10] = c.r[11];  // 06069752 mov r11,r10
    c.r[10] <<= 2;  // 06069754 shll2 r10
    c.r[10] += c.r[10];  // 06069756 add r10,r10
    c.r[0] = (uint32_t)(int16_t)ld16(0x060697FAu);  // 06069758 mov.w 0x060697FA,r0
    c.r[13] = ld32(c.r[12]);  // 0606975A mov.l @r12,r13
    c.r[0] += c.r[14];  // 0606975C add r14,r0
    c.r[13] += c.r[14];  // 0606975E add r14,r13
    st32(c.r[12], c.r[13]);  // 06069760 mov.l r13,@r12
    st32(c.r[0], c.r[10]);  // 06069762 mov.l r10,@r0
    c.r[10] = (uint32_t)(int16_t)ld16(0x060697F8u);  // 06069764 mov.w 0x060697F8,r10
    c.r[10] += c.r[14];  // 06069766 add r14,r10
    c.r[12] = (uint32_t)(int16_t)ld16(0x060697FAu);  // 06069768 mov.w 0x060697FA,r12
    c.r[0] = ld32(c.r[10]);  // 0606976A mov.l @r10,r0
    c.r[12] += c.r[14];  // 0606976C add r14,r12
    c.r[13] = ld32(c.r[12]);  // 0606976E mov.l @r12,r13
    c.r[10] = (uint32_t)(int16_t)ld16(0x060697FCu);  // 06069770 mov.w 0x060697FC,r10
    c.r[10] += c.r[14];  // 06069772 add r14,r10
    c.r[1] = ld32(c.r[0] + c.r[13]);  // 06069774 mov.l @(r0,r13),r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x060697FCu);  // 06069776 mov.w 0x060697FC,r12
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06069778 mov.l r1,@-r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x060697FEu);  // 0606977A mov.w 0x060697FE,r0
    st32(c.r[0] + c.r[14], c.r[10]);  // 0606977C mov.l r10,@(r0,r14)
    c.r[15] -= c.r[12];  // 0606977E sub r12,r15
    c.r[4] = c.r[15];  // 06069780 mov r15,r4
    c.r[13] = (uint32_t)(int16_t)ld16(0x060697FEu);  // 06069782 mov.w 0x060697FE,r13
    c.r[13] += c.r[14];  // 06069784 add r14,r13
    c.r[0] = ld32(0x06069810u);  // 06069786 mov.l 0x06069810,r0
    c.r[10] = (uint32_t)(int16_t)ld16(0x060697F4u);  // 06069788 mov.w 0x060697F4,r10
    c.r[10] += c.r[14];  // 0606978A add r14,r10
    c.r[12] = ld32(0x06069814u);  // 0606978C mov.l 0x06069814,r12
    { const uint32_t x = c.r[0]; c.pr = 0x06069792u; c.r[5] = ld32(c.r[13]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06069792u) return; }  // 0606978E jsr @r0 ; mov.l @r13,r5
    c.r[6] = c.r[14];  // 06069792 mov r14,r6
    c.r[5] = ld32(c.r[10]);  // 06069794 mov.l @r10,r5
    { const uint32_t x = c.r[12]; c.pr = 0x0606979Au; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606979Au) return; }  // 06069796 jsr @r12 ; mov r11,r4
    c.r[10] = (uint32_t)(int16_t)ld16(0x060697F0u);  // 0606979A mov.w 0x060697F0,r10
    c.r[10] += c.r[14];  // 0606979C add r14,r10
    c.r[0] = ld32(c.r[10]);  // 0606979E mov.l @r10,r0
    c.r[12] = (uint32_t)(int16_t)ld16(0x06069800u);  // 060697A0 mov.w 0x06069800,r12
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 060697A2 mov.b @(r0,r11),r1
    c.r[6] = c.r[1] & 0xFFu;  // 060697A4 extu.b r1,r6
    c.t = c.r[6] == c.r[8];  // 060697A6 cmp/eq r8,r6
    { const bool k = !c.t; c.r[15] += c.r[12]; if (k) { goto L_060697B0; } }  // 060697A8 bf/s 0x060697B0 ; add r12,r15
    goto L_060699A8;  // 060697AC bra 0x060699A8 ; nop
L_060697B0:
    c.r[13] = ld32(0x06069818u);  // 060697B0 mov.l 0x06069818,r13
    c.r[2] = c.r[6];  // 060697B2 mov r6,r2
    c.r[2] <<= 2;  // 060697B4 shll2 r2
    c.r[2] <<= 2;  // 060697B6 shll2 r2
    c.r[10] = (uint32_t)(int16_t)ld16(0x06069802u);  // 060697B8 mov.w 0x06069802,r10
    c.r[0] = (uint32_t)(int16_t)ld16(0x06069804u);  // 060697BA mov.w 0x06069804,r0
    c.r[0] += c.r[14];  // 060697BC add r14,r0
    c.r[1] = ld32(c.r[13]);  // 060697BE mov.l @r13,r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x06069804u);  // 060697C0 mov.w 0x06069804,r12
    c.r[2] += c.r[1];  // 060697C2 add r1,r2
    c.r[2] += 2;  // 060697C4 add #2,r2
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060697C6 mov.b @r2,r5
    c.r[12] += c.r[14];  // 060697C8 add r14,r12
    c.r[5] = c.r[5] & 0xFFu;  // 060697CA extu.b r5,r5
    st32(c.r[0], c.r[10]);  // 060697CC mov.l r10,@r0
    c.r[0] = (uint32_t)(int16_t)ld16(0x06069806u);  // 060697CE mov.w 0x06069806,r0
    c.r[13] = ld32(c.r[12]);  // 060697D0 mov.l @r12,r13
    c.r[0] += c.r[14]; goto L_0606981C;  // 060697D2 bra 0x0606981C ; add r14,r0
L_0606981C:
    c.r[13] += c.r[14];  // 0606981C add r14,r13
    c.r[12] = (uint32_t)(int16_t)ld16(0x0606995Au);  // 0606981E mov.w 0x0606995A,r12
    c.r[12] += c.r[14];  // 06069820 add r14,r12
    st32(c.r[12], c.r[13]);  // 06069822 mov.l r13,@r12
    c.r[10] = ld32(0x06069978u);  // 06069824 mov.l 0x06069978,r10
    { const uint32_t x = c.r[10]; c.pr = 0x0606982Au; c.r[4] = ld32(c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606982Au) return; }  // 06069826 jsr @r10 ; mov.l @r0,r4
    c.r[10] = (uint32_t)(int16_t)ld16(0x0606995Cu);  // 0606982A mov.w 0x0606995C,r10
    c.r[10] += c.r[14];  // 0606982C add r14,r10
    c.r[0] = ld32(c.r[10]);  // 0606982E mov.l @r10,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 06069830 mov.b @(r0,r11),r1
    c.r[12] = ld32(0x0606997Cu);  // 06069832 mov.l 0x0606997C,r12
    c.r[2] = ld32(c.r[12]);  // 06069834 mov.l @r12,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06069836 extu.b r1,r1
    c.r[1] <<= 2;  // 06069838 shll2 r1
    c.r[1] <<= 2;  // 0606983A shll2 r1
    c.r[1] += c.r[2];  // 0606983C add r2,r1
    c.r[1] += 2;  // 0606983E add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06069840 mov.b @r1,r2
    c.r[1] = ld32(0x06069980u);  // 06069842 mov.l 0x06069980,r1
    c.r[3] = ld32(c.r[1]);  // 06069844 mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06069846 extu.b r2,r2
    c.r[1] = 0x1Eu;  // 06069848 mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 0606984A mul.l r1,r2
    c.r[9] = (uint32_t)(int16_t)ld16(0x0606995Eu);  // 0606984C mov.w 0x0606995E,r9
    c.r[9] += c.r[14];  // 0606984E add r14,r9
    c.r[1] = c.macl;  // 06069850 sts macl,r1
    c.r[1] += c.r[3];  // 06069852 add r3,r1
    c.r[1] += 15;  // 06069854 add #15,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06069856 mov.b @r1,r5
    c.r[4] = c.r[9];  // 06069858 mov r9,r4
    c.r[1] = ld32(0x06069984u);  // 0606985A mov.l 0x06069984,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06069860u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06069860u) return; }  // 0606985C jsr @r1 ; extu.b r5,r5
    c.r[10] = (uint32_t)(int16_t)ld16(0x0606995Cu);  // 06069860 mov.w 0x0606995C,r10
    c.r[10] += c.r[14];  // 06069862 add r14,r10
    c.r[12] = (uint32_t)(int16_t)ld16(0x06069960u);  // 06069864 mov.w 0x06069960,r12
    c.r[12] += c.r[14];  // 06069866 add r14,r12
    c.r[6] = 0x5Du;  // 06069868 mov #93,r6
    c.r[0] = ld32(c.r[10]);  // 0606986A mov.l @r10,r0
    c.r[7] = c.r[9];  // 0606986C mov r9,r7
    c.r[13] = ld32(c.r[12]);  // 0606986E mov.l @r12,r13
    c.r[10] = (uint32_t)(int16_t)ld16(0x0606995Cu);  // 06069870 mov.w 0x0606995C,r10
    c.r[10] += c.r[14];  // 06069872 add r14,r10
    c.r[12] = (uint32_t)(int16_t)ld16(0x06069962u);  // 06069874 mov.w 0x06069962,r12
    c.r[12] += c.r[14];  // 06069876 add r14,r12
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[13]);  // 06069878 mov.b @(r0,r13),r1
    c.r[10] = ld32(0x06069988u);  // 0606987A mov.l 0x06069988,r10
    c.r[1] = c.r[1] & 0xFFu;  // 0606987C extu.b r1,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0606987E mov.l r1,@-r15
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 06069880 mov.b @(r0,r11),r1
    c.r[13] = (uint32_t)(int16_t)ld16(0x06069964u);  // 06069882 mov.w 0x06069964,r13
    c.r[1] = c.r[1] & 0xFFu;  // 06069884 extu.b r1,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06069886 mov.l r1,@-r15
    c.r[8] = ld32(c.r[12]);  // 06069888 mov.l @r12,r8
    c.r[0] = (uint32_t)(int16_t)ld16(0x06069966u);  // 0606988A mov.w 0x06069966,r0
    c.r[12] = (uint32_t)(int16_t)ld16(0x06069968u);  // 0606988C mov.w 0x06069968,r12
    c.r[12] += c.r[14];  // 0606988E add r14,r12
    c.r[12] = ld32(c.r[12]);  // 06069890 mov.l @r12,r12
    c.r[0] += c.r[14];  // 06069892 add r14,r0
    c.r[8] += c.r[12];  // 06069894 add r12,r8
    c.r[12] = (uint32_t)(int16_t)ld16(0x0606995Au);  // 06069896 mov.w 0x0606995A,r12
    c.r[1] = ld32(c.r[8] + 4);  // 06069898 mov.l @(4,r8),r1
    c.r[12] += c.r[14];  // 0606989A add r14,r12
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0606989C mov.l r1,@-r15
    c.r[15] -= c.r[13];  // 0606989E sub r13,r15
    c.r[4] = c.r[15];  // 060698A0 mov r15,r4
    c.r[13] = (uint32_t)(int16_t)ld16(0x06069960u);  // 060698A2 mov.w 0x06069960,r13
    c.r[5] = ld32(c.r[0]);  // 060698A4 mov.l @r0,r5
    { const uint32_t x = c.r[10]; c.pr = 0x060698AAu; c.r[13] += c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060698AAu) return; }  // 060698A6 jsr @r10 ; add r14,r13
    c.r[6] = ld32(c.r[12]);  // 060698AA mov.l @r12,r6
    c.r[4] = c.r[11];  // 060698AC mov r11,r4
    c.r[0] = ld32(0x0606998Cu);  // 060698AE mov.l 0x0606998C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060698B4u; c.r[5] = ld32(c.r[13]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060698B4u) return; }  // 060698B0 jsr @r0 ; mov.l @r13,r5
    c.r[10] = (uint32_t)(int16_t)ld16(0x06069962u);  // 060698B4 mov.w 0x06069962,r10
    c.r[10] += c.r[14];  // 060698B6 add r14,r10
    c.r[12] = (uint32_t)(int16_t)ld16(0x06069968u);  // 060698B8 mov.w 0x06069968,r12
    c.r[2] = ld32(c.r[8] + 4);  // 060698BA mov.l @(4,r8),r2
    c.r[12] += c.r[14];  // 060698BC add r14,r12
    c.r[0] = ld32(c.r[10]);  // 060698BE mov.l @r10,r0
    c.r[3] = 0x3u;  // 060698C0 mov #3,r3
    c.r[13] = ld32(c.r[12]);  // 060698C2 mov.l @r12,r13
    c.r[2] += 30;  // 060698C4 add #30,r2
    c.r[10] = (uint32_t)(int16_t)ld16(0x0606996Au);  // 060698C6 mov.w 0x0606996A,r10
    c.r[1] = ld32(c.r[0] + c.r[13]);  // 060698C8 mov.l @(r0,r13),r1
    c.r[10] += c.r[14];  // 060698CA add r14,r10
    c.r[1] += 30;  // 060698CC add #30,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060698CE mov.b @r1,r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x0606996Cu);  // 060698D0 mov.w 0x0606996C,r12
    st8(c.r[2], c.r[1]);  // 060698D2 mov.b r1,@r2
    c.r[0] = ld32(c.r[10]);  // 060698D4 mov.l @r10,r0
    c.r[12] += c.r[14];  // 060698D6 add r14,r12
    c.r[13] = ld32(c.r[12]);  // 060698D8 mov.l @r12,r13
    c.r[10] = (uint32_t)(int16_t)ld16(0x0606995Au);  // 060698DA mov.w 0x0606995A,r10
    c.r[2] = ld32(c.r[0] + c.r[13]);  // 060698DC mov.l @(r0,r13),r2
    c.r[10] += c.r[14];  // 060698DE add r14,r10
    c.r[2] += 1;  // 060698E0 add #1,r2
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060698E2 mov.b @r2,r7
    c.r[12] = (uint32_t)(int16_t)ld16(0x0606996Eu);  // 060698E4 mov.w 0x0606996E,r12
    c.r[0] = ld32(c.r[10]);  // 060698E6 mov.l @r10,r0
    c.r[12] += c.r[14];  // 060698E8 add r14,r12
    c.r[13] = ld32(c.r[12]);  // 060698EA mov.l @r12,r13
    c.r[1] = c.r[7];  // 060698EC mov r7,r1
    c.r[1] >>= 2;  // 060698EE shlr2 r1
    c.r[1] >>= 2;  // 060698F0 shlr2 r1
    c.r[3] &= c.r[1];  // 060698F2 and r1,r3
    c.r[10] = (uint32_t)(int16_t)ld16(0x06069970u);  // 060698F4 mov.w 0x06069970,r10
    c.r[15] += c.r[10];  // 060698F6 add r10,r15
    c.r[10] = (uint32_t)(int16_t)ld16(0x0606996Au);  // 060698F8 mov.w 0x0606996A,r10
    c.r[10] += c.r[14];  // 060698FA add r14,r10
    c.r[12] = (uint32_t)(int16_t)ld16(0x0606996Cu);  // 060698FC mov.w 0x0606996C,r12
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[13]);  // 060698FE mov.b @(r0,r13),r1
    c.r[12] += c.r[14];  // 06069900 add r14,r12
    c.r[6] = c.r[1];  // 06069902 mov r1,r6
    c.t = c.r[6] & 1; c.r[6] >>= 1;  // 06069904 shlr r6
    c.r[0] = 0x2u;  // 06069906 mov #2,r0
    c.r[6] &= c.r[0];  // 06069908 and r0,r6
    c.r[6] |= c.r[3];  // 0606990A or r3,r6
    c.r[6] <<= 2;  // 0606990C shll2 r6
    c.r[6] <<= 2;  // 0606990E shll2 r6
    c.r[1] = (uint32_t)(int16_t)ld16(0x06069972u);  // 06069910 mov.w 0x06069972,r1
    c.r[1] &= c.r[7];  // 06069912 and r7,r1
    c.r[1] |= c.r[6];  // 06069914 or r6,r1
    st8(c.r[2], c.r[1]);  // 06069916 mov.b r1,@r2
    c.r[7] = 0x0u;  // 06069918 mov #0,r7
    c.r[0] = ld32(c.r[10]);  // 0606991A mov.l @r10,r0
    c.r[6] = 0x3u;  // 0606991C mov #3,r6
    c.r[13] = ld32(c.r[12]);  // 0606991E mov.l @r12,r13
    c.r[10] = ld32(0x06069990u);  // 06069920 mov.l 0x06069990,r10
    c.r[9] = ld32(c.r[0] + c.r[13]);  // 06069922 mov.l @(r0,r13),r9
    c.r[12] = 0x0u;  // 06069924 mov #0,r12
    c.r[5] = ld32(c.r[10]);  // 06069926 mov.l @r10,r5
    c.r[1] = c.r[9];  // 06069928 mov r9,r1
    c.r[1] += 1;  // 0606992A add #1,r1
    c.r[0] = 0x3u;  // 0606992C mov #3,r0
    c.r[10] = (uint32_t)(int16_t)ld16(0x06069974u);  // 0606992E mov.w 0x06069974,r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06069930 mov.b @r1,r1
    c.r[10] += c.r[14];  // 06069932 add r14,r10
    c.r[8] = c.r[1];  // 06069934 mov r1,r8
    c.r[8] >>= 2;  // 06069936 shlr2 r8
    c.r[8] &= c.r[0];  // 06069938 and r0,r8
    c.r[0] = ld32(c.r[10]);  // 0606993A mov.l @r10,r0
    c.r[5] += 20;  // 0606993C add #20,r5
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[14]);  // 0606993E mov.w @(r0,r14),r4
    c.r[13] = ld32(0x06069994u);  // 06069940 mov.l 0x06069994,r13
    c.r[4] = c.r[4] & 0xFFFFu;  // 06069942 extu.w r4,r4
    { const uint32_t x = c.r[13]; c.pr = 0x06069948u; c.r[15] -= 4; st32(c.r[15], c.r[12]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06069948u) return; }  // 06069944 jsr @r13 ; mov.l r12,@-r15
    c.r[1] = c.r[0];  // 06069948 mov r0,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0606994A extu.w r1,r1
    c.r[0] = 0x1u;  // 0606994C mov #1,r0
    c.t = c.r[1] > c.r[0];  // 0606994E cmp/hi r0,r1
    { const bool k = c.t; c.r[15] += 4; if (k) { goto L_06069998; } }  // 06069950 bt/s 0x06069998 ; add #4,r15
    c.r[1] = 0x2u;  // 06069954 mov #2,r1
    c.r[1] |= c.r[8]; goto L_0606999A;  // 06069956 bra 0x0606999A ; or r8,r1
L_06069998:
    c.r[1] = c.r[8];  // 06069998 mov r8,r1
L_0606999A:
    c.r[2] = c.r[9];  // 0606999A mov r9,r2
    c.r[2] += 1;  // 0606999C add #1,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606999E mov.b @r2,r0
    c.r[1] <<= 2;  // 060699A0 shll2 r1
    c.r[0] &= 0xF3u;  // 060699A2 and #243,r0
    c.r[0] |= c.r[1];  // 060699A4 or r1,r0
    st8(c.r[2], c.r[0]);  // 060699A6 mov.b r0,@r2
L_060699A8:
    c.r[1] = ld32(0x06069B7Cu);  // 060699A8 mov.l 0x06069B7C,r1
    c.r[0] = c.r[11];  // 060699AA mov r11,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060699AC mov.b @(r0,r1),r2
    c.r[10] = 0x1u;  // 060699AE mov #1,r10
    c.r[1] = c.r[2];  // 060699B0 mov r2,r1
    c.r[1] += 4;  // 060699B2 add #4,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060699B4 extu.b r1,r1
    c.t = c.r[1] > c.r[10];  // 060699B6 cmp/hi r10,r1
    { const bool k = !c.t; c.r[1] = c.r[11]; if (k) { goto L_06069A78; } }  // 060699B8 bf/s 0x06069A78 ; mov r11,r1
    c.r[2] = c.r[2] & 0xFFu;  // 060699BC extu.b r2,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06069B60u);  // 060699BE mov.w 0x06069B60,r1
    c.t = c.r[2] == c.r[1];  // 060699C0 cmp/eq r1,r2
    { const bool k = c.t; c.r[1] = c.r[11]; if (k) { goto L_06069A78; } }  // 060699C2 bt/s 0x06069A78 ; mov r11,r1
    c.r[8] = (uint32_t)(int16_t)ld16(0x06069B62u);  // 060699C6 mov.w 0x06069B62,r8
    c.r[10] = (uint32_t)(int16_t)ld16(0x06069B64u);  // 060699C8 mov.w 0x06069B64,r10
    c.r[10] += c.r[14];  // 060699CA add r14,r10
    c.r[0] = ld32(c.r[10]);  // 060699CC mov.l @r10,r0
    c.r[8] += c.r[14];  // 060699CE add r14,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 060699D0 mov.b @(r0,r8),r1
    c.r[6] = c.r[1] & 0xFFu;  // 060699D2 extu.b r1,r6
    c.r[1] = (uint32_t)(int16_t)ld16(0x06069B66u);  // 060699D4 mov.w 0x06069B66,r1
    c.t = c.r[6] == c.r[1];  // 060699D6 cmp/eq r1,r6
    { const bool k = c.t; c.r[2] = c.r[6]; if (k) { goto L_06069A28; } }  // 060699D8 bt/s 0x06069A28 ; mov r6,r2
    c.r[12] = ld32(0x06069B80u);  // 060699DC mov.l 0x06069B80,r12
    c.r[2] <<= 2;  // 060699DE shll2 r2
    c.r[2] <<= 2;  // 060699E0 shll2 r2
    c.r[4] = (uint32_t)(int16_t)ld16(0x06069B68u);  // 060699E2 mov.w 0x06069B68,r4
    c.r[1] = ld32(c.r[12]);  // 060699E4 mov.l @r12,r1
    c.r[4] += c.r[14];  // 060699E6 add r14,r4
    c.r[2] += c.r[1];  // 060699E8 add r1,r2
    c.r[2] += 2;  // 060699EA add #2,r2
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060699EC mov.b @r2,r5
    c.r[13] = ld32(0x06069B84u);  // 060699EE mov.l 0x06069B84,r13
    { const uint32_t x = c.r[13]; c.pr = 0x060699F4u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060699F4u) return; }  // 060699F0 jsr @r13 ; extu.b r5,r5
    c.r[10] = (uint32_t)(int16_t)ld16(0x06069B64u);  // 060699F4 mov.w 0x06069B64,r10
    c.r[10] += c.r[14];  // 060699F6 add r14,r10
    c.r[0] = ld32(c.r[10]);  // 060699F8 mov.l @r10,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 060699FA mov.b @(r0,r8),r1
    c.r[2] = ld32(c.r[12]);  // 060699FC mov.l @r12,r2
    c.r[1] = c.r[1] & 0xFFu;  // 060699FE extu.b r1,r1
    c.r[1] <<= 2;  // 06069A00 shll2 r1
    c.r[1] <<= 2;  // 06069A02 shll2 r1
    c.r[1] += c.r[2];  // 06069A04 add r2,r1
    c.r[1] += 2;  // 06069A06 add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06069A08 mov.b @r1,r2
    c.r[1] = ld32(0x06069B88u);  // 06069A0A mov.l 0x06069B88,r1
    c.r[3] = ld32(c.r[1]);  // 06069A0C mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06069A0E extu.b r2,r2
    c.r[1] = 0x1Eu;  // 06069A10 mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 06069A12 mul.l r1,r2
    c.r[4] = c.r[14];  // 06069A14 mov r14,r4
    c.r[1] = c.macl;  // 06069A16 sts macl,r1
    c.r[1] += c.r[3];  // 06069A18 add r3,r1
    c.r[1] += 15;  // 06069A1A add #15,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06069A1C mov.b @r1,r5
    c.r[2] = ld32(0x06069B8Cu);  // 06069A1E mov.l 0x06069B8C,r2
    c.r[5] = c.r[5] & 0xFFu;  // 06069A20 extu.b r5,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x06069B6Au);  // 06069A22 mov.w 0x06069B6A,r1
    { const uint32_t x = c.r[2]; c.pr = 0x06069A28u; c.r[4] += c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06069A28u) return; }  // 06069A24 jsr @r2 ; add r1,r4
L_06069A28:
    c.r[2] = (uint32_t)(int16_t)ld16(0x06069B6Cu);  // 06069A28 mov.w 0x06069B6C,r2
    c.r[2] += c.r[14];  // 06069A2A add r14,r2
    c.r[12] = (uint32_t)(int16_t)ld16(0x06069B64u);  // 06069A2C mov.w 0x06069B64,r12
    c.r[12] += c.r[14];  // 06069A2E add r14,r12
    c.r[0] = c.r[2];  // 06069A30 mov r2,r0
    c.r[10] = (uint32_t)(int16_t)ld16(0x06069B6Eu);  // 06069A32 mov.w 0x06069B6E,r10
    c.r[1] = ld32(c.r[12]);  // 06069A34 mov.l @r12,r1
    c.r[10] += c.r[14];  // 06069A36 add r14,r10
    c.r[1] <<= 2;  // 06069A38 shll2 r1
    c.r[1] += c.r[1];  // 06069A3A add r1,r1
    c.r[5] = ld32(c.r[0] + c.r[1]);  // 06069A3C mov.l @(r0,r1),r5
    c.r[6] = c.r[11];  // 06069A3E mov r11,r6
    c.r[1] = c.r[11];  // 06069A40 mov r11,r1
    c.r[1] <<= 2;  // 06069A42 shll2 r1
    c.r[0] = ld32(c.r[10]);  // 06069A44 mov.l @r10,r0
    c.r[1] += c.r[14];  // 06069A46 add r14,r1
    c.r[10] = (uint32_t)(int16_t)ld16(0x06069B64u);  // 06069A48 mov.w 0x06069B64,r10
    c.r[4] = ld32(c.r[0] + c.r[1]);  // 06069A4A mov.l @(r0,r1),r4
    c.r[10] += c.r[14];  // 06069A4C add r14,r10
    c.r[0] = ld32(c.r[10]);  // 06069A4E mov.l @r10,r0
    c.r[12] = (uint32_t)(int16_t)ld16(0x06069B64u);  // 06069A50 mov.w 0x06069B64,r12
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 06069A52 mov.b @(r0,r8),r1
    c.r[12] += c.r[14];  // 06069A54 add r14,r12
    c.r[1] = c.r[1] & 0xFFu;  // 06069A56 extu.b r1,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06069A58 mov.l r1,@-r15
    c.r[1] = (uint32_t)(int16_t)ld16(0x06069B6Au);  // 06069A5A mov.w 0x06069B6A,r1
    c.r[1] += c.r[14];  // 06069A5C add r14,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06069A5E mov.l r1,@-r15
    c.r[1] = (uint32_t)(int16_t)ld16(0x06069B68u);  // 06069A60 mov.w 0x06069B68,r1
    c.r[1] += c.r[14];  // 06069A62 add r14,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06069A64 mov.l r1,@-r15
    c.r[1] = (uint32_t)(int16_t)ld16(0x06069B70u);  // 06069A66 mov.w 0x06069B70,r1
    c.r[1] += c.r[14];  // 06069A68 add r14,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06069A6A mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06069A6C mov.l r14,@-r15
    c.r[1] = ld32(0x06069B90u);  // 06069A6E mov.l 0x06069B90,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06069A74u; c.r[7] = ld32(c.r[12]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06069A74u) return; }  // 06069A70 jsr @r1 ; mov.l @r12,r7
    c.r[15] += 20;  // 06069A74 add #20,r15
    c.r[1] = c.r[11];  // 06069A76 mov r11,r1
L_06069A78:
    c.r[1] += 1;  // 06069A78 add #1,r1
    c.r[11] = c.r[1] & 0xFFu;  // 06069A7A extu.b r1,r11
    c.r[13] = 0x1u;  // 06069A7C mov #1,r13
    c.t = c.r[11] > c.r[13];  // 06069A7E cmp/hi r13,r11
    { const bool k = c.t; c.r[1] = c.r[11]; if (k) { goto L_06069A88; } }  // 06069A80 bt/s 0x06069A88 ; mov r11,r1
    SH2_POLL(c); goto L_0606938E;  // 06069A84 bra 0x0606938E ; nop
L_06069A88:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06069B72u);  // 06069A88 mov.w 0x06069B72,r0
    c.r[1] = ld32(c.r[0] + c.r[14]);  // 06069A8A mov.l @(r0,r14),r1
    c.r[3] = c.r[14];  // 06069A8C mov r14,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06069A8E mov.b @r1,r1
    c.r[3] += c.r[0];  // 06069A90 add r0,r3
    c.r[0] = c.r[1];  // 06069A92 mov r1,r0
    c.r[0] >>= 2;  // 06069A94 shlr2 r0
    c.r[0] >>= 2;  // 06069A96 shlr2 r0
    c.r[0] &= 0x1u;  // 06069A98 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06069A9A tst r0,r0
    { const bool k = c.t; c.r[11] = 0x0u; if (k) { goto L_06069ABA; } }  // 06069A9C bt/s 0x06069ABA ; mov #0,r11
    c.r[1] = (uint32_t)(int16_t)ld16(0x06069B62u);  // 06069AA0 mov.w 0x06069B62,r1
    c.r[1] += c.r[14];  // 06069AA2 add r14,r1
    c.r[1] += 1;  // 06069AA4 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06069AA6 mov.b @r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06069B66u);  // 06069AA8 mov.w 0x06069B66,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06069AAA extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 06069AAC cmp/eq r2,r1
    if (!c.t) { goto L_06069ABA; }  // 06069AAE bf 0x06069ABA
    c.r[1] = ld32(c.r[3] + 4);  // 06069AB0 mov.l @(4,r3),r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06069AB2 mov.b @r1,r0
    c.r[0] &= 0xEFu;  // 06069AB4 and #239,r0
    st8(c.r[1], c.r[0]);  // 06069AB6 mov.b r0,@r1
    c.r[11] = 0x0u;  // 06069AB8 mov #0,r11
L_06069ABA:
    c.r[4] = (uint32_t)(int16_t)ld16(0x06069B72u);  // 06069ABA mov.w 0x06069B72,r4
    c.r[5] = (uint32_t)(int16_t)ld16(0x06069B6Cu);  // 06069ABC mov.w 0x06069B6C,r5
    c.r[5] += c.r[14];  // 06069ABE add r14,r5
    c.r[6] = c.r[11];  // 06069AC0 mov r11,r6
L_06069AC2:
    c.r[6] <<= 2;  // 06069AC2 shll2 r6
    c.r[6] += c.r[14];  // 06069AC4 add r14,r6
    c.r[0] = c.r[6];  // 06069AC6 mov r6,r0
    c.r[1] = ld32(c.r[0] + c.r[4]);  // 06069AC8 mov.l @(r0,r4),r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06069ACA mov.b @r1,r1
    c.r[10] = 0x1u;  // 06069ACC mov #1,r10
    c.r[1] >>= 2;  // 06069ACE shlr2 r1
    c.r[1] >>= 2;  // 06069AD0 shlr2 r1
    c.r[1] >>= 2;  // 06069AD2 shlr2 r1
    c.r[1] &= c.r[10];  // 06069AD4 and r10,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06069AD6 tst r1,r1
    { const bool k = !c.t; c.r[1] = c.r[11]; if (k) { goto L_06069B1A; } }  // 06069AD8 bf/s 0x06069B1A ; mov r11,r1
    c.r[7] = c.r[11];  // 06069ADC mov r11,r7
    c.r[7] <<= 2;  // 06069ADE shll2 r7
    c.r[7] += c.r[7];  // 06069AE0 add r7,r7
    c.r[3] = c.r[5];  // 06069AE2 mov r5,r3
    c.r[3] += c.r[7];  // 06069AE4 add r7,r3
    c.r[1] = ld32(c.r[3] + 4);  // 06069AE6 mov.l @(4,r3),r1
    c.r[0] = c.r[5];  // 06069AE8 mov r5,r0
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06069AEA mov.b @r1,r8
    c.r[10] = (uint32_t)(int16_t)ld16(0x06069B74u);  // 06069AEC mov.w 0x06069B74,r10
    c.r[2] = ld32(c.r[0] + c.r[7]);  // 06069AEE mov.l @(r0,r7),r2
    c.r[8] &= c.r[10];  // 06069AF0 and r10,r8
    st8(c.r[1], c.r[8]);  // 06069AF2 mov.b r8,@r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06069AF4 mov.b @r2,r1
    c.r[1] &= c.r[10];  // 06069AF6 and r10,r1
    st8(c.r[2], c.r[1]);  // 06069AF8 mov.b r1,@r2
    c.r[1] = ld32(c.r[3] + 4);  // 06069AFA mov.l @(4,r3),r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06069AFC mov.b @r1,r3
    c.r[12] = (uint32_t)(int16_t)ld16(0x06069B76u);  // 06069AFE mov.w 0x06069B76,r12
    c.r[2] = ld32(c.r[0] + c.r[7]);  // 06069B00 mov.l @(r0,r7),r2
    c.r[3] &= c.r[12];  // 06069B02 and r12,r3
    st8(c.r[1], c.r[3]);  // 06069B04 mov.b r3,@r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06069B06 mov.b @r2,r1
    c.r[0] = c.r[6];  // 06069B08 mov r6,r0
    c.r[1] &= c.r[12];  // 06069B0A and r12,r1
    st8(c.r[2], c.r[1]);  // 06069B0C mov.b r1,@r2
    c.r[1] = ld32(c.r[0] + c.r[4]);  // 06069B0E mov.l @(r0,r4),r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06069B10 mov.b @r1,r2
    c.r[10] = (uint32_t)(int16_t)ld16(0x06069B78u);  // 06069B12 mov.w 0x06069B78,r10
    c.r[2] &= c.r[10];  // 06069B14 and r10,r2
    st8(c.r[1], c.r[2]);  // 06069B16 mov.b r2,@r1
    c.r[1] = c.r[11];  // 06069B18 mov r11,r1
L_06069B1A:
    c.r[1] += 1;  // 06069B1A add #1,r1
    c.r[11] = c.r[1] & 0xFFu;  // 06069B1C extu.b r1,r11
    c.r[1] = 0x1u;  // 06069B1E mov #1,r1
    c.t = c.r[11] > c.r[1];  // 06069B20 cmp/hi r1,r11
    { const bool k = !c.t; c.r[6] = c.r[11]; if (k) { SH2_POLL(c); goto L_06069AC2; } }  // 06069B22 bf/s 0x06069AC2 ; mov r11,r6
    c.r[5] = (uint32_t)(int16_t)ld16(0x06069B6Cu);  // 06069B26 mov.w 0x06069B6C,r5
    c.r[5] += c.r[14];  // 06069B28 add r14,r5
    c.r[4] = (uint32_t)(int16_t)ld16(0x06069B72u);  // 06069B2A mov.w 0x06069B72,r4
    c.r[1] = ld32(0x06069B94u);  // 06069B2C mov.l 0x06069B94,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06069B32u; c.r[4] += c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06069B32u) return; }  // 06069B2E jsr @r1 ; add r14,r4
    c.r[1] = ld32(0x06069B98u);  // 06069B32 mov.l 0x06069B98,r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x06069B7Au);  // 06069B34 mov.w 0x06069B7A,r12
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06069B36 mov.b @r1,r2
    c.r[3] = ld32(0x06069B9Cu);  // 06069B38 mov.l 0x06069B9C,r3
    c.r[2] &= c.r[12];  // 06069B3A and r12,r2
    st8(c.r[1], c.r[2]);  // 06069B3C mov.b r2,@r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06069B3E mov.b @r3,r1
    c.r[6] = c.r[1] & 0xFFu;  // 06069B40 extu.b r1,r6
    c.r[1] = ld32(0x06069B80u);  // 06069B42 mov.l 0x06069B80,r1
    c.r[7] = ld32(c.r[1]);  // 06069B44 mov.l @r1,r7
    c.r[6] <<= 2;  // 06069B46 shll2 r6
    c.r[6] <<= 2;  // 06069B48 shll2 r6
    c.r[6] += c.r[7];  // 06069B4A add r7,r6
    c.r[1] = c.r[6];  // 06069B4C mov r6,r1
    c.r[1] += 3;  // 06069B4E add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06069B50 mov.b @r1,r1
    c.r[13] = 0x3u;  // 06069B52 mov #3,r13
    c.r[2] = c.r[1];  // 06069B54 mov r1,r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 06069B56 shlr r2
    c.r[2] &= c.r[13];  // 06069B58 and r13,r2
    c.r[0] = c.r[2];  // 06069B5A mov r2,r0
    c.t = c.r[0] == 0x1u; goto L_06069BA0;  // 06069B5C bra 0x06069BA0 ; cmp/eq #1,r0
L_06069BA0:
    { const bool k = c.t; c.t = c.r[0] == 0x2u; if (k) { goto L_06069BE6; } }  // 06069BA0 bt/s 0x06069BE6 ; cmp/eq #2,r0
    { const bool k = !c.t; c.r[1] = c.r[3]; if (k) { goto L_06069BC2; } }  // 06069BA4 bf/s 0x06069BC2 ; mov r3,r1
    c.r[1] += 1;  // 06069BA8 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06069BAA mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06069BAC extu.b r1,r1
    c.r[1] <<= 2;  // 06069BAE shll2 r1
    c.r[1] <<= 2;  // 06069BB0 shll2 r1
    c.r[1] += c.r[7];  // 06069BB2 add r7,r1
    c.r[1] += 3;  // 06069BB4 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06069BB6 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06069BB8 mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06069BBA shlr r0
    c.r[0] &= 0x3u;  // 06069BBC and #3,r0
    c.t = c.r[0] == 0x1u;  // 06069BBE cmp/eq #1,r0
    if (!c.t) { goto L_06069BE6; }  // 06069BC0 bf 0x06069BE6
L_06069BC2:
    c.t = (c.r[2] & c.r[2]) == 0;  // 06069BC2 tst r2,r2
    if (!c.t) { goto L_06069BEE; }  // 06069BC4 bf 0x06069BEE
    c.r[1] = ld32(c.r[6] + 12);  // 06069BC6 mov.l @(12,r6),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06069BC8 tst r1,r1
    if (c.t) { goto L_06069BEE; }  // 06069BCA bt 0x06069BEE
    c.r[3] += 1;  // 06069BCC add #1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06069BCE mov.b @r3,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06069BD0 extu.b r1,r1
    c.r[1] <<= 2;  // 06069BD2 shll2 r1
    c.r[1] <<= 2;  // 06069BD4 shll2 r1
    c.r[1] += c.r[7];  // 06069BD6 add r7,r1
    c.r[1] += 3;  // 06069BD8 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06069BDA mov.b @r1,r1
    c.r[0] = c.r[1];  // 06069BDC mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06069BDE shlr r0
    c.r[0] &= 0x3u;  // 06069BE0 and #3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06069BE2 tst r0,r0
    if (!c.t) { goto L_06069BEE; }  // 06069BE4 bf 0x06069BEE
L_06069BE6:
    c.r[1] = ld32(0x06069C88u);  // 06069BE6 mov.l 0x06069C88,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06069BE8 mov.b @r1,r0
    c.r[0] |= 0x80u; goto L_06069BF4;  // 06069BEA bra 0x06069BF4 ; or #128,r0
L_06069BEE:
    c.r[1] = ld32(0x06069C88u);  // 06069BEE mov.l 0x06069C88,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06069BF0 mov.b @r1,r0
    c.r[0] &= 0x7Fu;  // 06069BF2 and #127,r0
L_06069BF4:
    st8(c.r[1], c.r[0]);  // 06069BF4 mov.b r0,@r1
    c.r[3] = ld32(0x06069C88u);  // 06069BF6 mov.l 0x06069C88,r3
    c.r[1] = ld32(0x06069C8Cu);  // 06069BF8 mov.l 0x06069C8C,r1
    c.r[7] = 0x3u;  // 06069BFA mov #3,r7
    c.r[2] = (uint32_t)(int16_t)ld16(0x06069C7Cu);  // 06069BFC mov.w 0x06069C7C,r2
    c.r[0] = c.r[14];  // 06069BFE mov r14,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06069C00 mov.b @r1,r1
    c.r[10] = 0x1u;  // 06069C02 mov #1,r10
    c.r[7] &= c.r[1];  // 06069C04 and r1,r7
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06069C06 mov.w @r3,r1
    c.r[7] <<= 2;  // 06069C08 shll2 r7
    c.r[7] <<= 2;  // 06069C0A shll2 r7
    c.r[7] += c.r[7];  // 06069C0C add r7,r7
    c.r[7] <<= 2;  // 06069C0E shll2 r7
    c.r[1] &= c.r[2];  // 06069C10 and r2,r1
    c.r[1] |= c.r[7];  // 06069C12 or r7,r1
    st16(c.r[3], c.r[1]);  // 06069C14 mov.w r1,@r3
    c.r[2] = (uint32_t)(int16_t)ld16(0x06069C7Eu);  // 06069C16 mov.w 0x06069C7E,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06069C18 mov.b @(r0,r2),r1
    c.r[1] >>= 2;  // 06069C1A shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06069C1C shlr r1
    c.r[1] &= c.r[10];  // 06069C1E and r10,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06069C20 tst r1,r1
    { const bool k = !c.t; c.r[3] += 2; if (k) { goto L_06069C38; } }  // 06069C22 bf/s 0x06069C38 ; add #2,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x06069C80u);  // 06069C26 mov.w 0x06069C80,r1
    c.r[1] += c.r[14];  // 06069C28 add r14,r1
    c.r[0] = c.r[1];  // 06069C2A mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06069C2C mov.b @(r0,r2),r1
    c.r[1] >>= 2;  // 06069C2E shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06069C30 shlr r1
    c.r[1] &= c.r[10];  // 06069C32 and r10,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06069C34 tst r1,r1
    if (c.t) { goto L_06069C50; }  // 06069C36 bt 0x06069C50
L_06069C38:
    c.r[1] = ld32(0x06069C90u);  // 06069C38 mov.l 0x06069C90,r1
    c.r[1] = ld32(c.r[1]);  // 06069C3A mov.l @r1,r1
    c.r[1] += 18;  // 06069C3C add #18,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06069C3E mov.w @r1,r1
    c.r[1] <<= 16;  // 06069C40 shll16 r1
    c.r[1] <<= 2;  // 06069C42 shll2 r1
    c.r[1] += c.r[1];  // 06069C44 add r1,r1
    c.r[1] <<= 2;  // 06069C46 shll2 r1
    c.r[1] >>= 16;  // 06069C48 shlr16 r1
    c.r[1] <<= 2;  // 06069C4A shll2 r1
    c.r[1] >>= 8; goto L_06069C52;  // 06069C4C bra 0x06069C52 ; shlr8 r1
L_06069C50:
    c.r[1] = 0x0u;  // 06069C50 mov #0,r1
L_06069C52:
    st16(c.r[3], c.r[1]);  // 06069C52 mov.w r1,@r3
    c.r[1] = ld32(0x06069C94u);  // 06069C54 mov.l 0x06069C94,r1
    c.r[3] = ld32(c.r[1]);  // 06069C56 mov.l @r1,r3
    c.r[2] = c.r[3];  // 06069C58 mov r3,r2
    c.r[2] += 2;  // 06069C5A add #2,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06069C82u);  // 06069C5C mov.w 0x06069C82,r1
    st16(c.r[2], c.r[1]);  // 06069C5E mov.w r1,@r2
    st16(c.r[3], c.r[1]);  // 06069C60 mov.w r1,@r3
    c.r[3] = (uint32_t)(int16_t)ld16(0x06069C84u);  // 06069C62 mov.w 0x06069C84,r3
    c.r[14] += c.r[3];  // 06069C64 add r3,r14
    c.r[15] = c.r[14];  // 06069C66 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06069C68 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06069C6A mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06069C6C mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06069C6E mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06069C70 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06069C72 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06069C74 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06069C86u);  // 06069C76 mov.w 0x06069C86,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06069C78 rts ; mov.l @r15+,r8
}

}  // namespace p_srwfin_installed
