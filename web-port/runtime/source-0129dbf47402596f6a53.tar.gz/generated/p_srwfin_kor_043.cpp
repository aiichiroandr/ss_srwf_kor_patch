#include "p_srwfin_kor_funcs.h"

namespace p_srwfin_kor {

void f_060B7000(SH2Context& c) {
    ran[3134] = 1;
    goto L_060B7000;
L_060B6DFE:
    c.mach = c.macl = 0;  // 060B6DFE clrmac
L_060B6E00:
    sh2_mac_l(c, 6, 7);  // 060B6E00 mac.l @r7+,@r6+
L_060B6E02:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[7] + 8);  // 060B6E02 mov.w @(8,r7),r0
L_060B6E04:
    c.r[5] = c.r[15];  // 060B6E04 mov r15,r5
L_060B6E06:
    sh2_mac_l(c, 6, 7);  // 060B6E06 mac.l @r7+,@r6+
L_060B6E08:
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B6E08 exts.w r0,r1
L_060B6E0A:
    c.r[1] <<= 2;  // 060B6E0A shll2 r1
L_060B6E0C:
    sh2_mac_l(c, 6, 7);  // 060B6E0C mac.l @r7+,@r6+
L_060B6E0E:
    c.r[6] += 4;  // 060B6E0E add #4,r6
L_060B6E10:
    c.r[7] -= 12;  // 060B6E10 add #-12,r7
L_060B6E12:
    c.r[1] <<= 2;  // 060B6E12 shll2 r1
L_060B6E14:
    c.r[0] = c.mach;  // 060B6E14 sts mach,r0
L_060B6E16:
    c.r[13] = c.macl;  // 060B6E16 sts macl,r13
L_060B6E18:
    c.mach = c.macl = 0;  // 060B6E18 clrmac
L_060B6E1A:
    sh2_mac_l(c, 6, 7);  // 060B6E1A mac.l @r7+,@r6+
L_060B6E1C:
    c.r[13] = c.r[0] << 16 | c.r[13] >> 16;  // 060B6E1C xtrct r0,r13
L_060B6E1E:
    st32(c.r[5], c.r[13]);  // 060B6E1E mov.l r13,@(0,r5)
L_060B6E20:
    sh2_mac_l(c, 6, 7);  // 060B6E20 mac.l @r7+,@r6+
L_060B6E22:
    c.r[1] += c.r[10];  // 060B6E22 add r10,r1
L_060B6E24:
    c.r[4] = 0x4u;  // 060B6E24 mov #4,r4
L_060B6E26:
    sh2_mac_l(c, 6, 7);  // 060B6E26 mac.l @r7+,@r6+
L_060B6E28:
    c.r[6] += 4;  // 060B6E28 add #4,r6
L_060B6E2A:
    c.r[7] -= 12;  // 060B6E2A add #-12,r7
L_060B6E2C:
    c.r[4] += c.r[1];  // 060B6E2C add r1,r4
L_060B6E2E:
    c.r[0] = c.mach;  // 060B6E2E sts mach,r0
L_060B6E30:
    c.r[2] = c.macl;  // 060B6E30 sts macl,r2
L_060B6E32:
    c.mach = c.macl = 0;  // 060B6E32 clrmac
L_060B6E34:
    sh2_mac_l(c, 6, 7);  // 060B6E34 mac.l @r7+,@r6+
L_060B6E36:
    c.r[2] = c.r[0] << 16 | c.r[2] >> 16;  // 060B6E36 xtrct r0,r2
L_060B6E38:
    st32(c.r[5] + 4, c.r[2]);  // 060B6E38 mov.l r2,@(4,r5)
L_060B6E3A:
    sh2_mac_l(c, 6, 7);  // 060B6E3A mac.l @r7+,@r6+
L_060B6E3C:
    c.r[12] = (uint32_t)(int16_t)ld16(c.r[8]);  // 060B6E3C mov.w @r8,r12
L_060B6E3E:
    c.r[9] = 0x7Fu;  // 060B6E3E mov #127,r9
L_060B6E40:
    sh2_mac_l(c, 6, 7);  // 060B6E40 mac.l @r7+,@r6+
L_060B6E42:
    c.r[6] -= 44;  // 060B6E42 add #-44,r6
L_060B6E44:
    c.r[9] &= c.r[12];  // 060B6E44 and r12,r9
L_060B6E46:
    c.r[9] <<= 2;  // 060B6E46 shll2 r9
L_060B6E48:
    c.r[0] = c.mach;  // 060B6E48 sts mach,r0
L_060B6E4A:
    c.r[3] = c.macl;  // 060B6E4A sts macl,r3
L_060B6E4C:
    c.mach = c.macl = 0;  // 060B6E4C clrmac
L_060B6E4E:
    sh2_mac_l(c, 5, 4);  // 060B6E4E mac.l @r4+,@r5+
L_060B6E50:
    c.r[3] = c.r[0] << 16 | c.r[3] >> 16;  // 060B6E50 xtrct r0,r3
L_060B6E52:
    c.r[0] = 0x060B7144u;  // 060B6E52 mova 0x060B7144,r0
L_060B6E54:
    sh2_mac_l(c, 5, 4);  // 060B6E54 mac.l @r4+,@r5+
L_060B6E56:
    st32(c.r[5], c.r[3]);  // 060B6E56 mov.l r3,@r5
L_060B6E58:
    c.r[9] <<= 2;  // 060B6E58 shll2 r9
L_060B6E5A:
    sh2_mac_l(c, 5, 4);  // 060B6E5A mac.l @r4+,@r5+
L_060B6E5C:
    c.r[9] += c.r[0];  // 060B6E5C add r0,r9
L_060B6E5E:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[8] + 10);  // 060B6E5E mov.w @(10,r8),r0
L_060B6E60:
    c.r[7] += 2;  // 060B6E60 add #2,r7
L_060B6E62:
    c.r[4] = c.mach;  // 060B6E62 sts mach,r4
L_060B6E64:
    st16(c.r[11], c.r[0]);  // 060B6E64 mov.w r0,@(0,r11)
L_060B6E66:
    c.r[0] = ld32(c.gbr + 900);  // 060B6E66 mov.l @(900,gbr),r0
L_060B6E68:
    c.t = (int32_t)c.r[4] >= (int32_t)c.r[0];  // 060B6E68 cmp/ge r0,r4
L_060B6E6A:
    { const bool k = c.t; c.r[0] = (c.r[12] & 0xFFFF0000u) | (c.r[12] & 0xFFu) << 8 | (c.r[12] >> 8 & 0xFFu); if (k) { goto L_060B6E76; } }  // 060B6E6A bt/s 0x060B6E76 ; swap.b r12,r0
L_060B6E6E:
    c.r[0] = ld32(c.r[9]); c.r[9] += 4;  // 060B6E6E mov.l @r9+,r0
L_060B6E70:
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 060B6E70 mov.w @r7+,r2
L_060B6E72:
    { const uint32_t x = c.r[0]; c.r[2] <<= 2; SH2_POLL(c); switch (x) { case 0x060B6DFEu: goto L_060B6DFE; case 0x060B6E00u: goto L_060B6E00; case 0x060B6E02u: goto L_060B6E02; case 0x060B6E04u: goto L_060B6E04; case 0x060B6E06u: goto L_060B6E06; case 0x060B6E08u: goto L_060B6E08; case 0x060B6E0Au: goto L_060B6E0A; case 0x060B6E0Cu: goto L_060B6E0C; case 0x060B6E0Eu: goto L_060B6E0E; case 0x060B6E10u: goto L_060B6E10; case 0x060B6E12u: goto L_060B6E12; case 0x060B6E14u: goto L_060B6E14; case 0x060B6E16u: goto L_060B6E16; case 0x060B6E18u: goto L_060B6E18; case 0x060B6E1Au: goto L_060B6E1A; case 0x060B6E1Cu: goto L_060B6E1C; case 0x060B6E1Eu: goto L_060B6E1E; case 0x060B6E20u: goto L_060B6E20; case 0x060B6E22u: goto L_060B6E22; case 0x060B6E24u: goto L_060B6E24; case 0x060B6E26u: goto L_060B6E26; case 0x060B6E28u: goto L_060B6E28; case 0x060B6E2Au: goto L_060B6E2A; case 0x060B6E2Cu: goto L_060B6E2C; case 0x060B6E2Eu: goto L_060B6E2E; case 0x060B6E30u: goto L_060B6E30; case 0x060B6E32u: goto L_060B6E32; case 0x060B6E34u: goto L_060B6E34; case 0x060B6E36u: goto L_060B6E36; case 0x060B6E38u: goto L_060B6E38; case 0x060B6E3Au: goto L_060B6E3A; case 0x060B6E3Cu: goto L_060B6E3C; case 0x060B6E3Eu: goto L_060B6E3E; case 0x060B6E40u: goto L_060B6E40; case 0x060B6E42u: goto L_060B6E42; case 0x060B6E44u: goto L_060B6E44; case 0x060B6E46u: goto L_060B6E46; case 0x060B6E48u: goto L_060B6E48; case 0x060B6E4Au: goto L_060B6E4A; case 0x060B6E4Cu: goto L_060B6E4C; case 0x060B6E4Eu: goto L_060B6E4E; case 0x060B6E50u: goto L_060B6E50; case 0x060B6E52u: goto L_060B6E52; case 0x060B6E54u: goto L_060B6E54; case 0x060B6E56u: goto L_060B6E56; case 0x060B6E58u: goto L_060B6E58; case 0x060B6E5Au: goto L_060B6E5A; case 0x060B6E5Cu: goto L_060B6E5C; case 0x060B6E5Eu: goto L_060B6E5E; case 0x060B6E60u: goto L_060B6E60; case 0x060B6E62u: goto L_060B6E62; case 0x060B6E64u: goto L_060B6E64; case 0x060B6E66u: goto L_060B6E66; case 0x060B6E68u: goto L_060B6E68; case 0x060B6E6Au: goto L_060B6E6A; case 0x060B6E6Eu: goto L_060B6E6E; case 0x060B6E70u: goto L_060B6E70; case 0x060B6E72u: goto L_060B6E72; case 0x060B6E76u: goto L_060B6E76; case 0x060B6E78u: goto L_060B6E78; case 0x060B6E7Cu: goto L_060B6E7C; case 0x060B6E7Eu: goto L_060B6E7E; case 0x060B6E80u: goto L_060B6E80; case 0x060B6E82u: goto L_060B6E82; case 0x060B6E84u: goto L_060B6E84; case 0x060B6E86u: goto L_060B6E86; case 0x060B6E88u: goto L_060B6E88; case 0x060B6E8Au: goto L_060B6E8A; case 0x060B6E8Eu: goto L_060B6E8E; case 0x060B6EBCu: goto L_060B6EBC; case 0x060B6EBEu: goto L_060B6EBE; case 0x060B6EC0u: goto L_060B6EC0; case 0x060B6EC2u: goto L_060B6EC2; case 0x060B6EC6u: goto L_060B6EC6; case 0x060B6EC8u: goto L_060B6EC8; case 0x060B6ECAu: goto L_060B6ECA; case 0x060B6ECCu: goto L_060B6ECC; case 0x060B6ECEu: goto L_060B6ECE; case 0x060B6ED0u: goto L_060B6ED0; case 0x060B7000u: goto L_060B7000; case 0x060B7002u: goto L_060B7002; case 0x060B7004u: goto L_060B7004; case 0x060B7006u: goto L_060B7006; case 0x060B7008u: goto L_060B7008; case 0x060B700Au: goto L_060B700A; case 0x060B700Cu: goto L_060B700C; case 0x060B700Eu: goto L_060B700E; case 0x060B7010u: goto L_060B7010; case 0x060B7014u: goto L_060B7014; case 0x060B7016u: goto L_060B7016; case 0x060B7018u: goto L_060B7018; case 0x060B701Au: goto L_060B701A; case 0x060B701Cu: goto L_060B701C; case 0x060B701Eu: goto L_060B701E; case 0x060B7020u: goto L_060B7020; case 0x060B7024u: goto L_060B7024; case 0x060B7026u: goto L_060B7026; case 0x060B7028u: goto L_060B7028; case 0x060B702Au: goto L_060B702A; case 0x060B702Cu: goto L_060B702C; case 0x060B702Eu: goto L_060B702E; case 0x060B7030u: goto L_060B7030; case 0x060B7032u: goto L_060B7032; case 0x060B7034u: goto L_060B7034; case 0x060B7036u: goto L_060B7036; case 0x060B7038u: goto L_060B7038; case 0x060B703Au: goto L_060B703A; case 0x060B703Eu: goto L_060B703E; case 0x060B7040u: goto L_060B7040; case 0x060B7042u: goto L_060B7042; case 0x060B70BCu: goto L_060B70BC; case 0x060B70BEu: goto L_060B70BE; case 0x060B70C2u: goto L_060B70C2; case 0x060B70C4u: goto L_060B70C4; case 0x060B70C6u: goto L_060B70C6; case 0x060B70CAu: goto L_060B70CA; case 0x060B70CCu: goto L_060B70CC; case 0x060B70D0u: goto L_060B70D0; case 0x060B70D2u: goto L_060B70D2; case 0x060B70D6u: goto L_060B70D6; case 0x060B70D8u: goto L_060B70D8; case 0x060B70DAu: goto L_060B70DA; case 0x060B70DCu: goto L_060B70DC; case 0x060B70DEu: goto L_060B70DE; case 0x060B70E0u: goto L_060B70E0; case 0x060B70E2u: goto L_060B70E2; case 0x060B70E4u: goto L_060B70E4; case 0x060B70E6u: goto L_060B70E6; case 0x060B70E8u: goto L_060B70E8; case 0x060B70EAu: goto L_060B70EA; case 0x060B70EEu: goto L_060B70EE; case 0x060B70F2u: goto L_060B70F2; case 0x060B70F4u: goto L_060B70F4; case 0x060B70F8u: goto L_060B70F8; case 0x060B70FCu: goto L_060B70FC; case 0x060B70FEu: goto L_060B70FE; case 0x060B7102u: goto L_060B7102; case 0x060B7106u: goto L_060B7106; case 0x060B7108u: goto L_060B7108; case 0x060B710Cu: goto L_060B710C; case 0x060B7110u: goto L_060B7110; case 0x060B7112u: goto L_060B7112; case 0x060B7116u: goto L_060B7116; case 0x060B711Au: goto L_060B711A; case 0x060B711Cu: goto L_060B711C; case 0x060B7120u: goto L_060B7120; case 0x060B7124u: goto L_060B7124; case 0x060B7126u: goto L_060B7126; case 0x060B712Au: goto L_060B712A; case 0x060B712Eu: goto L_060B712E; case 0x060B7130u: goto L_060B7130; case 0x060B7134u: goto L_060B7134; case 0x060B7136u: goto L_060B7136; case 0x060B7138u: goto L_060B7138; case 0x060B713Au: goto L_060B713A; default: sh2_call(c, x); return; } }  // 060B6E72 jmp @r0 ; shll2 r2
L_060B6E76:
    c.t = (c.r[0] & 0x1u) == 0;  // 060B6E76 tst #1,r0
L_060B6E78:
    { const bool k = c.t; c.r[3] = 0u - c.r[3]; if (k) { goto L_060B6E8E; } }  // 060B6E78 bt/s 0x060B6E8E ; neg r3,r3
L_060B6E7C:
    c.r[5] -= 4; st32(c.r[5], c.r[3]);  // 060B6E7C mov.l r3,@-r5
L_060B6E7E:
    c.r[2] = 0u - c.r[2];  // 060B6E7E neg r2,r2
L_060B6E80:
    c.r[5] -= 4; st32(c.r[5], c.r[2]);  // 060B6E80 mov.l r2,@-r5
L_060B6E82:
    c.r[13] = 0u - c.r[13];  // 060B6E82 neg r13,r13
L_060B6E84:
    c.r[5] -= 4; st32(c.r[5], c.r[13]);  // 060B6E84 mov.l r13,@-r5
L_060B6E86:
    c.r[0] = ld32(c.r[9]); c.r[9] += 4;  // 060B6E86 mov.l @r9+,r0
L_060B6E88:
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 060B6E88 mov.w @r7+,r2
L_060B6E8A:
    { const uint32_t x = c.r[0]; c.r[2] <<= 2; SH2_POLL(c); switch (x) { case 0x060B6DFEu: goto L_060B6DFE; case 0x060B6E00u: goto L_060B6E00; case 0x060B6E02u: goto L_060B6E02; case 0x060B6E04u: goto L_060B6E04; case 0x060B6E06u: goto L_060B6E06; case 0x060B6E08u: goto L_060B6E08; case 0x060B6E0Au: goto L_060B6E0A; case 0x060B6E0Cu: goto L_060B6E0C; case 0x060B6E0Eu: goto L_060B6E0E; case 0x060B6E10u: goto L_060B6E10; case 0x060B6E12u: goto L_060B6E12; case 0x060B6E14u: goto L_060B6E14; case 0x060B6E16u: goto L_060B6E16; case 0x060B6E18u: goto L_060B6E18; case 0x060B6E1Au: goto L_060B6E1A; case 0x060B6E1Cu: goto L_060B6E1C; case 0x060B6E1Eu: goto L_060B6E1E; case 0x060B6E20u: goto L_060B6E20; case 0x060B6E22u: goto L_060B6E22; case 0x060B6E24u: goto L_060B6E24; case 0x060B6E26u: goto L_060B6E26; case 0x060B6E28u: goto L_060B6E28; case 0x060B6E2Au: goto L_060B6E2A; case 0x060B6E2Cu: goto L_060B6E2C; case 0x060B6E2Eu: goto L_060B6E2E; case 0x060B6E30u: goto L_060B6E30; case 0x060B6E32u: goto L_060B6E32; case 0x060B6E34u: goto L_060B6E34; case 0x060B6E36u: goto L_060B6E36; case 0x060B6E38u: goto L_060B6E38; case 0x060B6E3Au: goto L_060B6E3A; case 0x060B6E3Cu: goto L_060B6E3C; case 0x060B6E3Eu: goto L_060B6E3E; case 0x060B6E40u: goto L_060B6E40; case 0x060B6E42u: goto L_060B6E42; case 0x060B6E44u: goto L_060B6E44; case 0x060B6E46u: goto L_060B6E46; case 0x060B6E48u: goto L_060B6E48; case 0x060B6E4Au: goto L_060B6E4A; case 0x060B6E4Cu: goto L_060B6E4C; case 0x060B6E4Eu: goto L_060B6E4E; case 0x060B6E50u: goto L_060B6E50; case 0x060B6E52u: goto L_060B6E52; case 0x060B6E54u: goto L_060B6E54; case 0x060B6E56u: goto L_060B6E56; case 0x060B6E58u: goto L_060B6E58; case 0x060B6E5Au: goto L_060B6E5A; case 0x060B6E5Cu: goto L_060B6E5C; case 0x060B6E5Eu: goto L_060B6E5E; case 0x060B6E60u: goto L_060B6E60; case 0x060B6E62u: goto L_060B6E62; case 0x060B6E64u: goto L_060B6E64; case 0x060B6E66u: goto L_060B6E66; case 0x060B6E68u: goto L_060B6E68; case 0x060B6E6Au: goto L_060B6E6A; case 0x060B6E6Eu: goto L_060B6E6E; case 0x060B6E70u: goto L_060B6E70; case 0x060B6E72u: goto L_060B6E72; case 0x060B6E76u: goto L_060B6E76; case 0x060B6E78u: goto L_060B6E78; case 0x060B6E7Cu: goto L_060B6E7C; case 0x060B6E7Eu: goto L_060B6E7E; case 0x060B6E80u: goto L_060B6E80; case 0x060B6E82u: goto L_060B6E82; case 0x060B6E84u: goto L_060B6E84; case 0x060B6E86u: goto L_060B6E86; case 0x060B6E88u: goto L_060B6E88; case 0x060B6E8Au: goto L_060B6E8A; case 0x060B6E8Eu: goto L_060B6E8E; case 0x060B6EBCu: goto L_060B6EBC; case 0x060B6EBEu: goto L_060B6EBE; case 0x060B6EC0u: goto L_060B6EC0; case 0x060B6EC2u: goto L_060B6EC2; case 0x060B6EC6u: goto L_060B6EC6; case 0x060B6EC8u: goto L_060B6EC8; case 0x060B6ECAu: goto L_060B6ECA; case 0x060B6ECCu: goto L_060B6ECC; case 0x060B6ECEu: goto L_060B6ECE; case 0x060B6ED0u: goto L_060B6ED0; case 0x060B7000u: goto L_060B7000; case 0x060B7002u: goto L_060B7002; case 0x060B7004u: goto L_060B7004; case 0x060B7006u: goto L_060B7006; case 0x060B7008u: goto L_060B7008; case 0x060B700Au: goto L_060B700A; case 0x060B700Cu: goto L_060B700C; case 0x060B700Eu: goto L_060B700E; case 0x060B7010u: goto L_060B7010; case 0x060B7014u: goto L_060B7014; case 0x060B7016u: goto L_060B7016; case 0x060B7018u: goto L_060B7018; case 0x060B701Au: goto L_060B701A; case 0x060B701Cu: goto L_060B701C; case 0x060B701Eu: goto L_060B701E; case 0x060B7020u: goto L_060B7020; case 0x060B7024u: goto L_060B7024; case 0x060B7026u: goto L_060B7026; case 0x060B7028u: goto L_060B7028; case 0x060B702Au: goto L_060B702A; case 0x060B702Cu: goto L_060B702C; case 0x060B702Eu: goto L_060B702E; case 0x060B7030u: goto L_060B7030; case 0x060B7032u: goto L_060B7032; case 0x060B7034u: goto L_060B7034; case 0x060B7036u: goto L_060B7036; case 0x060B7038u: goto L_060B7038; case 0x060B703Au: goto L_060B703A; case 0x060B703Eu: goto L_060B703E; case 0x060B7040u: goto L_060B7040; case 0x060B7042u: goto L_060B7042; case 0x060B70BCu: goto L_060B70BC; case 0x060B70BEu: goto L_060B70BE; case 0x060B70C2u: goto L_060B70C2; case 0x060B70C4u: goto L_060B70C4; case 0x060B70C6u: goto L_060B70C6; case 0x060B70CAu: goto L_060B70CA; case 0x060B70CCu: goto L_060B70CC; case 0x060B70D0u: goto L_060B70D0; case 0x060B70D2u: goto L_060B70D2; case 0x060B70D6u: goto L_060B70D6; case 0x060B70D8u: goto L_060B70D8; case 0x060B70DAu: goto L_060B70DA; case 0x060B70DCu: goto L_060B70DC; case 0x060B70DEu: goto L_060B70DE; case 0x060B70E0u: goto L_060B70E0; case 0x060B70E2u: goto L_060B70E2; case 0x060B70E4u: goto L_060B70E4; case 0x060B70E6u: goto L_060B70E6; case 0x060B70E8u: goto L_060B70E8; case 0x060B70EAu: goto L_060B70EA; case 0x060B70EEu: goto L_060B70EE; case 0x060B70F2u: goto L_060B70F2; case 0x060B70F4u: goto L_060B70F4; case 0x060B70F8u: goto L_060B70F8; case 0x060B70FCu: goto L_060B70FC; case 0x060B70FEu: goto L_060B70FE; case 0x060B7102u: goto L_060B7102; case 0x060B7106u: goto L_060B7106; case 0x060B7108u: goto L_060B7108; case 0x060B710Cu: goto L_060B710C; case 0x060B7110u: goto L_060B7110; case 0x060B7112u: goto L_060B7112; case 0x060B7116u: goto L_060B7116; case 0x060B711Au: goto L_060B711A; case 0x060B711Cu: goto L_060B711C; case 0x060B7120u: goto L_060B7120; case 0x060B7124u: goto L_060B7124; case 0x060B7126u: goto L_060B7126; case 0x060B712Au: goto L_060B712A; case 0x060B712Eu: goto L_060B712E; case 0x060B7130u: goto L_060B7130; case 0x060B7134u: goto L_060B7134; case 0x060B7136u: goto L_060B7136; case 0x060B7138u: goto L_060B7138; case 0x060B713Au: goto L_060B713A; default: sh2_call(c, x); return; } }  // 060B6E8A jmp @r0 ; shll2 r2
L_060B6E8E:
    c.r[7] += 6; goto L_060B6EBC;  // 060B6E8E bra 0x060B6EBC ; add #6,r7
L_060B6EBC:
    c.r[0] = ld32(c.r[15] + 16);  // 060B6EBC mov.l @(16,r15),r0
L_060B6EBE:
    c.r[8] += 12;  // 060B6EBE add #12,r8
L_060B6EC0:
    c.r[0] -= 1; c.t = c.r[0] == 0;  // 060B6EC0 dt r0
L_060B6EC2:
    { const bool k = !c.t; st32(c.r[15] + 16, c.r[0]); if (k) { SH2_POLL(c); goto L_060B6DFE; } }  // 060B6EC2 bf/s 0x060B6DFE ; mov.l r0,@(16,r15)
L_060B6EC6:
    c.r[15] += 24;  // 060B6EC6 add #24,r15
L_060B6EC8:
    c.r[4] = ld32(c.r[15]); c.r[15] += 4;  // 060B6EC8 mov.l @r15+,r4
L_060B6ECA:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060B6ECA lds.l @r15+,pr
L_060B6ECC:
    c.r[4] += 48;  // 060B6ECC add #48,r4
L_060B6ECE:
    c.r[0] = c.r[11];  // 060B6ECE mov r11,r0
L_060B6ED0:
    { const uint32_t x = c.pr; st32(c.gbr + 52, c.r[0]); c.pc = x; return; }  // 060B6ED0 rts ; mov.l r0,@(52,gbr)
L_060B7000:
    c.r[14] = ld32(c.r[1] + 12);  // 060B7000 mov.l @(12,r1),r14
L_060B7002:
    c.r[2] <<= 2;  // 060B7002 shll2 r2
L_060B7004:
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 060B7004 mov.w @r7+,r3
L_060B7006:
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 060B7006 mov.w @r7+,r4
L_060B7008:
    c.r[2] += c.r[10];  // 060B7008 add r10,r2
L_060B700A:
    c.r[0] = ld32(c.r[2] + 12);  // 060B700A mov.l @(12,r2),r0
L_060B700C:
    c.r[3] <<= 2;  // 060B700C shll2 r3
L_060B700E:
    c.t = (int32_t)c.r[14] > (int32_t)c.r[0];  // 060B700E cmp/gt r0,r14
L_060B7010:
    { const bool k = !c.t; c.r[3] <<= 2; if (k) { goto L_060B7016; } }  // 060B7010 bf/s 0x060B7016 ; shll2 r3
L_060B7014:
    c.r[14] = c.r[0];  // 060B7014 mov r0,r14
L_060B7016:
    c.r[3] += c.r[10];  // 060B7016 add r10,r3
L_060B7018:
    c.r[4] <<= 2;  // 060B7018 shll2 r4
L_060B701A:
    c.r[0] = ld32(c.r[3] + 12);  // 060B701A mov.l @(12,r3),r0
L_060B701C:
    c.r[4] <<= 2;  // 060B701C shll2 r4
L_060B701E:
    c.t = (int32_t)c.r[14] > (int32_t)c.r[0];  // 060B701E cmp/gt r0,r14
L_060B7020:
    { const bool k = !c.t; c.r[4] += c.r[10]; if (k) { goto L_060B7026; } }  // 060B7020 bf/s 0x060B7026 ; add r10,r4
L_060B7024:
    c.r[14] = c.r[0];  // 060B7024 mov r0,r14
L_060B7026:
    c.r[0] = ld32(c.r[4] + 12);  // 060B7026 mov.l @(12,r4),r0
L_060B7028:
    c.r[5] = ld32(c.r[15] + 12);  // 060B7028 mov.l @(12,r15),r5
L_060B702A:
    c.t = (int32_t)c.r[14] > (int32_t)c.r[0];  // 060B702A cmp/gt r0,r14
L_060B702C:
    if (!c.t) { goto L_060B7030; }  // 060B702C bf 0x060B7030
L_060B702E:
    c.r[14] = c.r[0];  // 060B702E mov r0,r14
L_060B7030:
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 160);  // 060B7030 mov.w @(160,gbr),r0
L_060B7032:
    c.r[5] <<= 16;  // 060B7032 shll16 r5
L_060B7034:
    c.r[0] <<= 16;  // 060B7034 shll16 r0
L_060B7036:
    c.r[0] += c.r[5];  // 060B7036 add r5,r0
L_060B7038:
    c.t = c.r[14] > c.r[0];  // 060B7038 cmp/hi r0,r14
L_060B703A:
    { const bool k = c.t; c.t = c.r[5] & 1; c.r[5] >>= 1; if (k) { goto L_060B70BE; } }  // 060B703A bt/s 0x060B70BE ; shlr r5
L_060B703E:
    c.t = (int32_t)c.r[14] > (int32_t)c.r[5];  // 060B703E cmp/gt r5,r14
L_060B7040:
    if (!c.t) { goto L_060B70BE; }  // 060B7040 bf 0x060B70BE
L_060B7042:
    c.r[14] >>= 16; goto L_060B70C2;  // 060B7042 bra 0x060B70C2 ; shlr16 r14
L_060B70BC:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060B70BC mov.l @r15+,r14
L_060B70BE:
    SH2_POLL(c); goto L_060B6EBC;  // 060B70BE bra 0x060B6EBC ; nop
L_060B70C2:
    c.r[0] = ld32(c.r[1] + 4);  // 060B70C2 mov.l @(4,r1),r0
L_060B70C4:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B70C4 shar r0
L_060B70C6:
    { const bool k = !c.t; c.r[0] = ld32(c.r[2] + 4); if (k) { goto L_060B70DA; } }  // 060B70C6 bf/s 0x060B70DA ; mov.l @(4,r2),r0
L_060B70CA:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B70CA shar r0
L_060B70CC:
    { const bool k = !c.t; c.r[0] = ld32(c.r[3] + 4); if (k) { goto L_060B70DA; } }  // 060B70CC bf/s 0x060B70DA ; mov.l @(4,r3),r0
L_060B70D0:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B70D0 shar r0
L_060B70D2:
    { const bool k = !c.t; c.r[0] = ld32(c.r[4] + 4); if (k) { goto L_060B70DA; } }  // 060B70D2 bf/s 0x060B70DA ; mov.l @(4,r4),r0
L_060B70D6:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B70D6 shar r0
L_060B70D8:
    if (c.t) { SH2_POLL(c); goto L_060B70BE; }  // 060B70D8 bt 0x060B70BE
L_060B70DA:
    c.r[0] = ld32(c.gbr + 892);  // 060B70DA mov.l @(892,gbr),r0
L_060B70DC:
    c.t = c.r[0] & 1; c.r[0] = c.r[0] >> 1 | c.t << 31;  // 060B70DC rotr r0
L_060B70DE:
    if (c.t) { goto L_060B7138; }  // 060B70DE bt 0x060B7138
L_060B70E0:
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060B70E0 mov.l r14,@-r15
L_060B70E2:
    c.r[14] = (uint32_t)(int16_t)ld16(0x060B7140u);  // 060B70E2 mov.w 0x060B7140,r14
L_060B70E4:
    c.r[5] = (uint32_t)(int16_t)ld16(0x060B7142u);  // 060B70E4 mov.w 0x060B7142,r5
L_060B70E6:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060B70E6 mov.w @(0,r1),r0
L_060B70E8:
    c.t = (int32_t)c.r[0] > (int32_t)c.r[5];  // 060B70E8 cmp/gt r5,r0
L_060B70EA:
    { const bool k = c.t; c.t = (int32_t)c.r[0] >= (int32_t)c.r[14]; if (k) { SH2_POLL(c); goto L_060B70BC; } }  // 060B70EA bt/s 0x060B70BC ; cmp/ge r14,r0
L_060B70EE:
    { const bool k = !c.t; c.r[0] = (uint32_t)(int16_t)ld16(c.r[1] + 2); if (k) { SH2_POLL(c); goto L_060B70BC; } }  // 060B70EE bf/s 0x060B70BC ; mov.w @(2,r1),r0
L_060B70F2:
    c.t = (int32_t)c.r[0] > (int32_t)c.r[5];  // 060B70F2 cmp/gt r5,r0
L_060B70F4:
    { const bool k = c.t; c.t = (int32_t)c.r[0] >= (int32_t)c.r[14]; if (k) { SH2_POLL(c); goto L_060B70BC; } }  // 060B70F4 bt/s 0x060B70BC ; cmp/ge r14,r0
L_060B70F8:
    { const bool k = !c.t; c.r[0] = (uint32_t)(int16_t)ld16(c.r[2]); if (k) { SH2_POLL(c); goto L_060B70BC; } }  // 060B70F8 bf/s 0x060B70BC ; mov.w @(0,r2),r0
L_060B70FC:
    c.t = (int32_t)c.r[0] > (int32_t)c.r[5];  // 060B70FC cmp/gt r5,r0
L_060B70FE:
    { const bool k = c.t; c.t = (int32_t)c.r[0] >= (int32_t)c.r[14]; if (k) { SH2_POLL(c); goto L_060B70BC; } }  // 060B70FE bt/s 0x060B70BC ; cmp/ge r14,r0
L_060B7102:
    { const bool k = !c.t; c.r[0] = (uint32_t)(int16_t)ld16(c.r[2] + 2); if (k) { SH2_POLL(c); goto L_060B70BC; } }  // 060B7102 bf/s 0x060B70BC ; mov.w @(2,r2),r0
L_060B7106:
    c.t = (int32_t)c.r[0] > (int32_t)c.r[5];  // 060B7106 cmp/gt r5,r0
L_060B7108:
    { const bool k = c.t; c.t = (int32_t)c.r[0] >= (int32_t)c.r[14]; if (k) { SH2_POLL(c); goto L_060B70BC; } }  // 060B7108 bt/s 0x060B70BC ; cmp/ge r14,r0
L_060B710C:
    { const bool k = !c.t; c.r[0] = (uint32_t)(int16_t)ld16(c.r[3]); if (k) { SH2_POLL(c); goto L_060B70BC; } }  // 060B710C bf/s 0x060B70BC ; mov.w @(0,r3),r0
L_060B7110:
    c.t = (int32_t)c.r[0] > (int32_t)c.r[5];  // 060B7110 cmp/gt r5,r0
L_060B7112:
    { const bool k = c.t; c.t = (int32_t)c.r[0] >= (int32_t)c.r[14]; if (k) { SH2_POLL(c); goto L_060B70BC; } }  // 060B7112 bt/s 0x060B70BC ; cmp/ge r14,r0
L_060B7116:
    { const bool k = !c.t; c.r[0] = (uint32_t)(int16_t)ld16(c.r[3] + 2); if (k) { SH2_POLL(c); goto L_060B70BC; } }  // 060B7116 bf/s 0x060B70BC ; mov.w @(2,r3),r0
L_060B711A:
    c.t = (int32_t)c.r[0] > (int32_t)c.r[5];  // 060B711A cmp/gt r5,r0
L_060B711C:
    { const bool k = c.t; c.t = (int32_t)c.r[0] >= (int32_t)c.r[14]; if (k) { SH2_POLL(c); goto L_060B70BC; } }  // 060B711C bt/s 0x060B70BC ; cmp/ge r14,r0
L_060B7120:
    { const bool k = !c.t; c.r[0] = (uint32_t)(int16_t)ld16(c.r[4]); if (k) { SH2_POLL(c); goto L_060B70BC; } }  // 060B7120 bf/s 0x060B70BC ; mov.w @(0,r4),r0
L_060B7124:
    c.t = (int32_t)c.r[0] > (int32_t)c.r[5];  // 060B7124 cmp/gt r5,r0
L_060B7126:
    { const bool k = c.t; c.t = (int32_t)c.r[0] >= (int32_t)c.r[14]; if (k) { SH2_POLL(c); goto L_060B70BC; } }  // 060B7126 bt/s 0x060B70BC ; cmp/ge r14,r0
L_060B712A:
    { const bool k = !c.t; c.r[0] = (uint32_t)(int16_t)ld16(c.r[4] + 2); if (k) { SH2_POLL(c); goto L_060B70BC; } }  // 060B712A bf/s 0x060B70BC ; mov.w @(2,r4),r0
L_060B712E:
    c.t = (int32_t)c.r[0] > (int32_t)c.r[5];  // 060B712E cmp/gt r5,r0
L_060B7130:
    { const bool k = c.t; c.t = (int32_t)c.r[0] >= (int32_t)c.r[14]; if (k) { SH2_POLL(c); goto L_060B70BC; } }  // 060B7130 bt/s 0x060B70BC ; cmp/ge r14,r0
L_060B7134:
    if (!c.t) { SH2_POLL(c); goto L_060B70BC; }  // 060B7134 bf 0x060B70BC
L_060B7136:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060B7136 mov.l @r15+,r14
L_060B7138:
    c.r[0] = ld32(c.r[9]); c.r[9] += 4;  // 060B7138 mov.l @r9+,r0
L_060B713A:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x060B6DFEu: goto L_060B6DFE; case 0x060B6E00u: goto L_060B6E00; case 0x060B6E02u: goto L_060B6E02; case 0x060B6E04u: goto L_060B6E04; case 0x060B6E06u: goto L_060B6E06; case 0x060B6E08u: goto L_060B6E08; case 0x060B6E0Au: goto L_060B6E0A; case 0x060B6E0Cu: goto L_060B6E0C; case 0x060B6E0Eu: goto L_060B6E0E; case 0x060B6E10u: goto L_060B6E10; case 0x060B6E12u: goto L_060B6E12; case 0x060B6E14u: goto L_060B6E14; case 0x060B6E16u: goto L_060B6E16; case 0x060B6E18u: goto L_060B6E18; case 0x060B6E1Au: goto L_060B6E1A; case 0x060B6E1Cu: goto L_060B6E1C; case 0x060B6E1Eu: goto L_060B6E1E; case 0x060B6E20u: goto L_060B6E20; case 0x060B6E22u: goto L_060B6E22; case 0x060B6E24u: goto L_060B6E24; case 0x060B6E26u: goto L_060B6E26; case 0x060B6E28u: goto L_060B6E28; case 0x060B6E2Au: goto L_060B6E2A; case 0x060B6E2Cu: goto L_060B6E2C; case 0x060B6E2Eu: goto L_060B6E2E; case 0x060B6E30u: goto L_060B6E30; case 0x060B6E32u: goto L_060B6E32; case 0x060B6E34u: goto L_060B6E34; case 0x060B6E36u: goto L_060B6E36; case 0x060B6E38u: goto L_060B6E38; case 0x060B6E3Au: goto L_060B6E3A; case 0x060B6E3Cu: goto L_060B6E3C; case 0x060B6E3Eu: goto L_060B6E3E; case 0x060B6E40u: goto L_060B6E40; case 0x060B6E42u: goto L_060B6E42; case 0x060B6E44u: goto L_060B6E44; case 0x060B6E46u: goto L_060B6E46; case 0x060B6E48u: goto L_060B6E48; case 0x060B6E4Au: goto L_060B6E4A; case 0x060B6E4Cu: goto L_060B6E4C; case 0x060B6E4Eu: goto L_060B6E4E; case 0x060B6E50u: goto L_060B6E50; case 0x060B6E52u: goto L_060B6E52; case 0x060B6E54u: goto L_060B6E54; case 0x060B6E56u: goto L_060B6E56; case 0x060B6E58u: goto L_060B6E58; case 0x060B6E5Au: goto L_060B6E5A; case 0x060B6E5Cu: goto L_060B6E5C; case 0x060B6E5Eu: goto L_060B6E5E; case 0x060B6E60u: goto L_060B6E60; case 0x060B6E62u: goto L_060B6E62; case 0x060B6E64u: goto L_060B6E64; case 0x060B6E66u: goto L_060B6E66; case 0x060B6E68u: goto L_060B6E68; case 0x060B6E6Au: goto L_060B6E6A; case 0x060B6E6Eu: goto L_060B6E6E; case 0x060B6E70u: goto L_060B6E70; case 0x060B6E72u: goto L_060B6E72; case 0x060B6E76u: goto L_060B6E76; case 0x060B6E78u: goto L_060B6E78; case 0x060B6E7Cu: goto L_060B6E7C; case 0x060B6E7Eu: goto L_060B6E7E; case 0x060B6E80u: goto L_060B6E80; case 0x060B6E82u: goto L_060B6E82; case 0x060B6E84u: goto L_060B6E84; case 0x060B6E86u: goto L_060B6E86; case 0x060B6E88u: goto L_060B6E88; case 0x060B6E8Au: goto L_060B6E8A; case 0x060B6E8Eu: goto L_060B6E8E; case 0x060B6EBCu: goto L_060B6EBC; case 0x060B6EBEu: goto L_060B6EBE; case 0x060B6EC0u: goto L_060B6EC0; case 0x060B6EC2u: goto L_060B6EC2; case 0x060B6EC6u: goto L_060B6EC6; case 0x060B6EC8u: goto L_060B6EC8; case 0x060B6ECAu: goto L_060B6ECA; case 0x060B6ECCu: goto L_060B6ECC; case 0x060B6ECEu: goto L_060B6ECE; case 0x060B6ED0u: goto L_060B6ED0; case 0x060B7000u: goto L_060B7000; case 0x060B7002u: goto L_060B7002; case 0x060B7004u: goto L_060B7004; case 0x060B7006u: goto L_060B7006; case 0x060B7008u: goto L_060B7008; case 0x060B700Au: goto L_060B700A; case 0x060B700Cu: goto L_060B700C; case 0x060B700Eu: goto L_060B700E; case 0x060B7010u: goto L_060B7010; case 0x060B7014u: goto L_060B7014; case 0x060B7016u: goto L_060B7016; case 0x060B7018u: goto L_060B7018; case 0x060B701Au: goto L_060B701A; case 0x060B701Cu: goto L_060B701C; case 0x060B701Eu: goto L_060B701E; case 0x060B7020u: goto L_060B7020; case 0x060B7024u: goto L_060B7024; case 0x060B7026u: goto L_060B7026; case 0x060B7028u: goto L_060B7028; case 0x060B702Au: goto L_060B702A; case 0x060B702Cu: goto L_060B702C; case 0x060B702Eu: goto L_060B702E; case 0x060B7030u: goto L_060B7030; case 0x060B7032u: goto L_060B7032; case 0x060B7034u: goto L_060B7034; case 0x060B7036u: goto L_060B7036; case 0x060B7038u: goto L_060B7038; case 0x060B703Au: goto L_060B703A; case 0x060B703Eu: goto L_060B703E; case 0x060B7040u: goto L_060B7040; case 0x060B7042u: goto L_060B7042; case 0x060B70BCu: goto L_060B70BC; case 0x060B70BEu: goto L_060B70BE; case 0x060B70C2u: goto L_060B70C2; case 0x060B70C4u: goto L_060B70C4; case 0x060B70C6u: goto L_060B70C6; case 0x060B70CAu: goto L_060B70CA; case 0x060B70CCu: goto L_060B70CC; case 0x060B70D0u: goto L_060B70D0; case 0x060B70D2u: goto L_060B70D2; case 0x060B70D6u: goto L_060B70D6; case 0x060B70D8u: goto L_060B70D8; case 0x060B70DAu: goto L_060B70DA; case 0x060B70DCu: goto L_060B70DC; case 0x060B70DEu: goto L_060B70DE; case 0x060B70E0u: goto L_060B70E0; case 0x060B70E2u: goto L_060B70E2; case 0x060B70E4u: goto L_060B70E4; case 0x060B70E6u: goto L_060B70E6; case 0x060B70E8u: goto L_060B70E8; case 0x060B70EAu: goto L_060B70EA; case 0x060B70EEu: goto L_060B70EE; case 0x060B70F2u: goto L_060B70F2; case 0x060B70F4u: goto L_060B70F4; case 0x060B70F8u: goto L_060B70F8; case 0x060B70FCu: goto L_060B70FC; case 0x060B70FEu: goto L_060B70FE; case 0x060B7102u: goto L_060B7102; case 0x060B7106u: goto L_060B7106; case 0x060B7108u: goto L_060B7108; case 0x060B710Cu: goto L_060B710C; case 0x060B7110u: goto L_060B7110; case 0x060B7112u: goto L_060B7112; case 0x060B7116u: goto L_060B7116; case 0x060B711Au: goto L_060B711A; case 0x060B711Cu: goto L_060B711C; case 0x060B7120u: goto L_060B7120; case 0x060B7124u: goto L_060B7124; case 0x060B7126u: goto L_060B7126; case 0x060B712Au: goto L_060B712A; case 0x060B712Eu: goto L_060B712E; case 0x060B7130u: goto L_060B7130; case 0x060B7134u: goto L_060B7134; case 0x060B7136u: goto L_060B7136; case 0x060B7138u: goto L_060B7138; case 0x060B713Au: goto L_060B713A; default: sh2_call(c, x); return; } }  // 060B713A jmp @r0 ; nop
}

void f_060B704C(SH2Context& c) {
    ran[3135] = 1;
    goto L_060B704C;
L_060B6DFE:
    c.mach = c.macl = 0;  // 060B6DFE clrmac
L_060B6E00:
    sh2_mac_l(c, 6, 7);  // 060B6E00 mac.l @r7+,@r6+
L_060B6E02:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[7] + 8);  // 060B6E02 mov.w @(8,r7),r0
L_060B6E04:
    c.r[5] = c.r[15];  // 060B6E04 mov r15,r5
L_060B6E06:
    sh2_mac_l(c, 6, 7);  // 060B6E06 mac.l @r7+,@r6+
L_060B6E08:
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B6E08 exts.w r0,r1
L_060B6E0A:
    c.r[1] <<= 2;  // 060B6E0A shll2 r1
L_060B6E0C:
    sh2_mac_l(c, 6, 7);  // 060B6E0C mac.l @r7+,@r6+
L_060B6E0E:
    c.r[6] += 4;  // 060B6E0E add #4,r6
L_060B6E10:
    c.r[7] -= 12;  // 060B6E10 add #-12,r7
L_060B6E12:
    c.r[1] <<= 2;  // 060B6E12 shll2 r1
L_060B6E14:
    c.r[0] = c.mach;  // 060B6E14 sts mach,r0
L_060B6E16:
    c.r[13] = c.macl;  // 060B6E16 sts macl,r13
L_060B6E18:
    c.mach = c.macl = 0;  // 060B6E18 clrmac
L_060B6E1A:
    sh2_mac_l(c, 6, 7);  // 060B6E1A mac.l @r7+,@r6+
L_060B6E1C:
    c.r[13] = c.r[0] << 16 | c.r[13] >> 16;  // 060B6E1C xtrct r0,r13
L_060B6E1E:
    st32(c.r[5], c.r[13]);  // 060B6E1E mov.l r13,@(0,r5)
L_060B6E20:
    sh2_mac_l(c, 6, 7);  // 060B6E20 mac.l @r7+,@r6+
L_060B6E22:
    c.r[1] += c.r[10];  // 060B6E22 add r10,r1
L_060B6E24:
    c.r[4] = 0x4u;  // 060B6E24 mov #4,r4
L_060B6E26:
    sh2_mac_l(c, 6, 7);  // 060B6E26 mac.l @r7+,@r6+
L_060B6E28:
    c.r[6] += 4;  // 060B6E28 add #4,r6
L_060B6E2A:
    c.r[7] -= 12;  // 060B6E2A add #-12,r7
L_060B6E2C:
    c.r[4] += c.r[1];  // 060B6E2C add r1,r4
L_060B6E2E:
    c.r[0] = c.mach;  // 060B6E2E sts mach,r0
L_060B6E30:
    c.r[2] = c.macl;  // 060B6E30 sts macl,r2
L_060B6E32:
    c.mach = c.macl = 0;  // 060B6E32 clrmac
L_060B6E34:
    sh2_mac_l(c, 6, 7);  // 060B6E34 mac.l @r7+,@r6+
L_060B6E36:
    c.r[2] = c.r[0] << 16 | c.r[2] >> 16;  // 060B6E36 xtrct r0,r2
L_060B6E38:
    st32(c.r[5] + 4, c.r[2]);  // 060B6E38 mov.l r2,@(4,r5)
L_060B6E3A:
    sh2_mac_l(c, 6, 7);  // 060B6E3A mac.l @r7+,@r6+
L_060B6E3C:
    c.r[12] = (uint32_t)(int16_t)ld16(c.r[8]);  // 060B6E3C mov.w @r8,r12
L_060B6E3E:
    c.r[9] = 0x7Fu;  // 060B6E3E mov #127,r9
L_060B6E40:
    sh2_mac_l(c, 6, 7);  // 060B6E40 mac.l @r7+,@r6+
L_060B6E42:
    c.r[6] -= 44;  // 060B6E42 add #-44,r6
L_060B6E44:
    c.r[9] &= c.r[12];  // 060B6E44 and r12,r9
L_060B6E46:
    c.r[9] <<= 2;  // 060B6E46 shll2 r9
L_060B6E48:
    c.r[0] = c.mach;  // 060B6E48 sts mach,r0
L_060B6E4A:
    c.r[3] = c.macl;  // 060B6E4A sts macl,r3
L_060B6E4C:
    c.mach = c.macl = 0;  // 060B6E4C clrmac
L_060B6E4E:
    sh2_mac_l(c, 5, 4);  // 060B6E4E mac.l @r4+,@r5+
L_060B6E50:
    c.r[3] = c.r[0] << 16 | c.r[3] >> 16;  // 060B6E50 xtrct r0,r3
L_060B6E52:
    c.r[0] = 0x060B7144u;  // 060B6E52 mova 0x060B7144,r0
L_060B6E54:
    sh2_mac_l(c, 5, 4);  // 060B6E54 mac.l @r4+,@r5+
L_060B6E56:
    st32(c.r[5], c.r[3]);  // 060B6E56 mov.l r3,@r5
L_060B6E58:
    c.r[9] <<= 2;  // 060B6E58 shll2 r9
L_060B6E5A:
    sh2_mac_l(c, 5, 4);  // 060B6E5A mac.l @r4+,@r5+
L_060B6E5C:
    c.r[9] += c.r[0];  // 060B6E5C add r0,r9
L_060B6E5E:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[8] + 10);  // 060B6E5E mov.w @(10,r8),r0
L_060B6E60:
    c.r[7] += 2;  // 060B6E60 add #2,r7
L_060B6E62:
    c.r[4] = c.mach;  // 060B6E62 sts mach,r4
L_060B6E64:
    st16(c.r[11], c.r[0]);  // 060B6E64 mov.w r0,@(0,r11)
L_060B6E66:
    c.r[0] = ld32(c.gbr + 900);  // 060B6E66 mov.l @(900,gbr),r0
L_060B6E68:
    c.t = (int32_t)c.r[4] >= (int32_t)c.r[0];  // 060B6E68 cmp/ge r0,r4
L_060B6E6A:
    { const bool k = c.t; c.r[0] = (c.r[12] & 0xFFFF0000u) | (c.r[12] & 0xFFu) << 8 | (c.r[12] >> 8 & 0xFFu); if (k) { goto L_060B6E76; } }  // 060B6E6A bt/s 0x060B6E76 ; swap.b r12,r0
L_060B6E6E:
    c.r[0] = ld32(c.r[9]); c.r[9] += 4;  // 060B6E6E mov.l @r9+,r0
L_060B6E70:
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 060B6E70 mov.w @r7+,r2
L_060B6E72:
    { const uint32_t x = c.r[0]; c.r[2] <<= 2; SH2_POLL(c); switch (x) { case 0x060B6DFEu: goto L_060B6DFE; case 0x060B6E00u: goto L_060B6E00; case 0x060B6E02u: goto L_060B6E02; case 0x060B6E04u: goto L_060B6E04; case 0x060B6E06u: goto L_060B6E06; case 0x060B6E08u: goto L_060B6E08; case 0x060B6E0Au: goto L_060B6E0A; case 0x060B6E0Cu: goto L_060B6E0C; case 0x060B6E0Eu: goto L_060B6E0E; case 0x060B6E10u: goto L_060B6E10; case 0x060B6E12u: goto L_060B6E12; case 0x060B6E14u: goto L_060B6E14; case 0x060B6E16u: goto L_060B6E16; case 0x060B6E18u: goto L_060B6E18; case 0x060B6E1Au: goto L_060B6E1A; case 0x060B6E1Cu: goto L_060B6E1C; case 0x060B6E1Eu: goto L_060B6E1E; case 0x060B6E20u: goto L_060B6E20; case 0x060B6E22u: goto L_060B6E22; case 0x060B6E24u: goto L_060B6E24; case 0x060B6E26u: goto L_060B6E26; case 0x060B6E28u: goto L_060B6E28; case 0x060B6E2Au: goto L_060B6E2A; case 0x060B6E2Cu: goto L_060B6E2C; case 0x060B6E2Eu: goto L_060B6E2E; case 0x060B6E30u: goto L_060B6E30; case 0x060B6E32u: goto L_060B6E32; case 0x060B6E34u: goto L_060B6E34; case 0x060B6E36u: goto L_060B6E36; case 0x060B6E38u: goto L_060B6E38; case 0x060B6E3Au: goto L_060B6E3A; case 0x060B6E3Cu: goto L_060B6E3C; case 0x060B6E3Eu: goto L_060B6E3E; case 0x060B6E40u: goto L_060B6E40; case 0x060B6E42u: goto L_060B6E42; case 0x060B6E44u: goto L_060B6E44; case 0x060B6E46u: goto L_060B6E46; case 0x060B6E48u: goto L_060B6E48; case 0x060B6E4Au: goto L_060B6E4A; case 0x060B6E4Cu: goto L_060B6E4C; case 0x060B6E4Eu: goto L_060B6E4E; case 0x060B6E50u: goto L_060B6E50; case 0x060B6E52u: goto L_060B6E52; case 0x060B6E54u: goto L_060B6E54; case 0x060B6E56u: goto L_060B6E56; case 0x060B6E58u: goto L_060B6E58; case 0x060B6E5Au: goto L_060B6E5A; case 0x060B6E5Cu: goto L_060B6E5C; case 0x060B6E5Eu: goto L_060B6E5E; case 0x060B6E60u: goto L_060B6E60; case 0x060B6E62u: goto L_060B6E62; case 0x060B6E64u: goto L_060B6E64; case 0x060B6E66u: goto L_060B6E66; case 0x060B6E68u: goto L_060B6E68; case 0x060B6E6Au: goto L_060B6E6A; case 0x060B6E6Eu: goto L_060B6E6E; case 0x060B6E70u: goto L_060B6E70; case 0x060B6E72u: goto L_060B6E72; case 0x060B6E76u: goto L_060B6E76; case 0x060B6E78u: goto L_060B6E78; case 0x060B6E7Cu: goto L_060B6E7C; case 0x060B6E7Eu: goto L_060B6E7E; case 0x060B6E80u: goto L_060B6E80; case 0x060B6E82u: goto L_060B6E82; case 0x060B6E84u: goto L_060B6E84; case 0x060B6E86u: goto L_060B6E86; case 0x060B6E88u: goto L_060B6E88; case 0x060B6E8Au: goto L_060B6E8A; case 0x060B6E8Eu: goto L_060B6E8E; case 0x060B6EBCu: goto L_060B6EBC; case 0x060B6EBEu: goto L_060B6EBE; case 0x060B6EC0u: goto L_060B6EC0; case 0x060B6EC2u: goto L_060B6EC2; case 0x060B6EC6u: goto L_060B6EC6; case 0x060B6EC8u: goto L_060B6EC8; case 0x060B6ECAu: goto L_060B6ECA; case 0x060B6ECCu: goto L_060B6ECC; case 0x060B6ECEu: goto L_060B6ECE; case 0x060B6ED0u: goto L_060B6ED0; case 0x060B704Cu: goto L_060B704C; case 0x060B704Eu: goto L_060B704E; case 0x060B7050u: goto L_060B7050; case 0x060B7052u: goto L_060B7052; case 0x060B7054u: goto L_060B7054; case 0x060B7056u: goto L_060B7056; case 0x060B7058u: goto L_060B7058; case 0x060B705Au: goto L_060B705A; case 0x060B705Cu: goto L_060B705C; case 0x060B705Eu: goto L_060B705E; case 0x060B7060u: goto L_060B7060; case 0x060B7064u: goto L_060B7064; case 0x060B7066u: goto L_060B7066; case 0x060B7068u: goto L_060B7068; case 0x060B706Au: goto L_060B706A; case 0x060B706Cu: goto L_060B706C; case 0x060B7070u: goto L_060B7070; case 0x060B7072u: goto L_060B7072; case 0x060B7074u: goto L_060B7074; case 0x060B7076u: goto L_060B7076; case 0x060B7078u: goto L_060B7078; case 0x060B707Au: goto L_060B707A; case 0x060B707Cu: goto L_060B707C; case 0x060B707Eu: goto L_060B707E; case 0x060B7080u: goto L_060B7080; case 0x060B7082u: goto L_060B7082; case 0x060B7084u: goto L_060B7084; case 0x060B7086u: goto L_060B7086; case 0x060B708Au: goto L_060B708A; case 0x060B708Cu: goto L_060B708C; case 0x060B708Eu: goto L_060B708E; case 0x060B70BCu: goto L_060B70BC; case 0x060B70BEu: goto L_060B70BE; case 0x060B70C2u: goto L_060B70C2; case 0x060B70C4u: goto L_060B70C4; case 0x060B70C6u: goto L_060B70C6; case 0x060B70CAu: goto L_060B70CA; case 0x060B70CCu: goto L_060B70CC; case 0x060B70D0u: goto L_060B70D0; case 0x060B70D2u: goto L_060B70D2; case 0x060B70D6u: goto L_060B70D6; case 0x060B70D8u: goto L_060B70D8; case 0x060B70DAu: goto L_060B70DA; case 0x060B70DCu: goto L_060B70DC; case 0x060B70DEu: goto L_060B70DE; case 0x060B70E0u: goto L_060B70E0; case 0x060B70E2u: goto L_060B70E2; case 0x060B70E4u: goto L_060B70E4; case 0x060B70E6u: goto L_060B70E6; case 0x060B70E8u: goto L_060B70E8; case 0x060B70EAu: goto L_060B70EA; case 0x060B70EEu: goto L_060B70EE; case 0x060B70F2u: goto L_060B70F2; case 0x060B70F4u: goto L_060B70F4; case 0x060B70F8u: goto L_060B70F8; case 0x060B70FCu: goto L_060B70FC; case 0x060B70FEu: goto L_060B70FE; case 0x060B7102u: goto L_060B7102; case 0x060B7106u: goto L_060B7106; case 0x060B7108u: goto L_060B7108; case 0x060B710Cu: goto L_060B710C; case 0x060B7110u: goto L_060B7110; case 0x060B7112u: goto L_060B7112; case 0x060B7116u: goto L_060B7116; case 0x060B711Au: goto L_060B711A; case 0x060B711Cu: goto L_060B711C; case 0x060B7120u: goto L_060B7120; case 0x060B7124u: goto L_060B7124; case 0x060B7126u: goto L_060B7126; case 0x060B712Au: goto L_060B712A; case 0x060B712Eu: goto L_060B712E; case 0x060B7130u: goto L_060B7130; case 0x060B7134u: goto L_060B7134; case 0x060B7136u: goto L_060B7136; case 0x060B7138u: goto L_060B7138; case 0x060B713Au: goto L_060B713A; default: sh2_call(c, x); return; } }  // 060B6E72 jmp @r0 ; shll2 r2
L_060B6E76:
    c.t = (c.r[0] & 0x1u) == 0;  // 060B6E76 tst #1,r0
L_060B6E78:
    { const bool k = c.t; c.r[3] = 0u - c.r[3]; if (k) { goto L_060B6E8E; } }  // 060B6E78 bt/s 0x060B6E8E ; neg r3,r3
L_060B6E7C:
    c.r[5] -= 4; st32(c.r[5], c.r[3]);  // 060B6E7C mov.l r3,@-r5
L_060B6E7E:
    c.r[2] = 0u - c.r[2];  // 060B6E7E neg r2,r2
L_060B6E80:
    c.r[5] -= 4; st32(c.r[5], c.r[2]);  // 060B6E80 mov.l r2,@-r5
L_060B6E82:
    c.r[13] = 0u - c.r[13];  // 060B6E82 neg r13,r13
L_060B6E84:
    c.r[5] -= 4; st32(c.r[5], c.r[13]);  // 060B6E84 mov.l r13,@-r5
L_060B6E86:
    c.r[0] = ld32(c.r[9]); c.r[9] += 4;  // 060B6E86 mov.l @r9+,r0
L_060B6E88:
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 060B6E88 mov.w @r7+,r2
L_060B6E8A:
    { const uint32_t x = c.r[0]; c.r[2] <<= 2; SH2_POLL(c); switch (x) { case 0x060B6DFEu: goto L_060B6DFE; case 0x060B6E00u: goto L_060B6E00; case 0x060B6E02u: goto L_060B6E02; case 0x060B6E04u: goto L_060B6E04; case 0x060B6E06u: goto L_060B6E06; case 0x060B6E08u: goto L_060B6E08; case 0x060B6E0Au: goto L_060B6E0A; case 0x060B6E0Cu: goto L_060B6E0C; case 0x060B6E0Eu: goto L_060B6E0E; case 0x060B6E10u: goto L_060B6E10; case 0x060B6E12u: goto L_060B6E12; case 0x060B6E14u: goto L_060B6E14; case 0x060B6E16u: goto L_060B6E16; case 0x060B6E18u: goto L_060B6E18; case 0x060B6E1Au: goto L_060B6E1A; case 0x060B6E1Cu: goto L_060B6E1C; case 0x060B6E1Eu: goto L_060B6E1E; case 0x060B6E20u: goto L_060B6E20; case 0x060B6E22u: goto L_060B6E22; case 0x060B6E24u: goto L_060B6E24; case 0x060B6E26u: goto L_060B6E26; case 0x060B6E28u: goto L_060B6E28; case 0x060B6E2Au: goto L_060B6E2A; case 0x060B6E2Cu: goto L_060B6E2C; case 0x060B6E2Eu: goto L_060B6E2E; case 0x060B6E30u: goto L_060B6E30; case 0x060B6E32u: goto L_060B6E32; case 0x060B6E34u: goto L_060B6E34; case 0x060B6E36u: goto L_060B6E36; case 0x060B6E38u: goto L_060B6E38; case 0x060B6E3Au: goto L_060B6E3A; case 0x060B6E3Cu: goto L_060B6E3C; case 0x060B6E3Eu: goto L_060B6E3E; case 0x060B6E40u: goto L_060B6E40; case 0x060B6E42u: goto L_060B6E42; case 0x060B6E44u: goto L_060B6E44; case 0x060B6E46u: goto L_060B6E46; case 0x060B6E48u: goto L_060B6E48; case 0x060B6E4Au: goto L_060B6E4A; case 0x060B6E4Cu: goto L_060B6E4C; case 0x060B6E4Eu: goto L_060B6E4E; case 0x060B6E50u: goto L_060B6E50; case 0x060B6E52u: goto L_060B6E52; case 0x060B6E54u: goto L_060B6E54; case 0x060B6E56u: goto L_060B6E56; case 0x060B6E58u: goto L_060B6E58; case 0x060B6E5Au: goto L_060B6E5A; case 0x060B6E5Cu: goto L_060B6E5C; case 0x060B6E5Eu: goto L_060B6E5E; case 0x060B6E60u: goto L_060B6E60; case 0x060B6E62u: goto L_060B6E62; case 0x060B6E64u: goto L_060B6E64; case 0x060B6E66u: goto L_060B6E66; case 0x060B6E68u: goto L_060B6E68; case 0x060B6E6Au: goto L_060B6E6A; case 0x060B6E6Eu: goto L_060B6E6E; case 0x060B6E70u: goto L_060B6E70; case 0x060B6E72u: goto L_060B6E72; case 0x060B6E76u: goto L_060B6E76; case 0x060B6E78u: goto L_060B6E78; case 0x060B6E7Cu: goto L_060B6E7C; case 0x060B6E7Eu: goto L_060B6E7E; case 0x060B6E80u: goto L_060B6E80; case 0x060B6E82u: goto L_060B6E82; case 0x060B6E84u: goto L_060B6E84; case 0x060B6E86u: goto L_060B6E86; case 0x060B6E88u: goto L_060B6E88; case 0x060B6E8Au: goto L_060B6E8A; case 0x060B6E8Eu: goto L_060B6E8E; case 0x060B6EBCu: goto L_060B6EBC; case 0x060B6EBEu: goto L_060B6EBE; case 0x060B6EC0u: goto L_060B6EC0; case 0x060B6EC2u: goto L_060B6EC2; case 0x060B6EC6u: goto L_060B6EC6; case 0x060B6EC8u: goto L_060B6EC8; case 0x060B6ECAu: goto L_060B6ECA; case 0x060B6ECCu: goto L_060B6ECC; case 0x060B6ECEu: goto L_060B6ECE; case 0x060B6ED0u: goto L_060B6ED0; case 0x060B704Cu: goto L_060B704C; case 0x060B704Eu: goto L_060B704E; case 0x060B7050u: goto L_060B7050; case 0x060B7052u: goto L_060B7052; case 0x060B7054u: goto L_060B7054; case 0x060B7056u: goto L_060B7056; case 0x060B7058u: goto L_060B7058; case 0x060B705Au: goto L_060B705A; case 0x060B705Cu: goto L_060B705C; case 0x060B705Eu: goto L_060B705E; case 0x060B7060u: goto L_060B7060; case 0x060B7064u: goto L_060B7064; case 0x060B7066u: goto L_060B7066; case 0x060B7068u: goto L_060B7068; case 0x060B706Au: goto L_060B706A; case 0x060B706Cu: goto L_060B706C; case 0x060B7070u: goto L_060B7070; case 0x060B7072u: goto L_060B7072; case 0x060B7074u: goto L_060B7074; case 0x060B7076u: goto L_060B7076; case 0x060B7078u: goto L_060B7078; case 0x060B707Au: goto L_060B707A; case 0x060B707Cu: goto L_060B707C; case 0x060B707Eu: goto L_060B707E; case 0x060B7080u: goto L_060B7080; case 0x060B7082u: goto L_060B7082; case 0x060B7084u: goto L_060B7084; case 0x060B7086u: goto L_060B7086; case 0x060B708Au: goto L_060B708A; case 0x060B708Cu: goto L_060B708C; case 0x060B708Eu: goto L_060B708E; case 0x060B70BCu: goto L_060B70BC; case 0x060B70BEu: goto L_060B70BE; case 0x060B70C2u: goto L_060B70C2; case 0x060B70C4u: goto L_060B70C4; case 0x060B70C6u: goto L_060B70C6; case 0x060B70CAu: goto L_060B70CA; case 0x060B70CCu: goto L_060B70CC; case 0x060B70D0u: goto L_060B70D0; case 0x060B70D2u: goto L_060B70D2; case 0x060B70D6u: goto L_060B70D6; case 0x060B70D8u: goto L_060B70D8; case 0x060B70DAu: goto L_060B70DA; case 0x060B70DCu: goto L_060B70DC; case 0x060B70DEu: goto L_060B70DE; case 0x060B70E0u: goto L_060B70E0; case 0x060B70E2u: goto L_060B70E2; case 0x060B70E4u: goto L_060B70E4; case 0x060B70E6u: goto L_060B70E6; case 0x060B70E8u: goto L_060B70E8; case 0x060B70EAu: goto L_060B70EA; case 0x060B70EEu: goto L_060B70EE; case 0x060B70F2u: goto L_060B70F2; case 0x060B70F4u: goto L_060B70F4; case 0x060B70F8u: goto L_060B70F8; case 0x060B70FCu: goto L_060B70FC; case 0x060B70FEu: goto L_060B70FE; case 0x060B7102u: goto L_060B7102; case 0x060B7106u: goto L_060B7106; case 0x060B7108u: goto L_060B7108; case 0x060B710Cu: goto L_060B710C; case 0x060B7110u: goto L_060B7110; case 0x060B7112u: goto L_060B7112; case 0x060B7116u: goto L_060B7116; case 0x060B711Au: goto L_060B711A; case 0x060B711Cu: goto L_060B711C; case 0x060B7120u: goto L_060B7120; case 0x060B7124u: goto L_060B7124; case 0x060B7126u: goto L_060B7126; case 0x060B712Au: goto L_060B712A; case 0x060B712Eu: goto L_060B712E; case 0x060B7130u: goto L_060B7130; case 0x060B7134u: goto L_060B7134; case 0x060B7136u: goto L_060B7136; case 0x060B7138u: goto L_060B7138; case 0x060B713Au: goto L_060B713A; default: sh2_call(c, x); return; } }  // 060B6E8A jmp @r0 ; shll2 r2
L_060B6E8E:
    c.r[7] += 6; goto L_060B6EBC;  // 060B6E8E bra 0x060B6EBC ; add #6,r7
L_060B6EBC:
    c.r[0] = ld32(c.r[15] + 16);  // 060B6EBC mov.l @(16,r15),r0
L_060B6EBE:
    c.r[8] += 12;  // 060B6EBE add #12,r8
L_060B6EC0:
    c.r[0] -= 1; c.t = c.r[0] == 0;  // 060B6EC0 dt r0
L_060B6EC2:
    { const bool k = !c.t; st32(c.r[15] + 16, c.r[0]); if (k) { SH2_POLL(c); goto L_060B6DFE; } }  // 060B6EC2 bf/s 0x060B6DFE ; mov.l r0,@(16,r15)
L_060B6EC6:
    c.r[15] += 24;  // 060B6EC6 add #24,r15
L_060B6EC8:
    c.r[4] = ld32(c.r[15]); c.r[15] += 4;  // 060B6EC8 mov.l @r15+,r4
L_060B6ECA:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060B6ECA lds.l @r15+,pr
L_060B6ECC:
    c.r[4] += 48;  // 060B6ECC add #48,r4
L_060B6ECE:
    c.r[0] = c.r[11];  // 060B6ECE mov r11,r0
L_060B6ED0:
    { const uint32_t x = c.pr; st32(c.gbr + 52, c.r[0]); c.pc = x; return; }  // 060B6ED0 rts ; mov.l r0,@(52,gbr)
L_060B704C:
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 060B704C mov.w @r7+,r3
L_060B704E:
    c.r[2] <<= 2;  // 060B704E shll2 r2
L_060B7050:
    c.r[14] = ld32(c.r[1] + 12);  // 060B7050 mov.l @(12,r1),r14
L_060B7052:
    c.r[2] += c.r[10];  // 060B7052 add r10,r2
L_060B7054:
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 060B7054 mov.w @r7+,r4
L_060B7056:
    c.r[0] = ld32(c.r[2] + 12);  // 060B7056 mov.l @(12,r2),r0
L_060B7058:
    c.r[3] <<= 2;  // 060B7058 shll2 r3
L_060B705A:
    c.r[3] <<= 2;  // 060B705A shll2 r3
L_060B705C:
    c.r[3] += c.r[10];  // 060B705C add r10,r3
L_060B705E:
    c.t = (int32_t)c.r[14] >= (int32_t)c.r[0];  // 060B705E cmp/ge r0,r14
L_060B7060:
    { const bool k = c.t; c.r[4] <<= 2; if (k) { goto L_060B7066; } }  // 060B7060 bt/s 0x060B7066 ; shll2 r4
L_060B7064:
    c.r[14] = c.r[0];  // 060B7064 mov r0,r14
L_060B7066:
    c.r[0] = ld32(c.r[3] + 12);  // 060B7066 mov.l @(12,r3),r0
L_060B7068:
    c.r[4] <<= 2;  // 060B7068 shll2 r4
L_060B706A:
    c.t = (int32_t)c.r[14] >= (int32_t)c.r[0];  // 060B706A cmp/ge r0,r14
L_060B706C:
    { const bool k = c.t; c.r[4] += c.r[10]; if (k) { goto L_060B7072; } }  // 060B706C bt/s 0x060B7072 ; add r10,r4
L_060B7070:
    c.r[14] = c.r[0];  // 060B7070 mov r0,r14
L_060B7072:
    c.r[0] = ld32(c.r[4] + 12);  // 060B7072 mov.l @(12,r4),r0
L_060B7074:
    c.r[5] = ld32(c.r[15] + 12);  // 060B7074 mov.l @(12,r15),r5
L_060B7076:
    c.t = (int32_t)c.r[14] >= (int32_t)c.r[0];  // 060B7076 cmp/ge r0,r14
L_060B7078:
    if (c.t) { goto L_060B707C; }  // 060B7078 bt 0x060B707C
L_060B707A:
    c.r[14] = c.r[0];  // 060B707A mov r0,r14
L_060B707C:
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 160);  // 060B707C mov.w @(160,gbr),r0
L_060B707E:
    c.r[5] <<= 16;  // 060B707E shll16 r5
L_060B7080:
    c.r[0] <<= 16;  // 060B7080 shll16 r0
L_060B7082:
    c.r[0] += c.r[5];  // 060B7082 add r5,r0
L_060B7084:
    c.t = c.r[14] > c.r[0];  // 060B7084 cmp/hi r0,r14
L_060B7086:
    { const bool k = c.t; c.t = c.r[5] & 1; c.r[5] >>= 1; if (k) { goto L_060B70BE; } }  // 060B7086 bt/s 0x060B70BE ; shlr r5
L_060B708A:
    c.t = (int32_t)c.r[14] > (int32_t)c.r[5];  // 060B708A cmp/gt r5,r14
L_060B708C:
    if (!c.t) { goto L_060B70BE; }  // 060B708C bf 0x060B70BE
L_060B708E:
    c.r[14] >>= 16; goto L_060B70C2;  // 060B708E bra 0x060B70C2 ; shlr16 r14
L_060B70BC:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060B70BC mov.l @r15+,r14
L_060B70BE:
    SH2_POLL(c); goto L_060B6EBC;  // 060B70BE bra 0x060B6EBC ; nop
L_060B70C2:
    c.r[0] = ld32(c.r[1] + 4);  // 060B70C2 mov.l @(4,r1),r0
L_060B70C4:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B70C4 shar r0
L_060B70C6:
    { const bool k = !c.t; c.r[0] = ld32(c.r[2] + 4); if (k) { goto L_060B70DA; } }  // 060B70C6 bf/s 0x060B70DA ; mov.l @(4,r2),r0
L_060B70CA:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B70CA shar r0
L_060B70CC:
    { const bool k = !c.t; c.r[0] = ld32(c.r[3] + 4); if (k) { goto L_060B70DA; } }  // 060B70CC bf/s 0x060B70DA ; mov.l @(4,r3),r0
L_060B70D0:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B70D0 shar r0
L_060B70D2:
    { const bool k = !c.t; c.r[0] = ld32(c.r[4] + 4); if (k) { goto L_060B70DA; } }  // 060B70D2 bf/s 0x060B70DA ; mov.l @(4,r4),r0
L_060B70D6:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B70D6 shar r0
L_060B70D8:
    if (c.t) { SH2_POLL(c); goto L_060B70BE; }  // 060B70D8 bt 0x060B70BE
L_060B70DA:
    c.r[0] = ld32(c.gbr + 892);  // 060B70DA mov.l @(892,gbr),r0
L_060B70DC:
    c.t = c.r[0] & 1; c.r[0] = c.r[0] >> 1 | c.t << 31;  // 060B70DC rotr r0
L_060B70DE:
    if (c.t) { goto L_060B7138; }  // 060B70DE bt 0x060B7138
L_060B70E0:
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060B70E0 mov.l r14,@-r15
L_060B70E2:
    c.r[14] = (uint32_t)(int16_t)ld16(0x060B7140u);  // 060B70E2 mov.w 0x060B7140,r14
L_060B70E4:
    c.r[5] = (uint32_t)(int16_t)ld16(0x060B7142u);  // 060B70E4 mov.w 0x060B7142,r5
L_060B70E6:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060B70E6 mov.w @(0,r1),r0
L_060B70E8:
    c.t = (int32_t)c.r[0] > (int32_t)c.r[5];  // 060B70E8 cmp/gt r5,r0
L_060B70EA:
    { const bool k = c.t; c.t = (int32_t)c.r[0] >= (int32_t)c.r[14]; if (k) { SH2_POLL(c); goto L_060B70BC; } }  // 060B70EA bt/s 0x060B70BC ; cmp/ge r14,r0
L_060B70EE:
    { const bool k = !c.t; c.r[0] = (uint32_t)(int16_t)ld16(c.r[1] + 2); if (k) { SH2_POLL(c); goto L_060B70BC; } }  // 060B70EE bf/s 0x060B70BC ; mov.w @(2,r1),r0
L_060B70F2:
    c.t = (int32_t)c.r[0] > (int32_t)c.r[5];  // 060B70F2 cmp/gt r5,r0
L_060B70F4:
    { const bool k = c.t; c.t = (int32_t)c.r[0] >= (int32_t)c.r[14]; if (k) { SH2_POLL(c); goto L_060B70BC; } }  // 060B70F4 bt/s 0x060B70BC ; cmp/ge r14,r0
L_060B70F8:
    { const bool k = !c.t; c.r[0] = (uint32_t)(int16_t)ld16(c.r[2]); if (k) { SH2_POLL(c); goto L_060B70BC; } }  // 060B70F8 bf/s 0x060B70BC ; mov.w @(0,r2),r0
L_060B70FC:
    c.t = (int32_t)c.r[0] > (int32_t)c.r[5];  // 060B70FC cmp/gt r5,r0
L_060B70FE:
    { const bool k = c.t; c.t = (int32_t)c.r[0] >= (int32_t)c.r[14]; if (k) { SH2_POLL(c); goto L_060B70BC; } }  // 060B70FE bt/s 0x060B70BC ; cmp/ge r14,r0
L_060B7102:
    { const bool k = !c.t; c.r[0] = (uint32_t)(int16_t)ld16(c.r[2] + 2); if (k) { SH2_POLL(c); goto L_060B70BC; } }  // 060B7102 bf/s 0x060B70BC ; mov.w @(2,r2),r0
L_060B7106:
    c.t = (int32_t)c.r[0] > (int32_t)c.r[5];  // 060B7106 cmp/gt r5,r0
L_060B7108:
    { const bool k = c.t; c.t = (int32_t)c.r[0] >= (int32_t)c.r[14]; if (k) { SH2_POLL(c); goto L_060B70BC; } }  // 060B7108 bt/s 0x060B70BC ; cmp/ge r14,r0
L_060B710C:
    { const bool k = !c.t; c.r[0] = (uint32_t)(int16_t)ld16(c.r[3]); if (k) { SH2_POLL(c); goto L_060B70BC; } }  // 060B710C bf/s 0x060B70BC ; mov.w @(0,r3),r0
L_060B7110:
    c.t = (int32_t)c.r[0] > (int32_t)c.r[5];  // 060B7110 cmp/gt r5,r0
L_060B7112:
    { const bool k = c.t; c.t = (int32_t)c.r[0] >= (int32_t)c.r[14]; if (k) { SH2_POLL(c); goto L_060B70BC; } }  // 060B7112 bt/s 0x060B70BC ; cmp/ge r14,r0
L_060B7116:
    { const bool k = !c.t; c.r[0] = (uint32_t)(int16_t)ld16(c.r[3] + 2); if (k) { SH2_POLL(c); goto L_060B70BC; } }  // 060B7116 bf/s 0x060B70BC ; mov.w @(2,r3),r0
L_060B711A:
    c.t = (int32_t)c.r[0] > (int32_t)c.r[5];  // 060B711A cmp/gt r5,r0
L_060B711C:
    { const bool k = c.t; c.t = (int32_t)c.r[0] >= (int32_t)c.r[14]; if (k) { SH2_POLL(c); goto L_060B70BC; } }  // 060B711C bt/s 0x060B70BC ; cmp/ge r14,r0
L_060B7120:
    { const bool k = !c.t; c.r[0] = (uint32_t)(int16_t)ld16(c.r[4]); if (k) { SH2_POLL(c); goto L_060B70BC; } }  // 060B7120 bf/s 0x060B70BC ; mov.w @(0,r4),r0
L_060B7124:
    c.t = (int32_t)c.r[0] > (int32_t)c.r[5];  // 060B7124 cmp/gt r5,r0
L_060B7126:
    { const bool k = c.t; c.t = (int32_t)c.r[0] >= (int32_t)c.r[14]; if (k) { SH2_POLL(c); goto L_060B70BC; } }  // 060B7126 bt/s 0x060B70BC ; cmp/ge r14,r0
L_060B712A:
    { const bool k = !c.t; c.r[0] = (uint32_t)(int16_t)ld16(c.r[4] + 2); if (k) { SH2_POLL(c); goto L_060B70BC; } }  // 060B712A bf/s 0x060B70BC ; mov.w @(2,r4),r0
L_060B712E:
    c.t = (int32_t)c.r[0] > (int32_t)c.r[5];  // 060B712E cmp/gt r5,r0
L_060B7130:
    { const bool k = c.t; c.t = (int32_t)c.r[0] >= (int32_t)c.r[14]; if (k) { SH2_POLL(c); goto L_060B70BC; } }  // 060B7130 bt/s 0x060B70BC ; cmp/ge r14,r0
L_060B7134:
    if (!c.t) { SH2_POLL(c); goto L_060B70BC; }  // 060B7134 bf 0x060B70BC
L_060B7136:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060B7136 mov.l @r15+,r14
L_060B7138:
    c.r[0] = ld32(c.r[9]); c.r[9] += 4;  // 060B7138 mov.l @r9+,r0
L_060B713A:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x060B6DFEu: goto L_060B6DFE; case 0x060B6E00u: goto L_060B6E00; case 0x060B6E02u: goto L_060B6E02; case 0x060B6E04u: goto L_060B6E04; case 0x060B6E06u: goto L_060B6E06; case 0x060B6E08u: goto L_060B6E08; case 0x060B6E0Au: goto L_060B6E0A; case 0x060B6E0Cu: goto L_060B6E0C; case 0x060B6E0Eu: goto L_060B6E0E; case 0x060B6E10u: goto L_060B6E10; case 0x060B6E12u: goto L_060B6E12; case 0x060B6E14u: goto L_060B6E14; case 0x060B6E16u: goto L_060B6E16; case 0x060B6E18u: goto L_060B6E18; case 0x060B6E1Au: goto L_060B6E1A; case 0x060B6E1Cu: goto L_060B6E1C; case 0x060B6E1Eu: goto L_060B6E1E; case 0x060B6E20u: goto L_060B6E20; case 0x060B6E22u: goto L_060B6E22; case 0x060B6E24u: goto L_060B6E24; case 0x060B6E26u: goto L_060B6E26; case 0x060B6E28u: goto L_060B6E28; case 0x060B6E2Au: goto L_060B6E2A; case 0x060B6E2Cu: goto L_060B6E2C; case 0x060B6E2Eu: goto L_060B6E2E; case 0x060B6E30u: goto L_060B6E30; case 0x060B6E32u: goto L_060B6E32; case 0x060B6E34u: goto L_060B6E34; case 0x060B6E36u: goto L_060B6E36; case 0x060B6E38u: goto L_060B6E38; case 0x060B6E3Au: goto L_060B6E3A; case 0x060B6E3Cu: goto L_060B6E3C; case 0x060B6E3Eu: goto L_060B6E3E; case 0x060B6E40u: goto L_060B6E40; case 0x060B6E42u: goto L_060B6E42; case 0x060B6E44u: goto L_060B6E44; case 0x060B6E46u: goto L_060B6E46; case 0x060B6E48u: goto L_060B6E48; case 0x060B6E4Au: goto L_060B6E4A; case 0x060B6E4Cu: goto L_060B6E4C; case 0x060B6E4Eu: goto L_060B6E4E; case 0x060B6E50u: goto L_060B6E50; case 0x060B6E52u: goto L_060B6E52; case 0x060B6E54u: goto L_060B6E54; case 0x060B6E56u: goto L_060B6E56; case 0x060B6E58u: goto L_060B6E58; case 0x060B6E5Au: goto L_060B6E5A; case 0x060B6E5Cu: goto L_060B6E5C; case 0x060B6E5Eu: goto L_060B6E5E; case 0x060B6E60u: goto L_060B6E60; case 0x060B6E62u: goto L_060B6E62; case 0x060B6E64u: goto L_060B6E64; case 0x060B6E66u: goto L_060B6E66; case 0x060B6E68u: goto L_060B6E68; case 0x060B6E6Au: goto L_060B6E6A; case 0x060B6E6Eu: goto L_060B6E6E; case 0x060B6E70u: goto L_060B6E70; case 0x060B6E72u: goto L_060B6E72; case 0x060B6E76u: goto L_060B6E76; case 0x060B6E78u: goto L_060B6E78; case 0x060B6E7Cu: goto L_060B6E7C; case 0x060B6E7Eu: goto L_060B6E7E; case 0x060B6E80u: goto L_060B6E80; case 0x060B6E82u: goto L_060B6E82; case 0x060B6E84u: goto L_060B6E84; case 0x060B6E86u: goto L_060B6E86; case 0x060B6E88u: goto L_060B6E88; case 0x060B6E8Au: goto L_060B6E8A; case 0x060B6E8Eu: goto L_060B6E8E; case 0x060B6EBCu: goto L_060B6EBC; case 0x060B6EBEu: goto L_060B6EBE; case 0x060B6EC0u: goto L_060B6EC0; case 0x060B6EC2u: goto L_060B6EC2; case 0x060B6EC6u: goto L_060B6EC6; case 0x060B6EC8u: goto L_060B6EC8; case 0x060B6ECAu: goto L_060B6ECA; case 0x060B6ECCu: goto L_060B6ECC; case 0x060B6ECEu: goto L_060B6ECE; case 0x060B6ED0u: goto L_060B6ED0; case 0x060B704Cu: goto L_060B704C; case 0x060B704Eu: goto L_060B704E; case 0x060B7050u: goto L_060B7050; case 0x060B7052u: goto L_060B7052; case 0x060B7054u: goto L_060B7054; case 0x060B7056u: goto L_060B7056; case 0x060B7058u: goto L_060B7058; case 0x060B705Au: goto L_060B705A; case 0x060B705Cu: goto L_060B705C; case 0x060B705Eu: goto L_060B705E; case 0x060B7060u: goto L_060B7060; case 0x060B7064u: goto L_060B7064; case 0x060B7066u: goto L_060B7066; case 0x060B7068u: goto L_060B7068; case 0x060B706Au: goto L_060B706A; case 0x060B706Cu: goto L_060B706C; case 0x060B7070u: goto L_060B7070; case 0x060B7072u: goto L_060B7072; case 0x060B7074u: goto L_060B7074; case 0x060B7076u: goto L_060B7076; case 0x060B7078u: goto L_060B7078; case 0x060B707Au: goto L_060B707A; case 0x060B707Cu: goto L_060B707C; case 0x060B707Eu: goto L_060B707E; case 0x060B7080u: goto L_060B7080; case 0x060B7082u: goto L_060B7082; case 0x060B7084u: goto L_060B7084; case 0x060B7086u: goto L_060B7086; case 0x060B708Au: goto L_060B708A; case 0x060B708Cu: goto L_060B708C; case 0x060B708Eu: goto L_060B708E; case 0x060B70BCu: goto L_060B70BC; case 0x060B70BEu: goto L_060B70BE; case 0x060B70C2u: goto L_060B70C2; case 0x060B70C4u: goto L_060B70C4; case 0x060B70C6u: goto L_060B70C6; case 0x060B70CAu: goto L_060B70CA; case 0x060B70CCu: goto L_060B70CC; case 0x060B70D0u: goto L_060B70D0; case 0x060B70D2u: goto L_060B70D2; case 0x060B70D6u: goto L_060B70D6; case 0x060B70D8u: goto L_060B70D8; case 0x060B70DAu: goto L_060B70DA; case 0x060B70DCu: goto L_060B70DC; case 0x060B70DEu: goto L_060B70DE; case 0x060B70E0u: goto L_060B70E0; case 0x060B70E2u: goto L_060B70E2; case 0x060B70E4u: goto L_060B70E4; case 0x060B70E6u: goto L_060B70E6; case 0x060B70E8u: goto L_060B70E8; case 0x060B70EAu: goto L_060B70EA; case 0x060B70EEu: goto L_060B70EE; case 0x060B70F2u: goto L_060B70F2; case 0x060B70F4u: goto L_060B70F4; case 0x060B70F8u: goto L_060B70F8; case 0x060B70FCu: goto L_060B70FC; case 0x060B70FEu: goto L_060B70FE; case 0x060B7102u: goto L_060B7102; case 0x060B7106u: goto L_060B7106; case 0x060B7108u: goto L_060B7108; case 0x060B710Cu: goto L_060B710C; case 0x060B7110u: goto L_060B7110; case 0x060B7112u: goto L_060B7112; case 0x060B7116u: goto L_060B7116; case 0x060B711Au: goto L_060B711A; case 0x060B711Cu: goto L_060B711C; case 0x060B7120u: goto L_060B7120; case 0x060B7124u: goto L_060B7124; case 0x060B7126u: goto L_060B7126; case 0x060B712Au: goto L_060B712A; case 0x060B712Eu: goto L_060B712E; case 0x060B7130u: goto L_060B7130; case 0x060B7134u: goto L_060B7134; case 0x060B7136u: goto L_060B7136; case 0x060B7138u: goto L_060B7138; case 0x060B713Au: goto L_060B713A; default: sh2_call(c, x); return; } }  // 060B713A jmp @r0 ; nop
}

void f_060B7098(SH2Context& c) {
    ran[3136] = 1;
    goto L_060B7098;
L_060B6DFE:
    c.mach = c.macl = 0;  // 060B6DFE clrmac
L_060B6E00:
    sh2_mac_l(c, 6, 7);  // 060B6E00 mac.l @r7+,@r6+
L_060B6E02:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[7] + 8);  // 060B6E02 mov.w @(8,r7),r0
L_060B6E04:
    c.r[5] = c.r[15];  // 060B6E04 mov r15,r5
L_060B6E06:
    sh2_mac_l(c, 6, 7);  // 060B6E06 mac.l @r7+,@r6+
L_060B6E08:
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B6E08 exts.w r0,r1
L_060B6E0A:
    c.r[1] <<= 2;  // 060B6E0A shll2 r1
L_060B6E0C:
    sh2_mac_l(c, 6, 7);  // 060B6E0C mac.l @r7+,@r6+
L_060B6E0E:
    c.r[6] += 4;  // 060B6E0E add #4,r6
L_060B6E10:
    c.r[7] -= 12;  // 060B6E10 add #-12,r7
L_060B6E12:
    c.r[1] <<= 2;  // 060B6E12 shll2 r1
L_060B6E14:
    c.r[0] = c.mach;  // 060B6E14 sts mach,r0
L_060B6E16:
    c.r[13] = c.macl;  // 060B6E16 sts macl,r13
L_060B6E18:
    c.mach = c.macl = 0;  // 060B6E18 clrmac
L_060B6E1A:
    sh2_mac_l(c, 6, 7);  // 060B6E1A mac.l @r7+,@r6+
L_060B6E1C:
    c.r[13] = c.r[0] << 16 | c.r[13] >> 16;  // 060B6E1C xtrct r0,r13
L_060B6E1E:
    st32(c.r[5], c.r[13]);  // 060B6E1E mov.l r13,@(0,r5)
L_060B6E20:
    sh2_mac_l(c, 6, 7);  // 060B6E20 mac.l @r7+,@r6+
L_060B6E22:
    c.r[1] += c.r[10];  // 060B6E22 add r10,r1
L_060B6E24:
    c.r[4] = 0x4u;  // 060B6E24 mov #4,r4
L_060B6E26:
    sh2_mac_l(c, 6, 7);  // 060B6E26 mac.l @r7+,@r6+
L_060B6E28:
    c.r[6] += 4;  // 060B6E28 add #4,r6
L_060B6E2A:
    c.r[7] -= 12;  // 060B6E2A add #-12,r7
L_060B6E2C:
    c.r[4] += c.r[1];  // 060B6E2C add r1,r4
L_060B6E2E:
    c.r[0] = c.mach;  // 060B6E2E sts mach,r0
L_060B6E30:
    c.r[2] = c.macl;  // 060B6E30 sts macl,r2
L_060B6E32:
    c.mach = c.macl = 0;  // 060B6E32 clrmac
L_060B6E34:
    sh2_mac_l(c, 6, 7);  // 060B6E34 mac.l @r7+,@r6+
L_060B6E36:
    c.r[2] = c.r[0] << 16 | c.r[2] >> 16;  // 060B6E36 xtrct r0,r2
L_060B6E38:
    st32(c.r[5] + 4, c.r[2]);  // 060B6E38 mov.l r2,@(4,r5)
L_060B6E3A:
    sh2_mac_l(c, 6, 7);  // 060B6E3A mac.l @r7+,@r6+
L_060B6E3C:
    c.r[12] = (uint32_t)(int16_t)ld16(c.r[8]);  // 060B6E3C mov.w @r8,r12
L_060B6E3E:
    c.r[9] = 0x7Fu;  // 060B6E3E mov #127,r9
L_060B6E40:
    sh2_mac_l(c, 6, 7);  // 060B6E40 mac.l @r7+,@r6+
L_060B6E42:
    c.r[6] -= 44;  // 060B6E42 add #-44,r6
L_060B6E44:
    c.r[9] &= c.r[12];  // 060B6E44 and r12,r9
L_060B6E46:
    c.r[9] <<= 2;  // 060B6E46 shll2 r9
L_060B6E48:
    c.r[0] = c.mach;  // 060B6E48 sts mach,r0
L_060B6E4A:
    c.r[3] = c.macl;  // 060B6E4A sts macl,r3
L_060B6E4C:
    c.mach = c.macl = 0;  // 060B6E4C clrmac
L_060B6E4E:
    sh2_mac_l(c, 5, 4);  // 060B6E4E mac.l @r4+,@r5+
L_060B6E50:
    c.r[3] = c.r[0] << 16 | c.r[3] >> 16;  // 060B6E50 xtrct r0,r3
L_060B6E52:
    c.r[0] = 0x060B7144u;  // 060B6E52 mova 0x060B7144,r0
L_060B6E54:
    sh2_mac_l(c, 5, 4);  // 060B6E54 mac.l @r4+,@r5+
L_060B6E56:
    st32(c.r[5], c.r[3]);  // 060B6E56 mov.l r3,@r5
L_060B6E58:
    c.r[9] <<= 2;  // 060B6E58 shll2 r9
L_060B6E5A:
    sh2_mac_l(c, 5, 4);  // 060B6E5A mac.l @r4+,@r5+
L_060B6E5C:
    c.r[9] += c.r[0];  // 060B6E5C add r0,r9
L_060B6E5E:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[8] + 10);  // 060B6E5E mov.w @(10,r8),r0
L_060B6E60:
    c.r[7] += 2;  // 060B6E60 add #2,r7
L_060B6E62:
    c.r[4] = c.mach;  // 060B6E62 sts mach,r4
L_060B6E64:
    st16(c.r[11], c.r[0]);  // 060B6E64 mov.w r0,@(0,r11)
L_060B6E66:
    c.r[0] = ld32(c.gbr + 900);  // 060B6E66 mov.l @(900,gbr),r0
L_060B6E68:
    c.t = (int32_t)c.r[4] >= (int32_t)c.r[0];  // 060B6E68 cmp/ge r0,r4
L_060B6E6A:
    { const bool k = c.t; c.r[0] = (c.r[12] & 0xFFFF0000u) | (c.r[12] & 0xFFu) << 8 | (c.r[12] >> 8 & 0xFFu); if (k) { goto L_060B6E76; } }  // 060B6E6A bt/s 0x060B6E76 ; swap.b r12,r0
L_060B6E6E:
    c.r[0] = ld32(c.r[9]); c.r[9] += 4;  // 060B6E6E mov.l @r9+,r0
L_060B6E70:
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 060B6E70 mov.w @r7+,r2
L_060B6E72:
    { const uint32_t x = c.r[0]; c.r[2] <<= 2; SH2_POLL(c); switch (x) { case 0x060B6DFEu: goto L_060B6DFE; case 0x060B6E00u: goto L_060B6E00; case 0x060B6E02u: goto L_060B6E02; case 0x060B6E04u: goto L_060B6E04; case 0x060B6E06u: goto L_060B6E06; case 0x060B6E08u: goto L_060B6E08; case 0x060B6E0Au: goto L_060B6E0A; case 0x060B6E0Cu: goto L_060B6E0C; case 0x060B6E0Eu: goto L_060B6E0E; case 0x060B6E10u: goto L_060B6E10; case 0x060B6E12u: goto L_060B6E12; case 0x060B6E14u: goto L_060B6E14; case 0x060B6E16u: goto L_060B6E16; case 0x060B6E18u: goto L_060B6E18; case 0x060B6E1Au: goto L_060B6E1A; case 0x060B6E1Cu: goto L_060B6E1C; case 0x060B6E1Eu: goto L_060B6E1E; case 0x060B6E20u: goto L_060B6E20; case 0x060B6E22u: goto L_060B6E22; case 0x060B6E24u: goto L_060B6E24; case 0x060B6E26u: goto L_060B6E26; case 0x060B6E28u: goto L_060B6E28; case 0x060B6E2Au: goto L_060B6E2A; case 0x060B6E2Cu: goto L_060B6E2C; case 0x060B6E2Eu: goto L_060B6E2E; case 0x060B6E30u: goto L_060B6E30; case 0x060B6E32u: goto L_060B6E32; case 0x060B6E34u: goto L_060B6E34; case 0x060B6E36u: goto L_060B6E36; case 0x060B6E38u: goto L_060B6E38; case 0x060B6E3Au: goto L_060B6E3A; case 0x060B6E3Cu: goto L_060B6E3C; case 0x060B6E3Eu: goto L_060B6E3E; case 0x060B6E40u: goto L_060B6E40; case 0x060B6E42u: goto L_060B6E42; case 0x060B6E44u: goto L_060B6E44; case 0x060B6E46u: goto L_060B6E46; case 0x060B6E48u: goto L_060B6E48; case 0x060B6E4Au: goto L_060B6E4A; case 0x060B6E4Cu: goto L_060B6E4C; case 0x060B6E4Eu: goto L_060B6E4E; case 0x060B6E50u: goto L_060B6E50; case 0x060B6E52u: goto L_060B6E52; case 0x060B6E54u: goto L_060B6E54; case 0x060B6E56u: goto L_060B6E56; case 0x060B6E58u: goto L_060B6E58; case 0x060B6E5Au: goto L_060B6E5A; case 0x060B6E5Cu: goto L_060B6E5C; case 0x060B6E5Eu: goto L_060B6E5E; case 0x060B6E60u: goto L_060B6E60; case 0x060B6E62u: goto L_060B6E62; case 0x060B6E64u: goto L_060B6E64; case 0x060B6E66u: goto L_060B6E66; case 0x060B6E68u: goto L_060B6E68; case 0x060B6E6Au: goto L_060B6E6A; case 0x060B6E6Eu: goto L_060B6E6E; case 0x060B6E70u: goto L_060B6E70; case 0x060B6E72u: goto L_060B6E72; case 0x060B6E76u: goto L_060B6E76; case 0x060B6E78u: goto L_060B6E78; case 0x060B6E7Cu: goto L_060B6E7C; case 0x060B6E7Eu: goto L_060B6E7E; case 0x060B6E80u: goto L_060B6E80; case 0x060B6E82u: goto L_060B6E82; case 0x060B6E84u: goto L_060B6E84; case 0x060B6E86u: goto L_060B6E86; case 0x060B6E88u: goto L_060B6E88; case 0x060B6E8Au: goto L_060B6E8A; case 0x060B6E8Eu: goto L_060B6E8E; case 0x060B6EBCu: goto L_060B6EBC; case 0x060B6EBEu: goto L_060B6EBE; case 0x060B6EC0u: goto L_060B6EC0; case 0x060B6EC2u: goto L_060B6EC2; case 0x060B6EC6u: goto L_060B6EC6; case 0x060B6EC8u: goto L_060B6EC8; case 0x060B6ECAu: goto L_060B6ECA; case 0x060B6ECCu: goto L_060B6ECC; case 0x060B6ECEu: goto L_060B6ECE; case 0x060B6ED0u: goto L_060B6ED0; case 0x060B7098u: goto L_060B7098; case 0x060B709Au: goto L_060B709A; case 0x060B709Cu: goto L_060B709C; case 0x060B709Eu: goto L_060B709E; case 0x060B70A2u: goto L_060B70A2; case 0x060B70A4u: goto L_060B70A4; case 0x060B70A6u: goto L_060B70A6; case 0x060B70A8u: goto L_060B70A8; case 0x060B70AAu: goto L_060B70AA; case 0x060B70ACu: goto L_060B70AC; case 0x060B70AEu: goto L_060B70AE; case 0x060B70B0u: goto L_060B70B0; case 0x060B70B2u: goto L_060B70B2; case 0x060B70B6u: goto L_060B70B6; default: sh2_call(c, x); return; } }  // 060B6E72 jmp @r0 ; shll2 r2
L_060B6E76:
    c.t = (c.r[0] & 0x1u) == 0;  // 060B6E76 tst #1,r0
L_060B6E78:
    { const bool k = c.t; c.r[3] = 0u - c.r[3]; if (k) { goto L_060B6E8E; } }  // 060B6E78 bt/s 0x060B6E8E ; neg r3,r3
L_060B6E7C:
    c.r[5] -= 4; st32(c.r[5], c.r[3]);  // 060B6E7C mov.l r3,@-r5
L_060B6E7E:
    c.r[2] = 0u - c.r[2];  // 060B6E7E neg r2,r2
L_060B6E80:
    c.r[5] -= 4; st32(c.r[5], c.r[2]);  // 060B6E80 mov.l r2,@-r5
L_060B6E82:
    c.r[13] = 0u - c.r[13];  // 060B6E82 neg r13,r13
L_060B6E84:
    c.r[5] -= 4; st32(c.r[5], c.r[13]);  // 060B6E84 mov.l r13,@-r5
L_060B6E86:
    c.r[0] = ld32(c.r[9]); c.r[9] += 4;  // 060B6E86 mov.l @r9+,r0
L_060B6E88:
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 060B6E88 mov.w @r7+,r2
L_060B6E8A:
    { const uint32_t x = c.r[0]; c.r[2] <<= 2; SH2_POLL(c); switch (x) { case 0x060B6DFEu: goto L_060B6DFE; case 0x060B6E00u: goto L_060B6E00; case 0x060B6E02u: goto L_060B6E02; case 0x060B6E04u: goto L_060B6E04; case 0x060B6E06u: goto L_060B6E06; case 0x060B6E08u: goto L_060B6E08; case 0x060B6E0Au: goto L_060B6E0A; case 0x060B6E0Cu: goto L_060B6E0C; case 0x060B6E0Eu: goto L_060B6E0E; case 0x060B6E10u: goto L_060B6E10; case 0x060B6E12u: goto L_060B6E12; case 0x060B6E14u: goto L_060B6E14; case 0x060B6E16u: goto L_060B6E16; case 0x060B6E18u: goto L_060B6E18; case 0x060B6E1Au: goto L_060B6E1A; case 0x060B6E1Cu: goto L_060B6E1C; case 0x060B6E1Eu: goto L_060B6E1E; case 0x060B6E20u: goto L_060B6E20; case 0x060B6E22u: goto L_060B6E22; case 0x060B6E24u: goto L_060B6E24; case 0x060B6E26u: goto L_060B6E26; case 0x060B6E28u: goto L_060B6E28; case 0x060B6E2Au: goto L_060B6E2A; case 0x060B6E2Cu: goto L_060B6E2C; case 0x060B6E2Eu: goto L_060B6E2E; case 0x060B6E30u: goto L_060B6E30; case 0x060B6E32u: goto L_060B6E32; case 0x060B6E34u: goto L_060B6E34; case 0x060B6E36u: goto L_060B6E36; case 0x060B6E38u: goto L_060B6E38; case 0x060B6E3Au: goto L_060B6E3A; case 0x060B6E3Cu: goto L_060B6E3C; case 0x060B6E3Eu: goto L_060B6E3E; case 0x060B6E40u: goto L_060B6E40; case 0x060B6E42u: goto L_060B6E42; case 0x060B6E44u: goto L_060B6E44; case 0x060B6E46u: goto L_060B6E46; case 0x060B6E48u: goto L_060B6E48; case 0x060B6E4Au: goto L_060B6E4A; case 0x060B6E4Cu: goto L_060B6E4C; case 0x060B6E4Eu: goto L_060B6E4E; case 0x060B6E50u: goto L_060B6E50; case 0x060B6E52u: goto L_060B6E52; case 0x060B6E54u: goto L_060B6E54; case 0x060B6E56u: goto L_060B6E56; case 0x060B6E58u: goto L_060B6E58; case 0x060B6E5Au: goto L_060B6E5A; case 0x060B6E5Cu: goto L_060B6E5C; case 0x060B6E5Eu: goto L_060B6E5E; case 0x060B6E60u: goto L_060B6E60; case 0x060B6E62u: goto L_060B6E62; case 0x060B6E64u: goto L_060B6E64; case 0x060B6E66u: goto L_060B6E66; case 0x060B6E68u: goto L_060B6E68; case 0x060B6E6Au: goto L_060B6E6A; case 0x060B6E6Eu: goto L_060B6E6E; case 0x060B6E70u: goto L_060B6E70; case 0x060B6E72u: goto L_060B6E72; case 0x060B6E76u: goto L_060B6E76; case 0x060B6E78u: goto L_060B6E78; case 0x060B6E7Cu: goto L_060B6E7C; case 0x060B6E7Eu: goto L_060B6E7E; case 0x060B6E80u: goto L_060B6E80; case 0x060B6E82u: goto L_060B6E82; case 0x060B6E84u: goto L_060B6E84; case 0x060B6E86u: goto L_060B6E86; case 0x060B6E88u: goto L_060B6E88; case 0x060B6E8Au: goto L_060B6E8A; case 0x060B6E8Eu: goto L_060B6E8E; case 0x060B6EBCu: goto L_060B6EBC; case 0x060B6EBEu: goto L_060B6EBE; case 0x060B6EC0u: goto L_060B6EC0; case 0x060B6EC2u: goto L_060B6EC2; case 0x060B6EC6u: goto L_060B6EC6; case 0x060B6EC8u: goto L_060B6EC8; case 0x060B6ECAu: goto L_060B6ECA; case 0x060B6ECCu: goto L_060B6ECC; case 0x060B6ECEu: goto L_060B6ECE; case 0x060B6ED0u: goto L_060B6ED0; case 0x060B7098u: goto L_060B7098; case 0x060B709Au: goto L_060B709A; case 0x060B709Cu: goto L_060B709C; case 0x060B709Eu: goto L_060B709E; case 0x060B70A2u: goto L_060B70A2; case 0x060B70A4u: goto L_060B70A4; case 0x060B70A6u: goto L_060B70A6; case 0x060B70A8u: goto L_060B70A8; case 0x060B70AAu: goto L_060B70AA; case 0x060B70ACu: goto L_060B70AC; case 0x060B70AEu: goto L_060B70AE; case 0x060B70B0u: goto L_060B70B0; case 0x060B70B2u: goto L_060B70B2; case 0x060B70B6u: goto L_060B70B6; default: sh2_call(c, x); return; } }  // 060B6E8A jmp @r0 ; shll2 r2
L_060B6E8E:
    c.r[7] += 6; goto L_060B6EBC;  // 060B6E8E bra 0x060B6EBC ; add #6,r7
L_060B6EBC:
    c.r[0] = ld32(c.r[15] + 16);  // 060B6EBC mov.l @(16,r15),r0
L_060B6EBE:
    c.r[8] += 12;  // 060B6EBE add #12,r8
L_060B6EC0:
    c.r[0] -= 1; c.t = c.r[0] == 0;  // 060B6EC0 dt r0
L_060B6EC2:
    { const bool k = !c.t; st32(c.r[15] + 16, c.r[0]); if (k) { SH2_POLL(c); goto L_060B6DFE; } }  // 060B6EC2 bf/s 0x060B6DFE ; mov.l r0,@(16,r15)
L_060B6EC6:
    c.r[15] += 24;  // 060B6EC6 add #24,r15
L_060B6EC8:
    c.r[4] = ld32(c.r[15]); c.r[15] += 4;  // 060B6EC8 mov.l @r15+,r4
L_060B6ECA:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060B6ECA lds.l @r15+,pr
L_060B6ECC:
    c.r[4] += 48;  // 060B6ECC add #48,r4
L_060B6ECE:
    c.r[0] = c.r[11];  // 060B6ECE mov r11,r0
L_060B6ED0:
    { const uint32_t x = c.pr; st32(c.gbr + 52, c.r[0]); c.pc = x; return; }  // 060B6ED0 rts ; mov.l r0,@(52,gbr)
L_060B7098:
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 160);  // 060B7098 mov.w @(160,gbr),r0
L_060B709A:
    c.r[2] <<= 2;  // 060B709A shll2 r2
L_060B709C:
    c.t = c.r[14] > c.r[0];  // 060B709C cmp/hi r0,r14
L_060B709E:
    { const bool k = c.t; c.r[2] += c.r[10]; if (k) { goto L_060B70B6; } }  // 060B709E bt/s 0x060B70B6 ; add r10,r2
L_060B70A2:
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 060B70A2 mov.w @r7+,r3
L_060B70A4:
    c.r[3] <<= 2;  // 060B70A4 shll2 r3
L_060B70A6:
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 060B70A6 mov.w @r7+,r4
L_060B70A8:
    c.r[3] <<= 2;  // 060B70A8 shll2 r3
L_060B70AA:
    c.r[3] += c.r[10];  // 060B70AA add r10,r3
L_060B70AC:
    c.r[4] <<= 2;  // 060B70AC shll2 r4
L_060B70AE:
    c.r[0] = ld32(c.r[9]); c.r[9] += 4;  // 060B70AE mov.l @r9+,r0
L_060B70B0:
    c.r[4] <<= 2;  // 060B70B0 shll2 r4
L_060B70B2:
    { const uint32_t x = c.r[0]; c.r[4] += c.r[10]; SH2_POLL(c); switch (x) { case 0x060B6DFEu: goto L_060B6DFE; case 0x060B6E00u: goto L_060B6E00; case 0x060B6E02u: goto L_060B6E02; case 0x060B6E04u: goto L_060B6E04; case 0x060B6E06u: goto L_060B6E06; case 0x060B6E08u: goto L_060B6E08; case 0x060B6E0Au: goto L_060B6E0A; case 0x060B6E0Cu: goto L_060B6E0C; case 0x060B6E0Eu: goto L_060B6E0E; case 0x060B6E10u: goto L_060B6E10; case 0x060B6E12u: goto L_060B6E12; case 0x060B6E14u: goto L_060B6E14; case 0x060B6E16u: goto L_060B6E16; case 0x060B6E18u: goto L_060B6E18; case 0x060B6E1Au: goto L_060B6E1A; case 0x060B6E1Cu: goto L_060B6E1C; case 0x060B6E1Eu: goto L_060B6E1E; case 0x060B6E20u: goto L_060B6E20; case 0x060B6E22u: goto L_060B6E22; case 0x060B6E24u: goto L_060B6E24; case 0x060B6E26u: goto L_060B6E26; case 0x060B6E28u: goto L_060B6E28; case 0x060B6E2Au: goto L_060B6E2A; case 0x060B6E2Cu: goto L_060B6E2C; case 0x060B6E2Eu: goto L_060B6E2E; case 0x060B6E30u: goto L_060B6E30; case 0x060B6E32u: goto L_060B6E32; case 0x060B6E34u: goto L_060B6E34; case 0x060B6E36u: goto L_060B6E36; case 0x060B6E38u: goto L_060B6E38; case 0x060B6E3Au: goto L_060B6E3A; case 0x060B6E3Cu: goto L_060B6E3C; case 0x060B6E3Eu: goto L_060B6E3E; case 0x060B6E40u: goto L_060B6E40; case 0x060B6E42u: goto L_060B6E42; case 0x060B6E44u: goto L_060B6E44; case 0x060B6E46u: goto L_060B6E46; case 0x060B6E48u: goto L_060B6E48; case 0x060B6E4Au: goto L_060B6E4A; case 0x060B6E4Cu: goto L_060B6E4C; case 0x060B6E4Eu: goto L_060B6E4E; case 0x060B6E50u: goto L_060B6E50; case 0x060B6E52u: goto L_060B6E52; case 0x060B6E54u: goto L_060B6E54; case 0x060B6E56u: goto L_060B6E56; case 0x060B6E58u: goto L_060B6E58; case 0x060B6E5Au: goto L_060B6E5A; case 0x060B6E5Cu: goto L_060B6E5C; case 0x060B6E5Eu: goto L_060B6E5E; case 0x060B6E60u: goto L_060B6E60; case 0x060B6E62u: goto L_060B6E62; case 0x060B6E64u: goto L_060B6E64; case 0x060B6E66u: goto L_060B6E66; case 0x060B6E68u: goto L_060B6E68; case 0x060B6E6Au: goto L_060B6E6A; case 0x060B6E6Eu: goto L_060B6E6E; case 0x060B6E70u: goto L_060B6E70; case 0x060B6E72u: goto L_060B6E72; case 0x060B6E76u: goto L_060B6E76; case 0x060B6E78u: goto L_060B6E78; case 0x060B6E7Cu: goto L_060B6E7C; case 0x060B6E7Eu: goto L_060B6E7E; case 0x060B6E80u: goto L_060B6E80; case 0x060B6E82u: goto L_060B6E82; case 0x060B6E84u: goto L_060B6E84; case 0x060B6E86u: goto L_060B6E86; case 0x060B6E88u: goto L_060B6E88; case 0x060B6E8Au: goto L_060B6E8A; case 0x060B6E8Eu: goto L_060B6E8E; case 0x060B6EBCu: goto L_060B6EBC; case 0x060B6EBEu: goto L_060B6EBE; case 0x060B6EC0u: goto L_060B6EC0; case 0x060B6EC2u: goto L_060B6EC2; case 0x060B6EC6u: goto L_060B6EC6; case 0x060B6EC8u: goto L_060B6EC8; case 0x060B6ECAu: goto L_060B6ECA; case 0x060B6ECCu: goto L_060B6ECC; case 0x060B6ECEu: goto L_060B6ECE; case 0x060B6ED0u: goto L_060B6ED0; case 0x060B7098u: goto L_060B7098; case 0x060B709Au: goto L_060B709A; case 0x060B709Cu: goto L_060B709C; case 0x060B709Eu: goto L_060B709E; case 0x060B70A2u: goto L_060B70A2; case 0x060B70A4u: goto L_060B70A4; case 0x060B70A6u: goto L_060B70A6; case 0x060B70A8u: goto L_060B70A8; case 0x060B70AAu: goto L_060B70AA; case 0x060B70ACu: goto L_060B70AC; case 0x060B70AEu: goto L_060B70AE; case 0x060B70B0u: goto L_060B70B0; case 0x060B70B2u: goto L_060B70B2; case 0x060B70B6u: goto L_060B70B6; default: sh2_call(c, x); return; } }  // 060B70B2 jmp @r0 ; add r10,r4
L_060B70B6:
    c.r[7] += 4; SH2_POLL(c); goto L_060B6EBC;  // 060B70B6 bra 0x060B6EBC ; add #4,r7
}

void f_060B7944(SH2Context& c) {
    ran[3137] = 1;
L_060B7944:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[8] + 2);  // 060B7944 mov.w @(2,r8),r0
L_060B7946:
    c.r[5] = ld32(c.r[15] + 20);  // 060B7946 mov.l @(20,r15),r5
L_060B7948:
    c.r[0] <<= 2;  // 060B7948 shll2 r0
L_060B794A:
    c.r[0] += c.r[0];  // 060B794A add r0,r0
L_060B794C:
    c.r[0] = ld32(c.r[0] + c.r[5]);  // 060B794C mov.l @(r0,r5),r0
L_060B794E:
    st32(c.r[11] + 8, c.r[0]);  // 060B794E mov.l r0,@(8,r11)
L_060B7950:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[8] + 8);  // 060B7950 mov.w @(8,r8),r0
L_060B7952:
    c.r[5] = ld32(c.r[8] + 4);  // 060B7952 mov.l @(4,r8),r5
L_060B7954:
    st16(c.r[11] + 28, c.r[0]);  // 060B7954 mov.w r0,@(28,r11)
L_060B7956:
    st32(c.r[11] + 4, c.r[5]);  // 060B7956 mov.l r5,@(4,r11)
L_060B7958:
    c.r[5] >>= 16;  // 060B7958 shlr16 r5
L_060B795A:
    c.r[5] >>= 2;  // 060B795A shlr2 r5
L_060B795C:
    c.t = c.r[5] & 1; c.r[5] >>= 1;  // 060B795C shlr r5
L_060B795E:
    if (!c.t) { goto L_060B7966; }  // 060B795E bf 0x060B7966
L_060B7960:
    c.r[1] = ld32(c.r[1]);  // 060B7960 mov.l @(0,r1),r1
L_060B7962:
    c.r[5] = ld32(c.r[2]); goto L_060B7A08;  // 060B7962 bra 0x060B7A08 ; mov.l @(0,r2),r5
L_060B7966:
    c.r[0] = ld32(c.r[1] + 4);  // 060B7966 mov.l @(4,r1),r0
L_060B7968:
    c.r[1] = ld32(c.r[1]);  // 060B7968 mov.l @(0,r1),r1
L_060B796A:
    c.t = (c.r[0] & 0x1u) == 0;  // 060B796A tst #1,r0
L_060B796C:
    { const bool k = c.t; c.r[5] = ld32(c.r[2]); if (k) { goto L_060B7A08; } }  // 060B796C bt/s 0x060B7A08 ; mov.l @(0,r2),r5
L_060B7970:
    c.r[0] = ld32(c.r[2] + 4);  // 060B7970 mov.l @(4,r2),r0
L_060B7972:
    c.r[2] = c.r[5];  // 060B7972 mov r5,r2
L_060B7974:
    c.t = (c.r[0] & 0x1u) == 0;  // 060B7974 tst #1,r0
L_060B7976:
    { const bool k = c.t; c.r[5] = ld32(c.r[3]); if (k) { goto L_060B7A1E; } }  // 060B7976 bt/s 0x060B7A1E ; mov.l @(0,r3),r5
L_060B797A:
    c.r[0] = ld32(c.r[3] + 4);  // 060B797A mov.l @(4,r3),r0
L_060B797C:
    c.r[3] = c.r[5];  // 060B797C mov r5,r3
L_060B797E:
    c.t = (c.r[0] & 0x1u) == 0;  // 060B797E tst #1,r0
L_060B7980:
    { const bool k = c.t; c.r[5] = ld32(c.r[4]); if (k) { goto L_060B7A34; } }  // 060B7980 bt/s 0x060B7A34 ; mov.l @(0,r4),r5
L_060B7984:
    c.r[0] = ld32(c.r[4] + 4);  // 060B7984 mov.l @(4,r4),r0
L_060B7986:
    c.r[4] = c.r[5];  // 060B7986 mov r5,r4
L_060B7988:
    c.t = (c.r[0] & 0x1u) == 0;  // 060B7988 tst #1,r0
L_060B798A:
    { const bool k = c.t; c.r[5] = 0x1u; if (k) { goto L_060B7A4A; } }  // 060B798A bt/s 0x060B7A4A ; mov #1,r5
L_060B798E:
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060B798E mov.l r9,@-r15
L_060B7990:
    c.r[5] <<= 16;  // 060B7990 shll16 r5
L_060B7992:
    c.t = c.r[5] & 1; c.r[5] >>= 1;  // 060B7992 shlr r5
L_060B7994:
    c.r[9] = c.r[4] << 16 | c.r[4] >> 16;  // 060B7994 swap.w r4,r9
L_060B7996:
    c.t = (c.r[9] & c.r[5]) == 0;  // 060B7996 tst r5,r9
L_060B7998:
    { uint32_t a = c.r[13], b = c.r[13], t = c.t; c.r[13] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B7998 subc r13,r13
L_060B799A:
    c.r[13] = ~c.r[13];  // 060B799A not r13,r13
L_060B799C:
    c.r[13] ^= c.r[9];  // 060B799C xor r9,r13
L_060B799E:
    c.t = (c.r[4] & c.r[5]) == 0;  // 060B799E tst r5,r4
L_060B79A0:
    { uint32_t a = c.r[9], b = c.r[9], t = c.t; c.r[9] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B79A0 subc r9,r9
L_060B79A2:
    c.r[9] = ~c.r[9];  // 060B79A2 not r9,r9
L_060B79A4:
    c.r[9] ^= c.r[4];  // 060B79A4 xor r4,r9
L_060B79A6:
    c.r[13] += c.r[9];  // 060B79A6 add r9,r13
L_060B79A8:
    c.r[13] = c.r[13] & 0xFFFFu;  // 060B79A8 extu.w r13,r13
L_060B79AA:
    c.r[0] = 0x060B7A4Cu;  // 060B79AA mova 0x060B7A4C,r0
L_060B79AC:
    c.r[9] = c.r[3] << 16 | c.r[3] >> 16;  // 060B79AC swap.w r3,r9
L_060B79AE:
    c.t = (c.r[9] & c.r[5]) == 0;  // 060B79AE tst r5,r9
L_060B79B0:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B79B0 subc r12,r12
L_060B79B2:
    c.r[12] = ~c.r[12];  // 060B79B2 not r12,r12
L_060B79B4:
    c.r[12] ^= c.r[9];  // 060B79B4 xor r9,r12
L_060B79B6:
    c.t = (c.r[3] & c.r[5]) == 0;  // 060B79B6 tst r5,r3
L_060B79B8:
    { uint32_t a = c.r[9], b = c.r[9], t = c.t; c.r[9] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B79B8 subc r9,r9
L_060B79BA:
    c.r[9] = ~c.r[9];  // 060B79BA not r9,r9
L_060B79BC:
    c.r[9] ^= c.r[3];  // 060B79BC xor r3,r9
L_060B79BE:
    c.r[12] += c.r[9];  // 060B79BE add r9,r12
L_060B79C0:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B79C0 extu.w r12,r12
L_060B79C2:
    c.t = (int32_t)c.r[12] > (int32_t)c.r[13];  // 060B79C2 cmp/gt r13,r12
L_060B79C4:
    { const bool k = c.t; c.r[9] = c.r[2] << 16 | c.r[2] >> 16; if (k) { goto L_060B79CC; } }  // 060B79C4 bt/s 0x060B79CC ; swap.w r2,r9
L_060B79C8:
    c.r[13] = c.r[12];  // 060B79C8 mov r12,r13
L_060B79CA:
    c.r[0] = 0x060B7A38u;  // 060B79CA mova 0x060B7A38,r0
L_060B79CC:
    c.t = (c.r[9] & c.r[5]) == 0;  // 060B79CC tst r5,r9
L_060B79CE:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B79CE subc r12,r12
L_060B79D0:
    c.r[12] = ~c.r[12];  // 060B79D0 not r12,r12
L_060B79D2:
    c.r[12] ^= c.r[9];  // 060B79D2 xor r9,r12
L_060B79D4:
    c.t = (c.r[2] & c.r[5]) == 0;  // 060B79D4 tst r5,r2
L_060B79D6:
    { uint32_t a = c.r[9], b = c.r[9], t = c.t; c.r[9] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B79D6 subc r9,r9
L_060B79D8:
    c.r[9] = ~c.r[9];  // 060B79D8 not r9,r9
L_060B79DA:
    c.r[9] ^= c.r[2];  // 060B79DA xor r2,r9
L_060B79DC:
    c.r[12] += c.r[9];  // 060B79DC add r9,r12
L_060B79DE:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B79DE extu.w r12,r12
L_060B79E0:
    c.t = (int32_t)c.r[12] > (int32_t)c.r[13];  // 060B79E0 cmp/gt r13,r12
L_060B79E2:
    { const bool k = c.t; c.r[9] = c.r[1] << 16 | c.r[1] >> 16; if (k) { goto L_060B79EA; } }  // 060B79E2 bt/s 0x060B79EA ; swap.w r1,r9
L_060B79E6:
    c.r[13] = c.r[12];  // 060B79E6 mov r12,r13
L_060B79E8:
    c.r[0] = 0x060B7A24u;  // 060B79E8 mova 0x060B7A24,r0
L_060B79EA:
    c.t = (c.r[9] & c.r[5]) == 0;  // 060B79EA tst r5,r9
L_060B79EC:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B79EC subc r12,r12
L_060B79EE:
    c.r[12] = ~c.r[12];  // 060B79EE not r12,r12
L_060B79F0:
    c.r[12] ^= c.r[9];  // 060B79F0 xor r9,r12
L_060B79F2:
    c.t = (c.r[1] & c.r[5]) == 0;  // 060B79F2 tst r5,r1
L_060B79F4:
    { uint32_t a = c.r[9], b = c.r[9], t = c.t; c.r[9] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B79F4 subc r9,r9
L_060B79F6:
    c.r[9] = ~c.r[9];  // 060B79F6 not r9,r9
L_060B79F8:
    c.r[9] ^= c.r[1];  // 060B79F8 xor r1,r9
L_060B79FA:
    c.r[12] += c.r[9];  // 060B79FA add r9,r12
L_060B79FC:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B79FC extu.w r12,r12
L_060B79FE:
    c.t = (int32_t)c.r[13] >= (int32_t)c.r[12];  // 060B79FE cmp/ge r12,r13
L_060B7A00:
    { const bool k = c.t; c.r[9] = ld32(c.r[15]); c.r[15] += 4; if (k) { goto L_060B7A0E; } }  // 060B7A00 bt/s 0x060B7A0E ; mov.l @r15+,r9
L_060B7A04:
    { const uint32_t x = c.r[0]; c.r[5] = ld32(c.r[9]); c.r[9] += 4; SH2_POLL(c); switch (x) { case 0x060B7944u: goto L_060B7944; case 0x060B7946u: goto L_060B7946; case 0x060B7948u: goto L_060B7948; case 0x060B794Au: goto L_060B794A; case 0x060B794Cu: goto L_060B794C; case 0x060B794Eu: goto L_060B794E; case 0x060B7950u: goto L_060B7950; case 0x060B7952u: goto L_060B7952; case 0x060B7954u: goto L_060B7954; case 0x060B7956u: goto L_060B7956; case 0x060B7958u: goto L_060B7958; case 0x060B795Au: goto L_060B795A; case 0x060B795Cu: goto L_060B795C; case 0x060B795Eu: goto L_060B795E; case 0x060B7960u: goto L_060B7960; case 0x060B7962u: goto L_060B7962; case 0x060B7966u: goto L_060B7966; case 0x060B7968u: goto L_060B7968; case 0x060B796Au: goto L_060B796A; case 0x060B796Cu: goto L_060B796C; case 0x060B7970u: goto L_060B7970; case 0x060B7972u: goto L_060B7972; case 0x060B7974u: goto L_060B7974; case 0x060B7976u: goto L_060B7976; case 0x060B797Au: goto L_060B797A; case 0x060B797Cu: goto L_060B797C; case 0x060B797Eu: goto L_060B797E; case 0x060B7980u: goto L_060B7980; case 0x060B7984u: goto L_060B7984; case 0x060B7986u: goto L_060B7986; case 0x060B7988u: goto L_060B7988; case 0x060B798Au: goto L_060B798A; case 0x060B798Eu: goto L_060B798E; case 0x060B7990u: goto L_060B7990; case 0x060B7992u: goto L_060B7992; case 0x060B7994u: goto L_060B7994; case 0x060B7996u: goto L_060B7996; case 0x060B7998u: goto L_060B7998; case 0x060B799Au: goto L_060B799A; case 0x060B799Cu: goto L_060B799C; case 0x060B799Eu: goto L_060B799E; case 0x060B79A0u: goto L_060B79A0; case 0x060B79A2u: goto L_060B79A2; case 0x060B79A4u: goto L_060B79A4; case 0x060B79A6u: goto L_060B79A6; case 0x060B79A8u: goto L_060B79A8; case 0x060B79AAu: goto L_060B79AA; case 0x060B79ACu: goto L_060B79AC; case 0x060B79AEu: goto L_060B79AE; case 0x060B79B0u: goto L_060B79B0; case 0x060B79B2u: goto L_060B79B2; case 0x060B79B4u: goto L_060B79B4; case 0x060B79B6u: goto L_060B79B6; case 0x060B79B8u: goto L_060B79B8; case 0x060B79BAu: goto L_060B79BA; case 0x060B79BCu: goto L_060B79BC; case 0x060B79BEu: goto L_060B79BE; case 0x060B79C0u: goto L_060B79C0; case 0x060B79C2u: goto L_060B79C2; case 0x060B79C4u: goto L_060B79C4; case 0x060B79C8u: goto L_060B79C8; case 0x060B79CAu: goto L_060B79CA; case 0x060B79CCu: goto L_060B79CC; case 0x060B79CEu: goto L_060B79CE; case 0x060B79D0u: goto L_060B79D0; case 0x060B79D2u: goto L_060B79D2; case 0x060B79D4u: goto L_060B79D4; case 0x060B79D6u: goto L_060B79D6; case 0x060B79D8u: goto L_060B79D8; case 0x060B79DAu: goto L_060B79DA; case 0x060B79DCu: goto L_060B79DC; case 0x060B79DEu: goto L_060B79DE; case 0x060B79E0u: goto L_060B79E0; case 0x060B79E2u: goto L_060B79E2; case 0x060B79E6u: goto L_060B79E6; case 0x060B79E8u: goto L_060B79E8; case 0x060B79EAu: goto L_060B79EA; case 0x060B79ECu: goto L_060B79EC; case 0x060B79EEu: goto L_060B79EE; case 0x060B79F0u: goto L_060B79F0; case 0x060B79F2u: goto L_060B79F2; case 0x060B79F4u: goto L_060B79F4; case 0x060B79F6u: goto L_060B79F6; case 0x060B79F8u: goto L_060B79F8; case 0x060B79FAu: goto L_060B79FA; case 0x060B79FCu: goto L_060B79FC; case 0x060B79FEu: goto L_060B79FE; case 0x060B7A00u: goto L_060B7A00; case 0x060B7A04u: goto L_060B7A04; case 0x060B7A08u: goto L_060B7A08; case 0x060B7A0Au: goto L_060B7A0A; case 0x060B7A0Cu: goto L_060B7A0C; case 0x060B7A0Eu: goto L_060B7A0E; case 0x060B7A10u: goto L_060B7A10; case 0x060B7A12u: goto L_060B7A12; case 0x060B7A14u: goto L_060B7A14; case 0x060B7A16u: goto L_060B7A16; case 0x060B7A1Eu: goto L_060B7A1E; case 0x060B7A20u: goto L_060B7A20; case 0x060B7A22u: goto L_060B7A22; case 0x060B7A24u: goto L_060B7A24; case 0x060B7A26u: goto L_060B7A26; case 0x060B7A28u: goto L_060B7A28; case 0x060B7A2Au: goto L_060B7A2A; case 0x060B7A2Cu: goto L_060B7A2C; case 0x060B7A2Eu: goto L_060B7A2E; case 0x060B7A30u: goto L_060B7A30; case 0x060B7A34u: goto L_060B7A34; case 0x060B7A36u: goto L_060B7A36; case 0x060B7A38u: goto L_060B7A38; case 0x060B7A3Au: goto L_060B7A3A; case 0x060B7A3Cu: goto L_060B7A3C; case 0x060B7A3Eu: goto L_060B7A3E; case 0x060B7A40u: goto L_060B7A40; case 0x060B7A42u: goto L_060B7A42; case 0x060B7A44u: goto L_060B7A44; case 0x060B7A4Au: goto L_060B7A4A; case 0x060B7A4Cu: goto L_060B7A4C; case 0x060B7A4Eu: goto L_060B7A4E; case 0x060B7A50u: goto L_060B7A50; case 0x060B7A52u: goto L_060B7A52; case 0x060B7A54u: goto L_060B7A54; case 0x060B7A56u: goto L_060B7A56; case 0x060B7A58u: goto L_060B7A58; default: sh2_call(c, x); return; } }  // 060B7A04 jmp @r0 ; mov.l @r9+,r5
L_060B7A08:
    c.r[3] = ld32(c.r[3]);  // 060B7A08 mov.l @(0,r3),r3
L_060B7A0A:
    c.r[2] = c.r[5];  // 060B7A0A mov r5,r2
L_060B7A0C:
    c.r[4] = ld32(c.r[4]);  // 060B7A0C mov.l @(0,r4),r4
L_060B7A0E:
    c.r[5] = ld32(c.r[9]); c.r[9] += 4;  // 060B7A0E mov.l @r9+,r5
L_060B7A10:
    st32(c.r[11] + 12, c.r[1]);  // 060B7A10 mov.l r1,@(12,r11)
L_060B7A12:
    st32(c.r[11] + 16, c.r[2]);  // 060B7A12 mov.l r2,@(16,r11)
L_060B7A14:
    st32(c.r[11] + 20, c.r[3]);  // 060B7A14 mov.l r3,@(20,r11)
L_060B7A16:
    { const uint32_t x = c.r[5]; st32(c.r[11] + 24, c.r[4]); SH2_POLL(c); switch (x) { case 0x060B7944u: goto L_060B7944; case 0x060B7946u: goto L_060B7946; case 0x060B7948u: goto L_060B7948; case 0x060B794Au: goto L_060B794A; case 0x060B794Cu: goto L_060B794C; case 0x060B794Eu: goto L_060B794E; case 0x060B7950u: goto L_060B7950; case 0x060B7952u: goto L_060B7952; case 0x060B7954u: goto L_060B7954; case 0x060B7956u: goto L_060B7956; case 0x060B7958u: goto L_060B7958; case 0x060B795Au: goto L_060B795A; case 0x060B795Cu: goto L_060B795C; case 0x060B795Eu: goto L_060B795E; case 0x060B7960u: goto L_060B7960; case 0x060B7962u: goto L_060B7962; case 0x060B7966u: goto L_060B7966; case 0x060B7968u: goto L_060B7968; case 0x060B796Au: goto L_060B796A; case 0x060B796Cu: goto L_060B796C; case 0x060B7970u: goto L_060B7970; case 0x060B7972u: goto L_060B7972; case 0x060B7974u: goto L_060B7974; case 0x060B7976u: goto L_060B7976; case 0x060B797Au: goto L_060B797A; case 0x060B797Cu: goto L_060B797C; case 0x060B797Eu: goto L_060B797E; case 0x060B7980u: goto L_060B7980; case 0x060B7984u: goto L_060B7984; case 0x060B7986u: goto L_060B7986; case 0x060B7988u: goto L_060B7988; case 0x060B798Au: goto L_060B798A; case 0x060B798Eu: goto L_060B798E; case 0x060B7990u: goto L_060B7990; case 0x060B7992u: goto L_060B7992; case 0x060B7994u: goto L_060B7994; case 0x060B7996u: goto L_060B7996; case 0x060B7998u: goto L_060B7998; case 0x060B799Au: goto L_060B799A; case 0x060B799Cu: goto L_060B799C; case 0x060B799Eu: goto L_060B799E; case 0x060B79A0u: goto L_060B79A0; case 0x060B79A2u: goto L_060B79A2; case 0x060B79A4u: goto L_060B79A4; case 0x060B79A6u: goto L_060B79A6; case 0x060B79A8u: goto L_060B79A8; case 0x060B79AAu: goto L_060B79AA; case 0x060B79ACu: goto L_060B79AC; case 0x060B79AEu: goto L_060B79AE; case 0x060B79B0u: goto L_060B79B0; case 0x060B79B2u: goto L_060B79B2; case 0x060B79B4u: goto L_060B79B4; case 0x060B79B6u: goto L_060B79B6; case 0x060B79B8u: goto L_060B79B8; case 0x060B79BAu: goto L_060B79BA; case 0x060B79BCu: goto L_060B79BC; case 0x060B79BEu: goto L_060B79BE; case 0x060B79C0u: goto L_060B79C0; case 0x060B79C2u: goto L_060B79C2; case 0x060B79C4u: goto L_060B79C4; case 0x060B79C8u: goto L_060B79C8; case 0x060B79CAu: goto L_060B79CA; case 0x060B79CCu: goto L_060B79CC; case 0x060B79CEu: goto L_060B79CE; case 0x060B79D0u: goto L_060B79D0; case 0x060B79D2u: goto L_060B79D2; case 0x060B79D4u: goto L_060B79D4; case 0x060B79D6u: goto L_060B79D6; case 0x060B79D8u: goto L_060B79D8; case 0x060B79DAu: goto L_060B79DA; case 0x060B79DCu: goto L_060B79DC; case 0x060B79DEu: goto L_060B79DE; case 0x060B79E0u: goto L_060B79E0; case 0x060B79E2u: goto L_060B79E2; case 0x060B79E6u: goto L_060B79E6; case 0x060B79E8u: goto L_060B79E8; case 0x060B79EAu: goto L_060B79EA; case 0x060B79ECu: goto L_060B79EC; case 0x060B79EEu: goto L_060B79EE; case 0x060B79F0u: goto L_060B79F0; case 0x060B79F2u: goto L_060B79F2; case 0x060B79F4u: goto L_060B79F4; case 0x060B79F6u: goto L_060B79F6; case 0x060B79F8u: goto L_060B79F8; case 0x060B79FAu: goto L_060B79FA; case 0x060B79FCu: goto L_060B79FC; case 0x060B79FEu: goto L_060B79FE; case 0x060B7A00u: goto L_060B7A00; case 0x060B7A04u: goto L_060B7A04; case 0x060B7A08u: goto L_060B7A08; case 0x060B7A0Au: goto L_060B7A0A; case 0x060B7A0Cu: goto L_060B7A0C; case 0x060B7A0Eu: goto L_060B7A0E; case 0x060B7A10u: goto L_060B7A10; case 0x060B7A12u: goto L_060B7A12; case 0x060B7A14u: goto L_060B7A14; case 0x060B7A16u: goto L_060B7A16; case 0x060B7A1Eu: goto L_060B7A1E; case 0x060B7A20u: goto L_060B7A20; case 0x060B7A22u: goto L_060B7A22; case 0x060B7A24u: goto L_060B7A24; case 0x060B7A26u: goto L_060B7A26; case 0x060B7A28u: goto L_060B7A28; case 0x060B7A2Au: goto L_060B7A2A; case 0x060B7A2Cu: goto L_060B7A2C; case 0x060B7A2Eu: goto L_060B7A2E; case 0x060B7A30u: goto L_060B7A30; case 0x060B7A34u: goto L_060B7A34; case 0x060B7A36u: goto L_060B7A36; case 0x060B7A38u: goto L_060B7A38; case 0x060B7A3Au: goto L_060B7A3A; case 0x060B7A3Cu: goto L_060B7A3C; case 0x060B7A3Eu: goto L_060B7A3E; case 0x060B7A40u: goto L_060B7A40; case 0x060B7A42u: goto L_060B7A42; case 0x060B7A44u: goto L_060B7A44; case 0x060B7A4Au: goto L_060B7A4A; case 0x060B7A4Cu: goto L_060B7A4C; case 0x060B7A4Eu: goto L_060B7A4E; case 0x060B7A50u: goto L_060B7A50; case 0x060B7A52u: goto L_060B7A52; case 0x060B7A54u: goto L_060B7A54; case 0x060B7A56u: goto L_060B7A56; case 0x060B7A58u: goto L_060B7A58; default: sh2_call(c, x); return; } }  // 060B7A16 jmp @r5 ; mov.l r4,@(24,r11)
L_060B7A1E:
    c.r[4] = ld32(c.r[4]);  // 060B7A1E mov.l @(0,r4),r4
L_060B7A20:
    c.r[3] = c.r[5];  // 060B7A20 mov r5,r3
L_060B7A22:
    c.r[5] = ld32(c.r[9]); c.r[9] += 4;  // 060B7A22 mov.l @r9+,r5
L_060B7A24:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[11]);  // 060B7A24 mov.w @(0,r11),r0
L_060B7A26:
    st32(c.r[11] + 16, c.r[1]);  // 060B7A26 mov.l r1,@(16,r11)
L_060B7A28:
    c.r[0] ^= 0x10u;  // 060B7A28 xor #16,r0
L_060B7A2A:
    st16(c.r[11], c.r[0]);  // 060B7A2A mov.w r0,@(0,r11)
L_060B7A2C:
    st32(c.r[11] + 12, c.r[2]);  // 060B7A2C mov.l r2,@(12,r11)
L_060B7A2E:
    st32(c.r[11] + 24, c.r[3]);  // 060B7A2E mov.l r3,@(24,r11)
L_060B7A30:
    { const uint32_t x = c.r[5]; st32(c.r[11] + 20, c.r[4]); SH2_POLL(c); switch (x) { case 0x060B7944u: goto L_060B7944; case 0x060B7946u: goto L_060B7946; case 0x060B7948u: goto L_060B7948; case 0x060B794Au: goto L_060B794A; case 0x060B794Cu: goto L_060B794C; case 0x060B794Eu: goto L_060B794E; case 0x060B7950u: goto L_060B7950; case 0x060B7952u: goto L_060B7952; case 0x060B7954u: goto L_060B7954; case 0x060B7956u: goto L_060B7956; case 0x060B7958u: goto L_060B7958; case 0x060B795Au: goto L_060B795A; case 0x060B795Cu: goto L_060B795C; case 0x060B795Eu: goto L_060B795E; case 0x060B7960u: goto L_060B7960; case 0x060B7962u: goto L_060B7962; case 0x060B7966u: goto L_060B7966; case 0x060B7968u: goto L_060B7968; case 0x060B796Au: goto L_060B796A; case 0x060B796Cu: goto L_060B796C; case 0x060B7970u: goto L_060B7970; case 0x060B7972u: goto L_060B7972; case 0x060B7974u: goto L_060B7974; case 0x060B7976u: goto L_060B7976; case 0x060B797Au: goto L_060B797A; case 0x060B797Cu: goto L_060B797C; case 0x060B797Eu: goto L_060B797E; case 0x060B7980u: goto L_060B7980; case 0x060B7984u: goto L_060B7984; case 0x060B7986u: goto L_060B7986; case 0x060B7988u: goto L_060B7988; case 0x060B798Au: goto L_060B798A; case 0x060B798Eu: goto L_060B798E; case 0x060B7990u: goto L_060B7990; case 0x060B7992u: goto L_060B7992; case 0x060B7994u: goto L_060B7994; case 0x060B7996u: goto L_060B7996; case 0x060B7998u: goto L_060B7998; case 0x060B799Au: goto L_060B799A; case 0x060B799Cu: goto L_060B799C; case 0x060B799Eu: goto L_060B799E; case 0x060B79A0u: goto L_060B79A0; case 0x060B79A2u: goto L_060B79A2; case 0x060B79A4u: goto L_060B79A4; case 0x060B79A6u: goto L_060B79A6; case 0x060B79A8u: goto L_060B79A8; case 0x060B79AAu: goto L_060B79AA; case 0x060B79ACu: goto L_060B79AC; case 0x060B79AEu: goto L_060B79AE; case 0x060B79B0u: goto L_060B79B0; case 0x060B79B2u: goto L_060B79B2; case 0x060B79B4u: goto L_060B79B4; case 0x060B79B6u: goto L_060B79B6; case 0x060B79B8u: goto L_060B79B8; case 0x060B79BAu: goto L_060B79BA; case 0x060B79BCu: goto L_060B79BC; case 0x060B79BEu: goto L_060B79BE; case 0x060B79C0u: goto L_060B79C0; case 0x060B79C2u: goto L_060B79C2; case 0x060B79C4u: goto L_060B79C4; case 0x060B79C8u: goto L_060B79C8; case 0x060B79CAu: goto L_060B79CA; case 0x060B79CCu: goto L_060B79CC; case 0x060B79CEu: goto L_060B79CE; case 0x060B79D0u: goto L_060B79D0; case 0x060B79D2u: goto L_060B79D2; case 0x060B79D4u: goto L_060B79D4; case 0x060B79D6u: goto L_060B79D6; case 0x060B79D8u: goto L_060B79D8; case 0x060B79DAu: goto L_060B79DA; case 0x060B79DCu: goto L_060B79DC; case 0x060B79DEu: goto L_060B79DE; case 0x060B79E0u: goto L_060B79E0; case 0x060B79E2u: goto L_060B79E2; case 0x060B79E6u: goto L_060B79E6; case 0x060B79E8u: goto L_060B79E8; case 0x060B79EAu: goto L_060B79EA; case 0x060B79ECu: goto L_060B79EC; case 0x060B79EEu: goto L_060B79EE; case 0x060B79F0u: goto L_060B79F0; case 0x060B79F2u: goto L_060B79F2; case 0x060B79F4u: goto L_060B79F4; case 0x060B79F6u: goto L_060B79F6; case 0x060B79F8u: goto L_060B79F8; case 0x060B79FAu: goto L_060B79FA; case 0x060B79FCu: goto L_060B79FC; case 0x060B79FEu: goto L_060B79FE; case 0x060B7A00u: goto L_060B7A00; case 0x060B7A04u: goto L_060B7A04; case 0x060B7A08u: goto L_060B7A08; case 0x060B7A0Au: goto L_060B7A0A; case 0x060B7A0Cu: goto L_060B7A0C; case 0x060B7A0Eu: goto L_060B7A0E; case 0x060B7A10u: goto L_060B7A10; case 0x060B7A12u: goto L_060B7A12; case 0x060B7A14u: goto L_060B7A14; case 0x060B7A16u: goto L_060B7A16; case 0x060B7A1Eu: goto L_060B7A1E; case 0x060B7A20u: goto L_060B7A20; case 0x060B7A22u: goto L_060B7A22; case 0x060B7A24u: goto L_060B7A24; case 0x060B7A26u: goto L_060B7A26; case 0x060B7A28u: goto L_060B7A28; case 0x060B7A2Au: goto L_060B7A2A; case 0x060B7A2Cu: goto L_060B7A2C; case 0x060B7A2Eu: goto L_060B7A2E; case 0x060B7A30u: goto L_060B7A30; case 0x060B7A34u: goto L_060B7A34; case 0x060B7A36u: goto L_060B7A36; case 0x060B7A38u: goto L_060B7A38; case 0x060B7A3Au: goto L_060B7A3A; case 0x060B7A3Cu: goto L_060B7A3C; case 0x060B7A3Eu: goto L_060B7A3E; case 0x060B7A40u: goto L_060B7A40; case 0x060B7A42u: goto L_060B7A42; case 0x060B7A44u: goto L_060B7A44; case 0x060B7A4Au: goto L_060B7A4A; case 0x060B7A4Cu: goto L_060B7A4C; case 0x060B7A4Eu: goto L_060B7A4E; case 0x060B7A50u: goto L_060B7A50; case 0x060B7A52u: goto L_060B7A52; case 0x060B7A54u: goto L_060B7A54; case 0x060B7A56u: goto L_060B7A56; case 0x060B7A58u: goto L_060B7A58; default: sh2_call(c, x); return; } }  // 060B7A30 jmp @r5 ; mov.l r4,@(20,r11)
L_060B7A34:
    c.r[4] = c.r[5];  // 060B7A34 mov r5,r4
L_060B7A36:
    c.r[5] = ld32(c.r[9]); c.r[9] += 4;  // 060B7A36 mov.l @r9+,r5
L_060B7A38:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[11]);  // 060B7A38 mov.w @(0,r11),r0
L_060B7A3A:
    st32(c.r[11] + 20, c.r[1]);  // 060B7A3A mov.l r1,@(20,r11)
L_060B7A3C:
    c.r[0] ^= 0x30u;  // 060B7A3C xor #48,r0
L_060B7A3E:
    st16(c.r[11], c.r[0]);  // 060B7A3E mov.w r0,@(0,r11)
L_060B7A40:
    st32(c.r[11] + 24, c.r[2]);  // 060B7A40 mov.l r2,@(24,r11)
L_060B7A42:
    st32(c.r[11] + 12, c.r[3]);  // 060B7A42 mov.l r3,@(12,r11)
L_060B7A44:
    { const uint32_t x = c.r[5]; st32(c.r[11] + 16, c.r[4]); SH2_POLL(c); switch (x) { case 0x060B7944u: goto L_060B7944; case 0x060B7946u: goto L_060B7946; case 0x060B7948u: goto L_060B7948; case 0x060B794Au: goto L_060B794A; case 0x060B794Cu: goto L_060B794C; case 0x060B794Eu: goto L_060B794E; case 0x060B7950u: goto L_060B7950; case 0x060B7952u: goto L_060B7952; case 0x060B7954u: goto L_060B7954; case 0x060B7956u: goto L_060B7956; case 0x060B7958u: goto L_060B7958; case 0x060B795Au: goto L_060B795A; case 0x060B795Cu: goto L_060B795C; case 0x060B795Eu: goto L_060B795E; case 0x060B7960u: goto L_060B7960; case 0x060B7962u: goto L_060B7962; case 0x060B7966u: goto L_060B7966; case 0x060B7968u: goto L_060B7968; case 0x060B796Au: goto L_060B796A; case 0x060B796Cu: goto L_060B796C; case 0x060B7970u: goto L_060B7970; case 0x060B7972u: goto L_060B7972; case 0x060B7974u: goto L_060B7974; case 0x060B7976u: goto L_060B7976; case 0x060B797Au: goto L_060B797A; case 0x060B797Cu: goto L_060B797C; case 0x060B797Eu: goto L_060B797E; case 0x060B7980u: goto L_060B7980; case 0x060B7984u: goto L_060B7984; case 0x060B7986u: goto L_060B7986; case 0x060B7988u: goto L_060B7988; case 0x060B798Au: goto L_060B798A; case 0x060B798Eu: goto L_060B798E; case 0x060B7990u: goto L_060B7990; case 0x060B7992u: goto L_060B7992; case 0x060B7994u: goto L_060B7994; case 0x060B7996u: goto L_060B7996; case 0x060B7998u: goto L_060B7998; case 0x060B799Au: goto L_060B799A; case 0x060B799Cu: goto L_060B799C; case 0x060B799Eu: goto L_060B799E; case 0x060B79A0u: goto L_060B79A0; case 0x060B79A2u: goto L_060B79A2; case 0x060B79A4u: goto L_060B79A4; case 0x060B79A6u: goto L_060B79A6; case 0x060B79A8u: goto L_060B79A8; case 0x060B79AAu: goto L_060B79AA; case 0x060B79ACu: goto L_060B79AC; case 0x060B79AEu: goto L_060B79AE; case 0x060B79B0u: goto L_060B79B0; case 0x060B79B2u: goto L_060B79B2; case 0x060B79B4u: goto L_060B79B4; case 0x060B79B6u: goto L_060B79B6; case 0x060B79B8u: goto L_060B79B8; case 0x060B79BAu: goto L_060B79BA; case 0x060B79BCu: goto L_060B79BC; case 0x060B79BEu: goto L_060B79BE; case 0x060B79C0u: goto L_060B79C0; case 0x060B79C2u: goto L_060B79C2; case 0x060B79C4u: goto L_060B79C4; case 0x060B79C8u: goto L_060B79C8; case 0x060B79CAu: goto L_060B79CA; case 0x060B79CCu: goto L_060B79CC; case 0x060B79CEu: goto L_060B79CE; case 0x060B79D0u: goto L_060B79D0; case 0x060B79D2u: goto L_060B79D2; case 0x060B79D4u: goto L_060B79D4; case 0x060B79D6u: goto L_060B79D6; case 0x060B79D8u: goto L_060B79D8; case 0x060B79DAu: goto L_060B79DA; case 0x060B79DCu: goto L_060B79DC; case 0x060B79DEu: goto L_060B79DE; case 0x060B79E0u: goto L_060B79E0; case 0x060B79E2u: goto L_060B79E2; case 0x060B79E6u: goto L_060B79E6; case 0x060B79E8u: goto L_060B79E8; case 0x060B79EAu: goto L_060B79EA; case 0x060B79ECu: goto L_060B79EC; case 0x060B79EEu: goto L_060B79EE; case 0x060B79F0u: goto L_060B79F0; case 0x060B79F2u: goto L_060B79F2; case 0x060B79F4u: goto L_060B79F4; case 0x060B79F6u: goto L_060B79F6; case 0x060B79F8u: goto L_060B79F8; case 0x060B79FAu: goto L_060B79FA; case 0x060B79FCu: goto L_060B79FC; case 0x060B79FEu: goto L_060B79FE; case 0x060B7A00u: goto L_060B7A00; case 0x060B7A04u: goto L_060B7A04; case 0x060B7A08u: goto L_060B7A08; case 0x060B7A0Au: goto L_060B7A0A; case 0x060B7A0Cu: goto L_060B7A0C; case 0x060B7A0Eu: goto L_060B7A0E; case 0x060B7A10u: goto L_060B7A10; case 0x060B7A12u: goto L_060B7A12; case 0x060B7A14u: goto L_060B7A14; case 0x060B7A16u: goto L_060B7A16; case 0x060B7A1Eu: goto L_060B7A1E; case 0x060B7A20u: goto L_060B7A20; case 0x060B7A22u: goto L_060B7A22; case 0x060B7A24u: goto L_060B7A24; case 0x060B7A26u: goto L_060B7A26; case 0x060B7A28u: goto L_060B7A28; case 0x060B7A2Au: goto L_060B7A2A; case 0x060B7A2Cu: goto L_060B7A2C; case 0x060B7A2Eu: goto L_060B7A2E; case 0x060B7A30u: goto L_060B7A30; case 0x060B7A34u: goto L_060B7A34; case 0x060B7A36u: goto L_060B7A36; case 0x060B7A38u: goto L_060B7A38; case 0x060B7A3Au: goto L_060B7A3A; case 0x060B7A3Cu: goto L_060B7A3C; case 0x060B7A3Eu: goto L_060B7A3E; case 0x060B7A40u: goto L_060B7A40; case 0x060B7A42u: goto L_060B7A42; case 0x060B7A44u: goto L_060B7A44; case 0x060B7A4Au: goto L_060B7A4A; case 0x060B7A4Cu: goto L_060B7A4C; case 0x060B7A4Eu: goto L_060B7A4E; case 0x060B7A50u: goto L_060B7A50; case 0x060B7A52u: goto L_060B7A52; case 0x060B7A54u: goto L_060B7A54; case 0x060B7A56u: goto L_060B7A56; case 0x060B7A58u: goto L_060B7A58; default: sh2_call(c, x); return; } }  // 060B7A44 jmp @r5 ; mov.l r4,@(16,r11)
L_060B7A4A:
    c.r[5] = ld32(c.r[9]); c.r[9] += 4;  // 060B7A4A mov.l @r9+,r5
L_060B7A4C:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[11]);  // 060B7A4C mov.w @(0,r11),r0
L_060B7A4E:
    st32(c.r[11] + 24, c.r[1]);  // 060B7A4E mov.l r1,@(24,r11)
L_060B7A50:
    c.r[0] ^= 0x20u;  // 060B7A50 xor #32,r0
L_060B7A52:
    st16(c.r[11], c.r[0]);  // 060B7A52 mov.w r0,@(0,r11)
L_060B7A54:
    st32(c.r[11] + 20, c.r[2]);  // 060B7A54 mov.l r2,@(20,r11)
L_060B7A56:
    st32(c.r[11] + 16, c.r[3]);  // 060B7A56 mov.l r3,@(16,r11)
L_060B7A58:
    { const uint32_t x = c.r[5]; st32(c.r[11] + 12, c.r[4]); SH2_POLL(c); switch (x) { case 0x060B7944u: goto L_060B7944; case 0x060B7946u: goto L_060B7946; case 0x060B7948u: goto L_060B7948; case 0x060B794Au: goto L_060B794A; case 0x060B794Cu: goto L_060B794C; case 0x060B794Eu: goto L_060B794E; case 0x060B7950u: goto L_060B7950; case 0x060B7952u: goto L_060B7952; case 0x060B7954u: goto L_060B7954; case 0x060B7956u: goto L_060B7956; case 0x060B7958u: goto L_060B7958; case 0x060B795Au: goto L_060B795A; case 0x060B795Cu: goto L_060B795C; case 0x060B795Eu: goto L_060B795E; case 0x060B7960u: goto L_060B7960; case 0x060B7962u: goto L_060B7962; case 0x060B7966u: goto L_060B7966; case 0x060B7968u: goto L_060B7968; case 0x060B796Au: goto L_060B796A; case 0x060B796Cu: goto L_060B796C; case 0x060B7970u: goto L_060B7970; case 0x060B7972u: goto L_060B7972; case 0x060B7974u: goto L_060B7974; case 0x060B7976u: goto L_060B7976; case 0x060B797Au: goto L_060B797A; case 0x060B797Cu: goto L_060B797C; case 0x060B797Eu: goto L_060B797E; case 0x060B7980u: goto L_060B7980; case 0x060B7984u: goto L_060B7984; case 0x060B7986u: goto L_060B7986; case 0x060B7988u: goto L_060B7988; case 0x060B798Au: goto L_060B798A; case 0x060B798Eu: goto L_060B798E; case 0x060B7990u: goto L_060B7990; case 0x060B7992u: goto L_060B7992; case 0x060B7994u: goto L_060B7994; case 0x060B7996u: goto L_060B7996; case 0x060B7998u: goto L_060B7998; case 0x060B799Au: goto L_060B799A; case 0x060B799Cu: goto L_060B799C; case 0x060B799Eu: goto L_060B799E; case 0x060B79A0u: goto L_060B79A0; case 0x060B79A2u: goto L_060B79A2; case 0x060B79A4u: goto L_060B79A4; case 0x060B79A6u: goto L_060B79A6; case 0x060B79A8u: goto L_060B79A8; case 0x060B79AAu: goto L_060B79AA; case 0x060B79ACu: goto L_060B79AC; case 0x060B79AEu: goto L_060B79AE; case 0x060B79B0u: goto L_060B79B0; case 0x060B79B2u: goto L_060B79B2; case 0x060B79B4u: goto L_060B79B4; case 0x060B79B6u: goto L_060B79B6; case 0x060B79B8u: goto L_060B79B8; case 0x060B79BAu: goto L_060B79BA; case 0x060B79BCu: goto L_060B79BC; case 0x060B79BEu: goto L_060B79BE; case 0x060B79C0u: goto L_060B79C0; case 0x060B79C2u: goto L_060B79C2; case 0x060B79C4u: goto L_060B79C4; case 0x060B79C8u: goto L_060B79C8; case 0x060B79CAu: goto L_060B79CA; case 0x060B79CCu: goto L_060B79CC; case 0x060B79CEu: goto L_060B79CE; case 0x060B79D0u: goto L_060B79D0; case 0x060B79D2u: goto L_060B79D2; case 0x060B79D4u: goto L_060B79D4; case 0x060B79D6u: goto L_060B79D6; case 0x060B79D8u: goto L_060B79D8; case 0x060B79DAu: goto L_060B79DA; case 0x060B79DCu: goto L_060B79DC; case 0x060B79DEu: goto L_060B79DE; case 0x060B79E0u: goto L_060B79E0; case 0x060B79E2u: goto L_060B79E2; case 0x060B79E6u: goto L_060B79E6; case 0x060B79E8u: goto L_060B79E8; case 0x060B79EAu: goto L_060B79EA; case 0x060B79ECu: goto L_060B79EC; case 0x060B79EEu: goto L_060B79EE; case 0x060B79F0u: goto L_060B79F0; case 0x060B79F2u: goto L_060B79F2; case 0x060B79F4u: goto L_060B79F4; case 0x060B79F6u: goto L_060B79F6; case 0x060B79F8u: goto L_060B79F8; case 0x060B79FAu: goto L_060B79FA; case 0x060B79FCu: goto L_060B79FC; case 0x060B79FEu: goto L_060B79FE; case 0x060B7A00u: goto L_060B7A00; case 0x060B7A04u: goto L_060B7A04; case 0x060B7A08u: goto L_060B7A08; case 0x060B7A0Au: goto L_060B7A0A; case 0x060B7A0Cu: goto L_060B7A0C; case 0x060B7A0Eu: goto L_060B7A0E; case 0x060B7A10u: goto L_060B7A10; case 0x060B7A12u: goto L_060B7A12; case 0x060B7A14u: goto L_060B7A14; case 0x060B7A16u: goto L_060B7A16; case 0x060B7A1Eu: goto L_060B7A1E; case 0x060B7A20u: goto L_060B7A20; case 0x060B7A22u: goto L_060B7A22; case 0x060B7A24u: goto L_060B7A24; case 0x060B7A26u: goto L_060B7A26; case 0x060B7A28u: goto L_060B7A28; case 0x060B7A2Au: goto L_060B7A2A; case 0x060B7A2Cu: goto L_060B7A2C; case 0x060B7A2Eu: goto L_060B7A2E; case 0x060B7A30u: goto L_060B7A30; case 0x060B7A34u: goto L_060B7A34; case 0x060B7A36u: goto L_060B7A36; case 0x060B7A38u: goto L_060B7A38; case 0x060B7A3Au: goto L_060B7A3A; case 0x060B7A3Cu: goto L_060B7A3C; case 0x060B7A3Eu: goto L_060B7A3E; case 0x060B7A40u: goto L_060B7A40; case 0x060B7A42u: goto L_060B7A42; case 0x060B7A44u: goto L_060B7A44; case 0x060B7A4Au: goto L_060B7A4A; case 0x060B7A4Cu: goto L_060B7A4C; case 0x060B7A4Eu: goto L_060B7A4E; case 0x060B7A50u: goto L_060B7A50; case 0x060B7A52u: goto L_060B7A52; case 0x060B7A54u: goto L_060B7A54; case 0x060B7A56u: goto L_060B7A56; case 0x060B7A58u: goto L_060B7A58; default: sh2_call(c, x); return; } }  // 060B7A58 jmp @r5 ; mov.l r4,@(12,r11)
}

void f_060B7950(SH2Context& c) {
    ran[3138] = 1;
L_060B7950:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[8] + 8);  // 060B7950 mov.w @(8,r8),r0
L_060B7952:
    c.r[5] = ld32(c.r[8] + 4);  // 060B7952 mov.l @(4,r8),r5
L_060B7954:
    st16(c.r[11] + 28, c.r[0]);  // 060B7954 mov.w r0,@(28,r11)
L_060B7956:
    st32(c.r[11] + 4, c.r[5]);  // 060B7956 mov.l r5,@(4,r11)
L_060B7958:
    c.r[5] >>= 16;  // 060B7958 shlr16 r5
L_060B795A:
    c.r[5] >>= 2;  // 060B795A shlr2 r5
L_060B795C:
    c.t = c.r[5] & 1; c.r[5] >>= 1;  // 060B795C shlr r5
L_060B795E:
    if (!c.t) { goto L_060B7966; }  // 060B795E bf 0x060B7966
L_060B7960:
    c.r[1] = ld32(c.r[1]);  // 060B7960 mov.l @(0,r1),r1
L_060B7962:
    c.r[5] = ld32(c.r[2]); goto L_060B7A08;  // 060B7962 bra 0x060B7A08 ; mov.l @(0,r2),r5
L_060B7966:
    c.r[0] = ld32(c.r[1] + 4);  // 060B7966 mov.l @(4,r1),r0
L_060B7968:
    c.r[1] = ld32(c.r[1]);  // 060B7968 mov.l @(0,r1),r1
L_060B796A:
    c.t = (c.r[0] & 0x1u) == 0;  // 060B796A tst #1,r0
L_060B796C:
    { const bool k = c.t; c.r[5] = ld32(c.r[2]); if (k) { goto L_060B7A08; } }  // 060B796C bt/s 0x060B7A08 ; mov.l @(0,r2),r5
L_060B7970:
    c.r[0] = ld32(c.r[2] + 4);  // 060B7970 mov.l @(4,r2),r0
L_060B7972:
    c.r[2] = c.r[5];  // 060B7972 mov r5,r2
L_060B7974:
    c.t = (c.r[0] & 0x1u) == 0;  // 060B7974 tst #1,r0
L_060B7976:
    { const bool k = c.t; c.r[5] = ld32(c.r[3]); if (k) { goto L_060B7A1E; } }  // 060B7976 bt/s 0x060B7A1E ; mov.l @(0,r3),r5
L_060B797A:
    c.r[0] = ld32(c.r[3] + 4);  // 060B797A mov.l @(4,r3),r0
L_060B797C:
    c.r[3] = c.r[5];  // 060B797C mov r5,r3
L_060B797E:
    c.t = (c.r[0] & 0x1u) == 0;  // 060B797E tst #1,r0
L_060B7980:
    { const bool k = c.t; c.r[5] = ld32(c.r[4]); if (k) { goto L_060B7A34; } }  // 060B7980 bt/s 0x060B7A34 ; mov.l @(0,r4),r5
L_060B7984:
    c.r[0] = ld32(c.r[4] + 4);  // 060B7984 mov.l @(4,r4),r0
L_060B7986:
    c.r[4] = c.r[5];  // 060B7986 mov r5,r4
L_060B7988:
    c.t = (c.r[0] & 0x1u) == 0;  // 060B7988 tst #1,r0
L_060B798A:
    { const bool k = c.t; c.r[5] = 0x1u; if (k) { goto L_060B7A4A; } }  // 060B798A bt/s 0x060B7A4A ; mov #1,r5
L_060B798E:
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060B798E mov.l r9,@-r15
L_060B7990:
    c.r[5] <<= 16;  // 060B7990 shll16 r5
L_060B7992:
    c.t = c.r[5] & 1; c.r[5] >>= 1;  // 060B7992 shlr r5
L_060B7994:
    c.r[9] = c.r[4] << 16 | c.r[4] >> 16;  // 060B7994 swap.w r4,r9
L_060B7996:
    c.t = (c.r[9] & c.r[5]) == 0;  // 060B7996 tst r5,r9
L_060B7998:
    { uint32_t a = c.r[13], b = c.r[13], t = c.t; c.r[13] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B7998 subc r13,r13
L_060B799A:
    c.r[13] = ~c.r[13];  // 060B799A not r13,r13
L_060B799C:
    c.r[13] ^= c.r[9];  // 060B799C xor r9,r13
L_060B799E:
    c.t = (c.r[4] & c.r[5]) == 0;  // 060B799E tst r5,r4
L_060B79A0:
    { uint32_t a = c.r[9], b = c.r[9], t = c.t; c.r[9] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B79A0 subc r9,r9
L_060B79A2:
    c.r[9] = ~c.r[9];  // 060B79A2 not r9,r9
L_060B79A4:
    c.r[9] ^= c.r[4];  // 060B79A4 xor r4,r9
L_060B79A6:
    c.r[13] += c.r[9];  // 060B79A6 add r9,r13
L_060B79A8:
    c.r[13] = c.r[13] & 0xFFFFu;  // 060B79A8 extu.w r13,r13
L_060B79AA:
    c.r[0] = 0x060B7A4Cu;  // 060B79AA mova 0x060B7A4C,r0
L_060B79AC:
    c.r[9] = c.r[3] << 16 | c.r[3] >> 16;  // 060B79AC swap.w r3,r9
L_060B79AE:
    c.t = (c.r[9] & c.r[5]) == 0;  // 060B79AE tst r5,r9
L_060B79B0:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B79B0 subc r12,r12
L_060B79B2:
    c.r[12] = ~c.r[12];  // 060B79B2 not r12,r12
L_060B79B4:
    c.r[12] ^= c.r[9];  // 060B79B4 xor r9,r12
L_060B79B6:
    c.t = (c.r[3] & c.r[5]) == 0;  // 060B79B6 tst r5,r3
L_060B79B8:
    { uint32_t a = c.r[9], b = c.r[9], t = c.t; c.r[9] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B79B8 subc r9,r9
L_060B79BA:
    c.r[9] = ~c.r[9];  // 060B79BA not r9,r9
L_060B79BC:
    c.r[9] ^= c.r[3];  // 060B79BC xor r3,r9
L_060B79BE:
    c.r[12] += c.r[9];  // 060B79BE add r9,r12
L_060B79C0:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B79C0 extu.w r12,r12
L_060B79C2:
    c.t = (int32_t)c.r[12] > (int32_t)c.r[13];  // 060B79C2 cmp/gt r13,r12
L_060B79C4:
    { const bool k = c.t; c.r[9] = c.r[2] << 16 | c.r[2] >> 16; if (k) { goto L_060B79CC; } }  // 060B79C4 bt/s 0x060B79CC ; swap.w r2,r9
L_060B79C8:
    c.r[13] = c.r[12];  // 060B79C8 mov r12,r13
L_060B79CA:
    c.r[0] = 0x060B7A38u;  // 060B79CA mova 0x060B7A38,r0
L_060B79CC:
    c.t = (c.r[9] & c.r[5]) == 0;  // 060B79CC tst r5,r9
L_060B79CE:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B79CE subc r12,r12
L_060B79D0:
    c.r[12] = ~c.r[12];  // 060B79D0 not r12,r12
L_060B79D2:
    c.r[12] ^= c.r[9];  // 060B79D2 xor r9,r12
L_060B79D4:
    c.t = (c.r[2] & c.r[5]) == 0;  // 060B79D4 tst r5,r2
L_060B79D6:
    { uint32_t a = c.r[9], b = c.r[9], t = c.t; c.r[9] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B79D6 subc r9,r9
L_060B79D8:
    c.r[9] = ~c.r[9];  // 060B79D8 not r9,r9
L_060B79DA:
    c.r[9] ^= c.r[2];  // 060B79DA xor r2,r9
L_060B79DC:
    c.r[12] += c.r[9];  // 060B79DC add r9,r12
L_060B79DE:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B79DE extu.w r12,r12
L_060B79E0:
    c.t = (int32_t)c.r[12] > (int32_t)c.r[13];  // 060B79E0 cmp/gt r13,r12
L_060B79E2:
    { const bool k = c.t; c.r[9] = c.r[1] << 16 | c.r[1] >> 16; if (k) { goto L_060B79EA; } }  // 060B79E2 bt/s 0x060B79EA ; swap.w r1,r9
L_060B79E6:
    c.r[13] = c.r[12];  // 060B79E6 mov r12,r13
L_060B79E8:
    c.r[0] = 0x060B7A24u;  // 060B79E8 mova 0x060B7A24,r0
L_060B79EA:
    c.t = (c.r[9] & c.r[5]) == 0;  // 060B79EA tst r5,r9
L_060B79EC:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B79EC subc r12,r12
L_060B79EE:
    c.r[12] = ~c.r[12];  // 060B79EE not r12,r12
L_060B79F0:
    c.r[12] ^= c.r[9];  // 060B79F0 xor r9,r12
L_060B79F2:
    c.t = (c.r[1] & c.r[5]) == 0;  // 060B79F2 tst r5,r1
L_060B79F4:
    { uint32_t a = c.r[9], b = c.r[9], t = c.t; c.r[9] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B79F4 subc r9,r9
L_060B79F6:
    c.r[9] = ~c.r[9];  // 060B79F6 not r9,r9
L_060B79F8:
    c.r[9] ^= c.r[1];  // 060B79F8 xor r1,r9
L_060B79FA:
    c.r[12] += c.r[9];  // 060B79FA add r9,r12
L_060B79FC:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B79FC extu.w r12,r12
L_060B79FE:
    c.t = (int32_t)c.r[13] >= (int32_t)c.r[12];  // 060B79FE cmp/ge r12,r13
L_060B7A00:
    { const bool k = c.t; c.r[9] = ld32(c.r[15]); c.r[15] += 4; if (k) { goto L_060B7A0E; } }  // 060B7A00 bt/s 0x060B7A0E ; mov.l @r15+,r9
L_060B7A04:
    { const uint32_t x = c.r[0]; c.r[5] = ld32(c.r[9]); c.r[9] += 4; SH2_POLL(c); switch (x) { case 0x060B7950u: goto L_060B7950; case 0x060B7952u: goto L_060B7952; case 0x060B7954u: goto L_060B7954; case 0x060B7956u: goto L_060B7956; case 0x060B7958u: goto L_060B7958; case 0x060B795Au: goto L_060B795A; case 0x060B795Cu: goto L_060B795C; case 0x060B795Eu: goto L_060B795E; case 0x060B7960u: goto L_060B7960; case 0x060B7962u: goto L_060B7962; case 0x060B7966u: goto L_060B7966; case 0x060B7968u: goto L_060B7968; case 0x060B796Au: goto L_060B796A; case 0x060B796Cu: goto L_060B796C; case 0x060B7970u: goto L_060B7970; case 0x060B7972u: goto L_060B7972; case 0x060B7974u: goto L_060B7974; case 0x060B7976u: goto L_060B7976; case 0x060B797Au: goto L_060B797A; case 0x060B797Cu: goto L_060B797C; case 0x060B797Eu: goto L_060B797E; case 0x060B7980u: goto L_060B7980; case 0x060B7984u: goto L_060B7984; case 0x060B7986u: goto L_060B7986; case 0x060B7988u: goto L_060B7988; case 0x060B798Au: goto L_060B798A; case 0x060B798Eu: goto L_060B798E; case 0x060B7990u: goto L_060B7990; case 0x060B7992u: goto L_060B7992; case 0x060B7994u: goto L_060B7994; case 0x060B7996u: goto L_060B7996; case 0x060B7998u: goto L_060B7998; case 0x060B799Au: goto L_060B799A; case 0x060B799Cu: goto L_060B799C; case 0x060B799Eu: goto L_060B799E; case 0x060B79A0u: goto L_060B79A0; case 0x060B79A2u: goto L_060B79A2; case 0x060B79A4u: goto L_060B79A4; case 0x060B79A6u: goto L_060B79A6; case 0x060B79A8u: goto L_060B79A8; case 0x060B79AAu: goto L_060B79AA; case 0x060B79ACu: goto L_060B79AC; case 0x060B79AEu: goto L_060B79AE; case 0x060B79B0u: goto L_060B79B0; case 0x060B79B2u: goto L_060B79B2; case 0x060B79B4u: goto L_060B79B4; case 0x060B79B6u: goto L_060B79B6; case 0x060B79B8u: goto L_060B79B8; case 0x060B79BAu: goto L_060B79BA; case 0x060B79BCu: goto L_060B79BC; case 0x060B79BEu: goto L_060B79BE; case 0x060B79C0u: goto L_060B79C0; case 0x060B79C2u: goto L_060B79C2; case 0x060B79C4u: goto L_060B79C4; case 0x060B79C8u: goto L_060B79C8; case 0x060B79CAu: goto L_060B79CA; case 0x060B79CCu: goto L_060B79CC; case 0x060B79CEu: goto L_060B79CE; case 0x060B79D0u: goto L_060B79D0; case 0x060B79D2u: goto L_060B79D2; case 0x060B79D4u: goto L_060B79D4; case 0x060B79D6u: goto L_060B79D6; case 0x060B79D8u: goto L_060B79D8; case 0x060B79DAu: goto L_060B79DA; case 0x060B79DCu: goto L_060B79DC; case 0x060B79DEu: goto L_060B79DE; case 0x060B79E0u: goto L_060B79E0; case 0x060B79E2u: goto L_060B79E2; case 0x060B79E6u: goto L_060B79E6; case 0x060B79E8u: goto L_060B79E8; case 0x060B79EAu: goto L_060B79EA; case 0x060B79ECu: goto L_060B79EC; case 0x060B79EEu: goto L_060B79EE; case 0x060B79F0u: goto L_060B79F0; case 0x060B79F2u: goto L_060B79F2; case 0x060B79F4u: goto L_060B79F4; case 0x060B79F6u: goto L_060B79F6; case 0x060B79F8u: goto L_060B79F8; case 0x060B79FAu: goto L_060B79FA; case 0x060B79FCu: goto L_060B79FC; case 0x060B79FEu: goto L_060B79FE; case 0x060B7A00u: goto L_060B7A00; case 0x060B7A04u: goto L_060B7A04; case 0x060B7A08u: goto L_060B7A08; case 0x060B7A0Au: goto L_060B7A0A; case 0x060B7A0Cu: goto L_060B7A0C; case 0x060B7A0Eu: goto L_060B7A0E; case 0x060B7A10u: goto L_060B7A10; case 0x060B7A12u: goto L_060B7A12; case 0x060B7A14u: goto L_060B7A14; case 0x060B7A16u: goto L_060B7A16; case 0x060B7A1Eu: goto L_060B7A1E; case 0x060B7A20u: goto L_060B7A20; case 0x060B7A22u: goto L_060B7A22; case 0x060B7A24u: goto L_060B7A24; case 0x060B7A26u: goto L_060B7A26; case 0x060B7A28u: goto L_060B7A28; case 0x060B7A2Au: goto L_060B7A2A; case 0x060B7A2Cu: goto L_060B7A2C; case 0x060B7A2Eu: goto L_060B7A2E; case 0x060B7A30u: goto L_060B7A30; case 0x060B7A34u: goto L_060B7A34; case 0x060B7A36u: goto L_060B7A36; case 0x060B7A38u: goto L_060B7A38; case 0x060B7A3Au: goto L_060B7A3A; case 0x060B7A3Cu: goto L_060B7A3C; case 0x060B7A3Eu: goto L_060B7A3E; case 0x060B7A40u: goto L_060B7A40; case 0x060B7A42u: goto L_060B7A42; case 0x060B7A44u: goto L_060B7A44; case 0x060B7A4Au: goto L_060B7A4A; case 0x060B7A4Cu: goto L_060B7A4C; case 0x060B7A4Eu: goto L_060B7A4E; case 0x060B7A50u: goto L_060B7A50; case 0x060B7A52u: goto L_060B7A52; case 0x060B7A54u: goto L_060B7A54; case 0x060B7A56u: goto L_060B7A56; case 0x060B7A58u: goto L_060B7A58; default: sh2_call(c, x); return; } }  // 060B7A04 jmp @r0 ; mov.l @r9+,r5
L_060B7A08:
    c.r[3] = ld32(c.r[3]);  // 060B7A08 mov.l @(0,r3),r3
L_060B7A0A:
    c.r[2] = c.r[5];  // 060B7A0A mov r5,r2
L_060B7A0C:
    c.r[4] = ld32(c.r[4]);  // 060B7A0C mov.l @(0,r4),r4
L_060B7A0E:
    c.r[5] = ld32(c.r[9]); c.r[9] += 4;  // 060B7A0E mov.l @r9+,r5
L_060B7A10:
    st32(c.r[11] + 12, c.r[1]);  // 060B7A10 mov.l r1,@(12,r11)
L_060B7A12:
    st32(c.r[11] + 16, c.r[2]);  // 060B7A12 mov.l r2,@(16,r11)
L_060B7A14:
    st32(c.r[11] + 20, c.r[3]);  // 060B7A14 mov.l r3,@(20,r11)
L_060B7A16:
    { const uint32_t x = c.r[5]; st32(c.r[11] + 24, c.r[4]); SH2_POLL(c); switch (x) { case 0x060B7950u: goto L_060B7950; case 0x060B7952u: goto L_060B7952; case 0x060B7954u: goto L_060B7954; case 0x060B7956u: goto L_060B7956; case 0x060B7958u: goto L_060B7958; case 0x060B795Au: goto L_060B795A; case 0x060B795Cu: goto L_060B795C; case 0x060B795Eu: goto L_060B795E; case 0x060B7960u: goto L_060B7960; case 0x060B7962u: goto L_060B7962; case 0x060B7966u: goto L_060B7966; case 0x060B7968u: goto L_060B7968; case 0x060B796Au: goto L_060B796A; case 0x060B796Cu: goto L_060B796C; case 0x060B7970u: goto L_060B7970; case 0x060B7972u: goto L_060B7972; case 0x060B7974u: goto L_060B7974; case 0x060B7976u: goto L_060B7976; case 0x060B797Au: goto L_060B797A; case 0x060B797Cu: goto L_060B797C; case 0x060B797Eu: goto L_060B797E; case 0x060B7980u: goto L_060B7980; case 0x060B7984u: goto L_060B7984; case 0x060B7986u: goto L_060B7986; case 0x060B7988u: goto L_060B7988; case 0x060B798Au: goto L_060B798A; case 0x060B798Eu: goto L_060B798E; case 0x060B7990u: goto L_060B7990; case 0x060B7992u: goto L_060B7992; case 0x060B7994u: goto L_060B7994; case 0x060B7996u: goto L_060B7996; case 0x060B7998u: goto L_060B7998; case 0x060B799Au: goto L_060B799A; case 0x060B799Cu: goto L_060B799C; case 0x060B799Eu: goto L_060B799E; case 0x060B79A0u: goto L_060B79A0; case 0x060B79A2u: goto L_060B79A2; case 0x060B79A4u: goto L_060B79A4; case 0x060B79A6u: goto L_060B79A6; case 0x060B79A8u: goto L_060B79A8; case 0x060B79AAu: goto L_060B79AA; case 0x060B79ACu: goto L_060B79AC; case 0x060B79AEu: goto L_060B79AE; case 0x060B79B0u: goto L_060B79B0; case 0x060B79B2u: goto L_060B79B2; case 0x060B79B4u: goto L_060B79B4; case 0x060B79B6u: goto L_060B79B6; case 0x060B79B8u: goto L_060B79B8; case 0x060B79BAu: goto L_060B79BA; case 0x060B79BCu: goto L_060B79BC; case 0x060B79BEu: goto L_060B79BE; case 0x060B79C0u: goto L_060B79C0; case 0x060B79C2u: goto L_060B79C2; case 0x060B79C4u: goto L_060B79C4; case 0x060B79C8u: goto L_060B79C8; case 0x060B79CAu: goto L_060B79CA; case 0x060B79CCu: goto L_060B79CC; case 0x060B79CEu: goto L_060B79CE; case 0x060B79D0u: goto L_060B79D0; case 0x060B79D2u: goto L_060B79D2; case 0x060B79D4u: goto L_060B79D4; case 0x060B79D6u: goto L_060B79D6; case 0x060B79D8u: goto L_060B79D8; case 0x060B79DAu: goto L_060B79DA; case 0x060B79DCu: goto L_060B79DC; case 0x060B79DEu: goto L_060B79DE; case 0x060B79E0u: goto L_060B79E0; case 0x060B79E2u: goto L_060B79E2; case 0x060B79E6u: goto L_060B79E6; case 0x060B79E8u: goto L_060B79E8; case 0x060B79EAu: goto L_060B79EA; case 0x060B79ECu: goto L_060B79EC; case 0x060B79EEu: goto L_060B79EE; case 0x060B79F0u: goto L_060B79F0; case 0x060B79F2u: goto L_060B79F2; case 0x060B79F4u: goto L_060B79F4; case 0x060B79F6u: goto L_060B79F6; case 0x060B79F8u: goto L_060B79F8; case 0x060B79FAu: goto L_060B79FA; case 0x060B79FCu: goto L_060B79FC; case 0x060B79FEu: goto L_060B79FE; case 0x060B7A00u: goto L_060B7A00; case 0x060B7A04u: goto L_060B7A04; case 0x060B7A08u: goto L_060B7A08; case 0x060B7A0Au: goto L_060B7A0A; case 0x060B7A0Cu: goto L_060B7A0C; case 0x060B7A0Eu: goto L_060B7A0E; case 0x060B7A10u: goto L_060B7A10; case 0x060B7A12u: goto L_060B7A12; case 0x060B7A14u: goto L_060B7A14; case 0x060B7A16u: goto L_060B7A16; case 0x060B7A1Eu: goto L_060B7A1E; case 0x060B7A20u: goto L_060B7A20; case 0x060B7A22u: goto L_060B7A22; case 0x060B7A24u: goto L_060B7A24; case 0x060B7A26u: goto L_060B7A26; case 0x060B7A28u: goto L_060B7A28; case 0x060B7A2Au: goto L_060B7A2A; case 0x060B7A2Cu: goto L_060B7A2C; case 0x060B7A2Eu: goto L_060B7A2E; case 0x060B7A30u: goto L_060B7A30; case 0x060B7A34u: goto L_060B7A34; case 0x060B7A36u: goto L_060B7A36; case 0x060B7A38u: goto L_060B7A38; case 0x060B7A3Au: goto L_060B7A3A; case 0x060B7A3Cu: goto L_060B7A3C; case 0x060B7A3Eu: goto L_060B7A3E; case 0x060B7A40u: goto L_060B7A40; case 0x060B7A42u: goto L_060B7A42; case 0x060B7A44u: goto L_060B7A44; case 0x060B7A4Au: goto L_060B7A4A; case 0x060B7A4Cu: goto L_060B7A4C; case 0x060B7A4Eu: goto L_060B7A4E; case 0x060B7A50u: goto L_060B7A50; case 0x060B7A52u: goto L_060B7A52; case 0x060B7A54u: goto L_060B7A54; case 0x060B7A56u: goto L_060B7A56; case 0x060B7A58u: goto L_060B7A58; default: sh2_call(c, x); return; } }  // 060B7A16 jmp @r5 ; mov.l r4,@(24,r11)
L_060B7A1E:
    c.r[4] = ld32(c.r[4]);  // 060B7A1E mov.l @(0,r4),r4
L_060B7A20:
    c.r[3] = c.r[5];  // 060B7A20 mov r5,r3
L_060B7A22:
    c.r[5] = ld32(c.r[9]); c.r[9] += 4;  // 060B7A22 mov.l @r9+,r5
L_060B7A24:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[11]);  // 060B7A24 mov.w @(0,r11),r0
L_060B7A26:
    st32(c.r[11] + 16, c.r[1]);  // 060B7A26 mov.l r1,@(16,r11)
L_060B7A28:
    c.r[0] ^= 0x10u;  // 060B7A28 xor #16,r0
L_060B7A2A:
    st16(c.r[11], c.r[0]);  // 060B7A2A mov.w r0,@(0,r11)
L_060B7A2C:
    st32(c.r[11] + 12, c.r[2]);  // 060B7A2C mov.l r2,@(12,r11)
L_060B7A2E:
    st32(c.r[11] + 24, c.r[3]);  // 060B7A2E mov.l r3,@(24,r11)
L_060B7A30:
    { const uint32_t x = c.r[5]; st32(c.r[11] + 20, c.r[4]); SH2_POLL(c); switch (x) { case 0x060B7950u: goto L_060B7950; case 0x060B7952u: goto L_060B7952; case 0x060B7954u: goto L_060B7954; case 0x060B7956u: goto L_060B7956; case 0x060B7958u: goto L_060B7958; case 0x060B795Au: goto L_060B795A; case 0x060B795Cu: goto L_060B795C; case 0x060B795Eu: goto L_060B795E; case 0x060B7960u: goto L_060B7960; case 0x060B7962u: goto L_060B7962; case 0x060B7966u: goto L_060B7966; case 0x060B7968u: goto L_060B7968; case 0x060B796Au: goto L_060B796A; case 0x060B796Cu: goto L_060B796C; case 0x060B7970u: goto L_060B7970; case 0x060B7972u: goto L_060B7972; case 0x060B7974u: goto L_060B7974; case 0x060B7976u: goto L_060B7976; case 0x060B797Au: goto L_060B797A; case 0x060B797Cu: goto L_060B797C; case 0x060B797Eu: goto L_060B797E; case 0x060B7980u: goto L_060B7980; case 0x060B7984u: goto L_060B7984; case 0x060B7986u: goto L_060B7986; case 0x060B7988u: goto L_060B7988; case 0x060B798Au: goto L_060B798A; case 0x060B798Eu: goto L_060B798E; case 0x060B7990u: goto L_060B7990; case 0x060B7992u: goto L_060B7992; case 0x060B7994u: goto L_060B7994; case 0x060B7996u: goto L_060B7996; case 0x060B7998u: goto L_060B7998; case 0x060B799Au: goto L_060B799A; case 0x060B799Cu: goto L_060B799C; case 0x060B799Eu: goto L_060B799E; case 0x060B79A0u: goto L_060B79A0; case 0x060B79A2u: goto L_060B79A2; case 0x060B79A4u: goto L_060B79A4; case 0x060B79A6u: goto L_060B79A6; case 0x060B79A8u: goto L_060B79A8; case 0x060B79AAu: goto L_060B79AA; case 0x060B79ACu: goto L_060B79AC; case 0x060B79AEu: goto L_060B79AE; case 0x060B79B0u: goto L_060B79B0; case 0x060B79B2u: goto L_060B79B2; case 0x060B79B4u: goto L_060B79B4; case 0x060B79B6u: goto L_060B79B6; case 0x060B79B8u: goto L_060B79B8; case 0x060B79BAu: goto L_060B79BA; case 0x060B79BCu: goto L_060B79BC; case 0x060B79BEu: goto L_060B79BE; case 0x060B79C0u: goto L_060B79C0; case 0x060B79C2u: goto L_060B79C2; case 0x060B79C4u: goto L_060B79C4; case 0x060B79C8u: goto L_060B79C8; case 0x060B79CAu: goto L_060B79CA; case 0x060B79CCu: goto L_060B79CC; case 0x060B79CEu: goto L_060B79CE; case 0x060B79D0u: goto L_060B79D0; case 0x060B79D2u: goto L_060B79D2; case 0x060B79D4u: goto L_060B79D4; case 0x060B79D6u: goto L_060B79D6; case 0x060B79D8u: goto L_060B79D8; case 0x060B79DAu: goto L_060B79DA; case 0x060B79DCu: goto L_060B79DC; case 0x060B79DEu: goto L_060B79DE; case 0x060B79E0u: goto L_060B79E0; case 0x060B79E2u: goto L_060B79E2; case 0x060B79E6u: goto L_060B79E6; case 0x060B79E8u: goto L_060B79E8; case 0x060B79EAu: goto L_060B79EA; case 0x060B79ECu: goto L_060B79EC; case 0x060B79EEu: goto L_060B79EE; case 0x060B79F0u: goto L_060B79F0; case 0x060B79F2u: goto L_060B79F2; case 0x060B79F4u: goto L_060B79F4; case 0x060B79F6u: goto L_060B79F6; case 0x060B79F8u: goto L_060B79F8; case 0x060B79FAu: goto L_060B79FA; case 0x060B79FCu: goto L_060B79FC; case 0x060B79FEu: goto L_060B79FE; case 0x060B7A00u: goto L_060B7A00; case 0x060B7A04u: goto L_060B7A04; case 0x060B7A08u: goto L_060B7A08; case 0x060B7A0Au: goto L_060B7A0A; case 0x060B7A0Cu: goto L_060B7A0C; case 0x060B7A0Eu: goto L_060B7A0E; case 0x060B7A10u: goto L_060B7A10; case 0x060B7A12u: goto L_060B7A12; case 0x060B7A14u: goto L_060B7A14; case 0x060B7A16u: goto L_060B7A16; case 0x060B7A1Eu: goto L_060B7A1E; case 0x060B7A20u: goto L_060B7A20; case 0x060B7A22u: goto L_060B7A22; case 0x060B7A24u: goto L_060B7A24; case 0x060B7A26u: goto L_060B7A26; case 0x060B7A28u: goto L_060B7A28; case 0x060B7A2Au: goto L_060B7A2A; case 0x060B7A2Cu: goto L_060B7A2C; case 0x060B7A2Eu: goto L_060B7A2E; case 0x060B7A30u: goto L_060B7A30; case 0x060B7A34u: goto L_060B7A34; case 0x060B7A36u: goto L_060B7A36; case 0x060B7A38u: goto L_060B7A38; case 0x060B7A3Au: goto L_060B7A3A; case 0x060B7A3Cu: goto L_060B7A3C; case 0x060B7A3Eu: goto L_060B7A3E; case 0x060B7A40u: goto L_060B7A40; case 0x060B7A42u: goto L_060B7A42; case 0x060B7A44u: goto L_060B7A44; case 0x060B7A4Au: goto L_060B7A4A; case 0x060B7A4Cu: goto L_060B7A4C; case 0x060B7A4Eu: goto L_060B7A4E; case 0x060B7A50u: goto L_060B7A50; case 0x060B7A52u: goto L_060B7A52; case 0x060B7A54u: goto L_060B7A54; case 0x060B7A56u: goto L_060B7A56; case 0x060B7A58u: goto L_060B7A58; default: sh2_call(c, x); return; } }  // 060B7A30 jmp @r5 ; mov.l r4,@(20,r11)
L_060B7A34:
    c.r[4] = c.r[5];  // 060B7A34 mov r5,r4
L_060B7A36:
    c.r[5] = ld32(c.r[9]); c.r[9] += 4;  // 060B7A36 mov.l @r9+,r5
L_060B7A38:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[11]);  // 060B7A38 mov.w @(0,r11),r0
L_060B7A3A:
    st32(c.r[11] + 20, c.r[1]);  // 060B7A3A mov.l r1,@(20,r11)
L_060B7A3C:
    c.r[0] ^= 0x30u;  // 060B7A3C xor #48,r0
L_060B7A3E:
    st16(c.r[11], c.r[0]);  // 060B7A3E mov.w r0,@(0,r11)
L_060B7A40:
    st32(c.r[11] + 24, c.r[2]);  // 060B7A40 mov.l r2,@(24,r11)
L_060B7A42:
    st32(c.r[11] + 12, c.r[3]);  // 060B7A42 mov.l r3,@(12,r11)
L_060B7A44:
    { const uint32_t x = c.r[5]; st32(c.r[11] + 16, c.r[4]); SH2_POLL(c); switch (x) { case 0x060B7950u: goto L_060B7950; case 0x060B7952u: goto L_060B7952; case 0x060B7954u: goto L_060B7954; case 0x060B7956u: goto L_060B7956; case 0x060B7958u: goto L_060B7958; case 0x060B795Au: goto L_060B795A; case 0x060B795Cu: goto L_060B795C; case 0x060B795Eu: goto L_060B795E; case 0x060B7960u: goto L_060B7960; case 0x060B7962u: goto L_060B7962; case 0x060B7966u: goto L_060B7966; case 0x060B7968u: goto L_060B7968; case 0x060B796Au: goto L_060B796A; case 0x060B796Cu: goto L_060B796C; case 0x060B7970u: goto L_060B7970; case 0x060B7972u: goto L_060B7972; case 0x060B7974u: goto L_060B7974; case 0x060B7976u: goto L_060B7976; case 0x060B797Au: goto L_060B797A; case 0x060B797Cu: goto L_060B797C; case 0x060B797Eu: goto L_060B797E; case 0x060B7980u: goto L_060B7980; case 0x060B7984u: goto L_060B7984; case 0x060B7986u: goto L_060B7986; case 0x060B7988u: goto L_060B7988; case 0x060B798Au: goto L_060B798A; case 0x060B798Eu: goto L_060B798E; case 0x060B7990u: goto L_060B7990; case 0x060B7992u: goto L_060B7992; case 0x060B7994u: goto L_060B7994; case 0x060B7996u: goto L_060B7996; case 0x060B7998u: goto L_060B7998; case 0x060B799Au: goto L_060B799A; case 0x060B799Cu: goto L_060B799C; case 0x060B799Eu: goto L_060B799E; case 0x060B79A0u: goto L_060B79A0; case 0x060B79A2u: goto L_060B79A2; case 0x060B79A4u: goto L_060B79A4; case 0x060B79A6u: goto L_060B79A6; case 0x060B79A8u: goto L_060B79A8; case 0x060B79AAu: goto L_060B79AA; case 0x060B79ACu: goto L_060B79AC; case 0x060B79AEu: goto L_060B79AE; case 0x060B79B0u: goto L_060B79B0; case 0x060B79B2u: goto L_060B79B2; case 0x060B79B4u: goto L_060B79B4; case 0x060B79B6u: goto L_060B79B6; case 0x060B79B8u: goto L_060B79B8; case 0x060B79BAu: goto L_060B79BA; case 0x060B79BCu: goto L_060B79BC; case 0x060B79BEu: goto L_060B79BE; case 0x060B79C0u: goto L_060B79C0; case 0x060B79C2u: goto L_060B79C2; case 0x060B79C4u: goto L_060B79C4; case 0x060B79C8u: goto L_060B79C8; case 0x060B79CAu: goto L_060B79CA; case 0x060B79CCu: goto L_060B79CC; case 0x060B79CEu: goto L_060B79CE; case 0x060B79D0u: goto L_060B79D0; case 0x060B79D2u: goto L_060B79D2; case 0x060B79D4u: goto L_060B79D4; case 0x060B79D6u: goto L_060B79D6; case 0x060B79D8u: goto L_060B79D8; case 0x060B79DAu: goto L_060B79DA; case 0x060B79DCu: goto L_060B79DC; case 0x060B79DEu: goto L_060B79DE; case 0x060B79E0u: goto L_060B79E0; case 0x060B79E2u: goto L_060B79E2; case 0x060B79E6u: goto L_060B79E6; case 0x060B79E8u: goto L_060B79E8; case 0x060B79EAu: goto L_060B79EA; case 0x060B79ECu: goto L_060B79EC; case 0x060B79EEu: goto L_060B79EE; case 0x060B79F0u: goto L_060B79F0; case 0x060B79F2u: goto L_060B79F2; case 0x060B79F4u: goto L_060B79F4; case 0x060B79F6u: goto L_060B79F6; case 0x060B79F8u: goto L_060B79F8; case 0x060B79FAu: goto L_060B79FA; case 0x060B79FCu: goto L_060B79FC; case 0x060B79FEu: goto L_060B79FE; case 0x060B7A00u: goto L_060B7A00; case 0x060B7A04u: goto L_060B7A04; case 0x060B7A08u: goto L_060B7A08; case 0x060B7A0Au: goto L_060B7A0A; case 0x060B7A0Cu: goto L_060B7A0C; case 0x060B7A0Eu: goto L_060B7A0E; case 0x060B7A10u: goto L_060B7A10; case 0x060B7A12u: goto L_060B7A12; case 0x060B7A14u: goto L_060B7A14; case 0x060B7A16u: goto L_060B7A16; case 0x060B7A1Eu: goto L_060B7A1E; case 0x060B7A20u: goto L_060B7A20; case 0x060B7A22u: goto L_060B7A22; case 0x060B7A24u: goto L_060B7A24; case 0x060B7A26u: goto L_060B7A26; case 0x060B7A28u: goto L_060B7A28; case 0x060B7A2Au: goto L_060B7A2A; case 0x060B7A2Cu: goto L_060B7A2C; case 0x060B7A2Eu: goto L_060B7A2E; case 0x060B7A30u: goto L_060B7A30; case 0x060B7A34u: goto L_060B7A34; case 0x060B7A36u: goto L_060B7A36; case 0x060B7A38u: goto L_060B7A38; case 0x060B7A3Au: goto L_060B7A3A; case 0x060B7A3Cu: goto L_060B7A3C; case 0x060B7A3Eu: goto L_060B7A3E; case 0x060B7A40u: goto L_060B7A40; case 0x060B7A42u: goto L_060B7A42; case 0x060B7A44u: goto L_060B7A44; case 0x060B7A4Au: goto L_060B7A4A; case 0x060B7A4Cu: goto L_060B7A4C; case 0x060B7A4Eu: goto L_060B7A4E; case 0x060B7A50u: goto L_060B7A50; case 0x060B7A52u: goto L_060B7A52; case 0x060B7A54u: goto L_060B7A54; case 0x060B7A56u: goto L_060B7A56; case 0x060B7A58u: goto L_060B7A58; default: sh2_call(c, x); return; } }  // 060B7A44 jmp @r5 ; mov.l r4,@(16,r11)
L_060B7A4A:
    c.r[5] = ld32(c.r[9]); c.r[9] += 4;  // 060B7A4A mov.l @r9+,r5
L_060B7A4C:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[11]);  // 060B7A4C mov.w @(0,r11),r0
L_060B7A4E:
    st32(c.r[11] + 24, c.r[1]);  // 060B7A4E mov.l r1,@(24,r11)
L_060B7A50:
    c.r[0] ^= 0x20u;  // 060B7A50 xor #32,r0
L_060B7A52:
    st16(c.r[11], c.r[0]);  // 060B7A52 mov.w r0,@(0,r11)
L_060B7A54:
    st32(c.r[11] + 20, c.r[2]);  // 060B7A54 mov.l r2,@(20,r11)
L_060B7A56:
    st32(c.r[11] + 16, c.r[3]);  // 060B7A56 mov.l r3,@(16,r11)
L_060B7A58:
    { const uint32_t x = c.r[5]; st32(c.r[11] + 12, c.r[4]); SH2_POLL(c); switch (x) { case 0x060B7950u: goto L_060B7950; case 0x060B7952u: goto L_060B7952; case 0x060B7954u: goto L_060B7954; case 0x060B7956u: goto L_060B7956; case 0x060B7958u: goto L_060B7958; case 0x060B795Au: goto L_060B795A; case 0x060B795Cu: goto L_060B795C; case 0x060B795Eu: goto L_060B795E; case 0x060B7960u: goto L_060B7960; case 0x060B7962u: goto L_060B7962; case 0x060B7966u: goto L_060B7966; case 0x060B7968u: goto L_060B7968; case 0x060B796Au: goto L_060B796A; case 0x060B796Cu: goto L_060B796C; case 0x060B7970u: goto L_060B7970; case 0x060B7972u: goto L_060B7972; case 0x060B7974u: goto L_060B7974; case 0x060B7976u: goto L_060B7976; case 0x060B797Au: goto L_060B797A; case 0x060B797Cu: goto L_060B797C; case 0x060B797Eu: goto L_060B797E; case 0x060B7980u: goto L_060B7980; case 0x060B7984u: goto L_060B7984; case 0x060B7986u: goto L_060B7986; case 0x060B7988u: goto L_060B7988; case 0x060B798Au: goto L_060B798A; case 0x060B798Eu: goto L_060B798E; case 0x060B7990u: goto L_060B7990; case 0x060B7992u: goto L_060B7992; case 0x060B7994u: goto L_060B7994; case 0x060B7996u: goto L_060B7996; case 0x060B7998u: goto L_060B7998; case 0x060B799Au: goto L_060B799A; case 0x060B799Cu: goto L_060B799C; case 0x060B799Eu: goto L_060B799E; case 0x060B79A0u: goto L_060B79A0; case 0x060B79A2u: goto L_060B79A2; case 0x060B79A4u: goto L_060B79A4; case 0x060B79A6u: goto L_060B79A6; case 0x060B79A8u: goto L_060B79A8; case 0x060B79AAu: goto L_060B79AA; case 0x060B79ACu: goto L_060B79AC; case 0x060B79AEu: goto L_060B79AE; case 0x060B79B0u: goto L_060B79B0; case 0x060B79B2u: goto L_060B79B2; case 0x060B79B4u: goto L_060B79B4; case 0x060B79B6u: goto L_060B79B6; case 0x060B79B8u: goto L_060B79B8; case 0x060B79BAu: goto L_060B79BA; case 0x060B79BCu: goto L_060B79BC; case 0x060B79BEu: goto L_060B79BE; case 0x060B79C0u: goto L_060B79C0; case 0x060B79C2u: goto L_060B79C2; case 0x060B79C4u: goto L_060B79C4; case 0x060B79C8u: goto L_060B79C8; case 0x060B79CAu: goto L_060B79CA; case 0x060B79CCu: goto L_060B79CC; case 0x060B79CEu: goto L_060B79CE; case 0x060B79D0u: goto L_060B79D0; case 0x060B79D2u: goto L_060B79D2; case 0x060B79D4u: goto L_060B79D4; case 0x060B79D6u: goto L_060B79D6; case 0x060B79D8u: goto L_060B79D8; case 0x060B79DAu: goto L_060B79DA; case 0x060B79DCu: goto L_060B79DC; case 0x060B79DEu: goto L_060B79DE; case 0x060B79E0u: goto L_060B79E0; case 0x060B79E2u: goto L_060B79E2; case 0x060B79E6u: goto L_060B79E6; case 0x060B79E8u: goto L_060B79E8; case 0x060B79EAu: goto L_060B79EA; case 0x060B79ECu: goto L_060B79EC; case 0x060B79EEu: goto L_060B79EE; case 0x060B79F0u: goto L_060B79F0; case 0x060B79F2u: goto L_060B79F2; case 0x060B79F4u: goto L_060B79F4; case 0x060B79F6u: goto L_060B79F6; case 0x060B79F8u: goto L_060B79F8; case 0x060B79FAu: goto L_060B79FA; case 0x060B79FCu: goto L_060B79FC; case 0x060B79FEu: goto L_060B79FE; case 0x060B7A00u: goto L_060B7A00; case 0x060B7A04u: goto L_060B7A04; case 0x060B7A08u: goto L_060B7A08; case 0x060B7A0Au: goto L_060B7A0A; case 0x060B7A0Cu: goto L_060B7A0C; case 0x060B7A0Eu: goto L_060B7A0E; case 0x060B7A10u: goto L_060B7A10; case 0x060B7A12u: goto L_060B7A12; case 0x060B7A14u: goto L_060B7A14; case 0x060B7A16u: goto L_060B7A16; case 0x060B7A1Eu: goto L_060B7A1E; case 0x060B7A20u: goto L_060B7A20; case 0x060B7A22u: goto L_060B7A22; case 0x060B7A24u: goto L_060B7A24; case 0x060B7A26u: goto L_060B7A26; case 0x060B7A28u: goto L_060B7A28; case 0x060B7A2Au: goto L_060B7A2A; case 0x060B7A2Cu: goto L_060B7A2C; case 0x060B7A2Eu: goto L_060B7A2E; case 0x060B7A30u: goto L_060B7A30; case 0x060B7A34u: goto L_060B7A34; case 0x060B7A36u: goto L_060B7A36; case 0x060B7A38u: goto L_060B7A38; case 0x060B7A3Au: goto L_060B7A3A; case 0x060B7A3Cu: goto L_060B7A3C; case 0x060B7A3Eu: goto L_060B7A3E; case 0x060B7A40u: goto L_060B7A40; case 0x060B7A42u: goto L_060B7A42; case 0x060B7A44u: goto L_060B7A44; case 0x060B7A4Au: goto L_060B7A4A; case 0x060B7A4Cu: goto L_060B7A4C; case 0x060B7A4Eu: goto L_060B7A4E; case 0x060B7A50u: goto L_060B7A50; case 0x060B7A52u: goto L_060B7A52; case 0x060B7A54u: goto L_060B7A54; case 0x060B7A56u: goto L_060B7A56; case 0x060B7A58u: goto L_060B7A58; default: sh2_call(c, x); return; } }  // 060B7A58 jmp @r5 ; mov.l r4,@(12,r11)
}

void f_060B7958(SH2Context& c) {
    ran[3139] = 1;
L_060B7958:
    c.r[5] >>= 16;  // 060B7958 shlr16 r5
L_060B795A:
    c.r[5] >>= 2;  // 060B795A shlr2 r5
L_060B795C:
    c.t = c.r[5] & 1; c.r[5] >>= 1;  // 060B795C shlr r5
L_060B795E:
    if (!c.t) { goto L_060B7966; }  // 060B795E bf 0x060B7966
L_060B7960:
    c.r[1] = ld32(c.r[1]);  // 060B7960 mov.l @(0,r1),r1
L_060B7962:
    c.r[5] = ld32(c.r[2]); goto L_060B7A08;  // 060B7962 bra 0x060B7A08 ; mov.l @(0,r2),r5
L_060B7966:
    c.r[0] = ld32(c.r[1] + 4);  // 060B7966 mov.l @(4,r1),r0
L_060B7968:
    c.r[1] = ld32(c.r[1]);  // 060B7968 mov.l @(0,r1),r1
L_060B796A:
    c.t = (c.r[0] & 0x1u) == 0;  // 060B796A tst #1,r0
L_060B796C:
    { const bool k = c.t; c.r[5] = ld32(c.r[2]); if (k) { goto L_060B7A08; } }  // 060B796C bt/s 0x060B7A08 ; mov.l @(0,r2),r5
L_060B7970:
    c.r[0] = ld32(c.r[2] + 4);  // 060B7970 mov.l @(4,r2),r0
L_060B7972:
    c.r[2] = c.r[5];  // 060B7972 mov r5,r2
L_060B7974:
    c.t = (c.r[0] & 0x1u) == 0;  // 060B7974 tst #1,r0
L_060B7976:
    { const bool k = c.t; c.r[5] = ld32(c.r[3]); if (k) { goto L_060B7A1E; } }  // 060B7976 bt/s 0x060B7A1E ; mov.l @(0,r3),r5
L_060B797A:
    c.r[0] = ld32(c.r[3] + 4);  // 060B797A mov.l @(4,r3),r0
L_060B797C:
    c.r[3] = c.r[5];  // 060B797C mov r5,r3
L_060B797E:
    c.t = (c.r[0] & 0x1u) == 0;  // 060B797E tst #1,r0
L_060B7980:
    { const bool k = c.t; c.r[5] = ld32(c.r[4]); if (k) { goto L_060B7A34; } }  // 060B7980 bt/s 0x060B7A34 ; mov.l @(0,r4),r5
L_060B7984:
    c.r[0] = ld32(c.r[4] + 4);  // 060B7984 mov.l @(4,r4),r0
L_060B7986:
    c.r[4] = c.r[5];  // 060B7986 mov r5,r4
L_060B7988:
    c.t = (c.r[0] & 0x1u) == 0;  // 060B7988 tst #1,r0
L_060B798A:
    { const bool k = c.t; c.r[5] = 0x1u; if (k) { goto L_060B7A4A; } }  // 060B798A bt/s 0x060B7A4A ; mov #1,r5
L_060B798E:
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060B798E mov.l r9,@-r15
L_060B7990:
    c.r[5] <<= 16;  // 060B7990 shll16 r5
L_060B7992:
    c.t = c.r[5] & 1; c.r[5] >>= 1;  // 060B7992 shlr r5
L_060B7994:
    c.r[9] = c.r[4] << 16 | c.r[4] >> 16;  // 060B7994 swap.w r4,r9
L_060B7996:
    c.t = (c.r[9] & c.r[5]) == 0;  // 060B7996 tst r5,r9
L_060B7998:
    { uint32_t a = c.r[13], b = c.r[13], t = c.t; c.r[13] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B7998 subc r13,r13
L_060B799A:
    c.r[13] = ~c.r[13];  // 060B799A not r13,r13
L_060B799C:
    c.r[13] ^= c.r[9];  // 060B799C xor r9,r13
L_060B799E:
    c.t = (c.r[4] & c.r[5]) == 0;  // 060B799E tst r5,r4
L_060B79A0:
    { uint32_t a = c.r[9], b = c.r[9], t = c.t; c.r[9] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B79A0 subc r9,r9
L_060B79A2:
    c.r[9] = ~c.r[9];  // 060B79A2 not r9,r9
L_060B79A4:
    c.r[9] ^= c.r[4];  // 060B79A4 xor r4,r9
L_060B79A6:
    c.r[13] += c.r[9];  // 060B79A6 add r9,r13
L_060B79A8:
    c.r[13] = c.r[13] & 0xFFFFu;  // 060B79A8 extu.w r13,r13
L_060B79AA:
    c.r[0] = 0x060B7A4Cu;  // 060B79AA mova 0x060B7A4C,r0
L_060B79AC:
    c.r[9] = c.r[3] << 16 | c.r[3] >> 16;  // 060B79AC swap.w r3,r9
L_060B79AE:
    c.t = (c.r[9] & c.r[5]) == 0;  // 060B79AE tst r5,r9
L_060B79B0:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B79B0 subc r12,r12
L_060B79B2:
    c.r[12] = ~c.r[12];  // 060B79B2 not r12,r12
L_060B79B4:
    c.r[12] ^= c.r[9];  // 060B79B4 xor r9,r12
L_060B79B6:
    c.t = (c.r[3] & c.r[5]) == 0;  // 060B79B6 tst r5,r3
L_060B79B8:
    { uint32_t a = c.r[9], b = c.r[9], t = c.t; c.r[9] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B79B8 subc r9,r9
L_060B79BA:
    c.r[9] = ~c.r[9];  // 060B79BA not r9,r9
L_060B79BC:
    c.r[9] ^= c.r[3];  // 060B79BC xor r3,r9
L_060B79BE:
    c.r[12] += c.r[9];  // 060B79BE add r9,r12
L_060B79C0:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B79C0 extu.w r12,r12
L_060B79C2:
    c.t = (int32_t)c.r[12] > (int32_t)c.r[13];  // 060B79C2 cmp/gt r13,r12
L_060B79C4:
    { const bool k = c.t; c.r[9] = c.r[2] << 16 | c.r[2] >> 16; if (k) { goto L_060B79CC; } }  // 060B79C4 bt/s 0x060B79CC ; swap.w r2,r9
L_060B79C8:
    c.r[13] = c.r[12];  // 060B79C8 mov r12,r13
L_060B79CA:
    c.r[0] = 0x060B7A38u;  // 060B79CA mova 0x060B7A38,r0
L_060B79CC:
    c.t = (c.r[9] & c.r[5]) == 0;  // 060B79CC tst r5,r9
L_060B79CE:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B79CE subc r12,r12
L_060B79D0:
    c.r[12] = ~c.r[12];  // 060B79D0 not r12,r12
L_060B79D2:
    c.r[12] ^= c.r[9];  // 060B79D2 xor r9,r12
L_060B79D4:
    c.t = (c.r[2] & c.r[5]) == 0;  // 060B79D4 tst r5,r2
L_060B79D6:
    { uint32_t a = c.r[9], b = c.r[9], t = c.t; c.r[9] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B79D6 subc r9,r9
L_060B79D8:
    c.r[9] = ~c.r[9];  // 060B79D8 not r9,r9
L_060B79DA:
    c.r[9] ^= c.r[2];  // 060B79DA xor r2,r9
L_060B79DC:
    c.r[12] += c.r[9];  // 060B79DC add r9,r12
L_060B79DE:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B79DE extu.w r12,r12
L_060B79E0:
    c.t = (int32_t)c.r[12] > (int32_t)c.r[13];  // 060B79E0 cmp/gt r13,r12
L_060B79E2:
    { const bool k = c.t; c.r[9] = c.r[1] << 16 | c.r[1] >> 16; if (k) { goto L_060B79EA; } }  // 060B79E2 bt/s 0x060B79EA ; swap.w r1,r9
L_060B79E6:
    c.r[13] = c.r[12];  // 060B79E6 mov r12,r13
L_060B79E8:
    c.r[0] = 0x060B7A24u;  // 060B79E8 mova 0x060B7A24,r0
L_060B79EA:
    c.t = (c.r[9] & c.r[5]) == 0;  // 060B79EA tst r5,r9
L_060B79EC:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B79EC subc r12,r12
L_060B79EE:
    c.r[12] = ~c.r[12];  // 060B79EE not r12,r12
L_060B79F0:
    c.r[12] ^= c.r[9];  // 060B79F0 xor r9,r12
L_060B79F2:
    c.t = (c.r[1] & c.r[5]) == 0;  // 060B79F2 tst r5,r1
L_060B79F4:
    { uint32_t a = c.r[9], b = c.r[9], t = c.t; c.r[9] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B79F4 subc r9,r9
L_060B79F6:
    c.r[9] = ~c.r[9];  // 060B79F6 not r9,r9
L_060B79F8:
    c.r[9] ^= c.r[1];  // 060B79F8 xor r1,r9
L_060B79FA:
    c.r[12] += c.r[9];  // 060B79FA add r9,r12
L_060B79FC:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B79FC extu.w r12,r12
L_060B79FE:
    c.t = (int32_t)c.r[13] >= (int32_t)c.r[12];  // 060B79FE cmp/ge r12,r13
L_060B7A00:
    { const bool k = c.t; c.r[9] = ld32(c.r[15]); c.r[15] += 4; if (k) { goto L_060B7A0E; } }  // 060B7A00 bt/s 0x060B7A0E ; mov.l @r15+,r9
L_060B7A04:
    { const uint32_t x = c.r[0]; c.r[5] = ld32(c.r[9]); c.r[9] += 4; SH2_POLL(c); switch (x) { case 0x060B7958u: goto L_060B7958; case 0x060B795Au: goto L_060B795A; case 0x060B795Cu: goto L_060B795C; case 0x060B795Eu: goto L_060B795E; case 0x060B7960u: goto L_060B7960; case 0x060B7962u: goto L_060B7962; case 0x060B7966u: goto L_060B7966; case 0x060B7968u: goto L_060B7968; case 0x060B796Au: goto L_060B796A; case 0x060B796Cu: goto L_060B796C; case 0x060B7970u: goto L_060B7970; case 0x060B7972u: goto L_060B7972; case 0x060B7974u: goto L_060B7974; case 0x060B7976u: goto L_060B7976; case 0x060B797Au: goto L_060B797A; case 0x060B797Cu: goto L_060B797C; case 0x060B797Eu: goto L_060B797E; case 0x060B7980u: goto L_060B7980; case 0x060B7984u: goto L_060B7984; case 0x060B7986u: goto L_060B7986; case 0x060B7988u: goto L_060B7988; case 0x060B798Au: goto L_060B798A; case 0x060B798Eu: goto L_060B798E; case 0x060B7990u: goto L_060B7990; case 0x060B7992u: goto L_060B7992; case 0x060B7994u: goto L_060B7994; case 0x060B7996u: goto L_060B7996; case 0x060B7998u: goto L_060B7998; case 0x060B799Au: goto L_060B799A; case 0x060B799Cu: goto L_060B799C; case 0x060B799Eu: goto L_060B799E; case 0x060B79A0u: goto L_060B79A0; case 0x060B79A2u: goto L_060B79A2; case 0x060B79A4u: goto L_060B79A4; case 0x060B79A6u: goto L_060B79A6; case 0x060B79A8u: goto L_060B79A8; case 0x060B79AAu: goto L_060B79AA; case 0x060B79ACu: goto L_060B79AC; case 0x060B79AEu: goto L_060B79AE; case 0x060B79B0u: goto L_060B79B0; case 0x060B79B2u: goto L_060B79B2; case 0x060B79B4u: goto L_060B79B4; case 0x060B79B6u: goto L_060B79B6; case 0x060B79B8u: goto L_060B79B8; case 0x060B79BAu: goto L_060B79BA; case 0x060B79BCu: goto L_060B79BC; case 0x060B79BEu: goto L_060B79BE; case 0x060B79C0u: goto L_060B79C0; case 0x060B79C2u: goto L_060B79C2; case 0x060B79C4u: goto L_060B79C4; case 0x060B79C8u: goto L_060B79C8; case 0x060B79CAu: goto L_060B79CA; case 0x060B79CCu: goto L_060B79CC; case 0x060B79CEu: goto L_060B79CE; case 0x060B79D0u: goto L_060B79D0; case 0x060B79D2u: goto L_060B79D2; case 0x060B79D4u: goto L_060B79D4; case 0x060B79D6u: goto L_060B79D6; case 0x060B79D8u: goto L_060B79D8; case 0x060B79DAu: goto L_060B79DA; case 0x060B79DCu: goto L_060B79DC; case 0x060B79DEu: goto L_060B79DE; case 0x060B79E0u: goto L_060B79E0; case 0x060B79E2u: goto L_060B79E2; case 0x060B79E6u: goto L_060B79E6; case 0x060B79E8u: goto L_060B79E8; case 0x060B79EAu: goto L_060B79EA; case 0x060B79ECu: goto L_060B79EC; case 0x060B79EEu: goto L_060B79EE; case 0x060B79F0u: goto L_060B79F0; case 0x060B79F2u: goto L_060B79F2; case 0x060B79F4u: goto L_060B79F4; case 0x060B79F6u: goto L_060B79F6; case 0x060B79F8u: goto L_060B79F8; case 0x060B79FAu: goto L_060B79FA; case 0x060B79FCu: goto L_060B79FC; case 0x060B79FEu: goto L_060B79FE; case 0x060B7A00u: goto L_060B7A00; case 0x060B7A04u: goto L_060B7A04; case 0x060B7A08u: goto L_060B7A08; case 0x060B7A0Au: goto L_060B7A0A; case 0x060B7A0Cu: goto L_060B7A0C; case 0x060B7A0Eu: goto L_060B7A0E; case 0x060B7A10u: goto L_060B7A10; case 0x060B7A12u: goto L_060B7A12; case 0x060B7A14u: goto L_060B7A14; case 0x060B7A16u: goto L_060B7A16; case 0x060B7A1Eu: goto L_060B7A1E; case 0x060B7A20u: goto L_060B7A20; case 0x060B7A22u: goto L_060B7A22; case 0x060B7A24u: goto L_060B7A24; case 0x060B7A26u: goto L_060B7A26; case 0x060B7A28u: goto L_060B7A28; case 0x060B7A2Au: goto L_060B7A2A; case 0x060B7A2Cu: goto L_060B7A2C; case 0x060B7A2Eu: goto L_060B7A2E; case 0x060B7A30u: goto L_060B7A30; case 0x060B7A34u: goto L_060B7A34; case 0x060B7A36u: goto L_060B7A36; case 0x060B7A38u: goto L_060B7A38; case 0x060B7A3Au: goto L_060B7A3A; case 0x060B7A3Cu: goto L_060B7A3C; case 0x060B7A3Eu: goto L_060B7A3E; case 0x060B7A40u: goto L_060B7A40; case 0x060B7A42u: goto L_060B7A42; case 0x060B7A44u: goto L_060B7A44; case 0x060B7A4Au: goto L_060B7A4A; case 0x060B7A4Cu: goto L_060B7A4C; case 0x060B7A4Eu: goto L_060B7A4E; case 0x060B7A50u: goto L_060B7A50; case 0x060B7A52u: goto L_060B7A52; case 0x060B7A54u: goto L_060B7A54; case 0x060B7A56u: goto L_060B7A56; case 0x060B7A58u: goto L_060B7A58; default: sh2_call(c, x); return; } }  // 060B7A04 jmp @r0 ; mov.l @r9+,r5
L_060B7A08:
    c.r[3] = ld32(c.r[3]);  // 060B7A08 mov.l @(0,r3),r3
L_060B7A0A:
    c.r[2] = c.r[5];  // 060B7A0A mov r5,r2
L_060B7A0C:
    c.r[4] = ld32(c.r[4]);  // 060B7A0C mov.l @(0,r4),r4
L_060B7A0E:
    c.r[5] = ld32(c.r[9]); c.r[9] += 4;  // 060B7A0E mov.l @r9+,r5
L_060B7A10:
    st32(c.r[11] + 12, c.r[1]);  // 060B7A10 mov.l r1,@(12,r11)
L_060B7A12:
    st32(c.r[11] + 16, c.r[2]);  // 060B7A12 mov.l r2,@(16,r11)
L_060B7A14:
    st32(c.r[11] + 20, c.r[3]);  // 060B7A14 mov.l r3,@(20,r11)
L_060B7A16:
    { const uint32_t x = c.r[5]; st32(c.r[11] + 24, c.r[4]); SH2_POLL(c); switch (x) { case 0x060B7958u: goto L_060B7958; case 0x060B795Au: goto L_060B795A; case 0x060B795Cu: goto L_060B795C; case 0x060B795Eu: goto L_060B795E; case 0x060B7960u: goto L_060B7960; case 0x060B7962u: goto L_060B7962; case 0x060B7966u: goto L_060B7966; case 0x060B7968u: goto L_060B7968; case 0x060B796Au: goto L_060B796A; case 0x060B796Cu: goto L_060B796C; case 0x060B7970u: goto L_060B7970; case 0x060B7972u: goto L_060B7972; case 0x060B7974u: goto L_060B7974; case 0x060B7976u: goto L_060B7976; case 0x060B797Au: goto L_060B797A; case 0x060B797Cu: goto L_060B797C; case 0x060B797Eu: goto L_060B797E; case 0x060B7980u: goto L_060B7980; case 0x060B7984u: goto L_060B7984; case 0x060B7986u: goto L_060B7986; case 0x060B7988u: goto L_060B7988; case 0x060B798Au: goto L_060B798A; case 0x060B798Eu: goto L_060B798E; case 0x060B7990u: goto L_060B7990; case 0x060B7992u: goto L_060B7992; case 0x060B7994u: goto L_060B7994; case 0x060B7996u: goto L_060B7996; case 0x060B7998u: goto L_060B7998; case 0x060B799Au: goto L_060B799A; case 0x060B799Cu: goto L_060B799C; case 0x060B799Eu: goto L_060B799E; case 0x060B79A0u: goto L_060B79A0; case 0x060B79A2u: goto L_060B79A2; case 0x060B79A4u: goto L_060B79A4; case 0x060B79A6u: goto L_060B79A6; case 0x060B79A8u: goto L_060B79A8; case 0x060B79AAu: goto L_060B79AA; case 0x060B79ACu: goto L_060B79AC; case 0x060B79AEu: goto L_060B79AE; case 0x060B79B0u: goto L_060B79B0; case 0x060B79B2u: goto L_060B79B2; case 0x060B79B4u: goto L_060B79B4; case 0x060B79B6u: goto L_060B79B6; case 0x060B79B8u: goto L_060B79B8; case 0x060B79BAu: goto L_060B79BA; case 0x060B79BCu: goto L_060B79BC; case 0x060B79BEu: goto L_060B79BE; case 0x060B79C0u: goto L_060B79C0; case 0x060B79C2u: goto L_060B79C2; case 0x060B79C4u: goto L_060B79C4; case 0x060B79C8u: goto L_060B79C8; case 0x060B79CAu: goto L_060B79CA; case 0x060B79CCu: goto L_060B79CC; case 0x060B79CEu: goto L_060B79CE; case 0x060B79D0u: goto L_060B79D0; case 0x060B79D2u: goto L_060B79D2; case 0x060B79D4u: goto L_060B79D4; case 0x060B79D6u: goto L_060B79D6; case 0x060B79D8u: goto L_060B79D8; case 0x060B79DAu: goto L_060B79DA; case 0x060B79DCu: goto L_060B79DC; case 0x060B79DEu: goto L_060B79DE; case 0x060B79E0u: goto L_060B79E0; case 0x060B79E2u: goto L_060B79E2; case 0x060B79E6u: goto L_060B79E6; case 0x060B79E8u: goto L_060B79E8; case 0x060B79EAu: goto L_060B79EA; case 0x060B79ECu: goto L_060B79EC; case 0x060B79EEu: goto L_060B79EE; case 0x060B79F0u: goto L_060B79F0; case 0x060B79F2u: goto L_060B79F2; case 0x060B79F4u: goto L_060B79F4; case 0x060B79F6u: goto L_060B79F6; case 0x060B79F8u: goto L_060B79F8; case 0x060B79FAu: goto L_060B79FA; case 0x060B79FCu: goto L_060B79FC; case 0x060B79FEu: goto L_060B79FE; case 0x060B7A00u: goto L_060B7A00; case 0x060B7A04u: goto L_060B7A04; case 0x060B7A08u: goto L_060B7A08; case 0x060B7A0Au: goto L_060B7A0A; case 0x060B7A0Cu: goto L_060B7A0C; case 0x060B7A0Eu: goto L_060B7A0E; case 0x060B7A10u: goto L_060B7A10; case 0x060B7A12u: goto L_060B7A12; case 0x060B7A14u: goto L_060B7A14; case 0x060B7A16u: goto L_060B7A16; case 0x060B7A1Eu: goto L_060B7A1E; case 0x060B7A20u: goto L_060B7A20; case 0x060B7A22u: goto L_060B7A22; case 0x060B7A24u: goto L_060B7A24; case 0x060B7A26u: goto L_060B7A26; case 0x060B7A28u: goto L_060B7A28; case 0x060B7A2Au: goto L_060B7A2A; case 0x060B7A2Cu: goto L_060B7A2C; case 0x060B7A2Eu: goto L_060B7A2E; case 0x060B7A30u: goto L_060B7A30; case 0x060B7A34u: goto L_060B7A34; case 0x060B7A36u: goto L_060B7A36; case 0x060B7A38u: goto L_060B7A38; case 0x060B7A3Au: goto L_060B7A3A; case 0x060B7A3Cu: goto L_060B7A3C; case 0x060B7A3Eu: goto L_060B7A3E; case 0x060B7A40u: goto L_060B7A40; case 0x060B7A42u: goto L_060B7A42; case 0x060B7A44u: goto L_060B7A44; case 0x060B7A4Au: goto L_060B7A4A; case 0x060B7A4Cu: goto L_060B7A4C; case 0x060B7A4Eu: goto L_060B7A4E; case 0x060B7A50u: goto L_060B7A50; case 0x060B7A52u: goto L_060B7A52; case 0x060B7A54u: goto L_060B7A54; case 0x060B7A56u: goto L_060B7A56; case 0x060B7A58u: goto L_060B7A58; default: sh2_call(c, x); return; } }  // 060B7A16 jmp @r5 ; mov.l r4,@(24,r11)
L_060B7A1E:
    c.r[4] = ld32(c.r[4]);  // 060B7A1E mov.l @(0,r4),r4
L_060B7A20:
    c.r[3] = c.r[5];  // 060B7A20 mov r5,r3
L_060B7A22:
    c.r[5] = ld32(c.r[9]); c.r[9] += 4;  // 060B7A22 mov.l @r9+,r5
L_060B7A24:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[11]);  // 060B7A24 mov.w @(0,r11),r0
L_060B7A26:
    st32(c.r[11] + 16, c.r[1]);  // 060B7A26 mov.l r1,@(16,r11)
L_060B7A28:
    c.r[0] ^= 0x10u;  // 060B7A28 xor #16,r0
L_060B7A2A:
    st16(c.r[11], c.r[0]);  // 060B7A2A mov.w r0,@(0,r11)
L_060B7A2C:
    st32(c.r[11] + 12, c.r[2]);  // 060B7A2C mov.l r2,@(12,r11)
L_060B7A2E:
    st32(c.r[11] + 24, c.r[3]);  // 060B7A2E mov.l r3,@(24,r11)
L_060B7A30:
    { const uint32_t x = c.r[5]; st32(c.r[11] + 20, c.r[4]); SH2_POLL(c); switch (x) { case 0x060B7958u: goto L_060B7958; case 0x060B795Au: goto L_060B795A; case 0x060B795Cu: goto L_060B795C; case 0x060B795Eu: goto L_060B795E; case 0x060B7960u: goto L_060B7960; case 0x060B7962u: goto L_060B7962; case 0x060B7966u: goto L_060B7966; case 0x060B7968u: goto L_060B7968; case 0x060B796Au: goto L_060B796A; case 0x060B796Cu: goto L_060B796C; case 0x060B7970u: goto L_060B7970; case 0x060B7972u: goto L_060B7972; case 0x060B7974u: goto L_060B7974; case 0x060B7976u: goto L_060B7976; case 0x060B797Au: goto L_060B797A; case 0x060B797Cu: goto L_060B797C; case 0x060B797Eu: goto L_060B797E; case 0x060B7980u: goto L_060B7980; case 0x060B7984u: goto L_060B7984; case 0x060B7986u: goto L_060B7986; case 0x060B7988u: goto L_060B7988; case 0x060B798Au: goto L_060B798A; case 0x060B798Eu: goto L_060B798E; case 0x060B7990u: goto L_060B7990; case 0x060B7992u: goto L_060B7992; case 0x060B7994u: goto L_060B7994; case 0x060B7996u: goto L_060B7996; case 0x060B7998u: goto L_060B7998; case 0x060B799Au: goto L_060B799A; case 0x060B799Cu: goto L_060B799C; case 0x060B799Eu: goto L_060B799E; case 0x060B79A0u: goto L_060B79A0; case 0x060B79A2u: goto L_060B79A2; case 0x060B79A4u: goto L_060B79A4; case 0x060B79A6u: goto L_060B79A6; case 0x060B79A8u: goto L_060B79A8; case 0x060B79AAu: goto L_060B79AA; case 0x060B79ACu: goto L_060B79AC; case 0x060B79AEu: goto L_060B79AE; case 0x060B79B0u: goto L_060B79B0; case 0x060B79B2u: goto L_060B79B2; case 0x060B79B4u: goto L_060B79B4; case 0x060B79B6u: goto L_060B79B6; case 0x060B79B8u: goto L_060B79B8; case 0x060B79BAu: goto L_060B79BA; case 0x060B79BCu: goto L_060B79BC; case 0x060B79BEu: goto L_060B79BE; case 0x060B79C0u: goto L_060B79C0; case 0x060B79C2u: goto L_060B79C2; case 0x060B79C4u: goto L_060B79C4; case 0x060B79C8u: goto L_060B79C8; case 0x060B79CAu: goto L_060B79CA; case 0x060B79CCu: goto L_060B79CC; case 0x060B79CEu: goto L_060B79CE; case 0x060B79D0u: goto L_060B79D0; case 0x060B79D2u: goto L_060B79D2; case 0x060B79D4u: goto L_060B79D4; case 0x060B79D6u: goto L_060B79D6; case 0x060B79D8u: goto L_060B79D8; case 0x060B79DAu: goto L_060B79DA; case 0x060B79DCu: goto L_060B79DC; case 0x060B79DEu: goto L_060B79DE; case 0x060B79E0u: goto L_060B79E0; case 0x060B79E2u: goto L_060B79E2; case 0x060B79E6u: goto L_060B79E6; case 0x060B79E8u: goto L_060B79E8; case 0x060B79EAu: goto L_060B79EA; case 0x060B79ECu: goto L_060B79EC; case 0x060B79EEu: goto L_060B79EE; case 0x060B79F0u: goto L_060B79F0; case 0x060B79F2u: goto L_060B79F2; case 0x060B79F4u: goto L_060B79F4; case 0x060B79F6u: goto L_060B79F6; case 0x060B79F8u: goto L_060B79F8; case 0x060B79FAu: goto L_060B79FA; case 0x060B79FCu: goto L_060B79FC; case 0x060B79FEu: goto L_060B79FE; case 0x060B7A00u: goto L_060B7A00; case 0x060B7A04u: goto L_060B7A04; case 0x060B7A08u: goto L_060B7A08; case 0x060B7A0Au: goto L_060B7A0A; case 0x060B7A0Cu: goto L_060B7A0C; case 0x060B7A0Eu: goto L_060B7A0E; case 0x060B7A10u: goto L_060B7A10; case 0x060B7A12u: goto L_060B7A12; case 0x060B7A14u: goto L_060B7A14; case 0x060B7A16u: goto L_060B7A16; case 0x060B7A1Eu: goto L_060B7A1E; case 0x060B7A20u: goto L_060B7A20; case 0x060B7A22u: goto L_060B7A22; case 0x060B7A24u: goto L_060B7A24; case 0x060B7A26u: goto L_060B7A26; case 0x060B7A28u: goto L_060B7A28; case 0x060B7A2Au: goto L_060B7A2A; case 0x060B7A2Cu: goto L_060B7A2C; case 0x060B7A2Eu: goto L_060B7A2E; case 0x060B7A30u: goto L_060B7A30; case 0x060B7A34u: goto L_060B7A34; case 0x060B7A36u: goto L_060B7A36; case 0x060B7A38u: goto L_060B7A38; case 0x060B7A3Au: goto L_060B7A3A; case 0x060B7A3Cu: goto L_060B7A3C; case 0x060B7A3Eu: goto L_060B7A3E; case 0x060B7A40u: goto L_060B7A40; case 0x060B7A42u: goto L_060B7A42; case 0x060B7A44u: goto L_060B7A44; case 0x060B7A4Au: goto L_060B7A4A; case 0x060B7A4Cu: goto L_060B7A4C; case 0x060B7A4Eu: goto L_060B7A4E; case 0x060B7A50u: goto L_060B7A50; case 0x060B7A52u: goto L_060B7A52; case 0x060B7A54u: goto L_060B7A54; case 0x060B7A56u: goto L_060B7A56; case 0x060B7A58u: goto L_060B7A58; default: sh2_call(c, x); return; } }  // 060B7A30 jmp @r5 ; mov.l r4,@(20,r11)
L_060B7A34:
    c.r[4] = c.r[5];  // 060B7A34 mov r5,r4
L_060B7A36:
    c.r[5] = ld32(c.r[9]); c.r[9] += 4;  // 060B7A36 mov.l @r9+,r5
L_060B7A38:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[11]);  // 060B7A38 mov.w @(0,r11),r0
L_060B7A3A:
    st32(c.r[11] + 20, c.r[1]);  // 060B7A3A mov.l r1,@(20,r11)
L_060B7A3C:
    c.r[0] ^= 0x30u;  // 060B7A3C xor #48,r0
L_060B7A3E:
    st16(c.r[11], c.r[0]);  // 060B7A3E mov.w r0,@(0,r11)
L_060B7A40:
    st32(c.r[11] + 24, c.r[2]);  // 060B7A40 mov.l r2,@(24,r11)
L_060B7A42:
    st32(c.r[11] + 12, c.r[3]);  // 060B7A42 mov.l r3,@(12,r11)
L_060B7A44:
    { const uint32_t x = c.r[5]; st32(c.r[11] + 16, c.r[4]); SH2_POLL(c); switch (x) { case 0x060B7958u: goto L_060B7958; case 0x060B795Au: goto L_060B795A; case 0x060B795Cu: goto L_060B795C; case 0x060B795Eu: goto L_060B795E; case 0x060B7960u: goto L_060B7960; case 0x060B7962u: goto L_060B7962; case 0x060B7966u: goto L_060B7966; case 0x060B7968u: goto L_060B7968; case 0x060B796Au: goto L_060B796A; case 0x060B796Cu: goto L_060B796C; case 0x060B7970u: goto L_060B7970; case 0x060B7972u: goto L_060B7972; case 0x060B7974u: goto L_060B7974; case 0x060B7976u: goto L_060B7976; case 0x060B797Au: goto L_060B797A; case 0x060B797Cu: goto L_060B797C; case 0x060B797Eu: goto L_060B797E; case 0x060B7980u: goto L_060B7980; case 0x060B7984u: goto L_060B7984; case 0x060B7986u: goto L_060B7986; case 0x060B7988u: goto L_060B7988; case 0x060B798Au: goto L_060B798A; case 0x060B798Eu: goto L_060B798E; case 0x060B7990u: goto L_060B7990; case 0x060B7992u: goto L_060B7992; case 0x060B7994u: goto L_060B7994; case 0x060B7996u: goto L_060B7996; case 0x060B7998u: goto L_060B7998; case 0x060B799Au: goto L_060B799A; case 0x060B799Cu: goto L_060B799C; case 0x060B799Eu: goto L_060B799E; case 0x060B79A0u: goto L_060B79A0; case 0x060B79A2u: goto L_060B79A2; case 0x060B79A4u: goto L_060B79A4; case 0x060B79A6u: goto L_060B79A6; case 0x060B79A8u: goto L_060B79A8; case 0x060B79AAu: goto L_060B79AA; case 0x060B79ACu: goto L_060B79AC; case 0x060B79AEu: goto L_060B79AE; case 0x060B79B0u: goto L_060B79B0; case 0x060B79B2u: goto L_060B79B2; case 0x060B79B4u: goto L_060B79B4; case 0x060B79B6u: goto L_060B79B6; case 0x060B79B8u: goto L_060B79B8; case 0x060B79BAu: goto L_060B79BA; case 0x060B79BCu: goto L_060B79BC; case 0x060B79BEu: goto L_060B79BE; case 0x060B79C0u: goto L_060B79C0; case 0x060B79C2u: goto L_060B79C2; case 0x060B79C4u: goto L_060B79C4; case 0x060B79C8u: goto L_060B79C8; case 0x060B79CAu: goto L_060B79CA; case 0x060B79CCu: goto L_060B79CC; case 0x060B79CEu: goto L_060B79CE; case 0x060B79D0u: goto L_060B79D0; case 0x060B79D2u: goto L_060B79D2; case 0x060B79D4u: goto L_060B79D4; case 0x060B79D6u: goto L_060B79D6; case 0x060B79D8u: goto L_060B79D8; case 0x060B79DAu: goto L_060B79DA; case 0x060B79DCu: goto L_060B79DC; case 0x060B79DEu: goto L_060B79DE; case 0x060B79E0u: goto L_060B79E0; case 0x060B79E2u: goto L_060B79E2; case 0x060B79E6u: goto L_060B79E6; case 0x060B79E8u: goto L_060B79E8; case 0x060B79EAu: goto L_060B79EA; case 0x060B79ECu: goto L_060B79EC; case 0x060B79EEu: goto L_060B79EE; case 0x060B79F0u: goto L_060B79F0; case 0x060B79F2u: goto L_060B79F2; case 0x060B79F4u: goto L_060B79F4; case 0x060B79F6u: goto L_060B79F6; case 0x060B79F8u: goto L_060B79F8; case 0x060B79FAu: goto L_060B79FA; case 0x060B79FCu: goto L_060B79FC; case 0x060B79FEu: goto L_060B79FE; case 0x060B7A00u: goto L_060B7A00; case 0x060B7A04u: goto L_060B7A04; case 0x060B7A08u: goto L_060B7A08; case 0x060B7A0Au: goto L_060B7A0A; case 0x060B7A0Cu: goto L_060B7A0C; case 0x060B7A0Eu: goto L_060B7A0E; case 0x060B7A10u: goto L_060B7A10; case 0x060B7A12u: goto L_060B7A12; case 0x060B7A14u: goto L_060B7A14; case 0x060B7A16u: goto L_060B7A16; case 0x060B7A1Eu: goto L_060B7A1E; case 0x060B7A20u: goto L_060B7A20; case 0x060B7A22u: goto L_060B7A22; case 0x060B7A24u: goto L_060B7A24; case 0x060B7A26u: goto L_060B7A26; case 0x060B7A28u: goto L_060B7A28; case 0x060B7A2Au: goto L_060B7A2A; case 0x060B7A2Cu: goto L_060B7A2C; case 0x060B7A2Eu: goto L_060B7A2E; case 0x060B7A30u: goto L_060B7A30; case 0x060B7A34u: goto L_060B7A34; case 0x060B7A36u: goto L_060B7A36; case 0x060B7A38u: goto L_060B7A38; case 0x060B7A3Au: goto L_060B7A3A; case 0x060B7A3Cu: goto L_060B7A3C; case 0x060B7A3Eu: goto L_060B7A3E; case 0x060B7A40u: goto L_060B7A40; case 0x060B7A42u: goto L_060B7A42; case 0x060B7A44u: goto L_060B7A44; case 0x060B7A4Au: goto L_060B7A4A; case 0x060B7A4Cu: goto L_060B7A4C; case 0x060B7A4Eu: goto L_060B7A4E; case 0x060B7A50u: goto L_060B7A50; case 0x060B7A52u: goto L_060B7A52; case 0x060B7A54u: goto L_060B7A54; case 0x060B7A56u: goto L_060B7A56; case 0x060B7A58u: goto L_060B7A58; default: sh2_call(c, x); return; } }  // 060B7A44 jmp @r5 ; mov.l r4,@(16,r11)
L_060B7A4A:
    c.r[5] = ld32(c.r[9]); c.r[9] += 4;  // 060B7A4A mov.l @r9+,r5
L_060B7A4C:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[11]);  // 060B7A4C mov.w @(0,r11),r0
L_060B7A4E:
    st32(c.r[11] + 24, c.r[1]);  // 060B7A4E mov.l r1,@(24,r11)
L_060B7A50:
    c.r[0] ^= 0x20u;  // 060B7A50 xor #32,r0
L_060B7A52:
    st16(c.r[11], c.r[0]);  // 060B7A52 mov.w r0,@(0,r11)
L_060B7A54:
    st32(c.r[11] + 20, c.r[2]);  // 060B7A54 mov.l r2,@(20,r11)
L_060B7A56:
    st32(c.r[11] + 16, c.r[3]);  // 060B7A56 mov.l r3,@(16,r11)
L_060B7A58:
    { const uint32_t x = c.r[5]; st32(c.r[11] + 12, c.r[4]); SH2_POLL(c); switch (x) { case 0x060B7958u: goto L_060B7958; case 0x060B795Au: goto L_060B795A; case 0x060B795Cu: goto L_060B795C; case 0x060B795Eu: goto L_060B795E; case 0x060B7960u: goto L_060B7960; case 0x060B7962u: goto L_060B7962; case 0x060B7966u: goto L_060B7966; case 0x060B7968u: goto L_060B7968; case 0x060B796Au: goto L_060B796A; case 0x060B796Cu: goto L_060B796C; case 0x060B7970u: goto L_060B7970; case 0x060B7972u: goto L_060B7972; case 0x060B7974u: goto L_060B7974; case 0x060B7976u: goto L_060B7976; case 0x060B797Au: goto L_060B797A; case 0x060B797Cu: goto L_060B797C; case 0x060B797Eu: goto L_060B797E; case 0x060B7980u: goto L_060B7980; case 0x060B7984u: goto L_060B7984; case 0x060B7986u: goto L_060B7986; case 0x060B7988u: goto L_060B7988; case 0x060B798Au: goto L_060B798A; case 0x060B798Eu: goto L_060B798E; case 0x060B7990u: goto L_060B7990; case 0x060B7992u: goto L_060B7992; case 0x060B7994u: goto L_060B7994; case 0x060B7996u: goto L_060B7996; case 0x060B7998u: goto L_060B7998; case 0x060B799Au: goto L_060B799A; case 0x060B799Cu: goto L_060B799C; case 0x060B799Eu: goto L_060B799E; case 0x060B79A0u: goto L_060B79A0; case 0x060B79A2u: goto L_060B79A2; case 0x060B79A4u: goto L_060B79A4; case 0x060B79A6u: goto L_060B79A6; case 0x060B79A8u: goto L_060B79A8; case 0x060B79AAu: goto L_060B79AA; case 0x060B79ACu: goto L_060B79AC; case 0x060B79AEu: goto L_060B79AE; case 0x060B79B0u: goto L_060B79B0; case 0x060B79B2u: goto L_060B79B2; case 0x060B79B4u: goto L_060B79B4; case 0x060B79B6u: goto L_060B79B6; case 0x060B79B8u: goto L_060B79B8; case 0x060B79BAu: goto L_060B79BA; case 0x060B79BCu: goto L_060B79BC; case 0x060B79BEu: goto L_060B79BE; case 0x060B79C0u: goto L_060B79C0; case 0x060B79C2u: goto L_060B79C2; case 0x060B79C4u: goto L_060B79C4; case 0x060B79C8u: goto L_060B79C8; case 0x060B79CAu: goto L_060B79CA; case 0x060B79CCu: goto L_060B79CC; case 0x060B79CEu: goto L_060B79CE; case 0x060B79D0u: goto L_060B79D0; case 0x060B79D2u: goto L_060B79D2; case 0x060B79D4u: goto L_060B79D4; case 0x060B79D6u: goto L_060B79D6; case 0x060B79D8u: goto L_060B79D8; case 0x060B79DAu: goto L_060B79DA; case 0x060B79DCu: goto L_060B79DC; case 0x060B79DEu: goto L_060B79DE; case 0x060B79E0u: goto L_060B79E0; case 0x060B79E2u: goto L_060B79E2; case 0x060B79E6u: goto L_060B79E6; case 0x060B79E8u: goto L_060B79E8; case 0x060B79EAu: goto L_060B79EA; case 0x060B79ECu: goto L_060B79EC; case 0x060B79EEu: goto L_060B79EE; case 0x060B79F0u: goto L_060B79F0; case 0x060B79F2u: goto L_060B79F2; case 0x060B79F4u: goto L_060B79F4; case 0x060B79F6u: goto L_060B79F6; case 0x060B79F8u: goto L_060B79F8; case 0x060B79FAu: goto L_060B79FA; case 0x060B79FCu: goto L_060B79FC; case 0x060B79FEu: goto L_060B79FE; case 0x060B7A00u: goto L_060B7A00; case 0x060B7A04u: goto L_060B7A04; case 0x060B7A08u: goto L_060B7A08; case 0x060B7A0Au: goto L_060B7A0A; case 0x060B7A0Cu: goto L_060B7A0C; case 0x060B7A0Eu: goto L_060B7A0E; case 0x060B7A10u: goto L_060B7A10; case 0x060B7A12u: goto L_060B7A12; case 0x060B7A14u: goto L_060B7A14; case 0x060B7A16u: goto L_060B7A16; case 0x060B7A1Eu: goto L_060B7A1E; case 0x060B7A20u: goto L_060B7A20; case 0x060B7A22u: goto L_060B7A22; case 0x060B7A24u: goto L_060B7A24; case 0x060B7A26u: goto L_060B7A26; case 0x060B7A28u: goto L_060B7A28; case 0x060B7A2Au: goto L_060B7A2A; case 0x060B7A2Cu: goto L_060B7A2C; case 0x060B7A2Eu: goto L_060B7A2E; case 0x060B7A30u: goto L_060B7A30; case 0x060B7A34u: goto L_060B7A34; case 0x060B7A36u: goto L_060B7A36; case 0x060B7A38u: goto L_060B7A38; case 0x060B7A3Au: goto L_060B7A3A; case 0x060B7A3Cu: goto L_060B7A3C; case 0x060B7A3Eu: goto L_060B7A3E; case 0x060B7A40u: goto L_060B7A40; case 0x060B7A42u: goto L_060B7A42; case 0x060B7A44u: goto L_060B7A44; case 0x060B7A4Au: goto L_060B7A4A; case 0x060B7A4Cu: goto L_060B7A4C; case 0x060B7A4Eu: goto L_060B7A4E; case 0x060B7A50u: goto L_060B7A50; case 0x060B7A52u: goto L_060B7A52; case 0x060B7A54u: goto L_060B7A54; case 0x060B7A56u: goto L_060B7A56; case 0x060B7A58u: goto L_060B7A58; default: sh2_call(c, x); return; } }  // 060B7A58 jmp @r5 ; mov.l r4,@(12,r11)
}

void f_060B7990(SH2Context& c) {
    ran[3140] = 1;
L_060B7990:
    c.r[5] <<= 16;  // 060B7990 shll16 r5
L_060B7992:
    c.t = c.r[5] & 1; c.r[5] >>= 1;  // 060B7992 shlr r5
L_060B7994:
    c.r[9] = c.r[4] << 16 | c.r[4] >> 16;  // 060B7994 swap.w r4,r9
L_060B7996:
    c.t = (c.r[9] & c.r[5]) == 0;  // 060B7996 tst r5,r9
L_060B7998:
    { uint32_t a = c.r[13], b = c.r[13], t = c.t; c.r[13] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B7998 subc r13,r13
L_060B799A:
    c.r[13] = ~c.r[13];  // 060B799A not r13,r13
L_060B799C:
    c.r[13] ^= c.r[9];  // 060B799C xor r9,r13
L_060B799E:
    c.t = (c.r[4] & c.r[5]) == 0;  // 060B799E tst r5,r4
L_060B79A0:
    { uint32_t a = c.r[9], b = c.r[9], t = c.t; c.r[9] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B79A0 subc r9,r9
L_060B79A2:
    c.r[9] = ~c.r[9];  // 060B79A2 not r9,r9
L_060B79A4:
    c.r[9] ^= c.r[4];  // 060B79A4 xor r4,r9
L_060B79A6:
    c.r[13] += c.r[9];  // 060B79A6 add r9,r13
L_060B79A8:
    c.r[13] = c.r[13] & 0xFFFFu;  // 060B79A8 extu.w r13,r13
L_060B79AA:
    c.r[0] = 0x060B7A4Cu;  // 060B79AA mova 0x060B7A4C,r0
L_060B79AC:
    c.r[9] = c.r[3] << 16 | c.r[3] >> 16;  // 060B79AC swap.w r3,r9
L_060B79AE:
    c.t = (c.r[9] & c.r[5]) == 0;  // 060B79AE tst r5,r9
L_060B79B0:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B79B0 subc r12,r12
L_060B79B2:
    c.r[12] = ~c.r[12];  // 060B79B2 not r12,r12
L_060B79B4:
    c.r[12] ^= c.r[9];  // 060B79B4 xor r9,r12
L_060B79B6:
    c.t = (c.r[3] & c.r[5]) == 0;  // 060B79B6 tst r5,r3
L_060B79B8:
    { uint32_t a = c.r[9], b = c.r[9], t = c.t; c.r[9] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B79B8 subc r9,r9
L_060B79BA:
    c.r[9] = ~c.r[9];  // 060B79BA not r9,r9
L_060B79BC:
    c.r[9] ^= c.r[3];  // 060B79BC xor r3,r9
L_060B79BE:
    c.r[12] += c.r[9];  // 060B79BE add r9,r12
L_060B79C0:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B79C0 extu.w r12,r12
L_060B79C2:
    c.t = (int32_t)c.r[12] > (int32_t)c.r[13];  // 060B79C2 cmp/gt r13,r12
L_060B79C4:
    { const bool k = c.t; c.r[9] = c.r[2] << 16 | c.r[2] >> 16; if (k) { goto L_060B79CC; } }  // 060B79C4 bt/s 0x060B79CC ; swap.w r2,r9
L_060B79C8:
    c.r[13] = c.r[12];  // 060B79C8 mov r12,r13
L_060B79CA:
    c.r[0] = 0x060B7A38u;  // 060B79CA mova 0x060B7A38,r0
L_060B79CC:
    c.t = (c.r[9] & c.r[5]) == 0;  // 060B79CC tst r5,r9
L_060B79CE:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B79CE subc r12,r12
L_060B79D0:
    c.r[12] = ~c.r[12];  // 060B79D0 not r12,r12
L_060B79D2:
    c.r[12] ^= c.r[9];  // 060B79D2 xor r9,r12
L_060B79D4:
    c.t = (c.r[2] & c.r[5]) == 0;  // 060B79D4 tst r5,r2
L_060B79D6:
    { uint32_t a = c.r[9], b = c.r[9], t = c.t; c.r[9] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B79D6 subc r9,r9
L_060B79D8:
    c.r[9] = ~c.r[9];  // 060B79D8 not r9,r9
L_060B79DA:
    c.r[9] ^= c.r[2];  // 060B79DA xor r2,r9
L_060B79DC:
    c.r[12] += c.r[9];  // 060B79DC add r9,r12
L_060B79DE:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B79DE extu.w r12,r12
L_060B79E0:
    c.t = (int32_t)c.r[12] > (int32_t)c.r[13];  // 060B79E0 cmp/gt r13,r12
L_060B79E2:
    { const bool k = c.t; c.r[9] = c.r[1] << 16 | c.r[1] >> 16; if (k) { goto L_060B79EA; } }  // 060B79E2 bt/s 0x060B79EA ; swap.w r1,r9
L_060B79E6:
    c.r[13] = c.r[12];  // 060B79E6 mov r12,r13
L_060B79E8:
    c.r[0] = 0x060B7A24u;  // 060B79E8 mova 0x060B7A24,r0
L_060B79EA:
    c.t = (c.r[9] & c.r[5]) == 0;  // 060B79EA tst r5,r9
L_060B79EC:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B79EC subc r12,r12
L_060B79EE:
    c.r[12] = ~c.r[12];  // 060B79EE not r12,r12
L_060B79F0:
    c.r[12] ^= c.r[9];  // 060B79F0 xor r9,r12
L_060B79F2:
    c.t = (c.r[1] & c.r[5]) == 0;  // 060B79F2 tst r5,r1
L_060B79F4:
    { uint32_t a = c.r[9], b = c.r[9], t = c.t; c.r[9] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B79F4 subc r9,r9
L_060B79F6:
    c.r[9] = ~c.r[9];  // 060B79F6 not r9,r9
L_060B79F8:
    c.r[9] ^= c.r[1];  // 060B79F8 xor r1,r9
L_060B79FA:
    c.r[12] += c.r[9];  // 060B79FA add r9,r12
L_060B79FC:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B79FC extu.w r12,r12
L_060B79FE:
    c.t = (int32_t)c.r[13] >= (int32_t)c.r[12];  // 060B79FE cmp/ge r12,r13
L_060B7A00:
    { const bool k = c.t; c.r[9] = ld32(c.r[15]); c.r[15] += 4; if (k) { goto L_060B7A0E; } }  // 060B7A00 bt/s 0x060B7A0E ; mov.l @r15+,r9
L_060B7A04:
    { const uint32_t x = c.r[0]; c.r[5] = ld32(c.r[9]); c.r[9] += 4; SH2_POLL(c); switch (x) { case 0x060B7990u: goto L_060B7990; case 0x060B7992u: goto L_060B7992; case 0x060B7994u: goto L_060B7994; case 0x060B7996u: goto L_060B7996; case 0x060B7998u: goto L_060B7998; case 0x060B799Au: goto L_060B799A; case 0x060B799Cu: goto L_060B799C; case 0x060B799Eu: goto L_060B799E; case 0x060B79A0u: goto L_060B79A0; case 0x060B79A2u: goto L_060B79A2; case 0x060B79A4u: goto L_060B79A4; case 0x060B79A6u: goto L_060B79A6; case 0x060B79A8u: goto L_060B79A8; case 0x060B79AAu: goto L_060B79AA; case 0x060B79ACu: goto L_060B79AC; case 0x060B79AEu: goto L_060B79AE; case 0x060B79B0u: goto L_060B79B0; case 0x060B79B2u: goto L_060B79B2; case 0x060B79B4u: goto L_060B79B4; case 0x060B79B6u: goto L_060B79B6; case 0x060B79B8u: goto L_060B79B8; case 0x060B79BAu: goto L_060B79BA; case 0x060B79BCu: goto L_060B79BC; case 0x060B79BEu: goto L_060B79BE; case 0x060B79C0u: goto L_060B79C0; case 0x060B79C2u: goto L_060B79C2; case 0x060B79C4u: goto L_060B79C4; case 0x060B79C8u: goto L_060B79C8; case 0x060B79CAu: goto L_060B79CA; case 0x060B79CCu: goto L_060B79CC; case 0x060B79CEu: goto L_060B79CE; case 0x060B79D0u: goto L_060B79D0; case 0x060B79D2u: goto L_060B79D2; case 0x060B79D4u: goto L_060B79D4; case 0x060B79D6u: goto L_060B79D6; case 0x060B79D8u: goto L_060B79D8; case 0x060B79DAu: goto L_060B79DA; case 0x060B79DCu: goto L_060B79DC; case 0x060B79DEu: goto L_060B79DE; case 0x060B79E0u: goto L_060B79E0; case 0x060B79E2u: goto L_060B79E2; case 0x060B79E6u: goto L_060B79E6; case 0x060B79E8u: goto L_060B79E8; case 0x060B79EAu: goto L_060B79EA; case 0x060B79ECu: goto L_060B79EC; case 0x060B79EEu: goto L_060B79EE; case 0x060B79F0u: goto L_060B79F0; case 0x060B79F2u: goto L_060B79F2; case 0x060B79F4u: goto L_060B79F4; case 0x060B79F6u: goto L_060B79F6; case 0x060B79F8u: goto L_060B79F8; case 0x060B79FAu: goto L_060B79FA; case 0x060B79FCu: goto L_060B79FC; case 0x060B79FEu: goto L_060B79FE; case 0x060B7A00u: goto L_060B7A00; case 0x060B7A04u: goto L_060B7A04; case 0x060B7A0Eu: goto L_060B7A0E; case 0x060B7A10u: goto L_060B7A10; case 0x060B7A12u: goto L_060B7A12; case 0x060B7A14u: goto L_060B7A14; case 0x060B7A16u: goto L_060B7A16; default: sh2_call(c, x); return; } }  // 060B7A04 jmp @r0 ; mov.l @r9+,r5
L_060B7A0E:
    c.r[5] = ld32(c.r[9]); c.r[9] += 4;  // 060B7A0E mov.l @r9+,r5
L_060B7A10:
    st32(c.r[11] + 12, c.r[1]);  // 060B7A10 mov.l r1,@(12,r11)
L_060B7A12:
    st32(c.r[11] + 16, c.r[2]);  // 060B7A12 mov.l r2,@(16,r11)
L_060B7A14:
    st32(c.r[11] + 20, c.r[3]);  // 060B7A14 mov.l r3,@(20,r11)
L_060B7A16:
    { const uint32_t x = c.r[5]; st32(c.r[11] + 24, c.r[4]); SH2_POLL(c); switch (x) { case 0x060B7990u: goto L_060B7990; case 0x060B7992u: goto L_060B7992; case 0x060B7994u: goto L_060B7994; case 0x060B7996u: goto L_060B7996; case 0x060B7998u: goto L_060B7998; case 0x060B799Au: goto L_060B799A; case 0x060B799Cu: goto L_060B799C; case 0x060B799Eu: goto L_060B799E; case 0x060B79A0u: goto L_060B79A0; case 0x060B79A2u: goto L_060B79A2; case 0x060B79A4u: goto L_060B79A4; case 0x060B79A6u: goto L_060B79A6; case 0x060B79A8u: goto L_060B79A8; case 0x060B79AAu: goto L_060B79AA; case 0x060B79ACu: goto L_060B79AC; case 0x060B79AEu: goto L_060B79AE; case 0x060B79B0u: goto L_060B79B0; case 0x060B79B2u: goto L_060B79B2; case 0x060B79B4u: goto L_060B79B4; case 0x060B79B6u: goto L_060B79B6; case 0x060B79B8u: goto L_060B79B8; case 0x060B79BAu: goto L_060B79BA; case 0x060B79BCu: goto L_060B79BC; case 0x060B79BEu: goto L_060B79BE; case 0x060B79C0u: goto L_060B79C0; case 0x060B79C2u: goto L_060B79C2; case 0x060B79C4u: goto L_060B79C4; case 0x060B79C8u: goto L_060B79C8; case 0x060B79CAu: goto L_060B79CA; case 0x060B79CCu: goto L_060B79CC; case 0x060B79CEu: goto L_060B79CE; case 0x060B79D0u: goto L_060B79D0; case 0x060B79D2u: goto L_060B79D2; case 0x060B79D4u: goto L_060B79D4; case 0x060B79D6u: goto L_060B79D6; case 0x060B79D8u: goto L_060B79D8; case 0x060B79DAu: goto L_060B79DA; case 0x060B79DCu: goto L_060B79DC; case 0x060B79DEu: goto L_060B79DE; case 0x060B79E0u: goto L_060B79E0; case 0x060B79E2u: goto L_060B79E2; case 0x060B79E6u: goto L_060B79E6; case 0x060B79E8u: goto L_060B79E8; case 0x060B79EAu: goto L_060B79EA; case 0x060B79ECu: goto L_060B79EC; case 0x060B79EEu: goto L_060B79EE; case 0x060B79F0u: goto L_060B79F0; case 0x060B79F2u: goto L_060B79F2; case 0x060B79F4u: goto L_060B79F4; case 0x060B79F6u: goto L_060B79F6; case 0x060B79F8u: goto L_060B79F8; case 0x060B79FAu: goto L_060B79FA; case 0x060B79FCu: goto L_060B79FC; case 0x060B79FEu: goto L_060B79FE; case 0x060B7A00u: goto L_060B7A00; case 0x060B7A04u: goto L_060B7A04; case 0x060B7A0Eu: goto L_060B7A0E; case 0x060B7A10u: goto L_060B7A10; case 0x060B7A12u: goto L_060B7A12; case 0x060B7A14u: goto L_060B7A14; case 0x060B7A16u: goto L_060B7A16; default: sh2_call(c, x); return; } }  // 060B7A16 jmp @r5 ; mov.l r4,@(24,r11)
}

void f_060B7A48(SH2Context& c) {
    ran[3141] = 1;
L_060B7A48:
    c.r[15] += 4;  // 060B7A48 add #4,r15
L_060B7A4A:
    c.r[5] = ld32(c.r[9]); c.r[9] += 4;  // 060B7A4A mov.l @r9+,r5
L_060B7A4C:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[11]);  // 060B7A4C mov.w @(0,r11),r0
L_060B7A4E:
    st32(c.r[11] + 24, c.r[1]);  // 060B7A4E mov.l r1,@(24,r11)
L_060B7A50:
    c.r[0] ^= 0x20u;  // 060B7A50 xor #32,r0
L_060B7A52:
    st16(c.r[11], c.r[0]);  // 060B7A52 mov.w r0,@(0,r11)
L_060B7A54:
    st32(c.r[11] + 20, c.r[2]);  // 060B7A54 mov.l r2,@(20,r11)
L_060B7A56:
    st32(c.r[11] + 16, c.r[3]);  // 060B7A56 mov.l r3,@(16,r11)
L_060B7A58:
    { const uint32_t x = c.r[5]; st32(c.r[11] + 12, c.r[4]); SH2_POLL(c); switch (x) { case 0x060B7A48u: goto L_060B7A48; case 0x060B7A4Au: goto L_060B7A4A; case 0x060B7A4Cu: goto L_060B7A4C; case 0x060B7A4Eu: goto L_060B7A4E; case 0x060B7A50u: goto L_060B7A50; case 0x060B7A52u: goto L_060B7A52; case 0x060B7A54u: goto L_060B7A54; case 0x060B7A56u: goto L_060B7A56; case 0x060B7A58u: goto L_060B7A58; default: sh2_call(c, x); return; } }  // 060B7A58 jmp @r5 ; mov.l r4,@(12,r11)
}

void f_060B7A5C(SH2Context& c) {
    ran[3142] = 1;
    c.mach = c.macl = 0;  // 060B7A5C clrmac
    c.r[5] = c.gbr;  // 060B7A5E stc gbr,r5
    c.r[4] = c.r[15];  // 060B7A60 mov r15,r4
    c.r[5] += 88;  // 060B7A62 add #88,r5
    sh2_mac_l(c, 5, 4);  // 060B7A64 mac.l @r4+,@r5+
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[8] + 6);  // 060B7A66 mov.w @(6,r8),r0
    c.r[1] = 0x1Fu;  // 060B7A68 mov #31,r1
    c.r[3] = (c.r[0] & 0xFFFF0000u) | (c.r[0] & 0xFFu) << 8 | (c.r[0] >> 8 & 0xFFu);  // 060B7A6A swap.b r0,r3
    sh2_mac_l(c, 5, 4);  // 060B7A6C mac.l @r4+,@r5+
    c.r[3] >>= 2;  // 060B7A6E shlr2 r3
    c.r[3] &= c.r[1];  // 060B7A70 and r1,r3
    c.r[1] &= c.r[0];  // 060B7A72 and r0,r1
    sh2_mac_l(c, 5, 4);  // 060B7A74 mac.l @r4+,@r5+
    c.r[0] >>= 2;  // 060B7A76 shlr2 r0
    c.r[0] >>= 2;  // 060B7A78 shlr2 r0
    c.r[2] = 0x1Fu;  // 060B7A7A mov #31,r2
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060B7A7C shlr r0
    c.r[2] &= c.r[0];  // 060B7A7E and r0,r2
    c.r[5] = c.mach;  // 060B7A80 sts mach,r5
    c.r[4] = c.macl;  // 060B7A82 sts macl,r4
    c.t = (c.r[5] & c.r[5]) == 0;  // 060B7A84 tst r5,r5
    { const bool k = c.t; c.r[0] = ld32(c.gbr + 100); if (k) { goto L_060B7A9C; } }  // 060B7A86 bt/s 0x060B7A9C ; mov.l @(100,gbr),r0
    c.r[5] += 1;  // 060B7A8A add #1,r5
    c.t = (c.r[5] & c.r[5]) == 0;  // 060B7A8C tst r5,r5
    if (c.t) { goto L_060B7AA0; }  // 060B7A8E bt 0x060B7AA0
    c.r[4] = 0xFFFFFFFFu;  // 060B7A90 mov #-1,r4
    c.t = (int32_t)c.r[5] > 0;  // 060B7A92 cmp/pl r5
    { const bool k = c.t; c.r[4] = c.r[4] & 0xFFu; if (k) { goto L_060B7AA8; } }  // 060B7A94 bt/s 0x060B7AA8 ; extu.b r4,r4
    goto L_060B7AB0;  // 060B7A98 bra 0x060B7AB0 ; nop
L_060B7A9C:
    c.r[5] = 0xFFFFFF80u;  // 060B7A9C mov #-128,r5
    c.r[5] = c.r[5] & 0xFFu;  // 060B7A9E extu.b r5,r5
L_060B7AA0:
    c.r[4] >>= 16;  // 060B7AA0 shlr16 r4
    c.r[4] >>= 8;  // 060B7AA2 shlr8 r4
    c.t = c.r[4] & 1; c.r[4] >>= 1;  // 060B7AA4 shlr r4
    c.r[4] |= c.r[5];  // 060B7AA6 or r5,r4
L_060B7AA8:
    c.r[5] = 0xFFFFFFF8u;  // 060B7AA8 mov #-8,r5
    c.r[4] &= c.r[5];  // 060B7AAA and r5,r4
    c.r[4] <<= 2;  // 060B7AAC shll2 r4
    c.r[0] += c.r[4];  // 060B7AAE add r4,r0
L_060B7AB0:
    c.r[5] = 0x4u;  // 060B7AB0 mov #4,r5
    c.r[5] <<= 8;  // 060B7AB2 shll8 r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060B7AB4 mov.b @(r0,r1),r1
    c.r[0] += c.r[5];  // 060B7AB6 add r5,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 060B7AB8 mov.b @(r0,r2),r2
    c.r[0] += c.r[5];  // 060B7ABA add r5,r0
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 060B7ABC mov.b @(r0,r3),r0
    c.r[0] |= 0x20u;  // 060B7ABE or #32,r0
    c.r[0] = (c.r[0] & 0xFFFF0000u) | (c.r[0] & 0xFFu) << 8 | (c.r[0] >> 8 & 0xFFu);  // 060B7AC0 swap.b r0,r0
    c.r[2] <<= 2;  // 060B7AC2 shll2 r2
    c.t = c.r[2] >> 31; c.r[2] <<= 1;  // 060B7AC4 shll r2
    c.r[0] += c.r[2];  // 060B7AC6 add r2,r0
    c.r[0] <<= 2;  // 060B7AC8 shll2 r0
    c.r[1] |= c.r[0];  // 060B7ACA or r0,r1
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[8] + 4);  // 060B7ACC mov.w @(4,r8),r0
    c.r[1] <<= 16;  // 060B7ACE shll16 r1
    c.r[1] = c.r[0] << 16 | c.r[1] >> 16;  // 060B7AD0 xtrct r0,r1
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[8] + 8);  // 060B7AD2 mov.w @(8,r8),r0
    st32(c.r[11] + 4, c.r[1]);  // 060B7AD4 mov.l r1,@(4,r11)
    { const uint32_t x = c.pr; st16(c.r[11] + 28, c.r[0]); c.pc = x; return; }  // 060B7AD6 rts ; mov.w r0,@(28,r11)
}

void f_060B7ADA(SH2Context& c) {
    ran[3143] = 1;
    c.mach = c.macl = 0;  // 060B7ADA clrmac
    c.r[4] = c.r[15];  // 060B7ADC mov r15,r4
    c.r[5] = c.gbr;  // 060B7ADE stc gbr,r5
    c.r[5] += 88;  // 060B7AE0 add #88,r5
    sh2_mac_l(c, 5, 4);  // 060B7AE2 mac.l @r4+,@r5+
    sh2_mac_l(c, 5, 4);  // 060B7AE4 mac.l @r4+,@r5+
    c.r[0] = ld32(c.r[8] + 4);  // 060B7AE6 mov.l @(4,r8),r0
    sh2_mac_l(c, 5, 4);  // 060B7AE8 mac.l @r4+,@r5+
    c.r[1] = 0x7u;  // 060B7AEA mov #7,r1
    c.r[5] = c.mach;  // 060B7AEC sts mach,r5
    c.r[4] = c.macl;  // 060B7AEE sts macl,r4
    c.t = (c.r[5] & c.r[5]) == 0;  // 060B7AF0 tst r5,r5
    { const bool k = c.t; c.r[5] += 1; if (k) { goto L_060B7B00; } }  // 060B7AF2 bt/s 0x060B7B00 ; add #1,r5
    c.t = (c.r[5] & c.r[5]) == 0;  // 060B7AF6 tst r5,r5
    { const bool k = c.t; c.t = (int32_t)c.r[5] >= 0; if (k) { goto L_060B7B02; } }  // 060B7AF8 bt/s 0x060B7B02 ; cmp/pz r5
    { const bool k = !c.t; c.r[4] = 0xFFFFFFFFu; if (k) { goto L_060B7B0E; } }  // 060B7AFC bf/s 0x060B7B0E ; mov #-1,r4
L_060B7B00:
    c.r[5] = 0x8u;  // 060B7B00 mov #8,r5
L_060B7B02:
    c.t = c.r[4] >> 31; c.r[4] = c.r[4] << 1 | c.t;  // 060B7B02 rotl r4
    c.t = c.r[4] >> 31; c.r[4] = c.r[4] << 1 | c.t;  // 060B7B04 rotl r4
    c.t = c.r[4] >> 31; c.r[4] = c.r[4] << 1 | c.t;  // 060B7B06 rotl r4
    c.r[4] &= c.r[1];  // 060B7B08 and r1,r4
    c.r[4] |= c.r[5];  // 060B7B0A or r5,r4
    c.r[0] += c.r[4];  // 060B7B0C add r4,r0
L_060B7B0E:
    { const uint32_t x = c.pr; st32(c.r[11] + 4, c.r[0]); c.pc = x; return; }  // 060B7B0E rts ; mov.l r0,@(4,r11)
}

void f_060B7B12(SH2Context& c) {
    ran[3144] = 1;
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[8] + 2);  // 060B7B12 mov.w @(2,r8),r0
    c.r[1] = ld32(c.r[15] + 20);  // 060B7B14 mov.l @(20,r15),r1
    c.r[0] <<= 2;  // 060B7B16 shll2 r0
    c.r[0] += c.r[0];  // 060B7B18 add r0,r0
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 060B7B1A mov.l @(r0,r1),r0
    c.mach = c.macl = 0;  // 060B7B1C clrmac
    st32(c.r[11] + 8, c.r[0]);  // 060B7B1E mov.l r0,@(8,r11)
    c.r[5] = c.gbr;  // 060B7B20 stc gbr,r5
    c.r[4] = c.r[15];  // 060B7B22 mov r15,r4
    c.r[5] += 88;  // 060B7B24 add #88,r5
    sh2_mac_l(c, 5, 4);  // 060B7B26 mac.l @r4+,@r5+
    c.r[3] = ld32(c.r[8] + 4);  // 060B7B28 mov.l @(4,r8),r3
    sh2_mac_l(c, 5, 4);  // 060B7B2A mac.l @r4+,@r5+
    c.r[0] = c.r[3] << 16 | c.r[3] >> 16;  // 060B7B2C swap.w r3,r0
    c.r[0] &= 0x38u;  // 060B7B2E and #56,r0
    sh2_mac_l(c, 5, 4);  // 060B7B30 mac.l @r4+,@r5+
    c.t = c.r[0] == 0x8u;  // 060B7B32 cmp/eq #8,r0
    if (c.t) { goto L_060B7B3A; }  // 060B7B34 bt 0x060B7B3A
    c.t = c.r[0] == 0x28u;  // 060B7B36 cmp/eq #40,r0
    if (!c.t) { goto L_060B7B6E; }  // 060B7B38 bf 0x060B7B6E
L_060B7B3A:
    c.r[0] = (uint32_t)(int16_t)ld16(0x060B7B76u);  // 060B7B3A mov.w 0x060B7B76,r0
    c.r[1] = c.mach;  // 060B7B3C sts mach,r1
    c.r[2] = c.macl;  // 060B7B3E sts macl,r2
    c.t = (c.r[1] & c.r[1]) == 0;  // 060B7B40 tst r1,r1
    { const bool k = c.t; c.r[1] += 1; if (k) { goto L_060B7B50; } }  // 060B7B42 bt/s 0x060B7B50 ; add #1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060B7B46 tst r1,r1
    { const bool k = c.t; c.t = (int32_t)c.r[1] >= 0; if (k) { goto L_060B7B52; } }  // 060B7B48 bt/s 0x060B7B52 ; cmp/pz r1
    { const bool k = !c.t; c.r[2] = 0xFFFFFFFFu; if (k) { goto L_060B7B5E; } }  // 060B7B4C bf/s 0x060B7B5E ; mov #-1,r2
L_060B7B50:
    c.r[1] = 0x10u;  // 060B7B50 mov #16,r1
L_060B7B52:
    c.r[2] >>= 16;  // 060B7B52 shlr16 r2
    c.r[2] >>= 8;  // 060B7B54 shlr8 r2
    c.r[2] >>= 2;  // 060B7B56 shlr2 r2
    c.r[2] >>= 2;  // 060B7B58 shlr2 r2
    c.r[2] |= c.r[1];  // 060B7B5A or r1,r2
    c.r[0] += c.r[2];  // 060B7B5C add r2,r0
L_060B7B5E:
    c.r[2] = 0xFFFFFFF8u;  // 060B7B5E mov #-8,r2
    st16(c.r[11] + 28, c.r[0]);  // 060B7B60 mov.w r0,@(28,r11)
    c.r[0] = c.r[3] << 16 | c.r[3] >> 16;  // 060B7B62 swap.w r3,r0
    c.r[0] &= c.r[2];  // 060B7B64 and r2,r0
    c.r[0] |= 0x4u;  // 060B7B66 or #4,r0
    c.r[0] = c.r[0] << 16 | c.r[0] >> 16;  // 060B7B68 swap.w r0,r0
    { const uint32_t x = c.pr; st32(c.r[11] + 4, c.r[0]); c.pc = x; return; }  // 060B7B6A rts ; mov.l r0,@(4,r11)
L_060B7B6E:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[8] + 8);  // 060B7B6E mov.w @(8,r8),r0
    st32(c.r[11] + 4, c.r[3]);  // 060B7B70 mov.l r3,@(4,r11)
    { const uint32_t x = c.pr; st16(c.r[11] + 28, c.r[0]); c.pc = x; return; }  // 060B7B72 rts ; mov.w r0,@(28,r11)
}

void f_060B7B78(SH2Context& c) {
    ran[3145] = 1;
    goto L_060B7B78;
L_060B6DFE:
    c.mach = c.macl = 0;  // 060B6DFE clrmac
L_060B6E00:
    sh2_mac_l(c, 6, 7);  // 060B6E00 mac.l @r7+,@r6+
L_060B6E02:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[7] + 8);  // 060B6E02 mov.w @(8,r7),r0
L_060B6E04:
    c.r[5] = c.r[15];  // 060B6E04 mov r15,r5
L_060B6E06:
    sh2_mac_l(c, 6, 7);  // 060B6E06 mac.l @r7+,@r6+
L_060B6E08:
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B6E08 exts.w r0,r1
L_060B6E0A:
    c.r[1] <<= 2;  // 060B6E0A shll2 r1
L_060B6E0C:
    sh2_mac_l(c, 6, 7);  // 060B6E0C mac.l @r7+,@r6+
L_060B6E0E:
    c.r[6] += 4;  // 060B6E0E add #4,r6
L_060B6E10:
    c.r[7] -= 12;  // 060B6E10 add #-12,r7
L_060B6E12:
    c.r[1] <<= 2;  // 060B6E12 shll2 r1
L_060B6E14:
    c.r[0] = c.mach;  // 060B6E14 sts mach,r0
L_060B6E16:
    c.r[13] = c.macl;  // 060B6E16 sts macl,r13
L_060B6E18:
    c.mach = c.macl = 0;  // 060B6E18 clrmac
L_060B6E1A:
    sh2_mac_l(c, 6, 7);  // 060B6E1A mac.l @r7+,@r6+
L_060B6E1C:
    c.r[13] = c.r[0] << 16 | c.r[13] >> 16;  // 060B6E1C xtrct r0,r13
L_060B6E1E:
    st32(c.r[5], c.r[13]);  // 060B6E1E mov.l r13,@(0,r5)
L_060B6E20:
    sh2_mac_l(c, 6, 7);  // 060B6E20 mac.l @r7+,@r6+
L_060B6E22:
    c.r[1] += c.r[10];  // 060B6E22 add r10,r1
L_060B6E24:
    c.r[4] = 0x4u;  // 060B6E24 mov #4,r4
L_060B6E26:
    sh2_mac_l(c, 6, 7);  // 060B6E26 mac.l @r7+,@r6+
L_060B6E28:
    c.r[6] += 4;  // 060B6E28 add #4,r6
L_060B6E2A:
    c.r[7] -= 12;  // 060B6E2A add #-12,r7
L_060B6E2C:
    c.r[4] += c.r[1];  // 060B6E2C add r1,r4
L_060B6E2E:
    c.r[0] = c.mach;  // 060B6E2E sts mach,r0
L_060B6E30:
    c.r[2] = c.macl;  // 060B6E30 sts macl,r2
L_060B6E32:
    c.mach = c.macl = 0;  // 060B6E32 clrmac
L_060B6E34:
    sh2_mac_l(c, 6, 7);  // 060B6E34 mac.l @r7+,@r6+
L_060B6E36:
    c.r[2] = c.r[0] << 16 | c.r[2] >> 16;  // 060B6E36 xtrct r0,r2
L_060B6E38:
    st32(c.r[5] + 4, c.r[2]);  // 060B6E38 mov.l r2,@(4,r5)
L_060B6E3A:
    sh2_mac_l(c, 6, 7);  // 060B6E3A mac.l @r7+,@r6+
L_060B6E3C:
    c.r[12] = (uint32_t)(int16_t)ld16(c.r[8]);  // 060B6E3C mov.w @r8,r12
L_060B6E3E:
    c.r[9] = 0x7Fu;  // 060B6E3E mov #127,r9
L_060B6E40:
    sh2_mac_l(c, 6, 7);  // 060B6E40 mac.l @r7+,@r6+
L_060B6E42:
    c.r[6] -= 44;  // 060B6E42 add #-44,r6
L_060B6E44:
    c.r[9] &= c.r[12];  // 060B6E44 and r12,r9
L_060B6E46:
    c.r[9] <<= 2;  // 060B6E46 shll2 r9
L_060B6E48:
    c.r[0] = c.mach;  // 060B6E48 sts mach,r0
L_060B6E4A:
    c.r[3] = c.macl;  // 060B6E4A sts macl,r3
L_060B6E4C:
    c.mach = c.macl = 0;  // 060B6E4C clrmac
L_060B6E4E:
    sh2_mac_l(c, 5, 4);  // 060B6E4E mac.l @r4+,@r5+
L_060B6E50:
    c.r[3] = c.r[0] << 16 | c.r[3] >> 16;  // 060B6E50 xtrct r0,r3
L_060B6E52:
    c.r[0] = 0x060B7144u;  // 060B6E52 mova 0x060B7144,r0
L_060B6E54:
    sh2_mac_l(c, 5, 4);  // 060B6E54 mac.l @r4+,@r5+
L_060B6E56:
    st32(c.r[5], c.r[3]);  // 060B6E56 mov.l r3,@r5
L_060B6E58:
    c.r[9] <<= 2;  // 060B6E58 shll2 r9
L_060B6E5A:
    sh2_mac_l(c, 5, 4);  // 060B6E5A mac.l @r4+,@r5+
L_060B6E5C:
    c.r[9] += c.r[0];  // 060B6E5C add r0,r9
L_060B6E5E:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[8] + 10);  // 060B6E5E mov.w @(10,r8),r0
L_060B6E60:
    c.r[7] += 2;  // 060B6E60 add #2,r7
L_060B6E62:
    c.r[4] = c.mach;  // 060B6E62 sts mach,r4
L_060B6E64:
    st16(c.r[11], c.r[0]);  // 060B6E64 mov.w r0,@(0,r11)
L_060B6E66:
    c.r[0] = ld32(c.gbr + 900);  // 060B6E66 mov.l @(900,gbr),r0
L_060B6E68:
    c.t = (int32_t)c.r[4] >= (int32_t)c.r[0];  // 060B6E68 cmp/ge r0,r4
L_060B6E6A:
    { const bool k = c.t; c.r[0] = (c.r[12] & 0xFFFF0000u) | (c.r[12] & 0xFFu) << 8 | (c.r[12] >> 8 & 0xFFu); if (k) { goto L_060B6E76; } }  // 060B6E6A bt/s 0x060B6E76 ; swap.b r12,r0
L_060B6E6E:
    c.r[0] = ld32(c.r[9]); c.r[9] += 4;  // 060B6E6E mov.l @r9+,r0
L_060B6E70:
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 060B6E70 mov.w @r7+,r2
L_060B6E72:
    { const uint32_t x = c.r[0]; c.r[2] <<= 2; SH2_POLL(c); switch (x) { case 0x060B6DFEu: goto L_060B6DFE; case 0x060B6E00u: goto L_060B6E00; case 0x060B6E02u: goto L_060B6E02; case 0x060B6E04u: goto L_060B6E04; case 0x060B6E06u: goto L_060B6E06; case 0x060B6E08u: goto L_060B6E08; case 0x060B6E0Au: goto L_060B6E0A; case 0x060B6E0Cu: goto L_060B6E0C; case 0x060B6E0Eu: goto L_060B6E0E; case 0x060B6E10u: goto L_060B6E10; case 0x060B6E12u: goto L_060B6E12; case 0x060B6E14u: goto L_060B6E14; case 0x060B6E16u: goto L_060B6E16; case 0x060B6E18u: goto L_060B6E18; case 0x060B6E1Au: goto L_060B6E1A; case 0x060B6E1Cu: goto L_060B6E1C; case 0x060B6E1Eu: goto L_060B6E1E; case 0x060B6E20u: goto L_060B6E20; case 0x060B6E22u: goto L_060B6E22; case 0x060B6E24u: goto L_060B6E24; case 0x060B6E26u: goto L_060B6E26; case 0x060B6E28u: goto L_060B6E28; case 0x060B6E2Au: goto L_060B6E2A; case 0x060B6E2Cu: goto L_060B6E2C; case 0x060B6E2Eu: goto L_060B6E2E; case 0x060B6E30u: goto L_060B6E30; case 0x060B6E32u: goto L_060B6E32; case 0x060B6E34u: goto L_060B6E34; case 0x060B6E36u: goto L_060B6E36; case 0x060B6E38u: goto L_060B6E38; case 0x060B6E3Au: goto L_060B6E3A; case 0x060B6E3Cu: goto L_060B6E3C; case 0x060B6E3Eu: goto L_060B6E3E; case 0x060B6E40u: goto L_060B6E40; case 0x060B6E42u: goto L_060B6E42; case 0x060B6E44u: goto L_060B6E44; case 0x060B6E46u: goto L_060B6E46; case 0x060B6E48u: goto L_060B6E48; case 0x060B6E4Au: goto L_060B6E4A; case 0x060B6E4Cu: goto L_060B6E4C; case 0x060B6E4Eu: goto L_060B6E4E; case 0x060B6E50u: goto L_060B6E50; case 0x060B6E52u: goto L_060B6E52; case 0x060B6E54u: goto L_060B6E54; case 0x060B6E56u: goto L_060B6E56; case 0x060B6E58u: goto L_060B6E58; case 0x060B6E5Au: goto L_060B6E5A; case 0x060B6E5Cu: goto L_060B6E5C; case 0x060B6E5Eu: goto L_060B6E5E; case 0x060B6E60u: goto L_060B6E60; case 0x060B6E62u: goto L_060B6E62; case 0x060B6E64u: goto L_060B6E64; case 0x060B6E66u: goto L_060B6E66; case 0x060B6E68u: goto L_060B6E68; case 0x060B6E6Au: goto L_060B6E6A; case 0x060B6E6Eu: goto L_060B6E6E; case 0x060B6E70u: goto L_060B6E70; case 0x060B6E72u: goto L_060B6E72; case 0x060B6E76u: goto L_060B6E76; case 0x060B6E78u: goto L_060B6E78; case 0x060B6E7Cu: goto L_060B6E7C; case 0x060B6E7Eu: goto L_060B6E7E; case 0x060B6E80u: goto L_060B6E80; case 0x060B6E82u: goto L_060B6E82; case 0x060B6E84u: goto L_060B6E84; case 0x060B6E86u: goto L_060B6E86; case 0x060B6E88u: goto L_060B6E88; case 0x060B6E8Au: goto L_060B6E8A; case 0x060B6E8Eu: goto L_060B6E8E; case 0x060B6EBCu: goto L_060B6EBC; case 0x060B6EBEu: goto L_060B6EBE; case 0x060B6EC0u: goto L_060B6EC0; case 0x060B6EC2u: goto L_060B6EC2; case 0x060B6EC6u: goto L_060B6EC6; case 0x060B6EC8u: goto L_060B6EC8; case 0x060B6ECAu: goto L_060B6ECA; case 0x060B6ECCu: goto L_060B6ECC; case 0x060B6ECEu: goto L_060B6ECE; case 0x060B6ED0u: goto L_060B6ED0; case 0x060B7990u: goto L_060B7990; case 0x060B7992u: goto L_060B7992; case 0x060B7994u: goto L_060B7994; case 0x060B7996u: goto L_060B7996; case 0x060B7998u: goto L_060B7998; case 0x060B799Au: goto L_060B799A; case 0x060B799Cu: goto L_060B799C; case 0x060B799Eu: goto L_060B799E; case 0x060B79A0u: goto L_060B79A0; case 0x060B79A2u: goto L_060B79A2; case 0x060B79A4u: goto L_060B79A4; case 0x060B79A6u: goto L_060B79A6; case 0x060B79A8u: goto L_060B79A8; case 0x060B79AAu: goto L_060B79AA; case 0x060B79ACu: goto L_060B79AC; case 0x060B79AEu: goto L_060B79AE; case 0x060B79B0u: goto L_060B79B0; case 0x060B79B2u: goto L_060B79B2; case 0x060B79B4u: goto L_060B79B4; case 0x060B79B6u: goto L_060B79B6; case 0x060B79B8u: goto L_060B79B8; case 0x060B79BAu: goto L_060B79BA; case 0x060B79BCu: goto L_060B79BC; case 0x060B79BEu: goto L_060B79BE; case 0x060B79C0u: goto L_060B79C0; case 0x060B79C2u: goto L_060B79C2; case 0x060B79C4u: goto L_060B79C4; case 0x060B79C8u: goto L_060B79C8; case 0x060B79CAu: goto L_060B79CA; case 0x060B79CCu: goto L_060B79CC; case 0x060B79CEu: goto L_060B79CE; case 0x060B79D0u: goto L_060B79D0; case 0x060B79D2u: goto L_060B79D2; case 0x060B79D4u: goto L_060B79D4; case 0x060B79D6u: goto L_060B79D6; case 0x060B79D8u: goto L_060B79D8; case 0x060B79DAu: goto L_060B79DA; case 0x060B79DCu: goto L_060B79DC; case 0x060B79DEu: goto L_060B79DE; case 0x060B79E0u: goto L_060B79E0; case 0x060B79E2u: goto L_060B79E2; case 0x060B79E6u: goto L_060B79E6; case 0x060B79E8u: goto L_060B79E8; case 0x060B79EAu: goto L_060B79EA; case 0x060B79ECu: goto L_060B79EC; case 0x060B79EEu: goto L_060B79EE; case 0x060B79F0u: goto L_060B79F0; case 0x060B79F2u: goto L_060B79F2; case 0x060B79F4u: goto L_060B79F4; case 0x060B79F6u: goto L_060B79F6; case 0x060B79F8u: goto L_060B79F8; case 0x060B79FAu: goto L_060B79FA; case 0x060B79FCu: goto L_060B79FC; case 0x060B79FEu: goto L_060B79FE; case 0x060B7A00u: goto L_060B7A00; case 0x060B7A04u: goto L_060B7A04; case 0x060B7A0Eu: goto L_060B7A0E; case 0x060B7A10u: goto L_060B7A10; case 0x060B7A12u: goto L_060B7A12; case 0x060B7A14u: goto L_060B7A14; case 0x060B7A16u: goto L_060B7A16; case 0x060B7A48u: goto L_060B7A48; case 0x060B7A4Au: goto L_060B7A4A; case 0x060B7A4Cu: goto L_060B7A4C; case 0x060B7A4Eu: goto L_060B7A4E; case 0x060B7A50u: goto L_060B7A50; case 0x060B7A52u: goto L_060B7A52; case 0x060B7A54u: goto L_060B7A54; case 0x060B7A56u: goto L_060B7A56; case 0x060B7A58u: goto L_060B7A58; case 0x060B7B78u: goto L_060B7B78; case 0x060B7B7Au: goto L_060B7B7A; case 0x060B7B7Cu: goto L_060B7B7C; case 0x060B7B7Eu: goto L_060B7B7E; case 0x060B7B80u: goto L_060B7B80; case 0x060B7B82u: goto L_060B7B82; case 0x060B7B84u: goto L_060B7B84; case 0x060B7B86u: goto L_060B7B86; case 0x060B7B88u: goto L_060B7B88; case 0x060B7B8Au: goto L_060B7B8A; case 0x060B7B8Eu: goto L_060B7B8E; case 0x060B7B90u: goto L_060B7B90; case 0x060B7B92u: goto L_060B7B92; case 0x060B7B94u: goto L_060B7B94; case 0x060B7B96u: goto L_060B7B96; case 0x060B7B9Au: goto L_060B7B9A; case 0x060B7B9Cu: goto L_060B7B9C; case 0x060B7B9Eu: goto L_060B7B9E; case 0x060B7BA0u: goto L_060B7BA0; case 0x060B7BA2u: goto L_060B7BA2; case 0x060B7BA6u: goto L_060B7BA6; case 0x060B7BA8u: goto L_060B7BA8; case 0x060B7BAAu: goto L_060B7BAA; case 0x060B7BAEu: goto L_060B7BAE; case 0x060B7BB0u: goto L_060B7BB0; case 0x060B7BB2u: goto L_060B7BB2; case 0x060B7BB4u: goto L_060B7BB4; case 0x060B7BB6u: goto L_060B7BB6; case 0x060B7BBAu: goto L_060B7BBA; case 0x060B7BBCu: goto L_060B7BBC; case 0x060B7BBEu: goto L_060B7BBE; case 0x060B7BC0u: goto L_060B7BC0; case 0x060B7BC2u: goto L_060B7BC2; case 0x060B7BC6u: goto L_060B7BC6; case 0x060B7BC8u: goto L_060B7BC8; case 0x060B7BCAu: goto L_060B7BCA; case 0x060B7BCEu: goto L_060B7BCE; case 0x060B7BD0u: goto L_060B7BD0; case 0x060B7BD2u: goto L_060B7BD2; case 0x060B7BD4u: goto L_060B7BD4; case 0x060B7BD6u: goto L_060B7BD6; case 0x060B7BDAu: goto L_060B7BDA; case 0x060B7BDCu: goto L_060B7BDC; case 0x060B7BDEu: goto L_060B7BDE; case 0x060B7BE0u: goto L_060B7BE0; case 0x060B7BE2u: goto L_060B7BE2; case 0x060B7BE6u: goto L_060B7BE6; case 0x060B7BE8u: goto L_060B7BE8; case 0x060B7BEAu: goto L_060B7BEA; case 0x060B7BEEu: goto L_060B7BEE; case 0x060B7BF0u: goto L_060B7BF0; case 0x060B7BF2u: goto L_060B7BF2; case 0x060B7BF4u: goto L_060B7BF4; case 0x060B7BF6u: goto L_060B7BF6; case 0x060B7BFAu: goto L_060B7BFA; case 0x060B7BFCu: goto L_060B7BFC; case 0x060B7BFEu: goto L_060B7BFE; case 0x060B7C00u: goto L_060B7C00; case 0x060B7C02u: goto L_060B7C02; case 0x060B7C06u: goto L_060B7C06; case 0x060B7C08u: goto L_060B7C08; case 0x060B7C0Au: goto L_060B7C0A; case 0x060B7C0Cu: goto L_060B7C0C; case 0x060B7C0Eu: goto L_060B7C0E; case 0x060B7C12u: goto L_060B7C12; case 0x060B7C58u: goto L_060B7C58; case 0x060B7C5Au: goto L_060B7C5A; case 0x060B7C5Cu: goto L_060B7C5C; case 0x060B7C5Eu: goto L_060B7C5E; case 0x060B7C60u: goto L_060B7C60; case 0x060B7C62u: goto L_060B7C62; case 0x060B7C64u: goto L_060B7C64; case 0x060B7C66u: goto L_060B7C66; case 0x060B7C68u: goto L_060B7C68; case 0x060B7C6Cu: goto L_060B7C6C; case 0x060B7C6Eu: goto L_060B7C6E; case 0x060B7C70u: goto L_060B7C70; case 0x060B7C72u: goto L_060B7C72; case 0x060B7C74u: goto L_060B7C74; case 0x060B7C76u: goto L_060B7C76; case 0x060B7C78u: goto L_060B7C78; case 0x060B7C7Au: goto L_060B7C7A; case 0x060B7C7Cu: goto L_060B7C7C; case 0x060B7C80u: goto L_060B7C80; case 0x060B7C82u: goto L_060B7C82; case 0x060B7C84u: goto L_060B7C84; case 0x060B7C86u: goto L_060B7C86; case 0x060B7C88u: goto L_060B7C88; case 0x060B7C8Au: goto L_060B7C8A; default: sh2_call(c, x); return; } }  // 060B6E72 jmp @r0 ; shll2 r2
L_060B6E76:
    c.t = (c.r[0] & 0x1u) == 0;  // 060B6E76 tst #1,r0
L_060B6E78:
    { const bool k = c.t; c.r[3] = 0u - c.r[3]; if (k) { goto L_060B6E8E; } }  // 060B6E78 bt/s 0x060B6E8E ; neg r3,r3
L_060B6E7C:
    c.r[5] -= 4; st32(c.r[5], c.r[3]);  // 060B6E7C mov.l r3,@-r5
L_060B6E7E:
    c.r[2] = 0u - c.r[2];  // 060B6E7E neg r2,r2
L_060B6E80:
    c.r[5] -= 4; st32(c.r[5], c.r[2]);  // 060B6E80 mov.l r2,@-r5
L_060B6E82:
    c.r[13] = 0u - c.r[13];  // 060B6E82 neg r13,r13
L_060B6E84:
    c.r[5] -= 4; st32(c.r[5], c.r[13]);  // 060B6E84 mov.l r13,@-r5
L_060B6E86:
    c.r[0] = ld32(c.r[9]); c.r[9] += 4;  // 060B6E86 mov.l @r9+,r0
L_060B6E88:
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 060B6E88 mov.w @r7+,r2
L_060B6E8A:
    { const uint32_t x = c.r[0]; c.r[2] <<= 2; SH2_POLL(c); switch (x) { case 0x060B6DFEu: goto L_060B6DFE; case 0x060B6E00u: goto L_060B6E00; case 0x060B6E02u: goto L_060B6E02; case 0x060B6E04u: goto L_060B6E04; case 0x060B6E06u: goto L_060B6E06; case 0x060B6E08u: goto L_060B6E08; case 0x060B6E0Au: goto L_060B6E0A; case 0x060B6E0Cu: goto L_060B6E0C; case 0x060B6E0Eu: goto L_060B6E0E; case 0x060B6E10u: goto L_060B6E10; case 0x060B6E12u: goto L_060B6E12; case 0x060B6E14u: goto L_060B6E14; case 0x060B6E16u: goto L_060B6E16; case 0x060B6E18u: goto L_060B6E18; case 0x060B6E1Au: goto L_060B6E1A; case 0x060B6E1Cu: goto L_060B6E1C; case 0x060B6E1Eu: goto L_060B6E1E; case 0x060B6E20u: goto L_060B6E20; case 0x060B6E22u: goto L_060B6E22; case 0x060B6E24u: goto L_060B6E24; case 0x060B6E26u: goto L_060B6E26; case 0x060B6E28u: goto L_060B6E28; case 0x060B6E2Au: goto L_060B6E2A; case 0x060B6E2Cu: goto L_060B6E2C; case 0x060B6E2Eu: goto L_060B6E2E; case 0x060B6E30u: goto L_060B6E30; case 0x060B6E32u: goto L_060B6E32; case 0x060B6E34u: goto L_060B6E34; case 0x060B6E36u: goto L_060B6E36; case 0x060B6E38u: goto L_060B6E38; case 0x060B6E3Au: goto L_060B6E3A; case 0x060B6E3Cu: goto L_060B6E3C; case 0x060B6E3Eu: goto L_060B6E3E; case 0x060B6E40u: goto L_060B6E40; case 0x060B6E42u: goto L_060B6E42; case 0x060B6E44u: goto L_060B6E44; case 0x060B6E46u: goto L_060B6E46; case 0x060B6E48u: goto L_060B6E48; case 0x060B6E4Au: goto L_060B6E4A; case 0x060B6E4Cu: goto L_060B6E4C; case 0x060B6E4Eu: goto L_060B6E4E; case 0x060B6E50u: goto L_060B6E50; case 0x060B6E52u: goto L_060B6E52; case 0x060B6E54u: goto L_060B6E54; case 0x060B6E56u: goto L_060B6E56; case 0x060B6E58u: goto L_060B6E58; case 0x060B6E5Au: goto L_060B6E5A; case 0x060B6E5Cu: goto L_060B6E5C; case 0x060B6E5Eu: goto L_060B6E5E; case 0x060B6E60u: goto L_060B6E60; case 0x060B6E62u: goto L_060B6E62; case 0x060B6E64u: goto L_060B6E64; case 0x060B6E66u: goto L_060B6E66; case 0x060B6E68u: goto L_060B6E68; case 0x060B6E6Au: goto L_060B6E6A; case 0x060B6E6Eu: goto L_060B6E6E; case 0x060B6E70u: goto L_060B6E70; case 0x060B6E72u: goto L_060B6E72; case 0x060B6E76u: goto L_060B6E76; case 0x060B6E78u: goto L_060B6E78; case 0x060B6E7Cu: goto L_060B6E7C; case 0x060B6E7Eu: goto L_060B6E7E; case 0x060B6E80u: goto L_060B6E80; case 0x060B6E82u: goto L_060B6E82; case 0x060B6E84u: goto L_060B6E84; case 0x060B6E86u: goto L_060B6E86; case 0x060B6E88u: goto L_060B6E88; case 0x060B6E8Au: goto L_060B6E8A; case 0x060B6E8Eu: goto L_060B6E8E; case 0x060B6EBCu: goto L_060B6EBC; case 0x060B6EBEu: goto L_060B6EBE; case 0x060B6EC0u: goto L_060B6EC0; case 0x060B6EC2u: goto L_060B6EC2; case 0x060B6EC6u: goto L_060B6EC6; case 0x060B6EC8u: goto L_060B6EC8; case 0x060B6ECAu: goto L_060B6ECA; case 0x060B6ECCu: goto L_060B6ECC; case 0x060B6ECEu: goto L_060B6ECE; case 0x060B6ED0u: goto L_060B6ED0; case 0x060B7990u: goto L_060B7990; case 0x060B7992u: goto L_060B7992; case 0x060B7994u: goto L_060B7994; case 0x060B7996u: goto L_060B7996; case 0x060B7998u: goto L_060B7998; case 0x060B799Au: goto L_060B799A; case 0x060B799Cu: goto L_060B799C; case 0x060B799Eu: goto L_060B799E; case 0x060B79A0u: goto L_060B79A0; case 0x060B79A2u: goto L_060B79A2; case 0x060B79A4u: goto L_060B79A4; case 0x060B79A6u: goto L_060B79A6; case 0x060B79A8u: goto L_060B79A8; case 0x060B79AAu: goto L_060B79AA; case 0x060B79ACu: goto L_060B79AC; case 0x060B79AEu: goto L_060B79AE; case 0x060B79B0u: goto L_060B79B0; case 0x060B79B2u: goto L_060B79B2; case 0x060B79B4u: goto L_060B79B4; case 0x060B79B6u: goto L_060B79B6; case 0x060B79B8u: goto L_060B79B8; case 0x060B79BAu: goto L_060B79BA; case 0x060B79BCu: goto L_060B79BC; case 0x060B79BEu: goto L_060B79BE; case 0x060B79C0u: goto L_060B79C0; case 0x060B79C2u: goto L_060B79C2; case 0x060B79C4u: goto L_060B79C4; case 0x060B79C8u: goto L_060B79C8; case 0x060B79CAu: goto L_060B79CA; case 0x060B79CCu: goto L_060B79CC; case 0x060B79CEu: goto L_060B79CE; case 0x060B79D0u: goto L_060B79D0; case 0x060B79D2u: goto L_060B79D2; case 0x060B79D4u: goto L_060B79D4; case 0x060B79D6u: goto L_060B79D6; case 0x060B79D8u: goto L_060B79D8; case 0x060B79DAu: goto L_060B79DA; case 0x060B79DCu: goto L_060B79DC; case 0x060B79DEu: goto L_060B79DE; case 0x060B79E0u: goto L_060B79E0; case 0x060B79E2u: goto L_060B79E2; case 0x060B79E6u: goto L_060B79E6; case 0x060B79E8u: goto L_060B79E8; case 0x060B79EAu: goto L_060B79EA; case 0x060B79ECu: goto L_060B79EC; case 0x060B79EEu: goto L_060B79EE; case 0x060B79F0u: goto L_060B79F0; case 0x060B79F2u: goto L_060B79F2; case 0x060B79F4u: goto L_060B79F4; case 0x060B79F6u: goto L_060B79F6; case 0x060B79F8u: goto L_060B79F8; case 0x060B79FAu: goto L_060B79FA; case 0x060B79FCu: goto L_060B79FC; case 0x060B79FEu: goto L_060B79FE; case 0x060B7A00u: goto L_060B7A00; case 0x060B7A04u: goto L_060B7A04; case 0x060B7A0Eu: goto L_060B7A0E; case 0x060B7A10u: goto L_060B7A10; case 0x060B7A12u: goto L_060B7A12; case 0x060B7A14u: goto L_060B7A14; case 0x060B7A16u: goto L_060B7A16; case 0x060B7A48u: goto L_060B7A48; case 0x060B7A4Au: goto L_060B7A4A; case 0x060B7A4Cu: goto L_060B7A4C; case 0x060B7A4Eu: goto L_060B7A4E; case 0x060B7A50u: goto L_060B7A50; case 0x060B7A52u: goto L_060B7A52; case 0x060B7A54u: goto L_060B7A54; case 0x060B7A56u: goto L_060B7A56; case 0x060B7A58u: goto L_060B7A58; case 0x060B7B78u: goto L_060B7B78; case 0x060B7B7Au: goto L_060B7B7A; case 0x060B7B7Cu: goto L_060B7B7C; case 0x060B7B7Eu: goto L_060B7B7E; case 0x060B7B80u: goto L_060B7B80; case 0x060B7B82u: goto L_060B7B82; case 0x060B7B84u: goto L_060B7B84; case 0x060B7B86u: goto L_060B7B86; case 0x060B7B88u: goto L_060B7B88; case 0x060B7B8Au: goto L_060B7B8A; case 0x060B7B8Eu: goto L_060B7B8E; case 0x060B7B90u: goto L_060B7B90; case 0x060B7B92u: goto L_060B7B92; case 0x060B7B94u: goto L_060B7B94; case 0x060B7B96u: goto L_060B7B96; case 0x060B7B9Au: goto L_060B7B9A; case 0x060B7B9Cu: goto L_060B7B9C; case 0x060B7B9Eu: goto L_060B7B9E; case 0x060B7BA0u: goto L_060B7BA0; case 0x060B7BA2u: goto L_060B7BA2; case 0x060B7BA6u: goto L_060B7BA6; case 0x060B7BA8u: goto L_060B7BA8; case 0x060B7BAAu: goto L_060B7BAA; case 0x060B7BAEu: goto L_060B7BAE; case 0x060B7BB0u: goto L_060B7BB0; case 0x060B7BB2u: goto L_060B7BB2; case 0x060B7BB4u: goto L_060B7BB4; case 0x060B7BB6u: goto L_060B7BB6; case 0x060B7BBAu: goto L_060B7BBA; case 0x060B7BBCu: goto L_060B7BBC; case 0x060B7BBEu: goto L_060B7BBE; case 0x060B7BC0u: goto L_060B7BC0; case 0x060B7BC2u: goto L_060B7BC2; case 0x060B7BC6u: goto L_060B7BC6; case 0x060B7BC8u: goto L_060B7BC8; case 0x060B7BCAu: goto L_060B7BCA; case 0x060B7BCEu: goto L_060B7BCE; case 0x060B7BD0u: goto L_060B7BD0; case 0x060B7BD2u: goto L_060B7BD2; case 0x060B7BD4u: goto L_060B7BD4; case 0x060B7BD6u: goto L_060B7BD6; case 0x060B7BDAu: goto L_060B7BDA; case 0x060B7BDCu: goto L_060B7BDC; case 0x060B7BDEu: goto L_060B7BDE; case 0x060B7BE0u: goto L_060B7BE0; case 0x060B7BE2u: goto L_060B7BE2; case 0x060B7BE6u: goto L_060B7BE6; case 0x060B7BE8u: goto L_060B7BE8; case 0x060B7BEAu: goto L_060B7BEA; case 0x060B7BEEu: goto L_060B7BEE; case 0x060B7BF0u: goto L_060B7BF0; case 0x060B7BF2u: goto L_060B7BF2; case 0x060B7BF4u: goto L_060B7BF4; case 0x060B7BF6u: goto L_060B7BF6; case 0x060B7BFAu: goto L_060B7BFA; case 0x060B7BFCu: goto L_060B7BFC; case 0x060B7BFEu: goto L_060B7BFE; case 0x060B7C00u: goto L_060B7C00; case 0x060B7C02u: goto L_060B7C02; case 0x060B7C06u: goto L_060B7C06; case 0x060B7C08u: goto L_060B7C08; case 0x060B7C0Au: goto L_060B7C0A; case 0x060B7C0Cu: goto L_060B7C0C; case 0x060B7C0Eu: goto L_060B7C0E; case 0x060B7C12u: goto L_060B7C12; case 0x060B7C58u: goto L_060B7C58; case 0x060B7C5Au: goto L_060B7C5A; case 0x060B7C5Cu: goto L_060B7C5C; case 0x060B7C5Eu: goto L_060B7C5E; case 0x060B7C60u: goto L_060B7C60; case 0x060B7C62u: goto L_060B7C62; case 0x060B7C64u: goto L_060B7C64; case 0x060B7C66u: goto L_060B7C66; case 0x060B7C68u: goto L_060B7C68; case 0x060B7C6Cu: goto L_060B7C6C; case 0x060B7C6Eu: goto L_060B7C6E; case 0x060B7C70u: goto L_060B7C70; case 0x060B7C72u: goto L_060B7C72; case 0x060B7C74u: goto L_060B7C74; case 0x060B7C76u: goto L_060B7C76; case 0x060B7C78u: goto L_060B7C78; case 0x060B7C7Au: goto L_060B7C7A; case 0x060B7C7Cu: goto L_060B7C7C; case 0x060B7C80u: goto L_060B7C80; case 0x060B7C82u: goto L_060B7C82; case 0x060B7C84u: goto L_060B7C84; case 0x060B7C86u: goto L_060B7C86; case 0x060B7C88u: goto L_060B7C88; case 0x060B7C8Au: goto L_060B7C8A; default: sh2_call(c, x); return; } }  // 060B6E8A jmp @r0 ; shll2 r2
L_060B6E8E:
    c.r[7] += 6; goto L_060B6EBC;  // 060B6E8E bra 0x060B6EBC ; add #6,r7
L_060B6EBC:
    c.r[0] = ld32(c.r[15] + 16);  // 060B6EBC mov.l @(16,r15),r0
L_060B6EBE:
    c.r[8] += 12;  // 060B6EBE add #12,r8
L_060B6EC0:
    c.r[0] -= 1; c.t = c.r[0] == 0;  // 060B6EC0 dt r0
L_060B6EC2:
    { const bool k = !c.t; st32(c.r[15] + 16, c.r[0]); if (k) { SH2_POLL(c); goto L_060B6DFE; } }  // 060B6EC2 bf/s 0x060B6DFE ; mov.l r0,@(16,r15)
L_060B6EC6:
    c.r[15] += 24;  // 060B6EC6 add #24,r15
L_060B6EC8:
    c.r[4] = ld32(c.r[15]); c.r[15] += 4;  // 060B6EC8 mov.l @r15+,r4
L_060B6ECA:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060B6ECA lds.l @r15+,pr
L_060B6ECC:
    c.r[4] += 48;  // 060B6ECC add #48,r4
L_060B6ECE:
    c.r[0] = c.r[11];  // 060B6ECE mov r11,r0
L_060B6ED0:
    { const uint32_t x = c.pr; st32(c.gbr + 52, c.r[0]); c.pc = x; return; }  // 060B6ED0 rts ; mov.l r0,@(52,gbr)
L_060B7990:
    c.r[5] <<= 16;  // 060B7990 shll16 r5
L_060B7992:
    c.t = c.r[5] & 1; c.r[5] >>= 1;  // 060B7992 shlr r5
L_060B7994:
    c.r[9] = c.r[4] << 16 | c.r[4] >> 16;  // 060B7994 swap.w r4,r9
L_060B7996:
    c.t = (c.r[9] & c.r[5]) == 0;  // 060B7996 tst r5,r9
L_060B7998:
    { uint32_t a = c.r[13], b = c.r[13], t = c.t; c.r[13] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B7998 subc r13,r13
L_060B799A:
    c.r[13] = ~c.r[13];  // 060B799A not r13,r13
L_060B799C:
    c.r[13] ^= c.r[9];  // 060B799C xor r9,r13
L_060B799E:
    c.t = (c.r[4] & c.r[5]) == 0;  // 060B799E tst r5,r4
L_060B79A0:
    { uint32_t a = c.r[9], b = c.r[9], t = c.t; c.r[9] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B79A0 subc r9,r9
L_060B79A2:
    c.r[9] = ~c.r[9];  // 060B79A2 not r9,r9
L_060B79A4:
    c.r[9] ^= c.r[4];  // 060B79A4 xor r4,r9
L_060B79A6:
    c.r[13] += c.r[9];  // 060B79A6 add r9,r13
L_060B79A8:
    c.r[13] = c.r[13] & 0xFFFFu;  // 060B79A8 extu.w r13,r13
L_060B79AA:
    c.r[0] = 0x060B7A4Cu;  // 060B79AA mova 0x060B7A4C,r0
L_060B79AC:
    c.r[9] = c.r[3] << 16 | c.r[3] >> 16;  // 060B79AC swap.w r3,r9
L_060B79AE:
    c.t = (c.r[9] & c.r[5]) == 0;  // 060B79AE tst r5,r9
L_060B79B0:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B79B0 subc r12,r12
L_060B79B2:
    c.r[12] = ~c.r[12];  // 060B79B2 not r12,r12
L_060B79B4:
    c.r[12] ^= c.r[9];  // 060B79B4 xor r9,r12
L_060B79B6:
    c.t = (c.r[3] & c.r[5]) == 0;  // 060B79B6 tst r5,r3
L_060B79B8:
    { uint32_t a = c.r[9], b = c.r[9], t = c.t; c.r[9] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B79B8 subc r9,r9
L_060B79BA:
    c.r[9] = ~c.r[9];  // 060B79BA not r9,r9
L_060B79BC:
    c.r[9] ^= c.r[3];  // 060B79BC xor r3,r9
L_060B79BE:
    c.r[12] += c.r[9];  // 060B79BE add r9,r12
L_060B79C0:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B79C0 extu.w r12,r12
L_060B79C2:
    c.t = (int32_t)c.r[12] > (int32_t)c.r[13];  // 060B79C2 cmp/gt r13,r12
L_060B79C4:
    { const bool k = c.t; c.r[9] = c.r[2] << 16 | c.r[2] >> 16; if (k) { goto L_060B79CC; } }  // 060B79C4 bt/s 0x060B79CC ; swap.w r2,r9
L_060B79C8:
    c.r[13] = c.r[12];  // 060B79C8 mov r12,r13
L_060B79CA:
    c.r[0] = 0x060B7A38u;  // 060B79CA mova 0x060B7A38,r0
L_060B79CC:
    c.t = (c.r[9] & c.r[5]) == 0;  // 060B79CC tst r5,r9
L_060B79CE:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B79CE subc r12,r12
L_060B79D0:
    c.r[12] = ~c.r[12];  // 060B79D0 not r12,r12
L_060B79D2:
    c.r[12] ^= c.r[9];  // 060B79D2 xor r9,r12
L_060B79D4:
    c.t = (c.r[2] & c.r[5]) == 0;  // 060B79D4 tst r5,r2
L_060B79D6:
    { uint32_t a = c.r[9], b = c.r[9], t = c.t; c.r[9] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B79D6 subc r9,r9
L_060B79D8:
    c.r[9] = ~c.r[9];  // 060B79D8 not r9,r9
L_060B79DA:
    c.r[9] ^= c.r[2];  // 060B79DA xor r2,r9
L_060B79DC:
    c.r[12] += c.r[9];  // 060B79DC add r9,r12
L_060B79DE:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B79DE extu.w r12,r12
L_060B79E0:
    c.t = (int32_t)c.r[12] > (int32_t)c.r[13];  // 060B79E0 cmp/gt r13,r12
L_060B79E2:
    { const bool k = c.t; c.r[9] = c.r[1] << 16 | c.r[1] >> 16; if (k) { goto L_060B79EA; } }  // 060B79E2 bt/s 0x060B79EA ; swap.w r1,r9
L_060B79E6:
    c.r[13] = c.r[12];  // 060B79E6 mov r12,r13
L_060B79E8:
    c.r[0] = 0x060B7A24u;  // 060B79E8 mova 0x060B7A24,r0
L_060B79EA:
    c.t = (c.r[9] & c.r[5]) == 0;  // 060B79EA tst r5,r9
L_060B79EC:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B79EC subc r12,r12
L_060B79EE:
    c.r[12] = ~c.r[12];  // 060B79EE not r12,r12
L_060B79F0:
    c.r[12] ^= c.r[9];  // 060B79F0 xor r9,r12
L_060B79F2:
    c.t = (c.r[1] & c.r[5]) == 0;  // 060B79F2 tst r5,r1
L_060B79F4:
    { uint32_t a = c.r[9], b = c.r[9], t = c.t; c.r[9] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B79F4 subc r9,r9
L_060B79F6:
    c.r[9] = ~c.r[9];  // 060B79F6 not r9,r9
L_060B79F8:
    c.r[9] ^= c.r[1];  // 060B79F8 xor r1,r9
L_060B79FA:
    c.r[12] += c.r[9];  // 060B79FA add r9,r12
L_060B79FC:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B79FC extu.w r12,r12
L_060B79FE:
    c.t = (int32_t)c.r[13] >= (int32_t)c.r[12];  // 060B79FE cmp/ge r12,r13
L_060B7A00:
    { const bool k = c.t; c.r[9] = ld32(c.r[15]); c.r[15] += 4; if (k) { goto L_060B7A0E; } }  // 060B7A00 bt/s 0x060B7A0E ; mov.l @r15+,r9
L_060B7A04:
    { const uint32_t x = c.r[0]; c.r[5] = ld32(c.r[9]); c.r[9] += 4; SH2_POLL(c); switch (x) { case 0x060B6DFEu: goto L_060B6DFE; case 0x060B6E00u: goto L_060B6E00; case 0x060B6E02u: goto L_060B6E02; case 0x060B6E04u: goto L_060B6E04; case 0x060B6E06u: goto L_060B6E06; case 0x060B6E08u: goto L_060B6E08; case 0x060B6E0Au: goto L_060B6E0A; case 0x060B6E0Cu: goto L_060B6E0C; case 0x060B6E0Eu: goto L_060B6E0E; case 0x060B6E10u: goto L_060B6E10; case 0x060B6E12u: goto L_060B6E12; case 0x060B6E14u: goto L_060B6E14; case 0x060B6E16u: goto L_060B6E16; case 0x060B6E18u: goto L_060B6E18; case 0x060B6E1Au: goto L_060B6E1A; case 0x060B6E1Cu: goto L_060B6E1C; case 0x060B6E1Eu: goto L_060B6E1E; case 0x060B6E20u: goto L_060B6E20; case 0x060B6E22u: goto L_060B6E22; case 0x060B6E24u: goto L_060B6E24; case 0x060B6E26u: goto L_060B6E26; case 0x060B6E28u: goto L_060B6E28; case 0x060B6E2Au: goto L_060B6E2A; case 0x060B6E2Cu: goto L_060B6E2C; case 0x060B6E2Eu: goto L_060B6E2E; case 0x060B6E30u: goto L_060B6E30; case 0x060B6E32u: goto L_060B6E32; case 0x060B6E34u: goto L_060B6E34; case 0x060B6E36u: goto L_060B6E36; case 0x060B6E38u: goto L_060B6E38; case 0x060B6E3Au: goto L_060B6E3A; case 0x060B6E3Cu: goto L_060B6E3C; case 0x060B6E3Eu: goto L_060B6E3E; case 0x060B6E40u: goto L_060B6E40; case 0x060B6E42u: goto L_060B6E42; case 0x060B6E44u: goto L_060B6E44; case 0x060B6E46u: goto L_060B6E46; case 0x060B6E48u: goto L_060B6E48; case 0x060B6E4Au: goto L_060B6E4A; case 0x060B6E4Cu: goto L_060B6E4C; case 0x060B6E4Eu: goto L_060B6E4E; case 0x060B6E50u: goto L_060B6E50; case 0x060B6E52u: goto L_060B6E52; case 0x060B6E54u: goto L_060B6E54; case 0x060B6E56u: goto L_060B6E56; case 0x060B6E58u: goto L_060B6E58; case 0x060B6E5Au: goto L_060B6E5A; case 0x060B6E5Cu: goto L_060B6E5C; case 0x060B6E5Eu: goto L_060B6E5E; case 0x060B6E60u: goto L_060B6E60; case 0x060B6E62u: goto L_060B6E62; case 0x060B6E64u: goto L_060B6E64; case 0x060B6E66u: goto L_060B6E66; case 0x060B6E68u: goto L_060B6E68; case 0x060B6E6Au: goto L_060B6E6A; case 0x060B6E6Eu: goto L_060B6E6E; case 0x060B6E70u: goto L_060B6E70; case 0x060B6E72u: goto L_060B6E72; case 0x060B6E76u: goto L_060B6E76; case 0x060B6E78u: goto L_060B6E78; case 0x060B6E7Cu: goto L_060B6E7C; case 0x060B6E7Eu: goto L_060B6E7E; case 0x060B6E80u: goto L_060B6E80; case 0x060B6E82u: goto L_060B6E82; case 0x060B6E84u: goto L_060B6E84; case 0x060B6E86u: goto L_060B6E86; case 0x060B6E88u: goto L_060B6E88; case 0x060B6E8Au: goto L_060B6E8A; case 0x060B6E8Eu: goto L_060B6E8E; case 0x060B6EBCu: goto L_060B6EBC; case 0x060B6EBEu: goto L_060B6EBE; case 0x060B6EC0u: goto L_060B6EC0; case 0x060B6EC2u: goto L_060B6EC2; case 0x060B6EC6u: goto L_060B6EC6; case 0x060B6EC8u: goto L_060B6EC8; case 0x060B6ECAu: goto L_060B6ECA; case 0x060B6ECCu: goto L_060B6ECC; case 0x060B6ECEu: goto L_060B6ECE; case 0x060B6ED0u: goto L_060B6ED0; case 0x060B7990u: goto L_060B7990; case 0x060B7992u: goto L_060B7992; case 0x060B7994u: goto L_060B7994; case 0x060B7996u: goto L_060B7996; case 0x060B7998u: goto L_060B7998; case 0x060B799Au: goto L_060B799A; case 0x060B799Cu: goto L_060B799C; case 0x060B799Eu: goto L_060B799E; case 0x060B79A0u: goto L_060B79A0; case 0x060B79A2u: goto L_060B79A2; case 0x060B79A4u: goto L_060B79A4; case 0x060B79A6u: goto L_060B79A6; case 0x060B79A8u: goto L_060B79A8; case 0x060B79AAu: goto L_060B79AA; case 0x060B79ACu: goto L_060B79AC; case 0x060B79AEu: goto L_060B79AE; case 0x060B79B0u: goto L_060B79B0; case 0x060B79B2u: goto L_060B79B2; case 0x060B79B4u: goto L_060B79B4; case 0x060B79B6u: goto L_060B79B6; case 0x060B79B8u: goto L_060B79B8; case 0x060B79BAu: goto L_060B79BA; case 0x060B79BCu: goto L_060B79BC; case 0x060B79BEu: goto L_060B79BE; case 0x060B79C0u: goto L_060B79C0; case 0x060B79C2u: goto L_060B79C2; case 0x060B79C4u: goto L_060B79C4; case 0x060B79C8u: goto L_060B79C8; case 0x060B79CAu: goto L_060B79CA; case 0x060B79CCu: goto L_060B79CC; case 0x060B79CEu: goto L_060B79CE; case 0x060B79D0u: goto L_060B79D0; case 0x060B79D2u: goto L_060B79D2; case 0x060B79D4u: goto L_060B79D4; case 0x060B79D6u: goto L_060B79D6; case 0x060B79D8u: goto L_060B79D8; case 0x060B79DAu: goto L_060B79DA; case 0x060B79DCu: goto L_060B79DC; case 0x060B79DEu: goto L_060B79DE; case 0x060B79E0u: goto L_060B79E0; case 0x060B79E2u: goto L_060B79E2; case 0x060B79E6u: goto L_060B79E6; case 0x060B79E8u: goto L_060B79E8; case 0x060B79EAu: goto L_060B79EA; case 0x060B79ECu: goto L_060B79EC; case 0x060B79EEu: goto L_060B79EE; case 0x060B79F0u: goto L_060B79F0; case 0x060B79F2u: goto L_060B79F2; case 0x060B79F4u: goto L_060B79F4; case 0x060B79F6u: goto L_060B79F6; case 0x060B79F8u: goto L_060B79F8; case 0x060B79FAu: goto L_060B79FA; case 0x060B79FCu: goto L_060B79FC; case 0x060B79FEu: goto L_060B79FE; case 0x060B7A00u: goto L_060B7A00; case 0x060B7A04u: goto L_060B7A04; case 0x060B7A0Eu: goto L_060B7A0E; case 0x060B7A10u: goto L_060B7A10; case 0x060B7A12u: goto L_060B7A12; case 0x060B7A14u: goto L_060B7A14; case 0x060B7A16u: goto L_060B7A16; case 0x060B7A48u: goto L_060B7A48; case 0x060B7A4Au: goto L_060B7A4A; case 0x060B7A4Cu: goto L_060B7A4C; case 0x060B7A4Eu: goto L_060B7A4E; case 0x060B7A50u: goto L_060B7A50; case 0x060B7A52u: goto L_060B7A52; case 0x060B7A54u: goto L_060B7A54; case 0x060B7A56u: goto L_060B7A56; case 0x060B7A58u: goto L_060B7A58; case 0x060B7B78u: goto L_060B7B78; case 0x060B7B7Au: goto L_060B7B7A; case 0x060B7B7Cu: goto L_060B7B7C; case 0x060B7B7Eu: goto L_060B7B7E; case 0x060B7B80u: goto L_060B7B80; case 0x060B7B82u: goto L_060B7B82; case 0x060B7B84u: goto L_060B7B84; case 0x060B7B86u: goto L_060B7B86; case 0x060B7B88u: goto L_060B7B88; case 0x060B7B8Au: goto L_060B7B8A; case 0x060B7B8Eu: goto L_060B7B8E; case 0x060B7B90u: goto L_060B7B90; case 0x060B7B92u: goto L_060B7B92; case 0x060B7B94u: goto L_060B7B94; case 0x060B7B96u: goto L_060B7B96; case 0x060B7B9Au: goto L_060B7B9A; case 0x060B7B9Cu: goto L_060B7B9C; case 0x060B7B9Eu: goto L_060B7B9E; case 0x060B7BA0u: goto L_060B7BA0; case 0x060B7BA2u: goto L_060B7BA2; case 0x060B7BA6u: goto L_060B7BA6; case 0x060B7BA8u: goto L_060B7BA8; case 0x060B7BAAu: goto L_060B7BAA; case 0x060B7BAEu: goto L_060B7BAE; case 0x060B7BB0u: goto L_060B7BB0; case 0x060B7BB2u: goto L_060B7BB2; case 0x060B7BB4u: goto L_060B7BB4; case 0x060B7BB6u: goto L_060B7BB6; case 0x060B7BBAu: goto L_060B7BBA; case 0x060B7BBCu: goto L_060B7BBC; case 0x060B7BBEu: goto L_060B7BBE; case 0x060B7BC0u: goto L_060B7BC0; case 0x060B7BC2u: goto L_060B7BC2; case 0x060B7BC6u: goto L_060B7BC6; case 0x060B7BC8u: goto L_060B7BC8; case 0x060B7BCAu: goto L_060B7BCA; case 0x060B7BCEu: goto L_060B7BCE; case 0x060B7BD0u: goto L_060B7BD0; case 0x060B7BD2u: goto L_060B7BD2; case 0x060B7BD4u: goto L_060B7BD4; case 0x060B7BD6u: goto L_060B7BD6; case 0x060B7BDAu: goto L_060B7BDA; case 0x060B7BDCu: goto L_060B7BDC; case 0x060B7BDEu: goto L_060B7BDE; case 0x060B7BE0u: goto L_060B7BE0; case 0x060B7BE2u: goto L_060B7BE2; case 0x060B7BE6u: goto L_060B7BE6; case 0x060B7BE8u: goto L_060B7BE8; case 0x060B7BEAu: goto L_060B7BEA; case 0x060B7BEEu: goto L_060B7BEE; case 0x060B7BF0u: goto L_060B7BF0; case 0x060B7BF2u: goto L_060B7BF2; case 0x060B7BF4u: goto L_060B7BF4; case 0x060B7BF6u: goto L_060B7BF6; case 0x060B7BFAu: goto L_060B7BFA; case 0x060B7BFCu: goto L_060B7BFC; case 0x060B7BFEu: goto L_060B7BFE; case 0x060B7C00u: goto L_060B7C00; case 0x060B7C02u: goto L_060B7C02; case 0x060B7C06u: goto L_060B7C06; case 0x060B7C08u: goto L_060B7C08; case 0x060B7C0Au: goto L_060B7C0A; case 0x060B7C0Cu: goto L_060B7C0C; case 0x060B7C0Eu: goto L_060B7C0E; case 0x060B7C12u: goto L_060B7C12; case 0x060B7C58u: goto L_060B7C58; case 0x060B7C5Au: goto L_060B7C5A; case 0x060B7C5Cu: goto L_060B7C5C; case 0x060B7C5Eu: goto L_060B7C5E; case 0x060B7C60u: goto L_060B7C60; case 0x060B7C62u: goto L_060B7C62; case 0x060B7C64u: goto L_060B7C64; case 0x060B7C66u: goto L_060B7C66; case 0x060B7C68u: goto L_060B7C68; case 0x060B7C6Cu: goto L_060B7C6C; case 0x060B7C6Eu: goto L_060B7C6E; case 0x060B7C70u: goto L_060B7C70; case 0x060B7C72u: goto L_060B7C72; case 0x060B7C74u: goto L_060B7C74; case 0x060B7C76u: goto L_060B7C76; case 0x060B7C78u: goto L_060B7C78; case 0x060B7C7Au: goto L_060B7C7A; case 0x060B7C7Cu: goto L_060B7C7C; case 0x060B7C80u: goto L_060B7C80; case 0x060B7C82u: goto L_060B7C82; case 0x060B7C84u: goto L_060B7C84; case 0x060B7C86u: goto L_060B7C86; case 0x060B7C88u: goto L_060B7C88; case 0x060B7C8Au: goto L_060B7C8A; default: sh2_call(c, x); return; } }  // 060B7A04 jmp @r0 ; mov.l @r9+,r5
L_060B7A0E:
    c.r[5] = ld32(c.r[9]); c.r[9] += 4;  // 060B7A0E mov.l @r9+,r5
L_060B7A10:
    st32(c.r[11] + 12, c.r[1]);  // 060B7A10 mov.l r1,@(12,r11)
L_060B7A12:
    st32(c.r[11] + 16, c.r[2]);  // 060B7A12 mov.l r2,@(16,r11)
L_060B7A14:
    st32(c.r[11] + 20, c.r[3]);  // 060B7A14 mov.l r3,@(20,r11)
L_060B7A16:
    { const uint32_t x = c.r[5]; st32(c.r[11] + 24, c.r[4]); SH2_POLL(c); switch (x) { case 0x060B6DFEu: goto L_060B6DFE; case 0x060B6E00u: goto L_060B6E00; case 0x060B6E02u: goto L_060B6E02; case 0x060B6E04u: goto L_060B6E04; case 0x060B6E06u: goto L_060B6E06; case 0x060B6E08u: goto L_060B6E08; case 0x060B6E0Au: goto L_060B6E0A; case 0x060B6E0Cu: goto L_060B6E0C; case 0x060B6E0Eu: goto L_060B6E0E; case 0x060B6E10u: goto L_060B6E10; case 0x060B6E12u: goto L_060B6E12; case 0x060B6E14u: goto L_060B6E14; case 0x060B6E16u: goto L_060B6E16; case 0x060B6E18u: goto L_060B6E18; case 0x060B6E1Au: goto L_060B6E1A; case 0x060B6E1Cu: goto L_060B6E1C; case 0x060B6E1Eu: goto L_060B6E1E; case 0x060B6E20u: goto L_060B6E20; case 0x060B6E22u: goto L_060B6E22; case 0x060B6E24u: goto L_060B6E24; case 0x060B6E26u: goto L_060B6E26; case 0x060B6E28u: goto L_060B6E28; case 0x060B6E2Au: goto L_060B6E2A; case 0x060B6E2Cu: goto L_060B6E2C; case 0x060B6E2Eu: goto L_060B6E2E; case 0x060B6E30u: goto L_060B6E30; case 0x060B6E32u: goto L_060B6E32; case 0x060B6E34u: goto L_060B6E34; case 0x060B6E36u: goto L_060B6E36; case 0x060B6E38u: goto L_060B6E38; case 0x060B6E3Au: goto L_060B6E3A; case 0x060B6E3Cu: goto L_060B6E3C; case 0x060B6E3Eu: goto L_060B6E3E; case 0x060B6E40u: goto L_060B6E40; case 0x060B6E42u: goto L_060B6E42; case 0x060B6E44u: goto L_060B6E44; case 0x060B6E46u: goto L_060B6E46; case 0x060B6E48u: goto L_060B6E48; case 0x060B6E4Au: goto L_060B6E4A; case 0x060B6E4Cu: goto L_060B6E4C; case 0x060B6E4Eu: goto L_060B6E4E; case 0x060B6E50u: goto L_060B6E50; case 0x060B6E52u: goto L_060B6E52; case 0x060B6E54u: goto L_060B6E54; case 0x060B6E56u: goto L_060B6E56; case 0x060B6E58u: goto L_060B6E58; case 0x060B6E5Au: goto L_060B6E5A; case 0x060B6E5Cu: goto L_060B6E5C; case 0x060B6E5Eu: goto L_060B6E5E; case 0x060B6E60u: goto L_060B6E60; case 0x060B6E62u: goto L_060B6E62; case 0x060B6E64u: goto L_060B6E64; case 0x060B6E66u: goto L_060B6E66; case 0x060B6E68u: goto L_060B6E68; case 0x060B6E6Au: goto L_060B6E6A; case 0x060B6E6Eu: goto L_060B6E6E; case 0x060B6E70u: goto L_060B6E70; case 0x060B6E72u: goto L_060B6E72; case 0x060B6E76u: goto L_060B6E76; case 0x060B6E78u: goto L_060B6E78; case 0x060B6E7Cu: goto L_060B6E7C; case 0x060B6E7Eu: goto L_060B6E7E; case 0x060B6E80u: goto L_060B6E80; case 0x060B6E82u: goto L_060B6E82; case 0x060B6E84u: goto L_060B6E84; case 0x060B6E86u: goto L_060B6E86; case 0x060B6E88u: goto L_060B6E88; case 0x060B6E8Au: goto L_060B6E8A; case 0x060B6E8Eu: goto L_060B6E8E; case 0x060B6EBCu: goto L_060B6EBC; case 0x060B6EBEu: goto L_060B6EBE; case 0x060B6EC0u: goto L_060B6EC0; case 0x060B6EC2u: goto L_060B6EC2; case 0x060B6EC6u: goto L_060B6EC6; case 0x060B6EC8u: goto L_060B6EC8; case 0x060B6ECAu: goto L_060B6ECA; case 0x060B6ECCu: goto L_060B6ECC; case 0x060B6ECEu: goto L_060B6ECE; case 0x060B6ED0u: goto L_060B6ED0; case 0x060B7990u: goto L_060B7990; case 0x060B7992u: goto L_060B7992; case 0x060B7994u: goto L_060B7994; case 0x060B7996u: goto L_060B7996; case 0x060B7998u: goto L_060B7998; case 0x060B799Au: goto L_060B799A; case 0x060B799Cu: goto L_060B799C; case 0x060B799Eu: goto L_060B799E; case 0x060B79A0u: goto L_060B79A0; case 0x060B79A2u: goto L_060B79A2; case 0x060B79A4u: goto L_060B79A4; case 0x060B79A6u: goto L_060B79A6; case 0x060B79A8u: goto L_060B79A8; case 0x060B79AAu: goto L_060B79AA; case 0x060B79ACu: goto L_060B79AC; case 0x060B79AEu: goto L_060B79AE; case 0x060B79B0u: goto L_060B79B0; case 0x060B79B2u: goto L_060B79B2; case 0x060B79B4u: goto L_060B79B4; case 0x060B79B6u: goto L_060B79B6; case 0x060B79B8u: goto L_060B79B8; case 0x060B79BAu: goto L_060B79BA; case 0x060B79BCu: goto L_060B79BC; case 0x060B79BEu: goto L_060B79BE; case 0x060B79C0u: goto L_060B79C0; case 0x060B79C2u: goto L_060B79C2; case 0x060B79C4u: goto L_060B79C4; case 0x060B79C8u: goto L_060B79C8; case 0x060B79CAu: goto L_060B79CA; case 0x060B79CCu: goto L_060B79CC; case 0x060B79CEu: goto L_060B79CE; case 0x060B79D0u: goto L_060B79D0; case 0x060B79D2u: goto L_060B79D2; case 0x060B79D4u: goto L_060B79D4; case 0x060B79D6u: goto L_060B79D6; case 0x060B79D8u: goto L_060B79D8; case 0x060B79DAu: goto L_060B79DA; case 0x060B79DCu: goto L_060B79DC; case 0x060B79DEu: goto L_060B79DE; case 0x060B79E0u: goto L_060B79E0; case 0x060B79E2u: goto L_060B79E2; case 0x060B79E6u: goto L_060B79E6; case 0x060B79E8u: goto L_060B79E8; case 0x060B79EAu: goto L_060B79EA; case 0x060B79ECu: goto L_060B79EC; case 0x060B79EEu: goto L_060B79EE; case 0x060B79F0u: goto L_060B79F0; case 0x060B79F2u: goto L_060B79F2; case 0x060B79F4u: goto L_060B79F4; case 0x060B79F6u: goto L_060B79F6; case 0x060B79F8u: goto L_060B79F8; case 0x060B79FAu: goto L_060B79FA; case 0x060B79FCu: goto L_060B79FC; case 0x060B79FEu: goto L_060B79FE; case 0x060B7A00u: goto L_060B7A00; case 0x060B7A04u: goto L_060B7A04; case 0x060B7A0Eu: goto L_060B7A0E; case 0x060B7A10u: goto L_060B7A10; case 0x060B7A12u: goto L_060B7A12; case 0x060B7A14u: goto L_060B7A14; case 0x060B7A16u: goto L_060B7A16; case 0x060B7A48u: goto L_060B7A48; case 0x060B7A4Au: goto L_060B7A4A; case 0x060B7A4Cu: goto L_060B7A4C; case 0x060B7A4Eu: goto L_060B7A4E; case 0x060B7A50u: goto L_060B7A50; case 0x060B7A52u: goto L_060B7A52; case 0x060B7A54u: goto L_060B7A54; case 0x060B7A56u: goto L_060B7A56; case 0x060B7A58u: goto L_060B7A58; case 0x060B7B78u: goto L_060B7B78; case 0x060B7B7Au: goto L_060B7B7A; case 0x060B7B7Cu: goto L_060B7B7C; case 0x060B7B7Eu: goto L_060B7B7E; case 0x060B7B80u: goto L_060B7B80; case 0x060B7B82u: goto L_060B7B82; case 0x060B7B84u: goto L_060B7B84; case 0x060B7B86u: goto L_060B7B86; case 0x060B7B88u: goto L_060B7B88; case 0x060B7B8Au: goto L_060B7B8A; case 0x060B7B8Eu: goto L_060B7B8E; case 0x060B7B90u: goto L_060B7B90; case 0x060B7B92u: goto L_060B7B92; case 0x060B7B94u: goto L_060B7B94; case 0x060B7B96u: goto L_060B7B96; case 0x060B7B9Au: goto L_060B7B9A; case 0x060B7B9Cu: goto L_060B7B9C; case 0x060B7B9Eu: goto L_060B7B9E; case 0x060B7BA0u: goto L_060B7BA0; case 0x060B7BA2u: goto L_060B7BA2; case 0x060B7BA6u: goto L_060B7BA6; case 0x060B7BA8u: goto L_060B7BA8; case 0x060B7BAAu: goto L_060B7BAA; case 0x060B7BAEu: goto L_060B7BAE; case 0x060B7BB0u: goto L_060B7BB0; case 0x060B7BB2u: goto L_060B7BB2; case 0x060B7BB4u: goto L_060B7BB4; case 0x060B7BB6u: goto L_060B7BB6; case 0x060B7BBAu: goto L_060B7BBA; case 0x060B7BBCu: goto L_060B7BBC; case 0x060B7BBEu: goto L_060B7BBE; case 0x060B7BC0u: goto L_060B7BC0; case 0x060B7BC2u: goto L_060B7BC2; case 0x060B7BC6u: goto L_060B7BC6; case 0x060B7BC8u: goto L_060B7BC8; case 0x060B7BCAu: goto L_060B7BCA; case 0x060B7BCEu: goto L_060B7BCE; case 0x060B7BD0u: goto L_060B7BD0; case 0x060B7BD2u: goto L_060B7BD2; case 0x060B7BD4u: goto L_060B7BD4; case 0x060B7BD6u: goto L_060B7BD6; case 0x060B7BDAu: goto L_060B7BDA; case 0x060B7BDCu: goto L_060B7BDC; case 0x060B7BDEu: goto L_060B7BDE; case 0x060B7BE0u: goto L_060B7BE0; case 0x060B7BE2u: goto L_060B7BE2; case 0x060B7BE6u: goto L_060B7BE6; case 0x060B7BE8u: goto L_060B7BE8; case 0x060B7BEAu: goto L_060B7BEA; case 0x060B7BEEu: goto L_060B7BEE; case 0x060B7BF0u: goto L_060B7BF0; case 0x060B7BF2u: goto L_060B7BF2; case 0x060B7BF4u: goto L_060B7BF4; case 0x060B7BF6u: goto L_060B7BF6; case 0x060B7BFAu: goto L_060B7BFA; case 0x060B7BFCu: goto L_060B7BFC; case 0x060B7BFEu: goto L_060B7BFE; case 0x060B7C00u: goto L_060B7C00; case 0x060B7C02u: goto L_060B7C02; case 0x060B7C06u: goto L_060B7C06; case 0x060B7C08u: goto L_060B7C08; case 0x060B7C0Au: goto L_060B7C0A; case 0x060B7C0Cu: goto L_060B7C0C; case 0x060B7C0Eu: goto L_060B7C0E; case 0x060B7C12u: goto L_060B7C12; case 0x060B7C58u: goto L_060B7C58; case 0x060B7C5Au: goto L_060B7C5A; case 0x060B7C5Cu: goto L_060B7C5C; case 0x060B7C5Eu: goto L_060B7C5E; case 0x060B7C60u: goto L_060B7C60; case 0x060B7C62u: goto L_060B7C62; case 0x060B7C64u: goto L_060B7C64; case 0x060B7C66u: goto L_060B7C66; case 0x060B7C68u: goto L_060B7C68; case 0x060B7C6Cu: goto L_060B7C6C; case 0x060B7C6Eu: goto L_060B7C6E; case 0x060B7C70u: goto L_060B7C70; case 0x060B7C72u: goto L_060B7C72; case 0x060B7C74u: goto L_060B7C74; case 0x060B7C76u: goto L_060B7C76; case 0x060B7C78u: goto L_060B7C78; case 0x060B7C7Au: goto L_060B7C7A; case 0x060B7C7Cu: goto L_060B7C7C; case 0x060B7C80u: goto L_060B7C80; case 0x060B7C82u: goto L_060B7C82; case 0x060B7C84u: goto L_060B7C84; case 0x060B7C86u: goto L_060B7C86; case 0x060B7C88u: goto L_060B7C88; case 0x060B7C8Au: goto L_060B7C8A; default: sh2_call(c, x); return; } }  // 060B7A16 jmp @r5 ; mov.l r4,@(24,r11)
L_060B7A48:
    c.r[15] += 4;  // 060B7A48 add #4,r15
L_060B7A4A:
    c.r[5] = ld32(c.r[9]); c.r[9] += 4;  // 060B7A4A mov.l @r9+,r5
L_060B7A4C:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[11]);  // 060B7A4C mov.w @(0,r11),r0
L_060B7A4E:
    st32(c.r[11] + 24, c.r[1]);  // 060B7A4E mov.l r1,@(24,r11)
L_060B7A50:
    c.r[0] ^= 0x20u;  // 060B7A50 xor #32,r0
L_060B7A52:
    st16(c.r[11], c.r[0]);  // 060B7A52 mov.w r0,@(0,r11)
L_060B7A54:
    st32(c.r[11] + 20, c.r[2]);  // 060B7A54 mov.l r2,@(20,r11)
L_060B7A56:
    st32(c.r[11] + 16, c.r[3]);  // 060B7A56 mov.l r3,@(16,r11)
L_060B7A58:
    { const uint32_t x = c.r[5]; st32(c.r[11] + 12, c.r[4]); SH2_POLL(c); switch (x) { case 0x060B6DFEu: goto L_060B6DFE; case 0x060B6E00u: goto L_060B6E00; case 0x060B6E02u: goto L_060B6E02; case 0x060B6E04u: goto L_060B6E04; case 0x060B6E06u: goto L_060B6E06; case 0x060B6E08u: goto L_060B6E08; case 0x060B6E0Au: goto L_060B6E0A; case 0x060B6E0Cu: goto L_060B6E0C; case 0x060B6E0Eu: goto L_060B6E0E; case 0x060B6E10u: goto L_060B6E10; case 0x060B6E12u: goto L_060B6E12; case 0x060B6E14u: goto L_060B6E14; case 0x060B6E16u: goto L_060B6E16; case 0x060B6E18u: goto L_060B6E18; case 0x060B6E1Au: goto L_060B6E1A; case 0x060B6E1Cu: goto L_060B6E1C; case 0x060B6E1Eu: goto L_060B6E1E; case 0x060B6E20u: goto L_060B6E20; case 0x060B6E22u: goto L_060B6E22; case 0x060B6E24u: goto L_060B6E24; case 0x060B6E26u: goto L_060B6E26; case 0x060B6E28u: goto L_060B6E28; case 0x060B6E2Au: goto L_060B6E2A; case 0x060B6E2Cu: goto L_060B6E2C; case 0x060B6E2Eu: goto L_060B6E2E; case 0x060B6E30u: goto L_060B6E30; case 0x060B6E32u: goto L_060B6E32; case 0x060B6E34u: goto L_060B6E34; case 0x060B6E36u: goto L_060B6E36; case 0x060B6E38u: goto L_060B6E38; case 0x060B6E3Au: goto L_060B6E3A; case 0x060B6E3Cu: goto L_060B6E3C; case 0x060B6E3Eu: goto L_060B6E3E; case 0x060B6E40u: goto L_060B6E40; case 0x060B6E42u: goto L_060B6E42; case 0x060B6E44u: goto L_060B6E44; case 0x060B6E46u: goto L_060B6E46; case 0x060B6E48u: goto L_060B6E48; case 0x060B6E4Au: goto L_060B6E4A; case 0x060B6E4Cu: goto L_060B6E4C; case 0x060B6E4Eu: goto L_060B6E4E; case 0x060B6E50u: goto L_060B6E50; case 0x060B6E52u: goto L_060B6E52; case 0x060B6E54u: goto L_060B6E54; case 0x060B6E56u: goto L_060B6E56; case 0x060B6E58u: goto L_060B6E58; case 0x060B6E5Au: goto L_060B6E5A; case 0x060B6E5Cu: goto L_060B6E5C; case 0x060B6E5Eu: goto L_060B6E5E; case 0x060B6E60u: goto L_060B6E60; case 0x060B6E62u: goto L_060B6E62; case 0x060B6E64u: goto L_060B6E64; case 0x060B6E66u: goto L_060B6E66; case 0x060B6E68u: goto L_060B6E68; case 0x060B6E6Au: goto L_060B6E6A; case 0x060B6E6Eu: goto L_060B6E6E; case 0x060B6E70u: goto L_060B6E70; case 0x060B6E72u: goto L_060B6E72; case 0x060B6E76u: goto L_060B6E76; case 0x060B6E78u: goto L_060B6E78; case 0x060B6E7Cu: goto L_060B6E7C; case 0x060B6E7Eu: goto L_060B6E7E; case 0x060B6E80u: goto L_060B6E80; case 0x060B6E82u: goto L_060B6E82; case 0x060B6E84u: goto L_060B6E84; case 0x060B6E86u: goto L_060B6E86; case 0x060B6E88u: goto L_060B6E88; case 0x060B6E8Au: goto L_060B6E8A; case 0x060B6E8Eu: goto L_060B6E8E; case 0x060B6EBCu: goto L_060B6EBC; case 0x060B6EBEu: goto L_060B6EBE; case 0x060B6EC0u: goto L_060B6EC0; case 0x060B6EC2u: goto L_060B6EC2; case 0x060B6EC6u: goto L_060B6EC6; case 0x060B6EC8u: goto L_060B6EC8; case 0x060B6ECAu: goto L_060B6ECA; case 0x060B6ECCu: goto L_060B6ECC; case 0x060B6ECEu: goto L_060B6ECE; case 0x060B6ED0u: goto L_060B6ED0; case 0x060B7990u: goto L_060B7990; case 0x060B7992u: goto L_060B7992; case 0x060B7994u: goto L_060B7994; case 0x060B7996u: goto L_060B7996; case 0x060B7998u: goto L_060B7998; case 0x060B799Au: goto L_060B799A; case 0x060B799Cu: goto L_060B799C; case 0x060B799Eu: goto L_060B799E; case 0x060B79A0u: goto L_060B79A0; case 0x060B79A2u: goto L_060B79A2; case 0x060B79A4u: goto L_060B79A4; case 0x060B79A6u: goto L_060B79A6; case 0x060B79A8u: goto L_060B79A8; case 0x060B79AAu: goto L_060B79AA; case 0x060B79ACu: goto L_060B79AC; case 0x060B79AEu: goto L_060B79AE; case 0x060B79B0u: goto L_060B79B0; case 0x060B79B2u: goto L_060B79B2; case 0x060B79B4u: goto L_060B79B4; case 0x060B79B6u: goto L_060B79B6; case 0x060B79B8u: goto L_060B79B8; case 0x060B79BAu: goto L_060B79BA; case 0x060B79BCu: goto L_060B79BC; case 0x060B79BEu: goto L_060B79BE; case 0x060B79C0u: goto L_060B79C0; case 0x060B79C2u: goto L_060B79C2; case 0x060B79C4u: goto L_060B79C4; case 0x060B79C8u: goto L_060B79C8; case 0x060B79CAu: goto L_060B79CA; case 0x060B79CCu: goto L_060B79CC; case 0x060B79CEu: goto L_060B79CE; case 0x060B79D0u: goto L_060B79D0; case 0x060B79D2u: goto L_060B79D2; case 0x060B79D4u: goto L_060B79D4; case 0x060B79D6u: goto L_060B79D6; case 0x060B79D8u: goto L_060B79D8; case 0x060B79DAu: goto L_060B79DA; case 0x060B79DCu: goto L_060B79DC; case 0x060B79DEu: goto L_060B79DE; case 0x060B79E0u: goto L_060B79E0; case 0x060B79E2u: goto L_060B79E2; case 0x060B79E6u: goto L_060B79E6; case 0x060B79E8u: goto L_060B79E8; case 0x060B79EAu: goto L_060B79EA; case 0x060B79ECu: goto L_060B79EC; case 0x060B79EEu: goto L_060B79EE; case 0x060B79F0u: goto L_060B79F0; case 0x060B79F2u: goto L_060B79F2; case 0x060B79F4u: goto L_060B79F4; case 0x060B79F6u: goto L_060B79F6; case 0x060B79F8u: goto L_060B79F8; case 0x060B79FAu: goto L_060B79FA; case 0x060B79FCu: goto L_060B79FC; case 0x060B79FEu: goto L_060B79FE; case 0x060B7A00u: goto L_060B7A00; case 0x060B7A04u: goto L_060B7A04; case 0x060B7A0Eu: goto L_060B7A0E; case 0x060B7A10u: goto L_060B7A10; case 0x060B7A12u: goto L_060B7A12; case 0x060B7A14u: goto L_060B7A14; case 0x060B7A16u: goto L_060B7A16; case 0x060B7A48u: goto L_060B7A48; case 0x060B7A4Au: goto L_060B7A4A; case 0x060B7A4Cu: goto L_060B7A4C; case 0x060B7A4Eu: goto L_060B7A4E; case 0x060B7A50u: goto L_060B7A50; case 0x060B7A52u: goto L_060B7A52; case 0x060B7A54u: goto L_060B7A54; case 0x060B7A56u: goto L_060B7A56; case 0x060B7A58u: goto L_060B7A58; case 0x060B7B78u: goto L_060B7B78; case 0x060B7B7Au: goto L_060B7B7A; case 0x060B7B7Cu: goto L_060B7B7C; case 0x060B7B7Eu: goto L_060B7B7E; case 0x060B7B80u: goto L_060B7B80; case 0x060B7B82u: goto L_060B7B82; case 0x060B7B84u: goto L_060B7B84; case 0x060B7B86u: goto L_060B7B86; case 0x060B7B88u: goto L_060B7B88; case 0x060B7B8Au: goto L_060B7B8A; case 0x060B7B8Eu: goto L_060B7B8E; case 0x060B7B90u: goto L_060B7B90; case 0x060B7B92u: goto L_060B7B92; case 0x060B7B94u: goto L_060B7B94; case 0x060B7B96u: goto L_060B7B96; case 0x060B7B9Au: goto L_060B7B9A; case 0x060B7B9Cu: goto L_060B7B9C; case 0x060B7B9Eu: goto L_060B7B9E; case 0x060B7BA0u: goto L_060B7BA0; case 0x060B7BA2u: goto L_060B7BA2; case 0x060B7BA6u: goto L_060B7BA6; case 0x060B7BA8u: goto L_060B7BA8; case 0x060B7BAAu: goto L_060B7BAA; case 0x060B7BAEu: goto L_060B7BAE; case 0x060B7BB0u: goto L_060B7BB0; case 0x060B7BB2u: goto L_060B7BB2; case 0x060B7BB4u: goto L_060B7BB4; case 0x060B7BB6u: goto L_060B7BB6; case 0x060B7BBAu: goto L_060B7BBA; case 0x060B7BBCu: goto L_060B7BBC; case 0x060B7BBEu: goto L_060B7BBE; case 0x060B7BC0u: goto L_060B7BC0; case 0x060B7BC2u: goto L_060B7BC2; case 0x060B7BC6u: goto L_060B7BC6; case 0x060B7BC8u: goto L_060B7BC8; case 0x060B7BCAu: goto L_060B7BCA; case 0x060B7BCEu: goto L_060B7BCE; case 0x060B7BD0u: goto L_060B7BD0; case 0x060B7BD2u: goto L_060B7BD2; case 0x060B7BD4u: goto L_060B7BD4; case 0x060B7BD6u: goto L_060B7BD6; case 0x060B7BDAu: goto L_060B7BDA; case 0x060B7BDCu: goto L_060B7BDC; case 0x060B7BDEu: goto L_060B7BDE; case 0x060B7BE0u: goto L_060B7BE0; case 0x060B7BE2u: goto L_060B7BE2; case 0x060B7BE6u: goto L_060B7BE6; case 0x060B7BE8u: goto L_060B7BE8; case 0x060B7BEAu: goto L_060B7BEA; case 0x060B7BEEu: goto L_060B7BEE; case 0x060B7BF0u: goto L_060B7BF0; case 0x060B7BF2u: goto L_060B7BF2; case 0x060B7BF4u: goto L_060B7BF4; case 0x060B7BF6u: goto L_060B7BF6; case 0x060B7BFAu: goto L_060B7BFA; case 0x060B7BFCu: goto L_060B7BFC; case 0x060B7BFEu: goto L_060B7BFE; case 0x060B7C00u: goto L_060B7C00; case 0x060B7C02u: goto L_060B7C02; case 0x060B7C06u: goto L_060B7C06; case 0x060B7C08u: goto L_060B7C08; case 0x060B7C0Au: goto L_060B7C0A; case 0x060B7C0Cu: goto L_060B7C0C; case 0x060B7C0Eu: goto L_060B7C0E; case 0x060B7C12u: goto L_060B7C12; case 0x060B7C58u: goto L_060B7C58; case 0x060B7C5Au: goto L_060B7C5A; case 0x060B7C5Cu: goto L_060B7C5C; case 0x060B7C5Eu: goto L_060B7C5E; case 0x060B7C60u: goto L_060B7C60; case 0x060B7C62u: goto L_060B7C62; case 0x060B7C64u: goto L_060B7C64; case 0x060B7C66u: goto L_060B7C66; case 0x060B7C68u: goto L_060B7C68; case 0x060B7C6Cu: goto L_060B7C6C; case 0x060B7C6Eu: goto L_060B7C6E; case 0x060B7C70u: goto L_060B7C70; case 0x060B7C72u: goto L_060B7C72; case 0x060B7C74u: goto L_060B7C74; case 0x060B7C76u: goto L_060B7C76; case 0x060B7C78u: goto L_060B7C78; case 0x060B7C7Au: goto L_060B7C7A; case 0x060B7C7Cu: goto L_060B7C7C; case 0x060B7C80u: goto L_060B7C80; case 0x060B7C82u: goto L_060B7C82; case 0x060B7C84u: goto L_060B7C84; case 0x060B7C86u: goto L_060B7C86; case 0x060B7C88u: goto L_060B7C88; case 0x060B7C8Au: goto L_060B7C8A; default: sh2_call(c, x); return; } }  // 060B7A58 jmp @r5 ; mov.l r4,@(12,r11)
L_060B7B78:
    c.r[0] = ld32(c.gbr + 156);  // 060B7B78 mov.l @(156,gbr),r0
L_060B7B7A:
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060B7B7A mov.l r9,@-r15
L_060B7B7C:
    c.r[13] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B7B7C exts.w r0,r13
L_060B7B7E:
    c.r[12] = c.r[0] << 16 | c.r[0] >> 16;  // 060B7B7E swap.w r0,r12
L_060B7B80:
    c.r[0] = ld32(c.r[1] + 4);  // 060B7B80 mov.l @(4,r1),r0
L_060B7B82:
    c.r[5] = 0x0u;  // 060B7B82 mov #0,r5
L_060B7B84:
    c.r[1] = ld32(c.r[1]);  // 060B7B84 mov.l @(0,r1),r1
L_060B7B86:
    c.r[12] = (uint32_t)(int32_t)(int16_t)c.r[12];  // 060B7B86 exts.w r12,r12
L_060B7B88:
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060B7B88 shlr r0
L_060B7B8A:
    { const bool k = !c.t; { uint64_t s = (uint64_t)c.r[5] + c.r[5] + c.t; c.t = (uint32_t)(s >> 32); c.r[5] = (uint32_t)s; } if (k) { goto L_060B7BA4; } }  // 060B7B8A bf/s 0x060B7BA4 ; addc r5,r5
L_060B7B8E:
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 142);  // 060B7B8E mov.w @(142,gbr),r0
L_060B7B90:
    c.r[9] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 060B7B90 exts.w r1,r9
L_060B7B92:
    c.r[9] += c.r[13];  // 060B7B92 add r13,r9
L_060B7B94:
    c.t = c.r[9] >= c.r[0];  // 060B7B94 cmp/hs r0,r9
L_060B7B96:
    { const bool k = c.t; c.r[9] = c.r[1] << 16 | c.r[1] >> 16; if (k) { goto L_060B7C12; } }  // 060B7B96 bt/s 0x060B7C12 ; swap.w r1,r9
L_060B7B9A:
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 140);  // 060B7B9A mov.w @(140,gbr),r0
L_060B7B9C:
    c.r[9] = (uint32_t)(int32_t)(int16_t)c.r[9];  // 060B7B9C exts.w r9,r9
L_060B7B9E:
    c.r[9] += c.r[12];  // 060B7B9E add r12,r9
L_060B7BA0:
    c.t = c.r[9] >= c.r[0];  // 060B7BA0 cmp/hs r0,r9
L_060B7BA2:
    { const bool k = c.t; c.r[0] = ld32(c.r[2] + 4); if (k) { goto L_060B7C12; } }  // 060B7BA2 bt/s 0x060B7C12 ; mov.l @(4,r2),r0
    goto L_060B7BA6;
L_060B7BA4:
    c.r[0] = ld32(c.r[2] + 4);  // 060B7BA4 mov.l @(4,r2),r0
L_060B7BA6:
    c.r[2] = ld32(c.r[2]);  // 060B7BA6 mov.l @(0,r2),r2
L_060B7BA8:
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060B7BA8 shlr r0
L_060B7BAA:
    { const bool k = !c.t; { uint64_t s = (uint64_t)c.r[5] + c.r[5] + c.t; c.t = (uint32_t)(s >> 32); c.r[5] = (uint32_t)s; } if (k) { goto L_060B7BC4; } }  // 060B7BAA bf/s 0x060B7BC4 ; addc r5,r5
L_060B7BAE:
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 142);  // 060B7BAE mov.w @(142,gbr),r0
L_060B7BB0:
    c.r[9] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 060B7BB0 exts.w r2,r9
L_060B7BB2:
    c.r[9] += c.r[13];  // 060B7BB2 add r13,r9
L_060B7BB4:
    c.t = c.r[9] >= c.r[0];  // 060B7BB4 cmp/hs r0,r9
L_060B7BB6:
    { const bool k = c.t; c.r[9] = c.r[2] << 16 | c.r[2] >> 16; if (k) { goto L_060B7C12; } }  // 060B7BB6 bt/s 0x060B7C12 ; swap.w r2,r9
L_060B7BBA:
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 140);  // 060B7BBA mov.w @(140,gbr),r0
L_060B7BBC:
    c.r[9] = (uint32_t)(int32_t)(int16_t)c.r[9];  // 060B7BBC exts.w r9,r9
L_060B7BBE:
    c.r[9] += c.r[12];  // 060B7BBE add r12,r9
L_060B7BC0:
    c.t = c.r[9] >= c.r[0];  // 060B7BC0 cmp/hs r0,r9
L_060B7BC2:
    { const bool k = c.t; c.r[0] = ld32(c.r[3] + 4); if (k) { goto L_060B7C12; } }  // 060B7BC2 bt/s 0x060B7C12 ; mov.l @(4,r3),r0
    goto L_060B7BC6;
L_060B7BC4:
    c.r[0] = ld32(c.r[3] + 4);  // 060B7BC4 mov.l @(4,r3),r0
L_060B7BC6:
    c.r[3] = ld32(c.r[3]);  // 060B7BC6 mov.l @(0,r3),r3
L_060B7BC8:
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060B7BC8 shlr r0
L_060B7BCA:
    { const bool k = !c.t; { uint64_t s = (uint64_t)c.r[5] + c.r[5] + c.t; c.t = (uint32_t)(s >> 32); c.r[5] = (uint32_t)s; } if (k) { goto L_060B7BE4; } }  // 060B7BCA bf/s 0x060B7BE4 ; addc r5,r5
L_060B7BCE:
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 142);  // 060B7BCE mov.w @(142,gbr),r0
L_060B7BD0:
    c.r[9] = (uint32_t)(int32_t)(int16_t)c.r[3];  // 060B7BD0 exts.w r3,r9
L_060B7BD2:
    c.r[9] += c.r[13];  // 060B7BD2 add r13,r9
L_060B7BD4:
    c.t = c.r[9] >= c.r[0];  // 060B7BD4 cmp/hs r0,r9
L_060B7BD6:
    { const bool k = c.t; c.r[9] = c.r[3] << 16 | c.r[3] >> 16; if (k) { goto L_060B7C12; } }  // 060B7BD6 bt/s 0x060B7C12 ; swap.w r3,r9
L_060B7BDA:
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 140);  // 060B7BDA mov.w @(140,gbr),r0
L_060B7BDC:
    c.r[9] = (uint32_t)(int32_t)(int16_t)c.r[9];  // 060B7BDC exts.w r9,r9
L_060B7BDE:
    c.r[9] += c.r[12];  // 060B7BDE add r12,r9
L_060B7BE0:
    c.t = c.r[9] >= c.r[0];  // 060B7BE0 cmp/hs r0,r9
L_060B7BE2:
    { const bool k = c.t; c.r[0] = ld32(c.r[4] + 4); if (k) { goto L_060B7C12; } }  // 060B7BE2 bt/s 0x060B7C12 ; mov.l @(4,r4),r0
    goto L_060B7BE6;
L_060B7BE4:
    c.r[0] = ld32(c.r[4] + 4);  // 060B7BE4 mov.l @(4,r4),r0
L_060B7BE6:
    c.r[4] = ld32(c.r[4]);  // 060B7BE6 mov.l @(0,r4),r4
L_060B7BE8:
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060B7BE8 shlr r0
L_060B7BEA:
    { const bool k = !c.t; { uint64_t s = (uint64_t)c.r[5] + c.r[5] + c.t; c.t = (uint32_t)(s >> 32); c.r[5] = (uint32_t)s; } if (k) { goto L_060B7C04; } }  // 060B7BEA bf/s 0x060B7C04 ; addc r5,r5
L_060B7BEE:
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 142);  // 060B7BEE mov.w @(142,gbr),r0
L_060B7BF0:
    c.r[9] = (uint32_t)(int32_t)(int16_t)c.r[4];  // 060B7BF0 exts.w r4,r9
L_060B7BF2:
    c.r[9] += c.r[13];  // 060B7BF2 add r13,r9
L_060B7BF4:
    c.t = c.r[9] >= c.r[0];  // 060B7BF4 cmp/hs r0,r9
L_060B7BF6:
    { const bool k = c.t; c.r[9] = c.r[4] << 16 | c.r[4] >> 16; if (k) { goto L_060B7C12; } }  // 060B7BF6 bt/s 0x060B7C12 ; swap.w r4,r9
L_060B7BFA:
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 140);  // 060B7BFA mov.w @(140,gbr),r0
L_060B7BFC:
    c.r[9] = (uint32_t)(int32_t)(int16_t)c.r[9];  // 060B7BFC exts.w r9,r9
L_060B7BFE:
    c.r[9] += c.r[12];  // 060B7BFE add r12,r9
L_060B7C00:
    c.t = c.r[9] >= c.r[0];  // 060B7C00 cmp/hs r0,r9
L_060B7C02:
    { const bool k = c.t; c.r[5] = 0x0u; if (k) { goto L_060B7C12; } }  // 060B7C02 bt/s 0x060B7C12 ; mov #0,r5
    goto L_060B7C06;
L_060B7C04:
    c.r[5] = 0x0u;  // 060B7C04 mov #0,r5
L_060B7C06:
    c.r[5] <<= 2;  // 060B7C06 shll2 r5
L_060B7C08:
    c.r[0] = 0x060B7C18u;  // 060B7C08 mova 0x060B7C18,r0
L_060B7C0A:
    c.r[0] = ld32(c.r[0] + c.r[5]);  // 060B7C0A mov.l @(r0,r5),r0
L_060B7C0C:
    c.r[5] = 0x1u;  // 060B7C0C mov #1,r5
L_060B7C0E:
    { const uint32_t x = c.r[0]; c.r[9] = ld32(c.r[15]); SH2_POLL(c); switch (x) { case 0x060B7C80u: goto L_060B7C80; case 0x060B7C58u: goto L_060B7C58; case 0x060B7C6Cu: goto L_060B7C6C; case 0x060B7A48u: goto L_060B7A48; case 0x060B7990u: goto L_060B7990; default: sh2_call(c, x); return; } }  // 060B7C0E jmp @r0 ; mov.l @r15,r9
L_060B7C12:
    c.r[15] += 4; SH2_POLL(c); goto L_060B6EBC;  // 060B7C12 bra 0x060B6EBC ; add #4,r15
L_060B7C58:
    c.r[5] = ld32(c.r[9]); c.r[9] += 4;  // 060B7C58 mov.l @r9+,r5
L_060B7C5A:
    c.r[15] += 4;  // 060B7C5A add #4,r15
L_060B7C5C:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[11]);  // 060B7C5C mov.w @(0,r11),r0
L_060B7C5E:
    st32(c.r[11] + 16, c.r[1]);  // 060B7C5E mov.l r1,@(16,r11)
L_060B7C60:
    c.r[0] ^= 0x10u;  // 060B7C60 xor #16,r0
L_060B7C62:
    st16(c.r[11], c.r[0]);  // 060B7C62 mov.w r0,@(0,r11)
L_060B7C64:
    st32(c.r[11] + 12, c.r[2]);  // 060B7C64 mov.l r2,@(12,r11)
L_060B7C66:
    st32(c.r[11] + 24, c.r[3]);  // 060B7C66 mov.l r3,@(24,r11)
L_060B7C68:
    { const uint32_t x = c.r[5]; st32(c.r[11] + 20, c.r[4]); SH2_POLL(c); switch (x) { case 0x060B6DFEu: goto L_060B6DFE; case 0x060B6E00u: goto L_060B6E00; case 0x060B6E02u: goto L_060B6E02; case 0x060B6E04u: goto L_060B6E04; case 0x060B6E06u: goto L_060B6E06; case 0x060B6E08u: goto L_060B6E08; case 0x060B6E0Au: goto L_060B6E0A; case 0x060B6E0Cu: goto L_060B6E0C; case 0x060B6E0Eu: goto L_060B6E0E; case 0x060B6E10u: goto L_060B6E10; case 0x060B6E12u: goto L_060B6E12; case 0x060B6E14u: goto L_060B6E14; case 0x060B6E16u: goto L_060B6E16; case 0x060B6E18u: goto L_060B6E18; case 0x060B6E1Au: goto L_060B6E1A; case 0x060B6E1Cu: goto L_060B6E1C; case 0x060B6E1Eu: goto L_060B6E1E; case 0x060B6E20u: goto L_060B6E20; case 0x060B6E22u: goto L_060B6E22; case 0x060B6E24u: goto L_060B6E24; case 0x060B6E26u: goto L_060B6E26; case 0x060B6E28u: goto L_060B6E28; case 0x060B6E2Au: goto L_060B6E2A; case 0x060B6E2Cu: goto L_060B6E2C; case 0x060B6E2Eu: goto L_060B6E2E; case 0x060B6E30u: goto L_060B6E30; case 0x060B6E32u: goto L_060B6E32; case 0x060B6E34u: goto L_060B6E34; case 0x060B6E36u: goto L_060B6E36; case 0x060B6E38u: goto L_060B6E38; case 0x060B6E3Au: goto L_060B6E3A; case 0x060B6E3Cu: goto L_060B6E3C; case 0x060B6E3Eu: goto L_060B6E3E; case 0x060B6E40u: goto L_060B6E40; case 0x060B6E42u: goto L_060B6E42; case 0x060B6E44u: goto L_060B6E44; case 0x060B6E46u: goto L_060B6E46; case 0x060B6E48u: goto L_060B6E48; case 0x060B6E4Au: goto L_060B6E4A; case 0x060B6E4Cu: goto L_060B6E4C; case 0x060B6E4Eu: goto L_060B6E4E; case 0x060B6E50u: goto L_060B6E50; case 0x060B6E52u: goto L_060B6E52; case 0x060B6E54u: goto L_060B6E54; case 0x060B6E56u: goto L_060B6E56; case 0x060B6E58u: goto L_060B6E58; case 0x060B6E5Au: goto L_060B6E5A; case 0x060B6E5Cu: goto L_060B6E5C; case 0x060B6E5Eu: goto L_060B6E5E; case 0x060B6E60u: goto L_060B6E60; case 0x060B6E62u: goto L_060B6E62; case 0x060B6E64u: goto L_060B6E64; case 0x060B6E66u: goto L_060B6E66; case 0x060B6E68u: goto L_060B6E68; case 0x060B6E6Au: goto L_060B6E6A; case 0x060B6E6Eu: goto L_060B6E6E; case 0x060B6E70u: goto L_060B6E70; case 0x060B6E72u: goto L_060B6E72; case 0x060B6E76u: goto L_060B6E76; case 0x060B6E78u: goto L_060B6E78; case 0x060B6E7Cu: goto L_060B6E7C; case 0x060B6E7Eu: goto L_060B6E7E; case 0x060B6E80u: goto L_060B6E80; case 0x060B6E82u: goto L_060B6E82; case 0x060B6E84u: goto L_060B6E84; case 0x060B6E86u: goto L_060B6E86; case 0x060B6E88u: goto L_060B6E88; case 0x060B6E8Au: goto L_060B6E8A; case 0x060B6E8Eu: goto L_060B6E8E; case 0x060B6EBCu: goto L_060B6EBC; case 0x060B6EBEu: goto L_060B6EBE; case 0x060B6EC0u: goto L_060B6EC0; case 0x060B6EC2u: goto L_060B6EC2; case 0x060B6EC6u: goto L_060B6EC6; case 0x060B6EC8u: goto L_060B6EC8; case 0x060B6ECAu: goto L_060B6ECA; case 0x060B6ECCu: goto L_060B6ECC; case 0x060B6ECEu: goto L_060B6ECE; case 0x060B6ED0u: goto L_060B6ED0; case 0x060B7990u: goto L_060B7990; case 0x060B7992u: goto L_060B7992; case 0x060B7994u: goto L_060B7994; case 0x060B7996u: goto L_060B7996; case 0x060B7998u: goto L_060B7998; case 0x060B799Au: goto L_060B799A; case 0x060B799Cu: goto L_060B799C; case 0x060B799Eu: goto L_060B799E; case 0x060B79A0u: goto L_060B79A0; case 0x060B79A2u: goto L_060B79A2; case 0x060B79A4u: goto L_060B79A4; case 0x060B79A6u: goto L_060B79A6; case 0x060B79A8u: goto L_060B79A8; case 0x060B79AAu: goto L_060B79AA; case 0x060B79ACu: goto L_060B79AC; case 0x060B79AEu: goto L_060B79AE; case 0x060B79B0u: goto L_060B79B0; case 0x060B79B2u: goto L_060B79B2; case 0x060B79B4u: goto L_060B79B4; case 0x060B79B6u: goto L_060B79B6; case 0x060B79B8u: goto L_060B79B8; case 0x060B79BAu: goto L_060B79BA; case 0x060B79BCu: goto L_060B79BC; case 0x060B79BEu: goto L_060B79BE; case 0x060B79C0u: goto L_060B79C0; case 0x060B79C2u: goto L_060B79C2; case 0x060B79C4u: goto L_060B79C4; case 0x060B79C8u: goto L_060B79C8; case 0x060B79CAu: goto L_060B79CA; case 0x060B79CCu: goto L_060B79CC; case 0x060B79CEu: goto L_060B79CE; case 0x060B79D0u: goto L_060B79D0; case 0x060B79D2u: goto L_060B79D2; case 0x060B79D4u: goto L_060B79D4; case 0x060B79D6u: goto L_060B79D6; case 0x060B79D8u: goto L_060B79D8; case 0x060B79DAu: goto L_060B79DA; case 0x060B79DCu: goto L_060B79DC; case 0x060B79DEu: goto L_060B79DE; case 0x060B79E0u: goto L_060B79E0; case 0x060B79E2u: goto L_060B79E2; case 0x060B79E6u: goto L_060B79E6; case 0x060B79E8u: goto L_060B79E8; case 0x060B79EAu: goto L_060B79EA; case 0x060B79ECu: goto L_060B79EC; case 0x060B79EEu: goto L_060B79EE; case 0x060B79F0u: goto L_060B79F0; case 0x060B79F2u: goto L_060B79F2; case 0x060B79F4u: goto L_060B79F4; case 0x060B79F6u: goto L_060B79F6; case 0x060B79F8u: goto L_060B79F8; case 0x060B79FAu: goto L_060B79FA; case 0x060B79FCu: goto L_060B79FC; case 0x060B79FEu: goto L_060B79FE; case 0x060B7A00u: goto L_060B7A00; case 0x060B7A04u: goto L_060B7A04; case 0x060B7A0Eu: goto L_060B7A0E; case 0x060B7A10u: goto L_060B7A10; case 0x060B7A12u: goto L_060B7A12; case 0x060B7A14u: goto L_060B7A14; case 0x060B7A16u: goto L_060B7A16; case 0x060B7A48u: goto L_060B7A48; case 0x060B7A4Au: goto L_060B7A4A; case 0x060B7A4Cu: goto L_060B7A4C; case 0x060B7A4Eu: goto L_060B7A4E; case 0x060B7A50u: goto L_060B7A50; case 0x060B7A52u: goto L_060B7A52; case 0x060B7A54u: goto L_060B7A54; case 0x060B7A56u: goto L_060B7A56; case 0x060B7A58u: goto L_060B7A58; case 0x060B7B78u: goto L_060B7B78; case 0x060B7B7Au: goto L_060B7B7A; case 0x060B7B7Cu: goto L_060B7B7C; case 0x060B7B7Eu: goto L_060B7B7E; case 0x060B7B80u: goto L_060B7B80; case 0x060B7B82u: goto L_060B7B82; case 0x060B7B84u: goto L_060B7B84; case 0x060B7B86u: goto L_060B7B86; case 0x060B7B88u: goto L_060B7B88; case 0x060B7B8Au: goto L_060B7B8A; case 0x060B7B8Eu: goto L_060B7B8E; case 0x060B7B90u: goto L_060B7B90; case 0x060B7B92u: goto L_060B7B92; case 0x060B7B94u: goto L_060B7B94; case 0x060B7B96u: goto L_060B7B96; case 0x060B7B9Au: goto L_060B7B9A; case 0x060B7B9Cu: goto L_060B7B9C; case 0x060B7B9Eu: goto L_060B7B9E; case 0x060B7BA0u: goto L_060B7BA0; case 0x060B7BA2u: goto L_060B7BA2; case 0x060B7BA6u: goto L_060B7BA6; case 0x060B7BA8u: goto L_060B7BA8; case 0x060B7BAAu: goto L_060B7BAA; case 0x060B7BAEu: goto L_060B7BAE; case 0x060B7BB0u: goto L_060B7BB0; case 0x060B7BB2u: goto L_060B7BB2; case 0x060B7BB4u: goto L_060B7BB4; case 0x060B7BB6u: goto L_060B7BB6; case 0x060B7BBAu: goto L_060B7BBA; case 0x060B7BBCu: goto L_060B7BBC; case 0x060B7BBEu: goto L_060B7BBE; case 0x060B7BC0u: goto L_060B7BC0; case 0x060B7BC2u: goto L_060B7BC2; case 0x060B7BC6u: goto L_060B7BC6; case 0x060B7BC8u: goto L_060B7BC8; case 0x060B7BCAu: goto L_060B7BCA; case 0x060B7BCEu: goto L_060B7BCE; case 0x060B7BD0u: goto L_060B7BD0; case 0x060B7BD2u: goto L_060B7BD2; case 0x060B7BD4u: goto L_060B7BD4; case 0x060B7BD6u: goto L_060B7BD6; case 0x060B7BDAu: goto L_060B7BDA; case 0x060B7BDCu: goto L_060B7BDC; case 0x060B7BDEu: goto L_060B7BDE; case 0x060B7BE0u: goto L_060B7BE0; case 0x060B7BE2u: goto L_060B7BE2; case 0x060B7BE6u: goto L_060B7BE6; case 0x060B7BE8u: goto L_060B7BE8; case 0x060B7BEAu: goto L_060B7BEA; case 0x060B7BEEu: goto L_060B7BEE; case 0x060B7BF0u: goto L_060B7BF0; case 0x060B7BF2u: goto L_060B7BF2; case 0x060B7BF4u: goto L_060B7BF4; case 0x060B7BF6u: goto L_060B7BF6; case 0x060B7BFAu: goto L_060B7BFA; case 0x060B7BFCu: goto L_060B7BFC; case 0x060B7BFEu: goto L_060B7BFE; case 0x060B7C00u: goto L_060B7C00; case 0x060B7C02u: goto L_060B7C02; case 0x060B7C06u: goto L_060B7C06; case 0x060B7C08u: goto L_060B7C08; case 0x060B7C0Au: goto L_060B7C0A; case 0x060B7C0Cu: goto L_060B7C0C; case 0x060B7C0Eu: goto L_060B7C0E; case 0x060B7C12u: goto L_060B7C12; case 0x060B7C58u: goto L_060B7C58; case 0x060B7C5Au: goto L_060B7C5A; case 0x060B7C5Cu: goto L_060B7C5C; case 0x060B7C5Eu: goto L_060B7C5E; case 0x060B7C60u: goto L_060B7C60; case 0x060B7C62u: goto L_060B7C62; case 0x060B7C64u: goto L_060B7C64; case 0x060B7C66u: goto L_060B7C66; case 0x060B7C68u: goto L_060B7C68; case 0x060B7C6Cu: goto L_060B7C6C; case 0x060B7C6Eu: goto L_060B7C6E; case 0x060B7C70u: goto L_060B7C70; case 0x060B7C72u: goto L_060B7C72; case 0x060B7C74u: goto L_060B7C74; case 0x060B7C76u: goto L_060B7C76; case 0x060B7C78u: goto L_060B7C78; case 0x060B7C7Au: goto L_060B7C7A; case 0x060B7C7Cu: goto L_060B7C7C; case 0x060B7C80u: goto L_060B7C80; case 0x060B7C82u: goto L_060B7C82; case 0x060B7C84u: goto L_060B7C84; case 0x060B7C86u: goto L_060B7C86; case 0x060B7C88u: goto L_060B7C88; case 0x060B7C8Au: goto L_060B7C8A; default: sh2_call(c, x); return; } }  // 060B7C68 jmp @r5 ; mov.l r4,@(20,r11)
L_060B7C6C:
    c.r[5] = ld32(c.r[9]); c.r[9] += 4;  // 060B7C6C mov.l @r9+,r5
L_060B7C6E:
    c.r[15] += 4;  // 060B7C6E add #4,r15
L_060B7C70:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[11]);  // 060B7C70 mov.w @(0,r11),r0
L_060B7C72:
    st32(c.r[11] + 20, c.r[1]);  // 060B7C72 mov.l r1,@(20,r11)
L_060B7C74:
    c.r[0] ^= 0x30u;  // 060B7C74 xor #48,r0
L_060B7C76:
    st16(c.r[11], c.r[0]);  // 060B7C76 mov.w r0,@(0,r11)
L_060B7C78:
    st32(c.r[11] + 24, c.r[2]);  // 060B7C78 mov.l r2,@(24,r11)
L_060B7C7A:
    st32(c.r[11] + 12, c.r[3]);  // 060B7C7A mov.l r3,@(12,r11)
L_060B7C7C:
    { const uint32_t x = c.r[5]; st32(c.r[11] + 16, c.r[4]); SH2_POLL(c); switch (x) { case 0x060B6DFEu: goto L_060B6DFE; case 0x060B6E00u: goto L_060B6E00; case 0x060B6E02u: goto L_060B6E02; case 0x060B6E04u: goto L_060B6E04; case 0x060B6E06u: goto L_060B6E06; case 0x060B6E08u: goto L_060B6E08; case 0x060B6E0Au: goto L_060B6E0A; case 0x060B6E0Cu: goto L_060B6E0C; case 0x060B6E0Eu: goto L_060B6E0E; case 0x060B6E10u: goto L_060B6E10; case 0x060B6E12u: goto L_060B6E12; case 0x060B6E14u: goto L_060B6E14; case 0x060B6E16u: goto L_060B6E16; case 0x060B6E18u: goto L_060B6E18; case 0x060B6E1Au: goto L_060B6E1A; case 0x060B6E1Cu: goto L_060B6E1C; case 0x060B6E1Eu: goto L_060B6E1E; case 0x060B6E20u: goto L_060B6E20; case 0x060B6E22u: goto L_060B6E22; case 0x060B6E24u: goto L_060B6E24; case 0x060B6E26u: goto L_060B6E26; case 0x060B6E28u: goto L_060B6E28; case 0x060B6E2Au: goto L_060B6E2A; case 0x060B6E2Cu: goto L_060B6E2C; case 0x060B6E2Eu: goto L_060B6E2E; case 0x060B6E30u: goto L_060B6E30; case 0x060B6E32u: goto L_060B6E32; case 0x060B6E34u: goto L_060B6E34; case 0x060B6E36u: goto L_060B6E36; case 0x060B6E38u: goto L_060B6E38; case 0x060B6E3Au: goto L_060B6E3A; case 0x060B6E3Cu: goto L_060B6E3C; case 0x060B6E3Eu: goto L_060B6E3E; case 0x060B6E40u: goto L_060B6E40; case 0x060B6E42u: goto L_060B6E42; case 0x060B6E44u: goto L_060B6E44; case 0x060B6E46u: goto L_060B6E46; case 0x060B6E48u: goto L_060B6E48; case 0x060B6E4Au: goto L_060B6E4A; case 0x060B6E4Cu: goto L_060B6E4C; case 0x060B6E4Eu: goto L_060B6E4E; case 0x060B6E50u: goto L_060B6E50; case 0x060B6E52u: goto L_060B6E52; case 0x060B6E54u: goto L_060B6E54; case 0x060B6E56u: goto L_060B6E56; case 0x060B6E58u: goto L_060B6E58; case 0x060B6E5Au: goto L_060B6E5A; case 0x060B6E5Cu: goto L_060B6E5C; case 0x060B6E5Eu: goto L_060B6E5E; case 0x060B6E60u: goto L_060B6E60; case 0x060B6E62u: goto L_060B6E62; case 0x060B6E64u: goto L_060B6E64; case 0x060B6E66u: goto L_060B6E66; case 0x060B6E68u: goto L_060B6E68; case 0x060B6E6Au: goto L_060B6E6A; case 0x060B6E6Eu: goto L_060B6E6E; case 0x060B6E70u: goto L_060B6E70; case 0x060B6E72u: goto L_060B6E72; case 0x060B6E76u: goto L_060B6E76; case 0x060B6E78u: goto L_060B6E78; case 0x060B6E7Cu: goto L_060B6E7C; case 0x060B6E7Eu: goto L_060B6E7E; case 0x060B6E80u: goto L_060B6E80; case 0x060B6E82u: goto L_060B6E82; case 0x060B6E84u: goto L_060B6E84; case 0x060B6E86u: goto L_060B6E86; case 0x060B6E88u: goto L_060B6E88; case 0x060B6E8Au: goto L_060B6E8A; case 0x060B6E8Eu: goto L_060B6E8E; case 0x060B6EBCu: goto L_060B6EBC; case 0x060B6EBEu: goto L_060B6EBE; case 0x060B6EC0u: goto L_060B6EC0; case 0x060B6EC2u: goto L_060B6EC2; case 0x060B6EC6u: goto L_060B6EC6; case 0x060B6EC8u: goto L_060B6EC8; case 0x060B6ECAu: goto L_060B6ECA; case 0x060B6ECCu: goto L_060B6ECC; case 0x060B6ECEu: goto L_060B6ECE; case 0x060B6ED0u: goto L_060B6ED0; case 0x060B7990u: goto L_060B7990; case 0x060B7992u: goto L_060B7992; case 0x060B7994u: goto L_060B7994; case 0x060B7996u: goto L_060B7996; case 0x060B7998u: goto L_060B7998; case 0x060B799Au: goto L_060B799A; case 0x060B799Cu: goto L_060B799C; case 0x060B799Eu: goto L_060B799E; case 0x060B79A0u: goto L_060B79A0; case 0x060B79A2u: goto L_060B79A2; case 0x060B79A4u: goto L_060B79A4; case 0x060B79A6u: goto L_060B79A6; case 0x060B79A8u: goto L_060B79A8; case 0x060B79AAu: goto L_060B79AA; case 0x060B79ACu: goto L_060B79AC; case 0x060B79AEu: goto L_060B79AE; case 0x060B79B0u: goto L_060B79B0; case 0x060B79B2u: goto L_060B79B2; case 0x060B79B4u: goto L_060B79B4; case 0x060B79B6u: goto L_060B79B6; case 0x060B79B8u: goto L_060B79B8; case 0x060B79BAu: goto L_060B79BA; case 0x060B79BCu: goto L_060B79BC; case 0x060B79BEu: goto L_060B79BE; case 0x060B79C0u: goto L_060B79C0; case 0x060B79C2u: goto L_060B79C2; case 0x060B79C4u: goto L_060B79C4; case 0x060B79C8u: goto L_060B79C8; case 0x060B79CAu: goto L_060B79CA; case 0x060B79CCu: goto L_060B79CC; case 0x060B79CEu: goto L_060B79CE; case 0x060B79D0u: goto L_060B79D0; case 0x060B79D2u: goto L_060B79D2; case 0x060B79D4u: goto L_060B79D4; case 0x060B79D6u: goto L_060B79D6; case 0x060B79D8u: goto L_060B79D8; case 0x060B79DAu: goto L_060B79DA; case 0x060B79DCu: goto L_060B79DC; case 0x060B79DEu: goto L_060B79DE; case 0x060B79E0u: goto L_060B79E0; case 0x060B79E2u: goto L_060B79E2; case 0x060B79E6u: goto L_060B79E6; case 0x060B79E8u: goto L_060B79E8; case 0x060B79EAu: goto L_060B79EA; case 0x060B79ECu: goto L_060B79EC; case 0x060B79EEu: goto L_060B79EE; case 0x060B79F0u: goto L_060B79F0; case 0x060B79F2u: goto L_060B79F2; case 0x060B79F4u: goto L_060B79F4; case 0x060B79F6u: goto L_060B79F6; case 0x060B79F8u: goto L_060B79F8; case 0x060B79FAu: goto L_060B79FA; case 0x060B79FCu: goto L_060B79FC; case 0x060B79FEu: goto L_060B79FE; case 0x060B7A00u: goto L_060B7A00; case 0x060B7A04u: goto L_060B7A04; case 0x060B7A0Eu: goto L_060B7A0E; case 0x060B7A10u: goto L_060B7A10; case 0x060B7A12u: goto L_060B7A12; case 0x060B7A14u: goto L_060B7A14; case 0x060B7A16u: goto L_060B7A16; case 0x060B7A48u: goto L_060B7A48; case 0x060B7A4Au: goto L_060B7A4A; case 0x060B7A4Cu: goto L_060B7A4C; case 0x060B7A4Eu: goto L_060B7A4E; case 0x060B7A50u: goto L_060B7A50; case 0x060B7A52u: goto L_060B7A52; case 0x060B7A54u: goto L_060B7A54; case 0x060B7A56u: goto L_060B7A56; case 0x060B7A58u: goto L_060B7A58; case 0x060B7B78u: goto L_060B7B78; case 0x060B7B7Au: goto L_060B7B7A; case 0x060B7B7Cu: goto L_060B7B7C; case 0x060B7B7Eu: goto L_060B7B7E; case 0x060B7B80u: goto L_060B7B80; case 0x060B7B82u: goto L_060B7B82; case 0x060B7B84u: goto L_060B7B84; case 0x060B7B86u: goto L_060B7B86; case 0x060B7B88u: goto L_060B7B88; case 0x060B7B8Au: goto L_060B7B8A; case 0x060B7B8Eu: goto L_060B7B8E; case 0x060B7B90u: goto L_060B7B90; case 0x060B7B92u: goto L_060B7B92; case 0x060B7B94u: goto L_060B7B94; case 0x060B7B96u: goto L_060B7B96; case 0x060B7B9Au: goto L_060B7B9A; case 0x060B7B9Cu: goto L_060B7B9C; case 0x060B7B9Eu: goto L_060B7B9E; case 0x060B7BA0u: goto L_060B7BA0; case 0x060B7BA2u: goto L_060B7BA2; case 0x060B7BA6u: goto L_060B7BA6; case 0x060B7BA8u: goto L_060B7BA8; case 0x060B7BAAu: goto L_060B7BAA; case 0x060B7BAEu: goto L_060B7BAE; case 0x060B7BB0u: goto L_060B7BB0; case 0x060B7BB2u: goto L_060B7BB2; case 0x060B7BB4u: goto L_060B7BB4; case 0x060B7BB6u: goto L_060B7BB6; case 0x060B7BBAu: goto L_060B7BBA; case 0x060B7BBCu: goto L_060B7BBC; case 0x060B7BBEu: goto L_060B7BBE; case 0x060B7BC0u: goto L_060B7BC0; case 0x060B7BC2u: goto L_060B7BC2; case 0x060B7BC6u: goto L_060B7BC6; case 0x060B7BC8u: goto L_060B7BC8; case 0x060B7BCAu: goto L_060B7BCA; case 0x060B7BCEu: goto L_060B7BCE; case 0x060B7BD0u: goto L_060B7BD0; case 0x060B7BD2u: goto L_060B7BD2; case 0x060B7BD4u: goto L_060B7BD4; case 0x060B7BD6u: goto L_060B7BD6; case 0x060B7BDAu: goto L_060B7BDA; case 0x060B7BDCu: goto L_060B7BDC; case 0x060B7BDEu: goto L_060B7BDE; case 0x060B7BE0u: goto L_060B7BE0; case 0x060B7BE2u: goto L_060B7BE2; case 0x060B7BE6u: goto L_060B7BE6; case 0x060B7BE8u: goto L_060B7BE8; case 0x060B7BEAu: goto L_060B7BEA; case 0x060B7BEEu: goto L_060B7BEE; case 0x060B7BF0u: goto L_060B7BF0; case 0x060B7BF2u: goto L_060B7BF2; case 0x060B7BF4u: goto L_060B7BF4; case 0x060B7BF6u: goto L_060B7BF6; case 0x060B7BFAu: goto L_060B7BFA; case 0x060B7BFCu: goto L_060B7BFC; case 0x060B7BFEu: goto L_060B7BFE; case 0x060B7C00u: goto L_060B7C00; case 0x060B7C02u: goto L_060B7C02; case 0x060B7C06u: goto L_060B7C06; case 0x060B7C08u: goto L_060B7C08; case 0x060B7C0Au: goto L_060B7C0A; case 0x060B7C0Cu: goto L_060B7C0C; case 0x060B7C0Eu: goto L_060B7C0E; case 0x060B7C12u: goto L_060B7C12; case 0x060B7C58u: goto L_060B7C58; case 0x060B7C5Au: goto L_060B7C5A; case 0x060B7C5Cu: goto L_060B7C5C; case 0x060B7C5Eu: goto L_060B7C5E; case 0x060B7C60u: goto L_060B7C60; case 0x060B7C62u: goto L_060B7C62; case 0x060B7C64u: goto L_060B7C64; case 0x060B7C66u: goto L_060B7C66; case 0x060B7C68u: goto L_060B7C68; case 0x060B7C6Cu: goto L_060B7C6C; case 0x060B7C6Eu: goto L_060B7C6E; case 0x060B7C70u: goto L_060B7C70; case 0x060B7C72u: goto L_060B7C72; case 0x060B7C74u: goto L_060B7C74; case 0x060B7C76u: goto L_060B7C76; case 0x060B7C78u: goto L_060B7C78; case 0x060B7C7Au: goto L_060B7C7A; case 0x060B7C7Cu: goto L_060B7C7C; case 0x060B7C80u: goto L_060B7C80; case 0x060B7C82u: goto L_060B7C82; case 0x060B7C84u: goto L_060B7C84; case 0x060B7C86u: goto L_060B7C86; case 0x060B7C88u: goto L_060B7C88; case 0x060B7C8Au: goto L_060B7C8A; default: sh2_call(c, x); return; } }  // 060B7C7C jmp @r5 ; mov.l r4,@(16,r11)
L_060B7C80:
    c.r[5] = ld32(c.r[9]); c.r[9] += 4;  // 060B7C80 mov.l @r9+,r5
L_060B7C82:
    c.r[15] += 4;  // 060B7C82 add #4,r15
L_060B7C84:
    st32(c.r[11] + 24, c.r[4]);  // 060B7C84 mov.l r4,@(24,r11)
L_060B7C86:
    st32(c.r[11] + 20, c.r[3]);  // 060B7C86 mov.l r3,@(20,r11)
L_060B7C88:
    st32(c.r[11] + 16, c.r[2]);  // 060B7C88 mov.l r2,@(16,r11)
L_060B7C8A:
    { const uint32_t x = c.r[5]; st32(c.r[11] + 12, c.r[1]); SH2_POLL(c); switch (x) { case 0x060B6DFEu: goto L_060B6DFE; case 0x060B6E00u: goto L_060B6E00; case 0x060B6E02u: goto L_060B6E02; case 0x060B6E04u: goto L_060B6E04; case 0x060B6E06u: goto L_060B6E06; case 0x060B6E08u: goto L_060B6E08; case 0x060B6E0Au: goto L_060B6E0A; case 0x060B6E0Cu: goto L_060B6E0C; case 0x060B6E0Eu: goto L_060B6E0E; case 0x060B6E10u: goto L_060B6E10; case 0x060B6E12u: goto L_060B6E12; case 0x060B6E14u: goto L_060B6E14; case 0x060B6E16u: goto L_060B6E16; case 0x060B6E18u: goto L_060B6E18; case 0x060B6E1Au: goto L_060B6E1A; case 0x060B6E1Cu: goto L_060B6E1C; case 0x060B6E1Eu: goto L_060B6E1E; case 0x060B6E20u: goto L_060B6E20; case 0x060B6E22u: goto L_060B6E22; case 0x060B6E24u: goto L_060B6E24; case 0x060B6E26u: goto L_060B6E26; case 0x060B6E28u: goto L_060B6E28; case 0x060B6E2Au: goto L_060B6E2A; case 0x060B6E2Cu: goto L_060B6E2C; case 0x060B6E2Eu: goto L_060B6E2E; case 0x060B6E30u: goto L_060B6E30; case 0x060B6E32u: goto L_060B6E32; case 0x060B6E34u: goto L_060B6E34; case 0x060B6E36u: goto L_060B6E36; case 0x060B6E38u: goto L_060B6E38; case 0x060B6E3Au: goto L_060B6E3A; case 0x060B6E3Cu: goto L_060B6E3C; case 0x060B6E3Eu: goto L_060B6E3E; case 0x060B6E40u: goto L_060B6E40; case 0x060B6E42u: goto L_060B6E42; case 0x060B6E44u: goto L_060B6E44; case 0x060B6E46u: goto L_060B6E46; case 0x060B6E48u: goto L_060B6E48; case 0x060B6E4Au: goto L_060B6E4A; case 0x060B6E4Cu: goto L_060B6E4C; case 0x060B6E4Eu: goto L_060B6E4E; case 0x060B6E50u: goto L_060B6E50; case 0x060B6E52u: goto L_060B6E52; case 0x060B6E54u: goto L_060B6E54; case 0x060B6E56u: goto L_060B6E56; case 0x060B6E58u: goto L_060B6E58; case 0x060B6E5Au: goto L_060B6E5A; case 0x060B6E5Cu: goto L_060B6E5C; case 0x060B6E5Eu: goto L_060B6E5E; case 0x060B6E60u: goto L_060B6E60; case 0x060B6E62u: goto L_060B6E62; case 0x060B6E64u: goto L_060B6E64; case 0x060B6E66u: goto L_060B6E66; case 0x060B6E68u: goto L_060B6E68; case 0x060B6E6Au: goto L_060B6E6A; case 0x060B6E6Eu: goto L_060B6E6E; case 0x060B6E70u: goto L_060B6E70; case 0x060B6E72u: goto L_060B6E72; case 0x060B6E76u: goto L_060B6E76; case 0x060B6E78u: goto L_060B6E78; case 0x060B6E7Cu: goto L_060B6E7C; case 0x060B6E7Eu: goto L_060B6E7E; case 0x060B6E80u: goto L_060B6E80; case 0x060B6E82u: goto L_060B6E82; case 0x060B6E84u: goto L_060B6E84; case 0x060B6E86u: goto L_060B6E86; case 0x060B6E88u: goto L_060B6E88; case 0x060B6E8Au: goto L_060B6E8A; case 0x060B6E8Eu: goto L_060B6E8E; case 0x060B6EBCu: goto L_060B6EBC; case 0x060B6EBEu: goto L_060B6EBE; case 0x060B6EC0u: goto L_060B6EC0; case 0x060B6EC2u: goto L_060B6EC2; case 0x060B6EC6u: goto L_060B6EC6; case 0x060B6EC8u: goto L_060B6EC8; case 0x060B6ECAu: goto L_060B6ECA; case 0x060B6ECCu: goto L_060B6ECC; case 0x060B6ECEu: goto L_060B6ECE; case 0x060B6ED0u: goto L_060B6ED0; case 0x060B7990u: goto L_060B7990; case 0x060B7992u: goto L_060B7992; case 0x060B7994u: goto L_060B7994; case 0x060B7996u: goto L_060B7996; case 0x060B7998u: goto L_060B7998; case 0x060B799Au: goto L_060B799A; case 0x060B799Cu: goto L_060B799C; case 0x060B799Eu: goto L_060B799E; case 0x060B79A0u: goto L_060B79A0; case 0x060B79A2u: goto L_060B79A2; case 0x060B79A4u: goto L_060B79A4; case 0x060B79A6u: goto L_060B79A6; case 0x060B79A8u: goto L_060B79A8; case 0x060B79AAu: goto L_060B79AA; case 0x060B79ACu: goto L_060B79AC; case 0x060B79AEu: goto L_060B79AE; case 0x060B79B0u: goto L_060B79B0; case 0x060B79B2u: goto L_060B79B2; case 0x060B79B4u: goto L_060B79B4; case 0x060B79B6u: goto L_060B79B6; case 0x060B79B8u: goto L_060B79B8; case 0x060B79BAu: goto L_060B79BA; case 0x060B79BCu: goto L_060B79BC; case 0x060B79BEu: goto L_060B79BE; case 0x060B79C0u: goto L_060B79C0; case 0x060B79C2u: goto L_060B79C2; case 0x060B79C4u: goto L_060B79C4; case 0x060B79C8u: goto L_060B79C8; case 0x060B79CAu: goto L_060B79CA; case 0x060B79CCu: goto L_060B79CC; case 0x060B79CEu: goto L_060B79CE; case 0x060B79D0u: goto L_060B79D0; case 0x060B79D2u: goto L_060B79D2; case 0x060B79D4u: goto L_060B79D4; case 0x060B79D6u: goto L_060B79D6; case 0x060B79D8u: goto L_060B79D8; case 0x060B79DAu: goto L_060B79DA; case 0x060B79DCu: goto L_060B79DC; case 0x060B79DEu: goto L_060B79DE; case 0x060B79E0u: goto L_060B79E0; case 0x060B79E2u: goto L_060B79E2; case 0x060B79E6u: goto L_060B79E6; case 0x060B79E8u: goto L_060B79E8; case 0x060B79EAu: goto L_060B79EA; case 0x060B79ECu: goto L_060B79EC; case 0x060B79EEu: goto L_060B79EE; case 0x060B79F0u: goto L_060B79F0; case 0x060B79F2u: goto L_060B79F2; case 0x060B79F4u: goto L_060B79F4; case 0x060B79F6u: goto L_060B79F6; case 0x060B79F8u: goto L_060B79F8; case 0x060B79FAu: goto L_060B79FA; case 0x060B79FCu: goto L_060B79FC; case 0x060B79FEu: goto L_060B79FE; case 0x060B7A00u: goto L_060B7A00; case 0x060B7A04u: goto L_060B7A04; case 0x060B7A0Eu: goto L_060B7A0E; case 0x060B7A10u: goto L_060B7A10; case 0x060B7A12u: goto L_060B7A12; case 0x060B7A14u: goto L_060B7A14; case 0x060B7A16u: goto L_060B7A16; case 0x060B7A48u: goto L_060B7A48; case 0x060B7A4Au: goto L_060B7A4A; case 0x060B7A4Cu: goto L_060B7A4C; case 0x060B7A4Eu: goto L_060B7A4E; case 0x060B7A50u: goto L_060B7A50; case 0x060B7A52u: goto L_060B7A52; case 0x060B7A54u: goto L_060B7A54; case 0x060B7A56u: goto L_060B7A56; case 0x060B7A58u: goto L_060B7A58; case 0x060B7B78u: goto L_060B7B78; case 0x060B7B7Au: goto L_060B7B7A; case 0x060B7B7Cu: goto L_060B7B7C; case 0x060B7B7Eu: goto L_060B7B7E; case 0x060B7B80u: goto L_060B7B80; case 0x060B7B82u: goto L_060B7B82; case 0x060B7B84u: goto L_060B7B84; case 0x060B7B86u: goto L_060B7B86; case 0x060B7B88u: goto L_060B7B88; case 0x060B7B8Au: goto L_060B7B8A; case 0x060B7B8Eu: goto L_060B7B8E; case 0x060B7B90u: goto L_060B7B90; case 0x060B7B92u: goto L_060B7B92; case 0x060B7B94u: goto L_060B7B94; case 0x060B7B96u: goto L_060B7B96; case 0x060B7B9Au: goto L_060B7B9A; case 0x060B7B9Cu: goto L_060B7B9C; case 0x060B7B9Eu: goto L_060B7B9E; case 0x060B7BA0u: goto L_060B7BA0; case 0x060B7BA2u: goto L_060B7BA2; case 0x060B7BA6u: goto L_060B7BA6; case 0x060B7BA8u: goto L_060B7BA8; case 0x060B7BAAu: goto L_060B7BAA; case 0x060B7BAEu: goto L_060B7BAE; case 0x060B7BB0u: goto L_060B7BB0; case 0x060B7BB2u: goto L_060B7BB2; case 0x060B7BB4u: goto L_060B7BB4; case 0x060B7BB6u: goto L_060B7BB6; case 0x060B7BBAu: goto L_060B7BBA; case 0x060B7BBCu: goto L_060B7BBC; case 0x060B7BBEu: goto L_060B7BBE; case 0x060B7BC0u: goto L_060B7BC0; case 0x060B7BC2u: goto L_060B7BC2; case 0x060B7BC6u: goto L_060B7BC6; case 0x060B7BC8u: goto L_060B7BC8; case 0x060B7BCAu: goto L_060B7BCA; case 0x060B7BCEu: goto L_060B7BCE; case 0x060B7BD0u: goto L_060B7BD0; case 0x060B7BD2u: goto L_060B7BD2; case 0x060B7BD4u: goto L_060B7BD4; case 0x060B7BD6u: goto L_060B7BD6; case 0x060B7BDAu: goto L_060B7BDA; case 0x060B7BDCu: goto L_060B7BDC; case 0x060B7BDEu: goto L_060B7BDE; case 0x060B7BE0u: goto L_060B7BE0; case 0x060B7BE2u: goto L_060B7BE2; case 0x060B7BE6u: goto L_060B7BE6; case 0x060B7BE8u: goto L_060B7BE8; case 0x060B7BEAu: goto L_060B7BEA; case 0x060B7BEEu: goto L_060B7BEE; case 0x060B7BF0u: goto L_060B7BF0; case 0x060B7BF2u: goto L_060B7BF2; case 0x060B7BF4u: goto L_060B7BF4; case 0x060B7BF6u: goto L_060B7BF6; case 0x060B7BFAu: goto L_060B7BFA; case 0x060B7BFCu: goto L_060B7BFC; case 0x060B7BFEu: goto L_060B7BFE; case 0x060B7C00u: goto L_060B7C00; case 0x060B7C02u: goto L_060B7C02; case 0x060B7C06u: goto L_060B7C06; case 0x060B7C08u: goto L_060B7C08; case 0x060B7C0Au: goto L_060B7C0A; case 0x060B7C0Cu: goto L_060B7C0C; case 0x060B7C0Eu: goto L_060B7C0E; case 0x060B7C12u: goto L_060B7C12; case 0x060B7C58u: goto L_060B7C58; case 0x060B7C5Au: goto L_060B7C5A; case 0x060B7C5Cu: goto L_060B7C5C; case 0x060B7C5Eu: goto L_060B7C5E; case 0x060B7C60u: goto L_060B7C60; case 0x060B7C62u: goto L_060B7C62; case 0x060B7C64u: goto L_060B7C64; case 0x060B7C66u: goto L_060B7C66; case 0x060B7C68u: goto L_060B7C68; case 0x060B7C6Cu: goto L_060B7C6C; case 0x060B7C6Eu: goto L_060B7C6E; case 0x060B7C70u: goto L_060B7C70; case 0x060B7C72u: goto L_060B7C72; case 0x060B7C74u: goto L_060B7C74; case 0x060B7C76u: goto L_060B7C76; case 0x060B7C78u: goto L_060B7C78; case 0x060B7C7Au: goto L_060B7C7A; case 0x060B7C7Cu: goto L_060B7C7C; case 0x060B7C80u: goto L_060B7C80; case 0x060B7C82u: goto L_060B7C82; case 0x060B7C84u: goto L_060B7C84; case 0x060B7C86u: goto L_060B7C86; case 0x060B7C88u: goto L_060B7C88; case 0x060B7C8Au: goto L_060B7C8A; default: sh2_call(c, x); return; } }  // 060B7C8A jmp @r5 ; mov.l r1,@(12,r11)
}

void f_060B7C58(SH2Context& c) {
    ran[3146] = 1;
L_060B7C58:
    c.r[5] = ld32(c.r[9]); c.r[9] += 4;  // 060B7C58 mov.l @r9+,r5
L_060B7C5A:
    c.r[15] += 4;  // 060B7C5A add #4,r15
L_060B7C5C:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[11]);  // 060B7C5C mov.w @(0,r11),r0
L_060B7C5E:
    st32(c.r[11] + 16, c.r[1]);  // 060B7C5E mov.l r1,@(16,r11)
L_060B7C60:
    c.r[0] ^= 0x10u;  // 060B7C60 xor #16,r0
L_060B7C62:
    st16(c.r[11], c.r[0]);  // 060B7C62 mov.w r0,@(0,r11)
L_060B7C64:
    st32(c.r[11] + 12, c.r[2]);  // 060B7C64 mov.l r2,@(12,r11)
L_060B7C66:
    st32(c.r[11] + 24, c.r[3]);  // 060B7C66 mov.l r3,@(24,r11)
L_060B7C68:
    { const uint32_t x = c.r[5]; st32(c.r[11] + 20, c.r[4]); SH2_POLL(c); switch (x) { case 0x060B7C58u: goto L_060B7C58; case 0x060B7C5Au: goto L_060B7C5A; case 0x060B7C5Cu: goto L_060B7C5C; case 0x060B7C5Eu: goto L_060B7C5E; case 0x060B7C60u: goto L_060B7C60; case 0x060B7C62u: goto L_060B7C62; case 0x060B7C64u: goto L_060B7C64; case 0x060B7C66u: goto L_060B7C66; case 0x060B7C68u: goto L_060B7C68; default: sh2_call(c, x); return; } }  // 060B7C68 jmp @r5 ; mov.l r4,@(20,r11)
}

void f_060B7C6C(SH2Context& c) {
    ran[3147] = 1;
L_060B7C6C:
    c.r[5] = ld32(c.r[9]); c.r[9] += 4;  // 060B7C6C mov.l @r9+,r5
L_060B7C6E:
    c.r[15] += 4;  // 060B7C6E add #4,r15
L_060B7C70:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[11]);  // 060B7C70 mov.w @(0,r11),r0
L_060B7C72:
    st32(c.r[11] + 20, c.r[1]);  // 060B7C72 mov.l r1,@(20,r11)
L_060B7C74:
    c.r[0] ^= 0x30u;  // 060B7C74 xor #48,r0
L_060B7C76:
    st16(c.r[11], c.r[0]);  // 060B7C76 mov.w r0,@(0,r11)
L_060B7C78:
    st32(c.r[11] + 24, c.r[2]);  // 060B7C78 mov.l r2,@(24,r11)
L_060B7C7A:
    st32(c.r[11] + 12, c.r[3]);  // 060B7C7A mov.l r3,@(12,r11)
L_060B7C7C:
    { const uint32_t x = c.r[5]; st32(c.r[11] + 16, c.r[4]); SH2_POLL(c); switch (x) { case 0x060B7C6Cu: goto L_060B7C6C; case 0x060B7C6Eu: goto L_060B7C6E; case 0x060B7C70u: goto L_060B7C70; case 0x060B7C72u: goto L_060B7C72; case 0x060B7C74u: goto L_060B7C74; case 0x060B7C76u: goto L_060B7C76; case 0x060B7C78u: goto L_060B7C78; case 0x060B7C7Au: goto L_060B7C7A; case 0x060B7C7Cu: goto L_060B7C7C; default: sh2_call(c, x); return; } }  // 060B7C7C jmp @r5 ; mov.l r4,@(16,r11)
}

void f_060B7C80(SH2Context& c) {
    ran[3148] = 1;
L_060B7C80:
    c.r[5] = ld32(c.r[9]); c.r[9] += 4;  // 060B7C80 mov.l @r9+,r5
L_060B7C82:
    c.r[15] += 4;  // 060B7C82 add #4,r15
L_060B7C84:
    st32(c.r[11] + 24, c.r[4]);  // 060B7C84 mov.l r4,@(24,r11)
L_060B7C86:
    st32(c.r[11] + 20, c.r[3]);  // 060B7C86 mov.l r3,@(20,r11)
L_060B7C88:
    st32(c.r[11] + 16, c.r[2]);  // 060B7C88 mov.l r2,@(16,r11)
L_060B7C8A:
    { const uint32_t x = c.r[5]; st32(c.r[11] + 12, c.r[1]); SH2_POLL(c); switch (x) { case 0x060B7C80u: goto L_060B7C80; case 0x060B7C82u: goto L_060B7C82; case 0x060B7C84u: goto L_060B7C84; case 0x060B7C86u: goto L_060B7C86; case 0x060B7C88u: goto L_060B7C88; case 0x060B7C8Au: goto L_060B7C8A; default: sh2_call(c, x); return; } }  // 060B7C8A jmp @r5 ; mov.l r1,@(12,r11)
}

void f_060B7C90(SH2Context& c) {
    ran[3149] = 1;
L_060B7C90:
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 060B7C90 mov.l r2,@-r15
L_060B7C92:
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060B7C92 mov.l r1,@-r15
L_060B7C94:
    c.r[1] = ld32(0x060B7CD4u);  // 060B7C94 mov.l 0x060B7CD4,r1
L_060B7C96:
    c.r[13] = ld32(c.r[1]);  // 060B7C96 mov.l @(0,r1),r13
L_060B7C98:
    c.r[12] = ld32(c.r[1] + 4);  // 060B7C98 mov.l @(4,r1),r12
L_060B7C9A:
    c.r[5] = c.r[14];  // 060B7C9A mov r14,r5
L_060B7C9C:
    c.t = (int32_t)c.r[13] >= (int32_t)c.r[5];  // 060B7C9C cmp/ge r5,r13
L_060B7C9E:
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_060B7CBA; } }  // 060B7C9E bt/s 0x060B7CBA ; mov #0,r0
L_060B7CA2:
    c.r[5] -= c.r[13];  // 060B7CA2 sub r13,r5
L_060B7CA4:
    c.t = (int32_t)c.r[5] >= (int32_t)c.r[12];  // 060B7CA4 cmp/ge r12,r5
L_060B7CA6:
    { const bool k = c.t; c.r[0] = (uint32_t)(int16_t)ld16(c.r[1] + 10); if (k) { goto L_060B7CBA; } }  // 060B7CA6 bt/s 0x060B7CBA ; mov.w @(10,r1),r0
L_060B7CAA:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[1] + 8);  // 060B7CAA mov.w @(8,r1),r0
L_060B7CAC:
    c.r[2] = c.r[0];  // 060B7CAC mov r0,r2
L_060B7CAE:
    c.t = c.r[0] == 0x0u;  // 060B7CAE cmp/eq #0,r0
L_060B7CB0:
    { const bool k = c.t; c.r[0] = c.r[5]; if (k) { goto L_060B7CBA; } }  // 060B7CB0 bt/s 0x060B7CBA ; mov r5,r0
L_060B7CB4:
    c.r[2] -= 1; c.t = c.r[2] == 0;  // 060B7CB4 dt r2
L_060B7CB6:
    { const bool k = !c.t; c.t = c.r[0] & 1; c.r[0] >>= 1; if (k) { SH2_POLL(c); goto L_060B7CB4; } }  // 060B7CB6 bf/s 0x060B7CB4 ; shlr r0
L_060B7CBA:
    c.r[5] = c.r[0];  // 060B7CBA mov r0,r5
L_060B7CBC:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[1] + 12);  // 060B7CBC mov.w @(12,r1),r0
L_060B7CBE:
    c.r[0] += c.r[5];  // 060B7CBE add r5,r0
L_060B7CC0:
    st16(c.r[8] + 8, c.r[0]);  // 060B7CC0 mov.w r0,@(8,r8)
L_060B7CC2:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[8] + 4);  // 060B7CC2 mov.w @(4,r8),r0
L_060B7CC4:
    c.r[0] |= 0x4u;  // 060B7CC4 or #4,r0
L_060B7CC6:
    st16(c.r[8] + 4, c.r[0]);  // 060B7CC6 mov.w r0,@(4,r8)
L_060B7CC8:
    c.r[1] = ld32(c.r[15]); c.r[15] += 4;  // 060B7CC8 mov.l @r15+,r1
L_060B7CCA:
    c.r[2] = ld32(c.r[15]); c.r[15] += 4;  // 060B7CCA mov.l @r15+,r2
L_060B7CCC:
    c.r[0] = ld32(0x060B7CD8u);  // 060B7CCC mov.l 0x060B7CD8,r0
L_060B7CCE:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x060B7C90u: goto L_060B7C90; case 0x060B7C92u: goto L_060B7C92; case 0x060B7C94u: goto L_060B7C94; case 0x060B7C96u: goto L_060B7C96; case 0x060B7C98u: goto L_060B7C98; case 0x060B7C9Au: goto L_060B7C9A; case 0x060B7C9Cu: goto L_060B7C9C; case 0x060B7C9Eu: goto L_060B7C9E; case 0x060B7CA2u: goto L_060B7CA2; case 0x060B7CA4u: goto L_060B7CA4; case 0x060B7CA6u: goto L_060B7CA6; case 0x060B7CAAu: goto L_060B7CAA; case 0x060B7CACu: goto L_060B7CAC; case 0x060B7CAEu: goto L_060B7CAE; case 0x060B7CB0u: goto L_060B7CB0; case 0x060B7CB4u: goto L_060B7CB4; case 0x060B7CB6u: goto L_060B7CB6; case 0x060B7CBAu: goto L_060B7CBA; case 0x060B7CBCu: goto L_060B7CBC; case 0x060B7CBEu: goto L_060B7CBE; case 0x060B7CC0u: goto L_060B7CC0; case 0x060B7CC2u: goto L_060B7CC2; case 0x060B7CC4u: goto L_060B7CC4; case 0x060B7CC6u: goto L_060B7CC6; case 0x060B7CC8u: goto L_060B7CC8; case 0x060B7CCAu: goto L_060B7CCA; case 0x060B7CCCu: goto L_060B7CCC; case 0x060B7CCEu: goto L_060B7CCE; default: sh2_call(c, x); return; } }  // 060B7CCE jmp @r0 ; nop
}

void f_060B7D48(SH2Context& c) {
    ran[3150] = 1;
    c.r[2] = ld32(0x060B7E18u);  // 060B7D48 mov.l 0x060B7E18,r2
    c.r[3] = ld32(0x060B7E24u);  // 060B7D4A mov.l 0x060B7E24,r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060B7D4C mov.b @r2,r0
    c.r[2] += 2;  // 060B7D4E add #2,r2
    st8(c.r[3], c.r[0]);  // 060B7D50 mov.b r0,@r3
    c.r[3] += 4;  // 060B7D52 add #4,r3
    c.r[1] = 0x7u;  // 060B7D54 mov #7,r1
L_060B7D56:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060B7D56 mov.b @r2,r0
    c.r[2] += 2;  // 060B7D58 add #2,r2
    st8(c.r[3], c.r[0]);  // 060B7D5A mov.b r0,@r3
    c.r[3] += 1;  // 060B7D5C add #1,r3
    c.r[1] -= 1; c.t = c.r[1] == 0;  // 060B7D5E dt r1
    if (!c.t) { SH2_POLL(c); goto L_060B7D56; }  // 060B7D60 bf 0x060B7D56
    c.r[3] += 1;  // 060B7D62 add #1,r3
    c.r[1] = 0x4u;  // 060B7D64 mov #4,r1
L_060B7D66:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060B7D66 mov.b @r2,r0
    c.r[2] += 2;  // 060B7D68 add #2,r2
    st8(c.r[3], c.r[0]);  // 060B7D6A mov.b r0,@r3
    c.r[3] += 1;  // 060B7D6C add #1,r3
    c.r[1] -= 1; c.t = c.r[1] == 0;  // 060B7D6E dt r1
    if (!c.t) { SH2_POLL(c); goto L_060B7D66; }  // 060B7D70 bf 0x060B7D66
    c.r[1] = 0x4u;  // 060B7D72 mov #4,r1
L_060B7D74:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060B7D74 mov.b @r2,r0
    c.r[2] += 2;  // 060B7D76 add #2,r2
    st8(c.r[3], c.r[0]);  // 060B7D78 mov.b r0,@r3
    c.r[3] += 1;  // 060B7D7A add #1,r3
    c.r[1] -= 1; c.t = c.r[1] == 0;  // 060B7D7C dt r1
    if (!c.t) { SH2_POLL(c); goto L_060B7D74; }  // 060B7D7E bf 0x060B7D74
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060B7D80 rts ; nop
}

void f_060B7D84(SH2Context& c) {
    ran[3151] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[4]);  // 060B7D84 mov.l r4,@-r15
    c.r[2] = ld32(0x060B7E28u);  // 060B7D86 mov.l 0x060B7E28,r2
    c.r[1] = ld32(0x060B7E1Cu);  // 060B7D88 mov.l 0x060B7E1C,r1
    c.r[0] = ld32(c.r[2]);  // 060B7D8A mov.l @r2,r0
    c.r[3] = ld32(0x060B7E20u);  // 060B7D8C mov.l 0x060B7E20,r3
    c.t = c.r[0] >= c.r[1];  // 060B7D8E cmp/hs r1,r0
    if (c.t) { goto L_060B7DA6; }  // 060B7D90 bt 0x060B7DA6
    c.r[3] = ld32(c.r[3]);  // 060B7D92 mov.l @r3,r3
    c.r[2] = ld32(0x060B7E18u);  // 060B7D94 mov.l 0x060B7E18,r2
    c.r[1] = 0x20u;  // 060B7D96 mov #32,r1
L_060B7D98:
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060B7D98 mov.b @r2,r4
    c.r[2] += 2;  // 060B7D9A add #2,r2
    st8(c.r[0] + c.r[3], c.r[4]);  // 060B7D9C mov.b r4,@(r0,r3)
    c.r[0] += 1;  // 060B7D9E add #1,r0
    c.r[1] -= 1; c.t = c.r[1] == 0;  // 060B7DA0 dt r1
    if (!c.t) { SH2_POLL(c); goto L_060B7D98; }  // 060B7DA2 bf 0x060B7D98
    c.r[2] = ld32(0x060B7E28u);  // 060B7DA4 mov.l 0x060B7E28,r2
L_060B7DA6:
    c.r[4] = ld32(c.r[15]); c.r[15] += 4;  // 060B7DA6 mov.l @r15+,r4
    { const uint32_t x = c.pr; st32(c.r[2], c.r[0]); c.pc = x; return; }  // 060B7DA8 rts ; mov.l r0,@r2
}

void f_060B7DAC(SH2Context& c) {
    ran[3152] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 060B7DAC mov.l r0,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[4]);  // 060B7DAE mov.l r4,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[3]);  // 060B7DB0 mov.l r3,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 060B7DB2 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060B7DB4 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060B7DB6 sts.l pr,@-r15
    c.r[15] -= 4; st32(c.r[15], c.mach);  // 060B7DB8 sts.l mach,@-r15
    c.r[2] = ld32(0x060B7E10u);  // 060B7DBA mov.l 0x060B7E10,r2
    c.r[15] -= 4; st32(c.r[15], c.macl);  // 060B7DBC sts.l macl,@-r15
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060B7DBE mov.b @r2,r0
    c.t = (c.r[0] & 0x80u) == 0;  // 060B7DC0 tst #128,r0
    { const bool k = !c.t; c.r[4] = c.r[0]; if (k) { goto L_060B7DCE; } }  // 060B7DC2 bf/s 0x060B7DCE ; mov r0,r4
    c.pr = 0x060B7DCAu; SH2_POLL(c); sh2_call(c, 0x060B7D48u); if (c.pc != 0x060B7DCAu) return;  // 060B7DC6 bsr 0x060B7D48 ; nop
    goto L_060B7DD2;  // 060B7DCA bra 0x060B7DD2 ; nop
L_060B7DCE:
    c.pr = 0x060B7DD2u; SH2_POLL(c); sh2_call(c, 0x060B7D84u); if (c.pc != 0x060B7DD2u) return;  // 060B7DCE bsr 0x060B7D84 ; nop
L_060B7DD2:
    c.r[1] = ld32(0x060B7E30u);  // 060B7DD2 mov.l 0x060B7E30,r1
    c.r[0] = c.r[4];  // 060B7DD4 mov r4,r0
    c.r[2] = ld32(0x060B7E34u);  // 060B7DD6 mov.l 0x060B7E34,r2
    st8(c.r[1], c.r[0]);  // 060B7DD8 mov.b r0,@r1
    c.r[3] = ld32(0x060B7E14u);  // 060B7DDA mov.l 0x060B7E14,r3
    c.t = (c.r[0] & 0x20u) == 0;  // 060B7DDC tst #32,r0
    if (c.t) { goto L_060B7DEC; }  // 060B7DDE bt 0x060B7DEC
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060B7DE0 mov.b @r2,r0
    c.r[0] ^= 0x80u;  // 060B7DE2 xor #128,r0
    st8(c.r[2], c.r[0]);  // 060B7DE4 mov.b r0,@r2
    st8(c.r[3], c.r[0]);  // 060B7DE6 mov.b r0,@(0,r3)
    goto L_060B7DFC;  // 060B7DE8 bra 0x060B7DFC ; nop
L_060B7DEC:
    c.r[3] = ld32(0x060B7E2Cu);  // 060B7DEC mov.l 0x060B7E2C,r3
    c.t = (c.r[0] & 0x80u) == 0;  // 060B7DEE tst #128,r0
    { const bool k = c.t; { uint32_t a = c.r[3], v = ld8(a); c.t = v == 0; st8(a, v | 0x80u); } if (k) { goto L_060B7DFC; } }  // 060B7DF0 bt/s 0x060B7DFC ; tas.b @r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060B7DF4 mov.b @r2,r0
    c.r[0] |= 0x40u;  // 060B7DF6 or #64,r0
    st8(c.r[2], c.r[0]);  // 060B7DF8 mov.b r0,@r2
    st8(c.r[3], c.r[0]);  // 060B7DFA mov.b r0,@(0,r3)
L_060B7DFC:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.macl = v; }  // 060B7DFC lds.l @r15+,macl
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.mach = v; }  // 060B7DFE lds.l @r15+,mach
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060B7E00 lds.l @r15+,pr
    c.r[1] = ld32(c.r[15]); c.r[15] += 4;  // 060B7E02 mov.l @r15+,r1
    c.r[2] = ld32(c.r[15]); c.r[15] += 4;  // 060B7E04 mov.l @r15+,r2
    c.r[3] = ld32(c.r[15]); c.r[15] += 4;  // 060B7E06 mov.l @r15+,r3
    c.r[4] = ld32(c.r[15]); c.r[15] += 4;  // 060B7E08 mov.l @r15+,r4
    { const uint32_t x = c.pr; c.r[0] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060B7E0A rts ; mov.l @r15+,r0
}

void f_060B7E38(SH2Context& c) {
    ran[3153] = 1;
    c.r[10] = ld32(0x060B7F4Cu);  // 060B7E38 mov.l 0x060B7F4C,r10
    c.r[11] = ld32(0x060B7F48u);  // 060B7E3A mov.l 0x060B7F48,r11
    c.r[10] = ld32(c.r[10]);  // 060B7E3C mov.l @r10,r10
    c.r[12] = (uint32_t)(int16_t)ld16(0x060B7F42u);  // 060B7E3E mov.w 0x060B7F42,r12
    c.r[11] = ld32(c.r[11]);  // 060B7E40 mov.l @r11,r11
    c.r[0] = ld32(0x060B7F68u);  // 060B7E42 mov.l 0x060B7F68,r0
    c.r[10] += c.r[12];  // 060B7E44 add r12,r10
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0]);  // 060B7E46 mov.b @r0,r0
    c.r[12] = c.r[10];  // 060B7E48 mov r10,r12
    c.t = (c.r[0] & 0x80u) == 0;  // 060B7E4A tst #128,r0
    { const bool k = c.t; c.r[10] -= 4; if (k) { goto L_060B7E56; } }  // 060B7E4C bt/s 0x060B7E56 ; add #-4,r10
    c.r[0] = ld32(0x060B7F6Cu);  // 060B7E50 mov.l 0x060B7F6C,r0
    st32(c.r[11] + 8, c.r[0]);  // 060B7E52 mov.l r0,@(8,r11)
    c.r[11] += 12;  // 060B7E54 add #12,r11
L_060B7E56:
    c.r[9] = (uint32_t)(int16_t)ld16(0x060B7F44u);  // 060B7E56 mov.w 0x060B7F44,r9
    c.r[8] = ld32(c.r[10]);  // 060B7E58 mov.l @r10,r8
L_060B7E5A:
    c.r[10] -= 4;  // 060B7E5A add #-4,r10
    c.t = (c.r[8] & c.r[8]) == 0;  // 060B7E5C tst r8,r8
    { const bool k = !c.t; c.r[9] -= 1; c.t = c.r[9] == 0; if (k) { goto L_060B7E82; } }  // 060B7E5E bf/s 0x060B7E82 ; dt r9
    { const bool k = !c.t; c.r[8] = ld32(c.r[10]); if (k) { SH2_POLL(c); goto L_060B7E5A; } }  // 060B7E62 bf/s 0x060B7E5A ; mov.l @r10,r8
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 169);  // 060B7E66 mov.b @(169,gbr),r0
    c.t = (c.r[0] & 0x20u) == 0;  // 060B7E68 tst #32,r0
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_060B7EE4; } }  // 060B7E6A bt/s 0x060B7EE4 ; mov #0,r0
    st8(c.gbr + 169, c.r[0]);  // 060B7E6E mov.b r0,@(169,gbr)
    c.r[0] = c.r[10];  // 060B7E70 mov r10,r0
    c.r[1] = ld32(0x060B7F54u);  // 060B7E72 mov.l 0x060B7F54,r1
    c.r[0] += 4;  // 060B7E74 add #4,r0
    c.r[2] = ld32(0x060B7F5Cu);  // 060B7E76 mov.l 0x060B7F5C,r2
    st32(c.gbr + 56, c.r[0]);  // 060B7E78 mov.l r0,@(56,gbr)
    st32(c.r[11] + 8, c.r[1]);  // 060B7E7A mov.l r1,@(8,r11)
    st32(c.r[11] + 20, c.r[2]);  // 060B7E7C mov.l r2,@(20,r11)
    c.r[11] += 24; SH2_POLL(c); goto L_060B7E56;  // 060B7E7E bra 0x060B7E56 ; add #24,r11
L_060B7E82:
    c.r[6] = 0x0u;  // 060B7E82 mov #0,r6
    c.r[7] = 0x0u;  // 060B7E84 mov #0,r7
L_060B7E86:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[8] + 30);  // 060B7E86 mov.w @(30,r8),r0
    c.r[2] = ld32(c.r[8] + 32);  // 060B7E88 mov.l @(32,r8),r2
    c.r[0] = c.r[0] & 0xFFu;  // 060B7E8A extu.b r0,r0
    c.r[0] <<= 2;  // 060B7E8C shll2 r0
    c.t = c.r[6] >= c.r[0];  // 060B7E8E cmp/hs r0,r6
    { const bool k = c.t; c.r[1] = ld32(c.r[0] + c.r[12]); if (k) { goto L_060B7E96; } }  // 060B7E90 bt/s 0x060B7E96 ; mov.l @(r0,r12),r1
    c.r[6] = c.r[0];  // 060B7E94 mov r0,r6
L_060B7E96:
    st32(c.r[8] + 32, c.r[1]);  // 060B7E96 mov.l r1,@(32,r8)
    c.r[7] += 1;  // 060B7E98 add #1,r7
    st32(c.r[0] + c.r[12], c.r[8]);  // 060B7E9A mov.l r8,@(r0,r12)
    c.t = (c.r[2] & c.r[2]) == 0;  // 060B7E9C tst r2,r2
    { const bool k = !c.t; c.r[8] = c.r[2]; if (k) { SH2_POLL(c); goto L_060B7E86; } }  // 060B7E9E bf/s 0x060B7E86 ; mov r2,r8
    st32(c.r[10] + 4, c.r[2]);  // 060B7EA2 mov.l r2,@(4,r10)
    c.r[8] = c.r[12];  // 060B7EA4 mov r12,r8
    c.r[8] += c.r[6];  // 060B7EA6 add r6,r8
L_060B7EA8:
    c.r[6] = ld32(c.r[8]);  // 060B7EA8 mov.l @r8,r6
    c.r[8] -= 4;  // 060B7EAA add #-4,r8
    c.t = (c.r[6] & c.r[6]) == 0;  // 060B7EAC tst r6,r6
    if (c.t) { SH2_POLL(c); goto L_060B7EA8; }  // 060B7EAE bt 0x060B7EA8
L_060B7EB0:
    c.r[0] = ld32(c.r[6] + 32);  // 060B7EB0 mov.l @(32,r6),r0
    st32(c.r[11] + 8, c.r[6]);  // 060B7EB2 mov.l r6,@(8,r11)
    c.r[11] += 12;  // 060B7EB4 add #12,r11
    c.r[6] = c.r[0];  // 060B7EB6 mov r0,r6
    c.t = (c.r[0] & c.r[0]) == 0;  // 060B7EB8 tst r0,r0
    { const bool k = !c.t; c.r[7] -= 1; c.t = c.r[7] == 0; if (k) { SH2_POLL(c); goto L_060B7EB0; } }  // 060B7EBA bf/s 0x060B7EB0 ; dt r7
    { const bool k = !c.t; st32(c.r[8] + 4, c.r[0]); if (k) { SH2_POLL(c); goto L_060B7EA8; } }  // 060B7EBE bf/s 0x060B7EA8 ; mov.l r0,@(4,r8)
    c.t = (c.r[9] & c.r[9]) == 0;  // 060B7EC2 tst r9,r9
    { const bool k = !c.t; c.r[8] = ld32(c.r[10]); if (k) { SH2_POLL(c); goto L_060B7E5A; } }  // 060B7EC4 bf/s 0x060B7E5A ; mov.l @r10,r8
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 169);  // 060B7EC8 mov.b @(169,gbr),r0
    c.t = (c.r[0] & 0x20u) == 0;  // 060B7ECA tst #32,r0
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_060B7EE4; } }  // 060B7ECC bt/s 0x060B7EE4 ; mov #0,r0
    st8(c.gbr + 169, c.r[0]);  // 060B7ED0 mov.b r0,@(169,gbr)
    c.r[0] = c.r[10];  // 060B7ED2 mov r10,r0
    c.r[0] += 4;  // 060B7ED4 add #4,r0
    c.r[1] = ld32(0x060B7F54u);  // 060B7ED6 mov.l 0x060B7F54,r1
    c.r[2] = ld32(0x060B7F5Cu);  // 060B7ED8 mov.l 0x060B7F5C,r2
    st32(c.gbr + 56, c.r[0]);  // 060B7EDA mov.l r0,@(56,gbr)
    st32(c.r[11] + 8, c.r[1]);  // 060B7EDC mov.l r1,@(8,r11)
    st32(c.r[11] + 20, c.r[2]);  // 060B7EDE mov.l r2,@(20,r11)
    c.r[11] += 24; SH2_POLL(c); goto L_060B7E56;  // 060B7EE0 bra 0x060B7E56 ; add #24,r11
L_060B7EE4:
    c.r[2] = ld32(0x060B7F60u);  // 060B7EE4 mov.l 0x060B7F60,r2
    st32(c.r[11] + 8, c.r[2]);  // 060B7EE6 mov.l r2,@(8,r11)
    c.r[1] = ld32(c.r[11] + 4);  // 060B7EE8 mov.l @(4,r11),r1
    c.r[0] = 0x1u;  // 060B7EEA mov #1,r0
    st8(c.gbr + 168, c.r[0]);  // 060B7EEC mov.b r0,@(168,gbr)
    c.r[0] = c.r[1] & 0xFFFFu;  // 060B7EEE extu.w r1,r0
    c.r[0] >>= 2;  // 060B7EF0 shlr2 r0
    c.r[0] >>= 2;  // 060B7EF2 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060B7EF4 shlr r0
    c.r[0] -= 3;  // 060B7EF6 add #-3,r0
    st16(c.gbr + 164, c.r[0]);  // 060B7EF8 mov.w r0,@(164,gbr)
    c.r[0] = 0xFFFFFFFFu;  // 060B7EFA mov #-1,r0
    st8(c.gbr + 166, c.r[0]);  // 060B7EFC mov.b r0,@(166,gbr)
    c.r[6] = ld32(0x060B7F50u);  // 060B7EFE mov.l 0x060B7F50,r6
    c.r[4] -= 4;  // 060B7F00 add #-4,r4
    c.r[7] = ld32(0x060B7F74u);  // 060B7F02 mov.l 0x060B7F74,r7
    c.r[0] = ld32(c.r[6]);  // 060B7F04 mov.l @(0,r6),r0
    c.r[1] = ld32(c.r[6] + 12);  // 060B7F06 mov.l @(12,r6),r1
    c.r[2] = ld32(c.r[6] + 20);  // 060B7F08 mov.l @(20,r6),r2
    st32(c.r[7], c.r[0]);  // 060B7F0A mov.l r0,@(0,r7)
    st32(c.r[7] + 12, c.r[1]);  // 060B7F0C mov.l r1,@(12,r7)
    st32(c.r[7] + 20, c.r[2]);  // 060B7F0E mov.l r2,@(20,r7)
    c.r[0] = ld32(c.r[6] + 44);  // 060B7F10 mov.l @(44,r6),r0
    c.r[1] = ld32(c.r[6] + 56);  // 060B7F12 mov.l @(56,r6),r1
    st32(c.r[7] + 32, c.r[0]);  // 060B7F14 mov.l r0,@(32,r7)
    st32(c.r[7] + 44, c.r[1]);  // 060B7F16 mov.l r1,@(44,r7)
    c.r[2] = ld32(0x060B7F64u);  // 060B7F18 mov.l 0x060B7F64,r2
    c.r[0] = ld32(c.gbr + 64);  // 060B7F1A mov.l @(64,gbr),r0
    c.r[2] = ld32(c.r[2]);  // 060B7F1C mov.l @r2,r2
    c.r[0] += c.r[2];  // 060B7F1E add r2,r0
    st32(c.gbr + 52, c.r[0]);  // 060B7F20 mov.l r0,@(52,gbr)
    c.r[1] = 0xFFFFFFA4u;  // 060B7F22 mov #-92,r1
    c.r[1] <<= 2;  // 060B7F24 shll2 r1
    c.r[0] = 0x11u;  // 060B7F26 mov #17,r0
    st8(c.r[1] + 2, c.r[0]);  // 060B7F28 mov.b r0,@(2,r1)
    ;  // 060B7F2A nop
    ;  // 060B7F2C nop
    ;  // 060B7F2E nop
    ;  // 060B7F30 nop
    ;  // 060B7F32 nop
    ;  // 060B7F34 nop
    ;  // 060B7F36 nop
    ;  // 060B7F38 nop
    ;  // 060B7F3A nop
    ;  // 060B7F3C nop
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060B7F3E rts ; nop
}

void f_060B7F78(SH2Context& c) {
    ran[3154] = 1;
    c.r[1] = c.r[0] & 0xFFFFu;  // 060B7F78 extu.w r0,r1
    c.r[5] = c.r[0] << 16 | c.r[0] >> 16;  // 060B7F7A swap.w r0,r5
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 160);  // 060B7F7C mov.w @(160,gbr),r0
    c.t = c.r[1] > c.r[0];  // 060B7F7E cmp/hi r0,r1
    if (c.t) { goto L_060B7FD0; }  // 060B7F80 bt 0x060B7FD0
    c.r[0] = ld32(c.gbr + 52);  // 060B7F82 mov.l @(52,gbr),r0
    c.r[11] = c.r[0];  // 060B7F84 mov r0,r11
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 169);  // 060B7F86 mov.b @(169,gbr),r0
    st16(c.r[11], c.r[5]);  // 060B7F88 mov.w r5,@r11
    c.t = (c.r[0] & 0x1u) == 0;  // 060B7F8A tst #1,r0
    { const bool k = !c.t; c.r[3] = 0x20u; if (k) { goto L_060B7F92; } }  // 060B7F8C bf/s 0x060B7F92 ; mov #32,r3
    c.r[3] = 0x10u;  // 060B7F90 mov #16,r3
L_060B7F92:
    c.r[0] |= c.r[3];  // 060B7F92 or r3,r0
    st8(c.gbr + 169, c.r[0]);  // 060B7F94 mov.b r0,@(169,gbr)
    c.r[0] = c.r[1];  // 060B7F96 mov r1,r0
    st16(c.r[11] + 30, c.r[0]);  // 060B7F98 mov.w r0,@(30,r11)
    c.r[1] >>= 8;  // 060B7F9A shlr8 r1
    c.r[0] = ld32(c.gbr + 56);  // 060B7F9C mov.l @(56,gbr),r0
    c.r[1] <<= 2;  // 060B7F9E shll2 r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060B7FA0 mov.l @(r0,r1),r2
    st32(c.r[0] + c.r[1], c.r[11]);  // 060B7FA2 mov.l r11,@(r0,r1)
    st32(c.r[11] + 32, c.r[2]);  // 060B7FA4 mov.l r2,@(32,r11)
    c.r[4] -= 4;  // 060B7FA6 add #-4,r4
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[4] + 6);  // 060B7FA8 mov.w @(6,r4),r0
    st16(c.r[11] + 28, c.r[0]);  // 060B7FAA mov.w r0,@(28,r11)
    c.r[2] = ld32(c.r[4] + 8);  // 060B7FAC mov.l @(8,r4),r2
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[4] + 4);  // 060B7FAE mov.w @(4,r4),r0
    st32(c.r[11] + 4, c.r[2]);  // 060B7FB0 mov.l r2,@(4,r11)
    c.r[1] = c.r[0] & 0xFFFFu;  // 060B7FB2 extu.w r0,r1
    c.r[0] = ld32(c.gbr + 60);  // 060B7FB4 mov.l @(60,gbr),r0
    c.r[1] <<= 2;  // 060B7FB6 shll2 r1
    c.t = c.r[1] >> 31; c.r[1] <<= 1;  // 060B7FB8 shll r1
    c.r[1] += c.r[0];  // 060B7FBA add r0,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 060B7FBC mov.w @r1+,r2
    c.r[0] = ld32(c.r[4] + 20);  // 060B7FBE mov.l @(20,r4),r0
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]); c.r[1] += 2;  // 060B7FC0 mov.w @r1+,r3
    c.macl = c.r[0] * c.r[2];  // 060B7FC2 mul.l r2,r0
    c.r[1] = ld32(c.r[1]);  // 060B7FC4 mov.l @r1,r1
    st32(c.r[11] + 8, c.r[1]);  // 060B7FC6 mov.l r1,@(8,r11)
    c.r[2] = c.macl;  // 060B7FC8 sts macl,r2
    c.macl = c.r[0] * c.r[3];  // 060B7FCA mul.l r3,r0
    { const uint32_t x = c.pr; c.r[3] = c.macl; c.pc = x; return; }  // 060B7FCC rts ; sts macl,r3
L_060B7FD0:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060B7FD0 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[4] += c.r[2]; c.pc = x; return; }  // 060B7FD2 rts ; add r2,r4
}

void f_060B7FD6(SH2Context& c) {
    ran[3155] = 1;
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060B7FD6 sts.l pr,@-r15
    c.pr = 0x060B7FDCu; c.r[2] = 0x14u; SH2_POLL(c); sh2_call(c, 0x060B7F78u); if (c.pc != 0x060B7FDCu) return;  // 060B7FD8 bsr 0x060B7F78 ; mov #20,r2
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[4] + 12);  // 060B7FDC mov.w @(12,r4),r0
    c.r[1] = ld32(c.r[4] + 16);  // 060B7FDE mov.l @(16,r4),r1
    c.r[7] = c.r[0];  // 060B7FE0 mov r0,r7
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 156);  // 060B7FE2 mov.w @(156,gbr),r0
    c.r[6] = c.r[7];  // 060B7FE4 mov r7,r6
    c.r[6] += c.r[0];  // 060B7FE6 add r0,r6
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 140);  // 060B7FE8 mov.w @(140,gbr),r0
    c.r[2] >>= 16;  // 060B7FEA shlr16 r2
    c.t = c.r[6] > c.r[0];  // 060B7FEC cmp/hi r0,r6
    { const bool k = c.t; c.r[4] += 24; if (k) { goto L_060B802A; } }  // 060B7FEE bt/s 0x060B802A ; add #24,r4
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 158);  // 060B7FF2 mov.w @(158,gbr),r0
    c.r[6] = c.r[1] << 16 | c.r[1] >> 16;  // 060B7FF4 swap.w r1,r6
    c.r[6] = (uint32_t)(int32_t)(int16_t)c.r[6];  // 060B7FF6 exts.w r6,r6
    c.r[6] += c.r[0];  // 060B7FF8 add r0,r6
    c.r[0] = (uint32_t)(int16_t)ld16(c.gbr + 142);  // 060B7FFA mov.w @(142,gbr),r0
    c.r[1] = c.r[7] << 16 | c.r[1] >> 16;  // 060B7FFC xtrct r7,r1
    c.t = c.r[6] > c.r[0];  // 060B7FFE cmp/hi r0,r6
    { const bool k = c.t; c.r[3] = c.r[2] << 16 | c.r[3] >> 16; if (k) { goto L_060B802A; } }  // 060B8000 bt/s 0x060B802A ; xtrct r2,r3
    st32(c.r[11] + 12, c.r[1]);  // 060B8004 mov.l r1,@(12,r11)
    st32(c.r[11] + 16, c.r[3]);  // 060B8006 mov.l r3,@(16,r11)
    c.r[1] = 0xFFFFFFF0u;  // 060B8008 mov #-16,r1
    c.r[5] &= c.r[1];  // 060B800A and r1,r5
    c.r[5] += 1;  // 060B800C add #1,r5
    c.r[0] = (c.r[5] & 0xFFFF0000u) | (c.r[5] & 0xFFu) << 8 | (c.r[5] >> 8 & 0xFFu);  // 060B800E swap.b r5,r0
    c.t = (c.r[0] & 0x3u) == 0;  // 060B8010 tst #3,r0
    { const bool k = !c.t; c.t = (c.r[0] & 0xCu) == 0; if (k) { goto L_060B801C; } }  // 060B8012 bf/s 0x060B801C ; tst #12,r0
    c.r[0] |= 0x2u;  // 060B8016 or #2,r0
    if (!c.t) { goto L_060B801C; }  // 060B8018 bf 0x060B801C
    c.r[0] |= 0x8u;  // 060B801A or #8,r0
L_060B801C:
    c.r[0] = (c.r[0] & 0xFFFF0000u) | (c.r[0] & 0xFFu) << 8 | (c.r[0] >> 8 & 0xFFu);  // 060B801C swap.b r0,r0
    st16(c.r[11], c.r[0]);  // 060B801E mov.w r0,@(0,r11)
    c.r[0] = c.r[11];  // 060B8020 mov r11,r0
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060B8022 lds.l @r15+,pr
    c.r[0] += 36;  // 060B8024 add #36,r0
    { const uint32_t x = c.pr; st32(c.gbr + 52, c.r[0]); c.pc = x; return; }  // 060B8026 rts ; mov.l r0,@(52,gbr)
L_060B802A:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[11] + 30);  // 060B802A mov.w @(30,r11),r0
    c.r[1] = ld32(c.r[11] + 32);  // 060B802C mov.l @(32,r11),r1
    c.r[2] = (c.r[0] & 0xFFFF0000u) | (c.r[0] & 0xFFu) << 8 | (c.r[0] >> 8 & 0xFFu);  // 060B802E swap.b r0,r2
    c.r[0] = ld32(c.gbr + 56);  // 060B8030 mov.l @(56,gbr),r0
    c.r[2] = c.r[2] & 0xFFu;  // 060B8032 extu.b r2,r2
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060B8034 lds.l @r15+,pr
    c.r[2] <<= 2;  // 060B8036 shll2 r2
    { const uint32_t x = c.pr; st32(c.r[0] + c.r[2], c.r[1]); c.pc = x; return; }  // 060B8038 rts ; mov.l r1,@(r0,r2)
}

void f_060B803C(SH2Context& c) {
    ran[3156] = 1;
L_060B803C:
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060B803C sts.l pr,@-r15
L_060B803E:
    c.pr = 0x060B8042u; c.r[2] = 0x1Cu; SH2_POLL(c); sh2_call(c, 0x060B7F78u); if (c.pc != 0x060B8042u) return;  // 060B803E bsr 0x060B7F78 ; mov #28,r2
L_060B8042:
    c.r[7] = ld32(c.r[4] + 24);  // 060B8042 mov.l @(24,r4),r7
L_060B8044:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060B8044 lds.l @r15+,pr
L_060B8046:
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[7] * (int32_t)c.r[2]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060B8046 dmuls.l r2,r7
L_060B8048:
    c.r[0] = ld32(c.gbr + 140);  // 060B8048 mov.l @(140,gbr),r0
L_060B804A:
    c.r[8] = ld32(c.r[4] + 28);  // 060B804A mov.l @(28,r4),r8
L_060B804C:
    c.r[14] = c.r[0];  // 060B804C mov r0,r14
L_060B804E:
    c.r[1] = c.mach;  // 060B804E sts mach,r1
L_060B8050:
    c.r[6] = c.macl;  // 060B8050 sts macl,r6
L_060B8052:
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[7] * (int32_t)c.r[3]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060B8052 dmuls.l r3,r7
L_060B8054:
    c.r[14] <<= 16;  // 060B8054 shll16 r14
L_060B8056:
    c.r[0] >>= 16;  // 060B8056 shlr16 r0
L_060B8058:
    c.r[6] = c.r[1] << 16 | c.r[6] >> 16;  // 060B8058 xtrct r1,r6
L_060B805A:
    c.r[1] = c.mach;  // 060B805A sts mach,r1
L_060B805C:
    c.r[7] = c.macl;  // 060B805C sts macl,r7
L_060B805E:
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[8] * (int32_t)c.r[2]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060B805E dmuls.l r2,r8
L_060B8060:
    c.r[13] = c.r[0] << 16 | c.r[0] >> 16;  // 060B8060 swap.w r0,r13
L_060B8062:
    c.r[0] = ld32(c.gbr + 156);  // 060B8062 mov.l @(156,gbr),r0
L_060B8064:
    c.r[7] = c.r[1] << 16 | c.r[7] >> 16;  // 060B8064 xtrct r1,r7
L_060B8066:
    c.r[1] = c.mach;  // 060B8066 sts mach,r1
L_060B8068:
    c.r[2] = c.macl;  // 060B8068 sts macl,r2
L_060B806A:
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[8] * (int32_t)c.r[3]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060B806A dmuls.l r3,r8
L_060B806C:
    c.r[12] = c.r[0];  // 060B806C mov r0,r12
L_060B806E:
    c.r[12] <<= 16;  // 060B806E shll16 r12
L_060B8070:
    c.r[2] = c.r[1] << 16 | c.r[2] >> 16;  // 060B8070 xtrct r1,r2
L_060B8072:
    c.r[1] = c.mach;  // 060B8072 sts mach,r1
L_060B8074:
    c.r[3] = c.macl;  // 060B8074 sts macl,r3
L_060B8076:
    c.r[0] >>= 16;  // 060B8076 shlr16 r0
L_060B8078:
    c.r[10] = c.r[0] << 16 | c.r[0] >> 16;  // 060B8078 swap.w r0,r10
L_060B807A:
    c.r[3] = c.r[1] << 16 | c.r[3] >> 16;  // 060B807A xtrct r1,r3
L_060B807C:
    c.r[0] = (c.r[5] & 0xFFFF0000u) | (c.r[5] & 0xFFu) << 8 | (c.r[5] >> 8 & 0xFFu);  // 060B807C swap.b r5,r0
L_060B807E:
    c.r[0] &= 0xFu;  // 060B807E and #15,r0
L_060B8080:
    c.r[1] = c.r[0];  // 060B8080 mov r0,r1
L_060B8082:
    c.r[1] <<= 2;  // 060B8082 shll2 r1
L_060B8084:
    c.r[0] = 0x060B8090u;  // 060B8084 mova 0x060B8090,r0
L_060B8086:
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 060B8086 mov.l @(r0,r1),r1
L_060B8088:
    c.r[8] = ld32(c.r[4] + 12);  // 060B8088 mov.l @(12,r4),r8
L_060B808A:
    { const uint32_t x = c.r[1]; c.r[9] = ld32(c.r[4] + 16); switch (x) { case 0x060B8256u: goto L_060B8256; case 0x060B8170u: goto L_060B8170; case 0x060B80DAu: goto L_060B80DA; case 0x060B8166u: goto L_060B8166; case 0x060B81DAu: goto L_060B81DA; case 0x060B8262u: goto L_060B8262; case 0x060B81D0u: goto L_060B81D0; case 0x060B8156u: goto L_060B8156; case 0x060B80D0u: goto L_060B80D0; case 0x060B815Eu: goto L_060B815E; default: sh2_call(c, x); return; } }  // 060B808A jmp @r1 ; mov.l @(16,r4),r9
L_060B80D0:
    c.r[1] = 0x20u;  // 060B80D0 mov #32,r1
L_060B80D2:
    c.r[5] ^= c.r[1];  // 060B80D2 xor r1,r5
L_060B80D4:
    st16(c.r[11], c.r[5]);  // 060B80D4 mov.w r5,@r11
L_060B80D6:
    c.r[3] = 0u - c.r[3];  // 060B80D6 neg r3,r3
L_060B80D8:
    c.r[7] = 0u - c.r[7];  // 060B80D8 neg r7,r7
L_060B80DA:
    c.r[0] = c.r[2];  // 060B80DA mov r2,r0
L_060B80DC:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B80DC shar r0
L_060B80DE:
    c.r[8] -= c.r[0];  // 060B80DE sub r0,r8
L_060B80E0:
    c.r[0] = c.r[8];  // 060B80E0 mov r8,r0
L_060B80E2:
    c.r[0] += c.r[10];  // 060B80E2 add r10,r0
L_060B80E4:
    c.t = c.r[0] > c.r[13];  // 060B80E4 cmp/hi r13,r0
L_060B80E6:
    { const bool k = c.t; c.r[4] += 32; if (k) { goto L_060B8146; } }  // 060B80E6 bt/s 0x060B8146 ; add #32,r4
L_060B80EA:
    c.r[0] = c.r[6];  // 060B80EA mov r6,r0
L_060B80EC:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B80EC shar r0
L_060B80EE:
    c.r[9] -= c.r[0];  // 060B80EE sub r0,r9
L_060B80F0:
    c.r[0] = c.r[9];  // 060B80F0 mov r9,r0
L_060B80F2:
    c.r[0] += c.r[12];  // 060B80F2 add r12,r0
L_060B80F4:
    c.t = c.r[0] > c.r[14];  // 060B80F4 cmp/hi r14,r0
L_060B80F6:
    { const bool k = c.t; c.r[1] = c.r[8] << 16 | c.r[8] >> 16; if (k) { goto L_060B8146; } }  // 060B80F6 bt/s 0x060B8146 ; swap.w r8,r1
L_060B80FA:
    c.r[8] += c.r[2];  // 060B80FA add r2,r8
L_060B80FC:
    c.r[0] = c.r[8];  // 060B80FC mov r8,r0
L_060B80FE:
    c.r[0] += c.r[10];  // 060B80FE add r10,r0
L_060B8100:
    c.t = c.r[0] > c.r[13];  // 060B8100 cmp/hi r13,r0
L_060B8102:
    { const bool k = c.t; c.r[5] = c.r[9]; if (k) { goto L_060B8146; } }  // 060B8102 bt/s 0x060B8146 ; mov r9,r5
L_060B8106:
    c.r[9] += c.r[6];  // 060B8106 add r6,r9
L_060B8108:
    c.r[0] = c.r[9];  // 060B8108 mov r9,r0
L_060B810A:
    c.r[0] += c.r[12];  // 060B810A add r12,r0
L_060B810C:
    c.t = c.r[0] > c.r[14];  // 060B810C cmp/hi r14,r0
L_060B810E:
    { const bool k = c.t; c.r[0] = c.r[8] << 16 | c.r[8] >> 16; if (k) { goto L_060B8146; } }  // 060B810E bt/s 0x060B8146 ; swap.w r8,r0
L_060B8112:
    c.r[5] = c.r[1] << 16 | c.r[5] >> 16;  // 060B8112 xtrct r1,r5
L_060B8114:
    c.r[1] = c.r[9];  // 060B8114 mov r9,r1
L_060B8116:
    c.r[1] = c.r[0] << 16 | c.r[1] >> 16;  // 060B8116 xtrct r0,r1
L_060B8118:
    c.r[8] -= c.r[7];  // 060B8118 sub r7,r8
L_060B811A:
    c.r[0] = c.r[8];  // 060B811A mov r8,r0
L_060B811C:
    c.r[0] += c.r[10];  // 060B811C add r10,r0
L_060B811E:
    c.t = c.r[0] > c.r[13];  // 060B811E cmp/hi r13,r0
L_060B8120:
    { const bool k = c.t; c.r[9] += c.r[3]; if (k) { goto L_060B8146; } }  // 060B8120 bt/s 0x060B8146 ; add r3,r9
L_060B8124:
    c.r[0] = c.r[9];  // 060B8124 mov r9,r0
L_060B8126:
    c.r[0] += c.r[12];  // 060B8126 add r12,r0
L_060B8128:
    c.t = c.r[0] > c.r[14];  // 060B8128 cmp/hi r14,r0
L_060B812A:
    { const bool k = c.t; c.r[3] = c.r[8] << 16 | c.r[8] >> 16; if (k) { goto L_060B8146; } }  // 060B812A bt/s 0x060B8146 ; swap.w r8,r3
L_060B812E:
    c.r[8] -= c.r[2];  // 060B812E sub r2,r8
L_060B8130:
    c.r[10] += c.r[8];  // 060B8130 add r8,r10
L_060B8132:
    c.t = c.r[10] > c.r[13];  // 060B8132 cmp/hi r13,r10
L_060B8134:
    { const bool k = c.t; c.r[7] = c.r[9]; if (k) { goto L_060B8146; } }  // 060B8134 bt/s 0x060B8146 ; mov r9,r7
L_060B8138:
    c.r[9] -= c.r[6];  // 060B8138 sub r6,r9
L_060B813A:
    c.r[12] += c.r[9];  // 060B813A add r9,r12
L_060B813C:
    c.t = c.r[12] > c.r[14];  // 060B813C cmp/hi r14,r12
L_060B813E:
    { const bool k = c.t; c.r[7] = c.r[3] << 16 | c.r[7] >> 16; if (k) { goto L_060B8146; } }  // 060B813E bt/s 0x060B8146 ; xtrct r3,r7
L_060B8142:
    c.r[8] = c.r[8] << 16 | c.r[8] >> 16; goto L_060B82D8;  // 060B8142 bra 0x060B82D8 ; swap.w r8,r8
L_060B8146:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[11] + 30);  // 060B8146 mov.w @(30,r11),r0
L_060B8148:
    c.r[1] = ld32(c.r[11] + 32);  // 060B8148 mov.l @(32,r11),r1
L_060B814A:
    c.r[2] = (c.r[0] & 0xFFFF0000u) | (c.r[0] & 0xFFu) << 8 | (c.r[0] >> 8 & 0xFFu);  // 060B814A swap.b r0,r2
L_060B814C:
    c.r[0] = ld32(c.gbr + 56);  // 060B814C mov.l @(56,gbr),r0
L_060B814E:
    c.r[2] = c.r[2] & 0xFFu;  // 060B814E extu.b r2,r2
L_060B8150:
    c.r[2] <<= 2;  // 060B8150 shll2 r2
L_060B8152:
    { const uint32_t x = c.pr; st32(c.r[0] + c.r[2], c.r[1]); c.pc = x; return; }  // 060B8152 rts ; mov.l r1,@(r0,r2)
L_060B8156:
    c.r[1] = 0x20u;  // 060B8156 mov #32,r1
L_060B8158:
    c.r[3] = 0u - c.r[3];  // 060B8158 neg r3,r3
L_060B815A:
    c.r[7] = 0u - c.r[7]; goto L_060B816C;  // 060B815A bra 0x060B816C ; neg r7,r7
L_060B815E:
    c.r[1] = 0x30u;  // 060B815E mov #48,r1
L_060B8160:
    c.r[3] = 0u - c.r[3];  // 060B8160 neg r3,r3
L_060B8162:
    c.r[7] = 0u - c.r[7]; goto L_060B8168;  // 060B8162 bra 0x060B8168 ; neg r7,r7
L_060B8166:
    c.r[1] = 0x10u;  // 060B8166 mov #16,r1
L_060B8168:
    c.r[2] = 0u - c.r[2];  // 060B8168 neg r2,r2
L_060B816A:
    c.r[6] = 0u - c.r[6];  // 060B816A neg r6,r6
L_060B816C:
    c.r[5] ^= c.r[1];  // 060B816C xor r1,r5
L_060B816E:
    st16(c.r[11], c.r[5]);  // 060B816E mov.w r5,@r11
L_060B8170:
    c.r[0] = c.r[8];  // 060B8170 mov r8,r0
L_060B8172:
    c.r[0] += c.r[10];  // 060B8172 add r10,r0
L_060B8174:
    c.t = c.r[0] > c.r[13];  // 060B8174 cmp/hi r13,r0
L_060B8176:
    { const bool k = c.t; c.r[4] += 32; if (k) { SH2_POLL(c); goto L_060B8146; } }  // 060B8176 bt/s 0x060B8146 ; add #32,r4
L_060B817A:
    c.r[0] = c.r[9];  // 060B817A mov r9,r0
L_060B817C:
    c.r[0] += c.r[12];  // 060B817C add r12,r0
L_060B817E:
    c.t = c.r[0] > c.r[14];  // 060B817E cmp/hi r14,r0
L_060B8180:
    { const bool k = c.t; c.r[0] = c.r[8] << 16 | c.r[8] >> 16; if (k) { SH2_POLL(c); goto L_060B8146; } }  // 060B8180 bt/s 0x060B8146 ; swap.w r8,r0
L_060B8184:
    c.r[5] = c.r[9];  // 060B8184 mov r9,r5
L_060B8186:
    c.r[5] = c.r[0] << 16 | c.r[5] >> 16;  // 060B8186 xtrct r0,r5
L_060B8188:
    c.r[8] += c.r[2];  // 060B8188 add r2,r8
L_060B818A:
    c.r[0] = c.r[8];  // 060B818A mov r8,r0
L_060B818C:
    c.r[0] += c.r[10];  // 060B818C add r10,r0
L_060B818E:
    c.t = c.r[0] > c.r[13];  // 060B818E cmp/hi r13,r0
L_060B8190:
    { const bool k = c.t; c.r[9] += c.r[6]; if (k) { SH2_POLL(c); goto L_060B8146; } }  // 060B8190 bt/s 0x060B8146 ; add r6,r9
L_060B8194:
    c.r[0] = c.r[9];  // 060B8194 mov r9,r0
L_060B8196:
    c.r[0] += c.r[12];  // 060B8196 add r12,r0
L_060B8198:
    c.t = c.r[0] > c.r[14];  // 060B8198 cmp/hi r14,r0
L_060B819A:
    { const bool k = c.t; c.r[0] = c.r[8] << 16 | c.r[8] >> 16; if (k) { SH2_POLL(c); goto L_060B8146; } }  // 060B819A bt/s 0x060B8146 ; swap.w r8,r0
L_060B819E:
    c.r[1] = c.r[9];  // 060B819E mov r9,r1
L_060B81A0:
    c.r[1] = c.r[0] << 16 | c.r[1] >> 16;  // 060B81A0 xtrct r0,r1
L_060B81A2:
    c.r[8] -= c.r[7];  // 060B81A2 sub r7,r8
L_060B81A4:
    c.r[0] = c.r[8];  // 060B81A4 mov r8,r0
L_060B81A6:
    c.r[0] += c.r[10];  // 060B81A6 add r10,r0
L_060B81A8:
    c.t = c.r[0] > c.r[13];  // 060B81A8 cmp/hi r13,r0
L_060B81AA:
    { const bool k = c.t; c.r[9] += c.r[3]; if (k) { SH2_POLL(c); goto L_060B8146; } }  // 060B81AA bt/s 0x060B8146 ; add r3,r9
L_060B81AE:
    c.r[0] = c.r[9];  // 060B81AE mov r9,r0
L_060B81B0:
    c.r[0] += c.r[12];  // 060B81B0 add r12,r0
L_060B81B2:
    c.t = c.r[0] > c.r[14];  // 060B81B2 cmp/hi r14,r0
L_060B81B4:
    { const bool k = c.t; c.r[3] = c.r[8] << 16 | c.r[8] >> 16; if (k) { SH2_POLL(c); goto L_060B8146; } }  // 060B81B4 bt/s 0x060B8146 ; swap.w r8,r3
L_060B81B8:
    c.r[8] -= c.r[2];  // 060B81B8 sub r2,r8
L_060B81BA:
    c.r[10] += c.r[8];  // 060B81BA add r8,r10
L_060B81BC:
    c.t = c.r[10] > c.r[13];  // 060B81BC cmp/hi r13,r10
L_060B81BE:
    { const bool k = c.t; c.r[7] = c.r[9]; if (k) { SH2_POLL(c); goto L_060B8146; } }  // 060B81BE bt/s 0x060B8146 ; mov r9,r7
L_060B81C2:
    c.r[9] -= c.r[6];  // 060B81C2 sub r6,r9
L_060B81C4:
    c.r[12] += c.r[9];  // 060B81C4 add r9,r12
L_060B81C6:
    c.t = c.r[12] > c.r[14];  // 060B81C6 cmp/hi r14,r12
L_060B81C8:
    { const bool k = c.t; c.r[7] = c.r[3] << 16 | c.r[7] >> 16; if (k) { SH2_POLL(c); goto L_060B8146; } }  // 060B81C8 bt/s 0x060B8146 ; xtrct r3,r7
L_060B81CC:
    c.r[8] = c.r[8] << 16 | c.r[8] >> 16; goto L_060B82D8;  // 060B81CC bra 0x060B82D8 ; swap.w r8,r8
L_060B81D0:
    c.r[1] = 0x10u;  // 060B81D0 mov #16,r1
L_060B81D2:
    c.r[5] ^= c.r[1];  // 060B81D2 xor r1,r5
L_060B81D4:
    st16(c.r[11], c.r[5]);  // 060B81D4 mov.w r5,@r11
L_060B81D6:
    c.r[2] = 0u - c.r[2];  // 060B81D6 neg r2,r2
L_060B81D8:
    c.r[6] = 0u - c.r[6];  // 060B81D8 neg r6,r6
L_060B81DA:
    c.r[0] = c.r[7];  // 060B81DA mov r7,r0
L_060B81DC:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B81DC shar r0
L_060B81DE:
    c.r[8] += c.r[0];  // 060B81DE add r0,r8
L_060B81E0:
    c.r[0] = c.r[8];  // 060B81E0 mov r8,r0
L_060B81E2:
    c.r[0] += c.r[10];  // 060B81E2 add r10,r0
L_060B81E4:
    c.t = c.r[0] > c.r[13];  // 060B81E4 cmp/hi r13,r0
L_060B81E6:
    { const bool k = c.t; c.r[4] += 32; if (k) { goto L_060B8246; } }  // 060B81E6 bt/s 0x060B8246 ; add #32,r4
L_060B81EA:
    c.r[0] = c.r[3];  // 060B81EA mov r3,r0
L_060B81EC:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B81EC shar r0
L_060B81EE:
    c.r[9] -= c.r[0];  // 060B81EE sub r0,r9
L_060B81F0:
    c.r[0] = c.r[9];  // 060B81F0 mov r9,r0
L_060B81F2:
    c.r[0] += c.r[12];  // 060B81F2 add r12,r0
L_060B81F4:
    c.t = c.r[0] > c.r[14];  // 060B81F4 cmp/hi r14,r0
L_060B81F6:
    { const bool k = c.t; c.r[1] = c.r[8] << 16 | c.r[8] >> 16; if (k) { goto L_060B8246; } }  // 060B81F6 bt/s 0x060B8246 ; swap.w r8,r1
L_060B81FA:
    c.r[8] += c.r[2];  // 060B81FA add r2,r8
L_060B81FC:
    c.r[0] = c.r[8];  // 060B81FC mov r8,r0
L_060B81FE:
    c.r[0] += c.r[10];  // 060B81FE add r10,r0
L_060B8200:
    c.t = c.r[0] > c.r[13];  // 060B8200 cmp/hi r13,r0
L_060B8202:
    { const bool k = c.t; c.r[5] = c.r[9]; if (k) { goto L_060B8246; } }  // 060B8202 bt/s 0x060B8246 ; mov r9,r5
L_060B8206:
    c.r[9] += c.r[6];  // 060B8206 add r6,r9
L_060B8208:
    c.r[0] = c.r[9];  // 060B8208 mov r9,r0
L_060B820A:
    c.r[0] += c.r[12];  // 060B820A add r12,r0
L_060B820C:
    c.t = c.r[0] > c.r[14];  // 060B820C cmp/hi r14,r0
L_060B820E:
    { const bool k = c.t; c.r[0] = c.r[8] << 16 | c.r[8] >> 16; if (k) { goto L_060B8246; } }  // 060B820E bt/s 0x060B8246 ; swap.w r8,r0
L_060B8212:
    c.r[5] = c.r[1] << 16 | c.r[5] >> 16;  // 060B8212 xtrct r1,r5
L_060B8214:
    c.r[1] = c.r[9];  // 060B8214 mov r9,r1
L_060B8216:
    c.r[1] = c.r[0] << 16 | c.r[1] >> 16;  // 060B8216 xtrct r0,r1
L_060B8218:
    c.r[8] -= c.r[7];  // 060B8218 sub r7,r8
L_060B821A:
    c.r[0] = c.r[8];  // 060B821A mov r8,r0
L_060B821C:
    c.r[0] += c.r[10];  // 060B821C add r10,r0
L_060B821E:
    c.t = c.r[0] > c.r[13];  // 060B821E cmp/hi r13,r0
L_060B8220:
    { const bool k = c.t; c.r[9] += c.r[3]; if (k) { goto L_060B8246; } }  // 060B8220 bt/s 0x060B8246 ; add r3,r9
L_060B8224:
    c.r[0] = c.r[9];  // 060B8224 mov r9,r0
L_060B8226:
    c.r[0] += c.r[12];  // 060B8226 add r12,r0
L_060B8228:
    c.t = c.r[0] > c.r[14];  // 060B8228 cmp/hi r14,r0
L_060B822A:
    { const bool k = c.t; c.r[3] = c.r[8] << 16 | c.r[8] >> 16; if (k) { goto L_060B8246; } }  // 060B822A bt/s 0x060B8246 ; swap.w r8,r3
L_060B822E:
    c.r[8] -= c.r[2];  // 060B822E sub r2,r8
L_060B8230:
    c.r[10] += c.r[8];  // 060B8230 add r8,r10
L_060B8232:
    c.t = c.r[10] > c.r[13];  // 060B8232 cmp/hi r13,r10
L_060B8234:
    { const bool k = c.t; c.r[7] = c.r[9]; if (k) { goto L_060B8246; } }  // 060B8234 bt/s 0x060B8246 ; mov r9,r7
L_060B8238:
    c.r[9] -= c.r[6];  // 060B8238 sub r6,r9
L_060B823A:
    c.r[12] += c.r[9];  // 060B823A add r9,r12
L_060B823C:
    c.t = c.r[12] > c.r[14];  // 060B823C cmp/hi r14,r12
L_060B823E:
    { const bool k = c.t; c.r[7] = c.r[3] << 16 | c.r[7] >> 16; if (k) { goto L_060B8246; } }  // 060B823E bt/s 0x060B8246 ; xtrct r3,r7
L_060B8242:
    c.r[8] = c.r[8] << 16 | c.r[8] >> 16; goto L_060B82D8;  // 060B8242 bra 0x060B82D8 ; swap.w r8,r8
L_060B8246:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[11] + 30);  // 060B8246 mov.w @(30,r11),r0
L_060B8248:
    c.r[1] = ld32(c.r[11] + 32);  // 060B8248 mov.l @(32,r11),r1
L_060B824A:
    c.r[2] = (c.r[0] & 0xFFFF0000u) | (c.r[0] & 0xFFu) << 8 | (c.r[0] >> 8 & 0xFFu);  // 060B824A swap.b r0,r2
L_060B824C:
    c.r[0] = ld32(c.gbr + 56);  // 060B824C mov.l @(56,gbr),r0
L_060B824E:
    c.r[2] = c.r[2] & 0xFFu;  // 060B824E extu.b r2,r2
L_060B8250:
    c.r[2] <<= 2;  // 060B8250 shll2 r2
L_060B8252:
    { const uint32_t x = c.pr; st32(c.r[0] + c.r[2], c.r[1]); c.pc = x; return; }  // 060B8252 rts ; mov.l r1,@(r0,r2)
L_060B8256:
    c.r[5] = (c.r[5] & 0xFFFF0000u) | (c.r[5] & 0xFFu) << 8 | (c.r[5] >> 8 & 0xFFu);  // 060B8256 swap.b r5,r5
L_060B8258:
    c.r[0] = 0xFFFFFFF0u;  // 060B8258 mov #-16,r0
L_060B825A:
    c.r[0] &= c.r[5];  // 060B825A and r5,r0
L_060B825C:
    c.r[0] |= 0xAu;  // 060B825C or #10,r0
L_060B825E:
    c.r[0] = (c.r[0] & 0xFFFF0000u) | (c.r[0] & 0xFFu) << 8 | (c.r[0] >> 8 & 0xFFu);  // 060B825E swap.b r0,r0
L_060B8260:
    st16(c.r[11], c.r[0]);  // 060B8260 mov.w r0,@(0,r11)
L_060B8262:
    c.r[0] = c.r[2];  // 060B8262 mov r2,r0
L_060B8264:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B8264 shar r0
L_060B8266:
    c.r[8] -= c.r[0];  // 060B8266 sub r0,r8
L_060B8268:
    c.r[0] = c.r[7];  // 060B8268 mov r7,r0
L_060B826A:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B826A shar r0
L_060B826C:
    c.r[8] += c.r[0];  // 060B826C add r0,r8
L_060B826E:
    c.r[0] = c.r[8];  // 060B826E mov r8,r0
L_060B8270:
    c.r[0] += c.r[10];  // 060B8270 add r10,r0
L_060B8272:
    c.t = c.r[0] > c.r[13];  // 060B8272 cmp/hi r13,r0
L_060B8274:
    { const bool k = c.t; c.r[4] += 32; if (k) { SH2_POLL(c); goto L_060B8246; } }  // 060B8274 bt/s 0x060B8246 ; add #32,r4
L_060B8278:
    c.r[0] = c.r[3];  // 060B8278 mov r3,r0
L_060B827A:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B827A shar r0
L_060B827C:
    c.r[9] -= c.r[0];  // 060B827C sub r0,r9
L_060B827E:
    c.r[0] = c.r[6];  // 060B827E mov r6,r0
L_060B8280:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B8280 shar r0
L_060B8282:
    c.r[9] -= c.r[0];  // 060B8282 sub r0,r9
L_060B8284:
    c.r[0] = c.r[9];  // 060B8284 mov r9,r0
L_060B8286:
    c.r[0] += c.r[12];  // 060B8286 add r12,r0
L_060B8288:
    c.t = c.r[0] > c.r[14];  // 060B8288 cmp/hi r14,r0
L_060B828A:
    { const bool k = c.t; c.r[1] = c.r[8] << 16 | c.r[8] >> 16; if (k) { SH2_POLL(c); goto L_060B8246; } }  // 060B828A bt/s 0x060B8246 ; swap.w r8,r1
L_060B828E:
    c.r[8] += c.r[2];  // 060B828E add r2,r8
L_060B8290:
    c.r[0] = c.r[8];  // 060B8290 mov r8,r0
L_060B8292:
    c.r[0] += c.r[10];  // 060B8292 add r10,r0
L_060B8294:
    c.t = c.r[0] > c.r[13];  // 060B8294 cmp/hi r13,r0
L_060B8296:
    { const bool k = c.t; c.r[5] = c.r[9]; if (k) { SH2_POLL(c); goto L_060B8246; } }  // 060B8296 bt/s 0x060B8246 ; mov r9,r5
L_060B829A:
    c.r[5] = c.r[1] << 16 | c.r[5] >> 16;  // 060B829A xtrct r1,r5
L_060B829C:
    c.r[9] += c.r[6];  // 060B829C add r6,r9
L_060B829E:
    c.r[0] = c.r[9];  // 060B829E mov r9,r0
L_060B82A0:
    c.r[0] += c.r[12];  // 060B82A0 add r12,r0
L_060B82A2:
    c.t = c.r[0] > c.r[14];  // 060B82A2 cmp/hi r14,r0
L_060B82A4:
    { const bool k = c.t; c.r[0] = c.r[8] << 16 | c.r[8] >> 16; if (k) { SH2_POLL(c); goto L_060B8246; } }  // 060B82A4 bt/s 0x060B8246 ; swap.w r8,r0
L_060B82A8:
    c.r[1] = c.r[9];  // 060B82A8 mov r9,r1
L_060B82AA:
    c.r[1] = c.r[0] << 16 | c.r[1] >> 16;  // 060B82AA xtrct r0,r1
L_060B82AC:
    c.r[8] -= c.r[7];  // 060B82AC sub r7,r8
L_060B82AE:
    c.r[0] = c.r[8];  // 060B82AE mov r8,r0
L_060B82B0:
    c.r[0] += c.r[10];  // 060B82B0 add r10,r0
L_060B82B2:
    c.t = c.r[0] > c.r[13];  // 060B82B2 cmp/hi r13,r0
L_060B82B4:
    { const bool k = c.t; c.r[9] += c.r[3]; if (k) { SH2_POLL(c); goto L_060B8246; } }  // 060B82B4 bt/s 0x060B8246 ; add r3,r9
L_060B82B8:
    c.r[0] = c.r[9];  // 060B82B8 mov r9,r0
L_060B82BA:
    c.r[0] += c.r[12];  // 060B82BA add r12,r0
L_060B82BC:
    c.t = c.r[0] > c.r[14];  // 060B82BC cmp/hi r14,r0
L_060B82BE:
    { const bool k = c.t; c.r[3] = c.r[8] << 16 | c.r[8] >> 16; if (k) { SH2_POLL(c); goto L_060B8246; } }  // 060B82BE bt/s 0x060B8246 ; swap.w r8,r3
L_060B82C2:
    c.r[8] -= c.r[2];  // 060B82C2 sub r2,r8
L_060B82C4:
    c.r[10] += c.r[8];  // 060B82C4 add r8,r10
L_060B82C6:
    c.t = c.r[10] > c.r[13];  // 060B82C6 cmp/hi r13,r10
L_060B82C8:
    { const bool k = c.t; c.r[7] = c.r[9]; if (k) { SH2_POLL(c); goto L_060B8246; } }  // 060B82C8 bt/s 0x060B8246 ; mov r9,r7
L_060B82CC:
    c.r[9] -= c.r[6];  // 060B82CC sub r6,r9
L_060B82CE:
    c.r[12] += c.r[9];  // 060B82CE add r9,r12
L_060B82D0:
    c.t = c.r[12] > c.r[14];  // 060B82D0 cmp/hi r14,r12
L_060B82D2:
    { const bool k = c.t; c.r[7] = c.r[3] << 16 | c.r[7] >> 16; if (k) { SH2_POLL(c); goto L_060B8246; } }  // 060B82D2 bt/s 0x060B8246 ; xtrct r3,r7
L_060B82D6:
    c.r[8] = c.r[8] << 16 | c.r[8] >> 16;  // 060B82D6 swap.w r8,r8
L_060B82D8:
    c.r[0] = c.r[11];  // 060B82D8 mov r11,r0
L_060B82DA:
    c.r[0] += 36;  // 060B82DA add #36,r0
L_060B82DC:
    st32(c.gbr + 52, c.r[0]);  // 060B82DC mov.l r0,@(52,gbr)
L_060B82DE:
    c.r[0] = ld32(c.gbr + 148);  // 060B82DE mov.l @(148,gbr),r0
L_060B82E0:
    c.r[3] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B82E0 exts.w r0,r3
L_060B82E2:
    c.r[2] = c.r[0] << 16 | c.r[0] >> 16;  // 060B82E2 swap.w r0,r2
L_060B82E4:
    c.r[0] = ld32(c.gbr + 816);  // 060B82E4 mov.l @(816,gbr),r0
L_060B82E6:
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 060B82E6 exts.w r2,r2
L_060B82E8:
    c.r[13] = c.r[0] & 0xFFFFu;  // 060B82E8 extu.w r0,r13
L_060B82EA:
    c.r[12] = c.r[0] << 16 | c.r[0] >> 16;  // 060B82EA swap.w r0,r12
L_060B82EC:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B82EC extu.w r12,r12
L_060B82EE:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[5];  // 060B82EE exts.w r5,r0
L_060B82F0:
    c.r[0] += c.r[3];  // 060B82F0 add r3,r0
L_060B82F2:
    c.t = c.r[0] >= c.r[13];  // 060B82F2 cmp/hs r13,r0
L_060B82F4:
    { const bool k = c.t; c.r[9] = c.r[8] << 16 | c.r[9] >> 16; if (k) { goto L_060B8302; } }  // 060B82F4 bt/s 0x060B8302 ; xtrct r8,r9
L_060B82F8:
    c.r[0] = c.r[5] << 16 | c.r[5] >> 16;  // 060B82F8 swap.w r5,r0
L_060B82FA:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B82FA exts.w r0,r0
L_060B82FC:
    c.r[0] += c.r[2];  // 060B82FC add r2,r0
L_060B82FE:
    c.t = c.r[12] > c.r[0];  // 060B82FE cmp/hi r0,r12
L_060B8300:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[1]; if (k) { goto L_060B83AE; } }  // 060B8300 bt/s 0x060B83AE ; exts.w r1,r0
    goto L_060B8304;
L_060B8302:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 060B8302 exts.w r1,r0
L_060B8304:
    c.r[0] += c.r[3];  // 060B8304 add r3,r0
L_060B8306:
    c.t = c.r[0] >= c.r[13];  // 060B8306 cmp/hs r13,r0
L_060B8308:
    { const bool k = c.t; c.r[0] = c.r[1] << 16 | c.r[1] >> 16; if (k) { goto L_060B8314; } }  // 060B8308 bt/s 0x060B8314 ; swap.w r1,r0
L_060B830C:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B830C exts.w r0,r0
L_060B830E:
    c.r[0] += c.r[2];  // 060B830E add r2,r0
L_060B8310:
    c.t = c.r[12] > c.r[0];  // 060B8310 cmp/hi r0,r12
L_060B8312:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[7]; if (k) { goto L_060B83B8; } }  // 060B8312 bt/s 0x060B83B8 ; exts.w r7,r0
    goto L_060B8316;
L_060B8314:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[7];  // 060B8314 exts.w r7,r0
L_060B8316:
    c.r[0] += c.r[3];  // 060B8316 add r3,r0
L_060B8318:
    c.t = c.r[0] >= c.r[13];  // 060B8318 cmp/hs r13,r0
L_060B831A:
    { const bool k = c.t; c.r[0] = c.r[7] << 16 | c.r[7] >> 16; if (k) { goto L_060B8326; } }  // 060B831A bt/s 0x060B8326 ; swap.w r7,r0
L_060B831E:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B831E exts.w r0,r0
L_060B8320:
    c.r[0] += c.r[2];  // 060B8320 add r2,r0
L_060B8322:
    c.t = c.r[12] > c.r[0];  // 060B8322 cmp/hi r0,r12
L_060B8324:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[9]; if (k) { goto L_060B83C8; } }  // 060B8324 bt/s 0x060B83C8 ; exts.w r9,r0
    goto L_060B8328;
L_060B8326:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[9];  // 060B8326 exts.w r9,r0
L_060B8328:
    c.r[0] += c.r[3];  // 060B8328 add r3,r0
L_060B832A:
    c.t = c.r[0] >= c.r[13];  // 060B832A cmp/hs r13,r0
L_060B832C:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[8]; if (k) { goto L_060B8336; } }  // 060B832C bt/s 0x060B8336 ; exts.w r8,r0
L_060B8330:
    c.r[0] += c.r[2];  // 060B8330 add r2,r0
L_060B8332:
    c.t = c.r[12] > c.r[0];  // 060B8332 cmp/hi r0,r12
L_060B8334:
    { const bool k = c.t; c.r[8] = 0x1u; if (k) { goto L_060B83D8; } }  // 060B8334 bt/s 0x060B83D8 ; mov #1,r8
    goto L_060B8338;
L_060B8336:
    c.r[8] = 0x1u;  // 060B8336 mov #1,r8
L_060B8338:
    c.r[8] <<= 16;  // 060B8338 shll16 r8
L_060B833A:
    c.t = c.r[8] & 1; c.r[8] >>= 1;  // 060B833A shlr r8
L_060B833C:
    c.r[2] = c.r[9] << 16 | c.r[9] >> 16;  // 060B833C swap.w r9,r2
L_060B833E:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B833E tst r8,r2
L_060B8340:
    { uint32_t a = c.r[13], b = c.r[13], t = c.t; c.r[13] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B8340 subc r13,r13
L_060B8342:
    c.r[13] = ~c.r[13];  // 060B8342 not r13,r13
L_060B8344:
    c.r[13] ^= c.r[2];  // 060B8344 xor r2,r13
L_060B8346:
    c.t = (c.r[9] & c.r[8]) == 0;  // 060B8346 tst r8,r9
L_060B8348:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B8348 subc r2,r2
L_060B834A:
    c.r[2] = ~c.r[2];  // 060B834A not r2,r2
L_060B834C:
    c.r[2] ^= c.r[9];  // 060B834C xor r9,r2
L_060B834E:
    c.r[13] += c.r[2];  // 060B834E add r2,r13
L_060B8350:
    c.r[13] = c.r[13] & 0xFFFFu;  // 060B8350 extu.w r13,r13
L_060B8352:
    c.r[0] = 0x060B83D8u;  // 060B8352 mova 0x060B83D8,r0
L_060B8354:
    c.r[2] = c.r[7] << 16 | c.r[7] >> 16;  // 060B8354 swap.w r7,r2
L_060B8356:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B8356 tst r8,r2
L_060B8358:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B8358 subc r12,r12
L_060B835A:
    c.r[12] = ~c.r[12];  // 060B835A not r12,r12
L_060B835C:
    c.r[12] ^= c.r[2];  // 060B835C xor r2,r12
L_060B835E:
    c.t = (c.r[7] & c.r[8]) == 0;  // 060B835E tst r8,r7
L_060B8360:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B8360 subc r2,r2
L_060B8362:
    c.r[2] = ~c.r[2];  // 060B8362 not r2,r2
L_060B8364:
    c.r[2] ^= c.r[7];  // 060B8364 xor r7,r2
L_060B8366:
    c.r[12] += c.r[2];  // 060B8366 add r2,r12
L_060B8368:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B8368 extu.w r12,r12
L_060B836A:
    c.t = (int32_t)c.r[12] > (int32_t)c.r[13];  // 060B836A cmp/gt r13,r12
L_060B836C:
    { const bool k = c.t; c.r[2] = c.r[1] << 16 | c.r[1] >> 16; if (k) { goto L_060B8374; } }  // 060B836C bt/s 0x060B8374 ; swap.w r1,r2
L_060B8370:
    c.r[13] = c.r[12];  // 060B8370 mov r12,r13
L_060B8372:
    c.r[0] = 0x060B83C8u;  // 060B8372 mova 0x060B83C8,r0
L_060B8374:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B8374 tst r8,r2
L_060B8376:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B8376 subc r12,r12
L_060B8378:
    c.r[12] = ~c.r[12];  // 060B8378 not r12,r12
L_060B837A:
    c.r[12] ^= c.r[2];  // 060B837A xor r2,r12
L_060B837C:
    c.t = (c.r[1] & c.r[8]) == 0;  // 060B837C tst r8,r1
L_060B837E:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B837E subc r2,r2
L_060B8380:
    c.r[2] = ~c.r[2];  // 060B8380 not r2,r2
L_060B8382:
    c.r[2] ^= c.r[1];  // 060B8382 xor r1,r2
L_060B8384:
    c.r[12] += c.r[2];  // 060B8384 add r2,r12
L_060B8386:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B8386 extu.w r12,r12
L_060B8388:
    c.t = (int32_t)c.r[12] > (int32_t)c.r[13];  // 060B8388 cmp/gt r13,r12
L_060B838A:
    { const bool k = c.t; c.r[2] = c.r[5] << 16 | c.r[5] >> 16; if (k) { goto L_060B8392; } }  // 060B838A bt/s 0x060B8392 ; swap.w r5,r2
L_060B838E:
    c.r[13] = c.r[12];  // 060B838E mov r12,r13
L_060B8390:
    c.r[0] = 0x060B83C8u;  // 060B8390 mova 0x060B83C8,r0
L_060B8392:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B8392 tst r8,r2
L_060B8394:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B8394 subc r12,r12
L_060B8396:
    c.r[12] = ~c.r[12];  // 060B8396 not r12,r12
L_060B8398:
    c.r[12] ^= c.r[2];  // 060B8398 xor r2,r12
L_060B839A:
    c.t = (c.r[5] & c.r[8]) == 0;  // 060B839A tst r8,r5
L_060B839C:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B839C subc r2,r2
L_060B839E:
    c.r[2] = ~c.r[2];  // 060B839E not r2,r2
L_060B83A0:
    c.r[2] ^= c.r[5];  // 060B83A0 xor r5,r2
L_060B83A2:
    c.r[12] += c.r[2];  // 060B83A2 add r2,r12
L_060B83A4:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B83A4 extu.w r12,r12
L_060B83A6:
    c.t = (int32_t)c.r[13] >= (int32_t)c.r[12];  // 060B83A6 cmp/ge r12,r13
L_060B83A8:
    if (c.t) { goto L_060B83AE; }  // 060B83A8 bt 0x060B83AE
L_060B83AA:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x060B803Cu: goto L_060B803C; case 0x060B803Eu: goto L_060B803E; case 0x060B8042u: goto L_060B8042; case 0x060B8044u: goto L_060B8044; case 0x060B8046u: goto L_060B8046; case 0x060B8048u: goto L_060B8048; case 0x060B804Au: goto L_060B804A; case 0x060B804Cu: goto L_060B804C; case 0x060B804Eu: goto L_060B804E; case 0x060B8050u: goto L_060B8050; case 0x060B8052u: goto L_060B8052; case 0x060B8054u: goto L_060B8054; case 0x060B8056u: goto L_060B8056; case 0x060B8058u: goto L_060B8058; case 0x060B805Au: goto L_060B805A; case 0x060B805Cu: goto L_060B805C; case 0x060B805Eu: goto L_060B805E; case 0x060B8060u: goto L_060B8060; case 0x060B8062u: goto L_060B8062; case 0x060B8064u: goto L_060B8064; case 0x060B8066u: goto L_060B8066; case 0x060B8068u: goto L_060B8068; case 0x060B806Au: goto L_060B806A; case 0x060B806Cu: goto L_060B806C; case 0x060B806Eu: goto L_060B806E; case 0x060B8070u: goto L_060B8070; case 0x060B8072u: goto L_060B8072; case 0x060B8074u: goto L_060B8074; case 0x060B8076u: goto L_060B8076; case 0x060B8078u: goto L_060B8078; case 0x060B807Au: goto L_060B807A; case 0x060B807Cu: goto L_060B807C; case 0x060B807Eu: goto L_060B807E; case 0x060B8080u: goto L_060B8080; case 0x060B8082u: goto L_060B8082; case 0x060B8084u: goto L_060B8084; case 0x060B8086u: goto L_060B8086; case 0x060B8088u: goto L_060B8088; case 0x060B808Au: goto L_060B808A; case 0x060B80D0u: goto L_060B80D0; case 0x060B80D2u: goto L_060B80D2; case 0x060B80D4u: goto L_060B80D4; case 0x060B80D6u: goto L_060B80D6; case 0x060B80D8u: goto L_060B80D8; case 0x060B80DAu: goto L_060B80DA; case 0x060B80DCu: goto L_060B80DC; case 0x060B80DEu: goto L_060B80DE; case 0x060B80E0u: goto L_060B80E0; case 0x060B80E2u: goto L_060B80E2; case 0x060B80E4u: goto L_060B80E4; case 0x060B80E6u: goto L_060B80E6; case 0x060B80EAu: goto L_060B80EA; case 0x060B80ECu: goto L_060B80EC; case 0x060B80EEu: goto L_060B80EE; case 0x060B80F0u: goto L_060B80F0; case 0x060B80F2u: goto L_060B80F2; case 0x060B80F4u: goto L_060B80F4; case 0x060B80F6u: goto L_060B80F6; case 0x060B80FAu: goto L_060B80FA; case 0x060B80FCu: goto L_060B80FC; case 0x060B80FEu: goto L_060B80FE; case 0x060B8100u: goto L_060B8100; case 0x060B8102u: goto L_060B8102; case 0x060B8106u: goto L_060B8106; case 0x060B8108u: goto L_060B8108; case 0x060B810Au: goto L_060B810A; case 0x060B810Cu: goto L_060B810C; case 0x060B810Eu: goto L_060B810E; case 0x060B8112u: goto L_060B8112; case 0x060B8114u: goto L_060B8114; case 0x060B8116u: goto L_060B8116; case 0x060B8118u: goto L_060B8118; case 0x060B811Au: goto L_060B811A; case 0x060B811Cu: goto L_060B811C; case 0x060B811Eu: goto L_060B811E; case 0x060B8120u: goto L_060B8120; case 0x060B8124u: goto L_060B8124; case 0x060B8126u: goto L_060B8126; case 0x060B8128u: goto L_060B8128; case 0x060B812Au: goto L_060B812A; case 0x060B812Eu: goto L_060B812E; case 0x060B8130u: goto L_060B8130; case 0x060B8132u: goto L_060B8132; case 0x060B8134u: goto L_060B8134; case 0x060B8138u: goto L_060B8138; case 0x060B813Au: goto L_060B813A; case 0x060B813Cu: goto L_060B813C; case 0x060B813Eu: goto L_060B813E; case 0x060B8142u: goto L_060B8142; case 0x060B8146u: goto L_060B8146; case 0x060B8148u: goto L_060B8148; case 0x060B814Au: goto L_060B814A; case 0x060B814Cu: goto L_060B814C; case 0x060B814Eu: goto L_060B814E; case 0x060B8150u: goto L_060B8150; case 0x060B8152u: goto L_060B8152; case 0x060B8156u: goto L_060B8156; case 0x060B8158u: goto L_060B8158; case 0x060B815Au: goto L_060B815A; case 0x060B815Eu: goto L_060B815E; case 0x060B8160u: goto L_060B8160; case 0x060B8162u: goto L_060B8162; case 0x060B8166u: goto L_060B8166; case 0x060B8168u: goto L_060B8168; case 0x060B816Au: goto L_060B816A; case 0x060B816Cu: goto L_060B816C; case 0x060B816Eu: goto L_060B816E; case 0x060B8170u: goto L_060B8170; case 0x060B8172u: goto L_060B8172; case 0x060B8174u: goto L_060B8174; case 0x060B8176u: goto L_060B8176; case 0x060B817Au: goto L_060B817A; case 0x060B817Cu: goto L_060B817C; case 0x060B817Eu: goto L_060B817E; case 0x060B8180u: goto L_060B8180; case 0x060B8184u: goto L_060B8184; case 0x060B8186u: goto L_060B8186; case 0x060B8188u: goto L_060B8188; case 0x060B818Au: goto L_060B818A; case 0x060B818Cu: goto L_060B818C; case 0x060B818Eu: goto L_060B818E; case 0x060B8190u: goto L_060B8190; case 0x060B8194u: goto L_060B8194; case 0x060B8196u: goto L_060B8196; case 0x060B8198u: goto L_060B8198; case 0x060B819Au: goto L_060B819A; case 0x060B819Eu: goto L_060B819E; case 0x060B81A0u: goto L_060B81A0; case 0x060B81A2u: goto L_060B81A2; case 0x060B81A4u: goto L_060B81A4; case 0x060B81A6u: goto L_060B81A6; case 0x060B81A8u: goto L_060B81A8; case 0x060B81AAu: goto L_060B81AA; case 0x060B81AEu: goto L_060B81AE; case 0x060B81B0u: goto L_060B81B0; case 0x060B81B2u: goto L_060B81B2; case 0x060B81B4u: goto L_060B81B4; case 0x060B81B8u: goto L_060B81B8; case 0x060B81BAu: goto L_060B81BA; case 0x060B81BCu: goto L_060B81BC; case 0x060B81BEu: goto L_060B81BE; case 0x060B81C2u: goto L_060B81C2; case 0x060B81C4u: goto L_060B81C4; case 0x060B81C6u: goto L_060B81C6; case 0x060B81C8u: goto L_060B81C8; case 0x060B81CCu: goto L_060B81CC; case 0x060B81D0u: goto L_060B81D0; case 0x060B81D2u: goto L_060B81D2; case 0x060B81D4u: goto L_060B81D4; case 0x060B81D6u: goto L_060B81D6; case 0x060B81D8u: goto L_060B81D8; case 0x060B81DAu: goto L_060B81DA; case 0x060B81DCu: goto L_060B81DC; case 0x060B81DEu: goto L_060B81DE; case 0x060B81E0u: goto L_060B81E0; case 0x060B81E2u: goto L_060B81E2; case 0x060B81E4u: goto L_060B81E4; case 0x060B81E6u: goto L_060B81E6; case 0x060B81EAu: goto L_060B81EA; case 0x060B81ECu: goto L_060B81EC; case 0x060B81EEu: goto L_060B81EE; case 0x060B81F0u: goto L_060B81F0; case 0x060B81F2u: goto L_060B81F2; case 0x060B81F4u: goto L_060B81F4; case 0x060B81F6u: goto L_060B81F6; case 0x060B81FAu: goto L_060B81FA; case 0x060B81FCu: goto L_060B81FC; case 0x060B81FEu: goto L_060B81FE; case 0x060B8200u: goto L_060B8200; case 0x060B8202u: goto L_060B8202; case 0x060B8206u: goto L_060B8206; case 0x060B8208u: goto L_060B8208; case 0x060B820Au: goto L_060B820A; case 0x060B820Cu: goto L_060B820C; case 0x060B820Eu: goto L_060B820E; case 0x060B8212u: goto L_060B8212; case 0x060B8214u: goto L_060B8214; case 0x060B8216u: goto L_060B8216; case 0x060B8218u: goto L_060B8218; case 0x060B821Au: goto L_060B821A; case 0x060B821Cu: goto L_060B821C; case 0x060B821Eu: goto L_060B821E; case 0x060B8220u: goto L_060B8220; case 0x060B8224u: goto L_060B8224; case 0x060B8226u: goto L_060B8226; case 0x060B8228u: goto L_060B8228; case 0x060B822Au: goto L_060B822A; case 0x060B822Eu: goto L_060B822E; case 0x060B8230u: goto L_060B8230; case 0x060B8232u: goto L_060B8232; case 0x060B8234u: goto L_060B8234; case 0x060B8238u: goto L_060B8238; case 0x060B823Au: goto L_060B823A; case 0x060B823Cu: goto L_060B823C; case 0x060B823Eu: goto L_060B823E; case 0x060B8242u: goto L_060B8242; case 0x060B8246u: goto L_060B8246; case 0x060B8248u: goto L_060B8248; case 0x060B824Au: goto L_060B824A; case 0x060B824Cu: goto L_060B824C; case 0x060B824Eu: goto L_060B824E; case 0x060B8250u: goto L_060B8250; case 0x060B8252u: goto L_060B8252; case 0x060B8256u: goto L_060B8256; case 0x060B8258u: goto L_060B8258; case 0x060B825Au: goto L_060B825A; case 0x060B825Cu: goto L_060B825C; case 0x060B825Eu: goto L_060B825E; case 0x060B8260u: goto L_060B8260; case 0x060B8262u: goto L_060B8262; case 0x060B8264u: goto L_060B8264; case 0x060B8266u: goto L_060B8266; case 0x060B8268u: goto L_060B8268; case 0x060B826Au: goto L_060B826A; case 0x060B826Cu: goto L_060B826C; case 0x060B826Eu: goto L_060B826E; case 0x060B8270u: goto L_060B8270; case 0x060B8272u: goto L_060B8272; case 0x060B8274u: goto L_060B8274; case 0x060B8278u: goto L_060B8278; case 0x060B827Au: goto L_060B827A; case 0x060B827Cu: goto L_060B827C; case 0x060B827Eu: goto L_060B827E; case 0x060B8280u: goto L_060B8280; case 0x060B8282u: goto L_060B8282; case 0x060B8284u: goto L_060B8284; case 0x060B8286u: goto L_060B8286; case 0x060B8288u: goto L_060B8288; case 0x060B828Au: goto L_060B828A; case 0x060B828Eu: goto L_060B828E; case 0x060B8290u: goto L_060B8290; case 0x060B8292u: goto L_060B8292; case 0x060B8294u: goto L_060B8294; case 0x060B8296u: goto L_060B8296; case 0x060B829Au: goto L_060B829A; case 0x060B829Cu: goto L_060B829C; case 0x060B829Eu: goto L_060B829E; case 0x060B82A0u: goto L_060B82A0; case 0x060B82A2u: goto L_060B82A2; case 0x060B82A4u: goto L_060B82A4; case 0x060B82A8u: goto L_060B82A8; case 0x060B82AAu: goto L_060B82AA; case 0x060B82ACu: goto L_060B82AC; case 0x060B82AEu: goto L_060B82AE; case 0x060B82B0u: goto L_060B82B0; case 0x060B82B2u: goto L_060B82B2; case 0x060B82B4u: goto L_060B82B4; case 0x060B82B8u: goto L_060B82B8; case 0x060B82BAu: goto L_060B82BA; case 0x060B82BCu: goto L_060B82BC; case 0x060B82BEu: goto L_060B82BE; case 0x060B82C2u: goto L_060B82C2; case 0x060B82C4u: goto L_060B82C4; case 0x060B82C6u: goto L_060B82C6; case 0x060B82C8u: goto L_060B82C8; case 0x060B82CCu: goto L_060B82CC; case 0x060B82CEu: goto L_060B82CE; case 0x060B82D0u: goto L_060B82D0; case 0x060B82D2u: goto L_060B82D2; case 0x060B82D6u: goto L_060B82D6; case 0x060B82D8u: goto L_060B82D8; case 0x060B82DAu: goto L_060B82DA; case 0x060B82DCu: goto L_060B82DC; case 0x060B82DEu: goto L_060B82DE; case 0x060B82E0u: goto L_060B82E0; case 0x060B82E2u: goto L_060B82E2; case 0x060B82E4u: goto L_060B82E4; case 0x060B82E6u: goto L_060B82E6; case 0x060B82E8u: goto L_060B82E8; case 0x060B82EAu: goto L_060B82EA; case 0x060B82ECu: goto L_060B82EC; case 0x060B82EEu: goto L_060B82EE; case 0x060B82F0u: goto L_060B82F0; case 0x060B82F2u: goto L_060B82F2; case 0x060B82F4u: goto L_060B82F4; case 0x060B82F8u: goto L_060B82F8; case 0x060B82FAu: goto L_060B82FA; case 0x060B82FCu: goto L_060B82FC; case 0x060B82FEu: goto L_060B82FE; case 0x060B8300u: goto L_060B8300; case 0x060B8304u: goto L_060B8304; case 0x060B8306u: goto L_060B8306; case 0x060B8308u: goto L_060B8308; case 0x060B830Cu: goto L_060B830C; case 0x060B830Eu: goto L_060B830E; case 0x060B8310u: goto L_060B8310; case 0x060B8312u: goto L_060B8312; case 0x060B8316u: goto L_060B8316; case 0x060B8318u: goto L_060B8318; case 0x060B831Au: goto L_060B831A; case 0x060B831Eu: goto L_060B831E; case 0x060B8320u: goto L_060B8320; case 0x060B8322u: goto L_060B8322; case 0x060B8324u: goto L_060B8324; case 0x060B8328u: goto L_060B8328; case 0x060B832Au: goto L_060B832A; case 0x060B832Cu: goto L_060B832C; case 0x060B8330u: goto L_060B8330; case 0x060B8332u: goto L_060B8332; case 0x060B8334u: goto L_060B8334; case 0x060B8338u: goto L_060B8338; case 0x060B833Au: goto L_060B833A; case 0x060B833Cu: goto L_060B833C; case 0x060B833Eu: goto L_060B833E; case 0x060B8340u: goto L_060B8340; case 0x060B8342u: goto L_060B8342; case 0x060B8344u: goto L_060B8344; case 0x060B8346u: goto L_060B8346; case 0x060B8348u: goto L_060B8348; case 0x060B834Au: goto L_060B834A; case 0x060B834Cu: goto L_060B834C; case 0x060B834Eu: goto L_060B834E; case 0x060B8350u: goto L_060B8350; case 0x060B8352u: goto L_060B8352; case 0x060B8354u: goto L_060B8354; case 0x060B8356u: goto L_060B8356; case 0x060B8358u: goto L_060B8358; case 0x060B835Au: goto L_060B835A; case 0x060B835Cu: goto L_060B835C; case 0x060B835Eu: goto L_060B835E; case 0x060B8360u: goto L_060B8360; case 0x060B8362u: goto L_060B8362; case 0x060B8364u: goto L_060B8364; case 0x060B8366u: goto L_060B8366; case 0x060B8368u: goto L_060B8368; case 0x060B836Au: goto L_060B836A; case 0x060B836Cu: goto L_060B836C; case 0x060B8370u: goto L_060B8370; case 0x060B8372u: goto L_060B8372; case 0x060B8374u: goto L_060B8374; case 0x060B8376u: goto L_060B8376; case 0x060B8378u: goto L_060B8378; case 0x060B837Au: goto L_060B837A; case 0x060B837Cu: goto L_060B837C; case 0x060B837Eu: goto L_060B837E; case 0x060B8380u: goto L_060B8380; case 0x060B8382u: goto L_060B8382; case 0x060B8384u: goto L_060B8384; case 0x060B8386u: goto L_060B8386; case 0x060B8388u: goto L_060B8388; case 0x060B838Au: goto L_060B838A; case 0x060B838Eu: goto L_060B838E; case 0x060B8390u: goto L_060B8390; case 0x060B8392u: goto L_060B8392; case 0x060B8394u: goto L_060B8394; case 0x060B8396u: goto L_060B8396; case 0x060B8398u: goto L_060B8398; case 0x060B839Au: goto L_060B839A; case 0x060B839Cu: goto L_060B839C; case 0x060B839Eu: goto L_060B839E; case 0x060B83A0u: goto L_060B83A0; case 0x060B83A2u: goto L_060B83A2; case 0x060B83A4u: goto L_060B83A4; case 0x060B83A6u: goto L_060B83A6; case 0x060B83A8u: goto L_060B83A8; case 0x060B83AAu: goto L_060B83AA; case 0x060B83AEu: goto L_060B83AE; case 0x060B83B0u: goto L_060B83B0; case 0x060B83B2u: goto L_060B83B2; case 0x060B83B4u: goto L_060B83B4; case 0x060B83B8u: goto L_060B83B8; case 0x060B83BAu: goto L_060B83BA; case 0x060B83BCu: goto L_060B83BC; case 0x060B83BEu: goto L_060B83BE; case 0x060B83C0u: goto L_060B83C0; case 0x060B83C2u: goto L_060B83C2; case 0x060B83C4u: goto L_060B83C4; case 0x060B83C8u: goto L_060B83C8; case 0x060B83CAu: goto L_060B83CA; case 0x060B83CCu: goto L_060B83CC; case 0x060B83CEu: goto L_060B83CE; case 0x060B83D0u: goto L_060B83D0; case 0x060B83D2u: goto L_060B83D2; case 0x060B83D4u: goto L_060B83D4; case 0x060B83D8u: goto L_060B83D8; case 0x060B83DAu: goto L_060B83DA; case 0x060B83DCu: goto L_060B83DC; case 0x060B83DEu: goto L_060B83DE; case 0x060B83E0u: goto L_060B83E0; case 0x060B83E2u: goto L_060B83E2; case 0x060B83E4u: goto L_060B83E4; default: sh2_call(c, x); return; } }  // 060B83AA jmp @r0 ; nop
L_060B83AE:
    st32(c.r[11] + 12, c.r[5]);  // 060B83AE mov.l r5,@(12,r11)
L_060B83B0:
    st32(c.r[11] + 16, c.r[1]);  // 060B83B0 mov.l r1,@(16,r11)
L_060B83B2:
    st32(c.r[11] + 20, c.r[7]);  // 060B83B2 mov.l r7,@(20,r11)
L_060B83B4:
    { const uint32_t x = c.pr; st32(c.r[11] + 24, c.r[9]); c.pc = x; return; }  // 060B83B4 rts ; mov.l r9,@(24,r11)
L_060B83B8:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[11]);  // 060B83B8 mov.w @(0,r11),r0
L_060B83BA:
    st32(c.r[11] + 16, c.r[5]);  // 060B83BA mov.l r5,@(16,r11)
L_060B83BC:
    c.r[0] ^= 0x10u;  // 060B83BC xor #16,r0
L_060B83BE:
    st16(c.r[11], c.r[0]);  // 060B83BE mov.w r0,@(0,r11)
L_060B83C0:
    st32(c.r[11] + 12, c.r[1]);  // 060B83C0 mov.l r1,@(12,r11)
L_060B83C2:
    st32(c.r[11] + 24, c.r[7]);  // 060B83C2 mov.l r7,@(24,r11)
L_060B83C4:
    { const uint32_t x = c.pr; st32(c.r[11] + 20, c.r[9]); c.pc = x; return; }  // 060B83C4 rts ; mov.l r9,@(20,r11)
L_060B83C8:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[11]);  // 060B83C8 mov.w @(0,r11),r0
L_060B83CA:
    st32(c.r[11] + 20, c.r[5]);  // 060B83CA mov.l r5,@(20,r11)
L_060B83CC:
    c.r[0] ^= 0x30u;  // 060B83CC xor #48,r0
L_060B83CE:
    st16(c.r[11], c.r[0]);  // 060B83CE mov.w r0,@(0,r11)
L_060B83D0:
    st32(c.r[11] + 24, c.r[1]);  // 060B83D0 mov.l r1,@(24,r11)
L_060B83D2:
    st32(c.r[11] + 12, c.r[7]);  // 060B83D2 mov.l r7,@(12,r11)
L_060B83D4:
    { const uint32_t x = c.pr; st32(c.r[11] + 16, c.r[9]); c.pc = x; return; }  // 060B83D4 rts ; mov.l r9,@(16,r11)
L_060B83D8:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[11]);  // 060B83D8 mov.w @(0,r11),r0
L_060B83DA:
    st32(c.r[11] + 24, c.r[5]);  // 060B83DA mov.l r5,@(24,r11)
L_060B83DC:
    c.r[0] ^= 0x20u;  // 060B83DC xor #32,r0
L_060B83DE:
    st16(c.r[11], c.r[0]);  // 060B83DE mov.w r0,@(0,r11)
L_060B83E0:
    st32(c.r[11] + 20, c.r[1]);  // 060B83E0 mov.l r1,@(20,r11)
L_060B83E2:
    st32(c.r[11] + 16, c.r[7]);  // 060B83E2 mov.l r7,@(16,r11)
L_060B83E4:
    { const uint32_t x = c.pr; st32(c.r[11] + 12, c.r[9]); c.pc = x; return; }  // 060B83E4 rts ; mov.l r9,@(12,r11)
}

void f_060B80D0(SH2Context& c) {
    ran[3157] = 1;
L_060B80D0:
    c.r[1] = 0x20u;  // 060B80D0 mov #32,r1
L_060B80D2:
    c.r[5] ^= c.r[1];  // 060B80D2 xor r1,r5
L_060B80D4:
    st16(c.r[11], c.r[5]);  // 060B80D4 mov.w r5,@r11
L_060B80D6:
    c.r[3] = 0u - c.r[3];  // 060B80D6 neg r3,r3
L_060B80D8:
    c.r[7] = 0u - c.r[7];  // 060B80D8 neg r7,r7
L_060B80DA:
    c.r[0] = c.r[2];  // 060B80DA mov r2,r0
L_060B80DC:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B80DC shar r0
L_060B80DE:
    c.r[8] -= c.r[0];  // 060B80DE sub r0,r8
L_060B80E0:
    c.r[0] = c.r[8];  // 060B80E0 mov r8,r0
L_060B80E2:
    c.r[0] += c.r[10];  // 060B80E2 add r10,r0
L_060B80E4:
    c.t = c.r[0] > c.r[13];  // 060B80E4 cmp/hi r13,r0
L_060B80E6:
    { const bool k = c.t; c.r[4] += 32; if (k) { goto L_060B8146; } }  // 060B80E6 bt/s 0x060B8146 ; add #32,r4
L_060B80EA:
    c.r[0] = c.r[6];  // 060B80EA mov r6,r0
L_060B80EC:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B80EC shar r0
L_060B80EE:
    c.r[9] -= c.r[0];  // 060B80EE sub r0,r9
L_060B80F0:
    c.r[0] = c.r[9];  // 060B80F0 mov r9,r0
L_060B80F2:
    c.r[0] += c.r[12];  // 060B80F2 add r12,r0
L_060B80F4:
    c.t = c.r[0] > c.r[14];  // 060B80F4 cmp/hi r14,r0
L_060B80F6:
    { const bool k = c.t; c.r[1] = c.r[8] << 16 | c.r[8] >> 16; if (k) { goto L_060B8146; } }  // 060B80F6 bt/s 0x060B8146 ; swap.w r8,r1
L_060B80FA:
    c.r[8] += c.r[2];  // 060B80FA add r2,r8
L_060B80FC:
    c.r[0] = c.r[8];  // 060B80FC mov r8,r0
L_060B80FE:
    c.r[0] += c.r[10];  // 060B80FE add r10,r0
L_060B8100:
    c.t = c.r[0] > c.r[13];  // 060B8100 cmp/hi r13,r0
L_060B8102:
    { const bool k = c.t; c.r[5] = c.r[9]; if (k) { goto L_060B8146; } }  // 060B8102 bt/s 0x060B8146 ; mov r9,r5
L_060B8106:
    c.r[9] += c.r[6];  // 060B8106 add r6,r9
L_060B8108:
    c.r[0] = c.r[9];  // 060B8108 mov r9,r0
L_060B810A:
    c.r[0] += c.r[12];  // 060B810A add r12,r0
L_060B810C:
    c.t = c.r[0] > c.r[14];  // 060B810C cmp/hi r14,r0
L_060B810E:
    { const bool k = c.t; c.r[0] = c.r[8] << 16 | c.r[8] >> 16; if (k) { goto L_060B8146; } }  // 060B810E bt/s 0x060B8146 ; swap.w r8,r0
L_060B8112:
    c.r[5] = c.r[1] << 16 | c.r[5] >> 16;  // 060B8112 xtrct r1,r5
L_060B8114:
    c.r[1] = c.r[9];  // 060B8114 mov r9,r1
L_060B8116:
    c.r[1] = c.r[0] << 16 | c.r[1] >> 16;  // 060B8116 xtrct r0,r1
L_060B8118:
    c.r[8] -= c.r[7];  // 060B8118 sub r7,r8
L_060B811A:
    c.r[0] = c.r[8];  // 060B811A mov r8,r0
L_060B811C:
    c.r[0] += c.r[10];  // 060B811C add r10,r0
L_060B811E:
    c.t = c.r[0] > c.r[13];  // 060B811E cmp/hi r13,r0
L_060B8120:
    { const bool k = c.t; c.r[9] += c.r[3]; if (k) { goto L_060B8146; } }  // 060B8120 bt/s 0x060B8146 ; add r3,r9
L_060B8124:
    c.r[0] = c.r[9];  // 060B8124 mov r9,r0
L_060B8126:
    c.r[0] += c.r[12];  // 060B8126 add r12,r0
L_060B8128:
    c.t = c.r[0] > c.r[14];  // 060B8128 cmp/hi r14,r0
L_060B812A:
    { const bool k = c.t; c.r[3] = c.r[8] << 16 | c.r[8] >> 16; if (k) { goto L_060B8146; } }  // 060B812A bt/s 0x060B8146 ; swap.w r8,r3
L_060B812E:
    c.r[8] -= c.r[2];  // 060B812E sub r2,r8
L_060B8130:
    c.r[10] += c.r[8];  // 060B8130 add r8,r10
L_060B8132:
    c.t = c.r[10] > c.r[13];  // 060B8132 cmp/hi r13,r10
L_060B8134:
    { const bool k = c.t; c.r[7] = c.r[9]; if (k) { goto L_060B8146; } }  // 060B8134 bt/s 0x060B8146 ; mov r9,r7
L_060B8138:
    c.r[9] -= c.r[6];  // 060B8138 sub r6,r9
L_060B813A:
    c.r[12] += c.r[9];  // 060B813A add r9,r12
L_060B813C:
    c.t = c.r[12] > c.r[14];  // 060B813C cmp/hi r14,r12
L_060B813E:
    { const bool k = c.t; c.r[7] = c.r[3] << 16 | c.r[7] >> 16; if (k) { goto L_060B8146; } }  // 060B813E bt/s 0x060B8146 ; xtrct r3,r7
L_060B8142:
    c.r[8] = c.r[8] << 16 | c.r[8] >> 16; goto L_060B82D8;  // 060B8142 bra 0x060B82D8 ; swap.w r8,r8
L_060B8146:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[11] + 30);  // 060B8146 mov.w @(30,r11),r0
L_060B8148:
    c.r[1] = ld32(c.r[11] + 32);  // 060B8148 mov.l @(32,r11),r1
L_060B814A:
    c.r[2] = (c.r[0] & 0xFFFF0000u) | (c.r[0] & 0xFFu) << 8 | (c.r[0] >> 8 & 0xFFu);  // 060B814A swap.b r0,r2
L_060B814C:
    c.r[0] = ld32(c.gbr + 56);  // 060B814C mov.l @(56,gbr),r0
L_060B814E:
    c.r[2] = c.r[2] & 0xFFu;  // 060B814E extu.b r2,r2
L_060B8150:
    c.r[2] <<= 2;  // 060B8150 shll2 r2
L_060B8152:
    { const uint32_t x = c.pr; st32(c.r[0] + c.r[2], c.r[1]); c.pc = x; return; }  // 060B8152 rts ; mov.l r1,@(r0,r2)
L_060B82D8:
    c.r[0] = c.r[11];  // 060B82D8 mov r11,r0
L_060B82DA:
    c.r[0] += 36;  // 060B82DA add #36,r0
L_060B82DC:
    st32(c.gbr + 52, c.r[0]);  // 060B82DC mov.l r0,@(52,gbr)
L_060B82DE:
    c.r[0] = ld32(c.gbr + 148);  // 060B82DE mov.l @(148,gbr),r0
L_060B82E0:
    c.r[3] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B82E0 exts.w r0,r3
L_060B82E2:
    c.r[2] = c.r[0] << 16 | c.r[0] >> 16;  // 060B82E2 swap.w r0,r2
L_060B82E4:
    c.r[0] = ld32(c.gbr + 816);  // 060B82E4 mov.l @(816,gbr),r0
L_060B82E6:
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 060B82E6 exts.w r2,r2
L_060B82E8:
    c.r[13] = c.r[0] & 0xFFFFu;  // 060B82E8 extu.w r0,r13
L_060B82EA:
    c.r[12] = c.r[0] << 16 | c.r[0] >> 16;  // 060B82EA swap.w r0,r12
L_060B82EC:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B82EC extu.w r12,r12
L_060B82EE:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[5];  // 060B82EE exts.w r5,r0
L_060B82F0:
    c.r[0] += c.r[3];  // 060B82F0 add r3,r0
L_060B82F2:
    c.t = c.r[0] >= c.r[13];  // 060B82F2 cmp/hs r13,r0
L_060B82F4:
    { const bool k = c.t; c.r[9] = c.r[8] << 16 | c.r[9] >> 16; if (k) { goto L_060B8302; } }  // 060B82F4 bt/s 0x060B8302 ; xtrct r8,r9
L_060B82F8:
    c.r[0] = c.r[5] << 16 | c.r[5] >> 16;  // 060B82F8 swap.w r5,r0
L_060B82FA:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B82FA exts.w r0,r0
L_060B82FC:
    c.r[0] += c.r[2];  // 060B82FC add r2,r0
L_060B82FE:
    c.t = c.r[12] > c.r[0];  // 060B82FE cmp/hi r0,r12
L_060B8300:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[1]; if (k) { goto L_060B83AE; } }  // 060B8300 bt/s 0x060B83AE ; exts.w r1,r0
    goto L_060B8304;
L_060B8302:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 060B8302 exts.w r1,r0
L_060B8304:
    c.r[0] += c.r[3];  // 060B8304 add r3,r0
L_060B8306:
    c.t = c.r[0] >= c.r[13];  // 060B8306 cmp/hs r13,r0
L_060B8308:
    { const bool k = c.t; c.r[0] = c.r[1] << 16 | c.r[1] >> 16; if (k) { goto L_060B8314; } }  // 060B8308 bt/s 0x060B8314 ; swap.w r1,r0
L_060B830C:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B830C exts.w r0,r0
L_060B830E:
    c.r[0] += c.r[2];  // 060B830E add r2,r0
L_060B8310:
    c.t = c.r[12] > c.r[0];  // 060B8310 cmp/hi r0,r12
L_060B8312:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[7]; if (k) { goto L_060B83B8; } }  // 060B8312 bt/s 0x060B83B8 ; exts.w r7,r0
    goto L_060B8316;
L_060B8314:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[7];  // 060B8314 exts.w r7,r0
L_060B8316:
    c.r[0] += c.r[3];  // 060B8316 add r3,r0
L_060B8318:
    c.t = c.r[0] >= c.r[13];  // 060B8318 cmp/hs r13,r0
L_060B831A:
    { const bool k = c.t; c.r[0] = c.r[7] << 16 | c.r[7] >> 16; if (k) { goto L_060B8326; } }  // 060B831A bt/s 0x060B8326 ; swap.w r7,r0
L_060B831E:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B831E exts.w r0,r0
L_060B8320:
    c.r[0] += c.r[2];  // 060B8320 add r2,r0
L_060B8322:
    c.t = c.r[12] > c.r[0];  // 060B8322 cmp/hi r0,r12
L_060B8324:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[9]; if (k) { goto L_060B83C8; } }  // 060B8324 bt/s 0x060B83C8 ; exts.w r9,r0
    goto L_060B8328;
L_060B8326:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[9];  // 060B8326 exts.w r9,r0
L_060B8328:
    c.r[0] += c.r[3];  // 060B8328 add r3,r0
L_060B832A:
    c.t = c.r[0] >= c.r[13];  // 060B832A cmp/hs r13,r0
L_060B832C:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[8]; if (k) { goto L_060B8336; } }  // 060B832C bt/s 0x060B8336 ; exts.w r8,r0
L_060B8330:
    c.r[0] += c.r[2];  // 060B8330 add r2,r0
L_060B8332:
    c.t = c.r[12] > c.r[0];  // 060B8332 cmp/hi r0,r12
L_060B8334:
    { const bool k = c.t; c.r[8] = 0x1u; if (k) { goto L_060B83D8; } }  // 060B8334 bt/s 0x060B83D8 ; mov #1,r8
    goto L_060B8338;
L_060B8336:
    c.r[8] = 0x1u;  // 060B8336 mov #1,r8
L_060B8338:
    c.r[8] <<= 16;  // 060B8338 shll16 r8
L_060B833A:
    c.t = c.r[8] & 1; c.r[8] >>= 1;  // 060B833A shlr r8
L_060B833C:
    c.r[2] = c.r[9] << 16 | c.r[9] >> 16;  // 060B833C swap.w r9,r2
L_060B833E:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B833E tst r8,r2
L_060B8340:
    { uint32_t a = c.r[13], b = c.r[13], t = c.t; c.r[13] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B8340 subc r13,r13
L_060B8342:
    c.r[13] = ~c.r[13];  // 060B8342 not r13,r13
L_060B8344:
    c.r[13] ^= c.r[2];  // 060B8344 xor r2,r13
L_060B8346:
    c.t = (c.r[9] & c.r[8]) == 0;  // 060B8346 tst r8,r9
L_060B8348:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B8348 subc r2,r2
L_060B834A:
    c.r[2] = ~c.r[2];  // 060B834A not r2,r2
L_060B834C:
    c.r[2] ^= c.r[9];  // 060B834C xor r9,r2
L_060B834E:
    c.r[13] += c.r[2];  // 060B834E add r2,r13
L_060B8350:
    c.r[13] = c.r[13] & 0xFFFFu;  // 060B8350 extu.w r13,r13
L_060B8352:
    c.r[0] = 0x060B83D8u;  // 060B8352 mova 0x060B83D8,r0
L_060B8354:
    c.r[2] = c.r[7] << 16 | c.r[7] >> 16;  // 060B8354 swap.w r7,r2
L_060B8356:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B8356 tst r8,r2
L_060B8358:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B8358 subc r12,r12
L_060B835A:
    c.r[12] = ~c.r[12];  // 060B835A not r12,r12
L_060B835C:
    c.r[12] ^= c.r[2];  // 060B835C xor r2,r12
L_060B835E:
    c.t = (c.r[7] & c.r[8]) == 0;  // 060B835E tst r8,r7
L_060B8360:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B8360 subc r2,r2
L_060B8362:
    c.r[2] = ~c.r[2];  // 060B8362 not r2,r2
L_060B8364:
    c.r[2] ^= c.r[7];  // 060B8364 xor r7,r2
L_060B8366:
    c.r[12] += c.r[2];  // 060B8366 add r2,r12
L_060B8368:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B8368 extu.w r12,r12
L_060B836A:
    c.t = (int32_t)c.r[12] > (int32_t)c.r[13];  // 060B836A cmp/gt r13,r12
L_060B836C:
    { const bool k = c.t; c.r[2] = c.r[1] << 16 | c.r[1] >> 16; if (k) { goto L_060B8374; } }  // 060B836C bt/s 0x060B8374 ; swap.w r1,r2
L_060B8370:
    c.r[13] = c.r[12];  // 060B8370 mov r12,r13
L_060B8372:
    c.r[0] = 0x060B83C8u;  // 060B8372 mova 0x060B83C8,r0
L_060B8374:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B8374 tst r8,r2
L_060B8376:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B8376 subc r12,r12
L_060B8378:
    c.r[12] = ~c.r[12];  // 060B8378 not r12,r12
L_060B837A:
    c.r[12] ^= c.r[2];  // 060B837A xor r2,r12
L_060B837C:
    c.t = (c.r[1] & c.r[8]) == 0;  // 060B837C tst r8,r1
L_060B837E:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B837E subc r2,r2
L_060B8380:
    c.r[2] = ~c.r[2];  // 060B8380 not r2,r2
L_060B8382:
    c.r[2] ^= c.r[1];  // 060B8382 xor r1,r2
L_060B8384:
    c.r[12] += c.r[2];  // 060B8384 add r2,r12
L_060B8386:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B8386 extu.w r12,r12
L_060B8388:
    c.t = (int32_t)c.r[12] > (int32_t)c.r[13];  // 060B8388 cmp/gt r13,r12
L_060B838A:
    { const bool k = c.t; c.r[2] = c.r[5] << 16 | c.r[5] >> 16; if (k) { goto L_060B8392; } }  // 060B838A bt/s 0x060B8392 ; swap.w r5,r2
L_060B838E:
    c.r[13] = c.r[12];  // 060B838E mov r12,r13
L_060B8390:
    c.r[0] = 0x060B83C8u;  // 060B8390 mova 0x060B83C8,r0
L_060B8392:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B8392 tst r8,r2
L_060B8394:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B8394 subc r12,r12
L_060B8396:
    c.r[12] = ~c.r[12];  // 060B8396 not r12,r12
L_060B8398:
    c.r[12] ^= c.r[2];  // 060B8398 xor r2,r12
L_060B839A:
    c.t = (c.r[5] & c.r[8]) == 0;  // 060B839A tst r8,r5
L_060B839C:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B839C subc r2,r2
L_060B839E:
    c.r[2] = ~c.r[2];  // 060B839E not r2,r2
L_060B83A0:
    c.r[2] ^= c.r[5];  // 060B83A0 xor r5,r2
L_060B83A2:
    c.r[12] += c.r[2];  // 060B83A2 add r2,r12
L_060B83A4:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B83A4 extu.w r12,r12
L_060B83A6:
    c.t = (int32_t)c.r[13] >= (int32_t)c.r[12];  // 060B83A6 cmp/ge r12,r13
L_060B83A8:
    if (c.t) { goto L_060B83AE; }  // 060B83A8 bt 0x060B83AE
L_060B83AA:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x060B80D0u: goto L_060B80D0; case 0x060B80D2u: goto L_060B80D2; case 0x060B80D4u: goto L_060B80D4; case 0x060B80D6u: goto L_060B80D6; case 0x060B80D8u: goto L_060B80D8; case 0x060B80DAu: goto L_060B80DA; case 0x060B80DCu: goto L_060B80DC; case 0x060B80DEu: goto L_060B80DE; case 0x060B80E0u: goto L_060B80E0; case 0x060B80E2u: goto L_060B80E2; case 0x060B80E4u: goto L_060B80E4; case 0x060B80E6u: goto L_060B80E6; case 0x060B80EAu: goto L_060B80EA; case 0x060B80ECu: goto L_060B80EC; case 0x060B80EEu: goto L_060B80EE; case 0x060B80F0u: goto L_060B80F0; case 0x060B80F2u: goto L_060B80F2; case 0x060B80F4u: goto L_060B80F4; case 0x060B80F6u: goto L_060B80F6; case 0x060B80FAu: goto L_060B80FA; case 0x060B80FCu: goto L_060B80FC; case 0x060B80FEu: goto L_060B80FE; case 0x060B8100u: goto L_060B8100; case 0x060B8102u: goto L_060B8102; case 0x060B8106u: goto L_060B8106; case 0x060B8108u: goto L_060B8108; case 0x060B810Au: goto L_060B810A; case 0x060B810Cu: goto L_060B810C; case 0x060B810Eu: goto L_060B810E; case 0x060B8112u: goto L_060B8112; case 0x060B8114u: goto L_060B8114; case 0x060B8116u: goto L_060B8116; case 0x060B8118u: goto L_060B8118; case 0x060B811Au: goto L_060B811A; case 0x060B811Cu: goto L_060B811C; case 0x060B811Eu: goto L_060B811E; case 0x060B8120u: goto L_060B8120; case 0x060B8124u: goto L_060B8124; case 0x060B8126u: goto L_060B8126; case 0x060B8128u: goto L_060B8128; case 0x060B812Au: goto L_060B812A; case 0x060B812Eu: goto L_060B812E; case 0x060B8130u: goto L_060B8130; case 0x060B8132u: goto L_060B8132; case 0x060B8134u: goto L_060B8134; case 0x060B8138u: goto L_060B8138; case 0x060B813Au: goto L_060B813A; case 0x060B813Cu: goto L_060B813C; case 0x060B813Eu: goto L_060B813E; case 0x060B8142u: goto L_060B8142; case 0x060B8146u: goto L_060B8146; case 0x060B8148u: goto L_060B8148; case 0x060B814Au: goto L_060B814A; case 0x060B814Cu: goto L_060B814C; case 0x060B814Eu: goto L_060B814E; case 0x060B8150u: goto L_060B8150; case 0x060B8152u: goto L_060B8152; case 0x060B82D8u: goto L_060B82D8; case 0x060B82DAu: goto L_060B82DA; case 0x060B82DCu: goto L_060B82DC; case 0x060B82DEu: goto L_060B82DE; case 0x060B82E0u: goto L_060B82E0; case 0x060B82E2u: goto L_060B82E2; case 0x060B82E4u: goto L_060B82E4; case 0x060B82E6u: goto L_060B82E6; case 0x060B82E8u: goto L_060B82E8; case 0x060B82EAu: goto L_060B82EA; case 0x060B82ECu: goto L_060B82EC; case 0x060B82EEu: goto L_060B82EE; case 0x060B82F0u: goto L_060B82F0; case 0x060B82F2u: goto L_060B82F2; case 0x060B82F4u: goto L_060B82F4; case 0x060B82F8u: goto L_060B82F8; case 0x060B82FAu: goto L_060B82FA; case 0x060B82FCu: goto L_060B82FC; case 0x060B82FEu: goto L_060B82FE; case 0x060B8300u: goto L_060B8300; case 0x060B8304u: goto L_060B8304; case 0x060B8306u: goto L_060B8306; case 0x060B8308u: goto L_060B8308; case 0x060B830Cu: goto L_060B830C; case 0x060B830Eu: goto L_060B830E; case 0x060B8310u: goto L_060B8310; case 0x060B8312u: goto L_060B8312; case 0x060B8316u: goto L_060B8316; case 0x060B8318u: goto L_060B8318; case 0x060B831Au: goto L_060B831A; case 0x060B831Eu: goto L_060B831E; case 0x060B8320u: goto L_060B8320; case 0x060B8322u: goto L_060B8322; case 0x060B8324u: goto L_060B8324; case 0x060B8328u: goto L_060B8328; case 0x060B832Au: goto L_060B832A; case 0x060B832Cu: goto L_060B832C; case 0x060B8330u: goto L_060B8330; case 0x060B8332u: goto L_060B8332; case 0x060B8334u: goto L_060B8334; case 0x060B8338u: goto L_060B8338; case 0x060B833Au: goto L_060B833A; case 0x060B833Cu: goto L_060B833C; case 0x060B833Eu: goto L_060B833E; case 0x060B8340u: goto L_060B8340; case 0x060B8342u: goto L_060B8342; case 0x060B8344u: goto L_060B8344; case 0x060B8346u: goto L_060B8346; case 0x060B8348u: goto L_060B8348; case 0x060B834Au: goto L_060B834A; case 0x060B834Cu: goto L_060B834C; case 0x060B834Eu: goto L_060B834E; case 0x060B8350u: goto L_060B8350; case 0x060B8352u: goto L_060B8352; case 0x060B8354u: goto L_060B8354; case 0x060B8356u: goto L_060B8356; case 0x060B8358u: goto L_060B8358; case 0x060B835Au: goto L_060B835A; case 0x060B835Cu: goto L_060B835C; case 0x060B835Eu: goto L_060B835E; case 0x060B8360u: goto L_060B8360; case 0x060B8362u: goto L_060B8362; case 0x060B8364u: goto L_060B8364; case 0x060B8366u: goto L_060B8366; case 0x060B8368u: goto L_060B8368; case 0x060B836Au: goto L_060B836A; case 0x060B836Cu: goto L_060B836C; case 0x060B8370u: goto L_060B8370; case 0x060B8372u: goto L_060B8372; case 0x060B8374u: goto L_060B8374; case 0x060B8376u: goto L_060B8376; case 0x060B8378u: goto L_060B8378; case 0x060B837Au: goto L_060B837A; case 0x060B837Cu: goto L_060B837C; case 0x060B837Eu: goto L_060B837E; case 0x060B8380u: goto L_060B8380; case 0x060B8382u: goto L_060B8382; case 0x060B8384u: goto L_060B8384; case 0x060B8386u: goto L_060B8386; case 0x060B8388u: goto L_060B8388; case 0x060B838Au: goto L_060B838A; case 0x060B838Eu: goto L_060B838E; case 0x060B8390u: goto L_060B8390; case 0x060B8392u: goto L_060B8392; case 0x060B8394u: goto L_060B8394; case 0x060B8396u: goto L_060B8396; case 0x060B8398u: goto L_060B8398; case 0x060B839Au: goto L_060B839A; case 0x060B839Cu: goto L_060B839C; case 0x060B839Eu: goto L_060B839E; case 0x060B83A0u: goto L_060B83A0; case 0x060B83A2u: goto L_060B83A2; case 0x060B83A4u: goto L_060B83A4; case 0x060B83A6u: goto L_060B83A6; case 0x060B83A8u: goto L_060B83A8; case 0x060B83AAu: goto L_060B83AA; case 0x060B83AEu: goto L_060B83AE; case 0x060B83B0u: goto L_060B83B0; case 0x060B83B2u: goto L_060B83B2; case 0x060B83B4u: goto L_060B83B4; case 0x060B83B8u: goto L_060B83B8; case 0x060B83BAu: goto L_060B83BA; case 0x060B83BCu: goto L_060B83BC; case 0x060B83BEu: goto L_060B83BE; case 0x060B83C0u: goto L_060B83C0; case 0x060B83C2u: goto L_060B83C2; case 0x060B83C4u: goto L_060B83C4; case 0x060B83C8u: goto L_060B83C8; case 0x060B83CAu: goto L_060B83CA; case 0x060B83CCu: goto L_060B83CC; case 0x060B83CEu: goto L_060B83CE; case 0x060B83D0u: goto L_060B83D0; case 0x060B83D2u: goto L_060B83D2; case 0x060B83D4u: goto L_060B83D4; case 0x060B83D8u: goto L_060B83D8; case 0x060B83DAu: goto L_060B83DA; case 0x060B83DCu: goto L_060B83DC; case 0x060B83DEu: goto L_060B83DE; case 0x060B83E0u: goto L_060B83E0; case 0x060B83E2u: goto L_060B83E2; case 0x060B83E4u: goto L_060B83E4; default: sh2_call(c, x); return; } }  // 060B83AA jmp @r0 ; nop
L_060B83AE:
    st32(c.r[11] + 12, c.r[5]);  // 060B83AE mov.l r5,@(12,r11)
L_060B83B0:
    st32(c.r[11] + 16, c.r[1]);  // 060B83B0 mov.l r1,@(16,r11)
L_060B83B2:
    st32(c.r[11] + 20, c.r[7]);  // 060B83B2 mov.l r7,@(20,r11)
L_060B83B4:
    { const uint32_t x = c.pr; st32(c.r[11] + 24, c.r[9]); c.pc = x; return; }  // 060B83B4 rts ; mov.l r9,@(24,r11)
L_060B83B8:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[11]);  // 060B83B8 mov.w @(0,r11),r0
L_060B83BA:
    st32(c.r[11] + 16, c.r[5]);  // 060B83BA mov.l r5,@(16,r11)
L_060B83BC:
    c.r[0] ^= 0x10u;  // 060B83BC xor #16,r0
L_060B83BE:
    st16(c.r[11], c.r[0]);  // 060B83BE mov.w r0,@(0,r11)
L_060B83C0:
    st32(c.r[11] + 12, c.r[1]);  // 060B83C0 mov.l r1,@(12,r11)
L_060B83C2:
    st32(c.r[11] + 24, c.r[7]);  // 060B83C2 mov.l r7,@(24,r11)
L_060B83C4:
    { const uint32_t x = c.pr; st32(c.r[11] + 20, c.r[9]); c.pc = x; return; }  // 060B83C4 rts ; mov.l r9,@(20,r11)
L_060B83C8:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[11]);  // 060B83C8 mov.w @(0,r11),r0
L_060B83CA:
    st32(c.r[11] + 20, c.r[5]);  // 060B83CA mov.l r5,@(20,r11)
L_060B83CC:
    c.r[0] ^= 0x30u;  // 060B83CC xor #48,r0
L_060B83CE:
    st16(c.r[11], c.r[0]);  // 060B83CE mov.w r0,@(0,r11)
L_060B83D0:
    st32(c.r[11] + 24, c.r[1]);  // 060B83D0 mov.l r1,@(24,r11)
L_060B83D2:
    st32(c.r[11] + 12, c.r[7]);  // 060B83D2 mov.l r7,@(12,r11)
L_060B83D4:
    { const uint32_t x = c.pr; st32(c.r[11] + 16, c.r[9]); c.pc = x; return; }  // 060B83D4 rts ; mov.l r9,@(16,r11)
L_060B83D8:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[11]);  // 060B83D8 mov.w @(0,r11),r0
L_060B83DA:
    st32(c.r[11] + 24, c.r[5]);  // 060B83DA mov.l r5,@(24,r11)
L_060B83DC:
    c.r[0] ^= 0x20u;  // 060B83DC xor #32,r0
L_060B83DE:
    st16(c.r[11], c.r[0]);  // 060B83DE mov.w r0,@(0,r11)
L_060B83E0:
    st32(c.r[11] + 20, c.r[1]);  // 060B83E0 mov.l r1,@(20,r11)
L_060B83E2:
    st32(c.r[11] + 16, c.r[7]);  // 060B83E2 mov.l r7,@(16,r11)
L_060B83E4:
    { const uint32_t x = c.pr; st32(c.r[11] + 12, c.r[9]); c.pc = x; return; }  // 060B83E4 rts ; mov.l r9,@(12,r11)
}

void f_060B80DA(SH2Context& c) {
    ran[3158] = 1;
L_060B80DA:
    c.r[0] = c.r[2];  // 060B80DA mov r2,r0
L_060B80DC:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B80DC shar r0
L_060B80DE:
    c.r[8] -= c.r[0];  // 060B80DE sub r0,r8
L_060B80E0:
    c.r[0] = c.r[8];  // 060B80E0 mov r8,r0
L_060B80E2:
    c.r[0] += c.r[10];  // 060B80E2 add r10,r0
L_060B80E4:
    c.t = c.r[0] > c.r[13];  // 060B80E4 cmp/hi r13,r0
L_060B80E6:
    { const bool k = c.t; c.r[4] += 32; if (k) { goto L_060B8146; } }  // 060B80E6 bt/s 0x060B8146 ; add #32,r4
L_060B80EA:
    c.r[0] = c.r[6];  // 060B80EA mov r6,r0
L_060B80EC:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B80EC shar r0
L_060B80EE:
    c.r[9] -= c.r[0];  // 060B80EE sub r0,r9
L_060B80F0:
    c.r[0] = c.r[9];  // 060B80F0 mov r9,r0
L_060B80F2:
    c.r[0] += c.r[12];  // 060B80F2 add r12,r0
L_060B80F4:
    c.t = c.r[0] > c.r[14];  // 060B80F4 cmp/hi r14,r0
L_060B80F6:
    { const bool k = c.t; c.r[1] = c.r[8] << 16 | c.r[8] >> 16; if (k) { goto L_060B8146; } }  // 060B80F6 bt/s 0x060B8146 ; swap.w r8,r1
L_060B80FA:
    c.r[8] += c.r[2];  // 060B80FA add r2,r8
L_060B80FC:
    c.r[0] = c.r[8];  // 060B80FC mov r8,r0
L_060B80FE:
    c.r[0] += c.r[10];  // 060B80FE add r10,r0
L_060B8100:
    c.t = c.r[0] > c.r[13];  // 060B8100 cmp/hi r13,r0
L_060B8102:
    { const bool k = c.t; c.r[5] = c.r[9]; if (k) { goto L_060B8146; } }  // 060B8102 bt/s 0x060B8146 ; mov r9,r5
L_060B8106:
    c.r[9] += c.r[6];  // 060B8106 add r6,r9
L_060B8108:
    c.r[0] = c.r[9];  // 060B8108 mov r9,r0
L_060B810A:
    c.r[0] += c.r[12];  // 060B810A add r12,r0
L_060B810C:
    c.t = c.r[0] > c.r[14];  // 060B810C cmp/hi r14,r0
L_060B810E:
    { const bool k = c.t; c.r[0] = c.r[8] << 16 | c.r[8] >> 16; if (k) { goto L_060B8146; } }  // 060B810E bt/s 0x060B8146 ; swap.w r8,r0
L_060B8112:
    c.r[5] = c.r[1] << 16 | c.r[5] >> 16;  // 060B8112 xtrct r1,r5
L_060B8114:
    c.r[1] = c.r[9];  // 060B8114 mov r9,r1
L_060B8116:
    c.r[1] = c.r[0] << 16 | c.r[1] >> 16;  // 060B8116 xtrct r0,r1
L_060B8118:
    c.r[8] -= c.r[7];  // 060B8118 sub r7,r8
L_060B811A:
    c.r[0] = c.r[8];  // 060B811A mov r8,r0
L_060B811C:
    c.r[0] += c.r[10];  // 060B811C add r10,r0
L_060B811E:
    c.t = c.r[0] > c.r[13];  // 060B811E cmp/hi r13,r0
L_060B8120:
    { const bool k = c.t; c.r[9] += c.r[3]; if (k) { goto L_060B8146; } }  // 060B8120 bt/s 0x060B8146 ; add r3,r9
L_060B8124:
    c.r[0] = c.r[9];  // 060B8124 mov r9,r0
L_060B8126:
    c.r[0] += c.r[12];  // 060B8126 add r12,r0
L_060B8128:
    c.t = c.r[0] > c.r[14];  // 060B8128 cmp/hi r14,r0
L_060B812A:
    { const bool k = c.t; c.r[3] = c.r[8] << 16 | c.r[8] >> 16; if (k) { goto L_060B8146; } }  // 060B812A bt/s 0x060B8146 ; swap.w r8,r3
L_060B812E:
    c.r[8] -= c.r[2];  // 060B812E sub r2,r8
L_060B8130:
    c.r[10] += c.r[8];  // 060B8130 add r8,r10
L_060B8132:
    c.t = c.r[10] > c.r[13];  // 060B8132 cmp/hi r13,r10
L_060B8134:
    { const bool k = c.t; c.r[7] = c.r[9]; if (k) { goto L_060B8146; } }  // 060B8134 bt/s 0x060B8146 ; mov r9,r7
L_060B8138:
    c.r[9] -= c.r[6];  // 060B8138 sub r6,r9
L_060B813A:
    c.r[12] += c.r[9];  // 060B813A add r9,r12
L_060B813C:
    c.t = c.r[12] > c.r[14];  // 060B813C cmp/hi r14,r12
L_060B813E:
    { const bool k = c.t; c.r[7] = c.r[3] << 16 | c.r[7] >> 16; if (k) { goto L_060B8146; } }  // 060B813E bt/s 0x060B8146 ; xtrct r3,r7
L_060B8142:
    c.r[8] = c.r[8] << 16 | c.r[8] >> 16; goto L_060B82D8;  // 060B8142 bra 0x060B82D8 ; swap.w r8,r8
L_060B8146:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[11] + 30);  // 060B8146 mov.w @(30,r11),r0
L_060B8148:
    c.r[1] = ld32(c.r[11] + 32);  // 060B8148 mov.l @(32,r11),r1
L_060B814A:
    c.r[2] = (c.r[0] & 0xFFFF0000u) | (c.r[0] & 0xFFu) << 8 | (c.r[0] >> 8 & 0xFFu);  // 060B814A swap.b r0,r2
L_060B814C:
    c.r[0] = ld32(c.gbr + 56);  // 060B814C mov.l @(56,gbr),r0
L_060B814E:
    c.r[2] = c.r[2] & 0xFFu;  // 060B814E extu.b r2,r2
L_060B8150:
    c.r[2] <<= 2;  // 060B8150 shll2 r2
L_060B8152:
    { const uint32_t x = c.pr; st32(c.r[0] + c.r[2], c.r[1]); c.pc = x; return; }  // 060B8152 rts ; mov.l r1,@(r0,r2)
L_060B82D8:
    c.r[0] = c.r[11];  // 060B82D8 mov r11,r0
L_060B82DA:
    c.r[0] += 36;  // 060B82DA add #36,r0
L_060B82DC:
    st32(c.gbr + 52, c.r[0]);  // 060B82DC mov.l r0,@(52,gbr)
L_060B82DE:
    c.r[0] = ld32(c.gbr + 148);  // 060B82DE mov.l @(148,gbr),r0
L_060B82E0:
    c.r[3] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B82E0 exts.w r0,r3
L_060B82E2:
    c.r[2] = c.r[0] << 16 | c.r[0] >> 16;  // 060B82E2 swap.w r0,r2
L_060B82E4:
    c.r[0] = ld32(c.gbr + 816);  // 060B82E4 mov.l @(816,gbr),r0
L_060B82E6:
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 060B82E6 exts.w r2,r2
L_060B82E8:
    c.r[13] = c.r[0] & 0xFFFFu;  // 060B82E8 extu.w r0,r13
L_060B82EA:
    c.r[12] = c.r[0] << 16 | c.r[0] >> 16;  // 060B82EA swap.w r0,r12
L_060B82EC:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B82EC extu.w r12,r12
L_060B82EE:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[5];  // 060B82EE exts.w r5,r0
L_060B82F0:
    c.r[0] += c.r[3];  // 060B82F0 add r3,r0
L_060B82F2:
    c.t = c.r[0] >= c.r[13];  // 060B82F2 cmp/hs r13,r0
L_060B82F4:
    { const bool k = c.t; c.r[9] = c.r[8] << 16 | c.r[9] >> 16; if (k) { goto L_060B8302; } }  // 060B82F4 bt/s 0x060B8302 ; xtrct r8,r9
L_060B82F8:
    c.r[0] = c.r[5] << 16 | c.r[5] >> 16;  // 060B82F8 swap.w r5,r0
L_060B82FA:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B82FA exts.w r0,r0
L_060B82FC:
    c.r[0] += c.r[2];  // 060B82FC add r2,r0
L_060B82FE:
    c.t = c.r[12] > c.r[0];  // 060B82FE cmp/hi r0,r12
L_060B8300:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[1]; if (k) { goto L_060B83AE; } }  // 060B8300 bt/s 0x060B83AE ; exts.w r1,r0
    goto L_060B8304;
L_060B8302:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 060B8302 exts.w r1,r0
L_060B8304:
    c.r[0] += c.r[3];  // 060B8304 add r3,r0
L_060B8306:
    c.t = c.r[0] >= c.r[13];  // 060B8306 cmp/hs r13,r0
L_060B8308:
    { const bool k = c.t; c.r[0] = c.r[1] << 16 | c.r[1] >> 16; if (k) { goto L_060B8314; } }  // 060B8308 bt/s 0x060B8314 ; swap.w r1,r0
L_060B830C:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B830C exts.w r0,r0
L_060B830E:
    c.r[0] += c.r[2];  // 060B830E add r2,r0
L_060B8310:
    c.t = c.r[12] > c.r[0];  // 060B8310 cmp/hi r0,r12
L_060B8312:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[7]; if (k) { goto L_060B83B8; } }  // 060B8312 bt/s 0x060B83B8 ; exts.w r7,r0
    goto L_060B8316;
L_060B8314:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[7];  // 060B8314 exts.w r7,r0
L_060B8316:
    c.r[0] += c.r[3];  // 060B8316 add r3,r0
L_060B8318:
    c.t = c.r[0] >= c.r[13];  // 060B8318 cmp/hs r13,r0
L_060B831A:
    { const bool k = c.t; c.r[0] = c.r[7] << 16 | c.r[7] >> 16; if (k) { goto L_060B8326; } }  // 060B831A bt/s 0x060B8326 ; swap.w r7,r0
L_060B831E:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B831E exts.w r0,r0
L_060B8320:
    c.r[0] += c.r[2];  // 060B8320 add r2,r0
L_060B8322:
    c.t = c.r[12] > c.r[0];  // 060B8322 cmp/hi r0,r12
L_060B8324:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[9]; if (k) { goto L_060B83C8; } }  // 060B8324 bt/s 0x060B83C8 ; exts.w r9,r0
    goto L_060B8328;
L_060B8326:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[9];  // 060B8326 exts.w r9,r0
L_060B8328:
    c.r[0] += c.r[3];  // 060B8328 add r3,r0
L_060B832A:
    c.t = c.r[0] >= c.r[13];  // 060B832A cmp/hs r13,r0
L_060B832C:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[8]; if (k) { goto L_060B8336; } }  // 060B832C bt/s 0x060B8336 ; exts.w r8,r0
L_060B8330:
    c.r[0] += c.r[2];  // 060B8330 add r2,r0
L_060B8332:
    c.t = c.r[12] > c.r[0];  // 060B8332 cmp/hi r0,r12
L_060B8334:
    { const bool k = c.t; c.r[8] = 0x1u; if (k) { goto L_060B83D8; } }  // 060B8334 bt/s 0x060B83D8 ; mov #1,r8
    goto L_060B8338;
L_060B8336:
    c.r[8] = 0x1u;  // 060B8336 mov #1,r8
L_060B8338:
    c.r[8] <<= 16;  // 060B8338 shll16 r8
L_060B833A:
    c.t = c.r[8] & 1; c.r[8] >>= 1;  // 060B833A shlr r8
L_060B833C:
    c.r[2] = c.r[9] << 16 | c.r[9] >> 16;  // 060B833C swap.w r9,r2
L_060B833E:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B833E tst r8,r2
L_060B8340:
    { uint32_t a = c.r[13], b = c.r[13], t = c.t; c.r[13] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B8340 subc r13,r13
L_060B8342:
    c.r[13] = ~c.r[13];  // 060B8342 not r13,r13
L_060B8344:
    c.r[13] ^= c.r[2];  // 060B8344 xor r2,r13
L_060B8346:
    c.t = (c.r[9] & c.r[8]) == 0;  // 060B8346 tst r8,r9
L_060B8348:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B8348 subc r2,r2
L_060B834A:
    c.r[2] = ~c.r[2];  // 060B834A not r2,r2
L_060B834C:
    c.r[2] ^= c.r[9];  // 060B834C xor r9,r2
L_060B834E:
    c.r[13] += c.r[2];  // 060B834E add r2,r13
L_060B8350:
    c.r[13] = c.r[13] & 0xFFFFu;  // 060B8350 extu.w r13,r13
L_060B8352:
    c.r[0] = 0x060B83D8u;  // 060B8352 mova 0x060B83D8,r0
L_060B8354:
    c.r[2] = c.r[7] << 16 | c.r[7] >> 16;  // 060B8354 swap.w r7,r2
L_060B8356:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B8356 tst r8,r2
L_060B8358:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B8358 subc r12,r12
L_060B835A:
    c.r[12] = ~c.r[12];  // 060B835A not r12,r12
L_060B835C:
    c.r[12] ^= c.r[2];  // 060B835C xor r2,r12
L_060B835E:
    c.t = (c.r[7] & c.r[8]) == 0;  // 060B835E tst r8,r7
L_060B8360:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B8360 subc r2,r2
L_060B8362:
    c.r[2] = ~c.r[2];  // 060B8362 not r2,r2
L_060B8364:
    c.r[2] ^= c.r[7];  // 060B8364 xor r7,r2
L_060B8366:
    c.r[12] += c.r[2];  // 060B8366 add r2,r12
L_060B8368:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B8368 extu.w r12,r12
L_060B836A:
    c.t = (int32_t)c.r[12] > (int32_t)c.r[13];  // 060B836A cmp/gt r13,r12
L_060B836C:
    { const bool k = c.t; c.r[2] = c.r[1] << 16 | c.r[1] >> 16; if (k) { goto L_060B8374; } }  // 060B836C bt/s 0x060B8374 ; swap.w r1,r2
L_060B8370:
    c.r[13] = c.r[12];  // 060B8370 mov r12,r13
L_060B8372:
    c.r[0] = 0x060B83C8u;  // 060B8372 mova 0x060B83C8,r0
L_060B8374:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B8374 tst r8,r2
L_060B8376:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B8376 subc r12,r12
L_060B8378:
    c.r[12] = ~c.r[12];  // 060B8378 not r12,r12
L_060B837A:
    c.r[12] ^= c.r[2];  // 060B837A xor r2,r12
L_060B837C:
    c.t = (c.r[1] & c.r[8]) == 0;  // 060B837C tst r8,r1
L_060B837E:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B837E subc r2,r2
L_060B8380:
    c.r[2] = ~c.r[2];  // 060B8380 not r2,r2
L_060B8382:
    c.r[2] ^= c.r[1];  // 060B8382 xor r1,r2
L_060B8384:
    c.r[12] += c.r[2];  // 060B8384 add r2,r12
L_060B8386:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B8386 extu.w r12,r12
L_060B8388:
    c.t = (int32_t)c.r[12] > (int32_t)c.r[13];  // 060B8388 cmp/gt r13,r12
L_060B838A:
    { const bool k = c.t; c.r[2] = c.r[5] << 16 | c.r[5] >> 16; if (k) { goto L_060B8392; } }  // 060B838A bt/s 0x060B8392 ; swap.w r5,r2
L_060B838E:
    c.r[13] = c.r[12];  // 060B838E mov r12,r13
L_060B8390:
    c.r[0] = 0x060B83C8u;  // 060B8390 mova 0x060B83C8,r0
L_060B8392:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B8392 tst r8,r2
L_060B8394:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B8394 subc r12,r12
L_060B8396:
    c.r[12] = ~c.r[12];  // 060B8396 not r12,r12
L_060B8398:
    c.r[12] ^= c.r[2];  // 060B8398 xor r2,r12
L_060B839A:
    c.t = (c.r[5] & c.r[8]) == 0;  // 060B839A tst r8,r5
L_060B839C:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B839C subc r2,r2
L_060B839E:
    c.r[2] = ~c.r[2];  // 060B839E not r2,r2
L_060B83A0:
    c.r[2] ^= c.r[5];  // 060B83A0 xor r5,r2
L_060B83A2:
    c.r[12] += c.r[2];  // 060B83A2 add r2,r12
L_060B83A4:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B83A4 extu.w r12,r12
L_060B83A6:
    c.t = (int32_t)c.r[13] >= (int32_t)c.r[12];  // 060B83A6 cmp/ge r12,r13
L_060B83A8:
    if (c.t) { goto L_060B83AE; }  // 060B83A8 bt 0x060B83AE
L_060B83AA:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x060B80DAu: goto L_060B80DA; case 0x060B80DCu: goto L_060B80DC; case 0x060B80DEu: goto L_060B80DE; case 0x060B80E0u: goto L_060B80E0; case 0x060B80E2u: goto L_060B80E2; case 0x060B80E4u: goto L_060B80E4; case 0x060B80E6u: goto L_060B80E6; case 0x060B80EAu: goto L_060B80EA; case 0x060B80ECu: goto L_060B80EC; case 0x060B80EEu: goto L_060B80EE; case 0x060B80F0u: goto L_060B80F0; case 0x060B80F2u: goto L_060B80F2; case 0x060B80F4u: goto L_060B80F4; case 0x060B80F6u: goto L_060B80F6; case 0x060B80FAu: goto L_060B80FA; case 0x060B80FCu: goto L_060B80FC; case 0x060B80FEu: goto L_060B80FE; case 0x060B8100u: goto L_060B8100; case 0x060B8102u: goto L_060B8102; case 0x060B8106u: goto L_060B8106; case 0x060B8108u: goto L_060B8108; case 0x060B810Au: goto L_060B810A; case 0x060B810Cu: goto L_060B810C; case 0x060B810Eu: goto L_060B810E; case 0x060B8112u: goto L_060B8112; case 0x060B8114u: goto L_060B8114; case 0x060B8116u: goto L_060B8116; case 0x060B8118u: goto L_060B8118; case 0x060B811Au: goto L_060B811A; case 0x060B811Cu: goto L_060B811C; case 0x060B811Eu: goto L_060B811E; case 0x060B8120u: goto L_060B8120; case 0x060B8124u: goto L_060B8124; case 0x060B8126u: goto L_060B8126; case 0x060B8128u: goto L_060B8128; case 0x060B812Au: goto L_060B812A; case 0x060B812Eu: goto L_060B812E; case 0x060B8130u: goto L_060B8130; case 0x060B8132u: goto L_060B8132; case 0x060B8134u: goto L_060B8134; case 0x060B8138u: goto L_060B8138; case 0x060B813Au: goto L_060B813A; case 0x060B813Cu: goto L_060B813C; case 0x060B813Eu: goto L_060B813E; case 0x060B8142u: goto L_060B8142; case 0x060B8146u: goto L_060B8146; case 0x060B8148u: goto L_060B8148; case 0x060B814Au: goto L_060B814A; case 0x060B814Cu: goto L_060B814C; case 0x060B814Eu: goto L_060B814E; case 0x060B8150u: goto L_060B8150; case 0x060B8152u: goto L_060B8152; case 0x060B82D8u: goto L_060B82D8; case 0x060B82DAu: goto L_060B82DA; case 0x060B82DCu: goto L_060B82DC; case 0x060B82DEu: goto L_060B82DE; case 0x060B82E0u: goto L_060B82E0; case 0x060B82E2u: goto L_060B82E2; case 0x060B82E4u: goto L_060B82E4; case 0x060B82E6u: goto L_060B82E6; case 0x060B82E8u: goto L_060B82E8; case 0x060B82EAu: goto L_060B82EA; case 0x060B82ECu: goto L_060B82EC; case 0x060B82EEu: goto L_060B82EE; case 0x060B82F0u: goto L_060B82F0; case 0x060B82F2u: goto L_060B82F2; case 0x060B82F4u: goto L_060B82F4; case 0x060B82F8u: goto L_060B82F8; case 0x060B82FAu: goto L_060B82FA; case 0x060B82FCu: goto L_060B82FC; case 0x060B82FEu: goto L_060B82FE; case 0x060B8300u: goto L_060B8300; case 0x060B8304u: goto L_060B8304; case 0x060B8306u: goto L_060B8306; case 0x060B8308u: goto L_060B8308; case 0x060B830Cu: goto L_060B830C; case 0x060B830Eu: goto L_060B830E; case 0x060B8310u: goto L_060B8310; case 0x060B8312u: goto L_060B8312; case 0x060B8316u: goto L_060B8316; case 0x060B8318u: goto L_060B8318; case 0x060B831Au: goto L_060B831A; case 0x060B831Eu: goto L_060B831E; case 0x060B8320u: goto L_060B8320; case 0x060B8322u: goto L_060B8322; case 0x060B8324u: goto L_060B8324; case 0x060B8328u: goto L_060B8328; case 0x060B832Au: goto L_060B832A; case 0x060B832Cu: goto L_060B832C; case 0x060B8330u: goto L_060B8330; case 0x060B8332u: goto L_060B8332; case 0x060B8334u: goto L_060B8334; case 0x060B8338u: goto L_060B8338; case 0x060B833Au: goto L_060B833A; case 0x060B833Cu: goto L_060B833C; case 0x060B833Eu: goto L_060B833E; case 0x060B8340u: goto L_060B8340; case 0x060B8342u: goto L_060B8342; case 0x060B8344u: goto L_060B8344; case 0x060B8346u: goto L_060B8346; case 0x060B8348u: goto L_060B8348; case 0x060B834Au: goto L_060B834A; case 0x060B834Cu: goto L_060B834C; case 0x060B834Eu: goto L_060B834E; case 0x060B8350u: goto L_060B8350; case 0x060B8352u: goto L_060B8352; case 0x060B8354u: goto L_060B8354; case 0x060B8356u: goto L_060B8356; case 0x060B8358u: goto L_060B8358; case 0x060B835Au: goto L_060B835A; case 0x060B835Cu: goto L_060B835C; case 0x060B835Eu: goto L_060B835E; case 0x060B8360u: goto L_060B8360; case 0x060B8362u: goto L_060B8362; case 0x060B8364u: goto L_060B8364; case 0x060B8366u: goto L_060B8366; case 0x060B8368u: goto L_060B8368; case 0x060B836Au: goto L_060B836A; case 0x060B836Cu: goto L_060B836C; case 0x060B8370u: goto L_060B8370; case 0x060B8372u: goto L_060B8372; case 0x060B8374u: goto L_060B8374; case 0x060B8376u: goto L_060B8376; case 0x060B8378u: goto L_060B8378; case 0x060B837Au: goto L_060B837A; case 0x060B837Cu: goto L_060B837C; case 0x060B837Eu: goto L_060B837E; case 0x060B8380u: goto L_060B8380; case 0x060B8382u: goto L_060B8382; case 0x060B8384u: goto L_060B8384; case 0x060B8386u: goto L_060B8386; case 0x060B8388u: goto L_060B8388; case 0x060B838Au: goto L_060B838A; case 0x060B838Eu: goto L_060B838E; case 0x060B8390u: goto L_060B8390; case 0x060B8392u: goto L_060B8392; case 0x060B8394u: goto L_060B8394; case 0x060B8396u: goto L_060B8396; case 0x060B8398u: goto L_060B8398; case 0x060B839Au: goto L_060B839A; case 0x060B839Cu: goto L_060B839C; case 0x060B839Eu: goto L_060B839E; case 0x060B83A0u: goto L_060B83A0; case 0x060B83A2u: goto L_060B83A2; case 0x060B83A4u: goto L_060B83A4; case 0x060B83A6u: goto L_060B83A6; case 0x060B83A8u: goto L_060B83A8; case 0x060B83AAu: goto L_060B83AA; case 0x060B83AEu: goto L_060B83AE; case 0x060B83B0u: goto L_060B83B0; case 0x060B83B2u: goto L_060B83B2; case 0x060B83B4u: goto L_060B83B4; case 0x060B83B8u: goto L_060B83B8; case 0x060B83BAu: goto L_060B83BA; case 0x060B83BCu: goto L_060B83BC; case 0x060B83BEu: goto L_060B83BE; case 0x060B83C0u: goto L_060B83C0; case 0x060B83C2u: goto L_060B83C2; case 0x060B83C4u: goto L_060B83C4; case 0x060B83C8u: goto L_060B83C8; case 0x060B83CAu: goto L_060B83CA; case 0x060B83CCu: goto L_060B83CC; case 0x060B83CEu: goto L_060B83CE; case 0x060B83D0u: goto L_060B83D0; case 0x060B83D2u: goto L_060B83D2; case 0x060B83D4u: goto L_060B83D4; case 0x060B83D8u: goto L_060B83D8; case 0x060B83DAu: goto L_060B83DA; case 0x060B83DCu: goto L_060B83DC; case 0x060B83DEu: goto L_060B83DE; case 0x060B83E0u: goto L_060B83E0; case 0x060B83E2u: goto L_060B83E2; case 0x060B83E4u: goto L_060B83E4; default: sh2_call(c, x); return; } }  // 060B83AA jmp @r0 ; nop
L_060B83AE:
    st32(c.r[11] + 12, c.r[5]);  // 060B83AE mov.l r5,@(12,r11)
L_060B83B0:
    st32(c.r[11] + 16, c.r[1]);  // 060B83B0 mov.l r1,@(16,r11)
L_060B83B2:
    st32(c.r[11] + 20, c.r[7]);  // 060B83B2 mov.l r7,@(20,r11)
L_060B83B4:
    { const uint32_t x = c.pr; st32(c.r[11] + 24, c.r[9]); c.pc = x; return; }  // 060B83B4 rts ; mov.l r9,@(24,r11)
L_060B83B8:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[11]);  // 060B83B8 mov.w @(0,r11),r0
L_060B83BA:
    st32(c.r[11] + 16, c.r[5]);  // 060B83BA mov.l r5,@(16,r11)
L_060B83BC:
    c.r[0] ^= 0x10u;  // 060B83BC xor #16,r0
L_060B83BE:
    st16(c.r[11], c.r[0]);  // 060B83BE mov.w r0,@(0,r11)
L_060B83C0:
    st32(c.r[11] + 12, c.r[1]);  // 060B83C0 mov.l r1,@(12,r11)
L_060B83C2:
    st32(c.r[11] + 24, c.r[7]);  // 060B83C2 mov.l r7,@(24,r11)
L_060B83C4:
    { const uint32_t x = c.pr; st32(c.r[11] + 20, c.r[9]); c.pc = x; return; }  // 060B83C4 rts ; mov.l r9,@(20,r11)
L_060B83C8:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[11]);  // 060B83C8 mov.w @(0,r11),r0
L_060B83CA:
    st32(c.r[11] + 20, c.r[5]);  // 060B83CA mov.l r5,@(20,r11)
L_060B83CC:
    c.r[0] ^= 0x30u;  // 060B83CC xor #48,r0
L_060B83CE:
    st16(c.r[11], c.r[0]);  // 060B83CE mov.w r0,@(0,r11)
L_060B83D0:
    st32(c.r[11] + 24, c.r[1]);  // 060B83D0 mov.l r1,@(24,r11)
L_060B83D2:
    st32(c.r[11] + 12, c.r[7]);  // 060B83D2 mov.l r7,@(12,r11)
L_060B83D4:
    { const uint32_t x = c.pr; st32(c.r[11] + 16, c.r[9]); c.pc = x; return; }  // 060B83D4 rts ; mov.l r9,@(16,r11)
L_060B83D8:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[11]);  // 060B83D8 mov.w @(0,r11),r0
L_060B83DA:
    st32(c.r[11] + 24, c.r[5]);  // 060B83DA mov.l r5,@(24,r11)
L_060B83DC:
    c.r[0] ^= 0x20u;  // 060B83DC xor #32,r0
L_060B83DE:
    st16(c.r[11], c.r[0]);  // 060B83DE mov.w r0,@(0,r11)
L_060B83E0:
    st32(c.r[11] + 20, c.r[1]);  // 060B83E0 mov.l r1,@(20,r11)
L_060B83E2:
    st32(c.r[11] + 16, c.r[7]);  // 060B83E2 mov.l r7,@(16,r11)
L_060B83E4:
    { const uint32_t x = c.pr; st32(c.r[11] + 12, c.r[9]); c.pc = x; return; }  // 060B83E4 rts ; mov.l r9,@(12,r11)
}

void f_060B8156(SH2Context& c) {
    ran[3159] = 1;
    goto L_060B8156;
L_060B8146:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[11] + 30);  // 060B8146 mov.w @(30,r11),r0
L_060B8148:
    c.r[1] = ld32(c.r[11] + 32);  // 060B8148 mov.l @(32,r11),r1
L_060B814A:
    c.r[2] = (c.r[0] & 0xFFFF0000u) | (c.r[0] & 0xFFu) << 8 | (c.r[0] >> 8 & 0xFFu);  // 060B814A swap.b r0,r2
L_060B814C:
    c.r[0] = ld32(c.gbr + 56);  // 060B814C mov.l @(56,gbr),r0
L_060B814E:
    c.r[2] = c.r[2] & 0xFFu;  // 060B814E extu.b r2,r2
L_060B8150:
    c.r[2] <<= 2;  // 060B8150 shll2 r2
L_060B8152:
    { const uint32_t x = c.pr; st32(c.r[0] + c.r[2], c.r[1]); c.pc = x; return; }  // 060B8152 rts ; mov.l r1,@(r0,r2)
L_060B8156:
    c.r[1] = 0x20u;  // 060B8156 mov #32,r1
L_060B8158:
    c.r[3] = 0u - c.r[3];  // 060B8158 neg r3,r3
L_060B815A:
    c.r[7] = 0u - c.r[7]; goto L_060B816C;  // 060B815A bra 0x060B816C ; neg r7,r7
L_060B816C:
    c.r[5] ^= c.r[1];  // 060B816C xor r1,r5
L_060B816E:
    st16(c.r[11], c.r[5]);  // 060B816E mov.w r5,@r11
L_060B8170:
    c.r[0] = c.r[8];  // 060B8170 mov r8,r0
L_060B8172:
    c.r[0] += c.r[10];  // 060B8172 add r10,r0
L_060B8174:
    c.t = c.r[0] > c.r[13];  // 060B8174 cmp/hi r13,r0
L_060B8176:
    { const bool k = c.t; c.r[4] += 32; if (k) { SH2_POLL(c); goto L_060B8146; } }  // 060B8176 bt/s 0x060B8146 ; add #32,r4
L_060B817A:
    c.r[0] = c.r[9];  // 060B817A mov r9,r0
L_060B817C:
    c.r[0] += c.r[12];  // 060B817C add r12,r0
L_060B817E:
    c.t = c.r[0] > c.r[14];  // 060B817E cmp/hi r14,r0
L_060B8180:
    { const bool k = c.t; c.r[0] = c.r[8] << 16 | c.r[8] >> 16; if (k) { SH2_POLL(c); goto L_060B8146; } }  // 060B8180 bt/s 0x060B8146 ; swap.w r8,r0
L_060B8184:
    c.r[5] = c.r[9];  // 060B8184 mov r9,r5
L_060B8186:
    c.r[5] = c.r[0] << 16 | c.r[5] >> 16;  // 060B8186 xtrct r0,r5
L_060B8188:
    c.r[8] += c.r[2];  // 060B8188 add r2,r8
L_060B818A:
    c.r[0] = c.r[8];  // 060B818A mov r8,r0
L_060B818C:
    c.r[0] += c.r[10];  // 060B818C add r10,r0
L_060B818E:
    c.t = c.r[0] > c.r[13];  // 060B818E cmp/hi r13,r0
L_060B8190:
    { const bool k = c.t; c.r[9] += c.r[6]; if (k) { SH2_POLL(c); goto L_060B8146; } }  // 060B8190 bt/s 0x060B8146 ; add r6,r9
L_060B8194:
    c.r[0] = c.r[9];  // 060B8194 mov r9,r0
L_060B8196:
    c.r[0] += c.r[12];  // 060B8196 add r12,r0
L_060B8198:
    c.t = c.r[0] > c.r[14];  // 060B8198 cmp/hi r14,r0
L_060B819A:
    { const bool k = c.t; c.r[0] = c.r[8] << 16 | c.r[8] >> 16; if (k) { SH2_POLL(c); goto L_060B8146; } }  // 060B819A bt/s 0x060B8146 ; swap.w r8,r0
L_060B819E:
    c.r[1] = c.r[9];  // 060B819E mov r9,r1
L_060B81A0:
    c.r[1] = c.r[0] << 16 | c.r[1] >> 16;  // 060B81A0 xtrct r0,r1
L_060B81A2:
    c.r[8] -= c.r[7];  // 060B81A2 sub r7,r8
L_060B81A4:
    c.r[0] = c.r[8];  // 060B81A4 mov r8,r0
L_060B81A6:
    c.r[0] += c.r[10];  // 060B81A6 add r10,r0
L_060B81A8:
    c.t = c.r[0] > c.r[13];  // 060B81A8 cmp/hi r13,r0
L_060B81AA:
    { const bool k = c.t; c.r[9] += c.r[3]; if (k) { SH2_POLL(c); goto L_060B8146; } }  // 060B81AA bt/s 0x060B8146 ; add r3,r9
L_060B81AE:
    c.r[0] = c.r[9];  // 060B81AE mov r9,r0
L_060B81B0:
    c.r[0] += c.r[12];  // 060B81B0 add r12,r0
L_060B81B2:
    c.t = c.r[0] > c.r[14];  // 060B81B2 cmp/hi r14,r0
L_060B81B4:
    { const bool k = c.t; c.r[3] = c.r[8] << 16 | c.r[8] >> 16; if (k) { SH2_POLL(c); goto L_060B8146; } }  // 060B81B4 bt/s 0x060B8146 ; swap.w r8,r3
L_060B81B8:
    c.r[8] -= c.r[2];  // 060B81B8 sub r2,r8
L_060B81BA:
    c.r[10] += c.r[8];  // 060B81BA add r8,r10
L_060B81BC:
    c.t = c.r[10] > c.r[13];  // 060B81BC cmp/hi r13,r10
L_060B81BE:
    { const bool k = c.t; c.r[7] = c.r[9]; if (k) { SH2_POLL(c); goto L_060B8146; } }  // 060B81BE bt/s 0x060B8146 ; mov r9,r7
L_060B81C2:
    c.r[9] -= c.r[6];  // 060B81C2 sub r6,r9
L_060B81C4:
    c.r[12] += c.r[9];  // 060B81C4 add r9,r12
L_060B81C6:
    c.t = c.r[12] > c.r[14];  // 060B81C6 cmp/hi r14,r12
L_060B81C8:
    { const bool k = c.t; c.r[7] = c.r[3] << 16 | c.r[7] >> 16; if (k) { SH2_POLL(c); goto L_060B8146; } }  // 060B81C8 bt/s 0x060B8146 ; xtrct r3,r7
L_060B81CC:
    c.r[8] = c.r[8] << 16 | c.r[8] >> 16; goto L_060B82D8;  // 060B81CC bra 0x060B82D8 ; swap.w r8,r8
L_060B82D8:
    c.r[0] = c.r[11];  // 060B82D8 mov r11,r0
L_060B82DA:
    c.r[0] += 36;  // 060B82DA add #36,r0
L_060B82DC:
    st32(c.gbr + 52, c.r[0]);  // 060B82DC mov.l r0,@(52,gbr)
L_060B82DE:
    c.r[0] = ld32(c.gbr + 148);  // 060B82DE mov.l @(148,gbr),r0
L_060B82E0:
    c.r[3] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B82E0 exts.w r0,r3
L_060B82E2:
    c.r[2] = c.r[0] << 16 | c.r[0] >> 16;  // 060B82E2 swap.w r0,r2
L_060B82E4:
    c.r[0] = ld32(c.gbr + 816);  // 060B82E4 mov.l @(816,gbr),r0
L_060B82E6:
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 060B82E6 exts.w r2,r2
L_060B82E8:
    c.r[13] = c.r[0] & 0xFFFFu;  // 060B82E8 extu.w r0,r13
L_060B82EA:
    c.r[12] = c.r[0] << 16 | c.r[0] >> 16;  // 060B82EA swap.w r0,r12
L_060B82EC:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B82EC extu.w r12,r12
L_060B82EE:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[5];  // 060B82EE exts.w r5,r0
L_060B82F0:
    c.r[0] += c.r[3];  // 060B82F0 add r3,r0
L_060B82F2:
    c.t = c.r[0] >= c.r[13];  // 060B82F2 cmp/hs r13,r0
L_060B82F4:
    { const bool k = c.t; c.r[9] = c.r[8] << 16 | c.r[9] >> 16; if (k) { goto L_060B8302; } }  // 060B82F4 bt/s 0x060B8302 ; xtrct r8,r9
L_060B82F8:
    c.r[0] = c.r[5] << 16 | c.r[5] >> 16;  // 060B82F8 swap.w r5,r0
L_060B82FA:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B82FA exts.w r0,r0
L_060B82FC:
    c.r[0] += c.r[2];  // 060B82FC add r2,r0
L_060B82FE:
    c.t = c.r[12] > c.r[0];  // 060B82FE cmp/hi r0,r12
L_060B8300:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[1]; if (k) { goto L_060B83AE; } }  // 060B8300 bt/s 0x060B83AE ; exts.w r1,r0
    goto L_060B8304;
L_060B8302:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 060B8302 exts.w r1,r0
L_060B8304:
    c.r[0] += c.r[3];  // 060B8304 add r3,r0
L_060B8306:
    c.t = c.r[0] >= c.r[13];  // 060B8306 cmp/hs r13,r0
L_060B8308:
    { const bool k = c.t; c.r[0] = c.r[1] << 16 | c.r[1] >> 16; if (k) { goto L_060B8314; } }  // 060B8308 bt/s 0x060B8314 ; swap.w r1,r0
L_060B830C:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B830C exts.w r0,r0
L_060B830E:
    c.r[0] += c.r[2];  // 060B830E add r2,r0
L_060B8310:
    c.t = c.r[12] > c.r[0];  // 060B8310 cmp/hi r0,r12
L_060B8312:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[7]; if (k) { goto L_060B83B8; } }  // 060B8312 bt/s 0x060B83B8 ; exts.w r7,r0
    goto L_060B8316;
L_060B8314:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[7];  // 060B8314 exts.w r7,r0
L_060B8316:
    c.r[0] += c.r[3];  // 060B8316 add r3,r0
L_060B8318:
    c.t = c.r[0] >= c.r[13];  // 060B8318 cmp/hs r13,r0
L_060B831A:
    { const bool k = c.t; c.r[0] = c.r[7] << 16 | c.r[7] >> 16; if (k) { goto L_060B8326; } }  // 060B831A bt/s 0x060B8326 ; swap.w r7,r0
L_060B831E:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B831E exts.w r0,r0
L_060B8320:
    c.r[0] += c.r[2];  // 060B8320 add r2,r0
L_060B8322:
    c.t = c.r[12] > c.r[0];  // 060B8322 cmp/hi r0,r12
L_060B8324:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[9]; if (k) { goto L_060B83C8; } }  // 060B8324 bt/s 0x060B83C8 ; exts.w r9,r0
    goto L_060B8328;
L_060B8326:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[9];  // 060B8326 exts.w r9,r0
L_060B8328:
    c.r[0] += c.r[3];  // 060B8328 add r3,r0
L_060B832A:
    c.t = c.r[0] >= c.r[13];  // 060B832A cmp/hs r13,r0
L_060B832C:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[8]; if (k) { goto L_060B8336; } }  // 060B832C bt/s 0x060B8336 ; exts.w r8,r0
L_060B8330:
    c.r[0] += c.r[2];  // 060B8330 add r2,r0
L_060B8332:
    c.t = c.r[12] > c.r[0];  // 060B8332 cmp/hi r0,r12
L_060B8334:
    { const bool k = c.t; c.r[8] = 0x1u; if (k) { goto L_060B83D8; } }  // 060B8334 bt/s 0x060B83D8 ; mov #1,r8
    goto L_060B8338;
L_060B8336:
    c.r[8] = 0x1u;  // 060B8336 mov #1,r8
L_060B8338:
    c.r[8] <<= 16;  // 060B8338 shll16 r8
L_060B833A:
    c.t = c.r[8] & 1; c.r[8] >>= 1;  // 060B833A shlr r8
L_060B833C:
    c.r[2] = c.r[9] << 16 | c.r[9] >> 16;  // 060B833C swap.w r9,r2
L_060B833E:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B833E tst r8,r2
L_060B8340:
    { uint32_t a = c.r[13], b = c.r[13], t = c.t; c.r[13] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B8340 subc r13,r13
L_060B8342:
    c.r[13] = ~c.r[13];  // 060B8342 not r13,r13
L_060B8344:
    c.r[13] ^= c.r[2];  // 060B8344 xor r2,r13
L_060B8346:
    c.t = (c.r[9] & c.r[8]) == 0;  // 060B8346 tst r8,r9
L_060B8348:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B8348 subc r2,r2
L_060B834A:
    c.r[2] = ~c.r[2];  // 060B834A not r2,r2
L_060B834C:
    c.r[2] ^= c.r[9];  // 060B834C xor r9,r2
L_060B834E:
    c.r[13] += c.r[2];  // 060B834E add r2,r13
L_060B8350:
    c.r[13] = c.r[13] & 0xFFFFu;  // 060B8350 extu.w r13,r13
L_060B8352:
    c.r[0] = 0x060B83D8u;  // 060B8352 mova 0x060B83D8,r0
L_060B8354:
    c.r[2] = c.r[7] << 16 | c.r[7] >> 16;  // 060B8354 swap.w r7,r2
L_060B8356:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B8356 tst r8,r2
L_060B8358:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B8358 subc r12,r12
L_060B835A:
    c.r[12] = ~c.r[12];  // 060B835A not r12,r12
L_060B835C:
    c.r[12] ^= c.r[2];  // 060B835C xor r2,r12
L_060B835E:
    c.t = (c.r[7] & c.r[8]) == 0;  // 060B835E tst r8,r7
L_060B8360:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B8360 subc r2,r2
L_060B8362:
    c.r[2] = ~c.r[2];  // 060B8362 not r2,r2
L_060B8364:
    c.r[2] ^= c.r[7];  // 060B8364 xor r7,r2
L_060B8366:
    c.r[12] += c.r[2];  // 060B8366 add r2,r12
L_060B8368:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B8368 extu.w r12,r12
L_060B836A:
    c.t = (int32_t)c.r[12] > (int32_t)c.r[13];  // 060B836A cmp/gt r13,r12
L_060B836C:
    { const bool k = c.t; c.r[2] = c.r[1] << 16 | c.r[1] >> 16; if (k) { goto L_060B8374; } }  // 060B836C bt/s 0x060B8374 ; swap.w r1,r2
L_060B8370:
    c.r[13] = c.r[12];  // 060B8370 mov r12,r13
L_060B8372:
    c.r[0] = 0x060B83C8u;  // 060B8372 mova 0x060B83C8,r0
L_060B8374:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B8374 tst r8,r2
L_060B8376:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B8376 subc r12,r12
L_060B8378:
    c.r[12] = ~c.r[12];  // 060B8378 not r12,r12
L_060B837A:
    c.r[12] ^= c.r[2];  // 060B837A xor r2,r12
L_060B837C:
    c.t = (c.r[1] & c.r[8]) == 0;  // 060B837C tst r8,r1
L_060B837E:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B837E subc r2,r2
L_060B8380:
    c.r[2] = ~c.r[2];  // 060B8380 not r2,r2
L_060B8382:
    c.r[2] ^= c.r[1];  // 060B8382 xor r1,r2
L_060B8384:
    c.r[12] += c.r[2];  // 060B8384 add r2,r12
L_060B8386:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B8386 extu.w r12,r12
L_060B8388:
    c.t = (int32_t)c.r[12] > (int32_t)c.r[13];  // 060B8388 cmp/gt r13,r12
L_060B838A:
    { const bool k = c.t; c.r[2] = c.r[5] << 16 | c.r[5] >> 16; if (k) { goto L_060B8392; } }  // 060B838A bt/s 0x060B8392 ; swap.w r5,r2
L_060B838E:
    c.r[13] = c.r[12];  // 060B838E mov r12,r13
L_060B8390:
    c.r[0] = 0x060B83C8u;  // 060B8390 mova 0x060B83C8,r0
L_060B8392:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B8392 tst r8,r2
L_060B8394:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B8394 subc r12,r12
L_060B8396:
    c.r[12] = ~c.r[12];  // 060B8396 not r12,r12
L_060B8398:
    c.r[12] ^= c.r[2];  // 060B8398 xor r2,r12
L_060B839A:
    c.t = (c.r[5] & c.r[8]) == 0;  // 060B839A tst r8,r5
L_060B839C:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B839C subc r2,r2
L_060B839E:
    c.r[2] = ~c.r[2];  // 060B839E not r2,r2
L_060B83A0:
    c.r[2] ^= c.r[5];  // 060B83A0 xor r5,r2
L_060B83A2:
    c.r[12] += c.r[2];  // 060B83A2 add r2,r12
L_060B83A4:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B83A4 extu.w r12,r12
L_060B83A6:
    c.t = (int32_t)c.r[13] >= (int32_t)c.r[12];  // 060B83A6 cmp/ge r12,r13
L_060B83A8:
    if (c.t) { goto L_060B83AE; }  // 060B83A8 bt 0x060B83AE
L_060B83AA:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x060B8146u: goto L_060B8146; case 0x060B8148u: goto L_060B8148; case 0x060B814Au: goto L_060B814A; case 0x060B814Cu: goto L_060B814C; case 0x060B814Eu: goto L_060B814E; case 0x060B8150u: goto L_060B8150; case 0x060B8152u: goto L_060B8152; case 0x060B8156u: goto L_060B8156; case 0x060B8158u: goto L_060B8158; case 0x060B815Au: goto L_060B815A; case 0x060B816Cu: goto L_060B816C; case 0x060B816Eu: goto L_060B816E; case 0x060B8170u: goto L_060B8170; case 0x060B8172u: goto L_060B8172; case 0x060B8174u: goto L_060B8174; case 0x060B8176u: goto L_060B8176; case 0x060B817Au: goto L_060B817A; case 0x060B817Cu: goto L_060B817C; case 0x060B817Eu: goto L_060B817E; case 0x060B8180u: goto L_060B8180; case 0x060B8184u: goto L_060B8184; case 0x060B8186u: goto L_060B8186; case 0x060B8188u: goto L_060B8188; case 0x060B818Au: goto L_060B818A; case 0x060B818Cu: goto L_060B818C; case 0x060B818Eu: goto L_060B818E; case 0x060B8190u: goto L_060B8190; case 0x060B8194u: goto L_060B8194; case 0x060B8196u: goto L_060B8196; case 0x060B8198u: goto L_060B8198; case 0x060B819Au: goto L_060B819A; case 0x060B819Eu: goto L_060B819E; case 0x060B81A0u: goto L_060B81A0; case 0x060B81A2u: goto L_060B81A2; case 0x060B81A4u: goto L_060B81A4; case 0x060B81A6u: goto L_060B81A6; case 0x060B81A8u: goto L_060B81A8; case 0x060B81AAu: goto L_060B81AA; case 0x060B81AEu: goto L_060B81AE; case 0x060B81B0u: goto L_060B81B0; case 0x060B81B2u: goto L_060B81B2; case 0x060B81B4u: goto L_060B81B4; case 0x060B81B8u: goto L_060B81B8; case 0x060B81BAu: goto L_060B81BA; case 0x060B81BCu: goto L_060B81BC; case 0x060B81BEu: goto L_060B81BE; case 0x060B81C2u: goto L_060B81C2; case 0x060B81C4u: goto L_060B81C4; case 0x060B81C6u: goto L_060B81C6; case 0x060B81C8u: goto L_060B81C8; case 0x060B81CCu: goto L_060B81CC; case 0x060B82D8u: goto L_060B82D8; case 0x060B82DAu: goto L_060B82DA; case 0x060B82DCu: goto L_060B82DC; case 0x060B82DEu: goto L_060B82DE; case 0x060B82E0u: goto L_060B82E0; case 0x060B82E2u: goto L_060B82E2; case 0x060B82E4u: goto L_060B82E4; case 0x060B82E6u: goto L_060B82E6; case 0x060B82E8u: goto L_060B82E8; case 0x060B82EAu: goto L_060B82EA; case 0x060B82ECu: goto L_060B82EC; case 0x060B82EEu: goto L_060B82EE; case 0x060B82F0u: goto L_060B82F0; case 0x060B82F2u: goto L_060B82F2; case 0x060B82F4u: goto L_060B82F4; case 0x060B82F8u: goto L_060B82F8; case 0x060B82FAu: goto L_060B82FA; case 0x060B82FCu: goto L_060B82FC; case 0x060B82FEu: goto L_060B82FE; case 0x060B8300u: goto L_060B8300; case 0x060B8304u: goto L_060B8304; case 0x060B8306u: goto L_060B8306; case 0x060B8308u: goto L_060B8308; case 0x060B830Cu: goto L_060B830C; case 0x060B830Eu: goto L_060B830E; case 0x060B8310u: goto L_060B8310; case 0x060B8312u: goto L_060B8312; case 0x060B8316u: goto L_060B8316; case 0x060B8318u: goto L_060B8318; case 0x060B831Au: goto L_060B831A; case 0x060B831Eu: goto L_060B831E; case 0x060B8320u: goto L_060B8320; case 0x060B8322u: goto L_060B8322; case 0x060B8324u: goto L_060B8324; case 0x060B8328u: goto L_060B8328; case 0x060B832Au: goto L_060B832A; case 0x060B832Cu: goto L_060B832C; case 0x060B8330u: goto L_060B8330; case 0x060B8332u: goto L_060B8332; case 0x060B8334u: goto L_060B8334; case 0x060B8338u: goto L_060B8338; case 0x060B833Au: goto L_060B833A; case 0x060B833Cu: goto L_060B833C; case 0x060B833Eu: goto L_060B833E; case 0x060B8340u: goto L_060B8340; case 0x060B8342u: goto L_060B8342; case 0x060B8344u: goto L_060B8344; case 0x060B8346u: goto L_060B8346; case 0x060B8348u: goto L_060B8348; case 0x060B834Au: goto L_060B834A; case 0x060B834Cu: goto L_060B834C; case 0x060B834Eu: goto L_060B834E; case 0x060B8350u: goto L_060B8350; case 0x060B8352u: goto L_060B8352; case 0x060B8354u: goto L_060B8354; case 0x060B8356u: goto L_060B8356; case 0x060B8358u: goto L_060B8358; case 0x060B835Au: goto L_060B835A; case 0x060B835Cu: goto L_060B835C; case 0x060B835Eu: goto L_060B835E; case 0x060B8360u: goto L_060B8360; case 0x060B8362u: goto L_060B8362; case 0x060B8364u: goto L_060B8364; case 0x060B8366u: goto L_060B8366; case 0x060B8368u: goto L_060B8368; case 0x060B836Au: goto L_060B836A; case 0x060B836Cu: goto L_060B836C; case 0x060B8370u: goto L_060B8370; case 0x060B8372u: goto L_060B8372; case 0x060B8374u: goto L_060B8374; case 0x060B8376u: goto L_060B8376; case 0x060B8378u: goto L_060B8378; case 0x060B837Au: goto L_060B837A; case 0x060B837Cu: goto L_060B837C; case 0x060B837Eu: goto L_060B837E; case 0x060B8380u: goto L_060B8380; case 0x060B8382u: goto L_060B8382; case 0x060B8384u: goto L_060B8384; case 0x060B8386u: goto L_060B8386; case 0x060B8388u: goto L_060B8388; case 0x060B838Au: goto L_060B838A; case 0x060B838Eu: goto L_060B838E; case 0x060B8390u: goto L_060B8390; case 0x060B8392u: goto L_060B8392; case 0x060B8394u: goto L_060B8394; case 0x060B8396u: goto L_060B8396; case 0x060B8398u: goto L_060B8398; case 0x060B839Au: goto L_060B839A; case 0x060B839Cu: goto L_060B839C; case 0x060B839Eu: goto L_060B839E; case 0x060B83A0u: goto L_060B83A0; case 0x060B83A2u: goto L_060B83A2; case 0x060B83A4u: goto L_060B83A4; case 0x060B83A6u: goto L_060B83A6; case 0x060B83A8u: goto L_060B83A8; case 0x060B83AAu: goto L_060B83AA; case 0x060B83AEu: goto L_060B83AE; case 0x060B83B0u: goto L_060B83B0; case 0x060B83B2u: goto L_060B83B2; case 0x060B83B4u: goto L_060B83B4; case 0x060B83B8u: goto L_060B83B8; case 0x060B83BAu: goto L_060B83BA; case 0x060B83BCu: goto L_060B83BC; case 0x060B83BEu: goto L_060B83BE; case 0x060B83C0u: goto L_060B83C0; case 0x060B83C2u: goto L_060B83C2; case 0x060B83C4u: goto L_060B83C4; case 0x060B83C8u: goto L_060B83C8; case 0x060B83CAu: goto L_060B83CA; case 0x060B83CCu: goto L_060B83CC; case 0x060B83CEu: goto L_060B83CE; case 0x060B83D0u: goto L_060B83D0; case 0x060B83D2u: goto L_060B83D2; case 0x060B83D4u: goto L_060B83D4; case 0x060B83D8u: goto L_060B83D8; case 0x060B83DAu: goto L_060B83DA; case 0x060B83DCu: goto L_060B83DC; case 0x060B83DEu: goto L_060B83DE; case 0x060B83E0u: goto L_060B83E0; case 0x060B83E2u: goto L_060B83E2; case 0x060B83E4u: goto L_060B83E4; default: sh2_call(c, x); return; } }  // 060B83AA jmp @r0 ; nop
L_060B83AE:
    st32(c.r[11] + 12, c.r[5]);  // 060B83AE mov.l r5,@(12,r11)
L_060B83B0:
    st32(c.r[11] + 16, c.r[1]);  // 060B83B0 mov.l r1,@(16,r11)
L_060B83B2:
    st32(c.r[11] + 20, c.r[7]);  // 060B83B2 mov.l r7,@(20,r11)
L_060B83B4:
    { const uint32_t x = c.pr; st32(c.r[11] + 24, c.r[9]); c.pc = x; return; }  // 060B83B4 rts ; mov.l r9,@(24,r11)
L_060B83B8:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[11]);  // 060B83B8 mov.w @(0,r11),r0
L_060B83BA:
    st32(c.r[11] + 16, c.r[5]);  // 060B83BA mov.l r5,@(16,r11)
L_060B83BC:
    c.r[0] ^= 0x10u;  // 060B83BC xor #16,r0
L_060B83BE:
    st16(c.r[11], c.r[0]);  // 060B83BE mov.w r0,@(0,r11)
L_060B83C0:
    st32(c.r[11] + 12, c.r[1]);  // 060B83C0 mov.l r1,@(12,r11)
L_060B83C2:
    st32(c.r[11] + 24, c.r[7]);  // 060B83C2 mov.l r7,@(24,r11)
L_060B83C4:
    { const uint32_t x = c.pr; st32(c.r[11] + 20, c.r[9]); c.pc = x; return; }  // 060B83C4 rts ; mov.l r9,@(20,r11)
L_060B83C8:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[11]);  // 060B83C8 mov.w @(0,r11),r0
L_060B83CA:
    st32(c.r[11] + 20, c.r[5]);  // 060B83CA mov.l r5,@(20,r11)
L_060B83CC:
    c.r[0] ^= 0x30u;  // 060B83CC xor #48,r0
L_060B83CE:
    st16(c.r[11], c.r[0]);  // 060B83CE mov.w r0,@(0,r11)
L_060B83D0:
    st32(c.r[11] + 24, c.r[1]);  // 060B83D0 mov.l r1,@(24,r11)
L_060B83D2:
    st32(c.r[11] + 12, c.r[7]);  // 060B83D2 mov.l r7,@(12,r11)
L_060B83D4:
    { const uint32_t x = c.pr; st32(c.r[11] + 16, c.r[9]); c.pc = x; return; }  // 060B83D4 rts ; mov.l r9,@(16,r11)
L_060B83D8:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[11]);  // 060B83D8 mov.w @(0,r11),r0
L_060B83DA:
    st32(c.r[11] + 24, c.r[5]);  // 060B83DA mov.l r5,@(24,r11)
L_060B83DC:
    c.r[0] ^= 0x20u;  // 060B83DC xor #32,r0
L_060B83DE:
    st16(c.r[11], c.r[0]);  // 060B83DE mov.w r0,@(0,r11)
L_060B83E0:
    st32(c.r[11] + 20, c.r[1]);  // 060B83E0 mov.l r1,@(20,r11)
L_060B83E2:
    st32(c.r[11] + 16, c.r[7]);  // 060B83E2 mov.l r7,@(16,r11)
L_060B83E4:
    { const uint32_t x = c.pr; st32(c.r[11] + 12, c.r[9]); c.pc = x; return; }  // 060B83E4 rts ; mov.l r9,@(12,r11)
}

void f_060B815E(SH2Context& c) {
    ran[3160] = 1;
    goto L_060B815E;
L_060B8146:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[11] + 30);  // 060B8146 mov.w @(30,r11),r0
L_060B8148:
    c.r[1] = ld32(c.r[11] + 32);  // 060B8148 mov.l @(32,r11),r1
L_060B814A:
    c.r[2] = (c.r[0] & 0xFFFF0000u) | (c.r[0] & 0xFFu) << 8 | (c.r[0] >> 8 & 0xFFu);  // 060B814A swap.b r0,r2
L_060B814C:
    c.r[0] = ld32(c.gbr + 56);  // 060B814C mov.l @(56,gbr),r0
L_060B814E:
    c.r[2] = c.r[2] & 0xFFu;  // 060B814E extu.b r2,r2
L_060B8150:
    c.r[2] <<= 2;  // 060B8150 shll2 r2
L_060B8152:
    { const uint32_t x = c.pr; st32(c.r[0] + c.r[2], c.r[1]); c.pc = x; return; }  // 060B8152 rts ; mov.l r1,@(r0,r2)
L_060B815E:
    c.r[1] = 0x30u;  // 060B815E mov #48,r1
L_060B8160:
    c.r[3] = 0u - c.r[3];  // 060B8160 neg r3,r3
L_060B8162:
    c.r[7] = 0u - c.r[7]; goto L_060B8168;  // 060B8162 bra 0x060B8168 ; neg r7,r7
L_060B8168:
    c.r[2] = 0u - c.r[2];  // 060B8168 neg r2,r2
L_060B816A:
    c.r[6] = 0u - c.r[6];  // 060B816A neg r6,r6
L_060B816C:
    c.r[5] ^= c.r[1];  // 060B816C xor r1,r5
L_060B816E:
    st16(c.r[11], c.r[5]);  // 060B816E mov.w r5,@r11
L_060B8170:
    c.r[0] = c.r[8];  // 060B8170 mov r8,r0
L_060B8172:
    c.r[0] += c.r[10];  // 060B8172 add r10,r0
L_060B8174:
    c.t = c.r[0] > c.r[13];  // 060B8174 cmp/hi r13,r0
L_060B8176:
    { const bool k = c.t; c.r[4] += 32; if (k) { SH2_POLL(c); goto L_060B8146; } }  // 060B8176 bt/s 0x060B8146 ; add #32,r4
L_060B817A:
    c.r[0] = c.r[9];  // 060B817A mov r9,r0
L_060B817C:
    c.r[0] += c.r[12];  // 060B817C add r12,r0
L_060B817E:
    c.t = c.r[0] > c.r[14];  // 060B817E cmp/hi r14,r0
L_060B8180:
    { const bool k = c.t; c.r[0] = c.r[8] << 16 | c.r[8] >> 16; if (k) { SH2_POLL(c); goto L_060B8146; } }  // 060B8180 bt/s 0x060B8146 ; swap.w r8,r0
L_060B8184:
    c.r[5] = c.r[9];  // 060B8184 mov r9,r5
L_060B8186:
    c.r[5] = c.r[0] << 16 | c.r[5] >> 16;  // 060B8186 xtrct r0,r5
L_060B8188:
    c.r[8] += c.r[2];  // 060B8188 add r2,r8
L_060B818A:
    c.r[0] = c.r[8];  // 060B818A mov r8,r0
L_060B818C:
    c.r[0] += c.r[10];  // 060B818C add r10,r0
L_060B818E:
    c.t = c.r[0] > c.r[13];  // 060B818E cmp/hi r13,r0
L_060B8190:
    { const bool k = c.t; c.r[9] += c.r[6]; if (k) { SH2_POLL(c); goto L_060B8146; } }  // 060B8190 bt/s 0x060B8146 ; add r6,r9
L_060B8194:
    c.r[0] = c.r[9];  // 060B8194 mov r9,r0
L_060B8196:
    c.r[0] += c.r[12];  // 060B8196 add r12,r0
L_060B8198:
    c.t = c.r[0] > c.r[14];  // 060B8198 cmp/hi r14,r0
L_060B819A:
    { const bool k = c.t; c.r[0] = c.r[8] << 16 | c.r[8] >> 16; if (k) { SH2_POLL(c); goto L_060B8146; } }  // 060B819A bt/s 0x060B8146 ; swap.w r8,r0
L_060B819E:
    c.r[1] = c.r[9];  // 060B819E mov r9,r1
L_060B81A0:
    c.r[1] = c.r[0] << 16 | c.r[1] >> 16;  // 060B81A0 xtrct r0,r1
L_060B81A2:
    c.r[8] -= c.r[7];  // 060B81A2 sub r7,r8
L_060B81A4:
    c.r[0] = c.r[8];  // 060B81A4 mov r8,r0
L_060B81A6:
    c.r[0] += c.r[10];  // 060B81A6 add r10,r0
L_060B81A8:
    c.t = c.r[0] > c.r[13];  // 060B81A8 cmp/hi r13,r0
L_060B81AA:
    { const bool k = c.t; c.r[9] += c.r[3]; if (k) { SH2_POLL(c); goto L_060B8146; } }  // 060B81AA bt/s 0x060B8146 ; add r3,r9
L_060B81AE:
    c.r[0] = c.r[9];  // 060B81AE mov r9,r0
L_060B81B0:
    c.r[0] += c.r[12];  // 060B81B0 add r12,r0
L_060B81B2:
    c.t = c.r[0] > c.r[14];  // 060B81B2 cmp/hi r14,r0
L_060B81B4:
    { const bool k = c.t; c.r[3] = c.r[8] << 16 | c.r[8] >> 16; if (k) { SH2_POLL(c); goto L_060B8146; } }  // 060B81B4 bt/s 0x060B8146 ; swap.w r8,r3
L_060B81B8:
    c.r[8] -= c.r[2];  // 060B81B8 sub r2,r8
L_060B81BA:
    c.r[10] += c.r[8];  // 060B81BA add r8,r10
L_060B81BC:
    c.t = c.r[10] > c.r[13];  // 060B81BC cmp/hi r13,r10
L_060B81BE:
    { const bool k = c.t; c.r[7] = c.r[9]; if (k) { SH2_POLL(c); goto L_060B8146; } }  // 060B81BE bt/s 0x060B8146 ; mov r9,r7
L_060B81C2:
    c.r[9] -= c.r[6];  // 060B81C2 sub r6,r9
L_060B81C4:
    c.r[12] += c.r[9];  // 060B81C4 add r9,r12
L_060B81C6:
    c.t = c.r[12] > c.r[14];  // 060B81C6 cmp/hi r14,r12
L_060B81C8:
    { const bool k = c.t; c.r[7] = c.r[3] << 16 | c.r[7] >> 16; if (k) { SH2_POLL(c); goto L_060B8146; } }  // 060B81C8 bt/s 0x060B8146 ; xtrct r3,r7
L_060B81CC:
    c.r[8] = c.r[8] << 16 | c.r[8] >> 16; goto L_060B82D8;  // 060B81CC bra 0x060B82D8 ; swap.w r8,r8
L_060B82D8:
    c.r[0] = c.r[11];  // 060B82D8 mov r11,r0
L_060B82DA:
    c.r[0] += 36;  // 060B82DA add #36,r0
L_060B82DC:
    st32(c.gbr + 52, c.r[0]);  // 060B82DC mov.l r0,@(52,gbr)
L_060B82DE:
    c.r[0] = ld32(c.gbr + 148);  // 060B82DE mov.l @(148,gbr),r0
L_060B82E0:
    c.r[3] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B82E0 exts.w r0,r3
L_060B82E2:
    c.r[2] = c.r[0] << 16 | c.r[0] >> 16;  // 060B82E2 swap.w r0,r2
L_060B82E4:
    c.r[0] = ld32(c.gbr + 816);  // 060B82E4 mov.l @(816,gbr),r0
L_060B82E6:
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 060B82E6 exts.w r2,r2
L_060B82E8:
    c.r[13] = c.r[0] & 0xFFFFu;  // 060B82E8 extu.w r0,r13
L_060B82EA:
    c.r[12] = c.r[0] << 16 | c.r[0] >> 16;  // 060B82EA swap.w r0,r12
L_060B82EC:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B82EC extu.w r12,r12
L_060B82EE:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[5];  // 060B82EE exts.w r5,r0
L_060B82F0:
    c.r[0] += c.r[3];  // 060B82F0 add r3,r0
L_060B82F2:
    c.t = c.r[0] >= c.r[13];  // 060B82F2 cmp/hs r13,r0
L_060B82F4:
    { const bool k = c.t; c.r[9] = c.r[8] << 16 | c.r[9] >> 16; if (k) { goto L_060B8302; } }  // 060B82F4 bt/s 0x060B8302 ; xtrct r8,r9
L_060B82F8:
    c.r[0] = c.r[5] << 16 | c.r[5] >> 16;  // 060B82F8 swap.w r5,r0
L_060B82FA:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B82FA exts.w r0,r0
L_060B82FC:
    c.r[0] += c.r[2];  // 060B82FC add r2,r0
L_060B82FE:
    c.t = c.r[12] > c.r[0];  // 060B82FE cmp/hi r0,r12
L_060B8300:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[1]; if (k) { goto L_060B83AE; } }  // 060B8300 bt/s 0x060B83AE ; exts.w r1,r0
    goto L_060B8304;
L_060B8302:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 060B8302 exts.w r1,r0
L_060B8304:
    c.r[0] += c.r[3];  // 060B8304 add r3,r0
L_060B8306:
    c.t = c.r[0] >= c.r[13];  // 060B8306 cmp/hs r13,r0
L_060B8308:
    { const bool k = c.t; c.r[0] = c.r[1] << 16 | c.r[1] >> 16; if (k) { goto L_060B8314; } }  // 060B8308 bt/s 0x060B8314 ; swap.w r1,r0
L_060B830C:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B830C exts.w r0,r0
L_060B830E:
    c.r[0] += c.r[2];  // 060B830E add r2,r0
L_060B8310:
    c.t = c.r[12] > c.r[0];  // 060B8310 cmp/hi r0,r12
L_060B8312:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[7]; if (k) { goto L_060B83B8; } }  // 060B8312 bt/s 0x060B83B8 ; exts.w r7,r0
    goto L_060B8316;
L_060B8314:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[7];  // 060B8314 exts.w r7,r0
L_060B8316:
    c.r[0] += c.r[3];  // 060B8316 add r3,r0
L_060B8318:
    c.t = c.r[0] >= c.r[13];  // 060B8318 cmp/hs r13,r0
L_060B831A:
    { const bool k = c.t; c.r[0] = c.r[7] << 16 | c.r[7] >> 16; if (k) { goto L_060B8326; } }  // 060B831A bt/s 0x060B8326 ; swap.w r7,r0
L_060B831E:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B831E exts.w r0,r0
L_060B8320:
    c.r[0] += c.r[2];  // 060B8320 add r2,r0
L_060B8322:
    c.t = c.r[12] > c.r[0];  // 060B8322 cmp/hi r0,r12
L_060B8324:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[9]; if (k) { goto L_060B83C8; } }  // 060B8324 bt/s 0x060B83C8 ; exts.w r9,r0
    goto L_060B8328;
L_060B8326:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[9];  // 060B8326 exts.w r9,r0
L_060B8328:
    c.r[0] += c.r[3];  // 060B8328 add r3,r0
L_060B832A:
    c.t = c.r[0] >= c.r[13];  // 060B832A cmp/hs r13,r0
L_060B832C:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[8]; if (k) { goto L_060B8336; } }  // 060B832C bt/s 0x060B8336 ; exts.w r8,r0
L_060B8330:
    c.r[0] += c.r[2];  // 060B8330 add r2,r0
L_060B8332:
    c.t = c.r[12] > c.r[0];  // 060B8332 cmp/hi r0,r12
L_060B8334:
    { const bool k = c.t; c.r[8] = 0x1u; if (k) { goto L_060B83D8; } }  // 060B8334 bt/s 0x060B83D8 ; mov #1,r8
    goto L_060B8338;
L_060B8336:
    c.r[8] = 0x1u;  // 060B8336 mov #1,r8
L_060B8338:
    c.r[8] <<= 16;  // 060B8338 shll16 r8
L_060B833A:
    c.t = c.r[8] & 1; c.r[8] >>= 1;  // 060B833A shlr r8
L_060B833C:
    c.r[2] = c.r[9] << 16 | c.r[9] >> 16;  // 060B833C swap.w r9,r2
L_060B833E:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B833E tst r8,r2
L_060B8340:
    { uint32_t a = c.r[13], b = c.r[13], t = c.t; c.r[13] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B8340 subc r13,r13
L_060B8342:
    c.r[13] = ~c.r[13];  // 060B8342 not r13,r13
L_060B8344:
    c.r[13] ^= c.r[2];  // 060B8344 xor r2,r13
L_060B8346:
    c.t = (c.r[9] & c.r[8]) == 0;  // 060B8346 tst r8,r9
L_060B8348:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B8348 subc r2,r2
L_060B834A:
    c.r[2] = ~c.r[2];  // 060B834A not r2,r2
L_060B834C:
    c.r[2] ^= c.r[9];  // 060B834C xor r9,r2
L_060B834E:
    c.r[13] += c.r[2];  // 060B834E add r2,r13
L_060B8350:
    c.r[13] = c.r[13] & 0xFFFFu;  // 060B8350 extu.w r13,r13
L_060B8352:
    c.r[0] = 0x060B83D8u;  // 060B8352 mova 0x060B83D8,r0
L_060B8354:
    c.r[2] = c.r[7] << 16 | c.r[7] >> 16;  // 060B8354 swap.w r7,r2
L_060B8356:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B8356 tst r8,r2
L_060B8358:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B8358 subc r12,r12
L_060B835A:
    c.r[12] = ~c.r[12];  // 060B835A not r12,r12
L_060B835C:
    c.r[12] ^= c.r[2];  // 060B835C xor r2,r12
L_060B835E:
    c.t = (c.r[7] & c.r[8]) == 0;  // 060B835E tst r8,r7
L_060B8360:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B8360 subc r2,r2
L_060B8362:
    c.r[2] = ~c.r[2];  // 060B8362 not r2,r2
L_060B8364:
    c.r[2] ^= c.r[7];  // 060B8364 xor r7,r2
L_060B8366:
    c.r[12] += c.r[2];  // 060B8366 add r2,r12
L_060B8368:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B8368 extu.w r12,r12
L_060B836A:
    c.t = (int32_t)c.r[12] > (int32_t)c.r[13];  // 060B836A cmp/gt r13,r12
L_060B836C:
    { const bool k = c.t; c.r[2] = c.r[1] << 16 | c.r[1] >> 16; if (k) { goto L_060B8374; } }  // 060B836C bt/s 0x060B8374 ; swap.w r1,r2
L_060B8370:
    c.r[13] = c.r[12];  // 060B8370 mov r12,r13
L_060B8372:
    c.r[0] = 0x060B83C8u;  // 060B8372 mova 0x060B83C8,r0
L_060B8374:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B8374 tst r8,r2
L_060B8376:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B8376 subc r12,r12
L_060B8378:
    c.r[12] = ~c.r[12];  // 060B8378 not r12,r12
L_060B837A:
    c.r[12] ^= c.r[2];  // 060B837A xor r2,r12
L_060B837C:
    c.t = (c.r[1] & c.r[8]) == 0;  // 060B837C tst r8,r1
L_060B837E:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B837E subc r2,r2
L_060B8380:
    c.r[2] = ~c.r[2];  // 060B8380 not r2,r2
L_060B8382:
    c.r[2] ^= c.r[1];  // 060B8382 xor r1,r2
L_060B8384:
    c.r[12] += c.r[2];  // 060B8384 add r2,r12
L_060B8386:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B8386 extu.w r12,r12
L_060B8388:
    c.t = (int32_t)c.r[12] > (int32_t)c.r[13];  // 060B8388 cmp/gt r13,r12
L_060B838A:
    { const bool k = c.t; c.r[2] = c.r[5] << 16 | c.r[5] >> 16; if (k) { goto L_060B8392; } }  // 060B838A bt/s 0x060B8392 ; swap.w r5,r2
L_060B838E:
    c.r[13] = c.r[12];  // 060B838E mov r12,r13
L_060B8390:
    c.r[0] = 0x060B83C8u;  // 060B8390 mova 0x060B83C8,r0
L_060B8392:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B8392 tst r8,r2
L_060B8394:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B8394 subc r12,r12
L_060B8396:
    c.r[12] = ~c.r[12];  // 060B8396 not r12,r12
L_060B8398:
    c.r[12] ^= c.r[2];  // 060B8398 xor r2,r12
L_060B839A:
    c.t = (c.r[5] & c.r[8]) == 0;  // 060B839A tst r8,r5
L_060B839C:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B839C subc r2,r2
L_060B839E:
    c.r[2] = ~c.r[2];  // 060B839E not r2,r2
L_060B83A0:
    c.r[2] ^= c.r[5];  // 060B83A0 xor r5,r2
L_060B83A2:
    c.r[12] += c.r[2];  // 060B83A2 add r2,r12
L_060B83A4:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B83A4 extu.w r12,r12
L_060B83A6:
    c.t = (int32_t)c.r[13] >= (int32_t)c.r[12];  // 060B83A6 cmp/ge r12,r13
L_060B83A8:
    if (c.t) { goto L_060B83AE; }  // 060B83A8 bt 0x060B83AE
L_060B83AA:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x060B8146u: goto L_060B8146; case 0x060B8148u: goto L_060B8148; case 0x060B814Au: goto L_060B814A; case 0x060B814Cu: goto L_060B814C; case 0x060B814Eu: goto L_060B814E; case 0x060B8150u: goto L_060B8150; case 0x060B8152u: goto L_060B8152; case 0x060B815Eu: goto L_060B815E; case 0x060B8160u: goto L_060B8160; case 0x060B8162u: goto L_060B8162; case 0x060B8168u: goto L_060B8168; case 0x060B816Au: goto L_060B816A; case 0x060B816Cu: goto L_060B816C; case 0x060B816Eu: goto L_060B816E; case 0x060B8170u: goto L_060B8170; case 0x060B8172u: goto L_060B8172; case 0x060B8174u: goto L_060B8174; case 0x060B8176u: goto L_060B8176; case 0x060B817Au: goto L_060B817A; case 0x060B817Cu: goto L_060B817C; case 0x060B817Eu: goto L_060B817E; case 0x060B8180u: goto L_060B8180; case 0x060B8184u: goto L_060B8184; case 0x060B8186u: goto L_060B8186; case 0x060B8188u: goto L_060B8188; case 0x060B818Au: goto L_060B818A; case 0x060B818Cu: goto L_060B818C; case 0x060B818Eu: goto L_060B818E; case 0x060B8190u: goto L_060B8190; case 0x060B8194u: goto L_060B8194; case 0x060B8196u: goto L_060B8196; case 0x060B8198u: goto L_060B8198; case 0x060B819Au: goto L_060B819A; case 0x060B819Eu: goto L_060B819E; case 0x060B81A0u: goto L_060B81A0; case 0x060B81A2u: goto L_060B81A2; case 0x060B81A4u: goto L_060B81A4; case 0x060B81A6u: goto L_060B81A6; case 0x060B81A8u: goto L_060B81A8; case 0x060B81AAu: goto L_060B81AA; case 0x060B81AEu: goto L_060B81AE; case 0x060B81B0u: goto L_060B81B0; case 0x060B81B2u: goto L_060B81B2; case 0x060B81B4u: goto L_060B81B4; case 0x060B81B8u: goto L_060B81B8; case 0x060B81BAu: goto L_060B81BA; case 0x060B81BCu: goto L_060B81BC; case 0x060B81BEu: goto L_060B81BE; case 0x060B81C2u: goto L_060B81C2; case 0x060B81C4u: goto L_060B81C4; case 0x060B81C6u: goto L_060B81C6; case 0x060B81C8u: goto L_060B81C8; case 0x060B81CCu: goto L_060B81CC; case 0x060B82D8u: goto L_060B82D8; case 0x060B82DAu: goto L_060B82DA; case 0x060B82DCu: goto L_060B82DC; case 0x060B82DEu: goto L_060B82DE; case 0x060B82E0u: goto L_060B82E0; case 0x060B82E2u: goto L_060B82E2; case 0x060B82E4u: goto L_060B82E4; case 0x060B82E6u: goto L_060B82E6; case 0x060B82E8u: goto L_060B82E8; case 0x060B82EAu: goto L_060B82EA; case 0x060B82ECu: goto L_060B82EC; case 0x060B82EEu: goto L_060B82EE; case 0x060B82F0u: goto L_060B82F0; case 0x060B82F2u: goto L_060B82F2; case 0x060B82F4u: goto L_060B82F4; case 0x060B82F8u: goto L_060B82F8; case 0x060B82FAu: goto L_060B82FA; case 0x060B82FCu: goto L_060B82FC; case 0x060B82FEu: goto L_060B82FE; case 0x060B8300u: goto L_060B8300; case 0x060B8304u: goto L_060B8304; case 0x060B8306u: goto L_060B8306; case 0x060B8308u: goto L_060B8308; case 0x060B830Cu: goto L_060B830C; case 0x060B830Eu: goto L_060B830E; case 0x060B8310u: goto L_060B8310; case 0x060B8312u: goto L_060B8312; case 0x060B8316u: goto L_060B8316; case 0x060B8318u: goto L_060B8318; case 0x060B831Au: goto L_060B831A; case 0x060B831Eu: goto L_060B831E; case 0x060B8320u: goto L_060B8320; case 0x060B8322u: goto L_060B8322; case 0x060B8324u: goto L_060B8324; case 0x060B8328u: goto L_060B8328; case 0x060B832Au: goto L_060B832A; case 0x060B832Cu: goto L_060B832C; case 0x060B8330u: goto L_060B8330; case 0x060B8332u: goto L_060B8332; case 0x060B8334u: goto L_060B8334; case 0x060B8338u: goto L_060B8338; case 0x060B833Au: goto L_060B833A; case 0x060B833Cu: goto L_060B833C; case 0x060B833Eu: goto L_060B833E; case 0x060B8340u: goto L_060B8340; case 0x060B8342u: goto L_060B8342; case 0x060B8344u: goto L_060B8344; case 0x060B8346u: goto L_060B8346; case 0x060B8348u: goto L_060B8348; case 0x060B834Au: goto L_060B834A; case 0x060B834Cu: goto L_060B834C; case 0x060B834Eu: goto L_060B834E; case 0x060B8350u: goto L_060B8350; case 0x060B8352u: goto L_060B8352; case 0x060B8354u: goto L_060B8354; case 0x060B8356u: goto L_060B8356; case 0x060B8358u: goto L_060B8358; case 0x060B835Au: goto L_060B835A; case 0x060B835Cu: goto L_060B835C; case 0x060B835Eu: goto L_060B835E; case 0x060B8360u: goto L_060B8360; case 0x060B8362u: goto L_060B8362; case 0x060B8364u: goto L_060B8364; case 0x060B8366u: goto L_060B8366; case 0x060B8368u: goto L_060B8368; case 0x060B836Au: goto L_060B836A; case 0x060B836Cu: goto L_060B836C; case 0x060B8370u: goto L_060B8370; case 0x060B8372u: goto L_060B8372; case 0x060B8374u: goto L_060B8374; case 0x060B8376u: goto L_060B8376; case 0x060B8378u: goto L_060B8378; case 0x060B837Au: goto L_060B837A; case 0x060B837Cu: goto L_060B837C; case 0x060B837Eu: goto L_060B837E; case 0x060B8380u: goto L_060B8380; case 0x060B8382u: goto L_060B8382; case 0x060B8384u: goto L_060B8384; case 0x060B8386u: goto L_060B8386; case 0x060B8388u: goto L_060B8388; case 0x060B838Au: goto L_060B838A; case 0x060B838Eu: goto L_060B838E; case 0x060B8390u: goto L_060B8390; case 0x060B8392u: goto L_060B8392; case 0x060B8394u: goto L_060B8394; case 0x060B8396u: goto L_060B8396; case 0x060B8398u: goto L_060B8398; case 0x060B839Au: goto L_060B839A; case 0x060B839Cu: goto L_060B839C; case 0x060B839Eu: goto L_060B839E; case 0x060B83A0u: goto L_060B83A0; case 0x060B83A2u: goto L_060B83A2; case 0x060B83A4u: goto L_060B83A4; case 0x060B83A6u: goto L_060B83A6; case 0x060B83A8u: goto L_060B83A8; case 0x060B83AAu: goto L_060B83AA; case 0x060B83AEu: goto L_060B83AE; case 0x060B83B0u: goto L_060B83B0; case 0x060B83B2u: goto L_060B83B2; case 0x060B83B4u: goto L_060B83B4; case 0x060B83B8u: goto L_060B83B8; case 0x060B83BAu: goto L_060B83BA; case 0x060B83BCu: goto L_060B83BC; case 0x060B83BEu: goto L_060B83BE; case 0x060B83C0u: goto L_060B83C0; case 0x060B83C2u: goto L_060B83C2; case 0x060B83C4u: goto L_060B83C4; case 0x060B83C8u: goto L_060B83C8; case 0x060B83CAu: goto L_060B83CA; case 0x060B83CCu: goto L_060B83CC; case 0x060B83CEu: goto L_060B83CE; case 0x060B83D0u: goto L_060B83D0; case 0x060B83D2u: goto L_060B83D2; case 0x060B83D4u: goto L_060B83D4; case 0x060B83D8u: goto L_060B83D8; case 0x060B83DAu: goto L_060B83DA; case 0x060B83DCu: goto L_060B83DC; case 0x060B83DEu: goto L_060B83DE; case 0x060B83E0u: goto L_060B83E0; case 0x060B83E2u: goto L_060B83E2; case 0x060B83E4u: goto L_060B83E4; default: sh2_call(c, x); return; } }  // 060B83AA jmp @r0 ; nop
L_060B83AE:
    st32(c.r[11] + 12, c.r[5]);  // 060B83AE mov.l r5,@(12,r11)
L_060B83B0:
    st32(c.r[11] + 16, c.r[1]);  // 060B83B0 mov.l r1,@(16,r11)
L_060B83B2:
    st32(c.r[11] + 20, c.r[7]);  // 060B83B2 mov.l r7,@(20,r11)
L_060B83B4:
    { const uint32_t x = c.pr; st32(c.r[11] + 24, c.r[9]); c.pc = x; return; }  // 060B83B4 rts ; mov.l r9,@(24,r11)
L_060B83B8:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[11]);  // 060B83B8 mov.w @(0,r11),r0
L_060B83BA:
    st32(c.r[11] + 16, c.r[5]);  // 060B83BA mov.l r5,@(16,r11)
L_060B83BC:
    c.r[0] ^= 0x10u;  // 060B83BC xor #16,r0
L_060B83BE:
    st16(c.r[11], c.r[0]);  // 060B83BE mov.w r0,@(0,r11)
L_060B83C0:
    st32(c.r[11] + 12, c.r[1]);  // 060B83C0 mov.l r1,@(12,r11)
L_060B83C2:
    st32(c.r[11] + 24, c.r[7]);  // 060B83C2 mov.l r7,@(24,r11)
L_060B83C4:
    { const uint32_t x = c.pr; st32(c.r[11] + 20, c.r[9]); c.pc = x; return; }  // 060B83C4 rts ; mov.l r9,@(20,r11)
L_060B83C8:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[11]);  // 060B83C8 mov.w @(0,r11),r0
L_060B83CA:
    st32(c.r[11] + 20, c.r[5]);  // 060B83CA mov.l r5,@(20,r11)
L_060B83CC:
    c.r[0] ^= 0x30u;  // 060B83CC xor #48,r0
L_060B83CE:
    st16(c.r[11], c.r[0]);  // 060B83CE mov.w r0,@(0,r11)
L_060B83D0:
    st32(c.r[11] + 24, c.r[1]);  // 060B83D0 mov.l r1,@(24,r11)
L_060B83D2:
    st32(c.r[11] + 12, c.r[7]);  // 060B83D2 mov.l r7,@(12,r11)
L_060B83D4:
    { const uint32_t x = c.pr; st32(c.r[11] + 16, c.r[9]); c.pc = x; return; }  // 060B83D4 rts ; mov.l r9,@(16,r11)
L_060B83D8:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[11]);  // 060B83D8 mov.w @(0,r11),r0
L_060B83DA:
    st32(c.r[11] + 24, c.r[5]);  // 060B83DA mov.l r5,@(24,r11)
L_060B83DC:
    c.r[0] ^= 0x20u;  // 060B83DC xor #32,r0
L_060B83DE:
    st16(c.r[11], c.r[0]);  // 060B83DE mov.w r0,@(0,r11)
L_060B83E0:
    st32(c.r[11] + 20, c.r[1]);  // 060B83E0 mov.l r1,@(20,r11)
L_060B83E2:
    st32(c.r[11] + 16, c.r[7]);  // 060B83E2 mov.l r7,@(16,r11)
L_060B83E4:
    { const uint32_t x = c.pr; st32(c.r[11] + 12, c.r[9]); c.pc = x; return; }  // 060B83E4 rts ; mov.l r9,@(12,r11)
}

void f_060B8166(SH2Context& c) {
    ran[3161] = 1;
    goto L_060B8166;
L_060B8146:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[11] + 30);  // 060B8146 mov.w @(30,r11),r0
L_060B8148:
    c.r[1] = ld32(c.r[11] + 32);  // 060B8148 mov.l @(32,r11),r1
L_060B814A:
    c.r[2] = (c.r[0] & 0xFFFF0000u) | (c.r[0] & 0xFFu) << 8 | (c.r[0] >> 8 & 0xFFu);  // 060B814A swap.b r0,r2
L_060B814C:
    c.r[0] = ld32(c.gbr + 56);  // 060B814C mov.l @(56,gbr),r0
L_060B814E:
    c.r[2] = c.r[2] & 0xFFu;  // 060B814E extu.b r2,r2
L_060B8150:
    c.r[2] <<= 2;  // 060B8150 shll2 r2
L_060B8152:
    { const uint32_t x = c.pr; st32(c.r[0] + c.r[2], c.r[1]); c.pc = x; return; }  // 060B8152 rts ; mov.l r1,@(r0,r2)
L_060B8166:
    c.r[1] = 0x10u;  // 060B8166 mov #16,r1
L_060B8168:
    c.r[2] = 0u - c.r[2];  // 060B8168 neg r2,r2
L_060B816A:
    c.r[6] = 0u - c.r[6];  // 060B816A neg r6,r6
L_060B816C:
    c.r[5] ^= c.r[1];  // 060B816C xor r1,r5
L_060B816E:
    st16(c.r[11], c.r[5]);  // 060B816E mov.w r5,@r11
L_060B8170:
    c.r[0] = c.r[8];  // 060B8170 mov r8,r0
L_060B8172:
    c.r[0] += c.r[10];  // 060B8172 add r10,r0
L_060B8174:
    c.t = c.r[0] > c.r[13];  // 060B8174 cmp/hi r13,r0
L_060B8176:
    { const bool k = c.t; c.r[4] += 32; if (k) { SH2_POLL(c); goto L_060B8146; } }  // 060B8176 bt/s 0x060B8146 ; add #32,r4
L_060B817A:
    c.r[0] = c.r[9];  // 060B817A mov r9,r0
L_060B817C:
    c.r[0] += c.r[12];  // 060B817C add r12,r0
L_060B817E:
    c.t = c.r[0] > c.r[14];  // 060B817E cmp/hi r14,r0
L_060B8180:
    { const bool k = c.t; c.r[0] = c.r[8] << 16 | c.r[8] >> 16; if (k) { SH2_POLL(c); goto L_060B8146; } }  // 060B8180 bt/s 0x060B8146 ; swap.w r8,r0
L_060B8184:
    c.r[5] = c.r[9];  // 060B8184 mov r9,r5
L_060B8186:
    c.r[5] = c.r[0] << 16 | c.r[5] >> 16;  // 060B8186 xtrct r0,r5
L_060B8188:
    c.r[8] += c.r[2];  // 060B8188 add r2,r8
L_060B818A:
    c.r[0] = c.r[8];  // 060B818A mov r8,r0
L_060B818C:
    c.r[0] += c.r[10];  // 060B818C add r10,r0
L_060B818E:
    c.t = c.r[0] > c.r[13];  // 060B818E cmp/hi r13,r0
L_060B8190:
    { const bool k = c.t; c.r[9] += c.r[6]; if (k) { SH2_POLL(c); goto L_060B8146; } }  // 060B8190 bt/s 0x060B8146 ; add r6,r9
L_060B8194:
    c.r[0] = c.r[9];  // 060B8194 mov r9,r0
L_060B8196:
    c.r[0] += c.r[12];  // 060B8196 add r12,r0
L_060B8198:
    c.t = c.r[0] > c.r[14];  // 060B8198 cmp/hi r14,r0
L_060B819A:
    { const bool k = c.t; c.r[0] = c.r[8] << 16 | c.r[8] >> 16; if (k) { SH2_POLL(c); goto L_060B8146; } }  // 060B819A bt/s 0x060B8146 ; swap.w r8,r0
L_060B819E:
    c.r[1] = c.r[9];  // 060B819E mov r9,r1
L_060B81A0:
    c.r[1] = c.r[0] << 16 | c.r[1] >> 16;  // 060B81A0 xtrct r0,r1
L_060B81A2:
    c.r[8] -= c.r[7];  // 060B81A2 sub r7,r8
L_060B81A4:
    c.r[0] = c.r[8];  // 060B81A4 mov r8,r0
L_060B81A6:
    c.r[0] += c.r[10];  // 060B81A6 add r10,r0
L_060B81A8:
    c.t = c.r[0] > c.r[13];  // 060B81A8 cmp/hi r13,r0
L_060B81AA:
    { const bool k = c.t; c.r[9] += c.r[3]; if (k) { SH2_POLL(c); goto L_060B8146; } }  // 060B81AA bt/s 0x060B8146 ; add r3,r9
L_060B81AE:
    c.r[0] = c.r[9];  // 060B81AE mov r9,r0
L_060B81B0:
    c.r[0] += c.r[12];  // 060B81B0 add r12,r0
L_060B81B2:
    c.t = c.r[0] > c.r[14];  // 060B81B2 cmp/hi r14,r0
L_060B81B4:
    { const bool k = c.t; c.r[3] = c.r[8] << 16 | c.r[8] >> 16; if (k) { SH2_POLL(c); goto L_060B8146; } }  // 060B81B4 bt/s 0x060B8146 ; swap.w r8,r3
L_060B81B8:
    c.r[8] -= c.r[2];  // 060B81B8 sub r2,r8
L_060B81BA:
    c.r[10] += c.r[8];  // 060B81BA add r8,r10
L_060B81BC:
    c.t = c.r[10] > c.r[13];  // 060B81BC cmp/hi r13,r10
L_060B81BE:
    { const bool k = c.t; c.r[7] = c.r[9]; if (k) { SH2_POLL(c); goto L_060B8146; } }  // 060B81BE bt/s 0x060B8146 ; mov r9,r7
L_060B81C2:
    c.r[9] -= c.r[6];  // 060B81C2 sub r6,r9
L_060B81C4:
    c.r[12] += c.r[9];  // 060B81C4 add r9,r12
L_060B81C6:
    c.t = c.r[12] > c.r[14];  // 060B81C6 cmp/hi r14,r12
L_060B81C8:
    { const bool k = c.t; c.r[7] = c.r[3] << 16 | c.r[7] >> 16; if (k) { SH2_POLL(c); goto L_060B8146; } }  // 060B81C8 bt/s 0x060B8146 ; xtrct r3,r7
L_060B81CC:
    c.r[8] = c.r[8] << 16 | c.r[8] >> 16; goto L_060B82D8;  // 060B81CC bra 0x060B82D8 ; swap.w r8,r8
L_060B82D8:
    c.r[0] = c.r[11];  // 060B82D8 mov r11,r0
L_060B82DA:
    c.r[0] += 36;  // 060B82DA add #36,r0
L_060B82DC:
    st32(c.gbr + 52, c.r[0]);  // 060B82DC mov.l r0,@(52,gbr)
L_060B82DE:
    c.r[0] = ld32(c.gbr + 148);  // 060B82DE mov.l @(148,gbr),r0
L_060B82E0:
    c.r[3] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B82E0 exts.w r0,r3
L_060B82E2:
    c.r[2] = c.r[0] << 16 | c.r[0] >> 16;  // 060B82E2 swap.w r0,r2
L_060B82E4:
    c.r[0] = ld32(c.gbr + 816);  // 060B82E4 mov.l @(816,gbr),r0
L_060B82E6:
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 060B82E6 exts.w r2,r2
L_060B82E8:
    c.r[13] = c.r[0] & 0xFFFFu;  // 060B82E8 extu.w r0,r13
L_060B82EA:
    c.r[12] = c.r[0] << 16 | c.r[0] >> 16;  // 060B82EA swap.w r0,r12
L_060B82EC:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B82EC extu.w r12,r12
L_060B82EE:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[5];  // 060B82EE exts.w r5,r0
L_060B82F0:
    c.r[0] += c.r[3];  // 060B82F0 add r3,r0
L_060B82F2:
    c.t = c.r[0] >= c.r[13];  // 060B82F2 cmp/hs r13,r0
L_060B82F4:
    { const bool k = c.t; c.r[9] = c.r[8] << 16 | c.r[9] >> 16; if (k) { goto L_060B8302; } }  // 060B82F4 bt/s 0x060B8302 ; xtrct r8,r9
L_060B82F8:
    c.r[0] = c.r[5] << 16 | c.r[5] >> 16;  // 060B82F8 swap.w r5,r0
L_060B82FA:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B82FA exts.w r0,r0
L_060B82FC:
    c.r[0] += c.r[2];  // 060B82FC add r2,r0
L_060B82FE:
    c.t = c.r[12] > c.r[0];  // 060B82FE cmp/hi r0,r12
L_060B8300:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[1]; if (k) { goto L_060B83AE; } }  // 060B8300 bt/s 0x060B83AE ; exts.w r1,r0
    goto L_060B8304;
L_060B8302:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 060B8302 exts.w r1,r0
L_060B8304:
    c.r[0] += c.r[3];  // 060B8304 add r3,r0
L_060B8306:
    c.t = c.r[0] >= c.r[13];  // 060B8306 cmp/hs r13,r0
L_060B8308:
    { const bool k = c.t; c.r[0] = c.r[1] << 16 | c.r[1] >> 16; if (k) { goto L_060B8314; } }  // 060B8308 bt/s 0x060B8314 ; swap.w r1,r0
L_060B830C:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B830C exts.w r0,r0
L_060B830E:
    c.r[0] += c.r[2];  // 060B830E add r2,r0
L_060B8310:
    c.t = c.r[12] > c.r[0];  // 060B8310 cmp/hi r0,r12
L_060B8312:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[7]; if (k) { goto L_060B83B8; } }  // 060B8312 bt/s 0x060B83B8 ; exts.w r7,r0
    goto L_060B8316;
L_060B8314:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[7];  // 060B8314 exts.w r7,r0
L_060B8316:
    c.r[0] += c.r[3];  // 060B8316 add r3,r0
L_060B8318:
    c.t = c.r[0] >= c.r[13];  // 060B8318 cmp/hs r13,r0
L_060B831A:
    { const bool k = c.t; c.r[0] = c.r[7] << 16 | c.r[7] >> 16; if (k) { goto L_060B8326; } }  // 060B831A bt/s 0x060B8326 ; swap.w r7,r0
L_060B831E:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B831E exts.w r0,r0
L_060B8320:
    c.r[0] += c.r[2];  // 060B8320 add r2,r0
L_060B8322:
    c.t = c.r[12] > c.r[0];  // 060B8322 cmp/hi r0,r12
L_060B8324:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[9]; if (k) { goto L_060B83C8; } }  // 060B8324 bt/s 0x060B83C8 ; exts.w r9,r0
    goto L_060B8328;
L_060B8326:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[9];  // 060B8326 exts.w r9,r0
L_060B8328:
    c.r[0] += c.r[3];  // 060B8328 add r3,r0
L_060B832A:
    c.t = c.r[0] >= c.r[13];  // 060B832A cmp/hs r13,r0
L_060B832C:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[8]; if (k) { goto L_060B8336; } }  // 060B832C bt/s 0x060B8336 ; exts.w r8,r0
L_060B8330:
    c.r[0] += c.r[2];  // 060B8330 add r2,r0
L_060B8332:
    c.t = c.r[12] > c.r[0];  // 060B8332 cmp/hi r0,r12
L_060B8334:
    { const bool k = c.t; c.r[8] = 0x1u; if (k) { goto L_060B83D8; } }  // 060B8334 bt/s 0x060B83D8 ; mov #1,r8
    goto L_060B8338;
L_060B8336:
    c.r[8] = 0x1u;  // 060B8336 mov #1,r8
L_060B8338:
    c.r[8] <<= 16;  // 060B8338 shll16 r8
L_060B833A:
    c.t = c.r[8] & 1; c.r[8] >>= 1;  // 060B833A shlr r8
L_060B833C:
    c.r[2] = c.r[9] << 16 | c.r[9] >> 16;  // 060B833C swap.w r9,r2
L_060B833E:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B833E tst r8,r2
L_060B8340:
    { uint32_t a = c.r[13], b = c.r[13], t = c.t; c.r[13] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B8340 subc r13,r13
L_060B8342:
    c.r[13] = ~c.r[13];  // 060B8342 not r13,r13
L_060B8344:
    c.r[13] ^= c.r[2];  // 060B8344 xor r2,r13
L_060B8346:
    c.t = (c.r[9] & c.r[8]) == 0;  // 060B8346 tst r8,r9
L_060B8348:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B8348 subc r2,r2
L_060B834A:
    c.r[2] = ~c.r[2];  // 060B834A not r2,r2
L_060B834C:
    c.r[2] ^= c.r[9];  // 060B834C xor r9,r2
L_060B834E:
    c.r[13] += c.r[2];  // 060B834E add r2,r13
L_060B8350:
    c.r[13] = c.r[13] & 0xFFFFu;  // 060B8350 extu.w r13,r13
L_060B8352:
    c.r[0] = 0x060B83D8u;  // 060B8352 mova 0x060B83D8,r0
L_060B8354:
    c.r[2] = c.r[7] << 16 | c.r[7] >> 16;  // 060B8354 swap.w r7,r2
L_060B8356:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B8356 tst r8,r2
L_060B8358:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B8358 subc r12,r12
L_060B835A:
    c.r[12] = ~c.r[12];  // 060B835A not r12,r12
L_060B835C:
    c.r[12] ^= c.r[2];  // 060B835C xor r2,r12
L_060B835E:
    c.t = (c.r[7] & c.r[8]) == 0;  // 060B835E tst r8,r7
L_060B8360:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B8360 subc r2,r2
L_060B8362:
    c.r[2] = ~c.r[2];  // 060B8362 not r2,r2
L_060B8364:
    c.r[2] ^= c.r[7];  // 060B8364 xor r7,r2
L_060B8366:
    c.r[12] += c.r[2];  // 060B8366 add r2,r12
L_060B8368:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B8368 extu.w r12,r12
L_060B836A:
    c.t = (int32_t)c.r[12] > (int32_t)c.r[13];  // 060B836A cmp/gt r13,r12
L_060B836C:
    { const bool k = c.t; c.r[2] = c.r[1] << 16 | c.r[1] >> 16; if (k) { goto L_060B8374; } }  // 060B836C bt/s 0x060B8374 ; swap.w r1,r2
L_060B8370:
    c.r[13] = c.r[12];  // 060B8370 mov r12,r13
L_060B8372:
    c.r[0] = 0x060B83C8u;  // 060B8372 mova 0x060B83C8,r0
L_060B8374:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B8374 tst r8,r2
L_060B8376:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B8376 subc r12,r12
L_060B8378:
    c.r[12] = ~c.r[12];  // 060B8378 not r12,r12
L_060B837A:
    c.r[12] ^= c.r[2];  // 060B837A xor r2,r12
L_060B837C:
    c.t = (c.r[1] & c.r[8]) == 0;  // 060B837C tst r8,r1
L_060B837E:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B837E subc r2,r2
L_060B8380:
    c.r[2] = ~c.r[2];  // 060B8380 not r2,r2
L_060B8382:
    c.r[2] ^= c.r[1];  // 060B8382 xor r1,r2
L_060B8384:
    c.r[12] += c.r[2];  // 060B8384 add r2,r12
L_060B8386:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B8386 extu.w r12,r12
L_060B8388:
    c.t = (int32_t)c.r[12] > (int32_t)c.r[13];  // 060B8388 cmp/gt r13,r12
L_060B838A:
    { const bool k = c.t; c.r[2] = c.r[5] << 16 | c.r[5] >> 16; if (k) { goto L_060B8392; } }  // 060B838A bt/s 0x060B8392 ; swap.w r5,r2
L_060B838E:
    c.r[13] = c.r[12];  // 060B838E mov r12,r13
L_060B8390:
    c.r[0] = 0x060B83C8u;  // 060B8390 mova 0x060B83C8,r0
L_060B8392:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B8392 tst r8,r2
L_060B8394:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B8394 subc r12,r12
L_060B8396:
    c.r[12] = ~c.r[12];  // 060B8396 not r12,r12
L_060B8398:
    c.r[12] ^= c.r[2];  // 060B8398 xor r2,r12
L_060B839A:
    c.t = (c.r[5] & c.r[8]) == 0;  // 060B839A tst r8,r5
L_060B839C:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B839C subc r2,r2
L_060B839E:
    c.r[2] = ~c.r[2];  // 060B839E not r2,r2
L_060B83A0:
    c.r[2] ^= c.r[5];  // 060B83A0 xor r5,r2
L_060B83A2:
    c.r[12] += c.r[2];  // 060B83A2 add r2,r12
L_060B83A4:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B83A4 extu.w r12,r12
L_060B83A6:
    c.t = (int32_t)c.r[13] >= (int32_t)c.r[12];  // 060B83A6 cmp/ge r12,r13
L_060B83A8:
    if (c.t) { goto L_060B83AE; }  // 060B83A8 bt 0x060B83AE
L_060B83AA:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x060B8146u: goto L_060B8146; case 0x060B8148u: goto L_060B8148; case 0x060B814Au: goto L_060B814A; case 0x060B814Cu: goto L_060B814C; case 0x060B814Eu: goto L_060B814E; case 0x060B8150u: goto L_060B8150; case 0x060B8152u: goto L_060B8152; case 0x060B8166u: goto L_060B8166; case 0x060B8168u: goto L_060B8168; case 0x060B816Au: goto L_060B816A; case 0x060B816Cu: goto L_060B816C; case 0x060B816Eu: goto L_060B816E; case 0x060B8170u: goto L_060B8170; case 0x060B8172u: goto L_060B8172; case 0x060B8174u: goto L_060B8174; case 0x060B8176u: goto L_060B8176; case 0x060B817Au: goto L_060B817A; case 0x060B817Cu: goto L_060B817C; case 0x060B817Eu: goto L_060B817E; case 0x060B8180u: goto L_060B8180; case 0x060B8184u: goto L_060B8184; case 0x060B8186u: goto L_060B8186; case 0x060B8188u: goto L_060B8188; case 0x060B818Au: goto L_060B818A; case 0x060B818Cu: goto L_060B818C; case 0x060B818Eu: goto L_060B818E; case 0x060B8190u: goto L_060B8190; case 0x060B8194u: goto L_060B8194; case 0x060B8196u: goto L_060B8196; case 0x060B8198u: goto L_060B8198; case 0x060B819Au: goto L_060B819A; case 0x060B819Eu: goto L_060B819E; case 0x060B81A0u: goto L_060B81A0; case 0x060B81A2u: goto L_060B81A2; case 0x060B81A4u: goto L_060B81A4; case 0x060B81A6u: goto L_060B81A6; case 0x060B81A8u: goto L_060B81A8; case 0x060B81AAu: goto L_060B81AA; case 0x060B81AEu: goto L_060B81AE; case 0x060B81B0u: goto L_060B81B0; case 0x060B81B2u: goto L_060B81B2; case 0x060B81B4u: goto L_060B81B4; case 0x060B81B8u: goto L_060B81B8; case 0x060B81BAu: goto L_060B81BA; case 0x060B81BCu: goto L_060B81BC; case 0x060B81BEu: goto L_060B81BE; case 0x060B81C2u: goto L_060B81C2; case 0x060B81C4u: goto L_060B81C4; case 0x060B81C6u: goto L_060B81C6; case 0x060B81C8u: goto L_060B81C8; case 0x060B81CCu: goto L_060B81CC; case 0x060B82D8u: goto L_060B82D8; case 0x060B82DAu: goto L_060B82DA; case 0x060B82DCu: goto L_060B82DC; case 0x060B82DEu: goto L_060B82DE; case 0x060B82E0u: goto L_060B82E0; case 0x060B82E2u: goto L_060B82E2; case 0x060B82E4u: goto L_060B82E4; case 0x060B82E6u: goto L_060B82E6; case 0x060B82E8u: goto L_060B82E8; case 0x060B82EAu: goto L_060B82EA; case 0x060B82ECu: goto L_060B82EC; case 0x060B82EEu: goto L_060B82EE; case 0x060B82F0u: goto L_060B82F0; case 0x060B82F2u: goto L_060B82F2; case 0x060B82F4u: goto L_060B82F4; case 0x060B82F8u: goto L_060B82F8; case 0x060B82FAu: goto L_060B82FA; case 0x060B82FCu: goto L_060B82FC; case 0x060B82FEu: goto L_060B82FE; case 0x060B8300u: goto L_060B8300; case 0x060B8304u: goto L_060B8304; case 0x060B8306u: goto L_060B8306; case 0x060B8308u: goto L_060B8308; case 0x060B830Cu: goto L_060B830C; case 0x060B830Eu: goto L_060B830E; case 0x060B8310u: goto L_060B8310; case 0x060B8312u: goto L_060B8312; case 0x060B8316u: goto L_060B8316; case 0x060B8318u: goto L_060B8318; case 0x060B831Au: goto L_060B831A; case 0x060B831Eu: goto L_060B831E; case 0x060B8320u: goto L_060B8320; case 0x060B8322u: goto L_060B8322; case 0x060B8324u: goto L_060B8324; case 0x060B8328u: goto L_060B8328; case 0x060B832Au: goto L_060B832A; case 0x060B832Cu: goto L_060B832C; case 0x060B8330u: goto L_060B8330; case 0x060B8332u: goto L_060B8332; case 0x060B8334u: goto L_060B8334; case 0x060B8338u: goto L_060B8338; case 0x060B833Au: goto L_060B833A; case 0x060B833Cu: goto L_060B833C; case 0x060B833Eu: goto L_060B833E; case 0x060B8340u: goto L_060B8340; case 0x060B8342u: goto L_060B8342; case 0x060B8344u: goto L_060B8344; case 0x060B8346u: goto L_060B8346; case 0x060B8348u: goto L_060B8348; case 0x060B834Au: goto L_060B834A; case 0x060B834Cu: goto L_060B834C; case 0x060B834Eu: goto L_060B834E; case 0x060B8350u: goto L_060B8350; case 0x060B8352u: goto L_060B8352; case 0x060B8354u: goto L_060B8354; case 0x060B8356u: goto L_060B8356; case 0x060B8358u: goto L_060B8358; case 0x060B835Au: goto L_060B835A; case 0x060B835Cu: goto L_060B835C; case 0x060B835Eu: goto L_060B835E; case 0x060B8360u: goto L_060B8360; case 0x060B8362u: goto L_060B8362; case 0x060B8364u: goto L_060B8364; case 0x060B8366u: goto L_060B8366; case 0x060B8368u: goto L_060B8368; case 0x060B836Au: goto L_060B836A; case 0x060B836Cu: goto L_060B836C; case 0x060B8370u: goto L_060B8370; case 0x060B8372u: goto L_060B8372; case 0x060B8374u: goto L_060B8374; case 0x060B8376u: goto L_060B8376; case 0x060B8378u: goto L_060B8378; case 0x060B837Au: goto L_060B837A; case 0x060B837Cu: goto L_060B837C; case 0x060B837Eu: goto L_060B837E; case 0x060B8380u: goto L_060B8380; case 0x060B8382u: goto L_060B8382; case 0x060B8384u: goto L_060B8384; case 0x060B8386u: goto L_060B8386; case 0x060B8388u: goto L_060B8388; case 0x060B838Au: goto L_060B838A; case 0x060B838Eu: goto L_060B838E; case 0x060B8390u: goto L_060B8390; case 0x060B8392u: goto L_060B8392; case 0x060B8394u: goto L_060B8394; case 0x060B8396u: goto L_060B8396; case 0x060B8398u: goto L_060B8398; case 0x060B839Au: goto L_060B839A; case 0x060B839Cu: goto L_060B839C; case 0x060B839Eu: goto L_060B839E; case 0x060B83A0u: goto L_060B83A0; case 0x060B83A2u: goto L_060B83A2; case 0x060B83A4u: goto L_060B83A4; case 0x060B83A6u: goto L_060B83A6; case 0x060B83A8u: goto L_060B83A8; case 0x060B83AAu: goto L_060B83AA; case 0x060B83AEu: goto L_060B83AE; case 0x060B83B0u: goto L_060B83B0; case 0x060B83B2u: goto L_060B83B2; case 0x060B83B4u: goto L_060B83B4; case 0x060B83B8u: goto L_060B83B8; case 0x060B83BAu: goto L_060B83BA; case 0x060B83BCu: goto L_060B83BC; case 0x060B83BEu: goto L_060B83BE; case 0x060B83C0u: goto L_060B83C0; case 0x060B83C2u: goto L_060B83C2; case 0x060B83C4u: goto L_060B83C4; case 0x060B83C8u: goto L_060B83C8; case 0x060B83CAu: goto L_060B83CA; case 0x060B83CCu: goto L_060B83CC; case 0x060B83CEu: goto L_060B83CE; case 0x060B83D0u: goto L_060B83D0; case 0x060B83D2u: goto L_060B83D2; case 0x060B83D4u: goto L_060B83D4; case 0x060B83D8u: goto L_060B83D8; case 0x060B83DAu: goto L_060B83DA; case 0x060B83DCu: goto L_060B83DC; case 0x060B83DEu: goto L_060B83DE; case 0x060B83E0u: goto L_060B83E0; case 0x060B83E2u: goto L_060B83E2; case 0x060B83E4u: goto L_060B83E4; default: sh2_call(c, x); return; } }  // 060B83AA jmp @r0 ; nop
L_060B83AE:
    st32(c.r[11] + 12, c.r[5]);  // 060B83AE mov.l r5,@(12,r11)
L_060B83B0:
    st32(c.r[11] + 16, c.r[1]);  // 060B83B0 mov.l r1,@(16,r11)
L_060B83B2:
    st32(c.r[11] + 20, c.r[7]);  // 060B83B2 mov.l r7,@(20,r11)
L_060B83B4:
    { const uint32_t x = c.pr; st32(c.r[11] + 24, c.r[9]); c.pc = x; return; }  // 060B83B4 rts ; mov.l r9,@(24,r11)
L_060B83B8:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[11]);  // 060B83B8 mov.w @(0,r11),r0
L_060B83BA:
    st32(c.r[11] + 16, c.r[5]);  // 060B83BA mov.l r5,@(16,r11)
L_060B83BC:
    c.r[0] ^= 0x10u;  // 060B83BC xor #16,r0
L_060B83BE:
    st16(c.r[11], c.r[0]);  // 060B83BE mov.w r0,@(0,r11)
L_060B83C0:
    st32(c.r[11] + 12, c.r[1]);  // 060B83C0 mov.l r1,@(12,r11)
L_060B83C2:
    st32(c.r[11] + 24, c.r[7]);  // 060B83C2 mov.l r7,@(24,r11)
L_060B83C4:
    { const uint32_t x = c.pr; st32(c.r[11] + 20, c.r[9]); c.pc = x; return; }  // 060B83C4 rts ; mov.l r9,@(20,r11)
L_060B83C8:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[11]);  // 060B83C8 mov.w @(0,r11),r0
L_060B83CA:
    st32(c.r[11] + 20, c.r[5]);  // 060B83CA mov.l r5,@(20,r11)
L_060B83CC:
    c.r[0] ^= 0x30u;  // 060B83CC xor #48,r0
L_060B83CE:
    st16(c.r[11], c.r[0]);  // 060B83CE mov.w r0,@(0,r11)
L_060B83D0:
    st32(c.r[11] + 24, c.r[1]);  // 060B83D0 mov.l r1,@(24,r11)
L_060B83D2:
    st32(c.r[11] + 12, c.r[7]);  // 060B83D2 mov.l r7,@(12,r11)
L_060B83D4:
    { const uint32_t x = c.pr; st32(c.r[11] + 16, c.r[9]); c.pc = x; return; }  // 060B83D4 rts ; mov.l r9,@(16,r11)
L_060B83D8:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[11]);  // 060B83D8 mov.w @(0,r11),r0
L_060B83DA:
    st32(c.r[11] + 24, c.r[5]);  // 060B83DA mov.l r5,@(24,r11)
L_060B83DC:
    c.r[0] ^= 0x20u;  // 060B83DC xor #32,r0
L_060B83DE:
    st16(c.r[11], c.r[0]);  // 060B83DE mov.w r0,@(0,r11)
L_060B83E0:
    st32(c.r[11] + 20, c.r[1]);  // 060B83E0 mov.l r1,@(20,r11)
L_060B83E2:
    st32(c.r[11] + 16, c.r[7]);  // 060B83E2 mov.l r7,@(16,r11)
L_060B83E4:
    { const uint32_t x = c.pr; st32(c.r[11] + 12, c.r[9]); c.pc = x; return; }  // 060B83E4 rts ; mov.l r9,@(12,r11)
}

void f_060B8170(SH2Context& c) {
    ran[3162] = 1;
    goto L_060B8170;
L_060B8146:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[11] + 30);  // 060B8146 mov.w @(30,r11),r0
L_060B8148:
    c.r[1] = ld32(c.r[11] + 32);  // 060B8148 mov.l @(32,r11),r1
L_060B814A:
    c.r[2] = (c.r[0] & 0xFFFF0000u) | (c.r[0] & 0xFFu) << 8 | (c.r[0] >> 8 & 0xFFu);  // 060B814A swap.b r0,r2
L_060B814C:
    c.r[0] = ld32(c.gbr + 56);  // 060B814C mov.l @(56,gbr),r0
L_060B814E:
    c.r[2] = c.r[2] & 0xFFu;  // 060B814E extu.b r2,r2
L_060B8150:
    c.r[2] <<= 2;  // 060B8150 shll2 r2
L_060B8152:
    { const uint32_t x = c.pr; st32(c.r[0] + c.r[2], c.r[1]); c.pc = x; return; }  // 060B8152 rts ; mov.l r1,@(r0,r2)
L_060B8170:
    c.r[0] = c.r[8];  // 060B8170 mov r8,r0
L_060B8172:
    c.r[0] += c.r[10];  // 060B8172 add r10,r0
L_060B8174:
    c.t = c.r[0] > c.r[13];  // 060B8174 cmp/hi r13,r0
L_060B8176:
    { const bool k = c.t; c.r[4] += 32; if (k) { SH2_POLL(c); goto L_060B8146; } }  // 060B8176 bt/s 0x060B8146 ; add #32,r4
L_060B817A:
    c.r[0] = c.r[9];  // 060B817A mov r9,r0
L_060B817C:
    c.r[0] += c.r[12];  // 060B817C add r12,r0
L_060B817E:
    c.t = c.r[0] > c.r[14];  // 060B817E cmp/hi r14,r0
L_060B8180:
    { const bool k = c.t; c.r[0] = c.r[8] << 16 | c.r[8] >> 16; if (k) { SH2_POLL(c); goto L_060B8146; } }  // 060B8180 bt/s 0x060B8146 ; swap.w r8,r0
L_060B8184:
    c.r[5] = c.r[9];  // 060B8184 mov r9,r5
L_060B8186:
    c.r[5] = c.r[0] << 16 | c.r[5] >> 16;  // 060B8186 xtrct r0,r5
L_060B8188:
    c.r[8] += c.r[2];  // 060B8188 add r2,r8
L_060B818A:
    c.r[0] = c.r[8];  // 060B818A mov r8,r0
L_060B818C:
    c.r[0] += c.r[10];  // 060B818C add r10,r0
L_060B818E:
    c.t = c.r[0] > c.r[13];  // 060B818E cmp/hi r13,r0
L_060B8190:
    { const bool k = c.t; c.r[9] += c.r[6]; if (k) { SH2_POLL(c); goto L_060B8146; } }  // 060B8190 bt/s 0x060B8146 ; add r6,r9
L_060B8194:
    c.r[0] = c.r[9];  // 060B8194 mov r9,r0
L_060B8196:
    c.r[0] += c.r[12];  // 060B8196 add r12,r0
L_060B8198:
    c.t = c.r[0] > c.r[14];  // 060B8198 cmp/hi r14,r0
L_060B819A:
    { const bool k = c.t; c.r[0] = c.r[8] << 16 | c.r[8] >> 16; if (k) { SH2_POLL(c); goto L_060B8146; } }  // 060B819A bt/s 0x060B8146 ; swap.w r8,r0
L_060B819E:
    c.r[1] = c.r[9];  // 060B819E mov r9,r1
L_060B81A0:
    c.r[1] = c.r[0] << 16 | c.r[1] >> 16;  // 060B81A0 xtrct r0,r1
L_060B81A2:
    c.r[8] -= c.r[7];  // 060B81A2 sub r7,r8
L_060B81A4:
    c.r[0] = c.r[8];  // 060B81A4 mov r8,r0
L_060B81A6:
    c.r[0] += c.r[10];  // 060B81A6 add r10,r0
L_060B81A8:
    c.t = c.r[0] > c.r[13];  // 060B81A8 cmp/hi r13,r0
L_060B81AA:
    { const bool k = c.t; c.r[9] += c.r[3]; if (k) { SH2_POLL(c); goto L_060B8146; } }  // 060B81AA bt/s 0x060B8146 ; add r3,r9
L_060B81AE:
    c.r[0] = c.r[9];  // 060B81AE mov r9,r0
L_060B81B0:
    c.r[0] += c.r[12];  // 060B81B0 add r12,r0
L_060B81B2:
    c.t = c.r[0] > c.r[14];  // 060B81B2 cmp/hi r14,r0
L_060B81B4:
    { const bool k = c.t; c.r[3] = c.r[8] << 16 | c.r[8] >> 16; if (k) { SH2_POLL(c); goto L_060B8146; } }  // 060B81B4 bt/s 0x060B8146 ; swap.w r8,r3
L_060B81B8:
    c.r[8] -= c.r[2];  // 060B81B8 sub r2,r8
L_060B81BA:
    c.r[10] += c.r[8];  // 060B81BA add r8,r10
L_060B81BC:
    c.t = c.r[10] > c.r[13];  // 060B81BC cmp/hi r13,r10
L_060B81BE:
    { const bool k = c.t; c.r[7] = c.r[9]; if (k) { SH2_POLL(c); goto L_060B8146; } }  // 060B81BE bt/s 0x060B8146 ; mov r9,r7
L_060B81C2:
    c.r[9] -= c.r[6];  // 060B81C2 sub r6,r9
L_060B81C4:
    c.r[12] += c.r[9];  // 060B81C4 add r9,r12
L_060B81C6:
    c.t = c.r[12] > c.r[14];  // 060B81C6 cmp/hi r14,r12
L_060B81C8:
    { const bool k = c.t; c.r[7] = c.r[3] << 16 | c.r[7] >> 16; if (k) { SH2_POLL(c); goto L_060B8146; } }  // 060B81C8 bt/s 0x060B8146 ; xtrct r3,r7
L_060B81CC:
    c.r[8] = c.r[8] << 16 | c.r[8] >> 16; goto L_060B82D8;  // 060B81CC bra 0x060B82D8 ; swap.w r8,r8
L_060B82D8:
    c.r[0] = c.r[11];  // 060B82D8 mov r11,r0
L_060B82DA:
    c.r[0] += 36;  // 060B82DA add #36,r0
L_060B82DC:
    st32(c.gbr + 52, c.r[0]);  // 060B82DC mov.l r0,@(52,gbr)
L_060B82DE:
    c.r[0] = ld32(c.gbr + 148);  // 060B82DE mov.l @(148,gbr),r0
L_060B82E0:
    c.r[3] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B82E0 exts.w r0,r3
L_060B82E2:
    c.r[2] = c.r[0] << 16 | c.r[0] >> 16;  // 060B82E2 swap.w r0,r2
L_060B82E4:
    c.r[0] = ld32(c.gbr + 816);  // 060B82E4 mov.l @(816,gbr),r0
L_060B82E6:
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 060B82E6 exts.w r2,r2
L_060B82E8:
    c.r[13] = c.r[0] & 0xFFFFu;  // 060B82E8 extu.w r0,r13
L_060B82EA:
    c.r[12] = c.r[0] << 16 | c.r[0] >> 16;  // 060B82EA swap.w r0,r12
L_060B82EC:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B82EC extu.w r12,r12
L_060B82EE:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[5];  // 060B82EE exts.w r5,r0
L_060B82F0:
    c.r[0] += c.r[3];  // 060B82F0 add r3,r0
L_060B82F2:
    c.t = c.r[0] >= c.r[13];  // 060B82F2 cmp/hs r13,r0
L_060B82F4:
    { const bool k = c.t; c.r[9] = c.r[8] << 16 | c.r[9] >> 16; if (k) { goto L_060B8302; } }  // 060B82F4 bt/s 0x060B8302 ; xtrct r8,r9
L_060B82F8:
    c.r[0] = c.r[5] << 16 | c.r[5] >> 16;  // 060B82F8 swap.w r5,r0
L_060B82FA:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B82FA exts.w r0,r0
L_060B82FC:
    c.r[0] += c.r[2];  // 060B82FC add r2,r0
L_060B82FE:
    c.t = c.r[12] > c.r[0];  // 060B82FE cmp/hi r0,r12
L_060B8300:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[1]; if (k) { goto L_060B83AE; } }  // 060B8300 bt/s 0x060B83AE ; exts.w r1,r0
    goto L_060B8304;
L_060B8302:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 060B8302 exts.w r1,r0
L_060B8304:
    c.r[0] += c.r[3];  // 060B8304 add r3,r0
L_060B8306:
    c.t = c.r[0] >= c.r[13];  // 060B8306 cmp/hs r13,r0
L_060B8308:
    { const bool k = c.t; c.r[0] = c.r[1] << 16 | c.r[1] >> 16; if (k) { goto L_060B8314; } }  // 060B8308 bt/s 0x060B8314 ; swap.w r1,r0
L_060B830C:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B830C exts.w r0,r0
L_060B830E:
    c.r[0] += c.r[2];  // 060B830E add r2,r0
L_060B8310:
    c.t = c.r[12] > c.r[0];  // 060B8310 cmp/hi r0,r12
L_060B8312:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[7]; if (k) { goto L_060B83B8; } }  // 060B8312 bt/s 0x060B83B8 ; exts.w r7,r0
    goto L_060B8316;
L_060B8314:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[7];  // 060B8314 exts.w r7,r0
L_060B8316:
    c.r[0] += c.r[3];  // 060B8316 add r3,r0
L_060B8318:
    c.t = c.r[0] >= c.r[13];  // 060B8318 cmp/hs r13,r0
L_060B831A:
    { const bool k = c.t; c.r[0] = c.r[7] << 16 | c.r[7] >> 16; if (k) { goto L_060B8326; } }  // 060B831A bt/s 0x060B8326 ; swap.w r7,r0
L_060B831E:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B831E exts.w r0,r0
L_060B8320:
    c.r[0] += c.r[2];  // 060B8320 add r2,r0
L_060B8322:
    c.t = c.r[12] > c.r[0];  // 060B8322 cmp/hi r0,r12
L_060B8324:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[9]; if (k) { goto L_060B83C8; } }  // 060B8324 bt/s 0x060B83C8 ; exts.w r9,r0
    goto L_060B8328;
L_060B8326:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[9];  // 060B8326 exts.w r9,r0
L_060B8328:
    c.r[0] += c.r[3];  // 060B8328 add r3,r0
L_060B832A:
    c.t = c.r[0] >= c.r[13];  // 060B832A cmp/hs r13,r0
L_060B832C:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[8]; if (k) { goto L_060B8336; } }  // 060B832C bt/s 0x060B8336 ; exts.w r8,r0
L_060B8330:
    c.r[0] += c.r[2];  // 060B8330 add r2,r0
L_060B8332:
    c.t = c.r[12] > c.r[0];  // 060B8332 cmp/hi r0,r12
L_060B8334:
    { const bool k = c.t; c.r[8] = 0x1u; if (k) { goto L_060B83D8; } }  // 060B8334 bt/s 0x060B83D8 ; mov #1,r8
    goto L_060B8338;
L_060B8336:
    c.r[8] = 0x1u;  // 060B8336 mov #1,r8
L_060B8338:
    c.r[8] <<= 16;  // 060B8338 shll16 r8
L_060B833A:
    c.t = c.r[8] & 1; c.r[8] >>= 1;  // 060B833A shlr r8
L_060B833C:
    c.r[2] = c.r[9] << 16 | c.r[9] >> 16;  // 060B833C swap.w r9,r2
L_060B833E:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B833E tst r8,r2
L_060B8340:
    { uint32_t a = c.r[13], b = c.r[13], t = c.t; c.r[13] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B8340 subc r13,r13
L_060B8342:
    c.r[13] = ~c.r[13];  // 060B8342 not r13,r13
L_060B8344:
    c.r[13] ^= c.r[2];  // 060B8344 xor r2,r13
L_060B8346:
    c.t = (c.r[9] & c.r[8]) == 0;  // 060B8346 tst r8,r9
L_060B8348:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B8348 subc r2,r2
L_060B834A:
    c.r[2] = ~c.r[2];  // 060B834A not r2,r2
L_060B834C:
    c.r[2] ^= c.r[9];  // 060B834C xor r9,r2
L_060B834E:
    c.r[13] += c.r[2];  // 060B834E add r2,r13
L_060B8350:
    c.r[13] = c.r[13] & 0xFFFFu;  // 060B8350 extu.w r13,r13
L_060B8352:
    c.r[0] = 0x060B83D8u;  // 060B8352 mova 0x060B83D8,r0
L_060B8354:
    c.r[2] = c.r[7] << 16 | c.r[7] >> 16;  // 060B8354 swap.w r7,r2
L_060B8356:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B8356 tst r8,r2
L_060B8358:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B8358 subc r12,r12
L_060B835A:
    c.r[12] = ~c.r[12];  // 060B835A not r12,r12
L_060B835C:
    c.r[12] ^= c.r[2];  // 060B835C xor r2,r12
L_060B835E:
    c.t = (c.r[7] & c.r[8]) == 0;  // 060B835E tst r8,r7
L_060B8360:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B8360 subc r2,r2
L_060B8362:
    c.r[2] = ~c.r[2];  // 060B8362 not r2,r2
L_060B8364:
    c.r[2] ^= c.r[7];  // 060B8364 xor r7,r2
L_060B8366:
    c.r[12] += c.r[2];  // 060B8366 add r2,r12
L_060B8368:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B8368 extu.w r12,r12
L_060B836A:
    c.t = (int32_t)c.r[12] > (int32_t)c.r[13];  // 060B836A cmp/gt r13,r12
L_060B836C:
    { const bool k = c.t; c.r[2] = c.r[1] << 16 | c.r[1] >> 16; if (k) { goto L_060B8374; } }  // 060B836C bt/s 0x060B8374 ; swap.w r1,r2
L_060B8370:
    c.r[13] = c.r[12];  // 060B8370 mov r12,r13
L_060B8372:
    c.r[0] = 0x060B83C8u;  // 060B8372 mova 0x060B83C8,r0
L_060B8374:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B8374 tst r8,r2
L_060B8376:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B8376 subc r12,r12
L_060B8378:
    c.r[12] = ~c.r[12];  // 060B8378 not r12,r12
L_060B837A:
    c.r[12] ^= c.r[2];  // 060B837A xor r2,r12
L_060B837C:
    c.t = (c.r[1] & c.r[8]) == 0;  // 060B837C tst r8,r1
L_060B837E:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B837E subc r2,r2
L_060B8380:
    c.r[2] = ~c.r[2];  // 060B8380 not r2,r2
L_060B8382:
    c.r[2] ^= c.r[1];  // 060B8382 xor r1,r2
L_060B8384:
    c.r[12] += c.r[2];  // 060B8384 add r2,r12
L_060B8386:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B8386 extu.w r12,r12
L_060B8388:
    c.t = (int32_t)c.r[12] > (int32_t)c.r[13];  // 060B8388 cmp/gt r13,r12
L_060B838A:
    { const bool k = c.t; c.r[2] = c.r[5] << 16 | c.r[5] >> 16; if (k) { goto L_060B8392; } }  // 060B838A bt/s 0x060B8392 ; swap.w r5,r2
L_060B838E:
    c.r[13] = c.r[12];  // 060B838E mov r12,r13
L_060B8390:
    c.r[0] = 0x060B83C8u;  // 060B8390 mova 0x060B83C8,r0
L_060B8392:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B8392 tst r8,r2
L_060B8394:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B8394 subc r12,r12
L_060B8396:
    c.r[12] = ~c.r[12];  // 060B8396 not r12,r12
L_060B8398:
    c.r[12] ^= c.r[2];  // 060B8398 xor r2,r12
L_060B839A:
    c.t = (c.r[5] & c.r[8]) == 0;  // 060B839A tst r8,r5
L_060B839C:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B839C subc r2,r2
L_060B839E:
    c.r[2] = ~c.r[2];  // 060B839E not r2,r2
L_060B83A0:
    c.r[2] ^= c.r[5];  // 060B83A0 xor r5,r2
L_060B83A2:
    c.r[12] += c.r[2];  // 060B83A2 add r2,r12
L_060B83A4:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B83A4 extu.w r12,r12
L_060B83A6:
    c.t = (int32_t)c.r[13] >= (int32_t)c.r[12];  // 060B83A6 cmp/ge r12,r13
L_060B83A8:
    if (c.t) { goto L_060B83AE; }  // 060B83A8 bt 0x060B83AE
L_060B83AA:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x060B8146u: goto L_060B8146; case 0x060B8148u: goto L_060B8148; case 0x060B814Au: goto L_060B814A; case 0x060B814Cu: goto L_060B814C; case 0x060B814Eu: goto L_060B814E; case 0x060B8150u: goto L_060B8150; case 0x060B8152u: goto L_060B8152; case 0x060B8170u: goto L_060B8170; case 0x060B8172u: goto L_060B8172; case 0x060B8174u: goto L_060B8174; case 0x060B8176u: goto L_060B8176; case 0x060B817Au: goto L_060B817A; case 0x060B817Cu: goto L_060B817C; case 0x060B817Eu: goto L_060B817E; case 0x060B8180u: goto L_060B8180; case 0x060B8184u: goto L_060B8184; case 0x060B8186u: goto L_060B8186; case 0x060B8188u: goto L_060B8188; case 0x060B818Au: goto L_060B818A; case 0x060B818Cu: goto L_060B818C; case 0x060B818Eu: goto L_060B818E; case 0x060B8190u: goto L_060B8190; case 0x060B8194u: goto L_060B8194; case 0x060B8196u: goto L_060B8196; case 0x060B8198u: goto L_060B8198; case 0x060B819Au: goto L_060B819A; case 0x060B819Eu: goto L_060B819E; case 0x060B81A0u: goto L_060B81A0; case 0x060B81A2u: goto L_060B81A2; case 0x060B81A4u: goto L_060B81A4; case 0x060B81A6u: goto L_060B81A6; case 0x060B81A8u: goto L_060B81A8; case 0x060B81AAu: goto L_060B81AA; case 0x060B81AEu: goto L_060B81AE; case 0x060B81B0u: goto L_060B81B0; case 0x060B81B2u: goto L_060B81B2; case 0x060B81B4u: goto L_060B81B4; case 0x060B81B8u: goto L_060B81B8; case 0x060B81BAu: goto L_060B81BA; case 0x060B81BCu: goto L_060B81BC; case 0x060B81BEu: goto L_060B81BE; case 0x060B81C2u: goto L_060B81C2; case 0x060B81C4u: goto L_060B81C4; case 0x060B81C6u: goto L_060B81C6; case 0x060B81C8u: goto L_060B81C8; case 0x060B81CCu: goto L_060B81CC; case 0x060B82D8u: goto L_060B82D8; case 0x060B82DAu: goto L_060B82DA; case 0x060B82DCu: goto L_060B82DC; case 0x060B82DEu: goto L_060B82DE; case 0x060B82E0u: goto L_060B82E0; case 0x060B82E2u: goto L_060B82E2; case 0x060B82E4u: goto L_060B82E4; case 0x060B82E6u: goto L_060B82E6; case 0x060B82E8u: goto L_060B82E8; case 0x060B82EAu: goto L_060B82EA; case 0x060B82ECu: goto L_060B82EC; case 0x060B82EEu: goto L_060B82EE; case 0x060B82F0u: goto L_060B82F0; case 0x060B82F2u: goto L_060B82F2; case 0x060B82F4u: goto L_060B82F4; case 0x060B82F8u: goto L_060B82F8; case 0x060B82FAu: goto L_060B82FA; case 0x060B82FCu: goto L_060B82FC; case 0x060B82FEu: goto L_060B82FE; case 0x060B8300u: goto L_060B8300; case 0x060B8304u: goto L_060B8304; case 0x060B8306u: goto L_060B8306; case 0x060B8308u: goto L_060B8308; case 0x060B830Cu: goto L_060B830C; case 0x060B830Eu: goto L_060B830E; case 0x060B8310u: goto L_060B8310; case 0x060B8312u: goto L_060B8312; case 0x060B8316u: goto L_060B8316; case 0x060B8318u: goto L_060B8318; case 0x060B831Au: goto L_060B831A; case 0x060B831Eu: goto L_060B831E; case 0x060B8320u: goto L_060B8320; case 0x060B8322u: goto L_060B8322; case 0x060B8324u: goto L_060B8324; case 0x060B8328u: goto L_060B8328; case 0x060B832Au: goto L_060B832A; case 0x060B832Cu: goto L_060B832C; case 0x060B8330u: goto L_060B8330; case 0x060B8332u: goto L_060B8332; case 0x060B8334u: goto L_060B8334; case 0x060B8338u: goto L_060B8338; case 0x060B833Au: goto L_060B833A; case 0x060B833Cu: goto L_060B833C; case 0x060B833Eu: goto L_060B833E; case 0x060B8340u: goto L_060B8340; case 0x060B8342u: goto L_060B8342; case 0x060B8344u: goto L_060B8344; case 0x060B8346u: goto L_060B8346; case 0x060B8348u: goto L_060B8348; case 0x060B834Au: goto L_060B834A; case 0x060B834Cu: goto L_060B834C; case 0x060B834Eu: goto L_060B834E; case 0x060B8350u: goto L_060B8350; case 0x060B8352u: goto L_060B8352; case 0x060B8354u: goto L_060B8354; case 0x060B8356u: goto L_060B8356; case 0x060B8358u: goto L_060B8358; case 0x060B835Au: goto L_060B835A; case 0x060B835Cu: goto L_060B835C; case 0x060B835Eu: goto L_060B835E; case 0x060B8360u: goto L_060B8360; case 0x060B8362u: goto L_060B8362; case 0x060B8364u: goto L_060B8364; case 0x060B8366u: goto L_060B8366; case 0x060B8368u: goto L_060B8368; case 0x060B836Au: goto L_060B836A; case 0x060B836Cu: goto L_060B836C; case 0x060B8370u: goto L_060B8370; case 0x060B8372u: goto L_060B8372; case 0x060B8374u: goto L_060B8374; case 0x060B8376u: goto L_060B8376; case 0x060B8378u: goto L_060B8378; case 0x060B837Au: goto L_060B837A; case 0x060B837Cu: goto L_060B837C; case 0x060B837Eu: goto L_060B837E; case 0x060B8380u: goto L_060B8380; case 0x060B8382u: goto L_060B8382; case 0x060B8384u: goto L_060B8384; case 0x060B8386u: goto L_060B8386; case 0x060B8388u: goto L_060B8388; case 0x060B838Au: goto L_060B838A; case 0x060B838Eu: goto L_060B838E; case 0x060B8390u: goto L_060B8390; case 0x060B8392u: goto L_060B8392; case 0x060B8394u: goto L_060B8394; case 0x060B8396u: goto L_060B8396; case 0x060B8398u: goto L_060B8398; case 0x060B839Au: goto L_060B839A; case 0x060B839Cu: goto L_060B839C; case 0x060B839Eu: goto L_060B839E; case 0x060B83A0u: goto L_060B83A0; case 0x060B83A2u: goto L_060B83A2; case 0x060B83A4u: goto L_060B83A4; case 0x060B83A6u: goto L_060B83A6; case 0x060B83A8u: goto L_060B83A8; case 0x060B83AAu: goto L_060B83AA; case 0x060B83AEu: goto L_060B83AE; case 0x060B83B0u: goto L_060B83B0; case 0x060B83B2u: goto L_060B83B2; case 0x060B83B4u: goto L_060B83B4; case 0x060B83B8u: goto L_060B83B8; case 0x060B83BAu: goto L_060B83BA; case 0x060B83BCu: goto L_060B83BC; case 0x060B83BEu: goto L_060B83BE; case 0x060B83C0u: goto L_060B83C0; case 0x060B83C2u: goto L_060B83C2; case 0x060B83C4u: goto L_060B83C4; case 0x060B83C8u: goto L_060B83C8; case 0x060B83CAu: goto L_060B83CA; case 0x060B83CCu: goto L_060B83CC; case 0x060B83CEu: goto L_060B83CE; case 0x060B83D0u: goto L_060B83D0; case 0x060B83D2u: goto L_060B83D2; case 0x060B83D4u: goto L_060B83D4; case 0x060B83D8u: goto L_060B83D8; case 0x060B83DAu: goto L_060B83DA; case 0x060B83DCu: goto L_060B83DC; case 0x060B83DEu: goto L_060B83DE; case 0x060B83E0u: goto L_060B83E0; case 0x060B83E2u: goto L_060B83E2; case 0x060B83E4u: goto L_060B83E4; default: sh2_call(c, x); return; } }  // 060B83AA jmp @r0 ; nop
L_060B83AE:
    st32(c.r[11] + 12, c.r[5]);  // 060B83AE mov.l r5,@(12,r11)
L_060B83B0:
    st32(c.r[11] + 16, c.r[1]);  // 060B83B0 mov.l r1,@(16,r11)
L_060B83B2:
    st32(c.r[11] + 20, c.r[7]);  // 060B83B2 mov.l r7,@(20,r11)
L_060B83B4:
    { const uint32_t x = c.pr; st32(c.r[11] + 24, c.r[9]); c.pc = x; return; }  // 060B83B4 rts ; mov.l r9,@(24,r11)
L_060B83B8:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[11]);  // 060B83B8 mov.w @(0,r11),r0
L_060B83BA:
    st32(c.r[11] + 16, c.r[5]);  // 060B83BA mov.l r5,@(16,r11)
L_060B83BC:
    c.r[0] ^= 0x10u;  // 060B83BC xor #16,r0
L_060B83BE:
    st16(c.r[11], c.r[0]);  // 060B83BE mov.w r0,@(0,r11)
L_060B83C0:
    st32(c.r[11] + 12, c.r[1]);  // 060B83C0 mov.l r1,@(12,r11)
L_060B83C2:
    st32(c.r[11] + 24, c.r[7]);  // 060B83C2 mov.l r7,@(24,r11)
L_060B83C4:
    { const uint32_t x = c.pr; st32(c.r[11] + 20, c.r[9]); c.pc = x; return; }  // 060B83C4 rts ; mov.l r9,@(20,r11)
L_060B83C8:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[11]);  // 060B83C8 mov.w @(0,r11),r0
L_060B83CA:
    st32(c.r[11] + 20, c.r[5]);  // 060B83CA mov.l r5,@(20,r11)
L_060B83CC:
    c.r[0] ^= 0x30u;  // 060B83CC xor #48,r0
L_060B83CE:
    st16(c.r[11], c.r[0]);  // 060B83CE mov.w r0,@(0,r11)
L_060B83D0:
    st32(c.r[11] + 24, c.r[1]);  // 060B83D0 mov.l r1,@(24,r11)
L_060B83D2:
    st32(c.r[11] + 12, c.r[7]);  // 060B83D2 mov.l r7,@(12,r11)
L_060B83D4:
    { const uint32_t x = c.pr; st32(c.r[11] + 16, c.r[9]); c.pc = x; return; }  // 060B83D4 rts ; mov.l r9,@(16,r11)
L_060B83D8:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[11]);  // 060B83D8 mov.w @(0,r11),r0
L_060B83DA:
    st32(c.r[11] + 24, c.r[5]);  // 060B83DA mov.l r5,@(24,r11)
L_060B83DC:
    c.r[0] ^= 0x20u;  // 060B83DC xor #32,r0
L_060B83DE:
    st16(c.r[11], c.r[0]);  // 060B83DE mov.w r0,@(0,r11)
L_060B83E0:
    st32(c.r[11] + 20, c.r[1]);  // 060B83E0 mov.l r1,@(20,r11)
L_060B83E2:
    st32(c.r[11] + 16, c.r[7]);  // 060B83E2 mov.l r7,@(16,r11)
L_060B83E4:
    { const uint32_t x = c.pr; st32(c.r[11] + 12, c.r[9]); c.pc = x; return; }  // 060B83E4 rts ; mov.l r9,@(12,r11)
}

void f_060B81D0(SH2Context& c) {
    ran[3163] = 1;
L_060B81D0:
    c.r[1] = 0x10u;  // 060B81D0 mov #16,r1
L_060B81D2:
    c.r[5] ^= c.r[1];  // 060B81D2 xor r1,r5
L_060B81D4:
    st16(c.r[11], c.r[5]);  // 060B81D4 mov.w r5,@r11
L_060B81D6:
    c.r[2] = 0u - c.r[2];  // 060B81D6 neg r2,r2
L_060B81D8:
    c.r[6] = 0u - c.r[6];  // 060B81D8 neg r6,r6
L_060B81DA:
    c.r[0] = c.r[7];  // 060B81DA mov r7,r0
L_060B81DC:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B81DC shar r0
L_060B81DE:
    c.r[8] += c.r[0];  // 060B81DE add r0,r8
L_060B81E0:
    c.r[0] = c.r[8];  // 060B81E0 mov r8,r0
L_060B81E2:
    c.r[0] += c.r[10];  // 060B81E2 add r10,r0
L_060B81E4:
    c.t = c.r[0] > c.r[13];  // 060B81E4 cmp/hi r13,r0
L_060B81E6:
    { const bool k = c.t; c.r[4] += 32; if (k) { goto L_060B8246; } }  // 060B81E6 bt/s 0x060B8246 ; add #32,r4
L_060B81EA:
    c.r[0] = c.r[3];  // 060B81EA mov r3,r0
L_060B81EC:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B81EC shar r0
L_060B81EE:
    c.r[9] -= c.r[0];  // 060B81EE sub r0,r9
L_060B81F0:
    c.r[0] = c.r[9];  // 060B81F0 mov r9,r0
L_060B81F2:
    c.r[0] += c.r[12];  // 060B81F2 add r12,r0
L_060B81F4:
    c.t = c.r[0] > c.r[14];  // 060B81F4 cmp/hi r14,r0
L_060B81F6:
    { const bool k = c.t; c.r[1] = c.r[8] << 16 | c.r[8] >> 16; if (k) { goto L_060B8246; } }  // 060B81F6 bt/s 0x060B8246 ; swap.w r8,r1
L_060B81FA:
    c.r[8] += c.r[2];  // 060B81FA add r2,r8
L_060B81FC:
    c.r[0] = c.r[8];  // 060B81FC mov r8,r0
L_060B81FE:
    c.r[0] += c.r[10];  // 060B81FE add r10,r0
L_060B8200:
    c.t = c.r[0] > c.r[13];  // 060B8200 cmp/hi r13,r0
L_060B8202:
    { const bool k = c.t; c.r[5] = c.r[9]; if (k) { goto L_060B8246; } }  // 060B8202 bt/s 0x060B8246 ; mov r9,r5
L_060B8206:
    c.r[9] += c.r[6];  // 060B8206 add r6,r9
L_060B8208:
    c.r[0] = c.r[9];  // 060B8208 mov r9,r0
L_060B820A:
    c.r[0] += c.r[12];  // 060B820A add r12,r0
L_060B820C:
    c.t = c.r[0] > c.r[14];  // 060B820C cmp/hi r14,r0
L_060B820E:
    { const bool k = c.t; c.r[0] = c.r[8] << 16 | c.r[8] >> 16; if (k) { goto L_060B8246; } }  // 060B820E bt/s 0x060B8246 ; swap.w r8,r0
L_060B8212:
    c.r[5] = c.r[1] << 16 | c.r[5] >> 16;  // 060B8212 xtrct r1,r5
L_060B8214:
    c.r[1] = c.r[9];  // 060B8214 mov r9,r1
L_060B8216:
    c.r[1] = c.r[0] << 16 | c.r[1] >> 16;  // 060B8216 xtrct r0,r1
L_060B8218:
    c.r[8] -= c.r[7];  // 060B8218 sub r7,r8
L_060B821A:
    c.r[0] = c.r[8];  // 060B821A mov r8,r0
L_060B821C:
    c.r[0] += c.r[10];  // 060B821C add r10,r0
L_060B821E:
    c.t = c.r[0] > c.r[13];  // 060B821E cmp/hi r13,r0
L_060B8220:
    { const bool k = c.t; c.r[9] += c.r[3]; if (k) { goto L_060B8246; } }  // 060B8220 bt/s 0x060B8246 ; add r3,r9
L_060B8224:
    c.r[0] = c.r[9];  // 060B8224 mov r9,r0
L_060B8226:
    c.r[0] += c.r[12];  // 060B8226 add r12,r0
L_060B8228:
    c.t = c.r[0] > c.r[14];  // 060B8228 cmp/hi r14,r0
L_060B822A:
    { const bool k = c.t; c.r[3] = c.r[8] << 16 | c.r[8] >> 16; if (k) { goto L_060B8246; } }  // 060B822A bt/s 0x060B8246 ; swap.w r8,r3
L_060B822E:
    c.r[8] -= c.r[2];  // 060B822E sub r2,r8
L_060B8230:
    c.r[10] += c.r[8];  // 060B8230 add r8,r10
L_060B8232:
    c.t = c.r[10] > c.r[13];  // 060B8232 cmp/hi r13,r10
L_060B8234:
    { const bool k = c.t; c.r[7] = c.r[9]; if (k) { goto L_060B8246; } }  // 060B8234 bt/s 0x060B8246 ; mov r9,r7
L_060B8238:
    c.r[9] -= c.r[6];  // 060B8238 sub r6,r9
L_060B823A:
    c.r[12] += c.r[9];  // 060B823A add r9,r12
L_060B823C:
    c.t = c.r[12] > c.r[14];  // 060B823C cmp/hi r14,r12
L_060B823E:
    { const bool k = c.t; c.r[7] = c.r[3] << 16 | c.r[7] >> 16; if (k) { goto L_060B8246; } }  // 060B823E bt/s 0x060B8246 ; xtrct r3,r7
L_060B8242:
    c.r[8] = c.r[8] << 16 | c.r[8] >> 16; goto L_060B82D8;  // 060B8242 bra 0x060B82D8 ; swap.w r8,r8
L_060B8246:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[11] + 30);  // 060B8246 mov.w @(30,r11),r0
L_060B8248:
    c.r[1] = ld32(c.r[11] + 32);  // 060B8248 mov.l @(32,r11),r1
L_060B824A:
    c.r[2] = (c.r[0] & 0xFFFF0000u) | (c.r[0] & 0xFFu) << 8 | (c.r[0] >> 8 & 0xFFu);  // 060B824A swap.b r0,r2
L_060B824C:
    c.r[0] = ld32(c.gbr + 56);  // 060B824C mov.l @(56,gbr),r0
L_060B824E:
    c.r[2] = c.r[2] & 0xFFu;  // 060B824E extu.b r2,r2
L_060B8250:
    c.r[2] <<= 2;  // 060B8250 shll2 r2
L_060B8252:
    { const uint32_t x = c.pr; st32(c.r[0] + c.r[2], c.r[1]); c.pc = x; return; }  // 060B8252 rts ; mov.l r1,@(r0,r2)
L_060B82D8:
    c.r[0] = c.r[11];  // 060B82D8 mov r11,r0
L_060B82DA:
    c.r[0] += 36;  // 060B82DA add #36,r0
L_060B82DC:
    st32(c.gbr + 52, c.r[0]);  // 060B82DC mov.l r0,@(52,gbr)
L_060B82DE:
    c.r[0] = ld32(c.gbr + 148);  // 060B82DE mov.l @(148,gbr),r0
L_060B82E0:
    c.r[3] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B82E0 exts.w r0,r3
L_060B82E2:
    c.r[2] = c.r[0] << 16 | c.r[0] >> 16;  // 060B82E2 swap.w r0,r2
L_060B82E4:
    c.r[0] = ld32(c.gbr + 816);  // 060B82E4 mov.l @(816,gbr),r0
L_060B82E6:
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 060B82E6 exts.w r2,r2
L_060B82E8:
    c.r[13] = c.r[0] & 0xFFFFu;  // 060B82E8 extu.w r0,r13
L_060B82EA:
    c.r[12] = c.r[0] << 16 | c.r[0] >> 16;  // 060B82EA swap.w r0,r12
L_060B82EC:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B82EC extu.w r12,r12
L_060B82EE:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[5];  // 060B82EE exts.w r5,r0
L_060B82F0:
    c.r[0] += c.r[3];  // 060B82F0 add r3,r0
L_060B82F2:
    c.t = c.r[0] >= c.r[13];  // 060B82F2 cmp/hs r13,r0
L_060B82F4:
    { const bool k = c.t; c.r[9] = c.r[8] << 16 | c.r[9] >> 16; if (k) { goto L_060B8302; } }  // 060B82F4 bt/s 0x060B8302 ; xtrct r8,r9
L_060B82F8:
    c.r[0] = c.r[5] << 16 | c.r[5] >> 16;  // 060B82F8 swap.w r5,r0
L_060B82FA:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B82FA exts.w r0,r0
L_060B82FC:
    c.r[0] += c.r[2];  // 060B82FC add r2,r0
L_060B82FE:
    c.t = c.r[12] > c.r[0];  // 060B82FE cmp/hi r0,r12
L_060B8300:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[1]; if (k) { goto L_060B83AE; } }  // 060B8300 bt/s 0x060B83AE ; exts.w r1,r0
    goto L_060B8304;
L_060B8302:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 060B8302 exts.w r1,r0
L_060B8304:
    c.r[0] += c.r[3];  // 060B8304 add r3,r0
L_060B8306:
    c.t = c.r[0] >= c.r[13];  // 060B8306 cmp/hs r13,r0
L_060B8308:
    { const bool k = c.t; c.r[0] = c.r[1] << 16 | c.r[1] >> 16; if (k) { goto L_060B8314; } }  // 060B8308 bt/s 0x060B8314 ; swap.w r1,r0
L_060B830C:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B830C exts.w r0,r0
L_060B830E:
    c.r[0] += c.r[2];  // 060B830E add r2,r0
L_060B8310:
    c.t = c.r[12] > c.r[0];  // 060B8310 cmp/hi r0,r12
L_060B8312:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[7]; if (k) { goto L_060B83B8; } }  // 060B8312 bt/s 0x060B83B8 ; exts.w r7,r0
    goto L_060B8316;
L_060B8314:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[7];  // 060B8314 exts.w r7,r0
L_060B8316:
    c.r[0] += c.r[3];  // 060B8316 add r3,r0
L_060B8318:
    c.t = c.r[0] >= c.r[13];  // 060B8318 cmp/hs r13,r0
L_060B831A:
    { const bool k = c.t; c.r[0] = c.r[7] << 16 | c.r[7] >> 16; if (k) { goto L_060B8326; } }  // 060B831A bt/s 0x060B8326 ; swap.w r7,r0
L_060B831E:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B831E exts.w r0,r0
L_060B8320:
    c.r[0] += c.r[2];  // 060B8320 add r2,r0
L_060B8322:
    c.t = c.r[12] > c.r[0];  // 060B8322 cmp/hi r0,r12
L_060B8324:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[9]; if (k) { goto L_060B83C8; } }  // 060B8324 bt/s 0x060B83C8 ; exts.w r9,r0
    goto L_060B8328;
L_060B8326:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[9];  // 060B8326 exts.w r9,r0
L_060B8328:
    c.r[0] += c.r[3];  // 060B8328 add r3,r0
L_060B832A:
    c.t = c.r[0] >= c.r[13];  // 060B832A cmp/hs r13,r0
L_060B832C:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[8]; if (k) { goto L_060B8336; } }  // 060B832C bt/s 0x060B8336 ; exts.w r8,r0
L_060B8330:
    c.r[0] += c.r[2];  // 060B8330 add r2,r0
L_060B8332:
    c.t = c.r[12] > c.r[0];  // 060B8332 cmp/hi r0,r12
L_060B8334:
    { const bool k = c.t; c.r[8] = 0x1u; if (k) { goto L_060B83D8; } }  // 060B8334 bt/s 0x060B83D8 ; mov #1,r8
    goto L_060B8338;
L_060B8336:
    c.r[8] = 0x1u;  // 060B8336 mov #1,r8
L_060B8338:
    c.r[8] <<= 16;  // 060B8338 shll16 r8
L_060B833A:
    c.t = c.r[8] & 1; c.r[8] >>= 1;  // 060B833A shlr r8
L_060B833C:
    c.r[2] = c.r[9] << 16 | c.r[9] >> 16;  // 060B833C swap.w r9,r2
L_060B833E:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B833E tst r8,r2
L_060B8340:
    { uint32_t a = c.r[13], b = c.r[13], t = c.t; c.r[13] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B8340 subc r13,r13
L_060B8342:
    c.r[13] = ~c.r[13];  // 060B8342 not r13,r13
L_060B8344:
    c.r[13] ^= c.r[2];  // 060B8344 xor r2,r13
L_060B8346:
    c.t = (c.r[9] & c.r[8]) == 0;  // 060B8346 tst r8,r9
L_060B8348:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B8348 subc r2,r2
L_060B834A:
    c.r[2] = ~c.r[2];  // 060B834A not r2,r2
L_060B834C:
    c.r[2] ^= c.r[9];  // 060B834C xor r9,r2
L_060B834E:
    c.r[13] += c.r[2];  // 060B834E add r2,r13
L_060B8350:
    c.r[13] = c.r[13] & 0xFFFFu;  // 060B8350 extu.w r13,r13
L_060B8352:
    c.r[0] = 0x060B83D8u;  // 060B8352 mova 0x060B83D8,r0
L_060B8354:
    c.r[2] = c.r[7] << 16 | c.r[7] >> 16;  // 060B8354 swap.w r7,r2
L_060B8356:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B8356 tst r8,r2
L_060B8358:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B8358 subc r12,r12
L_060B835A:
    c.r[12] = ~c.r[12];  // 060B835A not r12,r12
L_060B835C:
    c.r[12] ^= c.r[2];  // 060B835C xor r2,r12
L_060B835E:
    c.t = (c.r[7] & c.r[8]) == 0;  // 060B835E tst r8,r7
L_060B8360:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B8360 subc r2,r2
L_060B8362:
    c.r[2] = ~c.r[2];  // 060B8362 not r2,r2
L_060B8364:
    c.r[2] ^= c.r[7];  // 060B8364 xor r7,r2
L_060B8366:
    c.r[12] += c.r[2];  // 060B8366 add r2,r12
L_060B8368:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B8368 extu.w r12,r12
L_060B836A:
    c.t = (int32_t)c.r[12] > (int32_t)c.r[13];  // 060B836A cmp/gt r13,r12
L_060B836C:
    { const bool k = c.t; c.r[2] = c.r[1] << 16 | c.r[1] >> 16; if (k) { goto L_060B8374; } }  // 060B836C bt/s 0x060B8374 ; swap.w r1,r2
L_060B8370:
    c.r[13] = c.r[12];  // 060B8370 mov r12,r13
L_060B8372:
    c.r[0] = 0x060B83C8u;  // 060B8372 mova 0x060B83C8,r0
L_060B8374:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B8374 tst r8,r2
L_060B8376:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B8376 subc r12,r12
L_060B8378:
    c.r[12] = ~c.r[12];  // 060B8378 not r12,r12
L_060B837A:
    c.r[12] ^= c.r[2];  // 060B837A xor r2,r12
L_060B837C:
    c.t = (c.r[1] & c.r[8]) == 0;  // 060B837C tst r8,r1
L_060B837E:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B837E subc r2,r2
L_060B8380:
    c.r[2] = ~c.r[2];  // 060B8380 not r2,r2
L_060B8382:
    c.r[2] ^= c.r[1];  // 060B8382 xor r1,r2
L_060B8384:
    c.r[12] += c.r[2];  // 060B8384 add r2,r12
L_060B8386:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B8386 extu.w r12,r12
L_060B8388:
    c.t = (int32_t)c.r[12] > (int32_t)c.r[13];  // 060B8388 cmp/gt r13,r12
L_060B838A:
    { const bool k = c.t; c.r[2] = c.r[5] << 16 | c.r[5] >> 16; if (k) { goto L_060B8392; } }  // 060B838A bt/s 0x060B8392 ; swap.w r5,r2
L_060B838E:
    c.r[13] = c.r[12];  // 060B838E mov r12,r13
L_060B8390:
    c.r[0] = 0x060B83C8u;  // 060B8390 mova 0x060B83C8,r0
L_060B8392:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B8392 tst r8,r2
L_060B8394:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B8394 subc r12,r12
L_060B8396:
    c.r[12] = ~c.r[12];  // 060B8396 not r12,r12
L_060B8398:
    c.r[12] ^= c.r[2];  // 060B8398 xor r2,r12
L_060B839A:
    c.t = (c.r[5] & c.r[8]) == 0;  // 060B839A tst r8,r5
L_060B839C:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B839C subc r2,r2
L_060B839E:
    c.r[2] = ~c.r[2];  // 060B839E not r2,r2
L_060B83A0:
    c.r[2] ^= c.r[5];  // 060B83A0 xor r5,r2
L_060B83A2:
    c.r[12] += c.r[2];  // 060B83A2 add r2,r12
L_060B83A4:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B83A4 extu.w r12,r12
L_060B83A6:
    c.t = (int32_t)c.r[13] >= (int32_t)c.r[12];  // 060B83A6 cmp/ge r12,r13
L_060B83A8:
    if (c.t) { goto L_060B83AE; }  // 060B83A8 bt 0x060B83AE
L_060B83AA:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x060B81D0u: goto L_060B81D0; case 0x060B81D2u: goto L_060B81D2; case 0x060B81D4u: goto L_060B81D4; case 0x060B81D6u: goto L_060B81D6; case 0x060B81D8u: goto L_060B81D8; case 0x060B81DAu: goto L_060B81DA; case 0x060B81DCu: goto L_060B81DC; case 0x060B81DEu: goto L_060B81DE; case 0x060B81E0u: goto L_060B81E0; case 0x060B81E2u: goto L_060B81E2; case 0x060B81E4u: goto L_060B81E4; case 0x060B81E6u: goto L_060B81E6; case 0x060B81EAu: goto L_060B81EA; case 0x060B81ECu: goto L_060B81EC; case 0x060B81EEu: goto L_060B81EE; case 0x060B81F0u: goto L_060B81F0; case 0x060B81F2u: goto L_060B81F2; case 0x060B81F4u: goto L_060B81F4; case 0x060B81F6u: goto L_060B81F6; case 0x060B81FAu: goto L_060B81FA; case 0x060B81FCu: goto L_060B81FC; case 0x060B81FEu: goto L_060B81FE; case 0x060B8200u: goto L_060B8200; case 0x060B8202u: goto L_060B8202; case 0x060B8206u: goto L_060B8206; case 0x060B8208u: goto L_060B8208; case 0x060B820Au: goto L_060B820A; case 0x060B820Cu: goto L_060B820C; case 0x060B820Eu: goto L_060B820E; case 0x060B8212u: goto L_060B8212; case 0x060B8214u: goto L_060B8214; case 0x060B8216u: goto L_060B8216; case 0x060B8218u: goto L_060B8218; case 0x060B821Au: goto L_060B821A; case 0x060B821Cu: goto L_060B821C; case 0x060B821Eu: goto L_060B821E; case 0x060B8220u: goto L_060B8220; case 0x060B8224u: goto L_060B8224; case 0x060B8226u: goto L_060B8226; case 0x060B8228u: goto L_060B8228; case 0x060B822Au: goto L_060B822A; case 0x060B822Eu: goto L_060B822E; case 0x060B8230u: goto L_060B8230; case 0x060B8232u: goto L_060B8232; case 0x060B8234u: goto L_060B8234; case 0x060B8238u: goto L_060B8238; case 0x060B823Au: goto L_060B823A; case 0x060B823Cu: goto L_060B823C; case 0x060B823Eu: goto L_060B823E; case 0x060B8242u: goto L_060B8242; case 0x060B8246u: goto L_060B8246; case 0x060B8248u: goto L_060B8248; case 0x060B824Au: goto L_060B824A; case 0x060B824Cu: goto L_060B824C; case 0x060B824Eu: goto L_060B824E; case 0x060B8250u: goto L_060B8250; case 0x060B8252u: goto L_060B8252; case 0x060B82D8u: goto L_060B82D8; case 0x060B82DAu: goto L_060B82DA; case 0x060B82DCu: goto L_060B82DC; case 0x060B82DEu: goto L_060B82DE; case 0x060B82E0u: goto L_060B82E0; case 0x060B82E2u: goto L_060B82E2; case 0x060B82E4u: goto L_060B82E4; case 0x060B82E6u: goto L_060B82E6; case 0x060B82E8u: goto L_060B82E8; case 0x060B82EAu: goto L_060B82EA; case 0x060B82ECu: goto L_060B82EC; case 0x060B82EEu: goto L_060B82EE; case 0x060B82F0u: goto L_060B82F0; case 0x060B82F2u: goto L_060B82F2; case 0x060B82F4u: goto L_060B82F4; case 0x060B82F8u: goto L_060B82F8; case 0x060B82FAu: goto L_060B82FA; case 0x060B82FCu: goto L_060B82FC; case 0x060B82FEu: goto L_060B82FE; case 0x060B8300u: goto L_060B8300; case 0x060B8304u: goto L_060B8304; case 0x060B8306u: goto L_060B8306; case 0x060B8308u: goto L_060B8308; case 0x060B830Cu: goto L_060B830C; case 0x060B830Eu: goto L_060B830E; case 0x060B8310u: goto L_060B8310; case 0x060B8312u: goto L_060B8312; case 0x060B8316u: goto L_060B8316; case 0x060B8318u: goto L_060B8318; case 0x060B831Au: goto L_060B831A; case 0x060B831Eu: goto L_060B831E; case 0x060B8320u: goto L_060B8320; case 0x060B8322u: goto L_060B8322; case 0x060B8324u: goto L_060B8324; case 0x060B8328u: goto L_060B8328; case 0x060B832Au: goto L_060B832A; case 0x060B832Cu: goto L_060B832C; case 0x060B8330u: goto L_060B8330; case 0x060B8332u: goto L_060B8332; case 0x060B8334u: goto L_060B8334; case 0x060B8338u: goto L_060B8338; case 0x060B833Au: goto L_060B833A; case 0x060B833Cu: goto L_060B833C; case 0x060B833Eu: goto L_060B833E; case 0x060B8340u: goto L_060B8340; case 0x060B8342u: goto L_060B8342; case 0x060B8344u: goto L_060B8344; case 0x060B8346u: goto L_060B8346; case 0x060B8348u: goto L_060B8348; case 0x060B834Au: goto L_060B834A; case 0x060B834Cu: goto L_060B834C; case 0x060B834Eu: goto L_060B834E; case 0x060B8350u: goto L_060B8350; case 0x060B8352u: goto L_060B8352; case 0x060B8354u: goto L_060B8354; case 0x060B8356u: goto L_060B8356; case 0x060B8358u: goto L_060B8358; case 0x060B835Au: goto L_060B835A; case 0x060B835Cu: goto L_060B835C; case 0x060B835Eu: goto L_060B835E; case 0x060B8360u: goto L_060B8360; case 0x060B8362u: goto L_060B8362; case 0x060B8364u: goto L_060B8364; case 0x060B8366u: goto L_060B8366; case 0x060B8368u: goto L_060B8368; case 0x060B836Au: goto L_060B836A; case 0x060B836Cu: goto L_060B836C; case 0x060B8370u: goto L_060B8370; case 0x060B8372u: goto L_060B8372; case 0x060B8374u: goto L_060B8374; case 0x060B8376u: goto L_060B8376; case 0x060B8378u: goto L_060B8378; case 0x060B837Au: goto L_060B837A; case 0x060B837Cu: goto L_060B837C; case 0x060B837Eu: goto L_060B837E; case 0x060B8380u: goto L_060B8380; case 0x060B8382u: goto L_060B8382; case 0x060B8384u: goto L_060B8384; case 0x060B8386u: goto L_060B8386; case 0x060B8388u: goto L_060B8388; case 0x060B838Au: goto L_060B838A; case 0x060B838Eu: goto L_060B838E; case 0x060B8390u: goto L_060B8390; case 0x060B8392u: goto L_060B8392; case 0x060B8394u: goto L_060B8394; case 0x060B8396u: goto L_060B8396; case 0x060B8398u: goto L_060B8398; case 0x060B839Au: goto L_060B839A; case 0x060B839Cu: goto L_060B839C; case 0x060B839Eu: goto L_060B839E; case 0x060B83A0u: goto L_060B83A0; case 0x060B83A2u: goto L_060B83A2; case 0x060B83A4u: goto L_060B83A4; case 0x060B83A6u: goto L_060B83A6; case 0x060B83A8u: goto L_060B83A8; case 0x060B83AAu: goto L_060B83AA; case 0x060B83AEu: goto L_060B83AE; case 0x060B83B0u: goto L_060B83B0; case 0x060B83B2u: goto L_060B83B2; case 0x060B83B4u: goto L_060B83B4; case 0x060B83B8u: goto L_060B83B8; case 0x060B83BAu: goto L_060B83BA; case 0x060B83BCu: goto L_060B83BC; case 0x060B83BEu: goto L_060B83BE; case 0x060B83C0u: goto L_060B83C0; case 0x060B83C2u: goto L_060B83C2; case 0x060B83C4u: goto L_060B83C4; case 0x060B83C8u: goto L_060B83C8; case 0x060B83CAu: goto L_060B83CA; case 0x060B83CCu: goto L_060B83CC; case 0x060B83CEu: goto L_060B83CE; case 0x060B83D0u: goto L_060B83D0; case 0x060B83D2u: goto L_060B83D2; case 0x060B83D4u: goto L_060B83D4; case 0x060B83D8u: goto L_060B83D8; case 0x060B83DAu: goto L_060B83DA; case 0x060B83DCu: goto L_060B83DC; case 0x060B83DEu: goto L_060B83DE; case 0x060B83E0u: goto L_060B83E0; case 0x060B83E2u: goto L_060B83E2; case 0x060B83E4u: goto L_060B83E4; default: sh2_call(c, x); return; } }  // 060B83AA jmp @r0 ; nop
L_060B83AE:
    st32(c.r[11] + 12, c.r[5]);  // 060B83AE mov.l r5,@(12,r11)
L_060B83B0:
    st32(c.r[11] + 16, c.r[1]);  // 060B83B0 mov.l r1,@(16,r11)
L_060B83B2:
    st32(c.r[11] + 20, c.r[7]);  // 060B83B2 mov.l r7,@(20,r11)
L_060B83B4:
    { const uint32_t x = c.pr; st32(c.r[11] + 24, c.r[9]); c.pc = x; return; }  // 060B83B4 rts ; mov.l r9,@(24,r11)
L_060B83B8:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[11]);  // 060B83B8 mov.w @(0,r11),r0
L_060B83BA:
    st32(c.r[11] + 16, c.r[5]);  // 060B83BA mov.l r5,@(16,r11)
L_060B83BC:
    c.r[0] ^= 0x10u;  // 060B83BC xor #16,r0
L_060B83BE:
    st16(c.r[11], c.r[0]);  // 060B83BE mov.w r0,@(0,r11)
L_060B83C0:
    st32(c.r[11] + 12, c.r[1]);  // 060B83C0 mov.l r1,@(12,r11)
L_060B83C2:
    st32(c.r[11] + 24, c.r[7]);  // 060B83C2 mov.l r7,@(24,r11)
L_060B83C4:
    { const uint32_t x = c.pr; st32(c.r[11] + 20, c.r[9]); c.pc = x; return; }  // 060B83C4 rts ; mov.l r9,@(20,r11)
L_060B83C8:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[11]);  // 060B83C8 mov.w @(0,r11),r0
L_060B83CA:
    st32(c.r[11] + 20, c.r[5]);  // 060B83CA mov.l r5,@(20,r11)
L_060B83CC:
    c.r[0] ^= 0x30u;  // 060B83CC xor #48,r0
L_060B83CE:
    st16(c.r[11], c.r[0]);  // 060B83CE mov.w r0,@(0,r11)
L_060B83D0:
    st32(c.r[11] + 24, c.r[1]);  // 060B83D0 mov.l r1,@(24,r11)
L_060B83D2:
    st32(c.r[11] + 12, c.r[7]);  // 060B83D2 mov.l r7,@(12,r11)
L_060B83D4:
    { const uint32_t x = c.pr; st32(c.r[11] + 16, c.r[9]); c.pc = x; return; }  // 060B83D4 rts ; mov.l r9,@(16,r11)
L_060B83D8:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[11]);  // 060B83D8 mov.w @(0,r11),r0
L_060B83DA:
    st32(c.r[11] + 24, c.r[5]);  // 060B83DA mov.l r5,@(24,r11)
L_060B83DC:
    c.r[0] ^= 0x20u;  // 060B83DC xor #32,r0
L_060B83DE:
    st16(c.r[11], c.r[0]);  // 060B83DE mov.w r0,@(0,r11)
L_060B83E0:
    st32(c.r[11] + 20, c.r[1]);  // 060B83E0 mov.l r1,@(20,r11)
L_060B83E2:
    st32(c.r[11] + 16, c.r[7]);  // 060B83E2 mov.l r7,@(16,r11)
L_060B83E4:
    { const uint32_t x = c.pr; st32(c.r[11] + 12, c.r[9]); c.pc = x; return; }  // 060B83E4 rts ; mov.l r9,@(12,r11)
}

void f_060B81DA(SH2Context& c) {
    ran[3164] = 1;
L_060B81DA:
    c.r[0] = c.r[7];  // 060B81DA mov r7,r0
L_060B81DC:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B81DC shar r0
L_060B81DE:
    c.r[8] += c.r[0];  // 060B81DE add r0,r8
L_060B81E0:
    c.r[0] = c.r[8];  // 060B81E0 mov r8,r0
L_060B81E2:
    c.r[0] += c.r[10];  // 060B81E2 add r10,r0
L_060B81E4:
    c.t = c.r[0] > c.r[13];  // 060B81E4 cmp/hi r13,r0
L_060B81E6:
    { const bool k = c.t; c.r[4] += 32; if (k) { goto L_060B8246; } }  // 060B81E6 bt/s 0x060B8246 ; add #32,r4
L_060B81EA:
    c.r[0] = c.r[3];  // 060B81EA mov r3,r0
L_060B81EC:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B81EC shar r0
L_060B81EE:
    c.r[9] -= c.r[0];  // 060B81EE sub r0,r9
L_060B81F0:
    c.r[0] = c.r[9];  // 060B81F0 mov r9,r0
L_060B81F2:
    c.r[0] += c.r[12];  // 060B81F2 add r12,r0
L_060B81F4:
    c.t = c.r[0] > c.r[14];  // 060B81F4 cmp/hi r14,r0
L_060B81F6:
    { const bool k = c.t; c.r[1] = c.r[8] << 16 | c.r[8] >> 16; if (k) { goto L_060B8246; } }  // 060B81F6 bt/s 0x060B8246 ; swap.w r8,r1
L_060B81FA:
    c.r[8] += c.r[2];  // 060B81FA add r2,r8
L_060B81FC:
    c.r[0] = c.r[8];  // 060B81FC mov r8,r0
L_060B81FE:
    c.r[0] += c.r[10];  // 060B81FE add r10,r0
L_060B8200:
    c.t = c.r[0] > c.r[13];  // 060B8200 cmp/hi r13,r0
L_060B8202:
    { const bool k = c.t; c.r[5] = c.r[9]; if (k) { goto L_060B8246; } }  // 060B8202 bt/s 0x060B8246 ; mov r9,r5
L_060B8206:
    c.r[9] += c.r[6];  // 060B8206 add r6,r9
L_060B8208:
    c.r[0] = c.r[9];  // 060B8208 mov r9,r0
L_060B820A:
    c.r[0] += c.r[12];  // 060B820A add r12,r0
L_060B820C:
    c.t = c.r[0] > c.r[14];  // 060B820C cmp/hi r14,r0
L_060B820E:
    { const bool k = c.t; c.r[0] = c.r[8] << 16 | c.r[8] >> 16; if (k) { goto L_060B8246; } }  // 060B820E bt/s 0x060B8246 ; swap.w r8,r0
L_060B8212:
    c.r[5] = c.r[1] << 16 | c.r[5] >> 16;  // 060B8212 xtrct r1,r5
L_060B8214:
    c.r[1] = c.r[9];  // 060B8214 mov r9,r1
L_060B8216:
    c.r[1] = c.r[0] << 16 | c.r[1] >> 16;  // 060B8216 xtrct r0,r1
L_060B8218:
    c.r[8] -= c.r[7];  // 060B8218 sub r7,r8
L_060B821A:
    c.r[0] = c.r[8];  // 060B821A mov r8,r0
L_060B821C:
    c.r[0] += c.r[10];  // 060B821C add r10,r0
L_060B821E:
    c.t = c.r[0] > c.r[13];  // 060B821E cmp/hi r13,r0
L_060B8220:
    { const bool k = c.t; c.r[9] += c.r[3]; if (k) { goto L_060B8246; } }  // 060B8220 bt/s 0x060B8246 ; add r3,r9
L_060B8224:
    c.r[0] = c.r[9];  // 060B8224 mov r9,r0
L_060B8226:
    c.r[0] += c.r[12];  // 060B8226 add r12,r0
L_060B8228:
    c.t = c.r[0] > c.r[14];  // 060B8228 cmp/hi r14,r0
L_060B822A:
    { const bool k = c.t; c.r[3] = c.r[8] << 16 | c.r[8] >> 16; if (k) { goto L_060B8246; } }  // 060B822A bt/s 0x060B8246 ; swap.w r8,r3
L_060B822E:
    c.r[8] -= c.r[2];  // 060B822E sub r2,r8
L_060B8230:
    c.r[10] += c.r[8];  // 060B8230 add r8,r10
L_060B8232:
    c.t = c.r[10] > c.r[13];  // 060B8232 cmp/hi r13,r10
L_060B8234:
    { const bool k = c.t; c.r[7] = c.r[9]; if (k) { goto L_060B8246; } }  // 060B8234 bt/s 0x060B8246 ; mov r9,r7
L_060B8238:
    c.r[9] -= c.r[6];  // 060B8238 sub r6,r9
L_060B823A:
    c.r[12] += c.r[9];  // 060B823A add r9,r12
L_060B823C:
    c.t = c.r[12] > c.r[14];  // 060B823C cmp/hi r14,r12
L_060B823E:
    { const bool k = c.t; c.r[7] = c.r[3] << 16 | c.r[7] >> 16; if (k) { goto L_060B8246; } }  // 060B823E bt/s 0x060B8246 ; xtrct r3,r7
L_060B8242:
    c.r[8] = c.r[8] << 16 | c.r[8] >> 16; goto L_060B82D8;  // 060B8242 bra 0x060B82D8 ; swap.w r8,r8
L_060B8246:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[11] + 30);  // 060B8246 mov.w @(30,r11),r0
L_060B8248:
    c.r[1] = ld32(c.r[11] + 32);  // 060B8248 mov.l @(32,r11),r1
L_060B824A:
    c.r[2] = (c.r[0] & 0xFFFF0000u) | (c.r[0] & 0xFFu) << 8 | (c.r[0] >> 8 & 0xFFu);  // 060B824A swap.b r0,r2
L_060B824C:
    c.r[0] = ld32(c.gbr + 56);  // 060B824C mov.l @(56,gbr),r0
L_060B824E:
    c.r[2] = c.r[2] & 0xFFu;  // 060B824E extu.b r2,r2
L_060B8250:
    c.r[2] <<= 2;  // 060B8250 shll2 r2
L_060B8252:
    { const uint32_t x = c.pr; st32(c.r[0] + c.r[2], c.r[1]); c.pc = x; return; }  // 060B8252 rts ; mov.l r1,@(r0,r2)
L_060B82D8:
    c.r[0] = c.r[11];  // 060B82D8 mov r11,r0
L_060B82DA:
    c.r[0] += 36;  // 060B82DA add #36,r0
L_060B82DC:
    st32(c.gbr + 52, c.r[0]);  // 060B82DC mov.l r0,@(52,gbr)
L_060B82DE:
    c.r[0] = ld32(c.gbr + 148);  // 060B82DE mov.l @(148,gbr),r0
L_060B82E0:
    c.r[3] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B82E0 exts.w r0,r3
L_060B82E2:
    c.r[2] = c.r[0] << 16 | c.r[0] >> 16;  // 060B82E2 swap.w r0,r2
L_060B82E4:
    c.r[0] = ld32(c.gbr + 816);  // 060B82E4 mov.l @(816,gbr),r0
L_060B82E6:
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 060B82E6 exts.w r2,r2
L_060B82E8:
    c.r[13] = c.r[0] & 0xFFFFu;  // 060B82E8 extu.w r0,r13
L_060B82EA:
    c.r[12] = c.r[0] << 16 | c.r[0] >> 16;  // 060B82EA swap.w r0,r12
L_060B82EC:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B82EC extu.w r12,r12
L_060B82EE:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[5];  // 060B82EE exts.w r5,r0
L_060B82F0:
    c.r[0] += c.r[3];  // 060B82F0 add r3,r0
L_060B82F2:
    c.t = c.r[0] >= c.r[13];  // 060B82F2 cmp/hs r13,r0
L_060B82F4:
    { const bool k = c.t; c.r[9] = c.r[8] << 16 | c.r[9] >> 16; if (k) { goto L_060B8302; } }  // 060B82F4 bt/s 0x060B8302 ; xtrct r8,r9
L_060B82F8:
    c.r[0] = c.r[5] << 16 | c.r[5] >> 16;  // 060B82F8 swap.w r5,r0
L_060B82FA:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B82FA exts.w r0,r0
L_060B82FC:
    c.r[0] += c.r[2];  // 060B82FC add r2,r0
L_060B82FE:
    c.t = c.r[12] > c.r[0];  // 060B82FE cmp/hi r0,r12
L_060B8300:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[1]; if (k) { goto L_060B83AE; } }  // 060B8300 bt/s 0x060B83AE ; exts.w r1,r0
    goto L_060B8304;
L_060B8302:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 060B8302 exts.w r1,r0
L_060B8304:
    c.r[0] += c.r[3];  // 060B8304 add r3,r0
L_060B8306:
    c.t = c.r[0] >= c.r[13];  // 060B8306 cmp/hs r13,r0
L_060B8308:
    { const bool k = c.t; c.r[0] = c.r[1] << 16 | c.r[1] >> 16; if (k) { goto L_060B8314; } }  // 060B8308 bt/s 0x060B8314 ; swap.w r1,r0
L_060B830C:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B830C exts.w r0,r0
L_060B830E:
    c.r[0] += c.r[2];  // 060B830E add r2,r0
L_060B8310:
    c.t = c.r[12] > c.r[0];  // 060B8310 cmp/hi r0,r12
L_060B8312:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[7]; if (k) { goto L_060B83B8; } }  // 060B8312 bt/s 0x060B83B8 ; exts.w r7,r0
    goto L_060B8316;
L_060B8314:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[7];  // 060B8314 exts.w r7,r0
L_060B8316:
    c.r[0] += c.r[3];  // 060B8316 add r3,r0
L_060B8318:
    c.t = c.r[0] >= c.r[13];  // 060B8318 cmp/hs r13,r0
L_060B831A:
    { const bool k = c.t; c.r[0] = c.r[7] << 16 | c.r[7] >> 16; if (k) { goto L_060B8326; } }  // 060B831A bt/s 0x060B8326 ; swap.w r7,r0
L_060B831E:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B831E exts.w r0,r0
L_060B8320:
    c.r[0] += c.r[2];  // 060B8320 add r2,r0
L_060B8322:
    c.t = c.r[12] > c.r[0];  // 060B8322 cmp/hi r0,r12
L_060B8324:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[9]; if (k) { goto L_060B83C8; } }  // 060B8324 bt/s 0x060B83C8 ; exts.w r9,r0
    goto L_060B8328;
L_060B8326:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[9];  // 060B8326 exts.w r9,r0
L_060B8328:
    c.r[0] += c.r[3];  // 060B8328 add r3,r0
L_060B832A:
    c.t = c.r[0] >= c.r[13];  // 060B832A cmp/hs r13,r0
L_060B832C:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[8]; if (k) { goto L_060B8336; } }  // 060B832C bt/s 0x060B8336 ; exts.w r8,r0
L_060B8330:
    c.r[0] += c.r[2];  // 060B8330 add r2,r0
L_060B8332:
    c.t = c.r[12] > c.r[0];  // 060B8332 cmp/hi r0,r12
L_060B8334:
    { const bool k = c.t; c.r[8] = 0x1u; if (k) { goto L_060B83D8; } }  // 060B8334 bt/s 0x060B83D8 ; mov #1,r8
    goto L_060B8338;
L_060B8336:
    c.r[8] = 0x1u;  // 060B8336 mov #1,r8
L_060B8338:
    c.r[8] <<= 16;  // 060B8338 shll16 r8
L_060B833A:
    c.t = c.r[8] & 1; c.r[8] >>= 1;  // 060B833A shlr r8
L_060B833C:
    c.r[2] = c.r[9] << 16 | c.r[9] >> 16;  // 060B833C swap.w r9,r2
L_060B833E:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B833E tst r8,r2
L_060B8340:
    { uint32_t a = c.r[13], b = c.r[13], t = c.t; c.r[13] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B8340 subc r13,r13
L_060B8342:
    c.r[13] = ~c.r[13];  // 060B8342 not r13,r13
L_060B8344:
    c.r[13] ^= c.r[2];  // 060B8344 xor r2,r13
L_060B8346:
    c.t = (c.r[9] & c.r[8]) == 0;  // 060B8346 tst r8,r9
L_060B8348:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B8348 subc r2,r2
L_060B834A:
    c.r[2] = ~c.r[2];  // 060B834A not r2,r2
L_060B834C:
    c.r[2] ^= c.r[9];  // 060B834C xor r9,r2
L_060B834E:
    c.r[13] += c.r[2];  // 060B834E add r2,r13
L_060B8350:
    c.r[13] = c.r[13] & 0xFFFFu;  // 060B8350 extu.w r13,r13
L_060B8352:
    c.r[0] = 0x060B83D8u;  // 060B8352 mova 0x060B83D8,r0
L_060B8354:
    c.r[2] = c.r[7] << 16 | c.r[7] >> 16;  // 060B8354 swap.w r7,r2
L_060B8356:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B8356 tst r8,r2
L_060B8358:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B8358 subc r12,r12
L_060B835A:
    c.r[12] = ~c.r[12];  // 060B835A not r12,r12
L_060B835C:
    c.r[12] ^= c.r[2];  // 060B835C xor r2,r12
L_060B835E:
    c.t = (c.r[7] & c.r[8]) == 0;  // 060B835E tst r8,r7
L_060B8360:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B8360 subc r2,r2
L_060B8362:
    c.r[2] = ~c.r[2];  // 060B8362 not r2,r2
L_060B8364:
    c.r[2] ^= c.r[7];  // 060B8364 xor r7,r2
L_060B8366:
    c.r[12] += c.r[2];  // 060B8366 add r2,r12
L_060B8368:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B8368 extu.w r12,r12
L_060B836A:
    c.t = (int32_t)c.r[12] > (int32_t)c.r[13];  // 060B836A cmp/gt r13,r12
L_060B836C:
    { const bool k = c.t; c.r[2] = c.r[1] << 16 | c.r[1] >> 16; if (k) { goto L_060B8374; } }  // 060B836C bt/s 0x060B8374 ; swap.w r1,r2
L_060B8370:
    c.r[13] = c.r[12];  // 060B8370 mov r12,r13
L_060B8372:
    c.r[0] = 0x060B83C8u;  // 060B8372 mova 0x060B83C8,r0
L_060B8374:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B8374 tst r8,r2
L_060B8376:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B8376 subc r12,r12
L_060B8378:
    c.r[12] = ~c.r[12];  // 060B8378 not r12,r12
L_060B837A:
    c.r[12] ^= c.r[2];  // 060B837A xor r2,r12
L_060B837C:
    c.t = (c.r[1] & c.r[8]) == 0;  // 060B837C tst r8,r1
L_060B837E:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B837E subc r2,r2
L_060B8380:
    c.r[2] = ~c.r[2];  // 060B8380 not r2,r2
L_060B8382:
    c.r[2] ^= c.r[1];  // 060B8382 xor r1,r2
L_060B8384:
    c.r[12] += c.r[2];  // 060B8384 add r2,r12
L_060B8386:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B8386 extu.w r12,r12
L_060B8388:
    c.t = (int32_t)c.r[12] > (int32_t)c.r[13];  // 060B8388 cmp/gt r13,r12
L_060B838A:
    { const bool k = c.t; c.r[2] = c.r[5] << 16 | c.r[5] >> 16; if (k) { goto L_060B8392; } }  // 060B838A bt/s 0x060B8392 ; swap.w r5,r2
L_060B838E:
    c.r[13] = c.r[12];  // 060B838E mov r12,r13
L_060B8390:
    c.r[0] = 0x060B83C8u;  // 060B8390 mova 0x060B83C8,r0
L_060B8392:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B8392 tst r8,r2
L_060B8394:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B8394 subc r12,r12
L_060B8396:
    c.r[12] = ~c.r[12];  // 060B8396 not r12,r12
L_060B8398:
    c.r[12] ^= c.r[2];  // 060B8398 xor r2,r12
L_060B839A:
    c.t = (c.r[5] & c.r[8]) == 0;  // 060B839A tst r8,r5
L_060B839C:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B839C subc r2,r2
L_060B839E:
    c.r[2] = ~c.r[2];  // 060B839E not r2,r2
L_060B83A0:
    c.r[2] ^= c.r[5];  // 060B83A0 xor r5,r2
L_060B83A2:
    c.r[12] += c.r[2];  // 060B83A2 add r2,r12
L_060B83A4:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B83A4 extu.w r12,r12
L_060B83A6:
    c.t = (int32_t)c.r[13] >= (int32_t)c.r[12];  // 060B83A6 cmp/ge r12,r13
L_060B83A8:
    if (c.t) { goto L_060B83AE; }  // 060B83A8 bt 0x060B83AE
L_060B83AA:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x060B81DAu: goto L_060B81DA; case 0x060B81DCu: goto L_060B81DC; case 0x060B81DEu: goto L_060B81DE; case 0x060B81E0u: goto L_060B81E0; case 0x060B81E2u: goto L_060B81E2; case 0x060B81E4u: goto L_060B81E4; case 0x060B81E6u: goto L_060B81E6; case 0x060B81EAu: goto L_060B81EA; case 0x060B81ECu: goto L_060B81EC; case 0x060B81EEu: goto L_060B81EE; case 0x060B81F0u: goto L_060B81F0; case 0x060B81F2u: goto L_060B81F2; case 0x060B81F4u: goto L_060B81F4; case 0x060B81F6u: goto L_060B81F6; case 0x060B81FAu: goto L_060B81FA; case 0x060B81FCu: goto L_060B81FC; case 0x060B81FEu: goto L_060B81FE; case 0x060B8200u: goto L_060B8200; case 0x060B8202u: goto L_060B8202; case 0x060B8206u: goto L_060B8206; case 0x060B8208u: goto L_060B8208; case 0x060B820Au: goto L_060B820A; case 0x060B820Cu: goto L_060B820C; case 0x060B820Eu: goto L_060B820E; case 0x060B8212u: goto L_060B8212; case 0x060B8214u: goto L_060B8214; case 0x060B8216u: goto L_060B8216; case 0x060B8218u: goto L_060B8218; case 0x060B821Au: goto L_060B821A; case 0x060B821Cu: goto L_060B821C; case 0x060B821Eu: goto L_060B821E; case 0x060B8220u: goto L_060B8220; case 0x060B8224u: goto L_060B8224; case 0x060B8226u: goto L_060B8226; case 0x060B8228u: goto L_060B8228; case 0x060B822Au: goto L_060B822A; case 0x060B822Eu: goto L_060B822E; case 0x060B8230u: goto L_060B8230; case 0x060B8232u: goto L_060B8232; case 0x060B8234u: goto L_060B8234; case 0x060B8238u: goto L_060B8238; case 0x060B823Au: goto L_060B823A; case 0x060B823Cu: goto L_060B823C; case 0x060B823Eu: goto L_060B823E; case 0x060B8242u: goto L_060B8242; case 0x060B8246u: goto L_060B8246; case 0x060B8248u: goto L_060B8248; case 0x060B824Au: goto L_060B824A; case 0x060B824Cu: goto L_060B824C; case 0x060B824Eu: goto L_060B824E; case 0x060B8250u: goto L_060B8250; case 0x060B8252u: goto L_060B8252; case 0x060B82D8u: goto L_060B82D8; case 0x060B82DAu: goto L_060B82DA; case 0x060B82DCu: goto L_060B82DC; case 0x060B82DEu: goto L_060B82DE; case 0x060B82E0u: goto L_060B82E0; case 0x060B82E2u: goto L_060B82E2; case 0x060B82E4u: goto L_060B82E4; case 0x060B82E6u: goto L_060B82E6; case 0x060B82E8u: goto L_060B82E8; case 0x060B82EAu: goto L_060B82EA; case 0x060B82ECu: goto L_060B82EC; case 0x060B82EEu: goto L_060B82EE; case 0x060B82F0u: goto L_060B82F0; case 0x060B82F2u: goto L_060B82F2; case 0x060B82F4u: goto L_060B82F4; case 0x060B82F8u: goto L_060B82F8; case 0x060B82FAu: goto L_060B82FA; case 0x060B82FCu: goto L_060B82FC; case 0x060B82FEu: goto L_060B82FE; case 0x060B8300u: goto L_060B8300; case 0x060B8304u: goto L_060B8304; case 0x060B8306u: goto L_060B8306; case 0x060B8308u: goto L_060B8308; case 0x060B830Cu: goto L_060B830C; case 0x060B830Eu: goto L_060B830E; case 0x060B8310u: goto L_060B8310; case 0x060B8312u: goto L_060B8312; case 0x060B8316u: goto L_060B8316; case 0x060B8318u: goto L_060B8318; case 0x060B831Au: goto L_060B831A; case 0x060B831Eu: goto L_060B831E; case 0x060B8320u: goto L_060B8320; case 0x060B8322u: goto L_060B8322; case 0x060B8324u: goto L_060B8324; case 0x060B8328u: goto L_060B8328; case 0x060B832Au: goto L_060B832A; case 0x060B832Cu: goto L_060B832C; case 0x060B8330u: goto L_060B8330; case 0x060B8332u: goto L_060B8332; case 0x060B8334u: goto L_060B8334; case 0x060B8338u: goto L_060B8338; case 0x060B833Au: goto L_060B833A; case 0x060B833Cu: goto L_060B833C; case 0x060B833Eu: goto L_060B833E; case 0x060B8340u: goto L_060B8340; case 0x060B8342u: goto L_060B8342; case 0x060B8344u: goto L_060B8344; case 0x060B8346u: goto L_060B8346; case 0x060B8348u: goto L_060B8348; case 0x060B834Au: goto L_060B834A; case 0x060B834Cu: goto L_060B834C; case 0x060B834Eu: goto L_060B834E; case 0x060B8350u: goto L_060B8350; case 0x060B8352u: goto L_060B8352; case 0x060B8354u: goto L_060B8354; case 0x060B8356u: goto L_060B8356; case 0x060B8358u: goto L_060B8358; case 0x060B835Au: goto L_060B835A; case 0x060B835Cu: goto L_060B835C; case 0x060B835Eu: goto L_060B835E; case 0x060B8360u: goto L_060B8360; case 0x060B8362u: goto L_060B8362; case 0x060B8364u: goto L_060B8364; case 0x060B8366u: goto L_060B8366; case 0x060B8368u: goto L_060B8368; case 0x060B836Au: goto L_060B836A; case 0x060B836Cu: goto L_060B836C; case 0x060B8370u: goto L_060B8370; case 0x060B8372u: goto L_060B8372; case 0x060B8374u: goto L_060B8374; case 0x060B8376u: goto L_060B8376; case 0x060B8378u: goto L_060B8378; case 0x060B837Au: goto L_060B837A; case 0x060B837Cu: goto L_060B837C; case 0x060B837Eu: goto L_060B837E; case 0x060B8380u: goto L_060B8380; case 0x060B8382u: goto L_060B8382; case 0x060B8384u: goto L_060B8384; case 0x060B8386u: goto L_060B8386; case 0x060B8388u: goto L_060B8388; case 0x060B838Au: goto L_060B838A; case 0x060B838Eu: goto L_060B838E; case 0x060B8390u: goto L_060B8390; case 0x060B8392u: goto L_060B8392; case 0x060B8394u: goto L_060B8394; case 0x060B8396u: goto L_060B8396; case 0x060B8398u: goto L_060B8398; case 0x060B839Au: goto L_060B839A; case 0x060B839Cu: goto L_060B839C; case 0x060B839Eu: goto L_060B839E; case 0x060B83A0u: goto L_060B83A0; case 0x060B83A2u: goto L_060B83A2; case 0x060B83A4u: goto L_060B83A4; case 0x060B83A6u: goto L_060B83A6; case 0x060B83A8u: goto L_060B83A8; case 0x060B83AAu: goto L_060B83AA; case 0x060B83AEu: goto L_060B83AE; case 0x060B83B0u: goto L_060B83B0; case 0x060B83B2u: goto L_060B83B2; case 0x060B83B4u: goto L_060B83B4; case 0x060B83B8u: goto L_060B83B8; case 0x060B83BAu: goto L_060B83BA; case 0x060B83BCu: goto L_060B83BC; case 0x060B83BEu: goto L_060B83BE; case 0x060B83C0u: goto L_060B83C0; case 0x060B83C2u: goto L_060B83C2; case 0x060B83C4u: goto L_060B83C4; case 0x060B83C8u: goto L_060B83C8; case 0x060B83CAu: goto L_060B83CA; case 0x060B83CCu: goto L_060B83CC; case 0x060B83CEu: goto L_060B83CE; case 0x060B83D0u: goto L_060B83D0; case 0x060B83D2u: goto L_060B83D2; case 0x060B83D4u: goto L_060B83D4; case 0x060B83D8u: goto L_060B83D8; case 0x060B83DAu: goto L_060B83DA; case 0x060B83DCu: goto L_060B83DC; case 0x060B83DEu: goto L_060B83DE; case 0x060B83E0u: goto L_060B83E0; case 0x060B83E2u: goto L_060B83E2; case 0x060B83E4u: goto L_060B83E4; default: sh2_call(c, x); return; } }  // 060B83AA jmp @r0 ; nop
L_060B83AE:
    st32(c.r[11] + 12, c.r[5]);  // 060B83AE mov.l r5,@(12,r11)
L_060B83B0:
    st32(c.r[11] + 16, c.r[1]);  // 060B83B0 mov.l r1,@(16,r11)
L_060B83B2:
    st32(c.r[11] + 20, c.r[7]);  // 060B83B2 mov.l r7,@(20,r11)
L_060B83B4:
    { const uint32_t x = c.pr; st32(c.r[11] + 24, c.r[9]); c.pc = x; return; }  // 060B83B4 rts ; mov.l r9,@(24,r11)
L_060B83B8:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[11]);  // 060B83B8 mov.w @(0,r11),r0
L_060B83BA:
    st32(c.r[11] + 16, c.r[5]);  // 060B83BA mov.l r5,@(16,r11)
L_060B83BC:
    c.r[0] ^= 0x10u;  // 060B83BC xor #16,r0
L_060B83BE:
    st16(c.r[11], c.r[0]);  // 060B83BE mov.w r0,@(0,r11)
L_060B83C0:
    st32(c.r[11] + 12, c.r[1]);  // 060B83C0 mov.l r1,@(12,r11)
L_060B83C2:
    st32(c.r[11] + 24, c.r[7]);  // 060B83C2 mov.l r7,@(24,r11)
L_060B83C4:
    { const uint32_t x = c.pr; st32(c.r[11] + 20, c.r[9]); c.pc = x; return; }  // 060B83C4 rts ; mov.l r9,@(20,r11)
L_060B83C8:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[11]);  // 060B83C8 mov.w @(0,r11),r0
L_060B83CA:
    st32(c.r[11] + 20, c.r[5]);  // 060B83CA mov.l r5,@(20,r11)
L_060B83CC:
    c.r[0] ^= 0x30u;  // 060B83CC xor #48,r0
L_060B83CE:
    st16(c.r[11], c.r[0]);  // 060B83CE mov.w r0,@(0,r11)
L_060B83D0:
    st32(c.r[11] + 24, c.r[1]);  // 060B83D0 mov.l r1,@(24,r11)
L_060B83D2:
    st32(c.r[11] + 12, c.r[7]);  // 060B83D2 mov.l r7,@(12,r11)
L_060B83D4:
    { const uint32_t x = c.pr; st32(c.r[11] + 16, c.r[9]); c.pc = x; return; }  // 060B83D4 rts ; mov.l r9,@(16,r11)
L_060B83D8:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[11]);  // 060B83D8 mov.w @(0,r11),r0
L_060B83DA:
    st32(c.r[11] + 24, c.r[5]);  // 060B83DA mov.l r5,@(24,r11)
L_060B83DC:
    c.r[0] ^= 0x20u;  // 060B83DC xor #32,r0
L_060B83DE:
    st16(c.r[11], c.r[0]);  // 060B83DE mov.w r0,@(0,r11)
L_060B83E0:
    st32(c.r[11] + 20, c.r[1]);  // 060B83E0 mov.l r1,@(20,r11)
L_060B83E2:
    st32(c.r[11] + 16, c.r[7]);  // 060B83E2 mov.l r7,@(16,r11)
L_060B83E4:
    { const uint32_t x = c.pr; st32(c.r[11] + 12, c.r[9]); c.pc = x; return; }  // 060B83E4 rts ; mov.l r9,@(12,r11)
}

void f_060B8256(SH2Context& c) {
    ran[3165] = 1;
    goto L_060B8256;
L_060B8246:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[11] + 30);  // 060B8246 mov.w @(30,r11),r0
L_060B8248:
    c.r[1] = ld32(c.r[11] + 32);  // 060B8248 mov.l @(32,r11),r1
L_060B824A:
    c.r[2] = (c.r[0] & 0xFFFF0000u) | (c.r[0] & 0xFFu) << 8 | (c.r[0] >> 8 & 0xFFu);  // 060B824A swap.b r0,r2
L_060B824C:
    c.r[0] = ld32(c.gbr + 56);  // 060B824C mov.l @(56,gbr),r0
L_060B824E:
    c.r[2] = c.r[2] & 0xFFu;  // 060B824E extu.b r2,r2
L_060B8250:
    c.r[2] <<= 2;  // 060B8250 shll2 r2
L_060B8252:
    { const uint32_t x = c.pr; st32(c.r[0] + c.r[2], c.r[1]); c.pc = x; return; }  // 060B8252 rts ; mov.l r1,@(r0,r2)
L_060B8256:
    c.r[5] = (c.r[5] & 0xFFFF0000u) | (c.r[5] & 0xFFu) << 8 | (c.r[5] >> 8 & 0xFFu);  // 060B8256 swap.b r5,r5
L_060B8258:
    c.r[0] = 0xFFFFFFF0u;  // 060B8258 mov #-16,r0
L_060B825A:
    c.r[0] &= c.r[5];  // 060B825A and r5,r0
L_060B825C:
    c.r[0] |= 0xAu;  // 060B825C or #10,r0
L_060B825E:
    c.r[0] = (c.r[0] & 0xFFFF0000u) | (c.r[0] & 0xFFu) << 8 | (c.r[0] >> 8 & 0xFFu);  // 060B825E swap.b r0,r0
L_060B8260:
    st16(c.r[11], c.r[0]);  // 060B8260 mov.w r0,@(0,r11)
L_060B8262:
    c.r[0] = c.r[2];  // 060B8262 mov r2,r0
L_060B8264:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B8264 shar r0
L_060B8266:
    c.r[8] -= c.r[0];  // 060B8266 sub r0,r8
L_060B8268:
    c.r[0] = c.r[7];  // 060B8268 mov r7,r0
L_060B826A:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B826A shar r0
L_060B826C:
    c.r[8] += c.r[0];  // 060B826C add r0,r8
L_060B826E:
    c.r[0] = c.r[8];  // 060B826E mov r8,r0
L_060B8270:
    c.r[0] += c.r[10];  // 060B8270 add r10,r0
L_060B8272:
    c.t = c.r[0] > c.r[13];  // 060B8272 cmp/hi r13,r0
L_060B8274:
    { const bool k = c.t; c.r[4] += 32; if (k) { SH2_POLL(c); goto L_060B8246; } }  // 060B8274 bt/s 0x060B8246 ; add #32,r4
L_060B8278:
    c.r[0] = c.r[3];  // 060B8278 mov r3,r0
L_060B827A:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B827A shar r0
L_060B827C:
    c.r[9] -= c.r[0];  // 060B827C sub r0,r9
L_060B827E:
    c.r[0] = c.r[6];  // 060B827E mov r6,r0
L_060B8280:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B8280 shar r0
L_060B8282:
    c.r[9] -= c.r[0];  // 060B8282 sub r0,r9
L_060B8284:
    c.r[0] = c.r[9];  // 060B8284 mov r9,r0
L_060B8286:
    c.r[0] += c.r[12];  // 060B8286 add r12,r0
L_060B8288:
    c.t = c.r[0] > c.r[14];  // 060B8288 cmp/hi r14,r0
L_060B828A:
    { const bool k = c.t; c.r[1] = c.r[8] << 16 | c.r[8] >> 16; if (k) { SH2_POLL(c); goto L_060B8246; } }  // 060B828A bt/s 0x060B8246 ; swap.w r8,r1
L_060B828E:
    c.r[8] += c.r[2];  // 060B828E add r2,r8
L_060B8290:
    c.r[0] = c.r[8];  // 060B8290 mov r8,r0
L_060B8292:
    c.r[0] += c.r[10];  // 060B8292 add r10,r0
L_060B8294:
    c.t = c.r[0] > c.r[13];  // 060B8294 cmp/hi r13,r0
L_060B8296:
    { const bool k = c.t; c.r[5] = c.r[9]; if (k) { SH2_POLL(c); goto L_060B8246; } }  // 060B8296 bt/s 0x060B8246 ; mov r9,r5
L_060B829A:
    c.r[5] = c.r[1] << 16 | c.r[5] >> 16;  // 060B829A xtrct r1,r5
L_060B829C:
    c.r[9] += c.r[6];  // 060B829C add r6,r9
L_060B829E:
    c.r[0] = c.r[9];  // 060B829E mov r9,r0
L_060B82A0:
    c.r[0] += c.r[12];  // 060B82A0 add r12,r0
L_060B82A2:
    c.t = c.r[0] > c.r[14];  // 060B82A2 cmp/hi r14,r0
L_060B82A4:
    { const bool k = c.t; c.r[0] = c.r[8] << 16 | c.r[8] >> 16; if (k) { SH2_POLL(c); goto L_060B8246; } }  // 060B82A4 bt/s 0x060B8246 ; swap.w r8,r0
L_060B82A8:
    c.r[1] = c.r[9];  // 060B82A8 mov r9,r1
L_060B82AA:
    c.r[1] = c.r[0] << 16 | c.r[1] >> 16;  // 060B82AA xtrct r0,r1
L_060B82AC:
    c.r[8] -= c.r[7];  // 060B82AC sub r7,r8
L_060B82AE:
    c.r[0] = c.r[8];  // 060B82AE mov r8,r0
L_060B82B0:
    c.r[0] += c.r[10];  // 060B82B0 add r10,r0
L_060B82B2:
    c.t = c.r[0] > c.r[13];  // 060B82B2 cmp/hi r13,r0
L_060B82B4:
    { const bool k = c.t; c.r[9] += c.r[3]; if (k) { SH2_POLL(c); goto L_060B8246; } }  // 060B82B4 bt/s 0x060B8246 ; add r3,r9
L_060B82B8:
    c.r[0] = c.r[9];  // 060B82B8 mov r9,r0
L_060B82BA:
    c.r[0] += c.r[12];  // 060B82BA add r12,r0
L_060B82BC:
    c.t = c.r[0] > c.r[14];  // 060B82BC cmp/hi r14,r0
L_060B82BE:
    { const bool k = c.t; c.r[3] = c.r[8] << 16 | c.r[8] >> 16; if (k) { SH2_POLL(c); goto L_060B8246; } }  // 060B82BE bt/s 0x060B8246 ; swap.w r8,r3
L_060B82C2:
    c.r[8] -= c.r[2];  // 060B82C2 sub r2,r8
L_060B82C4:
    c.r[10] += c.r[8];  // 060B82C4 add r8,r10
L_060B82C6:
    c.t = c.r[10] > c.r[13];  // 060B82C6 cmp/hi r13,r10
L_060B82C8:
    { const bool k = c.t; c.r[7] = c.r[9]; if (k) { SH2_POLL(c); goto L_060B8246; } }  // 060B82C8 bt/s 0x060B8246 ; mov r9,r7
L_060B82CC:
    c.r[9] -= c.r[6];  // 060B82CC sub r6,r9
L_060B82CE:
    c.r[12] += c.r[9];  // 060B82CE add r9,r12
L_060B82D0:
    c.t = c.r[12] > c.r[14];  // 060B82D0 cmp/hi r14,r12
L_060B82D2:
    { const bool k = c.t; c.r[7] = c.r[3] << 16 | c.r[7] >> 16; if (k) { SH2_POLL(c); goto L_060B8246; } }  // 060B82D2 bt/s 0x060B8246 ; xtrct r3,r7
L_060B82D6:
    c.r[8] = c.r[8] << 16 | c.r[8] >> 16;  // 060B82D6 swap.w r8,r8
L_060B82D8:
    c.r[0] = c.r[11];  // 060B82D8 mov r11,r0
L_060B82DA:
    c.r[0] += 36;  // 060B82DA add #36,r0
L_060B82DC:
    st32(c.gbr + 52, c.r[0]);  // 060B82DC mov.l r0,@(52,gbr)
L_060B82DE:
    c.r[0] = ld32(c.gbr + 148);  // 060B82DE mov.l @(148,gbr),r0
L_060B82E0:
    c.r[3] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B82E0 exts.w r0,r3
L_060B82E2:
    c.r[2] = c.r[0] << 16 | c.r[0] >> 16;  // 060B82E2 swap.w r0,r2
L_060B82E4:
    c.r[0] = ld32(c.gbr + 816);  // 060B82E4 mov.l @(816,gbr),r0
L_060B82E6:
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 060B82E6 exts.w r2,r2
L_060B82E8:
    c.r[13] = c.r[0] & 0xFFFFu;  // 060B82E8 extu.w r0,r13
L_060B82EA:
    c.r[12] = c.r[0] << 16 | c.r[0] >> 16;  // 060B82EA swap.w r0,r12
L_060B82EC:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B82EC extu.w r12,r12
L_060B82EE:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[5];  // 060B82EE exts.w r5,r0
L_060B82F0:
    c.r[0] += c.r[3];  // 060B82F0 add r3,r0
L_060B82F2:
    c.t = c.r[0] >= c.r[13];  // 060B82F2 cmp/hs r13,r0
L_060B82F4:
    { const bool k = c.t; c.r[9] = c.r[8] << 16 | c.r[9] >> 16; if (k) { goto L_060B8302; } }  // 060B82F4 bt/s 0x060B8302 ; xtrct r8,r9
L_060B82F8:
    c.r[0] = c.r[5] << 16 | c.r[5] >> 16;  // 060B82F8 swap.w r5,r0
L_060B82FA:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B82FA exts.w r0,r0
L_060B82FC:
    c.r[0] += c.r[2];  // 060B82FC add r2,r0
L_060B82FE:
    c.t = c.r[12] > c.r[0];  // 060B82FE cmp/hi r0,r12
L_060B8300:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[1]; if (k) { goto L_060B83AE; } }  // 060B8300 bt/s 0x060B83AE ; exts.w r1,r0
    goto L_060B8304;
L_060B8302:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 060B8302 exts.w r1,r0
L_060B8304:
    c.r[0] += c.r[3];  // 060B8304 add r3,r0
L_060B8306:
    c.t = c.r[0] >= c.r[13];  // 060B8306 cmp/hs r13,r0
L_060B8308:
    { const bool k = c.t; c.r[0] = c.r[1] << 16 | c.r[1] >> 16; if (k) { goto L_060B8314; } }  // 060B8308 bt/s 0x060B8314 ; swap.w r1,r0
L_060B830C:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B830C exts.w r0,r0
L_060B830E:
    c.r[0] += c.r[2];  // 060B830E add r2,r0
L_060B8310:
    c.t = c.r[12] > c.r[0];  // 060B8310 cmp/hi r0,r12
L_060B8312:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[7]; if (k) { goto L_060B83B8; } }  // 060B8312 bt/s 0x060B83B8 ; exts.w r7,r0
    goto L_060B8316;
L_060B8314:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[7];  // 060B8314 exts.w r7,r0
L_060B8316:
    c.r[0] += c.r[3];  // 060B8316 add r3,r0
L_060B8318:
    c.t = c.r[0] >= c.r[13];  // 060B8318 cmp/hs r13,r0
L_060B831A:
    { const bool k = c.t; c.r[0] = c.r[7] << 16 | c.r[7] >> 16; if (k) { goto L_060B8326; } }  // 060B831A bt/s 0x060B8326 ; swap.w r7,r0
L_060B831E:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B831E exts.w r0,r0
L_060B8320:
    c.r[0] += c.r[2];  // 060B8320 add r2,r0
L_060B8322:
    c.t = c.r[12] > c.r[0];  // 060B8322 cmp/hi r0,r12
L_060B8324:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[9]; if (k) { goto L_060B83C8; } }  // 060B8324 bt/s 0x060B83C8 ; exts.w r9,r0
    goto L_060B8328;
L_060B8326:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[9];  // 060B8326 exts.w r9,r0
L_060B8328:
    c.r[0] += c.r[3];  // 060B8328 add r3,r0
L_060B832A:
    c.t = c.r[0] >= c.r[13];  // 060B832A cmp/hs r13,r0
L_060B832C:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[8]; if (k) { goto L_060B8336; } }  // 060B832C bt/s 0x060B8336 ; exts.w r8,r0
L_060B8330:
    c.r[0] += c.r[2];  // 060B8330 add r2,r0
L_060B8332:
    c.t = c.r[12] > c.r[0];  // 060B8332 cmp/hi r0,r12
L_060B8334:
    { const bool k = c.t; c.r[8] = 0x1u; if (k) { goto L_060B83D8; } }  // 060B8334 bt/s 0x060B83D8 ; mov #1,r8
    goto L_060B8338;
L_060B8336:
    c.r[8] = 0x1u;  // 060B8336 mov #1,r8
L_060B8338:
    c.r[8] <<= 16;  // 060B8338 shll16 r8
L_060B833A:
    c.t = c.r[8] & 1; c.r[8] >>= 1;  // 060B833A shlr r8
L_060B833C:
    c.r[2] = c.r[9] << 16 | c.r[9] >> 16;  // 060B833C swap.w r9,r2
L_060B833E:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B833E tst r8,r2
L_060B8340:
    { uint32_t a = c.r[13], b = c.r[13], t = c.t; c.r[13] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B8340 subc r13,r13
L_060B8342:
    c.r[13] = ~c.r[13];  // 060B8342 not r13,r13
L_060B8344:
    c.r[13] ^= c.r[2];  // 060B8344 xor r2,r13
L_060B8346:
    c.t = (c.r[9] & c.r[8]) == 0;  // 060B8346 tst r8,r9
L_060B8348:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B8348 subc r2,r2
L_060B834A:
    c.r[2] = ~c.r[2];  // 060B834A not r2,r2
L_060B834C:
    c.r[2] ^= c.r[9];  // 060B834C xor r9,r2
L_060B834E:
    c.r[13] += c.r[2];  // 060B834E add r2,r13
L_060B8350:
    c.r[13] = c.r[13] & 0xFFFFu;  // 060B8350 extu.w r13,r13
L_060B8352:
    c.r[0] = 0x060B83D8u;  // 060B8352 mova 0x060B83D8,r0
L_060B8354:
    c.r[2] = c.r[7] << 16 | c.r[7] >> 16;  // 060B8354 swap.w r7,r2
L_060B8356:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B8356 tst r8,r2
L_060B8358:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B8358 subc r12,r12
L_060B835A:
    c.r[12] = ~c.r[12];  // 060B835A not r12,r12
L_060B835C:
    c.r[12] ^= c.r[2];  // 060B835C xor r2,r12
L_060B835E:
    c.t = (c.r[7] & c.r[8]) == 0;  // 060B835E tst r8,r7
L_060B8360:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B8360 subc r2,r2
L_060B8362:
    c.r[2] = ~c.r[2];  // 060B8362 not r2,r2
L_060B8364:
    c.r[2] ^= c.r[7];  // 060B8364 xor r7,r2
L_060B8366:
    c.r[12] += c.r[2];  // 060B8366 add r2,r12
L_060B8368:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B8368 extu.w r12,r12
L_060B836A:
    c.t = (int32_t)c.r[12] > (int32_t)c.r[13];  // 060B836A cmp/gt r13,r12
L_060B836C:
    { const bool k = c.t; c.r[2] = c.r[1] << 16 | c.r[1] >> 16; if (k) { goto L_060B8374; } }  // 060B836C bt/s 0x060B8374 ; swap.w r1,r2
L_060B8370:
    c.r[13] = c.r[12];  // 060B8370 mov r12,r13
L_060B8372:
    c.r[0] = 0x060B83C8u;  // 060B8372 mova 0x060B83C8,r0
L_060B8374:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B8374 tst r8,r2
L_060B8376:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B8376 subc r12,r12
L_060B8378:
    c.r[12] = ~c.r[12];  // 060B8378 not r12,r12
L_060B837A:
    c.r[12] ^= c.r[2];  // 060B837A xor r2,r12
L_060B837C:
    c.t = (c.r[1] & c.r[8]) == 0;  // 060B837C tst r8,r1
L_060B837E:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B837E subc r2,r2
L_060B8380:
    c.r[2] = ~c.r[2];  // 060B8380 not r2,r2
L_060B8382:
    c.r[2] ^= c.r[1];  // 060B8382 xor r1,r2
L_060B8384:
    c.r[12] += c.r[2];  // 060B8384 add r2,r12
L_060B8386:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B8386 extu.w r12,r12
L_060B8388:
    c.t = (int32_t)c.r[12] > (int32_t)c.r[13];  // 060B8388 cmp/gt r13,r12
L_060B838A:
    { const bool k = c.t; c.r[2] = c.r[5] << 16 | c.r[5] >> 16; if (k) { goto L_060B8392; } }  // 060B838A bt/s 0x060B8392 ; swap.w r5,r2
L_060B838E:
    c.r[13] = c.r[12];  // 060B838E mov r12,r13
L_060B8390:
    c.r[0] = 0x060B83C8u;  // 060B8390 mova 0x060B83C8,r0
L_060B8392:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B8392 tst r8,r2
L_060B8394:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B8394 subc r12,r12
L_060B8396:
    c.r[12] = ~c.r[12];  // 060B8396 not r12,r12
L_060B8398:
    c.r[12] ^= c.r[2];  // 060B8398 xor r2,r12
L_060B839A:
    c.t = (c.r[5] & c.r[8]) == 0;  // 060B839A tst r8,r5
L_060B839C:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B839C subc r2,r2
L_060B839E:
    c.r[2] = ~c.r[2];  // 060B839E not r2,r2
L_060B83A0:
    c.r[2] ^= c.r[5];  // 060B83A0 xor r5,r2
L_060B83A2:
    c.r[12] += c.r[2];  // 060B83A2 add r2,r12
L_060B83A4:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B83A4 extu.w r12,r12
L_060B83A6:
    c.t = (int32_t)c.r[13] >= (int32_t)c.r[12];  // 060B83A6 cmp/ge r12,r13
L_060B83A8:
    if (c.t) { goto L_060B83AE; }  // 060B83A8 bt 0x060B83AE
L_060B83AA:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x060B8246u: goto L_060B8246; case 0x060B8248u: goto L_060B8248; case 0x060B824Au: goto L_060B824A; case 0x060B824Cu: goto L_060B824C; case 0x060B824Eu: goto L_060B824E; case 0x060B8250u: goto L_060B8250; case 0x060B8252u: goto L_060B8252; case 0x060B8256u: goto L_060B8256; case 0x060B8258u: goto L_060B8258; case 0x060B825Au: goto L_060B825A; case 0x060B825Cu: goto L_060B825C; case 0x060B825Eu: goto L_060B825E; case 0x060B8260u: goto L_060B8260; case 0x060B8262u: goto L_060B8262; case 0x060B8264u: goto L_060B8264; case 0x060B8266u: goto L_060B8266; case 0x060B8268u: goto L_060B8268; case 0x060B826Au: goto L_060B826A; case 0x060B826Cu: goto L_060B826C; case 0x060B826Eu: goto L_060B826E; case 0x060B8270u: goto L_060B8270; case 0x060B8272u: goto L_060B8272; case 0x060B8274u: goto L_060B8274; case 0x060B8278u: goto L_060B8278; case 0x060B827Au: goto L_060B827A; case 0x060B827Cu: goto L_060B827C; case 0x060B827Eu: goto L_060B827E; case 0x060B8280u: goto L_060B8280; case 0x060B8282u: goto L_060B8282; case 0x060B8284u: goto L_060B8284; case 0x060B8286u: goto L_060B8286; case 0x060B8288u: goto L_060B8288; case 0x060B828Au: goto L_060B828A; case 0x060B828Eu: goto L_060B828E; case 0x060B8290u: goto L_060B8290; case 0x060B8292u: goto L_060B8292; case 0x060B8294u: goto L_060B8294; case 0x060B8296u: goto L_060B8296; case 0x060B829Au: goto L_060B829A; case 0x060B829Cu: goto L_060B829C; case 0x060B829Eu: goto L_060B829E; case 0x060B82A0u: goto L_060B82A0; case 0x060B82A2u: goto L_060B82A2; case 0x060B82A4u: goto L_060B82A4; case 0x060B82A8u: goto L_060B82A8; case 0x060B82AAu: goto L_060B82AA; case 0x060B82ACu: goto L_060B82AC; case 0x060B82AEu: goto L_060B82AE; case 0x060B82B0u: goto L_060B82B0; case 0x060B82B2u: goto L_060B82B2; case 0x060B82B4u: goto L_060B82B4; case 0x060B82B8u: goto L_060B82B8; case 0x060B82BAu: goto L_060B82BA; case 0x060B82BCu: goto L_060B82BC; case 0x060B82BEu: goto L_060B82BE; case 0x060B82C2u: goto L_060B82C2; case 0x060B82C4u: goto L_060B82C4; case 0x060B82C6u: goto L_060B82C6; case 0x060B82C8u: goto L_060B82C8; case 0x060B82CCu: goto L_060B82CC; case 0x060B82CEu: goto L_060B82CE; case 0x060B82D0u: goto L_060B82D0; case 0x060B82D2u: goto L_060B82D2; case 0x060B82D6u: goto L_060B82D6; case 0x060B82D8u: goto L_060B82D8; case 0x060B82DAu: goto L_060B82DA; case 0x060B82DCu: goto L_060B82DC; case 0x060B82DEu: goto L_060B82DE; case 0x060B82E0u: goto L_060B82E0; case 0x060B82E2u: goto L_060B82E2; case 0x060B82E4u: goto L_060B82E4; case 0x060B82E6u: goto L_060B82E6; case 0x060B82E8u: goto L_060B82E8; case 0x060B82EAu: goto L_060B82EA; case 0x060B82ECu: goto L_060B82EC; case 0x060B82EEu: goto L_060B82EE; case 0x060B82F0u: goto L_060B82F0; case 0x060B82F2u: goto L_060B82F2; case 0x060B82F4u: goto L_060B82F4; case 0x060B82F8u: goto L_060B82F8; case 0x060B82FAu: goto L_060B82FA; case 0x060B82FCu: goto L_060B82FC; case 0x060B82FEu: goto L_060B82FE; case 0x060B8300u: goto L_060B8300; case 0x060B8304u: goto L_060B8304; case 0x060B8306u: goto L_060B8306; case 0x060B8308u: goto L_060B8308; case 0x060B830Cu: goto L_060B830C; case 0x060B830Eu: goto L_060B830E; case 0x060B8310u: goto L_060B8310; case 0x060B8312u: goto L_060B8312; case 0x060B8316u: goto L_060B8316; case 0x060B8318u: goto L_060B8318; case 0x060B831Au: goto L_060B831A; case 0x060B831Eu: goto L_060B831E; case 0x060B8320u: goto L_060B8320; case 0x060B8322u: goto L_060B8322; case 0x060B8324u: goto L_060B8324; case 0x060B8328u: goto L_060B8328; case 0x060B832Au: goto L_060B832A; case 0x060B832Cu: goto L_060B832C; case 0x060B8330u: goto L_060B8330; case 0x060B8332u: goto L_060B8332; case 0x060B8334u: goto L_060B8334; case 0x060B8338u: goto L_060B8338; case 0x060B833Au: goto L_060B833A; case 0x060B833Cu: goto L_060B833C; case 0x060B833Eu: goto L_060B833E; case 0x060B8340u: goto L_060B8340; case 0x060B8342u: goto L_060B8342; case 0x060B8344u: goto L_060B8344; case 0x060B8346u: goto L_060B8346; case 0x060B8348u: goto L_060B8348; case 0x060B834Au: goto L_060B834A; case 0x060B834Cu: goto L_060B834C; case 0x060B834Eu: goto L_060B834E; case 0x060B8350u: goto L_060B8350; case 0x060B8352u: goto L_060B8352; case 0x060B8354u: goto L_060B8354; case 0x060B8356u: goto L_060B8356; case 0x060B8358u: goto L_060B8358; case 0x060B835Au: goto L_060B835A; case 0x060B835Cu: goto L_060B835C; case 0x060B835Eu: goto L_060B835E; case 0x060B8360u: goto L_060B8360; case 0x060B8362u: goto L_060B8362; case 0x060B8364u: goto L_060B8364; case 0x060B8366u: goto L_060B8366; case 0x060B8368u: goto L_060B8368; case 0x060B836Au: goto L_060B836A; case 0x060B836Cu: goto L_060B836C; case 0x060B8370u: goto L_060B8370; case 0x060B8372u: goto L_060B8372; case 0x060B8374u: goto L_060B8374; case 0x060B8376u: goto L_060B8376; case 0x060B8378u: goto L_060B8378; case 0x060B837Au: goto L_060B837A; case 0x060B837Cu: goto L_060B837C; case 0x060B837Eu: goto L_060B837E; case 0x060B8380u: goto L_060B8380; case 0x060B8382u: goto L_060B8382; case 0x060B8384u: goto L_060B8384; case 0x060B8386u: goto L_060B8386; case 0x060B8388u: goto L_060B8388; case 0x060B838Au: goto L_060B838A; case 0x060B838Eu: goto L_060B838E; case 0x060B8390u: goto L_060B8390; case 0x060B8392u: goto L_060B8392; case 0x060B8394u: goto L_060B8394; case 0x060B8396u: goto L_060B8396; case 0x060B8398u: goto L_060B8398; case 0x060B839Au: goto L_060B839A; case 0x060B839Cu: goto L_060B839C; case 0x060B839Eu: goto L_060B839E; case 0x060B83A0u: goto L_060B83A0; case 0x060B83A2u: goto L_060B83A2; case 0x060B83A4u: goto L_060B83A4; case 0x060B83A6u: goto L_060B83A6; case 0x060B83A8u: goto L_060B83A8; case 0x060B83AAu: goto L_060B83AA; case 0x060B83AEu: goto L_060B83AE; case 0x060B83B0u: goto L_060B83B0; case 0x060B83B2u: goto L_060B83B2; case 0x060B83B4u: goto L_060B83B4; case 0x060B83B8u: goto L_060B83B8; case 0x060B83BAu: goto L_060B83BA; case 0x060B83BCu: goto L_060B83BC; case 0x060B83BEu: goto L_060B83BE; case 0x060B83C0u: goto L_060B83C0; case 0x060B83C2u: goto L_060B83C2; case 0x060B83C4u: goto L_060B83C4; case 0x060B83C8u: goto L_060B83C8; case 0x060B83CAu: goto L_060B83CA; case 0x060B83CCu: goto L_060B83CC; case 0x060B83CEu: goto L_060B83CE; case 0x060B83D0u: goto L_060B83D0; case 0x060B83D2u: goto L_060B83D2; case 0x060B83D4u: goto L_060B83D4; case 0x060B83D8u: goto L_060B83D8; case 0x060B83DAu: goto L_060B83DA; case 0x060B83DCu: goto L_060B83DC; case 0x060B83DEu: goto L_060B83DE; case 0x060B83E0u: goto L_060B83E0; case 0x060B83E2u: goto L_060B83E2; case 0x060B83E4u: goto L_060B83E4; default: sh2_call(c, x); return; } }  // 060B83AA jmp @r0 ; nop
L_060B83AE:
    st32(c.r[11] + 12, c.r[5]);  // 060B83AE mov.l r5,@(12,r11)
L_060B83B0:
    st32(c.r[11] + 16, c.r[1]);  // 060B83B0 mov.l r1,@(16,r11)
L_060B83B2:
    st32(c.r[11] + 20, c.r[7]);  // 060B83B2 mov.l r7,@(20,r11)
L_060B83B4:
    { const uint32_t x = c.pr; st32(c.r[11] + 24, c.r[9]); c.pc = x; return; }  // 060B83B4 rts ; mov.l r9,@(24,r11)
L_060B83B8:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[11]);  // 060B83B8 mov.w @(0,r11),r0
L_060B83BA:
    st32(c.r[11] + 16, c.r[5]);  // 060B83BA mov.l r5,@(16,r11)
L_060B83BC:
    c.r[0] ^= 0x10u;  // 060B83BC xor #16,r0
L_060B83BE:
    st16(c.r[11], c.r[0]);  // 060B83BE mov.w r0,@(0,r11)
L_060B83C0:
    st32(c.r[11] + 12, c.r[1]);  // 060B83C0 mov.l r1,@(12,r11)
L_060B83C2:
    st32(c.r[11] + 24, c.r[7]);  // 060B83C2 mov.l r7,@(24,r11)
L_060B83C4:
    { const uint32_t x = c.pr; st32(c.r[11] + 20, c.r[9]); c.pc = x; return; }  // 060B83C4 rts ; mov.l r9,@(20,r11)
L_060B83C8:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[11]);  // 060B83C8 mov.w @(0,r11),r0
L_060B83CA:
    st32(c.r[11] + 20, c.r[5]);  // 060B83CA mov.l r5,@(20,r11)
L_060B83CC:
    c.r[0] ^= 0x30u;  // 060B83CC xor #48,r0
L_060B83CE:
    st16(c.r[11], c.r[0]);  // 060B83CE mov.w r0,@(0,r11)
L_060B83D0:
    st32(c.r[11] + 24, c.r[1]);  // 060B83D0 mov.l r1,@(24,r11)
L_060B83D2:
    st32(c.r[11] + 12, c.r[7]);  // 060B83D2 mov.l r7,@(12,r11)
L_060B83D4:
    { const uint32_t x = c.pr; st32(c.r[11] + 16, c.r[9]); c.pc = x; return; }  // 060B83D4 rts ; mov.l r9,@(16,r11)
L_060B83D8:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[11]);  // 060B83D8 mov.w @(0,r11),r0
L_060B83DA:
    st32(c.r[11] + 24, c.r[5]);  // 060B83DA mov.l r5,@(24,r11)
L_060B83DC:
    c.r[0] ^= 0x20u;  // 060B83DC xor #32,r0
L_060B83DE:
    st16(c.r[11], c.r[0]);  // 060B83DE mov.w r0,@(0,r11)
L_060B83E0:
    st32(c.r[11] + 20, c.r[1]);  // 060B83E0 mov.l r1,@(20,r11)
L_060B83E2:
    st32(c.r[11] + 16, c.r[7]);  // 060B83E2 mov.l r7,@(16,r11)
L_060B83E4:
    { const uint32_t x = c.pr; st32(c.r[11] + 12, c.r[9]); c.pc = x; return; }  // 060B83E4 rts ; mov.l r9,@(12,r11)
}

void f_060B8262(SH2Context& c) {
    ran[3166] = 1;
    goto L_060B8262;
L_060B8246:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[11] + 30);  // 060B8246 mov.w @(30,r11),r0
L_060B8248:
    c.r[1] = ld32(c.r[11] + 32);  // 060B8248 mov.l @(32,r11),r1
L_060B824A:
    c.r[2] = (c.r[0] & 0xFFFF0000u) | (c.r[0] & 0xFFu) << 8 | (c.r[0] >> 8 & 0xFFu);  // 060B824A swap.b r0,r2
L_060B824C:
    c.r[0] = ld32(c.gbr + 56);  // 060B824C mov.l @(56,gbr),r0
L_060B824E:
    c.r[2] = c.r[2] & 0xFFu;  // 060B824E extu.b r2,r2
L_060B8250:
    c.r[2] <<= 2;  // 060B8250 shll2 r2
L_060B8252:
    { const uint32_t x = c.pr; st32(c.r[0] + c.r[2], c.r[1]); c.pc = x; return; }  // 060B8252 rts ; mov.l r1,@(r0,r2)
L_060B8262:
    c.r[0] = c.r[2];  // 060B8262 mov r2,r0
L_060B8264:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B8264 shar r0
L_060B8266:
    c.r[8] -= c.r[0];  // 060B8266 sub r0,r8
L_060B8268:
    c.r[0] = c.r[7];  // 060B8268 mov r7,r0
L_060B826A:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B826A shar r0
L_060B826C:
    c.r[8] += c.r[0];  // 060B826C add r0,r8
L_060B826E:
    c.r[0] = c.r[8];  // 060B826E mov r8,r0
L_060B8270:
    c.r[0] += c.r[10];  // 060B8270 add r10,r0
L_060B8272:
    c.t = c.r[0] > c.r[13];  // 060B8272 cmp/hi r13,r0
L_060B8274:
    { const bool k = c.t; c.r[4] += 32; if (k) { SH2_POLL(c); goto L_060B8246; } }  // 060B8274 bt/s 0x060B8246 ; add #32,r4
L_060B8278:
    c.r[0] = c.r[3];  // 060B8278 mov r3,r0
L_060B827A:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B827A shar r0
L_060B827C:
    c.r[9] -= c.r[0];  // 060B827C sub r0,r9
L_060B827E:
    c.r[0] = c.r[6];  // 060B827E mov r6,r0
L_060B8280:
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 060B8280 shar r0
L_060B8282:
    c.r[9] -= c.r[0];  // 060B8282 sub r0,r9
L_060B8284:
    c.r[0] = c.r[9];  // 060B8284 mov r9,r0
L_060B8286:
    c.r[0] += c.r[12];  // 060B8286 add r12,r0
L_060B8288:
    c.t = c.r[0] > c.r[14];  // 060B8288 cmp/hi r14,r0
L_060B828A:
    { const bool k = c.t; c.r[1] = c.r[8] << 16 | c.r[8] >> 16; if (k) { SH2_POLL(c); goto L_060B8246; } }  // 060B828A bt/s 0x060B8246 ; swap.w r8,r1
L_060B828E:
    c.r[8] += c.r[2];  // 060B828E add r2,r8
L_060B8290:
    c.r[0] = c.r[8];  // 060B8290 mov r8,r0
L_060B8292:
    c.r[0] += c.r[10];  // 060B8292 add r10,r0
L_060B8294:
    c.t = c.r[0] > c.r[13];  // 060B8294 cmp/hi r13,r0
L_060B8296:
    { const bool k = c.t; c.r[5] = c.r[9]; if (k) { SH2_POLL(c); goto L_060B8246; } }  // 060B8296 bt/s 0x060B8246 ; mov r9,r5
L_060B829A:
    c.r[5] = c.r[1] << 16 | c.r[5] >> 16;  // 060B829A xtrct r1,r5
L_060B829C:
    c.r[9] += c.r[6];  // 060B829C add r6,r9
L_060B829E:
    c.r[0] = c.r[9];  // 060B829E mov r9,r0
L_060B82A0:
    c.r[0] += c.r[12];  // 060B82A0 add r12,r0
L_060B82A2:
    c.t = c.r[0] > c.r[14];  // 060B82A2 cmp/hi r14,r0
L_060B82A4:
    { const bool k = c.t; c.r[0] = c.r[8] << 16 | c.r[8] >> 16; if (k) { SH2_POLL(c); goto L_060B8246; } }  // 060B82A4 bt/s 0x060B8246 ; swap.w r8,r0
L_060B82A8:
    c.r[1] = c.r[9];  // 060B82A8 mov r9,r1
L_060B82AA:
    c.r[1] = c.r[0] << 16 | c.r[1] >> 16;  // 060B82AA xtrct r0,r1
L_060B82AC:
    c.r[8] -= c.r[7];  // 060B82AC sub r7,r8
L_060B82AE:
    c.r[0] = c.r[8];  // 060B82AE mov r8,r0
L_060B82B0:
    c.r[0] += c.r[10];  // 060B82B0 add r10,r0
L_060B82B2:
    c.t = c.r[0] > c.r[13];  // 060B82B2 cmp/hi r13,r0
L_060B82B4:
    { const bool k = c.t; c.r[9] += c.r[3]; if (k) { SH2_POLL(c); goto L_060B8246; } }  // 060B82B4 bt/s 0x060B8246 ; add r3,r9
L_060B82B8:
    c.r[0] = c.r[9];  // 060B82B8 mov r9,r0
L_060B82BA:
    c.r[0] += c.r[12];  // 060B82BA add r12,r0
L_060B82BC:
    c.t = c.r[0] > c.r[14];  // 060B82BC cmp/hi r14,r0
L_060B82BE:
    { const bool k = c.t; c.r[3] = c.r[8] << 16 | c.r[8] >> 16; if (k) { SH2_POLL(c); goto L_060B8246; } }  // 060B82BE bt/s 0x060B8246 ; swap.w r8,r3
L_060B82C2:
    c.r[8] -= c.r[2];  // 060B82C2 sub r2,r8
L_060B82C4:
    c.r[10] += c.r[8];  // 060B82C4 add r8,r10
L_060B82C6:
    c.t = c.r[10] > c.r[13];  // 060B82C6 cmp/hi r13,r10
L_060B82C8:
    { const bool k = c.t; c.r[7] = c.r[9]; if (k) { SH2_POLL(c); goto L_060B8246; } }  // 060B82C8 bt/s 0x060B8246 ; mov r9,r7
L_060B82CC:
    c.r[9] -= c.r[6];  // 060B82CC sub r6,r9
L_060B82CE:
    c.r[12] += c.r[9];  // 060B82CE add r9,r12
L_060B82D0:
    c.t = c.r[12] > c.r[14];  // 060B82D0 cmp/hi r14,r12
L_060B82D2:
    { const bool k = c.t; c.r[7] = c.r[3] << 16 | c.r[7] >> 16; if (k) { SH2_POLL(c); goto L_060B8246; } }  // 060B82D2 bt/s 0x060B8246 ; xtrct r3,r7
L_060B82D6:
    c.r[8] = c.r[8] << 16 | c.r[8] >> 16;  // 060B82D6 swap.w r8,r8
L_060B82D8:
    c.r[0] = c.r[11];  // 060B82D8 mov r11,r0
L_060B82DA:
    c.r[0] += 36;  // 060B82DA add #36,r0
L_060B82DC:
    st32(c.gbr + 52, c.r[0]);  // 060B82DC mov.l r0,@(52,gbr)
L_060B82DE:
    c.r[0] = ld32(c.gbr + 148);  // 060B82DE mov.l @(148,gbr),r0
L_060B82E0:
    c.r[3] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B82E0 exts.w r0,r3
L_060B82E2:
    c.r[2] = c.r[0] << 16 | c.r[0] >> 16;  // 060B82E2 swap.w r0,r2
L_060B82E4:
    c.r[0] = ld32(c.gbr + 816);  // 060B82E4 mov.l @(816,gbr),r0
L_060B82E6:
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 060B82E6 exts.w r2,r2
L_060B82E8:
    c.r[13] = c.r[0] & 0xFFFFu;  // 060B82E8 extu.w r0,r13
L_060B82EA:
    c.r[12] = c.r[0] << 16 | c.r[0] >> 16;  // 060B82EA swap.w r0,r12
L_060B82EC:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B82EC extu.w r12,r12
L_060B82EE:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[5];  // 060B82EE exts.w r5,r0
L_060B82F0:
    c.r[0] += c.r[3];  // 060B82F0 add r3,r0
L_060B82F2:
    c.t = c.r[0] >= c.r[13];  // 060B82F2 cmp/hs r13,r0
L_060B82F4:
    { const bool k = c.t; c.r[9] = c.r[8] << 16 | c.r[9] >> 16; if (k) { goto L_060B8302; } }  // 060B82F4 bt/s 0x060B8302 ; xtrct r8,r9
L_060B82F8:
    c.r[0] = c.r[5] << 16 | c.r[5] >> 16;  // 060B82F8 swap.w r5,r0
L_060B82FA:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B82FA exts.w r0,r0
L_060B82FC:
    c.r[0] += c.r[2];  // 060B82FC add r2,r0
L_060B82FE:
    c.t = c.r[12] > c.r[0];  // 060B82FE cmp/hi r0,r12
L_060B8300:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[1]; if (k) { goto L_060B83AE; } }  // 060B8300 bt/s 0x060B83AE ; exts.w r1,r0
    goto L_060B8304;
L_060B8302:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 060B8302 exts.w r1,r0
L_060B8304:
    c.r[0] += c.r[3];  // 060B8304 add r3,r0
L_060B8306:
    c.t = c.r[0] >= c.r[13];  // 060B8306 cmp/hs r13,r0
L_060B8308:
    { const bool k = c.t; c.r[0] = c.r[1] << 16 | c.r[1] >> 16; if (k) { goto L_060B8314; } }  // 060B8308 bt/s 0x060B8314 ; swap.w r1,r0
L_060B830C:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B830C exts.w r0,r0
L_060B830E:
    c.r[0] += c.r[2];  // 060B830E add r2,r0
L_060B8310:
    c.t = c.r[12] > c.r[0];  // 060B8310 cmp/hi r0,r12
L_060B8312:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[7]; if (k) { goto L_060B83B8; } }  // 060B8312 bt/s 0x060B83B8 ; exts.w r7,r0
    goto L_060B8316;
L_060B8314:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[7];  // 060B8314 exts.w r7,r0
L_060B8316:
    c.r[0] += c.r[3];  // 060B8316 add r3,r0
L_060B8318:
    c.t = c.r[0] >= c.r[13];  // 060B8318 cmp/hs r13,r0
L_060B831A:
    { const bool k = c.t; c.r[0] = c.r[7] << 16 | c.r[7] >> 16; if (k) { goto L_060B8326; } }  // 060B831A bt/s 0x060B8326 ; swap.w r7,r0
L_060B831E:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 060B831E exts.w r0,r0
L_060B8320:
    c.r[0] += c.r[2];  // 060B8320 add r2,r0
L_060B8322:
    c.t = c.r[12] > c.r[0];  // 060B8322 cmp/hi r0,r12
L_060B8324:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[9]; if (k) { goto L_060B83C8; } }  // 060B8324 bt/s 0x060B83C8 ; exts.w r9,r0
    goto L_060B8328;
L_060B8326:
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[9];  // 060B8326 exts.w r9,r0
L_060B8328:
    c.r[0] += c.r[3];  // 060B8328 add r3,r0
L_060B832A:
    c.t = c.r[0] >= c.r[13];  // 060B832A cmp/hs r13,r0
L_060B832C:
    { const bool k = c.t; c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[8]; if (k) { goto L_060B8336; } }  // 060B832C bt/s 0x060B8336 ; exts.w r8,r0
L_060B8330:
    c.r[0] += c.r[2];  // 060B8330 add r2,r0
L_060B8332:
    c.t = c.r[12] > c.r[0];  // 060B8332 cmp/hi r0,r12
L_060B8334:
    { const bool k = c.t; c.r[8] = 0x1u; if (k) { goto L_060B83D8; } }  // 060B8334 bt/s 0x060B83D8 ; mov #1,r8
    goto L_060B8338;
L_060B8336:
    c.r[8] = 0x1u;  // 060B8336 mov #1,r8
L_060B8338:
    c.r[8] <<= 16;  // 060B8338 shll16 r8
L_060B833A:
    c.t = c.r[8] & 1; c.r[8] >>= 1;  // 060B833A shlr r8
L_060B833C:
    c.r[2] = c.r[9] << 16 | c.r[9] >> 16;  // 060B833C swap.w r9,r2
L_060B833E:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B833E tst r8,r2
L_060B8340:
    { uint32_t a = c.r[13], b = c.r[13], t = c.t; c.r[13] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B8340 subc r13,r13
L_060B8342:
    c.r[13] = ~c.r[13];  // 060B8342 not r13,r13
L_060B8344:
    c.r[13] ^= c.r[2];  // 060B8344 xor r2,r13
L_060B8346:
    c.t = (c.r[9] & c.r[8]) == 0;  // 060B8346 tst r8,r9
L_060B8348:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B8348 subc r2,r2
L_060B834A:
    c.r[2] = ~c.r[2];  // 060B834A not r2,r2
L_060B834C:
    c.r[2] ^= c.r[9];  // 060B834C xor r9,r2
L_060B834E:
    c.r[13] += c.r[2];  // 060B834E add r2,r13
L_060B8350:
    c.r[13] = c.r[13] & 0xFFFFu;  // 060B8350 extu.w r13,r13
L_060B8352:
    c.r[0] = 0x060B83D8u;  // 060B8352 mova 0x060B83D8,r0
L_060B8354:
    c.r[2] = c.r[7] << 16 | c.r[7] >> 16;  // 060B8354 swap.w r7,r2
L_060B8356:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B8356 tst r8,r2
L_060B8358:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B8358 subc r12,r12
L_060B835A:
    c.r[12] = ~c.r[12];  // 060B835A not r12,r12
L_060B835C:
    c.r[12] ^= c.r[2];  // 060B835C xor r2,r12
L_060B835E:
    c.t = (c.r[7] & c.r[8]) == 0;  // 060B835E tst r8,r7
L_060B8360:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B8360 subc r2,r2
L_060B8362:
    c.r[2] = ~c.r[2];  // 060B8362 not r2,r2
L_060B8364:
    c.r[2] ^= c.r[7];  // 060B8364 xor r7,r2
L_060B8366:
    c.r[12] += c.r[2];  // 060B8366 add r2,r12
L_060B8368:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B8368 extu.w r12,r12
L_060B836A:
    c.t = (int32_t)c.r[12] > (int32_t)c.r[13];  // 060B836A cmp/gt r13,r12
L_060B836C:
    { const bool k = c.t; c.r[2] = c.r[1] << 16 | c.r[1] >> 16; if (k) { goto L_060B8374; } }  // 060B836C bt/s 0x060B8374 ; swap.w r1,r2
L_060B8370:
    c.r[13] = c.r[12];  // 060B8370 mov r12,r13
L_060B8372:
    c.r[0] = 0x060B83C8u;  // 060B8372 mova 0x060B83C8,r0
L_060B8374:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B8374 tst r8,r2
L_060B8376:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B8376 subc r12,r12
L_060B8378:
    c.r[12] = ~c.r[12];  // 060B8378 not r12,r12
L_060B837A:
    c.r[12] ^= c.r[2];  // 060B837A xor r2,r12
L_060B837C:
    c.t = (c.r[1] & c.r[8]) == 0;  // 060B837C tst r8,r1
L_060B837E:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B837E subc r2,r2
L_060B8380:
    c.r[2] = ~c.r[2];  // 060B8380 not r2,r2
L_060B8382:
    c.r[2] ^= c.r[1];  // 060B8382 xor r1,r2
L_060B8384:
    c.r[12] += c.r[2];  // 060B8384 add r2,r12
L_060B8386:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B8386 extu.w r12,r12
L_060B8388:
    c.t = (int32_t)c.r[12] > (int32_t)c.r[13];  // 060B8388 cmp/gt r13,r12
L_060B838A:
    { const bool k = c.t; c.r[2] = c.r[5] << 16 | c.r[5] >> 16; if (k) { goto L_060B8392; } }  // 060B838A bt/s 0x060B8392 ; swap.w r5,r2
L_060B838E:
    c.r[13] = c.r[12];  // 060B838E mov r12,r13
L_060B8390:
    c.r[0] = 0x060B83C8u;  // 060B8390 mova 0x060B83C8,r0
L_060B8392:
    c.t = (c.r[2] & c.r[8]) == 0;  // 060B8392 tst r8,r2
L_060B8394:
    { uint32_t a = c.r[12], b = c.r[12], t = c.t; c.r[12] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B8394 subc r12,r12
L_060B8396:
    c.r[12] = ~c.r[12];  // 060B8396 not r12,r12
L_060B8398:
    c.r[12] ^= c.r[2];  // 060B8398 xor r2,r12
L_060B839A:
    c.t = (c.r[5] & c.r[8]) == 0;  // 060B839A tst r8,r5
L_060B839C:
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 060B839C subc r2,r2
L_060B839E:
    c.r[2] = ~c.r[2];  // 060B839E not r2,r2
L_060B83A0:
    c.r[2] ^= c.r[5];  // 060B83A0 xor r5,r2
L_060B83A2:
    c.r[12] += c.r[2];  // 060B83A2 add r2,r12
L_060B83A4:
    c.r[12] = c.r[12] & 0xFFFFu;  // 060B83A4 extu.w r12,r12
L_060B83A6:
    c.t = (int32_t)c.r[13] >= (int32_t)c.r[12];  // 060B83A6 cmp/ge r12,r13
L_060B83A8:
    if (c.t) { goto L_060B83AE; }  // 060B83A8 bt 0x060B83AE
L_060B83AA:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x060B8246u: goto L_060B8246; case 0x060B8248u: goto L_060B8248; case 0x060B824Au: goto L_060B824A; case 0x060B824Cu: goto L_060B824C; case 0x060B824Eu: goto L_060B824E; case 0x060B8250u: goto L_060B8250; case 0x060B8252u: goto L_060B8252; case 0x060B8262u: goto L_060B8262; case 0x060B8264u: goto L_060B8264; case 0x060B8266u: goto L_060B8266; case 0x060B8268u: goto L_060B8268; case 0x060B826Au: goto L_060B826A; case 0x060B826Cu: goto L_060B826C; case 0x060B826Eu: goto L_060B826E; case 0x060B8270u: goto L_060B8270; case 0x060B8272u: goto L_060B8272; case 0x060B8274u: goto L_060B8274; case 0x060B8278u: goto L_060B8278; case 0x060B827Au: goto L_060B827A; case 0x060B827Cu: goto L_060B827C; case 0x060B827Eu: goto L_060B827E; case 0x060B8280u: goto L_060B8280; case 0x060B8282u: goto L_060B8282; case 0x060B8284u: goto L_060B8284; case 0x060B8286u: goto L_060B8286; case 0x060B8288u: goto L_060B8288; case 0x060B828Au: goto L_060B828A; case 0x060B828Eu: goto L_060B828E; case 0x060B8290u: goto L_060B8290; case 0x060B8292u: goto L_060B8292; case 0x060B8294u: goto L_060B8294; case 0x060B8296u: goto L_060B8296; case 0x060B829Au: goto L_060B829A; case 0x060B829Cu: goto L_060B829C; case 0x060B829Eu: goto L_060B829E; case 0x060B82A0u: goto L_060B82A0; case 0x060B82A2u: goto L_060B82A2; case 0x060B82A4u: goto L_060B82A4; case 0x060B82A8u: goto L_060B82A8; case 0x060B82AAu: goto L_060B82AA; case 0x060B82ACu: goto L_060B82AC; case 0x060B82AEu: goto L_060B82AE; case 0x060B82B0u: goto L_060B82B0; case 0x060B82B2u: goto L_060B82B2; case 0x060B82B4u: goto L_060B82B4; case 0x060B82B8u: goto L_060B82B8; case 0x060B82BAu: goto L_060B82BA; case 0x060B82BCu: goto L_060B82BC; case 0x060B82BEu: goto L_060B82BE; case 0x060B82C2u: goto L_060B82C2; case 0x060B82C4u: goto L_060B82C4; case 0x060B82C6u: goto L_060B82C6; case 0x060B82C8u: goto L_060B82C8; case 0x060B82CCu: goto L_060B82CC; case 0x060B82CEu: goto L_060B82CE; case 0x060B82D0u: goto L_060B82D0; case 0x060B82D2u: goto L_060B82D2; case 0x060B82D6u: goto L_060B82D6; case 0x060B82D8u: goto L_060B82D8; case 0x060B82DAu: goto L_060B82DA; case 0x060B82DCu: goto L_060B82DC; case 0x060B82DEu: goto L_060B82DE; case 0x060B82E0u: goto L_060B82E0; case 0x060B82E2u: goto L_060B82E2; case 0x060B82E4u: goto L_060B82E4; case 0x060B82E6u: goto L_060B82E6; case 0x060B82E8u: goto L_060B82E8; case 0x060B82EAu: goto L_060B82EA; case 0x060B82ECu: goto L_060B82EC; case 0x060B82EEu: goto L_060B82EE; case 0x060B82F0u: goto L_060B82F0; case 0x060B82F2u: goto L_060B82F2; case 0x060B82F4u: goto L_060B82F4; case 0x060B82F8u: goto L_060B82F8; case 0x060B82FAu: goto L_060B82FA; case 0x060B82FCu: goto L_060B82FC; case 0x060B82FEu: goto L_060B82FE; case 0x060B8300u: goto L_060B8300; case 0x060B8304u: goto L_060B8304; case 0x060B8306u: goto L_060B8306; case 0x060B8308u: goto L_060B8308; case 0x060B830Cu: goto L_060B830C; case 0x060B830Eu: goto L_060B830E; case 0x060B8310u: goto L_060B8310; case 0x060B8312u: goto L_060B8312; case 0x060B8316u: goto L_060B8316; case 0x060B8318u: goto L_060B8318; case 0x060B831Au: goto L_060B831A; case 0x060B831Eu: goto L_060B831E; case 0x060B8320u: goto L_060B8320; case 0x060B8322u: goto L_060B8322; case 0x060B8324u: goto L_060B8324; case 0x060B8328u: goto L_060B8328; case 0x060B832Au: goto L_060B832A; case 0x060B832Cu: goto L_060B832C; case 0x060B8330u: goto L_060B8330; case 0x060B8332u: goto L_060B8332; case 0x060B8334u: goto L_060B8334; case 0x060B8338u: goto L_060B8338; case 0x060B833Au: goto L_060B833A; case 0x060B833Cu: goto L_060B833C; case 0x060B833Eu: goto L_060B833E; case 0x060B8340u: goto L_060B8340; case 0x060B8342u: goto L_060B8342; case 0x060B8344u: goto L_060B8344; case 0x060B8346u: goto L_060B8346; case 0x060B8348u: goto L_060B8348; case 0x060B834Au: goto L_060B834A; case 0x060B834Cu: goto L_060B834C; case 0x060B834Eu: goto L_060B834E; case 0x060B8350u: goto L_060B8350; case 0x060B8352u: goto L_060B8352; case 0x060B8354u: goto L_060B8354; case 0x060B8356u: goto L_060B8356; case 0x060B8358u: goto L_060B8358; case 0x060B835Au: goto L_060B835A; case 0x060B835Cu: goto L_060B835C; case 0x060B835Eu: goto L_060B835E; case 0x060B8360u: goto L_060B8360; case 0x060B8362u: goto L_060B8362; case 0x060B8364u: goto L_060B8364; case 0x060B8366u: goto L_060B8366; case 0x060B8368u: goto L_060B8368; case 0x060B836Au: goto L_060B836A; case 0x060B836Cu: goto L_060B836C; case 0x060B8370u: goto L_060B8370; case 0x060B8372u: goto L_060B8372; case 0x060B8374u: goto L_060B8374; case 0x060B8376u: goto L_060B8376; case 0x060B8378u: goto L_060B8378; case 0x060B837Au: goto L_060B837A; case 0x060B837Cu: goto L_060B837C; case 0x060B837Eu: goto L_060B837E; case 0x060B8380u: goto L_060B8380; case 0x060B8382u: goto L_060B8382; case 0x060B8384u: goto L_060B8384; case 0x060B8386u: goto L_060B8386; case 0x060B8388u: goto L_060B8388; case 0x060B838Au: goto L_060B838A; case 0x060B838Eu: goto L_060B838E; case 0x060B8390u: goto L_060B8390; case 0x060B8392u: goto L_060B8392; case 0x060B8394u: goto L_060B8394; case 0x060B8396u: goto L_060B8396; case 0x060B8398u: goto L_060B8398; case 0x060B839Au: goto L_060B839A; case 0x060B839Cu: goto L_060B839C; case 0x060B839Eu: goto L_060B839E; case 0x060B83A0u: goto L_060B83A0; case 0x060B83A2u: goto L_060B83A2; case 0x060B83A4u: goto L_060B83A4; case 0x060B83A6u: goto L_060B83A6; case 0x060B83A8u: goto L_060B83A8; case 0x060B83AAu: goto L_060B83AA; case 0x060B83AEu: goto L_060B83AE; case 0x060B83B0u: goto L_060B83B0; case 0x060B83B2u: goto L_060B83B2; case 0x060B83B4u: goto L_060B83B4; case 0x060B83B8u: goto L_060B83B8; case 0x060B83BAu: goto L_060B83BA; case 0x060B83BCu: goto L_060B83BC; case 0x060B83BEu: goto L_060B83BE; case 0x060B83C0u: goto L_060B83C0; case 0x060B83C2u: goto L_060B83C2; case 0x060B83C4u: goto L_060B83C4; case 0x060B83C8u: goto L_060B83C8; case 0x060B83CAu: goto L_060B83CA; case 0x060B83CCu: goto L_060B83CC; case 0x060B83CEu: goto L_060B83CE; case 0x060B83D0u: goto L_060B83D0; case 0x060B83D2u: goto L_060B83D2; case 0x060B83D4u: goto L_060B83D4; case 0x060B83D8u: goto L_060B83D8; case 0x060B83DAu: goto L_060B83DA; case 0x060B83DCu: goto L_060B83DC; case 0x060B83DEu: goto L_060B83DE; case 0x060B83E0u: goto L_060B83E0; case 0x060B83E2u: goto L_060B83E2; case 0x060B83E4u: goto L_060B83E4; default: sh2_call(c, x); return; } }  // 060B83AA jmp @r0 ; nop
L_060B83AE:
    st32(c.r[11] + 12, c.r[5]);  // 060B83AE mov.l r5,@(12,r11)
L_060B83B0:
    st32(c.r[11] + 16, c.r[1]);  // 060B83B0 mov.l r1,@(16,r11)
L_060B83B2:
    st32(c.r[11] + 20, c.r[7]);  // 060B83B2 mov.l r7,@(20,r11)
L_060B83B4:
    { const uint32_t x = c.pr; st32(c.r[11] + 24, c.r[9]); c.pc = x; return; }  // 060B83B4 rts ; mov.l r9,@(24,r11)
L_060B83B8:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[11]);  // 060B83B8 mov.w @(0,r11),r0
L_060B83BA:
    st32(c.r[11] + 16, c.r[5]);  // 060B83BA mov.l r5,@(16,r11)
L_060B83BC:
    c.r[0] ^= 0x10u;  // 060B83BC xor #16,r0
L_060B83BE:
    st16(c.r[11], c.r[0]);  // 060B83BE mov.w r0,@(0,r11)
L_060B83C0:
    st32(c.r[11] + 12, c.r[1]);  // 060B83C0 mov.l r1,@(12,r11)
L_060B83C2:
    st32(c.r[11] + 24, c.r[7]);  // 060B83C2 mov.l r7,@(24,r11)
L_060B83C4:
    { const uint32_t x = c.pr; st32(c.r[11] + 20, c.r[9]); c.pc = x; return; }  // 060B83C4 rts ; mov.l r9,@(20,r11)
L_060B83C8:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[11]);  // 060B83C8 mov.w @(0,r11),r0
L_060B83CA:
    st32(c.r[11] + 20, c.r[5]);  // 060B83CA mov.l r5,@(20,r11)
L_060B83CC:
    c.r[0] ^= 0x30u;  // 060B83CC xor #48,r0
L_060B83CE:
    st16(c.r[11], c.r[0]);  // 060B83CE mov.w r0,@(0,r11)
L_060B83D0:
    st32(c.r[11] + 24, c.r[1]);  // 060B83D0 mov.l r1,@(24,r11)
L_060B83D2:
    st32(c.r[11] + 12, c.r[7]);  // 060B83D2 mov.l r7,@(12,r11)
L_060B83D4:
    { const uint32_t x = c.pr; st32(c.r[11] + 16, c.r[9]); c.pc = x; return; }  // 060B83D4 rts ; mov.l r9,@(16,r11)
L_060B83D8:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[11]);  // 060B83D8 mov.w @(0,r11),r0
L_060B83DA:
    st32(c.r[11] + 24, c.r[5]);  // 060B83DA mov.l r5,@(24,r11)
L_060B83DC:
    c.r[0] ^= 0x20u;  // 060B83DC xor #32,r0
L_060B83DE:
    st16(c.r[11], c.r[0]);  // 060B83DE mov.w r0,@(0,r11)
L_060B83E0:
    st32(c.r[11] + 20, c.r[1]);  // 060B83E0 mov.l r1,@(20,r11)
L_060B83E2:
    st32(c.r[11] + 16, c.r[7]);  // 060B83E2 mov.l r7,@(16,r11)
L_060B83E4:
    { const uint32_t x = c.pr; st32(c.r[11] + 12, c.r[9]); c.pc = x; return; }  // 060B83E4 rts ; mov.l r9,@(12,r11)
}

void f_060B83E8(SH2Context& c) {
    ran[3167] = 1;
    c.r[6] = c.r[0];  // 060B83E8 mov r0,r6
    c.r[0] = ld32(c.gbr + 56);  // 060B83EA mov.l @(56,gbr),r0
    c.r[9] = ld32(c.r[4]); c.r[4] += 4;  // 060B83EC mov.l @r4+,r9
    c.r[2] = c.r[0];  // 060B83EE mov r0,r2
    c.r[1] = ld32(c.r[4]); c.r[4] += 4;  // 060B83F0 mov.l @r4+,r1
    c.t = (int32_t)c.r[9] > 0;  // 060B83F2 cmp/pl r9
    { const bool k = !c.t; c.r[1] <<= 2; if (k) { goto L_060B8412; } }  // 060B83F4 bf/s 0x060B8412 ; shll2 r1
    c.r[0] = ld32(c.gbr + 40);  // 060B83F8 mov.l @(40,gbr),r0
    c.r[1] <<= 2;  // 060B83FA shll2 r1
    c.r[0] += c.r[1];  // 060B83FC add r1,r0
    st32(c.gbr + 40, c.r[0]);  // 060B83FE mov.l r0,@(40,gbr)
L_060B8400:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[6] + 30);  // 060B8400 mov.w @(30,r6),r0
    c.r[9] -= 1; c.t = c.r[9] == 0;  // 060B8402 dt r9
    c.r[0] >>= 8;  // 060B8404 shlr8 r0
    c.r[0] <<= 2;  // 060B8406 shll2 r0
    c.r[3] = ld32(c.r[0] + c.r[2]);  // 060B8408 mov.l @(r0,r2),r3
    st32(c.r[0] + c.r[2], c.r[6]);  // 060B840A mov.l r6,@(r0,r2)
    st32(c.r[6] + 32, c.r[3]);  // 060B840C mov.l r3,@(32,r6)
    { const bool k = !c.t; c.r[6] -= 36; if (k) { SH2_POLL(c); goto L_060B8400; } }  // 060B840E bf/s 0x060B8400 ; add #-36,r6
L_060B8412:
    c.r[0] = (uint32_t)(int8_t)ld8(c.gbr + 169);  // 060B8412 mov.b @(169,gbr),r0
    c.t = (c.r[0] & 0x1u) == 0;  // 060B8414 tst #1,r0
    { const bool k = !c.t; c.r[1] = 0x20u; if (k) { goto L_060B841C; } }  // 060B8416 bf/s 0x060B841C ; mov #32,r1
    c.r[1] = 0x10u;  // 060B841A mov #16,r1
L_060B841C:
    c.r[0] |= c.r[1];  // 060B841C or r1,r0
    { const uint32_t x = c.pr; st8(c.gbr + 169, c.r[0]); c.pc = x; return; }  // 060B841E rts ; mov.b r0,@(169,gbr)
}

}  // namespace p_srwfin_kor
