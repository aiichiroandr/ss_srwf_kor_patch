#include "p_fin_resident_funcs.h"

namespace p_fin_resident {

static const SH2FuncEntry funcs[] = {
    {0x060D9EF0u, f_060D9EF0},
    {0x060D9EFAu, f_060D9EFA},
    {0x060D9FE6u, f_060D9FE6},
    {0x060DA006u, f_060DA006},
    {0x060DA1F0u, f_060DA1F0},
    {0x060DA800u, f_060DA800},
    {0x060DA82Au, f_060DA82A},
    {0x060DA854u, f_060DA854},
    {0x060DA88Au, f_060DA88A},
    {0x060DA8BEu, f_060DA8BE},
    {0x060DA8FAu, f_060DA8FA},
    {0x060DA914u, f_060DA914},
    {0x060DA92Au, f_060DA92A},
    {0x060DA9F0u, f_060DA9F0},
    {0x060DAA6Au, f_060DAA6A},
    {0x060DAB4Eu, f_060DAB4E},
    {0x060DABDCu, f_060DABDC},
    {0x060DABECu, f_060DABEC},
    {0x060DACD2u, f_060DACD2},
    {0x060DAD12u, f_060DAD12},
    {0x060DAD34u, f_060DAD34},
    {0x060DAD4Au, f_060DAD4A},
    {0x060DAE00u, f_060DAE00},
    {0x060DAE70u, f_060DAE70},
    {0x060DAF00u, f_060DAF00},
    {0x060DB000u, f_060DB000},
    {0x060DB100u, f_060DB100},
    {0x060DB200u, f_060DB200},
    {0x060DB300u, f_060DB300},
    {0x060DB400u, f_060DB400},
    {0x060DB600u, f_060DB600},
    {0x060DB800u, f_060DB800},
    {0x060DB900u, f_060DB900},
};

uint8_t ran[33];
static const uint16_t sizes[] = {123, 115, 16, 22, 144, 91, 21, 27, 26, 30, 13, 11, 64, 61, 128, 71, 8, 115, 32, 97, 11, 11, 70, 14, 80, 63, 55, 55, 19, 20, 128, 59, 48};

extern const SH2Module module = {"FIN_RESIDENT", 0x060D9EF0u, 6800u, 0x3A9E393Eu, funcs, 33, ran, sizes, true};

}  // namespace p_fin_resident
