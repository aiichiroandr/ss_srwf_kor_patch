#include "p_srwfin_installed_funcs.h"

namespace p_srwfin_installed {

void f_0602B328(SH2Context& c) {
    ran[599] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602B328 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602B32A sts.l pr,@-r15
    c.r[1] = ld32(0x0602B348u);  // 0602B32C mov.l 0x0602B348,r1
    c.r[1] = ld32(c.r[1]);  // 0602B32E mov.l @r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602B330 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0602B332 extu.b r1,r0
    c.r[0] <<= 2;  // 0602B334 shll2 r0
    c.r[1] = ld32(0x0602B34Cu);  // 0602B336 mov.l 0x0602B34C,r1
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 0602B338 mov.l @(r0,r1),r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602B33Eu; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602B33Eu) return; }  // 0602B33A jsr @r0 ; mov r15,r14
    c.r[15] = c.r[14];  // 0602B33E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602B340 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602B342 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[0] & 0xFFFFu; c.pc = x; return; }  // 0602B344 rts ; extu.w r0,r0
}

void f_0602B350(SH2Context& c) {
    ran[600] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602B350 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602B352 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602B354 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602B356 sts.l pr,@-r15
    c.r[9] = ld32(0x0602B3B0u);  // 0602B358 mov.l 0x0602B3B0,r9
    c.r[2] = ld32(c.r[9]);  // 0602B35A mov.l @r9,r2
    c.r[1] = c.r[2];  // 0602B35C mov r2,r1
    c.r[1] += 1;  // 0602B35E add #1,r1
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602B360 mov.b @r1,r8
    c.r[2] += 2;  // 0602B362 add #2,r2
    c.r[8] = c.r[8] & 0xFFu;  // 0602B364 extu.b r8,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602B366 mov.b @r2,r1
    c.r[8] <<= 8;  // 0602B368 shll8 r8
    c.r[1] = c.r[1] & 0xFFu;  // 0602B36A extu.b r1,r1
    c.r[8] |= c.r[1];  // 0602B36C or r1,r8
    c.r[1] = ld32(0x0602B3B4u);  // 0602B36E mov.l 0x0602B3B4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602B374u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602B374u) return; }  // 0602B370 jsr @r1 ; mov r15,r14
    c.r[6] = c.r[8];  // 0602B374 mov r8,r6
    c.r[1] = ld32(c.r[9]);  // 0602B376 mov.l @r9,r1
    c.r[6] >>= 8;  // 0602B378 shlr8 r6
    c.t = c.r[6] & 1; c.r[6] >>= 1;  // 0602B37A shlr r6
    c.r[1] += 3;  // 0602B37C add #3,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602B37E mov.b @r1,r5
    c.r[0] = ld32(0x0602B3B8u);  // 0602B380 mov.l 0x0602B3B8,r0
    c.r[5] = c.r[5] & 0xFFu;  // 0602B382 extu.b r5,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602B3A8u);  // 0602B384 mov.w 0x0602B3A8,r1
    c.r[8] &= c.r[1];  // 0602B386 and r1,r8
    { const uint32_t x = c.r[0]; c.pr = 0x0602B38Cu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602B38Cu) return; }  // 0602B388 jsr @r0 ; mov r8,r4
    c.r[2] = c.r[0] & 0xFFu;  // 0602B38C extu.b r0,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602B3AAu);  // 0602B38E mov.w 0x0602B3AA,r1
    c.t = c.r[2] == c.r[1];  // 0602B390 cmp/eq r1,r2
    if (!c.t) { goto L_0602B39A; }  // 0602B392 bf 0x0602B39A
    c.r[1] = ld32(0x0602B3BCu);  // 0602B394 mov.l 0x0602B3BC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602B39Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602B39Au) return; }  // 0602B396 jsr @r1 ; nop
L_0602B39A:
    c.r[15] = c.r[14];  // 0602B39A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602B39C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602B39E mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0602B3A0 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602B3ACu);  // 0602B3A2 mov.w 0x0602B3AC,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602B3A4 rts ; mov.l @r15+,r8
}

void f_0602B3C0(SH2Context& c) {
    ran[601] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602B3C0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602B3C2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0602B3C4 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0602B3C6 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0602B3C8 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602B3CA mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602B3CC sts.l pr,@-r15
    c.r[15] -= 128;  // 0602B3CE add #-128,r15
    c.r[3] = ld32(0x0602B548u);  // 0602B3D0 mov.l 0x0602B548,r3
    c.r[2] = ld32(c.r[3]);  // 0602B3D2 mov.l @r3,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602B53Eu);  // 0602B3D4 mov.w 0x0602B53E,r1
    c.r[0] = c.r[2];  // 0602B3D6 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0602B3D8 mov.b @(r0,r1),r1
    c.r[10] = 0x0u;  // 0602B3DA mov #0,r10
    c.r[1] = c.r[1] & 0xFFu;  // 0602B3DC extu.b r1,r1
    c.t = (int32_t)c.r[10] >= (int32_t)c.r[1];  // 0602B3DE cmp/ge r1,r10
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0602B452; } }  // 0602B3E0 bt/s 0x0602B452 ; mov r15,r14
    c.r[7] = (uint32_t)(int16_t)ld16(0x0602B540u);  // 0602B3E4 mov.w 0x0602B540,r7
L_0602B3E6:
    c.r[2] = c.r[10];  // 0602B3E6 mov r10,r2
    c.r[1] = ld32(c.r[3]);  // 0602B3E8 mov.l @r3,r1
    c.r[2] += c.r[2];  // 0602B3EA add r2,r2
    c.r[0] = c.r[1];  // 0602B3EC mov r1,r0
    c.r[1] += c.r[2];  // 0602B3EE add r2,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0602B3F0 mov.b @(r0,r2),r3
    c.r[1] += 1;  // 0602B3F2 add #1,r1
    c.r[0] = 0x7Fu;  // 0602B3F4 mov #127,r0
    c.r[3] &= c.r[0];  // 0602B3F6 and r0,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602B3F8 mov.b @r1,r2
    c.r[3] <<= 8;  // 0602B3FA shll8 r3
    c.r[2] = c.r[2] & 0xFFu;  // 0602B3FC extu.b r2,r2
    c.r[2] |= c.r[3];  // 0602B3FE or r3,r2
    c.r[1] = ld32(0x0602B54Cu);  // 0602B400 mov.l 0x0602B54C,r1
    c.r[1] = ld32(c.r[1]);  // 0602B402 mov.l @r1,r1
    c.r[2] <<= 2;  // 0602B404 shll2 r2
    c.r[2] <<= 2;  // 0602B406 shll2 r2
    c.r[2] += c.r[1];  // 0602B408 add r1,r2
    c.r[2] += 2;  // 0602B40A add #2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602B40C mov.b @r2,r1
    c.r[3] = c.r[1] & 0xFFu;  // 0602B40E extu.b r1,r3
    c.r[1] = ld32(0x0602B550u);  // 0602B410 mov.l 0x0602B550,r1
    c.r[2] = ld32(c.r[1]);  // 0602B412 mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 0602B414 mov #30,r1
    c.macl = c.r[3] * c.r[1];  // 0602B416 mul.l r1,r3
    c.r[1] = c.macl;  // 0602B418 sts macl,r1
    c.r[1] += c.r[2];  // 0602B41A add r2,r1
    c.r[1] += 15;  // 0602B41C add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602B41E mov.b @r1,r1
    c.t = c.r[3] == c.r[7];  // 0602B420 cmp/eq r7,r3
    { const bool k = c.t; c.r[9] = c.r[1] & 0xFFu; if (k) { goto L_0602B440; } }  // 0602B422 bt/s 0x0602B440 ; extu.b r1,r9
    c.t = c.r[9] == c.r[7];  // 0602B426 cmp/eq r7,r9
    { const bool k = c.t; c.r[2] = c.r[9]; if (k) { goto L_0602B440; } }  // 0602B428 bt/s 0x0602B440 ; mov r9,r2
    c.r[1] = ld32(0x0602B554u);  // 0602B42C mov.l 0x0602B554,r1
    c.r[2] += c.r[2];  // 0602B42E add r2,r2
    c.r[2] += c.r[9];  // 0602B430 add r9,r2
    c.r[1] = ld32(c.r[1]);  // 0602B432 mov.l @r1,r1
    c.r[2] <<= 2;  // 0602B434 shll2 r2
    c.r[2] += c.r[1];  // 0602B436 add r1,r2
    c.r[2] += 9;  // 0602B438 add #9,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602B43A mov.b @r2,r1
    c.r[0] = c.r[14];  // 0602B43C mov r14,r0
    st8(c.r[0] + c.r[10], c.r[1]);  // 0602B43E mov.b r1,@(r0,r10)
L_0602B440:
    c.r[3] = ld32(0x0602B548u);  // 0602B440 mov.l 0x0602B548,r3
    c.r[1] = ld32(c.r[3]);  // 0602B442 mov.l @r3,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602B53Eu);  // 0602B444 mov.w 0x0602B53E,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0602B446 mov.b @(r0,r1),r1
    c.r[10] += 1;  // 0602B448 add #1,r10
    c.r[1] = c.r[1] & 0xFFu;  // 0602B44A extu.b r1,r1
    c.t = (int32_t)c.r[10] >= (int32_t)c.r[1];  // 0602B44C cmp/ge r1,r10
    if (!c.t) { SH2_POLL(c); goto L_0602B3E6; }  // 0602B44E bf 0x0602B3E6
    c.r[10] = 0x0u;  // 0602B450 mov #0,r10
L_0602B452:
    c.r[6] = 0x7Fu;  // 0602B452 mov #127,r6
    c.r[7] = ld32(0x0602B554u);  // 0602B454 mov.l 0x0602B554,r7
    c.r[3] = 0x64u;  // 0602B456 mov #100,r3
    c.r[2] = 0x0u;  // 0602B458 mov #0,r2
L_0602B45A:
    c.r[1] = ld32(c.r[7]);  // 0602B45A mov.l @r7,r1
    c.r[10] += 1;  // 0602B45C add #1,r10
    c.t = (int32_t)c.r[10] > (int32_t)c.r[6];  // 0602B45E cmp/gt r6,r10
    c.r[1] += c.r[2];  // 0602B460 add r2,r1
    c.r[1] += 9;  // 0602B462 add #9,r1
    st8(c.r[1], c.r[3]);  // 0602B464 mov.b r3,@r1
    { const bool k = !c.t; c.r[2] += 12; if (k) { SH2_POLL(c); goto L_0602B45A; } }  // 0602B466 bf/s 0x0602B45A ; add #12,r2
    c.r[3] = ld32(0x0602B548u);  // 0602B46A mov.l 0x0602B548,r3
    c.r[2] = ld32(c.r[3]);  // 0602B46C mov.l @r3,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602B53Eu);  // 0602B46E mov.w 0x0602B53E,r1
    c.r[0] = c.r[2];  // 0602B470 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0602B472 mov.b @(r0,r1),r1
    c.r[10] = 0x0u;  // 0602B474 mov #0,r10
    c.r[1] = c.r[1] & 0xFFu;  // 0602B476 extu.b r1,r1
    c.t = (int32_t)c.r[10] >= (int32_t)c.r[1];  // 0602B478 cmp/ge r1,r10
    { const bool k = c.t; c.r[2] = c.r[10]; if (k) { goto L_0602B526; } }  // 0602B47A bt/s 0x0602B526 ; mov r10,r2
    c.r[11] = ld32(0x0602B554u);  // 0602B47E mov.l 0x0602B554,r11
    c.r[12] = ld32(0x0602B558u);  // 0602B480 mov.l 0x0602B558,r12
L_0602B482:
    c.r[1] = ld32(c.r[3]);  // 0602B482 mov.l @r3,r1
    c.r[2] += c.r[2];  // 0602B484 add r2,r2
    c.r[0] = c.r[1];  // 0602B486 mov r1,r0
    c.r[1] += c.r[2];  // 0602B488 add r2,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0602B48A mov.b @(r0,r2),r3
    c.r[1] += 1;  // 0602B48C add #1,r1
    c.r[0] = 0x7Fu;  // 0602B48E mov #127,r0
    c.r[3] &= c.r[0];  // 0602B490 and r0,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602B492 mov.b @r1,r2
    c.r[3] <<= 8;  // 0602B494 shll8 r3
    c.r[2] = c.r[2] & 0xFFu;  // 0602B496 extu.b r2,r2
    c.r[2] |= c.r[3];  // 0602B498 or r3,r2
    c.r[1] = ld32(0x0602B54Cu);  // 0602B49A mov.l 0x0602B54C,r1
    c.r[1] = ld32(c.r[1]);  // 0602B49C mov.l @r1,r1
    c.r[2] <<= 2;  // 0602B49E shll2 r2
    c.r[2] <<= 2;  // 0602B4A0 shll2 r2
    c.r[2] += c.r[1];  // 0602B4A2 add r1,r2
    c.r[2] += 2;  // 0602B4A4 add #2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602B4A6 mov.b @r2,r1
    c.r[3] = c.r[1] & 0xFFu;  // 0602B4A8 extu.b r1,r3
    c.r[1] = ld32(0x0602B550u);  // 0602B4AA mov.l 0x0602B550,r1
    c.r[2] = ld32(c.r[1]);  // 0602B4AC mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 0602B4AE mov #30,r1
    c.macl = c.r[3] * c.r[1];  // 0602B4B0 mul.l r1,r3
    c.r[1] = c.macl;  // 0602B4B2 sts macl,r1
    c.r[1] += c.r[2];  // 0602B4B4 add r2,r1
    c.r[1] += 15;  // 0602B4B6 add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602B4B8 mov.b @r1,r1
    c.r[0] = c.r[14];  // 0602B4BA mov r14,r0
    c.r[2] = ld32(c.r[11]);  // 0602B4BC mov.l @r11,r2
    c.r[9] = c.r[1] & 0xFFu;  // 0602B4BE extu.b r1,r9
    c.r[8] = c.r[9];  // 0602B4C0 mov r9,r8
    c.r[8] += c.r[8];  // 0602B4C2 add r8,r8
    c.r[8] += c.r[9];  // 0602B4C4 add r9,r8
    c.r[8] <<= 2;  // 0602B4C6 shll2 r8
    c.r[2] += c.r[8];  // 0602B4C8 add r8,r2
    c.r[2] += 9;  // 0602B4CA add #9,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 0602B4CC mov.b @(r0,r10),r1
    c.r[4] = c.r[9];  // 0602B4CE mov r9,r4
    { const uint32_t x = c.r[12]; c.pr = 0x0602B4D4u; st8(c.r[2], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602B4D4u) return; }  // 0602B4D0 jsr @r12 ; mov.b r1,@r2
    c.r[1] = ld32(c.r[11]);  // 0602B4D4 mov.l @r11,r1
    c.r[8] += c.r[1];  // 0602B4D6 add r1,r8
    c.r[8] += 8;  // 0602B4D8 add #8,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0602B4DA mov.b @r8,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0602B540u);  // 0602B4DC mov.w 0x0602B540,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0602B4DE extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 0602B4E0 cmp/eq r2,r1
    { const bool k = c.t; c.r[2] = c.r[9]; if (k) { goto L_0602B514; } }  // 0602B4E2 bt/s 0x0602B514 ; mov r9,r2
L_0602B4E6:
    c.r[2] += c.r[2];  // 0602B4E6 add r2,r2
    c.r[2] += c.r[9];  // 0602B4E8 add r9,r2
    c.r[1] = ld32(c.r[11]);  // 0602B4EA mov.l @r11,r1
    c.r[2] <<= 2;  // 0602B4EC shll2 r2
    c.r[2] += c.r[1];  // 0602B4EE add r1,r2
    c.r[2] += 8;  // 0602B4F0 add #8,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602B4F2 mov.b @r2,r1
    c.r[9] = c.r[1] & 0xFFu;  // 0602B4F4 extu.b r1,r9
    { const uint32_t x = c.r[12]; c.pr = 0x0602B4FAu; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602B4FAu) return; }  // 0602B4F6 jsr @r12 ; mov r9,r4
    c.r[2] = c.r[9];  // 0602B4FA mov r9,r2
    c.r[2] += c.r[2];  // 0602B4FC add r2,r2
    c.r[2] += c.r[9];  // 0602B4FE add r9,r2
    c.r[1] = ld32(c.r[11]);  // 0602B500 mov.l @r11,r1
    c.r[2] <<= 2;  // 0602B502 shll2 r2
    c.r[2] += c.r[1];  // 0602B504 add r1,r2
    c.r[2] += 8;  // 0602B506 add #8,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602B508 mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602B50A extu.b r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0602B540u);  // 0602B50C mov.w 0x0602B540,r2
    c.t = c.r[1] == c.r[2];  // 0602B50E cmp/eq r2,r1
    { const bool k = !c.t; c.r[2] = c.r[9]; if (k) { SH2_POLL(c); goto L_0602B4E6; } }  // 0602B510 bf/s 0x0602B4E6 ; mov r9,r2
L_0602B514:
    c.r[3] = ld32(0x0602B548u);  // 0602B514 mov.l 0x0602B548,r3
    c.r[1] = ld32(c.r[3]);  // 0602B516 mov.l @r3,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602B53Eu);  // 0602B518 mov.w 0x0602B53E,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0602B51A mov.b @(r0,r1),r1
    c.r[10] += 1;  // 0602B51C add #1,r10
    c.r[1] = c.r[1] & 0xFFu;  // 0602B51E extu.b r1,r1
    c.t = (int32_t)c.r[10] >= (int32_t)c.r[1];  // 0602B520 cmp/ge r1,r10
    { const bool k = !c.t; c.r[2] = c.r[10]; if (k) { SH2_POLL(c); goto L_0602B482; } }  // 0602B522 bf/s 0x0602B482 ; mov r10,r2
L_0602B526:
    c.r[3] = (uint32_t)(int16_t)ld16(0x0602B542u);  // 0602B526 mov.w 0x0602B542,r3
    c.r[14] += c.r[3];  // 0602B528 add r3,r14
    c.r[15] = c.r[14];  // 0602B52A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602B52C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602B52E mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0602B530 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0602B532 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0602B534 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0602B536 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602B544u);  // 0602B538 mov.w 0x0602B544,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602B53A rts ; mov.l @r15+,r8
}

void f_0602B55C(SH2Context& c) {
    ran[602] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602B55C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602B55E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0602B560 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602B562 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602B564 sts.l pr,@-r15
    c.r[1] = ld32(0x0602B604u);  // 0602B566 mov.l 0x0602B604,r1
    c.r[2] = ld32(c.r[1]);  // 0602B568 mov.l @r1,r2
    c.r[1] = c.r[2];  // 0602B56A mov r2,r1
    c.r[1] += 1;  // 0602B56C add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602B56E mov.b @r1,r1
    c.r[2] += 2;  // 0602B570 add #2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0602B572 extu.b r1,r1
    c.r[9] = c.r[1];  // 0602B574 mov r1,r9
    c.r[9] <<= 8;  // 0602B576 shll8 r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602B578 mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602B57A extu.b r1,r1
    c.r[9] |= c.r[1];  // 0602B57C or r1,r9
    c.r[1] = ld32(0x0602B608u);  // 0602B57E mov.l 0x0602B608,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602B584u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602B584u) return; }  // 0602B580 jsr @r1 ; mov r15,r14
    c.r[4] = (uint32_t)(int16_t)ld16(0x0602B5FCu);  // 0602B584 mov.w 0x0602B5FC,r4
    c.r[0] = ld32(0x0602B60Cu);  // 0602B586 mov.l 0x0602B60C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602B58Cu; c.r[4] &= c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602B58Cu) return; }  // 0602B588 jsr @r0 ; and r9,r4
    c.r[8] = c.r[0] & 0xFFu;  // 0602B58C extu.b r0,r8
    c.r[10] = (uint32_t)(int16_t)ld16(0x0602B5FEu);  // 0602B58E mov.w 0x0602B5FE,r10
    c.t = c.r[8] == c.r[10];  // 0602B590 cmp/eq r10,r8
    { const bool k = c.t; c.r[9] >>= 8; if (k) { goto L_0602B5EC; } }  // 0602B592 bt/s 0x0602B5EC ; shlr8 r9
    c.r[9] += c.r[9];  // 0602B596 add r9,r9
    c.r[9] >>= 8;  // 0602B598 shlr8 r9
    c.t = (c.r[9] & c.r[9]) == 0;  // 0602B59A tst r9,r9
    if (!c.t) { goto L_0602B5B6; }  // 0602B59C bf 0x0602B5B6
    c.r[0] = ld32(0x0602B610u);  // 0602B59E mov.l 0x0602B610,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602B5A4u; c.r[4] = c.r[8] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602B5A4u) return; }  // 0602B5A0 jsr @r0 ; extu.b r8,r4
    c.r[0] = c.r[0] & 0xFFu;  // 0602B5A4 extu.b r0,r0
    c.t = c.r[0] == c.r[10];  // 0602B5A6 cmp/eq r10,r0
    { const bool k = c.t; c.r[4] = c.r[0] & 0xFFu; if (k) { goto L_0602B5E0; } }  // 0602B5A8 bt/s 0x0602B5E0 ; extu.b r0,r4
    c.r[0] = ld32(0x0602B614u);  // 0602B5AC mov.l 0x0602B614,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602B5B2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602B5B2u) return; }  // 0602B5AE jsr @r0 ; nop
    goto L_0602B5E0;  // 0602B5B2 bra 0x0602B5E0 ; nop
L_0602B5B6:
    c.r[0] = ld32(0x0602B610u);  // 0602B5B6 mov.l 0x0602B610,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602B5BCu; c.r[4] = c.r[8] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602B5BCu) return; }  // 0602B5B8 jsr @r0 ; extu.b r8,r4
    c.r[1] = ld32(0x0602B618u);  // 0602B5BC mov.l 0x0602B618,r1
    c.r[2] = ld32(c.r[1]);  // 0602B5BE mov.l @r1,r2
    c.r[0] = c.r[0] & 0xFFu;  // 0602B5C0 extu.b r0,r0
    c.r[1] = 0x1Eu;  // 0602B5C2 mov #30,r1
    c.macl = c.r[0] * c.r[1];  // 0602B5C4 mul.l r1,r0
    c.r[4] = c.r[0] & 0xFFu;  // 0602B5C6 extu.b r0,r4
    c.r[1] = c.macl;  // 0602B5C8 sts macl,r1
    c.r[1] += c.r[2];  // 0602B5CA add r2,r1
    c.r[1] += 15;  // 0602B5CC add #15,r1
    c.r[0] = ld32(0x0602B61Cu);  // 0602B5CE mov.l 0x0602B61C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602B5D4u; st8(c.r[1], c.r[10]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602B5D4u) return; }  // 0602B5D0 jsr @r0 ; mov.b r10,@r1
    c.r[4] = c.r[0] & 0xFFu;  // 0602B5D4 extu.b r0,r4
    c.t = c.r[4] == c.r[10];  // 0602B5D6 cmp/eq r10,r4
    if (c.t) { goto L_0602B5E0; }  // 0602B5D8 bt 0x0602B5E0
    c.r[1] = ld32(0x0602B620u);  // 0602B5DA mov.l 0x0602B620,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602B5E0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602B5E0u) return; }  // 0602B5DC jsr @r1 ; nop
L_0602B5E0:
    c.r[1] = ld32(0x0602B624u);  // 0602B5E0 mov.l 0x0602B624,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602B5E6u; c.r[4] = c.r[8] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602B5E6u) return; }  // 0602B5E2 jsr @r1 ; extu.b r8,r4
    c.r[1] = ld32(0x0602B628u);  // 0602B5E6 mov.l 0x0602B628,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602B5ECu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602B5ECu) return; }  // 0602B5E8 jsr @r1 ; nop
L_0602B5EC:
    c.r[15] = c.r[14];  // 0602B5EC mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602B5EE lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602B5F0 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0602B5F2 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0602B5F4 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602B600u);  // 0602B5F6 mov.w 0x0602B600,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602B5F8 rts ; mov.l @r15+,r8
}

void f_0602B62C(SH2Context& c) {
    ran[603] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602B62C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602B62E sts.l pr,@-r15
    c.r[1] = ld32(0x0602B644u);  // 0602B630 mov.l 0x0602B644,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602B636u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602B636u) return; }  // 0602B632 jsr @r1 ; mov r15,r14
    c.r[15] = c.r[14];  // 0602B636 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602B638 lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602B640u);  // 0602B63A mov.w 0x0602B640,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602B63C rts ; mov.l @r15+,r14
}

void f_0602B648(SH2Context& c) {
    ran[604] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602B648 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602B64A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602B64C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602B64E sts.l pr,@-r15
    c.r[9] = ld32(0x0602B700u);  // 0602B650 mov.l 0x0602B700,r9
    c.r[3] = ld32(c.r[9]);  // 0602B652 mov.l @r9,r3
    c.r[1] = c.r[3];  // 0602B654 mov r3,r1
    c.r[1] += 3;  // 0602B656 add #3,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602B658 mov.b @r1,r2
    c.r[3] += 4;  // 0602B65A add #4,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0602B65C extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0602B65E mov.b @r3,r1
    c.r[2] <<= 8;  // 0602B660 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0602B662 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0602B664 or r1,r2
    c.r[8] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0602B666 exts.w r2,r8
    c.r[0] = c.r[8];  // 0602B668 mov r8,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0602B66A cmp/eq #-1,r0
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0602B674; } }  // 0602B66C bf/s 0x0602B674 ; mov r15,r14
    c.r[1] = ld32(0x0602B704u);  // 0602B670 mov.l 0x0602B704,r1
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0602B672 mov.w @r1,r8
L_0602B674:
    c.r[1] = ld32(0x0602B708u);  // 0602B674 mov.l 0x0602B708,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602B67Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602B67Au) return; }  // 0602B676 jsr @r1 ; nop
    c.r[5] = c.r[8] & 0xFFFFu;  // 0602B67A extu.w r8,r5
    c.r[2] = ld32(c.r[9]);  // 0602B67C mov.l @r9,r2
    c.r[0] = ld32(0x0602B70Cu);  // 0602B67E mov.l 0x0602B70C,r0
    c.r[1] = c.r[2];  // 0602B680 mov r2,r1
    c.r[1] += 1;  // 0602B682 add #1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602B684 mov.b @r1,r4
    c.r[2] += 2;  // 0602B686 add #2,r2
    c.r[4] = c.r[4] & 0xFFu;  // 0602B688 extu.b r4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602B68A mov.b @r2,r1
    c.r[4] <<= 8;  // 0602B68C shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 0602B68E extu.b r1,r1
    { const uint32_t x = c.r[0]; c.pr = 0x0602B694u; c.r[4] |= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602B694u) return; }  // 0602B690 jsr @r0 ; or r1,r4
    c.r[8] = c.r[0] & 0xFFu;  // 0602B694 extu.b r0,r8
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602B6FAu);  // 0602B696 mov.w 0x0602B6FA,r1
    c.t = c.r[8] == c.r[1];  // 0602B698 cmp/eq r1,r8
    if (c.t) { goto L_0602B6EC; }  // 0602B69A bt 0x0602B6EC
    c.r[1] = ld32(0x0602B710u);  // 0602B69C mov.l 0x0602B710,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602B6A2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602B6A2u) return; }  // 0602B69E jsr @r1 ; nop
    c.r[3] = 0x1Eu;  // 0602B6A2 mov #30,r3
    c.macl = c.r[8] * c.r[3];  // 0602B6A4 mul.l r3,r8
    c.r[7] = ld32(0x0602B714u);  // 0602B6A6 mov.l 0x0602B714,r7
    c.r[2] = ld32(c.r[7]);  // 0602B6A8 mov.l @r7,r2
    c.r[1] = c.macl;  // 0602B6AA sts macl,r1
    c.r[0] = c.macl;  // 0602B6AC sts macl,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 0602B6AE mov.w @(r0,r2),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0602B6B0 extu.w r1,r1
    c.r[0] = c.r[1];  // 0602B6B2 mov r1,r0
    c.t = c.r[0] == 0x3u;  // 0602B6B4 cmp/eq #3,r0
    { const bool k = !c.t; c.r[5] = 0x0u; if (k) { goto L_0602B6EC; } }  // 0602B6B6 bf/s 0x0602B6EC ; mov #0,r5
    c.r[2] = c.r[7];  // 0602B6BA mov r7,r2
    c.r[9] = c.r[3];  // 0602B6BC mov r3,r9
    c.r[4] = 0x7Fu;  // 0602B6BE mov #127,r4
    c.r[7] = 0x0u;  // 0602B6C0 mov #0,r7
L_0602B6C2:
    c.r[6] = c.r[7];  // 0602B6C2 mov r7,r6
    c.r[3] = ld32(c.r[2]);  // 0602B6C4 mov.l @r2,r3
    c.r[0] = c.r[7];  // 0602B6C6 mov r7,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 0602B6C8 mov.w @(r0,r3),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0602B6CA extu.w r1,r1
    c.r[0] = c.r[1];  // 0602B6CC mov r1,r0
    c.t = c.r[0] == 0x2u;  // 0602B6CE cmp/eq #2,r0
    { const bool k = !c.t; c.r[6] += c.r[3]; if (k) { goto L_0602B6E4; } }  // 0602B6D0 bf/s 0x0602B6E4 ; add r3,r6
    c.macl = c.r[8] * c.r[9];  // 0602B6D4 mul.l r9,r8
    c.r[1] = c.macl;  // 0602B6D6 sts macl,r1
    c.r[1] += c.r[3];  // 0602B6D8 add r3,r1
    c.r[1] += 15;  // 0602B6DA add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602B6DC mov.b @r1,r1
    c.r[6] += 15;  // 0602B6DE add #15,r6
    st8(c.r[6], c.r[1]); goto L_0602B6EC;  // 0602B6E0 bra 0x0602B6EC ; mov.b r1,@r6
L_0602B6E4:
    c.r[5] += 1;  // 0602B6E4 add #1,r5
    c.t = (int32_t)c.r[5] > (int32_t)c.r[4];  // 0602B6E6 cmp/gt r4,r5
    { const bool k = !c.t; c.r[7] += 30; if (k) { SH2_POLL(c); goto L_0602B6C2; } }  // 0602B6E8 bf/s 0x0602B6C2 ; add #30,r7
L_0602B6EC:
    c.r[15] = c.r[14];  // 0602B6EC mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602B6EE lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602B6F0 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0602B6F2 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602B6FCu);  // 0602B6F4 mov.w 0x0602B6FC,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602B6F6 rts ; mov.l @r15+,r8
}

void f_0602B718(SH2Context& c) {
    ran[605] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602B718 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602B71A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0602B71C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602B71E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602B720 sts.l pr,@-r15
    c.r[1] = ld32(0x0602B790u);  // 0602B722 mov.l 0x0602B790,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602B728u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602B728u) return; }  // 0602B724 jsr @r1 ; mov r15,r14
    c.r[1] = ld32(0x0602B794u);  // 0602B728 mov.l 0x0602B794,r1
    c.r[2] = ld32(c.r[1]);  // 0602B72A mov.l @r1,r2
    c.r[0] = ld32(0x0602B798u);  // 0602B72C mov.l 0x0602B798,r0
    c.r[1] = c.r[2];  // 0602B72E mov r2,r1
    c.r[1] += 1;  // 0602B730 add #1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602B732 mov.b @r1,r4
    c.r[2] += 2;  // 0602B734 add #2,r2
    c.r[4] = c.r[4] & 0xFFu;  // 0602B736 extu.b r4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602B738 mov.b @r2,r1
    c.r[4] <<= 8;  // 0602B73A shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 0602B73C extu.b r1,r1
    { const uint32_t x = c.r[0]; c.pr = 0x0602B742u; c.r[4] |= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602B742u) return; }  // 0602B73E jsr @r0 ; or r1,r4
    c.r[10] = c.r[0] & 0xFFu;  // 0602B742 extu.b r0,r10
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602B78Cu);  // 0602B744 mov.w 0x0602B78C,r1
    c.t = c.r[10] == c.r[1];  // 0602B746 cmp/eq r1,r10
    { const bool k = c.t; c.r[9] = 0x0u; if (k) { goto L_0602B77C; } }  // 0602B748 bt/s 0x0602B77C ; mov #0,r9
    c.r[8] = 0x0u;  // 0602B74C mov #0,r8
L_0602B74E:
    c.r[1] = ld32(0x0602B79Cu);  // 0602B74E mov.l 0x0602B79C,r1
    c.r[0] = ld32(c.r[1]);  // 0602B750 mov.l @r1,r0
    c.r[2] = c.r[8];  // 0602B752 mov r8,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[8]);  // 0602B754 mov.w @(r0,r8),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0602B756 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0602B758 tst r1,r1
    { const bool k = c.t; c.r[2] += c.r[0]; if (k) { goto L_0602B772; } }  // 0602B75A bt/s 0x0602B772 ; add r0,r2
    c.r[2] += 15;  // 0602B75E add #15,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602B760 mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602B762 extu.b r1,r1
    c.t = c.r[1] == c.r[10];  // 0602B764 cmp/eq r10,r1
    { const bool k = !c.t; c.r[1] = 0xFFFFFFFFu; if (k) { goto L_0602B772; } }  // 0602B766 bf/s 0x0602B772 ; mov #-1,r1
    st8(c.r[2], c.r[1]);  // 0602B76A mov.b r1,@r2
    c.r[1] = ld32(0x0602B7A0u);  // 0602B76C mov.l 0x0602B7A0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602B772u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602B772u) return; }  // 0602B76E jsr @r1 ; nop
L_0602B772:
    c.r[9] += 1;  // 0602B772 add #1,r9
    c.r[1] = 0x7Fu;  // 0602B774 mov #127,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 0602B776 cmp/gt r1,r9
    { const bool k = !c.t; c.r[8] += 30; if (k) { SH2_POLL(c); goto L_0602B74E; } }  // 0602B778 bf/s 0x0602B74E ; add #30,r8
L_0602B77C:
    c.r[15] = c.r[14];  // 0602B77C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602B77E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602B780 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0602B782 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0602B784 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602B78Eu);  // 0602B786 mov.w 0x0602B78E,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602B788 rts ; mov.l @r15+,r8
}

void f_0602B7A4(SH2Context& c) {
    ran[606] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602B7A4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602B7A6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0602B7A8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602B7AA mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602B7AC sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0602B7AE mov r15,r14
    c.r[1] = ld32(0x0602B83Cu);  // 0602B7B0 mov.l 0x0602B83C,r1
    c.r[2] = ld32(c.r[1]);  // 0602B7B2 mov.l @r1,r2
    c.r[9] = (uint32_t)(int16_t)ld16(0x0602B834u);  // 0602B7B4 mov.w 0x0602B834,r9
    c.r[1] = c.r[2];  // 0602B7B6 mov r2,r1
    c.r[1] += 1;  // 0602B7B8 add #1,r1
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602B7BA mov.b @r1,r8
    c.r[2] += 2;  // 0602B7BC add #2,r2
    c.r[8] = c.r[8] & 0xFFu;  // 0602B7BE extu.b r8,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602B7C0 mov.b @r2,r1
    c.r[8] <<= 8;  // 0602B7C2 shll8 r8
    c.r[1] = c.r[1] & 0xFFu;  // 0602B7C4 extu.b r1,r1
    c.r[8] |= c.r[1];  // 0602B7C6 or r1,r8
    c.r[9] &= c.r[8];  // 0602B7C8 and r8,r9
    c.r[8] >>= 8;  // 0602B7CA shlr8 r8
    c.r[1] = ld32(0x0602B840u);  // 0602B7CC mov.l 0x0602B840,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602B7D2u; c.t = c.r[8] & 1; c.r[8] >>= 1; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602B7D2u) return; }  // 0602B7CE jsr @r1 ; shlr r8
    c.r[1] = ld32(0x0602B844u);  // 0602B7D2 mov.l 0x0602B844,r1
    c.r[0] = ld32(0x0602B848u);  // 0602B7D4 mov.l 0x0602B848,r0
    c.r[1] = ld32(c.r[1]);  // 0602B7D6 mov.l @r1,r1
    c.r[5] = c.r[8];  // 0602B7D8 mov r8,r5
    c.r[1] += 8;  // 0602B7DA add #8,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602B7DC mov.b @r1,r6
    c.r[4] = c.r[9];  // 0602B7DE mov r9,r4
    c.r[6] = c.r[6] & 0xFFu;  // 0602B7E0 extu.b r6,r6
    c.r[6] >>= 2;  // 0602B7E2 shlr2 r6
    c.r[6] >>= 2;  // 0602B7E4 shlr2 r6
    { const uint32_t x = c.r[0]; c.pr = 0x0602B7EAu; c.r[6] >>= 2; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602B7EAu) return; }  // 0602B7E6 jsr @r0 ; shlr2 r6
    c.r[5] = c.r[0] & 0xFFu;  // 0602B7EA extu.b r0,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602B836u);  // 0602B7EC mov.w 0x0602B836,r1
    c.t = c.r[5] == c.r[1];  // 0602B7EE cmp/eq r1,r5
    { const bool k = c.t; c.r[10] = c.r[5]; if (k) { goto L_0602B824; } }  // 0602B7F0 bt/s 0x0602B824 ; mov r5,r10
    c.r[9] = ld32(0x0602B84Cu);  // 0602B7F4 mov.l 0x0602B84C,r9
    c.r[10] += c.r[10];  // 0602B7F6 add r10,r10
    c.r[10] += c.r[5];  // 0602B7F8 add r5,r10
    c.r[1] = ld32(c.r[9]);  // 0602B7FA mov.l @r9,r1
    c.r[10] <<= 2;  // 0602B7FC shll2 r10
    c.r[1] += c.r[10];  // 0602B7FE add r10,r1
    c.r[1] += 3;  // 0602B800 add #3,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602B802 mov.b @r1,r0
    c.r[8] = ld32(0x0602B850u);  // 0602B804 mov.l 0x0602B850,r8
    c.r[0] |= 0x8u;  // 0602B806 or #8,r0
    st8(c.r[1], c.r[0]);  // 0602B808 mov.b r0,@r1
    c.r[1] = ld32(0x0602B854u);  // 0602B80A mov.l 0x0602B854,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602B810u; c.r[4] = ld32(c.r[8]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602B810u) return; }  // 0602B80C jsr @r1 ; mov.l @r8,r4
    c.r[1] = ld32(c.r[9]);  // 0602B810 mov.l @r9,r1
    c.r[10] += c.r[1];  // 0602B812 add r1,r10
    c.r[1] = ld32(c.r[8]);  // 0602B814 mov.l @r8,r1
    c.r[1] += 12;  // 0602B816 add #12,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0602B818 mov.w @r1,r1
    c.r[10] += 10;  // 0602B81A add #10,r10
    st16(c.r[10], c.r[1]);  // 0602B81C mov.w r1,@r10
    c.r[1] = ld32(0x0602B858u);  // 0602B81E mov.l 0x0602B858,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602B824u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602B824u) return; }  // 0602B820 jsr @r1 ; nop
L_0602B824:
    c.r[15] = c.r[14];  // 0602B824 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602B826 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602B828 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0602B82A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0602B82C mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602B838u);  // 0602B82E mov.w 0x0602B838,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602B830 rts ; mov.l @r15+,r8
}

void f_0602B85C(SH2Context& c) {
    ran[607] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602B85C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602B85E sts.l pr,@-r15
    c.r[1] = ld32(0x0602B8A8u);  // 0602B860 mov.l 0x0602B8A8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602B866u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602B866u) return; }  // 0602B862 jsr @r1 ; mov r15,r14
    c.r[1] = ld32(0x0602B8ACu);  // 0602B866 mov.l 0x0602B8AC,r1
    c.r[2] = ld32(c.r[1]);  // 0602B868 mov.l @r1,r2
    c.r[0] = ld32(0x0602B8B0u);  // 0602B86A mov.l 0x0602B8B0,r0
    c.r[1] = c.r[2];  // 0602B86C mov r2,r1
    c.r[1] += 1;  // 0602B86E add #1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602B870 mov.b @r1,r4
    c.r[2] += 2;  // 0602B872 add #2,r2
    c.r[4] = c.r[4] & 0xFFu;  // 0602B874 extu.b r4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602B876 mov.b @r2,r1
    c.r[4] <<= 8;  // 0602B878 shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 0602B87A extu.b r1,r1
    { const uint32_t x = c.r[0]; c.pr = 0x0602B880u; c.r[4] |= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602B880u) return; }  // 0602B87C jsr @r0 ; or r1,r4
    c.r[5] = c.r[0] & 0xFFu;  // 0602B880 extu.b r0,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602B8A2u);  // 0602B882 mov.w 0x0602B8A2,r1
    c.t = c.r[5] == c.r[1];  // 0602B884 cmp/eq r1,r5
    if (c.t) { goto L_0602B898; }  // 0602B886 bt 0x0602B898
    c.r[1] = ld32(0x0602B8B4u);  // 0602B888 mov.l 0x0602B8B4,r1
    c.r[4] = ld32(c.r[1]);  // 0602B88A mov.l @r1,r4
    c.r[1] = ld32(0x0602B8B8u);  // 0602B88C mov.l 0x0602B8B8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602B892u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602B892u) return; }  // 0602B88E jsr @r1 ; nop
    c.r[1] = ld32(0x0602B8BCu);  // 0602B892 mov.l 0x0602B8BC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602B898u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602B898u) return; }  // 0602B894 jsr @r1 ; nop
L_0602B898:
    c.r[15] = c.r[14];  // 0602B898 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602B89A lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602B8A4u);  // 0602B89C mov.w 0x0602B8A4,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602B89E rts ; mov.l @r15+,r14
}

void f_0602B8C0(SH2Context& c) {
    ran[608] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602B8C0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602B8C2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0602B8C4 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0602B8C6 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602B8C8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602B8CA sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0602B8CC mov r15,r14
    c.r[1] = ld32(0x0602B950u);  // 0602B8CE mov.l 0x0602B950,r1
    c.r[9] = 0x0u;  // 0602B8D0 mov #0,r9
    c.r[1] = ld32(c.r[1]);  // 0602B8D2 mov.l @r1,r1
    c.r[10] = 0x0u;  // 0602B8D4 mov #0,r10
    c.r[1] += 1;  // 0602B8D6 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602B8D8 mov.b @r1,r1
    c.r[8] = 0x0u;  // 0602B8DA mov #0,r8
    c.r[11] = c.r[1] & 0xFFu;  // 0602B8DC extu.b r1,r11
L_0602B8DE:
    c.r[1] = ld32(0x0602B954u);  // 0602B8DE mov.l 0x0602B954,r1
    c.r[2] = ld32(c.r[1]);  // 0602B8E0 mov.l @r1,r2
    c.r[1] = c.r[8];  // 0602B8E2 mov r8,r1
    c.r[1] += c.r[2];  // 0602B8E4 add r2,r1
    c.r[1] += 3;  // 0602B8E6 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602B8E8 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0602B8EA mov r1,r0
    c.r[0] >>= 2;  // 0602B8EC shlr2 r0
    c.r[0] >>= 2;  // 0602B8EE shlr2 r0
    c.r[0] &= 0x3u;  // 0602B8F0 and #3,r0
    c.t = c.r[0] == c.r[11];  // 0602B8F2 cmp/eq r11,r0
    { const bool k = c.t; c.r[0] = c.r[8]; if (k) { goto L_0602B8FC; } }  // 0602B8F4 bt/s 0x0602B8FC ; mov r8,r0
    c.t = (c.r[11] & c.r[11]) == 0;  // 0602B8F8 tst r11,r11
    if (!c.t) { goto L_0602B92C; }  // 0602B8FA bf 0x0602B92C
L_0602B8FC:
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 0602B8FC mov.w @(r0,r2),r4
    c.r[0] = ld32(0x0602B958u);  // 0602B8FE mov.l 0x0602B958,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602B904u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602B904u) return; }  // 0602B900 jsr @r0 ; extu.w r4,r4
    c.r[1] = c.r[0];  // 0602B904 mov r0,r1
    c.r[3] = c.r[1] & 0xFFu;  // 0602B906 extu.b r1,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602B94Cu);  // 0602B908 mov.w 0x0602B94C,r1
    c.t = c.r[3] == c.r[1];  // 0602B90A cmp/eq r1,r3
    if (c.t) { goto L_0602B92C; }  // 0602B90C bt 0x0602B92C
    c.r[1] = ld32(0x0602B95Cu);  // 0602B90E mov.l 0x0602B95C,r1
    c.r[2] = ld32(c.r[1]);  // 0602B910 mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 0602B912 mov #30,r1
    c.macl = c.r[3] * c.r[1];  // 0602B914 mul.l r1,r3
    c.r[1] = c.macl;  // 0602B916 sts macl,r1
    c.r[1] += c.r[2];  // 0602B918 add r2,r1
    c.r[1] += 2;  // 0602B91A add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602B91C mov.b @r1,r1
    c.r[0] = c.r[1];  // 0602B91E mov r1,r0
    c.r[0] >>= 2;  // 0602B920 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0602B922 shlr r0
    c.r[0] &= 0x3u;  // 0602B924 and #3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0602B926 tst r0,r0
    if (!c.t) { goto L_0602B92C; }  // 0602B928 bf 0x0602B92C
    c.r[10] += 1;  // 0602B92A add #1,r10
L_0602B92C:
    c.r[9] += 1;  // 0602B92C add #1,r9
    c.r[1] = 0x7Fu;  // 0602B92E mov #127,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 0602B930 cmp/gt r1,r9
    { const bool k = !c.t; c.r[8] += 12; if (k) { SH2_POLL(c); goto L_0602B8DE; } }  // 0602B932 bf/s 0x0602B8DE ; add #12,r8
    c.r[1] = ld32(0x0602B960u);  // 0602B936 mov.l 0x0602B960,r1
    st32(c.r[1] + 20, c.r[10]);  // 0602B938 mov.l r10,@(20,r1)
    c.r[15] = c.r[14];  // 0602B93A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602B93C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602B93E mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0602B940 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0602B942 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0602B944 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602B94Eu);  // 0602B946 mov.w 0x0602B94E,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602B948 rts ; mov.l @r15+,r8
}

void f_0602B964(SH2Context& c) {
    ran[609] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602B964 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602B966 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0602B968 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602B96A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602B96C sts.l pr,@-r15
    c.r[10] = ld32(0x0602BA24u);  // 0602B96E mov.l 0x0602BA24,r10
    c.r[2] = ld32(c.r[10]);  // 0602B970 mov.l @r10,r2
    c.r[1] = c.r[2];  // 0602B972 mov r2,r1
    c.r[1] += 1;  // 0602B974 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602B976 mov.b @r1,r1
    c.r[2] += 2;  // 0602B978 add #2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0602B97A extu.b r1,r1
    c.r[9] = c.r[1];  // 0602B97C mov r1,r9
    c.r[9] <<= 8;  // 0602B97E shll8 r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602B980 mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602B982 extu.b r1,r1
    c.r[9] |= c.r[1];  // 0602B984 or r1,r9
    c.r[1] = ld32(0x0602BA28u);  // 0602B986 mov.l 0x0602BA28,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602B98Cu; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602B98Cu) return; }  // 0602B988 jsr @r1 ; mov r15,r14
    c.r[4] = (uint32_t)(int16_t)ld16(0x0602BA1Au);  // 0602B98C mov.w 0x0602BA1A,r4
    c.r[0] = ld32(0x0602BA2Cu);  // 0602B98E mov.l 0x0602BA2C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602B994u; c.r[4] &= c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602B994u) return; }  // 0602B990 jsr @r0 ; and r9,r4
    c.r[8] = c.r[0] & 0xFFu;  // 0602B994 extu.b r0,r8
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602BA1Cu);  // 0602B996 mov.w 0x0602BA1C,r1
    c.t = c.r[8] == c.r[1];  // 0602B998 cmp/eq r1,r8
    if (c.t) { goto L_0602BA0A; }  // 0602B99A bt 0x0602BA0A
    c.r[1] = ld32(0x0602BA30u);  // 0602B99C mov.l 0x0602BA30,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602B9A2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602B9A2u) return; }  // 0602B99E jsr @r1 ; nop
    c.r[9] >>= 8;  // 0602B9A2 shlr8 r9
    c.r[9] += c.r[9];  // 0602B9A4 add r9,r9
    c.r[9] >>= 8;  // 0602B9A6 shlr8 r9
    c.t = (c.r[9] & c.r[9]) == 0;  // 0602B9A8 tst r9,r9
    { const bool k = c.t; c.r[2] = c.r[8]; if (k) { goto L_0602B9F2; } }  // 0602B9AA bt/s 0x0602B9F2 ; mov r8,r2
    c.r[1] = ld32(0x0602BA34u);  // 0602B9AE mov.l 0x0602BA34,r1
    c.r[7] = c.r[8];  // 0602B9B0 mov r8,r7
    c.r[7] += c.r[7];  // 0602B9B2 add r7,r7
    c.r[7] += c.r[8];  // 0602B9B4 add r8,r7
    c.r[1] = ld32(c.r[1]);  // 0602B9B6 mov.l @r1,r1
    c.r[7] <<= 2;  // 0602B9B8 shll2 r7
    c.r[7] += c.r[1];  // 0602B9BA add r1,r7
    c.r[7] += 9;  // 0602B9BC add #9,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0602B9BE mov.b @r7,r1
    c.r[3] = c.r[1] & 0xFFu;  // 0602B9C0 extu.b r1,r3
    c.r[1] = ld32(c.r[10]);  // 0602B9C2 mov.l @r10,r1
    c.r[1] += 3;  // 0602B9C4 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602B9C6 mov.b @r1,r1
    c.r[3] += c.r[1];  // 0602B9C8 add r1,r3
    c.r[2] = c.r[3];  // 0602B9CA mov r3,r2
    c.r[2] -= 50;  // 0602B9CC add #-50,r2
    c.r[1] = 0x64u;  // 0602B9CE mov #100,r1
    c.t = c.r[2] > c.r[1];  // 0602B9D0 cmp/hi r1,r2
    if (c.t) { goto L_0602B9DA; }  // 0602B9D2 bt 0x0602B9DA
    st8(c.r[7], c.r[3]);  // 0602B9D4 mov.b r3,@r7
    c.r[15] = c.r[14]; goto L_0602BA0C;  // 0602B9D6 bra 0x0602BA0C ; mov r14,r15
L_0602B9DA:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602BA1Eu);  // 0602B9DA mov.w 0x0602BA1E,r1
    c.t = (int32_t)c.r[3] > (int32_t)c.r[1];  // 0602B9DC cmp/gt r1,r3
    if (!c.t) { goto L_0602B9E6; }  // 0602B9DE bf 0x0602B9E6
    st8(c.r[7], c.r[1]);  // 0602B9E0 mov.b r1,@r7
    c.r[15] = c.r[14]; goto L_0602BA0C;  // 0602B9E2 bra 0x0602BA0C ; mov r14,r15
L_0602B9E6:
    c.r[1] = 0x31u;  // 0602B9E6 mov #49,r1
    c.t = (int32_t)c.r[3] > (int32_t)c.r[1];  // 0602B9E8 cmp/gt r1,r3
    { const bool k = c.t; c.r[1] = 0x32u; if (k) { goto L_0602BA0A; } }  // 0602B9EA bt/s 0x0602BA0A ; mov #50,r1
    st8(c.r[7], c.r[1]); goto L_0602BA0A;  // 0602B9EE bra 0x0602BA0A ; mov.b r1,@r7
L_0602B9F2:
    c.r[1] = ld32(0x0602BA34u);  // 0602B9F2 mov.l 0x0602BA34,r1
    c.r[2] += c.r[2];  // 0602B9F4 add r2,r2
    c.r[2] += c.r[8];  // 0602B9F6 add r8,r2
    c.r[1] = ld32(c.r[1]);  // 0602B9F8 mov.l @r1,r1
    c.r[2] <<= 2;  // 0602B9FA shll2 r2
    c.r[2] += c.r[1];  // 0602B9FC add r1,r2
    c.r[1] = ld32(c.r[10]);  // 0602B9FE mov.l @r10,r1
    c.r[1] += 3;  // 0602BA00 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602BA02 mov.b @r1,r1
    c.r[2] += 9;  // 0602BA04 add #9,r2
    c.r[1] += 50;  // 0602BA06 add #50,r1
    st8(c.r[2], c.r[1]);  // 0602BA08 mov.b r1,@r2
L_0602BA0A:
    c.r[15] = c.r[14];  // 0602BA0A mov r14,r15
L_0602BA0C:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602BA0C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602BA0E mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0602BA10 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0602BA12 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602BA20u);  // 0602BA14 mov.w 0x0602BA20,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602BA16 rts ; mov.l @r15+,r8
}

void f_0602BA38(SH2Context& c) {
    ran[610] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602BA38 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602BA3A sts.l pr,@-r15
    c.r[1] = ld32(0x0602BA90u);  // 0602BA3C mov.l 0x0602BA90,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602BA42u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602BA42u) return; }  // 0602BA3E jsr @r1 ; mov r15,r14
    c.r[1] = ld32(0x0602BA94u);  // 0602BA42 mov.l 0x0602BA94,r1
    c.r[2] = ld32(c.r[1]);  // 0602BA44 mov.l @r1,r2
    c.r[0] = ld32(0x0602BA98u);  // 0602BA46 mov.l 0x0602BA98,r0
    c.r[1] = c.r[2];  // 0602BA48 mov r2,r1
    c.r[1] += 1;  // 0602BA4A add #1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602BA4C mov.b @r1,r4
    c.r[2] += 2;  // 0602BA4E add #2,r2
    c.r[4] = c.r[4] & 0xFFu;  // 0602BA50 extu.b r4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602BA52 mov.b @r2,r1
    c.r[4] <<= 8;  // 0602BA54 shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 0602BA56 extu.b r1,r1
    { const uint32_t x = c.r[0]; c.pr = 0x0602BA5Cu; c.r[4] |= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602BA5Cu) return; }  // 0602BA58 jsr @r0 ; or r1,r4
    c.r[0] = c.r[0] & 0xFFu;  // 0602BA5C extu.b r0,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602BA8Cu);  // 0602BA5E mov.w 0x0602BA8C,r1
    c.t = c.r[0] == c.r[1];  // 0602BA60 cmp/eq r1,r0
    { const bool k = c.t; c.r[2] = c.r[0]; if (k) { goto L_0602BA82; } }  // 0602BA62 bt/s 0x0602BA82 ; mov r0,r2
    c.r[1] = ld32(0x0602BA9Cu);  // 0602BA66 mov.l 0x0602BA9C,r1
    c.r[2] += c.r[2];  // 0602BA68 add r2,r2
    c.r[2] += c.r[0];  // 0602BA6A add r0,r2
    c.r[1] = ld32(c.r[1]);  // 0602BA6C mov.l @r1,r1
    c.r[2] <<= 2;  // 0602BA6E shll2 r2
    c.r[2] += c.r[1];  // 0602BA70 add r1,r2
    c.r[2] += 9;  // 0602BA72 add #9,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602BA74 mov.b @r2,r1
    c.r[3] = ld32(0x0602BAA0u);  // 0602BA76 mov.l 0x0602BAA0,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0602BA78 extu.b r1,r1
    st32(c.r[3] + 20, c.r[1]);  // 0602BA7A mov.l r1,@(20,r3)
    c.r[1] = ld32(0x0602BAA4u);  // 0602BA7C mov.l 0x0602BAA4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602BA82u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602BA82u) return; }  // 0602BA7E jsr @r1 ; nop
L_0602BA82:
    c.r[15] = c.r[14];  // 0602BA82 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602BA84 lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602BA8Eu);  // 0602BA86 mov.w 0x0602BA8E,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602BA88 rts ; mov.l @r15+,r14
}

void f_0602BAA8(SH2Context& c) {
    ran[611] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602BAA8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602BAAA sts.l pr,@-r15
    c.r[1] = ld32(0x0602BAFCu);  // 0602BAAC mov.l 0x0602BAFC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602BAB2u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602BAB2u) return; }  // 0602BAAE jsr @r1 ; mov r15,r14
    c.r[1] = ld32(0x0602BB00u);  // 0602BAB2 mov.l 0x0602BB00,r1
    c.r[2] = ld32(c.r[1]);  // 0602BAB4 mov.l @r1,r2
    c.r[1] = c.r[2];  // 0602BAB6 mov r2,r1
    c.r[1] += 3;  // 0602BAB8 add #3,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602BABA mov.b @r1,r5
    c.r[0] = ld32(0x0602BB04u);  // 0602BABC mov.l 0x0602BB04,r0
    c.r[5] = c.r[5] & 0xFFu;  // 0602BABE extu.b r5,r5
    c.r[1] = c.r[2];  // 0602BAC0 mov r2,r1
    c.r[1] += 4;  // 0602BAC2 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602BAC4 mov.b @r1,r1
    c.r[5] <<= 8;  // 0602BAC6 shll8 r5
    c.r[1] = c.r[1] & 0xFFu;  // 0602BAC8 extu.b r1,r1
    c.r[5] |= c.r[1];  // 0602BACA or r1,r5
    c.r[1] = c.r[2];  // 0602BACC mov r2,r1
    c.r[1] += 1;  // 0602BACE add #1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602BAD0 mov.b @r1,r4
    c.r[2] += 2;  // 0602BAD2 add #2,r2
    c.r[4] = c.r[4] & 0xFFu;  // 0602BAD4 extu.b r4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602BAD6 mov.b @r2,r1
    c.r[4] <<= 8;  // 0602BAD8 shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 0602BADA extu.b r1,r1
    { const uint32_t x = c.r[0]; c.pr = 0x0602BAE0u; c.r[4] |= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602BAE0u) return; }  // 0602BADC jsr @r0 ; or r1,r4
    c.r[2] = c.r[0] & 0xFFu;  // 0602BAE0 extu.b r0,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602BAF8u);  // 0602BAE2 mov.w 0x0602BAF8,r1
    c.t = c.r[2] == c.r[1];  // 0602BAE4 cmp/eq r1,r2
    if (!c.t) { goto L_0602BAEE; }  // 0602BAE6 bf 0x0602BAEE
    c.r[1] = ld32(0x0602BB08u);  // 0602BAE8 mov.l 0x0602BB08,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602BAEEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602BAEEu) return; }  // 0602BAEA jsr @r1 ; nop
L_0602BAEE:
    c.r[15] = c.r[14];  // 0602BAEE mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602BAF0 lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602BAFAu);  // 0602BAF2 mov.w 0x0602BAFA,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602BAF4 rts ; mov.l @r15+,r14
}

void f_0602BB0C(SH2Context& c) {
    ran[612] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602BB0C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602BB0E sts.l pr,@-r15
    c.r[1] = ld32(0x0602BB7Cu);  // 0602BB10 mov.l 0x0602BB7C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602BB16u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602BB16u) return; }  // 0602BB12 jsr @r1 ; mov r15,r14
    c.r[1] = ld32(0x0602BB80u);  // 0602BB16 mov.l 0x0602BB80,r1
    c.r[2] = ld32(c.r[1]);  // 0602BB18 mov.l @r1,r2
    c.r[0] = ld32(0x0602BB84u);  // 0602BB1A mov.l 0x0602BB84,r0
    c.r[1] = c.r[2];  // 0602BB1C mov r2,r1
    c.r[1] += 1;  // 0602BB1E add #1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602BB20 mov.b @r1,r4
    c.r[2] += 2;  // 0602BB22 add #2,r2
    c.r[4] = c.r[4] & 0xFFu;  // 0602BB24 extu.b r4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602BB26 mov.b @r2,r1
    c.r[4] <<= 8;  // 0602BB28 shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 0602BB2A extu.b r1,r1
    { const uint32_t x = c.r[0]; c.pr = 0x0602BB30u; c.r[4] |= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602BB30u) return; }  // 0602BB2C jsr @r0 ; or r1,r4
    c.r[0] = c.r[0] & 0xFFu;  // 0602BB30 extu.b r0,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602BB76u);  // 0602BB32 mov.w 0x0602BB76,r1
    c.t = c.r[0] == c.r[1];  // 0602BB34 cmp/eq r1,r0
    { const bool k = c.t; c.r[2] = 0x0u; if (k) { goto L_0602BB6C; } }  // 0602BB36 bt/s 0x0602BB6C ; mov #0,r2
L_0602BB3A:
    c.r[1] = ld32(0x0602BB88u);  // 0602BB3A mov.l 0x0602BB88,r1
    c.r[3] = c.r[2];  // 0602BB3C mov r2,r3
    c.r[3] += c.r[3];  // 0602BB3E add r3,r3
    c.r[3] += c.r[2];  // 0602BB40 add r2,r3
    c.r[1] = ld32(c.r[1]);  // 0602BB42 mov.l @r1,r1
    c.r[3] <<= 2;  // 0602BB44 shll2 r3
    c.r[3] += c.r[1];  // 0602BB46 add r1,r3
    c.r[3] += 8;  // 0602BB48 add #8,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0602BB4A mov.b @r3,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602BB4C extu.b r1,r1
    c.t = c.r[1] == c.r[0];  // 0602BB4E cmp/eq r0,r1
    { const bool k = !c.t; c.r[1] = c.r[2]; if (k) { goto L_0602BB62; } }  // 0602BB50 bf/s 0x0602BB62 ; mov r2,r1
    c.r[1] = 0xFFFFFFFFu;  // 0602BB54 mov #-1,r1
    st8(c.r[3], c.r[1]);  // 0602BB56 mov.b r1,@r3
    c.r[1] = ld32(0x0602BB8Cu);  // 0602BB58 mov.l 0x0602BB8C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602BB5Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602BB5Eu) return; }  // 0602BB5A jsr @r1 ; nop
    c.r[15] = c.r[14]; goto L_0602BB6E;  // 0602BB5E bra 0x0602BB6E ; mov r14,r15
L_0602BB62:
    c.r[1] += 1;  // 0602BB62 add #1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0602BB64 extu.b r1,r2
    c.r[1] = 0x7Fu;  // 0602BB66 mov #127,r1
    c.t = c.r[2] > c.r[1];  // 0602BB68 cmp/hi r1,r2
    if (!c.t) { SH2_POLL(c); goto L_0602BB3A; }  // 0602BB6A bf 0x0602BB3A
L_0602BB6C:
    c.r[15] = c.r[14];  // 0602BB6C mov r14,r15
L_0602BB6E:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602BB6E lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602BB78u);  // 0602BB70 mov.w 0x0602BB78,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602BB72 rts ; mov.l @r15+,r14
}

void f_0602BB90(SH2Context& c) {
    ran[613] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602BB90 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602BB92 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0602BB94 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0602BB96 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602BB98 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602BB9A sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0602BB9C mov r15,r14
    c.r[9] = 0x0u;  // 0602BB9E mov #0,r9
    c.r[11] = ld32(0x0602BBE8u);  // 0602BBA0 mov.l 0x0602BBE8,r11
    c.r[10] = ld32(0x0602BBECu);  // 0602BBA2 mov.l 0x0602BBEC,r10
    c.r[8] = 0x0u;  // 0602BBA4 mov #0,r8
L_0602BBA6:
    c.r[0] = ld32(c.r[11]);  // 0602BBA6 mov.l @r11,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[8]);  // 0602BBA8 mov.w @(r0,r8),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0602BBAA extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0602BBAC tst r1,r1
    if (c.t) { goto L_0602BBC8; }  // 0602BBAE bt 0x0602BBC8
    { const uint32_t x = c.r[10]; c.pr = 0x0602BBB4u; c.r[4] = c.r[9] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602BBB4u) return; }  // 0602BBB0 jsr @r10 ; extu.b r9,r4
    c.r[1] = ld32(c.r[11]);  // 0602BBB4 mov.l @r11,r1
    c.r[1] += c.r[8];  // 0602BBB6 add r8,r1
    c.r[1] += 8;  // 0602BBB8 add #8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602BBBA mov.b @r1,r1
    c.r[4] = c.r[1] & 0xFFu;  // 0602BBBC extu.b r1,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602BBE4u);  // 0602BBBE mov.w 0x0602BBE4,r1
    c.t = c.r[4] == c.r[1];  // 0602BBC0 cmp/eq r1,r4
    if (c.t) { goto L_0602BBC8; }  // 0602BBC2 bt 0x0602BBC8
    { const uint32_t x = c.r[10]; c.pr = 0x0602BBC8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602BBC8u) return; }  // 0602BBC4 jsr @r10 ; nop
L_0602BBC8:
    c.r[9] += 1;  // 0602BBC8 add #1,r9
    c.r[1] = 0x7Fu;  // 0602BBCA mov #127,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 0602BBCC cmp/gt r1,r9
    { const bool k = !c.t; c.r[8] += 12; if (k) { SH2_POLL(c); goto L_0602BBA6; } }  // 0602BBCE bf/s 0x0602BBA6 ; add #12,r8
    c.r[15] = c.r[14];  // 0602BBD2 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602BBD4 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602BBD6 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0602BBD8 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0602BBDA mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0602BBDC mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602BBE6u);  // 0602BBDE mov.w 0x0602BBE6,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602BBE0 rts ; mov.l @r15+,r8
}

void f_0602BBF0(SH2Context& c) {
    ran[614] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602BBF0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602BBF2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602BBF4 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0602BBF6 mov r15,r14
    c.r[1] = ld32(0x0602BC40u);  // 0602BBF8 mov.l 0x0602BC40,r1
    c.r[2] = ld32(c.r[1]);  // 0602BBFA mov.l @r1,r2
    c.r[0] = ld32(0x0602BC44u);  // 0602BBFC mov.l 0x0602BC44,r0
    c.r[1] = c.r[2];  // 0602BBFE mov r2,r1
    c.r[1] += 1;  // 0602BC00 add #1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602BC02 mov.b @r1,r4
    c.r[2] += 2;  // 0602BC04 add #2,r2
    c.r[4] = c.r[4] & 0xFFu;  // 0602BC06 extu.b r4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602BC08 mov.b @r2,r1
    c.r[4] <<= 8;  // 0602BC0A shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 0602BC0C extu.b r1,r1
    c.r[4] |= c.r[1];  // 0602BC0E or r1,r4
    c.r[8] = c.r[4];  // 0602BC10 mov r4,r8
    c.r[8] >>= 8;  // 0602BC12 shlr8 r8
    c.t = c.r[8] & 1; c.r[8] >>= 1;  // 0602BC14 shlr r8
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602BC38u);  // 0602BC16 mov.w 0x0602BC38,r1
    { const uint32_t x = c.r[0]; c.pr = 0x0602BC1Cu; c.r[4] &= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602BC1Cu) return; }  // 0602BC18 jsr @r0 ; and r1,r4
    c.r[0] = c.r[0] & 0xFFu;  // 0602BC1C extu.b r0,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602BC3Au);  // 0602BC1E mov.w 0x0602BC3A,r1
    c.t = c.r[0] == c.r[1];  // 0602BC20 cmp/eq r1,r0
    { const bool k = c.t; c.r[4] = c.r[0] & 0xFFu; if (k) { goto L_0602BC2C; } }  // 0602BC22 bt/s 0x0602BC2C ; extu.b r0,r4
    c.r[1] = ld32(0x0602BC48u);  // 0602BC26 mov.l 0x0602BC48,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602BC2Cu; c.r[5] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602BC2Cu) return; }  // 0602BC28 jsr @r1 ; mov r8,r5
L_0602BC2C:
    c.r[15] = c.r[14];  // 0602BC2C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602BC2E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602BC30 mov.l @r15+,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602BC3Cu);  // 0602BC32 mov.w 0x0602BC3C,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602BC34 rts ; mov.l @r15+,r8
}

void f_0602BC4C(SH2Context& c) {
    ran[615] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602BC4C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602BC4E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0602BC50 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0602BC52 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0602BC54 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602BC56 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602BC58 sts.l pr,@-r15
    c.r[1] = ld32(0x0602BD70u);  // 0602BC5A mov.l 0x0602BD70,r1
    c.r[2] = ld32(c.r[1]);  // 0602BC5C mov.l @r1,r2
    c.r[1] = c.r[2];  // 0602BC5E mov r2,r1
    c.r[1] += 1;  // 0602BC60 add #1,r1
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602BC62 mov.b @r1,r8
    c.r[8] = c.r[8] & 0xFFu;  // 0602BC64 extu.b r8,r8
    c.r[1] = c.r[2];  // 0602BC66 mov r2,r1
    c.r[1] += 2;  // 0602BC68 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602BC6A mov.b @r1,r1
    c.r[8] <<= 8;  // 0602BC6C shll8 r8
    c.r[1] = c.r[1] & 0xFFu;  // 0602BC6E extu.b r1,r1
    c.r[8] |= c.r[1];  // 0602BC70 or r1,r8
    c.r[1] = c.r[2];  // 0602BC72 mov r2,r1
    c.r[1] += 3;  // 0602BC74 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602BC76 mov.b @r1,r1
    c.r[2] += 4;  // 0602BC78 add #4,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0602BC7A extu.b r1,r1
    c.r[10] = c.r[1];  // 0602BC7C mov r1,r10
    c.r[10] <<= 8;  // 0602BC7E shll8 r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602BC80 mov.b @r2,r1
    c.r[14] = c.r[15];  // 0602BC82 mov r15,r14
    c.r[1] = c.r[1] & 0xFFu;  // 0602BC84 extu.b r1,r1
    c.r[10] |= c.r[1];  // 0602BC86 or r1,r10
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602BD64u);  // 0602BC88 mov.w 0x0602BD64,r1
    c.r[9] = c.r[1];  // 0602BC8A mov r1,r9
    c.r[9] &= c.r[8];  // 0602BC8C and r8,r9
    c.r[1] = ld32(0x0602BD74u);  // 0602BC8E mov.l 0x0602BD74,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602BC94u; c.r[12] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602BC94u) return; }  // 0602BC90 jsr @r1 ; mov r9,r12
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602BD66u);  // 0602BC94 mov.w 0x0602BD66,r1
    c.r[8] &= c.r[1];  // 0602BC96 and r1,r8
    c.r[0] = ld32(0x0602BD78u);  // 0602BC98 mov.l 0x0602BD78,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602BC9Eu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602BC9Eu) return; }  // 0602BC9A jsr @r0 ; mov r8,r4
    c.r[8] = c.r[0] & 0xFFu;  // 0602BC9E extu.b r0,r8
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602BD68u);  // 0602BCA0 mov.w 0x0602BD68,r1
    c.t = c.r[8] == c.r[1];  // 0602BCA2 cmp/eq r1,r8
    if (c.t) { goto L_0602BD50; }  // 0602BCA4 bt 0x0602BD50
    c.r[11] = ld32(0x0602BD7Cu);  // 0602BCA6 mov.l 0x0602BD7C,r11
    c.r[4] = ld32(c.r[11]);  // 0602BCA8 mov.l @r11,r4
    c.r[1] = ld32(0x0602BD80u);  // 0602BCAA mov.l 0x0602BD80,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602BCB0u; c.r[5] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602BCB0u) return; }  // 0602BCAC jsr @r1 ; mov r8,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602BD6Au);  // 0602BCB0 mov.w 0x0602BD6A,r1
    c.t = c.r[9] == c.r[1];  // 0602BCB2 cmp/eq r1,r9
    { const bool k = c.t; c.r[3] = c.r[8]; if (k) { goto L_0602BD04; } }  // 0602BCB4 bt/s 0x0602BD04 ; mov r8,r3
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 0602BCB8 cmp/gt r1,r9
    { const bool k = c.t; c.t = (c.r[9] & c.r[9]) == 0; if (k) { goto L_0602BCC6; } }  // 0602BCBA bt/s 0x0602BCC6 ; tst r9,r9
    { const bool k = c.t; c.r[15] = c.r[14]; if (k) { goto L_0602BCD2; } }  // 0602BCBE bt/s 0x0602BCD2 ; mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; } goto L_0602BD54;  // 0602BCC2 bra 0x0602BD54 ; lds.l @r15+,pr
L_0602BCC6:
    c.r[1] = ld32(0x0602BD84u);  // 0602BCC6 mov.l 0x0602BD84,r1
    c.t = c.r[12] == c.r[1];  // 0602BCC8 cmp/eq r1,r12
    { const bool k = c.t; c.r[2] = c.r[8]; if (k) { goto L_0602BD2E; } }  // 0602BCCA bt/s 0x0602BD2E ; mov r8,r2
    c.r[15] = c.r[14]; goto L_0602BD52;  // 0602BCCE bra 0x0602BD52 ; mov r14,r15
L_0602BCD2:
    c.r[1] = ld32(c.r[11]);  // 0602BCD2 mov.l @r11,r1
    c.r[1] += 12;  // 0602BCD4 add #12,r1
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0602BCD6 mov.w @r1,r3
    c.r[1] = c.r[3] & 0xFFFFu;  // 0602BCD8 extu.w r3,r1
    c.t = c.r[10] >= c.r[1];  // 0602BCDA cmp/hs r1,r10
    { const bool k = c.t; c.r[2] = c.r[8]; if (k) { goto L_0602BCF2; } }  // 0602BCDC bt/s 0x0602BCF2 ; mov r8,r2
    c.r[1] = ld32(0x0602BD88u);  // 0602BCE0 mov.l 0x0602BD88,r1
    c.r[1] = ld32(c.r[1]);  // 0602BCE2 mov.l @r1,r1
    c.r[2] += c.r[2];  // 0602BCE4 add r2,r2
    c.r[2] += c.r[8];  // 0602BCE6 add r8,r2
    c.r[2] <<= 2;  // 0602BCE8 shll2 r2
    c.r[2] += c.r[1];  // 0602BCEA add r1,r2
    c.r[2] += 10;  // 0602BCEC add #10,r2
    st16(c.r[2], c.r[10]); goto L_0602BD50;  // 0602BCEE bra 0x0602BD50 ; mov.w r10,@r2
L_0602BCF2:
    c.r[1] = ld32(0x0602BD88u);  // 0602BCF2 mov.l 0x0602BD88,r1
    c.r[1] = ld32(c.r[1]);  // 0602BCF4 mov.l @r1,r1
    c.r[2] += c.r[2];  // 0602BCF6 add r2,r2
    c.r[2] += c.r[8];  // 0602BCF8 add r8,r2
    c.r[2] <<= 2;  // 0602BCFA shll2 r2
    c.r[2] += c.r[1];  // 0602BCFC add r1,r2
    c.r[2] += 10;  // 0602BCFE add #10,r2
    st16(c.r[2], c.r[3]); goto L_0602BD50;  // 0602BD00 bra 0x0602BD50 ; mov.w r3,@r2
L_0602BD04:
    c.r[1] = ld32(0x0602BD88u);  // 0602BD04 mov.l 0x0602BD88,r1
    c.r[3] += c.r[3];  // 0602BD06 add r3,r3
    c.r[3] += c.r[8];  // 0602BD08 add r8,r3
    c.r[1] = ld32(c.r[1]);  // 0602BD0A mov.l @r1,r1
    c.r[3] <<= 2;  // 0602BD0C shll2 r3
    c.r[3] += c.r[1];  // 0602BD0E add r1,r3
    c.r[3] += 10;  // 0602BD10 add #10,r3
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0602BD12 mov.w @r3,r6
    c.r[1] = ld32(c.r[11]);  // 0602BD14 mov.l @r11,r1
    c.r[2] = c.r[6] & 0xFFFFu;  // 0602BD16 extu.w r6,r2
    c.r[1] += 12;  // 0602BD18 add #12,r1
    c.r[7] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0602BD1A mov.w @r1,r7
    c.r[2] += c.r[10];  // 0602BD1C add r10,r2
    c.r[1] = c.r[7] & 0xFFFFu;  // 0602BD1E extu.w r7,r1
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[1];  // 0602BD20 cmp/ge r1,r2
    { const bool k = c.t; c.r[10] += c.r[6]; if (k) { goto L_0602BD2A; } }  // 0602BD22 bt/s 0x0602BD2A ; add r6,r10
    st16(c.r[3], c.r[10]); goto L_0602BD50;  // 0602BD26 bra 0x0602BD50 ; mov.w r10,@r3
L_0602BD2A:
    st16(c.r[3], c.r[7]); goto L_0602BD50;  // 0602BD2A bra 0x0602BD50 ; mov.w r7,@r3
L_0602BD2E:
    c.r[1] = ld32(0x0602BD88u);  // 0602BD2E mov.l 0x0602BD88,r1
    c.r[2] += c.r[2];  // 0602BD30 add r2,r2
    c.r[2] += c.r[8];  // 0602BD32 add r8,r2
    c.r[1] = ld32(c.r[1]);  // 0602BD34 mov.l @r1,r1
    c.r[2] <<= 2;  // 0602BD36 shll2 r2
    c.r[2] += c.r[1];  // 0602BD38 add r1,r2
    c.r[2] += 10;  // 0602BD3A add #10,r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0602BD3C mov.w @r2,r3
    c.r[1] = c.r[3] & 0xFFFFu;  // 0602BD3E extu.w r3,r1
    c.r[1] -= c.r[10];  // 0602BD40 sub r10,r1
    c.t = (int32_t)c.r[1] >= 0;  // 0602BD42 cmp/pz r1
    { const bool k = !c.t; c.r[1] = c.r[3]; if (k) { goto L_0602BD4C; } }  // 0602BD44 bf/s 0x0602BD4C ; mov r3,r1
    c.r[1] -= c.r[10]; goto L_0602BD4E;  // 0602BD48 bra 0x0602BD4E ; sub r10,r1
L_0602BD4C:
    c.r[1] = 0x0u;  // 0602BD4C mov #0,r1
L_0602BD4E:
    st16(c.r[2], c.r[1]);  // 0602BD4E mov.w r1,@r2
L_0602BD50:
    c.r[15] = c.r[14];  // 0602BD50 mov r14,r15
L_0602BD52:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602BD52 lds.l @r15+,pr
L_0602BD54:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602BD54 mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0602BD56 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0602BD58 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0602BD5A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0602BD5C mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602BD6Cu);  // 0602BD5E mov.w 0x0602BD6C,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602BD60 rts ; mov.l @r15+,r8
}

void f_0602BD8C(SH2Context& c) {
    ran[616] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602BD8C mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0602BD8E mov r15,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602BD96u);  // 0602BD90 mov.w 0x0602BD96,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602BD92 rts ; mov.l @r15+,r14
}

void f_0602BD98(SH2Context& c) {
    ran[617] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602BD98 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602BD9A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602BD9C sts.l pr,@-r15
    c.r[1] = ld32(0x0602BE0Cu);  // 0602BD9E mov.l 0x0602BE0C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602BDA4u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602BDA4u) return; }  // 0602BDA0 jsr @r1 ; mov r15,r14
    c.r[8] = ld32(0x0602BE10u);  // 0602BDA4 mov.l 0x0602BE10,r8
    c.r[2] = ld32(c.r[8]);  // 0602BDA6 mov.l @r8,r2
    c.r[0] = ld32(0x0602BE14u);  // 0602BDA8 mov.l 0x0602BE14,r0
    c.r[1] = c.r[2];  // 0602BDAA mov r2,r1
    c.r[1] += 1;  // 0602BDAC add #1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602BDAE mov.b @r1,r4
    c.r[2] += 2;  // 0602BDB0 add #2,r2
    c.r[4] = c.r[4] & 0xFFu;  // 0602BDB2 extu.b r4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602BDB4 mov.b @r2,r1
    c.r[4] <<= 8;  // 0602BDB6 shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 0602BDB8 extu.b r1,r1
    { const uint32_t x = c.r[0]; c.pr = 0x0602BDBEu; c.r[4] |= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602BDBEu) return; }  // 0602BDBA jsr @r0 ; or r1,r4
    c.r[5] = c.r[0] & 0xFFu;  // 0602BDBE extu.b r0,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602BE06u);  // 0602BDC0 mov.w 0x0602BE06,r1
    c.t = c.r[5] == c.r[1];  // 0602BDC2 cmp/eq r1,r5
    { const bool k = c.t; c.r[7] = c.r[5]; if (k) { goto L_0602BDFA; } }  // 0602BDC4 bt/s 0x0602BDFA ; mov r5,r7
    c.r[1] = ld32(0x0602BE18u);  // 0602BDC8 mov.l 0x0602BE18,r1
    c.r[7] += c.r[7];  // 0602BDCA add r7,r7
    c.r[7] += c.r[5];  // 0602BDCC add r5,r7
    c.r[6] = ld32(c.r[1]);  // 0602BDCE mov.l @r1,r6
    c.r[7] <<= 2;  // 0602BDD0 shll2 r7
    c.r[3] = ld32(c.r[8]);  // 0602BDD2 mov.l @r8,r3
    c.r[0] = c.r[7];  // 0602BDD4 mov r7,r0
    c.r[1] = c.r[3];  // 0602BDD6 mov r3,r1
    c.r[1] += 3;  // 0602BDD8 add #3,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602BDDA mov.b @r1,r2
    c.r[3] += 4;  // 0602BDDC add #4,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0602BDDE extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0602BDE0 mov.b @r3,r1
    c.r[2] <<= 8;  // 0602BDE2 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0602BDE4 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0602BDE6 or r1,r2
    st16(c.r[0] + c.r[6], c.r[2]);  // 0602BDE8 mov.w r2,@(r0,r6)
    c.r[1] = ld32(0x0602BE1Cu);  // 0602BDEA mov.l 0x0602BE1C,r1
    c.r[4] = ld32(c.r[1]);  // 0602BDEC mov.l @r1,r4
    c.r[1] = ld32(0x0602BE20u);  // 0602BDEE mov.l 0x0602BE20,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602BDF4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602BDF4u) return; }  // 0602BDF0 jsr @r1 ; nop
    c.r[1] = ld32(0x0602BE24u);  // 0602BDF4 mov.l 0x0602BE24,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602BDFAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602BDFAu) return; }  // 0602BDF6 jsr @r1 ; nop
L_0602BDFA:
    c.r[15] = c.r[14];  // 0602BDFA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602BDFC lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602BDFE mov.l @r15+,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602BE08u);  // 0602BE00 mov.w 0x0602BE08,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602BE02 rts ; mov.l @r15+,r8
}

void f_0602BE28(SH2Context& c) {
    ran[618] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602BE28 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602BE2A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0602BE2C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0602BE2E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0602BE30 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0602BE32 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602BE34 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602BE36 sts.l pr,@-r15
    c.r[15] -= 92;  // 0602BE38 add #-92,r15
    c.r[14] = c.r[15];  // 0602BE3A mov r15,r14
    c.r[11] = (uint32_t)(int16_t)ld16(0x0602BFFEu);  // 0602BE3C mov.w 0x0602BFFE,r11
    st32(c.r[14] + 16, c.r[11]);  // 0602BE3E mov.l r11,@(16,r14)
    c.r[13] = 0x0u;  // 0602BE40 mov #0,r13
    c.r[0] = 0x40u;  // 0602BE42 mov #64,r0
    st32(c.r[0] + c.r[14], c.r[13]);  // 0602BE44 mov.l r13,@(r0,r14)
    c.r[0] = 0x0u;  // 0602BE46 mov #0,r0
    st32(c.r[14] + 60, c.r[0]);  // 0602BE48 mov.l r0,@(60,r14)
    st32(c.r[14] + 56, c.r[13]);  // 0602BE4A mov.l r13,@(56,r14)
    st32(c.r[14] + 52, c.r[0]);  // 0602BE4C mov.l r0,@(52,r14)
    st32(c.r[14] + 48, c.r[13]);  // 0602BE4E mov.l r13,@(48,r14)
    st32(c.r[14] + 44, c.r[0]);  // 0602BE50 mov.l r0,@(44,r14)
    st32(c.r[14] + 40, c.r[13]);  // 0602BE52 mov.l r13,@(40,r14)
    st32(c.r[14] + 36, c.r[0]);  // 0602BE54 mov.l r0,@(36,r14)
    st32(c.r[14] + 32, c.r[13]);  // 0602BE56 mov.l r13,@(32,r14)
    st32(c.r[14] + 28, c.r[0]);  // 0602BE58 mov.l r0,@(28,r14)
    st32(c.r[14] + 24, c.r[13]);  // 0602BE5A mov.l r13,@(24,r14)
    st32(c.r[14] + 20, c.r[0]);  // 0602BE5C mov.l r0,@(20,r14)
    c.r[13] = 0x48u;  // 0602BE5E mov #72,r13
    c.r[13] += c.r[14];  // 0602BE60 add r14,r13
    st32(c.r[13], c.r[0]);  // 0602BE62 mov.l r0,@r13
    c.r[13] = 0x44u;  // 0602BE64 mov #68,r13
    c.r[13] += c.r[14];  // 0602BE66 add r14,r13
    c.r[1] = ld32(0x0602C004u);  // 0602BE68 mov.l 0x0602C004,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602BE6Eu; st32(c.r[13], c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602BE6Eu) return; }  // 0602BE6A jsr @r1 ; mov.l r0,@r13
    c.r[10] = ld32(0x0602C008u);  // 0602BE6E mov.l 0x0602C008,r10
    c.r[13] = 0x54u;  // 0602BE70 mov #84,r13
    c.r[13] += c.r[14];  // 0602BE72 add r14,r13
    c.r[2] = ld32(c.r[10]);  // 0602BE74 mov.l @r10,r2
    c.r[8] = (uint32_t)(int16_t)ld16(0x0602C000u);  // 0602BE76 mov.w 0x0602C000,r8
    c.r[1] = c.r[2];  // 0602BE78 mov r2,r1
    c.r[1] += 1;  // 0602BE7A add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602BE7C mov.b @r1,r1
    c.r[2] += 2;  // 0602BE7E add #2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0602BE80 extu.b r1,r1
    c.r[0] = c.r[1];  // 0602BE82 mov r1,r0
    c.r[0] <<= 8;  // 0602BE84 shll8 r0
    st32(c.r[13], c.r[0]);  // 0602BE86 mov.l r0,@r13
    c.r[13] = 0x54u;  // 0602BE88 mov #84,r13
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602BE8A mov.b @r2,r1
    c.r[13] += c.r[14];  // 0602BE8C add r14,r13
    c.r[0] = ld32(c.r[13]);  // 0602BE8E mov.l @r13,r0
    c.r[1] = c.r[1] & 0xFFu;  // 0602BE90 extu.b r1,r1
    c.r[0] |= c.r[1];  // 0602BE92 or r1,r0
    st32(c.r[13], c.r[0]);  // 0602BE94 mov.l r0,@r13
    c.r[13] = 0x54u;  // 0602BE96 mov #84,r13
    c.r[13] += c.r[14];  // 0602BE98 add r14,r13
    c.r[4] = ld32(c.r[13]);  // 0602BE9A mov.l @r13,r4
    c.r[9] = ld32(0x0602C00Cu);  // 0602BE9C mov.l 0x0602C00C,r9
    { const uint32_t x = c.r[9]; c.pr = 0x0602BEA2u; c.r[4] &= c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602BEA2u) return; }  // 0602BE9E jsr @r9 ; and r8,r4
    c.r[1] = c.r[0];  // 0602BEA2 mov r0,r1
    c.r[12] = c.r[1] & 0xFFu;  // 0602BEA4 extu.b r1,r12
    c.t = c.r[12] == c.r[11];  // 0602BEA6 cmp/eq r11,r12
    if (!c.t) { goto L_0602BEAE; }  // 0602BEA8 bf 0x0602BEAE
    goto L_0602C34A;  // 0602BEAA bra 0x0602C34A ; nop
L_0602BEAE:
    c.r[2] = ld32(c.r[10]);  // 0602BEAE mov.l @r10,r2
    c.r[1] = c.r[2];  // 0602BEB0 mov r2,r1
    c.r[1] += 3;  // 0602BEB2 add #3,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602BEB4 mov.b @r1,r4
    c.r[2] += 4;  // 0602BEB6 add #4,r2
    c.r[4] = c.r[4] & 0xFFu;  // 0602BEB8 extu.b r4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602BEBA mov.b @r2,r1
    c.r[4] <<= 8;  // 0602BEBC shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 0602BEBE extu.b r1,r1
    c.r[4] |= c.r[1];  // 0602BEC0 or r1,r4
    { const uint32_t x = c.r[9]; c.pr = 0x0602BEC6u; c.r[4] &= c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602BEC6u) return; }  // 0602BEC2 jsr @r9 ; and r8,r4
    c.r[9] = c.r[0] & 0xFFu;  // 0602BEC6 extu.b r0,r9
    c.t = c.r[9] == c.r[11];  // 0602BEC8 cmp/eq r11,r9
    { const bool k = !c.t; c.r[5] = 0x1u; if (k) { goto L_0602BED2; } }  // 0602BECA bf/s 0x0602BED2 ; mov #1,r5
    goto L_0602C34A;  // 0602BECE bra 0x0602C34A ; nop
L_0602BED2:
    c.r[8] = ld32(0x0602C010u);  // 0602BED2 mov.l 0x0602C010,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0602BED8u; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602BED8u) return; }  // 0602BED4 jsr @r8 ; mov r12,r4
    c.r[10] = c.r[0] & 0xFFu;  // 0602BED8 extu.b r0,r10
    c.t = c.r[10] == c.r[11];  // 0602BEDA cmp/eq r11,r10
    { const bool k = !c.t; c.r[5] = 0x1u; if (k) { goto L_0602BEE4; } }  // 0602BEDC bf/s 0x0602BEE4 ; mov #1,r5
    goto L_0602C34A;  // 0602BEE0 bra 0x0602C34A ; nop
L_0602BEE4:
    { const uint32_t x = c.r[8]; c.pr = 0x0602BEE8u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602BEE8u) return; }  // 0602BEE4 jsr @r8 ; mov r9,r4
    c.r[1] = c.r[0];  // 0602BEE8 mov r0,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602BEEA extu.b r1,r1
    c.r[0] = 0x58u;  // 0602BEEC mov #88,r0
    st32(c.r[0] + c.r[14], c.r[1]);  // 0602BEEE mov.l r1,@(r0,r14)
    c.r[0] = 0x58u;  // 0602BEF0 mov #88,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 0602BEF2 mov.l @(r0,r14),r0
    c.t = c.r[0] == c.r[11];  // 0602BEF4 cmp/eq r11,r0
    { const bool k = c.t; c.r[13] = 0x58u; if (k) { goto L_0602BFDC; } }  // 0602BEF6 bt/s 0x0602BFDC ; mov #88,r13
    c.r[13] += c.r[14];  // 0602BEFA add r14,r13
    c.r[2] = ld32(c.r[13]);  // 0602BEFC mov.l @r13,r2
    c.r[1] = ld32(0x0602C014u);  // 0602BEFE mov.l 0x0602C014,r1
    c.r[1] = ld32(c.r[1]);  // 0602BF00 mov.l @r1,r1
    c.r[2] <<= 2;  // 0602BF02 shll2 r2
    c.r[2] <<= 2;  // 0602BF04 shll2 r2
    c.r[2] += c.r[1];  // 0602BF06 add r1,r2
    c.r[1] = c.r[2];  // 0602BF08 mov r2,r1
    c.r[1] += 8;  // 0602BF0A add #8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602BF0C mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602BF0E extu.b r1,r1
    st32(c.r[14] + 16, c.r[1]);  // 0602BF10 mov.l r1,@(16,r14)
    c.r[1] = c.r[2];  // 0602BF12 mov r2,r1
    c.r[1] += 9;  // 0602BF14 add #9,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602BF16 mov.b @r1,r1
    c.r[11] = c.r[1] & 0xFFu;  // 0602BF18 extu.b r1,r11
    c.r[1] = c.r[2];  // 0602BF1A mov r2,r1
    c.r[1] += 10;  // 0602BF1C add #10,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602BF1E mov.b @r1,r3
    c.r[1] = c.r[3] & 0xFFu;  // 0602BF20 extu.b r3,r1
    c.r[0] = c.r[1];  // 0602BF22 mov r1,r0
    c.r[0] >>= 2;  // 0602BF24 shlr2 r0
    c.r[0] >>= 2;  // 0602BF26 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0602BF28 shlr r0
    c.r[0] >>= 2;  // 0602BF2A shlr2 r0
    st32(c.r[14] + 20, c.r[0]);  // 0602BF2C mov.l r0,@(20,r14)
    c.r[7] = c.r[1];  // 0602BF2E mov r1,r7
    c.r[7] >>= 2;  // 0602BF30 shlr2 r7
    c.r[7] >>= 2;  // 0602BF32 shlr2 r7
    c.r[7] >>= 2;  // 0602BF34 shlr2 r7
    c.r[0] = c.r[7];  // 0602BF36 mov r7,r0
    c.r[0] &= 0x1u;  // 0602BF38 and #1,r0
    st32(c.r[14] + 24, c.r[0]);  // 0602BF3A mov.l r0,@(24,r14)
    c.r[7] = c.r[1];  // 0602BF3C mov r1,r7
    c.r[7] >>= 2;  // 0602BF3E shlr2 r7
    c.t = c.r[7] & 1; c.r[7] >>= 1;  // 0602BF40 shlr r7
    c.r[7] >>= 2;  // 0602BF42 shlr2 r7
    c.r[0] = c.r[7];  // 0602BF44 mov r7,r0
    c.r[0] &= 0x1u;  // 0602BF46 and #1,r0
    st32(c.r[14] + 28, c.r[0]);  // 0602BF48 mov.l r0,@(28,r14)
    c.r[7] = c.r[1];  // 0602BF4A mov r1,r7
    c.r[7] >>= 2;  // 0602BF4C shlr2 r7
    c.r[7] >>= 2;  // 0602BF4E shlr2 r7
    c.r[0] = c.r[7];  // 0602BF50 mov r7,r0
    c.r[0] &= 0x1u;  // 0602BF52 and #1,r0
    st32(c.r[14] + 32, c.r[0]);  // 0602BF54 mov.l r0,@(32,r14)
    c.r[7] = c.r[1];  // 0602BF56 mov r1,r7
    c.r[7] >>= 2;  // 0602BF58 shlr2 r7
    c.t = c.r[7] & 1; c.r[7] >>= 1;  // 0602BF5A shlr r7
    c.r[0] = c.r[7];  // 0602BF5C mov r7,r0
    c.r[0] &= 0x1u;  // 0602BF5E and #1,r0
    st32(c.r[14] + 36, c.r[0]);  // 0602BF60 mov.l r0,@(36,r14)
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0602BF62 shlr r1
    c.r[0] = c.r[1];  // 0602BF64 mov r1,r0
    c.r[0] &= 0x1u;  // 0602BF66 and #1,r0
    st32(c.r[14] + 40, c.r[0]);  // 0602BF68 mov.l r0,@(40,r14)
    c.r[0] = c.r[3];  // 0602BF6A mov r3,r0
    c.r[0] &= 0x1u;  // 0602BF6C and #1,r0
    st32(c.r[14] + 44, c.r[0]);  // 0602BF6E mov.l r0,@(44,r14)
    c.r[1] = c.r[2];  // 0602BF70 mov r2,r1
    c.r[1] += 11;  // 0602BF72 add #11,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602BF74 mov.b @r1,r1
    c.r[2] += 2;  // 0602BF76 add #2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0602BF78 extu.b r1,r1
    c.r[13] = c.r[1];  // 0602BF7A mov r1,r13
    c.r[13] >>= 2;  // 0602BF7C shlr2 r13
    c.r[13] >>= 2;  // 0602BF7E shlr2 r13
    c.t = c.r[13] & 1; c.r[13] >>= 1;  // 0602BF80 shlr r13
    c.r[13] >>= 2;  // 0602BF82 shlr2 r13
    st32(c.r[14] + 48, c.r[13]);  // 0602BF84 mov.l r13,@(48,r14)
    c.r[3] = c.r[1];  // 0602BF86 mov r1,r3
    c.r[3] >>= 2;  // 0602BF88 shlr2 r3
    c.r[3] >>= 2;  // 0602BF8A shlr2 r3
    c.r[3] >>= 2;  // 0602BF8C shlr2 r3
    c.r[0] = c.r[3];  // 0602BF8E mov r3,r0
    c.r[0] &= 0x1u;  // 0602BF90 and #1,r0
    st32(c.r[14] + 52, c.r[0]);  // 0602BF92 mov.l r0,@(52,r14)
    c.r[3] = c.r[1];  // 0602BF94 mov r1,r3
    c.r[3] >>= 2;  // 0602BF96 shlr2 r3
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 0602BF98 shlr r3
    c.r[3] >>= 2;  // 0602BF9A shlr2 r3
    c.r[0] = c.r[3];  // 0602BF9C mov r3,r0
    c.r[0] &= 0x1u;  // 0602BF9E and #1,r0
    st32(c.r[14] + 56, c.r[0]);  // 0602BFA0 mov.l r0,@(56,r14)
    c.r[3] = c.r[1];  // 0602BFA2 mov r1,r3
    c.r[3] >>= 2;  // 0602BFA4 shlr2 r3
    c.r[3] >>= 2;  // 0602BFA6 shlr2 r3
    c.r[0] = c.r[3];  // 0602BFA8 mov r3,r0
    c.r[0] &= 0x1u;  // 0602BFAA and #1,r0
    st32(c.r[14] + 60, c.r[0]);  // 0602BFAC mov.l r0,@(60,r14)
    c.r[1] >>= 2;  // 0602BFAE shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0602BFB0 shlr r1
    c.r[0] = c.r[1];  // 0602BFB2 mov r1,r0
    c.r[0] &= 0x1u;  // 0602BFB4 and #1,r0
    c.r[13] = 0x40u;  // 0602BFB6 mov #64,r13
    c.r[13] += c.r[14];  // 0602BFB8 add r14,r13
    st32(c.r[13], c.r[0]);  // 0602BFBA mov.l r0,@r13
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602BFBC mov.b @r2,r2
    c.r[1] = ld32(0x0602C018u);  // 0602BFBE mov.l 0x0602C018,r1
    c.r[3] = ld32(c.r[1]);  // 0602BFC0 mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0602BFC2 extu.b r2,r2
    c.r[1] = 0x1Eu;  // 0602BFC4 mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 0602BFC6 mul.l r1,r2
    c.r[13] = 0x58u;  // 0602BFC8 mov #88,r13
    c.r[13] += c.r[14];  // 0602BFCA add r14,r13
    c.r[1] = c.macl;  // 0602BFCC sts macl,r1
    c.r[1] += c.r[3];  // 0602BFCE add r3,r1
    c.r[1] += 15;  // 0602BFD0 add #15,r1
    c.r[0] = 0xFFFFFFFFu;  // 0602BFD2 mov #-1,r0
    st8(c.r[1], c.r[0]);  // 0602BFD4 mov.b r0,@r1
    c.r[1] = ld32(0x0602C01Cu);  // 0602BFD6 mov.l 0x0602C01C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602BFDCu; c.r[4] = ld32(c.r[13]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602BFDCu) return; }  // 0602BFD8 jsr @r1 ; mov.l @r13,r4
L_0602BFDC:
    c.r[1] = ld32(0x0602C014u);  // 0602BFDC mov.l 0x0602C014,r1
    c.r[2] = c.r[10];  // 0602BFDE mov r10,r2
    c.r[2] <<= 2;  // 0602BFE0 shll2 r2
    c.r[2] <<= 2;  // 0602BFE2 shll2 r2
    c.r[1] = ld32(c.r[1]);  // 0602BFE4 mov.l @r1,r1
    c.r[5] = 0x0u;  // 0602BFE6 mov #0,r5
    c.r[2] += c.r[1];  // 0602BFE8 add r1,r2
    c.r[2] += 2;  // 0602BFEA add #2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602BFEC mov.b @r2,r1
    c.r[6] = 0x7Fu;  // 0602BFEE mov #127,r6
    c.r[8] = c.r[1] & 0xFFu;  // 0602BFF0 extu.b r1,r8
    c.r[1] = ld32(0x0602C018u);  // 0602BFF2 mov.l 0x0602C018,r1
    c.r[7] = ld32(c.r[1]);  // 0602BFF4 mov.l @r1,r7
    c.r[2] = 0x0u;  // 0602BFF6 mov #0,r2
    c.r[3] = c.r[7];  // 0602BFF8 mov r7,r3
L_0602BFFA:
    c.r[0] = c.r[2]; goto L_0602C020;  // 0602BFFA bra 0x0602C020 ; mov r2,r0
L_0602C020:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[7]);  // 0602C020 mov.w @(r0,r7),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0602C022 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0602C024 tst r1,r1
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_0602C034; } }  // 0602C026 bt/s 0x0602C034 ; mov r3,r1
    c.r[1] += 15;  // 0602C02A add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602C02C mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602C02E extu.b r1,r1
    c.t = c.r[1] == c.r[9];  // 0602C030 cmp/eq r9,r1
    if (c.t) { goto L_0602C03E; }  // 0602C032 bt 0x0602C03E
L_0602C034:
    c.r[3] += 30;  // 0602C034 add #30,r3
    c.r[5] += 1;  // 0602C036 add #1,r5
    c.t = (int32_t)c.r[5] > (int32_t)c.r[6];  // 0602C038 cmp/gt r6,r5
    { const bool k = !c.t; c.r[2] += 30; if (k) { SH2_POLL(c); goto L_0602BFFA; } }  // 0602C03A bf/s 0x0602BFFA ; add #30,r2
L_0602C03E:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602C1C0u);  // 0602C03E mov.w 0x0602C1C0,r1
    c.t = c.r[5] == c.r[1];  // 0602C040 cmp/eq r1,r5
    if (c.t) { goto L_0602C048; }  // 0602C042 bt 0x0602C048
    goto L_0602C34A;  // 0602C044 bra 0x0602C34A ; nop
L_0602C048:
    c.r[1] = ld32(0x0602C1C4u);  // 0602C048 mov.l 0x0602C1C4,r1
    c.r[2] = ld32(c.r[1]);  // 0602C04A mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 0602C04C mov #30,r1
    c.macl = c.r[8] * c.r[1];  // 0602C04E mul.l r1,r8
    c.r[3] = c.macl;  // 0602C050 sts macl,r3
    c.r[3] += c.r[2];  // 0602C052 add r2,r3
    c.r[3] += 15;  // 0602C054 add #15,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0602C056 mov.b @r3,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602C058 extu.b r1,r1
    c.t = c.r[1] == c.r[12];  // 0602C05A cmp/eq r12,r1
    if (c.t) { goto L_0602C062; }  // 0602C05C bt 0x0602C062
    goto L_0602C34A;  // 0602C05E bra 0x0602C34A ; nop
L_0602C062:
    st8(c.r[3], c.r[9]);  // 0602C062 mov.b r9,@r3
    c.r[5] = 0x0u;  // 0602C064 mov #0,r5
    c.r[7] = 0xFu;  // 0602C066 mov #15,r7
    c.r[3] = ld32(0x0602C1C8u);  // 0602C068 mov.l 0x0602C1C8,r3
    c.r[2] = c.r[10];  // 0602C06A mov r10,r2
    c.r[2] <<= 2;  // 0602C06C shll2 r2
    c.r[2] <<= 2;  // 0602C06E shll2 r2
L_0602C070:
    c.r[1] = ld32(c.r[3]);  // 0602C070 mov.l @r3,r1
    c.r[1] += c.r[2];  // 0602C072 add r2,r1
    c.r[1] += 40;  // 0602C074 add #40,r1
    c.r[0] = c.r[1];  // 0602C076 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 0602C078 mov.b @(r0,r5),r1
    c.r[0] = c.r[14];  // 0602C07A mov r14,r0
    st8(c.r[0] + c.r[5], c.r[1]);  // 0602C07C mov.b r1,@(r0,r5)
    c.r[5] += 1;  // 0602C07E add #1,r5
    c.t = (int32_t)c.r[5] > (int32_t)c.r[7];  // 0602C080 cmp/gt r7,r5
    { const bool k = !c.t; c.r[13] = 0x4Cu; if (k) { SH2_POLL(c); goto L_0602C070; } }  // 0602C082 bf/s 0x0602C070 ; mov #76,r13
    c.r[1] = ld32(0x0602C1C4u);  // 0602C086 mov.l 0x0602C1C4,r1
    c.r[2] = ld32(c.r[1]);  // 0602C088 mov.l @r1,r2
    c.r[13] += c.r[14];  // 0602C08A add r14,r13
    c.r[1] = 0x1Eu;  // 0602C08C mov #30,r1
    c.macl = c.r[8] * c.r[1];  // 0602C08E mul.l r1,r8
    c.r[0] = 0x50u;  // 0602C090 mov #80,r0
    c.r[0] += c.r[14];  // 0602C092 add r14,r0
    c.r[3] = c.macl;  // 0602C094 sts macl,r3
    c.r[3] += c.r[2];  // 0602C096 add r2,r3
    c.r[1] = c.r[3];  // 0602C098 mov r3,r1
    c.r[1] += 22;  // 0602C09A add #22,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0602C09C mov.w @r1,r1
    c.r[3] += 24;  // 0602C09E add #24,r3
    c.r[1] = c.r[1] & 0xFFFFu;  // 0602C0A0 extu.w r1,r1
    st32(c.r[13], c.r[1]);  // 0602C0A2 mov.l r1,@r13
    c.r[13] = 0x54u;  // 0602C0A4 mov #84,r13
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0602C0A6 mov.w @r3,r1
    c.r[13] += c.r[14];  // 0602C0A8 add r14,r13
    c.r[1] = c.r[1] & 0xFFFFu;  // 0602C0AA extu.w r1,r1
    st32(c.r[0], c.r[1]);  // 0602C0AC mov.l r1,@r0
    c.r[1] = ld32(c.r[13]);  // 0602C0AE mov.l @r13,r1
    c.r[1] >>= 8;  // 0602C0B0 shlr8 r1
    c.r[1] += c.r[1];  // 0602C0B2 add r1,r1
    c.r[1] >>= 8;  // 0602C0B4 shlr8 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0602C0B6 tst r1,r1
    { const bool k = !c.t; c.r[2] = c.r[12]; if (k) { goto L_0602C0F8; } }  // 0602C0B8 bf/s 0x0602C0F8 ; mov r12,r2
    c.r[1] = ld32(0x0602C1CCu);  // 0602C0BC mov.l 0x0602C1CC,r1
    c.r[2] += c.r[2];  // 0602C0BE add r2,r2
    c.r[2] += c.r[12];  // 0602C0C0 add r12,r2
    c.r[2] <<= 2;  // 0602C0C2 shll2 r2
    c.r[0] = 0x44u;  // 0602C0C4 mov #68,r0
    c.r[3] = ld32(c.r[1]);  // 0602C0C6 mov.l @r1,r3
    c.r[0] += c.r[14];  // 0602C0C8 add r14,r0
    c.r[2] += c.r[3];  // 0602C0CA add r3,r2
    c.r[1] = c.r[2];  // 0602C0CC mov r2,r1
    c.r[1] += 10;  // 0602C0CE add #10,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0602C0D0 mov.w @r1,r1
    c.r[2] += 8;  // 0602C0D2 add #8,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 0602C0D4 extu.w r1,r1
    st32(c.r[0], c.r[1]);  // 0602C0D6 mov.l r1,@r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602C0D8 mov.b @r2,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0602C0DA extu.b r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602C1C2u);  // 0602C0DC mov.w 0x0602C1C2,r1
    c.t = c.r[2] == c.r[1];  // 0602C0DE cmp/eq r1,r2
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_0602C0F8; } }  // 0602C0E0 bt/s 0x0602C0F8 ; mov r2,r1
    c.r[1] += c.r[1];  // 0602C0E4 add r1,r1
    c.r[1] += c.r[2];  // 0602C0E6 add r2,r1
    c.r[1] <<= 2;  // 0602C0E8 shll2 r1
    c.r[1] += c.r[3];  // 0602C0EA add r3,r1
    c.r[1] += 10;  // 0602C0EC add #10,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0602C0EE mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0602C0F0 extu.w r1,r1
    c.r[13] = 0x48u;  // 0602C0F2 mov #72,r13
    c.r[13] += c.r[14];  // 0602C0F4 add r14,r13
    st32(c.r[13], c.r[1]);  // 0602C0F6 mov.l r1,@r13
L_0602C0F8:
    c.r[12] = ld32(0x0602C1D0u);  // 0602C0F8 mov.l 0x0602C1D0,r12
    c.r[1] = ld32(0x0602C1D4u);  // 0602C0FA mov.l 0x0602C1D4,r1
    c.r[4] = ld32(c.r[12]);  // 0602C0FC mov.l @r12,r4
    { const uint32_t x = c.r[1]; c.pr = 0x0602C102u; c.r[5] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602C102u) return; }  // 0602C0FE jsr @r1 ; mov r9,r5
    c.r[1] = ld32(0x0602C1D8u);  // 0602C102 mov.l 0x0602C1D8,r1
    c.r[6] = c.r[10];  // 0602C104 mov r10,r6
    c.r[4] = ld32(c.r[1]);  // 0602C106 mov.l @r1,r4
    c.r[1] = ld32(0x0602C1DCu);  // 0602C108 mov.l 0x0602C1DC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602C10Eu; c.r[5] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602C10Eu) return; }  // 0602C10A jsr @r1 ; mov r8,r5
    c.r[1] = ld32(0x0602C1E0u);  // 0602C10E mov.l 0x0602C1E0,r1
    c.r[6] = c.r[9];  // 0602C110 mov r9,r6
    c.r[5] = c.r[8];  // 0602C112 mov r8,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0602C118u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602C118u) return; }  // 0602C114 jsr @r1 ; mov r10,r4
    c.r[0] = 0x54u;  // 0602C118 mov #84,r0
    c.r[0] += c.r[14];  // 0602C11A add r14,r0
    c.r[13] = ld32(c.r[0]);  // 0602C11C mov.l @r0,r13
    c.r[13] >>= 8;  // 0602C11E shlr8 r13
    c.r[13] += c.r[13];  // 0602C120 add r13,r13
    c.r[13] >>= 8;  // 0602C122 shlr8 r13
    st32(c.r[0], c.r[13]);  // 0602C124 mov.l r13,@r0
    c.r[0] = 0x54u;  // 0602C126 mov #84,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 0602C128 mov.l @(r0,r14),r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0602C12A tst r0,r0
    { const bool k = !c.t; c.r[6] = c.r[9]; if (k) { goto L_0602C17E; } }  // 0602C12C bf/s 0x0602C17E ; mov r9,r6
    c.r[5] = ld32(0x0602C1CCu);  // 0602C130 mov.l 0x0602C1CC,r5
    c.r[6] += c.r[6];  // 0602C132 add r6,r6
    c.r[6] += c.r[9];  // 0602C134 add r9,r6
    c.r[6] <<= 2;  // 0602C136 shll2 r6
    c.r[13] = 0x46u;  // 0602C138 mov #70,r13
    c.r[7] = ld32(c.r[5]);  // 0602C13A mov.l @r5,r7
    c.r[13] += c.r[14];  // 0602C13C add r14,r13
    c.r[7] += c.r[6];  // 0602C13E add r6,r7
    c.r[7] += 10;  // 0602C140 add #10,r7
    c.r[13] = (uint32_t)(int16_t)ld16(c.r[13]);  // 0602C142 mov.w @r13,r13
    st16(c.r[7], c.r[13]);  // 0602C144 mov.w r13,@r7
    c.r[1] = ld32(c.r[12]);  // 0602C146 mov.l @r12,r1
    c.r[0] = 0x44u;  // 0602C148 mov #68,r0
    c.r[1] += 12;  // 0602C14A add #12,r1
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0602C14C mov.w @r1,r3
    c.r[2] = ld32(c.r[0] + c.r[14]);  // 0602C14E mov.l @(r0,r14),r2
    c.r[1] = c.r[3] & 0xFFFFu;  // 0602C150 extu.w r3,r1
    c.t = c.r[2] > c.r[1];  // 0602C152 cmp/hi r1,r2
    if (!c.t) { goto L_0602C158; }  // 0602C154 bf 0x0602C158
    st16(c.r[7], c.r[3]);  // 0602C156 mov.w r3,@r7
L_0602C158:
    c.r[3] = ld32(c.r[5]);  // 0602C158 mov.l @r5,r3
    c.r[6] += c.r[3];  // 0602C15A add r3,r6
    c.r[6] += 8;  // 0602C15C add #8,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0602C15E mov.b @r6,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0602C160 extu.b r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602C1C2u);  // 0602C162 mov.w 0x0602C1C2,r1
    c.t = c.r[2] == c.r[1];  // 0602C164 cmp/eq r1,r2
    { const bool k = c.t; c.r[5] = 0x0u; if (k) { goto L_0602C180; } }  // 0602C166 bt/s 0x0602C180 ; mov #0,r5
    c.r[1] = c.r[2];  // 0602C16A mov r2,r1
    c.r[1] += c.r[1];  // 0602C16C add r1,r1
    c.r[1] += c.r[2];  // 0602C16E add r2,r1
    c.r[1] <<= 2;  // 0602C170 shll2 r1
    c.r[1] += c.r[3];  // 0602C172 add r3,r1
    c.r[1] += 10;  // 0602C174 add #10,r1
    c.r[13] = 0x4Au;  // 0602C176 mov #74,r13
    c.r[13] += c.r[14];  // 0602C178 add r14,r13
    c.r[13] = (uint32_t)(int16_t)ld16(c.r[13]);  // 0602C17A mov.w @r13,r13
    st16(c.r[1], c.r[13]);  // 0602C17C mov.w r13,@r1
L_0602C17E:
    c.r[5] = 0x0u;  // 0602C17E mov #0,r5
L_0602C180:
    c.r[6] = 0xFu;  // 0602C180 mov #15,r6
    c.r[7] = ld32(0x0602C1C8u);  // 0602C182 mov.l 0x0602C1C8,r7
    c.r[3] = c.r[10];  // 0602C184 mov r10,r3
    c.r[3] <<= 2;  // 0602C186 shll2 r3
    c.r[3] <<= 2;  // 0602C188 shll2 r3
L_0602C18A:
    c.r[2] = ld32(c.r[7]);  // 0602C18A mov.l @r7,r2
    c.r[0] = c.r[14];  // 0602C18C mov r14,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 0602C18E mov.b @(r0,r5),r1
    c.r[2] += c.r[3];  // 0602C190 add r3,r2
    c.r[2] += 40;  // 0602C192 add #40,r2
    c.r[0] = c.r[2];  // 0602C194 mov r2,r0
    st8(c.r[0] + c.r[5], c.r[1]);  // 0602C196 mov.b r1,@(r0,r5)
    c.r[5] += 1;  // 0602C198 add #1,r5
    c.t = (int32_t)c.r[5] > (int32_t)c.r[6];  // 0602C19A cmp/gt r6,r5
    { const bool k = !c.t; c.r[13] = 0x4Eu; if (k) { SH2_POLL(c); goto L_0602C18A; } }  // 0602C19C bf/s 0x0602C18A ; mov #78,r13
    c.r[1] = ld32(0x0602C1C4u);  // 0602C1A0 mov.l 0x0602C1C4,r1
    c.r[3] = ld32(c.r[1]);  // 0602C1A2 mov.l @r1,r3
    c.r[13] += c.r[14];  // 0602C1A4 add r14,r13
    c.r[1] = 0x1Eu;  // 0602C1A6 mov #30,r1
    c.macl = c.r[8] * c.r[1];  // 0602C1A8 mul.l r1,r8
    c.r[0] = 0x52u;  // 0602C1AA mov #82,r0
    c.r[0] += c.r[14];  // 0602C1AC add r14,r0
    c.r[2] = c.macl;  // 0602C1AE sts macl,r2
    c.r[2] += c.r[3];  // 0602C1B0 add r3,r2
    c.r[1] = c.r[2];  // 0602C1B2 mov r2,r1
    c.r[1] += 22;  // 0602C1B4 add #22,r1
    c.r[13] = (uint32_t)(int16_t)ld16(c.r[13]);  // 0602C1B6 mov.w @r13,r13
    c.r[2] += 24;  // 0602C1B8 add #24,r2
    st16(c.r[1], c.r[13]);  // 0602C1BA mov.w r13,@r1
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[0]); goto L_0602C1E4;  // 0602C1BC bra 0x0602C1E4 ; mov.w @r0,r0
L_0602C1E4:
    st16(c.r[2], c.r[0]);  // 0602C1E4 mov.w r0,@r2
    c.r[0] = 0x58u;  // 0602C1E6 mov #88,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 0602C1E8 mov.l @(r0,r14),r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602C362u);  // 0602C1EA mov.w 0x0602C362,r1
    c.t = c.r[0] == c.r[1];  // 0602C1EC cmp/eq r1,r0
    { const bool k = !c.t; c.r[2] = c.r[10]; if (k) { goto L_0602C1F6; } }  // 0602C1EE bf/s 0x0602C1F6 ; mov r10,r2
    goto L_0602C344;  // 0602C1F2 bra 0x0602C344 ; nop
L_0602C1F6:
    c.r[3] = ld32(0x0602C374u);  // 0602C1F6 mov.l 0x0602C374,r3
    c.r[2] <<= 2;  // 0602C1F8 shll2 r2
    c.r[2] <<= 2;  // 0602C1FA shll2 r2
    c.r[13] = 0x13u;  // 0602C1FC mov #19,r13
    c.r[1] = ld32(c.r[3]);  // 0602C1FE mov.l @r3,r1
    c.r[13] += c.r[14];  // 0602C200 add r14,r13
    c.r[1] += c.r[2];  // 0602C202 add r2,r1
    c.r[1] += 8;  // 0602C204 add #8,r1
    c.r[13] = (uint32_t)(int8_t)ld8(c.r[13]);  // 0602C206 mov.b @r13,r13
    st8(c.r[1], c.r[13]);  // 0602C208 mov.b r13,@r1
    c.r[1] = ld32(c.r[3]);  // 0602C20A mov.l @r3,r1
    c.r[1] += c.r[2];  // 0602C20C add r2,r1
    c.r[1] += 9;  // 0602C20E add #9,r1
    st8(c.r[1], c.r[11]);  // 0602C210 mov.b r11,@r1
    c.r[1] = ld32(c.r[3]);  // 0602C212 mov.l @r3,r1
    c.r[0] = ld32(c.r[14] + 20);  // 0602C214 mov.l @(20,r14),r0
    c.r[1] += c.r[2];  // 0602C216 add r2,r1
    c.r[1] += 10;  // 0602C218 add #10,r1
    c.r[0] <<= 2;  // 0602C21A shll2 r0
    c.r[0] <<= 2;  // 0602C21C shll2 r0
    c.r[0] += c.r[0];  // 0602C21E add r0,r0
    c.r[0] <<= 2;  // 0602C220 shll2 r0
    st32(c.r[14] + 20, c.r[0]);  // 0602C222 mov.l r0,@(20,r14)
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602C224 mov.b @r1,r7
    c.r[13] = 0x7Fu;  // 0602C226 mov #127,r13
    c.r[7] &= c.r[13];  // 0602C228 and r13,r7
    c.r[7] |= c.r[0];  // 0602C22A or r0,r7
    st8(c.r[1], c.r[7]);  // 0602C22C mov.b r7,@r1
    c.r[1] = ld32(c.r[3]);  // 0602C22E mov.l @r3,r1
    c.r[0] = ld32(c.r[14] + 24);  // 0602C230 mov.l @(24,r14),r0
    c.r[1] += c.r[2];  // 0602C232 add r2,r1
    c.r[1] += 10;  // 0602C234 add #10,r1
    c.r[0] <<= 2;  // 0602C236 shll2 r0
    c.r[0] <<= 2;  // 0602C238 shll2 r0
    c.r[0] <<= 2;  // 0602C23A shll2 r0
    st32(c.r[14] + 24, c.r[0]);  // 0602C23C mov.l r0,@(24,r14)
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602C23E mov.b @r1,r7
    c.r[13] = (uint32_t)(int16_t)ld16(0x0602C364u);  // 0602C240 mov.w 0x0602C364,r13
    c.r[7] &= c.r[13];  // 0602C242 and r13,r7
    c.r[7] |= c.r[0];  // 0602C244 or r0,r7
    st8(c.r[1], c.r[7]);  // 0602C246 mov.b r7,@r1
    c.r[1] = ld32(c.r[3]);  // 0602C248 mov.l @r3,r1
    c.r[0] = ld32(c.r[14] + 28);  // 0602C24A mov.l @(28,r14),r0
    c.r[1] += c.r[2];  // 0602C24C add r2,r1
    c.r[1] += 10;  // 0602C24E add #10,r1
    c.r[0] <<= 2;  // 0602C250 shll2 r0
    c.r[0] += c.r[0];  // 0602C252 add r0,r0
    c.r[0] <<= 2;  // 0602C254 shll2 r0
    st32(c.r[14] + 28, c.r[0]);  // 0602C256 mov.l r0,@(28,r14)
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602C258 mov.b @r1,r7
    c.r[13] = (uint32_t)(int16_t)ld16(0x0602C366u);  // 0602C25A mov.w 0x0602C366,r13
    c.r[7] &= c.r[13];  // 0602C25C and r13,r7
    c.r[7] |= c.r[0];  // 0602C25E or r0,r7
    st8(c.r[1], c.r[7]);  // 0602C260 mov.b r7,@r1
    c.r[1] = ld32(c.r[3]);  // 0602C262 mov.l @r3,r1
    c.r[0] = ld32(c.r[14] + 32);  // 0602C264 mov.l @(32,r14),r0
    c.r[1] += c.r[2];  // 0602C266 add r2,r1
    c.r[1] += 10;  // 0602C268 add #10,r1
    c.r[0] <<= 2;  // 0602C26A shll2 r0
    c.r[0] <<= 2;  // 0602C26C shll2 r0
    st32(c.r[14] + 32, c.r[0]);  // 0602C26E mov.l r0,@(32,r14)
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602C270 mov.b @r1,r7
    c.r[13] = (uint32_t)(int16_t)ld16(0x0602C368u);  // 0602C272 mov.w 0x0602C368,r13
    c.r[7] &= c.r[13];  // 0602C274 and r13,r7
    c.r[7] |= c.r[0];  // 0602C276 or r0,r7
    st8(c.r[1], c.r[7]);  // 0602C278 mov.b r7,@r1
    c.r[1] = ld32(c.r[3]);  // 0602C27A mov.l @r3,r1
    c.r[0] = ld32(c.r[14] + 36);  // 0602C27C mov.l @(36,r14),r0
    c.r[1] += c.r[2];  // 0602C27E add r2,r1
    c.r[1] += 10;  // 0602C280 add #10,r1
    c.r[0] <<= 2;  // 0602C282 shll2 r0
    c.r[0] += c.r[0];  // 0602C284 add r0,r0
    st32(c.r[14] + 36, c.r[0]);  // 0602C286 mov.l r0,@(36,r14)
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602C288 mov.b @r1,r7
    c.r[13] = (uint32_t)(int16_t)ld16(0x0602C36Au);  // 0602C28A mov.w 0x0602C36A,r13
    c.r[7] &= c.r[13];  // 0602C28C and r13,r7
    c.r[7] |= c.r[0];  // 0602C28E or r0,r7
    st8(c.r[1], c.r[7]);  // 0602C290 mov.b r7,@r1
    c.r[1] = ld32(c.r[3]);  // 0602C292 mov.l @r3,r1
    c.r[0] = ld32(c.r[14] + 40);  // 0602C294 mov.l @(40,r14),r0
    c.r[1] += c.r[2];  // 0602C296 add r2,r1
    c.r[1] += 10;  // 0602C298 add #10,r1
    c.r[0] += c.r[0];  // 0602C29A add r0,r0
    st32(c.r[14] + 40, c.r[0]);  // 0602C29C mov.l r0,@(40,r14)
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602C29E mov.b @r1,r7
    c.r[13] = (uint32_t)(int16_t)ld16(0x0602C36Cu);  // 0602C2A0 mov.w 0x0602C36C,r13
    c.r[7] &= c.r[13];  // 0602C2A2 and r13,r7
    c.r[7] |= c.r[0];  // 0602C2A4 or r0,r7
    st8(c.r[1], c.r[7]);  // 0602C2A6 mov.b r7,@r1
    c.r[1] = ld32(c.r[3]);  // 0602C2A8 mov.l @r3,r1
    c.r[1] += c.r[2];  // 0602C2AA add r2,r1
    c.r[1] += 10;  // 0602C2AC add #10,r1
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602C2AE mov.b @r1,r7
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602C36Eu);  // 0602C2B0 mov.w 0x0602C36E,r0
    c.r[13] = ld32(c.r[14] + 44);  // 0602C2B2 mov.l @(44,r14),r13
    c.r[7] &= c.r[0];  // 0602C2B4 and r0,r7
    c.r[7] |= c.r[13];  // 0602C2B6 or r13,r7
    st8(c.r[1], c.r[7]);  // 0602C2B8 mov.b r7,@r1
    c.r[1] = ld32(c.r[3]);  // 0602C2BA mov.l @r3,r1
    c.r[0] = ld32(c.r[14] + 48);  // 0602C2BC mov.l @(48,r14),r0
    c.r[1] += c.r[2];  // 0602C2BE add r2,r1
    c.r[1] += 11;  // 0602C2C0 add #11,r1
    c.r[0] <<= 2;  // 0602C2C2 shll2 r0
    c.r[0] <<= 2;  // 0602C2C4 shll2 r0
    c.r[0] += c.r[0];  // 0602C2C6 add r0,r0
    c.r[0] <<= 2;  // 0602C2C8 shll2 r0
    st32(c.r[14] + 48, c.r[0]);  // 0602C2CA mov.l r0,@(48,r14)
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602C2CC mov.b @r1,r7
    c.r[13] = 0x7Fu;  // 0602C2CE mov #127,r13
    c.r[7] &= c.r[13];  // 0602C2D0 and r13,r7
    c.r[7] |= c.r[0];  // 0602C2D2 or r0,r7
    st8(c.r[1], c.r[7]);  // 0602C2D4 mov.b r7,@r1
    c.r[1] = ld32(c.r[3]);  // 0602C2D6 mov.l @r3,r1
    c.r[0] = ld32(c.r[14] + 52);  // 0602C2D8 mov.l @(52,r14),r0
    c.r[1] += c.r[2];  // 0602C2DA add r2,r1
    c.r[1] += 11;  // 0602C2DC add #11,r1
    c.r[0] <<= 2;  // 0602C2DE shll2 r0
    c.r[0] <<= 2;  // 0602C2E0 shll2 r0
    c.r[0] <<= 2;  // 0602C2E2 shll2 r0
    st32(c.r[14] + 52, c.r[0]);  // 0602C2E4 mov.l r0,@(52,r14)
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602C2E6 mov.b @r1,r7
    c.r[13] = (uint32_t)(int16_t)ld16(0x0602C364u);  // 0602C2E8 mov.w 0x0602C364,r13
    c.r[7] &= c.r[13];  // 0602C2EA and r13,r7
    c.r[7] |= c.r[0];  // 0602C2EC or r0,r7
    st8(c.r[1], c.r[7]);  // 0602C2EE mov.b r7,@r1
    c.r[1] = ld32(c.r[3]);  // 0602C2F0 mov.l @r3,r1
    c.r[0] = ld32(c.r[14] + 56);  // 0602C2F2 mov.l @(56,r14),r0
    c.r[1] += c.r[2];  // 0602C2F4 add r2,r1
    c.r[1] += 11;  // 0602C2F6 add #11,r1
    c.r[0] <<= 2;  // 0602C2F8 shll2 r0
    c.r[0] += c.r[0];  // 0602C2FA add r0,r0
    c.r[0] <<= 2;  // 0602C2FC shll2 r0
    st32(c.r[14] + 56, c.r[0]);  // 0602C2FE mov.l r0,@(56,r14)
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602C300 mov.b @r1,r7
    c.r[13] = (uint32_t)(int16_t)ld16(0x0602C366u);  // 0602C302 mov.w 0x0602C366,r13
    c.r[7] &= c.r[13];  // 0602C304 and r13,r7
    c.r[7] |= c.r[0];  // 0602C306 or r0,r7
    st8(c.r[1], c.r[7]);  // 0602C308 mov.b r7,@r1
    c.r[1] = ld32(c.r[3]);  // 0602C30A mov.l @r3,r1
    c.r[0] = ld32(c.r[14] + 60);  // 0602C30C mov.l @(60,r14),r0
    c.r[1] += c.r[2];  // 0602C30E add r2,r1
    c.r[1] += 11;  // 0602C310 add #11,r1
    c.r[0] <<= 2;  // 0602C312 shll2 r0
    c.r[0] <<= 2;  // 0602C314 shll2 r0
    st32(c.r[14] + 60, c.r[0]);  // 0602C316 mov.l r0,@(60,r14)
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602C318 mov.b @r1,r7
    c.r[13] = (uint32_t)(int16_t)ld16(0x0602C368u);  // 0602C31A mov.w 0x0602C368,r13
    c.r[7] &= c.r[13];  // 0602C31C and r13,r7
    c.r[7] |= c.r[0];  // 0602C31E or r0,r7
    st8(c.r[1], c.r[7]);  // 0602C320 mov.b r7,@r1
    c.r[0] = 0x40u;  // 0602C322 mov #64,r0
    c.r[1] = ld32(c.r[3]);  // 0602C324 mov.l @r3,r1
    c.r[0] += c.r[14];  // 0602C326 add r14,r0
    c.r[13] = ld32(c.r[0]);  // 0602C328 mov.l @r0,r13
    c.r[1] += c.r[2];  // 0602C32A add r2,r1
    c.r[1] += 11;  // 0602C32C add #11,r1
    c.r[13] <<= 2;  // 0602C32E shll2 r13
    c.r[13] += c.r[13];  // 0602C330 add r13,r13
    st32(c.r[0], c.r[13]);  // 0602C332 mov.l r13,@r0
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602C36Au);  // 0602C334 mov.w 0x0602C36A,r0
    c.r[13] = 0x40u;  // 0602C336 mov #64,r13
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602C338 mov.b @r1,r2
    c.r[13] += c.r[14];  // 0602C33A add r14,r13
    c.r[13] = ld32(c.r[13]);  // 0602C33C mov.l @r13,r13
    c.r[2] &= c.r[0];  // 0602C33E and r0,r2
    c.r[2] |= c.r[13];  // 0602C340 or r13,r2
    st8(c.r[1], c.r[2]);  // 0602C342 mov.b r2,@r1
L_0602C344:
    c.r[1] = ld32(0x0602C378u);  // 0602C344 mov.l 0x0602C378,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602C34Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602C34Au) return; }  // 0602C346 jsr @r1 ; nop
L_0602C34A:
    c.r[14] += 92;  // 0602C34A add #92,r14
    c.r[15] = c.r[14];  // 0602C34C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602C34E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602C350 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0602C352 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0602C354 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0602C356 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0602C358 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0602C35A mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602C370u);  // 0602C35C mov.w 0x0602C370,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602C35E rts ; mov.l @r15+,r8
}

void f_0602C37C(SH2Context& c) {
    ran[619] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602C37C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602C37E sts.l pr,@-r15
    c.r[1] = ld32(0x0602C3ECu);  // 0602C380 mov.l 0x0602C3EC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602C386u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602C386u) return; }  // 0602C382 jsr @r1 ; mov r15,r14
    c.r[1] = ld32(0x0602C3F0u);  // 0602C386 mov.l 0x0602C3F0,r1
    c.r[2] = ld32(c.r[1]);  // 0602C388 mov.l @r1,r2
    c.r[0] = ld32(0x0602C3F4u);  // 0602C38A mov.l 0x0602C3F4,r0
    c.r[1] = c.r[2];  // 0602C38C mov r2,r1
    c.r[1] += 1;  // 0602C38E add #1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602C390 mov.b @r1,r4
    c.r[2] += 2;  // 0602C392 add #2,r2
    c.r[4] = c.r[4] & 0xFFu;  // 0602C394 extu.b r4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602C396 mov.b @r2,r1
    c.r[4] <<= 8;  // 0602C398 shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 0602C39A extu.b r1,r1
    { const uint32_t x = c.r[0]; c.pr = 0x0602C3A0u; c.r[4] |= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602C3A0u) return; }  // 0602C39C jsr @r0 ; or r1,r4
    c.r[6] = c.r[0] & 0xFFu;  // 0602C3A0 extu.b r0,r6
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602C3E6u);  // 0602C3A2 mov.w 0x0602C3E6,r1
    c.t = c.r[6] == c.r[1];  // 0602C3A4 cmp/eq r1,r6
    { const bool k = c.t; c.r[7] = 0x0u; if (k) { goto L_0602C3DC; } }  // 0602C3A6 bt/s 0x0602C3DC ; mov #0,r7
    c.r[2] = 0x0u;  // 0602C3AA mov #0,r2
L_0602C3AC:
    c.r[1] = ld32(0x0602C3F8u);  // 0602C3AC mov.l 0x0602C3F8,r1
    c.r[0] = ld32(c.r[1]);  // 0602C3AE mov.l @r1,r0
    c.r[3] = c.r[2];  // 0602C3B0 mov r2,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 0602C3B2 mov.w @(r0,r2),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0602C3B4 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0602C3B6 tst r1,r1
    { const bool k = c.t; c.r[3] += c.r[0]; if (k) { goto L_0602C3D2; } }  // 0602C3B8 bt/s 0x0602C3D2 ; add r0,r3
    c.r[3] += 15;  // 0602C3BC add #15,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0602C3BE mov.b @r3,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602C3C0 extu.b r1,r1
    c.t = c.r[1] == c.r[6];  // 0602C3C2 cmp/eq r6,r1
    { const bool k = !c.t; c.r[7] += 1; if (k) { goto L_0602C3D4; } }  // 0602C3C4 bf/s 0x0602C3D4 ; add #1,r7
    c.r[1] = ld32(0x0602C3FCu);  // 0602C3C8 mov.l 0x0602C3FC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602C3CEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602C3CEu) return; }  // 0602C3CA jsr @r1 ; nop
    c.r[15] = c.r[14]; goto L_0602C3DE;  // 0602C3CE bra 0x0602C3DE ; mov r14,r15
L_0602C3D2:
    c.r[7] += 1;  // 0602C3D2 add #1,r7
L_0602C3D4:
    c.r[1] = 0x7Fu;  // 0602C3D4 mov #127,r1
    c.t = (int32_t)c.r[7] > (int32_t)c.r[1];  // 0602C3D6 cmp/gt r1,r7
    { const bool k = !c.t; c.r[2] += 30; if (k) { SH2_POLL(c); goto L_0602C3AC; } }  // 0602C3D8 bf/s 0x0602C3AC ; add #30,r2
L_0602C3DC:
    c.r[15] = c.r[14];  // 0602C3DC mov r14,r15
L_0602C3DE:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602C3DE lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602C3E8u);  // 0602C3E0 mov.w 0x0602C3E8,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602C3E2 rts ; mov.l @r15+,r14
}

void f_0602C400(SH2Context& c) {
    ran[620] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602C400 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602C402 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602C404 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602C406 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0602C408 mov r15,r14
    c.r[9] = (uint32_t)(int16_t)ld16(0x0602C440u);  // 0602C40A mov.w 0x0602C440,r9
    c.r[4] = ld32(0x0602C444u);  // 0602C40C mov.l 0x0602C444,r4
    c.r[8] = ld32(0x0602C448u);  // 0602C40E mov.l 0x0602C448,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0602C414u; c.r[5] = 0x1Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602C414u) return; }  // 0602C410 jsr @r8 ; mov #28,r5
    c.r[5] = c.r[9];  // 0602C414 mov r9,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0602C41Au; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602C41Au) return; }  // 0602C416 jsr @r8 ; mov r0,r4
    c.r[2] = ld32(0x0602C44Cu);  // 0602C41A mov.l 0x0602C44C,r2
    c.r[1] = ld32(c.r[2]);  // 0602C41C mov.l @r2,r1
    c.r[3] = c.r[0];  // 0602C41E mov r0,r3
    c.r[1] += 1;  // 0602C420 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602C422 mov.b @r1,r1
    c.r[3] += 33;  // 0602C424 add #33,r3
    st8(c.r[3], c.r[1]);  // 0602C426 mov.b r1,@r3
    c.r[1] = ld32(c.r[2]);  // 0602C428 mov.l @r2,r1
    c.r[0] += 34;  // 0602C42A add #34,r0
    c.r[1] += 2;  // 0602C42C add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602C42E mov.b @r1,r1
    c.r[15] = c.r[14];  // 0602C430 mov r14,r15
    st8(c.r[0], c.r[1]);  // 0602C432 mov.b r1,@r0
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602C434 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602C436 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0602C438 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602C442u);  // 0602C43A mov.w 0x0602C442,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602C43C rts ; mov.l @r15+,r8
}

void f_0602C450(SH2Context& c) {
    ran[621] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602C450 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602C452 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0602C454 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0602C456 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602C458 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602C45A sts.l pr,@-r15
    c.r[1] = ld32(0x0602C4CCu);  // 0602C45C mov.l 0x0602C4CC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602C462u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602C462u) return; }  // 0602C45E jsr @r1 ; mov r15,r14
    c.r[10] = ld32(0x0602C4D0u);  // 0602C462 mov.l 0x0602C4D0,r10
    c.r[2] = ld32(c.r[10]);  // 0602C464 mov.l @r10,r2
    c.r[11] = ld32(0x0602C4D4u);  // 0602C466 mov.l 0x0602C4D4,r11
    c.r[1] = c.r[2];  // 0602C468 mov r2,r1
    c.r[1] += 1;  // 0602C46A add #1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602C46C mov.b @r1,r4
    c.r[2] += 2;  // 0602C46E add #2,r2
    c.r[4] = c.r[4] & 0xFFu;  // 0602C470 extu.b r4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602C472 mov.b @r2,r1
    c.r[4] <<= 8;  // 0602C474 shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 0602C476 extu.b r1,r1
    { const uint32_t x = c.r[11]; c.pr = 0x0602C47Cu; c.r[4] |= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602C47Cu) return; }  // 0602C478 jsr @r11 ; or r1,r4
    c.r[8] = c.r[0] & 0xFFu;  // 0602C47C extu.b r0,r8
    c.r[9] = (uint32_t)(int16_t)ld16(0x0602C4C6u);  // 0602C47E mov.w 0x0602C4C6,r9
    c.t = c.r[8] == c.r[9];  // 0602C480 cmp/eq r9,r8
    if (c.t) { goto L_0602C4B4; }  // 0602C482 bt 0x0602C4B4
    c.r[2] = ld32(c.r[10]);  // 0602C484 mov.l @r10,r2
    c.r[1] = c.r[2];  // 0602C486 mov r2,r1
    c.r[1] += 3;  // 0602C488 add #3,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602C48A mov.b @r1,r4
    c.r[2] += 4;  // 0602C48C add #4,r2
    c.r[4] = c.r[4] & 0xFFu;  // 0602C48E extu.b r4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602C490 mov.b @r2,r1
    c.r[4] <<= 8;  // 0602C492 shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 0602C494 extu.b r1,r1
    { const uint32_t x = c.r[11]; c.pr = 0x0602C49Au; c.r[4] |= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602C49Au) return; }  // 0602C496 jsr @r11 ; or r1,r4
    c.r[0] = c.r[0] & 0xFFu;  // 0602C49A extu.b r0,r0
    c.t = c.r[0] == c.r[9];  // 0602C49C cmp/eq r9,r0
    { const bool k = c.t; c.r[4] = c.r[0] & 0xFFu; if (k) { goto L_0602C4B4; } }  // 0602C49E bt/s 0x0602C4B4 ; extu.b r0,r4
    c.r[0] = ld32(0x0602C4D8u);  // 0602C4A2 mov.l 0x0602C4D8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602C4A8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602C4A8u) return; }  // 0602C4A4 jsr @r0 ; nop
    c.r[1] = c.r[0] & 0xFFu;  // 0602C4A8 extu.b r0,r1
    c.t = c.r[8] == c.r[1];  // 0602C4AA cmp/eq r1,r8
    if (!c.t) { goto L_0602C4B4; }  // 0602C4AC bf 0x0602C4B4
    c.r[1] = ld32(0x0602C4DCu);  // 0602C4AE mov.l 0x0602C4DC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602C4B4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602C4B4u) return; }  // 0602C4B0 jsr @r1 ; nop
L_0602C4B4:
    c.r[15] = c.r[14];  // 0602C4B4 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602C4B6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602C4B8 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0602C4BA mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0602C4BC mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0602C4BE mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602C4C8u);  // 0602C4C0 mov.w 0x0602C4C8,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602C4C2 rts ; mov.l @r15+,r8
}

void f_0602C4E0(SH2Context& c) {
    ran[622] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602C4E0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602C4E2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0602C4E4 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0602C4E6 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0602C4E8 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0602C4EA mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602C4EC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602C4EE sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0602C4F0 mov r15,r14
    c.r[1] = ld32(0x0602C614u);  // 0602C4F2 mov.l 0x0602C614,r1
    c.r[10] = 0x0u;  // 0602C4F4 mov #0,r10
    c.r[1] = ld32(c.r[1]);  // 0602C4F6 mov.l @r1,r1
    c.r[12] = 0x3u;  // 0602C4F8 mov #3,r12
    c.r[1] += 1;  // 0602C4FA add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602C4FC mov.b @r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0602C60Au);  // 0602C4FE mov.w 0x0602C60A,r2
    c.r[0] = c.r[1] & 0xFFu;  // 0602C500 extu.b r1,r0
    c.r[2] &= c.r[0];  // 0602C502 and r0,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602C60Cu);  // 0602C504 mov.w 0x0602C60C,r1
    c.t = c.r[2] == c.r[1];  // 0602C506 cmp/eq r1,r2
    { const bool k = !c.t; c.r[12] &= c.r[0]; if (k) { goto L_0602C510; } }  // 0602C508 bf/s 0x0602C510 ; and r0,r12
    goto L_0602C668;  // 0602C50C bra 0x0602C668 ; nop
L_0602C510:
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0602C510 cmp/gt r1,r2
    { const bool k = c.t; c.r[0] = c.r[2]; if (k) { goto L_0602C522; } }  // 0602C512 bt/s 0x0602C522 ; mov r2,r0
    c.t = c.r[0] == 0x40u;  // 0602C516 cmp/eq #64,r0
    if (c.t) { goto L_0602C51E; }  // 0602C518 bt 0x0602C51E
    goto L_0602C6F4;  // 0602C51A bra 0x0602C6F4 ; nop
L_0602C51E:
    goto L_0602C530;  // 0602C51E bra 0x0602C530 ; nop
L_0602C522:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602C60Au);  // 0602C522 mov.w 0x0602C60A,r1
    c.t = c.r[2] == c.r[1];  // 0602C524 cmp/eq r1,r2
    if (c.t) { goto L_0602C52C; }  // 0602C526 bt 0x0602C52C
    goto L_0602C6F4;  // 0602C528 bra 0x0602C6F4 ; nop
L_0602C52C:
    goto L_0602C628;  // 0602C52C bra 0x0602C628 ; nop
L_0602C530:
    c.r[3] = ld32(0x0602C618u);  // 0602C530 mov.l 0x0602C618,r3
    c.r[2] = ld32(c.r[3]);  // 0602C532 mov.l @r3,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602C60Eu);  // 0602C534 mov.w 0x0602C60E,r1
    c.r[0] = c.r[2];  // 0602C536 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0602C538 mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602C53A extu.b r1,r1
    c.t = (int32_t)c.r[10] >= (int32_t)c.r[1];  // 0602C53C cmp/ge r1,r10
    { const bool k = !c.t; c.r[11] = 0x0u; if (k) { goto L_0602C546; } }  // 0602C53E bf/s 0x0602C546 ; mov #0,r11
    goto L_0602C75E;  // 0602C542 bra 0x0602C75E ; nop
L_0602C546:
    c.r[13] = ld32(0x0602C61Cu);  // 0602C546 mov.l 0x0602C61C,r13
    c.r[2] = c.r[11];  // 0602C548 mov r11,r2
L_0602C54A:
    c.r[1] = ld32(c.r[3]);  // 0602C54A mov.l @r3,r1
    c.r[2] += c.r[2];  // 0602C54C add r2,r2
    c.r[0] = c.r[1];  // 0602C54E mov r1,r0
    c.r[1] += c.r[2];  // 0602C550 add r2,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0602C552 mov.b @(r0,r2),r3
    c.r[1] += 1;  // 0602C554 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602C556 mov.b @r1,r1
    c.r[0] = 0x7Fu;  // 0602C558 mov #127,r0
    c.r[3] &= c.r[0];  // 0602C55A and r0,r3
    c.r[3] <<= 8;  // 0602C55C shll8 r3
    c.r[10] = c.r[1] & 0xFFu;  // 0602C55E extu.b r1,r10
    c.r[10] |= c.r[3];  // 0602C560 or r3,r10
    c.r[1] = ld32(0x0602C620u);  // 0602C562 mov.l 0x0602C620,r1
    c.r[2] = c.r[10];  // 0602C564 mov r10,r2
    c.r[2] <<= 2;  // 0602C566 shll2 r2
    c.r[2] <<= 2;  // 0602C568 shll2 r2
    c.r[3] = c.r[2];  // 0602C56A mov r2,r3
    c.r[1] = ld32(c.r[1]);  // 0602C56C mov.l @r1,r1
    c.r[0] = c.r[2];  // 0602C56E mov r2,r0
    c.r[3] += c.r[1];  // 0602C570 add r1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0602C572 mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602C574 extu.b r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0602C610u);  // 0602C576 mov.w 0x0602C610,r2
    c.t = c.r[1] == c.r[2];  // 0602C578 cmp/eq r2,r1
    { const bool k = c.t; c.r[3] += 2; if (k) { goto L_0602C5F4; } }  // 0602C57A bt/s 0x0602C5F4 ; add #2,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0602C57E mov.b @r3,r1
    c.r[3] = c.r[1] & 0xFFu;  // 0602C580 extu.b r1,r3
    c.r[1] = ld32(0x0602C624u);  // 0602C582 mov.l 0x0602C624,r1
    c.r[2] = ld32(c.r[1]);  // 0602C584 mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 0602C586 mov #30,r1
    c.macl = c.r[3] * c.r[1];  // 0602C588 mul.l r1,r3
    c.r[1] = c.macl;  // 0602C58A sts macl,r1
    c.r[1] += c.r[2];  // 0602C58C add r2,r1
    c.r[1] += 15;  // 0602C58E add #15,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602C590 mov.b @r1,r4
    c.r[5] = c.r[12];  // 0602C592 mov r12,r5
    { const uint32_t x = c.r[13]; c.pr = 0x0602C598u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602C598u) return; }  // 0602C594 jsr @r13 ; extu.b r4,r4
    c.r[9] = 0x0u;  // 0602C598 mov #0,r9
    c.r[8] = 0x0u;  // 0602C59A mov #0,r8
L_0602C59C:
    c.r[1] = ld32(0x0602C620u);  // 0602C59C mov.l 0x0602C620,r1
    c.r[3] = c.r[8];  // 0602C59E mov r8,r3
    c.r[0] = ld32(c.r[1]);  // 0602C5A0 mov.l @r1,r0
    c.r[2] = (uint32_t)(int16_t)ld16(0x0602C610u);  // 0602C5A2 mov.w 0x0602C610,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0602C5A4 mov.b @(r0,r8),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602C5A6 extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 0602C5A8 cmp/eq r2,r1
    { const bool k = c.t; c.r[3] += c.r[0]; if (k) { goto L_0602C5EA; } }  // 0602C5AA bt/s 0x0602C5EA ; add r0,r3
    c.r[1] = c.r[3];  // 0602C5AE mov r3,r1
    c.r[1] += 4;  // 0602C5B0 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602C5B2 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0602C5B4 mov r1,r0
    c.r[0] >>= 2;  // 0602C5B6 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0602C5B8 shlr r0
    c.r[0] >>= 2;  // 0602C5BA shlr2 r0
    c.r[0] &= 0x1u;  // 0602C5BC and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0602C5BE tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_0602C5EA; } }  // 0602C5C0 bt/s 0x0602C5EA ; mov r3,r1
    c.r[1] += 6;  // 0602C5C4 add #6,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602C5C6 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602C5C8 extu.b r1,r1
    c.t = c.r[10] == c.r[1];  // 0602C5CA cmp/eq r1,r10
    { const bool k = !c.t; c.r[3] += 2; if (k) { goto L_0602C5EA; } }  // 0602C5CC bf/s 0x0602C5EA ; add #2,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0602C5D0 mov.b @r3,r1
    c.r[3] = c.r[1] & 0xFFu;  // 0602C5D2 extu.b r1,r3
    c.r[1] = ld32(0x0602C624u);  // 0602C5D4 mov.l 0x0602C624,r1
    c.r[2] = ld32(c.r[1]);  // 0602C5D6 mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 0602C5D8 mov #30,r1
    c.macl = c.r[3] * c.r[1];  // 0602C5DA mul.l r1,r3
    c.r[1] = c.macl;  // 0602C5DC sts macl,r1
    c.r[1] += c.r[2];  // 0602C5DE add r2,r1
    c.r[1] += 15;  // 0602C5E0 add #15,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602C5E2 mov.b @r1,r4
    c.r[5] = c.r[12];  // 0602C5E4 mov r12,r5
    { const uint32_t x = c.r[13]; c.pr = 0x0602C5EAu; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602C5EAu) return; }  // 0602C5E6 jsr @r13 ; extu.b r4,r4
L_0602C5EA:
    c.r[9] += 1;  // 0602C5EA add #1,r9
    c.r[1] = 0x49u;  // 0602C5EC mov #73,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 0602C5EE cmp/gt r1,r9
    { const bool k = !c.t; c.r[8] += 16; if (k) { SH2_POLL(c); goto L_0602C59C; } }  // 0602C5F0 bf/s 0x0602C59C ; add #16,r8
L_0602C5F4:
    c.r[3] = ld32(0x0602C618u);  // 0602C5F4 mov.l 0x0602C618,r3
    c.r[1] = ld32(c.r[3]);  // 0602C5F6 mov.l @r3,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602C60Eu);  // 0602C5F8 mov.w 0x0602C60E,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0602C5FA mov.b @(r0,r1),r1
    c.r[11] += 1;  // 0602C5FC add #1,r11
    c.r[1] = c.r[1] & 0xFFu;  // 0602C5FE extu.b r1,r1
    c.t = (int32_t)c.r[11] >= (int32_t)c.r[1];  // 0602C600 cmp/ge r1,r11
    { const bool k = !c.t; c.r[2] = c.r[11]; if (k) { SH2_POLL(c); goto L_0602C54A; } }  // 0602C602 bf/s 0x0602C54A ; mov r11,r2
    goto L_0602C75E;  // 0602C606 bra 0x0602C75E ; nop
L_0602C628:
    c.r[3] = ld32(0x0602C78Cu);  // 0602C628 mov.l 0x0602C78C,r3
    c.r[2] = ld32(c.r[3]);  // 0602C62A mov.l @r3,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602C782u);  // 0602C62C mov.w 0x0602C782,r1
    c.r[0] = c.r[2];  // 0602C62E mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0602C630 mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602C632 extu.b r1,r1
    c.t = (int32_t)c.r[10] >= (int32_t)c.r[1];  // 0602C634 cmp/ge r1,r10
    { const bool k = !c.t; c.r[11] = 0x0u; if (k) { goto L_0602C63E; } }  // 0602C636 bf/s 0x0602C63E ; mov #0,r11
    goto L_0602C75E;  // 0602C63A bra 0x0602C75E ; nop
L_0602C63E:
    c.r[8] = c.r[3];  // 0602C63E mov r3,r8
    c.r[9] = ld32(0x0602C790u);  // 0602C640 mov.l 0x0602C790,r9
    c.r[1] = c.r[11];  // 0602C642 mov r11,r1
L_0602C644:
    c.r[2] = ld32(c.r[8]);  // 0602C644 mov.l @r8,r2
    c.r[1] += c.r[1];  // 0602C646 add r1,r1
    c.r[2] += c.r[1];  // 0602C648 add r1,r2
    c.r[2] += 1;  // 0602C64A add #1,r2
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602C64C mov.b @r2,r4
    c.r[5] = c.r[12];  // 0602C64E mov r12,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0602C654u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602C654u) return; }  // 0602C650 jsr @r9 ; extu.b r4,r4
    c.r[1] = ld32(c.r[8]);  // 0602C654 mov.l @r8,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602C782u);  // 0602C656 mov.w 0x0602C782,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0602C658 mov.b @(r0,r1),r1
    c.r[11] += 1;  // 0602C65A add #1,r11
    c.r[1] = c.r[1] & 0xFFu;  // 0602C65C extu.b r1,r1
    c.t = (int32_t)c.r[11] >= (int32_t)c.r[1];  // 0602C65E cmp/ge r1,r11
    { const bool k = !c.t; c.r[1] = c.r[11]; if (k) { SH2_POLL(c); goto L_0602C644; } }  // 0602C660 bf/s 0x0602C644 ; mov r11,r1
    goto L_0602C75E;  // 0602C664 bra 0x0602C75E ; nop
L_0602C668:
    c.r[1] = ld32(0x0602C78Cu);  // 0602C668 mov.l 0x0602C78C,r1
    c.r[2] = ld32(c.r[1]);  // 0602C66A mov.l @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602C782u);  // 0602C66C mov.w 0x0602C782,r0
    c.r[8] = 0x0u;  // 0602C66E mov #0,r8
    c.r[9] = 0x0u;  // 0602C670 mov #0,r9
    c.r[1] = 0x0u;  // 0602C672 mov #0,r1
    st8(c.r[0] + c.r[2], c.r[1]);  // 0602C674 mov.b r1,@(r0,r2)
L_0602C676:
    c.r[4] = c.r[8] & 0xFFu;  // 0602C676 extu.b r8,r4
    c.r[0] = ld32(0x0602C794u);  // 0602C678 mov.l 0x0602C794,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602C67Eu; c.r[5] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602C67Eu) return; }  // 0602C67A jsr @r0 ; mov #1,r5
    c.r[10] = c.r[0] & 0xFFu;  // 0602C67E extu.b r0,r10
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602C784u);  // 0602C680 mov.w 0x0602C784,r1
    c.t = c.r[10] == c.r[1];  // 0602C682 cmp/eq r1,r10
    { const bool k = c.t; c.r[10] <<= 2; if (k) { goto L_0602C6E6; } }  // 0602C684 bt/s 0x0602C6E6 ; shll2 r10
    c.r[1] = ld32(0x0602C798u);  // 0602C688 mov.l 0x0602C798,r1
    c.r[1] = ld32(c.r[1]);  // 0602C68A mov.l @r1,r1
    c.r[10] <<= 2;  // 0602C68C shll2 r10
    c.r[10] += c.r[1];  // 0602C68E add r1,r10
    c.r[10] += 3;  // 0602C690 add #3,r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0602C692 mov.b @r10,r1
    c.r[0] = c.r[1];  // 0602C694 mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0602C696 shlr r0
    c.r[0] &= 0x3u;  // 0602C698 and #3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0602C69A tst r0,r0
    if (!c.t) { goto L_0602C6E6; }  // 0602C69C bf 0x0602C6E6
    c.r[1] = ld32(0x0602C79Cu);  // 0602C69E mov.l 0x0602C79C,r1
    c.r[1] = ld32(c.r[1]);  // 0602C6A0 mov.l @r1,r1
    c.r[1] += c.r[9];  // 0602C6A2 add r9,r1
    c.r[1] += 3;  // 0602C6A4 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602C6A6 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0602C6A8 mov r1,r0
    c.r[0] >>= 2;  // 0602C6AA shlr2 r0
    c.r[0] >>= 2;  // 0602C6AC shlr2 r0
    c.r[0] &= 0x3u;  // 0602C6AE and #3,r0
    c.t = c.r[0] == c.r[12];  // 0602C6B0 cmp/eq r12,r0
    if (!c.t) { goto L_0602C6E6; }  // 0602C6B2 bf 0x0602C6E6
    c.r[1] = ld32(0x0602C78Cu);  // 0602C6B4 mov.l 0x0602C78C,r1
    c.r[3] = ld32(c.r[1]);  // 0602C6B6 mov.l @r1,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x0602C782u);  // 0602C6B8 mov.w 0x0602C782,r7
    c.r[0] = c.r[3];  // 0602C6BA mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0602C6BC mov.b @(r0,r7),r2
    c.r[1] = c.r[2];  // 0602C6BE mov r2,r1
    c.r[1] += 1;  // 0602C6C0 add #1,r1
    st8(c.r[0] + c.r[7], c.r[1]);  // 0602C6C2 mov.b r1,@(r0,r7)
    c.r[7] = c.r[2] & 0xFFu;  // 0602C6C4 extu.b r2,r7
    c.r[7] += c.r[7];  // 0602C6C6 add r7,r7
    c.r[1] = c.r[8] & 0xFFFFu;  // 0602C6C8 extu.w r8,r1
    c.r[6] = c.r[1];  // 0602C6CA mov r1,r6
    c.r[6] >>= 8;  // 0602C6CC shlr8 r6
    c.r[0] = 0x7Fu;  // 0602C6CE mov #127,r0
    c.r[6] &= c.r[0];  // 0602C6D0 and r0,r6
    c.r[0] = c.r[3];  // 0602C6D2 mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0602C6D4 mov.b @(r0,r7),r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602C786u);  // 0602C6D6 mov.w 0x0602C786,r0
    c.r[2] &= c.r[0];  // 0602C6D8 and r0,r2
    c.r[2] |= c.r[6];  // 0602C6DA or r6,r2
    c.r[0] = c.r[3];  // 0602C6DC mov r3,r0
    st8(c.r[0] + c.r[7], c.r[2]);  // 0602C6DE mov.b r2,@(r0,r7)
    c.r[3] += c.r[7];  // 0602C6E0 add r7,r3
    c.r[3] += 1;  // 0602C6E2 add #1,r3
    st8(c.r[3], c.r[1]);  // 0602C6E4 mov.b r1,@r3
L_0602C6E6:
    c.r[8] += 1;  // 0602C6E6 add #1,r8
    c.r[1] = 0x7Fu;  // 0602C6E8 mov #127,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 0602C6EA cmp/gt r1,r8
    { const bool k = !c.t; c.r[9] += 12; if (k) { SH2_POLL(c); goto L_0602C676; } }  // 0602C6EC bf/s 0x0602C676 ; add #12,r9
    goto L_0602C75E;  // 0602C6F0 bra 0x0602C75E ; nop
L_0602C6F4:
    c.r[1] = ld32(0x0602C78Cu);  // 0602C6F4 mov.l 0x0602C78C,r1
    c.r[2] = ld32(c.r[1]);  // 0602C6F6 mov.l @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602C782u);  // 0602C6F8 mov.w 0x0602C782,r0
    c.r[8] = 0x0u;  // 0602C6FA mov #0,r8
    c.r[5] = c.r[0];  // 0602C6FC mov r0,r5
    c.r[6] = 0x0u;  // 0602C6FE mov #0,r6
    c.r[1] = 0x0u;  // 0602C700 mov #0,r1
    st8(c.r[0] + c.r[2], c.r[1]);  // 0602C702 mov.b r1,@(r0,r2)
L_0602C704:
    c.r[1] = ld32(0x0602C79Cu);  // 0602C704 mov.l 0x0602C79C,r1
    c.r[0] = ld32(c.r[1]);  // 0602C706 mov.l @r1,r0
    c.r[2] = c.r[6];  // 0602C708 mov r6,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[6]);  // 0602C70A mov.w @(r0,r6),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0602C70C extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0602C70E tst r1,r1
    { const bool k = c.t; c.r[2] += c.r[0]; if (k) { goto L_0602C754; } }  // 0602C710 bt/s 0x0602C754 ; add r0,r2
    c.r[2] += 3;  // 0602C714 add #3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602C716 mov.b @r2,r1
    c.r[0] = c.r[1];  // 0602C718 mov r1,r0
    c.r[0] >>= 2;  // 0602C71A shlr2 r0
    c.r[0] >>= 2;  // 0602C71C shlr2 r0
    c.r[0] &= 0x3u;  // 0602C71E and #3,r0
    c.t = c.r[0] == c.r[12];  // 0602C720 cmp/eq r12,r0
    if (!c.t) { goto L_0602C754; }  // 0602C722 bf 0x0602C754
    c.r[1] = ld32(0x0602C78Cu);  // 0602C724 mov.l 0x0602C78C,r1
    c.r[3] = ld32(c.r[1]);  // 0602C726 mov.l @r1,r3
    c.r[0] = c.r[3];  // 0602C728 mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 0602C72A mov.b @(r0,r5),r2
    c.r[1] = c.r[2];  // 0602C72C mov r2,r1
    c.r[1] += 1;  // 0602C72E add #1,r1
    st8(c.r[0] + c.r[5], c.r[1]);  // 0602C730 mov.b r1,@(r0,r5)
    c.r[7] = c.r[2] & 0xFFu;  // 0602C732 extu.b r2,r7
    c.r[7] += c.r[7];  // 0602C734 add r7,r7
    c.r[1] = c.r[8] & 0xFFFFu;  // 0602C736 extu.w r8,r1
    c.r[4] = c.r[1];  // 0602C738 mov r1,r4
    c.r[4] >>= 8;  // 0602C73A shlr8 r4
    c.r[0] = 0x7Fu;  // 0602C73C mov #127,r0
    c.r[4] &= c.r[0];  // 0602C73E and r0,r4
    c.r[0] = c.r[3];  // 0602C740 mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0602C742 mov.b @(r0,r7),r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602C786u);  // 0602C744 mov.w 0x0602C786,r0
    c.r[2] &= c.r[0];  // 0602C746 and r0,r2
    c.r[2] |= c.r[4];  // 0602C748 or r4,r2
    c.r[0] = c.r[3];  // 0602C74A mov r3,r0
    st8(c.r[0] + c.r[7], c.r[2]);  // 0602C74C mov.b r2,@(r0,r7)
    c.r[3] += c.r[7];  // 0602C74E add r7,r3
    c.r[3] += 1;  // 0602C750 add #1,r3
    st8(c.r[3], c.r[1]);  // 0602C752 mov.b r1,@r3
L_0602C754:
    c.r[8] += 1;  // 0602C754 add #1,r8
    c.r[1] = 0x7Fu;  // 0602C756 mov #127,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 0602C758 cmp/gt r1,r8
    { const bool k = !c.t; c.r[6] += 12; if (k) { SH2_POLL(c); goto L_0602C704; } }  // 0602C75A bf/s 0x0602C704 ; add #12,r6
L_0602C75E:
    c.r[2] = ld32(0x0602C7A0u);  // 0602C75E mov.l 0x0602C7A0,r2
    c.r[1] = ld32(0x0602C78Cu);  // 0602C760 mov.l 0x0602C78C,r1
    c.r[1] = ld32(c.r[1]);  // 0602C762 mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602C782u);  // 0602C764 mov.w 0x0602C782,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0602C766 mov.b @(r0,r1),r1
    c.r[15] = c.r[14];  // 0602C768 mov r14,r15
    c.r[1] = c.r[1] & 0xFFu;  // 0602C76A extu.b r1,r1
    st32(c.r[2] + 20, c.r[1]);  // 0602C76C mov.l r1,@(20,r2)
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602C76E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602C770 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0602C772 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0602C774 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0602C776 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0602C778 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0602C77A mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602C788u);  // 0602C77C mov.w 0x0602C788,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602C77E rts ; mov.l @r15+,r8
}

void f_0602C7A4(SH2Context& c) {
    ran[623] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602C7A4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602C7A6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602C7A8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602C7AA sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0602C7AC mov r15,r14
    c.r[3] = ld32(0x0602C82Cu);  // 0602C7AE mov.l 0x0602C82C,r3
    c.r[2] = ld32(c.r[3]);  // 0602C7B0 mov.l @r3,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602C826u);  // 0602C7B2 mov.w 0x0602C826,r1
    c.r[0] = c.r[2];  // 0602C7B4 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0602C7B6 mov.b @(r0,r1),r1
    c.r[9] = 0x0u; goto L_0602C810;  // 0602C7B8 bra 0x0602C810 ; mov #0,r9
L_0602C7BC:
    c.r[1] = ld32(c.r[3]);  // 0602C7BC mov.l @r3,r1
    c.r[2] += c.r[2];  // 0602C7BE add r2,r2
    c.r[0] = c.r[1];  // 0602C7C0 mov r1,r0
    c.r[1] += c.r[2];  // 0602C7C2 add r2,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0602C7C4 mov.b @(r0,r2),r3
    c.r[1] += 1;  // 0602C7C6 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602C7C8 mov.b @r1,r1
    c.r[0] = 0x7Fu;  // 0602C7CA mov #127,r0
    c.r[3] &= c.r[0];  // 0602C7CC and r0,r3
    c.r[3] <<= 8;  // 0602C7CE shll8 r3
    c.r[4] = c.r[1] & 0xFFu;  // 0602C7D0 extu.b r1,r4
    c.r[4] |= c.r[3];  // 0602C7D2 or r3,r4
    c.r[1] = ld32(0x0602C830u);  // 0602C7D4 mov.l 0x0602C830,r1
    c.r[2] = c.r[4];  // 0602C7D6 mov r4,r2
    c.r[2] += c.r[2];  // 0602C7D8 add r2,r2
    c.r[2] += c.r[4];  // 0602C7DA add r4,r2
    c.r[2] <<= 2;  // 0602C7DC shll2 r2
    c.r[1] = ld32(c.r[1]);  // 0602C7DE mov.l @r1,r1
    c.r[0] = c.r[2];  // 0602C7E0 mov r2,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0602C7E2 mov.w @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0602C7E4 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0602C7E6 tst r1,r1
    if (c.t) { goto L_0602C806; }  // 0602C7E8 bt 0x0602C806
    c.r[8] = c.r[4] & 0xFFu;  // 0602C7EA extu.b r4,r8
    c.r[0] = ld32(0x0602C834u);  // 0602C7EC mov.l 0x0602C834,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602C7F2u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602C7F2u) return; }  // 0602C7EE jsr @r0 ; mov r8,r4
    c.r[4] = c.r[0] & 0xFFu;  // 0602C7F2 extu.b r0,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602C828u);  // 0602C7F4 mov.w 0x0602C828,r1
    c.t = c.r[4] == c.r[1];  // 0602C7F6 cmp/eq r1,r4
    if (c.t) { goto L_0602C800; }  // 0602C7F8 bt 0x0602C800
    c.r[0] = ld32(0x0602C838u);  // 0602C7FA mov.l 0x0602C838,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602C800u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602C800u) return; }  // 0602C7FC jsr @r0 ; extu.b r4,r4
L_0602C800:
    c.r[1] = ld32(0x0602C83Cu);  // 0602C800 mov.l 0x0602C83C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602C806u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602C806u) return; }  // 0602C802 jsr @r1 ; mov r8,r4
L_0602C806:
    c.r[3] = ld32(0x0602C82Cu);  // 0602C806 mov.l 0x0602C82C,r3
    c.r[1] = ld32(c.r[3]);  // 0602C808 mov.l @r3,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602C826u);  // 0602C80A mov.w 0x0602C826,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0602C80C mov.b @(r0,r1),r1
    c.r[9] += 1;  // 0602C80E add #1,r9
L_0602C810:
    c.r[1] = c.r[1] & 0xFFu;  // 0602C810 extu.b r1,r1
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[1];  // 0602C812 cmp/ge r1,r9
    { const bool k = !c.t; c.r[2] = c.r[9]; if (k) { SH2_POLL(c); goto L_0602C7BC; } }  // 0602C814 bf/s 0x0602C7BC ; mov r9,r2
    c.r[15] = c.r[14];  // 0602C818 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602C81A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602C81C mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0602C81E mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602C82Au);  // 0602C820 mov.w 0x0602C82A,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602C822 rts ; mov.l @r15+,r8
}

void f_0602C840(SH2Context& c) {
    ran[624] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602C840 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602C842 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0602C844 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0602C846 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602C848 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602C84A sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0602C84C mov r15,r14
    c.r[4] = c.r[4] & 0xFFu;  // 0602C84E extu.b r4,r4
    c.r[11] = ld32(0x0602C8C0u);  // 0602C850 mov.l 0x0602C8C0,r11
    c.r[10] = c.r[4];  // 0602C852 mov r4,r10
    c.r[10] += c.r[10];  // 0602C854 add r10,r10
    c.r[10] += c.r[4];  // 0602C856 add r4,r10
    c.r[10] <<= 2;  // 0602C858 shll2 r10
    c.r[0] = c.r[10];  // 0602C85A mov r10,r0
    c.r[4] = ld32(0x0602C8C4u);  // 0602C85C mov.l 0x0602C8C4,r4
    c.r[1] = ld32(c.r[11]);  // 0602C85E mov.l @r11,r1
    c.r[9] = ld32(0x0602C8C8u);  // 0602C860 mov.l 0x0602C8C8,r9
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0602C862 mov.w @(r0,r1),r8
    c.r[5] = 0x1Cu;  // 0602C864 mov #28,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0602C86Au; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602C86Au) return; }  // 0602C866 jsr @r9 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 0602C86A mov r0,r1
    c.r[5] = c.r[8];  // 0602C86C mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0602C872u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602C872u) return; }  // 0602C86E jsr @r9 ; mov r1,r4
    c.r[8] = c.r[0];  // 0602C872 mov r0,r8
    c.r[6] = 0x6u;  // 0602C874 mov #6,r6
    c.r[1] = ld32(c.r[11]);  // 0602C876 mov.l @r11,r1
    c.r[5] = c.r[8];  // 0602C878 mov r8,r5
    c.r[1] += c.r[10];  // 0602C87A add r10,r1
    c.r[1] += 2;  // 0602C87C add #2,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602C87E mov.b @r1,r4
    c.r[0] = ld32(0x0602C8CCu);  // 0602C880 mov.l 0x0602C8CC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602C886u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602C886u) return; }  // 0602C882 jsr @r0 ; extu.b r4,r4
    c.r[3] = c.r[0];  // 0602C886 mov r0,r3
    c.r[1] = c.r[8];  // 0602C888 mov r8,r1
    c.r[1] += 17;  // 0602C88A add #17,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602C88C mov.b @r1,r1
    c.r[8] += 18;  // 0602C88E add #18,r8
    c.r[11] = ld32(c.r[11]);  // 0602C890 mov.l @r11,r11
    c.r[2] = c.r[1] & 0xFFu;  // 0602C892 extu.b r1,r2
    c.r[2] <<= 8;  // 0602C894 shll8 r2
    c.r[11] += c.r[10];  // 0602C896 add r10,r11
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0602C898 mov.b @r8,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602C89A extu.b r1,r1
    c.r[2] |= c.r[1];  // 0602C89C or r1,r2
    c.r[1] = c.r[3] & 0xFFFFu;  // 0602C89E extu.w r3,r1
    c.r[2] += c.r[1];  // 0602C8A0 add r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602C8BEu);  // 0602C8A2 mov.w 0x0602C8BE,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0602C8A4 cmp/gt r1,r2
    { const bool k = !c.t; c.r[11] += 10; if (k) { goto L_0602C8AC; } }  // 0602C8A6 bf/s 0x0602C8AC ; add #10,r11
    c.r[2] = c.r[1];  // 0602C8AA mov r1,r2
L_0602C8AC:
    st16(c.r[11], c.r[2]);  // 0602C8AC mov.w r2,@r11
    c.r[15] = c.r[14];  // 0602C8AE mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602C8B0 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602C8B2 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0602C8B4 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0602C8B6 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0602C8B8 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602C8BA rts ; mov.l @r15+,r8
}

void f_0602C8D0(SH2Context& c) {
    ran[625] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602C8D0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602C8D2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0602C8D4 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0602C8D6 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0602C8D8 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0602C8DA mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602C8DC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602C8DE sts.l pr,@-r15
    c.r[15] -= 4;  // 0602C8E0 add #-4,r15
    c.r[14] = c.r[15];  // 0602C8E2 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0602C8E4 mov.l r4,@r14
    c.r[11] = c.r[5] & 0xFFu;  // 0602C8E6 extu.b r5,r11
    c.r[10] = 0x0u;  // 0602C8E8 mov #0,r10
    c.r[13] = ld32(0x0602C94Cu);  // 0602C8EA mov.l 0x0602C94C,r13
    c.r[12] = (uint32_t)(int16_t)ld16(0x0602C946u);  // 0602C8EC mov.w 0x0602C946,r12
    c.r[9] = ld32(c.r[14]);  // 0602C8EE mov.l @r14,r9
L_0602C8F0:
    c.r[9] += c.r[10];  // 0602C8F0 add r10,r9
    c.r[9] += 30;  // 0602C8F2 add #30,r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0602C8F4 mov.b @r9,r1
    c.r[4] = c.r[1] & 0xFFu;  // 0602C8F6 extu.b r1,r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 0602C8F8 tst r4,r4
    if (c.t) { goto L_0602C922; }  // 0602C8FA bt 0x0602C922
    { const uint32_t x = c.r[13]; c.pr = 0x0602C900u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602C900u) return; }  // 0602C8FC jsr @r13 ; nop
    c.r[8] = c.r[0] & 0xFFu;  // 0602C900 extu.b r0,r8
    { const uint32_t x = c.r[13]; c.pr = 0x0602C906u; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602C906u) return; }  // 0602C902 jsr @r13 ; mov r11,r4
    c.t = c.r[8] == c.r[12];  // 0602C906 cmp/eq r12,r8
    { const bool k = c.t; c.r[0] = c.r[0] & 0xFFu; if (k) { goto L_0602C926; } }  // 0602C908 bt/s 0x0602C926 ; extu.b r0,r0
    c.t = c.r[0] == c.r[12];  // 0602C90C cmp/eq r12,r0
    if (c.t) { goto L_0602C926; }  // 0602C90E bt 0x0602C926
    c.r[2] = (uint32_t)(int16_t)ld16(0x0602C948u);  // 0602C910 mov.w 0x0602C948,r2
    c.r[2] &= c.r[8];  // 0602C912 and r8,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602C948u);  // 0602C914 mov.w 0x0602C948,r1
    c.r[1] &= c.r[0];  // 0602C916 and r0,r1
    c.t = c.r[2] == c.r[1];  // 0602C918 cmp/eq r1,r2
    { const bool k = !c.t; c.t = c.r[8] >= c.r[0]; if (k) { goto L_0602C926; } }  // 0602C91A bf/s 0x0602C926 ; cmp/hs r0,r8
    { const bool k = c.t; c.r[10] += 1; if (k) { goto L_0602C928; } }  // 0602C91E bt/s 0x0602C928 ; add #1,r10
L_0602C922:
    st8(c.r[9], c.r[11]); goto L_0602C930;  // 0602C922 bra 0x0602C930 ; mov.b r11,@r9
L_0602C926:
    c.r[10] += 1;  // 0602C926 add #1,r10
L_0602C928:
    c.r[1] = 0x3u;  // 0602C928 mov #3,r1
    c.t = (int32_t)c.r[10] > (int32_t)c.r[1];  // 0602C92A cmp/gt r1,r10
    { const bool k = !c.t; c.r[9] = ld32(c.r[14]); if (k) { SH2_POLL(c); goto L_0602C8F0; } }  // 0602C92C bf/s 0x0602C8F0 ; mov.l @r14,r9
L_0602C930:
    c.r[14] += 4;  // 0602C930 add #4,r14
    c.r[15] = c.r[14];  // 0602C932 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602C934 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602C936 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0602C938 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0602C93A mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0602C93C mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0602C93E mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0602C940 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602C942 rts ; mov.l @r15+,r8
}

void f_0602C950(SH2Context& c) {
    ran[626] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602C950 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0602C952 mov r15,r14
    c.r[0] = c.r[4] & 0xFFu;  // 0602C954 extu.b r4,r0
    c.r[3] = (uint32_t)(int16_t)ld16(0x0602C9B0u);  // 0602C956 mov.w 0x0602C9B0,r3
    c.r[1] = c.r[0];  // 0602C958 mov r0,r1
    c.r[1] -= 33;  // 0602C95A add #-33,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602C95C extu.b r1,r1
    c.r[2] = 0x8u;  // 0602C95E mov #8,r2
    c.t = c.r[1] > c.r[2];  // 0602C960 cmp/hi r2,r1
    { const bool k = c.t; c.r[7] = c.r[0]; if (k) { goto L_0602C96E; } }  // 0602C962 bt/s 0x0602C96E ; mov r0,r7
    c.r[0] -= 32;  // 0602C966 add #-32,r0
    c.r[0] |= 0x10u;  // 0602C968 or #16,r0
    c.r[3] = c.r[0] & 0xFFu; goto L_0602C9A8;  // 0602C96A bra 0x0602C9A8 ; extu.b r0,r3
L_0602C96E:
    c.r[1] = 0x32u;  // 0602C96E mov #50,r1
    c.t = c.r[0] > c.r[1];  // 0602C970 cmp/hi r1,r0
    { const bool k = c.t; c.r[1] = 0x3Bu; if (k) { goto L_0602C97E; } }  // 0602C972 bt/s 0x0602C97E ; mov #59,r1
    c.r[0] -= 41;  // 0602C976 add #-41,r0
    c.r[0] |= 0x20u;  // 0602C978 or #32,r0
    c.r[3] = c.r[0] & 0xFFu; goto L_0602C9A8;  // 0602C97A bra 0x0602C9A8 ; extu.b r0,r3
L_0602C97E:
    c.t = c.r[0] > c.r[1];  // 0602C97E cmp/hi r1,r0
    { const bool k = c.t; c.r[1] = 0x44u; if (k) { goto L_0602C98C; } }  // 0602C980 bt/s 0x0602C98C ; mov #68,r1
    c.r[0] -= 50;  // 0602C984 add #-50,r0
    c.r[0] |= 0x30u;  // 0602C986 or #48,r0
    c.r[3] = c.r[0] & 0xFFu; goto L_0602C9A8;  // 0602C988 bra 0x0602C9A8 ; extu.b r0,r3
L_0602C98C:
    c.t = c.r[0] > c.r[1];  // 0602C98C cmp/hi r1,r0
    { const bool k = c.t; c.r[1] = 0x4Du; if (k) { goto L_0602C99A; } }  // 0602C98E bt/s 0x0602C99A ; mov #77,r1
    c.r[0] -= 59;  // 0602C992 add #-59,r0
    c.r[0] |= 0x40u;  // 0602C994 or #64,r0
    c.r[3] = c.r[0] & 0xFFu; goto L_0602C9A8;  // 0602C996 bra 0x0602C9A8 ; extu.b r0,r3
L_0602C99A:
    c.t = c.r[7] > c.r[1];  // 0602C99A cmp/hi r1,r7
    { const bool k = c.t; c.r[15] = c.r[14]; if (k) { goto L_0602C9AA; } }  // 0602C99C bt/s 0x0602C9AA ; mov r14,r15
    c.r[7] -= 68;  // 0602C9A0 add #-68,r7
    c.r[6] = 0x50u;  // 0602C9A2 mov #80,r6
    c.r[7] |= c.r[6];  // 0602C9A4 or r6,r7
    c.r[3] = c.r[7] & 0xFFu;  // 0602C9A6 extu.b r7,r3
L_0602C9A8:
    c.r[15] = c.r[14];  // 0602C9A8 mov r14,r15
L_0602C9AA:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602C9AA mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[3]; c.pc = x; return; }  // 0602C9AC rts ; mov r3,r0
}

void f_0602C9B4(SH2Context& c) {
    ran[627] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602C9B4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602C9B6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0602C9B8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0602C9BA mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0602C9BC mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0602C9BE mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602C9C0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602C9C2 sts.l pr,@-r15
    c.r[15] -= 4;  // 0602C9C4 add #-4,r15
    c.r[14] = c.r[15];  // 0602C9C6 mov r15,r14
    c.r[4] = c.r[4] & 0xFFu;  // 0602C9C8 extu.b r4,r4
    st32(c.r[14], c.r[4]);  // 0602C9CA mov.l r4,@r14
    c.r[13] = 0x0u;  // 0602C9CC mov #0,r13
    c.r[12] = 0x0u;  // 0602C9CE mov #0,r12
    c.r[4] = ld32(0x0602CB28u);  // 0602C9D0 mov.l 0x0602CB28,r4
    c.r[0] = ld32(0x0602CB2Cu);  // 0602C9D2 mov.l 0x0602CB2C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602C9D8u; c.r[5] = 0x21u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602C9D8u) return; }  // 0602C9D4 jsr @r0 ; mov #33,r5
    c.r[2] = ld32(c.r[14]);  // 0602C9D8 mov.l @r14,r2
    c.r[1] = ld32(0x0602CB30u);  // 0602C9DA mov.l 0x0602CB30,r1
    c.r[1] = ld32(c.r[1]);  // 0602C9DC mov.l @r1,r1
    c.r[2] <<= 2;  // 0602C9DE shll2 r2
    c.r[2] <<= 2;  // 0602C9E0 shll2 r2
    c.r[2] += c.r[1];  // 0602C9E2 add r1,r2
    c.r[2] += 2;  // 0602C9E4 add #2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602C9E6 mov.b @r2,r1
    c.r[7] = (uint32_t)(int16_t)ld16(0x0602CB24u);  // 0602C9E8 mov.w 0x0602CB24,r7
    c.r[2] = c.r[1] & 0xFFu;  // 0602C9EA extu.b r1,r2
    c.t = c.r[2] == c.r[7];  // 0602C9EC cmp/eq r7,r2
    { const bool k = !c.t; c.r[5] = c.r[0]; if (k) { goto L_0602C9F6; } }  // 0602C9EE bf/s 0x0602C9F6 ; mov r0,r5
    goto L_0602CB60;  // 0602C9F2 bra 0x0602CB60 ; nop
L_0602C9F6:
    c.r[1] = ld32(0x0602CB34u);  // 0602C9F6 mov.l 0x0602CB34,r1
    c.r[6] = 0x1Eu;  // 0602C9F8 mov #30,r6
    c.macl = c.r[2] * c.r[6];  // 0602C9FA mul.l r6,r2
    c.r[3] = ld32(c.r[1]);  // 0602C9FC mov.l @r1,r3
    c.r[1] = c.macl;  // 0602C9FE sts macl,r1
    c.r[1] += c.r[3];  // 0602CA00 add r3,r1
    c.r[1] += 16;  // 0602CA02 add #16,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602CA04 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602CA06 extu.b r1,r1
    c.t = c.r[1] == c.r[7];  // 0602CA08 cmp/eq r7,r1
    if (c.t) { goto L_0602CA0E; }  // 0602CA0A bt 0x0602CA0E
    c.r[2] = c.r[1];  // 0602CA0C mov r1,r2
L_0602CA0E:
    c.macl = c.r[2] * c.r[6];  // 0602CA0E mul.l r6,r2
    c.r[1] = c.macl;  // 0602CA10 sts macl,r1
    c.r[1] += c.r[3];  // 0602CA12 add r3,r1
    c.r[1] += 15;  // 0602CA14 add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602CA16 mov.b @r1,r1
    c.r[3] = c.r[1] & 0xFFu;  // 0602CA18 extu.b r1,r3
    c.t = c.r[3] == c.r[7];  // 0602CA1A cmp/eq r7,r3
    { const bool k = !c.t; c.r[1] = 0x64u; if (k) { goto L_0602CA24; } }  // 0602CA1C bf/s 0x0602CA24 ; mov #100,r1
    goto L_0602CB56;  // 0602CA20 bra 0x0602CB56 ; nop
L_0602CA24:
    c.r[1] = ld32(0x0602CB38u);  // 0602CA24 mov.l 0x0602CB38,r1
    c.r[2] = ld32(c.r[1]);  // 0602CA26 mov.l @r1,r2
    c.r[1] = c.r[3];  // 0602CA28 mov r3,r1
    c.r[1] += c.r[1];  // 0602CA2A add r1,r1
    c.r[1] += c.r[3];  // 0602CA2C add r3,r1
    c.r[1] <<= 2;  // 0602CA2E shll2 r1
    c.r[0] = c.r[1];  // 0602CA30 mov r1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 0602CA32 mov.w @(r0,r2),r1
    c.r[3] = 0x0u;  // 0602CA34 mov #0,r3
    c.r[6] = c.r[1] & 0xFFFFu;  // 0602CA36 extu.w r1,r6
    c.r[1] = c.r[5];  // 0602CA38 mov r5,r1
L_0602CA3A:
    c.r[1] += 2;  // 0602CA3A add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602CA3C mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0602CA3E extu.b r2,r2
    c.r[1] = c.r[5];  // 0602CA40 mov r5,r1
    c.r[1] += 3;  // 0602CA42 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602CA44 mov.b @r1,r1
    c.r[2] <<= 8;  // 0602CA46 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0602CA48 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0602CA4A or r1,r2
    c.t = c.r[6] == c.r[2];  // 0602CA4C cmp/eq r2,r6
    if (!c.t) { goto L_0602CA58; }  // 0602CA4E bf 0x0602CA58
    c.r[13] += 1;  // 0602CA50 add #1,r13
    c.r[0] = ld32(0x0602CB3Cu);  // 0602CA52 mov.l 0x0602CB3C,r0
    st32(c.r[0] + c.r[3], c.r[5]);  // 0602CA54 mov.l r5,@(r0,r3)
    c.r[3] += 4;  // 0602CA56 add #4,r3
L_0602CA58:
    c.r[5] += 6;  // 0602CA58 add #6,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[5]);  // 0602CA5A mov.b @r5,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602CA5C extu.b r1,r1
    c.t = c.r[1] == c.r[7];  // 0602CA5E cmp/eq r7,r1
    if (c.t) { goto L_0602CA72; }  // 0602CA60 bt 0x0602CA72
    c.r[5] += 2;  // 0602CA62 add #2,r5
    c.r[2] = (uint32_t)(int16_t)ld16(0x0602CB24u);  // 0602CA64 mov.w 0x0602CB24,r2
L_0602CA66:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[5]);  // 0602CA66 mov.b @r5,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602CA68 extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 0602CA6A cmp/eq r2,r1
    { const bool k = !c.t; c.r[5] += 2; if (k) { SH2_POLL(c); goto L_0602CA66; } }  // 0602CA6C bf/s 0x0602CA66 ; add #2,r5
    c.r[5] -= 2;  // 0602CA70 add #-2,r5
L_0602CA72:
    c.r[5] += 1;  // 0602CA72 add #1,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[5]);  // 0602CA74 mov.b @r5,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602CA76 extu.b r1,r1
    c.t = c.r[1] == c.r[7];  // 0602CA78 cmp/eq r7,r1
    { const bool k = !c.t; c.r[1] = c.r[5]; if (k) { SH2_POLL(c); goto L_0602CA3A; } }  // 0602CA7A bf/s 0x0602CA3A ; mov r5,r1
    c.r[12] = 0x0u;  // 0602CA7E mov #0,r12
    c.t = (int32_t)c.r[12] >= (int32_t)c.r[13];  // 0602CA80 cmp/ge r13,r12
    { const bool k = c.t; c.r[1] = 0x64u; if (k) { goto L_0602CB56; } }  // 0602CA82 bt/s 0x0602CB56 ; mov #100,r1
    c.r[10] = 0x0u;  // 0602CA86 mov #0,r10
L_0602CA88:
    c.r[0] = ld32(0x0602CB3Cu);  // 0602CA88 mov.l 0x0602CB3C,r0
    c.r[8] = ld32(c.r[0] + c.r[10]);  // 0602CA8A mov.l @(r0,r10),r8
    c.r[2] = c.r[8];  // 0602CA8C mov r8,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]); c.r[2] += 1;  // 0602CA8E mov.b @r2+,r1
    c.r[9] = (uint32_t)(int16_t)ld16(0x0602CB24u);  // 0602CA90 mov.w 0x0602CB24,r9
    c.r[1] = c.r[1] & 0xFFu;  // 0602CA92 extu.b r1,r1
    c.r[11] = c.r[1];  // 0602CA94 mov r1,r11
    c.r[11] <<= 8;  // 0602CA96 shll8 r11
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602CA98 mov.b @r2,r1
    c.r[0] = ld32(0x0602CB40u);  // 0602CA9A mov.l 0x0602CB40,r0
    c.r[1] = c.r[1] & 0xFFu;  // 0602CA9C extu.b r1,r1
    c.r[11] |= c.r[1];  // 0602CA9E or r1,r11
    { const uint32_t x = c.r[0]; c.pr = 0x0602CAA4u; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602CAA4u) return; }  // 0602CAA0 jsr @r0 ; mov r11,r4
    c.r[1] = c.r[0];  // 0602CAA4 mov r0,r1
    c.r[3] = c.r[1] & 0xFFu;  // 0602CAA6 extu.b r1,r3
    c.t = c.r[3] == c.r[9];  // 0602CAA8 cmp/eq r9,r3
    { const bool k = c.t; c.r[2] = c.r[3]; if (k) { goto L_0602CB1C; } }  // 0602CAAA bt/s 0x0602CB1C ; mov r3,r2
    c.r[1] = ld32(0x0602CB38u);  // 0602CAAE mov.l 0x0602CB38,r1
    c.r[2] += c.r[2];  // 0602CAB0 add r2,r2
    c.r[2] += c.r[3];  // 0602CAB2 add r3,r2
    c.r[1] = ld32(c.r[1]);  // 0602CAB4 mov.l @r1,r1
    c.r[2] <<= 2;  // 0602CAB6 shll2 r2
    c.r[2] += c.r[1];  // 0602CAB8 add r1,r2
    c.r[2] += 2;  // 0602CABA add #2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602CABC mov.b @r2,r1
    c.r[8] += 4;  // 0602CABE add #4,r8
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0602CAC0 mov.b @r8,r3
    c.r[7] = c.r[1] & 0xFFu;  // 0602CAC2 extu.b r1,r7
    c.r[1] = c.r[3] & 0xFFu;  // 0602CAC4 extu.b r3,r1
    c.t = c.r[1] == c.r[9];  // 0602CAC6 cmp/eq r9,r1
    if (c.t) { goto L_0602CAE6; }  // 0602CAC8 bt 0x0602CAE6
    c.r[6] = c.r[9];  // 0602CACA mov r9,r6
    c.r[2] = c.r[8];  // 0602CACC mov r8,r2
    c.r[2] += 1;  // 0602CACE add #1,r2
L_0602CAD0:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602CAD0 mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602CAD2 extu.b r1,r1
    c.t = c.r[7] >= c.r[1];  // 0602CAD4 cmp/hs r1,r7
    { const bool k = !c.t; c.r[2] += 2; if (k) { goto L_0602CAE6; } }  // 0602CAD6 bf/s 0x0602CAE6 ; add #2,r2
    c.r[9] = c.r[3] & 0xFFu;  // 0602CADA extu.b r3,r9
    c.r[8] += 2;  // 0602CADC add #2,r8
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0602CADE mov.b @r8,r3
    c.r[1] = c.r[3] & 0xFFu;  // 0602CAE0 extu.b r3,r1
    c.t = c.r[1] == c.r[6];  // 0602CAE2 cmp/eq r6,r1
    if (!c.t) { SH2_POLL(c); goto L_0602CAD0; }  // 0602CAE4 bf 0x0602CAD0
L_0602CAE6:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602CB24u);  // 0602CAE6 mov.w 0x0602CB24,r0
    c.t = c.r[9] == c.r[0];  // 0602CAE8 cmp/eq r0,r9
    if (c.t) { goto L_0602CB1C; }  // 0602CAEA bt 0x0602CB1C
    c.r[0] = ld32(0x0602CB44u);  // 0602CAEC mov.l 0x0602CB44,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602CAF2u; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602CAF2u) return; }  // 0602CAEE jsr @r0 ; mov r11,r4
    c.r[1] = c.r[0];  // 0602CAF2 mov r0,r1
    c.r[5] = c.r[1] & 0xFFu;  // 0602CAF4 extu.b r1,r5
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602CB24u);  // 0602CAF6 mov.w 0x0602CB24,r0
    c.t = c.r[5] == c.r[0];  // 0602CAF8 cmp/eq r0,r5
    if (c.t) { goto L_0602CB1C; }  // 0602CAFA bt 0x0602CB1C
    c.r[0] = ld32(0x0602CB48u);  // 0602CAFC mov.l 0x0602CB48,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602CB02u; c.r[4] = ld32(c.r[14]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602CB02u) return; }  // 0602CAFE jsr @r0 ; mov.l @r14,r4
    c.r[2] = c.r[0];  // 0602CB02 mov r0,r2
    c.r[1] = ld32(0x0602CB4Cu);  // 0602CB04 mov.l 0x0602CB4C,r1
    c.r[9] -= 1;  // 0602CB06 add #-1,r9
    c.r[0] = c.r[1];  // 0602CB08 mov r1,r0
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 0602CB0A mov.b @(r0,r9),r3
    c.r[2] = c.r[2] & 0xFFu;  // 0602CB0C extu.b r2,r2
    c.r[1] = 0x3u;  // 0602CB0E mov #3,r1
    c.r[1] &= c.r[3];  // 0602CB10 and r3,r1
    c.t = c.r[2] > c.r[1];  // 0602CB12 cmp/hi r1,r2
    if (c.t) { goto L_0602CB1C; }  // 0602CB14 bt 0x0602CB1C
    c.r[1] = c.r[3] & 0xFFu;  // 0602CB16 extu.b r3,r1
    c.r[1] >>= 2;  // 0602CB18 shlr2 r1
    c.r[12] += c.r[1];  // 0602CB1A add r1,r12
L_0602CB1C:
    c.r[10] += 4;  // 0602CB1C add #4,r10
    c.r[1] = c.r[13];  // 0602CB1E mov r13,r1
    c.r[1] <<= 2; goto L_0602CB50;  // 0602CB20 bra 0x0602CB50 ; shll2 r1
L_0602CB50:
    c.t = (int32_t)c.r[10] >= (int32_t)c.r[1];  // 0602CB50 cmp/ge r1,r10
    { const bool k = !c.t; c.r[1] = 0x64u; if (k) { SH2_POLL(c); goto L_0602CA88; } }  // 0602CB52 bf/s 0x0602CA88 ; mov #100,r1
L_0602CB56:
    c.t = (int32_t)c.r[12] > (int32_t)c.r[1];  // 0602CB56 cmp/gt r1,r12
    if (!c.t) { goto L_0602CB5C; }  // 0602CB58 bf 0x0602CB5C
    c.r[12] = c.r[1];  // 0602CB5A mov r1,r12
L_0602CB5C:
    c.r[0] = c.r[12] & 0xFFu; goto L_0602CB62;  // 0602CB5C bra 0x0602CB62 ; extu.b r12,r0
L_0602CB60:
    c.r[0] = 0x0u;  // 0602CB60 mov #0,r0
L_0602CB62:
    c.r[14] += 4;  // 0602CB62 add #4,r14
    c.r[15] = c.r[14];  // 0602CB64 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602CB66 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602CB68 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0602CB6A mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0602CB6C mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0602CB6E mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0602CB70 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0602CB72 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602CB74 rts ; mov.l @r15+,r8
}

void f_0602CB78(SH2Context& c) {
    ran[628] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602CB78 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0602CB7A mov r15,r14
    c.r[4] = c.r[4] & 0xFFu;  // 0602CB7C extu.b r4,r4
    c.r[5] = c.r[5] & 0xFFu;  // 0602CB7E extu.b r5,r5
    c.r[1] = ld32(0x0602CBCCu);  // 0602CB80 mov.l 0x0602CBCC,r1
    c.r[4] <<= 2;  // 0602CB82 shll2 r4
    c.r[4] <<= 2;  // 0602CB84 shll2 r4
    c.r[6] = c.r[4];  // 0602CB86 mov r4,r6
    c.r[0] = c.r[4];  // 0602CB88 mov r4,r0
    c.r[5] <<= 2;  // 0602CB8A shll2 r5
    c.r[5] <<= 2;  // 0602CB8C shll2 r5
    c.r[2] = ld32(c.r[1]);  // 0602CB8E mov.l @r1,r2
    c.r[7] = c.r[5];  // 0602CB90 mov r5,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0602CB92 mov.b @(r0,r2),r1
    c.r[6] += c.r[2];  // 0602CB94 add r2,r6
    c.r[3] = c.r[1] & 0xFFu;  // 0602CB96 extu.b r1,r3
    c.r[0] = c.r[5];  // 0602CB98 mov r5,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0602CB9A mov.b @(r0,r2),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602CB9C extu.b r1,r1
    c.r[3] -= c.r[1];  // 0602CB9E sub r1,r3
    c.t = (int32_t)c.r[3] >= 0;  // 0602CBA0 cmp/pz r3
    { const bool k = c.t; c.r[7] += c.r[2]; if (k) { goto L_0602CBA8; } }  // 0602CBA2 bt/s 0x0602CBA8 ; add r2,r7
    c.r[3] = 0u - c.r[3];  // 0602CBA6 neg r3,r3
L_0602CBA8:
    c.r[6] += 1;  // 0602CBA8 add #1,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0602CBAA mov.b @r6,r1
    c.r[7] += 1;  // 0602CBAC add #1,r7
    c.r[2] = c.r[1] & 0xFFu;  // 0602CBAE extu.b r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0602CBB0 mov.b @r7,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602CBB2 extu.b r1,r1
    c.r[2] -= c.r[1];  // 0602CBB4 sub r1,r2
    c.t = (int32_t)c.r[2] >= 0;  // 0602CBB6 cmp/pz r2
    if (c.t) { goto L_0602CBBC; }  // 0602CBB8 bt 0x0602CBBC
    c.r[2] = 0u - c.r[2];  // 0602CBBA neg r2,r2
L_0602CBBC:
    c.r[1] = c.r[3];  // 0602CBBC mov r3,r1
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[2];  // 0602CBBE cmp/ge r2,r1
    if (c.t) { goto L_0602CBC4; }  // 0602CBC0 bt 0x0602CBC4
    c.r[1] = c.r[2];  // 0602CBC2 mov r2,r1
L_0602CBC4:
    c.r[15] = c.r[14];  // 0602CBC4 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602CBC6 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[1] & 0xFFu; c.pc = x; return; }  // 0602CBC8 rts ; extu.b r1,r0
}

void f_0602CBD0(SH2Context& c) {
    ran[629] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602CBD0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602CBD2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0602CBD4 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0602CBD6 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0602CBD8 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0602CBDA mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602CBDC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602CBDE sts.l pr,@-r15
    c.r[15] -= 8;  // 0602CBE0 add #-8,r15
    c.r[5] = c.r[5] & 0xFFu;  // 0602CBE2 extu.b r5,r5
    c.r[9] = ld32(0x0602CE38u);  // 0602CBE4 mov.l 0x0602CE38,r9
    c.r[8] = c.r[5];  // 0602CBE6 mov r5,r8
    c.r[8] += c.r[8];  // 0602CBE8 add r8,r8
    c.r[8] += c.r[5];  // 0602CBEA add r5,r8
    c.r[8] <<= 2;  // 0602CBEC shll2 r8
    c.r[1] = ld32(c.r[9]);  // 0602CBEE mov.l @r9,r1
    c.r[0] = c.r[8];  // 0602CBF0 mov r8,r0
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0602CBF2 mov.w @(r0,r1),r2
    c.r[11] = c.r[4];  // 0602CBF4 mov r4,r11
    st16(c.r[11], c.r[2]);  // 0602CBF6 mov.w r2,@r11
    c.r[1] = ld32(0x0602CE3Cu);  // 0602CBF8 mov.l 0x0602CE3C,r1
    c.r[1] = ld32(c.r[1]);  // 0602CBFA mov.l @r1,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0602CBFC mov.w @r1,r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 0602CBFE extu.w r2,r2
    c.r[4] = c.r[1] & 0xFFFFu;  // 0602CC00 extu.w r1,r4
    c.t = c.r[4] == c.r[2];  // 0602CC02 cmp/eq r2,r4
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0602CC0E; } }  // 0602CC04 bf/s 0x0602CC0E ; mov r15,r14
    c.r[1] = ld32(0x0602CE40u);  // 0602CC08 mov.l 0x0602CE40,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602CC0Eu; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602CC0Eu) return; }  // 0602CC0A jsr @r1 ; mov #0,r5
L_0602CC0E:
    c.r[10] = c.r[11];  // 0602CC0E mov r11,r10
    c.r[1] = ld32(c.r[9]);  // 0602CC10 mov.l @r9,r1
    c.r[10] += 2;  // 0602CC12 add #2,r10
    c.r[1] += c.r[8];  // 0602CC14 add r8,r1
    c.r[1] += 2;  // 0602CC16 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602CC18 mov.b @r1,r1
    c.r[2] = c.r[11];  // 0602CC1A mov r11,r2
    st8(c.r[10], c.r[1]);  // 0602CC1C mov.b r1,@r10
    c.r[1] = ld32(c.r[9]);  // 0602CC1E mov.l @r9,r1
    c.r[2] += 3;  // 0602CC20 add #3,r2
    c.r[1] += c.r[8];  // 0602CC22 add r8,r1
    c.r[1] += 3;  // 0602CC24 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602CC26 mov.b @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602CE22u);  // 0602CC28 mov.w 0x0602CE22,r0
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602CC2A mov.b @r2,r3
    c.r[1] &= c.r[0];  // 0602CC2C and r0,r1
    c.r[0] = 0x3Fu;  // 0602CC2E mov #63,r0
    c.r[3] &= c.r[0];  // 0602CC30 and r0,r3
    c.r[3] |= c.r[1];  // 0602CC32 or r1,r3
    st8(c.r[2], c.r[3]);  // 0602CC34 mov.b r3,@r2
    c.r[1] = ld32(c.r[9]);  // 0602CC36 mov.l @r9,r1
    c.r[4] = ld32(0x0602CE44u);  // 0602CC38 mov.l 0x0602CE44,r4
    c.r[1] += c.r[8];  // 0602CC3A add r8,r1
    c.r[1] += 3;  // 0602CC3C add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602CC3E mov.b @r1,r1
    c.r[0] = 0x30u;  // 0602CC40 mov #48,r0
    c.r[1] &= c.r[0];  // 0602CC42 and r0,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602CE24u);  // 0602CC44 mov.w 0x0602CE24,r0
    c.r[3] &= c.r[0];  // 0602CC46 and r0,r3
    c.r[3] |= c.r[1];  // 0602CC48 or r1,r3
    st8(c.r[2], c.r[3]);  // 0602CC4A mov.b r3,@r2
    c.r[1] = ld32(c.r[9]);  // 0602CC4C mov.l @r9,r1
    c.r[5] = 0x1Cu;  // 0602CC4E mov #28,r5
    c.r[1] += c.r[8];  // 0602CC50 add r8,r1
    c.r[1] += 3;  // 0602CC52 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602CC54 mov.b @r1,r1
    c.r[0] = 0x8u;  // 0602CC56 mov #8,r0
    c.r[1] &= c.r[0];  // 0602CC58 and r0,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602CE26u);  // 0602CC5A mov.w 0x0602CE26,r0
    c.r[3] &= c.r[0];  // 0602CC5C and r0,r3
    c.r[3] |= c.r[1];  // 0602CC5E or r1,r3
    st8(c.r[2], c.r[3]);  // 0602CC60 mov.b r3,@r2
    c.r[2] = ld32(c.r[9]);  // 0602CC62 mov.l @r9,r2
    c.r[3] = c.r[11];  // 0602CC64 mov r11,r3
    c.r[2] += c.r[8];  // 0602CC66 add r8,r2
    c.r[1] = c.r[2];  // 0602CC68 mov r2,r1
    c.r[1] += 4;  // 0602CC6A add #4,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0602CC6C mov.w @r1,r1
    c.r[3] += 4;  // 0602CC6E add #4,r3
    st16(c.r[3], c.r[1]);  // 0602CC70 mov.w r1,@r3
    c.r[3] = c.r[11];  // 0602CC72 mov r11,r3
    c.r[3] += 6;  // 0602CC74 add #6,r3
    c.r[1] = c.r[2];  // 0602CC76 mov r2,r1
    c.r[1] += 6;  // 0602CC78 add #6,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0602CC7A mov.w @r1,r1
    c.r[2] += 8;  // 0602CC7C add #8,r2
    st16(c.r[3], c.r[1]);  // 0602CC7E mov.w r1,@r3
    c.r[3] = c.r[11];  // 0602CC80 mov r11,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602CC82 mov.b @r2,r1
    c.r[3] += 8;  // 0602CC84 add #8,r3
    st8(c.r[3], c.r[1]);  // 0602CC86 mov.b r1,@r3
    c.r[1] = ld32(c.r[9]);  // 0602CC88 mov.l @r9,r1
    c.r[2] = c.r[11];  // 0602CC8A mov r11,r2
    c.r[1] += c.r[8];  // 0602CC8C add r8,r1
    c.r[1] += 9;  // 0602CC8E add #9,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602CC90 mov.b @r1,r1
    c.r[2] += 9;  // 0602CC92 add #9,r2
    st8(c.r[2], c.r[1]);  // 0602CC94 mov.b r1,@r2
    c.r[1] = ld32(c.r[9]);  // 0602CC96 mov.l @r9,r1
    c.r[2] = c.r[11];  // 0602CC98 mov r11,r2
    c.r[8] += c.r[1];  // 0602CC9A add r1,r8
    c.r[8] += 10;  // 0602CC9C add #10,r8
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[8]);  // 0602CC9E mov.w @r8,r1
    c.r[2] += 10;  // 0602CCA0 add #10,r2
    st16(c.r[2], c.r[1]);  // 0602CCA2 mov.w r1,@r2
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[11]);  // 0602CCA4 mov.w @r11,r8
    c.r[9] = ld32(0x0602CE48u);  // 0602CCA6 mov.l 0x0602CE48,r9
    { const uint32_t x = c.r[9]; c.pr = 0x0602CCACu; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602CCACu) return; }  // 0602CCA8 jsr @r9 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 0602CCAC mov r0,r1
    c.r[5] = c.r[8];  // 0602CCAE mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0602CCB4u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602CCB4u) return; }  // 0602CCB0 jsr @r9 ; mov r1,r4
    c.r[12] = c.r[0];  // 0602CCB4 mov r0,r12
    c.r[3] = c.r[12];  // 0602CCB6 mov r12,r3
    c.r[3] += 3;  // 0602CCB8 add #3,r3
    c.r[0] = 0xFu;  // 0602CCBA mov #15,r0
    c.r[2] = c.r[11];  // 0602CCBC mov r11,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0602CCBE mov.b @r3,r1
    c.r[2] += 34;  // 0602CCC0 add #34,r2
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602CCC2 mov.b @r2,r7
    c.r[1] &= c.r[0];  // 0602CCC4 and r0,r1
    c.r[1] <<= 2;  // 0602CCC6 shll2 r1
    c.r[1] <<= 2;  // 0602CCC8 shll2 r1
    c.r[7] &= c.r[0];  // 0602CCCA and r0,r7
    c.r[7] |= c.r[1];  // 0602CCCC or r1,r7
    st8(c.r[2], c.r[7]);  // 0602CCCE mov.b r7,@r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0602CCD0 mov.b @r3,r1
    c.r[0] = 0x30u;  // 0602CCD2 mov #48,r0
    c.r[1] &= c.r[0];  // 0602CCD4 and r0,r1
    c.r[1] >>= 2;  // 0602CCD6 shlr2 r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602CE28u);  // 0602CCD8 mov.w 0x0602CE28,r0
    c.r[7] &= c.r[0];  // 0602CCDA and r0,r7
    c.r[7] |= c.r[1];  // 0602CCDC or r1,r7
    st8(c.r[2], c.r[7]);  // 0602CCDE mov.b r7,@r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0602CCE0 mov.b @r3,r1
    c.r[0] = 0x2u;  // 0602CCE2 mov #2,r0
    c.r[1] >>= 2;  // 0602CCE4 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0602CCE6 shlr r1
    c.r[1] >>= 2;  // 0602CCE8 shlr2 r1
    c.r[1] &= c.r[0];  // 0602CCEA and r0,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602CE2Au);  // 0602CCEC mov.w 0x0602CE2A,r0
    c.r[7] &= c.r[0];  // 0602CCEE and r0,r7
    c.r[7] |= c.r[1];  // 0602CCF0 or r1,r7
    st8(c.r[2], c.r[7]);  // 0602CCF2 mov.b r7,@r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0602CCF4 mov.b @r3,r1
    c.r[0] = 0x1u;  // 0602CCF6 mov #1,r0
    c.r[1] >>= 2;  // 0602CCF8 shlr2 r1
    c.r[1] >>= 2;  // 0602CCFA shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0602CCFC shlr r1
    c.r[1] >>= 2;  // 0602CCFE shlr2 r1
    c.r[1] &= c.r[0];  // 0602CD00 and r0,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602CE2Cu);  // 0602CD02 mov.w 0x0602CE2C,r0
    c.r[7] &= c.r[0];  // 0602CD04 and r0,r7
    c.r[7] |= c.r[1];  // 0602CD06 or r1,r7
    st8(c.r[2], c.r[7]);  // 0602CD08 mov.b r7,@r2
    c.r[2] = c.r[11];  // 0602CD0A mov r11,r2
    c.r[2] += 35;  // 0602CD0C add #35,r2
    c.r[1] = c.r[12];  // 0602CD0E mov r12,r1
    c.r[1] += 2;  // 0602CD10 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602CD12 mov.b @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602CE2Eu);  // 0602CD14 mov.w 0x0602CE2E,r0
    st8(c.r[2], c.r[1]);  // 0602CD16 mov.b r1,@r2
    c.r[2] = c.r[12];  // 0602CD18 mov r12,r2
    c.r[2] += 5;  // 0602CD1A add #5,r2
    c.r[1] = c.r[11];  // 0602CD1C mov r11,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602CD1E mov.b @r2,r3
    c.r[1] += 36;  // 0602CD20 add #36,r1
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602CD22 mov.b @r1,r7
    c.r[3] &= c.r[0];  // 0602CD24 and r0,r3
    c.r[0] = 0xFu;  // 0602CD26 mov #15,r0
    c.r[7] &= c.r[0];  // 0602CD28 and r0,r7
    c.r[7] |= c.r[3];  // 0602CD2A or r3,r7
    st8(c.r[1], c.r[7]);  // 0602CD2C mov.b r7,@r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602CD2E mov.b @r2,r2
    c.r[2] &= c.r[0];  // 0602CD30 and r0,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602CE2Eu);  // 0602CD32 mov.w 0x0602CE2E,r0
    c.r[7] &= c.r[0];  // 0602CD34 and r0,r7
    c.r[7] |= c.r[2];  // 0602CD36 or r2,r7
    st8(c.r[1], c.r[7]);  // 0602CD38 mov.b r7,@r1
    c.r[2] = c.r[12];  // 0602CD3A mov r12,r2
    c.r[2] += 6;  // 0602CD3C add #6,r2
    c.r[1] = c.r[11];  // 0602CD3E mov r11,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602CD40 mov.b @r2,r3
    c.r[1] += 37;  // 0602CD42 add #37,r1
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602CD44 mov.b @r1,r7
    c.r[3] &= c.r[0];  // 0602CD46 and r0,r3
    c.r[0] = 0xFu;  // 0602CD48 mov #15,r0
    c.r[7] &= c.r[0];  // 0602CD4A and r0,r7
    c.r[7] |= c.r[3];  // 0602CD4C or r3,r7
    st8(c.r[1], c.r[7]);  // 0602CD4E mov.b r7,@r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602CD50 mov.b @r2,r2
    c.r[6] = 0x1Fu;  // 0602CD52 mov #31,r6
    c.r[2] &= c.r[0];  // 0602CD54 and r0,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602CE2Eu);  // 0602CD56 mov.w 0x0602CE2E,r0
    c.r[7] &= c.r[0];  // 0602CD58 and r0,r7
    c.r[7] |= c.r[2];  // 0602CD5A or r2,r7
    st8(c.r[1], c.r[7]);  // 0602CD5C mov.b r7,@r1
    c.r[2] = c.r[12];  // 0602CD5E mov r12,r2
    c.r[2] += 7;  // 0602CD60 add #7,r2
    c.r[1] = c.r[11];  // 0602CD62 mov r11,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602CD64 mov.b @r2,r3
    c.r[1] += 38;  // 0602CD66 add #38,r1
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602CD68 mov.b @r1,r7
    c.r[3] &= c.r[0];  // 0602CD6A and r0,r3
    c.r[0] = 0xFu;  // 0602CD6C mov #15,r0
    c.r[7] &= c.r[0];  // 0602CD6E and r0,r7
    c.r[7] |= c.r[3];  // 0602CD70 or r3,r7
    st8(c.r[1], c.r[7]);  // 0602CD72 mov.b r7,@r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602CD74 mov.b @r2,r2
    c.r[5] = c.r[12];  // 0602CD76 mov r12,r5
    c.r[2] &= c.r[0];  // 0602CD78 and r0,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602CE2Eu);  // 0602CD7A mov.w 0x0602CE2E,r0
    c.r[7] &= c.r[0];  // 0602CD7C and r0,r7
    c.r[7] |= c.r[2];  // 0602CD7E or r2,r7
    st8(c.r[1], c.r[7]);  // 0602CD80 mov.b r7,@r1
    c.r[2] = c.r[12];  // 0602CD82 mov r12,r2
    c.r[2] += 8;  // 0602CD84 add #8,r2
    c.r[1] = c.r[11];  // 0602CD86 mov r11,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602CD88 mov.b @r2,r3
    c.r[1] += 39;  // 0602CD8A add #39,r1
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602CD8C mov.b @r1,r7
    c.r[3] &= c.r[0];  // 0602CD8E and r0,r3
    c.r[0] = 0xFu;  // 0602CD90 mov #15,r0
    c.r[7] &= c.r[0];  // 0602CD92 and r0,r7
    c.r[7] |= c.r[3];  // 0602CD94 or r3,r7
    st8(c.r[1], c.r[7]);  // 0602CD96 mov.b r7,@r1
    c.r[3] = c.r[11];  // 0602CD98 mov r11,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602CD9A mov.b @r2,r2
    c.r[3] += 40;  // 0602CD9C add #40,r3
    c.r[2] &= c.r[0];  // 0602CD9E and r0,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602CE2Eu);  // 0602CDA0 mov.w 0x0602CE2E,r0
    c.r[7] &= c.r[0];  // 0602CDA2 and r0,r7
    c.r[7] |= c.r[2];  // 0602CDA4 or r2,r7
    st8(c.r[1], c.r[7]);  // 0602CDA6 mov.b r7,@r1
    c.r[2] = c.r[12];  // 0602CDA8 mov r12,r2
    c.r[2] += 9;  // 0602CDAA add #9,r2
    c.r[7] = c.r[12];  // 0602CDAC mov r12,r7
    c.r[7] += 10;  // 0602CDAE add #10,r7
    c.r[1] = ld32(0x0602CE4Cu);  // 0602CDB0 mov.l 0x0602CE4C,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602CDB2 mov.b @r2,r4
    c.r[4] = c.r[4] & 0xFFu;  // 0602CDB4 extu.b r4,r4
    c.r[4] <<= 8;  // 0602CDB6 shll8 r4
    c.r[4] &= c.r[1];  // 0602CDB8 and r1,r4
    c.r[1] = ld32(0x0602CE50u);  // 0602CDBA mov.l 0x0602CE50,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602CDC0u; c.r[0] = 0x7u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602CDC0u) return; }  // 0602CDBC jsr @r1 ; mov #7,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0602CDC0 mov.b @r3,r1
    c.r[4] <<= 2;  // 0602CDC2 shll2 r4
    c.r[4] += c.r[4];  // 0602CDC4 add r4,r4
    c.r[4] <<= 2;  // 0602CDC6 shll2 r4
    c.r[6] &= c.r[1];  // 0602CDC8 and r1,r6
    c.r[6] |= c.r[4];  // 0602CDCA or r4,r6
    st8(c.r[3], c.r[6]);  // 0602CDCC mov.b r6,@r3
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602CDCE mov.b @r2,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602CE30u);  // 0602CDD0 mov.w 0x0602CE30,r1
    c.r[4] = c.r[4] & 0xFFu;  // 0602CDD2 extu.b r4,r4
    c.r[4] <<= 8;  // 0602CDD4 shll8 r4
    c.r[4] &= c.r[1];  // 0602CDD6 and r1,r4
    c.r[1] = ld32(0x0602CE54u);  // 0602CDD8 mov.l 0x0602CE54,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602CDDEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602CDDEu) return; }  // 0602CDDA jsr @r1 ; nop
    c.r[1] = c.r[4];  // 0602CDDE mov r4,r1
    c.r[1] &= c.r[0];  // 0602CDE0 and r0,r1
    c.r[1] <<= 2;  // 0602CDE2 shll2 r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602CE32u);  // 0602CDE4 mov.w 0x0602CE32,r0
    c.r[6] &= c.r[0];  // 0602CDE6 and r0,r6
    c.r[6] |= c.r[1];  // 0602CDE8 or r1,r6
    st8(c.r[3], c.r[6]);  // 0602CDEA mov.b r6,@r3
    c.r[0] = 0x7u;  // 0602CDEC mov #7,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0602CDEE mov.b @r7,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0602CE34u);  // 0602CDF0 mov.w 0x0602CE34,r2
    c.r[6] = c.r[1];  // 0602CDF2 mov r1,r6
    c.r[6] >>= 2;  // 0602CDF4 shlr2 r6
    c.r[6] >>= 2;  // 0602CDF6 shlr2 r6
    c.r[6] &= c.r[0];  // 0602CDF8 and r0,r6
    c.r[6] <<= 2;  // 0602CDFA shll2 r6
    c.r[6] <<= 2;  // 0602CDFC shll2 r6
    c.r[6] += c.r[6];  // 0602CDFE add r6,r6
    c.r[6] <<= 2;  // 0602CE00 shll2 r6
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0602CE02 mov.w @r3,r1
    c.r[0] = 0xFu;  // 0602CE04 mov #15,r0
    c.r[1] &= c.r[2];  // 0602CE06 and r2,r1
    c.r[1] |= c.r[6];  // 0602CE08 or r6,r1
    st16(c.r[3], c.r[1]);  // 0602CE0A mov.w r1,@r3
    c.r[2] = c.r[11];  // 0602CE0C mov r11,r2
    c.r[2] += 41;  // 0602CE0E add #41,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0602CE36u);  // 0602CE10 mov.w 0x0602CE36,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0602CE12 mov.b @r7,r1
    c.r[6] = c.r[12];  // 0602CE14 mov r12,r6
    c.r[7] = 0x7u;  // 0602CE16 mov #7,r7
    c.r[7] &= c.r[1];  // 0602CE18 and r1,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602CE1A mov.b @r2,r1
    c.r[7] <<= 2;  // 0602CE1C shll2 r7
    c.r[7] <<= 2; goto L_0602CE58;  // 0602CE1E bra 0x0602CE58 ; shll2 r7
L_0602CE58:
    c.r[3] &= c.r[1];  // 0602CE58 and r1,r3
    c.r[3] |= c.r[7];  // 0602CE5A or r7,r3
    st8(c.r[2], c.r[3]);  // 0602CE5C mov.b r3,@r2
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[6]); c.r[6] += 1;  // 0602CE5E mov.b @r6+,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602CF90u);  // 0602CE60 mov.w 0x0602CF90,r1
    c.r[4] = c.r[4] & 0xFFu;  // 0602CE62 extu.b r4,r4
    c.r[4] <<= 8;  // 0602CE64 shll8 r4
    c.r[4] &= c.r[1];  // 0602CE66 and r1,r4
    c.r[1] = ld32(0x0602CFA0u);  // 0602CE68 mov.l 0x0602CFA0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602CE6Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602CE6Eu) return; }  // 0602CE6A jsr @r1 ; nop
    c.r[1] = c.r[4];  // 0602CE6E mov r4,r1
    c.r[7] = c.r[1];  // 0602CE70 mov r1,r7
    c.t = c.r[7] & 1; c.r[7] >>= 1;  // 0602CE72 shlr r7
    c.r[7] &= c.r[0];  // 0602CE74 and r0,r7
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602CF92u);  // 0602CE76 mov.w 0x0602CF92,r0
    c.r[3] &= c.r[0];  // 0602CE78 and r0,r3
    c.r[3] |= c.r[7];  // 0602CE7A or r7,r3
    st8(c.r[2], c.r[3]);  // 0602CE7C mov.b r3,@r2
    c.r[0] = 0x1u;  // 0602CE7E mov #1,r0
    c.r[1] &= c.r[0];  // 0602CE80 and r0,r1
    c.r[7] = c.r[11];  // 0602CE82 mov r11,r7
    c.r[7] += 42;  // 0602CE84 add #42,r7
    c.r[1] <<= 2;  // 0602CE86 shll2 r1
    c.r[1] <<= 2;  // 0602CE88 shll2 r1
    c.r[1] += c.r[1];  // 0602CE8A add r1,r1
    c.r[1] <<= 2;  // 0602CE8C shll2 r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0602CE8E mov.b @r7,r2
    c.r[0] = 0x7Fu;  // 0602CE90 mov #127,r0
    c.r[2] &= c.r[0];  // 0602CE92 and r0,r2
    c.r[2] |= c.r[1];  // 0602CE94 or r1,r2
    st8(c.r[7], c.r[2]);  // 0602CE96 mov.b r2,@r7
    c.r[2] = (uint32_t)(int16_t)ld16(0x0602CF94u);  // 0602CE98 mov.w 0x0602CF94,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[12]);  // 0602CE9A mov.b @r12,r3
    c.r[0] = ld32(0x0602CFA4u);  // 0602CE9C mov.l 0x0602CFA4,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0602CE9E mov.b @r6,r1
    c.r[3] = c.r[3] & 0xFFu;  // 0602CEA0 extu.b r3,r3
    c.r[3] <<= 8;  // 0602CEA2 shll8 r3
    c.r[1] = c.r[1] & 0xFFu;  // 0602CEA4 extu.b r1,r1
    c.r[3] |= c.r[1];  // 0602CEA6 or r1,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602CF96u);  // 0602CEA8 mov.w 0x0602CF96,r1
    c.r[3] &= c.r[1];  // 0602CEAA and r1,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[7]);  // 0602CEAC mov.w @r7,r1
    c.r[3] <<= 2;  // 0602CEAE shll2 r3
    c.r[3] <<= 2;  // 0602CEB0 shll2 r3
    c.r[3] <<= 2;  // 0602CEB2 shll2 r3
    c.r[1] &= c.r[2];  // 0602CEB4 and r2,r1
    c.r[1] |= c.r[3];  // 0602CEB6 or r3,r1
    st16(c.r[7], c.r[1]);  // 0602CEB8 mov.w r1,@r7
    c.r[2] = c.r[11];  // 0602CEBA mov r11,r2
    c.r[1] = c.r[12];  // 0602CEBC mov r12,r1
    c.r[1] += 4;  // 0602CEBE add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602CEC0 mov.b @r1,r1
    c.r[2] += 44;  // 0602CEC2 add #44,r2
    st8(c.r[2], c.r[1]);  // 0602CEC4 mov.b r1,@r2
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0602CEC6 mov.b @r10,r4
    c.r[6] = 0x6u;  // 0602CEC8 mov #6,r6
    { const uint32_t x = c.r[0]; c.pr = 0x0602CECEu; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602CECEu) return; }  // 0602CECA jsr @r0 ; extu.b r4,r4
    c.r[1] = c.r[12];  // 0602CECE mov r12,r1
    c.r[1] += 17;  // 0602CED0 add #17,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602CED2 mov.b @r1,r1
    c.r[3] = c.r[0];  // 0602CED4 mov r0,r3
    c.r[2] = c.r[1] & 0xFFu;  // 0602CED6 extu.b r1,r2
    c.r[1] = c.r[12];  // 0602CED8 mov r12,r1
    c.r[1] += 18;  // 0602CEDA add #18,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602CEDC mov.b @r1,r1
    c.r[2] <<= 8;  // 0602CEDE shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0602CEE0 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0602CEE2 or r1,r2
    c.r[1] = c.r[3] & 0xFFFFu;  // 0602CEE4 extu.w r3,r1
    c.r[2] += c.r[1];  // 0602CEE6 add r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602CF98u);  // 0602CEE8 mov.w 0x0602CF98,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0602CEEA cmp/gt r1,r2
    { const bool k = c.t; c.r[1] = c.r[11]; if (k) { goto L_0602CEF6; } }  // 0602CEEC bt/s 0x0602CEF6 ; mov r11,r1
    c.r[1] += 12;  // 0602CEF0 add #12,r1
    st16(c.r[1], c.r[2]); goto L_0602CEFE;  // 0602CEF2 bra 0x0602CEFE ; mov.w r2,@r1
L_0602CEF6:
    c.r[2] = c.r[11];  // 0602CEF6 mov r11,r2
    c.r[2] += 12;  // 0602CEF8 add #12,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602CF9Au);  // 0602CEFA mov.w 0x0602CF9A,r1
    st16(c.r[2], c.r[1]);  // 0602CEFC mov.w r1,@r2
L_0602CEFE:
    c.r[1] = c.r[11];  // 0602CEFE mov r11,r1
    c.r[1] += 2;  // 0602CF00 add #2,r1
    c.r[0] = ld32(0x0602CFA4u);  // 0602CF02 mov.l 0x0602CFA4,r0
    c.r[6] = 0x0u;  // 0602CF04 mov #0,r6
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602CF06 mov.b @r1,r4
    c.r[5] = c.r[12];  // 0602CF08 mov r12,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0602CF0Eu; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602CF0Eu) return; }  // 0602CF0A jsr @r0 ; extu.b r4,r4
    c.r[1] = c.r[12];  // 0602CF0E mov r12,r1
    c.r[1] += 11;  // 0602CF10 add #11,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602CF12 mov.b @r1,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x0602CF9Cu);  // 0602CF14 mov.w 0x0602CF9C,r3
    c.r[2] = c.r[1] & 0xFFu;  // 0602CF16 extu.b r1,r2
    c.r[1] = c.r[0] & 0xFFFFu;  // 0602CF18 extu.w r0,r1
    c.r[2] += c.r[1];  // 0602CF1A add r1,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[3];  // 0602CF1C cmp/gt r3,r2
    { const bool k = !c.t; c.r[1] = c.r[11]; if (k) { goto L_0602CF28; } }  // 0602CF1E bf/s 0x0602CF28 ; mov r11,r1
    c.r[1] += 14;  // 0602CF22 add #14,r1
    st8(c.r[1], c.r[3]); goto L_0602CF2C;  // 0602CF24 bra 0x0602CF2C ; mov.b r3,@r1
L_0602CF28:
    c.r[1] += 14;  // 0602CF28 add #14,r1
    st8(c.r[1], c.r[2]);  // 0602CF2A mov.b r2,@r1
L_0602CF2C:
    c.r[1] = c.r[11];  // 0602CF2C mov r11,r1
    c.r[1] += 2;  // 0602CF2E add #2,r1
    c.r[0] = ld32(0x0602CFA4u);  // 0602CF30 mov.l 0x0602CFA4,r0
    c.r[6] = 0x1u;  // 0602CF32 mov #1,r6
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602CF34 mov.b @r1,r4
    c.r[5] = c.r[12];  // 0602CF36 mov r12,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0602CF3Cu; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602CF3Cu) return; }  // 0602CF38 jsr @r0 ; extu.b r4,r4
    c.r[1] = c.r[12];  // 0602CF3C mov r12,r1
    c.r[1] += 12;  // 0602CF3E add #12,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602CF40 mov.b @r1,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x0602CF9Cu);  // 0602CF42 mov.w 0x0602CF9C,r3
    c.r[2] = c.r[1] & 0xFFu;  // 0602CF44 extu.b r1,r2
    c.r[1] = c.r[0] & 0xFFFFu;  // 0602CF46 extu.w r0,r1
    c.r[2] += c.r[1];  // 0602CF48 add r1,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[3];  // 0602CF4A cmp/gt r3,r2
    { const bool k = !c.t; c.r[1] = c.r[11]; if (k) { goto L_0602CF56; } }  // 0602CF4C bf/s 0x0602CF56 ; mov r11,r1
    c.r[1] += 15;  // 0602CF50 add #15,r1
    st8(c.r[1], c.r[3]); goto L_0602CF5A;  // 0602CF52 bra 0x0602CF5A ; mov.b r3,@r1
L_0602CF56:
    c.r[1] += 15;  // 0602CF56 add #15,r1
    st8(c.r[1], c.r[2]);  // 0602CF58 mov.b r2,@r1
L_0602CF5A:
    c.r[1] = c.r[11];  // 0602CF5A mov r11,r1
    c.r[1] += 2;  // 0602CF5C add #2,r1
    c.r[0] = ld32(0x0602CFA4u);  // 0602CF5E mov.l 0x0602CFA4,r0
    c.r[6] = 0x2u;  // 0602CF60 mov #2,r6
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602CF62 mov.b @r1,r4
    c.r[5] = c.r[12];  // 0602CF64 mov r12,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0602CF6Au; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602CF6Au) return; }  // 0602CF66 jsr @r0 ; extu.b r4,r4
    c.r[1] = c.r[12];  // 0602CF6A mov r12,r1
    c.r[1] += 13;  // 0602CF6C add #13,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602CF6E mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0602CF70 extu.b r1,r2
    c.r[1] = c.r[12];  // 0602CF72 mov r12,r1
    c.r[1] += 14;  // 0602CF74 add #14,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602CF76 mov.b @r1,r1
    c.r[2] <<= 8;  // 0602CF78 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0602CF7A extu.b r1,r1
    c.r[2] |= c.r[1];  // 0602CF7C or r1,r2
    c.r[1] = c.r[0] & 0xFFFFu;  // 0602CF7E extu.w r0,r1
    c.r[2] += c.r[1];  // 0602CF80 add r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602CF98u);  // 0602CF82 mov.w 0x0602CF98,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0602CF84 cmp/gt r1,r2
    { const bool k = c.t; c.r[1] = c.r[11]; if (k) { goto L_0602CFA8; } }  // 0602CF86 bt/s 0x0602CFA8 ; mov r11,r1
    c.r[1] += 16;  // 0602CF8A add #16,r1
    st16(c.r[1], c.r[2]); goto L_0602CFB0;  // 0602CF8C bra 0x0602CFB0 ; mov.w r2,@r1
L_0602CFA8:
    c.r[2] = c.r[11];  // 0602CFA8 mov r11,r2
    c.r[2] += 16;  // 0602CFAA add #16,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602D0D0u);  // 0602CFAC mov.w 0x0602D0D0,r1
    st16(c.r[2], c.r[1]);  // 0602CFAE mov.w r1,@r2
L_0602CFB0:
    c.r[1] = c.r[11];  // 0602CFB0 mov r11,r1
    c.r[1] += 2;  // 0602CFB2 add #2,r1
    c.r[0] = ld32(0x0602D0D4u);  // 0602CFB4 mov.l 0x0602D0D4,r0
    c.r[6] = 0x4u;  // 0602CFB6 mov #4,r6
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602CFB8 mov.b @r1,r4
    c.r[5] = c.r[12];  // 0602CFBA mov r12,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0602CFC0u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602CFC0u) return; }  // 0602CFBC jsr @r0 ; extu.b r4,r4
    c.r[1] = c.r[12];  // 0602CFC0 mov r12,r1
    c.r[1] += 15;  // 0602CFC2 add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602CFC4 mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0602CFC6 extu.b r1,r2
    c.r[1] = c.r[12];  // 0602CFC8 mov r12,r1
    c.r[1] += 16;  // 0602CFCA add #16,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602CFCC mov.b @r1,r1
    c.r[2] <<= 8;  // 0602CFCE shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0602CFD0 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0602CFD2 or r1,r2
    c.r[1] = c.r[0] & 0xFFFFu;  // 0602CFD4 extu.w r0,r1
    c.r[2] += c.r[1];  // 0602CFD6 add r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602D0D2u);  // 0602CFD8 mov.w 0x0602D0D2,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0602CFDA cmp/gt r1,r2
    { const bool k = c.t; c.r[1] = c.r[11]; if (k) { goto L_0602CFE6; } }  // 0602CFDC bt/s 0x0602CFE6 ; mov r11,r1
    c.r[1] += 20;  // 0602CFE0 add #20,r1
    st16(c.r[1], c.r[2]); goto L_0602CFEE;  // 0602CFE2 bra 0x0602CFEE ; mov.w r2,@r1
L_0602CFE6:
    c.r[2] = c.r[11];  // 0602CFE6 mov r11,r2
    c.r[2] += 20;  // 0602CFE8 add #20,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602D0D0u);  // 0602CFEA mov.w 0x0602D0D0,r1
    st16(c.r[2], c.r[1]);  // 0602CFEC mov.w r1,@r2
L_0602CFEE:
    c.r[1] = c.r[11];  // 0602CFEE mov r11,r1
    c.r[1] += 2;  // 0602CFF0 add #2,r1
    c.r[0] = ld32(0x0602D0D4u);  // 0602CFF2 mov.l 0x0602D0D4,r0
    c.r[6] = 0x3u;  // 0602CFF4 mov #3,r6
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602CFF6 mov.b @r1,r4
    c.r[5] = c.r[12];  // 0602CFF8 mov r12,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0602CFFEu; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602CFFEu) return; }  // 0602CFFA jsr @r0 ; extu.b r4,r4
    c.r[1] = c.r[12];  // 0602CFFE mov r12,r1
    c.r[1] += 19;  // 0602D000 add #19,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602D002 mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0602D004 extu.b r1,r2
    c.r[1] = c.r[12];  // 0602D006 mov r12,r1
    c.r[1] += 20;  // 0602D008 add #20,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602D00A mov.b @r1,r1
    c.r[2] <<= 8;  // 0602D00C shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0602D00E extu.b r1,r1
    c.r[2] |= c.r[1];  // 0602D010 or r1,r2
    c.r[1] = c.r[0] & 0xFFFFu;  // 0602D012 extu.w r0,r1
    c.r[2] += c.r[1];  // 0602D014 add r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602D0D2u);  // 0602D016 mov.w 0x0602D0D2,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0602D018 cmp/gt r1,r2
    { const bool k = c.t; c.r[1] = c.r[11]; if (k) { goto L_0602D024; } }  // 0602D01A bt/s 0x0602D024 ; mov r11,r1
    c.r[1] += 18;  // 0602D01E add #18,r1
    st16(c.r[1], c.r[2]); goto L_0602D02C;  // 0602D020 bra 0x0602D02C ; mov.w r2,@r1
L_0602D024:
    c.r[2] = c.r[11];  // 0602D024 mov r11,r2
    c.r[2] += 18;  // 0602D026 add #18,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602D0D0u);  // 0602D028 mov.w 0x0602D0D0,r1
    st16(c.r[2], c.r[1]);  // 0602D02A mov.w r1,@r2
L_0602D02C:
    c.r[1] = c.r[11];  // 0602D02C mov r11,r1
    c.r[1] += 2;  // 0602D02E add #2,r1
    c.r[0] = ld32(0x0602D0D4u);  // 0602D030 mov.l 0x0602D0D4,r0
    c.r[6] = 0x5u;  // 0602D032 mov #5,r6
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602D034 mov.b @r1,r4
    c.r[5] = c.r[12];  // 0602D036 mov r12,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0602D03Cu; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602D03Cu) return; }  // 0602D038 jsr @r0 ; extu.b r4,r4
    c.r[1] = c.r[12];  // 0602D03C mov r12,r1
    c.r[1] += 21;  // 0602D03E add #21,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602D040 mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0602D042 extu.b r1,r2
    c.r[1] = c.r[12];  // 0602D044 mov r12,r1
    c.r[1] += 22;  // 0602D046 add #22,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602D048 mov.b @r1,r1
    c.r[2] <<= 8;  // 0602D04A shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0602D04C extu.b r1,r1
    c.r[2] |= c.r[1];  // 0602D04E or r1,r2
    c.r[1] = c.r[0] & 0xFFFFu;  // 0602D050 extu.w r0,r1
    c.r[2] += c.r[1];  // 0602D052 add r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602D0D2u);  // 0602D054 mov.w 0x0602D0D2,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0602D056 cmp/gt r1,r2
    { const bool k = c.t; c.r[1] = c.r[11]; if (k) { goto L_0602D062; } }  // 0602D058 bt/s 0x0602D062 ; mov r11,r1
    c.r[1] += 22;  // 0602D05C add #22,r1
    st16(c.r[1], c.r[2]); goto L_0602D06A;  // 0602D05E bra 0x0602D06A ; mov.w r2,@r1
L_0602D062:
    c.r[2] = c.r[11];  // 0602D062 mov r11,r2
    c.r[2] += 22;  // 0602D064 add #22,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602D0D0u);  // 0602D066 mov.w 0x0602D0D0,r1
    st16(c.r[2], c.r[1]);  // 0602D068 mov.w r1,@r2
L_0602D06A:
    c.r[7] = c.r[12];  // 0602D06A mov r12,r7
    c.r[7] += 23;  // 0602D06C add #23,r7
    c.r[1] = c.r[11];  // 0602D06E mov r11,r1
    c.r[1] += 2;  // 0602D070 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602D072 mov.b @r1,r1
    c.r[8] = 0x0u;  // 0602D074 mov #0,r8
    c.r[3] = 0x5u;  // 0602D076 mov #5,r3
    c.r[2] = 0xFFFFFFFFu;  // 0602D078 mov #-1,r2
    c.r[13] = c.r[1] & 0xFFu;  // 0602D07A extu.b r1,r13
L_0602D07C:
    c.r[1] = c.r[11];  // 0602D07C mov r11,r1
    c.r[1] += c.r[8];  // 0602D07E add r8,r1
    c.r[1] += 24;  // 0602D080 add #24,r1
    c.r[8] += 1;  // 0602D082 add #1,r8
    c.t = (int32_t)c.r[8] > (int32_t)c.r[3];  // 0602D084 cmp/gt r3,r8
    { const bool k = !c.t; st8(c.r[1], c.r[2]); if (k) { SH2_POLL(c); goto L_0602D07C; } }  // 0602D086 bf/s 0x0602D07C ; mov.b r2,@r1
    c.r[2] = c.r[11];  // 0602D08A mov r11,r2
    c.r[2] += 24;  // 0602D08C add #24,r2
    c.r[1] = 0x0u;  // 0602D08E mov #0,r1
    st8(c.r[2], c.r[1]);  // 0602D090 mov.b r1,@r2
    c.r[8] = 0x0u;  // 0602D092 mov #0,r8
    c.r[9] = c.r[7];  // 0602D094 mov r7,r9
L_0602D096:
    c.r[1] = c.r[9];  // 0602D096 mov r9,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0602D098 mov.b @r1+,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0602D09A extu.b r2,r2
    c.r[10] = c.r[2];  // 0602D09C mov r2,r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602D09E mov.b @r1,r1
    c.t = (c.r[2] & c.r[2]) == 0;  // 0602D0A0 tst r2,r2
    c.r[3] = c.r[1] & 0xFFu;  // 0602D0A2 extu.b r1,r3
    { const bool k = c.t; c.r[4] = c.r[3]; if (k) { goto L_0602D0FA; } }  // 0602D0A4 bt/s 0x0602D0FA ; mov r3,r4
    c.r[1] = 0x1Fu;  // 0602D0A8 mov #31,r1
    c.t = c.r[2] > c.r[1];  // 0602D0AA cmp/hi r1,r2
    { const bool k = c.t; c.r[1] = 0x5u; if (k) { goto L_0602D0F4; } }  // 0602D0AC bt/s 0x0602D0F4 ; mov #5,r1
    c.r[1] = 0x63u;  // 0602D0B0 mov #99,r1
    c.t = c.r[3] > c.r[1];  // 0602D0B2 cmp/hi r1,r3
    { const bool k = c.t; c.t = c.r[13] >= c.r[3]; if (k) { goto L_0602D0D8; } }  // 0602D0B4 bt/s 0x0602D0D8 ; cmp/hs r3,r13
    { const bool k = !c.t; c.r[1] = c.r[11]; if (k) { goto L_0602D0C4; } }  // 0602D0B8 bf/s 0x0602D0C4 ; mov r11,r1
    c.r[1] += c.r[8];  // 0602D0BC add r8,r1
    c.r[1] += 24;  // 0602D0BE add #24,r1
    st8(c.r[1], c.r[2]); goto L_0602D0F0;  // 0602D0C0 bra 0x0602D0F0 ; mov.b r2,@r1
L_0602D0C4:
    c.r[2] = c.r[11];  // 0602D0C4 mov r11,r2
    c.r[2] += c.r[8];  // 0602D0C6 add r8,r2
    c.r[2] += 24;  // 0602D0C8 add #24,r2
    c.r[1] = 0x0u;  // 0602D0CA mov #0,r1
    st8(c.r[2], c.r[1]); goto L_0602D0F0;  // 0602D0CC bra 0x0602D0F0 ; mov.b r1,@r2
L_0602D0D8:
    c.r[4] -= 100;  // 0602D0D8 add #-100,r4
    c.r[0] = ld32(0x0602D2C4u);  // 0602D0DA mov.l 0x0602D2C4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602D0E0u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602D0E0u) return; }  // 0602D0DC jsr @r0 ; extu.w r4,r4
    c.r[1] = c.r[0] & 0xFFu;  // 0602D0E0 extu.b r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0602D0E2 tst r1,r1
    { const bool k = c.t; c.r[1] = 0x5u; if (k) { goto L_0602D0F4; } }  // 0602D0E4 bt/s 0x0602D0F4 ; mov #5,r1
    c.r[1] = c.r[11];  // 0602D0E8 mov r11,r1
    c.r[1] += c.r[8];  // 0602D0EA add r8,r1
    c.r[1] += 24;  // 0602D0EC add #24,r1
    st8(c.r[1], c.r[10]);  // 0602D0EE mov.b r10,@r1
L_0602D0F0:
    c.r[8] += 1;  // 0602D0F0 add #1,r8
    c.r[1] = 0x5u;  // 0602D0F2 mov #5,r1
L_0602D0F4:
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 0602D0F4 cmp/gt r1,r8
    { const bool k = !c.t; c.r[9] += 2; if (k) { SH2_POLL(c); goto L_0602D096; } }  // 0602D0F6 bf/s 0x0602D096 ; add #2,r9
L_0602D0FA:
    c.r[2] = 0x0u;  // 0602D0FA mov #0,r2
    c.r[7] = 0x3u;  // 0602D0FC mov #3,r7
    c.r[3] = 0x0u;  // 0602D0FE mov #0,r3
L_0602D100:
    c.r[1] = c.r[11];  // 0602D100 mov r11,r1
    c.r[1] += c.r[2];  // 0602D102 add r2,r1
    c.r[1] += 30;  // 0602D104 add #30,r1
    c.r[2] += 1;  // 0602D106 add #1,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[7];  // 0602D108 cmp/gt r7,r2
    { const bool k = !c.t; st8(c.r[1], c.r[3]); if (k) { SH2_POLL(c); goto L_0602D100; } }  // 0602D10A bf/s 0x0602D100 ; mov.b r3,@r1
    c.r[10] = c.r[12];  // 0602D10E mov r12,r10
    c.r[10] += 23;  // 0602D110 add #23,r10
    c.r[13] = ld32(0x0602D2C8u);  // 0602D112 mov.l 0x0602D2C8,r13
    c.r[9] = c.r[12];  // 0602D114 mov r12,r9
    c.r[9] += 24;  // 0602D116 add #24,r9
L_0602D118:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0602D118 mov.b @r9,r1
    c.r[9] += 2;  // 0602D11A add #2,r9
    c.r[3] = c.r[1] & 0xFFu;  // 0602D11C extu.b r1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0602D11E mov.b @r10,r1
    c.r[4] = c.r[3];  // 0602D120 mov r3,r4
    c.r[5] = c.r[1] & 0xFFu;  // 0602D122 extu.b r1,r5
    c.t = (c.r[5] & c.r[5]) == 0;  // 0602D124 tst r5,r5
    { const bool k = c.t; c.r[8] = c.r[5]; if (k) { goto L_0602D166; } }  // 0602D126 bt/s 0x0602D166 ; mov r5,r8
    c.r[1] = c.r[5];  // 0602D12A mov r5,r1
    c.r[1] -= 32;  // 0602D12C add #-32,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602D12E extu.b r1,r1
    c.r[2] = 0x33u;  // 0602D130 mov #51,r2
    c.t = c.r[1] > c.r[2];  // 0602D132 cmp/hi r2,r1
    { const bool k = c.t; c.r[1] = 0x63u; if (k) { goto L_0602D162; } }  // 0602D134 bt/s 0x0602D162 ; mov #99,r1
    c.t = c.r[3] > c.r[1];  // 0602D138 cmp/hi r1,r3
    { const bool k = c.t; c.r[4] -= 100; if (k) { goto L_0602D150; } }  // 0602D13A bt/s 0x0602D150 ; add #-100,r4
    c.r[1] = c.r[11];  // 0602D13E mov r11,r1
    c.r[1] += 2;  // 0602D140 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602D142 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602D144 extu.b r1,r1
    c.t = c.r[1] >= c.r[3];  // 0602D146 cmp/hs r3,r1
    if (c.t) { goto L_0602D15E; }  // 0602D148 bt 0x0602D15E
    c.r[10] += 2;  // 0602D14A add #2,r10
    SH2_POLL(c); goto L_0602D118;  // 0602D14C bra 0x0602D118 ; nop
L_0602D150:
    c.r[0] = ld32(0x0602D2C4u);  // 0602D150 mov.l 0x0602D2C4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602D156u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602D156u) return; }  // 0602D152 jsr @r0 ; extu.w r4,r4
    c.r[1] = c.r[0] & 0xFFu;  // 0602D156 extu.b r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0602D158 tst r1,r1
    { const bool k = c.t; c.r[5] = c.r[8]; if (k) { goto L_0602D162; } }  // 0602D15A bt/s 0x0602D162 ; mov r8,r5
L_0602D15E:
    { const uint32_t x = c.r[13]; c.pr = 0x0602D162u; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602D162u) return; }  // 0602D15E jsr @r13 ; mov r11,r4
L_0602D162:
    c.r[10] += 2; SH2_POLL(c); goto L_0602D118;  // 0602D162 bra 0x0602D118 ; add #2,r10
L_0602D166:
    c.r[9] = 0x0u;  // 0602D166 mov #0,r9
    c.r[8] = c.r[11];  // 0602D168 mov r11,r8
    c.r[8] += 14;  // 0602D16A add #14,r8
    c.r[13] = (uint32_t)(int16_t)ld16(0x0602D2BAu);  // 0602D16C mov.w 0x0602D2BA,r13
    c.r[10] = c.r[11];  // 0602D16E mov r11,r10
    c.r[10] += 16;  // 0602D170 add #16,r10
    c.r[12] = (uint32_t)(int16_t)ld16(0x0602D2BCu);  // 0602D172 mov.w 0x0602D2BC,r12
    c.r[1] = c.r[11];  // 0602D174 mov r11,r1
L_0602D176:
    c.r[1] += c.r[9];  // 0602D176 add r9,r1
    c.r[1] += 30;  // 0602D178 add #30,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602D17A mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0602D17C extu.b r1,r0
    c.t = c.r[0] == 0x4Fu;  // 0602D17E cmp/eq #79,r0
    { const bool k = !c.t; c.r[1] = 0x3u; if (k) { goto L_0602D21A; } }  // 0602D180 bf/s 0x0602D21A ; mov #3,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[11]);  // 0602D184 mov.w @r11,r4
    c.r[0] = ld32(0x0602D2CCu);  // 0602D186 mov.l 0x0602D2CC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602D18Cu; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602D18Cu) return; }  // 0602D188 jsr @r0 ; extu.w r4,r4
    c.r[3] = c.r[0] & 0xFFu;  // 0602D18C extu.b r0,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602D2BEu);  // 0602D18E mov.w 0x0602D2BE,r1
    c.t = c.r[3] == c.r[1];  // 0602D190 cmp/eq r1,r3
    if (c.t) { goto L_0602D222; }  // 0602D192 bt 0x0602D222
    c.r[1] = ld32(0x0602D2D0u);  // 0602D194 mov.l 0x0602D2D0,r1
    c.r[2] = ld32(c.r[1]);  // 0602D196 mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 0602D198 mov #30,r1
    c.macl = c.r[3] * c.r[1];  // 0602D19A mul.l r1,r3
    c.r[0] = c.macl;  // 0602D19C sts macl,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 0602D19E mov.w @(r0,r2),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0602D1A0 extu.w r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0602D2C0u);  // 0602D1A2 mov.w 0x0602D2C0,r2
    c.t = c.r[1] == c.r[2];  // 0602D1A4 cmp/eq r2,r1
    if (!c.t) { goto L_0602D222; }  // 0602D1A6 bf 0x0602D222
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0602D1A8 mov.b @r8,r2
    c.r[1] = c.r[2] & 0xFFu;  // 0602D1AA extu.b r2,r1
    c.r[1] += 10;  // 0602D1AC add #10,r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[13];  // 0602D1AE cmp/gt r13,r1
    { const bool k = c.t; c.r[3] = c.r[11]; if (k) { goto L_0602D1BA; } }  // 0602D1B0 bt/s 0x0602D1BA ; mov r11,r3
    c.r[1] = c.r[2];  // 0602D1B4 mov r2,r1
    c.r[1] += 10;  // 0602D1B6 add #10,r1
    st8(c.r[8], c.r[1]);  // 0602D1B8 mov.b r1,@r8
L_0602D1BA:
    c.r[3] += 15;  // 0602D1BA add #15,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0602D1BC mov.b @r3,r2
    c.r[1] = c.r[2] & 0xFFu;  // 0602D1BE extu.b r2,r1
    c.r[1] += 10;  // 0602D1C0 add #10,r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[13];  // 0602D1C2 cmp/gt r13,r1
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_0602D1CC; } }  // 0602D1C4 bt/s 0x0602D1CC ; mov r2,r1
    c.r[1] += 10;  // 0602D1C8 add #10,r1
    st8(c.r[3], c.r[1]);  // 0602D1CA mov.b r1,@r3
L_0602D1CC:
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[10]);  // 0602D1CC mov.w @r10,r2
    c.r[1] = c.r[2] & 0xFFFFu;  // 0602D1CE extu.w r2,r1
    c.r[1] += 10;  // 0602D1D0 add #10,r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[12];  // 0602D1D2 cmp/gt r12,r1
    { const bool k = c.t; c.r[3] = c.r[11]; if (k) { goto L_0602D1DE; } }  // 0602D1D4 bt/s 0x0602D1DE ; mov r11,r3
    c.r[1] = c.r[2];  // 0602D1D8 mov r2,r1
    c.r[1] += 10;  // 0602D1DA add #10,r1
    st16(c.r[10], c.r[1]);  // 0602D1DC mov.w r1,@r10
L_0602D1DE:
    c.r[3] += 20;  // 0602D1DE add #20,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0602D1E0 mov.w @r3,r2
    c.r[1] = c.r[2] & 0xFFFFu;  // 0602D1E2 extu.w r2,r1
    c.r[1] += 10;  // 0602D1E4 add #10,r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[12];  // 0602D1E6 cmp/gt r12,r1
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_0602D1F0; } }  // 0602D1E8 bt/s 0x0602D1F0 ; mov r2,r1
    c.r[1] += 10;  // 0602D1EC add #10,r1
    st16(c.r[3], c.r[1]);  // 0602D1EE mov.w r1,@r3
L_0602D1F0:
    c.r[3] = c.r[11];  // 0602D1F0 mov r11,r3
    c.r[3] += 22;  // 0602D1F2 add #22,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0602D1F4 mov.w @r3,r2
    c.r[1] = c.r[2] & 0xFFFFu;  // 0602D1F6 extu.w r2,r1
    c.r[1] += 10;  // 0602D1F8 add #10,r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[12];  // 0602D1FA cmp/gt r12,r1
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_0602D204; } }  // 0602D1FC bt/s 0x0602D204 ; mov r2,r1
    c.r[1] += 10;  // 0602D200 add #10,r1
    st16(c.r[3], c.r[1]);  // 0602D202 mov.w r1,@r3
L_0602D204:
    c.r[3] = c.r[11];  // 0602D204 mov r11,r3
    c.r[3] += 18;  // 0602D206 add #18,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0602D208 mov.w @r3,r2
    c.r[1] = c.r[2] & 0xFFFFu;  // 0602D20A extu.w r2,r1
    c.r[1] += 10;  // 0602D20C add #10,r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[12];  // 0602D20E cmp/gt r12,r1
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_0602D222; } }  // 0602D210 bt/s 0x0602D222 ; mov r2,r1
    c.r[1] += 10;  // 0602D214 add #10,r1
    st16(c.r[3], c.r[1]); goto L_0602D222;  // 0602D216 bra 0x0602D222 ; mov.w r1,@r3
L_0602D21A:
    c.r[9] += 1;  // 0602D21A add #1,r9
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 0602D21C cmp/gt r1,r9
    { const bool k = !c.t; c.r[1] = c.r[11]; if (k) { SH2_POLL(c); goto L_0602D176; } }  // 0602D21E bf/s 0x0602D176 ; mov r11,r1
L_0602D222:
    c.r[9] = 0x0u;  // 0602D222 mov #0,r9
    c.r[6] = c.r[11];  // 0602D224 mov r11,r6
    c.r[6] += 4;  // 0602D226 add #4,r6
    c.r[7] = c.r[11];  // 0602D228 mov r11,r7
    c.r[7] += 20;  // 0602D22A add #20,r7
    c.r[13] = c.r[11];  // 0602D22C mov r11,r13
    c.r[13] += 16;  // 0602D22E add #16,r13
    c.r[12] = 0x0u;  // 0602D230 mov #0,r12
L_0602D232:
    c.r[1] = c.r[11];  // 0602D232 mov r11,r1
    c.r[1] += c.r[9];  // 0602D234 add r9,r1
    c.r[1] += 30;  // 0602D236 add #30,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602D238 mov.b @r1,r1
    c.r[8] = (uint32_t)(int16_t)ld16(0x0602D2BEu);  // 0602D23A mov.w 0x0602D2BE,r8
    c.r[3] = c.r[1] & 0xFFu;  // 0602D23C extu.b r1,r3
    c.r[1] = 0x30u;  // 0602D23E mov #48,r1
    c.r[2] = c.r[3];  // 0602D240 mov r3,r2
    c.r[2] -= 33;  // 0602D242 add #-33,r2
    c.t = c.r[2] > c.r[1];  // 0602D244 cmp/hi r1,r2
    { const bool k = c.t; c.r[10] = 0x0u; if (k) { goto L_0602D322; } }  // 0602D246 bt/s 0x0602D322 ; mov #0,r10
    c.r[1] = c.r[2];  // 0602D24A mov r2,r1
    c.r[1] += c.r[1];  // 0602D24C add r1,r1
    c.r[0] = 0x0602D258u;  // 0602D24E mova 0x0602D258,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0602D250 mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 0602D252 add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x0602D30Au: goto L_0602D30A; case 0x0602D310u: goto L_0602D310; case 0x0602D316u: goto L_0602D316; case 0x0602D322u: goto L_0602D322; case 0x0602D2D4u: goto L_0602D2D4; default: sh2_call(c, x); return; } }  // 0602D254 jmp @r0 ; nop
L_0602D2D4:
    c.r[1] = c.r[11];  // 0602D2D4 mov r11,r1
    c.r[1] += 2;  // 0602D2D6 add #2,r1
    c.r[4] = c.r[11];  // 0602D2D8 mov r11,r4
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602D2DA mov.b @r1,r5
    c.r[0] = ld32(0x0602D398u);  // 0602D2DC mov.l 0x0602D398,r0
    c.r[5] = c.r[5] & 0xFFu;  // 0602D2DE extu.b r5,r5
    st32(c.r[14], c.r[6]);  // 0602D2E0 mov.l r6,@r14
    { const uint32_t x = c.r[0]; c.pr = 0x0602D2E6u; st32(c.r[14] + 4, c.r[7]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602D2E6u) return; }  // 0602D2E2 jsr @r0 ; mov.l r7,@(4,r14)
    c.r[6] = ld32(c.r[14]);  // 0602D2E6 mov.l @r14,r6
    c.r[3] = c.r[0];  // 0602D2E8 mov r0,r3
    st16(c.r[6], c.r[3]);  // 0602D2EA mov.w r3,@r6
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[6]);  // 0602D2EC mov.w @r6,r2
    c.r[1] = ld32(0x0602D39Cu);  // 0602D2EE mov.l 0x0602D39C,r1
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[2] * (int32_t)c.r[1]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 0602D2F0 dmuls.l r1,r2
    c.r[0] = c.r[3];  // 0602D2F2 mov r3,r0
    c.r[7] = ld32(c.r[14] + 4);  // 0602D2F4 mov.l @(4,r14),r7
    c.r[1] = c.mach;  // 0602D2F6 sts mach,r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0602D2F8 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0602D2FA shar r1
    c.t = c.r[2] >> 31; c.r[2] <<= 1;  // 0602D2FC shll r2
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 0602D2FE subc r2,r2
    c.r[1] -= c.r[2];  // 0602D300 sub r2,r1
    c.r[0] -= c.r[1];  // 0602D302 sub r1,r0
    c.r[1] = c.r[0];  // 0602D304 mov r0,r1
    st16(c.r[6], c.r[1]); goto L_0602D322;  // 0602D306 bra 0x0602D322 ; mov.w r1,@r6
L_0602D30A:
    c.r[3] -= 33;  // 0602D30A add #-33,r3
    c.r[8] = c.r[3] & 0xFFu; goto L_0602D322;  // 0602D30C bra 0x0602D322 ; extu.b r3,r8
L_0602D310:
    c.r[3] -= 42;  // 0602D310 add #-42,r3
    c.r[8] = c.r[3] & 0xFFu; goto L_0602D322;  // 0602D312 bra 0x0602D322 ; extu.b r3,r8
L_0602D316:
    c.r[3] -= 51;  // 0602D316 add #-51,r3
    c.r[1] = c.r[3] & 0xFFu;  // 0602D318 extu.b r3,r1
    c.r[1] <<= 2;  // 0602D31A shll2 r1
    c.r[0] = ld32(0x0602D3A0u);  // 0602D31C mov.l 0x0602D3A0,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0602D31E mov.b @(r0,r1),r1
    c.r[10] = c.r[1] & 0xFFu;  // 0602D320 extu.b r1,r10
L_0602D322:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602D390u);  // 0602D322 mov.w 0x0602D390,r1
    c.t = c.r[8] == c.r[1];  // 0602D324 cmp/eq r1,r8
    { const bool k = c.t; c.r[2] = c.r[8]; if (k) { goto L_0602D340; } }  // 0602D326 bt/s 0x0602D340 ; mov r8,r2
    c.r[1] = ld32(0x0602D3A4u);  // 0602D32A mov.l 0x0602D3A4,r1
    c.r[2] += c.r[2];  // 0602D32C add r2,r2
    c.r[2] += c.r[8];  // 0602D32E add r8,r2
    c.r[2] += c.r[1];  // 0602D330 add r1,r2
    c.r[1] = c.r[2];  // 0602D332 mov r2,r1
    c.r[1] += 2;  // 0602D334 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602D336 mov.b @r1,r1
    c.r[2] += 1;  // 0602D338 add #1,r2
    c.r[10] = c.r[1] & 0xFFu;  // 0602D33A extu.b r1,r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602D33C mov.b @r2,r1
    c.r[12] = c.r[1] & 0xFFu;  // 0602D33E extu.b r1,r12
L_0602D340:
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[7]);  // 0602D340 mov.w @r7,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602D392u);  // 0602D342 mov.w 0x0602D392,r1
    c.r[2] = c.r[3] & 0xFFFFu;  // 0602D344 extu.w r3,r2
    c.r[2] += c.r[10];  // 0602D346 add r10,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0602D348 cmp/gt r1,r2
    { const bool k = c.t; c.r[10] += c.r[3]; if (k) { goto L_0602D352; } }  // 0602D34A bt/s 0x0602D352 ; add r3,r10
    st16(c.r[7], c.r[10]); goto L_0602D356;  // 0602D34E bra 0x0602D356 ; mov.w r10,@r7
L_0602D352:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602D394u);  // 0602D352 mov.w 0x0602D394,r1
    st16(c.r[7], c.r[1]);  // 0602D354 mov.w r1,@r7
L_0602D356:
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[13]);  // 0602D356 mov.w @r13,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602D392u);  // 0602D358 mov.w 0x0602D392,r1
    c.r[2] = c.r[3] & 0xFFFFu;  // 0602D35A extu.w r3,r2
    c.r[2] += c.r[12];  // 0602D35C add r12,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0602D35E cmp/gt r1,r2
    { const bool k = c.t; c.r[12] += c.r[3]; if (k) { goto L_0602D368; } }  // 0602D360 bt/s 0x0602D368 ; add r3,r12
    st16(c.r[13], c.r[12]); goto L_0602D36C;  // 0602D364 bra 0x0602D36C ; mov.w r12,@r13
L_0602D368:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602D394u);  // 0602D368 mov.w 0x0602D394,r1
    st16(c.r[13], c.r[1]);  // 0602D36A mov.w r1,@r13
L_0602D36C:
    c.r[9] += 1;  // 0602D36C add #1,r9
    c.r[1] = 0x3u;  // 0602D36E mov #3,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 0602D370 cmp/gt r1,r9
    { const bool k = c.t; c.r[12] = 0x0u; if (k) { goto L_0602D37A; } }  // 0602D372 bt/s 0x0602D37A ; mov #0,r12
    SH2_POLL(c); goto L_0602D232;  // 0602D376 bra 0x0602D232 ; nop
L_0602D37A:
    c.r[14] += 8;  // 0602D37A add #8,r14
    c.r[15] = c.r[14];  // 0602D37C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602D37E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602D380 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0602D382 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0602D384 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0602D386 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0602D388 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0602D38A mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602D38C rts ; mov.l @r15+,r8
}

void f_0602D3A8(SH2Context& c) {
    ran[630] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602D3A8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602D3AA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0602D3AC mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0602D3AE mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0602D3B0 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0602D3B2 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602D3B4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602D3B6 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0602D3B8 mov r15,r14
    c.r[0] = ld32(0x0602D4C4u);  // 0602D3BA mov.l 0x0602D4C4,r0
    c.r[2] = (uint32_t)(int16_t)ld16(0x0602D4B6u);  // 0602D3BC mov.w 0x0602D4B6,r2
    c.r[8] = (uint32_t)(int16_t)ld16(0x0602D4B8u);  // 0602D3BE mov.w 0x0602D4B8,r8
    c.r[1] = ld32(c.r[0]);  // 0602D3C0 mov.l @r0,r1
    c.r[0] = c.r[1];  // 0602D3C2 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0602D3C4 mov.b @(r0,r2),r1
    c.r[4] = ld32(0x0602D4C8u);  // 0602D3C6 mov.l 0x0602D4C8,r4
    c.r[12] = c.r[1];  // 0602D3C8 mov r1,r12
    c.r[12] >>= 2;  // 0602D3CA shlr2 r12
    c.r[12] >>= 2;  // 0602D3CC shlr2 r12
    c.r[12] >>= 2;  // 0602D3CE shlr2 r12
    c.r[0] = 0x1u;  // 0602D3D0 mov #1,r0
    c.r[12] &= c.r[0];  // 0602D3D2 and r0,r12
    c.r[0] = ld32(0x0602D4CCu);  // 0602D3D4 mov.l 0x0602D4CC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602D3DAu; c.r[5] = 0x1Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602D3DAu) return; }  // 0602D3D6 jsr @r0 ; mov #28,r5
    c.r[1] = c.r[0];  // 0602D3DA mov r0,r1
    c.r[5] = c.r[8];  // 0602D3DC mov r8,r5
    c.r[0] = ld32(0x0602D4CCu);  // 0602D3DE mov.l 0x0602D4CC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602D3E4u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602D3E4u) return; }  // 0602D3E0 jsr @r0 ; mov r1,r4
    c.r[11] = c.r[0];  // 0602D3E4 mov r0,r11
    c.r[0] = ld32(0x0602D4C4u);  // 0602D3E6 mov.l 0x0602D4C4,r0
    c.r[9] = (uint32_t)(int16_t)ld16(0x0602D4BAu);  // 0602D3E8 mov.w 0x0602D4BA,r9
    c.r[2] = 0x1u;  // 0602D3EA mov #1,r2
    c.r[12] += c.r[12];  // 0602D3EC add r12,r12
    c.r[1] = ld32(c.r[0]);  // 0602D3EE mov.l @r0,r1
    c.r[5] = 0x1Cu;  // 0602D3F0 mov #28,r5
    c.r[0] = c.r[1];  // 0602D3F2 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 0602D3F4 mov.b @(r0,r9),r1
    c.r[4] = ld32(0x0602D4C8u);  // 0602D3F6 mov.l 0x0602D4C8,r4
    c.r[2] &= c.r[1];  // 0602D3F8 and r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602D4BCu);  // 0602D3FA mov.w 0x0602D4BC,r1
    c.r[12] += c.r[1];  // 0602D3FC add r1,r12
    c.r[0] = ld32(0x0602D4CCu);  // 0602D3FE mov.l 0x0602D4CC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602D404u; c.r[12] |= c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602D404u) return; }  // 0602D400 jsr @r0 ; or r2,r12
    c.r[1] = c.r[0];  // 0602D404 mov r0,r1
    c.r[5] = c.r[12];  // 0602D406 mov r12,r5
    c.r[0] = ld32(0x0602D4CCu);  // 0602D408 mov.l 0x0602D4CC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602D40Eu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602D40Eu) return; }  // 0602D40A jsr @r0 ; mov r1,r4
    c.r[13] = c.r[0];  // 0602D40E mov r0,r13
    c.r[12] = c.r[11];  // 0602D410 mov r11,r12
    c.r[10] = 0x1u;  // 0602D412 mov #1,r10
    c.r[6] = 0x17u;  // 0602D414 mov #23,r6
    c.r[5] = c.r[13];  // 0602D416 mov r13,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[12]); c.r[12] += 1;  // 0602D418 mov.b @r12+,r1
    c.r[4] = c.r[11];  // 0602D41A mov r11,r4
    c.r[10] &= c.r[1];  // 0602D41C and r1,r10
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[12]);  // 0602D41E mov.b @r12,r8
    c.r[1] = ld32(0x0602D4D0u);  // 0602D420 mov.l 0x0602D4D0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602D426u; c.r[8] = c.r[8] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602D426u) return; }  // 0602D422 jsr @r1 ; extu.b r8,r8
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602D4BEu);  // 0602D426 mov.w 0x0602D4BE,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 0602D428 mov.b @r13,r1
    c.r[5] = 0x1Cu;  // 0602D42A mov #28,r5
    c.r[1] &= c.r[0];  // 0602D42C and r0,r1
    c.r[10] |= c.r[1];  // 0602D42E or r1,r10
    st8(c.r[11], c.r[10]);  // 0602D430 mov.b r10,@r11
    st8(c.r[12], c.r[8]);  // 0602D432 mov.b r8,@r12
    c.r[0] = ld32(0x0602D4C4u);  // 0602D434 mov.l 0x0602D4C4,r0
    c.r[1] = ld32(c.r[0]);  // 0602D436 mov.l @r0,r1
    c.r[4] = ld32(0x0602D4C8u);  // 0602D438 mov.l 0x0602D4C8,r4
    c.r[0] = c.r[1];  // 0602D43A mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 0602D43C mov.b @(r0,r9),r1
    c.r[8] = (uint32_t)(int16_t)ld16(0x0602D4C0u);  // 0602D43E mov.w 0x0602D4C0,r8
    c.r[0] = 0x1u;  // 0602D440 mov #1,r0
    c.r[1] &= c.r[0];  // 0602D442 and r0,r1
    c.r[0] = ld32(0x0602D4CCu);  // 0602D444 mov.l 0x0602D4CC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602D44Au; c.r[8] |= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602D44Au) return; }  // 0602D446 jsr @r0 ; or r1,r8
    c.r[1] = c.r[0];  // 0602D44A mov r0,r1
    c.r[5] = c.r[8];  // 0602D44C mov r8,r5
    c.r[0] = ld32(0x0602D4CCu);  // 0602D44E mov.l 0x0602D4CC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602D454u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602D454u) return; }  // 0602D450 jsr @r0 ; mov r1,r4
    c.r[13] = c.r[0];  // 0602D454 mov r0,r13
    c.r[1] = c.r[13];  // 0602D456 mov r13,r1
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[13]);  // 0602D458 mov.b @r13,r7
    c.r[1] += 1;  // 0602D45A add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602D45C mov.b @r1,r1
    c.r[2] = c.r[7] & 0xFFu;  // 0602D45E extu.b r7,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0602D460 extu.b r1,r1
    c.r[2] += c.r[1];  // 0602D462 add r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0602D464 tst r2,r2
    { const bool k = c.t; c.r[6] = 0x17u; if (k) { goto L_0602D494; } }  // 0602D466 bt/s 0x0602D494 ; mov #23,r6
    c.r[5] = c.r[13];  // 0602D46A mov r13,r5
    c.r[3] = c.r[11];  // 0602D46C mov r11,r3
    c.r[3] += 23;  // 0602D46E add #23,r3
L_0602D470:
    st8(c.r[3], c.r[7]);  // 0602D470 mov.b r7,@r3
    c.r[2] = c.r[3];  // 0602D472 mov r3,r2
    c.r[2] += 1;  // 0602D474 add #1,r2
    c.r[1] = c.r[5];  // 0602D476 mov r5,r1
    c.r[1] += 1;  // 0602D478 add #1,r1
    c.r[3] += 2;  // 0602D47A add #2,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602D47C mov.b @r1,r1
    c.r[5] += 2;  // 0602D47E add #2,r5
    st8(c.r[2], c.r[1]);  // 0602D480 mov.b r1,@r2
    c.r[1] = c.r[5];  // 0602D482 mov r5,r1
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0602D484 mov.b @r1+,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602D486 mov.b @r1,r1
    c.r[2] = c.r[7] & 0xFFu;  // 0602D488 extu.b r7,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0602D48A extu.b r1,r1
    c.r[2] += c.r[1];  // 0602D48C add r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0602D48E tst r2,r2
    { const bool k = !c.t; c.r[6] += 2; if (k) { SH2_POLL(c); goto L_0602D470; } }  // 0602D490 bf/s 0x0602D470 ; add #2,r6
L_0602D494:
    c.r[2] = c.r[6];  // 0602D494 mov r6,r2
    c.r[2] += c.r[11];  // 0602D496 add r11,r2
    c.r[2] += 1;  // 0602D498 add #1,r2
    c.r[1] = 0x0u;  // 0602D49A mov #0,r1
    st8(c.r[2], c.r[1]);  // 0602D49C mov.b r1,@r2
    c.r[0] = c.r[11];  // 0602D49E mov r11,r0
    st8(c.r[0] + c.r[6], c.r[1]);  // 0602D4A0 mov.b r1,@(r0,r6)
    c.r[15] = c.r[14];  // 0602D4A2 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602D4A4 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602D4A6 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0602D4A8 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0602D4AA mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0602D4AC mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0602D4AE mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0602D4B0 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602D4B2 rts ; mov.l @r15+,r8
}

void f_0602D4D4(SH2Context& c) {
    ran[631] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602D4D4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602D4D6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0602D4D8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0602D4DA mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602D4DC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602D4DE sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0602D4E0 mov r15,r14
    c.r[8] = (uint32_t)(int16_t)ld16(0x0602D578u);  // 0602D4E2 mov.w 0x0602D578,r8
    c.r[10] = ld32(0x0602D580u);  // 0602D4E4 mov.l 0x0602D580,r10
    c.r[9] = ld32(0x0602D584u);  // 0602D4E6 mov.l 0x0602D584,r9
    c.r[5] = 0x1Cu;  // 0602D4E8 mov #28,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0602D4EEu; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602D4EEu) return; }  // 0602D4EA jsr @r9 ; mov r10,r4
    c.r[1] = c.r[0];  // 0602D4EE mov r0,r1
    c.r[5] = c.r[8];  // 0602D4F0 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0602D4F6u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602D4F6u) return; }  // 0602D4F2 jsr @r9 ; mov r1,r4
    c.r[11] = c.r[0];  // 0602D4F6 mov r0,r11
    c.r[11] += 23;  // 0602D4F8 add #23,r11
    c.r[1] = ld32(0x0602D588u);  // 0602D4FA mov.l 0x0602D588,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0602D57Au);  // 0602D4FC mov.w 0x0602D57A,r2
    c.r[8] = (uint32_t)(int16_t)ld16(0x0602D57Cu);  // 0602D4FE mov.w 0x0602D57C,r8
    c.r[1] = ld32(c.r[1]);  // 0602D500 mov.l @r1,r1
    c.r[5] = 0x1Cu;  // 0602D502 mov #28,r5
    c.r[0] = c.r[1];  // 0602D504 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0602D506 mov.b @(r0,r2),r1
    c.r[4] = c.r[10];  // 0602D508 mov r10,r4
    c.r[0] = 0x1u;  // 0602D50A mov #1,r0
    c.r[1] &= c.r[0];  // 0602D50C and r0,r1
    { const uint32_t x = c.r[9]; c.pr = 0x0602D512u; c.r[8] |= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602D512u) return; }  // 0602D50E jsr @r9 ; or r1,r8
    c.r[1] = c.r[0];  // 0602D512 mov r0,r1
    c.r[5] = c.r[8];  // 0602D514 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0602D51Au; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602D51Au) return; }  // 0602D516 jsr @r9 ; mov r1,r4
    c.r[3] = c.r[0];  // 0602D51A mov r0,r3
    c.r[6] = 0x0u;  // 0602D51C mov #0,r6
    c.r[1] = c.r[3];  // 0602D51E mov r3,r1
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 0602D520 mov.b @(r0,r6),r7
    c.r[1] += 1;  // 0602D522 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602D524 mov.b @r1,r1
    c.r[2] = c.r[7] & 0xFFu;  // 0602D526 extu.b r7,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0602D528 extu.b r1,r1
    c.r[2] += c.r[1];  // 0602D52A add r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0602D52C tst r2,r2
    { const bool k = c.t; c.r[2] = c.r[6]; if (k) { goto L_0602D55C; } }  // 0602D52E bt/s 0x0602D55C ; mov r6,r2
    c.r[5] = c.r[3];  // 0602D532 mov r3,r5
    c.r[3] = c.r[11];  // 0602D534 mov r11,r3
L_0602D536:
    st8(c.r[3], c.r[7]);  // 0602D536 mov.b r7,@r3
    c.r[2] = c.r[3];  // 0602D538 mov r3,r2
    c.r[2] += 1;  // 0602D53A add #1,r2
    c.r[1] = c.r[5];  // 0602D53C mov r5,r1
    c.r[1] += 1;  // 0602D53E add #1,r1
    c.r[5] += 2;  // 0602D540 add #2,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602D542 mov.b @r1,r1
    c.r[3] += 2;  // 0602D544 add #2,r3
    st8(c.r[2], c.r[1]);  // 0602D546 mov.b r1,@r2
    c.r[1] = c.r[5];  // 0602D548 mov r5,r1
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0602D54A mov.b @r1+,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602D54C mov.b @r1,r1
    c.r[2] = c.r[7] & 0xFFu;  // 0602D54E extu.b r7,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0602D550 extu.b r1,r1
    c.r[2] += c.r[1];  // 0602D552 add r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0602D554 tst r2,r2
    { const bool k = !c.t; c.r[6] += 2; if (k) { SH2_POLL(c); goto L_0602D536; } }  // 0602D556 bf/s 0x0602D536 ; add #2,r6
    c.r[2] = c.r[6];  // 0602D55A mov r6,r2
L_0602D55C:
    c.r[2] += c.r[11];  // 0602D55C add r11,r2
    c.r[2] += 1;  // 0602D55E add #1,r2
    c.r[1] = 0x0u;  // 0602D560 mov #0,r1
    st8(c.r[2], c.r[1]);  // 0602D562 mov.b r1,@r2
    c.r[0] = c.r[11];  // 0602D564 mov r11,r0
    st8(c.r[0] + c.r[6], c.r[1]);  // 0602D566 mov.b r1,@(r0,r6)
    c.r[15] = c.r[14];  // 0602D568 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602D56A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602D56C mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0602D56E mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0602D570 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0602D572 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602D574 rts ; mov.l @r15+,r8
}

void f_0602D58C(SH2Context& c) {
    ran[632] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602D58C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602D58E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0602D590 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0602D592 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0602D594 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0602D596 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602D598 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602D59A sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0602D59C mov r15,r14
    c.r[11] = c.r[4] & 0xFFu;  // 0602D59E extu.b r4,r11
    c.r[9] = c.r[6] & 0xFFu;  // 0602D5A0 extu.b r6,r9
    c.r[13] = 0x1u;  // 0602D5A2 mov #1,r13
    c.t = c.r[11] > c.r[13];  // 0602D5A4 cmp/hi r13,r11
    { const bool k = !c.t; c.r[10] = 0x0u; if (k) { goto L_0602D602; } }  // 0602D5A6 bf/s 0x0602D602 ; mov #0,r10
    c.r[1] = c.r[9];  // 0602D5AA mov r9,r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0602D5AC shlr r1
    c.r[1] += c.r[5];  // 0602D5AE add r5,r1
    c.r[1] += 5;  // 0602D5B0 add #5,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602D5B2 mov.b @r1,r4
    c.r[5] = c.r[9];  // 0602D5B4 mov r9,r5
    c.r[5] += 1;  // 0602D5B6 add #1,r5
    c.r[0] = ld32(0x0602D618u);  // 0602D5B8 mov.l 0x0602D618,r0
    c.r[4] = c.r[4] & 0xFFu;  // 0602D5BA extu.b r4,r4
    c.r[1] = c.r[5];  // 0602D5BC mov r5,r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0602D5BE shlr r1
    c.r[1] += c.r[1];  // 0602D5C0 add r1,r1
    c.r[5] -= c.r[1];  // 0602D5C2 sub r1,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0602D5C8u; c.r[5] <<= 2; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602D5C8u) return; }  // 0602D5C4 jsr @r0 ; shll2 r5
    c.r[12] = c.r[0];  // 0602D5C8 mov r0,r12
    c.r[3] = 0xFu;  // 0602D5CA mov #15,r3
    c.r[12] &= c.r[3];  // 0602D5CC and r3,r12
    c.r[4] = ld32(0x0602D61Cu);  // 0602D5CE mov.l 0x0602D61C,r4
    c.r[8] = ld32(0x0602D620u);  // 0602D5D0 mov.l 0x0602D620,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0602D5D6u; c.r[5] = 0x1Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602D5D6u) return; }  // 0602D5D2 jsr @r8 ; mov #30,r5
    c.r[5] = c.r[13];  // 0602D5D6 mov r13,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0602D5DCu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602D5DCu) return; }  // 0602D5D8 jsr @r8 ; mov r0,r4
    c.r[5] = c.r[9];  // 0602D5DC mov r9,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0602D5E2u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602D5E2u) return; }  // 0602D5DE jsr @r8 ; mov r0,r4
    c.r[5] = c.r[12];  // 0602D5E2 mov r12,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0602D5E8u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602D5E8u) return; }  // 0602D5E4 jsr @r8 ; mov r0,r4
    c.r[2] = 0x2u;  // 0602D5E8 mov #2,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[11];  // 0602D5EA cmp/gt r11,r2
    if (c.t) { goto L_0602D602; }  // 0602D5EC bt 0x0602D602
L_0602D5EE:
    c.r[1] = c.r[2];  // 0602D5EE mov r2,r1
    c.r[1] += c.r[0];  // 0602D5F0 add r0,r1
    c.r[1] -= 2;  // 0602D5F2 add #-2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602D5F4 mov.b @r1,r1
    c.r[2] += 1;  // 0602D5F6 add #1,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[11];  // 0602D5F8 cmp/gt r11,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0602D5FA extu.b r1,r1
    c.r[1] += c.r[10];  // 0602D5FC add r10,r1
    { const bool k = !c.t; c.r[10] = c.r[1] & 0xFFFFu; if (k) { SH2_POLL(c); goto L_0602D5EE; } }  // 0602D5FE bf/s 0x0602D5EE ; extu.w r1,r10
L_0602D602:
    c.r[15] = c.r[14];  // 0602D602 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602D604 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602D606 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0602D608 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0602D60A mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0602D60C mov.l @r15+,r11
    c.r[0] = c.r[10];  // 0602D60E mov r10,r0
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0602D610 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0602D612 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602D614 rts ; mov.l @r15+,r8
}

void f_0602D624(SH2Context& c) {
    ran[633] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602D624 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602D626 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0602D628 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0602D62A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0602D62C mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602D62E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602D630 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0602D632 mov r15,r14
    c.r[4] = c.r[4] & 0xFFFFu;  // 0602D634 extu.w r4,r4
    c.r[0] = ld32(0x0602D72Cu);  // 0602D636 mov.l 0x0602D72C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602D63Cu; c.r[11] = c.r[5] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602D63Cu) return; }  // 0602D638 jsr @r0 ; extu.w r5,r11
    c.r[3] = c.r[0] & 0xFFu;  // 0602D63C extu.b r0,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602D728u);  // 0602D63E mov.w 0x0602D728,r1
    c.t = c.r[3] == c.r[1];  // 0602D640 cmp/eq r1,r3
    { const bool k = c.t; c.r[6] = 0x0u; if (k) { goto L_0602D714; } }  // 0602D642 bt/s 0x0602D714 ; mov #0,r6
    c.r[10] = ld32(0x0602D730u);  // 0602D646 mov.l 0x0602D730,r10
    c.r[12] = c.r[1];  // 0602D648 mov r1,r12
    c.r[4] = c.r[6];  // 0602D64A mov r6,r4
L_0602D64C:
    c.r[4] += c.r[4];  // 0602D64C add r4,r4
    c.r[4] += c.r[6];  // 0602D64E add r6,r4
    c.r[4] <<= 2;  // 0602D650 shll2 r4
    c.r[7] = c.r[4];  // 0602D652 mov r4,r7
    c.r[2] = ld32(c.r[10]);  // 0602D654 mov.l @r10,r2
    c.r[0] = c.r[4];  // 0602D656 mov r4,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 0602D658 mov.w @(r0,r2),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0602D65A extu.w r1,r1
    c.t = c.r[1] == c.r[11];  // 0602D65C cmp/eq r11,r1
    { const bool k = !c.t; c.r[7] += c.r[2]; if (k) { goto L_0602D706; } }  // 0602D65E bf/s 0x0602D706 ; add r2,r7
    c.t = c.r[3] == c.r[6];  // 0602D662 cmp/eq r6,r3
    { const bool k = c.t; c.r[1] = c.r[6]; if (k) { goto L_0602D708; } }  // 0602D664 bt/s 0x0602D708 ; mov r6,r1
    c.r[9] = c.r[7];  // 0602D668 mov r7,r9
    c.r[9] += 3;  // 0602D66A add #3,r9
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0602D66C mov.b @r9,r8
    c.r[0] = c.r[8];  // 0602D66E mov r8,r0
    c.r[0] >>= 2;  // 0602D670 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0602D672 shlr r0
    c.r[0] &= 0x1u;  // 0602D674 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0602D676 tst r0,r0
    { const bool k = c.t; c.r[1] += 1; if (k) { goto L_0602D70A; } }  // 0602D678 bt/s 0x0602D70A ; add #1,r1
    c.r[7] = c.r[3];  // 0602D67C mov r3,r7
    c.r[7] += c.r[7];  // 0602D67E add r7,r7
    c.r[5] = c.r[7];  // 0602D680 mov r7,r5
    c.r[5] += c.r[3];  // 0602D682 add r3,r5
    c.r[5] <<= 2;  // 0602D684 shll2 r5
    c.r[2] += c.r[5];  // 0602D686 add r5,r2
    c.r[1] = c.r[2];  // 0602D688 mov r2,r1
    c.r[1] += 8;  // 0602D68A add #8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602D68C mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602D68E extu.b r1,r1
    c.t = c.r[1] == c.r[6];  // 0602D690 cmp/eq r6,r1
    { const bool k = c.t; c.r[2] += 3; if (k) { goto L_0602D714; } }  // 0602D692 bt/s 0x0602D714 ; add #3,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602D696 mov.b @r2,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602D72Au);  // 0602D698 mov.w 0x0602D72A,r1
    c.r[1] &= c.r[0];  // 0602D69A and r0,r1
    c.r[0] = c.r[8];  // 0602D69C mov r8,r0
    c.r[0] &= 0x3Fu;  // 0602D69E and #63,r0
    c.r[0] |= c.r[1];  // 0602D6A0 or r1,r0
    st8(c.r[9], c.r[0]);  // 0602D6A2 mov.b r0,@r9
    c.r[1] = ld32(c.r[10]);  // 0602D6A4 mov.l @r10,r1
    c.r[2] = c.r[4];  // 0602D6A6 mov r4,r2
    c.r[2] += c.r[1];  // 0602D6A8 add r1,r2
    c.r[1] += c.r[5];  // 0602D6AA add r5,r1
    c.r[1] += 3;  // 0602D6AC add #3,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602D6AE mov.b @r1,r0
    c.r[2] += 3;  // 0602D6B0 add #3,r2
    c.r[1] = 0x30u;  // 0602D6B2 mov #48,r1
    c.r[1] &= c.r[0];  // 0602D6B4 and r0,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602D6B6 mov.b @r2,r0
    c.r[0] &= 0xCFu;  // 0602D6B8 and #207,r0
    c.r[0] |= c.r[1];  // 0602D6BA or r1,r0
    st8(c.r[2], c.r[0]);  // 0602D6BC mov.b r0,@r2
    c.r[2] = ld32(c.r[10]);  // 0602D6BE mov.l @r10,r2
    c.r[5] += c.r[2];  // 0602D6C0 add r2,r5
    c.r[5] += 8;  // 0602D6C2 add #8,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[5]);  // 0602D6C4 mov.b @r5,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602D6C6 extu.b r1,r1
    c.t = c.r[1] == c.r[12];  // 0602D6C8 cmp/eq r12,r1
    { const bool k = c.t; c.r[7] += c.r[3]; if (k) { goto L_0602D6F2; } }  // 0602D6CA bt/s 0x0602D6F2 ; add r3,r7
    c.r[5] = (uint32_t)(int16_t)ld16(0x0602D728u);  // 0602D6CE mov.w 0x0602D728,r5
L_0602D6D0:
    c.r[7] <<= 2;  // 0602D6D0 shll2 r7
    c.r[7] += c.r[2];  // 0602D6D2 add r2,r7
    c.r[7] += 8;  // 0602D6D4 add #8,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0602D6D6 mov.b @r7,r1
    c.r[3] = c.r[1] & 0xFFu;  // 0602D6D8 extu.b r1,r3
    c.r[7] = c.r[3];  // 0602D6DA mov r3,r7
    c.r[7] += c.r[7];  // 0602D6DC add r7,r7
    c.r[1] = c.r[7];  // 0602D6DE mov r7,r1
    c.r[1] += c.r[3];  // 0602D6E0 add r3,r1
    c.r[1] <<= 2;  // 0602D6E2 shll2 r1
    c.r[1] += c.r[2];  // 0602D6E4 add r2,r1
    c.r[1] += 8;  // 0602D6E6 add #8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602D6E8 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602D6EA extu.b r1,r1
    c.t = c.r[1] == c.r[5];  // 0602D6EC cmp/eq r5,r1
    { const bool k = !c.t; c.r[7] += c.r[3]; if (k) { SH2_POLL(c); goto L_0602D6D0; } }  // 0602D6EE bf/s 0x0602D6D0 ; add r3,r7
L_0602D6F2:
    c.r[1] = ld32(c.r[10]);  // 0602D6F2 mov.l @r10,r1
    c.r[2] = c.r[3];  // 0602D6F4 mov r3,r2
    c.r[2] += c.r[2];  // 0602D6F6 add r2,r2
    c.r[2] += c.r[3];  // 0602D6F8 add r3,r2
    c.r[2] <<= 2;  // 0602D6FA shll2 r2
    c.r[0] = c.r[6];  // 0602D6FC mov r6,r0
    c.r[2] += c.r[1];  // 0602D6FE add r1,r2
    c.r[2] += 8;  // 0602D700 add #8,r2
    st8(c.r[2], c.r[6]); goto L_0602D716;  // 0602D702 bra 0x0602D716 ; mov.b r6,@r2
L_0602D706:
    c.r[1] = c.r[6];  // 0602D706 mov r6,r1
L_0602D708:
    c.r[1] += 1;  // 0602D708 add #1,r1
L_0602D70A:
    c.r[6] = c.r[1] & 0xFFu;  // 0602D70A extu.b r1,r6
    c.r[1] = 0x7Fu;  // 0602D70C mov #127,r1
    c.t = c.r[6] > c.r[1];  // 0602D70E cmp/hi r1,r6
    { const bool k = !c.t; c.r[4] = c.r[6]; if (k) { SH2_POLL(c); goto L_0602D64C; } }  // 0602D710 bf/s 0x0602D64C ; mov r6,r4
L_0602D714:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602D728u);  // 0602D714 mov.w 0x0602D728,r0
L_0602D716:
    c.r[15] = c.r[14];  // 0602D716 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602D718 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602D71A mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0602D71C mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0602D71E mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0602D720 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0602D722 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602D724 rts ; mov.l @r15+,r8
}

void f_0602D734(SH2Context& c) {
    ran[634] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602D734 mov.l r14,@-r15
    c.r[2] = c.r[4] & 0xFFu;  // 0602D736 extu.b r4,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602D7ACu);  // 0602D738 mov.w 0x0602D7AC,r1
    c.t = c.r[2] == c.r[1];  // 0602D73A cmp/eq r1,r2
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0602D7A4; } }  // 0602D73C bt/s 0x0602D7A4 ; mov r15,r14
    c.r[1] = ld32(0x0602D7B0u);  // 0602D740 mov.l 0x0602D7B0,r1
    c.r[3] = ld32(c.r[1]);  // 0602D742 mov.l @r1,r3
    c.r[1] = c.r[2];  // 0602D744 mov r2,r1
    c.r[1] += c.r[1];  // 0602D746 add r1,r1
    c.r[1] += c.r[2];  // 0602D748 add r2,r1
    c.r[1] <<= 2;  // 0602D74A shll2 r1
    c.r[1] += c.r[3];  // 0602D74C add r3,r1
    c.r[1] += 3;  // 0602D74E add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602D750 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0602D752 mov r1,r0
    c.r[0] >>= 2;  // 0602D754 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0602D756 shlr r0
    c.r[0] &= 0x1u;  // 0602D758 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0602D75A tst r0,r0
    { const bool k = c.t; c.r[15] = c.r[14]; if (k) { goto L_0602D7A6; } }  // 0602D75C bt/s 0x0602D7A6 ; mov r14,r15
    c.r[7] = 0x7Fu;  // 0602D760 mov #127,r7
    c.r[0] = 0x0u;  // 0602D762 mov #0,r0
L_0602D764:
    c.r[1] = c.r[0];  // 0602D764 mov r0,r1
L_0602D766:
    c.r[1] += c.r[1];  // 0602D766 add r1,r1
    c.r[1] += c.r[0];  // 0602D768 add r0,r1
    c.r[1] <<= 2;  // 0602D76A shll2 r1
    c.r[1] += c.r[3];  // 0602D76C add r3,r1
    c.r[1] += 8;  // 0602D76E add #8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602D770 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602D772 extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 0602D774 cmp/eq r2,r1
    { const bool k = !c.t; c.r[1] = c.r[0]; if (k) { goto L_0602D77E; } }  // 0602D776 bf/s 0x0602D77E ; mov r0,r1
    c.r[2] = c.r[0]; goto L_0602D788;  // 0602D77A bra 0x0602D788 ; mov r0,r2
L_0602D77E:
    c.r[1] += 1;  // 0602D77E add #1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0602D780 extu.b r1,r0
    c.t = c.r[0] > c.r[7];  // 0602D782 cmp/hi r7,r0
    { const bool k = !c.t; c.r[1] = c.r[0]; if (k) { SH2_POLL(c); goto L_0602D766; } }  // 0602D784 bf/s 0x0602D766 ; mov r0,r1
L_0602D788:
    c.r[1] = c.r[2];  // 0602D788 mov r2,r1
    c.r[1] += c.r[1];  // 0602D78A add r1,r1
    c.r[1] += c.r[2];  // 0602D78C add r2,r1
    c.r[1] <<= 2;  // 0602D78E shll2 r1
    c.r[1] += c.r[3];  // 0602D790 add r3,r1
    c.r[1] += 3;  // 0602D792 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602D794 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0602D796 mov r1,r0
    c.r[0] >>= 2;  // 0602D798 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0602D79A shlr r0
    c.r[0] &= 0x1u;  // 0602D79C and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0602D79E tst r0,r0
    { const bool k = !c.t; c.r[0] = 0x0u; if (k) { SH2_POLL(c); goto L_0602D764; } }  // 0602D7A0 bf/s 0x0602D764 ; mov #0,r0
L_0602D7A4:
    c.r[15] = c.r[14];  // 0602D7A4 mov r14,r15
L_0602D7A6:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602D7A6 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[2]; c.pc = x; return; }  // 0602D7A8 rts ; mov r2,r0
}

void f_0602D7B4(SH2Context& c) {
    ran[635] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602D7B4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602D7B6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0602D7B8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0602D7BA mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0602D7BC mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0602D7BE mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602D7C0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602D7C2 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0602D7C4 mov r15,r14
    c.r[8] = c.r[4] & 0xFFFFu;  // 0602D7C6 extu.w r4,r8
    c.r[12] = c.r[5] & 0xFFu;  // 0602D7C8 extu.b r5,r12
    c.r[13] = c.r[6] & 0xFFu;  // 0602D7CA extu.b r6,r13
    c.r[0] = ld32(0x0602D8C8u);  // 0602D7CC mov.l 0x0602D8C8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602D7D2u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602D7D2u) return; }  // 0602D7CE jsr @r0 ; mov #0,r4
    c.r[11] = c.r[0] & 0xFFu;  // 0602D7D2 extu.b r0,r11
    c.r[3] = 0xFFFFFFFFu;  // 0602D7D4 mov #-1,r3
    c.r[1] = c.r[3] & 0xFFu;  // 0602D7D6 extu.b r3,r1
    c.t = c.r[11] == c.r[1];  // 0602D7D8 cmp/eq r1,r11
    { const bool k = c.t; c.r[9] = c.r[11]; if (k) { goto L_0602D8AA; } }  // 0602D7DA bt/s 0x0602D8AA ; mov r11,r9
    c.r[10] = ld32(0x0602D8CCu);  // 0602D7DE mov.l 0x0602D8CC,r10
    c.r[9] += c.r[9];  // 0602D7E0 add r9,r9
    c.r[9] += c.r[11];  // 0602D7E2 add r11,r9
    c.r[9] <<= 2;  // 0602D7E4 shll2 r9
    c.r[1] = c.r[9];  // 0602D7E6 mov r9,r1
    c.r[0] = c.r[9];  // 0602D7E8 mov r9,r0
    c.r[2] = ld32(c.r[10]);  // 0602D7EA mov.l @r10,r2
    c.r[4] = ld32(0x0602D8D0u);  // 0602D7EC mov.l 0x0602D8D0,r4
    c.r[1] += c.r[2];  // 0602D7EE add r2,r1
    st16(c.r[0] + c.r[2], c.r[8]);  // 0602D7F0 mov.w r8,@(r0,r2)
    c.r[1] += 2;  // 0602D7F2 add #2,r1
    st8(c.r[1], c.r[12]);  // 0602D7F4 mov.b r12,@r1
    c.r[1] = ld32(0x0602D8D4u);  // 0602D7F6 mov.l 0x0602D8D4,r1
    c.r[2] = ld32(c.r[10]);  // 0602D7F8 mov.l @r10,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602D8C0u);  // 0602D7FA mov.w 0x0602D8C0,r0
    c.r[1] = ld32(c.r[1]);  // 0602D7FC mov.l @r1,r1
    c.r[2] += c.r[9];  // 0602D7FE add r9,r2
    c.r[1] += 8;  // 0602D800 add #8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602D802 mov.b @r1,r1
    c.r[2] += 3;  // 0602D804 add #3,r2
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602D806 mov.b @r2,r7
    c.r[1] <<= 2;  // 0602D808 shll2 r1
    c.r[1] &= c.r[0];  // 0602D80A and r0,r1
    c.r[0] = 0x3Fu;  // 0602D80C mov #63,r0
    c.r[7] &= c.r[0];  // 0602D80E and r0,r7
    c.r[7] |= c.r[1];  // 0602D810 or r1,r7
    st8(c.r[2], c.r[7]);  // 0602D812 mov.b r7,@r2
    c.r[0] = 0x3u;  // 0602D814 mov #3,r0
    c.r[13] &= c.r[0];  // 0602D816 and r0,r13
    c.r[1] = ld32(c.r[10]);  // 0602D818 mov.l @r10,r1
    c.r[13] <<= 2;  // 0602D81A shll2 r13
    c.r[13] <<= 2;  // 0602D81C shll2 r13
    c.r[1] += c.r[9];  // 0602D81E add r9,r1
    c.r[1] += 3;  // 0602D820 add #3,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602D822 mov.b @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602D8C2u);  // 0602D824 mov.w 0x0602D8C2,r0
    c.r[2] &= c.r[0];  // 0602D826 and r0,r2
    c.r[2] |= c.r[13];  // 0602D828 or r13,r2
    st8(c.r[1], c.r[2]);  // 0602D82A mov.b r2,@r1
    c.r[1] = ld32(c.r[10]);  // 0602D82C mov.l @r10,r1
    c.r[5] = 0x1Eu;  // 0602D82E mov #30,r5
    c.r[1] += c.r[9];  // 0602D830 add r9,r1
    c.r[1] += 3;  // 0602D832 add #3,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602D834 mov.b @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602D8C4u);  // 0602D836 mov.w 0x0602D8C4,r0
    c.r[2] &= c.r[0];  // 0602D838 and r0,r2
    st8(c.r[1], c.r[2]);  // 0602D83A mov.b r2,@r1
    c.r[1] = ld32(c.r[10]);  // 0602D83C mov.l @r10,r1
    c.r[8] = ld32(0x0602D8D8u);  // 0602D83E mov.l 0x0602D8D8,r8
    c.r[1] += c.r[9];  // 0602D840 add r9,r1
    c.r[1] += 8;  // 0602D842 add #8,r1
    st8(c.r[1], c.r[3]);  // 0602D844 mov.b r3,@r1
    c.r[2] = ld32(c.r[10]);  // 0602D846 mov.l @r10,r2
    c.r[1] = 0x64u;  // 0602D848 mov #100,r1
    c.r[2] += c.r[9];  // 0602D84A add r9,r2
    c.r[2] += 9;  // 0602D84C add #9,r2
    st8(c.r[2], c.r[1]);  // 0602D84E mov.b r1,@r2
    c.r[1] = ld32(c.r[10]);  // 0602D850 mov.l @r10,r1
    c.r[13] = 0x0u;  // 0602D852 mov #0,r13
    c.r[1] += c.r[9];  // 0602D854 add r9,r1
    c.r[1] += 10;  // 0602D856 add #10,r1
    { const uint32_t x = c.r[8]; c.pr = 0x0602D85Cu; st16(c.r[1], c.r[13]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602D85Cu) return; }  // 0602D858 jsr @r8 ; mov.w r13,@r1
    c.r[1] = c.r[0];  // 0602D85C mov r0,r1
    c.r[5] = 0x0u;  // 0602D85E mov #0,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0602D864u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602D864u) return; }  // 0602D860 jsr @r8 ; mov r1,r4
    c.r[1] = 0x62u;  // 0602D864 mov #98,r1
    c.t = c.r[12] > c.r[1];  // 0602D866 cmp/hi r1,r12
    { const bool k = c.t; c.r[2] = c.r[0]; if (k) { goto L_0602D88C; } }  // 0602D868 bt/s 0x0602D88C ; mov r0,r2
    c.r[0] = c.r[12];  // 0602D86C mov r12,r0
    c.r[1] = ld32(c.r[10]);  // 0602D86E mov.l @r10,r1
    c.r[0] += c.r[0];  // 0602D870 add r0,r0
    c.r[9] += c.r[1];  // 0602D872 add r1,r9
    c.r[9] += 4;  // 0602D874 add #4,r9
    c.r[1] = c.r[0];  // 0602D876 mov r0,r1
    c.r[1] += c.r[2];  // 0602D878 add r2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0602D87A mov.b @(r0,r2),r2
    c.r[1] += 1;  // 0602D87C add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602D87E mov.b @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0602D880 extu.b r2,r2
    c.r[2] <<= 8;  // 0602D882 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0602D884 extu.b r1,r1
    c.r[2] += c.r[1];  // 0602D886 add r1,r2
    st16(c.r[9], c.r[2]); goto L_0602D894;  // 0602D888 bra 0x0602D894 ; mov.w r2,@r9
L_0602D88C:
    c.r[1] = ld32(c.r[10]);  // 0602D88C mov.l @r10,r1
    c.r[9] += c.r[1];  // 0602D88E add r1,r9
    c.r[9] += 4;  // 0602D890 add #4,r9
    st16(c.r[9], c.r[13]);  // 0602D892 mov.w r13,@r9
L_0602D894:
    c.r[1] = ld32(0x0602D8CCu);  // 0602D894 mov.l 0x0602D8CC,r1
    c.r[1] = ld32(c.r[1]);  // 0602D896 mov.l @r1,r1
    c.r[2] = c.r[11];  // 0602D898 mov r11,r2
    c.r[2] += c.r[2];  // 0602D89A add r2,r2
    c.r[2] += c.r[11];  // 0602D89C add r11,r2
    c.r[2] <<= 2;  // 0602D89E shll2 r2
    c.r[12] -= 1;  // 0602D8A0 add #-1,r12
    c.r[12] += c.r[12];  // 0602D8A2 add r12,r12
    c.r[2] += c.r[1];  // 0602D8A4 add r1,r2
    c.r[2] += 6;  // 0602D8A6 add #6,r2
    st16(c.r[2], c.r[12]);  // 0602D8A8 mov.w r12,@r2
L_0602D8AA:
    c.r[15] = c.r[14];  // 0602D8AA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602D8AC lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602D8AE mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0602D8B0 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0602D8B2 mov.l @r15+,r12
    c.r[0] = c.r[11];  // 0602D8B4 mov r11,r0
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0602D8B6 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0602D8B8 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0602D8BA mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602D8BC rts ; mov.l @r15+,r8
}

void f_0602D8DC(SH2Context& c) {
    ran[636] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602D8DC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602D8DE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0602D8E0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602D8E2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602D8E4 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0602D8E6 mov r15,r14
    c.r[8] = 0x0u;  // 0602D8E8 mov #0,r8
    c.r[10] = ld32(0x0602D908u);  // 0602D8EA mov.l 0x0602D908,r10
    c.r[9] = 0x7Fu;  // 0602D8EC mov #127,r9
L_0602D8EE:
    { const uint32_t x = c.r[10]; c.pr = 0x0602D8F2u; c.r[4] = c.r[8] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602D8F2u) return; }  // 0602D8EE jsr @r10 ; extu.b r8,r4
    c.r[8] += 1;  // 0602D8F2 add #1,r8
    c.t = (int32_t)c.r[8] > (int32_t)c.r[9];  // 0602D8F4 cmp/gt r9,r8
    if (!c.t) { SH2_POLL(c); goto L_0602D8EE; }  // 0602D8F6 bf 0x0602D8EE
    c.r[15] = c.r[14];  // 0602D8F8 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602D8FA lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602D8FC mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0602D8FE mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0602D900 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602D902 rts ; mov.l @r15+,r8
}

void f_0602D90C(SH2Context& c) {
    ran[637] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602D90C mov.l r14,@-r15
    c.r[4] = c.r[4] & 0xFFu;  // 0602D90E extu.b r4,r4
    c.r[7] = ld32(0x0602D988u);  // 0602D910 mov.l 0x0602D988,r7
    c.r[3] = c.r[4];  // 0602D912 mov r4,r3
    c.r[3] += c.r[3];  // 0602D914 add r3,r3
    c.r[3] += c.r[4];  // 0602D916 add r4,r3
    c.r[3] <<= 2;  // 0602D918 shll2 r3
    c.r[2] = c.r[3];  // 0602D91A mov r3,r2
    c.r[6] = 0x0u;  // 0602D91C mov #0,r6
    c.r[1] = ld32(c.r[7]);  // 0602D91E mov.l @r7,r1
    c.r[0] = c.r[3];  // 0602D920 mov r3,r0
    c.r[2] += c.r[1];  // 0602D922 add r1,r2
    st16(c.r[0] + c.r[1], c.r[6]);  // 0602D924 mov.w r6,@(r0,r1)
    c.r[2] += 2;  // 0602D926 add #2,r2
    c.r[1] = 0x0u;  // 0602D928 mov #0,r1
    st8(c.r[2], c.r[1]);  // 0602D92A mov.b r1,@r2
    c.r[1] = ld32(c.r[7]);  // 0602D92C mov.l @r7,r1
    c.r[1] += c.r[3];  // 0602D92E add r3,r1
    c.r[1] += 3;  // 0602D930 add #3,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602D932 mov.b @r1,r2
    c.r[0] = 0x3Fu;  // 0602D934 mov #63,r0
    c.r[2] &= c.r[0];  // 0602D936 and r0,r2
    st8(c.r[1], c.r[2]);  // 0602D938 mov.b r2,@r1
    c.r[1] = ld32(c.r[7]);  // 0602D93A mov.l @r7,r1
    c.r[1] += c.r[3];  // 0602D93C add r3,r1
    c.r[1] += 3;  // 0602D93E add #3,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602D940 mov.b @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602D984u);  // 0602D942 mov.w 0x0602D984,r0
    c.r[2] &= c.r[0];  // 0602D944 and r0,r2
    st8(c.r[1], c.r[2]);  // 0602D946 mov.b r2,@r1
    c.r[1] = ld32(c.r[7]);  // 0602D948 mov.l @r7,r1
    c.r[1] += c.r[3];  // 0602D94A add r3,r1
    c.r[1] += 3;  // 0602D94C add #3,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602D94E mov.b @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602D986u);  // 0602D950 mov.w 0x0602D986,r0
    c.r[2] &= c.r[0];  // 0602D952 and r0,r2
    st8(c.r[1], c.r[2]);  // 0602D954 mov.b r2,@r1
    c.r[2] = ld32(c.r[7]);  // 0602D956 mov.l @r7,r2
    c.r[14] = c.r[15];  // 0602D958 mov r15,r14
    c.r[2] += c.r[3];  // 0602D95A add r3,r2
    c.r[1] = c.r[2];  // 0602D95C mov r2,r1
    c.r[1] += 4;  // 0602D95E add #4,r1
    st16(c.r[1], c.r[6]);  // 0602D960 mov.w r6,@r1
    c.r[1] = c.r[2];  // 0602D962 mov r2,r1
    c.r[1] += 6;  // 0602D964 add #6,r1
    st16(c.r[1], c.r[6]);  // 0602D966 mov.w r6,@r1
    c.r[2] += 8;  // 0602D968 add #8,r2
    c.r[1] = 0xFFFFFFFFu;  // 0602D96A mov #-1,r1
    st8(c.r[2], c.r[1]);  // 0602D96C mov.b r1,@r2
    c.r[2] = ld32(c.r[7]);  // 0602D96E mov.l @r7,r2
    c.r[1] = 0x32u;  // 0602D970 mov #50,r1
    c.r[2] += c.r[3];  // 0602D972 add r3,r2
    c.r[2] += 9;  // 0602D974 add #9,r2
    st8(c.r[2], c.r[1]);  // 0602D976 mov.b r1,@r2
    c.r[1] = ld32(c.r[7]);  // 0602D978 mov.l @r7,r1
    c.r[3] += c.r[1];  // 0602D97A add r1,r3
    c.r[3] += 10;  // 0602D97C add #10,r3
    st16(c.r[3], c.r[6]);  // 0602D97E mov.w r6,@r3
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602D980 rts ; mov.l @r15+,r14
}

void f_0602D98C(SH2Context& c) {
    ran[638] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602D98C mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0602D98E mov r15,r14
    c.r[4] = c.r[4] & 0xFFFFu;  // 0602D990 extu.w r4,r4
    c.r[2] = 0x0u;  // 0602D992 mov #0,r2
    c.r[1] = ld32(0x0602D9C4u);  // 0602D994 mov.l 0x0602D9C4,r1
    c.r[3] = ld32(c.r[1]);  // 0602D996 mov.l @r1,r3
    c.r[7] = 0x7Fu;  // 0602D998 mov #127,r7
    c.r[0] = c.r[2];  // 0602D99A mov r2,r0
L_0602D99C:
    c.r[0] += c.r[0];  // 0602D99C add r0,r0
    c.r[0] += c.r[2];  // 0602D99E add r2,r0
    c.r[0] <<= 2;  // 0602D9A0 shll2 r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 0602D9A2 mov.w @(r0,r3),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0602D9A4 extu.w r1,r1
    c.t = c.r[1] == c.r[4];  // 0602D9A6 cmp/eq r4,r1
    { const bool k = !c.t; c.r[1] = c.r[2]; if (k) { goto L_0602D9B0; } }  // 0602D9A8 bf/s 0x0602D9B0 ; mov r2,r1
    c.r[0] = c.r[2]; goto L_0602D9BC;  // 0602D9AC bra 0x0602D9BC ; mov r2,r0
L_0602D9B0:
    c.r[1] += 1;  // 0602D9B0 add #1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0602D9B2 extu.b r1,r2
    c.t = c.r[2] > c.r[7];  // 0602D9B4 cmp/hi r7,r2
    { const bool k = !c.t; c.r[0] = c.r[2]; if (k) { SH2_POLL(c); goto L_0602D99C; } }  // 0602D9B6 bf/s 0x0602D99C ; mov r2,r0
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602D9C2u);  // 0602D9BA mov.w 0x0602D9C2,r0
L_0602D9BC:
    c.r[15] = c.r[14];  // 0602D9BC mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602D9BE rts ; mov.l @r15+,r14
}

void f_0602D9C8(SH2Context& c) {
    ran[639] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602D9C8 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0602D9CA mov r15,r14
    c.r[4] = c.r[4] & 0xFFu;  // 0602D9CC extu.b r4,r4
    c.r[1] = ld32(0x0602DA3Cu);  // 0602D9CE mov.l 0x0602DA3C,r1
    c.r[1] = ld32(c.r[1]);  // 0602D9D0 mov.l @r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0602D9D2 tst r1,r1
    { const bool k = c.t; c.r[6] = c.r[4]; if (k) { goto L_0602DA22; } }  // 0602D9D4 bt/s 0x0602DA22 ; mov r4,r6
    c.r[1] = ld32(0x0602DA40u);  // 0602D9D8 mov.l 0x0602DA40,r1
    c.r[2] = c.r[4];  // 0602D9DA mov r4,r2
    c.r[2] += c.r[2];  // 0602D9DC add r2,r2
    c.r[2] += c.r[4];  // 0602D9DE add r4,r2
    c.r[1] = ld32(c.r[1]);  // 0602D9E0 mov.l @r1,r1
    c.r[2] <<= 2;  // 0602D9E2 shll2 r2
    c.r[2] += c.r[1];  // 0602D9E4 add r1,r2
    c.r[2] += 9;  // 0602D9E6 add #9,r2
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602D9E8 mov.b @r2,r7
    c.r[1] = 0x63u;  // 0602D9EA mov #99,r1
    c.r[3] = c.r[7] & 0xFFu;  // 0602D9EC extu.b r7,r3
    c.t = c.r[3] > c.r[1];  // 0602D9EE cmp/hi r1,r3
    { const bool k = c.t; c.r[1] = 0x64u; if (k) { goto L_0602D9F8; } }  // 0602D9F0 bt/s 0x0602D9F8 ; mov #100,r1
    c.r[1] = 0x64u; goto L_0602DA00;  // 0602D9F4 bra 0x0602DA00 ; mov #100,r1
L_0602D9F8:
    c.t = c.r[3] > c.r[1];  // 0602D9F8 cmp/hi r1,r3
    { const bool k = !c.t; c.r[1] = 0xFFFFFFC8u; if (k) { goto L_0602DA02; } }  // 0602D9FA bf/s 0x0602DA02 ; mov #-56,r1
    c.r[1] -= c.r[7];  // 0602D9FE sub r7,r1
L_0602DA00:
    st8(c.r[2], c.r[1]);  // 0602DA00 mov.b r1,@r2
L_0602DA02:
    c.r[1] = ld32(0x0602DA40u);  // 0602DA02 mov.l 0x0602DA40,r1
    c.r[3] = c.r[6];  // 0602DA04 mov r6,r3
    c.r[3] += c.r[3];  // 0602DA06 add r3,r3
    c.r[3] += c.r[6];  // 0602DA08 add r6,r3
    c.r[1] = ld32(c.r[1]);  // 0602DA0A mov.l @r1,r1
    c.r[3] <<= 2;  // 0602DA0C shll2 r3
    c.r[3] += c.r[1];  // 0602DA0E add r1,r3
    c.r[3] += 9;  // 0602DA10 add #9,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0602DA12 mov.b @r3,r1
    c.r[2] = 0x31u;  // 0602DA14 mov #49,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0602DA16 extu.b r1,r1
    c.t = c.r[1] > c.r[2];  // 0602DA18 cmp/hi r2,r1
    { const bool k = c.t; c.r[1] = 0x32u; if (k) { goto L_0602DA36; } }  // 0602DA1A bt/s 0x0602DA36 ; mov #50,r1
    st8(c.r[3], c.r[1]); goto L_0602DA36;  // 0602DA1E bra 0x0602DA36 ; mov.b r1,@r3
L_0602DA22:
    c.r[1] = ld32(0x0602DA40u);  // 0602DA22 mov.l 0x0602DA40,r1
    c.r[1] = ld32(c.r[1]);  // 0602DA24 mov.l @r1,r1
    c.r[2] = c.r[6];  // 0602DA26 mov r6,r2
    c.r[2] += c.r[2];  // 0602DA28 add r2,r2
    c.r[2] += c.r[6];  // 0602DA2A add r6,r2
    c.r[2] <<= 2;  // 0602DA2C shll2 r2
    c.r[2] += c.r[1];  // 0602DA2E add r1,r2
    c.r[2] += 9;  // 0602DA30 add #9,r2
    c.r[1] = 0x64u;  // 0602DA32 mov #100,r1
    st8(c.r[2], c.r[1]);  // 0602DA34 mov.b r1,@r2
L_0602DA36:
    c.r[15] = c.r[14];  // 0602DA36 mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602DA38 rts ; mov.l @r15+,r14
}

void f_0602DA44(SH2Context& c) {
    ran[640] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602DA44 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602DA46 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0602DA48 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0602DA4A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0602DA4C mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0602DA4E mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602DA50 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602DA52 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0602DA54 mov r15,r14
    c.r[4] = c.r[4] & 0xFFu;  // 0602DA56 extu.b r4,r4
    c.r[9] = ld32(0x0602DAE4u);  // 0602DA58 mov.l 0x0602DAE4,r9
    c.r[10] = c.r[4];  // 0602DA5A mov r4,r10
    c.r[10] += c.r[10];  // 0602DA5C add r10,r10
    c.r[10] += c.r[4];  // 0602DA5E add r4,r10
    c.r[10] <<= 2;  // 0602DA60 shll2 r10
    c.r[0] = c.r[10];  // 0602DA62 mov r10,r0
    c.r[13] = ld32(0x0602DAE8u);  // 0602DA64 mov.l 0x0602DAE8,r13
    c.r[11] = ld32(0x0602DAECu);  // 0602DA66 mov.l 0x0602DAEC,r11
    c.r[1] = ld32(c.r[9]);  // 0602DA68 mov.l @r9,r1
    c.r[5] = 0x1Cu;  // 0602DA6A mov #28,r5
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0602DA6C mov.w @(r0,r1),r8
    c.r[4] = c.r[13];  // 0602DA6E mov r13,r4
    { const uint32_t x = c.r[11]; c.pr = 0x0602DA74u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602DA74u) return; }  // 0602DA70 jsr @r11 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 0602DA74 mov r0,r1
    c.r[5] = c.r[8];  // 0602DA76 mov r8,r5
    { const uint32_t x = c.r[11]; c.pr = 0x0602DA7Cu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602DA7Cu) return; }  // 0602DA78 jsr @r11 ; mov r1,r4
    c.r[2] = c.r[0];  // 0602DA7C mov r0,r2
    c.r[1] = ld32(c.r[9]);  // 0602DA7E mov.l @r9,r1
    c.r[10] += c.r[1];  // 0602DA80 add r1,r10
    c.r[10] += 2;  // 0602DA82 add #2,r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0602DA84 mov.b @r10,r1
    c.r[12] = 0x1u;  // 0602DA86 mov #1,r12
    c.r[9] = c.r[1] & 0xFFu;  // 0602DA88 extu.b r1,r9
    c.t = c.r[9] > c.r[12];  // 0602DA8A cmp/hi r12,r9
    { const bool k = !c.t; c.r[8] = 0x0u; if (k) { goto L_0602DACC; } }  // 0602DA8C bf/s 0x0602DACC ; mov #0,r8
    c.r[2] += 8;  // 0602DA90 add #8,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602DA92 mov.b @r2,r0
    c.r[10] = 0xFu;  // 0602DA94 mov #15,r10
    c.r[5] = 0x1Eu;  // 0602DA96 mov #30,r5
    c.r[4] = c.r[13];  // 0602DA98 mov r13,r4
    { const uint32_t x = c.r[11]; c.pr = 0x0602DA9Eu; c.r[10] &= c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602DA9Eu) return; }  // 0602DA9A jsr @r11 ; and r0,r10
    c.r[5] = c.r[12];  // 0602DA9E mov r12,r5
    { const uint32_t x = c.r[11]; c.pr = 0x0602DAA4u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602DAA4u) return; }  // 0602DAA0 jsr @r11 ; mov r0,r4
    c.r[5] = 0x7u;  // 0602DAA4 mov #7,r5
    { const uint32_t x = c.r[11]; c.pr = 0x0602DAAAu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602DAAAu) return; }  // 0602DAA6 jsr @r11 ; mov r0,r4
    c.r[5] = c.r[10];  // 0602DAAA mov r10,r5
    { const uint32_t x = c.r[11]; c.pr = 0x0602DAB0u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602DAB0u) return; }  // 0602DAAC jsr @r11 ; mov r0,r4
    c.r[2] = 0x2u;  // 0602DAB0 mov #2,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[9];  // 0602DAB2 cmp/gt r9,r2
    { const bool k = c.t; c.r[3] = c.r[0]; if (k) { goto L_0602DACC; } }  // 0602DAB4 bt/s 0x0602DACC ; mov r0,r3
L_0602DAB8:
    c.r[1] = c.r[2];  // 0602DAB8 mov r2,r1
    c.r[1] += c.r[3];  // 0602DABA add r3,r1
    c.r[1] -= 2;  // 0602DABC add #-2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602DABE mov.b @r1,r1
    c.r[2] += 1;  // 0602DAC0 add #1,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[9];  // 0602DAC2 cmp/gt r9,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0602DAC4 extu.b r1,r1
    c.r[1] += c.r[8];  // 0602DAC6 add r8,r1
    { const bool k = !c.t; c.r[8] = c.r[1] & 0xFFFFu; if (k) { SH2_POLL(c); goto L_0602DAB8; } }  // 0602DAC8 bf/s 0x0602DAB8 ; extu.w r1,r8
L_0602DACC:
    c.r[15] = c.r[14];  // 0602DACC mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602DACE lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602DAD0 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0602DAD2 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0602DAD4 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0602DAD6 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0602DAD8 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0602DADA mov.l @r15+,r9
    c.r[0] = c.r[8] & 0xFFu;  // 0602DADC extu.b r8,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602DADE rts ; mov.l @r15+,r8
}

void f_0602DAF0(SH2Context& c) {
    ran[641] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602DAF0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602DAF2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0602DAF4 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0602DAF6 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602DAF8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602DAFA sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0602DAFC mov r15,r14
    c.r[9] = 0x0u;  // 0602DAFE mov #0,r9
    c.r[10] = ld32(0x0602DB54u);  // 0602DB00 mov.l 0x0602DB54,r10
    c.r[11] = ld32(0x0602DB58u);  // 0602DB02 mov.l 0x0602DB58,r11
    c.r[8] = 0x0u;  // 0602DB04 mov #0,r8
L_0602DB06:
    c.r[0] = ld32(c.r[10]);  // 0602DB06 mov.l @r10,r0
    c.r[4] = c.r[8];  // 0602DB08 mov r8,r4
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[8]);  // 0602DB0A mov.w @(r0,r8),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0602DB0C extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0602DB0E tst r1,r1
    { const bool k = c.t; c.r[4] += c.r[0]; if (k) { goto L_0602DB38; } }  // 0602DB10 bt/s 0x0602DB38 ; add r0,r4
    c.r[2] = c.r[4];  // 0602DB14 mov r4,r2
    c.r[2] += 2;  // 0602DB16 add #2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602DB18 mov.b @r2,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0602DB1A extu.b r1,r0
    c.r[1] = 0x28u;  // 0602DB1C mov #40,r1
    c.t = c.r[0] > c.r[1];  // 0602DB1E cmp/hi r1,r0
    { const bool k = !c.t; c.r[1] = 0x1u; if (k) { goto L_0602DB28; } }  // 0602DB20 bf/s 0x0602DB28 ; mov #1,r1
    st8(c.r[2], c.r[1]); goto L_0602DB38;  // 0602DB24 bra 0x0602DB38 ; mov.b r1,@r2
L_0602DB28:
    c.t = c.r[0] == 0x28u;  // 0602DB28 cmp/eq #40,r0
    if (!c.t) { goto L_0602DB38; }  // 0602DB2A bf 0x0602DB38
    { const uint32_t x = c.r[11]; c.pr = 0x0602DB30u; c.r[5] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602DB30u) return; }  // 0602DB2C jsr @r11 ; mov r0,r5
    c.r[1] = ld32(c.r[10]);  // 0602DB30 mov.l @r10,r1
    c.r[1] += c.r[8];  // 0602DB32 add r8,r1
    c.r[1] += 4;  // 0602DB34 add #4,r1
    st16(c.r[1], c.r[0]);  // 0602DB36 mov.w r0,@r1
L_0602DB38:
    c.r[9] += 1;  // 0602DB38 add #1,r9
    c.r[1] = 0x7Fu;  // 0602DB3A mov #127,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 0602DB3C cmp/gt r1,r9
    { const bool k = !c.t; c.r[8] += 12; if (k) { SH2_POLL(c); goto L_0602DB06; } }  // 0602DB3E bf/s 0x0602DB06 ; add #12,r8
    c.r[15] = c.r[14];  // 0602DB42 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602DB44 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602DB46 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0602DB48 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0602DB4A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0602DB4C mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602DB4E rts ; mov.l @r15+,r8
}

void f_0602DB5C(SH2Context& c) {
    ran[642] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602DB5C mov.l r14,@-r15
    c.r[4] = c.r[4] & 0xFFu;  // 0602DB5E extu.b r4,r4
    c.r[5] = c.r[5] & 0xFFu;  // 0602DB60 extu.b r5,r5
    c.r[2] = ld32(0x0602DBECu);  // 0602DB62 mov.l 0x0602DBEC,r2
    c.r[3] = c.r[4];  // 0602DB64 mov r4,r3
    c.r[3] += c.r[3];  // 0602DB66 add r3,r3
    c.r[3] += c.r[4];  // 0602DB68 add r4,r3
    c.r[3] <<= 2;  // 0602DB6A shll2 r3
    c.r[7] = 0x3u;  // 0602DB6C mov #3,r7
    c.r[1] = ld32(c.r[2]);  // 0602DB6E mov.l @r2,r1
    c.r[7] &= c.r[5];  // 0602DB70 and r5,r7
    c.r[1] += c.r[3];  // 0602DB72 add r3,r1
    c.r[1] += 3;  // 0602DB74 add #3,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602DB76 mov.b @r1,r0
    c.r[7] <<= 2;  // 0602DB78 shll2 r7
    c.r[7] <<= 2;  // 0602DB7A shll2 r7
    c.r[0] &= 0xCFu;  // 0602DB7C and #207,r0
    c.r[0] |= c.r[7];  // 0602DB7E or r7,r0
    st8(c.r[1], c.r[0]);  // 0602DB80 mov.b r0,@r1
    c.r[2] = ld32(c.r[2]);  // 0602DB82 mov.l @r2,r2
    c.r[3] += c.r[2];  // 0602DB84 add r2,r3
    c.r[3] += 8;  // 0602DB86 add #8,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0602DB88 mov.b @r3,r1
    c.r[3] = c.r[1] & 0xFFu;  // 0602DB8A extu.b r1,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602DBEAu);  // 0602DB8C mov.w 0x0602DBEA,r1
    c.t = c.r[3] == c.r[1];  // 0602DB8E cmp/eq r1,r3
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0602DBA8; } }  // 0602DB90 bt/s 0x0602DBA8 ; mov r15,r14
    c.r[1] = c.r[3];  // 0602DB94 mov r3,r1
    c.r[1] += c.r[1];  // 0602DB96 add r1,r1
    c.r[1] += c.r[3];  // 0602DB98 add r3,r1
    c.r[1] <<= 2;  // 0602DB9A shll2 r1
    c.r[1] += c.r[2];  // 0602DB9C add r2,r1
    c.r[1] += 3;  // 0602DB9E add #3,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602DBA0 mov.b @r1,r0
    c.r[0] &= 0xCFu;  // 0602DBA2 and #207,r0
    c.r[0] |= c.r[7];  // 0602DBA4 or r7,r0
    st8(c.r[1], c.r[0]);  // 0602DBA6 mov.b r0,@r1
L_0602DBA8:
    c.r[7] = 0x0u;  // 0602DBA8 mov #0,r7
    c.r[6] = ld32(0x0602DBF0u);  // 0602DBAA mov.l 0x0602DBF0,r6
    c.r[5] <<= 2;  // 0602DBAC shll2 r5
    c.r[5] <<= 2;  // 0602DBAE shll2 r5
    c.r[5] <<= 2;  // 0602DBB0 shll2 r5
    c.r[2] = 0x0u;  // 0602DBB2 mov #0,r2
L_0602DBB4:
    c.r[0] = ld32(c.r[6]);  // 0602DBB4 mov.l @r6,r0
    c.r[3] = c.r[2];  // 0602DBB6 mov r2,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 0602DBB8 mov.w @(r0,r2),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0602DBBA extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0602DBBC tst r1,r1
    { const bool k = c.t; c.r[3] += c.r[0]; if (k) { goto L_0602DBDA; } }  // 0602DBBE bt/s 0x0602DBDA ; add r0,r3
    c.r[1] = c.r[3];  // 0602DBC2 mov r3,r1
    c.r[1] += 15;  // 0602DBC4 add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602DBC6 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602DBC8 extu.b r1,r1
    c.t = c.r[1] == c.r[4];  // 0602DBCA cmp/eq r4,r1
    { const bool k = !c.t; c.r[1] = c.r[3]; if (k) { goto L_0602DBDA; } }  // 0602DBCC bf/s 0x0602DBDA ; mov r3,r1
    c.r[1] += 2;  // 0602DBD0 add #2,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602DBD2 mov.b @r1,r0
    c.r[0] &= 0x3Fu;  // 0602DBD4 and #63,r0
    c.r[0] |= c.r[5];  // 0602DBD6 or r5,r0
    st8(c.r[1], c.r[0]);  // 0602DBD8 mov.b r0,@r1
L_0602DBDA:
    c.r[7] += 1;  // 0602DBDA add #1,r7
    c.r[1] = 0x7Fu;  // 0602DBDC mov #127,r1
    c.t = (int32_t)c.r[7] > (int32_t)c.r[1];  // 0602DBDE cmp/gt r1,r7
    { const bool k = !c.t; c.r[2] += 30; if (k) { SH2_POLL(c); goto L_0602DBB4; } }  // 0602DBE0 bf/s 0x0602DBB4 ; add #30,r2
    c.r[15] = c.r[14];  // 0602DBE4 mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602DBE6 rts ; mov.l @r15+,r14
}

void f_0602DBF4(SH2Context& c) {
    ran[643] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602DBF4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602DBF6 sts.l pr,@-r15
    c.r[1] = ld32(0x0602DC14u);  // 0602DBF8 mov.l 0x0602DC14,r1
    c.r[1] = ld32(c.r[1]);  // 0602DBFA mov.l @r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602DBFC mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0602DBFE extu.b r1,r0
    c.r[0] <<= 2;  // 0602DC00 shll2 r0
    c.r[1] = ld32(0x0602DC18u);  // 0602DC02 mov.l 0x0602DC18,r1
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 0602DC04 mov.l @(r0,r1),r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602DC0Au; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602DC0Au) return; }  // 0602DC06 jsr @r0 ; mov r15,r14
    c.r[15] = c.r[14];  // 0602DC0A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602DC0C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602DC0E mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[0] & 0xFFFFu; c.pc = x; return; }  // 0602DC10 rts ; extu.w r0,r0
}

void f_0602DC1C(SH2Context& c) {
    ran[644] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602DC1C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602DC1E sts.l pr,@-r15
    c.r[1] = ld32(0x0602DC48u);  // 0602DC20 mov.l 0x0602DC48,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602DC26u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602DC26u) return; }  // 0602DC22 jsr @r1 ; mov r15,r14
    c.r[1] = ld32(0x0602DC4Cu);  // 0602DC26 mov.l 0x0602DC4C,r1
    c.r[2] = ld32(c.r[1]);  // 0602DC28 mov.l @r1,r2
    c.r[1] = ld32(0x0602DC50u);  // 0602DC2A mov.l 0x0602DC50,r1
    c.t = c.r[2] == c.r[1];  // 0602DC2C cmp/eq r1,r2
    if (c.t) { goto L_0602DC3A; }  // 0602DC2E bt 0x0602DC3A
    c.r[1] = ld32(0x0602DC54u);  // 0602DC30 mov.l 0x0602DC54,r1
    st32(c.r[1] + 20, c.r[2]);  // 0602DC32 mov.l r2,@(20,r1)
    c.r[1] = ld32(0x0602DC58u);  // 0602DC34 mov.l 0x0602DC58,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602DC3Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602DC3Au) return; }  // 0602DC36 jsr @r1 ; nop
L_0602DC3A:
    c.r[15] = c.r[14];  // 0602DC3A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602DC3C lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602DC44u);  // 0602DC3E mov.w 0x0602DC44,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602DC40 rts ; mov.l @r15+,r14
}

void f_0602DC5C(SH2Context& c) {
    ran[645] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602DC5C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602DC5E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602DC60 sts.l pr,@-r15
    c.r[1] = ld32(0x0602DCE0u);  // 0602DC62 mov.l 0x0602DCE0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602DC68u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602DC68u) return; }  // 0602DC64 jsr @r1 ; mov r15,r14
    c.r[1] = ld32(0x0602DCE4u);  // 0602DC68 mov.l 0x0602DCE4,r1
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0602DC6A mov.w @r1,r5
    c.r[0] = ld32(0x0602DCE8u);  // 0602DC6C mov.l 0x0602DCE8,r0
    c.r[4] = 0x0u;  // 0602DC6E mov #0,r4
    { const uint32_t x = c.r[0]; c.pr = 0x0602DC74u; c.r[5] = c.r[5] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602DC74u) return; }  // 0602DC70 jsr @r0 ; extu.w r5,r5
    c.r[4] = c.r[0] & 0xFFFFu;  // 0602DC74 extu.w r0,r4
    c.r[1] = ld32(0x0602DCECu);  // 0602DC76 mov.l 0x0602DCEC,r1
    c.t = c.r[4] == c.r[1];  // 0602DC78 cmp/eq r1,r4
    { const bool k = c.t; c.r[3] = c.r[4]; if (k) { goto L_0602DCD0; } }  // 0602DC7A bt/s 0x0602DCD0 ; mov r4,r3
    c.r[7] = ld32(0x0602DCF0u);  // 0602DC7E mov.l 0x0602DCF0,r7
    c.r[3] <<= 2;  // 0602DC80 shll2 r3
    c.r[1] = ld32(0x0602DCF4u);  // 0602DC82 mov.l 0x0602DCF4,r1
    c.r[2] = ld32(c.r[1]);  // 0602DC84 mov.l @r1,r2
    c.r[3] += c.r[7];  // 0602DC86 add r7,r3
    c.r[1] = c.r[2];  // 0602DC88 mov r2,r1
    c.r[1] += 1;  // 0602DC8A add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602DC8C mov.b @r1,r1
    c.r[2] += 2;  // 0602DC8E add #2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0602DC90 extu.b r1,r1
    c.r[6] = c.r[1];  // 0602DC92 mov r1,r6
    c.r[6] <<= 8;  // 0602DC94 shll8 r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602DC96 mov.b @r2,r1
    c.r[8] = (uint32_t)(int16_t)ld16(0x0602DCDCu);  // 0602DC98 mov.w 0x0602DCDC,r8
    c.r[1] = c.r[1] & 0xFFu;  // 0602DC9A extu.b r1,r1
    c.r[6] |= c.r[1];  // 0602DC9C or r1,r6
    c.r[0] = c.r[6];  // 0602DC9E mov r6,r0
    c.r[0] >>= 2;  // 0602DCA0 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0602DCA2 shlr r0
    c.r[0] >>= 2;  // 0602DCA4 shlr2 r0
    c.r[0] &= 0x1Fu;  // 0602DCA6 and #31,r0
    c.r[1] = c.r[3];  // 0602DCA8 mov r3,r1
    c.r[1] += 2;  // 0602DCAA add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602DCAC mov.b @r1,r2
    c.r[3] += 3;  // 0602DCAE add #3,r3
    c.r[2] &= c.r[8];  // 0602DCB0 and r8,r2
    c.r[2] |= c.r[0];  // 0602DCB2 or r0,r2
    st8(c.r[1], c.r[2]);  // 0602DCB4 mov.b r2,@r1
    c.r[8] = 0x1Fu;  // 0602DCB6 mov #31,r8
    c.r[6] &= c.r[8];  // 0602DCB8 and r8,r6
    c.r[6] <<= 2;  // 0602DCBA shll2 r6
    c.r[6] += c.r[6];  // 0602DCBC add r6,r6
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0602DCBE mov.b @r3,r0
    c.r[1] = ld32(0x0602DCF8u);  // 0602DCC0 mov.l 0x0602DCF8,r1
    c.r[0] &= 0x7u;  // 0602DCC2 and #7,r0
    c.r[0] |= c.r[6];  // 0602DCC4 or r6,r0
    { const uint32_t x = c.r[1]; c.pr = 0x0602DCCAu; st8(c.r[3], c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602DCCAu) return; }  // 0602DCC6 jsr @r1 ; mov.b r0,@r3
    c.r[1] = ld32(0x0602DCFCu);  // 0602DCCA mov.l 0x0602DCFC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602DCD0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602DCD0u) return; }  // 0602DCCC jsr @r1 ; nop
L_0602DCD0:
    c.r[15] = c.r[14];  // 0602DCD0 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602DCD2 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602DCD4 mov.l @r15+,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602DCDEu);  // 0602DCD6 mov.w 0x0602DCDE,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602DCD8 rts ; mov.l @r15+,r8
}

void f_0602DD00(SH2Context& c) {
    ran[646] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602DD00 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602DD02 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602DD04 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602DD06 sts.l pr,@-r15
    c.r[1] = ld32(0x0602DDB8u);  // 0602DD08 mov.l 0x0602DDB8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602DD0Eu; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602DD0Eu) return; }  // 0602DD0A jsr @r1 ; mov r15,r14
    c.r[1] = ld32(0x0602DDBCu);  // 0602DD0E mov.l 0x0602DDBC,r1
    c.r[2] = ld32(c.r[1]);  // 0602DD10 mov.l @r1,r2
    c.r[0] = ld32(0x0602DDC0u);  // 0602DD12 mov.l 0x0602DDC0,r0
    c.r[1] = c.r[2];  // 0602DD14 mov r2,r1
    c.r[1] += 1;  // 0602DD16 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602DD18 mov.b @r1,r1
    c.r[2] += 2;  // 0602DD1A add #2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0602DD1C extu.b r1,r1
    c.r[8] = c.r[1];  // 0602DD1E mov r1,r8
    c.r[8] <<= 8;  // 0602DD20 shll8 r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602DD22 mov.b @r2,r1
    c.r[4] = 0x0u;  // 0602DD24 mov #0,r4
    c.r[1] = c.r[1] & 0xFFu;  // 0602DD26 extu.b r1,r1
    c.r[8] |= c.r[1];  // 0602DD28 or r1,r8
    c.r[1] = ld32(0x0602DDC4u);  // 0602DD2A mov.l 0x0602DDC4,r1
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0602DD2C mov.w @r1,r5
    c.r[9] = c.r[8];  // 0602DD2E mov r8,r9
    { const uint32_t x = c.r[0]; c.pr = 0x0602DD34u; c.r[5] = c.r[5] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602DD34u) return; }  // 0602DD30 jsr @r0 ; extu.w r5,r5
    c.r[4] = c.r[0] & 0xFFFFu;  // 0602DD34 extu.w r0,r4
    c.r[1] = ld32(0x0602DDC8u);  // 0602DD36 mov.l 0x0602DDC8,r1
    c.t = c.r[4] == c.r[1];  // 0602DD38 cmp/eq r1,r4
    if (c.t) { goto L_0602DDA2; }  // 0602DD3A bt 0x0602DDA2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602DDB0u);  // 0602DD3C mov.w 0x0602DDB0,r1
    c.r[2] = c.r[1];  // 0602DD3E mov r1,r2
    c.r[2] &= c.r[8];  // 0602DD40 and r8,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 0602DD42 extu.w r1,r1
    c.t = c.r[2] == c.r[1];  // 0602DD44 cmp/eq r1,r2
    { const bool k = !c.t; c.r[3] = c.r[4]; if (k) { goto L_0602DD78; } }  // 0602DD46 bf/s 0x0602DD78 ; mov r4,r3
    c.r[3] <<= 2;  // 0602DD4A shll2 r3
    c.r[1] = ld32(0x0602DDCCu);  // 0602DD4C mov.l 0x0602DDCC,r1
    c.r[0] = 0xFu;  // 0602DD4E mov #15,r0
    c.r[8] &= c.r[0];  // 0602DD50 and r0,r8
    c.r[1] = ld32(c.r[1]);  // 0602DD52 mov.l @r1,r1
    c.r[8] += c.r[8];  // 0602DD54 add r8,r8
    c.r[8] += c.r[1];  // 0602DD56 add r1,r8
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602DDB2u);  // 0602DD58 mov.w 0x0602DDB2,r1
    c.r[0] = c.r[8];  // 0602DD5A mov r8,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0602DD5C mov.b @(r0,r1),r1
    c.r[2] = ld32(0x0602DDD0u);  // 0602DD5E mov.l 0x0602DDD0,r2
    c.r[0] = c.r[2];  // 0602DD60 mov r2,r0
    st8(c.r[0] + c.r[3], c.r[1]);  // 0602DD62 mov.b r1,@(r0,r3)
    c.r[1] = c.r[3];  // 0602DD64 mov r3,r1
    c.r[1] += c.r[2];  // 0602DD66 add r2,r1
    c.r[1] += 2;  // 0602DD68 add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602DD6A mov.b @r1,r2
    c.r[0] = 0x3Fu;  // 0602DD6C mov #63,r0
    c.r[2] &= c.r[0];  // 0602DD6E and r0,r2
    c.r[0] = 0x40u;  // 0602DD70 mov #64,r0
    c.r[2] |= c.r[0];  // 0602DD72 or r0,r2
    st8(c.r[1], c.r[2]); goto L_0602DD96;  // 0602DD74 bra 0x0602DD96 ; mov.b r2,@r1
L_0602DD78:
    c.r[2] = ld32(0x0602DDD0u);  // 0602DD78 mov.l 0x0602DDD0,r2
    c.r[0] = c.r[4];  // 0602DD7A mov r4,r0
    c.r[0] <<= 2;  // 0602DD7C shll2 r0
    c.r[1] = c.r[9];  // 0602DD7E mov r9,r1
    c.r[1] >>= 8;  // 0602DD80 shlr8 r1
    st8(c.r[0] + c.r[2], c.r[1]);  // 0602DD82 mov.b r1,@(r0,r2)
    c.r[2] += c.r[0];  // 0602DD84 add r0,r2
    c.r[1] = c.r[2];  // 0602DD86 mov r2,r1
    c.r[1] += 1;  // 0602DD88 add #1,r1
    st8(c.r[1], c.r[9]);  // 0602DD8A mov.b r9,@r1
    c.r[2] += 2;  // 0602DD8C add #2,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602DD8E mov.b @r2,r0
    c.r[0] &= 0x3Fu;  // 0602DD90 and #63,r0
    c.r[0] |= 0x80u;  // 0602DD92 or #128,r0
    st8(c.r[2], c.r[0]);  // 0602DD94 mov.b r0,@r2
L_0602DD96:
    c.r[1] = ld32(0x0602DDD4u);  // 0602DD96 mov.l 0x0602DDD4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602DD9Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602DD9Cu) return; }  // 0602DD98 jsr @r1 ; nop
    c.r[1] = ld32(0x0602DDD8u);  // 0602DD9C mov.l 0x0602DDD8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602DDA2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602DDA2u) return; }  // 0602DD9E jsr @r1 ; nop
L_0602DDA2:
    c.r[15] = c.r[14];  // 0602DDA2 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602DDA4 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602DDA6 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0602DDA8 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602DDB4u);  // 0602DDAA mov.w 0x0602DDB4,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602DDAC rts ; mov.l @r15+,r8
}

void f_0602DDDC(SH2Context& c) {
    ran[647] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602DDDC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602DDDE sts.l pr,@-r15
    c.r[1] = ld32(0x0602DE38u);  // 0602DDE0 mov.l 0x0602DE38,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602DDE6u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602DDE6u) return; }  // 0602DDE2 jsr @r1 ; mov r15,r14
    c.r[1] = ld32(0x0602DE3Cu);  // 0602DDE6 mov.l 0x0602DE3C,r1
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0602DDE8 mov.w @r1,r5
    c.r[0] = ld32(0x0602DE40u);  // 0602DDEA mov.l 0x0602DE40,r0
    c.r[4] = 0x0u;  // 0602DDEC mov #0,r4
    { const uint32_t x = c.r[0]; c.pr = 0x0602DDF2u; c.r[5] = c.r[5] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602DDF2u) return; }  // 0602DDEE jsr @r0 ; extu.w r5,r5
    c.r[4] = c.r[0] & 0xFFFFu;  // 0602DDF2 extu.w r0,r4
    c.r[1] = ld32(0x0602DE44u);  // 0602DDF4 mov.l 0x0602DE44,r1
    c.t = c.r[4] == c.r[1];  // 0602DDF6 cmp/eq r1,r4
    if (c.t) { goto L_0602DE2A; }  // 0602DDF8 bt 0x0602DE2A
    c.r[1] = ld32(0x0602DE48u);  // 0602DDFA mov.l 0x0602DE48,r1
    c.r[1] = ld32(c.r[1]);  // 0602DDFC mov.l @r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602DDFE mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0602DE00 extu.b r1,r0
    c.t = c.r[0] == 0x3u;  // 0602DE02 cmp/eq #3,r0
    { const bool k = !c.t; c.r[2] = c.r[4]; if (k) { goto L_0602DE14; } }  // 0602DE04 bf/s 0x0602DE14 ; mov r4,r2
    c.r[2] <<= 2;  // 0602DE08 shll2 r2
    c.r[1] = ld32(0x0602DE4Cu);  // 0602DE0A mov.l 0x0602DE4C,r1
    c.r[2] += c.r[1];  // 0602DE0C add r1,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602DE0E mov.b @r2,r0
    c.r[0] |= 0x20u; goto L_0602DE1E;  // 0602DE10 bra 0x0602DE1E ; or #32,r0
L_0602DE14:
    c.r[2] <<= 2;  // 0602DE14 shll2 r2
    c.r[1] = ld32(0x0602DE4Cu);  // 0602DE16 mov.l 0x0602DE4C,r1
    c.r[2] += c.r[1];  // 0602DE18 add r1,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602DE1A mov.b @r2,r0
    c.r[0] &= 0xDFu;  // 0602DE1C and #223,r0
L_0602DE1E:
    c.r[1] = ld32(0x0602DE50u);  // 0602DE1E mov.l 0x0602DE50,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602DE24u; st8(c.r[2], c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602DE24u) return; }  // 0602DE20 jsr @r1 ; mov.b r0,@r2
    c.r[1] = ld32(0x0602DE54u);  // 0602DE24 mov.l 0x0602DE54,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602DE2Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602DE2Au) return; }  // 0602DE26 jsr @r1 ; nop
L_0602DE2A:
    c.r[15] = c.r[14];  // 0602DE2A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602DE2C lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602DE34u);  // 0602DE2E mov.w 0x0602DE34,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602DE30 rts ; mov.l @r15+,r14
}

void f_0602DE58(SH2Context& c) {
    ran[648] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602DE58 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602DE5A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602DE5C sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0602DE5E mov r15,r14
    c.r[8] = ld32(0x0602DEACu);  // 0602DE60 mov.l 0x0602DEAC,r8
    c.r[1] = c.r[8];  // 0602DE62 mov r8,r1
    c.r[1] += 28;  // 0602DE64 add #28,r1
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0602DE66 mov.w @r1,r5
    c.r[0] = ld32(0x0602DEB0u);  // 0602DE68 mov.l 0x0602DEB0,r0
    c.r[4] = 0x0u;  // 0602DE6A mov #0,r4
    { const uint32_t x = c.r[0]; c.pr = 0x0602DE70u; c.r[5] = c.r[5] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602DE70u) return; }  // 0602DE6C jsr @r0 ; extu.w r5,r5
    c.r[0] = c.r[0] & 0xFFFFu;  // 0602DE70 extu.w r0,r0
    c.r[1] = ld32(0x0602DEB4u);  // 0602DE72 mov.l 0x0602DEB4,r1
    c.t = c.r[0] == c.r[1];  // 0602DE74 cmp/eq r1,r0
    { const bool k = c.t; c.r[0] <<= 2; if (k) { goto L_0602DE9C; } }  // 0602DE76 bt/s 0x0602DE9C ; shll2 r0
    c.r[1] = ld32(0x0602DEB8u);  // 0602DE7A mov.l 0x0602DEB8,r1
    c.r[2] = ld32(c.r[1]);  // 0602DE7C mov.l @r1,r2
    c.r[2] += c.r[0];  // 0602DE7E add r0,r2
    c.r[1] = c.r[2];  // 0602DE80 mov r2,r1
    c.r[1] += 22;  // 0602DE82 add #22,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602DE84 mov.b @r1,r0
    c.r[2] += 23;  // 0602DE86 add #23,r2
    c.r[0] &= 0x1Fu;  // 0602DE88 and #31,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602DE8A mov.b @r2,r1
    c.r[0] <<= 2;  // 0602DE8C shll2 r0
    c.r[0] += c.r[0];  // 0602DE8E add r0,r0
    c.r[0] <<= 2;  // 0602DE90 shll2 r0
    c.r[1] = c.r[1] & 0xFFu;  // 0602DE92 extu.b r1,r1
    c.r[1] >>= 2;  // 0602DE94 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0602DE96 shlr r1
    c.r[1] |= c.r[0];  // 0602DE98 or r0,r1
    st32(c.r[8] + 20, c.r[1]);  // 0602DE9A mov.l r1,@(20,r8)
L_0602DE9C:
    c.r[15] = c.r[14];  // 0602DE9C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602DE9E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602DEA0 mov.l @r15+,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602DEA8u);  // 0602DEA2 mov.w 0x0602DEA8,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602DEA4 rts ; mov.l @r15+,r8
}

void f_0602DEBC(SH2Context& c) {
    ran[649] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602DEBC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602DEBE sts.l pr,@-r15
    c.r[1] = ld32(0x0602DF08u);  // 0602DEC0 mov.l 0x0602DF08,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602DEC6u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602DEC6u) return; }  // 0602DEC2 jsr @r1 ; mov r15,r14
    c.r[1] = ld32(0x0602DF0Cu);  // 0602DEC6 mov.l 0x0602DF0C,r1
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0602DEC8 mov.w @r1,r5
    c.r[0] = ld32(0x0602DF10u);  // 0602DECA mov.l 0x0602DF10,r0
    c.r[4] = 0x0u;  // 0602DECC mov #0,r4
    { const uint32_t x = c.r[0]; c.pr = 0x0602DED2u; c.r[5] = c.r[5] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602DED2u) return; }  // 0602DECE jsr @r0 ; extu.w r5,r5
    c.r[0] = c.r[0] & 0xFFFFu;  // 0602DED2 extu.w r0,r0
    c.r[1] = ld32(0x0602DF14u);  // 0602DED4 mov.l 0x0602DF14,r1
    c.t = c.r[0] == c.r[1];  // 0602DED6 cmp/eq r1,r0
    { const bool k = c.t; c.r[0] <<= 2; if (k) { goto L_0602DEFA; } }  // 0602DED8 bt/s 0x0602DEFA ; shll2 r0
    c.r[1] = ld32(0x0602DF18u);  // 0602DEDC mov.l 0x0602DF18,r1
    c.r[1] = ld32(c.r[1]);  // 0602DEDE mov.l @r1,r1
    c.r[1] += c.r[0];  // 0602DEE0 add r0,r1
    c.r[1] += 22;  // 0602DEE2 add #22,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602DEE4 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0602DEE6 mov r1,r0
    c.r[0] >>= 2;  // 0602DEE8 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0602DEEA shlr r0
    c.r[0] >>= 2;  // 0602DEEC shlr2 r0
    c.r[0] &= 0x1u;  // 0602DEEE and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0602DEF0 tst r0,r0
    if (c.t) { goto L_0602DEFA; }  // 0602DEF2 bt 0x0602DEFA
    c.r[1] = ld32(0x0602DF1Cu);  // 0602DEF4 mov.l 0x0602DF1C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602DEFAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602DEFAu) return; }  // 0602DEF6 jsr @r1 ; nop
L_0602DEFA:
    c.r[15] = c.r[14];  // 0602DEFA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602DEFC lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602DF04u);  // 0602DEFE mov.w 0x0602DF04,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602DF00 rts ; mov.l @r15+,r14
}

void f_0602DF20(SH2Context& c) {
    ran[650] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602DF20 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602DF22 sts.l pr,@-r15
    c.r[1] = ld32(0x0602DF90u);  // 0602DF24 mov.l 0x0602DF90,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602DF2Au; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602DF2Au) return; }  // 0602DF26 jsr @r1 ; mov r15,r14
    c.r[1] = ld32(0x0602DF94u);  // 0602DF2A mov.l 0x0602DF94,r1
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0602DF2C mov.w @r1,r5
    c.r[0] = ld32(0x0602DF98u);  // 0602DF2E mov.l 0x0602DF98,r0
    c.r[4] = 0x0u;  // 0602DF30 mov #0,r4
    { const uint32_t x = c.r[0]; c.pr = 0x0602DF36u; c.r[5] = c.r[5] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602DF36u) return; }  // 0602DF32 jsr @r0 ; extu.w r5,r5
    c.r[2] = c.r[0] & 0xFFFFu;  // 0602DF36 extu.w r0,r2
    c.r[1] = ld32(0x0602DF9Cu);  // 0602DF38 mov.l 0x0602DF9C,r1
    c.t = c.r[2] == c.r[1];  // 0602DF3A cmp/eq r1,r2
    { const bool k = c.t; c.r[2] <<= 2; if (k) { goto L_0602DF82; } }  // 0602DF3C bt/s 0x0602DF82 ; shll2 r2
    c.r[1] = ld32(0x0602DFA0u);  // 0602DF40 mov.l 0x0602DFA0,r1
    c.r[1] = ld32(c.r[1]);  // 0602DF42 mov.l @r1,r1
    c.r[1] += c.r[2];  // 0602DF44 add r2,r1
    c.r[1] += 22;  // 0602DF46 add #22,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602DF48 mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0602DF4A extu.b r1,r2
    c.r[0] = c.r[2];  // 0602DF4C mov r2,r0
    c.r[0] >>= 2;  // 0602DF4E shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0602DF50 shlr r0
    c.r[0] >>= 2;  // 0602DF52 shlr2 r0
    c.r[0] &= 0x1u;  // 0602DF54 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0602DF56 tst r0,r0
    if (!c.t) { goto L_0602DF82; }  // 0602DF58 bf 0x0602DF82
    c.r[1] = ld32(0x0602DFA4u);  // 0602DF5A mov.l 0x0602DFA4,r1
    c.r[1] = ld32(c.r[1]);  // 0602DF5C mov.l @r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602DF5E mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0602DF60 extu.b r1,r0
    c.t = c.r[0] == 0x7u;  // 0602DF62 cmp/eq #7,r0
    { const bool k = !c.t; c.r[2] >>= 2; if (k) { goto L_0602DF72; } }  // 0602DF64 bf/s 0x0602DF72 ; shlr2 r2
    c.r[2] >>= 2;  // 0602DF68 shlr2 r2
    c.r[2] >>= 2;  // 0602DF6A shlr2 r2
    c.r[0] = c.r[2];  // 0602DF6C mov r2,r0
    c.t = c.r[0] == 0x1u; goto L_0602DF7A;  // 0602DF6E bra 0x0602DF7A ; cmp/eq #1,r0
L_0602DF72:
    c.r[2] >>= 2;  // 0602DF72 shlr2 r2
    c.r[2] >>= 2;  // 0602DF74 shlr2 r2
    c.r[0] = c.r[2];  // 0602DF76 mov r2,r0
    c.t = c.r[0] == 0x2u;  // 0602DF78 cmp/eq #2,r0
L_0602DF7A:
    if (!c.t) { goto L_0602DF82; }  // 0602DF7A bf 0x0602DF82
    c.r[1] = ld32(0x0602DFA8u);  // 0602DF7C mov.l 0x0602DFA8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602DF82u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602DF82u) return; }  // 0602DF7E jsr @r1 ; nop
L_0602DF82:
    c.r[15] = c.r[14];  // 0602DF82 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602DF84 lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602DF8Cu);  // 0602DF86 mov.w 0x0602DF8C,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602DF88 rts ; mov.l @r15+,r14
}

void f_0602DFAC(SH2Context& c) {
    ran[651] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602DFAC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602DFAE sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0602DFB0 mov r15,r14
    c.r[1] = ld32(0x0602DFE4u);  // 0602DFB2 mov.l 0x0602DFE4,r1
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0602DFB4 mov.w @r1,r5
    c.r[0] = ld32(0x0602DFE8u);  // 0602DFB6 mov.l 0x0602DFE8,r0
    c.r[4] = 0x0u;  // 0602DFB8 mov #0,r4
    { const uint32_t x = c.r[0]; c.pr = 0x0602DFBEu; c.r[5] = c.r[5] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602DFBEu) return; }  // 0602DFBA jsr @r0 ; extu.w r5,r5
    c.r[0] = c.r[0] & 0xFFFFu;  // 0602DFBE extu.w r0,r0
    c.r[1] = ld32(0x0602DFECu);  // 0602DFC0 mov.l 0x0602DFEC,r1
    c.t = c.r[0] == c.r[1];  // 0602DFC2 cmp/eq r1,r0
    { const bool k = c.t; c.r[0] <<= 2; if (k) { goto L_0602DFD6; } }  // 0602DFC4 bt/s 0x0602DFD6 ; shll2 r0
    c.r[1] = ld32(0x0602DFF0u);  // 0602DFC8 mov.l 0x0602DFF0,r1
    c.r[1] = ld32(c.r[1]);  // 0602DFCA mov.l @r1,r1
    c.r[1] += c.r[0];  // 0602DFCC add r0,r1
    c.r[1] += 22;  // 0602DFCE add #22,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602DFD0 mov.b @r1,r0
    c.r[0] &= 0x3Fu;  // 0602DFD2 and #63,r0
    st8(c.r[1], c.r[0]);  // 0602DFD4 mov.b r0,@r1
L_0602DFD6:
    c.r[15] = c.r[14];  // 0602DFD6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602DFD8 lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602DFE0u);  // 0602DFDA mov.w 0x0602DFE0,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602DFDC rts ; mov.l @r15+,r14
}

void f_0602DFF4(SH2Context& c) {
    ran[652] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602DFF4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602DFF6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0602DFF8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0602DFFA mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0602DFFC mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0602DFFE mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602E000 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602E002 sts.l pr,@-r15
    c.r[15] -= 36;  // 0602E004 add #-36,r15
    c.r[14] = c.r[15];  // 0602E006 mov r15,r14
    c.r[0] = 0x0u;  // 0602E008 mov #0,r0
    c.r[1] = ld32(0x0602E0A8u);  // 0602E00A mov.l 0x0602E0A8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602E010u; st32(c.r[14] + 4, c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602E010u) return; }  // 0602E00C jsr @r1 ; mov.l r0,@(4,r14)
    c.r[8] = ld32(0x0602E0ACu);  // 0602E010 mov.l 0x0602E0AC,r8
    c.r[2] = ld32(c.r[8]);  // 0602E012 mov.l @r8,r2
    c.r[0] = ld32(0x0602E0B0u);  // 0602E014 mov.l 0x0602E0B0,r0
    c.r[1] = c.r[2];  // 0602E016 mov r2,r1
    c.r[1] += 1;  // 0602E018 add #1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602E01A mov.b @r1,r4
    c.r[2] += 2;  // 0602E01C add #2,r2
    c.r[4] = c.r[4] & 0xFFu;  // 0602E01E extu.b r4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602E020 mov.b @r2,r1
    c.r[4] <<= 8;  // 0602E022 shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 0602E024 extu.b r1,r1
    { const uint32_t x = c.r[0]; c.pr = 0x0602E02Au; c.r[4] |= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602E02Au) return; }  // 0602E026 jsr @r0 ; or r1,r4
    c.r[1] = c.r[0];  // 0602E02A mov r0,r1
    c.r[0] = ld32(0x0602E0B4u);  // 0602E02C mov.l 0x0602E0B4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602E032u; c.r[4] = c.r[1] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602E032u) return; }  // 0602E02E jsr @r0 ; extu.b r1,r4
    c.r[1] = c.r[0];  // 0602E032 mov r0,r1
    c.r[2] = ld32(c.r[8]);  // 0602E034 mov.l @r8,r2
    c.r[12] = c.r[1] & 0xFFu;  // 0602E036 extu.b r1,r12
    c.r[1] = c.r[2];  // 0602E038 mov r2,r1
    c.r[1] += 1;  // 0602E03A add #1,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602E03C mov.b @r1,r3
    c.r[2] += 2;  // 0602E03E add #2,r2
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602E040 mov.b @r2,r7
    c.r[3] = c.r[3] & 0xFFu;  // 0602E042 extu.b r3,r3
    c.r[3] <<= 8;  // 0602E044 shll8 r3
    c.r[1] = ld32(0x0602E0B8u);  // 0602E046 mov.l 0x0602E0B8,r1
    c.r[2] = c.r[12];  // 0602E048 mov r12,r2
    c.r[1] = ld32(c.r[1]);  // 0602E04A mov.l @r1,r1
    c.r[2] <<= 2;  // 0602E04C shll2 r2
    c.r[2] <<= 2;  // 0602E04E shll2 r2
    c.r[2] += c.r[1];  // 0602E050 add r1,r2
    c.r[2] += 2;  // 0602E052 add #2,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602E054 mov.b @r2,r2
    c.r[1] = ld32(0x0602E0BCu);  // 0602E056 mov.l 0x0602E0BC,r1
    c.r[6] = ld32(c.r[1]);  // 0602E058 mov.l @r1,r6
    c.r[2] = c.r[2] & 0xFFu;  // 0602E05A extu.b r2,r2
    c.r[1] = 0x1Eu;  // 0602E05C mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 0602E05E mul.l r1,r2
    c.r[7] = c.r[7] & 0xFFu;  // 0602E060 extu.b r7,r7
    c.r[1] = c.macl;  // 0602E062 sts macl,r1
    c.r[0] = c.r[1];  // 0602E064 mov r1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[6]);  // 0602E066 mov.w @(r0,r6),r1
    c.r[3] |= c.r[7];  // 0602E068 or r7,r3
    c.r[1] = c.r[1] & 0xFFFFu;  // 0602E06A extu.w r1,r1
    c.t = c.r[3] == c.r[1];  // 0602E06C cmp/eq r1,r3
    if (c.t) { goto L_0602E074; }  // 0602E06E bt 0x0602E074
    goto L_0602E3C8;  // 0602E070 bra 0x0602E3C8 ; nop
L_0602E074:
    c.r[3] = ld32(0x0602E0C0u);  // 0602E074 mov.l 0x0602E0C0,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0602E076 mov.b @r3,r1
    c.r[0] = c.r[1];  // 0602E078 mov r1,r0
    c.r[0] >>= 2;  // 0602E07A shlr2 r0
    c.r[0] >>= 2;  // 0602E07C shlr2 r0
    c.r[0] &= 0x1u;  // 0602E07E and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0602E080 tst r0,r0
    { const bool k = c.t; c.r[0] = 0x1u; if (k) { goto L_0602E0C8; } }  // 0602E082 bt/s 0x0602E0C8 ; mov #1,r0
    c.r[0] = c.r[1];  // 0602E086 mov r1,r0
    c.r[0] &= 0xEFu;  // 0602E088 and #239,r0
    st8(c.r[3], c.r[0]);  // 0602E08A mov.b r0,@r3
    c.r[2] = c.r[3];  // 0602E08C mov r3,r2
    c.r[2] += 4;  // 0602E08E add #4,r2
    c.r[3] += 2;  // 0602E090 add #2,r3
    c.r[1] = 0x0u;  // 0602E092 mov #0,r1
    st16(c.r[3], c.r[1]);  // 0602E094 mov.w r1,@r3
    st16(c.r[2], c.r[1]);  // 0602E096 mov.w r1,@r2
    c.r[2] = ld32(0x0602E0C4u);  // 0602E098 mov.l 0x0602E0C4,r2
    c.r[3] = c.r[2];  // 0602E09A mov r2,r3
    c.r[3] += 4;  // 0602E09C add #4,r3
    c.r[2] += 2;  // 0602E09E add #2,r2
    st16(c.r[2], c.r[1]);  // 0602E0A0 mov.w r1,@r2
    st16(c.r[3], c.r[1]); goto L_0602E0E0;  // 0602E0A2 bra 0x0602E0E0 ; mov.w r1,@r3
L_0602E0C8:
    st32(c.r[14] + 4, c.r[0]);  // 0602E0C8 mov.l r0,@(4,r14)
    c.r[1] = ld32(0x0602E298u);  // 0602E0CA mov.l 0x0602E298,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602E0CC mov.b @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602E294u);  // 0602E0CE mov.w 0x0602E294,r0
    c.r[3] = c.r[1];  // 0602E0D0 mov r1,r3
    c.r[3] += 4;  // 0602E0D2 add #4,r3
    c.r[2] &= c.r[0];  // 0602E0D4 and r0,r2
    st8(c.r[1], c.r[2]);  // 0602E0D6 mov.b r2,@r1
    c.r[1] += 2;  // 0602E0D8 add #2,r1
    c.r[2] = 0x0u;  // 0602E0DA mov #0,r2
    st16(c.r[1], c.r[2]);  // 0602E0DC mov.w r2,@r1
    st16(c.r[3], c.r[2]);  // 0602E0DE mov.w r2,@r3
L_0602E0E0:
    c.r[1] = ld32(0x0602E29Cu);  // 0602E0E0 mov.l 0x0602E29C,r1
    c.r[2] = ld32(c.r[1]);  // 0602E0E2 mov.l @r1,r2
    c.r[7] = ld32(0x0602E2A0u);  // 0602E0E4 mov.l 0x0602E2A0,r7
    c.r[1] = c.r[12];  // 0602E0E6 mov r12,r1
    c.r[1] <<= 2;  // 0602E0E8 shll2 r1
    c.r[1] <<= 2;  // 0602E0EA shll2 r1
    c.r[3] = c.r[1];  // 0602E0EC mov r1,r3
    c.r[0] = c.r[1];  // 0602E0EE mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0602E0F0 mov.b @(r0,r2),r1
    c.r[3] += c.r[2];  // 0602E0F2 add r2,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0602E0F4 extu.b r1,r1
    st32(c.r[14] + 8, c.r[1]);  // 0602E0F6 mov.l r1,@(8,r14)
    c.r[1] = c.r[3];  // 0602E0F8 mov r3,r1
    c.r[1] += 1;  // 0602E0FA add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602E0FC mov.b @r1,r1
    c.r[3] += 2;  // 0602E0FE add #2,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0602E100 extu.b r1,r1
    st32(c.r[14] + 12, c.r[1]);  // 0602E102 mov.l r1,@(12,r14)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0602E104 mov.b @r3,r1
    c.r[4] = 0x0u;  // 0602E106 mov #0,r4
    c.r[9] = c.r[1] & 0xFFu;  // 0602E108 extu.b r1,r9
    c.r[3] = 0x1Eu;  // 0602E10A mov #30,r3
    c.macl = c.r[9] * c.r[3];  // 0602E10C mul.l r3,r9
    c.r[6] = 0x3u;  // 0602E10E mov #3,r6
    c.r[1] = ld32(c.r[7]);  // 0602E110 mov.l @r7,r1
    c.r[2] = c.macl;  // 0602E112 sts macl,r2
    c.r[2] += c.r[1];  // 0602E114 add r1,r2
    c.r[1] = c.r[2];  // 0602E116 mov r2,r1
    c.r[1] += 15;  // 0602E118 add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602E11A mov.b @r1,r1
    c.r[2] += 2;  // 0602E11C add #2,r2
    c.r[10] = c.r[1] & 0xFFu;  // 0602E11E extu.b r1,r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602E120 mov.b @r2,r1
    c.r[0] = 0x20u;  // 0602E122 mov #32,r0
    c.r[1] |= c.r[0];  // 0602E124 or r0,r1
    st8(c.r[2], c.r[1]);  // 0602E126 mov.b r1,@r2
    c.r[1] = ld32(0x0602E2A4u);  // 0602E128 mov.l 0x0602E2A4,r1
    c.r[2] = c.r[10];  // 0602E12A mov r10,r2
    c.r[2] += c.r[2];  // 0602E12C add r2,r2
    c.r[2] += c.r[10];  // 0602E12E add r10,r2
    c.r[1] = ld32(c.r[1]);  // 0602E130 mov.l @r1,r1
    c.r[2] <<= 2;  // 0602E132 shll2 r2
    c.r[2] += c.r[1];  // 0602E134 add r1,r2
    c.r[1] = c.r[2];  // 0602E136 mov r2,r1
    c.r[1] += 2;  // 0602E138 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602E13A mov.b @r1,r1
    c.r[2] += 7;  // 0602E13C add #7,r2
    c.r[5] = c.r[1] & 0xFFu;  // 0602E13E extu.b r1,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602E140 mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602E142 extu.b r1,r1
    st32(c.r[14] + 16, c.r[1]);  // 0602E144 mov.l r1,@(16,r14)
    c.macl = c.r[9] * c.r[3];  // 0602E146 mul.l r3,r9
L_0602E148:
    c.r[1] = ld32(c.r[7]);  // 0602E148 mov.l @r7,r1
    c.r[2] = c.macl;  // 0602E14A sts macl,r2
    c.r[2] += c.r[1];  // 0602E14C add r1,r2
    c.r[2] += c.r[4];  // 0602E14E add r4,r2
    c.r[2] += 17;  // 0602E150 add #17,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602E152 mov.b @r2,r1
    c.r[0] = c.r[14];  // 0602E154 mov r14,r0
    st8(c.r[0] + c.r[4], c.r[1]);  // 0602E156 mov.b r1,@(r0,r4)
    c.r[4] += 1;  // 0602E158 add #1,r4
    c.t = (int32_t)c.r[4] > (int32_t)c.r[6];  // 0602E15A cmp/gt r6,r4
    { const bool k = !c.t; c.r[2] = c.r[5]; if (k) { SH2_POLL(c); goto L_0602E148; } }  // 0602E15C bf/s 0x0602E148 ; mov r5,r2
    c.r[2] += 10;  // 0602E160 add #10,r2
    c.r[1] = 0x62u;  // 0602E162 mov #98,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0602E164 cmp/gt r1,r2
    { const bool k = c.t; c.r[5] = 0x63u; if (k) { goto L_0602E16C; } }  // 0602E166 bt/s 0x0602E16C ; mov #99,r5
    c.r[5] = c.r[2] & 0xFFu;  // 0602E16A extu.b r2,r5
L_0602E16C:
    c.r[0] = ld32(0x0602E2A0u);  // 0602E16C mov.l 0x0602E2A0,r0
    c.r[1] = ld32(c.r[0]);  // 0602E16E mov.l @r0,r1
    c.r[13] = 0xFu;  // 0602E170 mov #15,r13
    c.r[0] = 0x1Eu;  // 0602E172 mov #30,r0
    c.macl = c.r[9] * c.r[0];  // 0602E174 mul.l r0,r9
    c.r[11] = 0x7u;  // 0602E176 mov #7,r11
    c.r[6] = 0x0u;  // 0602E178 mov #0,r6
    c.r[7] = c.macl;  // 0602E17A sts macl,r7
    c.r[7] += c.r[1];  // 0602E17C add r1,r7
    c.r[1] = c.r[7];  // 0602E17E mov r7,r1
    c.r[1] += 3;  // 0602E180 add #3,r1
    c.r[3] = c.r[7];  // 0602E182 mov r7,r3
    c.r[3] += 4;  // 0602E184 add #4,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602E186 mov.b @r1,r1
    c.r[9] = ld32(0x0602E2A8u);  // 0602E188 mov.l 0x0602E2A8,r9
    c.r[1] = c.r[1] & 0xFFu;  // 0602E18A extu.b r1,r1
    c.r[2] = c.r[1];  // 0602E18C mov r1,r2
    c.r[2] >>= 2;  // 0602E18E shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 0602E190 shlr r2
    c.r[0] = c.r[2];  // 0602E192 mov r2,r0
    c.r[0] &= 0xFu;  // 0602E194 and #15,r0
    st32(c.r[14] + 20, c.r[0]);  // 0602E196 mov.l r0,@(20,r14)
    c.r[0] = c.r[1];  // 0602E198 mov r1,r0
    c.r[0] &= 0x7u;  // 0602E19A and #7,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0602E19C mov.b @r3,r1
    c.r[0] += c.r[0];  // 0602E19E add r0,r0
    c.r[1] = c.r[1] & 0xFFu;  // 0602E1A0 extu.b r1,r1
    c.r[2] = c.r[1];  // 0602E1A2 mov r1,r2
    c.r[2] >>= 2;  // 0602E1A4 shlr2 r2
    c.r[2] >>= 2;  // 0602E1A6 shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 0602E1A8 shlr r2
    c.r[2] >>= 2;  // 0602E1AA shlr2 r2
    c.r[0] |= c.r[2];  // 0602E1AC or r2,r0
    st32(c.r[14] + 24, c.r[0]);  // 0602E1AE mov.l r0,@(24,r14)
    c.r[1] >>= 2;  // 0602E1B0 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0602E1B2 shlr r1
    c.r[0] = c.r[1];  // 0602E1B4 mov r1,r0
    c.r[0] &= 0xFu;  // 0602E1B6 and #15,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0602E1B8 mov.w @r3,r1
    st32(c.r[14] + 28, c.r[0]);  // 0602E1BA mov.l r0,@(28,r14)
    c.r[0] = c.r[1];  // 0602E1BC mov r1,r0
    c.r[0] >>= 2;  // 0602E1BE shlr2 r0
    c.r[0] >>= 2;  // 0602E1C0 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0602E1C2 shlr r0
    c.r[0] >>= 2;  // 0602E1C4 shlr2 r0
    c.r[0] &= 0xFu;  // 0602E1C6 and #15,r0
    st32(c.r[14] + 32, c.r[0]);  // 0602E1C8 mov.l r0,@(32,r14)
    c.r[1] = c.r[7];  // 0602E1CA mov r7,r1
    c.r[1] += 5;  // 0602E1CC add #5,r1
    c.r[7] += 6;  // 0602E1CE add #6,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602E1D0 mov.b @r1,r1
    c.r[0] = ld32(0x0602E2ACu);  // 0602E1D2 mov.l 0x0602E2AC,r0
    c.r[1] = c.r[1] & 0xFFu;  // 0602E1D4 extu.b r1,r1
    c.r[2] = c.r[1];  // 0602E1D6 mov r1,r2
    c.r[2] >>= 2;  // 0602E1D8 shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 0602E1DA shlr r2
    c.r[13] &= c.r[2];  // 0602E1DC and r2,r13
    c.r[11] &= c.r[1];  // 0602E1DE and r1,r11
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0602E1E0 mov.b @r7,r1
    c.r[11] += c.r[11];  // 0602E1E2 add r11,r11
    c.r[2] = ld32(c.r[9]);  // 0602E1E4 mov.l @r9,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0602E1E6 extu.b r1,r1
    c.r[1] >>= 2;  // 0602E1E8 shlr2 r1
    c.r[1] >>= 2;  // 0602E1EA shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0602E1EC shlr r1
    c.r[1] >>= 2;  // 0602E1EE shlr2 r1
    c.r[11] |= c.r[1];  // 0602E1F0 or r1,r11
    c.r[1] = c.r[2];  // 0602E1F2 mov r2,r1
    c.r[1] += 5;  // 0602E1F4 add #5,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602E1F6 mov.b @r1,r4
    c.r[2] += 6;  // 0602E1F8 add #6,r2
    c.r[4] = c.r[4] & 0xFFu;  // 0602E1FA extu.b r4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602E1FC mov.b @r2,r1
    c.r[4] <<= 8;  // 0602E1FE shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 0602E200 extu.b r1,r1
    { const uint32_t x = c.r[0]; c.pr = 0x0602E206u; c.r[4] |= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602E206u) return; }  // 0602E202 jsr @r0 ; or r1,r4
    c.r[1] = c.r[0];  // 0602E206 mov r0,r1
    c.r[10] = c.r[1] & 0xFFu;  // 0602E208 extu.b r1,r10
    c.r[8] = (uint32_t)(int16_t)ld16(0x0602E296u);  // 0602E20A mov.w 0x0602E296,r8
    c.t = c.r[10] == c.r[8];  // 0602E20C cmp/eq r8,r10
    { const bool k = !c.t; c.r[2] = c.r[10]; if (k) { goto L_0602E216; } }  // 0602E20E bf/s 0x0602E216 ; mov r10,r2
    goto L_0602E3C8;  // 0602E212 bra 0x0602E3C8 ; nop
L_0602E216:
    c.r[1] = ld32(0x0602E2A4u);  // 0602E216 mov.l 0x0602E2A4,r1
    c.r[2] += c.r[2];  // 0602E218 add r2,r2
    c.r[2] += c.r[10];  // 0602E21A add r10,r2
    c.r[2] <<= 2;  // 0602E21C shll2 r2
    c.r[0] = 0x12u;  // 0602E21E mov #18,r0
    c.r[0] += c.r[14];  // 0602E220 add r14,r0
    c.r[7] = c.r[8];  // 0602E222 mov r8,r7
    c.r[6] = 0x0u;  // 0602E224 mov #0,r6
    c.r[1] = ld32(c.r[1]);  // 0602E226 mov.l @r1,r1
    c.r[5] = 0x0u;  // 0602E228 mov #0,r5
    c.r[2] += c.r[1];  // 0602E22A add r1,r2
    c.r[1] = c.r[2];  // 0602E22C mov r2,r1
    c.r[1] += 6;  // 0602E22E add #6,r1
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[0]);  // 0602E230 mov.w @r0,r0
    c.r[2] += 9;  // 0602E232 add #9,r2
    st16(c.r[1], c.r[0]);  // 0602E234 mov.w r0,@r1
    c.r[1] = 0xFFFFFF96u;  // 0602E236 mov #-106,r1
    st8(c.r[2], c.r[1]);  // 0602E238 mov.b r1,@r2
    c.r[2] = ld32(c.r[9]);  // 0602E23A mov.l @r9,r2
    c.r[0] = ld32(0x0602E2B0u);  // 0602E23C mov.l 0x0602E2B0,r0
    c.r[1] = c.r[2];  // 0602E23E mov r2,r1
    c.r[1] += 3;  // 0602E240 add #3,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602E242 mov.b @r1,r4
    c.r[2] += 4;  // 0602E244 add #4,r2
    c.r[4] = c.r[4] & 0xFFu;  // 0602E246 extu.b r4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602E248 mov.b @r2,r1
    c.r[4] <<= 8;  // 0602E24A shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 0602E24C extu.b r1,r1
    c.r[4] |= c.r[1];  // 0602E24E or r1,r4
    c.r[1] = 0x0u;  // 0602E250 mov #0,r1
    { const uint32_t x = c.r[0]; c.pr = 0x0602E256u; c.r[15] -= 4; st32(c.r[15], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602E256u) return; }  // 0602E252 jsr @r0 ; mov.l r1,@-r15
    c.r[1] = c.r[0];  // 0602E256 mov r0,r1
    c.r[9] = c.r[1] & 0xFFu;  // 0602E258 extu.b r1,r9
    c.t = c.r[9] == c.r[8];  // 0602E25A cmp/eq r8,r9
    { const bool k = !c.t; c.r[15] += 4; if (k) { goto L_0602E264; } }  // 0602E25C bf/s 0x0602E264 ; add #4,r15
    goto L_0602E3C8;  // 0602E260 bra 0x0602E3C8 ; nop
L_0602E264:
    c.r[1] = ld32(0x0602E2B4u);  // 0602E264 mov.l 0x0602E2B4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602E26Au; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602E26Au) return; }  // 0602E266 jsr @r1 ; mov r12,r4
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0602E26A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0602E26C mov.l r13,@-r15
    c.r[0] = ld32(c.r[14] + 32);  // 0602E26E mov.l @(32,r14),r0
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 0602E270 mov.l r0,@-r15
    c.r[7] = ld32(c.r[14] + 28);  // 0602E272 mov.l @(28,r14),r7
    c.r[6] = ld32(c.r[14] + 24);  // 0602E274 mov.l @(24,r14),r6
    c.r[1] = ld32(0x0602E2B8u);  // 0602E276 mov.l 0x0602E2B8,r1
    c.r[5] = ld32(c.r[14] + 20);  // 0602E278 mov.l @(20,r14),r5
    { const uint32_t x = c.r[1]; c.pr = 0x0602E27Eu; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602E27Eu) return; }  // 0602E27A jsr @r1 ; mov r9,r4
    c.r[5] = c.r[10];  // 0602E27E mov r10,r5
    c.r[0] = ld32(0x0602E2BCu);  // 0602E280 mov.l 0x0602E2BC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602E286u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602E286u) return; }  // 0602E282 jsr @r0 ; mov r9,r4
    c.r[4] = 0x0u;  // 0602E286 mov #0,r4
    c.r[15] += 12;  // 0602E288 add #12,r15
    c.r[6] = 0x3u;  // 0602E28A mov #3,r6
    c.r[7] = ld32(0x0602E2A0u);  // 0602E28C mov.l 0x0602E2A0,r7
    c.r[3] = 0x1Eu;  // 0602E28E mov #30,r3
L_0602E290:
    c.macl = c.r[9] * c.r[3]; goto L_0602E2C0;  // 0602E290 bra 0x0602E2C0 ; mul.l r3,r9
L_0602E2C0:
    c.r[0] = c.r[14];  // 0602E2C0 mov r14,r0
    c.r[1] = ld32(c.r[7]);  // 0602E2C2 mov.l @r7,r1
    c.r[2] = c.macl;  // 0602E2C4 sts macl,r2
    c.r[2] += c.r[1];  // 0602E2C6 add r1,r2
    c.r[2] += c.r[4];  // 0602E2C8 add r4,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[4]);  // 0602E2CA mov.b @(r0,r4),r1
    c.r[2] += 17;  // 0602E2CC add #17,r2
    c.r[4] += 1;  // 0602E2CE add #1,r4
    c.t = (int32_t)c.r[4] > (int32_t)c.r[6];  // 0602E2D0 cmp/gt r6,r4
    { const bool k = !c.t; st8(c.r[2], c.r[1]); if (k) { SH2_POLL(c); goto L_0602E290; } }  // 0602E2D2 bf/s 0x0602E290 ; mov.b r1,@r2
    c.r[8] = ld32(0x0602E3ECu);  // 0602E2D6 mov.l 0x0602E3EC,r8
    c.r[12] <<= 2;  // 0602E2D8 shll2 r12
    c.r[12] <<= 2;  // 0602E2DA shll2 r12
    c.r[0] = 0x3u;  // 0602E2DC mov #3,r0
    c.r[2] = 0x1u;  // 0602E2DE mov #1,r2
    c.r[1] = ld32(c.r[8]);  // 0602E2E0 mov.l @r8,r1
    c.r[5] = c.r[9];  // 0602E2E2 mov r9,r5
    c.r[12] += c.r[1];  // 0602E2E4 add r1,r12
    c.r[12] += 3;  // 0602E2E6 add #3,r12
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[12]);  // 0602E2E8 mov.b @r12,r1
    c.r[4] = 0x0u;  // 0602E2EA mov #0,r4
    c.r[11] = c.r[1];  // 0602E2EC mov r1,r11
    c.r[11] >>= 2;  // 0602E2EE shlr2 r11
    c.t = c.r[11] & 1; c.r[11] >>= 1;  // 0602E2F0 shlr r11
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 0602E2F2 mov.l r2,@-r15
    c.r[1] = 0x0u;  // 0602E2F4 mov #0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0602E2F6 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 0602E2F8 mov.l r2,@-r15
    c.r[1] = 0x7u;  // 0602E2FA mov #7,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0602E2FC mov.l r1,@-r15
    c.r[7] = ld32(c.r[14] + 12);  // 0602E2FE mov.l @(12,r14),r7
    c.r[11] &= c.r[0];  // 0602E300 and r0,r11
    c.r[0] = ld32(0x0602E3F0u);  // 0602E302 mov.l 0x0602E3F0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602E308u; c.r[6] = ld32(c.r[14] + 8); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602E308u) return; }  // 0602E304 jsr @r0 ; mov.l @(8,r14),r6
    c.r[1] = c.r[0];  // 0602E308 mov r0,r1
    c.r[12] = c.r[1] & 0xFFu;  // 0602E30A extu.b r1,r12
    c.r[2] = c.r[12];  // 0602E30C mov r12,r2
    c.r[2] <<= 2;  // 0602E30E shll2 r2
    c.r[2] <<= 2;  // 0602E310 shll2 r2
    c.r[1] = ld32(c.r[8]);  // 0602E312 mov.l @r8,r1
    c.r[11] <<= 2;  // 0602E314 shll2 r11
    c.r[11] += c.r[11];  // 0602E316 add r11,r11
    c.r[1] += c.r[2];  // 0602E318 add r2,r1
    c.r[1] += 3;  // 0602E31A add #3,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602E31C mov.b @r1,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602E3E0u);  // 0602E31E mov.w 0x0602E3E0,r0
    c.r[3] &= c.r[0];  // 0602E320 and r0,r3
    c.r[3] |= c.r[11];  // 0602E322 or r11,r3
    st8(c.r[1], c.r[3]);  // 0602E324 mov.b r3,@r1
    c.r[1] = ld32(c.r[8]);  // 0602E326 mov.l @r8,r1
    c.r[1] += c.r[2];  // 0602E328 add r2,r1
    c.r[1] += 3;  // 0602E32A add #3,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602E32C mov.b @r1,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602E3E2u);  // 0602E32E mov.w 0x0602E3E2,r0
    c.r[3] &= c.r[0];  // 0602E330 and r0,r3
    st8(c.r[1], c.r[3]);  // 0602E332 mov.b r3,@r1
    c.r[1] = ld32(c.r[8]);  // 0602E334 mov.l @r8,r1
    c.r[1] += c.r[2];  // 0602E336 add r2,r1
    c.r[1] += 7;  // 0602E338 add #7,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602E33A mov.b @r1,r3
    c.r[0] = 0x10u;  // 0602E33C mov #16,r0
    c.r[3] |= c.r[0];  // 0602E33E or r0,r3
    st8(c.r[1], c.r[3]);  // 0602E340 mov.b r3,@r1
    c.r[1] = ld32(c.r[8]);  // 0602E342 mov.l @r8,r1
    c.r[1] += c.r[2];  // 0602E344 add r2,r1
    c.r[1] += 7;  // 0602E346 add #7,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602E348 mov.b @r1,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602E3E2u);  // 0602E34A mov.w 0x0602E3E2,r0
    c.r[3] &= c.r[0];  // 0602E34C and r0,r3
    st8(c.r[1], c.r[3]);  // 0602E34E mov.b r3,@r1
    c.r[1] = ld32(c.r[8]);  // 0602E350 mov.l @r8,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602E3E4u);  // 0602E352 mov.w 0x0602E3E4,r0
    c.r[1] += c.r[2];  // 0602E354 add r2,r1
    c.r[2] = c.r[1];  // 0602E356 mov r1,r2
    c.r[2] += 3;  // 0602E358 add #3,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602E35A mov.b @r2,r3
    c.r[1] += 4;  // 0602E35C add #4,r1
    c.r[3] &= c.r[0];  // 0602E35E and r0,r3
    st8(c.r[2], c.r[3]);  // 0602E360 mov.b r3,@r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602E362 mov.b @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602E3E6u);  // 0602E364 mov.w 0x0602E3E6,r0
    c.r[2] |= c.r[0];  // 0602E366 or r0,r2
    st8(c.r[1], c.r[2]);  // 0602E368 mov.b r2,@r1
    c.r[1] = ld32(0x0602E3F4u);  // 0602E36A mov.l 0x0602E3F4,r1
    st8(c.r[1], c.r[12]);  // 0602E36C mov.b r12,@r1
    c.r[0] = ld32(c.r[14] + 4);  // 0602E36E mov.l @(4,r14),r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0602E370 tst r0,r0
    { const bool k = c.t; c.r[15] += 16; if (k) { goto L_0602E39C; } }  // 0602E372 bt/s 0x0602E39C ; add #16,r15
    c.r[1] = ld32(0x0602E3F8u);  // 0602E376 mov.l 0x0602E3F8,r1
    c.r[2] = ld32(c.r[1]);  // 0602E378 mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 0602E37A mov #30,r1
    c.macl = c.r[9] * c.r[1];  // 0602E37C mul.l r1,r9
    c.r[1] = c.macl;  // 0602E37E sts macl,r1
    c.r[0] = c.r[1];  // 0602E380 mov r1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 0602E382 mov.w @(r0,r2),r1
    c.r[3] = ld32(0x0602E3FCu);  // 0602E384 mov.l 0x0602E3FC,r3
    st16(c.r[3], c.r[1]);  // 0602E386 mov.w r1,@r3
    c.r[1] = ld32(0x0602E400u);  // 0602E388 mov.l 0x0602E400,r1
    c.r[2] = ld32(c.r[1]);  // 0602E38A mov.l @r1,r2
    c.r[1] = c.r[10];  // 0602E38C mov r10,r1
    c.r[1] += c.r[1];  // 0602E38E add r1,r1
    c.r[1] += c.r[10];  // 0602E390 add r10,r1
    c.r[1] <<= 2;  // 0602E392 shll2 r1
    c.r[0] = c.r[1];  // 0602E394 mov r1,r0
    c.r[3] = ld32(0x0602E404u);  // 0602E396 mov.l 0x0602E404,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]); goto L_0602E3C0;  // 0602E398 bra 0x0602E3C0 ; mov.w @(r0,r2),r1
L_0602E39C:
    c.r[1] = ld32(0x0602E3F8u);  // 0602E39C mov.l 0x0602E3F8,r1
    c.r[2] = ld32(c.r[1]);  // 0602E39E mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 0602E3A0 mov #30,r1
    c.macl = c.r[9] * c.r[1];  // 0602E3A2 mul.l r1,r9
    c.r[1] = c.macl;  // 0602E3A4 sts macl,r1
    c.r[0] = c.r[1];  // 0602E3A6 mov r1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 0602E3A8 mov.w @(r0,r2),r1
    c.r[3] = ld32(0x0602E408u);  // 0602E3AA mov.l 0x0602E408,r3
    st16(c.r[3], c.r[1]);  // 0602E3AC mov.w r1,@r3
    c.r[1] = ld32(0x0602E400u);  // 0602E3AE mov.l 0x0602E400,r1
    c.r[2] = ld32(c.r[1]);  // 0602E3B0 mov.l @r1,r2
    c.r[1] = c.r[10];  // 0602E3B2 mov r10,r1
    c.r[1] += c.r[1];  // 0602E3B4 add r1,r1
    c.r[1] += c.r[10];  // 0602E3B6 add r10,r1
    c.r[1] <<= 2;  // 0602E3B8 shll2 r1
    c.r[0] = c.r[1];  // 0602E3BA mov r1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 0602E3BC mov.w @(r0,r2),r1
    c.r[3] = ld32(0x0602E40Cu);  // 0602E3BE mov.l 0x0602E40C,r3
L_0602E3C0:
    st16(c.r[3], c.r[1]);  // 0602E3C0 mov.w r1,@r3
    c.r[1] = ld32(0x0602E410u);  // 0602E3C2 mov.l 0x0602E410,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602E3C8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602E3C8u) return; }  // 0602E3C4 jsr @r1 ; nop
L_0602E3C8:
    c.r[14] += 36;  // 0602E3C8 add #36,r14
    c.r[15] = c.r[14];  // 0602E3CA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602E3CC lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602E3CE mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0602E3D0 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0602E3D2 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0602E3D4 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0602E3D6 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0602E3D8 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602E3E8u);  // 0602E3DA mov.w 0x0602E3E8,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602E3DC rts ; mov.l @r15+,r8
}

void f_0602E414(SH2Context& c) {
    ran[653] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602E414 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602E416 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602E418 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602E41A sts.l pr,@-r15
    c.r[1] = ld32(0x0602E550u);  // 0602E41C mov.l 0x0602E550,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602E422u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602E422u) return; }  // 0602E41E jsr @r1 ; mov r15,r14
    c.r[2] = ld32(0x0602E554u);  // 0602E422 mov.l 0x0602E554,r2
    c.r[1] = c.r[2];  // 0602E424 mov r2,r1
    c.r[1] += 6;  // 0602E426 add #6,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0602E428 mov.w @r1,r1
    c.r[2] += 10;  // 0602E42A add #10,r2
    c.r[9] = c.r[1] & 0xFFFFu;  // 0602E42C extu.w r1,r9
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0602E42E mov.w @r2,r1
    c.r[8] = c.r[1] & 0xFFFFu;  // 0602E430 extu.w r1,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 0602E432 tst r8,r8
    { const bool k = !c.t; c.r[3] = 0x2u; if (k) { goto L_0602E44A; } }  // 0602E434 bf/s 0x0602E44A ; mov #2,r3
    c.r[2] = ld32(0x0602E558u);  // 0602E438 mov.l 0x0602E558,r2
    c.r[1] = c.r[2];  // 0602E43A mov r2,r1
    c.r[1] += 10;  // 0602E43C add #10,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0602E43E mov.w @r1,r1
    c.r[2] += 6;  // 0602E440 add #6,r2
    c.r[8] = c.r[1] & 0xFFFFu;  // 0602E442 extu.w r1,r8
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0602E444 mov.w @r2,r1
    c.r[3] = 0x1u;  // 0602E446 mov #1,r3
    c.r[9] = c.r[1] & 0xFFFFu;  // 0602E448 extu.w r1,r9
L_0602E44A:
    c.r[1] = ld32(0x0602E55Cu);  // 0602E44A mov.l 0x0602E55C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602E44C mov.b @r1,r1
    c.r[0] = c.r[1];  // 0602E44E mov r1,r0
    c.r[0] >>= 2;  // 0602E450 shlr2 r0
    c.r[0] >>= 2;  // 0602E452 shlr2 r0
    c.r[0] &= 0x3u;  // 0602E454 and #3,r0
    c.r[0] &= c.r[3];  // 0602E456 and r3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0602E458 tst r0,r0
    if (c.t) { goto L_0602E4B0; }  // 0602E45A bt 0x0602E4B0
    c.r[7] = ld32(0x0602E560u);  // 0602E45C mov.l 0x0602E560,r7
    c.r[1] = c.r[7];  // 0602E45E mov r7,r1
    c.r[1] += 1;  // 0602E460 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602E462 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0602E464 mov r1,r0
    c.r[0] >>= 2;  // 0602E466 shlr2 r0
    c.r[0] &= 0x3u;  // 0602E468 and #3,r0
    c.r[0] &= c.r[3];  // 0602E46A and r3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0602E46C tst r0,r0
    if (c.t) { goto L_0602E4B0; }  // 0602E46E bt 0x0602E4B0
    c.r[1] = ld32(0x0602E564u);  // 0602E470 mov.l 0x0602E564,r1
    c.r[2] = ld32(c.r[1]);  // 0602E472 mov.l @r1,r2
    c.r[2] >>= 16;  // 0602E474 shlr16 r2
    c.r[1] = ld32(0x0602E568u);  // 0602E476 mov.l 0x0602E568,r1
    c.t = c.r[2] == c.r[1];  // 0602E478 cmp/eq r1,r2
    { const bool k = c.t; c.t = (c.r[2] & c.r[2]) == 0; if (k) { goto L_0602E4B0; } }  // 0602E47A bt/s 0x0602E4B0 ; tst r2,r2
    if (c.t) { goto L_0602E4B0; }  // 0602E47E bt 0x0602E4B0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0602E480 mov.b @r7,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602E482 extu.b r1,r1
    c.r[0] = c.r[1];  // 0602E484 mov r1,r0
    c.r[0] >>= 2;  // 0602E486 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0602E488 shlr r0
    c.r[0] >>= 2;  // 0602E48A shlr2 r0
    c.r[0] &= 0x1u;  // 0602E48C and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0602E48E tst r0,r0
    { const bool k = c.t; c.r[0] = c.r[1]; if (k) { goto L_0602E4B0; } }  // 0602E490 bt/s 0x0602E4B0 ; mov r1,r0
    c.r[0] >>= 2;  // 0602E494 shlr2 r0
    c.r[0] >>= 2;  // 0602E496 shlr2 r0
    c.r[0] &= 0x1u;  // 0602E498 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0602E49A tst r0,r0
    if (!c.t) { goto L_0602E4B0; }  // 0602E49C bf 0x0602E4B0
    c.r[1] = ld32(0x0602E56Cu);  // 0602E49E mov.l 0x0602E56C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602E4A4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602E4A4u) return; }  // 0602E4A0 jsr @r1 ; nop
    c.r[2] = ld32(0x0602E570u);  // 0602E4A4 mov.l 0x0602E570,r2
    c.r[1] = c.r[2];  // 0602E4A6 mov r2,r1
    c.r[1] += 28;  // 0602E4A8 add #28,r1
    st16(c.r[1], c.r[8]);  // 0602E4AA mov.w r8,@r1
    c.r[2] += 26;  // 0602E4AC add #26,r2
    st16(c.r[2], c.r[9]);  // 0602E4AE mov.w r9,@r2
L_0602E4B0:
    c.r[2] = ld32(0x0602E574u);  // 0602E4B0 mov.l 0x0602E574,r2
    c.r[1] = c.r[2];  // 0602E4B2 mov r2,r1
    c.r[1] += 6;  // 0602E4B4 add #6,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0602E4B6 mov.w @r1,r1
    c.r[2] += 10;  // 0602E4B8 add #10,r2
    c.r[9] = c.r[1] & 0xFFFFu;  // 0602E4BA extu.w r1,r9
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0602E4BC mov.w @r2,r1
    c.r[8] = c.r[1] & 0xFFFFu;  // 0602E4BE extu.w r1,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 0602E4C0 tst r8,r8
    { const bool k = !c.t; c.r[3] = 0x2u; if (k) { goto L_0602E4D8; } }  // 0602E4C2 bf/s 0x0602E4D8 ; mov #2,r3
    c.r[2] = ld32(0x0602E578u);  // 0602E4C6 mov.l 0x0602E578,r2
    c.r[1] = c.r[2];  // 0602E4C8 mov r2,r1
    c.r[1] += 10;  // 0602E4CA add #10,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0602E4CC mov.w @r1,r1
    c.r[2] += 6;  // 0602E4CE add #6,r2
    c.r[8] = c.r[1] & 0xFFFFu;  // 0602E4D0 extu.w r1,r8
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0602E4D2 mov.w @r2,r1
    c.r[3] = 0x1u;  // 0602E4D4 mov #1,r3
    c.r[9] = c.r[1] & 0xFFFFu;  // 0602E4D6 extu.w r1,r9
L_0602E4D8:
    c.r[1] = ld32(0x0602E57Cu);  // 0602E4D8 mov.l 0x0602E57C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602E4DA mov.b @r1,r1
    c.r[0] = c.r[1];  // 0602E4DC mov r1,r0
    c.r[0] >>= 2;  // 0602E4DE shlr2 r0
    c.r[0] >>= 2;  // 0602E4E0 shlr2 r0
    c.r[0] &= 0x3u;  // 0602E4E2 and #3,r0
    c.r[0] &= c.r[3];  // 0602E4E4 and r3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0602E4E6 tst r0,r0
    if (c.t) { goto L_0602E53E; }  // 0602E4E8 bt 0x0602E53E
    c.r[7] = ld32(0x0602E580u);  // 0602E4EA mov.l 0x0602E580,r7
    c.r[1] = c.r[7];  // 0602E4EC mov r7,r1
    c.r[1] += 1;  // 0602E4EE add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602E4F0 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0602E4F2 mov r1,r0
    c.r[0] >>= 2;  // 0602E4F4 shlr2 r0
    c.r[0] &= 0x3u;  // 0602E4F6 and #3,r0
    c.r[0] &= c.r[3];  // 0602E4F8 and r3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0602E4FA tst r0,r0
    if (c.t) { goto L_0602E53E; }  // 0602E4FC bt 0x0602E53E
    c.r[1] = ld32(0x0602E564u);  // 0602E4FE mov.l 0x0602E564,r1
    c.r[2] = ld32(c.r[1]);  // 0602E500 mov.l @r1,r2
    c.r[1] = ld32(0x0602E568u);  // 0602E502 mov.l 0x0602E568,r1
    c.r[2] &= c.r[1];  // 0602E504 and r1,r2
    c.t = c.r[2] == c.r[1];  // 0602E506 cmp/eq r1,r2
    { const bool k = c.t; c.t = (c.r[2] & c.r[2]) == 0; if (k) { goto L_0602E53E; } }  // 0602E508 bt/s 0x0602E53E ; tst r2,r2
    if (c.t) { goto L_0602E53E; }  // 0602E50C bt 0x0602E53E
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0602E50E mov.b @r7,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602E510 extu.b r1,r1
    c.r[0] = c.r[1];  // 0602E512 mov r1,r0
    c.r[0] >>= 2;  // 0602E514 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0602E516 shlr r0
    c.r[0] >>= 2;  // 0602E518 shlr2 r0
    c.r[0] &= 0x1u;  // 0602E51A and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0602E51C tst r0,r0
    { const bool k = c.t; c.r[0] = c.r[1]; if (k) { goto L_0602E53E; } }  // 0602E51E bt/s 0x0602E53E ; mov r1,r0
    c.r[0] >>= 2;  // 0602E522 shlr2 r0
    c.r[0] >>= 2;  // 0602E524 shlr2 r0
    c.r[0] &= 0x1u;  // 0602E526 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0602E528 tst r0,r0
    if (!c.t) { goto L_0602E53E; }  // 0602E52A bf 0x0602E53E
    c.r[1] = ld32(0x0602E56Cu);  // 0602E52C mov.l 0x0602E56C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602E532u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602E532u) return; }  // 0602E52E jsr @r1 ; nop
    c.r[2] = ld32(0x0602E570u);  // 0602E532 mov.l 0x0602E570,r2
    c.r[1] = c.r[2];  // 0602E534 mov r2,r1
    c.r[1] += 28;  // 0602E536 add #28,r1
    st16(c.r[1], c.r[8]);  // 0602E538 mov.w r8,@r1
    c.r[2] += 26;  // 0602E53A add #26,r2
    st16(c.r[2], c.r[9]);  // 0602E53C mov.w r9,@r2
L_0602E53E:
    c.r[15] = c.r[14];  // 0602E53E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602E540 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602E542 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0602E544 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602E54Cu);  // 0602E546 mov.w 0x0602E54C,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602E548 rts ; mov.l @r15+,r8
}

void f_0602E584(SH2Context& c) {
    ran[654] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602E584 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602E586 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0602E588 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0602E58A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602E58C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602E58E sts.l pr,@-r15
    c.r[1] = ld32(0x0602E6C8u);  // 0602E590 mov.l 0x0602E6C8,r1
    c.r[1] = ld32(c.r[1]);  // 0602E592 mov.l @r1,r1
    c.r[1] += 1;  // 0602E594 add #1,r1
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602E596 mov.b @r1,r8
    c.r[14] = c.r[15];  // 0602E598 mov r15,r14
    c.r[1] = ld32(0x0602E6CCu);  // 0602E59A mov.l 0x0602E6CC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602E5A0u; c.r[10] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602E5A0u) return; }  // 0602E59C jsr @r1 ; mov r8,r10
    c.r[1] = ld32(0x0602E6D0u);  // 0602E5A0 mov.l 0x0602E6D0,r1
    c.r[0] = ld32(0x0602E6D4u);  // 0602E5A2 mov.l 0x0602E6D4,r0
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0602E5A4 mov.w @r1,r5
    c.r[4] = 0x0u;  // 0602E5A6 mov #0,r4
    { const uint32_t x = c.r[0]; c.pr = 0x0602E5ACu; c.r[5] = c.r[5] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602E5ACu) return; }  // 0602E5A8 jsr @r0 ; extu.w r5,r5
    c.r[9] = c.r[0] & 0xFFFFu;  // 0602E5AC extu.w r0,r9
    c.r[1] = ld32(0x0602E6D8u);  // 0602E5AE mov.l 0x0602E6D8,r1
    c.t = c.r[9] == c.r[1];  // 0602E5B0 cmp/eq r1,r9
    { const bool k = c.t; c.t = (int32_t)c.r[8] >= 0; if (k) { goto L_0602E6B0; } }  // 0602E5B2 bt/s 0x0602E6B0 ; cmp/pz r8
    { const bool k = !c.t; c.r[2] = c.r[9]; if (k) { goto L_0602E620; } }  // 0602E5B6 bf/s 0x0602E620 ; mov r9,r2
    c.r[1] = ld32(0x0602E6DCu);  // 0602E5BA mov.l 0x0602E6DC,r1
    c.r[2] <<= 2;  // 0602E5BC shll2 r2
    c.r[2] += c.r[1];  // 0602E5BE add r1,r2
    c.r[4] = c.r[2];  // 0602E5C0 mov r2,r4
    c.r[4] += 2;  // 0602E5C2 add #2,r4
    c.r[3] = 0x1Fu;  // 0602E5C4 mov #31,r3
    c.r[6] = c.r[2];  // 0602E5C6 mov r2,r6
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[4]);  // 0602E5C8 mov.b @r4,r5
    c.r[6] += 3;  // 0602E5CA add #3,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0602E5CC mov.b @r6,r1
    c.r[3] &= c.r[5];  // 0602E5CE and r5,r3
    c.r[3] <<= 2;  // 0602E5D0 shll2 r3
    c.r[3] += c.r[3];  // 0602E5D2 add r3,r3
    c.r[3] <<= 2;  // 0602E5D4 shll2 r3
    c.r[7] = c.r[1] & 0xFFu;  // 0602E5D6 extu.b r1,r7
    c.r[7] >>= 2;  // 0602E5D8 shlr2 r7
    c.t = c.r[7] & 1; c.r[7] >>= 1;  // 0602E5DA shlr r7
    c.r[7] |= c.r[3];  // 0602E5DC or r3,r7
    c.r[2] = c.r[7];  // 0602E5DE mov r7,r2
    c.r[2] += c.r[8];  // 0602E5E0 add r8,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602E6C2u);  // 0602E5E2 mov.w 0x0602E6C2,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0602E5E4 cmp/gt r1,r2
    { const bool k = c.t; c.r[0] = c.r[5]; if (k) { goto L_0602E612; } }  // 0602E5E6 bt/s 0x0602E612 ; mov r5,r0
    c.r[7] += c.r[8];  // 0602E5EA add r8,r7
    c.r[2] = c.r[7] & 0xFFFFu;  // 0602E5EC extu.w r7,r2
    c.r[0] = c.r[2];  // 0602E5EE mov r2,r0
    c.r[0] >>= 2;  // 0602E5F0 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0602E5F2 shlr r0
    c.r[0] >>= 2;  // 0602E5F4 shlr2 r0
    c.r[0] &= 0x1Fu;  // 0602E5F6 and #31,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602E6C4u);  // 0602E5F8 mov.w 0x0602E6C4,r1
    c.r[1] &= c.r[5];  // 0602E5FA and r5,r1
    c.r[1] |= c.r[0];  // 0602E5FC or r0,r1
    st8(c.r[4], c.r[1]);  // 0602E5FE mov.b r1,@r4
    c.r[11] = 0x1Fu;  // 0602E600 mov #31,r11
    c.r[2] &= c.r[11];  // 0602E602 and r11,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0602E604 mov.b @r6,r0
    c.r[2] <<= 2;  // 0602E606 shll2 r2
    c.r[2] += c.r[2];  // 0602E608 add r2,r2
    c.r[0] &= 0x7u;  // 0602E60A and #7,r0
    c.r[0] |= c.r[2];  // 0602E60C or r2,r0
    st8(c.r[6], c.r[0]); goto L_0602E67E;  // 0602E60E bra 0x0602E67E ; mov.b r0,@r6
L_0602E612:
    c.r[0] |= 0x1Fu;  // 0602E612 or #31,r0
    st8(c.r[4], c.r[0]);  // 0602E614 mov.b r0,@r4
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0602E616 mov.b @r6,r0
    c.r[0] &= 0x7u;  // 0602E618 and #7,r0
    c.r[0] |= 0x38u;  // 0602E61A or #56,r0
    st8(c.r[6], c.r[0]); goto L_0602E67E;  // 0602E61C bra 0x0602E67E ; mov.b r0,@r6
L_0602E620:
    c.r[1] = ld32(0x0602E6DCu);  // 0602E620 mov.l 0x0602E6DC,r1
    c.r[2] <<= 2;  // 0602E622 shll2 r2
    c.r[2] += c.r[1];  // 0602E624 add r1,r2
    c.r[5] = c.r[2];  // 0602E626 mov r2,r5
    c.r[5] += 2;  // 0602E628 add #2,r5
    c.r[3] = 0x1Fu;  // 0602E62A mov #31,r3
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[5]);  // 0602E62C mov.b @r5,r6
    c.r[2] += 3;  // 0602E62E add #3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602E630 mov.b @r2,r1
    c.r[3] &= c.r[6];  // 0602E632 and r6,r3
    c.r[3] <<= 2;  // 0602E634 shll2 r3
    c.r[3] += c.r[3];  // 0602E636 add r3,r3
    c.r[3] <<= 2;  // 0602E638 shll2 r3
    c.r[7] = c.r[1] & 0xFFu;  // 0602E63A extu.b r1,r7
    c.r[7] >>= 2;  // 0602E63C shlr2 r7
    c.t = c.r[7] & 1; c.r[7] >>= 1;  // 0602E63E shlr r7
    c.r[7] |= c.r[3];  // 0602E640 or r3,r7
    c.r[1] = c.r[7];  // 0602E642 mov r7,r1
    c.r[1] += c.r[10];  // 0602E644 add r10,r1
    c.t = (int32_t)c.r[1] > 0;  // 0602E646 cmp/pl r1
    { const bool k = !c.t; c.r[7] += c.r[10]; if (k) { goto L_0602E670; } }  // 0602E648 bf/s 0x0602E670 ; add r10,r7
    c.r[3] = c.r[7] & 0xFFFFu;  // 0602E64C extu.w r7,r3
    c.r[0] = c.r[3];  // 0602E64E mov r3,r0
    c.r[0] >>= 2;  // 0602E650 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0602E652 shlr r0
    c.r[0] >>= 2;  // 0602E654 shlr2 r0
    c.r[0] &= 0x1Fu;  // 0602E656 and #31,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602E6C4u);  // 0602E658 mov.w 0x0602E6C4,r1
    c.r[1] &= c.r[6];  // 0602E65A and r6,r1
    c.r[1] |= c.r[0];  // 0602E65C or r0,r1
    st8(c.r[5], c.r[1]);  // 0602E65E mov.b r1,@r5
    c.r[11] = 0x1Fu;  // 0602E660 mov #31,r11
    c.r[3] &= c.r[11];  // 0602E662 and r11,r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602E664 mov.b @r2,r0
    c.r[3] <<= 2;  // 0602E666 shll2 r3
    c.r[3] += c.r[3];  // 0602E668 add r3,r3
    c.r[0] &= 0x7u;  // 0602E66A and #7,r0
    c.r[0] |= c.r[3]; goto L_0602E67C;  // 0602E66C bra 0x0602E67C ; or r3,r0
L_0602E670:
    c.r[0] = c.r[6];  // 0602E670 mov r6,r0
    c.r[0] &= 0xE0u;  // 0602E672 and #224,r0
    st8(c.r[5], c.r[0]);  // 0602E674 mov.b r0,@r5
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602E676 mov.b @r2,r0
    c.r[0] &= 0x7u;  // 0602E678 and #7,r0
    c.r[0] |= 0x8u;  // 0602E67A or #8,r0
L_0602E67C:
    st8(c.r[2], c.r[0]);  // 0602E67C mov.b r0,@r2
L_0602E67E:
    c.r[1] = ld32(0x0602E6E0u);  // 0602E67E mov.l 0x0602E6E0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602E684u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602E684u) return; }  // 0602E680 jsr @r1 ; mov r9,r4
    c.r[3] = ld32(0x0602E6E4u);  // 0602E684 mov.l 0x0602E6E4,r3
    c.r[1] = ld32(0x0602E6DCu);  // 0602E686 mov.l 0x0602E6DC,r1
    c.r[2] = c.r[9];  // 0602E688 mov r9,r2
    c.r[2] <<= 2;  // 0602E68A shll2 r2
    c.r[2] += c.r[1];  // 0602E68C add r1,r2
    c.r[1] = c.r[2];  // 0602E68E mov r2,r1
    c.r[1] += 2;  // 0602E690 add #2,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602E692 mov.b @r1,r0
    c.r[2] += 3;  // 0602E694 add #3,r2
    c.r[0] &= 0x1Fu;  // 0602E696 and #31,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602E698 mov.b @r2,r1
    c.r[0] <<= 2;  // 0602E69A shll2 r0
    c.r[0] += c.r[0];  // 0602E69C add r0,r0
    c.r[0] <<= 2;  // 0602E69E shll2 r0
    c.r[1] = c.r[1] & 0xFFu;  // 0602E6A0 extu.b r1,r1
    c.r[1] >>= 2;  // 0602E6A2 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0602E6A4 shlr r1
    c.r[1] |= c.r[0];  // 0602E6A6 or r0,r1
    st32(c.r[3] + 20, c.r[1]);  // 0602E6A8 mov.l r1,@(20,r3)
    c.r[1] = ld32(0x0602E6E8u);  // 0602E6AA mov.l 0x0602E6E8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602E6B0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602E6B0u) return; }  // 0602E6AC jsr @r1 ; nop
L_0602E6B0:
    c.r[15] = c.r[14];  // 0602E6B0 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602E6B2 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602E6B4 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0602E6B6 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0602E6B8 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0602E6BA mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602E6C6u);  // 0602E6BC mov.w 0x0602E6C6,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602E6BE rts ; mov.l @r15+,r8
}

void f_0602E6EC(SH2Context& c) {
    ran[655] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602E6EC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602E6EE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0602E6F0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0602E6F2 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602E6F4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602E6F6 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0602E6F8 mov r15,r14
    c.r[8] = ld32(0x0602E870u);  // 0602E6FA mov.l 0x0602E870,r8
    c.r[2] = ld32(c.r[8]);  // 0602E6FC mov.l @r8,r2
    c.r[9] = ld32(0x0602E874u);  // 0602E6FE mov.l 0x0602E874,r9
    c.r[1] = c.r[2];  // 0602E700 mov r2,r1
    c.r[1] += 1;  // 0602E702 add #1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602E704 mov.b @r1,r4
    c.r[2] += 2;  // 0602E706 add #2,r2
    c.r[4] = c.r[4] & 0xFFu;  // 0602E708 extu.b r4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602E70A mov.b @r2,r1
    c.r[4] <<= 8;  // 0602E70C shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 0602E70E extu.b r1,r1
    { const uint32_t x = c.r[9]; c.pr = 0x0602E714u; c.r[4] |= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602E714u) return; }  // 0602E710 jsr @r9 ; or r1,r4
    c.r[2] = ld32(c.r[8]);  // 0602E714 mov.l @r8,r2
    c.r[10] = c.r[0] & 0xFFu;  // 0602E716 extu.b r0,r10
    c.r[1] = c.r[2];  // 0602E718 mov r2,r1
    c.r[1] += 3;  // 0602E71A add #3,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602E71C mov.b @r1,r4
    c.r[2] += 4;  // 0602E71E add #4,r2
    c.r[4] = c.r[4] & 0xFFu;  // 0602E720 extu.b r4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602E722 mov.b @r2,r1
    c.r[4] <<= 8;  // 0602E724 shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 0602E726 extu.b r1,r1
    { const uint32_t x = c.r[9]; c.pr = 0x0602E72Cu; c.r[4] |= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602E72Cu) return; }  // 0602E728 jsr @r9 ; or r1,r4
    c.r[8] = (uint32_t)(int16_t)ld16(0x0602E86Au);  // 0602E72C mov.w 0x0602E86A,r8
    c.t = c.r[10] == c.r[8];  // 0602E72E cmp/eq r8,r10
    { const bool k = !c.t; c.r[9] = c.r[0] & 0xFFu; if (k) { goto L_0602E738; } }  // 0602E730 bf/s 0x0602E738 ; extu.b r0,r9
    goto L_0602E908;  // 0602E734 bra 0x0602E908 ; nop
L_0602E738:
    c.t = c.r[9] == c.r[8];  // 0602E738 cmp/eq r8,r9
    if (!c.t) { goto L_0602E740; }  // 0602E73A bf 0x0602E740
    goto L_0602E908;  // 0602E73C bra 0x0602E908 ; nop
L_0602E740:
    c.r[0] = ld32(0x0602E878u);  // 0602E740 mov.l 0x0602E878,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602E746u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602E746u) return; }  // 0602E742 jsr @r0 ; mov r9,r4
    c.r[7] = c.r[0] & 0xFFu;  // 0602E746 extu.b r0,r7
    c.r[3] = ld32(0x0602E87Cu);  // 0602E748 mov.l 0x0602E87C,r3
    c.r[2] = c.r[7];  // 0602E74A mov r7,r2
    c.r[2] <<= 2;  // 0602E74C shll2 r2
    c.r[2] <<= 2;  // 0602E74E shll2 r2
    c.r[1] = ld32(c.r[3]);  // 0602E750 mov.l @r3,r1
    c.r[6] = 0x0u;  // 0602E752 mov #0,r6
    c.r[2] += c.r[1];  // 0602E754 add r1,r2
    c.r[2] += 2;  // 0602E756 add #2,r2
    st8(c.r[2], c.r[10]);  // 0602E758 mov.b r10,@r2
    c.r[4] = ld32(c.r[3]);  // 0602E75A mov.l @r3,r4
    c.r[5] = 0x0u;  // 0602E75C mov #0,r5
    c.r[3] = c.r[4];  // 0602E75E mov r4,r3
L_0602E760:
    c.r[0] = c.r[5];  // 0602E760 mov r5,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[4]);  // 0602E762 mov.b @(r0,r4),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602E764 extu.b r1,r1
    c.t = c.r[1] == c.r[8];  // 0602E766 cmp/eq r8,r1
    { const bool k = c.t; c.r[2] = c.r[3]; if (k) { goto L_0602E780; } }  // 0602E768 bt/s 0x0602E780 ; mov r3,r2
    c.r[2] += 3;  // 0602E76C add #3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602E76E mov.b @r2,r1
    c.r[0] = c.r[1];  // 0602E770 mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0602E772 shlr r0
    c.r[0] &= 0x3u;  // 0602E774 and #3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0602E776 tst r0,r0
    { const bool k = !c.t; c.t = c.r[6] == c.r[7]; if (k) { goto L_0602E780; } }  // 0602E778 bf/s 0x0602E780 ; cmp/eq r7,r6
    { const bool k = !c.t; c.r[1] = c.r[7]; if (k) { goto L_0602E822; } }  // 0602E77C bf/s 0x0602E822 ; mov r7,r1
L_0602E780:
    c.r[3] += 16;  // 0602E780 add #16,r3
    c.r[6] += 1;  // 0602E782 add #1,r6
    c.r[1] = 0x49u;  // 0602E784 mov #73,r1
    c.t = (int32_t)c.r[6] > (int32_t)c.r[1];  // 0602E786 cmp/gt r1,r6
    { const bool k = !c.t; c.r[5] += 16; if (k) { SH2_POLL(c); goto L_0602E760; } }  // 0602E788 bf/s 0x0602E760 ; add #16,r5
L_0602E78C:
    c.r[1] = ld32(0x0602E87Cu);  // 0602E78C mov.l 0x0602E87C,r1
    c.r[7] <<= 2;  // 0602E78E shll2 r7
    c.r[7] <<= 2;  // 0602E790 shll2 r7
    c.r[5] = ld32(0x0602E880u);  // 0602E792 mov.l 0x0602E880,r5
    c.r[6] = 0x1Eu;  // 0602E794 mov #30,r6
    c.r[8] = ld32(0x0602E884u);  // 0602E796 mov.l 0x0602E884,r8
    c.r[1] = ld32(c.r[1]);  // 0602E798 mov.l @r1,r1
    c.macl = c.r[10] * c.r[6];  // 0602E79A mul.l r6,r10
    c.r[7] += c.r[1];  // 0602E79C add r1,r7
    c.r[1] = ld32(c.r[5]);  // 0602E79E mov.l @r5,r1
    c.r[4] = c.macl;  // 0602E7A0 sts macl,r4
    c.r[1] += c.r[4];  // 0602E7A2 add r4,r1
    c.r[1] += 15;  // 0602E7A4 add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602E7A6 mov.b @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602E86Cu);  // 0602E7A8 mov.w 0x0602E86C,r0
    c.r[2] = ld32(c.r[8]);  // 0602E7AA mov.l @r8,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0602E7AC extu.b r1,r1
    c.r[3] = c.r[1];  // 0602E7AE mov r1,r3
    c.r[3] += c.r[3];  // 0602E7B0 add r3,r3
    c.r[3] += c.r[1];  // 0602E7B2 add r1,r3
    c.r[3] <<= 2;  // 0602E7B4 shll2 r3
    c.r[3] += c.r[2];  // 0602E7B6 add r2,r3
    c.r[3] += 3;  // 0602E7B8 add #3,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0602E7BA mov.b @r3,r1
    c.macl = c.r[9] * c.r[6];  // 0602E7BC mul.l r6,r9
    c.r[3] = c.r[1] & 0xFFu;  // 0602E7BE extu.b r1,r3
    c.r[3] >>= 2;  // 0602E7C0 shlr2 r3
    c.r[3] >>= 2;  // 0602E7C2 shlr2 r3
    c.r[3] >>= 2;  // 0602E7C4 shlr2 r3
    c.r[2] = c.r[3];  // 0602E7C6 mov r3,r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 0602E7C8 shlr r2
    c.r[1] = c.r[7];  // 0602E7CA mov r7,r1
    c.r[1] += 3;  // 0602E7CC add #3,r1
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602E7CE mov.b @r1,r11
    c.r[7] += 4;  // 0602E7D0 add #4,r7
    c.r[11] &= c.r[0];  // 0602E7D2 and r0,r11
    c.r[11] |= c.r[2];  // 0602E7D4 or r2,r11
    st8(c.r[1], c.r[11]);  // 0602E7D6 mov.b r11,@r1
    c.r[0] = 0x1u;  // 0602E7D8 mov #1,r0
    c.r[3] &= c.r[0];  // 0602E7DA and r0,r3
    c.r[3] <<= 2;  // 0602E7DC shll2 r3
    c.r[3] <<= 2;  // 0602E7DE shll2 r3
    c.r[3] += c.r[3];  // 0602E7E0 add r3,r3
    c.r[3] <<= 2;  // 0602E7E2 shll2 r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0602E7E4 mov.b @r7,r1
    c.r[0] = 0x7Fu;  // 0602E7E6 mov #127,r0
    c.r[1] &= c.r[0];  // 0602E7E8 and r0,r1
    c.r[1] |= c.r[3];  // 0602E7EA or r3,r1
    st8(c.r[7], c.r[1]);  // 0602E7EC mov.b r1,@r7
    c.r[3] = ld32(0x0602E888u);  // 0602E7EE mov.l 0x0602E888,r3
    c.r[5] = ld32(c.r[5]);  // 0602E7F0 mov.l @r5,r5
    c.r[1] = c.macl;  // 0602E7F2 sts macl,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0602E7F4 mov.w @r3,r2
    c.r[0] = c.r[1];  // 0602E7F6 mov r1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[5]);  // 0602E7F8 mov.w @(r0,r5),r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 0602E7FA extu.w r2,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 0602E7FC extu.w r1,r1
    c.t = c.r[2] == c.r[1];  // 0602E7FE cmp/eq r1,r2
    { const bool k = !c.t; c.r[2] = c.r[4]; if (k) { goto L_0602E890; } }  // 0602E800 bf/s 0x0602E890 ; mov r4,r2
    c.r[2] += c.r[5];  // 0602E804 add r5,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0602E806 mov.w @r2,r1
    st16(c.r[3], c.r[1]);  // 0602E808 mov.w r1,@r3
    c.r[2] += 15;  // 0602E80A add #15,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602E80C mov.b @r2,r1
    c.r[3] = ld32(c.r[8]);  // 0602E80E mov.l @r8,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0602E810 extu.b r1,r1
    c.r[2] = c.r[1];  // 0602E812 mov r1,r2
    c.r[2] += c.r[2];  // 0602E814 add r2,r2
    c.r[2] += c.r[1];  // 0602E816 add r1,r2
    c.r[2] <<= 2;  // 0602E818 shll2 r2
    c.r[0] = c.r[2];  // 0602E81A mov r2,r0
    c.r[7] = ld32(0x0602E88Cu);  // 0602E81C mov.l 0x0602E88C,r7
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]); goto L_0602E8AE;  // 0602E81E bra 0x0602E8AE ; mov.w @(r0,r3),r1
L_0602E822:
    c.r[1] <<= 2;  // 0602E822 shll2 r1
    c.r[1] <<= 2;  // 0602E824 shll2 r1
    c.r[1] += c.r[4];  // 0602E826 add r4,r1
    c.r[3] += 4;  // 0602E828 add #4,r3
    c.r[1] += 4;  // 0602E82A add #4,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0602E82C mov.b @r3,r0
    c.r[2] = 0x1Eu;  // 0602E82E mov #30,r2
    c.r[2] &= c.r[0];  // 0602E830 and r0,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602E832 mov.b @r1,r0
    c.r[0] &= 0xE1u;  // 0602E834 and #225,r0
    c.r[0] |= c.r[2];  // 0602E836 or r2,r0
    st8(c.r[1], c.r[0]); SH2_POLL(c); goto L_0602E78C;  // 0602E838 bra 0x0602E78C ; mov.b r0,@r1
L_0602E83C:
    c.r[1] = ld32(0x0602E880u);  // 0602E83C mov.l 0x0602E880,r1
    c.r[2] = ld32(c.r[1]);  // 0602E83E mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 0602E840 mov #30,r1
    c.macl = c.r[10] * c.r[1];  // 0602E842 mul.l r1,r10
    c.r[3] = c.macl;  // 0602E844 sts macl,r3
    c.r[3] += c.r[2];  // 0602E846 add r2,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0602E848 mov.w @r3,r1
    c.r[0] = c.r[11];  // 0602E84A mov r11,r0
    st16(c.r[0] + c.r[7], c.r[1]);  // 0602E84C mov.w r1,@(r0,r7)
    c.r[3] += 15;  // 0602E84E add #15,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0602E850 mov.b @r3,r1
    c.r[2] = ld32(0x0602E884u);  // 0602E852 mov.l 0x0602E884,r2
    c.r[3] = ld32(c.r[2]);  // 0602E854 mov.l @r2,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0602E856 extu.b r1,r1
    c.r[2] = c.r[1];  // 0602E858 mov r1,r2
    c.r[2] += c.r[2];  // 0602E85A add r2,r2
    c.r[2] += c.r[1];  // 0602E85C add r1,r2
    c.r[2] <<= 2;  // 0602E85E shll2 r2
    c.r[0] = c.r[2];  // 0602E860 mov r2,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 0602E862 mov.w @(r0,r3),r1
    c.r[5] += 2;  // 0602E864 add #2,r5
    st16(c.r[5], c.r[1]); goto L_0602E8EC;  // 0602E866 bra 0x0602E8EC ; mov.w r1,@r5
L_0602E890:
    c.r[2] += c.r[5];  // 0602E890 add r5,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0602E892 mov.w @r2,r1
    c.r[3] += 2;  // 0602E894 add #2,r3
    st16(c.r[3], c.r[1]);  // 0602E896 mov.w r1,@r3
    c.r[2] += 15;  // 0602E898 add #15,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602E89A mov.b @r2,r1
    c.r[3] = ld32(c.r[8]);  // 0602E89C mov.l @r8,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0602E89E extu.b r1,r1
    c.r[2] = c.r[1];  // 0602E8A0 mov r1,r2
    c.r[2] += c.r[2];  // 0602E8A2 add r2,r2
    c.r[2] += c.r[1];  // 0602E8A4 add r1,r2
    c.r[2] <<= 2;  // 0602E8A6 shll2 r2
    c.r[0] = c.r[2];  // 0602E8A8 mov r2,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 0602E8AA mov.w @(r0,r3),r1
    c.r[7] = ld32(0x0602E920u);  // 0602E8AC mov.l 0x0602E920,r7
L_0602E8AE:
    st16(c.r[7], c.r[1]);  // 0602E8AE mov.w r1,@r7
    c.r[1] = ld32(0x0602E924u);  // 0602E8B0 mov.l 0x0602E924,r1
    c.r[3] = ld32(c.r[1]);  // 0602E8B2 mov.l @r1,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0602E8B4 mov.w @r3,r1
    c.r[2] = ld32(0x0602E928u);  // 0602E8B6 mov.l 0x0602E928,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 0602E8B8 extu.w r1,r1
    c.t = c.r[1] == c.r[2];  // 0602E8BA cmp/eq r2,r1
    { const bool k = c.t; c.r[6] = 0x0u; if (k) { goto L_0602E8EC; } }  // 0602E8BC bt/s 0x0602E8EC ; mov #0,r6
    c.r[7] = c.r[3];  // 0602E8C0 mov r3,r7
    c.r[8] = (uint32_t)(int16_t)ld16(0x0602E91Au);  // 0602E8C2 mov.w 0x0602E91A,r8
    c.r[4] = 0x4Au;  // 0602E8C4 mov #74,r4
    c.r[3] = c.r[2];  // 0602E8C6 mov r2,r3
    c.r[11] = 0x0u;  // 0602E8C8 mov #0,r11
    c.r[5] = c.r[7];  // 0602E8CA mov r7,r5
    c.r[0] = c.r[11];  // 0602E8CC mov r11,r0
L_0602E8CE:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[7]);  // 0602E8CE mov.w @(r0,r7),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0602E8D0 extu.w r1,r1
    c.t = c.r[1] == c.r[8];  // 0602E8D2 cmp/eq r8,r1
    { const bool k = c.t; c.r[2] = c.r[6]; if (k) { SH2_POLL(c); goto L_0602E83C; } }  // 0602E8D4 bt/s 0x0602E83C ; mov r6,r2
    c.r[11] += 4;  // 0602E8D8 add #4,r11
    c.r[5] += 4;  // 0602E8DA add #4,r5
    c.t = (int32_t)c.r[2] > (int32_t)c.r[4];  // 0602E8DC cmp/gt r4,r2
    { const bool k = c.t; c.r[6] += 1; if (k) { goto L_0602E8EC; } }  // 0602E8DE bt/s 0x0602E8EC ; add #1,r6
    c.r[0] = c.r[11];  // 0602E8E2 mov r11,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[7]);  // 0602E8E4 mov.w @(r0,r7),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0602E8E6 extu.w r1,r1
    c.t = c.r[1] == c.r[3];  // 0602E8E8 cmp/eq r3,r1
    if (!c.t) { SH2_POLL(c); goto L_0602E8CE; }  // 0602E8EA bf 0x0602E8CE
L_0602E8EC:
    c.r[1] = ld32(0x0602E92Cu);  // 0602E8EC mov.l 0x0602E92C,r1
    c.r[2] = ld32(c.r[1]);  // 0602E8EE mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 0602E8F0 mov #30,r1
    c.macl = c.r[9] * c.r[1];  // 0602E8F2 mul.l r1,r9
    c.r[1] = c.macl;  // 0602E8F4 sts macl,r1
    c.r[1] += c.r[2];  // 0602E8F6 add r2,r1
    c.r[1] += 15;  // 0602E8F8 add #15,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602E8FA mov.b @r1,r4
    c.r[1] = ld32(0x0602E930u);  // 0602E8FC mov.l 0x0602E930,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602E902u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602E902u) return; }  // 0602E8FE jsr @r1 ; extu.b r4,r4
    c.r[1] = ld32(0x0602E934u);  // 0602E902 mov.l 0x0602E934,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602E908u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602E908u) return; }  // 0602E904 jsr @r1 ; mov r9,r4
L_0602E908:
    c.r[15] = c.r[14];  // 0602E908 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602E90A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602E90C mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0602E90E mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0602E910 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0602E912 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602E91Cu);  // 0602E914 mov.w 0x0602E91C,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602E916 rts ; mov.l @r15+,r8
}

void f_0602E938(SH2Context& c) {
    ran[656] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602E938 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602E93A sts.l pr,@-r15
    c.r[1] = ld32(0x0602E974u);  // 0602E93C mov.l 0x0602E974,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602E942u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602E942u) return; }  // 0602E93E jsr @r1 ; mov r15,r14
    c.r[1] = ld32(0x0602E978u);  // 0602E942 mov.l 0x0602E978,r1
    c.r[2] = ld32(c.r[1]);  // 0602E944 mov.l @r1,r2
    c.r[0] = ld32(0x0602E97Cu);  // 0602E946 mov.l 0x0602E97C,r0
    c.r[1] = c.r[2];  // 0602E948 mov r2,r1
    c.r[1] += 1;  // 0602E94A add #1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602E94C mov.b @r1,r4
    c.r[2] += 2;  // 0602E94E add #2,r2
    c.r[4] = c.r[4] & 0xFFu;  // 0602E950 extu.b r4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602E952 mov.b @r2,r1
    c.r[4] <<= 8;  // 0602E954 shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 0602E956 extu.b r1,r1
    { const uint32_t x = c.r[0]; c.pr = 0x0602E95Cu; c.r[4] |= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602E95Cu) return; }  // 0602E958 jsr @r0 ; or r1,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 0602E95C tst r0,r0
    if (!c.t) { goto L_0602E966; }  // 0602E95E bf 0x0602E966
    c.r[1] = ld32(0x0602E980u);  // 0602E960 mov.l 0x0602E980,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602E966u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602E966u) return; }  // 0602E962 jsr @r1 ; nop
L_0602E966:
    c.r[15] = c.r[14];  // 0602E966 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602E968 lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602E970u);  // 0602E96A mov.w 0x0602E970,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602E96C rts ; mov.l @r15+,r14
}

void f_0602E984(SH2Context& c) {
    ran[657] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602E984 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602E986 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0602E988 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0602E98A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0602E98C mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602E98E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602E990 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0602E992 mov r15,r14
    c.r[11] = 0x0u;  // 0602E994 mov #0,r11
    c.r[8] = 0x0u;  // 0602E996 mov #0,r8
    c.r[10] = 0x0u;  // 0602E998 mov #0,r10
    c.r[12] = ld32(0x0602EA10u);  // 0602E99A mov.l 0x0602EA10,r12
    c.r[9] = c.r[8];  // 0602E99C mov r8,r9
L_0602E99E:
    c.r[9] += c.r[9];  // 0602E99E add r9,r9
    c.r[0] = c.r[9];  // 0602E9A0 mov r9,r0
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[12]);  // 0602E9A2 mov.w @(r0,r12),r5
    c.r[4] = 0x0u;  // 0602E9A4 mov #0,r4
    c.r[0] = ld32(0x0602EA14u);  // 0602E9A6 mov.l 0x0602EA14,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602E9ACu; c.r[5] = c.r[5] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602E9ACu) return; }  // 0602E9A8 jsr @r0 ; extu.w r5,r5
    c.r[1] = c.r[0];  // 0602E9AC mov r0,r1
    c.r[3] = c.r[1] & 0xFFFFu;  // 0602E9AE extu.w r1,r3
    c.r[1] = ld32(0x0602EA18u);  // 0602E9B0 mov.l 0x0602EA18,r1
    c.t = c.r[3] == c.r[1];  // 0602E9B2 cmp/eq r1,r3
    { const bool k = c.t; c.r[1] = c.r[8]; if (k) { goto L_0602E9E8; } }  // 0602E9B4 bt/s 0x0602E9E8 ; mov r8,r1
    c.r[1] = ld32(0x0602EA1Cu);  // 0602E9B8 mov.l 0x0602EA1C,r1
    c.r[2] = ld32(c.r[1]);  // 0602E9BA mov.l @r1,r2
    c.r[3] <<= 2;  // 0602E9BC shll2 r3
    c.r[2] += c.r[3];  // 0602E9BE add r3,r2
    c.r[1] = c.r[2];  // 0602E9C0 mov r2,r1
    c.r[1] += 22;  // 0602E9C2 add #22,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602E9C4 mov.b @r1,r0
    c.r[2] += 23;  // 0602E9C6 add #23,r2
    c.r[0] &= 0x1Fu;  // 0602E9C8 and #31,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602E9CA mov.b @r2,r1
    c.r[0] <<= 2;  // 0602E9CC shll2 r0
    c.r[0] += c.r[0];  // 0602E9CE add r0,r0
    c.r[0] <<= 2;  // 0602E9D0 shll2 r0
    c.r[1] = c.r[1] & 0xFFu;  // 0602E9D2 extu.b r1,r1
    c.r[1] >>= 2;  // 0602E9D4 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0602E9D6 shlr r1
    c.r[1] |= c.r[0];  // 0602E9D8 or r0,r1
    c.t = c.r[10] > c.r[1];  // 0602E9DA cmp/hi r1,r10
    if (c.t) { goto L_0602E9E6; }  // 0602E9DC bt 0x0602E9E6
    c.r[10] = c.r[1];  // 0602E9DE mov r1,r10
    c.r[0] = c.r[9];  // 0602E9E0 mov r9,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[12]);  // 0602E9E2 mov.w @(r0,r12),r1
    c.r[11] = c.r[1] & 0xFFFFu;  // 0602E9E4 extu.w r1,r11
L_0602E9E6:
    c.r[1] = c.r[8];  // 0602E9E6 mov r8,r1
L_0602E9E8:
    c.r[1] += 1;  // 0602E9E8 add #1,r1
    c.r[8] = c.r[1] & 0xFFFFu;  // 0602E9EA extu.w r1,r8
    c.r[1] = 0x2u;  // 0602E9EC mov #2,r1
    c.t = c.r[8] > c.r[1];  // 0602E9EE cmp/hi r1,r8
    { const bool k = !c.t; c.r[9] = c.r[8]; if (k) { SH2_POLL(c); goto L_0602E99E; } }  // 0602E9F0 bf/s 0x0602E99E ; mov r8,r9
    c.r[1] = ld32(0x0602EA20u);  // 0602E9F4 mov.l 0x0602EA20,r1
    st32(c.r[1] + 20, c.r[11]);  // 0602E9F6 mov.l r11,@(20,r1)
    c.r[15] = c.r[14];  // 0602E9F8 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602E9FA lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602E9FC mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0602E9FE mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0602EA00 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0602EA02 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0602EA04 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602EA0Cu);  // 0602EA06 mov.w 0x0602EA0C,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602EA08 rts ; mov.l @r15+,r8
}

void f_0602EA24(SH2Context& c) {
    ran[658] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602EA24 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602EA26 sts.l pr,@-r15
    c.r[1] = ld32(0x0602EA74u);  // 0602EA28 mov.l 0x0602EA74,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602EA2Eu; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602EA2Eu) return; }  // 0602EA2A jsr @r1 ; mov r15,r14
    c.r[1] = ld32(0x0602EA78u);  // 0602EA2E mov.l 0x0602EA78,r1
    c.r[2] = ld32(c.r[1]);  // 0602EA30 mov.l @r1,r2
    c.r[1] = c.r[2];  // 0602EA32 mov r2,r1
    c.r[1] += 2;  // 0602EA34 add #2,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602EA36 mov.b @r1,r5
    c.r[0] = ld32(0x0602EA7Cu);  // 0602EA38 mov.l 0x0602EA7C,r0
    c.r[5] = c.r[5] & 0xFFu;  // 0602EA3A extu.b r5,r5
    c.r[1] = c.r[2];  // 0602EA3C mov r2,r1
    c.r[1] += 3;  // 0602EA3E add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602EA40 mov.b @r1,r1
    c.r[5] <<= 8;  // 0602EA42 shll8 r5
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[2]); c.r[2] += 1;  // 0602EA44 mov.b @r2+,r4
    c.r[1] = c.r[1] & 0xFFu;  // 0602EA46 extu.b r1,r1
    c.r[5] |= c.r[1];  // 0602EA48 or r1,r5
    c.r[4] = c.r[4] & 0xFFu;  // 0602EA4A extu.b r4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602EA4C mov.b @r2,r1
    c.r[4] <<= 8;  // 0602EA4E shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 0602EA50 extu.b r1,r1
    { const uint32_t x = c.r[0]; c.pr = 0x0602EA56u; c.r[4] |= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602EA56u) return; }  // 0602EA52 jsr @r0 ; or r1,r4
    c.r[2] = c.r[0] & 0xFFu;  // 0602EA56 extu.b r0,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602EA6Eu);  // 0602EA58 mov.w 0x0602EA6E,r1
    c.t = c.r[2] == c.r[1];  // 0602EA5A cmp/eq r1,r2
    if (!c.t) { goto L_0602EA64; }  // 0602EA5C bf 0x0602EA64
    c.r[1] = ld32(0x0602EA80u);  // 0602EA5E mov.l 0x0602EA80,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602EA64u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602EA64u) return; }  // 0602EA60 jsr @r1 ; nop
L_0602EA64:
    c.r[15] = c.r[14];  // 0602EA64 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602EA66 lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602EA70u);  // 0602EA68 mov.w 0x0602EA70,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602EA6A rts ; mov.l @r15+,r14
}

void f_0602EA84(SH2Context& c) {
    ran[659] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602EA84 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602EA86 sts.l pr,@-r15
    c.r[1] = ld32(0x0602EAA4u);  // 0602EA88 mov.l 0x0602EAA4,r1
    c.r[1] = ld32(c.r[1]);  // 0602EA8A mov.l @r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602EA8C mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0602EA8E extu.b r1,r0
    c.r[0] <<= 2;  // 0602EA90 shll2 r0
    c.r[1] = ld32(0x0602EAA8u);  // 0602EA92 mov.l 0x0602EAA8,r1
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 0602EA94 mov.l @(r0,r1),r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602EA9Au; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602EA9Au) return; }  // 0602EA96 jsr @r0 ; mov r15,r14
    c.r[15] = c.r[14];  // 0602EA9A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602EA9C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602EA9E mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[0] & 0xFFFFu; c.pc = x; return; }  // 0602EAA0 rts ; extu.w r0,r0
}

void f_0602EAAC(SH2Context& c) {
    ran[660] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602EAAC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602EAAE mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602EAB0 sts.l pr,@-r15
    c.r[1] = ld32(0x0602EB00u);  // 0602EAB2 mov.l 0x0602EB00,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602EAB8u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602EAB8u) return; }  // 0602EAB4 jsr @r1 ; mov r15,r14
    c.r[1] = ld32(0x0602EB04u);  // 0602EAB8 mov.l 0x0602EB04,r1
    c.r[2] = ld32(c.r[1]);  // 0602EABA mov.l @r1,r2
    c.r[0] = ld32(0x0602EB08u);  // 0602EABC mov.l 0x0602EB08,r0
    c.r[1] = c.r[2];  // 0602EABE mov r2,r1
    c.r[1] += 1;  // 0602EAC0 add #1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602EAC2 mov.b @r1,r4
    c.r[2] += 2;  // 0602EAC4 add #2,r2
    c.r[4] = c.r[4] & 0xFFu;  // 0602EAC6 extu.b r4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602EAC8 mov.b @r2,r1
    c.r[4] <<= 8;  // 0602EACA shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 0602EACC extu.b r1,r1
    { const uint32_t x = c.r[0]; c.pr = 0x0602EAD2u; c.r[4] |= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602EAD2u) return; }  // 0602EACE jsr @r0 ; or r1,r4
    c.r[0] = c.r[0] & 0xFFu;  // 0602EAD2 extu.b r0,r0
    c.r[8] = (uint32_t)(int16_t)ld16(0x0602EAFAu);  // 0602EAD4 mov.w 0x0602EAFA,r8
    c.t = c.r[0] == c.r[8];  // 0602EAD6 cmp/eq r8,r0
    { const bool k = c.t; c.r[4] = c.r[0] & 0xFFu; if (k) { goto L_0602EAEE; } }  // 0602EAD8 bt/s 0x0602EAEE ; extu.b r0,r4
    c.r[0] = ld32(0x0602EB0Cu);  // 0602EADC mov.l 0x0602EB0C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602EAE2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602EAE2u) return; }  // 0602EADE jsr @r0 ; nop
    c.r[1] = c.r[0] & 0xFFu;  // 0602EAE2 extu.b r0,r1
    c.t = c.r[1] == c.r[8];  // 0602EAE4 cmp/eq r8,r1
    if (c.t) { goto L_0602EAEE; }  // 0602EAE6 bt 0x0602EAEE
    c.r[1] = ld32(0x0602EB10u);  // 0602EAE8 mov.l 0x0602EB10,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602EAEEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602EAEEu) return; }  // 0602EAEA jsr @r1 ; nop
L_0602EAEE:
    c.r[15] = c.r[14];  // 0602EAEE mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602EAF0 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602EAF2 mov.l @r15+,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602EAFCu);  // 0602EAF4 mov.w 0x0602EAFC,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602EAF6 rts ; mov.l @r15+,r8
}

void f_0602EB14(SH2Context& c) {
    ran[661] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602EB14 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602EB16 sts.l pr,@-r15
    c.r[1] = ld32(0x0602EB74u);  // 0602EB18 mov.l 0x0602EB74,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602EB1Eu; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602EB1Eu) return; }  // 0602EB1A jsr @r1 ; mov r15,r14
    c.r[1] = ld32(0x0602EB78u);  // 0602EB1E mov.l 0x0602EB78,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602EB20 mov.b @r1,r1
    c.r[6] = c.r[1] & 0xFFu;  // 0602EB22 extu.b r1,r6
    c.r[1] = ld32(0x0602EB7Cu);  // 0602EB24 mov.l 0x0602EB7C,r1
    c.r[2] = c.r[6];  // 0602EB26 mov r6,r2
    c.r[1] = ld32(c.r[1]);  // 0602EB28 mov.l @r1,r1
    c.r[2] <<= 2;  // 0602EB2A shll2 r2
    c.r[2] <<= 2;  // 0602EB2C shll2 r2
    c.r[2] += c.r[1];  // 0602EB2E add r1,r2
    c.r[2] += 2;  // 0602EB30 add #2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602EB32 mov.b @r2,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x0602EB6Eu);  // 0602EB34 mov.w 0x0602EB6E,r3
    c.r[5] = c.r[1] & 0xFFu;  // 0602EB36 extu.b r1,r5
    c.t = c.r[5] == c.r[3];  // 0602EB38 cmp/eq r3,r5
    if (c.t) { goto L_0602EB64; }  // 0602EB3A bt 0x0602EB64
    c.r[1] = ld32(0x0602EB80u);  // 0602EB3C mov.l 0x0602EB80,r1
    c.r[2] = ld32(c.r[1]);  // 0602EB3E mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 0602EB40 mov #30,r1
    c.macl = c.r[5] * c.r[1];  // 0602EB42 mul.l r1,r5
    c.r[1] = c.macl;  // 0602EB44 sts macl,r1
    c.r[1] += c.r[2];  // 0602EB46 add r2,r1
    c.r[1] += 16;  // 0602EB48 add #16,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602EB4A mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602EB4C extu.b r1,r1
    c.t = c.r[1] == c.r[3];  // 0602EB4E cmp/eq r3,r1
    if (c.t) { goto L_0602EB54; }  // 0602EB50 bt 0x0602EB54
    c.r[5] = c.r[1];  // 0602EB52 mov r1,r5
L_0602EB54:
    c.r[1] = ld32(0x0602EB84u);  // 0602EB54 mov.l 0x0602EB84,r1
    c.r[4] = ld32(c.r[1]);  // 0602EB56 mov.l @r1,r4
    c.r[1] = ld32(0x0602EB88u);  // 0602EB58 mov.l 0x0602EB88,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602EB5Eu; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602EB5Eu) return; }  // 0602EB5A jsr @r1 ; extu.b r5,r5
    c.r[1] = ld32(0x0602EB8Cu);  // 0602EB5E mov.l 0x0602EB8C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602EB64u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602EB64u) return; }  // 0602EB60 jsr @r1 ; nop
L_0602EB64:
    c.r[15] = c.r[14];  // 0602EB64 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602EB66 lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602EB70u);  // 0602EB68 mov.w 0x0602EB70,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602EB6A rts ; mov.l @r15+,r14
}

void f_0602EB90(SH2Context& c) {
    ran[662] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602EB90 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602EB92 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0602EB94 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0602EB96 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0602EB98 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0602EB9A mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602EB9C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602EB9E sts.l pr,@-r15
    c.r[1] = ld32(0x0602ED94u);  // 0602EBA0 mov.l 0x0602ED94,r1
    c.r[2] = ld32(c.r[1]);  // 0602EBA2 mov.l @r1,r2
    c.r[1] = c.r[2];  // 0602EBA4 mov r2,r1
    c.r[1] += 1;  // 0602EBA6 add #1,r1
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602EBA8 mov.b @r1,r8
    c.r[15] -= 8;  // 0602EBAA add #-8,r15
    c.r[8] = c.r[8] & 0xFFu;  // 0602EBAC extu.b r8,r8
    c.r[1] = c.r[2];  // 0602EBAE mov r2,r1
    c.r[1] += 2;  // 0602EBB0 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602EBB2 mov.b @r1,r1
    c.r[8] <<= 8;  // 0602EBB4 shll8 r8
    c.r[1] = c.r[1] & 0xFFu;  // 0602EBB6 extu.b r1,r1
    c.r[8] |= c.r[1];  // 0602EBB8 or r1,r8
    c.r[1] = c.r[2];  // 0602EBBA mov r2,r1
    c.r[1] += 3;  // 0602EBBC add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602EBBE mov.b @r1,r1
    c.r[2] += 4;  // 0602EBC0 add #4,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0602EBC2 extu.b r1,r1
    c.r[13] = c.r[1];  // 0602EBC4 mov r1,r13
    c.r[13] <<= 8;  // 0602EBC6 shll8 r13
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602EBC8 mov.b @r2,r1
    c.r[14] = c.r[15];  // 0602EBCA mov r15,r14
    c.r[1] = c.r[1] & 0xFFu;  // 0602EBCC extu.b r1,r1
    c.r[13] |= c.r[1];  // 0602EBCE or r1,r13
    st32(c.r[14] + 4, c.r[13]);  // 0602EBD0 mov.l r13,@(4,r14)
    c.r[13] = c.r[8];  // 0602EBD2 mov r8,r13
    c.r[13] >>= 8;  // 0602EBD4 shlr8 r13
    c.t = c.r[13] & 1; c.r[13] >>= 1;  // 0602EBD6 shlr r13
    c.r[1] = ld32(0x0602ED98u);  // 0602EBD8 mov.l 0x0602ED98,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602EBDEu; st32(c.r[14], c.r[13]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602EBDEu) return; }  // 0602EBDA jsr @r1 ; mov.l r13,@r14
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602ED8Cu);  // 0602EBDE mov.w 0x0602ED8C,r1
    c.r[8] &= c.r[1];  // 0602EBE0 and r1,r8
    c.r[0] = ld32(0x0602ED9Cu);  // 0602EBE2 mov.l 0x0602ED9C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602EBE8u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602EBE8u) return; }  // 0602EBE4 jsr @r0 ; mov r8,r4
    c.r[12] = c.r[0] & 0xFFu;  // 0602EBE8 extu.b r0,r12
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602ED8Eu);  // 0602EBEA mov.w 0x0602ED8E,r1
    c.t = c.r[12] == c.r[1];  // 0602EBEC cmp/eq r1,r12
    { const bool k = !c.t; c.r[9] = 0x0u; if (k) { goto L_0602EBF6; } }  // 0602EBEE bf/s 0x0602EBF6 ; mov #0,r9
    goto L_0602EE26;  // 0602EBF2 bra 0x0602EE26 ; nop
L_0602EBF6:
    c.r[11] = ld32(0x0602EDA0u);  // 0602EBF6 mov.l 0x0602EDA0,r11
    c.r[10] = 0x1Eu;  // 0602EBF8 mov #30,r10
    c.r[4] = c.r[1];  // 0602EBFA mov r1,r4
    c.macl = c.r[9] * c.r[10];  // 0602EBFC mul.l r10,r9
L_0602EBFE:
    c.r[3] = ld32(c.r[11]);  // 0602EBFE mov.l @r11,r3
    c.r[5] = c.macl;  // 0602EC00 sts macl,r5
    c.r[2] = c.r[5];  // 0602EC02 mov r5,r2
    c.r[2] += c.r[3];  // 0602EC04 add r3,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0602EC06 mov.w @r2,r1
    c.r[13] = ld32(c.r[14] + 4);  // 0602EC08 mov.l @(4,r14),r13
    c.r[1] = c.r[1] & 0xFFFFu;  // 0602EC0A extu.w r1,r1
    c.t = c.r[1] == c.r[13];  // 0602EC0C cmp/eq r13,r1
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_0602EC16; } }  // 0602EC0E bt/s 0x0602EC16 ; mov r9,r1
    goto L_0602EE16;  // 0602EC12 bra 0x0602EE16 ; nop
L_0602EC16:
    c.r[6] = c.r[2];  // 0602EC16 mov r2,r6
    c.r[6] += 15;  // 0602EC18 add #15,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0602EC1A mov.b @r6,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602EC1C extu.b r1,r1
    c.t = c.r[1] == c.r[4];  // 0602EC1E cmp/eq r4,r1
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_0602EC28; } }  // 0602EC20 bt/s 0x0602EC28 ; mov r9,r1
    goto L_0602EE16;  // 0602EC24 bra 0x0602EE16 ; nop
L_0602EC28:
    c.macl = c.r[12] * c.r[10];  // 0602EC28 mul.l r10,r12
    c.r[7] = c.macl;  // 0602EC2A sts macl,r7
    c.r[3] += c.r[7];  // 0602EC2C add r7,r3
    c.r[1] = c.r[3];  // 0602EC2E mov r3,r1
    c.r[1] += 16;  // 0602EC30 add #16,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602EC32 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602EC34 extu.b r1,r1
    c.t = c.r[1] == c.r[4];  // 0602EC36 cmp/eq r4,r1
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_0602EC40; } }  // 0602EC38 bt/s 0x0602EC40 ; mov r9,r1
    goto L_0602EE16;  // 0602EC3C bra 0x0602EE16 ; nop
L_0602EC40:
    c.r[2] += 16;  // 0602EC40 add #16,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602EC42 mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602EC44 extu.b r1,r1
    c.t = c.r[1] == c.r[4];  // 0602EC46 cmp/eq r4,r1
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_0602EC50; } }  // 0602EC48 bt/s 0x0602EC50 ; mov r9,r1
    goto L_0602EE16;  // 0602EC4C bra 0x0602EE16 ; nop
L_0602EC50:
    c.r[3] += 15;  // 0602EC50 add #15,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0602EC52 mov.b @r3,r1
    st8(c.r[6], c.r[1]);  // 0602EC54 mov.b r1,@r6
    c.r[1] = ld32(c.r[11]);  // 0602EC56 mov.l @r11,r1
    c.r[1] += c.r[7];  // 0602EC58 add r7,r1
    c.r[1] += 15;  // 0602EC5A add #15,r1
    st8(c.r[1], c.r[4]);  // 0602EC5C mov.b r4,@r1
    c.r[1] = ld32(c.r[11]);  // 0602EC5E mov.l @r11,r1
    c.r[2] = c.r[5];  // 0602EC60 mov r5,r2
    c.r[2] += c.r[1];  // 0602EC62 add r1,r2
    c.r[1] += c.r[7];  // 0602EC64 add r7,r1
    c.r[1] += 2;  // 0602EC66 add #2,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602EC68 mov.b @r1,r0
    c.r[2] += 2;  // 0602EC6A add #2,r2
    c.r[1] = 0x18u;  // 0602EC6C mov #24,r1
    c.r[1] &= c.r[0];  // 0602EC6E and r0,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602EC70 mov.b @r2,r0
    c.r[0] &= 0xE7u;  // 0602EC72 and #231,r0
    c.r[0] |= c.r[1];  // 0602EC74 or r1,r0
    st8(c.r[2], c.r[0]);  // 0602EC76 mov.b r0,@r2
    c.r[1] = ld32(c.r[11]);  // 0602EC78 mov.l @r11,r1
    c.r[2] = c.r[5];  // 0602EC7A mov r5,r2
    c.r[2] += c.r[1];  // 0602EC7C add r1,r2
    c.r[1] += c.r[7];  // 0602EC7E add r7,r1
    c.r[1] += 2;  // 0602EC80 add #2,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602EC82 mov.b @r1,r0
    c.r[2] += 2;  // 0602EC84 add #2,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602ED90u);  // 0602EC86 mov.w 0x0602ED90,r1
    c.r[1] &= c.r[0];  // 0602EC88 and r0,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602EC8A mov.b @r2,r0
    c.r[0] &= 0x3Fu;  // 0602EC8C and #63,r0
    c.r[0] |= c.r[1];  // 0602EC8E or r1,r0
    st8(c.r[2], c.r[0]);  // 0602EC90 mov.b r0,@r2
    c.r[1] = ld32(c.r[11]);  // 0602EC92 mov.l @r11,r1
    c.r[5] += c.r[1];  // 0602EC94 add r1,r5
    c.r[7] += c.r[1];  // 0602EC96 add r1,r7
    c.r[7] += 26;  // 0602EC98 add #26,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0602EC9A mov.b @r7,r1
    c.r[5] += 26;  // 0602EC9C add #26,r5
    st8(c.r[5], c.r[1]);  // 0602EC9E mov.b r1,@r5
    c.r[13] = ld32(c.r[14]);  // 0602ECA0 mov.l @r14,r13
    c.t = (c.r[13] & c.r[13]) == 0;  // 0602ECA2 tst r13,r13
    { const bool k = !c.t; c.r[7] = 0x0u; if (k) { goto L_0602ECAC; } }  // 0602ECA4 bf/s 0x0602ECAC ; mov #0,r7
    goto L_0602EE0C;  // 0602ECA8 bra 0x0602EE0C ; nop
L_0602ECAC:
    c.r[6] = 0x7u;  // 0602ECAC mov #7,r6
L_0602ECAE:
    c.macl = c.r[9] * c.r[10];  // 0602ECAE mul.l r10,r9
    c.r[1] = ld32(c.r[11]);  // 0602ECB0 mov.l @r11,r1
    c.r[3] = c.macl;  // 0602ECB2 sts macl,r3
    c.r[3] += c.r[1];  // 0602ECB4 add r1,r3
    c.macl = c.r[12] * c.r[10];  // 0602ECB6 mul.l r10,r12
    c.r[3] += c.r[7];  // 0602ECB8 add r7,r3
    c.r[3] += 7;  // 0602ECBA add #7,r3
    c.r[2] = c.macl;  // 0602ECBC sts macl,r2
    c.r[2] += c.r[1];  // 0602ECBE add r1,r2
    c.r[2] += c.r[7];  // 0602ECC0 add r7,r2
    c.r[2] += 7;  // 0602ECC2 add #7,r2
    c.r[7] += 1;  // 0602ECC4 add #1,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602ECC6 mov.b @r2,r1
    c.t = (int32_t)c.r[7] > (int32_t)c.r[6];  // 0602ECC8 cmp/gt r6,r7
    { const bool k = !c.t; st8(c.r[3], c.r[1]); if (k) { SH2_POLL(c); goto L_0602ECAE; } }  // 0602ECCA bf/s 0x0602ECAE ; mov.b r1,@r3
    c.r[7] = 0x0u;  // 0602ECCE mov #0,r7
    c.r[3] = 0x3u;  // 0602ECD0 mov #3,r3
L_0602ECD2:
    c.macl = c.r[9] * c.r[10];  // 0602ECD2 mul.l r10,r9
    c.r[1] = ld32(c.r[11]);  // 0602ECD4 mov.l @r11,r1
    c.r[8] = c.macl;  // 0602ECD6 sts macl,r8
    c.r[2] = c.r[8];  // 0602ECD8 mov r8,r2
    c.r[2] += c.r[1];  // 0602ECDA add r1,r2
    c.macl = c.r[12] * c.r[10];  // 0602ECDC mul.l r10,r12
    c.r[2] += c.r[7];  // 0602ECDE add r7,r2
    c.r[2] += 17;  // 0602ECE0 add #17,r2
    c.r[4] = c.macl;  // 0602ECE2 sts macl,r4
    c.r[1] += c.r[4];  // 0602ECE4 add r4,r1
    c.r[1] += c.r[7];  // 0602ECE6 add r7,r1
    c.r[1] += 17;  // 0602ECE8 add #17,r1
    c.r[7] += 1;  // 0602ECEA add #1,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602ECEC mov.b @r1,r1
    c.t = (int32_t)c.r[7] > (int32_t)c.r[3];  // 0602ECEE cmp/gt r3,r7
    { const bool k = !c.t; st8(c.r[2], c.r[1]); if (k) { SH2_POLL(c); goto L_0602ECD2; } }  // 0602ECF0 bf/s 0x0602ECD2 ; mov.b r1,@r2
    c.r[1] = ld32(c.r[11]);  // 0602ECF4 mov.l @r11,r1
    c.r[2] = c.r[8];  // 0602ECF6 mov r8,r2
    c.r[2] += c.r[1];  // 0602ECF8 add r1,r2
    c.r[1] += c.r[4];  // 0602ECFA add r4,r1
    c.r[1] += 3;  // 0602ECFC add #3,r1
    c.r[2] += 3;  // 0602ECFE add #3,r2
    c.r[3] = c.r[8];  // 0602ED00 mov r8,r3
    c.r[7] = 0x7u;  // 0602ED02 mov #7,r7
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602ED04 mov.b @r1,r0
    c.r[13] = 0x1u;  // 0602ED06 mov #1,r13
    c.r[1] = 0x78u;  // 0602ED08 mov #120,r1
    c.r[1] &= c.r[0];  // 0602ED0A and r0,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602ED0C mov.b @r2,r0
    c.r[5] = c.r[4];  // 0602ED0E mov r4,r5
    c.r[0] &= 0x87u;  // 0602ED10 and #135,r0
    c.r[0] |= c.r[1];  // 0602ED12 or r1,r0
    st8(c.r[2], c.r[0]);  // 0602ED14 mov.b r0,@r2
    c.r[1] = ld32(c.r[11]);  // 0602ED16 mov.l @r11,r1
    c.r[2] = c.r[4];  // 0602ED18 mov r4,r2
    c.r[3] += c.r[1];  // 0602ED1A add r1,r3
    c.r[2] += c.r[1];  // 0602ED1C add r1,r2
    c.r[1] = c.r[2];  // 0602ED1E mov r2,r1
    c.r[1] += 3;  // 0602ED20 add #3,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602ED22 mov.b @r1,r0
    c.r[2] += 4;  // 0602ED24 add #4,r2
    c.r[7] &= c.r[0];  // 0602ED26 and r0,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602ED28 mov.b @r2,r1
    c.r[7] += c.r[7];  // 0602ED2A add r7,r7
    c.r[1] = c.r[1] & 0xFFu;  // 0602ED2C extu.b r1,r1
    c.r[1] >>= 2;  // 0602ED2E shlr2 r1
    c.r[1] >>= 2;  // 0602ED30 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0602ED32 shlr r1
    c.r[1] >>= 2;  // 0602ED34 shlr2 r1
    c.r[7] |= c.r[1];  // 0602ED36 or r1,r7
    c.r[2] = c.r[7];  // 0602ED38 mov r7,r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 0602ED3A shlr r2
    c.r[1] = c.r[3];  // 0602ED3C mov r3,r1
    c.r[1] += 3;  // 0602ED3E add #3,r1
    c.r[7] &= c.r[13];  // 0602ED40 and r13,r7
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602ED42 mov.b @r1,r0
    c.r[3] += 4;  // 0602ED44 add #4,r3
    c.r[0] &= 0xF8u;  // 0602ED46 and #248,r0
    c.r[0] |= c.r[2];  // 0602ED48 or r2,r0
    st8(c.r[1], c.r[0]);  // 0602ED4A mov.b r0,@r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0602ED4C mov.b @r3,r0
    c.r[7] <<= 2;  // 0602ED4E shll2 r7
    c.r[7] <<= 2;  // 0602ED50 shll2 r7
    c.r[7] += c.r[7];  // 0602ED52 add r7,r7
    c.r[7] <<= 2;  // 0602ED54 shll2 r7
    c.r[0] &= 0x7Fu;  // 0602ED56 and #127,r0
    c.r[0] |= c.r[7];  // 0602ED58 or r7,r0
    st8(c.r[3], c.r[0]);  // 0602ED5A mov.b r0,@r3
    c.r[1] = ld32(c.r[11]);  // 0602ED5C mov.l @r11,r1
    c.r[2] = c.r[8];  // 0602ED5E mov r8,r2
    c.r[2] += c.r[1];  // 0602ED60 add r1,r2
    c.r[1] += c.r[4];  // 0602ED62 add r4,r1
    c.r[1] += 4;  // 0602ED64 add #4,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602ED66 mov.b @r1,r0
    c.r[2] += 4;  // 0602ED68 add #4,r2
    c.r[1] = 0x78u;  // 0602ED6A mov #120,r1
    c.r[1] &= c.r[0];  // 0602ED6C and r0,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602ED6E mov.b @r2,r0
    c.r[6] = (uint32_t)(int16_t)ld16(0x0602ED92u);  // 0602ED70 mov.w 0x0602ED92,r6
    c.r[0] &= 0x87u;  // 0602ED72 and #135,r0
    c.r[0] |= c.r[1];  // 0602ED74 or r1,r0
    st8(c.r[2], c.r[0]);  // 0602ED76 mov.b r0,@r2
    c.r[1] = ld32(c.r[11]);  // 0602ED78 mov.l @r11,r1
    c.r[7] = c.r[8];  // 0602ED7A mov r8,r7
    c.r[7] += c.r[1];  // 0602ED7C add r1,r7
    c.r[5] += c.r[1];  // 0602ED7E add r1,r5
    c.r[1] = c.r[5];  // 0602ED80 mov r5,r1
    c.r[1] += 4;  // 0602ED82 add #4,r1
    c.r[3] = c.r[7];  // 0602ED84 mov r7,r3
    c.r[3] += 4;  // 0602ED86 add #4,r3
    c.r[5] += 5; goto L_0602EDA4;  // 0602ED88 bra 0x0602EDA4 ; add #5,r5
L_0602EDA4:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0602EDA4 mov.w @r1,r1
    c.r[7] += 5;  // 0602EDA6 add #5,r7
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0602EDA8 mov.w @r3,r2
    c.r[6] &= c.r[1];  // 0602EDAA and r1,r6
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602EE3Eu);  // 0602EDAC mov.w 0x0602EE3E,r1
    c.r[2] &= c.r[1];  // 0602EDAE and r1,r2
    c.r[2] |= c.r[6];  // 0602EDB0 or r6,r2
    st16(c.r[3], c.r[2]);  // 0602EDB2 mov.w r2,@r3
    c.r[1] = 0x78u;  // 0602EDB4 mov #120,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[5]);  // 0602EDB6 mov.b @r5,r0
    c.r[3] = c.r[8];  // 0602EDB8 mov r8,r3
    c.r[1] &= c.r[0];  // 0602EDBA and r0,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0602EDBC mov.b @r7,r0
    c.r[2] = c.r[4];  // 0602EDBE mov r4,r2
    c.r[0] &= 0x87u;  // 0602EDC0 and #135,r0
    c.r[0] |= c.r[1];  // 0602EDC2 or r1,r0
    st8(c.r[7], c.r[0]);  // 0602EDC4 mov.b r0,@r7
    c.r[1] = ld32(c.r[11]);  // 0602EDC6 mov.l @r11,r1
    c.r[7] = 0x7u;  // 0602EDC8 mov #7,r7
    c.r[3] += c.r[1];  // 0602EDCA add r1,r3
    c.r[2] += c.r[1];  // 0602EDCC add r1,r2
    c.r[1] = c.r[2];  // 0602EDCE mov r2,r1
    c.r[1] += 5;  // 0602EDD0 add #5,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602EDD2 mov.b @r1,r0
    c.r[2] += 6;  // 0602EDD4 add #6,r2
    c.r[7] &= c.r[0];  // 0602EDD6 and r0,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602EDD8 mov.b @r2,r1
    c.r[7] += c.r[7];  // 0602EDDA add r7,r7
    c.r[1] = c.r[1] & 0xFFu;  // 0602EDDC extu.b r1,r1
    c.r[1] >>= 2;  // 0602EDDE shlr2 r1
    c.r[1] >>= 2;  // 0602EDE0 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0602EDE2 shlr r1
    c.r[1] >>= 2;  // 0602EDE4 shlr2 r1
    c.r[7] |= c.r[1];  // 0602EDE6 or r1,r7
    c.r[2] = c.r[7];  // 0602EDE8 mov r7,r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 0602EDEA shlr r2
    c.r[1] = c.r[3];  // 0602EDEC mov r3,r1
    c.r[1] += 5;  // 0602EDEE add #5,r1
    c.r[7] &= c.r[13];  // 0602EDF0 and r13,r7
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602EDF2 mov.b @r1,r0
    c.r[3] += 6;  // 0602EDF4 add #6,r3
    c.r[0] &= 0xF8u;  // 0602EDF6 and #248,r0
    c.r[0] |= c.r[2];  // 0602EDF8 or r2,r0
    st8(c.r[1], c.r[0]);  // 0602EDFA mov.b r0,@r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0602EDFC mov.b @r3,r0
    c.r[7] <<= 2;  // 0602EDFE shll2 r7
    c.r[7] <<= 2;  // 0602EE00 shll2 r7
    c.r[7] += c.r[7];  // 0602EE02 add r7,r7
    c.r[7] <<= 2;  // 0602EE04 shll2 r7
    c.r[0] &= 0x7Fu;  // 0602EE06 and #127,r0
    c.r[0] |= c.r[7];  // 0602EE08 or r7,r0
    st8(c.r[3], c.r[0]);  // 0602EE0A mov.b r0,@r3
L_0602EE0C:
    c.r[1] = ld32(0x0602EE44u);  // 0602EE0C mov.l 0x0602EE44,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602EE12u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602EE12u) return; }  // 0602EE0E jsr @r1 ; nop
    c.r[14] += 8; goto L_0602EE28;  // 0602EE12 bra 0x0602EE28 ; add #8,r14
L_0602EE16:
    c.r[1] += 1;  // 0602EE16 add #1,r1
    c.r[9] = c.r[1] & 0xFFu;  // 0602EE18 extu.b r1,r9
    c.r[1] = 0x7Fu;  // 0602EE1A mov #127,r1
    c.t = c.r[9] > c.r[1];  // 0602EE1C cmp/hi r1,r9
    { const bool k = c.t; c.macl = c.r[9] * c.r[10]; if (k) { goto L_0602EE26; } }  // 0602EE1E bt/s 0x0602EE26 ; mul.l r10,r9
    SH2_POLL(c); goto L_0602EBFE;  // 0602EE22 bra 0x0602EBFE ; nop
L_0602EE26:
    c.r[14] += 8;  // 0602EE26 add #8,r14
L_0602EE28:
    c.r[15] = c.r[14];  // 0602EE28 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602EE2A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602EE2C mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0602EE2E mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0602EE30 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0602EE32 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0602EE34 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0602EE36 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602EE40u);  // 0602EE38 mov.w 0x0602EE40,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602EE3A rts ; mov.l @r15+,r8
}

void f_0602EE48(SH2Context& c) {
    ran[663] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602EE48 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602EE4A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602EE4C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602EE4E sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0602EE50 mov r15,r14
    c.r[9] = ld32(0x0602EEB8u);  // 0602EE52 mov.l 0x0602EEB8,r9
    c.r[8] = c.r[9];  // 0602EE54 mov r9,r8
    c.r[1] = ld32(0x0602EEBCu);  // 0602EE56 mov.l 0x0602EEBC,r1
    c.r[3] = ld32(c.r[1]);  // 0602EE58 mov.l @r1,r3
    c.r[8] += 28;  // 0602EE5A add #28,r8
    c.r[1] = c.r[3];  // 0602EE5C mov r3,r1
    c.r[1] += 1;  // 0602EE5E add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602EE60 mov.b @r1,r2
    c.r[3] += 2;  // 0602EE62 add #2,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0602EE64 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0602EE66 mov.b @r3,r1
    c.r[2] <<= 8;  // 0602EE68 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0602EE6A extu.b r1,r1
    c.r[2] |= c.r[1];  // 0602EE6C or r1,r2
    c.r[1] = ld32(0x0602EEC0u);  // 0602EE6E mov.l 0x0602EEC0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602EE74u; st16(c.r[8], c.r[2]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602EE74u) return; }  // 0602EE70 jsr @r1 ; mov.w r2,@r8
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[8]);  // 0602EE74 mov.w @r8,r4
    c.r[0] = ld32(0x0602EEC4u);  // 0602EE76 mov.l 0x0602EEC4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602EE7Cu; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602EE7Cu) return; }  // 0602EE78 jsr @r0 ; extu.w r4,r4
    c.r[0] = c.r[0] & 0xFFu;  // 0602EE7C extu.b r0,r0
    c.r[3] = (uint32_t)(int16_t)ld16(0x0602EEB4u);  // 0602EE7E mov.w 0x0602EEB4,r3
    c.t = c.r[0] == c.r[3];  // 0602EE80 cmp/eq r3,r0
    if (c.t) { goto L_0602EEA6; }  // 0602EE82 bt 0x0602EEA6
    c.r[1] = ld32(0x0602EEC8u);  // 0602EE84 mov.l 0x0602EEC8,r1
    c.r[2] = ld32(c.r[1]);  // 0602EE86 mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 0602EE88 mov #30,r1
    c.macl = c.r[0] * c.r[1];  // 0602EE8A mul.l r1,r0
    c.r[1] = c.macl;  // 0602EE8C sts macl,r1
    c.r[1] += c.r[2];  // 0602EE8E add r2,r1
    c.r[1] += 15;  // 0602EE90 add #15,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602EE92 mov.b @r1,r2
    c.r[1] = c.r[2] & 0xFFu;  // 0602EE94 extu.b r2,r1
    c.t = c.r[1] == c.r[3];  // 0602EE96 cmp/eq r3,r1
    { const bool k = c.t; c.r[9] += 26; if (k) { goto L_0602EEA6; } }  // 0602EE98 bt/s 0x0602EEA6 ; add #26,r9
    c.r[1] = c.r[2] & 0xFFu;  // 0602EE9C extu.b r2,r1
    st16(c.r[9], c.r[1]);  // 0602EE9E mov.w r1,@r9
    c.r[1] = ld32(0x0602EECCu);  // 0602EEA0 mov.l 0x0602EECC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602EEA6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602EEA6u) return; }  // 0602EEA2 jsr @r1 ; nop
L_0602EEA6:
    c.r[15] = c.r[14];  // 0602EEA6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602EEA8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602EEAA mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0602EEAC mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602EEB6u);  // 0602EEAE mov.w 0x0602EEB6,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602EEB0 rts ; mov.l @r15+,r8
}

void f_0602EED0(SH2Context& c) {
    ran[664] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602EED0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602EED2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602EED4 sts.l pr,@-r15
    c.r[1] = ld32(0x0602EF30u);  // 0602EED6 mov.l 0x0602EF30,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602EEDCu; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602EEDCu) return; }  // 0602EED8 jsr @r1 ; mov r15,r14
    c.r[8] = (uint32_t)(int16_t)ld16(0x0602EF2Au);  // 0602EEDC mov.w 0x0602EF2A,r8
    c.r[1] = ld32(0x0602EF34u);  // 0602EEDE mov.l 0x0602EF34,r1
    c.r[0] = ld32(0x0602EF38u);  // 0602EEE0 mov.l 0x0602EF38,r0
    c.r[1] = ld32(c.r[1]);  // 0602EEE2 mov.l @r1,r1
    c.r[7] = c.r[8];  // 0602EEE4 mov r8,r7
    c.r[1] += 8;  // 0602EEE6 add #8,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602EEE8 mov.b @r1,r6
    c.r[5] = 0x0u;  // 0602EEEA mov #0,r5
    c.r[6] = c.r[6] & 0xFFu;  // 0602EEEC extu.b r6,r6
    c.r[1] = ld32(0x0602EF3Cu);  // 0602EEEE mov.l 0x0602EF3C,r1
    c.r[2] = ld32(c.r[1]);  // 0602EEF0 mov.l @r1,r2
    c.r[6] >>= 2;  // 0602EEF2 shlr2 r6
    c.r[6] >>= 2;  // 0602EEF4 shlr2 r6
    c.r[6] >>= 2;  // 0602EEF6 shlr2 r6
    c.r[1] = c.r[2];  // 0602EEF8 mov r2,r1
    c.r[1] += 1;  // 0602EEFA add #1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602EEFC mov.b @r1,r4
    c.r[2] += 2;  // 0602EEFE add #2,r2
    c.r[4] = c.r[4] & 0xFFu;  // 0602EF00 extu.b r4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602EF02 mov.b @r2,r1
    c.r[4] <<= 8;  // 0602EF04 shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 0602EF06 extu.b r1,r1
    c.r[4] |= c.r[1];  // 0602EF08 or r1,r4
    c.r[1] = 0x0u;  // 0602EF0A mov #0,r1
    { const uint32_t x = c.r[0]; c.pr = 0x0602EF10u; c.r[15] -= 4; st32(c.r[15], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602EF10u) return; }  // 0602EF0C jsr @r0 ; mov.l r1,@-r15
    c.r[1] = c.r[0] & 0xFFu;  // 0602EF10 extu.b r0,r1
    c.t = c.r[1] == c.r[8];  // 0602EF12 cmp/eq r8,r1
    { const bool k = c.t; c.r[15] += 4; if (k) { goto L_0602EF1E; } }  // 0602EF14 bt/s 0x0602EF1E ; add #4,r15
    c.r[1] = ld32(0x0602EF40u);  // 0602EF18 mov.l 0x0602EF40,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602EF1Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602EF1Eu) return; }  // 0602EF1A jsr @r1 ; nop
L_0602EF1E:
    c.r[15] = c.r[14];  // 0602EF1E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602EF20 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602EF22 mov.l @r15+,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602EF2Cu);  // 0602EF24 mov.w 0x0602EF2C,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602EF26 rts ; mov.l @r15+,r8
}

void f_0602EF44(SH2Context& c) {
    ran[665] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602EF44 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602EF46 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0602EF48 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0602EF4A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602EF4C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602EF4E sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0602EF50 mov r15,r14
    c.r[9] = ld32(0x0602EFC8u);  // 0602EF52 mov.l 0x0602EFC8,r9
    c.r[2] = ld32(c.r[9]);  // 0602EF54 mov.l @r9,r2
    c.r[3] = 0x3u;  // 0602EF56 mov #3,r3
    c.r[1] = c.r[2];  // 0602EF58 mov r2,r1
    c.r[1] += 1;  // 0602EF5A add #1,r1
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602EF5C mov.b @r1,r8
    c.r[2] += 2;  // 0602EF5E add #2,r2
    c.r[8] = c.r[8] & 0xFFu;  // 0602EF60 extu.b r8,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602EF62 mov.b @r2,r1
    c.r[8] <<= 8;  // 0602EF64 shll8 r8
    c.r[1] = c.r[1] & 0xFFu;  // 0602EF66 extu.b r1,r1
    c.r[8] |= c.r[1];  // 0602EF68 or r1,r8
    c.r[11] = c.r[8];  // 0602EF6A mov r8,r11
    c.r[11] >>= 8;  // 0602EF6C shlr8 r11
    c.t = c.r[11] & 1; c.r[11] >>= 1;  // 0602EF6E shlr r11
    c.r[11] >>= 2;  // 0602EF70 shlr2 r11
    c.r[11] &= c.r[3];  // 0602EF72 and r3,r11
    c.r[10] = c.r[8];  // 0602EF74 mov r8,r10
    c.r[10] >>= 8;  // 0602EF76 shlr8 r10
    c.t = c.r[10] & 1; c.r[10] >>= 1;  // 0602EF78 shlr r10
    c.r[1] = ld32(0x0602EFCCu);  // 0602EF7A mov.l 0x0602EFCC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602EF80u; c.r[10] &= c.r[3]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602EF80u) return; }  // 0602EF7C jsr @r1 ; and r3,r10
    c.r[0] = ld32(0x0602EFD0u);  // 0602EF80 mov.l 0x0602EFD0,r0
    c.r[6] = c.r[10];  // 0602EF82 mov r10,r6
    c.r[2] = ld32(c.r[9]);  // 0602EF84 mov.l @r9,r2
    c.r[5] = c.r[11];  // 0602EF86 mov r11,r5
    c.r[1] = c.r[2];  // 0602EF88 mov r2,r1
    c.r[1] += 3;  // 0602EF8A add #3,r1
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602EF8C mov.b @r1,r7
    c.r[2] += 4;  // 0602EF8E add #4,r2
    c.r[7] = c.r[7] & 0xFFu;  // 0602EF90 extu.b r7,r7
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602EFC2u);  // 0602EF92 mov.w 0x0602EFC2,r1
    c.r[8] &= c.r[1];  // 0602EF94 and r1,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602EF96 mov.b @r2,r1
    c.r[4] = c.r[8];  // 0602EF98 mov r8,r4
    c.r[1] = c.r[1] & 0xFFu;  // 0602EF9A extu.b r1,r1
    { const uint32_t x = c.r[0]; c.pr = 0x0602EFA0u; c.r[15] -= 4; st32(c.r[15], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602EFA0u) return; }  // 0602EF9C jsr @r0 ; mov.l r1,@-r15
    c.r[2] = c.r[0] & 0xFFu;  // 0602EFA0 extu.b r0,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602EFC4u);  // 0602EFA2 mov.w 0x0602EFC4,r1
    c.t = c.r[2] == c.r[1];  // 0602EFA4 cmp/eq r1,r2
    { const bool k = !c.t; c.r[15] += 4; if (k) { goto L_0602EFB0; } }  // 0602EFA6 bf/s 0x0602EFB0 ; add #4,r15
    c.r[1] = ld32(0x0602EFD4u);  // 0602EFAA mov.l 0x0602EFD4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602EFB0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602EFB0u) return; }  // 0602EFAC jsr @r1 ; nop
L_0602EFB0:
    c.r[15] = c.r[14];  // 0602EFB0 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602EFB2 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602EFB4 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0602EFB6 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0602EFB8 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0602EFBA mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602EFC6u);  // 0602EFBC mov.w 0x0602EFC6,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602EFBE rts ; mov.l @r15+,r8
}

void f_0602EFD8(SH2Context& c) {
    ran[666] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602EFD8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602EFDA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0602EFDC mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0602EFDE mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602EFE0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602EFE2 sts.l pr,@-r15
    c.r[8] = ld32(0x0602F0B8u);  // 0602EFE4 mov.l 0x0602F0B8,r8
    c.r[2] = ld32(c.r[8]);  // 0602EFE6 mov.l @r8,r2
    c.r[14] = c.r[15];  // 0602EFE8 mov r15,r14
    c.r[1] = c.r[2];  // 0602EFEA mov r2,r1
    c.r[1] += 3;  // 0602EFEC add #3,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602EFEE mov.b @r1,r5
    c.r[9] = ld32(0x0602F0BCu);  // 0602EFF0 mov.l 0x0602F0BC,r9
    c.r[5] = c.r[5] & 0xFFu;  // 0602EFF2 extu.b r5,r5
    c.r[1] = c.r[2];  // 0602EFF4 mov r2,r1
    c.r[1] += 4;  // 0602EFF6 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602EFF8 mov.b @r1,r1
    c.r[5] <<= 8;  // 0602EFFA shll8 r5
    c.r[1] = c.r[1] & 0xFFu;  // 0602EFFC extu.b r1,r1
    c.r[5] |= c.r[1];  // 0602EFFE or r1,r5
    c.r[1] = c.r[2];  // 0602F000 mov r2,r1
    c.r[1] += 1;  // 0602F002 add #1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602F004 mov.b @r1,r4
    c.r[2] += 2;  // 0602F006 add #2,r2
    c.r[4] = c.r[4] & 0xFFu;  // 0602F008 extu.b r4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602F00A mov.b @r2,r1
    c.r[4] <<= 8;  // 0602F00C shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 0602F00E extu.b r1,r1
    { const uint32_t x = c.r[9]; c.pr = 0x0602F014u; c.r[4] |= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602F014u) return; }  // 0602F010 jsr @r9 ; or r1,r4
    c.r[2] = ld32(c.r[8]);  // 0602F014 mov.l @r8,r2
    c.r[1] = c.r[2];  // 0602F016 mov r2,r1
    c.r[1] += 7;  // 0602F018 add #7,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602F01A mov.b @r1,r5
    c.r[10] = c.r[0] & 0xFFu;  // 0602F01C extu.b r0,r10
    c.r[5] = c.r[5] & 0xFFu;  // 0602F01E extu.b r5,r5
    c.r[1] = c.r[2];  // 0602F020 mov r2,r1
    c.r[1] += 8;  // 0602F022 add #8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602F024 mov.b @r1,r1
    c.r[5] <<= 8;  // 0602F026 shll8 r5
    c.r[1] = c.r[1] & 0xFFu;  // 0602F028 extu.b r1,r1
    c.r[5] |= c.r[1];  // 0602F02A or r1,r5
    c.r[1] = c.r[2];  // 0602F02C mov r2,r1
    c.r[1] += 5;  // 0602F02E add #5,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602F030 mov.b @r1,r4
    c.r[2] += 6;  // 0602F032 add #6,r2
    c.r[4] = c.r[4] & 0xFFu;  // 0602F034 extu.b r4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602F036 mov.b @r2,r1
    c.r[4] <<= 8;  // 0602F038 shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 0602F03A extu.b r1,r1
    { const uint32_t x = c.r[9]; c.pr = 0x0602F040u; c.r[4] |= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602F040u) return; }  // 0602F03C jsr @r9 ; or r1,r4
    c.r[2] = ld32(c.r[8]);  // 0602F040 mov.l @r8,r2
    c.r[1] = c.r[2];  // 0602F042 mov r2,r1
    c.r[1] += 11;  // 0602F044 add #11,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602F046 mov.b @r1,r5
    c.r[11] = c.r[0] & 0xFFu;  // 0602F048 extu.b r0,r11
    c.r[5] = c.r[5] & 0xFFu;  // 0602F04A extu.b r5,r5
    c.r[1] = c.r[2];  // 0602F04C mov r2,r1
    c.r[1] += 12;  // 0602F04E add #12,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602F050 mov.b @r1,r1
    c.r[5] <<= 8;  // 0602F052 shll8 r5
    c.r[1] = c.r[1] & 0xFFu;  // 0602F054 extu.b r1,r1
    c.r[5] |= c.r[1];  // 0602F056 or r1,r5
    c.r[1] = c.r[2];  // 0602F058 mov r2,r1
    c.r[1] += 9;  // 0602F05A add #9,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602F05C mov.b @r1,r4
    c.r[2] += 10;  // 0602F05E add #10,r2
    c.r[4] = c.r[4] & 0xFFu;  // 0602F060 extu.b r4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602F062 mov.b @r2,r1
    c.r[4] <<= 8;  // 0602F064 shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 0602F066 extu.b r1,r1
    { const uint32_t x = c.r[9]; c.pr = 0x0602F06Cu; c.r[4] |= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602F06Cu) return; }  // 0602F068 jsr @r9 ; or r1,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602F0B4u);  // 0602F06C mov.w 0x0602F0B4,r1
    c.t = c.r[10] == c.r[1];  // 0602F06E cmp/eq r1,r10
    { const bool k = c.t; c.r[0] = c.r[0] & 0xFFu; if (k) { goto L_0602F09C; } }  // 0602F070 bt/s 0x0602F09C ; extu.b r0,r0
    c.t = c.r[11] == c.r[1];  // 0602F074 cmp/eq r1,r11
    { const bool k = c.t; c.t = c.r[0] == c.r[1]; if (k) { goto L_0602F09C; } }  // 0602F076 bt/s 0x0602F09C ; cmp/eq r1,r0
    { const bool k = c.t; c.r[3] = 0x1Eu; if (k) { goto L_0602F09C; } }  // 0602F07A bt/s 0x0602F09C ; mov #30,r3
    c.macl = c.r[11] * c.r[3];  // 0602F07E mul.l r3,r11
    c.r[7] = ld32(0x0602F0C0u);  // 0602F080 mov.l 0x0602F0C0,r7
    c.r[2] = ld32(c.r[7]);  // 0602F082 mov.l @r7,r2
    c.r[1] = c.macl;  // 0602F084 sts macl,r1
    c.r[1] += c.r[2];  // 0602F086 add r2,r1
    c.r[1] += 16;  // 0602F088 add #16,r1
    c.macl = c.r[0] * c.r[3];  // 0602F08A mul.l r3,r0
    st8(c.r[1], c.r[10]);  // 0602F08C mov.b r10,@r1
    c.r[1] = ld32(c.r[7]);  // 0602F08E mov.l @r7,r1
    c.r[2] = c.macl;  // 0602F090 sts macl,r2
    c.r[2] += c.r[1];  // 0602F092 add r1,r2
    c.r[2] += 16;  // 0602F094 add #16,r2
    c.r[1] = ld32(0x0602F0C4u);  // 0602F096 mov.l 0x0602F0C4,r1
    st8(c.r[2], c.r[10]); goto L_0602F09E;  // 0602F098 bra 0x0602F09E ; mov.b r10,@r2
L_0602F09C:
    c.r[1] = ld32(0x0602F0C8u);  // 0602F09C mov.l 0x0602F0C8,r1
L_0602F09E:
    { const uint32_t x = c.r[1]; c.pr = 0x0602F0A2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602F0A2u) return; }  // 0602F09E jsr @r1 ; nop
    c.r[15] = c.r[14];  // 0602F0A2 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602F0A4 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602F0A6 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0602F0A8 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0602F0AA mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0602F0AC mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602F0B6u);  // 0602F0AE mov.w 0x0602F0B6,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602F0B0 rts ; mov.l @r15+,r8
}

void f_0602F0CC(SH2Context& c) {
    ran[667] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602F0CC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602F0CE sts.l pr,@-r15
    c.r[1] = ld32(0x0602F104u);  // 0602F0D0 mov.l 0x0602F104,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602F0D6u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602F0D6u) return; }  // 0602F0D2 jsr @r1 ; mov r15,r14
    c.r[1] = ld32(0x0602F108u);  // 0602F0D6 mov.l 0x0602F108,r1
    c.r[1] = ld32(c.r[1]);  // 0602F0D8 mov.l @r1,r1
    c.r[1] += 1;  // 0602F0DA add #1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602F0DC mov.b @r1,r4
    c.r[0] = ld32(0x0602F10Cu);  // 0602F0DE mov.l 0x0602F10C,r0
    c.r[4] -= 1;  // 0602F0E0 add #-1,r4
    { const uint32_t x = c.r[0]; c.pr = 0x0602F0E6u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602F0E6u) return; }  // 0602F0E2 jsr @r0 ; extu.b r4,r4
    c.r[2] = c.r[0] & 0xFFu;  // 0602F0E6 extu.b r0,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602F0FEu);  // 0602F0E8 mov.w 0x0602F0FE,r1
    c.t = c.r[2] == c.r[1];  // 0602F0EA cmp/eq r1,r2
    if (c.t) { goto L_0602F0F4; }  // 0602F0EC bt 0x0602F0F4
    c.r[1] = ld32(0x0602F110u);  // 0602F0EE mov.l 0x0602F110,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602F0F4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602F0F4u) return; }  // 0602F0F0 jsr @r1 ; nop
L_0602F0F4:
    c.r[15] = c.r[14];  // 0602F0F4 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602F0F6 lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602F100u);  // 0602F0F8 mov.w 0x0602F100,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602F0FA rts ; mov.l @r15+,r14
}

void f_0602F114(SH2Context& c) {
    ran[668] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602F114 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602F116 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0602F118 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602F11A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602F11C sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x0602F1CAu);  // 0602F11E mov.w 0x0602F1CA,r3
    c.r[15] += c.r[3];  // 0602F120 add r3,r15
    c.r[1] = ld32(0x0602F1D4u);  // 0602F122 mov.l 0x0602F1D4,r1
    c.r[2] = ld32(c.r[1]);  // 0602F124 mov.l @r1,r2
    c.r[14] = c.r[15];  // 0602F126 mov r15,r14
    c.r[1] = c.r[2];  // 0602F128 mov r2,r1
    c.r[1] += 1;  // 0602F12A add #1,r1
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602F12C mov.b @r1,r8
    c.r[2] += 2;  // 0602F12E add #2,r2
    c.r[8] = c.r[8] & 0xFFu;  // 0602F130 extu.b r8,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602F132 mov.b @r2,r1
    c.r[8] <<= 8;  // 0602F134 shll8 r8
    c.r[1] = c.r[1] & 0xFFu;  // 0602F136 extu.b r1,r1
    c.r[8] |= c.r[1];  // 0602F138 or r1,r8
    c.r[1] = ld32(0x0602F1D8u);  // 0602F13A mov.l 0x0602F1D8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602F140u; c.r[8] = (uint32_t)(int32_t)(int16_t)c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602F140u) return; }  // 0602F13C jsr @r1 ; exts.w r8,r8
    c.r[10] = ld32(0x0602F1DCu);  // 0602F140 mov.l 0x0602F1DC,r10
    c.r[1] = 0x0u;  // 0602F142 mov #0,r1
    st32(c.r[10] + 20, c.r[1]);  // 0602F144 mov.l r1,@(20,r10)
    c.r[8] = (uint32_t)(int32_t)(int16_t)c.r[8];  // 0602F146 exts.w r8,r8
    c.r[0] = ld32(0x0602F1E0u);  // 0602F148 mov.l 0x0602F1E0,r0
    c.r[6] = 0x0u;  // 0602F14A mov #0,r6
    c.r[5] = c.r[8];  // 0602F14C mov r8,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0602F152u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602F152u) return; }  // 0602F14E jsr @r0 ; mov r14,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 0602F152 tst r0,r0
    { const bool k = c.t; c.r[8] = (uint32_t)(int8_t)ld8(c.r[14]); if (k) { goto L_0602F1B6; } }  // 0602F154 bt/s 0x0602F1B6 ; mov.b @r14,r8
    c.r[6] = (uint32_t)(int16_t)ld16(0x0602F1CCu);  // 0602F158 mov.w 0x0602F1CC,r6
    c.r[9] = ld32(0x0602F1E4u);  // 0602F15A mov.l 0x0602F1E4,r9
    c.r[4] = c.r[14];  // 0602F15C mov r14,r4
    c.r[1] = ld32(c.r[9]);  // 0602F15E mov.l @r9,r1
    c.r[8] = c.r[8] & 0xFFu;  // 0602F160 extu.b r8,r8
    c.r[8] <<= 2;  // 0602F162 shll2 r8
    c.r[8] <<= 2;  // 0602F164 shll2 r8
    c.r[1] += c.r[8];  // 0602F166 add r8,r1
    c.r[1] += 2;  // 0602F168 add #2,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602F16A mov.b @r1,r5
    c.r[4] += 76;  // 0602F16C add #76,r4
    c.r[1] = ld32(0x0602F1E8u);  // 0602F16E mov.l 0x0602F1E8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602F174u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602F174u) return; }  // 0602F170 jsr @r1 ; extu.b r5,r5
    c.r[1] = ld32(c.r[9]);  // 0602F174 mov.l @r9,r1
    c.r[8] += c.r[1];  // 0602F176 add r1,r8
    c.r[8] += 4;  // 0602F178 add #4,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0602F17A mov.b @r8,r1
    c.r[0] = c.r[1];  // 0602F17C mov r1,r0
    c.r[0] >>= 2;  // 0602F17E shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0602F180 shlr r0
    c.r[0] >>= 2;  // 0602F182 shlr2 r0
    c.r[0] &= 0x1u;  // 0602F184 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0602F186 tst r0,r0
    c.r[1] = c.r[14];  // 0602F188 mov r14,r1
    c.r[1] += 98;  // 0602F18A add #98,r1
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0602F18C mov.w @r1,r6
    c.r[1] = 0x64u;  // 0602F18E mov #100,r1
    c.macl = (c.r[6] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 0602F190 mulu.w r1,r6
    c.r[7] = ld32(0x0602F1ECu);  // 0602F192 mov.l 0x0602F1EC,r7
    c.r[1] = c.r[14];  // 0602F194 mov r14,r1
    c.r[1] += 102;  // 0602F196 add #102,r1
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0602F198 mov.w @r1,r5
    c.r[4] = c.macl;  // 0602F19A sts macl,r4
    { const uint32_t x = c.r[7]; c.pr = 0x0602F1A0u; c.r[5] = c.r[5] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602F1A0u) return; }  // 0602F19C jsr @r7 ; extu.w r5,r5
    c.t = (c.r[0] & c.r[0]) == 0;  // 0602F1A0 tst r0,r0
    { const bool k = !c.t; st32(c.r[10] + 20, c.r[0]); if (k) { goto L_0602F1B0; } }  // 0602F1A2 bf/s 0x0602F1B0 ; mov.l r0,@(20,r10)
    c.r[1] = c.r[6] & 0xFFFFu;  // 0602F1A6 extu.w r6,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0602F1A8 tst r1,r1
    { const bool k = c.t; c.r[1] = 0x1u; if (k) { goto L_0602F1B0; } }  // 0602F1AA bt/s 0x0602F1B0 ; mov #1,r1
    st32(c.r[10] + 20, c.r[1]);  // 0602F1AE mov.l r1,@(20,r10)
L_0602F1B0:
    c.r[1] = ld32(0x0602F1F0u);  // 0602F1B0 mov.l 0x0602F1F0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602F1B6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602F1B6u) return; }  // 0602F1B2 jsr @r1 ; nop
L_0602F1B6:
    c.r[3] = (uint32_t)(int16_t)ld16(0x0602F1CEu);  // 0602F1B6 mov.w 0x0602F1CE,r3
    c.r[14] += c.r[3];  // 0602F1B8 add r3,r14
    c.r[15] = c.r[14];  // 0602F1BA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602F1BC lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602F1BE mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0602F1C0 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0602F1C2 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602F1D0u);  // 0602F1C4 mov.w 0x0602F1D0,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602F1C6 rts ; mov.l @r15+,r8
}

void f_0602F1F4(SH2Context& c) {
    ran[669] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602F1F4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602F1F6 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602F1F8 sts.l pr,@-r15
    c.r[1] = ld32(0x0602F24Cu);  // 0602F1FA mov.l 0x0602F24C,r1
    c.r[3] = ld32(c.r[1]);  // 0602F1FC mov.l @r1,r3
    c.r[1] = c.r[3];  // 0602F1FE mov r3,r1
    c.r[1] += 1;  // 0602F200 add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602F202 mov.b @r1,r2
    c.r[3] += 2;  // 0602F204 add #2,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0602F206 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0602F208 mov.b @r3,r1
    c.r[2] <<= 8;  // 0602F20A shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0602F20C extu.b r1,r1
    c.r[2] |= c.r[1];  // 0602F20E or r1,r2
    c.r[8] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0602F210 exts.w r2,r8
    c.r[0] = c.r[8];  // 0602F212 mov r8,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0602F214 cmp/eq #-1,r0
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0602F21E; } }  // 0602F216 bf/s 0x0602F21E ; mov r15,r14
    c.r[1] = ld32(0x0602F250u);  // 0602F21A mov.l 0x0602F250,r1
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0602F21C mov.w @r1,r8
L_0602F21E:
    c.r[1] = ld32(0x0602F254u);  // 0602F21E mov.l 0x0602F254,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602F224u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602F224u) return; }  // 0602F220 jsr @r1 ; nop
    c.r[5] = c.r[8] & 0xFFFFu;  // 0602F224 extu.w r8,r5
    c.r[8] = (uint32_t)(int16_t)ld16(0x0602F246u);  // 0602F226 mov.w 0x0602F246,r8
    c.r[0] = ld32(0x0602F258u);  // 0602F228 mov.l 0x0602F258,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602F22Eu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602F22Eu) return; }  // 0602F22A jsr @r0 ; mov r8,r4
    c.r[1] = c.r[0] & 0xFFu;  // 0602F22E extu.b r0,r1
    c.t = c.r[1] == c.r[8];  // 0602F230 cmp/eq r8,r1
    if (c.t) { goto L_0602F23A; }  // 0602F232 bt 0x0602F23A
    c.r[1] = ld32(0x0602F25Cu);  // 0602F234 mov.l 0x0602F25C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602F23Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602F23Au) return; }  // 0602F236 jsr @r1 ; nop
L_0602F23A:
    c.r[15] = c.r[14];  // 0602F23A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602F23C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602F23E mov.l @r15+,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602F248u);  // 0602F240 mov.w 0x0602F248,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602F242 rts ; mov.l @r15+,r8
}

void f_0602F260(SH2Context& c) {
    ran[670] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602F260 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602F262 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602F264 sts.l pr,@-r15
    c.r[1] = ld32(0x0602F2B8u);  // 0602F266 mov.l 0x0602F2B8,r1
    c.r[3] = ld32(c.r[1]);  // 0602F268 mov.l @r1,r3
    c.r[1] = c.r[3];  // 0602F26A mov r3,r1
    c.r[1] += 1;  // 0602F26C add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602F26E mov.b @r1,r2
    c.r[3] += 2;  // 0602F270 add #2,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0602F272 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0602F274 mov.b @r3,r1
    c.r[2] <<= 8;  // 0602F276 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0602F278 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0602F27A or r1,r2
    c.r[8] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0602F27C exts.w r2,r8
    c.r[0] = c.r[8];  // 0602F27E mov r8,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0602F280 cmp/eq #-1,r0
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0602F28A; } }  // 0602F282 bf/s 0x0602F28A ; mov r15,r14
    c.r[1] = ld32(0x0602F2BCu);  // 0602F286 mov.l 0x0602F2BC,r1
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0602F288 mov.w @r1,r8
L_0602F28A:
    c.r[1] = ld32(0x0602F2C0u);  // 0602F28A mov.l 0x0602F2C0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602F290u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602F290u) return; }  // 0602F28C jsr @r1 ; nop
    c.r[5] = c.r[8] & 0xFFFFu;  // 0602F290 extu.w r8,r5
    c.r[8] = (uint32_t)(int16_t)ld16(0x0602F2B2u);  // 0602F292 mov.w 0x0602F2B2,r8
    c.r[0] = ld32(0x0602F2C4u);  // 0602F294 mov.l 0x0602F2C4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602F29Au; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602F29Au) return; }  // 0602F296 jsr @r0 ; mov r8,r4
    c.r[1] = c.r[0] & 0xFFu;  // 0602F29A extu.b r0,r1
    c.t = c.r[1] == c.r[8];  // 0602F29C cmp/eq r8,r1
    if (c.t) { goto L_0602F2A6; }  // 0602F29E bt 0x0602F2A6
    c.r[1] = ld32(0x0602F2C8u);  // 0602F2A0 mov.l 0x0602F2C8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602F2A6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602F2A6u) return; }  // 0602F2A2 jsr @r1 ; nop
L_0602F2A6:
    c.r[15] = c.r[14];  // 0602F2A6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602F2A8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602F2AA mov.l @r15+,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602F2B4u);  // 0602F2AC mov.w 0x0602F2B4,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602F2AE rts ; mov.l @r15+,r8
}

void f_0602F2CC(SH2Context& c) {
    ran[671] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602F2CC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602F2CE mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602F2D0 sts.l pr,@-r15
    c.r[1] = ld32(0x0602F34Cu);  // 0602F2D2 mov.l 0x0602F34C,r1
    c.r[2] = ld32(c.r[1]);  // 0602F2D4 mov.l @r1,r2
    c.r[1] = c.r[2];  // 0602F2D6 mov r2,r1
    c.r[1] += 1;  // 0602F2D8 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602F2DA mov.b @r1,r1
    c.r[2] += 2;  // 0602F2DC add #2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0602F2DE extu.b r1,r1
    c.r[8] = c.r[1];  // 0602F2E0 mov r1,r8
    c.r[8] <<= 8;  // 0602F2E2 shll8 r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602F2E4 mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602F2E6 extu.b r1,r1
    c.r[8] |= c.r[1];  // 0602F2E8 or r1,r8
    c.r[1] = ld32(0x0602F350u);  // 0602F2EA mov.l 0x0602F350,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602F2F0u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602F2F0u) return; }  // 0602F2EC jsr @r1 ; mov r15,r14
    c.r[6] = 0x0u;  // 0602F2F0 mov #0,r6
    c.r[5] = (uint32_t)(int16_t)ld16(0x0602F348u);  // 0602F2F2 mov.w 0x0602F348,r5
    c.r[4] = ld32(0x0602F354u);  // 0602F2F4 mov.l 0x0602F354,r4
    c.r[3] = 0x0u;  // 0602F2F6 mov #0,r3
L_0602F2F8:
    c.r[1] = ld32(0x0602F358u);  // 0602F2F8 mov.l 0x0602F358,r1
    c.r[0] = ld32(c.r[1]);  // 0602F2FA mov.l @r1,r0
    c.r[2] = c.r[3];  // 0602F2FC mov r3,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 0602F2FE mov.w @(r0,r3),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0602F300 extu.w r1,r1
    c.t = c.r[1] == c.r[8];  // 0602F302 cmp/eq r8,r1
    { const bool k = !c.t; c.r[2] += c.r[0]; if (k) { goto L_0602F332; } }  // 0602F304 bf/s 0x0602F332 ; add r0,r2
    c.r[7] = c.r[2];  // 0602F308 mov r2,r7
    c.r[7] += 15;  // 0602F30A add #15,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0602F30C mov.b @r7,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0602F30E extu.b r1,r2
    c.t = c.r[2] == c.r[5];  // 0602F310 cmp/eq r5,r2
    { const bool k = c.t; c.r[6] += 1; if (k) { goto L_0602F334; } }  // 0602F312 bt/s 0x0602F334 ; add #1,r6
    c.r[1] = ld32(0x0602F35Cu);  // 0602F316 mov.l 0x0602F35C,r1
    c.r[0] = c.r[2];  // 0602F318 mov r2,r0
    c.r[0] += c.r[0];  // 0602F31A add r0,r0
    c.r[0] += c.r[2];  // 0602F31C add r2,r0
    c.r[1] = ld32(c.r[1]);  // 0602F31E mov.l @r1,r1
    c.r[0] <<= 2;  // 0602F320 shll2 r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0602F322 mov.w @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0602F324 extu.w r1,r1
    st32(c.r[4] + 20, c.r[1]);  // 0602F326 mov.l r1,@(20,r4)
    c.r[1] = ld32(0x0602F360u);  // 0602F328 mov.l 0x0602F360,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602F32Eu; st8(c.r[7], c.r[5]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602F32Eu) return; }  // 0602F32A jsr @r1 ; mov.b r5,@r7
    c.r[15] = c.r[14]; goto L_0602F33E;  // 0602F32E bra 0x0602F33E ; mov r14,r15
L_0602F332:
    c.r[6] += 1;  // 0602F332 add #1,r6
L_0602F334:
    c.r[1] = 0x7Fu;  // 0602F334 mov #127,r1
    c.t = (int32_t)c.r[6] > (int32_t)c.r[1];  // 0602F336 cmp/gt r1,r6
    { const bool k = !c.t; c.r[3] += 30; if (k) { SH2_POLL(c); goto L_0602F2F8; } }  // 0602F338 bf/s 0x0602F2F8 ; add #30,r3
    c.r[15] = c.r[14];  // 0602F33C mov r14,r15
L_0602F33E:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602F33E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602F340 mov.l @r15+,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602F34Au);  // 0602F342 mov.w 0x0602F34A,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602F344 rts ; mov.l @r15+,r8
}

void f_0602F364(SH2Context& c) {
    ran[672] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602F364 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602F366 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0602F368 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0602F36A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0602F36C mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602F36E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602F370 sts.l pr,@-r15
    c.r[1] = ld32(0x0602F3C0u);  // 0602F372 mov.l 0x0602F3C0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602F378u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602F378u) return; }  // 0602F374 jsr @r1 ; mov r15,r14
    c.r[8] = 0x0u;  // 0602F378 mov #0,r8
    c.r[10] = ld32(0x0602F3C4u);  // 0602F37A mov.l 0x0602F3C4,r10
    c.r[12] = ld32(0x0602F3C8u);  // 0602F37C mov.l 0x0602F3C8,r12
    c.r[11] = ld32(0x0602F3CCu);  // 0602F37E mov.l 0x0602F3CC,r11
    c.r[9] = 0x0u;  // 0602F380 mov #0,r9
L_0602F382:
    c.r[1] = ld32(0x0602F3D0u);  // 0602F382 mov.l 0x0602F3D0,r1
    c.r[0] = ld32(c.r[1]);  // 0602F384 mov.l @r1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[9]);  // 0602F386 mov.w @(r0,r9),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0602F388 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0602F38A tst r1,r1
    if (c.t) { goto L_0602F39C; }  // 0602F38C bt 0x0602F39C
    c.r[5] = c.r[8] & 0xFFu;  // 0602F38E extu.b r8,r5
    c.r[6] = (uint32_t)(int16_t)ld16(0x0602F3BAu);  // 0602F390 mov.w 0x0602F3BA,r6
    { const uint32_t x = c.r[12]; c.pr = 0x0602F396u; c.r[4] = ld32(c.r[10]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602F396u) return; }  // 0602F392 jsr @r12 ; mov.l @r10,r4
    c.r[4] = ld32(c.r[10]);  // 0602F396 mov.l @r10,r4
    { const uint32_t x = c.r[11]; c.pr = 0x0602F39Cu; c.r[5] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602F39Cu) return; }  // 0602F398 jsr @r11 ; extu.w r8,r5
L_0602F39C:
    c.r[8] += 1;  // 0602F39C add #1,r8
    c.r[1] = 0x7Fu;  // 0602F39E mov #127,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 0602F3A0 cmp/gt r1,r8
    { const bool k = !c.t; c.r[9] += 30; if (k) { SH2_POLL(c); goto L_0602F382; } }  // 0602F3A2 bf/s 0x0602F382 ; add #30,r9
    c.r[15] = c.r[14];  // 0602F3A6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602F3A8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602F3AA mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0602F3AC mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0602F3AE mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0602F3B0 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0602F3B2 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602F3BCu);  // 0602F3B4 mov.w 0x0602F3BC,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602F3B6 rts ; mov.l @r15+,r8
}

void f_0602F3D4(SH2Context& c) {
    ran[673] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602F3D4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602F3D6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602F3D8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602F3DA sts.l pr,@-r15
    c.r[1] = ld32(0x0602F484u);  // 0602F3DC mov.l 0x0602F484,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602F3E2u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602F3E2u) return; }  // 0602F3DE jsr @r1 ; mov r15,r14
    c.r[1] = ld32(0x0602F488u);  // 0602F3E2 mov.l 0x0602F488,r1
    c.r[2] = ld32(c.r[1]);  // 0602F3E4 mov.l @r1,r2
    c.r[0] = ld32(0x0602F48Cu);  // 0602F3E6 mov.l 0x0602F48C,r0
    c.r[1] = c.r[2];  // 0602F3E8 mov r2,r1
    c.r[1] += 1;  // 0602F3EA add #1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602F3EC mov.b @r1,r4
    c.r[2] += 2;  // 0602F3EE add #2,r2
    c.r[4] = c.r[4] & 0xFFu;  // 0602F3F0 extu.b r4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602F3F2 mov.b @r2,r1
    c.r[4] <<= 8;  // 0602F3F4 shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 0602F3F6 extu.b r1,r1
    { const uint32_t x = c.r[0]; c.pr = 0x0602F3FCu; c.r[4] |= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602F3FCu) return; }  // 0602F3F8 jsr @r0 ; or r1,r4
    c.r[4] = c.r[0] & 0xFFu;  // 0602F3FC extu.b r0,r4
    c.r[0] = ld32(0x0602F490u);  // 0602F3FE mov.l 0x0602F490,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602F404u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602F404u) return; }  // 0602F400 jsr @r0 ; nop
    c.r[9] = c.r[0] & 0xFFu;  // 0602F404 extu.b r0,r9
    c.r[6] = (uint32_t)(int16_t)ld16(0x0602F47Cu);  // 0602F406 mov.w 0x0602F47C,r6
    c.t = c.r[9] == c.r[6];  // 0602F408 cmp/eq r6,r9
    if (c.t) { goto L_0602F46E; }  // 0602F40A bt 0x0602F46E
    c.r[8] = ld32(0x0602F494u);  // 0602F40C mov.l 0x0602F494,r8
    c.r[1] = ld32(0x0602F498u);  // 0602F40E mov.l 0x0602F498,r1
    c.r[4] = ld32(c.r[8]);  // 0602F410 mov.l @r8,r4
    { const uint32_t x = c.r[1]; c.pr = 0x0602F416u; c.r[5] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602F416u) return; }  // 0602F412 jsr @r1 ; mov r9,r5
    c.r[2] = ld32(c.r[8]);  // 0602F416 mov.l @r8,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602F47Eu);  // 0602F418 mov.w 0x0602F47E,r1
    c.r[0] = c.r[2];  // 0602F41A mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0602F41C mov.b @(r0,r1),r1
    c.r[7] = 0x0u;  // 0602F41E mov #0,r7
    c.r[1] >>= 2;  // 0602F420 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0602F422 shlr r1
    c.r[0] = 0x7u;  // 0602F424 mov #7,r0
    c.r[1] &= c.r[0];  // 0602F426 and r0,r1
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[1];  // 0602F428 cmp/ge r1,r7
    if (c.t) { goto L_0602F46E; }  // 0602F42A bt 0x0602F46E
L_0602F42C:
    c.r[1] = ld32(0x0602F49Cu);  // 0602F42C mov.l 0x0602F49C,r1
    c.r[2] = ld32(c.r[1]);  // 0602F42E mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 0602F430 mov #30,r1
    c.macl = c.r[9] * c.r[1];  // 0602F432 mul.l r1,r9
    c.r[3] = c.macl;  // 0602F434 sts macl,r3
    c.r[3] += c.r[2];  // 0602F436 add r2,r3
    c.r[3] += c.r[7];  // 0602F438 add r7,r3
    c.r[3] += 17;  // 0602F43A add #17,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0602F43C mov.b @r3,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602F43E extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0602F440 tst r1,r1
    { const bool k = !c.t; c.r[7] += 1; if (k) { goto L_0602F45A; } }  // 0602F442 bf/s 0x0602F45A ; add #1,r7
    c.r[1] = ld32(0x0602F488u);  // 0602F446 mov.l 0x0602F488,r1
    c.r[1] = ld32(c.r[1]);  // 0602F448 mov.l @r1,r1
    c.r[1] += 3;  // 0602F44A add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602F44C mov.b @r1,r1
    st8(c.r[3], c.r[1]);  // 0602F44E mov.b r1,@r3
    c.r[1] = ld32(0x0602F4A0u);  // 0602F450 mov.l 0x0602F4A0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602F456u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602F456u) return; }  // 0602F452 jsr @r1 ; nop
    c.r[15] = c.r[14]; goto L_0602F470;  // 0602F456 bra 0x0602F470 ; mov r14,r15
L_0602F45A:
    c.r[1] = ld32(0x0602F494u);  // 0602F45A mov.l 0x0602F494,r1
    c.r[1] = ld32(c.r[1]);  // 0602F45C mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602F47Eu);  // 0602F45E mov.w 0x0602F47E,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0602F460 mov.b @(r0,r1),r1
    c.r[0] = c.r[1];  // 0602F462 mov r1,r0
    c.r[0] >>= 2;  // 0602F464 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0602F466 shlr r0
    c.r[0] &= 0x7u;  // 0602F468 and #7,r0
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[0];  // 0602F46A cmp/ge r0,r7
    if (!c.t) { SH2_POLL(c); goto L_0602F42C; }  // 0602F46C bf 0x0602F42C
L_0602F46E:
    c.r[15] = c.r[14];  // 0602F46E mov r14,r15
L_0602F470:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602F470 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602F472 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0602F474 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602F480u);  // 0602F476 mov.w 0x0602F480,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602F478 rts ; mov.l @r15+,r8
}

void f_0602F4A4(SH2Context& c) {
    ran[674] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602F4A4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602F4A6 sts.l pr,@-r15
    c.r[1] = ld32(0x0602F4ECu);  // 0602F4A8 mov.l 0x0602F4EC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602F4AEu; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602F4AEu) return; }  // 0602F4AA jsr @r1 ; mov r15,r14
    c.r[1] = ld32(0x0602F4F0u);  // 0602F4AE mov.l 0x0602F4F0,r1
    c.r[1] = ld32(c.r[1]);  // 0602F4B0 mov.l @r1,r1
    c.r[1] += 1;  // 0602F4B2 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602F4B4 mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0602F4B6 extu.b r1,r2
    c.r[1] = 0x1Du;  // 0602F4B8 mov #29,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0602F4BA cmp/gt r1,r2
    if (c.t) { goto L_0602F4DE; }  // 0602F4BC bt 0x0602F4DE
    c.r[1] = ld32(0x0602F4F4u);  // 0602F4BE mov.l 0x0602F4F4,r1
    c.r[7] = ld32(c.r[1]);  // 0602F4C0 mov.l @r1,r7
    c.r[6] = (uint32_t)(int16_t)ld16(0x0602F4E8u);  // 0602F4C2 mov.w 0x0602F4E8,r6
    c.r[7] += c.r[2];  // 0602F4C4 add r2,r7
    c.r[0] = c.r[7];  // 0602F4C6 mov r7,r0
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 0602F4C8 mov.b @(r0,r6),r3
    c.r[1] = 0x8u;  // 0602F4CA mov #8,r1
    c.r[2] = c.r[3] & 0xFFu;  // 0602F4CC extu.b r3,r2
    c.t = c.r[2] > c.r[1];  // 0602F4CE cmp/hi r1,r2
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_0602F4DE; } }  // 0602F4D0 bt/s 0x0602F4DE ; mov r3,r1
    c.r[1] += 1;  // 0602F4D4 add #1,r1
    st8(c.r[0] + c.r[6], c.r[1]);  // 0602F4D6 mov.b r1,@(r0,r6)
    c.r[1] = ld32(0x0602F4F8u);  // 0602F4D8 mov.l 0x0602F4F8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602F4DEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602F4DEu) return; }  // 0602F4DA jsr @r1 ; nop
L_0602F4DE:
    c.r[15] = c.r[14];  // 0602F4DE mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602F4E0 lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602F4EAu);  // 0602F4E2 mov.w 0x0602F4EA,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602F4E4 rts ; mov.l @r15+,r14
}

void f_0602F4FC(SH2Context& c) {
    ran[675] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602F4FC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602F4FE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0602F500 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602F502 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602F504 sts.l pr,@-r15
    c.r[1] = ld32(0x0602F590u);  // 0602F506 mov.l 0x0602F590,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602F50Cu; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602F50Cu) return; }  // 0602F508 jsr @r1 ; mov r15,r14
    c.r[8] = ld32(0x0602F594u);  // 0602F50C mov.l 0x0602F594,r8
    c.r[2] = ld32(c.r[8]);  // 0602F50E mov.l @r8,r2
    c.r[0] = ld32(0x0602F598u);  // 0602F510 mov.l 0x0602F598,r0
    c.r[1] = c.r[2];  // 0602F512 mov r2,r1
    c.r[1] += 1;  // 0602F514 add #1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602F516 mov.b @r1,r4
    c.r[2] += 2;  // 0602F518 add #2,r2
    c.r[4] = c.r[4] & 0xFFu;  // 0602F51A extu.b r4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602F51C mov.b @r2,r1
    c.r[4] <<= 8;  // 0602F51E shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 0602F520 extu.b r1,r1
    { const uint32_t x = c.r[0]; c.pr = 0x0602F526u; c.r[4] |= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602F526u) return; }  // 0602F522 jsr @r0 ; or r1,r4
    c.r[9] = c.r[0] & 0xFFu;  // 0602F526 extu.b r0,r9
    c.r[10] = (uint32_t)(int16_t)ld16(0x0602F58Au);  // 0602F528 mov.w 0x0602F58A,r10
    c.t = c.r[9] == c.r[10];  // 0602F52A cmp/eq r10,r9
    if (c.t) { goto L_0602F57A; }  // 0602F52C bt 0x0602F57A
    c.r[3] = ld32(c.r[8]);  // 0602F52E mov.l @r8,r3
    c.r[1] = ld32(0x0602F59Cu);  // 0602F530 mov.l 0x0602F59C,r1
    c.r[2] = ld32(c.r[1]);  // 0602F532 mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 0602F534 mov #30,r1
    c.macl = c.r[9] * c.r[1];  // 0602F536 mul.l r1,r9
    c.r[7] = c.macl;  // 0602F538 sts macl,r7
    c.r[7] += c.r[2];  // 0602F53A add r2,r7
    c.r[1] = c.r[3];  // 0602F53C mov r3,r1
    c.r[1] += 3;  // 0602F53E add #3,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602F540 mov.b @r1,r2
    c.r[3] += 4;  // 0602F542 add #4,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0602F544 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0602F546 mov.b @r3,r1
    c.r[2] <<= 8;  // 0602F548 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0602F54A extu.b r1,r1
    c.r[2] |= c.r[1];  // 0602F54C or r1,r2
    st16(c.r[7], c.r[2]);  // 0602F54E mov.w r2,@r7
    c.r[7] += 15;  // 0602F550 add #15,r7
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0602F552 mov.b @r7,r8
    c.r[1] = ld32(0x0602F5A0u);  // 0602F554 mov.l 0x0602F5A0,r1
    c.r[4] = ld32(c.r[1]);  // 0602F556 mov.l @r1,r4
    c.r[8] = c.r[8] & 0xFFu;  // 0602F558 extu.b r8,r8
    c.r[1] = ld32(0x0602F5A4u);  // 0602F55A mov.l 0x0602F5A4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602F560u; c.r[5] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602F560u) return; }  // 0602F55C jsr @r1 ; mov r8,r5
    c.r[1] = ld32(0x0602F5A8u);  // 0602F560 mov.l 0x0602F5A8,r1
    c.r[6] = c.r[10];  // 0602F562 mov r10,r6
    c.r[4] = ld32(c.r[1]);  // 0602F564 mov.l @r1,r4
    c.r[1] = ld32(0x0602F5ACu);  // 0602F566 mov.l 0x0602F5AC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602F56Cu; c.r[5] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602F56Cu) return; }  // 0602F568 jsr @r1 ; mov r8,r5
    c.r[1] = ld32(0x0602F5B0u);  // 0602F56C mov.l 0x0602F5B0,r1
    c.r[5] = c.r[9];  // 0602F56E mov r9,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0602F574u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602F574u) return; }  // 0602F570 jsr @r1 ; mov r8,r4
    c.r[1] = ld32(0x0602F5B4u);  // 0602F574 mov.l 0x0602F5B4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602F57Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602F57Au) return; }  // 0602F576 jsr @r1 ; nop
L_0602F57A:
    c.r[15] = c.r[14];  // 0602F57A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602F57C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602F57E mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0602F580 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0602F582 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602F58Cu);  // 0602F584 mov.w 0x0602F58C,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602F586 rts ; mov.l @r15+,r8
}

void f_0602F5B8(SH2Context& c) {
    ran[676] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602F5B8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602F5BA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602F5BC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602F5BE sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x0602F66Eu);  // 0602F5C0 mov.w 0x0602F66E,r3
    c.r[1] = ld32(0x0602F67Cu);  // 0602F5C2 mov.l 0x0602F67C,r1
    c.r[2] = ld32(c.r[1]);  // 0602F5C4 mov.l @r1,r2
    c.r[15] += c.r[3];  // 0602F5C6 add r3,r15
    c.r[1] = c.r[2];  // 0602F5C8 mov r2,r1
    c.r[1] += 1;  // 0602F5CA add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602F5CC mov.b @r1,r1
    c.r[2] += 2;  // 0602F5CE add #2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0602F5D0 extu.b r1,r1
    c.r[8] = c.r[1];  // 0602F5D2 mov r1,r8
    c.r[8] <<= 8;  // 0602F5D4 shll8 r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602F5D6 mov.b @r2,r1
    c.r[14] = c.r[15];  // 0602F5D8 mov r15,r14
    c.r[1] = c.r[1] & 0xFFu;  // 0602F5DA extu.b r1,r1
    c.r[8] |= c.r[1];  // 0602F5DC or r1,r8
    c.r[1] = ld32(0x0602F680u);  // 0602F5DE mov.l 0x0602F680,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602F5E4u; c.r[9] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602F5E4u) return; }  // 0602F5E0 jsr @r1 ; mov r8,r9
    c.r[1] = c.r[8];  // 0602F5E4 mov r8,r1
    c.r[1] >>= 8;  // 0602F5E6 shlr8 r1
    c.r[1] += c.r[1];  // 0602F5E8 add r1,r1
    c.r[1] >>= 8;  // 0602F5EA shlr8 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0602F5EC tst r1,r1
    { const bool k = c.t; c.r[4] = c.r[9]; if (k) { goto L_0602F604; } }  // 0602F5EE bt/s 0x0602F604 ; mov r9,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602F670u);  // 0602F5F2 mov.w 0x0602F670,r1
    c.r[8] &= c.r[1];  // 0602F5F4 and r1,r8
    c.r[0] = ld32(0x0602F684u);  // 0602F5F6 mov.l 0x0602F684,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602F5FCu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602F5FCu) return; }  // 0602F5F8 jsr @r0 ; mov r8,r4
    c.r[4] = c.r[0] & 0xFFu;  // 0602F5FC extu.b r0,r4
    c.r[0] = ld32(0x0602F688u);  // 0602F5FE mov.l 0x0602F688,r0
    goto L_0602F606;  // 0602F600 bra 0x0602F606 ; nop
L_0602F604:
    c.r[0] = ld32(0x0602F68Cu);  // 0602F604 mov.l 0x0602F68C,r0
L_0602F606:
    { const uint32_t x = c.r[0]; c.pr = 0x0602F60Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602F60Au) return; }  // 0602F606 jsr @r0 ; nop
    c.r[8] = c.r[0] & 0xFFu;  // 0602F60A extu.b r0,r8
    c.r[6] = (uint32_t)(int16_t)ld16(0x0602F672u);  // 0602F60C mov.w 0x0602F672,r6
    c.t = c.r[8] == c.r[6];  // 0602F60E cmp/eq r6,r8
    { const bool k = c.t; c.r[5] = c.r[8]; if (k) { goto L_0602F65C; } }  // 0602F610 bt/s 0x0602F65C ; mov r8,r5
    c.r[1] = ld32(0x0602F690u);  // 0602F614 mov.l 0x0602F690,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602F61Au; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602F61Au) return; }  // 0602F616 jsr @r1 ; mov r14,r4
    c.r[7] = (uint32_t)(int16_t)ld16(0x0602F674u);  // 0602F61A mov.w 0x0602F674,r7
    c.r[0] = c.r[14];  // 0602F61C mov r14,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0602F61E mov.b @(r0,r7),r1
    c.r[3] = 0x0u;  // 0602F620 mov #0,r3
    c.r[1] >>= 2;  // 0602F622 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0602F624 shlr r1
    c.r[0] = 0x7u;  // 0602F626 mov #7,r0
    c.r[1] &= c.r[0];  // 0602F628 and r0,r1
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[1];  // 0602F62A cmp/ge r1,r3
    { const bool k = c.t; c.r[5] = 0x1Eu; if (k) { goto L_0602F656; } }  // 0602F62C bt/s 0x0602F656 ; mov #30,r5
    c.r[4] = ld32(0x0602F694u);  // 0602F630 mov.l 0x0602F694,r4
    c.r[6] = 0x0u;  // 0602F632 mov #0,r6
    c.macl = c.r[8] * c.r[5];  // 0602F634 mul.l r5,r8
    c.r[0] = c.r[14];  // 0602F636 mov r14,r0
L_0602F638:
    c.r[1] = ld32(c.r[4]);  // 0602F638 mov.l @r4,r1
    c.r[2] = c.macl;  // 0602F63A sts macl,r2
    c.r[2] += c.r[1];  // 0602F63C add r1,r2
    c.r[2] += c.r[3];  // 0602F63E add r3,r2
    c.r[2] += 17;  // 0602F640 add #17,r2
    st8(c.r[2], c.r[6]);  // 0602F642 mov.b r6,@r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0602F644 mov.b @(r0,r7),r1
    c.r[3] += 1;  // 0602F646 add #1,r3
    c.r[1] >>= 2;  // 0602F648 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0602F64A shlr r1
    c.r[0] = 0x7u;  // 0602F64C mov #7,r0
    c.r[1] &= c.r[0];  // 0602F64E and r0,r1
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[1];  // 0602F650 cmp/ge r1,r3
    { const bool k = !c.t; c.r[0] = c.r[14]; if (k) { SH2_POLL(c); goto L_0602F638; } }  // 0602F652 bf/s 0x0602F638 ; mov r14,r0
L_0602F656:
    c.r[1] = ld32(0x0602F698u);  // 0602F656 mov.l 0x0602F698,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602F65Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602F65Cu) return; }  // 0602F658 jsr @r1 ; nop
L_0602F65C:
    c.r[3] = (uint32_t)(int16_t)ld16(0x0602F676u);  // 0602F65C mov.w 0x0602F676,r3
    c.r[14] += c.r[3];  // 0602F65E add r3,r14
    c.r[15] = c.r[14];  // 0602F660 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602F662 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602F664 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0602F666 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602F678u);  // 0602F668 mov.w 0x0602F678,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602F66A rts ; mov.l @r15+,r8
}

void f_0602F69C(SH2Context& c) {
    ran[677] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602F69C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602F69E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602F6A0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602F6A2 sts.l pr,@-r15
    c.r[1] = ld32(0x0602F708u);  // 0602F6A4 mov.l 0x0602F708,r1
    c.r[2] = ld32(c.r[1]);  // 0602F6A6 mov.l @r1,r2
    c.r[1] = c.r[2];  // 0602F6A8 mov r2,r1
    c.r[1] += 1;  // 0602F6AA add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602F6AC mov.b @r1,r1
    c.r[2] += 2;  // 0602F6AE add #2,r2
    c.r[9] = c.r[1] & 0xFFu;  // 0602F6B0 extu.b r1,r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602F6B2 mov.b @r2,r1
    c.r[8] = c.r[1] & 0xFFu;  // 0602F6B4 extu.b r1,r8
    c.r[1] = ld32(0x0602F70Cu);  // 0602F6B6 mov.l 0x0602F70C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602F6BCu; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602F6BCu) return; }  // 0602F6B8 jsr @r1 ; mov r15,r14
    c.r[3] = 0x0u;  // 0602F6BC mov #0,r3
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[8];  // 0602F6BE cmp/ge r8,r3
    { const bool k = c.t; c.t = c.r[3] == c.r[8]; if (k) { goto L_0602F6EC; } }  // 0602F6C0 bt/s 0x0602F6EC ; cmp/eq r8,r3
    c.r[4] = 0x1Du;  // 0602F6C4 mov #29,r4
    c.r[5] = ld32(0x0602F710u);  // 0602F6C6 mov.l 0x0602F710,r5
    c.r[7] = (uint32_t)(int16_t)ld16(0x0602F702u);  // 0602F6C8 mov.w 0x0602F702,r7
    c.r[6] = 0x8u;  // 0602F6CA mov #8,r6
    c.t = c.r[9] > c.r[4];  // 0602F6CC cmp/hi r4,r9
L_0602F6CE:
    if (c.t) { goto L_0602F6E2; }  // 0602F6CE bt 0x0602F6E2
    c.r[0] = ld32(c.r[5]);  // 0602F6D0 mov.l @r5,r0
    c.r[0] += c.r[9];  // 0602F6D2 add r9,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0602F6D4 mov.b @(r0,r7),r2
    c.r[1] = c.r[2] & 0xFFu;  // 0602F6D6 extu.b r2,r1
    c.t = c.r[1] > c.r[6];  // 0602F6D8 cmp/hi r6,r1
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_0602F6E2; } }  // 0602F6DA bt/s 0x0602F6E2 ; mov r2,r1
    c.r[1] += 1;  // 0602F6DE add #1,r1
    st8(c.r[0] + c.r[7], c.r[1]);  // 0602F6E0 mov.b r1,@(r0,r7)
L_0602F6E2:
    c.r[3] += 1;  // 0602F6E2 add #1,r3
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[8];  // 0602F6E4 cmp/ge r8,r3
    { const bool k = !c.t; c.t = c.r[9] > c.r[4]; if (k) { SH2_POLL(c); goto L_0602F6CE; } }  // 0602F6E6 bf/s 0x0602F6CE ; cmp/hi r4,r9
    c.t = c.r[3] == c.r[8];  // 0602F6EA cmp/eq r8,r3
L_0602F6EC:
    if (!c.t) { goto L_0602F6F4; }  // 0602F6EC bf 0x0602F6F4
    c.r[1] = ld32(0x0602F714u);  // 0602F6EE mov.l 0x0602F714,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602F6F4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602F6F4u) return; }  // 0602F6F0 jsr @r1 ; nop
L_0602F6F4:
    c.r[15] = c.r[14];  // 0602F6F4 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602F6F6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602F6F8 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0602F6FA mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602F704u);  // 0602F6FC mov.w 0x0602F704,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602F6FE rts ; mov.l @r15+,r8
}

void f_0602F718(SH2Context& c) {
    ran[678] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602F718 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602F71A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602F71C sts.l pr,@-r15
    c.r[1] = ld32(0x0602F768u);  // 0602F71E mov.l 0x0602F768,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602F724u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602F724u) return; }  // 0602F720 jsr @r1 ; mov r15,r14
    c.r[1] = ld32(0x0602F76Cu);  // 0602F724 mov.l 0x0602F76C,r1
    c.r[2] = ld32(c.r[1]);  // 0602F726 mov.l @r1,r2
    c.r[0] = ld32(0x0602F770u);  // 0602F728 mov.l 0x0602F770,r0
    c.r[1] = c.r[2];  // 0602F72A mov r2,r1
    c.r[1] += 1;  // 0602F72C add #1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602F72E mov.b @r1,r4
    c.r[2] += 2;  // 0602F730 add #2,r2
    c.r[4] = c.r[4] & 0xFFu;  // 0602F732 extu.b r4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602F734 mov.b @r2,r1
    c.r[4] <<= 8;  // 0602F736 shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 0602F738 extu.b r1,r1
    { const uint32_t x = c.r[0]; c.pr = 0x0602F73Eu; c.r[4] |= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602F73Eu) return; }  // 0602F73A jsr @r0 ; or r1,r4
    c.r[4] = c.r[0] & 0xFFu;  // 0602F73E extu.b r0,r4
    c.r[8] = (uint32_t)(int16_t)ld16(0x0602F764u);  // 0602F740 mov.w 0x0602F764,r8
    c.t = c.r[4] == c.r[8];  // 0602F742 cmp/eq r8,r4
    if (c.t) { goto L_0602F758; }  // 0602F744 bt 0x0602F758
    c.r[0] = ld32(0x0602F774u);  // 0602F746 mov.l 0x0602F774,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602F74Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602F74Cu) return; }  // 0602F748 jsr @r0 ; nop
    c.r[1] = c.r[0] & 0xFFu;  // 0602F74C extu.b r0,r1
    c.t = c.r[1] == c.r[8];  // 0602F74E cmp/eq r8,r1
    if (c.t) { goto L_0602F758; }  // 0602F750 bt 0x0602F758
    c.r[1] = ld32(0x0602F778u);  // 0602F752 mov.l 0x0602F778,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602F758u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602F758u) return; }  // 0602F754 jsr @r1 ; nop
L_0602F758:
    c.r[15] = c.r[14];  // 0602F758 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602F75A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602F75C mov.l @r15+,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602F766u);  // 0602F75E mov.w 0x0602F766,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602F760 rts ; mov.l @r15+,r8
}

void f_0602F77C(SH2Context& c) {
    ran[679] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602F77C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602F77E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0602F780 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0602F782 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602F784 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602F786 sts.l pr,@-r15
    c.r[15] -= 128;  // 0602F788 add #-128,r15
    c.r[14] = c.r[15];  // 0602F78A mov r15,r14
    c.r[1] = 0x2u;  // 0602F78C mov #2,r1
    st16(c.r[14], c.r[1]);  // 0602F78E mov.w r1,@r14
    c.r[2] = c.r[14];  // 0602F790 mov r14,r2
    c.r[2] += 2;  // 0602F792 add #2,r2
    c.r[1] = 0x3u;  // 0602F794 mov #3,r1
    st16(c.r[2], c.r[1]);  // 0602F796 mov.w r1,@r2
    c.r[2] = c.r[14];  // 0602F798 mov r14,r2
    c.r[2] += 4;  // 0602F79A add #4,r2
    c.r[1] = 0x4u;  // 0602F79C mov #4,r1
    st16(c.r[2], c.r[1]);  // 0602F79E mov.w r1,@r2
    c.r[2] = c.r[14];  // 0602F7A0 mov r14,r2
    c.r[2] += 6;  // 0602F7A2 add #6,r2
    c.r[1] = 0x26u;  // 0602F7A4 mov #38,r1
    st16(c.r[2], c.r[1]);  // 0602F7A6 mov.w r1,@r2
    c.r[2] = c.r[14];  // 0602F7A8 mov r14,r2
    c.r[2] += 8;  // 0602F7AA add #8,r2
    c.r[1] = 0x34u;  // 0602F7AC mov #52,r1
    st16(c.r[2], c.r[1]);  // 0602F7AE mov.w r1,@r2
    c.r[1] = c.r[14];  // 0602F7B0 mov r14,r1
    c.r[1] += 10;  // 0602F7B2 add #10,r1
    c.r[8] = (uint32_t)(int16_t)ld16(0x0602F8A8u);  // 0602F7B4 mov.w 0x0602F8A8,r8
    st16(c.r[1], c.r[8]);  // 0602F7B6 mov.w r8,@r1
    c.r[1] = ld32(0x0602F8B0u);  // 0602F7B8 mov.l 0x0602F8B0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602F7BEu; c.r[10] = 0x5u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602F7BEu) return; }  // 0602F7BA jsr @r1 ; mov #5,r10
    c.r[7] = ld32(0x0602F8B4u);  // 0602F7BE mov.l 0x0602F8B4,r7
    c.r[2] = ld32(c.r[7]);  // 0602F7C0 mov.l @r7,r2
    c.r[1] = c.r[2];  // 0602F7C2 mov r2,r1
    c.r[1] += 1;  // 0602F7C4 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602F7C6 mov.b @r1,r1
    c.r[2] += 2;  // 0602F7C8 add #2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0602F7CA extu.b r1,r1
    c.r[3] = c.r[1];  // 0602F7CC mov r1,r3
    c.r[3] <<= 8;  // 0602F7CE shll8 r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602F7D0 mov.b @r2,r1
    c.r[8] = c.r[8] & 0xFFFFu;  // 0602F7D2 extu.w r8,r8
    c.r[1] = c.r[1] & 0xFFu;  // 0602F7D4 extu.b r1,r1
    c.r[3] |= c.r[1];  // 0602F7D6 or r1,r3
    c.t = c.r[3] == c.r[8];  // 0602F7D8 cmp/eq r8,r3
    { const bool k = c.t; c.r[9] = 0x0u; if (k) { goto L_0602F81E; } }  // 0602F7DA bt/s 0x0602F81E ; mov #0,r9
    c.r[6] = 0xAu;  // 0602F7DE mov #10,r6
    c.r[0] = c.r[6];  // 0602F7E0 mov r6,r0
L_0602F7E2:
    st16(c.r[0] + c.r[14], c.r[3]);  // 0602F7E2 mov.w r3,@(r0,r14)
    c.r[6] += 2;  // 0602F7E4 add #2,r6
    c.r[0] = c.r[6];  // 0602F7E6 mov r6,r0
    st16(c.r[0] + c.r[14], c.r[8]);  // 0602F7E8 mov.w r8,@(r0,r14)
    c.r[2] = ld32(c.r[7]);  // 0602F7EA mov.l @r7,r2
    c.r[1] = c.r[2];  // 0602F7EC mov r2,r1
    c.r[1] += 2;  // 0602F7EE add #2,r1
    st32(c.r[7], c.r[1]);  // 0602F7F0 mov.l r1,@r7
    c.r[1] += 1;  // 0602F7F2 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602F7F4 mov.b @r1,r1
    c.r[2] += 4;  // 0602F7F6 add #4,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0602F7F8 extu.b r1,r1
    c.r[3] = c.r[1];  // 0602F7FA mov r1,r3
    c.r[3] <<= 8;  // 0602F7FC shll8 r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602F7FE mov.b @r2,r1
    c.r[10] += 1;  // 0602F800 add #1,r10
    c.r[1] = c.r[1] & 0xFFu;  // 0602F802 extu.b r1,r1
    c.r[3] |= c.r[1];  // 0602F804 or r1,r3
    c.r[1] = 0x3Fu;  // 0602F806 mov #63,r1
    c.t = (int32_t)c.r[10] > (int32_t)c.r[1];  // 0602F808 cmp/gt r1,r10
    { const bool k = !c.t; c.t = c.r[3] == c.r[8]; if (k) { goto L_0602F818; } }  // 0602F80A bf/s 0x0602F818 ; cmp/eq r8,r3
    c.r[1] = ld32(0x0602F8B8u);  // 0602F80E mov.l 0x0602F8B8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602F814u; c.r[9] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602F814u) return; }  // 0602F810 jsr @r1 ; mov #0,r9
    goto L_0602F81E;  // 0602F814 bra 0x0602F81E ; nop
L_0602F818:
    { const bool k = !c.t; c.r[0] = c.r[6]; if (k) { SH2_POLL(c); goto L_0602F7E2; } }  // 0602F818 bf/s 0x0602F7E2 ; mov r6,r0
    c.r[9] = 0x0u;  // 0602F81C mov #0,r9
L_0602F81E:
    c.r[11] = ld32(0x0602F8BCu);  // 0602F81E mov.l 0x0602F8BC,r11
    c.r[8] = 0x0u;  // 0602F820 mov #0,r8
L_0602F822:
    c.r[2] = c.r[8];  // 0602F822 mov r8,r2
    c.r[7] = ld32(c.r[11]);  // 0602F824 mov.l @r11,r7
    c.r[0] = c.r[8];  // 0602F826 mov r8,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[7]);  // 0602F828 mov.w @(r0,r7),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0602F82A extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0602F82C tst r1,r1
    { const bool k = c.t; c.r[2] += c.r[7]; if (k) { goto L_0602F888; } }  // 0602F82E bt/s 0x0602F888 ; add r7,r2
    c.r[1] = c.r[2];  // 0602F832 mov r2,r1
    c.r[1] += 2;  // 0602F834 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602F836 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0602F838 extu.b r1,r0
    c.r[0] >>= 2;  // 0602F83A shlr2 r0
    c.r[0] >>= 2;  // 0602F83C shlr2 r0
    c.r[0] >>= 2;  // 0602F83E shlr2 r0
    c.t = c.r[0] == 0x1u;  // 0602F840 cmp/eq #1,r0
    { const bool k = !c.t; c.r[2] += 15; if (k) { goto L_0602F888; } }  // 0602F842 bf/s 0x0602F888 ; add #15,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602F846 mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602F848 extu.b r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0602F8AAu);  // 0602F84A mov.w 0x0602F8AA,r2
    c.t = c.r[1] == c.r[2];  // 0602F84C cmp/eq r2,r1
    { const bool k = !c.t; c.r[3] = 0x0u; if (k) { goto L_0602F888; } }  // 0602F84E bf/s 0x0602F888 ; mov #0,r3
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[10];  // 0602F852 cmp/ge r10,r3
    { const bool k = c.t; c.t = (c.r[3] & c.r[3]) == 0; if (k) { goto L_0602F880; } }  // 0602F854 bt/s 0x0602F880 ; tst r3,r3
    c.r[6] = c.r[7];  // 0602F858 mov r7,r6
    c.r[5] = 0x0u;  // 0602F85A mov #0,r5
    c.r[7] = c.r[10];  // 0602F85C mov r10,r7
    c.r[7] += c.r[7];  // 0602F85E add r7,r7
    c.r[0] = c.r[8];  // 0602F860 mov r8,r0
L_0602F862:
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[6]);  // 0602F862 mov.w @(r0,r6),r2
    c.r[0] = c.r[5];  // 0602F864 mov r5,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[14]);  // 0602F866 mov.w @(r0,r14),r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 0602F868 extu.w r2,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 0602F86A extu.w r1,r1
    c.t = c.r[2] == c.r[1];  // 0602F86C cmp/eq r1,r2
    if (!c.t) { goto L_0602F876; }  // 0602F86E bf 0x0602F876
    c.r[3] = 0x1u;  // 0602F870 mov #1,r3
    c.t = (c.r[3] & c.r[3]) == 0; goto L_0602F880;  // 0602F872 bra 0x0602F880 ; tst r3,r3
L_0602F876:
    c.r[5] += 2;  // 0602F876 add #2,r5
    c.t = (int32_t)c.r[5] >= (int32_t)c.r[7];  // 0602F878 cmp/ge r7,r5
    { const bool k = !c.t; c.r[0] = c.r[8]; if (k) { SH2_POLL(c); goto L_0602F862; } }  // 0602F87A bf/s 0x0602F862 ; mov r8,r0
    c.t = (c.r[3] & c.r[3]) == 0;  // 0602F87E tst r3,r3
L_0602F880:
    if (!c.t) { goto L_0602F888; }  // 0602F880 bf 0x0602F888
    c.r[1] = ld32(0x0602F8C0u);  // 0602F882 mov.l 0x0602F8C0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602F888u; c.r[4] = c.r[9] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602F888u) return; }  // 0602F884 jsr @r1 ; extu.b r9,r4
L_0602F888:
    c.r[9] += 1;  // 0602F888 add #1,r9
    c.r[1] = 0x7Fu;  // 0602F88A mov #127,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 0602F88C cmp/gt r1,r9
    { const bool k = !c.t; c.r[8] += 30; if (k) { SH2_POLL(c); goto L_0602F822; } }  // 0602F88E bf/s 0x0602F822 ; add #30,r8
    c.r[3] = (uint32_t)(int16_t)ld16(0x0602F8ACu);  // 0602F892 mov.w 0x0602F8AC,r3
    c.r[14] += c.r[3];  // 0602F894 add r3,r14
    c.r[15] = c.r[14];  // 0602F896 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602F898 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602F89A mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0602F89C mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0602F89E mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0602F8A0 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602F8AEu);  // 0602F8A2 mov.w 0x0602F8AE,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602F8A4 rts ; mov.l @r15+,r8
}

void f_0602F8C4(SH2Context& c) {
    ran[680] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602F8C4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602F8C6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0602F8C8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0602F8CA mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0602F8CC mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0602F8CE mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602F8D0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602F8D2 sts.l pr,@-r15
    c.r[15] -= 4;  // 0602F8D4 add #-4,r15
    c.r[1] = ld32(0x0602F988u);  // 0602F8D6 mov.l 0x0602F988,r1
    c.r[2] = ld32(c.r[1]);  // 0602F8D8 mov.l @r1,r2
    c.r[1] = c.r[2];  // 0602F8DA mov r2,r1
    c.r[1] += 1;  // 0602F8DC add #1,r1
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602F8DE mov.b @r1,r8
    c.r[2] += 2;  // 0602F8E0 add #2,r2
    c.r[8] = c.r[8] & 0xFFu;  // 0602F8E2 extu.b r8,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602F8E4 mov.b @r2,r1
    c.r[8] <<= 8;  // 0602F8E6 shll8 r8
    c.r[1] = c.r[1] & 0xFFu;  // 0602F8E8 extu.b r1,r1
    c.r[8] |= c.r[1];  // 0602F8EA or r1,r8
    c.r[1] = ld32(0x0602F98Cu);  // 0602F8EC mov.l 0x0602F98C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602F8F2u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602F8F2u) return; }  // 0602F8EE jsr @r1 ; mov r15,r14
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602F982u);  // 0602F8F2 mov.w 0x0602F982,r1
    c.r[7] = c.r[1];  // 0602F8F4 mov r1,r7
    c.r[7] &= c.r[8];  // 0602F8F6 and r8,r7
    st32(c.r[14], c.r[7]);  // 0602F8F8 mov.l r7,@r14
    c.r[11] = c.r[8];  // 0602F8FA mov r8,r11
    c.r[11] >>= 8;  // 0602F8FC shlr8 r11
    c.t = c.r[11] & 1; c.r[11] >>= 1;  // 0602F8FE shlr r11
    c.r[10] = 0x0u;  // 0602F900 mov #0,r10
    c.r[13] = ld32(0x0602F990u);  // 0602F902 mov.l 0x0602F990,r13
    c.r[12] = ld32(0x0602F994u);  // 0602F904 mov.l 0x0602F994,r12
    c.r[1] = 0x1Eu;  // 0602F906 mov #30,r1
L_0602F908:
    c.macl = c.r[10] * c.r[1];  // 0602F908 mul.l r1,r10
    c.r[2] = ld32(c.r[13]);  // 0602F90A mov.l @r13,r2
    c.r[3] = c.macl;  // 0602F90C sts macl,r3
    c.r[3] += c.r[2];  // 0602F90E add r2,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0602F910 mov.w @r3,r1
    c.r[7] = ld32(c.r[14]);  // 0602F912 mov.l @r14,r7
    c.r[1] = c.r[1] & 0xFFFFu;  // 0602F914 extu.w r1,r1
    c.t = c.r[1] == c.r[7];  // 0602F916 cmp/eq r7,r1
    { const bool k = !c.t; c.r[1] = c.r[10]; if (k) { goto L_0602F95E; } }  // 0602F918 bf/s 0x0602F95E ; mov r10,r1
    c.r[3] += 2;  // 0602F91C add #2,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0602F91E mov.b @r3,r1
    c.r[0] = c.r[1];  // 0602F920 mov r1,r0
    c.r[0] >>= 2;  // 0602F922 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0602F924 shlr r0
    c.r[0] &= 0x3u;  // 0602F926 and #3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0602F928 tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[10]; if (k) { goto L_0602F95E; } }  // 0602F92A bf/s 0x0602F95E ; mov r10,r1
    c.r[5] = c.r[11] & 0xFFu;  // 0602F92E extu.b r11,r5
    { const uint32_t x = c.r[12]; c.pr = 0x0602F934u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602F934u) return; }  // 0602F930 jsr @r12 ; mov r10,r4
    c.r[8] = 0x0u;  // 0602F934 mov #0,r8
    c.r[9] = 0x0u;  // 0602F936 mov #0,r9
L_0602F938:
    c.r[1] = ld32(c.r[13]);  // 0602F938 mov.l @r13,r1
    c.r[1] += c.r[9];  // 0602F93A add r9,r1
    c.r[1] += 16;  // 0602F93C add #16,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602F93E mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602F940 extu.b r1,r1
    c.t = c.r[1] == c.r[10];  // 0602F942 cmp/eq r10,r1
    { const bool k = !c.t; c.r[4] = c.r[8] & 0xFFu; if (k) { goto L_0602F94C; } }  // 0602F944 bf/s 0x0602F94C ; extu.b r8,r4
    { const uint32_t x = c.r[12]; c.pr = 0x0602F94Cu; c.r[5] = c.r[11] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602F94Cu) return; }  // 0602F948 jsr @r12 ; extu.b r11,r5
L_0602F94C:
    c.r[8] += 1;  // 0602F94C add #1,r8
    c.r[1] = 0x7Fu;  // 0602F94E mov #127,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 0602F950 cmp/gt r1,r8
    { const bool k = !c.t; c.r[9] += 30; if (k) { SH2_POLL(c); goto L_0602F938; } }  // 0602F952 bf/s 0x0602F938 ; add #30,r9
    c.r[1] = ld32(0x0602F998u);  // 0602F956 mov.l 0x0602F998,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602F95Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602F95Cu) return; }  // 0602F958 jsr @r1 ; nop
    c.r[1] = c.r[10];  // 0602F95C mov r10,r1
L_0602F95E:
    c.r[1] += 1;  // 0602F95E add #1,r1
    c.r[10] = c.r[1] & 0xFFu;  // 0602F960 extu.b r1,r10
    c.r[1] = 0x7Fu;  // 0602F962 mov #127,r1
    c.t = c.r[10] > c.r[1];  // 0602F964 cmp/hi r1,r10
    { const bool k = !c.t; c.r[1] = 0x1Eu; if (k) { SH2_POLL(c); goto L_0602F908; } }  // 0602F966 bf/s 0x0602F908 ; mov #30,r1
    c.r[14] += 4;  // 0602F96A add #4,r14
    c.r[15] = c.r[14];  // 0602F96C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602F96E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602F970 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0602F972 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0602F974 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0602F976 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0602F978 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0602F97A mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602F984u);  // 0602F97C mov.w 0x0602F984,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602F97E rts ; mov.l @r15+,r8
}

void f_0602F99C(SH2Context& c) {
    ran[681] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602F99C mov.l r14,@-r15
    c.r[4] = c.r[4] & 0xFFu;  // 0602F99E extu.b r4,r4
    c.r[6] = c.r[5] & 0xFFu;  // 0602F9A0 extu.b r5,r6
    c.r[1] = 0x1Eu;  // 0602F9A2 mov #30,r1
    c.macl = c.r[4] * c.r[1];  // 0602F9A4 mul.l r1,r4
    c.r[7] = ld32(0x0602FA40u);  // 0602F9A6 mov.l 0x0602FA40,r7
    c.r[2] = ld32(c.r[7]);  // 0602F9A8 mov.l @r7,r2
    c.r[3] = c.macl;  // 0602F9AA sts macl,r3
    c.r[3] += c.r[2];  // 0602F9AC add r2,r3
    c.r[3] += 2;  // 0602F9AE add #2,r3
    c.r[1] = c.r[6];  // 0602F9B0 mov r6,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0602F9B2 mov.b @r3,r0
    c.r[1] <<= 2;  // 0602F9B4 shll2 r1
    c.r[1] <<= 2;  // 0602F9B6 shll2 r1
    c.r[1] <<= 2;  // 0602F9B8 shll2 r1
    c.r[0] &= 0x3Fu;  // 0602F9BA and #63,r0
    c.r[0] |= c.r[1];  // 0602F9BC or r1,r0
    st8(c.r[3], c.r[0]);  // 0602F9BE mov.b r0,@r3
    c.r[1] = ld32(c.r[7]);  // 0602F9C0 mov.l @r7,r1
    c.r[2] = c.macl;  // 0602F9C2 sts macl,r2
    c.r[2] += c.r[1];  // 0602F9C4 add r1,r2
    c.r[2] += 15;  // 0602F9C6 add #15,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602F9C8 mov.b @r2,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0602F9CA extu.b r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602FA3Cu);  // 0602F9CC mov.w 0x0602FA3C,r1
    c.t = c.r[2] == c.r[1];  // 0602F9CE cmp/eq r1,r2
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0602FA36; } }  // 0602F9D0 bt/s 0x0602FA36 ; mov r15,r14
    c.r[5] = ld32(0x0602FA44u);  // 0602F9D4 mov.l 0x0602FA44,r5
    c.r[7] = c.r[2];  // 0602F9D6 mov r2,r7
    c.r[7] += c.r[7];  // 0602F9D8 add r7,r7
    c.r[7] += c.r[2];  // 0602F9DA add r2,r7
    c.r[7] <<= 2;  // 0602F9DC shll2 r7
    c.r[2] = c.r[7];  // 0602F9DE mov r7,r2
    c.r[1] = ld32(c.r[5]);  // 0602F9E0 mov.l @r5,r1
    c.r[0] = c.r[7];  // 0602F9E2 mov r7,r0
    c.r[2] += c.r[1];  // 0602F9E4 add r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0602F9E6 mov.w @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0602F9E8 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0602F9EA tst r1,r1
    { const bool k = c.t; c.r[15] = c.r[14]; if (k) { goto L_0602FA38; } }  // 0602F9EC bt/s 0x0602FA38 ; mov r14,r15
    c.r[1] = c.r[2];  // 0602F9F0 mov r2,r1
    c.r[1] += 3;  // 0602F9F2 add #3,r1
    c.r[2] = 0x3u;  // 0602F9F4 mov #3,r2
    c.r[2] &= c.r[6];  // 0602F9F6 and r6,r2
    c.r[2] <<= 2;  // 0602F9F8 shll2 r2
    c.r[2] <<= 2;  // 0602F9FA shll2 r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602F9FC mov.b @r1,r0
    c.r[3] = 0x0u;  // 0602F9FE mov #0,r3
    c.r[4] = c.r[5];  // 0602FA00 mov r5,r4
    c.r[5] = c.r[7];  // 0602FA02 mov r7,r5
    c.r[6] = c.r[2];  // 0602FA04 mov r2,r6
    c.r[7] = 0x0u;  // 0602FA06 mov #0,r7
    c.r[0] &= 0xCFu;  // 0602FA08 and #207,r0
    c.r[0] |= c.r[2];  // 0602FA0A or r2,r0
    st8(c.r[1], c.r[0]);  // 0602FA0C mov.b r0,@r1
L_0602FA0E:
    c.r[2] = ld32(c.r[4]);  // 0602FA0E mov.l @r4,r2
    c.r[1] = c.r[5];  // 0602FA10 mov r5,r1
    c.r[1] += c.r[2];  // 0602FA12 add r2,r1
    c.r[1] += 8;  // 0602FA14 add #8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602FA16 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602FA18 extu.b r1,r1
    c.t = c.r[1] == c.r[3];  // 0602FA1A cmp/eq r3,r1
    { const bool k = !c.t; c.r[1] = c.r[7]; if (k) { goto L_0602FA2C; } }  // 0602FA1C bf/s 0x0602FA2C ; mov r7,r1
    c.r[1] += c.r[2];  // 0602FA20 add r2,r1
    c.r[1] += 3;  // 0602FA22 add #3,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602FA24 mov.b @r1,r0
    c.r[0] &= 0xCFu;  // 0602FA26 and #207,r0
    c.r[0] |= c.r[6];  // 0602FA28 or r6,r0
    st8(c.r[1], c.r[0]);  // 0602FA2A mov.b r0,@r1
L_0602FA2C:
    c.r[3] += 1;  // 0602FA2C add #1,r3
    c.r[1] = 0x7Fu;  // 0602FA2E mov #127,r1
    c.t = (int32_t)c.r[3] > (int32_t)c.r[1];  // 0602FA30 cmp/gt r1,r3
    { const bool k = !c.t; c.r[7] += 12; if (k) { SH2_POLL(c); goto L_0602FA0E; } }  // 0602FA32 bf/s 0x0602FA0E ; add #12,r7
L_0602FA36:
    c.r[15] = c.r[14];  // 0602FA36 mov r14,r15
L_0602FA38:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602FA38 rts ; mov.l @r15+,r14
}

void f_0602FA48(SH2Context& c) {
    ran[682] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602FA48 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602FA4A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0602FA4C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0602FA4E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0602FA50 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0602FA52 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602FA54 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602FA56 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0602FA58 mov r15,r14
    c.r[12] = c.r[4];  // 0602FA5A mov r4,r12
    c.r[13] = c.r[5];  // 0602FA5C mov r5,r13
    c.r[2] = 0x0u;  // 0602FA5E mov #0,r2
    c.r[7] = 0x3u;  // 0602FA60 mov #3,r7
    c.r[3] = 0x0u;  // 0602FA62 mov #0,r3
L_0602FA64:
    c.r[1] = c.r[12];  // 0602FA64 mov r12,r1
    c.r[1] += c.r[2];  // 0602FA66 add r2,r1
    c.r[1] += 39;  // 0602FA68 add #39,r1
    c.r[2] += 1;  // 0602FA6A add #1,r2
    c.t = c.r[2] > c.r[7];  // 0602FA6C cmp/hi r7,r2
    { const bool k = !c.t; st8(c.r[1], c.r[3]); if (k) { SH2_POLL(c); goto L_0602FA64; } }  // 0602FA6E bf/s 0x0602FA64 ; mov.b r3,@r1
    c.r[10] = 0x0u;  // 0602FA72 mov #0,r10
    c.r[9] = c.r[13];  // 0602FA74 mov r13,r9
L_0602FA76:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0602FA76 mov.b @r9,r11
    c.r[1] = c.r[11] & 0xFFu;  // 0602FA78 extu.b r11,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0602FA7A tst r1,r1
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_0602FABC; } }  // 0602FA7C bt/s 0x0602FABC ; mov r9,r1
    c.r[1] += 1;  // 0602FA80 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602FA82 mov.b @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602FAE6u);  // 0602FA84 mov.w 0x0602FAE6,r0
    c.r[8] = c.r[1] & 0xFFu;  // 0602FA86 extu.b r1,r8
    c.r[2] = c.r[8];  // 0602FA88 mov r8,r2
    c.r[1] = ld32(0x0602FAE8u);  // 0602FA8A mov.l 0x0602FAE8,r1
    c.r[1] = ld32(c.r[1]);  // 0602FA8C mov.l @r1,r1
    c.r[2] >>= 2;  // 0602FA8E shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 0602FA90 shlr r2
    c.r[2] += c.r[1];  // 0602FA92 add r1,r2
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0602FA94 mov.b @(r0,r2),r4
    c.r[6] = ld32(0x0602FAECu);  // 0602FA96 mov.l 0x0602FAEC,r6
    c.r[4] = c.r[4] & 0xFFu;  // 0602FA98 extu.b r4,r4
    c.r[0] = ~c.r[8];  // 0602FA9A not r8,r0
    c.r[0] &= 0x7u;  // 0602FA9C and #7,r0
    { const uint32_t x = c.r[6]; c.pr = 0x0602FAA2u; c.r[5] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602FAA2u) return; }  // 0602FA9E jsr @r6 ; mov r0,r5
    c.r[0] &= 0x1u;  // 0602FAA2 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0602FAA4 tst r0,r0
    { const bool k = !c.t; c.t = (c.r[8] & c.r[8]) == 0; if (k) { goto L_0602FAAC; } }  // 0602FAA6 bf/s 0x0602FAAC ; tst r8,r8
    if (!c.t) { goto L_0602FABC; }  // 0602FAAA bf 0x0602FABC
L_0602FAAC:
    c.r[1] = c.r[12];  // 0602FAAC mov r12,r1
    c.r[1] += c.r[10];  // 0602FAAE add r10,r1
    c.r[1] += 39;  // 0602FAB0 add #39,r1
    st8(c.r[1], c.r[11]);  // 0602FAB2 mov.b r11,@r1
    c.r[10] += 1;  // 0602FAB4 add #1,r10
    c.r[1] = 0x3u;  // 0602FAB6 mov #3,r1
    c.t = c.r[10] > c.r[1];  // 0602FAB8 cmp/hi r1,r10
    if (c.t) { goto L_0602FACE; }  // 0602FABA bt 0x0602FACE
L_0602FABC:
    c.r[9] += 2;  // 0602FABC add #2,r9
    c.r[1] = c.r[9];  // 0602FABE mov r9,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0602FAC0 mov.b @r9,r2
    c.r[1] += 1;  // 0602FAC2 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602FAC4 mov.b @r1,r1
    c.r[2] |= c.r[1];  // 0602FAC6 or r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0602FAC8 extu.b r2,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0602FACA tst r2,r2
    if (!c.t) { SH2_POLL(c); goto L_0602FA76; }  // 0602FACC bf 0x0602FA76
L_0602FACE:
    c.r[15] = c.r[14];  // 0602FACE mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602FAD0 lds.l @r15+,pr
    c.r[13] += 8;  // 0602FAD2 add #8,r13
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602FAD4 mov.l @r15+,r14
    c.r[0] = c.r[13];  // 0602FAD6 mov r13,r0
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0602FAD8 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0602FADA mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0602FADC mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0602FADE mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0602FAE0 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602FAE2 rts ; mov.l @r15+,r8
}

void f_0602FAF0(SH2Context& c) {
    ran[683] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602FAF0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602FAF2 sts.l pr,@-r15
    c.r[1] = c.r[4];  // 0602FAF4 mov r4,r1
    c.r[1] += 3;  // 0602FAF6 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602FAF8 mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0602FAFA extu.b r1,r2
    c.r[2] >>= 2;  // 0602FAFC shlr2 r2
    c.r[2] >>= 2;  // 0602FAFE shlr2 r2
    c.r[1] = 0x8u;  // 0602FB00 mov #8,r1
    c.r[2] -= 1;  // 0602FB02 add #-1,r2
    c.t = c.r[2] > c.r[1];  // 0602FB04 cmp/hi r1,r2
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0602FB88; } }  // 0602FB06 bt/s 0x0602FB88 ; mov r15,r14
    c.r[1] = c.r[2];  // 0602FB0A mov r2,r1
    c.r[1] += c.r[1];  // 0602FB0C add r1,r1
    c.r[0] = 0x0602FB18u;  // 0602FB0E mova 0x0602FB18,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0602FB10 mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 0602FB12 add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x0602FB2Au: goto L_0602FB2A; case 0x0602FB38u: goto L_0602FB38; case 0x0602FB46u: goto L_0602FB46; case 0x0602FB54u: goto L_0602FB54; case 0x0602FB62u: goto L_0602FB62; case 0x0602FB68u: goto L_0602FB68; case 0x0602FB70u: goto L_0602FB70; case 0x0602FB78u: goto L_0602FB78; case 0x0602FB80u: goto L_0602FB80; default: sh2_call(c, x); return; } }  // 0602FB14 jmp @r0 ; nop
L_0602FB2A:
    c.r[1] = c.r[4];  // 0602FB2A mov r4,r1
    c.r[1] += 37;  // 0602FB2C add #37,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602FB2E mov.b @r1,r0
    c.r[0] &= 0xF1u;  // 0602FB30 and #241,r0
    c.r[0] |= 0x8u;  // 0602FB32 or #8,r0
    st8(c.r[1], c.r[0]); goto L_0602FB88;  // 0602FB34 bra 0x0602FB88 ; mov.b r0,@r1
L_0602FB38:
    c.r[1] = ld32(c.r[4] + 36);  // 0602FB38 mov.l @(36,r4),r1
    c.r[2] = ld32(0x0602FB98u);  // 0602FB3A mov.l 0x0602FB98,r2
    c.r[1] &= c.r[2];  // 0602FB3C and r2,r1
    c.r[2] = ld32(0x0602FB9Cu);  // 0602FB3E mov.l 0x0602FB9C,r2
    c.r[2] |= c.r[1];  // 0602FB40 or r1,r2
    st32(c.r[4] + 36, c.r[2]); goto L_0602FB88;  // 0602FB42 bra 0x0602FB88 ; mov.l r2,@(36,r4)
L_0602FB46:
    c.r[1] = c.r[4];  // 0602FB46 mov r4,r1
    c.r[1] += 38;  // 0602FB48 add #38,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602FB4A mov.b @r1,r0
    c.r[0] &= 0xC7u;  // 0602FB4C and #199,r0
    c.r[0] |= 0x20u;  // 0602FB4E or #32,r0
    st8(c.r[1], c.r[0]); goto L_0602FB88;  // 0602FB50 bra 0x0602FB88 ; mov.b r0,@r1
L_0602FB54:
    c.r[1] = c.r[4];  // 0602FB54 mov r4,r1
    c.r[1] += 38;  // 0602FB56 add #38,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602FB58 mov.b @r1,r0
    c.r[0] &= 0xF8u;  // 0602FB5A and #248,r0
    c.r[0] |= 0x4u;  // 0602FB5C or #4,r0
    st8(c.r[1], c.r[0]); goto L_0602FB88;  // 0602FB5E bra 0x0602FB88 ; mov.b r0,@r1
L_0602FB62:
    c.r[1] = ld32(0x0602FBA0u);  // 0602FB62 mov.l 0x0602FBA0,r1
    c.r[5] = 0x1u; goto L_0602FB84;  // 0602FB64 bra 0x0602FB84 ; mov #1,r5
L_0602FB68:
    c.r[5] = (uint32_t)(int16_t)ld16(0x0602FB90u);  // 0602FB68 mov.w 0x0602FB90,r5
    c.r[1] = ld32(0x0602FBA4u);  // 0602FB6A mov.l 0x0602FBA4,r1
    goto L_0602FB84;  // 0602FB6C bra 0x0602FB84 ; nop
L_0602FB70:
    c.r[5] = (uint32_t)(int16_t)ld16(0x0602FB92u);  // 0602FB70 mov.w 0x0602FB92,r5
    c.r[1] = ld32(0x0602FBA8u);  // 0602FB72 mov.l 0x0602FBA8,r1
    goto L_0602FB84;  // 0602FB74 bra 0x0602FB84 ; nop
L_0602FB78:
    c.r[5] = (uint32_t)(int16_t)ld16(0x0602FB94u);  // 0602FB78 mov.w 0x0602FB94,r5
    c.r[1] = ld32(0x0602FBACu);  // 0602FB7A mov.l 0x0602FBAC,r1
    goto L_0602FB84;  // 0602FB7C bra 0x0602FB84 ; nop
L_0602FB80:
    c.r[1] = ld32(0x0602FBB0u);  // 0602FB80 mov.l 0x0602FBB0,r1
    c.r[5] = 0x14u;  // 0602FB82 mov #20,r5
L_0602FB84:
    { const uint32_t x = c.r[1]; c.pr = 0x0602FB88u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602FB88u) return; }  // 0602FB84 jsr @r1 ; nop
L_0602FB88:
    c.r[15] = c.r[14];  // 0602FB88 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602FB8A lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602FB8C rts ; mov.l @r15+,r14
}

}  // namespace p_srwfin_installed
