#include "p_srwfin_installed_funcs.h"

namespace p_srwfin_installed {

void f_060151C8(SH2Context& c) {
    ran[106] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060151C8 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 060151CA mov r15,r14
    c.r[7] = ld32(0x060151F0u);  // 060151CC mov.l 0x060151F0,r7
    c.r[6] = c.r[7];  // 060151CE mov r7,r6
    c.r[6] += 56;  // 060151D0 add #56,r6
    c.r[3] = ld32(c.r[7]);  // 060151D2 mov.l @r7,r3
    c.r[1] = c.r[3];  // 060151D4 mov r3,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 060151D6 mov.b @r1+,r2
    c.r[3] += 2;  // 060151D8 add #2,r3
    c.r[2] = c.r[2] & 0xFFu;  // 060151DA extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060151DC mov.b @r1,r1
    c.r[2] <<= 8;  // 060151DE shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 060151E0 extu.b r1,r1
    c.r[2] |= c.r[1];  // 060151E2 or r1,r2
    st16(c.r[6], c.r[2]);  // 060151E4 mov.w r2,@r6
    st32(c.r[7], c.r[3]);  // 060151E6 mov.l r3,@r7
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060151E8 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = 0x0u; c.pc = x; return; }  // 060151EA rts ; mov #0,r0
}

void f_060151F4(SH2Context& c) {
    ran[107] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060151F4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060151F6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060151F8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060151FA mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060151FC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060151FE sts.l pr,@-r15
    c.r[1] = ld32(0x060152E8u);  // 06015200 mov.l 0x060152E8,r1
    c.r[1] = ld32(c.r[1]);  // 06015202 mov.l @r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06015204 mov.b @r1,r1
    c.r[9] = c.r[1] & 0xFFu;  // 06015206 extu.b r1,r9
    c.t = (c.r[9] & c.r[9]) == 0;  // 06015208 tst r9,r9
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_06015226; } }  // 0601520A bf/s 0x06015226 ; mov r15,r14
    c.r[3] = ld32(0x060152ECu);  // 0601520E mov.l 0x060152EC,r3
    c.r[2] = ld32(c.r[3]);  // 06015210 mov.l @r3,r2
    c.r[1] = ld32(0x060152F0u);  // 06015212 mov.l 0x060152F0,r1
    c.r[2] += 1;  // 06015214 add #1,r2
    c.t = c.r[2] >= c.r[1];  // 06015216 cmp/hs r1,r2
    { const bool k = !c.t; st32(c.r[3], c.r[2]); if (k) { goto L_06015220; } }  // 06015218 bf/s 0x06015220 ; mov.l r2,@r3
    c.r[1] = ld32(0x060152F4u);  // 0601521C mov.l 0x060152F4,r1
    st32(c.r[3], c.r[1]);  // 0601521E mov.l r1,@r3
L_06015220:
    c.r[1] = ld32(c.r[3]);  // 06015220 mov.l @r3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06015222 mov.b @r1,r1
    c.r[9] = c.r[1] & 0xFFu;  // 06015224 extu.b r1,r9
L_06015226:
    c.r[1] = ld32(0x060152E8u);  // 06015226 mov.l 0x060152E8,r1
    c.r[2] = ld32(c.r[1]);  // 06015228 mov.l @r1,r2
    c.r[1] = c.r[2];  // 0601522A mov r2,r1
    c.r[1] += 1;  // 0601522C add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601522E mov.b @r1,r1
    c.r[2] += 2;  // 06015230 add #2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06015232 extu.b r1,r1
    c.r[10] = c.r[1];  // 06015234 mov r1,r10
    c.r[10] <<= 8;  // 06015236 shll8 r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06015238 mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601523A extu.b r1,r1
    c.r[10] |= c.r[1];  // 0601523C or r1,r10
    c.r[1] = ld32(0x060152F8u);  // 0601523E mov.l 0x060152F8,r1
    c.t = c.r[10] == c.r[1];  // 06015240 cmp/eq r1,r10
    { const bool k = !c.t; c.t = (c.r[9] & c.r[9]) == 0; if (k) { goto L_06015278; } }  // 06015242 bf/s 0x06015278 ; tst r9,r9
    c.r[7] = ld32(0x060152ECu);  // 06015246 mov.l 0x060152EC,r7
    c.r[1] = ld32(c.r[7]);  // 06015248 mov.l @r7,r1
    c.r[6] = ld32(0x060152F0u);  // 0601524A mov.l 0x060152F0,r6
    c.r[1] += 1;  // 0601524C add #1,r1
    c.t = c.r[1] >= c.r[6];  // 0601524E cmp/hs r6,r1
    { const bool k = !c.t; st32(c.r[7], c.r[1]); if (k) { goto L_06015258; } }  // 06015250 bf/s 0x06015258 ; mov.l r1,@r7
    c.r[1] = ld32(0x060152F4u);  // 06015254 mov.l 0x060152F4,r1
    st32(c.r[7], c.r[1]);  // 06015256 mov.l r1,@r7
L_06015258:
    c.r[2] = ld32(c.r[7]);  // 06015258 mov.l @r7,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]); c.r[2] += 1;  // 0601525A mov.b @r2+,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601525C extu.b r1,r1
    c.r[3] = c.r[1];  // 0601525E mov r1,r3
    c.r[3] <<= 8;  // 06015260 shll8 r3
    c.t = c.r[2] >= c.r[6];  // 06015262 cmp/hs r6,r2
    { const bool k = !c.t; st32(c.r[7], c.r[2]); if (k) { goto L_0601526C; } }  // 06015264 bf/s 0x0601526C ; mov.l r2,@r7
    c.r[1] = ld32(0x060152F4u);  // 06015268 mov.l 0x060152F4,r1
    st32(c.r[7], c.r[1]);  // 0601526A mov.l r1,@r7
L_0601526C:
    c.r[1] = ld32(c.r[7]);  // 0601526C mov.l @r7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601526E mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06015270 extu.b r1,r1
    c.r[10] = c.r[1];  // 06015272 mov r1,r10
    c.r[10] |= c.r[3];  // 06015274 or r3,r10
    c.t = (c.r[9] & c.r[9]) == 0;  // 06015276 tst r9,r9
L_06015278:
    if (c.t) { goto L_060152CC; }  // 06015278 bt 0x060152CC
    c.r[8] = ld32(0x060152E8u);  // 0601527A mov.l 0x060152E8,r8
    c.r[11] = c.r[8];  // 0601527C mov r8,r11
    c.r[11] += 56;  // 0601527E add #56,r11
    c.r[1] = c.r[8];  // 06015280 mov r8,r1
L_06015282:
    c.r[1] += 32;  // 06015282 add #32,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06015284 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06015286 mov r1,r0
    c.r[0] >>= 2;  // 06015288 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0601528A shlr r0
    c.r[0] &= 0x1u;  // 0601528C and #1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x060152E6u);  // 0601528E mov.w 0x060152E6,r1
    c.macl = (c.r[0] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 06015290 mulu.w r1,r0
    c.r[2] = 0x50u;  // 06015292 mov #80,r2
    c.r[1] = c.r[8];  // 06015294 mov r8,r1
    c.r[1] += 59;  // 06015296 add #59,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06015298 mov.b @r1,r1
    c.r[3] = c.macl;  // 0601529A sts macl,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0601529C extu.b r1,r1
    c.macl = c.r[1] * c.r[2];  // 0601529E mul.l r2,r1
    c.r[4] = 0x1u;  // 060152A0 mov #1,r4
    c.r[3] += c.r[8];  // 060152A2 add r8,r3
    c.r[7] = c.macl;  // 060152A4 sts macl,r7
    c.r[7] += c.r[3];  // 060152A6 add r3,r7
    c.r[7] += 76;  // 060152A8 add #76,r7
    c.r[1] = c.r[8];  // 060152AA mov r8,r1
    c.r[1] += 58;  // 060152AC add #58,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060152AE mov.b @r1,r1
    c.r[3] += 74;  // 060152B0 add #74,r3
    c.r[0] = c.r[1] & 0xFFu;  // 060152B2 extu.b r1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 060152B4 mov.w @r3,r1
    c.r[2] = c.r[10];  // 060152B6 mov r10,r2
    c.r[2] += c.r[1];  // 060152B8 add r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[11]);  // 060152BA mov.w @r11,r1
    c.r[0] += c.r[0];  // 060152BC add r0,r0
    c.r[2] += c.r[1];  // 060152BE add r1,r2
    c.r[1] = ld32(0x060152FCu);  // 060152C0 mov.l 0x060152FC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060152C6u; st16(c.r[0] + c.r[7], c.r[2]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060152C6u) return; }  // 060152C2 jsr @r1 ; mov.w r2,@(r0,r7)
    c.r[9] -= 1; c.t = c.r[9] == 0;  // 060152C6 dt r9
    { const bool k = !c.t; c.r[1] = c.r[8]; if (k) { SH2_POLL(c); goto L_06015282; } }  // 060152C8 bf/s 0x06015282 ; mov r8,r1
L_060152CC:
    c.r[1] = ld32(0x060152E8u);  // 060152CC mov.l 0x060152E8,r1
    c.r[2] = ld32(c.r[1]);  // 060152CE mov.l @r1,r2
    c.r[15] = c.r[14];  // 060152D0 mov r14,r15
    c.r[2] += 3;  // 060152D2 add #3,r2
    st32(c.r[1], c.r[2]);  // 060152D4 mov.l r2,@r1
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060152D6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060152D8 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060152DA mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060152DC mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060152DE mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060152E0 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.r[0] = 0x0u; c.pc = x; return; }  // 060152E2 rts ; mov #0,r0
}

void f_06015300(SH2Context& c) {
    ran[108] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06015300 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06015302 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06015304 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06015306 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06015308 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601530A sts.l pr,@-r15
    c.r[1] = ld32(0x060153FCu);  // 0601530C mov.l 0x060153FC,r1
    c.r[1] = ld32(c.r[1]);  // 0601530E mov.l @r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06015310 mov.b @r1,r1
    c.r[9] = c.r[1] & 0xFFu;  // 06015312 extu.b r1,r9
    c.t = (c.r[9] & c.r[9]) == 0;  // 06015314 tst r9,r9
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_06015332; } }  // 06015316 bf/s 0x06015332 ; mov r15,r14
    c.r[3] = ld32(0x06015400u);  // 0601531A mov.l 0x06015400,r3
    c.r[2] = ld32(c.r[3]);  // 0601531C mov.l @r3,r2
    c.r[1] = ld32(0x06015404u);  // 0601531E mov.l 0x06015404,r1
    c.r[2] += 1;  // 06015320 add #1,r2
    c.t = c.r[2] >= c.r[1];  // 06015322 cmp/hs r1,r2
    { const bool k = !c.t; st32(c.r[3], c.r[2]); if (k) { goto L_0601532C; } }  // 06015324 bf/s 0x0601532C ; mov.l r2,@r3
    c.r[1] = ld32(0x06015408u);  // 06015328 mov.l 0x06015408,r1
    st32(c.r[3], c.r[1]);  // 0601532A mov.l r1,@r3
L_0601532C:
    c.r[1] = ld32(c.r[3]);  // 0601532C mov.l @r3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601532E mov.b @r1,r1
    c.r[9] = c.r[1] & 0xFFu;  // 06015330 extu.b r1,r9
L_06015332:
    c.r[1] = ld32(0x060153FCu);  // 06015332 mov.l 0x060153FC,r1
    c.r[2] = ld32(c.r[1]);  // 06015334 mov.l @r1,r2
    c.r[1] = c.r[2];  // 06015336 mov r2,r1
    c.r[1] += 1;  // 06015338 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601533A mov.b @r1,r1
    c.r[2] += 2;  // 0601533C add #2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0601533E extu.b r1,r1
    c.r[10] = c.r[1];  // 06015340 mov r1,r10
    c.r[10] <<= 8;  // 06015342 shll8 r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06015344 mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06015346 extu.b r1,r1
    c.r[10] |= c.r[1];  // 06015348 or r1,r10
    c.r[1] = ld32(0x0601540Cu);  // 0601534A mov.l 0x0601540C,r1
    c.t = c.r[10] == c.r[1];  // 0601534C cmp/eq r1,r10
    { const bool k = !c.t; c.t = (c.r[9] & c.r[9]) == 0; if (k) { goto L_06015384; } }  // 0601534E bf/s 0x06015384 ; tst r9,r9
    c.r[7] = ld32(0x06015400u);  // 06015352 mov.l 0x06015400,r7
    c.r[1] = ld32(c.r[7]);  // 06015354 mov.l @r7,r1
    c.r[6] = ld32(0x06015404u);  // 06015356 mov.l 0x06015404,r6
    c.r[1] += 1;  // 06015358 add #1,r1
    c.t = c.r[1] >= c.r[6];  // 0601535A cmp/hs r6,r1
    { const bool k = !c.t; st32(c.r[7], c.r[1]); if (k) { goto L_06015364; } }  // 0601535C bf/s 0x06015364 ; mov.l r1,@r7
    c.r[1] = ld32(0x06015408u);  // 06015360 mov.l 0x06015408,r1
    st32(c.r[7], c.r[1]);  // 06015362 mov.l r1,@r7
L_06015364:
    c.r[2] = ld32(c.r[7]);  // 06015364 mov.l @r7,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]); c.r[2] += 1;  // 06015366 mov.b @r2+,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06015368 extu.b r1,r1
    c.r[3] = c.r[1];  // 0601536A mov r1,r3
    c.r[3] <<= 8;  // 0601536C shll8 r3
    c.t = c.r[2] >= c.r[6];  // 0601536E cmp/hs r6,r2
    { const bool k = !c.t; st32(c.r[7], c.r[2]); if (k) { goto L_06015378; } }  // 06015370 bf/s 0x06015378 ; mov.l r2,@r7
    c.r[1] = ld32(0x06015408u);  // 06015374 mov.l 0x06015408,r1
    st32(c.r[7], c.r[1]);  // 06015376 mov.l r1,@r7
L_06015378:
    c.r[1] = ld32(c.r[7]);  // 06015378 mov.l @r7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601537A mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601537C extu.b r1,r1
    c.r[10] = c.r[1];  // 0601537E mov r1,r10
    c.r[10] |= c.r[3];  // 06015380 or r3,r10
    c.t = (c.r[9] & c.r[9]) == 0;  // 06015382 tst r9,r9
L_06015384:
    if (c.t) { goto L_060153DE; }  // 06015384 bt 0x060153DE
    c.r[8] = ld32(0x060153FCu);  // 06015386 mov.l 0x060153FC,r8
    c.r[11] = c.r[8];  // 06015388 mov r8,r11
    c.r[11] += 56;  // 0601538A add #56,r11
    c.r[1] = c.r[8];  // 0601538C mov r8,r1
L_0601538E:
    c.r[1] += 32;  // 0601538E add #32,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06015390 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06015392 mov r1,r0
    c.r[0] >>= 2;  // 06015394 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06015396 shlr r0
    c.r[0] &= 0x1u;  // 06015398 and #1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x060153F8u);  // 0601539A mov.w 0x060153F8,r1
    c.macl = (c.r[0] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 0601539C mulu.w r1,r0
    c.r[2] = 0x50u;  // 0601539E mov #80,r2
    c.r[1] = c.r[8];  // 060153A0 mov r8,r1
    c.r[1] += 59;  // 060153A2 add #59,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060153A4 mov.b @r1,r1
    c.r[3] = c.macl;  // 060153A6 sts macl,r3
    c.r[1] = c.r[1] & 0xFFu;  // 060153A8 extu.b r1,r1
    c.macl = c.r[1] * c.r[2];  // 060153AA mul.l r2,r1
    c.r[4] = 0x1u;  // 060153AC mov #1,r4
    c.r[3] += c.r[8];  // 060153AE add r8,r3
    c.r[7] = c.macl;  // 060153B0 sts macl,r7
    c.r[7] += c.r[3];  // 060153B2 add r3,r7
    c.r[7] += 76;  // 060153B4 add #76,r7
    c.r[1] = c.r[8];  // 060153B6 mov r8,r1
    c.r[1] += 58;  // 060153B8 add #58,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060153BA mov.b @r1,r1
    c.r[3] += 74;  // 060153BC add #74,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 060153BE mov.w @r3,r2
    c.r[0] = c.r[1] & 0xFFu;  // 060153C0 extu.b r1,r0
    c.r[0] += c.r[0];  // 060153C2 add r0,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[11]);  // 060153C4 mov.w @r11,r1
    c.r[3] = c.r[10];  // 060153C6 mov r10,r3
    c.r[2] += c.r[1];  // 060153C8 add r1,r2
    c.r[1] = c.r[3];  // 060153CA mov r3,r1
    c.r[1] += 1;  // 060153CC add #1,r1
    c.r[10] = c.r[1] & 0xFFFFu;  // 060153CE extu.w r1,r10
    c.r[3] += c.r[2];  // 060153D0 add r2,r3
    c.r[1] = ld32(0x06015410u);  // 060153D2 mov.l 0x06015410,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060153D8u; st16(c.r[0] + c.r[7], c.r[3]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060153D8u) return; }  // 060153D4 jsr @r1 ; mov.w r3,@(r0,r7)
    c.r[9] -= 1; c.t = c.r[9] == 0;  // 060153D8 dt r9
    { const bool k = !c.t; c.r[1] = c.r[8]; if (k) { SH2_POLL(c); goto L_0601538E; } }  // 060153DA bf/s 0x0601538E ; mov r8,r1
L_060153DE:
    c.r[1] = ld32(0x060153FCu);  // 060153DE mov.l 0x060153FC,r1
    c.r[2] = ld32(c.r[1]);  // 060153E0 mov.l @r1,r2
    c.r[15] = c.r[14];  // 060153E2 mov r14,r15
    c.r[2] += 3;  // 060153E4 add #3,r2
    st32(c.r[1], c.r[2]);  // 060153E6 mov.l r2,@r1
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060153E8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060153EA mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060153EC mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060153EE mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060153F0 mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060153F2 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.r[0] = 0x0u; c.pc = x; return; }  // 060153F4 rts ; mov #0,r0
}

void f_06015414(SH2Context& c) {
    ran[109] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06015414 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06015416 mov r15,r14
    c.r[7] = ld32(0x06015448u);  // 06015418 mov.l 0x06015448,r7
    c.r[1] = 0xFu;  // 0601541A mov #15,r1
    c.r[2] = c.r[7];  // 0601541C mov r7,r2
    c.r[3] = ld32(c.r[7]);  // 0601541E mov.l @r7,r3
    c.r[2] += 60;  // 06015420 add #60,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06015422 mov.b @r3,r0
    c.r[1] &= c.r[0];  // 06015424 and r0,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06015426 mov.b @r2,r0
    c.r[1] <<= 2;  // 06015428 shll2 r1
    c.r[1] <<= 2;  // 0601542A shll2 r1
    c.r[0] &= 0xFu;  // 0601542C and #15,r0
    c.r[0] |= c.r[1];  // 0601542E or r1,r0
    st8(c.r[2], c.r[0]);  // 06015430 mov.b r0,@r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]); c.r[3] += 1;  // 06015432 mov.b @r3+,r1
    c.r[0] &= 0xF0u;  // 06015434 and #240,r0
    c.r[1] = c.r[1] & 0xFFu;  // 06015436 extu.b r1,r1
    c.r[1] >>= 2;  // 06015438 shlr2 r1
    c.r[1] >>= 2;  // 0601543A shlr2 r1
    c.r[0] |= c.r[1];  // 0601543C or r1,r0
    st8(c.r[2], c.r[0]);  // 0601543E mov.b r0,@r2
    st32(c.r[7], c.r[3]);  // 06015440 mov.l r3,@r7
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06015442 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = 0x0u; c.pc = x; return; }  // 06015444 rts ; mov #0,r0
}

void f_0601544C(SH2Context& c) {
    ran[110] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601544C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0601544E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06015450 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06015452 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06015454 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06015456 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06015458 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601545A sts.l pr,@-r15
    c.r[1] = ld32(0x06015560u);  // 0601545C mov.l 0x06015560,r1
    c.r[1] = ld32(c.r[1]);  // 0601545E mov.l @r1,r1
    c.r[15] -= 4;  // 06015460 add #-4,r15
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06015462 mov.b @r1,r1
    c.r[9] = c.r[1] & 0xFFu;  // 06015464 extu.b r1,r9
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601555Eu);  // 06015466 mov.w 0x0601555E,r1
    c.t = c.r[9] == c.r[1];  // 06015468 cmp/eq r1,r9
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_06015486; } }  // 0601546A bf/s 0x06015486 ; mov r15,r14
    c.r[3] = ld32(0x06015564u);  // 0601546E mov.l 0x06015564,r3
    c.r[2] = ld32(c.r[3]);  // 06015470 mov.l @r3,r2
    c.r[1] = ld32(0x06015568u);  // 06015472 mov.l 0x06015568,r1
    c.r[2] += 1;  // 06015474 add #1,r2
    c.t = c.r[2] >= c.r[1];  // 06015476 cmp/hs r1,r2
    { const bool k = !c.t; st32(c.r[3], c.r[2]); if (k) { goto L_06015480; } }  // 06015478 bf/s 0x06015480 ; mov.l r2,@r3
    c.r[1] = ld32(0x0601556Cu);  // 0601547C mov.l 0x0601556C,r1
    st32(c.r[3], c.r[1]);  // 0601547E mov.l r1,@r3
L_06015480:
    c.r[1] = ld32(c.r[3]);  // 06015480 mov.l @r3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06015482 mov.b @r1,r1
    c.r[9] = c.r[1] & 0xFFu;  // 06015484 extu.b r1,r9
L_06015486:
    c.r[1] = ld32(0x06015560u);  // 06015486 mov.l 0x06015560,r1
    c.r[1] = ld32(c.r[1]);  // 06015488 mov.l @r1,r1
    c.r[1] += 1;  // 0601548A add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601548C mov.b @r1,r1
    c.r[11] = c.r[1] & 0xFFu;  // 0601548E extu.b r1,r11
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601555Eu);  // 06015490 mov.w 0x0601555E,r1
    c.t = c.r[11] == c.r[1];  // 06015492 cmp/eq r1,r11
    { const bool k = !c.t; c.r[1] = 0x28u; if (k) { goto L_060154B2; } }  // 06015494 bf/s 0x060154B2 ; mov #40,r1
    c.r[3] = ld32(0x06015564u);  // 06015498 mov.l 0x06015564,r3
    c.r[2] = ld32(c.r[3]);  // 0601549A mov.l @r3,r2
    c.r[1] = ld32(0x06015568u);  // 0601549C mov.l 0x06015568,r1
    c.r[2] += 1;  // 0601549E add #1,r2
    c.t = c.r[2] >= c.r[1];  // 060154A0 cmp/hs r1,r2
    { const bool k = !c.t; st32(c.r[3], c.r[2]); if (k) { goto L_060154AA; } }  // 060154A2 bf/s 0x060154AA ; mov.l r2,@r3
    c.r[1] = ld32(0x0601556Cu);  // 060154A6 mov.l 0x0601556C,r1
    st32(c.r[3], c.r[1]);  // 060154A8 mov.l r1,@r3
L_060154AA:
    c.r[1] = ld32(c.r[3]);  // 060154AA mov.l @r3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060154AC mov.b @r1,r1
    c.r[11] = c.r[1] & 0xFFu;  // 060154AE extu.b r1,r11
    c.r[1] = 0x28u;  // 060154B0 mov #40,r1
L_060154B2:
    c.t = c.r[11] > c.r[1];  // 060154B2 cmp/hi r1,r11
    if (!c.t) { goto L_060154B8; }  // 060154B4 bf 0x060154B8
    c.r[11] = c.r[1];  // 060154B6 mov r1,r11
L_060154B8:
    c.r[1] = ld32(0x06015560u);  // 060154B8 mov.l 0x06015560,r1
    c.r[1] = ld32(c.r[1]);  // 060154BA mov.l @r1,r1
    c.r[1] += 2;  // 060154BC add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060154BE mov.b @r1,r1
    c.r[13] = c.r[1] & 0xFFu;  // 060154C0 extu.b r1,r13
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601555Eu);  // 060154C2 mov.w 0x0601555E,r1
    c.t = c.r[13] == c.r[1];  // 060154C4 cmp/eq r1,r13
    { const bool k = !c.t; c.r[12] = 0x1Cu; if (k) { goto L_060154E4; } }  // 060154C6 bf/s 0x060154E4 ; mov #28,r12
    c.r[3] = ld32(0x06015564u);  // 060154CA mov.l 0x06015564,r3
    c.r[2] = ld32(c.r[3]);  // 060154CC mov.l @r3,r2
    c.r[1] = ld32(0x06015568u);  // 060154CE mov.l 0x06015568,r1
    c.r[2] += 1;  // 060154D0 add #1,r2
    c.t = c.r[2] >= c.r[1];  // 060154D2 cmp/hs r1,r2
    { const bool k = !c.t; st32(c.r[3], c.r[2]); if (k) { goto L_060154DC; } }  // 060154D4 bf/s 0x060154DC ; mov.l r2,@r3
    c.r[1] = ld32(0x0601556Cu);  // 060154D8 mov.l 0x0601556C,r1
    st32(c.r[3], c.r[1]);  // 060154DA mov.l r1,@r3
L_060154DC:
    c.r[1] = ld32(c.r[3]);  // 060154DC mov.l @r3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060154DE mov.b @r1,r1
    c.r[13] = c.r[1] & 0xFFu;  // 060154E0 extu.b r1,r13
    c.r[12] = 0x1Cu;  // 060154E2 mov #28,r12
L_060154E4:
    c.t = c.r[13] > c.r[12];  // 060154E4 cmp/hi r12,r13
    if (!c.t) { goto L_060154EA; }  // 060154E6 bf 0x060154EA
    c.r[13] = 0x1Cu;  // 060154E8 mov #28,r13
L_060154EA:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601555Eu);  // 060154EA mov.w 0x0601555E,r1
    c.t = c.r[9] == c.r[1];  // 060154EC cmp/eq r1,r9
    if (!c.t) { goto L_060155DC; }  // 060154EE bf 0x060155DC
    c.r[3] = ld32(0x06015564u);  // 060154F0 mov.l 0x06015564,r3
    c.r[1] = ld32(c.r[3]);  // 060154F2 mov.l @r3,r1
    c.r[5] = ld32(0x06015568u);  // 060154F4 mov.l 0x06015568,r5
    c.r[1] += 1;  // 060154F6 add #1,r1
    c.t = c.r[1] >= c.r[5];  // 060154F8 cmp/hs r5,r1
    { const bool k = !c.t; st32(c.r[3], c.r[1]); if (k) { goto L_06015502; } }  // 060154FA bf/s 0x06015502 ; mov.l r1,@r3
    c.r[1] = ld32(0x0601556Cu);  // 060154FE mov.l 0x0601556C,r1
    st32(c.r[3], c.r[1]);  // 06015500 mov.l r1,@r3
L_06015502:
    c.r[7] = ld32(c.r[3]);  // 06015502 mov.l @r3,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06015504 mov.b @r7,r1
    c.r[2] = c.r[11];  // 06015506 mov r11,r2
    c.r[10] = c.r[1] & 0xFFu;  // 06015508 extu.b r1,r10
    c.r[2] += c.r[10];  // 0601550A add r10,r2
    c.r[1] = 0x28u;  // 0601550C mov #40,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0601550E cmp/gt r1,r2
    { const bool k = !c.t; c.r[1] = 0u - c.r[11]; if (k) { goto L_06015518; } }  // 06015510 bf/s 0x06015518 ; neg r11,r1
    c.r[1] += 40;  // 06015514 add #40,r1
    c.r[10] = c.r[1] & 0xFFu;  // 06015516 extu.b r1,r10
L_06015518:
    c.r[1] = c.r[7];  // 06015518 mov r7,r1
    c.r[1] += 1;  // 0601551A add #1,r1
    c.t = c.r[1] >= c.r[5];  // 0601551C cmp/hs r5,r1
    { const bool k = !c.t; st32(c.r[3], c.r[1]); if (k) { goto L_06015526; } }  // 0601551E bf/s 0x06015526 ; mov.l r1,@r3
    c.r[1] = ld32(0x0601556Cu);  // 06015522 mov.l 0x0601556C,r1
    st32(c.r[3], c.r[1]);  // 06015524 mov.l r1,@r3
L_06015526:
    c.r[1] = ld32(c.r[3]);  // 06015526 mov.l @r3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06015528 mov.b @r1,r1
    c.r[12] = 0x1Cu;  // 0601552A mov #28,r12
    c.r[1] = c.r[1] & 0xFFu;  // 0601552C extu.b r1,r1
    st32(c.r[14], c.r[1]);  // 0601552E mov.l r1,@r14
    c.r[1] += c.r[13];  // 06015530 add r13,r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[12];  // 06015532 cmp/gt r12,r1
    { const bool k = !c.t; c.r[1] = 0u - c.r[13]; if (k) { goto L_0601553E; } }  // 06015534 bf/s 0x0601553E ; neg r13,r1
    c.r[1] += 28;  // 06015538 add #28,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601553A extu.b r1,r1
    st32(c.r[14], c.r[1]);  // 0601553C mov.l r1,@r14
L_0601553E:
    c.r[1] = ld32(c.r[14]);  // 0601553E mov.l @r14,r1
    c.r[8] = c.r[13];  // 06015540 mov r13,r8
    c.r[1] += c.r[8];  // 06015542 add r8,r1
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 06015544 cmp/ge r1,r8
    { const bool k = !c.t; c.r[6] = c.r[3]; if (k) { goto L_0601554E; } }  // 06015546 bf/s 0x0601554E ; mov r3,r6
    goto L_060156CE;  // 0601554A bra 0x060156CE ; nop
L_0601554E:
    c.r[1] = 0x50u;  // 0601554E mov #80,r1
    c.macl = c.r[8] * c.r[1];  // 06015550 mul.l r1,r8
    c.r[9] = ld32(0x0601556Cu);  // 06015552 mov.l 0x0601556C,r9
    c.r[4] = ld32(0x06015560u);  // 06015554 mov.l 0x06015560,r4
    c.r[5] = c.macl;  // 06015556 sts macl,r5
L_06015558:
    c.r[7] = c.r[11];  // 06015558 mov r11,r7
    c.r[1] = c.r[7]; goto L_060155C6;  // 0601555A bra 0x060155C6 ; mov r7,r1
L_06015570:
    c.r[1] = ld32(c.r[6]);  // 06015570 mov.l @r6,r1
    c.r[12] = ld32(0x060156F0u);  // 06015572 mov.l 0x060156F0,r12
    c.r[1] += 1;  // 06015574 add #1,r1
    c.t = c.r[1] >= c.r[12];  // 06015576 cmp/hs r12,r1
    { const bool k = !c.t; st32(c.r[6], c.r[1]); if (k) { goto L_0601557E; } }  // 06015578 bf/s 0x0601557E ; mov.l r1,@r6
    st32(c.r[6], c.r[9]);  // 0601557C mov.l r9,@r6
L_0601557E:
    c.r[2] = ld32(c.r[6]);  // 0601557E mov.l @r6,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]); c.r[2] += 1;  // 06015580 mov.b @r2+,r1
    c.r[12] = ld32(0x060156F0u);  // 06015582 mov.l 0x060156F0,r12
    c.r[1] = c.r[1] & 0xFFu;  // 06015584 extu.b r1,r1
    c.r[3] = c.r[1];  // 06015586 mov r1,r3
    c.r[3] <<= 8;  // 06015588 shll8 r3
    c.t = c.r[2] >= c.r[12];  // 0601558A cmp/hs r12,r2
    { const bool k = !c.t; st32(c.r[6], c.r[2]); if (k) { goto L_06015592; } }  // 0601558C bf/s 0x06015592 ; mov.l r2,@r6
    st32(c.r[6], c.r[9]);  // 06015590 mov.l r9,@r6
L_06015592:
    c.r[1] = ld32(c.r[6]);  // 06015592 mov.l @r6,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06015594 mov.b @r1,r1
    c.r[2] = c.r[7];  // 06015596 mov r7,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06015598 extu.b r1,r1
    c.r[3] |= c.r[1];  // 0601559A or r1,r3
    c.r[1] = c.r[4];  // 0601559C mov r4,r1
    c.r[1] += 32;  // 0601559E add #32,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060155A0 mov.b @r1,r1
    c.r[7] += 1;  // 060155A2 add #1,r7
    c.r[0] = c.r[1];  // 060155A4 mov r1,r0
    c.r[0] >>= 2;  // 060155A6 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060155A8 shlr r0
    c.r[0] &= 0x1u;  // 060155AA and #1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x060156EEu);  // 060155AC mov.w 0x060156EE,r1
    c.macl = (c.r[0] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 060155AE mulu.w r1,r0
    c.r[2] += c.r[2];  // 060155B0 add r2,r2
    c.r[1] = c.macl;  // 060155B2 sts macl,r1
    c.r[1] += c.r[4];  // 060155B4 add r4,r1
    c.r[0] = c.r[5];  // 060155B6 mov r5,r0
    c.r[0] += c.r[1];  // 060155B8 add r1,r0
    c.r[1] += 74;  // 060155BA add #74,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060155BC mov.w @r1,r1
    c.r[0] += 76;  // 060155BE add #76,r0
    c.r[3] += c.r[1];  // 060155C0 add r1,r3
    st16(c.r[0] + c.r[2], c.r[3]);  // 060155C2 mov.w r3,@(r0,r2)
    c.r[1] = c.r[11];  // 060155C4 mov r11,r1
L_060155C6:
    c.r[1] += c.r[10];  // 060155C6 add r10,r1
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[1];  // 060155C8 cmp/ge r1,r7
    { const bool k = !c.t; c.r[1] = ld32(c.r[14]); if (k) { SH2_POLL(c); goto L_06015570; } }  // 060155CA bf/s 0x06015570 ; mov.l @r14,r1
    c.r[8] += 1;  // 060155CE add #1,r8
    c.r[1] += c.r[13];  // 060155D0 add r13,r1
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 060155D2 cmp/ge r1,r8
    { const bool k = !c.t; c.r[5] += 80; if (k) { SH2_POLL(c); goto L_06015558; } }  // 060155D4 bf/s 0x06015558 ; add #80,r5
    goto L_060156CE;  // 060155D8 bra 0x060156CE ; nop
L_060155DC:
    c.r[9] = c.r[9] & 0xFFFFu;  // 060155DC extu.w r9,r9
    c.r[4] = ld32(0x060156F4u);  // 060155DE mov.l 0x060156F4,r4
    c.r[8] = ld32(0x060156F8u);  // 060155E0 mov.l 0x060156F8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060155E6u; c.r[5] = 0x19u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060155E6u) return; }  // 060155E2 jsr @r8 ; mov #25,r5
    c.r[5] = c.r[9];  // 060155E6 mov r9,r5
    { const uint32_t x = c.r[8]; c.pr = 0x060155ECu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060155ECu) return; }  // 060155E8 jsr @r8 ; mov r0,r4
    c.r[6] = c.r[0];  // 060155EC mov r0,r6
    c.r[6] += 4;  // 060155EE add #4,r6
    c.r[0] = ld32(0x060156FCu);  // 060155F0 mov.l 0x060156FC,r0
    c.r[5] = ld32(0x06015700u);  // 060155F2 mov.l 0x06015700,r5
    { const uint32_t x = c.r[0]; c.pr = 0x060155F8u; c.r[4] = c.r[6]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060155F8u) return; }  // 060155F4 jsr @r0 ; mov r6,r4
    c.r[6] = ld32(0x06015700u);  // 060155F8 mov.l 0x06015700,r6
    c.r[6] += 4;  // 060155FA add #4,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 060155FC mov.b @r6,r1
    c.r[3] = c.r[1];  // 060155FE mov r1,r3
    c.r[3] <<= 16;  // 06015600 shll16 r3
    c.r[3] <<= 8;  // 06015602 shll8 r3
    c.r[1] = ld32(0x06015700u);  // 06015604 mov.l 0x06015700,r1
    c.r[1] += 5;  // 06015606 add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06015608 mov.b @r1,r1
    c.r[2] = c.r[11];  // 0601560A mov r11,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0601560C extu.b r1,r1
    c.r[1] <<= 16;  // 0601560E shll16 r1
    c.r[3] |= c.r[1];  // 06015610 or r1,r3
    c.r[1] = ld32(0x06015700u);  // 06015612 mov.l 0x06015700,r1
    c.r[1] += 6;  // 06015614 add #6,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06015616 mov.b @r1,r1
    c.r[6] = ld32(0x06015700u);  // 06015618 mov.l 0x06015700,r6
    c.r[1] = c.r[1] & 0xFFu;  // 0601561A extu.b r1,r1
    c.r[1] <<= 8;  // 0601561C shll8 r1
    c.r[3] |= c.r[1];  // 0601561E or r1,r3
    c.r[1] = ld32(0x06015700u);  // 06015620 mov.l 0x06015700,r1
    c.r[1] += 7;  // 06015622 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06015624 mov.b @r1,r1
    c.r[6] += 10;  // 06015626 add #10,r6
    c.r[1] = c.r[1] & 0xFFu;  // 06015628 extu.b r1,r1
    c.r[3] |= c.r[1];  // 0601562A or r1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0601562C mov.b @r6,r1
    c.r[10] = c.r[1] & 0xFFu;  // 0601562E extu.b r1,r10
    c.r[2] += c.r[10];  // 06015630 add r10,r2
    c.r[1] = 0x28u;  // 06015632 mov #40,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 06015634 cmp/gt r1,r2
    { const bool k = !c.t; c.r[3] -= 4; if (k) { goto L_06015640; } }  // 06015636 bf/s 0x06015640 ; add #-4,r3
    c.r[1] = 0u - c.r[11];  // 0601563A neg r11,r1
    c.r[1] += 40;  // 0601563C add #40,r1
    c.r[10] = c.r[1] & 0xFFu;  // 0601563E extu.b r1,r10
L_06015640:
    c.r[6] = ld32(0x06015700u);  // 06015640 mov.l 0x06015700,r6
    c.r[6] += 11;  // 06015642 add #11,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 06015644 mov.b @r6,r1
    c.r[12] = 0x1Cu;  // 06015646 mov #28,r12
    c.r[1] = c.r[1] & 0xFFu;  // 06015648 extu.b r1,r1
    st32(c.r[14], c.r[1]);  // 0601564A mov.l r1,@r14
    c.r[1] += c.r[13];  // 0601564C add r13,r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[12];  // 0601564E cmp/gt r12,r1
    { const bool k = !c.t; c.r[1] = 0u - c.r[13]; if (k) { goto L_0601565A; } }  // 06015650 bf/s 0x0601565A ; neg r13,r1
    c.r[1] += 28;  // 06015654 add #28,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06015656 extu.b r1,r1
    st32(c.r[14], c.r[1]);  // 06015658 mov.l r1,@r14
L_0601565A:
    c.r[6] = ld32(0x06015700u);  // 0601565A mov.l 0x06015700,r6
    c.r[1] = ld32(c.r[14]);  // 0601565C mov.l @r14,r1
    c.r[8] = c.r[13];  // 0601565E mov r13,r8
    c.r[1] += c.r[8];  // 06015660 add r8,r1
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 06015662 cmp/ge r1,r8
    { const bool k = c.t; c.r[6] += c.r[3]; if (k) { goto L_060156CE; } }  // 06015664 bt/s 0x060156CE ; add r3,r6
    c.r[1] = 0x50u;  // 06015668 mov #80,r1
    c.macl = c.r[8] * c.r[1];  // 0601566A mul.l r1,r8
    c.r[9] = c.macl;  // 0601566C sts macl,r9
L_0601566E:
    c.r[7] = c.r[11];  // 0601566E mov r11,r7
    c.r[1] = c.r[7];  // 06015670 mov r7,r1
    c.r[1] += c.r[10];  // 06015672 add r10,r1
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[1];  // 06015674 cmp/ge r1,r7
    { const bool k = c.t; c.r[1] = ld32(c.r[14]); if (k) { goto L_060156C4; } }  // 06015676 bt/s 0x060156C4 ; mov.l @r14,r1
    c.r[5] = c.r[6];  // 0601567A mov r6,r5
    c.r[5] += 1;  // 0601567C add #1,r5
L_0601567E:
    c.r[1] = ld32(0x06015704u);  // 0601567E mov.l 0x06015704,r1
    c.r[1] += 32;  // 06015680 add #32,r1
    c.r[12] = ld32(0x06015704u);  // 06015682 mov.l 0x06015704,r12
    c.r[4] = c.r[7];  // 06015684 mov r7,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06015686 mov.b @r1,r1
    c.r[7] += 1;  // 06015688 add #1,r7
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0601568A mov.b @r6,r2
    c.r[0] = c.r[1];  // 0601568C mov r1,r0
    c.r[0] >>= 2;  // 0601568E shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06015690 shlr r0
    c.r[0] &= 0x1u;  // 06015692 and #1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x060156EEu);  // 06015694 mov.w 0x060156EE,r1
    c.r[4] += c.r[4];  // 06015696 add r4,r4
    c.r[2] = c.r[2] & 0xFFu;  // 06015698 extu.b r2,r2
    c.r[2] <<= 8;  // 0601569A shll8 r2
    c.macl = (c.r[0] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 0601569C mulu.w r1,r0
    c.r[6] += 2;  // 0601569E add #2,r6
    c.r[3] = c.macl;  // 060156A0 sts macl,r3
    c.r[3] += c.r[12];  // 060156A2 add r12,r3
    c.r[0] = c.r[9];  // 060156A4 mov r9,r0
    c.r[0] += c.r[3];  // 060156A6 add r3,r0
    c.r[0] += 76;  // 060156A8 add #76,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[5]);  // 060156AA mov.b @r5,r1
    c.r[3] += 74;  // 060156AC add #74,r3
    c.r[1] = c.r[1] & 0xFFu;  // 060156AE extu.b r1,r1
    c.r[2] |= c.r[1];  // 060156B0 or r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 060156B2 mov.w @r3,r1
    c.r[5] += 2;  // 060156B4 add #2,r5
    c.r[2] += c.r[1];  // 060156B6 add r1,r2
    c.r[1] = c.r[11];  // 060156B8 mov r11,r1
    c.r[1] += c.r[10];  // 060156BA add r10,r1
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[1];  // 060156BC cmp/ge r1,r7
    { const bool k = !c.t; st16(c.r[0] + c.r[4], c.r[2]); if (k) { SH2_POLL(c); goto L_0601567E; } }  // 060156BE bf/s 0x0601567E ; mov.w r2,@(r0,r4)
    c.r[1] = ld32(c.r[14]);  // 060156C2 mov.l @r14,r1
L_060156C4:
    c.r[8] += 1;  // 060156C4 add #1,r8
    c.r[1] += c.r[13];  // 060156C6 add r13,r1
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 060156C8 cmp/ge r1,r8
    { const bool k = !c.t; c.r[9] += 80; if (k) { SH2_POLL(c); goto L_0601566E; } }  // 060156CA bf/s 0x0601566E ; add #80,r9
L_060156CE:
    c.r[1] = ld32(0x06015704u);  // 060156CE mov.l 0x06015704,r1
    c.r[14] += 4;  // 060156D0 add #4,r14
    c.r[2] = ld32(c.r[1]);  // 060156D2 mov.l @r1,r2
    c.r[15] = c.r[14];  // 060156D4 mov r14,r15
    c.r[2] += 3;  // 060156D6 add #3,r2
    st32(c.r[1], c.r[2]);  // 060156D8 mov.l r2,@r1
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060156DA lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060156DC mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060156DE mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060156E0 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060156E2 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060156E4 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060156E6 mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060156E8 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.r[0] = 0x0u; c.pc = x; return; }  // 060156EA rts ; mov #0,r0
}

void f_06015708(SH2Context& c) {
    ran[111] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06015708 mov.l r14,@-r15
    c.r[2] = ld32(0x06015770u);  // 0601570A mov.l 0x06015770,r2
    c.r[3] = c.r[2];  // 0601570C mov r2,r3
    c.r[3] += 58;  // 0601570E add #58,r3
    c.r[1] = c.r[2];  // 06015710 mov r2,r1
    c.r[1] += 63;  // 06015712 add #63,r1
    c.r[7] = c.r[2];  // 06015714 mov r2,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06015716 mov.b @r1,r1
    c.r[7] += 59;  // 06015718 add #59,r7
    st8(c.r[3], c.r[1]);  // 0601571A mov.b r1,@r3
    c.r[3] = c.r[2];  // 0601571C mov r2,r3
    c.r[1] = c.r[2];  // 0601571E mov r2,r1
    c.r[1] += 61;  // 06015720 add #61,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06015722 mov.b @r1,r1
    c.r[3] += 62;  // 06015724 add #62,r3
    st8(c.r[3], c.r[1]);  // 06015726 mov.b r1,@r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06015728 mov.b @r7,r1
    c.r[2] += 32;  // 0601572A add #32,r2
    c.r[1] += 1;  // 0601572C add #1,r1
    st8(c.r[7], c.r[1]);  // 0601572E mov.b r1,@r7
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06015730 mov.b @r2,r6
    c.r[3] = c.r[6] & 0xFFu;  // 06015732 extu.b r6,r3
    c.r[0] = c.r[3];  // 06015734 mov r3,r0
    c.r[0] >>= 2;  // 06015736 shlr2 r0
    c.r[0] >>= 2;  // 06015738 shlr2 r0
    c.r[0] &= 0x1u;  // 0601573A and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601573C tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06015756; } }  // 0601573E bt/s 0x06015756 ; mov r15,r14
    c.r[1] += 1;  // 06015742 add #1,r1
    c.r[0] = c.r[3];  // 06015744 mov r3,r0
    c.r[0] >>= 2;  // 06015746 shlr2 r0
    c.r[0] &= 0x1u;  // 06015748 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601574A tst r0,r0
    { const bool k = c.t; st8(c.r[7], c.r[1]); if (k) { goto L_06015756; } }  // 0601574C bt/s 0x06015756 ; mov.b r1,@r7
    c.r[0] = c.r[6];  // 06015750 mov r6,r0
    c.r[0] &= 0xFBu;  // 06015752 and #251,r0
    st8(c.r[2], c.r[0]);  // 06015754 mov.b r0,@r2
L_06015756:
    c.r[3] = ld32(0x06015774u);  // 06015756 mov.l 0x06015774,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06015758 mov.b @r3,r1
    c.r[2] = 0x1Bu;  // 0601575A mov #27,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0601575C extu.b r1,r1
    c.t = c.r[1] > c.r[2];  // 0601575E cmp/hi r2,r1
    { const bool k = !c.t; c.r[1] = 0x1Bu; if (k) { goto L_06015766; } }  // 06015760 bf/s 0x06015766 ; mov #27,r1
    st8(c.r[3], c.r[1]);  // 06015764 mov.b r1,@r3
L_06015766:
    c.r[15] = c.r[14];  // 06015766 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06015768 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = 0x0u; c.pc = x; return; }  // 0601576A rts ; mov #0,r0
}

void f_06015778(SH2Context& c) {
    ran[112] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06015778 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0601577A mov r15,r14
    c.r[3] = ld32(0x060157E4u);  // 0601577C mov.l 0x060157E4,r3
    c.r[2] = ld32(c.r[3]);  // 0601577E mov.l @r3,r2
    c.r[5] = 0x10u;  // 06015780 mov #16,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]); c.r[2] += 1;  // 06015782 mov.b @r2+,r1
    c.r[6] = c.r[3];  // 06015784 mov r3,r6
    c.r[1] = c.r[1] & 0xFFu;  // 06015786 extu.b r1,r1
    c.r[7] = c.r[1];  // 06015788 mov r1,r7
    c.r[7] <<= 8;  // 0601578A shll8 r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601578C mov.b @r2,r1
    c.r[6] += 61;  // 0601578E add #61,r6
    c.r[1] = c.r[1] & 0xFFu;  // 06015790 extu.b r1,r1
    c.r[7] |= c.r[1];  // 06015792 or r1,r7
    c.r[2] = c.r[7];  // 06015794 mov r7,r2
    c.r[2] >>= 2;  // 06015796 shlr2 r2
    c.r[1] = c.r[3];  // 06015798 mov r3,r1
    c.r[1] += 32;  // 0601579A add #32,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601579C mov.b @r1,r0
    c.r[2] &= c.r[5];  // 0601579E and r5,r2
    c.r[0] &= 0xEFu;  // 060157A0 and #239,r0
    c.r[0] |= c.r[2];  // 060157A2 or r2,r0
    st8(c.r[1], c.r[0]);  // 060157A4 mov.b r0,@r1
    c.r[0] = c.r[7];  // 060157A6 mov r7,r0
    c.r[0] &= 0x3Fu;  // 060157A8 and #63,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060157AA tst r0,r0
    { const bool k = c.t; st8(c.r[6], c.r[0]); if (k) { goto L_060157C6; } }  // 060157AC bt/s 0x060157C6 ; mov.b r0,@r6
    c.r[1] = c.r[3];  // 060157B0 mov r3,r1
    c.r[1] += 58;  // 060157B2 add #58,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060157B4 mov.b @r1,r2
    c.r[1] = c.r[2] & 0xFFu;  // 060157B6 extu.b r2,r1
    c.r[1] = 0u - c.r[1];  // 060157B8 neg r1,r1
    c.r[1] += 40;  // 060157BA add #40,r1
    c.t = (int32_t)c.r[0] > (int32_t)c.r[1];  // 060157BC cmp/gt r1,r0
    if (!c.t) { goto L_060157C2; }  // 060157BE bf 0x060157C2
    st8(c.r[6], c.r[1]);  // 060157C0 mov.b r1,@r6
L_060157C2:
    c.r[3] += 63;  // 060157C2 add #63,r3
    st8(c.r[3], c.r[2]);  // 060157C4 mov.b r2,@r3
L_060157C6:
    c.r[2] = ld32(0x060157E4u);  // 060157C6 mov.l 0x060157E4,r2
    c.r[3] = c.r[2];  // 060157C8 mov r2,r3
    c.r[1] = c.r[2];  // 060157CA mov r2,r1
    c.r[1] += 61;  // 060157CC add #61,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060157CE mov.b @r1,r1
    c.r[3] += 62;  // 060157D0 add #62,r3
    st8(c.r[3], c.r[1]);  // 060157D2 mov.b r1,@r3
    c.r[1] = ld32(c.r[2]);  // 060157D4 mov.l @r2,r1
    c.r[15] = c.r[14];  // 060157D6 mov r14,r15
    c.r[1] += 2;  // 060157D8 add #2,r1
    st32(c.r[2], c.r[1]);  // 060157DA mov.l r1,@r2
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060157DC mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = 0x0u; c.pc = x; return; }  // 060157DE rts ; mov #0,r0
}

void f_060157E8(SH2Context& c) {
    ran[113] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060157E8 mov.l r14,@-r15
    c.r[1] = ld32(0x060158F4u);  // 060157EA mov.l 0x060158F4,r1
    c.r[1] = ld32(c.r[1]);  // 060157EC mov.l @r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060157EE mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 060157F0 extu.b r1,r2
    c.r[1] = 0x7Fu;  // 060157F2 mov #127,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 060157F4 cmp/gt r1,r2
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_06015836; } }  // 060157F6 bf/s 0x06015836 ; mov r15,r14
    c.r[6] = c.r[2];  // 060157FA mov r2,r6
    c.r[1] = (uint32_t)(int16_t)ld16(0x060158F2u);  // 060157FC mov.w 0x060158F2,r1
    c.t = c.r[2] == c.r[1];  // 060157FE cmp/eq r1,r2
    { const bool k = !c.t; c.r[6] -= 128; if (k) { goto L_0601581C; } }  // 06015800 bf/s 0x0601581C ; add #-128,r6
    c.r[3] = ld32(0x060158F8u);  // 06015804 mov.l 0x060158F8,r3
    c.r[2] = ld32(c.r[3]);  // 06015806 mov.l @r3,r2
    c.r[1] = ld32(0x060158FCu);  // 06015808 mov.l 0x060158FC,r1
    c.r[2] += 1;  // 0601580A add #1,r2
    c.t = c.r[2] >= c.r[1];  // 0601580C cmp/hs r1,r2
    { const bool k = !c.t; st32(c.r[3], c.r[2]); if (k) { goto L_06015816; } }  // 0601580E bf/s 0x06015816 ; mov.l r2,@r3
    c.r[1] = ld32(0x06015900u);  // 06015812 mov.l 0x06015900,r1
    st32(c.r[3], c.r[1]);  // 06015814 mov.l r1,@r3
L_06015816:
    c.r[1] = ld32(c.r[3]);  // 06015816 mov.l @r3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06015818 mov.b @r1,r1
    c.r[6] = c.r[1] & 0xFFu;  // 0601581A extu.b r1,r6
L_0601581C:
    c.r[3] = ld32(0x060158F8u);  // 0601581C mov.l 0x060158F8,r3
    c.r[2] = ld32(c.r[3]);  // 0601581E mov.l @r3,r2
    c.r[1] = ld32(0x060158FCu);  // 06015820 mov.l 0x060158FC,r1
    c.r[2] += 1;  // 06015822 add #1,r2
    c.t = c.r[2] >= c.r[1];  // 06015824 cmp/hs r1,r2
    { const bool k = !c.t; st32(c.r[3], c.r[2]); if (k) { goto L_0601582E; } }  // 06015826 bf/s 0x0601582E ; mov.l r2,@r3
    c.r[1] = ld32(0x06015900u);  // 0601582A mov.l 0x06015900,r1
    st32(c.r[3], c.r[1]);  // 0601582C mov.l r1,@r3
L_0601582E:
    c.r[1] = ld32(c.r[3]);  // 0601582E mov.l @r3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06015830 mov.b @r1,r1
    c.r[7] = c.r[1] & 0xFFu; goto L_06015856;  // 06015832 bra 0x06015856 ; extu.b r1,r7
L_06015836:
    c.t = (c.r[2] & c.r[2]) == 0;  // 06015836 tst r2,r2
    { const bool k = !c.t; c.r[7] = c.r[2]; if (k) { goto L_06015854; } }  // 06015838 bf/s 0x06015854 ; mov r2,r7
    c.r[3] = ld32(0x060158F8u);  // 0601583C mov.l 0x060158F8,r3
    c.r[2] = ld32(c.r[3]);  // 0601583E mov.l @r3,r2
    c.r[1] = ld32(0x060158FCu);  // 06015840 mov.l 0x060158FC,r1
    c.r[2] += 1;  // 06015842 add #1,r2
    c.t = c.r[2] >= c.r[1];  // 06015844 cmp/hs r1,r2
    { const bool k = !c.t; st32(c.r[3], c.r[2]); if (k) { goto L_0601584E; } }  // 06015846 bf/s 0x0601584E ; mov.l r2,@r3
    c.r[1] = ld32(0x06015900u);  // 0601584A mov.l 0x06015900,r1
    st32(c.r[3], c.r[1]);  // 0601584C mov.l r1,@r3
L_0601584E:
    c.r[1] = ld32(c.r[3]);  // 0601584E mov.l @r3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06015850 mov.b @r1,r1
    c.r[7] = c.r[1] & 0xFFu;  // 06015852 extu.b r1,r7
L_06015854:
    c.r[6] = c.r[7];  // 06015854 mov r7,r6
L_06015856:
    c.r[1] = ld32(0x06015904u);  // 06015856 mov.l 0x06015904,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06015858 mov.b @r1,r1
    c.r[3] = ld32(0x06015908u);  // 0601585A mov.l 0x06015908,r3
    c.r[0] = c.r[1];  // 0601585C mov r1,r0
    c.r[0] >>= 2;  // 0601585E shlr2 r0
    c.r[0] >>= 2;  // 06015860 shlr2 r0
    c.r[0] &= 0x1u;  // 06015862 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06015864 tst r0,r0
    { const bool k = c.t; c.r[2] = c.r[6]; if (k) { goto L_0601587E; } }  // 06015866 bt/s 0x0601587E ; mov r6,r2
    c.r[2] -= c.r[7];  // 0601586A sub r7,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0601586C tst r2,r2
    { const bool k = c.t; c.r[1] = 0x0u; if (k) { goto L_0601588E; } }  // 0601586E bt/s 0x0601588E ; mov #0,r1
L_06015872:
    st8(c.r[3], c.r[1]);  // 06015872 mov.b r1,@r3
    c.r[2] -= 1; c.t = c.r[2] == 0;  // 06015874 dt r2
    { const bool k = !c.t; c.r[3] += 1; if (k) { SH2_POLL(c); goto L_06015872; } }  // 06015876 bf/s 0x06015872 ; add #1,r3
    c.r[2] = c.r[7]; goto L_06015890;  // 0601587A bra 0x06015890 ; mov r7,r2
L_0601587E:
    c.r[2] -= c.r[7];  // 0601587E sub r7,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06015880 tst r2,r2
    { const bool k = c.t; c.r[1] = 0x0u; if (k) { goto L_0601588E; } }  // 06015882 bt/s 0x0601588E ; mov #0,r1
L_06015886:
    st8(c.r[3], c.r[1]);  // 06015886 mov.b r1,@r3
    c.r[2] -= 1; c.t = c.r[2] == 0;  // 06015888 dt r2
    { const bool k = !c.t; c.r[3] += 1; if (k) { SH2_POLL(c); goto L_06015886; } }  // 0601588A bf/s 0x06015886 ; add #1,r3
L_0601588E:
    c.r[2] = c.r[7];  // 0601588E mov r7,r2
L_06015890:
    c.t = (c.r[2] & c.r[2]) == 0;  // 06015890 tst r2,r2
    { const bool k = c.t; c.r[1] = 0xFFFFFFFFu; if (k) { goto L_060158B8; } }  // 06015892 bt/s 0x060158B8 ; mov #-1,r1
    c.r[7] = ld32(0x060158F8u);  // 06015896 mov.l 0x060158F8,r7
    c.r[5] = ld32(0x060158FCu);  // 06015898 mov.l 0x060158FC,r5
    c.r[6] = ld32(0x06015900u);  // 0601589A mov.l 0x06015900,r6
L_0601589C:
    c.r[1] = ld32(c.r[7]);  // 0601589C mov.l @r7,r1
    c.r[1] += 1;  // 0601589E add #1,r1
    c.t = c.r[1] >= c.r[5];  // 060158A0 cmp/hs r5,r1
    { const bool k = !c.t; st32(c.r[7], c.r[1]); if (k) { goto L_060158A8; } }  // 060158A2 bf/s 0x060158A8 ; mov.l r1,@r7
    st32(c.r[7], c.r[6]);  // 060158A6 mov.l r6,@r7
L_060158A8:
    c.r[1] = ld32(c.r[7]);  // 060158A8 mov.l @r7,r1
    c.r[2] -= 1;  // 060158AA add #-1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060158AC mov.b @r1,r1
    c.t = (c.r[2] & c.r[2]) == 0;  // 060158AE tst r2,r2
    st8(c.r[3], c.r[1]);  // 060158B0 mov.b r1,@r3
    { const bool k = !c.t; c.r[3] += 1; if (k) { SH2_POLL(c); goto L_0601589C; } }  // 060158B2 bf/s 0x0601589C ; add #1,r3
    c.r[1] = 0xFFFFFFFFu;  // 060158B6 mov #-1,r1
L_060158B8:
    st8(c.r[3], c.r[1]);  // 060158B8 mov.b r1,@r3
    c.r[2] = ld32(0x060158F4u);  // 060158BA mov.l 0x060158F4,r2
    c.r[7] = c.r[2];  // 060158BC mov r2,r7
    c.r[6] = ld32(c.r[2]);  // 060158BE mov.l @r2,r6
    c.r[7] += 32;  // 060158C0 add #32,r7
    c.r[6] += 1;  // 060158C2 add #1,r6
    st32(c.r[2], c.r[6]);  // 060158C4 mov.l r6,@r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[7]);  // 060158C6 mov.b @r7,r0
    c.r[15] = c.r[14];  // 060158C8 mov r14,r15
    c.r[1] = c.r[0] & 0xFFu;  // 060158CA extu.b r0,r1
    c.r[1] >>= 2;  // 060158CC shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060158CE shlr r1
    c.r[1] >>= 2;  // 060158D0 shlr2 r1
    c.r[3] = c.r[1];  // 060158D2 mov r1,r3
    c.r[3] += 1;  // 060158D4 add #1,r3
    c.r[3] <<= 2;  // 060158D6 shll2 r3
    c.r[3] += c.r[3];  // 060158D8 add r3,r3
    c.r[3] <<= 2;  // 060158DA shll2 r3
    c.r[0] &= 0x1Fu;  // 060158DC and #31,r0
    c.r[0] |= c.r[3];  // 060158DE or r3,r0
    st8(c.r[7], c.r[0]);  // 060158E0 mov.b r0,@r7
    c.r[1] <<= 2;  // 060158E2 shll2 r1
    c.r[1] += c.r[2];  // 060158E4 add r2,r1
    st32(c.r[1] + 4, c.r[6]);  // 060158E6 mov.l r6,@(4,r1)
    c.r[1] = ld32(0x06015908u);  // 060158E8 mov.l 0x06015908,r1
    st32(c.r[2], c.r[1]);  // 060158EA mov.l r1,@r2
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060158EC mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = 0x0u; c.pc = x; return; }  // 060158EE rts ; mov #0,r0
}

void f_0601590C(SH2Context& c) {
    ran[114] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601590C mov.l r14,@-r15
    c.r[7] = ld32(0x0601599Cu);  // 0601590E mov.l 0x0601599C,r7
    c.r[6] = c.r[7];  // 06015910 mov r7,r6
    c.r[6] += 32;  // 06015912 add #32,r6
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[6]);  // 06015914 mov.w @r6,r1
    c.r[2] = ld32(c.r[7]);  // 06015916 mov.l @r7,r2
    c.r[0] = c.r[1];  // 06015918 mov r1,r0
    c.r[0] >>= 2;  // 0601591A shlr2 r0
    c.r[0] >>= 2;  // 0601591C shlr2 r0
    c.r[0] >>= 2;  // 0601591E shlr2 r0
    c.r[0] &= 0xFu;  // 06015920 and #15,r0
    c.r[0] += c.r[7];  // 06015922 add r7,r0
    c.r[1] = c.r[2];  // 06015924 mov r2,r1
    c.r[1] += 1;  // 06015926 add #1,r1
    st32(c.r[7], c.r[1]);  // 06015928 mov.l r1,@r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601592A mov.b @r2,r1
    c.r[0] += 34;  // 0601592C add #34,r0
    st8(c.r[0], c.r[1]);  // 0601592E mov.b r1,@r0
    c.r[1] = c.r[1] & 0xFFu;  // 06015930 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06015932 tst r1,r1
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_06015960; } }  // 06015934 bf/s 0x06015960 ; mov r15,r14
    c.r[3] = ld32(0x060159A0u);  // 06015938 mov.l 0x060159A0,r3
    c.r[2] = ld32(c.r[3]);  // 0601593A mov.l @r3,r2
    c.r[1] = ld32(0x060159A4u);  // 0601593C mov.l 0x060159A4,r1
    c.r[2] += 1;  // 0601593E add #1,r2
    c.t = c.r[2] >= c.r[1];  // 06015940 cmp/hs r1,r2
    { const bool k = !c.t; st32(c.r[3], c.r[2]); if (k) { goto L_0601594A; } }  // 06015942 bf/s 0x0601594A ; mov.l r2,@r3
    c.r[1] = ld32(0x060159A8u);  // 06015946 mov.l 0x060159A8,r1
    st32(c.r[3], c.r[1]);  // 06015948 mov.l r1,@r3
L_0601594A:
    c.r[1] = ld32(c.r[3]);  // 0601594A mov.l @r3,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601594C mov.b @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[6]);  // 0601594E mov.w @r6,r1
    c.r[0] = c.r[1];  // 06015950 mov r1,r0
    c.r[0] >>= 2;  // 06015952 shlr2 r0
    c.r[0] >>= 2;  // 06015954 shlr2 r0
    c.r[0] >>= 2;  // 06015956 shlr2 r0
    c.r[0] &= 0xFu;  // 06015958 and #15,r0
    c.r[0] += c.r[7];  // 0601595A add r7,r0
    c.r[0] += 34;  // 0601595C add #34,r0
    st8(c.r[0], c.r[2]);  // 0601595E mov.b r2,@r0
L_06015960:
    c.r[3] = ld32(0x0601599Cu);  // 06015960 mov.l 0x0601599C,r3
    c.r[7] = c.r[3];  // 06015962 mov r3,r7
    c.r[7] += 32;  // 06015964 add #32,r7
    c.r[5] = 0xFu;  // 06015966 mov #15,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x06015998u);  // 06015968 mov.w 0x06015998,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[7]);  // 0601596A mov.w @r7,r2
    c.r[15] = c.r[14];  // 0601596C mov r14,r15
    c.r[0] = c.r[2];  // 0601596E mov r2,r0
    c.r[0] >>= 2;  // 06015970 shlr2 r0
    c.r[0] >>= 2;  // 06015972 shlr2 r0
    c.r[0] >>= 2;  // 06015974 shlr2 r0
    c.r[0] &= 0xFu;  // 06015976 and #15,r0
    c.r[6] = c.r[0];  // 06015978 mov r0,r6
    c.r[6] += 1;  // 0601597A add #1,r6
    c.r[6] &= c.r[5];  // 0601597C and r5,r6
    c.r[6] <<= 2;  // 0601597E shll2 r6
    c.r[6] <<= 2;  // 06015980 shll2 r6
    c.r[6] <<= 2;  // 06015982 shll2 r6
    c.r[2] &= c.r[1];  // 06015984 and r1,r2
    c.r[2] |= c.r[6];  // 06015986 or r6,r2
    st16(c.r[7], c.r[2]);  // 06015988 mov.w r2,@r7
    c.r[0] <<= 2;  // 0601598A shll2 r0
    c.r[1] = ld32(c.r[3]);  // 0601598C mov.l @r3,r1
    c.r[0] += c.r[3];  // 0601598E add r3,r0
    st32(c.r[0] + 40, c.r[1]);  // 06015990 mov.l r1,@(40,r0)
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06015992 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = 0x0u; c.pc = x; return; }  // 06015994 rts ; mov #0,r0
}

void f_060159AC(SH2Context& c) {
    ran[115] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060159AC mov.l r14,@-r15
    c.r[7] = ld32(0x06015A20u);  // 060159AE mov.l 0x06015A20,r7
    c.r[3] = c.r[7];  // 060159B0 mov r7,r3
    c.r[3] += 32;  // 060159B2 add #32,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 060159B4 mov.w @r3,r1
    c.r[6] = (uint32_t)(int16_t)ld16(0x06015A1Eu);  // 060159B6 mov.w 0x06015A1E,r6
    c.r[0] = c.r[1];  // 060159B8 mov r1,r0
    c.r[0] >>= 2;  // 060159BA shlr2 r0
    c.r[0] >>= 2;  // 060159BC shlr2 r0
    c.r[0] >>= 2;  // 060159BE shlr2 r0
    c.r[0] &= 0xFu;  // 060159C0 and #15,r0
    c.r[0] -= 1;  // 060159C2 add #-1,r0
    c.r[0] &= 0xFu;  // 060159C4 and #15,r0
    c.r[0] <<= 2;  // 060159C6 shll2 r0
    c.r[0] <<= 2;  // 060159C8 shll2 r0
    c.r[0] <<= 2;  // 060159CA shll2 r0
    c.r[1] &= c.r[6];  // 060159CC and r6,r1
    c.r[1] |= c.r[0];  // 060159CE or r0,r1
    st16(c.r[3], c.r[1]);  // 060159D0 mov.w r1,@r3
    c.r[0] = c.r[1];  // 060159D2 mov r1,r0
    c.r[0] >>= 2;  // 060159D4 shlr2 r0
    c.r[0] >>= 2;  // 060159D6 shlr2 r0
    c.r[0] >>= 2;  // 060159D8 shlr2 r0
    c.r[0] &= 0xFu;  // 060159DA and #15,r0
    c.r[0] += c.r[7];  // 060159DC add r7,r0
    c.r[0] += 34;  // 060159DE add #34,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 060159E0 mov.b @r0,r1
    c.r[1] -= 1;  // 060159E2 add #-1,r1
    st8(c.r[0], c.r[1]);  // 060159E4 mov.b r1,@r0
    c.r[1] = c.r[1] & 0xFFu;  // 060159E6 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060159E8 tst r1,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06015A16; } }  // 060159EA bt/s 0x06015A16 ; mov r15,r14
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 060159EE mov.w @r3,r1
    c.r[5] = 0xFu;  // 060159F0 mov #15,r5
    c.r[0] = c.r[1];  // 060159F2 mov r1,r0
    c.r[0] >>= 2;  // 060159F4 shlr2 r0
    c.r[0] >>= 2;  // 060159F6 shlr2 r0
    c.r[0] >>= 2;  // 060159F8 shlr2 r0
    c.r[0] &= 0xFu;  // 060159FA and #15,r0
    c.r[2] = c.r[0];  // 060159FC mov r0,r2
    c.r[2] += 1;  // 060159FE add #1,r2
    c.r[2] &= c.r[5];  // 06015A00 and r5,r2
    c.r[2] <<= 2;  // 06015A02 shll2 r2
    c.r[2] <<= 2;  // 06015A04 shll2 r2
    c.r[2] <<= 2;  // 06015A06 shll2 r2
    c.r[1] &= c.r[6];  // 06015A08 and r6,r1
    c.r[1] |= c.r[2];  // 06015A0A or r2,r1
    st16(c.r[3], c.r[1]);  // 06015A0C mov.w r1,@r3
    c.r[0] <<= 2;  // 06015A0E shll2 r0
    c.r[0] += c.r[7];  // 06015A10 add r7,r0
    c.r[1] = ld32(c.r[0] + 40);  // 06015A12 mov.l @(40,r0),r1
    st32(c.r[7], c.r[1]);  // 06015A14 mov.l r1,@r7
L_06015A16:
    c.r[15] = c.r[14];  // 06015A16 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06015A18 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = 0x0u; c.pc = x; return; }  // 06015A1A rts ; mov #0,r0
}

void f_06015A24(SH2Context& c) {
    ran[116] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06015A24 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06015A26 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06015A28 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06015A2A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06015A2C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06015A2E sts.l pr,@-r15
    c.r[1] = ld32(0x06015B5Cu);  // 06015A30 mov.l 0x06015B5C,r1
    c.r[1] = ld32(c.r[1]);  // 06015A32 mov.l @r1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 06015A34 mov.b @r1+,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06015A36 mov.b @r1,r1
    c.r[6] = c.r[2] & 0xFFu;  // 06015A38 extu.b r2,r6
    c.r[9] = c.r[1] & 0xFFu;  // 06015A3A extu.b r1,r9
    c.r[1] = (uint32_t)(int16_t)ld16(0x06015B56u);  // 06015A3C mov.w 0x06015B56,r1
    c.t = c.r[6] == c.r[1];  // 06015A3E cmp/eq r1,r6
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_06015A5E; } }  // 06015A40 bf/s 0x06015A5E ; mov r15,r14
    c.r[3] = ld32(0x06015B60u);  // 06015A44 mov.l 0x06015B60,r3
    c.r[2] = ld32(c.r[3]);  // 06015A46 mov.l @r3,r2
    c.r[1] = ld32(0x06015B64u);  // 06015A48 mov.l 0x06015B64,r1
    c.r[2] += 1;  // 06015A4A add #1,r2
    c.t = c.r[2] >= c.r[1];  // 06015A4C cmp/hs r1,r2
    { const bool k = !c.t; st32(c.r[3], c.r[2]); if (k) { goto L_06015A56; } }  // 06015A4E bf/s 0x06015A56 ; mov.l r2,@r3
    c.r[1] = ld32(0x06015B68u);  // 06015A52 mov.l 0x06015B68,r1
    st32(c.r[3], c.r[1]);  // 06015A54 mov.l r1,@r3
L_06015A56:
    c.r[1] = ld32(c.r[3]);  // 06015A56 mov.l @r3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06015A58 mov.b @r1,r1
    c.r[6] = c.r[1] & 0xFFu;  // 06015A5A extu.b r1,r6
    c.r[1] = (uint32_t)(int16_t)ld16(0x06015B56u);  // 06015A5C mov.w 0x06015B56,r1
L_06015A5E:
    c.t = c.r[9] == c.r[1];  // 06015A5E cmp/eq r1,r9
    if (!c.t) { goto L_06015A7A; }  // 06015A60 bf 0x06015A7A
    c.r[3] = ld32(0x06015B60u);  // 06015A62 mov.l 0x06015B60,r3
    c.r[2] = ld32(c.r[3]);  // 06015A64 mov.l @r3,r2
    c.r[1] = ld32(0x06015B64u);  // 06015A66 mov.l 0x06015B64,r1
    c.r[2] += 1;  // 06015A68 add #1,r2
    c.t = c.r[2] >= c.r[1];  // 06015A6A cmp/hs r1,r2
    { const bool k = !c.t; st32(c.r[3], c.r[2]); if (k) { goto L_06015A74; } }  // 06015A6C bf/s 0x06015A74 ; mov.l r2,@r3
    c.r[1] = ld32(0x06015B68u);  // 06015A70 mov.l 0x06015B68,r1
    st32(c.r[3], c.r[1]);  // 06015A72 mov.l r1,@r3
L_06015A74:
    c.r[1] = ld32(c.r[3]);  // 06015A74 mov.l @r3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06015A76 mov.b @r1,r1
    c.r[9] = c.r[1] & 0xFFu;  // 06015A78 extu.b r1,r9
L_06015A7A:
    c.r[10] = ld32(0x06015B5Cu);  // 06015A7A mov.l 0x06015B5C,r10
    c.r[3] = c.r[10];  // 06015A7C mov r10,r3
    c.r[7] = ld32(c.r[10]);  // 06015A7E mov.l @r10,r7
    c.r[3] += 32;  // 06015A80 add #32,r3
    c.r[7] += 2;  // 06015A82 add #2,r7
    st32(c.r[10], c.r[7]);  // 06015A84 mov.l r7,@r10
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06015A86 mov.b @r3,r0
    c.r[11] = c.r[6];  // 06015A88 mov r6,r11
    c.r[1] = c.r[0] & 0xFFu;  // 06015A8A extu.b r0,r1
    c.r[1] >>= 2;  // 06015A8C shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06015A8E shlr r1
    c.r[1] >>= 2;  // 06015A90 shlr2 r1
    c.r[2] = c.r[1];  // 06015A92 mov r1,r2
    c.r[2] += 1;  // 06015A94 add #1,r2
    c.r[2] <<= 2;  // 06015A96 shll2 r2
    c.r[2] += c.r[2];  // 06015A98 add r2,r2
    c.r[2] <<= 2;  // 06015A9A shll2 r2
    c.r[0] &= 0x1Fu;  // 06015A9C and #31,r0
    c.r[0] |= c.r[2];  // 06015A9E or r2,r0
    st8(c.r[3], c.r[0]);  // 06015AA0 mov.b r0,@r3
    c.r[1] <<= 2;  // 06015AA2 shll2 r1
    c.r[1] += c.r[10];  // 06015AA4 add r10,r1
    st32(c.r[1] + 4, c.r[7]);  // 06015AA6 mov.l r7,@(4,r1)
    c.r[1] = (uint32_t)(int16_t)ld16(0x06015B58u);  // 06015AA8 mov.w 0x06015B58,r1
    c.r[2] = 0x13u;  // 06015AAA mov #19,r2
    c.r[11] -= c.r[1];  // 06015AAC sub r1,r11
    c.r[1] = c.r[11];  // 06015AAE mov r11,r1
    c.t = c.r[1] > c.r[2];  // 06015AB0 cmp/hi r2,r1
    { const bool k = !c.t; c.r[1] += c.r[1]; if (k) { goto L_06015ABA; } }  // 06015AB2 bf/s 0x06015ABA ; add r1,r1
    goto L_06015BF8;  // 06015AB6 bra 0x06015BF8 ; nop
L_06015ABA:
    c.r[0] = 0x06015AC4u;  // 06015ABA mova 0x06015AC4,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06015ABC mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 06015ABE add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x06015AECu: goto L_06015AEC; case 0x06015AF4u: goto L_06015AF4; case 0x06015B00u: goto L_06015B00; case 0x06015B0Cu: goto L_06015B0C; case 0x06015B14u: goto L_06015B14; case 0x06015B22u: goto L_06015B22; case 0x06015B2Au: goto L_06015B2A; case 0x06015B38u: goto L_06015B38; case 0x06015B40u: goto L_06015B40; case 0x06015B4Eu: goto L_06015B4E; case 0x06015B7Cu: goto L_06015B7C; case 0x06015B8Au: goto L_06015B8A; case 0x06015B98u: goto L_06015B98; case 0x06015BA6u: goto L_06015BA6; case 0x06015BB4u: goto L_06015BB4; case 0x06015BC2u: goto L_06015BC2; case 0x06015BCAu: goto L_06015BCA; case 0x06015BD2u: goto L_06015BD2; case 0x06015BDAu: goto L_06015BDA; case 0x06015BE2u: goto L_06015BE2; default: sh2_call(c, x); return; } }  // 06015AC0 jmp @r0 ; nop
L_06015AEC:
    c.r[4] = ld32(0x06015B6Cu);  // 06015AEC mov.l 0x06015B6C,r4
    c.r[8] = ld32(0x06015B70u);  // 06015AEE mov.l 0x06015B70,r8
    c.r[5] = 0x14u; goto L_06015BE8;  // 06015AF0 bra 0x06015BE8 ; mov #20,r5
L_06015AF4:
    c.r[4] = ld32(0x06015B74u);  // 06015AF4 mov.l 0x06015B74,r4
    c.r[0] = ld32(0x06015B70u);  // 06015AF6 mov.l 0x06015B70,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06015AFCu; c.r[5] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06015AFCu) return; }  // 06015AF8 jsr @r0 ; mov r9,r5
    goto L_06015BF2;  // 06015AFC bra 0x06015BF2 ; nop
L_06015B00:
    c.r[4] = ld32(0x06015B78u);  // 06015B00 mov.l 0x06015B78,r4
    c.r[0] = ld32(0x06015B70u);  // 06015B02 mov.l 0x06015B70,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06015B08u; c.r[5] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06015B08u) return; }  // 06015B04 jsr @r0 ; mov r9,r5
    goto L_06015BF2;  // 06015B08 bra 0x06015BF2 ; nop
L_06015B0C:
    c.r[4] = ld32(0x06015B6Cu);  // 06015B0C mov.l 0x06015B6C,r4
    c.r[8] = ld32(0x06015B70u);  // 06015B0E mov.l 0x06015B70,r8
    c.r[5] = 0xBu; goto L_06015BE8;  // 06015B10 bra 0x06015BE8 ; mov #11,r5
L_06015B14:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06015B5Au);  // 06015B14 mov.w 0x06015B5A,r1
    c.r[9] += c.r[1];  // 06015B16 add r1,r9
    c.r[9] = c.r[9] & 0xFFFFu;  // 06015B18 extu.w r9,r9
    c.r[4] = ld32(0x06015B6Cu);  // 06015B1A mov.l 0x06015B6C,r4
    c.r[8] = ld32(0x06015B70u);  // 06015B1C mov.l 0x06015B70,r8
    c.r[5] = 0xBu; goto L_06015BE8;  // 06015B1E bra 0x06015BE8 ; mov #11,r5
L_06015B22:
    c.r[4] = ld32(0x06015B6Cu);  // 06015B22 mov.l 0x06015B6C,r4
    c.r[8] = ld32(0x06015B70u);  // 06015B24 mov.l 0x06015B70,r8
    c.r[5] = 0xCu; goto L_06015BE8;  // 06015B26 bra 0x06015BE8 ; mov #12,r5
L_06015B2A:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06015B5Au);  // 06015B2A mov.w 0x06015B5A,r1
    c.r[9] += c.r[1];  // 06015B2C add r1,r9
    c.r[9] = c.r[9] & 0xFFFFu;  // 06015B2E extu.w r9,r9
    c.r[4] = ld32(0x06015B6Cu);  // 06015B30 mov.l 0x06015B6C,r4
    c.r[8] = ld32(0x06015B70u);  // 06015B32 mov.l 0x06015B70,r8
    c.r[5] = 0xCu; goto L_06015BE8;  // 06015B34 bra 0x06015BE8 ; mov #12,r5
L_06015B38:
    c.r[4] = ld32(0x06015B6Cu);  // 06015B38 mov.l 0x06015B6C,r4
    c.r[8] = ld32(0x06015B70u);  // 06015B3A mov.l 0x06015B70,r8
    c.r[5] = 0xDu; goto L_06015BE8;  // 06015B3C bra 0x06015BE8 ; mov #13,r5
L_06015B40:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06015B5Au);  // 06015B40 mov.w 0x06015B5A,r1
    c.r[9] += c.r[1];  // 06015B42 add r1,r9
    c.r[9] = c.r[9] & 0xFFFFu;  // 06015B44 extu.w r9,r9
    c.r[4] = ld32(0x06015B6Cu);  // 06015B46 mov.l 0x06015B6C,r4
    c.r[8] = ld32(0x06015B70u);  // 06015B48 mov.l 0x06015B70,r8
    c.r[5] = 0xDu; goto L_06015BE8;  // 06015B4A bra 0x06015BE8 ; mov #13,r5
L_06015B4E:
    c.r[4] = ld32(0x06015B6Cu);  // 06015B4E mov.l 0x06015B6C,r4
    c.r[8] = ld32(0x06015B70u);  // 06015B50 mov.l 0x06015B70,r8
    c.r[5] = 0xEu; goto L_06015BE8;  // 06015B52 bra 0x06015BE8 ; mov #14,r5
L_06015B7C:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06015C1Eu);  // 06015B7C mov.w 0x06015C1E,r1
    c.r[9] += c.r[1];  // 06015B7E add r1,r9
    c.r[9] = c.r[9] & 0xFFFFu;  // 06015B80 extu.w r9,r9
    c.r[4] = ld32(0x06015C28u);  // 06015B82 mov.l 0x06015C28,r4
    c.r[8] = ld32(0x06015C2Cu);  // 06015B84 mov.l 0x06015C2C,r8
    c.r[5] = 0xEu; goto L_06015BE8;  // 06015B86 bra 0x06015BE8 ; mov #14,r5
L_06015B8A:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06015C20u);  // 06015B8A mov.w 0x06015C20,r1
    c.r[9] += c.r[1];  // 06015B8C add r1,r9
    c.r[9] = c.r[9] & 0xFFFFu;  // 06015B8E extu.w r9,r9
    c.r[4] = ld32(0x06015C28u);  // 06015B90 mov.l 0x06015C28,r4
    c.r[8] = ld32(0x06015C2Cu);  // 06015B92 mov.l 0x06015C2C,r8
    c.r[5] = 0xEu; goto L_06015BE8;  // 06015B94 bra 0x06015BE8 ; mov #14,r5
L_06015B98:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06015C22u);  // 06015B98 mov.w 0x06015C22,r1
    c.r[9] += c.r[1];  // 06015B9A add r1,r9
    c.r[9] = c.r[9] & 0xFFFFu;  // 06015B9C extu.w r9,r9
    c.r[4] = ld32(0x06015C28u);  // 06015B9E mov.l 0x06015C28,r4
    c.r[8] = ld32(0x06015C2Cu);  // 06015BA0 mov.l 0x06015C2C,r8
    c.r[5] = 0xEu; goto L_06015BE8;  // 06015BA2 bra 0x06015BE8 ; mov #14,r5
L_06015BA6:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06015C24u);  // 06015BA6 mov.w 0x06015C24,r1
    c.r[9] += c.r[1];  // 06015BA8 add r1,r9
    c.r[9] = c.r[9] & 0xFFFFu;  // 06015BAA extu.w r9,r9
    c.r[4] = ld32(0x06015C28u);  // 06015BAC mov.l 0x06015C28,r4
    c.r[8] = ld32(0x06015C2Cu);  // 06015BAE mov.l 0x06015C2C,r8
    c.r[5] = 0xEu; goto L_06015BE8;  // 06015BB0 bra 0x06015BE8 ; mov #14,r5
L_06015BB4:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06015C26u);  // 06015BB4 mov.w 0x06015C26,r1
    c.r[9] += c.r[1];  // 06015BB6 add r1,r9
    c.r[9] = c.r[9] & 0xFFFFu;  // 06015BB8 extu.w r9,r9
    c.r[4] = ld32(0x06015C28u);  // 06015BBA mov.l 0x06015C28,r4
    c.r[8] = ld32(0x06015C2Cu);  // 06015BBC mov.l 0x06015C2C,r8
    c.r[5] = 0xEu; goto L_06015BE8;  // 06015BBE bra 0x06015BE8 ; mov #14,r5
L_06015BC2:
    c.r[4] = ld32(0x06015C28u);  // 06015BC2 mov.l 0x06015C28,r4
    c.r[8] = ld32(0x06015C2Cu);  // 06015BC4 mov.l 0x06015C2C,r8
    c.r[5] = 0xFu; goto L_06015BE8;  // 06015BC6 bra 0x06015BE8 ; mov #15,r5
L_06015BCA:
    c.r[4] = ld32(0x06015C28u);  // 06015BCA mov.l 0x06015C28,r4
    c.r[8] = ld32(0x06015C2Cu);  // 06015BCC mov.l 0x06015C2C,r8
    c.r[5] = 0x10u; goto L_06015BE8;  // 06015BCE bra 0x06015BE8 ; mov #16,r5
L_06015BD2:
    c.r[4] = ld32(0x06015C28u);  // 06015BD2 mov.l 0x06015C28,r4
    c.r[8] = ld32(0x06015C2Cu);  // 06015BD4 mov.l 0x06015C2C,r8
    c.r[5] = 0x11u; goto L_06015BE8;  // 06015BD6 bra 0x06015BE8 ; mov #17,r5
L_06015BDA:
    c.r[4] = ld32(0x06015C28u);  // 06015BDA mov.l 0x06015C28,r4
    c.r[8] = ld32(0x06015C2Cu);  // 06015BDC mov.l 0x06015C2C,r8
    c.r[5] = 0x12u; goto L_06015BE8;  // 06015BDE bra 0x06015BE8 ; mov #18,r5
L_06015BE2:
    c.r[4] = ld32(0x06015C28u);  // 06015BE2 mov.l 0x06015C28,r4
    c.r[8] = ld32(0x06015C2Cu);  // 06015BE4 mov.l 0x06015C2C,r8
    c.r[5] = 0x13u;  // 06015BE6 mov #19,r5
L_06015BE8:
    { const uint32_t x = c.r[8]; c.pr = 0x06015BECu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06015BECu) return; }  // 06015BE8 jsr @r8 ; nop
    c.r[5] = c.r[9];  // 06015BEC mov r9,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06015BF2u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06015BF2u) return; }  // 06015BEE jsr @r8 ; mov r0,r4
L_06015BF2:
    c.r[1] = ld32(0x06015C30u);  // 06015BF2 mov.l 0x06015C30,r1
    st32(c.r[1], c.r[0]); goto L_06015C0C;  // 06015BF4 bra 0x06015C0C ; mov.l r0,@r1
L_06015BF8:
    c.r[6] <<= 8;  // 06015BF8 shll8 r6
    c.r[9] |= c.r[6];  // 06015BFA or r6,r9
    c.r[4] = ld32(0x06015C28u);  // 06015BFC mov.l 0x06015C28,r4
    c.r[8] = ld32(0x06015C2Cu);  // 06015BFE mov.l 0x06015C2C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06015C04u; c.r[5] = 0x18u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06015C04u) return; }  // 06015C00 jsr @r8 ; mov #24,r5
    c.r[5] = c.r[9];  // 06015C04 mov r9,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06015C0Au; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06015C0Au) return; }  // 06015C06 jsr @r8 ; mov r0,r4
    st32(c.r[10], c.r[0]);  // 06015C0A mov.l r0,@r10
L_06015C0C:
    c.r[15] = c.r[14];  // 06015C0C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06015C0E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06015C10 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06015C12 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06015C14 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06015C16 mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06015C18 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.r[0] = 0x0u; c.pc = x; return; }  // 06015C1A rts ; mov #0,r0
}

void f_06015C34(SH2Context& c) {
    ran[117] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06015C34 mov.l r14,@-r15
    c.r[4] = ld32(0x06015C84u);  // 06015C36 mov.l 0x06015C84,r4
    c.r[0] = c.r[4];  // 06015C38 mov r4,r0
    c.r[0] += 58;  // 06015C3A add #58,r0
    c.r[6] = ld32(c.r[4]);  // 06015C3C mov.l @r4,r6
    c.r[5] = c.r[4];  // 06015C3E mov r4,r5
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06015C40 mov.b @r0,r3
    c.r[2] = c.r[6];  // 06015C42 mov r6,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]); c.r[2] += 1;  // 06015C44 mov.b @r2+,r1
    c.r[5] += 59;  // 06015C46 add #59,r5
    c.r[3] += c.r[1];  // 06015C48 add r1,r3
    st8(c.r[0], c.r[3]);  // 06015C4A mov.b r3,@r0
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[5]);  // 06015C4C mov.b @r5,r7
    c.r[14] = c.r[15];  // 06015C4E mov r15,r14
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06015C50 mov.b @r2,r1
    c.r[3] = c.r[3] & 0xFFu;  // 06015C52 extu.b r3,r3
    c.r[2] = c.r[7];  // 06015C54 mov r7,r2
    c.r[2] += c.r[1];  // 06015C56 add r1,r2
    c.r[1] = 0x27u;  // 06015C58 mov #39,r1
    c.t = c.r[3] > c.r[1];  // 06015C5A cmp/hi r1,r3
    { const bool k = !c.t; st8(c.r[5], c.r[2]); if (k) { goto L_06015C64; } }  // 06015C5C bf/s 0x06015C64 ; mov.b r2,@r5
    c.r[1] = 0x27u;  // 06015C60 mov #39,r1
    st8(c.r[0], c.r[1]);  // 06015C62 mov.b r1,@r0
L_06015C64:
    c.r[2] = c.r[2] & 0xFFu;  // 06015C64 extu.b r2,r2
    c.r[1] = 0x1Bu;  // 06015C66 mov #27,r1
    c.t = c.r[2] > c.r[1];  // 06015C68 cmp/hi r1,r2
    { const bool k = !c.t; c.r[1] = 0x1Bu; if (k) { goto L_06015C70; } }  // 06015C6A bf/s 0x06015C70 ; mov #27,r1
    st8(c.r[5], c.r[1]);  // 06015C6E mov.b r1,@r5
L_06015C70:
    c.r[2] = c.r[4];  // 06015C70 mov r4,r2
    c.r[2] += 63;  // 06015C72 add #63,r2
    c.r[6] += 2;  // 06015C74 add #2,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06015C76 mov.b @r0,r1
    c.r[15] = c.r[14];  // 06015C78 mov r14,r15
    st8(c.r[2], c.r[1]);  // 06015C7A mov.b r1,@r2
    st32(c.r[4], c.r[6]);  // 06015C7C mov.l r6,@r4
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06015C7E mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = 0x0u; c.pc = x; return; }  // 06015C80 rts ; mov #0,r0
}

void f_06015C88(SH2Context& c) {
    ran[118] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06015C88 mov.l r14,@-r15
    c.r[1] = ld32(0x06015D40u);  // 06015C8A mov.l 0x06015D40,r1
    c.r[7] = c.r[1];  // 06015C8C mov r1,r7
    c.r[1] = ld32(c.r[1]);  // 06015C8E mov.l @r1,r1
    c.r[7] += 58;  // 06015C90 add #58,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06015C92 mov.b @r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06015D3Au);  // 06015C94 mov.w 0x06015D3A,r2
    st8(c.r[7], c.r[1]);  // 06015C96 mov.b r1,@r7
    c.r[1] = c.r[1] & 0xFFu;  // 06015C98 extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 06015C9A cmp/eq r2,r1
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_06015CB8; } }  // 06015C9C bf/s 0x06015CB8 ; mov r15,r14
    c.r[3] = ld32(0x06015D44u);  // 06015CA0 mov.l 0x06015D44,r3
    c.r[2] = ld32(c.r[3]);  // 06015CA2 mov.l @r3,r2
    c.r[1] = ld32(0x06015D48u);  // 06015CA4 mov.l 0x06015D48,r1
    c.r[2] += 1;  // 06015CA6 add #1,r2
    c.t = c.r[2] >= c.r[1];  // 06015CA8 cmp/hs r1,r2
    { const bool k = !c.t; st32(c.r[3], c.r[2]); if (k) { goto L_06015CB2; } }  // 06015CAA bf/s 0x06015CB2 ; mov.l r2,@r3
    c.r[1] = ld32(0x06015D4Cu);  // 06015CAE mov.l 0x06015D4C,r1
    st32(c.r[3], c.r[1]);  // 06015CB0 mov.l r1,@r3
L_06015CB2:
    c.r[1] = ld32(c.r[3]);  // 06015CB2 mov.l @r3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06015CB4 mov.b @r1,r1
    st8(c.r[7], c.r[1]);  // 06015CB6 mov.b r1,@r7
L_06015CB8:
    c.r[1] = ld32(0x06015D40u);  // 06015CB8 mov.l 0x06015D40,r1
    c.r[7] = c.r[1];  // 06015CBA mov r1,r7
    c.r[1] = ld32(c.r[1]);  // 06015CBC mov.l @r1,r1
    c.r[7] += 59;  // 06015CBE add #59,r7
    c.r[1] += 1;  // 06015CC0 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06015CC2 mov.b @r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06015D3Au);  // 06015CC4 mov.w 0x06015D3A,r2
    st8(c.r[7], c.r[1]);  // 06015CC6 mov.b r1,@r7
    c.r[1] = c.r[1] & 0xFFu;  // 06015CC8 extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 06015CCA cmp/eq r2,r1
    if (!c.t) { goto L_06015CE6; }  // 06015CCC bf 0x06015CE6
    c.r[3] = ld32(0x06015D44u);  // 06015CCE mov.l 0x06015D44,r3
    c.r[2] = ld32(c.r[3]);  // 06015CD0 mov.l @r3,r2
    c.r[1] = ld32(0x06015D48u);  // 06015CD2 mov.l 0x06015D48,r1
    c.r[2] += 1;  // 06015CD4 add #1,r2
    c.t = c.r[2] >= c.r[1];  // 06015CD6 cmp/hs r1,r2
    { const bool k = !c.t; st32(c.r[3], c.r[2]); if (k) { goto L_06015CE0; } }  // 06015CD8 bf/s 0x06015CE0 ; mov.l r2,@r3
    c.r[1] = ld32(0x06015D4Cu);  // 06015CDC mov.l 0x06015D4C,r1
    st32(c.r[3], c.r[1]);  // 06015CDE mov.l r1,@r3
L_06015CE0:
    c.r[1] = ld32(c.r[3]);  // 06015CE0 mov.l @r3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06015CE2 mov.b @r1,r1
    st8(c.r[7], c.r[1]);  // 06015CE4 mov.b r1,@r7
L_06015CE6:
    c.r[7] = ld32(0x06015D40u);  // 06015CE6 mov.l 0x06015D40,r7
    c.r[5] = c.r[7];  // 06015CE8 mov r7,r5
    c.r[5] += 58;  // 06015CEA add #58,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[5]);  // 06015CEC mov.b @r5,r1
    c.r[2] = 0x27u;  // 06015CEE mov #39,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06015CF0 extu.b r1,r1
    c.t = c.r[1] > c.r[2];  // 06015CF2 cmp/hi r2,r1
    { const bool k = !c.t; c.r[1] = 0x27u; if (k) { goto L_06015CFA; } }  // 06015CF4 bf/s 0x06015CFA ; mov #39,r1
    st8(c.r[5], c.r[1]);  // 06015CF8 mov.b r1,@r5
L_06015CFA:
    c.r[6] = c.r[7];  // 06015CFA mov r7,r6
    c.r[6] += 59;  // 06015CFC add #59,r6
    c.r[1] = c.r[7];  // 06015CFE mov r7,r1
    c.r[1] += 32;  // 06015D00 add #32,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[6]);  // 06015D02 mov.b @r6,r3
    c.r[4] = (uint32_t)(int16_t)ld16(0x06015D3Cu);  // 06015D04 mov.w 0x06015D3C,r4
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06015D06 mov.b @r1,r2
    c.r[0] = c.r[3];  // 06015D08 mov r3,r0
    c.r[0] >>= 2;  // 06015D0A shlr2 r0
    c.r[0] &= 0x8u;  // 06015D0C and #8,r0
    c.r[2] &= c.r[4];  // 06015D0E and r4,r2
    c.r[2] |= c.r[0];  // 06015D10 or r0,r2
    st8(c.r[1], c.r[2]);  // 06015D12 mov.b r2,@r1
    c.r[0] = c.r[3];  // 06015D14 mov r3,r0
    c.r[0] &= 0x1Fu;  // 06015D16 and #31,r0
    c.r[1] = 0x1Bu;  // 06015D18 mov #27,r1
    c.t = c.r[0] > c.r[1];  // 06015D1A cmp/hi r1,r0
    { const bool k = !c.t; st8(c.r[6], c.r[0]); if (k) { goto L_06015D24; } }  // 06015D1C bf/s 0x06015D24 ; mov.b r0,@r6
    c.r[1] = 0x1Bu;  // 06015D20 mov #27,r1
    st8(c.r[6], c.r[1]);  // 06015D22 mov.b r1,@r6
L_06015D24:
    c.r[1] = c.r[7];  // 06015D24 mov r7,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[5]);  // 06015D26 mov.b @r5,r2
    c.r[1] += 63;  // 06015D28 add #63,r1
    st8(c.r[1], c.r[2]);  // 06015D2A mov.b r2,@r1
    c.r[1] = ld32(c.r[7]);  // 06015D2C mov.l @r7,r1
    c.r[15] = c.r[14];  // 06015D2E mov r14,r15
    c.r[1] += 2;  // 06015D30 add #2,r1
    st32(c.r[7], c.r[1]);  // 06015D32 mov.l r1,@r7
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06015D34 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = 0x0u; c.pc = x; return; }  // 06015D36 rts ; mov #0,r0
}

void f_06015D50(SH2Context& c) {
    ran[119] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06015D50 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06015D52 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06015D54 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06015D56 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06015D58 sts.l pr,@-r15
    c.r[3] = ld32(0x06015DCCu);  // 06015D5A mov.l 0x06015DCC,r3
    c.r[1] = ld32(c.r[3]);  // 06015D5C mov.l @r3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06015D5E mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 06015D60 extu.b r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06015DC6u);  // 06015D62 mov.w 0x06015DC6,r1
    c.t = c.r[2] == c.r[1];  // 06015D64 cmp/eq r1,r2
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06015D76; } }  // 06015D66 bt/s 0x06015D76 ; mov r15,r14
    c.r[1] = (uint32_t)(int16_t)ld16(0x06015DC8u);  // 06015D6A mov.w 0x06015DC8,r1
    c.t = c.r[2] == c.r[1];  // 06015D6C cmp/eq r1,r2
    { const bool k = c.t; c.r[8] = 0x0u; if (k) { goto L_06015D88; } }  // 06015D6E bt/s 0x06015D88 ; mov #0,r8
    goto L_06015D9A;  // 06015D72 bra 0x06015D9A ; nop
L_06015D76:
    c.r[3] += 32;  // 06015D76 add #32,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06015D78 mov.b @r3,r1
    c.r[0] = c.r[1];  // 06015D7A mov r1,r0
    c.r[0] >>= 2;  // 06015D7C shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06015D7E shlr r0
    c.r[0] &= 0x1u;  // 06015D80 and #1,r0
    c.r[1] = ld32(0x06015DD0u);  // 06015D82 mov.l 0x06015DD0,r1
    c.r[4] = c.r[0]; goto L_06015DAA;  // 06015D84 bra 0x06015DAA ; mov r0,r4
L_06015D88:
    c.r[10] = ld32(0x06015DD0u);  // 06015D88 mov.l 0x06015DD0,r10
    c.r[9] = 0x3u;  // 06015D8A mov #3,r9
L_06015D8C:
    { const uint32_t x = c.r[10]; c.pr = 0x06015D90u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06015D90u) return; }  // 06015D8C jsr @r10 ; mov r8,r4
    c.r[8] += 1;  // 06015D90 add #1,r8
    c.t = (int32_t)c.r[8] > (int32_t)c.r[9];  // 06015D92 cmp/gt r9,r8
    if (!c.t) { SH2_POLL(c); goto L_06015D8C; }  // 06015D94 bf 0x06015D8C
    goto L_06015DAE;  // 06015D96 bra 0x06015DAE ; nop
L_06015D9A:
    c.r[1] = ld32(0x06015DCCu);  // 06015D9A mov.l 0x06015DCC,r1
    c.r[1] = ld32(c.r[1]);  // 06015D9C mov.l @r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06015D9E mov.b @r1,r1
    c.r[4] = c.r[1] & 0xFFu;  // 06015DA0 extu.b r1,r4
    c.r[1] = 0x3u;  // 06015DA2 mov #3,r1
    c.t = c.r[4] > c.r[1];  // 06015DA4 cmp/hi r1,r4
    if (c.t) { goto L_06015DAE; }  // 06015DA6 bt 0x06015DAE
    c.r[1] = ld32(0x06015DD0u);  // 06015DA8 mov.l 0x06015DD0,r1
L_06015DAA:
    { const uint32_t x = c.r[1]; c.pr = 0x06015DAEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06015DAEu) return; }  // 06015DAA jsr @r1 ; nop
L_06015DAE:
    c.r[1] = ld32(0x06015DCCu);  // 06015DAE mov.l 0x06015DCC,r1
    c.r[2] = ld32(c.r[1]);  // 06015DB0 mov.l @r1,r2
    c.r[15] = c.r[14];  // 06015DB2 mov r14,r15
    c.r[2] += 1;  // 06015DB4 add #1,r2
    st32(c.r[1], c.r[2]);  // 06015DB6 mov.l r2,@r1
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06015DB8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06015DBA mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06015DBC mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06015DBE mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06015DC0 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.r[0] = 0x0u; c.pc = x; return; }  // 06015DC2 rts ; mov #0,r0
}

void f_06015DD4(SH2Context& c) {
    ran[120] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06015DD4 mov.l r14,@-r15
    c.r[3] = ld32(0x06015E18u);  // 06015DD6 mov.l 0x06015E18,r3
    c.r[7] = c.r[3];  // 06015DD8 mov r3,r7
    c.r[7] += 32;  // 06015DDA add #32,r7
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06015DDC mov.b @r7,r0
    c.r[1] = c.r[0] & 0xFFu;  // 06015DDE extu.b r0,r1
    c.r[2] = c.r[1];  // 06015DE0 mov r1,r2
    c.r[2] >>= 2;  // 06015DE2 shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 06015DE4 shlr r2
    c.r[2] >>= 2;  // 06015DE6 shlr2 r2
    c.r[1] = c.r[2] & 0xFFFFu;  // 06015DE8 extu.w r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06015DEA tst r1,r1
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_06015DF4; } }  // 06015DEC bf/s 0x06015DF4 ; mov r15,r14
    c.r[0] = 0xFFFFFFFFu; goto L_06015E12;  // 06015DF0 bra 0x06015E12 ; mov #-1,r0
L_06015DF4:
    c.r[2] -= 1;  // 06015DF4 add #-1,r2
    c.r[1] = c.r[2];  // 06015DF6 mov r2,r1
    c.r[1] <<= 2;  // 06015DF8 shll2 r1
    c.r[1] += c.r[1];  // 06015DFA add r1,r1
    c.r[1] <<= 2;  // 06015DFC shll2 r1
    c.r[0] &= 0x1Fu;  // 06015DFE and #31,r0
    c.r[0] |= c.r[1];  // 06015E00 or r1,r0
    st8(c.r[7], c.r[0]);  // 06015E02 mov.b r0,@r7
    c.r[6] = 0x7u;  // 06015E04 mov #7,r6
    c.r[2] &= c.r[6];  // 06015E06 and r6,r2
    c.r[2] <<= 2;  // 06015E08 shll2 r2
    c.r[2] += c.r[3];  // 06015E0A add r3,r2
    c.r[1] = ld32(c.r[2] + 4);  // 06015E0C mov.l @(4,r2),r1
    c.r[0] = 0x0u;  // 06015E0E mov #0,r0
    st32(c.r[3], c.r[1]);  // 06015E10 mov.l r1,@r3
L_06015E12:
    c.r[15] = c.r[14];  // 06015E12 mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06015E14 rts ; mov.l @r15+,r14
}

void f_06015E1C(SH2Context& c) {
    ran[121] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06015E1C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06015E1E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06015E20 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06015E22 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06015E24 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06015E26 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06015E28 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06015E2A mov r15,r14
    c.r[11] = ld32(0x06015EB0u);  // 06015E2C mov.l 0x06015EB0,r11
    c.r[1] = (uint32_t)(int16_t)ld16(0x06015EA6u);  // 06015E2E mov.w 0x06015EA6,r1
    c.macl = c.r[4] * c.r[1];  // 06015E30 mul.l r1,r4
    c.r[0] = c.r[11];  // 06015E32 mov r11,r0
    c.r[12] = (uint32_t)(int16_t)ld16(0x06015EA8u);  // 06015E34 mov.w 0x06015EA8,r12
    c.r[9] = c.macl;  // 06015E36 sts macl,r9
    c.r[10] = c.r[9];  // 06015E38 mov r9,r10
    c.r[10] += c.r[11];  // 06015E3A add r11,r10
    c.r[1] = c.r[10];  // 06015E3C mov r10,r1
    c.r[1] += 70;  // 06015E3E add #70,r1
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06015E40 mov.w @r1,r5
    c.r[6] = 0x3u;  // 06015E42 mov #3,r6
    c.r[4] = ld32(c.r[0] + c.r[12]);  // 06015E44 mov.l @(r0,r12),r4
    c.r[5] = c.r[5] & 0xFFFFu;  // 06015E46 extu.w r5,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x06015EAAu);  // 06015E48 mov.w 0x06015EAA,r1
    c.r[8] = c.r[5];  // 06015E4A mov r5,r8
    c.r[8] <<= 2;  // 06015E4C shll2 r8
    c.r[8] += c.r[8];  // 06015E4E add r8,r8
    c.r[7] = ld32(c.r[0] + c.r[1]);  // 06015E50 mov.l @(r0,r1),r7
    c.r[1] = ld32(0x06015EB4u);  // 06015E52 mov.l 0x06015EB4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06015E58u; c.r[4] += c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06015E58u) return; }  // 06015E54 jsr @r1 ; add r8,r4
    c.r[0] = c.r[11];  // 06015E58 mov r11,r0
    c.r[1] = ld32(0x06015EB8u);  // 06015E5A mov.l 0x06015EB8,r1
    c.r[4] = ld32(c.r[0] + c.r[12]);  // 06015E5C mov.l @(r0,r12),r4
    c.r[5] = 0x1u;  // 06015E5E mov #1,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06015E64u; c.r[4] += c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06015E64u) return; }  // 06015E60 jsr @r1 ; add r8,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x06015EACu);  // 06015E64 mov.w 0x06015EAC,r1
    c.r[0] = c.r[10];  // 06015E66 mov r10,r0
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 06015E68 mov.l @(r0,r1),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06015E6A tst r1,r1
    { const bool k = c.t; c.macl = c.r[9]; if (k) { goto L_06015E94; } }  // 06015E6C bt/s 0x06015E94 ; lds r9,macl
    c.r[6] = 0x0u;  // 06015E70 mov #0,r6
    c.r[7] = c.macl;  // 06015E72 sts macl,r7
    c.r[11] += 76;  // 06015E74 add #76,r11
    c.r[7] += c.r[11];  // 06015E76 add r11,r7
    c.r[3] = c.r[1];  // 06015E78 mov r1,r3
    c.r[5] = 0x27u;  // 06015E7A mov #39,r5
    c.r[4] = 0x1Bu;  // 06015E7C mov #27,r4
L_06015E7E:
    c.r[2] = 0x0u;  // 06015E7E mov #0,r2
L_06015E80:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[7]); c.r[7] += 2;  // 06015E80 mov.w @r7+,r1
    c.r[2] += 1;  // 06015E82 add #1,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[5];  // 06015E84 cmp/gt r5,r2
    st16(c.r[3], c.r[1]);  // 06015E86 mov.w r1,@r3
    { const bool k = !c.t; c.r[3] += 2; if (k) { SH2_POLL(c); goto L_06015E80; } }  // 06015E88 bf/s 0x06015E80 ; add #2,r3
    c.r[6] += 1;  // 06015E8C add #1,r6
    c.t = (int32_t)c.r[6] > (int32_t)c.r[4];  // 06015E8E cmp/gt r4,r6
    { const bool k = !c.t; c.r[3] += 48; if (k) { SH2_POLL(c); goto L_06015E7E; } }  // 06015E90 bf/s 0x06015E7E ; add #48,r3
L_06015E94:
    c.r[15] = c.r[14];  // 06015E94 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06015E96 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06015E98 mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06015E9A mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06015E9C mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06015E9E mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06015EA0 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06015EA2 rts ; mov.l @r15+,r8
}

void f_06015EBC(SH2Context& c) {
    ran[122] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06015EBC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06015EBE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06015EC0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06015EC2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06015EC4 sts.l pr,@-r15
    c.r[15] -= 4;  // 06015EC6 add #-4,r15
    c.r[14] = c.r[15];  // 06015EC8 mov r15,r14
    c.r[10] = c.r[4];  // 06015ECA mov r4,r10
    c.r[10] = c.r[10] & 0xFFu;  // 06015ECC extu.b r10,r10
    c.r[6] = ld32(0x06015FD4u);  // 06015ECE mov.l 0x06015FD4,r6
    c.r[8] = ld32(0x06015FD8u);  // 06015ED0 mov.l 0x06015FD8,r8
    c.r[0] = (uint32_t)(int16_t)ld16(0x06015FC6u);  // 06015ED2 mov.w 0x06015FC6,r0
    c.r[4] = ld32(c.r[0] + c.r[8]);  // 06015ED4 mov.l @(r0,r8),r4
    c.r[0] = ld32(0x06015FDCu);  // 06015ED6 mov.l 0x06015FDC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06015EDCu; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06015EDCu) return; }  // 06015ED8 jsr @r0 ; mov #0,r5
    c.r[1] = c.r[8];  // 06015EDC mov r8,r1
    c.r[1] += 32;  // 06015EDE add #32,r1
    c.r[2] = c.r[8];  // 06015EE0 mov r8,r2
    c.r[2] += 60;  // 06015EE2 add #60,r2
    c.r[4] = ld32(0x06015FE0u);  // 06015EE4 mov.l 0x06015FE0,r4
    c.r[9] = ld32(0x06015FE4u);  // 06015EE6 mov.l 0x06015FE4,r9
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06015EE8 mov.b @r1,r0
    c.r[5] = 0x18u;  // 06015EEA mov #24,r5
    c.r[0] &= 0xFBu;  // 06015EEC and #251,r0
    st8(c.r[1], c.r[0]);  // 06015EEE mov.b r0,@r1
    c.r[1] = 0x10u;  // 06015EF0 mov #16,r1
    { const uint32_t x = c.r[9]; c.pr = 0x06015EF6u; st8(c.r[2], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06015EF6u) return; }  // 06015EF2 jsr @r9 ; mov.b r1,@r2
    c.r[5] = c.r[10];  // 06015EF6 mov r10,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06015EFCu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06015EFCu) return; }  // 06015EF8 jsr @r9 ; mov r0,r4
    st32(c.r[8], c.r[0]);  // 06015EFC mov.l r0,@r8
    c.r[9] = ld32(0x06015FE8u);  // 06015EFE mov.l 0x06015FE8,r9
    c.r[10] = c.r[8];  // 06015F00 mov r8,r10
    c.r[10] += 58;  // 06015F02 add #58,r10
    c.r[1] = ld32(c.r[8]);  // 06015F04 mov.l @r8,r1
L_06015F06:
    c.r[2] = c.r[1];  // 06015F06 mov r1,r2
    c.r[2] += 1;  // 06015F08 add #1,r2
    st32(c.r[8], c.r[2]);  // 06015F0A mov.l r2,@r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06015F0C mov.b @r1,r1
    c.r[6] = c.r[1] & 0xFFu;  // 06015F0E extu.b r1,r6
    c.r[1] = c.r[8];  // 06015F10 mov r8,r1
    c.r[1] += 32;  // 06015F12 add #32,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06015F14 mov.b @r1,r1
    c.r[3] = c.r[1] & 0xFFu;  // 06015F16 extu.b r1,r3
    c.r[0] = c.r[3];  // 06015F18 mov r3,r0
    c.r[0] >>= 2;  // 06015F1A shlr2 r0
    c.r[0] >>= 2;  // 06015F1C shlr2 r0
    c.r[0] &= 0x1u;  // 06015F1E and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06015F20 tst r0,r0
    if (c.t) { goto L_06015F52; }  // 06015F22 bt 0x06015F52
    c.r[1] = (uint32_t)(int16_t)ld16(0x06015FC8u);  // 06015F24 mov.w 0x06015FC8,r1
    c.t = (int32_t)c.r[6] > (int32_t)c.r[1];  // 06015F26 cmp/gt r1,r6
    if (!c.t) { goto L_06015F4A; }  // 06015F28 bf 0x06015F4A
    c.r[1] = (uint32_t)(int16_t)ld16(0x06015FCAu);  // 06015F2A mov.w 0x06015FCA,r1
    c.t = (int32_t)c.r[6] > (int32_t)c.r[1];  // 06015F2C cmp/gt r1,r6
    if (c.t) { goto L_06015F5A; }  // 06015F2E bt 0x06015F5A
    c.r[1] = (uint32_t)(int16_t)ld16(0x06015FCCu);  // 06015F30 mov.w 0x06015FCC,r1
    c.r[6] += c.r[1];  // 06015F32 add r1,r6
    c.r[1] = c.r[2];  // 06015F34 mov r2,r1
    c.r[1] += 1;  // 06015F36 add #1,r1
    st32(c.r[8], c.r[1]);  // 06015F38 mov.l r1,@r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06015F3A mov.b @r2,r1
    c.r[6] <<= 8;  // 06015F3C shll8 r6
    c.r[1] = c.r[1] & 0xFFu;  // 06015F3E extu.b r1,r1
    c.r[6] += c.r[1];  // 06015F40 add r1,r6
    { const uint32_t x = c.r[9]; c.pr = 0x06015F46u; c.r[4] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06015F46u) return; }  // 06015F42 jsr @r9 ; extu.w r6,r4
    c.r[1] = ld32(c.r[8]); SH2_POLL(c); goto L_06015F06;  // 06015F46 bra 0x06015F06 ; mov.l @r8,r1
L_06015F4A:
    { const uint32_t x = c.r[9]; c.pr = 0x06015F4Eu; c.r[4] = c.r[6]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06015F4Eu) return; }  // 06015F4A jsr @r9 ; mov r6,r4
    c.r[1] = ld32(c.r[8]); SH2_POLL(c); goto L_06015F06;  // 06015F4E bra 0x06015F06 ; mov.l @r8,r1
L_06015F52:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06015FCEu);  // 06015F52 mov.w 0x06015FCE,r1
    c.t = (int32_t)c.r[6] > (int32_t)c.r[1];  // 06015F54 cmp/gt r1,r6
    { const bool k = !c.t; c.t = (c.r[6] & c.r[6]) == 0; if (k) { goto L_06015F70; } }  // 06015F56 bf/s 0x06015F70 ; tst r6,r6
L_06015F5A:
    c.r[6] <<= 2;  // 06015F5A shll2 r6
    c.r[1] = ld32(0x06015FECu);  // 06015F5C mov.l 0x06015FEC,r1
    c.r[0] = c.r[6];  // 06015F5E mov r6,r0
    c.r[6] = ld32(c.r[0] + c.r[1]);  // 06015F60 mov.l @(r0,r1),r6
    { const uint32_t x = c.r[6]; c.pr = 0x06015F66u; st32(c.r[14], c.r[6]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06015F66u) return; }  // 06015F62 jsr @r6 ; mov.l r6,@r14
    c.t = c.r[0] == 0xFFFFFFFFu;  // 06015F66 cmp/eq #-1,r0
    { const bool k = c.t; c.r[1] = c.r[0]; if (k) { goto L_06015FB6; } }  // 06015F68 bt/s 0x06015FB6 ; mov r0,r1
    c.r[1] = ld32(c.r[8]); SH2_POLL(c); goto L_06015F06;  // 06015F6C bra 0x06015F06 ; mov.l @r8,r1
L_06015F70:
    { const bool k = c.t; c.r[0] = c.r[3]; if (k) { goto L_06015FAC; } }  // 06015F70 bt/s 0x06015FAC ; mov r3,r0
    c.r[0] >>= 2;  // 06015F74 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06015F76 shlr r0
    c.r[0] &= 0x1u;  // 06015F78 and #1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06015FD0u);  // 06015F7A mov.w 0x06015FD0,r1
    c.macl = (c.r[0] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 06015F7C mulu.w r1,r0
    c.r[2] = c.r[8];  // 06015F7E mov r8,r2
    c.r[7] = c.macl;  // 06015F80 sts macl,r7
    c.r[7] += c.r[8];  // 06015F82 add r8,r7
    c.r[1] = c.r[7];  // 06015F84 mov r7,r1
    c.r[1] += 74;  // 06015F86 add #74,r1
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06015F88 mov.w @r1,r3
    c.r[2] += 56;  // 06015F8A add #56,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06015F8C mov.w @r2,r1
    c.r[3] += c.r[1];  // 06015F8E add r1,r3
    c.r[1] = c.r[8];  // 06015F90 mov r8,r1
    c.r[1] += 59;  // 06015F92 add #59,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06015F94 mov.b @r1,r1
    c.r[2] = 0x50u;  // 06015F96 mov #80,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06015F98 extu.b r1,r1
    c.macl = c.r[1] * c.r[2];  // 06015F9A mul.l r2,r1
    c.r[3] += c.r[6];  // 06015F9C add r6,r3
    c.r[0] = c.macl;  // 06015F9E sts macl,r0
    c.r[0] += c.r[7];  // 06015FA0 add r7,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 06015FA2 mov.b @r10,r1
    c.r[0] += 76;  // 06015FA4 add #76,r0
    c.r[1] = c.r[1] & 0xFFu;  // 06015FA6 extu.b r1,r1
    c.r[1] += c.r[1];  // 06015FA8 add r1,r1
    st16(c.r[0] + c.r[1], c.r[3]);  // 06015FAA mov.w r3,@(r0,r1)
L_06015FAC:
    c.r[1] = ld32(0x06015FF0u);  // 06015FAC mov.l 0x06015FF0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06015FB2u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06015FB2u) return; }  // 06015FAE jsr @r1 ; mov #1,r4
    c.r[1] = ld32(c.r[8]); SH2_POLL(c); goto L_06015F06;  // 06015FB2 bra 0x06015F06 ; mov.l @r8,r1
L_06015FB6:
    c.r[14] += 4;  // 06015FB6 add #4,r14
    c.r[15] = c.r[14];  // 06015FB8 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06015FBA lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06015FBC mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06015FBE mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06015FC0 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06015FC2 rts ; mov.l @r15+,r8
}

void f_06015F4E(SH2Context& c) {
    ran[123] = 1;
    goto L_06015F4E;
L_06015F06:
    c.r[2] = c.r[1];  // 06015F06 mov r1,r2
    c.r[2] += 1;  // 06015F08 add #1,r2
    st32(c.r[8], c.r[2]);  // 06015F0A mov.l r2,@r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06015F0C mov.b @r1,r1
    c.r[6] = c.r[1] & 0xFFu;  // 06015F0E extu.b r1,r6
    c.r[1] = c.r[8];  // 06015F10 mov r8,r1
    c.r[1] += 32;  // 06015F12 add #32,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06015F14 mov.b @r1,r1
    c.r[3] = c.r[1] & 0xFFu;  // 06015F16 extu.b r1,r3
    c.r[0] = c.r[3];  // 06015F18 mov r3,r0
    c.r[0] >>= 2;  // 06015F1A shlr2 r0
    c.r[0] >>= 2;  // 06015F1C shlr2 r0
    c.r[0] &= 0x1u;  // 06015F1E and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06015F20 tst r0,r0
    if (c.t) { goto L_06015F52; }  // 06015F22 bt 0x06015F52
    c.r[1] = (uint32_t)(int16_t)ld16(0x06015FC8u);  // 06015F24 mov.w 0x06015FC8,r1
    c.t = (int32_t)c.r[6] > (int32_t)c.r[1];  // 06015F26 cmp/gt r1,r6
    if (!c.t) { goto L_06015F4A; }  // 06015F28 bf 0x06015F4A
    c.r[1] = (uint32_t)(int16_t)ld16(0x06015FCAu);  // 06015F2A mov.w 0x06015FCA,r1
    c.t = (int32_t)c.r[6] > (int32_t)c.r[1];  // 06015F2C cmp/gt r1,r6
    if (c.t) { goto L_06015F5A; }  // 06015F2E bt 0x06015F5A
    c.r[1] = (uint32_t)(int16_t)ld16(0x06015FCCu);  // 06015F30 mov.w 0x06015FCC,r1
    c.r[6] += c.r[1];  // 06015F32 add r1,r6
    c.r[1] = c.r[2];  // 06015F34 mov r2,r1
    c.r[1] += 1;  // 06015F36 add #1,r1
    st32(c.r[8], c.r[1]);  // 06015F38 mov.l r1,@r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06015F3A mov.b @r2,r1
    c.r[6] <<= 8;  // 06015F3C shll8 r6
    c.r[1] = c.r[1] & 0xFFu;  // 06015F3E extu.b r1,r1
    c.r[6] += c.r[1];  // 06015F40 add r1,r6
    { const uint32_t x = c.r[9]; c.pr = 0x06015F46u; c.r[4] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06015F46u) return; }  // 06015F42 jsr @r9 ; extu.w r6,r4
    c.r[1] = ld32(c.r[8]); SH2_POLL(c); goto L_06015F06;  // 06015F46 bra 0x06015F06 ; mov.l @r8,r1
L_06015F4A:
    { const uint32_t x = c.r[9]; c.pr = 0x06015F4Eu; c.r[4] = c.r[6]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06015F4Eu) return; }  // 06015F4A jsr @r9 ; mov r6,r4
L_06015F4E:
    c.r[1] = ld32(c.r[8]); SH2_POLL(c); goto L_06015F06;  // 06015F4E bra 0x06015F06 ; mov.l @r8,r1
L_06015F52:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06015FCEu);  // 06015F52 mov.w 0x06015FCE,r1
    c.t = (int32_t)c.r[6] > (int32_t)c.r[1];  // 06015F54 cmp/gt r1,r6
    { const bool k = !c.t; c.t = (c.r[6] & c.r[6]) == 0; if (k) { goto L_06015F70; } }  // 06015F56 bf/s 0x06015F70 ; tst r6,r6
L_06015F5A:
    c.r[6] <<= 2;  // 06015F5A shll2 r6
    c.r[1] = ld32(0x06015FECu);  // 06015F5C mov.l 0x06015FEC,r1
    c.r[0] = c.r[6];  // 06015F5E mov r6,r0
    c.r[6] = ld32(c.r[0] + c.r[1]);  // 06015F60 mov.l @(r0,r1),r6
    { const uint32_t x = c.r[6]; c.pr = 0x06015F66u; st32(c.r[14], c.r[6]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06015F66u) return; }  // 06015F62 jsr @r6 ; mov.l r6,@r14
    c.t = c.r[0] == 0xFFFFFFFFu;  // 06015F66 cmp/eq #-1,r0
    { const bool k = c.t; c.r[1] = c.r[0]; if (k) { goto L_06015FB6; } }  // 06015F68 bt/s 0x06015FB6 ; mov r0,r1
    c.r[1] = ld32(c.r[8]); SH2_POLL(c); goto L_06015F06;  // 06015F6C bra 0x06015F06 ; mov.l @r8,r1
L_06015F70:
    { const bool k = c.t; c.r[0] = c.r[3]; if (k) { goto L_06015FAC; } }  // 06015F70 bt/s 0x06015FAC ; mov r3,r0
    c.r[0] >>= 2;  // 06015F74 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06015F76 shlr r0
    c.r[0] &= 0x1u;  // 06015F78 and #1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06015FD0u);  // 06015F7A mov.w 0x06015FD0,r1
    c.macl = (c.r[0] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 06015F7C mulu.w r1,r0
    c.r[2] = c.r[8];  // 06015F7E mov r8,r2
    c.r[7] = c.macl;  // 06015F80 sts macl,r7
    c.r[7] += c.r[8];  // 06015F82 add r8,r7
    c.r[1] = c.r[7];  // 06015F84 mov r7,r1
    c.r[1] += 74;  // 06015F86 add #74,r1
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06015F88 mov.w @r1,r3
    c.r[2] += 56;  // 06015F8A add #56,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06015F8C mov.w @r2,r1
    c.r[3] += c.r[1];  // 06015F8E add r1,r3
    c.r[1] = c.r[8];  // 06015F90 mov r8,r1
    c.r[1] += 59;  // 06015F92 add #59,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06015F94 mov.b @r1,r1
    c.r[2] = 0x50u;  // 06015F96 mov #80,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06015F98 extu.b r1,r1
    c.macl = c.r[1] * c.r[2];  // 06015F9A mul.l r2,r1
    c.r[3] += c.r[6];  // 06015F9C add r6,r3
    c.r[0] = c.macl;  // 06015F9E sts macl,r0
    c.r[0] += c.r[7];  // 06015FA0 add r7,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 06015FA2 mov.b @r10,r1
    c.r[0] += 76;  // 06015FA4 add #76,r0
    c.r[1] = c.r[1] & 0xFFu;  // 06015FA6 extu.b r1,r1
    c.r[1] += c.r[1];  // 06015FA8 add r1,r1
    st16(c.r[0] + c.r[1], c.r[3]);  // 06015FAA mov.w r3,@(r0,r1)
L_06015FAC:
    c.r[1] = ld32(0x06015FF0u);  // 06015FAC mov.l 0x06015FF0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06015FB2u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06015FB2u) return; }  // 06015FAE jsr @r1 ; mov #1,r4
    c.r[1] = ld32(c.r[8]); SH2_POLL(c); goto L_06015F06;  // 06015FB2 bra 0x06015F06 ; mov.l @r8,r1
L_06015FB6:
    c.r[14] += 4;  // 06015FB6 add #4,r14
    c.r[15] = c.r[14];  // 06015FB8 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06015FBA lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06015FBC mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06015FBE mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06015FC0 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06015FC2 rts ; mov.l @r15+,r8
}

void f_06015FF4(SH2Context& c) {
    ran[124] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06015FF4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06015FF6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06015FF8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06015FFA sts.l pr,@-r15
    c.r[15] -= 12;  // 06015FFC add #-12,r15
    c.r[14] = c.r[15];  // 06015FFE mov r15,r14
    c.r[8] = c.r[5] & 0xFFu;  // 06016000 extu.b r5,r8
    c.r[7] = 0xFFFFFFFFu;  // 06016002 mov #-1,r7
    c.r[1] = c.r[7] & 0xFFu;  // 06016004 extu.b r7,r1
    c.t = c.r[8] == c.r[1];  // 06016006 cmp/eq r1,r8
    { const bool k = c.t; c.r[9] = c.r[4] & 0xFFFFu; if (k) { goto L_06016064; } }  // 06016008 bt/s 0x06016064 ; extu.w r4,r9
    c.r[1] = ld32(0x060161A8u);  // 0601600C mov.l 0x060161A8,r1
    c.r[3] = ld32(c.r[1]);  // 0601600E mov.l @r1,r3
    c.r[1] = c.r[8];  // 06016010 mov r8,r1
    c.r[1] <<= 2;  // 06016012 shll2 r1
    c.r[1] += c.r[8];  // 06016014 add r8,r1
    c.r[1] <<= 2;  // 06016016 shll2 r1
    c.r[3] += c.r[1];  // 06016018 add r1,r3
    c.r[1] = c.r[3];  // 0601601A mov r3,r1
    c.r[1] += 50;  // 0601601C add #50,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601601E mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06016020 extu.b r1,r0
    c.r[0] >>= 2;  // 06016022 shlr2 r0
    c.r[0] >>= 2;  // 06016024 shlr2 r0
    c.r[0] >>= 2;  // 06016026 shlr2 r0
    c.t = c.r[0] == 0x3u;  // 06016028 cmp/eq #3,r0
    { const bool k = !c.t; c.r[1] = 0x0u; if (k) { goto L_06016036; } }  // 0601602A bf/s 0x06016036 ; mov #0,r1
    st8(c.r[14], c.r[1]);  // 0601602E mov.b r1,@r14
    c.r[1] = c.r[14];  // 06016030 mov r14,r1
    c.r[1] += 1; goto L_06016058;  // 06016032 bra 0x06016058 ; add #1,r1
L_06016036:
    c.r[4] = ld32(0x060161ACu);  // 06016036 mov.l 0x060161AC,r4
    c.r[1] = ld32(0x060161B0u);  // 06016038 mov.l 0x060161B0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601603Eu; c.r[3] += 51; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601603Eu) return; }  // 0601603A jsr @r1 ; add #51,r3
    st8(c.r[14], c.r[4]);  // 0601603E mov.b r4,@r14
    c.r[2] = c.r[14];  // 06016040 mov r14,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06016042 mov.b @r3,r1
    c.r[2] += 1;  // 06016044 add #1,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06016046 extu.b r1,r1
    c.r[1] >>= 2;  // 06016048 shlr2 r1
    c.r[1] >>= 2;  // 0601604A shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0601604C shlr r1
    c.r[1] >>= 2;  // 0601604E shlr2 r1
    c.r[1] -= 11;  // 06016050 add #-11,r1
    st8(c.r[2], c.r[1]);  // 06016052 mov.b r1,@r2
    c.r[1] = c.r[14];  // 06016054 mov r14,r1
    c.r[1] += 2;  // 06016056 add #2,r1
L_06016058:
    st8(c.r[1], c.r[7]);  // 06016058 mov.b r7,@r1
    c.r[1] = ld32(0x060161B4u);  // 0601605A mov.l 0x060161B4,r1
    c.r[6] = 0x0u;  // 0601605C mov #0,r6
    c.r[5] = c.r[14];  // 0601605E mov r14,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06016064u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06016064u) return; }  // 06016060 jsr @r1 ; mov #0,r4
L_06016064:
    c.r[1] = ld32(0x060161B8u);  // 06016064 mov.l 0x060161B8,r1
    c.t = c.r[9] == c.r[1];  // 06016066 cmp/eq r1,r9
    if (!c.t) { goto L_06016098; }  // 06016068 bf 0x06016098
    c.r[6] = ld32(0x060161BCu);  // 0601606A mov.l 0x060161BC,r6
    c.r[3] = ld32(0x060161C0u);  // 0601606C mov.l 0x060161C0,r3
    c.r[1] = ld32(c.r[3]);  // 0601606E mov.l @r3,r1
    c.r[7] = ld32(0x060161C4u);  // 06016070 mov.l 0x060161C4,r7
    c.r[1] += 1;  // 06016072 add #1,r1
    c.t = c.r[1] >= c.r[7];  // 06016074 cmp/hs r7,r1
    { const bool k = !c.t; st32(c.r[3], c.r[1]); if (k) { goto L_0601607E; } }  // 06016076 bf/s 0x0601607E ; mov.l r1,@r3
    c.r[1] = ld32(0x060161C8u);  // 0601607A mov.l 0x060161C8,r1
    st32(c.r[3], c.r[1]);  // 0601607C mov.l r1,@r3
L_0601607E:
    c.r[1] = ld32(c.r[3]);  // 0601607E mov.l @r3,r1
    c.r[2] = 0xFFFFFFFEu;  // 06016080 mov #-2,r2
    st8(c.r[1], c.r[2]);  // 06016082 mov.b r2,@r1
    c.r[1] = ld32(c.r[3]);  // 06016084 mov.l @r3,r1
    c.r[1] += 1;  // 06016086 add #1,r1
    c.t = c.r[1] >= c.r[7];  // 06016088 cmp/hs r7,r1
    { const bool k = !c.t; st32(c.r[3], c.r[1]); if (k) { goto L_06016092; } }  // 0601608A bf/s 0x06016092 ; mov.l r1,@r3
    c.r[1] = ld32(0x060161C8u);  // 0601608E mov.l 0x060161C8,r1
    st32(c.r[3], c.r[1]);  // 06016090 mov.l r1,@r3
L_06016092:
    c.r[1] = ld32(c.r[3]);  // 06016092 mov.l @r3,r1
    st8(c.r[1], c.r[6]); goto L_060160C4;  // 06016094 bra 0x060160C4 ; mov.b r6,@r1
L_06016098:
    c.r[3] = ld32(0x060161C0u);  // 06016098 mov.l 0x060161C0,r3
    c.r[1] = ld32(c.r[3]);  // 0601609A mov.l @r3,r1
    c.r[7] = ld32(0x060161C4u);  // 0601609C mov.l 0x060161C4,r7
    c.r[1] += 1;  // 0601609E add #1,r1
    c.t = c.r[1] >= c.r[7];  // 060160A0 cmp/hs r7,r1
    { const bool k = !c.t; st32(c.r[3], c.r[1]); if (k) { goto L_060160AA; } }  // 060160A2 bf/s 0x060160AA ; mov.l r1,@r3
    c.r[1] = ld32(0x060161C8u);  // 060160A6 mov.l 0x060161C8,r1
    st32(c.r[3], c.r[1]);  // 060160A8 mov.l r1,@r3
L_060160AA:
    c.r[2] = c.r[9];  // 060160AA mov r9,r2
    c.r[1] = ld32(c.r[3]);  // 060160AC mov.l @r3,r1
    c.r[2] >>= 8;  // 060160AE shlr8 r2
    st8(c.r[1], c.r[2]);  // 060160B0 mov.b r2,@r1
    c.r[1] = ld32(c.r[3]);  // 060160B2 mov.l @r3,r1
    c.r[1] += 1;  // 060160B4 add #1,r1
    c.t = c.r[1] >= c.r[7];  // 060160B6 cmp/hs r7,r1
    { const bool k = !c.t; st32(c.r[3], c.r[1]); if (k) { goto L_060160C0; } }  // 060160B8 bf/s 0x060160C0 ; mov.l r1,@r3
    c.r[1] = ld32(0x060161C8u);  // 060160BC mov.l 0x060161C8,r1
    st32(c.r[3], c.r[1]);  // 060160BE mov.l r1,@r3
L_060160C0:
    c.r[1] = ld32(c.r[3]);  // 060160C0 mov.l @r3,r1
    st8(c.r[1], c.r[9]);  // 060160C2 mov.b r9,@r1
L_060160C4:
    c.r[5] = 0xFFFFFFFFu;  // 060160C4 mov #-1,r5
    c.r[1] = c.r[5] & 0xFFu;  // 060160C6 extu.b r5,r1
    c.t = c.r[8] == c.r[1];  // 060160C8 cmp/eq r1,r8
    { const bool k = c.t; c.r[1] = 0x0u; if (k) { goto L_0601617E; } }  // 060160CA bt/s 0x0601617E ; mov #0,r1
    st8(c.r[14], c.r[1]);  // 060160CE mov.b r1,@r14
    c.r[1] = c.r[14];  // 060160D0 mov r14,r1
    c.r[1] += 1;  // 060160D2 add #1,r1
    st8(c.r[1], c.r[5]);  // 060160D4 mov.b r5,@r1
    c.r[6] = ld32(0x060161A8u);  // 060160D6 mov.l 0x060161A8,r6
    c.r[7] = c.r[8];  // 060160D8 mov r8,r7
    c.r[7] <<= 2;  // 060160DA shll2 r7
    c.r[7] += c.r[8];  // 060160DC add r8,r7
    c.r[1] = ld32(c.r[6]);  // 060160DE mov.l @r6,r1
    c.r[7] <<= 2;  // 060160E0 shll2 r7
    c.r[1] += c.r[7];  // 060160E2 add r7,r1
    c.r[1] += 50;  // 060160E4 add #50,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060160E6 mov.b @r1,r1
    c.r[3] = c.r[1] & 0xFFu;  // 060160E8 extu.b r1,r3
    c.r[3] >>= 2;  // 060160EA shlr2 r3
    c.r[3] >>= 2;  // 060160EC shlr2 r3
    c.r[3] >>= 2;  // 060160EE shlr2 r3
    c.r[0] = c.r[3];  // 060160F0 mov r3,r0
    c.t = c.r[0] == 0x2u;  // 060160F2 cmp/eq #2,r0
    { const bool k = !c.t; c.r[4] = 0x0u; if (k) { goto L_06016110; } }  // 060160F4 bf/s 0x06016110 ; mov #0,r4
    c.r[4] = 0x1u;  // 060160F8 mov #1,r4
    c.r[1] = 0xFFFFFFEBu;  // 060160FA mov #-21,r1
    st8(c.r[14], c.r[1]);  // 060160FC mov.b r1,@r14
    c.r[2] = 0xFFFFFFEDu;  // 060160FE mov #-19,r2
    c.r[0] = c.r[14];  // 06016100 mov r14,r0
    st8(c.r[0] + c.r[4], c.r[2]);  // 06016102 mov.b r2,@(r0,r4)
    c.r[2] = 0x3u;  // 06016104 mov #3,r2
    st8(c.r[0] + c.r[3], c.r[1]);  // 06016106 mov.b r1,@(r0,r3)
    c.r[4] = 0x4u;  // 06016108 mov #4,r4
    c.r[1] = 0xFFFFFFEEu;  // 0601610A mov #-18,r1
    st8(c.r[0] + c.r[2], c.r[1]);  // 0601610C mov.b r1,@(r0,r2)
    st8(c.r[0] + c.r[4], c.r[5]);  // 0601610E mov.b r5,@(r0,r4)
L_06016110:
    c.r[1] = ld32(c.r[6]);  // 06016110 mov.l @r6,r1
    c.r[1] += c.r[7];  // 06016112 add r7,r1
    c.r[1] += 51;  // 06016114 add #51,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06016116 mov.b @r1,r1
    c.r[0] = 0x1u;  // 06016118 mov #1,r0
    c.r[1] >>= 2;  // 0601611A shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0601611C shlr r1
    c.r[1] >>= 2;  // 0601611E shlr2 r1
    c.r[1] &= c.r[0];  // 06016120 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06016122 tst r1,r1
    { const bool k = c.t; c.r[2] = c.r[4]; if (k) { goto L_06016142; } }  // 06016124 bt/s 0x06016142 ; mov r4,r2
    c.r[1] = c.r[4];  // 06016128 mov r4,r1
    c.r[1] += 1;  // 0601612A add #1,r1
    c.r[4] = c.r[1] & 0xFFu;  // 0601612C extu.b r1,r4
    c.r[3] = c.r[4];  // 0601612E mov r4,r3
    c.r[1] = 0xFFFFFFEBu;  // 06016130 mov #-21,r1
    c.r[0] = c.r[14];  // 06016132 mov r14,r0
    st8(c.r[0] + c.r[2], c.r[1]);  // 06016134 mov.b r1,@(r0,r2)
    c.r[1] = c.r[4];  // 06016136 mov r4,r1
    c.r[1] += 1;  // 06016138 add #1,r1
    c.r[4] = c.r[1] & 0xFFu;  // 0601613A extu.b r1,r4
    c.r[1] = 0xFFFFFFF0u;  // 0601613C mov #-16,r1
    st8(c.r[0] + c.r[3], c.r[1]);  // 0601613E mov.b r1,@(r0,r3)
    st8(c.r[0] + c.r[4], c.r[5]);  // 06016140 mov.b r5,@(r0,r4)
L_06016142:
    c.r[1] = ld32(c.r[6]);  // 06016142 mov.l @r6,r1
    c.r[1] += c.r[7];  // 06016144 add r7,r1
    c.r[1] += 51;  // 06016146 add #51,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06016148 mov.b @r1,r1
    c.r[0] = 0x1u;  // 0601614A mov #1,r0
    c.r[1] >>= 2;  // 0601614C shlr2 r1
    c.r[1] >>= 2;  // 0601614E shlr2 r1
    c.r[1] >>= 2;  // 06016150 shlr2 r1
    c.r[1] &= c.r[0];  // 06016152 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06016154 tst r1,r1
    { const bool k = c.t; c.r[2] = c.r[4]; if (k) { goto L_06016174; } }  // 06016156 bt/s 0x06016174 ; mov r4,r2
    c.r[1] = c.r[4];  // 0601615A mov r4,r1
    c.r[1] += 1;  // 0601615C add #1,r1
    c.r[4] = c.r[1] & 0xFFu;  // 0601615E extu.b r1,r4
    c.r[3] = c.r[4];  // 06016160 mov r4,r3
    c.r[1] = 0xFFFFFFEBu;  // 06016162 mov #-21,r1
    c.r[0] = c.r[14];  // 06016164 mov r14,r0
    st8(c.r[0] + c.r[2], c.r[1]);  // 06016166 mov.b r1,@(r0,r2)
    c.r[1] = c.r[4];  // 06016168 mov r4,r1
    c.r[1] += 1;  // 0601616A add #1,r1
    c.r[4] = c.r[1] & 0xFFu;  // 0601616C extu.b r1,r4
    c.r[1] = 0xFFFFFFEFu;  // 0601616E mov #-17,r1
    st8(c.r[0] + c.r[3], c.r[1]);  // 06016170 mov.b r1,@(r0,r3)
    st8(c.r[0] + c.r[4], c.r[5]);  // 06016172 mov.b r5,@(r0,r4)
L_06016174:
    c.r[1] = ld32(0x060161B4u);  // 06016174 mov.l 0x060161B4,r1
    c.r[6] = 0x0u;  // 06016176 mov #0,r6
    c.r[5] = c.r[14];  // 06016178 mov r14,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0601617Eu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601617Eu) return; }  // 0601617A jsr @r1 ; mov #0,r4
L_0601617E:
    c.r[7] = (uint32_t)(int16_t)ld16(0x060161A4u);  // 0601617E mov.w 0x060161A4,r7
    c.r[3] = ld32(0x060161C0u);  // 06016180 mov.l 0x060161C0,r3
    c.r[2] = ld32(c.r[3]);  // 06016182 mov.l @r3,r2
    c.r[1] = ld32(0x060161C4u);  // 06016184 mov.l 0x060161C4,r1
    c.r[2] += 1;  // 06016186 add #1,r2
    c.t = c.r[2] >= c.r[1];  // 06016188 cmp/hs r1,r2
    { const bool k = !c.t; st32(c.r[3], c.r[2]); if (k) { goto L_06016192; } }  // 0601618A bf/s 0x06016192 ; mov.l r2,@r3
    c.r[1] = ld32(0x060161C8u);  // 0601618E mov.l 0x060161C8,r1
    st32(c.r[3], c.r[1]);  // 06016190 mov.l r1,@r3
L_06016192:
    c.r[14] += 12;  // 06016192 add #12,r14
    c.r[1] = ld32(c.r[3]);  // 06016194 mov.l @r3,r1
    c.r[15] = c.r[14];  // 06016196 mov r14,r15
    st8(c.r[1], c.r[7]);  // 06016198 mov.b r7,@r1
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601619A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601619C mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0601619E mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060161A0 rts ; mov.l @r15+,r8
}

void f_060161CC(SH2Context& c) {
    ran[125] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060161CC mov.l r14,@-r15
    c.r[14] = c.r[15];  // 060161CE mov r15,r14
    c.r[2] = c.r[4] & 0xFFu;  // 060161D0 extu.b r4,r2
    c.r[6] = (uint32_t)(int16_t)ld16(0x06016220u);  // 060161D2 mov.w 0x06016220,r6
    c.r[3] = ld32(0x06016224u);  // 060161D4 mov.l 0x06016224,r3
    c.r[1] = ld32(c.r[3]);  // 060161D6 mov.l @r3,r1
    c.r[7] = ld32(0x06016228u);  // 060161D8 mov.l 0x06016228,r7
    c.r[1] += 1;  // 060161DA add #1,r1
    c.t = c.r[1] >= c.r[7];  // 060161DC cmp/hs r7,r1
    { const bool k = !c.t; st32(c.r[3], c.r[1]); if (k) { goto L_060161E6; } }  // 060161DE bf/s 0x060161E6 ; mov.l r1,@r3
    c.r[1] = ld32(0x0601622Cu);  // 060161E2 mov.l 0x0601622C,r1
    st32(c.r[3], c.r[1]);  // 060161E4 mov.l r1,@r3
L_060161E6:
    c.r[1] = ld32(c.r[3]);  // 060161E6 mov.l @r3,r1
    c.r[2] <<= 8;  // 060161E8 shll8 r2
    c.r[2] <<= 2;  // 060161EA shll2 r2
    c.r[2] <<= 2;  // 060161EC shll2 r2
    st8(c.r[1], c.r[6]);  // 060161EE mov.b r6,@r1
    c.r[1] = ld32(c.r[3]);  // 060161F0 mov.l @r3,r1
    c.r[4] = c.r[2] & 0xFFFFu;  // 060161F2 extu.w r2,r4
    c.r[1] += 1;  // 060161F4 add #1,r1
    c.t = c.r[1] >= c.r[7];  // 060161F6 cmp/hs r7,r1
    { const bool k = !c.t; st32(c.r[3], c.r[1]); if (k) { goto L_06016200; } }  // 060161F8 bf/s 0x06016200 ; mov.l r1,@r3
    c.r[1] = ld32(0x0601622Cu);  // 060161FC mov.l 0x0601622C,r1
    st32(c.r[3], c.r[1]);  // 060161FE mov.l r1,@r3
L_06016200:
    c.r[2] = c.r[4];  // 06016200 mov r4,r2
    c.r[1] = ld32(c.r[3]);  // 06016202 mov.l @r3,r1
    c.r[2] >>= 8;  // 06016204 shlr8 r2
    st8(c.r[1], c.r[2]);  // 06016206 mov.b r2,@r1
    c.r[1] = ld32(c.r[3]);  // 06016208 mov.l @r3,r1
    c.r[1] += 1;  // 0601620A add #1,r1
    c.t = c.r[1] >= c.r[7];  // 0601620C cmp/hs r7,r1
    { const bool k = !c.t; st32(c.r[3], c.r[1]); if (k) { goto L_06016216; } }  // 0601620E bf/s 0x06016216 ; mov.l r1,@r3
    c.r[1] = ld32(0x0601622Cu);  // 06016212 mov.l 0x0601622C,r1
    st32(c.r[3], c.r[1]);  // 06016214 mov.l r1,@r3
L_06016216:
    c.r[1] = ld32(c.r[3]);  // 06016216 mov.l @r3,r1
    c.r[15] = c.r[14];  // 06016218 mov r14,r15
    st8(c.r[1], c.r[4]);  // 0601621A mov.b r4,@r1
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601621C rts ; mov.l @r15+,r14
}

void f_06016238(SH2Context& c) {
    ran[126] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06016238 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0601623A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0601623C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0601623E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06016240 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06016242 sts.l pr,@-r15
    c.r[15] -= 44;  // 06016244 add #-44,r15
    c.r[14] = c.r[15];  // 06016246 mov r15,r14
    c.r[8] = c.r[4] & 0xFFu;  // 06016248 extu.b r4,r8
    c.r[11] = c.r[5] & 0xFFu;  // 0601624A extu.b r5,r11
    c.r[9] = c.r[14];  // 0601624C mov r14,r9
    c.r[10] = c.r[8];  // 0601624E mov r8,r10
    c.r[10] >>= 2;  // 06016250 shlr2 r10
    c.r[10] >>= 2;  // 06016252 shlr2 r10
    c.r[2] = c.r[14];  // 06016254 mov r14,r2
    c.r[2] += 20;  // 06016256 add #20,r2
    c.r[1] = 0x11u;  // 06016258 mov #17,r1
    st8(c.r[2], c.r[1]);  // 0601625A mov.b r1,@r2
    c.r[1] = c.r[14];  // 0601625C mov r14,r1
    c.r[1] += 21;  // 0601625E add #21,r1
    c.r[3] = 0xFFFFFFD0u;  // 06016260 mov #-48,r3
    st8(c.r[1], c.r[3]);  // 06016262 mov.b r3,@r1
    c.r[1] = c.r[14];  // 06016264 mov r14,r1
    c.r[1] += 22;  // 06016266 add #22,r1
    st8(c.r[1], c.r[3]);  // 06016268 mov.b r3,@r1
    c.r[1] = c.r[14];  // 0601626A mov r14,r1
    c.r[1] += 23;  // 0601626C add #23,r1
    c.r[7] = 0xFFFFFFD2u;  // 0601626E mov #-46,r7
    st8(c.r[1], c.r[7]);  // 06016270 mov.b r7,@r1
    c.r[1] = c.r[14];  // 06016272 mov r14,r1
    c.r[1] += 24;  // 06016274 add #24,r1
    st8(c.r[1], c.r[3]);  // 06016276 mov.b r3,@r1
    c.r[5] = c.r[14];  // 06016278 mov r14,r5
    c.r[5] += 28;  // 0601627A add #28,r5
    c.r[1] = 0x14u;  // 0601627C mov #20,r1
    st8(c.r[5], c.r[1]);  // 0601627E mov.b r1,@r5
    c.r[2] = c.r[14];  // 06016280 mov r14,r2
    c.r[2] += 29;  // 06016282 add #29,r2
    c.r[1] = 0xFFFFFFCFu;  // 06016284 mov #-49,r1
    st8(c.r[2], c.r[1]);  // 06016286 mov.b r1,@r2
    c.r[1] = c.r[14];  // 06016288 mov r14,r1
    c.r[1] += 30;  // 0601628A add #30,r1
    st8(c.r[1], c.r[3]);  // 0601628C mov.b r3,@r1
    c.r[1] = c.r[14];  // 0601628E mov r14,r1
    c.r[1] += 31;  // 06016290 add #31,r1
    st8(c.r[1], c.r[7]);  // 06016292 mov.b r7,@r1
    c.r[1] = c.r[14];  // 06016294 mov r14,r1
    c.r[1] += 32;  // 06016296 add #32,r1
    st8(c.r[1], c.r[3]);  // 06016298 mov.b r3,@r1
    c.r[3] = c.r[14];  // 0601629A mov r14,r3
    c.r[3] += 36;  // 0601629C add #36,r3
    c.r[2] = 0x79u;  // 0601629E mov #121,r2
    st8(c.r[3], c.r[2]);  // 060162A0 mov.b r2,@r3
    c.r[1] = c.r[14];  // 060162A2 mov r14,r1
    c.r[1] += 37;  // 060162A4 add #37,r1
    st8(c.r[1], c.r[2]);  // 060162A6 mov.b r2,@r1
    c.r[1] = c.r[14];  // 060162A8 mov r14,r1
    c.r[1] += 38;  // 060162AA add #38,r1
    st8(c.r[1], c.r[2]);  // 060162AC mov.b r2,@r1
    c.r[1] = c.r[14];  // 060162AE mov r14,r1
    c.r[1] += 39;  // 060162B0 add #39,r1
    st8(c.r[1], c.r[2]);  // 060162B2 mov.b r2,@r1
    c.r[1] = c.r[14];  // 060162B4 mov r14,r1
    c.r[1] += 40;  // 060162B6 add #40,r1
    st8(c.r[1], c.r[2]);  // 060162B8 mov.b r2,@r1
    c.r[2] = 0x8u;  // 060162BA mov #8,r2
    c.r[2] &= c.r[8];  // 060162BC and r8,r2
    c.r[0] = 0x7u;  // 060162BE mov #7,r0
    c.t = (c.r[10] & c.r[10]) == 0;  // 060162C0 tst r10,r10
    { const bool k = c.t; c.r[8] &= c.r[0]; if (k) { goto L_06016316; } }  // 060162C2 bt/s 0x06016316 ; and r0,r8
    c.t = (c.r[6] & c.r[6]) == 0;  // 060162C6 tst r6,r6
    { const bool k = c.t; c.r[0] = c.r[6]; if (k) { goto L_060162D4; } }  // 060162C8 bt/s 0x060162D4 ; mov r6,r0
    c.r[1] = 0xFFFFFFFDu;  // 060162CC mov #-3,r1
    c.t = c.r[6] > c.r[1];  // 060162CE cmp/hi r1,r6
    { const bool k = !c.t; c.t = (c.r[2] & c.r[2]) == 0; if (k) { goto L_06016318; } }  // 060162D0 bf/s 0x06016318 ; tst r2,r2
L_060162D4:
    c.t = c.r[0] == 0xFFFFFFFEu;  // 060162D4 cmp/eq #-2,r0
    { const bool k = c.t; c.r[2] = c.r[14]; if (k) { goto L_060162E4; } }  // 060162D6 bt/s 0x060162E4 ; mov r14,r2
    c.t = c.r[0] == 0xFFFFFFFFu;  // 060162DA cmp/eq #-1,r0
    { const bool k = c.t; c.r[0] = c.r[5]; if (k) { goto L_06016302; } }  // 060162DC bt/s 0x06016302 ; mov r5,r0
    c.r[1] = c.r[14]; goto L_060162FE;  // 060162E0 bra 0x060162FE ; mov r14,r1
L_060162E4:
    c.r[0] = c.r[3];  // 060162E4 mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 060162E6 mov.b @(r0,r8),r1
    st8(c.r[14], c.r[1]);  // 060162E8 mov.b r1,@r14
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 060162EA mov.b @(r0,r8),r1
    c.r[2] += 1;  // 060162EC add #1,r2
    c.r[1] += 1;  // 060162EE add #1,r1
    st8(c.r[2], c.r[1]);  // 060162F0 mov.b r1,@r2
    c.r[2] = c.r[14];  // 060162F2 mov r14,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 060162F4 mov.b @(r0,r8),r1
    c.r[2] += 2;  // 060162F6 add #2,r2
    c.r[1] += 2;  // 060162F8 add #2,r1
    st8(c.r[2], c.r[1]); goto L_0601630E;  // 060162FA bra 0x0601630E ; mov.b r1,@r2
L_060162FE:
    c.r[1] += 20;  // 060162FE add #20,r1
    c.r[0] = c.r[1];  // 06016300 mov r1,r0
L_06016302:
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 06016302 mov.b @(r0,r8),r5
    c.r[6] = c.r[10];  // 06016304 mov r10,r6
    c.r[4] = c.r[14];  // 06016306 mov r14,r4
    c.r[0] = ld32(0x06016370u);  // 06016308 mov.l 0x06016370,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601630Eu; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601630Eu) return; }  // 0601630A jsr @r0 ; extu.b r5,r5
L_0601630E:
    c.r[1] = 0x0u;  // 0601630E mov #0,r1
    c.r[0] = c.r[14];  // 06016310 mov r14,r0
    st8(c.r[0] + c.r[10], c.r[1]); goto L_06016330;  // 06016312 bra 0x06016330 ; mov.b r1,@(r0,r10)
L_06016316:
    c.t = (c.r[2] & c.r[2]) == 0;  // 06016316 tst r2,r2
L_06016318:
    if (c.t) { goto L_06016320; }  // 06016318 bt 0x06016320
    c.r[5] = ld32(0x06016374u);  // 0601631A mov.l 0x06016374,r5
    goto L_06016322;  // 0601631C bra 0x06016322 ; nop
L_06016320:
    c.r[5] = ld32(0x06016378u);  // 06016320 mov.l 0x06016378,r5
L_06016322:
    c.r[0] = ld32(0x0601637Cu);  // 06016322 mov.l 0x0601637C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06016328u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06016328u) return; }  // 06016324 jsr @r0 ; mov r14,r4
    c.r[1] = ld32(0x06016380u);  // 06016328 mov.l 0x06016380,r1
    c.r[5] = c.r[14];  // 0601632A mov r14,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06016330u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06016330u) return; }  // 0601632C jsr @r1 ; mov r8,r4
L_06016330:
    c.r[10] = 0x3Fu;  // 06016330 mov #63,r10
    c.r[10] &= c.r[11];  // 06016332 and r11,r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06016334 mov.b @r9,r1
    c.r[11] >>= 2;  // 06016336 shlr2 r11
    c.r[11] >>= 2;  // 06016338 shlr2 r11
    c.r[11] >>= 2;  // 0601633A shlr2 r11
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601633C tst r1,r1
    { const bool k = c.t; c.r[1] = 0xFFFFFFFFu; if (k) { goto L_06016350; } }  // 0601633E bt/s 0x06016350 ; mov #-1,r1
    c.r[9] += 1;  // 06016342 add #1,r9
L_06016344:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06016344 mov.b @r9,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06016346 tst r1,r1
    { const bool k = !c.t; c.r[9] += 1; if (k) { SH2_POLL(c); goto L_06016344; } }  // 06016348 bf/s 0x06016344 ; add #1,r9
    c.r[9] -= 1;  // 0601634C add #-1,r9
    c.r[1] = 0xFFFFFFFFu;  // 0601634E mov #-1,r1
L_06016350:
    st8(c.r[9], c.r[1]);  // 06016350 mov.b r1,@r9
    c.r[1] = ld32(0x06016384u);  // 06016352 mov.l 0x06016384,r1
    c.r[6] = c.r[10];  // 06016354 mov r10,r6
    c.r[5] = c.r[14];  // 06016356 mov r14,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0601635Cu; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601635Cu) return; }  // 06016358 jsr @r1 ; mov r11,r4
    c.r[14] += 44;  // 0601635C add #44,r14
    c.r[15] = c.r[14];  // 0601635E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06016360 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06016362 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06016364 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06016366 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06016368 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601636A rts ; mov.l @r15+,r8
}

void f_06016388(SH2Context& c) {
    ran[127] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06016388 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0601638A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0601638C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0601638E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06016390 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06016392 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06016394 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06016396 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06016398 mov r15,r14
    c.r[9] = c.r[5];  // 0601639A mov r5,r9
    c.r[3] = c.r[4] & 0xFFu;  // 0601639C extu.b r4,r3
    c.r[11] = 0x0u;  // 0601639E mov #0,r11
    c.r[8] = ld32(0x06016408u);  // 060163A0 mov.l 0x06016408,r8
    c.r[10] = ld32(c.r[8]);  // 060163A2 mov.l @r8,r10
    c.r[12] = (uint32_t)(int16_t)ld16(0x06016406u);  // 060163A4 mov.w 0x06016406,r12
    c.r[12] &= c.r[3];  // 060163A6 and r3,r12
    c.r[0] = c.r[3];  // 060163A8 mov r3,r0
    c.r[0] &= 0x3u;  // 060163AA and #3,r0
    c.r[3] = c.r[0];  // 060163AC mov r0,r3
    c.t = c.r[0] == 0x2u;  // 060163AE cmp/eq #2,r0
    { const bool k = c.t; c.r[10] += 1; if (k) { goto L_06016418; } }  // 060163B0 bt/s 0x06016418 ; add #1,r10
    c.r[1] = 0x2u;  // 060163B4 mov #2,r1
    c.t = (int32_t)c.r[0] > (int32_t)c.r[1];  // 060163B6 cmp/gt r1,r0
    { const bool k = c.t; c.t = c.r[0] == 0x3u; if (k) { goto L_060163C6; } }  // 060163B8 bt/s 0x060163C6 ; cmp/eq #3,r0
    c.t = c.r[0] == 0x1u;  // 060163BC cmp/eq #1,r0
    { const bool k = c.t; c.t = (int32_t)c.r[9] >= 0; if (k) { goto L_060163D2; } }  // 060163BE bt/s 0x060163D2 ; cmp/pz r9
    c.t = (c.r[9] & c.r[9]) == 0; goto L_06016552;  // 060163C2 bra 0x06016552 ; tst r9,r9
L_060163C6:
    { const bool k = !c.t; c.t = (c.r[9] & c.r[9]) == 0; if (k) { goto L_060163CE; } }  // 060163C6 bf/s 0x060163CE ; tst r9,r9
    goto L_060164FC;  // 060163CA bra 0x060164FC ; nop
L_060163CE:
    goto L_06016552;  // 060163CE bra 0x06016552 ; nop
L_060163D2:
    if (c.t) { goto L_060163D6; }  // 060163D2 bt 0x060163D6
    c.r[11] = c.r[0];  // 060163D4 mov r0,r11
L_060163D6:
    c.t = (c.r[9] & c.r[9]) == 0;  // 060163D6 tst r9,r9
    { const bool k = !c.t; c.r[11] -= 49; if (k) { goto L_060163E0; } }  // 060163D8 bf/s 0x060163E0 ; add #-49,r11
    goto L_0601652E;  // 060163DC bra 0x0601652E ; nop
L_060163E0:
    c.r[2] = c.r[11] & 0xFFu;  // 060163E0 extu.b r11,r2
    c.r[1] = ld32(0x0601640Cu);  // 060163E2 mov.l 0x0601640C,r1
    c.t = c.r[10] >= c.r[1];  // 060163E4 cmp/hs r1,r10
    { const bool k = !c.t; st32(c.r[8], c.r[10]); if (k) { goto L_060163EE; } }  // 060163E6 bf/s 0x060163EE ; mov.l r10,@r8
    c.r[1] = ld32(0x06016410u);  // 060163EA mov.l 0x06016410,r1
    st32(c.r[8], c.r[1]);  // 060163EC mov.l r1,@r8
L_060163EE:
    c.r[1] = ld32(c.r[8]);  // 060163EE mov.l @r8,r1
    c.r[6] = c.r[9];  // 060163F0 mov r9,r6
    c.t = (int32_t)c.r[9] >= 0;  // 060163F2 cmp/pz r9
    { const bool k = c.t; st8(c.r[1], c.r[2]); if (k) { goto L_060163FA; } }  // 060163F4 bt/s 0x060163FA ; mov.b r2,@r1
    c.r[6] = 0u - c.r[9];  // 060163F8 neg r9,r6
L_060163FA:
    c.r[1] = ld32(0x06016414u);  // 060163FA mov.l 0x06016414,r1
    c.r[5] = 0x0u;  // 060163FC mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06016402u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06016402u) return; }  // 060163FE jsr @r1 ; mov r0,r4
    c.r[15] = c.r[14]; goto L_060165A6;  // 06016402 bra 0x060165A6 ; mov r14,r15
L_06016418:
    c.r[2] = (uint32_t)(int16_t)ld16(0x060164ECu);  // 06016418 mov.w 0x060164EC,r2
    c.r[12] = ld32(0x060164F0u);  // 0601641A mov.l 0x060164F0,r12
    c.t = c.r[10] >= c.r[12];  // 0601641C cmp/hs r12,r10
    { const bool k = !c.t; st32(c.r[8], c.r[10]); if (k) { goto L_06016426; } }  // 0601641E bf/s 0x06016426 ; mov.l r10,@r8
    c.r[1] = ld32(0x060164F4u);  // 06016422 mov.l 0x060164F4,r1
    st32(c.r[8], c.r[1]);  // 06016424 mov.l r1,@r8
L_06016426:
    c.r[1] = ld32(c.r[8]);  // 06016426 mov.l @r8,r1
    st8(c.r[1], c.r[2]);  // 06016428 mov.b r2,@r1
    c.r[1] = ld32(c.r[8]);  // 0601642A mov.l @r8,r1
    c.r[7] = (uint32_t)(int16_t)ld16(0x060164EEu);  // 0601642C mov.w 0x060164EE,r7
    c.r[1] += 1;  // 0601642E add #1,r1
    c.t = c.r[1] >= c.r[12];  // 06016430 cmp/hs r12,r1
    { const bool k = !c.t; st32(c.r[8], c.r[1]); if (k) { goto L_0601643A; } }  // 06016432 bf/s 0x0601643A ; mov.l r1,@r8
    c.r[1] = ld32(0x060164F4u);  // 06016436 mov.l 0x060164F4,r1
    st32(c.r[8], c.r[1]);  // 06016438 mov.l r1,@r8
L_0601643A:
    c.r[1] = ld32(c.r[8]);  // 0601643A mov.l @r8,r1
    c.r[2] = 0x10u;  // 0601643C mov #16,r2
    st8(c.r[1], c.r[2]);  // 0601643E mov.b r2,@r1
    c.r[1] = ld32(c.r[8]);  // 06016440 mov.l @r8,r1
    c.r[1] += 1;  // 06016442 add #1,r1
    c.t = c.r[1] >= c.r[12];  // 06016444 cmp/hs r12,r1
    { const bool k = !c.t; st32(c.r[8], c.r[1]); if (k) { goto L_0601644E; } }  // 06016446 bf/s 0x0601644E ; mov.l r1,@r8
    c.r[1] = ld32(0x060164F4u);  // 0601644A mov.l 0x060164F4,r1
    st32(c.r[8], c.r[1]);  // 0601644C mov.l r1,@r8
L_0601644E:
    c.r[1] = ld32(c.r[8]);  // 0601644E mov.l @r8,r1
    c.t = (int32_t)c.r[9] >= 0;  // 06016450 cmp/pz r9
    { const bool k = c.t; st8(c.r[1], c.r[7]); if (k) { goto L_06016458; } }  // 06016452 bt/s 0x06016458 ; mov.b r7,@r1
    c.r[11] = c.r[0];  // 06016456 mov r0,r11
L_06016458:
    c.t = (c.r[9] & c.r[9]) == 0;  // 06016458 tst r9,r9
    { const bool k = c.t; c.r[1] = c.r[11]; if (k) { goto L_060164AC; } }  // 0601645A bt/s 0x060164AC ; mov r11,r1
    c.r[1] -= 49;  // 0601645E add #-49,r1
    c.r[2] = c.r[1] & 0xFFu;  // 06016460 extu.b r1,r2
    c.r[1] = ld32(c.r[8]);  // 06016462 mov.l @r8,r1
    c.r[1] += 1;  // 06016464 add #1,r1
    c.t = c.r[1] >= c.r[12];  // 06016466 cmp/hs r12,r1
    { const bool k = !c.t; st32(c.r[8], c.r[1]); if (k) { goto L_06016470; } }  // 06016468 bf/s 0x06016470 ; mov.l r1,@r8
    c.r[1] = ld32(0x060164F4u);  // 0601646C mov.l 0x060164F4,r1
    st32(c.r[8], c.r[1]);  // 0601646E mov.l r1,@r8
L_06016470:
    c.r[1] = ld32(c.r[8]);  // 06016470 mov.l @r8,r1
    c.r[6] = c.r[9];  // 06016472 mov r9,r6
    c.t = (int32_t)c.r[9] >= 0;  // 06016474 cmp/pz r9
    { const bool k = c.t; st8(c.r[1], c.r[2]); if (k) { goto L_0601647C; } }  // 06016476 bt/s 0x0601647C ; mov.b r2,@r1
    c.r[6] = 0u - c.r[9];  // 0601647A neg r9,r6
L_0601647C:
    c.r[10] = ld32(0x060164F8u);  // 0601647C mov.l 0x060164F8,r10
    c.r[5] = 0x0u;  // 0601647E mov #0,r5
    { const uint32_t x = c.r[10]; c.pr = 0x06016484u; c.r[4] = c.r[3]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06016484u) return; }  // 06016480 jsr @r10 ; mov r3,r4
    c.r[11] -= 48;  // 06016484 add #-48,r11
    c.r[1] = ld32(c.r[8]);  // 06016486 mov.l @r8,r1
    c.r[2] = c.r[11] & 0xFFu;  // 06016488 extu.b r11,r2
    c.r[1] += 1;  // 0601648A add #1,r1
    c.t = c.r[1] >= c.r[12];  // 0601648C cmp/hs r12,r1
    { const bool k = !c.t; st32(c.r[8], c.r[1]); if (k) { goto L_06016496; } }  // 0601648E bf/s 0x06016496 ; mov.l r1,@r8
    c.r[1] = ld32(0x060164F4u);  // 06016492 mov.l 0x060164F4,r1
    st32(c.r[8], c.r[1]);  // 06016494 mov.l r1,@r8
L_06016496:
    c.r[1] = ld32(c.r[8]);  // 06016496 mov.l @r8,r1
    c.r[6] = c.r[9];  // 06016498 mov r9,r6
    c.t = (int32_t)c.r[9] >= 0;  // 0601649A cmp/pz r9
    { const bool k = c.t; st8(c.r[1], c.r[2]); if (k) { goto L_060164A2; } }  // 0601649C bt/s 0x060164A2 ; mov.b r2,@r1
    c.r[6] = 0u - c.r[9];  // 060164A0 neg r9,r6
L_060164A2:
    c.r[5] = 0x0u;  // 060164A2 mov #0,r5
    { const uint32_t x = c.r[10]; c.pr = 0x060164A8u; c.r[4] = 0x3u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060164A8u) return; }  // 060164A4 jsr @r10 ; mov #3,r4
    c.r[15] = c.r[14]; goto L_060165A6;  // 060164A8 bra 0x060165A6 ; mov r14,r15
L_060164AC:
    c.r[1] = ld32(c.r[8]);  // 060164AC mov.l @r8,r1
    c.r[1] += 1;  // 060164AE add #1,r1
    c.t = c.r[1] >= c.r[12];  // 060164B0 cmp/hs r12,r1
    { const bool k = !c.t; st32(c.r[8], c.r[1]); if (k) { goto L_060164BA; } }  // 060164B2 bf/s 0x060164BA ; mov.l r1,@r8
    c.r[1] = ld32(0x060164F4u);  // 060164B6 mov.l 0x060164F4,r1
    st32(c.r[8], c.r[1]);  // 060164B8 mov.l r1,@r8
L_060164BA:
    c.r[1] = ld32(c.r[8]);  // 060164BA mov.l @r8,r1
    st8(c.r[1], c.r[9]);  // 060164BC mov.b r9,@r1
    c.r[1] = ld32(c.r[8]);  // 060164BE mov.l @r8,r1
    c.r[1] += 1;  // 060164C0 add #1,r1
    c.t = c.r[1] >= c.r[12];  // 060164C2 cmp/hs r12,r1
    { const bool k = !c.t; st32(c.r[8], c.r[1]); if (k) { goto L_060164CC; } }  // 060164C4 bf/s 0x060164CC ; mov.l r1,@r8
    c.r[1] = ld32(0x060164F4u);  // 060164C8 mov.l 0x060164F4,r1
    st32(c.r[8], c.r[1]);  // 060164CA mov.l r1,@r8
L_060164CC:
    c.r[1] = ld32(c.r[8]);  // 060164CC mov.l @r8,r1
    st8(c.r[1], c.r[9]);  // 060164CE mov.b r9,@r1
    c.r[1] = ld32(c.r[8]);  // 060164D0 mov.l @r8,r1
    c.r[1] += 1;  // 060164D2 add #1,r1
    c.t = c.r[1] >= c.r[12];  // 060164D4 cmp/hs r12,r1
    { const bool k = !c.t; st32(c.r[8], c.r[1]); if (k) { goto L_060164DE; } }  // 060164D6 bf/s 0x060164DE ; mov.l r1,@r8
    c.r[1] = ld32(0x060164F4u);  // 060164DA mov.l 0x060164F4,r1
    st32(c.r[8], c.r[1]);  // 060164DC mov.l r1,@r8
L_060164DE:
    c.r[1] = ld32(c.r[8]);  // 060164DE mov.l @r8,r1
    st8(c.r[1], c.r[9]);  // 060164E0 mov.b r9,@r1
    c.r[1] = ld32(c.r[8]);  // 060164E2 mov.l @r8,r1
    c.r[1] += 1;  // 060164E4 add #1,r1
    st32(c.r[8], c.r[1]);  // 060164E6 mov.l r1,@r8
    c.t = c.r[1] >= c.r[12]; goto L_06016546;  // 060164E8 bra 0x06016546 ; cmp/hs r12,r1
L_060164FC:
    c.t = (int32_t)c.r[9] >= 0;  // 060164FC cmp/pz r9
    if (c.t) { goto L_06016502; }  // 060164FE bt 0x06016502
    c.r[11] = 0x1u;  // 06016500 mov #1,r11
L_06016502:
    c.t = (c.r[9] & c.r[9]) == 0;  // 06016502 tst r9,r9
    { const bool k = c.t; c.r[11] -= 49; if (k) { goto L_0601652E; } }  // 06016504 bt/s 0x0601652E ; add #-49,r11
    c.r[2] = c.r[11] & 0xFFu;  // 06016508 extu.b r11,r2
    c.r[1] = ld32(0x060165BCu);  // 0601650A mov.l 0x060165BC,r1
    c.t = c.r[10] >= c.r[1];  // 0601650C cmp/hs r1,r10
    { const bool k = !c.t; st32(c.r[8], c.r[10]); if (k) { goto L_06016516; } }  // 0601650E bf/s 0x06016516 ; mov.l r10,@r8
    c.r[1] = ld32(0x060165C0u);  // 06016512 mov.l 0x060165C0,r1
    st32(c.r[8], c.r[1]);  // 06016514 mov.l r1,@r8
L_06016516:
    c.r[1] = ld32(c.r[8]);  // 06016516 mov.l @r8,r1
    c.r[6] = c.r[9];  // 06016518 mov r9,r6
    c.t = (int32_t)c.r[9] >= 0;  // 0601651A cmp/pz r9
    { const bool k = c.t; st8(c.r[1], c.r[2]); if (k) { goto L_06016522; } }  // 0601651C bt/s 0x06016522 ; mov.b r2,@r1
    c.r[6] = 0u - c.r[9];  // 06016520 neg r9,r6
L_06016522:
    c.r[1] = ld32(0x060165C4u);  // 06016522 mov.l 0x060165C4,r1
    c.r[5] = 0x0u;  // 06016524 mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0601652Au; c.r[4] = 0x4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601652Au) return; }  // 06016526 jsr @r1 ; mov #4,r4
    c.r[15] = c.r[14]; goto L_060165A6;  // 0601652A bra 0x060165A6 ; mov r14,r15
L_0601652E:
    c.r[2] = ld32(0x060165BCu);  // 0601652E mov.l 0x060165BC,r2
    c.t = c.r[10] >= c.r[2];  // 06016530 cmp/hs r2,r10
    { const bool k = !c.t; st32(c.r[8], c.r[10]); if (k) { goto L_0601653A; } }  // 06016532 bf/s 0x0601653A ; mov.l r10,@r8
    c.r[1] = ld32(0x060165C0u);  // 06016536 mov.l 0x060165C0,r1
    st32(c.r[8], c.r[1]);  // 06016538 mov.l r1,@r8
L_0601653A:
    c.r[1] = ld32(c.r[8]);  // 0601653A mov.l @r8,r1
    st8(c.r[1], c.r[9]);  // 0601653C mov.b r9,@r1
    c.r[1] = ld32(c.r[8]);  // 0601653E mov.l @r8,r1
    c.r[1] += 1;  // 06016540 add #1,r1
    st32(c.r[8], c.r[1]);  // 06016542 mov.l r1,@r8
    c.t = c.r[1] >= c.r[2];  // 06016544 cmp/hs r2,r1
L_06016546:
    if (!c.t) { goto L_0601654C; }  // 06016546 bf 0x0601654C
    c.r[1] = ld32(0x060165C0u);  // 06016548 mov.l 0x060165C0,r1
    st32(c.r[8], c.r[1]);  // 0601654A mov.l r1,@r8
L_0601654C:
    c.r[1] = ld32(c.r[8]);  // 0601654C mov.l @r8,r1
    st8(c.r[1], c.r[9]); goto L_060165A4;  // 0601654E bra 0x060165A4 ; mov.b r9,@r1
L_06016552:
    { const bool k = !c.t; c.r[1] = 0x40u; if (k) { goto L_0601655C; } }  // 06016552 bf/s 0x0601655C ; mov #64,r1
    c.r[1] &= c.r[12];  // 06016556 and r12,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06016558 tst r1,r1
    if (c.t) { goto L_06016566; }  // 0601655A bt 0x06016566
L_0601655C:
    c.t = (int32_t)c.r[9] >= 0;  // 0601655C cmp/pz r9
    { const bool k = c.t; c.r[7] = 0x10u; if (k) { goto L_06016568; } }  // 0601655E bt/s 0x06016568 ; mov #16,r7
    c.r[7] = 0x11u; goto L_06016568;  // 06016562 bra 0x06016568 ; mov #17,r7
L_06016566:
    c.r[7] = (uint32_t)(int16_t)ld16(0x060165B8u);  // 06016566 mov.w 0x060165B8,r7
L_06016568:
    c.r[3] = ld32(0x060165C8u);  // 06016568 mov.l 0x060165C8,r3
    c.r[2] = ld32(c.r[3]);  // 0601656A mov.l @r3,r2
    c.r[1] = ld32(0x060165BCu);  // 0601656C mov.l 0x060165BC,r1
    c.r[2] += 1;  // 0601656E add #1,r2
    c.t = c.r[2] >= c.r[1];  // 06016570 cmp/hs r1,r2
    { const bool k = !c.t; st32(c.r[3], c.r[2]); if (k) { goto L_0601657A; } }  // 06016572 bf/s 0x0601657A ; mov.l r2,@r3
    c.r[1] = ld32(0x060165C0u);  // 06016576 mov.l 0x060165C0,r1
    st32(c.r[3], c.r[1]);  // 06016578 mov.l r1,@r3
L_0601657A:
    c.r[1] = ld32(c.r[3]);  // 0601657A mov.l @r3,r1
    c.r[5] = c.r[9];  // 0601657C mov r9,r5
    c.t = (int32_t)c.r[5] >= 0;  // 0601657E cmp/pz r5
    { const bool k = c.t; st8(c.r[1], c.r[7]); if (k) { goto L_06016586; } }  // 06016580 bt/s 0x06016586 ; mov.b r7,@r1
    c.r[5] = 0u - c.r[5];  // 06016584 neg r5,r5
L_06016586:
    c.r[1] = ld32(0x060165C4u);  // 06016586 mov.l 0x060165C4,r1
    c.r[6] = c.r[5];  // 06016588 mov r5,r6
    c.r[5] = 0x0u;  // 0601658A mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06016590u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06016590u) return; }  // 0601658C jsr @r1 ; mov #0,r4
    c.r[13] = (uint32_t)(int16_t)ld16(0x060165BAu);  // 06016590 mov.w 0x060165BA,r13
    c.r[12] &= c.r[13];  // 06016592 and r13,r12
    c.t = (c.r[12] & c.r[12]) == 0;  // 06016594 tst r12,r12
    { const bool k = c.t; c.r[1] = c.r[10]; if (k) { goto L_060165A4; } }  // 06016596 bt/s 0x060165A4 ; mov r10,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0601659A mov.b @r1+,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601659C mov.b @r1,r2
    c.r[2] += 1;  // 0601659E add #1,r2
    st8(c.r[10], c.r[2]);  // 060165A0 mov.b r2,@r10
    st8(c.r[1], c.r[3]);  // 060165A2 mov.b r3,@r1
L_060165A4:
    c.r[15] = c.r[14];  // 060165A4 mov r14,r15
L_060165A6:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060165A6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060165A8 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060165AA mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060165AC mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060165AE mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060165B0 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060165B2 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060165B4 rts ; mov.l @r15+,r8
}

void f_060165CC(SH2Context& c) {
    ran[128] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060165CC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060165CE mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060165D0 sts.l pr,@-r15
    c.r[6] = c.r[4] & 0xFFu;  // 060165D2 extu.b r4,r6
    c.r[8] = c.r[5] & 0xFFu;  // 060165D4 extu.b r5,r8
    c.t = c.r[6] == c.r[8];  // 060165D6 cmp/eq r8,r6
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_060165FC; } }  // 060165D8 bt/s 0x060165FC ; mov r15,r14
    c.r[1] = ld32(0x06016684u);  // 060165DC mov.l 0x06016684,r1
    c.r[5] = 0x0u;  // 060165DE mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x060165E4u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060165E4u) return; }  // 060165E0 jsr @r1 ; mov #0,r4
    c.r[7] = 0x13u;  // 060165E4 mov #19,r7
    c.r[3] = ld32(0x06016688u);  // 060165E6 mov.l 0x06016688,r3
    c.r[2] = ld32(c.r[3]);  // 060165E8 mov.l @r3,r2
    c.r[1] = ld32(0x0601668Cu);  // 060165EA mov.l 0x0601668C,r1
    c.r[2] += 1;  // 060165EC add #1,r2
    c.t = c.r[2] >= c.r[1];  // 060165EE cmp/hs r1,r2
    { const bool k = !c.t; st32(c.r[3], c.r[2]); if (k) { goto L_060165F8; } }  // 060165F0 bf/s 0x060165F8 ; mov.l r2,@r3
    c.r[1] = ld32(0x06016690u);  // 060165F4 mov.l 0x06016690,r1
    st32(c.r[3], c.r[1]);  // 060165F6 mov.l r1,@r3
L_060165F8:
    c.r[1] = ld32(c.r[3]); goto L_06016624;  // 060165F8 bra 0x06016624 ; mov.l @r3,r1
L_060165FC:
    c.r[7] = 0x0u;  // 060165FC mov #0,r7
    c.r[2] = ld32(0x06016688u);  // 060165FE mov.l 0x06016688,r2
    c.r[1] = ld32(c.r[2]);  // 06016600 mov.l @r2,r1
    c.r[3] = ld32(0x0601668Cu);  // 06016602 mov.l 0x0601668C,r3
    c.r[1] += 1;  // 06016604 add #1,r1
    c.t = c.r[1] >= c.r[3];  // 06016606 cmp/hs r3,r1
    { const bool k = !c.t; st32(c.r[2], c.r[1]); if (k) { goto L_06016610; } }  // 06016608 bf/s 0x06016610 ; mov.l r1,@r2
    c.r[1] = ld32(0x06016690u);  // 0601660C mov.l 0x06016690,r1
    st32(c.r[2], c.r[1]);  // 0601660E mov.l r1,@r2
L_06016610:
    c.r[1] = ld32(c.r[2]);  // 06016610 mov.l @r2,r1
    st8(c.r[1], c.r[7]);  // 06016612 mov.b r7,@r1
    c.r[1] = ld32(c.r[2]);  // 06016614 mov.l @r2,r1
    c.r[1] += 1;  // 06016616 add #1,r1
    c.t = c.r[1] >= c.r[3];  // 06016618 cmp/hs r3,r1
    { const bool k = !c.t; st32(c.r[2], c.r[1]); if (k) { goto L_06016622; } }  // 0601661A bf/s 0x06016622 ; mov.l r1,@r2
    c.r[1] = ld32(0x06016690u);  // 0601661E mov.l 0x06016690,r1
    st32(c.r[2], c.r[1]);  // 06016620 mov.l r1,@r2
L_06016622:
    c.r[1] = ld32(c.r[2]);  // 06016622 mov.l @r2,r1
L_06016624:
    c.r[0] = c.r[8];  // 06016624 mov r8,r0
    c.t = c.r[0] == 0x63u;  // 06016626 cmp/eq #99,r0
    { const bool k = !c.t; st8(c.r[1], c.r[7]); if (k) { goto L_0601666E; } }  // 06016628 bf/s 0x0601666E ; mov.b r7,@r1
    c.r[2] = 0x2u;  // 0601662C mov #2,r2
    c.r[3] = ld32(0x06016688u);  // 0601662E mov.l 0x06016688,r3
    c.r[1] = ld32(c.r[3]);  // 06016630 mov.l @r3,r1
    c.r[7] = ld32(0x0601668Cu);  // 06016632 mov.l 0x0601668C,r7
    c.r[1] += 1;  // 06016634 add #1,r1
    c.t = c.r[1] >= c.r[7];  // 06016636 cmp/hs r7,r1
    { const bool k = !c.t; st32(c.r[3], c.r[1]); if (k) { goto L_06016640; } }  // 06016638 bf/s 0x06016640 ; mov.l r1,@r3
    c.r[1] = ld32(0x06016690u);  // 0601663C mov.l 0x06016690,r1
    st32(c.r[3], c.r[1]);  // 0601663E mov.l r1,@r3
L_06016640:
    c.r[1] = ld32(c.r[3]);  // 06016640 mov.l @r3,r1
    st8(c.r[1], c.r[2]);  // 06016642 mov.b r2,@r1
    c.r[1] = ld32(c.r[3]);  // 06016644 mov.l @r3,r1
    c.r[6] = ld32(0x06016694u);  // 06016646 mov.l 0x06016694,r6
    c.r[1] += 1;  // 06016648 add #1,r1
    c.t = c.r[1] >= c.r[7];  // 0601664A cmp/hs r7,r1
    { const bool k = !c.t; st32(c.r[3], c.r[1]); if (k) { goto L_06016654; } }  // 0601664C bf/s 0x06016654 ; mov.l r1,@r3
    c.r[1] = ld32(0x06016690u);  // 06016650 mov.l 0x06016690,r1
    st32(c.r[3], c.r[1]);  // 06016652 mov.l r1,@r3
L_06016654:
    c.r[1] = ld32(c.r[3]);  // 06016654 mov.l @r3,r1
    c.r[2] = 0xFFFFFFF2u;  // 06016656 mov #-14,r2
    st8(c.r[1], c.r[2]);  // 06016658 mov.b r2,@r1
    c.r[1] = ld32(c.r[3]);  // 0601665A mov.l @r3,r1
    c.r[1] += 1;  // 0601665C add #1,r1
    c.t = c.r[1] >= c.r[7];  // 0601665E cmp/hs r7,r1
    { const bool k = !c.t; st32(c.r[3], c.r[1]); if (k) { goto L_06016668; } }  // 06016660 bf/s 0x06016668 ; mov.l r1,@r3
    c.r[1] = ld32(0x06016690u);  // 06016664 mov.l 0x06016690,r1
    st32(c.r[3], c.r[1]);  // 06016666 mov.l r1,@r3
L_06016668:
    c.r[1] = ld32(c.r[3]);  // 06016668 mov.l @r3,r1
    st8(c.r[1], c.r[6]); goto L_06016678;  // 0601666A bra 0x06016678 ; mov.b r6,@r1
L_0601666E:
    c.r[1] = ld32(0x06016684u);  // 0601666E mov.l 0x06016684,r1
    c.r[6] = c.r[8];  // 06016670 mov r8,r6
    c.r[5] = 0x0u;  // 06016672 mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06016678u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06016678u) return; }  // 06016674 jsr @r1 ; mov #0,r4
L_06016678:
    c.r[15] = c.r[14];  // 06016678 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601667A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601667C mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601667E rts ; mov.l @r15+,r8
}

void f_06016698(SH2Context& c) {
    ran[129] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06016698 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0601669A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601669C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601669E sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060166A0 mov r15,r14
    c.r[9] = c.r[4];  // 060166A2 mov r4,r9
    c.r[8] = c.r[5];  // 060166A4 mov r5,r8
    c.r[6] = c.r[6] & 0xFFu;  // 060166A6 extu.b r6,r6
    c.macl = c.r[6] * c.r[9];  // 060166A8 mul.l r9,r6
    c.r[1] = ld32(0x06016764u);  // 060166AA mov.l 0x06016764,r1
    c.r[2] = 0x0u;  // 060166AC mov #0,r2
    { const uint32_t x = c.r[1]; c.pr = 0x060166B2u; c.r[4] = c.macl; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060166B2u) return; }  // 060166AE jsr @r1 ; sts macl,r4
    c.r[7] = c.r[0] & 0xFFu;  // 060166B2 extu.b r0,r7
    c.t = c.r[2] >= c.r[7];  // 060166B4 cmp/hs r7,r2
    { const bool k = c.t; c.t = c.r[7] == c.r[6]; if (k) { goto L_060166DE; } }  // 060166B6 bt/s 0x060166DE ; cmp/eq r6,r7
    c.r[0] = 0x70u;  // 060166BA mov #112,r0
    c.r[3] = ld32(0x06016768u);  // 060166BC mov.l 0x06016768,r3
    c.r[4] = ld32(0x0601676Cu);  // 060166BE mov.l 0x0601676C,r4
    c.r[5] = ld32(0x06016770u);  // 060166C0 mov.l 0x06016770,r5
L_060166C2:
    c.r[1] = ld32(c.r[3]);  // 060166C2 mov.l @r3,r1
    c.r[1] += 1;  // 060166C4 add #1,r1
    c.t = c.r[1] >= c.r[4];  // 060166C6 cmp/hs r4,r1
    { const bool k = !c.t; st32(c.r[3], c.r[1]); if (k) { goto L_060166CE; } }  // 060166C8 bf/s 0x060166CE ; mov.l r1,@r3
    st32(c.r[3], c.r[5]);  // 060166CC mov.l r5,@r3
L_060166CE:
    c.r[1] = ld32(c.r[3]);  // 060166CE mov.l @r3,r1
    st8(c.r[1], c.r[0]);  // 060166D0 mov.b r0,@r1
    c.r[1] = c.r[2];  // 060166D2 mov r2,r1
    c.r[1] += 1;  // 060166D4 add #1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 060166D6 extu.b r1,r2
    c.t = c.r[2] >= c.r[7];  // 060166D8 cmp/hs r7,r2
    { const bool k = !c.t; c.t = c.r[7] == c.r[6]; if (k) { SH2_POLL(c); goto L_060166C2; } }  // 060166DA bf/s 0x060166C2 ; cmp/eq r6,r7
L_060166DE:
    { const bool k = c.t; c.r[2] = c.r[7]; if (k) { goto L_06016730; } }  // 060166DE bt/s 0x06016730 ; mov r7,r2
    c.macl = c.r[6] * c.r[9];  // 060166E2 mul.l r9,r6
    c.r[2] = c.macl;  // 060166E4 sts macl,r2
    c.macl = c.r[7] * c.r[8];  // 060166E6 mul.l r8,r7
    c.r[1] = c.macl;  // 060166E8 sts macl,r1
    c.r[2] -= c.r[1];  // 060166EA sub r1,r2
    c.r[2] <<= 2;  // 060166EC shll2 r2
    c.r[2] += c.r[2];  // 060166EE add r2,r2
    c.macl = c.r[6] * c.r[2];  // 060166F0 mul.l r2,r6
    c.r[5] = c.r[6];  // 060166F2 mov r6,r5
    c.r[1] = ld32(0x06016764u);  // 060166F4 mov.l 0x06016764,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060166FAu; c.r[4] = c.macl; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060166FAu) return; }  // 060166F6 jsr @r1 ; sts macl,r4
    c.r[4] = c.r[0];  // 060166FA mov r0,r4
    { const uint32_t x = c.r[1]; c.pr = 0x06016700u; c.r[5] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06016700u) return; }  // 060166FC jsr @r1 ; mov r8,r5
    c.r[1] = c.r[0] & 0xFFu;  // 06016700 extu.b r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06016702 tst r1,r1
    { const bool k = !c.t; c.t = (c.r[7] & c.r[7]) == 0; if (k) { goto L_0601670C; } }  // 06016704 bf/s 0x0601670C ; tst r7,r7
    { const bool k = c.t; c.r[2] = c.r[7]; if (k) { goto L_06016730; } }  // 06016708 bt/s 0x06016730 ; mov r7,r2
L_0601670C:
    c.r[1] = 0u - c.r[1];  // 0601670C neg r1,r1
    c.r[1] += 120;  // 0601670E add #120,r1
    c.r[5] = c.r[1] & 0xFFu;  // 06016710 extu.b r1,r5
    c.r[3] = ld32(0x06016768u);  // 06016712 mov.l 0x06016768,r3
    c.r[2] = ld32(c.r[3]);  // 06016714 mov.l @r3,r2
    c.r[1] = ld32(0x0601676Cu);  // 06016716 mov.l 0x0601676C,r1
    c.r[2] += 1;  // 06016718 add #1,r2
    c.t = c.r[2] >= c.r[1];  // 0601671A cmp/hs r1,r2
    { const bool k = !c.t; st32(c.r[3], c.r[2]); if (k) { goto L_06016724; } }  // 0601671C bf/s 0x06016724 ; mov.l r2,@r3
    c.r[1] = ld32(0x06016770u);  // 06016720 mov.l 0x06016770,r1
    st32(c.r[3], c.r[1]);  // 06016722 mov.l r1,@r3
L_06016724:
    c.r[1] = ld32(c.r[3]);  // 06016724 mov.l @r3,r1
    st8(c.r[1], c.r[5]);  // 06016726 mov.b r5,@r1
    c.r[1] = c.r[7];  // 06016728 mov r7,r1
    c.r[1] += 1;  // 0601672A add #1,r1
    c.r[7] = c.r[1] & 0xFFu;  // 0601672C extu.b r1,r7
    c.r[2] = c.r[7];  // 0601672E mov r7,r2
L_06016730:
    c.t = c.r[2] >= c.r[6];  // 06016730 cmp/hs r6,r2
    { const bool k = c.t; c.r[15] = c.r[14]; if (k) { goto L_0601675A; } }  // 06016732 bt/s 0x0601675A ; mov r14,r15
    c.r[4] = 0x78u;  // 06016736 mov #120,r4
    c.r[3] = ld32(0x06016768u);  // 06016738 mov.l 0x06016768,r3
    c.r[5] = ld32(0x0601676Cu);  // 0601673A mov.l 0x0601676C,r5
    c.r[7] = ld32(0x06016770u);  // 0601673C mov.l 0x06016770,r7
L_0601673E:
    c.r[1] = ld32(c.r[3]);  // 0601673E mov.l @r3,r1
    c.r[1] += 1;  // 06016740 add #1,r1
    c.t = c.r[1] >= c.r[5];  // 06016742 cmp/hs r5,r1
    { const bool k = !c.t; st32(c.r[3], c.r[1]); if (k) { goto L_0601674A; } }  // 06016744 bf/s 0x0601674A ; mov.l r1,@r3
    st32(c.r[3], c.r[7]);  // 06016748 mov.l r7,@r3
L_0601674A:
    c.r[1] = ld32(c.r[3]);  // 0601674A mov.l @r3,r1
    st8(c.r[1], c.r[4]);  // 0601674C mov.b r4,@r1
    c.r[1] = c.r[2];  // 0601674E mov r2,r1
    c.r[1] += 1;  // 06016750 add #1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 06016752 extu.b r1,r2
    c.t = c.r[2] >= c.r[6];  // 06016754 cmp/hs r6,r2
    { const bool k = !c.t; c.r[15] = c.r[14]; if (k) { SH2_POLL(c); goto L_0601673E; } }  // 06016756 bf/s 0x0601673E ; mov r14,r15
L_0601675A:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601675A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601675C mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0601675E mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06016760 rts ; mov.l @r15+,r8
}

void f_06016774(SH2Context& c) {
    ran[130] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06016774 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06016776 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06016778 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601677A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601677C sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0601677E mov r15,r14
    c.r[10] = c.r[4] & 0xFFu;  // 06016780 extu.b r4,r10
    c.r[9] = c.r[5] & 0xFFu;  // 06016782 extu.b r5,r9
    c.r[4] = ld32(0x0601694Cu);  // 06016784 mov.l 0x0601694C,r4
    c.r[8] = ld32(0x06016950u);  // 06016786 mov.l 0x06016950,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0601678Cu; c.r[5] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601678Cu) return; }  // 06016788 jsr @r8 ; mov #23,r5
    c.r[1] = c.r[0];  // 0601678C mov r0,r1
    c.r[5] = 0x1u;  // 0601678E mov #1,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06016794u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06016794u) return; }  // 06016790 jsr @r8 ; mov r1,r4
    c.r[3] = c.r[0];  // 06016794 mov r0,r3
    c.r[2] = 0x3u;  // 06016796 mov #3,r2
    c.r[2] &= c.r[10];  // 06016798 and r10,r2
    c.r[0] = c.r[2];  // 0601679A mov r2,r0
    c.t = c.r[0] == 0x2u;  // 0601679C cmp/eq #2,r0
    { const bool k = c.t; c.r[1] = 0x2u; if (k) { goto L_06016828; } }  // 0601679E bt/s 0x06016828 ; mov #2,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 060167A2 cmp/gt r1,r2
    { const bool k = c.t; c.t = c.r[0] == 0x3u; if (k) { goto L_060167B2; } }  // 060167A4 bt/s 0x060167B2 ; cmp/eq #3,r0
    c.t = c.r[0] == 0x1u;  // 060167A8 cmp/eq #1,r0
    { const bool k = c.t; c.r[0] = c.r[9]; if (k) { goto L_060167BE; } }  // 060167AA bt/s 0x060167BE ; mov r9,r0
    c.t = c.r[0] == 0x2u; goto L_06016992;  // 060167AE bra 0x06016992 ; cmp/eq #2,r0
L_060167B2:
    { const bool k = !c.t; c.r[0] = c.r[9]; if (k) { goto L_060167BA; } }  // 060167B2 bf/s 0x060167BA ; mov r9,r0
    goto L_060168C0;  // 060167B6 bra 0x060168C0 ; nop
L_060167BA:
    c.t = c.r[0] == 0x2u; goto L_06016992;  // 060167BA bra 0x06016992 ; cmp/eq #2,r0
L_060167BE:
    c.t = c.r[0] == 0x2u;  // 060167BE cmp/eq #2,r0
    { const bool k = c.t; c.t = (int32_t)c.r[9] > (int32_t)c.r[1]; if (k) { goto L_060167EC; } }  // 060167C0 bt/s 0x060167EC ; cmp/gt r1,r9
    { const bool k = c.t; c.t = c.r[0] == 0x1u; if (k) { goto L_060167D0; } }  // 060167C4 bt/s 0x060167D0 ; cmp/eq #1,r0
    { const bool k = c.t; c.r[0] = 0x7u; if (k) { goto L_060167DC; } }  // 060167C8 bt/s 0x060167DC ; mov #7,r0
    goto L_06016816;  // 060167CC bra 0x06016816 ; nop
L_060167D0:
    c.r[0] = c.r[9];  // 060167D0 mov r9,r0
    c.t = c.r[0] == 0x3u;  // 060167D2 cmp/eq #3,r0
    { const bool k = c.t; c.r[0] = 0x7u; if (k) { goto L_06016804; } }  // 060167D4 bt/s 0x06016804 ; mov #7,r0
    goto L_06016816;  // 060167D8 bra 0x06016816 ; nop
L_060167DC:
    c.r[1] = ld32(0x06016954u);  // 060167DC mov.l 0x06016954,r1
    c.r[1] = ld32(c.r[1]);  // 060167DE mov.l @r1,r1
    c.r[1] += 40;  // 060167E0 add #40,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060167E2 mov.b @r1,r1
    c.r[9] = c.r[1];  // 060167E4 mov r1,r9
    c.r[9] >>= 2;  // 060167E6 shlr2 r9
    c.r[9] &= c.r[0]; goto L_06016A08;  // 060167E8 bra 0x06016A08 ; and r0,r9
L_060167EC:
    c.r[1] = ld32(0x06016954u);  // 060167EC mov.l 0x06016954,r1
    c.r[1] = ld32(c.r[1]);  // 060167EE mov.l @r1,r1
    c.r[1] += 40;  // 060167F0 add #40,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060167F2 mov.w @r1,r1
    c.r[0] = 0x7u;  // 060167F4 mov #7,r0
    c.r[9] = c.r[1];  // 060167F6 mov r1,r9
    c.r[9] >>= 2;  // 060167F8 shlr2 r9
    c.r[9] >>= 2;  // 060167FA shlr2 r9
    c.t = c.r[9] & 1; c.r[9] >>= 1;  // 060167FC shlr r9
    c.r[9] >>= 2;  // 060167FE shlr2 r9
    c.r[9] &= c.r[0]; goto L_06016A08;  // 06016800 bra 0x06016A08 ; and r0,r9
L_06016804:
    c.r[1] = ld32(0x06016954u);  // 06016804 mov.l 0x06016954,r1
    c.r[1] = ld32(c.r[1]);  // 06016806 mov.l @r1,r1
    c.r[1] += 41;  // 06016808 add #41,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601680A mov.b @r1,r1
    c.r[9] = c.r[1];  // 0601680C mov r1,r9
    c.r[9] >>= 2;  // 0601680E shlr2 r9
    c.r[9] >>= 2;  // 06016810 shlr2 r9
    c.r[9] &= c.r[0]; goto L_06016A08;  // 06016812 bra 0x06016A08 ; and r0,r9
L_06016816:
    c.r[1] = ld32(0x06016954u);  // 06016816 mov.l 0x06016954,r1
    c.r[1] = ld32(c.r[1]);  // 06016818 mov.l @r1,r1
    c.r[1] += 40;  // 0601681A add #40,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601681C mov.b @r1,r1
    c.r[9] = c.r[1] & 0xFFu;  // 0601681E extu.b r1,r9
    c.r[9] >>= 2;  // 06016820 shlr2 r9
    c.t = c.r[9] & 1; c.r[9] >>= 1;  // 06016822 shlr r9
    c.r[9] >>= 2; goto L_06016A08;  // 06016824 bra 0x06016A08 ; shlr2 r9
L_06016828:
    c.r[0] = c.r[9];  // 06016828 mov r9,r0
    c.t = c.r[0] == 0x2u;  // 0601682A cmp/eq #2,r0
    { const bool k = c.t; c.r[10] >>= 2; if (k) { goto L_06016864; } }  // 0601682C bt/s 0x06016864 ; shlr2 r10
    c.t = (int32_t)c.r[9] > (int32_t)c.r[2];  // 06016830 cmp/gt r2,r9
    { const bool k = c.t; c.t = c.r[0] == 0x3u; if (k) { goto L_06016840; } }  // 06016832 bt/s 0x06016840 ; cmp/eq #3,r0
    c.t = c.r[0] == 0x1u;  // 06016836 cmp/eq #1,r0
    { const bool k = c.t; c.r[0] = 0x3u; if (k) { goto L_06016848; } }  // 06016838 bt/s 0x06016848 ; mov #3,r0
    goto L_06016896;  // 0601683C bra 0x06016896 ; nop
L_06016840:
    { const bool k = c.t; c.r[9] = 0x3u; if (k) { goto L_06016880; } }  // 06016840 bt/s 0x06016880 ; mov #3,r9
    goto L_06016896;  // 06016844 bra 0x06016896 ; nop
L_06016848:
    c.r[1] = ld32(0x06016958u);  // 06016848 mov.l 0x06016958,r1
    c.r[2] = ld32(c.r[1]);  // 0601684A mov.l @r1,r2
    c.r[1] = c.r[10];  // 0601684C mov r10,r1
    c.r[1] <<= 2;  // 0601684E shll2 r1
    c.r[1] += c.r[10];  // 06016850 add r10,r1
    c.r[1] <<= 2;  // 06016852 shll2 r1
    c.r[2] += c.r[1];  // 06016854 add r1,r2
    c.r[2] += 56;  // 06016856 add #56,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06016858 mov.b @r2,r1
    c.r[9] = c.r[1];  // 0601685A mov r1,r9
    c.r[9] >>= 2;  // 0601685C shlr2 r9
    c.r[9] >>= 2;  // 0601685E shlr2 r9
    c.r[9] &= c.r[0]; goto L_060168B0;  // 06016860 bra 0x060168B0 ; and r0,r9
L_06016864:
    c.r[1] = ld32(0x06016958u);  // 06016864 mov.l 0x06016958,r1
    c.r[2] = ld32(c.r[1]);  // 06016866 mov.l @r1,r2
    c.r[1] = c.r[10];  // 06016868 mov r10,r1
    c.r[1] <<= 2;  // 0601686A shll2 r1
    c.r[1] += c.r[10];  // 0601686C add r10,r1
    c.r[1] <<= 2;  // 0601686E shll2 r1
    c.r[2] += c.r[1];  // 06016870 add r1,r2
    c.r[2] += 56;  // 06016872 add #56,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06016874 mov.b @r2,r1
    c.r[0] = 0x3u;  // 06016876 mov #3,r0
    c.r[9] = c.r[1];  // 06016878 mov r1,r9
    c.r[9] >>= 2;  // 0601687A shlr2 r9
    c.r[9] &= c.r[0]; goto L_060168B0;  // 0601687C bra 0x060168B0 ; and r0,r9
L_06016880:
    c.r[1] = ld32(0x06016958u);  // 06016880 mov.l 0x06016958,r1
    c.r[2] = ld32(c.r[1]);  // 06016882 mov.l @r1,r2
    c.r[1] = c.r[10];  // 06016884 mov r10,r1
    c.r[1] <<= 2;  // 06016886 shll2 r1
    c.r[1] += c.r[10];  // 06016888 add r10,r1
    c.r[1] <<= 2;  // 0601688A shll2 r1
    c.r[2] += c.r[1];  // 0601688C add r1,r2
    c.r[2] += 56;  // 0601688E add #56,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06016890 mov.b @r2,r0
    c.r[9] &= c.r[0]; goto L_060168B0;  // 06016892 bra 0x060168B0 ; and r0,r9
L_06016896:
    c.r[1] = ld32(0x06016958u);  // 06016896 mov.l 0x06016958,r1
    c.r[2] = ld32(c.r[1]);  // 06016898 mov.l @r1,r2
    c.r[1] = c.r[10];  // 0601689A mov r10,r1
    c.r[1] <<= 2;  // 0601689C shll2 r1
    c.r[1] += c.r[10];  // 0601689E add r10,r1
    c.r[1] <<= 2;  // 060168A0 shll2 r1
    c.r[2] += c.r[1];  // 060168A2 add r1,r2
    c.r[2] += 56;  // 060168A4 add #56,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060168A6 mov.b @r2,r1
    c.r[9] = c.r[1] & 0xFFu;  // 060168A8 extu.b r1,r9
    c.r[9] >>= 2;  // 060168AA shlr2 r9
    c.r[9] >>= 2;  // 060168AC shlr2 r9
    c.r[9] >>= 2;  // 060168AE shlr2 r9
L_060168B0:
    c.t = (c.r[9] & c.r[9]) == 0;  // 060168B0 tst r9,r9
    { const bool k = !c.t; c.r[7] = 0x11u; if (k) { goto L_060168BA; } }  // 060168B2 bf/s 0x060168BA ; mov #17,r7
    goto L_060169F0;  // 060168B6 bra 0x060169F0 ; nop
L_060168BA:
    c.r[5] = 0u - c.r[9];  // 060168BA neg r9,r5
    c.r[5] += 3; goto L_06016A0C;  // 060168BC bra 0x06016A0C ; add #3,r5
L_060168C0:
    c.t = c.r[0] == 0x2u;  // 060168C0 cmp/eq #2,r0
    { const bool k = c.t; c.t = (int32_t)c.r[9] > (int32_t)c.r[1]; if (k) { goto L_06016906; } }  // 060168C2 bt/s 0x06016906 ; cmp/gt r1,r9
    { const bool k = c.t; c.t = c.r[0] == 0x3u; if (k) { goto L_060168D4; } }  // 060168C6 bt/s 0x060168D4 ; cmp/eq #3,r0
    c.t = c.r[0] == 0x1u;  // 060168CA cmp/eq #1,r0
    { const bool k = c.t; c.r[0] = 0x7u; if (k) { goto L_060168DC; } }  // 060168CC bt/s 0x060168DC ; mov #7,r0
    goto L_0601695C;  // 060168D0 bra 0x0601695C ; nop
L_060168D4:
    { const bool k = c.t; c.r[2] = 0x7u; if (k) { goto L_0601692E; } }  // 060168D4 bt/s 0x0601692E ; mov #7,r2
    goto L_0601695C;  // 060168D8 bra 0x0601695C ; nop
L_060168DC:
    c.r[1] = ld32(0x06016958u);  // 060168DC mov.l 0x06016958,r1
    c.r[1] = ld32(c.r[1]);  // 060168DE mov.l @r1,r1
    c.r[2] = ld32(c.r[1] + 36);  // 060168E0 mov.l @(36,r1),r2
    c.r[2] >>= 8;  // 060168E2 shlr8 r2
    c.r[2] <<= 2;  // 060168E4 shll2 r2
    c.r[2] >>= 8;  // 060168E6 shlr8 r2
    c.r[2] &= c.r[0];  // 060168E8 and r0,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 060168EA tst r2,r2
    { const bool k = c.t; c.r[1] = 0x0u; if (k) { goto L_0601698E; } }  // 060168EC bt/s 0x0601698E ; mov #0,r1
    c.r[1] = ld32(0x06016954u);  // 060168F0 mov.l 0x06016954,r1
    c.r[1] = ld32(c.r[1]);  // 060168F2 mov.l @r1,r1
    c.r[1] += 40;  // 060168F4 add #40,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060168F6 mov.b @r1,r1
    c.r[1] >>= 2;  // 060168F8 shlr2 r1
L_060168FA:
    c.r[1] &= c.r[0];  // 060168FA and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060168FC tst r1,r1
    if (!c.t) { goto L_06016986; }  // 060168FE bf 0x06016986
    c.r[1] = 0x0u;  // 06016900 mov #0,r1
    c.r[9] = c.r[1]; goto L_06016A08;  // 06016902 bra 0x06016A08 ; mov r1,r9
L_06016906:
    c.r[1] = ld32(0x06016958u);  // 06016906 mov.l 0x06016958,r1
    c.r[1] = ld32(c.r[1]);  // 06016908 mov.l @r1,r1
    c.r[1] += 38;  // 0601690A add #38,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601690C mov.b @r1,r1
    c.r[0] = 0x7u;  // 0601690E mov #7,r0
    c.r[2] = c.r[1];  // 06016910 mov r1,r2
    c.r[2] >>= 2;  // 06016912 shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 06016914 shlr r2
    c.r[2] &= c.r[0];  // 06016916 and r0,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06016918 tst r2,r2
    if (c.t) { goto L_0601698C; }  // 0601691A bt 0x0601698C
    c.r[1] = ld32(0x06016954u);  // 0601691C mov.l 0x06016954,r1
    c.r[1] = ld32(c.r[1]);  // 0601691E mov.l @r1,r1
    c.r[1] += 40;  // 06016920 add #40,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06016922 mov.w @r1,r1
    c.r[1] >>= 2;  // 06016924 shlr2 r1
    c.r[1] >>= 2;  // 06016926 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06016928 shlr r1
    c.r[1] >>= 2; SH2_POLL(c); goto L_060168FA;  // 0601692A bra 0x060168FA ; shlr2 r1
L_0601692E:
    c.r[1] = ld32(0x06016958u);  // 0601692E mov.l 0x06016958,r1
    c.r[1] = ld32(c.r[1]);  // 06016930 mov.l @r1,r1
    c.r[1] += 38;  // 06016932 add #38,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06016934 mov.b @r1,r0
    c.r[2] &= c.r[0];  // 06016936 and r0,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06016938 tst r2,r2
    { const bool k = c.t; c.r[0] = 0x7u; if (k) { goto L_0601698C; } }  // 0601693A bt/s 0x0601698C ; mov #7,r0
    c.r[1] = ld32(0x06016954u);  // 0601693E mov.l 0x06016954,r1
    c.r[1] = ld32(c.r[1]);  // 06016940 mov.l @r1,r1
    c.r[1] += 41;  // 06016942 add #41,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06016944 mov.b @r1,r1
    c.r[1] >>= 2;  // 06016946 shlr2 r1
    c.r[1] >>= 2; SH2_POLL(c); goto L_060168FA;  // 06016948 bra 0x060168FA ; shlr2 r1
L_0601695C:
    c.r[1] = ld32(0x06016A24u);  // 0601695C mov.l 0x06016A24,r1
    c.r[1] = ld32(c.r[1]);  // 0601695E mov.l @r1,r1
    c.r[1] += 37;  // 06016960 add #37,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06016962 mov.b @r1,r1
    c.r[0] = 0x7u;  // 06016964 mov #7,r0
    c.r[2] = c.r[1];  // 06016966 mov r1,r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 06016968 shlr r2
    c.r[2] &= c.r[0];  // 0601696A and r0,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0601696C tst r2,r2
    { const bool k = c.t; c.r[1] = 0x0u; if (k) { goto L_0601698E; } }  // 0601696E bt/s 0x0601698E ; mov #0,r1
    c.r[1] = ld32(0x06016A28u);  // 06016972 mov.l 0x06016A28,r1
    c.r[1] = ld32(c.r[1]);  // 06016974 mov.l @r1,r1
    c.r[1] += 40;  // 06016976 add #40,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06016978 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601697A extu.b r1,r1
    c.r[1] >>= 2;  // 0601697C shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0601697E shlr r1
    c.r[1] >>= 2;  // 06016980 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06016982 tst r1,r1
    if (c.t) { goto L_0601698C; }  // 06016984 bt 0x0601698C
L_06016986:
    c.r[1] += c.r[2];  // 06016986 add r2,r1
    c.t = c.r[1] & 1; c.r[1] >>= 1; goto L_0601698E;  // 06016988 bra 0x0601698E ; shlr r1
L_0601698C:
    c.r[1] = 0x0u;  // 0601698C mov #0,r1
L_0601698E:
    c.r[9] = c.r[1]; goto L_06016A08;  // 0601698E bra 0x06016A08 ; mov r1,r9
L_06016992:
    { const bool k = c.t; c.r[1] = 0x2u; if (k) { goto L_060169BC; } }  // 06016992 bt/s 0x060169BC ; mov #2,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 06016996 cmp/gt r1,r9
    { const bool k = c.t; c.t = c.r[0] == 0x1u; if (k) { goto L_060169A4; } }  // 06016998 bt/s 0x060169A4 ; cmp/eq #1,r0
    { const bool k = c.t; c.r[0] = 0x7u; if (k) { goto L_060169AE; } }  // 0601699C bt/s 0x060169AE ; mov #7,r0
    goto L_060169DA;  // 060169A0 bra 0x060169DA ; nop
L_060169A4:
    c.r[0] = c.r[9];  // 060169A4 mov r9,r0
    c.t = c.r[0] == 0x3u;  // 060169A6 cmp/eq #3,r0
    if (!c.t) { goto L_060169DA; }  // 060169A8 bf 0x060169DA
    goto L_060169CE;  // 060169AA bra 0x060169CE ; nop
L_060169AE:
    c.r[1] = ld32(0x06016A24u);  // 060169AE mov.l 0x06016A24,r1
    c.r[1] = ld32(c.r[1]);  // 060169B0 mov.l @r1,r1
    c.r[9] = ld32(c.r[1] + 36);  // 060169B2 mov.l @(36,r1),r9
    c.r[9] >>= 8;  // 060169B4 shlr8 r9
    c.r[9] <<= 2;  // 060169B6 shll2 r9
    c.r[9] >>= 8; goto L_060169E8;  // 060169B8 bra 0x060169E8 ; shlr8 r9
L_060169BC:
    c.r[1] = ld32(0x06016A24u);  // 060169BC mov.l 0x06016A24,r1
    c.r[1] = ld32(c.r[1]);  // 060169BE mov.l @r1,r1
    c.r[1] += 38;  // 060169C0 add #38,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060169C2 mov.b @r1,r1
    c.r[0] = 0x7u;  // 060169C4 mov #7,r0
    c.r[9] = c.r[1];  // 060169C6 mov r1,r9
    c.r[9] >>= 2;  // 060169C8 shlr2 r9
    c.t = c.r[9] & 1; c.r[9] >>= 1; goto L_060169E8;  // 060169CA bra 0x060169E8 ; shlr r9
L_060169CE:
    c.r[1] = ld32(0x06016A24u);  // 060169CE mov.l 0x06016A24,r1
    c.r[1] = ld32(c.r[1]);  // 060169D0 mov.l @r1,r1
    c.r[1] += 38;  // 060169D2 add #38,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060169D4 mov.b @r1,r0
    c.r[9] = 0x7u; goto L_060169E8;  // 060169D6 bra 0x060169E8 ; mov #7,r9
L_060169DA:
    c.r[1] = ld32(0x06016A24u);  // 060169DA mov.l 0x06016A24,r1
    c.r[1] = ld32(c.r[1]);  // 060169DC mov.l @r1,r1
    c.r[1] += 37;  // 060169DE add #37,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060169E0 mov.b @r1,r1
    c.r[0] = 0x7u;  // 060169E2 mov #7,r0
    c.r[9] = c.r[1];  // 060169E4 mov r1,r9
    c.t = c.r[9] & 1; c.r[9] >>= 1;  // 060169E6 shlr r9
L_060169E8:
    c.r[9] &= c.r[0];  // 060169E8 and r0,r9
    c.t = (c.r[9] & c.r[9]) == 0;  // 060169EA tst r9,r9
    { const bool k = !c.t; c.r[7] = 0x11u; if (k) { goto L_06016A08; } }  // 060169EC bf/s 0x06016A08 ; mov #17,r7
L_060169F0:
    c.r[3] = ld32(0x06016A2Cu);  // 060169F0 mov.l 0x06016A2C,r3
    c.r[2] = ld32(c.r[3]);  // 060169F2 mov.l @r3,r2
    c.r[1] = ld32(0x06016A30u);  // 060169F4 mov.l 0x06016A30,r1
    c.r[2] += 1;  // 060169F6 add #1,r2
    c.t = c.r[2] >= c.r[1];  // 060169F8 cmp/hs r1,r2
    { const bool k = !c.t; st32(c.r[3], c.r[2]); if (k) { goto L_06016A02; } }  // 060169FA bf/s 0x06016A02 ; mov.l r2,@r3
    c.r[1] = ld32(0x06016A34u);  // 060169FE mov.l 0x06016A34,r1
    st32(c.r[3], c.r[1]);  // 06016A00 mov.l r1,@r3
L_06016A02:
    c.r[1] = ld32(c.r[3]);  // 06016A02 mov.l @r3,r1
    st8(c.r[1], c.r[7]); goto L_06016A16;  // 06016A04 bra 0x06016A16 ; mov.b r7,@r1
L_06016A08:
    c.r[5] = 0u - c.r[9];  // 06016A08 neg r9,r5
    c.r[5] += 4;  // 06016A0A add #4,r5
L_06016A0C:
    c.r[5] = c.r[5] & 0xFFu;  // 06016A0C extu.b r5,r5
    c.r[1] = ld32(0x06016A38u);  // 06016A0E mov.l 0x06016A38,r1
    c.r[6] = 0x1u;  // 06016A10 mov #1,r6
    { const uint32_t x = c.r[1]; c.pr = 0x06016A16u; c.r[4] = c.r[3]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06016A16u) return; }  // 06016A12 jsr @r1 ; mov r3,r4
L_06016A16:
    c.r[15] = c.r[14];  // 06016A16 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06016A18 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06016A1A mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06016A1C mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06016A1E mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06016A20 rts ; mov.l @r15+,r8
}

void f_06016A3C(SH2Context& c) {
    ran[131] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06016A3C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06016A3E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06016A40 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06016A42 mov r15,r14
    c.r[6] = c.r[6] & 0xFFu;  // 06016A44 extu.b r6,r6
    c.t = (c.r[6] & c.r[6]) == 0;  // 06016A46 tst r6,r6
    { const bool k = !c.t; c.r[5] = c.r[5] & 0xFFu; if (k) { goto L_06016AD6; } }  // 06016A48 bf/s 0x06016AD6 ; extu.b r5,r5
    c.r[0] = c.r[5];  // 06016A4C mov r5,r0
    c.r[0] <<= 2;  // 06016A4E shll2 r0
    c.r[2] = c.r[4];  // 06016A50 mov r4,r2
    c.r[2] += c.r[0];  // 06016A52 add r0,r2
    c.r[1] = c.r[2];  // 06016A54 mov r2,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[4]);  // 06016A56 mov.b @(r0,r4),r3
    c.r[1] += 1;  // 06016A58 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06016A5A mov.b @r1,r1
    c.r[3] <<= 16;  // 06016A5C shll16 r3
    c.r[3] <<= 8;  // 06016A5E shll8 r3
    c.r[1] = c.r[1] & 0xFFu;  // 06016A60 extu.b r1,r1
    c.r[1] <<= 16;  // 06016A62 shll16 r1
    c.r[3] |= c.r[1];  // 06016A64 or r1,r3
    c.r[1] = c.r[2];  // 06016A66 mov r2,r1
    c.r[1] += 2;  // 06016A68 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06016A6A mov.b @r1,r1
    c.r[2] += 3;  // 06016A6C add #3,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06016A6E extu.b r1,r1
    c.r[1] <<= 8;  // 06016A70 shll8 r1
    c.r[3] |= c.r[1];  // 06016A72 or r1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06016A74 mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06016A76 extu.b r1,r1
    c.r[3] |= c.r[1];  // 06016A78 or r1,r3
    c.r[3] += c.r[4];  // 06016A7A add r4,r3
    c.r[7] = c.r[3];  // 06016A7C mov r3,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06016A7E mov.b @(r0,r3),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06016B0Eu);  // 06016A80 mov.w 0x06016B0E,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06016A82 extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 06016A84 cmp/eq r2,r1
    { const bool k = c.t; c.r[7] += c.r[0]; if (k) { goto L_06016B04; } }  // 06016A86 bt/s 0x06016B04 ; add r0,r7
    c.r[6] = ld32(0x06016B10u);  // 06016A8A mov.l 0x06016B10,r6
    c.r[4] = ld32(0x06016B14u);  // 06016A8C mov.l 0x06016B14,r4
    c.r[5] = ld32(0x06016B18u);  // 06016A8E mov.l 0x06016B18,r5
L_06016A90:
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06016A90 mov.b @r7,r3
    c.r[2] = 0xAu;  // 06016A92 mov #10,r2
    c.r[1] = c.r[3];  // 06016A94 mov r3,r1
    c.r[1] += 21;  // 06016A96 add #21,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06016A98 extu.b r1,r1
    c.t = c.r[1] > c.r[2];  // 06016A9A cmp/hi r2,r1
    { const bool k = c.t; c.r[2] = c.r[3] & 0xFFu; if (k) { goto L_06016AB2; } }  // 06016A9C bt/s 0x06016AB2 ; extu.b r3,r2
    c.r[1] = ld32(c.r[6]);  // 06016AA0 mov.l @r6,r1
    c.r[7] += 1;  // 06016AA2 add #1,r7
    c.r[1] += 1;  // 06016AA4 add #1,r1
    c.t = c.r[1] >= c.r[4];  // 06016AA6 cmp/hs r4,r1
    { const bool k = !c.t; st32(c.r[6], c.r[1]); if (k) { goto L_06016AAE; } }  // 06016AA8 bf/s 0x06016AAE ; mov.l r1,@r6
    st32(c.r[6], c.r[5]);  // 06016AAC mov.l r5,@r6
L_06016AAE:
    c.r[1] = ld32(c.r[6]);  // 06016AAE mov.l @r6,r1
    st8(c.r[1], c.r[2]);  // 06016AB0 mov.b r2,@r1
L_06016AB2:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]); c.r[7] += 1;  // 06016AB2 mov.b @r7+,r1
    c.r[2] = c.r[1] & 0xFFu;  // 06016AB4 extu.b r1,r2
    c.r[1] = ld32(c.r[6]);  // 06016AB6 mov.l @r6,r1
    c.r[1] += 1;  // 06016AB8 add #1,r1
    c.t = c.r[1] >= c.r[4];  // 06016ABA cmp/hs r4,r1
    { const bool k = !c.t; st32(c.r[6], c.r[1]); if (k) { goto L_06016AC2; } }  // 06016ABC bf/s 0x06016AC2 ; mov.l r1,@r6
    st32(c.r[6], c.r[5]);  // 06016AC0 mov.l r5,@r6
L_06016AC2:
    c.r[1] = ld32(c.r[6]);  // 06016AC2 mov.l @r6,r1
    st8(c.r[1], c.r[2]);  // 06016AC4 mov.b r2,@r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06016AC6 mov.b @r7,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06016B0Eu);  // 06016AC8 mov.w 0x06016B0E,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06016ACA extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 06016ACC cmp/eq r2,r1
    { const bool k = !c.t; c.r[15] = c.r[14]; if (k) { SH2_POLL(c); goto L_06016A90; } }  // 06016ACE bf/s 0x06016A90 ; mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4; goto L_06016B08;  // 06016AD2 bra 0x06016B08 ; mov.l @r15+,r14
L_06016AD6:
    c.r[2] = 0x0u;  // 06016AD6 mov #0,r2
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[6];  // 06016AD8 cmp/ge r6,r2
    { const bool k = c.t; c.r[15] = c.r[14]; if (k) { goto L_06016B06; } }  // 06016ADA bt/s 0x06016B06 ; mov r14,r15
    c.r[7] = ld32(0x06016B10u);  // 06016ADE mov.l 0x06016B10,r7
    c.r[9] = ld32(0x06016B14u);  // 06016AE0 mov.l 0x06016B14,r9
    c.r[8] = ld32(0x06016B18u);  // 06016AE2 mov.l 0x06016B18,r8
L_06016AE4:
    c.macl = c.r[5] * c.r[6];  // 06016AE4 mul.l r6,r5
    c.r[0] = c.macl;  // 06016AE6 sts macl,r0
    c.r[0] += c.r[4];  // 06016AE8 add r4,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06016AEA mov.b @(r0,r2),r1
    c.r[3] = c.r[1] & 0xFFu;  // 06016AEC extu.b r1,r3
    c.r[1] = ld32(c.r[7]);  // 06016AEE mov.l @r7,r1
    c.r[1] += 1;  // 06016AF0 add #1,r1
    c.t = c.r[1] >= c.r[9];  // 06016AF2 cmp/hs r9,r1
    { const bool k = !c.t; st32(c.r[7], c.r[1]); if (k) { goto L_06016AFA; } }  // 06016AF4 bf/s 0x06016AFA ; mov.l r1,@r7
    st32(c.r[7], c.r[8]);  // 06016AF8 mov.l r8,@r7
L_06016AFA:
    c.r[1] = ld32(c.r[7]);  // 06016AFA mov.l @r7,r1
    c.r[2] += 1;  // 06016AFC add #1,r2
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[6];  // 06016AFE cmp/ge r6,r2
    { const bool k = !c.t; st8(c.r[1], c.r[3]); if (k) { SH2_POLL(c); goto L_06016AE4; } }  // 06016B00 bf/s 0x06016AE4 ; mov.b r3,@r1
L_06016B04:
    c.r[15] = c.r[14];  // 06016B04 mov r14,r15
L_06016B06:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06016B06 mov.l @r15+,r14
L_06016B08:
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06016B08 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06016B0A rts ; mov.l @r15+,r8
}

void f_06016B1C(SH2Context& c) {
    ran[132] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06016B1C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06016B1E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06016B20 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06016B22 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06016B24 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06016B26 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06016B28 mov r15,r14
    c.r[10] = c.r[5];  // 06016B2A mov r5,r10
    c.r[0] = c.r[4] & 0xFFu;  // 06016B2C extu.b r4,r0
    c.r[1] = c.r[0];  // 06016B2E mov r0,r1
    c.r[9] = c.r[6] & 0xFFu;  // 06016B30 extu.b r6,r9
    c.t = (c.r[0] & c.r[0]) == 0;  // 06016B32 tst r0,r0
    { const bool k = !c.t; c.r[8] = c.r[10]; if (k) { goto L_06016BC0; } }  // 06016B34 bf/s 0x06016BC0 ; mov r10,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06016B38 mov.b @r8,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06016C28u);  // 06016B3A mov.w 0x06016C28,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06016B3C extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 06016B3E cmp/eq r2,r1
    { const bool k = c.t; c.r[4] = c.r[8]; if (k) { goto L_06016B66; } }  // 06016B40 bt/s 0x06016B66 ; mov r8,r4
    c.r[0] = ld32(0x06016C2Cu);  // 06016B44 mov.l 0x06016C2C,r0
    c.r[5] = 0x1u;  // 06016B46 mov #1,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06016B4Cu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06016B4Cu) return; }  // 06016B48 jsr @r0 ; mov r8,r4
    c.r[7] = c.r[0] & 0xFFu;  // 06016B4C extu.b r0,r7
    c.r[3] = ld32(0x06016C30u);  // 06016B4E mov.l 0x06016C30,r3
    c.r[2] = ld32(c.r[3]);  // 06016B50 mov.l @r3,r2
    c.r[1] = ld32(0x06016C34u);  // 06016B52 mov.l 0x06016C34,r1
    c.r[2] += 1;  // 06016B54 add #1,r2
    c.t = c.r[2] >= c.r[1];  // 06016B56 cmp/hs r1,r2
    { const bool k = !c.t; st32(c.r[3], c.r[2]); if (k) { goto L_06016B60; } }  // 06016B58 bf/s 0x06016B60 ; mov.l r2,@r3
    c.r[1] = ld32(0x06016C38u);  // 06016B5C mov.l 0x06016C38,r1
    st32(c.r[3], c.r[1]);  // 06016B5E mov.l r1,@r3
L_06016B60:
    c.r[1] = ld32(c.r[3]);  // 06016B60 mov.l @r3,r1
    st8(c.r[1], c.r[7]);  // 06016B62 mov.b r7,@r1
    c.r[4] = c.r[8];  // 06016B64 mov r8,r4
L_06016B66:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]);  // 06016B66 mov.b @r4,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06016C28u);  // 06016B68 mov.w 0x06016C28,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06016B6A extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 06016B6C cmp/eq r2,r1
    if (!c.t) { goto L_06016B74; }  // 06016B6E bf 0x06016B74
    goto L_06016CA6;  // 06016B70 bra 0x06016CA6 ; nop
L_06016B74:
    c.r[7] = ld32(0x06016C30u);  // 06016B74 mov.l 0x06016C30,r7
    c.r[5] = ld32(0x06016C34u);  // 06016B76 mov.l 0x06016C34,r5
    c.r[6] = ld32(0x06016C38u);  // 06016B78 mov.l 0x06016C38,r6
L_06016B7A:
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[4]);  // 06016B7A mov.b @r4,r3
    c.r[2] = 0xAu;  // 06016B7C mov #10,r2
    c.r[1] = c.r[3];  // 06016B7E mov r3,r1
    c.r[1] += 21;  // 06016B80 add #21,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06016B82 extu.b r1,r1
    c.t = c.r[1] > c.r[2];  // 06016B84 cmp/hi r2,r1
    { const bool k = c.t; c.r[2] = c.r[3] & 0xFFu; if (k) { goto L_06016B9C; } }  // 06016B86 bt/s 0x06016B9C ; extu.b r3,r2
    c.r[1] = ld32(c.r[7]);  // 06016B8A mov.l @r7,r1
    c.r[4] += 1;  // 06016B8C add #1,r4
    c.r[1] += 1;  // 06016B8E add #1,r1
    c.t = c.r[1] >= c.r[5];  // 06016B90 cmp/hs r5,r1
    { const bool k = !c.t; st32(c.r[7], c.r[1]); if (k) { goto L_06016B98; } }  // 06016B92 bf/s 0x06016B98 ; mov.l r1,@r7
    st32(c.r[7], c.r[6]);  // 06016B96 mov.l r6,@r7
L_06016B98:
    c.r[1] = ld32(c.r[7]);  // 06016B98 mov.l @r7,r1
    st8(c.r[1], c.r[2]);  // 06016B9A mov.b r2,@r1
L_06016B9C:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 06016B9C mov.b @r4+,r1
    c.r[2] = c.r[1] & 0xFFu;  // 06016B9E extu.b r1,r2
    c.r[1] = ld32(c.r[7]);  // 06016BA0 mov.l @r7,r1
    c.r[1] += 1;  // 06016BA2 add #1,r1
    c.t = c.r[1] >= c.r[5];  // 06016BA4 cmp/hs r5,r1
    { const bool k = !c.t; st32(c.r[7], c.r[1]); if (k) { goto L_06016BAC; } }  // 06016BA6 bf/s 0x06016BAC ; mov.l r1,@r7
    st32(c.r[7], c.r[6]);  // 06016BAA mov.l r6,@r7
L_06016BAC:
    c.r[1] = ld32(c.r[7]);  // 06016BAC mov.l @r7,r1
    st8(c.r[1], c.r[2]);  // 06016BAE mov.b r2,@r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]);  // 06016BB0 mov.b @r4,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06016C28u);  // 06016BB2 mov.w 0x06016C28,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06016BB4 extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 06016BB6 cmp/eq r2,r1
    if (!c.t) { SH2_POLL(c); goto L_06016B7A; }  // 06016BB8 bf 0x06016B7A
    c.r[15] = c.r[14];  // 06016BBA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; } goto L_06016CAA;  // 06016BBC bra 0x06016CAA ; lds.l @r15+,pr
L_06016BC0:
    c.r[0] = c.r[1];  // 06016BC0 mov r1,r0
    c.t = c.r[0] == 0x1u;  // 06016BC2 cmp/eq #1,r0
    { const bool k = !c.t; c.r[3] = 0x0u; if (k) { goto L_06016C3C; } }  // 06016BC4 bf/s 0x06016C3C ; mov #0,r3
    c.t = c.r[3] >= c.r[9];  // 06016BC8 cmp/hs r9,r3
    if (c.t) { goto L_06016CA6; }  // 06016BCA bt 0x06016CA6
    c.r[10] = (uint32_t)(int16_t)ld16(0x06016C28u);  // 06016BCC mov.w 0x06016C28,r10
    c.r[7] = ld32(0x06016C30u);  // 06016BCE mov.l 0x06016C30,r7
    c.r[4] = ld32(0x06016C34u);  // 06016BD0 mov.l 0x06016C34,r4
    c.r[5] = ld32(0x06016C38u);  // 06016BD2 mov.l 0x06016C38,r5
L_06016BD4:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06016BD4 mov.b @r8,r1
    c.r[6] = c.r[1] & 0xFFu;  // 06016BD6 extu.b r1,r6
    c.t = c.r[6] == c.r[10];  // 06016BD8 cmp/eq r10,r6
    if (!c.t) { goto L_06016BE2; }  // 06016BDA bf 0x06016BE2
    c.r[1] = ld32(c.r[7]);  // 06016BDC mov.l @r7,r1
    c.r[2] = 0x0u; goto L_06016C0A;  // 06016BDE bra 0x06016C0A ; mov #0,r2
L_06016BE2:
    c.r[1] += 21;  // 06016BE2 add #21,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06016BE4 extu.b r1,r1
    c.r[2] = 0xAu;  // 06016BE6 mov #10,r2
    c.t = c.r[1] > c.r[2];  // 06016BE8 cmp/hi r2,r1
    if (c.t) { goto L_06016C04; }  // 06016BEA bt 0x06016C04
    c.r[1] = ld32(c.r[7]);  // 06016BEC mov.l @r7,r1
    c.r[8] += 1;  // 06016BEE add #1,r8
    c.r[1] += 1;  // 06016BF0 add #1,r1
    c.t = c.r[1] >= c.r[4];  // 06016BF2 cmp/hs r4,r1
    { const bool k = !c.t; st32(c.r[7], c.r[1]); if (k) { goto L_06016BFA; } }  // 06016BF4 bf/s 0x06016BFA ; mov.l r1,@r7
    st32(c.r[7], c.r[5]);  // 06016BF8 mov.l r5,@r7
L_06016BFA:
    c.r[1] = ld32(c.r[7]);  // 06016BFA mov.l @r7,r1
    st8(c.r[1], c.r[6]);  // 06016BFC mov.b r6,@r1
    c.r[1] = c.r[3];  // 06016BFE mov r3,r1
    c.r[1] += 1;  // 06016C00 add #1,r1
    c.r[3] = c.r[1] & 0xFFu;  // 06016C02 extu.b r1,r3
L_06016C04:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]); c.r[8] += 1;  // 06016C04 mov.b @r8+,r1
    c.r[2] = c.r[1] & 0xFFu;  // 06016C06 extu.b r1,r2
    c.r[1] = ld32(c.r[7]);  // 06016C08 mov.l @r7,r1
L_06016C0A:
    c.r[1] += 1;  // 06016C0A add #1,r1
    c.t = c.r[1] >= c.r[4];  // 06016C0C cmp/hs r4,r1
    { const bool k = !c.t; st32(c.r[7], c.r[1]); if (k) { goto L_06016C14; } }  // 06016C0E bf/s 0x06016C14 ; mov.l r1,@r7
    st32(c.r[7], c.r[5]);  // 06016C12 mov.l r5,@r7
L_06016C14:
    c.r[1] = ld32(c.r[7]);  // 06016C14 mov.l @r7,r1
    st8(c.r[1], c.r[2]);  // 06016C16 mov.b r2,@r1
    c.r[1] = c.r[3];  // 06016C18 mov r3,r1
    c.r[1] += 1;  // 06016C1A add #1,r1
    c.r[3] = c.r[1] & 0xFFu;  // 06016C1C extu.b r1,r3
    c.t = c.r[3] >= c.r[9];  // 06016C1E cmp/hs r9,r3
    if (!c.t) { SH2_POLL(c); goto L_06016BD4; }  // 06016C20 bf 0x06016BD4
    c.r[15] = c.r[14];  // 06016C22 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; } goto L_06016CAA;  // 06016C24 bra 0x06016CAA ; lds.l @r15+,pr
L_06016C3C:
    c.r[0] = ld32(0x06016CB8u);  // 06016C3C mov.l 0x06016CB8,r0
    c.r[5] = 0x1u;  // 06016C3E mov #1,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06016C44u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06016C44u) return; }  // 06016C40 jsr @r0 ; mov r8,r4
    c.r[11] = c.r[0] & 0xFFu;  // 06016C44 extu.b r0,r11
    c.t = c.r[11] > c.r[9];  // 06016C46 cmp/hi r9,r11
    if (!c.t) { goto L_06016C4C; }  // 06016C48 bf 0x06016C4C
    c.r[11] = c.r[9];  // 06016C4A mov r9,r11
L_06016C4C:
    c.r[3] = 0x0u;  // 06016C4C mov #0,r3
    c.r[6] = c.r[9];  // 06016C4E mov r9,r6
    c.r[6] -= c.r[11];  // 06016C50 sub r11,r6
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[6];  // 06016C52 cmp/ge r6,r3
    { const bool k = c.t; c.t = c.r[3] >= c.r[11]; if (k) { goto L_06016C7E; } }  // 06016C54 bt/s 0x06016C7E ; cmp/hs r11,r3
    c.r[4] = 0x0u;  // 06016C58 mov #0,r4
    c.r[2] = ld32(0x06016CBCu);  // 06016C5A mov.l 0x06016CBC,r2
    c.r[5] = ld32(0x06016CC0u);  // 06016C5C mov.l 0x06016CC0,r5
    c.r[7] = ld32(0x06016CC4u);  // 06016C5E mov.l 0x06016CC4,r7
L_06016C60:
    c.r[1] = ld32(c.r[2]);  // 06016C60 mov.l @r2,r1
    c.r[1] += 1;  // 06016C62 add #1,r1
    c.t = c.r[1] >= c.r[5];  // 06016C64 cmp/hs r5,r1
    { const bool k = !c.t; st32(c.r[2], c.r[1]); if (k) { goto L_06016C6C; } }  // 06016C66 bf/s 0x06016C6C ; mov.l r1,@r2
    st32(c.r[2], c.r[7]);  // 06016C6A mov.l r7,@r2
L_06016C6C:
    c.r[1] = ld32(c.r[2]);  // 06016C6C mov.l @r2,r1
    st8(c.r[1], c.r[4]);  // 06016C6E mov.b r4,@r1
    c.r[1] = c.r[3];  // 06016C70 mov r3,r1
    c.r[1] += 1;  // 06016C72 add #1,r1
    c.r[3] = c.r[1] & 0xFFu;  // 06016C74 extu.b r1,r3
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[6];  // 06016C76 cmp/ge r6,r3
    if (!c.t) { SH2_POLL(c); goto L_06016C60; }  // 06016C78 bf 0x06016C60
    c.r[3] = 0x0u;  // 06016C7A mov #0,r3
    c.t = c.r[3] >= c.r[11];  // 06016C7C cmp/hs r11,r3
L_06016C7E:
    { const bool k = c.t; c.r[8] = c.r[10]; if (k) { goto L_06016CA6; } }  // 06016C7E bt/s 0x06016CA6 ; mov r10,r8
    c.r[7] = ld32(0x06016CBCu);  // 06016C82 mov.l 0x06016CBC,r7
    c.r[5] = ld32(0x06016CC0u);  // 06016C84 mov.l 0x06016CC0,r5
    c.r[6] = ld32(0x06016CC4u);  // 06016C86 mov.l 0x06016CC4,r6
L_06016C88:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]); c.r[8] += 1;  // 06016C88 mov.b @r8+,r1
    c.r[2] = c.r[1] & 0xFFu;  // 06016C8A extu.b r1,r2
    c.r[1] = ld32(c.r[7]);  // 06016C8C mov.l @r7,r1
    c.r[1] += 1;  // 06016C8E add #1,r1
    c.t = c.r[1] >= c.r[5];  // 06016C90 cmp/hs r5,r1
    { const bool k = !c.t; st32(c.r[7], c.r[1]); if (k) { goto L_06016C98; } }  // 06016C92 bf/s 0x06016C98 ; mov.l r1,@r7
    st32(c.r[7], c.r[6]);  // 06016C96 mov.l r6,@r7
L_06016C98:
    c.r[1] = ld32(c.r[7]);  // 06016C98 mov.l @r7,r1
    st8(c.r[1], c.r[2]);  // 06016C9A mov.b r2,@r1
    c.r[1] = c.r[3];  // 06016C9C mov r3,r1
    c.r[1] += 1;  // 06016C9E add #1,r1
    c.r[3] = c.r[1] & 0xFFu;  // 06016CA0 extu.b r1,r3
    c.t = c.r[3] >= c.r[11];  // 06016CA2 cmp/hs r11,r3
    if (!c.t) { SH2_POLL(c); goto L_06016C88; }  // 06016CA4 bf 0x06016C88
L_06016CA6:
    c.r[15] = c.r[14];  // 06016CA6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06016CA8 lds.l @r15+,pr
L_06016CAA:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06016CAA mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06016CAC mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06016CAE mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06016CB0 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06016CB2 rts ; mov.l @r15+,r8
}

void f_06016CC8(SH2Context& c) {
    ran[133] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06016CC8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06016CCA mov.l r14,@-r15
    c.r[0] = c.r[4];  // 06016CCC mov r4,r0
    c.r[0] &= 0x7u;  // 06016CCE and #7,r0
    c.r[1] = 0x3u;  // 06016CD0 mov #3,r1
    c.r[0] -= 1;  // 06016CD2 add #-1,r0
    c.t = c.r[0] > c.r[1];  // 06016CD4 cmp/hi r1,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06016D0C; } }  // 06016CD6 bt/s 0x06016D0C ; mov r15,r14
    c.r[1] = c.r[0];  // 06016CDA mov r0,r1
    c.r[1] += c.r[1];  // 06016CDC add r1,r1
    c.r[0] = 0x06016CE8u;  // 06016CDE mova 0x06016CE8,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06016CE0 mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 06016CE2 add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x06016CF0u: goto L_06016CF0; case 0x06016CF6u: goto L_06016CF6; case 0x06016CFEu: goto L_06016CFE; case 0x06016D06u: goto L_06016D06; default: sh2_call(c, x); return; } }  // 06016CE4 jmp @r0 ; nop
L_06016CF0:
    c.r[4] = (uint32_t)(int16_t)ld16(0x06016D58u);  // 06016CF0 mov.w 0x06016D58,r4
    c.r[6] = 0x16u; goto L_06016D10;  // 06016CF2 bra 0x06016D10 ; mov #22,r6
L_06016CF6:
    c.r[4] = (uint32_t)(int16_t)ld16(0x06016D58u);  // 06016CF6 mov.w 0x06016D58,r4
    c.r[6] = 0x16u;  // 06016CF8 mov #22,r6
    c.r[7] = 0x2u; goto L_06016D12;  // 06016CFA bra 0x06016D12 ; mov #2,r7
L_06016CFE:
    c.r[4] = (uint32_t)(int16_t)ld16(0x06016D5Au);  // 06016CFE mov.w 0x06016D5A,r4
    c.r[6] = 0x17u;  // 06016D00 mov #23,r6
    c.r[7] = 0x2u; goto L_06016D12;  // 06016D02 bra 0x06016D12 ; mov #2,r7
L_06016D06:
    c.r[4] = (uint32_t)(int16_t)ld16(0x06016D58u);  // 06016D06 mov.w 0x06016D58,r4
    c.r[6] = 0x16u; goto L_06016D10;  // 06016D08 bra 0x06016D10 ; mov #22,r6
L_06016D0C:
    c.r[4] = 0x30u;  // 06016D0C mov #48,r4
    c.r[6] = 0x16u;  // 06016D0E mov #22,r6
L_06016D10:
    c.r[7] = 0x1u;  // 06016D10 mov #1,r7
L_06016D12:
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[5]);  // 06016D12 mov.b @r5,r3
    c.r[1] = c.r[3] & 0xFFu;  // 06016D14 extu.b r3,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06016D16 tst r1,r1
    { const bool k = c.t; c.r[15] = c.r[14]; if (k) { goto L_06016D52; } }  // 06016D18 bt/s 0x06016D52 ; mov r14,r15
    c.r[8] = 0x66u;  // 06016D1C mov #102,r8
    c.r[0] = 0x9u;  // 06016D1E mov #9,r0
    c.r[2] = c.r[3] & 0xFFu;  // 06016D20 extu.b r3,r2
L_06016D22:
    c.t = c.r[2] > c.r[8];  // 06016D22 cmp/hi r8,r2
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_06016D44; } }  // 06016D24 bt/s 0x06016D44 ; mov r3,r1
    c.r[1] -= 48;  // 06016D28 add #-48,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06016D2A extu.b r1,r1
    c.t = c.r[1] > c.r[0];  // 06016D2C cmp/hi r0,r1
    if (c.t) { goto L_06016D3A; }  // 06016D2E bt 0x06016D3A
    c.r[2] -= 48;  // 06016D30 add #-48,r2
    c.macl = c.r[2] * c.r[7];  // 06016D32 mul.l r7,r2
    c.r[1] = c.macl;  // 06016D34 sts macl,r1
    c.r[1] += c.r[4]; goto L_06016D42;  // 06016D36 bra 0x06016D42 ; add r4,r1
L_06016D3A:
    c.r[2] -= 97;  // 06016D3A add #-97,r2
    c.macl = c.r[2] * c.r[7];  // 06016D3C mul.l r7,r2
    c.r[1] = c.macl;  // 06016D3E sts macl,r1
    c.r[1] += c.r[6];  // 06016D40 add r6,r1
L_06016D42:
    st8(c.r[5], c.r[1]);  // 06016D42 mov.b r1,@r5
L_06016D44:
    c.r[5] += 1;  // 06016D44 add #1,r5
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[5]);  // 06016D46 mov.b @r5,r3
    c.r[1] = c.r[3] & 0xFFu;  // 06016D48 extu.b r3,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06016D4A tst r1,r1
    { const bool k = !c.t; c.r[2] = c.r[3] & 0xFFu; if (k) { SH2_POLL(c); goto L_06016D22; } }  // 06016D4C bf/s 0x06016D22 ; extu.b r3,r2
    c.r[15] = c.r[14];  // 06016D50 mov r14,r15
L_06016D52:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06016D52 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06016D54 rts ; mov.l @r15+,r8
}

void f_06016D5C(SH2Context& c) {
    ran[134] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06016D5C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06016D5E mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06016D60 mov r15,r14
    c.r[8] = c.r[5] & 0xFFu;  // 06016D62 extu.b r5,r8
    c.r[0] = 0x0u;  // 06016D64 mov #0,r0
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[4]);  // 06016D66 mov.b @r4,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x06016DCCu);  // 06016D68 mov.w 0x06016DCC,r7
    c.r[1] = c.r[3] & 0xFFu;  // 06016D6A extu.b r3,r1
    c.t = c.r[1] == c.r[7];  // 06016D6C cmp/eq r7,r1
    { const bool k = c.t; c.r[2] = 0x0u; if (k) { goto L_06016DAC; } }  // 06016D6E bt/s 0x06016DAC ; mov #0,r2
    c.r[5] = 0xAu;  // 06016D72 mov #10,r5
    c.r[6] = (uint32_t)(int16_t)ld16(0x06016DCEu);  // 06016D74 mov.w 0x06016DCE,r6
    c.r[1] = c.r[2];  // 06016D76 mov r2,r1
L_06016D78:
    c.r[1] += 10;  // 06016D78 add #10,r1
    c.r[2] = c.r[1] & 0xFFu;  // 06016D7A extu.b r1,r2
    c.r[1] = c.r[0];  // 06016D7C mov r0,r1
    c.r[1] += 1;  // 06016D7E add #1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06016D80 extu.b r1,r0
    c.r[1] = c.r[3];  // 06016D82 mov r3,r1
    c.r[1] += 21;  // 06016D84 add #21,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06016D86 extu.b r1,r1
    c.t = c.r[1] > c.r[5];  // 06016D88 cmp/hi r5,r1
    { const bool k = c.t; c.r[1] = c.r[3] & 0xFFu; if (k) { goto L_06016DA0; } }  // 06016D8A bt/s 0x06016DA0 ; extu.b r3,r1
    c.t = c.r[1] > c.r[6];  // 06016D8E cmp/hi r6,r1
    { const bool k = !c.t; c.r[1] = c.r[2]; if (k) { goto L_06016D98; } }  // 06016D90 bf/s 0x06016D98 ; mov r2,r1
    c.r[1] += 5;  // 06016D94 add #5,r1
    c.r[2] = c.r[1] & 0xFFu;  // 06016D96 extu.b r1,r2
L_06016D98:
    c.r[4] += 1;  // 06016D98 add #1,r4
    c.r[1] = c.r[0];  // 06016D9A mov r0,r1
    c.r[1] += 1;  // 06016D9C add #1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06016D9E extu.b r1,r0
L_06016DA0:
    c.r[4] += 1;  // 06016DA0 add #1,r4
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[4]);  // 06016DA2 mov.b @r4,r3
    c.r[1] = c.r[3] & 0xFFu;  // 06016DA4 extu.b r3,r1
    c.t = c.r[1] == c.r[7];  // 06016DA6 cmp/eq r7,r1
    { const bool k = !c.t; c.r[1] = c.r[2]; if (k) { SH2_POLL(c); goto L_06016D78; } }  // 06016DA8 bf/s 0x06016D78 ; mov r2,r1
L_06016DAC:
    c.t = (c.r[8] & c.r[8]) == 0;  // 06016DAC tst r8,r8
    { const bool k = !c.t; c.r[2] += 5; if (k) { goto L_06016DC4; } }  // 06016DAE bf/s 0x06016DC4 ; add #5,r2
    c.r[1] = ld32(0x06016DD0u);  // 06016DB2 mov.l 0x06016DD0,r1
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[2] * (int32_t)c.r[1]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 06016DB4 dmuls.l r1,r2
    c.r[1] = c.mach;  // 06016DB6 sts mach,r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06016DB8 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06016DBA shar r1
    c.t = c.r[2] >> 31; c.r[2] <<= 1;  // 06016DBC shll r2
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 06016DBE subc r2,r2
    c.r[1] -= c.r[2];  // 06016DC0 sub r2,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06016DC2 extu.b r1,r0
L_06016DC4:
    c.r[15] = c.r[14];  // 06016DC4 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06016DC6 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06016DC8 rts ; mov.l @r15+,r8
}

void f_06016DD4(SH2Context& c) {
    ran[135] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06016DD4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06016DD6 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06016DD8 mov r15,r14
    c.r[8] = ld32(0x06016E54u);  // 06016DDA mov.l 0x06016E54,r8
    c.r[3] = (uint32_t)(int16_t)ld16(0x06016E46u);  // 06016DDC mov.w 0x06016E46,r3
    c.r[1] = 0x28u;  // 06016DDE mov #40,r1
    c.macl = c.r[4] * c.r[3];  // 06016DE0 mul.l r3,r4
    c.r[5] = (uint32_t)(int16_t)ld16(0x06016E48u);  // 06016DE2 mov.w 0x06016E48,r5
    c.t = (c.r[4] & c.r[4]) == 0;  // 06016DE4 tst r4,r4
    c.r[6] = c.macl;  // 06016DE6 sts macl,r6
    c.r[6] += c.r[8];  // 06016DE8 add r8,r6
    c.r[2] = c.r[6];  // 06016DEA mov r6,r2
    c.r[2] += 65;  // 06016DEC add #65,r2
    st8(c.r[2], c.r[1]);  // 06016DEE mov.b r1,@r2
    c.r[2] = c.r[6];  // 06016DF0 mov r6,r2
    c.r[2] += 66;  // 06016DF2 add #66,r2
    c.r[1] = 0x1Cu;  // 06016DF4 mov #28,r1
    st8(c.r[2], c.r[1]);  // 06016DF6 mov.b r1,@r2
    c.r[1] = c.r[6];  // 06016DF8 mov r6,r1
    c.r[1] += 67;  // 06016DFA add #67,r1
    c.r[2] = 0x0u;  // 06016DFC mov #0,r2
    st8(c.r[1], c.r[2]);  // 06016DFE mov.b r2,@r1
    c.r[1] = c.r[6];  // 06016E00 mov r6,r1
    c.r[1] += 68;  // 06016E02 add #68,r1
    st8(c.r[1], c.r[2]);  // 06016E04 mov.b r2,@r1
    c.r[2] = c.r[6];  // 06016E06 mov r6,r2
    c.r[2] += 70;  // 06016E08 add #70,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06016E4Au);  // 06016E0A mov.w 0x06016E4A,r1
    st16(c.r[2], c.r[1]);  // 06016E0C mov.w r1,@r2
    c.r[2] = (uint32_t)(int16_t)ld16(0x06016E4Cu);  // 06016E0E mov.w 0x06016E4C,r2
    c.r[1] = 0x0u;  // 06016E10 mov #0,r1
    c.r[0] = c.r[6];  // 06016E12 mov r6,r0
    st16(c.r[0] + c.r[5], c.r[1]);  // 06016E14 mov.w r1,@(r0,r5)
    { const bool k = c.t; st16(c.r[0] + c.r[2], c.r[1]); if (k) { goto L_06016E3E; } }  // 06016E16 bt/s 0x06016E3E ; mov.w r1,@(r0,r2)
    c.r[4] -= 1;  // 06016E1A add #-1,r4
    c.macl = c.r[4] * c.r[3];  // 06016E1C mul.l r3,r4
    c.r[7] = (uint32_t)(int16_t)ld16(0x06016E4Eu);  // 06016E1E mov.w 0x06016E4E,r7
    c.r[3] = c.macl;  // 06016E20 sts macl,r3
    c.r[3] += c.r[8];  // 06016E22 add r8,r3
    c.r[0] = c.r[3];  // 06016E24 mov r3,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[7]);  // 06016E26 mov.w @(r0,r7),r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 06016E28 mov.w @(r0,r2),r2
    c.r[1] += c.r[2];  // 06016E2A add r2,r1
    c.r[0] = c.r[6];  // 06016E2C mov r6,r0
    st16(c.r[0] + c.r[7], c.r[1]);  // 06016E2E mov.w r1,@(r0,r7)
    c.r[7] = (uint32_t)(int16_t)ld16(0x06016E50u);  // 06016E30 mov.w 0x06016E50,r7
    c.r[0] = c.r[3];  // 06016E32 mov r3,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[7]);  // 06016E34 mov.w @(r0,r7),r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[5]);  // 06016E36 mov.w @(r0,r5),r2
    c.r[1] += c.r[2];  // 06016E38 add r2,r1
    c.r[0] = c.r[6];  // 06016E3A mov r6,r0
    st16(c.r[0] + c.r[7], c.r[1]);  // 06016E3C mov.w r1,@(r0,r7)
L_06016E3E:
    c.r[15] = c.r[14];  // 06016E3E mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06016E40 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06016E42 rts ; mov.l @r15+,r8
}

void f_06016E58(SH2Context& c) {
    ran[136] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06016E58 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06016E5A mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06016E5C mov r15,r14
    c.r[1] = ld32(c.r[14] + 8);  // 06016E5E mov.l @(8,r14),r1
    c.r[4] = c.r[4] & 0xFFu;  // 06016E60 extu.b r4,r4
    c.r[5] = c.r[5] & 0xFFu;  // 06016E62 extu.b r5,r5
    c.r[8] = c.r[7] & 0xFFu;  // 06016E64 extu.b r7,r8
    c.r[7] = c.r[1] & 0xFFu;  // 06016E66 extu.b r1,r7
    c.r[1] = (uint32_t)(int16_t)ld16(0x06016F8Au);  // 06016E68 mov.w 0x06016F8A,r1
    c.t = c.r[4] == c.r[1];  // 06016E6A cmp/eq r1,r4
    { const bool k = c.t; c.r[6] = c.r[6] & 0xFFu; if (k) { goto L_06016F04; } }  // 06016E6C bt/s 0x06016F04 ; extu.b r6,r6
    c.r[3] = (uint32_t)(int16_t)ld16(0x06016F8Cu);  // 06016E70 mov.w 0x06016F8C,r3
    c.r[2] = ld32(0x06016F94u);  // 06016E72 mov.l 0x06016F94,r2
    c.r[1] = ld32(c.r[2]);  // 06016E74 mov.l @r2,r1
    c.r[0] = ld32(0x06016F98u);  // 06016E76 mov.l 0x06016F98,r0
    c.r[1] += 1;  // 06016E78 add #1,r1
    c.t = c.r[1] >= c.r[0];  // 06016E7A cmp/hs r0,r1
    { const bool k = !c.t; st32(c.r[2], c.r[1]); if (k) { goto L_06016E84; } }  // 06016E7C bf/s 0x06016E84 ; mov.l r1,@r2
    c.r[1] = ld32(0x06016F9Cu);  // 06016E80 mov.l 0x06016F9C,r1
    st32(c.r[2], c.r[1]);  // 06016E82 mov.l r1,@r2
L_06016E84:
    c.r[1] = ld32(c.r[2]);  // 06016E84 mov.l @r2,r1
    st8(c.r[1], c.r[3]);  // 06016E86 mov.b r3,@r1
    c.r[1] = ld32(c.r[2]);  // 06016E88 mov.l @r2,r1
    c.r[3] = 0x0u;  // 06016E8A mov #0,r3
    c.r[1] += 1;  // 06016E8C add #1,r1
    c.t = c.r[1] >= c.r[0];  // 06016E8E cmp/hs r0,r1
    { const bool k = !c.t; st32(c.r[2], c.r[1]); if (k) { goto L_06016E98; } }  // 06016E90 bf/s 0x06016E98 ; mov.l r1,@r2
    c.r[1] = ld32(0x06016F9Cu);  // 06016E94 mov.l 0x06016F9C,r1
    st32(c.r[2], c.r[1]);  // 06016E96 mov.l r1,@r2
L_06016E98:
    c.r[1] = ld32(c.r[2]);  // 06016E98 mov.l @r2,r1
    st8(c.r[1], c.r[3]);  // 06016E9A mov.b r3,@r1
    c.r[1] = c.r[4];  // 06016E9C mov r4,r1
    c.r[1] <<= 2;  // 06016E9E shll2 r1
    c.r[1] += c.r[1];  // 06016EA0 add r1,r1
    c.r[1] <<= 2;  // 06016EA2 shll2 r1
    c.r[3] = c.r[1] & 0xFFu;  // 06016EA4 extu.b r1,r3
    c.r[1] = ld32(c.r[2]);  // 06016EA6 mov.l @r2,r1
    c.r[1] += 1;  // 06016EA8 add #1,r1
    c.t = c.r[1] >= c.r[0];  // 06016EAA cmp/hs r0,r1
    { const bool k = !c.t; st32(c.r[2], c.r[1]); if (k) { goto L_06016EB4; } }  // 06016EAC bf/s 0x06016EB4 ; mov.l r1,@r2
    c.r[1] = ld32(0x06016F9Cu);  // 06016EB0 mov.l 0x06016F9C,r1
    st32(c.r[2], c.r[1]);  // 06016EB2 mov.l r1,@r2
L_06016EB4:
    c.r[1] = ld32(c.r[2]);  // 06016EB4 mov.l @r2,r1
    st8(c.r[1], c.r[3]);  // 06016EB6 mov.b r3,@r1
    c.r[1] = ld32(c.r[2]);  // 06016EB8 mov.l @r2,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x06016F8Eu);  // 06016EBA mov.w 0x06016F8E,r3
    c.r[1] += 1;  // 06016EBC add #1,r1
    c.t = c.r[1] >= c.r[0];  // 06016EBE cmp/hs r0,r1
    { const bool k = !c.t; st32(c.r[2], c.r[1]); if (k) { goto L_06016EC8; } }  // 06016EC0 bf/s 0x06016EC8 ; mov.l r1,@r2
    c.r[1] = ld32(0x06016F9Cu);  // 06016EC4 mov.l 0x06016F9C,r1
    st32(c.r[2], c.r[1]);  // 06016EC6 mov.l r1,@r2
L_06016EC8:
    c.r[1] = ld32(c.r[2]);  // 06016EC8 mov.l @r2,r1
    st8(c.r[1], c.r[3]);  // 06016ECA mov.b r3,@r1
    c.r[1] = ld32(c.r[2]);  // 06016ECC mov.l @r2,r1
    c.r[1] += 1;  // 06016ECE add #1,r1
    c.t = c.r[1] >= c.r[0];  // 06016ED0 cmp/hs r0,r1
    { const bool k = !c.t; st32(c.r[2], c.r[1]); if (k) { goto L_06016EDA; } }  // 06016ED2 bf/s 0x06016EDA ; mov.l r1,@r2
    c.r[1] = ld32(0x06016F9Cu);  // 06016ED6 mov.l 0x06016F9C,r1
    st32(c.r[2], c.r[1]);  // 06016ED8 mov.l r1,@r2
L_06016EDA:
    c.r[1] = ld32(c.r[2]);  // 06016EDA mov.l @r2,r1
    st8(c.r[1], c.r[4]);  // 06016EDC mov.b r4,@r1
    c.r[1] = ld32(c.r[2]);  // 06016EDE mov.l @r2,r1
    c.r[1] += 1;  // 06016EE0 add #1,r1
    c.t = c.r[1] >= c.r[0];  // 06016EE2 cmp/hs r0,r1
    { const bool k = !c.t; st32(c.r[2], c.r[1]); if (k) { goto L_06016EEC; } }  // 06016EE4 bf/s 0x06016EEC ; mov.l r1,@r2
    c.r[1] = ld32(0x06016F9Cu);  // 06016EE8 mov.l 0x06016F9C,r1
    st32(c.r[2], c.r[1]);  // 06016EEA mov.l r1,@r2
L_06016EEC:
    c.r[1] = ld32(c.r[2]);  // 06016EEC mov.l @r2,r1
    c.r[3] = 0x0u;  // 06016EEE mov #0,r3
    st8(c.r[1], c.r[3]);  // 06016EF0 mov.b r3,@r1
    c.r[1] = ld32(c.r[2]);  // 06016EF2 mov.l @r2,r1
    c.r[1] += 1;  // 06016EF4 add #1,r1
    c.t = c.r[1] >= c.r[0];  // 06016EF6 cmp/hs r0,r1
    { const bool k = !c.t; st32(c.r[2], c.r[1]); if (k) { goto L_06016F00; } }  // 06016EF8 bf/s 0x06016F00 ; mov.l r1,@r2
    c.r[1] = ld32(0x06016F9Cu);  // 06016EFC mov.l 0x06016F9C,r1
    st32(c.r[2], c.r[1]);  // 06016EFE mov.l r1,@r2
L_06016F00:
    c.r[1] = ld32(c.r[2]);  // 06016F00 mov.l @r2,r1
    st8(c.r[1], c.r[3]);  // 06016F02 mov.b r3,@r1
L_06016F04:
    c.r[2] = (uint32_t)(int16_t)ld16(0x06016F90u);  // 06016F04 mov.w 0x06016F90,r2
    c.r[3] = ld32(0x06016F94u);  // 06016F06 mov.l 0x06016F94,r3
    c.r[1] = ld32(c.r[3]);  // 06016F08 mov.l @r3,r1
    c.r[0] = ld32(0x06016F98u);  // 06016F0A mov.l 0x06016F98,r0
    c.r[1] += 1;  // 06016F0C add #1,r1
    c.t = c.r[1] >= c.r[0];  // 06016F0E cmp/hs r0,r1
    { const bool k = !c.t; st32(c.r[3], c.r[1]); if (k) { goto L_06016F18; } }  // 06016F10 bf/s 0x06016F18 ; mov.l r1,@r3
    c.r[1] = ld32(0x06016F9Cu);  // 06016F14 mov.l 0x06016F9C,r1
    st32(c.r[3], c.r[1]);  // 06016F16 mov.l r1,@r3
L_06016F18:
    c.r[1] = ld32(c.r[3]);  // 06016F18 mov.l @r3,r1
    st8(c.r[1], c.r[2]);  // 06016F1A mov.b r2,@r1
    c.r[1] = ld32(c.r[3]);  // 06016F1C mov.l @r3,r1
    c.r[1] += 1;  // 06016F1E add #1,r1
    c.t = c.r[1] >= c.r[0];  // 06016F20 cmp/hs r0,r1
    { const bool k = !c.t; st32(c.r[3], c.r[1]); if (k) { goto L_06016F2A; } }  // 06016F22 bf/s 0x06016F2A ; mov.l r1,@r3
    c.r[1] = ld32(0x06016F9Cu);  // 06016F26 mov.l 0x06016F9C,r1
    st32(c.r[3], c.r[1]);  // 06016F28 mov.l r1,@r3
L_06016F2A:
    c.r[1] = ld32(c.r[3]);  // 06016F2A mov.l @r3,r1
    st8(c.r[1], c.r[5]);  // 06016F2C mov.b r5,@r1
    c.r[1] = ld32(c.r[3]);  // 06016F2E mov.l @r3,r1
    c.r[1] += 1;  // 06016F30 add #1,r1
    c.t = c.r[1] >= c.r[0];  // 06016F32 cmp/hs r0,r1
    { const bool k = !c.t; st32(c.r[3], c.r[1]); if (k) { goto L_06016F3C; } }  // 06016F34 bf/s 0x06016F3C ; mov.l r1,@r3
    c.r[1] = ld32(0x06016F9Cu);  // 06016F38 mov.l 0x06016F9C,r1
    st32(c.r[3], c.r[1]);  // 06016F3A mov.l r1,@r3
L_06016F3C:
    c.r[1] = ld32(c.r[3]);  // 06016F3C mov.l @r3,r1
    st8(c.r[1], c.r[6]);  // 06016F3E mov.b r6,@r1
    c.r[1] = ld32(c.r[3]);  // 06016F40 mov.l @r3,r1
    c.r[1] += 1;  // 06016F42 add #1,r1
    c.t = c.r[1] >= c.r[0];  // 06016F44 cmp/hs r0,r1
    { const bool k = !c.t; st32(c.r[3], c.r[1]); if (k) { goto L_06016F4E; } }  // 06016F46 bf/s 0x06016F4E ; mov.l r1,@r3
    c.r[1] = ld32(0x06016F9Cu);  // 06016F4A mov.l 0x06016F9C,r1
    st32(c.r[3], c.r[1]);  // 06016F4C mov.l r1,@r3
L_06016F4E:
    c.r[1] = ld32(c.r[3]);  // 06016F4E mov.l @r3,r1
    st8(c.r[1], c.r[8]);  // 06016F50 mov.b r8,@r1
    c.r[1] = ld32(c.r[3]);  // 06016F52 mov.l @r3,r1
    c.r[1] += 1;  // 06016F54 add #1,r1
    c.t = c.r[1] >= c.r[0];  // 06016F56 cmp/hs r0,r1
    { const bool k = !c.t; st32(c.r[3], c.r[1]); if (k) { goto L_06016F60; } }  // 06016F58 bf/s 0x06016F60 ; mov.l r1,@r3
    c.r[1] = ld32(0x06016F9Cu);  // 06016F5C mov.l 0x06016F9C,r1
    st32(c.r[3], c.r[1]);  // 06016F5E mov.l r1,@r3
L_06016F60:
    c.r[1] = ld32(c.r[3]);  // 06016F60 mov.l @r3,r1
    c.r[2] = 0x0u;  // 06016F62 mov #0,r2
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[7];  // 06016F64 cmp/ge r7,r2
    { const bool k = c.t; st8(c.r[1], c.r[7]); if (k) { goto L_06016F84; } }  // 06016F66 bt/s 0x06016F84 ; mov.b r7,@r1
    c.r[5] = c.r[0];  // 06016F6A mov r0,r5
    c.r[6] = ld32(0x06016F9Cu);  // 06016F6C mov.l 0x06016F9C,r6
L_06016F6E:
    c.r[1] = ld32(c.r[3]);  // 06016F6E mov.l @r3,r1
    c.r[1] += 1;  // 06016F70 add #1,r1
    c.t = c.r[1] >= c.r[5];  // 06016F72 cmp/hs r5,r1
    { const bool k = !c.t; st32(c.r[3], c.r[1]); if (k) { goto L_06016F7A; } }  // 06016F74 bf/s 0x06016F7A ; mov.l r1,@r3
    st32(c.r[3], c.r[6]);  // 06016F78 mov.l r6,@r3
L_06016F7A:
    c.r[1] = ld32(c.r[3]);  // 06016F7A mov.l @r3,r1
    c.r[2] += 1;  // 06016F7C add #1,r2
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[7];  // 06016F7E cmp/ge r7,r2
    { const bool k = !c.t; st8(c.r[1], c.r[8]); if (k) { SH2_POLL(c); goto L_06016F6E; } }  // 06016F80 bf/s 0x06016F6E ; mov.b r8,@r1
L_06016F84:
    c.r[2] = ld32(0x06016F94u);  // 06016F84 mov.l 0x06016F94,r2
    c.r[1] = ld32(c.r[2]); goto L_06016FA0;  // 06016F86 bra 0x06016FA0 ; mov.l @r2,r1
L_06016FA0:
    c.r[3] = ld32(0x06016FECu);  // 06016FA0 mov.l 0x06016FEC,r3
    c.r[1] += 1;  // 06016FA2 add #1,r1
    c.t = c.r[1] >= c.r[3];  // 06016FA4 cmp/hs r3,r1
    { const bool k = !c.t; st32(c.r[2], c.r[1]); if (k) { goto L_06016FAE; } }  // 06016FA6 bf/s 0x06016FAE ; mov.l r1,@r2
    c.r[1] = ld32(0x06016FF0u);  // 06016FAA mov.l 0x06016FF0,r1
    st32(c.r[2], c.r[1]);  // 06016FAC mov.l r1,@r2
L_06016FAE:
    c.r[1] = ld32(c.r[2]);  // 06016FAE mov.l @r2,r1
    st8(c.r[1], c.r[8]);  // 06016FB0 mov.b r8,@r1
    c.r[1] = (uint32_t)(int16_t)ld16(0x06016FE6u);  // 06016FB2 mov.w 0x06016FE6,r1
    c.t = c.r[4] == c.r[1];  // 06016FB4 cmp/eq r1,r4
    if (c.t) { goto L_06016FDE; }  // 06016FB6 bt 0x06016FDE
    c.r[1] = ld32(c.r[2]);  // 06016FB8 mov.l @r2,r1
    c.r[7] = (uint32_t)(int16_t)ld16(0x06016FE8u);  // 06016FBA mov.w 0x06016FE8,r7
    c.r[1] += 1;  // 06016FBC add #1,r1
    c.t = c.r[1] >= c.r[3];  // 06016FBE cmp/hs r3,r1
    { const bool k = !c.t; st32(c.r[2], c.r[1]); if (k) { goto L_06016FC8; } }  // 06016FC0 bf/s 0x06016FC8 ; mov.l r1,@r2
    c.r[1] = ld32(0x06016FF0u);  // 06016FC4 mov.l 0x06016FF0,r1
    st32(c.r[2], c.r[1]);  // 06016FC6 mov.l r1,@r2
L_06016FC8:
    c.r[1] = ld32(c.r[2]);  // 06016FC8 mov.l @r2,r1
    st8(c.r[1], c.r[7]);  // 06016FCA mov.b r7,@r1
    c.r[1] = ld32(c.r[2]);  // 06016FCC mov.l @r2,r1
    c.r[1] += 1;  // 06016FCE add #1,r1
    c.t = c.r[1] >= c.r[3];  // 06016FD0 cmp/hs r3,r1
    { const bool k = !c.t; st32(c.r[2], c.r[1]); if (k) { goto L_06016FDA; } }  // 06016FD2 bf/s 0x06016FDA ; mov.l r1,@r2
    c.r[1] = ld32(0x06016FF0u);  // 06016FD6 mov.l 0x06016FF0,r1
    st32(c.r[2], c.r[1]);  // 06016FD8 mov.l r1,@r2
L_06016FDA:
    c.r[1] = ld32(c.r[2]);  // 06016FDA mov.l @r2,r1
    st8(c.r[1], c.r[4]);  // 06016FDC mov.b r4,@r1
L_06016FDE:
    c.r[15] = c.r[14];  // 06016FDE mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06016FE0 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06016FE2 rts ; mov.l @r15+,r8
}

void f_06016FF4(SH2Context& c) {
    ran[137] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06016FF4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06016FF6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06016FF8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06016FFA mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06016FFC mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06016FFE mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06017000 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06017002 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06017004 mov r15,r14
    c.r[13] = c.r[4] & 0xFFu;  // 06017006 extu.b r4,r13
    c.r[9] = c.r[5] & 0xFFu;  // 06017008 extu.b r5,r9
    c.r[10] = c.r[6] & 0xFFu;  // 0601700A extu.b r6,r10
    c.r[1] = 0u - c.r[9];  // 0601700C neg r9,r1
    c.r[1] += 39;  // 0601700E add #39,r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06017010 shar r1
    c.r[11] = c.r[1] & 0xFFu;  // 06017012 extu.b r1,r11
    c.r[12] = 0xBu;  // 06017014 mov #11,r12
    c.r[7] = (uint32_t)(int16_t)ld16(0x0601714Au);  // 06017016 mov.w 0x0601714A,r7
    c.r[2] = ld32(0x06017154u);  // 06017018 mov.l 0x06017154,r2
    c.r[1] = ld32(c.r[2]);  // 0601701A mov.l @r2,r1
    c.r[3] = ld32(0x06017158u);  // 0601701C mov.l 0x06017158,r3
    c.r[1] += 1;  // 0601701E add #1,r1
    c.t = c.r[1] >= c.r[3];  // 06017020 cmp/hs r3,r1
    { const bool k = !c.t; st32(c.r[2], c.r[1]); if (k) { goto L_0601702A; } }  // 06017022 bf/s 0x0601702A ; mov.l r1,@r2
    c.r[1] = ld32(0x0601715Cu);  // 06017026 mov.l 0x0601715C,r1
    st32(c.r[2], c.r[1]);  // 06017028 mov.l r1,@r2
L_0601702A:
    c.r[1] = ld32(c.r[2]);  // 0601702A mov.l @r2,r1
    st8(c.r[1], c.r[7]);  // 0601702C mov.b r7,@r1
    c.r[1] = ld32(c.r[2]);  // 0601702E mov.l @r2,r1
    c.r[1] += 1;  // 06017030 add #1,r1
    c.t = c.r[1] >= c.r[3];  // 06017032 cmp/hs r3,r1
    { const bool k = !c.t; st32(c.r[2], c.r[1]); if (k) { goto L_0601703C; } }  // 06017034 bf/s 0x0601703C ; mov.l r1,@r2
    c.r[1] = ld32(0x0601715Cu);  // 06017038 mov.l 0x0601715C,r1
    st32(c.r[2], c.r[1]);  // 0601703A mov.l r1,@r2
L_0601703C:
    c.r[1] = ld32(c.r[2]);  // 0601703C mov.l @r2,r1
    st8(c.r[1], c.r[11]);  // 0601703E mov.b r11,@r1
    c.r[1] = ld32(c.r[2]);  // 06017040 mov.l @r2,r1
    c.r[1] += 1;  // 06017042 add #1,r1
    c.t = c.r[1] >= c.r[3];  // 06017044 cmp/hs r3,r1
    { const bool k = !c.t; st32(c.r[2], c.r[1]); if (k) { goto L_0601704E; } }  // 06017046 bf/s 0x0601704E ; mov.l r1,@r2
    c.r[1] = ld32(0x0601715Cu);  // 0601704A mov.l 0x0601715C,r1
    st32(c.r[2], c.r[1]);  // 0601704C mov.l r1,@r2
L_0601704E:
    c.r[1] = ld32(c.r[2]);  // 0601704E mov.l @r2,r1
    st8(c.r[1], c.r[12]);  // 06017050 mov.b r12,@r1
    c.r[1] = ld32(c.r[2]);  // 06017052 mov.l @r2,r1
    c.r[1] += 1;  // 06017054 add #1,r1
    c.t = c.r[1] >= c.r[3];  // 06017056 cmp/hs r3,r1
    { const bool k = !c.t; st32(c.r[2], c.r[1]); if (k) { goto L_06017060; } }  // 06017058 bf/s 0x06017060 ; mov.l r1,@r2
    c.r[1] = ld32(0x0601715Cu);  // 0601705C mov.l 0x0601715C,r1
    st32(c.r[2], c.r[1]);  // 0601705E mov.l r1,@r2
L_06017060:
    c.r[1] = ld32(c.r[2]);  // 06017060 mov.l @r2,r1
    st8(c.r[1], c.r[9]);  // 06017062 mov.b r9,@r1
    c.r[1] = ld32(c.r[2]);  // 06017064 mov.l @r2,r1
    c.r[7] = 0x2u;  // 06017066 mov #2,r7
    c.r[1] += 1;  // 06017068 add #1,r1
    c.t = c.r[1] >= c.r[3];  // 0601706A cmp/hs r3,r1
    { const bool k = !c.t; st32(c.r[2], c.r[1]); if (k) { goto L_06017074; } }  // 0601706C bf/s 0x06017074 ; mov.l r1,@r2
    c.r[1] = ld32(0x0601715Cu);  // 06017070 mov.l 0x0601715C,r1
    st32(c.r[2], c.r[1]);  // 06017072 mov.l r1,@r2
L_06017074:
    c.r[1] = ld32(c.r[2]);  // 06017074 mov.l @r2,r1
    st8(c.r[1], c.r[7]);  // 06017076 mov.b r7,@r1
    c.r[1] = ld32(c.r[2]);  // 06017078 mov.l @r2,r1
    c.r[1] += 1;  // 0601707A add #1,r1
    c.t = c.r[1] >= c.r[3];  // 0601707C cmp/hs r3,r1
    { const bool k = !c.t; st32(c.r[2], c.r[1]); if (k) { goto L_06017086; } }  // 0601707E bf/s 0x06017086 ; mov.l r1,@r2
    c.r[1] = ld32(0x0601715Cu);  // 06017082 mov.l 0x0601715C,r1
    st32(c.r[2], c.r[1]);  // 06017084 mov.l r1,@r2
L_06017086:
    c.r[1] = ld32(c.r[2]);  // 06017086 mov.l @r2,r1
    st8(c.r[1], c.r[9]);  // 06017088 mov.b r9,@r1
    c.r[1] = ld32(c.r[2]);  // 0601708A mov.l @r2,r1
    c.r[1] += 1;  // 0601708C add #1,r1
    c.t = c.r[1] >= c.r[3];  // 0601708E cmp/hs r3,r1
    { const bool k = !c.t; st32(c.r[2], c.r[1]); if (k) { goto L_06017098; } }  // 06017090 bf/s 0x06017098 ; mov.l r1,@r2
    c.r[1] = ld32(0x0601715Cu);  // 06017094 mov.l 0x0601715C,r1
    st32(c.r[2], c.r[1]);  // 06017096 mov.l r1,@r2
L_06017098:
    c.r[1] = ld32(c.r[2]);  // 06017098 mov.l @r2,r1
    st8(c.r[1], c.r[9]);  // 0601709A mov.b r9,@r1
    c.r[1] = ld32(c.r[2]);  // 0601709C mov.l @r2,r1
    c.r[1] += 1;  // 0601709E add #1,r1
    c.t = c.r[1] >= c.r[3];  // 060170A0 cmp/hs r3,r1
    { const bool k = !c.t; st32(c.r[2], c.r[1]); if (k) { goto L_060170AA; } }  // 060170A2 bf/s 0x060170AA ; mov.l r1,@r2
    c.r[1] = ld32(0x0601715Cu);  // 060170A6 mov.l 0x0601715C,r1
    st32(c.r[2], c.r[1]);  // 060170A8 mov.l r1,@r2
L_060170AA:
    c.r[4] = ld32(0x06017160u);  // 060170AA mov.l 0x06017160,r4
    c.r[8] = ld32(0x06017164u);  // 060170AC mov.l 0x06017164,r8
    c.r[1] = ld32(c.r[2]);  // 060170AE mov.l @r2,r1
    c.r[5] = 0x17u;  // 060170B0 mov #23,r5
    { const uint32_t x = c.r[8]; c.pr = 0x060170B6u; st8(c.r[1], c.r[9]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060170B6u) return; }  // 060170B2 jsr @r8 ; mov.b r9,@r1
    c.r[5] = 0xAu;  // 060170B6 mov #10,r5
    { const uint32_t x = c.r[8]; c.pr = 0x060170BCu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060170BCu) return; }  // 060170B8 jsr @r8 ; mov r0,r4
    c.r[5] = c.r[10];  // 060170BC mov r10,r5
    { const uint32_t x = c.r[8]; c.pr = 0x060170C2u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060170C2u) return; }  // 060170BE jsr @r8 ; mov r0,r4
    c.r[5] = c.r[0];  // 060170C2 mov r0,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[5]);  // 060170C4 mov.b @r5,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x0601714Cu);  // 060170C6 mov.w 0x0601714C,r3
    c.r[1] = c.r[1] & 0xFFu;  // 060170C8 extu.b r1,r1
    c.t = c.r[1] == c.r[3];  // 060170CA cmp/eq r3,r1
    { const bool k = c.t; c.r[2] = 0x0u; if (k) { goto L_06017102; } }  // 060170CC bt/s 0x06017102 ; mov #0,r2
    c.r[4] = 0xAu;  // 060170D0 mov #10,r4
    c.r[6] = (uint32_t)(int16_t)ld16(0x0601714Eu);  // 060170D2 mov.w 0x0601714E,r6
    c.r[7] = c.r[3];  // 060170D4 mov r3,r7
    c.r[1] = c.r[2];  // 060170D6 mov r2,r1
L_060170D8:
    c.r[1] += 10;  // 060170D8 add #10,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0]);  // 060170DA mov.b @r0,r3
    c.r[2] = c.r[1] & 0xFFu;  // 060170DC extu.b r1,r2
    c.r[1] = c.r[3];  // 060170DE mov r3,r1
    c.r[1] += 21;  // 060170E0 add #21,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060170E2 extu.b r1,r1
    c.t = c.r[1] > c.r[4];  // 060170E4 cmp/hi r4,r1
    { const bool k = c.t; c.r[1] = c.r[3] & 0xFFu; if (k) { goto L_060170F6; } }  // 060170E6 bt/s 0x060170F6 ; extu.b r3,r1
    c.t = c.r[1] > c.r[6];  // 060170EA cmp/hi r6,r1
    { const bool k = !c.t; c.r[1] = c.r[2]; if (k) { goto L_060170F4; } }  // 060170EC bf/s 0x060170F4 ; mov r2,r1
    c.r[1] += 5;  // 060170F0 add #5,r1
    c.r[2] = c.r[1] & 0xFFu;  // 060170F2 extu.b r1,r2
L_060170F4:
    c.r[0] += 1;  // 060170F4 add #1,r0
L_060170F6:
    c.r[0] += 1;  // 060170F6 add #1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 060170F8 mov.b @r0,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060170FA extu.b r1,r1
    c.t = c.r[1] == c.r[7];  // 060170FC cmp/eq r7,r1
    { const bool k = !c.t; c.r[1] = c.r[2]; if (k) { SH2_POLL(c); goto L_060170D8; } }  // 060170FE bf/s 0x060170D8 ; mov r2,r1
L_06017102:
    c.r[2] += 5;  // 06017102 add #5,r2
    c.r[1] = ld32(0x06017168u);  // 06017104 mov.l 0x06017168,r1
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[2] * (int32_t)c.r[1]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 06017106 dmuls.l r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x06017150u);  // 06017108 mov.w 0x06017150,r3
    c.r[1] = c.mach;  // 0601710A sts mach,r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0601710C shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0601710E shar r1
    c.t = c.r[2] >> 31; c.r[2] <<= 1;  // 06017110 shll r2
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 06017112 subc r2,r2
    c.r[1] -= c.r[2];  // 06017114 sub r2,r1
    c.r[6] = c.r[1] & 0xFFu;  // 06017116 extu.b r1,r6
    c.r[2] = ld32(0x06017154u);  // 06017118 mov.l 0x06017154,r2
    c.r[1] = ld32(c.r[2]);  // 0601711A mov.l @r2,r1
    c.r[7] = ld32(0x06017158u);  // 0601711C mov.l 0x06017158,r7
    c.r[1] += 1;  // 0601711E add #1,r1
    c.t = c.r[1] >= c.r[7];  // 06017120 cmp/hs r7,r1
    { const bool k = !c.t; st32(c.r[2], c.r[1]); if (k) { goto L_0601712A; } }  // 06017122 bf/s 0x0601712A ; mov.l r1,@r2
    c.r[1] = ld32(0x0601715Cu);  // 06017126 mov.l 0x0601715C,r1
    st32(c.r[2], c.r[1]);  // 06017128 mov.l r1,@r2
L_0601712A:
    c.r[9] -= c.r[6];  // 0601712A sub r6,r9
    c.t = c.r[9] & 1; c.r[9] = (uint32_t)((int32_t)c.r[9] >> 1);  // 0601712C shar r9
    c.r[11] += c.r[9];  // 0601712E add r9,r11
    c.r[1] = ld32(c.r[2]);  // 06017130 mov.l @r2,r1
    c.r[11] += 1;  // 06017132 add #1,r11
    st8(c.r[1], c.r[3]);  // 06017134 mov.b r3,@r1
    c.r[1] = ld32(c.r[2]);  // 06017136 mov.l @r2,r1
    c.r[3] = c.r[11] & 0xFFu;  // 06017138 extu.b r11,r3
    c.r[1] += 1;  // 0601713A add #1,r1
    c.t = c.r[1] >= c.r[7];  // 0601713C cmp/hs r7,r1
    { const bool k = !c.t; st32(c.r[2], c.r[1]); if (k) { goto L_06017146; } }  // 0601713E bf/s 0x06017146 ; mov.l r1,@r2
    c.r[1] = ld32(0x0601715Cu);  // 06017142 mov.l 0x0601715C,r1
    st32(c.r[2], c.r[1]);  // 06017144 mov.l r1,@r2
L_06017146:
    c.r[12] += 1; goto L_0601716C;  // 06017146 bra 0x0601716C ; add #1,r12
L_0601716C:
    c.r[13] <<= 2;  // 0601716C shll2 r13
    c.r[13] += c.r[13];  // 0601716E add r13,r13
    c.r[13] <<= 2;  // 06017170 shll2 r13
    c.r[1] = ld32(c.r[2]);  // 06017172 mov.l @r2,r1
    c.r[12] |= c.r[13];  // 06017174 or r13,r12
    st8(c.r[1], c.r[3]);  // 06017176 mov.b r3,@r1
    c.r[1] = ld32(c.r[2]);  // 06017178 mov.l @r2,r1
    c.r[3] = c.r[12] & 0xFFu;  // 0601717A extu.b r12,r3
    c.r[1] += 1;  // 0601717C add #1,r1
    c.t = c.r[1] >= c.r[7];  // 0601717E cmp/hs r7,r1
    { const bool k = !c.t; st32(c.r[2], c.r[1]); if (k) { goto L_06017188; } }  // 06017180 bf/s 0x06017188 ; mov.l r1,@r2
    c.r[1] = ld32(0x06017200u);  // 06017184 mov.l 0x06017200,r1
    st32(c.r[2], c.r[1]);  // 06017186 mov.l r1,@r2
L_06017188:
    c.r[6] = 0x0u;  // 06017188 mov #0,r6
    c.r[1] = ld32(c.r[2]);  // 0601718A mov.l @r2,r1
    st8(c.r[1], c.r[3]);  // 0601718C mov.b r3,@r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[5]);  // 0601718E mov.b @r5,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x060171FAu);  // 06017190 mov.w 0x060171FA,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06017192 extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 06017194 cmp/eq r2,r1
    { const bool k = c.t; c.r[0] = c.r[5]; if (k) { goto L_060171CA; } }  // 06017196 bt/s 0x060171CA ; mov r5,r0
    c.r[4] = 0xAu;  // 0601719A mov #10,r4
    c.r[7] = (uint32_t)(int16_t)ld16(0x060171FCu);  // 0601719C mov.w 0x060171FC,r7
    c.r[3] = c.r[2];  // 0601719E mov r2,r3
    c.r[1] = c.r[6];  // 060171A0 mov r6,r1
L_060171A2:
    c.r[1] += 1;  // 060171A2 add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0]);  // 060171A4 mov.b @r0,r2
    c.r[6] = c.r[1] & 0xFFu;  // 060171A6 extu.b r1,r6
    c.r[1] = c.r[2];  // 060171A8 mov r2,r1
    c.r[1] += 21;  // 060171AA add #21,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060171AC extu.b r1,r1
    c.t = c.r[1] > c.r[4];  // 060171AE cmp/hi r4,r1
    { const bool k = c.t; c.r[1] = c.r[2] & 0xFFu; if (k) { goto L_060171BE; } }  // 060171B0 bt/s 0x060171BE ; extu.b r2,r1
    c.t = c.r[1] > c.r[7];  // 060171B4 cmp/hi r7,r1
    c.r[0] += 1;  // 060171B6 add #1,r0
    c.r[1] = c.r[6];  // 060171B8 mov r6,r1
    c.r[1] += 1;  // 060171BA add #1,r1
    c.r[6] = c.r[1] & 0xFFu;  // 060171BC extu.b r1,r6
L_060171BE:
    c.r[0] += 1;  // 060171BE add #1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 060171C0 mov.b @r0,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060171C2 extu.b r1,r1
    c.t = c.r[1] == c.r[3];  // 060171C4 cmp/eq r3,r1
    { const bool k = !c.t; c.r[1] = c.r[6]; if (k) { SH2_POLL(c); goto L_060171A2; } }  // 060171C6 bf/s 0x060171A2 ; mov r6,r1
L_060171CA:
    c.r[3] = ld32(0x06017204u);  // 060171CA mov.l 0x06017204,r3
    c.r[2] = ld32(c.r[3]);  // 060171CC mov.l @r3,r2
    c.r[1] = ld32(0x06017208u);  // 060171CE mov.l 0x06017208,r1
    c.r[2] += 1;  // 060171D0 add #1,r2
    c.t = c.r[2] >= c.r[1];  // 060171D2 cmp/hs r1,r2
    { const bool k = !c.t; st32(c.r[3], c.r[2]); if (k) { goto L_060171DC; } }  // 060171D4 bf/s 0x060171DC ; mov.l r2,@r3
    c.r[1] = ld32(0x06017200u);  // 060171D8 mov.l 0x06017200,r1
    st32(c.r[3], c.r[1]);  // 060171DA mov.l r1,@r3
L_060171DC:
    c.r[1] = ld32(c.r[3]);  // 060171DC mov.l @r3,r1
    st8(c.r[1], c.r[6]);  // 060171DE mov.b r6,@r1
    c.r[1] = ld32(0x0601720Cu);  // 060171E0 mov.l 0x0601720C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060171E6u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060171E6u) return; }  // 060171E2 jsr @r1 ; mov #1,r4
    c.r[15] = c.r[14];  // 060171E6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060171E8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060171EA mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060171EC mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060171EE mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060171F0 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060171F2 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060171F4 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060171F6 rts ; mov.l @r15+,r8
}

void f_06017210(SH2Context& c) {
    ran[138] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06017210 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06017212 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06017214 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06017216 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06017218 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601721A sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0601721C mov r15,r14
    c.r[11] = c.r[5];  // 0601721E mov r5,r11
    c.r[4] = c.r[4] & 0xFFu;  // 06017220 extu.b r4,r4
    c.r[3] = ld32(0x06017284u);  // 06017222 mov.l 0x06017284,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601727Cu);  // 06017224 mov.w 0x0601727C,r1
    c.macl = c.r[4] * c.r[1];  // 06017226 mul.l r1,r4
    c.r[2] = ld32(0x06017288u);  // 06017228 mov.l 0x06017288,r2
    c.r[10] = (uint32_t)(int16_t)ld16(0x0601727Eu);  // 0601722A mov.w 0x0601727E,r10
    c.r[9] = c.macl;  // 0601722C sts macl,r9
    c.r[9] += c.r[2];  // 0601722E add r2,r9
    c.r[1] = (uint32_t)(int16_t)ld16(0x06017280u);  // 06017230 mov.w 0x06017280,r1
    c.r[0] = c.r[9];  // 06017232 mov r9,r0
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06017234 mov.w @(r0,r1),r8
    c.r[6] = ld32(0x0601728Cu);  // 06017236 mov.l 0x0601728C,r6
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[10]);  // 06017238 mov.w @(r0,r10),r1
    c.r[4] = c.r[3];  // 0601723A mov r3,r4
    c.r[8] += c.r[1];  // 0601723C add r1,r8
    c.r[1] = (uint32_t)(int16_t)ld16(0x06017282u);  // 0601723E mov.w 0x06017282,r1
    c.r[0] = c.r[2];  // 06017240 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06017242 mov.b @(r0,r1),r1
    c.r[8] = c.r[8] & 0xFFFFu;  // 06017244 extu.w r8,r8
    c.r[2] = 0xFu;  // 06017246 mov #15,r2
    c.r[2] &= c.r[1];  // 06017248 and r1,r2
    c.r[1] = c.r[2];  // 0601724A mov r2,r1
    c.r[1] <<= 2;  // 0601724C shll2 r1
    c.r[1] <<= 2;  // 0601724E shll2 r1
    c.r[2] |= c.r[1];  // 06017250 or r1,r2
    c.r[0] = ld32(0x06017290u);  // 06017252 mov.l 0x06017290,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06017258u; c.r[5] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06017258u) return; }  // 06017254 jsr @r0 ; mov r2,r5
    c.r[1] = c.r[9];  // 06017258 mov r9,r1
    c.r[1] += 72;  // 0601725A add #72,r1
    st16(c.r[1], c.r[8]);  // 0601725C mov.w r8,@r1
    c.r[1] = ld32(0x06017294u);  // 0601725E mov.l 0x06017294,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06017264u; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06017264u) return; }  // 06017260 jsr @r1 ; mov r11,r4
    c.r[0] = c.r[9];  // 06017264 mov r9,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[10]);  // 06017266 mov.w @(r0,r10),r1
    c.r[15] = c.r[14];  // 06017268 mov r14,r15
    c.r[1] += 1;  // 0601726A add #1,r1
    st16(c.r[0] + c.r[10], c.r[1]);  // 0601726C mov.w r1,@(r0,r10)
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601726E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06017270 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06017272 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06017274 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06017276 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06017278 rts ; mov.l @r15+,r8
}

void f_06017298(SH2Context& c) {
    ran[139] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06017298 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0601729A mov r15,r14
    c.r[0] = c.r[4];  // 0601729C mov r4,r0
    c.r[2] = 0x0u;  // 0601729E mov #0,r2
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[5];  // 060172A0 cmp/ge r5,r2
    { const bool k = c.t; c.r[3] = c.r[0]; if (k) { goto L_060172D2; } }  // 060172A2 bt/s 0x060172D2 ; mov r0,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x060172E6u);  // 060172A6 mov.w 0x060172E6,r7
L_060172A8:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060172A8 mov.b @r3,r0
    c.r[1] = c.r[0] & 0xFFu;  // 060172AA extu.b r0,r1
    c.t = c.r[1] == c.r[7];  // 060172AC cmp/eq r7,r1
    { const bool k = c.t; c.r[0] &= 0xC0u; if (k) { goto L_060172D2; } }  // 060172AE bt/s 0x060172D2 ; and #192,r0
    c.r[0] >>= 2;  // 060172B2 shlr2 r0
    c.r[0] >>= 2;  // 060172B4 shlr2 r0
    c.r[0] >>= 2;  // 060172B6 shlr2 r0
    c.t = c.r[0] == 0x1u;  // 060172B8 cmp/eq #1,r0
    { const bool k = c.t; c.t = c.r[0] == 0x2u; if (k) { goto L_060172C6; } }  // 060172BA bt/s 0x060172C6 ; cmp/eq #2,r0
    if (c.t) { goto L_060172CA; }  // 060172BE bt 0x060172CA
    c.r[3] += 4;  // 060172C0 add #4,r3
    c.r[2] += 1; goto L_060172CE;  // 060172C2 bra 0x060172CE ; add #1,r2
L_060172C6:
    c.r[3] += 10; goto L_060172CC;  // 060172C6 bra 0x060172CC ; add #10,r3
L_060172CA:
    c.r[3] += 8;  // 060172CA add #8,r3
L_060172CC:
    c.r[2] += 1;  // 060172CC add #1,r2
L_060172CE:
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[5];  // 060172CE cmp/ge r5,r2
    if (!c.t) { SH2_POLL(c); goto L_060172A8; }  // 060172D0 bf 0x060172A8
L_060172D2:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060172D2 mov.b @r3,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x060172E6u);  // 060172D4 mov.w 0x060172E6,r2
    c.r[1] = c.r[1] & 0xFFu;  // 060172D6 extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 060172D8 cmp/eq r2,r1
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_060172E0; } }  // 060172DA bt/s 0x060172E0 ; mov #0,r0
    c.r[0] = c.r[3];  // 060172DE mov r3,r0
L_060172E0:
    c.r[15] = c.r[14];  // 060172E0 mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060172E2 rts ; mov.l @r15+,r14
}

void f_060172E8(SH2Context& c) {
    ran[140] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060172E8 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 060172EA mov r15,r14
    c.r[2] = 0x0u;  // 060172EC mov #0,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x06017322u);  // 060172EE mov.w 0x06017322,r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4]); goto L_06017312;  // 060172F0 bra 0x06017312 ; mov.b @r4,r0
L_060172F4:
    c.r[0] >>= 2;  // 060172F4 shlr2 r0
    c.r[0] >>= 2;  // 060172F6 shlr2 r0
    c.r[0] >>= 2;  // 060172F8 shlr2 r0
    c.t = c.r[0] == 0x1u;  // 060172FA cmp/eq #1,r0
    { const bool k = c.t; c.t = c.r[0] == 0x2u; if (k) { goto L_06017308; } }  // 060172FC bt/s 0x06017308 ; cmp/eq #2,r0
    if (c.t) { goto L_0601730C; }  // 06017300 bt 0x0601730C
    c.r[4] += 4;  // 06017302 add #4,r4
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4]); goto L_06017310;  // 06017304 bra 0x06017310 ; mov.b @r4,r0
L_06017308:
    c.r[4] += 10; goto L_0601730E;  // 06017308 bra 0x0601730E ; add #10,r4
L_0601730C:
    c.r[4] += 8;  // 0601730C add #8,r4
L_0601730E:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4]);  // 0601730E mov.b @r4,r0
L_06017310:
    c.r[2] += 1;  // 06017310 add #1,r2
L_06017312:
    c.r[1] = c.r[0] & 0xFFu;  // 06017312 extu.b r0,r1
    c.t = c.r[1] == c.r[3];  // 06017314 cmp/eq r3,r1
    { const bool k = !c.t; c.r[0] &= 0xC0u; if (k) { SH2_POLL(c); goto L_060172F4; } }  // 06017316 bf/s 0x060172F4 ; and #192,r0
    c.r[15] = c.r[14];  // 0601731A mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601731C mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[2]; c.pc = x; return; }  // 0601731E rts ; mov r2,r0
}

void f_0601732C(SH2Context& c) {
    ran[141] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601732C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0601732E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06017330 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06017332 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06017334 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06017336 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06017338 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601733A sts.l pr,@-r15
    c.r[2] = ld32(0x060173E8u);  // 0601733C mov.l 0x060173E8,r2
    c.r[1] = c.r[2];  // 0601733E mov r2,r1
    c.r[1] += 32;  // 06017340 add #32,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06017342 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06017344 mov r1,r0
    c.r[0] >>= 2;  // 06017346 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06017348 shlr r0
    c.r[0] &= 0x1u;  // 0601734A and #1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x060173E6u);  // 0601734C mov.w 0x060173E6,r1
    c.macl = (c.r[0] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 0601734E mulu.w r1,r0
    c.r[15] -= 12;  // 06017350 add #-12,r15
    c.r[1] = c.macl;  // 06017352 sts macl,r1
    c.r[1] += c.r[2];  // 06017354 add r2,r1
    c.r[1] += 72;  // 06017356 add #72,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06017358 mov.w @r1,r1
    c.r[7] = c.r[4];  // 0601735A mov r4,r7
    c.r[11] = c.r[1] & 0xFFFFu;  // 0601735C extu.w r1,r11
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0601735E mov.b @r7,r1
    c.r[0] = c.r[1];  // 06017360 mov r1,r0
    c.r[0] &= 0xC0u;  // 06017362 and #192,r0
    c.r[0] >>= 2;  // 06017364 shlr2 r0
    c.r[0] >>= 2;  // 06017366 shlr2 r0
    c.r[0] >>= 2;  // 06017368 shlr2 r0
    c.t = c.r[0] == 0x1u;  // 0601736A cmp/eq #1,r0
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_060173F8; } }  // 0601736C bf/s 0x060173F8 ; mov r15,r14
    c.r[8] = 0x3Fu;  // 06017370 mov #63,r8
    c.r[8] &= c.r[1];  // 06017372 and r1,r8
    c.r[1] = ld32(0x060173ECu);  // 06017374 mov.l 0x060173EC,r1
    c.r[2] = c.r[7];  // 06017376 mov r7,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06017378 mov.b @r1,r1
    c.r[2] += 4;  // 0601737A add #4,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601737C mov.b @r2,r2
    c.r[3] = c.r[1] & 0xFFu;  // 0601737E extu.b r1,r3
    c.r[1] = ld32(0x060173F0u);  // 06017380 mov.l 0x060173F0,r1
    c.r[0] = c.r[3];  // 06017382 mov r3,r0
    c.r[2] = c.r[2] & 0xFFu;  // 06017384 extu.b r2,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06017386 mov.b @(r0,r1),r3
    c.r[5] = c.r[2];  // 06017388 mov r2,r5
    c.r[3] = c.r[3] & 0xFFu;  // 0601738A extu.b r3,r3
    c.r[1] = ld32(0x060173F4u);  // 0601738C mov.l 0x060173F4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06017392u; c.r[4] = c.r[3]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06017392u) return; }  // 0601738E jsr @r1 ; mov r3,r4
    c.r[6] = c.r[0];  // 06017392 mov r0,r6
    c.macl = c.r[6] * c.r[2];  // 06017394 mul.l r2,r6
    c.r[1] = c.macl;  // 06017396 sts macl,r1
    c.r[3] -= c.r[1];  // 06017398 sub r1,r3
    c.r[1] = c.r[7];  // 0601739A mov r7,r1
    c.r[1] += 2;  // 0601739C add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601739E mov.b @r1,r1
    c.r[2] = 0x3Fu;  // 060173A0 mov #63,r2
    c.r[2] &= c.r[1];  // 060173A2 and r1,r2
    c.r[1] = c.r[7];  // 060173A4 mov r7,r1
    c.r[1] += 6;  // 060173A6 add #6,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060173A8 mov.b @r1,r1
    c.r[3] = c.r[3] & 0xFFu;  // 060173AA extu.b r3,r3
    c.r[1] = c.r[1] & 0xFFu;  // 060173AC extu.b r1,r1
    c.r[2] += c.r[1];  // 060173AE add r1,r2
    c.macl = c.r[3] * c.r[2];  // 060173B0 mul.l r2,r3
    c.r[1] = c.macl;  // 060173B2 sts macl,r1
    c.r[8] += c.r[1];  // 060173B4 add r1,r8
    c.r[8] = c.r[8] & 0xFFu;  // 060173B6 extu.b r8,r8
    st32(c.r[14], c.r[8]);  // 060173B8 mov.l r8,@r14
    c.r[1] = c.r[7];  // 060173BA mov r7,r1
    c.r[1] += 1;  // 060173BC add #1,r1
    c.r[3] = 0x1Fu;  // 060173BE mov #31,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060173C0 mov.b @r1,r1
    c.r[2] = c.r[6] & 0xFFu;  // 060173C2 extu.b r6,r2
    c.r[3] &= c.r[1];  // 060173C4 and r1,r3
    c.r[1] = c.r[7];  // 060173C6 mov r7,r1
    c.r[1] += 3;  // 060173C8 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060173CA mov.b @r1,r1
    c.r[6] = 0x3Fu;  // 060173CC mov #63,r6
    c.r[6] &= c.r[1];  // 060173CE and r1,r6
    c.r[1] = c.r[7];  // 060173D0 mov r7,r1
    c.r[1] += 7;  // 060173D2 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060173D4 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060173D6 extu.b r1,r1
    c.r[6] += c.r[1];  // 060173D8 add r1,r6
    c.macl = c.r[2] * c.r[6];  // 060173DA mul.l r6,r2
    c.r[1] = c.macl;  // 060173DC sts macl,r1
    c.r[3] += c.r[1];  // 060173DE add r1,r3
    c.r[3] = c.r[3] & 0xFFu;  // 060173E0 extu.b r3,r3
    st32(c.r[14] + 4, c.r[3]); goto L_0601740A;  // 060173E2 bra 0x0601740A ; mov.l r3,@(4,r14)
L_060173F8:
    c.r[0] = c.r[1];  // 060173F8 mov r1,r0
    c.r[0] &= 0x3Fu;  // 060173FA and #63,r0
    st32(c.r[14], c.r[0]);  // 060173FC mov.l r0,@r14
    c.r[1] = c.r[7];  // 060173FE mov r7,r1
    c.r[1] += 1;  // 06017400 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06017402 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06017404 mov r1,r0
    c.r[0] &= 0x1Fu;  // 06017406 and #31,r0
    st32(c.r[14] + 4, c.r[0]);  // 06017408 mov.l r0,@(4,r14)
L_0601740A:
    c.r[1] = c.r[7];  // 0601740A mov r7,r1
    c.r[1] += 3;  // 0601740C add #3,r1
    c.r[3] = 0x3Fu;  // 0601740E mov #63,r3
    c.r[7] += 2;  // 06017410 add #2,r7
    c.r[2] = 0x3Fu;  // 06017412 mov #63,r2
    c.r[8] = ld32(0x06017568u);  // 06017414 mov.l 0x06017568,r8
    c.r[10] = (uint32_t)(int16_t)ld16(0x06017552u);  // 06017416 mov.w 0x06017552,r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06017418 mov.b @r1,r1
    c.r[0] = c.r[8];  // 0601741A mov r8,r0
    c.r[5] = ld32(c.r[0] + c.r[10]);  // 0601741C mov.l @(r0,r10),r5
    c.r[3] &= c.r[1];  // 0601741E and r1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06017420 mov.b @r7,r1
    c.r[3] <<= 2;  // 06017422 shll2 r3
    c.r[3] += c.r[3];  // 06017424 add r3,r3
    c.r[2] &= c.r[1];  // 06017426 and r1,r2
    c.r[2] <<= 2;  // 06017428 shll2 r2
    c.r[2] += c.r[2];  // 0601742A add r2,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06017554u);  // 0601742C mov.w 0x06017554,r1
    c.r[7] = c.r[3];  // 0601742E mov r3,r7
    c.r[4] = ld32(c.r[0] + c.r[1]);  // 06017430 mov.l @(r0,r1),r4
    c.r[6] = c.r[2];  // 06017432 mov r2,r6
    c.r[1] = ld32(0x0601756Cu);  // 06017434 mov.l 0x0601756C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601743Au; c.r[15] -= 4; st32(c.r[15], c.r[11]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601743Au) return; }  // 06017436 jsr @r1 ; mov.l r11,@-r15
    c.r[7] = ld32(0x06017570u);  // 0601743A mov.l 0x06017570,r7
    c.r[9] = c.r[11];  // 0601743C mov r11,r9
    c.r[9] <<= 2;  // 0601743E shll2 r9
    c.r[9] += c.r[9];  // 06017440 add r9,r9
    c.r[0] = c.r[8];  // 06017442 mov r8,r0
    c.r[1] = ld32(0x06017574u);  // 06017444 mov.l 0x06017574,r1
    c.r[6] = 0x3u;  // 06017446 mov #3,r6
    c.r[4] = ld32(c.r[0] + c.r[10]);  // 06017448 mov.l @(r0,r10),r4
    c.r[5] = c.r[11];  // 0601744A mov r11,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06017450u; c.r[4] += c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06017450u) return; }  // 0601744C jsr @r1 ; add r9,r4
    c.r[0] = c.r[8];  // 06017450 mov r8,r0
    c.r[1] = ld32(0x06017578u);  // 06017452 mov.l 0x06017578,r1
    c.r[4] = ld32(c.r[0] + c.r[10]);  // 06017454 mov.l @(r0,r10),r4
    c.r[5] = 0x1u;  // 06017456 mov #1,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0601745Cu; c.r[4] += c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601745Cu) return; }  // 06017458 jsr @r1 ; add r9,r4
    c.r[1] = c.r[8];  // 0601745C mov r8,r1
    c.r[1] += 32;  // 0601745E add #32,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06017460 mov.b @r1,r1
    c.r[0] = 0x1u;  // 06017462 mov #1,r0
    c.r[2] = c.r[1];  // 06017464 mov r1,r2
    c.r[2] >>= 2;  // 06017466 shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 06017468 shlr r2
    c.r[2] &= c.r[0];  // 0601746A and r0,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06017556u);  // 0601746C mov.w 0x06017556,r1
    c.macl = (c.r[2] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 0601746E mulu.w r1,r2
    c.r[1] = c.macl;  // 06017470 sts macl,r1
    c.r[1] += c.r[8];  // 06017472 add r8,r1
    c.r[1] += 64;  // 06017474 add #64,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06017476 mov.b @r1,r1
    c.r[0] = 0x7u;  // 06017478 mov #7,r0
    c.r[2] = c.r[1];  // 0601747A mov r1,r2
    c.r[2] >>= 2;  // 0601747C shlr2 r2
    c.r[2] &= c.r[0];  // 0601747E and r0,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06017558u);  // 06017480 mov.w 0x06017558,r1
    c.r[0] = c.r[8];  // 06017482 mov r8,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06017484 mov.w @(r0,r1),r1
    c.r[6] = c.r[1] & 0xFFFFu;  // 06017486 extu.w r1,r6
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601755Au);  // 06017488 mov.w 0x0601755A,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601748A mov.b @(r0,r1),r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601755Cu);  // 0601748C mov.w 0x0601755C,r0
    c.r[1] &= c.r[0];  // 0601748E and r0,r1
    c.r[1] >>= 2;  // 06017490 shlr2 r1
    c.r[1] >>= 2;  // 06017492 shlr2 r1
    c.r[6] += c.r[1];  // 06017494 add r1,r6
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601755Eu);  // 06017496 mov.w 0x0601755E,r1
    c.r[0] = c.r[8];  // 06017498 mov r8,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601749A mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601749C extu.b r1,r1
    c.r[0] = c.r[1];  // 0601749E mov r1,r0
    c.t = c.r[0] == 0x3u;  // 060174A0 cmp/eq #3,r0
    { const bool k = !c.t; c.r[15] += 4; if (k) { goto L_060174A8; } }  // 060174A2 bf/s 0x060174A8 ; add #4,r15
    c.r[6] += 32;  // 060174A6 add #32,r6
L_060174A8:
    c.r[6] = c.r[6] & 0xFFFFu;  // 060174A8 extu.w r6,r6
    c.r[10] = ld32(0x06017568u);  // 060174AA mov.l 0x06017568,r10
    c.r[3] = (uint32_t)(int16_t)ld16(0x06017560u);  // 060174AC mov.w 0x06017560,r3
    c.r[1] = 0xAu;  // 060174AE mov #10,r1
    c.r[0] = c.r[10];  // 060174B0 mov r10,r0
    c.r[7] = c.r[2];  // 060174B2 mov r2,r7
    c.macl = (c.r[11] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 060174B4 mulu.w r1,r11
    c.r[4] = ld32(c.r[0] + c.r[3]);  // 060174B6 mov.l @(r0,r3),r4
    c.r[1] = c.macl;  // 060174B8 sts macl,r1
    c.r[4] += c.r[1];  // 060174BA add r1,r4
    c.r[1] = ld32(0x0601757Cu);  // 060174BC mov.l 0x0601757C,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060174BE mov.l r1,@-r15
    c.r[1] = (uint32_t)(int16_t)ld16(0x06017562u);  // 060174C0 mov.w 0x06017562,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060174C2 mov.l r1,@-r15
    c.r[1] = 0x0u;  // 060174C4 mov #0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060174C6 mov.l r1,@-r15
    c.r[1] = ld32(0x06017580u);  // 060174C8 mov.l 0x06017580,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060174CEu; c.r[5] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060174CEu) return; }  // 060174CA jsr @r1 ; mov r11,r5
    c.r[12] = (uint32_t)(int16_t)ld16(0x06017564u);  // 060174CE mov.w 0x06017564,r12
    c.r[0] = c.r[10];  // 060174D0 mov r10,r0
    c.r[13] = c.r[11];  // 060174D2 mov r11,r13
    c.r[13] += c.r[13];  // 060174D4 add r13,r13
    c.r[13] += c.r[11];  // 060174D6 add r11,r13
    c.r[0] = ld32(c.r[0] + c.r[12]);  // 060174D8 mov.l @(r0,r12),r0
    c.r[13] <<= 2;  // 060174DA shll2 r13
    st32(c.r[14] + 8, c.r[0]);  // 060174DC mov.l r0,@(8,r14)
    c.r[0] = ld32(c.r[14]);  // 060174DE mov.l @r14,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06017566u);  // 060174E0 mov.w 0x06017566,r1
    c.r[0] <<= 2;  // 060174E2 shll2 r0
    c.r[0] += c.r[0];  // 060174E4 add r0,r0
    c.r[0] += c.r[1];  // 060174E6 add r1,r0
    st32(c.r[14], c.r[0]);  // 060174E8 mov.l r0,@r14
    c.r[0] = ld32(0x06017584u);  // 060174EA mov.l 0x06017584,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060174F0u; c.r[4] = ld32(c.r[14]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060174F0u) return; }  // 060174EC jsr @r0 ; mov.l @r14,r4
    c.r[4] = c.r[0];  // 060174F0 mov r0,r4
    c.r[5] = c.r[1];  // 060174F2 mov r1,r5
    c.r[1] = ld32(0x06017588u);  // 060174F4 mov.l 0x06017588,r1
    c.r[8] = ld32(c.r[1]);  // 060174F6 mov.l @r1,r8
    c.r[9] = ld32(c.r[1] + 4);  // 060174F8 mov.l @(4,r1),r9
    c.r[0] = ld32(0x0601758Cu);  // 060174FA mov.l 0x0601758C,r0
    c.r[6] = c.r[8];  // 060174FC mov r8,r6
    { const uint32_t x = c.r[0]; c.pr = 0x06017502u; c.r[7] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06017502u) return; }  // 060174FE jsr @r0 ; mov r9,r7
    c.r[4] = c.r[0];  // 06017502 mov r0,r4
    c.r[11] = ld32(0x06017590u);  // 06017504 mov.l 0x06017590,r11
    { const uint32_t x = c.r[11]; c.pr = 0x0601750Au; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601750Au) return; }  // 06017506 jsr @r11 ; mov r1,r5
    c.r[1] = c.r[0];  // 0601750A mov r0,r1
    c.r[0] = ld32(c.r[14] + 8);  // 0601750C mov.l @(8,r14),r0
    st32(c.r[0] + c.r[13], c.r[1]);  // 0601750E mov.l r1,@(r0,r13)
    c.r[0] = c.r[10];  // 06017510 mov r10,r0
    c.r[1] = ld32(c.r[0] + c.r[12]);  // 06017512 mov.l @(r0,r12),r1
    c.r[0] = ld32(c.r[14] + 4);  // 06017514 mov.l @(4,r14),r0
    c.r[13] += c.r[1];  // 06017516 add r1,r13
    c.r[0] <<= 2;  // 06017518 shll2 r0
    c.r[0] += c.r[0];  // 0601751A add r0,r0
    c.r[0] -= 112;  // 0601751C add #-112,r0
    st32(c.r[14] + 4, c.r[0]);  // 0601751E mov.l r0,@(4,r14)
    c.r[0] = ld32(0x06017584u);  // 06017520 mov.l 0x06017584,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06017526u; c.r[4] = ld32(c.r[14] + 4); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06017526u) return; }  // 06017522 jsr @r0 ; mov.l @(4,r14),r4
    c.r[4] = c.r[0];  // 06017526 mov r0,r4
    c.r[5] = c.r[1];  // 06017528 mov r1,r5
    c.r[6] = c.r[8];  // 0601752A mov r8,r6
    c.r[0] = ld32(0x0601758Cu);  // 0601752C mov.l 0x0601758C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06017532u; c.r[7] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06017532u) return; }  // 0601752E jsr @r0 ; mov r9,r7
    c.r[4] = c.r[0];  // 06017532 mov r0,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06017538u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06017538u) return; }  // 06017534 jsr @r11 ; mov r1,r5
    c.r[1] = c.r[0];  // 06017538 mov r0,r1
    st32(c.r[13] + 4, c.r[1]);  // 0601753A mov.l r1,@(4,r13)
    c.r[14] += 12;  // 0601753C add #12,r14
    c.r[15] = c.r[14];  // 0601753E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06017540 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06017542 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06017544 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06017546 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06017548 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0601754A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0601754C mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601754E rts ; mov.l @r15+,r8
}

void f_06017594(SH2Context& c) {
    ran[142] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06017594 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06017596 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06017598 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601759A mov.l r14,@-r15
    c.r[15] -= 4;  // 0601759C add #-4,r15
    c.r[14] = c.r[15];  // 0601759E mov r15,r14
    c.r[7] = c.r[7] & 0xFFu;  // 060175A0 extu.b r7,r7
    c.r[0] = 0x1Bu;  // 060175A2 mov #27,r0
    c.r[0] += c.r[14];  // 060175A4 add r14,r0
    c.r[1] = c.r[4];  // 060175A6 mov r4,r1
    c.r[1] <<= 2;  // 060175A8 shll2 r1
    c.r[10] = (uint32_t)(int16_t)ld16(0x0601761Eu);  // 060175AA mov.w 0x0601761E,r10
    c.r[1] &= c.r[10];  // 060175AC and r10,r1
    c.r[9] = ld32(c.r[14] + 20);  // 060175AE mov.l @(20,r14),r9
    c.r[4] = 0x1u;  // 060175B0 mov #1,r4
    c.r[8] = ld32(c.r[14] + 28);  // 060175B2 mov.l @(28,r14),r8
    c.r[4] |= c.r[1];  // 060175B4 or r1,r4
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0]);  // 060175B6 mov.b @r0,r0
    c.r[2] = ld32(0x06017620u);  // 060175B8 mov.l 0x06017620,r2
    c.r[3] = ld32(c.r[14] + 32);  // 060175BA mov.l @(32,r14),r3
    c.r[0] = c.r[0] & 0xFFu;  // 060175BC extu.b r0,r0
    st32(c.r[14], c.r[0]);  // 060175BE mov.l r0,@r14
    c.r[8] = c.r[8] & 0xFFu;  // 060175C0 extu.b r8,r8
    c.r[3] = c.r[3] & 0xFFu;  // 060175C2 extu.b r3,r3
    c.r[0] = c.r[1];  // 060175C4 mov r1,r0
    st8(c.r[0] + c.r[2], c.r[5]);  // 060175C6 mov.b r5,@(r0,r2)
    c.r[1] = c.r[4];  // 060175C8 mov r4,r1
    c.r[1] += 1;  // 060175CA add #1,r1
    c.r[5] = c.r[1] & 0xFFu;  // 060175CC extu.b r1,r5
    c.r[3] <<= 2;  // 060175CE shll2 r3
    c.r[3] <<= 2;  // 060175D0 shll2 r3
    c.r[3] += c.r[3];  // 060175D2 add r3,r3
    c.r[3] <<= 2;  // 060175D4 shll2 r3
    c.r[6] |= c.r[3];  // 060175D6 or r3,r6
    c.r[0] = c.r[4];  // 060175D8 mov r4,r0
    st8(c.r[0] + c.r[2], c.r[6]);  // 060175DA mov.b r6,@(r0,r2)
    c.r[1] = c.r[5];  // 060175DC mov r5,r1
    c.r[1] += 1;  // 060175DE add #1,r1
    c.r[3] = c.r[1] & 0xFFu;  // 060175E0 extu.b r1,r3
    c.r[0] = c.r[5];  // 060175E2 mov r5,r0
    c.r[1] = c.r[3];  // 060175E4 mov r3,r1
    c.r[10] = ld32(c.r[14]);  // 060175E6 mov.l @r14,r10
    c.r[1] += 1;  // 060175E8 add #1,r1
    c.r[10] <<= 2;  // 060175EA shll2 r10
    c.r[10] <<= 2;  // 060175EC shll2 r10
    c.r[10] += c.r[10];  // 060175EE add r10,r10
    c.r[10] <<= 2;  // 060175F0 shll2 r10
    st32(c.r[14], c.r[10]);  // 060175F2 mov.l r10,@r14
    c.r[7] |= c.r[10];  // 060175F4 or r10,r7
    c.r[8] <<= 2;  // 060175F6 shll2 r8
    c.r[8] <<= 2;  // 060175F8 shll2 r8
    c.r[8] <<= 2;  // 060175FA shll2 r8
    c.r[7] |= c.r[8];  // 060175FC or r8,r7
    st8(c.r[0] + c.r[2], c.r[7]);  // 060175FE mov.b r7,@(r0,r2)
    c.r[7] = c.r[1] & 0xFFu;  // 06017600 extu.b r1,r7
    c.r[0] = c.r[3];  // 06017602 mov r3,r0
    st8(c.r[0] + c.r[2], c.r[9]);  // 06017604 mov.b r9,@(r0,r2)
    c.r[1] = 0xFFFFFFFFu;  // 06017606 mov #-1,r1
    c.r[0] = c.r[7];  // 06017608 mov r7,r0
    st8(c.r[0] + c.r[2], c.r[1]);  // 0601760A mov.b r1,@(r0,r2)
    c.r[1] = ld32(0x06017624u);  // 0601760C mov.l 0x06017624,r1
    st32(c.r[1], c.r[2]);  // 0601760E mov.l r2,@r1
    c.r[14] += 4;  // 06017610 add #4,r14
    c.r[15] = c.r[14];  // 06017612 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06017614 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06017616 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06017618 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601761A rts ; mov.l @r15+,r8
}

void f_06017628(SH2Context& c) {
    ran[143] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06017628 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0601762A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0601762C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0601762E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06017630 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06017632 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06017634 mov.l r14,@-r15
    c.r[15] -= 12;  // 06017636 add #-12,r15
    c.r[14] = c.r[15];  // 06017638 mov r15,r14
    c.r[9] = c.r[4];  // 0601763A mov r4,r9
    c.r[10] = 0x44u;  // 0601763C mov #68,r10
    c.r[10] += c.r[14];  // 0601763E add r14,r10
    c.r[11] = ld32(c.r[14] + 40);  // 06017640 mov.l @(40,r14),r11
    c.r[5] = c.r[5] & 0xFFu;  // 06017642 extu.b r5,r5
    c.r[12] = ld32(c.r[14] + 44);  // 06017644 mov.l @(44,r14),r12
    c.r[6] = c.r[6] & 0xFFu;  // 06017646 extu.b r6,r6
    c.r[13] = ld32(c.r[14] + 48);  // 06017648 mov.l @(48,r14),r13
    c.r[0] = ld32(c.r[14] + 52);  // 0601764A mov.l @(52,r14),r0
    c.r[1] = ld32(c.r[14] + 56);  // 0601764C mov.l @(56,r14),r1
    c.r[2] = ld32(0x06017714u);  // 0601764E mov.l 0x06017714,r2
    c.r[4] = ld32(c.r[14] + 60);  // 06017650 mov.l @(60,r14),r4
    st32(c.r[14] + 8, c.r[0]);  // 06017652 mov.l r0,@(8,r14)
    c.r[0] = 0x48u;  // 06017654 mov #72,r0
    c.r[0] += c.r[14];  // 06017656 add r14,r0
    c.r[1] = c.r[1] & 0xFFu;  // 06017658 extu.b r1,r1
    c.r[4] = c.r[4] & 0xFFu;  // 0601765A extu.b r4,r4
    c.r[1] <<= 2;  // 0601765C shll2 r1
    c.r[1] += c.r[1];  // 0601765E add r1,r1
    c.r[1] <<= 2;  // 06017660 shll2 r1
    c.r[5] |= c.r[1];  // 06017662 or r1,r5
    c.r[4] <<= 2;  // 06017664 shll2 r4
    c.r[4] <<= 2;  // 06017666 shll2 r4
    c.r[4] <<= 2;  // 06017668 shll2 r4
    c.r[5] |= c.r[4];  // 0601766A or r4,r5
    c.r[1] = c.r[2];  // 0601766C mov r2,r1
    c.r[8] = ld32(c.r[10]);  // 0601766E mov.l @r10,r8
    c.r[1] += 2;  // 06017670 add #2,r1
    c.r[3] = ld32(c.r[0]);  // 06017672 mov.l @r0,r3
    c.r[10] = 0x43u;  // 06017674 mov #67,r10
    c.r[10] += c.r[14];  // 06017676 add r14,r10
    c.r[8] = c.r[8] & 0xFFu;  // 06017678 extu.b r8,r8
    c.r[3] = c.r[3] & 0xFFu;  // 0601767A extu.b r3,r3
    c.r[0] = 0x4Eu;  // 0601767C mov #78,r0
    c.r[0] += c.r[14];  // 0601767E add r14,r0
    c.r[3] <<= 2;  // 06017680 shll2 r3
    c.r[3] <<= 2;  // 06017682 shll2 r3
    c.r[3] += c.r[3];  // 06017684 add r3,r3
    c.r[3] <<= 2;  // 06017686 shll2 r3
    c.r[5] |= c.r[3];  // 06017688 or r3,r5
    c.r[3] = c.r[2];  // 0601768A mov r2,r3
    c.r[10] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0601768C mov.b @r10,r10
    c.r[3] += 8;  // 0601768E add #8,r3
    c.r[10] = c.r[10] & 0xFFu;  // 06017690 extu.b r10,r10
    st32(c.r[14], c.r[10]);  // 06017692 mov.l r10,@r14
    c.r[10] = 0x40u;  // 06017694 mov #64,r10
    c.r[9] |= c.r[10];  // 06017696 or r10,r9
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[0]);  // 06017698 mov.w @r0,r0
    c.r[10] = 0xBu;  // 0601769A mov #11,r10
    c.r[0] = c.r[0] & 0xFFFFu;  // 0601769C extu.w r0,r0
    st32(c.r[14] + 4, c.r[0]);  // 0601769E mov.l r0,@(4,r14)
    st8(c.r[2], c.r[9]);  // 060176A0 mov.b r9,@r2
    c.r[9] = c.r[2];  // 060176A2 mov r2,r9
    c.r[9] += 1;  // 060176A4 add #1,r9
    st8(c.r[9], c.r[5]);  // 060176A6 mov.b r5,@r9
    c.r[0] = ld32(c.r[14]);  // 060176A8 mov.l @r14,r0
    c.r[10] += c.r[14];  // 060176AA add r14,r10
    c.r[0] <<= 2;  // 060176AC shll2 r0
    c.r[0] <<= 2;  // 060176AE shll2 r0
    c.r[0] += c.r[0];  // 060176B0 add r0,r0
    c.r[0] <<= 2;  // 060176B2 shll2 r0
    st32(c.r[14], c.r[0]);  // 060176B4 mov.l r0,@r14
    c.r[6] |= c.r[0];  // 060176B6 or r0,r6
    c.r[8] <<= 2;  // 060176B8 shll2 r8
    c.r[8] <<= 2;  // 060176BA shll2 r8
    c.r[8] <<= 2;  // 060176BC shll2 r8
    c.r[6] |= c.r[8];  // 060176BE or r8,r6
    st8(c.r[1], c.r[6]);  // 060176C0 mov.b r6,@r1
    c.r[1] = c.r[2];  // 060176C2 mov r2,r1
    c.r[1] += 3;  // 060176C4 add #3,r1
    st8(c.r[1], c.r[7]);  // 060176C6 mov.b r7,@r1
    c.r[1] = c.r[2];  // 060176C8 mov r2,r1
    c.r[1] += 4;  // 060176CA add #4,r1
    st8(c.r[1], c.r[11]);  // 060176CC mov.b r11,@r1
    c.r[1] = c.r[2];  // 060176CE mov r2,r1
    c.r[1] += 5;  // 060176D0 add #5,r1
    st8(c.r[1], c.r[12]);  // 060176D2 mov.b r12,@r1
    c.r[1] = c.r[2];  // 060176D4 mov r2,r1
    c.r[1] += 6;  // 060176D6 add #6,r1
    st8(c.r[1], c.r[13]);  // 060176D8 mov.b r13,@r1
    c.r[1] = c.r[2];  // 060176DA mov r2,r1
    c.r[1] += 7;  // 060176DC add #7,r1
    c.r[10] = (uint32_t)(int8_t)ld8(c.r[10]);  // 060176DE mov.b @r10,r10
    c.r[0] = 0x7u;  // 060176E0 mov #7,r0
    st8(c.r[1], c.r[10]);  // 060176E2 mov.b r10,@r1
    c.r[1] = ld32(c.r[14] + 4);  // 060176E4 mov.l @(4,r14),r1
    c.r[0] += c.r[14];  // 060176E6 add r14,r0
    c.r[1] >>= 8;  // 060176E8 shlr8 r1
    st8(c.r[3], c.r[1]);  // 060176EA mov.b r1,@r3
    c.r[1] = c.r[2];  // 060176EC mov r2,r1
    c.r[1] += 9;  // 060176EE add #9,r1
    c.r[3] = c.r[2];  // 060176F0 mov r2,r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0]);  // 060176F2 mov.b @r0,r0
    c.r[3] += 10;  // 060176F4 add #10,r3
    st8(c.r[1], c.r[0]);  // 060176F6 mov.b r0,@r1
    c.r[1] = 0xFFFFFFFFu;  // 060176F8 mov #-1,r1
    st8(c.r[3], c.r[1]);  // 060176FA mov.b r1,@r3
    c.r[1] = ld32(0x06017718u);  // 060176FC mov.l 0x06017718,r1
    st32(c.r[1], c.r[2]);  // 060176FE mov.l r2,@r1
    c.r[14] += 12;  // 06017700 add #12,r14
    c.r[15] = c.r[14];  // 06017702 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06017704 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06017706 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06017708 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0601770A mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0601770C mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0601770E mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06017710 rts ; mov.l @r15+,r8
}

void f_0601771C(SH2Context& c) {
    ran[144] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601771C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0601771E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06017720 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06017722 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06017724 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06017726 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06017728 mov.l r14,@-r15
    c.r[15] -= 8;  // 0601772A add #-8,r15
    c.r[14] = c.r[15];  // 0601772C mov r15,r14
    c.r[0] = ld32(c.r[14] + 36);  // 0601772E mov.l @(36,r14),r0
    c.r[1] = c.r[4];  // 06017730 mov r4,r1
    c.r[8] = ld32(c.r[14] + 40);  // 06017732 mov.l @(40,r14),r8
    c.r[13] = c.r[5];  // 06017734 mov r5,r13
    c.r[9] = ld32(c.r[14] + 44);  // 06017736 mov.l @(44,r14),r9
    c.r[7] = c.r[7] & 0xFFu;  // 06017738 extu.b r7,r7
    c.r[10] = ld32(c.r[14] + 48);  // 0601773A mov.l @(48,r14),r10
    c.r[1] <<= 2;  // 0601773C shll2 r1
    c.r[1] += c.r[1];  // 0601773E add r1,r1
    c.r[11] = ld32(c.r[14] + 52);  // 06017740 mov.l @(52,r14),r11
    c.r[12] = 0x1u;  // 06017742 mov #1,r12
    c.r[5] = ld32(c.r[14] + 56);  // 06017744 mov.l @(56,r14),r5
    c.r[2] = ld32(0x060177F8u);  // 06017746 mov.l 0x060177F8,r2
    c.r[4] = ld32(c.r[14] + 60);  // 06017748 mov.l @(60,r14),r4
    st32(c.r[14], c.r[0]);  // 0601774A mov.l r0,@r14
    st32(c.r[14] + 4, c.r[8]);  // 0601774C mov.l r8,@(4,r14)
    c.r[0] = 0x40u;  // 0601774E mov #64,r0
    c.r[0] += c.r[14];  // 06017750 add r14,r0
    c.r[5] = c.r[5] & 0xFFu;  // 06017752 extu.b r5,r5
    c.r[4] = c.r[4] & 0xFFu;  // 06017754 extu.b r4,r4
    c.r[8] = (uint32_t)(int16_t)ld16(0x060177F4u);  // 06017756 mov.w 0x060177F4,r8
    c.r[1] &= c.r[8];  // 06017758 and r8,r1
    c.r[3] = ld32(c.r[0]);  // 0601775A mov.l @r0,r3
    c.r[12] |= c.r[1];  // 0601775C or r1,r12
    c.r[3] = c.r[3] & 0xFFu;  // 0601775E extu.b r3,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x060177F6u);  // 06017760 mov.w 0x060177F6,r0
    c.r[13] |= c.r[0];  // 06017762 or r0,r13
    c.r[0] = c.r[1];  // 06017764 mov r1,r0
    st8(c.r[0] + c.r[2], c.r[13]);  // 06017766 mov.b r13,@(r0,r2)
    c.r[1] = c.r[12];  // 06017768 mov r12,r1
    c.r[1] += 1;  // 0601776A add #1,r1
    c.r[13] = c.r[1] & 0xFFu;  // 0601776C extu.b r1,r13
    c.r[3] <<= 2;  // 0601776E shll2 r3
    c.r[3] <<= 2;  // 06017770 shll2 r3
    c.r[3] += c.r[3];  // 06017772 add r3,r3
    c.r[3] <<= 2;  // 06017774 shll2 r3
    c.r[6] |= c.r[3];  // 06017776 or r3,r6
    c.r[0] = c.r[12];  // 06017778 mov r12,r0
    st8(c.r[0] + c.r[2], c.r[6]);  // 0601777A mov.b r6,@(r0,r2)
    c.r[1] = c.r[13];  // 0601777C mov r13,r1
    c.r[1] += 1;  // 0601777E add #1,r1
    c.r[3] = c.r[1] & 0xFFu;  // 06017780 extu.b r1,r3
    c.r[5] <<= 2;  // 06017782 shll2 r5
    c.r[5] <<= 2;  // 06017784 shll2 r5
    c.r[5] += c.r[5];  // 06017786 add r5,r5
    c.r[5] <<= 2;  // 06017788 shll2 r5
    c.r[7] |= c.r[5];  // 0601778A or r5,r7
    c.r[4] <<= 2;  // 0601778C shll2 r4
    c.r[4] <<= 2;  // 0601778E shll2 r4
    c.r[4] <<= 2;  // 06017790 shll2 r4
    c.r[7] |= c.r[4];  // 06017792 or r4,r7
    c.r[0] = c.r[13];  // 06017794 mov r13,r0
    st8(c.r[0] + c.r[2], c.r[7]);  // 06017796 mov.b r7,@(r0,r2)
    c.r[1] = c.r[3];  // 06017798 mov r3,r1
    c.r[1] += 1;  // 0601779A add #1,r1
    c.r[7] = c.r[1] & 0xFFu;  // 0601779C extu.b r1,r7
    c.r[0] = 0x3u;  // 0601779E mov #3,r0
    c.r[0] += c.r[14];  // 060177A0 add r14,r0
    c.r[1] = c.r[7];  // 060177A2 mov r7,r1
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[0]);  // 060177A4 mov.b @r0,r8
    c.r[1] += 1;  // 060177A6 add #1,r1
    c.r[0] = c.r[3];  // 060177A8 mov r3,r0
    st8(c.r[0] + c.r[2], c.r[8]);  // 060177AA mov.b r8,@(r0,r2)
    c.r[3] = c.r[1] & 0xFFu;  // 060177AC extu.b r1,r3
    c.r[0] = 0x7u;  // 060177AE mov #7,r0
    c.r[0] += c.r[14];  // 060177B0 add r14,r0
    c.r[1] = c.r[3];  // 060177B2 mov r3,r1
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[0]);  // 060177B4 mov.b @r0,r8
    c.r[1] += 1;  // 060177B6 add #1,r1
    c.r[0] = c.r[7];  // 060177B8 mov r7,r0
    st8(c.r[0] + c.r[2], c.r[8]);  // 060177BA mov.b r8,@(r0,r2)
    c.r[7] = c.r[1] & 0xFFu;  // 060177BC extu.b r1,r7
    c.r[0] = c.r[3];  // 060177BE mov r3,r0
    st8(c.r[0] + c.r[2], c.r[9]);  // 060177C0 mov.b r9,@(r0,r2)
    c.r[1] = c.r[7];  // 060177C2 mov r7,r1
    c.r[1] += 1;  // 060177C4 add #1,r1
    c.r[3] = c.r[1] & 0xFFu;  // 060177C6 extu.b r1,r3
    c.r[0] = c.r[7];  // 060177C8 mov r7,r0
    st8(c.r[0] + c.r[2], c.r[10]);  // 060177CA mov.b r10,@(r0,r2)
    c.r[1] = c.r[3];  // 060177CC mov r3,r1
    c.r[1] += 1;  // 060177CE add #1,r1
    c.r[7] = c.r[1] & 0xFFu;  // 060177D0 extu.b r1,r7
    c.r[0] = c.r[3];  // 060177D2 mov r3,r0
    st8(c.r[0] + c.r[2], c.r[11]);  // 060177D4 mov.b r11,@(r0,r2)
    c.r[1] = 0xFFFFFFFFu;  // 060177D6 mov #-1,r1
    c.r[0] = c.r[7];  // 060177D8 mov r7,r0
    st8(c.r[0] + c.r[2], c.r[1]);  // 060177DA mov.b r1,@(r0,r2)
    c.r[1] = ld32(0x060177FCu);  // 060177DC mov.l 0x060177FC,r1
    st32(c.r[1], c.r[2]);  // 060177DE mov.l r2,@r1
    c.r[14] += 8;  // 060177E0 add #8,r14
    c.r[15] = c.r[14];  // 060177E2 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060177E4 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060177E6 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060177E8 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060177EA mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060177EC mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060177EE mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060177F0 rts ; mov.l @r15+,r8
}

void f_06017800(SH2Context& c) {
    ran[145] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06017800 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06017802 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06017804 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06017806 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06017808 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0601780A mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601780C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601780E sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06017810 mov r15,r14
    c.r[12] = ld32(c.r[14] + 32);  // 06017812 mov.l @(32,r14),r12
    c.r[9] = c.r[4] & 0xFFu;  // 06017814 extu.b r4,r9
    c.r[10] = c.r[5] & 0xFFu;  // 06017816 extu.b r5,r10
    c.r[11] = c.r[6] & 0xFFFFu;  // 06017818 extu.w r6,r11
    c.r[1] = ld32(0x0601794Cu);  // 0601781A mov.l 0x0601794C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06017820u; c.r[13] = c.r[7] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06017820u) return; }  // 0601781C jsr @r1 ; extu.b r7,r13
    c.r[0] = c.r[10];  // 06017820 mov r10,r0
    c.t = c.r[0] == 0x2u;  // 06017822 cmp/eq #2,r0
    if (!c.t) { goto L_0601782C; }  // 06017824 bf 0x0601782C
    c.r[10] = 0x0u;  // 06017826 mov #0,r10
    c.r[8] = 0x1Cu; goto L_06017850;  // 06017828 bra 0x06017850 ; mov #28,r8
L_0601782C:
    c.r[4] = (uint32_t)(int16_t)ld16(0x0601793Au);  // 0601782C mov.w 0x0601793A,r4
    c.r[8] = ld32(0x06017950u);  // 0601782E mov.l 0x06017950,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06017834u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06017834u) return; }  // 06017830 jsr @r8 ; nop
    c.r[1] = 0x2u;  // 06017834 mov #2,r1
    c.t = c.r[10] > c.r[1];  // 06017836 cmp/hi r1,r10
    if (!c.t) { goto L_06017846; }  // 06017838 bf 0x06017846
    { const uint32_t x = c.r[8]; c.pr = 0x0601783Eu; c.r[4] = 0x5u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601783Eu) return; }  // 0601783A jsr @r8 ; mov #5,r4
    c.r[1] = c.r[10];  // 0601783E mov r10,r1
    c.r[1] -= 3;  // 06017840 add #-3,r1
    c.r[10] = c.r[1] & 0xFFu; goto L_0601784A;  // 06017842 bra 0x0601784A ; extu.b r1,r10
L_06017846:
    { const uint32_t x = c.r[8]; c.pr = 0x0601784Au; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601784Au) return; }  // 06017846 jsr @r8 ; mov #1,r4
L_0601784A:
    c.r[1] = c.r[10];  // 0601784A mov r10,r1
    c.r[1] += 4;  // 0601784C add #4,r1
    c.r[8] = c.r[1] & 0xFFu;  // 0601784E extu.b r1,r8
L_06017850:
    c.r[0] = c.r[9];  // 06017850 mov r9,r0
    c.t = c.r[0] == 0x2u;  // 06017852 cmp/eq #2,r0
    { const bool k = !c.t; c.r[1] = 0x1u; if (k) { goto L_06017870; } }  // 06017854 bf/s 0x06017870 ; mov #1,r1
    c.r[1] = ld32(0x06017954u);  // 06017858 mov.l 0x06017954,r1
    c.r[0] = c.r[1];  // 0601785A mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 0601785C mov.b @(r0,r10),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601785E extu.b r1,r1
    c.r[1] >>= 2;  // 06017860 shlr2 r1
    c.r[1] >>= 2;  // 06017862 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06017864 shlr r1
    c.r[1] >>= 2;  // 06017866 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06017868 tst r1,r1
    if (!c.t) { goto L_0601786E; }  // 0601786A bf 0x0601786E
    c.r[9] = 0x1u;  // 0601786C mov #1,r9
L_0601786E:
    c.r[1] = 0x1u;  // 0601786E mov #1,r1
L_06017870:
    c.t = c.r[9] > c.r[1];  // 06017870 cmp/hi r1,r9
    { const bool k = c.t; c.t = (c.r[10] & c.r[10]) == 0; if (k) { goto L_0601788E; } }  // 06017872 bt/s 0x0601788E ; tst r10,r10
    c.r[1] = ld32(0x06017954u);  // 06017876 mov.l 0x06017954,r1
    c.r[0] = c.r[1];  // 06017878 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 0601787A mov.b @(r0,r10),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601787C extu.b r1,r1
    c.r[1] >>= 2;  // 0601787E shlr2 r1
    c.r[1] >>= 2;  // 06017880 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06017882 shlr r1
    c.r[1] >>= 2;  // 06017884 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06017886 tst r1,r1
    if (c.t) { goto L_0601788C; }  // 06017888 bt 0x0601788C
    c.r[9] = 0x2u;  // 0601788A mov #2,r9
L_0601788C:
    c.t = (c.r[10] & c.r[10]) == 0;  // 0601788C tst r10,r10
L_0601788E:
    { const bool k = c.t; c.r[5] = 0x14u; if (k) { goto L_06017894; } }  // 0601788E bt/s 0x06017894 ; mov #20,r5
    c.r[5] = 0x2u;  // 06017892 mov #2,r5
L_06017894:
    c.r[0] = c.r[9];  // 06017894 mov r9,r0
    c.t = c.r[0] == 0x1u;  // 06017896 cmp/eq #1,r0
    { const bool k = !c.t; c.r[4] = c.r[10]; if (k) { goto L_06017964; } }  // 06017898 bf/s 0x06017964 ; mov r10,r4
    c.r[4] -= 1;  // 0601789C add #-1,r4
    c.t = (int32_t)c.r[4] >= 0;  // 0601789E cmp/pz r4
    if (c.t) { goto L_060178A4; }  // 060178A0 bt 0x060178A4
    c.r[4] = 0u - c.r[4];  // 060178A2 neg r4,r4
L_060178A4:
    c.r[9] = c.r[4] & 0xFFu;  // 060178A4 extu.b r4,r9
    c.r[1] = ld32(0x06017954u);  // 060178A6 mov.l 0x06017954,r1
    c.r[0] = c.r[1];  // 060178A8 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 060178AA mov.b @(r0,r9),r1
    c.r[1] = c.r[1] & 0xFFu;  // 060178AC extu.b r1,r1
    c.r[1] >>= 2;  // 060178AE shlr2 r1
    c.r[1] >>= 2;  // 060178B0 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060178B2 shlr r1
    c.r[1] >>= 2;  // 060178B4 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060178B6 tst r1,r1
    if (c.t) { goto L_060178E8; }  // 060178B8 bt 0x060178E8
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601793Cu);  // 060178BA mov.w 0x0601793C,r1
    c.macl = c.r[10] * c.r[1];  // 060178BC mul.l r1,r10
    c.r[2] = ld32(0x06017958u);  // 060178BE mov.l 0x06017958,r2
    c.r[6] = c.macl;  // 060178C0 sts macl,r6
    c.macl = c.r[9] * c.r[1];  // 060178C2 mul.l r1,r9
    c.r[7] = (uint32_t)(int16_t)ld16(0x0601793Eu);  // 060178C4 mov.w 0x0601793E,r7
    c.r[6] += c.r[2];  // 060178C6 add r2,r6
    c.r[3] = c.macl;  // 060178C8 sts macl,r3
    c.r[3] += c.r[2];  // 060178CA add r2,r3
    c.r[0] = c.r[3];  // 060178CC mov r3,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[7]);  // 060178CE mov.w @(r0,r7),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06017940u);  // 060178D0 mov.w 0x06017940,r2
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 060178D2 mov.w @(r0,r2),r2
    c.r[1] += c.r[2];  // 060178D4 add r2,r1
    c.r[0] = c.r[6];  // 060178D6 mov r6,r0
    st16(c.r[0] + c.r[7], c.r[1]);  // 060178D8 mov.w r1,@(r0,r7)
    c.r[2] = (uint32_t)(int16_t)ld16(0x06017942u);  // 060178DA mov.w 0x06017942,r2
    c.r[0] = c.r[3];  // 060178DC mov r3,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 060178DE mov.w @(r0,r2),r1
    c.r[1] += 4;  // 060178E0 add #4,r1
    c.r[0] = c.r[6];  // 060178E2 mov r6,r0
    st16(c.r[0] + c.r[2], c.r[1]); goto L_0601790A;  // 060178E4 bra 0x0601790A ; mov.w r1,@(r0,r2)
L_060178E8:
    c.r[2] = ld32(0x06017958u);  // 060178E8 mov.l 0x06017958,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601793Cu);  // 060178EA mov.w 0x0601793C,r1
    c.macl = c.r[10] * c.r[1];  // 060178EC mul.l r1,r10
    c.r[3] = (uint32_t)(int16_t)ld16(0x0601793Eu);  // 060178EE mov.w 0x0601793E,r3
    c.r[0] = c.r[2];  // 060178F0 mov r2,r0
    c.r[7] = c.macl;  // 060178F2 sts macl,r7
    c.r[1] = (uint32_t)(int16_t)ld16(0x06017944u);  // 060178F4 mov.w 0x06017944,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 060178F6 mov.w @(r0,r1),r1
    c.r[7] += c.r[2];  // 060178F8 add r2,r7
    c.r[0] = c.r[7];  // 060178FA mov r7,r0
    st16(c.r[0] + c.r[3], c.r[1]);  // 060178FC mov.w r1,@(r0,r3)
    c.r[1] = (uint32_t)(int16_t)ld16(0x06017946u);  // 060178FE mov.w 0x06017946,r1
    c.r[0] = c.r[2];  // 06017900 mov r2,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06017902 mov.w @(r0,r1),r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x06017942u);  // 06017904 mov.w 0x06017942,r3
    c.r[0] = c.r[7];  // 06017906 mov r7,r0
    st16(c.r[0] + c.r[3], c.r[1]);  // 06017908 mov.w r1,@(r0,r3)
L_0601790A:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601793Cu);  // 0601790A mov.w 0x0601793C,r1
    c.macl = c.r[10] * c.r[1];  // 0601790C mul.l r1,r10
    c.r[2] = ld32(0x06017958u);  // 0601790E mov.l 0x06017958,r2
    c.r[7] = (uint32_t)(int16_t)ld16(0x06017940u);  // 06017910 mov.w 0x06017940,r7
    c.r[3] = c.macl;  // 06017912 sts macl,r3
    c.r[3] += c.r[2];  // 06017914 add r2,r3
    c.r[2] = (uint32_t)(int16_t)ld16(0x06017948u);  // 06017916 mov.w 0x06017948,r2
    c.r[1] = 0x0u;  // 06017918 mov #0,r1
    c.r[0] = c.r[3];  // 0601791A mov r3,r0
    st16(c.r[0] + c.r[2], c.r[1]);  // 0601791C mov.w r1,@(r0,r2)
    st16(c.r[0] + c.r[7], c.r[1]);  // 0601791E mov.w r1,@(r0,r7)
    c.r[1] = ld32(0x0601795Cu);  // 06017920 mov.l 0x0601795C,r1
    c.t = c.r[11] == c.r[1];  // 06017922 cmp/eq r1,r11
    if (c.t) { goto L_060179B0; }  // 06017924 bt 0x060179B0
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06017926 mov.l r13,@-r15
    c.r[4] = (uint32_t)(int16_t)ld16(0x0601794Au);  // 06017928 mov.w 0x0601794A,r4
    c.r[4] |= c.r[10];  // 0601792A or r10,r4
    c.r[0] = ld32(0x06017960u);  // 0601792C mov.l 0x06017960,r0
    c.r[7] = c.r[11];  // 0601792E mov r11,r7
    c.r[6] = c.r[5];  // 06017930 mov r5,r6
    { const uint32_t x = c.r[0]; c.pr = 0x06017936u; c.r[5] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06017936u) return; }  // 06017932 jsr @r0 ; mov #1,r5
    c.r[15] += 4; goto L_060179B0;  // 06017936 bra 0x060179B0 ; add #4,r15
L_06017964:
    c.r[1] = ld32(0x06017A2Cu);  // 06017964 mov.l 0x06017A2C,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06017A20u);  // 06017966 mov.w 0x06017A20,r2
    c.r[7] = (uint32_t)(int16_t)ld16(0x06017A22u);  // 06017968 mov.w 0x06017A22,r7
    c.macl = c.r[10] * c.r[2];  // 0601796A mul.l r2,r10
    c.r[3] = (uint32_t)(int16_t)ld16(0x06017A24u);  // 0601796C mov.w 0x06017A24,r3
    c.t = (c.r[11] & c.r[11]) == 0;  // 0601796E tst r11,r11
    c.r[2] = c.macl;  // 06017970 sts macl,r2
    c.r[2] += c.r[1];  // 06017972 add r1,r2
    c.r[1] = 0x0u;  // 06017974 mov #0,r1
    c.r[0] = c.r[2];  // 06017976 mov r2,r0
    st16(c.r[0] + c.r[3], c.r[1]);  // 06017978 mov.w r1,@(r0,r3)
    { const bool k = c.t; st16(c.r[0] + c.r[7], c.r[1]); if (k) { goto L_0601799A; } }  // 0601797A bt/s 0x0601799A ; mov.w r1,@(r0,r7)
    c.r[1] = ld32(0x06017A30u);  // 0601797E mov.l 0x06017A30,r1
    c.t = c.r[11] == c.r[1];  // 06017980 cmp/eq r1,r11
    { const bool k = c.t; c.t = (c.r[12] & c.r[12]) == 0; if (k) { goto L_060179A8; } }  // 06017982 bt/s 0x060179A8 ; tst r12,r12
    c.r[4] = (uint32_t)(int16_t)ld16(0x06017A26u);  // 06017986 mov.w 0x06017A26,r4
    c.r[4] |= c.r[10];  // 06017988 or r10,r4
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0601798A mov.l r13,@-r15
    c.r[0] = ld32(0x06017A34u);  // 0601798C mov.l 0x06017A34,r0
    c.r[7] = c.r[11];  // 0601798E mov r11,r7
    c.r[6] = c.r[5];  // 06017990 mov r5,r6
    { const uint32_t x = c.r[0]; c.pr = 0x06017996u; c.r[5] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06017996u) return; }  // 06017992 jsr @r0 ; mov #1,r5
    c.r[15] += 4; goto L_060179A6;  // 06017996 bra 0x060179A6 ; add #4,r15
L_0601799A:
    c.r[1] = 0x1u;  // 0601799A mov #1,r1
    c.r[0] = c.r[2];  // 0601799C mov r2,r0
    st16(c.r[0] + c.r[7], c.r[1]);  // 0601799E mov.w r1,@(r0,r7)
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 060179A0 mov.w @(r0,r3),r1
    c.r[1] += 4;  // 060179A2 add #4,r1
    st16(c.r[0] + c.r[3], c.r[1]);  // 060179A4 mov.w r1,@(r0,r3)
L_060179A6:
    c.t = (c.r[12] & c.r[12]) == 0;  // 060179A6 tst r12,r12
L_060179A8:
    { const bool k = c.t; c.r[0] = c.r[12]; if (k) { goto L_060179D4; } }  // 060179A8 bt/s 0x060179D4 ; mov r12,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 060179AC cmp/eq #-1,r0
    if (c.t) { goto L_060179C4; }  // 060179AE bt 0x060179C4
L_060179B0:
    c.r[1] = ld32(0x06017A38u);  // 060179B0 mov.l 0x06017A38,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060179B6u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060179B6u) return; }  // 060179B2 jsr @r1 ; mov r10,r4
    c.r[1] = ld32(0x06017A3Cu);  // 060179B6 mov.l 0x06017A3C,r1
    c.r[6] = 0x0u;  // 060179B8 mov #0,r6
    c.r[5] = c.r[12];  // 060179BA mov r12,r5
    { const uint32_t x = c.r[1]; c.pr = 0x060179C0u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060179C0u) return; }  // 060179BC jsr @r1 ; mov #0,r4
    goto L_060179CA;  // 060179C0 bra 0x060179CA ; nop
L_060179C4:
    c.r[1] = ld32(0x06017A40u);  // 060179C4 mov.l 0x06017A40,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060179CAu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060179CAu) return; }  // 060179C6 jsr @r1 ; mov #0,r4
L_060179CA:
    c.r[1] = ld32(0x06017A44u);  // 060179CA mov.l 0x06017A44,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060179D0u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060179D0u) return; }  // 060179CC jsr @r1 ; mov r8,r4
    goto L_060179FE;  // 060179D0 bra 0x060179FE ; nop
L_060179D4:
    c.r[2] = ld32(0x06017A2Cu);  // 060179D4 mov.l 0x06017A2C,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06017A20u);  // 060179D6 mov.w 0x06017A20,r1
    c.macl = c.r[10] * c.r[1];  // 060179D8 mul.l r1,r10
    c.r[9] = (uint32_t)(int16_t)ld16(0x06017A22u);  // 060179DA mov.w 0x06017A22,r9
    c.r[8] = c.macl;  // 060179DC sts macl,r8
    c.r[8] += c.r[2];  // 060179DE add r2,r8
    c.r[1] = (uint32_t)(int16_t)ld16(0x06017A28u);  // 060179E0 mov.w 0x06017A28,r1
    c.r[0] = c.r[8];  // 060179E2 mov r8,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 060179E4 mov.w @(r0,r1),r1
    c.r[3] = c.r[8];  // 060179E6 mov r8,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[9]);  // 060179E8 mov.w @(r0,r9),r2
    c.r[3] += 70;  // 060179EA add #70,r3
    c.r[1] += c.r[2];  // 060179EC add r2,r1
    st16(c.r[3], c.r[1]);  // 060179EE mov.w r1,@r3
    c.r[1] = ld32(0x06017A40u);  // 060179F0 mov.l 0x06017A40,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060179F6u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060179F6u) return; }  // 060179F2 jsr @r1 ; mov #0,r4
    c.r[0] = c.r[8];  // 060179F6 mov r8,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[9]);  // 060179F8 mov.w @(r0,r9),r1
    c.r[1] += 1;  // 060179FA add #1,r1
    st16(c.r[0] + c.r[9], c.r[1]);  // 060179FC mov.w r1,@(r0,r9)
L_060179FE:
    c.r[1] = ld32(0x06017A48u);  // 060179FE mov.l 0x06017A48,r1
    c.r[0] = c.r[1];  // 06017A00 mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 06017A02 mov.b @(r0,r10),r2
    c.r[15] = c.r[14];  // 06017A04 mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x06017A26u);  // 06017A06 mov.w 0x06017A26,r0
    c.r[2] |= c.r[0];  // 06017A08 or r0,r2
    c.r[0] = c.r[1];  // 06017A0A mov r1,r0
    st8(c.r[0] + c.r[10], c.r[2]);  // 06017A0C mov.b r2,@(r0,r10)
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06017A0E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06017A10 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06017A12 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06017A14 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06017A16 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06017A18 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06017A1A mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06017A1C rts ; mov.l @r15+,r8
}

void f_06017A4C(SH2Context& c) {
    ran[146] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06017A4C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06017A4E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06017A50 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06017A52 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06017A54 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06017A56 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06017A58 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06017A5A sts.l pr,@-r15
    c.r[15] -= 4;  // 06017A5C add #-4,r15
    c.r[14] = c.r[15];  // 06017A5E mov r15,r14
    c.r[13] = ld32(c.r[14] + 36);  // 06017A60 mov.l @(36,r14),r13
    c.r[8] = c.r[4] & 0xFFu;  // 06017A62 extu.b r4,r8
    c.r[10] = c.r[5] & 0xFFu;  // 06017A64 extu.b r5,r10
    c.r[11] = c.r[6] & 0xFFFFu;  // 06017A66 extu.w r6,r11
    c.r[7] = c.r[7] & 0xFFu;  // 06017A68 extu.b r7,r7
    st32(c.r[14], c.r[7]);  // 06017A6A mov.l r7,@r14
    c.r[1] = ld32(0x06017BC8u);  // 06017A6C mov.l 0x06017BC8,r1
    c.r[2] = c.r[1];  // 06017A6E mov r1,r2
    c.r[2] += 1;  // 06017A70 add #1,r2
L_06017A72:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06017A72 mov.b @r1,r0
    c.r[0] &= 0x9Bu;  // 06017A74 and #155,r0
    st8(c.r[1], c.r[0]);  // 06017A76 mov.b r0,@r1
    c.r[1] += 1;  // 06017A78 add #1,r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 06017A7A cmp/gt r2,r1
    if (!c.t) { SH2_POLL(c); goto L_06017A72; }  // 06017A7C bf 0x06017A72
    c.r[1] = ld32(0x06017BCCu);  // 06017A7E mov.l 0x06017BCC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06017A84u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06017A84u) return; }  // 06017A80 jsr @r1 ; nop
    c.r[4] = (uint32_t)(int16_t)ld16(0x06017BB4u);  // 06017A84 mov.w 0x06017BB4,r4
    c.r[9] = ld32(0x06017BD0u);  // 06017A86 mov.l 0x06017BD0,r9
    { const uint32_t x = c.r[9]; c.pr = 0x06017A8Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06017A8Cu) return; }  // 06017A88 jsr @r9 ; nop
    c.r[1] = 0x2u;  // 06017A8C mov #2,r1
    c.t = c.r[10] > c.r[1];  // 06017A8E cmp/hi r1,r10
    if (!c.t) { goto L_06017A9E; }  // 06017A90 bf 0x06017A9E
    { const uint32_t x = c.r[9]; c.pr = 0x06017A96u; c.r[4] = 0x5u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06017A96u) return; }  // 06017A92 jsr @r9 ; mov #5,r4
    c.r[1] = c.r[10];  // 06017A96 mov r10,r1
    c.r[1] -= 3;  // 06017A98 add #-3,r1
    c.r[10] = c.r[1] & 0xFFu; goto L_06017AA2;  // 06017A9A bra 0x06017AA2 ; extu.b r1,r10
L_06017A9E:
    { const uint32_t x = c.r[9]; c.pr = 0x06017AA2u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06017AA2u) return; }  // 06017A9E jsr @r9 ; mov #1,r4
L_06017AA2:
    c.r[0] = c.r[8];  // 06017AA2 mov r8,r0
    c.t = c.r[0] == 0x2u;  // 06017AA4 cmp/eq #2,r0
    { const bool k = !c.t; c.r[1] = 0x1u; if (k) { goto L_06017AC2; } }  // 06017AA6 bf/s 0x06017AC2 ; mov #1,r1
    c.r[1] = ld32(0x06017BC8u);  // 06017AAA mov.l 0x06017BC8,r1
    c.r[0] = c.r[1];  // 06017AAC mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 06017AAE mov.b @(r0,r10),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06017AB0 extu.b r1,r1
    c.r[1] >>= 2;  // 06017AB2 shlr2 r1
    c.r[1] >>= 2;  // 06017AB4 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06017AB6 shlr r1
    c.r[1] >>= 2;  // 06017AB8 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06017ABA tst r1,r1
    if (!c.t) { goto L_06017AC0; }  // 06017ABC bf 0x06017AC0
    c.r[8] = 0x1u;  // 06017ABE mov #1,r8
L_06017AC0:
    c.r[1] = 0x1u;  // 06017AC0 mov #1,r1
L_06017AC2:
    c.t = c.r[8] > c.r[1];  // 06017AC2 cmp/hi r1,r8
    { const bool k = c.t; c.r[0] = c.r[8]; if (k) { goto L_06017AE0; } }  // 06017AC4 bt/s 0x06017AE0 ; mov r8,r0
    c.r[1] = ld32(0x06017BC8u);  // 06017AC8 mov.l 0x06017BC8,r1
    c.r[0] = c.r[1];  // 06017ACA mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 06017ACC mov.b @(r0,r10),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06017ACE extu.b r1,r1
    c.r[1] >>= 2;  // 06017AD0 shlr2 r1
    c.r[1] >>= 2;  // 06017AD2 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06017AD4 shlr r1
    c.r[1] >>= 2;  // 06017AD6 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06017AD8 tst r1,r1
    if (c.t) { goto L_06017ADE; }  // 06017ADA bt 0x06017ADE
    c.r[8] = 0x2u;  // 06017ADC mov #2,r8
L_06017ADE:
    c.r[0] = c.r[8];  // 06017ADE mov r8,r0
L_06017AE0:
    c.t = c.r[0] == 0x1u;  // 06017AE0 cmp/eq #1,r0
    { const bool k = c.t; c.r[4] = c.r[10]; if (k) { goto L_06017AEA; } }  // 06017AE2 bt/s 0x06017AEA ; mov r10,r4
    goto L_06017BF0;  // 06017AE6 bra 0x06017BF0 ; nop
L_06017AEA:
    c.r[4] -= 1;  // 06017AEA add #-1,r4
    c.t = (int32_t)c.r[4] >= 0;  // 06017AEC cmp/pz r4
    if (c.t) { goto L_06017AF2; }  // 06017AEE bt 0x06017AF2
    c.r[4] = 0u - c.r[4];  // 06017AF0 neg r4,r4
L_06017AF2:
    c.r[8] = c.r[4] & 0xFFu;  // 06017AF2 extu.b r4,r8
    c.r[1] = ld32(0x06017BC8u);  // 06017AF4 mov.l 0x06017BC8,r1
    c.r[0] = c.r[1];  // 06017AF6 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 06017AF8 mov.b @(r0,r8),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06017AFA extu.b r1,r1
    c.r[1] >>= 2;  // 06017AFC shlr2 r1
    c.r[1] >>= 2;  // 06017AFE shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06017B00 shlr r1
    c.r[1] >>= 2;  // 06017B02 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06017B04 tst r1,r1
    if (c.t) { goto L_06017B32; }  // 06017B06 bt 0x06017B32
    c.r[1] = (uint32_t)(int16_t)ld16(0x06017BB6u);  // 06017B08 mov.w 0x06017BB6,r1
    c.macl = c.r[10] * c.r[1];  // 06017B0A mul.l r1,r10
    c.r[6] = c.macl;  // 06017B0C sts macl,r6
    c.macl = c.r[8] * c.r[1];  // 06017B0E mul.l r1,r8
    c.r[7] = ld32(0x06017BD4u);  // 06017B10 mov.l 0x06017BD4,r7
    c.r[2] = (uint32_t)(int16_t)ld16(0x06017BB8u);  // 06017B12 mov.w 0x06017BB8,r2
    c.r[3] = c.macl;  // 06017B14 sts macl,r3
    c.r[3] += c.r[7];  // 06017B16 add r7,r3
    c.r[0] = c.r[3];  // 06017B18 mov r3,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 06017B1A mov.w @(r0,r2),r1
    c.r[6] += c.r[7];  // 06017B1C add r7,r6
    c.r[1] += 2;  // 06017B1E add #2,r1
    c.r[0] = c.r[6];  // 06017B20 mov r6,r0
    st16(c.r[0] + c.r[2], c.r[1]);  // 06017B22 mov.w r1,@(r0,r2)
    c.r[2] = (uint32_t)(int16_t)ld16(0x06017BBAu);  // 06017B24 mov.w 0x06017BBA,r2
    c.r[0] = c.r[3];  // 06017B26 mov r3,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 06017B28 mov.w @(r0,r2),r1
    c.r[1] += 4;  // 06017B2A add #4,r1
    c.r[0] = c.r[6];  // 06017B2C mov r6,r0
    st16(c.r[0] + c.r[2], c.r[1]); goto L_06017B54;  // 06017B2E bra 0x06017B54 ; mov.w r1,@(r0,r2)
L_06017B32:
    c.r[2] = ld32(0x06017BD4u);  // 06017B32 mov.l 0x06017BD4,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06017BB6u);  // 06017B34 mov.w 0x06017BB6,r1
    c.macl = c.r[10] * c.r[1];  // 06017B36 mul.l r1,r10
    c.r[3] = (uint32_t)(int16_t)ld16(0x06017BB8u);  // 06017B38 mov.w 0x06017BB8,r3
    c.r[0] = c.r[2];  // 06017B3A mov r2,r0
    c.r[7] = c.macl;  // 06017B3C sts macl,r7
    c.r[1] = (uint32_t)(int16_t)ld16(0x06017BBCu);  // 06017B3E mov.w 0x06017BBC,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06017B40 mov.w @(r0,r1),r1
    c.r[7] += c.r[2];  // 06017B42 add r2,r7
    c.r[0] = c.r[7];  // 06017B44 mov r7,r0
    st16(c.r[0] + c.r[3], c.r[1]);  // 06017B46 mov.w r1,@(r0,r3)
    c.r[1] = (uint32_t)(int16_t)ld16(0x06017BBEu);  // 06017B48 mov.w 0x06017BBE,r1
    c.r[0] = c.r[2];  // 06017B4A mov r2,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06017B4C mov.w @(r0,r1),r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x06017BBAu);  // 06017B4E mov.w 0x06017BBA,r3
    c.r[0] = c.r[7];  // 06017B50 mov r7,r0
    st16(c.r[0] + c.r[3], c.r[1]);  // 06017B52 mov.w r1,@(r0,r3)
L_06017B54:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06017BB6u);  // 06017B54 mov.w 0x06017BB6,r1
    c.macl = c.r[10] * c.r[1];  // 06017B56 mul.l r1,r10
    c.r[2] = ld32(0x06017BD4u);  // 06017B58 mov.l 0x06017BD4,r2
    c.r[7] = (uint32_t)(int16_t)ld16(0x06017BC0u);  // 06017B5A mov.w 0x06017BC0,r7
    c.r[3] = c.macl;  // 06017B5C sts macl,r3
    c.r[3] += c.r[2];  // 06017B5E add r2,r3
    c.r[2] = (uint32_t)(int16_t)ld16(0x06017BC2u);  // 06017B60 mov.w 0x06017BC2,r2
    c.r[1] = 0x0u;  // 06017B62 mov #0,r1
    c.r[0] = c.r[3];  // 06017B64 mov r3,r0
    st16(c.r[0] + c.r[2], c.r[1]);  // 06017B66 mov.w r1,@(r0,r2)
    st16(c.r[0] + c.r[7], c.r[1]);  // 06017B68 mov.w r1,@(r0,r7)
    c.r[1] = ld32(0x06017BD8u);  // 06017B6A mov.l 0x06017BD8,r1
    c.t = c.r[11] == c.r[1];  // 06017B6C cmp/eq r1,r11
    if (c.t) { goto L_06017C6C; }  // 06017B6E bt 0x06017C6C
    c.r[12] = ld32(0x06017BDCu);  // 06017B70 mov.l 0x06017BDC,r12
    c.r[9] = ld32(0x06017BE0u);  // 06017B72 mov.l 0x06017BE0,r9
    c.r[8] = ld32(0x06017BE4u);  // 06017B74 mov.l 0x06017BE4,r8
L_06017B76:
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[12]);  // 06017B76 mov.b @r12,r5
    c.r[4] = ld32(0x06017BE8u);  // 06017B78 mov.l 0x06017BE8,r4
    { const uint32_t x = c.r[9]; c.pr = 0x06017B7Eu; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06017B7Eu) return; }  // 06017B7A jsr @r9 ; extu.b r5,r5
    c.r[1] = ld32(0x06017BECu);  // 06017B7E mov.l 0x06017BEC,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06017B80 mov.l r1,@-r15
    c.r[7] = c.r[11];  // 06017B82 mov r11,r7
    c.r[6] = 0x2u;  // 06017B84 mov #2,r6
    c.r[5] = c.r[0];  // 06017B86 mov r0,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06017B8Cu; c.r[4] = 0x5u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06017B8Cu) return; }  // 06017B88 jsr @r8 ; mov #5,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 06017B8C tst r0,r0
    { const bool k = !c.t; c.r[15] += 4; if (k) { SH2_POLL(c); goto L_06017B76; } }  // 06017B8E bf/s 0x06017B76 ; add #4,r15
    c.r[1] = ld32(0x06017BC8u);  // 06017B92 mov.l 0x06017BC8,r1
    c.r[0] = c.r[1];  // 06017B94 mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 06017B96 mov.b @(r0,r10),r2
    c.r[0] = 0x20u;  // 06017B98 mov #32,r0
    c.r[2] |= c.r[0];  // 06017B9A or r0,r2
    c.r[0] = ld32(c.r[14]);  // 06017B9C mov.l @r14,r0
    c.r[0] &= 0x3u;  // 06017B9E and #3,r0
    c.r[0] <<= 2;  // 06017BA0 shll2 r0
    c.r[0] += c.r[0];  // 06017BA2 add r0,r0
    st32(c.r[14], c.r[0]);  // 06017BA4 mov.l r0,@r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x06017BC4u);  // 06017BA6 mov.w 0x06017BC4,r0
    c.r[2] &= c.r[0];  // 06017BA8 and r0,r2
    c.r[0] = ld32(c.r[14]);  // 06017BAA mov.l @r14,r0
    c.r[2] |= c.r[0];  // 06017BAC or r0,r2
    c.r[0] = c.r[1];  // 06017BAE mov r1,r0
    st8(c.r[0] + c.r[10], c.r[2]); goto L_06017C6C;  // 06017BB0 bra 0x06017C6C ; mov.b r2,@(r0,r10)
L_06017BF0:
    c.r[1] = ld32(0x06017D04u);  // 06017BF0 mov.l 0x06017D04,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06017CF8u);  // 06017BF2 mov.w 0x06017CF8,r2
    c.r[7] = (uint32_t)(int16_t)ld16(0x06017CFAu);  // 06017BF4 mov.w 0x06017CFA,r7
    c.macl = c.r[10] * c.r[2];  // 06017BF6 mul.l r2,r10
    c.r[3] = (uint32_t)(int16_t)ld16(0x06017CFCu);  // 06017BF8 mov.w 0x06017CFC,r3
    c.t = (c.r[11] & c.r[11]) == 0;  // 06017BFA tst r11,r11
    c.r[2] = c.macl;  // 06017BFC sts macl,r2
    c.r[2] += c.r[1];  // 06017BFE add r1,r2
    c.r[1] = 0x0u;  // 06017C00 mov #0,r1
    c.r[0] = c.r[2];  // 06017C02 mov r2,r0
    st16(c.r[0] + c.r[3], c.r[1]);  // 06017C04 mov.w r1,@(r0,r3)
    { const bool k = c.t; st16(c.r[0] + c.r[7], c.r[1]); if (k) { goto L_06017C56; } }  // 06017C06 bt/s 0x06017C56 ; mov.w r1,@(r0,r7)
    c.r[1] = ld32(0x06017D08u);  // 06017C0A mov.l 0x06017D08,r1
    c.t = c.r[11] == c.r[1];  // 06017C0C cmp/eq r1,r11
    { const bool k = c.t; c.t = (c.r[13] & c.r[13]) == 0; if (k) { goto L_06017C64; } }  // 06017C0E bt/s 0x06017C64 ; tst r13,r13
    c.r[12] = ld32(0x06017D0Cu);  // 06017C12 mov.l 0x06017D0C,r12
    c.r[9] = ld32(0x06017D10u);  // 06017C14 mov.l 0x06017D10,r9
    c.r[8] = ld32(0x06017D14u);  // 06017C16 mov.l 0x06017D14,r8
L_06017C18:
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[12]);  // 06017C18 mov.b @r12,r5
    c.r[4] = ld32(0x06017D18u);  // 06017C1A mov.l 0x06017D18,r4
    { const uint32_t x = c.r[9]; c.pr = 0x06017C20u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06017C20u) return; }  // 06017C1C jsr @r9 ; extu.b r5,r5
    c.r[1] = ld32(0x06017D1Cu);  // 06017C20 mov.l 0x06017D1C,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06017C22 mov.l r1,@-r15
    c.r[7] = c.r[11];  // 06017C24 mov r11,r7
    c.r[6] = 0x2u;  // 06017C26 mov #2,r6
    c.r[5] = c.r[0];  // 06017C28 mov r0,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06017C2Eu; c.r[4] = 0x5u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06017C2Eu) return; }  // 06017C2A jsr @r8 ; mov #5,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 06017C2E tst r0,r0
    { const bool k = !c.t; c.r[15] += 4; if (k) { SH2_POLL(c); goto L_06017C18; } }  // 06017C30 bf/s 0x06017C18 ; add #4,r15
    c.r[1] = ld32(0x06017D20u);  // 06017C34 mov.l 0x06017D20,r1
    c.r[0] = c.r[1];  // 06017C36 mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 06017C38 mov.b @(r0,r10),r2
    c.r[0] = 0x20u;  // 06017C3A mov #32,r0
    c.r[2] |= c.r[0];  // 06017C3C or r0,r2
    c.r[0] = ld32(c.r[14]);  // 06017C3E mov.l @r14,r0
    c.r[0] &= 0x3u;  // 06017C40 and #3,r0
    c.r[0] <<= 2;  // 06017C42 shll2 r0
    c.r[0] += c.r[0];  // 06017C44 add r0,r0
    st32(c.r[14], c.r[0]);  // 06017C46 mov.l r0,@r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x06017CFEu);  // 06017C48 mov.w 0x06017CFE,r0
    c.r[2] &= c.r[0];  // 06017C4A and r0,r2
    c.r[0] = ld32(c.r[14]);  // 06017C4C mov.l @r14,r0
    c.r[2] |= c.r[0];  // 06017C4E or r0,r2
    c.r[0] = c.r[1];  // 06017C50 mov r1,r0
    st8(c.r[0] + c.r[10], c.r[2]); goto L_06017C62;  // 06017C52 bra 0x06017C62 ; mov.b r2,@(r0,r10)
L_06017C56:
    c.r[1] = 0x1u;  // 06017C56 mov #1,r1
    c.r[0] = c.r[2];  // 06017C58 mov r2,r0
    st16(c.r[0] + c.r[7], c.r[1]);  // 06017C5A mov.w r1,@(r0,r7)
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 06017C5C mov.w @(r0,r3),r1
    c.r[1] += 4;  // 06017C5E add #4,r1
    st16(c.r[0] + c.r[3], c.r[1]);  // 06017C60 mov.w r1,@(r0,r3)
L_06017C62:
    c.t = (c.r[13] & c.r[13]) == 0;  // 06017C62 tst r13,r13
L_06017C64:
    { const bool k = c.t; c.r[0] = c.r[13]; if (k) { goto L_06017C96; } }  // 06017C64 bt/s 0x06017C96 ; mov r13,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 06017C68 cmp/eq #-1,r0
    if (c.t) { goto L_06017C80; }  // 06017C6A bt 0x06017C80
L_06017C6C:
    c.r[1] = ld32(0x06017D24u);  // 06017C6C mov.l 0x06017D24,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06017C72u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06017C72u) return; }  // 06017C6E jsr @r1 ; mov r10,r4
    c.r[1] = ld32(0x06017D28u);  // 06017C72 mov.l 0x06017D28,r1
    c.r[6] = 0x0u;  // 06017C74 mov #0,r6
    c.r[5] = c.r[13];  // 06017C76 mov r13,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06017C7Cu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06017C7Cu) return; }  // 06017C78 jsr @r1 ; mov #0,r4
    goto L_06017C86;  // 06017C7C bra 0x06017C86 ; nop
L_06017C80:
    c.r[1] = ld32(0x06017D2Cu);  // 06017C80 mov.l 0x06017D2C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06017C86u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06017C86u) return; }  // 06017C82 jsr @r1 ; mov #0,r4
L_06017C86:
    c.r[1] = ld32(0x06017D20u);  // 06017C86 mov.l 0x06017D20,r1
    c.r[0] = c.r[1];  // 06017C88 mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 06017C8A mov.b @(r0,r10),r2
    c.r[0] = 0x4u;  // 06017C8C mov #4,r0
    c.r[2] |= c.r[0];  // 06017C8E or r0,r2
    c.r[0] = c.r[1];  // 06017C90 mov r1,r0
    st8(c.r[0] + c.r[10], c.r[2]); goto L_06017CC0;  // 06017C92 bra 0x06017CC0 ; mov.b r2,@(r0,r10)
L_06017C96:
    c.r[2] = ld32(0x06017D04u);  // 06017C96 mov.l 0x06017D04,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06017CF8u);  // 06017C98 mov.w 0x06017CF8,r1
    c.macl = c.r[10] * c.r[1];  // 06017C9A mul.l r1,r10
    c.r[9] = (uint32_t)(int16_t)ld16(0x06017CFAu);  // 06017C9C mov.w 0x06017CFA,r9
    c.r[8] = c.macl;  // 06017C9E sts macl,r8
    c.r[8] += c.r[2];  // 06017CA0 add r2,r8
    c.r[1] = (uint32_t)(int16_t)ld16(0x06017D00u);  // 06017CA2 mov.w 0x06017D00,r1
    c.r[0] = c.r[8];  // 06017CA4 mov r8,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06017CA6 mov.w @(r0,r1),r1
    c.r[3] = c.r[8];  // 06017CA8 mov r8,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[9]);  // 06017CAA mov.w @(r0,r9),r2
    c.r[3] += 70;  // 06017CAC add #70,r3
    c.r[1] += c.r[2];  // 06017CAE add r2,r1
    st16(c.r[3], c.r[1]);  // 06017CB0 mov.w r1,@r3
    c.r[1] = ld32(0x06017D2Cu);  // 06017CB2 mov.l 0x06017D2C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06017CB8u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06017CB8u) return; }  // 06017CB4 jsr @r1 ; mov #0,r4
    c.r[0] = c.r[8];  // 06017CB8 mov r8,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[9]);  // 06017CBA mov.w @(r0,r9),r1
    c.r[1] += 1;  // 06017CBC add #1,r1
    st16(c.r[0] + c.r[9], c.r[1]);  // 06017CBE mov.w r1,@(r0,r9)
L_06017CC0:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06017CF8u);  // 06017CC0 mov.w 0x06017CF8,r1
    c.macl = c.r[10] * c.r[1];  // 06017CC2 mul.l r1,r10
    c.r[2] = ld32(0x06017D04u);  // 06017CC4 mov.l 0x06017D04,r2
    c.r[3] = c.macl;  // 06017CC6 sts macl,r3
    c.r[3] += c.r[2];  // 06017CC8 add r2,r3
    c.r[2] = (uint32_t)(int16_t)ld16(0x06017CFAu);  // 06017CCA mov.w 0x06017CFA,r2
    c.r[0] = c.r[3];  // 06017CCC mov r3,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 06017CCE mov.w @(r0,r2),r1
    c.r[14] += 4;  // 06017CD0 add #4,r14
    c.r[1] += 1;  // 06017CD2 add #1,r1
    st16(c.r[0] + c.r[2], c.r[1]);  // 06017CD4 mov.w r1,@(r0,r2)
    c.r[1] = ld32(0x06017D20u);  // 06017CD6 mov.l 0x06017D20,r1
    c.r[0] = c.r[1];  // 06017CD8 mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 06017CDA mov.b @(r0,r10),r2
    c.r[15] = c.r[14];  // 06017CDC mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x06017D02u);  // 06017CDE mov.w 0x06017D02,r0
    c.r[2] |= c.r[0];  // 06017CE0 or r0,r2
    c.r[0] = c.r[1];  // 06017CE2 mov r1,r0
    st8(c.r[0] + c.r[10], c.r[2]);  // 06017CE4 mov.b r2,@(r0,r10)
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06017CE6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06017CE8 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06017CEA mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06017CEC mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06017CEE mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06017CF0 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06017CF2 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06017CF4 rts ; mov.l @r15+,r8
}

void f_06017D30(SH2Context& c) {
    ran[147] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06017D30 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06017D32 mov r15,r14
    c.r[0] = ld32(0x06017D3Cu);  // 06017D34 mov.l 0x06017D3C,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06017D36 rts ; mov.l @r15+,r14
}

void f_06017D40(SH2Context& c) {
    ran[148] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06017D40 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06017D42 mov r15,r14
    c.r[7] = ld32(0x06017D64u);  // 06017D44 mov.l 0x06017D64,r7
    c.r[3] = ld32(c.r[7]);  // 06017D46 mov.l @r7,r3
    c.r[1] = c.r[3];  // 06017D48 mov r3,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06017D4A mov.b @r3,r2
    c.r[1] += 1;  // 06017D4C add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06017D4E mov.b @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 06017D50 extu.b r2,r2
    c.r[2] <<= 8;  // 06017D52 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06017D54 extu.b r1,r1
    c.r[2] |= c.r[1];  // 06017D56 or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 06017D58 exts.w r2,r2
    c.r[3] += c.r[2];  // 06017D5A add r2,r3
    st32(c.r[7], c.r[3]);  // 06017D5C mov.l r3,@r7
    c.r[0] = ld32(0x06017D68u);  // 06017D5E mov.l 0x06017D68,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06017D60 rts ; mov.l @r15+,r14
}

void f_06017D6C(SH2Context& c) {
    ran[149] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06017D6C mov.l r14,@-r15
    c.r[7] = ld32(0x06017DA4u);  // 06017D6E mov.l 0x06017DA4,r7
    c.r[2] = ld32(c.r[7]);  // 06017D70 mov.l @r7,r2
    c.r[1] = c.r[2];  // 06017D72 mov r2,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 06017D74 mov.b @r1+,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06017D76 mov.b @r1,r1
    c.r[3] <<= 16;  // 06017D78 shll16 r3
    c.r[3] <<= 8;  // 06017D7A shll8 r3
    c.r[1] = c.r[1] & 0xFFu;  // 06017D7C extu.b r1,r1
    c.r[1] <<= 16;  // 06017D7E shll16 r1
    c.r[3] |= c.r[1];  // 06017D80 or r1,r3
    c.r[1] = c.r[2];  // 06017D82 mov r2,r1
    c.r[1] += 2;  // 06017D84 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06017D86 mov.b @r1,r1
    c.r[14] = c.r[15];  // 06017D88 mov r15,r14
    c.r[1] = c.r[1] & 0xFFu;  // 06017D8A extu.b r1,r1
    c.r[1] <<= 8;  // 06017D8C shll8 r1
    c.r[3] |= c.r[1];  // 06017D8E or r1,r3
    c.r[1] = c.r[2];  // 06017D90 mov r2,r1
    c.r[1] += 3;  // 06017D92 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06017D94 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06017D96 extu.b r1,r1
    c.r[3] |= c.r[1];  // 06017D98 or r1,r3
    c.r[2] += c.r[3];  // 06017D9A add r3,r2
    st32(c.r[7], c.r[2]);  // 06017D9C mov.l r2,@r7
    c.r[0] = ld32(0x06017DA8u);  // 06017D9E mov.l 0x06017DA8,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06017DA0 rts ; mov.l @r15+,r14
}

void f_06017DAC(SH2Context& c) {
    ran[150] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06017DAC mov.l r14,@-r15
    c.r[6] = ld32(0x06017DF8u);  // 06017DAE mov.l 0x06017DF8,r6
    c.r[7] = c.r[6];  // 06017DB0 mov r6,r7
    c.r[7] += 68;  // 06017DB2 add #68,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06017DB4 mov.b @r7,r1
    c.r[3] = c.r[1] & 0xFFu;  // 06017DB6 extu.b r1,r3
    c.r[2] = c.r[3];  // 06017DB8 mov r3,r2
    c.r[2] += 1;  // 06017DBA add #1,r2
    c.r[1] = 0x10u;  // 06017DBC mov #16,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 06017DBE cmp/gt r1,r2
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_06017DC8; } }  // 06017DC0 bf/s 0x06017DC8 ; mov r15,r14
    c.r[0] = 0x1u; goto L_06017DF0;  // 06017DC4 bra 0x06017DF0 ; mov #1,r0
L_06017DC8:
    c.r[3] <<= 2;  // 06017DC8 shll2 r3
    c.r[1] = ld32(c.r[6]);  // 06017DCA mov.l @r6,r1
    c.r[3] += c.r[6];  // 06017DCC add r6,r3
    c.r[1] += 2;  // 06017DCE add #2,r1
    st32(c.r[3] + 4, c.r[1]);  // 06017DD0 mov.l r1,@(4,r3)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06017DD2 mov.b @r7,r1
    c.r[1] += 1;  // 06017DD4 add #1,r1
    st8(c.r[7], c.r[1]);  // 06017DD6 mov.b r1,@r7
    c.r[3] = ld32(c.r[6]);  // 06017DD8 mov.l @r6,r3
    c.r[1] = c.r[3];  // 06017DDA mov r3,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 06017DDC mov.b @r1+,r2
    c.r[0] = ld32(0x06017DFCu);  // 06017DDE mov.l 0x06017DFC,r0
    c.r[2] = c.r[2] & 0xFFu;  // 06017DE0 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06017DE2 mov.b @r1,r1
    c.r[2] <<= 8;  // 06017DE4 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06017DE6 extu.b r1,r1
    c.r[2] |= c.r[1];  // 06017DE8 or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 06017DEA exts.w r2,r2
    c.r[3] += c.r[2];  // 06017DEC add r2,r3
    st32(c.r[6], c.r[3]);  // 06017DEE mov.l r3,@r6
L_06017DF0:
    c.r[15] = c.r[14];  // 06017DF0 mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06017DF2 rts ; mov.l @r15+,r14
}

void f_06017E00(SH2Context& c) {
    ran[151] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06017E00 mov.l r14,@-r15
    c.r[3] = ld32(0x06017E34u);  // 06017E02 mov.l 0x06017E34,r3
    c.r[7] = c.r[3];  // 06017E04 mov r3,r7
    c.r[7] += 68;  // 06017E06 add #68,r7
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06017E08 mov.b @r7,r2
    c.r[1] = c.r[2] & 0xFFu;  // 06017E0A extu.b r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06017E0C tst r1,r1
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_06017E16; } }  // 06017E0E bf/s 0x06017E16 ; mov r15,r14
    c.r[0] = 0x2u; goto L_06017E2C;  // 06017E12 bra 0x06017E2C ; mov #2,r0
L_06017E16:
    c.r[1] = c.r[2];  // 06017E16 mov r2,r1
    c.r[1] -= 1;  // 06017E18 add #-1,r1
    st8(c.r[7], c.r[1]);  // 06017E1A mov.b r1,@r7
    c.r[1] = c.r[1] & 0xFFu;  // 06017E1C extu.b r1,r1
    c.r[1] <<= 2;  // 06017E1E shll2 r1
    c.r[1] += c.r[3];  // 06017E20 add r3,r1
    c.r[2] = ld32(c.r[1] + 4);  // 06017E22 mov.l @(4,r1),r2
    c.r[0] = ld32(0x06017E38u);  // 06017E24 mov.l 0x06017E38,r0
    st32(c.r[3], c.r[2]);  // 06017E26 mov.l r2,@r3
    c.r[2] = 0x0u;  // 06017E28 mov #0,r2
    st32(c.r[1] + 4, c.r[2]);  // 06017E2A mov.l r2,@(4,r1)
L_06017E2C:
    c.r[15] = c.r[14];  // 06017E2C mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06017E2E rts ; mov.l @r15+,r14
}

void f_06017E3C(SH2Context& c) {
    ran[152] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06017E3C mov.l r14,@-r15
    c.r[7] = ld32(0x06017E8Cu);  // 06017E3E mov.l 0x06017E8C,r7
    c.r[2] = c.r[7];  // 06017E40 mov r7,r2
    c.r[2] += 69;  // 06017E42 add #69,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06017E44 mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06017E46 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06017E48 tst r1,r1
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_06017E54; } }  // 06017E4A bf/s 0x06017E54 ; mov r15,r14
    c.r[1] = ld32(c.r[7]);  // 06017E4E mov.l @r7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06017E50 mov.b @r1,r1
    st8(c.r[2], c.r[1]);  // 06017E52 mov.b r1,@r2
L_06017E54:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06017E54 mov.b @r2,r1
    c.r[1] -= 1;  // 06017E56 add #-1,r1
    st8(c.r[2], c.r[1]);  // 06017E58 mov.b r1,@r2
    c.r[1] = c.r[1] & 0xFFu;  // 06017E5A extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06017E5C tst r1,r1
    if (c.t) { goto L_06017E82; }  // 06017E5E bt 0x06017E82
    c.r[3] = ld32(c.r[7]);  // 06017E60 mov.l @r7,r3
    c.r[1] = c.r[3];  // 06017E62 mov r3,r1
    c.r[1] += 1;  // 06017E64 add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06017E66 mov.b @r1,r2
    c.r[0] = ld32(0x06017E90u);  // 06017E68 mov.l 0x06017E90,r0
    c.r[2] = c.r[2] & 0xFFu;  // 06017E6A extu.b r2,r2
    c.r[1] = c.r[3];  // 06017E6C mov r3,r1
    c.r[1] += 2;  // 06017E6E add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06017E70 mov.b @r1,r1
    c.r[2] <<= 8;  // 06017E72 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06017E74 extu.b r1,r1
    c.r[2] |= c.r[1];  // 06017E76 or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 06017E78 exts.w r2,r2
    c.r[2] += 1;  // 06017E7A add #1,r2
    c.r[3] += c.r[2];  // 06017E7C add r2,r3
    st32(c.r[7], c.r[3]); goto L_06017E84;  // 06017E7E bra 0x06017E84 ; mov.l r3,@r7
L_06017E82:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06017E8Au);  // 06017E82 mov.w 0x06017E8A,r0
L_06017E84:
    c.r[15] = c.r[14];  // 06017E84 mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06017E86 rts ; mov.l @r15+,r14
}

void f_06017E94(SH2Context& c) {
    ran[153] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06017E94 mov.l r14,@-r15
    c.r[7] = ld32(0x06017EE4u);  // 06017E96 mov.l 0x06017EE4,r7
    c.r[3] = c.r[7];  // 06017E98 mov r7,r3
    c.r[3] += 68;  // 06017E9A add #68,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06017E9C mov.b @r3,r2
    c.r[1] = c.r[2];  // 06017E9E mov r2,r1
    c.r[1] += 1;  // 06017EA0 add #1,r1
    st8(c.r[3], c.r[1]);  // 06017EA2 mov.b r1,@r3
    c.r[2] = c.r[2] & 0xFFu;  // 06017EA4 extu.b r2,r2
    c.r[2] <<= 2;  // 06017EA6 shll2 r2
    c.r[1] = ld32(c.r[7]);  // 06017EA8 mov.l @r7,r1
    c.r[2] += c.r[7];  // 06017EAA add r7,r2
    c.r[1] += 4;  // 06017EAC add #4,r1
    st32(c.r[2] + 4, c.r[1]);  // 06017EAE mov.l r1,@(4,r2)
    c.r[2] = ld32(c.r[7]);  // 06017EB0 mov.l @r7,r2
    c.r[1] = c.r[2];  // 06017EB2 mov r2,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 06017EB4 mov.b @r1+,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06017EB6 mov.b @r1,r1
    c.r[3] <<= 16;  // 06017EB8 shll16 r3
    c.r[3] <<= 8;  // 06017EBA shll8 r3
    c.r[1] = c.r[1] & 0xFFu;  // 06017EBC extu.b r1,r1
    c.r[1] <<= 16;  // 06017EBE shll16 r1
    c.r[3] |= c.r[1];  // 06017EC0 or r1,r3
    c.r[1] = c.r[2];  // 06017EC2 mov r2,r1
    c.r[1] += 2;  // 06017EC4 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06017EC6 mov.b @r1,r1
    c.r[14] = c.r[15];  // 06017EC8 mov r15,r14
    c.r[1] = c.r[1] & 0xFFu;  // 06017ECA extu.b r1,r1
    c.r[1] <<= 8;  // 06017ECC shll8 r1
    c.r[3] |= c.r[1];  // 06017ECE or r1,r3
    c.r[1] = c.r[2];  // 06017ED0 mov r2,r1
    c.r[1] += 3;  // 06017ED2 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06017ED4 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06017ED6 extu.b r1,r1
    c.r[3] |= c.r[1];  // 06017ED8 or r1,r3
    c.r[2] += c.r[3];  // 06017EDA add r3,r2
    st32(c.r[7], c.r[2]);  // 06017EDC mov.l r2,@r7
    c.r[0] = ld32(0x06017EE8u);  // 06017EDE mov.l 0x06017EE8,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06017EE0 rts ; mov.l @r15+,r14
}

void f_06017EEC(SH2Context& c) {
    ran[154] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06017EEC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06017EEE mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06017EF0 sts.l pr,@-r15
    c.r[8] = ld32(0x06017F38u);  // 06017EF2 mov.l 0x06017F38,r8
    c.r[7] = c.r[8];  // 06017EF4 mov r8,r7
    c.r[7] += 68;  // 06017EF6 add #68,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06017EF8 mov.b @r7,r1
    c.r[3] = c.r[1] & 0xFFu;  // 06017EFA extu.b r1,r3
    c.r[2] = c.r[3];  // 06017EFC mov r3,r2
    c.r[2] += 1;  // 06017EFE add #1,r2
    c.r[1] = 0x10u;  // 06017F00 mov #16,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 06017F02 cmp/gt r1,r2
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_06017F0C; } }  // 06017F04 bf/s 0x06017F0C ; mov r15,r14
    c.r[0] = 0x1u; goto L_06017F2C;  // 06017F08 bra 0x06017F2C ; mov #1,r0
L_06017F0C:
    c.r[3] <<= 2;  // 06017F0C shll2 r3
    c.r[1] = ld32(c.r[8]);  // 06017F0E mov.l @r8,r1
    c.r[3] += c.r[8];  // 06017F10 add r8,r3
    c.r[1] += 1;  // 06017F12 add #1,r1
    st32(c.r[3] + 4, c.r[1]);  // 06017F14 mov.l r1,@(4,r3)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06017F16 mov.b @r7,r1
    c.r[1] += 1;  // 06017F18 add #1,r1
    st8(c.r[7], c.r[1]);  // 06017F1A mov.b r1,@r7
    c.r[1] = ld32(c.r[8]);  // 06017F1C mov.l @r8,r1
    c.r[0] = ld32(0x06017F3Cu);  // 06017F1E mov.l 0x06017F3C,r0
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06017F20 mov.b @r1,r5
    c.r[4] = 0x3u;  // 06017F22 mov #3,r4
    { const uint32_t x = c.r[0]; c.pr = 0x06017F28u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06017F28u) return; }  // 06017F24 jsr @r0 ; extu.b r5,r5
    st32(c.r[8], c.r[0]);  // 06017F28 mov.l r0,@r8
    c.r[0] = ld32(0x06017F40u);  // 06017F2A mov.l 0x06017F40,r0
L_06017F2C:
    c.r[15] = c.r[14];  // 06017F2C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06017F2E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06017F30 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06017F32 rts ; mov.l @r15+,r8
}

void f_06017F44(SH2Context& c) {
    ran[155] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06017F44 mov.l r14,@-r15
    c.r[2] = ld32(0x06017F7Cu);  // 06017F46 mov.l 0x06017F7C,r2
    c.r[3] = c.r[2];  // 06017F48 mov r2,r3
    c.r[3] += 72;  // 06017F4A add #72,r3
    c.r[1] = ld32(c.r[3]);  // 06017F4C mov.l @r3,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06017F4E tst r1,r1
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_06017F66; } }  // 06017F50 bf/s 0x06017F66 ; mov r15,r14
    c.r[1] = ld32(c.r[2]);  // 06017F54 mov.l @r2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 06017F56 mov.b @r1+,r2
    c.r[2] = c.r[2] & 0xFFu;  // 06017F58 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06017F5A mov.b @r1,r1
    c.r[2] <<= 8;  // 06017F5C shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06017F5E extu.b r1,r1
    c.r[2] |= c.r[1];  // 06017F60 or r1,r2
    st32(c.r[3], c.r[2]);  // 06017F62 mov.l r2,@r3
    c.r[1] = ld32(c.r[3]);  // 06017F64 mov.l @r3,r1
L_06017F66:
    c.r[1] -= 1; c.t = c.r[1] == 0;  // 06017F66 dt r1
    { const bool k = !c.t; st32(c.r[3], c.r[1]); if (k) { goto L_06017F72; } }  // 06017F68 bf/s 0x06017F72 ; mov.l r1,@r3
    c.r[0] = ld32(0x06017F80u);  // 06017F6C mov.l 0x06017F80,r0
    c.r[15] = c.r[14]; goto L_06017F76;  // 06017F6E bra 0x06017F76 ; mov r14,r15
L_06017F72:
    c.r[0] = 0x0u;  // 06017F72 mov #0,r0
    c.r[15] = c.r[14];  // 06017F74 mov r14,r15
L_06017F76:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06017F76 rts ; mov.l @r15+,r14
}

void f_06017F84(SH2Context& c) {
    ran[156] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06017F84 mov.l r14,@-r15
    c.r[1] = ld32(0x06017FA8u);  // 06017F86 mov.l 0x06017FA8,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06017F88 mov.w @r1,r2
    c.r[1] = c.r[2] & 0xFFFFu;  // 06017F8A extu.w r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06017F8C tst r1,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06017F9A; } }  // 06017F8E bt/s 0x06017F9A ; mov r15,r14
    c.r[1] = (uint32_t)(int16_t)ld16(0x06017FA6u);  // 06017F92 mov.w 0x06017FA6,r1
    c.r[1] &= c.r[2];  // 06017F94 and r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06017F96 tst r1,r1
    if (c.t) { goto L_06017F9E; }  // 06017F98 bt 0x06017F9E
L_06017F9A:
    c.r[0] = 0x0u; goto L_06017FA0;  // 06017F9A bra 0x06017FA0 ; mov #0,r0
L_06017F9E:
    c.r[0] = ld32(0x06017FACu);  // 06017F9E mov.l 0x06017FAC,r0
L_06017FA0:
    c.r[15] = c.r[14];  // 06017FA0 mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06017FA2 rts ; mov.l @r15+,r14
}

void f_06017FB0(SH2Context& c) {
    ran[157] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06017FB0 mov.l r14,@-r15
    c.r[2] = ld32(0x06017FF8u);  // 06017FB2 mov.l 0x06017FF8,r2
    c.r[3] = c.r[2];  // 06017FB4 mov r2,r3
    c.r[3] += 72;  // 06017FB6 add #72,r3
    c.r[1] = ld32(c.r[3]);  // 06017FB8 mov.l @r3,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06017FBA tst r1,r1
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_06017FD0; } }  // 06017FBC bf/s 0x06017FD0 ; mov r15,r14
    c.r[1] = ld32(c.r[2]);  // 06017FC0 mov.l @r2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 06017FC2 mov.b @r1+,r2
    c.r[2] = c.r[2] & 0xFFu;  // 06017FC4 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06017FC6 mov.b @r1,r1
    c.r[2] <<= 8;  // 06017FC8 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06017FCA extu.b r1,r1
    c.r[2] |= c.r[1];  // 06017FCC or r1,r2
    st32(c.r[3], c.r[2]);  // 06017FCE mov.l r2,@r3
L_06017FD0:
    c.r[1] = ld32(0x06017FFCu);  // 06017FD0 mov.l 0x06017FFC,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06017FD2 mov.w @r1,r2
    c.r[1] = c.r[2] & 0xFFFFu;  // 06017FD4 extu.w r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06017FD6 tst r1,r1
    if (c.t) { goto L_06017FE2; }  // 06017FD8 bt 0x06017FE2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06017FF6u);  // 06017FDA mov.w 0x06017FF6,r1
    c.r[1] &= c.r[2];  // 06017FDC and r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06017FDE tst r1,r1
    if (c.t) { goto L_06017FEE; }  // 06017FE0 bt 0x06017FEE
L_06017FE2:
    c.r[1] = ld32(c.r[3]);  // 06017FE2 mov.l @r3,r1
    c.r[1] -= 1; c.t = c.r[1] == 0;  // 06017FE4 dt r1
    { const bool k = c.t; st32(c.r[3], c.r[1]); if (k) { goto L_06017FEE; } }  // 06017FE6 bt/s 0x06017FEE ; mov.l r1,@r3
    c.r[0] = 0x0u; goto L_06017FF0;  // 06017FEA bra 0x06017FF0 ; mov #0,r0
L_06017FEE:
    c.r[0] = ld32(0x06018000u);  // 06017FEE mov.l 0x06018000,r0
L_06017FF0:
    c.r[15] = c.r[14];  // 06017FF0 mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06017FF2 rts ; mov.l @r15+,r14
}

void f_06018004(SH2Context& c) {
    ran[158] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06018004 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06018006 mov r15,r14
    c.r[0] = ld32(0x06018010u);  // 06018008 mov.l 0x06018010,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601800A rts ; mov.l @r15+,r14
}

void f_06018014(SH2Context& c) {
    ran[159] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06018014 mov.l r14,@-r15
    c.r[1] = ld32(0x06018040u);  // 06018016 mov.l 0x06018040,r1
    c.r[1] = ld32(c.r[1]);  // 06018018 mov.l @r1,r1
    c.r[1] += 1;  // 0601801A add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601801C mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601801E extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06018020 tst r1,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0601802E; } }  // 06018022 bt/s 0x0601802E ; mov r15,r14
    c.r[1] = ld32(0x06018044u);  // 06018026 mov.l 0x06018044,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06018028 mov.b @r1,r0
    c.r[0] |= 0x1u; goto L_06018034;  // 0601802A bra 0x06018034 ; or #1,r0
L_0601802E:
    c.r[1] = ld32(0x06018044u);  // 0601802E mov.l 0x06018044,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06018030 mov.b @r1,r0
    c.r[0] &= 0xFEu;  // 06018032 and #254,r0
L_06018034:
    st8(c.r[1], c.r[0]);  // 06018034 mov.b r0,@r1
    c.r[15] = c.r[14];  // 06018036 mov r14,r15
    c.r[0] = ld32(0x06018048u);  // 06018038 mov.l 0x06018048,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601803A rts ; mov.l @r15+,r14
}

void f_0601804C(SH2Context& c) {
    ran[160] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601804C mov.l r14,@-r15
    c.r[2] = ld32(0x060180B4u);  // 0601804E mov.l 0x060180B4,r2
    c.r[1] = ld32(c.r[2]);  // 06018050 mov.l @r2,r1
    c.r[1] += 1;  // 06018052 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06018054 mov.b @r1,r1
    c.r[7] = c.r[1] & 0xFFu;  // 06018056 extu.b r1,r7
    c.r[7] >>= 2;  // 06018058 shlr2 r7
    c.r[7] >>= 2;  // 0601805A shlr2 r7
    c.r[0] = c.r[7];  // 0601805C mov r7,r0
    c.t = c.r[0] == 0xDu;  // 0601805E cmp/eq #13,r0
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0601808A; } }  // 06018060 bf/s 0x0601808A ; mov r15,r14
    c.r[6] = ld32(0x060180B8u);  // 06018064 mov.l 0x060180B8,r6
    c.r[3] = c.r[2];  // 06018066 mov r2,r3
L_06018068:
    c.r[1] = c.r[7];  // 06018068 mov r7,r1
    c.r[1] -= 1;  // 0601806A add #-1,r1
    c.r[7] = c.r[1] & 0xFFu;  // 0601806C extu.b r1,r7
    c.r[2] = c.r[7];  // 0601806E mov r7,r2
    c.r[2] += c.r[2];  // 06018070 add r2,r2
    c.r[2] += c.r[7];  // 06018072 add r7,r2
    c.r[2] += c.r[6];  // 06018074 add r6,r2
    c.r[1] = ld32(c.r[3]);  // 06018076 mov.l @r3,r1
    c.r[2] += 2;  // 06018078 add #2,r2
    c.r[1] += 1;  // 0601807A add #1,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601807C mov.b @r1,r0
    c.t = (c.r[7] & c.r[7]) == 0;  // 0601807E tst r7,r7
    c.r[0] &= 0x1u;  // 06018080 and #1,r0
    { const bool k = !c.t; st8(c.r[2], c.r[0]); if (k) { SH2_POLL(c); goto L_06018068; } }  // 06018082 bf/s 0x06018068 ; mov.b r0,@r2
    c.r[15] = c.r[14]; goto L_060180AC;  // 06018086 bra 0x060180AC ; mov r14,r15
L_0601808A:
    c.r[0] = c.r[1];  // 0601808A mov r1,r0
    c.r[0] &= 0x1u;  // 0601808C and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601808E tst r0,r0
    { const bool k = c.t; c.r[3] = c.r[7]; if (k) { goto L_0601809E; } }  // 06018090 bt/s 0x0601809E ; mov r7,r3
    c.r[3] += c.r[3];  // 06018094 add r3,r3
    c.r[3] += c.r[7];  // 06018096 add r7,r3
    c.r[2] = ld32(0x060180BCu);  // 06018098 mov.l 0x060180BC,r2
    c.r[1] = 0x1u; goto L_060180A6;  // 0601809A bra 0x060180A6 ; mov #1,r1
L_0601809E:
    c.r[3] += c.r[3];  // 0601809E add r3,r3
    c.r[3] += c.r[7];  // 060180A0 add r7,r3
    c.r[2] = ld32(0x060180BCu);  // 060180A2 mov.l 0x060180BC,r2
    c.r[1] = 0x0u;  // 060180A4 mov #0,r1
L_060180A6:
    c.r[0] = c.r[3];  // 060180A6 mov r3,r0
    st8(c.r[0] + c.r[2], c.r[1]);  // 060180A8 mov.b r1,@(r0,r2)
    c.r[15] = c.r[14];  // 060180AA mov r14,r15
L_060180AC:
    c.r[0] = ld32(0x060180C0u);  // 060180AC mov.l 0x060180C0,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060180AE rts ; mov.l @r15+,r14
}

void f_060180C4(SH2Context& c) {
    ran[161] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060180C4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060180C6 sts.l pr,@-r15
    c.r[1] = ld32(0x060180E4u);  // 060180C8 mov.l 0x060180E4,r1
    c.r[1] = ld32(c.r[1]);  // 060180CA mov.l @r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060180CC mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 060180CE extu.b r1,r0
    c.r[0] <<= 2;  // 060180D0 shll2 r0
    c.r[1] = ld32(0x060180E8u);  // 060180D2 mov.l 0x060180E8,r1
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 060180D4 mov.l @(r0,r1),r0
    { const uint32_t x = c.r[0]; c.pr = 0x060180DAu; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060180DAu) return; }  // 060180D6 jsr @r0 ; mov r15,r14
    c.r[15] = c.r[14];  // 060180DA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060180DC lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060180DE mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[0] & 0xFFFFu; c.pc = x; return; }  // 060180E0 rts ; extu.w r0,r0
}

void f_060180EC(SH2Context& c) {
    ran[162] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060180EC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060180EE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060180F0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060180F2 sts.l pr,@-r15
    c.r[3] = ld32(0x06018184u);  // 060180F4 mov.l 0x06018184,r3
    c.r[2] = c.r[3];  // 060180F6 mov r3,r2
    c.r[2] += 72;  // 060180F8 add #72,r2
    c.r[1] = ld32(c.r[2]);  // 060180FA mov.l @r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060180FC tst r1,r1
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_06018112; } }  // 060180FE bf/s 0x06018112 ; mov r15,r14
    c.r[1] = (uint32_t)(int16_t)ld16(0x06018182u);  // 06018102 mov.w 0x06018182,r1
    st32(c.r[2], c.r[1]);  // 06018104 mov.l r1,@r2
    c.r[2] = c.r[3];  // 06018106 mov r3,r2
    c.r[2] += 76;  // 06018108 add #76,r2
    st32(c.r[2], c.r[1]);  // 0601810A mov.l r1,@r2
    c.r[2] = c.r[3];  // 0601810C mov r3,r2
    c.r[2] += 80;  // 0601810E add #80,r2
    st32(c.r[2], c.r[1]);  // 06018110 mov.l r1,@r2
L_06018112:
    c.r[1] = c.r[3];  // 06018112 mov r3,r1
    c.r[1] += 76;  // 06018114 add #76,r1
    c.r[7] = c.r[3];  // 06018116 mov r3,r7
    c.r[1] = ld32(c.r[1]);  // 06018118 mov.l @r1,r1
    c.r[7] += 80;  // 0601811A add #80,r7
    c.r[2] = ld32(c.r[7]);  // 0601811C mov.l @r7,r2
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 0601811E cmp/gt r2,r1
    if (c.t) { goto L_06018140; }  // 06018120 bt 0x06018140
    c.r[1] = ld32(c.r[3]);  // 06018122 mov.l @r3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06018124 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06018126 extu.b r1,r1
    c.r[2] -= c.r[1];  // 06018128 sub r1,r2
    st32(c.r[7], c.r[2]);  // 0601812A mov.l r2,@r7
    c.r[1] = ld32(0x06018188u);  // 0601812C mov.l 0x06018188,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0601812E mov.w @r1,r4
    c.t = (int32_t)c.r[2] > (int32_t)c.r[4];  // 06018130 cmp/gt r4,r2
    { const bool k = !c.t; c.r[3] += 82; if (k) { goto L_06018138; } }  // 06018132 bf/s 0x06018138 ; add #82,r3
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06018136 mov.w @r3,r4
L_06018138:
    c.r[1] = ld32(0x0601818Cu);  // 06018138 mov.l 0x0601818C,r1
    c.r[6] = c.r[4];  // 0601813A mov r4,r6
    { const uint32_t x = c.r[1]; c.pr = 0x06018140u; c.r[5] = c.r[4]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06018140u) return; }  // 0601813C jsr @r1 ; mov r4,r5
L_06018140:
    c.r[8] = ld32(0x06018184u);  // 06018140 mov.l 0x06018184,r8
    c.r[9] = c.r[8];  // 06018142 mov r8,r9
    c.r[9] += 76;  // 06018144 add #76,r9
    c.r[1] = ld32(c.r[9]);  // 06018146 mov.l @r9,r1
    c.t = (int32_t)c.r[1] > 0;  // 06018148 cmp/pl r1
    { const bool k = !c.t; c.r[1] = c.r[8]; if (k) { goto L_0601816A; } }  // 0601814A bf/s 0x0601816A ; mov r8,r1
    c.r[1] += 78;  // 0601814E add #78,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06018150 mov.w @r1,r4
    c.r[1] = ld32(0x06018190u);  // 06018152 mov.l 0x06018190,r1
    c.r[6] = c.r[4];  // 06018154 mov r4,r6
    { const uint32_t x = c.r[1]; c.pr = 0x0601815Au; c.r[5] = c.r[4]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601815Au) return; }  // 06018156 jsr @r1 ; mov r4,r5
    c.r[1] = ld32(c.r[8]);  // 0601815A mov.l @r8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601815C mov.b @r1,r1
    c.r[0] = ld32(0x06018194u);  // 0601815E mov.l 0x06018194,r0
    c.r[2] = ld32(c.r[9]);  // 06018160 mov.l @r9,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06018162 extu.b r1,r1
    c.r[2] -= c.r[1];  // 06018164 sub r1,r2
    st32(c.r[9], c.r[2]); goto L_06018176;  // 06018166 bra 0x06018176 ; mov.l r2,@r9
L_0601816A:
    c.r[1] = ld32(0x06018190u);  // 0601816A mov.l 0x06018190,r1
    c.r[6] = 0x0u;  // 0601816C mov #0,r6
    c.r[5] = 0x0u;  // 0601816E mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06018174u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06018174u) return; }  // 06018170 jsr @r1 ; mov #0,r4
    c.r[0] = ld32(0x06018198u);  // 06018174 mov.l 0x06018198,r0
L_06018176:
    c.r[15] = c.r[14];  // 06018176 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06018178 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601817A mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0601817C mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601817E rts ; mov.l @r15+,r8
}

void f_0601819C(SH2Context& c) {
    ran[163] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601819C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601819E sts.l pr,@-r15
    c.r[3] = ld32(0x0601822Cu);  // 060181A0 mov.l 0x0601822C,r3
    c.r[7] = c.r[3];  // 060181A2 mov r3,r7
    c.r[7] += 72;  // 060181A4 add #72,r7
    c.r[2] = ld32(c.r[7]);  // 060181A6 mov.l @r7,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 060181A8 tst r2,r2
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_060181C2; } }  // 060181AA bf/s 0x060181C2 ; mov r15,r14
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601822Au);  // 060181AE mov.w 0x0601822A,r1
    st32(c.r[7], c.r[1]);  // 060181B0 mov.l r1,@r7
    c.r[1] = c.r[3];  // 060181B2 mov r3,r1
    c.r[1] += 76;  // 060181B4 add #76,r1
    st32(c.r[1], c.r[2]);  // 060181B6 mov.l r2,@r1
    c.r[2] = c.r[3];  // 060181B8 mov r3,r2
    c.r[1] = ld32(0x06018230u);  // 060181BA mov.l 0x06018230,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060181BC mov.w @r1,r1
    c.r[2] += 80;  // 060181BE add #80,r2
    st32(c.r[2], c.r[1]);  // 060181C0 mov.l r1,@r2
L_060181C2:
    c.r[1] = c.r[3];  // 060181C2 mov r3,r1
    c.r[1] += 76;  // 060181C4 add #76,r1
    c.r[7] = c.r[3];  // 060181C6 mov r3,r7
    c.r[1] = ld32(c.r[1]);  // 060181C8 mov.l @r1,r1
    c.r[7] += 80;  // 060181CA add #80,r7
    c.r[2] = ld32(c.r[7]);  // 060181CC mov.l @r7,r2
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[2];  // 060181CE cmp/ge r2,r1
    if (!c.t) { goto L_060181EE; }  // 060181D0 bf 0x060181EE
    c.r[1] = ld32(c.r[3]);  // 060181D2 mov.l @r3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060181D4 mov.b @r1,r1
    c.r[4] = (uint32_t)(int16_t)ld16(0x0601822Au);  // 060181D6 mov.w 0x0601822A,r4
    c.r[1] = c.r[1] & 0xFFu;  // 060181D8 extu.b r1,r1
    c.r[1] += c.r[2];  // 060181DA add r2,r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[4];  // 060181DC cmp/gt r4,r1
    { const bool k = c.t; st32(c.r[7], c.r[1]); if (k) { goto L_060181E6; } }  // 060181DE bt/s 0x060181E6 ; mov.l r1,@r7
    c.r[3] += 82;  // 060181E2 add #82,r3
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[3]);  // 060181E4 mov.w @r3,r4
L_060181E6:
    c.r[1] = ld32(0x06018234u);  // 060181E6 mov.l 0x06018234,r1
    c.r[6] = c.r[4];  // 060181E8 mov r4,r6
    { const uint32_t x = c.r[1]; c.pr = 0x060181EEu; c.r[5] = c.r[4]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060181EEu) return; }  // 060181EA jsr @r1 ; mov r4,r5
L_060181EE:
    c.r[7] = ld32(0x0601822Cu);  // 060181EE mov.l 0x0601822C,r7
    c.r[3] = c.r[7];  // 060181F0 mov r7,r3
    c.r[1] = ld32(c.r[7]);  // 060181F2 mov.l @r7,r1
    c.r[3] += 76;  // 060181F4 add #76,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060181F6 mov.b @r1,r1
    c.r[4] = (uint32_t)(int16_t)ld16(0x0601822Au);  // 060181F8 mov.w 0x0601822A,r4
    c.r[2] = ld32(c.r[3]);  // 060181FA mov.l @r3,r2
    c.r[1] = c.r[1] & 0xFFu;  // 060181FC extu.b r1,r1
    c.r[2] += c.r[1];  // 060181FE add r1,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[4];  // 06018200 cmp/gt r4,r2
    { const bool k = c.t; st32(c.r[3], c.r[2]); if (k) { goto L_06018218; } }  // 06018202 bt/s 0x06018218 ; mov.l r2,@r3
    c.r[7] += 78;  // 06018206 add #78,r7
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[7]);  // 06018208 mov.w @r7,r4
    c.r[1] = ld32(0x06018238u);  // 0601820A mov.l 0x06018238,r1
    c.r[6] = c.r[4];  // 0601820C mov r4,r6
    { const uint32_t x = c.r[1]; c.pr = 0x06018212u; c.r[5] = c.r[4]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06018212u) return; }  // 0601820E jsr @r1 ; mov r4,r5
    c.r[0] = ld32(0x0601823Cu);  // 06018212 mov.l 0x0601823C,r0
    c.r[15] = c.r[14]; goto L_06018224;  // 06018214 bra 0x06018224 ; mov r14,r15
L_06018218:
    c.r[1] = ld32(0x06018238u);  // 06018218 mov.l 0x06018238,r1
    c.r[6] = c.r[4];  // 0601821A mov r4,r6
    { const uint32_t x = c.r[1]; c.pr = 0x06018220u; c.r[5] = c.r[4]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06018220u) return; }  // 0601821C jsr @r1 ; mov r4,r5
    c.r[0] = ld32(0x06018240u);  // 06018220 mov.l 0x06018240,r0
    c.r[15] = c.r[14];  // 06018222 mov r14,r15
L_06018224:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06018224 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06018226 rts ; mov.l @r15+,r14
}

void f_06018244(SH2Context& c) {
    ran[164] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06018244 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06018246 mov r15,r14
    c.r[1] = ld32(0x06018258u);  // 06018248 mov.l 0x06018258,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601824A mov.b @r1,r0
    c.r[0] |= 0x80u;  // 0601824C or #128,r0
    st8(c.r[1], c.r[0]);  // 0601824E mov.b r0,@r1
    c.r[0] = ld32(0x0601825Cu);  // 06018250 mov.l 0x0601825C,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06018252 rts ; mov.l @r15+,r14
}

void f_06018260(SH2Context& c) {
    ran[165] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06018260 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06018262 mov r15,r14
    c.r[1] = ld32(0x06018274u);  // 06018264 mov.l 0x06018274,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06018266 mov.b @r1,r0
    c.r[0] &= 0x7Fu;  // 06018268 and #127,r0
    st8(c.r[1], c.r[0]);  // 0601826A mov.b r0,@r1
    c.r[0] = ld32(0x06018278u);  // 0601826C mov.l 0x06018278,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601826E rts ; mov.l @r15+,r14
}

void f_0601827C(SH2Context& c) {
    ran[166] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601827C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601827E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06018280 sts.l pr,@-r15
    c.r[3] = ld32(0x06018380u);  // 06018282 mov.l 0x06018380,r3
    c.r[1] = c.r[3];  // 06018284 mov r3,r1
    c.r[1] += 72;  // 06018286 add #72,r1
    c.r[2] = ld32(c.r[1]);  // 06018288 mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0601828A tst r2,r2
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_060182F2; } }  // 0601828C bf/s 0x060182F2 ; mov r15,r14
    c.r[1] = ld32(0x06018384u);  // 06018290 mov.l 0x06018384,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06018292 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06018294 extu.b r1,r0
    c.r[0] >>= 2;  // 06018296 shlr2 r0
    c.r[0] >>= 2;  // 06018298 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0601829A shlr r0
    c.r[0] >>= 2;  // 0601829C shlr2 r0
    c.t = c.r[0] == 0x1u;  // 0601829E cmp/eq #1,r0
    if (!c.t) { goto L_060182C4; }  // 060182A0 bf 0x060182C4
    c.r[1] = ld32(0x06018388u);  // 060182A2 mov.l 0x06018388,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060182A4 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 060182A6 extu.b r1,r0
    c.t = c.r[0] == 0x2u;  // 060182A8 cmp/eq #2,r0
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_060182C4; } }  // 060182AA bt/s 0x060182C4 ; mov r3,r1
    c.r[1] += 76;  // 060182AE add #76,r1
    st32(c.r[1], c.r[2]);  // 060182B0 mov.l r2,@r1
    c.r[3] += 80;  // 060182B2 add #80,r3
    st32(c.r[3], c.r[2]);  // 060182B4 mov.l r2,@r3
    c.r[1] = ld32(0x0601838Cu);  // 060182B6 mov.l 0x0601838C,r1
    c.r[6] = 0x0u;  // 060182B8 mov #0,r6
    c.r[5] = 0x0u;  // 060182BA mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x060182C0u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060182C0u) return; }  // 060182BC jsr @r1 ; mov #0,r4
    goto L_06018352;  // 060182C0 bra 0x06018352 ; nop
L_060182C4:
    c.r[1] = ld32(0x06018390u);  // 060182C4 mov.l 0x06018390,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060182CAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060182CAu) return; }  // 060182C6 jsr @r1 ; nop
    c.r[2] = ld32(0x06018380u);  // 060182CA mov.l 0x06018380,r2
    c.r[1] = c.r[2];  // 060182CC mov r2,r1
    c.r[1] += 76;  // 060182CE add #76,r1
    c.r[8] = (uint32_t)(int16_t)ld16(0x0601837Au);  // 060182D0 mov.w 0x0601837A,r8
    st32(c.r[1], c.r[8]);  // 060182D2 mov.l r8,@r1
    c.r[2] += 80;  // 060182D4 add #80,r2
    st32(c.r[2], c.r[8]);  // 060182D6 mov.l r8,@r2
    c.r[1] = ld32(0x0601838Cu);  // 060182D8 mov.l 0x0601838C,r1
    c.r[6] = c.r[8];  // 060182DA mov r8,r6
    c.r[5] = c.r[8];  // 060182DC mov r8,r5
    { const uint32_t x = c.r[1]; c.pr = 0x060182E2u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060182E2u) return; }  // 060182DE jsr @r1 ; mov r8,r4
    c.r[1] = ld32(0x06018394u);  // 060182E2 mov.l 0x06018394,r1
    c.r[6] = c.r[8];  // 060182E4 mov r8,r6
    c.r[5] = c.r[8];  // 060182E6 mov r8,r5
    { const uint32_t x = c.r[1]; c.pr = 0x060182ECu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060182ECu) return; }  // 060182E8 jsr @r1 ; mov r8,r4
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601837Cu);  // 060182EC mov.w 0x0601837C,r0
    c.r[15] = c.r[14]; goto L_06018372;  // 060182EE bra 0x06018372 ; mov r14,r15
L_060182F2:
    c.r[1] = c.r[3];  // 060182F2 mov r3,r1
    c.r[1] += 76;  // 060182F4 add #76,r1
    c.r[6] = c.r[3];  // 060182F6 mov r3,r6
    c.r[1] = ld32(c.r[1]);  // 060182F8 mov.l @r1,r1
    c.r[6] += 80;  // 060182FA add #80,r6
    c.r[7] = ld32(c.r[6]);  // 060182FC mov.l @r6,r7
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[7];  // 060182FE cmp/ge r7,r1
    if (!c.t) { goto L_06018320; }  // 06018300 bf 0x06018320
    c.r[1] = ld32(c.r[3]);  // 06018302 mov.l @r3,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06018304 mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 06018306 extu.b r2,r2
    c.r[2] += c.r[7];  // 06018308 add r7,r2
    st32(c.r[6], c.r[2]);  // 0601830A mov.l r2,@r6
    c.r[1] = ld32(0x06018398u);  // 0601830C mov.l 0x06018398,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0601830E mov.w @r1,r4
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[4];  // 06018310 cmp/ge r4,r2
    { const bool k = c.t; c.r[3] += 82; if (k) { goto L_06018318; } }  // 06018312 bt/s 0x06018318 ; add #82,r3
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06018316 mov.w @r3,r4
L_06018318:
    c.r[1] = ld32(0x06018394u);  // 06018318 mov.l 0x06018394,r1
    c.r[6] = c.r[4];  // 0601831A mov r4,r6
    { const uint32_t x = c.r[1]; c.pr = 0x06018320u; c.r[5] = c.r[4]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06018320u) return; }  // 0601831C jsr @r1 ; mov r4,r5
L_06018320:
    c.r[7] = ld32(0x06018380u);  // 06018320 mov.l 0x06018380,r7
    c.r[1] = ld32(c.r[7]);  // 06018322 mov.l @r7,r1
    c.r[3] = c.r[7];  // 06018324 mov r7,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06018326 mov.b @r1,r1
    c.r[3] += 76;  // 06018328 add #76,r3
    c.r[2] = ld32(c.r[3]);  // 0601832A mov.l @r3,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0601832C extu.b r1,r1
    c.r[2] += c.r[1];  // 0601832E add r1,r2
    c.t = (int32_t)c.r[2] >= 0;  // 06018330 cmp/pz r2
    { const bool k = !c.t; st32(c.r[3], c.r[2]); if (k) { goto L_06018362; } }  // 06018332 bf/s 0x06018362 ; mov.l r2,@r3
    c.r[1] = ld32(0x06018384u);  // 06018336 mov.l 0x06018384,r1
    c.r[6] = 0x0u;  // 06018338 mov #0,r6
    c.r[5] = 0x0u;  // 0601833A mov #0,r5
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601833C mov.b @r1,r0
    c.r[0] |= 0x80u;  // 0601833E or #128,r0
    st8(c.r[1], c.r[0]);  // 06018340 mov.b r0,@r1
    c.r[1] = ld32(0x0601838Cu);  // 06018342 mov.l 0x0601838C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06018348u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06018348u) return; }  // 06018344 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06018388u);  // 06018348 mov.l 0x06018388,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601834A mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0601834C extu.b r1,r0
    c.t = c.r[0] == 0x2u;  // 0601834E cmp/eq #2,r0
    if (c.t) { goto L_0601835C; }  // 06018350 bt 0x0601835C
L_06018352:
    c.r[1] = ld32(0x06018394u);  // 06018352 mov.l 0x06018394,r1
    c.r[6] = 0x0u;  // 06018354 mov #0,r6
    c.r[5] = 0x0u;  // 06018356 mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0601835Cu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601835Cu) return; }  // 06018358 jsr @r1 ; mov #0,r4
L_0601835C:
    c.r[0] = ld32(0x0601839Cu);  // 0601835C mov.l 0x0601839C,r0
    c.r[15] = c.r[14]; goto L_06018372;  // 0601835E bra 0x06018372 ; mov r14,r15
L_06018362:
    c.r[7] += 78;  // 06018362 add #78,r7
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[7]);  // 06018364 mov.w @r7,r4
    c.r[1] = ld32(0x0601838Cu);  // 06018366 mov.l 0x0601838C,r1
    c.r[6] = c.r[4];  // 06018368 mov r4,r6
    { const uint32_t x = c.r[1]; c.pr = 0x0601836Eu; c.r[5] = c.r[4]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601836Eu) return; }  // 0601836A jsr @r1 ; mov r4,r5
    c.r[0] = 0x0u;  // 0601836E mov #0,r0
    c.r[15] = c.r[14];  // 06018370 mov r14,r15
L_06018372:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06018372 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06018374 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06018376 rts ; mov.l @r15+,r8
}

void f_060183A0(SH2Context& c) {
    ran[167] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060183A0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060183A2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060183A4 sts.l pr,@-r15
    c.r[3] = ld32(0x06018488u);  // 060183A6 mov.l 0x06018488,r3
    c.r[1] = c.r[3];  // 060183A8 mov r3,r1
    c.r[1] += 72;  // 060183AA add #72,r1
    c.r[1] = ld32(c.r[1]);  // 060183AC mov.l @r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060183AE tst r1,r1
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_06018406; } }  // 060183B0 bf/s 0x06018406 ; mov r15,r14
    c.r[1] = ld32(0x0601848Cu);  // 060183B4 mov.l 0x0601848C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060183B6 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060183B8 extu.b r1,r1
    c.r[1] >>= 2;  // 060183BA shlr2 r1
    c.r[1] >>= 2;  // 060183BC shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060183BE shlr r1
    c.r[1] >>= 2;  // 060183C0 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060183C2 tst r1,r1
    { const bool k = !c.t; c.r[2] = c.r[3]; if (k) { goto L_060183F4; } }  // 060183C4 bf/s 0x060183F4 ; mov r3,r2
    c.r[1] = ld32(0x06018490u);  // 060183C8 mov.l 0x06018490,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060183CA mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 060183CC extu.b r1,r0
    c.t = c.r[0] == 0x2u;  // 060183CE cmp/eq #2,r0
    { const bool k = c.t; c.r[2] += 76; if (k) { goto L_060183F6; } }  // 060183D0 bt/s 0x060183F6 ; add #76,r2
    c.r[1] = c.r[3];  // 060183D4 mov r3,r1
    c.r[1] += 76;  // 060183D6 add #76,r1
    c.r[8] = (uint32_t)(int16_t)ld16(0x06018480u);  // 060183D8 mov.w 0x06018480,r8
    st32(c.r[1], c.r[8]);  // 060183DA mov.l r8,@r1
    c.r[3] += 80;  // 060183DC add #80,r3
    st32(c.r[3], c.r[8]);  // 060183DE mov.l r8,@r3
    c.r[1] = ld32(0x06018494u);  // 060183E0 mov.l 0x06018494,r1
    c.r[6] = c.r[8];  // 060183E2 mov r8,r6
    c.r[5] = c.r[8];  // 060183E4 mov r8,r5
    { const uint32_t x = c.r[1]; c.pr = 0x060183EAu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060183EAu) return; }  // 060183E6 jsr @r1 ; mov r8,r4
    c.r[1] = ld32(0x06018498u);  // 060183EA mov.l 0x06018498,r1
    c.r[6] = c.r[8];  // 060183EC mov r8,r6
    c.r[5] = c.r[8];  // 060183EE mov r8,r5
    c.r[4] = c.r[8]; goto L_06018470;  // 060183F0 bra 0x06018470 ; mov r8,r4
L_060183F4:
    c.r[2] += 76;  // 060183F4 add #76,r2
L_060183F6:
    c.r[1] = 0x0u;  // 060183F6 mov #0,r1
    st32(c.r[2], c.r[1]);  // 060183F8 mov.l r1,@r2
    c.r[3] += 80;  // 060183FA add #80,r3
    c.r[1] = ld32(0x0601849Cu);  // 060183FC mov.l 0x0601849C,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060183FE mov.w @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06018482u);  // 06018400 mov.w 0x06018482,r0
    st32(c.r[3], c.r[1]); goto L_06018476;  // 06018402 bra 0x06018476 ; mov.l r1,@r3
L_06018406:
    c.r[1] = c.r[3];  // 06018406 mov r3,r1
    c.r[1] += 76;  // 06018408 add #76,r1
    c.r[7] = c.r[3];  // 0601840A mov r3,r7
    c.r[1] = ld32(c.r[1]);  // 0601840C mov.l @r1,r1
    c.r[7] += 80;  // 0601840E add #80,r7
    c.r[2] = ld32(c.r[7]);  // 06018410 mov.l @r7,r2
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 06018412 cmp/gt r2,r1
    if (c.t) { goto L_06018438; }  // 06018414 bt 0x06018438
    c.r[1] = ld32(c.r[3]);  // 06018416 mov.l @r3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06018418 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601841A extu.b r1,r1
    c.r[2] -= c.r[1];  // 0601841C sub r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06018484u);  // 0601841E mov.w 0x06018484,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 06018420 cmp/gt r1,r2
    { const bool k = c.t; st32(c.r[7], c.r[2]); if (k) { goto L_0601842C; } }  // 06018422 bt/s 0x0601842C ; mov.l r2,@r7
    c.r[4] = (uint32_t)(int16_t)ld16(0x06018480u);  // 06018426 mov.w 0x06018480,r4
    goto L_06018430;  // 06018428 bra 0x06018430 ; nop
L_0601842C:
    c.r[3] += 82;  // 0601842C add #82,r3
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0601842E mov.w @r3,r4
L_06018430:
    c.r[1] = ld32(0x06018498u);  // 06018430 mov.l 0x06018498,r1
    c.r[6] = c.r[4];  // 06018432 mov r4,r6
    { const uint32_t x = c.r[1]; c.pr = 0x06018438u; c.r[5] = c.r[4]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06018438u) return; }  // 06018434 jsr @r1 ; mov r4,r5
L_06018438:
    c.r[7] = ld32(0x06018488u);  // 06018438 mov.l 0x06018488,r7
    c.r[1] = ld32(c.r[7]);  // 0601843A mov.l @r7,r1
    c.r[3] = c.r[7];  // 0601843C mov r7,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601843E mov.b @r1,r1
    c.r[3] += 76;  // 06018440 add #76,r3
    c.r[2] = ld32(c.r[3]);  // 06018442 mov.l @r3,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06018444 extu.b r1,r1
    c.r[2] -= c.r[1];  // 06018446 sub r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06018484u);  // 06018448 mov.w 0x06018484,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0601844A cmp/gt r1,r2
    { const bool k = !c.t; st32(c.r[3], c.r[2]); if (k) { goto L_06018460; } }  // 0601844C bf/s 0x06018460 ; mov.l r2,@r3
    c.r[7] += 78;  // 06018450 add #78,r7
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[7]);  // 06018452 mov.w @r7,r4
    c.r[1] = ld32(0x06018494u);  // 06018454 mov.l 0x06018494,r1
    c.r[6] = c.r[4];  // 06018456 mov r4,r6
    { const uint32_t x = c.r[1]; c.pr = 0x0601845Cu; c.r[5] = c.r[4]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601845Cu) return; }  // 06018458 jsr @r1 ; mov r4,r5
    c.r[0] = 0x0u; goto L_06018476;  // 0601845C bra 0x06018476 ; mov #0,r0
L_06018460:
    c.r[1] = ld32(0x0601848Cu);  // 06018460 mov.l 0x0601848C,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06018462 mov.b @r1,r0
    c.r[4] = (uint32_t)(int16_t)ld16(0x06018480u);  // 06018464 mov.w 0x06018480,r4
    c.r[6] = c.r[4];  // 06018466 mov r4,r6
    c.r[5] = c.r[4];  // 06018468 mov r4,r5
    c.r[0] &= 0x7Fu;  // 0601846A and #127,r0
    st8(c.r[1], c.r[0]);  // 0601846C mov.b r0,@r1
    c.r[1] = ld32(0x06018494u);  // 0601846E mov.l 0x06018494,r1
L_06018470:
    { const uint32_t x = c.r[1]; c.pr = 0x06018474u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06018474u) return; }  // 06018470 jsr @r1 ; nop
    c.r[0] = ld32(0x060184A0u);  // 06018474 mov.l 0x060184A0,r0
L_06018476:
    c.r[15] = c.r[14];  // 06018476 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06018478 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601847A mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601847C rts ; mov.l @r15+,r8
}

void f_060184A4(SH2Context& c) {
    ran[168] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060184A4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060184A6 sts.l pr,@-r15
    c.r[1] = ld32(0x060184B8u);  // 060184A8 mov.l 0x060184B8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060184AEu; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060184AEu) return; }  // 060184AA jsr @r1 ; mov r15,r14
    c.r[15] = c.r[14];  // 060184AE mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060184B0 lds.l @r15+,pr
    c.r[0] = ld32(0x060184BCu);  // 060184B2 mov.l 0x060184BC,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060184B4 rts ; mov.l @r15+,r14
}

void f_060184C0(SH2Context& c) {
    ran[169] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060184C0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060184C2 sts.l pr,@-r15
    c.r[1] = ld32(0x060184D4u);  // 060184C4 mov.l 0x060184D4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060184CAu; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060184CAu) return; }  // 060184C6 jsr @r1 ; mov r15,r14
    c.r[15] = c.r[14];  // 060184CA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060184CC lds.l @r15+,pr
    c.r[0] = ld32(0x060184D8u);  // 060184CE mov.l 0x060184D8,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060184D0 rts ; mov.l @r15+,r14
}

void f_060184DC(SH2Context& c) {
    ran[170] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060184DC mov.l r14,@-r15
    c.r[1] = ld32(0x06018508u);  // 060184DE mov.l 0x06018508,r1
    c.r[1] = ld32(c.r[1]);  // 060184E0 mov.l @r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060184E2 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060184E4 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060184E6 tst r1,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_060184F4; } }  // 060184E8 bt/s 0x060184F4 ; mov r15,r14
    c.r[2] = ld32(0x0601850Cu);  // 060184EC mov.l 0x0601850C,r2
    c.r[1] = ld32(0x06018510u);  // 060184EE mov.l 0x06018510,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]); goto L_060184FA;  // 060184F0 bra 0x060184FA ; mov.b @r2,r2
L_060184F4:
    c.r[2] = ld32(0x06018510u);  // 060184F4 mov.l 0x06018510,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060184F6 mov.b @r2,r2
    c.r[1] = ld32(0x0601850Cu);  // 060184F8 mov.l 0x0601850C,r1
L_060184FA:
    st8(c.r[1], c.r[2]);  // 060184FA mov.b r2,@r1
    c.r[15] = c.r[14];  // 060184FC mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x06018504u);  // 060184FE mov.w 0x06018504,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06018500 rts ; mov.l @r15+,r14
}

void f_06018514(SH2Context& c) {
    ran[171] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06018514 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06018516 sts.l pr,@-r15
    c.r[1] = ld32(0x06018534u);  // 06018518 mov.l 0x06018534,r1
    c.r[1] = ld32(c.r[1]);  // 0601851A mov.l @r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601851C mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0601851E extu.b r1,r0
    c.r[0] <<= 2;  // 06018520 shll2 r0
    c.r[1] = ld32(0x06018538u);  // 06018522 mov.l 0x06018538,r1
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 06018524 mov.l @(r0,r1),r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601852Au; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601852Au) return; }  // 06018526 jsr @r0 ; mov r15,r14
    c.r[15] = c.r[14];  // 0601852A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601852C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601852E mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[0] & 0xFFFFu; c.pc = x; return; }  // 06018530 rts ; extu.w r0,r0
}

void f_0601853C(SH2Context& c) {
    ran[172] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601853C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0601853E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06018540 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06018542 sts.l pr,@-r15
    c.r[1] = ld32(0x060185C0u);  // 06018544 mov.l 0x060185C0,r1
    c.r[2] = ld32(c.r[1]);  // 06018546 mov.l @r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06018548 mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601854A extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601854C tst r1,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06018578; } }  // 0601854E bt/s 0x06018578 ; mov r15,r14
    c.r[2] += 1;  // 06018552 add #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06018554 mov.b @r2,r1
    c.r[9] = ld32(0x060185C4u);  // 06018556 mov.l 0x060185C4,r9
    c.r[8] = c.r[1] & 0xFFu;  // 06018558 extu.b r1,r8
    c.r[5] = c.r[8] & 0xFFu;  // 0601855A extu.b r8,r5
L_0601855C:
    c.r[6] = 0x0u;  // 0601855C mov #0,r6
    { const uint32_t x = c.r[9]; c.pr = 0x06018562u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06018562u) return; }  // 0601855E jsr @r9 ; mov #1,r4
    c.r[1] = ld32(0x060185C0u);  // 06018562 mov.l 0x060185C0,r1
    c.r[1] = ld32(c.r[1]);  // 06018564 mov.l @r1,r1
    c.r[1] += 1;  // 06018566 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06018568 mov.b @r1,r1
    c.r[8] += 1;  // 0601856A add #1,r8
    c.r[1] = c.r[1] & 0xFFu;  // 0601856C extu.b r1,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 0601856E cmp/gt r1,r8
    { const bool k = !c.t; c.r[5] = c.r[8] & 0xFFu; if (k) { SH2_POLL(c); goto L_0601855C; } }  // 06018570 bf/s 0x0601855C ; extu.b r8,r5
    goto L_060185A6;  // 06018574 bra 0x060185A6 ; nop
L_06018578:
    c.r[1] = c.r[2];  // 06018578 mov r2,r1
    c.r[1] += 1;  // 0601857A add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601857C mov.b @r1,r1
    c.r[2] += 2;  // 0601857E add #2,r2
    c.r[8] = c.r[1] & 0xFFu;  // 06018580 extu.b r1,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06018582 mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06018584 extu.b r1,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 06018586 cmp/gt r1,r8
    { const bool k = c.t; c.r[5] = c.r[8] & 0xFFu; if (k) { goto L_060185A6; } }  // 06018588 bt/s 0x060185A6 ; extu.b r8,r5
    c.r[9] = ld32(0x060185C4u);  // 0601858C mov.l 0x060185C4,r9
L_0601858E:
    c.r[6] = 0x0u;  // 0601858E mov #0,r6
    { const uint32_t x = c.r[9]; c.pr = 0x06018594u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06018594u) return; }  // 06018590 jsr @r9 ; mov #0,r4
    c.r[1] = ld32(0x060185C0u);  // 06018594 mov.l 0x060185C0,r1
    c.r[1] = ld32(c.r[1]);  // 06018596 mov.l @r1,r1
    c.r[1] += 2;  // 06018598 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601859A mov.b @r1,r1
    c.r[8] += 1;  // 0601859C add #1,r8
    c.r[1] = c.r[1] & 0xFFu;  // 0601859E extu.b r1,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 060185A0 cmp/gt r1,r8
    { const bool k = !c.t; c.r[5] = c.r[8] & 0xFFu; if (k) { SH2_POLL(c); goto L_0601858E; } }  // 060185A2 bf/s 0x0601858E ; extu.b r8,r5
L_060185A6:
    c.r[6] = ld32(0x060185C8u);  // 060185A6 mov.l 0x060185C8,r6
    c.r[1] = ld32(0x060185C4u);  // 060185A8 mov.l 0x060185C4,r1
    c.r[5] = 0x1u;  // 060185AA mov #1,r5
    { const uint32_t x = c.r[1]; c.pr = 0x060185B0u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060185B0u) return; }  // 060185AC jsr @r1 ; mov #0,r4
    c.r[15] = c.r[14];  // 060185B0 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060185B2 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060185B4 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060185B6 mov.l @r15+,r9
    c.r[0] = ld32(0x060185CCu);  // 060185B8 mov.l 0x060185CC,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060185BA rts ; mov.l @r15+,r8
}

void f_060185D0(SH2Context& c) {
    ran[173] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060185D0 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 060185D2 mov r15,r14
    c.r[1] = ld32(0x060185E8u);  // 060185D4 mov.l 0x060185E8,r1
    c.r[1] = ld32(c.r[1]);  // 060185D6 mov.l @r1,r1
    c.r[2] = ld32(0x060185ECu);  // 060185D8 mov.l 0x060185EC,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060185DA mov.b @r1,r1
    st8(c.r[2], c.r[1]);  // 060185DC mov.b r1,@r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x060185E4u);  // 060185DE mov.w 0x060185E4,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060185E0 rts ; mov.l @r15+,r14
}

void f_060185F0(SH2Context& c) {
    ran[174] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060185F0 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 060185F2 mov r15,r14
    c.r[1] = ld32(0x06018608u);  // 060185F4 mov.l 0x06018608,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060185F6 mov.b @r1,r1
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060185F8 mov.l @r15+,r14
    c.r[1] = c.r[1] & 0xFFu;  // 060185FA extu.b r1,r1
    c.r[0] = c.r[1];  // 060185FC mov r1,r0
    c.r[0] += c.r[0];  // 060185FE add r0,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06018606u);  // 06018600 mov.w 0x06018606,r1
    { const uint32_t x = c.pr; c.r[0] |= c.r[1]; c.pc = x; return; }  // 06018602 rts ; or r1,r0
}

void f_0601860C(SH2Context& c) {
    ran[175] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601860C mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0601860E mov r15,r14
    c.r[1] = ld32(0x06018620u);  // 06018610 mov.l 0x06018620,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06018612 mov.b @r1,r0
    c.r[0] |= 0x80u;  // 06018614 or #128,r0
    st8(c.r[1], c.r[0]);  // 06018616 mov.b r0,@r1
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06018618 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = 0x0u; c.pc = x; return; }  // 0601861A rts ; mov #0,r0
}

void f_06018648(SH2Context& c) {
    ran[176] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06018648 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0601864A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0601864C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0601864E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06018650 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06018652 sts.l pr,@-r15
    c.r[7] = ld32(0x060186CCu);  // 06018654 mov.l 0x060186CC,r7
    c.r[1] = c.r[7];  // 06018656 mov r7,r1
    c.r[1] += 72;  // 06018658 add #72,r1
    c.r[1] = ld32(c.r[1]);  // 0601865A mov.l @r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601865C tst r1,r1
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_060186E0; } }  // 0601865E bf/s 0x060186E0 ; mov r15,r14
    c.r[1] = ld32(c.r[7]);  // 06018662 mov.l @r7,r1
    c.r[1] += 1;  // 06018664 add #1,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06018666 mov.b @r1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x060186C6u);  // 06018668 mov.w 0x060186C6,r1
    c.r[1] &= c.r[0];  // 0601866A and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601866C tst r1,r1
    if (c.t) { goto L_06018696; }  // 0601866E bt 0x06018696
    c.r[0] &= 0xFu;  // 06018670 and #15,r0
    c.r[0] += c.r[0];  // 06018672 add r0,r0
    c.r[3] = ld32(0x060186D0u);  // 06018674 mov.l 0x060186D0,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 06018676 mov.w @(r0,r3),r2
    c.r[1] = 0x40u;  // 06018678 mov #64,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0601867A cmp/gt r1,r2
    { const bool k = !c.t; c.r[1] = 0x40u; if (k) { goto L_06018682; } }  // 0601867C bf/s 0x06018682 ; mov #64,r1
    st16(c.r[0] + c.r[3], c.r[1]);  // 06018680 mov.w r1,@(r0,r3)
L_06018682:
    c.r[1] = ld32(c.r[7]);  // 06018682 mov.l @r7,r1
    c.r[1] += 1;  // 06018684 add #1,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06018686 mov.b @r1,r0
    c.r[0] &= 0xFu;  // 06018688 and #15,r0
    c.r[0] += c.r[0];  // 0601868A add r0,r0
    c.r[0] += c.r[3];  // 0601868C add r3,r0
    c.r[0] += 1;  // 0601868E add #1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06018690 mov.b @r0,r1
    c.r[0] = c.r[1] & 0xFFu; goto L_06018698;  // 06018692 bra 0x06018698 ; extu.b r1,r0
L_06018696:
    c.r[0] = c.r[0] & 0xFFu;  // 06018696 extu.b r0,r0
L_06018698:
    c.t = c.r[0] == 0x3Cu;  // 06018698 cmp/eq #60,r0
    if (c.t) { goto L_060186A8; }  // 0601869A bt 0x060186A8
    c.r[1] = ld32(0x060186D4u);  // 0601869C mov.l 0x060186D4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060186A2u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060186A2u) return; }  // 0601869E jsr @r1 ; mov r0,r4
    c.r[0] = ld32(0x060186D8u);  // 060186A2 mov.l 0x060186D8,r0
    c.r[15] = c.r[14]; goto L_0601880A;  // 060186A4 bra 0x0601880A ; mov r14,r15
L_060186A8:
    c.r[2] = ld32(0x060186DCu);  // 060186A8 mov.l 0x060186DC,r2
    c.r[3] = c.r[2];  // 060186AA mov r2,r3
    c.r[3] += 14;  // 060186AC add #14,r3
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[3]);  // 060186AE mov.w @r3,r0
    c.r[0] &= 0x20u;  // 060186B0 and #32,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060186B2 tst r0,r0
    { const bool k = c.t; c.r[1] = 0x40u; if (k) { goto L_060186C0; } }  // 060186B4 bt/s 0x060186C0 ; mov #64,r1
    st16(c.r[3], c.r[1]);  // 060186B8 mov.w r1,@r3
    c.r[2] += 6;  // 060186BA add #6,r2
    c.r[1] = 0x0u;  // 060186BC mov #0,r1
    st16(c.r[2], c.r[1]);  // 060186BE mov.w r1,@r2
L_060186C0:
    c.r[0] = (uint32_t)(int16_t)ld16(0x060186C8u);  // 060186C0 mov.w 0x060186C8,r0
    c.r[15] = c.r[14]; goto L_0601880A;  // 060186C2 bra 0x0601880A ; mov r14,r15
L_060186E0:
    c.r[1] = ld32(0x06018820u);  // 060186E0 mov.l 0x06018820,r1
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060186E2 mov.w @r1,r0
    c.r[0] &= 0x9u;  // 060186E4 and #9,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060186E6 tst r0,r0
    { const bool k = !c.t; c.r[0] = 0x0u; if (k) { goto L_060186F0; } }  // 060186E8 bf/s 0x060186F0 ; mov #0,r0
    goto L_06018808;  // 060186EC bra 0x06018808 ; nop
L_060186F0:
    c.r[0] = ld32(0x06018824u);  // 060186F0 mov.l 0x06018824,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060186F6u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060186F6u) return; }  // 060186F2 jsr @r0 ; mov #0,r4
    c.r[0] = ld32(0x06018828u);  // 060186F6 mov.l 0x06018828,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060186FCu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060186FCu) return; }  // 060186F8 jsr @r0 ; nop
    c.r[2] = ld32(0x0601882Cu);  // 060186FC mov.l 0x0601882C,r2
    c.r[1] = 0x0u;  // 060186FE mov #0,r1
    st16(c.r[2], c.r[1]);  // 06018700 mov.w r1,@r2
    c.r[0] = ld32(0x06018830u);  // 06018702 mov.l 0x06018830,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06018708u; c.r[4] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06018708u) return; }  // 06018704 jsr @r0 ; mov #2,r4
    c.r[1] = ld32(0x06018834u);  // 06018708 mov.l 0x06018834,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601870A mov.b @r1,r0
    c.r[9] = ld32(0x06018838u);  // 0601870C mov.l 0x06018838,r9
    c.r[0] &= 0x7Fu;  // 0601870E and #127,r0
    st8(c.r[1], c.r[0]);  // 06018710 mov.b r0,@r1
    c.r[1] = ld32(0x0601883Cu);  // 06018712 mov.l 0x0601883C,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06018714 mov.b @r1,r0
    c.r[4] = ld32(0x06018840u);  // 06018716 mov.l 0x06018840,r4
    c.r[0] &= 0x7Fu;  // 06018718 and #127,r0
    st8(c.r[1], c.r[0]);  // 0601871A mov.b r0,@r1
    c.r[1] = ld32(0x06018844u);  // 0601871C mov.l 0x06018844,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601871E mov.b @r1,r0
    c.r[10] = ld32(0x06018848u);  // 06018720 mov.l 0x06018848,r10
    c.r[0] &= 0x7Fu;  // 06018722 and #127,r0
    st8(c.r[1], c.r[0]);  // 06018724 mov.b r0,@r1
    c.r[1] = ld32(0x0601884Cu);  // 06018726 mov.l 0x0601884C,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06018728 mov.b @r1,r0
    c.r[5] = c.r[9];  // 0601872A mov r9,r5
    c.r[0] &= 0x7Fu;  // 0601872C and #127,r0
    { const uint32_t x = c.r[10]; c.pr = 0x06018732u; st8(c.r[1], c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06018732u) return; }  // 0601872E jsr @r10 ; mov.b r0,@r1
    c.r[8] = ld32(0x06018850u);  // 06018732 mov.l 0x06018850,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06018738u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06018738u) return; }  // 06018734 jsr @r8 ; nop
    c.r[4] = ld32(0x06018854u);  // 06018738 mov.l 0x06018854,r4
    { const uint32_t x = c.r[10]; c.pr = 0x0601873Eu; c.r[5] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601873Eu) return; }  // 0601873A jsr @r10 ; mov r9,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06018742u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06018742u) return; }  // 0601873E jsr @r8 ; nop
    c.r[4] = ld32(0x06018858u);  // 06018742 mov.l 0x06018858,r4
    { const uint32_t x = c.r[10]; c.pr = 0x06018748u; c.r[5] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06018748u) return; }  // 06018744 jsr @r10 ; mov r9,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0601874Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601874Cu) return; }  // 06018748 jsr @r8 ; nop
    c.r[4] = ld32(0x0601885Cu);  // 0601874C mov.l 0x0601885C,r4
    { const uint32_t x = c.r[10]; c.pr = 0x06018752u; c.r[5] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06018752u) return; }  // 0601874E jsr @r10 ; mov r9,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06018756u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06018756u) return; }  // 06018752 jsr @r8 ; nop
    c.r[8] = ld32(0x06018860u);  // 06018756 mov.l 0x06018860,r8
L_06018758:
    c.r[7] = (uint32_t)(int16_t)ld16(0x06018818u);  // 06018758 mov.w 0x06018818,r7
    c.r[6] = ld32(0x06018840u);  // 0601875A mov.l 0x06018840,r6
    c.r[4] = ld32(0x06018864u);  // 0601875C mov.l 0x06018864,r4
    { const uint32_t x = c.r[8]; c.pr = 0x06018762u; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06018762u) return; }  // 0601875E jsr @r8 ; mov #0,r5
    c.t = (int32_t)c.r[0] > 0;  // 06018762 cmp/pl r0
    if (!c.t) { SH2_POLL(c); goto L_06018758; }  // 06018764 bf 0x06018758
    c.r[1] = ld32(0x06018850u);  // 06018766 mov.l 0x06018850,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601876Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601876Cu) return; }  // 06018768 jsr @r1 ; nop
    c.r[8] = ld32(0x06018860u);  // 0601876C mov.l 0x06018860,r8
    c.r[7] = 0xEu;  // 0601876E mov #14,r7
L_06018770:
    c.r[6] = ld32(0x06018868u);  // 06018770 mov.l 0x06018868,r6
    c.r[4] = ld32(0x0601886Cu);  // 06018772 mov.l 0x0601886C,r4
    { const uint32_t x = c.r[8]; c.pr = 0x06018778u; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06018778u) return; }  // 06018774 jsr @r8 ; mov #0,r5
    c.t = (int32_t)c.r[0] > 0;  // 06018778 cmp/pl r0
    { const bool k = !c.t; c.r[7] = 0xEu; if (k) { SH2_POLL(c); goto L_06018770; } }  // 0601877A bf/s 0x06018770 ; mov #14,r7
    c.r[1] = ld32(0x06018850u);  // 0601877E mov.l 0x06018850,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06018784u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06018784u) return; }  // 06018780 jsr @r1 ; nop
    c.r[8] = ld32(0x06018860u);  // 06018784 mov.l 0x06018860,r8
    c.r[7] = 0x1u;  // 06018786 mov #1,r7
L_06018788:
    c.r[6] = ld32(0x06018870u);  // 06018788 mov.l 0x06018870,r6
    c.r[4] = ld32(0x06018874u);  // 0601878A mov.l 0x06018874,r4
    { const uint32_t x = c.r[8]; c.pr = 0x06018790u; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06018790u) return; }  // 0601878C jsr @r8 ; mov #0,r5
    c.t = (int32_t)c.r[0] > 0;  // 06018790 cmp/pl r0
    { const bool k = !c.t; c.r[7] = 0x1u; if (k) { SH2_POLL(c); goto L_06018788; } }  // 06018792 bf/s 0x06018788 ; mov #1,r7
    c.r[1] = ld32(0x06018850u);  // 06018796 mov.l 0x06018850,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601879Cu; c.r[9] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601879Cu) return; }  // 06018798 jsr @r1 ; mov #0,r9
    c.r[1] = ld32(0x06018834u);  // 0601879C mov.l 0x06018834,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601879E mov.b @r1,r0
    c.r[0] |= 0x80u;  // 060187A0 or #128,r0
    st8(c.r[1], c.r[0]);  // 060187A2 mov.b r0,@r1
    c.r[1] = ld32(0x0601883Cu);  // 060187A4 mov.l 0x0601883C,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060187A6 mov.b @r1,r0
    c.r[0] |= 0x80u;  // 060187A8 or #128,r0
    st8(c.r[1], c.r[0]);  // 060187AA mov.b r0,@r1
    c.r[1] = ld32(0x06018844u);  // 060187AC mov.l 0x06018844,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060187AE mov.b @r1,r0
    c.r[2] = ld32(0x0601882Cu);  // 060187B0 mov.l 0x0601882C,r2
    c.r[0] |= 0x80u;  // 060187B2 or #128,r0
    st8(c.r[1], c.r[0]);  // 060187B4 mov.b r0,@r1
    c.r[1] = ld32(0x0601884Cu);  // 060187B6 mov.l 0x0601884C,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060187B8 mov.b @r1,r0
    c.r[4] = 0x0u;  // 060187BA mov #0,r4
    c.r[0] |= 0x80u;  // 060187BC or #128,r0
    st8(c.r[1], c.r[0]);  // 060187BE mov.b r0,@r1
    c.r[1] = 0x0u;  // 060187C0 mov #0,r1
    c.r[0] = ld32(0x06018878u);  // 060187C2 mov.l 0x06018878,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060187C8u; st16(c.r[2], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060187C8u) return; }  // 060187C4 jsr @r0 ; mov.w r1,@r2
    c.r[11] = ld32(0x0601887Cu);  // 060187C8 mov.l 0x0601887C,r11
    c.r[10] = ld32(0x06018880u);  // 060187CA mov.l 0x06018880,r10
    c.r[8] = c.r[9] & 0xFFu;  // 060187CC extu.b r9,r8
L_060187CE:
    c.r[5] = 0x0u;  // 060187CE mov #0,r5
    { const uint32_t x = c.r[11]; c.pr = 0x060187D4u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060187D4u) return; }  // 060187D0 jsr @r11 ; mov r8,r4
    c.r[6] = 0x0u;  // 060187D4 mov #0,r6
    c.r[5] = 0x7u;  // 060187D6 mov #7,r5
    { const uint32_t x = c.r[10]; c.pr = 0x060187DCu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060187DCu) return; }  // 060187D8 jsr @r10 ; mov r8,r4
    c.r[9] += 1;  // 060187DC add #1,r9
    c.r[1] = 0x4u;  // 060187DE mov #4,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 060187E0 cmp/gt r1,r9
    { const bool k = !c.t; c.r[8] = c.r[9] & 0xFFu; if (k) { SH2_POLL(c); goto L_060187CE; } }  // 060187E2 bf/s 0x060187CE ; extu.b r9,r8
    c.r[1] = ld32(0x06018884u);  // 060187E6 mov.l 0x06018884,r1
    c.r[3] = c.r[1];  // 060187E8 mov r1,r3
    c.r[3] += 1;  // 060187EA add #1,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060187EC mov.b @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601881Au);  // 060187EE mov.w 0x0601881A,r0
    st8(c.r[3], c.r[2]);  // 060187F0 mov.b r2,@r3
    c.r[2] = 0x3Cu;  // 060187F2 mov #60,r2
    st8(c.r[1], c.r[2]);  // 060187F4 mov.b r2,@r1
    c.r[3] = c.r[1];  // 060187F6 mov r1,r3
    c.r[3] += 4;  // 060187F8 add #4,r3
    c.r[2] = 0x0u;  // 060187FA mov #0,r2
    st8(c.r[3], c.r[2]);  // 060187FC mov.b r2,@r3
    c.r[1] += 14;  // 060187FE add #14,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0601881Cu);  // 06018800 mov.w 0x0601881C,r2
    st16(c.r[1], c.r[2]);  // 06018802 mov.w r2,@r1
    c.r[15] = c.r[14]; goto L_0601880A;  // 06018804 bra 0x0601880A ; mov r14,r15
L_06018808:
    c.r[15] = c.r[14];  // 06018808 mov r14,r15
L_0601880A:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601880A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601880C mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0601880E mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06018810 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06018812 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06018814 rts ; mov.l @r15+,r8
}

void f_06018888(SH2Context& c) {
    ran[177] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06018888 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601888A sts.l pr,@-r15
    c.r[2] = ld32(0x060188ECu);  // 0601888C mov.l 0x060188EC,r2
    c.r[3] = c.r[2];  // 0601888E mov r2,r3
    c.r[3] += 14;  // 06018890 add #14,r3
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06018892 mov.w @r3,r0
    c.r[0] &= 0x8u;  // 06018894 and #8,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06018896 tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_060188A2; } }  // 06018898 bt/s 0x060188A2 ; mov r15,r14
    c.r[0] = ld32(0x060188F0u);  // 0601889C mov.l 0x060188F0,r0
    c.r[15] = c.r[14]; goto L_060188E4;  // 0601889E bra 0x060188E4 ; mov r14,r15
L_060188A2:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[3]);  // 060188A2 mov.w @r3,r0
    c.r[0] &= 0x20u;  // 060188A4 and #32,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060188A6 tst r0,r0
    { const bool k = c.t; c.r[1] = 0x40u; if (k) { goto L_060188B8; } }  // 060188A8 bt/s 0x060188B8 ; mov #64,r1
    st16(c.r[3], c.r[1]);  // 060188AC mov.w r1,@r3
    c.r[2] += 6;  // 060188AE add #6,r2
    c.r[1] = 0x0u;  // 060188B0 mov #0,r1
    st16(c.r[2], c.r[1]);  // 060188B2 mov.w r1,@r2
    c.r[0] = 0x0u; goto L_060188E2;  // 060188B4 bra 0x060188E2 ; mov #0,r0
L_060188B8:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[3]);  // 060188B8 mov.w @r3,r0
    c.r[0] &= 0x1u;  // 060188BA and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060188BC tst r0,r0
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_060188E2; } }  // 060188BE bt/s 0x060188E2 ; mov #0,r0
    c.r[1] = ld32(0x060188F4u);  // 060188C2 mov.l 0x060188F4,r1
    c.r[1] = ld32(c.r[1]);  // 060188C4 mov.l @r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060188C6 tst r1,r1
    if (!c.t) { goto L_060188D6; }  // 060188C8 bf 0x060188D6
    c.r[1] = ld32(0x060188F8u);  // 060188CA mov.l 0x060188F8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060188D0u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060188D0u) return; }  // 060188CC jsr @r1 ; mov #0,r4
    c.r[0] = ld32(0x060188FCu);  // 060188D0 mov.l 0x060188FC,r0
    c.r[15] = c.r[14]; goto L_060188E4;  // 060188D2 bra 0x060188E4 ; mov r14,r15
L_060188D6:
    c.r[1] = ld32(0x060188F8u);  // 060188D6 mov.l 0x060188F8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060188DCu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060188DCu) return; }  // 060188D8 jsr @r1 ; mov #1,r4
    c.r[0] = ld32(0x060188F0u);  // 060188DC mov.l 0x060188F0,r0
    c.r[15] = c.r[14]; goto L_060188E4;  // 060188DE bra 0x060188E4 ; mov r14,r15
L_060188E2:
    c.r[15] = c.r[14];  // 060188E2 mov r14,r15
L_060188E4:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060188E4 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060188E6 rts ; mov.l @r15+,r14
}

void f_06018900(SH2Context& c) {
    ran[178] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06018900 mov.l r14,@-r15
    c.r[3] = ld32(0x0601896Cu);  // 06018902 mov.l 0x0601896C,r3
    c.r[7] = c.r[3];  // 06018904 mov r3,r7
    c.r[7] += 14;  // 06018906 add #14,r7
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[7]);  // 06018908 mov.w @r7,r1
    c.r[0] = c.r[1] & 0xFFFFu;  // 0601890A extu.w r1,r0
    c.t = c.r[0] == 0x20u;  // 0601890C cmp/eq #32,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06018962; } }  // 0601890E bt/s 0x06018962 ; mov r15,r14
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[7]);  // 06018912 mov.w @r7,r1
    c.r[0] = c.r[1] & 0xFFFFu;  // 06018914 extu.w r1,r0
    c.t = c.r[0] == 0x1u;  // 06018916 cmp/eq #1,r0
    { const bool k = !c.t; c.r[1] = c.r[3]; if (k) { goto L_0601893A; } }  // 06018918 bf/s 0x0601893A ; mov r3,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0601891C mov.b @r3,r2
    c.r[1] += 2;  // 0601891E add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06018920 mov.b @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 06018922 extu.b r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06018924 extu.b r1,r1
    c.t = c.r[2] == c.r[1];  // 06018926 cmp/eq r1,r2
    { const bool k = !c.t; c.r[1] = c.r[3]; if (k) { goto L_0601893A; } }  // 06018928 bf/s 0x0601893A ; mov r3,r1
    c.r[1] += 4;  // 0601892C add #4,r1
    c.r[2] = 0x0u;  // 0601892E mov #0,r2
    st8(c.r[1], c.r[2]);  // 06018930 mov.b r2,@r1
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601896Au);  // 06018932 mov.w 0x0601896A,r1
    st16(c.r[7], c.r[1]);  // 06018934 mov.w r1,@r7
    c.r[0] = 0x0u; goto L_06018964;  // 06018936 bra 0x06018964 ; mov #0,r0
L_0601893A:
    c.r[2] = ld32(0x0601896Cu);  // 0601893A mov.l 0x0601896C,r2
    c.r[1] = c.r[2];  // 0601893C mov r2,r1
    c.r[1] += 14;  // 0601893E add #14,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06018940 mov.w @r1,r1
    c.r[0] = c.r[1] & 0xFFFFu;  // 06018942 extu.w r1,r0
    c.t = c.r[0] == 0x8u;  // 06018944 cmp/eq #8,r0
    { const bool k = !c.t; c.r[0] = 0x0u; if (k) { goto L_06018964; } }  // 06018946 bf/s 0x06018964 ; mov #0,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601894A mov.b @r2,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0601894C extu.b r1,r0
    c.t = c.r[0] == 0x3Cu;  // 0601894E cmp/eq #60,r0
    { const bool k = !c.t; c.r[2] += 12; if (k) { goto L_06018958; } }  // 06018950 bf/s 0x06018958 ; add #12,r2
    c.r[1] = 0x0u; goto L_0601895A;  // 06018954 bra 0x0601895A ; mov #0,r1
L_06018958:
    c.r[1] = 0x1u;  // 06018958 mov #1,r1
L_0601895A:
    st16(c.r[2], c.r[1]);  // 0601895A mov.w r1,@r2
    c.r[2] = ld32(0x06018970u);  // 0601895C mov.l 0x06018970,r2
    c.r[1] = 0x10u;  // 0601895E mov #16,r1
    st16(c.r[2], c.r[1]);  // 06018960 mov.w r1,@r2
L_06018962:
    c.r[0] = ld32(0x06018974u);  // 06018962 mov.l 0x06018974,r0
L_06018964:
    c.r[15] = c.r[14];  // 06018964 mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06018966 rts ; mov.l @r15+,r14
}

void f_06018978(SH2Context& c) {
    ran[179] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06018978 mov.l r14,@-r15
    c.r[2] = ld32(0x060189ACu);  // 0601897A mov.l 0x060189AC,r2
    c.r[3] = c.r[2];  // 0601897C mov r2,r3
    c.r[3] += 14;  // 0601897E add #14,r3
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06018980 mov.w @r3,r0
    c.r[0] &= 0x9u;  // 06018982 and #9,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06018984 tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06018990; } }  // 06018986 bt/s 0x06018990 ; mov r15,r14
    c.r[0] = ld32(0x060189B0u);  // 0601898A mov.l 0x060189B0,r0
    c.r[15] = c.r[14]; goto L_060189A8;  // 0601898C bra 0x060189A8 ; mov r14,r15
L_06018990:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06018990 mov.w @r3,r0
    c.r[0] &= 0x20u;  // 06018992 and #32,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06018994 tst r0,r0
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_060189A6; } }  // 06018996 bt/s 0x060189A6 ; mov #0,r0
    c.r[1] = 0x40u;  // 0601899A mov #64,r1
    st16(c.r[3], c.r[1]);  // 0601899C mov.w r1,@r3
    c.r[2] += 6;  // 0601899E add #6,r2
    c.r[1] = 0x0u;  // 060189A0 mov #0,r1
    st16(c.r[2], c.r[1]);  // 060189A2 mov.w r1,@r2
    c.r[0] = 0x0u;  // 060189A4 mov #0,r0
L_060189A6:
    c.r[15] = c.r[14];  // 060189A6 mov r14,r15
L_060189A8:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060189A8 rts ; mov.l @r15+,r14
}

void f_060189B4(SH2Context& c) {
    ran[180] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060189B4 mov.l r14,@-r15
    c.r[2] = ld32(0x060189F0u);  // 060189B6 mov.l 0x060189F0,r2
    c.r[1] = ld32(0x060189F4u);  // 060189B8 mov.l 0x060189F4,r1
    c.r[3] = ld32(c.r[1]);  // 060189BA mov.l @r1,r3
    c.r[6] = (uint32_t)(int16_t)ld16(0x060189E8u);  // 060189BC mov.w 0x060189E8,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060189BE mov.b @r2,r1
    c.r[0] = c.r[3];  // 060189C0 mov r3,r0
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 060189C2 mov.b @(r0,r6),r7
    c.r[1] = c.r[1] & 0xFFu;  // 060189C4 extu.b r1,r1
    c.r[2] = c.r[7] & 0xFFu;  // 060189C6 extu.b r7,r2
    c.t = c.r[1] == c.r[2];  // 060189C8 cmp/eq r2,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_060189E0; } }  // 060189CA bt/s 0x060189E0 ; mov r15,r14
    c.r[1] = ld32(0x060189F8u);  // 060189CE mov.l 0x060189F8,r1
    c.r[2] = c.r[7] & 0xFFu;  // 060189D0 extu.b r7,r2
    st16(c.r[1], c.r[2]);  // 060189D2 mov.w r2,@r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 060189D4 mov.b @(r0,r6),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x060189EAu);  // 060189D6 mov.w 0x060189EA,r2
    st8(c.r[0] + c.r[2], c.r[1]);  // 060189D8 mov.b r1,@(r0,r2)
    c.r[0] = (uint32_t)(int16_t)ld16(0x060189ECu);  // 060189DA mov.w 0x060189EC,r0
    c.r[15] = c.r[14]; goto L_060189E4;  // 060189DC bra 0x060189E4 ; mov r14,r15
L_060189E0:
    c.r[0] = (uint32_t)(int16_t)ld16(0x060189EEu);  // 060189E0 mov.w 0x060189EE,r0
    c.r[15] = c.r[14];  // 060189E2 mov r14,r15
L_060189E4:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060189E4 rts ; mov.l @r15+,r14
}

void f_060189FC(SH2Context& c) {
    ran[181] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060189FC mov.l r14,@-r15
    c.r[2] = ld32(0x06018A38u);  // 060189FE mov.l 0x06018A38,r2
    c.r[1] = ld32(0x06018A3Cu);  // 06018A00 mov.l 0x06018A3C,r1
    c.r[3] = ld32(c.r[1]);  // 06018A02 mov.l @r1,r3
    c.r[6] = (uint32_t)(int16_t)ld16(0x06018A30u);  // 06018A04 mov.w 0x06018A30,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06018A06 mov.b @r2,r1
    c.r[0] = c.r[3];  // 06018A08 mov r3,r0
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 06018A0A mov.b @(r0,r6),r7
    c.r[1] = c.r[1] & 0xFFu;  // 06018A0C extu.b r1,r1
    c.r[2] = c.r[7] & 0xFFu;  // 06018A0E extu.b r7,r2
    c.t = c.r[1] == c.r[2];  // 06018A10 cmp/eq r2,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06018A28; } }  // 06018A12 bt/s 0x06018A28 ; mov r15,r14
    c.r[1] = ld32(0x06018A40u);  // 06018A16 mov.l 0x06018A40,r1
    c.r[2] = c.r[7] & 0xFFu;  // 06018A18 extu.b r7,r2
    st16(c.r[1], c.r[2]);  // 06018A1A mov.w r2,@r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 06018A1C mov.b @(r0,r6),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06018A32u);  // 06018A1E mov.w 0x06018A32,r2
    st8(c.r[0] + c.r[2], c.r[1]);  // 06018A20 mov.b r1,@(r0,r2)
    c.r[0] = (uint32_t)(int16_t)ld16(0x06018A34u);  // 06018A22 mov.w 0x06018A34,r0
    c.r[15] = c.r[14]; goto L_06018A2C;  // 06018A24 bra 0x06018A2C ; mov r14,r15
L_06018A28:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06018A36u);  // 06018A28 mov.w 0x06018A36,r0
    c.r[15] = c.r[14];  // 06018A2A mov r14,r15
L_06018A2C:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06018A2C rts ; mov.l @r15+,r14
}

void f_06018A84(SH2Context& c) {
    ran[182] = 1;
L_06018A84:
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06018A84 mov.l r8,@-r15
L_06018A86:
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06018A86 mov.l r9,@-r15
L_06018A88:
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06018A88 mov.l r10,@-r15
L_06018A8A:
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06018A8A mov.l r11,@-r15
L_06018A8C:
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06018A8C mov.l r12,@-r15
L_06018A8E:
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06018A8E mov.l r13,@-r15
L_06018A90:
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06018A90 mov.l r14,@-r15
L_06018A92:
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06018A92 sts.l pr,@-r15
L_06018A94:
    c.r[15] -= 64;  // 06018A94 add #-64,r15
L_06018A96:
    c.r[14] = c.r[15];  // 06018A96 mov r15,r14
L_06018A98:
    c.r[5] = ld32(0x06018BF4u);  // 06018A98 mov.l 0x06018BF4,r5
L_06018A9A:
    c.r[1] = ld32(0x06018BF8u);  // 06018A9A mov.l 0x06018BF8,r1
L_06018A9C:
    c.r[6] = 0x40u;  // 06018A9C mov #64,r6
L_06018A9E:
    { const uint32_t x = c.r[1]; c.pr = 0x06018AA2u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06018AA2u) return; }  // 06018A9E jsr @r1 ; mov r14,r4
L_06018AA2:
    c.r[1] = ld32(0x06018BFCu);  // 06018AA2 mov.l 0x06018BFC,r1
L_06018AA4:
    c.r[2] = ld32(c.r[1]);  // 06018AA4 mov.l @r1,r2
L_06018AA6:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06018BF0u);  // 06018AA6 mov.w 0x06018BF0,r1
L_06018AA8:
    c.r[0] = c.r[2];  // 06018AA8 mov r2,r0
L_06018AAA:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06018AAA mov.b @(r0,r1),r1
L_06018AAC:
    c.r[0] = 0x4u;  // 06018AAC mov #4,r0
L_06018AAE:
    c.r[1] &= c.r[0];  // 06018AAE and r0,r1
L_06018AB0:
    c.t = (c.r[1] & c.r[1]) == 0;  // 06018AB0 tst r1,r1
L_06018AB2:
    { const bool k = c.t; c.r[7] = 0x1Eu; if (k) { goto L_06018ACC; } }  // 06018AB2 bt/s 0x06018ACC ; mov #30,r7
L_06018AB6:
    c.r[2] = ld32(0x06018C00u);  // 06018AB6 mov.l 0x06018C00,r2
L_06018AB8:
    c.r[1] = c.r[2];  // 06018AB8 mov r2,r1
L_06018ABA:
    c.r[1] += 6;  // 06018ABA add #6,r1
L_06018ABC:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06018ABC mov.w @r1,r1
L_06018ABE:
    c.r[12] = c.r[1] & 0xFFFFu;  // 06018ABE extu.w r1,r12
L_06018AC0:
    c.r[1] = ld32(0x06018C04u);  // 06018AC0 mov.l 0x06018C04,r1
L_06018AC2:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06018AC2 mov.w @r1,r1
L_06018AC4:
    c.r[2] += 4;  // 06018AC4 add #4,r2
L_06018AC6:
    c.r[11] = c.r[1] & 0xFFFFu;  // 06018AC6 extu.w r1,r11
L_06018AC8:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]); goto L_06018B46;  // 06018AC8 bra 0x06018B46 ; mov.w @r2,r1
L_06018ACC:
    c.r[3] = ld32(0x06018C08u);  // 06018ACC mov.l 0x06018C08,r3
L_06018ACE:
    c.r[1] = ld32(0x06018C0Cu);  // 06018ACE mov.l 0x06018C0C,r1
L_06018AD0:
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]); c.r[3] += 1;  // 06018AD0 mov.b @r3+,r2
L_06018AD2:
    c.r[4] = ld32(c.r[1]);  // 06018AD2 mov.l @r1,r4
L_06018AD4:
    c.r[2] = c.r[2] & 0xFFu;  // 06018AD4 extu.b r2,r2
L_06018AD6:
    c.r[2] <<= 2;  // 06018AD6 shll2 r2
L_06018AD8:
    c.r[2] <<= 2;  // 06018AD8 shll2 r2
L_06018ADA:
    c.r[2] += c.r[4];  // 06018ADA add r4,r2
L_06018ADC:
    c.r[2] += 2;  // 06018ADC add #2,r2
L_06018ADE:
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06018ADE mov.b @r2,r2
L_06018AE0:
    c.r[1] = ld32(0x06018C10u);  // 06018AE0 mov.l 0x06018C10,r1
L_06018AE2:
    c.r[2] = c.r[2] & 0xFFu;  // 06018AE2 extu.b r2,r2
L_06018AE4:
    c.macl = c.r[2] * c.r[7];  // 06018AE4 mul.l r7,r2
L_06018AE6:
    c.r[5] = ld32(c.r[1]);  // 06018AE6 mov.l @r1,r5
L_06018AE8:
    c.r[1] = c.macl;  // 06018AE8 sts macl,r1
L_06018AEA:
    c.r[1] += c.r[5];  // 06018AEA add r5,r1
L_06018AEC:
    c.r[1] += 15;  // 06018AEC add #15,r1
L_06018AEE:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06018AEE mov.b @r1,r1
L_06018AF0:
    c.r[2] = ld32(0x06018C14u);  // 06018AF0 mov.l 0x06018C14,r2
L_06018AF2:
    c.r[6] = ld32(c.r[2]);  // 06018AF2 mov.l @r2,r6
L_06018AF4:
    c.r[1] = c.r[1] & 0xFFu;  // 06018AF4 extu.b r1,r1
L_06018AF6:
    c.r[2] = c.r[1];  // 06018AF6 mov r1,r2
L_06018AF8:
    c.r[2] += c.r[2];  // 06018AF8 add r2,r2
L_06018AFA:
    c.r[2] += c.r[1];  // 06018AFA add r1,r2
L_06018AFC:
    c.r[2] <<= 2;  // 06018AFC shll2 r2
L_06018AFE:
    c.r[0] = c.r[2];  // 06018AFE mov r2,r0
L_06018B00:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[6]);  // 06018B00 mov.w @(r0,r6),r1
L_06018B02:
    c.r[12] = c.r[1] & 0xFFFFu;  // 06018B02 extu.w r1,r12
L_06018B04:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06018B04 mov.b @r3,r1
L_06018B06:
    c.r[1] = c.r[1] & 0xFFu;  // 06018B06 extu.b r1,r1
L_06018B08:
    c.r[1] <<= 2;  // 06018B08 shll2 r1
L_06018B0A:
    c.r[1] <<= 2;  // 06018B0A shll2 r1
L_06018B0C:
    c.r[1] += c.r[4];  // 06018B0C add r4,r1
L_06018B0E:
    c.r[1] += 2;  // 06018B0E add #2,r1
L_06018B10:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06018B10 mov.b @r1,r1
L_06018B12:
    c.r[1] = c.r[1] & 0xFFu;  // 06018B12 extu.b r1,r1
L_06018B14:
    c.macl = c.r[1] * c.r[7];  // 06018B14 mul.l r7,r1
L_06018B16:
    c.r[1] = c.macl;  // 06018B16 sts macl,r1
L_06018B18:
    c.r[1] += c.r[5];  // 06018B18 add r5,r1
L_06018B1A:
    c.r[1] += 15;  // 06018B1A add #15,r1
L_06018B1C:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06018B1C mov.b @r1,r1
L_06018B1E:
    c.r[1] = c.r[1] & 0xFFu;  // 06018B1E extu.b r1,r1
L_06018B20:
    c.r[2] = c.r[1];  // 06018B20 mov r1,r2
L_06018B22:
    c.r[2] += c.r[2];  // 06018B22 add r2,r2
L_06018B24:
    c.r[2] += c.r[1];  // 06018B24 add r1,r2
L_06018B26:
    c.r[2] <<= 2;  // 06018B26 shll2 r2
L_06018B28:
    c.r[0] = c.r[2];  // 06018B28 mov r2,r0
L_06018B2A:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[6]);  // 06018B2A mov.w @(r0,r6),r1
L_06018B2C:
    c.r[11] = c.r[1] & 0xFFFFu;  // 06018B2C extu.w r1,r11
L_06018B2E:
    c.r[1] = ld32(0x06018C18u);  // 06018B2E mov.l 0x06018C18,r1
L_06018B30:
    c.r[3] = ld32(c.r[1]);  // 06018B30 mov.l @r1,r3
L_06018B32:
    c.r[1] = ld32(0x06018C1Cu);  // 06018B32 mov.l 0x06018C1C,r1
L_06018B34:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06018B34 mov.b @r1,r1
L_06018B36:
    c.r[1] = c.r[1] & 0xFFu;  // 06018B36 extu.b r1,r1
L_06018B38:
    c.r[2] = c.r[1];  // 06018B38 mov r1,r2
L_06018B3A:
    c.r[2] <<= 2;  // 06018B3A shll2 r2
L_06018B3C:
    c.r[2] += c.r[1];  // 06018B3C add r1,r2
L_06018B3E:
    c.r[2] <<= 2;  // 06018B3E shll2 r2
L_06018B40:
    c.r[3] += c.r[2];  // 06018B40 add r2,r3
L_06018B42:
    c.r[3] += 46;  // 06018B42 add #46,r3
L_06018B44:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06018B44 mov.w @r3,r1
L_06018B46:
    c.r[9] = c.r[1] & 0xFFFFu;  // 06018B46 extu.w r1,r9
L_06018B48:
    c.r[10] = ld32(0x06018C20u);  // 06018B48 mov.l 0x06018C20,r10
L_06018B4A:
    c.r[8] = ld32(0x06018C24u);  // 06018B4A mov.l 0x06018C24,r8
L_06018B4C:
    c.r[5] = 0x1Cu;  // 06018B4C mov #28,r5
L_06018B4E:
    { const uint32_t x = c.r[8]; c.pr = 0x06018B52u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06018B52u) return; }  // 06018B4E jsr @r8 ; mov r10,r4
L_06018B52:
    c.r[5] = c.r[12];  // 06018B52 mov r12,r5
L_06018B54:
    { const uint32_t x = c.r[8]; c.pr = 0x06018B58u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06018B58u) return; }  // 06018B54 jsr @r8 ; mov r0,r4
L_06018B58:
    c.r[0] += 2;  // 06018B58 add #2,r0
L_06018B5A:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06018B5A mov.b @r0,r0
L_06018B5C:
    c.r[13] = 0x1Au;  // 06018B5C mov #26,r13
L_06018B5E:
    c.r[0] &= 0x3Fu;  // 06018B5E and #63,r0
L_06018B60:
    c.t = c.r[0] > c.r[13];  // 06018B60 cmp/hi r13,r0
L_06018B62:
    { const bool k = !c.t; c.r[5] = 0x1Cu; if (k) { goto L_06018B7E; } }  // 06018B62 bf/s 0x06018B7E ; mov #28,r5
L_06018B66:
    { const uint32_t x = c.r[8]; c.pr = 0x06018B6Au; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06018B6Au) return; }  // 06018B66 jsr @r8 ; mov r10,r4
L_06018B6A:
    c.r[5] = c.r[12];  // 06018B6A mov r12,r5
L_06018B6C:
    { const uint32_t x = c.r[8]; c.pr = 0x06018B70u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06018B70u) return; }  // 06018B6C jsr @r8 ; mov r0,r4
L_06018B70:
    c.r[0] += 2;  // 06018B70 add #2,r0
L_06018B72:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06018B72 mov.b @r0,r0
L_06018B74:
    c.r[1] = 0x1Fu;  // 06018B74 mov #31,r1
L_06018B76:
    c.r[0] &= 0x3Fu;  // 06018B76 and #63,r0
L_06018B78:
    c.t = c.r[0] > c.r[1];  // 06018B78 cmp/hi r1,r0
L_06018B7A:
    { const bool k = !c.t; c.r[5] = 0x1Cu; if (k) { goto L_06018C68; } }  // 06018B7A bf/s 0x06018C68 ; mov #28,r5
L_06018B7E:
    c.r[5] = 0x1Cu;  // 06018B7E mov #28,r5
L_06018B80:
    { const uint32_t x = c.r[8]; c.pr = 0x06018B84u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06018B84u) return; }  // 06018B80 jsr @r8 ; mov r10,r4
L_06018B84:
    c.r[5] = c.r[11];  // 06018B84 mov r11,r5
L_06018B86:
    { const uint32_t x = c.r[8]; c.pr = 0x06018B8Au; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06018B8Au) return; }  // 06018B86 jsr @r8 ; mov r0,r4
L_06018B8A:
    c.r[0] += 2;  // 06018B8A add #2,r0
L_06018B8C:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06018B8C mov.b @r0,r0
L_06018B8E:
    c.r[0] &= 0x3Fu;  // 06018B8E and #63,r0
L_06018B90:
    c.t = c.r[0] > c.r[13];  // 06018B90 cmp/hi r13,r0
L_06018B92:
    { const bool k = !c.t; c.r[5] = 0x1Cu; if (k) { goto L_06018BAE; } }  // 06018B92 bf/s 0x06018BAE ; mov #28,r5
L_06018B96:
    { const uint32_t x = c.r[8]; c.pr = 0x06018B9Au; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06018B9Au) return; }  // 06018B96 jsr @r8 ; mov r10,r4
L_06018B9A:
    c.r[5] = c.r[11];  // 06018B9A mov r11,r5
L_06018B9C:
    { const uint32_t x = c.r[8]; c.pr = 0x06018BA0u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06018BA0u) return; }  // 06018B9C jsr @r8 ; mov r0,r4
L_06018BA0:
    c.r[0] += 2;  // 06018BA0 add #2,r0
L_06018BA2:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06018BA2 mov.b @r0,r0
L_06018BA4:
    c.r[1] = 0x1Fu;  // 06018BA4 mov #31,r1
L_06018BA6:
    c.r[0] &= 0x3Fu;  // 06018BA6 and #63,r0
L_06018BA8:
    c.t = c.r[0] > c.r[1];  // 06018BA8 cmp/hi r1,r0
L_06018BAA:
    { const bool k = !c.t; c.r[5] = 0x1Cu; if (k) { goto L_06018C60; } }  // 06018BAA bf/s 0x06018C60 ; mov #28,r5
L_06018BAE:
    c.r[3] = ld32(0x06018C08u);  // 06018BAE mov.l 0x06018C08,r3
L_06018BB0:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06018BB0 mov.b @r3,r1
L_06018BB2:
    c.r[2] = ld32(0x06018C0Cu);  // 06018BB2 mov.l 0x06018C0C,r2
L_06018BB4:
    c.r[2] = ld32(c.r[2]);  // 06018BB4 mov.l @r2,r2
L_06018BB6:
    c.r[1] = c.r[1] & 0xFFu;  // 06018BB6 extu.b r1,r1
L_06018BB8:
    c.r[1] <<= 2;  // 06018BB8 shll2 r1
L_06018BBA:
    c.r[1] <<= 2;  // 06018BBA shll2 r1
L_06018BBC:
    c.r[1] += c.r[2];  // 06018BBC add r2,r1
L_06018BBE:
    c.r[1] += 3;  // 06018BBE add #3,r1
L_06018BC0:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06018BC0 mov.b @r1,r1
L_06018BC2:
    c.r[0] = c.r[1];  // 06018BC2 mov r1,r0
L_06018BC4:
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06018BC4 shlr r0
L_06018BC6:
    c.r[0] &= 0x3u;  // 06018BC6 and #3,r0
L_06018BC8:
    c.t = (c.r[0] & c.r[0]) == 0;  // 06018BC8 tst r0,r0
L_06018BCA:
    { const bool k = c.t; c.r[5] = 0x1Cu; if (k) { goto L_06018C28; } }  // 06018BCA bt/s 0x06018C28 ; mov #28,r5
L_06018BCE:
    c.r[3] += 1;  // 06018BCE add #1,r3
L_06018BD0:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06018BD0 mov.b @r3,r1
L_06018BD2:
    c.r[1] = c.r[1] & 0xFFu;  // 06018BD2 extu.b r1,r1
L_06018BD4:
    c.r[1] <<= 2;  // 06018BD4 shll2 r1
L_06018BD6:
    c.r[1] <<= 2;  // 06018BD6 shll2 r1
L_06018BD8:
    c.r[1] += c.r[2];  // 06018BD8 add r2,r1
L_06018BDA:
    c.r[1] += 3;  // 06018BDA add #3,r1
L_06018BDC:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06018BDC mov.b @r1,r1
L_06018BDE:
    c.r[0] = c.r[1];  // 06018BDE mov r1,r0
L_06018BE0:
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06018BE0 shlr r0
L_06018BE2:
    c.r[0] &= 0x3u;  // 06018BE2 and #3,r0
L_06018BE4:
    c.t = (c.r[0] & c.r[0]) == 0;  // 06018BE4 tst r0,r0
L_06018BE6:
    if (!c.t) { goto L_06018C28; }  // 06018BE6 bf 0x06018C28
L_06018BE8:
    { const uint32_t x = c.r[8]; c.pr = 0x06018BECu; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06018BECu) return; }  // 06018BE8 jsr @r8 ; mov r10,r4
L_06018BEC:
    c.r[5] = c.r[11]; goto L_06018C6E;  // 06018BEC bra 0x06018C6E ; mov r11,r5
L_06018C28:
    { const uint32_t x = c.r[8]; c.pr = 0x06018C2Cu; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06018C2Cu) return; }  // 06018C28 jsr @r8 ; mov r10,r4
L_06018C2C:
    c.r[5] = c.r[12];  // 06018C2C mov r12,r5
L_06018C2E:
    { const uint32_t x = c.r[8]; c.pr = 0x06018C32u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06018C32u) return; }  // 06018C2E jsr @r8 ; mov r0,r4
L_06018C32:
    c.r[0] += 2;  // 06018C32 add #2,r0
L_06018C34:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06018C34 mov.b @r0,r0
L_06018C36:
    c.r[0] &= 0x3Fu;  // 06018C36 and #63,r0
L_06018C38:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 06018C38 mov.b @(r0,r14),r1
L_06018C3A:
    c.r[3] = c.r[1] & 0xFFu;  // 06018C3A extu.b r1,r3
L_06018C3C:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06018CC0u);  // 06018C3C mov.w 0x06018CC0,r1
L_06018C3E:
    c.t = c.r[9] == c.r[1];  // 06018C3E cmp/eq r1,r9
L_06018C40:
    if (!c.t) { goto L_06018C44; }  // 06018C40 bf 0x06018C44
L_06018C42:
    c.r[3] = 0x7u;  // 06018C42 mov #7,r3
L_06018C44:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06018CC2u);  // 06018C44 mov.w 0x06018CC2,r1
L_06018C46:
    c.t = c.r[9] == c.r[1];  // 06018C46 cmp/eq r1,r9
L_06018C48:
    if (!c.t) { goto L_06018C4C; }  // 06018C48 bf 0x06018C4C
L_06018C4A:
    c.r[3] = 0x8u;  // 06018C4A mov #8,r3
L_06018C4C:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06018CC4u);  // 06018C4C mov.w 0x06018CC4,r1
L_06018C4E:
    c.t = c.r[9] == c.r[1];  // 06018C4E cmp/eq r1,r9
L_06018C50:
    if (!c.t) { goto L_06018C54; }  // 06018C50 bf 0x06018C54
L_06018C52:
    c.r[3] = 0x8u;  // 06018C52 mov #8,r3
L_06018C54:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06018CC6u);  // 06018C54 mov.w 0x06018CC6,r1
L_06018C56:
    c.t = c.r[9] == c.r[1];  // 06018C56 cmp/eq r1,r9
L_06018C58:
    if (!c.t) { goto L_06018C7C; }  // 06018C58 bf 0x06018C7C
L_06018C5A:
    c.r[3] = 0x7u;  // 06018C5A mov #7,r3
L_06018C5C:
    goto L_06018C7C;  // 06018C5C bra 0x06018C7C ; nop
L_06018C60:
    { const uint32_t x = c.r[8]; c.pr = 0x06018C64u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06018C64u) return; }  // 06018C60 jsr @r8 ; mov r10,r4
L_06018C64:
    c.r[5] = c.r[11]; goto L_06018C6E;  // 06018C64 bra 0x06018C6E ; mov r11,r5
L_06018C68:
    { const uint32_t x = c.r[8]; c.pr = 0x06018C6Cu; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06018C6Cu) return; }  // 06018C68 jsr @r8 ; mov r10,r4
L_06018C6C:
    c.r[5] = c.r[12];  // 06018C6C mov r12,r5
L_06018C6E:
    { const uint32_t x = c.r[8]; c.pr = 0x06018C72u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06018C72u) return; }  // 06018C6E jsr @r8 ; mov r0,r4
L_06018C72:
    c.r[0] += 2;  // 06018C72 add #2,r0
L_06018C74:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06018C74 mov.b @r0,r0
L_06018C76:
    c.r[0] &= 0x3Fu;  // 06018C76 and #63,r0
L_06018C78:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 06018C78 mov.b @(r0,r14),r1
L_06018C7A:
    c.r[3] = c.r[1] & 0xFFu;  // 06018C7A extu.b r1,r3
L_06018C7C:
    c.r[1] = ld32(0x06018C84u);  // 06018C7C mov.l 0x06018C84,r1
L_06018C7E:
    { const uint32_t x = c.r[1]; SH2_POLL(c); switch (x) { case 0x06018A84u: goto L_06018A84; case 0x06018A86u: goto L_06018A86; case 0x06018A88u: goto L_06018A88; case 0x06018A8Au: goto L_06018A8A; case 0x06018A8Cu: goto L_06018A8C; case 0x06018A8Eu: goto L_06018A8E; case 0x06018A90u: goto L_06018A90; case 0x06018A92u: goto L_06018A92; case 0x06018A94u: goto L_06018A94; case 0x06018A96u: goto L_06018A96; case 0x06018A98u: goto L_06018A98; case 0x06018A9Au: goto L_06018A9A; case 0x06018A9Cu: goto L_06018A9C; case 0x06018A9Eu: goto L_06018A9E; case 0x06018AA2u: goto L_06018AA2; case 0x06018AA4u: goto L_06018AA4; case 0x06018AA6u: goto L_06018AA6; case 0x06018AA8u: goto L_06018AA8; case 0x06018AAAu: goto L_06018AAA; case 0x06018AACu: goto L_06018AAC; case 0x06018AAEu: goto L_06018AAE; case 0x06018AB0u: goto L_06018AB0; case 0x06018AB2u: goto L_06018AB2; case 0x06018AB6u: goto L_06018AB6; case 0x06018AB8u: goto L_06018AB8; case 0x06018ABAu: goto L_06018ABA; case 0x06018ABCu: goto L_06018ABC; case 0x06018ABEu: goto L_06018ABE; case 0x06018AC0u: goto L_06018AC0; case 0x06018AC2u: goto L_06018AC2; case 0x06018AC4u: goto L_06018AC4; case 0x06018AC6u: goto L_06018AC6; case 0x06018AC8u: goto L_06018AC8; case 0x06018ACCu: goto L_06018ACC; case 0x06018ACEu: goto L_06018ACE; case 0x06018AD0u: goto L_06018AD0; case 0x06018AD2u: goto L_06018AD2; case 0x06018AD4u: goto L_06018AD4; case 0x06018AD6u: goto L_06018AD6; case 0x06018AD8u: goto L_06018AD8; case 0x06018ADAu: goto L_06018ADA; case 0x06018ADCu: goto L_06018ADC; case 0x06018ADEu: goto L_06018ADE; case 0x06018AE0u: goto L_06018AE0; case 0x06018AE2u: goto L_06018AE2; case 0x06018AE4u: goto L_06018AE4; case 0x06018AE6u: goto L_06018AE6; case 0x06018AE8u: goto L_06018AE8; case 0x06018AEAu: goto L_06018AEA; case 0x06018AECu: goto L_06018AEC; case 0x06018AEEu: goto L_06018AEE; case 0x06018AF0u: goto L_06018AF0; case 0x06018AF2u: goto L_06018AF2; case 0x06018AF4u: goto L_06018AF4; case 0x06018AF6u: goto L_06018AF6; case 0x06018AF8u: goto L_06018AF8; case 0x06018AFAu: goto L_06018AFA; case 0x06018AFCu: goto L_06018AFC; case 0x06018AFEu: goto L_06018AFE; case 0x06018B00u: goto L_06018B00; case 0x06018B02u: goto L_06018B02; case 0x06018B04u: goto L_06018B04; case 0x06018B06u: goto L_06018B06; case 0x06018B08u: goto L_06018B08; case 0x06018B0Au: goto L_06018B0A; case 0x06018B0Cu: goto L_06018B0C; case 0x06018B0Eu: goto L_06018B0E; case 0x06018B10u: goto L_06018B10; case 0x06018B12u: goto L_06018B12; case 0x06018B14u: goto L_06018B14; case 0x06018B16u: goto L_06018B16; case 0x06018B18u: goto L_06018B18; case 0x06018B1Au: goto L_06018B1A; case 0x06018B1Cu: goto L_06018B1C; case 0x06018B1Eu: goto L_06018B1E; case 0x06018B20u: goto L_06018B20; case 0x06018B22u: goto L_06018B22; case 0x06018B24u: goto L_06018B24; case 0x06018B26u: goto L_06018B26; case 0x06018B28u: goto L_06018B28; case 0x06018B2Au: goto L_06018B2A; case 0x06018B2Cu: goto L_06018B2C; case 0x06018B2Eu: goto L_06018B2E; case 0x06018B30u: goto L_06018B30; case 0x06018B32u: goto L_06018B32; case 0x06018B34u: goto L_06018B34; case 0x06018B36u: goto L_06018B36; case 0x06018B38u: goto L_06018B38; case 0x06018B3Au: goto L_06018B3A; case 0x06018B3Cu: goto L_06018B3C; case 0x06018B3Eu: goto L_06018B3E; case 0x06018B40u: goto L_06018B40; case 0x06018B42u: goto L_06018B42; case 0x06018B44u: goto L_06018B44; case 0x06018B46u: goto L_06018B46; case 0x06018B48u: goto L_06018B48; case 0x06018B4Au: goto L_06018B4A; case 0x06018B4Cu: goto L_06018B4C; case 0x06018B4Eu: goto L_06018B4E; case 0x06018B52u: goto L_06018B52; case 0x06018B54u: goto L_06018B54; case 0x06018B58u: goto L_06018B58; case 0x06018B5Au: goto L_06018B5A; case 0x06018B5Cu: goto L_06018B5C; case 0x06018B5Eu: goto L_06018B5E; case 0x06018B60u: goto L_06018B60; case 0x06018B62u: goto L_06018B62; case 0x06018B66u: goto L_06018B66; case 0x06018B6Au: goto L_06018B6A; case 0x06018B6Cu: goto L_06018B6C; case 0x06018B70u: goto L_06018B70; case 0x06018B72u: goto L_06018B72; case 0x06018B74u: goto L_06018B74; case 0x06018B76u: goto L_06018B76; case 0x06018B78u: goto L_06018B78; case 0x06018B7Au: goto L_06018B7A; case 0x06018B7Eu: goto L_06018B7E; case 0x06018B80u: goto L_06018B80; case 0x06018B84u: goto L_06018B84; case 0x06018B86u: goto L_06018B86; case 0x06018B8Au: goto L_06018B8A; case 0x06018B8Cu: goto L_06018B8C; case 0x06018B8Eu: goto L_06018B8E; case 0x06018B90u: goto L_06018B90; case 0x06018B92u: goto L_06018B92; case 0x06018B96u: goto L_06018B96; case 0x06018B9Au: goto L_06018B9A; case 0x06018B9Cu: goto L_06018B9C; case 0x06018BA0u: goto L_06018BA0; case 0x06018BA2u: goto L_06018BA2; case 0x06018BA4u: goto L_06018BA4; case 0x06018BA6u: goto L_06018BA6; case 0x06018BA8u: goto L_06018BA8; case 0x06018BAAu: goto L_06018BAA; case 0x06018BAEu: goto L_06018BAE; case 0x06018BB0u: goto L_06018BB0; case 0x06018BB2u: goto L_06018BB2; case 0x06018BB4u: goto L_06018BB4; case 0x06018BB6u: goto L_06018BB6; case 0x06018BB8u: goto L_06018BB8; case 0x06018BBAu: goto L_06018BBA; case 0x06018BBCu: goto L_06018BBC; case 0x06018BBEu: goto L_06018BBE; case 0x06018BC0u: goto L_06018BC0; case 0x06018BC2u: goto L_06018BC2; case 0x06018BC4u: goto L_06018BC4; case 0x06018BC6u: goto L_06018BC6; case 0x06018BC8u: goto L_06018BC8; case 0x06018BCAu: goto L_06018BCA; case 0x06018BCEu: goto L_06018BCE; case 0x06018BD0u: goto L_06018BD0; case 0x06018BD2u: goto L_06018BD2; case 0x06018BD4u: goto L_06018BD4; case 0x06018BD6u: goto L_06018BD6; case 0x06018BD8u: goto L_06018BD8; case 0x06018BDAu: goto L_06018BDA; case 0x06018BDCu: goto L_06018BDC; case 0x06018BDEu: goto L_06018BDE; case 0x06018BE0u: goto L_06018BE0; case 0x06018BE2u: goto L_06018BE2; case 0x06018BE4u: goto L_06018BE4; case 0x06018BE6u: goto L_06018BE6; case 0x06018BE8u: goto L_06018BE8; case 0x06018BECu: goto L_06018BEC; case 0x06018C28u: goto L_06018C28; case 0x06018C2Cu: goto L_06018C2C; case 0x06018C2Eu: goto L_06018C2E; case 0x06018C32u: goto L_06018C32; case 0x06018C34u: goto L_06018C34; case 0x06018C36u: goto L_06018C36; case 0x06018C38u: goto L_06018C38; case 0x06018C3Au: goto L_06018C3A; case 0x06018C3Cu: goto L_06018C3C; case 0x06018C3Eu: goto L_06018C3E; case 0x06018C40u: goto L_06018C40; case 0x06018C42u: goto L_06018C42; case 0x06018C44u: goto L_06018C44; case 0x06018C46u: goto L_06018C46; case 0x06018C48u: goto L_06018C48; case 0x06018C4Au: goto L_06018C4A; case 0x06018C4Cu: goto L_06018C4C; case 0x06018C4Eu: goto L_06018C4E; case 0x06018C50u: goto L_06018C50; case 0x06018C52u: goto L_06018C52; case 0x06018C54u: goto L_06018C54; case 0x06018C56u: goto L_06018C56; case 0x06018C58u: goto L_06018C58; case 0x06018C5Au: goto L_06018C5A; case 0x06018C5Cu: goto L_06018C5C; case 0x06018C60u: goto L_06018C60; case 0x06018C64u: goto L_06018C64; case 0x06018C68u: goto L_06018C68; case 0x06018C6Cu: goto L_06018C6C; case 0x06018C6Eu: goto L_06018C6E; case 0x06018C72u: goto L_06018C72; case 0x06018C74u: goto L_06018C74; case 0x06018C76u: goto L_06018C76; case 0x06018C78u: goto L_06018C78; case 0x06018C7Au: goto L_06018C7A; case 0x06018C7Cu: goto L_06018C7C; case 0x06018C7Eu: goto L_06018C7E; default: sh2_call(c, x); return; } }  // 06018C7E jmp @r1 ; nop
}

void f_06018BAE(SH2Context& c) {
    ran[183] = 1;
L_06018BAE:
    c.r[3] = ld32(0x06018C08u);  // 06018BAE mov.l 0x06018C08,r3
L_06018BB0:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06018BB0 mov.b @r3,r1
L_06018BB2:
    c.r[2] = ld32(0x06018C0Cu);  // 06018BB2 mov.l 0x06018C0C,r2
L_06018BB4:
    c.r[2] = ld32(c.r[2]);  // 06018BB4 mov.l @r2,r2
L_06018BB6:
    c.r[1] = c.r[1] & 0xFFu;  // 06018BB6 extu.b r1,r1
L_06018BB8:
    c.r[1] <<= 2;  // 06018BB8 shll2 r1
L_06018BBA:
    c.r[1] <<= 2;  // 06018BBA shll2 r1
L_06018BBC:
    c.r[1] += c.r[2];  // 06018BBC add r2,r1
L_06018BBE:
    c.r[1] += 3;  // 06018BBE add #3,r1
L_06018BC0:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06018BC0 mov.b @r1,r1
L_06018BC2:
    c.r[0] = c.r[1];  // 06018BC2 mov r1,r0
L_06018BC4:
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06018BC4 shlr r0
L_06018BC6:
    c.r[0] &= 0x3u;  // 06018BC6 and #3,r0
L_06018BC8:
    c.t = (c.r[0] & c.r[0]) == 0;  // 06018BC8 tst r0,r0
L_06018BCA:
    { const bool k = c.t; c.r[5] = 0x1Cu; if (k) { goto L_06018C28; } }  // 06018BCA bt/s 0x06018C28 ; mov #28,r5
L_06018BCE:
    c.r[3] += 1;  // 06018BCE add #1,r3
L_06018BD0:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06018BD0 mov.b @r3,r1
L_06018BD2:
    c.r[1] = c.r[1] & 0xFFu;  // 06018BD2 extu.b r1,r1
L_06018BD4:
    c.r[1] <<= 2;  // 06018BD4 shll2 r1
L_06018BD6:
    c.r[1] <<= 2;  // 06018BD6 shll2 r1
L_06018BD8:
    c.r[1] += c.r[2];  // 06018BD8 add r2,r1
L_06018BDA:
    c.r[1] += 3;  // 06018BDA add #3,r1
L_06018BDC:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06018BDC mov.b @r1,r1
L_06018BDE:
    c.r[0] = c.r[1];  // 06018BDE mov r1,r0
L_06018BE0:
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06018BE0 shlr r0
L_06018BE2:
    c.r[0] &= 0x3u;  // 06018BE2 and #3,r0
L_06018BE4:
    c.t = (c.r[0] & c.r[0]) == 0;  // 06018BE4 tst r0,r0
L_06018BE6:
    if (!c.t) { goto L_06018C28; }  // 06018BE6 bf 0x06018C28
L_06018BE8:
    { const uint32_t x = c.r[8]; c.pr = 0x06018BECu; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06018BECu) return; }  // 06018BE8 jsr @r8 ; mov r10,r4
L_06018BEC:
    c.r[5] = c.r[11]; goto L_06018C6E;  // 06018BEC bra 0x06018C6E ; mov r11,r5
L_06018C28:
    { const uint32_t x = c.r[8]; c.pr = 0x06018C2Cu; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06018C2Cu) return; }  // 06018C28 jsr @r8 ; mov r10,r4
L_06018C2C:
    c.r[5] = c.r[12];  // 06018C2C mov r12,r5
L_06018C2E:
    { const uint32_t x = c.r[8]; c.pr = 0x06018C32u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06018C32u) return; }  // 06018C2E jsr @r8 ; mov r0,r4
L_06018C32:
    c.r[0] += 2;  // 06018C32 add #2,r0
L_06018C34:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06018C34 mov.b @r0,r0
L_06018C36:
    c.r[0] &= 0x3Fu;  // 06018C36 and #63,r0
L_06018C38:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 06018C38 mov.b @(r0,r14),r1
L_06018C3A:
    c.r[3] = c.r[1] & 0xFFu;  // 06018C3A extu.b r1,r3
L_06018C3C:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06018CC0u);  // 06018C3C mov.w 0x06018CC0,r1
L_06018C3E:
    c.t = c.r[9] == c.r[1];  // 06018C3E cmp/eq r1,r9
L_06018C40:
    if (!c.t) { goto L_06018C44; }  // 06018C40 bf 0x06018C44
L_06018C42:
    c.r[3] = 0x7u;  // 06018C42 mov #7,r3
L_06018C44:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06018CC2u);  // 06018C44 mov.w 0x06018CC2,r1
L_06018C46:
    c.t = c.r[9] == c.r[1];  // 06018C46 cmp/eq r1,r9
L_06018C48:
    if (!c.t) { goto L_06018C4C; }  // 06018C48 bf 0x06018C4C
L_06018C4A:
    c.r[3] = 0x8u;  // 06018C4A mov #8,r3
L_06018C4C:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06018CC4u);  // 06018C4C mov.w 0x06018CC4,r1
L_06018C4E:
    c.t = c.r[9] == c.r[1];  // 06018C4E cmp/eq r1,r9
L_06018C50:
    if (!c.t) { goto L_06018C54; }  // 06018C50 bf 0x06018C54
L_06018C52:
    c.r[3] = 0x8u;  // 06018C52 mov #8,r3
L_06018C54:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06018CC6u);  // 06018C54 mov.w 0x06018CC6,r1
L_06018C56:
    c.t = c.r[9] == c.r[1];  // 06018C56 cmp/eq r1,r9
L_06018C58:
    if (!c.t) { goto L_06018C7C; }  // 06018C58 bf 0x06018C7C
L_06018C5A:
    c.r[3] = 0x7u;  // 06018C5A mov #7,r3
L_06018C5C:
    goto L_06018C7C;  // 06018C5C bra 0x06018C7C ; nop
L_06018C6E:
    { const uint32_t x = c.r[8]; c.pr = 0x06018C72u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06018C72u) return; }  // 06018C6E jsr @r8 ; mov r0,r4
L_06018C72:
    c.r[0] += 2;  // 06018C72 add #2,r0
L_06018C74:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06018C74 mov.b @r0,r0
L_06018C76:
    c.r[0] &= 0x3Fu;  // 06018C76 and #63,r0
L_06018C78:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 06018C78 mov.b @(r0,r14),r1
L_06018C7A:
    c.r[3] = c.r[1] & 0xFFu;  // 06018C7A extu.b r1,r3
L_06018C7C:
    c.r[1] = ld32(0x06018C84u);  // 06018C7C mov.l 0x06018C84,r1
L_06018C7E:
    { const uint32_t x = c.r[1]; SH2_POLL(c); switch (x) { case 0x06018BAEu: goto L_06018BAE; case 0x06018BB0u: goto L_06018BB0; case 0x06018BB2u: goto L_06018BB2; case 0x06018BB4u: goto L_06018BB4; case 0x06018BB6u: goto L_06018BB6; case 0x06018BB8u: goto L_06018BB8; case 0x06018BBAu: goto L_06018BBA; case 0x06018BBCu: goto L_06018BBC; case 0x06018BBEu: goto L_06018BBE; case 0x06018BC0u: goto L_06018BC0; case 0x06018BC2u: goto L_06018BC2; case 0x06018BC4u: goto L_06018BC4; case 0x06018BC6u: goto L_06018BC6; case 0x06018BC8u: goto L_06018BC8; case 0x06018BCAu: goto L_06018BCA; case 0x06018BCEu: goto L_06018BCE; case 0x06018BD0u: goto L_06018BD0; case 0x06018BD2u: goto L_06018BD2; case 0x06018BD4u: goto L_06018BD4; case 0x06018BD6u: goto L_06018BD6; case 0x06018BD8u: goto L_06018BD8; case 0x06018BDAu: goto L_06018BDA; case 0x06018BDCu: goto L_06018BDC; case 0x06018BDEu: goto L_06018BDE; case 0x06018BE0u: goto L_06018BE0; case 0x06018BE2u: goto L_06018BE2; case 0x06018BE4u: goto L_06018BE4; case 0x06018BE6u: goto L_06018BE6; case 0x06018BE8u: goto L_06018BE8; case 0x06018BECu: goto L_06018BEC; case 0x06018C28u: goto L_06018C28; case 0x06018C2Cu: goto L_06018C2C; case 0x06018C2Eu: goto L_06018C2E; case 0x06018C32u: goto L_06018C32; case 0x06018C34u: goto L_06018C34; case 0x06018C36u: goto L_06018C36; case 0x06018C38u: goto L_06018C38; case 0x06018C3Au: goto L_06018C3A; case 0x06018C3Cu: goto L_06018C3C; case 0x06018C3Eu: goto L_06018C3E; case 0x06018C40u: goto L_06018C40; case 0x06018C42u: goto L_06018C42; case 0x06018C44u: goto L_06018C44; case 0x06018C46u: goto L_06018C46; case 0x06018C48u: goto L_06018C48; case 0x06018C4Au: goto L_06018C4A; case 0x06018C4Cu: goto L_06018C4C; case 0x06018C4Eu: goto L_06018C4E; case 0x06018C50u: goto L_06018C50; case 0x06018C52u: goto L_06018C52; case 0x06018C54u: goto L_06018C54; case 0x06018C56u: goto L_06018C56; case 0x06018C58u: goto L_06018C58; case 0x06018C5Au: goto L_06018C5A; case 0x06018C5Cu: goto L_06018C5C; case 0x06018C6Eu: goto L_06018C6E; case 0x06018C72u: goto L_06018C72; case 0x06018C74u: goto L_06018C74; case 0x06018C76u: goto L_06018C76; case 0x06018C78u: goto L_06018C78; case 0x06018C7Au: goto L_06018C7A; case 0x06018C7Cu: goto L_06018C7C; case 0x06018C7Eu: goto L_06018C7E; default: sh2_call(c, x); return; } }  // 06018C7E jmp @r1 ; nop
}

void f_06018C88(SH2Context& c) {
    ran[184] = 1;
    c.r[0] = (uint32_t)(int16_t)ld16(0x06018CC8u);  // 06018C88 mov.w 0x06018CC8,r0
    c.r[15] = c.r[14]; goto L_06018CAE;  // 06018C8A bra 0x06018CAE ; mov r14,r15
L_06018CAE:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06018CAE lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06018CB0 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06018CB2 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06018CB4 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06018CB6 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06018CB8 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06018CBA mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06018CBC rts ; mov.l @r15+,r8
}

void f_06018C8E(SH2Context& c) {
    ran[185] = 1;
    c.r[1] = ld32(0x06018CD0u);  // 06018C8E mov.l 0x06018CD0,r1
    st16(c.r[1], c.r[3]);  // 06018C90 mov.w r3,@r1
    c.r[3] = c.r[2];  // 06018C92 mov r2,r3
    c.r[3] += 14;  // 06018C94 add #14,r3
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06018C96 mov.w @r3,r0
    c.r[0] &= 0x20u;  // 06018C98 and #32,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06018C9A tst r0,r0
    { const bool k = c.t; c.r[1] = 0x40u; if (k) { goto L_06018CA8; } }  // 06018C9C bt/s 0x06018CA8 ; mov #64,r1
    st16(c.r[3], c.r[1]);  // 06018CA0 mov.w r1,@r3
    c.r[2] += 6;  // 06018CA2 add #6,r2
    c.r[1] = 0x0u;  // 06018CA4 mov #0,r1
    st16(c.r[2], c.r[1]);  // 06018CA6 mov.w r1,@r2
L_06018CA8:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06018CCAu);  // 06018CA8 mov.w 0x06018CCA,r0
    c.r[14] += 64;  // 06018CAA add #64,r14
    c.r[15] = c.r[14];  // 06018CAC mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06018CAE lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06018CB0 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06018CB2 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06018CB4 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06018CB6 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06018CB8 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06018CBA mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06018CBC rts ; mov.l @r15+,r8
}

void f_06018CD4(SH2Context& c) {
    ran[186] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06018CD4 mov.l r14,@-r15
    c.r[1] = ld32(0x06018D28u);  // 06018CD6 mov.l 0x06018D28,r1
    c.r[2] = ld32(c.r[1]);  // 06018CD8 mov.l @r1,r2
    c.r[1] = c.r[2];  // 06018CDA mov r2,r1
    c.r[1] += 9;  // 06018CDC add #9,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06018CDE mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06018CE0 extu.b r1,r1
    c.r[1] >>= 2;  // 06018CE2 shlr2 r1
    c.r[1] >>= 2;  // 06018CE4 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06018CE6 shlr r1
    c.r[1] >>= 2;  // 06018CE8 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06018CEA tst r1,r1
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_06018D02; } }  // 06018CEC bf/s 0x06018D02 ; mov r15,r14
    c.r[1] = ld32(0x06018D2Cu);  // 06018CF0 mov.l 0x06018D2C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06018CF2 mov.b @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06018D22u);  // 06018CF4 mov.w 0x06018D22,r0
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06018CF6 mov.b @(r0,r2),r3
    c.r[1] = c.r[1] & 0xFFu;  // 06018CF8 extu.b r1,r1
    c.r[2] = c.r[3] & 0xFFu;  // 06018CFA extu.b r3,r2
    c.t = c.r[1] == c.r[2];  // 06018CFC cmp/eq r2,r1
    { const bool k = !c.t; c.r[1] = c.r[3] & 0xFFu; if (k) { goto L_06018D16; } }  // 06018CFE bf/s 0x06018D16 ; extu.b r3,r1
L_06018D02:
    c.r[2] = ld32(0x06018D30u);  // 06018D02 mov.l 0x06018D30,r2
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06018D04 mov.w @r2,r0
    c.r[0] &= 0x26u;  // 06018D06 and #38,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06018D08 tst r0,r0
    { const bool k = c.t; c.r[1] = 0x4u; if (k) { goto L_06018D10; } }  // 06018D0A bt/s 0x06018D10 ; mov #4,r1
    st16(c.r[2], c.r[1]);  // 06018D0E mov.w r1,@r2
L_06018D10:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06018D24u);  // 06018D10 mov.w 0x06018D24,r0
    c.r[15] = c.r[14]; goto L_06018D1E;  // 06018D12 bra 0x06018D1E ; mov r14,r15
L_06018D16:
    c.r[2] = ld32(0x06018D34u);  // 06018D16 mov.l 0x06018D34,r2
    st16(c.r[2], c.r[1]);  // 06018D18 mov.w r1,@r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06018D26u);  // 06018D1A mov.w 0x06018D26,r0
    c.r[15] = c.r[14];  // 06018D1C mov r14,r15
L_06018D1E:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06018D1E rts ; mov.l @r15+,r14
}

void f_06018D38(SH2Context& c) {
    ran[187] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06018D38 mov.l r14,@-r15
    c.r[1] = ld32(0x06018D68u);  // 06018D3A mov.l 0x06018D68,r1
    c.r[2] = ld32(c.r[1]);  // 06018D3C mov.l @r1,r2
    c.r[3] = ld32(0x06018D6Cu);  // 06018D3E mov.l 0x06018D6C,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06018D40 mov.b @r3,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06018D62u);  // 06018D42 mov.w 0x06018D62,r0
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06018D44 mov.b @(r0,r2),r3
    c.r[1] = c.r[1] & 0xFFu;  // 06018D46 extu.b r1,r1
    c.r[2] = c.r[3] & 0xFFu;  // 06018D48 extu.b r3,r2
    c.t = c.r[1] == c.r[2];  // 06018D4A cmp/eq r2,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06018D5A; } }  // 06018D4C bt/s 0x06018D5A ; mov r15,r14
    c.r[2] = ld32(0x06018D70u);  // 06018D50 mov.l 0x06018D70,r2
    c.r[1] = c.r[3] & 0xFFu;  // 06018D52 extu.b r3,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06018D64u);  // 06018D54 mov.w 0x06018D64,r0
    st16(c.r[2], c.r[1]); goto L_06018D5C;  // 06018D56 bra 0x06018D5C ; mov.w r1,@r2
L_06018D5A:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06018D66u);  // 06018D5A mov.w 0x06018D66,r0
L_06018D5C:
    c.r[15] = c.r[14];  // 06018D5C mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06018D5E rts ; mov.l @r15+,r14
}

void f_06018D74(SH2Context& c) {
    ran[188] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06018D74 mov.l r14,@-r15
    c.r[2] = ld32(0x06018D90u);  // 06018D76 mov.l 0x06018D90,r2
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06018D78 mov.w @r2,r0
    c.r[0] &= 0x26u;  // 06018D7A and #38,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06018D7C tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06018D86; } }  // 06018D7E bt/s 0x06018D86 ; mov r15,r14
    c.r[1] = 0x2u;  // 06018D82 mov #2,r1
    st16(c.r[2], c.r[1]);  // 06018D84 mov.w r1,@r2
L_06018D86:
    c.r[15] = c.r[14];  // 06018D86 mov r14,r15
    c.r[0] = ld32(0x06018D94u);  // 06018D88 mov.l 0x06018D94,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06018D8A rts ; mov.l @r15+,r14
}

void f_06018D98(SH2Context& c) {
    ran[189] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06018D98 mov.l r14,@-r15
    c.r[2] = ld32(0x06018DC0u);  // 06018D9A mov.l 0x06018DC0,r2
    c.r[3] = c.r[2];  // 06018D9C mov r2,r3
    c.r[3] += 14;  // 06018D9E add #14,r3
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06018DA0 mov.w @r3,r0
    c.r[0] &= 0x20u;  // 06018DA2 and #32,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06018DA4 tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06018DB4; } }  // 06018DA6 bt/s 0x06018DB4 ; mov r15,r14
    c.r[1] = (uint32_t)(int16_t)ld16(0x06018DBCu);  // 06018DAA mov.w 0x06018DBC,r1
    st16(c.r[3], c.r[1]);  // 06018DAC mov.w r1,@r3
    c.r[2] += 6;  // 06018DAE add #6,r2
    c.r[1] = 0x0u;  // 06018DB0 mov #0,r1
    st16(c.r[2], c.r[1]);  // 06018DB2 mov.w r1,@r2
L_06018DB4:
    c.r[15] = c.r[14];  // 06018DB4 mov r14,r15
    c.r[0] = ld32(0x06018DC4u);  // 06018DB6 mov.l 0x06018DC4,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06018DB8 rts ; mov.l @r15+,r14
}

void f_06018DC8(SH2Context& c) {
    ran[190] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06018DC8 mov.l r14,@-r15
    c.r[1] = ld32(0x06018DF8u);  // 06018DCA mov.l 0x06018DF8,r1
    c.r[2] = ld32(c.r[1]);  // 06018DCC mov.l @r1,r2
    c.r[1] = c.r[2];  // 06018DCE mov r2,r1
    c.r[1] += 1;  // 06018DD0 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06018DD2 mov.b @r1,r1
    c.r[2] += 2;  // 06018DD4 add #2,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06018DD6 mov.b @r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06018DD8 extu.b r1,r1
    c.r[1] <<= 8;  // 06018DDA shll8 r1
    c.r[2] = c.r[2] & 0xFFu;  // 06018DDC extu.b r2,r2
    c.r[2] += c.r[1];  // 06018DDE add r1,r2
    c.r[1] = ld32(0x06018DFCu);  // 06018DE0 mov.l 0x06018DFC,r1
    c.r[1] = ld32(c.r[1] + 16);  // 06018DE2 mov.l @(16,r1),r1
    c.t = c.r[2] >= c.r[1];  // 06018DE4 cmp/hs r1,r2
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_06018DEE; } }  // 06018DE6 bf/s 0x06018DEE ; mov r15,r14
    c.r[0] = 0x0u; goto L_06018DF0;  // 06018DEA bra 0x06018DF0 ; mov #0,r0
L_06018DEE:
    c.r[0] = ld32(0x06018E00u);  // 06018DEE mov.l 0x06018E00,r0
L_06018DF0:
    c.r[15] = c.r[14];  // 06018DF0 mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06018DF2 rts ; mov.l @r15+,r14
}

void f_06018E04(SH2Context& c) {
    ran[191] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06018E04 mov.l r14,@-r15
    c.r[2] = ld32(0x06018E20u);  // 06018E06 mov.l 0x06018E20,r2
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06018E08 mov.w @r2,r0
    c.r[0] &= 0x26u;  // 06018E0A and #38,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06018E0C tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06018E16; } }  // 06018E0E bt/s 0x06018E16 ; mov r15,r14
    c.r[1] = 0x4u;  // 06018E12 mov #4,r1
    st16(c.r[2], c.r[1]);  // 06018E14 mov.w r1,@r2
L_06018E16:
    c.r[15] = c.r[14];  // 06018E16 mov r14,r15
    c.r[0] = ld32(0x06018E24u);  // 06018E18 mov.l 0x06018E24,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06018E1A rts ; mov.l @r15+,r14
}

void f_06018E28(SH2Context& c) {
    ran[192] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06018E28 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06018E2A sts.l pr,@-r15
    c.r[1] = ld32(0x06018E4Cu);  // 06018E2C mov.l 0x06018E4C,r1
    c.r[1] = ld32(c.r[1]);  // 06018E2E mov.l @r1,r1
    c.r[1] += 1;  // 06018E30 add #1,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06018E32 mov.b @r1,r0
    c.r[14] = c.r[15];  // 06018E34 mov r15,r14
    c.r[1] = 0xFu;  // 06018E36 mov #15,r1
    c.r[1] &= c.r[0];  // 06018E38 and r0,r1
    c.r[0] = ld32(0x06018E50u);  // 06018E3A mov.l 0x06018E50,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06018E40u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06018E40u) return; }  // 06018E3C jsr @r0 ; mov r1,r4
    c.r[15] = c.r[14];  // 06018E40 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06018E42 lds.l @r15+,pr
    c.r[0] = ld32(0x06018E54u);  // 06018E44 mov.l 0x06018E54,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06018E46 rts ; mov.l @r15+,r14
}

void f_06018E58(SH2Context& c) {
    ran[193] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06018E58 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06018E5A sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06018E5C mov r15,r14
    c.r[0] = ld32(0x06018E74u);  // 06018E5E mov.l 0x06018E74,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06018E64u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06018E64u) return; }  // 06018E60 jsr @r0 ; mov #0,r4
    c.r[2] = ld32(0x06018E78u);  // 06018E64 mov.l 0x06018E78,r2
    c.r[1] = 0x8u;  // 06018E66 mov #8,r1
    st16(c.r[2], c.r[1]);  // 06018E68 mov.w r1,@r2
    c.r[15] = c.r[14];  // 06018E6A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06018E6C lds.l @r15+,pr
    c.r[0] = ld32(0x06018E7Cu);  // 06018E6E mov.l 0x06018E7C,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06018E70 rts ; mov.l @r15+,r14
}

void f_06018E80(SH2Context& c) {
    ran[194] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06018E80 mov.l r14,@-r15
    c.r[1] = ld32(0x06018E9Cu);  // 06018E82 mov.l 0x06018E9C,r1
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06018E84 mov.w @r1,r0
    c.r[0] &= 0x9u;  // 06018E86 and #9,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06018E88 tst r0,r0
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_06018E92; } }  // 06018E8A bf/s 0x06018E92 ; mov r15,r14
    c.r[0] = 0x0u; goto L_06018E94;  // 06018E8E bra 0x06018E94 ; mov #0,r0
L_06018E92:
    c.r[0] = ld32(0x06018EA0u);  // 06018E92 mov.l 0x06018EA0,r0
L_06018E94:
    c.r[15] = c.r[14];  // 06018E94 mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06018E96 rts ; mov.l @r15+,r14
}

void f_06018EA4(SH2Context& c) {
    ran[195] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06018EA4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06018EA6 sts.l pr,@-r15
    c.r[1] = ld32(0x06018EC4u);  // 06018EA8 mov.l 0x06018EC4,r1
    c.r[1] = ld32(c.r[1]);  // 06018EAA mov.l @r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06018EAC mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06018EAE extu.b r1,r0
    c.r[0] <<= 2;  // 06018EB0 shll2 r0
    c.r[1] = ld32(0x06018EC8u);  // 06018EB2 mov.l 0x06018EC8,r1
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 06018EB4 mov.l @(r0,r1),r0
    { const uint32_t x = c.r[0]; c.pr = 0x06018EBAu; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06018EBAu) return; }  // 06018EB6 jsr @r0 ; mov r15,r14
    c.r[15] = c.r[14];  // 06018EBA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06018EBC lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06018EBE mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[0] & 0xFFFFu; c.pc = x; return; }  // 06018EC0 rts ; extu.w r0,r0
}

void f_06018ECC(SH2Context& c) {
    ran[196] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06018ECC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06018ECE sts.l pr,@-r15
    c.r[1] = ld32(0x06018F04u);  // 06018ED0 mov.l 0x06018F04,r1
    c.r[1] = ld32(c.r[1]);  // 06018ED2 mov.l @r1,r1
    c.r[1] += 1;  // 06018ED4 add #1,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06018ED6 mov.b @r1,r0
    c.r[2] = (uint32_t)(int16_t)ld16(0x06018F02u);  // 06018ED8 mov.w 0x06018F02,r2
    c.r[2] &= c.r[0];  // 06018EDA and r0,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06018F02u);  // 06018EDC mov.w 0x06018F02,r1
    c.t = c.r[2] == c.r[1];  // 06018EDE cmp/eq r1,r2
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_06018EF0; } }  // 06018EE0 bf/s 0x06018EF0 ; mov r15,r14
    c.r[0] &= 0xFu;  // 06018EE4 and #15,r0
    c.r[0] += c.r[0];  // 06018EE6 add r0,r0
    c.r[1] = ld32(0x06018F08u);  // 06018EE8 mov.l 0x06018F08,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06018EEA mov.b @(r0,r1),r1
    c.r[4] = c.r[1] & 0xFFu; goto L_06018EF2;  // 06018EEC bra 0x06018EF2 ; extu.b r1,r4
L_06018EF0:
    c.r[4] = c.r[0] & 0xFFu;  // 06018EF0 extu.b r0,r4
L_06018EF2:
    c.r[1] = ld32(0x06018F0Cu);  // 06018EF2 mov.l 0x06018F0C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06018EF8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06018EF8u) return; }  // 06018EF4 jsr @r1 ; nop
    c.r[15] = c.r[14];  // 06018EF8 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06018EFA lds.l @r15+,pr
    c.r[0] = ld32(0x06018F10u);  // 06018EFC mov.l 0x06018F10,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06018EFE rts ; mov.l @r15+,r14
}

void f_06018F14(SH2Context& c) {
    ran[197] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06018F14 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06018F16 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06018F18 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06018F1A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06018F1C mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06018F1E mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06018F20 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06018F22 sts.l pr,@-r15
    c.r[1] = ld32(0x06018FBCu);  // 06018F24 mov.l 0x06018FBC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06018F26 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06018F28 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06018F2A tst r1,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06018F36; } }  // 06018F2C bt/s 0x06018F36 ; mov r15,r14
    c.r[12] = 0x1u;  // 06018F30 mov #1,r12
    c.r[13] = 0x5u; goto L_06018F3A;  // 06018F32 bra 0x06018F3A ; mov #5,r13
L_06018F36:
    c.r[12] = 0x2u;  // 06018F36 mov #2,r12
    c.r[13] = 0x3u;  // 06018F38 mov #3,r13
L_06018F3A:
    c.r[9] = ld32(0x06018FBCu);  // 06018F3A mov.l 0x06018FBC,r9
    c.r[1] = c.r[9];  // 06018F3C mov r9,r1
    c.r[1] += 2;  // 06018F3E add #2,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06018F40 mov.b @r1,r4
    c.r[8] = ld32(0x06018FC0u);  // 06018F42 mov.l 0x06018FC0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06018F48u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06018F48u) return; }  // 06018F44 jsr @r8 ; extu.b r4,r4
    { const uint32_t x = c.r[8]; c.pr = 0x06018F4Cu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06018F4Cu) return; }  // 06018F48 jsr @r8 ; mov #1,r4
    { const uint32_t x = c.r[8]; c.pr = 0x06018F50u; c.r[4] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06018F50u) return; }  // 06018F4C jsr @r8 ; mov #2,r4
    { const uint32_t x = c.r[8]; c.pr = 0x06018F54u; c.r[4] = 0x3u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06018F54u) return; }  // 06018F50 jsr @r8 ; mov #3,r4
    c.r[2] = c.r[12];  // 06018F54 mov r12,r2
    c.r[2] <<= 2;  // 06018F56 shll2 r2
    c.r[2] += c.r[2];  // 06018F58 add r2,r2
    c.r[1] = ld32(0x06018FC4u);  // 06018F5A mov.l 0x06018FC4,r1
    c.r[0] = c.r[2];  // 06018F5C mov r2,r0
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06018F5E mov.b @(r0,r1),r3
    c.r[10] = ld32(0x06018FC8u);  // 06018F60 mov.l 0x06018FC8,r10
    c.r[0] = 0x7Fu;  // 06018F62 mov #127,r0
    c.r[3] &= c.r[0];  // 06018F64 and r0,r3
    c.r[0] = c.r[2];  // 06018F66 mov r2,r0
    st8(c.r[0] + c.r[1], c.r[3]);  // 06018F68 mov.b r3,@(r0,r1)
    c.r[2] = c.r[13];  // 06018F6A mov r13,r2
    c.r[2] <<= 2;  // 06018F6C shll2 r2
    c.r[2] += c.r[2];  // 06018F6E add r2,r2
    c.r[0] = c.r[2];  // 06018F70 mov r2,r0
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06018F72 mov.b @(r0,r1),r3
    c.r[5] = c.r[12];  // 06018F74 mov r12,r5
    c.r[0] = 0x7Fu;  // 06018F76 mov #127,r0
    c.r[3] &= c.r[0];  // 06018F78 and r0,r3
    c.r[0] = c.r[2];  // 06018F7A mov r2,r0
    st8(c.r[0] + c.r[1], c.r[3]);  // 06018F7C mov.b r3,@(r0,r1)
    c.r[8] = ld32(c.r[9] + 20);  // 06018F7E mov.l @(20,r9),r8
    c.r[4] = 0x0u;  // 06018F80 mov #0,r4
    c.r[2] = ld32(c.r[9] + 12);  // 06018F82 mov.l @(12,r9),r2
    c.r[6] = c.r[8];  // 06018F84 mov r8,r6
    c.r[1] = ld32(c.r[9] + 8);  // 06018F86 mov.l @(8,r9),r1
    c.r[11] = c.r[2];  // 06018F88 mov r2,r11
    c.r[11] -= c.r[1];  // 06018F8A sub r1,r11
    { const uint32_t x = c.r[10]; c.pr = 0x06018F90u; c.r[7] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06018F90u) return; }  // 06018F8C jsr @r10 ; mov r11,r7
    c.r[8] += c.r[11];  // 06018F90 add r11,r8
    c.r[6] = c.r[8];  // 06018F92 mov r8,r6
    c.r[7] = ld32(c.r[9] + 16);  // 06018F94 mov.l @(16,r9),r7
    c.r[5] = c.r[13];  // 06018F96 mov r13,r5
    c.r[1] = ld32(c.r[9] + 12);  // 06018F98 mov.l @(12,r9),r1
    c.r[4] = 0x0u;  // 06018F9A mov #0,r4
    { const uint32_t x = c.r[10]; c.pr = 0x06018FA0u; c.r[7] -= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06018FA0u) return; }  // 06018F9C jsr @r10 ; sub r1,r7
    c.r[9] += 4;  // 06018FA0 add #4,r9
    c.r[1] = 0x8u;  // 06018FA2 mov #8,r1
    st16(c.r[9], c.r[1]);  // 06018FA4 mov.w r1,@r9
    c.r[15] = c.r[14];  // 06018FA6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06018FA8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06018FAA mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06018FAC mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06018FAE mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06018FB0 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06018FB2 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06018FB4 mov.l @r15+,r9
    c.r[0] = ld32(0x06018FCCu);  // 06018FB6 mov.l 0x06018FCC,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06018FB8 rts ; mov.l @r15+,r8
}

void f_06018FD0(SH2Context& c) {
    ran[198] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06018FD0 mov.l r14,@-r15
    c.r[1] = ld32(0x0601901Cu);  // 06018FD2 mov.l 0x0601901C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06018FD4 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06018FD6 extu.b r1,r1
    c.r[1] >>= 2;  // 06018FD8 shlr2 r1
    c.r[1] >>= 2;  // 06018FDA shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06018FDC shlr r1
    c.r[1] >>= 2;  // 06018FDE shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06018FE0 tst r1,r1
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_06019012; } }  // 06018FE2 bf/s 0x06019012 ; mov r15,r14
    c.r[1] = ld32(0x06019020u);  // 06018FE6 mov.l 0x06019020,r1
    c.r[1] = ld32(c.r[1]);  // 06018FE8 mov.l @r1,r1
    c.r[1] += 1;  // 06018FEA add #1,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06018FEC mov.b @r1,r0
    c.r[2] = (uint32_t)(int16_t)ld16(0x0601901Au);  // 06018FEE mov.w 0x0601901A,r2
    c.r[2] &= c.r[0];  // 06018FF0 and r0,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601901Au);  // 06018FF2 mov.w 0x0601901A,r1
    c.t = c.r[2] == c.r[1];  // 06018FF4 cmp/eq r1,r2
    if (!c.t) { goto L_06019004; }  // 06018FF6 bf 0x06019004
    c.r[0] &= 0xFu;  // 06018FF8 and #15,r0
    c.r[0] += c.r[0];  // 06018FFA add r0,r0
    c.r[1] = ld32(0x06019024u);  // 06018FFC mov.l 0x06019024,r1
    c.r[2] = ld32(0x06019028u);  // 06018FFE mov.l 0x06019028,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]); goto L_06019008;  // 06019000 bra 0x06019008 ; mov.b @(r0,r1),r1
L_06019004:
    c.r[2] = ld32(0x06019028u);  // 06019004 mov.l 0x06019028,r2
    c.r[1] = c.r[0];  // 06019006 mov r0,r1
L_06019008:
    c.r[1] -= 1;  // 06019008 add #-1,r1
    st8(c.r[2], c.r[1]);  // 0601900A mov.b r1,@r2
    c.r[2] = ld32(0x0601902Cu);  // 0601900C mov.l 0x0601902C,r2
    c.r[1] = 0x10u;  // 0601900E mov #16,r1
    st16(c.r[2], c.r[1]);  // 06019010 mov.w r1,@r2
L_06019012:
    c.r[15] = c.r[14];  // 06019012 mov r14,r15
    c.r[0] = ld32(0x06019030u);  // 06019014 mov.l 0x06019030,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06019016 rts ; mov.l @r15+,r14
}

void f_06019034(SH2Context& c) {
    ran[199] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06019034 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06019036 mov r15,r14
    c.r[2] = ld32(0x06019048u);  // 06019038 mov.l 0x06019048,r2
    c.r[1] = 0x1u;  // 0601903A mov #1,r1
    st16(c.r[2], c.r[1]);  // 0601903C mov.w r1,@r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06019044u);  // 0601903E mov.w 0x06019044,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06019040 rts ; mov.l @r15+,r14
}

void f_0601904C(SH2Context& c) {
    ran[200] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601904C mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0601904E mov r15,r14
    c.r[2] = ld32(0x06019074u);  // 06019050 mov.l 0x06019074,r2
    c.r[7] = c.r[2];  // 06019052 mov r2,r7
    c.r[7] += 2;  // 06019054 add #2,r7
    c.r[1] = ld32(0x06019078u);  // 06019056 mov.l 0x06019078,r1
    c.r[3] = ld32(c.r[1]);  // 06019058 mov.l @r1,r3
    c.r[2] += 3;  // 0601905A add #3,r2
    c.r[1] = c.r[3];  // 0601905C mov r3,r1
    c.r[1] += 1;  // 0601905E add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06019060 mov.b @r1,r1
    c.r[3] += 2;  // 06019062 add #2,r3
    st8(c.r[7], c.r[1]);  // 06019064 mov.b r1,@r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06019066 mov.b @r3,r1
    st8(c.r[2], c.r[1]);  // 06019068 mov.b r1,@r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06019070u);  // 0601906A mov.w 0x06019070,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601906C rts ; mov.l @r15+,r14
}

void f_0601907C(SH2Context& c) {
    ran[201] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601907C mov.l r14,@-r15
    c.r[1] = ld32(0x060190E8u);  // 0601907E mov.l 0x060190E8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06019080 mov.b @r1,r1
    c.r[3] = ld32(0x060190ECu);  // 06019082 mov.l 0x060190EC,r3
    c.r[0] = c.r[1];  // 06019084 mov r1,r0
    c.r[0] >>= 2;  // 06019086 shlr2 r0
    c.r[0] >>= 2;  // 06019088 shlr2 r0
    c.r[0] >>= 2;  // 0601908A shlr2 r0
    c.r[0] &= 0x1u;  // 0601908C and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601908E tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0601909A; } }  // 06019090 bt/s 0x0601909A ; mov r15,r14
    c.r[1] = ld32(0x060190F0u);  // 06019094 mov.l 0x060190F0,r1
    c.r[1] = ld32(c.r[1]); goto L_0601909E;  // 06019096 bra 0x0601909E ; mov.l @r1,r1
L_0601909A:
    c.r[1] = ld32(0x060190F4u);  // 0601909A mov.l 0x060190F4,r1
    c.r[1] = ld32(c.r[1]);  // 0601909C mov.l @r1,r1
L_0601909E:
    c.r[1] += 44;  // 0601909E add #44,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060190A0 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060190A2 extu.b r1,r1
    c.r[2] = c.r[1];  // 060190A4 mov r1,r2
    c.r[2] <<= 8;  // 060190A6 shll8 r2
    c.r[1] = ld32(0x060190E8u);  // 060190A8 mov.l 0x060190E8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060190AA mov.b @r1,r1
    c.r[0] = c.r[1];  // 060190AC mov r1,r0
    c.r[0] >>= 2;  // 060190AE shlr2 r0
    c.r[0] >>= 2;  // 060190B0 shlr2 r0
    c.r[0] >>= 2;  // 060190B2 shlr2 r0
    c.r[0] &= 0x1u;  // 060190B4 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060190B6 tst r0,r0
    if (c.t) { goto L_060190C0; }  // 060190B8 bt 0x060190C0
    c.r[1] = ld32(0x060190F0u);  // 060190BA mov.l 0x060190F0,r1
    c.r[1] = ld32(c.r[1]); goto L_060190C4;  // 060190BC bra 0x060190C4 ; mov.l @r1,r1
L_060190C0:
    c.r[1] = ld32(0x060190F4u);  // 060190C0 mov.l 0x060190F4,r1
    c.r[1] = ld32(c.r[1]);  // 060190C2 mov.l @r1,r1
L_060190C4:
    c.r[1] += 45;  // 060190C4 add #45,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060190C6 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060190C8 extu.b r1,r1
    c.r[2] |= c.r[1];  // 060190CA or r1,r2
    st16(c.r[3], c.r[2]);  // 060190CC mov.w r2,@r3
    c.r[1] = ld32(0x060190ECu);  // 060190CE mov.l 0x060190EC,r1
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060190D0 mov.w @r1,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 060190D2 cmp/eq #-1,r0
    { const bool k = c.t; c.r[15] = c.r[14]; if (k) { goto L_060190DE; } }  // 060190D4 bt/s 0x060190DE ; mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x060190E4u);  // 060190D8 mov.w 0x060190E4,r0
    goto L_060190E0;  // 060190DA bra 0x060190E0 ; nop
L_060190DE:
    c.r[0] = (uint32_t)(int16_t)ld16(0x060190E6u);  // 060190DE mov.w 0x060190E6,r0
L_060190E0:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060190E0 rts ; mov.l @r15+,r14
}

void f_060190F8(SH2Context& c) {
    ran[202] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060190F8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060190FA sts.l pr,@-r15
    c.r[1] = ld32(0x06019118u);  // 060190FC mov.l 0x06019118,r1
    c.r[1] = ld32(c.r[1]);  // 060190FE mov.l @r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06019100 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06019102 extu.b r1,r0
    c.r[0] <<= 2;  // 06019104 shll2 r0
    c.r[1] = ld32(0x0601911Cu);  // 06019106 mov.l 0x0601911C,r1
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 06019108 mov.l @(r0,r1),r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601910Eu; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601910Eu) return; }  // 0601910A jsr @r0 ; mov r15,r14
    c.r[15] = c.r[14];  // 0601910E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06019110 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06019112 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[0] & 0xFFFFu; c.pc = x; return; }  // 06019114 rts ; extu.w r0,r0
}

void f_06019120(SH2Context& c) {
    ran[203] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06019120 mov.l r14,@-r15
    c.r[1] = ld32(0x06019144u);  // 06019122 mov.l 0x06019144,r1
    c.r[1] = ld32(c.r[1]);  // 06019124 mov.l @r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06019126 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06019128 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601912A tst r1,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06019136; } }  // 0601912C bt/s 0x06019136 ; mov r15,r14
    c.r[2] = ld32(0x06019148u);  // 06019130 mov.l 0x06019148,r2
    c.r[1] = 0x1u; goto L_0601913A;  // 06019132 bra 0x0601913A ; mov #1,r1
L_06019136:
    c.r[2] = ld32(0x06019148u);  // 06019136 mov.l 0x06019148,r2
    c.r[1] = 0x0u;  // 06019138 mov #0,r1
L_0601913A:
    st16(c.r[2], c.r[1]);  // 0601913A mov.w r1,@r2
    c.r[15] = c.r[14];  // 0601913C mov r14,r15
    c.r[0] = ld32(0x0601914Cu);  // 0601913E mov.l 0x0601914C,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06019140 rts ; mov.l @r15+,r14
}

void f_06019150(SH2Context& c) {
    ran[204] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06019150 mov.l r14,@-r15
    c.r[2] = ld32(0x0601916Cu);  // 06019152 mov.l 0x0601916C,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06019154 mov.w @r2,r1
    c.r[0] = c.r[1] & 0xFFFFu;  // 06019156 extu.w r1,r0
    c.t = c.r[0] == 0x20u;  // 06019158 cmp/eq #32,r0
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_06019162; } }  // 0601915A bf/s 0x06019162 ; mov r15,r14
    c.r[1] = 0x1u;  // 0601915E mov #1,r1
    st16(c.r[2], c.r[1]);  // 06019160 mov.w r1,@r2
L_06019162:
    c.r[15] = c.r[14];  // 06019162 mov r14,r15
    c.r[0] = ld32(0x06019170u);  // 06019164 mov.l 0x06019170,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06019166 rts ; mov.l @r15+,r14
}

void f_06019174(SH2Context& c) {
    ran[205] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06019174 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06019176 sts.l pr,@-r15
    c.r[3] = ld32(0x060191C4u);  // 06019178 mov.l 0x060191C4,r3
    c.r[7] = c.r[3];  // 0601917A mov r3,r7
    c.r[7] += 66;  // 0601917C add #66,r7
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[7]);  // 0601917E mov.w @r7,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06019180 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06019182 tst r1,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0601918C; } }  // 06019184 bt/s 0x0601918C ; mov r15,r14
    c.r[0] = 0x0u; goto L_060191BC;  // 06019188 bra 0x060191BC ; mov #0,r0
L_0601918C:
    c.r[1] = ld32(0x060191C8u);  // 0601918C mov.l 0x060191C8,r1
    c.r[1] = ld32(c.r[1]);  // 0601918E mov.l @r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06019190 tst r1,r1
    { const bool k = c.t; c.r[2] = c.r[3]; if (k) { goto L_060191AA; } }  // 06019192 bt/s 0x060191AA ; mov r3,r2
    c.r[2] += 68;  // 06019196 add #68,r2
    c.r[1] = 0x0u;  // 06019198 mov #0,r1
    st16(c.r[2], c.r[1]);  // 0601919A mov.w r1,@r2
    c.r[3] += 72;  // 0601919C add #72,r3
    c.r[1] = ld32(0x060191CCu);  // 0601919E mov.l 0x060191CC,r1
    st32(c.r[3], c.r[1]);  // 060191A0 mov.l r1,@r3
    c.r[1] = 0x2u;  // 060191A2 mov #2,r1
    c.r[0] = ld32(0x060191D0u);  // 060191A4 mov.l 0x060191D0,r0
    st16(c.r[7], c.r[1]); goto L_060191BC;  // 060191A6 bra 0x060191BC ; mov.w r1,@r7
L_060191AA:
    c.r[0] = ld32(0x060191D4u);  // 060191AA mov.l 0x060191D4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060191B0u; c.r[4] = 0xFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060191B0u) return; }  // 060191AC jsr @r0 ; mov #15,r4
    c.r[2] = ld32(0x060191D8u);  // 060191B0 mov.l 0x060191D8,r2
    c.r[1] = ld32(0x060191DCu);  // 060191B2 mov.l 0x060191DC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060191B4 mov.b @r1,r1
    c.r[0] = ld32(0x060191E0u);  // 060191B6 mov.l 0x060191E0,r0
    c.r[1] = c.r[1] & 0xFFu;  // 060191B8 extu.b r1,r1
    st16(c.r[2], c.r[1]);  // 060191BA mov.w r1,@r2
L_060191BC:
    c.r[15] = c.r[14];  // 060191BC mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060191BE lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060191C0 rts ; mov.l @r15+,r14
}

void f_060191E4(SH2Context& c) {
    ran[206] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060191E4 mov.l r14,@-r15
    c.r[2] = ld32(0x06019208u);  // 060191E6 mov.l 0x06019208,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 060191E8 mov.w @r2,r1
    c.r[0] = c.r[1] & 0xFFFFu;  // 060191EA extu.w r1,r0
    c.t = c.r[0] == 0x2u;  // 060191EC cmp/eq #2,r0
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_060191F6; } }  // 060191EE bf/s 0x060191F6 ; mov r15,r14
    c.r[0] = 0x0u; goto L_06019200;  // 060191F2 bra 0x06019200 ; mov #0,r0
L_060191F6:
    c.t = c.r[0] == 0x8u;  // 060191F6 cmp/eq #8,r0
    { const bool k = !c.t; c.r[1] = 0x10u; if (k) { goto L_060191FE; } }  // 060191F8 bf/s 0x060191FE ; mov #16,r1
    st16(c.r[2], c.r[1]);  // 060191FC mov.w r1,@r2
L_060191FE:
    c.r[0] = ld32(0x0601920Cu);  // 060191FE mov.l 0x0601920C,r0
L_06019200:
    c.r[15] = c.r[14];  // 06019200 mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06019202 rts ; mov.l @r15+,r14
}

void f_06019210(SH2Context& c) {
    ran[207] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06019210 mov.l r14,@-r15
    c.r[3] = ld32(0x06019238u);  // 06019212 mov.l 0x06019238,r3
    c.r[1] = ld32(c.r[3]);  // 06019214 mov.l @r3,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06019216 tst r1,r1
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_06019224; } }  // 06019218 bf/s 0x06019224 ; mov r15,r14
    c.r[2] = c.r[3];  // 0601921C mov r3,r2
    c.r[2] += 66;  // 0601921E add #66,r2
    c.r[1] = 0x0u;  // 06019220 mov #0,r1
    st16(c.r[2], c.r[1]);  // 06019222 mov.w r1,@r2
L_06019224:
    c.r[3] += 66;  // 06019224 add #66,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06019226 mov.w @r3,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06019228 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601922A tst r1,r1
    { const bool k = !c.t; c.r[0] = 0x0u; if (k) { goto L_06019232; } }  // 0601922C bf/s 0x06019232 ; mov #0,r0
    c.r[0] = ld32(0x0601923Cu);  // 06019230 mov.l 0x0601923C,r0
L_06019232:
    c.r[15] = c.r[14];  // 06019232 mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06019234 rts ; mov.l @r15+,r14
}

void f_06019240(SH2Context& c) {
    ran[208] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06019240 mov.l r14,@-r15
    c.r[3] = ld32(0x060192B8u);  // 06019242 mov.l 0x060192B8,r3
    c.r[7] = c.r[3];  // 06019244 mov r3,r7
    c.r[7] += 66;  // 06019246 add #66,r7
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[7]);  // 06019248 mov.w @r7,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0601924A extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601924C tst r1,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06019256; } }  // 0601924E bt/s 0x06019256 ; mov r15,r14
    c.r[0] = 0x0u; goto L_060192AC;  // 06019252 bra 0x060192AC ; mov #0,r0
L_06019256:
    c.r[2] = c.r[3];  // 06019256 mov r3,r2
    c.r[2] += 68;  // 06019258 add #68,r2
    c.r[1] = 0x1u;  // 0601925A mov #1,r1
    st16(c.r[2], c.r[1]);  // 0601925C mov.w r1,@r2
    c.r[1] = 0x2u;  // 0601925E mov #2,r1
    st16(c.r[7], c.r[1]);  // 06019260 mov.w r1,@r7
    c.r[5] = c.r[3];  // 06019262 mov r3,r5
    c.r[1] = ld32(0x060192BCu);  // 06019264 mov.l 0x060192BC,r1
    c.r[1] = ld32(c.r[1]);  // 06019266 mov.l @r1,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 06019268 mov.b @r1+,r6
    c.r[3] = (uint32_t)(int16_t)ld16(0x060192B2u);  // 0601926A mov.w 0x060192B2,r3
    c.r[2] = c.r[6] & 0xFFu;  // 0601926C extu.b r6,r2
    c.t = c.r[2] == c.r[3];  // 0601926E cmp/eq r3,r2
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06019270 mov.b @r1,r7
    c.r[2] = c.t;  // 06019272 movt r2
    c.r[1] = c.r[7] & 0xFFu;  // 06019274 extu.b r7,r1
    c.t = c.r[1] == c.r[3];  // 06019276 cmp/eq r3,r1
    c.r[1] = c.t;  // 06019278 movt r1
    c.r[2] &= c.r[1];  // 0601927A and r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0601927C tst r2,r2
    { const bool k = c.t; c.r[5] += 70; if (k) { goto L_06019298; } }  // 0601927E bt/s 0x06019298 ; add #70,r5
    c.r[3] = ld32(0x060192C0u);  // 06019282 mov.l 0x060192C0,r3
    c.r[1] = c.r[3];  // 06019284 mov r3,r1
    c.r[1] += 22;  // 06019286 add #22,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06019288 mov.w @r1,r2
    c.r[3] += 24;  // 0601928A add #24,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0601928C mov.w @r3,r1
    c.r[2] <<= 2;  // 0601928E shll2 r2
    c.r[2] <<= 2;  // 06019290 shll2 r2
    c.r[2] += c.r[2];  // 06019292 add r2,r2
    c.r[2] <<= 2; goto L_060192A4;  // 06019294 bra 0x060192A4 ; shll2 r2
L_06019298:
    c.r[2] = c.r[6] & 0xFFu;  // 06019298 extu.b r6,r2
    c.r[2] <<= 2;  // 0601929A shll2 r2
    c.r[2] <<= 2;  // 0601929C shll2 r2
    c.r[2] += c.r[2];  // 0601929E add r2,r2
    c.r[2] <<= 2;  // 060192A0 shll2 r2
    c.r[1] = c.r[7] & 0xFFu;  // 060192A2 extu.b r7,r1
L_060192A4:
    c.r[1] -= 1;  // 060192A4 add #-1,r1
    c.r[2] |= c.r[1];  // 060192A6 or r1,r2
    st16(c.r[5], c.r[2]);  // 060192A8 mov.w r2,@r5
    c.r[0] = (uint32_t)(int16_t)ld16(0x060192B4u);  // 060192AA mov.w 0x060192B4,r0
L_060192AC:
    c.r[15] = c.r[14];  // 060192AC mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060192AE rts ; mov.l @r15+,r14
}

void f_060192C4(SH2Context& c) {
    ran[209] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060192C4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060192C6 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060192C8 sts.l pr,@-r15
    c.r[1] = ld32(0x06019388u);  // 060192CA mov.l 0x06019388,r1
    c.r[1] = ld32(c.r[1]);  // 060192CC mov.l @r1,r1
    c.r[14] = c.r[15];  // 060192CE mov r15,r14
    c.r[1] += 1;  // 060192D0 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060192D2 mov.b @r1,r1
    c.r[4] = ld32(0x0601938Cu);  // 060192D4 mov.l 0x0601938C,r4
    c.r[0] = c.r[1] & 0xFFu;  // 060192D6 extu.b r1,r0
    c.r[0] += c.r[0];  // 060192D8 add r0,r0
    c.r[1] = ld32(0x06019390u);  // 060192DA mov.l 0x06019390,r1
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 060192DC mov.w @(r0,r1),r8
    c.r[0] = ld32(0x06019394u);  // 060192DE mov.l 0x06019394,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060192E4u; c.r[5] = 0x7u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060192E4u) return; }  // 060192E0 jsr @r0 ; mov #7,r5
    c.r[5] = c.r[0];  // 060192E4 mov r0,r5
    c.r[2] = c.r[8];  // 060192E6 mov r8,r2
    c.r[2] += 4;  // 060192E8 add #4,r2
    c.r[1] = ld32(0x06019398u);  // 060192EA mov.l 0x06019398,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060192EC mov.b @r1,r1
    c.r[2] += c.r[2];  // 060192EE add r2,r2
    c.r[0] = c.r[1];  // 060192F0 mov r1,r0
    c.r[0] >>= 2;  // 060192F2 shlr2 r0
    c.r[0] >>= 2;  // 060192F4 shlr2 r0
    c.r[0] >>= 2;  // 060192F6 shlr2 r0
    c.r[0] &= 0x1u;  // 060192F8 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060192FA tst r0,r0
    if (c.t) { goto L_06019304; }  // 060192FC bt 0x06019304
    c.r[1] = ld32(0x0601939Cu);  // 060192FE mov.l 0x0601939C,r1
    c.r[1] = ld32(c.r[1]); goto L_06019308;  // 06019300 bra 0x06019308 ; mov.l @r1,r1
L_06019304:
    c.r[1] = ld32(0x060193A0u);  // 06019304 mov.l 0x060193A0,r1
    c.r[1] = ld32(c.r[1]);  // 06019306 mov.l @r1,r1
L_06019308:
    c.r[1] += c.r[2];  // 06019308 add r2,r1
    c.r[2] = c.r[8];  // 0601930A mov r8,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601930C mov.b @r1,r1
    c.r[2] += 4;  // 0601930E add #4,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06019310 extu.b r1,r1
    c.r[3] = c.r[1];  // 06019312 mov r1,r3
    c.r[3] <<= 8;  // 06019314 shll8 r3
    c.r[1] = ld32(0x06019398u);  // 06019316 mov.l 0x06019398,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06019318 mov.b @r1,r1
    c.r[2] += c.r[2];  // 0601931A add r2,r2
    c.r[0] = c.r[1];  // 0601931C mov r1,r0
    c.r[0] >>= 2;  // 0601931E shlr2 r0
    c.r[0] >>= 2;  // 06019320 shlr2 r0
    c.r[0] >>= 2;  // 06019322 shlr2 r0
    c.r[0] &= 0x1u;  // 06019324 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06019326 tst r0,r0
    if (c.t) { goto L_06019330; }  // 06019328 bt 0x06019330
    c.r[1] = ld32(0x0601939Cu);  // 0601932A mov.l 0x0601939C,r1
    c.r[1] = ld32(c.r[1]); goto L_06019334;  // 0601932C bra 0x06019334 ; mov.l @r1,r1
L_06019330:
    c.r[1] = ld32(0x060193A0u);  // 06019330 mov.l 0x060193A0,r1
    c.r[1] = ld32(c.r[1]);  // 06019332 mov.l @r1,r1
L_06019334:
    c.r[2] += 1;  // 06019334 add #1,r2
    c.r[1] += c.r[2];  // 06019336 add r2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06019338 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601933A extu.b r1,r1
    c.r[1] |= c.r[3];  // 0601933C or r3,r1
    c.r[7] = c.r[1];  // 0601933E mov r1,r7
    c.r[1] = ld32(0x060193A4u);  // 06019340 mov.l 0x060193A4,r1
    c.t = c.r[7] == c.r[1];  // 06019342 cmp/eq r1,r7
    { const bool k = !c.t; c.r[0] = c.r[8]; if (k) { goto L_0601935A; } }  // 06019344 bf/s 0x0601935A ; mov r8,r0
    c.r[0] += c.r[0];  // 06019348 add r0,r0
    c.r[1] = ld32(0x060193A8u);  // 0601934A mov.l 0x060193A8,r1
    c.r[2] = c.r[1];  // 0601934C mov r1,r2
    c.r[2] -= 2;  // 0601934E add #-2,r2
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 06019350 mov.w @(r0,r2),r2
    st16(c.r[0] + c.r[1], c.r[2]);  // 06019352 mov.w r2,@(r0,r1)
    c.r[0] = (uint32_t)(int16_t)ld16(0x06019380u);  // 06019354 mov.w 0x06019380,r0
    c.r[15] = c.r[14]; goto L_06019378;  // 06019356 bra 0x06019378 ; mov r14,r15
L_0601935A:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06019382u);  // 0601935A mov.w 0x06019382,r1
    c.r[7] &= c.r[1];  // 0601935C and r1,r7
    c.r[1] = ld32(0x060193ACu);  // 0601935E mov.l 0x060193AC,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06019360 mov.l r1,@-r15
    c.r[0] = ld32(0x060193B0u);  // 06019362 mov.l 0x060193B0,r0
    c.r[6] = 0x2u;  // 06019364 mov #2,r6
    { const uint32_t x = c.r[0]; c.pr = 0x0601936Au; c.r[4] = 0x9u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601936Au) return; }  // 06019366 jsr @r0 ; mov #9,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601936A tst r0,r0
    { const bool k = !c.t; c.r[15] = c.r[14]; if (k) { goto L_06019376; } }  // 0601936C bf/s 0x06019376 ; mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x06019384u);  // 06019370 mov.w 0x06019384,r0
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; } goto L_0601937A;  // 06019372 bra 0x0601937A ; lds.l @r15+,pr
L_06019376:
    c.r[0] = 0x0u;  // 06019376 mov #0,r0
L_06019378:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06019378 lds.l @r15+,pr
L_0601937A:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601937A mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601937C rts ; mov.l @r15+,r8
}

void f_060193B4(SH2Context& c) {
    ran[210] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060193B4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060193B6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060193B8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060193BA mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060193BC sts.l pr,@-r15
    c.r[15] -= 12;  // 060193BE add #-12,r15
    c.r[14] = c.r[15];  // 060193C0 mov r15,r14
    c.r[3] = 0x0u;  // 060193C2 mov #0,r3
    st8(c.r[14], c.r[3]);  // 060193C4 mov.b r3,@r14
    c.r[2] = c.r[14];  // 060193C6 mov r14,r2
    c.r[2] += 1;  // 060193C8 add #1,r2
    c.r[1] = 0x1u;  // 060193CA mov #1,r1
    st8(c.r[2], c.r[1]);  // 060193CC mov.b r1,@r2
    c.r[2] = c.r[14];  // 060193CE mov r14,r2
    c.r[2] += 2;  // 060193D0 add #2,r2
    c.r[1] = 0x2u;  // 060193D2 mov #2,r1
    st8(c.r[2], c.r[1]);  // 060193D4 mov.b r1,@r2
    c.r[1] = c.r[14];  // 060193D6 mov r14,r1
    c.r[1] += 3;  // 060193D8 add #3,r1
    st8(c.r[1], c.r[3]);  // 060193DA mov.b r3,@r1
    c.r[2] = c.r[14];  // 060193DC mov r14,r2
    c.r[2] += 4;  // 060193DE add #4,r2
    c.r[1] = 0x3u;  // 060193E0 mov #3,r1
    st8(c.r[2], c.r[1]);  // 060193E2 mov.b r1,@r2
    c.r[1] = c.r[14];  // 060193E4 mov r14,r1
    c.r[1] += 5;  // 060193E6 add #5,r1
    st8(c.r[1], c.r[3]);  // 060193E8 mov.b r3,@r1
    c.r[1] = c.r[14];  // 060193EA mov r14,r1
    c.r[1] += 6;  // 060193EC add #6,r1
    st8(c.r[1], c.r[3]);  // 060193EE mov.b r3,@r1
    c.r[1] = c.r[14];  // 060193F0 mov r14,r1
    c.r[1] += 7;  // 060193F2 add #7,r1
    st8(c.r[1], c.r[3]);  // 060193F4 mov.b r3,@r1
    c.r[2] = c.r[14];  // 060193F6 mov r14,r2
    c.r[2] += 8;  // 060193F8 add #8,r2
    c.r[1] = 0x4u;  // 060193FA mov #4,r1
    st8(c.r[2], c.r[1]);  // 060193FC mov.b r1,@r2
    c.r[9] = ld32(0x06019514u);  // 060193FE mov.l 0x06019514,r9
    c.r[1] = ld32(c.r[9]);  // 06019400 mov.l @r9,r1
    c.r[8] = ld32(0x06019518u);  // 06019402 mov.l 0x06019518,r8
    c.r[1] += 1;  // 06019404 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06019406 mov.b @r1,r1
    c.r[4] = ld32(0x0601951Cu);  // 06019408 mov.l 0x0601951C,r4
    c.r[0] = c.r[1] & 0xFFu;  // 0601940A extu.b r1,r0
    c.r[0] += c.r[0];  // 0601940C add r0,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[8]);  // 0601940E mov.w @(r0,r8),r1
    c.r[5] = 0x8u;  // 06019410 mov #8,r5
    c.r[0] = ld32(0x06019520u);  // 06019412 mov.l 0x06019520,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06019418u; c.r[10] = c.r[1] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06019418u) return; }  // 06019414 jsr @r0 ; extu.w r1,r10
    c.r[1] = ld32(c.r[9]);  // 06019418 mov.l @r9,r1
    c.r[1] += 1;  // 0601941A add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601941C mov.b @r1,r1
    c.r[5] = c.r[0];  // 0601941E mov r0,r5
    c.r[0] = c.r[1] & 0xFFu;  // 06019420 extu.b r1,r0
    c.r[0] += c.r[0];  // 06019422 add r0,r0
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[8]);  // 06019424 mov.w @(r0,r8),r2
    c.r[1] = ld32(0x06019524u);  // 06019426 mov.l 0x06019524,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06019428 mov.b @r1,r1
    c.r[2] += 10;  // 0601942A add #10,r2
    c.r[2] += c.r[2];  // 0601942C add r2,r2
    c.r[0] = c.r[1];  // 0601942E mov r1,r0
    c.r[0] >>= 2;  // 06019430 shlr2 r0
    c.r[0] >>= 2;  // 06019432 shlr2 r0
    c.r[0] >>= 2;  // 06019434 shlr2 r0
    c.r[0] &= 0x1u;  // 06019436 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06019438 tst r0,r0
    if (c.t) { goto L_06019442; }  // 0601943A bt 0x06019442
    c.r[1] = ld32(0x06019528u);  // 0601943C mov.l 0x06019528,r1
    c.r[1] = ld32(c.r[1]); goto L_06019446;  // 0601943E bra 0x06019446 ; mov.l @r1,r1
L_06019442:
    c.r[1] = ld32(0x0601952Cu);  // 06019442 mov.l 0x0601952C,r1
    c.r[1] = ld32(c.r[1]);  // 06019444 mov.l @r1,r1
L_06019446:
    c.r[1] += c.r[2];  // 06019446 add r2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06019448 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601944A extu.b r1,r1
    c.r[7] = c.r[1];  // 0601944C mov r1,r7
    c.r[7] <<= 8;  // 0601944E shll8 r7
    c.r[1] = ld32(0x06019514u);  // 06019450 mov.l 0x06019514,r1
    c.r[1] = ld32(c.r[1]);  // 06019452 mov.l @r1,r1
    c.r[1] += 1;  // 06019454 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06019456 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06019458 extu.b r1,r0
    c.r[0] += c.r[0];  // 0601945A add r0,r0
    c.r[1] = ld32(0x06019518u);  // 0601945C mov.l 0x06019518,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0601945E mov.w @(r0,r1),r2
    c.r[2] += 10;  // 06019460 add #10,r2
    c.r[1] = ld32(0x06019524u);  // 06019462 mov.l 0x06019524,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06019464 mov.b @r1,r1
    c.r[2] += c.r[2];  // 06019466 add r2,r2
    c.r[0] = c.r[1];  // 06019468 mov r1,r0
    c.r[0] >>= 2;  // 0601946A shlr2 r0
    c.r[0] >>= 2;  // 0601946C shlr2 r0
    c.r[0] >>= 2;  // 0601946E shlr2 r0
    c.r[0] &= 0x1u;  // 06019470 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06019472 tst r0,r0
    if (c.t) { goto L_0601947C; }  // 06019474 bt 0x0601947C
    c.r[1] = ld32(0x06019528u);  // 06019476 mov.l 0x06019528,r1
    c.r[1] = ld32(c.r[1]); goto L_06019480;  // 06019478 bra 0x06019480 ; mov.l @r1,r1
L_0601947C:
    c.r[1] = ld32(0x0601952Cu);  // 0601947C mov.l 0x0601952C,r1
    c.r[1] = ld32(c.r[1]);  // 0601947E mov.l @r1,r1
L_06019480:
    c.r[2] += 1;  // 06019480 add #1,r2
    c.r[1] += c.r[2];  // 06019482 add r2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06019484 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06019486 extu.b r1,r1
    c.r[7] |= c.r[1];  // 06019488 or r1,r7
    c.r[1] = ld32(0x06019530u);  // 0601948A mov.l 0x06019530,r1
    c.t = c.r[7] == c.r[1];  // 0601948C cmp/eq r1,r7
    { const bool k = !c.t; c.r[0] = c.r[10]; if (k) { goto L_060194A4; } }  // 0601948E bf/s 0x060194A4 ; mov r10,r0
    c.r[0] += c.r[0];  // 06019492 add r0,r0
    c.r[1] = ld32(0x06019534u);  // 06019494 mov.l 0x06019534,r1
    c.r[2] = c.r[1];  // 06019496 mov r1,r2
    c.r[2] -= 2;  // 06019498 add #-2,r2
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 0601949A mov.w @(r0,r2),r2
    st16(c.r[0] + c.r[1], c.r[2]);  // 0601949C mov.w r2,@(r0,r1)
L_0601949E:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06019508u);  // 0601949E mov.w 0x06019508,r0
    c.r[14] += 12; goto L_060194FA;  // 060194A0 bra 0x060194FA ; add #12,r14
L_060194A4:
    c.r[1] = ld32(0x06019538u);  // 060194A4 mov.l 0x06019538,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060194A6 mov.w @r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0601950Au);  // 060194A8 mov.w 0x0601950A,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 060194AA extu.w r1,r1
    c.t = c.r[1] > c.r[2];  // 060194AC cmp/hi r2,r1
    if (c.t) { SH2_POLL(c); goto L_0601949E; }  // 060194AE bt 0x0601949E
    c.r[1] = ld32(0x0601953Cu);  // 060194B0 mov.l 0x0601953C,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060194B2 mov.w @r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0601950Cu);  // 060194B4 mov.w 0x0601950C,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 060194B6 extu.w r1,r1
    c.t = c.r[1] > c.r[2];  // 060194B8 cmp/hi r2,r1
    { const bool k = c.t; c.r[1] = 0xCu; if (k) { SH2_POLL(c); goto L_0601949E; } }  // 060194BA bt/s 0x0601949E ; mov #12,r1
    c.r[2] = ld32(0x06019540u);  // 060194BE mov.l 0x06019540,r2
    c.r[0] = 0x7u;  // 060194C0 mov #7,r0
    c.r[6] = 0x3u;  // 060194C2 mov #3,r6
    c.macl = (c.r[10] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 060194C4 mulu.w r1,r10
    c.r[4] = 0xAu;  // 060194C6 mov #10,r4
    c.r[1] = c.r[7];  // 060194C8 mov r7,r1
    c.r[1] >>= 8;  // 060194CA shlr8 r1
    c.r[1] >>= 2;  // 060194CC shlr2 r1
    c.r[1] >>= 2;  // 060194CE shlr2 r1
    c.r[1] &= c.r[0];  // 060194D0 and r0,r1
    c.r[0] = c.r[14];  // 060194D2 mov r14,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060194D4 mov.b @(r0,r1),r1
    c.r[3] = c.macl;  // 060194D6 sts macl,r3
    c.r[1] = c.r[1] & 0xFFu;  // 060194D8 extu.b r1,r1
    c.r[0] = c.r[3];  // 060194DA mov r3,r0
    st16(c.r[0] + c.r[2], c.r[1]);  // 060194DC mov.w r1,@(r0,r2)
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601950Eu);  // 060194DE mov.w 0x0601950E,r1
    c.r[7] &= c.r[1];  // 060194E0 and r1,r7
    c.r[1] = ld32(0x06019544u);  // 060194E2 mov.l 0x06019544,r1
    c.r[0] = ld32(0x06019548u);  // 060194E4 mov.l 0x06019548,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060194EAu; c.r[15] -= 4; st32(c.r[15], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060194EAu) return; }  // 060194E6 jsr @r0 ; mov.l r1,@-r15
    c.r[1] = c.r[0];  // 060194EA mov r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060194EC tst r1,r1
    { const bool k = !c.t; c.r[14] += 12; if (k) { goto L_060194F8; } }  // 060194EE bf/s 0x060194F8 ; add #12,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x06019510u);  // 060194F2 mov.w 0x06019510,r0
    c.r[15] = c.r[14]; goto L_060194FC;  // 060194F4 bra 0x060194FC ; mov r14,r15
L_060194F8:
    c.r[0] = 0x0u;  // 060194F8 mov #0,r0
L_060194FA:
    c.r[15] = c.r[14];  // 060194FA mov r14,r15
L_060194FC:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060194FC lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060194FE mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06019500 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06019502 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06019504 rts ; mov.l @r15+,r8
}

void f_0601954C(SH2Context& c) {
    ran[211] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601954C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0601954E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06019550 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06019552 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06019554 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06019556 sts.l pr,@-r15
    c.r[15] -= 24;  // 06019558 add #-24,r15
    c.r[14] = c.r[15];  // 0601955A mov r15,r14
    c.r[1] = c.r[14];  // 0601955C mov r14,r1
    c.r[1] += 8;  // 0601955E add #8,r1
    c.r[2] = ld32(0x06019750u);  // 06019560 mov.l 0x06019750,r2
    st32(c.r[14] + 8, c.r[2]);  // 06019562 mov.l r2,@(8,r14)
    c.r[9] = ld32(0x06019754u);  // 06019564 mov.l 0x06019754,r9
    st32(c.r[1] + 4, c.r[9]);  // 06019566 mov.l r9,@(4,r1)
    c.r[10] = ld32(0x06019758u);  // 06019568 mov.l 0x06019758,r10
    st32(c.r[1] + 8, c.r[10]);  // 0601956A mov.l r10,@(8,r1)
    c.r[11] = ld32(0x0601975Cu);  // 0601956C mov.l 0x0601975C,r11
    st32(c.r[1] + 12, c.r[11]);  // 0601956E mov.l r11,@(12,r1)
    c.r[1] = ld32(0x06019760u);  // 06019570 mov.l 0x06019760,r1
    c.r[1] = ld32(c.r[1]);  // 06019572 mov.l @r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06019574 tst r1,r1
    if (!c.t) { goto L_0601966C; }  // 06019576 bf 0x0601966C
    c.r[2] = c.r[14];  // 06019578 mov r14,r2
    c.r[1] = ld32(0x06019764u);  // 0601957A mov.l 0x06019764,r1
    c.r[2] += 2;  // 0601957C add #2,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0601957E mov.w @r1,r1
    c.r[8] = 0x0u;  // 06019580 mov #0,r8
    st16(c.r[14], c.r[1]);  // 06019582 mov.w r1,@r14
    c.r[1] = ld32(0x06019768u);  // 06019584 mov.l 0x06019768,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06019586 mov.w @r1,r1
    c.r[9] = c.r[14];  // 06019588 mov r14,r9
    st16(c.r[2], c.r[1]);  // 0601958A mov.w r1,@r2
    c.r[2] = c.r[14];  // 0601958C mov r14,r2
    c.r[1] = ld32(0x0601976Cu);  // 0601958E mov.l 0x0601976C,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06019590 mov.w @r1,r1
    c.r[2] += 4;  // 06019592 add #4,r2
    st16(c.r[2], c.r[1]);  // 06019594 mov.w r1,@r2
    c.r[2] = c.r[14];  // 06019596 mov r14,r2
    c.r[1] = ld32(0x06019770u);  // 06019598 mov.l 0x06019770,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0601959A mov.w @r1,r1
    c.r[2] += 6;  // 0601959C add #6,r2
    st16(c.r[2], c.r[1]);  // 0601959E mov.w r1,@r2
L_060195A0:
    c.r[7] = c.r[8];  // 060195A0 mov r8,r7
    c.r[7] += 1;  // 060195A2 add #1,r7
    c.r[1] = 0x3u;  // 060195A4 mov #3,r1
    c.t = (int32_t)c.r[7] > (int32_t)c.r[1];  // 060195A6 cmp/gt r1,r7
    if (c.t) { goto L_060195E6; }  // 060195A8 bt 0x060195E6
    c.r[4] = c.r[8];  // 060195AA mov r8,r4
    c.r[4] += c.r[4];  // 060195AC add r4,r4
    c.r[5] = c.r[9];  // 060195AE mov r9,r5
    c.r[10] = c.r[1];  // 060195B0 mov r1,r10
    c.r[6] = c.r[7];  // 060195B2 mov r7,r6
    c.r[6] <<= 2;  // 060195B4 shll2 r6
    c.r[6] += c.r[14];  // 060195B6 add r14,r6
    c.r[11] = c.r[7];  // 060195B8 mov r7,r11
    c.r[11] += c.r[11];  // 060195BA add r11,r11
L_060195BC:
    c.r[0] = c.r[4];  // 060195BC mov r4,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[14]);  // 060195BE mov.w @(r0,r14),r1
    c.r[0] = c.r[11];  // 060195C0 mov r11,r0
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[14]);  // 060195C2 mov.w @(r0,r14),r2
    c.r[3] = c.r[1] & 0xFFFFu;  // 060195C4 extu.w r1,r3
    c.r[1] = c.r[2] & 0xFFFFu;  // 060195C6 extu.w r2,r1
    c.t = c.r[3] > c.r[1];  // 060195C8 cmp/hi r1,r3
    { const bool k = !c.t; c.r[0] = c.r[4]; if (k) { goto L_060195DC; } }  // 060195CA bf/s 0x060195DC ; mov r4,r0
    st16(c.r[0] + c.r[14], c.r[2]);  // 060195CE mov.w r2,@(r0,r14)
    c.r[0] = c.r[11];  // 060195D0 mov r11,r0
    st16(c.r[0] + c.r[14], c.r[3]);  // 060195D2 mov.w r3,@(r0,r14)
    c.r[1] = ld32(c.r[6] + 8);  // 060195D4 mov.l @(8,r6),r1
    c.r[2] = ld32(c.r[5] + 8);  // 060195D6 mov.l @(8,r5),r2
    st32(c.r[5] + 8, c.r[1]);  // 060195D8 mov.l r1,@(8,r5)
    st32(c.r[6] + 8, c.r[2]);  // 060195DA mov.l r2,@(8,r6)
L_060195DC:
    c.r[6] += 4;  // 060195DC add #4,r6
    c.r[7] += 1;  // 060195DE add #1,r7
    c.t = (int32_t)c.r[7] > (int32_t)c.r[10];  // 060195E0 cmp/gt r10,r7
    { const bool k = !c.t; c.r[11] += 2; if (k) { SH2_POLL(c); goto L_060195BC; } }  // 060195E2 bf/s 0x060195BC ; add #2,r11
L_060195E6:
    c.r[8] += 1;  // 060195E6 add #1,r8
    c.r[10] = 0x2u;  // 060195E8 mov #2,r10
    c.t = (int32_t)c.r[8] > (int32_t)c.r[10];  // 060195EA cmp/gt r10,r8
    { const bool k = !c.t; c.r[9] += 4; if (k) { SH2_POLL(c); goto L_060195A0; } }  // 060195EC bf/s 0x060195A0 ; add #4,r9
    c.r[4] = ld32(0x06019774u);  // 060195F0 mov.l 0x06019774,r4
    c.r[0] = ld32(0x06019778u);  // 060195F2 mov.l 0x06019778,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060195F8u; c.r[5] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060195F8u) return; }  // 060195F4 jsr @r0 ; mov #1,r5
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[14]);  // 060195F8 mov.w @r14,r1
    c.r[7] = c.r[1] & 0xFFFFu;  // 060195FA extu.w r1,r7
    c.t = (c.r[7] & c.r[7]) == 0;  // 060195FC tst r7,r7
    { const bool k = c.t; c.r[8] = c.r[0]; if (k) { goto L_06019612; } }  // 060195FE bt/s 0x06019612 ; mov r0,r8
    c.r[1] = ld32(c.r[14] + 8);  // 06019602 mov.l @(8,r14),r1
    c.r[0] = ld32(0x0601977Cu);  // 06019604 mov.l 0x0601977C,r0
    c.r[6] = c.r[10];  // 06019606 mov r10,r6
    c.r[5] = c.r[8];  // 06019608 mov r8,r5
    c.r[4] = 0x4u;  // 0601960A mov #4,r4
    { const uint32_t x = c.r[0]; c.pr = 0x06019610u; c.r[15] -= 4; st32(c.r[15], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06019610u) return; }  // 0601960C jsr @r0 ; mov.l r1,@-r15
    c.r[15] += 4;  // 06019610 add #4,r15
L_06019612:
    c.r[1] = c.r[14];  // 06019612 mov r14,r1
    c.r[1] += 2;  // 06019614 add #2,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06019616 mov.w @r1,r1
    c.r[7] = c.r[1] & 0xFFFFu;  // 06019618 extu.w r1,r7
    c.t = (c.r[7] & c.r[7]) == 0;  // 0601961A tst r7,r7
    { const bool k = c.t; c.r[1] = c.r[14]; if (k) { goto L_06019632; } }  // 0601961C bt/s 0x06019632 ; mov r14,r1
    c.r[1] = ld32(c.r[14] + 12);  // 06019620 mov.l @(12,r14),r1
    c.r[0] = ld32(0x0601977Cu);  // 06019622 mov.l 0x0601977C,r0
    c.r[6] = c.r[10];  // 06019624 mov r10,r6
    c.r[5] = c.r[8];  // 06019626 mov r8,r5
    c.r[4] = 0x4u;  // 06019628 mov #4,r4
    { const uint32_t x = c.r[0]; c.pr = 0x0601962Eu; c.r[15] -= 4; st32(c.r[15], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601962Eu) return; }  // 0601962A jsr @r0 ; mov.l r1,@-r15
    c.r[15] += 4;  // 0601962E add #4,r15
    c.r[1] = c.r[14];  // 06019630 mov r14,r1
L_06019632:
    c.r[1] += 4;  // 06019632 add #4,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06019634 mov.w @r1,r1
    c.r[7] = c.r[1] & 0xFFFFu;  // 06019636 extu.w r1,r7
    c.t = (c.r[7] & c.r[7]) == 0;  // 06019638 tst r7,r7
    { const bool k = c.t; c.r[1] = c.r[14]; if (k) { goto L_06019650; } }  // 0601963A bt/s 0x06019650 ; mov r14,r1
    c.r[1] = ld32(c.r[14] + 16);  // 0601963E mov.l @(16,r14),r1
    c.r[0] = ld32(0x0601977Cu);  // 06019640 mov.l 0x0601977C,r0
    c.r[6] = c.r[10];  // 06019642 mov r10,r6
    c.r[5] = c.r[8];  // 06019644 mov r8,r5
    c.r[4] = 0x4u;  // 06019646 mov #4,r4
    { const uint32_t x = c.r[0]; c.pr = 0x0601964Cu; c.r[15] -= 4; st32(c.r[15], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601964Cu) return; }  // 06019648 jsr @r0 ; mov.l r1,@-r15
    c.r[15] += 4;  // 0601964C add #4,r15
    c.r[1] = c.r[14];  // 0601964E mov r14,r1
L_06019650:
    c.r[1] += 6;  // 06019650 add #6,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06019652 mov.w @r1,r1
    c.r[7] = c.r[1] & 0xFFFFu;  // 06019654 extu.w r1,r7
    c.t = (c.r[7] & c.r[7]) == 0;  // 06019656 tst r7,r7
    { const bool k = c.t; c.r[1] = ld32(c.r[14] + 20); if (k) { goto L_0601967C; } }  // 06019658 bt/s 0x0601967C ; mov.l @(20,r14),r1
    c.r[0] = ld32(0x0601977Cu);  // 0601965C mov.l 0x0601977C,r0
    c.r[6] = c.r[10];  // 0601965E mov r10,r6
    c.r[5] = c.r[8];  // 06019660 mov r8,r5
    c.r[4] = 0x4u;  // 06019662 mov #4,r4
    { const uint32_t x = c.r[0]; c.pr = 0x06019668u; c.r[15] -= 4; st32(c.r[15], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06019668u) return; }  // 06019664 jsr @r0 ; mov.l r1,@-r15
    goto L_0601967C;  // 06019668 bra 0x0601967C ; nop
L_0601966C:
    c.r[0] = c.r[1];  // 0601966C mov r1,r0
    c.t = c.r[0] == 0x1u;  // 0601966E cmp/eq #1,r0
    if (!c.t) { goto L_06019682; }  // 06019670 bf 0x06019682
    c.r[1] = ld32(0x06019780u);  // 06019672 mov.l 0x06019780,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06019674 mov.w @r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06019676 tst r1,r1
    { const bool k = !c.t; c.r[0] = 0x0u; if (k) { goto L_0601973A; } }  // 06019678 bf/s 0x0601973A ; mov #0,r0
L_0601967C:
    c.r[0] = ld32(0x06019784u);  // 0601967C mov.l 0x06019784,r0
    c.r[14] += 24; goto L_0601973C;  // 0601967E bra 0x0601973C ; add #24,r14
L_06019682:
    c.r[1] = ld32(0x06019764u);  // 06019682 mov.l 0x06019764,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06019684 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06019686 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06019688 tst r1,r1
    if (c.t) { goto L_060196AE; }  // 0601968A bt 0x060196AE
    c.r[4] = ld32(c.r[2] + 12);  // 0601968C mov.l @(12,r2),r4
    c.r[8] = ld32(0x06019788u);  // 0601968E mov.l 0x06019788,r8
    c.r[1] = 0x1u;  // 06019690 mov #1,r1
    st8(c.r[8], c.r[1]);  // 06019692 mov.b r1,@r8
    c.r[6] = ld32(c.r[2] + 4);  // 06019694 mov.l @(4,r2),r6
    c.r[5] = ld32(0x0601978Cu);  // 06019696 mov.l 0x0601978C,r5
    c.r[1] = ld32(c.r[2]);  // 06019698 mov.l @r2,r1
    c.r[4] += c.r[2];  // 0601969A add r2,r4
    c.r[6] -= c.r[1];  // 0601969C sub r1,r6
    c.r[1] = ld32(0x06019790u);  // 0601969E mov.l 0x06019790,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060196A4u; c.r[6] += 4; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060196A4u) return; }  // 060196A0 jsr @r1 ; add #4,r6
    c.r[1] = ld32(0x06019794u);  // 060196A4 mov.l 0x06019794,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060196AAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060196AAu) return; }  // 060196A6 jsr @r1 ; nop
    c.r[1] = 0x0u;  // 060196AA mov #0,r1
    st8(c.r[8], c.r[1]);  // 060196AC mov.b r1,@r8
L_060196AE:
    c.r[1] = ld32(0x06019768u);  // 060196AE mov.l 0x06019768,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060196B0 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 060196B2 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060196B4 tst r1,r1
    { const bool k = c.t; c.r[2] = c.r[9]; if (k) { goto L_060196DC; } }  // 060196B6 bt/s 0x060196DC ; mov r9,r2
    c.r[8] = ld32(0x06019788u);  // 060196BA mov.l 0x06019788,r8
    c.r[4] = ld32(c.r[2] + 12);  // 060196BC mov.l @(12,r2),r4
    c.r[1] = 0x1u;  // 060196BE mov #1,r1
    st8(c.r[8], c.r[1]);  // 060196C0 mov.b r1,@r8
    c.r[6] = ld32(c.r[2] + 4);  // 060196C2 mov.l @(4,r2),r6
    c.r[5] = ld32(0x06019798u);  // 060196C4 mov.l 0x06019798,r5
    c.r[1] = ld32(c.r[2]);  // 060196C6 mov.l @r2,r1
    c.r[4] += c.r[2];  // 060196C8 add r2,r4
    c.r[6] -= c.r[1];  // 060196CA sub r1,r6
    c.r[1] = ld32(0x06019790u);  // 060196CC mov.l 0x06019790,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060196D2u; c.r[6] += 4; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060196D2u) return; }  // 060196CE jsr @r1 ; add #4,r6
    c.r[1] = ld32(0x06019794u);  // 060196D2 mov.l 0x06019794,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060196D8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060196D8u) return; }  // 060196D4 jsr @r1 ; nop
    c.r[1] = 0x0u;  // 060196D8 mov #0,r1
    st8(c.r[8], c.r[1]);  // 060196DA mov.b r1,@r8
L_060196DC:
    c.r[1] = ld32(0x0601976Cu);  // 060196DC mov.l 0x0601976C,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060196DE mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 060196E0 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060196E2 tst r1,r1
    { const bool k = c.t; c.r[2] = c.r[10]; if (k) { goto L_0601970A; } }  // 060196E4 bt/s 0x0601970A ; mov r10,r2
    c.r[8] = ld32(0x06019788u);  // 060196E8 mov.l 0x06019788,r8
    c.r[4] = ld32(c.r[2] + 12);  // 060196EA mov.l @(12,r2),r4
    c.r[1] = 0x1u;  // 060196EC mov #1,r1
    st8(c.r[8], c.r[1]);  // 060196EE mov.b r1,@r8
    c.r[6] = ld32(c.r[2] + 4);  // 060196F0 mov.l @(4,r2),r6
    c.r[5] = ld32(0x0601979Cu);  // 060196F2 mov.l 0x0601979C,r5
    c.r[1] = ld32(c.r[2]);  // 060196F4 mov.l @r2,r1
    c.r[4] += c.r[2];  // 060196F6 add r2,r4
    c.r[6] -= c.r[1];  // 060196F8 sub r1,r6
    c.r[1] = ld32(0x06019790u);  // 060196FA mov.l 0x06019790,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06019700u; c.r[6] += 4; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06019700u) return; }  // 060196FC jsr @r1 ; add #4,r6
    c.r[1] = ld32(0x06019794u);  // 06019700 mov.l 0x06019794,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06019706u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06019706u) return; }  // 06019702 jsr @r1 ; nop
    c.r[1] = 0x0u;  // 06019706 mov #0,r1
    st8(c.r[8], c.r[1]);  // 06019708 mov.b r1,@r8
L_0601970A:
    c.r[1] = ld32(0x06019770u);  // 0601970A mov.l 0x06019770,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0601970C mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0601970E extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06019710 tst r1,r1
    { const bool k = c.t; c.r[2] = c.r[11]; if (k) { goto L_06019738; } }  // 06019712 bt/s 0x06019738 ; mov r11,r2
    c.r[8] = ld32(0x06019788u);  // 06019716 mov.l 0x06019788,r8
    c.r[4] = ld32(c.r[2] + 12);  // 06019718 mov.l @(12,r2),r4
    c.r[1] = 0x1u;  // 0601971A mov #1,r1
    st8(c.r[8], c.r[1]);  // 0601971C mov.b r1,@r8
    c.r[6] = ld32(c.r[2] + 4);  // 0601971E mov.l @(4,r2),r6
    c.r[5] = ld32(0x060197A0u);  // 06019720 mov.l 0x060197A0,r5
    c.r[1] = ld32(c.r[2]);  // 06019722 mov.l @r2,r1
    c.r[4] += c.r[2];  // 06019724 add r2,r4
    c.r[6] -= c.r[1];  // 06019726 sub r1,r6
    c.r[1] = ld32(0x06019790u);  // 06019728 mov.l 0x06019790,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601972Eu; c.r[6] += 4; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601972Eu) return; }  // 0601972A jsr @r1 ; add #4,r6
    c.r[1] = ld32(0x06019794u);  // 0601972E mov.l 0x06019794,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06019734u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06019734u) return; }  // 06019730 jsr @r1 ; nop
    c.r[1] = 0x0u;  // 06019734 mov #0,r1
    st8(c.r[8], c.r[1]);  // 06019736 mov.b r1,@r8
L_06019738:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601974Cu);  // 06019738 mov.w 0x0601974C,r0
L_0601973A:
    c.r[14] += 24;  // 0601973A add #24,r14
L_0601973C:
    c.r[15] = c.r[14];  // 0601973C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601973E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06019740 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06019742 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06019744 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06019746 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06019748 rts ; mov.l @r15+,r8
}

void f_060197B0(SH2Context& c) {
    ran[212] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060197B0 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 060197B2 mov r15,r14
    c.r[0] = c.r[4] & 0xFFFFu;  // 060197B4 extu.w r4,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601981Au);  // 060197B6 mov.w 0x0601981A,r1
    c.t = c.r[0] == c.r[1];  // 060197B8 cmp/eq r1,r0
    { const bool k = !c.t; c.r[2] = c.r[0]; if (k) { goto L_060197E4; } }  // 060197BA bf/s 0x060197E4 ; mov r0,r2
    c.r[1] = ld32(0x0601982Cu);  // 060197BE mov.l 0x0601982C,r1
    c.r[2] = ld32(c.r[1]);  // 060197C0 mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601981Cu);  // 060197C2 mov.w 0x0601981C,r1
    c.r[0] = c.r[2];  // 060197C4 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060197C6 mov.b @(r0,r1),r1
    c.r[3] = c.r[1];  // 060197C8 mov r1,r3
    c.r[3] >>= 2;  // 060197CA shlr2 r3
    c.r[3] >>= 2;  // 060197CC shlr2 r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601981Eu);  // 060197CE mov.w 0x0601981E,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060197D0 mov.b @(r0,r1),r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060197D2 shlr r1
    c.r[0] = 0x3u;  // 060197D4 mov #3,r0
    c.r[1] &= c.r[0];  // 060197D6 and r0,r1
    c.r[0] = 0x4u;  // 060197D8 mov #4,r0
    c.r[3] &= c.r[0];  // 060197DA and r0,r3
    c.r[3] |= c.r[1];  // 060197DC or r1,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x06019820u);  // 060197DE mov.w 0x06019820,r1
    c.r[3] += c.r[3]; goto L_06019810;  // 060197E0 bra 0x06019810 ; add r3,r3
L_060197E4:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06019822u);  // 060197E4 mov.w 0x06019822,r1
    c.t = c.r[2] == c.r[1];  // 060197E6 cmp/eq r1,r2
    { const bool k = !c.t; c.r[0] = c.r[2]; if (k) { goto L_06019814; } }  // 060197E8 bf/s 0x06019814 ; mov r2,r0
    c.r[1] = ld32(0x0601982Cu);  // 060197EC mov.l 0x0601982C,r1
    c.r[2] = ld32(c.r[1]);  // 060197EE mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06019824u);  // 060197F0 mov.w 0x06019824,r1
    c.r[0] = c.r[2];  // 060197F2 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060197F4 mov.b @(r0,r1),r1
    c.r[3] = c.r[1];  // 060197F6 mov r1,r3
    c.r[3] >>= 2;  // 060197F8 shlr2 r3
    c.r[3] >>= 2;  // 060197FA shlr2 r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x06019826u);  // 060197FC mov.w 0x06019826,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060197FE mov.b @(r0,r1),r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06019800 shlr r1
    c.r[0] = 0x3u;  // 06019802 mov #3,r0
    c.r[1] &= c.r[0];  // 06019804 and r0,r1
    c.r[0] = 0x4u;  // 06019806 mov #4,r0
    c.r[3] &= c.r[0];  // 06019808 and r0,r3
    c.r[3] |= c.r[1];  // 0601980A or r1,r3
    c.r[3] += c.r[3];  // 0601980C add r3,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x06019828u);  // 0601980E mov.w 0x06019828,r1
L_06019810:
    c.r[3] |= c.r[1];  // 06019810 or r1,r3
    c.r[0] = c.r[3];  // 06019812 mov r3,r0
L_06019814:
    c.r[15] = c.r[14];  // 06019814 mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06019816 rts ; mov.l @r15+,r14
}

void f_0601983C(SH2Context& c) {
    ran[213] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601983C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0601983E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06019840 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06019842 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06019844 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06019846 mov r15,r14
    c.r[8] = ld32(0x060198F4u);  // 06019848 mov.l 0x060198F4,r8
    c.r[7] = 0x2u;  // 0601984A mov #2,r7
L_0601984C:
    c.r[6] = ld32(0x060198F8u);  // 0601984C mov.l 0x060198F8,r6
    c.r[4] = ld32(0x060198FCu);  // 0601984E mov.l 0x060198FC,r4
    { const uint32_t x = c.r[8]; c.pr = 0x06019854u; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06019854u) return; }  // 06019850 jsr @r8 ; mov #0,r5
    c.t = (int32_t)c.r[0] > 0;  // 06019854 cmp/pl r0
    { const bool k = !c.t; c.r[7] = 0x2u; if (k) { SH2_POLL(c); goto L_0601984C; } }  // 06019856 bf/s 0x0601984C ; mov #2,r7
    c.r[1] = ld32(0x06019900u);  // 0601985A mov.l 0x06019900,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0601985C mov.w @r1,r4
    c.r[8] = ld32(0x06019904u);  // 0601985E mov.l 0x06019904,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06019864u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06019864u) return; }  // 06019860 jsr @r8 ; extu.w r4,r4
    c.r[7] = c.r[0] & 0xFFFFu;  // 06019864 extu.w r0,r7
    c.r[10] = ld32(0x060198F8u);  // 06019866 mov.l 0x060198F8,r10
    c.r[1] = ld32(0x06019908u);  // 06019868 mov.l 0x06019908,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0601986A mov.l r1,@-r15
    c.r[9] = ld32(0x0601990Cu);  // 0601986C mov.l 0x0601990C,r9
    c.r[6] = 0x1u;  // 0601986E mov #1,r6
    c.r[5] = c.r[10];  // 06019870 mov r10,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06019876u; c.r[4] = 0x1Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06019876u) return; }  // 06019872 jsr @r9 ; mov #30,r4
    c.r[1] = ld32(0x06019910u);  // 06019876 mov.l 0x06019910,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06019878 mov.w @r1,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0601987Eu; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601987Eu) return; }  // 0601987A jsr @r8 ; extu.w r4,r4
    c.r[7] = c.r[0] & 0xFFFFu;  // 0601987E extu.w r0,r7
    c.r[1] = ld32(0x06019914u);  // 06019880 mov.l 0x06019914,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06019882 mov.l r1,@-r15
    c.r[6] = 0x1u;  // 06019884 mov #1,r6
    c.r[5] = c.r[10];  // 06019886 mov r10,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0601988Cu; c.r[4] = 0x1Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601988Cu) return; }  // 06019888 jsr @r9 ; mov #30,r4
    c.r[1] = ld32(0x06019918u);  // 0601988C mov.l 0x06019918,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0601988E mov.w @r1,r4
    { const uint32_t x = c.r[8]; c.pr = 0x06019894u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06019894u) return; }  // 06019890 jsr @r8 ; extu.w r4,r4
    c.r[7] = c.r[0] & 0xFFFFu;  // 06019894 extu.w r0,r7
    c.t = (c.r[7] & c.r[7]) == 0;  // 06019896 tst r7,r7
    { const bool k = !c.t; c.r[15] += 8; if (k) { goto L_060198AA; } }  // 06019898 bf/s 0x060198AA ; add #8,r15
    c.r[4] = ld32(0x0601991Cu);  // 0601989C mov.l 0x0601991C,r4
    c.r[0] = ld32(0x06019920u);  // 0601989E mov.l 0x06019920,r0
    c.r[6] = 0x10u;  // 060198A0 mov #16,r6
    { const uint32_t x = c.r[0]; c.pr = 0x060198A6u; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060198A6u) return; }  // 060198A2 jsr @r0 ; mov #0,r5
    goto L_060198B8;  // 060198A6 bra 0x060198B8 ; nop
L_060198AA:
    c.r[1] = ld32(0x0601991Cu);  // 060198AA mov.l 0x0601991C,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060198AC mov.l r1,@-r15
    c.r[6] = 0x1u;  // 060198AE mov #1,r6
    c.r[5] = c.r[10];  // 060198B0 mov r10,r5
    { const uint32_t x = c.r[9]; c.pr = 0x060198B6u; c.r[4] = 0x1Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060198B6u) return; }  // 060198B2 jsr @r9 ; mov #30,r4
    c.r[15] += 4;  // 060198B6 add #4,r15
L_060198B8:
    c.r[1] = ld32(0x06019924u);  // 060198B8 mov.l 0x06019924,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060198BA mov.w @r1,r4
    c.r[0] = ld32(0x06019904u);  // 060198BC mov.l 0x06019904,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060198C2u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060198C2u) return; }  // 060198BE jsr @r0 ; extu.w r4,r4
    c.r[7] = c.r[0] & 0xFFFFu;  // 060198C2 extu.w r0,r7
    c.t = (c.r[7] & c.r[7]) == 0;  // 060198C4 tst r7,r7
    { const bool k = !c.t; c.r[6] = 0x10u; if (k) { goto L_060198D6; } }  // 060198C6 bf/s 0x060198D6 ; mov #16,r6
    c.r[4] = ld32(0x06019928u);  // 060198CA mov.l 0x06019928,r4
    c.r[0] = ld32(0x06019920u);  // 060198CC mov.l 0x06019920,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060198D2u; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060198D2u) return; }  // 060198CE jsr @r0 ; mov #0,r5
    c.r[15] = c.r[14]; goto L_060198E6;  // 060198D2 bra 0x060198E6 ; mov r14,r15
L_060198D6:
    c.r[5] = ld32(0x060198F8u);  // 060198D6 mov.l 0x060198F8,r5
    c.r[1] = ld32(0x06019928u);  // 060198D8 mov.l 0x06019928,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060198DA mov.l r1,@-r15
    c.r[0] = ld32(0x0601990Cu);  // 060198DC mov.l 0x0601990C,r0
    c.r[6] = 0x1u;  // 060198DE mov #1,r6
    { const uint32_t x = c.r[0]; c.pr = 0x060198E4u; c.r[4] = 0x1Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060198E4u) return; }  // 060198E0 jsr @r0 ; mov #30,r4
    c.r[15] = c.r[14];  // 060198E4 mov r14,r15
L_060198E6:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060198E6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060198E8 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060198EA mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060198EC mov.l @r15+,r9
    c.r[0] = ld32(0x0601992Cu);  // 060198EE mov.l 0x0601992C,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060198F0 rts ; mov.l @r15+,r8
}

}  // namespace p_srwfin_installed
