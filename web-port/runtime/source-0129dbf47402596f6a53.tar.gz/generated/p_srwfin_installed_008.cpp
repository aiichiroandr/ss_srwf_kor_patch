#include "p_srwfin_installed_funcs.h"

namespace p_srwfin_installed {

void f_06019930(SH2Context& c) {
    ran[214] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06019930 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06019932 sts.l pr,@-r15
    c.r[1] = ld32(0x06019950u);  // 06019934 mov.l 0x06019950,r1
    c.r[1] = ld32(c.r[1]);  // 06019936 mov.l @r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06019938 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0601993A extu.b r1,r0
    c.r[0] <<= 2;  // 0601993C shll2 r0
    c.r[1] = ld32(0x06019954u);  // 0601993E mov.l 0x06019954,r1
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 06019940 mov.l @(r0,r1),r0
    { const uint32_t x = c.r[0]; c.pr = 0x06019946u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06019946u) return; }  // 06019942 jsr @r0 ; mov r15,r14
    c.r[15] = c.r[14];  // 06019946 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06019948 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601994A mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[0] & 0xFFFFu; c.pc = x; return; }  // 0601994C rts ; extu.w r0,r0
}

void f_06019958(SH2Context& c) {
    ran[215] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06019958 mov.l r14,@-r15
    c.r[1] = ld32(0x06019974u);  // 0601995A mov.l 0x06019974,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0601995C mov.w @r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601995E tst r1,r1
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0601996A; } }  // 06019960 bf/s 0x0601996A ; mov r15,r14
    c.r[0] = ld32(0x06019978u);  // 06019964 mov.l 0x06019978,r0
    c.r[15] = c.r[14]; goto L_0601996E;  // 06019966 bra 0x0601996E ; mov r14,r15
L_0601996A:
    c.r[0] = 0x0u;  // 0601996A mov #0,r0
    c.r[15] = c.r[14];  // 0601996C mov r14,r15
L_0601996E:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601996E rts ; mov.l @r15+,r14
}

void f_0601997C(SH2Context& c) {
    ran[216] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601997C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601997E sts.l pr,@-r15
    c.r[1] = ld32(0x06019990u);  // 06019980 mov.l 0x06019990,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06019986u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06019986u) return; }  // 06019982 jsr @r1 ; mov r15,r14
    c.r[15] = c.r[14];  // 06019986 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06019988 lds.l @r15+,pr
    c.r[0] = ld32(0x06019994u);  // 0601998A mov.l 0x06019994,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601998C rts ; mov.l @r15+,r14
}

void f_06019998(SH2Context& c) {
    ran[217] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06019998 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0601999A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0601999C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0601999E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060199A0 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060199A2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060199A4 sts.l pr,@-r15
    c.r[1] = ld32(0x06019A14u);  // 060199A6 mov.l 0x06019A14,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060199A8 mov.w @r1,r1
    c.r[8] = c.r[1] & 0xFFFFu;  // 060199AA extu.w r1,r8
    c.r[1] = ld32(0x06019A18u);  // 060199AC mov.l 0x06019A18,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060199AE mov.w @r1,r1
    c.r[9] = c.r[1] & 0xFFFFu;  // 060199B0 extu.w r1,r9
    c.r[1] = (uint32_t)(int16_t)ld16(0x06019A10u);  // 060199B2 mov.w 0x06019A10,r1
    c.t = c.r[8] > c.r[1];  // 060199B4 cmp/hi r1,r8
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_060199BC; } }  // 060199B6 bf/s 0x060199BC ; mov r15,r14
    c.r[8] = 0x0u;  // 060199BA mov #0,r8
L_060199BC:
    c.t = c.r[9] > c.r[1];  // 060199BC cmp/hi r1,r9
    if (!c.t) { goto L_060199C2; }  // 060199BE bf 0x060199C2
    c.r[9] = 0x0u;  // 060199C0 mov #0,r9
L_060199C2:
    c.r[4] = ld32(0x06019A1Cu);  // 060199C2 mov.l 0x06019A1C,r4
    c.r[0] = ld32(0x06019A20u);  // 060199C4 mov.l 0x06019A20,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060199CAu; c.r[5] = 0x6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060199CAu) return; }  // 060199C6 jsr @r0 ; mov #6,r5
    c.r[10] = c.r[0];  // 060199CA mov r0,r10
    c.r[1] = ld32(0x06019A24u);  // 060199CC mov.l 0x06019A24,r1
    c.r[12] = ld32(0x06019A28u);  // 060199CE mov.l 0x06019A28,r12
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060199D0 mov.l r1,@-r15
    c.r[11] = ld32(0x06019A2Cu);  // 060199D2 mov.l 0x06019A2C,r11
    c.r[7] = c.r[8];  // 060199D4 mov r8,r7
    c.r[6] = 0x2u;  // 060199D6 mov #2,r6
    c.r[5] = c.r[10];  // 060199D8 mov r10,r5
    { const uint32_t x = c.r[11]; c.pr = 0x060199DEu; c.r[4] = 0x8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060199DEu) return; }  // 060199DA jsr @r11 ; mov #8,r4
    c.r[1] = ld32(0x06019A30u);  // 060199DE mov.l 0x06019A30,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060199E0 mov.b @r1,r1
    c.r[0] = c.r[1];  // 060199E2 mov r1,r0
    c.r[0] >>= 2;  // 060199E4 shlr2 r0
    c.r[0] &= 0x3u;  // 060199E6 and #3,r0
    c.r[1] = 0x1u;  // 060199E8 mov #1,r1
    c.t = c.r[0] > c.r[1];  // 060199EA cmp/hi r1,r0
    { const bool k = c.t; c.r[15] += 4; if (k) { goto L_060199FC; } }  // 060199EC bt/s 0x060199FC ; add #4,r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060199F0 mov.l r12,@-r15
    c.r[7] = c.r[9];  // 060199F2 mov r9,r7
    c.r[6] = 0x2u;  // 060199F4 mov #2,r6
    c.r[5] = c.r[10];  // 060199F6 mov r10,r5
    { const uint32_t x = c.r[11]; c.pr = 0x060199FCu; c.r[4] = 0x8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060199FCu) return; }  // 060199F8 jsr @r11 ; mov #8,r4
L_060199FC:
    c.r[15] = c.r[14];  // 060199FC mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060199FE lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06019A00 mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06019A02 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06019A04 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06019A06 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06019A08 mov.l @r15+,r9
    c.r[0] = ld32(0x06019A34u);  // 06019A0A mov.l 0x06019A34,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06019A0C rts ; mov.l @r15+,r8
}

void f_06019A38(SH2Context& c) {
    ran[218] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06019A38 mov.l r14,@-r15
    c.r[15] -= 44;  // 06019A3A add #-44,r15
    c.r[14] = c.r[15];  // 06019A3C mov r15,r14
    c.r[2] = c.r[14];  // 06019A3E mov r14,r2
    c.r[2] += 18;  // 06019A40 add #18,r2
    c.r[1] = 0xBu;  // 06019A42 mov #11,r1
    st16(c.r[2], c.r[1]);  // 06019A44 mov.w r1,@r2
    c.r[14] += 44;  // 06019A46 add #44,r14
    c.r[15] = c.r[14];  // 06019A48 mov r14,r15
    c.r[0] = ld32(0x06019A50u);  // 06019A4A mov.l 0x06019A50,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06019A4C rts ; mov.l @r15+,r14
}

void f_06019A54(SH2Context& c) {
    ran[219] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06019A54 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06019A56 mov r15,r14
    c.r[0] = ld32(0x06019A60u);  // 06019A58 mov.l 0x06019A60,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06019A5A rts ; mov.l @r15+,r14
}

void f_06019A64(SH2Context& c) {
    ran[220] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06019A64 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06019A66 mov r15,r14
    c.r[0] = ld32(0x06019A70u);  // 06019A68 mov.l 0x06019A70,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06019A6A rts ; mov.l @r15+,r14
}

void f_06019A74(SH2Context& c) {
    ran[221] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06019A74 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06019A76 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06019A78 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06019A7A mov r15,r14
    c.r[8] = ld32(0x06019AC4u);  // 06019A7C mov.l 0x06019AC4,r8
    c.r[7] = 0x2u;  // 06019A7E mov #2,r7
L_06019A80:
    c.r[6] = ld32(0x06019AC8u);  // 06019A80 mov.l 0x06019AC8,r6
    c.r[4] = ld32(0x06019ACCu);  // 06019A82 mov.l 0x06019ACC,r4
    { const uint32_t x = c.r[8]; c.pr = 0x06019A88u; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06019A88u) return; }  // 06019A84 jsr @r8 ; mov #0,r5
    c.t = (int32_t)c.r[0] > 0;  // 06019A88 cmp/pl r0
    { const bool k = !c.t; c.r[7] = 0x2u; if (k) { SH2_POLL(c); goto L_06019A80; } }  // 06019A8A bf/s 0x06019A80 ; mov #2,r7
    c.r[1] = ld32(0x06019AD0u);  // 06019A8E mov.l 0x06019AD0,r1
    c.r[0] = ld32(0x06019AD4u);  // 06019A90 mov.l 0x06019AD4,r0
    c.r[6] = 0x3u;  // 06019A92 mov #3,r6
    c.r[5] = ld32(0x06019AC8u);  // 06019A94 mov.l 0x06019AC8,r5
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06019A96 mov.b @r1,r7
    c.r[4] = 0xDu;  // 06019A98 mov #13,r4
    c.r[1] = ld32(0x06019AD8u);  // 06019A9A mov.l 0x06019AD8,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06019A9C mov.l r1,@-r15
    c.r[1] = ld32(0x06019ADCu);  // 06019A9E mov.l 0x06019ADC,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06019AA0 mov.l r1,@-r15
    c.r[1] = ld32(0x06019AE0u);  // 06019AA2 mov.l 0x06019AE0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06019AA4 mov.b @r1,r1
    c.r[7] = c.r[7] & 0xFFu;  // 06019AA6 extu.b r7,r7
    c.r[1] = c.r[1] & 0xFFu;  // 06019AA8 extu.b r1,r1
    { const uint32_t x = c.r[0]; c.pr = 0x06019AAEu; c.r[15] -= 4; st32(c.r[15], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06019AAEu) return; }  // 06019AAA jsr @r0 ; mov.l r1,@-r15
    c.t = (c.r[0] & c.r[0]) == 0;  // 06019AAE tst r0,r0
    { const bool k = !c.t; c.r[15] = c.r[14]; if (k) { goto L_06019ABA; } }  // 06019AB0 bf/s 0x06019ABA ; mov r14,r15
    c.r[0] = ld32(0x06019AE4u);  // 06019AB4 mov.l 0x06019AE4,r0
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; } goto L_06019ABE;  // 06019AB6 bra 0x06019ABE ; lds.l @r15+,pr
L_06019ABA:
    c.r[0] = 0x0u;  // 06019ABA mov #0,r0
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06019ABC lds.l @r15+,pr
L_06019ABE:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06019ABE mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06019AC0 rts ; mov.l @r15+,r8
}

void f_06019AE8(SH2Context& c) {
    ran[222] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06019AE8 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06019AEA mov r15,r14
    c.r[0] = ld32(0x06019AF4u);  // 06019AEC mov.l 0x06019AF4,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06019AEE rts ; mov.l @r15+,r14
}

void f_06019AF8(SH2Context& c) {
    ran[223] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06019AF8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06019AFA sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06019AFC mov r15,r14
    c.r[7] = ld32(0x06019B14u);  // 06019AFE mov.l 0x06019B14,r7
    c.r[6] = ld32(0x06019B18u);  // 06019B00 mov.l 0x06019B18,r6
    c.r[0] = ld32(0x06019B1Cu);  // 06019B02 mov.l 0x06019B1C,r0
    c.r[5] = 0x0u;  // 06019B04 mov #0,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06019B0Au; c.r[4] = 0x1Fu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06019B0Au) return; }  // 06019B06 jsr @r0 ; mov #31,r4
    c.r[15] = c.r[14];  // 06019B0A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06019B0C lds.l @r15+,pr
    c.r[0] = ld32(0x06019B20u);  // 06019B0E mov.l 0x06019B20,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06019B10 rts ; mov.l @r15+,r14
}

void f_06019B24(SH2Context& c) {
    ran[224] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06019B24 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06019B26 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06019B28 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06019B2A mov r15,r14
    c.r[8] = ld32(0x06019B64u);  // 06019B2C mov.l 0x06019B64,r8
    c.r[7] = 0x2u;  // 06019B2E mov #2,r7
L_06019B30:
    c.r[6] = ld32(0x06019B68u);  // 06019B30 mov.l 0x06019B68,r6
    c.r[4] = ld32(0x06019B6Cu);  // 06019B32 mov.l 0x06019B6C,r4
    { const uint32_t x = c.r[8]; c.pr = 0x06019B38u; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06019B38u) return; }  // 06019B34 jsr @r8 ; mov #0,r5
    c.t = (int32_t)c.r[0] > 0;  // 06019B38 cmp/pl r0
    { const bool k = !c.t; c.r[7] = 0x2u; if (k) { SH2_POLL(c); goto L_06019B30; } }  // 06019B3A bf/s 0x06019B30 ; mov #2,r7
    c.r[1] = ld32(0x06019B70u);  // 06019B3E mov.l 0x06019B70,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06019B40 mov.w @r1,r4
    c.r[0] = ld32(0x06019B74u);  // 06019B42 mov.l 0x06019B74,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06019B48u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06019B48u) return; }  // 06019B44 jsr @r0 ; extu.w r4,r4
    c.r[7] = c.r[0] & 0xFFFFu;  // 06019B48 extu.w r0,r7
    c.r[5] = ld32(0x06019B68u);  // 06019B4A mov.l 0x06019B68,r5
    c.r[1] = ld32(0x06019B78u);  // 06019B4C mov.l 0x06019B78,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06019B4E mov.l r1,@-r15
    c.r[0] = ld32(0x06019B7Cu);  // 06019B50 mov.l 0x06019B7C,r0
    c.r[6] = 0x1u;  // 06019B52 mov #1,r6
    { const uint32_t x = c.r[0]; c.pr = 0x06019B58u; c.r[4] = 0x1Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06019B58u) return; }  // 06019B54 jsr @r0 ; mov #30,r4
    c.r[15] = c.r[14];  // 06019B58 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06019B5A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06019B5C mov.l @r15+,r14
    c.r[0] = ld32(0x06019B80u);  // 06019B5E mov.l 0x06019B80,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06019B60 rts ; mov.l @r15+,r8
}

void f_06019B84(SH2Context& c) {
    ran[225] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06019B84 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06019B86 mov r15,r14
    c.r[2] = ld32(0x06019B94u);  // 06019B88 mov.l 0x06019B94,r2
    c.r[1] = 0x0u;  // 06019B8A mov #0,r1
    st32(c.r[2], c.r[1]);  // 06019B8C mov.l r1,@r2
    c.r[0] = ld32(0x06019B98u);  // 06019B8E mov.l 0x06019B98,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06019B90 rts ; mov.l @r15+,r14
}

void f_06019B9C(SH2Context& c) {
    ran[226] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06019B9C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06019B9E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06019BA0 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06019BA2 mov r15,r14
    c.r[1] = ld32(0x06019BDCu);  // 06019BA4 mov.l 0x06019BDC,r1
    c.r[1] = ld32(c.r[1]);  // 06019BA6 mov.l @r1,r1
    c.r[8] = ld32(0x06019BE0u);  // 06019BA8 mov.l 0x06019BE0,r8
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06019BAA mov.b @r1,r0
    c.r[4] = 0x1u;  // 06019BAC mov #1,r4
    c.r[1] = 0x1Fu;  // 06019BAE mov #31,r1
    c.r[1] &= c.r[0];  // 06019BB0 and r0,r1
    c.r[0] = ld32(0x06019BE4u);  // 06019BB2 mov.l 0x06019BE4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06019BB8u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06019BB8u) return; }  // 06019BB4 jsr @r0 ; mov r1,r5
    c.r[1] = ld32(c.r[8]);  // 06019BB8 mov.l @r8,r1
    c.r[1] &= c.r[0];  // 06019BBA and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06019BBC tst r1,r1
    if (!c.t) { goto L_06019BC6; }  // 06019BBE bf 0x06019BC6
    c.r[0] = 0x0u;  // 06019BC0 mov #0,r0
    c.r[15] = c.r[14]; goto L_06019BD2;  // 06019BC2 bra 0x06019BD2 ; mov r14,r15
L_06019BC6:
    c.r[1] = ~c.r[0];  // 06019BC6 not r0,r1
    c.r[2] = ld32(c.r[8]);  // 06019BC8 mov.l @r8,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06019BDAu);  // 06019BCA mov.w 0x06019BDA,r0
    c.r[2] &= c.r[1];  // 06019BCC and r1,r2
    st32(c.r[8], c.r[2]);  // 06019BCE mov.l r2,@r8
    c.r[15] = c.r[14];  // 06019BD0 mov r14,r15
L_06019BD2:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06019BD2 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06019BD4 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06019BD6 rts ; mov.l @r15+,r8
}

void f_06019BE8(SH2Context& c) {
    ran[227] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06019BE8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06019BEA mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06019BEC sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06019BEE mov r15,r14
    c.r[1] = ld32(0x06019C18u);  // 06019BF0 mov.l 0x06019C18,r1
    c.r[1] = ld32(c.r[1]);  // 06019BF2 mov.l @r1,r1
    c.r[8] = ld32(0x06019C1Cu);  // 06019BF4 mov.l 0x06019C1C,r8
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06019BF6 mov.b @r1,r0
    c.r[4] = 0x1u;  // 06019BF8 mov #1,r4
    c.r[1] = 0x1Fu;  // 06019BFA mov #31,r1
    c.r[1] &= c.r[0];  // 06019BFC and r0,r1
    c.r[0] = ld32(0x06019C20u);  // 06019BFE mov.l 0x06019C20,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06019C04u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06019C04u) return; }  // 06019C00 jsr @r0 ; mov r1,r5
    c.r[1] = ld32(c.r[8]);  // 06019C04 mov.l @r8,r1
    c.r[15] = c.r[14];  // 06019C06 mov r14,r15
    c.r[1] |= c.r[0];  // 06019C08 or r0,r1
    st32(c.r[8], c.r[1]);  // 06019C0A mov.l r1,@r8
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06019C0C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06019C0E mov.l @r15+,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x06019C16u);  // 06019C10 mov.w 0x06019C16,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06019C12 rts ; mov.l @r15+,r8
}

void f_06019C24(SH2Context& c) {
    ran[228] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06019C24 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06019C26 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06019C28 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06019C2A mov r15,r14
    c.r[1] = ld32(0x06019C58u);  // 06019C2C mov.l 0x06019C58,r1
    c.r[1] = ld32(c.r[1]);  // 06019C2E mov.l @r1,r1
    c.r[8] = ld32(0x06019C5Cu);  // 06019C30 mov.l 0x06019C5C,r8
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06019C32 mov.b @r1,r0
    c.r[4] = 0x1u;  // 06019C34 mov #1,r4
    c.r[1] = 0x1Fu;  // 06019C36 mov #31,r1
    c.r[1] &= c.r[0];  // 06019C38 and r0,r1
    c.r[0] = ld32(0x06019C60u);  // 06019C3A mov.l 0x06019C60,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06019C40u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06019C40u) return; }  // 06019C3C jsr @r0 ; mov r1,r5
    c.r[1] = ~c.r[0];  // 06019C40 not r0,r1
    c.r[2] = ld32(c.r[8]);  // 06019C42 mov.l @r8,r2
    c.r[15] = c.r[14];  // 06019C44 mov r14,r15
    c.r[2] &= c.r[1];  // 06019C46 and r1,r2
    st32(c.r[8], c.r[2]);  // 06019C48 mov.l r2,@r8
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06019C4A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06019C4C mov.l @r15+,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x06019C54u);  // 06019C4E mov.w 0x06019C54,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06019C50 rts ; mov.l @r15+,r8
}

void f_06019C64(SH2Context& c) {
    ran[229] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06019C64 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06019C66 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06019C68 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06019C6A mov r15,r14
    c.r[1] = ld32(0x06019CA8u);  // 06019C6C mov.l 0x06019CA8,r1
    c.r[1] = ld32(c.r[1]);  // 06019C6E mov.l @r1,r1
    c.r[8] = ld32(0x06019CACu);  // 06019C70 mov.l 0x06019CAC,r8
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06019C72 mov.b @r1,r0
    c.r[4] = 0x1u;  // 06019C74 mov #1,r4
    c.r[1] = 0x1Fu;  // 06019C76 mov #31,r1
    c.r[1] &= c.r[0];  // 06019C78 and r0,r1
    c.r[0] = ld32(0x06019CB0u);  // 06019C7A mov.l 0x06019CB0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06019C80u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06019C80u) return; }  // 06019C7C jsr @r0 ; mov r1,r5
    c.r[1] = ld32(c.r[8]);  // 06019C80 mov.l @r8,r1
    c.r[1] &= c.r[0];  // 06019C82 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06019C84 tst r1,r1
    { const bool k = !c.t; c.r[15] = c.r[14]; if (k) { goto L_06019C90; } }  // 06019C86 bf/s 0x06019C90 ; mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x06019CA2u);  // 06019C8A mov.w 0x06019CA2,r0
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; } goto L_06019C9C;  // 06019C8C bra 0x06019C9C ; lds.l @r15+,pr
L_06019C90:
    c.r[1] = ~c.r[0];  // 06019C90 not r0,r1
    c.r[2] = ld32(c.r[8]);  // 06019C92 mov.l @r8,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06019CA4u);  // 06019C94 mov.w 0x06019CA4,r0
    c.r[2] &= c.r[1];  // 06019C96 and r1,r2
    st32(c.r[8], c.r[2]);  // 06019C98 mov.l r2,@r8
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06019C9A lds.l @r15+,pr
L_06019C9C:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06019C9C mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06019C9E rts ; mov.l @r15+,r8
}

void f_06019CB4(SH2Context& c) {
    ran[230] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06019CB4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06019CB6 sts.l pr,@-r15
    c.r[1] = ld32(0x06019CD8u);  // 06019CB8 mov.l 0x06019CD8,r1
    c.r[1] = ld32(c.r[1]);  // 06019CBA mov.l @r1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 06019CBC mov.b @r1+,r4
    c.r[14] = c.r[15];  // 06019CBE mov r15,r14
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06019CC0 mov.b @r1,r5
    c.r[4] = c.r[4] & 0xFFu;  // 06019CC2 extu.b r4,r4
    c.r[1] = ld32(0x06019CDCu);  // 06019CC4 mov.l 0x06019CDC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06019CCAu; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06019CCAu) return; }  // 06019CC6 jsr @r1 ; extu.b r5,r5
    c.r[15] = c.r[14];  // 06019CCA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06019CCC lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x06019CD4u);  // 06019CCE mov.w 0x06019CD4,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06019CD0 rts ; mov.l @r15+,r14
}

void f_06019CE0(SH2Context& c) {
    ran[231] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06019CE0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06019CE2 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06019CE4 mov r15,r14
    c.r[1] = ld32(0x06019D10u);  // 06019CE6 mov.l 0x06019D10,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06019CECu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06019CECu) return; }  // 06019CE8 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06019D14u);  // 06019CEC mov.l 0x06019D14,r1
    c.r[5] = 0x7Fu;  // 06019CEE mov #127,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06019CF4u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06019CF4u) return; }  // 06019CF0 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06019D18u);  // 06019CF4 mov.l 0x06019D18,r1
    c.r[2] = 0x0u;  // 06019CF6 mov #0,r2
    st16(c.r[1], c.r[2]);  // 06019CF8 mov.w r2,@r1
    c.r[1] = ld32(0x06019D1Cu);  // 06019CFA mov.l 0x06019D1C,r1
    st16(c.r[1], c.r[2]);  // 06019CFC mov.w r2,@r1
    c.r[1] = ld32(0x06019D20u);  // 06019CFE mov.l 0x06019D20,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06019D04u; c.r[4] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06019D04u) return; }  // 06019D00 jsr @r1 ; mov #2,r4
    c.r[15] = c.r[14];  // 06019D04 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06019D06 lds.l @r15+,pr
    c.r[0] = ld32(0x06019D24u);  // 06019D08 mov.l 0x06019D24,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06019D0A rts ; mov.l @r15+,r14
}

void f_06019D28(SH2Context& c) {
    ran[232] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06019D28 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06019D2A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06019D2C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06019D2E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06019D30 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06019D32 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06019D34 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06019D36 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06019D38 mov r15,r14
    c.r[10] = ld32(0x06019E80u);  // 06019D3A mov.l 0x06019E80,r10
    c.r[2] = ld32(0x06019E84u);  // 06019D3C mov.l 0x06019E84,r2
    c.r[1] = 0x0u;  // 06019D3E mov #0,r1
    st32(c.r[2], c.r[1]);  // 06019D40 mov.l r1,@r2
    c.r[2] = ld32(0x06019E88u);  // 06019D42 mov.l 0x06019E88,r2
    c.r[1] = 0x1u;  // 06019D44 mov #1,r1
    st16(c.r[2], c.r[1]);  // 06019D46 mov.w r1,@r2
    c.r[1] = ld32(0x06019E8Cu);  // 06019D48 mov.l 0x06019E8C,r1
    c.r[8] = 0x0u;  // 06019D4A mov #0,r8
    st16(c.r[1], c.r[8]);  // 06019D4C mov.w r8,@r1
    c.r[2] = ld32(0x06019E90u);  // 06019D4E mov.l 0x06019E90,r2
    c.r[1] = 0x0u;  // 06019D50 mov #0,r1
    st8(c.r[2], c.r[1]);  // 06019D52 mov.b r1,@r2
    c.r[6] = (uint32_t)(int16_t)ld16(0x06019E6Au);  // 06019D54 mov.w 0x06019E6A,r6
    c.r[5] = (uint32_t)(int16_t)ld16(0x06019E6Cu);  // 06019D56 mov.w 0x06019E6C,r5
    c.r[0] = ld32(0x06019E94u);  // 06019D58 mov.l 0x06019E94,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06019D5Eu; c.r[4] = 0x20u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06019D5Eu) return; }  // 06019D5A jsr @r0 ; mov #32,r4
    c.r[1] = ld32(0x06019E98u);  // 06019D5E mov.l 0x06019E98,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06019D64u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06019D64u) return; }  // 06019D60 jsr @r1 ; mov #1,r4
    c.r[9] = ld32(0x06019E9Cu);  // 06019D64 mov.l 0x06019E9C,r9
    c.r[1] = ld32(0x06019EA0u);  // 06019D66 mov.l 0x06019EA0,r1
    st32(c.r[9] + 24, c.r[1]);  // 06019D68 mov.l r1,@(24,r9)
    c.r[1] = ld32(0x06019EA4u);  // 06019D6A mov.l 0x06019EA4,r1
    st32(c.r[9] + 28, c.r[1]);  // 06019D6C mov.l r1,@(28,r9)
    c.r[1] = ld32(0x06019EA8u);  // 06019D6E mov.l 0x06019EA8,r1
    st32(c.r[9] + 32, c.r[1]);  // 06019D70 mov.l r1,@(32,r9)
    c.r[1] = ld32(0x06019EACu);  // 06019D72 mov.l 0x06019EAC,r1
    c.r[0] = c.r[9];  // 06019D74 mov r9,r0
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06019D76 mov.w @r1,r2
    c.r[11] = (uint32_t)(int16_t)ld16(0x06019E6Eu);  // 06019D78 mov.w 0x06019E6E,r11
    c.r[1] = 0x8u;  // 06019D7A mov #8,r1
    c.r[1] &= c.r[2];  // 06019D7C and r2,r1
    st32(c.r[9] + 36, c.r[1]);  // 06019D7E mov.l r1,@(36,r9)
    c.r[1] = 0x10u;  // 06019D80 mov #16,r1
    c.r[1] &= c.r[2];  // 06019D82 and r2,r1
    st32(c.r[9] + 40, c.r[1]);  // 06019D84 mov.l r1,@(40,r9)
    c.r[2] = (uint32_t)(int16_t)ld16(0x06019E70u);  // 06019D86 mov.w 0x06019E70,r2
    c.r[1] = ld32(0x06019EB0u);  // 06019D88 mov.l 0x06019EB0,r1
    st32(c.r[0] + c.r[2], c.r[1]);  // 06019D8A mov.l r1,@(r0,r2)
    st32(c.r[0] + c.r[11], c.r[10]);  // 06019D8C mov.l r10,@(r0,r11)
    c.r[2] = (uint32_t)(int16_t)ld16(0x06019E72u);  // 06019D8E mov.w 0x06019E72,r2
    st32(c.r[0] + c.r[2], c.r[1]);  // 06019D90 mov.l r1,@(r0,r2)
    c.r[2] = ld32(0x06019EB4u);  // 06019D92 mov.l 0x06019EB4,r2
    c.r[1] = ld32(0x06019EB8u);  // 06019D94 mov.l 0x06019EB8,r1
    st32(c.r[2], c.r[1]);  // 06019D96 mov.l r1,@r2
    c.r[2] = ld32(0x06019EBCu);  // 06019D98 mov.l 0x06019EBC,r2
    st16(c.r[2], c.r[8]);  // 06019D9A mov.w r8,@r2
    c.r[2] += 2;  // 06019D9C add #2,r2
    c.r[1] = 0x20u;  // 06019D9E mov #32,r1
    st16(c.r[2], c.r[1]);  // 06019DA0 mov.w r1,@r2
    c.r[8] = c.r[9];  // 06019DA2 mov r9,r8
    c.r[8] += 1;  // 06019DA4 add #1,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06019DA6 mov.b @r8,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06019E74u);  // 06019DA8 mov.w 0x06019E74,r0
    c.r[1] &= c.r[0];  // 06019DAA and r0,r1
    st8(c.r[8], c.r[1]);  // 06019DAC mov.b r1,@r8
    c.r[1] = ld32(0x06019EC0u);  // 06019DAE mov.l 0x06019EC0,r1
    c.r[1] = ld32(c.r[1]);  // 06019DB0 mov.l @r1,r1
    c.r[12] = ld32(0x06019EC4u);  // 06019DB2 mov.l 0x06019EC4,r12
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06019DB4 mov.b @r1,r1
    c.r[13] = ld32(0x06019EC8u);  // 06019DB6 mov.l 0x06019EC8,r13
    c.r[3] = c.r[1] & 0xFFu;  // 06019DB8 extu.b r1,r3
    c.r[0] = c.r[3];  // 06019DBA mov r3,r0
    c.t = c.r[0] == 0x2u;  // 06019DBC cmp/eq #2,r0
    { const bool k = c.t; c.t = c.r[0] == 0x1u; if (k) { goto L_06019E38; } }  // 06019DBE bt/s 0x06019E38 ; cmp/eq #1,r0
    { const bool k = c.t; c.r[7] = c.r[3]; if (k) { goto L_06019DEE; } }  // 06019DC2 bt/s 0x06019DEE ; mov r3,r7
    c.r[7] = 0x1u;  // 06019DC6 mov #1,r7
    c.t = (int32_t)c.r[3] > (int32_t)c.r[7];  // 06019DC8 cmp/gt r7,r3
    { const bool k = c.t; c.t = c.r[0] == 0x3u; if (k) { goto L_06019DD6; } }  // 06019DCA bt/s 0x06019DD6 ; cmp/eq #3,r0
    c.t = (c.r[3] & c.r[3]) == 0;  // 06019DCE tst r3,r3
    if (!c.t) { goto L_06019E54; }  // 06019DD0 bf 0x06019E54
    goto L_06019DDC;  // 06019DD2 bra 0x06019DDC ; nop
L_06019DD6:
    if (!c.t) { goto L_06019E54; }  // 06019DD6 bf 0x06019E54
    goto L_06019E06;  // 06019DD8 bra 0x06019E06 ; nop
L_06019DDC:
    c.r[1] = ld32(0x06019ECCu);  // 06019DDC mov.l 0x06019ECC,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06019E76u);  // 06019DDE mov.w 0x06019E76,r2
    st16(c.r[1], c.r[2]);  // 06019DE0 mov.w r2,@r1
    c.r[1] = ld32(0x06019ED0u);  // 06019DE2 mov.l 0x06019ED0,r1
    c.r[5] = ld32(0x06019ED4u);  // 06019DE4 mov.l 0x06019ED4,r5
    c.r[4] = ld32(0x06019ED8u);  // 06019DE6 mov.l 0x06019ED8,r4
    c.r[0] = ld32(0x06019EDCu);  // 06019DE8 mov.l 0x06019EDC,r0
    st16(c.r[1], c.r[2]); goto L_06019DFE;  // 06019DEA bra 0x06019DFE ; mov.w r2,@r1
L_06019DEE:
    c.r[1] = ld32(0x06019ECCu);  // 06019DEE mov.l 0x06019ECC,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06019E76u);  // 06019DF0 mov.w 0x06019E76,r2
    st16(c.r[1], c.r[2]);  // 06019DF2 mov.w r2,@r1
    c.r[1] = ld32(0x06019ED0u);  // 06019DF4 mov.l 0x06019ED0,r1
    st16(c.r[1], c.r[2]);  // 06019DF6 mov.w r2,@r1
    c.r[5] = ld32(0x06019EE0u);  // 06019DF8 mov.l 0x06019EE0,r5
    c.r[4] = ld32(0x06019EE4u);  // 06019DFA mov.l 0x06019EE4,r4
    c.r[0] = ld32(0x06019EDCu);  // 06019DFC mov.l 0x06019EDC,r0
L_06019DFE:
    { const uint32_t x = c.r[0]; c.pr = 0x06019E02u; c.r[6] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06019E02u) return; }  // 06019DFE jsr @r0 ; mov #0,r6
    goto L_06019E38;  // 06019E02 bra 0x06019E38 ; nop
L_06019E06:
    c.r[1] = ld32(0x06019ECCu);  // 06019E06 mov.l 0x06019ECC,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06019E78u);  // 06019E08 mov.w 0x06019E78,r2
    st16(c.r[1], c.r[2]);  // 06019E0A mov.w r2,@r1
    c.r[1] = ld32(0x06019ED0u);  // 06019E0C mov.l 0x06019ED0,r1
    st16(c.r[1], c.r[2]);  // 06019E0E mov.w r2,@r1
    c.r[5] = ld32(0x06019EE0u);  // 06019E10 mov.l 0x06019EE0,r5
    c.r[4] = ld32(0x06019EE4u);  // 06019E12 mov.l 0x06019EE4,r4
    c.r[0] = ld32(0x06019EDCu);  // 06019E14 mov.l 0x06019EDC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06019E1Au; c.r[6] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06019E1Au) return; }  // 06019E16 jsr @r0 ; mov #0,r6
    c.r[12] = 0x0u;  // 06019E1A mov #0,r12
    c.r[13] = ld32(0x06019EE8u);  // 06019E1C mov.l 0x06019EE8,r13
    c.r[10] = ld32(0x06019EECu);  // 06019E1E mov.l 0x06019EEC,r10
    c.r[0] = c.r[9];  // 06019E20 mov r9,r0
    st32(c.r[0] + c.r[11], c.r[10]);  // 06019E22 mov.l r10,@(r0,r11)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06019E24 mov.b @r8,r1
    c.r[0] = 0x1u;  // 06019E26 mov #1,r0
    c.r[7] = (uint32_t)(int16_t)ld16(0x06019E7Au);  // 06019E28 mov.w 0x06019E7A,r7
    c.r[5] = (uint32_t)(int16_t)ld16(0x06019E78u);  // 06019E2A mov.w 0x06019E78,r5
    c.r[6] = 0x4u;  // 06019E2C mov #4,r6
    c.r[1] |= c.r[0];  // 06019E2E or r0,r1
    st8(c.r[8], c.r[1]);  // 06019E30 mov.b r1,@r8
    c.r[1] = ld32(0x06019EF0u);  // 06019E32 mov.l 0x06019EF0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06019E38u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06019E38u) return; }  // 06019E34 jsr @r1 ; mov r10,r4
L_06019E38:
    c.r[1] = ld32(0x06019EF4u);  // 06019E38 mov.l 0x06019EF4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06019E3Eu; c.r[4] = 0x3u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06019E3Eu) return; }  // 06019E3A jsr @r1 ; mov #3,r4
    c.r[1] = ld32(0x06019EF8u);  // 06019E3E mov.l 0x06019EF8,r1
    c.r[6] = c.r[12];  // 06019E40 mov r12,r6
    c.r[5] = 0x0u;  // 06019E42 mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06019E48u; c.r[4] = c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06019E48u) return; }  // 06019E44 jsr @r1 ; mov r13,r4
    c.r[1] = ld32(0x06019EFCu);  // 06019E48 mov.l 0x06019EFC,r1
    c.r[7] = c.r[10];  // 06019E4A mov r10,r7
    c.r[6] = c.r[10];  // 06019E4C mov r10,r6
    c.r[5] = c.r[10];  // 06019E4E mov r10,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06019E54u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06019E54u) return; }  // 06019E50 jsr @r1 ; mov r10,r4
L_06019E54:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06019E7Cu);  // 06019E54 mov.w 0x06019E7C,r0
    c.r[15] = c.r[14];  // 06019E56 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06019E58 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06019E5A mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06019E5C mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06019E5E mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06019E60 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06019E62 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06019E64 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06019E66 rts ; mov.l @r15+,r8
}

void f_06019F00(SH2Context& c) {
    ran[233] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06019F00 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06019F02 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06019F04 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06019F06 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06019F08 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06019F0A mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06019F0C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06019F0E sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06019F10 mov r15,r14
    c.r[9] = ld32(0x06019F8Cu);  // 06019F12 mov.l 0x06019F8C,r9
    c.r[5] = ld32(0x06019F90u);  // 06019F14 mov.l 0x06019F90,r5
    st32(c.r[9] + 4, c.r[5]);  // 06019F16 mov.l r5,@(4,r9)
    c.r[2] = ld32(0x06019F94u);  // 06019F18 mov.l 0x06019F94,r2
    c.r[13] = (uint32_t)(int16_t)ld16(0x06019F88u);  // 06019F1A mov.w 0x06019F88,r13
    c.r[8] = ld32(0x06019F98u);  // 06019F1C mov.l 0x06019F98,r8
    c.r[4] = ld32(c.r[2] + 12);  // 06019F1E mov.l @(12,r2),r4
    c.r[12] = 0x1u;  // 06019F20 mov #1,r12
    c.r[1] = ld32(c.r[2]);  // 06019F22 mov.l @r2,r1
    c.r[3] = ld32(0x06019F9Cu);  // 06019F24 mov.l 0x06019F9C,r3
    c.r[6] = ld32(c.r[2] + 4);  // 06019F26 mov.l @(4,r2),r6
    c.r[1] -= 8;  // 06019F28 add #-8,r1
    c.r[6] -= c.r[1];  // 06019F2A sub r1,r6
    c.r[6] &= c.r[13];  // 06019F2C and r13,r6
    st8(c.r[8], c.r[12]);  // 06019F2E mov.b r12,@r8
    { const uint32_t x = c.r[3]; c.pr = 0x06019F34u; c.r[4] += c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06019F34u) return; }  // 06019F30 jsr @r3 ; add r2,r4
    c.r[11] = ld32(0x06019FA0u);  // 06019F34 mov.l 0x06019FA0,r11
    { const uint32_t x = c.r[11]; c.pr = 0x06019F3Au; c.r[10] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06019F3Au) return; }  // 06019F36 jsr @r11 ; mov #0,r10
    st8(c.r[8], c.r[10]);  // 06019F3A mov.b r10,@r8
    c.r[1] = ld32(0x06019FA4u);  // 06019F3C mov.l 0x06019FA4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06019F3E mov.b @r1,r1
    c.r[0] = c.r[1];  // 06019F40 mov r1,r0
    c.r[0] >>= 2;  // 06019F42 shlr2 r0
    c.r[0] &= 0x3u;  // 06019F44 and #3,r0
    c.r[1] = 0x1u;  // 06019F46 mov #1,r1
    c.t = c.r[0] > c.r[1];  // 06019F48 cmp/hi r1,r0
    { const bool k = c.t; c.r[1] = 0x0u; if (k) { goto L_06019F70; } }  // 06019F4A bt/s 0x06019F70 ; mov #0,r1
    c.r[5] = ld32(0x06019FA8u);  // 06019F4E mov.l 0x06019FA8,r5
    st32(c.r[9] + 8, c.r[5]);  // 06019F50 mov.l r5,@(8,r9)
    c.r[2] = ld32(0x06019FACu);  // 06019F52 mov.l 0x06019FAC,r2
    c.r[4] = ld32(c.r[2] + 12);  // 06019F54 mov.l @(12,r2),r4
    c.r[1] = ld32(c.r[2]);  // 06019F56 mov.l @r2,r1
    c.r[3] = ld32(0x06019F9Cu);  // 06019F58 mov.l 0x06019F9C,r3
    c.r[6] = ld32(c.r[2] + 4);  // 06019F5A mov.l @(4,r2),r6
    c.r[1] -= 8;  // 06019F5C add #-8,r1
    c.r[6] -= c.r[1];  // 06019F5E sub r1,r6
    c.r[6] &= c.r[13];  // 06019F60 and r13,r6
    st8(c.r[8], c.r[12]);  // 06019F62 mov.b r12,@r8
    { const uint32_t x = c.r[3]; c.pr = 0x06019F68u; c.r[4] += c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06019F68u) return; }  // 06019F64 jsr @r3 ; add r2,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06019F6Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06019F6Cu) return; }  // 06019F68 jsr @r11 ; nop
    st8(c.r[8], c.r[10]); goto L_06019F72;  // 06019F6C bra 0x06019F72 ; mov.b r10,@r8
L_06019F70:
    st32(c.r[9] + 8, c.r[1]);  // 06019F70 mov.l r1,@(8,r9)
L_06019F72:
    c.r[15] = c.r[14];  // 06019F72 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06019F74 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06019F76 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06019F78 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06019F7A mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06019F7C mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06019F7E mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06019F80 mov.l @r15+,r9
    c.r[0] = ld32(0x06019FB0u);  // 06019F82 mov.l 0x06019FB0,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06019F84 rts ; mov.l @r15+,r8
}

void f_06019FB4(SH2Context& c) {
    ran[234] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06019FB4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06019FB6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06019FB8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06019FBA sts.l pr,@-r15
    c.r[9] = ld32(0x0601A084u);  // 06019FBC mov.l 0x0601A084,r9
    c.r[1] = ld32(c.r[9]);  // 06019FBE mov.l @r9,r1
    c.r[14] = c.r[15];  // 06019FC0 mov r15,r14
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06019FC2 mov.b @r1,r4
    c.r[0] = ld32(0x0601A088u);  // 06019FC4 mov.l 0x0601A088,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06019FCAu; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06019FCAu) return; }  // 06019FC6 jsr @r0 ; extu.b r4,r4
    c.r[8] = c.r[0];  // 06019FCA mov r0,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 06019FCC tst r8,r8
    if (c.t) { goto L_0601A072; }  // 06019FCE bt 0x0601A072
    c.r[3] = ld32(c.r[9]);  // 06019FD0 mov.l @r9,r3
    c.r[1] = c.r[3];  // 06019FD2 mov r3,r1
    c.r[1] += 1;  // 06019FD4 add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06019FD6 mov.b @r1,r2
    c.r[3] += 2;  // 06019FD8 add #2,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06019FDA extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06019FDC mov.b @r3,r1
    c.r[2] <<= 8;  // 06019FDE shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06019FE0 extu.b r1,r1
    c.r[2] |= c.r[1];  // 06019FE2 or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 06019FE4 exts.w r2,r2
    st32(c.r[8] + 4, c.r[2]);  // 06019FE6 mov.l r2,@(4,r8)
    c.r[3] = ld32(c.r[9]);  // 06019FE8 mov.l @r9,r3
    c.r[1] = c.r[3];  // 06019FEA mov r3,r1
    c.r[1] += 3;  // 06019FEC add #3,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06019FEE mov.b @r1,r2
    c.r[3] += 4;  // 06019FF0 add #4,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06019FF2 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06019FF4 mov.b @r3,r1
    c.r[2] <<= 8;  // 06019FF6 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06019FF8 extu.b r1,r1
    c.r[2] |= c.r[1];  // 06019FFA or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 06019FFC exts.w r2,r2
    st32(c.r[8] + 8, c.r[2]);  // 06019FFE mov.l r2,@(8,r8)
    c.r[1] = c.r[8];  // 0601A000 mov r8,r1
    c.r[1] += 56;  // 0601A002 add #56,r1
    c.r[2] = 0x0u;  // 0601A004 mov #0,r2
    st16(c.r[1], c.r[2]);  // 0601A006 mov.w r2,@r1
    c.r[1] = c.r[8];  // 0601A008 mov r8,r1
    c.r[1] += 2;  // 0601A00A add #2,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601A00C mov.b @r1,r0
    c.r[0] &= 0xFCu;  // 0601A00E and #252,r0
    st8(c.r[1], c.r[0]);  // 0601A010 mov.b r0,@r1
    c.r[1] = c.r[8];  // 0601A012 mov r8,r1
    c.r[1] += 58;  // 0601A014 add #58,r1
    st16(c.r[1], c.r[2]);  // 0601A016 mov.w r2,@r1
    c.r[1] = c.r[8];  // 0601A018 mov r8,r1
    c.r[1] += 16;  // 0601A01A add #16,r1
    st16(c.r[1], c.r[2]);  // 0601A01C mov.w r2,@r1
    c.r[1] = c.r[8];  // 0601A01E mov r8,r1
    c.r[1] += 18;  // 0601A020 add #18,r1
    st16(c.r[1], c.r[2]);  // 0601A022 mov.w r2,@r1
    c.r[2] = c.r[8];  // 0601A024 mov r8,r2
    c.r[2] += 64;  // 0601A026 add #64,r2
    c.r[1] = 0xAu;  // 0601A028 mov #10,r1
    st8(c.r[2], c.r[1]);  // 0601A02A mov.b r1,@r2
    c.r[2] = ld32(c.r[9]);  // 0601A02C mov.l @r9,r2
    c.r[1] = c.r[2];  // 0601A02E mov r2,r1
    c.r[1] += 5;  // 0601A030 add #5,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601A032 mov.b @r1,r5
    c.r[2] += 6;  // 0601A034 add #6,r2
    c.r[5] = c.r[5] & 0xFFu;  // 0601A036 extu.b r5,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601A038 mov.b @r2,r1
    c.r[5] <<= 8;  // 0601A03A shll8 r5
    c.r[1] = c.r[1] & 0xFFu;  // 0601A03C extu.b r1,r1
    c.r[5] |= c.r[1];  // 0601A03E or r1,r5
    c.r[1] = ld32(0x0601A08Cu);  // 0601A040 mov.l 0x0601A08C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601A046u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601A046u) return; }  // 0601A042 jsr @r1 ; mov r8,r4
    c.r[3] = ld32(c.r[9]);  // 0601A046 mov.l @r9,r3
    c.r[1] = c.r[3];  // 0601A048 mov r3,r1
    c.r[1] += 7;  // 0601A04A add #7,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601A04C mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0601A04E extu.b r2,r2
    c.r[1] = c.r[3];  // 0601A050 mov r3,r1
    c.r[1] += 8;  // 0601A052 add #8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601A054 mov.b @r1,r1
    c.r[2] <<= 8;  // 0601A056 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0601A058 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0601A05A or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0601A05C exts.w r2,r2
    c.r[2] += 7;  // 0601A05E add #7,r2
    c.r[3] += c.r[2];  // 0601A060 add r2,r3
    st32(c.r[8] + 36, c.r[3]);  // 0601A062 mov.l r3,@(36,r8)
    c.r[1] = ld32(c.r[9]);  // 0601A064 mov.l @r9,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601A080u);  // 0601A066 mov.w 0x0601A080,r0
    c.r[1] += 9;  // 0601A068 add #9,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601A06A mov.b @r1,r1
    c.r[8] += 61;  // 0601A06C add #61,r8
    st8(c.r[8], c.r[1]); goto L_0601A074;  // 0601A06E bra 0x0601A074 ; mov.b r1,@r8
L_0601A072:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601A080u);  // 0601A072 mov.w 0x0601A080,r0
L_0601A074:
    c.r[15] = c.r[14];  // 0601A074 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601A076 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601A078 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0601A07A mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601A07C rts ; mov.l @r15+,r8
}

void f_0601A090(SH2Context& c) {
    ran[235] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601A090 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0601A092 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601A094 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601A096 sts.l pr,@-r15
    c.r[9] = ld32(0x0601A160u);  // 0601A098 mov.l 0x0601A160,r9
    c.r[1] = ld32(c.r[9]);  // 0601A09A mov.l @r9,r1
    c.r[14] = c.r[15];  // 0601A09C mov r15,r14
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601A09E mov.b @r1,r4
    c.r[0] = ld32(0x0601A164u);  // 0601A0A0 mov.l 0x0601A164,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601A0A6u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601A0A6u) return; }  // 0601A0A2 jsr @r0 ; extu.b r4,r4
    c.r[8] = c.r[0];  // 0601A0A6 mov r0,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 0601A0A8 tst r8,r8
    if (c.t) { goto L_0601A14E; }  // 0601A0AA bt 0x0601A14E
    c.r[3] = ld32(c.r[9]);  // 0601A0AC mov.l @r9,r3
    c.r[1] = c.r[3];  // 0601A0AE mov r3,r1
    c.r[1] += 1;  // 0601A0B0 add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601A0B2 mov.b @r1,r2
    c.r[3] += 2;  // 0601A0B4 add #2,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0601A0B6 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0601A0B8 mov.b @r3,r1
    c.r[2] <<= 8;  // 0601A0BA shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0601A0BC extu.b r1,r1
    c.r[2] |= c.r[1];  // 0601A0BE or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0601A0C0 exts.w r2,r2
    st32(c.r[8] + 4, c.r[2]);  // 0601A0C2 mov.l r2,@(4,r8)
    c.r[3] = ld32(c.r[9]);  // 0601A0C4 mov.l @r9,r3
    c.r[1] = c.r[3];  // 0601A0C6 mov r3,r1
    c.r[1] += 3;  // 0601A0C8 add #3,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601A0CA mov.b @r1,r2
    c.r[3] += 4;  // 0601A0CC add #4,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0601A0CE extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0601A0D0 mov.b @r3,r1
    c.r[2] <<= 8;  // 0601A0D2 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0601A0D4 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0601A0D6 or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0601A0D8 exts.w r2,r2
    st32(c.r[8] + 8, c.r[2]);  // 0601A0DA mov.l r2,@(8,r8)
    c.r[1] = c.r[8];  // 0601A0DC mov r8,r1
    c.r[1] += 56;  // 0601A0DE add #56,r1
    c.r[2] = 0x0u;  // 0601A0E0 mov #0,r2
    st16(c.r[1], c.r[2]);  // 0601A0E2 mov.w r2,@r1
    c.r[1] = c.r[8];  // 0601A0E4 mov r8,r1
    c.r[1] += 2;  // 0601A0E6 add #2,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601A0E8 mov.b @r1,r0
    c.r[0] &= 0xFCu;  // 0601A0EA and #252,r0
    st8(c.r[1], c.r[0]);  // 0601A0EC mov.b r0,@r1
    c.r[1] = c.r[8];  // 0601A0EE mov r8,r1
    c.r[1] += 58;  // 0601A0F0 add #58,r1
    st16(c.r[1], c.r[2]);  // 0601A0F2 mov.w r2,@r1
    c.r[1] = c.r[8];  // 0601A0F4 mov r8,r1
    c.r[1] += 16;  // 0601A0F6 add #16,r1
    st16(c.r[1], c.r[2]);  // 0601A0F8 mov.w r2,@r1
    c.r[1] = c.r[8];  // 0601A0FA mov r8,r1
    c.r[1] += 18;  // 0601A0FC add #18,r1
    st16(c.r[1], c.r[2]);  // 0601A0FE mov.w r2,@r1
    c.r[2] = c.r[8];  // 0601A100 mov r8,r2
    c.r[2] += 64;  // 0601A102 add #64,r2
    c.r[1] = 0xAu;  // 0601A104 mov #10,r1
    st8(c.r[2], c.r[1]);  // 0601A106 mov.b r1,@r2
    c.r[3] = ld32(c.r[9]);  // 0601A108 mov.l @r9,r3
    c.r[1] = c.r[3];  // 0601A10A mov r3,r1
    c.r[1] += 5;  // 0601A10C add #5,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601A10E mov.b @r1,r5
    c.r[5] = c.r[5] & 0xFFu;  // 0601A110 extu.b r5,r5
    c.r[1] = c.r[3];  // 0601A112 mov r3,r1
    c.r[1] += 6;  // 0601A114 add #6,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601A116 mov.b @r1,r1
    c.r[5] <<= 8;  // 0601A118 shll8 r5
    c.r[1] = c.r[1] & 0xFFu;  // 0601A11A extu.b r1,r1
    c.r[5] |= c.r[1];  // 0601A11C or r1,r5
    c.r[1] = c.r[3];  // 0601A11E mov r3,r1
    c.r[1] += 7;  // 0601A120 add #7,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601A122 mov.b @r1,r2
    c.r[4] = c.r[8];  // 0601A124 mov r8,r4
    c.r[2] = c.r[2] & 0xFFu;  // 0601A126 extu.b r2,r2
    c.r[1] = c.r[3];  // 0601A128 mov r3,r1
    c.r[1] += 8;  // 0601A12A add #8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601A12C mov.b @r1,r1
    c.r[2] <<= 8;  // 0601A12E shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0601A130 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0601A132 or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0601A134 exts.w r2,r2
    c.r[2] += 7;  // 0601A136 add #7,r2
    c.r[3] += c.r[2];  // 0601A138 add r2,r3
    c.r[1] = ld32(0x0601A168u);  // 0601A13A mov.l 0x0601A168,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601A140u; st32(c.r[8] + 36, c.r[3]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601A140u) return; }  // 0601A13C jsr @r1 ; mov.l r3,@(36,r8)
    c.r[1] = ld32(c.r[9]);  // 0601A140 mov.l @r9,r1
    c.r[8] += 61;  // 0601A142 add #61,r8
    c.r[1] += 9;  // 0601A144 add #9,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601A146 mov.b @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601A15Cu);  // 0601A148 mov.w 0x0601A15C,r0
    st8(c.r[8], c.r[1]); goto L_0601A150;  // 0601A14A bra 0x0601A150 ; mov.b r1,@r8
L_0601A14E:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601A15Cu);  // 0601A14E mov.w 0x0601A15C,r0
L_0601A150:
    c.r[15] = c.r[14];  // 0601A150 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601A152 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601A154 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0601A156 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601A158 rts ; mov.l @r15+,r8
}

void f_0601A16C(SH2Context& c) {
    ran[236] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601A16C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0601A16E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601A170 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601A172 sts.l pr,@-r15
    c.r[9] = ld32(0x0601A23Cu);  // 0601A174 mov.l 0x0601A23C,r9
    c.r[1] = ld32(c.r[9]);  // 0601A176 mov.l @r9,r1
    c.r[14] = c.r[15];  // 0601A178 mov r15,r14
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601A17A mov.b @r1,r4
    c.r[0] = ld32(0x0601A240u);  // 0601A17C mov.l 0x0601A240,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601A182u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601A182u) return; }  // 0601A17E jsr @r0 ; extu.b r4,r4
    c.r[8] = c.r[0];  // 0601A182 mov r0,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 0601A184 tst r8,r8
    { const bool k = c.t; c.r[1] = 0x0u; if (k) { goto L_0601A224; } }  // 0601A186 bt/s 0x0601A224 ; mov #0,r1
    st32(c.r[8] + 4, c.r[1]);  // 0601A18A mov.l r1,@(4,r8)
    st32(c.r[8] + 8, c.r[1]);  // 0601A18C mov.l r1,@(8,r8)
    c.r[1] = c.r[8];  // 0601A18E mov r8,r1
    c.r[1] += 56;  // 0601A190 add #56,r1
    c.r[2] = 0x0u;  // 0601A192 mov #0,r2
    st16(c.r[1], c.r[2]);  // 0601A194 mov.w r2,@r1
    c.r[3] = c.r[8];  // 0601A196 mov r8,r3
    c.r[3] += 2;  // 0601A198 add #2,r3
    c.r[1] = c.r[8];  // 0601A19A mov r8,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0601A19C mov.b @r3,r0
    c.r[1] += 58;  // 0601A19E add #58,r1
    c.r[0] &= 0xFCu;  // 0601A1A0 and #252,r0
    st8(c.r[3], c.r[0]);  // 0601A1A2 mov.b r0,@r3
    st16(c.r[1], c.r[2]);  // 0601A1A4 mov.w r2,@r1
    c.r[1] = c.r[8];  // 0601A1A6 mov r8,r1
    c.r[1] += 16;  // 0601A1A8 add #16,r1
    st16(c.r[1], c.r[2]);  // 0601A1AA mov.w r2,@r1
    c.r[1] = c.r[8];  // 0601A1AC mov r8,r1
    c.r[1] += 18;  // 0601A1AE add #18,r1
    st16(c.r[1], c.r[2]);  // 0601A1B0 mov.w r2,@r1
    c.r[2] = c.r[8];  // 0601A1B2 mov r8,r2
    c.r[2] += 64;  // 0601A1B4 add #64,r2
    c.r[1] = 0xAu;  // 0601A1B6 mov #10,r1
    st8(c.r[2], c.r[1]);  // 0601A1B8 mov.b r1,@r2
    c.r[1] = ld32(c.r[9]);  // 0601A1BA mov.l @r9,r1
    c.r[2] = c.r[8];  // 0601A1BC mov r8,r2
    c.r[1] += 3;  // 0601A1BE add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601A1C0 mov.b @r1,r1
    c.r[2] += 61;  // 0601A1C2 add #61,r2
    st8(c.r[2], c.r[1]);  // 0601A1C4 mov.b r1,@r2
    c.r[1] = ld32(0x0601A244u);  // 0601A1C6 mov.l 0x0601A244,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601A1C8 mov.b @r1,r1
    c.r[5] = ld32(0x0601A248u);  // 0601A1CA mov.l 0x0601A248,r5
    c.r[1] = c.r[1] & 0xFFu;  // 0601A1CC extu.b r1,r1
    c.r[0] = c.r[1];  // 0601A1CE mov r1,r0
    c.r[0] >>= 2;  // 0601A1D0 shlr2 r0
    c.r[0] >>= 2;  // 0601A1D2 shlr2 r0
    c.r[0] >>= 2;  // 0601A1D4 shlr2 r0
    c.r[1] >>= 2;  // 0601A1D6 shlr2 r1
    c.r[1] >>= 2;  // 0601A1D8 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0601A1DA shlr r1
    c.r[1] >>= 2;  // 0601A1DC shlr2 r1
    c.r[0] &= 0x1u;  // 0601A1DE and #1,r0
    c.t = c.r[1] == c.r[0];  // 0601A1E0 cmp/eq r0,r1
    if (c.t) { goto L_0601A204; }  // 0601A1E2 bt 0x0601A204
    c.r[1] = ld32(c.r[8] + 4);  // 0601A1E4 mov.l @(4,r8),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0601A232u);  // 0601A1E6 mov.w 0x0601A232,r2
    c.r[2] -= c.r[1];  // 0601A1E8 sub r1,r2
    st32(c.r[8] + 4, c.r[2]);  // 0601A1EA mov.l r2,@(4,r8)
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601A234u);  // 0601A1EC mov.w 0x0601A234,r1
    c.r[5] ^= c.r[1];  // 0601A1EE xor r1,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0601A1F0 mov.b @r3,r1
    c.r[7] = (uint32_t)(int16_t)ld16(0x0601A236u);  // 0601A1F2 mov.w 0x0601A236,r7
    c.r[0] = c.r[1];  // 0601A1F4 mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0601A1F6 shlr r0
    c.r[0] &= 0x1u;  // 0601A1F8 and #1,r0
    c.r[0] ^= 0x1u;  // 0601A1FA xor #1,r0
    c.r[0] += c.r[0];  // 0601A1FC add r0,r0
    c.r[1] &= c.r[7];  // 0601A1FE and r7,r1
    c.r[1] |= c.r[0];  // 0601A200 or r0,r1
    st8(c.r[3], c.r[1]);  // 0601A202 mov.b r1,@r3
L_0601A204:
    c.r[1] = ld32(0x0601A24Cu);  // 0601A204 mov.l 0x0601A24C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601A20Au; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601A20Au) return; }  // 0601A206 jsr @r1 ; mov r8,r4
    c.r[2] = ld32(c.r[9]);  // 0601A20A mov.l @r9,r2
    c.r[1] = c.r[2];  // 0601A20C mov r2,r1
    c.r[1] += 1;  // 0601A20E add #1,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601A210 mov.b @r1,r5
    c.r[2] += 2;  // 0601A212 add #2,r2
    c.r[5] = c.r[5] & 0xFFu;  // 0601A214 extu.b r5,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601A216 mov.b @r2,r1
    c.r[5] <<= 8;  // 0601A218 shll8 r5
    c.r[1] = c.r[1] & 0xFFu;  // 0601A21A extu.b r1,r1
    c.r[5] |= c.r[1];  // 0601A21C or r1,r5
    c.r[1] = ld32(0x0601A250u);  // 0601A21E mov.l 0x0601A250,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601A224u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601A224u) return; }  // 0601A220 jsr @r1 ; mov r8,r4
L_0601A224:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601A238u);  // 0601A224 mov.w 0x0601A238,r0
    c.r[15] = c.r[14];  // 0601A226 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601A228 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601A22A mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0601A22C mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601A22E rts ; mov.l @r15+,r8
}

void f_0601A254(SH2Context& c) {
    ran[237] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601A254 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601A256 sts.l pr,@-r15
    c.r[1] = ld32(0x0601A28Cu);  // 0601A258 mov.l 0x0601A28C,r1
    c.r[4] = ld32(c.r[1]);  // 0601A25A mov.l @r1,r4
    c.r[2] = ld32(0x0601A290u);  // 0601A25C mov.l 0x0601A290,r2
    c.r[4] += 76;  // 0601A25E add #76,r4
    c.r[1] = ld32(c.r[2]);  // 0601A260 mov.l @r2,r1
    c.r[3] = c.r[4];  // 0601A262 mov r4,r3
    c.r[1] += 2;  // 0601A264 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601A266 mov.b @r1,r1
    c.r[3] += 61;  // 0601A268 add #61,r3
    st8(c.r[3], c.r[1]);  // 0601A26A mov.b r1,@r3
    c.r[1] = ld32(c.r[2]);  // 0601A26C mov.l @r2,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0601A26E mov.b @r1+,r5
    c.r[5] = c.r[5] & 0xFFu;  // 0601A270 extu.b r5,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601A272 mov.b @r1,r1
    c.r[5] <<= 8;  // 0601A274 shll8 r5
    c.r[1] = c.r[1] & 0xFFu;  // 0601A276 extu.b r1,r1
    c.r[5] |= c.r[1];  // 0601A278 or r1,r5
    c.r[1] = ld32(0x0601A294u);  // 0601A27A mov.l 0x0601A294,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601A280u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601A280u) return; }  // 0601A27C jsr @r1 ; mov r15,r14
    c.r[15] = c.r[14];  // 0601A280 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601A282 lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601A28Au);  // 0601A284 mov.w 0x0601A28A,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601A286 rts ; mov.l @r15+,r14
}

void f_0601A298(SH2Context& c) {
    ran[238] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601A298 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601A29A sts.l pr,@-r15
    c.r[1] = ld32(0x0601A2D4u);  // 0601A29C mov.l 0x0601A2D4,r1
    c.r[4] = ld32(c.r[1]);  // 0601A29E mov.l @r1,r4
    c.r[2] = ld32(0x0601A2D8u);  // 0601A2A0 mov.l 0x0601A2D8,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601A2D0u);  // 0601A2A2 mov.w 0x0601A2D0,r1
    c.r[4] += c.r[1];  // 0601A2A4 add r1,r4
    c.r[1] = ld32(c.r[2]);  // 0601A2A6 mov.l @r2,r1
    c.r[3] = c.r[4];  // 0601A2A8 mov r4,r3
    c.r[1] += 2;  // 0601A2AA add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601A2AC mov.b @r1,r1
    c.r[3] += 61;  // 0601A2AE add #61,r3
    st8(c.r[3], c.r[1]);  // 0601A2B0 mov.b r1,@r3
    c.r[1] = ld32(c.r[2]);  // 0601A2B2 mov.l @r2,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0601A2B4 mov.b @r1+,r5
    c.r[5] = c.r[5] & 0xFFu;  // 0601A2B6 extu.b r5,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601A2B8 mov.b @r1,r1
    c.r[5] <<= 8;  // 0601A2BA shll8 r5
    c.r[1] = c.r[1] & 0xFFu;  // 0601A2BC extu.b r1,r1
    c.r[5] |= c.r[1];  // 0601A2BE or r1,r5
    c.r[1] = ld32(0x0601A2DCu);  // 0601A2C0 mov.l 0x0601A2DC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601A2C6u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601A2C6u) return; }  // 0601A2C2 jsr @r1 ; mov r15,r14
    c.r[15] = c.r[14];  // 0601A2C6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601A2C8 lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601A2D2u);  // 0601A2CA mov.w 0x0601A2D2,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601A2CC rts ; mov.l @r15+,r14
}

void f_0601A2E0(SH2Context& c) {
    ran[239] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601A2E0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0601A2E2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0601A2E4 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601A2E6 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601A2E8 sts.l pr,@-r15
    c.r[9] = ld32(0x0601A400u);  // 0601A2EA mov.l 0x0601A400,r9
    c.r[1] = ld32(c.r[9]);  // 0601A2EC mov.l @r9,r1
    c.r[14] = c.r[15];  // 0601A2EE mov r15,r14
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601A2F0 mov.b @r1,r4
    c.r[0] = ld32(0x0601A404u);  // 0601A2F2 mov.l 0x0601A404,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601A2F8u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601A2F8u) return; }  // 0601A2F4 jsr @r0 ; extu.b r4,r4
    c.r[8] = c.r[0];  // 0601A2F8 mov r0,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 0601A2FA tst r8,r8
    { const bool k = c.t; c.r[2] = c.r[8]; if (k) { goto L_0601A3E8; } }  // 0601A2FC bt/s 0x0601A3E8 ; mov r8,r2
    c.r[2] += 65;  // 0601A300 add #65,r2
    c.r[1] = 0x1u;  // 0601A302 mov #1,r1
    st8(c.r[2], c.r[1]);  // 0601A304 mov.b r1,@r2
    c.r[3] = ld32(c.r[9]);  // 0601A306 mov.l @r9,r3
    c.r[1] = c.r[3];  // 0601A308 mov r3,r1
    c.r[1] += 5;  // 0601A30A add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601A30C mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601A30E extu.b r1,r1
    c.r[7] = c.r[1];  // 0601A310 mov r1,r7
    c.r[7] <<= 8;  // 0601A312 shll8 r7
    c.r[1] = c.r[3];  // 0601A314 mov r3,r1
    c.r[1] += 6;  // 0601A316 add #6,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601A318 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601A31A extu.b r1,r1
    c.r[7] |= c.r[1];  // 0601A31C or r1,r7
    c.r[1] = c.r[3];  // 0601A31E mov r3,r1
    c.r[1] += 7;  // 0601A320 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601A322 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601A324 extu.b r1,r1
    c.r[10] = c.r[1];  // 0601A326 mov r1,r10
    c.r[10] <<= 8;  // 0601A328 shll8 r10
    c.r[1] = c.r[3];  // 0601A32A mov r3,r1
    c.r[1] += 8;  // 0601A32C add #8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601A32E mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601A330 extu.b r1,r1
    c.r[10] |= c.r[1];  // 0601A332 or r1,r10
    c.r[1] = c.r[3];  // 0601A334 mov r3,r1
    c.r[1] += 1;  // 0601A336 add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601A338 mov.b @r1,r2
    c.r[3] += 2;  // 0601A33A add #2,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0601A33C extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0601A33E mov.b @r3,r1
    c.r[2] <<= 8;  // 0601A340 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0601A342 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0601A344 or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0601A346 exts.w r2,r2
    st32(c.r[8] + 4, c.r[2]);  // 0601A348 mov.l r2,@(4,r8)
    c.r[3] = ld32(c.r[9]);  // 0601A34A mov.l @r9,r3
    c.r[6] = 0x40u;  // 0601A34C mov #64,r6
    c.r[1] = c.r[3];  // 0601A34E mov r3,r1
    c.r[1] += 3;  // 0601A350 add #3,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601A352 mov.b @r1,r2
    c.r[3] += 4;  // 0601A354 add #4,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0601A356 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0601A358 mov.b @r3,r1
    c.r[2] <<= 8;  // 0601A35A shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0601A35C extu.b r1,r1
    c.r[2] |= c.r[1];  // 0601A35E or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0601A360 exts.w r2,r2
    st32(c.r[8] + 8, c.r[2]);  // 0601A362 mov.l r2,@(8,r8)
    c.r[1] = ld32(0x0601A408u);  // 0601A364 mov.l 0x0601A408,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601A366 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601A368 extu.b r1,r1
    c.r[0] = c.r[1];  // 0601A36A mov r1,r0
    c.r[0] >>= 2;  // 0601A36C shlr2 r0
    c.r[0] >>= 2;  // 0601A36E shlr2 r0
    c.r[0] >>= 2;  // 0601A370 shlr2 r0
    c.r[1] >>= 2;  // 0601A372 shlr2 r1
    c.r[1] >>= 2;  // 0601A374 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0601A376 shlr r1
    c.r[1] >>= 2;  // 0601A378 shlr2 r1
    c.r[0] &= 0x1u;  // 0601A37A and #1,r0
    c.t = c.r[1] == c.r[0];  // 0601A37C cmp/eq r0,r1
    { const bool k = c.t; c.r[7] |= c.r[6]; if (k) { goto L_0601A38C; } }  // 0601A37E bt/s 0x0601A38C ; or r6,r7
    c.r[1] = ld32(c.r[8] + 4);  // 0601A382 mov.l @(4,r8),r1
    c.r[1] = 0u - c.r[1];  // 0601A384 neg r1,r1
    st32(c.r[8] + 4, c.r[1]);  // 0601A386 mov.l r1,@(4,r8)
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601A3F8u);  // 0601A388 mov.w 0x0601A3F8,r1
    c.r[7] ^= c.r[1];  // 0601A38A xor r1,r7
L_0601A38C:
    c.r[1] = c.r[8];  // 0601A38C mov r8,r1
    c.r[1] += 56;  // 0601A38E add #56,r1
    c.r[3] = 0x0u;  // 0601A390 mov #0,r3
    st16(c.r[1], c.r[3]);  // 0601A392 mov.w r3,@r1
    c.r[1] = ld32(0x0601A40Cu);  // 0601A394 mov.l 0x0601A40C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601A39Au; c.r[4] = (uint32_t)(int32_t)(int16_t)c.r[7]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601A39Au) return; }  // 0601A396 jsr @r1 ; exts.w r7,r4
    c.r[0] = c.r[4];  // 0601A39A mov r4,r0
    c.r[0] &= 0x1u;  // 0601A39C and #1,r0
    c.r[1] = c.r[8];  // 0601A39E mov r8,r1
    c.r[1] += 2;  // 0601A3A0 add #2,r1
    c.r[0] += c.r[0];  // 0601A3A2 add r0,r0
    c.r[6] = (uint32_t)(int16_t)ld16(0x0601A3FAu);  // 0601A3A4 mov.w 0x0601A3FA,r6
    c.r[5] = c.r[7];  // 0601A3A6 mov r7,r5
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601A3A8 mov.b @r1,r2
    c.r[2] &= c.r[6];  // 0601A3AA and r6,r2
    c.r[2] |= c.r[0];  // 0601A3AC or r0,r2
    c.r[6] = (uint32_t)(int16_t)ld16(0x0601A3FCu);  // 0601A3AE mov.w 0x0601A3FC,r6
    c.r[2] &= c.r[6];  // 0601A3B0 and r6,r2
    st8(c.r[1], c.r[2]);  // 0601A3B2 mov.b r2,@r1
    c.r[1] = c.r[8];  // 0601A3B4 mov r8,r1
    c.r[1] += 58;  // 0601A3B6 add #58,r1
    st16(c.r[1], c.r[3]);  // 0601A3B8 mov.w r3,@r1
    c.r[1] = ld32(c.r[9]);  // 0601A3BA mov.l @r9,r1
    c.r[2] = c.r[8];  // 0601A3BC mov r8,r2
    c.r[1] += 9;  // 0601A3BE add #9,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601A3C0 mov.b @r1,r1
    c.r[2] += 61;  // 0601A3C2 add #61,r2
    st8(c.r[2], c.r[1]);  // 0601A3C4 mov.b r1,@r2
    c.r[1] = c.r[8];  // 0601A3C6 mov r8,r1
    c.r[1] += 16;  // 0601A3C8 add #16,r1
    st16(c.r[1], c.r[3]);  // 0601A3CA mov.w r3,@r1
    c.r[1] = c.r[8];  // 0601A3CC mov r8,r1
    c.r[1] += 18;  // 0601A3CE add #18,r1
    st16(c.r[1], c.r[3]);  // 0601A3D0 mov.w r3,@r1
    c.r[2] = c.r[8];  // 0601A3D2 mov r8,r2
    c.r[2] += 64;  // 0601A3D4 add #64,r2
    c.r[1] = 0xAu;  // 0601A3D6 mov #10,r1
    st8(c.r[2], c.r[1]);  // 0601A3D8 mov.b r1,@r2
    c.r[1] = ld32(0x0601A410u);  // 0601A3DA mov.l 0x0601A410,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601A3E0u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601A3E0u) return; }  // 0601A3DC jsr @r1 ; mov r8,r4
    c.r[1] = ld32(0x0601A414u);  // 0601A3E0 mov.l 0x0601A414,r1
    c.r[5] = c.r[10];  // 0601A3E2 mov r10,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0601A3E8u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601A3E8u) return; }  // 0601A3E4 jsr @r1 ; mov r8,r4
L_0601A3E8:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601A3FEu);  // 0601A3E8 mov.w 0x0601A3FE,r0
    c.r[15] = c.r[14];  // 0601A3EA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601A3EC lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601A3EE mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0601A3F0 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0601A3F2 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601A3F4 rts ; mov.l @r15+,r8
}

void f_0601A418(SH2Context& c) {
    ran[240] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601A418 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0601A41A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0601A41C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601A41E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601A420 sts.l pr,@-r15
    c.r[9] = ld32(0x0601A538u);  // 0601A422 mov.l 0x0601A538,r9
    c.r[1] = ld32(c.r[9]);  // 0601A424 mov.l @r9,r1
    c.r[14] = c.r[15];  // 0601A426 mov r15,r14
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601A428 mov.b @r1,r4
    c.r[0] = ld32(0x0601A53Cu);  // 0601A42A mov.l 0x0601A53C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601A430u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601A430u) return; }  // 0601A42C jsr @r0 ; extu.b r4,r4
    c.r[8] = c.r[0];  // 0601A430 mov r0,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 0601A432 tst r8,r8
    { const bool k = c.t; c.r[2] = c.r[8]; if (k) { goto L_0601A520; } }  // 0601A434 bt/s 0x0601A520 ; mov r8,r2
    c.r[2] += 65;  // 0601A438 add #65,r2
    c.r[1] = 0x4u;  // 0601A43A mov #4,r1
    st8(c.r[2], c.r[1]);  // 0601A43C mov.b r1,@r2
    c.r[3] = ld32(c.r[9]);  // 0601A43E mov.l @r9,r3
    c.r[1] = c.r[3];  // 0601A440 mov r3,r1
    c.r[1] += 5;  // 0601A442 add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601A444 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601A446 extu.b r1,r1
    c.r[7] = c.r[1];  // 0601A448 mov r1,r7
    c.r[7] <<= 8;  // 0601A44A shll8 r7
    c.r[1] = c.r[3];  // 0601A44C mov r3,r1
    c.r[1] += 6;  // 0601A44E add #6,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601A450 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601A452 extu.b r1,r1
    c.r[7] |= c.r[1];  // 0601A454 or r1,r7
    c.r[1] = c.r[3];  // 0601A456 mov r3,r1
    c.r[1] += 7;  // 0601A458 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601A45A mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601A45C extu.b r1,r1
    c.r[10] = c.r[1];  // 0601A45E mov r1,r10
    c.r[10] <<= 8;  // 0601A460 shll8 r10
    c.r[1] = c.r[3];  // 0601A462 mov r3,r1
    c.r[1] += 8;  // 0601A464 add #8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601A466 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601A468 extu.b r1,r1
    c.r[10] |= c.r[1];  // 0601A46A or r1,r10
    c.r[1] = c.r[3];  // 0601A46C mov r3,r1
    c.r[1] += 1;  // 0601A46E add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601A470 mov.b @r1,r2
    c.r[3] += 2;  // 0601A472 add #2,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0601A474 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0601A476 mov.b @r3,r1
    c.r[2] <<= 8;  // 0601A478 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0601A47A extu.b r1,r1
    c.r[2] |= c.r[1];  // 0601A47C or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0601A47E exts.w r2,r2
    st32(c.r[8] + 4, c.r[2]);  // 0601A480 mov.l r2,@(4,r8)
    c.r[3] = ld32(c.r[9]);  // 0601A482 mov.l @r9,r3
    c.r[6] = 0x40u;  // 0601A484 mov #64,r6
    c.r[1] = c.r[3];  // 0601A486 mov r3,r1
    c.r[1] += 3;  // 0601A488 add #3,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601A48A mov.b @r1,r2
    c.r[3] += 4;  // 0601A48C add #4,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0601A48E extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0601A490 mov.b @r3,r1
    c.r[2] <<= 8;  // 0601A492 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0601A494 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0601A496 or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0601A498 exts.w r2,r2
    st32(c.r[8] + 8, c.r[2]);  // 0601A49A mov.l r2,@(8,r8)
    c.r[1] = ld32(0x0601A540u);  // 0601A49C mov.l 0x0601A540,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601A49E mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601A4A0 extu.b r1,r1
    c.r[0] = c.r[1];  // 0601A4A2 mov r1,r0
    c.r[0] >>= 2;  // 0601A4A4 shlr2 r0
    c.r[0] >>= 2;  // 0601A4A6 shlr2 r0
    c.r[0] >>= 2;  // 0601A4A8 shlr2 r0
    c.r[1] >>= 2;  // 0601A4AA shlr2 r1
    c.r[1] >>= 2;  // 0601A4AC shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0601A4AE shlr r1
    c.r[1] >>= 2;  // 0601A4B0 shlr2 r1
    c.r[0] &= 0x1u;  // 0601A4B2 and #1,r0
    c.t = c.r[1] == c.r[0];  // 0601A4B4 cmp/eq r0,r1
    { const bool k = c.t; c.r[7] |= c.r[6]; if (k) { goto L_0601A4C4; } }  // 0601A4B6 bt/s 0x0601A4C4 ; or r6,r7
    c.r[1] = ld32(c.r[8] + 4);  // 0601A4BA mov.l @(4,r8),r1
    c.r[1] = 0u - c.r[1];  // 0601A4BC neg r1,r1
    st32(c.r[8] + 4, c.r[1]);  // 0601A4BE mov.l r1,@(4,r8)
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601A530u);  // 0601A4C0 mov.w 0x0601A530,r1
    c.r[7] ^= c.r[1];  // 0601A4C2 xor r1,r7
L_0601A4C4:
    c.r[1] = c.r[8];  // 0601A4C4 mov r8,r1
    c.r[1] += 56;  // 0601A4C6 add #56,r1
    c.r[3] = 0x0u;  // 0601A4C8 mov #0,r3
    st16(c.r[1], c.r[3]);  // 0601A4CA mov.w r3,@r1
    c.r[1] = ld32(0x0601A544u);  // 0601A4CC mov.l 0x0601A544,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601A4D2u; c.r[4] = (uint32_t)(int32_t)(int16_t)c.r[7]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601A4D2u) return; }  // 0601A4CE jsr @r1 ; exts.w r7,r4
    c.r[0] = c.r[4];  // 0601A4D2 mov r4,r0
    c.r[0] &= 0x1u;  // 0601A4D4 and #1,r0
    c.r[1] = c.r[8];  // 0601A4D6 mov r8,r1
    c.r[1] += 2;  // 0601A4D8 add #2,r1
    c.r[0] += c.r[0];  // 0601A4DA add r0,r0
    c.r[6] = (uint32_t)(int16_t)ld16(0x0601A532u);  // 0601A4DC mov.w 0x0601A532,r6
    c.r[5] = c.r[7];  // 0601A4DE mov r7,r5
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601A4E0 mov.b @r1,r2
    c.r[2] &= c.r[6];  // 0601A4E2 and r6,r2
    c.r[2] |= c.r[0];  // 0601A4E4 or r0,r2
    c.r[6] = (uint32_t)(int16_t)ld16(0x0601A534u);  // 0601A4E6 mov.w 0x0601A534,r6
    c.r[2] &= c.r[6];  // 0601A4E8 and r6,r2
    st8(c.r[1], c.r[2]);  // 0601A4EA mov.b r2,@r1
    c.r[1] = c.r[8];  // 0601A4EC mov r8,r1
    c.r[1] += 58;  // 0601A4EE add #58,r1
    st16(c.r[1], c.r[3]);  // 0601A4F0 mov.w r3,@r1
    c.r[1] = ld32(c.r[9]);  // 0601A4F2 mov.l @r9,r1
    c.r[2] = c.r[8];  // 0601A4F4 mov r8,r2
    c.r[1] += 9;  // 0601A4F6 add #9,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601A4F8 mov.b @r1,r1
    c.r[2] += 61;  // 0601A4FA add #61,r2
    st8(c.r[2], c.r[1]);  // 0601A4FC mov.b r1,@r2
    c.r[1] = c.r[8];  // 0601A4FE mov r8,r1
    c.r[1] += 16;  // 0601A500 add #16,r1
    st16(c.r[1], c.r[3]);  // 0601A502 mov.w r3,@r1
    c.r[1] = c.r[8];  // 0601A504 mov r8,r1
    c.r[1] += 18;  // 0601A506 add #18,r1
    st16(c.r[1], c.r[3]);  // 0601A508 mov.w r3,@r1
    c.r[2] = c.r[8];  // 0601A50A mov r8,r2
    c.r[2] += 64;  // 0601A50C add #64,r2
    c.r[1] = 0xAu;  // 0601A50E mov #10,r1
    st8(c.r[2], c.r[1]);  // 0601A510 mov.b r1,@r2
    c.r[1] = ld32(0x0601A548u);  // 0601A512 mov.l 0x0601A548,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601A518u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601A518u) return; }  // 0601A514 jsr @r1 ; mov r8,r4
    c.r[1] = ld32(0x0601A54Cu);  // 0601A518 mov.l 0x0601A54C,r1
    c.r[5] = c.r[10];  // 0601A51A mov r10,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0601A520u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601A520u) return; }  // 0601A51C jsr @r1 ; mov r8,r4
L_0601A520:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601A536u);  // 0601A520 mov.w 0x0601A536,r0
    c.r[15] = c.r[14];  // 0601A522 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601A524 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601A526 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0601A528 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0601A52A mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601A52C rts ; mov.l @r15+,r8
}

void f_0601A550(SH2Context& c) {
    ran[241] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601A550 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0601A552 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0601A554 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601A556 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601A558 sts.l pr,@-r15
    c.r[9] = ld32(0x0601A6A0u);  // 0601A55A mov.l 0x0601A6A0,r9
    c.r[1] = ld32(c.r[9]);  // 0601A55C mov.l @r9,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601A55E mov.b @r1,r0
    c.r[14] = c.r[15];  // 0601A560 mov r15,r14
    c.r[1] = 0x7Fu;  // 0601A562 mov #127,r1
    c.r[1] &= c.r[0];  // 0601A564 and r0,r1
    c.r[0] = ld32(0x0601A6A4u);  // 0601A566 mov.l 0x0601A6A4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601A56Cu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601A56Cu) return; }  // 0601A568 jsr @r0 ; mov r1,r4
    c.r[8] = c.r[0];  // 0601A56C mov r0,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 0601A56E tst r8,r8
    if (!c.t) { goto L_0601A576; }  // 0601A570 bf 0x0601A576
    goto L_0601A686;  // 0601A572 bra 0x0601A686 ; nop
L_0601A576:
    c.r[3] = ld32(c.r[9]);  // 0601A576 mov.l @r9,r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0601A578 mov.b @r3,r0
    c.r[0] &= 0x80u;  // 0601A57A and #128,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601A57C tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_0601A59E; } }  // 0601A57E bt/s 0x0601A59E ; mov r3,r1
    c.r[1] += 7;  // 0601A582 add #7,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601A584 mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0601A586 extu.b r2,r2
    c.r[1] = c.r[3];  // 0601A588 mov r3,r1
    c.r[1] += 8;  // 0601A58A add #8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601A58C mov.b @r1,r1
    c.r[2] <<= 8;  // 0601A58E shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0601A590 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0601A592 or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0601A594 exts.w r2,r2
    c.r[2] += 7;  // 0601A596 add #7,r2
    c.r[3] += c.r[2];  // 0601A598 add r2,r3
    st32(c.r[8] + 36, c.r[3]); goto L_0601A5B4;  // 0601A59A bra 0x0601A5B4 ; mov.l r3,@(36,r8)
L_0601A59E:
    c.r[1] += 7;  // 0601A59E add #7,r1
    c.r[3] += 8;  // 0601A5A0 add #8,r3
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601A5A2 mov.b @r1,r5
    c.r[5] = c.r[5] & 0xFFu;  // 0601A5A4 extu.b r5,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0601A5A6 mov.b @r3,r1
    c.r[5] <<= 8;  // 0601A5A8 shll8 r5
    c.r[1] = c.r[1] & 0xFFu;  // 0601A5AA extu.b r1,r1
    c.r[5] |= c.r[1];  // 0601A5AC or r1,r5
    c.r[1] = ld32(0x0601A6A8u);  // 0601A5AE mov.l 0x0601A6A8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601A5B4u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601A5B4u) return; }  // 0601A5B0 jsr @r1 ; mov r8,r4
L_0601A5B4:
    c.r[6] = ld32(0x0601A6A0u);  // 0601A5B4 mov.l 0x0601A6A0,r6
    c.r[1] = ld32(c.r[6]);  // 0601A5B6 mov.l @r6,r1
    c.r[2] = c.r[8];  // 0601A5B8 mov r8,r2
    c.r[1] += 9;  // 0601A5BA add #9,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601A5BC mov.b @r1,r1
    c.r[2] += 65;  // 0601A5BE add #65,r2
    st8(c.r[2], c.r[1]);  // 0601A5C0 mov.b r1,@r2
    c.r[3] = ld32(c.r[6]);  // 0601A5C2 mov.l @r6,r3
    c.r[1] = c.r[3];  // 0601A5C4 mov r3,r1
    c.r[1] += 5;  // 0601A5C6 add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601A5C8 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601A5CA extu.b r1,r1
    c.r[7] = c.r[1];  // 0601A5CC mov r1,r7
    c.r[7] <<= 8;  // 0601A5CE shll8 r7
    c.r[1] = c.r[3];  // 0601A5D0 mov r3,r1
    c.r[1] += 6;  // 0601A5D2 add #6,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601A5D4 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601A5D6 extu.b r1,r1
    c.r[7] |= c.r[1];  // 0601A5D8 or r1,r7
    c.r[1] = c.r[3];  // 0601A5DA mov r3,r1
    c.r[1] += 1;  // 0601A5DC add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601A5DE mov.b @r1,r2
    c.r[3] += 2;  // 0601A5E0 add #2,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0601A5E2 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0601A5E4 mov.b @r3,r1
    c.r[2] <<= 8;  // 0601A5E6 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0601A5E8 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0601A5EA or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0601A5EC exts.w r2,r2
    st32(c.r[8] + 4, c.r[2]);  // 0601A5EE mov.l r2,@(4,r8)
    c.r[3] = ld32(c.r[6]);  // 0601A5F0 mov.l @r6,r3
    c.r[10] = 0x40u;  // 0601A5F2 mov #64,r10
    c.r[1] = c.r[3];  // 0601A5F4 mov r3,r1
    c.r[1] += 3;  // 0601A5F6 add #3,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601A5F8 mov.b @r1,r2
    c.r[3] += 4;  // 0601A5FA add #4,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0601A5FC extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0601A5FE mov.b @r3,r1
    c.r[2] <<= 8;  // 0601A600 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0601A602 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0601A604 or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0601A606 exts.w r2,r2
    st32(c.r[8] + 8, c.r[2]);  // 0601A608 mov.l r2,@(8,r8)
    c.r[1] = ld32(0x0601A6ACu);  // 0601A60A mov.l 0x0601A6AC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601A60C mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601A60E extu.b r1,r1
    c.r[0] = c.r[1];  // 0601A610 mov r1,r0
    c.r[0] >>= 2;  // 0601A612 shlr2 r0
    c.r[0] >>= 2;  // 0601A614 shlr2 r0
    c.r[0] >>= 2;  // 0601A616 shlr2 r0
    c.r[1] >>= 2;  // 0601A618 shlr2 r1
    c.r[1] >>= 2;  // 0601A61A shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0601A61C shlr r1
    c.r[1] >>= 2;  // 0601A61E shlr2 r1
    c.r[0] &= 0x1u;  // 0601A620 and #1,r0
    c.t = c.r[1] == c.r[0];  // 0601A622 cmp/eq r0,r1
    { const bool k = c.t; c.r[7] |= c.r[10]; if (k) { goto L_0601A632; } }  // 0601A624 bt/s 0x0601A632 ; or r10,r7
    c.r[1] = ld32(c.r[8] + 4);  // 0601A628 mov.l @(4,r8),r1
    c.r[1] = 0u - c.r[1];  // 0601A62A neg r1,r1
    st32(c.r[8] + 4, c.r[1]);  // 0601A62C mov.l r1,@(4,r8)
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601A696u);  // 0601A62E mov.w 0x0601A696,r1
    c.r[7] ^= c.r[1];  // 0601A630 xor r1,r7
L_0601A632:
    c.r[1] = c.r[8];  // 0601A632 mov r8,r1
    c.r[1] += 56;  // 0601A634 add #56,r1
    c.r[3] = 0x0u;  // 0601A636 mov #0,r3
    st16(c.r[1], c.r[3]);  // 0601A638 mov.w r3,@r1
    c.r[1] = ld32(0x0601A6B0u);  // 0601A63A mov.l 0x0601A6B0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601A640u; c.r[4] = (uint32_t)(int32_t)(int16_t)c.r[7]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601A640u) return; }  // 0601A63C jsr @r1 ; exts.w r7,r4
    c.r[0] = c.r[4];  // 0601A640 mov r4,r0
    c.r[0] &= 0x1u;  // 0601A642 and #1,r0
    c.r[1] = c.r[8];  // 0601A644 mov r8,r1
    c.r[1] += 2;  // 0601A646 add #2,r1
    c.r[0] += c.r[0];  // 0601A648 add r0,r0
    c.r[10] = (uint32_t)(int16_t)ld16(0x0601A698u);  // 0601A64A mov.w 0x0601A698,r10
    c.r[5] = c.r[7];  // 0601A64C mov r7,r5
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601A64E mov.b @r1,r2
    c.r[2] &= c.r[10];  // 0601A650 and r10,r2
    c.r[2] |= c.r[0];  // 0601A652 or r0,r2
    c.r[10] = (uint32_t)(int16_t)ld16(0x0601A69Au);  // 0601A654 mov.w 0x0601A69A,r10
    c.r[2] &= c.r[10];  // 0601A656 and r10,r2
    st8(c.r[1], c.r[2]);  // 0601A658 mov.b r2,@r1
    c.r[1] = c.r[8];  // 0601A65A mov r8,r1
    c.r[1] += 58;  // 0601A65C add #58,r1
    st16(c.r[1], c.r[3]);  // 0601A65E mov.w r3,@r1
    c.r[1] = ld32(c.r[6]);  // 0601A660 mov.l @r6,r1
    c.r[2] = c.r[8];  // 0601A662 mov r8,r2
    c.r[1] += 10;  // 0601A664 add #10,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601A666 mov.b @r1,r1
    c.r[2] += 61;  // 0601A668 add #61,r2
    st8(c.r[2], c.r[1]);  // 0601A66A mov.b r1,@r2
    c.r[1] = c.r[8];  // 0601A66C mov r8,r1
    c.r[1] += 16;  // 0601A66E add #16,r1
    st16(c.r[1], c.r[3]);  // 0601A670 mov.w r3,@r1
    c.r[1] = c.r[8];  // 0601A672 mov r8,r1
    c.r[1] += 18;  // 0601A674 add #18,r1
    st16(c.r[1], c.r[3]);  // 0601A676 mov.w r3,@r1
    c.r[2] = c.r[8];  // 0601A678 mov r8,r2
    c.r[2] += 64;  // 0601A67A add #64,r2
    c.r[1] = 0xAu;  // 0601A67C mov #10,r1
    st8(c.r[2], c.r[1]);  // 0601A67E mov.b r1,@r2
    c.r[1] = ld32(0x0601A6B4u);  // 0601A680 mov.l 0x0601A6B4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601A686u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601A686u) return; }  // 0601A682 jsr @r1 ; mov r8,r4
L_0601A686:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601A69Cu);  // 0601A686 mov.w 0x0601A69C,r0
    c.r[15] = c.r[14];  // 0601A688 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601A68A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601A68C mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0601A68E mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0601A690 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601A692 rts ; mov.l @r15+,r8
}

void f_0601A6B8(SH2Context& c) {
    ran[242] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601A6B8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0601A6BA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0601A6BC mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601A6BE mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601A6C0 sts.l pr,@-r15
    c.r[9] = ld32(0x0601A7E0u);  // 0601A6C2 mov.l 0x0601A7E0,r9
    c.r[1] = ld32(c.r[9]);  // 0601A6C4 mov.l @r9,r1
    c.r[14] = c.r[15];  // 0601A6C6 mov r15,r14
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601A6C8 mov.b @r1,r4
    c.r[0] = ld32(0x0601A7E4u);  // 0601A6CA mov.l 0x0601A7E4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601A6D0u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601A6D0u) return; }  // 0601A6CC jsr @r0 ; extu.b r4,r4
    c.r[8] = c.r[0];  // 0601A6D0 mov r0,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 0601A6D2 tst r8,r8
    if (!c.t) { goto L_0601A6DE; }  // 0601A6D4 bf 0x0601A6DE
    c.r[15] = c.r[14];  // 0601A6D6 mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601A7D6u);  // 0601A6D8 mov.w 0x0601A7D6,r0
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; } goto L_0601A7CC;  // 0601A6DA bra 0x0601A7CC ; lds.l @r15+,pr
L_0601A6DE:
    c.r[3] = ld32(c.r[9]);  // 0601A6DE mov.l @r9,r3
    c.r[1] = c.r[3];  // 0601A6E0 mov r3,r1
    c.r[1] += 1;  // 0601A6E2 add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601A6E4 mov.b @r1,r2
    c.r[3] += 2;  // 0601A6E6 add #2,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0601A6E8 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0601A6EA mov.b @r3,r1
    c.r[2] <<= 8;  // 0601A6EC shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0601A6EE extu.b r1,r1
    c.r[2] |= c.r[1];  // 0601A6F0 or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0601A6F2 exts.w r2,r2
    st32(c.r[8] + 4, c.r[2]);  // 0601A6F4 mov.l r2,@(4,r8)
    c.r[3] = ld32(c.r[9]);  // 0601A6F6 mov.l @r9,r3
    c.r[1] = c.r[3];  // 0601A6F8 mov r3,r1
    c.r[1] += 3;  // 0601A6FA add #3,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601A6FC mov.b @r1,r2
    c.r[3] += 4;  // 0601A6FE add #4,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0601A700 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0601A702 mov.b @r3,r1
    c.r[2] <<= 8;  // 0601A704 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0601A706 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0601A708 or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0601A70A exts.w r2,r2
    st32(c.r[8] + 8, c.r[2]);  // 0601A70C mov.l r2,@(8,r8)
    c.r[2] = ld32(c.r[9]);  // 0601A70E mov.l @r9,r2
    c.r[1] = c.r[2];  // 0601A710 mov r2,r1
    c.r[1] += 5;  // 0601A712 add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601A714 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601A716 extu.b r1,r1
    c.r[5] = c.r[1];  // 0601A718 mov r1,r5
    c.r[5] <<= 8;  // 0601A71A shll8 r5
    c.r[1] = c.r[2];  // 0601A71C mov r2,r1
    c.r[1] += 6;  // 0601A71E add #6,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601A720 mov.b @r1,r1
    c.r[3] = c.r[8];  // 0601A722 mov r8,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0601A724 extu.b r1,r1
    c.r[5] |= c.r[1];  // 0601A726 or r1,r5
    c.r[1] = c.r[2];  // 0601A728 mov r2,r1
    c.r[1] += 7;  // 0601A72A add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601A72C mov.b @r1,r1
    c.r[2] += 8;  // 0601A72E add #8,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0601A730 extu.b r1,r1
    c.r[10] = c.r[1];  // 0601A732 mov r1,r10
    c.r[10] <<= 8;  // 0601A734 shll8 r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601A736 mov.b @r2,r1
    c.r[3] += 2;  // 0601A738 add #2,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0601A73A extu.b r1,r1
    c.r[10] |= c.r[1];  // 0601A73C or r1,r10
    c.r[1] = c.r[8];  // 0601A73E mov r8,r1
    c.r[1] += 56;  // 0601A740 add #56,r1
    c.r[2] = 0x0u;  // 0601A742 mov #0,r2
    st16(c.r[1], c.r[2]);  // 0601A744 mov.w r2,@r1
    c.r[1] = c.r[8];  // 0601A746 mov r8,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0601A748 mov.b @r3,r0
    c.r[1] += 58;  // 0601A74A add #58,r1
    c.r[0] &= 0xFCu;  // 0601A74C and #252,r0
    st8(c.r[3], c.r[0]);  // 0601A74E mov.b r0,@r3
    st16(c.r[1], c.r[2]);  // 0601A750 mov.w r2,@r1
    c.r[1] = c.r[8];  // 0601A752 mov r8,r1
    c.r[1] += 16;  // 0601A754 add #16,r1
    st16(c.r[1], c.r[2]);  // 0601A756 mov.w r2,@r1
    c.r[1] = c.r[8];  // 0601A758 mov r8,r1
    c.r[1] += 18;  // 0601A75A add #18,r1
    st16(c.r[1], c.r[2]);  // 0601A75C mov.w r2,@r1
    c.r[2] = c.r[8];  // 0601A75E mov r8,r2
    c.r[2] += 64;  // 0601A760 add #64,r2
    c.r[1] = 0xAu;  // 0601A762 mov #10,r1
    st8(c.r[2], c.r[1]);  // 0601A764 mov.b r1,@r2
    c.r[1] = ld32(c.r[9]);  // 0601A766 mov.l @r9,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601A768 mov.b @r1,r0
    c.r[0] &= 0x80u;  // 0601A76A and #128,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601A76C tst r0,r0
    if (!c.t) { goto L_0601A7AC; }  // 0601A76E bf 0x0601A7AC
    c.r[1] = ld32(0x0601A7E8u);  // 0601A770 mov.l 0x0601A7E8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601A772 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601A774 extu.b r1,r1
    c.r[0] = c.r[1];  // 0601A776 mov r1,r0
    c.r[0] >>= 2;  // 0601A778 shlr2 r0
    c.r[0] >>= 2;  // 0601A77A shlr2 r0
    c.r[0] >>= 2;  // 0601A77C shlr2 r0
    c.r[1] >>= 2;  // 0601A77E shlr2 r1
    c.r[1] >>= 2;  // 0601A780 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0601A782 shlr r1
    c.r[1] >>= 2;  // 0601A784 shlr2 r1
    c.r[0] &= 0x1u;  // 0601A786 and #1,r0
    c.t = c.r[1] == c.r[0];  // 0601A788 cmp/eq r0,r1
    if (c.t) { goto L_0601A7AC; }  // 0601A78A bt 0x0601A7AC
    c.r[1] = ld32(c.r[8] + 4);  // 0601A78C mov.l @(4,r8),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0601A7D8u);  // 0601A78E mov.w 0x0601A7D8,r2
    c.r[2] -= c.r[1];  // 0601A790 sub r1,r2
    st32(c.r[8] + 4, c.r[2]);  // 0601A792 mov.l r2,@(4,r8)
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601A7DAu);  // 0601A794 mov.w 0x0601A7DA,r1
    c.r[5] ^= c.r[1];  // 0601A796 xor r1,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0601A798 mov.b @r3,r1
    c.r[7] = (uint32_t)(int16_t)ld16(0x0601A7DCu);  // 0601A79A mov.w 0x0601A7DC,r7
    c.r[0] = c.r[1];  // 0601A79C mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0601A79E shlr r0
    c.r[0] &= 0x1u;  // 0601A7A0 and #1,r0
    c.r[0] ^= 0x1u;  // 0601A7A2 xor #1,r0
    c.r[0] += c.r[0];  // 0601A7A4 add r0,r0
    c.r[1] &= c.r[7];  // 0601A7A6 and r7,r1
    c.r[1] |= c.r[0];  // 0601A7A8 or r0,r1
    st8(c.r[3], c.r[1]);  // 0601A7AA mov.b r1,@r3
L_0601A7AC:
    c.r[1] = ld32(0x0601A7ECu);  // 0601A7AC mov.l 0x0601A7EC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601A7B2u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601A7B2u) return; }  // 0601A7AE jsr @r1 ; mov r8,r4
    c.r[1] = ld32(0x0601A7F0u);  // 0601A7B2 mov.l 0x0601A7F0,r1
    c.r[5] = c.r[10];  // 0601A7B4 mov r10,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0601A7BAu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601A7BAu) return; }  // 0601A7B6 jsr @r1 ; mov r8,r4
    c.r[1] = ld32(0x0601A7E0u);  // 0601A7BA mov.l 0x0601A7E0,r1
    c.r[1] = ld32(c.r[1]);  // 0601A7BC mov.l @r1,r1
    c.r[8] += 61;  // 0601A7BE add #61,r8
    c.r[1] += 9;  // 0601A7C0 add #9,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601A7C2 mov.b @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601A7D6u);  // 0601A7C4 mov.w 0x0601A7D6,r0
    st8(c.r[8], c.r[1]);  // 0601A7C6 mov.b r1,@r8
    c.r[15] = c.r[14];  // 0601A7C8 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601A7CA lds.l @r15+,pr
L_0601A7CC:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601A7CC mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0601A7CE mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0601A7D0 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601A7D2 rts ; mov.l @r15+,r8
}

void f_0601A7F4(SH2Context& c) {
    ran[243] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601A7F4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0601A7F6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601A7F8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601A7FA sts.l pr,@-r15
    c.r[9] = ld32(0x0601A894u);  // 0601A7FC mov.l 0x0601A894,r9
    c.r[1] = ld32(c.r[9]);  // 0601A7FE mov.l @r9,r1
    c.r[14] = c.r[15];  // 0601A800 mov r15,r14
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601A802 mov.b @r1,r4
    c.r[0] = ld32(0x0601A898u);  // 0601A804 mov.l 0x0601A898,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601A80Au; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601A80Au) return; }  // 0601A806 jsr @r0 ; extu.b r4,r4
    c.r[8] = c.r[0];  // 0601A80A mov r0,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 0601A80C tst r8,r8
    { const bool k = c.t; c.r[2] = 0x0u; if (k) { goto L_0601A882; } }  // 0601A80E bt/s 0x0601A882 ; mov #0,r2
    c.r[1] = ld32(0x0601A89Cu);  // 0601A812 mov.l 0x0601A89C,r1
    c.r[1] = ld32(c.r[1]);  // 0601A814 mov.l @r1,r1
    st32(c.r[8] + 4, c.r[1]);  // 0601A816 mov.l r1,@(4,r8)
    c.r[1] = ld32(0x0601A8A0u);  // 0601A818 mov.l 0x0601A8A0,r1
    c.r[1] = ld32(c.r[1]);  // 0601A81A mov.l @r1,r1
    st32(c.r[8] + 8, c.r[1]);  // 0601A81C mov.l r1,@(8,r8)
    c.r[1] = c.r[8];  // 0601A81E mov r8,r1
    c.r[1] += 56;  // 0601A820 add #56,r1
    st16(c.r[1], c.r[2]);  // 0601A822 mov.w r2,@r1
    c.r[1] = c.r[8];  // 0601A824 mov r8,r1
    c.r[1] += 2;  // 0601A826 add #2,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601A828 mov.b @r1,r0
    c.r[0] &= 0xFCu;  // 0601A82A and #252,r0
    st8(c.r[1], c.r[0]);  // 0601A82C mov.b r0,@r1
    c.r[1] = ld32(c.r[9]);  // 0601A82E mov.l @r9,r1
    c.r[3] = c.r[8];  // 0601A830 mov r8,r3
    c.r[1] += 5;  // 0601A832 add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601A834 mov.b @r1,r1
    c.r[3] += 61;  // 0601A836 add #61,r3
    st8(c.r[3], c.r[1]);  // 0601A838 mov.b r1,@r3
    c.r[1] = c.r[8];  // 0601A83A mov r8,r1
    c.r[1] += 16;  // 0601A83C add #16,r1
    st16(c.r[1], c.r[2]);  // 0601A83E mov.w r2,@r1
    c.r[1] = c.r[8];  // 0601A840 mov r8,r1
    c.r[1] += 18;  // 0601A842 add #18,r1
    st16(c.r[1], c.r[2]);  // 0601A844 mov.w r2,@r1
    c.r[2] = c.r[8];  // 0601A846 mov r8,r2
    c.r[2] += 64;  // 0601A848 add #64,r2
    c.r[1] = 0xAu;  // 0601A84A mov #10,r1
    st8(c.r[2], c.r[1]);  // 0601A84C mov.b r1,@r2
    c.r[2] = ld32(c.r[9]);  // 0601A84E mov.l @r9,r2
    c.r[1] = c.r[2];  // 0601A850 mov r2,r1
    c.r[1] += 1;  // 0601A852 add #1,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601A854 mov.b @r1,r5
    c.r[2] += 2;  // 0601A856 add #2,r2
    c.r[5] = c.r[5] & 0xFFu;  // 0601A858 extu.b r5,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601A85A mov.b @r2,r1
    c.r[5] <<= 8;  // 0601A85C shll8 r5
    c.r[1] = c.r[1] & 0xFFu;  // 0601A85E extu.b r1,r1
    c.r[5] |= c.r[1];  // 0601A860 or r1,r5
    c.r[1] = ld32(0x0601A8A4u);  // 0601A862 mov.l 0x0601A8A4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601A868u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601A868u) return; }  // 0601A864 jsr @r1 ; mov r8,r4
    c.r[2] = ld32(c.r[9]);  // 0601A868 mov.l @r9,r2
    c.r[1] = c.r[2];  // 0601A86A mov r2,r1
    c.r[1] += 3;  // 0601A86C add #3,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601A86E mov.b @r1,r5
    c.r[2] += 4;  // 0601A870 add #4,r2
    c.r[5] = c.r[5] & 0xFFu;  // 0601A872 extu.b r5,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601A874 mov.b @r2,r1
    c.r[5] <<= 8;  // 0601A876 shll8 r5
    c.r[1] = c.r[1] & 0xFFu;  // 0601A878 extu.b r1,r1
    c.r[5] |= c.r[1];  // 0601A87A or r1,r5
    c.r[1] = ld32(0x0601A8A8u);  // 0601A87C mov.l 0x0601A8A8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601A882u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601A882u) return; }  // 0601A87E jsr @r1 ; mov r8,r4
L_0601A882:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601A890u);  // 0601A882 mov.w 0x0601A890,r0
    c.r[15] = c.r[14];  // 0601A884 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601A886 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601A888 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0601A88A mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601A88C rts ; mov.l @r15+,r8
}

void f_0601A8AC(SH2Context& c) {
    ran[244] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601A8AC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601A8AE sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0601A8B0 mov r15,r14
    c.r[0] = ld32(0x0601A8ECu);  // 0601A8B2 mov.l 0x0601A8EC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601A8B8u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601A8B8u) return; }  // 0601A8B4 jsr @r0 ; mov #1,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601A8B8 tst r0,r0
    { const bool k = c.t; c.r[3] = c.r[0]; if (k) { goto L_0601A8DE; } }  // 0601A8BA bt/s 0x0601A8DE ; mov r0,r3
    c.r[2] = ld32(0x0601A8F0u);  // 0601A8BE mov.l 0x0601A8F0,r2
    c.r[1] = ld32(c.r[2]);  // 0601A8C0 mov.l @r2,r1
    c.r[1] += 2;  // 0601A8C2 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601A8C4 mov.b @r1,r1
    c.r[3] += 61;  // 0601A8C6 add #61,r3
    st8(c.r[3], c.r[1]);  // 0601A8C8 mov.b r1,@r3
    c.r[1] = ld32(c.r[2]);  // 0601A8CA mov.l @r2,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0601A8CC mov.b @r1+,r5
    c.r[5] = c.r[5] & 0xFFu;  // 0601A8CE extu.b r5,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601A8D0 mov.b @r1,r1
    c.r[5] <<= 8;  // 0601A8D2 shll8 r5
    c.r[1] = c.r[1] & 0xFFu;  // 0601A8D4 extu.b r1,r1
    c.r[5] |= c.r[1];  // 0601A8D6 or r1,r5
    c.r[1] = ld32(0x0601A8F4u);  // 0601A8D8 mov.l 0x0601A8F4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601A8DEu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601A8DEu) return; }  // 0601A8DA jsr @r1 ; mov r0,r4
L_0601A8DE:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601A8E8u);  // 0601A8DE mov.w 0x0601A8E8,r0
    c.r[15] = c.r[14];  // 0601A8E0 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601A8E2 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601A8E4 rts ; mov.l @r15+,r14
}

void f_0601A8F8(SH2Context& c) {
    ran[245] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601A8F8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601A8FA sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0601A8FC mov r15,r14
    c.r[0] = ld32(0x0601A938u);  // 0601A8FE mov.l 0x0601A938,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601A904u; c.r[4] = 0x4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601A904u) return; }  // 0601A900 jsr @r0 ; mov #4,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601A904 tst r0,r0
    { const bool k = c.t; c.r[3] = c.r[0]; if (k) { goto L_0601A92A; } }  // 0601A906 bt/s 0x0601A92A ; mov r0,r3
    c.r[2] = ld32(0x0601A93Cu);  // 0601A90A mov.l 0x0601A93C,r2
    c.r[1] = ld32(c.r[2]);  // 0601A90C mov.l @r2,r1
    c.r[1] += 2;  // 0601A90E add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601A910 mov.b @r1,r1
    c.r[3] += 61;  // 0601A912 add #61,r3
    st8(c.r[3], c.r[1]);  // 0601A914 mov.b r1,@r3
    c.r[1] = ld32(c.r[2]);  // 0601A916 mov.l @r2,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0601A918 mov.b @r1+,r5
    c.r[5] = c.r[5] & 0xFFu;  // 0601A91A extu.b r5,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601A91C mov.b @r1,r1
    c.r[5] <<= 8;  // 0601A91E shll8 r5
    c.r[1] = c.r[1] & 0xFFu;  // 0601A920 extu.b r1,r1
    c.r[5] |= c.r[1];  // 0601A922 or r1,r5
    c.r[1] = ld32(0x0601A940u);  // 0601A924 mov.l 0x0601A940,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601A92Au; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601A92Au) return; }  // 0601A926 jsr @r1 ; mov r0,r4
L_0601A92A:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601A934u);  // 0601A92A mov.w 0x0601A934,r0
    c.r[15] = c.r[14];  // 0601A92C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601A92E lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601A930 rts ; mov.l @r15+,r14
}

void f_0601A944(SH2Context& c) {
    ran[246] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601A944 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601A946 sts.l pr,@-r15
    c.r[1] = ld32(0x0601A97Cu);  // 0601A948 mov.l 0x0601A97C,r1
    c.r[1] = ld32(c.r[1]);  // 0601A94A mov.l @r1,r1
    c.r[1] += 1;  // 0601A94C add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601A94E mov.b @r1,r1
    c.r[14] = c.r[15];  // 0601A950 mov r15,r14
    c.r[0] = c.r[1] & 0xFFu;  // 0601A952 extu.b r1,r0
    c.r[0] += c.r[0];  // 0601A954 add r0,r0
    c.r[1] = ld32(0x0601A980u);  // 0601A956 mov.l 0x0601A980,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601A958 mov.b @(r0,r1),r4
    c.r[7] = ld32(0x0601A984u);  // 0601A95A mov.l 0x0601A984,r7
    c.r[4] = c.r[4] & 0xFFu;  // 0601A95C extu.b r4,r4
    c.r[0] = c.r[4];  // 0601A95E mov r4,r0
    c.r[0] += c.r[0];  // 0601A960 add r0,r0
    c.r[1] = ld32(0x0601A988u);  // 0601A962 mov.l 0x0601A988,r1
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0601A964 mov.w @(r0,r1),r6
    c.r[5] = 0x4u;  // 0601A966 mov #4,r5
    c.r[1] = 0x1u;  // 0601A968 mov #1,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0601A96A mov.l r1,@-r15
    c.r[1] = ld32(0x0601A98Cu);  // 0601A96C mov.l 0x0601A98C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601A972u; c.r[6] = c.r[6] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601A972u) return; }  // 0601A96E jsr @r1 ; extu.w r6,r6
    c.r[15] = c.r[14];  // 0601A972 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601A974 lds.l @r15+,pr
    c.r[0] = ld32(0x0601A990u);  // 0601A976 mov.l 0x0601A990,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601A978 rts ; mov.l @r15+,r14
}

void f_0601A994(SH2Context& c) {
    ran[247] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601A994 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0601A996 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0601A998 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0601A99A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0601A99C mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0601A99E mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601A9A0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601A9A2 sts.l pr,@-r15
    c.r[1] = ld32(0x0601AAE8u);  // 0601A9A4 mov.l 0x0601AAE8,r1
    c.r[1] = ld32(c.r[1]);  // 0601A9A6 mov.l @r1,r1
    c.r[15] -= 36;  // 0601A9A8 add #-36,r15
    c.r[1] += 1;  // 0601A9AA add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601A9AC mov.b @r1,r1
    c.r[14] = c.r[15];  // 0601A9AE mov r15,r14
    c.r[0] = c.r[1] & 0xFFu;  // 0601A9B0 extu.b r1,r0
    c.r[0] += c.r[0];  // 0601A9B2 add r0,r0
    c.r[1] = ld32(0x0601AAECu);  // 0601A9B4 mov.l 0x0601AAEC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601A9B6 mov.b @(r0,r1),r1
    c.r[3] = ld32(0x0601AAF0u);  // 0601A9B8 mov.l 0x0601AAF0,r3
    c.r[6] = c.r[1] & 0xFFu;  // 0601A9BA extu.b r1,r6
    c.r[2] = c.r[6];  // 0601A9BC mov r6,r2
    c.r[2] += c.r[2];  // 0601A9BE add r2,r2
    c.r[2] += c.r[6];  // 0601A9C0 add r6,r2
    c.r[2] <<= 2;  // 0601A9C2 shll2 r2
    c.r[1] = c.r[2];  // 0601A9C4 mov r2,r1
    c.r[1] += c.r[3];  // 0601A9C6 add r3,r1
    c.r[1] += 2;  // 0601A9C8 add #2,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0601A9CA mov.w @r1,r1
    c.r[12] = ld32(0x0601AAF4u);  // 0601A9CC mov.l 0x0601AAF4,r12
    c.r[0] = c.r[1] & 0xFFFFu;  // 0601A9CE extu.w r1,r0
    c.t = c.r[0] == 0x3u;  // 0601A9D0 cmp/eq #3,r0
    { const bool k = c.t; c.r[4] = ld32(c.r[12] + 12); if (k) { goto L_0601A9DC; } }  // 0601A9D2 bt/s 0x0601A9DC ; mov.l @(12,r12),r4
    c.r[1] = ld32(0x0601AAF8u);  // 0601A9D6 mov.l 0x0601AAF8,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]); goto L_0601A9E0;  // 0601A9D8 bra 0x0601A9E0 ; mov.w @r1,r1
L_0601A9DC:
    c.r[1] = ld32(0x0601AAFCu);  // 0601A9DC mov.l 0x0601AAFC,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0601A9DE mov.w @r1,r1
L_0601A9E0:
    c.r[0] = c.r[3];  // 0601A9E0 mov r3,r0
    st16(c.r[0] + c.r[2], c.r[1]);  // 0601A9E2 mov.w r1,@(r0,r2)
    c.r[11] = c.r[6];  // 0601A9E4 mov r6,r11
    c.r[11] += c.r[11];  // 0601A9E6 add r11,r11
    c.r[6] += c.r[11];  // 0601A9E8 add r11,r6
    st32(c.r[14] + 28, c.r[6]);  // 0601A9EA mov.l r6,@(28,r14)
    c.r[13] = c.r[6];  // 0601A9EC mov r6,r13
    c.r[13] <<= 2;  // 0601A9EE shll2 r13
    st32(c.r[14] + 28, c.r[13]);  // 0601A9F0 mov.l r13,@(28,r14)
    c.r[0] = ld32(0x0601AAF0u);  // 0601A9F2 mov.l 0x0601AAF0,r0
    c.r[1] = ld32(0x0601AB00u);  // 0601A9F4 mov.l 0x0601AB00,r1
    c.r[9] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[13]);  // 0601A9F6 mov.w @(r0,r13),r9
    c.r[6] = c.r[14];  // 0601A9F8 mov r14,r6
    c.r[9] = c.r[9] & 0xFFFFu;  // 0601A9FA extu.w r9,r9
    c.r[9] <<= 2;  // 0601A9FC shll2 r9
    c.r[9] += c.r[9];  // 0601A9FE add r9,r9
    c.r[9] <<= 2;  // 0601AA00 shll2 r9
    c.r[9] += c.r[1];  // 0601AA02 add r1,r9
    c.r[1] = ld32(0x0601AB04u);  // 0601AA04 mov.l 0x0601AB04,r1
    c.r[5] = ld32(c.r[1]);  // 0601AA06 mov.l @r1,r5
    c.r[13] = ld32(0x0601AB08u);  // 0601AA08 mov.l 0x0601AB08,r13
    c.r[1] = ld32(0x0601AAF4u);  // 0601AA0A mov.l 0x0601AAF4,r1
    { const uint32_t x = c.r[13]; c.pr = 0x0601AA10u; c.r[4] += c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601AA10u) return; }  // 0601AA0C jsr @r13 ; add r1,r4
    c.r[1] = c.r[14];  // 0601AA10 mov r14,r1
    c.r[1] += 4;  // 0601AA12 add #4,r1
    c.r[10] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0601AA14 mov.w @r1,r10
    c.r[0] = ld32(0x0601AB0Cu);  // 0601AA16 mov.l 0x0601AB0C,r0
    c.r[5] = ld32(c.r[14] + 8);  // 0601AA18 mov.l @(8,r14),r5
    c.r[10] = c.r[10] & 0xFFFFu;  // 0601AA1A extu.w r10,r10
    c.r[10] >>= 2;  // 0601AA1C shlr2 r10
    c.r[10] >>= 2;  // 0601AA1E shlr2 r10
    c.r[1] = ld32(0x0601AB10u);  // 0601AA20 mov.l 0x0601AB10,r1
    c.r[1] += c.r[11];  // 0601AA22 add r11,r1
    c.r[1] += 1;  // 0601AA24 add #1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601AA26 mov.b @r1,r4
    c.r[6] = c.r[10];  // 0601AA28 mov r10,r6
    { const uint32_t x = c.r[0]; c.pr = 0x0601AA2Eu; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601AA2Eu) return; }  // 0601AA2A jsr @r0 ; extu.b r4,r4
    c.r[1] = c.r[14];  // 0601AA2E mov r14,r1
    c.r[1] += 6;  // 0601AA30 add #6,r1
    c.r[8] = ld32(0x0601AB14u);  // 0601AA32 mov.l 0x0601AB14,r8
    c.r[7] = 0xEu;  // 0601AA34 mov #14,r7
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0601AA36 mov.w @r1,r1
    c.r[5] = c.r[9];  // 0601AA38 mov r9,r5
    c.r[1] = c.r[1] & 0xFFFFu;  // 0601AA3A extu.w r1,r1
    st32(c.r[14] + 32, c.r[1]);  // 0601AA3C mov.l r1,@(32,r14)
    c.r[13] = ld32(c.r[14] + 32);  // 0601AA3E mov.l @(32,r14),r13
    c.r[1] = 0x1u;  // 0601AA40 mov #1,r1
    st32(c.r[14] + 24, c.r[13]);  // 0601AA42 mov.l r13,@(24,r14)
    st8(c.r[8], c.r[1]);  // 0601AA44 mov.b r1,@r8
    c.r[6] = ld32(c.r[14] + 32);  // 0601AA46 mov.l @(32,r14),r6
    c.r[1] = ld32(0x0601AB18u);  // 0601AA48 mov.l 0x0601AB18,r1
    c.r[4] = ld32(c.r[14] + 16);  // 0601AA4A mov.l @(16,r14),r4
    c.r[6] <<= 2;  // 0601AA4C shll2 r6
    c.r[6] += c.r[6];  // 0601AA4E add r6,r6
    { const uint32_t x = c.r[1]; c.pr = 0x0601AA54u; c.r[6] <<= 2; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601AA54u) return; }  // 0601AA50 jsr @r1 ; shll2 r6
    c.r[1] = ld32(0x0601AB1Cu);  // 0601AA54 mov.l 0x0601AB1C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601AA5Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601AA5Au) return; }  // 0601AA56 jsr @r1 ; nop
    c.r[1] = 0x0u;  // 0601AA5A mov #0,r1
    st8(c.r[8], c.r[1]);  // 0601AA5C mov.b r1,@r8
    c.r[6] = ld32(0x0601AAF0u);  // 0601AA5E mov.l 0x0601AAF0,r6
    c.r[2] = ld32(c.r[12] + 4);  // 0601AA60 mov.l @(4,r12),r2
    c.r[6] += 4;  // 0601AA62 add #4,r6
    c.r[1] = ld32(c.r[12]);  // 0601AA64 mov.l @r12,r1
    c.r[13] = ld32(0x0601AB20u);  // 0601AA66 mov.l 0x0601AB20,r13
    c.r[0] = ld32(c.r[14] + 28);  // 0601AA68 mov.l @(28,r14),r0
    c.r[2] -= c.r[1];  // 0601AA6A sub r1,r2
    c.r[1] = ld32(c.r[12] + 12);  // 0601AA6C mov.l @(12,r12),r1
    c.r[6] += c.r[0];  // 0601AA6E add r0,r6
    c.r[2] += c.r[1];  // 0601AA70 add r1,r2
    c.r[1] = ld32(0x0601AB24u);  // 0601AA72 mov.l 0x0601AB24,r1
    c.r[12] += c.r[2];  // 0601AA74 add r2,r12
    c.r[5] = ld32(c.r[1]);  // 0601AA76 mov.l @r1,r5
    { const uint32_t x = c.r[13]; c.pr = 0x0601AA7Cu; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601AA7Cu) return; }  // 0601AA78 jsr @r13 ; mov r12,r4
    c.r[3] = c.r[0];  // 0601AA7C mov r0,r3
    c.r[2] = ld32(0x0601AB10u);  // 0601AA7E mov.l 0x0601AB10,r2
    c.r[0] = ld32(0x0601AB10u);  // 0601AA80 mov.l 0x0601AB10,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[11]);  // 0601AA82 mov.w @(r0,r11),r1
    c.r[2] += 2;  // 0601AA84 add #2,r2
    c.r[13] = ld32(c.r[14] + 28);  // 0601AA86 mov.l @(28,r14),r13
    c.r[10] += c.r[1];  // 0601AA88 add r1,r10
    c.r[0] = c.r[11];  // 0601AA8A mov r11,r0
    st16(c.r[0] + c.r[2], c.r[10]);  // 0601AA8C mov.w r10,@(r0,r2)
    c.r[0] = ld32(0x0601AAF0u);  // 0601AA8E mov.l 0x0601AAF0,r0
    c.r[13] += c.r[0];  // 0601AA90 add r0,r13
    c.r[13] += 2;  // 0601AA92 add #2,r13
    st32(c.r[14] + 28, c.r[13]);  // 0601AA94 mov.l r13,@(28,r14)
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[13]);  // 0601AA96 mov.w @r13,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0601AA98 extu.w r1,r1
    c.r[0] = c.r[1];  // 0601AA9A mov r1,r0
    c.t = c.r[0] == 0x3u;  // 0601AA9C cmp/eq #3,r0
    { const bool k = !c.t; c.r[0] = 0x22u; if (k) { goto L_0601AAB0; } }  // 0601AA9E bf/s 0x0601AAB0 ; mov #34,r0
    c.r[2] = ld32(0x0601AAFCu);  // 0601AAA2 mov.l 0x0601AAFC,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0601AAA4 mov.w @r2,r1
    c.r[13] = ld32(c.r[14] + 32);  // 0601AAA6 mov.l @(32,r14),r13
    c.r[0] += c.r[14];  // 0601AAA8 add r14,r0
    c.r[13] += c.r[1];  // 0601AAAA add r1,r13
    st32(c.r[14] + 32, c.r[13]); goto L_0601AABE;  // 0601AAAC bra 0x0601AABE ; mov.l r13,@(32,r14)
L_0601AAB0:
    c.r[2] = ld32(0x0601AAF8u);  // 0601AAB0 mov.l 0x0601AAF8,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0601AAB2 mov.w @r2,r1
    c.r[0] = 0x1Au;  // 0601AAB4 mov #26,r0
    c.r[13] = ld32(c.r[14] + 24);  // 0601AAB6 mov.l @(24,r14),r13
    c.r[0] += c.r[14];  // 0601AAB8 add r14,r0
    c.r[13] += c.r[1];  // 0601AABA add r1,r13
    st32(c.r[14] + 24, c.r[13]);  // 0601AABC mov.l r13,@(24,r14)
L_0601AABE:
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[0]);  // 0601AABE mov.w @r0,r0
    st16(c.r[2], c.r[0]);  // 0601AAC0 mov.w r0,@r2
    c.r[2] = ld32(0x0601AB24u);  // 0601AAC2 mov.l 0x0601AB24,r2
    c.r[3] += 3;  // 0601AAC4 add #3,r3
    c.r[3] >>= 2;  // 0601AAC6 shlr2 r3
    c.r[3] <<= 2;  // 0601AAC8 shll2 r3
    c.r[14] += 36;  // 0601AACA add #36,r14
    c.r[1] = ld32(c.r[2]);  // 0601AACC mov.l @r2,r1
    c.r[15] = c.r[14];  // 0601AACE mov r14,r15
    c.r[1] += c.r[3];  // 0601AAD0 add r3,r1
    st32(c.r[2], c.r[1]);  // 0601AAD2 mov.l r1,@r2
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601AAD4 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601AAD6 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0601AAD8 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0601AADA mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0601AADC mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0601AADE mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0601AAE0 mov.l @r15+,r9
    c.r[0] = ld32(0x0601AB28u);  // 0601AAE2 mov.l 0x0601AB28,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601AAE4 rts ; mov.l @r15+,r8
}

void f_0601AB2C(SH2Context& c) {
    ran[248] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601AB2C mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0601AB2E mov r15,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601AB36u);  // 0601AB30 mov.w 0x0601AB36,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601AB32 rts ; mov.l @r15+,r14
}

void f_0601AB38(SH2Context& c) {
    ran[249] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601AB38 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0601AB3A mov r15,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601AB42u);  // 0601AB3C mov.w 0x0601AB42,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601AB3E rts ; mov.l @r15+,r14
}

void f_0601AB44(SH2Context& c) {
    ran[250] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601AB44 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0601AB46 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0601AB48 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0601AB4A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0601AB4C mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0601AB4E mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601AB50 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601AB52 sts.l pr,@-r15
    c.r[15] -= 24;  // 0601AB54 add #-24,r15
    c.r[14] = c.r[15];  // 0601AB56 mov r15,r14
    c.r[2] = ld32(0x0601ABE0u);  // 0601AB58 mov.l 0x0601ABE0,r2
    c.r[4] = ld32(0x0601ABE4u);  // 0601AB5A mov.l 0x0601ABE4,r4
    c.r[5] = ld32(c.r[2]);  // 0601AB5C mov.l @r2,r5
    c.r[2] = ld32(0x0601ABE8u);  // 0601AB5E mov.l 0x0601ABE8,r2
    { const uint32_t x = c.r[2]; c.pr = 0x0601AB64u; c.r[6] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601AB64u) return; }  // 0601AB60 jsr @r2 ; mov r14,r6
    c.r[6] = 0x10u;  // 0601AB64 mov #16,r6
    c.r[4] = 0x6u;  // 0601AB66 mov #6,r4
    c.r[2] = ld32(0x0601ABECu);  // 0601AB68 mov.l 0x0601ABEC,r2
    { const uint32_t x = c.r[2]; c.pr = 0x0601AB6Eu; c.r[5] = ld32(c.r[14] + 8); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601AB6Eu) return; }  // 0601AB6A jsr @r2 ; mov.l @(8,r14),r5
    c.r[8] = ld32(0x0601ABF0u);  // 0601AB6E mov.l 0x0601ABF0,r8
    c.r[12] = 0x1u;  // 0601AB70 mov #1,r12
    st8(c.r[8], c.r[12]);  // 0601AB72 mov.b r12,@r8
    c.r[11] = c.r[14];  // 0601AB74 mov r14,r11
    c.r[11] += 6;  // 0601AB76 add #6,r11
    c.r[5] = ld32(0x0601ABF4u);  // 0601AB78 mov.l 0x0601ABF4,r5
    c.r[13] = ld32(0x0601ABF8u);  // 0601AB7A mov.l 0x0601ABF8,r13
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[11]);  // 0601AB7C mov.w @r11,r6
    c.r[7] = 0x7u;  // 0601AB7E mov #7,r7
    c.r[4] = ld32(c.r[14] + 16);  // 0601AB80 mov.l @(16,r14),r4
    c.r[6] = c.r[6] & 0xFFFFu;  // 0601AB82 extu.w r6,r6
    c.r[6] <<= 2;  // 0601AB84 shll2 r6
    c.r[6] += c.r[6];  // 0601AB86 add r6,r6
    { const uint32_t x = c.r[13]; c.pr = 0x0601AB8Cu; c.r[6] <<= 2; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601AB8Cu) return; }  // 0601AB88 jsr @r13 ; shll2 r6
    c.r[10] = ld32(0x0601ABFCu);  // 0601AB8C mov.l 0x0601ABFC,r10
    { const uint32_t x = c.r[10]; c.pr = 0x0601AB92u; c.r[9] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601AB92u) return; }  // 0601AB8E jsr @r10 ; mov #0,r9
    st8(c.r[8], c.r[9]);  // 0601AB92 mov.b r9,@r8
    c.r[2] = ld32(0x0601ABE0u);  // 0601AB94 mov.l 0x0601ABE0,r2
    c.r[4] = ld32(0x0601AC00u);  // 0601AB96 mov.l 0x0601AC00,r4
    c.r[5] = ld32(c.r[2]);  // 0601AB98 mov.l @r2,r5
    c.r[2] = ld32(0x0601ABE8u);  // 0601AB9A mov.l 0x0601ABE8,r2
    { const uint32_t x = c.r[2]; c.pr = 0x0601ABA0u; c.r[6] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601ABA0u) return; }  // 0601AB9C jsr @r2 ; mov r14,r6
    c.r[6] = 0x10u;  // 0601ABA0 mov #16,r6
    c.r[4] = 0x16u;  // 0601ABA2 mov #22,r4
    c.r[2] = ld32(0x0601ABECu);  // 0601ABA4 mov.l 0x0601ABEC,r2
    { const uint32_t x = c.r[2]; c.pr = 0x0601ABAAu; c.r[5] = ld32(c.r[14] + 8); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601ABAAu) return; }  // 0601ABA6 jsr @r2 ; mov.l @(8,r14),r5
    st8(c.r[8], c.r[12]);  // 0601ABAA mov.b r12,@r8
    c.r[5] = ld32(0x0601AC04u);  // 0601ABAC mov.l 0x0601AC04,r5
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[11]);  // 0601ABAE mov.w @r11,r6
    c.r[7] = 0x7u;  // 0601ABB0 mov #7,r7
    c.r[4] = ld32(c.r[14] + 16);  // 0601ABB2 mov.l @(16,r14),r4
    c.r[6] = c.r[6] & 0xFFFFu;  // 0601ABB4 extu.w r6,r6
    c.r[6] <<= 2;  // 0601ABB6 shll2 r6
    c.r[6] += c.r[6];  // 0601ABB8 add r6,r6
    { const uint32_t x = c.r[13]; c.pr = 0x0601ABBEu; c.r[6] <<= 2; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601ABBEu) return; }  // 0601ABBA jsr @r13 ; shll2 r6
    { const uint32_t x = c.r[10]; c.pr = 0x0601ABC2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601ABC2u) return; }  // 0601ABBE jsr @r10 ; nop
    st8(c.r[8], c.r[9]);  // 0601ABC2 mov.b r9,@r8
    c.r[14] += 24;  // 0601ABC4 add #24,r14
    c.r[15] = c.r[14];  // 0601ABC6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601ABC8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601ABCA mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0601ABCC mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0601ABCE mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0601ABD0 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0601ABD2 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0601ABD4 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601ABDCu);  // 0601ABD6 mov.w 0x0601ABDC,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601ABD8 rts ; mov.l @r15+,r8
}

void f_0601AC08(SH2Context& c) {
    ran[251] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601AC08 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0601AC0A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0601AC0C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0601AC0E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0601AC10 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0601AC12 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601AC14 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601AC16 sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x0601AD2Eu);  // 0601AC18 mov.w 0x0601AD2E,r3
    c.r[15] += c.r[3];  // 0601AC1A add r3,r15
    c.r[14] = c.r[15];  // 0601AC1C mov r15,r14
    c.r[6] = 0x2Au;  // 0601AC1E mov #42,r6
    c.r[2] = ld32(0x0601AD3Cu);  // 0601AC20 mov.l 0x0601AD3C,r2
    c.r[3] = c.r[2];  // 0601AC22 mov r2,r3
    c.r[3] += 48;  // 0601AC24 add #48,r3
    c.r[1] = c.r[2];  // 0601AC26 mov r2,r1
    c.r[1] += 88;  // 0601AC28 add #88,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0601AC2A mov.w @r1,r1
    c.r[0] = c.r[14];  // 0601AC2C mov r14,r0
    c.r[11] = 0x0u;  // 0601AC2E mov #0,r11
    c.r[12] = c.r[2];  // 0601AC30 mov r2,r12
    c.r[10] = 0x0u;  // 0601AC32 mov #0,r10
    st16(c.r[3], c.r[1]);  // 0601AC34 mov.w r1,@r3
    c.r[3] = (uint32_t)(int16_t)ld16(0x0601AD30u);  // 0601AC36 mov.w 0x0601AD30,r3
    st16(c.r[0] + c.r[3], c.r[1]);  // 0601AC38 mov.w r1,@(r0,r3)
    c.r[13] = c.r[3];  // 0601AC3A mov r3,r13
L_0601AC3C:
    c.r[1] = ld32(0x0601AD40u);  // 0601AC3C mov.l 0x0601AD40,r1
    c.r[2] = c.r[11];  // 0601AC3E mov r11,r2
    c.r[2] <<= 2;  // 0601AC40 shll2 r2
    c.r[2] += c.r[1];  // 0601AC42 add r1,r2
    c.r[1] = c.r[2];  // 0601AC44 mov r2,r1
    c.r[1] += 108;  // 0601AC46 add #108,r1
    c.r[0] = ld32(c.r[1]);  // 0601AC48 mov.l @r1,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0601AC4A cmp/eq #-1,r0
    { const bool k = c.t; c.r[0] = c.r[14]; if (k) { goto L_0601ACEA; } }  // 0601AC4C bt/s 0x0601ACEA ; mov r14,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[13]);  // 0601AC50 mov.w @(r0,r13),r1
    c.r[7] = (uint32_t)(int16_t)ld16(0x0601AD32u);  // 0601AC52 mov.w 0x0601AD32,r7
    c.r[9] = c.r[1] & 0xFFFFu;  // 0601AC54 extu.w r1,r9
    c.r[1] = c.r[2];  // 0601AC56 mov r2,r1
    c.r[1] += 110;  // 0601AC58 add #110,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0601AC5A mov.w @r1,r1
    c.r[0] = ld32(0x0601AD44u);  // 0601AC5C mov.l 0x0601AD44,r0
    st16(c.r[0] + c.r[10], c.r[1]);  // 0601AC5E mov.w r1,@(r0,r10)
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601AD34u);  // 0601AC60 mov.w 0x0601AD34,r1
    c.r[0] = c.r[2];  // 0601AC62 mov r2,r0
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 0601AC64 mov.l @(r0,r1),r1
    c.r[8] = c.r[6];  // 0601AC66 mov r6,r8
    c.r[4] = ld32(c.r[1] + 12);  // 0601AC68 mov.l @(12,r1),r4
    c.r[0] = c.r[14];  // 0601AC6A mov r14,r0
    c.r[4] += c.r[1];  // 0601AC6C add r1,r4
    st8(c.r[0] + c.r[7], c.r[8]);  // 0601AC6E mov.b r8,@(r0,r7)
    c.r[1] = ld32(0x0601AD48u);  // 0601AC70 mov.l 0x0601AD48,r1
    c.r[5] = ld32(c.r[1]);  // 0601AC72 mov.l @r1,r5
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601AC74 mov.l r14,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[13]);  // 0601AC76 mov.w @(r0,r13),r3
    c.r[6] = c.r[14];  // 0601AC78 mov r14,r6
    c.r[1] = ld32(c.r[12] + 16);  // 0601AC7A mov.l @(16,r12),r1
    c.r[2] = c.r[3] & 0xFFFFu;  // 0601AC7C extu.w r3,r2
    c.r[2] <<= 2;  // 0601AC7E shll2 r2
    c.r[1] += c.r[2];  // 0601AC80 add r2,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0601AC82 mov.l r1,@-r15
    c.r[1] = 0xAu;  // 0601AC84 mov #10,r1
    c.macl = (c.r[3] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 0601AC86 mulu.w r1,r3
    c.r[2] = ld32(c.r[12] + 8);  // 0601AC88 mov.l @(8,r12),r2
    c.r[1] = c.macl;  // 0601AC8A sts macl,r1
    c.r[2] += c.r[1];  // 0601AC8C add r1,r2
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 0601AC8E mov.l r2,@-r15
    c.r[1] = ld32(c.r[12] + 4);  // 0601AC90 mov.l @(4,r12),r1
    c.r[6] += c.r[13];  // 0601AC92 add r13,r6
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0601AC94 mov.l r1,@-r15
    c.r[1] = ld32(c.r[12]);  // 0601AC96 mov.l @r12,r1
    c.r[0] = 0x1u;  // 0601AC98 mov #1,r0
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0601AC9A mov.l r1,@-r15
    c.r[1] = 0x7u;  // 0601AC9C mov #7,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0601AC9E mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 0601ACA0 mov.l r0,@-r15
    c.r[0] = ld32(0x0601AD44u);  // 0601ACA2 mov.l 0x0601AD44,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[10]);  // 0601ACA4 mov.w @(r0,r10),r1
    c.r[7] += c.r[14];  // 0601ACA6 add r14,r7
    c.r[0] = 0x3u;  // 0601ACA8 mov #3,r0
    c.r[1] &= c.r[0];  // 0601ACAA and r0,r1
    c.r[0] = ld32(0x0601AD4Cu);  // 0601ACAC mov.l 0x0601AD4C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601ACB2u; c.r[15] -= 4; st32(c.r[15], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601ACB2u) return; }  // 0601ACAE jsr @r0 ; mov.l r1,@-r15
    c.r[15] += 32;  // 0601ACB2 add #32,r15
    c.r[2] = c.r[9];  // 0601ACB4 mov r9,r2
    c.r[2] <<= 2;  // 0601ACB6 shll2 r2
    c.r[2] += c.r[9];  // 0601ACB8 add r9,r2
    c.r[2] += c.r[2];  // 0601ACBA add r2,r2
    c.r[5] = (uint32_t)(int16_t)ld16(0x0601AD36u);  // 0601ACBC mov.w 0x0601AD36,r5
    c.r[6] = 0x1u;  // 0601ACBE mov #1,r6
    c.r[1] = ld32(c.r[12] + 8);  // 0601ACC0 mov.l @(8,r12),r1
    c.r[4] = c.r[8];  // 0601ACC2 mov r8,r4
    c.r[2] += c.r[1];  // 0601ACC4 add r1,r2
    c.r[2] += 4;  // 0601ACC6 add #4,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0601ACC8 mov.w @r2,r1
    c.r[0] = ld32(0x0601AD50u);  // 0601ACCA mov.l 0x0601AD50,r0
    c.r[5] &= c.r[1];  // 0601ACCC and r1,r5
    c.r[5] += c.r[5];  // 0601ACCE add r5,r5
    c.r[5] += c.r[14];  // 0601ACD0 add r14,r5
    c.r[1] = c.r[8];  // 0601ACD2 mov r8,r1
    c.r[1] <<= 2;  // 0601ACD4 shll2 r1
    c.r[1] += c.r[1];  // 0601ACD6 add r1,r1
    c.r[1] <<= 2;  // 0601ACD8 shll2 r1
    { const uint32_t x = c.r[0]; c.pr = 0x0601ACDEu; c.r[5] -= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601ACDEu) return; }  // 0601ACDA jsr @r0 ; sub r1,r5
    c.r[1] = c.r[8];  // 0601ACDE mov r8,r1
    c.r[1] += 1;  // 0601ACE0 add #1,r1
    c.r[2] = ld32(c.r[12] + 20);  // 0601ACE2 mov.l @(20,r12),r2
    c.r[6] = c.r[1] & 0xFFu;  // 0601ACE4 extu.b r1,r6
    c.r[0] = c.r[2];  // 0601ACE6 mov r2,r0
    st8(c.r[0] + c.r[9], c.r[8]);  // 0601ACE8 mov.b r8,@(r0,r9)
L_0601ACEA:
    c.r[11] += 1;  // 0601ACEA add #1,r11
    c.r[1] = 0xFu;  // 0601ACEC mov #15,r1
    c.t = (int32_t)c.r[11] > (int32_t)c.r[1];  // 0601ACEE cmp/gt r1,r11
    { const bool k = !c.t; c.r[10] += 2; if (k) { SH2_POLL(c); goto L_0601AC3C; } }  // 0601ACF0 bf/s 0x0601AC3C ; add #2,r10
    c.r[2] = ld32(0x0601AD54u);  // 0601ACF4 mov.l 0x0601AD54,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601AD30u);  // 0601ACF6 mov.w 0x0601AD30,r0
    c.r[7] = 0x10u;  // 0601ACF8 mov #16,r7
    c.r[6] = 0x0u;  // 0601ACFA mov #0,r6
    c.r[5] = 0x2Au;  // 0601ACFC mov #42,r5
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[14]);  // 0601ACFE mov.w @(r0,r14),r1
    st16(c.r[2], c.r[1]);  // 0601AD00 mov.w r1,@r2
    c.r[2] = ld32(0x0601AD58u);  // 0601AD02 mov.l 0x0601AD58,r2
    c.r[1] = 0x0u;  // 0601AD04 mov #0,r1
    st16(c.r[2], c.r[1]);  // 0601AD06 mov.w r1,@r2
    c.r[1] = ld32(0x0601AD5Cu);  // 0601AD08 mov.l 0x0601AD5C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601AD0Eu; c.r[4] = 0x30u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601AD0Eu) return; }  // 0601AD0A jsr @r1 ; mov #48,r4
    c.r[2] = ld32(0x0601AD60u);  // 0601AD0E mov.l 0x0601AD60,r2
    c.r[1] = 0x1u;  // 0601AD10 mov #1,r1
    st16(c.r[2], c.r[1]);  // 0601AD12 mov.w r1,@r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0601AD38u);  // 0601AD14 mov.w 0x0601AD38,r3
    c.r[14] += c.r[3];  // 0601AD16 add r3,r14
    c.r[15] = c.r[14];  // 0601AD18 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601AD1A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601AD1C mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0601AD1E mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0601AD20 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0601AD22 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0601AD24 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0601AD26 mov.l @r15+,r9
    c.r[0] = ld32(0x0601AD64u);  // 0601AD28 mov.l 0x0601AD64,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601AD2A rts ; mov.l @r15+,r8
}

void f_0601AD68(SH2Context& c) {
    ran[252] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601AD68 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601AD6A sts.l pr,@-r15
    c.r[1] = ld32(0x0601AD88u);  // 0601AD6C mov.l 0x0601AD88,r1
    c.r[1] = ld32(c.r[1]);  // 0601AD6E mov.l @r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601AD70 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0601AD72 extu.b r1,r0
    c.r[0] <<= 2;  // 0601AD74 shll2 r0
    c.r[1] = ld32(0x0601AD8Cu);  // 0601AD76 mov.l 0x0601AD8C,r1
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 0601AD78 mov.l @(r0,r1),r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601AD7Eu; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601AD7Eu) return; }  // 0601AD7A jsr @r0 ; mov r15,r14
    c.r[15] = c.r[14];  // 0601AD7E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601AD80 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601AD82 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[0] & 0xFFFFu; c.pc = x; return; }  // 0601AD84 rts ; extu.w r0,r0
}

void f_0601AD90(SH2Context& c) {
    ran[253] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601AD90 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0601AD92 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0601AD94 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0601AD96 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0601AD98 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601AD9A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601AD9C sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0601AD9E mov r15,r14
    c.r[4] = ld32(0x0601AE10u);  // 0601ADA0 mov.l 0x0601AE10,r4
    c.r[3] = ld32(0x0601AE14u);  // 0601ADA2 mov.l 0x0601AE14,r3
    c.r[8] = ld32(0x0601AE18u);  // 0601ADA4 mov.l 0x0601AE18,r8
    c.r[11] = 0x1u;  // 0601ADA6 mov #1,r11
    c.r[7] = ld32(c.r[4]);  // 0601ADA8 mov.l @r4,r7
    c.r[5] = ld32(0x0601AE1Cu);  // 0601ADAA mov.l 0x0601AE1C,r5
    c.r[2] = ld32(c.r[4] + 4);  // 0601ADAC mov.l @(4,r4),r2
    c.r[1] = c.r[7];  // 0601ADAE mov r7,r1
    c.r[1] -= 4;  // 0601ADB0 add #-4,r1
    c.r[2] -= c.r[1];  // 0601ADB2 sub r1,r2
    st32(c.r[3], c.r[2]);  // 0601ADB4 mov.l r2,@r3
    c.r[1] = ld32(c.r[4] + 12);  // 0601ADB6 mov.l @(12,r4),r1
    c.r[12] = ld32(0x0601AE20u);  // 0601ADB8 mov.l 0x0601AE20,r12
    st8(c.r[8], c.r[11]);  // 0601ADBA mov.b r11,@r8
    c.r[6] = ld32(c.r[4] + 8);  // 0601ADBC mov.l @(8,r4),r6
    c.r[1] += c.r[4];  // 0601ADBE add r4,r1
    c.r[6] -= c.r[7];  // 0601ADC0 sub r7,r6
    c.r[6] += 8;  // 0601ADC2 add #8,r6
    { const uint32_t x = c.r[12]; c.pr = 0x0601ADC8u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601ADC8u) return; }  // 0601ADC4 jsr @r12 ; mov r1,r4
    c.r[10] = ld32(0x0601AE24u);  // 0601ADC8 mov.l 0x0601AE24,r10
    { const uint32_t x = c.r[10]; c.pr = 0x0601ADCEu; c.r[9] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601ADCEu) return; }  // 0601ADCA jsr @r10 ; mov #0,r9
    st8(c.r[8], c.r[9]);  // 0601ADCE mov.b r9,@r8
    c.r[4] = ld32(0x0601AE28u);  // 0601ADD0 mov.l 0x0601AE28,r4
    c.r[7] = ld32(c.r[4]);  // 0601ADD2 mov.l @r4,r7
    c.r[3] = ld32(0x0601AE2Cu);  // 0601ADD4 mov.l 0x0601AE2C,r3
    c.r[2] = ld32(c.r[4] + 4);  // 0601ADD6 mov.l @(4,r4),r2
    c.r[1] = c.r[7];  // 0601ADD8 mov r7,r1
    c.r[1] -= 4;  // 0601ADDA add #-4,r1
    c.r[2] -= c.r[1];  // 0601ADDC sub r1,r2
    st32(c.r[3], c.r[2]);  // 0601ADDE mov.l r2,@r3
    c.r[1] = ld32(c.r[4] + 12);  // 0601ADE0 mov.l @(12,r4),r1
    c.r[5] = ld32(0x0601AE30u);  // 0601ADE2 mov.l 0x0601AE30,r5
    st8(c.r[8], c.r[11]);  // 0601ADE4 mov.b r11,@r8
    c.r[6] = ld32(c.r[4] + 8);  // 0601ADE6 mov.l @(8,r4),r6
    c.r[1] += c.r[4];  // 0601ADE8 add r4,r1
    c.r[6] -= c.r[7];  // 0601ADEA sub r7,r6
    c.r[6] += 8;  // 0601ADEC add #8,r6
    { const uint32_t x = c.r[12]; c.pr = 0x0601ADF2u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601ADF2u) return; }  // 0601ADEE jsr @r12 ; mov r1,r4
    { const uint32_t x = c.r[10]; c.pr = 0x0601ADF6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601ADF6u) return; }  // 0601ADF2 jsr @r10 ; nop
    st8(c.r[8], c.r[9]);  // 0601ADF6 mov.b r9,@r8
    c.r[15] = c.r[14];  // 0601ADF8 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601ADFA lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601ADFC mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0601ADFE mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0601AE00 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0601AE02 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0601AE04 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601AE0Cu);  // 0601AE06 mov.w 0x0601AE0C,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601AE08 rts ; mov.l @r15+,r8
}

void f_0601AE34(SH2Context& c) {
    ran[254] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601AE34 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601AE36 sts.l pr,@-r15
    c.r[1] = ld32(0x0601AE54u);  // 0601AE38 mov.l 0x0601AE54,r1
    c.r[1] = ld32(c.r[1]);  // 0601AE3A mov.l @r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601AE3C mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0601AE3E extu.b r1,r0
    c.r[0] <<= 2;  // 0601AE40 shll2 r0
    c.r[1] = ld32(0x0601AE58u);  // 0601AE42 mov.l 0x0601AE58,r1
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 0601AE44 mov.l @(r0,r1),r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601AE4Au; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601AE4Au) return; }  // 0601AE46 jsr @r0 ; mov r15,r14
    c.r[15] = c.r[14];  // 0601AE4A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601AE4C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601AE4E mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[0] & 0xFFFFu; c.pc = x; return; }  // 0601AE50 rts ; extu.w r0,r0
}

void f_0601AE5C(SH2Context& c) {
    ran[255] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601AE5C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601AE5E sts.l pr,@-r15
    c.r[1] = ld32(0x0601AE7Cu);  // 0601AE60 mov.l 0x0601AE7C,r1
    c.r[1] = ld32(c.r[1]);  // 0601AE62 mov.l @r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601AE64 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0601AE66 extu.b r1,r0
    c.r[0] <<= 2;  // 0601AE68 shll2 r0
    c.r[1] = ld32(0x0601AE80u);  // 0601AE6A mov.l 0x0601AE80,r1
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 0601AE6C mov.l @(r0,r1),r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601AE72u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601AE72u) return; }  // 0601AE6E jsr @r0 ; mov r15,r14
    c.r[15] = c.r[14];  // 0601AE72 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601AE74 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601AE76 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[0] & 0xFFFFu; c.pc = x; return; }  // 0601AE78 rts ; extu.w r0,r0
}

void f_0601AE84(SH2Context& c) {
    ran[256] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601AE84 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0601AE86 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0601AE88 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0601AE8A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601AE8C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601AE8E sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0601AE90 mov r15,r14
    c.r[9] = ld32(0x0601AFA4u);  // 0601AE92 mov.l 0x0601AFA4,r9
    c.r[1] = ld32(0x0601AFA8u);  // 0601AE94 mov.l 0x0601AFA8,r1
    c.r[8] = 0xFu;  // 0601AE96 mov #15,r8
    c.r[11] = 0x4u;  // 0601AE98 mov #4,r11
    c.r[1] = ld32(c.r[1]);  // 0601AE9A mov.l @r1,r1
    c.r[4] = ld32(0x0601AFACu);  // 0601AE9C mov.l 0x0601AFAC,r4
    c.r[1] += 1;  // 0601AE9E add #1,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601AEA0 mov.b @r1,r0
    c.r[8] &= c.r[0];  // 0601AEA2 and r0,r8
    c.r[0] = ld32(0x0601AFB0u);  // 0601AEA4 mov.l 0x0601AFB0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601AEAAu; c.r[5] = 0x25u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601AEAAu) return; }  // 0601AEA6 jsr @r0 ; mov #37,r5
    c.r[1] = c.r[0];  // 0601AEAA mov r0,r1
    c.r[1] += 4;  // 0601AEAC add #4,r1
    c.r[0] = ld32(0x0601AFB4u);  // 0601AEAE mov.l 0x0601AFB4,r0
    c.r[5] = c.r[9];  // 0601AEB0 mov r9,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0601AEB6u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601AEB6u) return; }  // 0601AEB2 jsr @r0 ; mov r1,r4
    c.r[2] = c.r[9];  // 0601AEB6 mov r9,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]); c.r[2] += 1;  // 0601AEB8 mov.b @r2+,r1
    c.r[0] = ld32(0x0601AFB8u);  // 0601AEBA mov.l 0x0601AFB8,r0
    c.r[1] = c.r[1] & 0xFFu;  // 0601AEBC extu.b r1,r1
    c.r[10] = c.r[1];  // 0601AEBE mov r1,r10
    c.r[10] <<= 8;  // 0601AEC0 shll8 r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601AEC2 mov.b @r2,r1
    c.r[4] = 0x1u;  // 0601AEC4 mov #1,r4
    c.r[1] = c.r[1] & 0xFFu;  // 0601AEC6 extu.b r1,r1
    { const uint32_t x = c.r[0]; c.pr = 0x0601AECCu; c.r[10] |= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601AECCu) return; }  // 0601AEC8 jsr @r0 ; or r1,r10
    c.r[6] = c.r[0] & 0xFFu;  // 0601AECC extu.b r0,r6
    c.r[1] = ld32(0x0601AFBCu);  // 0601AECE mov.l 0x0601AFBC,r1
    c.r[2] = c.r[6];  // 0601AED0 mov r6,r2
    c.r[2] += c.r[2];  // 0601AED2 add r2,r2
    c.r[2] += c.r[6];  // 0601AED4 add r6,r2
    c.r[2] <<= 2;  // 0601AED6 shll2 r2
    c.r[2] += c.r[1];  // 0601AED8 add r1,r2
    c.r[1] = c.r[9];  // 0601AEDA mov r9,r1
    c.r[1] += c.r[11];  // 0601AEDC add r11,r1
    c.t = (c.r[8] & c.r[8]) == 0;  // 0601AEDE tst r8,r8
    { const bool k = c.t; st32(c.r[2] + 4, c.r[1]); if (k) { goto L_0601AEF4; } }  // 0601AEE0 bt/s 0x0601AEF4 ; mov.l r1,@(4,r2)
    c.r[0] = c.r[8];  // 0601AEE4 mov r8,r0
    c.t = c.r[0] == 0x1u;  // 0601AEE6 cmp/eq #1,r0
    { const bool k = !c.t; c.r[2] += 8; if (k) { goto L_0601AEF0; } }  // 0601AEE8 bf/s 0x0601AEF0 ; add #8,r2
    c.r[1] = 0x0u; goto L_0601AEFA;  // 0601AEEC bra 0x0601AEFA ; mov #0,r1
L_0601AEF0:
    c.r[1] = 0x30u; goto L_0601AEFA;  // 0601AEF0 bra 0x0601AEFA ; mov #48,r1
L_0601AEF4:
    c.r[1] = ld32(0x0601AFC0u);  // 0601AEF4 mov.l 0x0601AFC0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601AEF6 mov.b @r1,r1
    c.r[2] += 8;  // 0601AEF8 add #8,r2
L_0601AEFA:
    st8(c.r[2], c.r[1]);  // 0601AEFA mov.b r1,@r2
    c.r[7] = ld32(0x0601AFBCu);  // 0601AEFC mov.l 0x0601AFBC,r7
    c.r[3] = c.r[6];  // 0601AEFE mov r6,r3
    c.r[3] += c.r[3];  // 0601AF00 add r3,r3
    c.r[3] += c.r[6];  // 0601AF02 add r6,r3
    c.r[3] <<= 2;  // 0601AF04 shll2 r3
    c.r[2] = c.r[10];  // 0601AF06 mov r10,r2
    c.r[2] >>= 2;  // 0601AF08 shlr2 r2
    c.r[2] >>= 2;  // 0601AF0A shlr2 r2
    c.r[1] = 0xFu;  // 0601AF0C mov #15,r1
    c.r[1] &= c.r[10];  // 0601AF0E and r10,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601AF10 tst r1,r1
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_0601AF1A; } }  // 0601AF12 bt/s 0x0601AF1A ; mov r2,r1
    c.r[1] += 1; goto L_0601AF1C;  // 0601AF16 bra 0x0601AF1C ; add #1,r1
L_0601AF1A:
    c.r[1] = c.r[2];  // 0601AF1A mov r2,r1
L_0601AF1C:
    c.r[0] = 0x7Fu;  // 0601AF1C mov #127,r0
    c.r[1] &= c.r[0];  // 0601AF1E and r0,r1
    c.r[0] = c.r[7];  // 0601AF20 mov r7,r0
    c.r[10] += c.r[10];  // 0601AF22 add r10,r10
    c.r[11] += c.r[10];  // 0601AF24 add r10,r11
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0601AF26 mov.b @(r0,r3),r2
    c.r[8] = ld32(0x0601AFC4u);  // 0601AF28 mov.l 0x0601AFC4,r8
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601AFA0u);  // 0601AF2A mov.w 0x0601AFA0,r0
    c.r[2] &= c.r[0];  // 0601AF2C and r0,r2
    c.r[2] |= c.r[1];  // 0601AF2E or r1,r2
    c.r[0] = c.r[7];  // 0601AF30 mov r7,r0
    st8(c.r[0] + c.r[3], c.r[2]);  // 0601AF32 mov.b r2,@(r0,r3)
    c.r[1] = c.r[9];  // 0601AF34 mov r9,r1
    c.r[1] += 2;  // 0601AF36 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601AF38 mov.b @r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0601AFA2u);  // 0601AF3A mov.w 0x0601AFA2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0601AF3C extu.b r1,r1
    c.r[10] = c.r[1];  // 0601AF3E mov r1,r10
    c.r[10] <<= 8;  // 0601AF40 shll8 r10
    c.r[1] = c.r[9];  // 0601AF42 mov r9,r1
    c.r[1] += 3;  // 0601AF44 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601AF46 mov.b @r1,r1
    c.r[7] = 0xEu;  // 0601AF48 mov #14,r7
    c.r[1] = c.r[1] & 0xFFu;  // 0601AF4A extu.b r1,r1
    c.r[10] |= c.r[1];  // 0601AF4C or r1,r10
    c.r[11] += c.r[10];  // 0601AF4E add r10,r11
    c.r[1] = 0x1u;  // 0601AF50 mov #1,r1
    st8(c.r[8], c.r[1]);  // 0601AF52 mov.b r1,@r8
    c.r[1] = 0x20u;  // 0601AF54 mov #32,r1
    c.macl = c.r[10] * c.r[1];  // 0601AF56 mul.l r1,r10
    c.r[9] += c.r[11];  // 0601AF58 add r11,r9
    c.r[4] = c.r[9];  // 0601AF5A mov r9,r4
    c.r[1] = ld32(0x0601AFC8u);  // 0601AF5C mov.l 0x0601AFC8,r1
    c.r[0] = c.r[1];  // 0601AF5E mov r1,r0
    c.r[5] = ld32(c.r[0] + c.r[2]);  // 0601AF60 mov.l @(r0,r2),r5
    c.r[1] = ld32(0x0601AFCCu);  // 0601AF62 mov.l 0x0601AFCC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601AF68u; c.r[6] = c.macl; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601AF68u) return; }  // 0601AF64 jsr @r1 ; sts macl,r6
    c.r[1] = ld32(0x0601AFD0u);  // 0601AF68 mov.l 0x0601AFD0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601AF6Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601AF6Eu) return; }  // 0601AF6A jsr @r1 ; nop
    c.r[1] = 0x0u;  // 0601AF6E mov #0,r1
    st8(c.r[8], c.r[1]);  // 0601AF70 mov.b r1,@r8
    c.r[1] = ld32(0x0601AFBCu);  // 0601AF72 mov.l 0x0601AFBC,r1
    c.r[3] = c.r[1];  // 0601AF74 mov r1,r3
    c.r[3] += 12;  // 0601AF76 add #12,r3
    c.r[2] = (uint32_t)(int16_t)ld16(0x0601AFA0u);  // 0601AF78 mov.w 0x0601AFA0,r2
    c.r[0] = 0x7Fu;  // 0601AF7A mov #127,r0
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0601AF7C mov.b @r3,r7
    c.r[15] = c.r[14];  // 0601AF7E mov r14,r15
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601AF80 mov.b @r1,r6
    c.r[2] &= c.r[7];  // 0601AF82 and r7,r2
    c.r[6] &= c.r[0];  // 0601AF84 and r0,r6
    c.r[6] |= c.r[2];  // 0601AF86 or r2,r6
    st8(c.r[1], c.r[6]);  // 0601AF88 mov.b r6,@r1
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601AFA0u);  // 0601AF8A mov.w 0x0601AFA0,r1
    c.r[1] |= c.r[7];  // 0601AF8C or r7,r1
    st8(c.r[3], c.r[1]);  // 0601AF8E mov.b r1,@r3
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601AF90 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601AF92 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0601AF94 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0601AF96 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0601AF98 mov.l @r15+,r9
    c.r[0] = ld32(0x0601AFD4u);  // 0601AF9A mov.l 0x0601AFD4,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601AF9C rts ; mov.l @r15+,r8
}

void f_0601AFD8(SH2Context& c) {
    ran[257] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601AFD8 mov.l r14,@-r15
    c.r[1] = ld32(0x0601B048u);  // 0601AFDA mov.l 0x0601B048,r1
    c.r[1] = ld32(c.r[1]);  // 0601AFDC mov.l @r1,r1
    c.r[1] += 1;  // 0601AFDE add #1,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601AFE0 mov.b @r1,r0
    c.r[2] = (uint32_t)(int16_t)ld16(0x0601B044u);  // 0601AFE2 mov.w 0x0601B044,r2
    c.r[2] &= c.r[0];  // 0601AFE4 and r0,r2
    c.r[2] >>= 2;  // 0601AFE6 shlr2 r2
    c.r[2] >>= 2;  // 0601AFE8 shlr2 r2
    c.r[0] &= 0xFu;  // 0601AFEA and #15,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601AFEC tst r0,r0
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0601B002; } }  // 0601AFEE bf/s 0x0601B002 ; mov r15,r14
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601B046u);  // 0601AFF2 mov.w 0x0601B046,r1
    c.macl = c.r[2] * c.r[1];  // 0601AFF4 mul.l r1,r2
    c.r[2] = c.macl;  // 0601AFF6 sts macl,r2
    c.r[1] = ld32(0x0601B04Cu);  // 0601AFF8 mov.l 0x0601B04C,r1
    c.r[2] += c.r[1];  // 0601AFFA add r1,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601AFFC mov.b @r2,r0
    c.r[0] &= 0x7Fu; goto L_0601B03A;  // 0601AFFE bra 0x0601B03A ; and #127,r0
L_0601B002:
    c.t = c.r[0] == 0x1u;  // 0601B002 cmp/eq #1,r0
    if (!c.t) { goto L_0601B016; }  // 0601B004 bf 0x0601B016
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601B046u);  // 0601B006 mov.w 0x0601B046,r1
    c.macl = c.r[2] * c.r[1];  // 0601B008 mul.l r1,r2
    c.r[2] = c.macl;  // 0601B00A sts macl,r2
    c.r[1] = ld32(0x0601B04Cu);  // 0601B00C mov.l 0x0601B04C,r1
    c.r[2] += c.r[1];  // 0601B00E add r1,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601B010 mov.b @r2,r0
    c.r[0] |= 0x80u; goto L_0601B03A;  // 0601B012 bra 0x0601B03A ; or #128,r0
L_0601B016:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601B046u);  // 0601B016 mov.w 0x0601B046,r1
    c.macl = c.r[2] * c.r[1];  // 0601B018 mul.l r1,r2
    c.r[2] = c.macl;  // 0601B01A sts macl,r2
    c.r[1] = ld32(0x0601B04Cu);  // 0601B01C mov.l 0x0601B04C,r1
    c.r[2] += c.r[1];  // 0601B01E add r1,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601B020 mov.b @r2,r0
    c.r[1] = c.r[0] & 0xFFu;  // 0601B022 extu.b r0,r1
    c.r[1] >>= 2;  // 0601B024 shlr2 r1
    c.r[1] >>= 2;  // 0601B026 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0601B028 shlr r1
    c.r[1] >>= 2;  // 0601B02A shlr2 r1
    c.r[1] += 1;  // 0601B02C add #1,r1
    c.r[1] <<= 2;  // 0601B02E shll2 r1
    c.r[1] <<= 2;  // 0601B030 shll2 r1
    c.r[1] += c.r[1];  // 0601B032 add r1,r1
    c.r[1] <<= 2;  // 0601B034 shll2 r1
    c.r[0] &= 0x7Fu;  // 0601B036 and #127,r0
    c.r[0] |= c.r[1];  // 0601B038 or r1,r0
L_0601B03A:
    st8(c.r[2], c.r[0]);  // 0601B03A mov.b r0,@r2
    c.r[15] = c.r[14];  // 0601B03C mov r14,r15
    c.r[0] = ld32(0x0601B050u);  // 0601B03E mov.l 0x0601B050,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601B040 rts ; mov.l @r15+,r14
}

void f_0601B054(SH2Context& c) {
    ran[258] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601B054 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601B056 sts.l pr,@-r15
    c.r[1] = ld32(0x0601B074u);  // 0601B058 mov.l 0x0601B074,r1
    c.r[1] = ld32(c.r[1]);  // 0601B05A mov.l @r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B05C mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0601B05E extu.b r1,r0
    c.r[0] <<= 2;  // 0601B060 shll2 r0
    c.r[1] = ld32(0x0601B078u);  // 0601B062 mov.l 0x0601B078,r1
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 0601B064 mov.l @(r0,r1),r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601B06Au; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601B06Au) return; }  // 0601B066 jsr @r0 ; mov r15,r14
    c.r[15] = c.r[14];  // 0601B06A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601B06C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601B06E mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[0] & 0xFFFFu; c.pc = x; return; }  // 0601B070 rts ; extu.w r0,r0
}

void f_0601B07C(SH2Context& c) {
    ran[259] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601B07C mov.l r14,@-r15
    c.r[1] = ld32(0x0601B0FCu);  // 0601B07E mov.l 0x0601B0FC,r1
    c.r[2] = ld32(c.r[1]);  // 0601B080 mov.l @r1,r2
    c.r[2] += 1;  // 0601B082 add #1,r2
    st32(c.r[1], c.r[2]);  // 0601B084 mov.l r2,@r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601B086 mov.b @r2,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0601B088 extu.b r1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601B08A tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0601B0BE; } }  // 0601B08C bt/s 0x0601B0BE ; mov r15,r14
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601B0F4u);  // 0601B090 mov.w 0x0601B0F4,r1
    c.r[1] &= c.r[0];  // 0601B092 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601B094 tst r1,r1
    { const bool k = c.t; c.r[0] &= 0x7Fu; if (k) { goto L_0601B0A6; } }  // 0601B096 bt/s 0x0601B0A6 ; and #127,r0
    c.r[2] = ld32(0x0601B100u);  // 0601B09A mov.l 0x0601B100,r2
    c.r[1] = 0x1u;  // 0601B09C mov #1,r1
    st8(c.r[0] + c.r[2], c.r[1]);  // 0601B09E mov.b r1,@(r0,r2)
    c.r[2] = ld32(0x0601B104u);  // 0601B0A0 mov.l 0x0601B104,r2
    c.r[1] = 0x0u; goto L_0601B0BA;  // 0601B0A2 bra 0x0601B0BA ; mov #0,r1
L_0601B0A6:
    c.r[3] = ld32(0x0601B108u);  // 0601B0A6 mov.l 0x0601B108,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0601B0A8 mov.b @r3,r1
    c.r[2] = ld32(0x0601B100u);  // 0601B0AA mov.l 0x0601B100,r2
    c.r[0] = c.r[1] & 0xFFu;  // 0601B0AC extu.b r1,r0
    c.r[1] = 0x1u;  // 0601B0AE mov #1,r1
    st8(c.r[0] + c.r[2], c.r[1]);  // 0601B0B0 mov.b r1,@(r0,r2)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0601B0B2 mov.b @r3,r1
    c.r[2] = ld32(0x0601B104u);  // 0601B0B4 mov.l 0x0601B104,r2
    c.r[0] = c.r[1] & 0xFFu;  // 0601B0B6 extu.b r1,r0
    c.r[1] = 0x0u;  // 0601B0B8 mov #0,r1
L_0601B0BA:
    st8(c.r[0] + c.r[2], c.r[1]); goto L_0601B0D2;  // 0601B0BA bra 0x0601B0D2 ; mov.b r1,@(r0,r2)
L_0601B0BE:
    c.r[6] = (uint32_t)(int16_t)ld16(0x0601B0F6u);  // 0601B0BE mov.w 0x0601B0F6,r6
    c.r[7] = ld32(0x0601B100u);  // 0601B0C0 mov.l 0x0601B100,r7
    c.r[3] = 0x1u;  // 0601B0C2 mov #1,r3
    c.r[2] = ld32(0x0601B104u);  // 0601B0C4 mov.l 0x0601B104,r2
    c.r[1] = 0x0u;  // 0601B0C6 mov #0,r1
L_0601B0C8:
    st8(c.r[0] + c.r[7], c.r[3]);  // 0601B0C8 mov.b r3,@(r0,r7)
    st8(c.r[0] + c.r[2], c.r[1]);  // 0601B0CA mov.b r1,@(r0,r2)
    c.r[0] += 1;  // 0601B0CC add #1,r0
    c.t = (int32_t)c.r[0] > (int32_t)c.r[6];  // 0601B0CE cmp/gt r6,r0
    if (!c.t) { SH2_POLL(c); goto L_0601B0C8; }  // 0601B0D0 bf 0x0601B0C8
L_0601B0D2:
    c.r[2] = ld32(0x0601B108u);  // 0601B0D2 mov.l 0x0601B108,r2
    c.r[1] = 0x0u;  // 0601B0D4 mov #0,r1
    st8(c.r[2], c.r[1]);  // 0601B0D6 mov.b r1,@r2
    c.r[2] = ld32(0x0601B10Cu);  // 0601B0D8 mov.l 0x0601B10C,r2
    c.r[1] = 0x0u;  // 0601B0DA mov #0,r1
    st16(c.r[2], c.r[1]);  // 0601B0DC mov.w r1,@r2
    c.r[0] = 0x0u;  // 0601B0DE mov #0,r0
    c.r[2] = 0x63u;  // 0601B0E0 mov #99,r2
    c.r[1] = ld32(0x0601B110u);  // 0601B0E2 mov.l 0x0601B110,r1
L_0601B0E4:
    st8(c.r[0] + c.r[1], c.r[0]);  // 0601B0E4 mov.b r0,@(r0,r1)
    c.r[0] += 1;  // 0601B0E6 add #1,r0
    c.t = (int32_t)c.r[0] > (int32_t)c.r[2];  // 0601B0E8 cmp/gt r2,r0
    { const bool k = !c.t; c.r[15] = c.r[14]; if (k) { SH2_POLL(c); goto L_0601B0E4; } }  // 0601B0EA bf/s 0x0601B0E4 ; mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601B0F8u);  // 0601B0EE mov.w 0x0601B0F8,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601B0F0 rts ; mov.l @r15+,r14
}

void f_0601B114(SH2Context& c) {
    ran[260] = 1;
L_0601B114:
    c.r[0] = ld32(0x0601B11Cu);  // 0601B114 mov.l 0x0601B11C,r0
L_0601B116:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x0601B114u: goto L_0601B114; case 0x0601B116u: goto L_0601B116; case 0x0601B124u: goto L_0601B124; case 0x0601B126u: goto L_0601B126; case 0x0601B128u: goto L_0601B128; case 0x0601B12Au: goto L_0601B12A; case 0x0601B12Cu: goto L_0601B12C; case 0x0601B12Eu: goto L_0601B12E; case 0x0601B130u: goto L_0601B130; case 0x0601B132u: goto L_0601B132; case 0x0601B134u: goto L_0601B134; case 0x0601B136u: goto L_0601B136; case 0x0601B138u: goto L_0601B138; case 0x0601B13Au: goto L_0601B13A; case 0x0601B13Eu: goto L_0601B13E; case 0x0601B140u: goto L_0601B140; case 0x0601B144u: goto L_0601B144; case 0x0601B146u: goto L_0601B146; case 0x0601B148u: goto L_0601B148; case 0x0601B14Au: goto L_0601B14A; case 0x0601B14Cu: goto L_0601B14C; case 0x0601B14Eu: goto L_0601B14E; case 0x0601B150u: goto L_0601B150; case 0x0601B152u: goto L_0601B152; case 0x0601B156u: goto L_0601B156; case 0x0601B158u: goto L_0601B158; case 0x0601B15Au: goto L_0601B15A; case 0x0601B15Cu: goto L_0601B15C; case 0x0601B15Eu: goto L_0601B15E; case 0x0601B162u: goto L_0601B162; case 0x0601B164u: goto L_0601B164; case 0x0601B166u: goto L_0601B166; case 0x0601B168u: goto L_0601B168; case 0x0601B16Au: goto L_0601B16A; case 0x0601B16Cu: goto L_0601B16C; case 0x0601B16Eu: goto L_0601B16E; case 0x0601B170u: goto L_0601B170; case 0x0601B172u: goto L_0601B172; case 0x0601B176u: goto L_0601B176; case 0x0601B178u: goto L_0601B178; case 0x0601B17Au: goto L_0601B17A; case 0x0601B17Cu: goto L_0601B17C; case 0x0601B17Eu: goto L_0601B17E; case 0x0601B180u: goto L_0601B180; case 0x0601B182u: goto L_0601B182; case 0x0601B184u: goto L_0601B184; case 0x0601B188u: goto L_0601B188; case 0x0601B18Au: goto L_0601B18A; case 0x0601B18Cu: goto L_0601B18C; case 0x0601B190u: goto L_0601B190; case 0x0601B194u: goto L_0601B194; case 0x0601B196u: goto L_0601B196; case 0x0601B198u: goto L_0601B198; case 0x0601B19Au: goto L_0601B19A; case 0x0601B19Cu: goto L_0601B19C; case 0x0601B19Eu: goto L_0601B19E; case 0x0601B1A0u: goto L_0601B1A0; case 0x0601B1A2u: goto L_0601B1A2; case 0x0601B1A4u: goto L_0601B1A4; case 0x0601B1A6u: goto L_0601B1A6; case 0x0601B1A8u: goto L_0601B1A8; case 0x0601B1AAu: goto L_0601B1AA; case 0x0601B1ACu: goto L_0601B1AC; case 0x0601B1B0u: goto L_0601B1B0; case 0x0601B1B2u: goto L_0601B1B2; case 0x0601B1B4u: goto L_0601B1B4; case 0x0601B1B6u: goto L_0601B1B6; case 0x0601B1B8u: goto L_0601B1B8; case 0x0601B1BAu: goto L_0601B1BA; case 0x0601B1BCu: goto L_0601B1BC; case 0x0601B1BEu: goto L_0601B1BE; case 0x0601B1C0u: goto L_0601B1C0; case 0x0601B1C2u: goto L_0601B1C2; case 0x0601B1C4u: goto L_0601B1C4; case 0x0601B1C8u: goto L_0601B1C8; case 0x0601B1CAu: goto L_0601B1CA; case 0x0601B1CCu: goto L_0601B1CC; case 0x0601B1CEu: goto L_0601B1CE; case 0x0601B1D0u: goto L_0601B1D0; case 0x0601B1D2u: goto L_0601B1D2; case 0x0601B1D4u: goto L_0601B1D4; case 0x0601B1D6u: goto L_0601B1D6; case 0x0601B1D8u: goto L_0601B1D8; case 0x0601B1DAu: goto L_0601B1DA; case 0x0601B1DCu: goto L_0601B1DC; case 0x0601B1DEu: goto L_0601B1DE; case 0x0601B1E0u: goto L_0601B1E0; case 0x0601B1E2u: goto L_0601B1E2; case 0x0601B1E4u: goto L_0601B1E4; case 0x0601B1E6u: goto L_0601B1E6; case 0x0601B1E8u: goto L_0601B1E8; case 0x0601B1EAu: goto L_0601B1EA; case 0x0601B1ECu: goto L_0601B1EC; case 0x0601B1EEu: goto L_0601B1EE; case 0x0601B1F0u: goto L_0601B1F0; case 0x0601B1F2u: goto L_0601B1F2; case 0x0601B1F4u: goto L_0601B1F4; case 0x0601B1F6u: goto L_0601B1F6; case 0x0601B1F8u: goto L_0601B1F8; case 0x0601B1FAu: goto L_0601B1FA; case 0x0601B1FCu: goto L_0601B1FC; case 0x0601B1FEu: goto L_0601B1FE; case 0x0601B200u: goto L_0601B200; case 0x0601B202u: goto L_0601B202; case 0x0601B204u: goto L_0601B204; case 0x0601B206u: goto L_0601B206; case 0x0601B208u: goto L_0601B208; case 0x0601B20Au: goto L_0601B20A; case 0x0601B20Cu: goto L_0601B20C; case 0x0601B20Eu: goto L_0601B20E; case 0x0601B210u: goto L_0601B210; case 0x0601B214u: goto L_0601B214; case 0x0601B216u: goto L_0601B216; case 0x0601B218u: goto L_0601B218; case 0x0601B21Au: goto L_0601B21A; case 0x0601B21Cu: goto L_0601B21C; case 0x0601B21Eu: goto L_0601B21E; case 0x0601B220u: goto L_0601B220; case 0x0601B222u: goto L_0601B222; case 0x0601B224u: goto L_0601B224; case 0x0601B228u: goto L_0601B228; case 0x0601B22Au: goto L_0601B22A; case 0x0601B22Eu: goto L_0601B22E; case 0x0601B260u: goto L_0601B260; case 0x0601B262u: goto L_0601B262; case 0x0601B264u: goto L_0601B264; case 0x0601B266u: goto L_0601B266; case 0x0601B268u: goto L_0601B268; case 0x0601B26Au: goto L_0601B26A; case 0x0601B26Cu: goto L_0601B26C; case 0x0601B26Eu: goto L_0601B26E; case 0x0601B270u: goto L_0601B270; case 0x0601B272u: goto L_0601B272; case 0x0601B274u: goto L_0601B274; case 0x0601B276u: goto L_0601B276; case 0x0601B278u: goto L_0601B278; case 0x0601B27Au: goto L_0601B27A; case 0x0601B27Cu: goto L_0601B27C; case 0x0601B27Eu: goto L_0601B27E; case 0x0601B280u: goto L_0601B280; case 0x0601B284u: goto L_0601B284; case 0x0601B286u: goto L_0601B286; case 0x0601B288u: goto L_0601B288; case 0x0601B28Au: goto L_0601B28A; case 0x0601B28Cu: goto L_0601B28C; case 0x0601B28Eu: goto L_0601B28E; case 0x0601B290u: goto L_0601B290; case 0x0601B292u: goto L_0601B292; case 0x0601B296u: goto L_0601B296; case 0x0601B298u: goto L_0601B298; case 0x0601B29Au: goto L_0601B29A; case 0x0601B29Eu: goto L_0601B29E; case 0x0601B2A0u: goto L_0601B2A0; case 0x0601B2A2u: goto L_0601B2A2; case 0x0601B2A4u: goto L_0601B2A4; case 0x0601B2A6u: goto L_0601B2A6; case 0x0601B2A8u: goto L_0601B2A8; case 0x0601B2AAu: goto L_0601B2AA; case 0x0601B2ACu: goto L_0601B2AC; case 0x0601B2AEu: goto L_0601B2AE; case 0x0601B2B0u: goto L_0601B2B0; case 0x0601B2B4u: goto L_0601B2B4; case 0x0601B2B8u: goto L_0601B2B8; case 0x0601B2BAu: goto L_0601B2BA; case 0x0601B2BCu: goto L_0601B2BC; case 0x0601B2BEu: goto L_0601B2BE; case 0x0601B2C0u: goto L_0601B2C0; case 0x0601B2C2u: goto L_0601B2C2; case 0x0601B2C4u: goto L_0601B2C4; case 0x0601B2C6u: goto L_0601B2C6; case 0x0601B2C8u: goto L_0601B2C8; case 0x0601B2CAu: goto L_0601B2CA; case 0x0601B2CCu: goto L_0601B2CC; case 0x0601B2CEu: goto L_0601B2CE; case 0x0601B2D0u: goto L_0601B2D0; case 0x0601B2D2u: goto L_0601B2D2; case 0x0601B2D4u: goto L_0601B2D4; case 0x0601B2D6u: goto L_0601B2D6; case 0x0601B2D8u: goto L_0601B2D8; case 0x0601B2DAu: goto L_0601B2DA; case 0x0601B2DEu: goto L_0601B2DE; case 0x0601B2E0u: goto L_0601B2E0; case 0x0601B2E2u: goto L_0601B2E2; case 0x0601B2E4u: goto L_0601B2E4; case 0x0601B2E6u: goto L_0601B2E6; case 0x0601B2E8u: goto L_0601B2E8; case 0x0601B2EAu: goto L_0601B2EA; case 0x0601B2ECu: goto L_0601B2EC; case 0x0601B2EEu: goto L_0601B2EE; case 0x0601B2F0u: goto L_0601B2F0; case 0x0601B2F2u: goto L_0601B2F2; case 0x0601B2F4u: goto L_0601B2F4; case 0x0601B2F6u: goto L_0601B2F6; case 0x0601B2F8u: goto L_0601B2F8; case 0x0601B2FAu: goto L_0601B2FA; case 0x0601B2FCu: goto L_0601B2FC; case 0x0601B2FEu: goto L_0601B2FE; case 0x0601B300u: goto L_0601B300; case 0x0601B302u: goto L_0601B302; case 0x0601B306u: goto L_0601B306; case 0x0601B308u: goto L_0601B308; case 0x0601B30Au: goto L_0601B30A; case 0x0601B30Cu: goto L_0601B30C; case 0x0601B30Eu: goto L_0601B30E; case 0x0601B312u: goto L_0601B312; case 0x0601B314u: goto L_0601B314; case 0x0601B316u: goto L_0601B316; case 0x0601B318u: goto L_0601B318; case 0x0601B31Au: goto L_0601B31A; case 0x0601B31Cu: goto L_0601B31C; case 0x0601B320u: goto L_0601B320; case 0x0601B322u: goto L_0601B322; case 0x0601B324u: goto L_0601B324; case 0x0601B326u: goto L_0601B326; case 0x0601B328u: goto L_0601B328; case 0x0601B32Cu: goto L_0601B32C; case 0x0601B32Eu: goto L_0601B32E; case 0x0601B330u: goto L_0601B330; case 0x0601B332u: goto L_0601B332; case 0x0601B334u: goto L_0601B334; case 0x0601B336u: goto L_0601B336; case 0x0601B338u: goto L_0601B338; case 0x0601B33Au: goto L_0601B33A; case 0x0601B33Cu: goto L_0601B33C; case 0x0601B340u: goto L_0601B340; case 0x0601B342u: goto L_0601B342; case 0x0601B346u: goto L_0601B346; case 0x0601B348u: goto L_0601B348; case 0x0601B34Au: goto L_0601B34A; case 0x0601B34Eu: goto L_0601B34E; case 0x0601B350u: goto L_0601B350; case 0x0601B352u: goto L_0601B352; case 0x0601B354u: goto L_0601B354; case 0x0601B356u: goto L_0601B356; case 0x0601B358u: goto L_0601B358; case 0x0601B35Au: goto L_0601B35A; case 0x0601B35Cu: goto L_0601B35C; case 0x0601B35Eu: goto L_0601B35E; case 0x0601B360u: goto L_0601B360; case 0x0601B362u: goto L_0601B362; case 0x0601B364u: goto L_0601B364; case 0x0601B366u: goto L_0601B366; case 0x0601B368u: goto L_0601B368; case 0x0601B36Au: goto L_0601B36A; case 0x0601B36Cu: goto L_0601B36C; case 0x0601B36Eu: goto L_0601B36E; case 0x0601B370u: goto L_0601B370; case 0x0601B372u: goto L_0601B372; case 0x0601B374u: goto L_0601B374; case 0x0601B376u: goto L_0601B376; case 0x0601B378u: goto L_0601B378; case 0x0601B37Au: goto L_0601B37A; case 0x0601B37Eu: goto L_0601B37E; case 0x0601B380u: goto L_0601B380; case 0x0601B382u: goto L_0601B382; case 0x0601B384u: goto L_0601B384; case 0x0601B386u: goto L_0601B386; case 0x0601B388u: goto L_0601B388; case 0x0601B38Au: goto L_0601B38A; case 0x0601B38Cu: goto L_0601B38C; case 0x0601B38Eu: goto L_0601B38E; case 0x0601B392u: goto L_0601B392; case 0x0601B394u: goto L_0601B394; case 0x0601B398u: goto L_0601B398; case 0x0601B39Cu: goto L_0601B39C; case 0x0601B39Eu: goto L_0601B39E; case 0x0601B3A0u: goto L_0601B3A0; case 0x0601B3A2u: goto L_0601B3A2; case 0x0601B3A4u: goto L_0601B3A4; case 0x0601B3A6u: goto L_0601B3A6; case 0x0601B3A8u: goto L_0601B3A8; case 0x0601B3AAu: goto L_0601B3AA; case 0x0601B3ACu: goto L_0601B3AC; case 0x0601B3AEu: goto L_0601B3AE; case 0x0601B3B0u: goto L_0601B3B0; case 0x0601B3B2u: goto L_0601B3B2; case 0x0601B3B4u: goto L_0601B3B4; case 0x0601B3B6u: goto L_0601B3B6; case 0x0601B3B8u: goto L_0601B3B8; case 0x0601B3BAu: goto L_0601B3BA; case 0x0601B3BCu: goto L_0601B3BC; case 0x0601B3BEu: goto L_0601B3BE; case 0x0601B3C0u: goto L_0601B3C0; case 0x0601B3C2u: goto L_0601B3C2; case 0x0601B3C4u: goto L_0601B3C4; case 0x0601B3C6u: goto L_0601B3C6; case 0x0601B3C8u: goto L_0601B3C8; case 0x0601B3CAu: goto L_0601B3CA; case 0x0601B3CCu: goto L_0601B3CC; case 0x0601B3CEu: goto L_0601B3CE; case 0x0601B3D0u: goto L_0601B3D0; case 0x0601B3D2u: goto L_0601B3D2; case 0x0601B3D4u: goto L_0601B3D4; case 0x0601B3D6u: goto L_0601B3D6; case 0x0601B3D8u: goto L_0601B3D8; case 0x0601B3DAu: goto L_0601B3DA; case 0x0601B3DCu: goto L_0601B3DC; case 0x0601B3DEu: goto L_0601B3DE; case 0x0601B3E0u: goto L_0601B3E0; case 0x0601B3E2u: goto L_0601B3E2; case 0x0601B3E4u: goto L_0601B3E4; case 0x0601B3E6u: goto L_0601B3E6; case 0x0601B3E8u: goto L_0601B3E8; case 0x0601B3EAu: goto L_0601B3EA; case 0x0601B3ECu: goto L_0601B3EC; case 0x0601B3EEu: goto L_0601B3EE; case 0x0601B3F2u: goto L_0601B3F2; case 0x0601B3F4u: goto L_0601B3F4; case 0x0601B3F6u: goto L_0601B3F6; case 0x0601B3FAu: goto L_0601B3FA; case 0x0601B3FCu: goto L_0601B3FC; case 0x0601B3FEu: goto L_0601B3FE; case 0x0601B400u: goto L_0601B400; case 0x0601B402u: goto L_0601B402; case 0x0601B406u: goto L_0601B406; case 0x0601B408u: goto L_0601B408; case 0x0601B40Au: goto L_0601B40A; case 0x0601B40Cu: goto L_0601B40C; case 0x0601B410u: goto L_0601B410; case 0x0601B412u: goto L_0601B412; case 0x0601B414u: goto L_0601B414; case 0x0601B416u: goto L_0601B416; case 0x0601B418u: goto L_0601B418; case 0x0601B41Au: goto L_0601B41A; case 0x0601B41Cu: goto L_0601B41C; case 0x0601B41Eu: goto L_0601B41E; case 0x0601B420u: goto L_0601B420; case 0x0601B424u: goto L_0601B424; case 0x0601B426u: goto L_0601B426; case 0x0601B428u: goto L_0601B428; case 0x0601B42Au: goto L_0601B42A; case 0x0601B42Cu: goto L_0601B42C; case 0x0601B42Eu: goto L_0601B42E; case 0x0601B430u: goto L_0601B430; case 0x0601B458u: goto L_0601B458; case 0x0601B45Au: goto L_0601B45A; case 0x0601B45Cu: goto L_0601B45C; case 0x0601B45Eu: goto L_0601B45E; case 0x0601B460u: goto L_0601B460; case 0x0601B462u: goto L_0601B462; case 0x0601B464u: goto L_0601B464; case 0x0601B466u: goto L_0601B466; case 0x0601B46Au: goto L_0601B46A; case 0x0601B46Cu: goto L_0601B46C; case 0x0601B470u: goto L_0601B470; case 0x0601B472u: goto L_0601B472; case 0x0601B474u: goto L_0601B474; case 0x0601B476u: goto L_0601B476; case 0x0601B478u: goto L_0601B478; case 0x0601B47Au: goto L_0601B47A; case 0x0601B47Cu: goto L_0601B47C; case 0x0601B47Eu: goto L_0601B47E; case 0x0601B480u: goto L_0601B480; case 0x0601B482u: goto L_0601B482; case 0x0601B486u: goto L_0601B486; case 0x0601B488u: goto L_0601B488; case 0x0601B48Au: goto L_0601B48A; case 0x0601B48Cu: goto L_0601B48C; case 0x0601B48Eu: goto L_0601B48E; case 0x0601B490u: goto L_0601B490; case 0x0601B492u: goto L_0601B492; case 0x0601B494u: goto L_0601B494; case 0x0601B496u: goto L_0601B496; case 0x0601B49Au: goto L_0601B49A; case 0x0601B49Cu: goto L_0601B49C; case 0x0601B49Eu: goto L_0601B49E; case 0x0601B4A2u: goto L_0601B4A2; case 0x0601B4A4u: goto L_0601B4A4; case 0x0601B4A6u: goto L_0601B4A6; case 0x0601B4AAu: goto L_0601B4AA; case 0x0601B4ACu: goto L_0601B4AC; case 0x0601B4AEu: goto L_0601B4AE; case 0x0601B4B0u: goto L_0601B4B0; case 0x0601B4B2u: goto L_0601B4B2; case 0x0601B4B4u: goto L_0601B4B4; case 0x0601B4B6u: goto L_0601B4B6; case 0x0601B4B8u: goto L_0601B4B8; case 0x0601B4BAu: goto L_0601B4BA; case 0x0601B4BCu: goto L_0601B4BC; case 0x0601B4BEu: goto L_0601B4BE; case 0x0601B4C0u: goto L_0601B4C0; case 0x0601B4C2u: goto L_0601B4C2; case 0x0601B4C4u: goto L_0601B4C4; case 0x0601B4C6u: goto L_0601B4C6; case 0x0601B4C8u: goto L_0601B4C8; case 0x0601B4CAu: goto L_0601B4CA; case 0x0601B4CCu: goto L_0601B4CC; case 0x0601B4CEu: goto L_0601B4CE; case 0x0601B4D0u: goto L_0601B4D0; case 0x0601B4D2u: goto L_0601B4D2; case 0x0601B4D6u: goto L_0601B4D6; case 0x0601B4D8u: goto L_0601B4D8; case 0x0601B4DAu: goto L_0601B4DA; case 0x0601B4DCu: goto L_0601B4DC; case 0x0601B4DEu: goto L_0601B4DE; case 0x0601B4E0u: goto L_0601B4E0; case 0x0601B4E2u: goto L_0601B4E2; case 0x0601B4E4u: goto L_0601B4E4; case 0x0601B4E6u: goto L_0601B4E6; case 0x0601B4EAu: goto L_0601B4EA; case 0x0601B4ECu: goto L_0601B4EC; case 0x0601B4F0u: goto L_0601B4F0; case 0x0601B4F4u: goto L_0601B4F4; case 0x0601B4F6u: goto L_0601B4F6; case 0x0601B4F8u: goto L_0601B4F8; case 0x0601B4FAu: goto L_0601B4FA; case 0x0601B4FCu: goto L_0601B4FC; case 0x0601B4FEu: goto L_0601B4FE; case 0x0601B500u: goto L_0601B500; case 0x0601B502u: goto L_0601B502; case 0x0601B504u: goto L_0601B504; case 0x0601B506u: goto L_0601B506; case 0x0601B508u: goto L_0601B508; case 0x0601B50Au: goto L_0601B50A; case 0x0601B50Cu: goto L_0601B50C; case 0x0601B50Eu: goto L_0601B50E; case 0x0601B510u: goto L_0601B510; case 0x0601B512u: goto L_0601B512; case 0x0601B516u: goto L_0601B516; case 0x0601B51Au: goto L_0601B51A; case 0x0601B51Cu: goto L_0601B51C; case 0x0601B51Eu: goto L_0601B51E; case 0x0601B520u: goto L_0601B520; case 0x0601B522u: goto L_0601B522; case 0x0601B524u: goto L_0601B524; case 0x0601B526u: goto L_0601B526; case 0x0601B528u: goto L_0601B528; case 0x0601B52Au: goto L_0601B52A; case 0x0601B52Cu: goto L_0601B52C; case 0x0601B530u: goto L_0601B530; case 0x0601B532u: goto L_0601B532; case 0x0601B534u: goto L_0601B534; case 0x0601B536u: goto L_0601B536; case 0x0601B538u: goto L_0601B538; case 0x0601B53Au: goto L_0601B53A; case 0x0601B53Cu: goto L_0601B53C; case 0x0601B53Eu: goto L_0601B53E; case 0x0601B540u: goto L_0601B540; case 0x0601B542u: goto L_0601B542; case 0x0601B544u: goto L_0601B544; case 0x0601B546u: goto L_0601B546; case 0x0601B548u: goto L_0601B548; case 0x0601B54Au: goto L_0601B54A; case 0x0601B54Cu: goto L_0601B54C; case 0x0601B54Eu: goto L_0601B54E; case 0x0601B550u: goto L_0601B550; case 0x0601B552u: goto L_0601B552; case 0x0601B554u: goto L_0601B554; case 0x0601B556u: goto L_0601B556; case 0x0601B558u: goto L_0601B558; case 0x0601B57Cu: goto L_0601B57C; case 0x0601B57Eu: goto L_0601B57E; case 0x0601B580u: goto L_0601B580; case 0x0601B582u: goto L_0601B582; case 0x0601B584u: goto L_0601B584; case 0x0601B586u: goto L_0601B586; case 0x0601B588u: goto L_0601B588; case 0x0601B58Au: goto L_0601B58A; case 0x0601B58Cu: goto L_0601B58C; case 0x0601B58Eu: goto L_0601B58E; case 0x0601B590u: goto L_0601B590; case 0x0601B592u: goto L_0601B592; case 0x0601B594u: goto L_0601B594; case 0x0601B596u: goto L_0601B596; case 0x0601B598u: goto L_0601B598; case 0x0601B59Au: goto L_0601B59A; case 0x0601B59Cu: goto L_0601B59C; case 0x0601B59Eu: goto L_0601B59E; case 0x0601B5A0u: goto L_0601B5A0; case 0x0601B5A4u: goto L_0601B5A4; case 0x0601B5A6u: goto L_0601B5A6; case 0x0601B5A8u: goto L_0601B5A8; case 0x0601B5AAu: goto L_0601B5AA; case 0x0601B5ACu: goto L_0601B5AC; case 0x0601B5B0u: goto L_0601B5B0; case 0x0601B5B2u: goto L_0601B5B2; case 0x0601B5B4u: goto L_0601B5B4; case 0x0601B5B6u: goto L_0601B5B6; case 0x0601B5B8u: goto L_0601B5B8; case 0x0601B5BAu: goto L_0601B5BA; case 0x0601B5BEu: goto L_0601B5BE; case 0x0601B5C0u: goto L_0601B5C0; case 0x0601B5C2u: goto L_0601B5C2; case 0x0601B5C4u: goto L_0601B5C4; case 0x0601B5C6u: goto L_0601B5C6; case 0x0601B5C8u: goto L_0601B5C8; case 0x0601B5CAu: goto L_0601B5CA; case 0x0601B5CCu: goto L_0601B5CC; case 0x0601B5CEu: goto L_0601B5CE; case 0x0601B5D0u: goto L_0601B5D0; case 0x0601B5D2u: goto L_0601B5D2; case 0x0601B5D4u: goto L_0601B5D4; case 0x0601B5D6u: goto L_0601B5D6; case 0x0601B5D8u: goto L_0601B5D8; case 0x0601B5DAu: goto L_0601B5DA; case 0x0601B5DCu: goto L_0601B5DC; case 0x0601B5DEu: goto L_0601B5DE; case 0x0601B5E2u: goto L_0601B5E2; case 0x0601B5E4u: goto L_0601B5E4; case 0x0601B5E6u: goto L_0601B5E6; case 0x0601B5E8u: goto L_0601B5E8; case 0x0601B5EAu: goto L_0601B5EA; case 0x0601B5ECu: goto L_0601B5EC; case 0x0601B5EEu: goto L_0601B5EE; case 0x0601B5F0u: goto L_0601B5F0; case 0x0601B5F2u: goto L_0601B5F2; case 0x0601B5F4u: goto L_0601B5F4; case 0x0601B5F6u: goto L_0601B5F6; case 0x0601B5F8u: goto L_0601B5F8; case 0x0601B5FAu: goto L_0601B5FA; case 0x0601B5FCu: goto L_0601B5FC; case 0x0601B5FEu: goto L_0601B5FE; case 0x0601B602u: goto L_0601B602; case 0x0601B604u: goto L_0601B604; case 0x0601B608u: goto L_0601B608; case 0x0601B60Cu: goto L_0601B60C; case 0x0601B60Eu: goto L_0601B60E; case 0x0601B610u: goto L_0601B610; case 0x0601B612u: goto L_0601B612; case 0x0601B614u: goto L_0601B614; case 0x0601B616u: goto L_0601B616; case 0x0601B618u: goto L_0601B618; case 0x0601B61Au: goto L_0601B61A; case 0x0601B61Cu: goto L_0601B61C; case 0x0601B61Eu: goto L_0601B61E; case 0x0601B620u: goto L_0601B620; case 0x0601B622u: goto L_0601B622; case 0x0601B624u: goto L_0601B624; case 0x0601B626u: goto L_0601B626; case 0x0601B628u: goto L_0601B628; case 0x0601B62Au: goto L_0601B62A; case 0x0601B62Cu: goto L_0601B62C; case 0x0601B62Eu: goto L_0601B62E; case 0x0601B630u: goto L_0601B630; case 0x0601B632u: goto L_0601B632; case 0x0601B634u: goto L_0601B634; case 0x0601B636u: goto L_0601B636; case 0x0601B638u: goto L_0601B638; case 0x0601B63Au: goto L_0601B63A; case 0x0601B63Cu: goto L_0601B63C; case 0x0601B63Eu: goto L_0601B63E; case 0x0601B640u: goto L_0601B640; case 0x0601B642u: goto L_0601B642; case 0x0601B644u: goto L_0601B644; case 0x0601B646u: goto L_0601B646; case 0x0601B648u: goto L_0601B648; case 0x0601B64Au: goto L_0601B64A; case 0x0601B64Cu: goto L_0601B64C; case 0x0601B64Eu: goto L_0601B64E; case 0x0601B650u: goto L_0601B650; case 0x0601B652u: goto L_0601B652; case 0x0601B654u: goto L_0601B654; case 0x0601B656u: goto L_0601B656; case 0x0601B658u: goto L_0601B658; case 0x0601B65Au: goto L_0601B65A; case 0x0601B65Cu: goto L_0601B65C; case 0x0601B65Eu: goto L_0601B65E; case 0x0601B660u: goto L_0601B660; case 0x0601B664u: goto L_0601B664; case 0x0601B666u: goto L_0601B666; case 0x0601B66Au: goto L_0601B66A; case 0x0601B66Cu: goto L_0601B66C; case 0x0601B66Eu: goto L_0601B66E; case 0x0601B670u: goto L_0601B670; case 0x0601B672u: goto L_0601B672; case 0x0601B674u: goto L_0601B674; case 0x0601B676u: goto L_0601B676; case 0x0601B678u: goto L_0601B678; case 0x0601B67Au: goto L_0601B67A; case 0x0601B67Eu: goto L_0601B67E; case 0x0601B682u: goto L_0601B682; case 0x0601B684u: goto L_0601B684; case 0x0601B688u: goto L_0601B688; case 0x0601B68Au: goto L_0601B68A; case 0x0601B68Cu: goto L_0601B68C; case 0x0601B68Eu: goto L_0601B68E; case 0x0601B690u: goto L_0601B690; case 0x0601B692u: goto L_0601B692; case 0x0601B696u: goto L_0601B696; case 0x0601B698u: goto L_0601B698; case 0x0601B69Au: goto L_0601B69A; case 0x0601B69Cu: goto L_0601B69C; case 0x0601B69Eu: goto L_0601B69E; case 0x0601B6A0u: goto L_0601B6A0; case 0x0601B6A4u: goto L_0601B6A4; case 0x0601B6A6u: goto L_0601B6A6; case 0x0601B6A8u: goto L_0601B6A8; case 0x0601B6AAu: goto L_0601B6AA; case 0x0601B6ACu: goto L_0601B6AC; case 0x0601B6AEu: goto L_0601B6AE; case 0x0601B6B0u: goto L_0601B6B0; case 0x0601B6B2u: goto L_0601B6B2; case 0x0601B6B4u: goto L_0601B6B4; case 0x0601B6B6u: goto L_0601B6B6; case 0x0601B6B8u: goto L_0601B6B8; case 0x0601B6BAu: goto L_0601B6BA; case 0x0601B6BCu: goto L_0601B6BC; case 0x0601B6BEu: goto L_0601B6BE; case 0x0601B6C0u: goto L_0601B6C0; case 0x0601B6C2u: goto L_0601B6C2; case 0x0601B6C4u: goto L_0601B6C4; case 0x0601B6C8u: goto L_0601B6C8; case 0x0601B6CAu: goto L_0601B6CA; case 0x0601B6CEu: goto L_0601B6CE; case 0x0601B6D0u: goto L_0601B6D0; case 0x0601B6D2u: goto L_0601B6D2; case 0x0601B6D4u: goto L_0601B6D4; case 0x0601B6D6u: goto L_0601B6D6; case 0x0601B6D8u: goto L_0601B6D8; case 0x0601B6DAu: goto L_0601B6DA; case 0x0601B6DCu: goto L_0601B6DC; case 0x0601B6DEu: goto L_0601B6DE; case 0x0601B6E0u: goto L_0601B6E0; case 0x0607EB7Cu: goto L_0607EB7C; case 0x0607EB7Eu: goto L_0607EB7E; case 0x0607EB80u: goto L_0607EB80; case 0x0607EB82u: goto L_0607EB82; case 0x0607EB84u: goto L_0607EB84; case 0x0607EB86u: goto L_0607EB86; case 0x0607EB88u: goto L_0607EB88; case 0x0607EB8Au: goto L_0607EB8A; case 0x0607EB8Cu: goto L_0607EB8C; case 0x0607EB8Eu: goto L_0607EB8E; case 0x0607EB90u: goto L_0607EB90; case 0x0607EB92u: goto L_0607EB92; case 0x0607EB94u: goto L_0607EB94; case 0x0607EB96u: goto L_0607EB96; case 0x0607EB98u: goto L_0607EB98; case 0x0607EB9Au: goto L_0607EB9A; case 0x0607EB9Cu: goto L_0607EB9C; case 0x0607EB9Eu: goto L_0607EB9E; case 0x0607EBA0u: goto L_0607EBA0; case 0x0607EBA2u: goto L_0607EBA2; case 0x0607EBA4u: goto L_0607EBA4; case 0x0607EBA6u: goto L_0607EBA6; case 0x0607EBA8u: goto L_0607EBA8; case 0x0607EBAAu: goto L_0607EBAA; case 0x0607EBACu: goto L_0607EBAC; case 0x0607EBAEu: goto L_0607EBAE; case 0x0607EBB0u: goto L_0607EBB0; case 0x0607EBB2u: goto L_0607EBB2; case 0x0607EBB4u: goto L_0607EBB4; case 0x0607EBB6u: goto L_0607EBB6; case 0x0607EBBAu: goto L_0607EBBA; case 0x0607EBBCu: goto L_0607EBBC; case 0x0607EBBEu: goto L_0607EBBE; case 0x0607EBC2u: goto L_0607EBC2; case 0x0607EBC4u: goto L_0607EBC4; case 0x0607EBC6u: goto L_0607EBC6; case 0x0607EBC8u: goto L_0607EBC8; case 0x0607EBCAu: goto L_0607EBCA; case 0x0607EBCCu: goto L_0607EBCC; case 0x0607EBD0u: goto L_0607EBD0; case 0x0607EBD2u: goto L_0607EBD2; case 0x0607EBD4u: goto L_0607EBD4; case 0x0607EBD6u: goto L_0607EBD6; case 0x0607EBD8u: goto L_0607EBD8; case 0x0607EBDAu: goto L_0607EBDA; case 0x0607EBDCu: goto L_0607EBDC; case 0x0607EBDEu: goto L_0607EBDE; case 0x0607EBE0u: goto L_0607EBE0; case 0x0607EBE2u: goto L_0607EBE2; case 0x0607EBE4u: goto L_0607EBE4; case 0x0607EBE6u: goto L_0607EBE6; case 0x0607EBE8u: goto L_0607EBE8; case 0x0607EBEAu: goto L_0607EBEA; case 0x0607EBECu: goto L_0607EBEC; case 0x0607EBEEu: goto L_0607EBEE; case 0x0607EBF0u: goto L_0607EBF0; case 0x0607EBF2u: goto L_0607EBF2; case 0x0607EBF4u: goto L_0607EBF4; case 0x0607EBF6u: goto L_0607EBF6; case 0x0607EBF8u: goto L_0607EBF8; case 0x0607EBFCu: goto L_0607EBFC; case 0x0607EBFEu: goto L_0607EBFE; case 0x0607EC02u: goto L_0607EC02; case 0x0607EC04u: goto L_0607EC04; case 0x0607EC06u: goto L_0607EC06; case 0x0607EC08u: goto L_0607EC08; case 0x0607EC0Au: goto L_0607EC0A; case 0x0607EC0Cu: goto L_0607EC0C; case 0x0607EC0Eu: goto L_0607EC0E; case 0x0607EC10u: goto L_0607EC10; case 0x0607EC12u: goto L_0607EC12; case 0x0607EC14u: goto L_0607EC14; case 0x0607EC16u: goto L_0607EC16; case 0x0607EC18u: goto L_0607EC18; case 0x0607EC1Au: goto L_0607EC1A; case 0x0607EC1Cu: goto L_0607EC1C; case 0x0607EC1Eu: goto L_0607EC1E; case 0x0607EC20u: goto L_0607EC20; case 0x0607EC22u: goto L_0607EC22; case 0x0607EC26u: goto L_0607EC26; case 0x0607EC28u: goto L_0607EC28; case 0x0607EC2Au: goto L_0607EC2A; case 0x0607EC2Cu: goto L_0607EC2C; case 0x0607EC2Eu: goto L_0607EC2E; case 0x0607EC30u: goto L_0607EC30; case 0x0607EC32u: goto L_0607EC32; case 0x0607EC34u: goto L_0607EC34; case 0x0607EC36u: goto L_0607EC36; case 0x0607EC38u: goto L_0607EC38; case 0x0607EC3Au: goto L_0607EC3A; case 0x0607EC3Cu: goto L_0607EC3C; case 0x0607EC3Eu: goto L_0607EC3E; case 0x0607EC40u: goto L_0607EC40; case 0x0607EC42u: goto L_0607EC42; case 0x0607EC44u: goto L_0607EC44; case 0x0607EC46u: goto L_0607EC46; case 0x0607EC48u: goto L_0607EC48; case 0x0607EC4Au: goto L_0607EC4A; case 0x0607EC4Cu: goto L_0607EC4C; case 0x0607EC50u: goto L_0607EC50; case 0x0607EC52u: goto L_0607EC52; case 0x0607EC54u: goto L_0607EC54; case 0x0607EC56u: goto L_0607EC56; case 0x0607EC58u: goto L_0607EC58; case 0x0607EC5Au: goto L_0607EC5A; case 0x0607EC5Cu: goto L_0607EC5C; case 0x0607EC5Eu: goto L_0607EC5E; case 0x0607EC60u: goto L_0607EC60; case 0x0607EC64u: goto L_0607EC64; case 0x0607EC66u: goto L_0607EC66; case 0x0607EC68u: goto L_0607EC68; case 0x0607EC6Au: goto L_0607EC6A; case 0x0607EC6Cu: goto L_0607EC6C; case 0x0607EC6Eu: goto L_0607EC6E; case 0x0607EC70u: goto L_0607EC70; case 0x0607EC74u: goto L_0607EC74; case 0x0607EC76u: goto L_0607EC76; case 0x0607EC78u: goto L_0607EC78; case 0x0607EC7Au: goto L_0607EC7A; case 0x0607EC7Cu: goto L_0607EC7C; case 0x0607EC7Eu: goto L_0607EC7E; case 0x0607EC80u: goto L_0607EC80; case 0x0607EC82u: goto L_0607EC82; case 0x0607EC84u: goto L_0607EC84; case 0x0607EC86u: goto L_0607EC86; case 0x0607EC88u: goto L_0607EC88; case 0x0607EC8Au: goto L_0607EC8A; case 0x0607EC8Cu: goto L_0607EC8C; case 0x0607EC8Eu: goto L_0607EC8E; case 0x0607EC90u: goto L_0607EC90; case 0x0607EC92u: goto L_0607EC92; case 0x0607EC94u: goto L_0607EC94; case 0x0607EC96u: goto L_0607EC96; case 0x0607EC98u: goto L_0607EC98; case 0x0607EC9Au: goto L_0607EC9A; case 0x0607EC9Cu: goto L_0607EC9C; case 0x0607EC9Eu: goto L_0607EC9E; case 0x0607ECA0u: goto L_0607ECA0; case 0x0607ECA2u: goto L_0607ECA2; case 0x0607ECA4u: goto L_0607ECA4; case 0x0607ECA8u: goto L_0607ECA8; case 0x0607ECAAu: goto L_0607ECAA; case 0x0607ECACu: goto L_0607ECAC; case 0x0607ECAEu: goto L_0607ECAE; case 0x0607ECB0u: goto L_0607ECB0; case 0x0607ECB2u: goto L_0607ECB2; case 0x0607ECB4u: goto L_0607ECB4; case 0x0607ECB6u: goto L_0607ECB6; case 0x0607ECB8u: goto L_0607ECB8; case 0x0607ECBAu: goto L_0607ECBA; case 0x0607ECBCu: goto L_0607ECBC; case 0x0607ECBEu: goto L_0607ECBE; case 0x0607ECC0u: goto L_0607ECC0; case 0x0607ECC2u: goto L_0607ECC2; case 0x0607ECC4u: goto L_0607ECC4; case 0x0607ECC6u: goto L_0607ECC6; case 0x0607ECC8u: goto L_0607ECC8; case 0x0607ECCAu: goto L_0607ECCA; case 0x0607ECCCu: goto L_0607ECCC; case 0x0607ECCEu: goto L_0607ECCE; case 0x0607ECD0u: goto L_0607ECD0; case 0x0607ECD2u: goto L_0607ECD2; case 0x0607ECD6u: goto L_0607ECD6; case 0x0607ECD8u: goto L_0607ECD8; case 0x0607ECDAu: goto L_0607ECDA; case 0x0607ECDCu: goto L_0607ECDC; case 0x0607ECDEu: goto L_0607ECDE; case 0x0607ECE0u: goto L_0607ECE0; case 0x0607ECE4u: goto L_0607ECE4; case 0x0607ECE8u: goto L_0607ECE8; case 0x0607ECEAu: goto L_0607ECEA; case 0x0607EE54u: goto L_0607EE54; case 0x0607EE56u: goto L_0607EE56; case 0x0607EE58u: goto L_0607EE58; case 0x0607EE5Au: goto L_0607EE5A; case 0x0607EE5Cu: goto L_0607EE5C; case 0x0607EE5Eu: goto L_0607EE5E; case 0x0607EE60u: goto L_0607EE60; case 0x0607EE62u: goto L_0607EE62; case 0x0608431Eu: goto L_0608431E; case 0x06084320u: goto L_06084320; case 0x06084322u: goto L_06084322; case 0x06084324u: goto L_06084324; case 0x06084326u: goto L_06084326; case 0x06084328u: goto L_06084328; case 0x0608432Au: goto L_0608432A; case 0x0608432Cu: goto L_0608432C; case 0x06084330u: goto L_06084330; case 0x06084332u: goto L_06084332; case 0x06084334u: goto L_06084334; case 0x06084336u: goto L_06084336; case 0x06084338u: goto L_06084338; case 0x0608433Au: goto L_0608433A; case 0x0608433Cu: goto L_0608433C; case 0x0608433Eu: goto L_0608433E; case 0x06084340u: goto L_06084340; case 0x06084342u: goto L_06084342; case 0x06084344u: goto L_06084344; case 0x06084346u: goto L_06084346; case 0x06084348u: goto L_06084348; case 0x0608434Au: goto L_0608434A; case 0x0608434Cu: goto L_0608434C; case 0x0608434Eu: goto L_0608434E; case 0x06084350u: goto L_06084350; case 0x06084352u: goto L_06084352; case 0x06084354u: goto L_06084354; case 0x06084356u: goto L_06084356; case 0x06084358u: goto L_06084358; case 0x0608435Au: goto L_0608435A; case 0x0608435Cu: goto L_0608435C; case 0x0608435Eu: goto L_0608435E; case 0x06084362u: goto L_06084362; case 0x06084364u: goto L_06084364; default: sh2_call(c, x); return; } }  // 0601B116 jmp @r0 ; nop
L_0601B124:
    c.r[3] = ld32(0x0601B240u);  // 0601B124 mov.l 0x0601B240,r3
L_0601B126:
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0601B126 mov.w @r3,r2
L_0601B128:
    c.r[7] = ld32(0x0601B244u);  // 0601B128 mov.l 0x0601B244,r7
L_0601B12A:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[7]);  // 0601B12A mov.w @r7,r1
L_0601B12C:
    c.r[2] |= c.r[1];  // 0601B12C or r1,r2
L_0601B12E:
    st16(c.r[3], c.r[2]);  // 0601B12E mov.w r2,@r3
L_0601B130:
    c.r[1] = 0x0u;  // 0601B130 mov #0,r1
L_0601B132:
    st16(c.r[7], c.r[1]);  // 0601B132 mov.w r1,@r7
L_0601B134:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601B232u);  // 0601B134 mov.w 0x0601B232,r1
L_0601B136:
    c.r[1] &= c.r[2];  // 0601B136 and r2,r1
L_0601B138:
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601B138 tst r1,r1
L_0601B13A:
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0601B144; } }  // 0601B13A bt/s 0x0601B144 ; mov r15,r14
L_0601B13E:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601B234u);  // 0601B13E mov.w 0x0601B234,r0
L_0601B140:
    c.r[15] = c.r[14]; goto L_0601B6D2;  // 0601B140 bra 0x0601B6D2 ; mov r14,r15
L_0601B144:
    c.r[0] = c.r[2];  // 0601B144 mov r2,r0
L_0601B146:
    c.r[0] >>= 8;  // 0601B146 shlr8 r0
L_0601B148:
    c.r[0] &= 0x1u;  // 0601B148 and #1,r0
L_0601B14A:
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601B14A tst r0,r0
L_0601B14C:
    if (c.t) { goto L_0601B156; }  // 0601B14C bt 0x0601B156
L_0601B14E:
    c.r[15] = c.r[14];  // 0601B14E mov r14,r15
L_0601B150:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601B236u);  // 0601B150 mov.w 0x0601B236,r0
L_0601B152:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; } goto L_0601B6D4;  // 0601B152 bra 0x0601B6D4 ; lds.l @r15+,pr
L_0601B156:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601B238u);  // 0601B156 mov.w 0x0601B238,r1
L_0601B158:
    c.r[2] &= c.r[1];  // 0601B158 and r1,r2
L_0601B15A:
    c.t = (c.r[2] & c.r[2]) == 0;  // 0601B15A tst r2,r2
L_0601B15C:
    if (c.t) { goto L_0601B162; }  // 0601B15C bt 0x0601B162
L_0601B15E:
    goto L_0601B46A;  // 0601B15E bra 0x0601B46A ; nop
L_0601B162:
    c.r[1] = ld32(0x0601B248u);  // 0601B162 mov.l 0x0601B248,r1
L_0601B164:
    c.r[9] = ld32(c.r[1]);  // 0601B164 mov.l @r1,r9
L_0601B166:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0601B166 mov.b @r9,r0
L_0601B168:
    c.r[0] &= 0xC0u;  // 0601B168 and #192,r0
L_0601B16A:
    c.r[0] >>= 2;  // 0601B16A shlr2 r0
L_0601B16C:
    c.r[0] >>= 2;  // 0601B16C shlr2 r0
L_0601B16E:
    c.r[0] >>= 2;  // 0601B16E shlr2 r0
L_0601B170:
    c.t = c.r[0] == 0x1u;  // 0601B170 cmp/eq #1,r0
L_0601B172:
    { const bool k = c.t; c.t = (c.r[9] & c.r[9]) == 0; if (k) { goto L_0601B18C; } }  // 0601B172 bt/s 0x0601B18C ; tst r9,r9
L_0601B176:
    c.r[1] = ld32(0x0601B24Cu);  // 0601B176 mov.l 0x0601B24C,r1
L_0601B178:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B178 mov.b @r1,r1
L_0601B17A:
    c.r[0] = c.r[1] & 0xFFu;  // 0601B17A extu.b r1,r0
L_0601B17C:
    c.r[1] = ld32(0x0601B250u);  // 0601B17C mov.l 0x0601B250,r1
L_0601B17E:
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601B17E mov.b @(r0,r1),r5
L_0601B180:
    c.r[4] = c.r[9];  // 0601B180 mov r9,r4
L_0601B182:
    c.r[0] = ld32(0x0601B254u);  // 0601B182 mov.l 0x0601B254,r0
L_0601B184:
    { const uint32_t x = c.r[0]; c.pr = 0x0601B188u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601B188u) return; }  // 0601B184 jsr @r0 ; extu.b r5,r5
L_0601B188:
    c.r[9] = c.r[0];  // 0601B188 mov r0,r9
L_0601B18A:
    c.t = (c.r[9] & c.r[9]) == 0;  // 0601B18A tst r9,r9
L_0601B18C:
    { const bool k = !c.t; c.r[4] = 0x0u; if (k) { goto L_0601B194; } }  // 0601B18C bf/s 0x0601B194 ; mov #0,r4
L_0601B190:
    goto L_0601B6C8;  // 0601B190 bra 0x0601B6C8 ; nop
L_0601B194:
    c.r[1] = ld32(0x0601B258u);  // 0601B194 mov.l 0x0601B258,r1
L_0601B196:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B196 mov.b @r1,r0
L_0601B198:
    c.r[7] = 0x3u;  // 0601B198 mov #3,r7
L_0601B19A:
    c.r[3] = 0x0u;  // 0601B19A mov #0,r3
L_0601B19C:
    c.r[2] = ld32(0x0601B25Cu);  // 0601B19C mov.l 0x0601B25C,r2
L_0601B19E:
    c.r[0] &= 0xFEu;  // 0601B19E and #254,r0
L_0601B1A0:
    st8(c.r[1], c.r[0]);  // 0601B1A0 mov.b r0,@r1
L_0601B1A2:
    c.r[1] = c.r[2];  // 0601B1A2 mov r2,r1
L_0601B1A4:
    c.r[1] += 2;  // 0601B1A4 add #2,r1
L_0601B1A6:
    st8(c.r[1], c.r[3]);  // 0601B1A6 mov.b r3,@r1
L_0601B1A8:
    c.r[4] += 1;  // 0601B1A8 add #1,r4
L_0601B1AA:
    c.t = (int32_t)c.r[4] > (int32_t)c.r[7];  // 0601B1AA cmp/gt r7,r4
L_0601B1AC:
    { const bool k = !c.t; c.r[2] += 3; if (k) { SH2_POLL(c); goto L_0601B1A2; } }  // 0601B1AC bf/s 0x0601B1A2 ; add #3,r2
L_0601B1B0:
    c.r[7] = c.r[9];  // 0601B1B0 mov r9,r7
L_0601B1B2:
    c.r[7] += 2;  // 0601B1B2 add #2,r7
L_0601B1B4:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0601B1B4 mov.b @r7,r1
L_0601B1B6:
    c.r[0] = c.r[1];  // 0601B1B6 mov r1,r0
L_0601B1B8:
    c.r[0] >>= 2;  // 0601B1B8 shlr2 r0
L_0601B1BA:
    c.r[0] >>= 2;  // 0601B1BA shlr2 r0
L_0601B1BC:
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0601B1BC shlr r0
L_0601B1BE:
    c.r[0] >>= 2;  // 0601B1BE shlr2 r0
L_0601B1C0:
    c.r[0] &= 0x1u;  // 0601B1C0 and #1,r0
L_0601B1C2:
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601B1C2 tst r0,r0
L_0601B1C4:
    { const bool k = c.t; c.r[0] = c.r[1]; if (k) { goto L_0601B1E2; } }  // 0601B1C4 bt/s 0x0601B1E2 ; mov r1,r0
L_0601B1C8:
    c.r[1] = ld32(0x0601B258u);  // 0601B1C8 mov.l 0x0601B258,r1
L_0601B1CA:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B1CA mov.b @r1,r0
L_0601B1CC:
    c.r[2] = ld32(0x0601B25Cu);  // 0601B1CC mov.l 0x0601B25C,r2
L_0601B1CE:
    c.r[3] = c.r[2];  // 0601B1CE mov r2,r3
L_0601B1D0:
    c.r[3] += 8;  // 0601B1D0 add #8,r3
L_0601B1D2:
    c.r[2] += 11;  // 0601B1D2 add #11,r2
L_0601B1D4:
    c.r[0] |= 0x1u;  // 0601B1D4 or #1,r0
L_0601B1D6:
    st8(c.r[1], c.r[0]);  // 0601B1D6 mov.b r0,@r1
L_0601B1D8:
    c.r[1] = 0x1u;  // 0601B1D8 mov #1,r1
L_0601B1DA:
    st8(c.r[2], c.r[1]);  // 0601B1DA mov.b r1,@r2
L_0601B1DC:
    st8(c.r[3], c.r[1]);  // 0601B1DC mov.b r1,@r3
L_0601B1DE:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0601B1DE mov.b @r7,r1
L_0601B1E0:
    c.r[0] = c.r[1];  // 0601B1E0 mov r1,r0
L_0601B1E2:
    c.r[0] >>= 2;  // 0601B1E2 shlr2 r0
L_0601B1E4:
    c.r[0] >>= 2;  // 0601B1E4 shlr2 r0
L_0601B1E6:
    c.r[0] >>= 2;  // 0601B1E6 shlr2 r0
L_0601B1E8:
    c.r[0] &= 0x1u;  // 0601B1E8 and #1,r0
L_0601B1EA:
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601B1EA tst r0,r0
L_0601B1EC:
    if (c.t) { goto L_0601B204; }  // 0601B1EC bt 0x0601B204
L_0601B1EE:
    c.r[1] = ld32(0x0601B258u);  // 0601B1EE mov.l 0x0601B258,r1
L_0601B1F0:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B1F0 mov.b @r1,r0
L_0601B1F2:
    c.r[2] = ld32(0x0601B25Cu);  // 0601B1F2 mov.l 0x0601B25C,r2
L_0601B1F4:
    c.r[3] = c.r[2];  // 0601B1F4 mov r2,r3
L_0601B1F6:
    c.r[3] += 2;  // 0601B1F6 add #2,r3
L_0601B1F8:
    c.r[2] += 5;  // 0601B1F8 add #5,r2
L_0601B1FA:
    c.r[0] |= 0x1u;  // 0601B1FA or #1,r0
L_0601B1FC:
    st8(c.r[1], c.r[0]);  // 0601B1FC mov.b r0,@r1
L_0601B1FE:
    c.r[1] = 0x1u;  // 0601B1FE mov #1,r1
L_0601B200:
    st8(c.r[2], c.r[1]);  // 0601B200 mov.b r1,@r2
L_0601B202:
    st8(c.r[3], c.r[1]);  // 0601B202 mov.b r1,@r3
L_0601B204:
    c.r[1] = ld32(0x0601B240u);  // 0601B204 mov.l 0x0601B240,r1
L_0601B206:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0601B206 mov.w @r1,r1
L_0601B208:
    c.r[2] = (uint32_t)(int16_t)ld16(0x0601B23Au);  // 0601B208 mov.w 0x0601B23A,r2
L_0601B20A:
    c.r[2] &= c.r[1];  // 0601B20A and r1,r2
L_0601B20C:
    c.t = (c.r[2] & c.r[2]) == 0;  // 0601B20C tst r2,r2
L_0601B20E:
    if (!c.t) { goto L_0601B214; }  // 0601B20E bf 0x0601B214
L_0601B210:
    goto L_0601B36E;  // 0601B210 bra 0x0601B36E ; nop
L_0601B214:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0601B214 mov.b @r9,r1
L_0601B216:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601B23Cu);  // 0601B216 mov.w 0x0601B23C,r0
L_0601B218:
    c.r[1] &= c.r[0];  // 0601B218 and r0,r1
L_0601B21A:
    c.r[1] >>= 2;  // 0601B21A shlr2 r1
L_0601B21C:
    c.r[1] >>= 2;  // 0601B21C shlr2 r1
L_0601B21E:
    c.r[1] >>= 2;  // 0601B21E shlr2 r1
L_0601B220:
    c.r[0] = c.r[1];  // 0601B220 mov r1,r0
L_0601B222:
    c.t = c.r[0] == 0x1u;  // 0601B222 cmp/eq #1,r0
L_0601B224:
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_0601B260; } }  // 0601B224 bt/s 0x0601B260 ; mov r9,r1
L_0601B228:
    c.t = c.r[0] == 0x2u;  // 0601B228 cmp/eq #2,r0
L_0601B22A:
    { const bool k = c.t; c.r[1] += 4; if (k) { goto L_0601B312; } }  // 0601B22A bt/s 0x0601B312 ; add #4,r1
L_0601B22E:
    goto L_0601B32C;  // 0601B22E bra 0x0601B32C ; nop
L_0601B260:
    c.r[1] += 5;  // 0601B260 add #5,r1
L_0601B262:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B262 mov.b @r1,r1
L_0601B264:
    c.r[10] = c.r[1] & 0xFFu;  // 0601B264 extu.b r1,r10
L_0601B266:
    c.r[1] = c.r[9];  // 0601B266 mov r9,r1
L_0601B268:
    c.r[1] += 4;  // 0601B268 add #4,r1
L_0601B26A:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B26A mov.b @r1,r1
L_0601B26C:
    c.r[13] = ld32(0x0601B438u);  // 0601B26C mov.l 0x0601B438,r13
L_0601B26E:
    c.r[8] = c.r[1] & 0xFFu;  // 0601B26E extu.b r1,r8
L_0601B270:
    c.r[1] = ld32(0x0601B43Cu);  // 0601B270 mov.l 0x0601B43C,r1
L_0601B272:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B272 mov.b @r1,r1
L_0601B274:
    c.r[7] = ld32(0x0601B440u);  // 0601B274 mov.l 0x0601B440,r7
L_0601B276:
    c.r[12] = c.r[1] & 0xFFu;  // 0601B276 extu.b r1,r12
L_0601B278:
    c.r[0] = c.r[12];  // 0601B278 mov r12,r0
L_0601B27A:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[13]);  // 0601B27A mov.b @(r0,r13),r11
L_0601B27C:
    c.r[5] = c.r[8];  // 0601B27C mov r8,r5
L_0601B27E:
    c.r[6] = c.r[11] & 0xFFu;  // 0601B27E extu.b r11,r6
L_0601B280:
    { const uint32_t x = c.r[7]; c.pr = 0x0601B284u; c.r[4] = c.r[6]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601B284u) return; }  // 0601B280 jsr @r7 ; mov r6,r4
L_0601B284:
    c.r[7] = c.r[0];  // 0601B284 mov r0,r7
L_0601B286:
    c.macl = c.r[7] * c.r[8];  // 0601B286 mul.l r8,r7
L_0601B288:
    c.r[0] = c.r[6];  // 0601B288 mov r6,r0
L_0601B28A:
    c.r[1] = c.macl;  // 0601B28A sts macl,r1
L_0601B28C:
    c.r[0] -= c.r[1];  // 0601B28C sub r1,r0
L_0601B28E:
    c.r[1] = c.r[0];  // 0601B28E mov r0,r1
L_0601B290:
    c.t = (int32_t)c.r[1] > 0;  // 0601B290 cmp/pl r1
L_0601B292:
    { const bool k = !c.t; c.r[1] = c.r[11]; if (k) { goto L_0601B29E; } }  // 0601B292 bf/s 0x0601B29E ; mov r11,r1
L_0601B296:
    c.r[1] -= 1;  // 0601B296 add #-1,r1
L_0601B298:
    c.r[0] = c.r[12];  // 0601B298 mov r12,r0
L_0601B29A:
    st8(c.r[0] + c.r[13], c.r[1]); goto L_0601B358;  // 0601B29A bra 0x0601B358 ; mov.b r1,@(r0,r13)
L_0601B29E:
    c.r[1] = c.r[9];  // 0601B29E mov r9,r1
L_0601B2A0:
    c.r[1] += 1;  // 0601B2A0 add #1,r1
L_0601B2A2:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B2A2 mov.b @r1,r1
L_0601B2A4:
    c.r[0] = c.r[1];  // 0601B2A4 mov r1,r0
L_0601B2A6:
    c.r[0] >>= 2;  // 0601B2A6 shlr2 r0
L_0601B2A8:
    c.r[0] >>= 2;  // 0601B2A8 shlr2 r0
L_0601B2AA:
    c.r[0] >>= 2;  // 0601B2AA shlr2 r0
L_0601B2AC:
    c.r[0] &= 0x1u;  // 0601B2AC and #1,r0
L_0601B2AE:
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601B2AE tst r0,r0
L_0601B2B0:
    { const bool k = !c.t; c.r[4] = c.r[6]; if (k) { goto L_0601B2B8; } }  // 0601B2B0 bf/s 0x0601B2B8 ; mov r6,r4
L_0601B2B4:
    goto L_0601B46A;  // 0601B2B4 bra 0x0601B46A ; nop
L_0601B2B8:
    c.r[1] = c.r[9];  // 0601B2B8 mov r9,r1
L_0601B2BA:
    c.r[1] += 8;  // 0601B2BA add #8,r1
L_0601B2BC:
    c.r[3] = c.r[12];  // 0601B2BC mov r12,r3
L_0601B2BE:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B2BE mov.b @r1,r1
L_0601B2C0:
    c.r[0] = c.r[3];  // 0601B2C0 mov r3,r0
L_0601B2C2:
    c.r[2] = c.r[1] & 0xFFu;  // 0601B2C2 extu.b r1,r2
L_0601B2C4:
    c.r[1] = c.r[9];  // 0601B2C4 mov r9,r1
L_0601B2C6:
    c.r[1] += 9;  // 0601B2C6 add #9,r1
L_0601B2C8:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B2C8 mov.b @r1,r1
L_0601B2CA:
    c.r[2] <<= 8;  // 0601B2CA shll8 r2
L_0601B2CC:
    c.r[1] = c.r[1] & 0xFFu;  // 0601B2CC extu.b r1,r1
L_0601B2CE:
    c.r[2] |= c.r[1];  // 0601B2CE or r1,r2
L_0601B2D0:
    c.r[1] = ld32(0x0601B444u);  // 0601B2D0 mov.l 0x0601B444,r1
L_0601B2D2:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601B2D2 mov.b @(r0,r1),r1
L_0601B2D4:
    c.r[1] = c.r[1] & 0xFFu;  // 0601B2D4 extu.b r1,r1
L_0601B2D6:
    c.r[1] -= 1;  // 0601B2D6 add #-1,r1
L_0601B2D8:
    c.macl = c.r[1] * c.r[10];  // 0601B2D8 mul.l r10,r1
L_0601B2DA:
    c.r[4] += c.r[8]; goto L_0601B2F2;  // 0601B2DA bra 0x0601B2F2 ; add r8,r4
L_0601B2DE:
    c.r[1] = ld32(0x0601B438u);  // 0601B2DE mov.l 0x0601B438,r1
L_0601B2E0:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601B2E0 mov.b @(r0,r1),r1
L_0601B2E2:
    c.r[1] = c.r[1] & 0xFFu;  // 0601B2E2 extu.b r1,r1
L_0601B2E4:
    c.t = (int32_t)c.r[4] > (int32_t)c.r[1];  // 0601B2E4 cmp/gt r1,r4
L_0601B2E6:
    if (!c.t) { goto L_0601B306; }  // 0601B2E6 bf 0x0601B306
L_0601B2E8:
    c.r[1] = ld32(0x0601B444u);  // 0601B2E8 mov.l 0x0601B444,r1
L_0601B2EA:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601B2EA mov.b @(r0,r1),r1
L_0601B2EC:
    c.r[1] = c.r[1] & 0xFFu;  // 0601B2EC extu.b r1,r1
L_0601B2EE:
    c.r[1] -= 1;  // 0601B2EE add #-1,r1
L_0601B2F0:
    c.macl = c.r[1] * c.r[10];  // 0601B2F0 mul.l r10,r1
L_0601B2F2:
    c.r[1] = c.macl;  // 0601B2F2 sts macl,r1
L_0601B2F4:
    c.macl = c.r[1] * c.r[8];  // 0601B2F4 mul.l r8,r1
L_0601B2F6:
    c.r[4] -= 1;  // 0601B2F6 add #-1,r4
L_0601B2F8:
    c.r[0] = c.r[2];  // 0601B2F8 mov r2,r0
L_0601B2FA:
    c.r[1] = c.macl;  // 0601B2FA sts macl,r1
L_0601B2FC:
    c.r[0] -= c.r[1];  // 0601B2FC sub r1,r0
L_0601B2FE:
    c.r[1] = c.r[0];  // 0601B2FE mov r0,r1
L_0601B300:
    c.t = (int32_t)c.r[1] > (int32_t)c.r[4];  // 0601B300 cmp/gt r4,r1
L_0601B302:
    { const bool k = !c.t; c.r[0] = c.r[3]; if (k) { SH2_POLL(c); goto L_0601B2DE; } }  // 0601B302 bf/s 0x0601B2DE ; mov r3,r0
L_0601B306:
    c.r[1] = ld32(0x0601B43Cu);  // 0601B306 mov.l 0x0601B43C,r1
L_0601B308:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B308 mov.b @r1,r1
L_0601B30A:
    c.r[0] = c.r[1] & 0xFFu;  // 0601B30A extu.b r1,r0
L_0601B30C:
    c.r[1] = ld32(0x0601B438u);  // 0601B30C mov.l 0x0601B438,r1
L_0601B30E:
    st8(c.r[0] + c.r[1], c.r[4]); goto L_0601B358;  // 0601B30E bra 0x0601B358 ; mov.b r4,@(r0,r1)
L_0601B312:
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B312 mov.b @r1,r3
L_0601B314:
    c.r[2] = c.r[3] & 0xFFu;  // 0601B314 extu.b r3,r2
L_0601B316:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601B434u);  // 0601B316 mov.w 0x0601B434,r1
L_0601B318:
    c.t = c.r[2] == c.r[1];  // 0601B318 cmp/eq r1,r2
L_0601B31A:
    if (!c.t) { goto L_0601B320; }  // 0601B31A bf 0x0601B320
L_0601B31C:
    goto L_0601B46A;  // 0601B31C bra 0x0601B46A ; nop
L_0601B320:
    c.r[1] = ld32(0x0601B43Cu);  // 0601B320 mov.l 0x0601B43C,r1
L_0601B322:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B322 mov.b @r1,r1
L_0601B324:
    c.r[0] = c.r[1] & 0xFFu;  // 0601B324 extu.b r1,r0
L_0601B326:
    c.r[1] = ld32(0x0601B438u);  // 0601B326 mov.l 0x0601B438,r1
L_0601B328:
    st8(c.r[0] + c.r[1], c.r[3]); goto L_0601B358;  // 0601B328 bra 0x0601B358 ; mov.b r3,@(r0,r1)
L_0601B32C:
    c.r[10] = ld32(0x0601B43Cu);  // 0601B32C mov.l 0x0601B43C,r10
L_0601B32E:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0601B32E mov.b @r10,r1
L_0601B330:
    c.r[8] = ld32(0x0601B438u);  // 0601B330 mov.l 0x0601B438,r8
L_0601B332:
    c.r[3] = c.r[1] & 0xFFu;  // 0601B332 extu.b r1,r3
L_0601B334:
    c.r[0] = c.r[3];  // 0601B334 mov r3,r0
L_0601B336:
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0601B336 mov.b @(r0,r8),r2
L_0601B338:
    c.r[1] = c.r[2] & 0xFFu;  // 0601B338 extu.b r2,r1
L_0601B33A:
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601B33A tst r1,r1
L_0601B33C:
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_0601B346; } }  // 0601B33C bt/s 0x0601B346 ; mov r2,r1
L_0601B340:
    c.r[1] -= 1;  // 0601B340 add #-1,r1
L_0601B342:
    st8(c.r[0] + c.r[8], c.r[1]); goto L_0601B358;  // 0601B342 bra 0x0601B358 ; mov.b r1,@(r0,r8)
L_0601B346:
    c.r[1] = ld32(0x0601B448u);  // 0601B346 mov.l 0x0601B448,r1
L_0601B348:
    c.r[0] = ld32(0x0601B44Cu);  // 0601B348 mov.l 0x0601B44C,r0
L_0601B34A:
    { const uint32_t x = c.r[0]; c.pr = 0x0601B34Eu; c.r[4] = ld32(c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601B34Eu) return; }  // 0601B34A jsr @r0 ; mov.l @r1,r4
L_0601B34E:
    c.r[2] = c.r[0];  // 0601B34E mov r0,r2
L_0601B350:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0601B350 mov.b @r10,r1
L_0601B352:
    c.r[2] -= 1;  // 0601B352 add #-1,r2
L_0601B354:
    c.r[0] = c.r[1] & 0xFFu;  // 0601B354 extu.b r1,r0
L_0601B356:
    st8(c.r[0] + c.r[8], c.r[2]);  // 0601B356 mov.b r2,@(r0,r8)
L_0601B358:
    c.r[1] = c.r[9];  // 0601B358 mov r9,r1
L_0601B35A:
    c.r[1] += 1;  // 0601B35A add #1,r1
L_0601B35C:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B35C mov.b @r1,r1
L_0601B35E:
    c.r[0] = c.r[1];  // 0601B35E mov r1,r0
L_0601B360:
    c.r[0] >>= 2;  // 0601B360 shlr2 r0
L_0601B362:
    c.r[0] >>= 2;  // 0601B362 shlr2 r0
L_0601B364:
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0601B364 shlr r0
L_0601B366:
    c.r[0] >>= 2;  // 0601B366 shlr2 r0
L_0601B368:
    c.r[0] &= 0x1u;  // 0601B368 and #1,r0
L_0601B36A:
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601B36A tst r0,r0
L_0601B36C:
    if (!c.t) { goto L_0601B46A; }  // 0601B36C bf 0x0601B46A
L_0601B36E:
    c.r[1] = ld32(0x0601B450u);  // 0601B36E mov.l 0x0601B450,r1
L_0601B370:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0601B370 mov.w @r1,r1
L_0601B372:
    c.r[2] = ld32(0x0601B454u);  // 0601B372 mov.l 0x0601B454,r2
L_0601B374:
    c.r[2] &= c.r[1];  // 0601B374 and r1,r2
L_0601B376:
    c.t = (c.r[2] & c.r[2]) == 0;  // 0601B376 tst r2,r2
L_0601B378:
    if (!c.t) { goto L_0601B37E; }  // 0601B378 bf 0x0601B37E
L_0601B37A:
    goto L_0601B4C6;  // 0601B37A bra 0x0601B4C6 ; nop
L_0601B37E:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0601B37E mov.b @r9,r1
L_0601B380:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601B436u);  // 0601B380 mov.w 0x0601B436,r0
L_0601B382:
    c.r[1] &= c.r[0];  // 0601B382 and r0,r1
L_0601B384:
    c.r[1] >>= 2;  // 0601B384 shlr2 r1
L_0601B386:
    c.r[1] >>= 2;  // 0601B386 shlr2 r1
L_0601B388:
    c.r[1] >>= 2;  // 0601B388 shlr2 r1
L_0601B38A:
    c.r[0] = c.r[1];  // 0601B38A mov r1,r0
L_0601B38C:
    c.t = c.r[0] == 0x1u;  // 0601B38C cmp/eq #1,r0
L_0601B38E:
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_0601B39C; } }  // 0601B38E bt/s 0x0601B39C ; mov r9,r1
L_0601B392:
    c.t = c.r[0] == 0x2u;  // 0601B392 cmp/eq #2,r0
L_0601B394:
    { const bool k = c.t; c.r[1] += 5; if (k) { goto L_0601B470; } }  // 0601B394 bt/s 0x0601B470 ; add #5,r1
L_0601B398:
    goto L_0601B486;  // 0601B398 bra 0x0601B486 ; nop
L_0601B39C:
    c.r[1] += 5;  // 0601B39C add #5,r1
L_0601B39E:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B39E mov.b @r1,r1
L_0601B3A0:
    c.r[10] = c.r[1] & 0xFFu;  // 0601B3A0 extu.b r1,r10
L_0601B3A2:
    c.r[1] = c.r[9];  // 0601B3A2 mov r9,r1
L_0601B3A4:
    c.r[1] += 4;  // 0601B3A4 add #4,r1
L_0601B3A6:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B3A6 mov.b @r1,r1
L_0601B3A8:
    c.r[8] = c.r[1] & 0xFFu;  // 0601B3A8 extu.b r1,r8
L_0601B3AA:
    c.r[1] = c.r[9];  // 0601B3AA mov r9,r1
L_0601B3AC:
    c.r[1] += 8;  // 0601B3AC add #8,r1
L_0601B3AE:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B3AE mov.b @r1,r1
L_0601B3B0:
    c.macl = c.r[10] * c.r[8];  // 0601B3B0 mul.l r8,r10
L_0601B3B2:
    c.r[4] = c.r[1] & 0xFFu;  // 0601B3B2 extu.b r1,r4
L_0601B3B4:
    c.r[1] = c.r[9];  // 0601B3B4 mov r9,r1
L_0601B3B6:
    c.r[1] += 9;  // 0601B3B6 add #9,r1
L_0601B3B8:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B3B8 mov.b @r1,r1
L_0601B3BA:
    c.r[4] <<= 8;  // 0601B3BA shll8 r4
L_0601B3BC:
    c.r[1] = c.r[1] & 0xFFu;  // 0601B3BC extu.b r1,r1
L_0601B3BE:
    c.r[4] |= c.r[1];  // 0601B3BE or r1,r4
L_0601B3C0:
    c.r[1] = ld32(0x0601B43Cu);  // 0601B3C0 mov.l 0x0601B43C,r1
L_0601B3C2:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B3C2 mov.b @r1,r1
L_0601B3C4:
    c.r[10] = c.r[1] & 0xFFu;  // 0601B3C4 extu.b r1,r10
L_0601B3C6:
    c.r[1] = ld32(0x0601B444u);  // 0601B3C6 mov.l 0x0601B444,r1
L_0601B3C8:
    c.r[0] = c.r[10];  // 0601B3C8 mov r10,r0
L_0601B3CA:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601B3CA mov.b @(r0,r1),r1
L_0601B3CC:
    c.r[2] = c.macl;  // 0601B3CC sts macl,r2
L_0601B3CE:
    c.r[1] = c.r[1] & 0xFFu;  // 0601B3CE extu.b r1,r1
L_0601B3D0:
    c.r[1] -= 1;  // 0601B3D0 add #-1,r1
L_0601B3D2:
    c.macl = c.r[2] * c.r[1];  // 0601B3D2 mul.l r1,r2
L_0601B3D4:
    c.r[1] = c.macl;  // 0601B3D4 sts macl,r1
L_0601B3D6:
    c.macl = c.r[2];  // 0601B3D6 lds r2,macl
L_0601B3D8:
    c.r[4] -= c.r[1];  // 0601B3D8 sub r1,r4
L_0601B3DA:
    c.r[1] = c.macl;  // 0601B3DA sts macl,r1
L_0601B3DC:
    c.t = (int32_t)c.r[4] > (int32_t)c.r[1];  // 0601B3DC cmp/gt r1,r4
L_0601B3DE:
    if (!c.t) { goto L_0601B3E2; }  // 0601B3DE bf 0x0601B3E2
L_0601B3E0:
    c.r[4] = c.macl;  // 0601B3E0 sts macl,r4
L_0601B3E2:
    c.r[12] = ld32(0x0601B438u);  // 0601B3E2 mov.l 0x0601B438,r12
L_0601B3E4:
    c.r[0] = c.r[10];  // 0601B3E4 mov r10,r0
L_0601B3E6:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[12]);  // 0601B3E6 mov.b @(r0,r12),r11
L_0601B3E8:
    c.r[6] = c.r[11] & 0xFFu;  // 0601B3E8 extu.b r11,r6
L_0601B3EA:
    c.r[6] += 1;  // 0601B3EA add #1,r6
L_0601B3EC:
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[4];  // 0601B3EC cmp/ge r4,r6
L_0601B3EE:
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_0601B410; } }  // 0601B3EE bt/s 0x0601B410 ; mov r9,r1
L_0601B3F2:
    c.r[4] = c.r[6];  // 0601B3F2 mov r6,r4
L_0601B3F4:
    c.r[7] = ld32(0x0601B440u);  // 0601B3F4 mov.l 0x0601B440,r7
L_0601B3F6:
    { const uint32_t x = c.r[7]; c.pr = 0x0601B3FAu; c.r[5] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601B3FAu) return; }  // 0601B3F6 jsr @r7 ; mov r8,r5
L_0601B3FA:
    c.macl = c.r[0] * c.r[8];  // 0601B3FA mul.l r8,r0
L_0601B3FC:
    c.r[1] = c.macl;  // 0601B3FC sts macl,r1
L_0601B3FE:
    c.r[6] -= c.r[1];  // 0601B3FE sub r1,r6
L_0601B400:
    c.t = (c.r[6] & c.r[6]) == 0;  // 0601B400 tst r6,r6
L_0601B402:
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_0601B410; } }  // 0601B402 bt/s 0x0601B410 ; mov r9,r1
L_0601B406:
    c.r[1] = c.r[11];  // 0601B406 mov r11,r1
L_0601B408:
    c.r[1] += 1;  // 0601B408 add #1,r1
L_0601B40A:
    c.r[0] = c.r[10];  // 0601B40A mov r10,r0
L_0601B40C:
    st8(c.r[0] + c.r[12], c.r[1]); goto L_0601B4B0;  // 0601B40C bra 0x0601B4B0 ; mov.b r1,@(r0,r12)
L_0601B410:
    c.r[1] += 1;  // 0601B410 add #1,r1
L_0601B412:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B412 mov.b @r1,r1
L_0601B414:
    c.r[0] = c.r[1];  // 0601B414 mov r1,r0
L_0601B416:
    c.r[0] >>= 2;  // 0601B416 shlr2 r0
L_0601B418:
    c.r[0] >>= 2;  // 0601B418 shlr2 r0
L_0601B41A:
    c.r[0] >>= 2;  // 0601B41A shlr2 r0
L_0601B41C:
    c.r[0] &= 0x1u;  // 0601B41C and #1,r0
L_0601B41E:
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601B41E tst r0,r0
L_0601B420:
    { const bool k = c.t; c.r[8] -= 1; if (k) { goto L_0601B458; } }  // 0601B420 bt/s 0x0601B458 ; add #-1,r8
L_0601B424:
    c.r[1] = ld32(0x0601B43Cu);  // 0601B424 mov.l 0x0601B43C,r1
L_0601B426:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B426 mov.b @r1,r1
L_0601B428:
    c.r[2] = ld32(0x0601B438u);  // 0601B428 mov.l 0x0601B438,r2
L_0601B42A:
    c.r[0] = c.r[1] & 0xFFu;  // 0601B42A extu.b r1,r0
L_0601B42C:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0601B42C mov.b @(r0,r2),r1
L_0601B42E:
    c.r[1] -= c.r[8];  // 0601B42E sub r8,r1
L_0601B430:
    st8(c.r[0] + c.r[2], c.r[1]); goto L_0601B4B0;  // 0601B430 bra 0x0601B4B0 ; mov.b r1,@(r0,r2)
L_0601B458:
    c.r[1] = ld32(0x0601B564u);  // 0601B458 mov.l 0x0601B564,r1
L_0601B45A:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B45A mov.b @r1,r1
L_0601B45C:
    c.r[0] = c.r[1] & 0xFFu;  // 0601B45C extu.b r1,r0
L_0601B45E:
    c.r[1] = ld32(0x0601B568u);  // 0601B45E mov.l 0x0601B568,r1
L_0601B460:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601B460 mov.b @(r0,r1),r1
L_0601B462:
    c.r[1] = c.r[1] & 0xFFu;  // 0601B462 extu.b r1,r1
L_0601B464:
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601B464 tst r1,r1
L_0601B466:
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_0601B4B2; } }  // 0601B466 bt/s 0x0601B4B2 ; mov r9,r1
L_0601B46A:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601B55Cu);  // 0601B46A mov.w 0x0601B55C,r0
L_0601B46C:
    c.r[15] = c.r[14]; goto L_0601B6D2;  // 0601B46C bra 0x0601B6D2 ; mov r14,r15
L_0601B470:
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B470 mov.b @r1,r3
L_0601B472:
    c.r[2] = c.r[3] & 0xFFu;  // 0601B472 extu.b r3,r2
L_0601B474:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601B55Eu);  // 0601B474 mov.w 0x0601B55E,r1
L_0601B476:
    c.t = c.r[2] == c.r[1];  // 0601B476 cmp/eq r1,r2
L_0601B478:
    if (c.t) { SH2_POLL(c); goto L_0601B46A; }  // 0601B478 bt 0x0601B46A
L_0601B47A:
    c.r[1] = ld32(0x0601B564u);  // 0601B47A mov.l 0x0601B564,r1
L_0601B47C:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B47C mov.b @r1,r1
L_0601B47E:
    c.r[0] = c.r[1] & 0xFFu;  // 0601B47E extu.b r1,r0
L_0601B480:
    c.r[1] = ld32(0x0601B568u);  // 0601B480 mov.l 0x0601B568,r1
L_0601B482:
    st8(c.r[0] + c.r[1], c.r[3]); goto L_0601B4B0;  // 0601B482 bra 0x0601B4B0 ; mov.b r3,@(r0,r1)
L_0601B486:
    c.r[10] = ld32(0x0601B564u);  // 0601B486 mov.l 0x0601B564,r10
L_0601B488:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0601B488 mov.b @r10,r1
L_0601B48A:
    c.r[11] = ld32(0x0601B568u);  // 0601B48A mov.l 0x0601B568,r11
L_0601B48C:
    c.r[0] = c.r[1] & 0xFFu;  // 0601B48C extu.b r1,r0
L_0601B48E:
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 0601B48E mov.b @(r0,r11),r8
L_0601B490:
    c.r[1] = ld32(0x0601B56Cu);  // 0601B490 mov.l 0x0601B56C,r1
L_0601B492:
    c.r[4] = ld32(c.r[1]);  // 0601B492 mov.l @r1,r4
L_0601B494:
    c.r[0] = ld32(0x0601B570u);  // 0601B494 mov.l 0x0601B570,r0
L_0601B496:
    { const uint32_t x = c.r[0]; c.pr = 0x0601B49Au; c.r[8] = c.r[8] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601B49Au) return; }  // 0601B496 jsr @r0 ; extu.b r8,r8
L_0601B49A:
    c.r[0] -= 1;  // 0601B49A add #-1,r0
L_0601B49C:
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[0];  // 0601B49C cmp/ge r0,r8
L_0601B49E:
    { const bool k = c.t; c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]); if (k) { goto L_0601B4AA; } }  // 0601B49E bt/s 0x0601B4AA ; mov.b @r10,r1
L_0601B4A2:
    c.r[0] = c.r[1] & 0xFFu;  // 0601B4A2 extu.b r1,r0
L_0601B4A4:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 0601B4A4 mov.b @(r0,r11),r1
L_0601B4A6:
    c.r[1] += 1; goto L_0601B4AE;  // 0601B4A6 bra 0x0601B4AE ; add #1,r1
L_0601B4AA:
    c.r[0] = c.r[1] & 0xFFu;  // 0601B4AA extu.b r1,r0
L_0601B4AC:
    c.r[1] = 0x0u;  // 0601B4AC mov #0,r1
L_0601B4AE:
    st8(c.r[0] + c.r[11], c.r[1]);  // 0601B4AE mov.b r1,@(r0,r11)
L_0601B4B0:
    c.r[1] = c.r[9];  // 0601B4B0 mov r9,r1
L_0601B4B2:
    c.r[1] += 1;  // 0601B4B2 add #1,r1
L_0601B4B4:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B4B4 mov.b @r1,r1
L_0601B4B6:
    c.r[0] = c.r[1];  // 0601B4B6 mov r1,r0
L_0601B4B8:
    c.r[0] >>= 2;  // 0601B4B8 shlr2 r0
L_0601B4BA:
    c.r[0] >>= 2;  // 0601B4BA shlr2 r0
L_0601B4BC:
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0601B4BC shlr r0
L_0601B4BE:
    c.r[0] >>= 2;  // 0601B4BE shlr2 r0
L_0601B4C0:
    c.r[0] &= 0x1u;  // 0601B4C0 and #1,r0
L_0601B4C2:
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601B4C2 tst r0,r0
L_0601B4C4:
    if (!c.t) { SH2_POLL(c); goto L_0601B46A; }  // 0601B4C4 bf 0x0601B46A
L_0601B4C6:
    c.r[1] = ld32(0x0601B574u);  // 0601B4C6 mov.l 0x0601B574,r1
L_0601B4C8:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0601B4C8 mov.w @r1,r1
L_0601B4CA:
    c.r[2] = (uint32_t)(int16_t)ld16(0x0601B560u);  // 0601B4CA mov.w 0x0601B560,r2
L_0601B4CC:
    c.r[2] &= c.r[1];  // 0601B4CC and r1,r2
L_0601B4CE:
    c.t = (c.r[2] & c.r[2]) == 0;  // 0601B4CE tst r2,r2
L_0601B4D0:
    if (!c.t) { goto L_0601B4D6; }  // 0601B4D0 bf 0x0601B4D6
L_0601B4D2:
    goto L_0601B5E2;  // 0601B4D2 bra 0x0601B5E2 ; nop
L_0601B4D6:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0601B4D6 mov.b @r9,r1
L_0601B4D8:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601B562u);  // 0601B4D8 mov.w 0x0601B562,r0
L_0601B4DA:
    c.r[1] &= c.r[0];  // 0601B4DA and r0,r1
L_0601B4DC:
    c.r[1] >>= 2;  // 0601B4DC shlr2 r1
L_0601B4DE:
    c.r[1] >>= 2;  // 0601B4DE shlr2 r1
L_0601B4E0:
    c.r[1] >>= 2;  // 0601B4E0 shlr2 r1
L_0601B4E2:
    c.r[0] = c.r[1];  // 0601B4E2 mov r1,r0
L_0601B4E4:
    c.t = c.r[0] == 0x1u;  // 0601B4E4 cmp/eq #1,r0
L_0601B4E6:
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_0601B4F4; } }  // 0601B4E6 bt/s 0x0601B4F4 ; mov r9,r1
L_0601B4EA:
    c.t = c.r[0] == 0x2u;  // 0601B4EA cmp/eq #2,r0
L_0601B4EC:
    { const bool k = c.t; c.r[1] += 6; if (k) { goto L_0601B5B0; } }  // 0601B4EC bt/s 0x0601B5B0 ; add #6,r1
L_0601B4F0:
    c.r[1] = c.r[9]; goto L_0601B5CA;  // 0601B4F0 bra 0x0601B5CA ; mov r9,r1
L_0601B4F4:
    c.r[1] += 5;  // 0601B4F4 add #5,r1
L_0601B4F6:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B4F6 mov.b @r1,r1
L_0601B4F8:
    c.r[10] = c.r[1] & 0xFFu;  // 0601B4F8 extu.b r1,r10
L_0601B4FA:
    c.r[1] = c.r[9];  // 0601B4FA mov r9,r1
L_0601B4FC:
    c.r[1] += 4;  // 0601B4FC add #4,r1
L_0601B4FE:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B4FE mov.b @r1,r1
L_0601B500:
    c.r[8] = c.r[1] & 0xFFu;  // 0601B500 extu.b r1,r8
L_0601B502:
    c.r[1] = ld32(0x0601B564u);  // 0601B502 mov.l 0x0601B564,r1
L_0601B504:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B504 mov.b @r1,r1
L_0601B506:
    c.r[3] = ld32(0x0601B568u);  // 0601B506 mov.l 0x0601B568,r3
L_0601B508:
    c.r[2] = c.r[1] & 0xFFu;  // 0601B508 extu.b r1,r2
L_0601B50A:
    c.r[0] = c.r[2];  // 0601B50A mov r2,r0
L_0601B50C:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0601B50C mov.b @(r0,r3),r1
L_0601B50E:
    c.r[7] = c.r[1] & 0xFFu;  // 0601B50E extu.b r1,r7
L_0601B510:
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[8];  // 0601B510 cmp/ge r8,r7
L_0601B512:
    { const bool k = !c.t; c.r[1] -= c.r[8]; if (k) { goto L_0601B51A; } }  // 0601B512 bf/s 0x0601B51A ; sub r8,r1
L_0601B516:
    st8(c.r[0] + c.r[3], c.r[1]); goto L_0601B5C8;  // 0601B516 bra 0x0601B5C8 ; mov.b r1,@(r0,r3)
L_0601B51A:
    c.r[1] = c.r[9];  // 0601B51A mov r9,r1
L_0601B51C:
    c.r[1] += 1;  // 0601B51C add #1,r1
L_0601B51E:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B51E mov.b @r1,r1
L_0601B520:
    c.r[0] = c.r[1];  // 0601B520 mov r1,r0
L_0601B522:
    c.r[0] >>= 2;  // 0601B522 shlr2 r0
L_0601B524:
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0601B524 shlr r0
L_0601B526:
    c.r[0] >>= 2;  // 0601B526 shlr2 r0
L_0601B528:
    c.r[0] &= 0x1u;  // 0601B528 and #1,r0
L_0601B52A:
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601B52A tst r0,r0
L_0601B52C:
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { SH2_POLL(c); goto L_0601B46A; } }  // 0601B52C bt/s 0x0601B46A ; mov r9,r1
L_0601B530:
    c.r[1] += 8;  // 0601B530 add #8,r1
L_0601B532:
    c.r[0] = c.r[2];  // 0601B532 mov r2,r0
L_0601B534:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B534 mov.b @r1,r1
L_0601B536:
    c.macl = c.r[10] * c.r[8];  // 0601B536 mul.l r8,r10
L_0601B538:
    c.r[3] = c.r[1] & 0xFFu;  // 0601B538 extu.b r1,r3
L_0601B53A:
    c.r[1] = c.r[9];  // 0601B53A mov r9,r1
L_0601B53C:
    c.r[1] += 9;  // 0601B53C add #9,r1
L_0601B53E:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B53E mov.b @r1,r1
L_0601B540:
    c.r[3] <<= 8;  // 0601B540 shll8 r3
L_0601B542:
    c.r[1] = c.r[1] & 0xFFu;  // 0601B542 extu.b r1,r1
L_0601B544:
    c.r[3] |= c.r[1];  // 0601B544 or r1,r3
L_0601B546:
    c.r[1] = ld32(0x0601B578u);  // 0601B546 mov.l 0x0601B578,r1
L_0601B548:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601B548 mov.b @(r0,r1),r1
L_0601B54A:
    c.r[4] = c.macl;  // 0601B54A sts macl,r4
L_0601B54C:
    c.r[1] = c.r[1] & 0xFFu;  // 0601B54C extu.b r1,r1
L_0601B54E:
    c.r[1] -= 1;  // 0601B54E add #-1,r1
L_0601B550:
    c.macl = c.r[1] * c.r[10];  // 0601B550 mul.l r10,r1
L_0601B552:
    c.r[4] -= c.r[8];  // 0601B552 sub r8,r4
L_0601B554:
    c.r[1] = c.macl;  // 0601B554 sts macl,r1
L_0601B556:
    c.macl = c.r[1] * c.r[8];  // 0601B556 mul.l r8,r1
L_0601B558:
    c.r[4] += c.r[7]; goto L_0601B596;  // 0601B558 bra 0x0601B596 ; add r7,r4
L_0601B57C:
    c.r[1] = ld32(0x0601B6ECu);  // 0601B57C mov.l 0x0601B6EC,r1
L_0601B57E:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601B57E mov.b @(r0,r1),r1
L_0601B580:
    c.r[1] = c.r[1] & 0xFFu;  // 0601B580 extu.b r1,r1
L_0601B582:
    c.t = (int32_t)c.r[4] > (int32_t)c.r[1];  // 0601B582 cmp/gt r1,r4
L_0601B584:
    if (!c.t) { goto L_0601B5A4; }  // 0601B584 bf 0x0601B5A4
L_0601B586:
    c.r[4] -= c.r[8];  // 0601B586 sub r8,r4
L_0601B588:
    c.r[1] = ld32(0x0601B6F0u);  // 0601B588 mov.l 0x0601B6F0,r1
L_0601B58A:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601B58A mov.b @(r0,r1),r1
L_0601B58C:
    c.r[1] = c.r[1] & 0xFFu;  // 0601B58C extu.b r1,r1
L_0601B58E:
    c.r[1] -= 1;  // 0601B58E add #-1,r1
L_0601B590:
    c.macl = c.r[1] * c.r[10];  // 0601B590 mul.l r10,r1
L_0601B592:
    c.r[1] = c.macl;  // 0601B592 sts macl,r1
L_0601B594:
    c.macl = c.r[1] * c.r[8];  // 0601B594 mul.l r8,r1
L_0601B596:
    c.r[0] = c.r[3];  // 0601B596 mov r3,r0
L_0601B598:
    c.r[1] = c.macl;  // 0601B598 sts macl,r1
L_0601B59A:
    c.r[0] -= c.r[1];  // 0601B59A sub r1,r0
L_0601B59C:
    c.r[1] = c.r[0];  // 0601B59C mov r0,r1
L_0601B59E:
    c.t = (int32_t)c.r[1] > (int32_t)c.r[4];  // 0601B59E cmp/gt r4,r1
L_0601B5A0:
    { const bool k = !c.t; c.r[0] = c.r[2]; if (k) { SH2_POLL(c); goto L_0601B57C; } }  // 0601B5A0 bf/s 0x0601B57C ; mov r2,r0
L_0601B5A4:
    c.r[1] = ld32(0x0601B6F4u);  // 0601B5A4 mov.l 0x0601B6F4,r1
L_0601B5A6:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B5A6 mov.b @r1,r1
L_0601B5A8:
    c.r[0] = c.r[1] & 0xFFu;  // 0601B5A8 extu.b r1,r0
L_0601B5AA:
    c.r[1] = ld32(0x0601B6ECu);  // 0601B5AA mov.l 0x0601B6EC,r1
L_0601B5AC:
    st8(c.r[0] + c.r[1], c.r[4]); goto L_0601B5C8;  // 0601B5AC bra 0x0601B5C8 ; mov.b r4,@(r0,r1)
L_0601B5B0:
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B5B0 mov.b @r1,r3
L_0601B5B2:
    c.r[2] = c.r[3] & 0xFFu;  // 0601B5B2 extu.b r3,r2
L_0601B5B4:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601B6E4u);  // 0601B5B4 mov.w 0x0601B6E4,r1
L_0601B5B6:
    c.t = c.r[2] == c.r[1];  // 0601B5B6 cmp/eq r1,r2
L_0601B5B8:
    if (!c.t) { goto L_0601B5BE; }  // 0601B5B8 bf 0x0601B5BE
L_0601B5BA:
    SH2_POLL(c); goto L_0601B46A;  // 0601B5BA bra 0x0601B46A ; nop
L_0601B5BE:
    c.r[1] = ld32(0x0601B6F4u);  // 0601B5BE mov.l 0x0601B6F4,r1
L_0601B5C0:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B5C0 mov.b @r1,r1
L_0601B5C2:
    c.r[0] = c.r[1] & 0xFFu;  // 0601B5C2 extu.b r1,r0
L_0601B5C4:
    c.r[1] = ld32(0x0601B6ECu);  // 0601B5C4 mov.l 0x0601B6EC,r1
L_0601B5C6:
    st8(c.r[0] + c.r[1], c.r[3]);  // 0601B5C6 mov.b r3,@(r0,r1)
L_0601B5C8:
    c.r[1] = c.r[9];  // 0601B5C8 mov r9,r1
L_0601B5CA:
    c.r[1] += 1;  // 0601B5CA add #1,r1
L_0601B5CC:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B5CC mov.b @r1,r1
L_0601B5CE:
    c.r[0] = c.r[1];  // 0601B5CE mov r1,r0
L_0601B5D0:
    c.r[0] >>= 2;  // 0601B5D0 shlr2 r0
L_0601B5D2:
    c.r[0] >>= 2;  // 0601B5D2 shlr2 r0
L_0601B5D4:
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0601B5D4 shlr r0
L_0601B5D6:
    c.r[0] >>= 2;  // 0601B5D6 shlr2 r0
L_0601B5D8:
    c.r[0] &= 0x1u;  // 0601B5D8 and #1,r0
L_0601B5DA:
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601B5DA tst r0,r0
L_0601B5DC:
    if (c.t) { goto L_0601B5E2; }  // 0601B5DC bt 0x0601B5E2
L_0601B5DE:
    SH2_POLL(c); goto L_0601B46A;  // 0601B5DE bra 0x0601B46A ; nop
L_0601B5E2:
    c.r[1] = ld32(0x0601B6F8u);  // 0601B5E2 mov.l 0x0601B6F8,r1
L_0601B5E4:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0601B5E4 mov.w @r1,r1
L_0601B5E6:
    c.r[2] = (uint32_t)(int16_t)ld16(0x0601B6E6u);  // 0601B5E6 mov.w 0x0601B6E6,r2
L_0601B5E8:
    c.r[2] &= c.r[1];  // 0601B5E8 and r1,r2
L_0601B5EA:
    c.t = (c.r[2] & c.r[2]) == 0;  // 0601B5EA tst r2,r2
L_0601B5EC:
    if (c.t) { goto L_0601B6C8; }  // 0601B5EC bt 0x0601B6C8
L_0601B5EE:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0601B5EE mov.b @r9,r1
L_0601B5F0:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601B6E8u);  // 0601B5F0 mov.w 0x0601B6E8,r0
L_0601B5F2:
    c.r[1] &= c.r[0];  // 0601B5F2 and r0,r1
L_0601B5F4:
    c.r[1] >>= 2;  // 0601B5F4 shlr2 r1
L_0601B5F6:
    c.r[1] >>= 2;  // 0601B5F6 shlr2 r1
L_0601B5F8:
    c.r[1] >>= 2;  // 0601B5F8 shlr2 r1
L_0601B5FA:
    c.r[0] = c.r[1];  // 0601B5FA mov r1,r0
L_0601B5FC:
    c.t = c.r[0] == 0x1u;  // 0601B5FC cmp/eq #1,r0
L_0601B5FE:
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_0601B60C; } }  // 0601B5FE bt/s 0x0601B60C ; mov r9,r1
L_0601B602:
    c.t = c.r[0] == 0x2u;  // 0601B602 cmp/eq #2,r0
L_0601B604:
    { const bool k = c.t; c.r[1] += 7; if (k) { goto L_0601B696; } }  // 0601B604 bt/s 0x0601B696 ; add #7,r1
L_0601B608:
    c.r[1] = c.r[9]; goto L_0601B6B0;  // 0601B608 bra 0x0601B6B0 ; mov r9,r1
L_0601B60C:
    c.r[1] += 5;  // 0601B60C add #5,r1
L_0601B60E:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B60E mov.b @r1,r1
L_0601B610:
    c.r[10] = c.r[1] & 0xFFu;  // 0601B610 extu.b r1,r10
L_0601B612:
    c.r[1] = c.r[9];  // 0601B612 mov r9,r1
L_0601B614:
    c.r[1] += 4;  // 0601B614 add #4,r1
L_0601B616:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B616 mov.b @r1,r1
L_0601B618:
    c.r[8] = c.r[1] & 0xFFu;  // 0601B618 extu.b r1,r8
L_0601B61A:
    c.r[1] = c.r[9];  // 0601B61A mov r9,r1
L_0601B61C:
    c.r[1] += 8;  // 0601B61C add #8,r1
L_0601B61E:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B61E mov.b @r1,r1
L_0601B620:
    c.macl = c.r[10] * c.r[8];  // 0601B620 mul.l r8,r10
L_0601B622:
    c.r[4] = c.r[1] & 0xFFu;  // 0601B622 extu.b r1,r4
L_0601B624:
    c.r[1] = c.r[9];  // 0601B624 mov r9,r1
L_0601B626:
    c.r[1] += 9;  // 0601B626 add #9,r1
L_0601B628:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B628 mov.b @r1,r1
L_0601B62A:
    c.r[4] <<= 8;  // 0601B62A shll8 r4
L_0601B62C:
    c.r[1] = c.r[1] & 0xFFu;  // 0601B62C extu.b r1,r1
L_0601B62E:
    c.r[4] |= c.r[1];  // 0601B62E or r1,r4
L_0601B630:
    c.r[1] = ld32(0x0601B6F4u);  // 0601B630 mov.l 0x0601B6F4,r1
L_0601B632:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B632 mov.b @r1,r1
L_0601B634:
    c.r[10] = c.r[1] & 0xFFu;  // 0601B634 extu.b r1,r10
L_0601B636:
    c.r[1] = ld32(0x0601B6F0u);  // 0601B636 mov.l 0x0601B6F0,r1
L_0601B638:
    c.r[0] = c.r[10];  // 0601B638 mov r10,r0
L_0601B63A:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601B63A mov.b @(r0,r1),r1
L_0601B63C:
    c.r[2] = c.macl;  // 0601B63C sts macl,r2
L_0601B63E:
    c.r[1] = c.r[1] & 0xFFu;  // 0601B63E extu.b r1,r1
L_0601B640:
    c.r[1] -= 1;  // 0601B640 add #-1,r1
L_0601B642:
    c.macl = c.r[2] * c.r[1];  // 0601B642 mul.l r1,r2
L_0601B644:
    c.r[1] = c.macl;  // 0601B644 sts macl,r1
L_0601B646:
    c.macl = c.r[2];  // 0601B646 lds r2,macl
L_0601B648:
    c.r[4] -= c.r[1];  // 0601B648 sub r1,r4
L_0601B64A:
    c.r[1] = c.macl;  // 0601B64A sts macl,r1
L_0601B64C:
    c.t = (int32_t)c.r[4] > (int32_t)c.r[1];  // 0601B64C cmp/gt r1,r4
L_0601B64E:
    if (!c.t) { goto L_0601B652; }  // 0601B64E bf 0x0601B652
L_0601B650:
    c.r[4] = c.macl;  // 0601B650 sts macl,r4
L_0601B652:
    c.r[11] = ld32(0x0601B6ECu);  // 0601B652 mov.l 0x0601B6EC,r11
L_0601B654:
    c.r[0] = c.r[10];  // 0601B654 mov r10,r0
L_0601B656:
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 0601B656 mov.b @(r0,r11),r2
L_0601B658:
    c.r[6] = c.r[2] & 0xFFu;  // 0601B658 extu.b r2,r6
L_0601B65A:
    c.r[1] = c.r[6];  // 0601B65A mov r6,r1
L_0601B65C:
    c.r[1] += c.r[8];  // 0601B65C add r8,r1
L_0601B65E:
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[4];  // 0601B65E cmp/ge r4,r1
L_0601B660:
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_0601B66A; } }  // 0601B660 bt/s 0x0601B66A ; mov r9,r1
L_0601B664:
    c.r[8] += c.r[2];  // 0601B664 add r2,r8
L_0601B666:
    st8(c.r[0] + c.r[11], c.r[8]); goto L_0601B6B0;  // 0601B666 bra 0x0601B6B0 ; mov.b r8,@(r0,r11)
L_0601B66A:
    c.r[1] += 1;  // 0601B66A add #1,r1
L_0601B66C:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B66C mov.b @r1,r1
L_0601B66E:
    c.r[0] = c.r[1];  // 0601B66E mov r1,r0
L_0601B670:
    c.r[0] >>= 2;  // 0601B670 shlr2 r0
L_0601B672:
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0601B672 shlr r0
L_0601B674:
    c.r[0] >>= 2;  // 0601B674 shlr2 r0
L_0601B676:
    c.r[0] &= 0x1u;  // 0601B676 and #1,r0
L_0601B678:
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601B678 tst r0,r0
L_0601B67A:
    { const bool k = !c.t; c.r[4] = c.r[6]; if (k) { goto L_0601B682; } }  // 0601B67A bf/s 0x0601B682 ; mov r6,r4
L_0601B67E:
    SH2_POLL(c); goto L_0601B46A;  // 0601B67E bra 0x0601B46A ; nop
L_0601B682:
    c.r[7] = ld32(0x0601B6FCu);  // 0601B682 mov.l 0x0601B6FC,r7
L_0601B684:
    { const uint32_t x = c.r[7]; c.pr = 0x0601B688u; c.r[5] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601B688u) return; }  // 0601B684 jsr @r7 ; mov r8,r5
L_0601B688:
    c.r[7] = c.r[0];  // 0601B688 mov r0,r7
L_0601B68A:
    c.macl = c.r[7] * c.r[8];  // 0601B68A mul.l r8,r7
L_0601B68C:
    c.r[0] = c.r[10];  // 0601B68C mov r10,r0
L_0601B68E:
    c.r[1] = c.macl;  // 0601B68E sts macl,r1
L_0601B690:
    c.r[6] -= c.r[1];  // 0601B690 sub r1,r6
L_0601B692:
    st8(c.r[0] + c.r[11], c.r[6]); goto L_0601B6AE;  // 0601B692 bra 0x0601B6AE ; mov.b r6,@(r0,r11)
L_0601B696:
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B696 mov.b @r1,r3
L_0601B698:
    c.r[2] = c.r[3] & 0xFFu;  // 0601B698 extu.b r3,r2
L_0601B69A:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601B6E4u);  // 0601B69A mov.w 0x0601B6E4,r1
L_0601B69C:
    c.t = c.r[2] == c.r[1];  // 0601B69C cmp/eq r1,r2
L_0601B69E:
    if (!c.t) { goto L_0601B6A4; }  // 0601B69E bf 0x0601B6A4
L_0601B6A0:
    SH2_POLL(c); goto L_0601B46A;  // 0601B6A0 bra 0x0601B46A ; nop
L_0601B6A4:
    c.r[1] = ld32(0x0601B6F4u);  // 0601B6A4 mov.l 0x0601B6F4,r1
L_0601B6A6:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B6A6 mov.b @r1,r1
L_0601B6A8:
    c.r[0] = c.r[1] & 0xFFu;  // 0601B6A8 extu.b r1,r0
L_0601B6AA:
    c.r[1] = ld32(0x0601B6ECu);  // 0601B6AA mov.l 0x0601B6EC,r1
L_0601B6AC:
    st8(c.r[0] + c.r[1], c.r[3]);  // 0601B6AC mov.b r3,@(r0,r1)
L_0601B6AE:
    c.r[1] = c.r[9];  // 0601B6AE mov r9,r1
L_0601B6B0:
    c.r[1] += 1;  // 0601B6B0 add #1,r1
L_0601B6B2:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B6B2 mov.b @r1,r1
L_0601B6B4:
    c.r[0] = c.r[1];  // 0601B6B4 mov r1,r0
L_0601B6B6:
    c.r[0] >>= 2;  // 0601B6B6 shlr2 r0
L_0601B6B8:
    c.r[0] >>= 2;  // 0601B6B8 shlr2 r0
L_0601B6BA:
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0601B6BA shlr r0
L_0601B6BC:
    c.r[0] >>= 2;  // 0601B6BC shlr2 r0
L_0601B6BE:
    c.r[0] &= 0x1u;  // 0601B6BE and #1,r0
L_0601B6C0:
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601B6C0 tst r0,r0
L_0601B6C2:
    if (c.t) { goto L_0601B6C8; }  // 0601B6C2 bt 0x0601B6C8
L_0601B6C4:
    SH2_POLL(c); goto L_0601B46A;  // 0601B6C4 bra 0x0601B46A ; nop
L_0601B6C8:
    c.r[1] = ld32(0x0601B700u);  // 0601B6C8 mov.l 0x0601B700,r1
L_0601B6CA:
    { const uint32_t x = c.r[1]; c.pr = 0x0601B6CEu; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601B6CEu) return; }  // 0601B6CA jsr @r1 ; mov r9,r4
L_0601B6CE:
    c.r[0] = 0x0u;  // 0601B6CE mov #0,r0
L_0601B6D0:
    c.r[15] = c.r[14];  // 0601B6D0 mov r14,r15
L_0601B6D2:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601B6D2 lds.l @r15+,pr
L_0601B6D4:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601B6D4 mov.l @r15+,r14
L_0601B6D6:
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0601B6D6 mov.l @r15+,r13
L_0601B6D8:
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0601B6D8 mov.l @r15+,r12
L_0601B6DA:
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0601B6DA mov.l @r15+,r11
L_0601B6DC:
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0601B6DC mov.l @r15+,r10
L_0601B6DE:
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0601B6DE mov.l @r15+,r9
L_0601B6E0:
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601B6E0 rts ; mov.l @r15+,r8
L_0607EB7C:
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0607EB7C mov.l r8,@-r15
L_0607EB7E:
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0607EB7E mov.l r9,@-r15
L_0607EB80:
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0607EB80 mov.l r10,@-r15
L_0607EB82:
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0607EB82 mov.l r11,@-r15
L_0607EB84:
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0607EB84 mov.l r12,@-r15
L_0607EB86:
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0607EB86 mov.l r13,@-r15
L_0607EB88:
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0607EB88 mov.l r14,@-r15
L_0607EB8A:
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0607EB8A sts.l pr,@-r15
L_0607EB8C:
    c.r[1] = ld32(0x0607ED04u);  // 0607EB8C mov.l 0x0607ED04,r1
L_0607EB8E:
    c.r[10] = ld32(c.r[1]);  // 0607EB8E mov.l @r1,r10
L_0607EB90:
    c.r[0] = 0x0u;  // 0607EB90 mov #0,r0
L_0607EB92:
    st32(c.r[1], c.r[0]);  // 0607EB92 mov.l r0,@r1
L_0607EB94:
    c.r[1] = ld32(0x0607ED08u);  // 0607EB94 mov.l 0x0607ED08,r1
L_0607EB96:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607EB96 mov.b @r1,r0
L_0607EB98:
    c.r[0] = c.r[0] & 0xFFu;  // 0607EB98 extu.b r0,r0
L_0607EB9A:
    c.r[13] = c.r[0];  // 0607EB9A mov r0,r13
L_0607EB9C:
    c.r[1] = ld32(0x0607ED0Cu);  // 0607EB9C mov.l 0x0607ED0C,r1
L_0607EB9E:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607EB9E mov.b @r1,r0
L_0607EBA0:
    c.r[0] = c.r[0] & 0xFFu;  // 0607EBA0 extu.b r0,r0
L_0607EBA2:
    c.r[1] = c.r[13];  // 0607EBA2 mov r13,r1
L_0607EBA4:
    c.r[1] <<= 8;  // 0607EBA4 shll8 r1
L_0607EBA6:
    c.r[0] |= c.r[1];  // 0607EBA6 or r1,r0
L_0607EBA8:
    c.r[1] = ld32(0x0607ED10u);  // 0607EBA8 mov.l 0x0607ED10,r1
L_0607EBAA:
    st16(c.r[1], c.r[0]);  // 0607EBAA mov.w r0,@r1
L_0607EBAC:
    c.r[0] = c.r[13];  // 0607EBAC mov r13,r0
L_0607EBAE:
    c.t = c.r[0] == 0x43u;  // 0607EBAE cmp/eq #67,r0
L_0607EBB0:
    if (!c.t) { goto L_0607EBBA; }  // 0607EBB0 bf 0x0607EBBA
L_0607EBB2:
    c.r[1] = ld32(0x0607ED14u);  // 0607EBB2 mov.l 0x0607ED14,r1
L_0607EBB4:
    c.r[2] = ld32(0x0607ED18u);  // 0607EBB4 mov.l 0x0607ED18,r2
L_0607EBB6:
    goto L_0607EBC6;  // 0607EBB6 bra 0x0607EBC6 ; nop
L_0607EBBA:
    c.t = c.r[0] == 0x58u;  // 0607EBBA cmp/eq #88,r0
L_0607EBBC:
    if (c.t) { goto L_0607EBC2; }  // 0607EBBC bt 0x0607EBC2
L_0607EBBE:
    goto L_0607ECE8;  // 0607EBBE bra 0x0607ECE8 ; nop
L_0607EBC2:
    c.r[1] = ld32(0x0607ED1Cu);  // 0607EBC2 mov.l 0x0607ED1C,r1
L_0607EBC4:
    c.r[2] = ld32(0x0607ED20u);  // 0607EBC4 mov.l 0x0607ED20,r2
L_0607EBC6:
    c.r[1] = ld32(c.r[1]);  // 0607EBC6 mov.l @r1,r1
L_0607EBC8:
    c.t = c.r[2] == c.r[1];  // 0607EBC8 cmp/eq r1,r2
L_0607EBCA:
    if (c.t) { goto L_0607EBD0; }  // 0607EBCA bt 0x0607EBD0
L_0607EBCC:
    goto L_0607ECE8;  // 0607EBCC bra 0x0607ECE8 ; nop
L_0607EBD0:
    c.r[0] = c.r[13];  // 0607EBD0 mov r13,r0
L_0607EBD2:
    c.t = c.r[0] == 0x43u;  // 0607EBD2 cmp/eq #67,r0
L_0607EBD4:
    if (!c.t) { goto L_0607EC02; }  // 0607EBD4 bf 0x0607EC02
L_0607EBD6:
    c.t = (c.r[10] & c.r[10]) == 0;  // 0607EBD6 tst r10,r10
L_0607EBD8:
    if (c.t) { goto L_0607EC02; }  // 0607EBD8 bt 0x0607EC02
L_0607EBDA:
    c.r[1] = ld32(0x0607ED24u);  // 0607EBDA mov.l 0x0607ED24,r1
L_0607EBDC:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607EBDC mov.b @r1,r0
L_0607EBDE:
    c.t = (c.r[0] & 0x8u) == 0;  // 0607EBDE tst #8,r0
L_0607EBE0:
    if (!c.t) { goto L_0607EC02; }  // 0607EBE0 bf 0x0607EC02
L_0607EBE2:
    c.r[1] = ld32(0x0607ED28u);  // 0607EBE2 mov.l 0x0607ED28,r1
L_0607EBE4:
    c.r[1] = ld32(c.r[1]);  // 0607EBE4 mov.l @r1,r1
L_0607EBE6:
    c.t = c.r[10] == c.r[1];  // 0607EBE6 cmp/eq r1,r10
L_0607EBE8:
    if (!c.t) { goto L_0607EC02; }  // 0607EBE8 bf 0x0607EC02
L_0607EBEA:
    c.r[3] = c.r[10];  // 0607EBEA mov r10,r3
L_0607EBEC:
    c.r[8] = ld32(0x0607ED2Cu);  // 0607EBEC mov.l 0x0607ED2C,r8
L_0607EBEE:
    c.r[9] = 0x1Cu;  // 0607EBEE mov #28,r9
L_0607EBF0:
    c.r[10] = 0x28u;  // 0607EBF0 mov #40,r10
L_0607EBF2:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[8]); c.r[8] += 2;  // 0607EBF2 mov.w @r8+,r1
L_0607EBF4:
    st16(c.r[3], c.r[1]);  // 0607EBF4 mov.w r1,@r3
L_0607EBF6:
    c.r[10] -= 1; c.t = c.r[10] == 0;  // 0607EBF6 dt r10
L_0607EBF8:
    { const bool k = !c.t; c.r[3] += 2; if (k) { SH2_POLL(c); goto L_0607EBF2; } }  // 0607EBF8 bf/s 0x0607EBF2 ; add #2,r3
L_0607EBFC:
    c.r[9] -= 1; c.t = c.r[9] == 0;  // 0607EBFC dt r9
L_0607EBFE:
    { const bool k = !c.t; c.r[3] += 48; if (k) { SH2_POLL(c); goto L_0607EBF0; } }  // 0607EBFE bf/s 0x0607EBF0 ; add #48,r3
L_0607EC02:
    c.r[3] = ld32(0x0607ED30u);  // 0607EC02 mov.l 0x0607ED30,r3
L_0607EC04:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0607EC04 mov.w @r3,r1
L_0607EC06:
    c.r[4] = ld32(0x0607ED34u);  // 0607EC06 mov.l 0x0607ED34,r4
L_0607EC08:
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[4]);  // 0607EC08 mov.w @r4,r2
L_0607EC0A:
    c.r[1] |= c.r[2];  // 0607EC0A or r2,r1
L_0607EC0C:
    c.r[1] = c.r[1] & 0xFFFFu;  // 0607EC0C extu.w r1,r1
L_0607EC0E:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607ED68u);  // 0607EC0E mov.w 0x0607ED68,r0
L_0607EC10:
    c.t = (c.r[1] & c.r[0]) == 0;  // 0607EC10 tst r0,r1
L_0607EC12:
    if (!c.t) { goto L_0607ECE8; }  // 0607EC12 bf 0x0607ECE8
L_0607EC14:
    c.r[0] = c.r[1];  // 0607EC14 mov r1,r0
L_0607EC16:
    c.r[0] <<= 2;  // 0607EC16 shll2 r0
L_0607EC18:
    c.r[0] >>= 16;  // 0607EC18 shlr16 r0
L_0607EC1A:
    c.t = c.r[0] == 0x1u;  // 0607EC1A cmp/eq #1,r0
L_0607EC1C:
    if (c.t) { goto L_0607EC26; }  // 0607EC1C bt 0x0607EC26
L_0607EC1E:
    c.t = c.r[0] == 0x2u;  // 0607EC1E cmp/eq #2,r0
L_0607EC20:
    if (!c.t) { goto L_0607ECE8; }  // 0607EC20 bf 0x0607ECE8
L_0607EC22:
    c.r[5] = 0x1u; goto L_0607EC28;  // 0607EC22 bra 0x0607EC28 ; mov #1,r5
L_0607EC26:
    c.r[5] = 0xFFFFFFFFu;  // 0607EC26 mov #-1,r5
L_0607EC28:
    c.r[6] = ld32(0x0607ED38u);  // 0607EC28 mov.l 0x0607ED38,r6
L_0607EC2A:
    c.r[7] = ld32(c.r[6]);  // 0607EC2A mov.l @r6,r7
L_0607EC2C:
    c.r[8] = c.r[7];  // 0607EC2C mov r7,r8
L_0607EC2E:
    c.r[8] -= 14;  // 0607EC2E add #-14,r8
L_0607EC30:
    c.r[9] = ld32(0x0607ED3Cu);  // 0607EC30 mov.l 0x0607ED3C,r9
L_0607EC32:
    c.r[0] = c.r[13];  // 0607EC32 mov r13,r0
L_0607EC34:
    st8(c.r[9] + 2, c.r[0]);  // 0607EC34 mov.b r0,@(2,r9)
L_0607EC36:
    c.r[10] = 0xEu;  // 0607EC36 mov #14,r10
L_0607EC38:
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[8]); c.r[8] += 1;  // 0607EC38 mov.b @r8+,r11
L_0607EC3A:
    c.r[12] = (uint32_t)(int8_t)ld8(c.r[9]); c.r[9] += 1;  // 0607EC3A mov.b @r9+,r12
L_0607EC3C:
    c.t = c.r[12] == c.r[11];  // 0607EC3C cmp/eq r11,r12
L_0607EC3E:
    if (!c.t) { goto L_0607ECE8; }  // 0607EC3E bf 0x0607ECE8
L_0607EC40:
    c.r[10] -= 1; c.t = c.r[10] == 0;  // 0607EC40 dt r10
L_0607EC42:
    if (!c.t) { SH2_POLL(c); goto L_0607EC38; }  // 0607EC42 bf 0x0607EC38
L_0607EC44:
    c.r[0] = c.r[13];  // 0607EC44 mov r13,r0
L_0607EC46:
    c.t = c.r[0] == 0x58u;  // 0607EC46 cmp/eq #88,r0
L_0607EC48:
    if (!c.t) { goto L_0607EC50; }  // 0607EC48 bf 0x0607EC50
L_0607EC4A:
    c.r[0] = ld32(0x0607ED40u);  // 0607EC4A mov.l 0x0607ED40,r0
L_0607EC4C:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x0601B114u: goto L_0601B114; case 0x0601B116u: goto L_0601B116; case 0x0601B124u: goto L_0601B124; case 0x0601B126u: goto L_0601B126; case 0x0601B128u: goto L_0601B128; case 0x0601B12Au: goto L_0601B12A; case 0x0601B12Cu: goto L_0601B12C; case 0x0601B12Eu: goto L_0601B12E; case 0x0601B130u: goto L_0601B130; case 0x0601B132u: goto L_0601B132; case 0x0601B134u: goto L_0601B134; case 0x0601B136u: goto L_0601B136; case 0x0601B138u: goto L_0601B138; case 0x0601B13Au: goto L_0601B13A; case 0x0601B13Eu: goto L_0601B13E; case 0x0601B140u: goto L_0601B140; case 0x0601B144u: goto L_0601B144; case 0x0601B146u: goto L_0601B146; case 0x0601B148u: goto L_0601B148; case 0x0601B14Au: goto L_0601B14A; case 0x0601B14Cu: goto L_0601B14C; case 0x0601B14Eu: goto L_0601B14E; case 0x0601B150u: goto L_0601B150; case 0x0601B152u: goto L_0601B152; case 0x0601B156u: goto L_0601B156; case 0x0601B158u: goto L_0601B158; case 0x0601B15Au: goto L_0601B15A; case 0x0601B15Cu: goto L_0601B15C; case 0x0601B15Eu: goto L_0601B15E; case 0x0601B162u: goto L_0601B162; case 0x0601B164u: goto L_0601B164; case 0x0601B166u: goto L_0601B166; case 0x0601B168u: goto L_0601B168; case 0x0601B16Au: goto L_0601B16A; case 0x0601B16Cu: goto L_0601B16C; case 0x0601B16Eu: goto L_0601B16E; case 0x0601B170u: goto L_0601B170; case 0x0601B172u: goto L_0601B172; case 0x0601B176u: goto L_0601B176; case 0x0601B178u: goto L_0601B178; case 0x0601B17Au: goto L_0601B17A; case 0x0601B17Cu: goto L_0601B17C; case 0x0601B17Eu: goto L_0601B17E; case 0x0601B180u: goto L_0601B180; case 0x0601B182u: goto L_0601B182; case 0x0601B184u: goto L_0601B184; case 0x0601B188u: goto L_0601B188; case 0x0601B18Au: goto L_0601B18A; case 0x0601B18Cu: goto L_0601B18C; case 0x0601B190u: goto L_0601B190; case 0x0601B194u: goto L_0601B194; case 0x0601B196u: goto L_0601B196; case 0x0601B198u: goto L_0601B198; case 0x0601B19Au: goto L_0601B19A; case 0x0601B19Cu: goto L_0601B19C; case 0x0601B19Eu: goto L_0601B19E; case 0x0601B1A0u: goto L_0601B1A0; case 0x0601B1A2u: goto L_0601B1A2; case 0x0601B1A4u: goto L_0601B1A4; case 0x0601B1A6u: goto L_0601B1A6; case 0x0601B1A8u: goto L_0601B1A8; case 0x0601B1AAu: goto L_0601B1AA; case 0x0601B1ACu: goto L_0601B1AC; case 0x0601B1B0u: goto L_0601B1B0; case 0x0601B1B2u: goto L_0601B1B2; case 0x0601B1B4u: goto L_0601B1B4; case 0x0601B1B6u: goto L_0601B1B6; case 0x0601B1B8u: goto L_0601B1B8; case 0x0601B1BAu: goto L_0601B1BA; case 0x0601B1BCu: goto L_0601B1BC; case 0x0601B1BEu: goto L_0601B1BE; case 0x0601B1C0u: goto L_0601B1C0; case 0x0601B1C2u: goto L_0601B1C2; case 0x0601B1C4u: goto L_0601B1C4; case 0x0601B1C8u: goto L_0601B1C8; case 0x0601B1CAu: goto L_0601B1CA; case 0x0601B1CCu: goto L_0601B1CC; case 0x0601B1CEu: goto L_0601B1CE; case 0x0601B1D0u: goto L_0601B1D0; case 0x0601B1D2u: goto L_0601B1D2; case 0x0601B1D4u: goto L_0601B1D4; case 0x0601B1D6u: goto L_0601B1D6; case 0x0601B1D8u: goto L_0601B1D8; case 0x0601B1DAu: goto L_0601B1DA; case 0x0601B1DCu: goto L_0601B1DC; case 0x0601B1DEu: goto L_0601B1DE; case 0x0601B1E0u: goto L_0601B1E0; case 0x0601B1E2u: goto L_0601B1E2; case 0x0601B1E4u: goto L_0601B1E4; case 0x0601B1E6u: goto L_0601B1E6; case 0x0601B1E8u: goto L_0601B1E8; case 0x0601B1EAu: goto L_0601B1EA; case 0x0601B1ECu: goto L_0601B1EC; case 0x0601B1EEu: goto L_0601B1EE; case 0x0601B1F0u: goto L_0601B1F0; case 0x0601B1F2u: goto L_0601B1F2; case 0x0601B1F4u: goto L_0601B1F4; case 0x0601B1F6u: goto L_0601B1F6; case 0x0601B1F8u: goto L_0601B1F8; case 0x0601B1FAu: goto L_0601B1FA; case 0x0601B1FCu: goto L_0601B1FC; case 0x0601B1FEu: goto L_0601B1FE; case 0x0601B200u: goto L_0601B200; case 0x0601B202u: goto L_0601B202; case 0x0601B204u: goto L_0601B204; case 0x0601B206u: goto L_0601B206; case 0x0601B208u: goto L_0601B208; case 0x0601B20Au: goto L_0601B20A; case 0x0601B20Cu: goto L_0601B20C; case 0x0601B20Eu: goto L_0601B20E; case 0x0601B210u: goto L_0601B210; case 0x0601B214u: goto L_0601B214; case 0x0601B216u: goto L_0601B216; case 0x0601B218u: goto L_0601B218; case 0x0601B21Au: goto L_0601B21A; case 0x0601B21Cu: goto L_0601B21C; case 0x0601B21Eu: goto L_0601B21E; case 0x0601B220u: goto L_0601B220; case 0x0601B222u: goto L_0601B222; case 0x0601B224u: goto L_0601B224; case 0x0601B228u: goto L_0601B228; case 0x0601B22Au: goto L_0601B22A; case 0x0601B22Eu: goto L_0601B22E; case 0x0601B260u: goto L_0601B260; case 0x0601B262u: goto L_0601B262; case 0x0601B264u: goto L_0601B264; case 0x0601B266u: goto L_0601B266; case 0x0601B268u: goto L_0601B268; case 0x0601B26Au: goto L_0601B26A; case 0x0601B26Cu: goto L_0601B26C; case 0x0601B26Eu: goto L_0601B26E; case 0x0601B270u: goto L_0601B270; case 0x0601B272u: goto L_0601B272; case 0x0601B274u: goto L_0601B274; case 0x0601B276u: goto L_0601B276; case 0x0601B278u: goto L_0601B278; case 0x0601B27Au: goto L_0601B27A; case 0x0601B27Cu: goto L_0601B27C; case 0x0601B27Eu: goto L_0601B27E; case 0x0601B280u: goto L_0601B280; case 0x0601B284u: goto L_0601B284; case 0x0601B286u: goto L_0601B286; case 0x0601B288u: goto L_0601B288; case 0x0601B28Au: goto L_0601B28A; case 0x0601B28Cu: goto L_0601B28C; case 0x0601B28Eu: goto L_0601B28E; case 0x0601B290u: goto L_0601B290; case 0x0601B292u: goto L_0601B292; case 0x0601B296u: goto L_0601B296; case 0x0601B298u: goto L_0601B298; case 0x0601B29Au: goto L_0601B29A; case 0x0601B29Eu: goto L_0601B29E; case 0x0601B2A0u: goto L_0601B2A0; case 0x0601B2A2u: goto L_0601B2A2; case 0x0601B2A4u: goto L_0601B2A4; case 0x0601B2A6u: goto L_0601B2A6; case 0x0601B2A8u: goto L_0601B2A8; case 0x0601B2AAu: goto L_0601B2AA; case 0x0601B2ACu: goto L_0601B2AC; case 0x0601B2AEu: goto L_0601B2AE; case 0x0601B2B0u: goto L_0601B2B0; case 0x0601B2B4u: goto L_0601B2B4; case 0x0601B2B8u: goto L_0601B2B8; case 0x0601B2BAu: goto L_0601B2BA; case 0x0601B2BCu: goto L_0601B2BC; case 0x0601B2BEu: goto L_0601B2BE; case 0x0601B2C0u: goto L_0601B2C0; case 0x0601B2C2u: goto L_0601B2C2; case 0x0601B2C4u: goto L_0601B2C4; case 0x0601B2C6u: goto L_0601B2C6; case 0x0601B2C8u: goto L_0601B2C8; case 0x0601B2CAu: goto L_0601B2CA; case 0x0601B2CCu: goto L_0601B2CC; case 0x0601B2CEu: goto L_0601B2CE; case 0x0601B2D0u: goto L_0601B2D0; case 0x0601B2D2u: goto L_0601B2D2; case 0x0601B2D4u: goto L_0601B2D4; case 0x0601B2D6u: goto L_0601B2D6; case 0x0601B2D8u: goto L_0601B2D8; case 0x0601B2DAu: goto L_0601B2DA; case 0x0601B2DEu: goto L_0601B2DE; case 0x0601B2E0u: goto L_0601B2E0; case 0x0601B2E2u: goto L_0601B2E2; case 0x0601B2E4u: goto L_0601B2E4; case 0x0601B2E6u: goto L_0601B2E6; case 0x0601B2E8u: goto L_0601B2E8; case 0x0601B2EAu: goto L_0601B2EA; case 0x0601B2ECu: goto L_0601B2EC; case 0x0601B2EEu: goto L_0601B2EE; case 0x0601B2F0u: goto L_0601B2F0; case 0x0601B2F2u: goto L_0601B2F2; case 0x0601B2F4u: goto L_0601B2F4; case 0x0601B2F6u: goto L_0601B2F6; case 0x0601B2F8u: goto L_0601B2F8; case 0x0601B2FAu: goto L_0601B2FA; case 0x0601B2FCu: goto L_0601B2FC; case 0x0601B2FEu: goto L_0601B2FE; case 0x0601B300u: goto L_0601B300; case 0x0601B302u: goto L_0601B302; case 0x0601B306u: goto L_0601B306; case 0x0601B308u: goto L_0601B308; case 0x0601B30Au: goto L_0601B30A; case 0x0601B30Cu: goto L_0601B30C; case 0x0601B30Eu: goto L_0601B30E; case 0x0601B312u: goto L_0601B312; case 0x0601B314u: goto L_0601B314; case 0x0601B316u: goto L_0601B316; case 0x0601B318u: goto L_0601B318; case 0x0601B31Au: goto L_0601B31A; case 0x0601B31Cu: goto L_0601B31C; case 0x0601B320u: goto L_0601B320; case 0x0601B322u: goto L_0601B322; case 0x0601B324u: goto L_0601B324; case 0x0601B326u: goto L_0601B326; case 0x0601B328u: goto L_0601B328; case 0x0601B32Cu: goto L_0601B32C; case 0x0601B32Eu: goto L_0601B32E; case 0x0601B330u: goto L_0601B330; case 0x0601B332u: goto L_0601B332; case 0x0601B334u: goto L_0601B334; case 0x0601B336u: goto L_0601B336; case 0x0601B338u: goto L_0601B338; case 0x0601B33Au: goto L_0601B33A; case 0x0601B33Cu: goto L_0601B33C; case 0x0601B340u: goto L_0601B340; case 0x0601B342u: goto L_0601B342; case 0x0601B346u: goto L_0601B346; case 0x0601B348u: goto L_0601B348; case 0x0601B34Au: goto L_0601B34A; case 0x0601B34Eu: goto L_0601B34E; case 0x0601B350u: goto L_0601B350; case 0x0601B352u: goto L_0601B352; case 0x0601B354u: goto L_0601B354; case 0x0601B356u: goto L_0601B356; case 0x0601B358u: goto L_0601B358; case 0x0601B35Au: goto L_0601B35A; case 0x0601B35Cu: goto L_0601B35C; case 0x0601B35Eu: goto L_0601B35E; case 0x0601B360u: goto L_0601B360; case 0x0601B362u: goto L_0601B362; case 0x0601B364u: goto L_0601B364; case 0x0601B366u: goto L_0601B366; case 0x0601B368u: goto L_0601B368; case 0x0601B36Au: goto L_0601B36A; case 0x0601B36Cu: goto L_0601B36C; case 0x0601B36Eu: goto L_0601B36E; case 0x0601B370u: goto L_0601B370; case 0x0601B372u: goto L_0601B372; case 0x0601B374u: goto L_0601B374; case 0x0601B376u: goto L_0601B376; case 0x0601B378u: goto L_0601B378; case 0x0601B37Au: goto L_0601B37A; case 0x0601B37Eu: goto L_0601B37E; case 0x0601B380u: goto L_0601B380; case 0x0601B382u: goto L_0601B382; case 0x0601B384u: goto L_0601B384; case 0x0601B386u: goto L_0601B386; case 0x0601B388u: goto L_0601B388; case 0x0601B38Au: goto L_0601B38A; case 0x0601B38Cu: goto L_0601B38C; case 0x0601B38Eu: goto L_0601B38E; case 0x0601B392u: goto L_0601B392; case 0x0601B394u: goto L_0601B394; case 0x0601B398u: goto L_0601B398; case 0x0601B39Cu: goto L_0601B39C; case 0x0601B39Eu: goto L_0601B39E; case 0x0601B3A0u: goto L_0601B3A0; case 0x0601B3A2u: goto L_0601B3A2; case 0x0601B3A4u: goto L_0601B3A4; case 0x0601B3A6u: goto L_0601B3A6; case 0x0601B3A8u: goto L_0601B3A8; case 0x0601B3AAu: goto L_0601B3AA; case 0x0601B3ACu: goto L_0601B3AC; case 0x0601B3AEu: goto L_0601B3AE; case 0x0601B3B0u: goto L_0601B3B0; case 0x0601B3B2u: goto L_0601B3B2; case 0x0601B3B4u: goto L_0601B3B4; case 0x0601B3B6u: goto L_0601B3B6; case 0x0601B3B8u: goto L_0601B3B8; case 0x0601B3BAu: goto L_0601B3BA; case 0x0601B3BCu: goto L_0601B3BC; case 0x0601B3BEu: goto L_0601B3BE; case 0x0601B3C0u: goto L_0601B3C0; case 0x0601B3C2u: goto L_0601B3C2; case 0x0601B3C4u: goto L_0601B3C4; case 0x0601B3C6u: goto L_0601B3C6; case 0x0601B3C8u: goto L_0601B3C8; case 0x0601B3CAu: goto L_0601B3CA; case 0x0601B3CCu: goto L_0601B3CC; case 0x0601B3CEu: goto L_0601B3CE; case 0x0601B3D0u: goto L_0601B3D0; case 0x0601B3D2u: goto L_0601B3D2; case 0x0601B3D4u: goto L_0601B3D4; case 0x0601B3D6u: goto L_0601B3D6; case 0x0601B3D8u: goto L_0601B3D8; case 0x0601B3DAu: goto L_0601B3DA; case 0x0601B3DCu: goto L_0601B3DC; case 0x0601B3DEu: goto L_0601B3DE; case 0x0601B3E0u: goto L_0601B3E0; case 0x0601B3E2u: goto L_0601B3E2; case 0x0601B3E4u: goto L_0601B3E4; case 0x0601B3E6u: goto L_0601B3E6; case 0x0601B3E8u: goto L_0601B3E8; case 0x0601B3EAu: goto L_0601B3EA; case 0x0601B3ECu: goto L_0601B3EC; case 0x0601B3EEu: goto L_0601B3EE; case 0x0601B3F2u: goto L_0601B3F2; case 0x0601B3F4u: goto L_0601B3F4; case 0x0601B3F6u: goto L_0601B3F6; case 0x0601B3FAu: goto L_0601B3FA; case 0x0601B3FCu: goto L_0601B3FC; case 0x0601B3FEu: goto L_0601B3FE; case 0x0601B400u: goto L_0601B400; case 0x0601B402u: goto L_0601B402; case 0x0601B406u: goto L_0601B406; case 0x0601B408u: goto L_0601B408; case 0x0601B40Au: goto L_0601B40A; case 0x0601B40Cu: goto L_0601B40C; case 0x0601B410u: goto L_0601B410; case 0x0601B412u: goto L_0601B412; case 0x0601B414u: goto L_0601B414; case 0x0601B416u: goto L_0601B416; case 0x0601B418u: goto L_0601B418; case 0x0601B41Au: goto L_0601B41A; case 0x0601B41Cu: goto L_0601B41C; case 0x0601B41Eu: goto L_0601B41E; case 0x0601B420u: goto L_0601B420; case 0x0601B424u: goto L_0601B424; case 0x0601B426u: goto L_0601B426; case 0x0601B428u: goto L_0601B428; case 0x0601B42Au: goto L_0601B42A; case 0x0601B42Cu: goto L_0601B42C; case 0x0601B42Eu: goto L_0601B42E; case 0x0601B430u: goto L_0601B430; case 0x0601B458u: goto L_0601B458; case 0x0601B45Au: goto L_0601B45A; case 0x0601B45Cu: goto L_0601B45C; case 0x0601B45Eu: goto L_0601B45E; case 0x0601B460u: goto L_0601B460; case 0x0601B462u: goto L_0601B462; case 0x0601B464u: goto L_0601B464; case 0x0601B466u: goto L_0601B466; case 0x0601B46Au: goto L_0601B46A; case 0x0601B46Cu: goto L_0601B46C; case 0x0601B470u: goto L_0601B470; case 0x0601B472u: goto L_0601B472; case 0x0601B474u: goto L_0601B474; case 0x0601B476u: goto L_0601B476; case 0x0601B478u: goto L_0601B478; case 0x0601B47Au: goto L_0601B47A; case 0x0601B47Cu: goto L_0601B47C; case 0x0601B47Eu: goto L_0601B47E; case 0x0601B480u: goto L_0601B480; case 0x0601B482u: goto L_0601B482; case 0x0601B486u: goto L_0601B486; case 0x0601B488u: goto L_0601B488; case 0x0601B48Au: goto L_0601B48A; case 0x0601B48Cu: goto L_0601B48C; case 0x0601B48Eu: goto L_0601B48E; case 0x0601B490u: goto L_0601B490; case 0x0601B492u: goto L_0601B492; case 0x0601B494u: goto L_0601B494; case 0x0601B496u: goto L_0601B496; case 0x0601B49Au: goto L_0601B49A; case 0x0601B49Cu: goto L_0601B49C; case 0x0601B49Eu: goto L_0601B49E; case 0x0601B4A2u: goto L_0601B4A2; case 0x0601B4A4u: goto L_0601B4A4; case 0x0601B4A6u: goto L_0601B4A6; case 0x0601B4AAu: goto L_0601B4AA; case 0x0601B4ACu: goto L_0601B4AC; case 0x0601B4AEu: goto L_0601B4AE; case 0x0601B4B0u: goto L_0601B4B0; case 0x0601B4B2u: goto L_0601B4B2; case 0x0601B4B4u: goto L_0601B4B4; case 0x0601B4B6u: goto L_0601B4B6; case 0x0601B4B8u: goto L_0601B4B8; case 0x0601B4BAu: goto L_0601B4BA; case 0x0601B4BCu: goto L_0601B4BC; case 0x0601B4BEu: goto L_0601B4BE; case 0x0601B4C0u: goto L_0601B4C0; case 0x0601B4C2u: goto L_0601B4C2; case 0x0601B4C4u: goto L_0601B4C4; case 0x0601B4C6u: goto L_0601B4C6; case 0x0601B4C8u: goto L_0601B4C8; case 0x0601B4CAu: goto L_0601B4CA; case 0x0601B4CCu: goto L_0601B4CC; case 0x0601B4CEu: goto L_0601B4CE; case 0x0601B4D0u: goto L_0601B4D0; case 0x0601B4D2u: goto L_0601B4D2; case 0x0601B4D6u: goto L_0601B4D6; case 0x0601B4D8u: goto L_0601B4D8; case 0x0601B4DAu: goto L_0601B4DA; case 0x0601B4DCu: goto L_0601B4DC; case 0x0601B4DEu: goto L_0601B4DE; case 0x0601B4E0u: goto L_0601B4E0; case 0x0601B4E2u: goto L_0601B4E2; case 0x0601B4E4u: goto L_0601B4E4; case 0x0601B4E6u: goto L_0601B4E6; case 0x0601B4EAu: goto L_0601B4EA; case 0x0601B4ECu: goto L_0601B4EC; case 0x0601B4F0u: goto L_0601B4F0; case 0x0601B4F4u: goto L_0601B4F4; case 0x0601B4F6u: goto L_0601B4F6; case 0x0601B4F8u: goto L_0601B4F8; case 0x0601B4FAu: goto L_0601B4FA; case 0x0601B4FCu: goto L_0601B4FC; case 0x0601B4FEu: goto L_0601B4FE; case 0x0601B500u: goto L_0601B500; case 0x0601B502u: goto L_0601B502; case 0x0601B504u: goto L_0601B504; case 0x0601B506u: goto L_0601B506; case 0x0601B508u: goto L_0601B508; case 0x0601B50Au: goto L_0601B50A; case 0x0601B50Cu: goto L_0601B50C; case 0x0601B50Eu: goto L_0601B50E; case 0x0601B510u: goto L_0601B510; case 0x0601B512u: goto L_0601B512; case 0x0601B516u: goto L_0601B516; case 0x0601B51Au: goto L_0601B51A; case 0x0601B51Cu: goto L_0601B51C; case 0x0601B51Eu: goto L_0601B51E; case 0x0601B520u: goto L_0601B520; case 0x0601B522u: goto L_0601B522; case 0x0601B524u: goto L_0601B524; case 0x0601B526u: goto L_0601B526; case 0x0601B528u: goto L_0601B528; case 0x0601B52Au: goto L_0601B52A; case 0x0601B52Cu: goto L_0601B52C; case 0x0601B530u: goto L_0601B530; case 0x0601B532u: goto L_0601B532; case 0x0601B534u: goto L_0601B534; case 0x0601B536u: goto L_0601B536; case 0x0601B538u: goto L_0601B538; case 0x0601B53Au: goto L_0601B53A; case 0x0601B53Cu: goto L_0601B53C; case 0x0601B53Eu: goto L_0601B53E; case 0x0601B540u: goto L_0601B540; case 0x0601B542u: goto L_0601B542; case 0x0601B544u: goto L_0601B544; case 0x0601B546u: goto L_0601B546; case 0x0601B548u: goto L_0601B548; case 0x0601B54Au: goto L_0601B54A; case 0x0601B54Cu: goto L_0601B54C; case 0x0601B54Eu: goto L_0601B54E; case 0x0601B550u: goto L_0601B550; case 0x0601B552u: goto L_0601B552; case 0x0601B554u: goto L_0601B554; case 0x0601B556u: goto L_0601B556; case 0x0601B558u: goto L_0601B558; case 0x0601B57Cu: goto L_0601B57C; case 0x0601B57Eu: goto L_0601B57E; case 0x0601B580u: goto L_0601B580; case 0x0601B582u: goto L_0601B582; case 0x0601B584u: goto L_0601B584; case 0x0601B586u: goto L_0601B586; case 0x0601B588u: goto L_0601B588; case 0x0601B58Au: goto L_0601B58A; case 0x0601B58Cu: goto L_0601B58C; case 0x0601B58Eu: goto L_0601B58E; case 0x0601B590u: goto L_0601B590; case 0x0601B592u: goto L_0601B592; case 0x0601B594u: goto L_0601B594; case 0x0601B596u: goto L_0601B596; case 0x0601B598u: goto L_0601B598; case 0x0601B59Au: goto L_0601B59A; case 0x0601B59Cu: goto L_0601B59C; case 0x0601B59Eu: goto L_0601B59E; case 0x0601B5A0u: goto L_0601B5A0; case 0x0601B5A4u: goto L_0601B5A4; case 0x0601B5A6u: goto L_0601B5A6; case 0x0601B5A8u: goto L_0601B5A8; case 0x0601B5AAu: goto L_0601B5AA; case 0x0601B5ACu: goto L_0601B5AC; case 0x0601B5B0u: goto L_0601B5B0; case 0x0601B5B2u: goto L_0601B5B2; case 0x0601B5B4u: goto L_0601B5B4; case 0x0601B5B6u: goto L_0601B5B6; case 0x0601B5B8u: goto L_0601B5B8; case 0x0601B5BAu: goto L_0601B5BA; case 0x0601B5BEu: goto L_0601B5BE; case 0x0601B5C0u: goto L_0601B5C0; case 0x0601B5C2u: goto L_0601B5C2; case 0x0601B5C4u: goto L_0601B5C4; case 0x0601B5C6u: goto L_0601B5C6; case 0x0601B5C8u: goto L_0601B5C8; case 0x0601B5CAu: goto L_0601B5CA; case 0x0601B5CCu: goto L_0601B5CC; case 0x0601B5CEu: goto L_0601B5CE; case 0x0601B5D0u: goto L_0601B5D0; case 0x0601B5D2u: goto L_0601B5D2; case 0x0601B5D4u: goto L_0601B5D4; case 0x0601B5D6u: goto L_0601B5D6; case 0x0601B5D8u: goto L_0601B5D8; case 0x0601B5DAu: goto L_0601B5DA; case 0x0601B5DCu: goto L_0601B5DC; case 0x0601B5DEu: goto L_0601B5DE; case 0x0601B5E2u: goto L_0601B5E2; case 0x0601B5E4u: goto L_0601B5E4; case 0x0601B5E6u: goto L_0601B5E6; case 0x0601B5E8u: goto L_0601B5E8; case 0x0601B5EAu: goto L_0601B5EA; case 0x0601B5ECu: goto L_0601B5EC; case 0x0601B5EEu: goto L_0601B5EE; case 0x0601B5F0u: goto L_0601B5F0; case 0x0601B5F2u: goto L_0601B5F2; case 0x0601B5F4u: goto L_0601B5F4; case 0x0601B5F6u: goto L_0601B5F6; case 0x0601B5F8u: goto L_0601B5F8; case 0x0601B5FAu: goto L_0601B5FA; case 0x0601B5FCu: goto L_0601B5FC; case 0x0601B5FEu: goto L_0601B5FE; case 0x0601B602u: goto L_0601B602; case 0x0601B604u: goto L_0601B604; case 0x0601B608u: goto L_0601B608; case 0x0601B60Cu: goto L_0601B60C; case 0x0601B60Eu: goto L_0601B60E; case 0x0601B610u: goto L_0601B610; case 0x0601B612u: goto L_0601B612; case 0x0601B614u: goto L_0601B614; case 0x0601B616u: goto L_0601B616; case 0x0601B618u: goto L_0601B618; case 0x0601B61Au: goto L_0601B61A; case 0x0601B61Cu: goto L_0601B61C; case 0x0601B61Eu: goto L_0601B61E; case 0x0601B620u: goto L_0601B620; case 0x0601B622u: goto L_0601B622; case 0x0601B624u: goto L_0601B624; case 0x0601B626u: goto L_0601B626; case 0x0601B628u: goto L_0601B628; case 0x0601B62Au: goto L_0601B62A; case 0x0601B62Cu: goto L_0601B62C; case 0x0601B62Eu: goto L_0601B62E; case 0x0601B630u: goto L_0601B630; case 0x0601B632u: goto L_0601B632; case 0x0601B634u: goto L_0601B634; case 0x0601B636u: goto L_0601B636; case 0x0601B638u: goto L_0601B638; case 0x0601B63Au: goto L_0601B63A; case 0x0601B63Cu: goto L_0601B63C; case 0x0601B63Eu: goto L_0601B63E; case 0x0601B640u: goto L_0601B640; case 0x0601B642u: goto L_0601B642; case 0x0601B644u: goto L_0601B644; case 0x0601B646u: goto L_0601B646; case 0x0601B648u: goto L_0601B648; case 0x0601B64Au: goto L_0601B64A; case 0x0601B64Cu: goto L_0601B64C; case 0x0601B64Eu: goto L_0601B64E; case 0x0601B650u: goto L_0601B650; case 0x0601B652u: goto L_0601B652; case 0x0601B654u: goto L_0601B654; case 0x0601B656u: goto L_0601B656; case 0x0601B658u: goto L_0601B658; case 0x0601B65Au: goto L_0601B65A; case 0x0601B65Cu: goto L_0601B65C; case 0x0601B65Eu: goto L_0601B65E; case 0x0601B660u: goto L_0601B660; case 0x0601B664u: goto L_0601B664; case 0x0601B666u: goto L_0601B666; case 0x0601B66Au: goto L_0601B66A; case 0x0601B66Cu: goto L_0601B66C; case 0x0601B66Eu: goto L_0601B66E; case 0x0601B670u: goto L_0601B670; case 0x0601B672u: goto L_0601B672; case 0x0601B674u: goto L_0601B674; case 0x0601B676u: goto L_0601B676; case 0x0601B678u: goto L_0601B678; case 0x0601B67Au: goto L_0601B67A; case 0x0601B67Eu: goto L_0601B67E; case 0x0601B682u: goto L_0601B682; case 0x0601B684u: goto L_0601B684; case 0x0601B688u: goto L_0601B688; case 0x0601B68Au: goto L_0601B68A; case 0x0601B68Cu: goto L_0601B68C; case 0x0601B68Eu: goto L_0601B68E; case 0x0601B690u: goto L_0601B690; case 0x0601B692u: goto L_0601B692; case 0x0601B696u: goto L_0601B696; case 0x0601B698u: goto L_0601B698; case 0x0601B69Au: goto L_0601B69A; case 0x0601B69Cu: goto L_0601B69C; case 0x0601B69Eu: goto L_0601B69E; case 0x0601B6A0u: goto L_0601B6A0; case 0x0601B6A4u: goto L_0601B6A4; case 0x0601B6A6u: goto L_0601B6A6; case 0x0601B6A8u: goto L_0601B6A8; case 0x0601B6AAu: goto L_0601B6AA; case 0x0601B6ACu: goto L_0601B6AC; case 0x0601B6AEu: goto L_0601B6AE; case 0x0601B6B0u: goto L_0601B6B0; case 0x0601B6B2u: goto L_0601B6B2; case 0x0601B6B4u: goto L_0601B6B4; case 0x0601B6B6u: goto L_0601B6B6; case 0x0601B6B8u: goto L_0601B6B8; case 0x0601B6BAu: goto L_0601B6BA; case 0x0601B6BCu: goto L_0601B6BC; case 0x0601B6BEu: goto L_0601B6BE; case 0x0601B6C0u: goto L_0601B6C0; case 0x0601B6C2u: goto L_0601B6C2; case 0x0601B6C4u: goto L_0601B6C4; case 0x0601B6C8u: goto L_0601B6C8; case 0x0601B6CAu: goto L_0601B6CA; case 0x0601B6CEu: goto L_0601B6CE; case 0x0601B6D0u: goto L_0601B6D0; case 0x0601B6D2u: goto L_0601B6D2; case 0x0601B6D4u: goto L_0601B6D4; case 0x0601B6D6u: goto L_0601B6D6; case 0x0601B6D8u: goto L_0601B6D8; case 0x0601B6DAu: goto L_0601B6DA; case 0x0601B6DCu: goto L_0601B6DC; case 0x0601B6DEu: goto L_0601B6DE; case 0x0601B6E0u: goto L_0601B6E0; case 0x0607EB7Cu: goto L_0607EB7C; case 0x0607EB7Eu: goto L_0607EB7E; case 0x0607EB80u: goto L_0607EB80; case 0x0607EB82u: goto L_0607EB82; case 0x0607EB84u: goto L_0607EB84; case 0x0607EB86u: goto L_0607EB86; case 0x0607EB88u: goto L_0607EB88; case 0x0607EB8Au: goto L_0607EB8A; case 0x0607EB8Cu: goto L_0607EB8C; case 0x0607EB8Eu: goto L_0607EB8E; case 0x0607EB90u: goto L_0607EB90; case 0x0607EB92u: goto L_0607EB92; case 0x0607EB94u: goto L_0607EB94; case 0x0607EB96u: goto L_0607EB96; case 0x0607EB98u: goto L_0607EB98; case 0x0607EB9Au: goto L_0607EB9A; case 0x0607EB9Cu: goto L_0607EB9C; case 0x0607EB9Eu: goto L_0607EB9E; case 0x0607EBA0u: goto L_0607EBA0; case 0x0607EBA2u: goto L_0607EBA2; case 0x0607EBA4u: goto L_0607EBA4; case 0x0607EBA6u: goto L_0607EBA6; case 0x0607EBA8u: goto L_0607EBA8; case 0x0607EBAAu: goto L_0607EBAA; case 0x0607EBACu: goto L_0607EBAC; case 0x0607EBAEu: goto L_0607EBAE; case 0x0607EBB0u: goto L_0607EBB0; case 0x0607EBB2u: goto L_0607EBB2; case 0x0607EBB4u: goto L_0607EBB4; case 0x0607EBB6u: goto L_0607EBB6; case 0x0607EBBAu: goto L_0607EBBA; case 0x0607EBBCu: goto L_0607EBBC; case 0x0607EBBEu: goto L_0607EBBE; case 0x0607EBC2u: goto L_0607EBC2; case 0x0607EBC4u: goto L_0607EBC4; case 0x0607EBC6u: goto L_0607EBC6; case 0x0607EBC8u: goto L_0607EBC8; case 0x0607EBCAu: goto L_0607EBCA; case 0x0607EBCCu: goto L_0607EBCC; case 0x0607EBD0u: goto L_0607EBD0; case 0x0607EBD2u: goto L_0607EBD2; case 0x0607EBD4u: goto L_0607EBD4; case 0x0607EBD6u: goto L_0607EBD6; case 0x0607EBD8u: goto L_0607EBD8; case 0x0607EBDAu: goto L_0607EBDA; case 0x0607EBDCu: goto L_0607EBDC; case 0x0607EBDEu: goto L_0607EBDE; case 0x0607EBE0u: goto L_0607EBE0; case 0x0607EBE2u: goto L_0607EBE2; case 0x0607EBE4u: goto L_0607EBE4; case 0x0607EBE6u: goto L_0607EBE6; case 0x0607EBE8u: goto L_0607EBE8; case 0x0607EBEAu: goto L_0607EBEA; case 0x0607EBECu: goto L_0607EBEC; case 0x0607EBEEu: goto L_0607EBEE; case 0x0607EBF0u: goto L_0607EBF0; case 0x0607EBF2u: goto L_0607EBF2; case 0x0607EBF4u: goto L_0607EBF4; case 0x0607EBF6u: goto L_0607EBF6; case 0x0607EBF8u: goto L_0607EBF8; case 0x0607EBFCu: goto L_0607EBFC; case 0x0607EBFEu: goto L_0607EBFE; case 0x0607EC02u: goto L_0607EC02; case 0x0607EC04u: goto L_0607EC04; case 0x0607EC06u: goto L_0607EC06; case 0x0607EC08u: goto L_0607EC08; case 0x0607EC0Au: goto L_0607EC0A; case 0x0607EC0Cu: goto L_0607EC0C; case 0x0607EC0Eu: goto L_0607EC0E; case 0x0607EC10u: goto L_0607EC10; case 0x0607EC12u: goto L_0607EC12; case 0x0607EC14u: goto L_0607EC14; case 0x0607EC16u: goto L_0607EC16; case 0x0607EC18u: goto L_0607EC18; case 0x0607EC1Au: goto L_0607EC1A; case 0x0607EC1Cu: goto L_0607EC1C; case 0x0607EC1Eu: goto L_0607EC1E; case 0x0607EC20u: goto L_0607EC20; case 0x0607EC22u: goto L_0607EC22; case 0x0607EC26u: goto L_0607EC26; case 0x0607EC28u: goto L_0607EC28; case 0x0607EC2Au: goto L_0607EC2A; case 0x0607EC2Cu: goto L_0607EC2C; case 0x0607EC2Eu: goto L_0607EC2E; case 0x0607EC30u: goto L_0607EC30; case 0x0607EC32u: goto L_0607EC32; case 0x0607EC34u: goto L_0607EC34; case 0x0607EC36u: goto L_0607EC36; case 0x0607EC38u: goto L_0607EC38; case 0x0607EC3Au: goto L_0607EC3A; case 0x0607EC3Cu: goto L_0607EC3C; case 0x0607EC3Eu: goto L_0607EC3E; case 0x0607EC40u: goto L_0607EC40; case 0x0607EC42u: goto L_0607EC42; case 0x0607EC44u: goto L_0607EC44; case 0x0607EC46u: goto L_0607EC46; case 0x0607EC48u: goto L_0607EC48; case 0x0607EC4Au: goto L_0607EC4A; case 0x0607EC4Cu: goto L_0607EC4C; case 0x0607EC50u: goto L_0607EC50; case 0x0607EC52u: goto L_0607EC52; case 0x0607EC54u: goto L_0607EC54; case 0x0607EC56u: goto L_0607EC56; case 0x0607EC58u: goto L_0607EC58; case 0x0607EC5Au: goto L_0607EC5A; case 0x0607EC5Cu: goto L_0607EC5C; case 0x0607EC5Eu: goto L_0607EC5E; case 0x0607EC60u: goto L_0607EC60; case 0x0607EC64u: goto L_0607EC64; case 0x0607EC66u: goto L_0607EC66; case 0x0607EC68u: goto L_0607EC68; case 0x0607EC6Au: goto L_0607EC6A; case 0x0607EC6Cu: goto L_0607EC6C; case 0x0607EC6Eu: goto L_0607EC6E; case 0x0607EC70u: goto L_0607EC70; case 0x0607EC74u: goto L_0607EC74; case 0x0607EC76u: goto L_0607EC76; case 0x0607EC78u: goto L_0607EC78; case 0x0607EC7Au: goto L_0607EC7A; case 0x0607EC7Cu: goto L_0607EC7C; case 0x0607EC7Eu: goto L_0607EC7E; case 0x0607EC80u: goto L_0607EC80; case 0x0607EC82u: goto L_0607EC82; case 0x0607EC84u: goto L_0607EC84; case 0x0607EC86u: goto L_0607EC86; case 0x0607EC88u: goto L_0607EC88; case 0x0607EC8Au: goto L_0607EC8A; case 0x0607EC8Cu: goto L_0607EC8C; case 0x0607EC8Eu: goto L_0607EC8E; case 0x0607EC90u: goto L_0607EC90; case 0x0607EC92u: goto L_0607EC92; case 0x0607EC94u: goto L_0607EC94; case 0x0607EC96u: goto L_0607EC96; case 0x0607EC98u: goto L_0607EC98; case 0x0607EC9Au: goto L_0607EC9A; case 0x0607EC9Cu: goto L_0607EC9C; case 0x0607EC9Eu: goto L_0607EC9E; case 0x0607ECA0u: goto L_0607ECA0; case 0x0607ECA2u: goto L_0607ECA2; case 0x0607ECA4u: goto L_0607ECA4; case 0x0607ECA8u: goto L_0607ECA8; case 0x0607ECAAu: goto L_0607ECAA; case 0x0607ECACu: goto L_0607ECAC; case 0x0607ECAEu: goto L_0607ECAE; case 0x0607ECB0u: goto L_0607ECB0; case 0x0607ECB2u: goto L_0607ECB2; case 0x0607ECB4u: goto L_0607ECB4; case 0x0607ECB6u: goto L_0607ECB6; case 0x0607ECB8u: goto L_0607ECB8; case 0x0607ECBAu: goto L_0607ECBA; case 0x0607ECBCu: goto L_0607ECBC; case 0x0607ECBEu: goto L_0607ECBE; case 0x0607ECC0u: goto L_0607ECC0; case 0x0607ECC2u: goto L_0607ECC2; case 0x0607ECC4u: goto L_0607ECC4; case 0x0607ECC6u: goto L_0607ECC6; case 0x0607ECC8u: goto L_0607ECC8; case 0x0607ECCAu: goto L_0607ECCA; case 0x0607ECCCu: goto L_0607ECCC; case 0x0607ECCEu: goto L_0607ECCE; case 0x0607ECD0u: goto L_0607ECD0; case 0x0607ECD2u: goto L_0607ECD2; case 0x0607ECD6u: goto L_0607ECD6; case 0x0607ECD8u: goto L_0607ECD8; case 0x0607ECDAu: goto L_0607ECDA; case 0x0607ECDCu: goto L_0607ECDC; case 0x0607ECDEu: goto L_0607ECDE; case 0x0607ECE0u: goto L_0607ECE0; case 0x0607ECE4u: goto L_0607ECE4; case 0x0607ECE8u: goto L_0607ECE8; case 0x0607ECEAu: goto L_0607ECEA; case 0x0607EE54u: goto L_0607EE54; case 0x0607EE56u: goto L_0607EE56; case 0x0607EE58u: goto L_0607EE58; case 0x0607EE5Au: goto L_0607EE5A; case 0x0607EE5Cu: goto L_0607EE5C; case 0x0607EE5Eu: goto L_0607EE5E; case 0x0607EE60u: goto L_0607EE60; case 0x0607EE62u: goto L_0607EE62; case 0x0608431Eu: goto L_0608431E; case 0x06084320u: goto L_06084320; case 0x06084322u: goto L_06084322; case 0x06084324u: goto L_06084324; case 0x06084326u: goto L_06084326; case 0x06084328u: goto L_06084328; case 0x0608432Au: goto L_0608432A; case 0x0608432Cu: goto L_0608432C; case 0x06084330u: goto L_06084330; case 0x06084332u: goto L_06084332; case 0x06084334u: goto L_06084334; case 0x06084336u: goto L_06084336; case 0x06084338u: goto L_06084338; case 0x0608433Au: goto L_0608433A; case 0x0608433Cu: goto L_0608433C; case 0x0608433Eu: goto L_0608433E; case 0x06084340u: goto L_06084340; case 0x06084342u: goto L_06084342; case 0x06084344u: goto L_06084344; case 0x06084346u: goto L_06084346; case 0x06084348u: goto L_06084348; case 0x0608434Au: goto L_0608434A; case 0x0608434Cu: goto L_0608434C; case 0x0608434Eu: goto L_0608434E; case 0x06084350u: goto L_06084350; case 0x06084352u: goto L_06084352; case 0x06084354u: goto L_06084354; case 0x06084356u: goto L_06084356; case 0x06084358u: goto L_06084358; case 0x0608435Au: goto L_0608435A; case 0x0608435Cu: goto L_0608435C; case 0x0608435Eu: goto L_0608435E; case 0x06084362u: goto L_06084362; case 0x06084364u: goto L_06084364; default: sh2_call(c, x); return; } }  // 0607EC4C jmp @r0 ; nop
L_0607EC50:
    c.r[1] = ld32(0x0607ED44u);  // 0607EC50 mov.l 0x0607ED44,r1
L_0607EC52:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607EC52 mov.b @r1,r0
L_0607EC54:
    c.r[0] = c.r[0] & 0xFFu;  // 0607EC54 extu.b r0,r0
L_0607EC56:
    c.r[13] = c.r[0];  // 0607EC56 mov r0,r13
L_0607EC58:
    c.r[1] = 0x5u;  // 0607EC58 mov #5,r1
L_0607EC5A:
    c.t = c.r[0] >= c.r[1];  // 0607EC5A cmp/hs r1,r0
L_0607EC5C:
    if (c.t) { goto L_0607ECE8; }  // 0607EC5C bt 0x0607ECE8
L_0607EC5E:
    c.r[0] = ld32(0x0607ED48u);  // 0607EC5E mov.l 0x0607ED48,r0
L_0607EC60:
    { const uint32_t x = c.r[0]; c.pr = 0x0607EC64u; c.r[4] = c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607EC64u) return; }  // 0607EC60 jsr @r0 ; mov r13,r4
L_0607EC64:
    c.r[1] = ld32(0x0607ED4Cu);  // 0607EC64 mov.l 0x0607ED4C,r1
L_0607EC66:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607EC66 mov.b @r1,r1
L_0607EC68:
    c.r[1] = c.r[1] & 0xFFu;  // 0607EC68 extu.b r1,r1
L_0607EC6A:
    c.r[1] -= c.r[0];  // 0607EC6A sub r0,r1
L_0607EC6C:
    c.r[10] = c.r[1];  // 0607EC6C mov r1,r10
L_0607EC6E:
    c.r[0] = ld32(0x0607ED50u);  // 0607EC6E mov.l 0x0607ED50,r0
L_0607EC70:
    { const uint32_t x = c.r[0]; c.pr = 0x0607EC74u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607EC74u) return; }  // 0607EC70 jsr @r0 ; nop
L_0607EC74:
    c.r[12] = c.r[0];  // 0607EC74 mov r0,r12
L_0607EC76:
    c.r[14] = ld32(0x0607ED54u);  // 0607EC76 mov.l 0x0607ED54,r14
L_0607EC78:
    c.r[2] = c.r[14];  // 0607EC78 mov r14,r2
L_0607EC7A:
    c.r[2] += c.r[13];  // 0607EC7A add r13,r2
L_0607EC7C:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0607EC7C mov.b @r2,r0
L_0607EC7E:
    c.r[0] = c.r[0] & 0xFFu;  // 0607EC7E extu.b r0,r0
L_0607EC80:
    c.r[11] = 0x0u;  // 0607EC80 mov #0,r11
L_0607EC82:
    c.t = (c.r[12] & c.r[12]) == 0;  // 0607EC82 tst r12,r12
L_0607EC84:
    if (!c.t) { goto L_0607EC8A; }  // 0607EC84 bf 0x0607EC8A
L_0607EC86:
    c.r[0] = 0x1u;  // 0607EC86 mov #1,r0
L_0607EC88:
    c.r[11] = 0x1u;  // 0607EC88 mov #1,r11
L_0607EC8A:
    c.r[0] += c.r[5];  // 0607EC8A add r5,r0
L_0607EC8C:
    c.t = (int32_t)c.r[0] >= (int32_t)c.r[11];  // 0607EC8C cmp/ge r11,r0
L_0607EC8E:
    if (!c.t) { goto L_0607ECE4; }  // 0607EC8E bf 0x0607ECE4
L_0607EC90:
    c.t = (int32_t)c.r[0] > (int32_t)c.r[10];  // 0607EC90 cmp/gt r10,r0
L_0607EC92:
    if (c.t) { goto L_0607ECE4; }  // 0607EC92 bt 0x0607ECE4
L_0607EC94:
    st8(c.r[2], c.r[0]);  // 0607EC94 mov.b r0,@r2
L_0607EC96:
    c.t = (c.r[0] & c.r[0]) == 0;  // 0607EC96 tst r0,r0
L_0607EC98:
    if (!c.t) { goto L_0607EC9C; }  // 0607EC98 bf 0x0607EC9C
L_0607EC9A:
    c.r[0] = 0x1u;  // 0607EC9A mov #1,r0
L_0607EC9C:
    c.r[1] = c.r[2];  // 0607EC9C mov r2,r1
L_0607EC9E:
    c.r[1] += 5;  // 0607EC9E add #5,r1
L_0607ECA0:
    st8(c.r[1], c.r[0]);  // 0607ECA0 mov.b r0,@r1
L_0607ECA2:
    c.r[0] = ld32(0x0607ED50u);  // 0607ECA2 mov.l 0x0607ED50,r0
L_0607ECA4:
    { const uint32_t x = c.r[0]; c.pr = 0x0607ECA8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0607ECA8u) return; }  // 0607ECA4 jsr @r0 ; nop
L_0607ECA8:
    c.t = c.r[0] == 0x1u;  // 0607ECA8 cmp/eq #1,r0
L_0607ECAA:
    if (!c.t) { goto L_0607ECBE; }  // 0607ECAA bf 0x0607ECBE
L_0607ECAC:
    c.r[2] = ld32(0x0607ED44u);  // 0607ECAC mov.l 0x0607ED44,r2
L_0607ECAE:
    st8(c.r[2], c.r[1]);  // 0607ECAE mov.b r1,@r2
L_0607ECB0:
    c.r[2] = c.r[14];  // 0607ECB0 mov r14,r2
L_0607ECB2:
    c.r[2] += c.r[1];  // 0607ECB2 add r1,r2
L_0607ECB4:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0607ECB4 mov.b @r2,r0
L_0607ECB6:
    c.t = c.r[0] == 0x1u;  // 0607ECB6 cmp/eq #1,r0
L_0607ECB8:
    if (!c.t) { goto L_0607ECBE; }  // 0607ECB8 bf 0x0607ECBE
L_0607ECBA:
    c.r[0] = 0x0u;  // 0607ECBA mov #0,r0
L_0607ECBC:
    st8(c.r[2], c.r[0]);  // 0607ECBC mov.b r0,@r2
L_0607ECBE:
    c.r[1] = ld32(0x0607ED58u);  // 0607ECBE mov.l 0x0607ED58,r1
L_0607ECC0:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0607ECC0 mov.b @r1,r0
L_0607ECC2:
    c.t = (c.r[0] & 0x80u) == 0;  // 0607ECC2 tst #128,r0
L_0607ECC4:
    if (!c.t) { goto L_0607ECD2; }  // 0607ECC4 bf 0x0607ECD2
L_0607ECC6:
    c.r[1] = ld32(0x0607ED5Cu);  // 0607ECC6 mov.l 0x0607ED5C,r1
L_0607ECC8:
    c.r[0] = 0x0u;  // 0607ECC8 mov #0,r0
L_0607ECCA:
    st8(c.r[1], c.r[0]);  // 0607ECCA mov.b r0,@r1
L_0607ECCC:
    c.r[1] = ld32(0x0607ED60u);  // 0607ECCC mov.l 0x0607ED60,r1
L_0607ECCE:
    c.r[0] = 0x10u;  // 0607ECCE mov #16,r0
L_0607ECD0:
    st16(c.r[1], c.r[0]);  // 0607ECD0 mov.w r0,@r1
L_0607ECD2:
    c.pr = 0x0607ECD6u; SH2_POLL(c); sh2_call(c, 0x0607ECEEu); if (c.pc != 0x0607ECD6u) return;  // 0607ECD2 bsr 0x0607ECEE ; nop
L_0607ECD6:
    c.r[6] = ld32(0x0607ED38u);  // 0607ECD6 mov.l 0x0607ED38,r6
L_0607ECD8:
    c.r[7] = ld32(c.r[6]);  // 0607ECD8 mov.l @r6,r7
L_0607ECDA:
    c.r[7] -= 14;  // 0607ECDA add #-14,r7
L_0607ECDC:
    st32(c.r[6], c.r[7]);  // 0607ECDC mov.l r7,@r6
L_0607ECDE:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0607ED6Au);  // 0607ECDE mov.w 0x0607ED6A,r0
L_0607ECE0:
    goto L_0607EE54;  // 0607ECE0 bra 0x0607EE54 ; nop
L_0607ECE4:
    c.pr = 0x0607ECE8u; SH2_POLL(c); sh2_call(c, 0x0607ECEEu); if (c.pc != 0x0607ECE8u) return;  // 0607ECE4 bsr 0x0607ECEE ; nop
L_0607ECE8:
    c.r[0] = ld32(0x0607ED64u);  // 0607ECE8 mov.l 0x0607ED64,r0
L_0607ECEA:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x0601B114u: goto L_0601B114; case 0x0601B116u: goto L_0601B116; case 0x0601B124u: goto L_0601B124; case 0x0601B126u: goto L_0601B126; case 0x0601B128u: goto L_0601B128; case 0x0601B12Au: goto L_0601B12A; case 0x0601B12Cu: goto L_0601B12C; case 0x0601B12Eu: goto L_0601B12E; case 0x0601B130u: goto L_0601B130; case 0x0601B132u: goto L_0601B132; case 0x0601B134u: goto L_0601B134; case 0x0601B136u: goto L_0601B136; case 0x0601B138u: goto L_0601B138; case 0x0601B13Au: goto L_0601B13A; case 0x0601B13Eu: goto L_0601B13E; case 0x0601B140u: goto L_0601B140; case 0x0601B144u: goto L_0601B144; case 0x0601B146u: goto L_0601B146; case 0x0601B148u: goto L_0601B148; case 0x0601B14Au: goto L_0601B14A; case 0x0601B14Cu: goto L_0601B14C; case 0x0601B14Eu: goto L_0601B14E; case 0x0601B150u: goto L_0601B150; case 0x0601B152u: goto L_0601B152; case 0x0601B156u: goto L_0601B156; case 0x0601B158u: goto L_0601B158; case 0x0601B15Au: goto L_0601B15A; case 0x0601B15Cu: goto L_0601B15C; case 0x0601B15Eu: goto L_0601B15E; case 0x0601B162u: goto L_0601B162; case 0x0601B164u: goto L_0601B164; case 0x0601B166u: goto L_0601B166; case 0x0601B168u: goto L_0601B168; case 0x0601B16Au: goto L_0601B16A; case 0x0601B16Cu: goto L_0601B16C; case 0x0601B16Eu: goto L_0601B16E; case 0x0601B170u: goto L_0601B170; case 0x0601B172u: goto L_0601B172; case 0x0601B176u: goto L_0601B176; case 0x0601B178u: goto L_0601B178; case 0x0601B17Au: goto L_0601B17A; case 0x0601B17Cu: goto L_0601B17C; case 0x0601B17Eu: goto L_0601B17E; case 0x0601B180u: goto L_0601B180; case 0x0601B182u: goto L_0601B182; case 0x0601B184u: goto L_0601B184; case 0x0601B188u: goto L_0601B188; case 0x0601B18Au: goto L_0601B18A; case 0x0601B18Cu: goto L_0601B18C; case 0x0601B190u: goto L_0601B190; case 0x0601B194u: goto L_0601B194; case 0x0601B196u: goto L_0601B196; case 0x0601B198u: goto L_0601B198; case 0x0601B19Au: goto L_0601B19A; case 0x0601B19Cu: goto L_0601B19C; case 0x0601B19Eu: goto L_0601B19E; case 0x0601B1A0u: goto L_0601B1A0; case 0x0601B1A2u: goto L_0601B1A2; case 0x0601B1A4u: goto L_0601B1A4; case 0x0601B1A6u: goto L_0601B1A6; case 0x0601B1A8u: goto L_0601B1A8; case 0x0601B1AAu: goto L_0601B1AA; case 0x0601B1ACu: goto L_0601B1AC; case 0x0601B1B0u: goto L_0601B1B0; case 0x0601B1B2u: goto L_0601B1B2; case 0x0601B1B4u: goto L_0601B1B4; case 0x0601B1B6u: goto L_0601B1B6; case 0x0601B1B8u: goto L_0601B1B8; case 0x0601B1BAu: goto L_0601B1BA; case 0x0601B1BCu: goto L_0601B1BC; case 0x0601B1BEu: goto L_0601B1BE; case 0x0601B1C0u: goto L_0601B1C0; case 0x0601B1C2u: goto L_0601B1C2; case 0x0601B1C4u: goto L_0601B1C4; case 0x0601B1C8u: goto L_0601B1C8; case 0x0601B1CAu: goto L_0601B1CA; case 0x0601B1CCu: goto L_0601B1CC; case 0x0601B1CEu: goto L_0601B1CE; case 0x0601B1D0u: goto L_0601B1D0; case 0x0601B1D2u: goto L_0601B1D2; case 0x0601B1D4u: goto L_0601B1D4; case 0x0601B1D6u: goto L_0601B1D6; case 0x0601B1D8u: goto L_0601B1D8; case 0x0601B1DAu: goto L_0601B1DA; case 0x0601B1DCu: goto L_0601B1DC; case 0x0601B1DEu: goto L_0601B1DE; case 0x0601B1E0u: goto L_0601B1E0; case 0x0601B1E2u: goto L_0601B1E2; case 0x0601B1E4u: goto L_0601B1E4; case 0x0601B1E6u: goto L_0601B1E6; case 0x0601B1E8u: goto L_0601B1E8; case 0x0601B1EAu: goto L_0601B1EA; case 0x0601B1ECu: goto L_0601B1EC; case 0x0601B1EEu: goto L_0601B1EE; case 0x0601B1F0u: goto L_0601B1F0; case 0x0601B1F2u: goto L_0601B1F2; case 0x0601B1F4u: goto L_0601B1F4; case 0x0601B1F6u: goto L_0601B1F6; case 0x0601B1F8u: goto L_0601B1F8; case 0x0601B1FAu: goto L_0601B1FA; case 0x0601B1FCu: goto L_0601B1FC; case 0x0601B1FEu: goto L_0601B1FE; case 0x0601B200u: goto L_0601B200; case 0x0601B202u: goto L_0601B202; case 0x0601B204u: goto L_0601B204; case 0x0601B206u: goto L_0601B206; case 0x0601B208u: goto L_0601B208; case 0x0601B20Au: goto L_0601B20A; case 0x0601B20Cu: goto L_0601B20C; case 0x0601B20Eu: goto L_0601B20E; case 0x0601B210u: goto L_0601B210; case 0x0601B214u: goto L_0601B214; case 0x0601B216u: goto L_0601B216; case 0x0601B218u: goto L_0601B218; case 0x0601B21Au: goto L_0601B21A; case 0x0601B21Cu: goto L_0601B21C; case 0x0601B21Eu: goto L_0601B21E; case 0x0601B220u: goto L_0601B220; case 0x0601B222u: goto L_0601B222; case 0x0601B224u: goto L_0601B224; case 0x0601B228u: goto L_0601B228; case 0x0601B22Au: goto L_0601B22A; case 0x0601B22Eu: goto L_0601B22E; case 0x0601B260u: goto L_0601B260; case 0x0601B262u: goto L_0601B262; case 0x0601B264u: goto L_0601B264; case 0x0601B266u: goto L_0601B266; case 0x0601B268u: goto L_0601B268; case 0x0601B26Au: goto L_0601B26A; case 0x0601B26Cu: goto L_0601B26C; case 0x0601B26Eu: goto L_0601B26E; case 0x0601B270u: goto L_0601B270; case 0x0601B272u: goto L_0601B272; case 0x0601B274u: goto L_0601B274; case 0x0601B276u: goto L_0601B276; case 0x0601B278u: goto L_0601B278; case 0x0601B27Au: goto L_0601B27A; case 0x0601B27Cu: goto L_0601B27C; case 0x0601B27Eu: goto L_0601B27E; case 0x0601B280u: goto L_0601B280; case 0x0601B284u: goto L_0601B284; case 0x0601B286u: goto L_0601B286; case 0x0601B288u: goto L_0601B288; case 0x0601B28Au: goto L_0601B28A; case 0x0601B28Cu: goto L_0601B28C; case 0x0601B28Eu: goto L_0601B28E; case 0x0601B290u: goto L_0601B290; case 0x0601B292u: goto L_0601B292; case 0x0601B296u: goto L_0601B296; case 0x0601B298u: goto L_0601B298; case 0x0601B29Au: goto L_0601B29A; case 0x0601B29Eu: goto L_0601B29E; case 0x0601B2A0u: goto L_0601B2A0; case 0x0601B2A2u: goto L_0601B2A2; case 0x0601B2A4u: goto L_0601B2A4; case 0x0601B2A6u: goto L_0601B2A6; case 0x0601B2A8u: goto L_0601B2A8; case 0x0601B2AAu: goto L_0601B2AA; case 0x0601B2ACu: goto L_0601B2AC; case 0x0601B2AEu: goto L_0601B2AE; case 0x0601B2B0u: goto L_0601B2B0; case 0x0601B2B4u: goto L_0601B2B4; case 0x0601B2B8u: goto L_0601B2B8; case 0x0601B2BAu: goto L_0601B2BA; case 0x0601B2BCu: goto L_0601B2BC; case 0x0601B2BEu: goto L_0601B2BE; case 0x0601B2C0u: goto L_0601B2C0; case 0x0601B2C2u: goto L_0601B2C2; case 0x0601B2C4u: goto L_0601B2C4; case 0x0601B2C6u: goto L_0601B2C6; case 0x0601B2C8u: goto L_0601B2C8; case 0x0601B2CAu: goto L_0601B2CA; case 0x0601B2CCu: goto L_0601B2CC; case 0x0601B2CEu: goto L_0601B2CE; case 0x0601B2D0u: goto L_0601B2D0; case 0x0601B2D2u: goto L_0601B2D2; case 0x0601B2D4u: goto L_0601B2D4; case 0x0601B2D6u: goto L_0601B2D6; case 0x0601B2D8u: goto L_0601B2D8; case 0x0601B2DAu: goto L_0601B2DA; case 0x0601B2DEu: goto L_0601B2DE; case 0x0601B2E0u: goto L_0601B2E0; case 0x0601B2E2u: goto L_0601B2E2; case 0x0601B2E4u: goto L_0601B2E4; case 0x0601B2E6u: goto L_0601B2E6; case 0x0601B2E8u: goto L_0601B2E8; case 0x0601B2EAu: goto L_0601B2EA; case 0x0601B2ECu: goto L_0601B2EC; case 0x0601B2EEu: goto L_0601B2EE; case 0x0601B2F0u: goto L_0601B2F0; case 0x0601B2F2u: goto L_0601B2F2; case 0x0601B2F4u: goto L_0601B2F4; case 0x0601B2F6u: goto L_0601B2F6; case 0x0601B2F8u: goto L_0601B2F8; case 0x0601B2FAu: goto L_0601B2FA; case 0x0601B2FCu: goto L_0601B2FC; case 0x0601B2FEu: goto L_0601B2FE; case 0x0601B300u: goto L_0601B300; case 0x0601B302u: goto L_0601B302; case 0x0601B306u: goto L_0601B306; case 0x0601B308u: goto L_0601B308; case 0x0601B30Au: goto L_0601B30A; case 0x0601B30Cu: goto L_0601B30C; case 0x0601B30Eu: goto L_0601B30E; case 0x0601B312u: goto L_0601B312; case 0x0601B314u: goto L_0601B314; case 0x0601B316u: goto L_0601B316; case 0x0601B318u: goto L_0601B318; case 0x0601B31Au: goto L_0601B31A; case 0x0601B31Cu: goto L_0601B31C; case 0x0601B320u: goto L_0601B320; case 0x0601B322u: goto L_0601B322; case 0x0601B324u: goto L_0601B324; case 0x0601B326u: goto L_0601B326; case 0x0601B328u: goto L_0601B328; case 0x0601B32Cu: goto L_0601B32C; case 0x0601B32Eu: goto L_0601B32E; case 0x0601B330u: goto L_0601B330; case 0x0601B332u: goto L_0601B332; case 0x0601B334u: goto L_0601B334; case 0x0601B336u: goto L_0601B336; case 0x0601B338u: goto L_0601B338; case 0x0601B33Au: goto L_0601B33A; case 0x0601B33Cu: goto L_0601B33C; case 0x0601B340u: goto L_0601B340; case 0x0601B342u: goto L_0601B342; case 0x0601B346u: goto L_0601B346; case 0x0601B348u: goto L_0601B348; case 0x0601B34Au: goto L_0601B34A; case 0x0601B34Eu: goto L_0601B34E; case 0x0601B350u: goto L_0601B350; case 0x0601B352u: goto L_0601B352; case 0x0601B354u: goto L_0601B354; case 0x0601B356u: goto L_0601B356; case 0x0601B358u: goto L_0601B358; case 0x0601B35Au: goto L_0601B35A; case 0x0601B35Cu: goto L_0601B35C; case 0x0601B35Eu: goto L_0601B35E; case 0x0601B360u: goto L_0601B360; case 0x0601B362u: goto L_0601B362; case 0x0601B364u: goto L_0601B364; case 0x0601B366u: goto L_0601B366; case 0x0601B368u: goto L_0601B368; case 0x0601B36Au: goto L_0601B36A; case 0x0601B36Cu: goto L_0601B36C; case 0x0601B36Eu: goto L_0601B36E; case 0x0601B370u: goto L_0601B370; case 0x0601B372u: goto L_0601B372; case 0x0601B374u: goto L_0601B374; case 0x0601B376u: goto L_0601B376; case 0x0601B378u: goto L_0601B378; case 0x0601B37Au: goto L_0601B37A; case 0x0601B37Eu: goto L_0601B37E; case 0x0601B380u: goto L_0601B380; case 0x0601B382u: goto L_0601B382; case 0x0601B384u: goto L_0601B384; case 0x0601B386u: goto L_0601B386; case 0x0601B388u: goto L_0601B388; case 0x0601B38Au: goto L_0601B38A; case 0x0601B38Cu: goto L_0601B38C; case 0x0601B38Eu: goto L_0601B38E; case 0x0601B392u: goto L_0601B392; case 0x0601B394u: goto L_0601B394; case 0x0601B398u: goto L_0601B398; case 0x0601B39Cu: goto L_0601B39C; case 0x0601B39Eu: goto L_0601B39E; case 0x0601B3A0u: goto L_0601B3A0; case 0x0601B3A2u: goto L_0601B3A2; case 0x0601B3A4u: goto L_0601B3A4; case 0x0601B3A6u: goto L_0601B3A6; case 0x0601B3A8u: goto L_0601B3A8; case 0x0601B3AAu: goto L_0601B3AA; case 0x0601B3ACu: goto L_0601B3AC; case 0x0601B3AEu: goto L_0601B3AE; case 0x0601B3B0u: goto L_0601B3B0; case 0x0601B3B2u: goto L_0601B3B2; case 0x0601B3B4u: goto L_0601B3B4; case 0x0601B3B6u: goto L_0601B3B6; case 0x0601B3B8u: goto L_0601B3B8; case 0x0601B3BAu: goto L_0601B3BA; case 0x0601B3BCu: goto L_0601B3BC; case 0x0601B3BEu: goto L_0601B3BE; case 0x0601B3C0u: goto L_0601B3C0; case 0x0601B3C2u: goto L_0601B3C2; case 0x0601B3C4u: goto L_0601B3C4; case 0x0601B3C6u: goto L_0601B3C6; case 0x0601B3C8u: goto L_0601B3C8; case 0x0601B3CAu: goto L_0601B3CA; case 0x0601B3CCu: goto L_0601B3CC; case 0x0601B3CEu: goto L_0601B3CE; case 0x0601B3D0u: goto L_0601B3D0; case 0x0601B3D2u: goto L_0601B3D2; case 0x0601B3D4u: goto L_0601B3D4; case 0x0601B3D6u: goto L_0601B3D6; case 0x0601B3D8u: goto L_0601B3D8; case 0x0601B3DAu: goto L_0601B3DA; case 0x0601B3DCu: goto L_0601B3DC; case 0x0601B3DEu: goto L_0601B3DE; case 0x0601B3E0u: goto L_0601B3E0; case 0x0601B3E2u: goto L_0601B3E2; case 0x0601B3E4u: goto L_0601B3E4; case 0x0601B3E6u: goto L_0601B3E6; case 0x0601B3E8u: goto L_0601B3E8; case 0x0601B3EAu: goto L_0601B3EA; case 0x0601B3ECu: goto L_0601B3EC; case 0x0601B3EEu: goto L_0601B3EE; case 0x0601B3F2u: goto L_0601B3F2; case 0x0601B3F4u: goto L_0601B3F4; case 0x0601B3F6u: goto L_0601B3F6; case 0x0601B3FAu: goto L_0601B3FA; case 0x0601B3FCu: goto L_0601B3FC; case 0x0601B3FEu: goto L_0601B3FE; case 0x0601B400u: goto L_0601B400; case 0x0601B402u: goto L_0601B402; case 0x0601B406u: goto L_0601B406; case 0x0601B408u: goto L_0601B408; case 0x0601B40Au: goto L_0601B40A; case 0x0601B40Cu: goto L_0601B40C; case 0x0601B410u: goto L_0601B410; case 0x0601B412u: goto L_0601B412; case 0x0601B414u: goto L_0601B414; case 0x0601B416u: goto L_0601B416; case 0x0601B418u: goto L_0601B418; case 0x0601B41Au: goto L_0601B41A; case 0x0601B41Cu: goto L_0601B41C; case 0x0601B41Eu: goto L_0601B41E; case 0x0601B420u: goto L_0601B420; case 0x0601B424u: goto L_0601B424; case 0x0601B426u: goto L_0601B426; case 0x0601B428u: goto L_0601B428; case 0x0601B42Au: goto L_0601B42A; case 0x0601B42Cu: goto L_0601B42C; case 0x0601B42Eu: goto L_0601B42E; case 0x0601B430u: goto L_0601B430; case 0x0601B458u: goto L_0601B458; case 0x0601B45Au: goto L_0601B45A; case 0x0601B45Cu: goto L_0601B45C; case 0x0601B45Eu: goto L_0601B45E; case 0x0601B460u: goto L_0601B460; case 0x0601B462u: goto L_0601B462; case 0x0601B464u: goto L_0601B464; case 0x0601B466u: goto L_0601B466; case 0x0601B46Au: goto L_0601B46A; case 0x0601B46Cu: goto L_0601B46C; case 0x0601B470u: goto L_0601B470; case 0x0601B472u: goto L_0601B472; case 0x0601B474u: goto L_0601B474; case 0x0601B476u: goto L_0601B476; case 0x0601B478u: goto L_0601B478; case 0x0601B47Au: goto L_0601B47A; case 0x0601B47Cu: goto L_0601B47C; case 0x0601B47Eu: goto L_0601B47E; case 0x0601B480u: goto L_0601B480; case 0x0601B482u: goto L_0601B482; case 0x0601B486u: goto L_0601B486; case 0x0601B488u: goto L_0601B488; case 0x0601B48Au: goto L_0601B48A; case 0x0601B48Cu: goto L_0601B48C; case 0x0601B48Eu: goto L_0601B48E; case 0x0601B490u: goto L_0601B490; case 0x0601B492u: goto L_0601B492; case 0x0601B494u: goto L_0601B494; case 0x0601B496u: goto L_0601B496; case 0x0601B49Au: goto L_0601B49A; case 0x0601B49Cu: goto L_0601B49C; case 0x0601B49Eu: goto L_0601B49E; case 0x0601B4A2u: goto L_0601B4A2; case 0x0601B4A4u: goto L_0601B4A4; case 0x0601B4A6u: goto L_0601B4A6; case 0x0601B4AAu: goto L_0601B4AA; case 0x0601B4ACu: goto L_0601B4AC; case 0x0601B4AEu: goto L_0601B4AE; case 0x0601B4B0u: goto L_0601B4B0; case 0x0601B4B2u: goto L_0601B4B2; case 0x0601B4B4u: goto L_0601B4B4; case 0x0601B4B6u: goto L_0601B4B6; case 0x0601B4B8u: goto L_0601B4B8; case 0x0601B4BAu: goto L_0601B4BA; case 0x0601B4BCu: goto L_0601B4BC; case 0x0601B4BEu: goto L_0601B4BE; case 0x0601B4C0u: goto L_0601B4C0; case 0x0601B4C2u: goto L_0601B4C2; case 0x0601B4C4u: goto L_0601B4C4; case 0x0601B4C6u: goto L_0601B4C6; case 0x0601B4C8u: goto L_0601B4C8; case 0x0601B4CAu: goto L_0601B4CA; case 0x0601B4CCu: goto L_0601B4CC; case 0x0601B4CEu: goto L_0601B4CE; case 0x0601B4D0u: goto L_0601B4D0; case 0x0601B4D2u: goto L_0601B4D2; case 0x0601B4D6u: goto L_0601B4D6; case 0x0601B4D8u: goto L_0601B4D8; case 0x0601B4DAu: goto L_0601B4DA; case 0x0601B4DCu: goto L_0601B4DC; case 0x0601B4DEu: goto L_0601B4DE; case 0x0601B4E0u: goto L_0601B4E0; case 0x0601B4E2u: goto L_0601B4E2; case 0x0601B4E4u: goto L_0601B4E4; case 0x0601B4E6u: goto L_0601B4E6; case 0x0601B4EAu: goto L_0601B4EA; case 0x0601B4ECu: goto L_0601B4EC; case 0x0601B4F0u: goto L_0601B4F0; case 0x0601B4F4u: goto L_0601B4F4; case 0x0601B4F6u: goto L_0601B4F6; case 0x0601B4F8u: goto L_0601B4F8; case 0x0601B4FAu: goto L_0601B4FA; case 0x0601B4FCu: goto L_0601B4FC; case 0x0601B4FEu: goto L_0601B4FE; case 0x0601B500u: goto L_0601B500; case 0x0601B502u: goto L_0601B502; case 0x0601B504u: goto L_0601B504; case 0x0601B506u: goto L_0601B506; case 0x0601B508u: goto L_0601B508; case 0x0601B50Au: goto L_0601B50A; case 0x0601B50Cu: goto L_0601B50C; case 0x0601B50Eu: goto L_0601B50E; case 0x0601B510u: goto L_0601B510; case 0x0601B512u: goto L_0601B512; case 0x0601B516u: goto L_0601B516; case 0x0601B51Au: goto L_0601B51A; case 0x0601B51Cu: goto L_0601B51C; case 0x0601B51Eu: goto L_0601B51E; case 0x0601B520u: goto L_0601B520; case 0x0601B522u: goto L_0601B522; case 0x0601B524u: goto L_0601B524; case 0x0601B526u: goto L_0601B526; case 0x0601B528u: goto L_0601B528; case 0x0601B52Au: goto L_0601B52A; case 0x0601B52Cu: goto L_0601B52C; case 0x0601B530u: goto L_0601B530; case 0x0601B532u: goto L_0601B532; case 0x0601B534u: goto L_0601B534; case 0x0601B536u: goto L_0601B536; case 0x0601B538u: goto L_0601B538; case 0x0601B53Au: goto L_0601B53A; case 0x0601B53Cu: goto L_0601B53C; case 0x0601B53Eu: goto L_0601B53E; case 0x0601B540u: goto L_0601B540; case 0x0601B542u: goto L_0601B542; case 0x0601B544u: goto L_0601B544; case 0x0601B546u: goto L_0601B546; case 0x0601B548u: goto L_0601B548; case 0x0601B54Au: goto L_0601B54A; case 0x0601B54Cu: goto L_0601B54C; case 0x0601B54Eu: goto L_0601B54E; case 0x0601B550u: goto L_0601B550; case 0x0601B552u: goto L_0601B552; case 0x0601B554u: goto L_0601B554; case 0x0601B556u: goto L_0601B556; case 0x0601B558u: goto L_0601B558; case 0x0601B57Cu: goto L_0601B57C; case 0x0601B57Eu: goto L_0601B57E; case 0x0601B580u: goto L_0601B580; case 0x0601B582u: goto L_0601B582; case 0x0601B584u: goto L_0601B584; case 0x0601B586u: goto L_0601B586; case 0x0601B588u: goto L_0601B588; case 0x0601B58Au: goto L_0601B58A; case 0x0601B58Cu: goto L_0601B58C; case 0x0601B58Eu: goto L_0601B58E; case 0x0601B590u: goto L_0601B590; case 0x0601B592u: goto L_0601B592; case 0x0601B594u: goto L_0601B594; case 0x0601B596u: goto L_0601B596; case 0x0601B598u: goto L_0601B598; case 0x0601B59Au: goto L_0601B59A; case 0x0601B59Cu: goto L_0601B59C; case 0x0601B59Eu: goto L_0601B59E; case 0x0601B5A0u: goto L_0601B5A0; case 0x0601B5A4u: goto L_0601B5A4; case 0x0601B5A6u: goto L_0601B5A6; case 0x0601B5A8u: goto L_0601B5A8; case 0x0601B5AAu: goto L_0601B5AA; case 0x0601B5ACu: goto L_0601B5AC; case 0x0601B5B0u: goto L_0601B5B0; case 0x0601B5B2u: goto L_0601B5B2; case 0x0601B5B4u: goto L_0601B5B4; case 0x0601B5B6u: goto L_0601B5B6; case 0x0601B5B8u: goto L_0601B5B8; case 0x0601B5BAu: goto L_0601B5BA; case 0x0601B5BEu: goto L_0601B5BE; case 0x0601B5C0u: goto L_0601B5C0; case 0x0601B5C2u: goto L_0601B5C2; case 0x0601B5C4u: goto L_0601B5C4; case 0x0601B5C6u: goto L_0601B5C6; case 0x0601B5C8u: goto L_0601B5C8; case 0x0601B5CAu: goto L_0601B5CA; case 0x0601B5CCu: goto L_0601B5CC; case 0x0601B5CEu: goto L_0601B5CE; case 0x0601B5D0u: goto L_0601B5D0; case 0x0601B5D2u: goto L_0601B5D2; case 0x0601B5D4u: goto L_0601B5D4; case 0x0601B5D6u: goto L_0601B5D6; case 0x0601B5D8u: goto L_0601B5D8; case 0x0601B5DAu: goto L_0601B5DA; case 0x0601B5DCu: goto L_0601B5DC; case 0x0601B5DEu: goto L_0601B5DE; case 0x0601B5E2u: goto L_0601B5E2; case 0x0601B5E4u: goto L_0601B5E4; case 0x0601B5E6u: goto L_0601B5E6; case 0x0601B5E8u: goto L_0601B5E8; case 0x0601B5EAu: goto L_0601B5EA; case 0x0601B5ECu: goto L_0601B5EC; case 0x0601B5EEu: goto L_0601B5EE; case 0x0601B5F0u: goto L_0601B5F0; case 0x0601B5F2u: goto L_0601B5F2; case 0x0601B5F4u: goto L_0601B5F4; case 0x0601B5F6u: goto L_0601B5F6; case 0x0601B5F8u: goto L_0601B5F8; case 0x0601B5FAu: goto L_0601B5FA; case 0x0601B5FCu: goto L_0601B5FC; case 0x0601B5FEu: goto L_0601B5FE; case 0x0601B602u: goto L_0601B602; case 0x0601B604u: goto L_0601B604; case 0x0601B608u: goto L_0601B608; case 0x0601B60Cu: goto L_0601B60C; case 0x0601B60Eu: goto L_0601B60E; case 0x0601B610u: goto L_0601B610; case 0x0601B612u: goto L_0601B612; case 0x0601B614u: goto L_0601B614; case 0x0601B616u: goto L_0601B616; case 0x0601B618u: goto L_0601B618; case 0x0601B61Au: goto L_0601B61A; case 0x0601B61Cu: goto L_0601B61C; case 0x0601B61Eu: goto L_0601B61E; case 0x0601B620u: goto L_0601B620; case 0x0601B622u: goto L_0601B622; case 0x0601B624u: goto L_0601B624; case 0x0601B626u: goto L_0601B626; case 0x0601B628u: goto L_0601B628; case 0x0601B62Au: goto L_0601B62A; case 0x0601B62Cu: goto L_0601B62C; case 0x0601B62Eu: goto L_0601B62E; case 0x0601B630u: goto L_0601B630; case 0x0601B632u: goto L_0601B632; case 0x0601B634u: goto L_0601B634; case 0x0601B636u: goto L_0601B636; case 0x0601B638u: goto L_0601B638; case 0x0601B63Au: goto L_0601B63A; case 0x0601B63Cu: goto L_0601B63C; case 0x0601B63Eu: goto L_0601B63E; case 0x0601B640u: goto L_0601B640; case 0x0601B642u: goto L_0601B642; case 0x0601B644u: goto L_0601B644; case 0x0601B646u: goto L_0601B646; case 0x0601B648u: goto L_0601B648; case 0x0601B64Au: goto L_0601B64A; case 0x0601B64Cu: goto L_0601B64C; case 0x0601B64Eu: goto L_0601B64E; case 0x0601B650u: goto L_0601B650; case 0x0601B652u: goto L_0601B652; case 0x0601B654u: goto L_0601B654; case 0x0601B656u: goto L_0601B656; case 0x0601B658u: goto L_0601B658; case 0x0601B65Au: goto L_0601B65A; case 0x0601B65Cu: goto L_0601B65C; case 0x0601B65Eu: goto L_0601B65E; case 0x0601B660u: goto L_0601B660; case 0x0601B664u: goto L_0601B664; case 0x0601B666u: goto L_0601B666; case 0x0601B66Au: goto L_0601B66A; case 0x0601B66Cu: goto L_0601B66C; case 0x0601B66Eu: goto L_0601B66E; case 0x0601B670u: goto L_0601B670; case 0x0601B672u: goto L_0601B672; case 0x0601B674u: goto L_0601B674; case 0x0601B676u: goto L_0601B676; case 0x0601B678u: goto L_0601B678; case 0x0601B67Au: goto L_0601B67A; case 0x0601B67Eu: goto L_0601B67E; case 0x0601B682u: goto L_0601B682; case 0x0601B684u: goto L_0601B684; case 0x0601B688u: goto L_0601B688; case 0x0601B68Au: goto L_0601B68A; case 0x0601B68Cu: goto L_0601B68C; case 0x0601B68Eu: goto L_0601B68E; case 0x0601B690u: goto L_0601B690; case 0x0601B692u: goto L_0601B692; case 0x0601B696u: goto L_0601B696; case 0x0601B698u: goto L_0601B698; case 0x0601B69Au: goto L_0601B69A; case 0x0601B69Cu: goto L_0601B69C; case 0x0601B69Eu: goto L_0601B69E; case 0x0601B6A0u: goto L_0601B6A0; case 0x0601B6A4u: goto L_0601B6A4; case 0x0601B6A6u: goto L_0601B6A6; case 0x0601B6A8u: goto L_0601B6A8; case 0x0601B6AAu: goto L_0601B6AA; case 0x0601B6ACu: goto L_0601B6AC; case 0x0601B6AEu: goto L_0601B6AE; case 0x0601B6B0u: goto L_0601B6B0; case 0x0601B6B2u: goto L_0601B6B2; case 0x0601B6B4u: goto L_0601B6B4; case 0x0601B6B6u: goto L_0601B6B6; case 0x0601B6B8u: goto L_0601B6B8; case 0x0601B6BAu: goto L_0601B6BA; case 0x0601B6BCu: goto L_0601B6BC; case 0x0601B6BEu: goto L_0601B6BE; case 0x0601B6C0u: goto L_0601B6C0; case 0x0601B6C2u: goto L_0601B6C2; case 0x0601B6C4u: goto L_0601B6C4; case 0x0601B6C8u: goto L_0601B6C8; case 0x0601B6CAu: goto L_0601B6CA; case 0x0601B6CEu: goto L_0601B6CE; case 0x0601B6D0u: goto L_0601B6D0; case 0x0601B6D2u: goto L_0601B6D2; case 0x0601B6D4u: goto L_0601B6D4; case 0x0601B6D6u: goto L_0601B6D6; case 0x0601B6D8u: goto L_0601B6D8; case 0x0601B6DAu: goto L_0601B6DA; case 0x0601B6DCu: goto L_0601B6DC; case 0x0601B6DEu: goto L_0601B6DE; case 0x0601B6E0u: goto L_0601B6E0; case 0x0607EB7Cu: goto L_0607EB7C; case 0x0607EB7Eu: goto L_0607EB7E; case 0x0607EB80u: goto L_0607EB80; case 0x0607EB82u: goto L_0607EB82; case 0x0607EB84u: goto L_0607EB84; case 0x0607EB86u: goto L_0607EB86; case 0x0607EB88u: goto L_0607EB88; case 0x0607EB8Au: goto L_0607EB8A; case 0x0607EB8Cu: goto L_0607EB8C; case 0x0607EB8Eu: goto L_0607EB8E; case 0x0607EB90u: goto L_0607EB90; case 0x0607EB92u: goto L_0607EB92; case 0x0607EB94u: goto L_0607EB94; case 0x0607EB96u: goto L_0607EB96; case 0x0607EB98u: goto L_0607EB98; case 0x0607EB9Au: goto L_0607EB9A; case 0x0607EB9Cu: goto L_0607EB9C; case 0x0607EB9Eu: goto L_0607EB9E; case 0x0607EBA0u: goto L_0607EBA0; case 0x0607EBA2u: goto L_0607EBA2; case 0x0607EBA4u: goto L_0607EBA4; case 0x0607EBA6u: goto L_0607EBA6; case 0x0607EBA8u: goto L_0607EBA8; case 0x0607EBAAu: goto L_0607EBAA; case 0x0607EBACu: goto L_0607EBAC; case 0x0607EBAEu: goto L_0607EBAE; case 0x0607EBB0u: goto L_0607EBB0; case 0x0607EBB2u: goto L_0607EBB2; case 0x0607EBB4u: goto L_0607EBB4; case 0x0607EBB6u: goto L_0607EBB6; case 0x0607EBBAu: goto L_0607EBBA; case 0x0607EBBCu: goto L_0607EBBC; case 0x0607EBBEu: goto L_0607EBBE; case 0x0607EBC2u: goto L_0607EBC2; case 0x0607EBC4u: goto L_0607EBC4; case 0x0607EBC6u: goto L_0607EBC6; case 0x0607EBC8u: goto L_0607EBC8; case 0x0607EBCAu: goto L_0607EBCA; case 0x0607EBCCu: goto L_0607EBCC; case 0x0607EBD0u: goto L_0607EBD0; case 0x0607EBD2u: goto L_0607EBD2; case 0x0607EBD4u: goto L_0607EBD4; case 0x0607EBD6u: goto L_0607EBD6; case 0x0607EBD8u: goto L_0607EBD8; case 0x0607EBDAu: goto L_0607EBDA; case 0x0607EBDCu: goto L_0607EBDC; case 0x0607EBDEu: goto L_0607EBDE; case 0x0607EBE0u: goto L_0607EBE0; case 0x0607EBE2u: goto L_0607EBE2; case 0x0607EBE4u: goto L_0607EBE4; case 0x0607EBE6u: goto L_0607EBE6; case 0x0607EBE8u: goto L_0607EBE8; case 0x0607EBEAu: goto L_0607EBEA; case 0x0607EBECu: goto L_0607EBEC; case 0x0607EBEEu: goto L_0607EBEE; case 0x0607EBF0u: goto L_0607EBF0; case 0x0607EBF2u: goto L_0607EBF2; case 0x0607EBF4u: goto L_0607EBF4; case 0x0607EBF6u: goto L_0607EBF6; case 0x0607EBF8u: goto L_0607EBF8; case 0x0607EBFCu: goto L_0607EBFC; case 0x0607EBFEu: goto L_0607EBFE; case 0x0607EC02u: goto L_0607EC02; case 0x0607EC04u: goto L_0607EC04; case 0x0607EC06u: goto L_0607EC06; case 0x0607EC08u: goto L_0607EC08; case 0x0607EC0Au: goto L_0607EC0A; case 0x0607EC0Cu: goto L_0607EC0C; case 0x0607EC0Eu: goto L_0607EC0E; case 0x0607EC10u: goto L_0607EC10; case 0x0607EC12u: goto L_0607EC12; case 0x0607EC14u: goto L_0607EC14; case 0x0607EC16u: goto L_0607EC16; case 0x0607EC18u: goto L_0607EC18; case 0x0607EC1Au: goto L_0607EC1A; case 0x0607EC1Cu: goto L_0607EC1C; case 0x0607EC1Eu: goto L_0607EC1E; case 0x0607EC20u: goto L_0607EC20; case 0x0607EC22u: goto L_0607EC22; case 0x0607EC26u: goto L_0607EC26; case 0x0607EC28u: goto L_0607EC28; case 0x0607EC2Au: goto L_0607EC2A; case 0x0607EC2Cu: goto L_0607EC2C; case 0x0607EC2Eu: goto L_0607EC2E; case 0x0607EC30u: goto L_0607EC30; case 0x0607EC32u: goto L_0607EC32; case 0x0607EC34u: goto L_0607EC34; case 0x0607EC36u: goto L_0607EC36; case 0x0607EC38u: goto L_0607EC38; case 0x0607EC3Au: goto L_0607EC3A; case 0x0607EC3Cu: goto L_0607EC3C; case 0x0607EC3Eu: goto L_0607EC3E; case 0x0607EC40u: goto L_0607EC40; case 0x0607EC42u: goto L_0607EC42; case 0x0607EC44u: goto L_0607EC44; case 0x0607EC46u: goto L_0607EC46; case 0x0607EC48u: goto L_0607EC48; case 0x0607EC4Au: goto L_0607EC4A; case 0x0607EC4Cu: goto L_0607EC4C; case 0x0607EC50u: goto L_0607EC50; case 0x0607EC52u: goto L_0607EC52; case 0x0607EC54u: goto L_0607EC54; case 0x0607EC56u: goto L_0607EC56; case 0x0607EC58u: goto L_0607EC58; case 0x0607EC5Au: goto L_0607EC5A; case 0x0607EC5Cu: goto L_0607EC5C; case 0x0607EC5Eu: goto L_0607EC5E; case 0x0607EC60u: goto L_0607EC60; case 0x0607EC64u: goto L_0607EC64; case 0x0607EC66u: goto L_0607EC66; case 0x0607EC68u: goto L_0607EC68; case 0x0607EC6Au: goto L_0607EC6A; case 0x0607EC6Cu: goto L_0607EC6C; case 0x0607EC6Eu: goto L_0607EC6E; case 0x0607EC70u: goto L_0607EC70; case 0x0607EC74u: goto L_0607EC74; case 0x0607EC76u: goto L_0607EC76; case 0x0607EC78u: goto L_0607EC78; case 0x0607EC7Au: goto L_0607EC7A; case 0x0607EC7Cu: goto L_0607EC7C; case 0x0607EC7Eu: goto L_0607EC7E; case 0x0607EC80u: goto L_0607EC80; case 0x0607EC82u: goto L_0607EC82; case 0x0607EC84u: goto L_0607EC84; case 0x0607EC86u: goto L_0607EC86; case 0x0607EC88u: goto L_0607EC88; case 0x0607EC8Au: goto L_0607EC8A; case 0x0607EC8Cu: goto L_0607EC8C; case 0x0607EC8Eu: goto L_0607EC8E; case 0x0607EC90u: goto L_0607EC90; case 0x0607EC92u: goto L_0607EC92; case 0x0607EC94u: goto L_0607EC94; case 0x0607EC96u: goto L_0607EC96; case 0x0607EC98u: goto L_0607EC98; case 0x0607EC9Au: goto L_0607EC9A; case 0x0607EC9Cu: goto L_0607EC9C; case 0x0607EC9Eu: goto L_0607EC9E; case 0x0607ECA0u: goto L_0607ECA0; case 0x0607ECA2u: goto L_0607ECA2; case 0x0607ECA4u: goto L_0607ECA4; case 0x0607ECA8u: goto L_0607ECA8; case 0x0607ECAAu: goto L_0607ECAA; case 0x0607ECACu: goto L_0607ECAC; case 0x0607ECAEu: goto L_0607ECAE; case 0x0607ECB0u: goto L_0607ECB0; case 0x0607ECB2u: goto L_0607ECB2; case 0x0607ECB4u: goto L_0607ECB4; case 0x0607ECB6u: goto L_0607ECB6; case 0x0607ECB8u: goto L_0607ECB8; case 0x0607ECBAu: goto L_0607ECBA; case 0x0607ECBCu: goto L_0607ECBC; case 0x0607ECBEu: goto L_0607ECBE; case 0x0607ECC0u: goto L_0607ECC0; case 0x0607ECC2u: goto L_0607ECC2; case 0x0607ECC4u: goto L_0607ECC4; case 0x0607ECC6u: goto L_0607ECC6; case 0x0607ECC8u: goto L_0607ECC8; case 0x0607ECCAu: goto L_0607ECCA; case 0x0607ECCCu: goto L_0607ECCC; case 0x0607ECCEu: goto L_0607ECCE; case 0x0607ECD0u: goto L_0607ECD0; case 0x0607ECD2u: goto L_0607ECD2; case 0x0607ECD6u: goto L_0607ECD6; case 0x0607ECD8u: goto L_0607ECD8; case 0x0607ECDAu: goto L_0607ECDA; case 0x0607ECDCu: goto L_0607ECDC; case 0x0607ECDEu: goto L_0607ECDE; case 0x0607ECE0u: goto L_0607ECE0; case 0x0607ECE4u: goto L_0607ECE4; case 0x0607ECE8u: goto L_0607ECE8; case 0x0607ECEAu: goto L_0607ECEA; case 0x0607EE54u: goto L_0607EE54; case 0x0607EE56u: goto L_0607EE56; case 0x0607EE58u: goto L_0607EE58; case 0x0607EE5Au: goto L_0607EE5A; case 0x0607EE5Cu: goto L_0607EE5C; case 0x0607EE5Eu: goto L_0607EE5E; case 0x0607EE60u: goto L_0607EE60; case 0x0607EE62u: goto L_0607EE62; case 0x0608431Eu: goto L_0608431E; case 0x06084320u: goto L_06084320; case 0x06084322u: goto L_06084322; case 0x06084324u: goto L_06084324; case 0x06084326u: goto L_06084326; case 0x06084328u: goto L_06084328; case 0x0608432Au: goto L_0608432A; case 0x0608432Cu: goto L_0608432C; case 0x06084330u: goto L_06084330; case 0x06084332u: goto L_06084332; case 0x06084334u: goto L_06084334; case 0x06084336u: goto L_06084336; case 0x06084338u: goto L_06084338; case 0x0608433Au: goto L_0608433A; case 0x0608433Cu: goto L_0608433C; case 0x0608433Eu: goto L_0608433E; case 0x06084340u: goto L_06084340; case 0x06084342u: goto L_06084342; case 0x06084344u: goto L_06084344; case 0x06084346u: goto L_06084346; case 0x06084348u: goto L_06084348; case 0x0608434Au: goto L_0608434A; case 0x0608434Cu: goto L_0608434C; case 0x0608434Eu: goto L_0608434E; case 0x06084350u: goto L_06084350; case 0x06084352u: goto L_06084352; case 0x06084354u: goto L_06084354; case 0x06084356u: goto L_06084356; case 0x06084358u: goto L_06084358; case 0x0608435Au: goto L_0608435A; case 0x0608435Cu: goto L_0608435C; case 0x0608435Eu: goto L_0608435E; case 0x06084362u: goto L_06084362; case 0x06084364u: goto L_06084364; default: sh2_call(c, x); return; } }  // 0607ECEA jmp @r0 ; nop
L_0607EE54:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0607EE54 lds.l @r15+,pr
L_0607EE56:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0607EE56 mov.l @r15+,r14
L_0607EE58:
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0607EE58 mov.l @r15+,r13
L_0607EE5A:
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0607EE5A mov.l @r15+,r12
L_0607EE5C:
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0607EE5C mov.l @r15+,r11
L_0607EE5E:
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0607EE5E mov.l @r15+,r10
L_0607EE60:
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0607EE60 mov.l @r15+,r9
L_0607EE62:
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0607EE62 rts ; mov.l @r15+,r8
L_0608431E:
    c.r[10] = c.r[5];  // 0608431E mov r5,r10
L_06084320:
    c.r[1] = ld32(0x06084394u);  // 06084320 mov.l 0x06084394,r1
L_06084322:
    c.r[4] = ld32(c.r[1]);  // 06084322 mov.l @r1,r4
L_06084324:
    c.r[1] = ld32(0x060843D0u);  // 06084324 mov.l 0x060843D0,r1
L_06084326:
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06084326 mov.b @r1,r5
L_06084328:
    c.r[5] = c.r[5] & 0xFFu;  // 06084328 extu.b r5,r5
L_0608432A:
    c.r[0] = ld32(0x06084390u);  // 0608432A mov.l 0x06084390,r0
L_0608432C:
    { const uint32_t x = c.r[0]; c.pr = 0x06084330u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06084330u) return; }  // 0608432C jsr @r0 ; nop
L_06084330:
    c.r[1] = ld32(0x06084384u);  // 06084330 mov.l 0x06084384,r1
L_06084332:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06084332 mov.b @r1,r1
L_06084334:
    c.r[1] = c.r[1] & 0xFFu;  // 06084334 extu.b r1,r1
L_06084336:
    c.r[1] -= c.r[0];  // 06084336 sub r0,r1
L_06084338:
    c.r[2] = ld32(0x0608439Cu);  // 06084338 mov.l 0x0608439C,r2
L_0608433A:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2] + 14);  // 0608433A mov.b @(14,r2),r0
L_0608433C:
    c.r[0] = c.r[0] & 0xFFu;  // 0608433C extu.b r0,r0
L_0608433E:
    c.r[0] += c.r[10];  // 0608433E add r10,r0
L_06084340:
    c.r[3] = 0x1u;  // 06084340 mov #1,r3
L_06084342:
    c.t = (int32_t)c.r[0] >= (int32_t)c.r[3];  // 06084342 cmp/ge r3,r0
L_06084344:
    if (!c.t) { goto L_06084362; }  // 06084344 bf 0x06084362
L_06084346:
    c.t = (int32_t)c.r[0] > (int32_t)c.r[1];  // 06084346 cmp/gt r1,r0
L_06084348:
    if (c.t) { goto L_06084362; }  // 06084348 bt 0x06084362
L_0608434A:
    c.t = (int32_t)c.r[10] > 0;  // 0608434A cmp/pl r10
L_0608434C:
    if (!c.t) { goto L_0608435A; }  // 0608434C bf 0x0608435A
L_0608434E:
    c.r[3] = ld32(0x060843C4u);  // 0608434E mov.l 0x060843C4,r3
L_06084350:
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06084350 mov.w @r3,r3
L_06084352:
    c.r[3] = c.r[3] & 0xFFFFu;  // 06084352 extu.w r3,r3
L_06084354:
    c.r[4] = (uint32_t)(int16_t)ld16(0x060843E2u);  // 06084354 mov.w 0x060843E2,r4
L_06084356:
    c.t = c.r[3] > c.r[4];  // 06084356 cmp/hi r4,r3
L_06084358:
    if (c.t) { goto L_06084362; }  // 06084358 bt 0x06084362
L_0608435A:
    st8(c.r[2] + 14, c.r[0]);  // 0608435A mov.b r0,@(14,r2)
L_0608435C:
    c.r[0] = ld32(0x060843D4u);  // 0608435C mov.l 0x060843D4,r0
L_0608435E:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x0601B114u: goto L_0601B114; case 0x0601B116u: goto L_0601B116; case 0x0601B124u: goto L_0601B124; case 0x0601B126u: goto L_0601B126; case 0x0601B128u: goto L_0601B128; case 0x0601B12Au: goto L_0601B12A; case 0x0601B12Cu: goto L_0601B12C; case 0x0601B12Eu: goto L_0601B12E; case 0x0601B130u: goto L_0601B130; case 0x0601B132u: goto L_0601B132; case 0x0601B134u: goto L_0601B134; case 0x0601B136u: goto L_0601B136; case 0x0601B138u: goto L_0601B138; case 0x0601B13Au: goto L_0601B13A; case 0x0601B13Eu: goto L_0601B13E; case 0x0601B140u: goto L_0601B140; case 0x0601B144u: goto L_0601B144; case 0x0601B146u: goto L_0601B146; case 0x0601B148u: goto L_0601B148; case 0x0601B14Au: goto L_0601B14A; case 0x0601B14Cu: goto L_0601B14C; case 0x0601B14Eu: goto L_0601B14E; case 0x0601B150u: goto L_0601B150; case 0x0601B152u: goto L_0601B152; case 0x0601B156u: goto L_0601B156; case 0x0601B158u: goto L_0601B158; case 0x0601B15Au: goto L_0601B15A; case 0x0601B15Cu: goto L_0601B15C; case 0x0601B15Eu: goto L_0601B15E; case 0x0601B162u: goto L_0601B162; case 0x0601B164u: goto L_0601B164; case 0x0601B166u: goto L_0601B166; case 0x0601B168u: goto L_0601B168; case 0x0601B16Au: goto L_0601B16A; case 0x0601B16Cu: goto L_0601B16C; case 0x0601B16Eu: goto L_0601B16E; case 0x0601B170u: goto L_0601B170; case 0x0601B172u: goto L_0601B172; case 0x0601B176u: goto L_0601B176; case 0x0601B178u: goto L_0601B178; case 0x0601B17Au: goto L_0601B17A; case 0x0601B17Cu: goto L_0601B17C; case 0x0601B17Eu: goto L_0601B17E; case 0x0601B180u: goto L_0601B180; case 0x0601B182u: goto L_0601B182; case 0x0601B184u: goto L_0601B184; case 0x0601B188u: goto L_0601B188; case 0x0601B18Au: goto L_0601B18A; case 0x0601B18Cu: goto L_0601B18C; case 0x0601B190u: goto L_0601B190; case 0x0601B194u: goto L_0601B194; case 0x0601B196u: goto L_0601B196; case 0x0601B198u: goto L_0601B198; case 0x0601B19Au: goto L_0601B19A; case 0x0601B19Cu: goto L_0601B19C; case 0x0601B19Eu: goto L_0601B19E; case 0x0601B1A0u: goto L_0601B1A0; case 0x0601B1A2u: goto L_0601B1A2; case 0x0601B1A4u: goto L_0601B1A4; case 0x0601B1A6u: goto L_0601B1A6; case 0x0601B1A8u: goto L_0601B1A8; case 0x0601B1AAu: goto L_0601B1AA; case 0x0601B1ACu: goto L_0601B1AC; case 0x0601B1B0u: goto L_0601B1B0; case 0x0601B1B2u: goto L_0601B1B2; case 0x0601B1B4u: goto L_0601B1B4; case 0x0601B1B6u: goto L_0601B1B6; case 0x0601B1B8u: goto L_0601B1B8; case 0x0601B1BAu: goto L_0601B1BA; case 0x0601B1BCu: goto L_0601B1BC; case 0x0601B1BEu: goto L_0601B1BE; case 0x0601B1C0u: goto L_0601B1C0; case 0x0601B1C2u: goto L_0601B1C2; case 0x0601B1C4u: goto L_0601B1C4; case 0x0601B1C8u: goto L_0601B1C8; case 0x0601B1CAu: goto L_0601B1CA; case 0x0601B1CCu: goto L_0601B1CC; case 0x0601B1CEu: goto L_0601B1CE; case 0x0601B1D0u: goto L_0601B1D0; case 0x0601B1D2u: goto L_0601B1D2; case 0x0601B1D4u: goto L_0601B1D4; case 0x0601B1D6u: goto L_0601B1D6; case 0x0601B1D8u: goto L_0601B1D8; case 0x0601B1DAu: goto L_0601B1DA; case 0x0601B1DCu: goto L_0601B1DC; case 0x0601B1DEu: goto L_0601B1DE; case 0x0601B1E0u: goto L_0601B1E0; case 0x0601B1E2u: goto L_0601B1E2; case 0x0601B1E4u: goto L_0601B1E4; case 0x0601B1E6u: goto L_0601B1E6; case 0x0601B1E8u: goto L_0601B1E8; case 0x0601B1EAu: goto L_0601B1EA; case 0x0601B1ECu: goto L_0601B1EC; case 0x0601B1EEu: goto L_0601B1EE; case 0x0601B1F0u: goto L_0601B1F0; case 0x0601B1F2u: goto L_0601B1F2; case 0x0601B1F4u: goto L_0601B1F4; case 0x0601B1F6u: goto L_0601B1F6; case 0x0601B1F8u: goto L_0601B1F8; case 0x0601B1FAu: goto L_0601B1FA; case 0x0601B1FCu: goto L_0601B1FC; case 0x0601B1FEu: goto L_0601B1FE; case 0x0601B200u: goto L_0601B200; case 0x0601B202u: goto L_0601B202; case 0x0601B204u: goto L_0601B204; case 0x0601B206u: goto L_0601B206; case 0x0601B208u: goto L_0601B208; case 0x0601B20Au: goto L_0601B20A; case 0x0601B20Cu: goto L_0601B20C; case 0x0601B20Eu: goto L_0601B20E; case 0x0601B210u: goto L_0601B210; case 0x0601B214u: goto L_0601B214; case 0x0601B216u: goto L_0601B216; case 0x0601B218u: goto L_0601B218; case 0x0601B21Au: goto L_0601B21A; case 0x0601B21Cu: goto L_0601B21C; case 0x0601B21Eu: goto L_0601B21E; case 0x0601B220u: goto L_0601B220; case 0x0601B222u: goto L_0601B222; case 0x0601B224u: goto L_0601B224; case 0x0601B228u: goto L_0601B228; case 0x0601B22Au: goto L_0601B22A; case 0x0601B22Eu: goto L_0601B22E; case 0x0601B260u: goto L_0601B260; case 0x0601B262u: goto L_0601B262; case 0x0601B264u: goto L_0601B264; case 0x0601B266u: goto L_0601B266; case 0x0601B268u: goto L_0601B268; case 0x0601B26Au: goto L_0601B26A; case 0x0601B26Cu: goto L_0601B26C; case 0x0601B26Eu: goto L_0601B26E; case 0x0601B270u: goto L_0601B270; case 0x0601B272u: goto L_0601B272; case 0x0601B274u: goto L_0601B274; case 0x0601B276u: goto L_0601B276; case 0x0601B278u: goto L_0601B278; case 0x0601B27Au: goto L_0601B27A; case 0x0601B27Cu: goto L_0601B27C; case 0x0601B27Eu: goto L_0601B27E; case 0x0601B280u: goto L_0601B280; case 0x0601B284u: goto L_0601B284; case 0x0601B286u: goto L_0601B286; case 0x0601B288u: goto L_0601B288; case 0x0601B28Au: goto L_0601B28A; case 0x0601B28Cu: goto L_0601B28C; case 0x0601B28Eu: goto L_0601B28E; case 0x0601B290u: goto L_0601B290; case 0x0601B292u: goto L_0601B292; case 0x0601B296u: goto L_0601B296; case 0x0601B298u: goto L_0601B298; case 0x0601B29Au: goto L_0601B29A; case 0x0601B29Eu: goto L_0601B29E; case 0x0601B2A0u: goto L_0601B2A0; case 0x0601B2A2u: goto L_0601B2A2; case 0x0601B2A4u: goto L_0601B2A4; case 0x0601B2A6u: goto L_0601B2A6; case 0x0601B2A8u: goto L_0601B2A8; case 0x0601B2AAu: goto L_0601B2AA; case 0x0601B2ACu: goto L_0601B2AC; case 0x0601B2AEu: goto L_0601B2AE; case 0x0601B2B0u: goto L_0601B2B0; case 0x0601B2B4u: goto L_0601B2B4; case 0x0601B2B8u: goto L_0601B2B8; case 0x0601B2BAu: goto L_0601B2BA; case 0x0601B2BCu: goto L_0601B2BC; case 0x0601B2BEu: goto L_0601B2BE; case 0x0601B2C0u: goto L_0601B2C0; case 0x0601B2C2u: goto L_0601B2C2; case 0x0601B2C4u: goto L_0601B2C4; case 0x0601B2C6u: goto L_0601B2C6; case 0x0601B2C8u: goto L_0601B2C8; case 0x0601B2CAu: goto L_0601B2CA; case 0x0601B2CCu: goto L_0601B2CC; case 0x0601B2CEu: goto L_0601B2CE; case 0x0601B2D0u: goto L_0601B2D0; case 0x0601B2D2u: goto L_0601B2D2; case 0x0601B2D4u: goto L_0601B2D4; case 0x0601B2D6u: goto L_0601B2D6; case 0x0601B2D8u: goto L_0601B2D8; case 0x0601B2DAu: goto L_0601B2DA; case 0x0601B2DEu: goto L_0601B2DE; case 0x0601B2E0u: goto L_0601B2E0; case 0x0601B2E2u: goto L_0601B2E2; case 0x0601B2E4u: goto L_0601B2E4; case 0x0601B2E6u: goto L_0601B2E6; case 0x0601B2E8u: goto L_0601B2E8; case 0x0601B2EAu: goto L_0601B2EA; case 0x0601B2ECu: goto L_0601B2EC; case 0x0601B2EEu: goto L_0601B2EE; case 0x0601B2F0u: goto L_0601B2F0; case 0x0601B2F2u: goto L_0601B2F2; case 0x0601B2F4u: goto L_0601B2F4; case 0x0601B2F6u: goto L_0601B2F6; case 0x0601B2F8u: goto L_0601B2F8; case 0x0601B2FAu: goto L_0601B2FA; case 0x0601B2FCu: goto L_0601B2FC; case 0x0601B2FEu: goto L_0601B2FE; case 0x0601B300u: goto L_0601B300; case 0x0601B302u: goto L_0601B302; case 0x0601B306u: goto L_0601B306; case 0x0601B308u: goto L_0601B308; case 0x0601B30Au: goto L_0601B30A; case 0x0601B30Cu: goto L_0601B30C; case 0x0601B30Eu: goto L_0601B30E; case 0x0601B312u: goto L_0601B312; case 0x0601B314u: goto L_0601B314; case 0x0601B316u: goto L_0601B316; case 0x0601B318u: goto L_0601B318; case 0x0601B31Au: goto L_0601B31A; case 0x0601B31Cu: goto L_0601B31C; case 0x0601B320u: goto L_0601B320; case 0x0601B322u: goto L_0601B322; case 0x0601B324u: goto L_0601B324; case 0x0601B326u: goto L_0601B326; case 0x0601B328u: goto L_0601B328; case 0x0601B32Cu: goto L_0601B32C; case 0x0601B32Eu: goto L_0601B32E; case 0x0601B330u: goto L_0601B330; case 0x0601B332u: goto L_0601B332; case 0x0601B334u: goto L_0601B334; case 0x0601B336u: goto L_0601B336; case 0x0601B338u: goto L_0601B338; case 0x0601B33Au: goto L_0601B33A; case 0x0601B33Cu: goto L_0601B33C; case 0x0601B340u: goto L_0601B340; case 0x0601B342u: goto L_0601B342; case 0x0601B346u: goto L_0601B346; case 0x0601B348u: goto L_0601B348; case 0x0601B34Au: goto L_0601B34A; case 0x0601B34Eu: goto L_0601B34E; case 0x0601B350u: goto L_0601B350; case 0x0601B352u: goto L_0601B352; case 0x0601B354u: goto L_0601B354; case 0x0601B356u: goto L_0601B356; case 0x0601B358u: goto L_0601B358; case 0x0601B35Au: goto L_0601B35A; case 0x0601B35Cu: goto L_0601B35C; case 0x0601B35Eu: goto L_0601B35E; case 0x0601B360u: goto L_0601B360; case 0x0601B362u: goto L_0601B362; case 0x0601B364u: goto L_0601B364; case 0x0601B366u: goto L_0601B366; case 0x0601B368u: goto L_0601B368; case 0x0601B36Au: goto L_0601B36A; case 0x0601B36Cu: goto L_0601B36C; case 0x0601B36Eu: goto L_0601B36E; case 0x0601B370u: goto L_0601B370; case 0x0601B372u: goto L_0601B372; case 0x0601B374u: goto L_0601B374; case 0x0601B376u: goto L_0601B376; case 0x0601B378u: goto L_0601B378; case 0x0601B37Au: goto L_0601B37A; case 0x0601B37Eu: goto L_0601B37E; case 0x0601B380u: goto L_0601B380; case 0x0601B382u: goto L_0601B382; case 0x0601B384u: goto L_0601B384; case 0x0601B386u: goto L_0601B386; case 0x0601B388u: goto L_0601B388; case 0x0601B38Au: goto L_0601B38A; case 0x0601B38Cu: goto L_0601B38C; case 0x0601B38Eu: goto L_0601B38E; case 0x0601B392u: goto L_0601B392; case 0x0601B394u: goto L_0601B394; case 0x0601B398u: goto L_0601B398; case 0x0601B39Cu: goto L_0601B39C; case 0x0601B39Eu: goto L_0601B39E; case 0x0601B3A0u: goto L_0601B3A0; case 0x0601B3A2u: goto L_0601B3A2; case 0x0601B3A4u: goto L_0601B3A4; case 0x0601B3A6u: goto L_0601B3A6; case 0x0601B3A8u: goto L_0601B3A8; case 0x0601B3AAu: goto L_0601B3AA; case 0x0601B3ACu: goto L_0601B3AC; case 0x0601B3AEu: goto L_0601B3AE; case 0x0601B3B0u: goto L_0601B3B0; case 0x0601B3B2u: goto L_0601B3B2; case 0x0601B3B4u: goto L_0601B3B4; case 0x0601B3B6u: goto L_0601B3B6; case 0x0601B3B8u: goto L_0601B3B8; case 0x0601B3BAu: goto L_0601B3BA; case 0x0601B3BCu: goto L_0601B3BC; case 0x0601B3BEu: goto L_0601B3BE; case 0x0601B3C0u: goto L_0601B3C0; case 0x0601B3C2u: goto L_0601B3C2; case 0x0601B3C4u: goto L_0601B3C4; case 0x0601B3C6u: goto L_0601B3C6; case 0x0601B3C8u: goto L_0601B3C8; case 0x0601B3CAu: goto L_0601B3CA; case 0x0601B3CCu: goto L_0601B3CC; case 0x0601B3CEu: goto L_0601B3CE; case 0x0601B3D0u: goto L_0601B3D0; case 0x0601B3D2u: goto L_0601B3D2; case 0x0601B3D4u: goto L_0601B3D4; case 0x0601B3D6u: goto L_0601B3D6; case 0x0601B3D8u: goto L_0601B3D8; case 0x0601B3DAu: goto L_0601B3DA; case 0x0601B3DCu: goto L_0601B3DC; case 0x0601B3DEu: goto L_0601B3DE; case 0x0601B3E0u: goto L_0601B3E0; case 0x0601B3E2u: goto L_0601B3E2; case 0x0601B3E4u: goto L_0601B3E4; case 0x0601B3E6u: goto L_0601B3E6; case 0x0601B3E8u: goto L_0601B3E8; case 0x0601B3EAu: goto L_0601B3EA; case 0x0601B3ECu: goto L_0601B3EC; case 0x0601B3EEu: goto L_0601B3EE; case 0x0601B3F2u: goto L_0601B3F2; case 0x0601B3F4u: goto L_0601B3F4; case 0x0601B3F6u: goto L_0601B3F6; case 0x0601B3FAu: goto L_0601B3FA; case 0x0601B3FCu: goto L_0601B3FC; case 0x0601B3FEu: goto L_0601B3FE; case 0x0601B400u: goto L_0601B400; case 0x0601B402u: goto L_0601B402; case 0x0601B406u: goto L_0601B406; case 0x0601B408u: goto L_0601B408; case 0x0601B40Au: goto L_0601B40A; case 0x0601B40Cu: goto L_0601B40C; case 0x0601B410u: goto L_0601B410; case 0x0601B412u: goto L_0601B412; case 0x0601B414u: goto L_0601B414; case 0x0601B416u: goto L_0601B416; case 0x0601B418u: goto L_0601B418; case 0x0601B41Au: goto L_0601B41A; case 0x0601B41Cu: goto L_0601B41C; case 0x0601B41Eu: goto L_0601B41E; case 0x0601B420u: goto L_0601B420; case 0x0601B424u: goto L_0601B424; case 0x0601B426u: goto L_0601B426; case 0x0601B428u: goto L_0601B428; case 0x0601B42Au: goto L_0601B42A; case 0x0601B42Cu: goto L_0601B42C; case 0x0601B42Eu: goto L_0601B42E; case 0x0601B430u: goto L_0601B430; case 0x0601B458u: goto L_0601B458; case 0x0601B45Au: goto L_0601B45A; case 0x0601B45Cu: goto L_0601B45C; case 0x0601B45Eu: goto L_0601B45E; case 0x0601B460u: goto L_0601B460; case 0x0601B462u: goto L_0601B462; case 0x0601B464u: goto L_0601B464; case 0x0601B466u: goto L_0601B466; case 0x0601B46Au: goto L_0601B46A; case 0x0601B46Cu: goto L_0601B46C; case 0x0601B470u: goto L_0601B470; case 0x0601B472u: goto L_0601B472; case 0x0601B474u: goto L_0601B474; case 0x0601B476u: goto L_0601B476; case 0x0601B478u: goto L_0601B478; case 0x0601B47Au: goto L_0601B47A; case 0x0601B47Cu: goto L_0601B47C; case 0x0601B47Eu: goto L_0601B47E; case 0x0601B480u: goto L_0601B480; case 0x0601B482u: goto L_0601B482; case 0x0601B486u: goto L_0601B486; case 0x0601B488u: goto L_0601B488; case 0x0601B48Au: goto L_0601B48A; case 0x0601B48Cu: goto L_0601B48C; case 0x0601B48Eu: goto L_0601B48E; case 0x0601B490u: goto L_0601B490; case 0x0601B492u: goto L_0601B492; case 0x0601B494u: goto L_0601B494; case 0x0601B496u: goto L_0601B496; case 0x0601B49Au: goto L_0601B49A; case 0x0601B49Cu: goto L_0601B49C; case 0x0601B49Eu: goto L_0601B49E; case 0x0601B4A2u: goto L_0601B4A2; case 0x0601B4A4u: goto L_0601B4A4; case 0x0601B4A6u: goto L_0601B4A6; case 0x0601B4AAu: goto L_0601B4AA; case 0x0601B4ACu: goto L_0601B4AC; case 0x0601B4AEu: goto L_0601B4AE; case 0x0601B4B0u: goto L_0601B4B0; case 0x0601B4B2u: goto L_0601B4B2; case 0x0601B4B4u: goto L_0601B4B4; case 0x0601B4B6u: goto L_0601B4B6; case 0x0601B4B8u: goto L_0601B4B8; case 0x0601B4BAu: goto L_0601B4BA; case 0x0601B4BCu: goto L_0601B4BC; case 0x0601B4BEu: goto L_0601B4BE; case 0x0601B4C0u: goto L_0601B4C0; case 0x0601B4C2u: goto L_0601B4C2; case 0x0601B4C4u: goto L_0601B4C4; case 0x0601B4C6u: goto L_0601B4C6; case 0x0601B4C8u: goto L_0601B4C8; case 0x0601B4CAu: goto L_0601B4CA; case 0x0601B4CCu: goto L_0601B4CC; case 0x0601B4CEu: goto L_0601B4CE; case 0x0601B4D0u: goto L_0601B4D0; case 0x0601B4D2u: goto L_0601B4D2; case 0x0601B4D6u: goto L_0601B4D6; case 0x0601B4D8u: goto L_0601B4D8; case 0x0601B4DAu: goto L_0601B4DA; case 0x0601B4DCu: goto L_0601B4DC; case 0x0601B4DEu: goto L_0601B4DE; case 0x0601B4E0u: goto L_0601B4E0; case 0x0601B4E2u: goto L_0601B4E2; case 0x0601B4E4u: goto L_0601B4E4; case 0x0601B4E6u: goto L_0601B4E6; case 0x0601B4EAu: goto L_0601B4EA; case 0x0601B4ECu: goto L_0601B4EC; case 0x0601B4F0u: goto L_0601B4F0; case 0x0601B4F4u: goto L_0601B4F4; case 0x0601B4F6u: goto L_0601B4F6; case 0x0601B4F8u: goto L_0601B4F8; case 0x0601B4FAu: goto L_0601B4FA; case 0x0601B4FCu: goto L_0601B4FC; case 0x0601B4FEu: goto L_0601B4FE; case 0x0601B500u: goto L_0601B500; case 0x0601B502u: goto L_0601B502; case 0x0601B504u: goto L_0601B504; case 0x0601B506u: goto L_0601B506; case 0x0601B508u: goto L_0601B508; case 0x0601B50Au: goto L_0601B50A; case 0x0601B50Cu: goto L_0601B50C; case 0x0601B50Eu: goto L_0601B50E; case 0x0601B510u: goto L_0601B510; case 0x0601B512u: goto L_0601B512; case 0x0601B516u: goto L_0601B516; case 0x0601B51Au: goto L_0601B51A; case 0x0601B51Cu: goto L_0601B51C; case 0x0601B51Eu: goto L_0601B51E; case 0x0601B520u: goto L_0601B520; case 0x0601B522u: goto L_0601B522; case 0x0601B524u: goto L_0601B524; case 0x0601B526u: goto L_0601B526; case 0x0601B528u: goto L_0601B528; case 0x0601B52Au: goto L_0601B52A; case 0x0601B52Cu: goto L_0601B52C; case 0x0601B530u: goto L_0601B530; case 0x0601B532u: goto L_0601B532; case 0x0601B534u: goto L_0601B534; case 0x0601B536u: goto L_0601B536; case 0x0601B538u: goto L_0601B538; case 0x0601B53Au: goto L_0601B53A; case 0x0601B53Cu: goto L_0601B53C; case 0x0601B53Eu: goto L_0601B53E; case 0x0601B540u: goto L_0601B540; case 0x0601B542u: goto L_0601B542; case 0x0601B544u: goto L_0601B544; case 0x0601B546u: goto L_0601B546; case 0x0601B548u: goto L_0601B548; case 0x0601B54Au: goto L_0601B54A; case 0x0601B54Cu: goto L_0601B54C; case 0x0601B54Eu: goto L_0601B54E; case 0x0601B550u: goto L_0601B550; case 0x0601B552u: goto L_0601B552; case 0x0601B554u: goto L_0601B554; case 0x0601B556u: goto L_0601B556; case 0x0601B558u: goto L_0601B558; case 0x0601B57Cu: goto L_0601B57C; case 0x0601B57Eu: goto L_0601B57E; case 0x0601B580u: goto L_0601B580; case 0x0601B582u: goto L_0601B582; case 0x0601B584u: goto L_0601B584; case 0x0601B586u: goto L_0601B586; case 0x0601B588u: goto L_0601B588; case 0x0601B58Au: goto L_0601B58A; case 0x0601B58Cu: goto L_0601B58C; case 0x0601B58Eu: goto L_0601B58E; case 0x0601B590u: goto L_0601B590; case 0x0601B592u: goto L_0601B592; case 0x0601B594u: goto L_0601B594; case 0x0601B596u: goto L_0601B596; case 0x0601B598u: goto L_0601B598; case 0x0601B59Au: goto L_0601B59A; case 0x0601B59Cu: goto L_0601B59C; case 0x0601B59Eu: goto L_0601B59E; case 0x0601B5A0u: goto L_0601B5A0; case 0x0601B5A4u: goto L_0601B5A4; case 0x0601B5A6u: goto L_0601B5A6; case 0x0601B5A8u: goto L_0601B5A8; case 0x0601B5AAu: goto L_0601B5AA; case 0x0601B5ACu: goto L_0601B5AC; case 0x0601B5B0u: goto L_0601B5B0; case 0x0601B5B2u: goto L_0601B5B2; case 0x0601B5B4u: goto L_0601B5B4; case 0x0601B5B6u: goto L_0601B5B6; case 0x0601B5B8u: goto L_0601B5B8; case 0x0601B5BAu: goto L_0601B5BA; case 0x0601B5BEu: goto L_0601B5BE; case 0x0601B5C0u: goto L_0601B5C0; case 0x0601B5C2u: goto L_0601B5C2; case 0x0601B5C4u: goto L_0601B5C4; case 0x0601B5C6u: goto L_0601B5C6; case 0x0601B5C8u: goto L_0601B5C8; case 0x0601B5CAu: goto L_0601B5CA; case 0x0601B5CCu: goto L_0601B5CC; case 0x0601B5CEu: goto L_0601B5CE; case 0x0601B5D0u: goto L_0601B5D0; case 0x0601B5D2u: goto L_0601B5D2; case 0x0601B5D4u: goto L_0601B5D4; case 0x0601B5D6u: goto L_0601B5D6; case 0x0601B5D8u: goto L_0601B5D8; case 0x0601B5DAu: goto L_0601B5DA; case 0x0601B5DCu: goto L_0601B5DC; case 0x0601B5DEu: goto L_0601B5DE; case 0x0601B5E2u: goto L_0601B5E2; case 0x0601B5E4u: goto L_0601B5E4; case 0x0601B5E6u: goto L_0601B5E6; case 0x0601B5E8u: goto L_0601B5E8; case 0x0601B5EAu: goto L_0601B5EA; case 0x0601B5ECu: goto L_0601B5EC; case 0x0601B5EEu: goto L_0601B5EE; case 0x0601B5F0u: goto L_0601B5F0; case 0x0601B5F2u: goto L_0601B5F2; case 0x0601B5F4u: goto L_0601B5F4; case 0x0601B5F6u: goto L_0601B5F6; case 0x0601B5F8u: goto L_0601B5F8; case 0x0601B5FAu: goto L_0601B5FA; case 0x0601B5FCu: goto L_0601B5FC; case 0x0601B5FEu: goto L_0601B5FE; case 0x0601B602u: goto L_0601B602; case 0x0601B604u: goto L_0601B604; case 0x0601B608u: goto L_0601B608; case 0x0601B60Cu: goto L_0601B60C; case 0x0601B60Eu: goto L_0601B60E; case 0x0601B610u: goto L_0601B610; case 0x0601B612u: goto L_0601B612; case 0x0601B614u: goto L_0601B614; case 0x0601B616u: goto L_0601B616; case 0x0601B618u: goto L_0601B618; case 0x0601B61Au: goto L_0601B61A; case 0x0601B61Cu: goto L_0601B61C; case 0x0601B61Eu: goto L_0601B61E; case 0x0601B620u: goto L_0601B620; case 0x0601B622u: goto L_0601B622; case 0x0601B624u: goto L_0601B624; case 0x0601B626u: goto L_0601B626; case 0x0601B628u: goto L_0601B628; case 0x0601B62Au: goto L_0601B62A; case 0x0601B62Cu: goto L_0601B62C; case 0x0601B62Eu: goto L_0601B62E; case 0x0601B630u: goto L_0601B630; case 0x0601B632u: goto L_0601B632; case 0x0601B634u: goto L_0601B634; case 0x0601B636u: goto L_0601B636; case 0x0601B638u: goto L_0601B638; case 0x0601B63Au: goto L_0601B63A; case 0x0601B63Cu: goto L_0601B63C; case 0x0601B63Eu: goto L_0601B63E; case 0x0601B640u: goto L_0601B640; case 0x0601B642u: goto L_0601B642; case 0x0601B644u: goto L_0601B644; case 0x0601B646u: goto L_0601B646; case 0x0601B648u: goto L_0601B648; case 0x0601B64Au: goto L_0601B64A; case 0x0601B64Cu: goto L_0601B64C; case 0x0601B64Eu: goto L_0601B64E; case 0x0601B650u: goto L_0601B650; case 0x0601B652u: goto L_0601B652; case 0x0601B654u: goto L_0601B654; case 0x0601B656u: goto L_0601B656; case 0x0601B658u: goto L_0601B658; case 0x0601B65Au: goto L_0601B65A; case 0x0601B65Cu: goto L_0601B65C; case 0x0601B65Eu: goto L_0601B65E; case 0x0601B660u: goto L_0601B660; case 0x0601B664u: goto L_0601B664; case 0x0601B666u: goto L_0601B666; case 0x0601B66Au: goto L_0601B66A; case 0x0601B66Cu: goto L_0601B66C; case 0x0601B66Eu: goto L_0601B66E; case 0x0601B670u: goto L_0601B670; case 0x0601B672u: goto L_0601B672; case 0x0601B674u: goto L_0601B674; case 0x0601B676u: goto L_0601B676; case 0x0601B678u: goto L_0601B678; case 0x0601B67Au: goto L_0601B67A; case 0x0601B67Eu: goto L_0601B67E; case 0x0601B682u: goto L_0601B682; case 0x0601B684u: goto L_0601B684; case 0x0601B688u: goto L_0601B688; case 0x0601B68Au: goto L_0601B68A; case 0x0601B68Cu: goto L_0601B68C; case 0x0601B68Eu: goto L_0601B68E; case 0x0601B690u: goto L_0601B690; case 0x0601B692u: goto L_0601B692; case 0x0601B696u: goto L_0601B696; case 0x0601B698u: goto L_0601B698; case 0x0601B69Au: goto L_0601B69A; case 0x0601B69Cu: goto L_0601B69C; case 0x0601B69Eu: goto L_0601B69E; case 0x0601B6A0u: goto L_0601B6A0; case 0x0601B6A4u: goto L_0601B6A4; case 0x0601B6A6u: goto L_0601B6A6; case 0x0601B6A8u: goto L_0601B6A8; case 0x0601B6AAu: goto L_0601B6AA; case 0x0601B6ACu: goto L_0601B6AC; case 0x0601B6AEu: goto L_0601B6AE; case 0x0601B6B0u: goto L_0601B6B0; case 0x0601B6B2u: goto L_0601B6B2; case 0x0601B6B4u: goto L_0601B6B4; case 0x0601B6B6u: goto L_0601B6B6; case 0x0601B6B8u: goto L_0601B6B8; case 0x0601B6BAu: goto L_0601B6BA; case 0x0601B6BCu: goto L_0601B6BC; case 0x0601B6BEu: goto L_0601B6BE; case 0x0601B6C0u: goto L_0601B6C0; case 0x0601B6C2u: goto L_0601B6C2; case 0x0601B6C4u: goto L_0601B6C4; case 0x0601B6C8u: goto L_0601B6C8; case 0x0601B6CAu: goto L_0601B6CA; case 0x0601B6CEu: goto L_0601B6CE; case 0x0601B6D0u: goto L_0601B6D0; case 0x0601B6D2u: goto L_0601B6D2; case 0x0601B6D4u: goto L_0601B6D4; case 0x0601B6D6u: goto L_0601B6D6; case 0x0601B6D8u: goto L_0601B6D8; case 0x0601B6DAu: goto L_0601B6DA; case 0x0601B6DCu: goto L_0601B6DC; case 0x0601B6DEu: goto L_0601B6DE; case 0x0601B6E0u: goto L_0601B6E0; case 0x0607EB7Cu: goto L_0607EB7C; case 0x0607EB7Eu: goto L_0607EB7E; case 0x0607EB80u: goto L_0607EB80; case 0x0607EB82u: goto L_0607EB82; case 0x0607EB84u: goto L_0607EB84; case 0x0607EB86u: goto L_0607EB86; case 0x0607EB88u: goto L_0607EB88; case 0x0607EB8Au: goto L_0607EB8A; case 0x0607EB8Cu: goto L_0607EB8C; case 0x0607EB8Eu: goto L_0607EB8E; case 0x0607EB90u: goto L_0607EB90; case 0x0607EB92u: goto L_0607EB92; case 0x0607EB94u: goto L_0607EB94; case 0x0607EB96u: goto L_0607EB96; case 0x0607EB98u: goto L_0607EB98; case 0x0607EB9Au: goto L_0607EB9A; case 0x0607EB9Cu: goto L_0607EB9C; case 0x0607EB9Eu: goto L_0607EB9E; case 0x0607EBA0u: goto L_0607EBA0; case 0x0607EBA2u: goto L_0607EBA2; case 0x0607EBA4u: goto L_0607EBA4; case 0x0607EBA6u: goto L_0607EBA6; case 0x0607EBA8u: goto L_0607EBA8; case 0x0607EBAAu: goto L_0607EBAA; case 0x0607EBACu: goto L_0607EBAC; case 0x0607EBAEu: goto L_0607EBAE; case 0x0607EBB0u: goto L_0607EBB0; case 0x0607EBB2u: goto L_0607EBB2; case 0x0607EBB4u: goto L_0607EBB4; case 0x0607EBB6u: goto L_0607EBB6; case 0x0607EBBAu: goto L_0607EBBA; case 0x0607EBBCu: goto L_0607EBBC; case 0x0607EBBEu: goto L_0607EBBE; case 0x0607EBC2u: goto L_0607EBC2; case 0x0607EBC4u: goto L_0607EBC4; case 0x0607EBC6u: goto L_0607EBC6; case 0x0607EBC8u: goto L_0607EBC8; case 0x0607EBCAu: goto L_0607EBCA; case 0x0607EBCCu: goto L_0607EBCC; case 0x0607EBD0u: goto L_0607EBD0; case 0x0607EBD2u: goto L_0607EBD2; case 0x0607EBD4u: goto L_0607EBD4; case 0x0607EBD6u: goto L_0607EBD6; case 0x0607EBD8u: goto L_0607EBD8; case 0x0607EBDAu: goto L_0607EBDA; case 0x0607EBDCu: goto L_0607EBDC; case 0x0607EBDEu: goto L_0607EBDE; case 0x0607EBE0u: goto L_0607EBE0; case 0x0607EBE2u: goto L_0607EBE2; case 0x0607EBE4u: goto L_0607EBE4; case 0x0607EBE6u: goto L_0607EBE6; case 0x0607EBE8u: goto L_0607EBE8; case 0x0607EBEAu: goto L_0607EBEA; case 0x0607EBECu: goto L_0607EBEC; case 0x0607EBEEu: goto L_0607EBEE; case 0x0607EBF0u: goto L_0607EBF0; case 0x0607EBF2u: goto L_0607EBF2; case 0x0607EBF4u: goto L_0607EBF4; case 0x0607EBF6u: goto L_0607EBF6; case 0x0607EBF8u: goto L_0607EBF8; case 0x0607EBFCu: goto L_0607EBFC; case 0x0607EBFEu: goto L_0607EBFE; case 0x0607EC02u: goto L_0607EC02; case 0x0607EC04u: goto L_0607EC04; case 0x0607EC06u: goto L_0607EC06; case 0x0607EC08u: goto L_0607EC08; case 0x0607EC0Au: goto L_0607EC0A; case 0x0607EC0Cu: goto L_0607EC0C; case 0x0607EC0Eu: goto L_0607EC0E; case 0x0607EC10u: goto L_0607EC10; case 0x0607EC12u: goto L_0607EC12; case 0x0607EC14u: goto L_0607EC14; case 0x0607EC16u: goto L_0607EC16; case 0x0607EC18u: goto L_0607EC18; case 0x0607EC1Au: goto L_0607EC1A; case 0x0607EC1Cu: goto L_0607EC1C; case 0x0607EC1Eu: goto L_0607EC1E; case 0x0607EC20u: goto L_0607EC20; case 0x0607EC22u: goto L_0607EC22; case 0x0607EC26u: goto L_0607EC26; case 0x0607EC28u: goto L_0607EC28; case 0x0607EC2Au: goto L_0607EC2A; case 0x0607EC2Cu: goto L_0607EC2C; case 0x0607EC2Eu: goto L_0607EC2E; case 0x0607EC30u: goto L_0607EC30; case 0x0607EC32u: goto L_0607EC32; case 0x0607EC34u: goto L_0607EC34; case 0x0607EC36u: goto L_0607EC36; case 0x0607EC38u: goto L_0607EC38; case 0x0607EC3Au: goto L_0607EC3A; case 0x0607EC3Cu: goto L_0607EC3C; case 0x0607EC3Eu: goto L_0607EC3E; case 0x0607EC40u: goto L_0607EC40; case 0x0607EC42u: goto L_0607EC42; case 0x0607EC44u: goto L_0607EC44; case 0x0607EC46u: goto L_0607EC46; case 0x0607EC48u: goto L_0607EC48; case 0x0607EC4Au: goto L_0607EC4A; case 0x0607EC4Cu: goto L_0607EC4C; case 0x0607EC50u: goto L_0607EC50; case 0x0607EC52u: goto L_0607EC52; case 0x0607EC54u: goto L_0607EC54; case 0x0607EC56u: goto L_0607EC56; case 0x0607EC58u: goto L_0607EC58; case 0x0607EC5Au: goto L_0607EC5A; case 0x0607EC5Cu: goto L_0607EC5C; case 0x0607EC5Eu: goto L_0607EC5E; case 0x0607EC60u: goto L_0607EC60; case 0x0607EC64u: goto L_0607EC64; case 0x0607EC66u: goto L_0607EC66; case 0x0607EC68u: goto L_0607EC68; case 0x0607EC6Au: goto L_0607EC6A; case 0x0607EC6Cu: goto L_0607EC6C; case 0x0607EC6Eu: goto L_0607EC6E; case 0x0607EC70u: goto L_0607EC70; case 0x0607EC74u: goto L_0607EC74; case 0x0607EC76u: goto L_0607EC76; case 0x0607EC78u: goto L_0607EC78; case 0x0607EC7Au: goto L_0607EC7A; case 0x0607EC7Cu: goto L_0607EC7C; case 0x0607EC7Eu: goto L_0607EC7E; case 0x0607EC80u: goto L_0607EC80; case 0x0607EC82u: goto L_0607EC82; case 0x0607EC84u: goto L_0607EC84; case 0x0607EC86u: goto L_0607EC86; case 0x0607EC88u: goto L_0607EC88; case 0x0607EC8Au: goto L_0607EC8A; case 0x0607EC8Cu: goto L_0607EC8C; case 0x0607EC8Eu: goto L_0607EC8E; case 0x0607EC90u: goto L_0607EC90; case 0x0607EC92u: goto L_0607EC92; case 0x0607EC94u: goto L_0607EC94; case 0x0607EC96u: goto L_0607EC96; case 0x0607EC98u: goto L_0607EC98; case 0x0607EC9Au: goto L_0607EC9A; case 0x0607EC9Cu: goto L_0607EC9C; case 0x0607EC9Eu: goto L_0607EC9E; case 0x0607ECA0u: goto L_0607ECA0; case 0x0607ECA2u: goto L_0607ECA2; case 0x0607ECA4u: goto L_0607ECA4; case 0x0607ECA8u: goto L_0607ECA8; case 0x0607ECAAu: goto L_0607ECAA; case 0x0607ECACu: goto L_0607ECAC; case 0x0607ECAEu: goto L_0607ECAE; case 0x0607ECB0u: goto L_0607ECB0; case 0x0607ECB2u: goto L_0607ECB2; case 0x0607ECB4u: goto L_0607ECB4; case 0x0607ECB6u: goto L_0607ECB6; case 0x0607ECB8u: goto L_0607ECB8; case 0x0607ECBAu: goto L_0607ECBA; case 0x0607ECBCu: goto L_0607ECBC; case 0x0607ECBEu: goto L_0607ECBE; case 0x0607ECC0u: goto L_0607ECC0; case 0x0607ECC2u: goto L_0607ECC2; case 0x0607ECC4u: goto L_0607ECC4; case 0x0607ECC6u: goto L_0607ECC6; case 0x0607ECC8u: goto L_0607ECC8; case 0x0607ECCAu: goto L_0607ECCA; case 0x0607ECCCu: goto L_0607ECCC; case 0x0607ECCEu: goto L_0607ECCE; case 0x0607ECD0u: goto L_0607ECD0; case 0x0607ECD2u: goto L_0607ECD2; case 0x0607ECD6u: goto L_0607ECD6; case 0x0607ECD8u: goto L_0607ECD8; case 0x0607ECDAu: goto L_0607ECDA; case 0x0607ECDCu: goto L_0607ECDC; case 0x0607ECDEu: goto L_0607ECDE; case 0x0607ECE0u: goto L_0607ECE0; case 0x0607ECE4u: goto L_0607ECE4; case 0x0607ECE8u: goto L_0607ECE8; case 0x0607ECEAu: goto L_0607ECEA; case 0x0607EE54u: goto L_0607EE54; case 0x0607EE56u: goto L_0607EE56; case 0x0607EE58u: goto L_0607EE58; case 0x0607EE5Au: goto L_0607EE5A; case 0x0607EE5Cu: goto L_0607EE5C; case 0x0607EE5Eu: goto L_0607EE5E; case 0x0607EE60u: goto L_0607EE60; case 0x0607EE62u: goto L_0607EE62; case 0x0608431Eu: goto L_0608431E; case 0x06084320u: goto L_06084320; case 0x06084322u: goto L_06084322; case 0x06084324u: goto L_06084324; case 0x06084326u: goto L_06084326; case 0x06084328u: goto L_06084328; case 0x0608432Au: goto L_0608432A; case 0x0608432Cu: goto L_0608432C; case 0x06084330u: goto L_06084330; case 0x06084332u: goto L_06084332; case 0x06084334u: goto L_06084334; case 0x06084336u: goto L_06084336; case 0x06084338u: goto L_06084338; case 0x0608433Au: goto L_0608433A; case 0x0608433Cu: goto L_0608433C; case 0x0608433Eu: goto L_0608433E; case 0x06084340u: goto L_06084340; case 0x06084342u: goto L_06084342; case 0x06084344u: goto L_06084344; case 0x06084346u: goto L_06084346; case 0x06084348u: goto L_06084348; case 0x0608434Au: goto L_0608434A; case 0x0608434Cu: goto L_0608434C; case 0x0608434Eu: goto L_0608434E; case 0x06084350u: goto L_06084350; case 0x06084352u: goto L_06084352; case 0x06084354u: goto L_06084354; case 0x06084356u: goto L_06084356; case 0x06084358u: goto L_06084358; case 0x0608435Au: goto L_0608435A; case 0x0608435Cu: goto L_0608435C; case 0x0608435Eu: goto L_0608435E; case 0x06084362u: goto L_06084362; case 0x06084364u: goto L_06084364; default: sh2_call(c, x); return; } }  // 0608435E jmp @r0 ; nop
L_06084362:
    c.r[0] = ld32(0x060843D8u);  // 06084362 mov.l 0x060843D8,r0
L_06084364:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x0601B114u: goto L_0601B114; case 0x0601B116u: goto L_0601B116; case 0x0601B124u: goto L_0601B124; case 0x0601B126u: goto L_0601B126; case 0x0601B128u: goto L_0601B128; case 0x0601B12Au: goto L_0601B12A; case 0x0601B12Cu: goto L_0601B12C; case 0x0601B12Eu: goto L_0601B12E; case 0x0601B130u: goto L_0601B130; case 0x0601B132u: goto L_0601B132; case 0x0601B134u: goto L_0601B134; case 0x0601B136u: goto L_0601B136; case 0x0601B138u: goto L_0601B138; case 0x0601B13Au: goto L_0601B13A; case 0x0601B13Eu: goto L_0601B13E; case 0x0601B140u: goto L_0601B140; case 0x0601B144u: goto L_0601B144; case 0x0601B146u: goto L_0601B146; case 0x0601B148u: goto L_0601B148; case 0x0601B14Au: goto L_0601B14A; case 0x0601B14Cu: goto L_0601B14C; case 0x0601B14Eu: goto L_0601B14E; case 0x0601B150u: goto L_0601B150; case 0x0601B152u: goto L_0601B152; case 0x0601B156u: goto L_0601B156; case 0x0601B158u: goto L_0601B158; case 0x0601B15Au: goto L_0601B15A; case 0x0601B15Cu: goto L_0601B15C; case 0x0601B15Eu: goto L_0601B15E; case 0x0601B162u: goto L_0601B162; case 0x0601B164u: goto L_0601B164; case 0x0601B166u: goto L_0601B166; case 0x0601B168u: goto L_0601B168; case 0x0601B16Au: goto L_0601B16A; case 0x0601B16Cu: goto L_0601B16C; case 0x0601B16Eu: goto L_0601B16E; case 0x0601B170u: goto L_0601B170; case 0x0601B172u: goto L_0601B172; case 0x0601B176u: goto L_0601B176; case 0x0601B178u: goto L_0601B178; case 0x0601B17Au: goto L_0601B17A; case 0x0601B17Cu: goto L_0601B17C; case 0x0601B17Eu: goto L_0601B17E; case 0x0601B180u: goto L_0601B180; case 0x0601B182u: goto L_0601B182; case 0x0601B184u: goto L_0601B184; case 0x0601B188u: goto L_0601B188; case 0x0601B18Au: goto L_0601B18A; case 0x0601B18Cu: goto L_0601B18C; case 0x0601B190u: goto L_0601B190; case 0x0601B194u: goto L_0601B194; case 0x0601B196u: goto L_0601B196; case 0x0601B198u: goto L_0601B198; case 0x0601B19Au: goto L_0601B19A; case 0x0601B19Cu: goto L_0601B19C; case 0x0601B19Eu: goto L_0601B19E; case 0x0601B1A0u: goto L_0601B1A0; case 0x0601B1A2u: goto L_0601B1A2; case 0x0601B1A4u: goto L_0601B1A4; case 0x0601B1A6u: goto L_0601B1A6; case 0x0601B1A8u: goto L_0601B1A8; case 0x0601B1AAu: goto L_0601B1AA; case 0x0601B1ACu: goto L_0601B1AC; case 0x0601B1B0u: goto L_0601B1B0; case 0x0601B1B2u: goto L_0601B1B2; case 0x0601B1B4u: goto L_0601B1B4; case 0x0601B1B6u: goto L_0601B1B6; case 0x0601B1B8u: goto L_0601B1B8; case 0x0601B1BAu: goto L_0601B1BA; case 0x0601B1BCu: goto L_0601B1BC; case 0x0601B1BEu: goto L_0601B1BE; case 0x0601B1C0u: goto L_0601B1C0; case 0x0601B1C2u: goto L_0601B1C2; case 0x0601B1C4u: goto L_0601B1C4; case 0x0601B1C8u: goto L_0601B1C8; case 0x0601B1CAu: goto L_0601B1CA; case 0x0601B1CCu: goto L_0601B1CC; case 0x0601B1CEu: goto L_0601B1CE; case 0x0601B1D0u: goto L_0601B1D0; case 0x0601B1D2u: goto L_0601B1D2; case 0x0601B1D4u: goto L_0601B1D4; case 0x0601B1D6u: goto L_0601B1D6; case 0x0601B1D8u: goto L_0601B1D8; case 0x0601B1DAu: goto L_0601B1DA; case 0x0601B1DCu: goto L_0601B1DC; case 0x0601B1DEu: goto L_0601B1DE; case 0x0601B1E0u: goto L_0601B1E0; case 0x0601B1E2u: goto L_0601B1E2; case 0x0601B1E4u: goto L_0601B1E4; case 0x0601B1E6u: goto L_0601B1E6; case 0x0601B1E8u: goto L_0601B1E8; case 0x0601B1EAu: goto L_0601B1EA; case 0x0601B1ECu: goto L_0601B1EC; case 0x0601B1EEu: goto L_0601B1EE; case 0x0601B1F0u: goto L_0601B1F0; case 0x0601B1F2u: goto L_0601B1F2; case 0x0601B1F4u: goto L_0601B1F4; case 0x0601B1F6u: goto L_0601B1F6; case 0x0601B1F8u: goto L_0601B1F8; case 0x0601B1FAu: goto L_0601B1FA; case 0x0601B1FCu: goto L_0601B1FC; case 0x0601B1FEu: goto L_0601B1FE; case 0x0601B200u: goto L_0601B200; case 0x0601B202u: goto L_0601B202; case 0x0601B204u: goto L_0601B204; case 0x0601B206u: goto L_0601B206; case 0x0601B208u: goto L_0601B208; case 0x0601B20Au: goto L_0601B20A; case 0x0601B20Cu: goto L_0601B20C; case 0x0601B20Eu: goto L_0601B20E; case 0x0601B210u: goto L_0601B210; case 0x0601B214u: goto L_0601B214; case 0x0601B216u: goto L_0601B216; case 0x0601B218u: goto L_0601B218; case 0x0601B21Au: goto L_0601B21A; case 0x0601B21Cu: goto L_0601B21C; case 0x0601B21Eu: goto L_0601B21E; case 0x0601B220u: goto L_0601B220; case 0x0601B222u: goto L_0601B222; case 0x0601B224u: goto L_0601B224; case 0x0601B228u: goto L_0601B228; case 0x0601B22Au: goto L_0601B22A; case 0x0601B22Eu: goto L_0601B22E; case 0x0601B260u: goto L_0601B260; case 0x0601B262u: goto L_0601B262; case 0x0601B264u: goto L_0601B264; case 0x0601B266u: goto L_0601B266; case 0x0601B268u: goto L_0601B268; case 0x0601B26Au: goto L_0601B26A; case 0x0601B26Cu: goto L_0601B26C; case 0x0601B26Eu: goto L_0601B26E; case 0x0601B270u: goto L_0601B270; case 0x0601B272u: goto L_0601B272; case 0x0601B274u: goto L_0601B274; case 0x0601B276u: goto L_0601B276; case 0x0601B278u: goto L_0601B278; case 0x0601B27Au: goto L_0601B27A; case 0x0601B27Cu: goto L_0601B27C; case 0x0601B27Eu: goto L_0601B27E; case 0x0601B280u: goto L_0601B280; case 0x0601B284u: goto L_0601B284; case 0x0601B286u: goto L_0601B286; case 0x0601B288u: goto L_0601B288; case 0x0601B28Au: goto L_0601B28A; case 0x0601B28Cu: goto L_0601B28C; case 0x0601B28Eu: goto L_0601B28E; case 0x0601B290u: goto L_0601B290; case 0x0601B292u: goto L_0601B292; case 0x0601B296u: goto L_0601B296; case 0x0601B298u: goto L_0601B298; case 0x0601B29Au: goto L_0601B29A; case 0x0601B29Eu: goto L_0601B29E; case 0x0601B2A0u: goto L_0601B2A0; case 0x0601B2A2u: goto L_0601B2A2; case 0x0601B2A4u: goto L_0601B2A4; case 0x0601B2A6u: goto L_0601B2A6; case 0x0601B2A8u: goto L_0601B2A8; case 0x0601B2AAu: goto L_0601B2AA; case 0x0601B2ACu: goto L_0601B2AC; case 0x0601B2AEu: goto L_0601B2AE; case 0x0601B2B0u: goto L_0601B2B0; case 0x0601B2B4u: goto L_0601B2B4; case 0x0601B2B8u: goto L_0601B2B8; case 0x0601B2BAu: goto L_0601B2BA; case 0x0601B2BCu: goto L_0601B2BC; case 0x0601B2BEu: goto L_0601B2BE; case 0x0601B2C0u: goto L_0601B2C0; case 0x0601B2C2u: goto L_0601B2C2; case 0x0601B2C4u: goto L_0601B2C4; case 0x0601B2C6u: goto L_0601B2C6; case 0x0601B2C8u: goto L_0601B2C8; case 0x0601B2CAu: goto L_0601B2CA; case 0x0601B2CCu: goto L_0601B2CC; case 0x0601B2CEu: goto L_0601B2CE; case 0x0601B2D0u: goto L_0601B2D0; case 0x0601B2D2u: goto L_0601B2D2; case 0x0601B2D4u: goto L_0601B2D4; case 0x0601B2D6u: goto L_0601B2D6; case 0x0601B2D8u: goto L_0601B2D8; case 0x0601B2DAu: goto L_0601B2DA; case 0x0601B2DEu: goto L_0601B2DE; case 0x0601B2E0u: goto L_0601B2E0; case 0x0601B2E2u: goto L_0601B2E2; case 0x0601B2E4u: goto L_0601B2E4; case 0x0601B2E6u: goto L_0601B2E6; case 0x0601B2E8u: goto L_0601B2E8; case 0x0601B2EAu: goto L_0601B2EA; case 0x0601B2ECu: goto L_0601B2EC; case 0x0601B2EEu: goto L_0601B2EE; case 0x0601B2F0u: goto L_0601B2F0; case 0x0601B2F2u: goto L_0601B2F2; case 0x0601B2F4u: goto L_0601B2F4; case 0x0601B2F6u: goto L_0601B2F6; case 0x0601B2F8u: goto L_0601B2F8; case 0x0601B2FAu: goto L_0601B2FA; case 0x0601B2FCu: goto L_0601B2FC; case 0x0601B2FEu: goto L_0601B2FE; case 0x0601B300u: goto L_0601B300; case 0x0601B302u: goto L_0601B302; case 0x0601B306u: goto L_0601B306; case 0x0601B308u: goto L_0601B308; case 0x0601B30Au: goto L_0601B30A; case 0x0601B30Cu: goto L_0601B30C; case 0x0601B30Eu: goto L_0601B30E; case 0x0601B312u: goto L_0601B312; case 0x0601B314u: goto L_0601B314; case 0x0601B316u: goto L_0601B316; case 0x0601B318u: goto L_0601B318; case 0x0601B31Au: goto L_0601B31A; case 0x0601B31Cu: goto L_0601B31C; case 0x0601B320u: goto L_0601B320; case 0x0601B322u: goto L_0601B322; case 0x0601B324u: goto L_0601B324; case 0x0601B326u: goto L_0601B326; case 0x0601B328u: goto L_0601B328; case 0x0601B32Cu: goto L_0601B32C; case 0x0601B32Eu: goto L_0601B32E; case 0x0601B330u: goto L_0601B330; case 0x0601B332u: goto L_0601B332; case 0x0601B334u: goto L_0601B334; case 0x0601B336u: goto L_0601B336; case 0x0601B338u: goto L_0601B338; case 0x0601B33Au: goto L_0601B33A; case 0x0601B33Cu: goto L_0601B33C; case 0x0601B340u: goto L_0601B340; case 0x0601B342u: goto L_0601B342; case 0x0601B346u: goto L_0601B346; case 0x0601B348u: goto L_0601B348; case 0x0601B34Au: goto L_0601B34A; case 0x0601B34Eu: goto L_0601B34E; case 0x0601B350u: goto L_0601B350; case 0x0601B352u: goto L_0601B352; case 0x0601B354u: goto L_0601B354; case 0x0601B356u: goto L_0601B356; case 0x0601B358u: goto L_0601B358; case 0x0601B35Au: goto L_0601B35A; case 0x0601B35Cu: goto L_0601B35C; case 0x0601B35Eu: goto L_0601B35E; case 0x0601B360u: goto L_0601B360; case 0x0601B362u: goto L_0601B362; case 0x0601B364u: goto L_0601B364; case 0x0601B366u: goto L_0601B366; case 0x0601B368u: goto L_0601B368; case 0x0601B36Au: goto L_0601B36A; case 0x0601B36Cu: goto L_0601B36C; case 0x0601B36Eu: goto L_0601B36E; case 0x0601B370u: goto L_0601B370; case 0x0601B372u: goto L_0601B372; case 0x0601B374u: goto L_0601B374; case 0x0601B376u: goto L_0601B376; case 0x0601B378u: goto L_0601B378; case 0x0601B37Au: goto L_0601B37A; case 0x0601B37Eu: goto L_0601B37E; case 0x0601B380u: goto L_0601B380; case 0x0601B382u: goto L_0601B382; case 0x0601B384u: goto L_0601B384; case 0x0601B386u: goto L_0601B386; case 0x0601B388u: goto L_0601B388; case 0x0601B38Au: goto L_0601B38A; case 0x0601B38Cu: goto L_0601B38C; case 0x0601B38Eu: goto L_0601B38E; case 0x0601B392u: goto L_0601B392; case 0x0601B394u: goto L_0601B394; case 0x0601B398u: goto L_0601B398; case 0x0601B39Cu: goto L_0601B39C; case 0x0601B39Eu: goto L_0601B39E; case 0x0601B3A0u: goto L_0601B3A0; case 0x0601B3A2u: goto L_0601B3A2; case 0x0601B3A4u: goto L_0601B3A4; case 0x0601B3A6u: goto L_0601B3A6; case 0x0601B3A8u: goto L_0601B3A8; case 0x0601B3AAu: goto L_0601B3AA; case 0x0601B3ACu: goto L_0601B3AC; case 0x0601B3AEu: goto L_0601B3AE; case 0x0601B3B0u: goto L_0601B3B0; case 0x0601B3B2u: goto L_0601B3B2; case 0x0601B3B4u: goto L_0601B3B4; case 0x0601B3B6u: goto L_0601B3B6; case 0x0601B3B8u: goto L_0601B3B8; case 0x0601B3BAu: goto L_0601B3BA; case 0x0601B3BCu: goto L_0601B3BC; case 0x0601B3BEu: goto L_0601B3BE; case 0x0601B3C0u: goto L_0601B3C0; case 0x0601B3C2u: goto L_0601B3C2; case 0x0601B3C4u: goto L_0601B3C4; case 0x0601B3C6u: goto L_0601B3C6; case 0x0601B3C8u: goto L_0601B3C8; case 0x0601B3CAu: goto L_0601B3CA; case 0x0601B3CCu: goto L_0601B3CC; case 0x0601B3CEu: goto L_0601B3CE; case 0x0601B3D0u: goto L_0601B3D0; case 0x0601B3D2u: goto L_0601B3D2; case 0x0601B3D4u: goto L_0601B3D4; case 0x0601B3D6u: goto L_0601B3D6; case 0x0601B3D8u: goto L_0601B3D8; case 0x0601B3DAu: goto L_0601B3DA; case 0x0601B3DCu: goto L_0601B3DC; case 0x0601B3DEu: goto L_0601B3DE; case 0x0601B3E0u: goto L_0601B3E0; case 0x0601B3E2u: goto L_0601B3E2; case 0x0601B3E4u: goto L_0601B3E4; case 0x0601B3E6u: goto L_0601B3E6; case 0x0601B3E8u: goto L_0601B3E8; case 0x0601B3EAu: goto L_0601B3EA; case 0x0601B3ECu: goto L_0601B3EC; case 0x0601B3EEu: goto L_0601B3EE; case 0x0601B3F2u: goto L_0601B3F2; case 0x0601B3F4u: goto L_0601B3F4; case 0x0601B3F6u: goto L_0601B3F6; case 0x0601B3FAu: goto L_0601B3FA; case 0x0601B3FCu: goto L_0601B3FC; case 0x0601B3FEu: goto L_0601B3FE; case 0x0601B400u: goto L_0601B400; case 0x0601B402u: goto L_0601B402; case 0x0601B406u: goto L_0601B406; case 0x0601B408u: goto L_0601B408; case 0x0601B40Au: goto L_0601B40A; case 0x0601B40Cu: goto L_0601B40C; case 0x0601B410u: goto L_0601B410; case 0x0601B412u: goto L_0601B412; case 0x0601B414u: goto L_0601B414; case 0x0601B416u: goto L_0601B416; case 0x0601B418u: goto L_0601B418; case 0x0601B41Au: goto L_0601B41A; case 0x0601B41Cu: goto L_0601B41C; case 0x0601B41Eu: goto L_0601B41E; case 0x0601B420u: goto L_0601B420; case 0x0601B424u: goto L_0601B424; case 0x0601B426u: goto L_0601B426; case 0x0601B428u: goto L_0601B428; case 0x0601B42Au: goto L_0601B42A; case 0x0601B42Cu: goto L_0601B42C; case 0x0601B42Eu: goto L_0601B42E; case 0x0601B430u: goto L_0601B430; case 0x0601B458u: goto L_0601B458; case 0x0601B45Au: goto L_0601B45A; case 0x0601B45Cu: goto L_0601B45C; case 0x0601B45Eu: goto L_0601B45E; case 0x0601B460u: goto L_0601B460; case 0x0601B462u: goto L_0601B462; case 0x0601B464u: goto L_0601B464; case 0x0601B466u: goto L_0601B466; case 0x0601B46Au: goto L_0601B46A; case 0x0601B46Cu: goto L_0601B46C; case 0x0601B470u: goto L_0601B470; case 0x0601B472u: goto L_0601B472; case 0x0601B474u: goto L_0601B474; case 0x0601B476u: goto L_0601B476; case 0x0601B478u: goto L_0601B478; case 0x0601B47Au: goto L_0601B47A; case 0x0601B47Cu: goto L_0601B47C; case 0x0601B47Eu: goto L_0601B47E; case 0x0601B480u: goto L_0601B480; case 0x0601B482u: goto L_0601B482; case 0x0601B486u: goto L_0601B486; case 0x0601B488u: goto L_0601B488; case 0x0601B48Au: goto L_0601B48A; case 0x0601B48Cu: goto L_0601B48C; case 0x0601B48Eu: goto L_0601B48E; case 0x0601B490u: goto L_0601B490; case 0x0601B492u: goto L_0601B492; case 0x0601B494u: goto L_0601B494; case 0x0601B496u: goto L_0601B496; case 0x0601B49Au: goto L_0601B49A; case 0x0601B49Cu: goto L_0601B49C; case 0x0601B49Eu: goto L_0601B49E; case 0x0601B4A2u: goto L_0601B4A2; case 0x0601B4A4u: goto L_0601B4A4; case 0x0601B4A6u: goto L_0601B4A6; case 0x0601B4AAu: goto L_0601B4AA; case 0x0601B4ACu: goto L_0601B4AC; case 0x0601B4AEu: goto L_0601B4AE; case 0x0601B4B0u: goto L_0601B4B0; case 0x0601B4B2u: goto L_0601B4B2; case 0x0601B4B4u: goto L_0601B4B4; case 0x0601B4B6u: goto L_0601B4B6; case 0x0601B4B8u: goto L_0601B4B8; case 0x0601B4BAu: goto L_0601B4BA; case 0x0601B4BCu: goto L_0601B4BC; case 0x0601B4BEu: goto L_0601B4BE; case 0x0601B4C0u: goto L_0601B4C0; case 0x0601B4C2u: goto L_0601B4C2; case 0x0601B4C4u: goto L_0601B4C4; case 0x0601B4C6u: goto L_0601B4C6; case 0x0601B4C8u: goto L_0601B4C8; case 0x0601B4CAu: goto L_0601B4CA; case 0x0601B4CCu: goto L_0601B4CC; case 0x0601B4CEu: goto L_0601B4CE; case 0x0601B4D0u: goto L_0601B4D0; case 0x0601B4D2u: goto L_0601B4D2; case 0x0601B4D6u: goto L_0601B4D6; case 0x0601B4D8u: goto L_0601B4D8; case 0x0601B4DAu: goto L_0601B4DA; case 0x0601B4DCu: goto L_0601B4DC; case 0x0601B4DEu: goto L_0601B4DE; case 0x0601B4E0u: goto L_0601B4E0; case 0x0601B4E2u: goto L_0601B4E2; case 0x0601B4E4u: goto L_0601B4E4; case 0x0601B4E6u: goto L_0601B4E6; case 0x0601B4EAu: goto L_0601B4EA; case 0x0601B4ECu: goto L_0601B4EC; case 0x0601B4F0u: goto L_0601B4F0; case 0x0601B4F4u: goto L_0601B4F4; case 0x0601B4F6u: goto L_0601B4F6; case 0x0601B4F8u: goto L_0601B4F8; case 0x0601B4FAu: goto L_0601B4FA; case 0x0601B4FCu: goto L_0601B4FC; case 0x0601B4FEu: goto L_0601B4FE; case 0x0601B500u: goto L_0601B500; case 0x0601B502u: goto L_0601B502; case 0x0601B504u: goto L_0601B504; case 0x0601B506u: goto L_0601B506; case 0x0601B508u: goto L_0601B508; case 0x0601B50Au: goto L_0601B50A; case 0x0601B50Cu: goto L_0601B50C; case 0x0601B50Eu: goto L_0601B50E; case 0x0601B510u: goto L_0601B510; case 0x0601B512u: goto L_0601B512; case 0x0601B516u: goto L_0601B516; case 0x0601B51Au: goto L_0601B51A; case 0x0601B51Cu: goto L_0601B51C; case 0x0601B51Eu: goto L_0601B51E; case 0x0601B520u: goto L_0601B520; case 0x0601B522u: goto L_0601B522; case 0x0601B524u: goto L_0601B524; case 0x0601B526u: goto L_0601B526; case 0x0601B528u: goto L_0601B528; case 0x0601B52Au: goto L_0601B52A; case 0x0601B52Cu: goto L_0601B52C; case 0x0601B530u: goto L_0601B530; case 0x0601B532u: goto L_0601B532; case 0x0601B534u: goto L_0601B534; case 0x0601B536u: goto L_0601B536; case 0x0601B538u: goto L_0601B538; case 0x0601B53Au: goto L_0601B53A; case 0x0601B53Cu: goto L_0601B53C; case 0x0601B53Eu: goto L_0601B53E; case 0x0601B540u: goto L_0601B540; case 0x0601B542u: goto L_0601B542; case 0x0601B544u: goto L_0601B544; case 0x0601B546u: goto L_0601B546; case 0x0601B548u: goto L_0601B548; case 0x0601B54Au: goto L_0601B54A; case 0x0601B54Cu: goto L_0601B54C; case 0x0601B54Eu: goto L_0601B54E; case 0x0601B550u: goto L_0601B550; case 0x0601B552u: goto L_0601B552; case 0x0601B554u: goto L_0601B554; case 0x0601B556u: goto L_0601B556; case 0x0601B558u: goto L_0601B558; case 0x0601B57Cu: goto L_0601B57C; case 0x0601B57Eu: goto L_0601B57E; case 0x0601B580u: goto L_0601B580; case 0x0601B582u: goto L_0601B582; case 0x0601B584u: goto L_0601B584; case 0x0601B586u: goto L_0601B586; case 0x0601B588u: goto L_0601B588; case 0x0601B58Au: goto L_0601B58A; case 0x0601B58Cu: goto L_0601B58C; case 0x0601B58Eu: goto L_0601B58E; case 0x0601B590u: goto L_0601B590; case 0x0601B592u: goto L_0601B592; case 0x0601B594u: goto L_0601B594; case 0x0601B596u: goto L_0601B596; case 0x0601B598u: goto L_0601B598; case 0x0601B59Au: goto L_0601B59A; case 0x0601B59Cu: goto L_0601B59C; case 0x0601B59Eu: goto L_0601B59E; case 0x0601B5A0u: goto L_0601B5A0; case 0x0601B5A4u: goto L_0601B5A4; case 0x0601B5A6u: goto L_0601B5A6; case 0x0601B5A8u: goto L_0601B5A8; case 0x0601B5AAu: goto L_0601B5AA; case 0x0601B5ACu: goto L_0601B5AC; case 0x0601B5B0u: goto L_0601B5B0; case 0x0601B5B2u: goto L_0601B5B2; case 0x0601B5B4u: goto L_0601B5B4; case 0x0601B5B6u: goto L_0601B5B6; case 0x0601B5B8u: goto L_0601B5B8; case 0x0601B5BAu: goto L_0601B5BA; case 0x0601B5BEu: goto L_0601B5BE; case 0x0601B5C0u: goto L_0601B5C0; case 0x0601B5C2u: goto L_0601B5C2; case 0x0601B5C4u: goto L_0601B5C4; case 0x0601B5C6u: goto L_0601B5C6; case 0x0601B5C8u: goto L_0601B5C8; case 0x0601B5CAu: goto L_0601B5CA; case 0x0601B5CCu: goto L_0601B5CC; case 0x0601B5CEu: goto L_0601B5CE; case 0x0601B5D0u: goto L_0601B5D0; case 0x0601B5D2u: goto L_0601B5D2; case 0x0601B5D4u: goto L_0601B5D4; case 0x0601B5D6u: goto L_0601B5D6; case 0x0601B5D8u: goto L_0601B5D8; case 0x0601B5DAu: goto L_0601B5DA; case 0x0601B5DCu: goto L_0601B5DC; case 0x0601B5DEu: goto L_0601B5DE; case 0x0601B5E2u: goto L_0601B5E2; case 0x0601B5E4u: goto L_0601B5E4; case 0x0601B5E6u: goto L_0601B5E6; case 0x0601B5E8u: goto L_0601B5E8; case 0x0601B5EAu: goto L_0601B5EA; case 0x0601B5ECu: goto L_0601B5EC; case 0x0601B5EEu: goto L_0601B5EE; case 0x0601B5F0u: goto L_0601B5F0; case 0x0601B5F2u: goto L_0601B5F2; case 0x0601B5F4u: goto L_0601B5F4; case 0x0601B5F6u: goto L_0601B5F6; case 0x0601B5F8u: goto L_0601B5F8; case 0x0601B5FAu: goto L_0601B5FA; case 0x0601B5FCu: goto L_0601B5FC; case 0x0601B5FEu: goto L_0601B5FE; case 0x0601B602u: goto L_0601B602; case 0x0601B604u: goto L_0601B604; case 0x0601B608u: goto L_0601B608; case 0x0601B60Cu: goto L_0601B60C; case 0x0601B60Eu: goto L_0601B60E; case 0x0601B610u: goto L_0601B610; case 0x0601B612u: goto L_0601B612; case 0x0601B614u: goto L_0601B614; case 0x0601B616u: goto L_0601B616; case 0x0601B618u: goto L_0601B618; case 0x0601B61Au: goto L_0601B61A; case 0x0601B61Cu: goto L_0601B61C; case 0x0601B61Eu: goto L_0601B61E; case 0x0601B620u: goto L_0601B620; case 0x0601B622u: goto L_0601B622; case 0x0601B624u: goto L_0601B624; case 0x0601B626u: goto L_0601B626; case 0x0601B628u: goto L_0601B628; case 0x0601B62Au: goto L_0601B62A; case 0x0601B62Cu: goto L_0601B62C; case 0x0601B62Eu: goto L_0601B62E; case 0x0601B630u: goto L_0601B630; case 0x0601B632u: goto L_0601B632; case 0x0601B634u: goto L_0601B634; case 0x0601B636u: goto L_0601B636; case 0x0601B638u: goto L_0601B638; case 0x0601B63Au: goto L_0601B63A; case 0x0601B63Cu: goto L_0601B63C; case 0x0601B63Eu: goto L_0601B63E; case 0x0601B640u: goto L_0601B640; case 0x0601B642u: goto L_0601B642; case 0x0601B644u: goto L_0601B644; case 0x0601B646u: goto L_0601B646; case 0x0601B648u: goto L_0601B648; case 0x0601B64Au: goto L_0601B64A; case 0x0601B64Cu: goto L_0601B64C; case 0x0601B64Eu: goto L_0601B64E; case 0x0601B650u: goto L_0601B650; case 0x0601B652u: goto L_0601B652; case 0x0601B654u: goto L_0601B654; case 0x0601B656u: goto L_0601B656; case 0x0601B658u: goto L_0601B658; case 0x0601B65Au: goto L_0601B65A; case 0x0601B65Cu: goto L_0601B65C; case 0x0601B65Eu: goto L_0601B65E; case 0x0601B660u: goto L_0601B660; case 0x0601B664u: goto L_0601B664; case 0x0601B666u: goto L_0601B666; case 0x0601B66Au: goto L_0601B66A; case 0x0601B66Cu: goto L_0601B66C; case 0x0601B66Eu: goto L_0601B66E; case 0x0601B670u: goto L_0601B670; case 0x0601B672u: goto L_0601B672; case 0x0601B674u: goto L_0601B674; case 0x0601B676u: goto L_0601B676; case 0x0601B678u: goto L_0601B678; case 0x0601B67Au: goto L_0601B67A; case 0x0601B67Eu: goto L_0601B67E; case 0x0601B682u: goto L_0601B682; case 0x0601B684u: goto L_0601B684; case 0x0601B688u: goto L_0601B688; case 0x0601B68Au: goto L_0601B68A; case 0x0601B68Cu: goto L_0601B68C; case 0x0601B68Eu: goto L_0601B68E; case 0x0601B690u: goto L_0601B690; case 0x0601B692u: goto L_0601B692; case 0x0601B696u: goto L_0601B696; case 0x0601B698u: goto L_0601B698; case 0x0601B69Au: goto L_0601B69A; case 0x0601B69Cu: goto L_0601B69C; case 0x0601B69Eu: goto L_0601B69E; case 0x0601B6A0u: goto L_0601B6A0; case 0x0601B6A4u: goto L_0601B6A4; case 0x0601B6A6u: goto L_0601B6A6; case 0x0601B6A8u: goto L_0601B6A8; case 0x0601B6AAu: goto L_0601B6AA; case 0x0601B6ACu: goto L_0601B6AC; case 0x0601B6AEu: goto L_0601B6AE; case 0x0601B6B0u: goto L_0601B6B0; case 0x0601B6B2u: goto L_0601B6B2; case 0x0601B6B4u: goto L_0601B6B4; case 0x0601B6B6u: goto L_0601B6B6; case 0x0601B6B8u: goto L_0601B6B8; case 0x0601B6BAu: goto L_0601B6BA; case 0x0601B6BCu: goto L_0601B6BC; case 0x0601B6BEu: goto L_0601B6BE; case 0x0601B6C0u: goto L_0601B6C0; case 0x0601B6C2u: goto L_0601B6C2; case 0x0601B6C4u: goto L_0601B6C4; case 0x0601B6C8u: goto L_0601B6C8; case 0x0601B6CAu: goto L_0601B6CA; case 0x0601B6CEu: goto L_0601B6CE; case 0x0601B6D0u: goto L_0601B6D0; case 0x0601B6D2u: goto L_0601B6D2; case 0x0601B6D4u: goto L_0601B6D4; case 0x0601B6D6u: goto L_0601B6D6; case 0x0601B6D8u: goto L_0601B6D8; case 0x0601B6DAu: goto L_0601B6DA; case 0x0601B6DCu: goto L_0601B6DC; case 0x0601B6DEu: goto L_0601B6DE; case 0x0601B6E0u: goto L_0601B6E0; case 0x0607EB7Cu: goto L_0607EB7C; case 0x0607EB7Eu: goto L_0607EB7E; case 0x0607EB80u: goto L_0607EB80; case 0x0607EB82u: goto L_0607EB82; case 0x0607EB84u: goto L_0607EB84; case 0x0607EB86u: goto L_0607EB86; case 0x0607EB88u: goto L_0607EB88; case 0x0607EB8Au: goto L_0607EB8A; case 0x0607EB8Cu: goto L_0607EB8C; case 0x0607EB8Eu: goto L_0607EB8E; case 0x0607EB90u: goto L_0607EB90; case 0x0607EB92u: goto L_0607EB92; case 0x0607EB94u: goto L_0607EB94; case 0x0607EB96u: goto L_0607EB96; case 0x0607EB98u: goto L_0607EB98; case 0x0607EB9Au: goto L_0607EB9A; case 0x0607EB9Cu: goto L_0607EB9C; case 0x0607EB9Eu: goto L_0607EB9E; case 0x0607EBA0u: goto L_0607EBA0; case 0x0607EBA2u: goto L_0607EBA2; case 0x0607EBA4u: goto L_0607EBA4; case 0x0607EBA6u: goto L_0607EBA6; case 0x0607EBA8u: goto L_0607EBA8; case 0x0607EBAAu: goto L_0607EBAA; case 0x0607EBACu: goto L_0607EBAC; case 0x0607EBAEu: goto L_0607EBAE; case 0x0607EBB0u: goto L_0607EBB0; case 0x0607EBB2u: goto L_0607EBB2; case 0x0607EBB4u: goto L_0607EBB4; case 0x0607EBB6u: goto L_0607EBB6; case 0x0607EBBAu: goto L_0607EBBA; case 0x0607EBBCu: goto L_0607EBBC; case 0x0607EBBEu: goto L_0607EBBE; case 0x0607EBC2u: goto L_0607EBC2; case 0x0607EBC4u: goto L_0607EBC4; case 0x0607EBC6u: goto L_0607EBC6; case 0x0607EBC8u: goto L_0607EBC8; case 0x0607EBCAu: goto L_0607EBCA; case 0x0607EBCCu: goto L_0607EBCC; case 0x0607EBD0u: goto L_0607EBD0; case 0x0607EBD2u: goto L_0607EBD2; case 0x0607EBD4u: goto L_0607EBD4; case 0x0607EBD6u: goto L_0607EBD6; case 0x0607EBD8u: goto L_0607EBD8; case 0x0607EBDAu: goto L_0607EBDA; case 0x0607EBDCu: goto L_0607EBDC; case 0x0607EBDEu: goto L_0607EBDE; case 0x0607EBE0u: goto L_0607EBE0; case 0x0607EBE2u: goto L_0607EBE2; case 0x0607EBE4u: goto L_0607EBE4; case 0x0607EBE6u: goto L_0607EBE6; case 0x0607EBE8u: goto L_0607EBE8; case 0x0607EBEAu: goto L_0607EBEA; case 0x0607EBECu: goto L_0607EBEC; case 0x0607EBEEu: goto L_0607EBEE; case 0x0607EBF0u: goto L_0607EBF0; case 0x0607EBF2u: goto L_0607EBF2; case 0x0607EBF4u: goto L_0607EBF4; case 0x0607EBF6u: goto L_0607EBF6; case 0x0607EBF8u: goto L_0607EBF8; case 0x0607EBFCu: goto L_0607EBFC; case 0x0607EBFEu: goto L_0607EBFE; case 0x0607EC02u: goto L_0607EC02; case 0x0607EC04u: goto L_0607EC04; case 0x0607EC06u: goto L_0607EC06; case 0x0607EC08u: goto L_0607EC08; case 0x0607EC0Au: goto L_0607EC0A; case 0x0607EC0Cu: goto L_0607EC0C; case 0x0607EC0Eu: goto L_0607EC0E; case 0x0607EC10u: goto L_0607EC10; case 0x0607EC12u: goto L_0607EC12; case 0x0607EC14u: goto L_0607EC14; case 0x0607EC16u: goto L_0607EC16; case 0x0607EC18u: goto L_0607EC18; case 0x0607EC1Au: goto L_0607EC1A; case 0x0607EC1Cu: goto L_0607EC1C; case 0x0607EC1Eu: goto L_0607EC1E; case 0x0607EC20u: goto L_0607EC20; case 0x0607EC22u: goto L_0607EC22; case 0x0607EC26u: goto L_0607EC26; case 0x0607EC28u: goto L_0607EC28; case 0x0607EC2Au: goto L_0607EC2A; case 0x0607EC2Cu: goto L_0607EC2C; case 0x0607EC2Eu: goto L_0607EC2E; case 0x0607EC30u: goto L_0607EC30; case 0x0607EC32u: goto L_0607EC32; case 0x0607EC34u: goto L_0607EC34; case 0x0607EC36u: goto L_0607EC36; case 0x0607EC38u: goto L_0607EC38; case 0x0607EC3Au: goto L_0607EC3A; case 0x0607EC3Cu: goto L_0607EC3C; case 0x0607EC3Eu: goto L_0607EC3E; case 0x0607EC40u: goto L_0607EC40; case 0x0607EC42u: goto L_0607EC42; case 0x0607EC44u: goto L_0607EC44; case 0x0607EC46u: goto L_0607EC46; case 0x0607EC48u: goto L_0607EC48; case 0x0607EC4Au: goto L_0607EC4A; case 0x0607EC4Cu: goto L_0607EC4C; case 0x0607EC50u: goto L_0607EC50; case 0x0607EC52u: goto L_0607EC52; case 0x0607EC54u: goto L_0607EC54; case 0x0607EC56u: goto L_0607EC56; case 0x0607EC58u: goto L_0607EC58; case 0x0607EC5Au: goto L_0607EC5A; case 0x0607EC5Cu: goto L_0607EC5C; case 0x0607EC5Eu: goto L_0607EC5E; case 0x0607EC60u: goto L_0607EC60; case 0x0607EC64u: goto L_0607EC64; case 0x0607EC66u: goto L_0607EC66; case 0x0607EC68u: goto L_0607EC68; case 0x0607EC6Au: goto L_0607EC6A; case 0x0607EC6Cu: goto L_0607EC6C; case 0x0607EC6Eu: goto L_0607EC6E; case 0x0607EC70u: goto L_0607EC70; case 0x0607EC74u: goto L_0607EC74; case 0x0607EC76u: goto L_0607EC76; case 0x0607EC78u: goto L_0607EC78; case 0x0607EC7Au: goto L_0607EC7A; case 0x0607EC7Cu: goto L_0607EC7C; case 0x0607EC7Eu: goto L_0607EC7E; case 0x0607EC80u: goto L_0607EC80; case 0x0607EC82u: goto L_0607EC82; case 0x0607EC84u: goto L_0607EC84; case 0x0607EC86u: goto L_0607EC86; case 0x0607EC88u: goto L_0607EC88; case 0x0607EC8Au: goto L_0607EC8A; case 0x0607EC8Cu: goto L_0607EC8C; case 0x0607EC8Eu: goto L_0607EC8E; case 0x0607EC90u: goto L_0607EC90; case 0x0607EC92u: goto L_0607EC92; case 0x0607EC94u: goto L_0607EC94; case 0x0607EC96u: goto L_0607EC96; case 0x0607EC98u: goto L_0607EC98; case 0x0607EC9Au: goto L_0607EC9A; case 0x0607EC9Cu: goto L_0607EC9C; case 0x0607EC9Eu: goto L_0607EC9E; case 0x0607ECA0u: goto L_0607ECA0; case 0x0607ECA2u: goto L_0607ECA2; case 0x0607ECA4u: goto L_0607ECA4; case 0x0607ECA8u: goto L_0607ECA8; case 0x0607ECAAu: goto L_0607ECAA; case 0x0607ECACu: goto L_0607ECAC; case 0x0607ECAEu: goto L_0607ECAE; case 0x0607ECB0u: goto L_0607ECB0; case 0x0607ECB2u: goto L_0607ECB2; case 0x0607ECB4u: goto L_0607ECB4; case 0x0607ECB6u: goto L_0607ECB6; case 0x0607ECB8u: goto L_0607ECB8; case 0x0607ECBAu: goto L_0607ECBA; case 0x0607ECBCu: goto L_0607ECBC; case 0x0607ECBEu: goto L_0607ECBE; case 0x0607ECC0u: goto L_0607ECC0; case 0x0607ECC2u: goto L_0607ECC2; case 0x0607ECC4u: goto L_0607ECC4; case 0x0607ECC6u: goto L_0607ECC6; case 0x0607ECC8u: goto L_0607ECC8; case 0x0607ECCAu: goto L_0607ECCA; case 0x0607ECCCu: goto L_0607ECCC; case 0x0607ECCEu: goto L_0607ECCE; case 0x0607ECD0u: goto L_0607ECD0; case 0x0607ECD2u: goto L_0607ECD2; case 0x0607ECD6u: goto L_0607ECD6; case 0x0607ECD8u: goto L_0607ECD8; case 0x0607ECDAu: goto L_0607ECDA; case 0x0607ECDCu: goto L_0607ECDC; case 0x0607ECDEu: goto L_0607ECDE; case 0x0607ECE0u: goto L_0607ECE0; case 0x0607ECE4u: goto L_0607ECE4; case 0x0607ECE8u: goto L_0607ECE8; case 0x0607ECEAu: goto L_0607ECEA; case 0x0607EE54u: goto L_0607EE54; case 0x0607EE56u: goto L_0607EE56; case 0x0607EE58u: goto L_0607EE58; case 0x0607EE5Au: goto L_0607EE5A; case 0x0607EE5Cu: goto L_0607EE5C; case 0x0607EE5Eu: goto L_0607EE5E; case 0x0607EE60u: goto L_0607EE60; case 0x0607EE62u: goto L_0607EE62; case 0x0608431Eu: goto L_0608431E; case 0x06084320u: goto L_06084320; case 0x06084322u: goto L_06084322; case 0x06084324u: goto L_06084324; case 0x06084326u: goto L_06084326; case 0x06084328u: goto L_06084328; case 0x0608432Au: goto L_0608432A; case 0x0608432Cu: goto L_0608432C; case 0x06084330u: goto L_06084330; case 0x06084332u: goto L_06084332; case 0x06084334u: goto L_06084334; case 0x06084336u: goto L_06084336; case 0x06084338u: goto L_06084338; case 0x0608433Au: goto L_0608433A; case 0x0608433Cu: goto L_0608433C; case 0x0608433Eu: goto L_0608433E; case 0x06084340u: goto L_06084340; case 0x06084342u: goto L_06084342; case 0x06084344u: goto L_06084344; case 0x06084346u: goto L_06084346; case 0x06084348u: goto L_06084348; case 0x0608434Au: goto L_0608434A; case 0x0608434Cu: goto L_0608434C; case 0x0608434Eu: goto L_0608434E; case 0x06084350u: goto L_06084350; case 0x06084352u: goto L_06084352; case 0x06084354u: goto L_06084354; case 0x06084356u: goto L_06084356; case 0x06084358u: goto L_06084358; case 0x0608435Au: goto L_0608435A; case 0x0608435Cu: goto L_0608435C; case 0x0608435Eu: goto L_0608435E; case 0x06084362u: goto L_06084362; case 0x06084364u: goto L_06084364; default: sh2_call(c, x); return; } }  // 06084364 jmp @r0 ; nop
}

void f_0601B120(SH2Context& c) {
    ran[261] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601B120 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601B122 sts.l pr,@-r15
    c.r[3] = ld32(0x0601B240u);  // 0601B124 mov.l 0x0601B240,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0601B126 mov.w @r3,r2
    c.r[7] = ld32(0x0601B244u);  // 0601B128 mov.l 0x0601B244,r7
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[7]);  // 0601B12A mov.w @r7,r1
    c.r[2] |= c.r[1];  // 0601B12C or r1,r2
    st16(c.r[3], c.r[2]);  // 0601B12E mov.w r2,@r3
    c.r[1] = 0x0u;  // 0601B130 mov #0,r1
    st16(c.r[7], c.r[1]);  // 0601B132 mov.w r1,@r7
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601B232u);  // 0601B134 mov.w 0x0601B232,r1
    c.r[1] &= c.r[2];  // 0601B136 and r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601B138 tst r1,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0601B144; } }  // 0601B13A bt/s 0x0601B144 ; mov r15,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601B234u);  // 0601B13E mov.w 0x0601B234,r0
    c.r[15] = c.r[14]; goto L_0601B6D2;  // 0601B140 bra 0x0601B6D2 ; mov r14,r15
L_0601B144:
    c.r[0] = c.r[2];  // 0601B144 mov r2,r0
    c.r[0] >>= 8;  // 0601B146 shlr8 r0
    c.r[0] &= 0x1u;  // 0601B148 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601B14A tst r0,r0
    if (c.t) { goto L_0601B156; }  // 0601B14C bt 0x0601B156
    c.r[15] = c.r[14];  // 0601B14E mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601B236u);  // 0601B150 mov.w 0x0601B236,r0
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; } goto L_0601B6D4;  // 0601B152 bra 0x0601B6D4 ; lds.l @r15+,pr
L_0601B156:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601B238u);  // 0601B156 mov.w 0x0601B238,r1
    c.r[2] &= c.r[1];  // 0601B158 and r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0601B15A tst r2,r2
    if (c.t) { goto L_0601B162; }  // 0601B15C bt 0x0601B162
    goto L_0601B46A;  // 0601B15E bra 0x0601B46A ; nop
L_0601B162:
    c.r[1] = ld32(0x0601B248u);  // 0601B162 mov.l 0x0601B248,r1
    c.r[9] = ld32(c.r[1]);  // 0601B164 mov.l @r1,r9
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0601B166 mov.b @r9,r0
    c.r[0] &= 0xC0u;  // 0601B168 and #192,r0
    c.r[0] >>= 2;  // 0601B16A shlr2 r0
    c.r[0] >>= 2;  // 0601B16C shlr2 r0
    c.r[0] >>= 2;  // 0601B16E shlr2 r0
    c.t = c.r[0] == 0x1u;  // 0601B170 cmp/eq #1,r0
    { const bool k = c.t; c.t = (c.r[9] & c.r[9]) == 0; if (k) { goto L_0601B18C; } }  // 0601B172 bt/s 0x0601B18C ; tst r9,r9
    c.r[1] = ld32(0x0601B24Cu);  // 0601B176 mov.l 0x0601B24C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B178 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0601B17A extu.b r1,r0
    c.r[1] = ld32(0x0601B250u);  // 0601B17C mov.l 0x0601B250,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601B17E mov.b @(r0,r1),r5
    c.r[4] = c.r[9];  // 0601B180 mov r9,r4
    c.r[0] = ld32(0x0601B254u);  // 0601B182 mov.l 0x0601B254,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601B188u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601B188u) return; }  // 0601B184 jsr @r0 ; extu.b r5,r5
    c.r[9] = c.r[0];  // 0601B188 mov r0,r9
    c.t = (c.r[9] & c.r[9]) == 0;  // 0601B18A tst r9,r9
L_0601B18C:
    { const bool k = !c.t; c.r[4] = 0x0u; if (k) { goto L_0601B194; } }  // 0601B18C bf/s 0x0601B194 ; mov #0,r4
    goto L_0601B6C8;  // 0601B190 bra 0x0601B6C8 ; nop
L_0601B194:
    c.r[1] = ld32(0x0601B258u);  // 0601B194 mov.l 0x0601B258,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B196 mov.b @r1,r0
    c.r[7] = 0x3u;  // 0601B198 mov #3,r7
    c.r[3] = 0x0u;  // 0601B19A mov #0,r3
    c.r[2] = ld32(0x0601B25Cu);  // 0601B19C mov.l 0x0601B25C,r2
    c.r[0] &= 0xFEu;  // 0601B19E and #254,r0
    st8(c.r[1], c.r[0]);  // 0601B1A0 mov.b r0,@r1
L_0601B1A2:
    c.r[1] = c.r[2];  // 0601B1A2 mov r2,r1
    c.r[1] += 2;  // 0601B1A4 add #2,r1
    st8(c.r[1], c.r[3]);  // 0601B1A6 mov.b r3,@r1
    c.r[4] += 1;  // 0601B1A8 add #1,r4
    c.t = (int32_t)c.r[4] > (int32_t)c.r[7];  // 0601B1AA cmp/gt r7,r4
    { const bool k = !c.t; c.r[2] += 3; if (k) { SH2_POLL(c); goto L_0601B1A2; } }  // 0601B1AC bf/s 0x0601B1A2 ; add #3,r2
    c.r[7] = c.r[9];  // 0601B1B0 mov r9,r7
    c.r[7] += 2;  // 0601B1B2 add #2,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0601B1B4 mov.b @r7,r1
    c.r[0] = c.r[1];  // 0601B1B6 mov r1,r0
    c.r[0] >>= 2;  // 0601B1B8 shlr2 r0
    c.r[0] >>= 2;  // 0601B1BA shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0601B1BC shlr r0
    c.r[0] >>= 2;  // 0601B1BE shlr2 r0
    c.r[0] &= 0x1u;  // 0601B1C0 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601B1C2 tst r0,r0
    { const bool k = c.t; c.r[0] = c.r[1]; if (k) { goto L_0601B1E2; } }  // 0601B1C4 bt/s 0x0601B1E2 ; mov r1,r0
    c.r[1] = ld32(0x0601B258u);  // 0601B1C8 mov.l 0x0601B258,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B1CA mov.b @r1,r0
    c.r[2] = ld32(0x0601B25Cu);  // 0601B1CC mov.l 0x0601B25C,r2
    c.r[3] = c.r[2];  // 0601B1CE mov r2,r3
    c.r[3] += 8;  // 0601B1D0 add #8,r3
    c.r[2] += 11;  // 0601B1D2 add #11,r2
    c.r[0] |= 0x1u;  // 0601B1D4 or #1,r0
    st8(c.r[1], c.r[0]);  // 0601B1D6 mov.b r0,@r1
    c.r[1] = 0x1u;  // 0601B1D8 mov #1,r1
    st8(c.r[2], c.r[1]);  // 0601B1DA mov.b r1,@r2
    st8(c.r[3], c.r[1]);  // 0601B1DC mov.b r1,@r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0601B1DE mov.b @r7,r1
    c.r[0] = c.r[1];  // 0601B1E0 mov r1,r0
L_0601B1E2:
    c.r[0] >>= 2;  // 0601B1E2 shlr2 r0
    c.r[0] >>= 2;  // 0601B1E4 shlr2 r0
    c.r[0] >>= 2;  // 0601B1E6 shlr2 r0
    c.r[0] &= 0x1u;  // 0601B1E8 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601B1EA tst r0,r0
    if (c.t) { goto L_0601B204; }  // 0601B1EC bt 0x0601B204
    c.r[1] = ld32(0x0601B258u);  // 0601B1EE mov.l 0x0601B258,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B1F0 mov.b @r1,r0
    c.r[2] = ld32(0x0601B25Cu);  // 0601B1F2 mov.l 0x0601B25C,r2
    c.r[3] = c.r[2];  // 0601B1F4 mov r2,r3
    c.r[3] += 2;  // 0601B1F6 add #2,r3
    c.r[2] += 5;  // 0601B1F8 add #5,r2
    c.r[0] |= 0x1u;  // 0601B1FA or #1,r0
    st8(c.r[1], c.r[0]);  // 0601B1FC mov.b r0,@r1
    c.r[1] = 0x1u;  // 0601B1FE mov #1,r1
    st8(c.r[2], c.r[1]);  // 0601B200 mov.b r1,@r2
    st8(c.r[3], c.r[1]);  // 0601B202 mov.b r1,@r3
L_0601B204:
    c.r[1] = ld32(0x0601B240u);  // 0601B204 mov.l 0x0601B240,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0601B206 mov.w @r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0601B23Au);  // 0601B208 mov.w 0x0601B23A,r2
    c.r[2] &= c.r[1];  // 0601B20A and r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0601B20C tst r2,r2
    if (!c.t) { goto L_0601B214; }  // 0601B20E bf 0x0601B214
    goto L_0601B36E;  // 0601B210 bra 0x0601B36E ; nop
L_0601B214:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0601B214 mov.b @r9,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601B23Cu);  // 0601B216 mov.w 0x0601B23C,r0
    c.r[1] &= c.r[0];  // 0601B218 and r0,r1
    c.r[1] >>= 2;  // 0601B21A shlr2 r1
    c.r[1] >>= 2;  // 0601B21C shlr2 r1
    c.r[1] >>= 2;  // 0601B21E shlr2 r1
    c.r[0] = c.r[1];  // 0601B220 mov r1,r0
    c.t = c.r[0] == 0x1u;  // 0601B222 cmp/eq #1,r0
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_0601B260; } }  // 0601B224 bt/s 0x0601B260 ; mov r9,r1
    c.t = c.r[0] == 0x2u;  // 0601B228 cmp/eq #2,r0
    { const bool k = c.t; c.r[1] += 4; if (k) { goto L_0601B312; } }  // 0601B22A bt/s 0x0601B312 ; add #4,r1
    goto L_0601B32C;  // 0601B22E bra 0x0601B32C ; nop
L_0601B260:
    c.r[1] += 5;  // 0601B260 add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B262 mov.b @r1,r1
    c.r[10] = c.r[1] & 0xFFu;  // 0601B264 extu.b r1,r10
    c.r[1] = c.r[9];  // 0601B266 mov r9,r1
    c.r[1] += 4;  // 0601B268 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B26A mov.b @r1,r1
    c.r[13] = ld32(0x0601B438u);  // 0601B26C mov.l 0x0601B438,r13
    c.r[8] = c.r[1] & 0xFFu;  // 0601B26E extu.b r1,r8
    c.r[1] = ld32(0x0601B43Cu);  // 0601B270 mov.l 0x0601B43C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B272 mov.b @r1,r1
    c.r[7] = ld32(0x0601B440u);  // 0601B274 mov.l 0x0601B440,r7
    c.r[12] = c.r[1] & 0xFFu;  // 0601B276 extu.b r1,r12
    c.r[0] = c.r[12];  // 0601B278 mov r12,r0
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[13]);  // 0601B27A mov.b @(r0,r13),r11
    c.r[5] = c.r[8];  // 0601B27C mov r8,r5
    c.r[6] = c.r[11] & 0xFFu;  // 0601B27E extu.b r11,r6
    { const uint32_t x = c.r[7]; c.pr = 0x0601B284u; c.r[4] = c.r[6]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601B284u) return; }  // 0601B280 jsr @r7 ; mov r6,r4
    c.r[7] = c.r[0];  // 0601B284 mov r0,r7
    c.macl = c.r[7] * c.r[8];  // 0601B286 mul.l r8,r7
    c.r[0] = c.r[6];  // 0601B288 mov r6,r0
    c.r[1] = c.macl;  // 0601B28A sts macl,r1
    c.r[0] -= c.r[1];  // 0601B28C sub r1,r0
    c.r[1] = c.r[0];  // 0601B28E mov r0,r1
    c.t = (int32_t)c.r[1] > 0;  // 0601B290 cmp/pl r1
    { const bool k = !c.t; c.r[1] = c.r[11]; if (k) { goto L_0601B29E; } }  // 0601B292 bf/s 0x0601B29E ; mov r11,r1
    c.r[1] -= 1;  // 0601B296 add #-1,r1
    c.r[0] = c.r[12];  // 0601B298 mov r12,r0
    st8(c.r[0] + c.r[13], c.r[1]); goto L_0601B358;  // 0601B29A bra 0x0601B358 ; mov.b r1,@(r0,r13)
L_0601B29E:
    c.r[1] = c.r[9];  // 0601B29E mov r9,r1
    c.r[1] += 1;  // 0601B2A0 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B2A2 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0601B2A4 mov r1,r0
    c.r[0] >>= 2;  // 0601B2A6 shlr2 r0
    c.r[0] >>= 2;  // 0601B2A8 shlr2 r0
    c.r[0] >>= 2;  // 0601B2AA shlr2 r0
    c.r[0] &= 0x1u;  // 0601B2AC and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601B2AE tst r0,r0
    { const bool k = !c.t; c.r[4] = c.r[6]; if (k) { goto L_0601B2B8; } }  // 0601B2B0 bf/s 0x0601B2B8 ; mov r6,r4
    goto L_0601B46A;  // 0601B2B4 bra 0x0601B46A ; nop
L_0601B2B8:
    c.r[1] = c.r[9];  // 0601B2B8 mov r9,r1
    c.r[1] += 8;  // 0601B2BA add #8,r1
    c.r[3] = c.r[12];  // 0601B2BC mov r12,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B2BE mov.b @r1,r1
    c.r[0] = c.r[3];  // 0601B2C0 mov r3,r0
    c.r[2] = c.r[1] & 0xFFu;  // 0601B2C2 extu.b r1,r2
    c.r[1] = c.r[9];  // 0601B2C4 mov r9,r1
    c.r[1] += 9;  // 0601B2C6 add #9,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B2C8 mov.b @r1,r1
    c.r[2] <<= 8;  // 0601B2CA shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0601B2CC extu.b r1,r1
    c.r[2] |= c.r[1];  // 0601B2CE or r1,r2
    c.r[1] = ld32(0x0601B444u);  // 0601B2D0 mov.l 0x0601B444,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601B2D2 mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601B2D4 extu.b r1,r1
    c.r[1] -= 1;  // 0601B2D6 add #-1,r1
    c.macl = c.r[1] * c.r[10];  // 0601B2D8 mul.l r10,r1
    c.r[4] += c.r[8]; goto L_0601B2F2;  // 0601B2DA bra 0x0601B2F2 ; add r8,r4
L_0601B2DE:
    c.r[1] = ld32(0x0601B438u);  // 0601B2DE mov.l 0x0601B438,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601B2E0 mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601B2E2 extu.b r1,r1
    c.t = (int32_t)c.r[4] > (int32_t)c.r[1];  // 0601B2E4 cmp/gt r1,r4
    if (!c.t) { goto L_0601B306; }  // 0601B2E6 bf 0x0601B306
    c.r[1] = ld32(0x0601B444u);  // 0601B2E8 mov.l 0x0601B444,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601B2EA mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601B2EC extu.b r1,r1
    c.r[1] -= 1;  // 0601B2EE add #-1,r1
    c.macl = c.r[1] * c.r[10];  // 0601B2F0 mul.l r10,r1
L_0601B2F2:
    c.r[1] = c.macl;  // 0601B2F2 sts macl,r1
    c.macl = c.r[1] * c.r[8];  // 0601B2F4 mul.l r8,r1
    c.r[4] -= 1;  // 0601B2F6 add #-1,r4
    c.r[0] = c.r[2];  // 0601B2F8 mov r2,r0
    c.r[1] = c.macl;  // 0601B2FA sts macl,r1
    c.r[0] -= c.r[1];  // 0601B2FC sub r1,r0
    c.r[1] = c.r[0];  // 0601B2FE mov r0,r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[4];  // 0601B300 cmp/gt r4,r1
    { const bool k = !c.t; c.r[0] = c.r[3]; if (k) { SH2_POLL(c); goto L_0601B2DE; } }  // 0601B302 bf/s 0x0601B2DE ; mov r3,r0
L_0601B306:
    c.r[1] = ld32(0x0601B43Cu);  // 0601B306 mov.l 0x0601B43C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B308 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0601B30A extu.b r1,r0
    c.r[1] = ld32(0x0601B438u);  // 0601B30C mov.l 0x0601B438,r1
    st8(c.r[0] + c.r[1], c.r[4]); goto L_0601B358;  // 0601B30E bra 0x0601B358 ; mov.b r4,@(r0,r1)
L_0601B312:
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B312 mov.b @r1,r3
    c.r[2] = c.r[3] & 0xFFu;  // 0601B314 extu.b r3,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601B434u);  // 0601B316 mov.w 0x0601B434,r1
    c.t = c.r[2] == c.r[1];  // 0601B318 cmp/eq r1,r2
    if (!c.t) { goto L_0601B320; }  // 0601B31A bf 0x0601B320
    goto L_0601B46A;  // 0601B31C bra 0x0601B46A ; nop
L_0601B320:
    c.r[1] = ld32(0x0601B43Cu);  // 0601B320 mov.l 0x0601B43C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B322 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0601B324 extu.b r1,r0
    c.r[1] = ld32(0x0601B438u);  // 0601B326 mov.l 0x0601B438,r1
    st8(c.r[0] + c.r[1], c.r[3]); goto L_0601B358;  // 0601B328 bra 0x0601B358 ; mov.b r3,@(r0,r1)
L_0601B32C:
    c.r[10] = ld32(0x0601B43Cu);  // 0601B32C mov.l 0x0601B43C,r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0601B32E mov.b @r10,r1
    c.r[8] = ld32(0x0601B438u);  // 0601B330 mov.l 0x0601B438,r8
    c.r[3] = c.r[1] & 0xFFu;  // 0601B332 extu.b r1,r3
    c.r[0] = c.r[3];  // 0601B334 mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0601B336 mov.b @(r0,r8),r2
    c.r[1] = c.r[2] & 0xFFu;  // 0601B338 extu.b r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601B33A tst r1,r1
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_0601B346; } }  // 0601B33C bt/s 0x0601B346 ; mov r2,r1
    c.r[1] -= 1;  // 0601B340 add #-1,r1
    st8(c.r[0] + c.r[8], c.r[1]); goto L_0601B358;  // 0601B342 bra 0x0601B358 ; mov.b r1,@(r0,r8)
L_0601B346:
    c.r[1] = ld32(0x0601B448u);  // 0601B346 mov.l 0x0601B448,r1
    c.r[0] = ld32(0x0601B44Cu);  // 0601B348 mov.l 0x0601B44C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601B34Eu; c.r[4] = ld32(c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601B34Eu) return; }  // 0601B34A jsr @r0 ; mov.l @r1,r4
    c.r[2] = c.r[0];  // 0601B34E mov r0,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0601B350 mov.b @r10,r1
    c.r[2] -= 1;  // 0601B352 add #-1,r2
    c.r[0] = c.r[1] & 0xFFu;  // 0601B354 extu.b r1,r0
    st8(c.r[0] + c.r[8], c.r[2]);  // 0601B356 mov.b r2,@(r0,r8)
L_0601B358:
    c.r[1] = c.r[9];  // 0601B358 mov r9,r1
    c.r[1] += 1;  // 0601B35A add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B35C mov.b @r1,r1
    c.r[0] = c.r[1];  // 0601B35E mov r1,r0
    c.r[0] >>= 2;  // 0601B360 shlr2 r0
    c.r[0] >>= 2;  // 0601B362 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0601B364 shlr r0
    c.r[0] >>= 2;  // 0601B366 shlr2 r0
    c.r[0] &= 0x1u;  // 0601B368 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601B36A tst r0,r0
    if (!c.t) { goto L_0601B46A; }  // 0601B36C bf 0x0601B46A
L_0601B36E:
    c.r[1] = ld32(0x0601B450u);  // 0601B36E mov.l 0x0601B450,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0601B370 mov.w @r1,r1
    c.r[2] = ld32(0x0601B454u);  // 0601B372 mov.l 0x0601B454,r2
    c.r[2] &= c.r[1];  // 0601B374 and r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0601B376 tst r2,r2
    if (!c.t) { goto L_0601B37E; }  // 0601B378 bf 0x0601B37E
    goto L_0601B4C6;  // 0601B37A bra 0x0601B4C6 ; nop
L_0601B37E:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0601B37E mov.b @r9,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601B436u);  // 0601B380 mov.w 0x0601B436,r0
    c.r[1] &= c.r[0];  // 0601B382 and r0,r1
    c.r[1] >>= 2;  // 0601B384 shlr2 r1
    c.r[1] >>= 2;  // 0601B386 shlr2 r1
    c.r[1] >>= 2;  // 0601B388 shlr2 r1
    c.r[0] = c.r[1];  // 0601B38A mov r1,r0
    c.t = c.r[0] == 0x1u;  // 0601B38C cmp/eq #1,r0
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_0601B39C; } }  // 0601B38E bt/s 0x0601B39C ; mov r9,r1
    c.t = c.r[0] == 0x2u;  // 0601B392 cmp/eq #2,r0
    { const bool k = c.t; c.r[1] += 5; if (k) { goto L_0601B470; } }  // 0601B394 bt/s 0x0601B470 ; add #5,r1
    goto L_0601B486;  // 0601B398 bra 0x0601B486 ; nop
L_0601B39C:
    c.r[1] += 5;  // 0601B39C add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B39E mov.b @r1,r1
    c.r[10] = c.r[1] & 0xFFu;  // 0601B3A0 extu.b r1,r10
    c.r[1] = c.r[9];  // 0601B3A2 mov r9,r1
    c.r[1] += 4;  // 0601B3A4 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B3A6 mov.b @r1,r1
    c.r[8] = c.r[1] & 0xFFu;  // 0601B3A8 extu.b r1,r8
    c.r[1] = c.r[9];  // 0601B3AA mov r9,r1
    c.r[1] += 8;  // 0601B3AC add #8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B3AE mov.b @r1,r1
    c.macl = c.r[10] * c.r[8];  // 0601B3B0 mul.l r8,r10
    c.r[4] = c.r[1] & 0xFFu;  // 0601B3B2 extu.b r1,r4
    c.r[1] = c.r[9];  // 0601B3B4 mov r9,r1
    c.r[1] += 9;  // 0601B3B6 add #9,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B3B8 mov.b @r1,r1
    c.r[4] <<= 8;  // 0601B3BA shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 0601B3BC extu.b r1,r1
    c.r[4] |= c.r[1];  // 0601B3BE or r1,r4
    c.r[1] = ld32(0x0601B43Cu);  // 0601B3C0 mov.l 0x0601B43C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B3C2 mov.b @r1,r1
    c.r[10] = c.r[1] & 0xFFu;  // 0601B3C4 extu.b r1,r10
    c.r[1] = ld32(0x0601B444u);  // 0601B3C6 mov.l 0x0601B444,r1
    c.r[0] = c.r[10];  // 0601B3C8 mov r10,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601B3CA mov.b @(r0,r1),r1
    c.r[2] = c.macl;  // 0601B3CC sts macl,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0601B3CE extu.b r1,r1
    c.r[1] -= 1;  // 0601B3D0 add #-1,r1
    c.macl = c.r[2] * c.r[1];  // 0601B3D2 mul.l r1,r2
    c.r[1] = c.macl;  // 0601B3D4 sts macl,r1
    c.macl = c.r[2];  // 0601B3D6 lds r2,macl
    c.r[4] -= c.r[1];  // 0601B3D8 sub r1,r4
    c.r[1] = c.macl;  // 0601B3DA sts macl,r1
    c.t = (int32_t)c.r[4] > (int32_t)c.r[1];  // 0601B3DC cmp/gt r1,r4
    if (!c.t) { goto L_0601B3E2; }  // 0601B3DE bf 0x0601B3E2
    c.r[4] = c.macl;  // 0601B3E0 sts macl,r4
L_0601B3E2:
    c.r[12] = ld32(0x0601B438u);  // 0601B3E2 mov.l 0x0601B438,r12
    c.r[0] = c.r[10];  // 0601B3E4 mov r10,r0
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[12]);  // 0601B3E6 mov.b @(r0,r12),r11
    c.r[6] = c.r[11] & 0xFFu;  // 0601B3E8 extu.b r11,r6
    c.r[6] += 1;  // 0601B3EA add #1,r6
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[4];  // 0601B3EC cmp/ge r4,r6
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_0601B410; } }  // 0601B3EE bt/s 0x0601B410 ; mov r9,r1
    c.r[4] = c.r[6];  // 0601B3F2 mov r6,r4
    c.r[7] = ld32(0x0601B440u);  // 0601B3F4 mov.l 0x0601B440,r7
    { const uint32_t x = c.r[7]; c.pr = 0x0601B3FAu; c.r[5] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601B3FAu) return; }  // 0601B3F6 jsr @r7 ; mov r8,r5
    c.macl = c.r[0] * c.r[8];  // 0601B3FA mul.l r8,r0
    c.r[1] = c.macl;  // 0601B3FC sts macl,r1
    c.r[6] -= c.r[1];  // 0601B3FE sub r1,r6
    c.t = (c.r[6] & c.r[6]) == 0;  // 0601B400 tst r6,r6
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_0601B410; } }  // 0601B402 bt/s 0x0601B410 ; mov r9,r1
    c.r[1] = c.r[11];  // 0601B406 mov r11,r1
    c.r[1] += 1;  // 0601B408 add #1,r1
    c.r[0] = c.r[10];  // 0601B40A mov r10,r0
    st8(c.r[0] + c.r[12], c.r[1]); goto L_0601B4B0;  // 0601B40C bra 0x0601B4B0 ; mov.b r1,@(r0,r12)
L_0601B410:
    c.r[1] += 1;  // 0601B410 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B412 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0601B414 mov r1,r0
    c.r[0] >>= 2;  // 0601B416 shlr2 r0
    c.r[0] >>= 2;  // 0601B418 shlr2 r0
    c.r[0] >>= 2;  // 0601B41A shlr2 r0
    c.r[0] &= 0x1u;  // 0601B41C and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601B41E tst r0,r0
    { const bool k = c.t; c.r[8] -= 1; if (k) { goto L_0601B458; } }  // 0601B420 bt/s 0x0601B458 ; add #-1,r8
    c.r[1] = ld32(0x0601B43Cu);  // 0601B424 mov.l 0x0601B43C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B426 mov.b @r1,r1
    c.r[2] = ld32(0x0601B438u);  // 0601B428 mov.l 0x0601B438,r2
    c.r[0] = c.r[1] & 0xFFu;  // 0601B42A extu.b r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0601B42C mov.b @(r0,r2),r1
    c.r[1] -= c.r[8];  // 0601B42E sub r8,r1
    st8(c.r[0] + c.r[2], c.r[1]); goto L_0601B4B0;  // 0601B430 bra 0x0601B4B0 ; mov.b r1,@(r0,r2)
L_0601B458:
    c.r[1] = ld32(0x0601B564u);  // 0601B458 mov.l 0x0601B564,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B45A mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0601B45C extu.b r1,r0
    c.r[1] = ld32(0x0601B568u);  // 0601B45E mov.l 0x0601B568,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601B460 mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601B462 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601B464 tst r1,r1
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_0601B4B2; } }  // 0601B466 bt/s 0x0601B4B2 ; mov r9,r1
L_0601B46A:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601B55Cu);  // 0601B46A mov.w 0x0601B55C,r0
    c.r[15] = c.r[14]; goto L_0601B6D2;  // 0601B46C bra 0x0601B6D2 ; mov r14,r15
L_0601B470:
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B470 mov.b @r1,r3
    c.r[2] = c.r[3] & 0xFFu;  // 0601B472 extu.b r3,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601B55Eu);  // 0601B474 mov.w 0x0601B55E,r1
    c.t = c.r[2] == c.r[1];  // 0601B476 cmp/eq r1,r2
    if (c.t) { SH2_POLL(c); goto L_0601B46A; }  // 0601B478 bt 0x0601B46A
    c.r[1] = ld32(0x0601B564u);  // 0601B47A mov.l 0x0601B564,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B47C mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0601B47E extu.b r1,r0
    c.r[1] = ld32(0x0601B568u);  // 0601B480 mov.l 0x0601B568,r1
    st8(c.r[0] + c.r[1], c.r[3]); goto L_0601B4B0;  // 0601B482 bra 0x0601B4B0 ; mov.b r3,@(r0,r1)
L_0601B486:
    c.r[10] = ld32(0x0601B564u);  // 0601B486 mov.l 0x0601B564,r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0601B488 mov.b @r10,r1
    c.r[11] = ld32(0x0601B568u);  // 0601B48A mov.l 0x0601B568,r11
    c.r[0] = c.r[1] & 0xFFu;  // 0601B48C extu.b r1,r0
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 0601B48E mov.b @(r0,r11),r8
    c.r[1] = ld32(0x0601B56Cu);  // 0601B490 mov.l 0x0601B56C,r1
    c.r[4] = ld32(c.r[1]);  // 0601B492 mov.l @r1,r4
    c.r[0] = ld32(0x0601B570u);  // 0601B494 mov.l 0x0601B570,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601B49Au; c.r[8] = c.r[8] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601B49Au) return; }  // 0601B496 jsr @r0 ; extu.b r8,r8
    c.r[0] -= 1;  // 0601B49A add #-1,r0
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[0];  // 0601B49C cmp/ge r0,r8
    { const bool k = c.t; c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]); if (k) { goto L_0601B4AA; } }  // 0601B49E bt/s 0x0601B4AA ; mov.b @r10,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0601B4A2 extu.b r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 0601B4A4 mov.b @(r0,r11),r1
    c.r[1] += 1; goto L_0601B4AE;  // 0601B4A6 bra 0x0601B4AE ; add #1,r1
L_0601B4AA:
    c.r[0] = c.r[1] & 0xFFu;  // 0601B4AA extu.b r1,r0
    c.r[1] = 0x0u;  // 0601B4AC mov #0,r1
L_0601B4AE:
    st8(c.r[0] + c.r[11], c.r[1]);  // 0601B4AE mov.b r1,@(r0,r11)
L_0601B4B0:
    c.r[1] = c.r[9];  // 0601B4B0 mov r9,r1
L_0601B4B2:
    c.r[1] += 1;  // 0601B4B2 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B4B4 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0601B4B6 mov r1,r0
    c.r[0] >>= 2;  // 0601B4B8 shlr2 r0
    c.r[0] >>= 2;  // 0601B4BA shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0601B4BC shlr r0
    c.r[0] >>= 2;  // 0601B4BE shlr2 r0
    c.r[0] &= 0x1u;  // 0601B4C0 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601B4C2 tst r0,r0
    if (!c.t) { SH2_POLL(c); goto L_0601B46A; }  // 0601B4C4 bf 0x0601B46A
L_0601B4C6:
    c.r[1] = ld32(0x0601B574u);  // 0601B4C6 mov.l 0x0601B574,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0601B4C8 mov.w @r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0601B560u);  // 0601B4CA mov.w 0x0601B560,r2
    c.r[2] &= c.r[1];  // 0601B4CC and r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0601B4CE tst r2,r2
    if (!c.t) { goto L_0601B4D6; }  // 0601B4D0 bf 0x0601B4D6
    goto L_0601B5E2;  // 0601B4D2 bra 0x0601B5E2 ; nop
L_0601B4D6:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0601B4D6 mov.b @r9,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601B562u);  // 0601B4D8 mov.w 0x0601B562,r0
    c.r[1] &= c.r[0];  // 0601B4DA and r0,r1
    c.r[1] >>= 2;  // 0601B4DC shlr2 r1
    c.r[1] >>= 2;  // 0601B4DE shlr2 r1
    c.r[1] >>= 2;  // 0601B4E0 shlr2 r1
    c.r[0] = c.r[1];  // 0601B4E2 mov r1,r0
    c.t = c.r[0] == 0x1u;  // 0601B4E4 cmp/eq #1,r0
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_0601B4F4; } }  // 0601B4E6 bt/s 0x0601B4F4 ; mov r9,r1
    c.t = c.r[0] == 0x2u;  // 0601B4EA cmp/eq #2,r0
    { const bool k = c.t; c.r[1] += 6; if (k) { goto L_0601B5B0; } }  // 0601B4EC bt/s 0x0601B5B0 ; add #6,r1
    c.r[1] = c.r[9]; goto L_0601B5CA;  // 0601B4F0 bra 0x0601B5CA ; mov r9,r1
L_0601B4F4:
    c.r[1] += 5;  // 0601B4F4 add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B4F6 mov.b @r1,r1
    c.r[10] = c.r[1] & 0xFFu;  // 0601B4F8 extu.b r1,r10
    c.r[1] = c.r[9];  // 0601B4FA mov r9,r1
    c.r[1] += 4;  // 0601B4FC add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B4FE mov.b @r1,r1
    c.r[8] = c.r[1] & 0xFFu;  // 0601B500 extu.b r1,r8
    c.r[1] = ld32(0x0601B564u);  // 0601B502 mov.l 0x0601B564,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B504 mov.b @r1,r1
    c.r[3] = ld32(0x0601B568u);  // 0601B506 mov.l 0x0601B568,r3
    c.r[2] = c.r[1] & 0xFFu;  // 0601B508 extu.b r1,r2
    c.r[0] = c.r[2];  // 0601B50A mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0601B50C mov.b @(r0,r3),r1
    c.r[7] = c.r[1] & 0xFFu;  // 0601B50E extu.b r1,r7
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[8];  // 0601B510 cmp/ge r8,r7
    { const bool k = !c.t; c.r[1] -= c.r[8]; if (k) { goto L_0601B51A; } }  // 0601B512 bf/s 0x0601B51A ; sub r8,r1
    st8(c.r[0] + c.r[3], c.r[1]); goto L_0601B5C8;  // 0601B516 bra 0x0601B5C8 ; mov.b r1,@(r0,r3)
L_0601B51A:
    c.r[1] = c.r[9];  // 0601B51A mov r9,r1
    c.r[1] += 1;  // 0601B51C add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B51E mov.b @r1,r1
    c.r[0] = c.r[1];  // 0601B520 mov r1,r0
    c.r[0] >>= 2;  // 0601B522 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0601B524 shlr r0
    c.r[0] >>= 2;  // 0601B526 shlr2 r0
    c.r[0] &= 0x1u;  // 0601B528 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601B52A tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { SH2_POLL(c); goto L_0601B46A; } }  // 0601B52C bt/s 0x0601B46A ; mov r9,r1
    c.r[1] += 8;  // 0601B530 add #8,r1
    c.r[0] = c.r[2];  // 0601B532 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B534 mov.b @r1,r1
    c.macl = c.r[10] * c.r[8];  // 0601B536 mul.l r8,r10
    c.r[3] = c.r[1] & 0xFFu;  // 0601B538 extu.b r1,r3
    c.r[1] = c.r[9];  // 0601B53A mov r9,r1
    c.r[1] += 9;  // 0601B53C add #9,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B53E mov.b @r1,r1
    c.r[3] <<= 8;  // 0601B540 shll8 r3
    c.r[1] = c.r[1] & 0xFFu;  // 0601B542 extu.b r1,r1
    c.r[3] |= c.r[1];  // 0601B544 or r1,r3
    c.r[1] = ld32(0x0601B578u);  // 0601B546 mov.l 0x0601B578,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601B548 mov.b @(r0,r1),r1
    c.r[4] = c.macl;  // 0601B54A sts macl,r4
    c.r[1] = c.r[1] & 0xFFu;  // 0601B54C extu.b r1,r1
    c.r[1] -= 1;  // 0601B54E add #-1,r1
    c.macl = c.r[1] * c.r[10];  // 0601B550 mul.l r10,r1
    c.r[4] -= c.r[8];  // 0601B552 sub r8,r4
    c.r[1] = c.macl;  // 0601B554 sts macl,r1
    c.macl = c.r[1] * c.r[8];  // 0601B556 mul.l r8,r1
    c.r[4] += c.r[7]; goto L_0601B596;  // 0601B558 bra 0x0601B596 ; add r7,r4
L_0601B57C:
    c.r[1] = ld32(0x0601B6ECu);  // 0601B57C mov.l 0x0601B6EC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601B57E mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601B580 extu.b r1,r1
    c.t = (int32_t)c.r[4] > (int32_t)c.r[1];  // 0601B582 cmp/gt r1,r4
    if (!c.t) { goto L_0601B5A4; }  // 0601B584 bf 0x0601B5A4
    c.r[4] -= c.r[8];  // 0601B586 sub r8,r4
    c.r[1] = ld32(0x0601B6F0u);  // 0601B588 mov.l 0x0601B6F0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601B58A mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601B58C extu.b r1,r1
    c.r[1] -= 1;  // 0601B58E add #-1,r1
    c.macl = c.r[1] * c.r[10];  // 0601B590 mul.l r10,r1
    c.r[1] = c.macl;  // 0601B592 sts macl,r1
    c.macl = c.r[1] * c.r[8];  // 0601B594 mul.l r8,r1
L_0601B596:
    c.r[0] = c.r[3];  // 0601B596 mov r3,r0
    c.r[1] = c.macl;  // 0601B598 sts macl,r1
    c.r[0] -= c.r[1];  // 0601B59A sub r1,r0
    c.r[1] = c.r[0];  // 0601B59C mov r0,r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[4];  // 0601B59E cmp/gt r4,r1
    { const bool k = !c.t; c.r[0] = c.r[2]; if (k) { SH2_POLL(c); goto L_0601B57C; } }  // 0601B5A0 bf/s 0x0601B57C ; mov r2,r0
L_0601B5A4:
    c.r[1] = ld32(0x0601B6F4u);  // 0601B5A4 mov.l 0x0601B6F4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B5A6 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0601B5A8 extu.b r1,r0
    c.r[1] = ld32(0x0601B6ECu);  // 0601B5AA mov.l 0x0601B6EC,r1
    st8(c.r[0] + c.r[1], c.r[4]); goto L_0601B5C8;  // 0601B5AC bra 0x0601B5C8 ; mov.b r4,@(r0,r1)
L_0601B5B0:
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B5B0 mov.b @r1,r3
    c.r[2] = c.r[3] & 0xFFu;  // 0601B5B2 extu.b r3,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601B6E4u);  // 0601B5B4 mov.w 0x0601B6E4,r1
    c.t = c.r[2] == c.r[1];  // 0601B5B6 cmp/eq r1,r2
    if (!c.t) { goto L_0601B5BE; }  // 0601B5B8 bf 0x0601B5BE
    SH2_POLL(c); goto L_0601B46A;  // 0601B5BA bra 0x0601B46A ; nop
L_0601B5BE:
    c.r[1] = ld32(0x0601B6F4u);  // 0601B5BE mov.l 0x0601B6F4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B5C0 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0601B5C2 extu.b r1,r0
    c.r[1] = ld32(0x0601B6ECu);  // 0601B5C4 mov.l 0x0601B6EC,r1
    st8(c.r[0] + c.r[1], c.r[3]);  // 0601B5C6 mov.b r3,@(r0,r1)
L_0601B5C8:
    c.r[1] = c.r[9];  // 0601B5C8 mov r9,r1
L_0601B5CA:
    c.r[1] += 1;  // 0601B5CA add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B5CC mov.b @r1,r1
    c.r[0] = c.r[1];  // 0601B5CE mov r1,r0
    c.r[0] >>= 2;  // 0601B5D0 shlr2 r0
    c.r[0] >>= 2;  // 0601B5D2 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0601B5D4 shlr r0
    c.r[0] >>= 2;  // 0601B5D6 shlr2 r0
    c.r[0] &= 0x1u;  // 0601B5D8 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601B5DA tst r0,r0
    if (c.t) { goto L_0601B5E2; }  // 0601B5DC bt 0x0601B5E2
    SH2_POLL(c); goto L_0601B46A;  // 0601B5DE bra 0x0601B46A ; nop
L_0601B5E2:
    c.r[1] = ld32(0x0601B6F8u);  // 0601B5E2 mov.l 0x0601B6F8,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0601B5E4 mov.w @r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0601B6E6u);  // 0601B5E6 mov.w 0x0601B6E6,r2
    c.r[2] &= c.r[1];  // 0601B5E8 and r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0601B5EA tst r2,r2
    if (c.t) { goto L_0601B6C8; }  // 0601B5EC bt 0x0601B6C8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0601B5EE mov.b @r9,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601B6E8u);  // 0601B5F0 mov.w 0x0601B6E8,r0
    c.r[1] &= c.r[0];  // 0601B5F2 and r0,r1
    c.r[1] >>= 2;  // 0601B5F4 shlr2 r1
    c.r[1] >>= 2;  // 0601B5F6 shlr2 r1
    c.r[1] >>= 2;  // 0601B5F8 shlr2 r1
    c.r[0] = c.r[1];  // 0601B5FA mov r1,r0
    c.t = c.r[0] == 0x1u;  // 0601B5FC cmp/eq #1,r0
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_0601B60C; } }  // 0601B5FE bt/s 0x0601B60C ; mov r9,r1
    c.t = c.r[0] == 0x2u;  // 0601B602 cmp/eq #2,r0
    { const bool k = c.t; c.r[1] += 7; if (k) { goto L_0601B696; } }  // 0601B604 bt/s 0x0601B696 ; add #7,r1
    c.r[1] = c.r[9]; goto L_0601B6B0;  // 0601B608 bra 0x0601B6B0 ; mov r9,r1
L_0601B60C:
    c.r[1] += 5;  // 0601B60C add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B60E mov.b @r1,r1
    c.r[10] = c.r[1] & 0xFFu;  // 0601B610 extu.b r1,r10
    c.r[1] = c.r[9];  // 0601B612 mov r9,r1
    c.r[1] += 4;  // 0601B614 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B616 mov.b @r1,r1
    c.r[8] = c.r[1] & 0xFFu;  // 0601B618 extu.b r1,r8
    c.r[1] = c.r[9];  // 0601B61A mov r9,r1
    c.r[1] += 8;  // 0601B61C add #8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B61E mov.b @r1,r1
    c.macl = c.r[10] * c.r[8];  // 0601B620 mul.l r8,r10
    c.r[4] = c.r[1] & 0xFFu;  // 0601B622 extu.b r1,r4
    c.r[1] = c.r[9];  // 0601B624 mov r9,r1
    c.r[1] += 9;  // 0601B626 add #9,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B628 mov.b @r1,r1
    c.r[4] <<= 8;  // 0601B62A shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 0601B62C extu.b r1,r1
    c.r[4] |= c.r[1];  // 0601B62E or r1,r4
    c.r[1] = ld32(0x0601B6F4u);  // 0601B630 mov.l 0x0601B6F4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B632 mov.b @r1,r1
    c.r[10] = c.r[1] & 0xFFu;  // 0601B634 extu.b r1,r10
    c.r[1] = ld32(0x0601B6F0u);  // 0601B636 mov.l 0x0601B6F0,r1
    c.r[0] = c.r[10];  // 0601B638 mov r10,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601B63A mov.b @(r0,r1),r1
    c.r[2] = c.macl;  // 0601B63C sts macl,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0601B63E extu.b r1,r1
    c.r[1] -= 1;  // 0601B640 add #-1,r1
    c.macl = c.r[2] * c.r[1];  // 0601B642 mul.l r1,r2
    c.r[1] = c.macl;  // 0601B644 sts macl,r1
    c.macl = c.r[2];  // 0601B646 lds r2,macl
    c.r[4] -= c.r[1];  // 0601B648 sub r1,r4
    c.r[1] = c.macl;  // 0601B64A sts macl,r1
    c.t = (int32_t)c.r[4] > (int32_t)c.r[1];  // 0601B64C cmp/gt r1,r4
    if (!c.t) { goto L_0601B652; }  // 0601B64E bf 0x0601B652
    c.r[4] = c.macl;  // 0601B650 sts macl,r4
L_0601B652:
    c.r[11] = ld32(0x0601B6ECu);  // 0601B652 mov.l 0x0601B6EC,r11
    c.r[0] = c.r[10];  // 0601B654 mov r10,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 0601B656 mov.b @(r0,r11),r2
    c.r[6] = c.r[2] & 0xFFu;  // 0601B658 extu.b r2,r6
    c.r[1] = c.r[6];  // 0601B65A mov r6,r1
    c.r[1] += c.r[8];  // 0601B65C add r8,r1
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[4];  // 0601B65E cmp/ge r4,r1
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_0601B66A; } }  // 0601B660 bt/s 0x0601B66A ; mov r9,r1
    c.r[8] += c.r[2];  // 0601B664 add r2,r8
    st8(c.r[0] + c.r[11], c.r[8]); goto L_0601B6B0;  // 0601B666 bra 0x0601B6B0 ; mov.b r8,@(r0,r11)
L_0601B66A:
    c.r[1] += 1;  // 0601B66A add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B66C mov.b @r1,r1
    c.r[0] = c.r[1];  // 0601B66E mov r1,r0
    c.r[0] >>= 2;  // 0601B670 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0601B672 shlr r0
    c.r[0] >>= 2;  // 0601B674 shlr2 r0
    c.r[0] &= 0x1u;  // 0601B676 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601B678 tst r0,r0
    { const bool k = !c.t; c.r[4] = c.r[6]; if (k) { goto L_0601B682; } }  // 0601B67A bf/s 0x0601B682 ; mov r6,r4
    SH2_POLL(c); goto L_0601B46A;  // 0601B67E bra 0x0601B46A ; nop
L_0601B682:
    c.r[7] = ld32(0x0601B6FCu);  // 0601B682 mov.l 0x0601B6FC,r7
    { const uint32_t x = c.r[7]; c.pr = 0x0601B688u; c.r[5] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601B688u) return; }  // 0601B684 jsr @r7 ; mov r8,r5
    c.r[7] = c.r[0];  // 0601B688 mov r0,r7
    c.macl = c.r[7] * c.r[8];  // 0601B68A mul.l r8,r7
    c.r[0] = c.r[10];  // 0601B68C mov r10,r0
    c.r[1] = c.macl;  // 0601B68E sts macl,r1
    c.r[6] -= c.r[1];  // 0601B690 sub r1,r6
    st8(c.r[0] + c.r[11], c.r[6]); goto L_0601B6AE;  // 0601B692 bra 0x0601B6AE ; mov.b r6,@(r0,r11)
L_0601B696:
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B696 mov.b @r1,r3
    c.r[2] = c.r[3] & 0xFFu;  // 0601B698 extu.b r3,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601B6E4u);  // 0601B69A mov.w 0x0601B6E4,r1
    c.t = c.r[2] == c.r[1];  // 0601B69C cmp/eq r1,r2
    if (!c.t) { goto L_0601B6A4; }  // 0601B69E bf 0x0601B6A4
    SH2_POLL(c); goto L_0601B46A;  // 0601B6A0 bra 0x0601B46A ; nop
L_0601B6A4:
    c.r[1] = ld32(0x0601B6F4u);  // 0601B6A4 mov.l 0x0601B6F4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B6A6 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0601B6A8 extu.b r1,r0
    c.r[1] = ld32(0x0601B6ECu);  // 0601B6AA mov.l 0x0601B6EC,r1
    st8(c.r[0] + c.r[1], c.r[3]);  // 0601B6AC mov.b r3,@(r0,r1)
L_0601B6AE:
    c.r[1] = c.r[9];  // 0601B6AE mov r9,r1
L_0601B6B0:
    c.r[1] += 1;  // 0601B6B0 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B6B2 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0601B6B4 mov r1,r0
    c.r[0] >>= 2;  // 0601B6B6 shlr2 r0
    c.r[0] >>= 2;  // 0601B6B8 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0601B6BA shlr r0
    c.r[0] >>= 2;  // 0601B6BC shlr2 r0
    c.r[0] &= 0x1u;  // 0601B6BE and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601B6C0 tst r0,r0
    if (c.t) { goto L_0601B6C8; }  // 0601B6C2 bt 0x0601B6C8
    SH2_POLL(c); goto L_0601B46A;  // 0601B6C4 bra 0x0601B46A ; nop
L_0601B6C8:
    c.r[1] = ld32(0x0601B700u);  // 0601B6C8 mov.l 0x0601B700,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601B6CEu; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601B6CEu) return; }  // 0601B6CA jsr @r1 ; mov r9,r4
    c.r[0] = 0x0u;  // 0601B6CE mov #0,r0
    c.r[15] = c.r[14];  // 0601B6D0 mov r14,r15
L_0601B6D2:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601B6D2 lds.l @r15+,pr
L_0601B6D4:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601B6D4 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0601B6D6 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0601B6D8 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0601B6DA mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0601B6DC mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0601B6DE mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601B6E0 rts ; mov.l @r15+,r8
}

void f_0601B124(SH2Context& c) {
    ran[262] = 1;
    c.r[3] = ld32(0x0601B240u);  // 0601B124 mov.l 0x0601B240,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0601B126 mov.w @r3,r2
    c.r[7] = ld32(0x0601B244u);  // 0601B128 mov.l 0x0601B244,r7
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[7]);  // 0601B12A mov.w @r7,r1
    c.r[2] |= c.r[1];  // 0601B12C or r1,r2
    st16(c.r[3], c.r[2]);  // 0601B12E mov.w r2,@r3
    c.r[1] = 0x0u;  // 0601B130 mov #0,r1
    st16(c.r[7], c.r[1]);  // 0601B132 mov.w r1,@r7
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601B232u);  // 0601B134 mov.w 0x0601B232,r1
    c.r[1] &= c.r[2];  // 0601B136 and r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601B138 tst r1,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0601B144; } }  // 0601B13A bt/s 0x0601B144 ; mov r15,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601B234u);  // 0601B13E mov.w 0x0601B234,r0
    c.r[15] = c.r[14]; goto L_0601B6D2;  // 0601B140 bra 0x0601B6D2 ; mov r14,r15
L_0601B144:
    c.r[0] = c.r[2];  // 0601B144 mov r2,r0
    c.r[0] >>= 8;  // 0601B146 shlr8 r0
    c.r[0] &= 0x1u;  // 0601B148 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601B14A tst r0,r0
    if (c.t) { goto L_0601B156; }  // 0601B14C bt 0x0601B156
    c.r[15] = c.r[14];  // 0601B14E mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601B236u);  // 0601B150 mov.w 0x0601B236,r0
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; } goto L_0601B6D4;  // 0601B152 bra 0x0601B6D4 ; lds.l @r15+,pr
L_0601B156:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601B238u);  // 0601B156 mov.w 0x0601B238,r1
    c.r[2] &= c.r[1];  // 0601B158 and r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0601B15A tst r2,r2
    if (c.t) { goto L_0601B162; }  // 0601B15C bt 0x0601B162
    goto L_0601B46A;  // 0601B15E bra 0x0601B46A ; nop
L_0601B162:
    c.r[1] = ld32(0x0601B248u);  // 0601B162 mov.l 0x0601B248,r1
    c.r[9] = ld32(c.r[1]);  // 0601B164 mov.l @r1,r9
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0601B166 mov.b @r9,r0
    c.r[0] &= 0xC0u;  // 0601B168 and #192,r0
    c.r[0] >>= 2;  // 0601B16A shlr2 r0
    c.r[0] >>= 2;  // 0601B16C shlr2 r0
    c.r[0] >>= 2;  // 0601B16E shlr2 r0
    c.t = c.r[0] == 0x1u;  // 0601B170 cmp/eq #1,r0
    { const bool k = c.t; c.t = (c.r[9] & c.r[9]) == 0; if (k) { goto L_0601B18C; } }  // 0601B172 bt/s 0x0601B18C ; tst r9,r9
    c.r[1] = ld32(0x0601B24Cu);  // 0601B176 mov.l 0x0601B24C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B178 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0601B17A extu.b r1,r0
    c.r[1] = ld32(0x0601B250u);  // 0601B17C mov.l 0x0601B250,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601B17E mov.b @(r0,r1),r5
    c.r[4] = c.r[9];  // 0601B180 mov r9,r4
    c.r[0] = ld32(0x0601B254u);  // 0601B182 mov.l 0x0601B254,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601B188u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601B188u) return; }  // 0601B184 jsr @r0 ; extu.b r5,r5
    c.r[9] = c.r[0];  // 0601B188 mov r0,r9
    c.t = (c.r[9] & c.r[9]) == 0;  // 0601B18A tst r9,r9
L_0601B18C:
    { const bool k = !c.t; c.r[4] = 0x0u; if (k) { goto L_0601B194; } }  // 0601B18C bf/s 0x0601B194 ; mov #0,r4
    goto L_0601B6C8;  // 0601B190 bra 0x0601B6C8 ; nop
L_0601B194:
    c.r[1] = ld32(0x0601B258u);  // 0601B194 mov.l 0x0601B258,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B196 mov.b @r1,r0
    c.r[7] = 0x3u;  // 0601B198 mov #3,r7
    c.r[3] = 0x0u;  // 0601B19A mov #0,r3
    c.r[2] = ld32(0x0601B25Cu);  // 0601B19C mov.l 0x0601B25C,r2
    c.r[0] &= 0xFEu;  // 0601B19E and #254,r0
    st8(c.r[1], c.r[0]);  // 0601B1A0 mov.b r0,@r1
L_0601B1A2:
    c.r[1] = c.r[2];  // 0601B1A2 mov r2,r1
    c.r[1] += 2;  // 0601B1A4 add #2,r1
    st8(c.r[1], c.r[3]);  // 0601B1A6 mov.b r3,@r1
    c.r[4] += 1;  // 0601B1A8 add #1,r4
    c.t = (int32_t)c.r[4] > (int32_t)c.r[7];  // 0601B1AA cmp/gt r7,r4
    { const bool k = !c.t; c.r[2] += 3; if (k) { SH2_POLL(c); goto L_0601B1A2; } }  // 0601B1AC bf/s 0x0601B1A2 ; add #3,r2
    c.r[7] = c.r[9];  // 0601B1B0 mov r9,r7
    c.r[7] += 2;  // 0601B1B2 add #2,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0601B1B4 mov.b @r7,r1
    c.r[0] = c.r[1];  // 0601B1B6 mov r1,r0
    c.r[0] >>= 2;  // 0601B1B8 shlr2 r0
    c.r[0] >>= 2;  // 0601B1BA shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0601B1BC shlr r0
    c.r[0] >>= 2;  // 0601B1BE shlr2 r0
    c.r[0] &= 0x1u;  // 0601B1C0 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601B1C2 tst r0,r0
    { const bool k = c.t; c.r[0] = c.r[1]; if (k) { goto L_0601B1E2; } }  // 0601B1C4 bt/s 0x0601B1E2 ; mov r1,r0
    c.r[1] = ld32(0x0601B258u);  // 0601B1C8 mov.l 0x0601B258,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B1CA mov.b @r1,r0
    c.r[2] = ld32(0x0601B25Cu);  // 0601B1CC mov.l 0x0601B25C,r2
    c.r[3] = c.r[2];  // 0601B1CE mov r2,r3
    c.r[3] += 8;  // 0601B1D0 add #8,r3
    c.r[2] += 11;  // 0601B1D2 add #11,r2
    c.r[0] |= 0x1u;  // 0601B1D4 or #1,r0
    st8(c.r[1], c.r[0]);  // 0601B1D6 mov.b r0,@r1
    c.r[1] = 0x1u;  // 0601B1D8 mov #1,r1
    st8(c.r[2], c.r[1]);  // 0601B1DA mov.b r1,@r2
    st8(c.r[3], c.r[1]);  // 0601B1DC mov.b r1,@r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0601B1DE mov.b @r7,r1
    c.r[0] = c.r[1];  // 0601B1E0 mov r1,r0
L_0601B1E2:
    c.r[0] >>= 2;  // 0601B1E2 shlr2 r0
    c.r[0] >>= 2;  // 0601B1E4 shlr2 r0
    c.r[0] >>= 2;  // 0601B1E6 shlr2 r0
    c.r[0] &= 0x1u;  // 0601B1E8 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601B1EA tst r0,r0
    if (c.t) { goto L_0601B204; }  // 0601B1EC bt 0x0601B204
    c.r[1] = ld32(0x0601B258u);  // 0601B1EE mov.l 0x0601B258,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B1F0 mov.b @r1,r0
    c.r[2] = ld32(0x0601B25Cu);  // 0601B1F2 mov.l 0x0601B25C,r2
    c.r[3] = c.r[2];  // 0601B1F4 mov r2,r3
    c.r[3] += 2;  // 0601B1F6 add #2,r3
    c.r[2] += 5;  // 0601B1F8 add #5,r2
    c.r[0] |= 0x1u;  // 0601B1FA or #1,r0
    st8(c.r[1], c.r[0]);  // 0601B1FC mov.b r0,@r1
    c.r[1] = 0x1u;  // 0601B1FE mov #1,r1
    st8(c.r[2], c.r[1]);  // 0601B200 mov.b r1,@r2
    st8(c.r[3], c.r[1]);  // 0601B202 mov.b r1,@r3
L_0601B204:
    c.r[1] = ld32(0x0601B240u);  // 0601B204 mov.l 0x0601B240,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0601B206 mov.w @r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0601B23Au);  // 0601B208 mov.w 0x0601B23A,r2
    c.r[2] &= c.r[1];  // 0601B20A and r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0601B20C tst r2,r2
    if (!c.t) { goto L_0601B214; }  // 0601B20E bf 0x0601B214
    goto L_0601B36E;  // 0601B210 bra 0x0601B36E ; nop
L_0601B214:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0601B214 mov.b @r9,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601B23Cu);  // 0601B216 mov.w 0x0601B23C,r0
    c.r[1] &= c.r[0];  // 0601B218 and r0,r1
    c.r[1] >>= 2;  // 0601B21A shlr2 r1
    c.r[1] >>= 2;  // 0601B21C shlr2 r1
    c.r[1] >>= 2;  // 0601B21E shlr2 r1
    c.r[0] = c.r[1];  // 0601B220 mov r1,r0
    c.t = c.r[0] == 0x1u;  // 0601B222 cmp/eq #1,r0
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_0601B260; } }  // 0601B224 bt/s 0x0601B260 ; mov r9,r1
    c.t = c.r[0] == 0x2u;  // 0601B228 cmp/eq #2,r0
    { const bool k = c.t; c.r[1] += 4; if (k) { goto L_0601B312; } }  // 0601B22A bt/s 0x0601B312 ; add #4,r1
    goto L_0601B32C;  // 0601B22E bra 0x0601B32C ; nop
L_0601B260:
    c.r[1] += 5;  // 0601B260 add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B262 mov.b @r1,r1
    c.r[10] = c.r[1] & 0xFFu;  // 0601B264 extu.b r1,r10
    c.r[1] = c.r[9];  // 0601B266 mov r9,r1
    c.r[1] += 4;  // 0601B268 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B26A mov.b @r1,r1
    c.r[13] = ld32(0x0601B438u);  // 0601B26C mov.l 0x0601B438,r13
    c.r[8] = c.r[1] & 0xFFu;  // 0601B26E extu.b r1,r8
    c.r[1] = ld32(0x0601B43Cu);  // 0601B270 mov.l 0x0601B43C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B272 mov.b @r1,r1
    c.r[7] = ld32(0x0601B440u);  // 0601B274 mov.l 0x0601B440,r7
    c.r[12] = c.r[1] & 0xFFu;  // 0601B276 extu.b r1,r12
    c.r[0] = c.r[12];  // 0601B278 mov r12,r0
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[13]);  // 0601B27A mov.b @(r0,r13),r11
    c.r[5] = c.r[8];  // 0601B27C mov r8,r5
    c.r[6] = c.r[11] & 0xFFu;  // 0601B27E extu.b r11,r6
    { const uint32_t x = c.r[7]; c.pr = 0x0601B284u; c.r[4] = c.r[6]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601B284u) return; }  // 0601B280 jsr @r7 ; mov r6,r4
    c.r[7] = c.r[0];  // 0601B284 mov r0,r7
    c.macl = c.r[7] * c.r[8];  // 0601B286 mul.l r8,r7
    c.r[0] = c.r[6];  // 0601B288 mov r6,r0
    c.r[1] = c.macl;  // 0601B28A sts macl,r1
    c.r[0] -= c.r[1];  // 0601B28C sub r1,r0
    c.r[1] = c.r[0];  // 0601B28E mov r0,r1
    c.t = (int32_t)c.r[1] > 0;  // 0601B290 cmp/pl r1
    { const bool k = !c.t; c.r[1] = c.r[11]; if (k) { goto L_0601B29E; } }  // 0601B292 bf/s 0x0601B29E ; mov r11,r1
    c.r[1] -= 1;  // 0601B296 add #-1,r1
    c.r[0] = c.r[12];  // 0601B298 mov r12,r0
    st8(c.r[0] + c.r[13], c.r[1]); goto L_0601B358;  // 0601B29A bra 0x0601B358 ; mov.b r1,@(r0,r13)
L_0601B29E:
    c.r[1] = c.r[9];  // 0601B29E mov r9,r1
    c.r[1] += 1;  // 0601B2A0 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B2A2 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0601B2A4 mov r1,r0
    c.r[0] >>= 2;  // 0601B2A6 shlr2 r0
    c.r[0] >>= 2;  // 0601B2A8 shlr2 r0
    c.r[0] >>= 2;  // 0601B2AA shlr2 r0
    c.r[0] &= 0x1u;  // 0601B2AC and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601B2AE tst r0,r0
    { const bool k = !c.t; c.r[4] = c.r[6]; if (k) { goto L_0601B2B8; } }  // 0601B2B0 bf/s 0x0601B2B8 ; mov r6,r4
    goto L_0601B46A;  // 0601B2B4 bra 0x0601B46A ; nop
L_0601B2B8:
    c.r[1] = c.r[9];  // 0601B2B8 mov r9,r1
    c.r[1] += 8;  // 0601B2BA add #8,r1
    c.r[3] = c.r[12];  // 0601B2BC mov r12,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B2BE mov.b @r1,r1
    c.r[0] = c.r[3];  // 0601B2C0 mov r3,r0
    c.r[2] = c.r[1] & 0xFFu;  // 0601B2C2 extu.b r1,r2
    c.r[1] = c.r[9];  // 0601B2C4 mov r9,r1
    c.r[1] += 9;  // 0601B2C6 add #9,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B2C8 mov.b @r1,r1
    c.r[2] <<= 8;  // 0601B2CA shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0601B2CC extu.b r1,r1
    c.r[2] |= c.r[1];  // 0601B2CE or r1,r2
    c.r[1] = ld32(0x0601B444u);  // 0601B2D0 mov.l 0x0601B444,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601B2D2 mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601B2D4 extu.b r1,r1
    c.r[1] -= 1;  // 0601B2D6 add #-1,r1
    c.macl = c.r[1] * c.r[10];  // 0601B2D8 mul.l r10,r1
    c.r[4] += c.r[8]; goto L_0601B2F2;  // 0601B2DA bra 0x0601B2F2 ; add r8,r4
L_0601B2DE:
    c.r[1] = ld32(0x0601B438u);  // 0601B2DE mov.l 0x0601B438,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601B2E0 mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601B2E2 extu.b r1,r1
    c.t = (int32_t)c.r[4] > (int32_t)c.r[1];  // 0601B2E4 cmp/gt r1,r4
    if (!c.t) { goto L_0601B306; }  // 0601B2E6 bf 0x0601B306
    c.r[1] = ld32(0x0601B444u);  // 0601B2E8 mov.l 0x0601B444,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601B2EA mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601B2EC extu.b r1,r1
    c.r[1] -= 1;  // 0601B2EE add #-1,r1
    c.macl = c.r[1] * c.r[10];  // 0601B2F0 mul.l r10,r1
L_0601B2F2:
    c.r[1] = c.macl;  // 0601B2F2 sts macl,r1
    c.macl = c.r[1] * c.r[8];  // 0601B2F4 mul.l r8,r1
    c.r[4] -= 1;  // 0601B2F6 add #-1,r4
    c.r[0] = c.r[2];  // 0601B2F8 mov r2,r0
    c.r[1] = c.macl;  // 0601B2FA sts macl,r1
    c.r[0] -= c.r[1];  // 0601B2FC sub r1,r0
    c.r[1] = c.r[0];  // 0601B2FE mov r0,r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[4];  // 0601B300 cmp/gt r4,r1
    { const bool k = !c.t; c.r[0] = c.r[3]; if (k) { SH2_POLL(c); goto L_0601B2DE; } }  // 0601B302 bf/s 0x0601B2DE ; mov r3,r0
L_0601B306:
    c.r[1] = ld32(0x0601B43Cu);  // 0601B306 mov.l 0x0601B43C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B308 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0601B30A extu.b r1,r0
    c.r[1] = ld32(0x0601B438u);  // 0601B30C mov.l 0x0601B438,r1
    st8(c.r[0] + c.r[1], c.r[4]); goto L_0601B358;  // 0601B30E bra 0x0601B358 ; mov.b r4,@(r0,r1)
L_0601B312:
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B312 mov.b @r1,r3
    c.r[2] = c.r[3] & 0xFFu;  // 0601B314 extu.b r3,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601B434u);  // 0601B316 mov.w 0x0601B434,r1
    c.t = c.r[2] == c.r[1];  // 0601B318 cmp/eq r1,r2
    if (!c.t) { goto L_0601B320; }  // 0601B31A bf 0x0601B320
    goto L_0601B46A;  // 0601B31C bra 0x0601B46A ; nop
L_0601B320:
    c.r[1] = ld32(0x0601B43Cu);  // 0601B320 mov.l 0x0601B43C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B322 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0601B324 extu.b r1,r0
    c.r[1] = ld32(0x0601B438u);  // 0601B326 mov.l 0x0601B438,r1
    st8(c.r[0] + c.r[1], c.r[3]); goto L_0601B358;  // 0601B328 bra 0x0601B358 ; mov.b r3,@(r0,r1)
L_0601B32C:
    c.r[10] = ld32(0x0601B43Cu);  // 0601B32C mov.l 0x0601B43C,r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0601B32E mov.b @r10,r1
    c.r[8] = ld32(0x0601B438u);  // 0601B330 mov.l 0x0601B438,r8
    c.r[3] = c.r[1] & 0xFFu;  // 0601B332 extu.b r1,r3
    c.r[0] = c.r[3];  // 0601B334 mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0601B336 mov.b @(r0,r8),r2
    c.r[1] = c.r[2] & 0xFFu;  // 0601B338 extu.b r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601B33A tst r1,r1
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_0601B346; } }  // 0601B33C bt/s 0x0601B346 ; mov r2,r1
    c.r[1] -= 1;  // 0601B340 add #-1,r1
    st8(c.r[0] + c.r[8], c.r[1]); goto L_0601B358;  // 0601B342 bra 0x0601B358 ; mov.b r1,@(r0,r8)
L_0601B346:
    c.r[1] = ld32(0x0601B448u);  // 0601B346 mov.l 0x0601B448,r1
    c.r[0] = ld32(0x0601B44Cu);  // 0601B348 mov.l 0x0601B44C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601B34Eu; c.r[4] = ld32(c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601B34Eu) return; }  // 0601B34A jsr @r0 ; mov.l @r1,r4
    c.r[2] = c.r[0];  // 0601B34E mov r0,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0601B350 mov.b @r10,r1
    c.r[2] -= 1;  // 0601B352 add #-1,r2
    c.r[0] = c.r[1] & 0xFFu;  // 0601B354 extu.b r1,r0
    st8(c.r[0] + c.r[8], c.r[2]);  // 0601B356 mov.b r2,@(r0,r8)
L_0601B358:
    c.r[1] = c.r[9];  // 0601B358 mov r9,r1
    c.r[1] += 1;  // 0601B35A add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B35C mov.b @r1,r1
    c.r[0] = c.r[1];  // 0601B35E mov r1,r0
    c.r[0] >>= 2;  // 0601B360 shlr2 r0
    c.r[0] >>= 2;  // 0601B362 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0601B364 shlr r0
    c.r[0] >>= 2;  // 0601B366 shlr2 r0
    c.r[0] &= 0x1u;  // 0601B368 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601B36A tst r0,r0
    if (!c.t) { goto L_0601B46A; }  // 0601B36C bf 0x0601B46A
L_0601B36E:
    c.r[1] = ld32(0x0601B450u);  // 0601B36E mov.l 0x0601B450,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0601B370 mov.w @r1,r1
    c.r[2] = ld32(0x0601B454u);  // 0601B372 mov.l 0x0601B454,r2
    c.r[2] &= c.r[1];  // 0601B374 and r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0601B376 tst r2,r2
    if (!c.t) { goto L_0601B37E; }  // 0601B378 bf 0x0601B37E
    goto L_0601B4C6;  // 0601B37A bra 0x0601B4C6 ; nop
L_0601B37E:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0601B37E mov.b @r9,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601B436u);  // 0601B380 mov.w 0x0601B436,r0
    c.r[1] &= c.r[0];  // 0601B382 and r0,r1
    c.r[1] >>= 2;  // 0601B384 shlr2 r1
    c.r[1] >>= 2;  // 0601B386 shlr2 r1
    c.r[1] >>= 2;  // 0601B388 shlr2 r1
    c.r[0] = c.r[1];  // 0601B38A mov r1,r0
    c.t = c.r[0] == 0x1u;  // 0601B38C cmp/eq #1,r0
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_0601B39C; } }  // 0601B38E bt/s 0x0601B39C ; mov r9,r1
    c.t = c.r[0] == 0x2u;  // 0601B392 cmp/eq #2,r0
    { const bool k = c.t; c.r[1] += 5; if (k) { goto L_0601B470; } }  // 0601B394 bt/s 0x0601B470 ; add #5,r1
    goto L_0601B486;  // 0601B398 bra 0x0601B486 ; nop
L_0601B39C:
    c.r[1] += 5;  // 0601B39C add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B39E mov.b @r1,r1
    c.r[10] = c.r[1] & 0xFFu;  // 0601B3A0 extu.b r1,r10
    c.r[1] = c.r[9];  // 0601B3A2 mov r9,r1
    c.r[1] += 4;  // 0601B3A4 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B3A6 mov.b @r1,r1
    c.r[8] = c.r[1] & 0xFFu;  // 0601B3A8 extu.b r1,r8
    c.r[1] = c.r[9];  // 0601B3AA mov r9,r1
    c.r[1] += 8;  // 0601B3AC add #8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B3AE mov.b @r1,r1
    c.macl = c.r[10] * c.r[8];  // 0601B3B0 mul.l r8,r10
    c.r[4] = c.r[1] & 0xFFu;  // 0601B3B2 extu.b r1,r4
    c.r[1] = c.r[9];  // 0601B3B4 mov r9,r1
    c.r[1] += 9;  // 0601B3B6 add #9,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B3B8 mov.b @r1,r1
    c.r[4] <<= 8;  // 0601B3BA shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 0601B3BC extu.b r1,r1
    c.r[4] |= c.r[1];  // 0601B3BE or r1,r4
    c.r[1] = ld32(0x0601B43Cu);  // 0601B3C0 mov.l 0x0601B43C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B3C2 mov.b @r1,r1
    c.r[10] = c.r[1] & 0xFFu;  // 0601B3C4 extu.b r1,r10
    c.r[1] = ld32(0x0601B444u);  // 0601B3C6 mov.l 0x0601B444,r1
    c.r[0] = c.r[10];  // 0601B3C8 mov r10,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601B3CA mov.b @(r0,r1),r1
    c.r[2] = c.macl;  // 0601B3CC sts macl,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0601B3CE extu.b r1,r1
    c.r[1] -= 1;  // 0601B3D0 add #-1,r1
    c.macl = c.r[2] * c.r[1];  // 0601B3D2 mul.l r1,r2
    c.r[1] = c.macl;  // 0601B3D4 sts macl,r1
    c.macl = c.r[2];  // 0601B3D6 lds r2,macl
    c.r[4] -= c.r[1];  // 0601B3D8 sub r1,r4
    c.r[1] = c.macl;  // 0601B3DA sts macl,r1
    c.t = (int32_t)c.r[4] > (int32_t)c.r[1];  // 0601B3DC cmp/gt r1,r4
    if (!c.t) { goto L_0601B3E2; }  // 0601B3DE bf 0x0601B3E2
    c.r[4] = c.macl;  // 0601B3E0 sts macl,r4
L_0601B3E2:
    c.r[12] = ld32(0x0601B438u);  // 0601B3E2 mov.l 0x0601B438,r12
    c.r[0] = c.r[10];  // 0601B3E4 mov r10,r0
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[12]);  // 0601B3E6 mov.b @(r0,r12),r11
    c.r[6] = c.r[11] & 0xFFu;  // 0601B3E8 extu.b r11,r6
    c.r[6] += 1;  // 0601B3EA add #1,r6
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[4];  // 0601B3EC cmp/ge r4,r6
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_0601B410; } }  // 0601B3EE bt/s 0x0601B410 ; mov r9,r1
    c.r[4] = c.r[6];  // 0601B3F2 mov r6,r4
    c.r[7] = ld32(0x0601B440u);  // 0601B3F4 mov.l 0x0601B440,r7
    { const uint32_t x = c.r[7]; c.pr = 0x0601B3FAu; c.r[5] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601B3FAu) return; }  // 0601B3F6 jsr @r7 ; mov r8,r5
    c.macl = c.r[0] * c.r[8];  // 0601B3FA mul.l r8,r0
    c.r[1] = c.macl;  // 0601B3FC sts macl,r1
    c.r[6] -= c.r[1];  // 0601B3FE sub r1,r6
    c.t = (c.r[6] & c.r[6]) == 0;  // 0601B400 tst r6,r6
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_0601B410; } }  // 0601B402 bt/s 0x0601B410 ; mov r9,r1
    c.r[1] = c.r[11];  // 0601B406 mov r11,r1
    c.r[1] += 1;  // 0601B408 add #1,r1
    c.r[0] = c.r[10];  // 0601B40A mov r10,r0
    st8(c.r[0] + c.r[12], c.r[1]); goto L_0601B4B0;  // 0601B40C bra 0x0601B4B0 ; mov.b r1,@(r0,r12)
L_0601B410:
    c.r[1] += 1;  // 0601B410 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B412 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0601B414 mov r1,r0
    c.r[0] >>= 2;  // 0601B416 shlr2 r0
    c.r[0] >>= 2;  // 0601B418 shlr2 r0
    c.r[0] >>= 2;  // 0601B41A shlr2 r0
    c.r[0] &= 0x1u;  // 0601B41C and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601B41E tst r0,r0
    { const bool k = c.t; c.r[8] -= 1; if (k) { goto L_0601B458; } }  // 0601B420 bt/s 0x0601B458 ; add #-1,r8
    c.r[1] = ld32(0x0601B43Cu);  // 0601B424 mov.l 0x0601B43C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B426 mov.b @r1,r1
    c.r[2] = ld32(0x0601B438u);  // 0601B428 mov.l 0x0601B438,r2
    c.r[0] = c.r[1] & 0xFFu;  // 0601B42A extu.b r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0601B42C mov.b @(r0,r2),r1
    c.r[1] -= c.r[8];  // 0601B42E sub r8,r1
    st8(c.r[0] + c.r[2], c.r[1]); goto L_0601B4B0;  // 0601B430 bra 0x0601B4B0 ; mov.b r1,@(r0,r2)
L_0601B458:
    c.r[1] = ld32(0x0601B564u);  // 0601B458 mov.l 0x0601B564,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B45A mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0601B45C extu.b r1,r0
    c.r[1] = ld32(0x0601B568u);  // 0601B45E mov.l 0x0601B568,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601B460 mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601B462 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601B464 tst r1,r1
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_0601B4B2; } }  // 0601B466 bt/s 0x0601B4B2 ; mov r9,r1
L_0601B46A:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601B55Cu);  // 0601B46A mov.w 0x0601B55C,r0
    c.r[15] = c.r[14]; goto L_0601B6D2;  // 0601B46C bra 0x0601B6D2 ; mov r14,r15
L_0601B470:
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B470 mov.b @r1,r3
    c.r[2] = c.r[3] & 0xFFu;  // 0601B472 extu.b r3,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601B55Eu);  // 0601B474 mov.w 0x0601B55E,r1
    c.t = c.r[2] == c.r[1];  // 0601B476 cmp/eq r1,r2
    if (c.t) { SH2_POLL(c); goto L_0601B46A; }  // 0601B478 bt 0x0601B46A
    c.r[1] = ld32(0x0601B564u);  // 0601B47A mov.l 0x0601B564,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B47C mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0601B47E extu.b r1,r0
    c.r[1] = ld32(0x0601B568u);  // 0601B480 mov.l 0x0601B568,r1
    st8(c.r[0] + c.r[1], c.r[3]); goto L_0601B4B0;  // 0601B482 bra 0x0601B4B0 ; mov.b r3,@(r0,r1)
L_0601B486:
    c.r[10] = ld32(0x0601B564u);  // 0601B486 mov.l 0x0601B564,r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0601B488 mov.b @r10,r1
    c.r[11] = ld32(0x0601B568u);  // 0601B48A mov.l 0x0601B568,r11
    c.r[0] = c.r[1] & 0xFFu;  // 0601B48C extu.b r1,r0
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 0601B48E mov.b @(r0,r11),r8
    c.r[1] = ld32(0x0601B56Cu);  // 0601B490 mov.l 0x0601B56C,r1
    c.r[4] = ld32(c.r[1]);  // 0601B492 mov.l @r1,r4
    c.r[0] = ld32(0x0601B570u);  // 0601B494 mov.l 0x0601B570,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601B49Au; c.r[8] = c.r[8] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601B49Au) return; }  // 0601B496 jsr @r0 ; extu.b r8,r8
    c.r[0] -= 1;  // 0601B49A add #-1,r0
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[0];  // 0601B49C cmp/ge r0,r8
    { const bool k = c.t; c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]); if (k) { goto L_0601B4AA; } }  // 0601B49E bt/s 0x0601B4AA ; mov.b @r10,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0601B4A2 extu.b r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 0601B4A4 mov.b @(r0,r11),r1
    c.r[1] += 1; goto L_0601B4AE;  // 0601B4A6 bra 0x0601B4AE ; add #1,r1
L_0601B4AA:
    c.r[0] = c.r[1] & 0xFFu;  // 0601B4AA extu.b r1,r0
    c.r[1] = 0x0u;  // 0601B4AC mov #0,r1
L_0601B4AE:
    st8(c.r[0] + c.r[11], c.r[1]);  // 0601B4AE mov.b r1,@(r0,r11)
L_0601B4B0:
    c.r[1] = c.r[9];  // 0601B4B0 mov r9,r1
L_0601B4B2:
    c.r[1] += 1;  // 0601B4B2 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B4B4 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0601B4B6 mov r1,r0
    c.r[0] >>= 2;  // 0601B4B8 shlr2 r0
    c.r[0] >>= 2;  // 0601B4BA shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0601B4BC shlr r0
    c.r[0] >>= 2;  // 0601B4BE shlr2 r0
    c.r[0] &= 0x1u;  // 0601B4C0 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601B4C2 tst r0,r0
    if (!c.t) { SH2_POLL(c); goto L_0601B46A; }  // 0601B4C4 bf 0x0601B46A
L_0601B4C6:
    c.r[1] = ld32(0x0601B574u);  // 0601B4C6 mov.l 0x0601B574,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0601B4C8 mov.w @r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0601B560u);  // 0601B4CA mov.w 0x0601B560,r2
    c.r[2] &= c.r[1];  // 0601B4CC and r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0601B4CE tst r2,r2
    if (!c.t) { goto L_0601B4D6; }  // 0601B4D0 bf 0x0601B4D6
    goto L_0601B5E2;  // 0601B4D2 bra 0x0601B5E2 ; nop
L_0601B4D6:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0601B4D6 mov.b @r9,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601B562u);  // 0601B4D8 mov.w 0x0601B562,r0
    c.r[1] &= c.r[0];  // 0601B4DA and r0,r1
    c.r[1] >>= 2;  // 0601B4DC shlr2 r1
    c.r[1] >>= 2;  // 0601B4DE shlr2 r1
    c.r[1] >>= 2;  // 0601B4E0 shlr2 r1
    c.r[0] = c.r[1];  // 0601B4E2 mov r1,r0
    c.t = c.r[0] == 0x1u;  // 0601B4E4 cmp/eq #1,r0
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_0601B4F4; } }  // 0601B4E6 bt/s 0x0601B4F4 ; mov r9,r1
    c.t = c.r[0] == 0x2u;  // 0601B4EA cmp/eq #2,r0
    { const bool k = c.t; c.r[1] += 6; if (k) { goto L_0601B5B0; } }  // 0601B4EC bt/s 0x0601B5B0 ; add #6,r1
    c.r[1] = c.r[9]; goto L_0601B5CA;  // 0601B4F0 bra 0x0601B5CA ; mov r9,r1
L_0601B4F4:
    c.r[1] += 5;  // 0601B4F4 add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B4F6 mov.b @r1,r1
    c.r[10] = c.r[1] & 0xFFu;  // 0601B4F8 extu.b r1,r10
    c.r[1] = c.r[9];  // 0601B4FA mov r9,r1
    c.r[1] += 4;  // 0601B4FC add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B4FE mov.b @r1,r1
    c.r[8] = c.r[1] & 0xFFu;  // 0601B500 extu.b r1,r8
    c.r[1] = ld32(0x0601B564u);  // 0601B502 mov.l 0x0601B564,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B504 mov.b @r1,r1
    c.r[3] = ld32(0x0601B568u);  // 0601B506 mov.l 0x0601B568,r3
    c.r[2] = c.r[1] & 0xFFu;  // 0601B508 extu.b r1,r2
    c.r[0] = c.r[2];  // 0601B50A mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0601B50C mov.b @(r0,r3),r1
    c.r[7] = c.r[1] & 0xFFu;  // 0601B50E extu.b r1,r7
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[8];  // 0601B510 cmp/ge r8,r7
    { const bool k = !c.t; c.r[1] -= c.r[8]; if (k) { goto L_0601B51A; } }  // 0601B512 bf/s 0x0601B51A ; sub r8,r1
    st8(c.r[0] + c.r[3], c.r[1]); goto L_0601B5C8;  // 0601B516 bra 0x0601B5C8 ; mov.b r1,@(r0,r3)
L_0601B51A:
    c.r[1] = c.r[9];  // 0601B51A mov r9,r1
    c.r[1] += 1;  // 0601B51C add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B51E mov.b @r1,r1
    c.r[0] = c.r[1];  // 0601B520 mov r1,r0
    c.r[0] >>= 2;  // 0601B522 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0601B524 shlr r0
    c.r[0] >>= 2;  // 0601B526 shlr2 r0
    c.r[0] &= 0x1u;  // 0601B528 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601B52A tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { SH2_POLL(c); goto L_0601B46A; } }  // 0601B52C bt/s 0x0601B46A ; mov r9,r1
    c.r[1] += 8;  // 0601B530 add #8,r1
    c.r[0] = c.r[2];  // 0601B532 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B534 mov.b @r1,r1
    c.macl = c.r[10] * c.r[8];  // 0601B536 mul.l r8,r10
    c.r[3] = c.r[1] & 0xFFu;  // 0601B538 extu.b r1,r3
    c.r[1] = c.r[9];  // 0601B53A mov r9,r1
    c.r[1] += 9;  // 0601B53C add #9,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B53E mov.b @r1,r1
    c.r[3] <<= 8;  // 0601B540 shll8 r3
    c.r[1] = c.r[1] & 0xFFu;  // 0601B542 extu.b r1,r1
    c.r[3] |= c.r[1];  // 0601B544 or r1,r3
    c.r[1] = ld32(0x0601B578u);  // 0601B546 mov.l 0x0601B578,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601B548 mov.b @(r0,r1),r1
    c.r[4] = c.macl;  // 0601B54A sts macl,r4
    c.r[1] = c.r[1] & 0xFFu;  // 0601B54C extu.b r1,r1
    c.r[1] -= 1;  // 0601B54E add #-1,r1
    c.macl = c.r[1] * c.r[10];  // 0601B550 mul.l r10,r1
    c.r[4] -= c.r[8];  // 0601B552 sub r8,r4
    c.r[1] = c.macl;  // 0601B554 sts macl,r1
    c.macl = c.r[1] * c.r[8];  // 0601B556 mul.l r8,r1
    c.r[4] += c.r[7]; goto L_0601B596;  // 0601B558 bra 0x0601B596 ; add r7,r4
L_0601B57C:
    c.r[1] = ld32(0x0601B6ECu);  // 0601B57C mov.l 0x0601B6EC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601B57E mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601B580 extu.b r1,r1
    c.t = (int32_t)c.r[4] > (int32_t)c.r[1];  // 0601B582 cmp/gt r1,r4
    if (!c.t) { goto L_0601B5A4; }  // 0601B584 bf 0x0601B5A4
    c.r[4] -= c.r[8];  // 0601B586 sub r8,r4
    c.r[1] = ld32(0x0601B6F0u);  // 0601B588 mov.l 0x0601B6F0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601B58A mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601B58C extu.b r1,r1
    c.r[1] -= 1;  // 0601B58E add #-1,r1
    c.macl = c.r[1] * c.r[10];  // 0601B590 mul.l r10,r1
    c.r[1] = c.macl;  // 0601B592 sts macl,r1
    c.macl = c.r[1] * c.r[8];  // 0601B594 mul.l r8,r1
L_0601B596:
    c.r[0] = c.r[3];  // 0601B596 mov r3,r0
    c.r[1] = c.macl;  // 0601B598 sts macl,r1
    c.r[0] -= c.r[1];  // 0601B59A sub r1,r0
    c.r[1] = c.r[0];  // 0601B59C mov r0,r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[4];  // 0601B59E cmp/gt r4,r1
    { const bool k = !c.t; c.r[0] = c.r[2]; if (k) { SH2_POLL(c); goto L_0601B57C; } }  // 0601B5A0 bf/s 0x0601B57C ; mov r2,r0
L_0601B5A4:
    c.r[1] = ld32(0x0601B6F4u);  // 0601B5A4 mov.l 0x0601B6F4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B5A6 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0601B5A8 extu.b r1,r0
    c.r[1] = ld32(0x0601B6ECu);  // 0601B5AA mov.l 0x0601B6EC,r1
    st8(c.r[0] + c.r[1], c.r[4]); goto L_0601B5C8;  // 0601B5AC bra 0x0601B5C8 ; mov.b r4,@(r0,r1)
L_0601B5B0:
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B5B0 mov.b @r1,r3
    c.r[2] = c.r[3] & 0xFFu;  // 0601B5B2 extu.b r3,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601B6E4u);  // 0601B5B4 mov.w 0x0601B6E4,r1
    c.t = c.r[2] == c.r[1];  // 0601B5B6 cmp/eq r1,r2
    if (!c.t) { goto L_0601B5BE; }  // 0601B5B8 bf 0x0601B5BE
    SH2_POLL(c); goto L_0601B46A;  // 0601B5BA bra 0x0601B46A ; nop
L_0601B5BE:
    c.r[1] = ld32(0x0601B6F4u);  // 0601B5BE mov.l 0x0601B6F4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B5C0 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0601B5C2 extu.b r1,r0
    c.r[1] = ld32(0x0601B6ECu);  // 0601B5C4 mov.l 0x0601B6EC,r1
    st8(c.r[0] + c.r[1], c.r[3]);  // 0601B5C6 mov.b r3,@(r0,r1)
L_0601B5C8:
    c.r[1] = c.r[9];  // 0601B5C8 mov r9,r1
L_0601B5CA:
    c.r[1] += 1;  // 0601B5CA add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B5CC mov.b @r1,r1
    c.r[0] = c.r[1];  // 0601B5CE mov r1,r0
    c.r[0] >>= 2;  // 0601B5D0 shlr2 r0
    c.r[0] >>= 2;  // 0601B5D2 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0601B5D4 shlr r0
    c.r[0] >>= 2;  // 0601B5D6 shlr2 r0
    c.r[0] &= 0x1u;  // 0601B5D8 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601B5DA tst r0,r0
    if (c.t) { goto L_0601B5E2; }  // 0601B5DC bt 0x0601B5E2
    SH2_POLL(c); goto L_0601B46A;  // 0601B5DE bra 0x0601B46A ; nop
L_0601B5E2:
    c.r[1] = ld32(0x0601B6F8u);  // 0601B5E2 mov.l 0x0601B6F8,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0601B5E4 mov.w @r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0601B6E6u);  // 0601B5E6 mov.w 0x0601B6E6,r2
    c.r[2] &= c.r[1];  // 0601B5E8 and r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0601B5EA tst r2,r2
    if (c.t) { goto L_0601B6C8; }  // 0601B5EC bt 0x0601B6C8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0601B5EE mov.b @r9,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601B6E8u);  // 0601B5F0 mov.w 0x0601B6E8,r0
    c.r[1] &= c.r[0];  // 0601B5F2 and r0,r1
    c.r[1] >>= 2;  // 0601B5F4 shlr2 r1
    c.r[1] >>= 2;  // 0601B5F6 shlr2 r1
    c.r[1] >>= 2;  // 0601B5F8 shlr2 r1
    c.r[0] = c.r[1];  // 0601B5FA mov r1,r0
    c.t = c.r[0] == 0x1u;  // 0601B5FC cmp/eq #1,r0
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_0601B60C; } }  // 0601B5FE bt/s 0x0601B60C ; mov r9,r1
    c.t = c.r[0] == 0x2u;  // 0601B602 cmp/eq #2,r0
    { const bool k = c.t; c.r[1] += 7; if (k) { goto L_0601B696; } }  // 0601B604 bt/s 0x0601B696 ; add #7,r1
    c.r[1] = c.r[9]; goto L_0601B6B0;  // 0601B608 bra 0x0601B6B0 ; mov r9,r1
L_0601B60C:
    c.r[1] += 5;  // 0601B60C add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B60E mov.b @r1,r1
    c.r[10] = c.r[1] & 0xFFu;  // 0601B610 extu.b r1,r10
    c.r[1] = c.r[9];  // 0601B612 mov r9,r1
    c.r[1] += 4;  // 0601B614 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B616 mov.b @r1,r1
    c.r[8] = c.r[1] & 0xFFu;  // 0601B618 extu.b r1,r8
    c.r[1] = c.r[9];  // 0601B61A mov r9,r1
    c.r[1] += 8;  // 0601B61C add #8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B61E mov.b @r1,r1
    c.macl = c.r[10] * c.r[8];  // 0601B620 mul.l r8,r10
    c.r[4] = c.r[1] & 0xFFu;  // 0601B622 extu.b r1,r4
    c.r[1] = c.r[9];  // 0601B624 mov r9,r1
    c.r[1] += 9;  // 0601B626 add #9,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B628 mov.b @r1,r1
    c.r[4] <<= 8;  // 0601B62A shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 0601B62C extu.b r1,r1
    c.r[4] |= c.r[1];  // 0601B62E or r1,r4
    c.r[1] = ld32(0x0601B6F4u);  // 0601B630 mov.l 0x0601B6F4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B632 mov.b @r1,r1
    c.r[10] = c.r[1] & 0xFFu;  // 0601B634 extu.b r1,r10
    c.r[1] = ld32(0x0601B6F0u);  // 0601B636 mov.l 0x0601B6F0,r1
    c.r[0] = c.r[10];  // 0601B638 mov r10,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601B63A mov.b @(r0,r1),r1
    c.r[2] = c.macl;  // 0601B63C sts macl,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0601B63E extu.b r1,r1
    c.r[1] -= 1;  // 0601B640 add #-1,r1
    c.macl = c.r[2] * c.r[1];  // 0601B642 mul.l r1,r2
    c.r[1] = c.macl;  // 0601B644 sts macl,r1
    c.macl = c.r[2];  // 0601B646 lds r2,macl
    c.r[4] -= c.r[1];  // 0601B648 sub r1,r4
    c.r[1] = c.macl;  // 0601B64A sts macl,r1
    c.t = (int32_t)c.r[4] > (int32_t)c.r[1];  // 0601B64C cmp/gt r1,r4
    if (!c.t) { goto L_0601B652; }  // 0601B64E bf 0x0601B652
    c.r[4] = c.macl;  // 0601B650 sts macl,r4
L_0601B652:
    c.r[11] = ld32(0x0601B6ECu);  // 0601B652 mov.l 0x0601B6EC,r11
    c.r[0] = c.r[10];  // 0601B654 mov r10,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 0601B656 mov.b @(r0,r11),r2
    c.r[6] = c.r[2] & 0xFFu;  // 0601B658 extu.b r2,r6
    c.r[1] = c.r[6];  // 0601B65A mov r6,r1
    c.r[1] += c.r[8];  // 0601B65C add r8,r1
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[4];  // 0601B65E cmp/ge r4,r1
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_0601B66A; } }  // 0601B660 bt/s 0x0601B66A ; mov r9,r1
    c.r[8] += c.r[2];  // 0601B664 add r2,r8
    st8(c.r[0] + c.r[11], c.r[8]); goto L_0601B6B0;  // 0601B666 bra 0x0601B6B0 ; mov.b r8,@(r0,r11)
L_0601B66A:
    c.r[1] += 1;  // 0601B66A add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B66C mov.b @r1,r1
    c.r[0] = c.r[1];  // 0601B66E mov r1,r0
    c.r[0] >>= 2;  // 0601B670 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0601B672 shlr r0
    c.r[0] >>= 2;  // 0601B674 shlr2 r0
    c.r[0] &= 0x1u;  // 0601B676 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601B678 tst r0,r0
    { const bool k = !c.t; c.r[4] = c.r[6]; if (k) { goto L_0601B682; } }  // 0601B67A bf/s 0x0601B682 ; mov r6,r4
    SH2_POLL(c); goto L_0601B46A;  // 0601B67E bra 0x0601B46A ; nop
L_0601B682:
    c.r[7] = ld32(0x0601B6FCu);  // 0601B682 mov.l 0x0601B6FC,r7
    { const uint32_t x = c.r[7]; c.pr = 0x0601B688u; c.r[5] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601B688u) return; }  // 0601B684 jsr @r7 ; mov r8,r5
    c.r[7] = c.r[0];  // 0601B688 mov r0,r7
    c.macl = c.r[7] * c.r[8];  // 0601B68A mul.l r8,r7
    c.r[0] = c.r[10];  // 0601B68C mov r10,r0
    c.r[1] = c.macl;  // 0601B68E sts macl,r1
    c.r[6] -= c.r[1];  // 0601B690 sub r1,r6
    st8(c.r[0] + c.r[11], c.r[6]); goto L_0601B6AE;  // 0601B692 bra 0x0601B6AE ; mov.b r6,@(r0,r11)
L_0601B696:
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B696 mov.b @r1,r3
    c.r[2] = c.r[3] & 0xFFu;  // 0601B698 extu.b r3,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601B6E4u);  // 0601B69A mov.w 0x0601B6E4,r1
    c.t = c.r[2] == c.r[1];  // 0601B69C cmp/eq r1,r2
    if (!c.t) { goto L_0601B6A4; }  // 0601B69E bf 0x0601B6A4
    SH2_POLL(c); goto L_0601B46A;  // 0601B6A0 bra 0x0601B46A ; nop
L_0601B6A4:
    c.r[1] = ld32(0x0601B6F4u);  // 0601B6A4 mov.l 0x0601B6F4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B6A6 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0601B6A8 extu.b r1,r0
    c.r[1] = ld32(0x0601B6ECu);  // 0601B6AA mov.l 0x0601B6EC,r1
    st8(c.r[0] + c.r[1], c.r[3]);  // 0601B6AC mov.b r3,@(r0,r1)
L_0601B6AE:
    c.r[1] = c.r[9];  // 0601B6AE mov r9,r1
L_0601B6B0:
    c.r[1] += 1;  // 0601B6B0 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B6B2 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0601B6B4 mov r1,r0
    c.r[0] >>= 2;  // 0601B6B6 shlr2 r0
    c.r[0] >>= 2;  // 0601B6B8 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0601B6BA shlr r0
    c.r[0] >>= 2;  // 0601B6BC shlr2 r0
    c.r[0] &= 0x1u;  // 0601B6BE and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601B6C0 tst r0,r0
    if (c.t) { goto L_0601B6C8; }  // 0601B6C2 bt 0x0601B6C8
    SH2_POLL(c); goto L_0601B46A;  // 0601B6C4 bra 0x0601B46A ; nop
L_0601B6C8:
    c.r[1] = ld32(0x0601B700u);  // 0601B6C8 mov.l 0x0601B700,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601B6CEu; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601B6CEu) return; }  // 0601B6CA jsr @r1 ; mov r9,r4
    c.r[0] = 0x0u;  // 0601B6CE mov #0,r0
    c.r[15] = c.r[14];  // 0601B6D0 mov r14,r15
L_0601B6D2:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601B6D2 lds.l @r15+,pr
L_0601B6D4:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601B6D4 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0601B6D6 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0601B6D8 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0601B6DA mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0601B6DC mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0601B6DE mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601B6E0 rts ; mov.l @r15+,r8
}

void f_0601B704(SH2Context& c) {
    ran[263] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601B704 mov.l r14,@-r15
    c.r[1] = ld32(0x0601B728u);  // 0601B706 mov.l 0x0601B728,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B708 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0601B70A extu.b r1,r0
    c.r[1] = ld32(0x0601B72Cu);  // 0601B70C mov.l 0x0601B72C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601B70E mov.b @(r0,r1),r1
    c.r[14] = c.r[15];  // 0601B710 mov r15,r14
    c.r[0] = c.r[1] & 0xFFu;  // 0601B712 extu.b r1,r0
    c.r[1] = ld32(0x0601B730u);  // 0601B714 mov.l 0x0601B730,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601B716 mov.b @(r0,r1),r1
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601B718 mov.l @r15+,r14
    c.r[0] = c.r[1] & 0xFFu;  // 0601B71A extu.b r1,r0
    c.r[0] += c.r[0];  // 0601B71C add r0,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601B724u);  // 0601B71E mov.w 0x0601B724,r1
    { const uint32_t x = c.pr; c.r[0] |= c.r[1]; c.pc = x; return; }  // 0601B720 rts ; or r1,r0
}

void f_0601B734(SH2Context& c) {
    ran[264] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601B734 mov.l r14,@-r15
    c.r[1] = ld32(0x0601B758u);  // 0601B736 mov.l 0x0601B758,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B738 mov.b @r1,r1
    c.r[14] = c.r[15];  // 0601B73A mov r15,r14
    c.r[0] = c.r[1] & 0xFFu;  // 0601B73C extu.b r1,r0
    c.r[1] = ld32(0x0601B75Cu);  // 0601B73E mov.l 0x0601B75C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601B740 mov.b @(r0,r1),r1
    c.r[2] = ld32(0x0601B760u);  // 0601B742 mov.l 0x0601B760,r2
    c.r[0] = c.r[1] & 0xFFu;  // 0601B744 extu.b r1,r0
    c.r[1] = ld32(0x0601B764u);  // 0601B746 mov.l 0x0601B764,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601B748 mov.b @(r0,r1),r1
    c.r[1] += 1;  // 0601B74A add #1,r1
    st8(c.r[2], c.r[1]);  // 0601B74C mov.b r1,@r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601B754u);  // 0601B74E mov.w 0x0601B754,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601B750 rts ; mov.l @r15+,r14
}

void f_0601B768(SH2Context& c) {
    ran[265] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601B768 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0601B76A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0601B76C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601B76E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601B770 sts.l pr,@-r15
    c.r[10] = ld32(0x0601B814u);  // 0601B772 mov.l 0x0601B814,r10
    c.r[1] = ld32(c.r[10]);  // 0601B774 mov.l @r10,r1
    c.r[1] += 2;  // 0601B776 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B778 mov.b @r1,r1
    c.r[9] = c.r[1] & 0xFFu;  // 0601B77A extu.b r1,r9
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601B80Cu);  // 0601B77C mov.w 0x0601B80C,r1
    c.t = c.r[9] == c.r[1];  // 0601B77E cmp/eq r1,r9
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0601B796; } }  // 0601B780 bt/s 0x0601B796 ; mov r15,r14
    c.r[4] = ld32(0x0601B818u);  // 0601B784 mov.l 0x0601B818,r4
    c.r[8] = ld32(0x0601B81Cu);  // 0601B786 mov.l 0x0601B81C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0601B78Cu; c.r[5] = 0x1Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601B78Cu) return; }  // 0601B788 jsr @r8 ; mov #26,r5
    c.r[5] = c.r[9];  // 0601B78C mov r9,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0601B792u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601B792u) return; }  // 0601B78E jsr @r8 ; mov r0,r4
    c.r[1] = ld32(0x0601B820u);  // 0601B792 mov.l 0x0601B820,r1
    st32(c.r[1], c.r[0]);  // 0601B794 mov.l r0,@r1
L_0601B796:
    c.r[1] = ld32(0x0601B820u);  // 0601B796 mov.l 0x0601B820,r1
    c.r[7] = ld32(c.r[1]);  // 0601B798 mov.l @r1,r7
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0601B79A mov.b @r7,r0
    c.r[0] &= 0xC0u;  // 0601B79C and #192,r0
    c.r[0] >>= 2;  // 0601B79E shlr2 r0
    c.r[0] >>= 2;  // 0601B7A0 shlr2 r0
    c.r[0] >>= 2;  // 0601B7A2 shlr2 r0
    c.t = c.r[0] == 0x1u;  // 0601B7A4 cmp/eq #1,r0
    { const bool k = c.t; c.r[4] = c.r[7]; if (k) { goto L_0601B7BC; } }  // 0601B7A6 bt/s 0x0601B7BC ; mov r7,r4
    c.r[1] = ld32(0x0601B824u);  // 0601B7AA mov.l 0x0601B824,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B7AC mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0601B7AE extu.b r1,r0
    c.r[1] = ld32(0x0601B828u);  // 0601B7B0 mov.l 0x0601B828,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601B7B2 mov.b @(r0,r1),r5
    c.r[0] = ld32(0x0601B82Cu);  // 0601B7B4 mov.l 0x0601B82C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601B7BAu; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601B7BAu) return; }  // 0601B7B6 jsr @r0 ; extu.b r5,r5
    c.r[7] = c.r[0];  // 0601B7BA mov r0,r7
L_0601B7BC:
    c.r[3] = ld32(0x0601B830u);  // 0601B7BC mov.l 0x0601B830,r3
    c.r[2] = c.r[3];  // 0601B7BE mov r3,r2
    c.r[1] = ld32(c.r[10]);  // 0601B7C0 mov.l @r10,r1
    c.r[2] += 32;  // 0601B7C2 add #32,r2
    c.r[1] += 1;  // 0601B7C4 add #1,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B7C6 mov.b @r1,r0
    c.r[6] = (uint32_t)(int16_t)ld16(0x0601B80Eu);  // 0601B7C8 mov.w 0x0601B80E,r6
    c.r[0] &= 0x1u;  // 0601B7CA and #1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601B7CC mov.b @r2,r1
    c.r[0] <<= 2;  // 0601B7CE shll2 r0
    c.r[0] += c.r[0];  // 0601B7D0 add r0,r0
    c.r[1] &= c.r[6];  // 0601B7D2 and r6,r1
    c.r[1] |= c.r[0];  // 0601B7D4 or r0,r1
    st8(c.r[2], c.r[1]);  // 0601B7D6 mov.b r1,@r2
    c.r[0] = c.r[1];  // 0601B7D8 mov r1,r0
    c.r[0] >>= 2;  // 0601B7DA shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0601B7DC shlr r0
    c.r[0] &= 0x1u;  // 0601B7DE and #1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601B810u);  // 0601B7E0 mov.w 0x0601B810,r1
    c.macl = (c.r[0] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 0601B7E2 mulu.w r1,r0
    c.r[1] = c.macl;  // 0601B7E4 sts macl,r1
    c.r[1] += c.r[3];  // 0601B7E6 add r3,r1
    c.r[1] += 72;  // 0601B7E8 add #72,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0601B7EA mov.w @r1,r1
    c.r[2] = ld32(0x0601B834u);  // 0601B7EC mov.l 0x0601B834,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 0601B7EE extu.w r1,r1
    c.t = c.r[1] == c.r[2];  // 0601B7F0 cmp/eq r2,r1
    { const bool k = !c.t; c.r[5] = c.r[7]; if (k) { goto L_0601B7FC; } }  // 0601B7F2 bf/s 0x0601B7FC ; mov r7,r5
    c.r[1] = ld32(0x0601B838u);  // 0601B7F6 mov.l 0x0601B838,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601B7FCu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601B7FCu) return; }  // 0601B7F8 jsr @r1 ; mov r0,r4
L_0601B7FC:
    c.r[15] = c.r[14];  // 0601B7FC mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601B7FE lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601B800 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0601B802 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0601B804 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601B812u);  // 0601B806 mov.w 0x0601B812,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601B808 rts ; mov.l @r15+,r8
}

void f_0601B83C(SH2Context& c) {
    ran[266] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601B83C mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0601B83E mov r15,r14
    c.r[1] = ld32(0x0601B854u);  // 0601B840 mov.l 0x0601B854,r1
    c.r[1] = ld32(c.r[1]);  // 0601B842 mov.l @r1,r1
    c.r[2] = ld32(0x0601B858u);  // 0601B844 mov.l 0x0601B858,r2
    c.r[1] += 1;  // 0601B846 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B848 mov.b @r1,r1
    st8(c.r[2], c.r[1]);  // 0601B84A mov.b r1,@r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601B852u);  // 0601B84C mov.w 0x0601B852,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601B84E rts ; mov.l @r15+,r14
}

void f_0601B85C(SH2Context& c) {
    ran[267] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601B85C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0601B85E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0601B860 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0601B862 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0601B864 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601B866 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601B868 sts.l pr,@-r15
    c.r[1] = ld32(0x0601B928u);  // 0601B86A mov.l 0x0601B928,r1
    c.r[2] = ld32(c.r[1]);  // 0601B86C mov.l @r1,r2
    c.r[1] = c.r[2];  // 0601B86E mov r2,r1
    c.r[1] += 5;  // 0601B870 add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B872 mov.b @r1,r1
    c.r[6] = c.r[1] & 0xFFu;  // 0601B874 extu.b r1,r6
    c.r[1] = c.r[2];  // 0601B876 mov r2,r1
    c.r[1] += 4;  // 0601B878 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B87A mov.b @r1,r1
    c.r[7] = c.r[1] & 0xFFu;  // 0601B87C extu.b r1,r7
    c.r[1] = c.r[2];  // 0601B87E mov r2,r1
    c.r[1] += 8;  // 0601B880 add #8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B882 mov.b @r1,r1
    c.r[2] += 9;  // 0601B884 add #9,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0601B886 extu.b r1,r1
    c.r[9] = c.r[1];  // 0601B888 mov r1,r9
    c.r[9] <<= 8;  // 0601B88A shll8 r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601B88C mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601B88E extu.b r1,r1
    c.r[9] |= c.r[1];  // 0601B890 or r1,r9
    c.r[1] = ld32(0x0601B92Cu);  // 0601B892 mov.l 0x0601B92C,r1
    c.r[1] = ld32(c.r[1]);  // 0601B894 mov.l @r1,r1
    c.r[1] += 1;  // 0601B896 add #1,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B898 mov.b @r1,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0601B89A cmp/eq #-1,r0
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0601B8BA; } }  // 0601B89C bf/s 0x0601B8BA ; mov r15,r14
    c.r[1] = ld32(0x0601B930u);  // 0601B8A0 mov.l 0x0601B930,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B8A2 mov.b @r1,r1
    c.r[3] = ld32(0x0601B934u);  // 0601B8A4 mov.l 0x0601B934,r3
    c.r[2] = c.r[1] & 0xFFu;  // 0601B8A6 extu.b r1,r2
    c.r[0] = c.r[2];  // 0601B8A8 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0601B8AA mov.b @(r0,r3),r1
    c.r[5] = c.r[1] & 0xFFu;  // 0601B8AC extu.b r1,r5
    c.r[0] = c.r[5];  // 0601B8AE mov r5,r0
    c.t = c.r[0] == 0x1u;  // 0601B8B0 cmp/eq #1,r0
    { const bool k = c.t; c.r[1] -= 1; if (k) { goto L_0601B8BA; } }  // 0601B8B2 bt/s 0x0601B8BA ; add #-1,r1
    c.r[0] = c.r[2];  // 0601B8B6 mov r2,r0
    st8(c.r[0] + c.r[3], c.r[1]);  // 0601B8B8 mov.b r1,@(r0,r3)
L_0601B8BA:
    c.r[1] = ld32(0x0601B92Cu);  // 0601B8BA mov.l 0x0601B92C,r1
    c.r[1] = ld32(c.r[1]);  // 0601B8BC mov.l @r1,r1
    c.r[1] += 1;  // 0601B8BE add #1,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B8C0 mov.b @r1,r0
    c.t = c.r[0] == 0x1u;  // 0601B8C2 cmp/eq #1,r0
    { const bool k = !c.t; c.macl = c.r[6] * c.r[7]; if (k) { goto L_0601B912; } }  // 0601B8C4 bf/s 0x0601B912 ; mul.l r7,r6
    c.r[12] = ld32(0x0601B930u);  // 0601B8C8 mov.l 0x0601B930,r12
    c.r[10] = ld32(0x0601B934u);  // 0601B8CA mov.l 0x0601B934,r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[12]);  // 0601B8CC mov.b @r12,r1
    c.r[8] = c.r[1] & 0xFFu;  // 0601B8CE extu.b r1,r8
    c.r[0] = c.r[8];  // 0601B8D0 mov r8,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 0601B8D2 mov.b @(r0,r10),r1
    c.r[3] = c.macl;  // 0601B8D4 sts macl,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0601B8D6 extu.b r1,r1
    c.macl = c.r[3] * c.r[1];  // 0601B8D8 mul.l r1,r3
    c.r[2] = c.macl;  // 0601B8DA sts macl,r2
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[9];  // 0601B8DC cmp/ge r9,r2
    { const bool k = c.t; c.r[15] = c.r[14]; if (k) { goto L_0601B914; } }  // 0601B8DE bt/s 0x0601B914 ; mov r14,r15
    c.r[11] = ld32(0x0601B938u);  // 0601B8E2 mov.l 0x0601B938,r11
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 0601B8E4 mov.b @(r0,r11),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601B8E6 extu.b r1,r1
    c.r[2] += c.r[1];  // 0601B8E8 add r1,r2
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[9];  // 0601B8EA cmp/ge r9,r2
    { const bool k = !c.t; c.macl = c.r[3]; if (k) { goto L_0601B908; } }  // 0601B8EC bf/s 0x0601B908 ; lds r3,macl
    c.r[4] = c.r[9];  // 0601B8F0 mov r9,r4
    c.r[6] = ld32(0x0601B93Cu);  // 0601B8F2 mov.l 0x0601B93C,r6
    c.r[7] = c.macl;  // 0601B8F4 sts macl,r7
    { const uint32_t x = c.r[6]; c.pr = 0x0601B8FAu; c.r[5] = c.macl; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601B8FAu) return; }  // 0601B8F6 jsr @r6 ; sts macl,r5
    c.r[6] = c.r[0];  // 0601B8FA mov r0,r6
    c.macl = c.r[6] * c.r[7];  // 0601B8FC mul.l r7,r6
    c.r[0] = c.r[8];  // 0601B8FE mov r8,r0
    c.r[1] = c.macl;  // 0601B900 sts macl,r1
    c.r[9] -= c.r[1];  // 0601B902 sub r1,r9
    c.r[9] -= 1;  // 0601B904 add #-1,r9
    st8(c.r[0] + c.r[11], c.r[9]);  // 0601B906 mov.b r9,@(r0,r11)
L_0601B908:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[12]);  // 0601B908 mov.b @r12,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0601B90A extu.b r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 0601B90C mov.b @(r0,r10),r1
    c.r[1] += 1;  // 0601B90E add #1,r1
    st8(c.r[0] + c.r[10], c.r[1]);  // 0601B910 mov.b r1,@(r0,r10)
L_0601B912:
    c.r[15] = c.r[14];  // 0601B912 mov r14,r15
L_0601B914:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601B914 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601B916 mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0601B918 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0601B91A mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0601B91C mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0601B91E mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601B926u);  // 0601B920 mov.w 0x0601B926,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601B922 rts ; mov.l @r15+,r8
}

void f_0601B940(SH2Context& c) {
    ran[268] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601B940 mov.l r14,@-r15
    c.r[1] = ld32(0x0601B994u);  // 0601B942 mov.l 0x0601B994,r1
    c.r[3] = ld32(c.r[1]);  // 0601B944 mov.l @r1,r3
    c.r[1] = ld32(0x0601B998u);  // 0601B946 mov.l 0x0601B998,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B948 mov.b @r1,r1
    c.r[7] = c.r[1] & 0xFFu;  // 0601B94A extu.b r1,r7
    c.r[1] = ld32(0x0601B99Cu);  // 0601B94C mov.l 0x0601B99C,r1
    c.r[0] = c.r[7];  // 0601B94E mov r7,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601B950 mov.b @(r0,r1),r1
    c.r[2] = 0xBu;  // 0601B952 mov #11,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0601B954 extu.b r1,r1
    c.r[1] -= 1;  // 0601B956 add #-1,r1
    c.macl = c.r[1] * c.r[2];  // 0601B958 mul.l r2,r1
    c.r[14] = c.r[15];  // 0601B95A mov r15,r14
    c.r[1] = ld32(0x0601B9A0u);  // 0601B95C mov.l 0x0601B9A0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601B95E mov.b @(r0,r1),r1
    c.r[2] = c.macl;  // 0601B960 sts macl,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0601B962 extu.b r1,r1
    c.r[2] += c.r[1];  // 0601B964 add r1,r2
    c.r[2] += c.r[2];  // 0601B966 add r2,r2
    c.r[0] = c.r[3];  // 0601B968 mov r3,r0
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0601B96A mov.b @(r0,r2),r7
    c.r[1] = c.r[7] & 0xFFu;  // 0601B96C extu.b r7,r1
    c.r[1] >>= 2;  // 0601B96E shlr2 r1
    c.r[1] >>= 2;  // 0601B970 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0601B972 shlr r1
    c.r[1] >>= 2;  // 0601B974 shlr2 r1
    c.r[1] += 1;  // 0601B976 add #1,r1
    c.r[1] <<= 2;  // 0601B978 shll2 r1
    c.r[1] <<= 2;  // 0601B97A shll2 r1
    c.r[1] += c.r[1];  // 0601B97C add r1,r1
    c.r[1] <<= 2;  // 0601B97E shll2 r1
    c.r[0] = 0x7Fu;  // 0601B980 mov #127,r0
    c.r[7] &= c.r[0];  // 0601B982 and r0,r7
    c.r[7] |= c.r[1];  // 0601B984 or r1,r7
    c.r[0] = c.r[3];  // 0601B986 mov r3,r0
    st8(c.r[0] + c.r[2], c.r[7]);  // 0601B988 mov.b r7,@(r0,r2)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601B990u);  // 0601B98A mov.w 0x0601B990,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601B98C rts ; mov.l @r15+,r14
}

void f_0601B9A4(SH2Context& c) {
    ran[269] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601B9A4 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0601B9A6 mov r15,r14
    c.r[7] = ld32(0x0601B9CCu);  // 0601B9A8 mov.l 0x0601B9CC,r7
    c.r[1] = ld32(0x0601B9D0u);  // 0601B9AA mov.l 0x0601B9D0,r1
    c.r[3] = ld32(c.r[1]);  // 0601B9AC mov.l @r1,r3
    c.r[1] = c.r[3];  // 0601B9AE mov r3,r1
    c.r[1] += 1;  // 0601B9B0 add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B9B2 mov.b @r1,r2
    c.r[3] += 2;  // 0601B9B4 add #2,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0601B9B6 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0601B9B8 mov.b @r3,r1
    c.r[2] <<= 8;  // 0601B9BA shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0601B9BC extu.b r1,r1
    c.r[2] |= c.r[1];  // 0601B9BE or r1,r2
    st16(c.r[7], c.r[2]);  // 0601B9C0 mov.w r2,@r7
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601B9C8u);  // 0601B9C2 mov.w 0x0601B9C8,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601B9C4 rts ; mov.l @r15+,r14
}

void f_0601B9D4(SH2Context& c) {
    ran[270] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601B9D4 mov.l r14,@-r15
    c.r[1] = ld32(0x0601BA14u);  // 0601B9D6 mov.l 0x0601BA14,r1
    c.r[7] = ld32(c.r[1]);  // 0601B9D8 mov.l @r1,r7
    c.r[1] = c.r[7];  // 0601B9DA mov r7,r1
    c.r[1] += 1;  // 0601B9DC add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B9DE mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601B9E0 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601B9E2 tst r1,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0601B9FC; } }  // 0601B9E4 bt/s 0x0601B9FC ; mov r15,r14
    c.r[1] = ld32(0x0601BA18u);  // 0601B9E8 mov.l 0x0601BA18,r1
    c.r[3] = ld32(0x0601BA1Cu);  // 0601B9EA mov.l 0x0601BA1C,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B9EC mov.b @r1,r1
    c.r[7] += 2;  // 0601B9EE add #2,r7
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0601B9F0 mov.b @r7,r2
    c.r[0] = c.r[1] & 0xFFu;  // 0601B9F2 extu.b r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0601B9F4 mov.b @(r0,r3),r1
    c.r[1] += c.r[2];  // 0601B9F6 add r2,r1
    st8(c.r[0] + c.r[3], c.r[1]); goto L_0601BA0A;  // 0601B9F8 bra 0x0601BA0A ; mov.b r1,@(r0,r3)
L_0601B9FC:
    c.r[1] = ld32(0x0601BA18u);  // 0601B9FC mov.l 0x0601BA18,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601B9FE mov.b @r1,r1
    c.r[7] += 2;  // 0601BA00 add #2,r7
    c.r[0] = c.r[1] & 0xFFu;  // 0601BA02 extu.b r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0601BA04 mov.b @r7,r1
    c.r[2] = ld32(0x0601BA1Cu);  // 0601BA06 mov.l 0x0601BA1C,r2
    st8(c.r[0] + c.r[2], c.r[1]);  // 0601BA08 mov.b r1,@(r0,r2)
L_0601BA0A:
    c.r[15] = c.r[14];  // 0601BA0A mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601BA12u);  // 0601BA0C mov.w 0x0601BA12,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601BA0E rts ; mov.l @r15+,r14
}

void f_0601BA20(SH2Context& c) {
    ran[271] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601BA20 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601BA22 sts.l pr,@-r15
    c.r[1] = ld32(0x0601BA40u);  // 0601BA24 mov.l 0x0601BA40,r1
    c.r[1] = ld32(c.r[1]);  // 0601BA26 mov.l @r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601BA28 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0601BA2A extu.b r1,r0
    c.r[0] <<= 2;  // 0601BA2C shll2 r0
    c.r[1] = ld32(0x0601BA44u);  // 0601BA2E mov.l 0x0601BA44,r1
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 0601BA30 mov.l @(r0,r1),r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601BA36u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601BA36u) return; }  // 0601BA32 jsr @r0 ; mov r15,r14
    c.r[15] = c.r[14];  // 0601BA36 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601BA38 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601BA3A mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[0] & 0xFFFFu; c.pc = x; return; }  // 0601BA3C rts ; extu.w r0,r0
}

void f_0601BA48(SH2Context& c) {
    ran[272] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601BA48 mov.l r14,@-r15
    c.r[1] = ld32(0x0601BA90u);  // 0601BA4A mov.l 0x0601BA90,r1
    c.r[1] = ld32(c.r[1]);  // 0601BA4C mov.l @r1,r1
    c.r[14] = c.r[15];  // 0601BA4E mov r15,r14
    c.r[1] += 1;  // 0601BA50 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601BA52 mov.b @r1,r1
    c.r[3] = c.r[1] & 0xFFu;  // 0601BA54 extu.b r1,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601BA8Eu);  // 0601BA56 mov.w 0x0601BA8E,r1
    c.r[1] &= c.r[3];  // 0601BA58 and r3,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601BA5A tst r1,r1
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_0601BA80; } }  // 0601BA5C bt/s 0x0601BA80 ; mov #0,r0
    c.r[1] = 0x40u;  // 0601BA60 mov #64,r1
    c.r[1] &= c.r[3];  // 0601BA62 and r3,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601BA64 tst r1,r1
    if (c.t) { goto L_0601BA74; }  // 0601BA66 bt 0x0601BA74
    c.r[1] = ld32(0x0601BA94u);  // 0601BA68 mov.l 0x0601BA94,r1
    c.r[1] = ld32(c.r[1]);  // 0601BA6A mov.l @r1,r1
    c.r[1] += 4;  // 0601BA6C add #4,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0601BA6E mov.w @r1,r1
    c.r[1] = ~c.r[1]; goto L_0601BAA0;  // 0601BA70 bra 0x0601BAA0 ; not r1,r1
L_0601BA74:
    c.r[1] = ld32(0x0601BA94u);  // 0601BA74 mov.l 0x0601BA94,r1
    c.r[1] = ld32(c.r[1]);  // 0601BA76 mov.l @r1,r1
    c.r[1] += 2;  // 0601BA78 add #2,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0601BA7A mov.w @r1,r1
    c.r[1] = ~c.r[1]; goto L_0601BAA0;  // 0601BA7C bra 0x0601BAA0 ; not r1,r1
L_0601BA80:
    c.r[1] = 0x40u;  // 0601BA80 mov #64,r1
    c.r[1] &= c.r[3];  // 0601BA82 and r3,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601BA84 tst r1,r1
    if (c.t) { goto L_0601BA9C; }  // 0601BA86 bt 0x0601BA9C
    c.r[1] = ld32(0x0601BA98u);  // 0601BA88 mov.l 0x0601BA98,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]); goto L_0601BAA0;  // 0601BA8A bra 0x0601BAA0 ; mov.w @r1,r1
L_0601BA9C:
    c.r[1] = ld32(0x0601BBA0u);  // 0601BA9C mov.l 0x0601BBA0,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0601BA9E mov.w @r1,r1
L_0601BAA0:
    c.r[2] = c.r[1] & 0xFFFFu;  // 0601BAA0 extu.w r1,r2
    c.r[1] = 0x20u;  // 0601BAA2 mov #32,r1
    c.r[1] &= c.r[3];  // 0601BAA4 and r3,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601BAA6 tst r1,r1
    { const bool k = c.t; c.r[1] = 0x10u; if (k) { goto L_0601BAC0; } }  // 0601BAA8 bt/s 0x0601BAC0 ; mov #16,r1
    c.r[1] = c.r[2];  // 0601BAAC mov r2,r1
    c.r[1] >>= 8;  // 0601BAAE shlr8 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0601BAB0 shlr r1
    c.r[1] >>= 2;  // 0601BAB2 shlr2 r1
    c.r[7] = 0x1u;  // 0601BAB4 mov #1,r7
    c.r[1] &= c.r[7];  // 0601BAB6 and r7,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601BAB8 tst r1,r1
    if (!c.t) { goto L_0601BB8E; }  // 0601BABA bf 0x0601BB8E
    c.r[0] += 1;  // 0601BABC add #1,r0
    c.r[1] = 0x10u;  // 0601BABE mov #16,r1
L_0601BAC0:
    c.r[1] &= c.r[3];  // 0601BAC0 and r3,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601BAC2 tst r1,r1
    { const bool k = c.t; c.r[1] = 0x8u; if (k) { goto L_0601BAF8; } }  // 0601BAC4 bt/s 0x0601BAF8 ; mov #8,r1
    c.r[1] = c.r[2];  // 0601BAC8 mov r2,r1
    c.r[1] >>= 8;  // 0601BACA shlr8 r1
    c.r[1] >>= 2;  // 0601BACC shlr2 r1
    c.r[7] = 0x1u;  // 0601BACE mov #1,r7
    c.r[1] &= c.r[7];  // 0601BAD0 and r7,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601BAD2 tst r1,r1
    { const bool k = !c.t; c.r[1] = c.r[2]; if (k) { goto L_0601BB8E; } }  // 0601BAD4 bf/s 0x0601BB8E ; mov r2,r1
    c.r[1] >>= 8;  // 0601BAD8 shlr8 r1
    c.r[7] = 0x1u;  // 0601BADA mov #1,r7
    c.r[1] &= c.r[7];  // 0601BADC and r7,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601BADE tst r1,r1
    { const bool k = !c.t; c.r[0] += 1; if (k) { goto L_0601BB8E; } }  // 0601BAE0 bf/s 0x0601BB8E ; add #1,r0
    c.r[1] = c.r[2];  // 0601BAE4 mov r2,r1
    c.r[1] >>= 8;  // 0601BAE6 shlr8 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0601BAE8 shlr r1
    c.r[7] = 0x1u;  // 0601BAEA mov #1,r7
    c.r[1] &= c.r[7];  // 0601BAEC and r7,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601BAEE tst r1,r1
    { const bool k = !c.t; c.r[0] += 1; if (k) { goto L_0601BB8E; } }  // 0601BAF0 bf/s 0x0601BB8E ; add #1,r0
    c.r[0] += 1;  // 0601BAF4 add #1,r0
    c.r[1] = 0x8u;  // 0601BAF6 mov #8,r1
L_0601BAF8:
    c.r[1] &= c.r[3];  // 0601BAF8 and r3,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601BAFA tst r1,r1
    { const bool k = c.t; c.r[1] = 0x4u; if (k) { goto L_0601BB20; } }  // 0601BAFC bt/s 0x0601BB20 ; mov #4,r1
    c.r[1] = 0x40u;  // 0601BB00 mov #64,r1
    c.r[1] &= c.r[2];  // 0601BB02 and r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601BB04 tst r1,r1
    { const bool k = !c.t; c.r[1] = 0x20u; if (k) { goto L_0601BB8E; } }  // 0601BB06 bf/s 0x0601BB8E ; mov #32,r1
    c.r[1] &= c.r[2];  // 0601BB0A and r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601BB0C tst r1,r1
    { const bool k = !c.t; c.r[0] += 1; if (k) { goto L_0601BB8E; } }  // 0601BB0E bf/s 0x0601BB8E ; add #1,r0
    c.r[1] = 0x10u;  // 0601BB12 mov #16,r1
    c.r[1] &= c.r[2];  // 0601BB14 and r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601BB16 tst r1,r1
    { const bool k = !c.t; c.r[0] += 1; if (k) { goto L_0601BB8E; } }  // 0601BB18 bf/s 0x0601BB8E ; add #1,r0
    c.r[0] += 1;  // 0601BB1C add #1,r0
    c.r[1] = 0x4u;  // 0601BB1E mov #4,r1
L_0601BB20:
    c.r[1] &= c.r[3];  // 0601BB20 and r3,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601BB22 tst r1,r1
    { const bool k = c.t; c.r[1] = 0x2u; if (k) { goto L_0601BB3E; } }  // 0601BB24 bt/s 0x0601BB3E ; mov #2,r1
    c.r[1] = 0x8u;  // 0601BB28 mov #8,r1
    c.r[1] &= c.r[2];  // 0601BB2A and r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601BB2C tst r1,r1
    if (!c.t) { goto L_0601BB8E; }  // 0601BB2E bf 0x0601BB8E
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601BB9Cu);  // 0601BB30 mov.w 0x0601BB9C,r1
    c.r[1] &= c.r[2];  // 0601BB32 and r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601BB34 tst r1,r1
    { const bool k = !c.t; c.r[0] += 1; if (k) { goto L_0601BB8E; } }  // 0601BB36 bf/s 0x0601BB8E ; add #1,r0
    c.r[0] += 1;  // 0601BB3A add #1,r0
    c.r[1] = 0x2u;  // 0601BB3C mov #2,r1
L_0601BB3E:
    c.r[1] &= c.r[3];  // 0601BB3E and r3,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601BB40 tst r1,r1
    { const bool k = c.t; c.r[7] = 0x1u; if (k) { goto L_0601BB66; } }  // 0601BB42 bt/s 0x0601BB66 ; mov #1,r7
    c.r[1] = c.r[2];  // 0601BB46 mov r2,r1
    c.r[1] >>= 8;  // 0601BB48 shlr8 r1
    c.r[1] <<= 2;  // 0601BB4A shll2 r1
    c.r[1] >>= 8;  // 0601BB4C shlr8 r1
    c.r[1] &= c.r[7];  // 0601BB4E and r7,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601BB50 tst r1,r1
    { const bool k = !c.t; c.r[1] = c.r[2]; if (k) { goto L_0601BB8E; } }  // 0601BB52 bf/s 0x0601BB8E ; mov r2,r1
    c.r[1] >>= 8;  // 0601BB56 shlr8 r1
    c.r[1] += c.r[1];  // 0601BB58 add r1,r1
    c.r[1] >>= 8;  // 0601BB5A shlr8 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601BB5C tst r1,r1
    { const bool k = !c.t; c.r[0] += 1; if (k) { goto L_0601BB8E; } }  // 0601BB5E bf/s 0x0601BB8E ; add #1,r0
    c.r[0] += 1;  // 0601BB62 add #1,r0
    c.r[7] = 0x1u;  // 0601BB64 mov #1,r7
L_0601BB66:
    c.r[3] &= c.r[7];  // 0601BB66 and r7,r3
    c.t = (c.r[3] & c.r[3]) == 0;  // 0601BB68 tst r3,r3
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_0601BB8E; } }  // 0601BB6A bt/s 0x0601BB8E ; mov r2,r1
    c.r[1] >>= 8;  // 0601BB6E shlr8 r1
    c.r[1] >>= 2;  // 0601BB70 shlr2 r1
    c.r[1] >>= 2;  // 0601BB72 shlr2 r1
    c.r[1] &= c.r[7];  // 0601BB74 and r7,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601BB76 tst r1,r1
    { const bool k = !c.t; c.r[2] >>= 8; if (k) { goto L_0601BB8E; } }  // 0601BB78 bf/s 0x0601BB8E ; shlr8 r2
    c.r[2] >>= 2;  // 0601BB7C shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 0601BB7E shlr r2
    c.r[2] >>= 2;  // 0601BB80 shlr2 r2
    c.r[7] = 0x1u;  // 0601BB82 mov #1,r7
    c.r[2] &= c.r[7];  // 0601BB84 and r7,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0601BB86 tst r2,r2
    { const bool k = !c.t; c.r[0] += 1; if (k) { goto L_0601BB8E; } }  // 0601BB88 bf/s 0x0601BB8E ; add #1,r0
    c.r[0] += 1;  // 0601BB8C add #1,r0
L_0601BB8E:
    c.r[0] += c.r[0];  // 0601BB8E add r0,r0
    c.r[0] += 2;  // 0601BB90 add #2,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601BB9Eu);  // 0601BB92 mov.w 0x0601BB9E,r1
    c.r[0] |= c.r[1];  // 0601BB94 or r1,r0
    c.r[15] = c.r[14];  // 0601BB96 mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601BB98 rts ; mov.l @r15+,r14
}

void f_0601BBA4(SH2Context& c) {
    ran[273] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601BBA4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601BBA6 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0601BBA8 mov r15,r14
    c.r[1] = ld32(0x0601BC18u);  // 0601BBAA mov.l 0x0601BC18,r1
    c.r[3] = ld32(0x0601BC1Cu);  // 0601BBAC mov.l 0x0601BC1C,r3
    c.r[2] = c.r[3];  // 0601BBAE mov r3,r2
    c.r[2] += 56;  // 0601BBB0 add #56,r2
    c.r[7] = ld32(c.r[1]);  // 0601BBB2 mov.l @r1,r7
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601BC12u);  // 0601BBB4 mov.w 0x0601BC12,r0
    c.r[7] += 1;  // 0601BBB6 add #1,r7
    st32(c.r[1], c.r[7]);  // 0601BBB8 mov.l r7,@r1
    c.r[1] = 0x0u;  // 0601BBBA mov #0,r1
    st16(c.r[2], c.r[1]);  // 0601BBBC mov.w r1,@r2
    c.r[1] = 0x33u;  // 0601BBBE mov #51,r1
    st8(c.r[0] + c.r[3], c.r[1]);  // 0601BBC0 mov.b r1,@(r0,r3)
    c.r[2] = ld32(0x0601BC20u);  // 0601BBC2 mov.l 0x0601BC20,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0601BBC4 mov.b @r7,r1
    c.r[0] = 0x0u;  // 0601BBC6 mov #0,r0
    st8(c.r[2], c.r[1]);  // 0601BBC8 mov.b r1,@r2
    c.r[2] = 0x63u;  // 0601BBCA mov #99,r2
    c.r[1] = ld32(0x0601BC24u);  // 0601BBCC mov.l 0x0601BC24,r1
L_0601BBCE:
    st8(c.r[0] + c.r[1], c.r[0]);  // 0601BBCE mov.b r0,@(r0,r1)
    c.r[0] += 1;  // 0601BBD0 add #1,r0
    c.t = (int32_t)c.r[0] > (int32_t)c.r[2];  // 0601BBD2 cmp/gt r2,r0
    if (!c.t) { SH2_POLL(c); goto L_0601BBCE; }  // 0601BBD4 bf 0x0601BBCE
    c.r[1] = ld32(0x0601BC18u);  // 0601BBD6 mov.l 0x0601BC18,r1
    c.r[1] = ld32(c.r[1]);  // 0601BBD8 mov.l @r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601BBDA mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0601BBDC extu.b r1,r0
    c.r[0] <<= 2;  // 0601BBDE shll2 r0
    c.r[1] = ld32(0x0601BC28u);  // 0601BBE0 mov.l 0x0601BC28,r1
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 0601BBE2 mov.l @(r0,r1),r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601BBE8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601BBE8u) return; }  // 0601BBE4 jsr @r0 ; nop
    c.r[3] = ld32(0x0601BC1Cu);  // 0601BBE8 mov.l 0x0601BC1C,r3
    c.r[1] = c.r[3];  // 0601BBEA mov r3,r1
    c.r[1] += 32;  // 0601BBEC add #32,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601BBEE mov.b @r1,r1
    c.r[7] = c.r[0];  // 0601BBF0 mov r0,r7
    c.r[0] = c.r[1];  // 0601BBF2 mov r1,r0
    c.r[0] >>= 2;  // 0601BBF4 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0601BBF6 shlr r0
    c.r[0] &= 0x1u;  // 0601BBF8 and #1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601BC14u);  // 0601BBFA mov.w 0x0601BC14,r1
    c.macl = (c.r[0] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 0601BBFC mulu.w r1,r0
    c.r[15] = c.r[14];  // 0601BBFE mov r14,r15
    c.r[2] = c.macl;  // 0601BC00 sts macl,r2
    c.r[2] += c.r[3];  // 0601BC02 add r3,r2
    c.r[2] += 72;  // 0601BC04 add #72,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601BC16u);  // 0601BC06 mov.w 0x0601BC16,r1
    st16(c.r[2], c.r[1]);  // 0601BC08 mov.w r1,@r2
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601BC0A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601BC0C mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[7] & 0xFFFFu; c.pc = x; return; }  // 0601BC0E rts ; extu.w r7,r0
}

void f_0601BC2C(SH2Context& c) {
    ran[274] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601BC2C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601BC2E sts.l pr,@-r15
    c.r[1] = ld32(0x0601BC4Cu);  // 0601BC30 mov.l 0x0601BC4C,r1
    c.r[1] = ld32(c.r[1]);  // 0601BC32 mov.l @r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601BC34 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0601BC36 extu.b r1,r0
    c.r[0] <<= 2;  // 0601BC38 shll2 r0
    c.r[1] = ld32(0x0601BC50u);  // 0601BC3A mov.l 0x0601BC50,r1
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 0601BC3C mov.l @(r0,r1),r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601BC42u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601BC42u) return; }  // 0601BC3E jsr @r0 ; mov r15,r14
    c.r[15] = c.r[14];  // 0601BC42 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601BC44 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601BC46 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[0] & 0xFFFFu; c.pc = x; return; }  // 0601BC48 rts ; extu.w r0,r0
}

void f_0601BC54(SH2Context& c) {
    ran[275] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601BC54 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0601BC56 mov r15,r14
    c.r[6] = 0x0u;  // 0601BC58 mov #0,r6
    c.r[4] = 0x1u;  // 0601BC5A mov #1,r4
    c.r[5] = 0x21u;  // 0601BC5C mov #33,r5
    c.r[3] = ld32(0x0601BCA8u);  // 0601BC5E mov.l 0x0601BCA8,r3
    c.r[7] = ld32(0x0601BCACu);  // 0601BC60 mov.l 0x0601BCAC,r7
L_0601BC62:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0601BC62 mov.b @r7,r0
    c.r[1] = c.r[3];  // 0601BC64 mov r3,r1
    c.r[1] += 65;  // 0601BC66 add #65,r1
    c.r[2] = c.r[3];  // 0601BC68 mov r3,r2
    c.r[2] += 66;  // 0601BC6A add #66,r2
    c.r[6] += 1;  // 0601BC6C add #1,r6
    c.t = (int32_t)c.r[6] > (int32_t)c.r[4];  // 0601BC6E cmp/gt r4,r6
    c.r[0] &= 0x7Fu;  // 0601BC70 and #127,r0
    st8(c.r[7], c.r[0]);  // 0601BC72 mov.b r0,@r7
    st8(c.r[1], c.r[5]);  // 0601BC74 mov.b r5,@r1
    c.r[1] = 0x6u;  // 0601BC76 mov #6,r1
    st8(c.r[2], c.r[1]);  // 0601BC78 mov.b r1,@r2
    c.r[2] = c.r[3];  // 0601BC7A mov r3,r2
    c.r[2] += 67;  // 0601BC7C add #67,r2
    c.r[1] = 0x7u;  // 0601BC7E mov #7,r1
    st8(c.r[2], c.r[1]);  // 0601BC80 mov.b r1,@r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601BCA2u);  // 0601BC82 mov.w 0x0601BCA2,r1
    c.r[3] += c.r[1];  // 0601BC84 add r1,r3
    { const bool k = !c.t; c.r[7] += 1; if (k) { SH2_POLL(c); goto L_0601BC62; } }  // 0601BC86 bf/s 0x0601BC62 ; add #1,r7
    c.r[3] = ld32(0x0601BCA8u);  // 0601BC8A mov.l 0x0601BCA8,r3
    c.r[2] = c.r[3];  // 0601BC8C mov r3,r2
    c.r[2] += 68;  // 0601BC8E add #68,r2
    c.r[1] = 0x14u;  // 0601BC90 mov #20,r1
    st8(c.r[2], c.r[1]);  // 0601BC92 mov.b r1,@r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601BCA4u);  // 0601BC94 mov.w 0x0601BCA4,r0
    c.r[1] = 0x2u;  // 0601BC96 mov #2,r1
    st8(c.r[0] + c.r[3], c.r[1]);  // 0601BC98 mov.b r1,@(r0,r3)
    c.r[15] = c.r[14];  // 0601BC9A mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601BCA6u);  // 0601BC9C mov.w 0x0601BCA6,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601BC9E rts ; mov.l @r15+,r14
}

void f_0601BCB0(SH2Context& c) {
    ran[276] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601BCB0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0601BCB2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601BCB4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601BCB6 sts.l pr,@-r15
    c.r[9] = 0x0u;  // 0601BCB8 mov #0,r9
    c.r[3] = ld32(0x0601BD6Cu);  // 0601BCBA mov.l 0x0601BD6C,r3
    c.r[0] = c.r[3];  // 0601BCBC mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 0601BCBE mov.b @(r0,r9),r1
    c.r[2] = 0x1u;  // 0601BCC0 mov #1,r2
    c.r[1] >>= 2;  // 0601BCC2 shlr2 r1
    c.r[1] >>= 2;  // 0601BCC4 shlr2 r1
    c.r[1] >>= 2;  // 0601BCC6 shlr2 r1
    c.r[1] &= c.r[2];  // 0601BCC8 and r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601BCCA tst r1,r1
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0601BCFE; } }  // 0601BCCC bf/s 0x0601BCFE ; mov r15,r14
    c.r[9] = c.r[2];  // 0601BCD0 mov r2,r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 0601BCD2 mov.b @(r0,r9),r1
    c.r[1] >>= 2;  // 0601BCD4 shlr2 r1
    c.r[1] >>= 2;  // 0601BCD6 shlr2 r1
    c.r[1] >>= 2;  // 0601BCD8 shlr2 r1
    c.r[1] &= c.r[2];  // 0601BCDA and r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601BCDC tst r1,r1
    { const bool k = !c.t; c.r[5] = 0x1u; if (k) { goto L_0601BD00; } }  // 0601BCDE bf/s 0x0601BD00 ; mov #1,r5
    c.r[9] += 1;  // 0601BCE2 add #1,r9
L_0601BCE4:
    c.t = (int32_t)c.r[9] > (int32_t)c.r[2];  // 0601BCE4 cmp/gt r2,r9
    { const bool k = c.t; c.r[0] = c.r[3]; if (k) { goto L_0601BCFE; } }  // 0601BCE6 bt/s 0x0601BCFE ; mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 0601BCEA mov.b @(r0,r9),r1
    c.r[1] >>= 2;  // 0601BCEC shlr2 r1
    c.r[1] >>= 2;  // 0601BCEE shlr2 r1
    c.r[1] >>= 2;  // 0601BCF0 shlr2 r1
    c.r[0] = 0x1u;  // 0601BCF2 mov #1,r0
    c.r[1] &= c.r[0];  // 0601BCF4 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601BCF6 tst r1,r1
    { const bool k = c.t; c.r[9] += 1; if (k) { SH2_POLL(c); goto L_0601BCE4; } }  // 0601BCF8 bt/s 0x0601BCE4 ; add #1,r9
    c.r[9] -= 1;  // 0601BCFC add #-1,r9
L_0601BCFE:
    c.r[5] = 0x1u;  // 0601BCFE mov #1,r5
L_0601BD00:
    c.t = (int32_t)c.r[9] > (int32_t)c.r[5];  // 0601BD00 cmp/gt r5,r9
    { const bool k = c.t; c.t = (c.r[9] & c.r[9]) == 0; if (k) { goto L_0601BD56; } }  // 0601BD02 bt/s 0x0601BD56 ; tst r9,r9
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601BD64u);  // 0601BD06 mov.w 0x0601BD64,r1
    c.macl = c.r[9] * c.r[1];  // 0601BD08 mul.l r1,r9
    c.r[2] = ld32(0x0601BD70u);  // 0601BD0A mov.l 0x0601BD70,r2
    c.r[3] = c.macl;  // 0601BD0C sts macl,r3
    c.r[3] += c.r[2];  // 0601BD0E add r2,r3
    c.r[2] = (uint32_t)(int16_t)ld16(0x0601BD66u);  // 0601BD10 mov.w 0x0601BD66,r2
    c.r[0] = c.r[3];  // 0601BD12 mov r3,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 0601BD14 mov.w @(r0,r2),r1
    c.r[6] = 0x14u;  // 0601BD16 mov #20,r6
    c.r[1] -= 1;  // 0601BD18 add #-1,r1
    { const bool k = c.t; st16(c.r[0] + c.r[2], c.r[1]); if (k) { goto L_0601BD20; } }  // 0601BD1A bt/s 0x0601BD20 ; mov.w r1,@(r0,r2)
    c.r[6] = 0x2u;  // 0601BD1E mov #2,r6
L_0601BD20:
    c.r[2] = c.r[9] & 0xFFu;  // 0601BD20 extu.b r9,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601BD68u);  // 0601BD22 mov.w 0x0601BD68,r0
    c.r[2] |= c.r[0];  // 0601BD24 or r0,r2
    c.r[8] = ld32(0x0601BD6Cu);  // 0601BD26 mov.l 0x0601BD6C,r8
    c.r[0] = c.r[8];  // 0601BD28 mov r8,r0
    c.r[7] = ld32(0x0601BD74u);  // 0601BD2A mov.l 0x0601BD74,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 0601BD2C mov.b @(r0,r9),r1
    c.r[4] = c.r[2];  // 0601BD2E mov r2,r4
    c.r[1] >>= 2;  // 0601BD30 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0601BD32 shlr r1
    c.r[0] = 0x3u;  // 0601BD34 mov #3,r0
    c.r[1] &= c.r[0];  // 0601BD36 and r0,r1
    c.r[0] = ld32(0x0601BD78u);  // 0601BD38 mov.l 0x0601BD78,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601BD3Eu; c.r[15] -= 4; st32(c.r[15], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601BD3Eu) return; }  // 0601BD3A jsr @r0 ; mov.l r1,@-r15
    c.r[0] = c.r[8];  // 0601BD3E mov r8,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 0601BD40 mov.b @(r0,r9),r1
    c.r[1] >>= 2;  // 0601BD42 shlr2 r1
    c.r[0] = 0x1u;  // 0601BD44 mov #1,r0
    c.r[1] &= c.r[0];  // 0601BD46 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601BD48 tst r1,r1
    { const bool k = c.t; c.r[15] += 4; if (k) { goto L_0601BD56; } }  // 0601BD4A bt/s 0x0601BD56 ; add #4,r15
    c.r[9] += 4;  // 0601BD4E add #4,r9
    c.r[1] = ld32(0x0601BD7Cu);  // 0601BD50 mov.l 0x0601BD7C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601BD56u; c.r[4] = c.r[9] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601BD56u) return; }  // 0601BD52 jsr @r1 ; extu.b r9,r4
L_0601BD56:
    c.r[15] = c.r[14];  // 0601BD56 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601BD58 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601BD5A mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0601BD5C mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601BD6Au);  // 0601BD5E mov.w 0x0601BD6A,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601BD60 rts ; mov.l @r15+,r8
}

void f_0601BD80(SH2Context& c) {
    ran[277] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601BD80 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601BD82 sts.l pr,@-r15
    c.r[1] = ld32(0x0601BDA0u);  // 0601BD84 mov.l 0x0601BDA0,r1
    c.r[1] = ld32(c.r[1]);  // 0601BD86 mov.l @r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601BD88 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0601BD8A extu.b r1,r0
    c.r[0] <<= 2;  // 0601BD8C shll2 r0
    c.r[1] = ld32(0x0601BDA4u);  // 0601BD8E mov.l 0x0601BDA4,r1
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 0601BD90 mov.l @(r0,r1),r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601BD96u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601BD96u) return; }  // 0601BD92 jsr @r0 ; mov r15,r14
    c.r[15] = c.r[14];  // 0601BD96 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601BD98 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601BD9A mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[0] & 0xFFFFu; c.pc = x; return; }  // 0601BD9C rts ; extu.w r0,r0
}

void f_0601BDA8(SH2Context& c) {
    ran[278] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601BDA8 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0601BDAA mov r15,r14
    c.r[1] = ld32(0x0601BDBCu);  // 0601BDAC mov.l 0x0601BDBC,r1
    c.r[2] = ld32(0x0601BDC0u);  // 0601BDAE mov.l 0x0601BDC0,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601BDB0 mov.b @r2,r2
    st8(c.r[1], c.r[2]);  // 0601BDB2 mov.b r2,@r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601BDBAu);  // 0601BDB4 mov.w 0x0601BDBA,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601BDB6 rts ; mov.l @r15+,r14
}

void f_0601BDC4(SH2Context& c) {
    ran[279] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601BDC4 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0601BDC6 mov r15,r14
    c.r[1] = ld32(0x0601BDD8u);  // 0601BDC8 mov.l 0x0601BDD8,r1
    c.r[2] = ld32(0x0601BDDCu);  // 0601BDCA mov.l 0x0601BDDC,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601BDCC mov.b @r2,r2
    st8(c.r[1], c.r[2]);  // 0601BDCE mov.b r2,@r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601BDD6u);  // 0601BDD0 mov.w 0x0601BDD6,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601BDD2 rts ; mov.l @r15+,r14
}

void f_0601BDE0(SH2Context& c) {
    ran[280] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601BDE0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0601BDE2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0601BDE4 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0601BDE6 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0601BDE8 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601BDEA mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601BDEC sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0601BDEE mov r15,r14
    c.r[10] = ld32(0x0601BE38u);  // 0601BDF0 mov.l 0x0601BE38,r10
    c.r[12] = ld32(0x0601BE3Cu);  // 0601BDF2 mov.l 0x0601BE3C,r12
    c.r[11] = ld32(0x0601BE40u);  // 0601BDF4 mov.l 0x0601BE40,r11
    c.r[9] = c.r[10];  // 0601BDF6 mov r10,r9
    c.r[8] = 0x0u;  // 0601BDF8 mov #0,r8
L_0601BDFA:
    c.r[1] = c.r[9];  // 0601BDFA mov r9,r1
    c.r[1] += 2;  // 0601BDFC add #2,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0601BDFE mov.w @r1,r1
    c.r[4] = c.r[1] & 0xFFFFu;  // 0601BE00 extu.w r1,r4
    c.r[1] = ld32(0x0601BE44u);  // 0601BE02 mov.l 0x0601BE44,r1
    c.t = c.r[4] == c.r[1];  // 0601BE04 cmp/eq r1,r4
    if (c.t) { goto L_0601BE20; }  // 0601BE06 bt 0x0601BE20
    { const uint32_t x = c.r[12]; c.pr = 0x0601BE0Cu; c.r[5] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601BE0Cu) return; }  // 0601BE08 jsr @r12 ; mov #1,r5
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601BE0C tst r0,r0
    { const bool k = c.t; c.r[0] = c.r[8]; if (k) { goto L_0601BE1A; } }  // 0601BE0E bt/s 0x0601BE1A ; mov r8,r0
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[10]);  // 0601BE12 mov.w @(r0,r10),r4
    c.r[5] = 0x1u;  // 0601BE14 mov #1,r5
    { const uint32_t x = c.r[11]; c.pr = 0x0601BE1Au; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601BE1Au) return; }  // 0601BE16 jsr @r11 ; extu.w r4,r4
L_0601BE1A:
    c.r[9] += 4;  // 0601BE1A add #4,r9
    c.r[8] += 4; SH2_POLL(c); goto L_0601BDFA;  // 0601BE1C bra 0x0601BDFA ; add #4,r8
L_0601BE20:
    c.r[15] = c.r[14];  // 0601BE20 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601BE22 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601BE24 mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0601BE26 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0601BE28 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0601BE2A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0601BE2C mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601BE34u);  // 0601BE2E mov.w 0x0601BE34,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601BE30 rts ; mov.l @r15+,r8
}

void f_0601BE48(SH2Context& c) {
    ran[281] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601BE48 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601BE4A sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0601BE4C mov r15,r14
    c.r[1] = ld32(0x0601BE68u);  // 0601BE4E mov.l 0x0601BE68,r1
    c.r[1] = ld32(c.r[1]);  // 0601BE50 mov.l @r1,r1
    c.r[0] = ld32(0x0601BE6Cu);  // 0601BE52 mov.l 0x0601BE6C,r0
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601BE54 mov.b @r1,r4
    c.r[5] = 0x1u;  // 0601BE56 mov #1,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0601BE5Cu; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601BE5Cu) return; }  // 0601BE58 jsr @r0 ; extu.b r4,r4
    c.r[15] = c.r[14];  // 0601BE5C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601BE5E lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601BE66u);  // 0601BE60 mov.w 0x0601BE66,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601BE62 rts ; mov.l @r15+,r14
}

void f_0601BE70(SH2Context& c) {
    ran[282] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601BE70 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601BE72 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601BE74 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0601BE76 mov r15,r14
    c.r[8] = ld32(0x0601BE98u);  // 0601BE78 mov.l 0x0601BE98,r8
    c.r[1] = ld32(c.r[8]);  // 0601BE7A mov.l @r8,r1
    c.r[0] = ld32(0x0601BE9Cu);  // 0601BE7C mov.l 0x0601BE9C,r0
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601BE7E mov.b @r1,r5
    c.r[4] = 0x2u;  // 0601BE80 mov #2,r4
    { const uint32_t x = c.r[0]; c.pr = 0x0601BE86u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601BE86u) return; }  // 0601BE82 jsr @r0 ; extu.b r5,r5
    st32(c.r[8], c.r[0]);  // 0601BE86 mov.l r0,@r8
    c.r[15] = c.r[14];  // 0601BE88 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601BE8A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601BE8C mov.l @r15+,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601BE94u);  // 0601BE8E mov.w 0x0601BE94,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601BE90 rts ; mov.l @r15+,r8
}

void f_0601BEA0(SH2Context& c) {
    ran[283] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601BEA0 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0601BEA2 mov r15,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601BEAAu);  // 0601BEA4 mov.w 0x0601BEAA,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601BEA6 rts ; mov.l @r15+,r14
}

void f_0601BEAC(SH2Context& c) {
    ran[284] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601BEAC mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0601BEAE mov r15,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601BEB6u);  // 0601BEB0 mov.w 0x0601BEB6,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601BEB2 rts ; mov.l @r15+,r14
}

void f_0601BEB8(SH2Context& c) {
    ran[285] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601BEB8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601BEBA mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601BEBC sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0601BEBE mov r15,r14
    c.r[5] = c.r[5] & 0xFFFFu;  // 0601BEC0 extu.w r5,r5
    c.r[8] = ld32(0x0601BEF4u);  // 0601BEC2 mov.l 0x0601BEF4,r8
    c.r[3] = c.r[8];  // 0601BEC4 mov r8,r3
    c.r[3] += 68;  // 0601BEC6 add #68,r3
    c.r[4] = c.r[4] & 0xFFu;  // 0601BEC8 extu.b r4,r4
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0601BECA mov.b @r3,r2
    c.r[0] = ld32(0x0601BEF8u);  // 0601BECC mov.l 0x0601BEF8,r0
    c.r[1] = c.r[2];  // 0601BECE mov r2,r1
    c.r[1] += 1;  // 0601BED0 add #1,r1
    st8(c.r[3], c.r[1]);  // 0601BED2 mov.b r1,@r3
    c.r[2] = c.r[2] & 0xFFu;  // 0601BED4 extu.b r2,r2
    c.r[2] <<= 2;  // 0601BED6 shll2 r2
    c.r[1] = ld32(c.r[8]);  // 0601BED8 mov.l @r8,r1
    c.r[2] += c.r[8];  // 0601BEDA add r8,r2
    c.r[1] += c.r[5];  // 0601BEDC add r5,r1
    st32(c.r[2] + 4, c.r[1]);  // 0601BEDE mov.l r1,@(4,r2)
    c.r[5] = c.r[4];  // 0601BEE0 mov r4,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0601BEE6u; c.r[4] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601BEE6u) return; }  // 0601BEE2 jsr @r0 ; mov #2,r4
    st32(c.r[8], c.r[0]);  // 0601BEE6 mov.l r0,@r8
    c.r[15] = c.r[14];  // 0601BEE8 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601BEEA lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601BEEC mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0601BEEE mov.l @r15+,r8
    { const uint32_t x = c.pr; c.r[0] = 0x0u; c.pc = x; return; }  // 0601BEF0 rts ; mov #0,r0
}

void f_0601BEFC(SH2Context& c) {
    ran[286] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601BEFC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601BEFE sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0601BF00 mov r15,r14
    c.r[6] = c.r[4];  // 0601BF02 mov r4,r6
    c.r[6] = c.r[6] & 0xFFu;  // 0601BF04 extu.b r6,r6
    c.r[7] = ld32(0x0601BF24u);  // 0601BF06 mov.l 0x0601BF24,r7
    c.r[1] = ld32(0x0601BF28u);  // 0601BF08 mov.l 0x0601BF28,r1
    c.r[1] = ld32(c.r[1]);  // 0601BF0A mov.l @r1,r1
    c.r[0] = ld32(0x0601BF2Cu);  // 0601BF0C mov.l 0x0601BF2C,r0
    c.r[5] = 0x0u;  // 0601BF0E mov #0,r5
    c.r[4] = 0xEu;  // 0601BF10 mov #14,r4
    { const uint32_t x = c.r[0]; c.pr = 0x0601BF16u; c.r[15] -= 4; st32(c.r[15], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601BF16u) return; }  // 0601BF12 jsr @r0 ; mov.l r1,@-r15
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0601BF16 cmp/eq #-1,r0
    if (c.t) { goto L_0601BF1C; }  // 0601BF18 bt 0x0601BF1C
    c.r[0] = 0x0u;  // 0601BF1A mov #0,r0
L_0601BF1C:
    c.r[15] = c.r[14];  // 0601BF1C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601BF1E lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601BF20 rts ; mov.l @r15+,r14
}

void f_0601BF30(SH2Context& c) {
    ran[287] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601BF30 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0601BF32 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601BF34 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601BF36 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0601BF38 mov r15,r14
    c.r[2] = c.r[5];  // 0601BF3A mov r5,r2
    c.r[4] = c.r[4] & 0xFFFFu;  // 0601BF3C extu.w r4,r4
    c.r[2] <<= 2;  // 0601BF3E shll2 r2
    c.r[1] = ld32(0x0601BF74u);  // 0601BF40 mov.l 0x0601BF74,r1
    c.r[0] = c.r[2];  // 0601BF42 mov r2,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0601BF44 mov.w @(r0,r1),r1
    c.r[8] = ld32(0x0601BF78u);  // 0601BF46 mov.l 0x0601BF78,r8
    c.r[4] += c.r[1];  // 0601BF48 add r1,r4
    c.r[1] = c.r[4] & 0xFFFFu;  // 0601BF4A extu.w r4,r1
    c.r[9] = c.r[1];  // 0601BF4C mov r1,r9
    c.r[9] >>= 2;  // 0601BF4E shlr2 r9
    c.t = c.r[9] & 1; c.r[9] >>= 1;  // 0601BF50 shlr r9
    c.r[0] = 0x7u;  // 0601BF52 mov #7,r0
    c.r[1] &= c.r[0];  // 0601BF54 and r0,r1
    c.r[5] = c.r[1];  // 0601BF56 mov r1,r5
    c.r[0] = ld32(0x0601BF7Cu);  // 0601BF58 mov.l 0x0601BF7C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601BF5Eu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601BF5Eu) return; }  // 0601BF5A jsr @r0 ; mov #1,r4
    c.r[2] = c.r[0];  // 0601BF5E mov r0,r2
    c.r[0] = c.r[9];  // 0601BF60 mov r9,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0601BF62 mov.b @(r0,r8),r1
    c.r[15] = c.r[14];  // 0601BF64 mov r14,r15
    c.r[2] |= c.r[1];  // 0601BF66 or r1,r2
    st8(c.r[0] + c.r[8], c.r[2]);  // 0601BF68 mov.b r2,@(r0,r8)
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601BF6A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601BF6C mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0601BF6E mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601BF70 rts ; mov.l @r15+,r8
}

void f_0601BF80(SH2Context& c) {
    ran[288] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601BF80 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601BF82 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601BF84 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0601BF86 mov r15,r14
    c.r[2] = c.r[4];  // 0601BF88 mov r4,r2
    c.r[0] = c.r[5];  // 0601BF8A mov r5,r0
    c.r[0] <<= 2;  // 0601BF8C shll2 r0
    c.r[1] = ld32(0x0601BFBCu);  // 0601BF8E mov.l 0x0601BFBC,r1
    c.r[3] = 0x7u;  // 0601BF90 mov #7,r3
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 0601BF92 mov.l @(r0,r1),r1
    c.r[4] = 0x1u;  // 0601BF94 mov #1,r4
    c.r[2] += c.r[1];  // 0601BF96 add r1,r2
    c.r[0] = c.r[2];  // 0601BF98 mov r2,r0
    c.r[0] >>= 2;  // 0601BF9A shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0601BF9C shlr r0
    c.r[2] &= c.r[3];  // 0601BF9E and r3,r2
    c.r[1] = ld32(0x0601BFC0u);  // 0601BFA0 mov.l 0x0601BFC0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601BFA2 mov.b @(r0,r1),r1
    c.r[5] = c.r[2];  // 0601BFA4 mov r2,r5
    c.r[0] = ld32(0x0601BFC4u);  // 0601BFA6 mov.l 0x0601BFC4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601BFACu; c.r[8] = c.r[1] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601BFACu) return; }  // 0601BFA8 jsr @r0 ; extu.b r1,r8
    c.r[15] = c.r[14];  // 0601BFAC mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601BFAE lds.l @r15+,pr
    c.r[8] &= c.r[0];  // 0601BFB0 and r0,r8
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601BFB2 mov.l @r15+,r14
    c.r[0] = c.r[8];  // 0601BFB4 mov r8,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601BFB6 rts ; mov.l @r15+,r8
}

void f_0601BFC8(SH2Context& c) {
    ran[289] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601BFC8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601BFCA sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0601BFCC mov r15,r14
    c.r[1] = ld32(0x0601C008u);  // 0601BFCE mov.l 0x0601C008,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601BFD4u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601BFD4u) return; }  // 0601BFD0 jsr @r1 ; mov #0,r4
    c.r[7] = ld32(0x0601C00Cu);  // 0601BFD4 mov.l 0x0601C00C,r7
    c.r[1] = ld32(0x0601C010u);  // 0601BFD6 mov.l 0x0601C010,r1
    c.r[0] = ld32(0x0601C014u);  // 0601BFD8 mov.l 0x0601C014,r0
    c.r[5] = 0x4u;  // 0601BFDA mov #4,r5
    c.r[3] = ld32(c.r[1]);  // 0601BFDC mov.l @r1,r3
    c.r[4] = 0x3u;  // 0601BFDE mov #3,r4
    c.r[1] = c.r[3];  // 0601BFE0 mov r3,r1
    c.r[1] += 2;  // 0601BFE2 add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601BFE4 mov.b @r1,r2
    c.r[3] += 3;  // 0601BFE6 add #3,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0601BFE8 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0601BFEA mov.b @r3,r1
    c.r[2] <<= 8;  // 0601BFEC shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0601BFEE extu.b r1,r1
    c.r[2] |= c.r[1];  // 0601BFF0 or r1,r2
    c.r[2] >>= 8;  // 0601BFF2 shlr8 r2
    c.r[2] += c.r[2];  // 0601BFF4 add r2,r2
    c.r[2] >>= 8;  // 0601BFF6 shlr8 r2
    { const uint32_t x = c.r[0]; c.pr = 0x0601BFFCu; st32(c.r[7], c.r[2]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601BFFCu) return; }  // 0601BFF8 jsr @r0 ; mov.l r2,@r7
    c.r[15] = c.r[14];  // 0601BFFC mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601BFFE lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601C006u);  // 0601C000 mov.w 0x0601C006,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601C002 rts ; mov.l @r15+,r14
}

void f_0601C018(SH2Context& c) {
    ran[290] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601C018 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601C01A sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0601C01C mov r15,r14
    c.r[1] = ld32(0x0601C058u);  // 0601C01E mov.l 0x0601C058,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601C024u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601C024u) return; }  // 0601C020 jsr @r1 ; mov #1,r4
    c.r[7] = ld32(0x0601C05Cu);  // 0601C024 mov.l 0x0601C05C,r7
    c.r[1] = ld32(0x0601C060u);  // 0601C026 mov.l 0x0601C060,r1
    c.r[0] = ld32(0x0601C064u);  // 0601C028 mov.l 0x0601C064,r0
    c.r[5] = 0x4u;  // 0601C02A mov #4,r5
    c.r[3] = ld32(c.r[1]);  // 0601C02C mov.l @r1,r3
    c.r[4] = 0x3u;  // 0601C02E mov #3,r4
    c.r[1] = c.r[3];  // 0601C030 mov r3,r1
    c.r[1] += 2;  // 0601C032 add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601C034 mov.b @r1,r2
    c.r[3] += 3;  // 0601C036 add #3,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0601C038 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0601C03A mov.b @r3,r1
    c.r[2] <<= 8;  // 0601C03C shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0601C03E extu.b r1,r1
    c.r[2] |= c.r[1];  // 0601C040 or r1,r2
    c.r[2] >>= 8;  // 0601C042 shlr8 r2
    c.r[2] += c.r[2];  // 0601C044 add r2,r2
    c.r[2] >>= 8;  // 0601C046 shlr8 r2
    { const uint32_t x = c.r[0]; c.pr = 0x0601C04Cu; st32(c.r[7], c.r[2]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601C04Cu) return; }  // 0601C048 jsr @r0 ; mov.l r2,@r7
    c.r[15] = c.r[14];  // 0601C04C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601C04E lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601C056u);  // 0601C050 mov.w 0x0601C056,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601C052 rts ; mov.l @r15+,r14
}

void f_0601C068(SH2Context& c) {
    ran[291] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601C068 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0601C06A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601C06C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601C06E sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0601C070 mov r15,r14
    c.r[1] = ld32(0x0601C0F8u);  // 0601C072 mov.l 0x0601C0F8,r1
    c.r[2] = ld32(c.r[1]);  // 0601C074 mov.l @r1,r2
    c.r[4] = 0x0u;  // 0601C076 mov #0,r4
    c.r[1] = c.r[2];  // 0601C078 mov r2,r1
    c.r[1] += 2;  // 0601C07A add #2,r1
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601C07C mov.b @r1,r8
    c.r[2] += 3;  // 0601C07E add #3,r2
    c.r[8] = c.r[8] & 0xFFu;  // 0601C080 extu.b r8,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601C082 mov.b @r2,r1
    c.r[8] <<= 8;  // 0601C084 shll8 r8
    c.r[1] = c.r[1] & 0xFFu;  // 0601C086 extu.b r1,r1
    c.r[8] |= c.r[1];  // 0601C088 or r1,r8
    c.r[1] = ld32(0x0601C0FCu);  // 0601C08A mov.l 0x0601C0FC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601C090u; c.r[9] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601C090u) return; }  // 0601C08C jsr @r1 ; mov r8,r9
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601C0F2u);  // 0601C090 mov.w 0x0601C0F2,r1
    c.r[8] &= c.r[1];  // 0601C092 and r1,r8
    c.r[1] = c.r[1] & 0xFFFFu;  // 0601C094 extu.w r1,r1
    c.t = c.r[8] == c.r[1];  // 0601C096 cmp/eq r1,r8
    if (!c.t) { goto L_0601C0BC; }  // 0601C098 bf 0x0601C0BC
    c.r[1] = ld32(0x0601C100u);  // 0601C09A mov.l 0x0601C100,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601C0A0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601C0A0u) return; }  // 0601C09C jsr @r1 ; nop
    c.r[2] = ld32(0x0601C104u);  // 0601C0A0 mov.l 0x0601C104,r2
    c.r[1] = 0x1u;  // 0601C0A2 mov #1,r1
    st32(c.r[2], c.r[1]);  // 0601C0A4 mov.l r1,@r2
    c.r[1] = ld32(0x0601C108u);  // 0601C0A6 mov.l 0x0601C108,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601C0A8 mov.b @r1,r4
    c.r[0] = ld32(0x0601C10Cu);  // 0601C0AA mov.l 0x0601C10C,r0
    c.r[5] = 0x4u;  // 0601C0AC mov #4,r5
    c.r[4] = c.r[4] & 0xFFu;  // 0601C0AE extu.b r4,r4
    c.r[4] >>= 2;  // 0601C0B0 shlr2 r4
    c.r[4] >>= 2;  // 0601C0B2 shlr2 r4
    c.t = c.r[4] & 1; c.r[4] >>= 1;  // 0601C0B4 shlr r4
    c.r[4] >>= 2;  // 0601C0B6 shlr2 r4
    c.r[4] += 5; goto L_0601C0E0;  // 0601C0B8 bra 0x0601C0E0 ; add #5,r4
L_0601C0BC:
    c.r[1] = ld32(0x0601C110u);  // 0601C0BC mov.l 0x0601C110,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601C0C2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601C0C2u) return; }  // 0601C0BE jsr @r1 ; nop
    c.r[1] = ld32(0x0601C104u);  // 0601C0C2 mov.l 0x0601C104,r1
    c.r[9] >>= 8;  // 0601C0C4 shlr8 r9
    c.r[9] += c.r[9];  // 0601C0C6 add r9,r9
    c.r[9] >>= 8;  // 0601C0C8 shlr8 r9
    st32(c.r[1], c.r[9]);  // 0601C0CA mov.l r9,@r1
    c.r[1] = ld32(0x0601C108u);  // 0601C0CC mov.l 0x0601C108,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601C0CE mov.b @r1,r4
    c.r[0] = ld32(0x0601C10Cu);  // 0601C0D0 mov.l 0x0601C10C,r0
    c.r[5] = 0x4u;  // 0601C0D2 mov #4,r5
    c.r[4] = c.r[4] & 0xFFu;  // 0601C0D4 extu.b r4,r4
    c.r[4] >>= 2;  // 0601C0D6 shlr2 r4
    c.r[4] >>= 2;  // 0601C0D8 shlr2 r4
    c.t = c.r[4] & 1; c.r[4] >>= 1;  // 0601C0DA shlr r4
    c.r[4] >>= 2;  // 0601C0DC shlr2 r4
    c.r[4] += 1;  // 0601C0DE add #1,r4
L_0601C0E0:
    { const uint32_t x = c.r[0]; c.pr = 0x0601C0E4u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601C0E4u) return; }  // 0601C0E0 jsr @r0 ; extu.w r4,r4
    c.r[15] = c.r[14];  // 0601C0E4 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601C0E6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601C0E8 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0601C0EA mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601C0F4u);  // 0601C0EC mov.w 0x0601C0F4,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601C0EE rts ; mov.l @r15+,r8
}

void f_0601C114(SH2Context& c) {
    ran[292] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601C114 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601C116 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0601C118 mov r15,r14
    c.r[1] = ld32(0x0601C150u);  // 0601C11A mov.l 0x0601C150,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601C120u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601C120u) return; }  // 0601C11C jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x0601C154u);  // 0601C120 mov.l 0x0601C154,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601C126u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601C126u) return; }  // 0601C122 jsr @r1 ; nop
    c.r[2] = ld32(0x0601C158u);  // 0601C126 mov.l 0x0601C158,r2
    c.r[1] = 0x0u;  // 0601C128 mov #0,r1
    st32(c.r[2], c.r[1]);  // 0601C12A mov.l r1,@r2
    c.r[1] = ld32(0x0601C15Cu);  // 0601C12C mov.l 0x0601C15C,r1
    c.r[0] = ld32(0x0601C160u);  // 0601C12E mov.l 0x0601C160,r0
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601C130 mov.b @r1,r4
    c.r[5] = 0x4u;  // 0601C132 mov #4,r5
    c.r[4] = c.r[4] & 0xFFu;  // 0601C134 extu.b r4,r4
    c.r[4] >>= 2;  // 0601C136 shlr2 r4
    c.r[4] >>= 2;  // 0601C138 shlr2 r4
    c.t = c.r[4] & 1; c.r[4] >>= 1;  // 0601C13A shlr r4
    c.r[4] >>= 2;  // 0601C13C shlr2 r4
    c.r[4] += 1;  // 0601C13E add #1,r4
    { const uint32_t x = c.r[0]; c.pr = 0x0601C144u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601C144u) return; }  // 0601C140 jsr @r0 ; extu.w r4,r4
    c.r[15] = c.r[14];  // 0601C144 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601C146 lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601C14Eu);  // 0601C148 mov.w 0x0601C14E,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601C14A rts ; mov.l @r15+,r14
}

void f_0601C164(SH2Context& c) {
    ran[293] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601C164 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601C166 sts.l pr,@-r15
    c.r[1] = ld32(0x0601C194u);  // 0601C168 mov.l 0x0601C194,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601C16Eu; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601C16Eu) return; }  // 0601C16A jsr @r1 ; mov r15,r14
    c.r[1] = ld32(0x0601C198u);  // 0601C16E mov.l 0x0601C198,r1
    c.r[0] = ld32(0x0601C19Cu);  // 0601C170 mov.l 0x0601C19C,r0
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601C172 mov.b @r1,r4
    c.r[5] = 0x0u;  // 0601C174 mov #0,r5
    c.r[4] = c.r[4] & 0xFFu;  // 0601C176 extu.b r4,r4
    c.r[4] >>= 2;  // 0601C178 shlr2 r4
    c.r[4] >>= 2;  // 0601C17A shlr2 r4
    c.t = c.r[4] & 1; c.r[4] >>= 1;  // 0601C17C shlr r4
    c.r[4] >>= 2;  // 0601C17E shlr2 r4
    c.r[4] += 1;  // 0601C180 add #1,r4
    { const uint32_t x = c.r[0]; c.pr = 0x0601C186u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601C186u) return; }  // 0601C182 jsr @r0 ; extu.w r4,r4
    c.r[15] = c.r[14];  // 0601C186 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601C188 lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601C190u);  // 0601C18A mov.w 0x0601C190,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601C18C rts ; mov.l @r15+,r14
}

void f_0601C1A0(SH2Context& c) {
    ran[294] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601C1A0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0601C1A2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0601C1A4 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601C1A6 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601C1A8 sts.l pr,@-r15
    c.r[7] = ld32(0x0601C21Cu);  // 0601C1AA mov.l 0x0601C21C,r7
    c.r[3] = ld32(c.r[7]);  // 0601C1AC mov.l @r7,r3
    c.r[14] = c.r[15];  // 0601C1AE mov r15,r14
    c.r[2] = c.r[3];  // 0601C1B0 mov r3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]); c.r[2] += 1;  // 0601C1B2 mov.b @r2+,r1
    c.r[6] = ld32(0x0601C220u);  // 0601C1B4 mov.l 0x0601C220,r6
    c.r[1] = c.r[1] & 0xFFu;  // 0601C1B6 extu.b r1,r1
    st32(c.r[6], c.r[1]);  // 0601C1B8 mov.l r1,@r6
    st32(c.r[7], c.r[2]);  // 0601C1BA mov.l r2,@r7
    c.r[1] = c.r[3];  // 0601C1BC mov r3,r1
    c.r[1] += 5;  // 0601C1BE add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601C1C0 mov.b @r1,r1
    c.r[3] += 6;  // 0601C1C2 add #6,r3
    c.r[8] = c.r[1] & 0xFFu;  // 0601C1C4 extu.b r1,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0601C1C6 mov.b @r3,r1
    c.r[9] = c.r[1] & 0xFFu;  // 0601C1C8 extu.b r1,r9
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601C216u);  // 0601C1CA mov.w 0x0601C216,r1
    c.r[1] &= c.r[8];  // 0601C1CC and r8,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601C1CE tst r1,r1
    { const bool k = c.t; c.r[4] = 0x0u; if (k) { goto L_0601C1DA; } }  // 0601C1D0 bt/s 0x0601C1DA ; mov #0,r4
    c.r[10] = 0x7Fu;  // 0601C1D4 mov #127,r10
    c.r[8] &= c.r[10];  // 0601C1D6 and r10,r8
    c.r[4] = 0x1u;  // 0601C1D8 mov #1,r4
L_0601C1DA:
    c.r[1] = ld32(0x0601C224u);  // 0601C1DA mov.l 0x0601C224,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601C1E0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601C1E0u) return; }  // 0601C1DC jsr @r1 ; nop
    c.r[1] = ld32(0x0601C228u);  // 0601C1E0 mov.l 0x0601C228,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601C1E6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601C1E6u) return; }  // 0601C1E2 jsr @r1 ; nop
    c.r[1] = ld32(0x0601C22Cu);  // 0601C1E6 mov.l 0x0601C22C,r1
    c.r[5] = c.r[9];  // 0601C1E8 mov r9,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0601C1EEu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601C1EEu) return; }  // 0601C1EA jsr @r1 ; mov r8,r4
    c.r[1] = ld32(0x0601C230u);  // 0601C1EE mov.l 0x0601C230,r1
    c.r[0] = ld32(0x0601C234u);  // 0601C1F0 mov.l 0x0601C234,r0
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601C1F2 mov.b @r1,r4
    c.r[5] = 0x6u;  // 0601C1F4 mov #6,r5
    c.r[4] = c.r[4] & 0xFFu;  // 0601C1F6 extu.b r4,r4
    c.r[4] >>= 2;  // 0601C1F8 shlr2 r4
    c.r[4] >>= 2;  // 0601C1FA shlr2 r4
    c.t = c.r[4] & 1; c.r[4] >>= 1;  // 0601C1FC shlr r4
    c.r[4] >>= 2;  // 0601C1FE shlr2 r4
    c.r[4] += 1;  // 0601C200 add #1,r4
    { const uint32_t x = c.r[0]; c.pr = 0x0601C206u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601C206u) return; }  // 0601C202 jsr @r0 ; extu.w r4,r4
    c.r[15] = c.r[14];  // 0601C206 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601C208 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601C20A mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0601C20C mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0601C20E mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601C218u);  // 0601C210 mov.w 0x0601C218,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601C212 rts ; mov.l @r15+,r8
}

void f_0601C238(SH2Context& c) {
    ran[295] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601C238 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601C23A sts.l pr,@-r15
    c.r[1] = ld32(0x0601C264u);  // 0601C23C mov.l 0x0601C264,r1
    c.r[0] = ld32(c.r[1]);  // 0601C23E mov.l @r1,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0601C240 cmp/eq #-1,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0601C252; } }  // 0601C242 bt/s 0x0601C252 ; mov r15,r14
    c.r[1] = ld32(0x0601C268u);  // 0601C246 mov.l 0x0601C268,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601C24Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601C24Cu) return; }  // 0601C248 jsr @r1 ; nop
    c.r[1] = ld32(0x0601C26Cu);  // 0601C24C mov.l 0x0601C26C,r1
    goto L_0601C254;  // 0601C24E bra 0x0601C254 ; nop
L_0601C252:
    c.r[1] = ld32(0x0601C270u);  // 0601C252 mov.l 0x0601C270,r1
L_0601C254:
    { const uint32_t x = c.r[1]; c.pr = 0x0601C258u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601C258u) return; }  // 0601C254 jsr @r1 ; nop
    c.r[15] = c.r[14];  // 0601C258 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601C25A lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601C262u);  // 0601C25C mov.w 0x0601C262,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601C25E rts ; mov.l @r15+,r14
}

void f_0601C274(SH2Context& c) {
    ran[296] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601C274 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0601C276 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601C278 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601C27A sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0601C27C mov r15,r14
    c.r[1] = ld32(0x0601C2E8u);  // 0601C27E mov.l 0x0601C2E8,r1
    c.r[0] = 0x1u;  // 0601C280 mov #1,r0
    c.r[1] = ld32(c.r[1]);  // 0601C282 mov.l @r1,r1
    c.r[7] = 0x2u;  // 0601C284 mov #2,r7
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0601C286 mov.b @r1+,r2
    c.r[6] = 0x20u;  // 0601C288 mov #32,r6
    c.r[8] = c.r[2] & 0xFFu;  // 0601C28A extu.b r2,r8
    c.r[4] = (uint32_t)(int32_t)(int8_t)c.r[8];  // 0601C28C exts.b r8,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601C28E mov.b @r1,r1
    c.r[5] = c.r[1] & 0xFFu;  // 0601C290 extu.b r1,r5
    c.r[1] = ld32(0x0601C2ECu);  // 0601C292 mov.l 0x0601C2EC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601C298u; c.r[2] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601C298u) return; }  // 0601C294 jsr @r1 ; mov #1,r2
    c.r[9] = c.r[4];  // 0601C298 mov r4,r9
    c.r[9] &= c.r[0];  // 0601C29A and r0,r9
    c.r[3] = c.r[5];  // 0601C29C mov r5,r3
    c.r[3] >>= 2;  // 0601C29E shlr2 r3
    c.r[3] >>= 2;  // 0601C2A0 shlr2 r3
    c.r[3] >>= 2;  // 0601C2A2 shlr2 r3
    c.r[0] = 0x3Fu;  // 0601C2A4 mov #63,r0
    c.r[5] &= c.r[0];  // 0601C2A6 and r0,r5
    c.r[8] &= c.r[0];  // 0601C2A8 and r0,r8
    c.r[15] -= 4; st32(c.r[15], c.r[3]);  // 0601C2AA mov.l r3,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 0601C2AC mov.l r2,@-r15
    c.r[1] = 0x0u;  // 0601C2AE mov #0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0601C2B0 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0601C2B2 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0601C2B4 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 0601C2B6 mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0601C2B8 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0601C2BA mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[3]);  // 0601C2BC mov.l r3,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 0601C2BE mov.l r2,@-r15
    c.r[1] = ld32(0x0601C2F0u);  // 0601C2C0 mov.l 0x0601C2F0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601C2C6u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601C2C6u) return; }  // 0601C2C2 jsr @r1 ; mov r8,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601C2E2u);  // 0601C2C6 mov.w 0x0601C2E2,r1
    c.macl = c.r[9] * c.r[1];  // 0601C2C8 mul.l r1,r9
    c.r[2] = ld32(0x0601C2F4u);  // 0601C2CA mov.l 0x0601C2F4,r2
    c.r[15] = c.r[14];  // 0601C2CC mov r14,r15
    c.r[3] = c.macl;  // 0601C2CE sts macl,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601C2E4u);  // 0601C2D0 mov.w 0x0601C2E4,r1
    c.r[0] = c.r[3];  // 0601C2D2 mov r3,r0
    st16(c.r[0] + c.r[2], c.r[1]);  // 0601C2D4 mov.w r1,@(r0,r2)
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601C2D6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601C2D8 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0601C2DA mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601C2E6u);  // 0601C2DC mov.w 0x0601C2E6,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601C2DE rts ; mov.l @r15+,r8
}

void f_0601C2F8(SH2Context& c) {
    ran[297] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601C2F8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601C2FA sts.l pr,@-r15
    c.r[1] = ld32(0x0601C318u);  // 0601C2FC mov.l 0x0601C318,r1
    c.r[1] = ld32(c.r[1]);  // 0601C2FE mov.l @r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601C300 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0601C302 extu.b r1,r0
    c.r[0] <<= 2;  // 0601C304 shll2 r0
    c.r[1] = ld32(0x0601C31Cu);  // 0601C306 mov.l 0x0601C31C,r1
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 0601C308 mov.l @(r0,r1),r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601C30Eu; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601C30Eu) return; }  // 0601C30A jsr @r0 ; mov r15,r14
    c.r[15] = c.r[14];  // 0601C30E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601C310 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601C312 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[0] & 0xFFFFu; c.pc = x; return; }  // 0601C314 rts ; extu.w r0,r0
}

void f_0601C320(SH2Context& c) {
    ran[298] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601C320 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601C322 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601C324 sts.l pr,@-r15
    c.r[1] = ld32(0x0601C374u);  // 0601C326 mov.l 0x0601C374,r1
    c.r[2] = ld32(c.r[1]);  // 0601C328 mov.l @r1,r2
    c.r[14] = c.r[15];  // 0601C32A mov r15,r14
    c.r[1] = c.r[2];  // 0601C32C mov r2,r1
    c.r[1] += 1;  // 0601C32E add #1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601C330 mov.b @r1,r4
    c.r[0] = ld32(0x0601C378u);  // 0601C332 mov.l 0x0601C378,r0
    c.r[4] = c.r[4] & 0xFFu;  // 0601C334 extu.b r4,r4
    c.r[4] <<= 8;  // 0601C336 shll8 r4
    c.r[1] = c.r[2];  // 0601C338 mov r2,r1
    c.r[1] += 2;  // 0601C33A add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601C33C mov.b @r1,r1
    c.r[2] += 3;  // 0601C33E add #3,r2
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601C340 mov.b @r2,r8
    c.r[1] = c.r[1] & 0xFFu;  // 0601C342 extu.b r1,r1
    c.r[4] |= c.r[1];  // 0601C344 or r1,r4
    { const uint32_t x = c.r[0]; c.pr = 0x0601C34Au; c.r[8] = c.r[8] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601C34Au) return; }  // 0601C346 jsr @r0 ; extu.b r8,r8
    c.r[6] = c.r[0] & 0xFFFFu;  // 0601C34A extu.w r0,r6
    c.r[1] = ld32(0x0601C37Cu);  // 0601C34C mov.l 0x0601C37C,r1
    c.r[7] = c.r[8];  // 0601C34E mov r8,r7
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601C350 mov.b @r1,r5
    c.r[4] = 0x2u;  // 0601C352 mov #2,r4
    c.r[5] = c.r[5] & 0xFFu;  // 0601C354 extu.b r5,r5
    c.r[5] >>= 2;  // 0601C356 shlr2 r5
    c.r[5] >>= 2;  // 0601C358 shlr2 r5
    c.t = c.r[5] & 1; c.r[5] >>= 1;  // 0601C35A shlr r5
    c.r[1] = 0x0u;  // 0601C35C mov #0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0601C35E mov.l r1,@-r15
    c.r[1] = ld32(0x0601C380u);  // 0601C360 mov.l 0x0601C380,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601C366u; c.r[5] >>= 2; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601C366u) return; }  // 0601C362 jsr @r1 ; shlr2 r5
    c.r[15] = c.r[14];  // 0601C366 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601C368 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601C36A mov.l @r15+,r14
    c.r[0] = ld32(0x0601C384u);  // 0601C36C mov.l 0x0601C384,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601C36E rts ; mov.l @r15+,r8
}

void f_0601C388(SH2Context& c) {
    ran[299] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601C388 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0601C38A mov r15,r14
    c.r[1] = ld32(0x0601C3A0u);  // 0601C38C mov.l 0x0601C3A0,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0601C38E mov.w @r1,r2
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601C390 mov.l @r15+,r14
    c.r[2] += c.r[2];  // 0601C392 add r2,r2
    c.r[2] += 1;  // 0601C394 add #1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601C39Eu);  // 0601C396 mov.w 0x0601C39E,r1
    c.r[2] |= c.r[1];  // 0601C398 or r1,r2
    { const uint32_t x = c.pr; c.r[0] = c.r[2] & 0xFFFFu; c.pc = x; return; }  // 0601C39A rts ; extu.w r2,r0
}

void f_0601C3A4(SH2Context& c) {
    ran[300] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601C3A4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0601C3A6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0601C3A8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0601C3AA mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0601C3AC mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601C3AE mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601C3B0 sts.l pr,@-r15
    c.r[15] -= 76;  // 0601C3B2 add #-76,r15
    c.r[1] = ld32(0x0601C500u);  // 0601C3B4 mov.l 0x0601C500,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601C3BAu; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601C3BAu) return; }  // 0601C3B6 jsr @r1 ; mov r15,r14
    c.r[1] = ld32(0x0601C504u);  // 0601C3BA mov.l 0x0601C504,r1
    c.r[3] = ld32(c.r[1]);  // 0601C3BC mov.l @r1,r3
    c.r[1] = c.r[3];  // 0601C3BE mov r3,r1
    c.r[1] += 2;  // 0601C3C0 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601C3C2 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601C3C4 extu.b r1,r1
    c.r[11] = c.r[1];  // 0601C3C6 mov r1,r11
    c.r[11] <<= 8;  // 0601C3C8 shll8 r11
    c.r[1] = c.r[3];  // 0601C3CA mov r3,r1
    c.r[1] += 3;  // 0601C3CC add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601C3CE mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601C3D0 extu.b r1,r1
    c.r[11] |= c.r[1];  // 0601C3D2 or r1,r11
    c.r[1] = c.r[3];  // 0601C3D4 mov r3,r1
    c.r[1] += 1;  // 0601C3D6 add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601C3D8 mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0601C3DA extu.b r2,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601C4ECu);  // 0601C3DC mov.w 0x0601C4EC,r1
    c.r[12] = c.r[1];  // 0601C3DE mov r1,r12
    c.r[12] &= c.r[11];  // 0601C3E0 and r11,r12
    c.r[12] >>= 2;  // 0601C3E2 shlr2 r12
    c.t = c.r[12] & 1; c.r[12] >>= 1;  // 0601C3E4 shlr r12
    c.r[12] >>= 2;  // 0601C3E6 shlr2 r12
    c.r[12] |= c.r[2];  // 0601C3E8 or r2,r12
    c.r[1] = c.r[3];  // 0601C3EA mov r3,r1
    c.r[1] += 4;  // 0601C3EC add #4,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0601C4EEu);  // 0601C3EE mov.w 0x0601C4EE,r2
    c.r[2] &= c.r[11];  // 0601C3F0 and r11,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601C3F2 mov.b @r1,r1
    c.r[2] >>= 2;  // 0601C3F4 shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 0601C3F6 shlr r2
    c.r[1] = c.r[1] & 0xFFu;  // 0601C3F8 extu.b r1,r1
    c.r[2] += c.r[1];  // 0601C3FA add r1,r2
    c.r[8] = c.r[2] & 0xFFFFu;  // 0601C3FC extu.w r2,r8
    c.r[0] = c.r[8];  // 0601C3FE mov r8,r0
    c.r[0] >>= 8;  // 0601C400 shlr8 r0
    c.r[0] &= 0x1u;  // 0601C402 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601C404 tst r0,r0
    { const bool k = c.t; c.r[9] = 0x0u; if (k) { goto L_0601C418; } }  // 0601C406 bt/s 0x0601C418 ; mov #0,r9
    c.r[2] = ~c.r[8];  // 0601C40A not r8,r2
    c.r[2] = c.r[2] & 0xFFFFu;  // 0601C40C extu.w r2,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601C4F0u);  // 0601C40E mov.w 0x0601C4F0,r1
    c.r[2] &= c.r[1];  // 0601C410 and r1,r2
    c.r[2] += 1;  // 0601C412 add #1,r2
    c.r[8] = c.r[2] & 0xFFFFu;  // 0601C414 extu.w r2,r8
    c.r[9] = 0x1u;  // 0601C416 mov #1,r9
L_0601C418:
    c.r[1] = c.r[3];  // 0601C418 mov r3,r1
    c.r[1] += 5;  // 0601C41A add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601C41C mov.b @r1,r1
    c.r[3] += 6;  // 0601C41E add #6,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0601C420 extu.b r1,r1
    c.r[4] = c.r[1];  // 0601C422 mov r1,r4
    c.r[4] <<= 8;  // 0601C424 shll8 r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0601C426 mov.b @r3,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601C428 extu.b r1,r1
    c.r[4] |= c.r[1];  // 0601C42A or r1,r4
    c.r[1] = ld32(0x0601C508u);  // 0601C42C mov.l 0x0601C508,r1
    c.t = c.r[4] == c.r[1];  // 0601C42E cmp/eq r1,r4
    { const bool k = c.t; c.t = (c.r[8] & c.r[8]) == 0; if (k) { goto L_0601C446; } }  // 0601C430 bt/s 0x0601C446 ; tst r8,r8
    c.r[0] = ld32(0x0601C50Cu);  // 0601C434 mov.l 0x0601C50C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601C43Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601C43Au) return; }  // 0601C436 jsr @r0 ; nop
    c.r[1] = c.r[0] & 0xFFFFu;  // 0601C43A extu.w r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601C43C tst r1,r1
    { const bool k = !c.t; c.t = (c.r[8] & c.r[8]) == 0; if (k) { goto L_0601C446; } }  // 0601C43E bf/s 0x0601C446 ; tst r8,r8
    goto L_0601C60A;  // 0601C442 bra 0x0601C60A ; nop
L_0601C446:
    { const bool k = c.t; c.t = (c.r[9] & c.r[9]) == 0; if (k) { goto L_0601C474; } }  // 0601C446 bt/s 0x0601C474 ; tst r9,r9
    if (!c.t) { goto L_0601C45C; }  // 0601C44A bf 0x0601C45C
    c.r[1] = ld32(0x0601C510u);  // 0601C44C mov.l 0x0601C510,r1
    c.r[1] = ld32(c.r[1]);  // 0601C44E mov.l @r1,r1
    c.r[1] += 6;  // 0601C450 add #6,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601C452 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601C454 extu.b r1,r1
    c.t = c.r[1] == c.r[8];  // 0601C456 cmp/eq r8,r1
    { const bool k = c.t; c.t = (c.r[9] & c.r[9]) == 0; if (k) { goto L_0601C474; } }  // 0601C458 bt/s 0x0601C474 ; tst r9,r9
L_0601C45C:
    if (!c.t) { goto L_0601C462; }  // 0601C45C bf 0x0601C462
    goto L_0601C60A;  // 0601C45E bra 0x0601C60A ; nop
L_0601C462:
    c.r[1] = ld32(0x0601C510u);  // 0601C462 mov.l 0x0601C510,r1
    c.r[1] = ld32(c.r[1]);  // 0601C464 mov.l @r1,r1
    c.r[1] += 6;  // 0601C466 add #6,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601C468 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601C46A extu.b r1,r1
    c.t = c.r[1] >= c.r[8];  // 0601C46C cmp/hs r8,r1
    if (c.t) { goto L_0601C474; }  // 0601C46E bt 0x0601C474
    goto L_0601C60A;  // 0601C470 bra 0x0601C60A ; nop
L_0601C474:
    c.r[8] = c.r[11];  // 0601C474 mov r11,r8
    c.r[8] <<= 16;  // 0601C476 shll16 r8
    c.r[8] <<= 2;  // 0601C478 shll2 r8
    c.r[8] += c.r[8];  // 0601C47A add r8,r8
    c.r[8] <<= 2;  // 0601C47C shll2 r8
    c.r[8] >>= 16;  // 0601C47E shlr16 r8
    c.r[8] += c.r[8];  // 0601C480 add r8,r8
    c.r[8] >>= 8;  // 0601C482 shlr8 r8
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601C4F2u);  // 0601C484 mov.w 0x0601C4F2,r1
    c.r[1] += c.r[8];  // 0601C486 add r8,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0601C488 extu.w r1,r1
    c.r[2] = 0x7u;  // 0601C48A mov #7,r2
    c.t = c.r[1] > c.r[2];  // 0601C48C cmp/hi r2,r1
    { const bool k = c.t; c.r[9] = 0x0u; if (k) { goto L_0601C516; } }  // 0601C48E bt/s 0x0601C516 ; mov #0,r9
    c.r[1] = c.r[8];  // 0601C492 mov r8,r1
    c.r[1] -= 48;  // 0601C494 add #-48,r1
    c.r[9] = c.r[1] & 0xFFu;  // 0601C496 extu.b r1,r9
    c.r[1] = ld32(0x0601C510u);  // 0601C498 mov.l 0x0601C510,r1
    c.r[2] = ld32(c.r[1]);  // 0601C49A mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601C4F4u);  // 0601C49C mov.w 0x0601C4F4,r1
    c.r[0] = c.r[2];  // 0601C49E mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601C4A0 mov.b @(r0,r1),r1
    c.r[3] = c.r[1];  // 0601C4A2 mov r1,r3
    c.r[3] >>= 2;  // 0601C4A4 shlr2 r3
    c.r[3] >>= 2;  // 0601C4A6 shlr2 r3
    c.r[0] = 0x4u;  // 0601C4A8 mov #4,r0
    c.r[3] &= c.r[0];  // 0601C4AA and r0,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601C4F6u);  // 0601C4AC mov.w 0x0601C4F6,r1
    c.r[0] = c.r[2];  // 0601C4AE mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601C4B0 mov.b @(r0,r1),r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0601C4B2 shlr r1
    c.r[0] = 0x3u;  // 0601C4B4 mov #3,r0
    c.r[1] &= c.r[0];  // 0601C4B6 and r0,r1
    c.r[3] += c.r[1];  // 0601C4B8 add r1,r3
    c.t = c.r[9] == c.r[3];  // 0601C4BA cmp/eq r3,r9
    { const bool k = !c.t; c.r[0] = c.r[2]; if (k) { goto L_0601C4C6; } }  // 0601C4BC bf/s 0x0601C4C6 ; mov r2,r0
    c.r[8] = (uint32_t)(int16_t)ld16(0x0601C4F8u);  // 0601C4C0 mov.w 0x0601C4F8,r8
    goto L_0601C516;  // 0601C4C2 bra 0x0601C516 ; nop
L_0601C4C6:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601C4FAu);  // 0601C4C6 mov.w 0x0601C4FA,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601C4C8 mov.b @(r0,r1),r1
    c.r[3] = c.r[1];  // 0601C4CA mov r1,r3
    c.r[3] >>= 2;  // 0601C4CC shlr2 r3
    c.r[3] >>= 2;  // 0601C4CE shlr2 r3
    c.r[0] = 0x4u;  // 0601C4D0 mov #4,r0
    c.r[3] &= c.r[0];  // 0601C4D2 and r0,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601C4FCu);  // 0601C4D4 mov.w 0x0601C4FC,r1
    c.r[0] = c.r[2];  // 0601C4D6 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601C4D8 mov.b @(r0,r1),r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0601C4DA shlr r1
    c.r[0] = 0x3u;  // 0601C4DC mov #3,r0
    c.r[1] &= c.r[0];  // 0601C4DE and r0,r1
    c.r[3] += c.r[1];  // 0601C4E0 add r1,r3
    c.t = c.r[9] == c.r[3];  // 0601C4E2 cmp/eq r3,r9
    if (!c.t) { goto L_0601C514; }  // 0601C4E4 bf 0x0601C514
    c.r[8] = (uint32_t)(int16_t)ld16(0x0601C4FEu);  // 0601C4E6 mov.w 0x0601C4FE,r8
    goto L_0601C516;  // 0601C4E8 bra 0x0601C516 ; nop
L_0601C514:
    c.r[9] = (uint32_t)(int16_t)ld16(0x0601C620u);  // 0601C514 mov.w 0x0601C620,r9
L_0601C516:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601C620u);  // 0601C516 mov.w 0x0601C620,r1
    c.t = c.r[9] == c.r[1];  // 0601C518 cmp/eq r1,r9
    { const bool k = c.t; c.r[5] = 0x0u; if (k) { goto L_0601C60A; } }  // 0601C51A bt/s 0x0601C60A ; mov #0,r5
    c.r[0] = ld32(0x0601C62Cu);  // 0601C51E mov.l 0x0601C62C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601C524u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601C524u) return; }  // 0601C520 jsr @r0 ; mov r8,r4
    c.r[10] = c.r[0] & 0xFFFFu;  // 0601C524 extu.w r0,r10
    c.r[1] = ld32(0x0601C630u);  // 0601C526 mov.l 0x0601C630,r1
    c.t = c.r[10] == c.r[1];  // 0601C528 cmp/eq r1,r10
    if (c.t) { goto L_0601C60A; }  // 0601C52A bt 0x0601C60A
    c.r[1] = ld32(0x0601C634u);  // 0601C52C mov.l 0x0601C634,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601C532u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601C532u) return; }  // 0601C52E jsr @r1 ; nop
    c.t = (c.r[9] & c.r[9]) == 0;  // 0601C532 tst r9,r9
    { const bool k = c.t; c.r[5] = (uint32_t)(int32_t)(int16_t)c.r[8]; if (k) { goto L_0601C542; } }  // 0601C534 bt/s 0x0601C542 ; exts.w r8,r5
    c.r[0] = ld32(0x0601C638u);  // 0601C538 mov.l 0x0601C638,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601C53Eu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601C53Eu) return; }  // 0601C53A jsr @r0 ; mov r8,r4
    c.r[10] = c.r[0] & 0xFFFFu;  // 0601C53E extu.w r0,r10
    c.r[5] = (uint32_t)(int32_t)(int16_t)c.r[8];  // 0601C540 exts.w r8,r5
L_0601C542:
    c.r[0] = ld32(0x0601C63Cu);  // 0601C542 mov.l 0x0601C63C,r0
    c.r[6] = 0x0u;  // 0601C544 mov #0,r6
    { const uint32_t x = c.r[0]; c.pr = 0x0601C54Au; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601C54Au) return; }  // 0601C546 jsr @r0 ; mov r14,r4
    c.r[3] = c.r[0];  // 0601C54A mov r0,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[14]);  // 0601C54C mov.b @r14,r2
    c.r[1] = ld32(0x0601C640u);  // 0601C54E mov.l 0x0601C640,r1
    c.r[1] = ld32(c.r[1]);  // 0601C550 mov.l @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0601C552 extu.b r2,r2
    c.r[2] <<= 2;  // 0601C554 shll2 r2
    c.r[2] <<= 2;  // 0601C556 shll2 r2
    c.r[2] += c.r[1];  // 0601C558 add r1,r2
    c.r[2] += 3;  // 0601C55A add #3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601C55C mov.b @r2,r1
    c.r[0] = c.r[1];  // 0601C55E mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0601C560 shlr r0
    c.r[0] &= 0x3u;  // 0601C562 and #3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601C564 tst r0,r0
    { const bool k = !c.t; c.r[9] = 0x0u; if (k) { goto L_0601C57C; } }  // 0601C566 bf/s 0x0601C57C ; mov #0,r9
    c.r[1] = c.r[11];  // 0601C56A mov r11,r1
    c.r[1] >>= 8;  // 0601C56C shlr8 r1
    c.r[1] += c.r[1];  // 0601C56E add r1,r1
    c.r[1] >>= 8;  // 0601C570 shlr8 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601C572 tst r1,r1
    if (!c.t) { goto L_0601C58A; }  // 0601C574 bf 0x0601C58A
    c.r[9] = c.r[3];  // 0601C576 mov r3,r9
    c.t = (c.r[9] & c.r[9]) == 0; goto L_0601C58C;  // 0601C578 bra 0x0601C58C ; tst r9,r9
L_0601C57C:
    c.r[1] = c.r[11];  // 0601C57C mov r11,r1
    c.r[1] >>= 8;  // 0601C57E shlr8 r1
    c.r[1] += c.r[1];  // 0601C580 add r1,r1
    c.r[1] >>= 8;  // 0601C582 shlr8 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601C584 tst r1,r1
    if (c.t) { goto L_0601C58A; }  // 0601C586 bt 0x0601C58A
    c.r[9] = c.r[3];  // 0601C588 mov r3,r9
L_0601C58A:
    c.t = (c.r[9] & c.r[9]) == 0;  // 0601C58A tst r9,r9
L_0601C58C:
    { const bool k = c.t; c.r[1] = 0x7Fu; if (k) { goto L_0601C60A; } }  // 0601C58C bt/s 0x0601C60A ; mov #127,r1
    c.r[9] = ld32(0x0601C644u);  // 0601C590 mov.l 0x0601C644,r9
    c.r[2] = c.r[9];  // 0601C592 mov r9,r2
    c.r[2] += 10;  // 0601C594 add #10,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601C596 mov.b @r2,r3
    c.r[0] = 0x3u;  // 0601C598 mov #3,r0
    c.r[11] &= c.r[0];  // 0601C59A and r0,r11
    c.r[11] <<= 2;  // 0601C59C shll2 r11
    c.r[11] += c.r[11];  // 0601C59E add r11,r11
    c.r[1] &= c.r[3];  // 0601C5A0 and r3,r1
    st8(c.r[2], c.r[1]);  // 0601C5A2 mov.b r1,@r2
    c.r[1] = ld32(0x0601C648u);  // 0601C5A4 mov.l 0x0601C648,r1
    st16(c.r[1], c.r[8]);  // 0601C5A6 mov.w r8,@r1
    c.r[1] = c.r[9];  // 0601C5A8 mov r9,r1
    c.r[1] += 8;  // 0601C5AA add #8,r1
    st16(c.r[1], c.r[10]);  // 0601C5AC mov.w r10,@r1
    c.r[1] = 0x67u;  // 0601C5AE mov #103,r1
    c.r[1] &= c.r[3];  // 0601C5B0 and r3,r1
    c.r[1] |= c.r[11];  // 0601C5B2 or r11,r1
    st8(c.r[2], c.r[1]);  // 0601C5B4 mov.b r1,@r2
    c.r[2] = ld32(0x0601C64Cu);  // 0601C5B6 mov.l 0x0601C64C,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601C622u);  // 0601C5B8 mov.w 0x0601C622,r1
    st16(c.r[2], c.r[1]);  // 0601C5BA mov.w r1,@r2
    c.r[2] = ld32(0x0601C650u);  // 0601C5BC mov.l 0x0601C650,r2
    c.r[1] = 0xFFFFFFFFu;  // 0601C5BE mov #-1,r1
    st8(c.r[2], c.r[1]);  // 0601C5C0 mov.b r1,@r2
    c.r[1] = ld32(0x0601C654u);  // 0601C5C2 mov.l 0x0601C654,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601C5C8u; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601C5C8u) return; }  // 0601C5C4 jsr @r1 ; mov r12,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601C624u);  // 0601C5C8 mov.w 0x0601C624,r1
    c.t = c.r[8] == c.r[1];  // 0601C5CA cmp/eq r1,r8
    if (!c.t) { goto L_0601C5EA; }  // 0601C5CC bf 0x0601C5EA
    c.r[3] = ld32(c.r[9]);  // 0601C5CE mov.l @r9,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0601C5D0 mov.b @r3,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0601C626u);  // 0601C5D2 mov.w 0x0601C626,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0601C5D4 extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 0601C5D6 cmp/eq r2,r1
    { const bool k = !c.t; c.r[2] = c.r[3]; if (k) { goto L_0601C5EA; } }  // 0601C5D8 bf/s 0x0601C5EA ; mov r3,r2
    c.r[2] += 1;  // 0601C5DC add #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601C5DE mov.b @r2,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0601C5E0 extu.b r1,r0
    c.t = c.r[0] == 0x2u;  // 0601C5E2 cmp/eq #2,r0
    { const bool k = !c.t; c.r[1] = 0x7u; if (k) { goto L_0601C5EA; } }  // 0601C5E4 bf/s 0x0601C5EA ; mov #7,r1
    st8(c.r[2], c.r[1]);  // 0601C5E8 mov.b r1,@r2
L_0601C5EA:
    c.r[1] = ld32(0x0601C658u);  // 0601C5EA mov.l 0x0601C658,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601C5F0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601C5F0u) return; }  // 0601C5EC jsr @r1 ; nop
    c.r[2] = ld32(0x0601C65Cu);  // 0601C5F0 mov.l 0x0601C65C,r2
    c.r[1] = 0x0u;  // 0601C5F2 mov #0,r1
    st32(c.r[2], c.r[1]);  // 0601C5F4 mov.l r1,@r2
    c.r[1] = ld32(0x0601C660u);  // 0601C5F6 mov.l 0x0601C660,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601C5FCu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601C5FCu) return; }  // 0601C5F8 jsr @r1 ; nop
    c.r[0] = ld32(0x0601C664u);  // 0601C5FC mov.l 0x0601C664,r0
    c.r[5] = 0x7u;  // 0601C5FE mov #7,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0601C604u; c.r[4] = 0x4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601C604u) return; }  // 0601C600 jsr @r0 ; mov #4,r4
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601C628u);  // 0601C604 mov.w 0x0601C628,r0
    c.r[14] += 76; goto L_0601C60E;  // 0601C606 bra 0x0601C60E ; add #76,r14
L_0601C60A:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601C62Au);  // 0601C60A mov.w 0x0601C62A,r0
    c.r[14] += 76;  // 0601C60C add #76,r14
L_0601C60E:
    c.r[15] = c.r[14];  // 0601C60E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601C610 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601C612 mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0601C614 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0601C616 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0601C618 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0601C61A mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601C61C rts ; mov.l @r15+,r8
}

void f_0601C668(SH2Context& c) {
    ran[301] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601C668 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0601C66A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0601C66C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0601C66E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0601C670 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0601C672 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601C674 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601C676 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0601C678 mov r15,r14
    c.r[10] = ld32(0x0601C768u);  // 0601C67A mov.l 0x0601C768,r10
    c.r[11] = ld32(0x0601C76Cu);  // 0601C67C mov.l 0x0601C76C,r11
    c.r[9] = c.r[11];  // 0601C67E mov r11,r9
    c.r[9] += 10;  // 0601C680 add #10,r9
    c.r[12] = (uint32_t)(int16_t)ld16(0x0601C760u);  // 0601C682 mov.w 0x0601C760,r12
    c.r[13] = c.r[12];  // 0601C684 mov r12,r13
    c.r[3] = ld32(c.r[10]);  // 0601C686 mov.l @r10,r3
    c.r[5] = 0x0u;  // 0601C688 mov #0,r5
    c.r[1] = c.r[3];  // 0601C68A mov r3,r1
    c.r[1] += 1;  // 0601C68C add #1,r1
    st32(c.r[10], c.r[1]);  // 0601C68E mov.l r1,@r10
    c.r[1] = c.r[3];  // 0601C690 mov r3,r1
    c.r[1] += 3;  // 0601C692 add #3,r1
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601C694 mov.b @r1,r8
    c.r[7] = ld32(0x0601C770u);  // 0601C696 mov.l 0x0601C770,r7
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0601C698 mov.b @r9,r0
    c.r[8] = c.r[8] & 0xFFu;  // 0601C69A extu.b r8,r8
    c.r[8] <<= 8;  // 0601C69C shll8 r8
    c.r[1] = c.r[3];  // 0601C69E mov r3,r1
    c.r[1] += 4;  // 0601C6A0 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601C6A2 mov.b @r1,r1
    c.r[0] &= 0x7Fu;  // 0601C6A4 and #127,r0
    c.r[1] = c.r[1] & 0xFFu;  // 0601C6A6 extu.b r1,r1
    c.r[8] |= c.r[1];  // 0601C6A8 or r1,r8
    c.r[1] = c.r[3];  // 0601C6AA mov r3,r1
    c.r[1] += 5;  // 0601C6AC add #5,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601C6AE mov.b @r1,r2
    c.r[3] += 6;  // 0601C6B0 add #6,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0601C6B2 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0601C6B4 mov.b @r3,r1
    c.r[2] <<= 8;  // 0601C6B6 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0601C6B8 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0601C6BA or r1,r2
    c.r[1] = c.r[2];  // 0601C6BC mov r2,r1
    c.r[1] >>= 8;  // 0601C6BE shlr8 r1
    c.r[1] += c.r[1];  // 0601C6C0 add r1,r1
    c.r[1] >>= 8;  // 0601C6C2 shlr8 r1
    c.r[1] <<= 2;  // 0601C6C4 shll2 r1
    c.r[1] <<= 2;  // 0601C6C6 shll2 r1
    c.r[1] += c.r[1];  // 0601C6C8 add r1,r1
    c.r[1] <<= 2;  // 0601C6CA shll2 r1
    c.r[0] |= c.r[1];  // 0601C6CC or r1,r0
    st8(c.r[9], c.r[0]);  // 0601C6CE mov.b r0,@r9
    c.r[13] &= c.r[2];  // 0601C6D0 and r2,r13
    { const uint32_t x = c.r[7]; c.pr = 0x0601C6D6u; c.r[4] = c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601C6D6u) return; }  // 0601C6D2 jsr @r7 ; mov r13,r4
    c.r[4] = c.r[8];  // 0601C6D6 mov r8,r4
    c.r[3] = ld32(c.r[10]);  // 0601C6D8 mov.l @r10,r3
    c.r[5] = 0x0u;  // 0601C6DA mov #0,r5
    c.r[1] = c.r[3];  // 0601C6DC mov r3,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0601C6DE mov.b @r1+,r2
    c.r[7] = ld32(0x0601C770u);  // 0601C6E0 mov.l 0x0601C770,r7
    c.r[2] = c.r[2] & 0xFFu;  // 0601C6E2 extu.b r2,r2
    c.r[2] <<= 8;  // 0601C6E4 shll8 r2
    c.r[4] >>= 2;  // 0601C6E6 shlr2 r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601C6E8 mov.b @r1,r1
    c.r[4] &= c.r[12];  // 0601C6EA and r12,r4
    c.r[1] = c.r[1] & 0xFFu;  // 0601C6EC extu.b r1,r1
    c.r[2] |= c.r[1];  // 0601C6EE or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0601C6F0 exts.w r2,r2
    c.r[3] += c.r[2];  // 0601C6F2 add r2,r3
    st32(c.r[11], c.r[3]);  // 0601C6F4 mov.l r3,@r11
    c.r[1] = ld32(0x0601C774u);  // 0601C6F6 mov.l 0x0601C774,r1
    { const uint32_t x = c.r[7]; c.pr = 0x0601C6FCu; st16(c.r[1], c.r[4]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601C6FCu) return; }  // 0601C6F8 jsr @r7 ; mov.w r4,@r1
    c.r[0] = ld32(0x0601C778u);  // 0601C6FC mov.l 0x0601C778,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601C702u; c.r[4] = c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601C702u) return; }  // 0601C6FE jsr @r0 ; mov r13,r4
    c.r[11] += 8;  // 0601C702 add #8,r11
    st16(c.r[11], c.r[0]);  // 0601C704 mov.w r0,@r11
    c.r[1] = 0x3u;  // 0601C706 mov #3,r1
    c.r[1] &= c.r[8];  // 0601C708 and r8,r1
    c.r[1] <<= 2;  // 0601C70A shll2 r1
    c.r[1] += c.r[1];  // 0601C70C add r1,r1
    c.r[2] = ld32(0x0601C77Cu);  // 0601C70E mov.l 0x0601C77C,r2
    c.r[5] = 0x6u;  // 0601C710 mov #6,r5
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0601C712 mov.b @r9,r0
    c.r[4] = 0x3u;  // 0601C714 mov #3,r4
    c.r[0] &= 0xE7u;  // 0601C716 and #231,r0
    c.r[0] |= c.r[1];  // 0601C718 or r1,r0
    st8(c.r[9], c.r[0]);  // 0601C71A mov.b r0,@r9
    c.r[0] >>= 2;  // 0601C71C shlr2 r0
    c.r[0] >>= 2;  // 0601C71E shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0601C720 shlr r0
    c.r[0] >>= 2;  // 0601C722 shlr2 r0
    c.r[0] += c.r[0];  // 0601C724 add r0,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601C762u);  // 0601C726 mov.w 0x0601C762,r1
    st16(c.r[0] + c.r[2], c.r[1]);  // 0601C728 mov.w r1,@(r0,r2)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0601C72A mov.b @r9,r1
    c.r[2] = ld32(0x0601C780u);  // 0601C72C mov.l 0x0601C780,r2
    c.r[0] = c.r[1] & 0xFFu;  // 0601C72E extu.b r1,r0
    c.r[0] >>= 2;  // 0601C730 shlr2 r0
    c.r[0] >>= 2;  // 0601C732 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0601C734 shlr r0
    c.r[0] >>= 2;  // 0601C736 shlr2 r0
    c.r[1] = 0xFFFFFFFFu;  // 0601C738 mov #-1,r1
    st8(c.r[0] + c.r[2], c.r[1]);  // 0601C73A mov.b r1,@(r0,r2)
    c.r[1] = ld32(0x0601C784u);  // 0601C73C mov.l 0x0601C784,r1
    c.r[8] >>= 8;  // 0601C73E shlr8 r8
    c.r[8] += c.r[8];  // 0601C740 add r8,r8
    c.r[8] >>= 8;  // 0601C742 shlr8 r8
    c.r[0] = ld32(0x0601C788u);  // 0601C744 mov.l 0x0601C788,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601C74Au; st32(c.r[1], c.r[8]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601C74Au) return; }  // 0601C746 jsr @r0 ; mov.l r8,@r1
    c.r[15] = c.r[14];  // 0601C74A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601C74C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601C74E mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0601C750 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0601C752 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0601C754 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0601C756 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0601C758 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601C764u);  // 0601C75A mov.w 0x0601C764,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601C75C rts ; mov.l @r15+,r8
}

void f_0601C78C(SH2Context& c) {
    ran[302] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601C78C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0601C78E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0601C790 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0601C792 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0601C794 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0601C796 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601C798 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601C79A sts.l pr,@-r15
    c.r[15] -= 4;  // 0601C79C add #-4,r15
    c.r[1] = ld32(0x0601C8FCu);  // 0601C79E mov.l 0x0601C8FC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601C7A4u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601C7A4u) return; }  // 0601C7A0 jsr @r1 ; mov r15,r14
    c.r[1] = ld32(0x0601C900u);  // 0601C7A4 mov.l 0x0601C900,r1
    c.r[1] = ld32(c.r[1]);  // 0601C7A6 mov.l @r1,r1
    c.r[1] += 4;  // 0601C7A8 add #4,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601C7AA mov.b @r1,r2
    c.t = (int32_t)c.r[2] >= 0;  // 0601C7AC cmp/pz r2
    { const bool k = c.t; c.r[3] = 0x0u; if (k) { goto L_0601C7B8; } }  // 0601C7AE bt/s 0x0601C7B8 ; mov #0,r3
    c.r[3] = 0x1u;  // 0601C7B2 mov #1,r3
    c.r[1] = 0u - c.r[2];  // 0601C7B4 neg r2,r1
    c.r[2] = (uint32_t)(int32_t)(int8_t)c.r[1];  // 0601C7B6 exts.b r1,r2
L_0601C7B8:
    c.t = (c.r[2] & c.r[2]) == 0;  // 0601C7B8 tst r2,r2
    { const bool k = c.t; c.t = (c.r[3] & c.r[3]) == 0; if (k) { goto L_0601C7E0; } }  // 0601C7BA bt/s 0x0601C7E0 ; tst r3,r3
    if (!c.t) { goto L_0601C7D0; }  // 0601C7BE bf 0x0601C7D0
    c.r[1] = ld32(0x0601C904u);  // 0601C7C0 mov.l 0x0601C904,r1
    c.r[1] = ld32(c.r[1]);  // 0601C7C2 mov.l @r1,r1
    c.r[1] += 6;  // 0601C7C4 add #6,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601C7C6 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601C7C8 extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 0601C7CA cmp/eq r2,r1
    { const bool k = c.t; c.t = (c.r[3] & c.r[3]) == 0; if (k) { goto L_0601C7E0; } }  // 0601C7CC bt/s 0x0601C7E0 ; tst r3,r3
L_0601C7D0:
    if (c.t) { goto L_0601C8D2; }  // 0601C7D0 bt 0x0601C8D2
    c.r[1] = ld32(0x0601C904u);  // 0601C7D2 mov.l 0x0601C904,r1
    c.r[1] = ld32(c.r[1]);  // 0601C7D4 mov.l @r1,r1
    c.r[1] += 6;  // 0601C7D6 add #6,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601C7D8 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601C7DA extu.b r1,r1
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[2];  // 0601C7DC cmp/ge r2,r1
    if (!c.t) { goto L_0601C8D2; }  // 0601C7DE bf 0x0601C8D2
L_0601C7E0:
    c.r[8] = ld32(0x0601C900u);  // 0601C7E0 mov.l 0x0601C900,r8
    c.r[2] = ld32(c.r[8]);  // 0601C7E2 mov.l @r8,r2
    c.r[1] = c.r[2];  // 0601C7E4 mov r2,r1
    c.r[1] += 2;  // 0601C7E6 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601C7E8 mov.b @r1,r1
    c.r[2] += 3;  // 0601C7EA add #3,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0601C7EC extu.b r1,r1
    c.r[13] = c.r[1];  // 0601C7EE mov r1,r13
    c.r[13] <<= 8;  // 0601C7F0 shll8 r13
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601C7F2 mov.b @r2,r1
    c.r[0] = ld32(0x0601C908u);  // 0601C7F4 mov.l 0x0601C908,r0
    c.r[1] = c.r[1] & 0xFFu;  // 0601C7F6 extu.b r1,r1
    c.r[13] |= c.r[1];  // 0601C7F8 or r1,r13
    c.r[11] = c.r[13];  // 0601C7FA mov r13,r11
    c.r[11] <<= 16;  // 0601C7FC shll16 r11
    c.r[11] <<= 2;  // 0601C7FE shll2 r11
    c.r[11] += c.r[11];  // 0601C800 add r11,r11
    c.r[11] <<= 2;  // 0601C802 shll2 r11
    c.r[11] >>= 16;  // 0601C804 shlr16 r11
    c.r[11] += c.r[11];  // 0601C806 add r11,r11
    c.r[11] >>= 8;  // 0601C808 shlr8 r11
    { const uint32_t x = c.r[0]; c.pr = 0x0601C80Eu; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601C80Eu) return; }  // 0601C80A jsr @r0 ; mov r11,r4
    c.r[4] = c.r[0] & 0xFFu;  // 0601C80E extu.b r0,r4
    c.r[9] = (uint32_t)(int16_t)ld16(0x0601C8F0u);  // 0601C810 mov.w 0x0601C8F0,r9
    c.t = c.r[4] == c.r[9];  // 0601C812 cmp/eq r9,r4
    if (c.t) { goto L_0601C8D2; }  // 0601C814 bt 0x0601C8D2
    c.r[1] = ld32(c.r[8]);  // 0601C816 mov.l @r8,r1
    c.r[12] = ld32(0x0601C90Cu);  // 0601C818 mov.l 0x0601C90C,r12
    c.r[10] = c.r[12];  // 0601C81A mov r12,r10
    c.r[10] += 10;  // 0601C81C add #10,r10
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601C8F2u);  // 0601C81E mov.w 0x0601C8F2,r0
    c.r[1] += 1;  // 0601C820 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601C822 mov.b @r1,r1
    c.r[8] = ld32(0x0601C910u);  // 0601C824 mov.l 0x0601C910,r8
    c.r[1] = c.r[1] & 0xFFu;  // 0601C826 extu.b r1,r1
    st32(c.r[14], c.r[1]);  // 0601C828 mov.l r1,@r14
    c.r[1] &= c.r[0];  // 0601C82A and r0,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0601C82C mov.b @r10,r2
    c.r[0] = 0x7Fu;  // 0601C82E mov #127,r0
    c.r[2] &= c.r[0];  // 0601C830 and r0,r2
    c.r[2] |= c.r[1];  // 0601C832 or r1,r2
    st8(c.r[10], c.r[2]);  // 0601C834 mov.b r2,@r10
    c.r[1] = c.r[8];  // 0601C836 mov r8,r1
    c.r[1] += 28;  // 0601C838 add #28,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0601C83A mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0601C83C extu.w r1,r1
    c.t = c.r[1] == c.r[11];  // 0601C83E cmp/eq r11,r1
    if (!c.t) { goto L_0601C8D2; }  // 0601C840 bf 0x0601C8D2
    c.r[0] = ld32(0x0601C914u);  // 0601C842 mov.l 0x0601C914,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601C848u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601C848u) return; }  // 0601C844 jsr @r0 ; extu.b r4,r4
    c.r[1] = c.r[0] & 0xFFu;  // 0601C848 extu.b r0,r1
    c.t = c.r[1] == c.r[9];  // 0601C84A cmp/eq r9,r1
    { const bool k = c.t; c.r[11] = c.r[9]; if (k) { goto L_0601C8CC; } }  // 0601C84C bt/s 0x0601C8CC ; mov r9,r11
    c.r[8] += 26;  // 0601C850 add #26,r8
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[8]);  // 0601C852 mov.w @r8,r4
    c.r[0] = ld32(0x0601C918u);  // 0601C854 mov.l 0x0601C918,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601C85Au; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601C85Au) return; }  // 0601C856 jsr @r0 ; extu.w r4,r4
    c.r[2] = c.r[0];  // 0601C85A mov r0,r2
    c.r[1] = c.r[12];  // 0601C85C mov r12,r1
    c.r[1] += 8;  // 0601C85E add #8,r1
    st16(c.r[1], c.r[2]);  // 0601C860 mov.w r2,@r1
    c.r[0] = 0x3u;  // 0601C862 mov #3,r0
    c.r[13] &= c.r[0];  // 0601C864 and r0,r13
    c.r[13] <<= 2;  // 0601C866 shll2 r13
    c.r[13] += c.r[13];  // 0601C868 add r13,r13
    c.r[3] = (uint32_t)(int16_t)ld16(0x0601C8F4u);  // 0601C86A mov.w 0x0601C8F4,r3
    c.r[2] = ld32(0x0601C91Cu);  // 0601C86C mov.l 0x0601C91C,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0601C86E mov.b @r10,r1
    c.r[4] = ld32(0x0601C920u);  // 0601C870 mov.l 0x0601C920,r4
    c.r[3] &= c.r[1];  // 0601C872 and r1,r3
    c.r[3] |= c.r[13];  // 0601C874 or r13,r3
    st8(c.r[10], c.r[3]);  // 0601C876 mov.b r3,@r10
    c.r[3] >>= 2;  // 0601C878 shlr2 r3
    c.r[3] >>= 2;  // 0601C87A shlr2 r3
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 0601C87C shlr r3
    c.r[3] >>= 2;  // 0601C87E shlr2 r3
    c.r[3] += c.r[3];  // 0601C880 add r3,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601C8F6u);  // 0601C882 mov.w 0x0601C8F6,r1
    c.r[0] = c.r[3];  // 0601C884 mov r3,r0
    st16(c.r[0] + c.r[2], c.r[1]);  // 0601C886 mov.w r1,@(r0,r2)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0601C888 mov.b @r10,r1
    c.r[8] = ld32(0x0601C924u);  // 0601C88A mov.l 0x0601C924,r8
    c.r[2] = c.r[1] & 0xFFu;  // 0601C88C extu.b r1,r2
    c.r[2] >>= 2;  // 0601C88E shlr2 r2
    c.r[2] >>= 2;  // 0601C890 shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 0601C892 shlr r2
    c.r[2] >>= 2;  // 0601C894 shlr2 r2
    c.r[1] = ld32(0x0601C928u);  // 0601C896 mov.l 0x0601C928,r1
    c.r[0] = c.r[2];  // 0601C898 mov r2,r0
    st8(c.r[0] + c.r[1], c.r[11]);  // 0601C89A mov.b r11,@(r0,r1)
    c.r[0] = ld32(c.r[14]);  // 0601C89C mov.l @r14,r0
    c.r[5] = 0x26u;  // 0601C89E mov #38,r5
    c.r[0] &= 0x7Fu;  // 0601C8A0 and #127,r0
    { const uint32_t x = c.r[8]; c.pr = 0x0601C8A6u; st32(c.r[14], c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601C8A6u) return; }  // 0601C8A2 jsr @r8 ; mov.l r0,@r14
    c.r[1] = c.r[0];  // 0601C8A6 mov r0,r1
    c.r[5] = ld32(c.r[14]);  // 0601C8A8 mov.l @r14,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0601C8AEu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601C8AEu) return; }  // 0601C8AA jsr @r8 ; mov r1,r4
    c.r[1] = c.r[0];  // 0601C8AE mov r0,r1
    st32(c.r[12], c.r[1]);  // 0601C8B0 mov.l r1,@r12
    c.r[1] = ld32(0x0601C92Cu);  // 0601C8B2 mov.l 0x0601C92C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601C8B8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601C8B8u) return; }  // 0601C8B4 jsr @r1 ; nop
    c.r[2] = ld32(0x0601C930u);  // 0601C8B8 mov.l 0x0601C930,r2
    c.r[1] = 0x0u;  // 0601C8BA mov #0,r1
    st32(c.r[2], c.r[1]);  // 0601C8BC mov.l r1,@r2
    c.r[1] = ld32(0x0601C934u);  // 0601C8BE mov.l 0x0601C934,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601C8C4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601C8C4u) return; }  // 0601C8C0 jsr @r1 ; nop
    c.r[5] = 0x5u;  // 0601C8C4 mov #5,r5
    c.r[0] = ld32(0x0601C938u);  // 0601C8C6 mov.l 0x0601C938,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601C8CCu; c.r[4] = 0x4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601C8CCu) return; }  // 0601C8C8 jsr @r0 ; mov #4,r4
L_0601C8CC:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601C8F8u);  // 0601C8CC mov.w 0x0601C8F8,r0
    c.r[14] += 4; goto L_0601C8DC;  // 0601C8CE bra 0x0601C8DC ; add #4,r14
L_0601C8D2:
    c.r[1] = ld32(0x0601C8FCu);  // 0601C8D2 mov.l 0x0601C8FC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601C8D8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601C8D8u) return; }  // 0601C8D4 jsr @r1 ; nop
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601C8FAu);  // 0601C8D8 mov.w 0x0601C8FA,r0
    c.r[14] += 4;  // 0601C8DA add #4,r14
L_0601C8DC:
    c.r[15] = c.r[14];  // 0601C8DC mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601C8DE lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601C8E0 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0601C8E2 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0601C8E4 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0601C8E6 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0601C8E8 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0601C8EA mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601C8EC rts ; mov.l @r15+,r8
}

void f_0601C93C(SH2Context& c) {
    ran[303] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601C93C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601C93E sts.l pr,@-r15
    c.r[0] = ld32(0x0601C96Cu);  // 0601C940 mov.l 0x0601C96C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601C946u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601C946u) return; }  // 0601C942 jsr @r0 ; mov r15,r14
    c.r[1] = ld32(0x0601C970u);  // 0601C946 mov.l 0x0601C970,r1
    c.r[1] = ld32(c.r[1]);  // 0601C948 mov.l @r1,r1
    c.r[1] += 1;  // 0601C94A add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601C94C mov.b @r1,r1
    c.r[15] = c.r[14];  // 0601C94E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601C950 lds.l @r15+,pr
    c.r[1] = c.r[1] & 0xFFu;  // 0601C952 extu.b r1,r1
    c.macl = c.r[0] * c.r[1];  // 0601C954 mul.l r1,r0
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601C956 mov.l @r15+,r14
    c.r[2] = c.macl;  // 0601C958 sts macl,r2
    c.r[2] >>= 16;  // 0601C95A shlr16 r2
    c.r[2] += c.r[2];  // 0601C95C add r2,r2
    c.r[2] += 2;  // 0601C95E add #2,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601C968u);  // 0601C960 mov.w 0x0601C968,r1
    c.r[2] |= c.r[1];  // 0601C962 or r1,r2
    { const uint32_t x = c.pr; c.r[0] = c.r[2] & 0xFFFFu; c.pc = x; return; }  // 0601C964 rts ; extu.w r2,r0
}

void f_0601C974(SH2Context& c) {
    ran[304] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601C974 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0601C976 mov r15,r14
    c.r[3] = ld32(0x0601C9A0u);  // 0601C978 mov.l 0x0601C9A0,r3
    c.r[2] = c.r[3];  // 0601C97A mov r3,r2
    c.r[2] += 2;  // 0601C97C add #2,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601C99Cu);  // 0601C97E mov.w 0x0601C99C,r1
    st16(c.r[2], c.r[1]);  // 0601C980 mov.w r1,@r2
    st16(c.r[3], c.r[1]);  // 0601C982 mov.w r1,@r3
    c.r[3] = ld32(0x0601C9A4u);  // 0601C984 mov.l 0x0601C9A4,r3
    c.r[2] = c.r[3];  // 0601C986 mov r3,r2
    c.r[2] += 1;  // 0601C988 add #1,r2
    c.r[1] = 0xFFFFFFFFu;  // 0601C98A mov #-1,r1
    st8(c.r[2], c.r[1]);  // 0601C98C mov.b r1,@r2
    st8(c.r[3], c.r[1]);  // 0601C98E mov.b r1,@r3
    c.r[2] = ld32(0x0601C9A8u);  // 0601C990 mov.l 0x0601C9A8,r2
    c.r[1] = 0x0u;  // 0601C992 mov #0,r1
    st32(c.r[2] + 4, c.r[1]);  // 0601C994 mov.l r1,@(4,r2)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601C99Eu);  // 0601C996 mov.w 0x0601C99E,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601C998 rts ; mov.l @r15+,r14
}

void f_0601C9AC(SH2Context& c) {
    ran[305] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601C9AC mov.l r14,@-r15
    c.r[1] = ld32(0x0601CA00u);  // 0601C9AE mov.l 0x0601CA00,r1
    c.r[2] = ld32(c.r[1]);  // 0601C9B0 mov.l @r1,r2
    c.r[1] = c.r[2];  // 0601C9B2 mov r2,r1
    c.r[1] += 1;  // 0601C9B4 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601C9B6 mov.b @r1,r1
    c.r[3] = c.r[1];  // 0601C9B8 mov r1,r3
    c.r[3] <<= 16;  // 0601C9BA shll16 r3
    c.r[3] <<= 8;  // 0601C9BC shll8 r3
    c.r[1] = c.r[2];  // 0601C9BE mov r2,r1
    c.r[1] += 2;  // 0601C9C0 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601C9C2 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601C9C4 extu.b r1,r1
    c.r[1] <<= 16;  // 0601C9C6 shll16 r1
    c.r[3] |= c.r[1];  // 0601C9C8 or r1,r3
    c.r[1] = c.r[2];  // 0601C9CA mov r2,r1
    c.r[1] += 3;  // 0601C9CC add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601C9CE mov.b @r1,r1
    c.r[2] += 4;  // 0601C9D0 add #4,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0601C9D2 extu.b r1,r1
    c.r[1] <<= 8;  // 0601C9D4 shll8 r1
    c.r[3] |= c.r[1];  // 0601C9D6 or r1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601C9D8 mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601C9DA extu.b r1,r1
    c.r[3] |= c.r[1];  // 0601C9DC or r1,r3
    c.r[1] = ld32(0x0601CA04u);  // 0601C9DE mov.l 0x0601CA04,r1
    c.t = c.r[3] == c.r[1];  // 0601C9E0 cmp/eq r1,r3
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0601C9EC; } }  // 0601C9E2 bt/s 0x0601C9EC ; mov r15,r14
    c.r[1] = ld32(0x0601CA08u);  // 0601C9E6 mov.l 0x0601CA08,r1
    st32(c.r[1] + 12, c.r[3]); goto L_0601C9F4;  // 0601C9E8 bra 0x0601C9F4 ; mov.l r3,@(12,r1)
L_0601C9EC:
    c.r[2] = ld32(0x0601CA0Cu);  // 0601C9EC mov.l 0x0601CA0C,r2
    c.r[2] = ld32(c.r[2] + 20);  // 0601C9EE mov.l @(20,r2),r2
    c.r[1] = ld32(0x0601CA08u);  // 0601C9F0 mov.l 0x0601CA08,r1
    st32(c.r[1] + 12, c.r[2]);  // 0601C9F2 mov.l r2,@(12,r1)
L_0601C9F4:
    c.r[15] = c.r[14];  // 0601C9F4 mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601C9FCu);  // 0601C9F6 mov.w 0x0601C9FC,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601C9F8 rts ; mov.l @r15+,r14
}

void f_0601CA10(SH2Context& c) {
    ran[306] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601CA10 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601CA12 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601CA14 sts.l pr,@-r15
    c.r[1] = ld32(0x0601CA84u);  // 0601CA16 mov.l 0x0601CA84,r1
    c.r[2] = ld32(c.r[1]);  // 0601CA18 mov.l @r1,r2
    c.r[2] += 1;  // 0601CA1A add #1,r2
    st32(c.r[1], c.r[2]);  // 0601CA1C mov.l r2,@r1
    c.r[1] = ld32(0x0601CA88u);  // 0601CA1E mov.l 0x0601CA88,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601CA24u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601CA24u) return; }  // 0601CA20 jsr @r1 ; mov r15,r14
    c.r[8] = ld32(0x0601CA8Cu);  // 0601CA24 mov.l 0x0601CA8C,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0601CA26 mov.b @r8,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0601CA7Eu);  // 0601CA28 mov.w 0x0601CA7E,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0601CA2A extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 0601CA2C cmp/eq r2,r1
    if (!c.t) { goto L_0601CA38; }  // 0601CA2E bf 0x0601CA38
    c.r[15] = c.r[14];  // 0601CA30 mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601CA80u);  // 0601CA32 mov.w 0x0601CA80,r0
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; } goto L_0601CA78;  // 0601CA34 bra 0x0601CA78 ; lds.l @r15+,pr
L_0601CA38:
    c.r[1] = ld32(0x0601CA90u);  // 0601CA38 mov.l 0x0601CA90,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601CA3Eu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601CA3Eu) return; }  // 0601CA3A jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x0601CA94u);  // 0601CA3E mov.l 0x0601CA94,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601CA44u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601CA44u) return; }  // 0601CA40 jsr @r1 ; nop
    c.r[1] = c.r[8];  // 0601CA44 mov r8,r1
    c.r[1] += 1;  // 0601CA46 add #1,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601CA48 mov.b @r1,r5
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0601CA4A mov.b @r8,r4
    c.r[5] = c.r[5] & 0xFFu;  // 0601CA4C extu.b r5,r5
    c.r[1] = ld32(0x0601CA98u);  // 0601CA4E mov.l 0x0601CA98,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601CA54u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601CA54u) return; }  // 0601CA50 jsr @r1 ; extu.b r4,r4
    c.r[1] = ld32(0x0601CA9Cu);  // 0601CA54 mov.l 0x0601CA9C,r1
    c.r[0] = ld32(0x0601CAA0u);  // 0601CA56 mov.l 0x0601CAA0,r0
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601CA58 mov.b @r1,r4
    c.r[5] = 0x4u;  // 0601CA5A mov #4,r5
    c.r[4] = c.r[4] & 0xFFu;  // 0601CA5C extu.b r4,r4
    c.r[4] >>= 2;  // 0601CA5E shlr2 r4
    c.r[4] >>= 2;  // 0601CA60 shlr2 r4
    c.t = c.r[4] & 1; c.r[4] >>= 1;  // 0601CA62 shlr r4
    c.r[4] >>= 2;  // 0601CA64 shlr2 r4
    c.r[4] += 1;  // 0601CA66 add #1,r4
    { const uint32_t x = c.r[0]; c.pr = 0x0601CA6Cu; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601CA6Cu) return; }  // 0601CA68 jsr @r0 ; extu.w r4,r4
    c.r[1] = ld32(0x0601CAA4u);  // 0601CA6C mov.l 0x0601CAA4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601CA72u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601CA72u) return; }  // 0601CA6E jsr @r1 ; nop
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601CA82u);  // 0601CA72 mov.w 0x0601CA82,r0
    c.r[15] = c.r[14];  // 0601CA74 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601CA76 lds.l @r15+,pr
L_0601CA78:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601CA78 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601CA7A rts ; mov.l @r15+,r8
}

void f_0601CAA8(SH2Context& c) {
    ran[307] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601CAA8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0601CAAA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0601CAAC mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0601CAAE mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0601CAB0 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0601CAB2 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601CAB4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601CAB6 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0601CAB8 mov r15,r14
    c.r[11] = c.r[4] & 0xFFu;  // 0601CABA extu.b r4,r11
    c.r[9] = ld32(0x0601CBA0u);  // 0601CABC mov.l 0x0601CBA0,r9
    c.r[12] = c.r[9];  // 0601CABE mov r9,r12
    c.r[12] += 10;  // 0601CAC0 add #10,r12
    c.r[1] = c.r[11];  // 0601CAC2 mov r11,r1
    c.r[1] <<= 2;  // 0601CAC4 shll2 r1
    c.r[1] <<= 2;  // 0601CAC6 shll2 r1
    c.r[1] += c.r[1];  // 0601CAC8 add r1,r1
    c.r[1] <<= 2;  // 0601CACA shll2 r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[12]);  // 0601CACC mov.b @r12,r2
    c.r[0] = 0x7Fu;  // 0601CACE mov #127,r0
    c.r[2] &= c.r[0];  // 0601CAD0 and r0,r2
    c.r[2] |= c.r[1];  // 0601CAD2 or r1,r2
    st8(c.r[12], c.r[2]);  // 0601CAD4 mov.b r2,@r12
    c.r[1] = ld32(0x0601CBA4u);  // 0601CAD6 mov.l 0x0601CBA4,r1
    c.r[3] = ld32(c.r[1]);  // 0601CAD8 mov.l @r1,r3
    c.r[13] = c.r[11];  // 0601CADA mov r11,r13
    c.r[1] = c.r[3];  // 0601CADC mov r3,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0601CADE mov.b @r1+,r2
    c.r[8] = ld32(0x0601CBA8u);  // 0601CAE0 mov.l 0x0601CBA8,r8
    c.r[2] = c.r[2] & 0xFFu;  // 0601CAE2 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601CAE4 mov.b @r1,r1
    c.r[2] <<= 8;  // 0601CAE6 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0601CAE8 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0601CAEA or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0601CAEC exts.w r2,r2
    c.r[2] += c.r[3];  // 0601CAEE add r3,r2
    st32(c.r[9], c.r[2]);  // 0601CAF0 mov.l r2,@r9
    c.r[1] = c.r[3];  // 0601CAF2 mov r3,r1
    c.r[1] += 2;  // 0601CAF4 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601CAF6 mov.b @r1,r1
    c.r[3] += 3;  // 0601CAF8 add #3,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0601CAFA extu.b r1,r1
    c.r[10] = c.r[1];  // 0601CAFC mov r1,r10
    c.r[10] <<= 8;  // 0601CAFE shll8 r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0601CB00 mov.b @r3,r1
    c.r[5] = 0x0u;  // 0601CB02 mov #0,r5
    c.r[1] = c.r[1] & 0xFFu;  // 0601CB04 extu.b r1,r1
    c.r[10] |= c.r[1];  // 0601CB06 or r1,r10
    c.r[4] = c.r[10];  // 0601CB08 mov r10,r4
    c.r[4] <<= 16;  // 0601CB0A shll16 r4
    c.r[4] <<= 2;  // 0601CB0C shll2 r4
    c.r[4] += c.r[4];  // 0601CB0E add r4,r4
    c.r[4] <<= 2;  // 0601CB10 shll2 r4
    c.r[4] >>= 16;  // 0601CB12 shlr16 r4
    c.r[4] += c.r[4];  // 0601CB14 add r4,r4
    c.r[4] >>= 8;  // 0601CB16 shlr8 r4
    c.r[1] = ld32(0x0601CBACu);  // 0601CB18 mov.l 0x0601CBAC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601CB1Eu; st16(c.r[8], c.r[4]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601CB1Eu) return; }  // 0601CB1A jsr @r1 ; mov.w r4,@r8
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[8]);  // 0601CB1E mov.w @r8,r4
    c.r[0] = ld32(0x0601CBB0u);  // 0601CB20 mov.l 0x0601CBB0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601CB26u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601CB26u) return; }  // 0601CB22 jsr @r0 ; extu.w r4,r4
    c.r[2] = c.r[0];  // 0601CB26 mov r0,r2
    c.r[9] += 8;  // 0601CB28 add #8,r9
    st16(c.r[9], c.r[2]);  // 0601CB2A mov.w r2,@r9
    c.r[0] = 0x3u;  // 0601CB2C mov #3,r0
    c.r[10] &= c.r[0];  // 0601CB2E and r0,r10
    c.r[10] <<= 2;  // 0601CB30 shll2 r10
    c.r[10] += c.r[10];  // 0601CB32 add r10,r10
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601CB9Au);  // 0601CB34 mov.w 0x0601CB9A,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[12]);  // 0601CB36 mov.b @r12,r1
    c.r[3] = ld32(0x0601CBB4u);  // 0601CB38 mov.l 0x0601CBB4,r3
    c.r[1] &= c.r[0];  // 0601CB3A and r0,r1
    c.r[1] |= c.r[10];  // 0601CB3C or r10,r1
    st8(c.r[12], c.r[1]);  // 0601CB3E mov.b r1,@r12
    c.r[1] >>= 2;  // 0601CB40 shlr2 r1
    c.r[1] >>= 2;  // 0601CB42 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0601CB44 shlr r1
    c.r[1] >>= 2;  // 0601CB46 shlr2 r1
    c.r[1] += c.r[1];  // 0601CB48 add r1,r1
    c.r[0] = c.r[1];  // 0601CB4A mov r1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 0601CB4C mov.w @(r0,r3),r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 0601CB4E extu.w r2,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 0601CB50 extu.w r1,r1
    c.t = c.r[1] == c.r[2];  // 0601CB52 cmp/eq r2,r1
    { const bool k = c.t; c.r[11] += c.r[11]; if (k) { goto L_0601CB5E; } }  // 0601CB54 bt/s 0x0601CB5E ; add r11,r11
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601CB9Cu);  // 0601CB58 mov.w 0x0601CB9C,r1
    c.r[0] = c.r[11];  // 0601CB5A mov r11,r0
    st16(c.r[0] + c.r[3], c.r[1]);  // 0601CB5C mov.w r1,@(r0,r3)
L_0601CB5E:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[12]);  // 0601CB5E mov.b @r12,r1
    c.r[2] = ld32(0x0601CBB8u);  // 0601CB60 mov.l 0x0601CBB8,r2
    c.r[3] = c.r[1] & 0xFFu;  // 0601CB62 extu.b r1,r3
    c.r[1] = c.r[3];  // 0601CB64 mov r3,r1
    c.r[1] >>= 2;  // 0601CB66 shlr2 r1
    c.r[1] >>= 2;  // 0601CB68 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0601CB6A shlr r1
    c.r[1] >>= 2;  // 0601CB6C shlr2 r1
    c.r[0] = c.r[1];  // 0601CB6E mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0601CB70 mov.b @(r0,r2),r1
    c.r[3] >>= 2;  // 0601CB72 shlr2 r3
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 0601CB74 shlr r3
    c.r[1] = c.r[1] & 0xFFu;  // 0601CB76 extu.b r1,r1
    c.r[0] = 0x3u;  // 0601CB78 mov #3,r0
    c.r[3] &= c.r[0];  // 0601CB7A and r0,r3
    c.t = c.r[1] == c.r[3];  // 0601CB7C cmp/eq r3,r1
    { const bool k = c.t; c.r[1] = 0xFFFFFFFFu; if (k) { goto L_0601CB86; } }  // 0601CB7E bt/s 0x0601CB86 ; mov #-1,r1
    c.r[0] = c.r[13];  // 0601CB82 mov r13,r0
    st8(c.r[0] + c.r[2], c.r[1]);  // 0601CB84 mov.b r1,@(r0,r2)
L_0601CB86:
    c.r[15] = c.r[14];  // 0601CB86 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601CB88 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601CB8A mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0601CB8C mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0601CB8E mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0601CB90 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0601CB92 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0601CB94 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601CB96 rts ; mov.l @r15+,r8
}

void f_0601CBBC(SH2Context& c) {
    ran[308] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601CBBC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0601CBBE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601CBC0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601CBC2 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0601CBC4 mov r15,r14
    c.r[8] = c.r[4];  // 0601CBC6 mov r4,r8
    c.r[8] = c.r[8] & 0xFFFFu;  // 0601CBC8 extu.w r8,r8
    c.r[4] = ld32(0x0601CBF4u);  // 0601CBCA mov.l 0x0601CBF4,r4
    c.r[9] = ld32(0x0601CBF8u);  // 0601CBCC mov.l 0x0601CBF8,r9
    { const uint32_t x = c.r[9]; c.pr = 0x0601CBD2u; c.r[5] = 0x1Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601CBD2u) return; }  // 0601CBCE jsr @r9 ; mov #28,r5
    c.r[5] = c.r[8];  // 0601CBD2 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0601CBD8u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601CBD8u) return; }  // 0601CBD4 jsr @r9 ; mov r0,r4
    c.r[2] = 0x1u;  // 0601CBD8 mov #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]); c.r[0] += 1;  // 0601CBDA mov.b @r0+,r1
    c.r[15] = c.r[14];  // 0601CBDC mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601CBDE lds.l @r15+,pr
    c.r[2] &= c.r[1];  // 0601CBE0 and r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0601CBE2 mov.b @r0,r1
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601CBE4 mov.l @r15+,r14
    c.r[1] = c.r[1] & 0xFFu;  // 0601CBE6 extu.b r1,r1
    c.r[0] = c.r[2];  // 0601CBE8 mov r2,r0
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0601CBEA mov.l @r15+,r9
    c.r[0] <<= 8;  // 0601CBEC shll8 r0
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0601CBEE mov.l @r15+,r8
    { const uint32_t x = c.pr; c.r[0] |= c.r[1]; c.pc = x; return; }  // 0601CBF0 rts ; or r1,r0
}

void f_0601CBFC(SH2Context& c) {
    ran[309] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601CBFC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601CBFE mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601CC00 sts.l pr,@-r15
    c.r[15] -= 128;  // 0601CC02 add #-128,r15
    c.r[1] = ld32(0x0601CD44u);  // 0601CC04 mov.l 0x0601CD44,r1
    c.r[4] = ld32(c.r[1] + 4);  // 0601CC06 mov.l @(4,r1),r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 0601CC08 tst r4,r4
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0601CC24; } }  // 0601CC0A bf/s 0x0601CC24 ; mov r15,r14
    c.r[1] += 10;  // 0601CC0E add #10,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601CC10 mov.b @r1,r2
    c.r[0] = 0x20u;  // 0601CC12 mov #32,r0
    c.r[3] = c.r[2];  // 0601CC14 mov r2,r3
    c.r[3] >>= 2;  // 0601CC16 shlr2 r3
    c.r[3] &= c.r[0];  // 0601CC18 and r0,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601CD40u);  // 0601CC1A mov.w 0x0601CD40,r0
    c.r[2] &= c.r[0];  // 0601CC1C and r0,r2
    c.r[2] |= c.r[3];  // 0601CC1E or r3,r2
    st8(c.r[1], c.r[2]); goto L_0601CC7A;  // 0601CC20 bra 0x0601CC7A ; mov.b r2,@r1
L_0601CC24:
    c.r[8] = c.r[1];  // 0601CC24 mov r1,r8
    c.r[8] += 10;  // 0601CC26 add #10,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0601CC28 mov.b @r8,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601CC2A extu.b r1,r1
    c.r[0] = c.r[1];  // 0601CC2C mov r1,r0
    c.r[0] >>= 2;  // 0601CC2E shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0601CC30 shlr r0
    c.r[0] >>= 2;  // 0601CC32 shlr2 r0
    c.r[1] >>= 2;  // 0601CC34 shlr2 r1
    c.r[1] >>= 2;  // 0601CC36 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0601CC38 shlr r1
    c.r[1] >>= 2;  // 0601CC3A shlr2 r1
    c.r[0] &= 0x3u;  // 0601CC3C and #3,r0
    c.t = c.r[1] == c.r[0];  // 0601CC3E cmp/eq r0,r1
    { const bool k = c.t; c.r[6] = 0x1u; if (k) { goto L_0601CC7A; } }  // 0601CC40 bt/s 0x0601CC7A ; mov #1,r6
    c.r[0] = ld32(0x0601CD48u);  // 0601CC44 mov.l 0x0601CD48,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601CC4Au; c.r[5] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601CC4Au) return; }  // 0601CC46 jsr @r0 ; mov r14,r5
    c.r[0] = 0x3u;  // 0601CC4A mov #3,r0
    c.r[7] = 0x0u;  // 0601CC4C mov #0,r7
    c.r[6] = 0x0u;  // 0601CC4E mov #0,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0601CC50 mov.b @r8,r1
    c.r[4] = 0x2u;  // 0601CC52 mov #2,r4
    c.r[1] >>= 2;  // 0601CC54 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0601CC56 shlr r1
    c.r[1] >>= 2;  // 0601CC58 shlr2 r1
    c.r[1] &= c.r[0];  // 0601CC5A and r0,r1
    c.r[1] += 3;  // 0601CC5C add #3,r1
    c.r[5] = c.r[1] & 0xFFu;  // 0601CC5E extu.b r1,r5
    c.r[1] = ld32(0x0601CD4Cu);  // 0601CC60 mov.l 0x0601CD4C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601CC66u; c.r[15] -= 4; st32(c.r[15], c.r[14]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601CC66u) return; }  // 0601CC62 jsr @r1 ; mov.l r14,@-r15
    c.r[0] = 0x20u;  // 0601CC66 mov #32,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0601CC68 mov.b @r8,r1
    c.r[15] += 4;  // 0601CC6A add #4,r15
    c.r[2] = c.r[1];  // 0601CC6C mov r1,r2
    c.r[2] >>= 2;  // 0601CC6E shlr2 r2
    c.r[2] &= c.r[0];  // 0601CC70 and r0,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601CD40u);  // 0601CC72 mov.w 0x0601CD40,r0
    c.r[1] &= c.r[0];  // 0601CC74 and r0,r1
    c.r[1] |= c.r[2];  // 0601CC76 or r2,r1
    st8(c.r[8], c.r[1]);  // 0601CC78 mov.b r1,@r8
L_0601CC7A:
    c.r[8] = ld32(0x0601CD44u);  // 0601CC7A mov.l 0x0601CD44,r8
    c.r[0] = ld32(0x0601CD48u);  // 0601CC7C mov.l 0x0601CD48,r0
    c.r[6] = 0x1u;  // 0601CC7E mov #1,r6
    c.r[4] = ld32(c.r[8]);  // 0601CC80 mov.l @r8,r4
    c.r[5] = c.r[14];  // 0601CC82 mov r14,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0601CC88u; st32(c.r[8] + 4, c.r[4]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601CC88u) return; }  // 0601CC84 jsr @r0 ; mov.l r4,@(4,r8)
    st32(c.r[8], c.r[0]);  // 0601CC88 mov.l r0,@r8
    c.r[1] = c.r[8];  // 0601CC8A mov r8,r1
    c.r[1] += 10;  // 0601CC8C add #10,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601CC8E mov.b @r1,r1
    c.r[7] = c.r[1] & 0xFFu;  // 0601CC90 extu.b r1,r7
    c.r[3] = c.r[7];  // 0601CC92 mov r7,r3
    c.r[3] >>= 2;  // 0601CC94 shlr2 r3
    c.r[3] >>= 2;  // 0601CC96 shlr2 r3
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 0601CC98 shlr r3
    c.r[3] >>= 2;  // 0601CC9A shlr2 r3
    c.r[0] = c.r[3];  // 0601CC9C mov r3,r0
    c.r[0] += c.r[0];  // 0601CC9E add r0,r0
    c.r[1] = ld32(0x0601CD50u);  // 0601CCA0 mov.l 0x0601CD50,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0601CCA2 mov.w @(r0,r1),r2
    c.r[8] += 8;  // 0601CCA4 add #8,r8
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[8]);  // 0601CCA6 mov.w @r8,r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 0601CCA8 extu.w r2,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 0601CCAA extu.w r1,r1
    c.t = c.r[2] == c.r[1];  // 0601CCAC cmp/eq r1,r2
    { const bool k = !c.t; c.r[0] = c.r[3]; if (k) { goto L_0601CCD2; } }  // 0601CCAE bf/s 0x0601CCD2 ; mov r3,r0
    c.r[1] = ld32(0x0601CD54u);  // 0601CCB2 mov.l 0x0601CD54,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601CCB4 mov.b @(r0,r1),r1
    c.r[7] >>= 2;  // 0601CCB6 shlr2 r7
    c.t = c.r[7] & 1; c.r[7] >>= 1;  // 0601CCB8 shlr r7
    c.r[1] = c.r[1] & 0xFFu;  // 0601CCBA extu.b r1,r1
    c.r[0] = 0x3u;  // 0601CCBC mov #3,r0
    c.r[7] &= c.r[0];  // 0601CCBE and r0,r7
    c.t = c.r[1] == c.r[7];  // 0601CCC0 cmp/eq r7,r1
    if (!c.t) { goto L_0601CCD2; }  // 0601CCC2 bf 0x0601CCD2
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601CCC4 mov.l r14,@-r15
    c.r[1] = ld32(0x0601CD4Cu);  // 0601CCC6 mov.l 0x0601CD4C,r1
    c.r[7] = 0x0u;  // 0601CCC8 mov #0,r7
    c.r[6] = 0x0u;  // 0601CCCA mov #0,r6
    c.r[5] = c.r[3];  // 0601CCCC mov r3,r5
    c.r[4] = 0x2u; goto L_0601CD2E;  // 0601CCCE bra 0x0601CD2E ; mov #2,r4
L_0601CCD2:
    c.r[3] = ld32(0x0601CD44u);  // 0601CCD2 mov.l 0x0601CD44,r3
    c.r[7] = c.r[3];  // 0601CCD4 mov r3,r7
    c.r[7] += 10;  // 0601CCD6 add #10,r7
    c.r[0] = 0x2u;  // 0601CCD8 mov #2,r0
    c.r[2] = ld32(0x0601CD50u);  // 0601CCDA mov.l 0x0601CD50,r2
    c.r[3] += 8;  // 0601CCDC add #8,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0601CCDE mov.b @r7,r1
    c.r[4] = 0x2u;  // 0601CCE0 mov #2,r4
    c.r[6] = c.r[1];  // 0601CCE2 mov r1,r6
    c.r[6] >>= 2;  // 0601CCE4 shlr2 r6
    c.r[6] >>= 2;  // 0601CCE6 shlr2 r6
    c.r[6] >>= 2;  // 0601CCE8 shlr2 r6
    c.r[6] &= c.r[0];  // 0601CCEA and r0,r6
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0601CCEC mov.w @r3,r1
    c.r[0] = c.r[6];  // 0601CCEE mov r6,r0
    st16(c.r[0] + c.r[2], c.r[1]);  // 0601CCF0 mov.w r1,@(r0,r2)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0601CCF2 mov.b @r7,r1
    c.r[0] = 0x3u;  // 0601CCF4 mov #3,r0
    c.r[6] = c.r[1] & 0xFFu;  // 0601CCF6 extu.b r1,r6
    c.r[2] = c.r[6];  // 0601CCF8 mov r6,r2
    c.r[2] >>= 2;  // 0601CCFA shlr2 r2
    c.r[2] >>= 2;  // 0601CCFC shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 0601CCFE shlr r2
    c.r[2] >>= 2;  // 0601CD00 shlr2 r2
    c.r[1] = ld32(0x0601CD54u);  // 0601CD02 mov.l 0x0601CD54,r1
    c.r[6] >>= 2;  // 0601CD04 shlr2 r6
    c.t = c.r[6] & 1; c.r[6] >>= 1;  // 0601CD06 shlr r6
    c.r[6] &= c.r[0];  // 0601CD08 and r0,r6
    c.r[0] = c.r[2];  // 0601CD0A mov r2,r0
    st8(c.r[0] + c.r[1], c.r[6]);  // 0601CD0C mov.b r6,@(r0,r1)
    c.r[0] = 0x3u;  // 0601CD0E mov #3,r0
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0601CD10 mov.b @r7,r5
    c.r[1] = ld32(0x0601CD4Cu);  // 0601CD12 mov.l 0x0601CD4C,r1
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0601CD14 mov.w @r3,r6
    c.r[5] = c.r[5] & 0xFFu;  // 0601CD16 extu.b r5,r5
    c.r[2] = c.r[5];  // 0601CD18 mov r5,r2
    c.r[2] >>= 2;  // 0601CD1A shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 0601CD1C shlr r2
    c.r[2] &= c.r[0];  // 0601CD1E and r0,r2
    c.r[6] = c.r[6] & 0xFFFFu;  // 0601CD20 extu.w r6,r6
    c.r[5] >>= 2;  // 0601CD22 shlr2 r5
    c.r[5] >>= 2;  // 0601CD24 shlr2 r5
    c.t = c.r[5] & 1; c.r[5] >>= 1;  // 0601CD26 shlr r5
    c.r[5] >>= 2;  // 0601CD28 shlr2 r5
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601CD2A mov.l r14,@-r15
    c.r[7] = c.r[2];  // 0601CD2C mov r2,r7
L_0601CD2E:
    { const uint32_t x = c.r[1]; c.pr = 0x0601CD32u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601CD32u) return; }  // 0601CD2E jsr @r1 ; nop
    c.r[3] = (uint32_t)(int16_t)ld16(0x0601CD42u);  // 0601CD32 mov.w 0x0601CD42,r3
    c.r[14] += c.r[3];  // 0601CD34 add r3,r14
    c.r[15] = c.r[14];  // 0601CD36 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601CD38 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601CD3A mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601CD3C rts ; mov.l @r15+,r8
}

void f_0601CD58(SH2Context& c) {
    ran[310] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601CD58 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601CD5A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601CD5C sts.l pr,@-r15
    c.r[15] -= 128;  // 0601CD5E add #-128,r15
    c.r[14] = c.r[15];  // 0601CD60 mov r15,r14
    c.r[8] = ld32(0x0601CE28u);  // 0601CD62 mov.l 0x0601CE28,r8
    c.r[0] = ld32(0x0601CE2Cu);  // 0601CD64 mov.l 0x0601CE2C,r0
    c.r[6] = 0x1u;  // 0601CD66 mov #1,r6
    c.r[4] = ld32(c.r[8]);  // 0601CD68 mov.l @r8,r4
    { const uint32_t x = c.r[0]; c.pr = 0x0601CD6Eu; c.r[5] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601CD6Eu) return; }  // 0601CD6A jsr @r0 ; mov r14,r5
    st32(c.r[8], c.r[0]);  // 0601CD6E mov.l r0,@r8
    c.r[1] = c.r[8];  // 0601CD70 mov r8,r1
    c.r[1] += 10;  // 0601CD72 add #10,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601CD74 mov.b @r1,r1
    c.r[7] = c.r[1] & 0xFFu;  // 0601CD76 extu.b r1,r7
    c.r[3] = c.r[7];  // 0601CD78 mov r7,r3
    c.r[3] >>= 2;  // 0601CD7A shlr2 r3
    c.r[3] >>= 2;  // 0601CD7C shlr2 r3
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 0601CD7E shlr r3
    c.r[3] >>= 2;  // 0601CD80 shlr2 r3
    c.r[0] = c.r[3];  // 0601CD82 mov r3,r0
    c.r[0] += c.r[0];  // 0601CD84 add r0,r0
    c.r[1] = ld32(0x0601CE30u);  // 0601CD86 mov.l 0x0601CE30,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0601CD88 mov.w @(r0,r1),r2
    c.r[8] += 8;  // 0601CD8A add #8,r8
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[8]);  // 0601CD8C mov.w @r8,r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 0601CD8E extu.w r2,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 0601CD90 extu.w r1,r1
    c.t = c.r[2] == c.r[1];  // 0601CD92 cmp/eq r1,r2
    { const bool k = !c.t; c.r[0] = c.r[3]; if (k) { goto L_0601CDB8; } }  // 0601CD94 bf/s 0x0601CDB8 ; mov r3,r0
    c.r[1] = ld32(0x0601CE34u);  // 0601CD98 mov.l 0x0601CE34,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601CD9A mov.b @(r0,r1),r1
    c.r[7] >>= 2;  // 0601CD9C shlr2 r7
    c.t = c.r[7] & 1; c.r[7] >>= 1;  // 0601CD9E shlr r7
    c.r[1] = c.r[1] & 0xFFu;  // 0601CDA0 extu.b r1,r1
    c.r[0] = 0x3u;  // 0601CDA2 mov #3,r0
    c.r[7] &= c.r[0];  // 0601CDA4 and r0,r7
    c.t = c.r[1] == c.r[7];  // 0601CDA6 cmp/eq r7,r1
    if (!c.t) { goto L_0601CDB8; }  // 0601CDA8 bf 0x0601CDB8
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601CDAA mov.l r14,@-r15
    c.r[1] = ld32(0x0601CE38u);  // 0601CDAC mov.l 0x0601CE38,r1
    c.r[7] = 0x0u;  // 0601CDAE mov #0,r7
    c.r[6] = 0x0u;  // 0601CDB0 mov #0,r6
    c.r[5] = c.r[3];  // 0601CDB2 mov r3,r5
    c.r[4] = 0x2u; goto L_0601CE14;  // 0601CDB4 bra 0x0601CE14 ; mov #2,r4
L_0601CDB8:
    c.r[3] = ld32(0x0601CE28u);  // 0601CDB8 mov.l 0x0601CE28,r3
    c.r[7] = c.r[3];  // 0601CDBA mov r3,r7
    c.r[7] += 10;  // 0601CDBC add #10,r7
    c.r[0] = 0x2u;  // 0601CDBE mov #2,r0
    c.r[2] = ld32(0x0601CE30u);  // 0601CDC0 mov.l 0x0601CE30,r2
    c.r[3] += 8;  // 0601CDC2 add #8,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0601CDC4 mov.b @r7,r1
    c.r[4] = 0x2u;  // 0601CDC6 mov #2,r4
    c.r[6] = c.r[1];  // 0601CDC8 mov r1,r6
    c.r[6] >>= 2;  // 0601CDCA shlr2 r6
    c.r[6] >>= 2;  // 0601CDCC shlr2 r6
    c.r[6] >>= 2;  // 0601CDCE shlr2 r6
    c.r[6] &= c.r[0];  // 0601CDD0 and r0,r6
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0601CDD2 mov.w @r3,r1
    c.r[0] = c.r[6];  // 0601CDD4 mov r6,r0
    st16(c.r[0] + c.r[2], c.r[1]);  // 0601CDD6 mov.w r1,@(r0,r2)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0601CDD8 mov.b @r7,r1
    c.r[0] = 0x3u;  // 0601CDDA mov #3,r0
    c.r[6] = c.r[1] & 0xFFu;  // 0601CDDC extu.b r1,r6
    c.r[2] = c.r[6];  // 0601CDDE mov r6,r2
    c.r[2] >>= 2;  // 0601CDE0 shlr2 r2
    c.r[2] >>= 2;  // 0601CDE2 shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 0601CDE4 shlr r2
    c.r[2] >>= 2;  // 0601CDE6 shlr2 r2
    c.r[1] = ld32(0x0601CE34u);  // 0601CDE8 mov.l 0x0601CE34,r1
    c.r[6] >>= 2;  // 0601CDEA shlr2 r6
    c.t = c.r[6] & 1; c.r[6] >>= 1;  // 0601CDEC shlr r6
    c.r[6] &= c.r[0];  // 0601CDEE and r0,r6
    c.r[0] = c.r[2];  // 0601CDF0 mov r2,r0
    st8(c.r[0] + c.r[1], c.r[6]);  // 0601CDF2 mov.b r6,@(r0,r1)
    c.r[0] = 0x3u;  // 0601CDF4 mov #3,r0
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0601CDF6 mov.b @r7,r5
    c.r[1] = ld32(0x0601CE38u);  // 0601CDF8 mov.l 0x0601CE38,r1
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0601CDFA mov.w @r3,r6
    c.r[5] = c.r[5] & 0xFFu;  // 0601CDFC extu.b r5,r5
    c.r[2] = c.r[5];  // 0601CDFE mov r5,r2
    c.r[2] >>= 2;  // 0601CE00 shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 0601CE02 shlr r2
    c.r[2] &= c.r[0];  // 0601CE04 and r0,r2
    c.r[6] = c.r[6] & 0xFFFFu;  // 0601CE06 extu.w r6,r6
    c.r[5] >>= 2;  // 0601CE08 shlr2 r5
    c.r[5] >>= 2;  // 0601CE0A shlr2 r5
    c.t = c.r[5] & 1; c.r[5] >>= 1;  // 0601CE0C shlr r5
    c.r[5] >>= 2;  // 0601CE0E shlr2 r5
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601CE10 mov.l r14,@-r15
    c.r[7] = c.r[2];  // 0601CE12 mov r2,r7
L_0601CE14:
    { const uint32_t x = c.r[1]; c.pr = 0x0601CE18u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601CE18u) return; }  // 0601CE14 jsr @r1 ; nop
    c.r[3] = (uint32_t)(int16_t)ld16(0x0601CE26u);  // 0601CE18 mov.w 0x0601CE26,r3
    c.r[14] += c.r[3];  // 0601CE1A add r3,r14
    c.r[15] = c.r[14];  // 0601CE1C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601CE1E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601CE20 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601CE22 rts ; mov.l @r15+,r8
}

void f_0601CE3C(SH2Context& c) {
    ran[311] = 1;
    c.t = (ld8(c.gbr + c.r[0]) & 0xCCu) == 0;  // 0601CE3C tst.b #204,@(r0,gbr)
    c.t = (ld8(c.gbr + c.r[0]) & 0xCDu) == 0;  // 0601CE3E tst.b #205,@(r0,gbr)
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601CE40 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0601CE42 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0601CE44 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0601CE46 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0601CE48 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0601CE4A mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601CE4C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601CE4E sts.l pr,@-r15
    c.r[15] -= 8;  // 0601CE50 add #-8,r15
    c.r[14] = c.r[15];  // 0601CE52 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0601CE54 mov.l r4,@r14
    c.r[10] = c.r[5];  // 0601CE56 mov r5,r10
    st32(c.r[14] + 4, c.r[6]);  // 0601CE58 mov.l r6,@(4,r14)
    c.r[12] = 0x0u;  // 0601CE5A mov #0,r12
    c.r[13] = 0x0u;  // 0601CE5C mov #0,r13
    c.r[8] = 0x0u;  // 0601CE5E mov #0,r8
    c.r[11] = 0x0u;  // 0601CE60 mov #0,r11
    c.r[9] = ld32(c.r[14]);  // 0601CE62 mov.l @r14,r9
L_0601CE64:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0601CE64 mov.b @r9,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0601CF4Au);  // 0601CE66 mov.w 0x0601CF4A,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0601CE68 extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 0601CE6A cmp/eq r2,r1
    { const bool k = !c.t; c.r[5] = c.r[10]; if (k) { goto L_0601CE84; } }  // 0601CE6C bf/s 0x0601CE84 ; mov r10,r5
    c.r[5] += c.r[8];  // 0601CE70 add r8,r5
    c.r[1] = c.r[9];  // 0601CE72 mov r9,r1
    c.r[1] += 1;  // 0601CE74 add #1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601CE76 mov.b @r1,r4
    c.r[0] = ld32(0x0601CF58u);  // 0601CE78 mov.l 0x0601CF58,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601CE7Eu; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601CE7Eu) return; }  // 0601CE7A jsr @r0 ; extu.b r4,r4
    c.r[8] += c.r[0];  // 0601CE7E add r0,r8
    c.r[9] += 2;  // 0601CE80 add #2,r9
    c.r[11] += 2;  // 0601CE82 add #2,r11
L_0601CE84:
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0601CE84 mov.b @r9,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601CF4Cu);  // 0601CE86 mov.w 0x0601CF4C,r0
    c.r[2] = c.r[3] & 0xFFu;  // 0601CE88 extu.b r3,r2
    c.t = c.r[2] == c.r[0];  // 0601CE8A cmp/eq r0,r2
    if (!c.t) { goto L_0601CEAC; }  // 0601CE8C bf 0x0601CEAC
    c.r[13] += 1;  // 0601CE8E add #1,r13
    c.r[1] = 0x2u;  // 0601CE90 mov #2,r1
    c.t = (int32_t)c.r[13] > (int32_t)c.r[1];  // 0601CE92 cmp/gt r1,r13
    { const bool k = c.t; c.r[1] = 0xFFFFFFFFu; if (k) { goto L_0601CF1A; } }  // 0601CE94 bt/s 0x0601CF1A ; mov #-1,r1
    c.r[0] = ld32(c.r[14] + 4);  // 0601CE98 mov.l @(4,r14),r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601CE9A tst r0,r0
    { const bool k = c.t; c.r[0] = c.r[10]; if (k) { goto L_0601CEA8; } }  // 0601CE9C bt/s 0x0601CEA8 ; mov r10,r0
    st8(c.r[0] + c.r[8], c.r[2]);  // 0601CEA0 mov.b r2,@(r0,r8)
    c.r[8] += 1;  // 0601CEA2 add #1,r8
    c.r[1] = 0x0u; goto L_0601CF76;  // 0601CEA4 bra 0x0601CF76 ; mov #0,r1
L_0601CEA8:
    st8(c.r[0] + c.r[8], c.r[2]); goto L_0601CF78;  // 0601CEA8 bra 0x0601CF78 ; mov.b r2,@(r0,r8)
L_0601CEAC:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601CF4Eu);  // 0601CEAC mov.w 0x0601CF4E,r1
    c.t = c.r[2] == c.r[1];  // 0601CEAE cmp/eq r1,r2
    if (!c.t) { goto L_0601CF12; }  // 0601CEB0 bf 0x0601CF12
    c.r[9] += 1;  // 0601CEB2 add #1,r9
    c.r[1] = ld32(0x0601CF5Cu);  // 0601CEB4 mov.l 0x0601CF5C,r1
    c.r[2] = ld32(c.r[1] + 12);  // 0601CEB6 mov.l @(12,r1),r2
    c.r[3] = ld32(0x0601CF60u);  // 0601CEB8 mov.l 0x0601CF60,r3
    c.t = (c.r[2] & c.r[2]) == 0;  // 0601CEBA tst r2,r2
    { const bool k = !c.t; c.r[11] += 1; if (k) { goto L_0601CEC6; } }  // 0601CEBC bf/s 0x0601CEC6 ; add #1,r11
    c.r[1] = 0x30u;  // 0601CEC0 mov #48,r1
    c.r[0] = c.r[10]; goto L_0601CF76;  // 0601CEC2 bra 0x0601CF76 ; mov r10,r0
L_0601CEC6:
    c.t = (int32_t)c.r[2] >= 0;  // 0601CEC6 cmp/pz r2
    { const bool k = c.t; c.r[1] = 0x11u; if (k) { goto L_0601CED6; } }  // 0601CEC8 bt/s 0x0601CED6 ; mov #17,r1
    c.r[0] = c.r[10];  // 0601CECC mov r10,r0
    st8(c.r[0] + c.r[8], c.r[1]);  // 0601CECE mov.b r1,@(r0,r8)
    c.r[8] += 1;  // 0601CED0 add #1,r8
    c.r[2] = ~c.r[2];  // 0601CED2 not r2,r2
    c.r[2] += 1;  // 0601CED4 add #1,r2
L_0601CED6:
    c.r[6] = ld32(0x0601CF64u);  // 0601CED6 mov.l 0x0601CF64,r6
    c.r[1] = ld32(0x0601CF68u);  // 0601CED8 mov.l 0x0601CF68,r1
    c.r[7] = ld32(c.r[1]);  // 0601CEDA mov.l @r1,r7
L_0601CEDC:
    c.r[4] = c.r[2];  // 0601CEDC mov r2,r4
    { const uint32_t x = c.r[6]; c.pr = 0x0601CEE2u; c.r[5] = c.r[3]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601CEE2u) return; }  // 0601CEDE jsr @r6 ; mov r3,r5
    c.r[5] = c.r[0];  // 0601CEE2 mov r0,r5
    c.macl = c.r[5] * c.r[3];  // 0601CEE4 mul.l r3,r5
    c.r[4] = c.r[2];  // 0601CEE6 mov r2,r4
    c.t = (c.r[5] & c.r[5]) == 0;  // 0601CEE8 tst r5,r5
    c.r[1] = c.macl;  // 0601CEEA sts macl,r1
    { const bool k = !c.t; c.r[4] -= c.r[1]; if (k) { goto L_0601CEF8; } }  // 0601CEEC bf/s 0x0601CEF8 ; sub r1,r4
    c.r[0] = c.r[3];  // 0601CEF0 mov r3,r0
    c.t = c.r[0] == 0x1u;  // 0601CEF2 cmp/eq #1,r0
    { const bool k = !c.t; { uint64_t p = (uint64_t)c.r[3] * c.r[7]; c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; } if (k) { goto L_0601CF02; } }  // 0601CEF4 bf/s 0x0601CF02 ; dmulu.l r7,r3
L_0601CEF8:
    c.r[5] += 48;  // 0601CEF8 add #48,r5
    c.r[0] = c.r[10];  // 0601CEFA mov r10,r0
    st8(c.r[0] + c.r[8], c.r[5]);  // 0601CEFC mov.b r5,@(r0,r8)
    c.r[8] += 1;  // 0601CEFE add #1,r8
    { uint64_t p = (uint64_t)c.r[3] * c.r[7]; c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 0601CF00 dmulu.l r7,r3
L_0601CF02:
    c.r[3] = c.mach;  // 0601CF02 sts mach,r3
    c.r[3] >>= 2;  // 0601CF04 shlr2 r3
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 0601CF06 shlr r3
    c.t = (c.r[3] & c.r[3]) == 0;  // 0601CF08 tst r3,r3
    { const bool k = !c.t; c.r[2] = c.r[4]; if (k) { SH2_POLL(c); goto L_0601CEDC; } }  // 0601CF0A bf/s 0x0601CEDC ; mov r4,r2
    c.r[8] -= 1; goto L_0601CF78;  // 0601CF0E bra 0x0601CF78 ; add #-1,r8
L_0601CF12:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601CF50u);  // 0601CF12 mov.w 0x0601CF50,r1
    c.t = c.r[2] == c.r[1];  // 0601CF14 cmp/eq r1,r2
    { const bool k = !c.t; c.r[1] = 0xFFFFFFFFu; if (k) { goto L_0601CF2E; } }  // 0601CF16 bf/s 0x0601CF2E ; mov #-1,r1
L_0601CF1A:
    c.r[0] = c.r[10];  // 0601CF1A mov r10,r0
    st8(c.r[0] + c.r[8], c.r[1]);  // 0601CF1C mov.b r1,@(r0,r8)
    c.r[0] = ld32(0x0601CF6Cu);  // 0601CF1E mov.l 0x0601CF6C,r0
    st8(c.r[0], c.r[8]);  // 0601CF20 mov.b r8,@r0
    c.r[0] = ld32(c.r[14]);  // 0601CF22 mov.l @r14,r0
    c.r[11] += 1;  // 0601CF24 add #1,r11
    c.r[0] += c.r[11];  // 0601CF26 add r11,r0
    st32(c.r[14], c.r[0]);  // 0601CF28 mov.l r0,@r14
    c.r[0] = ld32(c.r[14]); goto L_0601CF9C;  // 0601CF2A bra 0x0601CF9C ; mov.l @r14,r0
L_0601CF2E:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601CF52u);  // 0601CF2E mov.w 0x0601CF52,r1
    c.t = c.r[2] == c.r[1];  // 0601CF30 cmp/eq r1,r2
    if (c.t) { goto L_0601CF70; }  // 0601CF32 bt 0x0601CF70
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601CF54u);  // 0601CF34 mov.w 0x0601CF54,r1
    c.t = c.r[2] > c.r[1];  // 0601CF36 cmp/hi r1,r2
    { const bool k = !c.t; c.r[0] = c.r[10]; if (k) { goto L_0601CF70; } }  // 0601CF38 bf/s 0x0601CF70 ; mov r10,r0
    st8(c.r[0] + c.r[8], c.r[3]);  // 0601CF3C mov.b r3,@(r0,r8)
    c.r[9] += 1;  // 0601CF3E add #1,r9
    c.r[11] += 1;  // 0601CF40 add #1,r11
    c.r[8] += 1;  // 0601CF42 add #1,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0601CF44 mov.b @r9,r1
    c.r[12] = 0x1u; goto L_0601CF76;  // 0601CF46 bra 0x0601CF76 ; mov #1,r12
L_0601CF70:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0601CF70 mov.b @r9,r1
    c.r[0] = c.r[10];  // 0601CF72 mov r10,r0
    c.r[12] = 0x0u;  // 0601CF74 mov #0,r12
L_0601CF76:
    st8(c.r[0] + c.r[8], c.r[1]);  // 0601CF76 mov.b r1,@(r0,r8)
L_0601CF78:
    c.r[9] += 1;  // 0601CF78 add #1,r9
    c.r[11] += 1;  // 0601CF7A add #1,r11
    c.r[0] = c.r[10];  // 0601CF7C mov r10,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0601CF7E mov.b @(r0,r8),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0601CFB2u);  // 0601CF80 mov.w 0x0601CFB2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0601CF82 extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 0601CF84 cmp/eq r2,r1
    { const bool k = c.t; c.r[8] += 1; if (k) { goto L_0601CF8E; } }  // 0601CF86 bt/s 0x0601CF8E ; add #1,r8
    SH2_POLL(c); goto L_0601CE64;  // 0601CF8A bra 0x0601CE64 ; nop
L_0601CF8E:
    c.t = (c.r[12] & c.r[12]) == 0;  // 0601CF8E tst r12,r12
    { const bool k = c.t; c.r[0] = 0xFFFFFFFFu; if (k) { goto L_0601CF98; } }  // 0601CF90 bt/s 0x0601CF98 ; mov #-1,r0
    SH2_POLL(c); goto L_0601CE64;  // 0601CF94 bra 0x0601CE64 ; nop
L_0601CF98:
    c.r[1] = ld32(0x0601CFB4u);  // 0601CF98 mov.l 0x0601CFB4,r1
    st8(c.r[1], c.r[8]);  // 0601CF9A mov.b r8,@r1
L_0601CF9C:
    c.r[14] += 8;  // 0601CF9C add #8,r14
    c.r[15] = c.r[14];  // 0601CF9E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601CFA0 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601CFA2 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0601CFA4 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0601CFA6 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0601CFA8 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0601CFAA mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0601CFAC mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601CFAE rts ; mov.l @r15+,r8
}

void f_0601CE40(SH2Context& c) {
    ran[312] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601CE40 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0601CE42 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0601CE44 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0601CE46 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0601CE48 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0601CE4A mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601CE4C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601CE4E sts.l pr,@-r15
    c.r[15] -= 8;  // 0601CE50 add #-8,r15
    c.r[14] = c.r[15];  // 0601CE52 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0601CE54 mov.l r4,@r14
    c.r[10] = c.r[5];  // 0601CE56 mov r5,r10
    st32(c.r[14] + 4, c.r[6]);  // 0601CE58 mov.l r6,@(4,r14)
    c.r[12] = 0x0u;  // 0601CE5A mov #0,r12
    c.r[13] = 0x0u;  // 0601CE5C mov #0,r13
    c.r[8] = 0x0u;  // 0601CE5E mov #0,r8
    c.r[11] = 0x0u;  // 0601CE60 mov #0,r11
    c.r[9] = ld32(c.r[14]);  // 0601CE62 mov.l @r14,r9
L_0601CE64:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0601CE64 mov.b @r9,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0601CF4Au);  // 0601CE66 mov.w 0x0601CF4A,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0601CE68 extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 0601CE6A cmp/eq r2,r1
    { const bool k = !c.t; c.r[5] = c.r[10]; if (k) { goto L_0601CE84; } }  // 0601CE6C bf/s 0x0601CE84 ; mov r10,r5
    c.r[5] += c.r[8];  // 0601CE70 add r8,r5
    c.r[1] = c.r[9];  // 0601CE72 mov r9,r1
    c.r[1] += 1;  // 0601CE74 add #1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601CE76 mov.b @r1,r4
    c.r[0] = ld32(0x0601CF58u);  // 0601CE78 mov.l 0x0601CF58,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601CE7Eu; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601CE7Eu) return; }  // 0601CE7A jsr @r0 ; extu.b r4,r4
    c.r[8] += c.r[0];  // 0601CE7E add r0,r8
    c.r[9] += 2;  // 0601CE80 add #2,r9
    c.r[11] += 2;  // 0601CE82 add #2,r11
L_0601CE84:
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0601CE84 mov.b @r9,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601CF4Cu);  // 0601CE86 mov.w 0x0601CF4C,r0
    c.r[2] = c.r[3] & 0xFFu;  // 0601CE88 extu.b r3,r2
    c.t = c.r[2] == c.r[0];  // 0601CE8A cmp/eq r0,r2
    if (!c.t) { goto L_0601CEAC; }  // 0601CE8C bf 0x0601CEAC
    c.r[13] += 1;  // 0601CE8E add #1,r13
    c.r[1] = 0x2u;  // 0601CE90 mov #2,r1
    c.t = (int32_t)c.r[13] > (int32_t)c.r[1];  // 0601CE92 cmp/gt r1,r13
    { const bool k = c.t; c.r[1] = 0xFFFFFFFFu; if (k) { goto L_0601CF1A; } }  // 0601CE94 bt/s 0x0601CF1A ; mov #-1,r1
    c.r[0] = ld32(c.r[14] + 4);  // 0601CE98 mov.l @(4,r14),r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601CE9A tst r0,r0
    { const bool k = c.t; c.r[0] = c.r[10]; if (k) { goto L_0601CEA8; } }  // 0601CE9C bt/s 0x0601CEA8 ; mov r10,r0
    st8(c.r[0] + c.r[8], c.r[2]);  // 0601CEA0 mov.b r2,@(r0,r8)
    c.r[8] += 1;  // 0601CEA2 add #1,r8
    c.r[1] = 0x0u; goto L_0601CF76;  // 0601CEA4 bra 0x0601CF76 ; mov #0,r1
L_0601CEA8:
    st8(c.r[0] + c.r[8], c.r[2]); goto L_0601CF78;  // 0601CEA8 bra 0x0601CF78 ; mov.b r2,@(r0,r8)
L_0601CEAC:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601CF4Eu);  // 0601CEAC mov.w 0x0601CF4E,r1
    c.t = c.r[2] == c.r[1];  // 0601CEAE cmp/eq r1,r2
    if (!c.t) { goto L_0601CF12; }  // 0601CEB0 bf 0x0601CF12
    c.r[9] += 1;  // 0601CEB2 add #1,r9
    c.r[1] = ld32(0x0601CF5Cu);  // 0601CEB4 mov.l 0x0601CF5C,r1
    c.r[2] = ld32(c.r[1] + 12);  // 0601CEB6 mov.l @(12,r1),r2
    c.r[3] = ld32(0x0601CF60u);  // 0601CEB8 mov.l 0x0601CF60,r3
    c.t = (c.r[2] & c.r[2]) == 0;  // 0601CEBA tst r2,r2
    { const bool k = !c.t; c.r[11] += 1; if (k) { goto L_0601CEC6; } }  // 0601CEBC bf/s 0x0601CEC6 ; add #1,r11
    c.r[1] = 0x30u;  // 0601CEC0 mov #48,r1
    c.r[0] = c.r[10]; goto L_0601CF76;  // 0601CEC2 bra 0x0601CF76 ; mov r10,r0
L_0601CEC6:
    c.t = (int32_t)c.r[2] >= 0;  // 0601CEC6 cmp/pz r2
    { const bool k = c.t; c.r[1] = 0x11u; if (k) { goto L_0601CED6; } }  // 0601CEC8 bt/s 0x0601CED6 ; mov #17,r1
    c.r[0] = c.r[10];  // 0601CECC mov r10,r0
    st8(c.r[0] + c.r[8], c.r[1]);  // 0601CECE mov.b r1,@(r0,r8)
    c.r[8] += 1;  // 0601CED0 add #1,r8
    c.r[2] = ~c.r[2];  // 0601CED2 not r2,r2
    c.r[2] += 1;  // 0601CED4 add #1,r2
L_0601CED6:
    c.r[6] = ld32(0x0601CF64u);  // 0601CED6 mov.l 0x0601CF64,r6
    c.r[1] = ld32(0x0601CF68u);  // 0601CED8 mov.l 0x0601CF68,r1
    c.r[7] = ld32(c.r[1]);  // 0601CEDA mov.l @r1,r7
L_0601CEDC:
    c.r[4] = c.r[2];  // 0601CEDC mov r2,r4
    { const uint32_t x = c.r[6]; c.pr = 0x0601CEE2u; c.r[5] = c.r[3]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601CEE2u) return; }  // 0601CEDE jsr @r6 ; mov r3,r5
    c.r[5] = c.r[0];  // 0601CEE2 mov r0,r5
    c.macl = c.r[5] * c.r[3];  // 0601CEE4 mul.l r3,r5
    c.r[4] = c.r[2];  // 0601CEE6 mov r2,r4
    c.t = (c.r[5] & c.r[5]) == 0;  // 0601CEE8 tst r5,r5
    c.r[1] = c.macl;  // 0601CEEA sts macl,r1
    { const bool k = !c.t; c.r[4] -= c.r[1]; if (k) { goto L_0601CEF8; } }  // 0601CEEC bf/s 0x0601CEF8 ; sub r1,r4
    c.r[0] = c.r[3];  // 0601CEF0 mov r3,r0
    c.t = c.r[0] == 0x1u;  // 0601CEF2 cmp/eq #1,r0
    { const bool k = !c.t; { uint64_t p = (uint64_t)c.r[3] * c.r[7]; c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; } if (k) { goto L_0601CF02; } }  // 0601CEF4 bf/s 0x0601CF02 ; dmulu.l r7,r3
L_0601CEF8:
    c.r[5] += 48;  // 0601CEF8 add #48,r5
    c.r[0] = c.r[10];  // 0601CEFA mov r10,r0
    st8(c.r[0] + c.r[8], c.r[5]);  // 0601CEFC mov.b r5,@(r0,r8)
    c.r[8] += 1;  // 0601CEFE add #1,r8
    { uint64_t p = (uint64_t)c.r[3] * c.r[7]; c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 0601CF00 dmulu.l r7,r3
L_0601CF02:
    c.r[3] = c.mach;  // 0601CF02 sts mach,r3
    c.r[3] >>= 2;  // 0601CF04 shlr2 r3
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 0601CF06 shlr r3
    c.t = (c.r[3] & c.r[3]) == 0;  // 0601CF08 tst r3,r3
    { const bool k = !c.t; c.r[2] = c.r[4]; if (k) { SH2_POLL(c); goto L_0601CEDC; } }  // 0601CF0A bf/s 0x0601CEDC ; mov r4,r2
    c.r[8] -= 1; goto L_0601CF78;  // 0601CF0E bra 0x0601CF78 ; add #-1,r8
L_0601CF12:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601CF50u);  // 0601CF12 mov.w 0x0601CF50,r1
    c.t = c.r[2] == c.r[1];  // 0601CF14 cmp/eq r1,r2
    { const bool k = !c.t; c.r[1] = 0xFFFFFFFFu; if (k) { goto L_0601CF2E; } }  // 0601CF16 bf/s 0x0601CF2E ; mov #-1,r1
L_0601CF1A:
    c.r[0] = c.r[10];  // 0601CF1A mov r10,r0
    st8(c.r[0] + c.r[8], c.r[1]);  // 0601CF1C mov.b r1,@(r0,r8)
    c.r[0] = ld32(0x0601CF6Cu);  // 0601CF1E mov.l 0x0601CF6C,r0
    st8(c.r[0], c.r[8]);  // 0601CF20 mov.b r8,@r0
    c.r[0] = ld32(c.r[14]);  // 0601CF22 mov.l @r14,r0
    c.r[11] += 1;  // 0601CF24 add #1,r11
    c.r[0] += c.r[11];  // 0601CF26 add r11,r0
    st32(c.r[14], c.r[0]);  // 0601CF28 mov.l r0,@r14
    c.r[0] = ld32(c.r[14]); goto L_0601CF9C;  // 0601CF2A bra 0x0601CF9C ; mov.l @r14,r0
L_0601CF2E:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601CF52u);  // 0601CF2E mov.w 0x0601CF52,r1
    c.t = c.r[2] == c.r[1];  // 0601CF30 cmp/eq r1,r2
    if (c.t) { goto L_0601CF70; }  // 0601CF32 bt 0x0601CF70
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601CF54u);  // 0601CF34 mov.w 0x0601CF54,r1
    c.t = c.r[2] > c.r[1];  // 0601CF36 cmp/hi r1,r2
    { const bool k = !c.t; c.r[0] = c.r[10]; if (k) { goto L_0601CF70; } }  // 0601CF38 bf/s 0x0601CF70 ; mov r10,r0
    st8(c.r[0] + c.r[8], c.r[3]);  // 0601CF3C mov.b r3,@(r0,r8)
    c.r[9] += 1;  // 0601CF3E add #1,r9
    c.r[11] += 1;  // 0601CF40 add #1,r11
    c.r[8] += 1;  // 0601CF42 add #1,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0601CF44 mov.b @r9,r1
    c.r[12] = 0x1u; goto L_0601CF76;  // 0601CF46 bra 0x0601CF76 ; mov #1,r12
L_0601CF70:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0601CF70 mov.b @r9,r1
    c.r[0] = c.r[10];  // 0601CF72 mov r10,r0
    c.r[12] = 0x0u;  // 0601CF74 mov #0,r12
L_0601CF76:
    st8(c.r[0] + c.r[8], c.r[1]);  // 0601CF76 mov.b r1,@(r0,r8)
L_0601CF78:
    c.r[9] += 1;  // 0601CF78 add #1,r9
    c.r[11] += 1;  // 0601CF7A add #1,r11
    c.r[0] = c.r[10];  // 0601CF7C mov r10,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0601CF7E mov.b @(r0,r8),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0601CFB2u);  // 0601CF80 mov.w 0x0601CFB2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0601CF82 extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 0601CF84 cmp/eq r2,r1
    { const bool k = c.t; c.r[8] += 1; if (k) { goto L_0601CF8E; } }  // 0601CF86 bt/s 0x0601CF8E ; add #1,r8
    SH2_POLL(c); goto L_0601CE64;  // 0601CF8A bra 0x0601CE64 ; nop
L_0601CF8E:
    c.t = (c.r[12] & c.r[12]) == 0;  // 0601CF8E tst r12,r12
    { const bool k = c.t; c.r[0] = 0xFFFFFFFFu; if (k) { goto L_0601CF98; } }  // 0601CF90 bt/s 0x0601CF98 ; mov #-1,r0
    SH2_POLL(c); goto L_0601CE64;  // 0601CF94 bra 0x0601CE64 ; nop
L_0601CF98:
    c.r[1] = ld32(0x0601CFB4u);  // 0601CF98 mov.l 0x0601CFB4,r1
    st8(c.r[1], c.r[8]);  // 0601CF9A mov.b r8,@r1
L_0601CF9C:
    c.r[14] += 8;  // 0601CF9C add #8,r14
    c.r[15] = c.r[14];  // 0601CF9E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601CFA0 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601CFA2 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0601CFA4 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0601CFA6 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0601CFA8 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0601CFAA mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0601CFAC mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601CFAE rts ; mov.l @r15+,r8
}

void f_0601CFB8(SH2Context& c) {
    ran[313] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601CFB8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601CFBA mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0601CFBC mov r15,r14
    c.r[4] = c.r[4] & 0xFFu;  // 0601CFBE extu.b r4,r4
    c.r[0] = c.r[4];  // 0601CFC0 mov r4,r0
    c.t = c.r[0] == 0x3u;  // 0601CFC2 cmp/eq #3,r0
    if (c.t) { goto L_0601D030; }  // 0601CFC4 bt 0x0601D030
    c.t = c.r[0] == 0x4u;  // 0601CFC6 cmp/eq #4,r0
    if (c.t) { goto L_0601D04A; }  // 0601CFC8 bt 0x0601D04A
    c.r[0] = 0xAu;  // 0601CFCA mov #10,r0
    c.t = c.r[4] > c.r[0];  // 0601CFCC cmp/hi r0,r4
    { const bool k = c.t; c.r[0] -= 3; if (k) { goto L_0601D04A; } }  // 0601CFCE bt/s 0x0601D04A ; add #-3,r0
    c.t = c.r[4] > c.r[0];  // 0601CFD2 cmp/hi r0,r4
    if (c.t) { goto L_0601D04E; }  // 0601CFD4 bt 0x0601D04E
    c.r[7] = 0x42u;  // 0601CFD6 mov #66,r7
    c.r[0] = 0x4u;  // 0601CFD8 mov #4,r0
    c.t = c.r[4] > c.r[0];  // 0601CFDA cmp/hi r0,r4
    if (!c.t) { goto L_0601CFE2; }  // 0601CFDC bf 0x0601CFE2
    c.r[4] -= 5;  // 0601CFDE add #-5,r4
    c.r[7] += 1;  // 0601CFE0 add #1,r7
L_0601CFE2:
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601CFE2 sts.l pr,@-r15
    c.pr = 0x0601CFE8u; c.r[8] = c.r[4]; SH2_POLL(c); sh2_call(c, 0x0601D05Cu); if (c.pc != 0x0601CFE8u) return;  // 0601CFE4 bsr 0x0601D05C ; mov r4,r8
    c.r[6] = c.r[3];  // 0601CFE8 mov r3,r6
    c.r[6] += 14;  // 0601CFEA add #14,r6
    c.r[7] = c.r[3];  // 0601CFEC mov r3,r7
    c.r[2] = 0xFFFFFFEAu;  // 0601CFEE mov #-22,r2
    if (c.t) { goto L_0601D01C; }  // 0601CFF0 bt 0x0601D01C
    c.r[0] = c.r[8];  // 0601CFF2 mov r8,r0
    c.t = c.r[0] == 0x2u;  // 0601CFF4 cmp/eq #2,r0
    if (c.t) { goto L_0601D018; }  // 0601CFF6 bt 0x0601D018
L_0601CFF8:
    c.t = c.r[3] >= c.r[6];  // 0601CFF8 cmp/hs r6,r3
    if (c.t) { goto L_0601D01A; }  // 0601CFFA bt 0x0601D01A
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]); c.r[3] += 1;  // 0601CFFC mov.b @r3+,r0
    c.t = c.r[0] == 0x0u;  // 0601CFFE cmp/eq #0,r0
    if (c.t) { goto L_0601D00E; }  // 0601D000 bt 0x0601D00E
    c.t = c.r[0] == 0xFFFFFFE3u;  // 0601D002 cmp/eq #-29,r0
    if (c.t) { goto L_0601D00E; }  // 0601D004 bt 0x0601D00E
    c.t = c.r[0] > c.r[2];  // 0601D006 cmp/hi r2,r0
    if (!c.t) { SH2_POLL(c); goto L_0601CFF8; }  // 0601D008 bf 0x0601CFF8
    c.r[3] += 1; SH2_POLL(c); goto L_0601CFF8;  // 0601D00A bra 0x0601CFF8 ; add #1,r3
L_0601D00E:
    c.t = (c.r[8] & c.r[8]) == 0;  // 0601D00E tst r8,r8
    if (c.t) { goto L_0601D01C; }  // 0601D010 bt 0x0601D01C
    c.r[3] -= 1;  // 0601D012 add #-1,r3
    c.r[6] = c.r[3]; goto L_0601D01A;  // 0601D014 bra 0x0601D01A ; mov r3,r6
L_0601D018:
    c.r[6] -= 8;  // 0601D018 add #-8,r6
L_0601D01A:
    c.r[3] = c.r[7];  // 0601D01A mov r7,r3
L_0601D01C:
    c.r[4] = 0xFFFFFFFFu;  // 0601D01C mov #-1,r4
    c.r[1] = ld32(0x0601D054u);  // 0601D01E mov.l 0x0601D054,r1
    c.t = c.r[3] >= c.r[6];  // 0601D020 cmp/hs r6,r3
    if (!c.t) { goto L_0601D026; }  // 0601D022 bf 0x0601D026
    c.r[1] += 28;  // 0601D024 add #28,r1
L_0601D026:
    { const uint32_t x = c.r[1]; c.pr = 0x0601D02Au; c.r[0] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601D02Au) return; }  // 0601D026 jsr @r1 ; mov #0,r0
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601D02A lds.l @r15+,pr
    c.r[7] = c.r[0]; goto L_0601D1E4;  // 0601D02C bra 0x0601D1E4 ; mov r0,r7
L_0601D030:
    c.r[1] = ld32(0x0601D1F4u);  // 0601D030 mov.l 0x0601D1F4,r1
    c.r[1] = ld32(c.r[1]);  // 0601D032 mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601D1F0u);  // 0601D034 mov.w 0x0601D1F0,r0
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601D036 mov.b @(r0,r1),r0
    c.t = (c.r[0] & 0x40u) == 0;  // 0601D038 tst #64,r0
    c.r[3] = ld32(0x0601D058u);  // 0601D03A mov.l 0x0601D058,r3
    if (c.t) { goto L_0601D040; }  // 0601D03C bt 0x0601D040
    c.r[3] += 3;  // 0601D03E add #3,r3
L_0601D040:
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601D040 sts.l pr,@-r15
    c.r[6] = c.r[3];  // 0601D042 mov r3,r6
    c.r[6] += 14;  // 0601D044 add #14,r6
    c.r[2] = 0xFFFFFFEAu; SH2_POLL(c); goto L_0601D01C;  // 0601D046 bra 0x0601D01C ; mov #-22,r2
L_0601D04A:
    c.r[7] = 0x0u; goto L_0601D162;  // 0601D04A bra 0x0601D162 ; mov #0,r7
L_0601D04E:
    c.r[8] = c.r[4];  // 0601D04E mov r4,r8
    c.r[8] -= 8; goto L_0601D1AC;  // 0601D050 bra 0x0601D1AC ; add #-8,r8
L_0601D162:
    c.r[1] = ld32(0x0601D1F4u);  // 0601D162 mov.l 0x0601D1F4,r1
    c.r[1] = ld32(c.r[1]);  // 0601D164 mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601D1F0u);  // 0601D166 mov.w 0x0601D1F0,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601D168 mov.b @(r0,r1),r1
    c.r[0] = c.r[1];  // 0601D16A mov r1,r0
    c.r[0] >>= 2;  // 0601D16C shlr2 r0
    c.r[0] >>= 2;  // 0601D16E shlr2 r0
    c.r[0] >>= 2;  // 0601D170 shlr2 r0
    c.r[0] &= 0x1u;  // 0601D172 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601D174 tst r0,r0
    if (c.t) { goto L_0601D184; }  // 0601D176 bt 0x0601D184
    c.r[7] += 2;  // 0601D178 add #2,r7
    c.r[1] = ld32(0x0601D200u);  // 0601D17A mov.l 0x0601D200,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0601D17C mov.b @r1+,r2
    st8(c.r[5], c.r[2]);  // 0601D17E mov.b r2,@r5
    c.r[2] = c.r[5]; goto L_0601D19A;  // 0601D180 bra 0x0601D19A ; mov r5,r2
L_0601D184:
    c.r[1] = ld32(0x0601D204u);  // 0601D184 mov.l 0x0601D204,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0601D186 mov.b @r1+,r2
    c.r[7] += 4;  // 0601D188 add #4,r7
    st8(c.r[5], c.r[2]);  // 0601D18A mov.b r2,@r5
    c.r[2] = c.r[5];  // 0601D18C mov r5,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0601D18E mov.b @r1+,r3
    c.r[2] += 1;  // 0601D190 add #1,r2
    st8(c.r[2], c.r[3]);  // 0601D192 mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0601D194 mov.b @r1+,r3
    c.r[2] += 1;  // 0601D196 add #1,r2
    st8(c.r[2], c.r[3]);  // 0601D198 mov.b r3,@r2
L_0601D19A:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601D19A mov.b @r1,r1
    c.r[2] += 1;  // 0601D19C add #1,r2
    st8(c.r[2], c.r[1]); goto L_0601D1AC;  // 0601D19E bra 0x0601D1AC ; mov.b r1,@r2
L_0601D1AC:
    c.r[0] = c.r[8];  // 0601D1AC mov r8,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0601D1AE cmp/eq #-1,r0
    { const bool k = c.t; c.r[15] = c.r[14]; if (k) { goto L_0601D1E4; } }  // 0601D1B0 bt/s 0x0601D1E4 ; mov r14,r15
    c.r[1] = ld32(0x0601D1F4u);  // 0601D1B4 mov.l 0x0601D1F4,r1
    c.r[3] = c.r[8];  // 0601D1B6 mov r8,r3
    c.r[3] <<= 2;  // 0601D1B8 shll2 r3
    c.r[3] += c.r[8];  // 0601D1BA add r8,r3
    c.r[3] += c.r[3];  // 0601D1BC add r3,r3
    c.r[2] = (uint32_t)(int16_t)ld16(0x0601D1F2u);  // 0601D1BE mov.w 0x0601D1F2,r2
    c.r[3] += c.r[2];  // 0601D1C0 add r2,r3
    c.r[6] = ld32(c.r[1]);  // 0601D1C2 mov.l @r1,r6
    c.r[7] = 0x0u;  // 0601D1C4 mov #0,r7
    c.r[4] = 0x9u;  // 0601D1C6 mov #9,r4
    c.r[6] += c.r[3];  // 0601D1C8 add r3,r6
    c.r[3] = (uint32_t)(int16_t)ld16(0x0601D1EEu);  // 0601D1CA mov.w 0x0601D1EE,r3
    c.r[0] = c.r[6];  // 0601D1CC mov r6,r0
L_0601D1CE:
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0601D1CE mov.b @(r0,r7),r2
    c.r[1] = c.r[2] & 0xFFu;  // 0601D1D0 extu.b r2,r1
    c.t = c.r[1] == c.r[3];  // 0601D1D2 cmp/eq r3,r1
    { const bool k = c.t; c.r[0] = c.r[5]; if (k) { goto L_0601D1E2; } }  // 0601D1D4 bt/s 0x0601D1E2 ; mov r5,r0
    st8(c.r[0] + c.r[7], c.r[2]);  // 0601D1D8 mov.b r2,@(r0,r7)
    c.r[7] += 1;  // 0601D1DA add #1,r7
    c.t = (int32_t)c.r[7] > (int32_t)c.r[4];  // 0601D1DC cmp/gt r4,r7
    { const bool k = !c.t; c.r[0] = c.r[6]; if (k) { SH2_POLL(c); goto L_0601D1CE; } }  // 0601D1DE bf/s 0x0601D1CE ; mov r6,r0
L_0601D1E2:
    c.r[15] = c.r[14];  // 0601D1E2 mov r14,r15
L_0601D1E4:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601D1E4 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0601D1E6 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.r[0] = c.r[7]; c.pc = x; return; }  // 0601D1E8 rts ; mov r7,r0
}

void f_0601D05C(SH2Context& c) {
    ran[314] = 1;
L_0601D05C:
    c.r[0] = ld32(0x0601D064u);  // 0601D05C mov.l 0x0601D064,r0
L_0601D05E:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x0601D05Cu: goto L_0601D05C; case 0x0601D05Eu: goto L_0601D05E; default: sh2_call(c, x); return; } }  // 0601D05E jmp @r0 ; nop
}

void f_0601D068(SH2Context& c) {
    ran[315] = 1;
    c.r[0] = c.r[7];  // 0601D068 mov r7,r0
    c.t = (c.r[0] & 0x2u) == 0;  // 0601D06A tst #2,r0
    if (!c.t) { goto L_0601D0AC; }  // 0601D06C bf 0x0601D0AC
    c.t = (c.r[0] & 0x1u) == 0;  // 0601D06E tst #1,r0
    if (c.t) { goto L_0601D080; }  // 0601D070 bt 0x0601D080
    c.r[0] = c.r[5];  // 0601D072 mov r5,r0
    c.t = (c.r[0] & 0x7u) == 0;  // 0601D074 tst #7,r0
    { const bool k = c.t; c.r[4] = 0x1u; if (k) { goto L_0601D07C; } }  // 0601D076 bt/s 0x0601D07C ; mov #1,r4
    c.r[4] = 0x0u;  // 0601D07A mov #0,r4
L_0601D07C:
    c.r[7] += 2; goto L_0601D0AC;  // 0601D07C bra 0x0601D0AC ; add #2,r7
L_0601D080:
    c.r[1] = c.r[6];  // 0601D080 mov r6,r1
    c.r[1] -= 8;  // 0601D082 add #-8,r1
    c.r[2] = c.r[5];  // 0601D084 mov r5,r2
    c.r[2] -= c.r[6];  // 0601D086 sub r6,r2
    c.r[0] = 0x13u;  // 0601D088 mov #19,r0
    c.t = c.r[2] > c.r[0];  // 0601D08A cmp/hi r0,r2
    { const bool k = !c.t; c.r[0] = c.r[7]; if (k) { goto L_0601D096; } }  // 0601D08C bf/s 0x0601D096 ; mov r7,r0
    c.r[2] -= 20;  // 0601D090 add #-20,r2
    c.r[6] += 20;  // 0601D092 add #20,r6
    c.r[1] += 4;  // 0601D094 add #4,r1
L_0601D096:
    c.t = (c.r[2] & c.r[2]) == 0;  // 0601D096 tst r2,r2
    if (c.t) { goto L_0601D0A6; }  // 0601D098 bt 0x0601D0A6
    c.r[0] = c.r[2];  // 0601D09A mov r2,r0
    c.t = c.r[0] == 0xEu;  // 0601D09C cmp/eq #14,r0
    if (!c.t) { goto L_0601D12A; }  // 0601D09E bf 0x0601D12A
    c.r[7] = 0x34u;  // 0601D0A0 mov #52,r7
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); goto L_0601D0D2;  // 0601D0A2 bra 0x0601D0D2 ; mov.b @r1,r2
L_0601D0A6:
    c.r[7] = 0x20u;  // 0601D0A6 mov #32,r7
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); goto L_0601D0D2;  // 0601D0A8 bra 0x0601D0D2 ; mov.b @r1,r2
L_0601D0AC:
    c.r[3] = c.r[6];  // 0601D0AC mov r6,r3
    c.r[1] = c.r[6];  // 0601D0AE mov r6,r1
    c.r[1] -= 8;  // 0601D0B0 add #-8,r1
    c.r[0] = c.r[7];  // 0601D0B2 mov r7,r0
    c.t = c.r[0] == 0x43u;  // 0601D0B4 cmp/eq #67,r0
    { const bool k = !c.t; c.r[0] = c.r[4]; if (k) { goto L_0601D0BE; } }  // 0601D0B6 bf/s 0x0601D0BE ; mov r4,r0
    c.r[3] += 20;  // 0601D0BA add #20,r3
    c.r[1] += 4;  // 0601D0BC add #4,r1
L_0601D0BE:
    c.t = c.r[0] == 0x2u;  // 0601D0BE cmp/eq #2,r0
    if (!c.t) { goto L_0601D0C8; }  // 0601D0C0 bf 0x0601D0C8
    c.r[7] = 0x34u;  // 0601D0C2 mov #52,r7
    c.r[3] += 14; goto L_0601D0D0;  // 0601D0C4 bra 0x0601D0D0 ; add #14,r3
L_0601D0C8:
    c.r[7] = 0x0u;  // 0601D0C8 mov #0,r7
    c.t = (c.r[4] & c.r[4]) == 0;  // 0601D0CA tst r4,r4
    if (!c.t) { goto L_0601D0D0; }  // 0601D0CC bf 0x0601D0D0
    c.r[7] += 12;  // 0601D0CE add #12,r7
L_0601D0D0:
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601D0D0 mov.b @r1,r2
L_0601D0D2:
    c.r[2] += 104;  // 0601D0D2 add #104,r2
    c.r[0] = 0x7u;  // 0601D0D4 mov #7,r0
    c.t = c.r[2] > c.r[0];  // 0601D0D6 cmp/hi r0,r2
    if (c.t) { goto L_0601D12A; }  // 0601D0D8 bt 0x0601D12A
    c.r[2] <<= 8;  // 0601D0DA shll8 r2
    c.r[2] >>= 2;  // 0601D0DC shlr2 r2
    c.r[6] = ld32(0x0601D13Cu);  // 0601D0DE mov.l 0x0601D13C,r6
    c.r[6] += c.r[2];  // 0601D0E0 add r2,r6
    c.r[1] = c.r[6];  // 0601D0E2 mov r6,r1
    c.r[4] = c.r[6];  // 0601D0E4 mov r6,r4
    c.r[4] += 16;  // 0601D0E6 add #16,r4
    c.r[0] = c.r[7];  // 0601D0E8 mov r7,r0
    c.t = (c.r[0] & 0x10u) == 0;  // 0601D0EA tst #16,r0
    { const bool k = c.t; c.r[2] = 0xEu; if (k) { goto L_0601D0F6; } }  // 0601D0EC bt/s 0x0601D0F6 ; mov #14,r2
    c.r[1] += 20;  // 0601D0F0 add #20,r1
    c.r[4] += 12;  // 0601D0F2 add #12,r4
    c.r[2] -= 8;  // 0601D0F4 add #-8,r2
L_0601D0F6:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0601D0F6 mov.b @r3,r0
    c.r[0] += 21;  // 0601D0F8 add #21,r0
    c.t = (int32_t)c.r[0] >= 0;  // 0601D0FA cmp/pz r0
    if (!c.t) { goto L_0601D100; }  // 0601D0FC bf 0x0601D100
    c.r[1] = ld32(c.r[4]);  // 0601D0FE mov.l @r4,r1
L_0601D100:
    c.r[4] = c.r[3];  // 0601D100 mov r3,r4
    c.r[0] = 0x14u;  // 0601D102 mov #20,r0
    c.t = c.r[7] > c.r[0];  // 0601D104 cmp/hi r0,r7
    if (c.t) { goto L_0601D10E; }  // 0601D106 bt 0x0601D10E
    c.t = c.r[6] & 1; c.r[6] >>= 1;  // 0601D108 shlr r6
    c.r[0] = ld32(0x0601D140u);  // 0601D10A mov.l 0x0601D140,r0
    c.r[6] += c.r[0];  // 0601D10C add r0,r6
L_0601D10E:
    c.r[6] += c.r[7];  // 0601D10E add r7,r6
L_0601D110:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0601D110 mov.b @r1+,r0
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 0601D112 mov.b @r4+,r7
    c.t = c.r[0] == c.r[7];  // 0601D114 cmp/eq r7,r0
    if (c.t) { goto L_0601D12E; }  // 0601D116 bt 0x0601D12E
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0601D118 cmp/eq #-1,r0
    if (!c.t) { goto L_0601D12A; }  // 0601D11A bf 0x0601D12A
    c.t = (c.r[7] & c.r[7]) == 0;  // 0601D11C tst r7,r7
    if (!c.t) { goto L_0601D12A; }  // 0601D11E bf 0x0601D12A
    c.r[0] = c.r[6];  // 0601D120 mov r6,r0
    c.r[0] &= 0x18u;  // 0601D122 and #24,r0
    c.t = c.r[0] == 0x18u;  // 0601D124 cmp/eq #24,r0
    { const bool k = c.t; c.r[2] -= 1; c.t = c.r[2] == 0; if (k) { goto L_0601D134; } }  // 0601D126 bt/s 0x0601D134 ; dt r2
L_0601D12A:
    { const uint32_t x = c.pr; c.t = 0; c.pc = x; return; }  // 0601D12A rts ; clrt
L_0601D12E:
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0601D12E cmp/eq #-1,r0
    if (c.t) { goto L_0601D136; }  // 0601D130 bt 0x0601D136
    c.r[2] -= 1; c.t = c.r[2] == 0;  // 0601D132 dt r2
L_0601D134:
    if (!c.t) { SH2_POLL(c); goto L_0601D110; }  // 0601D134 bf 0x0601D110
L_0601D136:
    c.r[3] = c.r[6];  // 0601D136 mov r6,r3
    { const uint32_t x = c.pr; c.t = 1; c.pc = x; return; }  // 0601D138 rts ; sett
}

void f_0601D144(SH2Context& c) {
    ran[316] = 1;
L_0601D144:
    c.r[7] = 0x40u; goto L_0601D14A;  // 0601D144 bra 0x0601D14A ; mov #64,r7
L_0601D14A:
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601D14A sts.l pr,@-r15
L_0601D14C:
    c.pr = 0x0601D150u; SH2_POLL(c); sh2_call(c, 0x0601D05Cu); if (c.pc != 0x0601D150u) return;  // 0601D14C bsr 0x0601D05C ; nop
L_0601D150:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601D150 lds.l @r15+,pr
L_0601D152:
    c.r[5] = c.r[3];  // 0601D152 mov r3,r5
L_0601D154:
    c.r[4] = 0x0u;  // 0601D154 mov #0,r4
L_0601D156:
    c.r[1] = ld32(0x0601D15Cu);  // 0601D156 mov.l 0x0601D15C,r1
L_0601D158:
    { const uint32_t x = c.r[1]; c.r[6] = 0x0u; SH2_POLL(c); switch (x) { case 0x0601D144u: goto L_0601D144; case 0x0601D14Au: goto L_0601D14A; case 0x0601D14Cu: goto L_0601D14C; case 0x0601D150u: goto L_0601D150; case 0x0601D152u: goto L_0601D152; case 0x0601D154u: goto L_0601D154; case 0x0601D156u: goto L_0601D156; case 0x0601D158u: goto L_0601D158; default: sh2_call(c, x); return; } }  // 0601D158 jmp @r1 ; mov #0,r6
}

void f_0601D148(SH2Context& c) {
    ran[317] = 1;
L_0601D148:
    c.r[7] = 0x41u;  // 0601D148 mov #65,r7
L_0601D14A:
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601D14A sts.l pr,@-r15
L_0601D14C:
    c.pr = 0x0601D150u; SH2_POLL(c); sh2_call(c, 0x0601D05Cu); if (c.pc != 0x0601D150u) return;  // 0601D14C bsr 0x0601D05C ; nop
L_0601D150:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601D150 lds.l @r15+,pr
L_0601D152:
    c.r[5] = c.r[3];  // 0601D152 mov r3,r5
L_0601D154:
    c.r[4] = 0x0u;  // 0601D154 mov #0,r4
L_0601D156:
    c.r[1] = ld32(0x0601D15Cu);  // 0601D156 mov.l 0x0601D15C,r1
L_0601D158:
    { const uint32_t x = c.r[1]; c.r[6] = 0x0u; SH2_POLL(c); switch (x) { case 0x0601D148u: goto L_0601D148; case 0x0601D14Au: goto L_0601D14A; case 0x0601D14Cu: goto L_0601D14C; case 0x0601D150u: goto L_0601D150; case 0x0601D152u: goto L_0601D152; case 0x0601D154u: goto L_0601D154; case 0x0601D156u: goto L_0601D156; case 0x0601D158u: goto L_0601D158; default: sh2_call(c, x); return; } }  // 0601D158 jmp @r1 ; mov #0,r6
}

void f_0601D208(SH2Context& c) {
    ran[318] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601D208 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0601D20A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601D20C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601D20E sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0601D210 mov r15,r14
    c.r[9] = c.r[4] & 0xFFu;  // 0601D212 extu.b r4,r9
    c.r[2] = ld32(0x0601D290u);  // 0601D214 mov.l 0x0601D290,r2
    c.r[1] = c.r[2];  // 0601D216 mov r2,r1
    c.r[1] += 78;  // 0601D218 add #78,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601D21A mov.b @r1,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601D28Cu);  // 0601D21C mov.w 0x0601D28C,r0
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0601D21E mov.b @(r0,r2),r0
    c.r[1] = c.r[0] & 0xFFu;  // 0601D220 extu.b r0,r1
    c.r[1] >>= 2;  // 0601D222 shlr2 r1
    c.r[1] >>= 2;  // 0601D224 shlr2 r1
    c.r[1] += c.r[3];  // 0601D226 add r3,r1
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[1];  // 0601D228 cmp/ge r1,r9
    { const bool k = !c.t; c.r[8] = c.r[5] & 0xFFu; if (k) { goto L_0601D258; } }  // 0601D22A bf/s 0x0601D258 ; extu.b r5,r8
    c.r[0] &= 0xFu;  // 0601D22E and #15,r0
    c.r[0] -= 20;  // 0601D230 add #-20,r0
    c.r[3] -= c.r[0];  // 0601D232 sub r0,r3
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[3];  // 0601D234 cmp/ge r3,r9
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_0601D258; } }  // 0601D236 bt/s 0x0601D258 ; mov r2,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601D28Eu);  // 0601D23A mov.w 0x0601D28E,r0
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0601D23C mov.b @(r0,r2),r0
    c.r[1] += 79;  // 0601D23E add #79,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601D240 mov.b @r1,r3
    c.r[1] = c.r[0] & 0xFFu;  // 0601D242 extu.b r0,r1
    c.r[1] >>= 2;  // 0601D244 shlr2 r1
    c.r[1] >>= 2;  // 0601D246 shlr2 r1
    c.r[1] += c.r[3];  // 0601D248 add r3,r1
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 0601D24A cmp/ge r1,r8
    { const bool k = !c.t; c.r[0] &= 0xFu; if (k) { goto L_0601D258; } }  // 0601D24C bf/s 0x0601D258 ; and #15,r0
    c.r[0] -= 10;  // 0601D250 add #-10,r0
    c.r[3] -= c.r[0];  // 0601D252 sub r0,r3
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[3];  // 0601D254 cmp/ge r3,r8
    if (!c.t) { goto L_0601D278; }  // 0601D256 bf 0x0601D278
L_0601D258:
    c.r[3] = ld32(0x0601D290u);  // 0601D258 mov.l 0x0601D290,r3
    c.r[2] = c.r[3];  // 0601D25A mov r3,r2
    c.r[2] += 78;  // 0601D25C add #78,r2
    c.r[1] = c.r[9];  // 0601D25E mov r9,r1
    c.r[1] -= 9;  // 0601D260 add #-9,r1
    st8(c.r[2], c.r[1]);  // 0601D262 mov.b r1,@r2
    c.r[3] += 79;  // 0601D264 add #79,r3
    c.r[1] = c.r[8];  // 0601D266 mov r8,r1
    c.r[1] -= 6;  // 0601D268 add #-6,r1
    st8(c.r[3], c.r[1]);  // 0601D26A mov.b r1,@r3
    c.r[9] = c.r[9] & 0xFFu;  // 0601D26C extu.b r9,r9
    c.r[8] = c.r[8] & 0xFFu;  // 0601D26E extu.b r8,r8
    c.r[1] = ld32(0x0601D294u);  // 0601D270 mov.l 0x0601D294,r1
    c.r[5] = 0x0u;  // 0601D272 mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0601D278u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601D278u) return; }  // 0601D274 jsr @r1 ; mov #0,r4
L_0601D278:
    c.r[1] = ld32(0x0601D298u);  // 0601D278 mov.l 0x0601D298,r1
    c.r[5] = c.r[8];  // 0601D27A mov r8,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0601D280u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601D280u) return; }  // 0601D27C jsr @r1 ; mov r9,r4
    c.r[15] = c.r[14];  // 0601D280 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601D282 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601D284 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0601D286 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601D288 rts ; mov.l @r15+,r8
}

void f_0601D29C(SH2Context& c) {
    ran[319] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601D29C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0601D29E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601D2A0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601D2A2 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0601D2A4 mov r15,r14
    c.r[8] = c.r[5];  // 0601D2A6 mov r5,r8
    c.r[1] = ld32(0x0601D35Cu);  // 0601D2A8 mov.l 0x0601D35C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601D2AEu; c.r[9] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601D2AEu) return; }  // 0601D2AA jsr @r1 ; extu.w r4,r9
    c.r[1] = ld32(0x0601D360u);  // 0601D2AE mov.l 0x0601D360,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601D2B0 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0601D2B2 mov r1,r0
    c.r[0] >>= 2;  // 0601D2B4 shlr2 r0
    c.r[0] >>= 2;  // 0601D2B6 shlr2 r0
    c.r[0] &= 0x1u;  // 0601D2B8 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601D2BA tst r0,r0
    if (c.t) { goto L_0601D2FE; }  // 0601D2BC bt 0x0601D2FE
    c.r[2] = ld32(0x0601D364u);  // 0601D2BE mov.l 0x0601D364,r2
    c.r[1] = c.r[2];  // 0601D2C0 mov r2,r1
    c.r[1] += 6;  // 0601D2C2 add #6,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0601D2C4 mov.w @r1,r1
    c.r[7] = c.r[1] & 0xFFFFu;  // 0601D2C6 extu.w r1,r7
    c.t = (c.r[7] & c.r[7]) == 0;  // 0601D2C8 tst r7,r7
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_0601D2D8; } }  // 0601D2CA bt/s 0x0601D2D8 ; mov r2,r1
    c.r[1] += 8;  // 0601D2CE add #8,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0601D2D0 mov.w @r1,r1
    c.r[2] += 10;  // 0601D2D2 add #10,r2
    c.r[6] = c.r[1] & 0xFFFFu; goto L_0601D2EC;  // 0601D2D4 bra 0x0601D2EC ; extu.w r1,r6
L_0601D2D8:
    c.r[2] = ld32(0x0601D368u);  // 0601D2D8 mov.l 0x0601D368,r2
    c.r[1] = c.r[2];  // 0601D2DA mov r2,r1
    c.r[1] += 8;  // 0601D2DC add #8,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0601D2DE mov.w @r1,r1
    c.r[6] = c.r[1] & 0xFFFFu;  // 0601D2E0 extu.w r1,r6
    c.r[1] = c.r[2];  // 0601D2E2 mov r2,r1
    c.r[1] += 6;  // 0601D2E4 add #6,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0601D2E6 mov.w @r1,r1
    c.r[2] += 10;  // 0601D2E8 add #10,r2
    c.r[7] = c.r[1] & 0xFFFFu;  // 0601D2EA extu.w r1,r7
L_0601D2EC:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0601D2EC mov.w @r2,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0601D2EE extu.w r1,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0601D2F0 mov.l r1,@-r15
    c.r[0] = ld32(0x0601D36Cu);  // 0601D2F2 mov.l 0x0601D36C,r0
    c.r[5] = c.r[8];  // 0601D2F4 mov r8,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0601D2FAu; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601D2FAu) return; }  // 0601D2F6 jsr @r0 ; mov r9,r4
    c.r[0] = c.r[0] & 0xFFFFu; goto L_0601D350;  // 0601D2FA bra 0x0601D350 ; extu.w r0,r0
L_0601D2FE:
    c.r[1] = ld32(0x0601D370u);  // 0601D2FE mov.l 0x0601D370,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601D300 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0601D302 mov r1,r0
    c.r[0] >>= 2;  // 0601D304 shlr2 r0
    c.r[0] >>= 2;  // 0601D306 shlr2 r0
    c.r[0] &= 0x1u;  // 0601D308 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601D30A tst r0,r0
    if (c.t) { goto L_0601D34E; }  // 0601D30C bt 0x0601D34E
    c.r[2] = ld32(0x0601D374u);  // 0601D30E mov.l 0x0601D374,r2
    c.r[1] = c.r[2];  // 0601D310 mov r2,r1
    c.r[1] += 6;  // 0601D312 add #6,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0601D314 mov.w @r1,r1
    c.r[7] = c.r[1] & 0xFFFFu;  // 0601D316 extu.w r1,r7
    c.t = (c.r[7] & c.r[7]) == 0;  // 0601D318 tst r7,r7
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_0601D328; } }  // 0601D31A bt/s 0x0601D328 ; mov r2,r1
    c.r[1] += 8;  // 0601D31E add #8,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0601D320 mov.w @r1,r1
    c.r[2] += 10;  // 0601D322 add #10,r2
    c.r[6] = c.r[1] & 0xFFFFu; goto L_0601D33C;  // 0601D324 bra 0x0601D33C ; extu.w r1,r6
L_0601D328:
    c.r[2] = ld32(0x0601D378u);  // 0601D328 mov.l 0x0601D378,r2
    c.r[1] = c.r[2];  // 0601D32A mov r2,r1
    c.r[1] += 8;  // 0601D32C add #8,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0601D32E mov.w @r1,r1
    c.r[6] = c.r[1] & 0xFFFFu;  // 0601D330 extu.w r1,r6
    c.r[1] = c.r[2];  // 0601D332 mov r2,r1
    c.r[1] += 6;  // 0601D334 add #6,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0601D336 mov.w @r1,r1
    c.r[2] += 10;  // 0601D338 add #10,r2
    c.r[7] = c.r[1] & 0xFFFFu;  // 0601D33A extu.w r1,r7
L_0601D33C:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0601D33C mov.w @r2,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0601D33E extu.w r1,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0601D340 mov.l r1,@-r15
    c.r[0] = ld32(0x0601D36Cu);  // 0601D342 mov.l 0x0601D36C,r0
    c.r[5] = c.r[8];  // 0601D344 mov r8,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0601D34Au; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601D34Au) return; }  // 0601D346 jsr @r0 ; mov r9,r4
    c.r[0] = c.r[0] & 0xFFFFu; goto L_0601D350;  // 0601D34A bra 0x0601D350 ; extu.w r0,r0
L_0601D34E:
    c.r[0] = ld32(0x0601D37Cu);  // 0601D34E mov.l 0x0601D37C,r0
L_0601D350:
    c.r[15] = c.r[14];  // 0601D350 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601D352 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601D354 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0601D356 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601D358 rts ; mov.l @r15+,r8
}

void f_0601D380(SH2Context& c) {
    ran[320] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601D380 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0601D382 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0601D384 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0601D386 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0601D388 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0601D38A mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601D38C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601D38E sts.l pr,@-r15
    c.r[15] -= 24;  // 0601D390 add #-24,r15
    c.r[14] = c.r[15];  // 0601D392 mov r15,r14
    st32(c.r[14] + 8, c.r[5]);  // 0601D394 mov.l r5,@(8,r14)
    c.r[4] = c.r[4] & 0xFFFFu;  // 0601D396 extu.w r4,r4
    st32(c.r[14] + 4, c.r[4]);  // 0601D398 mov.l r4,@(4,r14)
    c.r[6] = c.r[6] & 0xFFFFu;  // 0601D39A extu.w r6,r6
    st32(c.r[14] + 12, c.r[6]);  // 0601D39C mov.l r6,@(12,r14)
    c.r[12] = c.r[7] & 0xFFFFu;  // 0601D39E extu.w r7,r12
    c.r[13] = 0x0u;  // 0601D3A0 mov #0,r13
    c.r[1] = ld32(c.r[14] + 56);  // 0601D3A2 mov.l @(56,r14),r1
    c.r[8] = (uint32_t)(int16_t)ld16(0x0601D41Au);  // 0601D3A4 mov.w 0x0601D41A,r8
    c.r[1] = c.r[1] & 0xFFFFu;  // 0601D3A6 extu.w r1,r1
    st32(c.r[14] + 16, c.r[1]);  // 0601D3A8 mov.l r1,@(16,r14)
    c.r[0] = ld32(0x0601D420u);  // 0601D3AA mov.l 0x0601D420,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601D3B0u; c.r[4] = ld32(c.r[14] + 16); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601D3B0u) return; }  // 0601D3AC jsr @r0 ; mov.l @(16,r14),r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601D3B0 tst r0,r0
    if (c.t) { goto L_0601D440; }  // 0601D3B2 bt 0x0601D440
    c.r[0] = ld32(0x0601D424u);  // 0601D3B4 mov.l 0x0601D424,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601D3BAu; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601D3BAu) return; }  // 0601D3B6 jsr @r0 ; mov r12,r4
    c.r[1] = c.r[0];  // 0601D3BA mov r0,r1
    c.r[9] = c.r[1] & 0xFFu;  // 0601D3BC extu.b r1,r9
    c.r[1] = ld32(0x0601D428u);  // 0601D3BE mov.l 0x0601D428,r1
    c.r[3] = ld32(c.r[1]);  // 0601D3C0 mov.l @r1,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601D41Cu);  // 0601D3C2 mov.w 0x0601D41C,r1
    c.r[0] = c.r[3];  // 0601D3C4 mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601D3C6 mov.b @(r0,r1),r1
    c.r[7] = c.r[1] & 0xFFu;  // 0601D3C8 extu.b r1,r7
    c.t = (int32_t)c.r[13] >= (int32_t)c.r[7];  // 0601D3CA cmp/ge r7,r13
    { const bool k = c.t; c.r[2] = 0x0u; if (k) { goto L_0601D400; } }  // 0601D3CC bt/s 0x0601D400 ; mov #0,r2
    c.r[6] = c.r[3];  // 0601D3D0 mov r3,r6
    c.r[1] = ld32(0x0601D42Cu);  // 0601D3D2 mov.l 0x0601D42C,r1
    c.r[4] = ld32(c.r[1]);  // 0601D3D4 mov.l @r1,r4
    c.r[5] = c.r[7];  // 0601D3D6 mov r7,r5
    c.r[7] = c.r[6];  // 0601D3D8 mov r6,r7
    c.r[3] = 0x0u;  // 0601D3DA mov #0,r3
L_0601D3DC:
    c.r[1] = c.r[7];  // 0601D3DC mov r7,r1
    c.r[1] += 1;  // 0601D3DE add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601D3E0 mov.b @r1,r1
    c.r[8] = c.r[1] & 0xFFu;  // 0601D3E2 extu.b r1,r8
    c.r[1] = 0x1Eu;  // 0601D3E4 mov #30,r1
    c.macl = c.r[8] * c.r[1];  // 0601D3E6 mul.l r1,r8
    c.r[1] = c.macl;  // 0601D3E8 sts macl,r1
    c.r[1] += c.r[4];  // 0601D3EA add r4,r1
    c.r[1] += 15;  // 0601D3EC add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601D3EE mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601D3F0 extu.b r1,r1
    c.t = c.r[1] == c.r[9];  // 0601D3F2 cmp/eq r9,r1
    { const bool k = c.t; c.r[7] += 2; if (k) { goto L_0601D400; } }  // 0601D3F4 bt/s 0x0601D400 ; add #2,r7
    c.r[2] += 1;  // 0601D3F8 add #1,r2
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[5];  // 0601D3FA cmp/ge r5,r2
    { const bool k = !c.t; c.r[3] += 2; if (k) { SH2_POLL(c); goto L_0601D3DC; } }  // 0601D3FC bf/s 0x0601D3DC ; add #2,r3
L_0601D400:
    c.r[6] = (uint32_t)(int16_t)ld16(0x0601D41Au);  // 0601D400 mov.w 0x0601D41A,r6
    c.r[1] = ld32(0x0601D430u);  // 0601D402 mov.l 0x0601D430,r1
    c.r[4] = ld32(c.r[1]);  // 0601D404 mov.l @r1,r4
    c.r[1] = ld32(0x0601D434u);  // 0601D406 mov.l 0x0601D434,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601D40Cu; c.r[5] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601D40Cu) return; }  // 0601D408 jsr @r1 ; mov r8,r5
    c.r[13] = 0x0u;  // 0601D40C mov #0,r13
    c.r[0] = ld32(0x0601D438u);  // 0601D40E mov.l 0x0601D438,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601D414u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601D414u) return; }  // 0601D410 jsr @r0 ; mov r8,r4
    c.r[1] = ld32(0x0601D43Cu);  // 0601D414 mov.l 0x0601D43C,r1
    st8(c.r[1], c.r[0]); goto L_0601D444;  // 0601D416 bra 0x0601D444 ; mov.b r0,@r1
L_0601D440:
    c.r[1] = ld32(0x0601D584u);  // 0601D440 mov.l 0x0601D584,r1
    st8(c.r[1], c.r[8]);  // 0601D442 mov.b r8,@r1
L_0601D444:
    c.r[1] = ld32(0x0601D584u);  // 0601D444 mov.l 0x0601D584,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601D446 mov.b @r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0601D57Cu);  // 0601D448 mov.w 0x0601D57C,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0601D44A extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 0601D44C cmp/eq r2,r1
    { const bool k = !c.t; c.r[0] = 0x1u; if (k) { goto L_0601D456; } }  // 0601D44E bf/s 0x0601D456 ; mov #1,r0
    goto L_0601D658;  // 0601D452 bra 0x0601D658 ; nop
L_0601D456:
    st32(c.r[14] + 20, c.r[0]);  // 0601D456 mov.l r0,@(20,r14)
    c.r[1] = ld32(0x0601D588u);  // 0601D458 mov.l 0x0601D588,r1
    c.r[1] = ld32(c.r[1]);  // 0601D45A mov.l @r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0601D57Eu);  // 0601D45C mov.w 0x0601D57E,r2
    c.r[0] = c.r[1];  // 0601D45E mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0601D460 mov.b @(r0,r2),r1
    c.r[1] >>= 2;  // 0601D462 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0601D464 shlr r1
    c.r[1] >>= 2;  // 0601D466 shlr2 r1
    c.r[0] = 0x1u;  // 0601D468 mov #1,r0
    c.r[1] &= c.r[0];  // 0601D46A and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601D46C tst r1,r1
    if (c.t) { goto L_0601D482; }  // 0601D46E bt 0x0601D482
    c.r[4] = (uint32_t)(int16_t)ld16(0x0601D580u);  // 0601D470 mov.w 0x0601D580,r4
    c.r[0] = ld32(0x0601D58Cu);  // 0601D472 mov.l 0x0601D58C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601D478u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601D478u) return; }  // 0601D474 jsr @r0 ; nop
    c.r[0] &= 0xF0u;  // 0601D478 and #240,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601D47A tst r0,r0
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_0601D482; } }  // 0601D47C bt/s 0x0601D482 ; mov #0,r0
    st32(c.r[14] + 20, c.r[0]);  // 0601D480 mov.l r0,@(20,r14)
L_0601D482:
    c.r[1] = ld32(0x0601D588u);  // 0601D482 mov.l 0x0601D588,r1
    c.r[1] = ld32(c.r[1]);  // 0601D484 mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601D582u);  // 0601D486 mov.w 0x0601D582,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601D488 mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601D48A extu.b r1,r1
    c.r[0] = c.r[1];  // 0601D48C mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0601D48E shlr r0
    c.r[0] &= 0xFu;  // 0601D490 and #15,r0
    c.t = c.r[0] == 0x9u;  // 0601D492 cmp/eq #9,r0
    { const bool k = c.t; c.r[1] >>= 2; if (k) { goto L_0601D49C; } }  // 0601D494 bt/s 0x0601D49C ; shlr2 r1
    goto L_0601D606;  // 0601D498 bra 0x0601D606 ; nop
L_0601D49C:
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0601D49C shlr r1
    c.r[1] >>= 2;  // 0601D49E shlr2 r1
    c.r[0] = c.r[1];  // 0601D4A0 mov r1,r0
    c.t = c.r[0] == 0x2u;  // 0601D4A2 cmp/eq #2,r0
    if (c.t) { goto L_0601D4AA; }  // 0601D4A4 bt 0x0601D4AA
    goto L_0601D606;  // 0601D4A6 bra 0x0601D606 ; nop
L_0601D4AA:
    c.r[9] = 0x0u;  // 0601D4AA mov #0,r9
    c.r[2] = 0x0u;  // 0601D4AC mov #0,r2
    c.r[5] = ld32(0x0601D590u);  // 0601D4AE mov.l 0x0601D590,r5
    c.r[6] = 0x1u;  // 0601D4B0 mov #1,r6
    c.r[7] = 0x7Fu;  // 0601D4B2 mov #127,r7
    c.r[3] = 0x0u;  // 0601D4B4 mov #0,r3
L_0601D4B6:
    c.r[1] = ld32(c.r[5]);  // 0601D4B6 mov.l @r5,r1
    c.r[1] += c.r[3];  // 0601D4B8 add r3,r1
    c.r[1] += 16;  // 0601D4BA add #16,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601D4BC mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601D4BE extu.b r1,r1
    c.t = c.r[1] == c.r[8];  // 0601D4C0 cmp/eq r8,r1
    { const bool k = !c.t; c.r[0] = c.r[14]; if (k) { goto L_0601D4D2; } }  // 0601D4C2 bf/s 0x0601D4D2 ; mov r14,r0
    st8(c.r[0] + c.r[9], c.r[2]);  // 0601D4C6 mov.b r2,@(r0,r9)
    c.r[1] = c.r[9];  // 0601D4C8 mov r9,r1
    c.r[1] += 1;  // 0601D4CA add #1,r1
    c.r[9] = c.r[1] & 0xFFu;  // 0601D4CC extu.b r1,r9
    c.t = c.r[9] > c.r[6];  // 0601D4CE cmp/hi r6,r9
    if (c.t) { goto L_0601D4DA; }  // 0601D4D0 bt 0x0601D4DA
L_0601D4D2:
    c.r[2] += 1;  // 0601D4D2 add #1,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[7];  // 0601D4D4 cmp/gt r7,r2
    { const bool k = !c.t; c.r[3] += 30; if (k) { SH2_POLL(c); goto L_0601D4B6; } }  // 0601D4D6 bf/s 0x0601D4B6 ; add #30,r3
L_0601D4DA:
    c.r[9] = 0x0u;  // 0601D4DA mov #0,r9
    c.r[11] = ld32(0x0601D594u);  // 0601D4DC mov.l 0x0601D594,r11
    c.r[0] = c.r[14];  // 0601D4DE mov r14,r0
L_0601D4E0:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 0601D4E0 mov.b @(r0,r9),r1
    c.r[5] = 0x1Bu;  // 0601D4E2 mov #27,r5
    c.r[2] = c.r[1] & 0xFFu;  // 0601D4E4 extu.b r1,r2
    c.r[1] = 0x1Eu;  // 0601D4E6 mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 0601D4E8 mul.l r1,r2
    c.r[0] = ld32(0x0601D590u);  // 0601D4EA mov.l 0x0601D590,r0
    c.r[3] = ld32(c.r[0]);  // 0601D4EC mov.l @r0,r3
    c.r[10] = c.macl;  // 0601D4EE sts macl,r10
    c.r[0] = c.r[10];  // 0601D4F0 mov r10,r0
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 0601D4F2 mov.w @(r0,r3),r8
    c.r[4] = ld32(0x0601D598u);  // 0601D4F4 mov.l 0x0601D598,r4
    { const uint32_t x = c.r[11]; c.pr = 0x0601D4FAu; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601D4FAu) return; }  // 0601D4F6 jsr @r11 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 0601D4FA mov r0,r1
    c.r[5] = c.r[8];  // 0601D4FC mov r8,r5
    { const uint32_t x = c.r[11]; c.pr = 0x0601D502u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601D502u) return; }  // 0601D4FE jsr @r11 ; mov r1,r4
    c.r[2] = c.r[0];  // 0601D502 mov r0,r2
    c.r[1] = c.r[2];  // 0601D504 mov r2,r1
    c.r[1] += 7;  // 0601D506 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601D508 mov.b @r1,r1
    c.r[8] = 0x7u;  // 0601D50A mov #7,r8
    c.r[8] &= c.r[1];  // 0601D50C and r1,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 0601D50E tst r8,r8
    if (!c.t) { goto L_0601D5A8; }  // 0601D510 bf 0x0601D5A8
    c.r[8] = c.r[2];  // 0601D512 mov r2,r8
    c.r[8] += 25;  // 0601D514 add #25,r8
    c.r[2] = 0xFu;  // 0601D516 mov #15,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0601D518 mov.b @r8,r1
    c.r[0] = 0x10u;  // 0601D51A mov #16,r0
    c.r[2] &= c.r[1];  // 0601D51C and r1,r2
    c.r[2] |= c.r[0];  // 0601D51E or r0,r2
    c.r[1] = ld32(0x0601D584u);  // 0601D520 mov.l 0x0601D584,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601D522 mov.b @r1,r1
    c.r[6] = c.r[2];  // 0601D524 mov r2,r6
    c.r[7] = c.r[1] & 0xFFu;  // 0601D526 extu.b r1,r7
    c.r[1] = ld32(0x0601D59Cu);  // 0601D528 mov.l 0x0601D59C,r1
    c.r[3] = ld32(c.r[1]);  // 0601D52A mov.l @r1,r3
    c.r[7] <<= 2;  // 0601D52C shll2 r7
    c.r[7] <<= 2;  // 0601D52E shll2 r7
    c.r[1] = c.r[7];  // 0601D530 mov r7,r1
    c.r[1] += c.r[3];  // 0601D532 add r3,r1
    c.r[1] += 1;  // 0601D534 add #1,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601D536 mov.b @r1,r5
    c.r[0] = c.r[7];  // 0601D538 mov r7,r0
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0601D53A mov.b @(r0,r3),r4
    c.r[5] = c.r[5] & 0xFFu;  // 0601D53C extu.b r5,r5
    c.r[4] = c.r[4] & 0xFFu;  // 0601D53E extu.b r4,r4
    c.r[0] = ld32(0x0601D5A0u);  // 0601D540 mov.l 0x0601D5A0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601D546u; c.r[7] = 0xFFFFFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601D546u) return; }  // 0601D542 jsr @r0 ; mov #-1,r7
    c.r[1] = c.r[0];  // 0601D546 mov r0,r1
    c.r[1] = (uint32_t)(int32_t)(int8_t)c.r[1];  // 0601D548 exts.b r1,r1
    c.t = (int32_t)c.r[1] >= 0;  // 0601D54A cmp/pz r1
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_0601D5F6; } }  // 0601D54C bt/s 0x0601D5F6 ; mov r9,r1
    c.r[0] = 0x30u;  // 0601D550 mov #48,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0601D552 mov.b @r8,r1
    c.r[5] = 0xAu;  // 0601D554 mov #10,r5
    c.r[1] &= c.r[0];  // 0601D556 and r0,r1
    c.r[1] >>= 2;  // 0601D558 shlr2 r1
    c.r[1] >>= 2;  // 0601D55A shlr2 r1
    c.r[1] += 1;  // 0601D55C add #1,r1
    c.r[0] = ld32(0x0601D590u);  // 0601D55E mov.l 0x0601D590,r0
    c.r[4] = ld32(c.r[0]);  // 0601D560 mov.l @r0,r4
    c.r[6] = c.r[1] & 0xFFu;  // 0601D562 extu.b r1,r6
    c.r[4] += c.r[10];  // 0601D564 add r10,r4
    c.r[0] = ld32(0x0601D5A4u);  // 0601D566 mov.l 0x0601D5A4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601D56Cu; c.r[4] += 17; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601D56Cu) return; }  // 0601D568 jsr @r0 ; add #17,r4
    c.r[1] = c.r[0];  // 0601D56C mov r0,r1
    c.r[1] = (uint32_t)(int32_t)(int8_t)c.r[1];  // 0601D56E exts.b r1,r1
    c.r[0] = c.r[1];  // 0601D570 mov r1,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0601D572 cmp/eq #-1,r0
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_0601D606; } }  // 0601D574 bt/s 0x0601D606 ; mov r9,r1
    c.r[1] += 1; goto L_0601D5F8;  // 0601D578 bra 0x0601D5F8 ; add #1,r1
L_0601D5A8:
    c.r[0] = c.r[8];  // 0601D5A8 mov r8,r0
    c.t = c.r[0] == 0x1u;  // 0601D5AA cmp/eq #1,r0
    { const bool k = !c.t; c.r[1] = c.r[9]; if (k) { goto L_0601D5F6; } }  // 0601D5AC bf/s 0x0601D5F6 ; mov r9,r1
    c.r[0] = ld32(0x0601D674u);  // 0601D5B0 mov.l 0x0601D674,r0
    c.r[1] = ld32(c.r[0]);  // 0601D5B2 mov.l @r0,r1
    c.r[5] = 0x1Cu;  // 0601D5B4 mov #28,r5
    c.r[10] += c.r[1];  // 0601D5B6 add r1,r10
    c.r[10] += 15;  // 0601D5B8 add #15,r10
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0601D5BA mov.b @r10,r2
    c.r[1] = ld32(0x0601D678u);  // 0601D5BC mov.l 0x0601D678,r1
    c.r[1] = ld32(c.r[1]);  // 0601D5BE mov.l @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0601D5C0 extu.b r2,r2
    c.r[3] = c.r[2];  // 0601D5C2 mov r2,r3
    c.r[3] += c.r[3];  // 0601D5C4 add r3,r3
    c.r[3] += c.r[2];  // 0601D5C6 add r2,r3
    c.r[3] <<= 2;  // 0601D5C8 shll2 r3
    c.r[0] = c.r[3];  // 0601D5CA mov r3,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0601D5CC mov.w @(r0,r1),r1
    c.r[4] = ld32(0x0601D67Cu);  // 0601D5CE mov.l 0x0601D67C,r4
    { const uint32_t x = c.r[11]; c.pr = 0x0601D5D4u; c.r[12] = c.r[1] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601D5D4u) return; }  // 0601D5D0 jsr @r11 ; extu.w r1,r12
    c.r[1] = c.r[0];  // 0601D5D4 mov r0,r1
    c.r[5] = c.r[12];  // 0601D5D6 mov r12,r5
    { const uint32_t x = c.r[11]; c.pr = 0x0601D5DCu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601D5DCu) return; }  // 0601D5D8 jsr @r11 ; mov r1,r4
    c.r[2] = c.r[0];  // 0601D5DC mov r0,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]); c.r[2] += 1;  // 0601D5DE mov.b @r2+,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601D5E0 extu.b r1,r1
    c.r[0] = c.r[1];  // 0601D5E2 mov r1,r0
    c.r[0] <<= 8;  // 0601D5E4 shll8 r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601D5E6 mov.b @r2,r1
    c.r[13] = c.r[8];  // 0601D5E8 mov r8,r13
    c.r[1] = c.r[1] & 0xFFu;  // 0601D5EA extu.b r1,r1
    c.r[0] |= c.r[1];  // 0601D5EC or r1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601D670u);  // 0601D5EE mov.w 0x0601D670,r1
    c.r[0] &= c.r[1];  // 0601D5F0 and r1,r0
    st32(c.r[14] + 12, c.r[0]);  // 0601D5F2 mov.l r0,@(12,r14)
    c.r[1] = c.r[9];  // 0601D5F4 mov r9,r1
L_0601D5F6:
    c.r[1] += 1;  // 0601D5F6 add #1,r1
L_0601D5F8:
    c.r[9] = c.r[1] & 0xFFu;  // 0601D5F8 extu.b r1,r9
    c.r[1] = 0x1u;  // 0601D5FA mov #1,r1
    c.t = c.r[9] > c.r[1];  // 0601D5FC cmp/hi r1,r9
    { const bool k = c.t; c.r[0] = c.r[14]; if (k) { goto L_0601D606; } }  // 0601D5FE bt/s 0x0601D606 ; mov r14,r0
    SH2_POLL(c); goto L_0601D4E0;  // 0601D602 bra 0x0601D4E0 ; nop
L_0601D606:
    c.r[1] = ld32(0x0601D680u);  // 0601D606 mov.l 0x0601D680,r1
    c.r[1] = ld32(c.r[1]);  // 0601D608 mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601D672u);  // 0601D60A mov.w 0x0601D672,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601D60C mov.b @(r0,r1),r1
    c.r[0] = c.r[1];  // 0601D60E mov r1,r0
    c.r[0] >>= 2;  // 0601D610 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0601D612 shlr r0
    c.r[0] >>= 2;  // 0601D614 shlr2 r0
    c.r[0] &= 0x1u;  // 0601D616 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601D618 tst r0,r0
    { const bool k = c.t; c.r[0] = ld32(c.r[14] + 4); if (k) { goto L_0601D62A; } }  // 0601D61A bt/s 0x0601D62A ; mov.l @(4,r14),r0
    c.t = (c.r[13] & c.r[13]) == 0;  // 0601D61E tst r13,r13
    { const bool k = !c.t; c.r[0] = ld32(c.r[14] + 20); if (k) { goto L_0601D628; } }  // 0601D620 bf/s 0x0601D628 ; mov.l @(20,r14),r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601D624 tst r0,r0
    if (c.t) { goto L_0601D658; }  // 0601D626 bt 0x0601D658
L_0601D628:
    c.r[0] = ld32(c.r[14] + 4);  // 0601D628 mov.l @(4,r14),r0
L_0601D62A:
    c.t = c.r[12] == c.r[0];  // 0601D62A cmp/eq r0,r12
    if (c.t) { goto L_0601D634; }  // 0601D62C bt 0x0601D634
    c.r[1] = ld32(0x0601D684u);  // 0601D62E mov.l 0x0601D684,r1
    c.t = c.r[0] == c.r[1];  // 0601D630 cmp/eq r1,r0
    if (!c.t) { goto L_0601D658; }  // 0601D632 bf 0x0601D658
L_0601D634:
    c.r[1] = ld32(0x0601D688u);  // 0601D634 mov.l 0x0601D688,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601D63Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601D63Au) return; }  // 0601D636 jsr @r1 ; nop
    c.r[0] = ld32(c.r[14] + 8);  // 0601D63A mov.l @(8,r14),r0
    c.t = c.r[0] == 0x1u;  // 0601D63C cmp/eq #1,r0
    { const bool k = c.t; c.r[1] = 0x1u; if (k) { goto L_0601D650; } }  // 0601D63E bt/s 0x0601D650 ; mov #1,r1
    c.t = (int32_t)c.r[0] > (int32_t)c.r[1];  // 0601D642 cmp/gt r1,r0
    { const bool k = c.t; c.t = (c.r[0] & c.r[0]) == 0; if (k) { goto L_0601D654; } }  // 0601D644 bt/s 0x0601D654 ; tst r0,r0
    { const bool k = !c.t; c.r[0] = ld32(c.r[14] + 12); if (k) { goto L_0601D654; } }  // 0601D648 bf/s 0x0601D654 ; mov.l @(12,r14),r0
    c.r[14] += 24; goto L_0601D65C;  // 0601D64C bra 0x0601D65C ; add #24,r14
L_0601D650:
    c.r[0] = c.r[12]; goto L_0601D65A;  // 0601D650 bra 0x0601D65A ; mov r12,r0
L_0601D654:
    c.r[0] = ld32(c.r[14] + 16); goto L_0601D65A;  // 0601D654 bra 0x0601D65A ; mov.l @(16,r14),r0
L_0601D658:
    c.r[0] = ld32(0x0601D684u);  // 0601D658 mov.l 0x0601D684,r0
L_0601D65A:
    c.r[14] += 24;  // 0601D65A add #24,r14
L_0601D65C:
    c.r[15] = c.r[14];  // 0601D65C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601D65E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601D660 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0601D662 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0601D664 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0601D666 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0601D668 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0601D66A mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601D66C rts ; mov.l @r15+,r8
}

}  // namespace p_srwfin_installed
