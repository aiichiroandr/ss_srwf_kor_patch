#include "p_srwfin_kor_funcs.h"

namespace p_srwfin_kor {

void f_06089174(SH2Context& c) {
    ran[1931] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06089174 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06089176 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06089178 sts.l pr,@-r15
    c.r[15] -= 8;  // 0608917A add #-8,r15
    c.r[14] = c.r[15];  // 0608917C mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608917E mov.l r4,@r14
    c.r[1] = ld32(c.r[14]);  // 06089180 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06089182 tst r1,r1
    if (!c.t) { goto L_060891CC; }  // 06089184 bf 0x060891CC
    c.r[1] = 0x0u;  // 06089186 mov #0,r1
    st32(c.r[14] + 4, c.r[1]);  // 06089188 mov.l r1,@(4,r14)
L_0608918A:
    c.r[1] = ld32(c.r[14] + 4);  // 0608918A mov.l @(4,r14),r1
    c.r[2] = 0x1Fu;  // 0608918C mov #31,r2
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 0608918E cmp/gt r2,r1
    if (!c.t) { goto L_06089196; }  // 06089190 bf 0x06089196
    goto L_060891C8;  // 06089192 bra 0x060891C8 ; nop
L_06089196:
    c.r[1] = ld32(c.r[14] + 4);  // 06089196 mov.l @(4,r14),r1
    c.r[4] = c.r[1];  // 06089198 mov r1,r4
    c.r[8] = ld32(0x060891F0u);  // 0608919A mov.l 0x060891F0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060891A0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060891A0u) return; }  // 0608919C jsr @r8 ; nop
    st32(c.r[14], c.r[0]);  // 060891A0 mov.l r0,@r14
    c.r[1] = ld32(c.r[14]);  // 060891A2 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060891A4 tst r1,r1
    if (c.t) { goto L_060891BA; }  // 060891A6 bt 0x060891BA
    c.r[2] = ld32(c.r[14]);  // 060891A8 mov.l @r14,r2
    c.r[1] = ld32(c.r[2]);  // 060891AA mov.l @r2,r1
    c.r[2] = c.r[1];  // 060891AC mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x060891ECu);  // 060891AE mov.w 0x060891EC,r3
    c.r[1] += c.r[3];  // 060891B0 add r3,r1
    c.r[2] = ld32(c.r[1]);  // 060891B2 mov.l @r1,r2
    c.r[4] = ld32(c.r[14]);  // 060891B4 mov.l @r14,r4
    { const uint32_t x = c.r[2]; c.pr = 0x060891BAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060891BAu) return; }  // 060891B6 jsr @r2 ; nop
L_060891BA:
    c.r[2] = ld32(c.r[14] + 4);  // 060891BA mov.l @(4,r14),r2
    c.r[1] = c.r[2];  // 060891BC mov r2,r1
    c.r[1] += 1;  // 060891BE add #1,r1
    c.r[2] = c.r[1];  // 060891C0 mov r1,r2
    st32(c.r[14] + 4, c.r[2]);  // 060891C2 mov.l r2,@(4,r14)
    SH2_POLL(c); goto L_0608918A;  // 060891C4 bra 0x0608918A ; nop
L_060891C8:
    goto L_060891DE;  // 060891C8 bra 0x060891DE ; nop
L_060891CC:
    c.r[2] = ld32(c.r[14]);  // 060891CC mov.l @r14,r2
    c.r[1] = ld32(c.r[2]);  // 060891CE mov.l @r2,r1
    c.r[2] = c.r[1];  // 060891D0 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x060891ECu);  // 060891D2 mov.w 0x060891EC,r3
    c.r[1] += c.r[3];  // 060891D4 add r3,r1
    c.r[2] = ld32(c.r[1]);  // 060891D6 mov.l @r1,r2
    c.r[4] = ld32(c.r[14]);  // 060891D8 mov.l @r14,r4
    { const uint32_t x = c.r[2]; c.pr = 0x060891DEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060891DEu) return; }  // 060891DA jsr @r2 ; nop
L_060891DE:
    c.r[14] += 8;  // 060891DE add #8,r14
    c.r[15] = c.r[14];  // 060891E0 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060891E2 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060891E4 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060891E6 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060891E8 rts ; nop
}

void f_060891F4(SH2Context& c) {
    ran[1932] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060891F4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060891F6 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060891F8 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060891FA mov r15,r14
    c.r[8] = ld32(0x06089210u);  // 060891FC mov.l 0x06089210,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06089202u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06089202u) return; }  // 060891FE jsr @r8 ; nop
    c.r[15] = c.r[14];  // 06089202 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06089204 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06089206 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06089208 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608920A rts ; nop
}

void f_06089214(SH2Context& c) {
    ran[1933] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06089214 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06089216 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06089218 sts.l pr,@-r15
    c.r[15] -= 4;  // 0608921A add #-4,r15
    c.r[14] = c.r[15];  // 0608921C mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608921E mov.l r4,@r14
    c.r[1] = ld32(c.r[14]);  // 06089220 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06089222 tst r1,r1
    if (!c.t) { goto L_06089234; }  // 06089224 bf 0x06089234
    c.r[1] = (uint32_t)(int16_t)ld16(0x06089254u);  // 06089226 mov.w 0x06089254,r1
    c.r[4] = c.r[1];  // 06089228 mov r1,r4
    c.r[8] = ld32(0x06089258u);  // 0608922A mov.l 0x06089258,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06089230u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06089230u) return; }  // 0608922C jsr @r8 ; nop
    goto L_06089246;  // 06089230 bra 0x06089246 ; nop
L_06089234:
    c.r[2] = ld32(c.r[14]);  // 06089234 mov.l @r14,r2
    c.r[1] = ld32(c.r[2]);  // 06089236 mov.l @r2,r1
    c.r[2] = c.r[1];  // 06089238 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x06089256u);  // 0608923A mov.w 0x06089256,r3
    c.r[1] += c.r[3];  // 0608923C add r3,r1
    c.r[2] = ld32(c.r[1]);  // 0608923E mov.l @r1,r2
    c.r[4] = ld32(c.r[14]);  // 06089240 mov.l @r14,r4
    { const uint32_t x = c.r[2]; c.pr = 0x06089246u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06089246u) return; }  // 06089242 jsr @r2 ; nop
L_06089246:
    c.r[14] += 4;  // 06089246 add #4,r14
    c.r[15] = c.r[14];  // 06089248 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608924A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608924C mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608924E mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06089250 rts ; nop
}

void f_0608925C(SH2Context& c) {
    ran[1934] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608925C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608925E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06089260 sts.l pr,@-r15
    c.r[15] -= 4;  // 06089262 add #-4,r15
    c.r[14] = c.r[15];  // 06089264 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06089266 mov.l r4,@r14
    c.r[1] = ld32(c.r[14]);  // 06089268 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0608926A tst r1,r1
    if (!c.t) { goto L_0608927C; }  // 0608926C bf 0x0608927C
    c.r[1] = (uint32_t)(int16_t)ld16(0x06089292u);  // 0608926E mov.w 0x06089292,r1
    c.r[4] = c.r[1];  // 06089270 mov r1,r4
    c.r[8] = ld32(0x06089294u);  // 06089272 mov.l 0x06089294,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06089278u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06089278u) return; }  // 06089274 jsr @r8 ; nop
    goto L_06089284;  // 06089278 bra 0x06089284 ; nop
L_0608927C:
    c.r[4] = ld32(c.r[14]);  // 0608927C mov.l @r14,r4
    c.r[8] = ld32(0x06089298u);  // 0608927E mov.l 0x06089298,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06089284u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06089284u) return; }  // 06089280 jsr @r8 ; nop
L_06089284:
    c.r[14] += 4;  // 06089284 add #4,r14
    c.r[15] = c.r[14];  // 06089286 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06089288 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608928A mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608928C mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608928E rts ; nop
}

void f_0608929C(SH2Context& c) {
    ran[1935] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608929C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608929E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060892A0 sts.l pr,@-r15
    c.r[15] -= 8;  // 060892A2 add #-8,r15
    c.r[14] = c.r[15];  // 060892A4 mov r15,r14
    st32(c.r[14], c.r[4]);  // 060892A6 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 060892A8 mov.l r5,@(4,r14)
    c.r[1] = ld32(c.r[14]);  // 060892AA mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060892AC tst r1,r1
    if (!c.t) { goto L_060892BE; }  // 060892AE bf 0x060892BE
    c.r[1] = (uint32_t)(int16_t)ld16(0x060892D8u);  // 060892B0 mov.w 0x060892D8,r1
    c.r[4] = c.r[1];  // 060892B2 mov r1,r4
    c.r[8] = ld32(0x060892DCu);  // 060892B4 mov.l 0x060892DC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060892BAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060892BAu) return; }  // 060892B6 jsr @r8 ; nop
    goto L_060892CA;  // 060892BA bra 0x060892CA ; nop
L_060892BE:
    c.r[1] = ld32(c.r[14] + 4);  // 060892BE mov.l @(4,r14),r1
    c.r[5] = c.r[1];  // 060892C0 mov r1,r5
    c.r[4] = ld32(c.r[14]);  // 060892C2 mov.l @r14,r4
    c.r[8] = ld32(0x060892E0u);  // 060892C4 mov.l 0x060892E0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060892CAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060892CAu) return; }  // 060892C6 jsr @r8 ; nop
L_060892CA:
    c.r[14] += 8;  // 060892CA add #8,r14
    c.r[15] = c.r[14];  // 060892CC mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060892CE lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060892D0 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060892D2 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060892D4 rts ; nop
}

void f_060892E4(SH2Context& c) {
    ran[1936] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060892E4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060892E6 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060892E8 sts.l pr,@-r15
    c.r[15] -= 8;  // 060892EA add #-8,r15
    c.r[14] = c.r[15];  // 060892EC mov r15,r14
    st32(c.r[14], c.r[4]);  // 060892EE mov.l r4,@r14
    c.r[1] = ld32(c.r[14]);  // 060892F0 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060892F2 tst r1,r1
    if (!c.t) { goto L_06089306; }  // 060892F4 bf 0x06089306
    c.r[1] = (uint32_t)(int16_t)ld16(0x06089328u);  // 060892F6 mov.w 0x06089328,r1
    c.r[4] = c.r[1];  // 060892F8 mov r1,r4
    c.r[8] = ld32(0x0608932Cu);  // 060892FA mov.l 0x0608932C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06089300u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06089300u) return; }  // 060892FC jsr @r8 ; nop
    c.r[0] = 0x0u;  // 06089300 mov #0,r0
    goto L_0608931A;  // 06089302 bra 0x0608931A ; nop
L_06089306:
    c.r[1] = c.r[14];  // 06089306 mov r14,r1
    c.r[1] += 4;  // 06089308 add #4,r1
    c.r[5] = c.r[1];  // 0608930A mov r1,r5
    c.r[4] = ld32(c.r[14]);  // 0608930C mov.l @r14,r4
    c.r[8] = ld32(0x06089330u);  // 0608930E mov.l 0x06089330,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06089314u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06089314u) return; }  // 06089310 jsr @r8 ; nop
    c.r[0] = ld32(c.r[14] + 4);  // 06089314 mov.l @(4,r14),r0
    goto L_0608931A;  // 06089316 bra 0x0608931A ; nop
L_0608931A:
    c.r[14] += 8;  // 0608931A add #8,r14
    c.r[15] = c.r[14];  // 0608931C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608931E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06089320 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06089322 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06089324 rts ; nop
}

void f_06089334(SH2Context& c) {
    ran[1937] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06089334 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06089336 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06089338 sts.l pr,@-r15
    c.r[15] -= 8;  // 0608933A add #-8,r15
    c.r[14] = c.r[15];  // 0608933C mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608933E mov.l r4,@r14
    c.r[1] = ld32(c.r[14]);  // 06089340 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06089342 tst r1,r1
    if (!c.t) { goto L_06089356; }  // 06089344 bf 0x06089356
    c.r[1] = (uint32_t)(int16_t)ld16(0x06089396u);  // 06089346 mov.w 0x06089396,r1
    c.r[4] = c.r[1];  // 06089348 mov r1,r4
    c.r[8] = ld32(0x06089398u);  // 0608934A mov.l 0x06089398,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06089350u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06089350u) return; }  // 0608934C jsr @r8 ; nop
    c.r[0] = 0x0u;  // 06089350 mov #0,r0
    goto L_06089388;  // 06089352 bra 0x06089388 ; nop
L_06089356:
    c.r[4] = ld32(c.r[14]);  // 06089356 mov.l @r14,r4
    c.r[8] = ld32(0x0608939Cu);  // 06089358 mov.l 0x0608939C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608935Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608935Eu) return; }  // 0608935A jsr @r8 ; nop
    st32(c.r[14] + 4, c.r[0]);  // 0608935E mov.l r0,@(4,r14)
    c.r[1] = ld32(c.r[14] + 4);  // 06089360 mov.l @(4,r14),r1
    c.r[0] = ld32(c.r[1] + 4);  // 06089362 mov.l @(4,r1),r0
    c.r[1] = 0xFFFFFFFFu;  // 06089364 mov #-1,r1
    c.t = (int32_t)c.r[0] >= (int32_t)c.r[1];  // 06089366 cmp/ge r1,r0
    if (!c.t) { goto L_0608937C; }  // 06089368 bf 0x0608937C
    c.t = (int32_t)c.r[0] > 0;  // 0608936A cmp/pl r0
    if (!c.t) { goto L_06089376; }  // 0608936C bf 0x06089376
    c.t = c.r[0] == 0x2u;  // 0608936E cmp/eq #2,r0
    if (c.t) { goto L_06089376; }  // 06089370 bt 0x06089376
    goto L_0608937C;  // 06089372 bra 0x0608937C ; nop
L_06089376:
    c.r[0] = 0x0u;  // 06089376 mov #0,r0
    goto L_06089388;  // 06089378 bra 0x06089388 ; nop
L_0608937C:
    c.r[2] = ld32(c.r[14] + 4);  // 0608937C mov.l @(4,r14),r2
    c.r[1] = c.r[2];  // 0608937E mov r2,r1
    c.r[1] += 24;  // 06089380 add #24,r1
    c.r[0] = ld32(c.r[1] + 20);  // 06089382 mov.l @(20,r1),r0
    goto L_06089388;  // 06089384 bra 0x06089388 ; nop
L_06089388:
    c.r[14] += 8;  // 06089388 add #8,r14
    c.r[15] = c.r[14];  // 0608938A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608938C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608938E mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06089390 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06089392 rts ; nop
}

void f_060893A0(SH2Context& c) {
    ran[1938] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060893A0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060893A2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060893A4 sts.l pr,@-r15
    c.r[15] -= 8;  // 060893A6 add #-8,r15
    c.r[14] = c.r[15];  // 060893A8 mov r15,r14
    st32(c.r[14], c.r[4]);  // 060893AA mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 060893AC mov.l r5,@(4,r14)
    c.r[1] = ld32(c.r[14]);  // 060893AE mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060893B0 tst r1,r1
    if (!c.t) { goto L_060893C2; }  // 060893B2 bf 0x060893C2
    c.r[1] = (uint32_t)(int16_t)ld16(0x060893DCu);  // 060893B4 mov.w 0x060893DC,r1
    c.r[4] = c.r[1];  // 060893B6 mov r1,r4
    c.r[8] = ld32(0x060893E0u);  // 060893B8 mov.l 0x060893E0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060893BEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060893BEu) return; }  // 060893BA jsr @r8 ; nop
    goto L_060893CE;  // 060893BE bra 0x060893CE ; nop
L_060893C2:
    c.r[1] = ld32(c.r[14] + 4);  // 060893C2 mov.l @(4,r14),r1
    c.r[5] = c.r[1];  // 060893C4 mov r1,r5
    c.r[4] = ld32(c.r[14]);  // 060893C6 mov.l @r14,r4
    c.r[8] = ld32(0x060893E4u);  // 060893C8 mov.l 0x060893E4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060893CEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060893CEu) return; }  // 060893CA jsr @r8 ; nop
L_060893CE:
    c.r[14] += 8;  // 060893CE add #8,r14
    c.r[15] = c.r[14];  // 060893D0 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060893D2 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060893D4 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060893D6 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060893D8 rts ; nop
}

void f_060893E8(SH2Context& c) {
    ran[1939] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060893E8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060893EA mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060893EC sts.l pr,@-r15
    c.r[15] -= 8;  // 060893EE add #-8,r15
    c.r[14] = c.r[15];  // 060893F0 mov r15,r14
    st32(c.r[14], c.r[4]);  // 060893F2 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 060893F4 mov.l r5,@(4,r14)
    c.r[1] = ld32(c.r[14]);  // 060893F6 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060893F8 tst r1,r1
    if (!c.t) { goto L_0608940A; }  // 060893FA bf 0x0608940A
    c.r[1] = (uint32_t)(int16_t)ld16(0x06089424u);  // 060893FC mov.w 0x06089424,r1
    c.r[4] = c.r[1];  // 060893FE mov r1,r4
    c.r[8] = ld32(0x06089428u);  // 06089400 mov.l 0x06089428,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06089406u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06089406u) return; }  // 06089402 jsr @r8 ; nop
    goto L_06089416;  // 06089406 bra 0x06089416 ; nop
L_0608940A:
    c.r[1] = ld32(c.r[14] + 4);  // 0608940A mov.l @(4,r14),r1
    c.r[5] = c.r[1];  // 0608940C mov r1,r5
    c.r[4] = ld32(c.r[14]);  // 0608940E mov.l @r14,r4
    c.r[8] = ld32(0x0608942Cu);  // 06089410 mov.l 0x0608942C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06089416u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06089416u) return; }  // 06089412 jsr @r8 ; nop
L_06089416:
    c.r[14] += 8;  // 06089416 add #8,r14
    c.r[15] = c.r[14];  // 06089418 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608941A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608941C mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608941E mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06089420 rts ; nop
}

void f_06089430(SH2Context& c) {
    ran[1940] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06089430 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06089432 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06089434 sts.l pr,@-r15
    c.r[15] -= 8;  // 06089436 add #-8,r15
    c.r[14] = c.r[15];  // 06089438 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608943A mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 0608943C mov.l r5,@(4,r14)
    c.r[1] = ld32(c.r[14]);  // 0608943E mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06089440 tst r1,r1
    if (!c.t) { goto L_06089452; }  // 06089442 bf 0x06089452
    c.r[1] = (uint32_t)(int16_t)ld16(0x0608946Cu);  // 06089444 mov.w 0x0608946C,r1
    c.r[4] = c.r[1];  // 06089446 mov r1,r4
    c.r[8] = ld32(0x06089470u);  // 06089448 mov.l 0x06089470,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608944Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608944Eu) return; }  // 0608944A jsr @r8 ; nop
    goto L_0608945E;  // 0608944E bra 0x0608945E ; nop
L_06089452:
    c.r[1] = ld32(c.r[14] + 4);  // 06089452 mov.l @(4,r14),r1
    c.r[5] = c.r[1];  // 06089454 mov r1,r5
    c.r[4] = ld32(c.r[14]);  // 06089456 mov.l @r14,r4
    c.r[8] = ld32(0x06089474u);  // 06089458 mov.l 0x06089474,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608945Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608945Eu) return; }  // 0608945A jsr @r8 ; nop
L_0608945E:
    c.r[14] += 8;  // 0608945E add #8,r14
    c.r[15] = c.r[14];  // 06089460 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06089462 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06089464 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06089466 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06089468 rts ; nop
}

void f_06089478(SH2Context& c) {
    ran[1941] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06089478 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608947A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608947C sts.l pr,@-r15
    c.r[15] -= 8;  // 0608947E add #-8,r15
    c.r[14] = c.r[15];  // 06089480 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06089482 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 06089484 mov.l r5,@(4,r14)
    c.r[1] = ld32(c.r[14]);  // 06089486 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06089488 tst r1,r1
    if (!c.t) { goto L_0608949A; }  // 0608948A bf 0x0608949A
    c.r[1] = (uint32_t)(int16_t)ld16(0x060894B4u);  // 0608948C mov.w 0x060894B4,r1
    c.r[4] = c.r[1];  // 0608948E mov r1,r4
    c.r[8] = ld32(0x060894B8u);  // 06089490 mov.l 0x060894B8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06089496u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06089496u) return; }  // 06089492 jsr @r8 ; nop
    goto L_060894A6;  // 06089496 bra 0x060894A6 ; nop
L_0608949A:
    c.r[1] = ld32(c.r[14] + 4);  // 0608949A mov.l @(4,r14),r1
    c.r[5] = c.r[1];  // 0608949C mov r1,r5
    c.r[4] = ld32(c.r[14]);  // 0608949E mov.l @r14,r4
    c.r[8] = ld32(0x060894BCu);  // 060894A0 mov.l 0x060894BC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060894A6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060894A6u) return; }  // 060894A2 jsr @r8 ; nop
L_060894A6:
    c.r[14] += 8;  // 060894A6 add #8,r14
    c.r[15] = c.r[14];  // 060894A8 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060894AA lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060894AC mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060894AE mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060894B0 rts ; nop
}

void f_060894C0(SH2Context& c) {
    ran[1942] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060894C0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060894C2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060894C4 sts.l pr,@-r15
    c.r[15] -= 12;  // 060894C6 add #-12,r15
    c.r[14] = c.r[15];  // 060894C8 mov r15,r14
    st32(c.r[14], c.r[4]);  // 060894CA mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 060894CC mov.l r5,@(4,r14)
    c.r[1] = ld32(c.r[14]);  // 060894CE mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060894D0 tst r1,r1
    if (!c.t) { goto L_060894E2; }  // 060894D2 bf 0x060894E2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06089520u);  // 060894D4 mov.w 0x06089520,r1
    c.r[4] = c.r[1];  // 060894D6 mov r1,r4
    c.r[8] = ld32(0x06089524u);  // 060894D8 mov.l 0x06089524,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060894DEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060894DEu) return; }  // 060894DA jsr @r8 ; nop
    goto L_06089512;  // 060894DE bra 0x06089512 ; nop
L_060894E2:
    c.r[1] = ld32(c.r[14] + 4);  // 060894E2 mov.l @(4,r14),r1
    c.t = (int32_t)c.r[1] >= 0;  // 060894E4 cmp/pz r1
    if (!c.t) { goto L_060894F4; }  // 060894E6 bf 0x060894F4
    c.r[1] = ld32(c.r[14] + 4);  // 060894E8 mov.l @(4,r14),r1
    c.r[2] = 0x7u;  // 060894EA mov #7,r2
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 060894EC cmp/gt r2,r1
    if (c.t) { goto L_060894F4; }  // 060894EE bt 0x060894F4
    goto L_06089502;  // 060894F0 bra 0x06089502 ; nop
L_060894F4:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06089522u);  // 060894F4 mov.w 0x06089522,r1
    c.r[4] = c.r[1];  // 060894F6 mov r1,r4
    c.r[8] = ld32(0x06089524u);  // 060894F8 mov.l 0x06089524,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060894FEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060894FEu) return; }  // 060894FA jsr @r8 ; nop
    goto L_06089512;  // 060894FE bra 0x06089512 ; nop
L_06089502:
    c.r[4] = ld32(c.r[14]);  // 06089502 mov.l @r14,r4
    c.r[8] = ld32(0x06089528u);  // 06089504 mov.l 0x06089528,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608950Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608950Au) return; }  // 06089506 jsr @r8 ; nop
    st32(c.r[14] + 8, c.r[0]);  // 0608950A mov.l r0,@(8,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 0608950C mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[14] + 4);  // 0608950E mov.l @(4,r14),r2
    st32(c.r[1] + 16, c.r[2]);  // 06089510 mov.l r2,@(16,r1)
L_06089512:
    c.r[14] += 12;  // 06089512 add #12,r14
    c.r[15] = c.r[14];  // 06089514 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06089516 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06089518 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608951A mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608951C rts ; nop
}

void f_0608952C(SH2Context& c) {
    ran[1943] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608952C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608952E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06089530 sts.l pr,@-r15
    c.r[15] -= 12;  // 06089532 add #-12,r15
    c.r[14] = c.r[15];  // 06089534 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06089536 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 06089538 mov.l r5,@(4,r14)
    c.r[1] = ld32(c.r[14]);  // 0608953A mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0608953C tst r1,r1
    if (!c.t) { goto L_0608954E; }  // 0608953E bf 0x0608954E
    c.r[1] = (uint32_t)(int16_t)ld16(0x0608958Cu);  // 06089540 mov.w 0x0608958C,r1
    c.r[4] = c.r[1];  // 06089542 mov r1,r4
    c.r[8] = ld32(0x06089590u);  // 06089544 mov.l 0x06089590,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608954Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608954Au) return; }  // 06089546 jsr @r8 ; nop
    goto L_0608957E;  // 0608954A bra 0x0608957E ; nop
L_0608954E:
    c.r[1] = ld32(c.r[14] + 4);  // 0608954E mov.l @(4,r14),r1
    c.t = (int32_t)c.r[1] >= 0;  // 06089550 cmp/pz r1
    if (!c.t) { goto L_06089560; }  // 06089552 bf 0x06089560
    c.r[1] = ld32(c.r[14] + 4);  // 06089554 mov.l @(4,r14),r1
    c.r[2] = 0x7u;  // 06089556 mov #7,r2
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 06089558 cmp/gt r2,r1
    if (c.t) { goto L_06089560; }  // 0608955A bt 0x06089560
    goto L_0608956E;  // 0608955C bra 0x0608956E ; nop
L_06089560:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0608958Eu);  // 06089560 mov.w 0x0608958E,r1
    c.r[4] = c.r[1];  // 06089562 mov r1,r4
    c.r[8] = ld32(0x06089590u);  // 06089564 mov.l 0x06089590,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608956Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608956Au) return; }  // 06089566 jsr @r8 ; nop
    goto L_0608957E;  // 0608956A bra 0x0608957E ; nop
L_0608956E:
    c.r[4] = ld32(c.r[14]);  // 0608956E mov.l @r14,r4
    c.r[8] = ld32(0x06089594u);  // 06089570 mov.l 0x06089594,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06089576u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06089576u) return; }  // 06089572 jsr @r8 ; nop
    st32(c.r[14] + 8, c.r[0]);  // 06089576 mov.l r0,@(8,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 06089578 mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[14] + 4);  // 0608957A mov.l @(4,r14),r2
    st32(c.r[1] + 20, c.r[2]);  // 0608957C mov.l r2,@(20,r1)
L_0608957E:
    c.r[14] += 12;  // 0608957E add #12,r14
    c.r[15] = c.r[14];  // 06089580 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06089582 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06089584 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06089586 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06089588 rts ; nop
}

void f_06089598(SH2Context& c) {
    ran[1944] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06089598 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608959A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608959C sts.l pr,@-r15
    c.r[15] -= 8;  // 0608959E add #-8,r15
    c.r[14] = c.r[15];  // 060895A0 mov r15,r14
    st32(c.r[14], c.r[4]);  // 060895A2 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 060895A4 mov.l r5,@(4,r14)
    c.r[1] = ld32(c.r[14]);  // 060895A6 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060895A8 tst r1,r1
    if (!c.t) { goto L_060895BA; }  // 060895AA bf 0x060895BA
    c.r[1] = (uint32_t)(int16_t)ld16(0x060895D4u);  // 060895AC mov.w 0x060895D4,r1
    c.r[4] = c.r[1];  // 060895AE mov r1,r4
    c.r[8] = ld32(0x060895D8u);  // 060895B0 mov.l 0x060895D8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060895B6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060895B6u) return; }  // 060895B2 jsr @r8 ; nop
    goto L_060895C6;  // 060895B6 bra 0x060895C6 ; nop
L_060895BA:
    c.r[1] = ld32(c.r[14] + 4);  // 060895BA mov.l @(4,r14),r1
    c.r[5] = c.r[1];  // 060895BC mov r1,r5
    c.r[4] = ld32(c.r[14]);  // 060895BE mov.l @r14,r4
    c.r[8] = ld32(0x060895DCu);  // 060895C0 mov.l 0x060895DC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060895C6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060895C6u) return; }  // 060895C2 jsr @r8 ; nop
L_060895C6:
    c.r[14] += 8;  // 060895C6 add #8,r14
    c.r[15] = c.r[14];  // 060895C8 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060895CA lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060895CC mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060895CE mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060895D0 rts ; nop
}

void f_060895E0(SH2Context& c) {
    ran[1945] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060895E0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060895E2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060895E4 sts.l pr,@-r15
    c.r[15] -= 8;  // 060895E6 add #-8,r15
    c.r[14] = c.r[15];  // 060895E8 mov r15,r14
    st32(c.r[14], c.r[4]);  // 060895EA mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 060895EC mov.l r5,@(4,r14)
    c.r[1] = ld32(c.r[14]);  // 060895EE mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060895F0 tst r1,r1
    if (!c.t) { goto L_06089602; }  // 060895F2 bf 0x06089602
    c.r[1] = (uint32_t)(int16_t)ld16(0x0608961Cu);  // 060895F4 mov.w 0x0608961C,r1
    c.r[4] = c.r[1];  // 060895F6 mov r1,r4
    c.r[8] = ld32(0x06089620u);  // 060895F8 mov.l 0x06089620,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060895FEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060895FEu) return; }  // 060895FA jsr @r8 ; nop
    goto L_0608960E;  // 060895FE bra 0x0608960E ; nop
L_06089602:
    c.r[1] = ld32(c.r[14] + 4);  // 06089602 mov.l @(4,r14),r1
    c.r[5] = c.r[1];  // 06089604 mov r1,r5
    c.r[4] = ld32(c.r[14]);  // 06089606 mov.l @r14,r4
    c.r[8] = ld32(0x06089624u);  // 06089608 mov.l 0x06089624,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608960Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608960Eu) return; }  // 0608960A jsr @r8 ; nop
L_0608960E:
    c.r[14] += 8;  // 0608960E add #8,r14
    c.r[15] = c.r[14];  // 06089610 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06089612 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06089614 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06089616 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06089618 rts ; nop
}

void f_06089628(SH2Context& c) {
    ran[1946] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06089628 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608962A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608962C sts.l pr,@-r15
    c.r[15] -= 12;  // 0608962E add #-12,r15
    c.r[14] = c.r[15];  // 06089630 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06089632 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 06089634 mov.l r5,@(4,r14)
    st32(c.r[14] + 8, c.r[6]);  // 06089636 mov.l r6,@(8,r14)
    c.r[1] = ld32(c.r[14]);  // 06089638 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0608963A tst r1,r1
    if (!c.t) { goto L_0608964C; }  // 0608963C bf 0x0608964C
    c.r[1] = (uint32_t)(int16_t)ld16(0x0608966Au);  // 0608963E mov.w 0x0608966A,r1
    c.r[4] = c.r[1];  // 06089640 mov r1,r4
    c.r[8] = ld32(0x0608966Cu);  // 06089642 mov.l 0x0608966C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06089648u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06089648u) return; }  // 06089644 jsr @r8 ; nop
    goto L_0608965C;  // 06089648 bra 0x0608965C ; nop
L_0608964C:
    c.r[1] = ld32(c.r[14] + 8);  // 0608964C mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[14] + 4);  // 0608964E mov.l @(4,r14),r2
    c.r[6] = c.r[1];  // 06089650 mov r1,r6
    c.r[5] = c.r[2];  // 06089652 mov r2,r5
    c.r[4] = ld32(c.r[14]);  // 06089654 mov.l @r14,r4
    c.r[8] = ld32(0x06089670u);  // 06089656 mov.l 0x06089670,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608965Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608965Cu) return; }  // 06089658 jsr @r8 ; nop
L_0608965C:
    c.r[14] += 12;  // 0608965C add #12,r14
    c.r[15] = c.r[14];  // 0608965E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06089660 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06089662 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06089664 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06089666 rts ; nop
}

void f_06089674(SH2Context& c) {
    ran[1947] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06089674 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06089676 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06089678 sts.l pr,@-r15
    c.r[15] -= 4;  // 0608967A add #-4,r15
    c.r[14] = c.r[15];  // 0608967C mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608967E mov.l r4,@r14
    c.r[1] = ld32(c.r[14]);  // 06089680 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06089682 tst r1,r1
    if (!c.t) { goto L_06089694; }  // 06089684 bf 0x06089694
    c.r[1] = (uint32_t)(int16_t)ld16(0x060896AAu);  // 06089686 mov.w 0x060896AA,r1
    c.r[4] = c.r[1];  // 06089688 mov r1,r4
    c.r[8] = ld32(0x060896ACu);  // 0608968A mov.l 0x060896AC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06089690u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06089690u) return; }  // 0608968C jsr @r8 ; nop
    goto L_0608969C;  // 06089690 bra 0x0608969C ; nop
L_06089694:
    c.r[4] = ld32(c.r[14]);  // 06089694 mov.l @r14,r4
    c.r[8] = ld32(0x060896B0u);  // 06089696 mov.l 0x060896B0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608969Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608969Cu) return; }  // 06089698 jsr @r8 ; nop
L_0608969C:
    c.r[14] += 4;  // 0608969C add #4,r14
    c.r[15] = c.r[14];  // 0608969E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060896A0 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060896A2 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060896A4 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060896A6 rts ; nop
}

void f_060896B4(SH2Context& c) {
    ran[1948] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060896B4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060896B6 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060896B8 sts.l pr,@-r15
    c.r[15] -= 8;  // 060896BA add #-8,r15
    c.r[14] = c.r[15];  // 060896BC mov r15,r14
    st32(c.r[14], c.r[4]);  // 060896BE mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 060896C0 mov.l r5,@(4,r14)
    c.r[1] = ld32(c.r[14]);  // 060896C2 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060896C4 tst r1,r1
    if (!c.t) { goto L_060896D6; }  // 060896C6 bf 0x060896D6
    c.r[1] = (uint32_t)(int16_t)ld16(0x060896F0u);  // 060896C8 mov.w 0x060896F0,r1
    c.r[4] = c.r[1];  // 060896CA mov r1,r4
    c.r[8] = ld32(0x060896F4u);  // 060896CC mov.l 0x060896F4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060896D2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060896D2u) return; }  // 060896CE jsr @r8 ; nop
    goto L_060896E2;  // 060896D2 bra 0x060896E2 ; nop
L_060896D6:
    c.r[1] = ld32(c.r[14] + 4);  // 060896D6 mov.l @(4,r14),r1
    c.r[5] = c.r[1];  // 060896D8 mov r1,r5
    c.r[4] = ld32(c.r[14]);  // 060896DA mov.l @r14,r4
    c.r[8] = ld32(0x060896F8u);  // 060896DC mov.l 0x060896F8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060896E2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060896E2u) return; }  // 060896DE jsr @r8 ; nop
L_060896E2:
    c.r[14] += 8;  // 060896E2 add #8,r14
    c.r[15] = c.r[14];  // 060896E4 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060896E6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060896E8 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060896EA mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060896EC rts ; nop
}

void f_060896FC(SH2Context& c) {
    ran[1949] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060896FC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060896FE mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06089700 sts.l pr,@-r15
    c.r[15] -= 8;  // 06089702 add #-8,r15
    c.r[14] = c.r[15];  // 06089704 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06089706 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 06089708 mov.l r5,@(4,r14)
    c.r[1] = ld32(c.r[14] + 4);  // 0608970A mov.l @(4,r14),r1
    c.r[5] = c.r[1];  // 0608970C mov r1,r5
    c.r[4] = ld32(c.r[14]);  // 0608970E mov.l @r14,r4
    c.r[8] = ld32(0x06089724u);  // 06089710 mov.l 0x06089724,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06089716u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06089716u) return; }  // 06089712 jsr @r8 ; nop
    c.r[14] += 8;  // 06089716 add #8,r14
    c.r[15] = c.r[14];  // 06089718 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608971A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608971C mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608971E mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06089720 rts ; nop
}

void f_06089728(SH2Context& c) {
    ran[1950] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06089728 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608972A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608972C sts.l pr,@-r15
    c.r[15] -= 8;  // 0608972E add #-8,r15
    c.r[14] = c.r[15];  // 06089730 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06089732 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 06089734 mov.l r5,@(4,r14)
    c.r[1] = ld32(c.r[14] + 4);  // 06089736 mov.l @(4,r14),r1
    c.r[5] = c.r[1];  // 06089738 mov r1,r5
    c.r[4] = ld32(c.r[14]);  // 0608973A mov.l @r14,r4
    c.r[8] = ld32(0x06089750u);  // 0608973C mov.l 0x06089750,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06089742u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06089742u) return; }  // 0608973E jsr @r8 ; nop
    c.r[14] += 8;  // 06089742 add #8,r14
    c.r[15] = c.r[14];  // 06089744 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06089746 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06089748 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608974A mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608974C rts ; nop
}

void f_06089754(SH2Context& c) {
    ran[1951] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06089754 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06089756 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06089758 sts.l pr,@-r15
    c.r[15] -= 4;  // 0608975A add #-4,r15
    c.r[14] = c.r[15];  // 0608975C mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608975E mov.l r4,@r14
    c.r[4] = ld32(c.r[14]);  // 06089760 mov.l @r14,r4
    c.r[8] = ld32(0x06089778u);  // 06089762 mov.l 0x06089778,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06089768u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06089768u) return; }  // 06089764 jsr @r8 ; nop
    c.r[14] += 4;  // 06089768 add #4,r14
    c.r[15] = c.r[14];  // 0608976A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608976C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608976E mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06089770 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06089772 rts ; nop
}

void f_0608977C(SH2Context& c) {
    ran[1952] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608977C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608977E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06089780 sts.l pr,@-r15
    c.r[15] -= 16;  // 06089782 add #-16,r15
    c.r[14] = c.r[15];  // 06089784 mov r15,r14
    c.r[1] = 0x0u;  // 06089786 mov #0,r1
    st32(c.r[14] + 4, c.r[1]);  // 06089788 mov.l r1,@(4,r14)
    c.r[8] = ld32(0x06089834u);  // 0608978A mov.l 0x06089834,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06089790u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06089790u) return; }  // 0608978C jsr @r8 ; nop
    st32(c.r[14] + 8, c.r[0]);  // 06089790 mov.l r0,@(8,r14)
    c.r[1] = 0x0u;  // 06089792 mov #0,r1
    st32(c.r[14] + 12, c.r[1]);  // 06089794 mov.l r1,@(12,r14)
L_06089796:
    c.r[1] = ld32(c.r[14] + 12);  // 06089796 mov.l @(12,r14),r1
    c.r[2] = 0x1Fu;  // 06089798 mov #31,r2
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 0608979A cmp/gt r2,r1
    if (!c.t) { goto L_060897A2; }  // 0608979C bf 0x060897A2
    goto L_060897CE;  // 0608979E bra 0x060897CE ; nop
L_060897A2:
    c.r[1] = ld32(c.r[14] + 12);  // 060897A2 mov.l @(12,r14),r1
    c.r[4] = c.r[1];  // 060897A4 mov r1,r4
    c.r[8] = ld32(0x06089838u);  // 060897A6 mov.l 0x06089838,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060897ACu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060897ACu) return; }  // 060897A8 jsr @r8 ; nop
    st32(c.r[14] + 4, c.r[0]);  // 060897AC mov.l r0,@(4,r14)
    c.r[1] = ld32(c.r[14] + 4);  // 060897AE mov.l @(4,r14),r1
    c.r[2] = ld32(c.r[14] + 8);  // 060897B0 mov.l @(8,r14),r2
    c.t = c.r[1] == c.r[2];  // 060897B2 cmp/eq r2,r1
    if (c.t) { goto L_060897C0; }  // 060897B4 bt 0x060897C0
    c.r[1] = ld32(c.r[14] + 4);  // 060897B6 mov.l @(4,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060897B8 tst r1,r1
    if (c.t) { goto L_060897C0; }  // 060897BA bt 0x060897C0
    goto L_060897CE;  // 060897BC bra 0x060897CE ; nop
L_060897C0:
    c.r[2] = ld32(c.r[14] + 12);  // 060897C0 mov.l @(12,r14),r2
    c.r[1] = c.r[2];  // 060897C2 mov r2,r1
    c.r[1] += 1;  // 060897C4 add #1,r1
    c.r[2] = c.r[1];  // 060897C6 mov r1,r2
    st32(c.r[14] + 12, c.r[2]);  // 060897C8 mov.l r2,@(12,r14)
    SH2_POLL(c); goto L_06089796;  // 060897CA bra 0x06089796 ; nop
L_060897CE:
    c.r[8] = ld32(0x0608983Cu);  // 060897CE mov.l 0x0608983C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060897D4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060897D4u) return; }  // 060897D0 jsr @r8 ; nop
    st32(c.r[14], c.r[0]);  // 060897D4 mov.l r0,@r14
    c.r[1] = ld32(c.r[14]);  // 060897D6 mov.l @r14,r1
    c.r[3] = 0x3u;  // 060897D8 mov #3,r3
    c.r[2] = 0x0u;  // 060897DA mov #0,r2
    c.r[1] -= c.r[2];  // 060897DC sub r2,r1
    c.t = c.r[1] > c.r[3];  // 060897DE cmp/hi r3,r1
    if (c.t) { goto L_06089814; }  // 060897E0 bt 0x06089814
    c.r[1] += c.r[1];  // 060897E2 add r1,r1
    c.r[0] = 0x060897F0u;  // 060897E4 mova 0x060897F0,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 060897E6 mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 060897E8 add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x060897F8u: goto L_060897F8; case 0x06089814u: goto L_06089814; case 0x06089806u: goto L_06089806; default: sh2_call(c, x); return; } }  // 060897EA jmp @r0 ; nop
L_060897F8:
    c.r[1] = ld32(c.r[14] + 4);  // 060897F8 mov.l @(4,r14),r1
    c.r[4] = c.r[1];  // 060897FA mov r1,r4
    c.r[8] = ld32(0x06089840u);  // 060897FC mov.l 0x06089840,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06089802u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06089802u) return; }  // 060897FE jsr @r8 ; nop
    goto L_06089822;  // 06089802 bra 0x06089822 ; nop
L_06089806:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06089830u);  // 06089806 mov.w 0x06089830,r1
    c.r[4] = c.r[1];  // 06089808 mov r1,r4
    c.r[8] = ld32(0x06089844u);  // 0608980A mov.l 0x06089844,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06089810u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06089810u) return; }  // 0608980C jsr @r8 ; nop
    goto L_06089822;  // 06089810 bra 0x06089822 ; nop
L_06089814:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06089832u);  // 06089814 mov.w 0x06089832,r1
    c.r[4] = c.r[1];  // 06089816 mov r1,r4
    c.r[8] = ld32(0x06089844u);  // 06089818 mov.l 0x06089844,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608981Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608981Eu) return; }  // 0608981A jsr @r8 ; nop
    goto L_06089822;  // 0608981E bra 0x06089822 ; nop
L_06089822:
    c.r[14] += 16;  // 06089822 add #16,r14
    c.r[15] = c.r[14];  // 06089824 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06089826 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06089828 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608982A mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608982C rts ; nop
}

void f_06089848(SH2Context& c) {
    ran[1953] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06089848 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608984A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608984C sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0608984E mov r15,r14
    c.r[8] = ld32(0x0608986Cu);  // 06089850 mov.l 0x0608986C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06089856u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06089856u) return; }  // 06089852 jsr @r8 ; nop
    c.r[1] = c.r[0];  // 06089856 mov r0,r1
    c.r[0] = c.r[1];  // 06089858 mov r1,r0
    goto L_0608985E;  // 0608985A bra 0x0608985E ; nop
L_0608985E:
    c.r[15] = c.r[14];  // 0608985E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06089860 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06089862 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06089864 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06089866 rts ; nop
}

void f_06089870(SH2Context& c) {
    ran[1954] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06089870 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06089872 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06089874 sts.l pr,@-r15
    c.r[15] -= 8;  // 06089876 add #-8,r15
    c.r[14] = c.r[15];  // 06089878 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608987A mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 0608987C mov.l r5,@(4,r14)
    c.r[1] = ld32(c.r[14]);  // 0608987E mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06089880 tst r1,r1
    if (!c.t) { goto L_06089892; }  // 06089882 bf 0x06089892
    c.r[1] = (uint32_t)(int16_t)ld16(0x060898CAu);  // 06089884 mov.w 0x060898CA,r1
    c.r[4] = c.r[1];  // 06089886 mov r1,r4
    c.r[8] = ld32(0x060898D0u);  // 06089888 mov.l 0x060898D0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608988Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608988Eu) return; }  // 0608988A jsr @r8 ; nop
    goto L_060898BC;  // 0608988E bra 0x060898BC ; nop
L_06089892:
    c.r[1] = ld32(c.r[14] + 4);  // 06089892 mov.l @(4,r14),r1
    c.t = (int32_t)c.r[1] > 0;  // 06089894 cmp/pl r1
    if (c.t) { goto L_060898A6; }  // 06089896 bt 0x060898A6
    c.r[1] = (uint32_t)(int16_t)ld16(0x060898CCu);  // 06089898 mov.w 0x060898CC,r1
    c.r[4] = c.r[1];  // 0608989A mov r1,r4
    c.r[8] = ld32(0x060898D0u);  // 0608989C mov.l 0x060898D0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060898A2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060898A2u) return; }  // 0608989E jsr @r8 ; nop
    goto L_060898BC;  // 060898A2 bra 0x060898BC ; nop
L_060898A6:
    c.r[2] = ld32(c.r[14]);  // 060898A6 mov.l @r14,r2
    c.r[1] = ld32(c.r[2]);  // 060898A8 mov.l @r2,r1
    c.r[2] = c.r[1];  // 060898AA mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x060898CEu);  // 060898AC mov.w 0x060898CE,r3
    c.r[1] += c.r[3];  // 060898AE add r3,r1
    c.r[2] = ld32(c.r[14] + 4);  // 060898B0 mov.l @(4,r14),r2
    c.r[1] = ld32(c.r[1]);  // 060898B2 mov.l @r1,r1
    c.r[5] = c.r[2];  // 060898B4 mov r2,r5
    c.r[4] = ld32(c.r[14]);  // 060898B6 mov.l @r14,r4
    { const uint32_t x = c.r[1]; c.pr = 0x060898BCu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060898BCu) return; }  // 060898B8 jsr @r1 ; nop
L_060898BC:
    c.r[14] += 8;  // 060898BC add #8,r14
    c.r[15] = c.r[14];  // 060898BE mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060898C0 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060898C2 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060898C4 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060898C6 rts ; nop
}

void f_060898D4(SH2Context& c) {
    ran[1955] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060898D4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060898D6 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060898D8 sts.l pr,@-r15
    c.r[15] -= 8;  // 060898DA add #-8,r15
    c.r[14] = c.r[15];  // 060898DC mov r15,r14
    st32(c.r[14], c.r[4]);  // 060898DE mov.l r4,@r14
    c.r[1] = ld32(c.r[14]);  // 060898E0 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060898E2 tst r1,r1
    if (!c.t) { goto L_060898F6; }  // 060898E4 bf 0x060898F6
    c.r[1] = (uint32_t)(int16_t)ld16(0x06089916u);  // 060898E6 mov.w 0x06089916,r1
    c.r[4] = c.r[1];  // 060898E8 mov r1,r4
    c.r[8] = ld32(0x06089918u);  // 060898EA mov.l 0x06089918,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060898F0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060898F0u) return; }  // 060898EC jsr @r8 ; nop
    c.r[0] = 0xFFFFFFFFu;  // 060898F0 mov #-1,r0
    goto L_06089908;  // 060898F2 bra 0x06089908 ; nop
L_060898F6:
    c.r[4] = ld32(c.r[14]);  // 060898F6 mov.l @r14,r4
    c.r[8] = ld32(0x0608991Cu);  // 060898F8 mov.l 0x0608991C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060898FEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060898FEu) return; }  // 060898FA jsr @r8 ; nop
    st32(c.r[14] + 4, c.r[0]);  // 060898FE mov.l r0,@(4,r14)
    c.r[1] = ld32(c.r[14] + 4);  // 06089900 mov.l @(4,r14),r1
    c.r[0] = ld32(c.r[1] + 4);  // 06089902 mov.l @(4,r1),r0
    goto L_06089908;  // 06089904 bra 0x06089908 ; nop
L_06089908:
    c.r[14] += 8;  // 06089908 add #8,r14
    c.r[15] = c.r[14];  // 0608990A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608990C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608990E mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06089910 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06089912 rts ; nop
}

void f_06089920(SH2Context& c) {
    ran[1956] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06089920 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06089922 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06089924 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06089926 mov r15,r14
    c.r[8] = ld32(0x06089944u);  // 06089928 mov.l 0x06089944,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608992Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608992Eu) return; }  // 0608992A jsr @r8 ; nop
    c.r[1] = c.r[0];  // 0608992E mov r0,r1
    c.r[0] = c.r[1];  // 06089930 mov r1,r0
    goto L_06089936;  // 06089932 bra 0x06089936 ; nop
L_06089936:
    c.r[15] = c.r[14];  // 06089936 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06089938 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608993A mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608993C mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608993E rts ; nop
}

void f_06089948(SH2Context& c) {
    ran[1957] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06089948 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608994A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608994C sts.l pr,@-r15
    c.r[15] -= 8;  // 0608994E add #-8,r15
    c.r[14] = c.r[15];  // 06089950 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06089952 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 06089954 mov.l r5,@(4,r14)
    c.r[1] = ld32(c.r[14] + 4);  // 06089956 mov.l @(4,r14),r1
    c.r[5] = c.r[1];  // 06089958 mov r1,r5
    c.r[4] = ld32(c.r[14]);  // 0608995A mov.l @r14,r4
    c.r[8] = ld32(0x06089970u);  // 0608995C mov.l 0x06089970,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06089962u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06089962u) return; }  // 0608995E jsr @r8 ; nop
    c.r[14] += 8;  // 06089962 add #8,r14
    c.r[15] = c.r[14];  // 06089964 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06089966 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06089968 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608996A mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608996C rts ; nop
}

void f_06089974(SH2Context& c) {
    ran[1958] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06089974 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06089976 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06089978 sts.l pr,@-r15
    c.r[15] -= 16;  // 0608997A add #-16,r15
    c.r[14] = c.r[15];  // 0608997C mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608997E mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 06089980 mov.l r5,@(4,r14)
    st32(c.r[14] + 8, c.r[6]);  // 06089982 mov.l r6,@(8,r14)
    c.r[1] = ld32(c.r[14]);  // 06089984 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06089986 tst r1,r1
    if (!c.t) { goto L_0608999A; }  // 06089988 bf 0x0608999A
    c.r[1] = (uint32_t)(int16_t)ld16(0x060899C4u);  // 0608998A mov.w 0x060899C4,r1
    c.r[4] = c.r[1];  // 0608998C mov r1,r4
    c.r[8] = ld32(0x060899C8u);  // 0608998E mov.l 0x060899C8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06089994u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06089994u) return; }  // 06089990 jsr @r8 ; nop
    c.r[0] = 0x0u;  // 06089994 mov #0,r0
    goto L_060899B6;  // 06089996 bra 0x060899B6 ; nop
L_0608999A:
    c.r[1] = ld32(c.r[14] + 8);  // 0608999A mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[14] + 4);  // 0608999C mov.l @(4,r14),r2
    c.r[3] = c.r[14];  // 0608999E mov r14,r3
    c.r[3] += 12;  // 060899A0 add #12,r3
    c.r[7] = c.r[1];  // 060899A2 mov r1,r7
    c.r[6] = c.r[2];  // 060899A4 mov r2,r6
    c.r[5] = c.r[3];  // 060899A6 mov r3,r5
    c.r[4] = ld32(c.r[14]);  // 060899A8 mov.l @r14,r4
    c.r[8] = ld32(0x060899CCu);  // 060899AA mov.l 0x060899CC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060899B0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060899B0u) return; }  // 060899AC jsr @r8 ; nop
    c.r[0] = ld32(c.r[14] + 12);  // 060899B0 mov.l @(12,r14),r0
    goto L_060899B6;  // 060899B2 bra 0x060899B6 ; nop
L_060899B6:
    c.r[14] += 16;  // 060899B6 add #16,r14
    c.r[15] = c.r[14];  // 060899B8 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060899BA lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060899BC mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060899BE mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 060899C0 rts ; nop
}

void f_060899D0(SH2Context& c) {
    ran[1959] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060899D0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060899D2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060899D4 sts.l pr,@-r15
    c.r[15] -= 8;  // 060899D6 add #-8,r15
    c.r[14] = c.r[15];  // 060899D8 mov r15,r14
    st32(c.r[14], c.r[4]);  // 060899DA mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 060899DC mov.l r5,@(4,r14)
    c.r[1] = ld32(c.r[14]);  // 060899DE mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060899E0 tst r1,r1
    if (!c.t) { goto L_060899F2; }  // 060899E2 bf 0x060899F2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06089A20u);  // 060899E4 mov.w 0x06089A20,r1
    c.r[4] = c.r[1];  // 060899E6 mov r1,r4
    c.r[8] = ld32(0x06089A24u);  // 060899E8 mov.l 0x06089A24,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060899EEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060899EEu) return; }  // 060899EA jsr @r8 ; nop
    goto L_06089A12;  // 060899EE bra 0x06089A12 ; nop
L_060899F2:
    c.r[1] = ld32(c.r[14] + 4);  // 060899F2 mov.l @(4,r14),r1
    c.t = (int32_t)c.r[1] >= 0;  // 060899F4 cmp/pz r1
    if (c.t) { goto L_06089A06; }  // 060899F6 bt 0x06089A06
    c.r[1] = (uint32_t)(int16_t)ld16(0x06089A22u);  // 060899F8 mov.w 0x06089A22,r1
    c.r[4] = c.r[1];  // 060899FA mov r1,r4
    c.r[8] = ld32(0x06089A24u);  // 060899FC mov.l 0x06089A24,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06089A02u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06089A02u) return; }  // 060899FE jsr @r8 ; nop
    goto L_06089A12;  // 06089A02 bra 0x06089A12 ; nop
L_06089A06:
    c.r[1] = ld32(c.r[14] + 4);  // 06089A06 mov.l @(4,r14),r1
    c.r[5] = c.r[1];  // 06089A08 mov r1,r5
    c.r[4] = ld32(c.r[14]);  // 06089A0A mov.l @r14,r4
    c.r[8] = ld32(0x06089A28u);  // 06089A0C mov.l 0x06089A28,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06089A12u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06089A12u) return; }  // 06089A0E jsr @r8 ; nop
L_06089A12:
    c.r[14] += 8;  // 06089A12 add #8,r14
    c.r[15] = c.r[14];  // 06089A14 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06089A16 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06089A18 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06089A1A mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06089A1C rts ; nop
}

void f_06089A2C(SH2Context& c) {
    ran[1960] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06089A2C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06089A2E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06089A30 sts.l pr,@-r15
    c.r[15] -= 8;  // 06089A32 add #-8,r15
    c.r[14] = c.r[15];  // 06089A34 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06089A36 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 06089A38 mov.l r5,@(4,r14)
    c.r[1] = ld32(c.r[14]);  // 06089A3A mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06089A3C tst r1,r1
    if (!c.t) { goto L_06089A50; }  // 06089A3E bf 0x06089A50
    c.r[1] = (uint32_t)(int16_t)ld16(0x06089A92u);  // 06089A40 mov.w 0x06089A92,r1
    c.r[4] = c.r[1];  // 06089A42 mov r1,r4
    c.r[8] = ld32(0x06089A98u);  // 06089A44 mov.l 0x06089A98,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06089A4Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06089A4Au) return; }  // 06089A46 jsr @r8 ; nop
    c.r[0] = 0x0u;  // 06089A4A mov #0,r0
    goto L_06089A84;  // 06089A4C bra 0x06089A84 ; nop
L_06089A50:
    c.r[1] = ld32(c.r[14] + 4);  // 06089A50 mov.l @(4,r14),r1
    c.t = (int32_t)c.r[1] > 0;  // 06089A52 cmp/pl r1
    if (c.t) { goto L_06089A66; }  // 06089A54 bt 0x06089A66
    c.r[1] = (uint32_t)(int16_t)ld16(0x06089A94u);  // 06089A56 mov.w 0x06089A94,r1
    c.r[4] = c.r[1];  // 06089A58 mov r1,r4
    c.r[8] = ld32(0x06089A98u);  // 06089A5A mov.l 0x06089A98,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06089A60u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06089A60u) return; }  // 06089A5C jsr @r8 ; nop
    c.r[0] = 0x0u;  // 06089A60 mov #0,r0
    goto L_06089A84;  // 06089A62 bra 0x06089A84 ; nop
L_06089A66:
    c.r[2] = ld32(c.r[14]);  // 06089A66 mov.l @r14,r2
    c.r[1] = ld32(c.r[2]);  // 06089A68 mov.l @r2,r1
    c.r[2] = c.r[1];  // 06089A6A mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x06089A96u);  // 06089A6C mov.w 0x06089A96,r3
    c.r[1] += c.r[3];  // 06089A6E add r3,r1
    c.r[2] = ld32(c.r[14] + 4);  // 06089A70 mov.l @(4,r14),r2
    c.r[1] = ld32(c.r[1]);  // 06089A72 mov.l @r1,r1
    c.r[5] = c.r[2];  // 06089A74 mov r2,r5
    c.r[4] = ld32(c.r[14]);  // 06089A76 mov.l @r14,r4
    { const uint32_t x = c.r[1]; c.pr = 0x06089A7Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06089A7Cu) return; }  // 06089A78 jsr @r1 ; nop
    c.r[1] = c.r[0];  // 06089A7C mov r0,r1
    c.r[0] = c.r[1];  // 06089A7E mov r1,r0
    goto L_06089A84;  // 06089A80 bra 0x06089A84 ; nop
L_06089A84:
    c.r[14] += 8;  // 06089A84 add #8,r14
    c.r[15] = c.r[14];  // 06089A86 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06089A88 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06089A8A mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06089A8C mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06089A8E rts ; nop
}

void f_06089A9C(SH2Context& c) {
    ran[1961] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06089A9C mov.l r14,@-r15
    c.r[15] -= 8;  // 06089A9E add #-8,r15
    c.r[14] = c.r[15];  // 06089AA0 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06089AA2 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 06089AA4 mov.l r5,@(4,r14)
    c.r[0] = 0x0u;  // 06089AA6 mov #0,r0
    goto L_06089AAC;  // 06089AA8 bra 0x06089AAC ; nop
L_06089AAC:
    c.r[14] += 8;  // 06089AAC add #8,r14
    c.r[15] = c.r[14];  // 06089AAE mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06089AB0 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06089AB2 rts ; nop
}

void f_06089AB8(SH2Context& c) {
    ran[1962] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06089AB8 mov.l r14,@-r15
    c.r[15] -= 8;  // 06089ABA add #-8,r15
    c.r[14] = c.r[15];  // 06089ABC mov r15,r14
    st32(c.r[14], c.r[4]);  // 06089ABE mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 06089AC0 mov.l r5,@(4,r14)
    goto L_06089AC6;  // 06089AC2 bra 0x06089AC6 ; nop
L_06089AC6:
    c.r[14] += 8;  // 06089AC6 add #8,r14
    c.r[15] = c.r[14];  // 06089AC8 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06089ACA mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06089ACC rts ; nop
}

void f_06089AD0(SH2Context& c) {
    ran[1963] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06089AD0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06089AD2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06089AD4 sts.l pr,@-r15
    c.r[15] -= 8;  // 06089AD6 add #-8,r15
    c.r[14] = c.r[15];  // 06089AD8 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06089ADA mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 06089ADC mov.l r5,@(4,r14)
    c.r[1] = ld32(c.r[14]);  // 06089ADE mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06089AE0 tst r1,r1
    if (!c.t) { goto L_06089AF2; }  // 06089AE2 bf 0x06089AF2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06089B16u);  // 06089AE4 mov.w 0x06089B16,r1
    c.r[4] = c.r[1];  // 06089AE6 mov r1,r4
    c.r[8] = ld32(0x06089B1Cu);  // 06089AE8 mov.l 0x06089B1C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06089AEEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06089AEEu) return; }  // 06089AEA jsr @r8 ; nop
    goto L_06089B08;  // 06089AEE bra 0x06089B08 ; nop
L_06089AF2:
    c.r[2] = ld32(c.r[14]);  // 06089AF2 mov.l @r14,r2
    c.r[1] = ld32(c.r[2]);  // 06089AF4 mov.l @r2,r1
    c.r[2] = c.r[1];  // 06089AF6 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x06089B18u);  // 06089AF8 mov.w 0x06089B18,r3
    c.r[1] += c.r[3];  // 06089AFA add r3,r1
    c.r[2] = ld32(c.r[14] + 4);  // 06089AFC mov.l @(4,r14),r2
    c.r[1] = ld32(c.r[1]);  // 06089AFE mov.l @r1,r1
    c.r[5] = c.r[2];  // 06089B00 mov r2,r5
    c.r[4] = ld32(c.r[14]);  // 06089B02 mov.l @r14,r4
    { const uint32_t x = c.r[1]; c.pr = 0x06089B08u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06089B08u) return; }  // 06089B04 jsr @r1 ; nop
L_06089B08:
    c.r[14] += 8;  // 06089B08 add #8,r14
    c.r[15] = c.r[14];  // 06089B0A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06089B0C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06089B0E mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06089B10 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06089B12 rts ; nop
}

void f_06089B20(SH2Context& c) {
    ran[1964] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06089B20 mov.l r14,@-r15
    c.r[15] -= 8;  // 06089B22 add #-8,r15
    c.r[14] = c.r[15];  // 06089B24 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06089B26 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 06089B28 mov.l r5,@(4,r14)
    goto L_06089B2E;  // 06089B2A bra 0x06089B2E ; nop
L_06089B2E:
    c.r[14] += 8;  // 06089B2E add #8,r14
    c.r[15] = c.r[14];  // 06089B30 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06089B32 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06089B34 rts ; nop
}

void f_06089B38(SH2Context& c) {
    ran[1965] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06089B38 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06089B3A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06089B3C sts.l pr,@-r15
    c.r[15] -= 8;  // 06089B3E add #-8,r15
    c.r[14] = c.r[15];  // 06089B40 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06089B42 mov.l r4,@r14
    c.r[1] = ld32(c.r[14]);  // 06089B44 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06089B46 tst r1,r1
    if (!c.t) { goto L_06089B5A; }  // 06089B48 bf 0x06089B5A
    c.r[1] = (uint32_t)(int16_t)ld16(0x06089B9Eu);  // 06089B4A mov.w 0x06089B9E,r1
    c.r[4] = c.r[1];  // 06089B4C mov r1,r4
    c.r[8] = ld32(0x06089BA0u);  // 06089B4E mov.l 0x06089BA0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06089B54u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06089B54u) return; }  // 06089B50 jsr @r8 ; nop
    c.r[0] = 0x1u;  // 06089B54 mov #1,r0
    goto L_06089B90;  // 06089B56 bra 0x06089B90 ; nop
L_06089B5A:
    c.r[4] = ld32(c.r[14]);  // 06089B5A mov.l @r14,r4
    c.r[8] = ld32(0x06089BA4u);  // 06089B5C mov.l 0x06089BA4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06089B62u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06089B62u) return; }  // 06089B5E jsr @r8 ; nop
    c.t = (c.r[0] & c.r[0]) == 0;  // 06089B62 tst r0,r0
    if (!c.t) { goto L_06089B6C; }  // 06089B64 bf 0x06089B6C
    c.r[0] = 0x1u;  // 06089B66 mov #1,r0
    goto L_06089B90;  // 06089B68 bra 0x06089B90 ; nop
L_06089B6C:
    c.r[4] = ld32(c.r[14]);  // 06089B6C mov.l @r14,r4
    c.r[8] = ld32(0x06089BA8u);  // 06089B6E mov.l 0x06089BA8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06089B74u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06089B74u) return; }  // 06089B70 jsr @r8 ; nop
    st32(c.r[14] + 4, c.r[0]);  // 06089B74 mov.l r0,@(4,r14)
    c.r[0] = ld32(c.r[14] + 4);  // 06089B76 mov.l @(4,r14),r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 06089B78 cmp/eq #-1,r0
    if (c.t) { goto L_06089B84; }  // 06089B7A bt 0x06089B84
    c.t = c.r[0] == 0x5u;  // 06089B7C cmp/eq #5,r0
    if (c.t) { goto L_06089B84; }  // 06089B7E bt 0x06089B84
    goto L_06089B8A;  // 06089B80 bra 0x06089B8A ; nop
L_06089B84:
    c.r[0] = 0x1u;  // 06089B84 mov #1,r0
    goto L_06089B90;  // 06089B86 bra 0x06089B90 ; nop
L_06089B8A:
    c.r[0] = 0x0u;  // 06089B8A mov #0,r0
    goto L_06089B90;  // 06089B8C bra 0x06089B90 ; nop
L_06089B90:
    c.r[14] += 8;  // 06089B90 add #8,r14
    c.r[15] = c.r[14];  // 06089B92 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06089B94 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06089B96 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06089B98 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06089B9A rts ; nop
}

void f_06089BAC(SH2Context& c) {
    ran[1966] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06089BAC mov.l r14,@-r15
    c.r[15] -= 4;  // 06089BAE add #-4,r15
    c.r[14] = c.r[15];  // 06089BB0 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06089BB2 mov.l r4,@r14
    goto L_06089BB8;  // 06089BB4 bra 0x06089BB8 ; nop
L_06089BB8:
    c.r[14] += 4;  // 06089BB8 add #4,r14
    c.r[15] = c.r[14];  // 06089BBA mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06089BBC mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 06089BBE rts ; nop
}

void f_06089BC4(SH2Context& c) {
    ran[1967] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06089BC4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06089BC6 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06089BC8 sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x06089D3Cu);  // 06089BCA mov.w 0x06089D3C,r3
    c.r[15] += c.r[3];  // 06089BCC add r3,r15
    c.r[14] = c.r[15];  // 06089BCE mov r15,r14
    st32(c.r[14], c.r[4]);  // 06089BD0 mov.l r4,@r14
    c.r[1] = ld32(c.r[14]);  // 06089BD2 mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 06089BD4 mov.l @r1,r2
    st32(c.r[14] + 4, c.r[2]);  // 06089BD6 mov.l r2,@(4,r14)
    c.r[1] = ld32(c.r[14] + 4);  // 06089BD8 mov.l @(4,r14),r1
    c.r[2] = c.r[1];  // 06089BDA mov r1,r2
    c.r[2] += 4;  // 06089BDC add #4,r2
    st32(c.r[14] + 8, c.r[2]);  // 06089BDE mov.l r2,@(8,r14)
    c.r[1] = ld32(c.r[14] + 4);  // 06089BE0 mov.l @(4,r14),r1
    c.r[2] = c.r[1];  // 06089BE2 mov r1,r2
    c.r[2] += 56;  // 06089BE4 add #56,r2
    st32(c.r[14] + 12, c.r[2]);  // 06089BE6 mov.l r2,@(12,r14)
    c.r[1] = c.r[14];  // 06089BE8 mov r14,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06089D3Eu);  // 06089BEA mov.w 0x06089D3E,r2
    c.r[1] = c.r[14];  // 06089BEC mov r14,r1
    c.r[1] += c.r[2];  // 06089BEE add r2,r1
    c.r[2] = c.r[14];  // 06089BF0 mov r14,r2
    c.r[2] += 68;  // 06089BF2 add #68,r2
    st32(c.r[1], c.r[2]);  // 06089BF4 mov.l r2,@r1
    c.r[1] = c.r[14];  // 06089BF6 mov r14,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06089D40u);  // 06089BF8 mov.w 0x06089D40,r2
    c.r[1] = c.r[14];  // 06089BFA mov r14,r1
    c.r[1] += c.r[2];  // 06089BFC add r2,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06089D42u);  // 06089BFE mov.w 0x06089D42,r2
    c.r[3] = c.r[14];  // 06089C00 mov r14,r3
    c.r[3] += c.r[2];  // 06089C02 add r2,r3
    st32(c.r[1], c.r[3]);  // 06089C04 mov.l r3,@r1
    c.r[1] = c.r[14];  // 06089C06 mov r14,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06089D44u);  // 06089C08 mov.w 0x06089D44,r2
    c.r[1] = c.r[14];  // 06089C0A mov r14,r1
    c.r[1] += c.r[2];  // 06089C0C add r2,r1
    c.r[2] = c.r[14];  // 06089C0E mov r14,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x06089D40u);  // 06089C10 mov.w 0x06089D40,r3
    c.r[2] = c.r[14];  // 06089C12 mov r14,r2
    c.r[2] += c.r[3];  // 06089C14 add r3,r2
    c.r[3] = ld32(c.r[2]);  // 06089C16 mov.l @r2,r3
    c.r[2] = (uint32_t)(int16_t)ld16(0x06089D46u);  // 06089C18 mov.w 0x06089D46,r2
    c.r[3] += c.r[2];  // 06089C1A add r2,r3
    st32(c.r[1], c.r[3]);  // 06089C1C mov.l r3,@r1
    c.r[1] = c.r[14];  // 06089C1E mov r14,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06089D48u);  // 06089C20 mov.w 0x06089D48,r2
    c.r[1] = c.r[14];  // 06089C22 mov r14,r1
    c.r[1] += c.r[2];  // 06089C24 add r2,r1
    c.r[2] = c.r[14];  // 06089C26 mov r14,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x06089D40u);  // 06089C28 mov.w 0x06089D40,r3
    c.r[2] = c.r[14];  // 06089C2A mov r14,r2
    c.r[2] += c.r[3];  // 06089C2C add r3,r2
    c.r[3] = ld32(c.r[2]);  // 06089C2E mov.l @r2,r3
    st32(c.r[1], c.r[3]);  // 06089C30 mov.l r3,@r1
    c.r[1] = ld32(c.r[14] + 12);  // 06089C32 mov.l @(12,r14),r1
    c.r[3] = ld32(c.r[14] + 12);  // 06089C34 mov.l @(12,r14),r3
    c.r[2] = c.r[3];  // 06089C36 mov r3,r2
    c.r[3] += 64;  // 06089C38 add #64,r3
    c.r[1] = ld32(c.r[1] + 60);  // 06089C3A mov.l @(60,r1),r1
    c.r[2] = ld32(c.r[3]);  // 06089C3C mov.l @r3,r2
    c.r[1] -= c.r[2];  // 06089C3E sub r2,r1
    st32(c.r[14] + 32, c.r[1]);  // 06089C40 mov.l r1,@(32,r14)
    c.r[1] = ld32(c.r[14] + 32);  // 06089C42 mov.l @(32,r14),r1
    c.r[2] = ld32(0x06089D50u);  // 06089C44 mov.l 0x06089D50,r2
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[1] * (int32_t)c.r[2]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 06089C46 dmuls.l r2,r1
    c.r[2] = c.mach;  // 06089C48 sts mach,r2
    c.r[4] = c.r[2];  // 06089C4A mov r2,r4
    c.r[2] = ld32(0x06089D54u);  // 06089C4C mov.l 0x06089D54,r2
    { const uint32_t x = c.r[2]; c.pr = 0x06089C52u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06089C52u) return; }  // 06089C4E jsr @r2 ; nop
    c.r[2] = c.r[4];  // 06089C52 mov r4,r2
    c.r[3] = c.r[1];  // 06089C54 mov r1,r3
    c.t = c.r[3] >> 31; c.r[3] <<= 1;  // 06089C56 shll r3
    { uint32_t a = c.r[3], b = c.r[3], t = c.t; c.r[3] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 06089C58 subc r3,r3
    c.r[1] = c.r[2];  // 06089C5A mov r2,r1
    c.r[1] -= c.r[3];  // 06089C5C sub r3,r1
    c.r[2] = 0x12u;  // 06089C5E mov #18,r2
    c.macl = c.r[1] * c.r[2];  // 06089C60 mul.l r2,r1
    c.r[1] = c.macl;  // 06089C62 sts macl,r1
    c.r[2] = ld32(c.r[14] + 32);  // 06089C64 mov.l @(32,r14),r2
    c.r[3] = ld32(0x06089D50u);  // 06089C66 mov.l 0x06089D50,r3
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[2] * (int32_t)c.r[3]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 06089C68 dmuls.l r3,r2
    c.r[3] = c.mach;  // 06089C6A sts mach,r3
    c.r[4] = c.r[3];  // 06089C6C mov r3,r4
    c.r[3] = ld32(0x06089D54u);  // 06089C6E mov.l 0x06089D54,r3
    { const uint32_t x = c.r[3]; c.pr = 0x06089C74u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06089C74u) return; }  // 06089C70 jsr @r3 ; nop
    c.r[3] = c.r[4];  // 06089C74 mov r4,r3
    c.r[7] = c.r[2];  // 06089C76 mov r2,r7
    c.t = c.r[7] >> 31; c.r[7] <<= 1;  // 06089C78 shll r7
    { uint32_t a = c.r[7], b = c.r[7], t = c.t; c.r[7] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 06089C7A subc r7,r7
    c.r[3] -= c.r[7];  // 06089C7C sub r7,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x06089D4Au);  // 06089C7E mov.w 0x06089D4A,r7
    c.macl = c.r[3] * c.r[7];  // 06089C80 mul.l r7,r3
    c.r[3] = c.macl;  // 06089C82 sts macl,r3
    c.r[7] = c.r[2];  // 06089C84 mov r2,r7
    c.r[7] -= c.r[3];  // 06089C86 sub r3,r7
    c.r[2] = c.r[7];  // 06089C88 mov r7,r2
    c.t = (int32_t)c.r[2] >= 0;  // 06089C8A cmp/pz r2
    if (c.t) { goto L_06089C90; }  // 06089C8C bt 0x06089C90
    c.r[2] += 127;  // 06089C8E add #127,r2
L_06089C90:
    c.r[4] = c.r[2];  // 06089C90 mov r2,r4
    c.r[2] = ld32(0x06089D58u);  // 06089C92 mov.l 0x06089D58,r2
    { const uint32_t x = c.r[2]; c.pr = 0x06089C98u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06089C98u) return; }  // 06089C94 jsr @r2 ; nop
    c.r[2] = c.r[4];  // 06089C98 mov r4,r2
    c.r[1] += c.r[2];  // 06089C9A add r2,r1
    st32(c.r[14] + 36, c.r[1]);  // 06089C9C mov.l r1,@(36,r14)
    c.r[1] = ld32(c.r[14] + 12);  // 06089C9E mov.l @(12,r14),r1
    c.r[0] = ld32(c.r[1] + 36);  // 06089CA0 mov.l @(36,r1),r0
    c.t = c.r[0] == 0x2u;  // 06089CA2 cmp/eq #2,r0
    if (!c.t) { goto L_06089CB0; }  // 06089CA4 bf 0x06089CB0
    c.r[2] = ld32(c.r[14] + 36);  // 06089CA6 mov.l @(36,r14),r2
    c.r[1] = c.r[2];  // 06089CA8 mov r2,r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06089CAA shar r1
    c.r[2] = c.r[1];  // 06089CAC mov r1,r2
    st32(c.r[14] + 36, c.r[2]);  // 06089CAE mov.l r2,@(36,r14)
L_06089CB0:
    c.r[1] = ld32(c.r[14] + 12);  // 06089CB0 mov.l @(12,r14),r1
    c.r[0] = ld32(c.r[1] + 48);  // 06089CB2 mov.l @(48,r1),r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 06089CB4 cmp/eq #-1,r0
    if (c.t) { goto L_06089CCC; }  // 06089CB6 bt 0x06089CCC
    c.r[2] = ld32(c.r[14] + 12);  // 06089CB8 mov.l @(12,r14),r2
    c.r[1] = c.r[2];  // 06089CBA mov r2,r1
    c.r[2] += 104;  // 06089CBC add #104,r2
    c.r[1] = ld32(c.r[14] + 12);  // 06089CBE mov.l @(12,r14),r1
    c.r[2] = ld32(c.r[2]);  // 06089CC0 mov.l @r2,r2
    c.r[1] = ld32(c.r[1] + 48);  // 06089CC2 mov.l @(48,r1),r1
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[1];  // 06089CC4 cmp/ge r1,r2
    if (!c.t) { goto L_06089CCC; }  // 06089CC6 bf 0x06089CCC
    c.r[1] = 0x0u;  // 06089CC8 mov #0,r1
    st32(c.r[14] + 36, c.r[1]);  // 06089CCA mov.l r1,@(36,r14)
L_06089CCC:
    c.r[1] = c.r[14];  // 06089CCC mov r14,r1
    c.r[1] += 24;  // 06089CCE add #24,r1
    c.r[2] = c.r[14];  // 06089CD0 mov r14,r2
    c.r[2] += 20;  // 06089CD2 add #20,r2
    c.r[3] = c.r[14];  // 06089CD4 mov r14,r3
    c.r[3] += 16;  // 06089CD6 add #16,r3
    c.r[7] = c.r[14];  // 06089CD8 mov r14,r7
    c.r[7] += 28;  // 06089CDA add #28,r7
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 06089CDC mov.l r7,@-r15
    c.r[7] = c.r[1];  // 06089CDE mov r1,r7
    c.r[6] = c.r[2];  // 06089CE0 mov r2,r6
    c.r[5] = c.r[3];  // 06089CE2 mov r3,r5
    c.r[4] = ld32(c.r[14]);  // 06089CE4 mov.l @r14,r4
    c.r[8] = ld32(0x06089D5Cu);  // 06089CE6 mov.l 0x06089D5C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06089CECu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06089CECu) return; }  // 06089CE8 jsr @r8 ; nop
    c.r[15] += 4;  // 06089CEC add #4,r15
    c.r[1] = ld32(c.r[14] + 28);  // 06089CEE mov.l @(28,r14),r1
    c.r[2] = ld32(0x06089D60u);  // 06089CF0 mov.l 0x06089D60,r2
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[1] * (int32_t)c.r[2]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 06089CF2 dmuls.l r2,r1
    c.r[2] = c.mach;  // 06089CF4 sts mach,r2
    c.r[3] = c.r[2];  // 06089CF6 mov r2,r3
    c.r[3] += c.r[1];  // 06089CF8 add r1,r3
    c.r[4] = c.r[3];  // 06089CFA mov r3,r4
    c.r[2] = ld32(0x06089D64u);  // 06089CFC mov.l 0x06089D64,r2
    { const uint32_t x = c.r[2]; c.pr = 0x06089D02u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06089D02u) return; }  // 06089CFE jsr @r2 ; nop
    c.r[2] = c.r[4];  // 06089D02 mov r4,r2
    c.r[3] = c.r[1];  // 06089D04 mov r1,r3
    c.t = c.r[3] >> 31; c.r[3] <<= 1;  // 06089D06 shll r3
    { uint32_t a = c.r[3], b = c.r[3], t = c.t; c.r[3] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 06089D08 subc r3,r3
    c.r[1] = c.r[2];  // 06089D0A mov r2,r1
    c.r[1] -= c.r[3];  // 06089D0C sub r3,r1
    st32(c.r[14] + 40, c.r[1]);  // 06089D0E mov.l r1,@(40,r14)
    c.r[1] = ld32(c.r[14] + 40);  // 06089D10 mov.l @(40,r14),r1
    c.r[2] = ld32(c.r[14] + 36);  // 06089D12 mov.l @(36,r14),r2
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 06089D14 cmp/gt r2,r1
    if (!c.t) { goto L_06089D1A; }  // 06089D16 bf 0x06089D1A
    c.r[1] = ld32(c.r[14] + 36);  // 06089D18 mov.l @(36,r14),r1
L_06089D1A:
    st32(c.r[14] + 44, c.r[1]);  // 06089D1A mov.l r1,@(44,r14)
    c.r[1] = ld32(c.r[14] + 12);  // 06089D1C mov.l @(12,r14),r1
    c.r[2] = c.r[1];  // 06089D1E mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x06089D4Cu);  // 06089D20 mov.w 0x06089D4C,r3
    c.r[2] = c.r[1];  // 06089D22 mov r1,r2
    c.r[2] += c.r[3];  // 06089D24 add r3,r2
    c.r[1] = ld32(c.r[14] + 44);  // 06089D26 mov.l @(44,r14),r1
    c.r[3] = ld32(c.r[2]);  // 06089D28 mov.l @r2,r3
    c.t = (int32_t)c.r[1] > (int32_t)c.r[3];  // 06089D2A cmp/gt r3,r1
    if (!c.t) { goto L_06089D30; }  // 06089D2C bf 0x06089D30
    c.r[1] = ld32(c.r[2]);  // 06089D2E mov.l @r2,r1
L_06089D30:
    st32(c.r[14] + 44, c.r[1]);  // 06089D30 mov.l r1,@(44,r14)
    c.r[1] = ld32(c.r[14] + 44);  // 06089D32 mov.l @(44,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06089D34 tst r1,r1
    if (!c.t) { goto L_06089D68; }  // 06089D36 bf 0x06089D68
    goto L_0608A33A;  // 06089D38 bra 0x0608A33A ; nop
L_06089D68:
    c.r[1] = ld32(c.r[14] + 12);  // 06089D68 mov.l @(12,r14),r1
    c.r[2] = c.r[1];  // 06089D6A mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x06089E42u);  // 06089D6C mov.w 0x06089E42,r3
    c.r[1] += c.r[3];  // 06089D6E add r3,r1
    c.r[2] = ld32(c.r[1]);  // 06089D70 mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06089D72 tst r2,r2
    if (c.t) { goto L_06089D76; }  // 06089D74 bt 0x06089D76
L_06089D76:
    c.r[1] = ld32(c.r[14] + 12);  // 06089D76 mov.l @(12,r14),r1
    c.r[2] = c.r[1];  // 06089D78 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x06089E42u);  // 06089D7A mov.w 0x06089E42,r3
    c.r[1] += c.r[3];  // 06089D7C add r3,r1
    c.r[2] = 0x0u;  // 06089D7E mov #0,r2
    st32(c.r[1], c.r[2]);  // 06089D80 mov.l r2,@r1
    c.r[1] = ld32(c.r[14] + 12);  // 06089D82 mov.l @(12,r14),r1
    c.r[0] = ld32(c.r[1] + 36);  // 06089D84 mov.l @(36,r1),r0
    c.t = c.r[0] == 0x2u;  // 06089D86 cmp/eq #2,r0
    if (c.t) { goto L_06089D8E; }  // 06089D88 bt 0x06089D8E
    goto L_0608A07E;  // 06089D8A bra 0x0608A07E ; nop
L_06089D8E:
    c.r[1] = c.r[14];  // 06089D8E mov r14,r1
    c.r[2] = c.r[14];  // 06089D90 mov r14,r2
    c.r[2] += 64;  // 06089D92 add #64,r2
    c.r[1] = 0x0u;  // 06089D94 mov #0,r1
    st32(c.r[2], c.r[1]);  // 06089D96 mov.l r1,@r2
L_06089D98:
    c.r[2] = c.r[14];  // 06089D98 mov r14,r2
    c.r[1] = c.r[14];  // 06089D9A mov r14,r1
    c.r[1] += 64;  // 06089D9C add #64,r1
    c.r[2] = ld32(c.r[14] + 44);  // 06089D9E mov.l @(44,r14),r2
    c.r[3] = c.r[2];  // 06089DA0 mov r2,r3
    c.r[2] = c.r[3];  // 06089DA2 mov r3,r2
    c.r[2] += c.r[2];  // 06089DA4 add r2,r2
    c.r[1] = ld32(c.r[1]);  // 06089DA6 mov.l @r1,r1
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[2];  // 06089DA8 cmp/ge r2,r1
    if (!c.t) { goto L_06089DB0; }  // 06089DAA bf 0x06089DB0
    goto L_0608A07A;  // 06089DAC bra 0x0608A07A ; nop
L_06089DB0:
    c.r[2] = ld32(c.r[14] + 12);  // 06089DB0 mov.l @(12,r14),r2
    c.r[1] = c.r[2];  // 06089DB2 mov r2,r1
    c.r[2] += 76;  // 06089DB4 add #76,r2
    c.r[1] = ld32(c.r[2]);  // 06089DB6 mov.l @r2,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06089E42u);  // 06089DB8 mov.w 0x06089E42,r2
    c.r[1] += c.r[2];  // 06089DBA add r2,r1
    c.r[3] = ld32(c.r[14] + 12);  // 06089DBC mov.l @(12,r14),r3
    c.r[2] = c.r[3];  // 06089DBE mov r3,r2
    c.r[3] += 68;  // 06089DC0 add #68,r3
    c.r[2] = ld32(c.r[3]);  // 06089DC2 mov.l @r3,r2
    c.t = c.r[1] > c.r[2];  // 06089DC4 cmp/hi r2,r1
    if (c.t) { goto L_06089DCC; }  // 06089DC6 bt 0x06089DCC
    goto L_06089E4C;  // 06089DC8 bra 0x06089E4C ; nop
L_06089DCC:
    c.r[1] = ld32(c.r[14] + 12);  // 06089DCC mov.l @(12,r14),r1
    c.r[2] = c.r[1];  // 06089DCE mov r1,r2
    c.r[1] += 68;  // 06089DD0 add #68,r1
    c.r[3] = ld32(c.r[14] + 12);  // 06089DD2 mov.l @(12,r14),r3
    c.r[2] = c.r[3];  // 06089DD4 mov r3,r2
    c.r[3] += 76;  // 06089DD6 add #76,r3
    c.r[1] = ld32(c.r[1]);  // 06089DD8 mov.l @r1,r1
    c.r[2] = ld32(c.r[3]);  // 06089DDA mov.l @r3,r2
    c.r[1] -= c.r[2];  // 06089DDC sub r2,r1
    st32(c.r[14] + 48, c.r[1]);  // 06089DDE mov.l r1,@(48,r14)
    c.r[1] = (uint32_t)(int16_t)ld16(0x06089E42u);  // 06089DE0 mov.w 0x06089E42,r1
    c.r[2] = ld32(c.r[14] + 48);  // 06089DE2 mov.l @(48,r14),r2
    c.r[1] -= c.r[2];  // 06089DE4 sub r2,r1
    st32(c.r[14] + 52, c.r[1]);  // 06089DE6 mov.l r1,@(52,r14)
    c.r[1] = ld32(c.r[14] + 48);  // 06089DE8 mov.l @(48,r14),r1
    c.r[3] = ld32(c.r[14] + 12);  // 06089DEA mov.l @(12,r14),r3
    c.r[2] = c.r[3];  // 06089DEC mov r3,r2
    c.r[3] += 76;  // 06089DEE add #76,r3
    c.r[2] = ld32(c.r[3]);  // 06089DF0 mov.l @r3,r2
    c.r[3] = c.r[14];  // 06089DF2 mov r14,r3
    c.r[6] = (uint32_t)(int16_t)ld16(0x06089E44u);  // 06089DF4 mov.w 0x06089E44,r6
    c.r[7] = c.r[14];  // 06089DF6 mov r14,r7
    c.r[7] += c.r[6];  // 06089DF8 add r6,r7
    c.r[3] = ld32(c.r[7]);  // 06089DFA mov.l @r7,r3
    c.r[6] = c.r[1];  // 06089DFC mov r1,r6
    c.r[5] = c.r[2];  // 06089DFE mov r2,r5
    c.r[4] = c.r[3];  // 06089E00 mov r3,r4
    c.r[8] = ld32(0x06089E48u);  // 06089E02 mov.l 0x06089E48,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06089E08u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06089E08u) return; }  // 06089E04 jsr @r8 ; nop
    c.r[1] = ld32(c.r[14] + 52);  // 06089E08 mov.l @(52,r14),r1
    c.r[3] = ld32(c.r[14] + 8);  // 06089E0A mov.l @(8,r14),r3
    c.r[2] = ld32(c.r[3]);  // 06089E0C mov.l @r3,r2
    c.r[3] = c.r[14];  // 06089E0E mov r14,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x06089E44u);  // 06089E10 mov.w 0x06089E44,r7
    c.r[3] = c.r[14];  // 06089E12 mov r14,r3
    c.r[3] += c.r[7];  // 06089E14 add r7,r3
    c.r[7] = ld32(c.r[3]);  // 06089E16 mov.l @r3,r7
    c.r[6] = ld32(c.r[14] + 48);  // 06089E18 mov.l @(48,r14),r6
    c.r[3] = c.r[7];  // 06089E1A mov r7,r3
    c.r[3] += c.r[6];  // 06089E1C add r6,r3
    c.r[6] = c.r[1];  // 06089E1E mov r1,r6
    c.r[5] = c.r[2];  // 06089E20 mov r2,r5
    c.r[4] = c.r[3];  // 06089E22 mov r3,r4
    c.r[8] = ld32(0x06089E48u);  // 06089E24 mov.l 0x06089E48,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06089E2Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06089E2Au) return; }  // 06089E26 jsr @r8 ; nop
    c.r[1] = c.r[14];  // 06089E2A mov r14,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06089E46u);  // 06089E2C mov.w 0x06089E46,r2
    c.r[1] = c.r[14];  // 06089E2E mov r14,r1
    c.r[1] += c.r[2];  // 06089E30 add r2,r1
    c.r[2] = c.r[14];  // 06089E32 mov r14,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x06089E44u);  // 06089E34 mov.w 0x06089E44,r3
    c.r[2] = c.r[14];  // 06089E36 mov r14,r2
    c.r[2] += c.r[3];  // 06089E38 add r3,r2
    c.r[3] = ld32(c.r[2]);  // 06089E3A mov.l @r2,r3
    st32(c.r[1], c.r[3]);  // 06089E3C mov.l r3,@r1
    goto L_06089E5E;  // 06089E3E bra 0x06089E5E ; nop
L_06089E4C:
    c.r[1] = c.r[14];  // 06089E4C mov r14,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06089FB2u);  // 06089E4E mov.w 0x06089FB2,r2
    c.r[1] = c.r[14];  // 06089E50 mov r14,r1
    c.r[1] += c.r[2];  // 06089E52 add r2,r1
    c.r[3] = ld32(c.r[14] + 12);  // 06089E54 mov.l @(12,r14),r3
    c.r[2] = c.r[3];  // 06089E56 mov r3,r2
    c.r[3] += 76;  // 06089E58 add #76,r3
    c.r[2] = ld32(c.r[3]);  // 06089E5A mov.l @r3,r2
    st32(c.r[1], c.r[2]);  // 06089E5C mov.l r2,@r1
L_06089E5E:
    c.r[1] = c.r[14];  // 06089E5E mov r14,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x06089FB4u);  // 06089E60 mov.w 0x06089FB4,r3
    c.r[2] = c.r[14];  // 06089E62 mov r14,r2
    c.r[2] += c.r[3];  // 06089E64 add r3,r2
    c.r[1] = ld32(c.r[2]);  // 06089E66 mov.l @r2,r1
    c.r[2] = c.r[14];  // 06089E68 mov r14,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x06089FB2u);  // 06089E6A mov.w 0x06089FB2,r3
    c.r[2] = c.r[14];  // 06089E6C mov r14,r2
    c.r[2] += c.r[3];  // 06089E6E add r3,r2
    c.r[3] = ld32(c.r[2]);  // 06089E70 mov.l @r2,r3
    c.r[5] = c.r[1];  // 06089E72 mov r1,r5
    c.r[4] = c.r[3];  // 06089E74 mov r3,r4
    c.r[8] = ld32(0x06089FC0u);  // 06089E76 mov.l 0x06089FC0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06089E7Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06089E7Cu) return; }  // 06089E78 jsr @r8 ; nop
    c.r[1] = c.r[14];  // 06089E7C mov r14,r1
    c.r[1] += 24;  // 06089E7E add #24,r1
    c.r[2] = c.r[14];  // 06089E80 mov r14,r2
    c.r[2] += 20;  // 06089E82 add #20,r2
    c.r[3] = c.r[14];  // 06089E84 mov r14,r3
    c.r[3] += 16;  // 06089E86 add #16,r3
    c.r[7] = c.r[14];  // 06089E88 mov r14,r7
    c.r[7] += 28;  // 06089E8A add #28,r7
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 06089E8C mov.l r7,@-r15
    c.r[7] = c.r[1];  // 06089E8E mov r1,r7
    c.r[6] = c.r[2];  // 06089E90 mov r2,r6
    c.r[5] = c.r[3];  // 06089E92 mov r3,r5
    c.r[4] = ld32(c.r[14]);  // 06089E94 mov.l @r14,r4
    c.r[8] = ld32(0x06089FC4u);  // 06089E96 mov.l 0x06089FC4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06089E9Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06089E9Cu) return; }  // 06089E98 jsr @r8 ; nop
    c.r[15] += 4;  // 06089E9C add #4,r15
    c.r[1] = ld32(c.r[14] + 24);  // 06089E9E mov.l @(24,r14),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06089FB6u);  // 06089EA0 mov.w 0x06089FB6,r2
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 06089EA2 cmp/gt r2,r1
    if (!c.t) { goto L_06089EA8; }  // 06089EA4 bf 0x06089EA8
    c.r[1] = (uint32_t)(int16_t)ld16(0x06089FB6u);  // 06089EA6 mov.w 0x06089FB6,r1
L_06089EA8:
    st32(c.r[14] + 48, c.r[1]);  // 06089EA8 mov.l r1,@(48,r14)
    c.r[1] = (uint32_t)(int16_t)ld16(0x06089FB6u);  // 06089EAA mov.w 0x06089FB6,r1
    c.r[2] = ld32(c.r[14] + 48);  // 06089EAC mov.l @(48,r14),r2
    c.r[1] -= c.r[2];  // 06089EAE sub r2,r1
    st32(c.r[14] + 52, c.r[1]);  // 06089EB0 mov.l r1,@(52,r14)
    c.r[2] = ld32(c.r[14] + 48);  // 06089EB2 mov.l @(48,r14),r2
    c.r[1] = c.r[2];  // 06089EB4 mov r2,r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06089EB6 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06089EB8 shar r1
    c.r[2] = c.r[1];  // 06089EBA mov r1,r2
    st32(c.r[14] + 56, c.r[2]);  // 06089EBC mov.l r2,@(56,r14)
    c.r[2] = ld32(c.r[14] + 52);  // 06089EBE mov.l @(52,r14),r2
    c.r[1] = c.r[2];  // 06089EC0 mov r2,r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06089EC2 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06089EC4 shar r1
    c.r[2] = c.r[1];  // 06089EC6 mov r1,r2
    st32(c.r[14] + 60, c.r[2]);  // 06089EC8 mov.l r2,@(60,r14)
    c.r[1] = ld32(c.r[14] + 56);  // 06089ECA mov.l @(56,r14),r1
    c.r[2] = c.r[14];  // 06089ECC mov r14,r2
    c.r[7] = (uint32_t)(int16_t)ld16(0x06089FB8u);  // 06089ECE mov.w 0x06089FB8,r7
    c.r[3] = c.r[14];  // 06089ED0 mov r14,r3
    c.r[3] += c.r[7];  // 06089ED2 add r7,r3
    c.r[2] = ld32(c.r[3]);  // 06089ED4 mov.l @r3,r2
    c.r[3] = ld32(c.r[14] + 20);  // 06089ED6 mov.l @(20,r14),r3
    c.r[6] = c.r[1];  // 06089ED8 mov r1,r6
    c.r[5] = c.r[2];  // 06089EDA mov r2,r5
    c.r[4] = c.r[3];  // 06089EDC mov r3,r4
    c.r[8] = ld32(0x06089FC8u);  // 06089EDE mov.l 0x06089FC8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06089EE4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06089EE4u) return; }  // 06089EE0 jsr @r8 ; nop
    c.r[1] = ld32(c.r[14] + 56);  // 06089EE4 mov.l @(56,r14),r1
    c.r[2] = c.r[14];  // 06089EE6 mov r14,r2
    c.r[7] = (uint32_t)(int16_t)ld16(0x06089FBAu);  // 06089EE8 mov.w 0x06089FBA,r7
    c.r[3] = c.r[14];  // 06089EEA mov r14,r3
    c.r[3] += c.r[7];  // 06089EEC add r7,r3
    c.r[2] = ld32(c.r[3]);  // 06089EEE mov.l @r3,r2
    c.r[3] = ld32(c.r[14] + 16);  // 06089EF0 mov.l @(16,r14),r3
    c.r[6] = c.r[1];  // 06089EF2 mov r1,r6
    c.r[5] = c.r[2];  // 06089EF4 mov r2,r5
    c.r[4] = c.r[3];  // 06089EF6 mov r3,r4
    c.r[8] = ld32(0x06089FC8u);  // 06089EF8 mov.l 0x06089FC8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06089EFEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06089EFEu) return; }  // 06089EFA jsr @r8 ; nop
    c.r[1] = ld32(c.r[14] + 48);  // 06089EFE mov.l @(48,r14),r1
    c.r[5] = c.r[1];  // 06089F00 mov r1,r5
    c.r[4] = ld32(c.r[14]);  // 06089F02 mov.l @r14,r4
    c.r[8] = ld32(0x06089FCCu);  // 06089F04 mov.l 0x06089FCC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06089F0Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06089F0Au) return; }  // 06089F06 jsr @r8 ; nop
    c.r[1] = ld32(c.r[14] + 52);  // 06089F0A mov.l @(52,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06089F0C tst r1,r1
    if (!c.t) { goto L_06089F14; }  // 06089F0E bf 0x06089F14
    goto L_06089F82;  // 06089F10 bra 0x06089F82 ; nop
L_06089F14:
    c.r[1] = c.r[14];  // 06089F14 mov r14,r1
    c.r[1] += 24;  // 06089F16 add #24,r1
    c.r[2] = c.r[14];  // 06089F18 mov r14,r2
    c.r[2] += 20;  // 06089F1A add #20,r2
    c.r[3] = c.r[14];  // 06089F1C mov r14,r3
    c.r[3] += 16;  // 06089F1E add #16,r3
    c.r[7] = c.r[14];  // 06089F20 mov r14,r7
    c.r[7] += 28;  // 06089F22 add #28,r7
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 06089F24 mov.l r7,@-r15
    c.r[7] = c.r[1];  // 06089F26 mov r1,r7
    c.r[6] = c.r[2];  // 06089F28 mov r2,r6
    c.r[5] = c.r[3];  // 06089F2A mov r3,r5
    c.r[4] = ld32(c.r[14]);  // 06089F2C mov.l @r14,r4
    c.r[8] = ld32(0x06089FC4u);  // 06089F2E mov.l 0x06089FC4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06089F34u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06089F34u) return; }  // 06089F30 jsr @r8 ; nop
    c.r[15] += 4;  // 06089F34 add #4,r15
    c.r[1] = ld32(c.r[14] + 60);  // 06089F36 mov.l @(60,r14),r1
    c.r[2] = c.r[14];  // 06089F38 mov r14,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x06089FB8u);  // 06089F3A mov.w 0x06089FB8,r3
    c.r[2] = c.r[14];  // 06089F3C mov r14,r2
    c.r[2] += c.r[3];  // 06089F3E add r3,r2
    c.r[3] = ld32(c.r[2]);  // 06089F40 mov.l @r2,r3
    c.r[7] = ld32(c.r[14] + 48);  // 06089F42 mov.l @(48,r14),r7
    c.r[2] = c.r[3];  // 06089F44 mov r3,r2
    c.r[2] += c.r[7];  // 06089F46 add r7,r2
    c.r[3] = ld32(c.r[14] + 20);  // 06089F48 mov.l @(20,r14),r3
    c.r[6] = c.r[1];  // 06089F4A mov r1,r6
    c.r[5] = c.r[2];  // 06089F4C mov r2,r5
    c.r[4] = c.r[3];  // 06089F4E mov r3,r4
    c.r[8] = ld32(0x06089FC8u);  // 06089F50 mov.l 0x06089FC8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06089F56u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06089F56u) return; }  // 06089F52 jsr @r8 ; nop
    c.r[1] = ld32(c.r[14] + 60);  // 06089F56 mov.l @(60,r14),r1
    c.r[2] = c.r[14];  // 06089F58 mov r14,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x06089FBAu);  // 06089F5A mov.w 0x06089FBA,r3
    c.r[2] = c.r[14];  // 06089F5C mov r14,r2
    c.r[2] += c.r[3];  // 06089F5E add r3,r2
    c.r[3] = ld32(c.r[2]);  // 06089F60 mov.l @r2,r3
    c.r[7] = ld32(c.r[14] + 48);  // 06089F62 mov.l @(48,r14),r7
    c.r[2] = c.r[3];  // 06089F64 mov r3,r2
    c.r[2] += c.r[7];  // 06089F66 add r7,r2
    c.r[3] = ld32(c.r[14] + 16);  // 06089F68 mov.l @(16,r14),r3
    c.r[6] = c.r[1];  // 06089F6A mov r1,r6
    c.r[5] = c.r[2];  // 06089F6C mov r2,r5
    c.r[4] = c.r[3];  // 06089F6E mov r3,r4
    c.r[8] = ld32(0x06089FC8u);  // 06089F70 mov.l 0x06089FC8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06089F76u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06089F76u) return; }  // 06089F72 jsr @r8 ; nop
    c.r[1] = ld32(c.r[14] + 52);  // 06089F76 mov.l @(52,r14),r1
    c.r[5] = c.r[1];  // 06089F78 mov r1,r5
    c.r[4] = ld32(c.r[14]);  // 06089F7A mov.l @r14,r4
    c.r[8] = ld32(0x06089FCCu);  // 06089F7C mov.l 0x06089FCC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06089F82u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06089F82u) return; }  // 06089F7E jsr @r8 ; nop
L_06089F82:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06089FBCu);  // 06089F82 mov.w 0x06089FBC,r1
    c.r[5] = c.r[1];  // 06089F84 mov r1,r5
    c.r[4] = ld32(c.r[14]);  // 06089F86 mov.l @r14,r4
    c.r[8] = ld32(0x06089FD0u);  // 06089F88 mov.l 0x06089FD0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06089F8Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06089F8Eu) return; }  // 06089F8A jsr @r8 ; nop
    c.r[1] = ld32(c.r[14] + 12);  // 06089F8E mov.l @(12,r14),r1
    c.r[0] = ld32(c.r[1] + 48);  // 06089F90 mov.l @(48,r1),r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 06089F92 cmp/eq #-1,r0
    if (!c.t) { goto L_06089F9A; }  // 06089F94 bf 0x06089F9A
    goto L_06089FD4;  // 06089F96 bra 0x06089FD4 ; nop
L_06089F9A:
    c.r[2] = ld32(c.r[14] + 12);  // 06089F9A mov.l @(12,r14),r2
    c.r[1] = c.r[2];  // 06089F9C mov r2,r1
    c.r[2] += 104;  // 06089F9E add #104,r2
    c.r[1] = ld32(c.r[14] + 12);  // 06089FA0 mov.l @(12,r14),r1
    c.r[2] = ld32(c.r[2]);  // 06089FA2 mov.l @r2,r2
    c.r[1] = ld32(c.r[1] + 48);  // 06089FA4 mov.l @(48,r1),r1
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[1];  // 06089FA6 cmp/ge r1,r2
    if (c.t) { goto L_06089FAE; }  // 06089FA8 bt 0x06089FAE
    goto L_06089FD4;  // 06089FAA bra 0x06089FD4 ; nop
L_06089FAE:
    goto L_0608A07A;  // 06089FAE bra 0x0608A07A ; nop
L_06089FD4:
    c.r[1] = ld32(c.r[14] + 12);  // 06089FD4 mov.l @(12,r14),r1
    c.r[2] = c.r[1];  // 06089FD6 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608A130u);  // 06089FD8 mov.w 0x0608A130,r3
    c.r[2] = c.r[1];  // 06089FDA mov r1,r2
    c.r[2] += c.r[3];  // 06089FDC add r3,r2
    c.r[1] = ld32(c.r[14] + 12);  // 06089FDE mov.l @(12,r14),r1
    c.r[2] = c.r[1];  // 06089FE0 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608A130u);  // 06089FE2 mov.w 0x0608A130,r3
    c.r[1] += c.r[3];  // 06089FE4 add r3,r1
    c.r[2] = ld32(c.r[14] + 12);  // 06089FE6 mov.l @(12,r14),r2
    c.r[3] = c.r[2];  // 06089FE8 mov r2,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x0608A130u);  // 06089FEA mov.w 0x0608A130,r7
    c.r[2] += c.r[7];  // 06089FEC add r7,r2
    c.r[3] = ld32(c.r[2]);  // 06089FEE mov.l @r2,r3
    c.r[2] = c.r[3];  // 06089FF0 mov r3,r2
    c.r[2] += 1;  // 06089FF2 add #1,r2
    c.r[3] = c.r[2];  // 06089FF4 mov r2,r3
    st32(c.r[1], c.r[3]);  // 06089FF6 mov.l r3,@r1
    c.r[1] = ld32(c.r[14] + 12);  // 06089FF8 mov.l @(12,r14),r1
    c.r[2] = c.r[1];  // 06089FFA mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608A130u);  // 06089FFC mov.w 0x0608A130,r3
    c.r[2] = c.r[1];  // 06089FFE mov r1,r2
    c.r[2] += c.r[3];  // 0608A000 add r3,r2
    c.r[1] = ld32(c.r[2]);  // 0608A002 mov.l @r2,r1
    c.r[2] = ld32(0x0608A138u);  // 0608A004 mov.l 0x0608A138,r2
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[1] * (int32_t)c.r[2]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 0608A006 dmuls.l r2,r1
    c.r[3] = c.mach;  // 0608A008 sts mach,r3
    c.r[2] = c.r[3];  // 0608A00A mov r3,r2
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 0608A00C shar r2
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 0608A00E shar r2
    c.r[3] = c.r[2];  // 0608A010 mov r2,r3
    c.r[7] = c.r[1];  // 0608A012 mov r1,r7
    c.t = c.r[7] >> 31; c.r[7] <<= 1;  // 0608A014 shll r7
    { uint32_t a = c.r[7], b = c.r[7], t = c.t; c.r[7] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 0608A016 subc r7,r7
    c.r[2] = c.r[3];  // 0608A018 mov r3,r2
    c.r[2] -= c.r[7];  // 0608A01A sub r7,r2
    c.r[3] = 0x12u;  // 0608A01C mov #18,r3
    c.macl = c.r[2] * c.r[3];  // 0608A01E mul.l r3,r2
    c.r[2] = c.macl;  // 0608A020 sts macl,r2
    c.r[1] -= c.r[2];  // 0608A022 sub r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0608A024 tst r1,r1
    if (c.t) { goto L_0608A02C; }  // 0608A026 bt 0x0608A02C
    goto L_0608A05A;  // 0608A028 bra 0x0608A05A ; nop
L_0608A02C:
    c.r[5] = 0x14u;  // 0608A02C mov #20,r5
    c.r[4] = ld32(c.r[14]);  // 0608A02E mov.l @r14,r4
    c.r[8] = ld32(0x0608A13Cu);  // 0608A030 mov.l 0x0608A13C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608A036u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608A036u) return; }  // 0608A032 jsr @r8 ; nop
    c.r[1] = ld32(c.r[14] + 12);  // 0608A036 mov.l @(12,r14),r1
    c.r[0] = ld32(c.r[1] + 48);  // 0608A038 mov.l @(48,r1),r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0608A03A cmp/eq #-1,r0
    if (!c.t) { goto L_0608A042; }  // 0608A03C bf 0x0608A042
    goto L_0608A05A;  // 0608A03E bra 0x0608A05A ; nop
L_0608A042:
    c.r[2] = ld32(c.r[14] + 12);  // 0608A042 mov.l @(12,r14),r2
    c.r[1] = c.r[2];  // 0608A044 mov r2,r1
    c.r[2] += 104;  // 0608A046 add #104,r2
    c.r[1] = ld32(c.r[14] + 12);  // 0608A048 mov.l @(12,r14),r1
    c.r[2] = ld32(c.r[2]);  // 0608A04A mov.l @r2,r2
    c.r[1] = ld32(c.r[1] + 48);  // 0608A04C mov.l @(48,r1),r1
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[1];  // 0608A04E cmp/ge r1,r2
    if (c.t) { goto L_0608A056; }  // 0608A050 bt 0x0608A056
    goto L_0608A05A;  // 0608A052 bra 0x0608A05A ; nop
L_0608A056:
    goto L_0608A07A;  // 0608A056 bra 0x0608A07A ; nop
L_0608A05A:
    c.r[1] = c.r[14];  // 0608A05A mov r14,r1
    c.r[2] = c.r[14];  // 0608A05C mov r14,r2
    c.r[2] += 64;  // 0608A05E add #64,r2
    c.r[3] = c.r[14];  // 0608A060 mov r14,r3
    c.r[1] = c.r[14];  // 0608A062 mov r14,r1
    c.r[1] += 64;  // 0608A064 add #64,r1
    c.r[2] = c.r[14];  // 0608A066 mov r14,r2
    c.r[3] = c.r[14];  // 0608A068 mov r14,r3
    c.r[3] += 64;  // 0608A06A add #64,r3
    c.r[7] = ld32(c.r[3]);  // 0608A06C mov.l @r3,r7
    c.r[2] = c.r[7];  // 0608A06E mov r7,r2
    c.r[2] += 1;  // 0608A070 add #1,r2
    c.r[3] = c.r[2];  // 0608A072 mov r2,r3
    st32(c.r[1], c.r[3]);  // 0608A074 mov.l r3,@r1
    SH2_POLL(c); goto L_06089D98;  // 0608A076 bra 0x06089D98 ; nop
L_0608A07A:
    goto L_0608A336;  // 0608A07A bra 0x0608A336 ; nop
L_0608A07E:
    c.r[1] = c.r[14];  // 0608A07E mov r14,r1
    c.r[2] = c.r[14];  // 0608A080 mov r14,r2
    c.r[2] += 64;  // 0608A082 add #64,r2
    c.r[1] = 0x0u;  // 0608A084 mov #0,r1
    st32(c.r[2], c.r[1]);  // 0608A086 mov.l r1,@r2
L_0608A088:
    c.r[1] = c.r[14];  // 0608A088 mov r14,r1
    c.r[2] = c.r[14];  // 0608A08A mov r14,r2
    c.r[2] += 64;  // 0608A08C add #64,r2
    c.r[1] = ld32(c.r[2]);  // 0608A08E mov.l @r2,r1
    c.r[2] = ld32(c.r[14] + 44);  // 0608A090 mov.l @(44,r14),r2
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[2];  // 0608A092 cmp/ge r2,r1
    if (c.t) { goto L_0608A09A; }  // 0608A094 bt 0x0608A09A
    goto L_0608A09E;  // 0608A096 bra 0x0608A09E ; nop
L_0608A09A:
    goto L_0608A336;  // 0608A09A bra 0x0608A336 ; nop
L_0608A09E:
    c.r[2] = ld32(c.r[14] + 12);  // 0608A09E mov.l @(12,r14),r2
    c.r[1] = c.r[2];  // 0608A0A0 mov r2,r1
    c.r[2] += 76;  // 0608A0A2 add #76,r2
    c.r[1] = ld32(c.r[2]);  // 0608A0A4 mov.l @r2,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0608A132u);  // 0608A0A6 mov.w 0x0608A132,r2
    c.r[1] += c.r[2];  // 0608A0A8 add r2,r1
    c.r[3] = ld32(c.r[14] + 12);  // 0608A0AA mov.l @(12,r14),r3
    c.r[2] = c.r[3];  // 0608A0AC mov r3,r2
    c.r[3] += 68;  // 0608A0AE add #68,r3
    c.r[2] = ld32(c.r[3]);  // 0608A0B0 mov.l @r3,r2
    c.t = c.r[1] > c.r[2];  // 0608A0B2 cmp/hi r2,r1
    if (c.t) { goto L_0608A0BA; }  // 0608A0B4 bt 0x0608A0BA
    goto L_0608A144;  // 0608A0B6 bra 0x0608A144 ; nop
L_0608A0BA:
    c.r[1] = ld32(c.r[14] + 12);  // 0608A0BA mov.l @(12,r14),r1
    c.r[2] = c.r[1];  // 0608A0BC mov r1,r2
    c.r[1] += 68;  // 0608A0BE add #68,r1
    c.r[3] = ld32(c.r[14] + 12);  // 0608A0C0 mov.l @(12,r14),r3
    c.r[2] = c.r[3];  // 0608A0C2 mov r3,r2
    c.r[3] += 76;  // 0608A0C4 add #76,r3
    c.r[1] = ld32(c.r[1]);  // 0608A0C6 mov.l @r1,r1
    c.r[2] = ld32(c.r[3]);  // 0608A0C8 mov.l @r3,r2
    c.r[1] -= c.r[2];  // 0608A0CA sub r2,r1
    st32(c.r[14] + 48, c.r[1]);  // 0608A0CC mov.l r1,@(48,r14)
    c.r[1] = (uint32_t)(int16_t)ld16(0x0608A132u);  // 0608A0CE mov.w 0x0608A132,r1
    c.r[2] = ld32(c.r[14] + 48);  // 0608A0D0 mov.l @(48,r14),r2
    c.r[1] -= c.r[2];  // 0608A0D2 sub r2,r1
    st32(c.r[14] + 52, c.r[1]);  // 0608A0D4 mov.l r1,@(52,r14)
    c.r[1] = ld32(c.r[14] + 48);  // 0608A0D6 mov.l @(48,r14),r1
    c.r[3] = ld32(c.r[14] + 12);  // 0608A0D8 mov.l @(12,r14),r3
    c.r[2] = c.r[3];  // 0608A0DA mov r3,r2
    c.r[3] += 76;  // 0608A0DC add #76,r3
    c.r[2] = ld32(c.r[3]);  // 0608A0DE mov.l @r3,r2
    c.r[3] = c.r[14];  // 0608A0E0 mov r14,r3
    c.r[6] = (uint32_t)(int16_t)ld16(0x0608A134u);  // 0608A0E2 mov.w 0x0608A134,r6
    c.r[7] = c.r[14];  // 0608A0E4 mov r14,r7
    c.r[7] += c.r[6];  // 0608A0E6 add r6,r7
    c.r[3] = ld32(c.r[7]);  // 0608A0E8 mov.l @r7,r3
    c.r[6] = c.r[1];  // 0608A0EA mov r1,r6
    c.r[5] = c.r[2];  // 0608A0EC mov r2,r5
    c.r[4] = c.r[3];  // 0608A0EE mov r3,r4
    c.r[8] = ld32(0x0608A140u);  // 0608A0F0 mov.l 0x0608A140,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608A0F6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608A0F6u) return; }  // 0608A0F2 jsr @r8 ; nop
    c.r[1] = ld32(c.r[14] + 52);  // 0608A0F6 mov.l @(52,r14),r1
    c.r[3] = ld32(c.r[14] + 8);  // 0608A0F8 mov.l @(8,r14),r3
    c.r[2] = ld32(c.r[3]);  // 0608A0FA mov.l @r3,r2
    c.r[3] = c.r[14];  // 0608A0FC mov r14,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x0608A134u);  // 0608A0FE mov.w 0x0608A134,r7
    c.r[3] = c.r[14];  // 0608A100 mov r14,r3
    c.r[3] += c.r[7];  // 0608A102 add r7,r3
    c.r[7] = ld32(c.r[3]);  // 0608A104 mov.l @r3,r7
    c.r[6] = ld32(c.r[14] + 48);  // 0608A106 mov.l @(48,r14),r6
    c.r[3] = c.r[7];  // 0608A108 mov r7,r3
    c.r[3] += c.r[6];  // 0608A10A add r6,r3
    c.r[6] = c.r[1];  // 0608A10C mov r1,r6
    c.r[5] = c.r[2];  // 0608A10E mov r2,r5
    c.r[4] = c.r[3];  // 0608A110 mov r3,r4
    c.r[8] = ld32(0x0608A140u);  // 0608A112 mov.l 0x0608A140,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608A118u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608A118u) return; }  // 0608A114 jsr @r8 ; nop
    c.r[1] = c.r[14];  // 0608A118 mov r14,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0608A136u);  // 0608A11A mov.w 0x0608A136,r2
    c.r[1] = c.r[14];  // 0608A11C mov r14,r1
    c.r[1] += c.r[2];  // 0608A11E add r2,r1
    c.r[2] = c.r[14];  // 0608A120 mov r14,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608A134u);  // 0608A122 mov.w 0x0608A134,r3
    c.r[2] = c.r[14];  // 0608A124 mov r14,r2
    c.r[2] += c.r[3];  // 0608A126 add r3,r2
    c.r[3] = ld32(c.r[2]);  // 0608A128 mov.l @r2,r3
    st32(c.r[1], c.r[3]);  // 0608A12A mov.l r3,@r1
    goto L_0608A156;  // 0608A12C bra 0x0608A156 ; nop
L_0608A144:
    c.r[1] = c.r[14];  // 0608A144 mov r14,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0608A274u);  // 0608A146 mov.w 0x0608A274,r2
    c.r[1] = c.r[14];  // 0608A148 mov r14,r1
    c.r[1] += c.r[2];  // 0608A14A add r2,r1
    c.r[3] = ld32(c.r[14] + 12);  // 0608A14C mov.l @(12,r14),r3
    c.r[2] = c.r[3];  // 0608A14E mov r3,r2
    c.r[3] += 76;  // 0608A150 add #76,r3
    c.r[2] = ld32(c.r[3]);  // 0608A152 mov.l @r3,r2
    st32(c.r[1], c.r[2]);  // 0608A154 mov.l r2,@r1
L_0608A156:
    c.r[1] = c.r[14];  // 0608A156 mov r14,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608A276u);  // 0608A158 mov.w 0x0608A276,r3
    c.r[2] = c.r[14];  // 0608A15A mov r14,r2
    c.r[2] += c.r[3];  // 0608A15C add r3,r2
    c.r[1] = ld32(c.r[2]);  // 0608A15E mov.l @r2,r1
    c.r[2] = c.r[14];  // 0608A160 mov r14,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608A274u);  // 0608A162 mov.w 0x0608A274,r3
    c.r[2] = c.r[14];  // 0608A164 mov r14,r2
    c.r[2] += c.r[3];  // 0608A166 add r3,r2
    c.r[3] = ld32(c.r[2]);  // 0608A168 mov.l @r2,r3
    c.r[5] = c.r[1];  // 0608A16A mov r1,r5
    c.r[4] = c.r[3];  // 0608A16C mov r3,r4
    c.r[8] = ld32(0x0608A27Cu);  // 0608A16E mov.l 0x0608A27C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608A174u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608A174u) return; }  // 0608A170 jsr @r8 ; nop
    c.r[1] = c.r[14];  // 0608A174 mov r14,r1
    c.r[1] += 24;  // 0608A176 add #24,r1
    c.r[2] = c.r[14];  // 0608A178 mov r14,r2
    c.r[2] += 20;  // 0608A17A add #20,r2
    c.r[3] = c.r[14];  // 0608A17C mov r14,r3
    c.r[3] += 16;  // 0608A17E add #16,r3
    c.r[7] = c.r[14];  // 0608A180 mov r14,r7
    c.r[7] += 28;  // 0608A182 add #28,r7
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 0608A184 mov.l r7,@-r15
    c.r[7] = c.r[1];  // 0608A186 mov r1,r7
    c.r[6] = c.r[2];  // 0608A188 mov r2,r6
    c.r[5] = c.r[3];  // 0608A18A mov r3,r5
    c.r[4] = ld32(c.r[14]);  // 0608A18C mov.l @r14,r4
    c.r[8] = ld32(0x0608A280u);  // 0608A18E mov.l 0x0608A280,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608A194u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608A194u) return; }  // 0608A190 jsr @r8 ; nop
    c.r[15] += 4;  // 0608A194 add #4,r15
    c.r[1] = ld32(c.r[14] + 24);  // 0608A196 mov.l @(24,r14),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0608A278u);  // 0608A198 mov.w 0x0608A278,r2
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 0608A19A cmp/gt r2,r1
    if (c.t) { goto L_0608A1A2; }  // 0608A19C bt 0x0608A1A2
    goto L_0608A1A4;  // 0608A19E bra 0x0608A1A4 ; nop
L_0608A1A2:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0608A278u);  // 0608A1A2 mov.w 0x0608A278,r1
L_0608A1A4:
    st32(c.r[14] + 48, c.r[1]);  // 0608A1A4 mov.l r1,@(48,r14)
    c.r[1] = (uint32_t)(int16_t)ld16(0x0608A278u);  // 0608A1A6 mov.w 0x0608A278,r1
    c.r[2] = ld32(c.r[14] + 48);  // 0608A1A8 mov.l @(48,r14),r2
    c.r[1] -= c.r[2];  // 0608A1AA sub r2,r1
    st32(c.r[14] + 52, c.r[1]);  // 0608A1AC mov.l r1,@(52,r14)
    c.r[2] = ld32(c.r[14] + 48);  // 0608A1AE mov.l @(48,r14),r2
    c.r[1] = c.r[2];  // 0608A1B0 mov r2,r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0608A1B2 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0608A1B4 shar r1
    c.r[2] = c.r[1];  // 0608A1B6 mov r1,r2
    st32(c.r[14] + 56, c.r[2]);  // 0608A1B8 mov.l r2,@(56,r14)
    c.r[2] = ld32(c.r[14] + 52);  // 0608A1BA mov.l @(52,r14),r2
    c.r[1] = c.r[2];  // 0608A1BC mov r2,r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0608A1BE shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0608A1C0 shar r1
    c.r[2] = c.r[1];  // 0608A1C2 mov r1,r2
    st32(c.r[14] + 60, c.r[2]);  // 0608A1C4 mov.l r2,@(60,r14)
    c.r[1] = ld32(c.r[14] + 56);  // 0608A1C6 mov.l @(56,r14),r1
    c.r[2] = c.r[14];  // 0608A1C8 mov r14,r2
    c.r[7] = (uint32_t)(int16_t)ld16(0x0608A276u);  // 0608A1CA mov.w 0x0608A276,r7
    c.r[3] = c.r[14];  // 0608A1CC mov r14,r3
    c.r[3] += c.r[7];  // 0608A1CE add r7,r3
    c.r[2] = ld32(c.r[3]);  // 0608A1D0 mov.l @r3,r2
    c.r[3] = ld32(c.r[14] + 16);  // 0608A1D2 mov.l @(16,r14),r3
    c.r[6] = c.r[1];  // 0608A1D4 mov r1,r6
    c.r[5] = c.r[2];  // 0608A1D6 mov r2,r5
    c.r[4] = c.r[3];  // 0608A1D8 mov r3,r4
    c.r[8] = ld32(0x0608A284u);  // 0608A1DA mov.l 0x0608A284,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608A1E0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608A1E0u) return; }  // 0608A1DC jsr @r8 ; nop
    c.r[1] = ld32(c.r[14] + 48);  // 0608A1E0 mov.l @(48,r14),r1
    c.r[5] = c.r[1];  // 0608A1E2 mov r1,r5
    c.r[4] = ld32(c.r[14]);  // 0608A1E4 mov.l @r14,r4
    c.r[8] = ld32(0x0608A288u);  // 0608A1E6 mov.l 0x0608A288,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608A1ECu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608A1ECu) return; }  // 0608A1E8 jsr @r8 ; nop
    c.r[1] = ld32(c.r[14] + 52);  // 0608A1EC mov.l @(52,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0608A1EE tst r1,r1
    if (!c.t) { goto L_0608A1F6; }  // 0608A1F0 bf 0x0608A1F6
    goto L_0608A244;  // 0608A1F2 bra 0x0608A244 ; nop
L_0608A1F6:
    c.r[1] = c.r[14];  // 0608A1F6 mov r14,r1
    c.r[1] += 24;  // 0608A1F8 add #24,r1
    c.r[2] = c.r[14];  // 0608A1FA mov r14,r2
    c.r[2] += 20;  // 0608A1FC add #20,r2
    c.r[3] = c.r[14];  // 0608A1FE mov r14,r3
    c.r[3] += 16;  // 0608A200 add #16,r3
    c.r[7] = c.r[14];  // 0608A202 mov r14,r7
    c.r[7] += 28;  // 0608A204 add #28,r7
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 0608A206 mov.l r7,@-r15
    c.r[7] = c.r[1];  // 0608A208 mov r1,r7
    c.r[6] = c.r[2];  // 0608A20A mov r2,r6
    c.r[5] = c.r[3];  // 0608A20C mov r3,r5
    c.r[4] = ld32(c.r[14]);  // 0608A20E mov.l @r14,r4
    c.r[8] = ld32(0x0608A280u);  // 0608A210 mov.l 0x0608A280,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608A216u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608A216u) return; }  // 0608A212 jsr @r8 ; nop
    c.r[15] += 4;  // 0608A216 add #4,r15
    c.r[1] = ld32(c.r[14] + 60);  // 0608A218 mov.l @(60,r14),r1
    c.r[2] = c.r[14];  // 0608A21A mov r14,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608A276u);  // 0608A21C mov.w 0x0608A276,r3
    c.r[2] = c.r[14];  // 0608A21E mov r14,r2
    c.r[2] += c.r[3];  // 0608A220 add r3,r2
    c.r[3] = ld32(c.r[2]);  // 0608A222 mov.l @r2,r3
    c.r[7] = ld32(c.r[14] + 48);  // 0608A224 mov.l @(48,r14),r7
    c.r[2] = c.r[3];  // 0608A226 mov r3,r2
    c.r[2] += c.r[7];  // 0608A228 add r7,r2
    c.r[3] = ld32(c.r[14] + 16);  // 0608A22A mov.l @(16,r14),r3
    c.r[6] = c.r[1];  // 0608A22C mov r1,r6
    c.r[5] = c.r[2];  // 0608A22E mov r2,r5
    c.r[4] = c.r[3];  // 0608A230 mov r3,r4
    c.r[8] = ld32(0x0608A284u);  // 0608A232 mov.l 0x0608A284,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608A238u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608A238u) return; }  // 0608A234 jsr @r8 ; nop
    c.r[1] = ld32(c.r[14] + 52);  // 0608A238 mov.l @(52,r14),r1
    c.r[5] = c.r[1];  // 0608A23A mov r1,r5
    c.r[4] = ld32(c.r[14]);  // 0608A23C mov.l @r14,r4
    c.r[8] = ld32(0x0608A288u);  // 0608A23E mov.l 0x0608A288,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608A244u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608A244u) return; }  // 0608A240 jsr @r8 ; nop
L_0608A244:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0608A27Au);  // 0608A244 mov.w 0x0608A27A,r1
    c.r[5] = c.r[1];  // 0608A246 mov r1,r5
    c.r[4] = ld32(c.r[14]);  // 0608A248 mov.l @r14,r4
    c.r[8] = ld32(0x0608A28Cu);  // 0608A24A mov.l 0x0608A28C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608A250u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608A250u) return; }  // 0608A24C jsr @r8 ; nop
    c.r[1] = ld32(c.r[14] + 12);  // 0608A250 mov.l @(12,r14),r1
    c.r[0] = ld32(c.r[1] + 48);  // 0608A252 mov.l @(48,r1),r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0608A254 cmp/eq #-1,r0
    if (!c.t) { goto L_0608A25C; }  // 0608A256 bf 0x0608A25C
    goto L_0608A290;  // 0608A258 bra 0x0608A290 ; nop
L_0608A25C:
    c.r[2] = ld32(c.r[14] + 12);  // 0608A25C mov.l @(12,r14),r2
    c.r[1] = c.r[2];  // 0608A25E mov r2,r1
    c.r[2] += 104;  // 0608A260 add #104,r2
    c.r[1] = ld32(c.r[14] + 12);  // 0608A262 mov.l @(12,r14),r1
    c.r[2] = ld32(c.r[2]);  // 0608A264 mov.l @r2,r2
    c.r[1] = ld32(c.r[1] + 48);  // 0608A266 mov.l @(48,r1),r1
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[1];  // 0608A268 cmp/ge r1,r2
    if (c.t) { goto L_0608A270; }  // 0608A26A bt 0x0608A270
    goto L_0608A290;  // 0608A26C bra 0x0608A290 ; nop
L_0608A270:
    goto L_0608A336;  // 0608A270 bra 0x0608A336 ; nop
L_0608A290:
    c.r[1] = ld32(c.r[14] + 12);  // 0608A290 mov.l @(12,r14),r1
    c.r[2] = c.r[1];  // 0608A292 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608A34Au);  // 0608A294 mov.w 0x0608A34A,r3
    c.r[2] = c.r[1];  // 0608A296 mov r1,r2
    c.r[2] += c.r[3];  // 0608A298 add r3,r2
    c.r[1] = ld32(c.r[14] + 12);  // 0608A29A mov.l @(12,r14),r1
    c.r[2] = c.r[1];  // 0608A29C mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608A34Au);  // 0608A29E mov.w 0x0608A34A,r3
    c.r[1] += c.r[3];  // 0608A2A0 add r3,r1
    c.r[2] = ld32(c.r[14] + 12);  // 0608A2A2 mov.l @(12,r14),r2
    c.r[3] = c.r[2];  // 0608A2A4 mov r2,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x0608A34Au);  // 0608A2A6 mov.w 0x0608A34A,r7
    c.r[2] += c.r[7];  // 0608A2A8 add r7,r2
    c.r[3] = ld32(c.r[2]);  // 0608A2AA mov.l @r2,r3
    c.r[2] = c.r[3];  // 0608A2AC mov r3,r2
    c.r[2] += 1;  // 0608A2AE add #1,r2
    c.r[3] = c.r[2];  // 0608A2B0 mov r2,r3
    st32(c.r[1], c.r[3]);  // 0608A2B2 mov.l r3,@r1
    c.r[1] = ld32(c.r[14] + 12);  // 0608A2B4 mov.l @(12,r14),r1
    c.r[2] = c.r[1];  // 0608A2B6 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608A34Au);  // 0608A2B8 mov.w 0x0608A34A,r3
    c.r[2] = c.r[1];  // 0608A2BA mov r1,r2
    c.r[2] += c.r[3];  // 0608A2BC add r3,r2
    c.r[1] = ld32(c.r[2]);  // 0608A2BE mov.l @r2,r1
    c.r[2] = ld32(0x0608A350u);  // 0608A2C0 mov.l 0x0608A350,r2
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[1] * (int32_t)c.r[2]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 0608A2C2 dmuls.l r2,r1
    c.r[3] = c.mach;  // 0608A2C4 sts mach,r3
    c.r[2] = c.r[3];  // 0608A2C6 mov r3,r2
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 0608A2C8 shar r2
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 0608A2CA shar r2
    c.r[3] = c.r[2];  // 0608A2CC mov r2,r3
    c.r[7] = c.r[1];  // 0608A2CE mov r1,r7
    c.t = c.r[7] >> 31; c.r[7] <<= 1;  // 0608A2D0 shll r7
    { uint32_t a = c.r[7], b = c.r[7], t = c.t; c.r[7] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 0608A2D2 subc r7,r7
    c.r[2] = c.r[3];  // 0608A2D4 mov r3,r2
    c.r[2] -= c.r[7];  // 0608A2D6 sub r7,r2
    c.r[3] = 0x12u;  // 0608A2D8 mov #18,r3
    c.macl = c.r[2] * c.r[3];  // 0608A2DA mul.l r3,r2
    c.r[2] = c.macl;  // 0608A2DC sts macl,r2
    c.r[1] -= c.r[2];  // 0608A2DE sub r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0608A2E0 tst r1,r1
    if (c.t) { goto L_0608A2E8; }  // 0608A2E2 bt 0x0608A2E8
    goto L_0608A316;  // 0608A2E4 bra 0x0608A316 ; nop
L_0608A2E8:
    c.r[5] = 0x14u;  // 0608A2E8 mov #20,r5
    c.r[4] = ld32(c.r[14]);  // 0608A2EA mov.l @r14,r4
    c.r[8] = ld32(0x0608A354u);  // 0608A2EC mov.l 0x0608A354,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608A2F2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608A2F2u) return; }  // 0608A2EE jsr @r8 ; nop
    c.r[1] = ld32(c.r[14] + 12);  // 0608A2F2 mov.l @(12,r14),r1
    c.r[0] = ld32(c.r[1] + 48);  // 0608A2F4 mov.l @(48,r1),r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0608A2F6 cmp/eq #-1,r0
    if (!c.t) { goto L_0608A2FE; }  // 0608A2F8 bf 0x0608A2FE
    goto L_0608A316;  // 0608A2FA bra 0x0608A316 ; nop
L_0608A2FE:
    c.r[2] = ld32(c.r[14] + 12);  // 0608A2FE mov.l @(12,r14),r2
    c.r[1] = c.r[2];  // 0608A300 mov r2,r1
    c.r[2] += 104;  // 0608A302 add #104,r2
    c.r[1] = ld32(c.r[14] + 12);  // 0608A304 mov.l @(12,r14),r1
    c.r[2] = ld32(c.r[2]);  // 0608A306 mov.l @r2,r2
    c.r[1] = ld32(c.r[1] + 48);  // 0608A308 mov.l @(48,r1),r1
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[1];  // 0608A30A cmp/ge r1,r2
    if (c.t) { goto L_0608A312; }  // 0608A30C bt 0x0608A312
    goto L_0608A316;  // 0608A30E bra 0x0608A316 ; nop
L_0608A312:
    goto L_0608A336;  // 0608A312 bra 0x0608A336 ; nop
L_0608A316:
    c.r[1] = c.r[14];  // 0608A316 mov r14,r1
    c.r[2] = c.r[14];  // 0608A318 mov r14,r2
    c.r[2] += 64;  // 0608A31A add #64,r2
    c.r[3] = c.r[14];  // 0608A31C mov r14,r3
    c.r[1] = c.r[14];  // 0608A31E mov r14,r1
    c.r[1] += 64;  // 0608A320 add #64,r1
    c.r[2] = c.r[14];  // 0608A322 mov r14,r2
    c.r[3] = c.r[14];  // 0608A324 mov r14,r3
    c.r[3] += 64;  // 0608A326 add #64,r3
    c.r[7] = ld32(c.r[3]);  // 0608A328 mov.l @r3,r7
    c.r[2] = c.r[7];  // 0608A32A mov r7,r2
    c.r[2] += 1;  // 0608A32C add #1,r2
    c.r[3] = c.r[2];  // 0608A32E mov r2,r3
    st32(c.r[1], c.r[3]);  // 0608A330 mov.l r3,@r1
    SH2_POLL(c); goto L_0608A088;  // 0608A332 bra 0x0608A088 ; nop
L_0608A336:
    goto L_0608A33A;  // 0608A336 bra 0x0608A33A ; nop
L_0608A33A:
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608A34Cu);  // 0608A33A mov.w 0x0608A34C,r3
    c.r[14] += c.r[3];  // 0608A33C add r3,r14
    c.r[15] = c.r[14];  // 0608A33E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608A340 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608A342 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608A344 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608A346 rts ; nop
}

void f_0608A358(SH2Context& c) {
    ran[1968] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608A358 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608A35A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608A35C sts.l pr,@-r15
    c.r[15] -= 12;  // 0608A35E add #-12,r15
    c.r[14] = c.r[15];  // 0608A360 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608A362 mov.l r4,@r14
    c.r[1] = ld32(c.r[14]);  // 0608A364 mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 0608A366 mov.l @r1,r2
    st32(c.r[14] + 4, c.r[2]);  // 0608A368 mov.l r2,@(4,r14)
    c.r[1] = ld32(c.r[14] + 4);  // 0608A36A mov.l @(4,r14),r1
    c.r[2] = c.r[1];  // 0608A36C mov r1,r2
    c.r[2] += 56;  // 0608A36E add #56,r2
    st32(c.r[14] + 8, c.r[2]);  // 0608A370 mov.l r2,@(8,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 0608A372 mov.l @(8,r14),r1
    c.r[0] = ld32(c.r[1] + 28);  // 0608A374 mov.l @(28,r1),r0
    c.t = c.r[0] == 0x6u;  // 0608A376 cmp/eq #6,r0
    if (!c.t) { goto L_0608A386; }  // 0608A378 bf 0x0608A386
    c.r[4] = ld32(c.r[14]);  // 0608A37A mov.l @r14,r4
    c.r[8] = ld32(0x0608A3A4u);  // 0608A37C mov.l 0x0608A3A4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608A382u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608A382u) return; }  // 0608A37E jsr @r8 ; nop
    goto L_0608A396;  // 0608A382 bra 0x0608A396 ; nop
L_0608A386:
    c.r[1] = ld32(c.r[14] + 8);  // 0608A386 mov.l @(8,r14),r1
    c.r[0] = ld32(c.r[1] + 28);  // 0608A388 mov.l @(28,r1),r0
    c.t = c.r[0] == 0x5u;  // 0608A38A cmp/eq #5,r0
    if (!c.t) { goto L_0608A396; }  // 0608A38C bf 0x0608A396
    c.r[4] = ld32(c.r[14]);  // 0608A38E mov.l @r14,r4
    c.r[8] = ld32(0x0608A3A8u);  // 0608A390 mov.l 0x0608A3A8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608A396u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608A396u) return; }  // 0608A392 jsr @r8 ; nop
L_0608A396:
    c.r[14] += 12;  // 0608A396 add #12,r14
    c.r[15] = c.r[14];  // 0608A398 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608A39A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608A39C mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608A39E mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608A3A0 rts ; nop
}

void f_0608A3AC(SH2Context& c) {
    ran[1969] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608A3AC mov.l r14,@-r15
    c.r[15] -= 16;  // 0608A3AE add #-16,r15
    c.r[14] = c.r[15];  // 0608A3B0 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608A3B2 mov.l r4,@r14
    c.r[1] = ld32(c.r[14]);  // 0608A3B4 mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 0608A3B6 mov.l @r1,r2
    st32(c.r[14] + 4, c.r[2]);  // 0608A3B8 mov.l r2,@(4,r14)
    c.r[1] = ld32(c.r[14] + 4);  // 0608A3BA mov.l @(4,r14),r1
    c.r[2] = c.r[1];  // 0608A3BC mov r1,r2
    c.r[2] += 56;  // 0608A3BE add #56,r2
    st32(c.r[14] + 8, c.r[2]);  // 0608A3C0 mov.l r2,@(8,r14)
    c.r[1] = ld32(c.r[14] + 4);  // 0608A3C2 mov.l @(4,r14),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0608A430u);  // 0608A3C4 mov.w 0x0608A430,r2
    c.r[1] += c.r[2];  // 0608A3C6 add r2,r1
    st32(c.r[14] + 12, c.r[1]);  // 0608A3C8 mov.l r1,@(12,r14)
    c.r[2] = ld32(c.r[14] + 8);  // 0608A3CA mov.l @(8,r14),r2
    c.r[1] = c.r[2];  // 0608A3CC mov r2,r1
    c.r[1] += 24;  // 0608A3CE add #24,r1
    c.r[2] = 0xFFFFFFFFu;  // 0608A3D0 mov #-1,r2
    st32(c.r[1] + 8, c.r[2]);  // 0608A3D2 mov.l r2,@(8,r1)
    c.r[2] = ld32(c.r[14] + 8);  // 0608A3D4 mov.l @(8,r14),r2
    c.r[1] = c.r[2];  // 0608A3D6 mov r2,r1
    c.r[1] += 24;  // 0608A3D8 add #24,r1
    c.r[2] = 0x10u;  // 0608A3DA mov #16,r2
    st32(c.r[1] + 16, c.r[2]);  // 0608A3DC mov.l r2,@(16,r1)
    c.r[2] = ld32(c.r[14] + 8);  // 0608A3DE mov.l @(8,r14),r2
    c.r[1] = c.r[2];  // 0608A3E0 mov r2,r1
    c.r[1] += 24;  // 0608A3E2 add #24,r1
    c.r[2] = 0xFFFFFFFFu;  // 0608A3E4 mov #-1,r2
    st32(c.r[1] + 12, c.r[2]);  // 0608A3E6 mov.l r2,@(12,r1)
    c.r[2] = ld32(c.r[14] + 8);  // 0608A3E8 mov.l @(8,r14),r2
    c.r[1] = c.r[2];  // 0608A3EA mov r2,r1
    c.r[1] += 24;  // 0608A3EC add #24,r1
    c.r[2] = 0xFFFFFFFFu;  // 0608A3EE mov #-1,r2
    st32(c.r[1] + 20, c.r[2]);  // 0608A3F0 mov.l r2,@(20,r1)
    c.r[2] = ld32(c.r[14] + 8);  // 0608A3F2 mov.l @(8,r14),r2
    c.r[1] = c.r[2];  // 0608A3F4 mov r2,r1
    c.r[1] += 24;  // 0608A3F6 add #24,r1
    c.r[2] = 0xFFFFFFFFu;  // 0608A3F8 mov #-1,r2
    st32(c.r[1] + 24, c.r[2]);  // 0608A3FA mov.l r2,@(24,r1)
    c.r[2] = ld32(c.r[14] + 8);  // 0608A3FC mov.l @(8,r14),r2
    c.r[1] = c.r[2];  // 0608A3FE mov r2,r1
    c.r[1] += 24;  // 0608A400 add #24,r1
    c.r[2] = 0xFFFFFFFFu;  // 0608A402 mov #-1,r2
    st32(c.r[1] + 28, c.r[2]);  // 0608A404 mov.l r2,@(28,r1)
    c.r[1] = ld32(c.r[14] + 8);  // 0608A406 mov.l @(8,r14),r1
    c.r[0] = ld32(c.r[1] + 24);  // 0608A408 mov.l @(24,r1),r0
    c.t = c.r[0] == 0x1u;  // 0608A40A cmp/eq #1,r0
    if (!c.t) { goto L_0608A414; }  // 0608A40C bf 0x0608A414
    c.r[1] = ld32(c.r[14] + 8);  // 0608A40E mov.l @(8,r14),r1
    c.r[2] = 0x1u;  // 0608A410 mov #1,r2
    st32(c.r[1] + 12, c.r[2]);  // 0608A412 mov.l r2,@(12,r1)
L_0608A414:
    c.r[1] = ld32(c.r[14] + 12);  // 0608A414 mov.l @(12,r14),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0608A432u);  // 0608A416 mov.w 0x0608A432,r2
    st32(c.r[1] + 36, c.r[2]);  // 0608A418 mov.l r2,@(36,r1)
    c.r[1] = ld32(c.r[14] + 8);  // 0608A41A mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 0608A41C mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608A434u);  // 0608A41E mov.w 0x0608A434,r3
    c.r[1] += c.r[3];  // 0608A420 add r3,r1
    c.r[2] = ld32(0x0608A438u);  // 0608A422 mov.l 0x0608A438,r2
    st32(c.r[1], c.r[2]);  // 0608A424 mov.l r2,@r1
    c.r[14] += 16;  // 0608A426 add #16,r14
    c.r[15] = c.r[14];  // 0608A428 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608A42A mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608A42C rts ; nop
}

void f_0608A43C(SH2Context& c) {
    ran[1970] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608A43C mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0608A43E mov r15,r14
    c.r[1] = ld32(0x0608A454u);  // 0608A440 mov.l 0x0608A454,r1
    c.r[2] = ld32(0x0608A458u);  // 0608A442 mov.l 0x0608A458,r2
    st32(c.r[1], c.r[2]);  // 0608A444 mov.l r2,@r1
    c.r[1] = ld32(0x0608A45Cu);  // 0608A446 mov.l 0x0608A45C,r1
    c.r[2] = ld32(0x0608A460u);  // 0608A448 mov.l 0x0608A460,r2
    st32(c.r[1], c.r[2]);  // 0608A44A mov.l r2,@r1
    c.r[15] = c.r[14];  // 0608A44C mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608A44E mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608A450 rts ; nop
}

void f_0608A464(SH2Context& c) {
    ran[1971] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608A464 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0608A466 mov r15,r14
    c.r[1] = ld32(0x0608A484u);  // 0608A468 mov.l 0x0608A484,r1
    c.r[2] = 0x0u;  // 0608A46A mov #0,r2
    st32(c.r[1], c.r[2]);  // 0608A46C mov.l r2,@r1
    c.r[1] = ld32(0x0608A488u);  // 0608A46E mov.l 0x0608A488,r1
    c.r[2] = 0x0u;  // 0608A470 mov #0,r2
    st32(c.r[1], c.r[2]);  // 0608A472 mov.l r2,@r1
    c.r[1] = ld32(0x0608A48Cu);  // 0608A474 mov.l 0x0608A48C,r1
    c.r[2] = 0x0u;  // 0608A476 mov #0,r2
    st32(c.r[1], c.r[2]);  // 0608A478 mov.l r2,@r1
    c.r[15] = c.r[14];  // 0608A47A mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608A47C mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608A47E rts ; nop
}

void f_0608A490(SH2Context& c) {
    ran[1972] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608A490 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608A492 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608A494 sts.l pr,@-r15
    c.r[15] -= 12;  // 0608A496 add #-12,r15
    c.r[14] = c.r[15];  // 0608A498 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608A49A mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 0608A49C mov.l r5,@(4,r14)
    c.r[1] = ld32(0x0608A51Cu);  // 0608A49E mov.l 0x0608A51C,r1
    c.r[2] = ld32(c.r[1]);  // 0608A4A0 mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0608A4A2 tst r2,r2
    if (!c.t) { goto L_0608A4B2; }  // 0608A4A4 bf 0x0608A4B2
    c.r[8] = ld32(0x0608A520u);  // 0608A4A6 mov.l 0x0608A520,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608A4ACu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608A4ACu) return; }  // 0608A4A8 jsr @r8 ; nop
    c.r[1] = ld32(0x0608A51Cu);  // 0608A4AC mov.l 0x0608A51C,r1
    c.r[2] = 0x1u;  // 0608A4AE mov #1,r2
    st32(c.r[1], c.r[2]);  // 0608A4B0 mov.l r2,@r1
L_0608A4B2:
    c.r[1] = ld32(c.r[14] + 4);  // 0608A4B2 mov.l @(4,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0608A4B4 tst r1,r1
    if (!c.t) { goto L_0608A4C8; }  // 0608A4B6 bf 0x0608A4C8
    c.r[1] = (uint32_t)(int16_t)ld16(0x0608A51Au);  // 0608A4B8 mov.w 0x0608A51A,r1
    c.r[4] = c.r[1];  // 0608A4BA mov r1,r4
    c.r[8] = ld32(0x0608A524u);  // 0608A4BC mov.l 0x0608A524,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608A4C2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608A4C2u) return; }  // 0608A4BE jsr @r8 ; nop
    c.r[0] = 0x0u;  // 0608A4C2 mov #0,r0
    goto L_0608A69E;  // 0608A4C4 bra 0x0608A69E ; nop
L_0608A4C8:
    c.r[1] = ld32(c.r[14]);  // 0608A4C8 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0608A4CA tst r1,r1
    if (!c.t) { goto L_0608A4DE; }  // 0608A4CC bf 0x0608A4DE
    c.r[1] = (uint32_t)(int16_t)ld16(0x0608A51Au);  // 0608A4CE mov.w 0x0608A51A,r1
    c.r[4] = c.r[1];  // 0608A4D0 mov r1,r4
    c.r[8] = ld32(0x0608A524u);  // 0608A4D2 mov.l 0x0608A524,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608A4D8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608A4D8u) return; }  // 0608A4D4 jsr @r8 ; nop
    c.r[0] = 0x0u;  // 0608A4D8 mov #0,r0
    goto L_0608A69E;  // 0608A4DA bra 0x0608A69E ; nop
L_0608A4DE:
    c.r[1] = ld32(c.r[14]);  // 0608A4DE mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 0608A4E0 mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0608A4E2 tst r2,r2
    if (c.t) { goto L_0608A50A; }  // 0608A4E4 bt 0x0608A50A
    c.r[1] = ld32(c.r[14]);  // 0608A4E6 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 4);  // 0608A4E8 mov.l @(4,r1),r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0608A4EA tst r2,r2
    if (c.t) { goto L_0608A50A; }  // 0608A4EC bt 0x0608A50A
    c.r[1] = ld32(c.r[14]);  // 0608A4EE mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 8);  // 0608A4F0 mov.l @(8,r1),r2
    c.t = (int32_t)c.r[2] > 0;  // 0608A4F2 cmp/pl r2
    if (!c.t) { goto L_0608A50A; }  // 0608A4F4 bf 0x0608A50A
    c.r[1] = ld32(c.r[14]);  // 0608A4F6 mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 12);  // 0608A4F8 mov.l @(12,r1),r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0608A4FA tst r2,r2
    if (c.t) { goto L_0608A50A; }  // 0608A4FC bt 0x0608A50A
    c.r[1] = ld32(c.r[14]);  // 0608A4FE mov.l @r14,r1
    c.r[2] = ld32(c.r[1] + 16);  // 0608A500 mov.l @(16,r1),r2
    c.t = (int32_t)c.r[2] > 0;  // 0608A502 cmp/pl r2
    if (!c.t) { goto L_0608A50A; }  // 0608A504 bf 0x0608A50A
    goto L_0608A528;  // 0608A506 bra 0x0608A528 ; nop
L_0608A50A:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0608A51Au);  // 0608A50A mov.w 0x0608A51A,r1
    c.r[4] = c.r[1];  // 0608A50C mov r1,r4
    c.r[8] = ld32(0x0608A524u);  // 0608A50E mov.l 0x0608A524,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608A514u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608A514u) return; }  // 0608A510 jsr @r8 ; nop
    c.r[0] = 0x0u;  // 0608A514 mov #0,r0
    goto L_0608A69E;  // 0608A516 bra 0x0608A69E ; nop
L_0608A528:
    c.r[2] = ld32(c.r[14]);  // 0608A528 mov.l @r14,r2
    c.r[1] = ld32(c.r[2] + 8);  // 0608A52A mov.l @(8,r2),r1
    c.r[3] = ld32(c.r[14]);  // 0608A52C mov.l @r14,r3
    c.r[2] = ld32(c.r[3] + 4);  // 0608A52E mov.l @(4,r3),r2
    c.r[7] = ld32(c.r[14]);  // 0608A530 mov.l @r14,r7
    c.r[3] = ld32(c.r[7]);  // 0608A532 mov.l @r7,r3
    c.r[4] = ld32(c.r[14] + 4);  // 0608A534 mov.l @(4,r14),r4
    c.r[7] = ld32(c.r[14]);  // 0608A536 mov.l @r14,r7
    c.r[6] = ld32(c.r[7] + 16);  // 0608A538 mov.l @(16,r7),r6
    c.r[15] -= 4; st32(c.r[15], c.r[6]);  // 0608A53A mov.l r6,@-r15
    c.r[7] = ld32(c.r[14]);  // 0608A53C mov.l @r14,r7
    c.r[6] = ld32(c.r[7] + 12);  // 0608A53E mov.l @(12,r7),r6
    c.r[15] -= 4; st32(c.r[15], c.r[6]);  // 0608A540 mov.l r6,@-r15
    c.r[7] = c.r[1];  // 0608A542 mov r1,r7
    c.r[6] = c.r[2];  // 0608A544 mov r2,r6
    c.r[5] = c.r[3];  // 0608A546 mov r3,r5
    c.r[8] = ld32(0x0608A6D0u);  // 0608A548 mov.l 0x0608A6D0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608A54Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608A54Eu) return; }  // 0608A54A jsr @r8 ; nop
    c.r[15] += 8;  // 0608A54E add #8,r15
    st32(c.r[14] + 8, c.r[0]);  // 0608A550 mov.l r0,@(8,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 0608A552 mov.l @(8,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0608A554 tst r1,r1
    if (!c.t) { goto L_0608A55C; }  // 0608A556 bf 0x0608A55C
    goto L_0608A698;  // 0608A558 bra 0x0608A698 ; nop
L_0608A55C:
    c.r[2] = ld32(c.r[14] + 8);  // 0608A55C mov.l @(8,r14),r2
    c.r[1] = ld32(c.r[2]);  // 0608A55E mov.l @r2,r1
    c.r[2] = c.r[1];  // 0608A560 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608A6ACu);  // 0608A562 mov.w 0x0608A6AC,r3
    c.r[1] += c.r[3];  // 0608A564 add r3,r1
    c.r[2] = 0x2u;  // 0608A566 mov #2,r2
    st32(c.r[1], c.r[2]);  // 0608A568 mov.l r2,@r1
    c.r[2] = ld32(c.r[14] + 8);  // 0608A56A mov.l @(8,r14),r2
    c.r[1] = ld32(c.r[2]);  // 0608A56C mov.l @r2,r1
    c.r[2] = c.r[1];  // 0608A56E mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608A6AEu);  // 0608A570 mov.w 0x0608A6AE,r3
    c.r[1] += c.r[3];  // 0608A572 add r3,r1
    c.r[2] = ld32(0x0608A6D4u);  // 0608A574 mov.l 0x0608A6D4,r2
    st32(c.r[1], c.r[2]);  // 0608A576 mov.l r2,@r1
    c.r[2] = ld32(c.r[14] + 8);  // 0608A578 mov.l @(8,r14),r2
    c.r[1] = ld32(c.r[2]);  // 0608A57A mov.l @r2,r1
    c.r[2] = c.r[1];  // 0608A57C mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608A6B0u);  // 0608A57E mov.w 0x0608A6B0,r3
    c.r[1] += c.r[3];  // 0608A580 add r3,r1
    c.r[2] = ld32(0x0608A6D8u);  // 0608A582 mov.l 0x0608A6D8,r2
    st32(c.r[1], c.r[2]);  // 0608A584 mov.l r2,@r1
    c.r[2] = ld32(c.r[14] + 8);  // 0608A586 mov.l @(8,r14),r2
    c.r[1] = ld32(c.r[2]);  // 0608A588 mov.l @r2,r1
    c.r[2] = c.r[1];  // 0608A58A mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608A6B2u);  // 0608A58C mov.w 0x0608A6B2,r3
    c.r[1] += c.r[3];  // 0608A58E add r3,r1
    c.r[2] = ld32(0x0608A6DCu);  // 0608A590 mov.l 0x0608A6DC,r2
    st32(c.r[1], c.r[2]);  // 0608A592 mov.l r2,@r1
    c.r[2] = ld32(c.r[14] + 8);  // 0608A594 mov.l @(8,r14),r2
    c.r[1] = ld32(c.r[2]);  // 0608A596 mov.l @r2,r1
    c.r[2] = c.r[1];  // 0608A598 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608A6B4u);  // 0608A59A mov.w 0x0608A6B4,r3
    c.r[1] += c.r[3];  // 0608A59C add r3,r1
    c.r[2] = ld32(0x0608A6E0u);  // 0608A59E mov.l 0x0608A6E0,r2
    st32(c.r[1], c.r[2]);  // 0608A5A0 mov.l r2,@r1
    c.r[2] = ld32(c.r[14] + 8);  // 0608A5A2 mov.l @(8,r14),r2
    c.r[1] = ld32(c.r[2]);  // 0608A5A4 mov.l @r2,r1
    c.r[2] = c.r[1];  // 0608A5A6 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608A6B6u);  // 0608A5A8 mov.w 0x0608A6B6,r3
    c.r[1] += c.r[3];  // 0608A5AA add r3,r1
    c.r[2] = ld32(0x0608A6E4u);  // 0608A5AC mov.l 0x0608A6E4,r2
    st32(c.r[1], c.r[2]);  // 0608A5AE mov.l r2,@r1
    c.r[2] = ld32(c.r[14] + 8);  // 0608A5B0 mov.l @(8,r14),r2
    c.r[1] = ld32(c.r[2]);  // 0608A5B2 mov.l @r2,r1
    c.r[2] = c.r[1];  // 0608A5B4 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608A6B8u);  // 0608A5B6 mov.w 0x0608A6B8,r3
    c.r[1] += c.r[3];  // 0608A5B8 add r3,r1
    c.r[2] = 0xFFFFFFFFu;  // 0608A5BA mov #-1,r2
    st32(c.r[1], c.r[2]);  // 0608A5BC mov.l r2,@r1
    c.r[2] = ld32(c.r[14] + 8);  // 0608A5BE mov.l @(8,r14),r2
    c.r[1] = ld32(c.r[2]);  // 0608A5C0 mov.l @r2,r1
    c.r[2] = c.r[1];  // 0608A5C2 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608A6BAu);  // 0608A5C4 mov.w 0x0608A6BA,r3
    c.r[1] += c.r[3];  // 0608A5C6 add r3,r1
    c.r[2] = 0x0u;  // 0608A5C8 mov #0,r2
    st32(c.r[1], c.r[2]);  // 0608A5CA mov.l r2,@r1
    c.r[2] = ld32(c.r[14] + 8);  // 0608A5CC mov.l @(8,r14),r2
    c.r[1] = ld32(c.r[2]);  // 0608A5CE mov.l @r2,r1
    c.r[2] = c.r[1];  // 0608A5D0 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608A6BCu);  // 0608A5D2 mov.w 0x0608A6BC,r3
    c.r[1] += c.r[3];  // 0608A5D4 add r3,r1
    c.r[2] = 0x0u;  // 0608A5D6 mov #0,r2
    st32(c.r[1], c.r[2]);  // 0608A5D8 mov.l r2,@r1
    c.r[2] = ld32(c.r[14] + 8);  // 0608A5DA mov.l @(8,r14),r2
    c.r[1] = ld32(c.r[2]);  // 0608A5DC mov.l @r2,r1
    c.r[2] = c.r[1];  // 0608A5DE mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608A6BEu);  // 0608A5E0 mov.w 0x0608A6BE,r3
    c.r[1] += c.r[3];  // 0608A5E2 add r3,r1
    c.r[2] = 0x0u;  // 0608A5E4 mov #0,r2
    st32(c.r[1], c.r[2]);  // 0608A5E6 mov.l r2,@r1
    c.r[2] = ld32(c.r[14] + 8);  // 0608A5E8 mov.l @(8,r14),r2
    c.r[1] = ld32(c.r[2]);  // 0608A5EA mov.l @r2,r1
    c.r[2] = c.r[1];  // 0608A5EC mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608A6C0u);  // 0608A5EE mov.w 0x0608A6C0,r3
    c.r[1] += c.r[3];  // 0608A5F0 add r3,r1
    c.r[2] = 0x0u;  // 0608A5F2 mov #0,r2
    st32(c.r[1], c.r[2]);  // 0608A5F4 mov.l r2,@r1
    c.r[2] = ld32(c.r[14] + 8);  // 0608A5F6 mov.l @(8,r14),r2
    c.r[1] = ld32(c.r[2]);  // 0608A5F8 mov.l @r2,r1
    c.r[2] = c.r[1];  // 0608A5FA mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608A6C2u);  // 0608A5FC mov.w 0x0608A6C2,r3
    c.r[1] += c.r[3];  // 0608A5FE add r3,r1
    c.r[2] = 0x0u;  // 0608A600 mov #0,r2
    st32(c.r[1], c.r[2]);  // 0608A602 mov.l r2,@r1
    c.r[2] = ld32(c.r[14] + 8);  // 0608A604 mov.l @(8,r14),r2
    c.r[1] = ld32(c.r[2]);  // 0608A606 mov.l @r2,r1
    c.r[2] = c.r[1];  // 0608A608 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608A6C4u);  // 0608A60A mov.w 0x0608A6C4,r3
    c.r[1] += c.r[3];  // 0608A60C add r3,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0608A6C6u);  // 0608A60E mov.w 0x0608A6C6,r2
    st32(c.r[1], c.r[2]);  // 0608A610 mov.l r2,@r1
    c.r[2] = ld32(c.r[14] + 8);  // 0608A612 mov.l @(8,r14),r2
    c.r[1] = ld32(c.r[2]);  // 0608A614 mov.l @r2,r1
    c.r[2] = c.r[1];  // 0608A616 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608A6C8u);  // 0608A618 mov.w 0x0608A6C8,r3
    c.r[1] += c.r[3];  // 0608A61A add r3,r1
    c.r[2] = 0x0u;  // 0608A61C mov #0,r2
    st32(c.r[1], c.r[2]);  // 0608A61E mov.l r2,@r1
    c.r[2] = ld32(c.r[14] + 8);  // 0608A620 mov.l @(8,r14),r2
    c.r[1] = ld32(c.r[2]);  // 0608A622 mov.l @r2,r1
    c.r[2] = c.r[1];  // 0608A624 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608A6CAu);  // 0608A626 mov.w 0x0608A6CA,r3
    c.r[1] += c.r[3];  // 0608A628 add r3,r1
    c.r[2] = ld32(0x0608A6E8u);  // 0608A62A mov.l 0x0608A6E8,r2
    st32(c.r[1], c.r[2]);  // 0608A62C mov.l r2,@r1
    c.r[2] = ld32(c.r[14] + 8);  // 0608A62E mov.l @(8,r14),r2
    c.r[1] = ld32(c.r[2]);  // 0608A630 mov.l @r2,r1
    c.r[2] = c.r[1];  // 0608A632 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608A6CCu);  // 0608A634 mov.w 0x0608A6CC,r3
    c.r[1] += c.r[3];  // 0608A636 add r3,r1
    c.r[2] = ld32(c.r[14] + 4);  // 0608A638 mov.l @(4,r14),r2
    st32(c.r[1], c.r[2]);  // 0608A63A mov.l r2,@r1
    c.r[1] = ld32(c.r[14] + 8);  // 0608A63C mov.l @(8,r14),r1
    c.r[3] = ld32(c.r[14] + 8);  // 0608A63E mov.l @(8,r14),r3
    c.r[2] = ld32(c.r[3]);  // 0608A640 mov.l @r3,r2
    c.r[3] = c.r[2];  // 0608A642 mov r2,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x0608A6CAu);  // 0608A644 mov.w 0x0608A6CA,r7
    c.r[3] = c.r[2];  // 0608A646 mov r2,r3
    c.r[3] += c.r[7];  // 0608A648 add r7,r3
    c.r[2] = ld32(c.r[3]);  // 0608A64A mov.l @r3,r2
    c.r[7] = ld32(c.r[14] + 8);  // 0608A64C mov.l @(8,r14),r7
    c.r[3] = ld32(c.r[7]);  // 0608A64E mov.l @r7,r3
    c.r[7] = c.r[3];  // 0608A650 mov r3,r7
    c.r[6] = (uint32_t)(int16_t)ld16(0x0608A6CCu);  // 0608A652 mov.w 0x0608A6CC,r6
    c.r[7] = c.r[3];  // 0608A654 mov r3,r7
    c.r[7] += c.r[6];  // 0608A656 add r6,r7
    c.r[3] = ld32(c.r[7]);  // 0608A658 mov.l @r7,r3
    c.r[6] = c.r[1];  // 0608A65A mov r1,r6
    c.r[5] = c.r[2];  // 0608A65C mov r2,r5
    c.r[4] = c.r[3];  // 0608A65E mov r3,r4
    c.r[8] = ld32(0x0608A6ECu);  // 0608A660 mov.l 0x0608A6EC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608A666u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608A666u) return; }  // 0608A662 jsr @r8 ; nop
    c.r[2] = ld32(c.r[14] + 8);  // 0608A666 mov.l @(8,r14),r2
    c.r[1] = ld32(c.r[2]);  // 0608A668 mov.l @r2,r1
    c.r[2] = c.r[1];  // 0608A66A mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608A6CEu);  // 0608A66C mov.w 0x0608A6CE,r3
    c.r[1] += c.r[3];  // 0608A66E add r3,r1
    c.r[2] = 0x14u;  // 0608A670 mov #20,r2
    st32(c.r[1], c.r[2]);  // 0608A672 mov.l r2,@r1
    c.r[2] = ld32(c.r[14] + 8);  // 0608A674 mov.l @(8,r14),r2
    c.r[1] = ld32(c.r[2]);  // 0608A676 mov.l @r2,r1
    c.r[2] = c.r[1];  // 0608A678 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608A6CEu);  // 0608A67A mov.w 0x0608A6CE,r3
    c.r[2] = c.r[1];  // 0608A67C mov r1,r2
    c.r[2] += c.r[3];  // 0608A67E add r3,r2
    c.r[1] = ld32(c.r[2]);  // 0608A680 mov.l @r2,r1
    c.r[3] = ld32(c.r[14] + 8);  // 0608A682 mov.l @(8,r14),r3
    c.r[2] = ld32(c.r[3]);  // 0608A684 mov.l @r3,r2
    c.r[3] = c.r[2];  // 0608A686 mov r2,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x0608A6CCu);  // 0608A688 mov.w 0x0608A6CC,r7
    c.r[2] += c.r[7];  // 0608A68A add r7,r2
    c.r[3] = ld32(c.r[2]);  // 0608A68C mov.l @r2,r3
    c.r[5] = c.r[1];  // 0608A68E mov r1,r5
    c.r[4] = c.r[3];  // 0608A690 mov r3,r4
    c.r[8] = ld32(0x0608A6F0u);  // 0608A692 mov.l 0x0608A6F0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608A698u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608A698u) return; }  // 0608A694 jsr @r8 ; nop
L_0608A698:
    c.r[0] = ld32(c.r[14] + 8);  // 0608A698 mov.l @(8,r14),r0
    goto L_0608A69E;  // 0608A69A bra 0x0608A69E ; nop
L_0608A69E:
    c.r[14] += 12;  // 0608A69E add #12,r14
    c.r[15] = c.r[14];  // 0608A6A0 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608A6A2 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608A6A4 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608A6A6 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608A6A8 rts ; nop
}

void f_0608A6F4(SH2Context& c) {
    ran[1973] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608A6F4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608A6F6 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608A6F8 sts.l pr,@-r15
    c.r[15] -= 4;  // 0608A6FA add #-4,r15
    c.r[14] = c.r[15];  // 0608A6FC mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608A6FE mov.l r4,@r14
    c.r[1] = ld32(c.r[14]);  // 0608A700 mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0608A702 tst r1,r1
    if (!c.t) { goto L_0608A714; }  // 0608A704 bf 0x0608A714
    c.r[1] = (uint32_t)(int16_t)ld16(0x0608A768u);  // 0608A706 mov.w 0x0608A768,r1
    c.r[4] = c.r[1];  // 0608A708 mov r1,r4
    c.r[8] = ld32(0x0608A770u);  // 0608A70A mov.l 0x0608A770,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608A710u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608A710u) return; }  // 0608A70C jsr @r8 ; nop
    goto L_0608A75A;  // 0608A710 bra 0x0608A75A ; nop
L_0608A714:
    c.r[2] = ld32(c.r[14]);  // 0608A714 mov.l @r14,r2
    c.r[1] = ld32(c.r[2]);  // 0608A716 mov.l @r2,r1
    c.r[2] = c.r[1];  // 0608A718 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608A76Au);  // 0608A71A mov.w 0x0608A76A,r3
    c.r[1] += c.r[3];  // 0608A71C add r3,r1
    c.r[0] = ld32(c.r[1]);  // 0608A71E mov.l @r1,r0
    c.t = c.r[0] == 0x2u;  // 0608A720 cmp/eq #2,r0
    if (c.t) { goto L_0608A72E; }  // 0608A722 bt 0x0608A72E
    c.r[1] = (uint32_t)(int16_t)ld16(0x0608A76Cu);  // 0608A724 mov.w 0x0608A76C,r1
    c.r[4] = c.r[1];  // 0608A726 mov r1,r4
    c.r[8] = ld32(0x0608A770u);  // 0608A728 mov.l 0x0608A770,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608A72Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608A72Eu) return; }  // 0608A72A jsr @r8 ; nop
L_0608A72E:
    c.r[4] = ld32(c.r[14]);  // 0608A72E mov.l @r14,r4
    c.r[8] = ld32(0x0608A774u);  // 0608A730 mov.l 0x0608A774,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608A736u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608A736u) return; }  // 0608A732 jsr @r8 ; nop
    c.r[1] = ld32(0x0608A778u);  // 0608A736 mov.l 0x0608A778,r1
    c.r[3] = ld32(c.r[14]);  // 0608A738 mov.l @r14,r3
    c.r[2] = ld32(c.r[3]);  // 0608A73A mov.l @r3,r2
    c.r[3] = c.r[2];  // 0608A73C mov r2,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x0608A76Eu);  // 0608A73E mov.w 0x0608A76E,r7
    c.r[3] = c.r[2];  // 0608A740 mov r2,r3
    c.r[3] += c.r[7];  // 0608A742 add r7,r3
    c.r[2] = ld32(c.r[3]);  // 0608A744 mov.l @r3,r2
    c.r[6] = 0x0u;  // 0608A746 mov #0,r6
    c.r[5] = c.r[1];  // 0608A748 mov r1,r5
    c.r[4] = c.r[2];  // 0608A74A mov r2,r4
    c.r[8] = ld32(0x0608A77Cu);  // 0608A74C mov.l 0x0608A77C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608A752u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608A752u) return; }  // 0608A74E jsr @r8 ; nop
    c.r[4] = ld32(c.r[14]);  // 0608A752 mov.l @r14,r4
    c.r[8] = ld32(0x0608A780u);  // 0608A754 mov.l 0x0608A780,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608A75Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608A75Au) return; }  // 0608A756 jsr @r8 ; nop
L_0608A75A:
    c.r[14] += 4;  // 0608A75A add #4,r14
    c.r[15] = c.r[14];  // 0608A75C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608A75E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608A760 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608A762 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608A764 rts ; nop
}

void f_0608A784(SH2Context& c) {
    ran[1974] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608A784 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608A786 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608A788 sts.l pr,@-r15
    c.r[15] -= 68;  // 0608A78A add #-68,r15
    c.r[14] = c.r[15];  // 0608A78C mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608A78E mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 0608A790 mov.l r5,@(4,r14)
    st32(c.r[14] + 8, c.r[6]);  // 0608A792 mov.l r6,@(8,r14)
    st32(c.r[14] + 12, c.r[7]);  // 0608A794 mov.l r7,@(12,r14)
    c.r[1] = c.r[14];  // 0608A796 mov r14,r1
    c.r[2] = c.r[14];  // 0608A798 mov r14,r2
    c.r[2] += 16;  // 0608A79A add #16,r2
    c.r[1] = ld32(c.r[14] + 8);  // 0608A79C mov.l @(8,r14),r1
    st32(c.r[2], c.r[1]);  // 0608A79E mov.l r1,@r2
    c.r[1] = c.r[14];  // 0608A7A0 mov r14,r1
    c.r[2] = c.r[14];  // 0608A7A2 mov r14,r2
    c.r[2] += 16;  // 0608A7A4 add #16,r2
    c.r[1] = ld32(c.r[14] + 12);  // 0608A7A6 mov.l @(12,r14),r1
    st32(c.r[2] + 4, c.r[1]);  // 0608A7A8 mov.l r1,@(4,r2)
    c.r[1] = c.r[14];  // 0608A7AA mov r14,r1
    c.r[2] = c.r[14];  // 0608A7AC mov r14,r2
    c.r[2] += 16;  // 0608A7AE add #16,r2
    c.r[1] = 0x0u;  // 0608A7B0 mov #0,r1
    st32(c.r[2] + 40, c.r[1]);  // 0608A7B2 mov.l r1,@(40,r2)
    c.r[1] = c.r[14];  // 0608A7B4 mov r14,r1
    c.r[2] = c.r[14];  // 0608A7B6 mov r14,r2
    c.r[2] += 16;  // 0608A7B8 add #16,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0608A83Cu);  // 0608A7BA mov.w 0x0608A83C,r1
    st32(c.r[2] + 44, c.r[1]);  // 0608A7BC mov.l r1,@(44,r2)
    c.r[1] = c.r[14];  // 0608A7BE mov r14,r1
    c.r[2] = c.r[14];  // 0608A7C0 mov r14,r2
    c.r[2] += 16;  // 0608A7C2 add #16,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0608A83Eu);  // 0608A7C4 mov.w 0x0608A83E,r1
    st32(c.r[2] + 48, c.r[1]);  // 0608A7C6 mov.l r1,@(48,r2)
    c.r[1] = c.r[14];  // 0608A7C8 mov r14,r1
    c.r[2] = c.r[14];  // 0608A7CA mov r14,r2
    c.r[2] += 16;  // 0608A7CC add #16,r2
    c.r[1] = 0x1u;  // 0608A7CE mov #1,r1
    st32(c.r[2] + 16, c.r[1]);  // 0608A7D0 mov.l r1,@(16,r2)
    c.r[1] = c.r[14];  // 0608A7D2 mov r14,r1
    c.r[2] = c.r[14];  // 0608A7D4 mov r14,r2
    c.r[2] += 16;  // 0608A7D6 add #16,r2
    c.r[1] = 0x1u;  // 0608A7D8 mov #1,r1
    st32(c.r[2] + 20, c.r[1]);  // 0608A7DA mov.l r1,@(20,r2)
    c.r[1] = c.r[14];  // 0608A7DC mov r14,r1
    c.r[2] = c.r[14];  // 0608A7DE mov r14,r2
    c.r[2] += 16;  // 0608A7E0 add #16,r2
    c.r[3] = 0x50u;  // 0608A7E2 mov #80,r3
    c.r[3] += c.r[14];  // 0608A7E4 add r14,r3
    c.r[1] = ld32(c.r[3]);  // 0608A7E6 mov.l @r3,r1
    st32(c.r[2] + 8, c.r[1]);  // 0608A7E8 mov.l r1,@(8,r2)
    c.r[1] = c.r[14];  // 0608A7EA mov r14,r1
    c.r[2] = c.r[14];  // 0608A7EC mov r14,r2
    c.r[2] += 16;  // 0608A7EE add #16,r2
    c.r[3] = 0x54u;  // 0608A7F0 mov #84,r3
    c.r[3] += c.r[14];  // 0608A7F2 add r14,r3
    c.r[1] = ld32(c.r[3]);  // 0608A7F4 mov.l @r3,r1
    st32(c.r[2] + 12, c.r[1]);  // 0608A7F6 mov.l r1,@(12,r2)
    c.r[1] = c.r[14];  // 0608A7F8 mov r14,r1
    c.r[2] = c.r[14];  // 0608A7FA mov r14,r2
    c.r[2] += 16;  // 0608A7FC add #16,r2
    c.r[1] = 0x0u;  // 0608A7FE mov #0,r1
    st32(c.r[2] + 24, c.r[1]);  // 0608A800 mov.l r1,@(24,r2)
    c.r[1] = c.r[14];  // 0608A802 mov r14,r1
    c.r[2] = c.r[14];  // 0608A804 mov r14,r2
    c.r[2] += 16;  // 0608A806 add #16,r2
    c.r[1] = 0x7u;  // 0608A808 mov #7,r1
    st32(c.r[2] + 28, c.r[1]);  // 0608A80A mov.l r1,@(28,r2)
    c.r[1] = c.r[14];  // 0608A80C mov r14,r1
    c.r[2] = c.r[14];  // 0608A80E mov r14,r2
    c.r[2] += 16;  // 0608A810 add #16,r2
    c.r[1] = 0x0u;  // 0608A812 mov #0,r1
    st32(c.r[2] + 32, c.r[1]);  // 0608A814 mov.l r1,@(32,r2)
    c.r[1] = c.r[14];  // 0608A816 mov r14,r1
    c.r[1] += 16;  // 0608A818 add #16,r1
    c.r[2] = ld32(c.r[14] + 4);  // 0608A81A mov.l @(4,r14),r2
    c.r[5] = c.r[1];  // 0608A81C mov r1,r5
    c.r[4] = c.r[2];  // 0608A81E mov r2,r4
    c.r[8] = ld32(0x0608A840u);  // 0608A820 mov.l 0x0608A840,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608A826u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608A826u) return; }  // 0608A822 jsr @r8 ; nop
    c.r[1] = c.r[0];  // 0608A826 mov r0,r1
    c.r[0] = c.r[1];  // 0608A828 mov r1,r0
    goto L_0608A82E;  // 0608A82A bra 0x0608A82E ; nop
L_0608A82E:
    c.r[14] += 68;  // 0608A82E add #68,r14
    c.r[15] = c.r[14];  // 0608A830 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608A832 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608A834 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608A836 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608A838 rts ; nop
}

void f_0608A844(SH2Context& c) {
    ran[1975] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608A844 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608A846 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608A848 sts.l pr,@-r15
    c.r[15] -= 8;  // 0608A84A add #-8,r15
    c.r[14] = c.r[15];  // 0608A84C mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608A84E mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 0608A850 mov.l r5,@(4,r14)
    c.r[2] = ld32(c.r[14]);  // 0608A852 mov.l @r14,r2
    c.r[1] = ld32(c.r[2]);  // 0608A854 mov.l @r2,r1
    c.r[2] = c.r[1];  // 0608A856 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608A892u);  // 0608A858 mov.w 0x0608A892,r3
    c.r[1] += c.r[3];  // 0608A85A add r3,r1
    c.r[2] = ld32(c.r[14] + 4);  // 0608A85C mov.l @(4,r14),r2
    st32(c.r[1], c.r[2]);  // 0608A85E mov.l r2,@r1
    c.r[2] = ld32(c.r[14]);  // 0608A860 mov.l @r14,r2
    c.r[1] = ld32(c.r[2]);  // 0608A862 mov.l @r2,r1
    c.r[2] = c.r[1];  // 0608A864 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608A892u);  // 0608A866 mov.w 0x0608A892,r3
    c.r[2] = c.r[1];  // 0608A868 mov r1,r2
    c.r[2] += c.r[3];  // 0608A86A add r3,r2
    c.r[1] = ld32(c.r[2]);  // 0608A86C mov.l @r2,r1
    c.r[3] = ld32(c.r[14]);  // 0608A86E mov.l @r14,r3
    c.r[2] = ld32(c.r[3]);  // 0608A870 mov.l @r3,r2
    c.r[3] = c.r[2];  // 0608A872 mov r2,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x0608A894u);  // 0608A874 mov.w 0x0608A894,r7
    c.r[2] += c.r[7];  // 0608A876 add r7,r2
    c.r[3] = ld32(c.r[2]);  // 0608A878 mov.l @r2,r3
    c.r[5] = c.r[1];  // 0608A87A mov r1,r5
    c.r[4] = c.r[3];  // 0608A87C mov r3,r4
    c.r[8] = ld32(0x0608A898u);  // 0608A87E mov.l 0x0608A898,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608A884u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608A884u) return; }  // 0608A880 jsr @r8 ; nop
    c.r[14] += 8;  // 0608A884 add #8,r14
    c.r[15] = c.r[14];  // 0608A886 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608A888 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608A88A mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608A88C mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608A88E rts ; nop
}

void f_0608A89C(SH2Context& c) {
    ran[1976] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608A89C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608A89E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608A8A0 sts.l pr,@-r15
    c.r[15] -= 4;  // 0608A8A2 add #-4,r15
    c.r[14] = c.r[15];  // 0608A8A4 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608A8A6 mov.l r4,@r14
    c.r[4] = ld32(c.r[14]);  // 0608A8A8 mov.l @r14,r4
    c.r[8] = ld32(0x0608A8C0u);  // 0608A8AA mov.l 0x0608A8C0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608A8B0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608A8B0u) return; }  // 0608A8AC jsr @r8 ; nop
    c.r[14] += 4;  // 0608A8B0 add #4,r14
    c.r[15] = c.r[14];  // 0608A8B2 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608A8B4 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608A8B6 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608A8B8 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608A8BA rts ; nop
}

void f_0608A8C4(SH2Context& c) {
    ran[1977] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608A8C4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608A8C6 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608A8C8 sts.l pr,@-r15
    c.r[15] -= 20;  // 0608A8CA add #-20,r15
    c.r[14] = c.r[15];  // 0608A8CC mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608A8CE mov.l r4,@r14
    c.r[4] = ld32(c.r[14]);  // 0608A8D0 mov.l @r14,r4
    c.r[8] = ld32(0x0608A984u);  // 0608A8D2 mov.l 0x0608A984,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608A8D8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608A8D8u) return; }  // 0608A8D4 jsr @r8 ; nop
    c.t = (c.r[0] & c.r[0]) == 0;  // 0608A8D8 tst r0,r0
    if (c.t) { goto L_0608A972; }  // 0608A8DA bt 0x0608A972
L_0608A8DC:
    c.r[1] = c.r[14];  // 0608A8DC mov r14,r1
    c.r[1] += 4;  // 0608A8DE add #4,r1
    c.r[3] = ld32(c.r[14]);  // 0608A8E0 mov.l @r14,r3
    c.r[2] = ld32(c.r[3]);  // 0608A8E2 mov.l @r3,r2
    c.r[3] = c.r[2];  // 0608A8E4 mov r2,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x0608A980u);  // 0608A8E6 mov.w 0x0608A980,r7
    c.r[3] = c.r[2];  // 0608A8E8 mov r2,r3
    c.r[3] += c.r[7];  // 0608A8EA add r7,r3
    c.r[2] = ld32(c.r[3]);  // 0608A8EC mov.l @r3,r2
    c.r[7] = ld32(c.r[14]);  // 0608A8EE mov.l @r14,r7
    c.r[3] = ld32(c.r[7]);  // 0608A8F0 mov.l @r7,r3
    c.r[7] = c.r[3];  // 0608A8F2 mov r3,r7
    c.r[6] = (uint32_t)(int16_t)ld16(0x0608A982u);  // 0608A8F4 mov.w 0x0608A982,r6
    c.r[7] = c.r[3];  // 0608A8F6 mov r3,r7
    c.r[7] += c.r[6];  // 0608A8F8 add r6,r7
    c.r[3] = ld32(c.r[7]);  // 0608A8FA mov.l @r7,r3
    c.r[6] = c.r[1];  // 0608A8FC mov r1,r6
    c.r[5] = c.r[2];  // 0608A8FE mov r2,r5
    c.r[4] = c.r[3];  // 0608A900 mov r3,r4
    c.r[8] = ld32(0x0608A988u);  // 0608A902 mov.l 0x0608A988,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608A908u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608A908u) return; }  // 0608A904 jsr @r8 ; nop
    c.t = c.r[0] == 0x1u;  // 0608A908 cmp/eq #1,r0
    if (!c.t) { goto L_0608A96A; }  // 0608A90A bf 0x0608A96A
    c.r[1] = c.r[14];  // 0608A90C mov r14,r1
    c.r[2] = c.r[14];  // 0608A90E mov r14,r2
    c.r[2] += 4;  // 0608A910 add #4,r2
    c.r[1] = c.r[2];  // 0608A912 mov r2,r1
    c.r[2] += 12;  // 0608A914 add #12,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0608A916 mov.b @r2,r1
    c.r[2] = 0x40u;  // 0608A918 mov #64,r2
    c.r[2] &= c.r[1];  // 0608A91A and r1,r2
    c.r[1] = c.r[2] & 0xFFu;  // 0608A91C extu.b r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0608A91E tst r1,r1
    if (c.t) { goto L_0608A93E; }  // 0608A920 bt 0x0608A93E
    c.r[1] = c.r[14];  // 0608A922 mov r14,r1
    c.r[2] = c.r[14];  // 0608A924 mov r14,r2
    c.r[2] += 4;  // 0608A926 add #4,r2
    c.r[1] = c.r[2];  // 0608A928 mov r2,r1
    c.r[2] += 13;  // 0608A92A add #13,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0608A92C mov.b @r2,r3
    c.r[1] = c.r[3] & 0xFFu;  // 0608A92E extu.b r3,r1
    c.r[5] = c.r[1];  // 0608A930 mov r1,r5
    c.r[4] = ld32(c.r[14]);  // 0608A932 mov.l @r14,r4
    c.r[8] = ld32(0x0608A98Cu);  // 0608A934 mov.l 0x0608A98C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608A93Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608A93Au) return; }  // 0608A936 jsr @r8 ; nop
    goto L_0608A96A;  // 0608A93A bra 0x0608A96A ; nop
L_0608A93E:
    c.r[2] = ld32(c.r[14]);  // 0608A93E mov.l @r14,r2
    c.r[1] = ld32(c.r[2]);  // 0608A940 mov.l @r2,r1
    c.r[2] = c.r[1];  // 0608A942 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608A980u);  // 0608A944 mov.w 0x0608A980,r3
    c.r[1] += c.r[3];  // 0608A946 add r3,r1
    c.r[2] = ld32(c.r[14]);  // 0608A948 mov.l @r14,r2
    c.r[1] = ld32(c.r[2]);  // 0608A94A mov.l @r2,r1
    c.r[2] = c.r[1];  // 0608A94C mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608A980u);  // 0608A94E mov.w 0x0608A980,r3
    c.r[1] += c.r[3];  // 0608A950 add r3,r1
    c.r[3] = ld32(c.r[14]);  // 0608A952 mov.l @r14,r3
    c.r[2] = ld32(c.r[3]);  // 0608A954 mov.l @r3,r2
    c.r[3] = c.r[2];  // 0608A956 mov r2,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x0608A980u);  // 0608A958 mov.w 0x0608A980,r7
    c.r[2] += c.r[7];  // 0608A95A add r7,r2
    c.r[3] = ld32(c.r[2]);  // 0608A95C mov.l @r2,r3
    c.r[2] = c.r[3];  // 0608A95E mov r3,r2
    c.r[2] += 1;  // 0608A960 add #1,r2
    c.r[3] = c.r[2];  // 0608A962 mov r2,r3
    st32(c.r[1], c.r[3]);  // 0608A964 mov.l r3,@r1
    goto L_0608A96E;  // 0608A966 bra 0x0608A96E ; nop
L_0608A96A:
    goto L_0608A972;  // 0608A96A bra 0x0608A972 ; nop
L_0608A96E:
    SH2_POLL(c); goto L_0608A8DC;  // 0608A96E bra 0x0608A8DC ; nop
L_0608A972:
    c.r[14] += 20;  // 0608A972 add #20,r14
    c.r[15] = c.r[14];  // 0608A974 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608A976 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608A978 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608A97A mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608A97C rts ; nop
}

void f_0608A990(SH2Context& c) {
    ran[1978] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608A990 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608A992 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608A994 sts.l pr,@-r15
    c.r[15] -= 4;  // 0608A996 add #-4,r15
    c.r[14] = c.r[15];  // 0608A998 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608A99A mov.l r4,@r14
    c.r[4] = ld32(c.r[14]);  // 0608A99C mov.l @r14,r4
    c.r[8] = ld32(0x0608A9C4u);  // 0608A99E mov.l 0x0608A9C4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608A9A4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608A9A4u) return; }  // 0608A9A0 jsr @r8 ; nop
    c.t = (c.r[0] & c.r[0]) == 0;  // 0608A9A4 tst r0,r0
    if (c.t) { goto L_0608A9AC; }  // 0608A9A6 bt 0x0608A9AC
    goto L_0608A9B4;  // 0608A9A8 bra 0x0608A9B4 ; nop
L_0608A9AC:
    c.r[4] = ld32(c.r[14]);  // 0608A9AC mov.l @r14,r4
    c.r[8] = ld32(0x0608A9C8u);  // 0608A9AE mov.l 0x0608A9C8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608A9B4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608A9B4u) return; }  // 0608A9B0 jsr @r8 ; nop
L_0608A9B4:
    c.r[14] += 4;  // 0608A9B4 add #4,r14
    c.r[15] = c.r[14];  // 0608A9B6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608A9B8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608A9BA mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608A9BC mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608A9BE rts ; nop
}

void f_0608A9CC(SH2Context& c) {
    ran[1979] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608A9CC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608A9CE mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608A9D0 sts.l pr,@-r15
    c.r[15] -= 20;  // 0608A9D2 add #-20,r15
    c.r[14] = c.r[15];  // 0608A9D4 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608A9D6 mov.l r4,@r14
    c.r[1] = c.r[14];  // 0608A9D8 mov r14,r1
    c.r[1] += 12;  // 0608A9DA add #12,r1
    c.r[2] = c.r[14];  // 0608A9DC mov r14,r2
    c.r[2] += 8;  // 0608A9DE add #8,r2
    c.r[3] = c.r[14];  // 0608A9E0 mov r14,r3
    c.r[3] += 4;  // 0608A9E2 add #4,r3
    c.r[7] = c.r[1];  // 0608A9E4 mov r1,r7
    c.r[6] = c.r[2];  // 0608A9E6 mov r2,r6
    c.r[5] = c.r[3];  // 0608A9E8 mov r3,r5
    c.r[4] = ld32(c.r[14]);  // 0608A9EA mov.l @r14,r4
    c.r[8] = ld32(0x0608AA9Cu);  // 0608A9EC mov.l 0x0608AA9C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608A9F2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608A9F2u) return; }  // 0608A9EE jsr @r8 ; nop
    c.r[2] = ld32(c.r[14]);  // 0608A9F2 mov.l @r14,r2
    c.r[1] = ld32(c.r[2]);  // 0608A9F4 mov.l @r2,r1
    c.r[2] = c.r[1];  // 0608A9F6 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608AA8Eu);  // 0608A9F8 mov.w 0x0608AA8E,r3
    c.r[1] += c.r[3];  // 0608A9FA add r3,r1
    c.r[2] = ld32(c.r[14] + 4);  // 0608A9FC mov.l @(4,r14),r2
    st32(c.r[1], c.r[2]);  // 0608A9FE mov.l r2,@r1
    c.r[2] = ld32(c.r[14]);  // 0608AA00 mov.l @r14,r2
    c.r[1] = ld32(c.r[2]);  // 0608AA02 mov.l @r2,r1
    c.r[2] = c.r[1];  // 0608AA04 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608AA90u);  // 0608AA06 mov.w 0x0608AA90,r3
    c.r[1] += c.r[3];  // 0608AA08 add r3,r1
    c.r[2] = ld32(c.r[14] + 8);  // 0608AA0A mov.l @(8,r14),r2
    st32(c.r[1], c.r[2]);  // 0608AA0C mov.l r2,@r1
    c.r[2] = ld32(c.r[14]);  // 0608AA0E mov.l @r14,r2
    c.r[1] = ld32(c.r[2]);  // 0608AA10 mov.l @r2,r1
    c.r[2] = c.r[1];  // 0608AA12 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608AA92u);  // 0608AA14 mov.w 0x0608AA92,r3
    c.r[1] += c.r[3];  // 0608AA16 add r3,r1
    c.r[2] = 0x0u;  // 0608AA18 mov #0,r2
    st32(c.r[1], c.r[2]);  // 0608AA1A mov.l r2,@r1
    c.r[2] = ld32(c.r[14]);  // 0608AA1C mov.l @r14,r2
    c.r[1] = ld32(c.r[2]);  // 0608AA1E mov.l @r2,r1
    c.r[2] = c.r[1];  // 0608AA20 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608AA94u);  // 0608AA22 mov.w 0x0608AA94,r3
    c.r[1] += c.r[3];  // 0608AA24 add r3,r1
    c.r[2] = ld32(c.r[14] + 8);  // 0608AA26 mov.l @(8,r14),r2
    c.r[1] = ld32(c.r[1]);  // 0608AA28 mov.l @r1,r1
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[1];  // 0608AA2A cmp/ge r1,r2
    if (!c.t) { goto L_0608AA80; }  // 0608AA2C bf 0x0608AA80
    c.r[2] = ld32(c.r[14]);  // 0608AA2E mov.l @r14,r2
    c.r[1] = ld32(c.r[2]);  // 0608AA30 mov.l @r2,r1
    c.r[2] = c.r[1];  // 0608AA32 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608AA96u);  // 0608AA34 mov.w 0x0608AA96,r3
    c.r[1] += c.r[3];  // 0608AA36 add r3,r1
    c.r[2] = ld32(c.r[1]);  // 0608AA38 mov.l @r1,r2
    c.r[4] = c.r[2];  // 0608AA3A mov r2,r4
    c.r[8] = ld32(0x0608AAA0u);  // 0608AA3C mov.l 0x0608AAA0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608AA42u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608AA42u) return; }  // 0608AA3E jsr @r8 ; nop
    st32(c.r[14] + 16, c.r[0]);  // 0608AA42 mov.l r0,@(16,r14)
    c.r[1] = ld32(c.r[14] + 16);  // 0608AA44 mov.l @(16,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0608AA46 tst r1,r1
    if (c.t) { goto L_0608AA60; }  // 0608AA48 bt 0x0608AA60
    c.r[2] = ld32(c.r[14]);  // 0608AA4A mov.l @r14,r2
    c.r[1] = ld32(c.r[2]);  // 0608AA4C mov.l @r2,r1
    c.r[2] = c.r[1];  // 0608AA4E mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608AA98u);  // 0608AA50 mov.w 0x0608AA98,r3
    c.r[1] += c.r[3];  // 0608AA52 add r3,r1
    c.r[2] = ld32(c.r[14] + 16);  // 0608AA54 mov.l @(16,r14),r2
    c.r[1] = ld32(c.r[1]);  // 0608AA56 mov.l @r1,r1
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[1];  // 0608AA58 cmp/ge r1,r2
    if (c.t) { goto L_0608AA60; }  // 0608AA5A bt 0x0608AA60
    goto L_0608AA72;  // 0608AA5C bra 0x0608AA72 ; nop
L_0608AA60:
    c.r[1] = ld32(0x0608AAA4u);  // 0608AA60 mov.l 0x0608AAA4,r1
    c.r[2] = ld32(c.r[14]);  // 0608AA62 mov.l @r14,r2
    st32(c.r[1], c.r[2]);  // 0608AA64 mov.l r2,@r1
    c.r[8] = ld32(0x0608AAA8u);  // 0608AA66 mov.l 0x0608AAA8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608AA6Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608AA6Cu) return; }  // 0608AA68 jsr @r8 ; nop
    c.r[1] = ld32(0x0608AAA4u);  // 0608AA6C mov.l 0x0608AAA4,r1
    c.r[2] = 0x0u;  // 0608AA6E mov #0,r2
    st32(c.r[1], c.r[2]);  // 0608AA70 mov.l r2,@r1
L_0608AA72:
    c.r[2] = ld32(c.r[14]);  // 0608AA72 mov.l @r14,r2
    c.r[1] = ld32(c.r[2]);  // 0608AA74 mov.l @r2,r1
    c.r[2] = c.r[1];  // 0608AA76 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608AA9Au);  // 0608AA78 mov.w 0x0608AA9A,r3
    c.r[1] += c.r[3];  // 0608AA7A add r3,r1
    c.r[2] = ld32(c.r[14] + 16);  // 0608AA7C mov.l @(16,r14),r2
    st32(c.r[1], c.r[2]);  // 0608AA7E mov.l r2,@r1
L_0608AA80:
    c.r[14] += 20;  // 0608AA80 add #20,r14
    c.r[15] = c.r[14];  // 0608AA82 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608AA84 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608AA86 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608AA88 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608AA8A rts ; nop
}

void f_0608AAAC(SH2Context& c) {
    ran[1980] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608AAAC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608AAAE mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608AAB0 sts.l pr,@-r15
    c.r[15] -= 4;  // 0608AAB2 add #-4,r15
    c.r[14] = c.r[15];  // 0608AAB4 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608AAB6 mov.l r4,@r14
    c.r[2] = ld32(c.r[14]);  // 0608AAB8 mov.l @r14,r2
    c.r[1] = ld32(c.r[2]);  // 0608AABA mov.l @r2,r1
    c.r[2] = c.r[1];  // 0608AABC mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608AB3Cu);  // 0608AABE mov.w 0x0608AB3C,r3
    c.r[1] += c.r[3];  // 0608AAC0 add r3,r1
    c.r[0] = ld32(c.r[1]);  // 0608AAC2 mov.l @r1,r0
    c.t = c.r[0] == 0x1u;  // 0608AAC4 cmp/eq #1,r0
    if (!c.t) { goto L_0608AB2E; }  // 0608AAC6 bf 0x0608AB2E
    c.r[2] = ld32(c.r[14]);  // 0608AAC8 mov.l @r14,r2
    c.r[1] = ld32(c.r[2]);  // 0608AACA mov.l @r2,r1
    c.r[2] = c.r[1];  // 0608AACC mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608AB3Eu);  // 0608AACE mov.w 0x0608AB3E,r3
    c.r[1] += c.r[3];  // 0608AAD0 add r3,r1
    c.r[2] = ld32(c.r[1]);  // 0608AAD2 mov.l @r1,r2
    c.r[1] = ld32(0x0608AB40u);  // 0608AAD4 mov.l 0x0608AB40,r1
    c.t = c.r[2] == c.r[1];  // 0608AAD6 cmp/eq r1,r2
    if (!c.t) { goto L_0608AAF6; }  // 0608AAD8 bf 0x0608AAF6
L_0608AADA:
    c.r[8] = ld32(0x0608AB44u);  // 0608AADA mov.l 0x0608AB44,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608AAE0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608AAE0u) return; }  // 0608AADC jsr @r8 ; nop
    c.t = c.r[0] == 0x2u;  // 0608AAE0 cmp/eq #2,r0
    if (c.t) { goto L_0608AAE8; }  // 0608AAE2 bt 0x0608AAE8
    goto L_0608AAEC;  // 0608AAE4 bra 0x0608AAEC ; nop
L_0608AAE8:
    SH2_POLL(c); goto L_0608AADA;  // 0608AAE8 bra 0x0608AADA ; nop
L_0608AAEC:
    c.r[1] = ld32(0x0608AB48u);  // 0608AAEC mov.l 0x0608AB48,r1
    c.r[2] = 0x0u;  // 0608AAEE mov #0,r2
    st32(c.r[1], c.r[2]);  // 0608AAF0 mov.l r2,@r1
    goto L_0608AB20;  // 0608AAF2 bra 0x0608AB20 ; nop
L_0608AAF6:
    c.r[2] = ld32(c.r[14]);  // 0608AAF6 mov.l @r14,r2
    c.r[1] = ld32(c.r[2]);  // 0608AAF8 mov.l @r2,r1
    c.r[2] = c.r[1];  // 0608AAFA mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608AB3Eu);  // 0608AAFC mov.w 0x0608AB3E,r3
    c.r[1] += c.r[3];  // 0608AAFE add r3,r1
    c.r[2] = ld32(c.r[1]);  // 0608AB00 mov.l @r1,r2
    c.r[1] = ld32(0x0608AB4Cu);  // 0608AB02 mov.l 0x0608AB4C,r1
    c.t = c.r[2] == c.r[1];  // 0608AB04 cmp/eq r1,r2
    if (!c.t) { goto L_0608AB20; }  // 0608AB06 bf 0x0608AB20
L_0608AB08:
    c.r[8] = ld32(0x0608AB50u);  // 0608AB08 mov.l 0x0608AB50,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608AB0Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608AB0Eu) return; }  // 0608AB0A jsr @r8 ; nop
    c.t = c.r[0] == 0x2u;  // 0608AB0E cmp/eq #2,r0
    if (c.t) { goto L_0608AB16; }  // 0608AB10 bt 0x0608AB16
    goto L_0608AB1A;  // 0608AB12 bra 0x0608AB1A ; nop
L_0608AB16:
    SH2_POLL(c); goto L_0608AB08;  // 0608AB16 bra 0x0608AB08 ; nop
L_0608AB1A:
    c.r[1] = ld32(0x0608AB54u);  // 0608AB1A mov.l 0x0608AB54,r1
    c.r[2] = 0x0u;  // 0608AB1C mov #0,r2
    st32(c.r[1], c.r[2]);  // 0608AB1E mov.l r2,@r1
L_0608AB20:
    c.r[2] = ld32(c.r[14]);  // 0608AB20 mov.l @r14,r2
    c.r[1] = ld32(c.r[2]);  // 0608AB22 mov.l @r2,r1
    c.r[2] = c.r[1];  // 0608AB24 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608AB3Cu);  // 0608AB26 mov.w 0x0608AB3C,r3
    c.r[1] += c.r[3];  // 0608AB28 add r3,r1
    c.r[2] = 0x0u;  // 0608AB2A mov #0,r2
    st32(c.r[1], c.r[2]);  // 0608AB2C mov.l r2,@r1
L_0608AB2E:
    c.r[14] += 4;  // 0608AB2E add #4,r14
    c.r[15] = c.r[14];  // 0608AB30 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608AB32 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608AB34 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608AB36 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608AB38 rts ; nop
}

void f_0608AB58(SH2Context& c) {
    ran[1981] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608AB58 mov.l r14,@-r15
    c.r[15] -= 12;  // 0608AB5A add #-12,r15
    c.r[14] = c.r[15];  // 0608AB5C mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608AB5E mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 0608AB60 mov.l r5,@(4,r14)
    st32(c.r[14] + 8, c.r[6]);  // 0608AB62 mov.l r6,@(8,r14)
    c.r[0] = 0x0u;  // 0608AB64 mov #0,r0
    goto L_0608AB6A;  // 0608AB66 bra 0x0608AB6A ; nop
L_0608AB6A:
    c.r[14] += 12;  // 0608AB6A add #12,r14
    c.r[15] = c.r[14];  // 0608AB6C mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608AB6E mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608AB70 rts ; nop
}

void f_0608AB74(SH2Context& c) {
    ran[1982] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608AB74 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608AB76 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608AB78 sts.l pr,@-r15
    c.r[15] -= 40;  // 0608AB7A add #-40,r15
    c.r[14] = c.r[15];  // 0608AB7C mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608AB7E mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 0608AB80 mov.l r5,@(4,r14)
    st32(c.r[14] + 8, c.r[6]);  // 0608AB82 mov.l r6,@(8,r14)
    c.r[1] = ld32(c.r[14]);  // 0608AB84 mov.l @r14,r1
    st32(c.r[14] + 12, c.r[1]);  // 0608AB86 mov.l r1,@(12,r14)
    c.r[1] = ld32(c.r[14] + 12);  // 0608AB88 mov.l @(12,r14),r1
    c.r[4] = c.r[1];  // 0608AB8A mov r1,r4
    c.r[8] = ld32(0x0608ACCCu);  // 0608AB8C mov.l 0x0608ACCC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608AB92u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608AB92u) return; }  // 0608AB8E jsr @r8 ; nop
    c.t = (c.r[0] & c.r[0]) == 0;  // 0608AB92 tst r0,r0
    if (c.t) { goto L_0608AB9C; }  // 0608AB94 bt 0x0608AB9C
    c.r[0] = 0x0u;  // 0608AB96 mov #0,r0
    goto L_0608ACB6;  // 0608AB98 bra 0x0608ACB6 ; nop
L_0608AB9C:
    c.r[2] = ld32(c.r[14] + 12);  // 0608AB9C mov.l @(12,r14),r2
    c.r[1] = ld32(c.r[2]);  // 0608AB9E mov.l @r2,r1
    c.r[2] = c.r[1];  // 0608ABA0 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608ACC4u);  // 0608ABA2 mov.w 0x0608ACC4,r3
    c.r[1] += c.r[3];  // 0608ABA4 add r3,r1
    c.r[0] = ld32(c.r[1]);  // 0608ABA6 mov.l @r1,r0
    c.t = c.r[0] == 0x1u;  // 0608ABA8 cmp/eq #1,r0
    if (!c.t) { goto L_0608AC06; }  // 0608ABAA bf 0x0608AC06
    c.r[8] = ld32(0x0608ACD0u);  // 0608ABAC mov.l 0x0608ACD0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608ABB2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608ABB2u) return; }  // 0608ABAE jsr @r8 ; nop
    c.t = c.r[0] == 0x2u;  // 0608ABB2 cmp/eq #2,r0
    if (!c.t) { goto L_0608ABC0; }  // 0608ABB4 bf 0x0608ABC0
    c.r[0] = 0xFFFFFFFFu;  // 0608ABB6 mov #-1,r0
    goto L_0608ACB6;  // 0608ABB8 bra 0x0608ACB6 ; nop
L_0608ABC0:
    c.r[2] = ld32(c.r[14] + 12);  // 0608ABC0 mov.l @(12,r14),r2
    c.r[1] = ld32(c.r[2]);  // 0608ABC2 mov.l @r2,r1
    c.r[2] = c.r[1];  // 0608ABC4 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608ACC4u);  // 0608ABC6 mov.w 0x0608ACC4,r3
    c.r[1] += c.r[3];  // 0608ABC8 add r3,r1
    c.r[2] = 0x0u;  // 0608ABCA mov #0,r2
    st32(c.r[1], c.r[2]);  // 0608ABCC mov.l r2,@r1
    c.r[2] = ld32(c.r[14] + 12);  // 0608ABCE mov.l @(12,r14),r2
    c.r[1] = ld32(c.r[2]);  // 0608ABD0 mov.l @r2,r1
    c.r[2] = c.r[1];  // 0608ABD2 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608ACC6u);  // 0608ABD4 mov.w 0x0608ACC6,r3
    c.r[1] += c.r[3];  // 0608ABD6 add r3,r1
    c.r[3] = ld32(c.r[14] + 12);  // 0608ABD8 mov.l @(12,r14),r3
    c.r[2] = ld32(c.r[3]);  // 0608ABDA mov.l @r3,r2
    c.r[3] = c.r[2];  // 0608ABDC mov r2,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x0608ACC8u);  // 0608ABDE mov.w 0x0608ACC8,r7
    c.r[2] += c.r[7];  // 0608ABE0 add r7,r2
    c.r[1] = ld32(c.r[1]);  // 0608ABE2 mov.l @r1,r1
    c.r[2] = ld32(c.r[2]);  // 0608ABE4 mov.l @r2,r2
    c.macl = c.r[1] * c.r[2];  // 0608ABE6 mul.l r2,r1
    c.r[1] = c.macl;  // 0608ABE8 sts macl,r1
    c.r[2] = ld32(c.r[14] + 12);  // 0608ABEA mov.l @(12,r14),r2
    c.r[5] = c.r[1];  // 0608ABEC mov r1,r5
    c.r[4] = c.r[2];  // 0608ABEE mov r2,r4
    c.r[8] = ld32(0x0608ACD4u);  // 0608ABF0 mov.l 0x0608ACD4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608ABF6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608ABF6u) return; }  // 0608ABF2 jsr @r8 ; nop
    c.r[2] = ld32(c.r[14] + 12);  // 0608ABF6 mov.l @(12,r14),r2
    c.r[1] = ld32(c.r[2]);  // 0608ABF8 mov.l @r2,r1
    c.r[2] = c.r[1];  // 0608ABFA mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608ACC8u);  // 0608ABFC mov.w 0x0608ACC8,r3
    c.r[1] += c.r[3];  // 0608ABFE add r3,r1
    c.r[0] = ld32(c.r[1]);  // 0608AC00 mov.l @r1,r0
    goto L_0608ACB6;  // 0608AC02 bra 0x0608ACB6 ; nop
L_0608AC06:
    c.r[1] = c.r[14];  // 0608AC06 mov r14,r1
    c.r[1] += 36;  // 0608AC08 add #36,r1
    c.r[2] = c.r[14];  // 0608AC0A mov r14,r2
    c.r[2] += 32;  // 0608AC0C add #32,r2
    c.r[3] = c.r[14];  // 0608AC0E mov r14,r3
    c.r[3] += 28;  // 0608AC10 add #28,r3
    c.r[4] = ld32(c.r[14] + 12);  // 0608AC12 mov.l @(12,r14),r4
    c.r[7] = c.r[1];  // 0608AC14 mov r1,r7
    c.r[6] = c.r[2];  // 0608AC16 mov r2,r6
    c.r[5] = c.r[3];  // 0608AC18 mov r3,r5
    c.r[8] = ld32(0x0608ACD8u);  // 0608AC1A mov.l 0x0608ACD8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608AC20u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608AC20u) return; }  // 0608AC1C jsr @r8 ; nop
    c.r[2] = ld32(c.r[14] + 12);  // 0608AC20 mov.l @(12,r14),r2
    c.r[1] = ld32(c.r[2]);  // 0608AC22 mov.l @r2,r1
    c.r[2] = c.r[1];  // 0608AC24 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608ACC6u);  // 0608AC26 mov.w 0x0608ACC6,r3
    c.r[1] += c.r[3];  // 0608AC28 add r3,r1
    c.r[4] = ld32(c.r[14] + 32);  // 0608AC2A mov.l @(32,r14),r4
    c.r[5] = ld32(c.r[1]);  // 0608AC2C mov.l @r1,r5
    c.r[7] = ld32(0x0608ACDCu);  // 0608AC2E mov.l 0x0608ACDC,r7
    { const uint32_t x = c.r[7]; c.pr = 0x0608AC34u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608AC34u) return; }  // 0608AC30 jsr @r7 ; nop
    st32(c.r[14] + 24, c.r[0]);  // 0608AC34 mov.l r0,@(24,r14)
    c.r[1] = ld32(c.r[14] + 24);  // 0608AC36 mov.l @(24,r14),r1
    c.r[2] = ld32(c.r[14] + 8);  // 0608AC38 mov.l @(8,r14),r2
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 0608AC3A cmp/gt r2,r1
    if (!c.t) { goto L_0608AC40; }  // 0608AC3C bf 0x0608AC40
    c.r[1] = ld32(c.r[14] + 8);  // 0608AC3E mov.l @(8,r14),r1
L_0608AC40:
    st32(c.r[14] + 24, c.r[1]);  // 0608AC40 mov.l r1,@(24,r14)
    c.r[1] = ld32(c.r[14] + 24);  // 0608AC42 mov.l @(24,r14),r1
    c.t = (int32_t)c.r[1] > 0;  // 0608AC44 cmp/pl r1
    if (c.t) { goto L_0608AC4E; }  // 0608AC46 bt 0x0608AC4E
    c.r[0] = 0x0u;  // 0608AC48 mov #0,r0
    goto L_0608ACB6;  // 0608AC4A bra 0x0608ACB6 ; nop
L_0608AC4E:
    c.r[1] = ld32(c.r[14] + 12);  // 0608AC4E mov.l @(12,r14),r1
    c.r[4] = c.r[1];  // 0608AC50 mov r1,r4
    c.r[8] = ld32(0x0608ACE0u);  // 0608AC52 mov.l 0x0608ACE0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608AC58u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608AC58u) return; }  // 0608AC54 jsr @r8 ; nop
    c.r[1] = c.r[14];  // 0608AC58 mov r14,r1
    c.r[1] += 20;  // 0608AC5A add #20,r1
    c.r[2] = ld32(c.r[14] + 4);  // 0608AC5C mov.l @(4,r14),r2
    c.r[5] = c.r[1];  // 0608AC5E mov r1,r5
    c.r[4] = c.r[2];  // 0608AC60 mov r2,r4
    c.r[8] = ld32(0x0608ACE4u);  // 0608AC62 mov.l 0x0608ACE4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608AC68u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608AC68u) return; }  // 0608AC64 jsr @r8 ; nop
    st32(c.r[14] + 16, c.r[0]);  // 0608AC68 mov.l r0,@(16,r14)
    c.r[2] = ld32(c.r[14] + 12);  // 0608AC6A mov.l @(12,r14),r2
    c.r[1] = ld32(c.r[2]);  // 0608AC6C mov.l @r2,r1
    c.r[2] = c.r[1];  // 0608AC6E mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608ACC6u);  // 0608AC70 mov.w 0x0608ACC6,r3
    c.r[1] += c.r[3];  // 0608AC72 add r3,r1
    c.r[2] = ld32(c.r[1]);  // 0608AC74 mov.l @r1,r2
    c.r[1] = c.r[2];  // 0608AC76 mov r2,r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0608AC78 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0608AC7A shar r1
    c.r[2] = c.r[1];  // 0608AC7C mov r1,r2
    c.r[1] = ld32(c.r[14] + 24);  // 0608AC7E mov.l @(24,r14),r1
    c.macl = c.r[2] * c.r[1];  // 0608AC80 mul.l r1,r2
    c.r[1] = c.macl;  // 0608AC82 sts macl,r1
    c.r[2] = ld32(c.r[14] + 16);  // 0608AC84 mov.l @(16,r14),r2
    c.r[3] = ld32(c.r[14] + 28);  // 0608AC86 mov.l @(28,r14),r3
    c.r[6] = c.r[1];  // 0608AC88 mov r1,r6
    c.r[5] = c.r[2];  // 0608AC8A mov r2,r5
    c.r[4] = c.r[3];  // 0608AC8C mov r3,r4
    c.r[8] = ld32(0x0608ACE8u);  // 0608AC8E mov.l 0x0608ACE8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608AC94u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608AC94u) return; }  // 0608AC90 jsr @r8 ; nop
    c.r[2] = ld32(c.r[14] + 12);  // 0608AC94 mov.l @(12,r14),r2
    c.r[1] = ld32(c.r[2]);  // 0608AC96 mov.l @r2,r1
    c.r[2] = c.r[1];  // 0608AC98 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608ACC8u);  // 0608AC9A mov.w 0x0608ACC8,r3
    c.r[1] += c.r[3];  // 0608AC9C add r3,r1
    c.r[2] = ld32(c.r[14] + 24);  // 0608AC9E mov.l @(24,r14),r2
    st32(c.r[1], c.r[2]);  // 0608ACA0 mov.l r2,@r1
    c.r[2] = ld32(c.r[14] + 12);  // 0608ACA2 mov.l @(12,r14),r2
    c.r[1] = ld32(c.r[2]);  // 0608ACA4 mov.l @r2,r1
    c.r[2] = c.r[1];  // 0608ACA6 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608ACC4u);  // 0608ACA8 mov.w 0x0608ACC4,r3
    c.r[1] += c.r[3];  // 0608ACAA add r3,r1
    c.r[2] = 0x1u;  // 0608ACAC mov #1,r2
    st32(c.r[1], c.r[2]);  // 0608ACAE mov.l r2,@r1
    c.r[0] = 0xFFFFFFFFu;  // 0608ACB0 mov #-1,r0
    goto L_0608ACB6;  // 0608ACB2 bra 0x0608ACB6 ; nop
L_0608ACB6:
    c.r[14] += 40;  // 0608ACB6 add #40,r14
    c.r[15] = c.r[14];  // 0608ACB8 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608ACBA lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608ACBC mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608ACBE mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608ACC0 rts ; nop
}

void f_0608ACEC(SH2Context& c) {
    ran[1983] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608ACEC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608ACEE mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608ACF0 sts.l pr,@-r15
    c.r[15] -= 64;  // 0608ACF2 add #-64,r15
    c.r[14] = c.r[15];  // 0608ACF4 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608ACF6 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 0608ACF8 mov.l r5,@(4,r14)
    st32(c.r[14] + 8, c.r[6]);  // 0608ACFA mov.l r6,@(8,r14)
    c.r[4] = 0x1u;  // 0608ACFC mov #1,r4
    c.r[8] = ld32(0x0608ADC4u);  // 0608ACFE mov.l 0x0608ADC4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608AD04u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608AD04u) return; }  // 0608AD00 jsr @r8 ; nop
    c.r[1] = c.r[14];  // 0608AD04 mov r14,r1
    c.r[2] = c.r[14];  // 0608AD06 mov r14,r2
    c.r[2] += 12;  // 0608AD08 add #12,r2
    c.r[1] = 0x0u;  // 0608AD0A mov #0,r1
    st32(c.r[2], c.r[1]);  // 0608AD0C mov.l r1,@r2
    c.r[1] = c.r[14];  // 0608AD0E mov r14,r1
    c.r[2] = c.r[14];  // 0608AD10 mov r14,r2
    c.r[2] += 12;  // 0608AD12 add #12,r2
    c.r[1] = 0x1u;  // 0608AD14 mov #1,r1
    st32(c.r[2] + 4, c.r[1]);  // 0608AD16 mov.l r1,@(4,r2)
    c.r[1] = c.r[14];  // 0608AD18 mov r14,r1
    c.r[2] = c.r[14];  // 0608AD1A mov r14,r2
    c.r[2] += 12;  // 0608AD1C add #12,r2
    c.r[1] = 0xFu;  // 0608AD1E mov #15,r1
    st32(c.r[2] + 8, c.r[1]);  // 0608AD20 mov.l r1,@(8,r2)
    c.r[1] = c.r[14];  // 0608AD22 mov r14,r1
    c.r[1] += 12;  // 0608AD24 add #12,r1
    c.r[4] = c.r[1];  // 0608AD26 mov r1,r4
    c.r[8] = ld32(0x0608ADC8u);  // 0608AD28 mov.l 0x0608ADC8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608AD2Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608AD2Eu) return; }  // 0608AD2A jsr @r8 ; nop
    c.r[1] = c.r[14];  // 0608AD2E mov r14,r1
    c.r[2] = c.r[14];  // 0608AD30 mov r14,r2
    c.r[2] += 24;  // 0608AD32 add #24,r2
    c.r[1] = ld32(c.r[14] + 4);  // 0608AD34 mov.l @(4,r14),r1
    st32(c.r[2], c.r[1]);  // 0608AD36 mov.l r1,@r2
    c.r[1] = c.r[14];  // 0608AD38 mov r14,r1
    c.r[2] = c.r[14];  // 0608AD3A mov r14,r2
    c.r[2] += 24;  // 0608AD3C add #24,r2
    c.r[1] = ld32(c.r[14]);  // 0608AD3E mov.l @r14,r1
    st32(c.r[2] + 4, c.r[1]);  // 0608AD40 mov.l r1,@(4,r2)
    c.r[1] = c.r[14];  // 0608AD42 mov r14,r1
    c.r[2] = c.r[14];  // 0608AD44 mov r14,r2
    c.r[2] += 24;  // 0608AD46 add #24,r2
    c.r[1] = ld32(c.r[14] + 8);  // 0608AD48 mov.l @(8,r14),r1
    st32(c.r[2] + 8, c.r[1]);  // 0608AD4A mov.l r1,@(8,r2)
    c.r[1] = c.r[14];  // 0608AD4C mov r14,r1
    c.r[2] = c.r[14];  // 0608AD4E mov r14,r2
    c.r[2] += 24;  // 0608AD50 add #24,r2
    c.r[1] = 0x1u;  // 0608AD52 mov #1,r1
    st32(c.r[2] + 12, c.r[1]);  // 0608AD54 mov.l r1,@(12,r2)
    c.r[1] = c.r[14];  // 0608AD56 mov r14,r1
    c.r[2] = c.r[14];  // 0608AD58 mov r14,r2
    c.r[2] += 24;  // 0608AD5A add #24,r2
    c.r[1] = 0x0u;  // 0608AD5C mov #0,r1
    st32(c.r[2] + 16, c.r[1]);  // 0608AD5E mov.l r1,@(16,r2)
    c.r[1] = c.r[14];  // 0608AD60 mov r14,r1
    c.r[2] = c.r[14];  // 0608AD62 mov r14,r2
    c.r[2] += 24;  // 0608AD64 add #24,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0608ADBEu);  // 0608AD66 mov.w 0x0608ADBE,r1
    st32(c.r[2] + 20, c.r[1]);  // 0608AD68 mov.l r1,@(20,r2)
    c.r[1] = c.r[14];  // 0608AD6A mov r14,r1
    c.r[2] = c.r[14];  // 0608AD6C mov r14,r2
    c.r[2] += 24;  // 0608AD6E add #24,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0608ADC0u);  // 0608AD70 mov.w 0x0608ADC0,r1
    st32(c.r[2] + 24, c.r[1]);  // 0608AD72 mov.l r1,@(24,r2)
    c.r[1] = c.r[14];  // 0608AD74 mov r14,r1
    c.r[2] = c.r[14];  // 0608AD76 mov r14,r2
    c.r[2] += 24;  // 0608AD78 add #24,r2
    c.r[1] = 0x0u;  // 0608AD7A mov #0,r1
    st32(c.r[2] + 28, c.r[1]);  // 0608AD7C mov.l r1,@(28,r2)
    c.r[1] = c.r[14];  // 0608AD7E mov r14,r1
    c.r[2] = c.r[14];  // 0608AD80 mov r14,r2
    c.r[2] += 24;  // 0608AD82 add #24,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0608ADC2u);  // 0608AD84 mov.w 0x0608ADC2,r1
    st32(c.r[2] + 36, c.r[1]);  // 0608AD86 mov.l r1,@(36,r2)
    c.r[1] = c.r[14];  // 0608AD88 mov r14,r1
    c.r[1] += 24;  // 0608AD8A add #24,r1
    c.r[5] = 0x1u;  // 0608AD8C mov #1,r5
    c.r[4] = c.r[1];  // 0608AD8E mov r1,r4
    c.r[8] = ld32(0x0608ADCCu);  // 0608AD90 mov.l 0x0608ADCC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608AD96u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608AD96u) return; }  // 0608AD92 jsr @r8 ; nop
    c.r[4] = 0x1u;  // 0608AD96 mov #1,r4
    c.r[8] = ld32(0x0608ADD0u);  // 0608AD98 mov.l 0x0608ADD0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608AD9Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608AD9Eu) return; }  // 0608AD9A jsr @r8 ; nop
    c.r[1] = ld32(0x0608ADD4u);  // 0608AD9E mov.l 0x0608ADD4,r1
    c.r[2] = ld32(c.r[14]);  // 0608ADA0 mov.l @r14,r2
    st32(c.r[1], c.r[2]);  // 0608ADA2 mov.l r2,@r1
    c.r[1] = ld32(0x0608ADD8u);  // 0608ADA4 mov.l 0x0608ADD8,r1
    c.r[2] = ld32(c.r[14] + 8);  // 0608ADA6 mov.l @(8,r14),r2
    c.r[3] = c.r[2];  // 0608ADA8 mov r2,r3
    c.r[2] = c.r[3];  // 0608ADAA mov r3,r2
    c.r[2] <<= 2;  // 0608ADAC shll2 r2
    st32(c.r[1], c.r[2]);  // 0608ADAE mov.l r2,@r1
    c.r[14] += 64;  // 0608ADB0 add #64,r14
    c.r[15] = c.r[14];  // 0608ADB2 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608ADB4 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608ADB6 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608ADB8 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608ADBA rts ; nop
}

void f_0608ADDC(SH2Context& c) {
    ran[1984] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608ADDC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608ADDE mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608ADE0 sts.l pr,@-r15
    c.r[15] -= 12;  // 0608ADE2 add #-12,r15
    c.r[14] = c.r[15];  // 0608ADE4 mov r15,r14
    c.r[4] = c.r[14];  // 0608ADE6 mov r14,r4
    c.r[8] = ld32(0x0608AE38u);  // 0608ADE8 mov.l 0x0608AE38,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608ADEEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608ADEEu) return; }  // 0608ADEA jsr @r8 ; nop
    c.r[0] = ld32(c.r[14]);  // 0608ADEE mov.l @r14,r0
    c.t = c.r[0] == 0x4u;  // 0608ADF0 cmp/eq #4,r0
    if (!c.t) { goto L_0608ADFA; }  // 0608ADF2 bf 0x0608ADFA
    c.r[0] = 0x1u;  // 0608ADF4 mov #1,r0
    goto L_0608AE28;  // 0608ADF6 bra 0x0608AE28 ; nop
L_0608ADFA:
    c.r[4] = 0x1u;  // 0608ADFA mov #1,r4
    c.r[8] = ld32(0x0608AE3Cu);  // 0608ADFC mov.l 0x0608AE3C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608AE02u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608AE02u) return; }  // 0608ADFE jsr @r8 ; nop
    st32(c.r[14] + 8, c.r[0]);  // 0608AE02 mov.l r0,@(8,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 0608AE04 mov.l @(8,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0608AE06 tst r1,r1
    if (!c.t) { goto L_0608AE10; }  // 0608AE08 bf 0x0608AE10
    c.r[0] = 0x2u;  // 0608AE0A mov #2,r0
    goto L_0608AE28;  // 0608AE0C bra 0x0608AE28 ; nop
L_0608AE10:
    c.r[2] = ld32(0x0608AE40u);  // 0608AE10 mov.l 0x0608AE40,r2
    c.r[1] = ld32(c.r[2]);  // 0608AE12 mov.l @r2,r1
    c.r[2] = ld32(0x0608AE44u);  // 0608AE14 mov.l 0x0608AE44,r2
    c.r[3] = ld32(c.r[2]);  // 0608AE16 mov.l @r2,r3
    c.r[5] = c.r[1];  // 0608AE18 mov r1,r5
    c.r[4] = c.r[3];  // 0608AE1A mov r3,r4
    c.r[8] = ld32(0x0608AE48u);  // 0608AE1C mov.l 0x0608AE48,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608AE22u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608AE22u) return; }  // 0608AE1E jsr @r8 ; nop
    c.r[0] = 0x0u;  // 0608AE22 mov #0,r0
    goto L_0608AE28;  // 0608AE24 bra 0x0608AE28 ; nop
L_0608AE28:
    c.r[14] += 12;  // 0608AE28 add #12,r14
    c.r[15] = c.r[14];  // 0608AE2A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608AE2C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608AE2E mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608AE30 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608AE32 rts ; nop
}

void f_0608AE4C(SH2Context& c) {
    ran[1985] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608AE4C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608AE4E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608AE50 sts.l pr,@-r15
    c.r[15] -= 40;  // 0608AE52 add #-40,r15
    c.r[14] = c.r[15];  // 0608AE54 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608AE56 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 0608AE58 mov.l r5,@(4,r14)
    st32(c.r[14] + 8, c.r[6]);  // 0608AE5A mov.l r6,@(8,r14)
    c.r[1] = ld32(c.r[14]);  // 0608AE5C mov.l @r14,r1
    st32(c.r[14] + 12, c.r[1]);  // 0608AE5E mov.l r1,@(12,r14)
    c.r[1] = ld32(c.r[14] + 12);  // 0608AE60 mov.l @(12,r14),r1
    c.r[4] = c.r[1];  // 0608AE62 mov r1,r4
    c.r[8] = ld32(0x0608AF9Cu);  // 0608AE64 mov.l 0x0608AF9C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608AE6Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608AE6Au) return; }  // 0608AE66 jsr @r8 ; nop
    c.t = (c.r[0] & c.r[0]) == 0;  // 0608AE6A tst r0,r0
    if (c.t) { goto L_0608AE74; }  // 0608AE6C bt 0x0608AE74
    c.r[0] = 0x0u;  // 0608AE6E mov #0,r0
    goto L_0608AF86;  // 0608AE70 bra 0x0608AF86 ; nop
L_0608AE74:
    c.r[2] = ld32(c.r[14] + 12);  // 0608AE74 mov.l @(12,r14),r2
    c.r[1] = ld32(c.r[2]);  // 0608AE76 mov.l @r2,r1
    c.r[2] = c.r[1];  // 0608AE78 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608AF94u);  // 0608AE7A mov.w 0x0608AF94,r3
    c.r[1] += c.r[3];  // 0608AE7C add r3,r1
    c.r[0] = ld32(c.r[1]);  // 0608AE7E mov.l @r1,r0
    c.t = c.r[0] == 0x1u;  // 0608AE80 cmp/eq #1,r0
    if (!c.t) { goto L_0608AEDE; }  // 0608AE82 bf 0x0608AEDE
    c.r[8] = ld32(0x0608AFA0u);  // 0608AE84 mov.l 0x0608AFA0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608AE8Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608AE8Au) return; }  // 0608AE86 jsr @r8 ; nop
    c.t = c.r[0] == 0x2u;  // 0608AE8A cmp/eq #2,r0
    if (!c.t) { goto L_0608AE98; }  // 0608AE8C bf 0x0608AE98
    c.r[0] = 0xFFFFFFFFu;  // 0608AE8E mov #-1,r0
    goto L_0608AF86;  // 0608AE90 bra 0x0608AF86 ; nop
L_0608AE98:
    c.r[2] = ld32(c.r[14] + 12);  // 0608AE98 mov.l @(12,r14),r2
    c.r[1] = ld32(c.r[2]);  // 0608AE9A mov.l @r2,r1
    c.r[2] = c.r[1];  // 0608AE9C mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608AF94u);  // 0608AE9E mov.w 0x0608AF94,r3
    c.r[1] += c.r[3];  // 0608AEA0 add r3,r1
    c.r[2] = 0x0u;  // 0608AEA2 mov #0,r2
    st32(c.r[1], c.r[2]);  // 0608AEA4 mov.l r2,@r1
    c.r[2] = ld32(c.r[14] + 12);  // 0608AEA6 mov.l @(12,r14),r2
    c.r[1] = ld32(c.r[2]);  // 0608AEA8 mov.l @r2,r1
    c.r[2] = c.r[1];  // 0608AEAA mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608AF96u);  // 0608AEAC mov.w 0x0608AF96,r3
    c.r[1] += c.r[3];  // 0608AEAE add r3,r1
    c.r[3] = ld32(c.r[14] + 12);  // 0608AEB0 mov.l @(12,r14),r3
    c.r[2] = ld32(c.r[3]);  // 0608AEB2 mov.l @r3,r2
    c.r[3] = c.r[2];  // 0608AEB4 mov r2,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x0608AF98u);  // 0608AEB6 mov.w 0x0608AF98,r7
    c.r[2] += c.r[7];  // 0608AEB8 add r7,r2
    c.r[1] = ld32(c.r[1]);  // 0608AEBA mov.l @r1,r1
    c.r[2] = ld32(c.r[2]);  // 0608AEBC mov.l @r2,r2
    c.macl = c.r[1] * c.r[2];  // 0608AEBE mul.l r2,r1
    c.r[1] = c.macl;  // 0608AEC0 sts macl,r1
    c.r[2] = ld32(c.r[14] + 12);  // 0608AEC2 mov.l @(12,r14),r2
    c.r[5] = c.r[1];  // 0608AEC4 mov r1,r5
    c.r[4] = c.r[2];  // 0608AEC6 mov r2,r4
    c.r[8] = ld32(0x0608AFA4u);  // 0608AEC8 mov.l 0x0608AFA4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608AECEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608AECEu) return; }  // 0608AECA jsr @r8 ; nop
    c.r[2] = ld32(c.r[14] + 12);  // 0608AECE mov.l @(12,r14),r2
    c.r[1] = ld32(c.r[2]);  // 0608AED0 mov.l @r2,r1
    c.r[2] = c.r[1];  // 0608AED2 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608AF98u);  // 0608AED4 mov.w 0x0608AF98,r3
    c.r[1] += c.r[3];  // 0608AED6 add r3,r1
    c.r[0] = ld32(c.r[1]);  // 0608AED8 mov.l @r1,r0
    goto L_0608AF86;  // 0608AEDA bra 0x0608AF86 ; nop
L_0608AEDE:
    c.r[1] = c.r[14];  // 0608AEDE mov r14,r1
    c.r[1] += 36;  // 0608AEE0 add #36,r1
    c.r[2] = c.r[14];  // 0608AEE2 mov r14,r2
    c.r[2] += 32;  // 0608AEE4 add #32,r2
    c.r[3] = c.r[14];  // 0608AEE6 mov r14,r3
    c.r[3] += 28;  // 0608AEE8 add #28,r3
    c.r[4] = ld32(c.r[14] + 12);  // 0608AEEA mov.l @(12,r14),r4
    c.r[7] = c.r[1];  // 0608AEEC mov r1,r7
    c.r[6] = c.r[2];  // 0608AEEE mov r2,r6
    c.r[5] = c.r[3];  // 0608AEF0 mov r3,r5
    c.r[8] = ld32(0x0608AFA8u);  // 0608AEF2 mov.l 0x0608AFA8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608AEF8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608AEF8u) return; }  // 0608AEF4 jsr @r8 ; nop
    c.r[2] = ld32(c.r[14] + 12);  // 0608AEF8 mov.l @(12,r14),r2
    c.r[1] = ld32(c.r[2]);  // 0608AEFA mov.l @r2,r1
    c.r[2] = c.r[1];  // 0608AEFC mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608AF96u);  // 0608AEFE mov.w 0x0608AF96,r3
    c.r[1] += c.r[3];  // 0608AF00 add r3,r1
    c.r[4] = ld32(c.r[14] + 32);  // 0608AF02 mov.l @(32,r14),r4
    c.r[5] = ld32(c.r[1]);  // 0608AF04 mov.l @r1,r5
    c.r[7] = ld32(0x0608AFACu);  // 0608AF06 mov.l 0x0608AFAC,r7
    { const uint32_t x = c.r[7]; c.pr = 0x0608AF0Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608AF0Cu) return; }  // 0608AF08 jsr @r7 ; nop
    st32(c.r[14] + 24, c.r[0]);  // 0608AF0C mov.l r0,@(24,r14)
    c.r[1] = ld32(c.r[14] + 24);  // 0608AF0E mov.l @(24,r14),r1
    c.r[2] = ld32(c.r[14] + 8);  // 0608AF10 mov.l @(8,r14),r2
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 0608AF12 cmp/gt r2,r1
    if (!c.t) { goto L_0608AF18; }  // 0608AF14 bf 0x0608AF18
    c.r[1] = ld32(c.r[14] + 8);  // 0608AF16 mov.l @(8,r14),r1
L_0608AF18:
    st32(c.r[14] + 24, c.r[1]);  // 0608AF18 mov.l r1,@(24,r14)
    c.r[1] = ld32(c.r[14] + 24);  // 0608AF1A mov.l @(24,r14),r1
    c.t = (int32_t)c.r[1] > 0;  // 0608AF1C cmp/pl r1
    if (c.t) { goto L_0608AF26; }  // 0608AF1E bt 0x0608AF26
    c.r[0] = 0x0u;  // 0608AF20 mov #0,r0
    goto L_0608AF86;  // 0608AF22 bra 0x0608AF86 ; nop
L_0608AF26:
    c.r[1] = ld32(c.r[14] + 12);  // 0608AF26 mov.l @(12,r14),r1
    c.r[4] = c.r[1];  // 0608AF28 mov r1,r4
    c.r[8] = ld32(0x0608AFB0u);  // 0608AF2A mov.l 0x0608AFB0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608AF30u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608AF30u) return; }  // 0608AF2C jsr @r8 ; nop
    c.r[1] = c.r[14];  // 0608AF30 mov r14,r1
    c.r[1] += 20;  // 0608AF32 add #20,r1
    c.r[2] = ld32(c.r[14] + 4);  // 0608AF34 mov.l @(4,r14),r2
    c.r[5] = c.r[1];  // 0608AF36 mov r1,r5
    c.r[4] = c.r[2];  // 0608AF38 mov r2,r4
    c.r[8] = ld32(0x0608AFB4u);  // 0608AF3A mov.l 0x0608AFB4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608AF40u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608AF40u) return; }  // 0608AF3C jsr @r8 ; nop
    st32(c.r[14] + 16, c.r[0]);  // 0608AF40 mov.l r0,@(16,r14)
    c.r[2] = ld32(c.r[14] + 12);  // 0608AF42 mov.l @(12,r14),r2
    c.r[1] = ld32(c.r[2]);  // 0608AF44 mov.l @r2,r1
    c.r[2] = c.r[1];  // 0608AF46 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608AF96u);  // 0608AF48 mov.w 0x0608AF96,r3
    c.r[1] += c.r[3];  // 0608AF4A add r3,r1
    c.r[2] = ld32(c.r[1]);  // 0608AF4C mov.l @r1,r2
    c.r[1] = ld32(c.r[14] + 24);  // 0608AF4E mov.l @(24,r14),r1
    c.macl = c.r[2] * c.r[1];  // 0608AF50 mul.l r1,r2
    c.r[1] = c.macl;  // 0608AF52 sts macl,r1
    c.r[2] = ld32(c.r[14] + 16);  // 0608AF54 mov.l @(16,r14),r2
    c.r[3] = ld32(c.r[14] + 28);  // 0608AF56 mov.l @(28,r14),r3
    c.r[6] = c.r[1];  // 0608AF58 mov r1,r6
    c.r[5] = c.r[2];  // 0608AF5A mov r2,r5
    c.r[4] = c.r[3];  // 0608AF5C mov r3,r4
    c.r[8] = ld32(0x0608AFB8u);  // 0608AF5E mov.l 0x0608AFB8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608AF64u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608AF64u) return; }  // 0608AF60 jsr @r8 ; nop
    c.r[2] = ld32(c.r[14] + 12);  // 0608AF64 mov.l @(12,r14),r2
    c.r[1] = ld32(c.r[2]);  // 0608AF66 mov.l @r2,r1
    c.r[2] = c.r[1];  // 0608AF68 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608AF98u);  // 0608AF6A mov.w 0x0608AF98,r3
    c.r[1] += c.r[3];  // 0608AF6C add r3,r1
    c.r[2] = ld32(c.r[14] + 24);  // 0608AF6E mov.l @(24,r14),r2
    st32(c.r[1], c.r[2]);  // 0608AF70 mov.l r2,@r1
    c.r[2] = ld32(c.r[14] + 12);  // 0608AF72 mov.l @(12,r14),r2
    c.r[1] = ld32(c.r[2]);  // 0608AF74 mov.l @r2,r1
    c.r[2] = c.r[1];  // 0608AF76 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608AF94u);  // 0608AF78 mov.w 0x0608AF94,r3
    c.r[1] += c.r[3];  // 0608AF7A add r3,r1
    c.r[2] = 0x1u;  // 0608AF7C mov #1,r2
    st32(c.r[1], c.r[2]);  // 0608AF7E mov.l r2,@r1
    c.r[0] = 0xFFFFFFFFu;  // 0608AF80 mov #-1,r0
    goto L_0608AF86;  // 0608AF82 bra 0x0608AF86 ; nop
L_0608AF86:
    c.r[14] += 40;  // 0608AF86 add #40,r14
    c.r[15] = c.r[14];  // 0608AF88 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608AF8A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608AF8C mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608AF8E mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608AF90 rts ; nop
}

void f_0608AFBC(SH2Context& c) {
    ran[1986] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608AFBC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608AFBE mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608AFC0 sts.l pr,@-r15
    c.r[15] -= 56;  // 0608AFC2 add #-56,r15
    c.r[14] = c.r[15];  // 0608AFC4 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608AFC6 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 0608AFC8 mov.l r5,@(4,r14)
    st32(c.r[14] + 8, c.r[6]);  // 0608AFCA mov.l r6,@(8,r14)
    c.r[8] = ld32(0x0608B080u);  // 0608AFCC mov.l 0x0608B080,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608AFD2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608AFD2u) return; }  // 0608AFCE jsr @r8 ; nop
    st32(c.r[14] + 52, c.r[0]);  // 0608AFD2 mov.l r0,@(52,r14)
    c.r[4] = 0xFu;  // 0608AFD4 mov #15,r4
    c.r[8] = ld32(0x0608B084u);  // 0608AFD6 mov.l 0x0608B084,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608AFDCu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608AFDCu) return; }  // 0608AFD8 jsr @r8 ; nop
    c.r[1] = ld32(0x0608B088u);  // 0608AFDC mov.l 0x0608B088,r1
    c.r[2] = ld32(c.r[14]);  // 0608AFDE mov.l @r14,r2
    st32(c.r[1], c.r[2]);  // 0608AFE0 mov.l r2,@r1
    c.r[1] = ld32(0x0608B08Cu);  // 0608AFE2 mov.l 0x0608B08C,r1
    c.r[2] = ld32(c.r[14] + 8);  // 0608AFE4 mov.l @(8,r14),r2
    st32(c.r[1], c.r[2]);  // 0608AFE6 mov.l r2,@r1
    c.r[1] = c.r[14];  // 0608AFE8 mov r14,r1
    c.r[2] = c.r[14];  // 0608AFEA mov r14,r2
    c.r[2] += 12;  // 0608AFEC add #12,r2
    c.r[1] = ld32(c.r[14] + 4);  // 0608AFEE mov.l @(4,r14),r1
    st32(c.r[2], c.r[1]);  // 0608AFF0 mov.l r1,@r2
    c.r[1] = c.r[14];  // 0608AFF2 mov r14,r1
    c.r[2] = c.r[14];  // 0608AFF4 mov r14,r2
    c.r[2] += 12;  // 0608AFF6 add #12,r2
    c.r[1] = ld32(c.r[14]);  // 0608AFF8 mov.l @r14,r1
    st32(c.r[2] + 4, c.r[1]);  // 0608AFFA mov.l r1,@(4,r2)
    c.r[1] = c.r[14];  // 0608AFFC mov r14,r1
    c.r[2] = c.r[14];  // 0608AFFE mov r14,r2
    c.r[2] += 12;  // 0608B000 add #12,r2
    c.r[1] = ld32(c.r[14] + 8);  // 0608B002 mov.l @(8,r14),r1
    st32(c.r[2] + 8, c.r[1]);  // 0608B004 mov.l r1,@(8,r2)
    c.r[1] = c.r[14];  // 0608B006 mov r14,r1
    c.r[2] = c.r[14];  // 0608B008 mov r14,r2
    c.r[2] += 12;  // 0608B00A add #12,r2
    c.r[1] = 0x0u;  // 0608B00C mov #0,r1
    st32(c.r[2] + 12, c.r[1]);  // 0608B00E mov.l r1,@(12,r2)
    c.r[1] = c.r[14];  // 0608B010 mov r14,r1
    c.r[2] = c.r[14];  // 0608B012 mov r14,r2
    c.r[2] += 12;  // 0608B014 add #12,r2
    c.r[1] = 0x2u;  // 0608B016 mov #2,r1
    st32(c.r[2] + 16, c.r[1]);  // 0608B018 mov.l r1,@(16,r2)
    c.r[1] = c.r[14];  // 0608B01A mov r14,r1
    c.r[2] = c.r[14];  // 0608B01C mov r14,r2
    c.r[2] += 12;  // 0608B01E add #12,r2
    c.r[1] = 0x0u;  // 0608B020 mov #0,r1
    st32(c.r[2] + 20, c.r[1]);  // 0608B022 mov.l r1,@(20,r2)
    c.r[1] = c.r[14];  // 0608B024 mov r14,r1
    c.r[2] = c.r[14];  // 0608B026 mov r14,r2
    c.r[2] += 12;  // 0608B028 add #12,r2
    c.r[1] = 0x0u;  // 0608B02A mov #0,r1
    st32(c.r[2] + 24, c.r[1]);  // 0608B02C mov.l r1,@(24,r2)
    c.r[1] = c.r[14];  // 0608B02E mov r14,r1
    c.r[2] = c.r[14];  // 0608B030 mov r14,r2
    c.r[2] += 12;  // 0608B032 add #12,r2
    c.r[1] = 0x0u;  // 0608B034 mov #0,r1
    st32(c.r[2] + 28, c.r[1]);  // 0608B036 mov.l r1,@(28,r2)
    c.r[1] = c.r[14];  // 0608B038 mov r14,r1
    c.r[2] = c.r[14];  // 0608B03A mov r14,r2
    c.r[2] += 12;  // 0608B03C add #12,r2
    c.r[1] = 0x7u;  // 0608B03E mov #7,r1
    st32(c.r[2] + 32, c.r[1]);  // 0608B040 mov.l r1,@(32,r2)
    c.r[1] = c.r[14];  // 0608B042 mov r14,r1
    c.r[2] = c.r[14];  // 0608B044 mov r14,r2
    c.r[2] += 12;  // 0608B046 add #12,r2
    c.r[1] = 0x3u;  // 0608B048 mov #3,r1
    st32(c.r[2] + 36, c.r[1]);  // 0608B04A mov.l r1,@(36,r2)
    c.r[1] = c.r[14];  // 0608B04C mov r14,r1
    c.r[1] += 12;  // 0608B04E add #12,r1
    c.r[5] = 0x0u;  // 0608B050 mov #0,r5
    c.r[4] = c.r[1];  // 0608B052 mov r1,r4
    c.r[8] = ld32(0x0608B090u);  // 0608B054 mov.l 0x0608B090,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608B05Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608B05Au) return; }  // 0608B056 jsr @r8 ; nop
    c.r[4] = 0x0u;  // 0608B05A mov #0,r4
    c.r[8] = ld32(0x0608B094u);  // 0608B05C mov.l 0x0608B094,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608B062u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608B062u) return; }  // 0608B05E jsr @r8 ; nop
    c.r[1] = ld32(0x0608B098u);  // 0608B062 mov.l 0x0608B098,r1
    c.r[2] = 0x1u;  // 0608B064 mov #1,r2
    st8(c.r[1], c.r[2]);  // 0608B066 mov.b r2,@r1
    c.r[1] = ld32(c.r[14] + 52);  // 0608B068 mov.l @(52,r14),r1
    c.r[4] = c.r[1];  // 0608B06A mov r1,r4
    c.r[8] = ld32(0x0608B084u);  // 0608B06C mov.l 0x0608B084,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608B072u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608B072u) return; }  // 0608B06E jsr @r8 ; nop
    c.r[14] += 56;  // 0608B072 add #56,r14
    c.r[15] = c.r[14];  // 0608B074 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608B076 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608B078 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608B07A mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608B07C rts ; nop
}

void f_0608B09C(SH2Context& c) {
    ran[1987] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608B09C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608B09E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608B0A0 sts.l pr,@-r15
    c.r[15] -= 8;  // 0608B0A2 add #-8,r15
    c.r[14] = c.r[15];  // 0608B0A4 mov r15,r14
    c.r[8] = ld32(0x0608B124u);  // 0608B0A6 mov.l 0x0608B124,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608B0ACu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608B0ACu) return; }  // 0608B0A8 jsr @r8 ; nop
    st32(c.r[14] + 4, c.r[0]);  // 0608B0AC mov.l r0,@(4,r14)
    c.r[4] = 0xFu;  // 0608B0AE mov #15,r4
    c.r[8] = ld32(0x0608B128u);  // 0608B0B0 mov.l 0x0608B128,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608B0B6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608B0B6u) return; }  // 0608B0B2 jsr @r8 ; nop
    c.r[1] = ld32(0x0608B12Cu);  // 0608B0B6 mov.l 0x0608B12C,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0608B0B8 mov.b @r1,r2
    c.r[0] = c.r[2] & 0xFFu;  // 0608B0BA extu.b r2,r0
    c.t = c.r[0] == 0x1u;  // 0608B0BC cmp/eq #1,r0
    if (!c.t) { goto L_0608B106; }  // 0608B0BE bf 0x0608B106
    c.r[5] = 0x0u;  // 0608B0C0 mov #0,r5
    c.r[4] = c.r[14];  // 0608B0C2 mov r14,r4
    c.r[8] = ld32(0x0608B130u);  // 0608B0C4 mov.l 0x0608B130,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608B0CAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608B0CAu) return; }  // 0608B0C6 jsr @r8 ; nop
    c.r[0] = ld32(c.r[14]);  // 0608B0CA mov.l @r14,r0
    c.t = c.r[0] == 0x1u;  // 0608B0CC cmp/eq #1,r0
    if (!c.t) { goto L_0608B0E0; }  // 0608B0CE bf 0x0608B0E0
    c.r[1] = ld32(c.r[14] + 4);  // 0608B0D0 mov.l @(4,r14),r1
    c.r[4] = c.r[1];  // 0608B0D2 mov r1,r4
    c.r[8] = ld32(0x0608B128u);  // 0608B0D4 mov.l 0x0608B128,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608B0DAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608B0DAu) return; }  // 0608B0D6 jsr @r8 ; nop
    c.r[0] = 0x2u;  // 0608B0DA mov #2,r0
    goto L_0608B116;  // 0608B0DC bra 0x0608B116 ; nop
L_0608B0E0:
    c.r[2] = ld32(0x0608B134u);  // 0608B0E0 mov.l 0x0608B134,r2
    c.r[1] = ld32(c.r[2]);  // 0608B0E2 mov.l @r2,r1
    c.r[2] = ld32(0x0608B138u);  // 0608B0E4 mov.l 0x0608B138,r2
    c.r[3] = ld32(c.r[2]);  // 0608B0E6 mov.l @r2,r3
    c.r[5] = c.r[1];  // 0608B0E8 mov r1,r5
    c.r[4] = c.r[3];  // 0608B0EA mov r3,r4
    c.r[8] = ld32(0x0608B13Cu);  // 0608B0EC mov.l 0x0608B13C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608B0F2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608B0F2u) return; }  // 0608B0EE jsr @r8 ; nop
    c.r[1] = ld32(c.r[14] + 4);  // 0608B0F2 mov.l @(4,r14),r1
    c.r[4] = c.r[1];  // 0608B0F4 mov r1,r4
    c.r[8] = ld32(0x0608B128u);  // 0608B0F6 mov.l 0x0608B128,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608B0FCu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608B0FCu) return; }  // 0608B0F8 jsr @r8 ; nop
    c.r[0] = 0x0u;  // 0608B0FC mov #0,r0
    goto L_0608B116;  // 0608B0FE bra 0x0608B116 ; nop
L_0608B106:
    c.r[1] = ld32(c.r[14] + 4);  // 0608B106 mov.l @(4,r14),r1
    c.r[4] = c.r[1];  // 0608B108 mov r1,r4
    c.r[8] = ld32(0x0608B128u);  // 0608B10A mov.l 0x0608B128,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608B110u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608B110u) return; }  // 0608B10C jsr @r8 ; nop
    c.r[0] = 0x0u;  // 0608B110 mov #0,r0
    goto L_0608B116;  // 0608B112 bra 0x0608B116 ; nop
L_0608B116:
    c.r[14] += 8;  // 0608B116 add #8,r14
    c.r[15] = c.r[14];  // 0608B118 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608B11A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608B11C mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608B11E mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608B120 rts ; nop
}

void f_0608B140(SH2Context& c) {
    ran[1988] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608B140 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608B142 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608B144 sts.l pr,@-r15
    c.r[15] -= 52;  // 0608B146 add #-52,r15
    c.r[14] = c.r[15];  // 0608B148 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608B14A mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 0608B14C mov.l r5,@(4,r14)
    st32(c.r[14] + 8, c.r[6]);  // 0608B14E mov.l r6,@(8,r14)
    c.r[1] = ld32(c.r[14]);  // 0608B150 mov.l @r14,r1
    st32(c.r[14] + 12, c.r[1]);  // 0608B152 mov.l r1,@(12,r14)
    c.r[1] = ld32(c.r[14] + 12);  // 0608B154 mov.l @(12,r14),r1
    c.r[4] = c.r[1];  // 0608B156 mov r1,r4
    c.r[8] = ld32(0x0608B24Cu);  // 0608B158 mov.l 0x0608B24C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608B15Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608B15Eu) return; }  // 0608B15A jsr @r8 ; nop
    c.t = (c.r[0] & c.r[0]) == 0;  // 0608B15E tst r0,r0
    if (c.t) { goto L_0608B168; }  // 0608B160 bt 0x0608B168
    c.r[0] = 0x0u;  // 0608B162 mov #0,r0
    goto L_0608B23A;  // 0608B164 bra 0x0608B23A ; nop
L_0608B168:
    c.r[1] = c.r[14];  // 0608B168 mov r14,r1
    c.r[1] += 48;  // 0608B16A add #48,r1
    c.r[2] = c.r[14];  // 0608B16C mov r14,r2
    c.r[2] += 44;  // 0608B16E add #44,r2
    c.r[3] = c.r[14];  // 0608B170 mov r14,r3
    c.r[3] += 40;  // 0608B172 add #40,r3
    c.r[4] = ld32(c.r[14] + 12);  // 0608B174 mov.l @(12,r14),r4
    c.r[7] = c.r[1];  // 0608B176 mov r1,r7
    c.r[6] = c.r[2];  // 0608B178 mov r2,r6
    c.r[5] = c.r[3];  // 0608B17A mov r3,r5
    c.r[8] = ld32(0x0608B250u);  // 0608B17C mov.l 0x0608B250,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608B182u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608B182u) return; }  // 0608B17E jsr @r8 ; nop
    c.r[2] = ld32(c.r[14] + 12);  // 0608B182 mov.l @(12,r14),r2
    c.r[1] = ld32(c.r[2]);  // 0608B184 mov.l @r2,r1
    c.r[2] = c.r[1];  // 0608B186 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608B248u);  // 0608B188 mov.w 0x0608B248,r3
    c.r[1] += c.r[3];  // 0608B18A add r3,r1
    c.r[4] = ld32(c.r[14] + 44);  // 0608B18C mov.l @(44,r14),r4
    c.r[5] = ld32(c.r[1]);  // 0608B18E mov.l @r1,r5
    c.r[7] = ld32(0x0608B254u);  // 0608B190 mov.l 0x0608B254,r7
    { const uint32_t x = c.r[7]; c.pr = 0x0608B196u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608B196u) return; }  // 0608B192 jsr @r7 ; nop
    st32(c.r[14] + 32, c.r[0]);  // 0608B196 mov.l r0,@(32,r14)
    c.r[1] = ld32(c.r[14] + 32);  // 0608B198 mov.l @(32,r14),r1
    c.r[2] = ld32(c.r[14] + 8);  // 0608B19A mov.l @(8,r14),r2
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 0608B19C cmp/gt r2,r1
    if (!c.t) { goto L_0608B1A2; }  // 0608B19E bf 0x0608B1A2
    c.r[1] = ld32(c.r[14] + 8);  // 0608B1A0 mov.l @(8,r14),r1
L_0608B1A2:
    st32(c.r[14] + 32, c.r[1]);  // 0608B1A2 mov.l r1,@(32,r14)
    c.r[1] = ld32(c.r[14] + 32);  // 0608B1A4 mov.l @(32,r14),r1
    c.t = (int32_t)c.r[1] > 0;  // 0608B1A6 cmp/pl r1
    if (c.t) { goto L_0608B1B0; }  // 0608B1A8 bt 0x0608B1B0
    c.r[0] = 0x0u;  // 0608B1AA mov #0,r0
    goto L_0608B23A;  // 0608B1AC bra 0x0608B23A ; nop
L_0608B1B0:
    c.r[1] = ld32(c.r[14] + 12);  // 0608B1B0 mov.l @(12,r14),r1
    c.r[4] = c.r[1];  // 0608B1B2 mov r1,r4
    c.r[8] = ld32(0x0608B258u);  // 0608B1B4 mov.l 0x0608B258,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608B1BAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608B1BAu) return; }  // 0608B1B6 jsr @r8 ; nop
    c.r[1] = c.r[14];  // 0608B1BA mov r14,r1
    c.r[1] += 24;  // 0608B1BC add #24,r1
    c.r[2] = ld32(c.r[14] + 4);  // 0608B1BE mov.l @(4,r14),r2
    c.r[5] = c.r[1];  // 0608B1C0 mov r1,r5
    c.r[4] = c.r[2];  // 0608B1C2 mov r2,r4
    c.r[8] = ld32(0x0608B25Cu);  // 0608B1C4 mov.l 0x0608B25C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608B1CAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608B1CAu) return; }  // 0608B1C6 jsr @r8 ; nop
    st32(c.r[14] + 16, c.r[0]);  // 0608B1CA mov.l r0,@(16,r14)
    c.r[1] = ld32(c.r[14] + 40);  // 0608B1CC mov.l @(40,r14),r1
    st32(c.r[14] + 20, c.r[1]);  // 0608B1CE mov.l r1,@(20,r14)
    c.r[2] = ld32(c.r[14] + 12);  // 0608B1D0 mov.l @(12,r14),r2
    c.r[1] = ld32(c.r[2]);  // 0608B1D2 mov.l @r2,r1
    c.r[2] = c.r[1];  // 0608B1D4 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608B248u);  // 0608B1D6 mov.w 0x0608B248,r3
    c.r[1] += c.r[3];  // 0608B1D8 add r3,r1
    c.r[2] = ld32(c.r[1]);  // 0608B1DA mov.l @r1,r2
    c.r[1] = c.r[2];  // 0608B1DC mov r2,r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0608B1DE shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0608B1E0 shar r1
    c.r[2] = c.r[1];  // 0608B1E2 mov r1,r2
    c.r[1] = ld32(c.r[14] + 32);  // 0608B1E4 mov.l @(32,r14),r1
    c.macl = c.r[2] * c.r[1];  // 0608B1E6 mul.l r1,r2
    c.r[1] = c.macl;  // 0608B1E8 sts macl,r1
    c.r[2] = c.r[1];  // 0608B1EA mov r1,r2
    st32(c.r[14] + 36, c.r[2]);  // 0608B1EC mov.l r2,@(36,r14)
    st32(c.r[14] + 28, c.r[2]);  // 0608B1EE mov.l r2,@(28,r14)
L_0608B1F0:
    c.r[2] = ld32(c.r[14] + 28);  // 0608B1F0 mov.l @(28,r14),r2
    c.r[1] = c.r[2];  // 0608B1F2 mov r2,r1
    c.r[1] -= 1;  // 0608B1F4 add #-1,r1
    c.r[2] = c.r[1];  // 0608B1F6 mov r1,r2
    st32(c.r[14] + 28, c.r[2]);  // 0608B1F8 mov.l r2,@(28,r14)
    c.t = (int32_t)c.r[2] >= 0;  // 0608B1FA cmp/pz r2
    if (c.t) { goto L_0608B202; }  // 0608B1FC bt 0x0608B202
    goto L_0608B222;  // 0608B1FE bra 0x0608B222 ; nop
L_0608B202:
    c.r[1] = ld32(c.r[14] + 20);  // 0608B202 mov.l @(20,r14),r1
    c.r[2] = c.r[1];  // 0608B204 mov r1,r2
    c.r[2] += 4;  // 0608B206 add #4,r2
    st32(c.r[14] + 20, c.r[2]);  // 0608B208 mov.l r2,@(20,r14)
    c.r[2] = ld32(c.r[14] + 16);  // 0608B20A mov.l @(16,r14),r2
    c.r[3] = ld32(c.r[2]);  // 0608B20C mov.l @r2,r3
    st32(c.r[1], c.r[3]);  // 0608B20E mov.l r3,@r1
    c.r[1] = ld32(c.r[14] + 24);  // 0608B210 mov.l @(24,r14),r1
    c.r[2] = c.r[1];  // 0608B212 mov r1,r2
    c.r[1] = c.r[2];  // 0608B214 mov r2,r1
    c.r[1] <<= 2;  // 0608B216 shll2 r1
    c.r[2] = ld32(c.r[14] + 16);  // 0608B218 mov.l @(16,r14),r2
    c.r[1] += c.r[2];  // 0608B21A add r2,r1
    st32(c.r[14] + 16, c.r[1]);  // 0608B21C mov.l r1,@(16,r14)
    SH2_POLL(c); goto L_0608B1F0;  // 0608B21E bra 0x0608B1F0 ; nop
L_0608B222:
    c.r[2] = ld32(c.r[14] + 36);  // 0608B222 mov.l @(36,r14),r2
    c.r[1] = c.r[2];  // 0608B224 mov r2,r1
    c.r[1] <<= 2;  // 0608B226 shll2 r1
    c.r[2] = ld32(c.r[14] + 12);  // 0608B228 mov.l @(12,r14),r2
    c.r[5] = c.r[1];  // 0608B22A mov r1,r5
    c.r[4] = c.r[2];  // 0608B22C mov r2,r4
    c.r[8] = ld32(0x0608B260u);  // 0608B22E mov.l 0x0608B260,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608B234u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608B234u) return; }  // 0608B230 jsr @r8 ; nop
    c.r[0] = ld32(c.r[14] + 32);  // 0608B234 mov.l @(32,r14),r0
    goto L_0608B23A;  // 0608B236 bra 0x0608B23A ; nop
L_0608B23A:
    c.r[14] += 52;  // 0608B23A add #52,r14
    c.r[15] = c.r[14];  // 0608B23C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608B23E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608B240 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608B242 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608B244 rts ; nop
}

void f_0608B264(SH2Context& c) {
    ran[1989] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608B264 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608B266 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608B268 sts.l pr,@-r15
    c.r[15] -= 32;  // 0608B26A add #-32,r15
    c.r[14] = c.r[15];  // 0608B26C mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608B26E mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 0608B270 mov.l r5,@(4,r14)
    c.r[4] = ld32(c.r[14]);  // 0608B272 mov.l @r14,r4
    c.r[8] = ld32(0x0608B3A0u);  // 0608B274 mov.l 0x0608B3A0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608B27Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608B27Au) return; }  // 0608B276 jsr @r8 ; nop
    st32(c.r[14] + 20, c.r[0]);  // 0608B27A mov.l r0,@(20,r14)
    c.r[1] = 0x0u;  // 0608B27C mov #0,r1
    st32(c.r[14] + 28, c.r[1]);  // 0608B27E mov.l r1,@(28,r14)
    c.r[1] = c.r[14];  // 0608B280 mov r14,r1
    c.r[1] += 16;  // 0608B282 add #16,r1
    c.r[2] = c.r[14];  // 0608B284 mov r14,r2
    c.r[2] += 12;  // 0608B286 add #12,r2
    c.r[3] = c.r[14];  // 0608B288 mov r14,r3
    c.r[3] += 8;  // 0608B28A add #8,r3
    c.r[7] = c.r[1];  // 0608B28C mov r1,r7
    c.r[6] = c.r[2];  // 0608B28E mov r2,r6
    c.r[5] = c.r[3];  // 0608B290 mov r3,r5
    c.r[4] = ld32(c.r[14]);  // 0608B292 mov.l @r14,r4
    c.r[8] = ld32(0x0608B3A4u);  // 0608B294 mov.l 0x0608B3A4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608B29Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608B29Au) return; }  // 0608B296 jsr @r8 ; nop
    c.r[2] = ld32(c.r[14]);  // 0608B29A mov.l @r14,r2
    c.r[1] = ld32(c.r[2]);  // 0608B29C mov.l @r2,r1
    c.r[2] = c.r[1];  // 0608B29E mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608B394u);  // 0608B2A0 mov.w 0x0608B394,r3
    c.r[1] += c.r[3];  // 0608B2A2 add r3,r1
    c.r[2] = ld32(c.r[14] + 12);  // 0608B2A4 mov.l @(12,r14),r2
    c.r[1] = ld32(c.r[1]);  // 0608B2A6 mov.l @r1,r1
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[1];  // 0608B2A8 cmp/ge r1,r2
    if (c.t) { goto L_0608B2B0; }  // 0608B2AA bt 0x0608B2B0
    goto L_0608B380;  // 0608B2AC bra 0x0608B380 ; nop
L_0608B2B0:
    c.r[1] = ld32(c.r[14] + 4);  // 0608B2B0 mov.l @(4,r14),r1
    c.r[2] = ld32(c.r[14] + 12);  // 0608B2B2 mov.l @(12,r14),r2
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 0608B2B4 cmp/gt r2,r1
    if (!c.t) { goto L_0608B2C0; }  // 0608B2B6 bf 0x0608B2C0
    c.r[1] = ld32(c.r[14] + 12);  // 0608B2B8 mov.l @(12,r14),r1
    st32(c.r[14] + 28, c.r[1]);  // 0608B2BA mov.l r1,@(28,r14)
    goto L_0608B2C4;  // 0608B2BC bra 0x0608B2C4 ; nop
L_0608B2C0:
    c.r[1] = ld32(c.r[14] + 4);  // 0608B2C0 mov.l @(4,r14),r1
    st32(c.r[14] + 28, c.r[1]);  // 0608B2C2 mov.l r1,@(28,r14)
L_0608B2C4:
    c.r[2] = ld32(c.r[14]);  // 0608B2C4 mov.l @r14,r2
    c.r[1] = ld32(c.r[2]);  // 0608B2C6 mov.l @r2,r1
    c.r[2] = c.r[1];  // 0608B2C8 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608B394u);  // 0608B2CA mov.w 0x0608B394,r3
    c.r[1] += c.r[3];  // 0608B2CC add r3,r1
    c.r[4] = ld32(c.r[14] + 28);  // 0608B2CE mov.l @(28,r14),r4
    c.r[5] = ld32(c.r[1]);  // 0608B2D0 mov.l @r1,r5
    c.r[7] = ld32(0x0608B3A8u);  // 0608B2D2 mov.l 0x0608B3A8,r7
    { const uint32_t x = c.r[7]; c.pr = 0x0608B2D8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608B2D8u) return; }  // 0608B2D4 jsr @r7 ; nop
    st32(c.r[14] + 24, c.r[0]);  // 0608B2D8 mov.l r0,@(24,r14)
    c.r[2] = ld32(c.r[14]);  // 0608B2DA mov.l @r14,r2
    c.r[1] = ld32(c.r[2]);  // 0608B2DC mov.l @r2,r1
    c.r[2] = c.r[1];  // 0608B2DE mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608B394u);  // 0608B2E0 mov.w 0x0608B394,r3
    c.r[1] += c.r[3];  // 0608B2E2 add r3,r1
    c.r[2] = ld32(c.r[14] + 24);  // 0608B2E4 mov.l @(24,r14),r2
    c.r[1] = ld32(c.r[1]);  // 0608B2E6 mov.l @r1,r1
    c.macl = c.r[2] * c.r[1];  // 0608B2E8 mul.l r1,r2
    c.r[1] = c.macl;  // 0608B2EA sts macl,r1
    st32(c.r[14] + 28, c.r[1]);  // 0608B2EC mov.l r1,@(28,r14)
    c.r[1] = ld32(c.r[14] + 24);  // 0608B2EE mov.l @(24,r14),r1
    c.t = (int32_t)c.r[1] > 0;  // 0608B2F0 cmp/pl r1
    if (c.t) { goto L_0608B2F8; }  // 0608B2F2 bt 0x0608B2F8
    goto L_0608B380;  // 0608B2F4 bra 0x0608B380 ; nop
L_0608B2F8:
    c.r[2] = ld32(c.r[14]);  // 0608B2F8 mov.l @r14,r2
    c.r[1] = ld32(c.r[2]);  // 0608B2FA mov.l @r2,r1
    c.r[2] = c.r[1];  // 0608B2FC mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608B396u);  // 0608B2FE mov.w 0x0608B396,r3
    c.r[1] += c.r[3];  // 0608B300 add r3,r1
    c.r[2] = ld32(c.r[14] + 8);  // 0608B302 mov.l @(8,r14),r2
    st32(c.r[1], c.r[2]);  // 0608B304 mov.l r2,@r1
    c.r[2] = ld32(c.r[14]);  // 0608B306 mov.l @r14,r2
    c.r[1] = ld32(c.r[2]);  // 0608B308 mov.l @r2,r1
    c.r[2] = c.r[1];  // 0608B30A mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608B398u);  // 0608B30C mov.w 0x0608B398,r3
    c.r[1] += c.r[3];  // 0608B30E add r3,r1
    c.r[2] = ld32(c.r[14] + 28);  // 0608B310 mov.l @(28,r14),r2
    st32(c.r[1], c.r[2]);  // 0608B312 mov.l r2,@r1
    c.r[2] = ld32(c.r[14]);  // 0608B314 mov.l @r14,r2
    c.r[1] = ld32(c.r[2]);  // 0608B316 mov.l @r2,r1
    c.r[2] = c.r[1];  // 0608B318 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608B39Au);  // 0608B31A mov.w 0x0608B39A,r3
    c.r[1] += c.r[3];  // 0608B31C add r3,r1
    c.r[2] = 0x0u;  // 0608B31E mov #0,r2
    st32(c.r[1], c.r[2]);  // 0608B320 mov.l r2,@r1
    c.r[1] = ld32(0x0608B3ACu);  // 0608B322 mov.l 0x0608B3AC,r1
    c.r[2] = ld32(c.r[14]);  // 0608B324 mov.l @r14,r2
    st32(c.r[1], c.r[2]);  // 0608B326 mov.l r2,@r1
L_0608B328:
    c.r[8] = ld32(0x0608B3B0u);  // 0608B328 mov.l 0x0608B3B0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608B32Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608B32Eu) return; }  // 0608B32A jsr @r8 ; nop
    c.r[1] = (uint32_t)(int16_t)ld16(0x0608B39Cu);  // 0608B32E mov.w 0x0608B39C,r1
    c.t = c.r[0] == c.r[1];  // 0608B330 cmp/eq r1,r0
    if (!c.t) { goto L_0608B338; }  // 0608B332 bf 0x0608B338
    goto L_0608B36C;  // 0608B334 bra 0x0608B36C ; nop
L_0608B338:
    c.r[2] = ld32(c.r[14]);  // 0608B338 mov.l @r14,r2
    c.r[1] = ld32(c.r[2]);  // 0608B33A mov.l @r2,r1
    c.r[2] = c.r[1];  // 0608B33C mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608B39Au);  // 0608B33E mov.w 0x0608B39A,r3
    c.r[1] += c.r[3];  // 0608B340 add r3,r1
    c.r[3] = ld32(c.r[14]);  // 0608B342 mov.l @r14,r3
    c.r[2] = ld32(c.r[3]);  // 0608B344 mov.l @r3,r2
    c.r[3] = c.r[2];  // 0608B346 mov r2,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x0608B398u);  // 0608B348 mov.w 0x0608B398,r7
    c.r[2] += c.r[7];  // 0608B34A add r7,r2
    c.r[1] = ld32(c.r[1]);  // 0608B34C mov.l @r1,r1
    c.r[2] = ld32(c.r[2]);  // 0608B34E mov.l @r2,r2
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[2];  // 0608B350 cmp/ge r2,r1
    if (!c.t) { goto L_0608B368; }  // 0608B352 bf 0x0608B368
    c.r[2] = ld32(c.r[14]);  // 0608B354 mov.l @r14,r2
    c.r[1] = ld32(c.r[2]);  // 0608B356 mov.l @r2,r1
    c.r[2] = c.r[1];  // 0608B358 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608B39Eu);  // 0608B35A mov.w 0x0608B39E,r3
    c.r[1] += c.r[3];  // 0608B35C add r3,r1
    c.r[2] = ld32(c.r[1]);  // 0608B35E mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0608B360 tst r2,r2
    if (!c.t) { goto L_0608B368; }  // 0608B362 bf 0x0608B368
    goto L_0608B36C;  // 0608B364 bra 0x0608B36C ; nop
L_0608B368:
    SH2_POLL(c); goto L_0608B328;  // 0608B368 bra 0x0608B328 ; nop
L_0608B36C:
    c.r[1] = ld32(0x0608B3ACu);  // 0608B36C mov.l 0x0608B3AC,r1
    c.r[2] = 0x0u;  // 0608B36E mov #0,r2
    st32(c.r[1], c.r[2]);  // 0608B370 mov.l r2,@r1
    c.r[2] = ld32(c.r[14]);  // 0608B372 mov.l @r14,r2
    c.r[1] = ld32(c.r[2]);  // 0608B374 mov.l @r2,r1
    c.r[2] = c.r[1];  // 0608B376 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608B39Au);  // 0608B378 mov.w 0x0608B39A,r3
    c.r[1] += c.r[3];  // 0608B37A add r3,r1
    c.r[2] = ld32(c.r[1]);  // 0608B37C mov.l @r1,r2
    st32(c.r[14] + 28, c.r[2]);  // 0608B37E mov.l r2,@(28,r14)
L_0608B380:
    c.r[0] = ld32(c.r[14] + 28);  // 0608B380 mov.l @(28,r14),r0
    goto L_0608B386;  // 0608B382 bra 0x0608B386 ; nop
L_0608B386:
    c.r[14] += 32;  // 0608B386 add #32,r14
    c.r[15] = c.r[14];  // 0608B388 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608B38A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608B38C mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608B38E mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608B390 rts ; nop
}

void f_0608B3B4(SH2Context& c) {
    ran[1990] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608B3B4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608B3B6 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608B3B8 sts.l pr,@-r15
    c.r[15] -= 8;  // 0608B3BA add #-8,r15
    c.r[14] = c.r[15];  // 0608B3BC mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608B3BE mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 0608B3C0 mov.l r5,@(4,r14)
    c.r[0] = ld32(c.r[14] + 4);  // 0608B3C2 mov.l @(4,r14),r0
    c.t = c.r[0] == 0x1u;  // 0608B3C4 cmp/eq #1,r0
    if (c.t) { goto L_0608B3E8; }  // 0608B3C6 bt 0x0608B3E8
    c.r[1] = 0x1u;  // 0608B3C8 mov #1,r1
    c.t = c.r[0] >= c.r[1];  // 0608B3CA cmp/hs r1,r0
    if (!c.t) { goto L_0608B3D6; }  // 0608B3CC bf 0x0608B3D6
    c.t = c.r[0] == 0x2u;  // 0608B3CE cmp/eq #2,r0
    if (c.t) { goto L_0608B3FA; }  // 0608B3D0 bt 0x0608B3FA
    goto L_0608B3D6;  // 0608B3D2 bra 0x0608B3D6 ; nop
L_0608B3D6:
    c.r[2] = ld32(c.r[14]);  // 0608B3D6 mov.l @r14,r2
    c.r[1] = ld32(c.r[2]);  // 0608B3D8 mov.l @r2,r1
    c.r[2] = c.r[1];  // 0608B3DA mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608B442u);  // 0608B3DC mov.w 0x0608B442,r3
    c.r[1] += c.r[3];  // 0608B3DE add r3,r1
    c.r[2] = ld32(0x0608B448u);  // 0608B3E0 mov.l 0x0608B448,r2
    st32(c.r[1], c.r[2]);  // 0608B3E2 mov.l r2,@r1
    goto L_0608B40C;  // 0608B3E4 bra 0x0608B40C ; nop
L_0608B3E8:
    c.r[2] = ld32(c.r[14]);  // 0608B3E8 mov.l @r14,r2
    c.r[1] = ld32(c.r[2]);  // 0608B3EA mov.l @r2,r1
    c.r[2] = c.r[1];  // 0608B3EC mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608B442u);  // 0608B3EE mov.w 0x0608B442,r3
    c.r[1] += c.r[3];  // 0608B3F0 add r3,r1
    c.r[2] = ld32(0x0608B44Cu);  // 0608B3F2 mov.l 0x0608B44C,r2
    st32(c.r[1], c.r[2]);  // 0608B3F4 mov.l r2,@r1
    goto L_0608B40C;  // 0608B3F6 bra 0x0608B40C ; nop
L_0608B3FA:
    c.r[2] = ld32(c.r[14]);  // 0608B3FA mov.l @r14,r2
    c.r[1] = ld32(c.r[2]);  // 0608B3FC mov.l @r2,r1
    c.r[2] = c.r[1];  // 0608B3FE mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608B442u);  // 0608B400 mov.w 0x0608B442,r3
    c.r[1] += c.r[3];  // 0608B402 add r3,r1
    c.r[2] = ld32(0x0608B450u);  // 0608B404 mov.l 0x0608B450,r2
    st32(c.r[1], c.r[2]);  // 0608B406 mov.l r2,@r1
    goto L_0608B40C;  // 0608B408 bra 0x0608B40C ; nop
L_0608B40C:
    c.r[2] = ld32(c.r[14]);  // 0608B40C mov.l @r14,r2
    c.r[1] = ld32(c.r[2]);  // 0608B40E mov.l @r2,r1
    c.r[2] = c.r[1];  // 0608B410 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608B442u);  // 0608B412 mov.w 0x0608B442,r3
    c.r[2] = c.r[1];  // 0608B414 mov r1,r2
    c.r[2] += c.r[3];  // 0608B416 add r3,r2
    c.r[1] = ld32(c.r[2]);  // 0608B418 mov.l @r2,r1
    c.r[3] = ld32(c.r[14]);  // 0608B41A mov.l @r14,r3
    c.r[2] = ld32(c.r[3]);  // 0608B41C mov.l @r3,r2
    c.r[3] = c.r[2];  // 0608B41E mov r2,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x0608B444u);  // 0608B420 mov.w 0x0608B444,r7
    c.r[3] = c.r[2];  // 0608B422 mov r2,r3
    c.r[3] += c.r[7];  // 0608B424 add r7,r3
    c.r[2] = ld32(c.r[3]);  // 0608B426 mov.l @r3,r2
    c.r[6] = ld32(c.r[14]);  // 0608B428 mov.l @r14,r6
    c.r[5] = c.r[1];  // 0608B42A mov r1,r5
    c.r[4] = c.r[2];  // 0608B42C mov r2,r4
    c.r[8] = ld32(0x0608B454u);  // 0608B42E mov.l 0x0608B454,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608B434u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608B434u) return; }  // 0608B430 jsr @r8 ; nop
    c.r[14] += 8;  // 0608B434 add #8,r14
    c.r[15] = c.r[14];  // 0608B436 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608B438 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608B43A mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608B43C mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608B43E rts ; nop
}

void f_0608B458(SH2Context& c) {
    ran[1991] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608B458 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608B45A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608B45C sts.l pr,@-r15
    c.r[15] -= 4;  // 0608B45E add #-4,r15
    c.r[14] = c.r[15];  // 0608B460 mov r15,r14
    c.r[8] = ld32(0x0608B48Cu);  // 0608B462 mov.l 0x0608B48C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608B468u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608B468u) return; }  // 0608B464 jsr @r8 ; nop
    c.r[1] = (uint32_t)(int16_t)ld16(0x0608B488u);  // 0608B468 mov.w 0x0608B488,r1
    c.r[1] &= c.r[0];  // 0608B46A and r0,r1
    c.r[2] = c.r[1];  // 0608B46C mov r1,r2
    c.r[2] >>= 2;  // 0608B46E shlr2 r2
    c.r[2] >>= 2;  // 0608B470 shlr2 r2
    st32(c.r[14], c.r[2]);  // 0608B472 mov.l r2,@r14
    c.r[0] = ld32(c.r[14]);  // 0608B474 mov.l @r14,r0
    goto L_0608B47A;  // 0608B476 bra 0x0608B47A ; nop
L_0608B47A:
    c.r[14] += 4;  // 0608B47A add #4,r14
    c.r[15] = c.r[14];  // 0608B47C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608B47E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608B480 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608B482 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608B484 rts ; nop
}

void f_0608B490(SH2Context& c) {
    ran[1992] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608B490 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0608B492 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608B494 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608B496 sts.l pr,@-r15
    c.r[15] -= 4;  // 0608B498 add #-4,r15
    c.r[14] = c.r[15];  // 0608B49A mov r15,r14
    c.r[8] = c.r[4];  // 0608B49C mov r4,r8
    c.r[9] = ld32(0x0608B4D4u);  // 0608B49E mov.l 0x0608B4D4,r9
    { const uint32_t x = c.r[9]; c.pr = 0x0608B4A4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608B4A4u) return; }  // 0608B4A0 jsr @r9 ; nop
    st32(c.r[14], c.r[0]);  // 0608B4A4 mov.l r0,@r14
    c.r[1] = ld32(c.r[14]);  // 0608B4A6 mov.l @r14,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0608B4D2u);  // 0608B4A8 mov.w 0x0608B4D2,r2
    c.r[1] &= c.r[2];  // 0608B4AA and r2,r1
    st32(c.r[14], c.r[1]);  // 0608B4AC mov.l r1,@r14
    c.r[1] = c.r[8];  // 0608B4AE mov r8,r1
    c.r[1] <<= 2;  // 0608B4B0 shll2 r1
    c.r[1] <<= 2;  // 0608B4B2 shll2 r1
    c.r[2] = ld32(c.r[14]);  // 0608B4B4 mov.l @r14,r2
    c.r[1] |= c.r[2];  // 0608B4B6 or r2,r1
    st32(c.r[14], c.r[1]);  // 0608B4B8 mov.l r1,@r14
    c.r[4] = ld32(c.r[14]);  // 0608B4BA mov.l @r14,r4
    c.r[9] = ld32(0x0608B4D8u);  // 0608B4BC mov.l 0x0608B4D8,r9
    { const uint32_t x = c.r[9]; c.pr = 0x0608B4C2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608B4C2u) return; }  // 0608B4BE jsr @r9 ; nop
    c.r[14] += 4;  // 0608B4C2 add #4,r14
    c.r[15] = c.r[14];  // 0608B4C4 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608B4C6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608B4C8 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0608B4CA mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608B4CC mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608B4CE rts ; nop
}

void f_0608B4DC(SH2Context& c) {
    ran[1993] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608B4DC mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0608B4DE mov r15,r14
    c.r[1] = c.r[4];  // 0608B4E0 mov r4,r1
    sh2_set_sr(c, c.r[1] & 0x3F3u); SH2_POLL(c);  // 0608B4E2 ldc r1,sr
    c.r[15] = c.r[14];  // 0608B4E4 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608B4E6 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608B4E8 rts ; nop
}

void f_0608B4EC(SH2Context& c) {
    ran[1994] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608B4EC mov.l r14,@-r15
    c.r[15] -= 4;  // 0608B4EE add #-4,r15
    c.r[14] = c.r[15];  // 0608B4F0 mov r15,r14
    c.r[1] = sh2_get_sr(c);  // 0608B4F2 stc sr,r1
    st32(c.r[14], c.r[1]);  // 0608B4F4 mov.l r1,@r14
    c.r[0] = ld32(c.r[14]);  // 0608B4F6 mov.l @r14,r0
    goto L_0608B4FC;  // 0608B4F8 bra 0x0608B4FC ; nop
L_0608B4FC:
    c.r[14] += 4;  // 0608B4FC add #4,r14
    c.r[15] = c.r[14];  // 0608B4FE mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608B500 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608B502 rts ; nop
}

void f_0608B508(SH2Context& c) {
    ran[1995] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608B508 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0608B50A mov r15,r14
    c.r[1] = ld32(0x0608B528u);  // 0608B50C mov.l 0x0608B528,r1
    c.r[2] = 0x0u;  // 0608B50E mov #0,r2
    st32(c.r[1], c.r[2]);  // 0608B510 mov.l r2,@r1
    c.r[1] = ld32(0x0608B52Cu);  // 0608B512 mov.l 0x0608B52C,r1
    c.r[2] = 0x0u;  // 0608B514 mov #0,r2
    st32(c.r[1], c.r[2]);  // 0608B516 mov.l r2,@r1
    c.r[1] = ld32(0x0608B530u);  // 0608B518 mov.l 0x0608B530,r1
    c.r[2] = 0x0u;  // 0608B51A mov #0,r2
    st32(c.r[1], c.r[2]);  // 0608B51C mov.l r2,@r1
    c.r[15] = c.r[14];  // 0608B51E mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608B520 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608B522 rts ; nop
}

void f_0608B534(SH2Context& c) {
    ran[1996] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608B534 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608B536 sts.l pr,@-r15
    c.r[15] -= 4;  // 0608B538 add #-4,r15
    c.r[14] = c.r[15];  // 0608B53A mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608B53C mov.l r4,@r14
    c.r[1] = ld32(0x0608B568u);  // 0608B53E mov.l 0x0608B568,r1
    c.r[2] = ld32(c.r[14]);  // 0608B540 mov.l @r14,r2
    st32(c.r[1], c.r[2]);  // 0608B542 mov.l r2,@r1
    c.r[1] = ld32(0x0608B56Cu);  // 0608B544 mov.l 0x0608B56C,r1
    c.r[2] = ld32(c.r[1]);  // 0608B546 mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0608B548 tst r2,r2
    if (c.t) { goto L_0608B55C; }  // 0608B54A bt 0x0608B55C
    c.r[1] = ld32(0x0608B56Cu);  // 0608B54C mov.l 0x0608B56C,r1
    c.r[3] = ld32(0x0608B570u);  // 0608B54E mov.l 0x0608B570,r3
    c.r[2] = ld32(c.r[3]);  // 0608B550 mov.l @r3,r2
    c.r[1] = ld32(c.r[1]);  // 0608B552 mov.l @r1,r1
    c.r[5] = ld32(c.r[14]);  // 0608B554 mov.l @r14,r5
    c.r[4] = c.r[2];  // 0608B556 mov r2,r4
    { const uint32_t x = c.r[1]; c.pr = 0x0608B55Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608B55Cu) return; }  // 0608B558 jsr @r1 ; nop
L_0608B55C:
    c.r[14] += 4;  // 0608B55C add #4,r14
    c.r[15] = c.r[14];  // 0608B55E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608B560 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608B562 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608B564 rts ; nop
}

void f_0608B574(SH2Context& c) {
    ran[1997] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608B574 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0608B576 mov r15,r14
    c.r[1] = ld32(0x0608B588u);  // 0608B578 mov.l 0x0608B588,r1
    c.r[0] = ld32(c.r[1]);  // 0608B57A mov.l @r1,r0
    goto L_0608B580;  // 0608B57C bra 0x0608B580 ; nop
L_0608B580:
    c.r[15] = c.r[14];  // 0608B580 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608B582 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608B584 rts ; nop
}

void f_0608B58C(SH2Context& c) {
    ran[1998] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608B58C mov.l r14,@-r15
    c.r[15] -= 8;  // 0608B58E add #-8,r15
    c.r[14] = c.r[15];  // 0608B590 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608B592 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 0608B594 mov.l r5,@(4,r14)
    c.r[1] = ld32(0x0608B5ACu);  // 0608B596 mov.l 0x0608B5AC,r1
    c.r[2] = ld32(c.r[14]);  // 0608B598 mov.l @r14,r2
    st32(c.r[1], c.r[2]);  // 0608B59A mov.l r2,@r1
    c.r[1] = ld32(0x0608B5B0u);  // 0608B59C mov.l 0x0608B5B0,r1
    c.r[2] = ld32(c.r[14] + 4);  // 0608B59E mov.l @(4,r14),r2
    st32(c.r[1], c.r[2]);  // 0608B5A0 mov.l r2,@r1
    c.r[14] += 8;  // 0608B5A2 add #8,r14
    c.r[15] = c.r[14];  // 0608B5A4 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608B5A6 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608B5A8 rts ; nop
}

void f_0608B5B4(SH2Context& c) {
    ran[1999] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608B5B4 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0608B5B6 mov r15,r14
    goto L_0608B5BC;  // 0608B5B8 bra 0x0608B5BC ; nop
L_0608B5BC:
    c.r[15] = c.r[14];  // 0608B5BC mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608B5BE mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608B5C0 rts ; nop
}

void f_0608B5C4(SH2Context& c) {
    ran[2000] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608B5C4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608B5C6 sts.l pr,@-r15
    c.r[15] -= 16;  // 0608B5C8 add #-16,r15
    c.r[14] = c.r[15];  // 0608B5CA mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608B5CC mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 0608B5CE mov.l r5,@(4,r14)
    c.r[1] = ld32(c.r[14]);  // 0608B5D0 mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 0608B5D2 mov.l @r1,r2
    st32(c.r[14] + 8, c.r[2]);  // 0608B5D4 mov.l r2,@(8,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 0608B5D6 mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 0608B5D8 mov r1,r2
    c.r[2] += 56;  // 0608B5DA add #56,r2
    st32(c.r[14] + 12, c.r[2]);  // 0608B5DC mov.l r2,@(12,r14)
    c.r[1] = ld32(c.r[14] + 12);  // 0608B5DE mov.l @(12,r14),r1
    c.r[2] = c.r[1];  // 0608B5E0 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608B64Cu);  // 0608B5E2 mov.w 0x0608B64C,r3
    c.r[1] += c.r[3];  // 0608B5E4 add r3,r1
    c.r[2] = ld32(c.r[14] + 4);  // 0608B5E6 mov.l @(4,r14),r2
    st32(c.r[1], c.r[2]);  // 0608B5E8 mov.l r2,@r1
    c.r[1] = ld32(c.r[14] + 12);  // 0608B5EA mov.l @(12,r14),r1
    c.r[2] = c.r[1];  // 0608B5EC mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608B64Eu);  // 0608B5EE mov.w 0x0608B64E,r3
    c.r[1] += c.r[3];  // 0608B5F0 add r3,r1
    c.r[2] = ld32(c.r[14] + 12);  // 0608B5F2 mov.l @(12,r14),r2
    c.r[3] = c.r[2];  // 0608B5F4 mov r2,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x0608B64Cu);  // 0608B5F6 mov.w 0x0608B64C,r7
    c.r[3] = c.r[2];  // 0608B5F8 mov r2,r3
    c.r[3] += c.r[7];  // 0608B5FA add r7,r3
    c.r[2] = ld32(c.r[3]);  // 0608B5FC mov.l @r3,r2
    c.r[3] = ld32(c.r[14] + 12);  // 0608B5FE mov.l @(12,r14),r3
    c.r[7] = ld32(c.r[3] + 40);  // 0608B600 mov.l @(40,r3),r7
    c.r[3] = 0x8u;  // 0608B602 mov #8,r3
    c.t = (int32_t)c.r[7] > (int32_t)c.r[3];  // 0608B604 cmp/gt r3,r7
    if (!c.t) { goto L_0608B60A; }  // 0608B606 bf 0x0608B60A
    c.r[2] += c.r[2];  // 0608B608 add r2,r2
L_0608B60A:
    st32(c.r[1], c.r[2]);  // 0608B60A mov.l r2,@r1
    c.r[1] = ld32(c.r[14] + 12);  // 0608B60C mov.l @(12,r14),r1
    c.r[2] = c.r[1];  // 0608B60E mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608B650u);  // 0608B610 mov.w 0x0608B650,r3
    c.r[1] += c.r[3];  // 0608B612 add r3,r1
    c.r[2] = ld32(c.r[14] + 12);  // 0608B614 mov.l @(12,r14),r2
    c.r[3] = c.r[2];  // 0608B616 mov r2,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x0608B64Cu);  // 0608B618 mov.w 0x0608B64C,r7
    c.r[2] += c.r[7];  // 0608B61A add r7,r2
    c.r[3] = ld32(c.r[2]);  // 0608B61C mov.l @r2,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x0608B652u);  // 0608B61E mov.w 0x0608B652,r7
    c.r[2] = c.r[3];  // 0608B620 mov r3,r2
    c.r[2] += c.r[7];  // 0608B622 add r7,r2
    c.r[3] = ld32(0x0608B654u);  // 0608B624 mov.l 0x0608B654,r3
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[2] * (int32_t)c.r[3]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 0608B626 dmuls.l r3,r2
    c.r[3] = c.mach;  // 0608B628 sts mach,r3
    c.r[7] = c.r[3];  // 0608B62A mov r3,r7
    c.r[7] += c.r[2];  // 0608B62C add r2,r7
    c.r[4] = c.r[7];  // 0608B62E mov r7,r4
    c.r[3] = ld32(0x0608B658u);  // 0608B630 mov.l 0x0608B658,r3
    { const uint32_t x = c.r[3]; c.pr = 0x0608B636u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608B636u) return; }  // 0608B632 jsr @r3 ; nop
    c.r[3] = c.r[4];  // 0608B636 mov r4,r3
    c.t = c.r[2] >> 31; c.r[2] <<= 1;  // 0608B638 shll r2
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 0608B63A subc r2,r2
    c.r[3] -= c.r[2];  // 0608B63C sub r2,r3
    st32(c.r[1], c.r[3]);  // 0608B63E mov.l r3,@r1
    c.r[14] += 16;  // 0608B640 add #16,r14
    c.r[15] = c.r[14];  // 0608B642 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608B644 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608B646 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608B648 rts ; nop
}

void f_0608B65C(SH2Context& c) {
    ran[2001] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608B65C mov.l r14,@-r15
    c.r[15] -= 8;  // 0608B65E add #-8,r15
    c.r[14] = c.r[15];  // 0608B660 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608B662 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 0608B664 mov.l r5,@(4,r14)
    c.r[1] = ld32(c.r[14]);  // 0608B666 mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 0608B668 mov.l @r1,r2
    c.r[1] = ld32(c.r[14] + 4);  // 0608B66A mov.l @(4,r14),r1
    st32(c.r[2] + 44, c.r[1]);  // 0608B66C mov.l r1,@(44,r2)
    c.r[14] += 8;  // 0608B66E add #8,r14
    c.r[15] = c.r[14];  // 0608B670 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608B672 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608B674 rts ; nop
}

void f_0608B678(SH2Context& c) {
    ran[2002] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608B678 mov.l r14,@-r15
    c.r[15] -= 8;  // 0608B67A add #-8,r15
    c.r[14] = c.r[15];  // 0608B67C mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608B67E mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 0608B680 mov.l r5,@(4,r14)
    c.r[1] = ld32(c.r[14]);  // 0608B682 mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 0608B684 mov.l @r1,r2
    c.r[1] = ld32(c.r[14] + 4);  // 0608B686 mov.l @(4,r14),r1
    st32(c.r[2] + 48, c.r[1]);  // 0608B688 mov.l r1,@(48,r2)
    c.r[14] += 8;  // 0608B68A add #8,r14
    c.r[15] = c.r[14];  // 0608B68C mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608B68E mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608B690 rts ; nop
}

void f_0608B694(SH2Context& c) {
    ran[2003] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608B694 mov.l r14,@-r15
    c.r[15] -= 8;  // 0608B696 add #-8,r15
    c.r[14] = c.r[15];  // 0608B698 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608B69A mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 0608B69C mov.l r5,@(4,r14)
    c.r[1] = ld32(c.r[14]);  // 0608B69E mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 0608B6A0 mov.l @r1,r2
    c.r[1] = ld32(c.r[14] + 4);  // 0608B6A2 mov.l @(4,r14),r1
    st32(c.r[2] + 52, c.r[1]);  // 0608B6A4 mov.l r1,@(52,r2)
    c.r[14] += 8;  // 0608B6A6 add #8,r14
    c.r[15] = c.r[14];  // 0608B6A8 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608B6AA mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608B6AC rts ; nop
}

void f_0608B6B0(SH2Context& c) {
    ran[2004] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608B6B0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608B6B2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608B6B4 sts.l pr,@-r15
    c.r[15] -= 8;  // 0608B6B6 add #-8,r15
    c.r[14] = c.r[15];  // 0608B6B8 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608B6BA mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 0608B6BC mov.l r5,@(4,r14)
    c.r[1] = ld32(0x0608B720u);  // 0608B6BE mov.l 0x0608B720,r1
    c.r[3] = ld32(c.r[14]);  // 0608B6C0 mov.l @r14,r3
    c.r[2] = c.r[3];  // 0608B6C2 mov r3,r2
    c.r[2] += 3;  // 0608B6C4 add #3,r2
    c.r[3] = 0xFFFFFFFCu;  // 0608B6C6 mov #-4,r3
    c.r[2] &= c.r[3];  // 0608B6C8 and r3,r2
    st32(c.r[1], c.r[2]);  // 0608B6CA mov.l r2,@r1
    c.r[1] = ld32(0x0608B720u);  // 0608B6CC mov.l 0x0608B720,r1
    c.r[2] = ld32(c.r[1]);  // 0608B6CE mov.l @r1,r2
    c.r[1] = ld32(c.r[14]);  // 0608B6D0 mov.l @r14,r1
    c.t = c.r[2] == c.r[1];  // 0608B6D2 cmp/eq r1,r2
    if (!c.t) { goto L_0608B6E4; }  // 0608B6D4 bf 0x0608B6E4
    c.r[1] = ld32(0x0608B724u);  // 0608B6D6 mov.l 0x0608B724,r1
    c.r[2] = ld32(c.r[14] + 4);  // 0608B6D8 mov.l @(4,r14),r2
    c.r[3] = 0xFFFFFFFCu;  // 0608B6DA mov #-4,r3
    c.r[2] &= c.r[3];  // 0608B6DC and r3,r2
    st32(c.r[1], c.r[2]);  // 0608B6DE mov.l r2,@r1
    goto L_0608B6F2;  // 0608B6E0 bra 0x0608B6F2 ; nop
L_0608B6E4:
    c.r[1] = ld32(0x0608B724u);  // 0608B6E4 mov.l 0x0608B724,r1
    c.r[3] = ld32(c.r[14] + 4);  // 0608B6E6 mov.l @(4,r14),r3
    c.r[2] = c.r[3];  // 0608B6E8 mov r3,r2
    c.r[2] -= 4;  // 0608B6EA add #-4,r2
    c.r[3] = 0xFFFFFFFCu;  // 0608B6EC mov #-4,r3
    c.r[2] &= c.r[3];  // 0608B6EE and r3,r2
    st32(c.r[1], c.r[2]);  // 0608B6F0 mov.l r2,@r1
L_0608B6F2:
    c.r[1] = ld32(0x0608B720u);  // 0608B6F2 mov.l 0x0608B720,r1
    c.r[2] = ld32(c.r[1]);  // 0608B6F4 mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0608B6F6 tst r2,r2
    if (c.t) { goto L_0608B706; }  // 0608B6F8 bt 0x0608B706
    c.r[1] = ld32(0x0608B724u);  // 0608B6FA mov.l 0x0608B724,r1
    c.r[2] = ld32(c.r[1]);  // 0608B6FC mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0608B6FE tst r2,r2
    if (!c.t) { goto L_0608B710; }  // 0608B700 bf 0x0608B710
    goto L_0608B706;  // 0608B702 bra 0x0608B706 ; nop
L_0608B706:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0608B71Eu);  // 0608B706 mov.w 0x0608B71E,r1
    c.r[4] = c.r[1];  // 0608B708 mov r1,r4
    c.r[8] = ld32(0x0608B728u);  // 0608B70A mov.l 0x0608B728,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608B710u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608B710u) return; }  // 0608B70C jsr @r8 ; nop
L_0608B710:
    c.r[14] += 8;  // 0608B710 add #8,r14
    c.r[15] = c.r[14];  // 0608B712 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608B714 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608B716 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608B718 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608B71A rts ; nop
}

void f_0608B748(SH2Context& c) {
    ran[2005] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608B748 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608B74A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608B74C sts.l pr,@-r15
    c.r[15] -= 4;  // 0608B74E add #-4,r15
    c.r[14] = c.r[15];  // 0608B750 mov r15,r14
    c.r[1] = ld32(0x0608B804u);  // 0608B752 mov.l 0x0608B804,r1
    c.r[2] = 0x0u;  // 0608B754 mov #0,r2
    st32(c.r[1], c.r[2]);  // 0608B756 mov.l r2,@r1
    c.r[1] = ld32(0x0608B808u);  // 0608B758 mov.l 0x0608B808,r1
    c.r[2] = 0x0u;  // 0608B75A mov #0,r2
    st32(c.r[1], c.r[2]);  // 0608B75C mov.l r2,@r1
    c.r[1] = ld32(0x0608B80Cu);  // 0608B75E mov.l 0x0608B80C,r1
    c.r[2] = 0x0u;  // 0608B760 mov #0,r2
    st32(c.r[1], c.r[2]);  // 0608B762 mov.l r2,@r1
    c.r[1] = ld32(0x0608B810u);  // 0608B764 mov.l 0x0608B810,r1
    c.r[2] = 0x0u;  // 0608B766 mov #0,r2
    st32(c.r[1], c.r[2]);  // 0608B768 mov.l r2,@r1
    c.r[1] = ld32(0x0608B814u);  // 0608B76A mov.l 0x0608B814,r1
    c.r[2] = 0x0u;  // 0608B76C mov #0,r2
    st32(c.r[1], c.r[2]);  // 0608B76E mov.l r2,@r1
    c.r[1] = ld32(0x0608B818u);  // 0608B770 mov.l 0x0608B818,r1
    c.r[2] = 0x0u;  // 0608B772 mov #0,r2
    st32(c.r[1], c.r[2]);  // 0608B774 mov.l r2,@r1
    c.r[8] = ld32(0x0608B81Cu);  // 0608B776 mov.l 0x0608B81C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608B77Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608B77Cu) return; }  // 0608B778 jsr @r8 ; nop
    c.r[8] = ld32(0x0608B820u);  // 0608B77C mov.l 0x0608B820,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608B782u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608B782u) return; }  // 0608B77E jsr @r8 ; nop
    c.r[8] = ld32(0x0608B824u);  // 0608B782 mov.l 0x0608B824,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608B788u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608B788u) return; }  // 0608B784 jsr @r8 ; nop
    c.r[1] = ld32(0x0608B828u);  // 0608B788 mov.l 0x0608B828,r1
    c.r[2] = ld32(0x0608B82Cu);  // 0608B78A mov.l 0x0608B82C,r2
    c.r[6] = 0x20u;  // 0608B78C mov #32,r6
    c.r[5] = c.r[1];  // 0608B78E mov r1,r5
    c.r[4] = c.r[2];  // 0608B790 mov r2,r4
    c.r[8] = ld32(0x0608B830u);  // 0608B792 mov.l 0x0608B830,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608B798u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608B798u) return; }  // 0608B794 jsr @r8 ; nop
    c.r[1] = 0x0u;  // 0608B798 mov #0,r1
    st32(c.r[14], c.r[1]);  // 0608B79A mov.l r1,@r14
L_0608B79C:
    c.r[1] = ld32(c.r[14]);  // 0608B79C mov.l @r14,r1
    c.r[2] = 0x1Fu;  // 0608B79E mov #31,r2
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 0608B7A0 cmp/gt r2,r1
    if (!c.t) { goto L_0608B7A8; }  // 0608B7A2 bf 0x0608B7A8
    goto L_0608B7E0;  // 0608B7A4 bra 0x0608B7E0 ; nop
L_0608B7A8:
    c.r[1] = ld32(c.r[14]);  // 0608B7A8 mov.l @r14,r1
    c.r[2] = c.r[1];  // 0608B7AA mov r1,r2
    c.r[1] = c.r[2];  // 0608B7AC mov r2,r1
    c.r[1] <<= 2;  // 0608B7AE shll2 r1
    c.r[2] = ld32(0x0608B834u);  // 0608B7B0 mov.l 0x0608B834,r2
    c.r[1] += c.r[2];  // 0608B7B2 add r2,r1
    c.r[3] = ld32(c.r[14]);  // 0608B7B4 mov.l @r14,r3
    c.r[2] = c.r[3];  // 0608B7B6 mov r3,r2
    c.r[2] <<= 16;  // 0608B7B8 shll16 r2
    c.r[2] <<= 8;  // 0608B7BA shll8 r2
    c.r[7] = ld32(c.r[14]);  // 0608B7BC mov.l @r14,r7
    c.r[3] = c.r[7];  // 0608B7BE mov r7,r3
    c.r[3] <<= 16;  // 0608B7C0 shll16 r3
    c.r[2] |= c.r[3];  // 0608B7C2 or r3,r2
    c.r[7] = ld32(c.r[14]);  // 0608B7C4 mov.l @r14,r7
    c.r[3] = c.r[7];  // 0608B7C6 mov r7,r3
    c.r[3] <<= 8;  // 0608B7C8 shll8 r3
    c.r[2] |= c.r[3];  // 0608B7CA or r3,r2
    c.r[3] = ld32(c.r[14]);  // 0608B7CC mov.l @r14,r3
    c.r[2] |= c.r[3];  // 0608B7CE or r3,r2
    st32(c.r[1], c.r[2]);  // 0608B7D0 mov.l r2,@r1
    c.r[2] = ld32(c.r[14]);  // 0608B7D2 mov.l @r14,r2
    c.r[1] = c.r[2];  // 0608B7D4 mov r2,r1
    c.r[1] += 1;  // 0608B7D6 add #1,r1
    c.r[2] = c.r[1];  // 0608B7D8 mov r1,r2
    st32(c.r[14], c.r[2]);  // 0608B7DA mov.l r2,@r14
    SH2_POLL(c); goto L_0608B79C;  // 0608B7DC bra 0x0608B79C ; nop
L_0608B7E0:
    c.r[1] = ld32(0x0608B838u);  // 0608B7E0 mov.l 0x0608B838,r1
    c.r[2] = ld32(0x0608B83Cu);  // 0608B7E2 mov.l 0x0608B83C,r2
    st32(c.r[1], c.r[2]);  // 0608B7E4 mov.l r2,@r1
    c.r[1] = ld32(0x0608B840u);  // 0608B7E6 mov.l 0x0608B840,r1
    c.r[2] = ld32(0x0608B844u);  // 0608B7E8 mov.l 0x0608B844,r2
    st32(c.r[1], c.r[2]);  // 0608B7EA mov.l r2,@r1
    c.r[1] = ld32(0x0608B848u);  // 0608B7EC mov.l 0x0608B848,r1
    c.r[2] = ld32(0x0608B84Cu);  // 0608B7EE mov.l 0x0608B84C,r2
    st32(c.r[1], c.r[2]);  // 0608B7F0 mov.l r2,@r1
    goto L_0608B7F6;  // 0608B7F2 bra 0x0608B7F6 ; nop
L_0608B7F6:
    c.r[14] += 4;  // 0608B7F6 add #4,r14
    c.r[15] = c.r[14];  // 0608B7F8 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608B7FA lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608B7FC mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608B7FE mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608B800 rts ; nop
}

void f_0608B850(SH2Context& c) {
    ran[2006] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608B850 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608B852 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608B854 sts.l pr,@-r15
    c.r[15] -= 8;  // 0608B856 add #-8,r15
    c.r[14] = c.r[15];  // 0608B858 mov r15,r14
    ;  // 0608B85A nop
    c.r[1] = 0x0u;  // 0608B85C mov #0,r1
    st32(c.r[14] + 4, c.r[1]);  // 0608B85E mov.l r1,@(4,r14)
L_0608B860:
    c.r[1] = ld32(c.r[14] + 4);  // 0608B860 mov.l @(4,r14),r1
    c.r[2] = 0x1Fu;  // 0608B862 mov #31,r2
    c.t = c.r[1] > c.r[2];  // 0608B864 cmp/hi r2,r1
    if (!c.t) { goto L_0608B86C; }  // 0608B866 bf 0x0608B86C
    goto L_0608B8A8;  // 0608B868 bra 0x0608B8A8 ; nop
L_0608B86C:
    c.r[1] = ld32(0x0608B8C8u);  // 0608B86C mov.l 0x0608B8C8,r1
    c.r[2] = ld32(c.r[14] + 4);  // 0608B86E mov.l @(4,r14),r2
    c.r[3] = c.r[2];  // 0608B870 mov r2,r3
    c.r[2] = c.r[3];  // 0608B872 mov r3,r2
    c.r[2] <<= 2;  // 0608B874 shll2 r2
    c.r[3] = ld32(0x0608B8CCu);  // 0608B876 mov.l 0x0608B8CC,r3
    c.r[2] += c.r[3];  // 0608B878 add r3,r2
    c.r[1] = ld32(c.r[1]);  // 0608B87A mov.l @r1,r1
    c.r[2] = ld32(c.r[2]);  // 0608B87C mov.l @r2,r2
    c.r[1] &= c.r[2];  // 0608B87E and r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0608B880 tst r1,r1
    if (c.t) { goto L_0608B89A; }  // 0608B882 bt 0x0608B89A
    c.r[1] = ld32(c.r[14] + 4);  // 0608B884 mov.l @(4,r14),r1
    c.r[2] = c.r[1];  // 0608B886 mov r1,r2
    c.r[1] = c.r[2];  // 0608B888 mov r2,r1
    c.r[1] <<= 2;  // 0608B88A shll2 r1
    c.r[2] = ld32(0x0608B8D0u);  // 0608B88C mov.l 0x0608B8D0,r2
    c.r[1] += c.r[2];  // 0608B88E add r2,r1
    st32(c.r[14], c.r[1]);  // 0608B890 mov.l r1,@r14
    c.r[4] = ld32(c.r[14]);  // 0608B892 mov.l @r14,r4
    c.r[8] = ld32(0x0608B8D4u);  // 0608B894 mov.l 0x0608B8D4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608B89Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608B89Au) return; }  // 0608B896 jsr @r8 ; nop
L_0608B89A:
    c.r[2] = ld32(c.r[14] + 4);  // 0608B89A mov.l @(4,r14),r2
    c.r[1] = c.r[2];  // 0608B89C mov r2,r1
    c.r[1] += 1;  // 0608B89E add #1,r1
    c.r[2] = c.r[1];  // 0608B8A0 mov r1,r2
    st32(c.r[14] + 4, c.r[2]);  // 0608B8A2 mov.l r2,@(4,r14)
    SH2_POLL(c); goto L_0608B860;  // 0608B8A4 bra 0x0608B860 ; nop
L_0608B8A8:
    c.r[1] = ld32(0x0608B8C8u);  // 0608B8A8 mov.l 0x0608B8C8,r1
    c.r[2] = 0x0u;  // 0608B8AA mov #0,r2
    st32(c.r[1], c.r[2]);  // 0608B8AC mov.l r2,@r1
    c.r[1] = ld32(0x0608B8D8u);  // 0608B8AE mov.l 0x0608B8D8,r1
    c.r[2] = 0xFFFFFFFFu;  // 0608B8B0 mov #-1,r2
    st32(c.r[1], c.r[2]);  // 0608B8B2 mov.l r2,@r1
    goto L_0608B8B8;  // 0608B8B4 bra 0x0608B8B8 ; nop
L_0608B8B8:
    c.r[14] += 8;  // 0608B8B8 add #8,r14
    c.r[15] = c.r[14];  // 0608B8BA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608B8BC lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608B8BE mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608B8C0 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608B8C2 rts ; nop
}

void f_0608B8DC(SH2Context& c) {
    ran[2007] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608B8DC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608B8DE mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608B8E0 sts.l pr,@-r15
    c.r[15] -= 4;  // 0608B8E2 add #-4,r15
    c.r[14] = c.r[15];  // 0608B8E4 mov r15,r14
    c.r[8] = ld32(0x0608B934u);  // 0608B8E6 mov.l 0x0608B934,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608B8ECu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608B8ECu) return; }  // 0608B8E8 jsr @r8 ; nop
    st32(c.r[14], c.r[0]);  // 0608B8EC mov.l r0,@r14
    c.r[4] = 0xFu;  // 0608B8EE mov #15,r4
    c.r[8] = ld32(0x0608B938u);  // 0608B8F0 mov.l 0x0608B938,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608B8F6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608B8F6u) return; }  // 0608B8F2 jsr @r8 ; nop
    c.r[1] = ld32(0x0608B93Cu);  // 0608B8F6 mov.l 0x0608B93C,r1
    c.r[2] = ld32(c.r[1]);  // 0608B8F8 mov.l @r1,r2
    c.r[1] = ld32(0x0608B940u);  // 0608B8FA mov.l 0x0608B940,r1
    c.t = c.r[2] == c.r[1];  // 0608B8FC cmp/eq r1,r2
    if (!c.t) { goto L_0608B91C; }  // 0608B8FE bf 0x0608B91C
    c.r[2] = ld32(0x0608B944u);  // 0608B900 mov.l 0x0608B944,r2
    c.r[1] = ld32(0x0608B944u);  // 0608B902 mov.l 0x0608B944,r1
    c.r[2] = ld32(0x0608B944u);  // 0608B904 mov.l 0x0608B944,r2
    c.r[3] = ld32(c.r[2]);  // 0608B906 mov.l @r2,r3
    c.r[2] = c.r[3];  // 0608B908 mov r3,r2
    c.r[2] += 1;  // 0608B90A add #1,r2
    c.r[3] = c.r[2];  // 0608B90C mov r2,r3
    st32(c.r[1], c.r[3]);  // 0608B90E mov.l r3,@r1
    c.r[8] = ld32(0x0608B948u);  // 0608B910 mov.l 0x0608B948,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608B916u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608B916u) return; }  // 0608B912 jsr @r8 ; nop
    c.r[8] = ld32(0x0608B94Cu);  // 0608B916 mov.l 0x0608B94C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608B91Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608B91Cu) return; }  // 0608B918 jsr @r8 ; nop
L_0608B91C:
    c.r[4] = ld32(c.r[14]);  // 0608B91C mov.l @r14,r4
    c.r[8] = ld32(0x0608B938u);  // 0608B91E mov.l 0x0608B938,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608B924u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608B924u) return; }  // 0608B920 jsr @r8 ; nop
    c.r[14] += 4;  // 0608B924 add #4,r14
    c.r[15] = c.r[14];  // 0608B926 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608B928 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608B92A mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608B92C mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608B92E rts ; nop
}

void f_0608B950(SH2Context& c) {
    ran[2008] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608B950 mov.l r14,@-r15
    c.r[15] -= 16;  // 0608B952 add #-16,r15
    c.r[14] = c.r[15];  // 0608B954 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608B956 mov.l r4,@r14
    c.r[1] = ld32(c.r[14]);  // 0608B958 mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 0608B95A mov.l @r1,r2
    st32(c.r[14] + 4, c.r[2]);  // 0608B95C mov.l r2,@(4,r14)
    c.r[1] = ld32(c.r[14] + 4);  // 0608B95E mov.l @(4,r14),r1
    c.r[2] = c.r[1];  // 0608B960 mov r1,r2
    c.r[2] += 4;  // 0608B962 add #4,r2
    st32(c.r[14] + 8, c.r[2]);  // 0608B964 mov.l r2,@(8,r14)
    c.r[1] = ld32(c.r[14] + 4);  // 0608B966 mov.l @(4,r14),r1
    c.r[2] = c.r[1];  // 0608B968 mov r1,r2
    c.r[2] += 56;  // 0608B96A add #56,r2
    st32(c.r[14] + 12, c.r[2]);  // 0608B96C mov.l r2,@(12,r14)
    c.r[1] = ld32(c.r[14] + 12);  // 0608B96E mov.l @(12,r14),r1
    c.r[2] = 0x0u;  // 0608B970 mov #0,r2
    st32(c.r[1] + 4, c.r[2]);  // 0608B972 mov.l r2,@(4,r1)
    c.r[1] = ld32(c.r[14] + 12);  // 0608B974 mov.l @(12,r14),r1
    c.r[2] = 0x0u;  // 0608B976 mov #0,r2
    st32(c.r[1] + 60, c.r[2]);  // 0608B978 mov.l r2,@(60,r1)
    c.r[2] = ld32(c.r[14] + 12);  // 0608B97A mov.l @(12,r14),r2
    c.r[1] = c.r[2];  // 0608B97C mov r2,r1
    c.r[2] += 64;  // 0608B97E add #64,r2
    c.r[1] = 0x0u;  // 0608B980 mov #0,r1
    st32(c.r[2], c.r[1]);  // 0608B982 mov.l r1,@r2
    c.r[1] = ld32(c.r[14] + 12);  // 0608B984 mov.l @(12,r14),r1
    c.r[2] = c.r[1];  // 0608B986 mov r1,r2
    c.r[1] += 72;  // 0608B988 add #72,r1
    c.r[2] = ld32(c.r[14] + 8);  // 0608B98A mov.l @(8,r14),r2
    c.r[3] = ld32(c.r[2]);  // 0608B98C mov.l @r2,r3
    st32(c.r[1], c.r[3]);  // 0608B98E mov.l r3,@r1
    c.r[1] = ld32(c.r[14] + 12);  // 0608B990 mov.l @(12,r14),r1
    c.r[2] = c.r[1];  // 0608B992 mov r1,r2
    c.r[1] += 76;  // 0608B994 add #76,r1
    c.r[2] = ld32(c.r[14] + 8);  // 0608B996 mov.l @(8,r14),r2
    c.r[3] = ld32(c.r[2]);  // 0608B998 mov.l @r2,r3
    st32(c.r[1], c.r[3]);  // 0608B99A mov.l r3,@r1
    c.r[2] = ld32(c.r[14] + 12);  // 0608B99C mov.l @(12,r14),r2
    c.r[1] = c.r[2];  // 0608B99E mov r2,r1
    c.r[2] += 96;  // 0608B9A0 add #96,r2
    c.r[1] = 0x0u;  // 0608B9A2 mov #0,r1
    st32(c.r[2], c.r[1]);  // 0608B9A4 mov.l r1,@r2
    c.r[2] = ld32(c.r[14] + 12);  // 0608B9A6 mov.l @(12,r14),r2
    c.r[1] = c.r[2];  // 0608B9A8 mov r2,r1
    c.r[2] += 100;  // 0608B9AA add #100,r2
    c.r[1] = 0x0u;  // 0608B9AC mov #0,r1
    st32(c.r[2], c.r[1]);  // 0608B9AE mov.l r1,@r2
    c.r[1] = ld32(c.r[14] + 12);  // 0608B9B0 mov.l @(12,r14),r1
    c.r[2] = c.r[1];  // 0608B9B2 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608BA06u);  // 0608B9B4 mov.w 0x0608BA06,r3
    c.r[1] += c.r[3];  // 0608B9B6 add r3,r1
    c.r[2] = 0x0u;  // 0608B9B8 mov #0,r2
    st32(c.r[1], c.r[2]);  // 0608B9BA mov.l r2,@r1
    c.r[1] = ld32(c.r[14] + 12);  // 0608B9BC mov.l @(12,r14),r1
    c.r[2] = c.r[1];  // 0608B9BE mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608BA08u);  // 0608B9C0 mov.w 0x0608BA08,r3
    c.r[1] += c.r[3];  // 0608B9C2 add r3,r1
    c.r[2] = 0x0u;  // 0608B9C4 mov #0,r2
    st32(c.r[1], c.r[2]);  // 0608B9C6 mov.l r2,@r1
    c.r[2] = ld32(c.r[14] + 12);  // 0608B9C8 mov.l @(12,r14),r2
    c.r[1] = c.r[2];  // 0608B9CA mov r2,r1
    c.r[2] += 104;  // 0608B9CC add #104,r2
    c.r[1] = 0x0u;  // 0608B9CE mov #0,r1
    st32(c.r[2], c.r[1]);  // 0608B9D0 mov.l r1,@r2
    c.r[2] = ld32(c.r[14] + 12);  // 0608B9D2 mov.l @(12,r14),r2
    c.r[1] = c.r[2];  // 0608B9D4 mov r2,r1
    c.r[2] += 108;  // 0608B9D6 add #108,r2
    c.r[1] = 0x0u;  // 0608B9D8 mov #0,r1
    st32(c.r[2], c.r[1]);  // 0608B9DA mov.l r1,@r2
    c.r[2] = ld32(c.r[14] + 12);  // 0608B9DC mov.l @(12,r14),r2
    c.r[1] = c.r[2];  // 0608B9DE mov r2,r1
    c.r[2] += 112;  // 0608B9E0 add #112,r2
    c.r[1] = 0x0u;  // 0608B9E2 mov #0,r1
    st32(c.r[2], c.r[1]);  // 0608B9E4 mov.l r1,@r2
    c.r[2] = ld32(c.r[14] + 12);  // 0608B9E6 mov.l @(12,r14),r2
    c.r[1] = c.r[2];  // 0608B9E8 mov r2,r1
    c.r[2] += 116;  // 0608B9EA add #116,r2
    c.r[1] = 0x0u;  // 0608B9EC mov #0,r1
    st32(c.r[2], c.r[1]);  // 0608B9EE mov.l r1,@r2
    c.r[1] = ld32(c.r[14] + 12);  // 0608B9F0 mov.l @(12,r14),r1
    c.r[2] = c.r[1];  // 0608B9F2 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608BA0Au);  // 0608B9F4 mov.w 0x0608BA0A,r3
    c.r[1] += c.r[3];  // 0608B9F6 add r3,r1
    c.r[2] = 0x0u;  // 0608B9F8 mov #0,r2
    st32(c.r[1], c.r[2]);  // 0608B9FA mov.l r2,@r1
    c.r[14] += 16;  // 0608B9FC add #16,r14
    c.r[15] = c.r[14];  // 0608B9FE mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608BA00 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608BA02 rts ; nop
}

void f_0608BA0C(SH2Context& c) {
    ran[2009] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608BA0C mov.l r14,@-r15
    c.r[15] -= 12;  // 0608BA0E add #-12,r15
    c.r[14] = c.r[15];  // 0608BA10 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608BA12 mov.l r4,@r14
    c.r[1] = ld32(c.r[14]);  // 0608BA14 mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 0608BA16 mov.l @r1,r2
    st32(c.r[14] + 4, c.r[2]);  // 0608BA18 mov.l r2,@(4,r14)
    c.r[1] = ld32(c.r[14] + 4);  // 0608BA1A mov.l @(4,r14),r1
    c.r[2] = c.r[1];  // 0608BA1C mov r1,r2
    c.r[2] += 56;  // 0608BA1E add #56,r2
    st32(c.r[14] + 8, c.r[2]);  // 0608BA20 mov.l r2,@(8,r14)
    c.r[1] = ld32(c.r[14] + 4);  // 0608BA22 mov.l @(4,r14),r1
    c.r[2] = ld32(0x0608BA88u);  // 0608BA24 mov.l 0x0608BA88,r2
    st32(c.r[1], c.r[2]);  // 0608BA26 mov.l r2,@r1
    c.r[1] = ld32(c.r[14] + 8);  // 0608BA28 mov.l @(8,r14),r1
    c.r[2] = ld32(0x0608BA8Cu);  // 0608BA2A mov.l 0x0608BA8C,r2
    st32(c.r[1], c.r[2]);  // 0608BA2C mov.l r2,@r1
    c.r[1] = ld32(c.r[14] + 8);  // 0608BA2E mov.l @(8,r14),r1
    c.r[2] = ld32(0x0608BA90u);  // 0608BA30 mov.l 0x0608BA90,r2
    st32(c.r[1] + 20, c.r[2]);  // 0608BA32 mov.l r2,@(20,r1)
    c.r[1] = ld32(c.r[14] + 8);  // 0608BA34 mov.l @(8,r14),r1
    c.r[2] = ld32(0x0608BA94u);  // 0608BA36 mov.l 0x0608BA94,r2
    st32(c.r[1] + 56, c.r[2]);  // 0608BA38 mov.l r2,@(56,r1)
    c.r[2] = ld32(c.r[14] + 8);  // 0608BA3A mov.l @(8,r14),r2
    c.r[1] = c.r[2];  // 0608BA3C mov r2,r1
    c.r[2] += 84;  // 0608BA3E add #84,r2
    c.r[1] = ld32(0x0608BA98u);  // 0608BA40 mov.l 0x0608BA98,r1
    st32(c.r[2], c.r[1]);  // 0608BA42 mov.l r1,@r2
    c.r[1] = ld32(c.r[14] + 8);  // 0608BA44 mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 0608BA46 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608BA7Eu);  // 0608BA48 mov.w 0x0608BA7E,r3
    c.r[1] += c.r[3];  // 0608BA4A add r3,r1
    c.r[2] = ld32(0x0608BA9Cu);  // 0608BA4C mov.l 0x0608BA9C,r2
    st32(c.r[1], c.r[2]);  // 0608BA4E mov.l r2,@r1
    c.r[1] = ld32(c.r[14] + 8);  // 0608BA50 mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 0608BA52 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608BA80u);  // 0608BA54 mov.w 0x0608BA80,r3
    c.r[1] += c.r[3];  // 0608BA56 add r3,r1
    c.r[2] = ld32(0x0608BAA0u);  // 0608BA58 mov.l 0x0608BAA0,r2
    st32(c.r[1], c.r[2]);  // 0608BA5A mov.l r2,@r1
    c.r[1] = ld32(c.r[14] + 8);  // 0608BA5C mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 0608BA5E mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608BA82u);  // 0608BA60 mov.w 0x0608BA82,r3
    c.r[1] += c.r[3];  // 0608BA62 add r3,r1
    c.r[2] = ld32(0x0608BAA4u);  // 0608BA64 mov.l 0x0608BAA4,r2
    st32(c.r[1], c.r[2]);  // 0608BA66 mov.l r2,@r1
    c.r[1] = ld32(c.r[14] + 8);  // 0608BA68 mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 0608BA6A mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608BA84u);  // 0608BA6C mov.w 0x0608BA84,r3
    c.r[1] += c.r[3];  // 0608BA6E add r3,r1
    c.r[2] = ld32(0x0608BAA8u);  // 0608BA70 mov.l 0x0608BAA8,r2
    st32(c.r[1], c.r[2]);  // 0608BA72 mov.l r2,@r1
    c.r[14] += 12;  // 0608BA74 add #12,r14
    c.r[15] = c.r[14];  // 0608BA76 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608BA78 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608BA7A rts ; nop
}

void f_0608BAAC(SH2Context& c) {
    ran[2010] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608BAAC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608BAAE mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608BAB0 sts.l pr,@-r15
    c.r[15] -= 24;  // 0608BAB2 add #-24,r15
    c.r[14] = c.r[15];  // 0608BAB4 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608BAB6 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 0608BAB8 mov.l r5,@(4,r14)
    c.r[1] = ld32(c.r[14]);  // 0608BABA mov.l @r14,r1
    c.r[2] = c.r[1];  // 0608BABC mov r1,r2
    c.r[2] += 56;  // 0608BABE add #56,r2
    st32(c.r[14] + 12, c.r[2]);  // 0608BAC0 mov.l r2,@(12,r14)
    c.r[1] = ld32(0x0608BB98u);  // 0608BAC2 mov.l 0x0608BB98,r1
    c.r[2] = ld32(c.r[1]);  // 0608BAC4 mov.l @r1,r2
    c.r[1] = ld32(0x0608BB9Cu);  // 0608BAC6 mov.l 0x0608BB9C,r1
    c.t = c.r[2] == c.r[1];  // 0608BAC8 cmp/eq r1,r2
    if (c.t) { goto L_0608BADC; }  // 0608BACA bt 0x0608BADC
    c.r[1] = (uint32_t)(int16_t)ld16(0x0608BB8Cu);  // 0608BACC mov.w 0x0608BB8C,r1
    c.r[4] = c.r[1];  // 0608BACE mov r1,r4
    c.r[8] = ld32(0x0608BBA0u);  // 0608BAD0 mov.l 0x0608BBA0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608BAD6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608BAD6u) return; }  // 0608BAD2 jsr @r8 ; nop
    c.r[0] = 0x0u;  // 0608BAD6 mov #0,r0
    goto L_0608BD86;  // 0608BAD8 bra 0x0608BD86 ; nop
L_0608BADC:
    ;  // 0608BADC nop
    c.r[1] = 0x0u;  // 0608BADE mov #0,r1
    st32(c.r[14] + 16, c.r[1]);  // 0608BAE0 mov.l r1,@(16,r14)
L_0608BAE2:
    c.r[1] = ld32(c.r[14] + 16);  // 0608BAE2 mov.l @(16,r14),r1
    c.r[2] = 0x1Fu;  // 0608BAE4 mov #31,r2
    c.t = c.r[1] > c.r[2];  // 0608BAE6 cmp/hi r2,r1
    if (!c.t) { goto L_0608BAEE; }  // 0608BAE8 bf 0x0608BAEE
    goto L_0608BB18;  // 0608BAEA bra 0x0608BB18 ; nop
L_0608BAEE:
    c.r[1] = ld32(0x0608BBA4u);  // 0608BAEE mov.l 0x0608BBA4,r1
    c.r[2] = ld32(c.r[14] + 16);  // 0608BAF0 mov.l @(16,r14),r2
    c.r[3] = c.r[2];  // 0608BAF2 mov r2,r3
    c.r[2] = c.r[3];  // 0608BAF4 mov r3,r2
    c.r[2] <<= 2;  // 0608BAF6 shll2 r2
    c.r[3] = ld32(0x0608BBA8u);  // 0608BAF8 mov.l 0x0608BBA8,r3
    c.r[2] += c.r[3];  // 0608BAFA add r3,r2
    c.r[1] = ld32(c.r[1]);  // 0608BAFC mov.l @r1,r1
    c.r[2] = ld32(c.r[2]);  // 0608BAFE mov.l @r2,r2
    c.r[1] &= c.r[2];  // 0608BB00 and r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0608BB02 tst r1,r1
    if (!c.t) { goto L_0608BB0A; }  // 0608BB04 bf 0x0608BB0A
    goto L_0608BB18;  // 0608BB06 bra 0x0608BB18 ; nop
L_0608BB0A:
    c.r[2] = ld32(c.r[14] + 16);  // 0608BB0A mov.l @(16,r14),r2
    c.r[1] = c.r[2];  // 0608BB0C mov r2,r1
    c.r[1] += 1;  // 0608BB0E add #1,r1
    c.r[2] = c.r[1];  // 0608BB10 mov r1,r2
    st32(c.r[14] + 16, c.r[2]);  // 0608BB12 mov.l r2,@(16,r14)
    SH2_POLL(c); goto L_0608BAE2;  // 0608BB14 bra 0x0608BAE2 ; nop
L_0608BB18:
    c.r[0] = ld32(c.r[14] + 16);  // 0608BB18 mov.l @(16,r14),r0
    c.t = c.r[0] == 0x20u;  // 0608BB1A cmp/eq #32,r0
    if (!c.t) { goto L_0608BB2E; }  // 0608BB1C bf 0x0608BB2E
    c.r[1] = (uint32_t)(int16_t)ld16(0x0608BB8Eu);  // 0608BB1E mov.w 0x0608BB8E,r1
    c.r[4] = c.r[1];  // 0608BB20 mov r1,r4
    c.r[8] = ld32(0x0608BBA0u);  // 0608BB22 mov.l 0x0608BBA0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608BB28u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608BB28u) return; }  // 0608BB24 jsr @r8 ; nop
    c.r[0] = 0x0u;  // 0608BB28 mov #0,r0
    goto L_0608BD86;  // 0608BB2A bra 0x0608BD86 ; nop
L_0608BB2E:
    c.r[1] = ld32(c.r[14] + 4);  // 0608BB2E mov.l @(4,r14),r1
    c.r[2] = ld32(c.r[1] + 12);  // 0608BB30 mov.l @(12,r1),r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608BB90u);  // 0608BB32 mov.w 0x0608BB90,r3
    c.r[1] = c.r[2];  // 0608BB34 mov r2,r1
    c.r[1] &= c.r[3];  // 0608BB36 and r3,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0608BB38 tst r1,r1
    if (c.t) { goto L_0608BB4C; }  // 0608BB3A bt 0x0608BB4C
    c.r[1] = (uint32_t)(int16_t)ld16(0x0608BB92u);  // 0608BB3C mov.w 0x0608BB92,r1
    c.r[4] = c.r[1];  // 0608BB3E mov r1,r4
    c.r[8] = ld32(0x0608BBA0u);  // 0608BB40 mov.l 0x0608BBA0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608BB46u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608BB46u) return; }  // 0608BB42 jsr @r8 ; nop
    c.r[0] = 0x0u;  // 0608BB46 mov #0,r0
    goto L_0608BD86;  // 0608BB48 bra 0x0608BD86 ; nop
L_0608BB4C:
    c.r[1] = ld32(c.r[14] + 4);  // 0608BB4C mov.l @(4,r14),r1
    c.r[2] = ld32(c.r[1] + 12);  // 0608BB4E mov.l @(12,r1),r2
    c.r[4] = c.r[2];  // 0608BB50 mov r2,r4
    c.r[1] = ld32(0x0608BBACu);  // 0608BB52 mov.l 0x0608BBAC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0608BB58u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608BB58u) return; }  // 0608BB54 jsr @r1 ; nop
    c.r[1] = c.r[4];  // 0608BB58 mov r4,r1
    st32(c.r[14] + 20, c.r[1]);  // 0608BB5A mov.l r1,@(20,r14)
    c.r[1] = ld32(c.r[14] + 20);  // 0608BB5C mov.l @(20,r14),r1
    c.r[2] = 0x1u;  // 0608BB5E mov #1,r2
    c.t = c.r[1] > c.r[2];  // 0608BB60 cmp/hi r2,r1
    if (c.t) { goto L_0608BB74; }  // 0608BB62 bt 0x0608BB74
    c.r[1] = (uint32_t)(int16_t)ld16(0x0608BB94u);  // 0608BB64 mov.w 0x0608BB94,r1
    c.r[4] = c.r[1];  // 0608BB66 mov r1,r4
    c.r[8] = ld32(0x0608BBA0u);  // 0608BB68 mov.l 0x0608BBA0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608BB6Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608BB6Eu) return; }  // 0608BB6A jsr @r8 ; nop
    c.r[0] = 0x0u;  // 0608BB6E mov #0,r0
    goto L_0608BD86;  // 0608BB70 bra 0x0608BD86 ; nop
L_0608BB74:
    c.r[1] = ld32(c.r[14] + 20);  // 0608BB74 mov.l @(20,r14),r1
    c.r[2] = 0x10u;  // 0608BB76 mov #16,r2
    c.t = c.r[1] > c.r[2];  // 0608BB78 cmp/hi r2,r1
    if (!c.t) { goto L_0608BBB0; }  // 0608BB7A bf 0x0608BBB0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0608BB92u);  // 0608BB7C mov.w 0x0608BB92,r1
    c.r[4] = c.r[1];  // 0608BB7E mov r1,r4
    c.r[8] = ld32(0x0608BBA0u);  // 0608BB80 mov.l 0x0608BBA0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608BB86u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608BB86u) return; }  // 0608BB82 jsr @r8 ; nop
    c.r[0] = 0x0u;  // 0608BB86 mov #0,r0
    goto L_0608BD86;  // 0608BB88 bra 0x0608BD86 ; nop
L_0608BBB0:
    c.r[1] = ld32(0x0608BDACu);  // 0608BBB0 mov.l 0x0608BDAC,r1
    c.r[2] = ld32(0x0608BDACu);  // 0608BBB2 mov.l 0x0608BDAC,r2
    c.r[3] = ld32(c.r[14] + 16);  // 0608BBB4 mov.l @(16,r14),r3
    c.r[7] = c.r[3];  // 0608BBB6 mov r3,r7
    c.r[3] = c.r[7];  // 0608BBB8 mov r7,r3
    c.r[3] <<= 2;  // 0608BBBA shll2 r3
    c.r[7] = ld32(0x0608BDB0u);  // 0608BBBC mov.l 0x0608BDB0,r7
    c.r[3] += c.r[7];  // 0608BBBE add r7,r3
    c.r[2] = ld32(c.r[2]);  // 0608BBC0 mov.l @r2,r2
    c.r[3] = ld32(c.r[3]);  // 0608BBC2 mov.l @r3,r3
    c.r[2] |= c.r[3];  // 0608BBC4 or r3,r2
    st32(c.r[1], c.r[2]);  // 0608BBC6 mov.l r2,@r1
    c.r[1] = ld32(c.r[14] + 16);  // 0608BBC8 mov.l @(16,r14),r1
    c.r[2] = c.r[1];  // 0608BBCA mov r1,r2
    c.r[1] = c.r[2];  // 0608BBCC mov r2,r1
    c.r[1] <<= 2;  // 0608BBCE shll2 r1
    c.r[2] = ld32(0x0608BDB4u);  // 0608BBD0 mov.l 0x0608BDB4,r2
    c.r[1] += c.r[2];  // 0608BBD2 add r2,r1
    st32(c.r[14] + 8, c.r[1]);  // 0608BBD4 mov.l r1,@(8,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 0608BBD6 mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[14]);  // 0608BBD8 mov.l @r14,r2
    st32(c.r[1], c.r[2]);  // 0608BBDA mov.l r2,@r1
    c.r[1] = (uint32_t)(int16_t)ld16(0x0608BD94u);  // 0608BBDC mov.w 0x0608BD94,r1
    c.r[6] = c.r[1];  // 0608BBDE mov r1,r6
    c.r[5] = 0x0u;  // 0608BBE0 mov #0,r5
    c.r[4] = ld32(c.r[14]);  // 0608BBE2 mov.l @r14,r4
    c.r[8] = ld32(0x0608BDB8u);  // 0608BBE4 mov.l 0x0608BDB8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608BBEAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608BBEAu) return; }  // 0608BBE6 jsr @r8 ; nop
    c.r[2] = ld32(c.r[14]);  // 0608BBEA mov.l @r14,r2
    c.r[1] = c.r[2];  // 0608BBEC mov r2,r1
    c.r[2] += 4;  // 0608BBEE add #4,r2
    c.r[3] = ld32(c.r[14] + 4);  // 0608BBF0 mov.l @(4,r14),r3
    c.r[1] = c.r[3];  // 0608BBF2 mov r3,r1
    c.r[3] = ld32(c.r[1]);  // 0608BBF4 mov.l @r1,r3
    st32(c.r[2], c.r[3]);  // 0608BBF6 mov.l r3,@r2
    c.r[2] += 4;  // 0608BBF8 add #4,r2
    c.r[1] += 4;  // 0608BBFA add #4,r1
    c.r[3] = ld32(c.r[1]);  // 0608BBFC mov.l @r1,r3
    st32(c.r[2], c.r[3]);  // 0608BBFE mov.l r3,@r2
    c.r[2] += 4;  // 0608BC00 add #4,r2
    c.r[1] += 4;  // 0608BC02 add #4,r1
    c.r[3] = ld32(c.r[1]);  // 0608BC04 mov.l @r1,r3
    st32(c.r[2], c.r[3]);  // 0608BC06 mov.l r3,@r2
    c.r[2] += 4;  // 0608BC08 add #4,r2
    c.r[1] += 4;  // 0608BC0A add #4,r1
    c.r[3] = ld32(c.r[1]);  // 0608BC0C mov.l @r1,r3
    st32(c.r[2], c.r[3]);  // 0608BC0E mov.l r3,@r2
    c.r[2] += 4;  // 0608BC10 add #4,r2
    c.r[1] += 4;  // 0608BC12 add #4,r1
    c.r[3] = ld32(c.r[1]);  // 0608BC14 mov.l @r1,r3
    st32(c.r[2], c.r[3]);  // 0608BC16 mov.l r3,@r2
    c.r[2] += 4;  // 0608BC18 add #4,r2
    c.r[1] += 4;  // 0608BC1A add #4,r1
    c.r[3] = ld32(c.r[1]);  // 0608BC1C mov.l @r1,r3
    st32(c.r[2], c.r[3]);  // 0608BC1E mov.l r3,@r2
    c.r[2] += 4;  // 0608BC20 add #4,r2
    c.r[1] += 4;  // 0608BC22 add #4,r1
    c.r[3] = ld32(c.r[1]);  // 0608BC24 mov.l @r1,r3
    st32(c.r[2], c.r[3]);  // 0608BC26 mov.l r3,@r2
    c.r[2] += 4;  // 0608BC28 add #4,r2
    c.r[1] += 4;  // 0608BC2A add #4,r1
    c.r[3] = ld32(c.r[1]);  // 0608BC2C mov.l @r1,r3
    st32(c.r[2], c.r[3]);  // 0608BC2E mov.l r3,@r2
    c.r[2] += 4;  // 0608BC30 add #4,r2
    c.r[1] += 4;  // 0608BC32 add #4,r1
    c.r[3] = ld32(c.r[1]);  // 0608BC34 mov.l @r1,r3
    st32(c.r[2], c.r[3]);  // 0608BC36 mov.l r3,@r2
    c.r[2] += 4;  // 0608BC38 add #4,r2
    c.r[1] += 4;  // 0608BC3A add #4,r1
    c.r[3] = ld32(c.r[1]);  // 0608BC3C mov.l @r1,r3
    st32(c.r[2], c.r[3]);  // 0608BC3E mov.l r3,@r2
    c.r[2] += 4;  // 0608BC40 add #4,r2
    c.r[1] += 4;  // 0608BC42 add #4,r1
    c.r[3] = ld32(c.r[1]);  // 0608BC44 mov.l @r1,r3
    st32(c.r[2], c.r[3]);  // 0608BC46 mov.l r3,@r2
    c.r[2] += 4;  // 0608BC48 add #4,r2
    c.r[1] += 4;  // 0608BC4A add #4,r1
    c.r[3] = ld32(c.r[1]);  // 0608BC4C mov.l @r1,r3
    st32(c.r[2], c.r[3]);  // 0608BC4E mov.l r3,@r2
    c.r[2] += 4;  // 0608BC50 add #4,r2
    c.r[1] += 4;  // 0608BC52 add #4,r1
    c.r[3] = ld32(c.r[1]);  // 0608BC54 mov.l @r1,r3
    st32(c.r[2], c.r[3]);  // 0608BC56 mov.l r3,@r2
    c.r[2] += 4;  // 0608BC58 add #4,r2
    c.r[1] += 4;  // 0608BC5A add #4,r1
    c.r[2] = ld32(c.r[14] + 8);  // 0608BC5C mov.l @(8,r14),r2
    c.r[4] = c.r[2];  // 0608BC5E mov r2,r4
    c.r[8] = ld32(0x0608BDBCu);  // 0608BC60 mov.l 0x0608BDBC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608BC66u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608BC66u) return; }  // 0608BC62 jsr @r8 ; nop
    c.r[1] = ld32(c.r[14] + 12);  // 0608BC66 mov.l @(12,r14),r1
    c.r[2] = 0x0u;  // 0608BC68 mov #0,r2
    st32(c.r[1] + 4, c.r[2]);  // 0608BC6A mov.l r2,@(4,r1)
    c.r[1] = ld32(c.r[14] + 12);  // 0608BC6C mov.l @(12,r14),r1
    c.r[2] = 0x0u;  // 0608BC6E mov #0,r2
    st32(c.r[1] + 8, c.r[2]);  // 0608BC70 mov.l r2,@(8,r1)
    c.r[1] = ld32(c.r[14] + 12);  // 0608BC72 mov.l @(12,r14),r1
    c.r[2] = 0x0u;  // 0608BC74 mov #0,r2
    st32(c.r[1] + 12, c.r[2]);  // 0608BC76 mov.l r2,@(12,r1)
    c.r[1] = ld32(c.r[14] + 12);  // 0608BC78 mov.l @(12,r14),r1
    c.r[2] = 0x1u;  // 0608BC7A mov #1,r2
    st32(c.r[1] + 16, c.r[2]);  // 0608BC7C mov.l r2,@(16,r1)
    c.r[1] = ld32(c.r[14] + 4);  // 0608BC7E mov.l @(4,r14),r1
    c.r[2] = 0x0u;  // 0608BC80 mov #0,r2
    st32(c.r[1] + 36, c.r[2]);  // 0608BC82 mov.l r2,@(36,r1)
    c.r[1] = ld32(c.r[14] + 12);  // 0608BC84 mov.l @(12,r14),r1
    c.r[2] = 0x2u;  // 0608BC86 mov #2,r2
    st32(c.r[1] + 24, c.r[2]);  // 0608BC88 mov.l r2,@(24,r1)
    c.r[1] = ld32(c.r[14] + 12);  // 0608BC8A mov.l @(12,r14),r1
    c.r[2] = 0x1u;  // 0608BC8C mov #1,r2
    st32(c.r[1] + 28, c.r[2]);  // 0608BC8E mov.l r2,@(28,r1)
    c.r[1] = ld32(c.r[14] + 12);  // 0608BC90 mov.l @(12,r14),r1
    c.r[2] = 0x0u;  // 0608BC92 mov #0,r2
    st32(c.r[1] + 60, c.r[2]);  // 0608BC94 mov.l r2,@(60,r1)
    c.r[2] = ld32(c.r[14] + 12);  // 0608BC96 mov.l @(12,r14),r2
    c.r[1] = c.r[2];  // 0608BC98 mov r2,r1
    c.r[2] += 64;  // 0608BC9A add #64,r2
    c.r[1] = 0x0u;  // 0608BC9C mov #0,r1
    st32(c.r[2], c.r[1]);  // 0608BC9E mov.l r1,@r2
    c.r[1] = ld32(c.r[14] + 12);  // 0608BCA0 mov.l @(12,r14),r1
    c.r[2] = c.r[1];  // 0608BCA2 mov r1,r2
    c.r[1] += 72;  // 0608BCA4 add #72,r1
    c.r[2] = ld32(c.r[14] + 4);  // 0608BCA6 mov.l @(4,r14),r2
    c.r[3] = ld32(c.r[2]);  // 0608BCA8 mov.l @r2,r3
    st32(c.r[1], c.r[3]);  // 0608BCAA mov.l r3,@r1
    c.r[1] = ld32(c.r[14] + 12);  // 0608BCAC mov.l @(12,r14),r1
    c.r[2] = c.r[1];  // 0608BCAE mov r1,r2
    c.r[1] += 76;  // 0608BCB0 add #76,r1
    c.r[2] = ld32(c.r[14] + 4);  // 0608BCB2 mov.l @(4,r14),r2
    c.r[3] = ld32(c.r[2]);  // 0608BCB4 mov.l @r2,r3
    st32(c.r[1], c.r[3]);  // 0608BCB6 mov.l r3,@r1
    c.r[1] = ld32(c.r[14] + 12);  // 0608BCB8 mov.l @(12,r14),r1
    c.r[2] = c.r[1];  // 0608BCBA mov r1,r2
    c.r[1] += 68;  // 0608BCBC add #68,r1
    c.r[2] = ld32(c.r[14] + 4);  // 0608BCBE mov.l @(4,r14),r2
    c.r[3] = ld32(c.r[14] + 4);  // 0608BCC0 mov.l @(4,r14),r3
    c.r[2] = ld32(c.r[2]);  // 0608BCC2 mov.l @r2,r2
    c.r[3] = ld32(c.r[3] + 4);  // 0608BCC4 mov.l @(4,r3),r3
    c.r[2] += c.r[3];  // 0608BCC6 add r3,r2
    st32(c.r[1], c.r[2]);  // 0608BCC8 mov.l r2,@r1
    c.r[2] = ld32(c.r[14] + 12);  // 0608BCCA mov.l @(12,r14),r2
    c.r[1] = c.r[2];  // 0608BCCC mov r2,r1
    c.r[2] += 96;  // 0608BCCE add #96,r2
    c.r[1] = 0x0u;  // 0608BCD0 mov #0,r1
    st32(c.r[2], c.r[1]);  // 0608BCD2 mov.l r1,@r2
    c.r[2] = ld32(c.r[14] + 12);  // 0608BCD4 mov.l @(12,r14),r2
    c.r[1] = c.r[2];  // 0608BCD6 mov r2,r1
    c.r[2] += 100;  // 0608BCD8 add #100,r2
    c.r[1] = 0x0u;  // 0608BCDA mov #0,r1
    st32(c.r[2], c.r[1]);  // 0608BCDC mov.l r1,@r2
    c.r[1] = ld32(c.r[14] + 12);  // 0608BCDE mov.l @(12,r14),r1
    c.r[2] = c.r[1];  // 0608BCE0 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608BD96u);  // 0608BCE2 mov.w 0x0608BD96,r3
    c.r[1] += c.r[3];  // 0608BCE4 add r3,r1
    c.r[2] = 0x0u;  // 0608BCE6 mov #0,r2
    st32(c.r[1], c.r[2]);  // 0608BCE8 mov.l r2,@r1
    c.r[1] = ld32(c.r[14] + 12);  // 0608BCEA mov.l @(12,r14),r1
    c.r[2] = c.r[1];  // 0608BCEC mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608BD98u);  // 0608BCEE mov.w 0x0608BD98,r3
    c.r[1] += c.r[3];  // 0608BCF0 add r3,r1
    c.r[2] = 0x0u;  // 0608BCF2 mov #0,r2
    st32(c.r[1], c.r[2]);  // 0608BCF4 mov.l r2,@r1
    c.r[2] = ld32(c.r[14] + 12);  // 0608BCF6 mov.l @(12,r14),r2
    c.r[1] = c.r[2];  // 0608BCF8 mov r2,r1
    c.r[2] += 104;  // 0608BCFA add #104,r2
    c.r[1] = 0x0u;  // 0608BCFC mov #0,r1
    st32(c.r[2], c.r[1]);  // 0608BCFE mov.l r1,@r2
    c.r[2] = ld32(c.r[14] + 12);  // 0608BD00 mov.l @(12,r14),r2
    c.r[1] = c.r[2];  // 0608BD02 mov r2,r1
    c.r[2] += 108;  // 0608BD04 add #108,r2
    c.r[1] = 0x0u;  // 0608BD06 mov #0,r1
    st32(c.r[2], c.r[1]);  // 0608BD08 mov.l r1,@r2
    c.r[2] = ld32(c.r[14] + 12);  // 0608BD0A mov.l @(12,r14),r2
    c.r[1] = c.r[2];  // 0608BD0C mov r2,r1
    c.r[2] += 112;  // 0608BD0E add #112,r2
    c.r[1] = 0x0u;  // 0608BD10 mov #0,r1
    st32(c.r[2], c.r[1]);  // 0608BD12 mov.l r1,@r2
    c.r[2] = ld32(c.r[14] + 12);  // 0608BD14 mov.l @(12,r14),r2
    c.r[1] = c.r[2];  // 0608BD16 mov r2,r1
    c.r[2] += 116;  // 0608BD18 add #116,r2
    c.r[1] = 0x0u;  // 0608BD1A mov #0,r1
    st32(c.r[2], c.r[1]);  // 0608BD1C mov.l r1,@r2
    c.r[1] = ld32(c.r[14] + 12);  // 0608BD1E mov.l @(12,r14),r1
    c.r[2] = c.r[1];  // 0608BD20 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608BD9Au);  // 0608BD22 mov.w 0x0608BD9A,r3
    c.r[1] += c.r[3];  // 0608BD24 add r3,r1
    c.r[2] = 0x0u;  // 0608BD26 mov #0,r2
    st32(c.r[1], c.r[2]);  // 0608BD28 mov.l r2,@r1
    c.r[1] = ld32(c.r[14] + 12);  // 0608BD2A mov.l @(12,r14),r1
    c.r[2] = c.r[1];  // 0608BD2C mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608BD9Cu);  // 0608BD2E mov.w 0x0608BD9C,r3
    c.r[1] += c.r[3];  // 0608BD30 add r3,r1
    c.r[2] = 0x0u;  // 0608BD32 mov #0,r2
    st32(c.r[1], c.r[2]);  // 0608BD34 mov.l r2,@r1
    c.r[1] = ld32(c.r[14] + 12);  // 0608BD36 mov.l @(12,r14),r1
    c.r[2] = c.r[1];  // 0608BD38 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608BD9Eu);  // 0608BD3A mov.w 0x0608BD9E,r3
    c.r[1] += c.r[3];  // 0608BD3C add r3,r1
    c.r[2] = 0x0u;  // 0608BD3E mov #0,r2
    st32(c.r[1], c.r[2]);  // 0608BD40 mov.l r2,@r1
    c.r[1] = ld32(c.r[14] + 12);  // 0608BD42 mov.l @(12,r14),r1
    c.r[2] = c.r[1];  // 0608BD44 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608BDA0u);  // 0608BD46 mov.w 0x0608BDA0,r3
    c.r[1] += c.r[3];  // 0608BD48 add r3,r1
    c.r[2] = 0x0u;  // 0608BD4A mov #0,r2
    st32(c.r[1], c.r[2]);  // 0608BD4C mov.l r2,@r1
    c.r[1] = ld32(c.r[14] + 12);  // 0608BD4E mov.l @(12,r14),r1
    c.r[2] = c.r[1];  // 0608BD50 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608BDA2u);  // 0608BD52 mov.w 0x0608BDA2,r3
    c.r[1] += c.r[3];  // 0608BD54 add r3,r1
    c.r[2] = 0x0u;  // 0608BD56 mov #0,r2
    st32(c.r[1], c.r[2]);  // 0608BD58 mov.l r2,@r1
    c.r[1] = ld32(c.r[14] + 12);  // 0608BD5A mov.l @(12,r14),r1
    c.r[2] = c.r[1];  // 0608BD5C mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608BDA4u);  // 0608BD5E mov.w 0x0608BDA4,r3
    c.r[1] += c.r[3];  // 0608BD60 add r3,r1
    c.r[2] = 0x0u;  // 0608BD62 mov #0,r2
    st32(c.r[1], c.r[2]);  // 0608BD64 mov.l r2,@r1
    c.r[1] = ld32(c.r[14] + 12);  // 0608BD66 mov.l @(12,r14),r1
    c.r[2] = c.r[1];  // 0608BD68 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608BDA6u);  // 0608BD6A mov.w 0x0608BDA6,r3
    c.r[1] += c.r[3];  // 0608BD6C add r3,r1
    c.r[2] = ld32(0x0608BDC0u);  // 0608BD6E mov.l 0x0608BDC0,r2
    st32(c.r[1], c.r[2]);  // 0608BD70 mov.l r2,@r1
    c.r[1] = (uint32_t)(int16_t)ld16(0x0608BDA8u);  // 0608BD72 mov.w 0x0608BDA8,r1
    c.r[2] = ld32(c.r[14] + 8);  // 0608BD74 mov.l @(8,r14),r2
    c.r[5] = c.r[1];  // 0608BD76 mov r1,r5
    c.r[4] = c.r[2];  // 0608BD78 mov r2,r4
    c.r[8] = ld32(0x0608BDC4u);  // 0608BD7A mov.l 0x0608BDC4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608BD80u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608BD80u) return; }  // 0608BD7C jsr @r8 ; nop
    c.r[0] = ld32(c.r[14] + 8);  // 0608BD80 mov.l @(8,r14),r0
    goto L_0608BD86;  // 0608BD82 bra 0x0608BD86 ; nop
L_0608BD86:
    c.r[14] += 24;  // 0608BD86 add #24,r14
    c.r[15] = c.r[14];  // 0608BD88 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608BD8A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608BD8C mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608BD8E mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608BD90 rts ; nop
}

void f_0608BDC8(SH2Context& c) {
    ran[2011] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608BDC8 mov.l r14,@-r15
    c.r[15] -= 8;  // 0608BDCA add #-8,r15
    c.r[14] = c.r[15];  // 0608BDCC mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608BDCE mov.l r4,@r14
    c.r[1] = ld32(c.r[14]);  // 0608BDD0 mov.l @r14,r1
    c.r[3] = ld32(0x0608BE18u);  // 0608BDD2 mov.l 0x0608BE18,r3
    c.r[2] = c.r[1];  // 0608BDD4 mov r1,r2
    c.r[2] -= c.r[3];  // 0608BDD6 sub r3,r2
    c.r[1] = c.r[2];  // 0608BDD8 mov r2,r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0608BDDA shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0608BDDC shar r1
    c.r[2] = c.r[1];  // 0608BDDE mov r1,r2
    st32(c.r[14] + 4, c.r[2]);  // 0608BDE0 mov.l r2,@(4,r14)
    c.r[1] = ld32(c.r[14] + 4);  // 0608BDE2 mov.l @(4,r14),r1
    c.r[2] = 0x1Fu;  // 0608BDE4 mov #31,r2
    c.t = c.r[1] > c.r[2];  // 0608BDE6 cmp/hi r2,r1
    if (c.t) { goto L_0608BE08; }  // 0608BDE8 bt 0x0608BE08
    c.r[1] = ld32(0x0608BE1Cu);  // 0608BDEA mov.l 0x0608BE1C,r1
    c.r[2] = ld32(c.r[14] + 4);  // 0608BDEC mov.l @(4,r14),r2
    c.r[3] = c.r[2];  // 0608BDEE mov r2,r3
    c.r[2] = c.r[3];  // 0608BDF0 mov r3,r2
    c.r[2] <<= 2;  // 0608BDF2 shll2 r2
    c.r[3] = ld32(0x0608BE20u);  // 0608BDF4 mov.l 0x0608BE20,r3
    c.r[2] += c.r[3];  // 0608BDF6 add r3,r2
    c.r[1] = ld32(c.r[1]);  // 0608BDF8 mov.l @r1,r1
    c.r[2] = ld32(c.r[2]);  // 0608BDFA mov.l @r2,r2
    c.r[1] &= c.r[2];  // 0608BDFC and r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0608BDFE tst r1,r1
    if (c.t) { goto L_0608BE08; }  // 0608BE00 bt 0x0608BE08
    c.r[0] = 0x1u;  // 0608BE02 mov #1,r0
    goto L_0608BE0E;  // 0608BE04 bra 0x0608BE0E ; nop
L_0608BE08:
    c.r[0] = 0x0u;  // 0608BE08 mov #0,r0
    goto L_0608BE0E;  // 0608BE0A bra 0x0608BE0E ; nop
L_0608BE0E:
    c.r[14] += 8;  // 0608BE0E add #8,r14
    c.r[15] = c.r[14];  // 0608BE10 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608BE12 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608BE14 rts ; nop
}

void f_0608BE24(SH2Context& c) {
    ran[2012] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608BE24 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608BE26 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608BE28 sts.l pr,@-r15
    c.r[15] -= 8;  // 0608BE2A add #-8,r15
    c.r[14] = c.r[15];  // 0608BE2C mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608BE2E mov.l r4,@r14
    c.r[1] = ld32(c.r[14]);  // 0608BE30 mov.l @r14,r1
    c.r[3] = ld32(0x0608BEC8u);  // 0608BE32 mov.l 0x0608BEC8,r3
    c.r[2] = c.r[1];  // 0608BE34 mov r1,r2
    c.r[2] -= c.r[3];  // 0608BE36 sub r3,r2
    c.r[1] = c.r[2];  // 0608BE38 mov r2,r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0608BE3A shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0608BE3C shar r1
    c.r[2] = c.r[1];  // 0608BE3E mov r1,r2
    st32(c.r[14] + 4, c.r[2]);  // 0608BE40 mov.l r2,@(4,r14)
    c.r[1] = ld32(0x0608BECCu);  // 0608BE42 mov.l 0x0608BECC,r1
    c.r[2] = ld32(c.r[1]);  // 0608BE44 mov.l @r1,r2
    c.r[1] = ld32(0x0608BED0u);  // 0608BE46 mov.l 0x0608BED0,r1
    c.t = c.r[2] == c.r[1];  // 0608BE48 cmp/eq r1,r2
    if (c.t) { goto L_0608BE5A; }  // 0608BE4A bt 0x0608BE5A
    c.r[1] = (uint32_t)(int16_t)ld16(0x0608BEC2u);  // 0608BE4C mov.w 0x0608BEC2,r1
    c.r[4] = c.r[1];  // 0608BE4E mov r1,r4
    c.r[8] = ld32(0x0608BED4u);  // 0608BE50 mov.l 0x0608BED4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608BE56u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608BE56u) return; }  // 0608BE52 jsr @r8 ; nop
    goto L_0608BEB4;  // 0608BE56 bra 0x0608BEB4 ; nop
L_0608BE5A:
    c.r[1] = ld32(0x0608BED8u);  // 0608BE5A mov.l 0x0608BED8,r1
    c.r[2] = ld32(c.r[14] + 4);  // 0608BE5C mov.l @(4,r14),r2
    c.r[3] = c.r[2];  // 0608BE5E mov r2,r3
    c.r[2] = c.r[3];  // 0608BE60 mov r3,r2
    c.r[2] <<= 2;  // 0608BE62 shll2 r2
    c.r[3] = ld32(0x0608BEDCu);  // 0608BE64 mov.l 0x0608BEDC,r3
    c.r[2] += c.r[3];  // 0608BE66 add r3,r2
    c.r[1] = ld32(c.r[1]);  // 0608BE68 mov.l @r1,r1
    c.r[2] = ld32(c.r[2]);  // 0608BE6A mov.l @r2,r2
    c.r[1] &= c.r[2];  // 0608BE6C and r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0608BE6E tst r1,r1
    if (!c.t) { goto L_0608BE80; }  // 0608BE70 bf 0x0608BE80
    c.r[1] = (uint32_t)(int16_t)ld16(0x0608BEC4u);  // 0608BE72 mov.w 0x0608BEC4,r1
    c.r[4] = c.r[1];  // 0608BE74 mov r1,r4
    c.r[8] = ld32(0x0608BED4u);  // 0608BE76 mov.l 0x0608BED4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608BE7Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608BE7Cu) return; }  // 0608BE78 jsr @r8 ; nop
    goto L_0608BEB4;  // 0608BE7C bra 0x0608BEB4 ; nop
L_0608BE80:
    c.r[4] = ld32(c.r[14]);  // 0608BE80 mov.l @r14,r4
    c.r[8] = ld32(0x0608BEE0u);  // 0608BE82 mov.l 0x0608BEE0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608BE88u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608BE88u) return; }  // 0608BE84 jsr @r8 ; nop
    c.r[1] = ld32(0x0608BED8u);  // 0608BE88 mov.l 0x0608BED8,r1
    c.r[2] = ld32(0x0608BED8u);  // 0608BE8A mov.l 0x0608BED8,r2
    c.r[3] = ld32(c.r[14] + 4);  // 0608BE8C mov.l @(4,r14),r3
    c.r[7] = c.r[3];  // 0608BE8E mov r3,r7
    c.r[3] = c.r[7];  // 0608BE90 mov r7,r3
    c.r[3] <<= 2;  // 0608BE92 shll2 r3
    c.r[7] = ld32(0x0608BEDCu);  // 0608BE94 mov.l 0x0608BEDC,r7
    c.r[3] += c.r[7];  // 0608BE96 add r7,r3
    c.r[7] = ld32(c.r[3]);  // 0608BE98 mov.l @r3,r7
    c.r[3] = ~c.r[7];  // 0608BE9A not r7,r3
    c.r[2] = ld32(c.r[2]);  // 0608BE9C mov.l @r2,r2
    c.r[3] &= c.r[2];  // 0608BE9E and r2,r3
    st32(c.r[1], c.r[3]);  // 0608BEA0 mov.l r3,@r1
    c.r[1] = ld32(0x0608BED8u);  // 0608BEA2 mov.l 0x0608BED8,r1
    c.r[2] = ld32(c.r[1]);  // 0608BEA4 mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0608BEA6 tst r2,r2
    if (!c.t) { goto L_0608BEB0; }  // 0608BEA8 bf 0x0608BEB0
    c.r[1] = ld32(0x0608BEE4u);  // 0608BEAA mov.l 0x0608BEE4,r1
    c.r[2] = 0x0u;  // 0608BEAC mov #0,r2
    st32(c.r[1], c.r[2]);  // 0608BEAE mov.l r2,@r1
L_0608BEB0:
    goto L_0608BEB4;  // 0608BEB0 bra 0x0608BEB4 ; nop
L_0608BEB4:
    c.r[14] += 8;  // 0608BEB4 add #8,r14
    c.r[15] = c.r[14];  // 0608BEB6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608BEB8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608BEBA mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608BEBC mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608BEBE rts ; nop
}

void f_0608BEE8(SH2Context& c) {
    ran[2013] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608BEE8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608BEEA mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608BEEC sts.l pr,@-r15
    c.r[15] -= 4;  // 0608BEEE add #-4,r15
    c.r[14] = c.r[15];  // 0608BEF0 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608BEF2 mov.l r4,@r14
    c.r[1] = (uint32_t)(int16_t)ld16(0x0608BF0Cu);  // 0608BEF4 mov.w 0x0608BF0C,r1
    c.r[4] = c.r[1];  // 0608BEF6 mov r1,r4
    c.r[8] = ld32(0x0608BF10u);  // 0608BEF8 mov.l 0x0608BF10,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608BEFEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608BEFEu) return; }  // 0608BEFA jsr @r8 ; nop
    c.r[14] += 4;  // 0608BEFE add #4,r14
    c.r[15] = c.r[14];  // 0608BF00 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608BF02 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608BF04 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608BF06 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608BF08 rts ; nop
}

void f_0608BF14(SH2Context& c) {
    ran[2014] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608BF14 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608BF16 sts.l pr,@-r15
    c.r[15] -= 20;  // 0608BF18 add #-20,r15
    c.r[14] = c.r[15];  // 0608BF1A mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608BF1C mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 0608BF1E mov.l r5,@(4,r14)
    c.r[1] = ld32(c.r[14]);  // 0608BF20 mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 0608BF22 mov.l @r1,r2
    st32(c.r[14] + 8, c.r[2]);  // 0608BF24 mov.l r2,@(8,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 0608BF26 mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 0608BF28 mov r1,r2
    c.r[2] += 4;  // 0608BF2A add #4,r2
    st32(c.r[14] + 12, c.r[2]);  // 0608BF2C mov.l r2,@(12,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 0608BF2E mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 0608BF30 mov r1,r2
    c.r[2] += 56;  // 0608BF32 add #56,r2
    st32(c.r[14] + 16, c.r[2]);  // 0608BF34 mov.l r2,@(16,r14)
    c.r[1] = ld32(c.r[14] + 16);  // 0608BF36 mov.l @(16,r14),r1
    c.r[2] = 0x1u;  // 0608BF38 mov #1,r2
    st32(c.r[1] + 8, c.r[2]);  // 0608BF3A mov.l r2,@(8,r1)
    c.r[2] = ld32(c.r[14] + 16);  // 0608BF3C mov.l @(16,r14),r2
    c.r[1] = c.r[2];  // 0608BF3E mov r2,r1
    c.r[2] += 24;  // 0608BF40 add #24,r2
    c.r[3] = ld32(c.r[14] + 4);  // 0608BF42 mov.l @(4,r14),r3
    c.r[1] = c.r[3];  // 0608BF44 mov r3,r1
    c.r[3] = ld32(c.r[1]);  // 0608BF46 mov.l @r1,r3
    st32(c.r[2], c.r[3]);  // 0608BF48 mov.l r3,@r2
    c.r[2] += 4;  // 0608BF4A add #4,r2
    c.r[1] += 4;  // 0608BF4C add #4,r1
    c.r[3] = ld32(c.r[1]);  // 0608BF4E mov.l @r1,r3
    st32(c.r[2], c.r[3]);  // 0608BF50 mov.l r3,@r2
    c.r[2] += 4;  // 0608BF52 add #4,r2
    c.r[1] += 4;  // 0608BF54 add #4,r1
    c.r[3] = ld32(c.r[1]);  // 0608BF56 mov.l @r1,r3
    st32(c.r[2], c.r[3]);  // 0608BF58 mov.l r3,@r2
    c.r[2] += 4;  // 0608BF5A add #4,r2
    c.r[1] += 4;  // 0608BF5C add #4,r1
    c.r[3] = ld32(c.r[1]);  // 0608BF5E mov.l @r1,r3
    st32(c.r[2], c.r[3]);  // 0608BF60 mov.l r3,@r2
    c.r[2] += 4;  // 0608BF62 add #4,r2
    c.r[1] += 4;  // 0608BF64 add #4,r1
    c.r[3] = ld32(c.r[1]);  // 0608BF66 mov.l @r1,r3
    st32(c.r[2], c.r[3]);  // 0608BF68 mov.l r3,@r2
    c.r[2] += 4;  // 0608BF6A add #4,r2
    c.r[1] += 4;  // 0608BF6C add #4,r1
    c.r[3] = ld32(c.r[1]);  // 0608BF6E mov.l @r1,r3
    st32(c.r[2], c.r[3]);  // 0608BF70 mov.l r3,@r2
    c.r[2] += 4;  // 0608BF72 add #4,r2
    c.r[1] += 4;  // 0608BF74 add #4,r1
    c.r[3] = ld32(c.r[1]);  // 0608BF76 mov.l @r1,r3
    st32(c.r[2], c.r[3]);  // 0608BF78 mov.l r3,@r2
    c.r[2] += 4;  // 0608BF7A add #4,r2
    c.r[1] += 4;  // 0608BF7C add #4,r1
    c.r[3] = ld32(c.r[1]);  // 0608BF7E mov.l @r1,r3
    st32(c.r[2], c.r[3]);  // 0608BF80 mov.l r3,@r2
    c.r[2] += 4;  // 0608BF82 add #4,r2
    c.r[1] += 4;  // 0608BF84 add #4,r1
    c.r[2] = ld32(c.r[14] + 16);  // 0608BF86 mov.l @(16,r14),r2
    c.r[0] = ld32(c.r[2] + 28);  // 0608BF88 mov.l @(28,r2),r0
    c.t = c.r[0] == 0x6u;  // 0608BF8A cmp/eq #6,r0
    if (!c.t) { goto L_0608BF98; }  // 0608BF8C bf 0x0608BF98
    c.r[1] = ld32(0x0608BFD4u);  // 0608BF8E mov.l 0x0608BFD4,r1
    c.r[2] = ld32(c.r[1]);  // 0608BF90 mov.l @r1,r2
    c.r[4] = ld32(c.r[14]);  // 0608BF92 mov.l @r14,r4
    { const uint32_t x = c.r[2]; c.pr = 0x0608BF98u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608BF98u) return; }  // 0608BF94 jsr @r2 ; nop
L_0608BF98:
    c.r[1] = ld32(c.r[14] + 16);  // 0608BF98 mov.l @(16,r14),r1
    c.r[2] = c.r[1];  // 0608BF9A mov r1,r2
    c.r[1] += 92;  // 0608BF9C add #92,r1
    c.r[3] = ld32(c.r[14] + 12);  // 0608BF9E mov.l @(12,r14),r3
    c.r[2] = ld32(c.r[3] + 12);  // 0608BFA0 mov.l @(12,r3),r2
    c.r[3] = ld32(c.r[14] + 16);  // 0608BFA2 mov.l @(16,r14),r3
    c.r[7] = ld32(c.r[3] + 40);  // 0608BFA4 mov.l @(40,r3),r7
    c.r[3] = 0x8u;  // 0608BFA6 mov #8,r3
    c.t = (int32_t)c.r[7] > (int32_t)c.r[3];  // 0608BFA8 cmp/gt r3,r7
    if (!c.t) { goto L_0608BFAE; }  // 0608BFAA bf 0x0608BFAE
    c.r[2] += c.r[2];  // 0608BFAC add r2,r2
L_0608BFAE:
    st32(c.r[1], c.r[2]);  // 0608BFAE mov.l r2,@r1
    c.r[1] = ld32(c.r[14] + 16);  // 0608BFB0 mov.l @(16,r14),r1
    c.r[2] = c.r[1];  // 0608BFB2 mov r1,r2
    c.r[1] += 88;  // 0608BFB4 add #88,r1
    c.r[2] = ld32(c.r[14] + 12);  // 0608BFB6 mov.l @(12,r14),r2
    c.r[7] = ld32(c.r[14] + 16);  // 0608BFB8 mov.l @(16,r14),r7
    c.r[3] = c.r[7];  // 0608BFBA mov r7,r3
    c.r[7] += 92;  // 0608BFBC add #92,r7
    c.r[2] = ld32(c.r[2] + 8);  // 0608BFBE mov.l @(8,r2),r2
    c.r[3] = ld32(c.r[7]);  // 0608BFC0 mov.l @r7,r3
    c.r[2] += c.r[3];  // 0608BFC2 add r3,r2
    st32(c.r[1], c.r[2]);  // 0608BFC4 mov.l r2,@r1
    c.r[14] += 20;  // 0608BFC6 add #20,r14
    c.r[15] = c.r[14];  // 0608BFC8 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608BFCA lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608BFCC mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608BFCE rts ; nop
}

void f_0608BFD8(SH2Context& c) {
    ran[2015] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608BFD8 mov.l r14,@-r15
    c.r[15] -= 12;  // 0608BFDA add #-12,r15
    c.r[14] = c.r[15];  // 0608BFDC mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608BFDE mov.l r4,@r14
    c.r[1] = ld32(c.r[14]);  // 0608BFE0 mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 0608BFE2 mov.l @r1,r2
    st32(c.r[14] + 4, c.r[2]);  // 0608BFE4 mov.l r2,@(4,r14)
    c.r[1] = ld32(c.r[14] + 4);  // 0608BFE6 mov.l @(4,r14),r1
    c.r[2] = c.r[1];  // 0608BFE8 mov r1,r2
    c.r[2] += 4;  // 0608BFEA add #4,r2
    st32(c.r[14] + 8, c.r[2]);  // 0608BFEC mov.l r2,@(8,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 0608BFEE mov.l @(8,r14),r1
    c.r[0] = ld32(c.r[1] + 4);  // 0608BFF0 mov.l @(4,r1),r0
    goto L_0608BFF6;  // 0608BFF2 bra 0x0608BFF6 ; nop
L_0608BFF6:
    c.r[14] += 12;  // 0608BFF6 add #12,r14
    c.r[15] = c.r[14];  // 0608BFF8 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608BFFA mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608BFFC rts ; nop
}

void f_0608C000(SH2Context& c) {
    ran[2016] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608C000 mov.l r14,@-r15
    c.r[15] -= 28;  // 0608C002 add #-28,r15
    c.r[14] = c.r[15];  // 0608C004 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608C006 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 0608C008 mov.l r5,@(4,r14)
    st32(c.r[14] + 8, c.r[6]);  // 0608C00A mov.l r6,@(8,r14)
    st32(c.r[14] + 12, c.r[7]);  // 0608C00C mov.l r7,@(12,r14)
    c.r[1] = ld32(c.r[14]);  // 0608C00E mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 0608C010 mov.l @r1,r2
    st32(c.r[14] + 16, c.r[2]);  // 0608C012 mov.l r2,@(16,r14)
    c.r[1] = ld32(c.r[14] + 16);  // 0608C014 mov.l @(16,r14),r1
    c.r[2] = c.r[1];  // 0608C016 mov r1,r2
    c.r[2] += 4;  // 0608C018 add #4,r2
    st32(c.r[14] + 20, c.r[2]);  // 0608C01A mov.l r2,@(20,r14)
    c.r[1] = ld32(c.r[14] + 16);  // 0608C01C mov.l @(16,r14),r1
    c.r[2] = c.r[1];  // 0608C01E mov r1,r2
    c.r[2] += 56;  // 0608C020 add #56,r2
    st32(c.r[14] + 24, c.r[2]);  // 0608C022 mov.l r2,@(24,r14)
    c.r[1] = ld32(c.r[14] + 12);  // 0608C024 mov.l @(12,r14),r1
    c.r[2] = ld32(c.r[14] + 20);  // 0608C026 mov.l @(20,r14),r2
    c.r[7] = ld32(c.r[14] + 24);  // 0608C028 mov.l @(24,r14),r7
    c.r[3] = c.r[7];  // 0608C02A mov r7,r3
    c.r[7] += 64;  // 0608C02C add #64,r7
    c.r[2] = ld32(c.r[2] + 4);  // 0608C02E mov.l @(4,r2),r2
    c.r[3] = ld32(c.r[7]);  // 0608C030 mov.l @r7,r3
    c.r[2] += c.r[3];  // 0608C032 add r3,r2
    c.r[3] = ld32(c.r[14] + 24);  // 0608C034 mov.l @(24,r14),r3
    c.r[7] = ld32(c.r[3] + 60);  // 0608C036 mov.l @(60,r3),r7
    c.r[2] -= c.r[7];  // 0608C038 sub r7,r2
    st32(c.r[1], c.r[2]);  // 0608C03A mov.l r2,@r1
    c.r[1] = ld32(c.r[14] + 12);  // 0608C03C mov.l @(12,r14),r1
    c.r[2] = ld32(c.r[1]);  // 0608C03E mov.l @r1,r2
    c.t = (int32_t)c.r[2] > 0;  // 0608C040 cmp/pl r2
    if (c.t) { goto L_0608C054; }  // 0608C042 bt 0x0608C054
    c.r[1] = ld32(c.r[14] + 8);  // 0608C044 mov.l @(8,r14),r1
    c.r[2] = 0x0u;  // 0608C046 mov #0,r2
    st32(c.r[1], c.r[2]);  // 0608C048 mov.l r2,@r1
    c.r[1] = ld32(c.r[14] + 4);  // 0608C04A mov.l @(4,r14),r1
    c.r[2] = 0x0u;  // 0608C04C mov #0,r2
    st32(c.r[1], c.r[2]);  // 0608C04E mov.l r2,@r1
    goto L_0608C096;  // 0608C050 bra 0x0608C096 ; nop
L_0608C054:
    c.r[1] = ld32(c.r[14] + 24);  // 0608C054 mov.l @(24,r14),r1
    c.r[2] = c.r[1];  // 0608C056 mov r1,r2
    c.r[1] += 72;  // 0608C058 add #72,r1
    c.r[3] = ld32(c.r[14] + 24);  // 0608C05A mov.l @(24,r14),r3
    c.r[2] = c.r[3];  // 0608C05C mov r3,r2
    c.r[3] += 76;  // 0608C05E add #76,r3
    c.r[1] = ld32(c.r[1]);  // 0608C060 mov.l @r1,r1
    c.r[2] = ld32(c.r[3]);  // 0608C062 mov.l @r3,r2
    c.t = c.r[1] >= c.r[2];  // 0608C064 cmp/hs r2,r1
    if (!c.t) { goto L_0608C082; }  // 0608C066 bf 0x0608C082
    c.r[1] = ld32(c.r[14] + 8);  // 0608C068 mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[14] + 24);  // 0608C06A mov.l @(24,r14),r2
    c.r[3] = c.r[2];  // 0608C06C mov r2,r3
    c.r[2] += 68;  // 0608C06E add #68,r2
    c.r[7] = ld32(c.r[14] + 24);  // 0608C070 mov.l @(24,r14),r7
    c.r[3] = c.r[7];  // 0608C072 mov r7,r3
    c.r[7] += 72;  // 0608C074 add #72,r7
    c.r[2] = ld32(c.r[2]);  // 0608C076 mov.l @r2,r2
    c.r[3] = ld32(c.r[7]);  // 0608C078 mov.l @r7,r3
    c.r[2] -= c.r[3];  // 0608C07A sub r3,r2
    st32(c.r[1], c.r[2]);  // 0608C07C mov.l r2,@r1
    goto L_0608C08A;  // 0608C07E bra 0x0608C08A ; nop
L_0608C082:
    c.r[1] = ld32(c.r[14] + 8);  // 0608C082 mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[14] + 12);  // 0608C084 mov.l @(12,r14),r2
    c.r[3] = ld32(c.r[2]);  // 0608C086 mov.l @r2,r3
    st32(c.r[1], c.r[3]);  // 0608C088 mov.l r3,@r1
L_0608C08A:
    c.r[1] = ld32(c.r[14] + 4);  // 0608C08A mov.l @(4,r14),r1
    c.r[3] = ld32(c.r[14] + 24);  // 0608C08C mov.l @(24,r14),r3
    c.r[2] = c.r[3];  // 0608C08E mov r3,r2
    c.r[3] += 72;  // 0608C090 add #72,r3
    c.r[2] = ld32(c.r[3]);  // 0608C092 mov.l @r3,r2
    st32(c.r[1], c.r[2]);  // 0608C094 mov.l r2,@r1
L_0608C096:
    goto L_0608C09A;  // 0608C096 bra 0x0608C09A ; nop
L_0608C09A:
    c.r[14] += 28;  // 0608C09A add #28,r14
    c.r[15] = c.r[14];  // 0608C09C mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608C09E mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608C0A0 rts ; nop
}

void f_0608C0A4(SH2Context& c) {
    ran[2017] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608C0A4 mov.l r14,@-r15
    c.r[15] -= 20;  // 0608C0A6 add #-20,r15
    c.r[14] = c.r[15];  // 0608C0A8 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608C0AA mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 0608C0AC mov.l r5,@(4,r14)
    c.r[1] = ld32(c.r[14]);  // 0608C0AE mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 0608C0B0 mov.l @r1,r2
    st32(c.r[14] + 8, c.r[2]);  // 0608C0B2 mov.l r2,@(8,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 0608C0B4 mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 0608C0B6 mov r1,r2
    c.r[2] += 4;  // 0608C0B8 add #4,r2
    st32(c.r[14] + 12, c.r[2]);  // 0608C0BA mov.l r2,@(12,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 0608C0BC mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 0608C0BE mov r1,r2
    c.r[2] += 56;  // 0608C0C0 add #56,r2
    st32(c.r[14] + 16, c.r[2]);  // 0608C0C2 mov.l r2,@(16,r14)
    c.r[1] = ld32(c.r[14] + 4);  // 0608C0C4 mov.l @(4,r14),r1
    c.t = (int32_t)c.r[1] > 0;  // 0608C0C6 cmp/pl r1
    if (c.t) { goto L_0608C0CE; }  // 0608C0C8 bt 0x0608C0CE
    goto L_0608C11C;  // 0608C0CA bra 0x0608C11C ; nop
L_0608C0CE:
    c.r[1] = ld32(c.r[14] + 16);  // 0608C0CE mov.l @(16,r14),r1
    c.r[2] = ld32(c.r[14] + 16);  // 0608C0D0 mov.l @(16,r14),r2
    c.r[3] = ld32(c.r[2] + 60);  // 0608C0D2 mov.l @(60,r2),r3
    c.r[2] = ld32(c.r[14] + 4);  // 0608C0D4 mov.l @(4,r14),r2
    c.r[3] += c.r[2];  // 0608C0D6 add r2,r3
    st32(c.r[1] + 60, c.r[3]);  // 0608C0D8 mov.l r3,@(60,r1)
    c.r[1] = ld32(c.r[14] + 16);  // 0608C0DA mov.l @(16,r14),r1
    c.r[2] = c.r[1];  // 0608C0DC mov r1,r2
    c.r[1] += 72;  // 0608C0DE add #72,r1
    c.r[3] = ld32(c.r[14] + 16);  // 0608C0E0 mov.l @(16,r14),r3
    c.r[2] = c.r[3];  // 0608C0E2 mov r3,r2
    c.r[3] += 72;  // 0608C0E4 add #72,r3
    c.r[2] = ld32(c.r[3]);  // 0608C0E6 mov.l @r3,r2
    c.r[3] = ld32(c.r[14] + 4);  // 0608C0E8 mov.l @(4,r14),r3
    c.r[2] += c.r[3];  // 0608C0EA add r3,r2
    st32(c.r[1], c.r[2]);  // 0608C0EC mov.l r2,@r1
    c.r[1] = ld32(c.r[14] + 16);  // 0608C0EE mov.l @(16,r14),r1
    c.r[2] = c.r[1];  // 0608C0F0 mov r1,r2
    c.r[1] += 72;  // 0608C0F2 add #72,r1
    c.r[3] = ld32(c.r[14] + 16);  // 0608C0F4 mov.l @(16,r14),r3
    c.r[2] = c.r[3];  // 0608C0F6 mov r3,r2
    c.r[3] += 68;  // 0608C0F8 add #68,r3
    c.r[1] = ld32(c.r[1]);  // 0608C0FA mov.l @r1,r1
    c.r[2] = ld32(c.r[3]);  // 0608C0FC mov.l @r3,r2
    c.t = c.r[1] >= c.r[2];  // 0608C0FE cmp/hs r2,r1
    if (!c.t) { goto L_0608C118; }  // 0608C100 bf 0x0608C118
    c.r[1] = ld32(c.r[14] + 16);  // 0608C102 mov.l @(16,r14),r1
    c.r[2] = c.r[1];  // 0608C104 mov r1,r2
    c.r[1] += 72;  // 0608C106 add #72,r1
    c.r[3] = ld32(c.r[14] + 16);  // 0608C108 mov.l @(16,r14),r3
    c.r[2] = c.r[3];  // 0608C10A mov r3,r2
    c.r[3] += 72;  // 0608C10C add #72,r3
    c.r[2] = ld32(c.r[14] + 12);  // 0608C10E mov.l @(12,r14),r2
    c.r[3] = ld32(c.r[3]);  // 0608C110 mov.l @r3,r3
    c.r[2] = ld32(c.r[2] + 4);  // 0608C112 mov.l @(4,r2),r2
    c.r[3] -= c.r[2];  // 0608C114 sub r2,r3
    st32(c.r[1], c.r[3]);  // 0608C116 mov.l r3,@r1
L_0608C118:
    goto L_0608C11C;  // 0608C118 bra 0x0608C11C ; nop
L_0608C11C:
    c.r[14] += 20;  // 0608C11C add #20,r14
    c.r[15] = c.r[14];  // 0608C11E mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608C120 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608C122 rts ; nop
}

void f_0608C128(SH2Context& c) {
    ran[2018] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608C128 mov.l r14,@-r15
    c.r[15] -= 20;  // 0608C12A add #-20,r15
    c.r[14] = c.r[15];  // 0608C12C mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608C12E mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 0608C130 mov.l r5,@(4,r14)
    c.r[1] = ld32(c.r[14]);  // 0608C132 mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 0608C134 mov.l @r1,r2
    st32(c.r[14] + 8, c.r[2]);  // 0608C136 mov.l r2,@(8,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 0608C138 mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 0608C13A mov r1,r2
    c.r[2] += 4;  // 0608C13C add #4,r2
    st32(c.r[14] + 12, c.r[2]);  // 0608C13E mov.l r2,@(12,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 0608C140 mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 0608C142 mov r1,r2
    c.r[2] += 56;  // 0608C144 add #56,r2
    st32(c.r[14] + 16, c.r[2]);  // 0608C146 mov.l r2,@(16,r14)
    c.r[1] = ld32(c.r[14] + 16);  // 0608C148 mov.l @(16,r14),r1
    c.r[2] = c.r[1];  // 0608C14A mov r1,r2
    c.r[1] += 64;  // 0608C14C add #64,r1
    c.r[3] = ld32(c.r[14] + 16);  // 0608C14E mov.l @(16,r14),r3
    c.r[2] = c.r[3];  // 0608C150 mov r3,r2
    c.r[3] += 64;  // 0608C152 add #64,r3
    c.r[2] = ld32(c.r[3]);  // 0608C154 mov.l @r3,r2
    c.r[3] = ld32(c.r[14] + 4);  // 0608C156 mov.l @(4,r14),r3
    c.r[2] += c.r[3];  // 0608C158 add r3,r2
    st32(c.r[1], c.r[2]);  // 0608C15A mov.l r2,@r1
    c.r[1] = ld32(c.r[14] + 16);  // 0608C15C mov.l @(16,r14),r1
    c.r[2] = c.r[1];  // 0608C15E mov r1,r2
    c.r[1] += 76;  // 0608C160 add #76,r1
    c.r[3] = ld32(c.r[14] + 16);  // 0608C162 mov.l @(16,r14),r3
    c.r[2] = c.r[3];  // 0608C164 mov r3,r2
    c.r[3] += 76;  // 0608C166 add #76,r3
    c.r[2] = ld32(c.r[3]);  // 0608C168 mov.l @r3,r2
    c.r[3] = ld32(c.r[14] + 4);  // 0608C16A mov.l @(4,r14),r3
    c.r[2] += c.r[3];  // 0608C16C add r3,r2
    st32(c.r[1], c.r[2]);  // 0608C16E mov.l r2,@r1
    c.r[1] = ld32(c.r[14] + 16);  // 0608C170 mov.l @(16,r14),r1
    c.r[2] = c.r[1];  // 0608C172 mov r1,r2
    c.r[1] += 76;  // 0608C174 add #76,r1
    c.r[3] = ld32(c.r[14] + 16);  // 0608C176 mov.l @(16,r14),r3
    c.r[2] = c.r[3];  // 0608C178 mov r3,r2
    c.r[3] += 68;  // 0608C17A add #68,r3
    c.r[1] = ld32(c.r[1]);  // 0608C17C mov.l @r1,r1
    c.r[2] = ld32(c.r[3]);  // 0608C17E mov.l @r3,r2
    c.t = c.r[1] >= c.r[2];  // 0608C180 cmp/hs r2,r1
    if (!c.t) { goto L_0608C19A; }  // 0608C182 bf 0x0608C19A
    c.r[1] = ld32(c.r[14] + 16);  // 0608C184 mov.l @(16,r14),r1
    c.r[2] = c.r[1];  // 0608C186 mov r1,r2
    c.r[1] += 76;  // 0608C188 add #76,r1
    c.r[3] = ld32(c.r[14] + 16);  // 0608C18A mov.l @(16,r14),r3
    c.r[2] = c.r[3];  // 0608C18C mov r3,r2
    c.r[3] += 76;  // 0608C18E add #76,r3
    c.r[2] = ld32(c.r[14] + 12);  // 0608C190 mov.l @(12,r14),r2
    c.r[3] = ld32(c.r[3]);  // 0608C192 mov.l @r3,r3
    c.r[2] = ld32(c.r[2] + 4);  // 0608C194 mov.l @(4,r2),r2
    c.r[3] -= c.r[2];  // 0608C196 sub r2,r3
    st32(c.r[1], c.r[3]);  // 0608C198 mov.l r3,@r1
L_0608C19A:
    goto L_0608C19E;  // 0608C19A bra 0x0608C19E ; nop
L_0608C19E:
    c.r[14] += 20;  // 0608C19E add #20,r14
    c.r[15] = c.r[14];  // 0608C1A0 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608C1A2 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608C1A4 rts ; nop
}

void f_0608C1A8(SH2Context& c) {
    ran[2019] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608C1A8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608C1AA mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608C1AC sts.l pr,@-r15
    c.r[15] -= 16;  // 0608C1AE add #-16,r15
    c.r[14] = c.r[15];  // 0608C1B0 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608C1B2 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 0608C1B4 mov.l r5,@(4,r14)
    c.r[1] = ld32(c.r[14]);  // 0608C1B6 mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 0608C1B8 mov.l @r1,r2
    st32(c.r[14] + 8, c.r[2]);  // 0608C1BA mov.l r2,@(8,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 0608C1BC mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 0608C1BE mov r1,r2
    c.r[2] += 56;  // 0608C1C0 add #56,r2
    st32(c.r[14] + 12, c.r[2]);  // 0608C1C2 mov.l r2,@(12,r14)
    c.r[1] = ld32(c.r[14] + 12);  // 0608C1C4 mov.l @(12,r14),r1
    c.r[2] = c.r[1];  // 0608C1C6 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608C20Cu);  // 0608C1C8 mov.w 0x0608C20C,r3
    c.r[1] += c.r[3];  // 0608C1CA add r3,r1
    c.r[2] = ld32(c.r[1]);  // 0608C1CC mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0608C1CE tst r2,r2
    if (!c.t) { goto L_0608C1E2; }  // 0608C1D0 bf 0x0608C1E2
    c.r[1] = ld32(c.r[14] + 4);  // 0608C1D2 mov.l @(4,r14),r1
    c.r[5] = c.r[1];  // 0608C1D4 mov r1,r5
    c.r[4] = ld32(c.r[14]);  // 0608C1D6 mov.l @r14,r4
    c.r[8] = ld32(0x0608C210u);  // 0608C1D8 mov.l 0x0608C210,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608C1DEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608C1DEu) return; }  // 0608C1DA jsr @r8 ; nop
    goto L_0608C1FA;  // 0608C1DE bra 0x0608C1FA ; nop
L_0608C1E2:
    c.r[1] = ld32(c.r[14] + 12);  // 0608C1E2 mov.l @(12,r14),r1
    c.r[2] = c.r[1];  // 0608C1E4 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608C20Eu);  // 0608C1E6 mov.w 0x0608C20E,r3
    c.r[1] += c.r[3];  // 0608C1E8 add r3,r1
    c.r[2] = ld32(c.r[14] + 12);  // 0608C1EA mov.l @(12,r14),r2
    c.r[3] = c.r[2];  // 0608C1EC mov r2,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x0608C20Eu);  // 0608C1EE mov.w 0x0608C20E,r7
    c.r[2] += c.r[7];  // 0608C1F0 add r7,r2
    c.r[3] = ld32(c.r[2]);  // 0608C1F2 mov.l @r2,r3
    c.r[2] = ld32(c.r[14] + 4);  // 0608C1F4 mov.l @(4,r14),r2
    c.r[3] += c.r[2];  // 0608C1F6 add r2,r3
    st32(c.r[1], c.r[3]);  // 0608C1F8 mov.l r3,@r1
L_0608C1FA:
    goto L_0608C1FE;  // 0608C1FA bra 0x0608C1FE ; nop
L_0608C1FE:
    c.r[14] += 16;  // 0608C1FE add #16,r14
    c.r[15] = c.r[14];  // 0608C200 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608C202 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608C204 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608C206 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608C208 rts ; nop
}

void f_0608C214(SH2Context& c) {
    ran[2020] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608C214 mov.l r14,@-r15
    c.r[15] -= 8;  // 0608C216 add #-8,r15
    c.r[14] = c.r[15];  // 0608C218 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608C21A mov.l r4,@r14
    c.r[1] = ld32(c.r[14]);  // 0608C21C mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 0608C21E mov.l @r1,r2
    st32(c.r[14] + 4, c.r[2]);  // 0608C220 mov.l r2,@(4,r14)
    c.r[2] = ld32(c.r[14] + 4);  // 0608C222 mov.l @(4,r14),r2
    c.r[1] = c.r[2];  // 0608C224 mov r2,r1
    c.r[1] += 4;  // 0608C226 add #4,r1
    c.r[0] = c.r[1];  // 0608C228 mov r1,r0
    goto L_0608C22E;  // 0608C22A bra 0x0608C22E ; nop
L_0608C22E:
    c.r[14] += 8;  // 0608C22E add #8,r14
    c.r[15] = c.r[14];  // 0608C230 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608C232 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608C234 rts ; nop
}

void f_0608C238(SH2Context& c) {
    ran[2021] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608C238 mov.l r14,@-r15
    c.r[15] -= 8;  // 0608C23A add #-8,r15
    c.r[14] = c.r[15];  // 0608C23C mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608C23E mov.l r4,@r14
    c.r[1] = ld32(c.r[14]);  // 0608C240 mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 0608C242 mov.l @r1,r2
    st32(c.r[14] + 4, c.r[2]);  // 0608C244 mov.l r2,@(4,r14)
    c.r[2] = ld32(c.r[14] + 4);  // 0608C246 mov.l @(4,r14),r2
    c.r[1] = c.r[2];  // 0608C248 mov r2,r1
    c.r[1] += 56;  // 0608C24A add #56,r1
    c.r[0] = c.r[1];  // 0608C24C mov r1,r0
    goto L_0608C252;  // 0608C24E bra 0x0608C252 ; nop
L_0608C252:
    c.r[14] += 8;  // 0608C252 add #8,r14
    c.r[15] = c.r[14];  // 0608C254 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608C256 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608C258 rts ; nop
}

void f_0608C25C(SH2Context& c) {
    ran[2022] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608C25C mov.l r14,@-r15
    c.r[15] -= 12;  // 0608C25E add #-12,r15
    c.r[14] = c.r[15];  // 0608C260 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608C262 mov.l r4,@r14
    c.r[1] = ld32(c.r[14]);  // 0608C264 mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 0608C266 mov.l @r1,r2
    st32(c.r[14] + 4, c.r[2]);  // 0608C268 mov.l r2,@(4,r14)
    c.r[1] = ld32(c.r[14] + 4);  // 0608C26A mov.l @(4,r14),r1
    c.r[2] = c.r[1];  // 0608C26C mov r1,r2
    c.r[2] += 56;  // 0608C26E add #56,r2
    st32(c.r[14] + 8, c.r[2]);  // 0608C270 mov.l r2,@(8,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 0608C272 mov.l @(8,r14),r1
    c.r[2] = 0x2u;  // 0608C274 mov #2,r2
    st32(c.r[1] + 4, c.r[2]);  // 0608C276 mov.l r2,@(4,r1)
    goto L_0608C27C;  // 0608C278 bra 0x0608C27C ; nop
L_0608C27C:
    c.r[14] += 12;  // 0608C27C add #12,r14
    c.r[15] = c.r[14];  // 0608C27E mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608C280 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608C282 rts ; nop
}

void f_0608C288(SH2Context& c) {
    ran[2023] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608C288 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608C28A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608C28C sts.l pr,@-r15
    c.r[15] -= 12;  // 0608C28E add #-12,r15
    c.r[14] = c.r[15];  // 0608C290 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608C292 mov.l r4,@r14
    c.r[1] = ld32(c.r[14]);  // 0608C294 mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 0608C296 mov.l @r1,r2
    st32(c.r[14] + 4, c.r[2]);  // 0608C298 mov.l r2,@(4,r14)
    c.r[1] = ld32(c.r[14] + 4);  // 0608C29A mov.l @(4,r14),r1
    c.r[2] = c.r[1];  // 0608C29C mov r1,r2
    c.r[2] += 56;  // 0608C29E add #56,r2
    st32(c.r[14] + 8, c.r[2]);  // 0608C2A0 mov.l r2,@(8,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 0608C2A2 mov.l @(8,r14),r1
    c.r[0] = ld32(c.r[1] + 4);  // 0608C2A4 mov.l @(4,r1),r0
    c.t = c.r[0] == 0x4u;  // 0608C2A6 cmp/eq #4,r0
    if (!c.t) { goto L_0608C2B2; }  // 0608C2A8 bf 0x0608C2B2
    c.r[4] = ld32(c.r[14]);  // 0608C2AA mov.l @r14,r4
    c.r[8] = ld32(0x0608C2D0u);  // 0608C2AC mov.l 0x0608C2D0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608C2B2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608C2B2u) return; }  // 0608C2AE jsr @r8 ; nop
L_0608C2B2:
    c.r[1] = ld32(c.r[14] + 8);  // 0608C2B2 mov.l @(8,r14),r1
    c.r[2] = 0x5u;  // 0608C2B4 mov #5,r2
    st32(c.r[1] + 4, c.r[2]);  // 0608C2B6 mov.l r2,@(4,r1)
    c.r[1] = ld32(c.r[14] + 8);  // 0608C2B8 mov.l @(8,r14),r1
    c.r[2] = 0x0u;  // 0608C2BA mov #0,r2
    st32(c.r[1] + 16, c.r[2]);  // 0608C2BC mov.l r2,@(16,r1)
    goto L_0608C2C2;  // 0608C2BE bra 0x0608C2C2 ; nop
L_0608C2C2:
    c.r[14] += 12;  // 0608C2C2 add #12,r14
    c.r[15] = c.r[14];  // 0608C2C4 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608C2C6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608C2C8 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608C2CA mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608C2CC rts ; nop
}

void f_0608C2D4(SH2Context& c) {
    ran[2024] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608C2D4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0608C2D6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608C2D8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608C2DA sts.l pr,@-r15
    c.r[15] -= 24;  // 0608C2DC add #-24,r15
    c.r[14] = c.r[15];  // 0608C2DE mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608C2E0 mov.l r4,@r14
    c.r[1] = ld32(c.r[14]);  // 0608C2E2 mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 0608C2E4 mov.l @r1,r2
    st32(c.r[14] + 4, c.r[2]);  // 0608C2E6 mov.l r2,@(4,r14)
    c.r[1] = ld32(c.r[14] + 4);  // 0608C2E8 mov.l @(4,r14),r1
    c.r[2] = c.r[1];  // 0608C2EA mov r1,r2
    c.r[2] += 4;  // 0608C2EC add #4,r2
    st32(c.r[14] + 8, c.r[2]);  // 0608C2EE mov.l r2,@(8,r14)
    c.r[1] = ld32(c.r[14] + 4);  // 0608C2F0 mov.l @(4,r14),r1
    c.r[2] = c.r[1];  // 0608C2F2 mov r1,r2
    c.r[2] += 56;  // 0608C2F4 add #56,r2
    st32(c.r[14] + 12, c.r[2]);  // 0608C2F6 mov.l r2,@(12,r14)
    c.r[1] = ld32(0x0608C400u);  // 0608C2F8 mov.l 0x0608C400,r1
    c.r[2] = ld32(c.r[1]);  // 0608C2FA mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0608C2FC tst r2,r2
    if (!c.t) { goto L_0608C30E; }  // 0608C2FE bf 0x0608C30E
    c.r[1] = (uint32_t)(int16_t)ld16(0x0608C3F8u);  // 0608C300 mov.w 0x0608C3F8,r1
    c.r[4] = c.r[1];  // 0608C302 mov r1,r4
    c.r[9] = ld32(0x0608C404u);  // 0608C304 mov.l 0x0608C404,r9
    { const uint32_t x = c.r[9]; c.pr = 0x0608C30Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608C30Au) return; }  // 0608C306 jsr @r9 ; nop
    goto L_0608C4B0;  // 0608C30A bra 0x0608C4B0 ; nop
L_0608C30E:
    c.r[1] = ld32(0x0608C408u);  // 0608C30E mov.l 0x0608C408,r1
    c.r[2] = ld32(c.r[1]);  // 0608C310 mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0608C312 tst r2,r2
    if (!c.t) { goto L_0608C324; }  // 0608C314 bf 0x0608C324
    c.r[1] = (uint32_t)(int16_t)ld16(0x0608C3FAu);  // 0608C316 mov.w 0x0608C3FA,r1
    c.r[4] = c.r[1];  // 0608C318 mov r1,r4
    c.r[9] = ld32(0x0608C404u);  // 0608C31A mov.l 0x0608C404,r9
    { const uint32_t x = c.r[9]; c.pr = 0x0608C320u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608C320u) return; }  // 0608C31C jsr @r9 ; nop
    goto L_0608C4B0;  // 0608C320 bra 0x0608C4B0 ; nop
L_0608C324:
    c.r[1] = ld32(c.r[14] + 12);  // 0608C324 mov.l @(12,r14),r1
    c.r[2] = c.r[1];  // 0608C326 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608C3FCu);  // 0608C328 mov.w 0x0608C3FC,r3
    c.r[1] += c.r[3];  // 0608C32A add r3,r1
    c.r[2] = ld32(0x0608C40Cu);  // 0608C32C mov.l 0x0608C40C,r2
    c.r[3] = ld32(c.r[2]);  // 0608C32E mov.l @r2,r3
    st32(c.r[1], c.r[3]);  // 0608C330 mov.l r3,@r1
    c.r[4] = ld32(c.r[14]);  // 0608C332 mov.l @r14,r4
    c.r[9] = ld32(0x0608C410u);  // 0608C334 mov.l 0x0608C410,r9
    { const uint32_t x = c.r[9]; c.pr = 0x0608C33Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608C33Au) return; }  // 0608C336 jsr @r9 ; nop
    c.r[4] = ld32(c.r[14]);  // 0608C33A mov.l @r14,r4
    c.r[9] = ld32(0x0608C414u);  // 0608C33C mov.l 0x0608C414,r9
    { const uint32_t x = c.r[9]; c.pr = 0x0608C342u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608C342u) return; }  // 0608C33E jsr @r9 ; nop
    c.r[1] = ld32(c.r[14] + 12);  // 0608C342 mov.l @(12,r14),r1
    c.r[2] = c.r[1];  // 0608C344 mov r1,r2
    c.r[1] += 116;  // 0608C346 add #116,r1
    c.r[3] = ld32(c.r[14] + 12);  // 0608C348 mov.l @(12,r14),r3
    c.r[2] = c.r[3];  // 0608C34A mov r3,r2
    c.r[3] += 116;  // 0608C34C add #116,r3
    c.r[2] = ld32(c.r[3]);  // 0608C34E mov.l @r3,r2
    c.r[3] = c.r[2];  // 0608C350 mov r2,r3
    c.r[3] += c.r[0];  // 0608C352 add r0,r3
    st32(c.r[1], c.r[3]);  // 0608C354 mov.l r3,@r1
    c.r[1] = ld32(c.r[14] + 12);  // 0608C356 mov.l @(12,r14),r1
    c.r[2] = c.r[1];  // 0608C358 mov r1,r2
    c.r[1] += 108;  // 0608C35A add #108,r1
    c.r[3] = ld32(c.r[14] + 12);  // 0608C35C mov.l @(12,r14),r3
    c.r[2] = c.r[3];  // 0608C35E mov r3,r2
    c.r[3] += 116;  // 0608C360 add #116,r3
    c.r[1] = ld32(c.r[1]);  // 0608C362 mov.l @r1,r1
    c.r[2] = ld32(c.r[3]);  // 0608C364 mov.l @r3,r2
    c.r[1] -= c.r[2];  // 0608C366 sub r2,r1
    st32(c.r[14] + 16, c.r[1]);  // 0608C368 mov.l r1,@(16,r14)
    c.r[2] = ld32(c.r[14] + 12);  // 0608C36A mov.l @(12,r14),r2
    c.r[1] = c.r[2];  // 0608C36C mov r2,r1
    c.r[2] += 96;  // 0608C36E add #96,r2
    c.r[8] = ld32(c.r[2]);  // 0608C370 mov.l @r2,r8
    c.r[1] = ld32(c.r[14] + 12);  // 0608C372 mov.l @(12,r14),r1
    c.r[2] = ld32(c.r[1] + 40);  // 0608C374 mov.l @(40,r1),r2
    c.r[1] = 0x8u;  // 0608C376 mov #8,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0608C378 cmp/gt r1,r2
    if (!c.t) { goto L_0608C38A; }  // 0608C37A bf 0x0608C38A
    c.r[1] = ld32(c.r[14] + 16);  // 0608C37C mov.l @(16,r14),r1
    c.r[2] = c.r[1];  // 0608C37E mov r1,r2
    c.r[2] += c.r[2];  // 0608C380 add r2,r2
    c.r[1] = c.r[8];  // 0608C382 mov r8,r1
    c.r[1] -= c.r[2];  // 0608C384 sub r2,r1
    goto L_0608C390;  // 0608C386 bra 0x0608C390 ; nop
L_0608C38A:
    c.r[2] = ld32(c.r[14] + 16);  // 0608C38A mov.l @(16,r14),r2
    c.r[1] = c.r[8];  // 0608C38C mov r8,r1
    c.r[1] -= c.r[2];  // 0608C38E sub r2,r1
L_0608C390:
    st32(c.r[14] + 20, c.r[1]);  // 0608C390 mov.l r1,@(20,r14)
    c.r[2] = ld32(c.r[14] + 12);  // 0608C392 mov.l @(12,r14),r2
    c.r[1] = c.r[2];  // 0608C394 mov r2,r1
    c.r[2] += 92;  // 0608C396 add #92,r2
    c.r[1] = ld32(c.r[2]);  // 0608C398 mov.l @r2,r1
    c.r[2] = c.r[1];  // 0608C39A mov r1,r2
    c.r[1] = c.r[2];  // 0608C39C mov r2,r1
    c.r[1] <<= 8;  // 0608C39E shll8 r1
    c.r[2] = ld32(c.r[14] + 20);  // 0608C3A0 mov.l @(20,r14),r2
    c.r[1] += c.r[2];  // 0608C3A2 add r2,r1
    st32(c.r[14] + 20, c.r[1]);  // 0608C3A4 mov.l r1,@(20,r14)
    c.r[2] = ld32(c.r[14] + 12);  // 0608C3A6 mov.l @(12,r14),r2
    c.r[1] = c.r[2];  // 0608C3A8 mov r2,r1
    c.r[6] = c.r[2];  // 0608C3AA mov r2,r6
    c.r[6] += 92;  // 0608C3AC add #92,r6
    c.r[7] = ld32(c.r[14] + 20);  // 0608C3AE mov.l @(20,r14),r7
    c.r[4] = c.r[7];  // 0608C3B0 mov r7,r4
    c.r[5] = ld32(c.r[6]);  // 0608C3B2 mov.l @r6,r5
    c.r[9] = ld32(0x0608C418u);  // 0608C3B4 mov.l 0x0608C418,r9
    { const uint32_t x = c.r[9]; c.pr = 0x0608C3BAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608C3BAu) return; }  // 0608C3B6 jsr @r9 ; nop
    c.r[1] = ld32(c.r[6]);  // 0608C3BA mov.l @r6,r1
    c.macl = c.r[0] * c.r[1];  // 0608C3BC mul.l r1,r0
    c.r[1] = c.macl;  // 0608C3BE sts macl,r1
    c.r[2] = c.r[7];  // 0608C3C0 mov r7,r2
    c.r[2] -= c.r[1];  // 0608C3C2 sub r1,r2
    st32(c.r[14] + 20, c.r[2]);  // 0608C3C4 mov.l r2,@(20,r14)
    c.r[1] = ld32(c.r[14] + 12);  // 0608C3C6 mov.l @(12,r14),r1
    c.r[0] = ld32(c.r[1] + 36);  // 0608C3C8 mov.l @(36,r1),r0
    c.t = c.r[0] == 0x1u;  // 0608C3CA cmp/eq #1,r0
    if (!c.t) { goto L_0608C420; }  // 0608C3CC bf 0x0608C420
    c.r[2] = ld32(c.r[14] + 12);  // 0608C3CE mov.l @(12,r14),r2
    c.r[1] = c.r[2];  // 0608C3D0 mov r2,r1
    c.r[2] += 92;  // 0608C3D2 add #92,r2
    c.r[1] = ld32(c.r[2]);  // 0608C3D4 mov.l @r2,r1
    c.r[3] = ld32(c.r[14] + 8);  // 0608C3D6 mov.l @(8,r14),r3
    c.r[2] = ld32(c.r[3] + 8);  // 0608C3D8 mov.l @(8,r3),r2
    c.r[7] = ld32(0x0608C408u);  // 0608C3DA mov.l 0x0608C408,r7
    c.r[3] = ld32(c.r[7]);  // 0608C3DC mov.l @r7,r3
    c.r[7] = ld32(0x0608C400u);  // 0608C3DE mov.l 0x0608C400,r7
    c.r[4] = ld32(c.r[7]);  // 0608C3E0 mov.l @r7,r4
    c.r[7] = ld32(c.r[14] + 20);  // 0608C3E2 mov.l @(20,r14),r7
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 0608C3E4 mov.l r7,@-r15
    c.r[7] = c.r[1];  // 0608C3E6 mov r1,r7
    c.r[6] = c.r[2];  // 0608C3E8 mov r2,r6
    c.r[5] = c.r[3];  // 0608C3EA mov r3,r5
    c.r[9] = ld32(0x0608C41Cu);  // 0608C3EC mov.l 0x0608C41C,r9
    { const uint32_t x = c.r[9]; c.pr = 0x0608C3F2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608C3F2u) return; }  // 0608C3EE jsr @r9 ; nop
    c.r[15] += 4;  // 0608C3F2 add #4,r15
    goto L_0608C470;  // 0608C3F4 bra 0x0608C470 ; nop
L_0608C420:
    c.r[2] = ld32(c.r[14] + 12);  // 0608C420 mov.l @(12,r14),r2
    c.r[1] = c.r[2];  // 0608C422 mov r2,r1
    c.r[2] += 92;  // 0608C424 add #92,r2
    c.r[1] = ld32(c.r[2]);  // 0608C426 mov.l @r2,r1
    c.r[3] = ld32(c.r[14] + 8);  // 0608C428 mov.l @(8,r14),r3
    c.r[2] = ld32(c.r[3] + 8);  // 0608C42A mov.l @(8,r3),r2
    c.r[7] = ld32(0x0608C4C0u);  // 0608C42C mov.l 0x0608C4C0,r7
    c.r[3] = ld32(c.r[7]);  // 0608C42E mov.l @r7,r3
    c.r[7] = ld32(0x0608C4C4u);  // 0608C430 mov.l 0x0608C4C4,r7
    c.r[4] = ld32(c.r[7]);  // 0608C432 mov.l @r7,r4
    c.r[7] = ld32(c.r[14] + 20);  // 0608C434 mov.l @(20,r14),r7
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 0608C436 mov.l r7,@-r15
    c.r[7] = c.r[1];  // 0608C438 mov r1,r7
    c.r[6] = c.r[2];  // 0608C43A mov r2,r6
    c.r[5] = c.r[3];  // 0608C43C mov r3,r5
    c.r[9] = ld32(0x0608C4C8u);  // 0608C43E mov.l 0x0608C4C8,r9
    { const uint32_t x = c.r[9]; c.pr = 0x0608C444u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608C444u) return; }  // 0608C440 jsr @r9 ; nop
    c.r[15] += 4;  // 0608C444 add #4,r15
    c.r[2] = ld32(c.r[14] + 12);  // 0608C446 mov.l @(12,r14),r2
    c.r[1] = c.r[2];  // 0608C448 mov r2,r1
    c.r[2] += 92;  // 0608C44A add #92,r2
    c.r[1] = ld32(c.r[2]);  // 0608C44C mov.l @r2,r1
    c.r[3] = ld32(c.r[14] + 12);  // 0608C44E mov.l @(12,r14),r3
    c.r[2] = c.r[3];  // 0608C450 mov r3,r2
    c.r[3] += 88;  // 0608C452 add #88,r3
    c.r[2] = ld32(c.r[3]);  // 0608C454 mov.l @r3,r2
    c.r[7] = ld32(0x0608C4C0u);  // 0608C456 mov.l 0x0608C4C0,r7
    c.r[3] = ld32(c.r[7]);  // 0608C458 mov.l @r7,r3
    c.r[7] = ld32(0x0608C4C4u);  // 0608C45A mov.l 0x0608C4C4,r7
    c.r[4] = ld32(c.r[7]);  // 0608C45C mov.l @r7,r4
    c.r[7] = ld32(c.r[14] + 20);  // 0608C45E mov.l @(20,r14),r7
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 0608C460 mov.l r7,@-r15
    c.r[7] = c.r[1];  // 0608C462 mov r1,r7
    c.r[6] = c.r[2];  // 0608C464 mov r2,r6
    c.r[5] = c.r[3];  // 0608C466 mov r3,r5
    c.r[9] = ld32(0x0608C4C8u);  // 0608C468 mov.l 0x0608C4C8,r9
    { const uint32_t x = c.r[9]; c.pr = 0x0608C46Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608C46Eu) return; }  // 0608C46A jsr @r9 ; nop
    c.r[15] += 4;  // 0608C46E add #4,r15
L_0608C470:
    c.r[1] = ld32(c.r[14] + 12);  // 0608C470 mov.l @(12,r14),r1
    c.r[2] = c.r[1];  // 0608C472 mov r1,r2
    c.r[1] += 96;  // 0608C474 add #96,r1
    c.r[3] = ld32(c.r[14] + 12);  // 0608C476 mov.l @(12,r14),r3
    c.r[2] = c.r[3];  // 0608C478 mov r3,r2
    c.r[3] += 96;  // 0608C47A add #96,r3
    c.r[2] = ld32(c.r[3]);  // 0608C47C mov.l @r3,r2
    c.r[3] = ld32(c.r[14] + 20);  // 0608C47E mov.l @(20,r14),r3
    c.r[2] -= c.r[3];  // 0608C480 sub r3,r2
    st32(c.r[1], c.r[2]);  // 0608C482 mov.l r2,@r1
    c.r[2] = ld32(c.r[14] + 12);  // 0608C484 mov.l @(12,r14),r2
    c.r[1] = c.r[2];  // 0608C486 mov r2,r1
    c.r[2] += 96;  // 0608C488 add #96,r2
    c.r[1] = ld32(c.r[2]);  // 0608C48A mov.l @r2,r1
    c.t = (int32_t)c.r[1] >= 0;  // 0608C48C cmp/pz r1
    if (c.t) { goto L_0608C4AA; }  // 0608C48E bt 0x0608C4AA
    c.r[1] = ld32(c.r[14] + 12);  // 0608C490 mov.l @(12,r14),r1
    c.r[2] = c.r[1];  // 0608C492 mov r1,r2
    c.r[1] += 96;  // 0608C494 add #96,r1
    c.r[2] = ld32(c.r[14] + 12);  // 0608C496 mov.l @(12,r14),r2
    c.r[3] = c.r[2];  // 0608C498 mov r2,r3
    c.r[2] += 96;  // 0608C49A add #96,r2
    c.r[7] = ld32(c.r[14] + 12);  // 0608C49C mov.l @(12,r14),r7
    c.r[3] = c.r[7];  // 0608C49E mov r7,r3
    c.r[7] += 92;  // 0608C4A0 add #92,r7
    c.r[2] = ld32(c.r[2]);  // 0608C4A2 mov.l @r2,r2
    c.r[3] = ld32(c.r[7]);  // 0608C4A4 mov.l @r7,r3
    c.r[2] += c.r[3];  // 0608C4A6 add r3,r2
    st32(c.r[1], c.r[2]);  // 0608C4A8 mov.l r2,@r1
L_0608C4AA:
    c.r[1] = ld32(c.r[14] + 12);  // 0608C4AA mov.l @(12,r14),r1
    c.r[2] = 0x1u;  // 0608C4AC mov #1,r2
    st32(c.r[1] + 4, c.r[2]);  // 0608C4AE mov.l r2,@(4,r1)
L_0608C4B0:
    c.r[14] += 24;  // 0608C4B0 add #24,r14
    c.r[15] = c.r[14];  // 0608C4B2 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608C4B4 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608C4B6 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0608C4B8 mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608C4BA mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608C4BC rts ; nop
}

void f_0608C4CC(SH2Context& c) {
    ran[2025] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608C4CC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608C4CE mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608C4D0 sts.l pr,@-r15
    c.r[15] -= 16;  // 0608C4D2 add #-16,r15
    c.r[14] = c.r[15];  // 0608C4D4 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608C4D6 mov.l r4,@r14
    c.r[1] = ld32(c.r[14]);  // 0608C4D8 mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 0608C4DA mov.l @r1,r2
    st32(c.r[14] + 4, c.r[2]);  // 0608C4DC mov.l r2,@(4,r14)
    c.r[1] = ld32(c.r[14] + 4);  // 0608C4DE mov.l @(4,r14),r1
    c.r[2] = c.r[1];  // 0608C4E0 mov r1,r2
    c.r[2] += 56;  // 0608C4E2 add #56,r2
    st32(c.r[14] + 8, c.r[2]);  // 0608C4E4 mov.l r2,@(8,r14)
    c.r[8] = ld32(0x0608C5B0u);  // 0608C4E6 mov.l 0x0608C5B0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608C4ECu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608C4ECu) return; }  // 0608C4E8 jsr @r8 ; nop
    st32(c.r[14] + 12, c.r[0]);  // 0608C4EC mov.l r0,@(12,r14)
    c.r[4] = 0xFu;  // 0608C4EE mov #15,r4
    c.r[8] = ld32(0x0608C5B4u);  // 0608C4F0 mov.l 0x0608C5B4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608C4F6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608C4F6u) return; }  // 0608C4F2 jsr @r8 ; nop
    c.r[1] = ld32(c.r[14] + 8);  // 0608C4F6 mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 0608C4F8 mov r1,r2
    c.r[1] += 124;  // 0608C4FA add #124,r1
    c.r[2] = ld32(0x0608C5B8u);  // 0608C4FC mov.l 0x0608C5B8,r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0608C4FE mov.w @r2,r3
    c.r[2] = 0x1u;  // 0608C500 mov #1,r2
    c.r[2] &= c.r[3];  // 0608C502 and r3,r2
    c.r[3] = c.r[2] & 0xFFFFu;  // 0608C504 extu.w r2,r3
    c.t = (c.r[3] & c.r[3]) == 0;  // 0608C506 tst r3,r3
    if (c.t) { goto L_0608C51E; }  // 0608C508 bt 0x0608C51E
    c.r[2] = ld32(0x0608C5BCu);  // 0608C50A mov.l 0x0608C5BC,r2
    c.r[3] = ld32(c.r[2]);  // 0608C50C mov.l @r2,r3
    c.t = (c.r[3] & c.r[3]) == 0;  // 0608C50E tst r3,r3
    if (!c.t) { goto L_0608C518; }  // 0608C510 bf 0x0608C518
    c.r[2] = (uint32_t)(int16_t)ld16(0x0608C5A2u);  // 0608C512 mov.w 0x0608C5A2,r2
    goto L_0608C51A;  // 0608C514 bra 0x0608C51A ; nop
L_0608C518:
    c.r[2] = (uint32_t)(int16_t)ld16(0x0608C5A4u);  // 0608C518 mov.w 0x0608C5A4,r2
L_0608C51A:
    goto L_0608C52E;  // 0608C51A bra 0x0608C52E ; nop
L_0608C51E:
    c.r[3] = ld32(0x0608C5BCu);  // 0608C51E mov.l 0x0608C5BC,r3
    c.r[7] = ld32(c.r[3]);  // 0608C520 mov.l @r3,r7
    c.t = (c.r[7] & c.r[7]) == 0;  // 0608C522 tst r7,r7
    if (!c.t) { goto L_0608C52C; }  // 0608C524 bf 0x0608C52C
    c.r[2] = (uint32_t)(int16_t)ld16(0x0608C5A6u);  // 0608C526 mov.w 0x0608C5A6,r2
    goto L_0608C52E;  // 0608C528 bra 0x0608C52E ; nop
L_0608C52C:
    c.r[2] = (uint32_t)(int16_t)ld16(0x0608C5A8u);  // 0608C52C mov.w 0x0608C5A8,r2
L_0608C52E:
    st32(c.r[1], c.r[2]);  // 0608C52E mov.l r2,@r1
    c.r[4] = ld32(c.r[14]);  // 0608C530 mov.l @r14,r4
    c.r[8] = ld32(0x0608C5C0u);  // 0608C532 mov.l 0x0608C5C0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608C538u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608C538u) return; }  // 0608C534 jsr @r8 ; nop
    c.r[4] = ld32(c.r[14]);  // 0608C538 mov.l @r14,r4
    c.r[8] = ld32(0x0608C5C4u);  // 0608C53A mov.l 0x0608C5C4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608C540u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608C540u) return; }  // 0608C53C jsr @r8 ; nop
    c.r[1] = ld32(c.r[14] + 8);  // 0608C540 mov.l @(8,r14),r1
    c.r[2] = 0x4u;  // 0608C542 mov #4,r2
    st32(c.r[1] + 4, c.r[2]);  // 0608C544 mov.l r2,@(4,r1)
    c.r[2] = ld32(c.r[14] + 8);  // 0608C546 mov.l @(8,r14),r2
    c.r[1] = c.r[2];  // 0608C548 mov r2,r1
    c.r[2] += 100;  // 0608C54A add #100,r2
    c.r[1] = 0x0u;  // 0608C54C mov #0,r1
    st32(c.r[2], c.r[1]);  // 0608C54E mov.l r1,@r2
    c.r[1] = ld32(c.r[14] + 8);  // 0608C550 mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 0608C552 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608C5AAu);  // 0608C554 mov.w 0x0608C5AA,r3
    c.r[1] += c.r[3];  // 0608C556 add r3,r1
    c.r[2] = ld32(0x0608C5C8u);  // 0608C558 mov.l 0x0608C5C8,r2
    c.r[3] = ld32(c.r[2]);  // 0608C55A mov.l @r2,r3
    st32(c.r[1], c.r[3]);  // 0608C55C mov.l r3,@r1
    c.r[1] = ld32(c.r[14] + 8);  // 0608C55E mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 0608C560 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608C5ACu);  // 0608C562 mov.w 0x0608C5AC,r3
    c.r[1] += c.r[3];  // 0608C564 add r3,r1
    c.r[2] = ld32(c.r[14] + 8);  // 0608C566 mov.l @(8,r14),r2
    c.r[3] = c.r[2];  // 0608C568 mov r2,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x0608C5ACu);  // 0608C56A mov.w 0x0608C5AC,r7
    c.r[2] += c.r[7];  // 0608C56C add r7,r2
    c.r[3] = ld32(c.r[14] + 8);  // 0608C56E mov.l @(8,r14),r3
    c.r[7] = c.r[3];  // 0608C570 mov r3,r7
    c.r[6] = (uint32_t)(int16_t)ld16(0x0608C5AAu);  // 0608C572 mov.w 0x0608C5AA,r6
    c.r[3] += c.r[6];  // 0608C574 add r6,r3
    c.r[7] = ld32(c.r[14] + 8);  // 0608C576 mov.l @(8,r14),r7
    c.r[6] = c.r[7];  // 0608C578 mov r7,r6
    c.r[5] = (uint32_t)(int16_t)ld16(0x0608C5AEu);  // 0608C57A mov.w 0x0608C5AE,r5
    c.r[7] += c.r[5];  // 0608C57C add r5,r7
    c.r[3] = ld32(c.r[3]);  // 0608C57E mov.l @r3,r3
    c.r[7] = ld32(c.r[7]);  // 0608C580 mov.l @r7,r7
    c.r[3] -= c.r[7];  // 0608C582 sub r7,r3
    c.r[2] = ld32(c.r[2]);  // 0608C584 mov.l @r2,r2
    c.r[3] += c.r[2];  // 0608C586 add r2,r3
    st32(c.r[1], c.r[3]);  // 0608C588 mov.l r3,@r1
    c.r[1] = ld32(c.r[14] + 12);  // 0608C58A mov.l @(12,r14),r1
    c.r[4] = c.r[1];  // 0608C58C mov r1,r4
    c.r[8] = ld32(0x0608C5B4u);  // 0608C58E mov.l 0x0608C5B4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608C594u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608C594u) return; }  // 0608C590 jsr @r8 ; nop
    c.r[14] += 16;  // 0608C594 add #16,r14
    c.r[15] = c.r[14];  // 0608C596 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608C598 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608C59A mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608C59C mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608C59E rts ; nop
}

void f_0608C5CC(SH2Context& c) {
    ran[2026] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608C5CC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608C5CE mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608C5D0 sts.l pr,@-r15
    c.r[15] -= 16;  // 0608C5D2 add #-16,r15
    c.r[14] = c.r[15];  // 0608C5D4 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608C5D6 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 0608C5D8 mov.l r5,@(4,r14)
    c.r[1] = ld32(c.r[14]);  // 0608C5DA mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 0608C5DC mov.l @r1,r2
    st32(c.r[14] + 8, c.r[2]);  // 0608C5DE mov.l r2,@(8,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 0608C5E0 mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 0608C5E2 mov r1,r2
    c.r[2] += 56;  // 0608C5E4 add #56,r2
    st32(c.r[14] + 12, c.r[2]);  // 0608C5E6 mov.l r2,@(12,r14)
    c.r[1] = ld32(c.r[14] + 12);  // 0608C5E8 mov.l @(12,r14),r1
    c.r[0] = ld32(c.r[1] + 4);  // 0608C5EA mov.l @(4,r1),r0
    c.t = c.r[0] == 0x1u;  // 0608C5EC cmp/eq #1,r0
    if (c.t) { goto L_0608C60A; }  // 0608C5EE bt 0x0608C60A
    c.t = c.r[0] == 0x4u;  // 0608C5F0 cmp/eq #4,r0
    if (c.t) { goto L_0608C5F8; }  // 0608C5F2 bt 0x0608C5F8
    goto L_0608C61C;  // 0608C5F4 bra 0x0608C61C ; nop
L_0608C5F8:
    c.r[1] = ld32(c.r[14] + 4);  // 0608C5F8 mov.l @(4,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0608C5FA tst r1,r1
    if (!c.t) { goto L_0608C606; }  // 0608C5FC bf 0x0608C606
    c.r[4] = ld32(c.r[14]);  // 0608C5FE mov.l @r14,r4
    c.r[8] = ld32(0x0608C634u);  // 0608C600 mov.l 0x0608C634,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608C606u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608C606u) return; }  // 0608C602 jsr @r8 ; nop
L_0608C606:
    goto L_0608C620;  // 0608C606 bra 0x0608C620 ; nop
L_0608C60A:
    c.r[0] = ld32(c.r[14] + 4);  // 0608C60A mov.l @(4,r14),r0
    c.t = c.r[0] == 0x1u;  // 0608C60C cmp/eq #1,r0
    if (!c.t) { goto L_0608C618; }  // 0608C60E bf 0x0608C618
    c.r[4] = ld32(c.r[14]);  // 0608C610 mov.l @r14,r4
    c.r[8] = ld32(0x0608C638u);  // 0608C612 mov.l 0x0608C638,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608C618u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608C618u) return; }  // 0608C614 jsr @r8 ; nop
L_0608C618:
    goto L_0608C620;  // 0608C618 bra 0x0608C620 ; nop
L_0608C61C:
    goto L_0608C620;  // 0608C61C bra 0x0608C620 ; nop
L_0608C620:
    goto L_0608C624;  // 0608C620 bra 0x0608C624 ; nop
L_0608C624:
    c.r[14] += 16;  // 0608C624 add #16,r14
    c.r[15] = c.r[14];  // 0608C626 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608C628 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608C62A mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608C62C mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608C62E rts ; nop
}

void f_0608C644(SH2Context& c) {
    ran[2027] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608C644 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608C646 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608C648 sts.l pr,@-r15
    c.r[15] -= 20;  // 0608C64A add #-20,r15
    c.r[14] = c.r[15];  // 0608C64C mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608C64E mov.l r4,@r14
    c.r[1] = ld32(c.r[14]);  // 0608C650 mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 0608C652 mov.l @r1,r2
    st32(c.r[14] + 4, c.r[2]);  // 0608C654 mov.l r2,@(4,r14)
    c.r[1] = ld32(c.r[14] + 4);  // 0608C656 mov.l @(4,r14),r1
    c.r[2] = c.r[1];  // 0608C658 mov r1,r2
    c.r[2] += 4;  // 0608C65A add #4,r2
    st32(c.r[14] + 8, c.r[2]);  // 0608C65C mov.l r2,@(8,r14)
    c.r[1] = ld32(c.r[14] + 4);  // 0608C65E mov.l @(4,r14),r1
    c.r[2] = c.r[1];  // 0608C660 mov r1,r2
    c.r[2] += 56;  // 0608C662 add #56,r2
    st32(c.r[14] + 12, c.r[2]);  // 0608C664 mov.l r2,@(12,r14)
    c.r[1] = ld32(c.r[14] + 12);  // 0608C666 mov.l @(12,r14),r1
    c.r[0] = ld32(c.r[1] + 24);  // 0608C668 mov.l @(24,r1),r0
    c.t = c.r[0] == 0x1u;  // 0608C66A cmp/eq #1,r0
    if (!c.t) { goto L_0608C68C; }  // 0608C66C bf 0x0608C68C
    c.r[1] = ld32(c.r[14] + 12);  // 0608C66E mov.l @(12,r14),r1
    c.r[2] = ld32(c.r[1] + 12);  // 0608C670 mov.l @(12,r1),r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0608C672 tst r2,r2
    if (!c.t) { goto L_0608C686; }  // 0608C674 bf 0x0608C686
    c.r[1] = ld32(c.r[14] + 12);  // 0608C676 mov.l @(12,r14),r1
    c.r[2] = 0x3u;  // 0608C678 mov #3,r2
    st32(c.r[1] + 4, c.r[2]);  // 0608C67A mov.l r2,@(4,r1)
    c.r[0] = 0x0u;  // 0608C67C mov #0,r0
    goto L_0608C742;  // 0608C67E bra 0x0608C742 ; nop
L_0608C686:
    c.r[0] = 0xFFFFFFFFu;  // 0608C686 mov #-1,r0
    goto L_0608C742;  // 0608C688 bra 0x0608C742 ; nop
L_0608C68C:
    c.r[1] = ld32(c.r[14] + 12);  // 0608C68C mov.l @(12,r14),r1
    c.r[2] = ld32(c.r[1] + 60);  // 0608C68E mov.l @(60,r1),r2
    c.r[1] = 0x3u;  // 0608C690 mov #3,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0608C692 cmp/gt r1,r2
    if (c.t) { goto L_0608C69C; }  // 0608C694 bt 0x0608C69C
    c.r[0] = 0xFFFFFFFFu;  // 0608C696 mov #-1,r0
    goto L_0608C742;  // 0608C698 bra 0x0608C742 ; nop
L_0608C69C:
    c.r[1] = ld32(c.r[14] + 8);  // 0608C69C mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[1]);  // 0608C69E mov.l @r1,r2
    c.r[1] = ld32(c.r[2]);  // 0608C6A0 mov.l @r2,r1
    st32(c.r[14] + 16, c.r[1]);  // 0608C6A2 mov.l r1,@(16,r14)
    c.r[1] = ld32(0x0608C758u);  // 0608C6A4 mov.l 0x0608C758,r1
    c.r[2] = ld32(c.r[14] + 16);  // 0608C6A6 mov.l @(16,r14),r2
    c.r[1] = ld32(c.r[1]);  // 0608C6A8 mov.l @r1,r1
    c.t = c.r[2] == c.r[1];  // 0608C6AA cmp/eq r1,r2
    if (!c.t) { goto L_0608C6C4; }  // 0608C6AC bf 0x0608C6C4
    c.r[4] = ld32(c.r[14]);  // 0608C6AE mov.l @r14,r4
    c.r[8] = ld32(0x0608C75Cu);  // 0608C6B0 mov.l 0x0608C75C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608C6B6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608C6B6u) return; }  // 0608C6B2 jsr @r8 ; nop
    c.t = (c.r[0] & c.r[0]) == 0;  // 0608C6B6 tst r0,r0
    if (c.t) { goto L_0608C6C0; }  // 0608C6B8 bt 0x0608C6C0
    c.r[0] = 0xFFFFFFFFu;  // 0608C6BA mov #-1,r0
    goto L_0608C742;  // 0608C6BC bra 0x0608C742 ; nop
L_0608C6C0:
    goto L_0608C6D4;  // 0608C6C0 bra 0x0608C6D4 ; nop
L_0608C6C4:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0608C750u);  // 0608C6C4 mov.w 0x0608C750,r1
    c.r[4] = c.r[1];  // 0608C6C6 mov r1,r4
    c.r[8] = ld32(0x0608C760u);  // 0608C6C8 mov.l 0x0608C760,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608C6CEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608C6CEu) return; }  // 0608C6CA jsr @r8 ; nop
    c.r[0] = 0xFFFFFFFFu;  // 0608C6CE mov #-1,r0
    goto L_0608C742;  // 0608C6D0 bra 0x0608C742 ; nop
L_0608C6D4:
    c.r[1] = ld32(c.r[14] + 12);  // 0608C6D4 mov.l @(12,r14),r1
    c.r[2] = c.r[1];  // 0608C6D6 mov r1,r2
    c.r[1] += 92;  // 0608C6D8 add #92,r1
    c.r[3] = ld32(c.r[14] + 8);  // 0608C6DA mov.l @(8,r14),r3
    c.r[2] = ld32(c.r[3] + 12);  // 0608C6DC mov.l @(12,r3),r2
    c.r[3] = ld32(c.r[14] + 12);  // 0608C6DE mov.l @(12,r14),r3
    c.r[7] = ld32(c.r[3] + 40);  // 0608C6E0 mov.l @(40,r3),r7
    c.r[3] = 0x8u;  // 0608C6E2 mov #8,r3
    c.t = (int32_t)c.r[7] > (int32_t)c.r[3];  // 0608C6E4 cmp/gt r3,r7
    if (!c.t) { goto L_0608C6EA; }  // 0608C6E6 bf 0x0608C6EA
    c.r[2] += c.r[2];  // 0608C6E8 add r2,r2
L_0608C6EA:
    st32(c.r[1], c.r[2]);  // 0608C6EA mov.l r2,@r1
    c.r[1] = ld32(c.r[14] + 12);  // 0608C6EC mov.l @(12,r14),r1
    c.r[2] = c.r[1];  // 0608C6EE mov r1,r2
    c.r[1] += 88;  // 0608C6F0 add #88,r1
    c.r[2] = ld32(c.r[14] + 8);  // 0608C6F2 mov.l @(8,r14),r2
    c.r[7] = ld32(c.r[14] + 12);  // 0608C6F4 mov.l @(12,r14),r7
    c.r[3] = c.r[7];  // 0608C6F6 mov r7,r3
    c.r[7] += 92;  // 0608C6F8 add #92,r7
    c.r[2] = ld32(c.r[2] + 8);  // 0608C6FA mov.l @(8,r2),r2
    c.r[3] = ld32(c.r[7]);  // 0608C6FC mov.l @r7,r3
    c.r[2] += c.r[3];  // 0608C6FE add r3,r2
    st32(c.r[1], c.r[2]);  // 0608C700 mov.l r2,@r1
    c.r[2] = ld32(c.r[14] + 12);  // 0608C702 mov.l @(12,r14),r2
    c.r[1] = c.r[2];  // 0608C704 mov r2,r1
    c.r[2] += 80;  // 0608C706 add #80,r2
    c.r[1] = ld32(c.r[2]);  // 0608C708 mov.l @r2,r1
    c.r[5] = c.r[1];  // 0608C70A mov r1,r5
    c.r[4] = ld32(c.r[14]);  // 0608C70C mov.l @r14,r4
    c.r[8] = ld32(0x0608C764u);  // 0608C70E mov.l 0x0608C764,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608C714u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608C714u) return; }  // 0608C710 jsr @r8 ; nop
    c.r[1] = ld32(c.r[14] + 12);  // 0608C714 mov.l @(12,r14),r1
    c.r[2] = c.r[1];  // 0608C716 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608C752u);  // 0608C718 mov.w 0x0608C752,r3
    c.r[1] += c.r[3];  // 0608C71A add r3,r1
    c.r[2] = ld32(c.r[14] + 12);  // 0608C71C mov.l @(12,r14),r2
    c.r[3] = c.r[2];  // 0608C71E mov r2,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x0608C754u);  // 0608C720 mov.w 0x0608C754,r7
    c.r[3] = c.r[2];  // 0608C722 mov r2,r3
    c.r[3] += c.r[7];  // 0608C724 add r7,r3
    c.r[2] = ld32(c.r[3]);  // 0608C726 mov.l @r3,r2
    c.r[3] = ld32(c.r[14] + 12);  // 0608C728 mov.l @(12,r14),r3
    c.r[7] = ld32(c.r[3] + 40);  // 0608C72A mov.l @(40,r3),r7
    c.r[3] = 0x8u;  // 0608C72C mov #8,r3
    c.t = (int32_t)c.r[7] > (int32_t)c.r[3];  // 0608C72E cmp/gt r3,r7
    if (!c.t) { goto L_0608C734; }  // 0608C730 bf 0x0608C734
    c.r[2] += c.r[2];  // 0608C732 add r2,r2
L_0608C734:
    st32(c.r[1], c.r[2]);  // 0608C734 mov.l r2,@r1
    c.r[1] = ld32(c.r[14] + 12);  // 0608C736 mov.l @(12,r14),r1
    c.r[2] = 0x3u;  // 0608C738 mov #3,r2
    st32(c.r[1] + 4, c.r[2]);  // 0608C73A mov.l r2,@(4,r1)
    c.r[0] = 0x0u;  // 0608C73C mov #0,r0
    goto L_0608C742;  // 0608C73E bra 0x0608C742 ; nop
L_0608C742:
    c.r[14] += 20;  // 0608C742 add #20,r14
    c.r[15] = c.r[14];  // 0608C744 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608C746 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608C748 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608C74A mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608C74C rts ; nop
}

void f_0608C768(SH2Context& c) {
    ran[2028] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608C768 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608C76A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608C76C sts.l pr,@-r15
    c.r[15] -= 16;  // 0608C76E add #-16,r15
    c.r[14] = c.r[15];  // 0608C770 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608C772 mov.l r4,@r14
    c.r[1] = ld32(c.r[14]);  // 0608C774 mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 0608C776 mov.l @r1,r2
    st32(c.r[14] + 4, c.r[2]);  // 0608C778 mov.l r2,@(4,r14)
    c.r[1] = ld32(c.r[14] + 4);  // 0608C77A mov.l @(4,r14),r1
    c.r[2] = c.r[1];  // 0608C77C mov r1,r2
    c.r[2] += 56;  // 0608C77E add #56,r2
    st32(c.r[14] + 8, c.r[2]);  // 0608C780 mov.l r2,@(8,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 0608C782 mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[14]);  // 0608C784 mov.l @r14,r2
    c.r[3] = ld32(c.r[2]);  // 0608C786 mov.l @r2,r3
    c.r[1] = ld32(c.r[1] + 60);  // 0608C788 mov.l @(60,r1),r1
    c.r[2] = ld32(c.r[3] + 44);  // 0608C78A mov.l @(44,r3),r2
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[2];  // 0608C78C cmp/ge r2,r1
    if (c.t) { goto L_0608C794; }  // 0608C78E bt 0x0608C794
    goto L_0608C836;  // 0608C790 bra 0x0608C836 ; nop
L_0608C794:
    c.r[1] = ld32(c.r[14] + 8);  // 0608C794 mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 0608C796 mov r1,r2
    c.r[1] += 108;  // 0608C798 add #108,r1
    c.r[2] = ld32(c.r[14]);  // 0608C79A mov.l @r14,r2
    c.r[3] = ld32(c.r[2]);  // 0608C79C mov.l @r2,r3
    c.r[1] = ld32(c.r[1]);  // 0608C79E mov.l @r1,r1
    c.r[2] = ld32(c.r[3] + 48);  // 0608C7A0 mov.l @(48,r3),r2
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[2];  // 0608C7A2 cmp/ge r2,r1
    if (c.t) { goto L_0608C7AA; }  // 0608C7A4 bt 0x0608C7AA
    goto L_0608C836;  // 0608C7A6 bra 0x0608C836 ; nop
L_0608C7AA:
    c.r[8] = ld32(0x0608C850u);  // 0608C7AA mov.l 0x0608C850,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608C7B0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608C7B0u) return; }  // 0608C7AC jsr @r8 ; nop
    st32(c.r[14] + 12, c.r[0]);  // 0608C7B0 mov.l r0,@(12,r14)
    c.r[4] = 0xFu;  // 0608C7B2 mov #15,r4
    c.r[8] = ld32(0x0608C854u);  // 0608C7B4 mov.l 0x0608C854,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608C7BAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608C7BAu) return; }  // 0608C7B6 jsr @r8 ; nop
    c.r[1] = ld32(c.r[14] + 8);  // 0608C7BA mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 0608C7BC mov r1,r2
    c.r[1] += 124;  // 0608C7BE add #124,r1
    c.r[2] = ld32(0x0608C858u);  // 0608C7C0 mov.l 0x0608C858,r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0608C7C2 mov.w @r2,r3
    c.r[2] = 0x1u;  // 0608C7C4 mov #1,r2
    c.r[2] &= c.r[3];  // 0608C7C6 and r3,r2
    c.r[3] = c.r[2] & 0xFFFFu;  // 0608C7C8 extu.w r2,r3
    c.t = (c.r[3] & c.r[3]) == 0;  // 0608C7CA tst r3,r3
    if (c.t) { goto L_0608C7E2; }  // 0608C7CC bt 0x0608C7E2
    c.r[2] = ld32(0x0608C85Cu);  // 0608C7CE mov.l 0x0608C85C,r2
    c.r[3] = ld32(c.r[2]);  // 0608C7D0 mov.l @r2,r3
    c.t = (c.r[3] & c.r[3]) == 0;  // 0608C7D2 tst r3,r3
    if (!c.t) { goto L_0608C7DC; }  // 0608C7D4 bf 0x0608C7DC
    c.r[2] = (uint32_t)(int16_t)ld16(0x0608C844u);  // 0608C7D6 mov.w 0x0608C844,r2
    goto L_0608C7DE;  // 0608C7D8 bra 0x0608C7DE ; nop
L_0608C7DC:
    c.r[2] = (uint32_t)(int16_t)ld16(0x0608C846u);  // 0608C7DC mov.w 0x0608C846,r2
L_0608C7DE:
    goto L_0608C7F2;  // 0608C7DE bra 0x0608C7F2 ; nop
L_0608C7E2:
    c.r[3] = ld32(0x0608C85Cu);  // 0608C7E2 mov.l 0x0608C85C,r3
    c.r[7] = ld32(c.r[3]);  // 0608C7E4 mov.l @r3,r7
    c.t = (c.r[7] & c.r[7]) == 0;  // 0608C7E6 tst r7,r7
    if (!c.t) { goto L_0608C7F0; }  // 0608C7E8 bf 0x0608C7F0
    c.r[2] = (uint32_t)(int16_t)ld16(0x0608C848u);  // 0608C7EA mov.w 0x0608C848,r2
    goto L_0608C7F2;  // 0608C7EC bra 0x0608C7F2 ; nop
L_0608C7F0:
    c.r[2] = (uint32_t)(int16_t)ld16(0x0608C84Au);  // 0608C7F0 mov.w 0x0608C84A,r2
L_0608C7F2:
    st32(c.r[1], c.r[2]);  // 0608C7F2 mov.l r2,@r1
    c.r[4] = ld32(c.r[14]);  // 0608C7F4 mov.l @r14,r4
    c.r[8] = ld32(0x0608C860u);  // 0608C7F6 mov.l 0x0608C860,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608C7FCu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608C7FCu) return; }  // 0608C7F8 jsr @r8 ; nop
    c.r[4] = ld32(c.r[14]);  // 0608C7FC mov.l @r14,r4
    c.r[8] = ld32(0x0608C864u);  // 0608C7FE mov.l 0x0608C864,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608C804u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608C804u) return; }  // 0608C800 jsr @r8 ; nop
    c.r[1] = ld32(c.r[14] + 8);  // 0608C804 mov.l @(8,r14),r1
    c.r[2] = 0x4u;  // 0608C806 mov #4,r2
    st32(c.r[1] + 4, c.r[2]);  // 0608C808 mov.l r2,@(4,r1)
    c.r[2] = ld32(c.r[14] + 8);  // 0608C80A mov.l @(8,r14),r2
    c.r[1] = c.r[2];  // 0608C80C mov r2,r1
    c.r[2] += 100;  // 0608C80E add #100,r2
    c.r[1] = 0x0u;  // 0608C810 mov #0,r1
    st32(c.r[2], c.r[1]);  // 0608C812 mov.l r1,@r2
    c.r[1] = ld32(c.r[14] + 8);  // 0608C814 mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 0608C816 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608C84Cu);  // 0608C818 mov.w 0x0608C84C,r3
    c.r[1] += c.r[3];  // 0608C81A add r3,r1
    c.r[2] = ld32(c.r[14] + 8);  // 0608C81C mov.l @(8,r14),r2
    c.r[3] = c.r[2];  // 0608C81E mov r2,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x0608C84Eu);  // 0608C820 mov.w 0x0608C84E,r7
    c.r[2] += c.r[7];  // 0608C822 add r7,r2
    c.r[3] = ld32(0x0608C868u);  // 0608C824 mov.l 0x0608C868,r3
    c.r[7] = ld32(c.r[3]);  // 0608C826 mov.l @r3,r7
    st32(c.r[2], c.r[7]);  // 0608C828 mov.l r7,@r2
    st32(c.r[1], c.r[7]);  // 0608C82A mov.l r7,@r1
    c.r[1] = ld32(c.r[14] + 12);  // 0608C82C mov.l @(12,r14),r1
    c.r[4] = c.r[1];  // 0608C82E mov r1,r4
    c.r[8] = ld32(0x0608C854u);  // 0608C830 mov.l 0x0608C854,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608C836u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608C836u) return; }  // 0608C832 jsr @r8 ; nop
L_0608C836:
    c.r[14] += 16;  // 0608C836 add #16,r14
    c.r[15] = c.r[14];  // 0608C838 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608C83A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608C83C mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608C83E mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608C840 rts ; nop
}

void f_0608C86C(SH2Context& c) {
    ran[2029] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608C86C mov.l r14,@-r15
    c.r[15] -= 12;  // 0608C86E add #-12,r15
    c.r[14] = c.r[15];  // 0608C870 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608C872 mov.l r4,@r14
    c.r[1] = ld32(c.r[14]);  // 0608C874 mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 0608C876 mov.l @r1,r2
    st32(c.r[14] + 4, c.r[2]);  // 0608C878 mov.l r2,@(4,r14)
    c.r[1] = ld32(c.r[14] + 4);  // 0608C87A mov.l @(4,r14),r1
    c.r[2] = c.r[1];  // 0608C87C mov r1,r2
    c.r[2] += 56;  // 0608C87E add #56,r2
    st32(c.r[14] + 8, c.r[2]);  // 0608C880 mov.l r2,@(8,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 0608C882 mov.l @(8,r14),r1
    c.r[0] = ld32(c.r[1] + 12);  // 0608C884 mov.l @(12,r1),r0
    c.t = c.r[0] == 0x1u;  // 0608C886 cmp/eq #1,r0
    if (!c.t) { goto L_0608C894; }  // 0608C888 bf 0x0608C894
    c.r[0] = 0x1u;  // 0608C88A mov #1,r0
    goto L_0608C89A;  // 0608C88C bra 0x0608C89A ; nop
L_0608C894:
    c.r[0] = 0x0u;  // 0608C894 mov #0,r0
    goto L_0608C89A;  // 0608C896 bra 0x0608C89A ; nop
L_0608C89A:
    c.r[14] += 12;  // 0608C89A add #12,r14
    c.r[15] = c.r[14];  // 0608C89C mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608C89E mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608C8A0 rts ; nop
}

void f_0608C8A4(SH2Context& c) {
    ran[2030] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608C8A4 mov.l r14,@-r15
    c.r[15] -= 16;  // 0608C8A6 add #-16,r15
    c.r[14] = c.r[15];  // 0608C8A8 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608C8AA mov.l r4,@r14
    c.r[2] = c.r[5];  // 0608C8AC mov r5,r2
    c.r[1] = c.r[14];  // 0608C8AE mov r14,r1
    c.r[3] = c.r[14];  // 0608C8B0 mov r14,r3
    c.r[3] += 4;  // 0608C8B2 add #4,r3
    st8(c.r[3], c.r[2]);  // 0608C8B4 mov.b r2,@r3
    c.r[7] = ld32(c.r[14]);  // 0608C8B6 mov.l @r14,r7
    c.r[6] = ld32(c.r[7]);  // 0608C8B8 mov.l @r7,r6
    st32(c.r[14] + 8, c.r[6]);  // 0608C8BA mov.l r6,@(8,r14)
    c.r[7] = ld32(c.r[14] + 8);  // 0608C8BC mov.l @(8,r14),r7
    c.r[6] = c.r[7];  // 0608C8BE mov r7,r6
    c.r[6] += 56;  // 0608C8C0 add #56,r6
    st32(c.r[14] + 12, c.r[6]);  // 0608C8C2 mov.l r6,@(12,r14)
    c.r[7] = c.r[14];  // 0608C8C4 mov r14,r7
    c.r[6] = c.r[14];  // 0608C8C6 mov r14,r6
    c.r[6] += 4;  // 0608C8C8 add #4,r6
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0608C8CA mov.b @r6,r7
    c.r[6] = 0x1u;  // 0608C8CC mov #1,r6
    c.r[6] &= c.r[7];  // 0608C8CE and r7,r6
    c.r[7] = c.r[6] & 0xFFu;  // 0608C8D0 extu.b r6,r7
    c.t = (c.r[7] & c.r[7]) == 0;  // 0608C8D2 tst r7,r7
    if (!c.t) { goto L_0608C8E4; }  // 0608C8D4 bf 0x0608C8E4
    c.r[6] = ld32(c.r[14] + 12);  // 0608C8D6 mov.l @(12,r14),r6
    c.r[7] = c.r[6];  // 0608C8D8 mov r6,r7
    c.r[7] += 24;  // 0608C8DA add #24,r7
    c.r[6] = 0x1u;  // 0608C8DC mov #1,r6
    st32(c.r[7] + 12, c.r[6]);  // 0608C8DE mov.l r6,@(12,r7)
    goto L_0608C8EE;  // 0608C8E0 bra 0x0608C8EE ; nop
L_0608C8E4:
    c.r[6] = ld32(c.r[14] + 12);  // 0608C8E4 mov.l @(12,r14),r6
    c.r[7] = c.r[6];  // 0608C8E6 mov r6,r7
    c.r[7] += 24;  // 0608C8E8 add #24,r7
    c.r[6] = 0x2u;  // 0608C8EA mov #2,r6
    st32(c.r[7] + 12, c.r[6]);  // 0608C8EC mov.l r6,@(12,r7)
L_0608C8EE:
    c.r[7] = c.r[14];  // 0608C8EE mov r14,r7
    c.r[6] = c.r[14];  // 0608C8F0 mov r14,r6
    c.r[6] += 4;  // 0608C8F2 add #4,r6
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0608C8F4 mov.b @r6,r7
    c.r[6] = 0x4u;  // 0608C8F6 mov #4,r6
    c.r[6] &= c.r[7];  // 0608C8F8 and r7,r6
    c.r[7] = c.r[6] & 0xFFu;  // 0608C8FA extu.b r6,r7
    c.t = (c.r[7] & c.r[7]) == 0;  // 0608C8FC tst r7,r7
    if (!c.t) { goto L_0608C90E; }  // 0608C8FE bf 0x0608C90E
    c.r[6] = ld32(c.r[14] + 12);  // 0608C900 mov.l @(12,r14),r6
    c.r[7] = c.r[6];  // 0608C902 mov r6,r7
    c.r[7] += 24;  // 0608C904 add #24,r7
    c.r[6] = ld32(0x0608C92Cu);  // 0608C906 mov.l 0x0608C92C,r6
    st32(c.r[7] + 20, c.r[6]);  // 0608C908 mov.l r6,@(20,r7)
    goto L_0608C918;  // 0608C90A bra 0x0608C918 ; nop
L_0608C90E:
    c.r[6] = ld32(c.r[14] + 12);  // 0608C90E mov.l @(12,r14),r6
    c.r[7] = c.r[6];  // 0608C910 mov r6,r7
    c.r[7] += 24;  // 0608C912 add #24,r7
    c.r[6] = (uint32_t)(int16_t)ld16(0x0608C928u);  // 0608C914 mov.w 0x0608C928,r6
    st32(c.r[7] + 20, c.r[6]);  // 0608C916 mov.l r6,@(20,r7)
L_0608C918:
    c.r[7] = ld32(c.r[14] + 12);  // 0608C918 mov.l @(12,r14),r7
    c.r[6] = 0x0u;  // 0608C91A mov #0,r6
    st32(c.r[7] + 12, c.r[6]);  // 0608C91C mov.l r6,@(12,r7)
    c.r[14] += 16;  // 0608C91E add #16,r14
    c.r[15] = c.r[14];  // 0608C920 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608C922 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608C924 rts ; nop
}

void f_0608C930(SH2Context& c) {
    ran[2031] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608C930 mov.l r14,@-r15
    c.r[15] -= 16;  // 0608C932 add #-16,r15
    c.r[14] = c.r[15];  // 0608C934 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608C936 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 0608C938 mov.l r5,@(4,r14)
    c.r[1] = ld32(c.r[14]);  // 0608C93A mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 0608C93C mov.l @r1,r2
    st32(c.r[14] + 8, c.r[2]);  // 0608C93E mov.l r2,@(8,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 0608C940 mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 0608C942 mov r1,r2
    c.r[2] += 4;  // 0608C944 add #4,r2
    st32(c.r[14] + 12, c.r[2]);  // 0608C946 mov.l r2,@(12,r14)
    c.r[1] = ld32(c.r[14] + 12);  // 0608C948 mov.l @(12,r14),r1
    c.r[2] = ld32(c.r[14] + 4);  // 0608C94A mov.l @(4,r14),r2
    st32(c.r[1] + 32, c.r[2]);  // 0608C94C mov.l r2,@(32,r1)
    c.r[14] += 16;  // 0608C94E add #16,r14
    c.r[15] = c.r[14];  // 0608C950 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608C952 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608C954 rts ; nop
}

void f_0608C958(SH2Context& c) {
    ran[2032] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608C958 mov.l r14,@-r15
    c.r[15] -= 16;  // 0608C95A add #-16,r15
    c.r[14] = c.r[15];  // 0608C95C mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608C95E mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 0608C960 mov.l r5,@(4,r14)
    c.r[1] = ld32(c.r[14]);  // 0608C962 mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 0608C964 mov.l @r1,r2
    st32(c.r[14] + 8, c.r[2]);  // 0608C966 mov.l r2,@(8,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 0608C968 mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 0608C96A mov r1,r2
    c.r[2] += 4;  // 0608C96C add #4,r2
    st32(c.r[14] + 12, c.r[2]);  // 0608C96E mov.l r2,@(12,r14)
    c.r[1] = ld32(c.r[14] + 12);  // 0608C970 mov.l @(12,r14),r1
    c.r[2] = ld32(c.r[14] + 4);  // 0608C972 mov.l @(4,r14),r2
    st32(c.r[1] + 36, c.r[2]);  // 0608C974 mov.l r2,@(36,r1)
    c.r[14] += 16;  // 0608C976 add #16,r14
    c.r[15] = c.r[14];  // 0608C978 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608C97A mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608C97C rts ; nop
}

void f_0608C980(SH2Context& c) {
    ran[2033] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608C980 mov.l r14,@-r15
    c.r[15] -= 16;  // 0608C982 add #-16,r15
    c.r[14] = c.r[15];  // 0608C984 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608C986 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 0608C988 mov.l r5,@(4,r14)
    c.r[1] = ld32(c.r[14]);  // 0608C98A mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 0608C98C mov.l @r1,r2
    st32(c.r[14] + 8, c.r[2]);  // 0608C98E mov.l r2,@(8,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 0608C990 mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 0608C992 mov r1,r2
    c.r[2] += 4;  // 0608C994 add #4,r2
    st32(c.r[14] + 12, c.r[2]);  // 0608C996 mov.l r2,@(12,r14)
    c.r[1] = ld32(c.r[14] + 12);  // 0608C998 mov.l @(12,r14),r1
    c.r[2] = ld32(c.r[14] + 4);  // 0608C99A mov.l @(4,r14),r2
    st32(c.r[1] + 24, c.r[2]);  // 0608C99C mov.l r2,@(24,r1)
    c.r[14] += 16;  // 0608C99E add #16,r14
    c.r[15] = c.r[14];  // 0608C9A0 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608C9A2 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608C9A4 rts ; nop
}

void f_0608C9A8(SH2Context& c) {
    ran[2034] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608C9A8 mov.l r14,@-r15
    c.r[15] -= 20;  // 0608C9AA add #-20,r15
    c.r[14] = c.r[15];  // 0608C9AC mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608C9AE mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 0608C9B0 mov.l r5,@(4,r14)
    st32(c.r[14] + 8, c.r[6]);  // 0608C9B2 mov.l r6,@(8,r14)
    c.r[1] = ld32(c.r[14]);  // 0608C9B4 mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 0608C9B6 mov.l @r1,r2
    st32(c.r[14] + 12, c.r[2]);  // 0608C9B8 mov.l r2,@(12,r14)
    c.r[1] = ld32(c.r[14] + 12);  // 0608C9BA mov.l @(12,r14),r1
    c.r[2] = c.r[1];  // 0608C9BC mov r1,r2
    c.r[2] += 4;  // 0608C9BE add #4,r2
    st32(c.r[14] + 16, c.r[2]);  // 0608C9C0 mov.l r2,@(16,r14)
    c.r[1] = ld32(c.r[14] + 16);  // 0608C9C2 mov.l @(16,r14),r1
    c.r[2] = ld32(c.r[14] + 4);  // 0608C9C4 mov.l @(4,r14),r2
    st32(c.r[1] + 28, c.r[2]);  // 0608C9C6 mov.l r2,@(28,r1)
    c.r[1] = ld32(c.r[14] + 16);  // 0608C9C8 mov.l @(16,r14),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0608C9DCu);  // 0608C9CA mov.w 0x0608C9DC,r2
    c.r[3] = ld32(c.r[14] + 8);  // 0608C9CC mov.l @(8,r14),r3
    c.r[2] -= c.r[3];  // 0608C9CE sub r3,r2
    st32(c.r[1] + 36, c.r[2]);  // 0608C9D0 mov.l r2,@(36,r1)
    c.r[14] += 20;  // 0608C9D2 add #20,r14
    c.r[15] = c.r[14];  // 0608C9D4 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608C9D6 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608C9D8 rts ; nop
}

void f_0608C9E0(SH2Context& c) {
    ran[2035] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608C9E0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608C9E2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608C9E4 sts.l pr,@-r15
    c.r[15] -= 12;  // 0608C9E6 add #-12,r15
    c.r[14] = c.r[15];  // 0608C9E8 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608C9EA mov.l r4,@r14
    c.r[1] = ld32(c.r[14]);  // 0608C9EC mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 0608C9EE mov.l @r1,r2
    st32(c.r[14] + 4, c.r[2]);  // 0608C9F0 mov.l r2,@(4,r14)
    c.r[1] = ld32(c.r[14] + 4);  // 0608C9F2 mov.l @(4,r14),r1
    c.r[2] = c.r[1];  // 0608C9F4 mov r1,r2
    c.r[2] += 56;  // 0608C9F6 add #56,r2
    st32(c.r[14] + 8, c.r[2]);  // 0608C9F8 mov.l r2,@(8,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 0608C9FA mov.l @(8,r14),r1
    c.r[0] = ld32(c.r[1] + 4);  // 0608C9FC mov.l @(4,r1),r0
    c.t = c.r[0] == 0x4u;  // 0608C9FE cmp/eq #4,r0
    if (!c.t) { goto L_0608CA10; }  // 0608CA00 bf 0x0608CA10
    c.r[7] = 0xFFFFFFFFu;  // 0608CA02 mov #-1,r7
    c.r[6] = 0xFFFFFFFFu;  // 0608CA04 mov #-1,r6
    c.r[5] = 0xFFFFFFFFu;  // 0608CA06 mov #-1,r5
    c.r[4] = ld32(c.r[14]);  // 0608CA08 mov.l @r14,r4
    c.r[8] = ld32(0x0608CA20u);  // 0608CA0A mov.l 0x0608CA20,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608CA10u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608CA10u) return; }  // 0608CA0C jsr @r8 ; nop
L_0608CA10:
    c.r[14] += 12;  // 0608CA10 add #12,r14
    c.r[15] = c.r[14];  // 0608CA12 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608CA14 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608CA16 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608CA18 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608CA1A rts ; nop
}

void f_0608CA24(SH2Context& c) {
    ran[2036] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608CA24 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608CA26 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608CA28 sts.l pr,@-r15
    c.r[15] -= 32;  // 0608CA2A add #-32,r15
    c.r[14] = c.r[15];  // 0608CA2C mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608CA2E mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 0608CA30 mov.l r5,@(4,r14)
    c.r[1] = ld32(c.r[14]);  // 0608CA32 mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 0608CA34 mov.l @r1,r2
    st32(c.r[14] + 8, c.r[2]);  // 0608CA36 mov.l r2,@(8,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 0608CA38 mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 0608CA3A mov r1,r2
    c.r[2] += 4;  // 0608CA3C add #4,r2
    st32(c.r[14] + 12, c.r[2]);  // 0608CA3E mov.l r2,@(12,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 0608CA40 mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 0608CA42 mov r1,r2
    c.r[2] += 56;  // 0608CA44 add #56,r2
    st32(c.r[14] + 16, c.r[2]);  // 0608CA46 mov.l r2,@(16,r14)
    c.r[1] = ld32(c.r[14] + 4);  // 0608CA48 mov.l @(4,r14),r1
    c.r[2] = ld32(c.r[1]);  // 0608CA4A mov.l @r1,r2
    st32(c.r[14] + 20, c.r[2]);  // 0608CA4C mov.l r2,@(20,r14)
    c.r[1] = ld32(c.r[14] + 20);  // 0608CA4E mov.l @(20,r14),r1
    c.r[2] = c.r[1];  // 0608CA50 mov r1,r2
    c.r[2] += 4;  // 0608CA52 add #4,r2
    st32(c.r[14] + 24, c.r[2]);  // 0608CA54 mov.l r2,@(24,r14)
    c.r[1] = ld32(c.r[14] + 20);  // 0608CA56 mov.l @(20,r14),r1
    c.r[2] = c.r[1];  // 0608CA58 mov r1,r2
    c.r[2] += 56;  // 0608CA5A add #56,r2
    st32(c.r[14] + 28, c.r[2]);  // 0608CA5C mov.l r2,@(28,r14)
    c.r[1] = ld32(c.r[14] + 28);  // 0608CA5E mov.l @(28,r14),r1
    c.r[2] = ld32(c.r[1] + 4);  // 0608CA60 mov.l @(4,r1),r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0608CA62 tst r2,r2
    if (c.t) { goto L_0608CA76; }  // 0608CA64 bt 0x0608CA76
    c.r[1] = (uint32_t)(int16_t)ld16(0x0608CBB4u);  // 0608CA66 mov.w 0x0608CBB4,r1
    c.r[4] = c.r[1];  // 0608CA68 mov r1,r4
    c.r[8] = ld32(0x0608CBBCu);  // 0608CA6A mov.l 0x0608CBBC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608CA70u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608CA70u) return; }  // 0608CA6C jsr @r8 ; nop
    c.r[0] = 0xFFFFFFFFu;  // 0608CA70 mov #-1,r0
    goto L_0608CBA6;  // 0608CA72 bra 0x0608CBA6 ; nop
L_0608CA76:
    c.r[1] = ld32(c.r[14] + 4);  // 0608CA76 mov.l @(4,r14),r1
    c.r[4] = c.r[1];  // 0608CA78 mov r1,r4
    c.r[8] = ld32(0x0608CBC0u);  // 0608CA7A mov.l 0x0608CBC0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608CA80u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608CA80u) return; }  // 0608CA7C jsr @r8 ; nop
    c.r[1] = ld32(c.r[14] + 4);  // 0608CA80 mov.l @(4,r14),r1
    c.r[4] = c.r[1];  // 0608CA82 mov r1,r4
    c.r[8] = ld32(0x0608CBC4u);  // 0608CA84 mov.l 0x0608CBC4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608CA8Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608CA8Au) return; }  // 0608CA86 jsr @r8 ; nop
    c.t = (c.r[0] & c.r[0]) == 0;  // 0608CA8A tst r0,r0
    if (c.t) { goto L_0608CA94; }  // 0608CA8C bt 0x0608CA94
    c.r[0] = 0xFFFFFFFFu;  // 0608CA8E mov #-1,r0
    goto L_0608CBA6;  // 0608CA90 bra 0x0608CBA6 ; nop
L_0608CA94:
    c.r[1] = ld32(c.r[14] + 12);  // 0608CA94 mov.l @(12,r14),r1
    c.r[2] = ld32(c.r[14] + 24);  // 0608CA96 mov.l @(24,r14),r2
    c.r[1] = ld32(c.r[1] + 20);  // 0608CA98 mov.l @(20,r1),r1
    c.r[2] = ld32(c.r[2] + 20);  // 0608CA9A mov.l @(20,r2),r2
    c.t = c.r[1] == c.r[2];  // 0608CA9C cmp/eq r2,r1
    if (!c.t) { goto L_0608CAE0; }  // 0608CA9E bf 0x0608CAE0
    c.r[1] = ld32(c.r[14] + 12);  // 0608CAA0 mov.l @(12,r14),r1
    c.r[2] = ld32(c.r[14] + 24);  // 0608CAA2 mov.l @(24,r14),r2
    c.r[1] = ld32(c.r[1] + 8);  // 0608CAA4 mov.l @(8,r1),r1
    c.r[2] = ld32(c.r[2] + 8);  // 0608CAA6 mov.l @(8,r2),r2
    c.t = c.r[1] == c.r[2];  // 0608CAA8 cmp/eq r2,r1
    if (!c.t) { goto L_0608CAE0; }  // 0608CAAA bf 0x0608CAE0
    c.r[1] = ld32(c.r[14] + 12);  // 0608CAAC mov.l @(12,r14),r1
    c.r[2] = ld32(c.r[14] + 24);  // 0608CAAE mov.l @(24,r14),r2
    c.r[1] = ld32(c.r[1] + 12);  // 0608CAB0 mov.l @(12,r1),r1
    c.r[2] = ld32(c.r[2] + 12);  // 0608CAB2 mov.l @(12,r2),r2
    c.t = c.r[1] == c.r[2];  // 0608CAB4 cmp/eq r2,r1
    if (!c.t) { goto L_0608CAE0; }  // 0608CAB6 bf 0x0608CAE0
    c.r[1] = ld32(c.r[14] + 16);  // 0608CAB8 mov.l @(16,r14),r1
    c.r[2] = ld32(c.r[14] + 28);  // 0608CABA mov.l @(28,r14),r2
    c.r[1] = ld32(c.r[1] + 36);  // 0608CABC mov.l @(36,r1),r1
    c.r[2] = ld32(c.r[2] + 36);  // 0608CABE mov.l @(36,r2),r2
    c.t = c.r[1] == c.r[2];  // 0608CAC0 cmp/eq r2,r1
    if (!c.t) { goto L_0608CAE0; }  // 0608CAC2 bf 0x0608CAE0
    c.r[1] = ld32(c.r[14] + 16);  // 0608CAC4 mov.l @(16,r14),r1
    c.r[2] = ld32(c.r[14] + 28);  // 0608CAC6 mov.l @(28,r14),r2
    c.r[1] = ld32(c.r[1] + 40);  // 0608CAC8 mov.l @(40,r1),r1
    c.r[2] = ld32(c.r[2] + 40);  // 0608CACA mov.l @(40,r2),r2
    c.t = c.r[1] == c.r[2];  // 0608CACC cmp/eq r2,r1
    if (!c.t) { goto L_0608CAE0; }  // 0608CACE bf 0x0608CAE0
    c.r[1] = ld32(c.r[14] + 16);  // 0608CAD0 mov.l @(16,r14),r1
    c.r[2] = ld32(c.r[14] + 28);  // 0608CAD2 mov.l @(28,r14),r2
    c.r[1] = ld32(c.r[1] + 44);  // 0608CAD4 mov.l @(44,r1),r1
    c.r[2] = ld32(c.r[2] + 44);  // 0608CAD6 mov.l @(44,r2),r2
    c.t = c.r[1] == c.r[2];  // 0608CAD8 cmp/eq r2,r1
    if (!c.t) { goto L_0608CAE0; }  // 0608CADA bf 0x0608CAE0
    goto L_0608CAF0;  // 0608CADC bra 0x0608CAF0 ; nop
L_0608CAE0:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0608CBB6u);  // 0608CAE0 mov.w 0x0608CBB6,r1
    c.r[4] = c.r[1];  // 0608CAE2 mov r1,r4
    c.r[8] = ld32(0x0608CBBCu);  // 0608CAE4 mov.l 0x0608CBBC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608CAEAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608CAEAu) return; }  // 0608CAE6 jsr @r8 ; nop
    c.r[0] = 0xFFFFFFFFu;  // 0608CAEA mov #-1,r0
    goto L_0608CBA6;  // 0608CAEC bra 0x0608CBA6 ; nop
L_0608CAF0:
    c.r[1] = ld32(c.r[14] + 24);  // 0608CAF0 mov.l @(24,r14),r1
    c.r[2] = ld32(c.r[14] + 12);  // 0608CAF2 mov.l @(12,r14),r2
    c.r[3] = ld32(c.r[2] + 24);  // 0608CAF4 mov.l @(24,r2),r3
    st32(c.r[1] + 24, c.r[3]);  // 0608CAF6 mov.l r3,@(24,r1)
    c.r[1] = ld32(c.r[14] + 24);  // 0608CAF8 mov.l @(24,r14),r1
    c.r[2] = ld32(c.r[14] + 12);  // 0608CAFA mov.l @(12,r14),r2
    c.r[3] = ld32(c.r[2] + 28);  // 0608CAFC mov.l @(28,r2),r3
    st32(c.r[1] + 28, c.r[3]);  // 0608CAFE mov.l r3,@(28,r1)
    c.r[1] = ld32(c.r[14] + 24);  // 0608CB00 mov.l @(24,r14),r1
    c.r[2] = ld32(c.r[14] + 12);  // 0608CB02 mov.l @(12,r14),r2
    c.r[3] = ld32(c.r[2] + 32);  // 0608CB04 mov.l @(32,r2),r3
    st32(c.r[1] + 32, c.r[3]);  // 0608CB06 mov.l r3,@(32,r1)
    c.r[1] = ld32(c.r[14] + 28);  // 0608CB08 mov.l @(28,r14),r1
    c.r[2] = c.r[1];  // 0608CB0A mov r1,r2
    c.r[1] += 96;  // 0608CB0C add #96,r1
    c.r[3] = ld32(c.r[14] + 16);  // 0608CB0E mov.l @(16,r14),r3
    c.r[2] = c.r[3];  // 0608CB10 mov r3,r2
    c.r[3] += 96;  // 0608CB12 add #96,r3
    c.r[2] = ld32(c.r[3]);  // 0608CB14 mov.l @r3,r2
    st32(c.r[1], c.r[2]);  // 0608CB16 mov.l r2,@r1
    c.r[1] = ld32(c.r[14] + 28);  // 0608CB18 mov.l @(28,r14),r1
    c.r[2] = c.r[1];  // 0608CB1A mov r1,r2
    c.r[1] += 108;  // 0608CB1C add #108,r1
    c.r[3] = ld32(c.r[14] + 16);  // 0608CB1E mov.l @(16,r14),r3
    c.r[2] = c.r[3];  // 0608CB20 mov r3,r2
    c.r[3] += 108;  // 0608CB22 add #108,r3
    c.r[2] = ld32(c.r[3]);  // 0608CB24 mov.l @r3,r2
    st32(c.r[1], c.r[2]);  // 0608CB26 mov.l r2,@r1
    c.r[1] = ld32(c.r[14] + 28);  // 0608CB28 mov.l @(28,r14),r1
    c.r[2] = c.r[1];  // 0608CB2A mov r1,r2
    c.r[1] += 116;  // 0608CB2C add #116,r1
    c.r[3] = ld32(c.r[14] + 16);  // 0608CB2E mov.l @(16,r14),r3
    c.r[2] = c.r[3];  // 0608CB30 mov r3,r2
    c.r[3] += 116;  // 0608CB32 add #116,r3
    c.r[2] = ld32(c.r[3]);  // 0608CB34 mov.l @r3,r2
    st32(c.r[1], c.r[2]);  // 0608CB36 mov.l r2,@r1
    c.r[1] = ld32(c.r[14] + 28);  // 0608CB38 mov.l @(28,r14),r1
    c.r[2] = c.r[1];  // 0608CB3A mov r1,r2
    c.r[1] += 112;  // 0608CB3C add #112,r1
    c.r[3] = ld32(c.r[14] + 28);  // 0608CB3E mov.l @(28,r14),r3
    c.r[2] = c.r[3];  // 0608CB40 mov r3,r2
    c.r[3] += 108;  // 0608CB42 add #108,r3
    c.r[2] = ld32(c.r[3]);  // 0608CB44 mov.l @r3,r2
    st32(c.r[1], c.r[2]);  // 0608CB46 mov.l r2,@r1
    c.r[1] = ld32(c.r[14] + 28);  // 0608CB48 mov.l @(28,r14),r1
    c.r[2] = c.r[1];  // 0608CB4A mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608CBB8u);  // 0608CB4C mov.w 0x0608CBB8,r3
    c.r[1] += c.r[3];  // 0608CB4E add r3,r1
    c.r[2] = ld32(0x0608CBC8u);  // 0608CB50 mov.l 0x0608CBC8,r2
    c.r[3] = ld32(c.r[2]);  // 0608CB52 mov.l @r2,r3
    st32(c.r[1], c.r[3]);  // 0608CB54 mov.l r3,@r1
    c.r[1] = ld32(c.r[14] + 28);  // 0608CB56 mov.l @(28,r14),r1
    c.r[2] = c.r[1];  // 0608CB58 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608CBBAu);  // 0608CB5A mov.w 0x0608CBBA,r3
    c.r[1] += c.r[3];  // 0608CB5C add r3,r1
    c.r[2] = ld32(c.r[14] + 16);  // 0608CB5E mov.l @(16,r14),r2
    c.r[3] = c.r[2];  // 0608CB60 mov r2,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x0608CBBAu);  // 0608CB62 mov.w 0x0608CBBA,r7
    c.r[2] += c.r[7];  // 0608CB64 add r7,r2
    c.r[3] = ld32(c.r[2]);  // 0608CB66 mov.l @r2,r3
    st32(c.r[1], c.r[3]);  // 0608CB68 mov.l r3,@r1
    c.r[1] = ld32(c.r[14] + 28);  // 0608CB6A mov.l @(28,r14),r1
    c.r[2] = c.r[1];  // 0608CB6C mov r1,r2
    c.r[1] += 100;  // 0608CB6E add #100,r1
    c.r[3] = ld32(c.r[14] + 16);  // 0608CB70 mov.l @(16,r14),r3
    c.r[2] = c.r[3];  // 0608CB72 mov r3,r2
    c.r[3] += 100;  // 0608CB74 add #100,r3
    c.r[2] = ld32(c.r[3]);  // 0608CB76 mov.l @r3,r2
    st32(c.r[1], c.r[2]);  // 0608CB78 mov.l r2,@r1
    c.r[1] = ld32(c.r[14] + 28);  // 0608CB7A mov.l @(28,r14),r1
    c.r[2] = c.r[1];  // 0608CB7C mov r1,r2
    c.r[1] += 120;  // 0608CB7E add #120,r1
    c.r[3] = ld32(c.r[14] + 16);  // 0608CB80 mov.l @(16,r14),r3
    c.r[2] = c.r[3];  // 0608CB82 mov r3,r2
    c.r[3] += 120;  // 0608CB84 add #120,r3
    c.r[2] = ld32(c.r[3]);  // 0608CB86 mov.l @r3,r2
    st32(c.r[1], c.r[2]);  // 0608CB88 mov.l r2,@r1
    c.r[1] = ld32(c.r[14] + 28);  // 0608CB8A mov.l @(28,r14),r1
    c.r[2] = c.r[1];  // 0608CB8C mov r1,r2
    c.r[1] += 124;  // 0608CB8E add #124,r1
    c.r[3] = ld32(c.r[14] + 16);  // 0608CB90 mov.l @(16,r14),r3
    c.r[2] = c.r[3];  // 0608CB92 mov r3,r2
    c.r[3] += 124;  // 0608CB94 add #124,r3
    c.r[2] = ld32(c.r[3]);  // 0608CB96 mov.l @r3,r2
    st32(c.r[1], c.r[2]);  // 0608CB98 mov.l r2,@r1
    c.r[1] = ld32(c.r[14] + 28);  // 0608CB9A mov.l @(28,r14),r1
    c.r[2] = 0x4u;  // 0608CB9C mov #4,r2
    st32(c.r[1] + 4, c.r[2]);  // 0608CB9E mov.l r2,@(4,r1)
    c.r[0] = 0x0u;  // 0608CBA0 mov #0,r0
    goto L_0608CBA6;  // 0608CBA2 bra 0x0608CBA6 ; nop
L_0608CBA6:
    c.r[14] += 32;  // 0608CBA6 add #32,r14
    c.r[15] = c.r[14];  // 0608CBA8 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608CBAA lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608CBAC mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608CBAE mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608CBB0 rts ; nop
}

void f_0608CBCC(SH2Context& c) {
    ran[2037] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608CBCC mov.l r14,@-r15
    c.r[15] -= 16;  // 0608CBCE add #-16,r15
    c.r[14] = c.r[15];  // 0608CBD0 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608CBD2 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 0608CBD4 mov.l r5,@(4,r14)
    c.r[1] = ld32(c.r[14]);  // 0608CBD6 mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 0608CBD8 mov.l @r1,r2
    st32(c.r[14] + 8, c.r[2]);  // 0608CBDA mov.l r2,@(8,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 0608CBDC mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 0608CBDE mov r1,r2
    c.r[2] += 56;  // 0608CBE0 add #56,r2
    st32(c.r[14] + 12, c.r[2]);  // 0608CBE2 mov.l r2,@(12,r14)
    c.r[1] = ld32(c.r[14] + 12);  // 0608CBE4 mov.l @(12,r14),r1
    c.r[2] = ld32(c.r[14] + 4);  // 0608CBE6 mov.l @(4,r14),r2
    st32(c.r[1] + 16, c.r[2]);  // 0608CBE8 mov.l r2,@(16,r1)
    c.r[14] += 16;  // 0608CBEA add #16,r14
    c.r[15] = c.r[14];  // 0608CBEC mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608CBEE mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608CBF0 rts ; nop
}

void f_0608CBF4(SH2Context& c) {
    ran[2038] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608CBF4 mov.l r14,@-r15
    c.r[15] -= 4;  // 0608CBF6 add #-4,r15
    c.r[14] = c.r[15];  // 0608CBF8 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608CBFA mov.l r4,@r14
    c.r[1] = ld32(0x0608CC0Cu);  // 0608CBFC mov.l 0x0608CC0C,r1
    c.r[2] = ld32(c.r[14]);  // 0608CBFE mov.l @r14,r2
    st32(c.r[1], c.r[2]);  // 0608CC00 mov.l r2,@r1
    c.r[14] += 4;  // 0608CC02 add #4,r14
    c.r[15] = c.r[14];  // 0608CC04 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608CC06 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608CC08 rts ; nop
}

void f_0608CC10(SH2Context& c) {
    ran[2039] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608CC10 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0608CC12 mov r15,r14
    c.r[1] = ld32(0x0608CC24u);  // 0608CC14 mov.l 0x0608CC24,r1
    c.r[0] = ld32(c.r[1]);  // 0608CC16 mov.l @r1,r0
    goto L_0608CC1C;  // 0608CC18 bra 0x0608CC1C ; nop
L_0608CC1C:
    c.r[15] = c.r[14];  // 0608CC1C mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608CC1E mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608CC20 rts ; nop
}

void f_0608CC28(SH2Context& c) {
    ran[2040] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608CC28 mov.l r14,@-r15
    c.r[15] -= 12;  // 0608CC2A add #-12,r15
    c.r[14] = c.r[15];  // 0608CC2C mov r15,r14
    c.r[1] = ld32(0x0608CC8Cu);  // 0608CC2E mov.l 0x0608CC8C,r1
    c.r[2] = ld32(c.r[1]);  // 0608CC30 mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0608CC32 tst r2,r2
    if (!c.t) { goto L_0608CC3C; }  // 0608CC34 bf 0x0608CC3C
    c.r[0] = 0x2u;  // 0608CC36 mov #2,r0
    goto L_0608CC80;  // 0608CC38 bra 0x0608CC80 ; nop
L_0608CC3C:
    c.r[2] = ld32(0x0608CC8Cu);  // 0608CC3C mov.l 0x0608CC8C,r2
    c.r[1] = ld32(c.r[2]);  // 0608CC3E mov.l @r2,r1
    c.r[2] = ld32(c.r[1]);  // 0608CC40 mov.l @r1,r2
    st32(c.r[14], c.r[2]);  // 0608CC42 mov.l r2,@r14
    c.r[1] = ld32(c.r[14]);  // 0608CC44 mov.l @r14,r1
    c.r[2] = c.r[1];  // 0608CC46 mov r1,r2
    c.r[2] += 56;  // 0608CC48 add #56,r2
    st32(c.r[14] + 8, c.r[2]);  // 0608CC4A mov.l r2,@(8,r14)
    c.r[1] = ld32(c.r[14]);  // 0608CC4C mov.l @r14,r1
    c.r[2] = c.r[1];  // 0608CC4E mov r1,r2
    c.r[2] += 4;  // 0608CC50 add #4,r2
    st32(c.r[14] + 4, c.r[2]);  // 0608CC52 mov.l r2,@(4,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 0608CC54 mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[1] + 60);  // 0608CC56 mov.l @(60,r1),r2
    c.t = (int32_t)c.r[2] > 0;  // 0608CC58 cmp/pl r2
    if (!c.t) { goto L_0608CC70; }  // 0608CC5A bf 0x0608CC70
    c.r[1] = ld32(c.r[14] + 8);  // 0608CC5C mov.l @(8,r14),r1
    c.r[3] = ld32(0x0608CC8Cu);  // 0608CC5E mov.l 0x0608CC8C,r3
    c.r[2] = ld32(c.r[3]);  // 0608CC60 mov.l @r3,r2
    c.r[3] = ld32(c.r[2]);  // 0608CC62 mov.l @r2,r3
    c.r[1] = ld32(c.r[1] + 60);  // 0608CC64 mov.l @(60,r1),r1
    c.r[2] = ld32(c.r[3] + 44);  // 0608CC66 mov.l @(44,r3),r2
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[2];  // 0608CC68 cmp/ge r2,r1
    if (!c.t) { goto L_0608CC70; }  // 0608CC6A bf 0x0608CC70
    goto L_0608CC7A;  // 0608CC6C bra 0x0608CC7A ; nop
L_0608CC70:
    c.r[0] = 0x1u;  // 0608CC70 mov #1,r0
    goto L_0608CC80;  // 0608CC72 bra 0x0608CC80 ; nop
L_0608CC7A:
    c.r[0] = 0x0u;  // 0608CC7A mov #0,r0
    goto L_0608CC80;  // 0608CC7C bra 0x0608CC80 ; nop
L_0608CC80:
    c.r[14] += 12;  // 0608CC80 add #12,r14
    c.r[15] = c.r[14];  // 0608CC82 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608CC84 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608CC86 rts ; nop
}

void f_0608CC90(SH2Context& c) {
    ran[2041] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608CC90 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608CC92 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608CC94 sts.l pr,@-r15
    c.r[15] -= 4;  // 0608CC96 add #-4,r15
    c.r[14] = c.r[15];  // 0608CC98 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608CC9A mov.l r4,@r14
    c.r[1] = ld32(c.r[14]);  // 0608CC9C mov.l @r14,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0608CC9E tst r1,r1
    if (c.t) { goto L_0608CCB4; }  // 0608CCA0 bt 0x0608CCB4
    c.r[4] = ld32(c.r[14]);  // 0608CCA2 mov.l @r14,r4
    c.r[8] = ld32(0x0608CCD4u);  // 0608CCA4 mov.l 0x0608CCD4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608CCAAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608CCAAu) return; }  // 0608CCA6 jsr @r8 ; nop
    c.r[5] = 0x0u;  // 0608CCAA mov #0,r5
    c.r[4] = ld32(c.r[14]);  // 0608CCAC mov.l @r14,r4
    c.r[8] = ld32(0x0608CCD8u);  // 0608CCAE mov.l 0x0608CCD8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608CCB4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608CCB4u) return; }  // 0608CCB0 jsr @r8 ; nop
L_0608CCB4:
    c.r[1] = ld32(0x0608CCDCu);  // 0608CCB4 mov.l 0x0608CCDC,r1
    c.r[2] = ld32(c.r[1]);  // 0608CCB6 mov.l @r1,r2
    c.r[4] = c.r[2];  // 0608CCB8 mov r2,r4
    c.r[8] = ld32(0x0608CCE0u);  // 0608CCBA mov.l 0x0608CCE0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608CCC0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608CCC0u) return; }  // 0608CCBC jsr @r8 ; nop
    c.r[1] = ld32(0x0608CCDCu);  // 0608CCC0 mov.l 0x0608CCDC,r1
    c.r[2] = 0x0u;  // 0608CCC2 mov #0,r2
    st32(c.r[1], c.r[2]);  // 0608CCC4 mov.l r2,@r1
    c.r[14] += 4;  // 0608CCC6 add #4,r14
    c.r[15] = c.r[14];  // 0608CCC8 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608CCCA lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608CCCC mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608CCCE mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608CCD0 rts ; nop
}

void f_0608CCE4(SH2Context& c) {
    ran[2042] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608CCE4 mov.l r14,@-r15
    c.r[15] -= 4;  // 0608CCE6 add #-4,r15
    c.r[14] = c.r[15];  // 0608CCE8 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608CCEA mov.l r4,@r14
    c.r[1] = ld32(0x0608CD2Cu);  // 0608CCEC mov.l 0x0608CD2C,r1
    c.r[2] = ld32(c.r[14]);  // 0608CCEE mov.l @r14,r2
    c.r[3] = c.r[2];  // 0608CCF0 mov r2,r3
    c.r[2] = c.r[3];  // 0608CCF2 mov r3,r2
    c.r[2] <<= 2;  // 0608CCF4 shll2 r2
    c.r[3] = ld32(0x0608CD30u);  // 0608CCF6 mov.l 0x0608CD30,r3
    c.r[2] += c.r[3];  // 0608CCF8 add r3,r2
    c.r[1] = ld32(c.r[1]);  // 0608CCFA mov.l @r1,r1
    c.r[2] = ld32(c.r[2]);  // 0608CCFC mov.l @r2,r2
    c.r[1] &= c.r[2];  // 0608CCFE and r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0608CD00 tst r1,r1
    if (c.t) { goto L_0608CD1A; }  // 0608CD02 bt 0x0608CD1A
    c.r[1] = ld32(c.r[14]);  // 0608CD04 mov.l @r14,r1
    c.r[2] = c.r[1];  // 0608CD06 mov r1,r2
    c.r[1] = c.r[2];  // 0608CD08 mov r2,r1
    c.r[1] <<= 2;  // 0608CD0A shll2 r1
    c.r[2] = ld32(0x0608CD34u);  // 0608CD0C mov.l 0x0608CD34,r2
    c.r[1] += c.r[2];  // 0608CD0E add r2,r1
    c.r[0] = c.r[1];  // 0608CD10 mov r1,r0
    goto L_0608CD20;  // 0608CD12 bra 0x0608CD20 ; nop
L_0608CD1A:
    c.r[0] = 0x0u;  // 0608CD1A mov #0,r0
    goto L_0608CD20;  // 0608CD1C bra 0x0608CD20 ; nop
L_0608CD20:
    c.r[14] += 4;  // 0608CD20 add #4,r14
    c.r[15] = c.r[14];  // 0608CD22 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608CD24 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608CD26 rts ; nop
}

void f_0608CD38(SH2Context& c) {
    ran[2043] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608CD38 mov.l r14,@-r15
    c.r[15] -= 4;  // 0608CD3A add #-4,r15
    c.r[14] = c.r[15];  // 0608CD3C mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608CD3E mov.l r4,@r14
    c.r[1] = ld32(c.r[14]);  // 0608CD40 mov.l @r14,r1
    c.r[3] = ld32(0x0608CD60u);  // 0608CD42 mov.l 0x0608CD60,r3
    c.r[2] = c.r[1];  // 0608CD44 mov r1,r2
    c.r[2] -= c.r[3];  // 0608CD46 sub r3,r2
    c.r[1] = c.r[2];  // 0608CD48 mov r2,r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0608CD4A shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0608CD4C shar r1
    c.r[2] = c.r[1];  // 0608CD4E mov r1,r2
    c.r[0] = c.r[2];  // 0608CD50 mov r2,r0
    goto L_0608CD56;  // 0608CD52 bra 0x0608CD56 ; nop
L_0608CD56:
    c.r[14] += 4;  // 0608CD56 add #4,r14
    c.r[15] = c.r[14];  // 0608CD58 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608CD5A mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608CD5C rts ; nop
}

void f_0608CD64(SH2Context& c) {
    ran[2044] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608CD64 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608CD66 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608CD68 sts.l pr,@-r15
    c.r[15] -= 12;  // 0608CD6A add #-12,r15
    c.r[14] = c.r[15];  // 0608CD6C mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608CD6E mov.l r4,@r14
    c.r[1] = ld32(c.r[14]);  // 0608CD70 mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 0608CD72 mov.l @r1,r2
    st32(c.r[14] + 4, c.r[2]);  // 0608CD74 mov.l r2,@(4,r14)
    c.r[1] = ld32(c.r[14] + 4);  // 0608CD76 mov.l @(4,r14),r1
    c.r[2] = c.r[1];  // 0608CD78 mov r1,r2
    c.r[2] += 56;  // 0608CD7A add #56,r2
    st32(c.r[14] + 8, c.r[2]);  // 0608CD7C mov.l r2,@(8,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 0608CD7E mov.l @(8,r14),r1
    c.r[0] = ld32(c.r[1] + 48);  // 0608CD80 mov.l @(48,r1),r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0608CD82 cmp/eq #-1,r0
    if (c.t) { goto L_0608CD96; }  // 0608CD84 bt 0x0608CD96
    c.r[1] = ld32(c.r[14] + 8);  // 0608CD86 mov.l @(8,r14),r1
    c.r[3] = ld32(c.r[14] + 8);  // 0608CD88 mov.l @(8,r14),r3
    c.r[2] = c.r[3];  // 0608CD8A mov r3,r2
    c.r[3] += 104;  // 0608CD8C add #104,r3
    c.r[1] = ld32(c.r[1] + 48);  // 0608CD8E mov.l @(48,r1),r1
    c.r[2] = ld32(c.r[3]);  // 0608CD90 mov.l @r3,r2
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 0608CD92 cmp/gt r2,r1
    if (!c.t) { goto L_0608CD96; }  // 0608CD94 bf 0x0608CD96
L_0608CD96:
    c.r[1] = ld32(0x0608CDE8u);  // 0608CD96 mov.l 0x0608CDE8,r1
    c.r[2] = ld32(c.r[1]);  // 0608CD98 mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0608CD9A tst r2,r2
    if (c.t) { goto L_0608CDB4; }  // 0608CD9C bt 0x0608CDB4
    c.r[1] = ld32(0x0608CDE8u);  // 0608CD9E mov.l 0x0608CDE8,r1
    c.r[2] = ld32(c.r[1]);  // 0608CDA0 mov.l @r1,r2
    c.r[5] = c.r[2];  // 0608CDA2 mov r2,r5
    c.r[4] = ld32(c.r[14]);  // 0608CDA4 mov.l @r14,r4
    c.r[8] = ld32(0x0608CDECu);  // 0608CDA6 mov.l 0x0608CDEC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608CDACu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608CDACu) return; }  // 0608CDA8 jsr @r8 ; nop
    c.t = (c.r[0] & c.r[0]) == 0;  // 0608CDAC tst r0,r0
    if (!c.t) { goto L_0608CDB4; }  // 0608CDAE bf 0x0608CDB4
    goto L_0608CDBC;  // 0608CDB0 bra 0x0608CDBC ; nop
L_0608CDB4:
    c.r[4] = ld32(c.r[14]);  // 0608CDB4 mov.l @r14,r4
    c.r[8] = ld32(0x0608CDF0u);  // 0608CDB6 mov.l 0x0608CDF0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608CDBCu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608CDBCu) return; }  // 0608CDB8 jsr @r8 ; nop
L_0608CDBC:
    c.r[1] = ld32(0x0608CDE8u);  // 0608CDBC mov.l 0x0608CDE8,r1
    c.r[2] = ld32(c.r[1]);  // 0608CDBE mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0608CDC0 tst r2,r2
    if (c.t) { goto L_0608CDD4; }  // 0608CDC2 bt 0x0608CDD4
    c.r[1] = ld32(0x0608CDE8u);  // 0608CDC4 mov.l 0x0608CDE8,r1
    c.r[2] = 0x0u;  // 0608CDC6 mov #0,r2
    st32(c.r[1], c.r[2]);  // 0608CDC8 mov.l r2,@r1
    c.r[5] = 0x0u;  // 0608CDCA mov #0,r5
    c.r[4] = ld32(c.r[14]);  // 0608CDCC mov.l @r14,r4
    c.r[8] = ld32(0x0608CDF4u);  // 0608CDCE mov.l 0x0608CDF4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608CDD4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608CDD4u) return; }  // 0608CDD0 jsr @r8 ; nop
L_0608CDD4:
    c.r[1] = ld32(c.r[14] + 8);  // 0608CDD4 mov.l @(8,r14),r1
    c.r[2] = 0x5u;  // 0608CDD6 mov #5,r2
    st32(c.r[1] + 4, c.r[2]);  // 0608CDD8 mov.l r2,@(4,r1)
    c.r[14] += 12;  // 0608CDDA add #12,r14
    c.r[15] = c.r[14];  // 0608CDDC mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608CDDE lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608CDE0 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608CDE2 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608CDE4 rts ; nop
}

void f_0608CDF8(SH2Context& c) {
    ran[2045] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608CDF8 mov.l r14,@-r15
    c.r[15] -= 16;  // 0608CDFA add #-16,r15
    c.r[14] = c.r[15];  // 0608CDFC mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608CDFE mov.l r4,@r14
    c.r[1] = ld32(c.r[14]);  // 0608CE00 mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 0608CE02 mov.l @r1,r2
    st32(c.r[14] + 4, c.r[2]);  // 0608CE04 mov.l r2,@(4,r14)
    c.r[1] = ld32(c.r[14] + 4);  // 0608CE06 mov.l @(4,r14),r1
    c.r[2] = c.r[1];  // 0608CE08 mov r1,r2
    c.r[2] += 56;  // 0608CE0A add #56,r2
    st32(c.r[14] + 8, c.r[2]);  // 0608CE0C mov.l r2,@(8,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 0608CE0E mov.l @(8,r14),r1
    c.r[3] = ld32(c.r[14] + 8);  // 0608CE10 mov.l @(8,r14),r3
    c.r[2] = c.r[3];  // 0608CE12 mov r3,r2
    c.r[3] += 64;  // 0608CE14 add #64,r3
    c.r[1] = ld32(c.r[1] + 60);  // 0608CE16 mov.l @(60,r1),r1
    c.r[2] = ld32(c.r[3]);  // 0608CE18 mov.l @r3,r2
    c.r[1] -= c.r[2];  // 0608CE1A sub r2,r1
    st32(c.r[14] + 12, c.r[1]);  // 0608CE1C mov.l r1,@(12,r14)
    c.r[1] = ld32(c.r[14] + 12);  // 0608CE1E mov.l @(12,r14),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0608CE20 tst r1,r1
    if (!c.t) { goto L_0608CE2A; }  // 0608CE22 bf 0x0608CE2A
    c.r[0] = 0x1u;  // 0608CE24 mov #1,r0
    goto L_0608CE4E;  // 0608CE26 bra 0x0608CE4E ; nop
L_0608CE2A:
    c.r[1] = ld32(c.r[14] + 8);  // 0608CE2A mov.l @(8,r14),r1
    c.r[0] = ld32(c.r[1] + 48);  // 0608CE2C mov.l @(48,r1),r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0608CE2E cmp/eq #-1,r0
    if (c.t) { goto L_0608CE48; }  // 0608CE30 bt 0x0608CE48
    c.r[1] = ld32(c.r[14] + 8);  // 0608CE32 mov.l @(8,r14),r1
    c.r[3] = ld32(c.r[14] + 8);  // 0608CE34 mov.l @(8,r14),r3
    c.r[2] = c.r[3];  // 0608CE36 mov r3,r2
    c.r[3] += 104;  // 0608CE38 add #104,r3
    c.r[1] = ld32(c.r[1] + 48);  // 0608CE3A mov.l @(48,r1),r1
    c.r[2] = ld32(c.r[3]);  // 0608CE3C mov.l @r3,r2
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 0608CE3E cmp/gt r2,r1
    if (c.t) { goto L_0608CE48; }  // 0608CE40 bt 0x0608CE48
    c.r[0] = 0x1u;  // 0608CE42 mov #1,r0
    goto L_0608CE4E;  // 0608CE44 bra 0x0608CE4E ; nop
L_0608CE48:
    c.r[0] = 0x0u;  // 0608CE48 mov #0,r0
    goto L_0608CE4E;  // 0608CE4A bra 0x0608CE4E ; nop
L_0608CE4E:
    c.r[14] += 16;  // 0608CE4E add #16,r14
    c.r[15] = c.r[14];  // 0608CE50 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608CE52 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608CE54 rts ; nop
}

void f_0608CE58(SH2Context& c) {
    ran[2046] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608CE58 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608CE5A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608CE5C sts.l pr,@-r15
    c.r[15] -= 16;  // 0608CE5E add #-16,r15
    c.r[14] = c.r[15];  // 0608CE60 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608CE62 mov.l r4,@r14
    c.r[1] = ld32(c.r[14]);  // 0608CE64 mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 0608CE66 mov.l @r1,r2
    st32(c.r[14] + 4, c.r[2]);  // 0608CE68 mov.l r2,@(4,r14)
    c.r[1] = ld32(c.r[14] + 4);  // 0608CE6A mov.l @(4,r14),r1
    c.r[2] = c.r[1];  // 0608CE6C mov r1,r2
    c.r[2] += 56;  // 0608CE6E add #56,r2
    st32(c.r[14] + 8, c.r[2]);  // 0608CE70 mov.l r2,@(8,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 0608CE72 mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 0608CE74 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608CF56u);  // 0608CE76 mov.w 0x0608CF56,r3
    c.r[2] = c.r[1];  // 0608CE78 mov r1,r2
    c.r[2] += c.r[3];  // 0608CE7A add r3,r2
    c.r[1] = ld32(c.r[14] + 8);  // 0608CE7C mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 0608CE7E mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608CF56u);  // 0608CE80 mov.w 0x0608CF56,r3
    c.r[1] += c.r[3];  // 0608CE82 add r3,r1
    c.r[2] = ld32(c.r[14] + 8);  // 0608CE84 mov.l @(8,r14),r2
    c.r[3] = c.r[2];  // 0608CE86 mov r2,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x0608CF56u);  // 0608CE88 mov.w 0x0608CF56,r7
    c.r[2] += c.r[7];  // 0608CE8A add r7,r2
    c.r[3] = ld32(c.r[2]);  // 0608CE8C mov.l @r2,r3
    c.r[2] = c.r[3];  // 0608CE8E mov r3,r2
    c.r[2] += 1;  // 0608CE90 add #1,r2
    c.r[3] = c.r[2];  // 0608CE92 mov r2,r3
    st32(c.r[1], c.r[3]);  // 0608CE94 mov.l r3,@r1
    c.r[1] = ld32(c.r[14] + 8);  // 0608CE96 mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[1] + 4);  // 0608CE98 mov.l @(4,r1),r2
    c.r[1] = 0x1u;  // 0608CE9A mov #1,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0608CE9C cmp/gt r1,r2
    if (!c.t) { goto L_0608CEAE; }  // 0608CE9E bf 0x0608CEAE
    c.r[1] = ld32(c.r[14] + 8);  // 0608CEA0 mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[1] + 4);  // 0608CEA2 mov.l @(4,r1),r2
    c.r[1] = 0x4u;  // 0608CEA4 mov #4,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0608CEA6 cmp/gt r1,r2
    if (c.t) { goto L_0608CEAE; }  // 0608CEA8 bt 0x0608CEAE
    goto L_0608CEB2;  // 0608CEAA bra 0x0608CEB2 ; nop
L_0608CEAE:
    goto L_0608CF48;  // 0608CEAE bra 0x0608CF48 ; nop
L_0608CEB2:
    c.r[1] = ld32(0x0608CF5Cu);  // 0608CEB2 mov.l 0x0608CF5C,r1
    c.r[2] = ld32(c.r[1]);  // 0608CEB4 mov.l @r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0608CEB6 tst r2,r2
    if (c.t) { goto L_0608CECC; }  // 0608CEB8 bt 0x0608CECC
    c.r[4] = ld32(c.r[14]);  // 0608CEBA mov.l @r14,r4
    c.r[8] = ld32(0x0608CF60u);  // 0608CEBC mov.l 0x0608CF60,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608CEC2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608CEC2u) return; }  // 0608CEBE jsr @r8 ; nop
    c.r[1] = ld32(c.r[14] + 8);  // 0608CEC2 mov.l @(8,r14),r1
    c.r[2] = 0xFFFFFFFFu;  // 0608CEC4 mov #-1,r2
    st32(c.r[1] + 4, c.r[2]);  // 0608CEC6 mov.l r2,@(4,r1)
    goto L_0608CF48;  // 0608CEC8 bra 0x0608CF48 ; nop
L_0608CECC:
    c.r[1] = ld32(c.r[14] + 8);  // 0608CECC mov.l @(8,r14),r1
    c.r[0] = ld32(c.r[1] + 4);  // 0608CECE mov.l @(4,r1),r0
    c.t = c.r[0] == 0x2u;  // 0608CED0 cmp/eq #2,r0
    if (!c.t) { goto L_0608CEE4; }  // 0608CED2 bf 0x0608CEE4
    c.r[4] = ld32(c.r[14]);  // 0608CED4 mov.l @r14,r4
    c.r[8] = ld32(0x0608CF64u);  // 0608CED6 mov.l 0x0608CF64,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608CEDCu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608CEDCu) return; }  // 0608CED8 jsr @r8 ; nop
    c.t = (c.r[0] & c.r[0]) == 0;  // 0608CEDC tst r0,r0
    if (c.t) { goto L_0608CEE4; }  // 0608CEDE bt 0x0608CEE4
    goto L_0608CF48;  // 0608CEE0 bra 0x0608CF48 ; nop
L_0608CEE4:
    c.r[1] = ld32(c.r[14] + 8);  // 0608CEE4 mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 0608CEE6 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608CF58u);  // 0608CEE8 mov.w 0x0608CF58,r3
    c.r[1] += c.r[3];  // 0608CEEA add r3,r1
    c.r[2] = ld32(c.r[1]);  // 0608CEEC mov.l @r1,r2
    c.r[4] = ld32(c.r[14]);  // 0608CEEE mov.l @r14,r4
    { const uint32_t x = c.r[2]; c.pr = 0x0608CEF4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608CEF4u) return; }  // 0608CEF0 jsr @r2 ; nop
    c.r[1] = ld32(c.r[14] + 8);  // 0608CEF4 mov.l @(8,r14),r1
    c.r[0] = ld32(c.r[1] + 4);  // 0608CEF6 mov.l @(4,r1),r0
    c.t = c.r[0] == 0x4u;  // 0608CEF8 cmp/eq #4,r0
    if (!c.t) { goto L_0608CF34; }  // 0608CEFA bf 0x0608CF34
    c.r[4] = ld32(c.r[14]);  // 0608CEFC mov.l @r14,r4
    c.r[8] = ld32(0x0608CF68u);  // 0608CEFE mov.l 0x0608CF68,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608CF04u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608CF04u) return; }  // 0608CF00 jsr @r8 ; nop
    c.t = (c.r[0] & c.r[0]) == 0;  // 0608CF04 tst r0,r0
    if (c.t) { goto L_0608CF34; }  // 0608CF06 bt 0x0608CF34
    c.r[1] = c.r[14];  // 0608CF08 mov r14,r1
    c.r[1] += 12;  // 0608CF0A add #12,r1
    c.r[5] = c.r[1];  // 0608CF0C mov r1,r5
    c.r[4] = ld32(c.r[14]);  // 0608CF0E mov.l @r14,r4
    c.r[8] = ld32(0x0608CF6Cu);  // 0608CF10 mov.l 0x0608CF6C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608CF16u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608CF16u) return; }  // 0608CF12 jsr @r8 ; nop
    c.r[1] = ld32(c.r[14]);  // 0608CF16 mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 0608CF18 mov.l @r1,r2
    c.r[1] = ld32(c.r[14] + 12);  // 0608CF1A mov.l @(12,r14),r1
    c.r[2] = ld32(c.r[2] + 52);  // 0608CF1C mov.l @(52,r2),r2
    c.r[1] += c.r[2];  // 0608CF1E add r2,r1
    c.r[3] = ld32(c.r[14] + 8);  // 0608CF20 mov.l @(8,r14),r3
    c.r[2] = c.r[3];  // 0608CF22 mov r3,r2
    c.r[3] += 108;  // 0608CF24 add #108,r3
    c.r[2] = ld32(c.r[3]);  // 0608CF26 mov.l @r3,r2
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 0608CF28 cmp/gt r2,r1
    if (!c.t) { goto L_0608CF34; }  // 0608CF2A bf 0x0608CF34
    c.r[4] = ld32(c.r[14]);  // 0608CF2C mov.l @r14,r4
    c.r[8] = ld32(0x0608CF70u);  // 0608CF2E mov.l 0x0608CF70,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608CF34u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608CF34u) return; }  // 0608CF30 jsr @r8 ; nop
L_0608CF34:
    c.r[1] = ld32(c.r[14] + 8);  // 0608CF34 mov.l @(8,r14),r1
    c.r[0] = ld32(c.r[1] + 4);  // 0608CF36 mov.l @(4,r1),r0
    c.t = c.r[0] == 0x3u;  // 0608CF38 cmp/eq #3,r0
    if (!c.t) { goto L_0608CF44; }  // 0608CF3A bf 0x0608CF44
    c.r[4] = ld32(c.r[14]);  // 0608CF3C mov.l @r14,r4
    c.r[8] = ld32(0x0608CF74u);  // 0608CF3E mov.l 0x0608CF74,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608CF44u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608CF44u) return; }  // 0608CF40 jsr @r8 ; nop
L_0608CF44:
    goto L_0608CF48;  // 0608CF44 bra 0x0608CF48 ; nop
L_0608CF48:
    c.r[14] += 16;  // 0608CF48 add #16,r14
    c.r[15] = c.r[14];  // 0608CF4A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608CF4C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608CF4E mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608CF50 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608CF52 rts ; nop
}

void f_0608CF78(SH2Context& c) {
    ran[2047] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608CF78 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608CF7A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608CF7C sts.l pr,@-r15
    c.r[15] -= 4;  // 0608CF7E add #-4,r15
    c.r[14] = c.r[15];  // 0608CF80 mov r15,r14
    c.r[8] = ld32(0x0608CFACu);  // 0608CF82 mov.l 0x0608CFAC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608CF88u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608CF88u) return; }  // 0608CF84 jsr @r8 ; nop
    c.r[1] = (uint32_t)(int16_t)ld16(0x0608CFA8u);  // 0608CF88 mov.w 0x0608CFA8,r1
    c.r[1] &= c.r[0];  // 0608CF8A and r0,r1
    c.r[2] = c.r[1];  // 0608CF8C mov r1,r2
    c.r[2] >>= 2;  // 0608CF8E shlr2 r2
    c.r[2] >>= 2;  // 0608CF90 shlr2 r2
    st32(c.r[14], c.r[2]);  // 0608CF92 mov.l r2,@r14
    c.r[0] = ld32(c.r[14]);  // 0608CF94 mov.l @r14,r0
    goto L_0608CF9A;  // 0608CF96 bra 0x0608CF9A ; nop
L_0608CF9A:
    c.r[14] += 4;  // 0608CF9A add #4,r14
    c.r[15] = c.r[14];  // 0608CF9C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608CF9E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608CFA0 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608CFA2 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608CFA4 rts ; nop
}

void f_0608CFB0(SH2Context& c) {
    ran[2048] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608CFB0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0608CFB2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608CFB4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608CFB6 sts.l pr,@-r15
    c.r[15] -= 4;  // 0608CFB8 add #-4,r15
    c.r[14] = c.r[15];  // 0608CFBA mov r15,r14
    c.r[8] = c.r[4];  // 0608CFBC mov r4,r8
    c.r[9] = ld32(0x0608CFF4u);  // 0608CFBE mov.l 0x0608CFF4,r9
    { const uint32_t x = c.r[9]; c.pr = 0x0608CFC4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608CFC4u) return; }  // 0608CFC0 jsr @r9 ; nop
    st32(c.r[14], c.r[0]);  // 0608CFC4 mov.l r0,@r14
    c.r[1] = ld32(c.r[14]);  // 0608CFC6 mov.l @r14,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0608CFF2u);  // 0608CFC8 mov.w 0x0608CFF2,r2
    c.r[1] &= c.r[2];  // 0608CFCA and r2,r1
    st32(c.r[14], c.r[1]);  // 0608CFCC mov.l r1,@r14
    c.r[1] = c.r[8];  // 0608CFCE mov r8,r1
    c.r[1] <<= 2;  // 0608CFD0 shll2 r1
    c.r[1] <<= 2;  // 0608CFD2 shll2 r1
    c.r[2] = ld32(c.r[14]);  // 0608CFD4 mov.l @r14,r2
    c.r[1] |= c.r[2];  // 0608CFD6 or r2,r1
    st32(c.r[14], c.r[1]);  // 0608CFD8 mov.l r1,@r14
    c.r[4] = ld32(c.r[14]);  // 0608CFDA mov.l @r14,r4
    c.r[9] = ld32(0x0608CFF8u);  // 0608CFDC mov.l 0x0608CFF8,r9
    { const uint32_t x = c.r[9]; c.pr = 0x0608CFE2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608CFE2u) return; }  // 0608CFDE jsr @r9 ; nop
    c.r[14] += 4;  // 0608CFE2 add #4,r14
    c.r[15] = c.r[14];  // 0608CFE4 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608CFE6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608CFE8 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0608CFEA mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608CFEC mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608CFEE rts ; nop
}

void f_0608CFFC(SH2Context& c) {
    ran[2049] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608CFFC mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0608CFFE mov r15,r14
    c.r[1] = c.r[4];  // 0608D000 mov r4,r1
    sh2_set_sr(c, c.r[1] & 0x3F3u); SH2_POLL(c);  // 0608D002 ldc r1,sr
    c.r[15] = c.r[14];  // 0608D004 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608D006 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608D008 rts ; nop
}

void f_0608D00C(SH2Context& c) {
    ran[2050] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608D00C mov.l r14,@-r15
    c.r[15] -= 4;  // 0608D00E add #-4,r15
    c.r[14] = c.r[15];  // 0608D010 mov r15,r14
    c.r[1] = sh2_get_sr(c);  // 0608D012 stc sr,r1
    st32(c.r[14], c.r[1]);  // 0608D014 mov.l r1,@r14
    c.r[0] = ld32(c.r[14]);  // 0608D016 mov.l @r14,r0
    goto L_0608D01C;  // 0608D018 bra 0x0608D01C ; nop
L_0608D01C:
    c.r[14] += 4;  // 0608D01C add #4,r14
    c.r[15] = c.r[14];  // 0608D01E mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608D020 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608D022 rts ; nop
}

void f_0608D028(SH2Context& c) {
    ran[2051] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608D028 mov.l r14,@-r15
    c.r[15] -= 4;  // 0608D02A add #-4,r15
    c.r[14] = c.r[15];  // 0608D02C mov r15,r14
    ;  // 0608D02E nop
    c.r[1] = (uint32_t)(int16_t)ld16(0x0608D066u);  // 0608D030 mov.w 0x0608D066,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0608D032 mov.b @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0608D068u);  // 0608D034 mov.w 0x0608D068,r1
    c.r[1] &= c.r[2];  // 0608D036 and r2,r1
    st8(c.r[14], c.r[1]);  // 0608D038 mov.b r1,@r14
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[14]);  // 0608D03A mov.b @r14,r1
    c.r[2] = 0x2u;  // 0608D03C mov #2,r2
    c.r[2] |= c.r[1];  // 0608D03E or r1,r2
    st8(c.r[14], c.r[2]);  // 0608D040 mov.b r2,@r14
    c.r[1] = (uint32_t)(int16_t)ld16(0x0608D066u);  // 0608D042 mov.w 0x0608D066,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[14]);  // 0608D044 mov.b @r14,r2
    st8(c.r[1], c.r[2]);  // 0608D046 mov.b r2,@r1
    goto L_0608D050;  // 0608D048 bra 0x0608D050 ; nop
L_0608D050:
    c.r[1] = ld32(0x0608D06Cu);  // 0608D050 mov.l 0x0608D06C,r1
    c.r[2] = 0x0u;  // 0608D052 mov #0,r2
    st32(c.r[1], c.r[2]);  // 0608D054 mov.l r2,@r1
    c.r[1] = ld32(0x0608D070u);  // 0608D056 mov.l 0x0608D070,r1
    c.r[2] = 0x0u;  // 0608D058 mov #0,r2
    st16(c.r[1], c.r[2]);  // 0608D05A mov.w r2,@r1
    c.r[14] += 4;  // 0608D05C add #4,r14
    c.r[15] = c.r[14];  // 0608D05E mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608D060 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608D062 rts ; nop
}

void f_0608D074(SH2Context& c) {
    ran[2052] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608D074 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608D076 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608D078 sts.l pr,@-r15
    c.r[15] -= 12;  // 0608D07A add #-12,r15
    c.r[14] = c.r[15];  // 0608D07C mov r15,r14
    c.r[8] = ld32(0x0608D118u);  // 0608D07E mov.l 0x0608D118,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608D084u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608D084u) return; }  // 0608D080 jsr @r8 ; nop
    st32(c.r[14] + 8, c.r[0]);  // 0608D084 mov.l r0,@(8,r14)
    c.r[4] = 0xFu;  // 0608D086 mov #15,r4
    c.r[8] = ld32(0x0608D11Cu);  // 0608D088 mov.l 0x0608D11C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608D08Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608D08Eu) return; }  // 0608D08A jsr @r8 ; nop
    c.r[2] = c.r[14];  // 0608D08E mov r14,r2
    c.r[1] = c.r[14];  // 0608D090 mov r14,r1
    c.r[1] += 4;  // 0608D092 add #4,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0608D110u);  // 0608D094 mov.w 0x0608D110,r2
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0608D096 mov.b @r2,r7
    c.r[3] = c.r[7] & 0xFFu;  // 0608D098 extu.b r7,r3
    c.r[2] = c.r[3];  // 0608D09A mov r3,r2
    c.r[2] <<= 8;  // 0608D09C shll8 r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608D112u);  // 0608D09E mov.w 0x0608D112,r3
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0608D0A0 mov.b @r3,r7
    c.r[3] = c.r[7] & 0xFFu;  // 0608D0A2 extu.b r7,r3
    c.r[2] = c.r[2];  // 0608D0A4 mov r2,r2
    c.r[3] |= c.r[2];  // 0608D0A6 or r2,r3
    st16(c.r[1], c.r[3]);  // 0608D0A8 mov.w r3,@r1
    c.r[1] = c.r[14];  // 0608D0AA mov r14,r1
    c.r[2] = c.r[14];  // 0608D0AC mov r14,r2
    c.r[2] += 4;  // 0608D0AE add #4,r2
    c.r[1] = ld32(0x0608D120u);  // 0608D0B0 mov.l 0x0608D120,r1
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0608D0B2 mov.w @r2,r3
    c.r[2] = c.r[3] & 0xFFFFu;  // 0608D0B4 extu.w r3,r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0608D0B6 mov.w @r1,r3
    c.r[1] = c.r[3] & 0xFFFFu;  // 0608D0B8 extu.w r3,r1
    c.t = c.r[2] >= c.r[1];  // 0608D0BA cmp/hs r1,r2
    if (c.t) { goto L_0608D0CA; }  // 0608D0BC bt 0x0608D0CA
    c.r[1] = ld32(0x0608D124u);  // 0608D0BE mov.l 0x0608D124,r1
    c.r[2] = ld32(0x0608D124u);  // 0608D0C0 mov.l 0x0608D124,r2
    c.r[3] = ld32(c.r[2]);  // 0608D0C2 mov.l @r2,r3
    c.r[2] = (uint32_t)(int16_t)ld16(0x0608D114u);  // 0608D0C4 mov.w 0x0608D114,r2
    c.r[3] += c.r[2];  // 0608D0C6 add r2,r3
    st32(c.r[1], c.r[3]);  // 0608D0C8 mov.l r3,@r1
L_0608D0CA:
    c.r[1] = ld32(0x0608D120u);  // 0608D0CA mov.l 0x0608D120,r1
    c.r[2] = c.r[14];  // 0608D0CC mov r14,r2
    c.r[3] = c.r[14];  // 0608D0CE mov r14,r3
    c.r[3] += 4;  // 0608D0D0 add #4,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0608D0D2 mov.w @r3,r2
    st16(c.r[1], c.r[2]);  // 0608D0D4 mov.w r2,@r1
    c.r[1] = ld32(0x0608D124u);  // 0608D0D6 mov.l 0x0608D124,r1
    c.r[2] = c.r[14];  // 0608D0D8 mov r14,r2
    c.r[3] = c.r[14];  // 0608D0DA mov r14,r3
    c.r[3] += 4;  // 0608D0DC add #4,r3
    c.r[7] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0608D0DE mov.w @r3,r7
    c.r[2] = c.r[7] & 0xFFFFu;  // 0608D0E0 extu.w r7,r2
    c.r[3] = c.r[2];  // 0608D0E2 mov r2,r3
    c.r[3] >>= 8;  // 0608D0E4 shlr8 r3
    c.r[2] = c.r[3];  // 0608D0E6 mov r3,r2
    c.r[3] = c.r[2] & 0xFFu;  // 0608D0E8 extu.b r2,r3
    c.r[2] = c.r[3] & 0xFFFFu;  // 0608D0EA extu.w r3,r2
    c.r[1] = ld32(c.r[1]);  // 0608D0EC mov.l @r1,r1
    c.r[2] += c.r[1];  // 0608D0EE add r1,r2
    st32(c.r[14], c.r[2]);  // 0608D0F0 mov.l r2,@r14
    c.r[1] = ld32(c.r[14] + 8);  // 0608D0F2 mov.l @(8,r14),r1
    c.r[4] = c.r[1];  // 0608D0F4 mov r1,r4
    c.r[8] = ld32(0x0608D11Cu);  // 0608D0F6 mov.l 0x0608D11C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608D0FCu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608D0FCu) return; }  // 0608D0F8 jsr @r8 ; nop
    c.r[0] = ld32(c.r[14]);  // 0608D0FC mov.l @r14,r0
    goto L_0608D102;  // 0608D0FE bra 0x0608D102 ; nop
L_0608D102:
    c.r[14] += 12;  // 0608D102 add #12,r14
    c.r[15] = c.r[14];  // 0608D104 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608D106 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608D108 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608D10A mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608D10C rts ; nop
}

void f_0608D128(SH2Context& c) {
    ran[2053] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608D128 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608D12A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608D12C sts.l pr,@-r15
    c.r[15] -= 16;  // 0608D12E add #-16,r15
    c.r[14] = c.r[15];  // 0608D130 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608D132 mov.l r4,@r14
    c.r[1] = ld32(c.r[14]);  // 0608D134 mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 0608D136 mov.l @r1,r2
    st32(c.r[14] + 4, c.r[2]);  // 0608D138 mov.l r2,@(4,r14)
    c.r[1] = ld32(c.r[14] + 4);  // 0608D13A mov.l @(4,r14),r1
    c.r[2] = c.r[1];  // 0608D13C mov r1,r2
    c.r[2] += 56;  // 0608D13E add #56,r2
    st32(c.r[14] + 8, c.r[2]);  // 0608D140 mov.l r2,@(8,r14)
    c.r[8] = ld32(0x0608D178u);  // 0608D142 mov.l 0x0608D178,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608D148u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608D148u) return; }  // 0608D144 jsr @r8 ; nop
    st32(c.r[14] + 12, c.r[0]);  // 0608D148 mov.l r0,@(12,r14)
    c.r[4] = 0xFu;  // 0608D14A mov #15,r4
    c.r[8] = ld32(0x0608D17Cu);  // 0608D14C mov.l 0x0608D17C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608D152u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608D152u) return; }  // 0608D14E jsr @r8 ; nop
    c.r[8] = ld32(0x0608D180u);  // 0608D152 mov.l 0x0608D180,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608D158u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608D158u) return; }  // 0608D154 jsr @r8 ; nop
    c.r[2] = ld32(c.r[14] + 8);  // 0608D158 mov.l @(8,r14),r2
    c.r[1] = c.r[2];  // 0608D15A mov r2,r1
    c.r[2] += 120;  // 0608D15C add #120,r2
    st32(c.r[2], c.r[0]);  // 0608D15E mov.l r0,@r2
    c.r[1] = ld32(c.r[14] + 12);  // 0608D160 mov.l @(12,r14),r1
    c.r[4] = c.r[1];  // 0608D162 mov r1,r4
    c.r[8] = ld32(0x0608D17Cu);  // 0608D164 mov.l 0x0608D17C,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608D16Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608D16Au) return; }  // 0608D166 jsr @r8 ; nop
    c.r[14] += 16;  // 0608D16A add #16,r14
    c.r[15] = c.r[14];  // 0608D16C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608D16E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608D170 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608D172 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608D174 rts ; nop
}

void f_0608D184(SH2Context& c) {
    ran[2054] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608D184 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608D186 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608D188 sts.l pr,@-r15
    c.r[15] -= 20;  // 0608D18A add #-20,r15
    c.r[14] = c.r[15];  // 0608D18C mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608D18E mov.l r4,@r14
    c.r[1] = ld32(c.r[14]);  // 0608D190 mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 0608D192 mov.l @r1,r2
    st32(c.r[14] + 4, c.r[2]);  // 0608D194 mov.l r2,@(4,r14)
    c.r[1] = ld32(c.r[14] + 4);  // 0608D196 mov.l @(4,r14),r1
    c.r[2] = c.r[1];  // 0608D198 mov r1,r2
    c.r[2] += 56;  // 0608D19A add #56,r2
    st32(c.r[14] + 8, c.r[2]);  // 0608D19C mov.l r2,@(8,r14)
    c.r[8] = ld32(0x0608D1E0u);  // 0608D19E mov.l 0x0608D1E0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608D1A4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608D1A4u) return; }  // 0608D1A0 jsr @r8 ; nop
    st32(c.r[14] + 16, c.r[0]);  // 0608D1A4 mov.l r0,@(16,r14)
    c.r[4] = 0xFu;  // 0608D1A6 mov #15,r4
    c.r[8] = ld32(0x0608D1E4u);  // 0608D1A8 mov.l 0x0608D1E4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608D1AEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608D1AEu) return; }  // 0608D1AA jsr @r8 ; nop
    c.r[8] = ld32(0x0608D1E8u);  // 0608D1AE mov.l 0x0608D1E8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608D1B4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608D1B4u) return; }  // 0608D1B0 jsr @r8 ; nop
    c.r[2] = ld32(c.r[14] + 8);  // 0608D1B4 mov.l @(8,r14),r2
    c.r[1] = c.r[2];  // 0608D1B6 mov r2,r1
    c.r[2] += 120;  // 0608D1B8 add #120,r2
    c.r[1] = ld32(c.r[2]);  // 0608D1BA mov.l @r2,r1
    c.r[2] = c.r[0];  // 0608D1BC mov r0,r2
    c.r[2] -= c.r[1];  // 0608D1BE sub r1,r2
    st32(c.r[14] + 12, c.r[2]);  // 0608D1C0 mov.l r2,@(12,r14)
    c.r[1] = ld32(c.r[14] + 16);  // 0608D1C2 mov.l @(16,r14),r1
    c.r[4] = c.r[1];  // 0608D1C4 mov r1,r4
    c.r[8] = ld32(0x0608D1E4u);  // 0608D1C6 mov.l 0x0608D1E4,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608D1CCu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608D1CCu) return; }  // 0608D1C8 jsr @r8 ; nop
    c.r[0] = ld32(c.r[14] + 12);  // 0608D1CC mov.l @(12,r14),r0
    goto L_0608D1D2;  // 0608D1CE bra 0x0608D1D2 ; nop
L_0608D1D2:
    c.r[14] += 20;  // 0608D1D2 add #20,r14
    c.r[15] = c.r[14];  // 0608D1D4 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608D1D6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608D1D8 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608D1DA mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608D1DC rts ; nop
}

void f_0608D1EC(SH2Context& c) {
    ran[2055] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608D1EC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0608D1EE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0608D1F0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0608D1F2 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608D1F4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608D1F6 sts.l pr,@-r15
    c.r[15] -= 24;  // 0608D1F8 add #-24,r15
    c.r[14] = c.r[15];  // 0608D1FA mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608D1FC mov.l r4,@r14
    c.r[1] = ld32(c.r[14]);  // 0608D1FE mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 0608D200 mov.l @r1,r2
    st32(c.r[14] + 4, c.r[2]);  // 0608D202 mov.l r2,@(4,r14)
    c.r[1] = ld32(c.r[14] + 4);  // 0608D204 mov.l @(4,r14),r1
    c.r[2] = c.r[1];  // 0608D206 mov r1,r2
    c.r[2] += 56;  // 0608D208 add #56,r2
    st32(c.r[14] + 8, c.r[2]);  // 0608D20A mov.l r2,@(8,r14)
    c.r[2] = ld32(c.r[14] + 8);  // 0608D20C mov.l @(8,r14),r2
    c.r[1] = ld32(c.r[2] + 4);  // 0608D20E mov.l @(4,r2),r1
    c.r[3] = 0x6u;  // 0608D210 mov #6,r3
    c.r[2] = 0xFFFFFFFFu;  // 0608D212 mov #-1,r2
    c.r[1] -= c.r[2];  // 0608D214 sub r2,r1
    c.t = c.r[1] > c.r[3];  // 0608D216 cmp/hi r3,r1
    if (c.t) { goto L_0608D25A; }  // 0608D218 bt 0x0608D25A
    c.r[1] += c.r[1];  // 0608D21A add r1,r1
    c.r[0] = 0x0608D228u;  // 0608D21C mova 0x0608D228,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0608D21E mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 0608D220 add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x0608D236u: goto L_0608D236; case 0x0608D240u: goto L_0608D240; case 0x0608D248u: goto L_0608D248; default: sh2_call(c, x); return; } }  // 0608D222 jmp @r0 ; nop
L_0608D236:
    c.r[0] = 0xFFFFFFFFu;  // 0608D236 mov #-1,r0
    goto L_0608D33A;  // 0608D238 bra 0x0608D33A ; nop
L_0608D240:
    c.r[1] = 0x0u;  // 0608D240 mov #0,r1
    st32(c.r[14] + 12, c.r[1]);  // 0608D242 mov.l r1,@(12,r14)
    goto L_0608D262;  // 0608D244 bra 0x0608D262 ; nop
L_0608D248:
    c.r[4] = ld32(c.r[14]);  // 0608D248 mov.l @r14,r4
    c.r[8] = ld32(0x0608D350u);  // 0608D24A mov.l 0x0608D350,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608D250u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608D250u) return; }  // 0608D24C jsr @r8 ; nop
    st32(c.r[14] + 20, c.r[0]);  // 0608D250 mov.l r0,@(20,r14)
    c.r[0] = ld32(c.r[14] + 20);  // 0608D252 mov.l @(20,r14),r0
    st32(c.r[14] + 12, c.r[0]);  // 0608D254 mov.l r0,@(12,r14)
    goto L_0608D262;  // 0608D256 bra 0x0608D262 ; nop
L_0608D25A:
    c.r[1] = 0x0u;  // 0608D25A mov #0,r1
    st32(c.r[14] + 12, c.r[1]);  // 0608D25C mov.l r1,@(12,r14)
    goto L_0608D262;  // 0608D25E bra 0x0608D262 ; nop
L_0608D262:
    c.r[2] = ld32(c.r[14] + 8);  // 0608D262 mov.l @(8,r14),r2
    c.r[1] = c.r[2];  // 0608D264 mov r2,r1
    c.r[2] += 100;  // 0608D266 add #100,r2
    c.r[1] = ld32(c.r[2]);  // 0608D268 mov.l @r2,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0608D34Eu);  // 0608D26A mov.w 0x0608D34E,r2
    c.macl = c.r[1] * c.r[2];  // 0608D26C mul.l r2,r1
    c.r[7] = c.macl;  // 0608D26E sts macl,r7
    c.r[2] = ld32(c.r[14] + 8);  // 0608D270 mov.l @(8,r14),r2
    c.r[1] = c.r[2];  // 0608D272 mov r2,r1
    c.r[2] += 124;  // 0608D274 add #124,r2
    c.r[4] = ld32(c.r[14] + 12);  // 0608D276 mov.l @(12,r14),r4
    c.r[5] = ld32(c.r[2]);  // 0608D278 mov.l @r2,r5
    c.r[6] = ld32(0x0608D354u);  // 0608D27A mov.l 0x0608D354,r6
    { const uint32_t x = c.r[6]; c.pr = 0x0608D280u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608D280u) return; }  // 0608D27C jsr @r6 ; nop
    st32(c.r[14] + 20, c.r[0]);  // 0608D280 mov.l r0,@(20,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 0608D282 mov.l @(8,r14),r1
    c.r[2] = ld32(c.r[1] + 44);  // 0608D284 mov.l @(44,r1),r2
    c.r[0] = ld32(c.r[14] + 20);  // 0608D286 mov.l @(20,r14),r0
    c.macl = c.r[0] * c.r[2];  // 0608D288 mul.l r2,r0
    c.r[6] = c.macl;  // 0608D28A sts macl,r6
    c.r[1] = ld32(c.r[14] + 8);  // 0608D28C mov.l @(8,r14),r1
    c.r[3] = ld32(c.r[14] + 8);  // 0608D28E mov.l @(8,r14),r3
    c.r[2] = c.r[3];  // 0608D290 mov r3,r2
    c.r[3] += 124;  // 0608D292 add #124,r3
    c.r[4] = ld32(c.r[1] + 44);  // 0608D294 mov.l @(44,r1),r4
    c.r[5] = ld32(c.r[3]);  // 0608D296 mov.l @r3,r5
    c.r[8] = ld32(0x0608D354u);  // 0608D298 mov.l 0x0608D354,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608D29Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608D29Eu) return; }  // 0608D29A jsr @r8 ; nop
    st32(c.r[14] + 20, c.r[0]);  // 0608D29E mov.l r0,@(20,r14)
    c.r[2] = ld32(c.r[14] + 8);  // 0608D2A0 mov.l @(8,r14),r2
    c.r[1] = c.r[2];  // 0608D2A2 mov r2,r1
    c.r[9] = c.r[2];  // 0608D2A4 mov r2,r9
    c.r[9] += 124;  // 0608D2A6 add #124,r9
    c.r[8] = ld32(c.r[14] + 12);  // 0608D2A8 mov.l @(12,r14),r8
    c.r[4] = c.r[8];  // 0608D2AA mov r8,r4
    c.r[5] = ld32(c.r[9]);  // 0608D2AC mov.l @r9,r5
    c.r[10] = ld32(0x0608D354u);  // 0608D2AE mov.l 0x0608D354,r10
    { const uint32_t x = c.r[10]; c.pr = 0x0608D2B4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608D2B4u) return; }  // 0608D2B0 jsr @r10 ; nop
    c.r[5] = c.r[0];  // 0608D2B4 mov r0,r5
    c.r[1] = ld32(c.r[9]);  // 0608D2B6 mov.l @r9,r1
    c.macl = c.r[5] * c.r[1];  // 0608D2B8 mul.l r1,r5
    c.r[1] = c.macl;  // 0608D2BA sts macl,r1
    c.r[2] = c.r[8];  // 0608D2BC mov r8,r2
    c.r[2] -= c.r[1];  // 0608D2BE sub r1,r2
    c.r[0] = ld32(c.r[14] + 20);  // 0608D2C0 mov.l @(20,r14),r0
    c.macl = c.r[0] * c.r[2];  // 0608D2C2 mul.l r2,r0
    c.r[0] = c.macl;  // 0608D2C4 sts macl,r0
    st32(c.r[14] + 20, c.r[0]);  // 0608D2C6 mov.l r0,@(20,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 0608D2C8 mov.l @(8,r14),r1
    c.r[3] = ld32(c.r[14] + 8);  // 0608D2CA mov.l @(8,r14),r3
    c.r[2] = c.r[3];  // 0608D2CC mov r3,r2
    c.r[9] = c.r[3];  // 0608D2CE mov r3,r9
    c.r[9] += 124;  // 0608D2D0 add #124,r9
    c.r[8] = ld32(c.r[1] + 44);  // 0608D2D2 mov.l @(44,r1),r8
    c.r[4] = c.r[8];  // 0608D2D4 mov r8,r4
    c.r[5] = ld32(c.r[9]);  // 0608D2D6 mov.l @r9,r5
    c.r[10] = ld32(0x0608D354u);  // 0608D2D8 mov.l 0x0608D354,r10
    { const uint32_t x = c.r[10]; c.pr = 0x0608D2DEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608D2DEu) return; }  // 0608D2DA jsr @r10 ; nop
    c.r[5] = c.r[0];  // 0608D2DE mov r0,r5
    c.r[1] = ld32(c.r[9]);  // 0608D2E0 mov.l @r9,r1
    c.macl = c.r[5] * c.r[1];  // 0608D2E2 mul.l r1,r5
    c.r[1] = c.macl;  // 0608D2E4 sts macl,r1
    c.r[8] -= c.r[1];  // 0608D2E6 sub r1,r8
    c.r[2] = ld32(c.r[14] + 8);  // 0608D2E8 mov.l @(8,r14),r2
    c.r[1] = c.r[2];  // 0608D2EA mov r2,r1
    c.r[10] = c.r[2];  // 0608D2EC mov r2,r10
    c.r[10] += 124;  // 0608D2EE add #124,r10
    c.r[9] = ld32(c.r[14] + 12);  // 0608D2F0 mov.l @(12,r14),r9
    c.r[4] = c.r[9];  // 0608D2F2 mov r9,r4
    c.r[5] = ld32(c.r[10]);  // 0608D2F4 mov.l @r10,r5
    c.r[11] = ld32(0x0608D354u);  // 0608D2F6 mov.l 0x0608D354,r11
    { const uint32_t x = c.r[11]; c.pr = 0x0608D2FCu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608D2FCu) return; }  // 0608D2F8 jsr @r11 ; nop
    c.r[5] = c.r[0];  // 0608D2FC mov r0,r5
    c.r[1] = ld32(c.r[10]);  // 0608D2FE mov.l @r10,r1
    c.macl = c.r[5] * c.r[1];  // 0608D300 mul.l r1,r5
    c.r[1] = c.macl;  // 0608D302 sts macl,r1
    c.r[2] = c.r[9];  // 0608D304 mov r9,r2
    c.r[2] -= c.r[1];  // 0608D306 sub r1,r2
    c.macl = c.r[8] * c.r[2];  // 0608D308 mul.l r2,r8
    c.r[1] = c.macl;  // 0608D30A sts macl,r1
    c.r[3] = ld32(c.r[14] + 8);  // 0608D30C mov.l @(8,r14),r3
    c.r[2] = c.r[3];  // 0608D30E mov r3,r2
    c.r[3] += 124;  // 0608D310 add #124,r3
    c.r[4] = c.r[1];  // 0608D312 mov r1,r4
    c.r[5] = ld32(c.r[3]);  // 0608D314 mov.l @r3,r5
    c.r[8] = ld32(0x0608D354u);  // 0608D316 mov.l 0x0608D354,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608D31Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608D31Cu) return; }  // 0608D318 jsr @r8 ; nop
    c.r[5] = c.r[0];  // 0608D31C mov r0,r5
    c.r[1] = ld32(c.r[14] + 20);  // 0608D31E mov.l @(20,r14),r1
    c.r[1] += c.r[5];  // 0608D320 add r5,r1
    c.r[2] = c.r[6];  // 0608D322 mov r6,r2
    c.r[2] += c.r[1];  // 0608D324 add r1,r2
    c.r[1] = c.r[7];  // 0608D326 mov r7,r1
    c.r[1] += c.r[2];  // 0608D328 add r2,r1
    st32(c.r[14] + 16, c.r[1]);  // 0608D32A mov.l r1,@(16,r14)
    c.r[1] = ld32(c.r[14] + 16);  // 0608D32C mov.l @(16,r14),r1
    c.r[2] = 0xFFFFFFFCu;  // 0608D32E mov #-4,r2
    c.r[1] &= c.r[2];  // 0608D330 and r2,r1
    st32(c.r[14] + 16, c.r[1]);  // 0608D332 mov.l r1,@(16,r14)
    c.r[0] = ld32(c.r[14] + 16);  // 0608D334 mov.l @(16,r14),r0
    goto L_0608D33A;  // 0608D336 bra 0x0608D33A ; nop
L_0608D33A:
    c.r[14] += 24;  // 0608D33A add #24,r14
    c.r[15] = c.r[14];  // 0608D33C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608D33E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608D340 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0608D342 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0608D344 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0608D346 mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608D348 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608D34A rts ; nop
}

void f_0608D358(SH2Context& c) {
    ran[2056] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608D358 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608D35A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608D35C sts.l pr,@-r15
    c.r[15] -= 16;  // 0608D35E add #-16,r15
    c.r[14] = c.r[15];  // 0608D360 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608D362 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 0608D364 mov.l r5,@(4,r14)
    c.r[1] = ld32(c.r[14]);  // 0608D366 mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 0608D368 mov.l @r1,r2
    st32(c.r[14] + 8, c.r[2]);  // 0608D36A mov.l r2,@(8,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 0608D36C mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 0608D36E mov r1,r2
    c.r[2] += 56;  // 0608D370 add #56,r2
    st32(c.r[14] + 12, c.r[2]);  // 0608D372 mov.l r2,@(12,r14)
    c.r[2] = ld32(c.r[14] + 12);  // 0608D374 mov.l @(12,r14),r2
    c.r[1] = ld32(c.r[2] + 4);  // 0608D376 mov.l @(4,r2),r1
    c.r[3] = 0x6u;  // 0608D378 mov #6,r3
    c.r[2] = 0xFFFFFFFFu;  // 0608D37A mov #-1,r2
    c.r[1] -= c.r[2];  // 0608D37C sub r2,r1
    c.t = c.r[1] > c.r[3];  // 0608D37E cmp/hi r3,r1
    if (c.t) { goto L_0608D3F2; }  // 0608D380 bt 0x0608D3F2
    c.r[1] += c.r[1];  // 0608D382 add r1,r1
    c.r[0] = 0x0608D390u;  // 0608D384 mova 0x0608D390,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0608D386 mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 0608D388 add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x0608D39Eu: goto L_0608D39E; case 0x0608D3B2u: goto L_0608D3B2; case 0x0608D3A8u: goto L_0608D3A8; case 0x0608D3CCu: goto L_0608D3CC; default: sh2_call(c, x); return; } }  // 0608D38A jmp @r0 ; nop
L_0608D39E:
    c.r[1] = ld32(c.r[14] + 4);  // 0608D39E mov.l @(4,r14),r1
    c.r[2] = 0xFFFFFFFFu;  // 0608D3A0 mov #-1,r2
    st32(c.r[1], c.r[2]);  // 0608D3A2 mov.l r2,@r1
    goto L_0608D3F2;  // 0608D3A4 bra 0x0608D3F2 ; nop
L_0608D3A8:
    c.r[1] = ld32(c.r[14] + 4);  // 0608D3A8 mov.l @(4,r14),r1
    c.r[2] = 0x0u;  // 0608D3AA mov #0,r2
    st32(c.r[1], c.r[2]);  // 0608D3AC mov.l r2,@r1
    goto L_0608D3F2;  // 0608D3AE bra 0x0608D3F2 ; nop
L_0608D3B2:
    c.r[1] = ld32(c.r[14] + 4);  // 0608D3B2 mov.l @(4,r14),r1
    c.r[2] = ld32(c.r[14] + 12);  // 0608D3B4 mov.l @(12,r14),r2
    c.r[3] = c.r[2];  // 0608D3B6 mov r2,r3
    c.r[2] += 116;  // 0608D3B8 add #116,r2
    c.r[7] = ld32(c.r[14] + 12);  // 0608D3BA mov.l @(12,r14),r7
    c.r[3] = c.r[7];  // 0608D3BC mov r7,r3
    c.r[7] += 112;  // 0608D3BE add #112,r7
    c.r[2] = ld32(c.r[2]);  // 0608D3C0 mov.l @r2,r2
    c.r[3] = ld32(c.r[7]);  // 0608D3C2 mov.l @r7,r3
    c.r[2] -= c.r[3];  // 0608D3C4 sub r3,r2
    st32(c.r[1], c.r[2]);  // 0608D3C6 mov.l r2,@r1
    goto L_0608D3F2;  // 0608D3C8 bra 0x0608D3F2 ; nop
L_0608D3CC:
    c.r[4] = ld32(c.r[14]);  // 0608D3CC mov.l @r14,r4
    c.r[8] = ld32(0x0608D404u);  // 0608D3CE mov.l 0x0608D404,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608D3D4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608D3D4u) return; }  // 0608D3D0 jsr @r8 ; nop
    c.r[1] = ld32(c.r[14] + 4);  // 0608D3D4 mov.l @(4,r14),r1
    c.r[3] = ld32(c.r[14] + 12);  // 0608D3D6 mov.l @(12,r14),r3
    c.r[2] = c.r[3];  // 0608D3D8 mov r3,r2
    c.r[3] += 116;  // 0608D3DA add #116,r3
    c.r[7] = ld32(c.r[3]);  // 0608D3DC mov.l @r3,r7
    c.r[2] = c.r[0];  // 0608D3DE mov r0,r2
    c.r[2] += c.r[7];  // 0608D3E0 add r7,r2
    c.r[7] = ld32(c.r[14] + 12);  // 0608D3E2 mov.l @(12,r14),r7
    c.r[3] = c.r[7];  // 0608D3E4 mov r7,r3
    c.r[7] += 112;  // 0608D3E6 add #112,r7
    c.r[3] = ld32(c.r[7]);  // 0608D3E8 mov.l @r7,r3
    c.r[2] -= c.r[3];  // 0608D3EA sub r3,r2
    st32(c.r[1], c.r[2]);  // 0608D3EC mov.l r2,@r1
    goto L_0608D3F2;  // 0608D3EE bra 0x0608D3F2 ; nop
L_0608D3F2:
    goto L_0608D3F6;  // 0608D3F2 bra 0x0608D3F6 ; nop
L_0608D3F6:
    c.r[14] += 16;  // 0608D3F6 add #16,r14
    c.r[15] = c.r[14];  // 0608D3F8 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608D3FA lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608D3FC mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608D3FE mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608D400 rts ; nop
}

void f_0608D408(SH2Context& c) {
    ran[2057] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608D408 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608D40A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608D40C sts.l pr,@-r15
    c.r[15] -= 16;  // 0608D40E add #-16,r15
    c.r[14] = c.r[15];  // 0608D410 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608D412 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 0608D414 mov.l r5,@(4,r14)
    c.r[1] = ld32(c.r[14]);  // 0608D416 mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 0608D418 mov.l @r1,r2
    st32(c.r[14] + 8, c.r[2]);  // 0608D41A mov.l r2,@(8,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 0608D41C mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 0608D41E mov r1,r2
    c.r[2] += 56;  // 0608D420 add #56,r2
    st32(c.r[14] + 12, c.r[2]);  // 0608D422 mov.l r2,@(12,r14)
    c.r[2] = ld32(c.r[14] + 12);  // 0608D424 mov.l @(12,r14),r2
    c.r[1] = ld32(c.r[2] + 4);  // 0608D426 mov.l @(4,r2),r1
    c.r[3] = 0x6u;  // 0608D428 mov #6,r3
    c.r[2] = 0xFFFFFFFFu;  // 0608D42A mov #-1,r2
    c.r[1] -= c.r[2];  // 0608D42C sub r2,r1
    c.t = c.r[1] > c.r[3];  // 0608D42E cmp/hi r3,r1
    if (c.t) { goto L_0608D484; }  // 0608D430 bt 0x0608D484
    c.r[1] += c.r[1];  // 0608D432 add r1,r1
    c.r[0] = 0x0608D440u;  // 0608D434 mova 0x0608D440,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0608D436 mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 0608D438 add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x0608D44Eu: goto L_0608D44E; case 0x0608D458u: goto L_0608D458; case 0x0608D468u: goto L_0608D468; default: sh2_call(c, x); return; } }  // 0608D43A jmp @r0 ; nop
L_0608D44E:
    c.r[1] = ld32(c.r[14] + 4);  // 0608D44E mov.l @(4,r14),r1
    c.r[2] = 0xFFFFFFFFu;  // 0608D450 mov #-1,r2
    st32(c.r[1], c.r[2]);  // 0608D452 mov.l r2,@r1
    goto L_0608D484;  // 0608D454 bra 0x0608D484 ; nop
L_0608D458:
    c.r[1] = ld32(c.r[14] + 4);  // 0608D458 mov.l @(4,r14),r1
    c.r[3] = ld32(c.r[14] + 12);  // 0608D45A mov.l @(12,r14),r3
    c.r[2] = c.r[3];  // 0608D45C mov r3,r2
    c.r[3] += 116;  // 0608D45E add #116,r3
    c.r[2] = ld32(c.r[3]);  // 0608D460 mov.l @r3,r2
    st32(c.r[1], c.r[2]);  // 0608D462 mov.l r2,@r1
    goto L_0608D484;  // 0608D464 bra 0x0608D484 ; nop
L_0608D468:
    c.r[4] = ld32(c.r[14]);  // 0608D468 mov.l @r14,r4
    c.r[8] = ld32(0x0608D498u);  // 0608D46A mov.l 0x0608D498,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608D470u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608D470u) return; }  // 0608D46C jsr @r8 ; nop
    c.r[1] = ld32(c.r[14] + 4);  // 0608D470 mov.l @(4,r14),r1
    c.r[3] = ld32(c.r[14] + 12);  // 0608D472 mov.l @(12,r14),r3
    c.r[2] = c.r[3];  // 0608D474 mov r3,r2
    c.r[3] += 116;  // 0608D476 add #116,r3
    c.r[2] = ld32(c.r[3]);  // 0608D478 mov.l @r3,r2
    c.r[3] = c.r[2];  // 0608D47A mov r2,r3
    c.r[3] += c.r[0];  // 0608D47C add r0,r3
    st32(c.r[1], c.r[3]);  // 0608D47E mov.l r3,@r1
    goto L_0608D484;  // 0608D480 bra 0x0608D484 ; nop
L_0608D484:
    goto L_0608D488;  // 0608D484 bra 0x0608D488 ; nop
L_0608D488:
    c.r[14] += 16;  // 0608D488 add #16,r14
    c.r[15] = c.r[14];  // 0608D48A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608D48C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608D48E mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608D490 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608D492 rts ; nop
}

void f_0608D49C(SH2Context& c) {
    ran[2058] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608D49C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608D49E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608D4A0 sts.l pr,@-r15
    c.r[15] -= 4;  // 0608D4A2 add #-4,r15
    c.r[14] = c.r[15];  // 0608D4A4 mov r15,r14
    c.r[8] = ld32(0x0608D4D0u);  // 0608D4A6 mov.l 0x0608D4D0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608D4ACu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608D4ACu) return; }  // 0608D4A8 jsr @r8 ; nop
    c.r[1] = (uint32_t)(int16_t)ld16(0x0608D4CCu);  // 0608D4AC mov.w 0x0608D4CC,r1
    c.r[1] &= c.r[0];  // 0608D4AE and r0,r1
    c.r[2] = c.r[1];  // 0608D4B0 mov r1,r2
    c.r[2] >>= 2;  // 0608D4B2 shlr2 r2
    c.r[2] >>= 2;  // 0608D4B4 shlr2 r2
    st32(c.r[14], c.r[2]);  // 0608D4B6 mov.l r2,@r14
    c.r[0] = ld32(c.r[14]);  // 0608D4B8 mov.l @r14,r0
    goto L_0608D4BE;  // 0608D4BA bra 0x0608D4BE ; nop
L_0608D4BE:
    c.r[14] += 4;  // 0608D4BE add #4,r14
    c.r[15] = c.r[14];  // 0608D4C0 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608D4C2 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608D4C4 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608D4C6 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608D4C8 rts ; nop
}

void f_0608D4D4(SH2Context& c) {
    ran[2059] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608D4D4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0608D4D6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608D4D8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608D4DA sts.l pr,@-r15
    c.r[15] -= 4;  // 0608D4DC add #-4,r15
    c.r[14] = c.r[15];  // 0608D4DE mov r15,r14
    c.r[8] = c.r[4];  // 0608D4E0 mov r4,r8
    c.r[9] = ld32(0x0608D518u);  // 0608D4E2 mov.l 0x0608D518,r9
    { const uint32_t x = c.r[9]; c.pr = 0x0608D4E8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608D4E8u) return; }  // 0608D4E4 jsr @r9 ; nop
    st32(c.r[14], c.r[0]);  // 0608D4E8 mov.l r0,@r14
    c.r[1] = ld32(c.r[14]);  // 0608D4EA mov.l @r14,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0608D516u);  // 0608D4EC mov.w 0x0608D516,r2
    c.r[1] &= c.r[2];  // 0608D4EE and r2,r1
    st32(c.r[14], c.r[1]);  // 0608D4F0 mov.l r1,@r14
    c.r[1] = c.r[8];  // 0608D4F2 mov r8,r1
    c.r[1] <<= 2;  // 0608D4F4 shll2 r1
    c.r[1] <<= 2;  // 0608D4F6 shll2 r1
    c.r[2] = ld32(c.r[14]);  // 0608D4F8 mov.l @r14,r2
    c.r[1] |= c.r[2];  // 0608D4FA or r2,r1
    st32(c.r[14], c.r[1]);  // 0608D4FC mov.l r1,@r14
    c.r[4] = ld32(c.r[14]);  // 0608D4FE mov.l @r14,r4
    c.r[9] = ld32(0x0608D51Cu);  // 0608D500 mov.l 0x0608D51C,r9
    { const uint32_t x = c.r[9]; c.pr = 0x0608D506u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608D506u) return; }  // 0608D502 jsr @r9 ; nop
    c.r[14] += 4;  // 0608D506 add #4,r14
    c.r[15] = c.r[14];  // 0608D508 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608D50A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608D50C mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0608D50E mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608D510 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608D512 rts ; nop
}

void f_0608D520(SH2Context& c) {
    ran[2060] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608D520 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0608D522 mov r15,r14
    c.r[1] = c.r[4];  // 0608D524 mov r4,r1
    sh2_set_sr(c, c.r[1] & 0x3F3u); SH2_POLL(c);  // 0608D526 ldc r1,sr
    c.r[15] = c.r[14];  // 0608D528 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608D52A mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608D52C rts ; nop
}

void f_0608D530(SH2Context& c) {
    ran[2061] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608D530 mov.l r14,@-r15
    c.r[15] -= 4;  // 0608D532 add #-4,r15
    c.r[14] = c.r[15];  // 0608D534 mov r15,r14
    c.r[1] = sh2_get_sr(c);  // 0608D536 stc sr,r1
    st32(c.r[14], c.r[1]);  // 0608D538 mov.l r1,@r14
    c.r[0] = ld32(c.r[14]);  // 0608D53A mov.l @r14,r0
    goto L_0608D540;  // 0608D53C bra 0x0608D540 ; nop
L_0608D540:
    c.r[14] += 4;  // 0608D540 add #4,r14
    c.r[15] = c.r[14];  // 0608D542 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608D544 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608D546 rts ; nop
}

void f_0608D54C(SH2Context& c) {
    ran[2062] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608D54C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608D54E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608D550 sts.l pr,@-r15
    c.r[15] -= 20;  // 0608D552 add #-20,r15
    c.r[14] = c.r[15];  // 0608D554 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608D556 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 0608D558 mov.l r5,@(4,r14)
    st32(c.r[14] + 8, c.r[6]);  // 0608D55A mov.l r6,@(8,r14)
    st32(c.r[14] + 12, c.r[7]);  // 0608D55C mov.l r7,@(12,r14)
    c.r[2] = ld32(c.r[14]);  // 0608D55E mov.l @r14,r2
    c.r[1] = 0x3u;  // 0608D560 mov #3,r1
    c.r[1] &= c.r[2];  // 0608D562 and r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0608D564 tst r1,r1
    if (c.t) { goto L_0608D57C; }  // 0608D566 bt 0x0608D57C
    c.r[2] = ld32(c.r[14]);  // 0608D568 mov.l @r14,r2
    c.r[1] = c.r[2];  // 0608D56A mov r2,r1
    c.r[1] += 3;  // 0608D56C add #3,r1
    c.r[2] = 0xFFFFFFFCu;  // 0608D56E mov #-4,r2
    c.r[1] &= c.r[2];  // 0608D570 and r2,r1
    st32(c.r[14], c.r[1]);  // 0608D572 mov.l r1,@r14
    c.r[1] = ld32(c.r[14] + 4);  // 0608D574 mov.l @(4,r14),r1
    c.r[2] = c.r[1];  // 0608D576 mov r1,r2
    c.r[2] -= 4;  // 0608D578 add #-4,r2
    st32(c.r[14] + 4, c.r[2]);  // 0608D57A mov.l r2,@(4,r14)
L_0608D57C:
    c.r[1] = ld32(c.r[14] + 4);  // 0608D57C mov.l @(4,r14),r1
    c.r[2] = 0xFFFFFFFCu;  // 0608D57E mov #-4,r2
    c.r[1] &= c.r[2];  // 0608D580 and r2,r1
    st32(c.r[14] + 4, c.r[1]);  // 0608D582 mov.l r1,@(4,r14)
L_0608D584:
    c.r[1] = ld32(c.r[14] + 32);  // 0608D584 mov.l @(32,r14),r1
    c.t = (int32_t)c.r[1] > 0;  // 0608D586 cmp/pl r1
    if (c.t) { goto L_0608D58E; }  // 0608D588 bt 0x0608D58E
    goto L_0608D5EC;  // 0608D58A bra 0x0608D5EC ; nop
L_0608D58E:
    c.r[1] = ld32(c.r[14] + 4);  // 0608D58E mov.l @(4,r14),r1
    c.r[2] = ld32(c.r[14] + 32);  // 0608D590 mov.l @(32,r14),r2
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 0608D592 cmp/gt r2,r1
    if (!c.t) { goto L_0608D598; }  // 0608D594 bf 0x0608D598
    c.r[1] = ld32(c.r[14] + 32);  // 0608D596 mov.l @(32,r14),r1
L_0608D598:
    st32(c.r[14] + 16, c.r[1]);  // 0608D598 mov.l r1,@(16,r14)
    c.r[2] = ld32(c.r[14] + 16);  // 0608D59A mov.l @(16,r14),r2
    c.r[1] = 0x3u;  // 0608D59C mov #3,r1
    c.r[1] &= c.r[2];  // 0608D59E and r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0608D5A0 tst r1,r1
    if (c.t) { goto L_0608D5BC; }  // 0608D5A2 bt 0x0608D5BC
    c.r[1] = ld32(c.r[14] + 16);  // 0608D5A4 mov.l @(16,r14),r1
    c.r[2] = ld32(c.r[14] + 12);  // 0608D5A6 mov.l @(12,r14),r2
    c.r[3] = ld32(c.r[14] + 8);  // 0608D5A8 mov.l @(8,r14),r3
    c.r[7] = c.r[1];  // 0608D5AA mov r1,r7
    c.r[6] = c.r[2];  // 0608D5AC mov r2,r6
    c.r[5] = c.r[3];  // 0608D5AE mov r3,r5
    c.r[4] = ld32(c.r[14]);  // 0608D5B0 mov.l @r14,r4
    c.r[8] = ld32(0x0608D5FCu);  // 0608D5B2 mov.l 0x0608D5FC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608D5B8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608D5B8u) return; }  // 0608D5B4 jsr @r8 ; nop
    goto L_0608D5E0;  // 0608D5B8 bra 0x0608D5E0 ; nop
L_0608D5BC:
    c.r[1] = ld32(c.r[14] + 16);  // 0608D5BC mov.l @(16,r14),r1
    c.r[2] = c.r[1];  // 0608D5BE mov r1,r2
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 0608D5C0 shar r2
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 0608D5C2 shar r2
    c.r[1] = c.r[2];  // 0608D5C4 mov r2,r1
    c.r[3] = ld32(c.r[14] + 12);  // 0608D5C6 mov.l @(12,r14),r3
    c.r[2] = c.r[3];  // 0608D5C8 mov r3,r2
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 0608D5CA shar r2
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 0608D5CC shar r2
    c.r[3] = c.r[2];  // 0608D5CE mov r2,r3
    c.r[2] = ld32(c.r[14] + 8);  // 0608D5D0 mov.l @(8,r14),r2
    c.r[7] = c.r[1];  // 0608D5D2 mov r1,r7
    c.r[6] = c.r[3];  // 0608D5D4 mov r3,r6
    c.r[5] = c.r[2];  // 0608D5D6 mov r2,r5
    c.r[4] = ld32(c.r[14]);  // 0608D5D8 mov.l @r14,r4
    c.r[8] = ld32(0x0608D600u);  // 0608D5DA mov.l 0x0608D600,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0608D5E0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608D5E0u) return; }  // 0608D5DC jsr @r8 ; nop
L_0608D5E0:
    c.r[1] = ld32(c.r[14] + 32);  // 0608D5E0 mov.l @(32,r14),r1
    c.r[2] = ld32(c.r[14] + 16);  // 0608D5E2 mov.l @(16,r14),r2
    c.r[1] -= c.r[2];  // 0608D5E4 sub r2,r1
    st32(c.r[14] + 32, c.r[1]);  // 0608D5E6 mov.l r1,@(32,r14)
    SH2_POLL(c); goto L_0608D584;  // 0608D5E8 bra 0x0608D584 ; nop
L_0608D5EC:
    c.r[14] += 20;  // 0608D5EC add #20,r14
    c.r[15] = c.r[14];  // 0608D5EE mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608D5F0 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608D5F2 mov.l @r15+,r14
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608D5F4 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608D5F6 rts ; nop
}

void f_0608D604(SH2Context& c) {
    ran[2063] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608D604 mov.l r14,@-r15
    c.r[15] -= 32;  // 0608D606 add #-32,r15
    c.r[14] = c.r[15];  // 0608D608 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608D60A mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 0608D60C mov.l r5,@(4,r14)
    st32(c.r[14] + 8, c.r[6]);  // 0608D60E mov.l r6,@(8,r14)
    st32(c.r[14] + 12, c.r[7]);  // 0608D610 mov.l r7,@(12,r14)
    c.r[2] = ld32(c.r[14]);  // 0608D612 mov.l @r14,r2
    c.r[3] = ld32(c.r[2]);  // 0608D614 mov.l @r2,r3
    st32(c.r[14] + 16, c.r[3]);  // 0608D616 mov.l r3,@(16,r14)
    c.r[2] = ld32(c.r[14] + 16);  // 0608D618 mov.l @(16,r14),r2
    c.r[3] = c.r[2];  // 0608D61A mov r2,r3
    c.r[3] += 4;  // 0608D61C add #4,r3
    st32(c.r[14] + 20, c.r[3]);  // 0608D61E mov.l r3,@(20,r14)
    c.r[2] = ld32(c.r[14] + 16);  // 0608D620 mov.l @(16,r14),r2
    c.r[3] = c.r[2];  // 0608D622 mov r2,r3
    c.r[3] += 56;  // 0608D624 add #56,r3
    st32(c.r[14] + 24, c.r[3]);  // 0608D626 mov.l r3,@(24,r14)
    c.r[2] = ld32(c.r[14] + 24);  // 0608D628 mov.l @(24,r14),r2
    c.r[3] = c.r[2];  // 0608D62A mov r2,r3
    c.r[2] += 116;  // 0608D62C add #116,r2
    c.r[7] = ld32(c.r[14] + 24);  // 0608D62E mov.l @(24,r14),r7
    c.r[3] = c.r[7];  // 0608D630 mov r7,r3
    c.r[7] += 100;  // 0608D632 add #100,r7
    c.r[3] = ld32(c.r[7]);  // 0608D634 mov.l @r7,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x0608D710u);  // 0608D636 mov.w 0x0608D710,r7
    c.macl = c.r[3] * c.r[7];  // 0608D638 mul.l r7,r3
    c.r[3] = c.macl;  // 0608D63A sts macl,r3
    c.r[2] = ld32(c.r[2]);  // 0608D63C mov.l @r2,r2
    c.r[3] += c.r[2];  // 0608D63E add r2,r3
    st32(c.r[14] + 28, c.r[3]);  // 0608D640 mov.l r3,@(28,r14)
    c.r[2] = ld32(c.r[14] + 36);  // 0608D642 mov.l @(36,r14),r2
    c.r[7] = ld32(c.r[14] + 24);  // 0608D644 mov.l @(24,r14),r7
    c.r[3] = c.r[7];  // 0608D646 mov r7,r3
    c.r[7] += 92;  // 0608D648 add #92,r7
    c.r[1] = ld32(c.r[7]);  // 0608D64A mov.l @r7,r1
    c.r[3] = ld32(c.r[14] + 24);  // 0608D64C mov.l @(24,r14),r3
    c.r[7] = ld32(c.r[3] + 40);  // 0608D64E mov.l @(40,r3),r7
    c.r[3] = 0x8u;  // 0608D650 mov #8,r3
    c.t = (int32_t)c.r[7] > (int32_t)c.r[3];  // 0608D652 cmp/gt r3,r7
    if (c.t) { goto L_0608D66C; }  // 0608D654 bt 0x0608D66C
    c.r[7] = ld32(c.r[14] + 24);  // 0608D656 mov.l @(24,r14),r7
    c.r[3] = c.r[7];  // 0608D658 mov r7,r3
    c.r[7] += 108;  // 0608D65A add #108,r7
    c.r[3] = ld32(c.r[7]);  // 0608D65C mov.l @r7,r3
    c.r[6] = ld32(c.r[14] + 28);  // 0608D65E mov.l @(28,r14),r6
    c.r[7] = c.r[3];  // 0608D660 mov r3,r7
    c.r[7] -= c.r[6];  // 0608D662 sub r6,r7
    c.r[3] = c.r[1];  // 0608D664 mov r1,r3
    c.r[3] -= c.r[7];  // 0608D666 sub r7,r3
    goto L_0608D680;  // 0608D668 bra 0x0608D680 ; nop
L_0608D66C:
    c.r[6] = ld32(c.r[14] + 24);  // 0608D66C mov.l @(24,r14),r6
    c.r[7] = c.r[6];  // 0608D66E mov r6,r7
    c.r[6] += 108;  // 0608D670 add #108,r6
    c.r[7] = ld32(c.r[6]);  // 0608D672 mov.l @r6,r7
    c.r[6] = ld32(c.r[14] + 28);  // 0608D674 mov.l @(28,r14),r6
    c.r[7] -= c.r[6];  // 0608D676 sub r6,r7
    c.r[6] = c.r[7];  // 0608D678 mov r7,r6
    c.r[6] += c.r[6];  // 0608D67A add r6,r6
    c.r[3] = c.r[1];  // 0608D67C mov r1,r3
    c.r[3] -= c.r[6];  // 0608D67E sub r6,r3
L_0608D680:
    st32(c.r[2], c.r[3]);  // 0608D680 mov.l r3,@r2
    c.r[2] = ld32(c.r[14] + 36);  // 0608D682 mov.l @(36,r14),r2
    c.r[3] = ld32(c.r[2]);  // 0608D684 mov.l @r2,r3
    c.t = (c.r[3] & c.r[3]) == 0;  // 0608D686 tst r3,r3
    if (!c.t) { goto L_0608D6A0; }  // 0608D688 bf 0x0608D6A0
    c.r[2] = ld32(c.r[14] + 12);  // 0608D68A mov.l @(12,r14),r2
    c.r[3] = 0x0u;  // 0608D68C mov #0,r3
    st32(c.r[2], c.r[3]);  // 0608D68E mov.l r3,@r2
    c.r[2] = ld32(c.r[14] + 4);  // 0608D690 mov.l @(4,r14),r2
    c.r[3] = 0x0u;  // 0608D692 mov #0,r3
    st32(c.r[2], c.r[3]);  // 0608D694 mov.l r3,@r2
    c.r[2] = ld32(c.r[14] + 8);  // 0608D696 mov.l @(8,r14),r2
    c.r[3] = 0x0u;  // 0608D698 mov #0,r3
    st32(c.r[2], c.r[3]);  // 0608D69A mov.l r3,@r2
    goto L_0608D706;  // 0608D69C bra 0x0608D706 ; nop
L_0608D6A0:
    c.r[3] = ld32(c.r[14] + 24);  // 0608D6A0 mov.l @(24,r14),r3
    c.r[2] = c.r[3];  // 0608D6A2 mov r3,r2
    c.r[3] += 96;  // 0608D6A4 add #96,r3
    c.r[2] = ld32(c.r[14] + 36);  // 0608D6A6 mov.l @(36,r14),r2
    c.r[3] = ld32(c.r[3]);  // 0608D6A8 mov.l @r3,r3
    c.r[7] = ld32(c.r[2]);  // 0608D6AA mov.l @r2,r7
    c.r[2] = c.r[3];  // 0608D6AC mov r3,r2
    c.r[2] += c.r[7];  // 0608D6AE add r7,r2
    c.r[7] = ld32(c.r[14] + 24);  // 0608D6B0 mov.l @(24,r14),r7
    c.r[3] = c.r[7];  // 0608D6B2 mov r7,r3
    c.r[7] += 92;  // 0608D6B4 add #92,r7
    c.r[3] = ld32(c.r[7]);  // 0608D6B6 mov.l @r7,r3
    c.t = (int32_t)c.r[2] > (int32_t)c.r[3];  // 0608D6B8 cmp/gt r3,r2
    if (!c.t) { goto L_0608D6D6; }  // 0608D6BA bf 0x0608D6D6
    c.r[2] = ld32(c.r[14] + 12);  // 0608D6BC mov.l @(12,r14),r2
    c.r[3] = ld32(c.r[14] + 24);  // 0608D6BE mov.l @(24,r14),r3
    c.r[7] = c.r[3];  // 0608D6C0 mov r3,r7
    c.r[3] += 92;  // 0608D6C2 add #92,r3
    c.r[6] = ld32(c.r[14] + 24);  // 0608D6C4 mov.l @(24,r14),r6
    c.r[7] = c.r[6];  // 0608D6C6 mov r6,r7
    c.r[6] += 96;  // 0608D6C8 add #96,r6
    c.r[3] = ld32(c.r[3]);  // 0608D6CA mov.l @r3,r3
    c.r[7] = ld32(c.r[6]);  // 0608D6CC mov.l @r6,r7
    c.r[3] -= c.r[7];  // 0608D6CE sub r7,r3
    st32(c.r[2], c.r[3]);  // 0608D6D0 mov.l r3,@r2
    goto L_0608D6DE;  // 0608D6D2 bra 0x0608D6DE ; nop
L_0608D6D6:
    c.r[2] = ld32(c.r[14] + 12);  // 0608D6D6 mov.l @(12,r14),r2
    c.r[3] = ld32(c.r[14] + 36);  // 0608D6D8 mov.l @(36,r14),r3
    c.r[7] = ld32(c.r[3]);  // 0608D6DA mov.l @r3,r7
    st32(c.r[2], c.r[7]);  // 0608D6DC mov.l r7,@r2
L_0608D6DE:
    c.r[2] = ld32(c.r[14] + 4);  // 0608D6DE mov.l @(4,r14),r2
    c.r[3] = ld32(c.r[14] + 20);  // 0608D6E0 mov.l @(20,r14),r3
    c.r[6] = ld32(c.r[14] + 24);  // 0608D6E2 mov.l @(24,r14),r6
    c.r[7] = c.r[6];  // 0608D6E4 mov r6,r7
    c.r[6] += 96;  // 0608D6E6 add #96,r6
    c.r[3] = ld32(c.r[3] + 8);  // 0608D6E8 mov.l @(8,r3),r3
    c.r[7] = ld32(c.r[6]);  // 0608D6EA mov.l @r6,r7
    c.r[3] += c.r[7];  // 0608D6EC add r7,r3
    st32(c.r[2], c.r[3]);  // 0608D6EE mov.l r3,@r2
    c.r[2] = ld32(c.r[14] + 8);  // 0608D6F0 mov.l @(8,r14),r2
    c.r[3] = ld32(c.r[14] + 24);  // 0608D6F2 mov.l @(24,r14),r3
    c.r[7] = c.r[3];  // 0608D6F4 mov r3,r7
    c.r[3] += 88;  // 0608D6F6 add #88,r3
    c.r[6] = ld32(c.r[14] + 24);  // 0608D6F8 mov.l @(24,r14),r6
    c.r[7] = c.r[6];  // 0608D6FA mov r6,r7
    c.r[6] += 96;  // 0608D6FC add #96,r6
    c.r[3] = ld32(c.r[3]);  // 0608D6FE mov.l @r3,r3
    c.r[7] = ld32(c.r[6]);  // 0608D700 mov.l @r6,r7
    c.r[3] += c.r[7];  // 0608D702 add r7,r3
    st32(c.r[2], c.r[3]);  // 0608D704 mov.l r3,@r2
L_0608D706:
    c.r[14] += 32;  // 0608D706 add #32,r14
    c.r[15] = c.r[14];  // 0608D708 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608D70A mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608D70C rts ; nop
}

void f_0608D714(SH2Context& c) {
    ran[2064] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608D714 mov.l r14,@-r15
    c.r[15] -= 20;  // 0608D716 add #-20,r15
    c.r[14] = c.r[15];  // 0608D718 mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608D71A mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 0608D71C mov.l r5,@(4,r14)
    c.r[1] = ld32(c.r[14]);  // 0608D71E mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 0608D720 mov.l @r1,r2
    st32(c.r[14] + 8, c.r[2]);  // 0608D722 mov.l r2,@(8,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 0608D724 mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 0608D726 mov r1,r2
    c.r[2] += 56;  // 0608D728 add #56,r2
    st32(c.r[14] + 12, c.r[2]);  // 0608D72A mov.l r2,@(12,r14)
    c.r[1] = ld32(c.r[14] + 4);  // 0608D72C mov.l @(4,r14),r1
    c.r[2] = ld32(c.r[14] + 12);  // 0608D72E mov.l @(12,r14),r2
    c.r[3] = ld32(c.r[2] + 40);  // 0608D730 mov.l @(40,r2),r3
    c.r[2] = 0x8u;  // 0608D732 mov #8,r2
    c.t = (int32_t)c.r[3] > (int32_t)c.r[2];  // 0608D734 cmp/gt r2,r3
    if (!c.t) { goto L_0608D73E; }  // 0608D736 bf 0x0608D73E
    c.r[2] = c.r[1];  // 0608D738 mov r1,r2
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 0608D73A shar r2
    c.r[1] = c.r[2];  // 0608D73C mov r2,r1
L_0608D73E:
    st32(c.r[14] + 16, c.r[1]);  // 0608D73E mov.l r1,@(16,r14)
    c.r[1] = ld32(c.r[14] + 12);  // 0608D740 mov.l @(12,r14),r1
    c.r[2] = c.r[1];  // 0608D742 mov r1,r2
    c.r[1] += 104;  // 0608D744 add #104,r1
    c.r[3] = ld32(c.r[14] + 12);  // 0608D746 mov.l @(12,r14),r3
    c.r[2] = c.r[3];  // 0608D748 mov r3,r2
    c.r[3] += 104;  // 0608D74A add #104,r3
    c.r[2] = ld32(c.r[3]);  // 0608D74C mov.l @r3,r2
    c.r[3] = ld32(c.r[14] + 16);  // 0608D74E mov.l @(16,r14),r3
    c.r[2] += c.r[3];  // 0608D750 add r3,r2
    st32(c.r[1], c.r[2]);  // 0608D752 mov.l r2,@r1
    c.r[1] = ld32(c.r[14] + 12);  // 0608D754 mov.l @(12,r14),r1
    c.r[2] = c.r[1];  // 0608D756 mov r1,r2
    c.r[1] += 108;  // 0608D758 add #108,r1
    c.r[3] = ld32(c.r[14] + 12);  // 0608D75A mov.l @(12,r14),r3
    c.r[2] = c.r[3];  // 0608D75C mov r3,r2
    c.r[3] += 108;  // 0608D75E add #108,r3
    c.r[2] = ld32(c.r[3]);  // 0608D760 mov.l @r3,r2
    c.r[3] = ld32(c.r[14] + 16);  // 0608D762 mov.l @(16,r14),r3
    c.r[2] += c.r[3];  // 0608D764 add r3,r2
    st32(c.r[1], c.r[2]);  // 0608D766 mov.l r2,@r1
    c.r[1] = ld32(c.r[14] + 12);  // 0608D768 mov.l @(12,r14),r1
    c.r[2] = c.r[1];  // 0608D76A mov r1,r2
    c.r[1] += 96;  // 0608D76C add #96,r1
    c.r[3] = ld32(c.r[14] + 12);  // 0608D76E mov.l @(12,r14),r3
    c.r[2] = c.r[3];  // 0608D770 mov r3,r2
    c.r[3] += 96;  // 0608D772 add #96,r3
    c.r[2] = ld32(c.r[3]);  // 0608D774 mov.l @r3,r2
    c.r[3] = ld32(c.r[14] + 4);  // 0608D776 mov.l @(4,r14),r3
    c.r[2] += c.r[3];  // 0608D778 add r3,r2
    st32(c.r[1], c.r[2]);  // 0608D77A mov.l r2,@r1
    c.r[1] = ld32(c.r[14] + 12);  // 0608D77C mov.l @(12,r14),r1
    c.r[2] = c.r[1];  // 0608D77E mov r1,r2
    c.r[1] += 96;  // 0608D780 add #96,r1
    c.r[3] = ld32(c.r[14] + 12);  // 0608D782 mov.l @(12,r14),r3
    c.r[2] = c.r[3];  // 0608D784 mov r3,r2
    c.r[3] += 92;  // 0608D786 add #92,r3
    c.r[1] = ld32(c.r[1]);  // 0608D788 mov.l @r1,r1
    c.r[2] = ld32(c.r[3]);  // 0608D78A mov.l @r3,r2
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[2];  // 0608D78C cmp/ge r2,r1
    if (!c.t) { goto L_0608D7B6; }  // 0608D78E bf 0x0608D7B6
    c.r[1] = ld32(c.r[14] + 12);  // 0608D790 mov.l @(12,r14),r1
    c.r[2] = c.r[1];  // 0608D792 mov r1,r2
    c.r[1] += 96;  // 0608D794 add #96,r1
    c.r[2] = ld32(c.r[14] + 12);  // 0608D796 mov.l @(12,r14),r2
    c.r[3] = c.r[2];  // 0608D798 mov r2,r3
    c.r[2] += 96;  // 0608D79A add #96,r2
    c.r[7] = ld32(c.r[14] + 12);  // 0608D79C mov.l @(12,r14),r7
    c.r[3] = c.r[7];  // 0608D79E mov r7,r3
    c.r[7] += 92;  // 0608D7A0 add #92,r7
    c.r[2] = ld32(c.r[2]);  // 0608D7A2 mov.l @r2,r2
    c.r[3] = ld32(c.r[7]);  // 0608D7A4 mov.l @r7,r3
    c.r[2] -= c.r[3];  // 0608D7A6 sub r3,r2
    st32(c.r[1], c.r[2]);  // 0608D7A8 mov.l r2,@r1
    c.r[2] = ld32(c.r[14] + 12);  // 0608D7AA mov.l @(12,r14),r2
    c.r[1] = c.r[2];  // 0608D7AC mov r2,r1
    c.r[2] += 96;  // 0608D7AE add #96,r2
    c.r[1] = ld32(c.r[2]);  // 0608D7B0 mov.l @r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0608D7B2 tst r1,r1
    if (c.t) { goto L_0608D7B6; }  // 0608D7B4 bt 0x0608D7B6
L_0608D7B6:
    goto L_0608D7BA;  // 0608D7B6 bra 0x0608D7BA ; nop
L_0608D7BA:
    c.r[14] += 20;  // 0608D7BA add #20,r14
    c.r[15] = c.r[14];  // 0608D7BC mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608D7BE mov.l @r15+,r14
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608D7C0 rts ; nop
}

void f_0608D7C4(SH2Context& c) {
    ran[2065] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0608D7C4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0608D7C6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0608D7C8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0608D7CA sts.l pr,@-r15
    c.r[15] -= 40;  // 0608D7CC add #-40,r15
    c.r[14] = c.r[15];  // 0608D7CE mov r15,r14
    st32(c.r[14], c.r[4]);  // 0608D7D0 mov.l r4,@r14
    st32(c.r[14] + 4, c.r[5]);  // 0608D7D2 mov.l r5,@(4,r14)
    c.r[1] = ld32(c.r[14]);  // 0608D7D4 mov.l @r14,r1
    c.r[2] = ld32(c.r[1]);  // 0608D7D6 mov.l @r1,r2
    st32(c.r[14] + 8, c.r[2]);  // 0608D7D8 mov.l r2,@(8,r14)
    c.r[1] = ld32(c.r[14] + 8);  // 0608D7DA mov.l @(8,r14),r1
    c.r[2] = c.r[1];  // 0608D7DC mov r1,r2
    c.r[2] += 56;  // 0608D7DE add #56,r2
    st32(c.r[14] + 12, c.r[2]);  // 0608D7E0 mov.l r2,@(12,r14)
    c.r[1] = c.r[14];  // 0608D7E2 mov r14,r1
    c.r[1] += 16;  // 0608D7E4 add #16,r1
    c.r[2] = c.r[14];  // 0608D7E6 mov r14,r2
    c.r[2] += 32;  // 0608D7E8 add #32,r2
    c.r[3] = c.r[14];  // 0608D7EA mov r14,r3
    c.r[3] += 28;  // 0608D7EC add #28,r3
    c.r[7] = c.r[14];  // 0608D7EE mov r14,r7
    c.r[7] += 20;  // 0608D7F0 add #20,r7
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 0608D7F2 mov.l r7,@-r15
    c.r[7] = c.r[1];  // 0608D7F4 mov r1,r7
    c.r[6] = c.r[2];  // 0608D7F6 mov r2,r6
    c.r[5] = c.r[3];  // 0608D7F8 mov r3,r5
    c.r[4] = ld32(c.r[14]);  // 0608D7FA mov.l @r14,r4
    c.r[9] = ld32(0x0608D914u);  // 0608D7FC mov.l 0x0608D914,r9
    { const uint32_t x = c.r[9]; c.pr = 0x0608D802u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608D802u) return; }  // 0608D7FE jsr @r9 ; nop
    c.r[15] += 4;  // 0608D802 add #4,r15
    c.r[1] = ld32(c.r[14] + 4);  // 0608D804 mov.l @(4,r14),r1
    c.r[2] = ld32(c.r[14] + 16);  // 0608D806 mov.l @(16,r14),r2
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 0608D808 cmp/gt r2,r1
    if (!c.t) { goto L_0608D810; }  // 0608D80A bf 0x0608D810
    goto L_0608D89E;  // 0608D80C bra 0x0608D89E ; nop
L_0608D810:
    c.r[1] = ld32(c.r[14] + 12);  // 0608D810 mov.l @(12,r14),r1
    c.r[2] = c.r[1];  // 0608D812 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608D904u);  // 0608D814 mov.w 0x0608D904,r3
    c.r[1] += c.r[3];  // 0608D816 add r3,r1
    c.r[2] = 0x0u;  // 0608D818 mov #0,r2
    st32(c.r[1], c.r[2]);  // 0608D81A mov.l r2,@r1
    c.r[2] = ld32(c.r[14] + 12);  // 0608D81C mov.l @(12,r14),r2
    c.r[1] = c.r[2];  // 0608D81E mov r2,r1
    c.r[2] += 76;  // 0608D820 add #76,r2
    c.r[1] = ld32(c.r[2]);  // 0608D822 mov.l @r2,r1
    st32(c.r[14] + 36, c.r[1]);  // 0608D824 mov.l r1,@(36,r14)
    c.r[1] = ld32(c.r[14] + 12);  // 0608D826 mov.l @(12,r14),r1
    c.r[2] = c.r[1];  // 0608D828 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608D906u);  // 0608D82A mov.w 0x0608D906,r3
    c.r[1] += c.r[3];  // 0608D82C add r3,r1
    c.r[2] = ld32(c.r[14] + 12);  // 0608D82E mov.l @(12,r14),r2
    c.r[0] = ld32(c.r[2] + 36);  // 0608D830 mov.l @(36,r2),r0
    c.t = c.r[0] == 0x1u;  // 0608D832 cmp/eq #1,r0
    if (c.t) { goto L_0608D84A; }  // 0608D834 bt 0x0608D84A
    c.r[2] = ld32(c.r[14] + 12);  // 0608D836 mov.l @(12,r14),r2
    c.r[0] = ld32(c.r[2] + 28);  // 0608D838 mov.l @(28,r2),r0
    c.t = c.r[0] == 0x1u;  // 0608D83A cmp/eq #1,r0
    if (!c.t) { goto L_0608D844; }  // 0608D83C bf 0x0608D844
    c.r[2] = ld32(c.r[14] + 32);  // 0608D83E mov.l @(32,r14),r2
    goto L_0608D846;  // 0608D840 bra 0x0608D846 ; nop
L_0608D844:
    c.r[2] = ld32(c.r[14] + 28);  // 0608D844 mov.l @(28,r14),r2
L_0608D846:
    goto L_0608D84C;  // 0608D846 bra 0x0608D84C ; nop
L_0608D84A:
    c.r[2] = ld32(c.r[14] + 28);  // 0608D84A mov.l @(28,r14),r2
L_0608D84C:
    st32(c.r[1], c.r[2]);  // 0608D84C mov.l r2,@r1
    c.r[1] = ld32(c.r[14] + 12);  // 0608D84E mov.l @(12,r14),r1
    c.r[2] = c.r[1];  // 0608D850 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608D908u);  // 0608D852 mov.w 0x0608D908,r3
    c.r[1] += c.r[3];  // 0608D854 add r3,r1
    c.r[2] = ld32(c.r[14] + 12);  // 0608D856 mov.l @(12,r14),r2
    c.r[0] = ld32(c.r[2] + 36);  // 0608D858 mov.l @(36,r2),r0
    c.t = c.r[0] == 0x1u;  // 0608D85A cmp/eq #1,r0
    if (c.t) { goto L_0608D872; }  // 0608D85C bt 0x0608D872
    c.r[2] = ld32(c.r[14] + 12);  // 0608D85E mov.l @(12,r14),r2
    c.r[0] = ld32(c.r[2] + 28);  // 0608D860 mov.l @(28,r2),r0
    c.t = c.r[0] == 0x1u;  // 0608D862 cmp/eq #1,r0
    if (!c.t) { goto L_0608D86C; }  // 0608D864 bf 0x0608D86C
    c.r[2] = ld32(c.r[14] + 28);  // 0608D866 mov.l @(28,r14),r2
    goto L_0608D86E;  // 0608D868 bra 0x0608D86E ; nop
L_0608D86C:
    c.r[2] = ld32(c.r[14] + 32);  // 0608D86C mov.l @(32,r14),r2
L_0608D86E:
    goto L_0608D874;  // 0608D86E bra 0x0608D874 ; nop
L_0608D872:
    c.r[2] = 0x0u;  // 0608D872 mov #0,r2
L_0608D874:
    st32(c.r[1], c.r[2]);  // 0608D874 mov.l r2,@r1
    c.r[1] = ld32(c.r[14] + 12);  // 0608D876 mov.l @(12,r14),r1
    c.r[2] = c.r[1];  // 0608D878 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608D90Au);  // 0608D87A mov.w 0x0608D90A,r3
    c.r[1] += c.r[3];  // 0608D87C add r3,r1
    c.r[2] = ld32(c.r[14] + 36);  // 0608D87E mov.l @(36,r14),r2
    st32(c.r[1], c.r[2]);  // 0608D880 mov.l r2,@r1
    c.r[1] = ld32(c.r[14] + 12);  // 0608D882 mov.l @(12,r14),r1
    c.r[2] = c.r[1];  // 0608D884 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608D90Cu);  // 0608D886 mov.w 0x0608D90C,r3
    c.r[1] += c.r[3];  // 0608D888 add r3,r1
    c.r[2] = ld32(c.r[14] + 4);  // 0608D88A mov.l @(4,r14),r2
    st32(c.r[1], c.r[2]);  // 0608D88C mov.l r2,@r1
    c.r[1] = ld32(c.r[14] + 4);  // 0608D88E mov.l @(4,r14),r1
    c.r[5] = c.r[1];  // 0608D890 mov r1,r5
    c.r[4] = ld32(c.r[14]);  // 0608D892 mov.l @r14,r4
    c.r[9] = ld32(0x0608D918u);  // 0608D894 mov.l 0x0608D918,r9
    { const uint32_t x = c.r[9]; c.pr = 0x0608D89Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608D89Au) return; }  // 0608D896 jsr @r9 ; nop
    goto L_0608DA1C;  // 0608D89A bra 0x0608DA1C ; nop
L_0608D89E:
    c.r[1] = ld32(c.r[14] + 12);  // 0608D89E mov.l @(12,r14),r1
    c.r[2] = c.r[1];  // 0608D8A0 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608D904u);  // 0608D8A2 mov.w 0x0608D904,r3
    c.r[1] += c.r[3];  // 0608D8A4 add r3,r1
    c.r[2] = 0x1u;  // 0608D8A6 mov #1,r2
    st32(c.r[1], c.r[2]);  // 0608D8A8 mov.l r2,@r1
    c.r[2] = ld32(c.r[14] + 12);  // 0608D8AA mov.l @(12,r14),r2
    c.r[1] = c.r[2];  // 0608D8AC mov r2,r1
    c.r[2] += 76;  // 0608D8AE add #76,r2
    c.r[1] = ld32(c.r[2]);  // 0608D8B0 mov.l @r2,r1
    st32(c.r[14] + 36, c.r[1]);  // 0608D8B2 mov.l r1,@(36,r14)
    c.r[1] = ld32(c.r[14] + 12);  // 0608D8B4 mov.l @(12,r14),r1
    c.r[2] = c.r[1];  // 0608D8B6 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608D90Eu);  // 0608D8B8 mov.w 0x0608D90E,r3
    c.r[1] += c.r[3];  // 0608D8BA add r3,r1
    c.r[2] = ld32(c.r[14] + 12);  // 0608D8BC mov.l @(12,r14),r2
    c.r[0] = ld32(c.r[2] + 36);  // 0608D8BE mov.l @(36,r2),r0
    c.t = c.r[0] == 0x1u;  // 0608D8C0 cmp/eq #1,r0
    if (c.t) { goto L_0608D8D8; }  // 0608D8C2 bt 0x0608D8D8
    c.r[2] = ld32(c.r[14] + 12);  // 0608D8C4 mov.l @(12,r14),r2
    c.r[0] = ld32(c.r[2] + 28);  // 0608D8C6 mov.l @(28,r2),r0
    c.t = c.r[0] == 0x1u;  // 0608D8C8 cmp/eq #1,r0
    if (!c.t) { goto L_0608D8D2; }  // 0608D8CA bf 0x0608D8D2
    c.r[2] = ld32(c.r[14] + 32);  // 0608D8CC mov.l @(32,r14),r2
    goto L_0608D8D4;  // 0608D8CE bra 0x0608D8D4 ; nop
L_0608D8D2:
    c.r[2] = ld32(c.r[14] + 28);  // 0608D8D2 mov.l @(28,r14),r2
L_0608D8D4:
    goto L_0608D8DA;  // 0608D8D4 bra 0x0608D8DA ; nop
L_0608D8D8:
    c.r[2] = ld32(c.r[14] + 28);  // 0608D8D8 mov.l @(28,r14),r2
L_0608D8DA:
    st32(c.r[1], c.r[2]);  // 0608D8DA mov.l r2,@r1
    c.r[1] = ld32(c.r[14] + 12);  // 0608D8DC mov.l @(12,r14),r1
    c.r[2] = c.r[1];  // 0608D8DE mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608D910u);  // 0608D8E0 mov.w 0x0608D910,r3
    c.r[1] += c.r[3];  // 0608D8E2 add r3,r1
    c.r[2] = ld32(c.r[14] + 12);  // 0608D8E4 mov.l @(12,r14),r2
    c.r[0] = ld32(c.r[2] + 36);  // 0608D8E6 mov.l @(36,r2),r0
    c.t = c.r[0] == 0x1u;  // 0608D8E8 cmp/eq #1,r0
    if (!c.t) { goto L_0608D8F0; }  // 0608D8EA bf 0x0608D8F0
    goto L_0608D91C;  // 0608D8EC bra 0x0608D91C ; nop
L_0608D8F0:
    c.r[2] = ld32(c.r[14] + 12);  // 0608D8F0 mov.l @(12,r14),r2
    c.r[0] = ld32(c.r[2] + 28);  // 0608D8F2 mov.l @(28,r2),r0
    c.t = c.r[0] == 0x1u;  // 0608D8F4 cmp/eq #1,r0
    if (!c.t) { goto L_0608D8FE; }  // 0608D8F6 bf 0x0608D8FE
    c.r[2] = ld32(c.r[14] + 28);  // 0608D8F8 mov.l @(28,r14),r2
    goto L_0608D900;  // 0608D8FA bra 0x0608D900 ; nop
L_0608D8FE:
    c.r[2] = ld32(c.r[14] + 32);  // 0608D8FE mov.l @(32,r14),r2
L_0608D900:
    goto L_0608D91E;  // 0608D900 bra 0x0608D91E ; nop
L_0608D91C:
    c.r[2] = 0x0u;  // 0608D91C mov #0,r2
L_0608D91E:
    st32(c.r[1], c.r[2]);  // 0608D91E mov.l r2,@r1
    c.r[1] = ld32(c.r[14] + 12);  // 0608D920 mov.l @(12,r14),r1
    c.r[2] = c.r[1];  // 0608D922 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608DA2Cu);  // 0608D924 mov.w 0x0608DA2C,r3
    c.r[1] += c.r[3];  // 0608D926 add r3,r1
    c.r[2] = ld32(c.r[14] + 36);  // 0608D928 mov.l @(36,r14),r2
    st32(c.r[1], c.r[2]);  // 0608D92A mov.l r2,@r1
    c.r[1] = ld32(c.r[14] + 12);  // 0608D92C mov.l @(12,r14),r1
    c.r[2] = c.r[1];  // 0608D92E mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608DA2Eu);  // 0608D930 mov.w 0x0608DA2E,r3
    c.r[1] += c.r[3];  // 0608D932 add r3,r1
    c.r[2] = ld32(c.r[14] + 16);  // 0608D934 mov.l @(16,r14),r2
    st32(c.r[1], c.r[2]);  // 0608D936 mov.l r2,@r1
    c.r[1] = ld32(c.r[14] + 16);  // 0608D938 mov.l @(16,r14),r1
    c.r[5] = c.r[1];  // 0608D93A mov r1,r5
    c.r[4] = ld32(c.r[14]);  // 0608D93C mov.l @r14,r4
    c.r[9] = ld32(0x0608DA38u);  // 0608D93E mov.l 0x0608DA38,r9
    { const uint32_t x = c.r[9]; c.pr = 0x0608D944u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608D944u) return; }  // 0608D940 jsr @r9 ; nop
    c.r[1] = ld32(c.r[14] + 4);  // 0608D944 mov.l @(4,r14),r1
    c.r[2] = ld32(c.r[14] + 16);  // 0608D946 mov.l @(16,r14),r2
    c.r[1] -= c.r[2];  // 0608D948 sub r2,r1
    st32(c.r[14] + 24, c.r[1]);  // 0608D94A mov.l r1,@(24,r14)
    c.r[2] = ld32(c.r[14] + 12);  // 0608D94C mov.l @(12,r14),r2
    c.r[1] = c.r[2];  // 0608D94E mov r2,r1
    c.r[2] += 76;  // 0608D950 add #76,r2
    c.r[8] = ld32(c.r[2]);  // 0608D952 mov.l @r2,r8
    c.r[1] = ld32(c.r[14] + 12);  // 0608D954 mov.l @(12,r14),r1
    c.r[0] = ld32(c.r[1] + 36);  // 0608D956 mov.l @(36,r1),r0
    c.t = c.r[0] == 0x1u;  // 0608D958 cmp/eq #1,r0
    if (!c.t) { goto L_0608D960; }  // 0608D95A bf 0x0608D960
    goto L_0608D96E;  // 0608D95C bra 0x0608D96E ; nop
L_0608D960:
    c.r[1] = ld32(c.r[14] + 16);  // 0608D960 mov.l @(16,r14),r1
    c.r[2] = c.r[1];  // 0608D962 mov r1,r2
    c.r[2] += c.r[2];  // 0608D964 add r2,r2
    c.r[1] = c.r[8];  // 0608D966 mov r8,r1
    c.r[1] += c.r[2];  // 0608D968 add r2,r1
    goto L_0608D974;  // 0608D96A bra 0x0608D974 ; nop
L_0608D96E:
    c.r[2] = ld32(c.r[14] + 16);  // 0608D96E mov.l @(16,r14),r2
    c.r[1] = c.r[8];  // 0608D970 mov r8,r1
    c.r[1] += c.r[2];  // 0608D972 add r2,r1
L_0608D974:
    st32(c.r[14] + 36, c.r[1]);  // 0608D974 mov.l r1,@(36,r14)
    c.r[1] = c.r[14];  // 0608D976 mov r14,r1
    c.r[1] += 16;  // 0608D978 add #16,r1
    c.r[2] = c.r[14];  // 0608D97A mov r14,r2
    c.r[2] += 32;  // 0608D97C add #32,r2
    c.r[3] = c.r[14];  // 0608D97E mov r14,r3
    c.r[3] += 28;  // 0608D980 add #28,r3
    c.r[7] = c.r[14];  // 0608D982 mov r14,r7
    c.r[7] += 20;  // 0608D984 add #20,r7
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 0608D986 mov.l r7,@-r15
    c.r[7] = c.r[1];  // 0608D988 mov r1,r7
    c.r[6] = c.r[2];  // 0608D98A mov r2,r6
    c.r[5] = c.r[3];  // 0608D98C mov r3,r5
    c.r[4] = ld32(c.r[14]);  // 0608D98E mov.l @r14,r4
    c.r[9] = ld32(0x0608DA3Cu);  // 0608D990 mov.l 0x0608DA3C,r9
    { const uint32_t x = c.r[9]; c.pr = 0x0608D996u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608D996u) return; }  // 0608D992 jsr @r9 ; nop
    c.r[15] += 4;  // 0608D996 add #4,r15
    c.r[1] = ld32(c.r[14] + 12);  // 0608D998 mov.l @(12,r14),r1
    c.r[2] = c.r[1];  // 0608D99A mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608DA30u);  // 0608D99C mov.w 0x0608DA30,r3
    c.r[1] += c.r[3];  // 0608D99E add r3,r1
    c.r[2] = ld32(c.r[14] + 12);  // 0608D9A0 mov.l @(12,r14),r2
    c.r[0] = ld32(c.r[2] + 36);  // 0608D9A2 mov.l @(36,r2),r0
    c.t = c.r[0] == 0x1u;  // 0608D9A4 cmp/eq #1,r0
    if (!c.t) { goto L_0608D9AC; }  // 0608D9A6 bf 0x0608D9AC
    goto L_0608D9C4;  // 0608D9A8 bra 0x0608D9C4 ; nop
L_0608D9AC:
    c.r[2] = ld32(c.r[14] + 12);  // 0608D9AC mov.l @(12,r14),r2
    c.r[0] = ld32(c.r[2] + 28);  // 0608D9AE mov.l @(28,r2),r0
    c.t = c.r[0] == 0x1u;  // 0608D9B0 cmp/eq #1,r0
    if (c.t) { goto L_0608D9B8; }  // 0608D9B2 bt 0x0608D9B8
    goto L_0608D9BE;  // 0608D9B4 bra 0x0608D9BE ; nop
L_0608D9B8:
    c.r[2] = ld32(c.r[14] + 32);  // 0608D9B8 mov.l @(32,r14),r2
    goto L_0608D9C0;  // 0608D9BA bra 0x0608D9C0 ; nop
L_0608D9BE:
    c.r[2] = ld32(c.r[14] + 28);  // 0608D9BE mov.l @(28,r14),r2
L_0608D9C0:
    goto L_0608D9C6;  // 0608D9C0 bra 0x0608D9C6 ; nop
L_0608D9C4:
    c.r[2] = ld32(c.r[14] + 28);  // 0608D9C4 mov.l @(28,r14),r2
L_0608D9C6:
    st32(c.r[1], c.r[2]);  // 0608D9C6 mov.l r2,@r1
    c.r[1] = ld32(c.r[14] + 12);  // 0608D9C8 mov.l @(12,r14),r1
    c.r[2] = c.r[1];  // 0608D9CA mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608DA32u);  // 0608D9CC mov.w 0x0608DA32,r3
    c.r[1] += c.r[3];  // 0608D9CE add r3,r1
    c.r[2] = ld32(c.r[14] + 12);  // 0608D9D0 mov.l @(12,r14),r2
    c.r[0] = ld32(c.r[2] + 36);  // 0608D9D2 mov.l @(36,r2),r0
    c.t = c.r[0] == 0x1u;  // 0608D9D4 cmp/eq #1,r0
    if (!c.t) { goto L_0608D9DC; }  // 0608D9D6 bf 0x0608D9DC
    goto L_0608D9F4;  // 0608D9D8 bra 0x0608D9F4 ; nop
L_0608D9DC:
    c.r[2] = ld32(c.r[14] + 12);  // 0608D9DC mov.l @(12,r14),r2
    c.r[0] = ld32(c.r[2] + 28);  // 0608D9DE mov.l @(28,r2),r0
    c.t = c.r[0] == 0x1u;  // 0608D9E0 cmp/eq #1,r0
    if (c.t) { goto L_0608D9E8; }  // 0608D9E2 bt 0x0608D9E8
    goto L_0608D9EE;  // 0608D9E4 bra 0x0608D9EE ; nop
L_0608D9E8:
    c.r[2] = ld32(c.r[14] + 28);  // 0608D9E8 mov.l @(28,r14),r2
    goto L_0608D9F0;  // 0608D9EA bra 0x0608D9F0 ; nop
L_0608D9EE:
    c.r[2] = ld32(c.r[14] + 32);  // 0608D9EE mov.l @(32,r14),r2
L_0608D9F0:
    goto L_0608D9F6;  // 0608D9F0 bra 0x0608D9F6 ; nop
L_0608D9F4:
    c.r[2] = 0x0u;  // 0608D9F4 mov #0,r2
L_0608D9F6:
    st32(c.r[1], c.r[2]);  // 0608D9F6 mov.l r2,@r1
    c.r[1] = ld32(c.r[14] + 12);  // 0608D9F8 mov.l @(12,r14),r1
    c.r[2] = c.r[1];  // 0608D9FA mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608DA34u);  // 0608D9FC mov.w 0x0608DA34,r3
    c.r[1] += c.r[3];  // 0608D9FE add r3,r1
    c.r[2] = ld32(c.r[14] + 36);  // 0608DA00 mov.l @(36,r14),r2
    st32(c.r[1], c.r[2]);  // 0608DA02 mov.l r2,@r1
    c.r[1] = ld32(c.r[14] + 12);  // 0608DA04 mov.l @(12,r14),r1
    c.r[2] = c.r[1];  // 0608DA06 mov r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0608DA36u);  // 0608DA08 mov.w 0x0608DA36,r3
    c.r[1] += c.r[3];  // 0608DA0A add r3,r1
    c.r[2] = ld32(c.r[14] + 24);  // 0608DA0C mov.l @(24,r14),r2
    st32(c.r[1], c.r[2]);  // 0608DA0E mov.l r2,@r1
    c.r[1] = ld32(c.r[14] + 24);  // 0608DA10 mov.l @(24,r14),r1
    c.r[5] = c.r[1];  // 0608DA12 mov r1,r5
    c.r[4] = ld32(c.r[14]);  // 0608DA14 mov.l @r14,r4
    c.r[9] = ld32(0x0608DA38u);  // 0608DA16 mov.l 0x0608DA38,r9
    { const uint32_t x = c.r[9]; c.pr = 0x0608DA1Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0608DA1Cu) return; }  // 0608DA18 jsr @r9 ; nop
L_0608DA1C:
    c.r[14] += 40;  // 0608DA1C add #40,r14
    c.r[15] = c.r[14];  // 0608DA1E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0608DA20 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0608DA22 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0608DA24 mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0608DA26 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0608DA28 rts ; nop
}

}  // namespace p_srwfin_kor
