#include "p_srwfin_installed_funcs.h"

namespace p_srwfin_installed {

void f_0601D68C(SH2Context& c) {
    ran[321] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601D68C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0601D68E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0601D690 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601D692 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601D694 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0601D696 mov r15,r14
    c.r[8] = c.r[4] & 0xFFFFu;  // 0601D698 extu.w r4,r8
    c.r[10] = 0x0u;  // 0601D69A mov #0,r10
    c.r[9] = ld32(0x0601D6C4u);  // 0601D69C mov.l 0x0601D6C4,r9
L_0601D69E:
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0601D69E mov.l r10,@-r15
    c.r[7] = ld32(0x0601D6C8u);  // 0601D6A0 mov.l 0x0601D6C8,r7
    c.r[6] = c.r[8];  // 0601D6A2 mov r8,r6
    c.r[5] = 0xFFFFFFFFu;  // 0601D6A4 mov #-1,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0601D6AAu; c.r[4] = 0x14u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601D6AAu) return; }  // 0601D6A6 jsr @r9 ; mov #20,r4
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0601D6AA cmp/eq #-1,r0
    { const bool k = c.t; c.r[15] += 4; if (k) { SH2_POLL(c); goto L_0601D69E; } }  // 0601D6AC bt/s 0x0601D69E ; add #4,r15
    c.r[2] = ld32(0x0601D6CCu);  // 0601D6B0 mov.l 0x0601D6CC,r2
    c.r[1] = ld32(0x0601D6C8u);  // 0601D6B2 mov.l 0x0601D6C8,r1
    st32(c.r[2], c.r[1]);  // 0601D6B4 mov.l r1,@r2
    c.r[15] = c.r[14];  // 0601D6B6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601D6B8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601D6BA mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0601D6BC mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0601D6BE mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601D6C0 rts ; mov.l @r15+,r8
}

void f_0601D6D0(SH2Context& c) {
    ran[322] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601D6D0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601D6D2 sts.l pr,@-r15
    c.r[1] = ld32(0x0601D6F0u);  // 0601D6D4 mov.l 0x0601D6F0,r1
    c.r[1] = ld32(c.r[1]);  // 0601D6D6 mov.l @r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601D6D8 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0601D6DA extu.b r1,r0
    c.r[0] <<= 2;  // 0601D6DC shll2 r0
    c.r[1] = ld32(0x0601D6F4u);  // 0601D6DE mov.l 0x0601D6F4,r1
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 0601D6E0 mov.l @(r0,r1),r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601D6E6u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601D6E6u) return; }  // 0601D6E2 jsr @r0 ; mov r15,r14
    c.r[15] = c.r[14];  // 0601D6E6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601D6E8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601D6EA mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[0] & 0xFFFFu; c.pc = x; return; }  // 0601D6EC rts ; extu.w r0,r0
}

void f_0601D6F8(SH2Context& c) {
    ran[323] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601D6F8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601D6FA sts.l pr,@-r15
    c.r[1] = ld32(0x0601D720u);  // 0601D6FC mov.l 0x0601D720,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601D702u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601D702u) return; }  // 0601D6FE jsr @r1 ; mov r15,r14
    c.r[0] = ld32(0x0601D724u);  // 0601D702 mov.l 0x0601D724,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601D708u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601D708u) return; }  // 0601D704 jsr @r0 ; nop
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0601D708 cmp/eq #-1,r0
    if (c.t) { goto L_0601D712; }  // 0601D70A bt 0x0601D712
    c.r[1] = ld32(0x0601D728u);  // 0601D70C mov.l 0x0601D728,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601D712u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601D712u) return; }  // 0601D70E jsr @r1 ; nop
L_0601D712:
    c.r[15] = c.r[14];  // 0601D712 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601D714 lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601D71Cu);  // 0601D716 mov.w 0x0601D71C,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601D718 rts ; mov.l @r15+,r14
}

void f_0601D72C(SH2Context& c) {
    ran[324] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601D72C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601D72E sts.l pr,@-r15
    c.r[4] = ld32(0x0601D77Cu);  // 0601D730 mov.l 0x0601D77C,r4
    c.r[1] = c.r[4];  // 0601D732 mov r4,r1
    c.r[1] += 37;  // 0601D734 add #37,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601D736 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601D738 extu.b r1,r1
    c.r[1] >>= 2;  // 0601D73A shlr2 r1
    c.r[1] >>= 2;  // 0601D73C shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0601D73E shlr r1
    c.r[1] >>= 2;  // 0601D740 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601D742 tst r1,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0601D74E; } }  // 0601D744 bt/s 0x0601D74E ; mov r15,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601D77Au);  // 0601D748 mov.w 0x0601D77A,r0
    c.r[15] = c.r[14]; goto L_0601D774;  // 0601D74A bra 0x0601D774 ; mov r14,r15
L_0601D74E:
    c.r[4] += 33;  // 0601D74E add #33,r4
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[4]);  // 0601D750 mov.b @r4,r4
    c.r[1] = ld32(0x0601D780u);  // 0601D752 mov.l 0x0601D780,r1
    st8(c.r[1], c.r[4]);  // 0601D754 mov.b r4,@r1
    c.r[1] = ld32(0x0601D784u);  // 0601D756 mov.l 0x0601D784,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601D75Cu; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601D75Cu) return; }  // 0601D758 jsr @r1 ; extu.b r4,r4
    c.r[0] = ld32(0x0601D788u);  // 0601D75C mov.l 0x0601D788,r0
    c.r[5] = 0x1u;  // 0601D75E mov #1,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0601D764u; c.r[4] = 0x9u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601D764u) return; }  // 0601D760 jsr @r0 ; mov #9,r4
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 0601D764 exts.w r0,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0601D766 cmp/eq #-1,r0
    { const bool k = c.t; c.r[0] = 0x1u; if (k) { goto L_0601D772; } }  // 0601D768 bt/s 0x0601D772 ; mov #1,r0
    c.r[0] = ld32(0x0601D78Cu);  // 0601D76C mov.l 0x0601D78C,r0
    c.r[15] = c.r[14]; goto L_0601D774;  // 0601D76E bra 0x0601D774 ; mov r14,r15
L_0601D772:
    c.r[15] = c.r[14];  // 0601D772 mov r14,r15
L_0601D774:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601D774 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601D776 rts ; mov.l @r15+,r14
}

void f_0601D790(SH2Context& c) {
    ran[325] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601D790 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601D792 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0601D794 mov r15,r14
    c.r[1] = ld32(0x0601D7B0u);  // 0601D796 mov.l 0x0601D7B0,r1
    c.r[2] = ld32(c.r[1]);  // 0601D798 mov.l @r1,r2
    c.r[2] += 1;  // 0601D79A add #1,r2
    st32(c.r[1], c.r[2]);  // 0601D79C mov.l r2,@r1
    c.r[1] = ld32(0x0601D7B4u);  // 0601D79E mov.l 0x0601D7B4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601D7A4u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601D7A4u) return; }  // 0601D7A0 jsr @r1 ; mov #0,r4
    c.r[15] = c.r[14];  // 0601D7A4 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601D7A6 lds.l @r15+,pr
    c.r[0] = ld32(0x0601D7B8u);  // 0601D7A8 mov.l 0x0601D7B8,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601D7AA rts ; mov.l @r15+,r14
}

void f_0601D7BC(SH2Context& c) {
    ran[326] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601D7BC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0601D7BE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0601D7C0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601D7C2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601D7C4 sts.l pr,@-r15
    c.r[1] = ld32(0x0601D938u);  // 0601D7C6 mov.l 0x0601D938,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601D7CCu; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601D7CCu) return; }  // 0601D7C8 jsr @r1 ; mov r15,r14
    c.r[8] = ld32(0x0601D93Cu);  // 0601D7CC mov.l 0x0601D93C,r8
    c.r[2] = ld32(c.r[8]);  // 0601D7CE mov.l @r8,r2
    c.r[9] = ld32(0x0601D940u);  // 0601D7D0 mov.l 0x0601D940,r9
    c.r[1] = c.r[2];  // 0601D7D2 mov r2,r1
    c.r[1] += 1;  // 0601D7D4 add #1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601D7D6 mov.b @r1,r4
    c.r[2] += 2;  // 0601D7D8 add #2,r2
    c.r[4] = c.r[4] & 0xFFu;  // 0601D7DA extu.b r4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601D7DC mov.b @r2,r1
    c.r[4] <<= 8;  // 0601D7DE shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 0601D7E0 extu.b r1,r1
    { const uint32_t x = c.r[9]; c.pr = 0x0601D7E6u; c.r[4] |= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601D7E6u) return; }  // 0601D7E2 jsr @r9 ; or r1,r4
    c.r[2] = ld32(c.r[8]);  // 0601D7E6 mov.l @r8,r2
    c.r[10] = c.r[0] & 0xFFu;  // 0601D7E8 extu.b r0,r10
    c.r[1] = c.r[2];  // 0601D7EA mov r2,r1
    c.r[1] += 3;  // 0601D7EC add #3,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601D7EE mov.b @r1,r4
    c.r[2] += 4;  // 0601D7F0 add #4,r2
    c.r[4] = c.r[4] & 0xFFu;  // 0601D7F2 extu.b r4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601D7F4 mov.b @r2,r1
    c.r[4] <<= 8;  // 0601D7F6 shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 0601D7F8 extu.b r1,r1
    { const uint32_t x = c.r[9]; c.pr = 0x0601D7FEu; c.r[4] |= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601D7FEu) return; }  // 0601D7FA jsr @r9 ; or r1,r4
    c.r[1] = ld32(c.r[8]);  // 0601D7FE mov.l @r8,r1
    c.r[1] += 5;  // 0601D800 add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601D802 mov.b @r1,r1
    c.r[2] = c.r[0] & 0xFFu;  // 0601D804 extu.b r0,r2
    c.r[7] = c.r[1] & 0xFFu;  // 0601D806 extu.b r1,r7
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601D934u);  // 0601D808 mov.w 0x0601D934,r1
    c.t = c.r[2] == c.r[1];  // 0601D80A cmp/eq r1,r2
    { const bool k = !c.t; c.t = c.r[10] == c.r[1]; if (k) { goto L_0601D814; } }  // 0601D80C bf/s 0x0601D814 ; cmp/eq r1,r10
    goto L_0601D924;  // 0601D810 bra 0x0601D924 ; nop
L_0601D814:
    { const bool k = !c.t; c.r[2] <<= 2; if (k) { goto L_0601D81C; } }  // 0601D814 bf/s 0x0601D81C ; shll2 r2
    goto L_0601D924;  // 0601D818 bra 0x0601D924 ; nop
L_0601D81C:
    c.r[1] = ld32(0x0601D944u);  // 0601D81C mov.l 0x0601D944,r1
    c.r[3] = ld32(c.r[1]);  // 0601D81E mov.l @r1,r3
    c.r[2] <<= 2;  // 0601D820 shll2 r2
    c.r[2] += c.r[3];  // 0601D822 add r3,r2
    c.r[1] = c.r[2];  // 0601D824 mov r2,r1
    c.r[1] += 7;  // 0601D826 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601D828 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601D82A extu.b r1,r1
    c.r[1] >>= 2;  // 0601D82C shlr2 r1
    c.r[1] >>= 2;  // 0601D82E shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0601D830 shlr r1
    c.r[1] >>= 2;  // 0601D832 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601D834 tst r1,r1
    { const bool k = c.t; c.r[2] += 3; if (k) { goto L_0601D924; } }  // 0601D836 bt/s 0x0601D924 ; add #3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601D83A mov.b @r2,r1
    c.r[0] = 0x3u;  // 0601D83C mov #3,r0
    c.r[6] = c.r[1];  // 0601D83E mov r1,r6
    c.t = c.r[6] & 1; c.r[6] >>= 1;  // 0601D840 shlr r6
    c.r[2] = c.r[10];  // 0601D842 mov r10,r2
    c.r[2] <<= 2;  // 0601D844 shll2 r2
    c.r[2] <<= 2;  // 0601D846 shll2 r2
    c.r[2] += c.r[3];  // 0601D848 add r3,r2
    c.r[1] = c.r[2];  // 0601D84A mov r2,r1
    c.r[1] += 3;  // 0601D84C add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601D84E mov.b @r1,r1
    c.r[6] &= c.r[0];  // 0601D850 and r0,r6
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0601D852 shlr r1
    c.r[1] &= c.r[0];  // 0601D854 and r0,r1
    c.t = c.r[6] == c.r[1];  // 0601D856 cmp/eq r1,r6
    { const bool k = !c.t; c.r[2] += 4; if (k) { goto L_0601D924; } }  // 0601D858 bf/s 0x0601D924 ; add #4,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601D85C mov.b @r2,r1
    c.r[0] = c.r[1];  // 0601D85E mov r1,r0
    c.r[0] >>= 2;  // 0601D860 shlr2 r0
    c.r[0] >>= 2;  // 0601D862 shlr2 r0
    c.r[0] >>= 2;  // 0601D864 shlr2 r0
    c.r[0] &= 0x1u;  // 0601D866 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601D868 tst r0,r0
    { const bool k = !c.t; c.t = (c.r[7] & c.r[7]) == 0; if (k) { goto L_0601D924; } }  // 0601D86A bf/s 0x0601D924 ; tst r7,r7
    { const bool k = !c.t; c.r[1] = 0xFFFFFFFFu; if (k) { goto L_0601D87A; } }  // 0601D86E bf/s 0x0601D87A ; mov #-1,r1
    c.r[2] = ld32(0x0601D948u);  // 0601D872 mov.l 0x0601D948,r2
    st32(c.r[2] + 16, c.r[1]);  // 0601D874 mov.l r1,@(16,r2)
    st32(c.r[2] + 12, c.r[1]); goto L_0601D91E;  // 0601D876 bra 0x0601D91E ; mov.l r1,@(12,r2)
L_0601D87A:
    c.r[1] = ld32(0x0601D948u);  // 0601D87A mov.l 0x0601D948,r1
    c.r[2] = ld32(c.r[1] + 20);  // 0601D87C mov.l @(20,r1),r2
    c.r[1] = 0x3u;  // 0601D87E mov #3,r1
    c.t = c.r[2] > c.r[1];  // 0601D880 cmp/hi r1,r2
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_0601D91E; } }  // 0601D882 bt/s 0x0601D91E ; mov r2,r1
    c.r[1] += c.r[1];  // 0601D886 add r1,r1
    c.r[0] = 0x0601D894u;  // 0601D888 mova 0x0601D894,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0601D88A mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 0601D88C add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x0601D89Cu: goto L_0601D89C; case 0x0601D8BEu: goto L_0601D8BE; case 0x0601D8DAu: goto L_0601D8DA; case 0x0601D8FCu: goto L_0601D8FC; default: sh2_call(c, x); return; } }  // 0601D88E jmp @r0 ; nop
L_0601D89C:
    c.r[1] = ld32(0x0601D944u);  // 0601D89C mov.l 0x0601D944,r1
    c.r[2] = ld32(c.r[1]);  // 0601D89E mov.l @r1,r2
    c.r[7] = ld32(0x0601D948u);  // 0601D8A0 mov.l 0x0601D948,r7
    c.r[1] = c.r[10];  // 0601D8A2 mov r10,r1
    c.r[1] <<= 2;  // 0601D8A4 shll2 r1
    c.r[1] <<= 2;  // 0601D8A6 shll2 r1
    c.r[3] = c.r[1];  // 0601D8A8 mov r1,r3
    c.r[3] += c.r[2];  // 0601D8AA add r2,r3
    c.r[0] = c.r[1];  // 0601D8AC mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0601D8AE mov.b @(r0,r2),r1
    c.r[3] += 1;  // 0601D8B0 add #1,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0601D8B2 extu.b r1,r1
    st32(c.r[7] + 12, c.r[1]);  // 0601D8B4 mov.l r1,@(12,r7)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0601D8B6 mov.b @r3,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601D8B8 extu.b r1,r1
    c.r[1] -= 1; goto L_0601D91C;  // 0601D8BA bra 0x0601D91C ; add #-1,r1
L_0601D8BE:
    c.r[1] = ld32(0x0601D944u);  // 0601D8BE mov.l 0x0601D944,r1
    c.r[2] = ld32(c.r[1]);  // 0601D8C0 mov.l @r1,r2
    c.r[7] = ld32(0x0601D948u);  // 0601D8C2 mov.l 0x0601D948,r7
    c.r[1] = c.r[10];  // 0601D8C4 mov r10,r1
    c.r[1] <<= 2;  // 0601D8C6 shll2 r1
    c.r[1] <<= 2;  // 0601D8C8 shll2 r1
    c.r[3] = c.r[1];  // 0601D8CA mov r1,r3
    c.r[3] += c.r[2];  // 0601D8CC add r2,r3
    c.r[0] = c.r[1];  // 0601D8CE mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0601D8D0 mov.b @(r0,r2),r1
    c.r[3] += 1;  // 0601D8D2 add #1,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0601D8D4 extu.b r1,r1
    c.r[1] += 1; goto L_0601D916;  // 0601D8D6 bra 0x0601D916 ; add #1,r1
L_0601D8DA:
    c.r[1] = ld32(0x0601D944u);  // 0601D8DA mov.l 0x0601D944,r1
    c.r[2] = ld32(c.r[1]);  // 0601D8DC mov.l @r1,r2
    c.r[7] = ld32(0x0601D948u);  // 0601D8DE mov.l 0x0601D948,r7
    c.r[1] = c.r[10];  // 0601D8E0 mov r10,r1
    c.r[1] <<= 2;  // 0601D8E2 shll2 r1
    c.r[1] <<= 2;  // 0601D8E4 shll2 r1
    c.r[3] = c.r[1];  // 0601D8E6 mov r1,r3
    c.r[3] += c.r[2];  // 0601D8E8 add r2,r3
    c.r[0] = c.r[1];  // 0601D8EA mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0601D8EC mov.b @(r0,r2),r1
    c.r[3] += 1;  // 0601D8EE add #1,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0601D8F0 extu.b r1,r1
    st32(c.r[7] + 12, c.r[1]);  // 0601D8F2 mov.l r1,@(12,r7)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0601D8F4 mov.b @r3,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601D8F6 extu.b r1,r1
    c.r[1] += 1; goto L_0601D91C;  // 0601D8F8 bra 0x0601D91C ; add #1,r1
L_0601D8FC:
    c.r[1] = ld32(0x0601D944u);  // 0601D8FC mov.l 0x0601D944,r1
    c.r[2] = ld32(c.r[1]);  // 0601D8FE mov.l @r1,r2
    c.r[7] = ld32(0x0601D948u);  // 0601D900 mov.l 0x0601D948,r7
    c.r[1] = c.r[10];  // 0601D902 mov r10,r1
    c.r[1] <<= 2;  // 0601D904 shll2 r1
    c.r[1] <<= 2;  // 0601D906 shll2 r1
    c.r[3] = c.r[1];  // 0601D908 mov r1,r3
    c.r[3] += c.r[2];  // 0601D90A add r2,r3
    c.r[0] = c.r[1];  // 0601D90C mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0601D90E mov.b @(r0,r2),r1
    c.r[3] += 1;  // 0601D910 add #1,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0601D912 extu.b r1,r1
    c.r[1] -= 1;  // 0601D914 add #-1,r1
L_0601D916:
    st32(c.r[7] + 12, c.r[1]);  // 0601D916 mov.l r1,@(12,r7)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0601D918 mov.b @r3,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601D91A extu.b r1,r1
L_0601D91C:
    st32(c.r[7] + 16, c.r[1]);  // 0601D91C mov.l r1,@(16,r7)
L_0601D91E:
    c.r[1] = ld32(0x0601D94Cu);  // 0601D91E mov.l 0x0601D94C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601D924u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601D924u) return; }  // 0601D920 jsr @r1 ; nop
L_0601D924:
    c.r[15] = c.r[14];  // 0601D924 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601D926 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601D928 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0601D92A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0601D92C mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601D936u);  // 0601D92E mov.w 0x0601D936,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601D930 rts ; mov.l @r15+,r8
}

void f_0601D950(SH2Context& c) {
    ran[327] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601D950 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0601D952 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601D954 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601D956 sts.l pr,@-r15
    c.r[15] -= 76;  // 0601D958 add #-76,r15
    c.r[14] = c.r[15];  // 0601D95A mov r15,r14
    c.r[9] = ld32(0x0601DA0Cu);  // 0601D95C mov.l 0x0601DA0C,r9
    c.r[8] = ld32(0x0601DA10u);  // 0601D95E mov.l 0x0601DA10,r8
    c.r[0] = ld32(0x0601DA14u);  // 0601D960 mov.l 0x0601DA14,r0
    c.r[7] = 0x0u;  // 0601D962 mov #0,r7
    c.r[2] = ld32(c.r[9]);  // 0601D964 mov.l @r9,r2
    c.r[5] = c.r[14];  // 0601D966 mov r14,r5
    c.r[4] = ld32(c.r[8]);  // 0601D968 mov.l @r8,r4
    c.r[1] = c.r[2];  // 0601D96A mov r2,r1
    c.r[1] += 1;  // 0601D96C add #1,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601D96E mov.b @r1,r6
    c.r[2] += 2;  // 0601D970 add #2,r2
    c.r[6] = c.r[6] & 0xFFu;  // 0601D972 extu.b r6,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601D974 mov.b @r2,r1
    c.r[6] <<= 8;  // 0601D976 shll8 r6
    c.r[1] = c.r[1] & 0xFFu;  // 0601D978 extu.b r1,r1
    c.r[6] |= c.r[1];  // 0601D97A or r1,r6
    { const uint32_t x = c.r[0]; c.pr = 0x0601D980u; c.r[6] = (uint32_t)(int32_t)(int16_t)c.r[6]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601D980u) return; }  // 0601D97C jsr @r0 ; exts.w r6,r6
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601D980 tst r0,r0
    { const bool k = c.t; c.r[1] = (uint32_t)(int8_t)ld8(c.r[14]); if (k) { goto L_0601D9F4; } }  // 0601D982 bt/s 0x0601D9F4 ; mov.b @r14,r1
    c.r[4] = c.r[1] & 0xFFu;  // 0601D986 extu.b r1,r4
    c.r[2] = c.r[4];  // 0601D988 mov r4,r2
    c.r[1] = ld32(c.r[8]);  // 0601D98A mov.l @r8,r1
    c.r[2] <<= 2;  // 0601D98C shll2 r2
    c.r[2] <<= 2;  // 0601D98E shll2 r2
    c.r[2] += c.r[1];  // 0601D990 add r1,r2
    c.r[1] = c.r[2];  // 0601D992 mov r2,r1
    c.r[1] += 4;  // 0601D994 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601D996 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0601D998 mov r1,r0
    c.r[0] >>= 2;  // 0601D99A shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0601D99C shlr r0
    c.r[0] >>= 2;  // 0601D99E shlr2 r0
    c.r[0] &= 0x1u;  // 0601D9A0 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601D9A2 tst r0,r0
    { const bool k = c.t; c.r[2] += 6; if (k) { goto L_0601D9AC; } }  // 0601D9A4 bt/s 0x0601D9AC ; add #6,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601D9A8 mov.b @r2,r1
    c.r[4] = c.r[1] & 0xFFu;  // 0601D9AA extu.b r1,r4
L_0601D9AC:
    c.r[6] = ld32(0x0601DA18u);  // 0601D9AC mov.l 0x0601DA18,r6
    c.r[2] = ld32(0x0601DA1Cu);  // 0601D9AE mov.l 0x0601DA1C,r2
    c.r[7] = c.r[2];  // 0601D9B0 mov r2,r7
    c.r[7] += 33;  // 0601D9B2 add #33,r7
    c.r[3] = c.r[2];  // 0601D9B4 mov r2,r3
    c.r[3] += 32;  // 0601D9B6 add #32,r3
    c.r[1] = c.r[4];  // 0601D9B8 mov r4,r1
    st8(c.r[3], c.r[1]);  // 0601D9BA mov.b r1,@r3
    st8(c.r[7], c.r[1]);  // 0601D9BC mov.b r1,@r7
    st8(c.r[6], c.r[1]);  // 0601D9BE mov.b r1,@r6
    c.r[7] = c.r[2];  // 0601D9C0 mov r2,r7
    c.r[7] += 24;  // 0601D9C2 add #24,r7
    c.r[3] = c.r[2];  // 0601D9C4 mov r2,r3
    c.r[3] += 36;  // 0601D9C6 add #36,r3
    c.r[1] = 0xFFFFFFFFu;  // 0601D9C8 mov #-1,r1
    st32(c.r[2] + 16, c.r[1]);  // 0601D9CA mov.l r1,@(16,r2)
    st32(c.r[2] + 12, c.r[1]);  // 0601D9CC mov.l r1,@(12,r2)
    c.r[6] = 0xFFFFFFFFu;  // 0601D9CE mov #-1,r6
    st8(c.r[3], c.r[6]);  // 0601D9D0 mov.b r6,@r3
    c.r[1] = 0xFFFFFFFFu;  // 0601D9D2 mov #-1,r1
    st16(c.r[7], c.r[1]);  // 0601D9D4 mov.w r1,@r7
    c.r[1] = ld32(c.r[9]);  // 0601D9D6 mov.l @r9,r1
    c.r[1] += 2;  // 0601D9D8 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601D9DA mov.b @r1,r1
    c.r[2] += 30;  // 0601D9DC add #30,r2
    st8(c.r[2], c.r[1]);  // 0601D9DE mov.b r1,@r2
    c.r[1] = (uint32_t)(int32_t)(int8_t)c.r[1];  // 0601D9E0 exts.b r1,r1
    c.t = (int32_t)c.r[1] >= 0;  // 0601D9E2 cmp/pz r1
    if (c.t) { goto L_0601D9E8; }  // 0601D9E4 bt 0x0601D9E8
    st8(c.r[2], c.r[6]);  // 0601D9E6 mov.b r6,@r2
L_0601D9E8:
    c.r[1] = ld32(0x0601DA20u);  // 0601D9E8 mov.l 0x0601DA20,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601D9EEu; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601D9EEu) return; }  // 0601D9EA jsr @r1 ; extu.b r4,r4
    c.r[1] = ld32(0x0601DA24u);  // 0601D9EE mov.l 0x0601DA24,r1
    goto L_0601D9F6;  // 0601D9F0 bra 0x0601D9F6 ; nop
L_0601D9F4:
    c.r[1] = ld32(0x0601DA28u);  // 0601D9F4 mov.l 0x0601DA28,r1
L_0601D9F6:
    { const uint32_t x = c.r[1]; c.pr = 0x0601D9FAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601D9FAu) return; }  // 0601D9F6 jsr @r1 ; nop
    c.r[14] += 76;  // 0601D9FA add #76,r14
    c.r[15] = c.r[14];  // 0601D9FC mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601D9FE lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601DA00 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0601DA02 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601DA0Au);  // 0601DA04 mov.w 0x0601DA0A,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601DA06 rts ; mov.l @r15+,r8
}

void f_0601DA2C(SH2Context& c) {
    ran[328] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601DA2C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0601DA2E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0601DA30 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0601DA32 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0601DA34 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0601DA36 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601DA38 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601DA3A sts.l pr,@-r15
    c.r[15] -= 4;  // 0601DA3C add #-4,r15
    c.r[1] = ld32(0x0601DB24u);  // 0601DA3E mov.l 0x0601DB24,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601DA40 mov.b @r1,r2
    c.r[14] = c.r[15];  // 0601DA42 mov r15,r14
    c.r[2] = c.r[2] & 0xFFu;  // 0601DA44 extu.b r2,r2
    c.r[1] = ld32(0x0601DB28u);  // 0601DA46 mov.l 0x0601DB28,r1
    c.r[2] <<= 2;  // 0601DA48 shll2 r2
    c.r[2] <<= 2;  // 0601DA4A shll2 r2
    c.r[3] = c.r[2];  // 0601DA4C mov r2,r3
    c.r[1] = ld32(c.r[1]);  // 0601DA4E mov.l @r1,r1
    c.r[0] = c.r[2];  // 0601DA50 mov r2,r0
    c.r[3] += c.r[1];  // 0601DA52 add r1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601DA54 mov.b @(r0,r1),r1
    c.r[3] += 1;  // 0601DA56 add #1,r3
    c.r[13] = c.r[1] & 0xFFu;  // 0601DA58 extu.b r1,r13
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0601DA5A mov.b @r3,r1
    c.r[8] = 0x0u;  // 0601DA5C mov #0,r8
    c.r[1] = c.r[1] & 0xFFu;  // 0601DA5E extu.b r1,r1
    st32(c.r[14], c.r[1]);  // 0601DA60 mov.l r1,@r14
    c.r[1] = ld32(0x0601DB2Cu);  // 0601DA62 mov.l 0x0601DB2C,r1
    c.r[2] = ld32(c.r[1]);  // 0601DA64 mov.l @r1,r2
    c.r[11] = (uint32_t)(int16_t)ld16(0x0601DB20u);  // 0601DA66 mov.w 0x0601DB20,r11
    c.r[1] = c.r[2];  // 0601DA68 mov r2,r1
    c.r[1] += 1;  // 0601DA6A add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601DA6C mov.b @r1,r1
    c.r[2] += 2;  // 0601DA6E add #2,r2
    c.r[10] = c.r[1] & 0xFFu;  // 0601DA70 extu.b r1,r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601DA72 mov.b @r2,r1
    c.t = c.r[10] == c.r[11];  // 0601DA74 cmp/eq r11,r10
    { const bool k = !c.t; c.r[9] = c.r[1] & 0xFFu; if (k) { goto L_0601DA84; } }  // 0601DA76 bf/s 0x0601DA84 ; extu.b r1,r9
    c.r[1] = ld32(0x0601DB30u);  // 0601DA7A mov.l 0x0601DB30,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0601DA7C mov.b @r1+,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601DA7E mov.b @r1,r1
    c.r[10] = c.r[2] & 0xFFu;  // 0601DA80 extu.b r2,r10
    c.r[9] = c.r[1] & 0xFFu;  // 0601DA82 extu.b r1,r9
L_0601DA84:
    c.r[1] = ld32(0x0601DB34u);  // 0601DA84 mov.l 0x0601DB34,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601DA8Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601DA8Au) return; }  // 0601DA86 jsr @r1 ; nop
    c.r[12] = ld32(0x0601DB38u);  // 0601DA8A mov.l 0x0601DB38,r12
    c.r[6] = c.r[8] & 0xFFu;  // 0601DA8C extu.b r8,r6
L_0601DA8E:
    c.r[1] = 0x1u;  // 0601DA8E mov #1,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0601DA90 mov.l r1,@-r15
    c.r[7] = c.r[11];  // 0601DA92 mov r11,r7
    c.r[5] = c.r[9];  // 0601DA94 mov r9,r5
    { const uint32_t x = c.r[12]; c.pr = 0x0601DA9Au; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601DA9Au) return; }  // 0601DA96 jsr @r12 ; mov r10,r4
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0601DA9A cmp/eq #-1,r0
    { const bool k = !c.t; c.r[15] += 4; if (k) { goto L_0601DAB0; } }  // 0601DA9C bf/s 0x0601DAB0 ; add #4,r15
    c.r[8] += 1;  // 0601DAA0 add #1,r8
    c.r[1] = 0xAu;  // 0601DAA2 mov #10,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 0601DAA4 cmp/gt r1,r8
    { const bool k = !c.t; c.r[6] = c.r[8] & 0xFFu; if (k) { SH2_POLL(c); goto L_0601DA8E; } }  // 0601DAA6 bf/s 0x0601DA8E ; extu.b r8,r6
    c.r[1] = ld32(0x0601DB3Cu);  // 0601DAAA mov.l 0x0601DB3C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601DAB0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601DAB0u) return; }  // 0601DAAC jsr @r1 ; nop
L_0601DAB0:
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0601DAB0 mov.l r11,@-r15
    c.r[1] = c.r[8] & 0xFFu;  // 0601DAB2 extu.b r8,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0601DAB4 mov.l r1,@-r15
    c.r[0] = ld32(0x0601DB40u);  // 0601DAB6 mov.l 0x0601DB40,r0
    c.r[7] = c.r[9];  // 0601DAB8 mov r9,r7
    c.r[6] = c.r[10];  // 0601DABA mov r10,r6
    c.r[5] = ld32(c.r[14]);  // 0601DABC mov.l @r14,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0601DAC2u; c.r[4] = c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601DAC2u) return; }  // 0601DABE jsr @r0 ; mov r13,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601DAC2 tst r0,r0
    { const bool k = c.t; c.r[15] += 8; if (k) { goto L_0601DACE; } }  // 0601DAC4 bt/s 0x0601DACE ; add #8,r15
    c.r[1] = ld32(0x0601DB3Cu);  // 0601DAC8 mov.l 0x0601DB3C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601DACEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601DACEu) return; }  // 0601DACA jsr @r1 ; nop
L_0601DACE:
    c.r[1] = ld32(0x0601DB44u);  // 0601DACE mov.l 0x0601DB44,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601DAD0 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601DAD2 extu.b r1,r1
    c.r[1] >>= 2;  // 0601DAD4 shlr2 r1
    c.r[1] >>= 2;  // 0601DAD6 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0601DAD8 shlr r1
    c.r[1] >>= 2;  // 0601DADA shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601DADC tst r1,r1
    if (c.t) { goto L_0601DB08; }  // 0601DADE bt 0x0601DB08
    c.r[7] = ld32(0x0601DB24u);  // 0601DAE0 mov.l 0x0601DB24,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0601DAE2 mov.b @r7,r1
    c.r[3] = ld32(0x0601DB28u);  // 0601DAE4 mov.l 0x0601DB28,r3
    c.r[2] = ld32(c.r[3]);  // 0601DAE6 mov.l @r3,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0601DAE8 extu.b r1,r1
    c.r[1] <<= 2;  // 0601DAEA shll2 r1
    c.r[1] <<= 2;  // 0601DAEC shll2 r1
    c.r[0] = c.r[1];  // 0601DAEE mov r1,r0
    st8(c.r[0] + c.r[2], c.r[13]);  // 0601DAF0 mov.b r13,@(r0,r2)
    c.r[0] = 0x3u;  // 0601DAF2 mov #3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0601DAF4 mov.b @r7,r1
    c.r[0] += c.r[14];  // 0601DAF6 add r14,r0
    c.r[2] = ld32(c.r[3]);  // 0601DAF8 mov.l @r3,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0601DAFA extu.b r1,r1
    c.r[1] <<= 2;  // 0601DAFC shll2 r1
    c.r[1] <<= 2;  // 0601DAFE shll2 r1
    c.r[1] += c.r[2];  // 0601DB00 add r2,r1
    c.r[1] += 1;  // 0601DB02 add #1,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0601DB04 mov.b @r0,r0
    st8(c.r[1], c.r[0]);  // 0601DB06 mov.b r0,@r1
L_0601DB08:
    c.r[14] += 4;  // 0601DB08 add #4,r14
    c.r[15] = c.r[14];  // 0601DB0A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601DB0C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601DB0E mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0601DB10 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0601DB12 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0601DB14 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0601DB16 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0601DB18 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601DB22u);  // 0601DB1A mov.w 0x0601DB22,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601DB1C rts ; mov.l @r15+,r8
}

void f_0601DB48(SH2Context& c) {
    ran[329] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601DB48 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0601DB4A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0601DB4C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0601DB4E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0601DB50 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0601DB52 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601DB54 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601DB56 sts.l pr,@-r15
    c.r[15] -= 4;  // 0601DB58 add #-4,r15
    c.r[1] = ld32(0x0601DC4Cu);  // 0601DB5A mov.l 0x0601DC4C,r1
    c.r[2] = ld32(c.r[1]);  // 0601DB5C mov.l @r1,r2
    c.r[14] = c.r[15];  // 0601DB5E mov r15,r14
    c.r[1] = c.r[2];  // 0601DB60 mov r2,r1
    c.r[1] += 1;  // 0601DB62 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601DB64 mov.b @r1,r1
    c.r[2] += 2;  // 0601DB66 add #2,r2
    c.r[9] = c.r[1] & 0xFFu;  // 0601DB68 extu.b r1,r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601DB6A mov.b @r2,r1
    c.r[8] = 0x0u;  // 0601DB6C mov #0,r8
    c.r[10] = c.r[1] & 0xFFu;  // 0601DB6E extu.b r1,r10
    c.r[1] = ld32(0x0601DC50u);  // 0601DB70 mov.l 0x0601DC50,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601DB72 mov.b @r1,r3
    c.r[11] = (uint32_t)(int16_t)ld16(0x0601DC48u);  // 0601DB74 mov.w 0x0601DC48,r11
    c.r[2] = c.r[3] & 0xFFu;  // 0601DB76 extu.b r3,r2
    c.r[1] = ld32(0x0601DC54u);  // 0601DB78 mov.l 0x0601DC54,r1
    c.r[2] <<= 2;  // 0601DB7A shll2 r2
    c.r[2] <<= 2;  // 0601DB7C shll2 r2
    c.r[7] = c.r[2];  // 0601DB7E mov r2,r7
    c.r[1] = ld32(c.r[1]);  // 0601DB80 mov.l @r1,r1
    c.r[0] = c.r[2];  // 0601DB82 mov r2,r0
    c.r[7] += c.r[1];  // 0601DB84 add r1,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601DB86 mov.b @(r0,r1),r1
    c.r[7] += 1;  // 0601DB88 add #1,r7
    c.r[13] = c.r[1] & 0xFFu;  // 0601DB8A extu.b r1,r13
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0601DB8C mov.b @r7,r1
    c.t = c.r[9] == c.r[11];  // 0601DB8E cmp/eq r11,r9
    c.r[1] = c.r[1] & 0xFFu;  // 0601DB90 extu.b r1,r1
    st32(c.r[14], c.r[1]);  // 0601DB92 mov.l r1,@r14
    c.r[1] = ld32(0x0601DC58u);  // 0601DB94 mov.l 0x0601DC58,r1
    c.r[2] = c.r[1];  // 0601DB96 mov r1,r2
    c.r[2] += 33;  // 0601DB98 add #33,r2
    c.r[1] += 32;  // 0601DB9A add #32,r1
    st8(c.r[1], c.r[3]);  // 0601DB9C mov.b r3,@r1
    { const bool k = !c.t; st8(c.r[2], c.r[3]); if (k) { goto L_0601DBAC; } }  // 0601DB9E bf/s 0x0601DBAC ; mov.b r3,@r2
    c.r[1] = ld32(0x0601DC5Cu);  // 0601DBA2 mov.l 0x0601DC5C,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0601DBA4 mov.b @r1+,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601DBA6 mov.b @r1,r1
    c.r[9] = c.r[2] & 0xFFu;  // 0601DBA8 extu.b r2,r9
    c.r[10] = c.r[1] & 0xFFu;  // 0601DBAA extu.b r1,r10
L_0601DBAC:
    c.r[1] = ld32(0x0601DC60u);  // 0601DBAC mov.l 0x0601DC60,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601DBB2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601DBB2u) return; }  // 0601DBAE jsr @r1 ; nop
    c.r[12] = ld32(0x0601DC64u);  // 0601DBB2 mov.l 0x0601DC64,r12
    c.r[6] = c.r[8] & 0xFFu;  // 0601DBB4 extu.b r8,r6
L_0601DBB6:
    c.r[1] = 0x0u;  // 0601DBB6 mov #0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0601DBB8 mov.l r1,@-r15
    c.r[7] = c.r[11];  // 0601DBBA mov r11,r7
    c.r[5] = c.r[10];  // 0601DBBC mov r10,r5
    { const uint32_t x = c.r[12]; c.pr = 0x0601DBC2u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601DBC2u) return; }  // 0601DBBE jsr @r12 ; mov r9,r4
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0601DBC2 cmp/eq #-1,r0
    { const bool k = !c.t; c.r[15] += 4; if (k) { goto L_0601DBD8; } }  // 0601DBC4 bf/s 0x0601DBD8 ; add #4,r15
    c.r[8] += 1;  // 0601DBC8 add #1,r8
    c.r[1] = 0xAu;  // 0601DBCA mov #10,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 0601DBCC cmp/gt r1,r8
    { const bool k = !c.t; c.r[6] = c.r[8] & 0xFFu; if (k) { SH2_POLL(c); goto L_0601DBB6; } }  // 0601DBCE bf/s 0x0601DBB6 ; extu.b r8,r6
    c.r[1] = ld32(0x0601DC68u);  // 0601DBD2 mov.l 0x0601DC68,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601DBD8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601DBD8u) return; }  // 0601DBD4 jsr @r1 ; nop
L_0601DBD8:
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0601DBD8 mov.l r11,@-r15
    c.r[1] = c.r[8] & 0xFFu;  // 0601DBDA extu.b r8,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0601DBDC mov.l r1,@-r15
    c.r[0] = ld32(0x0601DC6Cu);  // 0601DBDE mov.l 0x0601DC6C,r0
    c.r[7] = c.r[10];  // 0601DBE0 mov r10,r7
    c.r[6] = c.r[9];  // 0601DBE2 mov r9,r6
    c.r[5] = ld32(c.r[14]);  // 0601DBE4 mov.l @r14,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0601DBEAu; c.r[4] = c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601DBEAu) return; }  // 0601DBE6 jsr @r0 ; mov r13,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601DBEA tst r0,r0
    { const bool k = c.t; c.r[15] += 8; if (k) { goto L_0601DBF6; } }  // 0601DBEC bt/s 0x0601DBF6 ; add #8,r15
    c.r[1] = ld32(0x0601DC68u);  // 0601DBF0 mov.l 0x0601DC68,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601DBF6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601DBF6u) return; }  // 0601DBF2 jsr @r1 ; nop
L_0601DBF6:
    c.r[1] = ld32(0x0601DC70u);  // 0601DBF6 mov.l 0x0601DC70,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601DBF8 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601DBFA extu.b r1,r1
    c.r[1] >>= 2;  // 0601DBFC shlr2 r1
    c.r[1] >>= 2;  // 0601DBFE shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0601DC00 shlr r1
    c.r[1] >>= 2;  // 0601DC02 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601DC04 tst r1,r1
    if (c.t) { goto L_0601DC30; }  // 0601DC06 bt 0x0601DC30
    c.r[7] = ld32(0x0601DC50u);  // 0601DC08 mov.l 0x0601DC50,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0601DC0A mov.b @r7,r1
    c.r[3] = ld32(0x0601DC54u);  // 0601DC0C mov.l 0x0601DC54,r3
    c.r[2] = ld32(c.r[3]);  // 0601DC0E mov.l @r3,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0601DC10 extu.b r1,r1
    c.r[1] <<= 2;  // 0601DC12 shll2 r1
    c.r[1] <<= 2;  // 0601DC14 shll2 r1
    c.r[0] = c.r[1];  // 0601DC16 mov r1,r0
    st8(c.r[0] + c.r[2], c.r[13]);  // 0601DC18 mov.b r13,@(r0,r2)
    c.r[0] = 0x3u;  // 0601DC1A mov #3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0601DC1C mov.b @r7,r1
    c.r[0] += c.r[14];  // 0601DC1E add r14,r0
    c.r[2] = ld32(c.r[3]);  // 0601DC20 mov.l @r3,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0601DC22 extu.b r1,r1
    c.r[1] <<= 2;  // 0601DC24 shll2 r1
    c.r[1] <<= 2;  // 0601DC26 shll2 r1
    c.r[1] += c.r[2];  // 0601DC28 add r2,r1
    c.r[1] += 1;  // 0601DC2A add #1,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0601DC2C mov.b @r0,r0
    st8(c.r[1], c.r[0]);  // 0601DC2E mov.b r0,@r1
L_0601DC30:
    c.r[14] += 4;  // 0601DC30 add #4,r14
    c.r[15] = c.r[14];  // 0601DC32 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601DC34 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601DC36 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0601DC38 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0601DC3A mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0601DC3C mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0601DC3E mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0601DC40 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601DC4Au);  // 0601DC42 mov.w 0x0601DC4A,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601DC44 rts ; mov.l @r15+,r8
}

void f_0601DC74(SH2Context& c) {
    ran[330] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601DC74 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0601DC76 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0601DC78 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0601DC7A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0601DC7C mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0601DC7E mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601DC80 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601DC82 sts.l pr,@-r15
    c.r[15] -= 8;  // 0601DC84 add #-8,r15
    c.r[1] = ld32(0x0601DDB8u);  // 0601DC86 mov.l 0x0601DDB8,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601DC88 mov.b @r1,r2
    c.r[14] = c.r[15];  // 0601DC8A mov r15,r14
    c.r[2] = c.r[2] & 0xFFu;  // 0601DC8C extu.b r2,r2
    c.r[1] = ld32(0x0601DDBCu);  // 0601DC8E mov.l 0x0601DDBC,r1
    c.r[2] <<= 2;  // 0601DC90 shll2 r2
    c.r[2] <<= 2;  // 0601DC92 shll2 r2
    c.r[3] = c.r[2];  // 0601DC94 mov r2,r3
    c.r[1] = ld32(c.r[1]);  // 0601DC96 mov.l @r1,r1
    c.r[0] = c.r[2];  // 0601DC98 mov r2,r0
    c.r[3] += c.r[1];  // 0601DC9A add r1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601DC9C mov.b @(r0,r1),r1
    c.r[3] += 1;  // 0601DC9E add #1,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0601DCA0 extu.b r1,r1
    st32(c.r[14], c.r[1]);  // 0601DCA2 mov.l r1,@r14
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0601DCA4 mov.b @r3,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601DCA6 extu.b r1,r1
    st32(c.r[14] + 4, c.r[1]);  // 0601DCA8 mov.l r1,@(4,r14)
    c.r[1] = ld32(0x0601DDC0u);  // 0601DCAA mov.l 0x0601DDC0,r1
    c.r[2] = ld32(c.r[1]);  // 0601DCAC mov.l @r1,r2
    c.r[1] = c.r[2];  // 0601DCAE mov r2,r1
    c.r[1] += 1;  // 0601DCB0 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601DCB2 mov.b @r1,r1
    c.r[11] = c.r[1] & 0xFFu;  // 0601DCB4 extu.b r1,r11
    c.r[1] = c.r[2];  // 0601DCB6 mov r2,r1
    c.r[1] += 2;  // 0601DCB8 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601DCBA mov.b @r1,r1
    c.r[10] = c.r[1] & 0xFFu;  // 0601DCBC extu.b r1,r10
    c.r[1] = c.r[2];  // 0601DCBE mov r2,r1
    c.r[1] += 3;  // 0601DCC0 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601DCC2 mov.b @r1,r1
    c.r[2] += 4;  // 0601DCC4 add #4,r2
    c.r[9] = c.r[1] & 0xFFu;  // 0601DCC6 extu.b r1,r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601DCC8 mov.b @r2,r1
    c.r[8] = c.r[1] & 0xFFu;  // 0601DCCA extu.b r1,r8
    c.r[1] = ld32(0x0601DDC4u);  // 0601DCCC mov.l 0x0601DDC4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601DCD2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601DCD2u) return; }  // 0601DCCE jsr @r1 ; nop
    c.r[12] = ld32(0x0601DDC8u);  // 0601DCD2 mov.l 0x0601DDC8,r12
    c.r[1] = 0x1u;  // 0601DCD4 mov #1,r1
L_0601DCD6:
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0601DCD6 mov.l r1,@-r15
    c.r[7] = c.r[8];  // 0601DCD8 mov r8,r7
    c.r[6] = c.r[9];  // 0601DCDA mov r9,r6
    c.r[5] = c.r[10];  // 0601DCDC mov r10,r5
    c.r[13] = ld32(0x0601DDCCu);  // 0601DCDE mov.l 0x0601DDCC,r13
    { const uint32_t x = c.r[13]; c.pr = 0x0601DCE4u; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601DCE4u) return; }  // 0601DCE0 jsr @r13 ; mov r11,r4
    c.r[1] = c.r[0];  // 0601DCE4 mov r0,r1
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0601DCE6 cmp/eq #-1,r0
    { const bool k = !c.t; c.r[15] += 4; if (k) { goto L_0601DD40; } }  // 0601DCE8 bf/s 0x0601DD40 ; add #4,r15
    c.t = (c.r[11] & c.r[11]) == 0;  // 0601DCEC tst r11,r11
    { const bool k = c.t; c.t = (c.r[10] & c.r[10]) == 0; if (k) { goto L_0601DCF8; } }  // 0601DCEE bt/s 0x0601DCF8 ; tst r10,r10
    c.r[1] = c.r[11];  // 0601DCF2 mov r11,r1
    c.r[1] -= 1;  // 0601DCF4 add #-1,r1
    c.r[11] = c.r[1] & 0xFFu;  // 0601DCF6 extu.b r1,r11
L_0601DCF8:
    { const bool k = c.t; c.r[1] = c.r[12]; if (k) { goto L_0601DD04; } }  // 0601DCF8 bt/s 0x0601DD04 ; mov r12,r1
    c.r[1] = c.r[10];  // 0601DCFC mov r10,r1
    c.r[1] -= 1;  // 0601DCFE add #-1,r1
    c.r[10] = c.r[1] & 0xFFu;  // 0601DD00 extu.b r1,r10
    c.r[1] = c.r[12];  // 0601DD02 mov r12,r1
L_0601DD04:
    c.r[1] += 76;  // 0601DD04 add #76,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601DD06 mov.b @r1,r1
    c.r[3] = c.r[1] & 0xFFu;  // 0601DD08 extu.b r1,r3
    c.t = c.r[9] >= c.r[3];  // 0601DD0A cmp/hs r3,r9
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_0601DD14; } }  // 0601DD0C bt/s 0x0601DD14 ; mov r9,r1
    c.r[1] += 1;  // 0601DD10 add #1,r1
    c.r[9] = c.r[1] & 0xFFu;  // 0601DD12 extu.b r1,r9
L_0601DD14:
    c.r[0] = ld32(0x0601DDD0u);  // 0601DD14 mov.l 0x0601DDD0,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0601DD16 mov.b @r0,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0601DD18 extu.b r1,r2
    c.t = c.r[8] >= c.r[2];  // 0601DD1A cmp/hs r2,r8
    { const bool k = c.t; c.t = (c.r[11] & c.r[11]) == 0; if (k) { goto L_0601DD26; } }  // 0601DD1C bt/s 0x0601DD26 ; tst r11,r11
    c.r[1] = c.r[8];  // 0601DD20 mov r8,r1
    c.r[1] += 1;  // 0601DD22 add #1,r1
    c.r[8] = c.r[1] & 0xFFu;  // 0601DD24 extu.b r1,r8
L_0601DD26:
    { const bool k = !c.t; c.r[1] = 0x1u; if (k) { SH2_POLL(c); goto L_0601DCD6; } }  // 0601DD26 bf/s 0x0601DCD6 ; mov #1,r1
    c.t = (c.r[10] & c.r[10]) == 0;  // 0601DD2A tst r10,r10
    { const bool k = !c.t; c.r[3] -= 1; if (k) { SH2_POLL(c); goto L_0601DCD6; } }  // 0601DD2C bf/s 0x0601DCD6 ; add #-1,r3
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[3];  // 0601DD30 cmp/ge r3,r9
    { const bool k = !c.t; c.r[2] -= 1; if (k) { SH2_POLL(c); goto L_0601DCD6; } }  // 0601DD32 bf/s 0x0601DCD6 ; add #-1,r2
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[2];  // 0601DD36 cmp/ge r2,r8
    if (!c.t) { SH2_POLL(c); goto L_0601DCD6; }  // 0601DD38 bf 0x0601DCD6
    c.r[1] = ld32(0x0601DDD4u);  // 0601DD3A mov.l 0x0601DDD4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601DD40u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601DD40u) return; }  // 0601DD3C jsr @r1 ; nop
L_0601DD40:
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601DD40 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0601DD42 mov.l r9,@-r15
    c.r[0] = ld32(0x0601DDD8u);  // 0601DD44 mov.l 0x0601DDD8,r0
    c.r[5] = ld32(c.r[14] + 4);  // 0601DD46 mov.l @(4,r14),r5
    c.r[7] = c.r[10];  // 0601DD48 mov r10,r7
    c.r[4] = ld32(c.r[14]);  // 0601DD4A mov.l @r14,r4
    { const uint32_t x = c.r[0]; c.pr = 0x0601DD50u; c.r[6] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601DD50u) return; }  // 0601DD4C jsr @r0 ; mov r11,r6
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601DD50 tst r0,r0
    { const bool k = c.t; c.r[15] += 8; if (k) { goto L_0601DD5C; } }  // 0601DD52 bt/s 0x0601DD5C ; add #8,r15
    c.r[1] = ld32(0x0601DDD4u);  // 0601DD56 mov.l 0x0601DDD4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601DD5Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601DD5Cu) return; }  // 0601DD58 jsr @r1 ; nop
L_0601DD5C:
    c.r[1] = ld32(0x0601DDDCu);  // 0601DD5C mov.l 0x0601DDDC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601DD5E mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601DD60 extu.b r1,r1
    c.r[1] >>= 2;  // 0601DD62 shlr2 r1
    c.r[1] >>= 2;  // 0601DD64 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0601DD66 shlr r1
    c.r[1] >>= 2;  // 0601DD68 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601DD6A tst r1,r1
    { const bool k = c.t; c.r[0] = 0x3u; if (k) { goto L_0601DD9C; } }  // 0601DD6C bt/s 0x0601DD9C ; mov #3,r0
    c.r[7] = ld32(0x0601DDB8u);  // 0601DD70 mov.l 0x0601DDB8,r7
    c.r[3] = ld32(0x0601DDBCu);  // 0601DD72 mov.l 0x0601DDBC,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0601DD74 mov.b @r7,r1
    c.r[0] += c.r[14];  // 0601DD76 add r14,r0
    c.r[2] = ld32(c.r[3]);  // 0601DD78 mov.l @r3,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0601DD7A extu.b r1,r1
    c.r[1] <<= 2;  // 0601DD7C shll2 r1
    c.r[1] <<= 2;  // 0601DD7E shll2 r1
    c.r[13] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0601DD80 mov.b @r0,r13
    c.r[0] = c.r[1];  // 0601DD82 mov r1,r0
    st8(c.r[0] + c.r[2], c.r[13]);  // 0601DD84 mov.b r13,@(r0,r2)
    c.r[0] = 0x7u;  // 0601DD86 mov #7,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0601DD88 mov.b @r7,r1
    c.r[0] += c.r[14];  // 0601DD8A add r14,r0
    c.r[2] = ld32(c.r[3]);  // 0601DD8C mov.l @r3,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0601DD8E extu.b r1,r1
    c.r[1] <<= 2;  // 0601DD90 shll2 r1
    c.r[1] <<= 2;  // 0601DD92 shll2 r1
    c.r[1] += c.r[2];  // 0601DD94 add r2,r1
    c.r[1] += 1;  // 0601DD96 add #1,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0601DD98 mov.b @r0,r0
    st8(c.r[1], c.r[0]);  // 0601DD9A mov.b r0,@r1
L_0601DD9C:
    c.r[14] += 8;  // 0601DD9C add #8,r14
    c.r[15] = c.r[14];  // 0601DD9E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601DDA0 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601DDA2 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0601DDA4 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0601DDA6 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0601DDA8 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0601DDAA mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0601DDAC mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601DDB4u);  // 0601DDAE mov.w 0x0601DDB4,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601DDB0 rts ; mov.l @r15+,r8
}

void f_0601DDE0(SH2Context& c) {
    ran[331] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601DDE0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0601DDE2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601DDE4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601DDE6 sts.l pr,@-r15
    c.r[9] = ld32(0x0601DE88u);  // 0601DDE8 mov.l 0x0601DE88,r9
    c.r[2] = ld32(c.r[9]);  // 0601DDEA mov.l @r9,r2
    c.r[1] = c.r[2];  // 0601DDEC mov r2,r1
    c.r[1] += 1;  // 0601DDEE add #1,r1
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601DDF0 mov.b @r1,r8
    c.r[2] += 2;  // 0601DDF2 add #2,r2
    c.r[8] = c.r[8] & 0xFFu;  // 0601DDF4 extu.b r8,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601DDF6 mov.b @r2,r1
    c.r[8] <<= 8;  // 0601DDF8 shll8 r8
    c.r[1] = c.r[1] & 0xFFu;  // 0601DDFA extu.b r1,r1
    c.r[8] |= c.r[1];  // 0601DDFC or r1,r8
    c.r[1] = ld32(0x0601DE8Cu);  // 0601DDFE mov.l 0x0601DE8C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601DE04u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601DE04u) return; }  // 0601DE00 jsr @r1 ; mov r15,r14
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601DE82u);  // 0601DE04 mov.w 0x0601DE82,r1
    c.r[8] &= c.r[1];  // 0601DE06 and r1,r8
    c.r[0] = ld32(0x0601DE90u);  // 0601DE08 mov.l 0x0601DE90,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601DE0Eu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601DE0Eu) return; }  // 0601DE0A jsr @r0 ; mov r8,r4
    c.r[0] = c.r[0] & 0xFFu;  // 0601DE0E extu.b r0,r0
    c.r[8] = (uint32_t)(int16_t)ld16(0x0601DE84u);  // 0601DE10 mov.w 0x0601DE84,r8
    c.t = c.r[0] == c.r[8];  // 0601DE12 cmp/eq r8,r0
    { const bool k = c.t; c.r[1] = c.r[0]; if (k) { goto L_0601DE74; } }  // 0601DE14 bt/s 0x0601DE74 ; mov r0,r1
    c.r[6] = ld32(0x0601DE94u);  // 0601DE18 mov.l 0x0601DE94,r6
    c.r[2] = ld32(0x0601DE98u);  // 0601DE1A mov.l 0x0601DE98,r2
    c.r[7] = c.r[2];  // 0601DE1C mov r2,r7
    c.r[7] += 33;  // 0601DE1E add #33,r7
    c.r[3] = c.r[2];  // 0601DE20 mov r2,r3
    c.r[3] += 32;  // 0601DE22 add #32,r3
    st8(c.r[3], c.r[1]);  // 0601DE24 mov.b r1,@r3
    st8(c.r[7], c.r[1]);  // 0601DE26 mov.b r1,@r7
    st8(c.r[6], c.r[1]);  // 0601DE28 mov.b r1,@r6
    c.r[6] = c.r[2];  // 0601DE2A mov r2,r6
    c.r[6] += 24;  // 0601DE2C add #24,r6
    c.r[7] = c.r[2];  // 0601DE2E mov r2,r7
    c.r[7] += 36;  // 0601DE30 add #36,r7
    c.r[1] = c.r[2];  // 0601DE32 mov r2,r1
    c.r[1] += 30;  // 0601DE34 add #30,r1
    c.r[3] = 0xFFFFFFFFu;  // 0601DE36 mov #-1,r3
    st8(c.r[1], c.r[3]);  // 0601DE38 mov.b r3,@r1
    c.r[1] = 0xFFFFFFFFu;  // 0601DE3A mov #-1,r1
    st32(c.r[2] + 16, c.r[1]);  // 0601DE3C mov.l r1,@(16,r2)
    st32(c.r[2] + 12, c.r[1]);  // 0601DE3E mov.l r1,@(12,r2)
    st8(c.r[7], c.r[3]);  // 0601DE40 mov.b r3,@r7
    c.r[1] = 0xFFFFFFFFu;  // 0601DE42 mov #-1,r1
    st16(c.r[6], c.r[1]);  // 0601DE44 mov.w r1,@r6
    c.r[2] = ld32(c.r[9]);  // 0601DE46 mov.l @r9,r2
    c.r[0] = ld32(0x0601DE9Cu);  // 0601DE48 mov.l 0x0601DE9C,r0
    c.r[1] = c.r[2];  // 0601DE4A mov r2,r1
    c.r[1] += 5;  // 0601DE4C add #5,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601DE4E mov.b @r1,r6
    c.r[7] = c.r[8];  // 0601DE50 mov r8,r7
    c.r[6] = c.r[6] & 0xFFu;  // 0601DE52 extu.b r6,r6
    c.r[1] = c.r[2];  // 0601DE54 mov r2,r1
    c.r[1] += 4;  // 0601DE56 add #4,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601DE58 mov.b @r1,r5
    c.r[2] += 3;  // 0601DE5A add #3,r2
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601DE5C mov.b @r2,r4
    c.r[5] = c.r[5] & 0xFFu;  // 0601DE5E extu.b r5,r5
    c.r[4] = c.r[4] & 0xFFu;  // 0601DE60 extu.b r4,r4
    c.r[1] = 0x0u;  // 0601DE62 mov #0,r1
    { const uint32_t x = c.r[0]; c.pr = 0x0601DE68u; c.r[15] -= 4; st32(c.r[15], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601DE68u) return; }  // 0601DE64 jsr @r0 ; mov.l r1,@-r15
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0601DE68 cmp/eq #-1,r0
    { const bool k = c.t; c.r[15] += 4; if (k) { goto L_0601DE74; } }  // 0601DE6A bt/s 0x0601DE74 ; add #4,r15
    c.r[1] = ld32(0x0601DEA0u);  // 0601DE6E mov.l 0x0601DEA0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601DE74u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601DE74u) return; }  // 0601DE70 jsr @r1 ; nop
L_0601DE74:
    c.r[15] = c.r[14];  // 0601DE74 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601DE76 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601DE78 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0601DE7A mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601DE86u);  // 0601DE7C mov.w 0x0601DE86,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601DE7E rts ; mov.l @r15+,r8
}

void f_0601DEA4(SH2Context& c) {
    ran[332] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601DEA4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0601DEA6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0601DEA8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0601DEAA mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0601DEAC mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0601DEAE mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601DEB0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601DEB2 sts.l pr,@-r15
    c.r[15] -= 8;  // 0601DEB4 add #-8,r15
    c.r[14] = c.r[15];  // 0601DEB6 mov r15,r14
    c.r[10] = ld32(0x0601E04Cu);  // 0601DEB8 mov.l 0x0601E04C,r10
    c.r[2] = ld32(c.r[10]);  // 0601DEBA mov.l @r10,r2
    c.r[9] = ld32(0x0601E050u);  // 0601DEBC mov.l 0x0601E050,r9
    c.r[1] = c.r[2];  // 0601DEBE mov r2,r1
    c.r[1] += 1;  // 0601DEC0 add #1,r1
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601DEC2 mov.b @r1,r8
    c.r[2] += 2;  // 0601DEC4 add #2,r2
    c.r[8] = c.r[8] & 0xFFu;  // 0601DEC6 extu.b r8,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601DEC8 mov.b @r2,r1
    c.r[8] <<= 8;  // 0601DECA shll8 r8
    c.r[1] = c.r[1] & 0xFFu;  // 0601DECC extu.b r1,r1
    c.r[8] |= c.r[1];  // 0601DECE or r1,r8
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0601DED0 mov.b @r9,r2
    c.r[1] = ld32(0x0601E054u);  // 0601DED2 mov.l 0x0601E054,r1
    c.r[1] = ld32(c.r[1]);  // 0601DED4 mov.l @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0601DED6 extu.b r2,r2
    c.r[2] <<= 2;  // 0601DED8 shll2 r2
    c.r[2] <<= 2;  // 0601DEDA shll2 r2
    c.r[3] = c.r[2];  // 0601DEDC mov r2,r3
    c.r[3] += c.r[1];  // 0601DEDE add r1,r3
    c.r[0] = c.r[2];  // 0601DEE0 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601DEE2 mov.b @(r0,r1),r1
    c.r[3] += 1;  // 0601DEE4 add #1,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0601DEE6 extu.b r1,r1
    st32(c.r[14], c.r[1]);  // 0601DEE8 mov.l r1,@r14
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0601DEEA mov.b @r3,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601DEEC extu.b r1,r1
    st32(c.r[14] + 4, c.r[1]);  // 0601DEEE mov.l r1,@(4,r14)
    c.r[1] = ld32(0x0601E058u);  // 0601DEF0 mov.l 0x0601E058,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601DEF6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601DEF6u) return; }  // 0601DEF2 jsr @r1 ; nop
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601E044u);  // 0601DEF6 mov.w 0x0601E044,r1
    c.r[8] &= c.r[1];  // 0601DEF8 and r1,r8
    c.r[13] = ld32(0x0601E05Cu);  // 0601DEFA mov.l 0x0601E05C,r13
    { const uint32_t x = c.r[13]; c.pr = 0x0601DF00u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601DF00u) return; }  // 0601DEFC jsr @r13 ; mov r8,r4
    c.r[1] = c.r[0];  // 0601DF00 mov r0,r1
    c.r[6] = c.r[1] & 0xFFu;  // 0601DF02 extu.b r1,r6
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601E046u);  // 0601DF04 mov.w 0x0601E046,r1
    c.t = c.r[6] == c.r[1];  // 0601DF06 cmp/eq r1,r6
    { const bool k = !c.t; c.r[1] = c.r[6]; if (k) { goto L_0601DF10; } }  // 0601DF08 bf/s 0x0601DF10 ; mov r6,r1
    goto L_0601E02C;  // 0601DF0C bra 0x0601E02C ; nop
L_0601DF10:
    c.r[2] = ld32(0x0601E060u);  // 0601DF10 mov.l 0x0601E060,r2
    c.r[7] = c.r[2];  // 0601DF12 mov r2,r7
    c.r[7] += 33;  // 0601DF14 add #33,r7
    c.r[3] = c.r[2];  // 0601DF16 mov r2,r3
    c.r[3] += 32;  // 0601DF18 add #32,r3
    st8(c.r[3], c.r[1]);  // 0601DF1A mov.b r1,@r3
    st8(c.r[7], c.r[1]);  // 0601DF1C mov.b r1,@r7
    st8(c.r[9], c.r[1]);  // 0601DF1E mov.b r1,@r9
    c.r[6] = c.r[2];  // 0601DF20 mov r2,r6
    c.r[6] += 24;  // 0601DF22 add #24,r6
    c.r[7] = c.r[2];  // 0601DF24 mov r2,r7
    c.r[7] += 36;  // 0601DF26 add #36,r7
    c.r[1] = c.r[2];  // 0601DF28 mov r2,r1
    c.r[1] += 30;  // 0601DF2A add #30,r1
    c.r[3] = 0xFFFFFFFFu;  // 0601DF2C mov #-1,r3
    st8(c.r[1], c.r[3]);  // 0601DF2E mov.b r3,@r1
    c.r[1] = 0xFFFFFFFFu;  // 0601DF30 mov #-1,r1
    st32(c.r[2] + 16, c.r[1]);  // 0601DF32 mov.l r1,@(16,r2)
    st32(c.r[2] + 12, c.r[1]);  // 0601DF34 mov.l r1,@(12,r2)
    st8(c.r[7], c.r[3]);  // 0601DF36 mov.b r3,@r7
    c.r[1] = 0xFFFFFFFFu;  // 0601DF38 mov #-1,r1
    st16(c.r[6], c.r[1]);  // 0601DF3A mov.w r1,@r6
    c.r[2] = ld32(c.r[10]);  // 0601DF3C mov.l @r10,r2
    c.r[1] = c.r[2];  // 0601DF3E mov r2,r1
    c.r[1] += 3;  // 0601DF40 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601DF42 mov.b @r1,r1
    c.r[11] = c.r[1] & 0xFFu;  // 0601DF44 extu.b r1,r11
    c.r[1] = c.r[2];  // 0601DF46 mov r2,r1
    c.r[1] += 4;  // 0601DF48 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601DF4A mov.b @r1,r1
    c.r[10] = c.r[1] & 0xFFu;  // 0601DF4C extu.b r1,r10
    c.r[1] = c.r[2];  // 0601DF4E mov r2,r1
    c.r[1] += 5;  // 0601DF50 add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601DF52 mov.b @r1,r1
    c.r[2] += 6;  // 0601DF54 add #6,r2
    c.r[9] = c.r[1] & 0xFFu;  // 0601DF56 extu.b r1,r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601DF58 mov.b @r2,r1
    c.r[8] = c.r[1] & 0xFFu;  // 0601DF5A extu.b r1,r8
    c.r[1] = ld32(0x0601E064u);  // 0601DF5C mov.l 0x0601E064,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601DF62u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601DF62u) return; }  // 0601DF5E jsr @r1 ; nop
    c.r[12] = ld32(0x0601E068u);  // 0601DF62 mov.l 0x0601E068,r12
    c.r[1] = 0x0u;  // 0601DF64 mov #0,r1
L_0601DF66:
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0601DF66 mov.l r1,@-r15
    c.r[7] = c.r[8];  // 0601DF68 mov r8,r7
    c.r[6] = c.r[9];  // 0601DF6A mov r9,r6
    c.r[5] = c.r[10];  // 0601DF6C mov r10,r5
    c.r[0] = ld32(0x0601E06Cu);  // 0601DF6E mov.l 0x0601E06C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601DF74u; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601DF74u) return; }  // 0601DF70 jsr @r0 ; mov r11,r4
    c.r[1] = c.r[0];  // 0601DF74 mov r0,r1
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0601DF76 cmp/eq #-1,r0
    { const bool k = !c.t; c.r[15] += 4; if (k) { goto L_0601DFD0; } }  // 0601DF78 bf/s 0x0601DFD0 ; add #4,r15
    c.t = (c.r[11] & c.r[11]) == 0;  // 0601DF7C tst r11,r11
    { const bool k = c.t; c.t = (c.r[10] & c.r[10]) == 0; if (k) { goto L_0601DF88; } }  // 0601DF7E bt/s 0x0601DF88 ; tst r10,r10
    c.r[1] = c.r[11];  // 0601DF82 mov r11,r1
    c.r[1] -= 1;  // 0601DF84 add #-1,r1
    c.r[11] = c.r[1] & 0xFFu;  // 0601DF86 extu.b r1,r11
L_0601DF88:
    { const bool k = c.t; c.r[1] = c.r[12]; if (k) { goto L_0601DF94; } }  // 0601DF88 bt/s 0x0601DF94 ; mov r12,r1
    c.r[1] = c.r[10];  // 0601DF8C mov r10,r1
    c.r[1] -= 1;  // 0601DF8E add #-1,r1
    c.r[10] = c.r[1] & 0xFFu;  // 0601DF90 extu.b r1,r10
    c.r[1] = c.r[12];  // 0601DF92 mov r12,r1
L_0601DF94:
    c.r[1] += 76;  // 0601DF94 add #76,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601DF96 mov.b @r1,r1
    c.r[3] = c.r[1] & 0xFFu;  // 0601DF98 extu.b r1,r3
    c.t = c.r[9] >= c.r[3];  // 0601DF9A cmp/hs r3,r9
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_0601DFA4; } }  // 0601DF9C bt/s 0x0601DFA4 ; mov r9,r1
    c.r[1] += 1;  // 0601DFA0 add #1,r1
    c.r[9] = c.r[1] & 0xFFu;  // 0601DFA2 extu.b r1,r9
L_0601DFA4:
    c.r[13] = ld32(0x0601E070u);  // 0601DFA4 mov.l 0x0601E070,r13
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 0601DFA6 mov.b @r13,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0601DFA8 extu.b r1,r2
    c.t = c.r[8] >= c.r[2];  // 0601DFAA cmp/hs r2,r8
    { const bool k = c.t; c.t = (c.r[11] & c.r[11]) == 0; if (k) { goto L_0601DFB6; } }  // 0601DFAC bt/s 0x0601DFB6 ; tst r11,r11
    c.r[1] = c.r[8];  // 0601DFB0 mov r8,r1
    c.r[1] += 1;  // 0601DFB2 add #1,r1
    c.r[8] = c.r[1] & 0xFFu;  // 0601DFB4 extu.b r1,r8
L_0601DFB6:
    { const bool k = !c.t; c.r[1] = 0x0u; if (k) { SH2_POLL(c); goto L_0601DF66; } }  // 0601DFB6 bf/s 0x0601DF66 ; mov #0,r1
    c.t = (c.r[10] & c.r[10]) == 0;  // 0601DFBA tst r10,r10
    { const bool k = !c.t; c.r[3] -= 1; if (k) { SH2_POLL(c); goto L_0601DF66; } }  // 0601DFBC bf/s 0x0601DF66 ; add #-1,r3
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[3];  // 0601DFC0 cmp/ge r3,r9
    { const bool k = !c.t; c.r[2] -= 1; if (k) { SH2_POLL(c); goto L_0601DF66; } }  // 0601DFC2 bf/s 0x0601DF66 ; add #-1,r2
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[2];  // 0601DFC6 cmp/ge r2,r8
    if (!c.t) { SH2_POLL(c); goto L_0601DF66; }  // 0601DFC8 bf 0x0601DF66
    c.r[1] = ld32(0x0601E058u);  // 0601DFCA mov.l 0x0601E058,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601DFD0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601DFD0u) return; }  // 0601DFCC jsr @r1 ; nop
L_0601DFD0:
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601DFD0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0601DFD2 mov.l r9,@-r15
    c.r[0] = ld32(0x0601E074u);  // 0601DFD4 mov.l 0x0601E074,r0
    c.r[5] = ld32(c.r[14] + 4);  // 0601DFD6 mov.l @(4,r14),r5
    c.r[7] = c.r[10];  // 0601DFD8 mov r10,r7
    c.r[4] = ld32(c.r[14]);  // 0601DFDA mov.l @r14,r4
    { const uint32_t x = c.r[0]; c.pr = 0x0601DFE0u; c.r[6] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601DFE0u) return; }  // 0601DFDC jsr @r0 ; mov r11,r6
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601DFE0 tst r0,r0
    { const bool k = c.t; c.r[15] += 8; if (k) { goto L_0601DFEC; } }  // 0601DFE2 bt/s 0x0601DFEC ; add #8,r15
    c.r[1] = ld32(0x0601E058u);  // 0601DFE6 mov.l 0x0601E058,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601DFECu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601DFECu) return; }  // 0601DFE8 jsr @r1 ; nop
L_0601DFEC:
    c.r[1] = ld32(0x0601E078u);  // 0601DFEC mov.l 0x0601E078,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601DFEE mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601DFF0 extu.b r1,r1
    c.r[1] >>= 2;  // 0601DFF2 shlr2 r1
    c.r[1] >>= 2;  // 0601DFF4 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0601DFF6 shlr r1
    c.r[1] >>= 2;  // 0601DFF8 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601DFFA tst r1,r1
    { const bool k = c.t; c.r[0] = 0x3u; if (k) { goto L_0601E02C; } }  // 0601DFFC bt/s 0x0601E02C ; mov #3,r0
    c.r[7] = ld32(0x0601E050u);  // 0601E000 mov.l 0x0601E050,r7
    c.r[3] = ld32(0x0601E054u);  // 0601E002 mov.l 0x0601E054,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0601E004 mov.b @r7,r1
    c.r[0] += c.r[14];  // 0601E006 add r14,r0
    c.r[2] = ld32(c.r[3]);  // 0601E008 mov.l @r3,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0601E00A extu.b r1,r1
    c.r[1] <<= 2;  // 0601E00C shll2 r1
    c.r[1] <<= 2;  // 0601E00E shll2 r1
    c.r[13] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0601E010 mov.b @r0,r13
    c.r[0] = c.r[1];  // 0601E012 mov r1,r0
    st8(c.r[0] + c.r[2], c.r[13]);  // 0601E014 mov.b r13,@(r0,r2)
    c.r[0] = 0x7u;  // 0601E016 mov #7,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0601E018 mov.b @r7,r1
    c.r[0] += c.r[14];  // 0601E01A add r14,r0
    c.r[2] = ld32(c.r[3]);  // 0601E01C mov.l @r3,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0601E01E extu.b r1,r1
    c.r[1] <<= 2;  // 0601E020 shll2 r1
    c.r[1] <<= 2;  // 0601E022 shll2 r1
    c.r[1] += c.r[2];  // 0601E024 add r2,r1
    c.r[1] += 1;  // 0601E026 add #1,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0601E028 mov.b @r0,r0
    st8(c.r[1], c.r[0]);  // 0601E02A mov.b r0,@r1
L_0601E02C:
    c.r[14] += 8;  // 0601E02C add #8,r14
    c.r[15] = c.r[14];  // 0601E02E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601E030 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601E032 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0601E034 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0601E036 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0601E038 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0601E03A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0601E03C mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601E048u);  // 0601E03E mov.w 0x0601E048,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601E040 rts ; mov.l @r15+,r8
}

void f_0601E07C(SH2Context& c) {
    ran[333] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601E07C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601E07E sts.l pr,@-r15
    c.r[1] = ld32(0x0601E0C0u);  // 0601E080 mov.l 0x0601E0C0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601E086u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601E086u) return; }  // 0601E082 jsr @r1 ; mov r15,r14
    c.r[1] = ld32(0x0601E0C4u);  // 0601E086 mov.l 0x0601E0C4,r1
    c.r[2] = ld32(c.r[1]);  // 0601E088 mov.l @r1,r2
    c.r[0] = ld32(0x0601E0C8u);  // 0601E08A mov.l 0x0601E0C8,r0
    c.r[1] = c.r[2];  // 0601E08C mov r2,r1
    c.r[1] += 1;  // 0601E08E add #1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601E090 mov.b @r1,r4
    c.r[2] += 2;  // 0601E092 add #2,r2
    c.r[4] = c.r[4] & 0xFFu;  // 0601E094 extu.b r4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601E096 mov.b @r2,r1
    c.r[4] <<= 8;  // 0601E098 shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 0601E09A extu.b r1,r1
    { const uint32_t x = c.r[0]; c.pr = 0x0601E0A0u; c.r[4] |= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601E0A0u) return; }  // 0601E09C jsr @r0 ; or r1,r4
    c.r[0] = c.r[0] & 0xFFu;  // 0601E0A0 extu.b r0,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601E0BCu);  // 0601E0A2 mov.w 0x0601E0BC,r1
    c.t = c.r[0] == c.r[1];  // 0601E0A4 cmp/eq r1,r0
    if (c.t) { goto L_0601E0B2; }  // 0601E0A6 bt 0x0601E0B2
    c.r[1] = ld32(0x0601E0CCu);  // 0601E0A8 mov.l 0x0601E0CC,r1
    st8(c.r[1], c.r[0]);  // 0601E0AA mov.b r0,@r1
    c.r[1] = ld32(0x0601E0D0u);  // 0601E0AC mov.l 0x0601E0D0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601E0B2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601E0B2u) return; }  // 0601E0AE jsr @r1 ; nop
L_0601E0B2:
    c.r[15] = c.r[14];  // 0601E0B2 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601E0B4 lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601E0BEu);  // 0601E0B6 mov.w 0x0601E0BE,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601E0B8 rts ; mov.l @r15+,r14
}

void f_0601E0D4(SH2Context& c) {
    ran[334] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601E0D4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601E0D6 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601E0D8 sts.l pr,@-r15
    c.r[1] = ld32(0x0601E13Cu);  // 0601E0DA mov.l 0x0601E13C,r1
    c.r[1] = ld32(c.r[1]);  // 0601E0DC mov.l @r1,r1
    c.r[1] += 1;  // 0601E0DE add #1,r1
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601E0E0 mov.b @r1,r8
    c.r[1] = ld32(0x0601E140u);  // 0601E0E2 mov.l 0x0601E140,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601E0E8u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601E0E8u) return; }  // 0601E0E4 jsr @r1 ; mov r15,r14
    c.r[2] = ld32(0x0601E144u);  // 0601E0E8 mov.l 0x0601E144,r2
    c.r[3] = c.r[2];  // 0601E0EA mov r2,r3
    c.r[3] += 30;  // 0601E0EC add #30,r3
    c.r[1] = 0xFFFFFFFFu;  // 0601E0EE mov #-1,r1
    st8(c.r[3], c.r[1]);  // 0601E0F0 mov.b r1,@r3
    c.r[1] = 0xFFFFFFFFu;  // 0601E0F2 mov #-1,r1
    st32(c.r[2] + 16, c.r[1]);  // 0601E0F4 mov.l r1,@(16,r2)
    st32(c.r[2] + 12, c.r[1]);  // 0601E0F6 mov.l r1,@(12,r2)
    c.r[8] = c.r[8] & 0xFFu;  // 0601E0F8 extu.b r8,r8
    c.r[2] += 32;  // 0601E0FA add #32,r2
    c.r[1] = ld32(0x0601E148u);  // 0601E0FC mov.l 0x0601E148,r1
    c.r[7] = 0x0u;  // 0601E0FE mov #0,r7
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601E100 mov.b @r2,r2
    c.r[6] = c.r[8];  // 0601E102 mov r8,r6
    c.r[3] = ld32(c.r[1]);  // 0601E104 mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0601E106 extu.b r2,r2
    c.r[2] <<= 2;  // 0601E108 shll2 r2
    c.r[2] <<= 2;  // 0601E10A shll2 r2
    c.r[1] = c.r[2];  // 0601E10C mov r2,r1
    c.r[1] += c.r[3];  // 0601E10E add r3,r1
    c.r[1] += 1;  // 0601E110 add #1,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601E112 mov.b @r1,r5
    c.r[0] = c.r[2];  // 0601E114 mov r2,r0
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0601E116 mov.b @(r0,r3),r4
    c.r[5] = c.r[5] & 0xFFu;  // 0601E118 extu.b r5,r5
    c.r[0] = ld32(0x0601E14Cu);  // 0601E11A mov.l 0x0601E14C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601E120u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601E120u) return; }  // 0601E11C jsr @r0 ; extu.b r4,r4
    c.r[1] = c.r[0];  // 0601E120 mov r0,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601E122 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601E124 tst r1,r1
    if (c.t) { goto L_0601E12E; }  // 0601E126 bt 0x0601E12E
    c.r[1] = ld32(0x0601E150u);  // 0601E128 mov.l 0x0601E150,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601E12Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601E12Eu) return; }  // 0601E12A jsr @r1 ; nop
L_0601E12E:
    c.r[15] = c.r[14];  // 0601E12E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601E130 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601E132 mov.l @r15+,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601E13Au);  // 0601E134 mov.w 0x0601E13A,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601E136 rts ; mov.l @r15+,r8
}

void f_0601E154(SH2Context& c) {
    ran[335] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601E154 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601E156 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601E158 sts.l pr,@-r15
    c.r[1] = ld32(0x0601E1E0u);  // 0601E15A mov.l 0x0601E1E0,r1
    c.r[2] = ld32(c.r[1]);  // 0601E15C mov.l @r1,r2
    c.r[1] = c.r[2];  // 0601E15E mov r2,r1
    c.r[1] += 1;  // 0601E160 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601E162 mov.b @r1,r1
    c.r[2] += 2;  // 0601E164 add #2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0601E166 extu.b r1,r1
    c.r[8] = c.r[1];  // 0601E168 mov r1,r8
    c.r[8] <<= 8;  // 0601E16A shll8 r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601E16C mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601E16E extu.b r1,r1
    c.r[8] |= c.r[1];  // 0601E170 or r1,r8
    c.r[1] = ld32(0x0601E1E4u);  // 0601E172 mov.l 0x0601E1E4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601E178u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601E178u) return; }  // 0601E174 jsr @r1 ; mov r15,r14
    c.r[4] = (uint32_t)(int16_t)ld16(0x0601E1D8u);  // 0601E178 mov.w 0x0601E1D8,r4
    c.r[0] = ld32(0x0601E1E8u);  // 0601E17A mov.l 0x0601E1E8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601E180u; c.r[4] &= c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601E180u) return; }  // 0601E17C jsr @r0 ; and r8,r4
    c.r[4] = c.r[0] & 0xFFu;  // 0601E180 extu.b r0,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601E1DAu);  // 0601E182 mov.w 0x0601E1DA,r1
    c.t = c.r[4] == c.r[1];  // 0601E184 cmp/eq r1,r4
    { const bool k = c.t; c.r[1] = c.r[4]; if (k) { goto L_0601E1CC; } }  // 0601E186 bt/s 0x0601E1CC ; mov r4,r1
    c.r[6] = ld32(0x0601E1ECu);  // 0601E18A mov.l 0x0601E1EC,r6
    c.r[2] = ld32(0x0601E1F0u);  // 0601E18C mov.l 0x0601E1F0,r2
    c.r[7] = c.r[2];  // 0601E18E mov r2,r7
    c.r[7] += 33;  // 0601E190 add #33,r7
    c.r[3] = c.r[2];  // 0601E192 mov r2,r3
    c.r[3] += 32;  // 0601E194 add #32,r3
    st8(c.r[3], c.r[1]);  // 0601E196 mov.b r1,@r3
    st8(c.r[7], c.r[1]);  // 0601E198 mov.b r1,@r7
    st8(c.r[6], c.r[1]);  // 0601E19A mov.b r1,@r6
    c.r[6] = c.r[2];  // 0601E19C mov r2,r6
    c.r[6] += 24;  // 0601E19E add #24,r6
    c.r[7] = c.r[2];  // 0601E1A0 mov r2,r7
    c.r[7] += 36;  // 0601E1A2 add #36,r7
    c.r[1] = c.r[2];  // 0601E1A4 mov r2,r1
    c.r[1] += 30;  // 0601E1A6 add #30,r1
    c.r[3] = 0xFFFFFFFFu;  // 0601E1A8 mov #-1,r3
    st8(c.r[1], c.r[3]);  // 0601E1AA mov.b r3,@r1
    c.r[1] = 0xFFFFFFFFu;  // 0601E1AC mov #-1,r1
    st32(c.r[2] + 16, c.r[1]);  // 0601E1AE mov.l r1,@(16,r2)
    st32(c.r[2] + 12, c.r[1]);  // 0601E1B0 mov.l r1,@(12,r2)
    st8(c.r[7], c.r[3]);  // 0601E1B2 mov.b r3,@r7
    c.r[1] = 0xFFFFFFFFu;  // 0601E1B4 mov #-1,r1
    st16(c.r[6], c.r[1]);  // 0601E1B6 mov.w r1,@r6
    c.r[1] = ld32(0x0601E1F4u);  // 0601E1B8 mov.l 0x0601E1F4,r1
    c.r[8] &= c.r[1];  // 0601E1BA and r1,r8
    c.r[0] = ld32(0x0601E1F8u);  // 0601E1BC mov.l 0x0601E1F8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601E1C2u; c.r[5] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601E1C2u) return; }  // 0601E1BE jsr @r0 ; mov r8,r5
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0601E1C2 cmp/eq #-1,r0
    if (c.t) { goto L_0601E1CC; }  // 0601E1C4 bt 0x0601E1CC
    c.r[1] = ld32(0x0601E1FCu);  // 0601E1C6 mov.l 0x0601E1FC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601E1CCu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601E1CCu) return; }  // 0601E1C8 jsr @r1 ; nop
L_0601E1CC:
    c.r[15] = c.r[14];  // 0601E1CC mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601E1CE lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601E1D0 mov.l @r15+,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601E1DCu);  // 0601E1D2 mov.w 0x0601E1DC,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601E1D4 rts ; mov.l @r15+,r8
}

void f_0601E200(SH2Context& c) {
    ran[336] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601E200 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0601E202 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601E204 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601E206 sts.l pr,@-r15
    c.r[1] = ld32(0x0601E250u);  // 0601E208 mov.l 0x0601E250,r1
    c.r[2] = ld32(c.r[1]);  // 0601E20A mov.l @r1,r2
    c.r[14] = c.r[15];  // 0601E20C mov r15,r14
    c.r[1] = c.r[2];  // 0601E20E mov r2,r1
    c.r[1] += 1;  // 0601E210 add #1,r1
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601E212 mov.b @r1,r8
    c.r[2] += 2;  // 0601E214 add #2,r2
    c.r[8] = c.r[8] & 0xFFu;  // 0601E216 extu.b r8,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601E218 mov.b @r2,r1
    c.r[8] <<= 8;  // 0601E21A shll8 r8
    c.r[1] = c.r[1] & 0xFFu;  // 0601E21C extu.b r1,r1
    c.r[8] |= c.r[1];  // 0601E21E or r1,r8
    c.r[1] = ld32(0x0601E254u);  // 0601E220 mov.l 0x0601E254,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601E226u; c.r[8] = (uint32_t)(int32_t)(int16_t)c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601E226u) return; }  // 0601E222 jsr @r1 ; exts.w r8,r8
    c.r[9] = ld32(0x0601E258u);  // 0601E226 mov.l 0x0601E258,r9
    c.r[1] = 0x0u;  // 0601E228 mov #0,r1
    st32(c.r[9], c.r[1]);  // 0601E22A mov.l r1,@r9
    c.r[0] = ld32(0x0601E25Cu);  // 0601E22C mov.l 0x0601E25C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601E232u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601E232u) return; }  // 0601E22E jsr @r0 ; mov r8,r4
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0601E232 cmp/eq #-1,r0
    { const bool k = c.t; c.r[1] = 0x1u; if (k) { goto L_0601E240; } }  // 0601E234 bt/s 0x0601E240 ; mov #1,r1
    st32(c.r[9], c.r[1]);  // 0601E238 mov.l r1,@r9
    c.r[1] = ld32(0x0601E260u);  // 0601E23A mov.l 0x0601E260,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601E240u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601E240u) return; }  // 0601E23C jsr @r1 ; nop
L_0601E240:
    c.r[15] = c.r[14];  // 0601E240 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601E242 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601E244 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0601E246 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601E24Eu);  // 0601E248 mov.w 0x0601E24E,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601E24A rts ; mov.l @r15+,r8
}

void f_0601E264(SH2Context& c) {
    ran[337] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601E264 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601E266 sts.l pr,@-r15
    c.r[1] = ld32(0x0601E290u);  // 0601E268 mov.l 0x0601E290,r1
    c.r[1] = ld32(c.r[1]);  // 0601E26A mov.l @r1,r1
    c.r[14] = c.r[15];  // 0601E26C mov r15,r14
    c.r[1] += 1;  // 0601E26E add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601E270 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601E272 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601E274 tst r1,r1
    { const bool k = c.t; c.r[4] = 0x0u; if (k) { goto L_0601E27C; } }  // 0601E276 bt/s 0x0601E27C ; mov #0,r4
    c.r[4] = ld32(0x0601E294u);  // 0601E27A mov.l 0x0601E294,r4
L_0601E27C:
    c.r[0] = ld32(0x0601E298u);  // 0601E27C mov.l 0x0601E298,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601E282u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601E282u) return; }  // 0601E27E jsr @r0 ; nop
    c.r[15] = c.r[14];  // 0601E282 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601E284 lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601E28Cu);  // 0601E286 mov.w 0x0601E28C,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601E288 rts ; mov.l @r15+,r14
}

void f_0601E29C(SH2Context& c) {
    ran[338] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601E29C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0601E29E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601E2A0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601E2A2 sts.l pr,@-r15
    c.r[1] = ld32(0x0601E32Cu);  // 0601E2A4 mov.l 0x0601E32C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601E2AAu; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601E2AAu) return; }  // 0601E2A6 jsr @r1 ; mov r15,r14
    c.r[8] = 0xFFFFFFFFu;  // 0601E2AA mov #-1,r8
    c.r[9] = ld32(0x0601E330u);  // 0601E2AC mov.l 0x0601E330,r9
    c.r[1] = 0x0u;  // 0601E2AE mov #0,r1
    c.r[0] = ld32(0x0601E334u);  // 0601E2B0 mov.l 0x0601E334,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601E2B6u; st32(c.r[9], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601E2B6u) return; }  // 0601E2B2 jsr @r0 ; mov.l r1,@r9
    c.r[1] = c.r[0] & 0xFFu;  // 0601E2B6 extu.b r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601E2B8 tst r1,r1
    { const bool k = !c.t; c.r[1] = 0x1u; if (k) { goto L_0601E2CA; } }  // 0601E2BA bf/s 0x0601E2CA ; mov #1,r1
    st32(c.r[9], c.r[1]);  // 0601E2BE mov.l r1,@r9
    c.r[1] = ld32(0x0601E338u);  // 0601E2C0 mov.l 0x0601E338,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601E2C6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601E2C6u) return; }  // 0601E2C2 jsr @r1 ; nop
    c.r[15] = c.r[14]; goto L_0601E31C;  // 0601E2C6 bra 0x0601E31C ; mov r14,r15
L_0601E2CA:
    c.r[1] = ld32(0x0601E33Cu);  // 0601E2CA mov.l 0x0601E33C,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601E2CC mov.b @r1,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0601E2CE cmp/eq #-1,r0
    if (c.t) { goto L_0601E2D8; }  // 0601E2D0 bt 0x0601E2D8
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601E2D2 mov.b @r1,r8
    c.r[0] = c.r[8]; goto L_0601E2F8;  // 0601E2D4 bra 0x0601E2F8 ; mov r8,r0
L_0601E2D8:
    c.r[1] = ld32(0x0601E340u);  // 0601E2D8 mov.l 0x0601E340,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601E2DA mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0601E2DC extu.b r2,r2
    c.r[1] = ld32(0x0601E344u);  // 0601E2DE mov.l 0x0601E344,r1
    c.r[1] = ld32(c.r[1]);  // 0601E2E0 mov.l @r1,r1
    c.r[2] <<= 2;  // 0601E2E2 shll2 r2
    c.r[2] <<= 2;  // 0601E2E4 shll2 r2
    c.r[2] += c.r[1];  // 0601E2E6 add r1,r2
    c.r[2] += 9;  // 0601E2E8 add #9,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601E2EA mov.b @r2,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0601E2EC extu.b r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601E328u);  // 0601E2EE mov.w 0x0601E328,r1
    c.t = c.r[2] == c.r[1];  // 0601E2F0 cmp/eq r1,r2
    if (c.t) { goto L_0601E2F6; }  // 0601E2F2 bt 0x0601E2F6
    c.r[8] = c.r[2];  // 0601E2F4 mov r2,r8
L_0601E2F6:
    c.r[0] = c.r[8];  // 0601E2F6 mov r8,r0
L_0601E2F8:
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0601E2F8 cmp/eq #-1,r0
    { const bool k = c.t; c.r[5] = c.r[8] & 0xFFFFu; if (k) { goto L_0601E31A; } }  // 0601E2FA bt/s 0x0601E31A ; extu.w r8,r5
    c.r[1] = ld32(0x0601E340u);  // 0601E2FE mov.l 0x0601E340,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601E300 mov.b @r1,r4
    c.r[0] = ld32(0x0601E348u);  // 0601E302 mov.l 0x0601E348,r0
    c.r[6] = 0x1u;  // 0601E304 mov #1,r6
    { const uint32_t x = c.r[0]; c.pr = 0x0601E30Au; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601E30Au) return; }  // 0601E306 jsr @r0 ; extu.b r4,r4
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0601E30A cmp/eq #-1,r0
    if (c.t) { goto L_0601E31A; }  // 0601E30C bt 0x0601E31A
    c.r[1] = ld32(0x0601E338u);  // 0601E30E mov.l 0x0601E338,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601E314u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601E314u) return; }  // 0601E310 jsr @r1 ; nop
    c.r[2] = ld32(0x0601E330u);  // 0601E314 mov.l 0x0601E330,r2
    c.r[1] = 0x1u;  // 0601E316 mov #1,r1
    st32(c.r[2], c.r[1]);  // 0601E318 mov.l r1,@r2
L_0601E31A:
    c.r[15] = c.r[14];  // 0601E31A mov r14,r15
L_0601E31C:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601E31C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601E31E mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0601E320 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601E32Au);  // 0601E322 mov.w 0x0601E32A,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601E324 rts ; mov.l @r15+,r8
}

void f_0601E34C(SH2Context& c) {
    ran[339] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601E34C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601E34E sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0601E350 mov r15,r14
    c.r[1] = ld32(0x0601E380u);  // 0601E352 mov.l 0x0601E380,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601E354 mov.b @r1,r4
    c.r[2] = ld32(0x0601E384u);  // 0601E356 mov.l 0x0601E384,r2
    st8(c.r[2], c.r[4]);  // 0601E358 mov.b r4,@r2
    c.r[1] = ld32(0x0601E388u);  // 0601E35A mov.l 0x0601E388,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601E360u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601E360u) return; }  // 0601E35C jsr @r1 ; extu.b r4,r4
    c.r[0] = ld32(0x0601E38Cu);  // 0601E360 mov.l 0x0601E38C,r0
    c.r[5] = 0x1u;  // 0601E362 mov #1,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0601E368u; c.r[4] = 0xAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601E368u) return; }  // 0601E364 jsr @r0 ; mov #10,r4
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 0601E368 exts.w r0,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0601E36A cmp/eq #-1,r0
    { const bool k = c.t; c.r[0] = 0x1u; if (k) { goto L_0601E376; } }  // 0601E36C bt/s 0x0601E376 ; mov #1,r0
    c.r[0] = ld32(0x0601E390u);  // 0601E370 mov.l 0x0601E390,r0
    c.r[15] = c.r[14]; goto L_0601E378;  // 0601E372 bra 0x0601E378 ; mov r14,r15
L_0601E376:
    c.r[15] = c.r[14];  // 0601E376 mov r14,r15
L_0601E378:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601E378 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601E37A rts ; mov.l @r15+,r14
}

void f_0601E394(SH2Context& c) {
    ran[340] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601E394 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0601E396 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601E398 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601E39A sts.l pr,@-r15
    c.r[9] = ld32(0x0601E41Cu);  // 0601E39C mov.l 0x0601E41C,r9
    c.r[2] = ld32(c.r[9]);  // 0601E39E mov.l @r9,r2
    c.r[1] = c.r[2];  // 0601E3A0 mov r2,r1
    c.r[1] += 1;  // 0601E3A2 add #1,r1
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601E3A4 mov.b @r1,r8
    c.r[14] = c.r[15];  // 0601E3A6 mov r15,r14
    c.r[8] = c.r[8] & 0xFFu;  // 0601E3A8 extu.b r8,r8
    c.r[8] <<= 8;  // 0601E3AA shll8 r8
    c.r[1] = c.r[2];  // 0601E3AC mov r2,r1
    c.r[1] += 2;  // 0601E3AE add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601E3B0 mov.b @r1,r1
    c.r[2] += 3;  // 0601E3B2 add #3,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0601E3B4 extu.b r1,r1
    c.r[8] |= c.r[1];  // 0601E3B6 or r1,r8
    c.r[1] = ld32(0x0601E420u);  // 0601E3B8 mov.l 0x0601E420,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601E3BEu; st32(c.r[9], c.r[2]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601E3BEu) return; }  // 0601E3BA jsr @r1 ; mov.l r2,@r9
    c.r[0] = ld32(0x0601E424u);  // 0601E3BE mov.l 0x0601E424,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601E3C4u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601E3C4u) return; }  // 0601E3C0 jsr @r0 ; mov r8,r4
    c.r[0] = c.r[0] & 0xFFu;  // 0601E3C4 extu.b r0,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601E416u);  // 0601E3C6 mov.w 0x0601E416,r1
    c.t = c.r[0] == c.r[1];  // 0601E3C8 cmp/eq r1,r0
    if (c.t) { goto L_0601E408; }  // 0601E3CA bt 0x0601E408
    c.r[3] = ld32(c.r[9]);  // 0601E3CC mov.l @r9,r3
    c.r[2] = c.r[3];  // 0601E3CE mov r3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]); c.r[2] += 1;  // 0601E3D0 mov.b @r2+,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601E3D2 extu.b r1,r1
    c.r[7] = c.r[1];  // 0601E3D4 mov r1,r7
    c.r[7] <<= 8;  // 0601E3D6 shll8 r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601E3D8 mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601E3DA extu.b r1,r1
    c.r[7] |= c.r[1];  // 0601E3DC or r1,r7
    c.r[2] = c.r[7] & 0xFFFFu;  // 0601E3DE extu.w r7,r2
    c.r[1] = ld32(0x0601E428u);  // 0601E3E0 mov.l 0x0601E428,r1
    c.t = c.r[2] == c.r[1];  // 0601E3E2 cmp/eq r1,r2
    { const bool k = !c.t; c.t = (c.r[2] & c.r[2]) == 0; if (k) { goto L_0601E3EE; } }  // 0601E3E4 bf/s 0x0601E3EE ; tst r2,r2
    c.r[1] = ld32(0x0601E42Cu);  // 0601E3E8 mov.l 0x0601E42C,r1
    c.r[2] = ld32(c.r[1]); goto L_0601E3F8;  // 0601E3EA bra 0x0601E3F8 ; mov.l @r1,r2
L_0601E3EE:
    { const bool k = c.t; c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[7]; if (k) { goto L_0601E3F6; } }  // 0601E3EE bt/s 0x0601E3F6 ; exts.w r7,r2
    c.r[2] += c.r[3]; goto L_0601E3F8;  // 0601E3F2 bra 0x0601E3F8 ; add r3,r2
L_0601E3F6:
    c.r[2] = 0x0u;  // 0601E3F6 mov #0,r2
L_0601E3F8:
    c.r[1] = ld32(0x0601E430u);  // 0601E3F8 mov.l 0x0601E430,r1
    c.r[1] = ld32(c.r[1]);  // 0601E3FA mov.l @r1,r1
    c.r[0] <<= 2;  // 0601E3FC shll2 r0
    c.r[0] <<= 2;  // 0601E3FE shll2 r0
    c.r[0] += c.r[1];  // 0601E400 add r1,r0
    c.r[1] = ld32(0x0601E434u);  // 0601E402 mov.l 0x0601E434,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601E408u; st32(c.r[0] + 12, c.r[2]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601E408u) return; }  // 0601E404 jsr @r1 ; mov.l r2,@(12,r0)
L_0601E408:
    c.r[15] = c.r[14];  // 0601E408 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601E40A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601E40C mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0601E40E mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601E418u);  // 0601E410 mov.w 0x0601E418,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601E412 rts ; mov.l @r15+,r8
}

void f_0601E438(SH2Context& c) {
    ran[341] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601E438 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601E43A sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0601E43C mov r15,r14
    c.r[1] = ld32(0x0601E46Cu);  // 0601E43E mov.l 0x0601E46C,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601E440 mov.b @r1,r4
    c.r[2] = ld32(0x0601E470u);  // 0601E442 mov.l 0x0601E470,r2
    st8(c.r[2], c.r[4]);  // 0601E444 mov.b r4,@r2
    c.r[1] = ld32(0x0601E474u);  // 0601E446 mov.l 0x0601E474,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601E44Cu; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601E44Cu) return; }  // 0601E448 jsr @r1 ; extu.b r4,r4
    c.r[0] = ld32(0x0601E478u);  // 0601E44C mov.l 0x0601E478,r0
    c.r[5] = 0x1u;  // 0601E44E mov #1,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0601E454u; c.r[4] = 0xCu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601E454u) return; }  // 0601E450 jsr @r0 ; mov #12,r4
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 0601E454 exts.w r0,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0601E456 cmp/eq #-1,r0
    { const bool k = c.t; c.r[0] = 0x1u; if (k) { goto L_0601E462; } }  // 0601E458 bt/s 0x0601E462 ; mov #1,r0
    c.r[0] = ld32(0x0601E47Cu);  // 0601E45C mov.l 0x0601E47C,r0
    c.r[15] = c.r[14]; goto L_0601E464;  // 0601E45E bra 0x0601E464 ; mov r14,r15
L_0601E462:
    c.r[15] = c.r[14];  // 0601E462 mov r14,r15
L_0601E464:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601E464 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601E466 rts ; mov.l @r15+,r14
}

void f_0601E480(SH2Context& c) {
    ran[342] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601E480 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601E482 sts.l pr,@-r15
    c.r[4] = ld32(0x0601E4D0u);  // 0601E484 mov.l 0x0601E4D0,r4
    c.r[1] = c.r[4];  // 0601E486 mov r4,r1
    c.r[1] += 37;  // 0601E488 add #37,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601E48A mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601E48C extu.b r1,r1
    c.r[1] >>= 2;  // 0601E48E shlr2 r1
    c.r[1] >>= 2;  // 0601E490 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0601E492 shlr r1
    c.r[1] >>= 2;  // 0601E494 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601E496 tst r1,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0601E4A2; } }  // 0601E498 bt/s 0x0601E4A2 ; mov r15,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601E4CEu);  // 0601E49C mov.w 0x0601E4CE,r0
    c.r[15] = c.r[14]; goto L_0601E4C8;  // 0601E49E bra 0x0601E4C8 ; mov r14,r15
L_0601E4A2:
    c.r[4] += 33;  // 0601E4A2 add #33,r4
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[4]);  // 0601E4A4 mov.b @r4,r4
    c.r[1] = ld32(0x0601E4D4u);  // 0601E4A6 mov.l 0x0601E4D4,r1
    st8(c.r[1], c.r[4]);  // 0601E4A8 mov.b r4,@r1
    c.r[1] = ld32(0x0601E4D8u);  // 0601E4AA mov.l 0x0601E4D8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601E4B0u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601E4B0u) return; }  // 0601E4AC jsr @r1 ; extu.b r4,r4
    c.r[0] = ld32(0x0601E4DCu);  // 0601E4B0 mov.l 0x0601E4DC,r0
    c.r[5] = 0x1u;  // 0601E4B2 mov #1,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0601E4B8u; c.r[4] = 0xBu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601E4B8u) return; }  // 0601E4B4 jsr @r0 ; mov #11,r4
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 0601E4B8 exts.w r0,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0601E4BA cmp/eq #-1,r0
    { const bool k = c.t; c.r[0] = 0x1u; if (k) { goto L_0601E4C6; } }  // 0601E4BC bt/s 0x0601E4C6 ; mov #1,r0
    c.r[0] = ld32(0x0601E4E0u);  // 0601E4C0 mov.l 0x0601E4E0,r0
    c.r[15] = c.r[14]; goto L_0601E4C8;  // 0601E4C2 bra 0x0601E4C8 ; mov r14,r15
L_0601E4C6:
    c.r[15] = c.r[14];  // 0601E4C6 mov r14,r15
L_0601E4C8:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601E4C8 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601E4CA rts ; mov.l @r15+,r14
}

void f_0601E4E4(SH2Context& c) {
    ran[343] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601E4E4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0601E4E6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601E4E8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601E4EA sts.l pr,@-r15
    c.r[1] = ld32(0x0601E720u);  // 0601E4EC mov.l 0x0601E720,r1
    c.r[2] = ld32(c.r[1]);  // 0601E4EE mov.l @r1,r2
    c.r[1] = c.r[2];  // 0601E4F0 mov r2,r1
    c.r[1] += 1;  // 0601E4F2 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601E4F4 mov.b @r1,r1
    c.r[2] += 2;  // 0601E4F6 add #2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0601E4F8 extu.b r1,r1
    c.r[8] = c.r[1];  // 0601E4FA mov r1,r8
    c.r[8] <<= 8;  // 0601E4FC shll8 r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601E4FE mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601E500 extu.b r1,r1
    c.r[8] |= c.r[1];  // 0601E502 or r1,r8
    c.r[1] = ld32(0x0601E724u);  // 0601E504 mov.l 0x0601E724,r1
    c.r[2] = 0xFu;  // 0601E506 mov #15,r2
    c.r[0] = c.r[8];  // 0601E508 mov r8,r0
    c.r[0] -= c.r[1];  // 0601E50A sub r1,r0
    c.r[1] = c.r[0];  // 0601E50C mov r0,r1
    c.t = c.r[1] > c.r[2];  // 0601E50E cmp/hi r2,r1
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0601E518; } }  // 0601E510 bf/s 0x0601E518 ; mov r15,r14
    goto L_0601E6CA;  // 0601E514 bra 0x0601E6CA ; nop
L_0601E518:
    c.r[1] += c.r[1];  // 0601E518 add r1,r1
    c.r[0] = 0x0601E524u;  // 0601E51A mova 0x0601E524,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0601E51C mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 0601E51E add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x0601E560u: goto L_0601E560; case 0x0601E5D2u: goto L_0601E5D2; case 0x0601E614u: goto L_0601E614; case 0x0601E6AEu: goto L_0601E6AE; case 0x0601E6CAu: goto L_0601E6CA; case 0x0601E544u: goto L_0601E544; default: sh2_call(c, x); return; } }  // 0601E520 jmp @r0 ; nop
L_0601E544:
    c.r[1] = ld32(0x0601E728u);  // 0601E544 mov.l 0x0601E728,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601E546 mov.b @r1,r1
    c.r[2] = ld32(0x0601E72Cu);  // 0601E548 mov.l 0x0601E72C,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0601E54A extu.b r1,r1
    st32(c.r[2] + 12, c.r[1]);  // 0601E54C mov.l r1,@(12,r2)
    c.r[1] = ld32(0x0601E730u);  // 0601E54E mov.l 0x0601E730,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601E550 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601E552 extu.b r1,r1
    st32(c.r[2] + 16, c.r[1]);  // 0601E554 mov.l r1,@(16,r2)
    c.r[1] = ld32(0x0601E734u);  // 0601E556 mov.l 0x0601E734,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601E558 mov.b @r1,r1
    c.r[2] = ld32(0x0601E738u);  // 0601E55A mov.l 0x0601E738,r2
    st8(c.r[2], c.r[1]); goto L_0601E70C;  // 0601E55C bra 0x0601E70C ; mov.b r1,@r2
L_0601E560:
    c.r[1] = ld32(0x0601E73Cu);  // 0601E560 mov.l 0x0601E73C,r1
    c.r[0] = 0x3u;  // 0601E562 mov #3,r0
    c.r[8] &= c.r[0];  // 0601E564 and r0,r8
    st8(c.r[1], c.r[8]);  // 0601E566 mov.b r8,@r1
    c.r[1] = ld32(0x0601E720u);  // 0601E568 mov.l 0x0601E720,r1
    c.r[2] = ld32(c.r[1]);  // 0601E56A mov.l @r1,r2
    c.r[1] = c.r[2];  // 0601E56C mov r2,r1
    c.r[1] += 3;  // 0601E56E add #3,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601E570 mov.b @r1,r4
    c.r[2] += 4;  // 0601E572 add #4,r2
    c.r[4] = c.r[4] & 0xFFu;  // 0601E574 extu.b r4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601E576 mov.b @r2,r1
    c.r[4] <<= 8;  // 0601E578 shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 0601E57A extu.b r1,r1
    c.r[4] |= c.r[1];  // 0601E57C or r1,r4
    c.r[1] = ld32(0x0601E740u);  // 0601E57E mov.l 0x0601E740,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601E584u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601E584u) return; }  // 0601E580 jsr @r1 ; nop
    c.r[1] = ld32(0x0601E734u);  // 0601E584 mov.l 0x0601E734,r1
    c.r[3] = c.r[1];  // 0601E586 mov r1,r3
    c.r[3] += 1;  // 0601E588 add #1,r3
    c.r[2] = ld32(0x0601E744u);  // 0601E58A mov.l 0x0601E744,r2
    c.r[7] = ld32(0x0601E728u);  // 0601E58C mov.l 0x0601E728,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601E58E mov.b @r1,r1
    c.r[5] = 0x6u;  // 0601E590 mov #6,r5
    st8(c.r[2], c.r[1]);  // 0601E592 mov.b r1,@r2
    st8(c.r[3], c.r[1]);  // 0601E594 mov.b r1,@r3
L_0601E596:
    c.r[1] = ld32(0x0601E738u);  // 0601E596 mov.l 0x0601E738,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601E598 mov.b @r1,r2
    c.r[4] = 0x1Du;  // 0601E59A mov #29,r4
    c.r[2] = c.r[2] & 0xFFu;  // 0601E59C extu.b r2,r2
    c.r[1] = ld32(0x0601E748u);  // 0601E59E mov.l 0x0601E748,r1
    c.r[2] <<= 2;  // 0601E5A0 shll2 r2
    c.r[2] <<= 2;  // 0601E5A2 shll2 r2
    c.r[3] = c.r[2];  // 0601E5A4 mov r2,r3
    c.r[1] = ld32(c.r[1]);  // 0601E5A6 mov.l @r1,r1
    c.r[0] = c.r[2];  // 0601E5A8 mov r2,r0
    c.r[3] += c.r[1];  // 0601E5AA add r1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601E5AC mov.b @(r0,r1),r1
    c.r[3] += 1;  // 0601E5AE add #1,r3
    st8(c.r[7], c.r[1]);  // 0601E5B0 mov.b r1,@r7
    c.r[2] = ld32(0x0601E730u);  // 0601E5B2 mov.l 0x0601E730,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0601E5B4 mov.b @r3,r1
    c.r[0] = ld32(0x0601E74Cu);  // 0601E5B6 mov.l 0x0601E74C,r0
    st8(c.r[2], c.r[1]);  // 0601E5B8 mov.b r1,@r2
L_0601E5BA:
    { const uint32_t x = c.r[0]; c.pr = 0x0601E5BEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601E5BEu) return; }  // 0601E5BA jsr @r0 ; nop
    c.r[1] = c.r[0];  // 0601E5BE mov r0,r1
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[1];  // 0601E5C0 exts.w r1,r1
    c.r[0] = c.r[1];  // 0601E5C2 mov r1,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0601E5C4 cmp/eq #-1,r0
    { const bool k = !c.t; c.r[0] = 0x1u; if (k) { goto L_0601E5CE; } }  // 0601E5C6 bf/s 0x0601E5CE ; mov #1,r0
    goto L_0601E70E;  // 0601E5CA bra 0x0601E70E ; nop
L_0601E5CE:
    goto L_0601E706;  // 0601E5CE bra 0x0601E706 ; nop
L_0601E5D2:
    c.r[8] = ld32(0x0601E73Cu);  // 0601E5D2 mov.l 0x0601E73C,r8
    c.r[9] = ld32(0x0601E72Cu);  // 0601E5D4 mov.l 0x0601E72C,r9
    c.r[1] = c.r[9];  // 0601E5D6 mov r9,r1
    c.r[1] += 26;  // 0601E5D8 add #26,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0601E5DA mov.w @r1,r4
    c.r[0] = ld32(0x0601E750u);  // 0601E5DC mov.l 0x0601E750,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601E5E2u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601E5E2u) return; }  // 0601E5DE jsr @r0 ; extu.w r4,r4
    c.r[1] = c.r[0];  // 0601E5E2 mov r0,r1
    st8(c.r[8], c.r[1]);  // 0601E5E4 mov.b r1,@r8
    c.r[1] = ld32(0x0601E720u);  // 0601E5E6 mov.l 0x0601E720,r1
    c.r[2] = ld32(c.r[1]);  // 0601E5E8 mov.l @r1,r2
    c.r[1] = c.r[2];  // 0601E5EA mov r2,r1
    c.r[1] += 3;  // 0601E5EC add #3,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601E5EE mov.b @r1,r4
    c.r[2] += 4;  // 0601E5F0 add #4,r2
    c.r[4] = c.r[4] & 0xFFu;  // 0601E5F2 extu.b r4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601E5F4 mov.b @r2,r1
    c.r[4] <<= 8;  // 0601E5F6 shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 0601E5F8 extu.b r1,r1
    c.r[4] |= c.r[1];  // 0601E5FA or r1,r4
    c.r[1] = ld32(0x0601E740u);  // 0601E5FC mov.l 0x0601E740,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601E602u; c.r[9] += 36; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601E602u) return; }  // 0601E5FE jsr @r1 ; add #36,r9
    c.r[1] = ld32(0x0601E734u);  // 0601E602 mov.l 0x0601E734,r1
    c.r[2] = c.r[1];  // 0601E604 mov r1,r2
    c.r[2] += 1;  // 0601E606 add #1,r2
    c.r[7] = ld32(0x0601E728u);  // 0601E608 mov.l 0x0601E728,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601E60A mov.b @r1,r1
    c.r[5] = 0x6u;  // 0601E60C mov #6,r5
    st8(c.r[9], c.r[1]);  // 0601E60E mov.b r1,@r9
    st8(c.r[2], c.r[1]); SH2_POLL(c); goto L_0601E596;  // 0601E610 bra 0x0601E596 ; mov.b r1,@r2
L_0601E614:
    c.r[8] = ld32(0x0601E720u);  // 0601E614 mov.l 0x0601E720,r8
    c.r[2] = ld32(c.r[8]);  // 0601E616 mov.l @r8,r2
    c.r[1] = c.r[2];  // 0601E618 mov r2,r1
    c.r[1] += 3;  // 0601E61A add #3,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601E61C mov.b @r1,r4
    c.r[2] += 4;  // 0601E61E add #4,r2
    c.r[4] = c.r[4] & 0xFFu;  // 0601E620 extu.b r4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601E622 mov.b @r2,r1
    c.r[4] <<= 8;  // 0601E624 shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 0601E626 extu.b r1,r1
    c.r[4] |= c.r[1];  // 0601E628 or r1,r4
    c.r[1] = ld32(0x0601E740u);  // 0601E62A mov.l 0x0601E740,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601E630u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601E630u) return; }  // 0601E62C jsr @r1 ; nop
    c.r[1] = ld32(0x0601E734u);  // 0601E630 mov.l 0x0601E734,r1
    c.r[3] = c.r[1];  // 0601E632 mov r1,r3
    c.r[3] += 1;  // 0601E634 add #1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601E636 mov.b @r1,r1
    c.r[2] = ld32(0x0601E744u);  // 0601E638 mov.l 0x0601E744,r2
    st8(c.r[2], c.r[1]);  // 0601E63A mov.b r1,@r2
    st8(c.r[3], c.r[1]);  // 0601E63C mov.b r1,@r3
    c.r[2] = ld32(c.r[8]);  // 0601E63E mov.l @r8,r2
    c.r[9] = ld32(0x0601E73Cu);  // 0601E640 mov.l 0x0601E73C,r9
    c.r[1] = c.r[2];  // 0601E642 mov r2,r1
    c.r[1] += 7;  // 0601E644 add #7,r1
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601E646 mov.b @r1,r7
    c.r[2] += 6;  // 0601E648 add #6,r2
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601E64A mov.b @r2,r6
    c.r[7] = c.r[7] & 0xFFu;  // 0601E64C extu.b r7,r7
    c.r[1] = ld32(0x0601E738u);  // 0601E64E mov.l 0x0601E738,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601E650 mov.b @r1,r2
    c.r[6] = c.r[6] & 0xFFu;  // 0601E652 extu.b r6,r6
    c.r[2] = c.r[2] & 0xFFu;  // 0601E654 extu.b r2,r2
    c.r[1] = ld32(0x0601E748u);  // 0601E656 mov.l 0x0601E748,r1
    c.r[3] = ld32(c.r[1]);  // 0601E658 mov.l @r1,r3
    c.r[2] <<= 2;  // 0601E65A shll2 r2
    c.r[2] <<= 2;  // 0601E65C shll2 r2
    c.r[1] = c.r[2];  // 0601E65E mov r2,r1
    c.r[1] += c.r[3];  // 0601E660 add r3,r1
    c.r[1] += 1;  // 0601E662 add #1,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601E664 mov.b @r1,r5
    c.r[0] = c.r[2];  // 0601E666 mov r2,r0
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0601E668 mov.b @(r0,r3),r4
    c.r[5] = c.r[5] & 0xFFu;  // 0601E66A extu.b r5,r5
    c.r[0] = ld32(0x0601E754u);  // 0601E66C mov.l 0x0601E754,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601E672u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601E672u) return; }  // 0601E66E jsr @r0 ; extu.b r4,r4
    c.r[1] = c.r[0];  // 0601E672 mov r0,r1
    st8(c.r[9], c.r[1]);  // 0601E674 mov.b r1,@r9
    c.r[2] = ld32(0x0601E728u);  // 0601E676 mov.l 0x0601E728,r2
    c.r[5] = 0x8u;  // 0601E678 mov #8,r5
    c.r[4] = 0x1Du;  // 0601E67A mov #29,r4
    c.r[7] = ld32(c.r[8]);  // 0601E67C mov.l @r8,r7
    c.r[0] = ld32(0x0601E74Cu);  // 0601E67E mov.l 0x0601E74C,r0
    c.r[1] = c.r[7];  // 0601E680 mov r7,r1
    c.r[1] += 6;  // 0601E682 add #6,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601E684 mov.b @r1,r3
    c.r[7] += 7;  // 0601E686 add #7,r7
    st8(c.r[2], c.r[3]);  // 0601E688 mov.b r3,@r2
    c.r[1] = ld32(0x0601E730u);  // 0601E68A mov.l 0x0601E730,r1
    c.r[2] = ld32(0x0601E758u);  // 0601E68C mov.l 0x0601E758,r2
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0601E68E mov.b @r7,r7
    c.r[6] = c.r[2];  // 0601E690 mov r2,r6
    st8(c.r[1], c.r[7]);  // 0601E692 mov.b r7,@r1
    c.r[1] = c.r[2];  // 0601E694 mov r2,r1
    c.r[1] += 78;  // 0601E696 add #78,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601E698 mov.b @r1,r1
    c.r[6] += 116;  // 0601E69A add #116,r6
    c.r[3] -= c.r[1];  // 0601E69C sub r1,r3
    st8(c.r[6], c.r[3]);  // 0601E69E mov.b r3,@r6
    c.r[3] = c.r[2];  // 0601E6A0 mov r2,r3
    c.r[2] += 79;  // 0601E6A2 add #79,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601E6A4 mov.b @r2,r1
    c.r[3] += 117;  // 0601E6A6 add #117,r3
    c.r[7] -= c.r[1];  // 0601E6A8 sub r1,r7
    st8(c.r[3], c.r[7]); SH2_POLL(c); goto L_0601E5BA;  // 0601E6AA bra 0x0601E5BA ; mov.b r7,@r3
L_0601E6AE:
    c.r[7] = ld32(0x0601E75Cu);  // 0601E6AE mov.l 0x0601E75C,r7
    c.r[2] = ld32(0x0601E760u);  // 0601E6B0 mov.l 0x0601E760,r2
    c.r[3] = c.r[2];  // 0601E6B2 mov r2,r3
    c.r[1] = ld32(0x0601E720u);  // 0601E6B4 mov.l 0x0601E720,r1
    c.r[1] = ld32(c.r[1]);  // 0601E6B6 mov.l @r1,r1
    c.r[3] += 2;  // 0601E6B8 add #2,r3
    c.r[1] += 3;  // 0601E6BA add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601E6BC mov.b @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601E71Au);  // 0601E6BE mov.w 0x0601E71A,r0
    st8(c.r[3], c.r[1]);  // 0601E6C0 mov.b r1,@r3
    st8(c.r[2], c.r[1]);  // 0601E6C2 mov.b r1,@r2
    c.r[1] = c.r[1] & 0xFFu;  // 0601E6C4 extu.b r1,r1
    st16(c.r[7], c.r[1]); goto L_0601E70E;  // 0601E6C6 bra 0x0601E70E ; mov.w r1,@r7
L_0601E6CA:
    c.r[1] = ld32(0x0601E720u);  // 0601E6CA mov.l 0x0601E720,r1
    c.r[2] = ld32(c.r[1]);  // 0601E6CC mov.l @r1,r2
    c.r[0] = ld32(0x0601E764u);  // 0601E6CE mov.l 0x0601E764,r0
    c.r[1] = c.r[2];  // 0601E6D0 mov r2,r1
    c.r[1] += 3;  // 0601E6D2 add #3,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601E6D4 mov.b @r1,r4
    c.r[2] += 4;  // 0601E6D6 add #4,r2
    c.r[4] = c.r[4] & 0xFFu;  // 0601E6D8 extu.b r4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601E6DA mov.b @r2,r1
    c.r[4] <<= 8;  // 0601E6DC shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 0601E6DE extu.b r1,r1
    { const uint32_t x = c.r[0]; c.pr = 0x0601E6E4u; c.r[4] |= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601E6E4u) return; }  // 0601E6E0 jsr @r0 ; or r1,r4
    c.r[2] = ld32(0x0601E768u);  // 0601E6E4 mov.l 0x0601E768,r2
    c.r[1] = ld32(0x0601E744u);  // 0601E6E6 mov.l 0x0601E744,r1
    st8(c.r[1], c.r[0]);  // 0601E6E8 mov.b r0,@r1
    st8(c.r[2], c.r[0]);  // 0601E6EA mov.b r0,@r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601E71Cu);  // 0601E6EC mov.w 0x0601E71C,r1
    c.r[8] &= c.r[1];  // 0601E6EE and r1,r8
    c.r[1] = ld32(0x0601E740u);  // 0601E6F0 mov.l 0x0601E740,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601E6F6u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601E6F6u) return; }  // 0601E6F2 jsr @r1 ; mov r8,r4
    c.r[0] = ld32(0x0601E74Cu);  // 0601E6F6 mov.l 0x0601E74C,r0
    c.r[5] = 0x6u;  // 0601E6F8 mov #6,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0601E6FEu; c.r[4] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601E6FEu) return; }  // 0601E6FA jsr @r0 ; mov #23,r4
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 0601E6FE exts.w r0,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0601E700 cmp/eq #-1,r0
    { const bool k = c.t; c.r[0] = 0x1u; if (k) { goto L_0601E70E; } }  // 0601E702 bt/s 0x0601E70E ; mov #1,r0
L_0601E706:
    c.r[0] = ld32(0x0601E76Cu);  // 0601E706 mov.l 0x0601E76C,r0
    c.r[15] = c.r[14]; goto L_0601E710;  // 0601E708 bra 0x0601E710 ; mov r14,r15
L_0601E70C:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601E71Eu);  // 0601E70C mov.w 0x0601E71E,r0
L_0601E70E:
    c.r[15] = c.r[14];  // 0601E70E mov r14,r15
L_0601E710:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601E710 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601E712 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0601E714 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601E716 rts ; mov.l @r15+,r8
}

void f_0601E770(SH2Context& c) {
    ran[344] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601E770 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0601E772 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0601E774 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0601E776 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0601E778 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601E77A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601E77C sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0601E77E mov r15,r14
    c.r[0] = ld32(0x0601E824u);  // 0601E780 mov.l 0x0601E824,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601E786u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601E786u) return; }  // 0601E782 jsr @r0 ; extu.w r4,r4
    c.r[11] = ld32(0x0601E828u);  // 0601E786 mov.l 0x0601E828,r11
    c.r[8] = ld32(0x0601E82Cu);  // 0601E788 mov.l 0x0601E82C,r8
    c.r[2] = c.r[8];  // 0601E78A mov r8,r2
    c.r[2] += 33;  // 0601E78C add #33,r2
    c.r[1] = c.r[8];  // 0601E78E mov r8,r1
    c.r[1] += 32;  // 0601E790 add #32,r1
    st8(c.r[1], c.r[0]);  // 0601E792 mov.b r0,@r1
    st8(c.r[2], c.r[0]);  // 0601E794 mov.b r0,@r2
    st8(c.r[11], c.r[0]);  // 0601E796 mov.b r0,@r11
    c.r[12] = ld32(0x0601E830u);  // 0601E798 mov.l 0x0601E830,r12
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[12]);  // 0601E79A mov.b @r12,r4
    c.r[10] = ld32(0x0601E834u);  // 0601E79C mov.l 0x0601E834,r10
    { const uint32_t x = c.r[10]; c.pr = 0x0601E7A2u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601E7A2u) return; }  // 0601E79E jsr @r10 ; extu.b r4,r4
    c.r[1] = ld32(0x0601E838u);  // 0601E7A2 mov.l 0x0601E838,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[12]);  // 0601E7A4 mov.b @r12,r2
    c.r[6] = (uint32_t)(int16_t)ld16(0x0601E822u);  // 0601E7A6 mov.w 0x0601E822,r6
    c.r[1] = ld32(c.r[1]);  // 0601E7A8 mov.l @r1,r1
    c.r[9] = ld32(0x0601E83Cu);  // 0601E7AA mov.l 0x0601E83C,r9
    c.r[4] = ld32(c.r[9]);  // 0601E7AC mov.l @r9,r4
    c.r[2] = c.r[2] & 0xFFu;  // 0601E7AE extu.b r2,r2
    c.r[2] <<= 2;  // 0601E7B0 shll2 r2
    c.r[2] <<= 2;  // 0601E7B2 shll2 r2
    c.r[2] += c.r[1];  // 0601E7B4 add r1,r2
    c.r[2] += 2;  // 0601E7B6 add #2,r2
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601E7B8 mov.b @r2,r5
    c.r[1] = ld32(0x0601E840u);  // 0601E7BA mov.l 0x0601E840,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601E7C0u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601E7C0u) return; }  // 0601E7BC jsr @r1 ; extu.b r5,r5
    c.r[1] = c.r[8];  // 0601E7C0 mov r8,r1
    c.r[1] += 36;  // 0601E7C2 add #36,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601E7C4 mov.b @r1,r4
    { const uint32_t x = c.r[10]; c.pr = 0x0601E7CAu; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601E7CAu) return; }  // 0601E7C6 jsr @r10 ; extu.b r4,r4
    c.r[8] += 24;  // 0601E7CA add #24,r8
    c.r[2] = ld32(0x0601E844u);  // 0601E7CC mov.l 0x0601E844,r2
    c.r[1] = ld32(0x0601E848u);  // 0601E7CE mov.l 0x0601E848,r1
    c.r[1] = ld32(c.r[1]);  // 0601E7D0 mov.l @r1,r1
    c.r[3] = c.r[2];  // 0601E7D2 mov r2,r3
    c.r[1] += 5;  // 0601E7D4 add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601E7D6 mov.b @r1,r1
    c.r[3] += 2;  // 0601E7D8 add #2,r3
    st8(c.r[3], c.r[1]);  // 0601E7DA mov.b r1,@r3
    st8(c.r[2], c.r[1]);  // 0601E7DC mov.b r1,@r2
    c.r[1] = c.r[1] & 0xFFu;  // 0601E7DE extu.b r1,r1
    st16(c.r[8], c.r[1]);  // 0601E7E0 mov.w r1,@r8
    c.r[2] = 0x14u;  // 0601E7E2 mov #20,r2
    c.macl = (uint32_t)((int32_t)(int16_t)c.r[1] * (int16_t)c.r[2]);  // 0601E7E4 muls.w r2,r1
    c.r[3] = ld32(c.r[9]);  // 0601E7E6 mov.l @r9,r3
    c.r[1] = c.macl;  // 0601E7E8 sts macl,r1
    c.r[3] += c.r[1];  // 0601E7EA add r1,r3
    c.r[3] += 50;  // 0601E7EC add #50,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0601E7EE mov.b @r3,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0601E7F0 extu.b r1,r0
    c.r[0] >>= 2;  // 0601E7F2 shlr2 r0
    c.r[0] >>= 2;  // 0601E7F4 shlr2 r0
    c.r[0] >>= 2;  // 0601E7F6 shlr2 r0
    c.t = c.r[0] == 0x2u;  // 0601E7F8 cmp/eq #2,r0
    if (c.t) { goto L_0601E7FE; }  // 0601E7FA bt 0x0601E7FE
    c.r[11] += 1;  // 0601E7FC add #1,r11
L_0601E7FE:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[11]);  // 0601E7FE mov.b @r11,r1
    st8(c.r[12], c.r[1]);  // 0601E800 mov.b r1,@r12
    c.r[2] = ld32(0x0601E82Cu);  // 0601E802 mov.l 0x0601E82C,r2
    c.r[1] = 0xFFFFFFFFu;  // 0601E804 mov #-1,r1
    st32(c.r[2] + 16, c.r[1]);  // 0601E806 mov.l r1,@(16,r2)
    st32(c.r[2] + 12, c.r[1]);  // 0601E808 mov.l r1,@(12,r2)
    c.r[2] = ld32(0x0601E84Cu);  // 0601E80A mov.l 0x0601E84C,r2
    c.r[1] = 0x1u;  // 0601E80C mov #1,r1
    st8(c.r[2], c.r[1]);  // 0601E80E mov.b r1,@r2
    c.r[15] = c.r[14];  // 0601E810 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601E812 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601E814 mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0601E816 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0601E818 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0601E81A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0601E81C mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601E81E rts ; mov.l @r15+,r8
}

void f_0601E850(SH2Context& c) {
    ran[345] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601E850 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0601E852 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601E854 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601E856 sts.l pr,@-r15
    c.r[1] = ld32(0x0601E908u);  // 0601E858 mov.l 0x0601E908,r1
    c.r[3] = ld32(c.r[1]);  // 0601E85A mov.l @r1,r3
    c.r[6] = (uint32_t)(int16_t)ld16(0x0601E902u);  // 0601E85C mov.w 0x0601E902,r6
    c.r[1] = c.r[3];  // 0601E85E mov r3,r1
    c.r[1] += 1;  // 0601E860 add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601E862 mov.b @r1,r2
    c.r[3] += 2;  // 0601E864 add #2,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0601E866 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0601E868 mov.b @r3,r1
    c.r[2] <<= 8;  // 0601E86A shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0601E86C extu.b r1,r1
    c.r[2] |= c.r[1];  // 0601E86E or r1,r2
    c.r[1] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0601E870 exts.w r2,r1
    c.r[0] = c.r[1];  // 0601E872 mov r1,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0601E874 cmp/eq #-1,r0
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0601E8C8; } }  // 0601E876 bf/s 0x0601E8C8 ; mov r15,r14
    c.r[2] = 0x0u;  // 0601E87A mov #0,r2
    c.r[9] = ld32(0x0601E90Cu);  // 0601E87C mov.l 0x0601E90C,r9
    c.r[8] = c.r[6];  // 0601E87E mov r6,r8
    c.r[4] = ld32(0x0601E910u);  // 0601E880 mov.l 0x0601E910,r4
    c.r[5] = 0x1u;  // 0601E882 mov #1,r5
    c.r[0] = c.r[2];  // 0601E884 mov r2,r0
L_0601E886:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 0601E886 mov.b @(r0,r9),r1
    c.r[6] = c.r[1] & 0xFFu;  // 0601E888 extu.b r1,r6
    c.t = c.r[6] == c.r[8];  // 0601E88A cmp/eq r8,r6
    if (c.t) { goto L_0601E8AC; }  // 0601E88C bt 0x0601E8AC
    c.r[3] = c.r[6];  // 0601E88E mov r6,r3
    c.r[3] <<= 2;  // 0601E890 shll2 r3
    c.r[3] <<= 2;  // 0601E892 shll2 r3
    c.r[7] = ld32(c.r[4]);  // 0601E894 mov.l @r4,r7
    c.r[6] = c.r[3];  // 0601E896 mov r3,r6
    c.r[6] += c.r[7];  // 0601E898 add r7,r6
    c.r[1] = c.r[6];  // 0601E89A mov r6,r1
    c.r[1] += 3;  // 0601E89C add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601E89E mov.b @r1,r1
    c.r[0] = c.r[1];  // 0601E8A0 mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0601E8A2 shlr r0
    c.r[0] &= 0x3u;  // 0601E8A4 and #3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601E8A6 tst r0,r0
    { const bool k = !c.t; c.r[0] = c.r[3]; if (k) { goto L_0601E8B8; } }  // 0601E8A8 bf/s 0x0601E8B8 ; mov r3,r0
L_0601E8AC:
    c.r[2] += 1;  // 0601E8AC add #1,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[5];  // 0601E8AE cmp/gt r5,r2
    { const bool k = !c.t; c.r[0] = c.r[2]; if (k) { SH2_POLL(c); goto L_0601E886; } }  // 0601E8B0 bf/s 0x0601E886 ; mov r2,r0
    c.r[15] = c.r[14]; goto L_0601E8F6;  // 0601E8B4 bra 0x0601E8F6 ; mov r14,r15
L_0601E8B8:
    c.r[1] = ld32(0x0601E914u);  // 0601E8B8 mov.l 0x0601E914,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0601E8BA mov.b @(r0,r7),r2
    c.r[6] += 1;  // 0601E8BC add #1,r6
    st8(c.r[1], c.r[2]);  // 0601E8BE mov.b r2,@r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0601E8C0 mov.b @r6,r2
    c.r[1] += 1;  // 0601E8C2 add #1,r1
    st8(c.r[1], c.r[2]); goto L_0601E8F4;  // 0601E8C4 bra 0x0601E8F4 ; mov.b r2,@r1
L_0601E8C8:
    c.r[0] = ld32(0x0601E918u);  // 0601E8C8 mov.l 0x0601E918,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601E8CEu; c.r[4] = c.r[1] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601E8CEu) return; }  // 0601E8CA jsr @r0 ; extu.w r1,r4
    c.r[6] = c.r[0] & 0xFFu;  // 0601E8CE extu.b r0,r6
    c.r[3] = 0xFFFFFFFFu;  // 0601E8D0 mov #-1,r3
    c.r[2] = c.r[3] & 0xFFu;  // 0601E8D2 extu.b r3,r2
    c.t = c.r[6] == c.r[2];  // 0601E8D4 cmp/eq r2,r6
    { const bool k = c.t; c.r[6] <<= 2; if (k) { goto L_0601E8F4; } }  // 0601E8D6 bt/s 0x0601E8F4 ; shll2 r6
    c.r[1] = ld32(0x0601E910u);  // 0601E8DA mov.l 0x0601E910,r1
    c.r[6] <<= 2;  // 0601E8DC shll2 r6
    c.r[1] = ld32(c.r[1]);  // 0601E8DE mov.l @r1,r1
    c.r[0] = c.r[6];  // 0601E8E0 mov r6,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601E8E2 mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601E8E4 extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 0601E8E6 cmp/eq r2,r1
    if (c.t) { goto L_0601E8F4; }  // 0601E8E8 bt 0x0601E8F4
    c.r[2] = ld32(0x0601E914u);  // 0601E8EA mov.l 0x0601E914,r2
    c.r[1] = c.r[2];  // 0601E8EC mov r2,r1
    c.r[1] += 1;  // 0601E8EE add #1,r1
    st8(c.r[1], c.r[3]);  // 0601E8F0 mov.b r3,@r1
    st8(c.r[2], c.r[3]);  // 0601E8F2 mov.b r3,@r2
L_0601E8F4:
    c.r[15] = c.r[14];  // 0601E8F4 mov r14,r15
L_0601E8F6:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601E8F6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601E8F8 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0601E8FA mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601E904u);  // 0601E8FC mov.w 0x0601E904,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601E8FE rts ; mov.l @r15+,r8
}

void f_0601E91C(SH2Context& c) {
    ran[346] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601E91C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0601E91E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0601E920 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601E922 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601E924 sts.l pr,@-r15
    c.r[1] = ld32(0x0601E97Cu);  // 0601E926 mov.l 0x0601E97C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601E92Cu; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601E92Cu) return; }  // 0601E928 jsr @r1 ; mov r15,r14
    c.r[8] = ld32(0x0601E980u);  // 0601E92C mov.l 0x0601E980,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0601E92E mov.b @r8,r1
    c.r[9] = 0xFFFFFFFFu;  // 0601E930 mov #-1,r9
    c.r[7] = c.r[9] & 0xFFu;  // 0601E932 extu.b r9,r7
    c.r[4] = c.r[1] & 0xFFu;  // 0601E934 extu.b r1,r4
    c.t = c.r[4] == c.r[7];  // 0601E936 cmp/eq r7,r4
    { const bool k = c.t; c.r[10] = c.r[8]; if (k) { goto L_0601E96A; } }  // 0601E938 bt/s 0x0601E96A ; mov r8,r10
    c.r[10] += 1;  // 0601E93C add #1,r10
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0601E93E mov.b @r10,r5
    c.r[1] = 0x0u;  // 0601E940 mov #0,r1
    c.r[0] = ld32(0x0601E984u);  // 0601E942 mov.l 0x0601E984,r0
    c.r[6] = 0x0u;  // 0601E944 mov #0,r6
    c.r[5] = c.r[5] & 0xFFu;  // 0601E946 extu.b r5,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0601E94Cu; c.r[15] -= 4; st32(c.r[15], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601E94Cu) return; }  // 0601E948 jsr @r0 ; mov.l r1,@-r15
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0601E94C cmp/eq #-1,r0
    { const bool k = c.t; c.r[15] += 4; if (k) { goto L_0601E96A; } }  // 0601E94E bt/s 0x0601E96A ; add #4,r15
    st8(c.r[10], c.r[9]);  // 0601E952 mov.b r9,@r10
    st8(c.r[8], c.r[9]);  // 0601E954 mov.b r9,@r8
    c.r[8] += 2;  // 0601E956 add #2,r8
    c.r[1] = 0x0u;  // 0601E958 mov #0,r1
    st16(c.r[8], c.r[1]);  // 0601E95A mov.w r1,@r8
    c.r[1] = ld32(0x0601E988u);  // 0601E95C mov.l 0x0601E988,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601E95E mov.b @r1,r1
    c.r[2] = ld32(0x0601E98Cu);  // 0601E960 mov.l 0x0601E98C,r2
    st8(c.r[2], c.r[1]);  // 0601E962 mov.b r1,@r2
    c.r[1] = ld32(0x0601E990u);  // 0601E964 mov.l 0x0601E990,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601E96Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601E96Au) return; }  // 0601E966 jsr @r1 ; nop
L_0601E96A:
    c.r[15] = c.r[14];  // 0601E96A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601E96C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601E96E mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0601E970 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0601E972 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601E97Au);  // 0601E974 mov.w 0x0601E97A,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601E976 rts ; mov.l @r15+,r8
}

void f_0601E994(SH2Context& c) {
    ran[347] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601E994 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601E996 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0601E998 mov r15,r14
    c.r[4] = ld32(0x0601E9B4u);  // 0601E99A mov.l 0x0601E9B4,r4
    c.r[0] = ld32(0x0601E9B8u);  // 0601E99C mov.l 0x0601E9B8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601E9A2u; c.r[5] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601E9A2u) return; }  // 0601E99E jsr @r0 ; mov #1,r5
    c.r[2] = ld32(0x0601E9BCu);  // 0601E9A2 mov.l 0x0601E9BC,r2
    c.r[1] = c.r[0] & 0xFFFFu;  // 0601E9A4 extu.w r0,r1
    st32(c.r[2] + 20, c.r[1]);  // 0601E9A6 mov.l r1,@(20,r2)
    c.r[15] = c.r[14];  // 0601E9A8 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601E9AA lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601E9B2u);  // 0601E9AC mov.w 0x0601E9B2,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601E9AE rts ; mov.l @r15+,r14
}

void f_0601E9C0(SH2Context& c) {
    ran[348] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601E9C0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601E9C2 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0601E9C4 mov r15,r14
    c.r[4] = ld32(0x0601E9E0u);  // 0601E9C6 mov.l 0x0601E9E0,r4
    c.r[0] = ld32(0x0601E9E4u);  // 0601E9C8 mov.l 0x0601E9E4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601E9CEu; c.r[5] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601E9CEu) return; }  // 0601E9CA jsr @r0 ; mov #2,r5
    c.r[2] = ld32(0x0601E9E8u);  // 0601E9CE mov.l 0x0601E9E8,r2
    c.r[1] = c.r[0] & 0xFFFFu;  // 0601E9D0 extu.w r0,r1
    st32(c.r[2] + 20, c.r[1]);  // 0601E9D2 mov.l r1,@(20,r2)
    c.r[15] = c.r[14];  // 0601E9D4 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601E9D6 lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601E9DEu);  // 0601E9D8 mov.w 0x0601E9DE,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601E9DA rts ; mov.l @r15+,r14
}

void f_0601E9EC(SH2Context& c) {
    ran[349] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601E9EC mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0601E9EE mov r15,r14
    c.r[1] = ld32(0x0601EA00u);  // 0601E9F0 mov.l 0x0601EA00,r1
    c.r[2] = ld32(0x0601EA04u);  // 0601E9F2 mov.l 0x0601EA04,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601E9F4 mov.b @r2,r2
    st8(c.r[1], c.r[2]);  // 0601E9F6 mov.b r2,@r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601E9FEu);  // 0601E9F8 mov.w 0x0601E9FE,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601E9FA rts ; mov.l @r15+,r14
}

void f_0601EA08(SH2Context& c) {
    ran[350] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601EA08 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0601EA0A mov r15,r14
    c.r[1] = ld32(0x0601EA1Cu);  // 0601EA0C mov.l 0x0601EA1C,r1
    c.r[2] = ld32(0x0601EA20u);  // 0601EA0E mov.l 0x0601EA20,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601EA10 mov.b @r2,r2
    st8(c.r[1], c.r[2]);  // 0601EA12 mov.b r2,@r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601EA1Au);  // 0601EA14 mov.w 0x0601EA1A,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601EA16 rts ; mov.l @r15+,r14
}

void f_0601EA24(SH2Context& c) {
    ran[351] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601EA24 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0601EA26 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0601EA28 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0601EA2A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0601EA2C mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0601EA2E mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601EA30 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601EA32 sts.l pr,@-r15
    c.r[1] = ld32(0x0601EB20u);  // 0601EA34 mov.l 0x0601EB20,r1
    c.r[3] = ld32(c.r[1]);  // 0601EA36 mov.l @r1,r3
    c.r[14] = c.r[15];  // 0601EA38 mov r15,r14
    c.r[1] = c.r[3];  // 0601EA3A mov r3,r1
    c.r[1] += 1;  // 0601EA3C add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601EA3E mov.b @r1,r2
    c.r[3] += 2;  // 0601EA40 add #2,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0601EA42 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0601EA44 mov.b @r3,r1
    c.r[2] <<= 8;  // 0601EA46 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0601EA48 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0601EA4A or r1,r2
    c.r[1] = ld32(0x0601EB24u);  // 0601EA4C mov.l 0x0601EB24,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601EA52u; c.r[12] = (uint32_t)(int32_t)(int16_t)c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601EA52u) return; }  // 0601EA4E jsr @r1 ; exts.w r2,r12
    c.r[8] = ld32(0x0601EB28u);  // 0601EA52 mov.l 0x0601EB28,r8
    c.r[3] = c.r[8];  // 0601EA54 mov r8,r3
    c.r[3] += 33;  // 0601EA56 add #33,r3
    c.r[2] = c.r[8];  // 0601EA58 mov r8,r2
    c.r[2] += 32;  // 0601EA5A add #32,r2
    c.r[13] = ld32(0x0601EB2Cu);  // 0601EA5C mov.l 0x0601EB2C,r13
    c.r[7] = c.r[8];  // 0601EA5E mov r8,r7
    c.r[7] += 24;  // 0601EA60 add #24,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 0601EA62 mov.b @r13,r1
    c.r[11] = ld32(0x0601EB30u);  // 0601EA64 mov.l 0x0601EB30,r11
    c.r[10] = c.r[1] & 0xFFu;  // 0601EA66 extu.b r1,r10
    st8(c.r[2], c.r[1]);  // 0601EA68 mov.b r1,@r2
    st8(c.r[3], c.r[1]);  // 0601EA6A mov.b r1,@r3
    c.r[3] = c.r[8];  // 0601EA6C mov r8,r3
    c.r[3] += 36;  // 0601EA6E add #36,r3
    c.r[1] = c.r[8];  // 0601EA70 mov r8,r1
    c.r[1] += 30;  // 0601EA72 add #30,r1
    c.r[2] = 0xFFFFFFFFu;  // 0601EA74 mov #-1,r2
    st8(c.r[1], c.r[2]);  // 0601EA76 mov.b r2,@r1
    c.r[1] = 0xFFFFFFFFu;  // 0601EA78 mov #-1,r1
    st32(c.r[8] + 16, c.r[1]);  // 0601EA7A mov.l r1,@(16,r8)
    st32(c.r[8] + 12, c.r[1]);  // 0601EA7C mov.l r1,@(12,r8)
    st8(c.r[3], c.r[2]);  // 0601EA7E mov.b r2,@r3
    c.r[1] = 0xFFFFFFFFu;  // 0601EA80 mov #-1,r1
    st16(c.r[7], c.r[1]);  // 0601EA82 mov.w r1,@r7
    c.r[1] = ld32(c.r[11]);  // 0601EA84 mov.l @r11,r1
    c.r[10] <<= 2;  // 0601EA86 shll2 r10
    c.r[10] <<= 2;  // 0601EA88 shll2 r10
    c.r[1] += c.r[10];  // 0601EA8A add r10,r1
    c.r[1] += 4;  // 0601EA8C add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601EA8E mov.b @r1,r1
    c.r[0] = c.r[1];  // 0601EA90 mov r1,r0
    c.r[0] >>= 2;  // 0601EA92 shlr2 r0
    c.r[0] >>= 2;  // 0601EA94 shlr2 r0
    c.r[0] >>= 2;  // 0601EA96 shlr2 r0
    c.r[0] &= 0x1u;  // 0601EA98 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601EA9A tst r0,r0
    { const bool k = !c.t; c.r[9] = 0x0u; if (k) { goto L_0601EB06; } }  // 0601EA9C bf/s 0x0601EB06 ; mov #0,r9
    c.r[0] = ld32(0x0601EB34u);  // 0601EAA0 mov.l 0x0601EB34,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601EAA6u; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601EAA6u) return; }  // 0601EAA2 jsr @r0 ; mov r12,r4
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0601EAA6 cmp/eq #-1,r0
    { const bool k = c.t; st32(c.r[8] + 20, c.r[0]); if (k) { goto L_0601EB06; } }  // 0601EAA8 bt/s 0x0601EB06 ; mov.l r0,@(20,r8)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 0601EAAC mov.b @r13,r1
    c.r[2] = ld32(c.r[11]);  // 0601EAAE mov.l @r11,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0601EAB0 extu.b r1,r1
    c.r[1] <<= 2;  // 0601EAB2 shll2 r1
    c.r[1] <<= 2;  // 0601EAB4 shll2 r1
    c.r[3] = c.r[1];  // 0601EAB6 mov r1,r3
    c.r[3] += c.r[2];  // 0601EAB8 add r2,r3
    c.r[0] = c.r[1];  // 0601EABA mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0601EABC mov.b @(r0,r2),r1
    c.r[3] += 1;  // 0601EABE add #1,r3
    c.r[12] = c.r[1] & 0xFFu;  // 0601EAC0 extu.b r1,r12
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0601EAC2 mov.b @r3,r1
    c.r[8] = c.r[1] & 0xFFu;  // 0601EAC4 extu.b r1,r8
    c.r[1] = ld32(0x0601EB38u);  // 0601EAC6 mov.l 0x0601EB38,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601EAC8 mov.b @r1,r1
    c.r[0] = c.r[10];  // 0601EACA mov r10,r0
    st8(c.r[0] + c.r[2], c.r[1]);  // 0601EACC mov.b r1,@(r0,r2)
    c.r[1] = ld32(c.r[11]);  // 0601EACE mov.l @r11,r1
    c.r[10] += c.r[1];  // 0601EAD0 add r1,r10
    c.r[1] = ld32(0x0601EB3Cu);  // 0601EAD2 mov.l 0x0601EB3C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601EAD4 mov.b @r1,r1
    c.r[10] += 1;  // 0601EAD6 add #1,r10
    st8(c.r[10], c.r[1]);  // 0601EAD8 mov.b r1,@r10
    c.r[1] = ld32(0x0601EB40u);  // 0601EADA mov.l 0x0601EB40,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601EAE0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601EAE0u) return; }  // 0601EADC jsr @r1 ; nop
    c.r[10] = ld32(0x0601EB44u);  // 0601EAE0 mov.l 0x0601EB44,r10
    c.r[6] = c.r[9] & 0xFFu;  // 0601EAE2 extu.b r9,r6
L_0601EAE4:
    c.r[1] = 0x0u;  // 0601EAE4 mov #0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0601EAE6 mov.l r1,@-r15
    c.r[7] = (uint32_t)(int16_t)ld16(0x0601EB1Cu);  // 0601EAE8 mov.w 0x0601EB1C,r7
    c.r[5] = c.r[8];  // 0601EAEA mov r8,r5
    { const uint32_t x = c.r[10]; c.pr = 0x0601EAF0u; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601EAF0u) return; }  // 0601EAEC jsr @r10 ; mov r12,r4
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0601EAF0 cmp/eq #-1,r0
    { const bool k = !c.t; c.r[15] += 4; if (k) { goto L_0601EB06; } }  // 0601EAF2 bf/s 0x0601EB06 ; add #4,r15
    c.r[9] += 1;  // 0601EAF6 add #1,r9
    c.r[1] = 0xAu;  // 0601EAF8 mov #10,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 0601EAFA cmp/gt r1,r9
    { const bool k = !c.t; c.r[6] = c.r[9] & 0xFFu; if (k) { SH2_POLL(c); goto L_0601EAE4; } }  // 0601EAFC bf/s 0x0601EAE4 ; extu.b r9,r6
    c.r[1] = ld32(0x0601EB24u);  // 0601EB00 mov.l 0x0601EB24,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601EB06u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601EB06u) return; }  // 0601EB02 jsr @r1 ; nop
L_0601EB06:
    c.r[15] = c.r[14];  // 0601EB06 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601EB08 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601EB0A mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0601EB0C mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0601EB0E mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0601EB10 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0601EB12 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0601EB14 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601EB1Eu);  // 0601EB16 mov.w 0x0601EB1E,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601EB18 rts ; mov.l @r15+,r8
}

void f_0601EB48(SH2Context& c) {
    ran[352] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601EB48 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601EB4A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601EB4C sts.l pr,@-r15
    c.r[1] = ld32(0x0601EBB8u);  // 0601EB4E mov.l 0x0601EBB8,r1
    c.r[3] = ld32(c.r[1]);  // 0601EB50 mov.l @r1,r3
    c.r[14] = c.r[15];  // 0601EB52 mov r15,r14
    c.r[1] = c.r[3];  // 0601EB54 mov r3,r1
    c.r[1] += 1;  // 0601EB56 add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601EB58 mov.b @r1,r2
    c.r[3] += 2;  // 0601EB5A add #2,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0601EB5C extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0601EB5E mov.b @r3,r1
    c.r[2] <<= 8;  // 0601EB60 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0601EB62 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0601EB64 or r1,r2
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0601EB66 exts.w r2,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0601EB68 cmp/eq #-1,r0
    { const bool k = !c.t; c.r[1] = c.r[0]; if (k) { goto L_0601EB76; } }  // 0601EB6A bf/s 0x0601EB76 ; mov r0,r1
    c.r[1] = ld32(0x0601EBBCu);  // 0601EB6E mov.l 0x0601EBBC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601EB70 mov.b @r1,r1
    c.r[8] = c.r[1] & 0xFFu; goto L_0601EB7E;  // 0601EB72 bra 0x0601EB7E ; extu.b r1,r8
L_0601EB76:
    c.r[0] = ld32(0x0601EBC0u);  // 0601EB76 mov.l 0x0601EBC0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601EB7Cu; c.r[4] = c.r[1] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601EB7Cu) return; }  // 0601EB78 jsr @r0 ; extu.w r1,r4
    c.r[8] = c.r[0] & 0xFFu;  // 0601EB7C extu.b r0,r8
L_0601EB7E:
    c.r[1] = ld32(0x0601EBC4u);  // 0601EB7E mov.l 0x0601EBC4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601EB84u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601EB84u) return; }  // 0601EB80 jsr @r1 ; nop
    c.r[3] = (uint32_t)(int16_t)ld16(0x0601EBB4u);  // 0601EB84 mov.w 0x0601EBB4,r3
    c.t = c.r[8] == c.r[3];  // 0601EB86 cmp/eq r3,r8
    { const bool k = c.t; c.r[8] <<= 2; if (k) { goto L_0601EBA8; } }  // 0601EB88 bt/s 0x0601EBA8 ; shll2 r8
    c.r[1] = ld32(0x0601EBC8u);  // 0601EB8C mov.l 0x0601EBC8,r1
    c.r[1] = ld32(c.r[1]);  // 0601EB8E mov.l @r1,r1
    c.r[8] <<= 2;  // 0601EB90 shll2 r8
    c.r[8] += c.r[1];  // 0601EB92 add r1,r8
    c.r[8] += 9;  // 0601EB94 add #9,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0601EB96 mov.b @r8,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0601EB98 extu.b r1,r2
    c.t = c.r[2] == c.r[3];  // 0601EB9A cmp/eq r3,r2
    if (c.t) { goto L_0601EBA8; }  // 0601EB9C bt 0x0601EBA8
    c.r[1] = ld32(0x0601EBCCu);  // 0601EB9E mov.l 0x0601EBCC,r1
    st32(c.r[1] + 20, c.r[2]);  // 0601EBA0 mov.l r2,@(20,r1)
    c.r[1] = ld32(0x0601EBD0u);  // 0601EBA2 mov.l 0x0601EBD0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601EBA8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601EBA8u) return; }  // 0601EBA4 jsr @r1 ; nop
L_0601EBA8:
    c.r[15] = c.r[14];  // 0601EBA8 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601EBAA lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601EBAC mov.l @r15+,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601EBB6u);  // 0601EBAE mov.w 0x0601EBB6,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601EBB0 rts ; mov.l @r15+,r8
}

void f_0601EBD4(SH2Context& c) {
    ran[353] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601EBD4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0601EBD6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0601EBD8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0601EBDA mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601EBDC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601EBDE sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0601EBE0 mov r15,r14
    c.r[9] = ld32(0x0601EC64u);  // 0601EBE2 mov.l 0x0601EC64,r9
    c.r[10] = ld32(0x0601EC68u);  // 0601EBE4 mov.l 0x0601EC68,r10
    c.r[2] = ld32(c.r[10]);  // 0601EBE6 mov.l @r10,r2
    c.r[11] = ld32(0x0601EC6Cu);  // 0601EBE8 mov.l 0x0601EC6C,r11
    c.r[1] = c.r[2];  // 0601EBEA mov r2,r1
    c.r[1] += 1;  // 0601EBEC add #1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601EBEE mov.b @r1,r4
    c.r[2] += 2;  // 0601EBF0 add #2,r2
    c.r[4] = c.r[4] & 0xFFu;  // 0601EBF2 extu.b r4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601EBF4 mov.b @r2,r1
    c.r[4] <<= 8;  // 0601EBF6 shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 0601EBF8 extu.b r1,r1
    { const uint32_t x = c.r[11]; c.pr = 0x0601EBFEu; c.r[4] |= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601EBFEu) return; }  // 0601EBFA jsr @r11 ; or r1,r4
    c.r[8] = ld32(0x0601EC70u);  // 0601EBFE mov.l 0x0601EC70,r8
    c.r[2] = c.r[8];  // 0601EC00 mov r8,r2
    c.r[2] += 33;  // 0601EC02 add #33,r2
    c.r[1] = c.r[8];  // 0601EC04 mov r8,r1
    c.r[1] += 32;  // 0601EC06 add #32,r1
    st8(c.r[1], c.r[0]);  // 0601EC08 mov.b r0,@r1
    st8(c.r[2], c.r[0]);  // 0601EC0A mov.b r0,@r2
    st8(c.r[9], c.r[0]);  // 0601EC0C mov.b r0,@r9
    c.r[9] = ld32(0x0601EC74u);  // 0601EC0E mov.l 0x0601EC74,r9
    { const uint32_t x = c.r[9]; c.pr = 0x0601EC14u; c.r[4] = c.r[0] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601EC14u) return; }  // 0601EC10 jsr @r9 ; extu.b r0,r4
    c.r[2] = ld32(c.r[10]);  // 0601EC14 mov.l @r10,r2
    c.r[1] = c.r[2];  // 0601EC16 mov r2,r1
    c.r[1] += 3;  // 0601EC18 add #3,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601EC1A mov.b @r1,r4
    c.r[2] += 4;  // 0601EC1C add #4,r2
    c.r[4] = c.r[4] & 0xFFu;  // 0601EC1E extu.b r4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601EC20 mov.b @r2,r1
    c.r[4] <<= 8;  // 0601EC22 shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 0601EC24 extu.b r1,r1
    { const uint32_t x = c.r[11]; c.pr = 0x0601EC2Au; c.r[4] |= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601EC2Au) return; }  // 0601EC26 jsr @r11 ; or r1,r4
    c.r[1] = c.r[8];  // 0601EC2A mov r8,r1
    c.r[1] += 36;  // 0601EC2C add #36,r1
    st8(c.r[1], c.r[0]);  // 0601EC2E mov.b r0,@r1
    { const uint32_t x = c.r[9]; c.pr = 0x0601EC34u; c.r[4] = c.r[0] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601EC34u) return; }  // 0601EC30 jsr @r9 ; extu.b r0,r4
    c.r[3] = c.r[8];  // 0601EC34 mov r8,r3
    c.r[3] += 24;  // 0601EC36 add #24,r3
    c.r[2] = c.r[8];  // 0601EC38 mov r8,r2
    c.r[2] += 30;  // 0601EC3A add #30,r2
    c.r[1] = 0xFFFFFFFFu;  // 0601EC3C mov #-1,r1
    st8(c.r[2], c.r[1]);  // 0601EC3E mov.b r1,@r2
    c.r[1] = 0xFFFFFFFFu;  // 0601EC40 mov #-1,r1
    st32(c.r[8] + 16, c.r[1]);  // 0601EC42 mov.l r1,@(16,r8)
    st32(c.r[8] + 12, c.r[1]);  // 0601EC44 mov.l r1,@(12,r8)
    c.r[1] = 0xFFFFFFFFu;  // 0601EC46 mov #-1,r1
    st16(c.r[3], c.r[1]);  // 0601EC48 mov.w r1,@r3
    c.r[0] = ld32(0x0601EC78u);  // 0601EC4A mov.l 0x0601EC78,r0
    c.r[5] = 0x5u;  // 0601EC4C mov #5,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0601EC52u; c.r[4] = 0x9u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601EC52u) return; }  // 0601EC4E jsr @r0 ; mov #9,r4
    c.r[15] = c.r[14];  // 0601EC52 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601EC54 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601EC56 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0601EC58 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0601EC5A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0601EC5C mov.l @r15+,r9
    c.r[0] = ld32(0x0601EC7Cu);  // 0601EC5E mov.l 0x0601EC7C,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601EC60 rts ; mov.l @r15+,r8
}

void f_0601EC80(SH2Context& c) {
    ran[354] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601EC80 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601EC82 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601EC84 sts.l pr,@-r15
    c.r[1] = ld32(0x0601ECF0u);  // 0601EC86 mov.l 0x0601ECF0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601EC8Cu; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601EC8Cu) return; }  // 0601EC88 jsr @r1 ; mov r15,r14
    c.r[8] = ld32(0x0601ECF4u);  // 0601EC8C mov.l 0x0601ECF4,r8
    c.r[2] = ld32(c.r[8]);  // 0601EC8E mov.l @r8,r2
    c.r[0] = ld32(0x0601ECF8u);  // 0601EC90 mov.l 0x0601ECF8,r0
    c.r[1] = c.r[2];  // 0601EC92 mov r2,r1
    c.r[1] += 1;  // 0601EC94 add #1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601EC96 mov.b @r1,r4
    c.r[2] += 2;  // 0601EC98 add #2,r2
    c.r[4] = c.r[4] & 0xFFu;  // 0601EC9A extu.b r4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601EC9C mov.b @r2,r1
    c.r[4] <<= 8;  // 0601EC9E shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 0601ECA0 extu.b r1,r1
    { const uint32_t x = c.r[0]; c.pr = 0x0601ECA6u; c.r[4] |= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601ECA6u) return; }  // 0601ECA2 jsr @r0 ; or r1,r4
    c.r[0] = c.r[0] & 0xFFu;  // 0601ECA6 extu.b r0,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601ECECu);  // 0601ECA8 mov.w 0x0601ECEC,r1
    c.t = c.r[0] == c.r[1];  // 0601ECAA cmp/eq r1,r0
    if (c.t) { goto L_0601ECE0; }  // 0601ECAC bt 0x0601ECE0
    c.r[1] = ld32(c.r[8]);  // 0601ECAE mov.l @r8,r1
    c.r[1] += 3;  // 0601ECB0 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601ECB2 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601ECB4 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601ECB6 tst r1,r1
    { const bool k = !c.t; c.r[0] <<= 2; if (k) { goto L_0601ECCC; } }  // 0601ECB8 bf/s 0x0601ECCC ; shll2 r0
    c.r[1] = ld32(0x0601ECFCu);  // 0601ECBC mov.l 0x0601ECFC,r1
    c.r[1] = ld32(c.r[1]);  // 0601ECBE mov.l @r1,r1
    c.r[0] <<= 2;  // 0601ECC0 shll2 r0
    c.r[0] += c.r[1];  // 0601ECC2 add r1,r0
    c.r[1] = ld32(c.r[0] + 12);  // 0601ECC4 mov.l @(12,r0),r1
    c.r[2] = ld32(0x0601ED00u);  // 0601ECC6 mov.l 0x0601ED00,r2
    st32(c.r[2], c.r[1]); goto L_0601ECDA;  // 0601ECC8 bra 0x0601ECDA ; mov.l r1,@r2
L_0601ECCC:
    c.r[1] = ld32(0x0601ECFCu);  // 0601ECCC mov.l 0x0601ECFC,r1
    c.r[1] = ld32(c.r[1]);  // 0601ECCE mov.l @r1,r1
    c.r[0] <<= 2;  // 0601ECD0 shll2 r0
    c.r[0] += c.r[1];  // 0601ECD2 add r1,r0
    c.r[1] = ld32(0x0601ED00u);  // 0601ECD4 mov.l 0x0601ED00,r1
    c.r[1] = ld32(c.r[1]);  // 0601ECD6 mov.l @r1,r1
    st32(c.r[0] + 12, c.r[1]);  // 0601ECD8 mov.l r1,@(12,r0)
L_0601ECDA:
    c.r[1] = ld32(0x0601ED04u);  // 0601ECDA mov.l 0x0601ED04,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601ECE0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601ECE0u) return; }  // 0601ECDC jsr @r1 ; nop
L_0601ECE0:
    c.r[15] = c.r[14];  // 0601ECE0 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601ECE2 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601ECE4 mov.l @r15+,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601ECEEu);  // 0601ECE6 mov.w 0x0601ECEE,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601ECE8 rts ; mov.l @r15+,r8
}

void f_0601ED08(SH2Context& c) {
    ran[355] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601ED08 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0601ED0A mov r15,r14
    c.r[1] = ld32(0x0601ED1Cu);  // 0601ED0C mov.l 0x0601ED1C,r1
    c.r[2] = ld32(0x0601ED20u);  // 0601ED0E mov.l 0x0601ED20,r2
    c.r[2] = ld32(c.r[2] + 8);  // 0601ED10 mov.l @(8,r2),r2
    st32(c.r[1] + 20, c.r[2]);  // 0601ED12 mov.l r2,@(20,r1)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601ED1Au);  // 0601ED14 mov.w 0x0601ED1A,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601ED16 rts ; mov.l @r15+,r14
}

void f_0601ED24(SH2Context& c) {
    ran[356] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601ED24 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0601ED26 mov r15,r14
    c.r[1] = ld32(0x0601ED38u);  // 0601ED28 mov.l 0x0601ED38,r1
    c.r[2] = ld32(0x0601ED3Cu);  // 0601ED2A mov.l 0x0601ED3C,r2
    c.r[2] = ld32(c.r[2] + 4);  // 0601ED2C mov.l @(4,r2),r2
    st32(c.r[1] + 20, c.r[2]);  // 0601ED2E mov.l r2,@(20,r1)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601ED36u);  // 0601ED30 mov.w 0x0601ED36,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601ED32 rts ; mov.l @r15+,r14
}

void f_0601ED40(SH2Context& c) {
    ran[357] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601ED40 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601ED42 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601ED44 sts.l pr,@-r15
    c.r[8] = ld32(0x0601ED90u);  // 0601ED46 mov.l 0x0601ED90,r8
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0601ED48 mov.b @r8,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601ED8Cu);  // 0601ED4A mov.w 0x0601ED8C,r1
    c.r[4] = c.r[3] & 0xFFu;  // 0601ED4C extu.b r3,r4
    c.t = c.r[4] == c.r[1];  // 0601ED4E cmp/eq r1,r4
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0601ED5A; } }  // 0601ED50 bf/s 0x0601ED5A ; mov r15,r14
    c.r[1] = ld32(0x0601ED94u);  // 0601ED54 mov.l 0x0601ED94,r1
    goto L_0601ED7C;  // 0601ED56 bra 0x0601ED7C ; nop
L_0601ED5A:
    c.r[2] = ld32(0x0601ED98u);  // 0601ED5A mov.l 0x0601ED98,r2
    c.r[1] = ld32(0x0601ED9Cu);  // 0601ED5C mov.l 0x0601ED9C,r1
    st8(c.r[1], c.r[3]);  // 0601ED5E mov.b r3,@r1
    c.r[1] = ld32(0x0601EDA0u);  // 0601ED60 mov.l 0x0601EDA0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601ED66u; st8(c.r[2], c.r[3]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601ED66u) return; }  // 0601ED62 jsr @r1 ; mov.b r3,@r2
    c.r[7] = ld32(0x0601EDA4u);  // 0601ED66 mov.l 0x0601EDA4,r7
    c.r[3] = ld32(0x0601EDA8u);  // 0601ED68 mov.l 0x0601EDA8,r3
    c.r[2] = c.r[3];  // 0601ED6A mov r3,r2
    c.r[8] += 1;  // 0601ED6C add #1,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0601ED6E mov.b @r8,r1
    c.r[2] += 2;  // 0601ED70 add #2,r2
    st8(c.r[2], c.r[1]);  // 0601ED72 mov.b r1,@r2
    st8(c.r[3], c.r[1]);  // 0601ED74 mov.b r1,@r3
    c.r[1] = c.r[1] & 0xFFu;  // 0601ED76 extu.b r1,r1
    st16(c.r[7], c.r[1]);  // 0601ED78 mov.w r1,@r7
    c.r[1] = ld32(0x0601EDACu);  // 0601ED7A mov.l 0x0601EDAC,r1
L_0601ED7C:
    { const uint32_t x = c.r[1]; c.pr = 0x0601ED80u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601ED80u) return; }  // 0601ED7C jsr @r1 ; nop
    c.r[15] = c.r[14];  // 0601ED80 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601ED82 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601ED84 mov.l @r15+,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601ED8Eu);  // 0601ED86 mov.w 0x0601ED8E,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601ED88 rts ; mov.l @r15+,r8
}

void f_0601EDB0(SH2Context& c) {
    ran[358] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601EDB0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0601EDB2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0601EDB4 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0601EDB6 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0601EDB8 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0601EDBA mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601EDBC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601EDBE sts.l pr,@-r15
    c.r[13] = ld32(0x0601EE94u);  // 0601EDC0 mov.l 0x0601EE94,r13
    c.r[2] = ld32(c.r[13]);  // 0601EDC2 mov.l @r13,r2
    c.r[1] = c.r[2];  // 0601EDC4 mov r2,r1
    c.r[1] += 1;  // 0601EDC6 add #1,r1
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601EDC8 mov.b @r1,r8
    c.r[2] += 2;  // 0601EDCA add #2,r2
    c.r[8] = c.r[8] & 0xFFu;  // 0601EDCC extu.b r8,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601EDCE mov.b @r2,r1
    c.r[8] <<= 8;  // 0601EDD0 shll8 r8
    c.r[1] = c.r[1] & 0xFFu;  // 0601EDD2 extu.b r1,r1
    c.r[8] |= c.r[1];  // 0601EDD4 or r1,r8
    c.r[1] = ld32(0x0601EE98u);  // 0601EDD6 mov.l 0x0601EE98,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601EDDCu; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601EDDCu) return; }  // 0601EDD8 jsr @r1 ; mov r15,r14
    c.r[12] = c.r[8];  // 0601EDDC mov r8,r12
    c.r[12] >>= 8;  // 0601EDDE shlr8 r12
    c.t = c.r[12] & 1; c.r[12] >>= 1;  // 0601EDE0 shlr r12
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601EE8Cu);  // 0601EDE2 mov.w 0x0601EE8C,r1
    c.r[8] &= c.r[1];  // 0601EDE4 and r1,r8
    c.r[11] = ld32(0x0601EE9Cu);  // 0601EDE6 mov.l 0x0601EE9C,r11
    { const uint32_t x = c.r[11]; c.pr = 0x0601EDECu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601EDECu) return; }  // 0601EDE8 jsr @r11 ; mov r8,r4
    c.r[8] = c.r[0] & 0xFFu;  // 0601EDEC extu.b r0,r8
    c.r[10] = (uint32_t)(int16_t)ld16(0x0601EE8Eu);  // 0601EDEE mov.w 0x0601EE8E,r10
    c.t = c.r[8] == c.r[10];  // 0601EDF0 cmp/eq r10,r8
    { const bool k = c.t; c.r[2] = c.r[8]; if (k) { goto L_0601EE76; } }  // 0601EDF2 bt/s 0x0601EE76 ; mov r8,r2
    c.r[9] = ld32(0x0601EEA0u);  // 0601EDF6 mov.l 0x0601EEA0,r9
    c.r[1] = ld32(c.r[9]);  // 0601EDF8 mov.l @r9,r1
    c.r[2] <<= 2;  // 0601EDFA shll2 r2
    c.r[2] <<= 2;  // 0601EDFC shll2 r2
    c.r[2] += c.r[1];  // 0601EDFE add r1,r2
    c.r[1] = c.r[2];  // 0601EE00 mov r2,r1
    c.r[1] += 4;  // 0601EE02 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601EE04 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0601EE06 mov r1,r0
    c.r[0] >>= 2;  // 0601EE08 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0601EE0A shlr r0
    c.r[0] >>= 2;  // 0601EE0C shlr2 r0
    c.r[0] &= 0x1u;  // 0601EE0E and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601EE10 tst r0,r0
    { const bool k = c.t; c.r[2] += 6; if (k) { goto L_0601EE1A; } }  // 0601EE12 bt/s 0x0601EE1A ; add #6,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601EE16 mov.b @r2,r1
    c.r[8] = c.r[1] & 0xFFu;  // 0601EE18 extu.b r1,r8
L_0601EE1A:
    c.r[3] = ld32(0x0601EEA4u);  // 0601EE1A mov.l 0x0601EEA4,r3
    c.r[2] = ld32(0x0601EEA8u);  // 0601EE1C mov.l 0x0601EEA8,r2
    c.r[1] = c.r[8];  // 0601EE1E mov r8,r1
    st8(c.r[2], c.r[1]);  // 0601EE20 mov.b r1,@r2
    st8(c.r[3], c.r[1]);  // 0601EE22 mov.b r1,@r3
    c.r[2] = ld32(c.r[13]);  // 0601EE24 mov.l @r13,r2
    c.r[1] = c.r[2];  // 0601EE26 mov r2,r1
    c.r[1] += 3;  // 0601EE28 add #3,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601EE2A mov.b @r1,r4
    c.r[2] += 4;  // 0601EE2C add #4,r2
    c.r[4] = c.r[4] & 0xFFu;  // 0601EE2E extu.b r4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601EE30 mov.b @r2,r1
    c.r[4] <<= 8;  // 0601EE32 shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 0601EE34 extu.b r1,r1
    { const uint32_t x = c.r[11]; c.pr = 0x0601EE3Au; c.r[4] |= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601EE3Au) return; }  // 0601EE36 jsr @r11 ; or r1,r4
    c.r[5] = c.r[0] & 0xFFu;  // 0601EE3A extu.b r0,r5
    c.t = c.r[5] == c.r[10];  // 0601EE3C cmp/eq r10,r5
    { const bool k = c.t; c.r[2] = c.r[5]; if (k) { goto L_0601EE76; } }  // 0601EE3E bt/s 0x0601EE76 ; mov r5,r2
    c.r[1] = ld32(c.r[9]);  // 0601EE42 mov.l @r9,r1
    c.r[2] <<= 2;  // 0601EE44 shll2 r2
    c.r[2] <<= 2;  // 0601EE46 shll2 r2
    c.r[2] += c.r[1];  // 0601EE48 add r1,r2
    c.r[1] = c.r[2];  // 0601EE4A mov r2,r1
    c.r[1] += 4;  // 0601EE4C add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601EE4E mov.b @r1,r1
    c.r[0] = c.r[1];  // 0601EE50 mov r1,r0
    c.r[0] >>= 2;  // 0601EE52 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0601EE54 shlr r0
    c.r[0] >>= 2;  // 0601EE56 shlr2 r0
    c.r[0] &= 0x1u;  // 0601EE58 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601EE5A tst r0,r0
    { const bool k = c.t; c.r[2] += 6; if (k) { goto L_0601EE64; } }  // 0601EE5C bt/s 0x0601EE64 ; add #6,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601EE60 mov.b @r2,r1
    c.r[5] = c.r[1] & 0xFFu;  // 0601EE62 extu.b r1,r5
L_0601EE64:
    c.r[0] = ld32(0x0601EEACu);  // 0601EE64 mov.l 0x0601EEAC,r0
    c.r[6] = c.r[12];  // 0601EE66 mov r12,r6
    { const uint32_t x = c.r[0]; c.pr = 0x0601EE6Cu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601EE6Cu) return; }  // 0601EE68 jsr @r0 ; mov r8,r4
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0601EE6C cmp/eq #-1,r0
    if (c.t) { goto L_0601EE76; }  // 0601EE6E bt 0x0601EE76
    c.r[1] = ld32(0x0601EEB0u);  // 0601EE70 mov.l 0x0601EEB0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601EE76u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601EE76u) return; }  // 0601EE72 jsr @r1 ; nop
L_0601EE76:
    c.r[15] = c.r[14];  // 0601EE76 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601EE78 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601EE7A mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0601EE7C mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0601EE7E mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0601EE80 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0601EE82 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0601EE84 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601EE90u);  // 0601EE86 mov.w 0x0601EE90,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601EE88 rts ; mov.l @r15+,r8
}

void f_0601EEB4(SH2Context& c) {
    ran[359] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601EEB4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0601EEB6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0601EEB8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0601EEBA mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0601EEBC mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0601EEBE mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601EEC0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601EEC2 sts.l pr,@-r15
    c.r[1] = ld32(0x0601EFB0u);  // 0601EEC4 mov.l 0x0601EFB0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601EECAu; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601EECAu) return; }  // 0601EEC6 jsr @r1 ; mov r15,r14
    c.r[13] = ld32(0x0601EFB4u);  // 0601EECA mov.l 0x0601EFB4,r13
    c.r[1] = 0xFFFFFFFFu;  // 0601EECC mov #-1,r1
    st32(c.r[13] + 20, c.r[1]);  // 0601EECE mov.l r1,@(20,r13)
    c.r[11] = ld32(0x0601EFB8u);  // 0601EED0 mov.l 0x0601EFB8,r11
    c.r[2] = ld32(c.r[11]);  // 0601EED2 mov.l @r11,r2
    c.r[12] = ld32(0x0601EFBCu);  // 0601EED4 mov.l 0x0601EFBC,r12
    c.r[1] = c.r[2];  // 0601EED6 mov r2,r1
    c.r[1] += 1;  // 0601EED8 add #1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601EEDA mov.b @r1,r4
    c.r[2] += 2;  // 0601EEDC add #2,r2
    c.r[4] = c.r[4] & 0xFFu;  // 0601EEDE extu.b r4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601EEE0 mov.b @r2,r1
    c.r[4] <<= 8;  // 0601EEE2 shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 0601EEE4 extu.b r1,r1
    { const uint32_t x = c.r[12]; c.pr = 0x0601EEEAu; c.r[4] |= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601EEEAu) return; }  // 0601EEE6 jsr @r12 ; or r1,r4
    c.r[8] = c.r[0] & 0xFFu;  // 0601EEEA extu.b r0,r8
    c.r[10] = (uint32_t)(int16_t)ld16(0x0601EFAAu);  // 0601EEEC mov.w 0x0601EFAA,r10
    c.t = c.r[8] == c.r[10];  // 0601EEEE cmp/eq r10,r8
    { const bool k = c.t; c.r[2] = c.r[8]; if (k) { goto L_0601EF94; } }  // 0601EEF0 bt/s 0x0601EF94 ; mov r8,r2
    c.r[9] = ld32(0x0601EFC0u);  // 0601EEF4 mov.l 0x0601EFC0,r9
    c.r[1] = ld32(c.r[9]);  // 0601EEF6 mov.l @r9,r1
    c.r[2] <<= 2;  // 0601EEF8 shll2 r2
    c.r[2] <<= 2;  // 0601EEFA shll2 r2
    c.r[2] += c.r[1];  // 0601EEFC add r1,r2
    c.r[1] = c.r[2];  // 0601EEFE mov r2,r1
    c.r[1] += 4;  // 0601EF00 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601EF02 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0601EF04 mov r1,r0
    c.r[0] >>= 2;  // 0601EF06 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0601EF08 shlr r0
    c.r[0] >>= 2;  // 0601EF0A shlr2 r0
    c.r[0] &= 0x1u;  // 0601EF0C and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601EF0E tst r0,r0
    { const bool k = c.t; c.r[2] += 6; if (k) { goto L_0601EF18; } }  // 0601EF10 bt/s 0x0601EF18 ; add #6,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601EF14 mov.b @r2,r1
    c.r[8] = c.r[1] & 0xFFu;  // 0601EF16 extu.b r1,r8
L_0601EF18:
    c.r[2] = ld32(c.r[11]);  // 0601EF18 mov.l @r11,r2
    c.r[1] = c.r[2];  // 0601EF1A mov r2,r1
    c.r[1] += 3;  // 0601EF1C add #3,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601EF1E mov.b @r1,r4
    c.r[2] += 4;  // 0601EF20 add #4,r2
    c.r[4] = c.r[4] & 0xFFu;  // 0601EF22 extu.b r4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601EF24 mov.b @r2,r1
    c.r[4] <<= 8;  // 0601EF26 shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 0601EF28 extu.b r1,r1
    { const uint32_t x = c.r[12]; c.pr = 0x0601EF2Eu; c.r[4] |= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601EF2Eu) return; }  // 0601EF2A jsr @r12 ; or r1,r4
    c.r[2] = c.r[0] & 0xFFu;  // 0601EF2E extu.b r0,r2
    c.t = c.r[2] == c.r[10];  // 0601EF30 cmp/eq r10,r2
    { const bool k = c.t; c.r[7] = c.r[2]; if (k) { goto L_0601EF94; } }  // 0601EF32 bt/s 0x0601EF94 ; mov r2,r7
    c.r[3] = ld32(c.r[9]);  // 0601EF36 mov.l @r9,r3
    c.r[7] <<= 2;  // 0601EF38 shll2 r7
    c.r[7] <<= 2;  // 0601EF3A shll2 r7
    c.r[7] += c.r[3];  // 0601EF3C add r3,r7
    c.r[1] = c.r[7];  // 0601EF3E mov r7,r1
    c.r[1] += 4;  // 0601EF40 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601EF42 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0601EF44 mov r1,r0
    c.r[0] >>= 2;  // 0601EF46 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0601EF48 shlr r0
    c.r[0] >>= 2;  // 0601EF4A shlr2 r0
    c.r[0] &= 0x1u;  // 0601EF4C and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601EF4E tst r0,r0
    { const bool k = c.t; c.r[2] <<= 2; if (k) { goto L_0601EF5C; } }  // 0601EF50 bt/s 0x0601EF5C ; shll2 r2
    c.r[7] += 6;  // 0601EF54 add #6,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0601EF56 mov.b @r7,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0601EF58 extu.b r1,r2
    c.r[2] <<= 2;  // 0601EF5A shll2 r2
L_0601EF5C:
    c.r[2] <<= 2;  // 0601EF5C shll2 r2
    c.r[1] = c.r[2];  // 0601EF5E mov r2,r1
    c.r[1] += c.r[3];  // 0601EF60 add r3,r1
    c.r[1] += 1;  // 0601EF62 add #1,r1
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601EF64 mov.b @r1,r7
    c.r[0] = c.r[2];  // 0601EF66 mov r2,r0
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0601EF68 mov.b @(r0,r3),r6
    c.r[7] = c.r[7] & 0xFFu;  // 0601EF6A extu.b r7,r7
    c.r[6] = c.r[6] & 0xFFu;  // 0601EF6C extu.b r6,r6
    c.r[2] = c.r[8];  // 0601EF6E mov r8,r2
    c.r[2] <<= 2;  // 0601EF70 shll2 r2
    c.r[2] <<= 2;  // 0601EF72 shll2 r2
    c.r[1] = c.r[2];  // 0601EF74 mov r2,r1
    c.r[1] += c.r[3];  // 0601EF76 add r3,r1
    c.r[1] += 1;  // 0601EF78 add #1,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601EF7A mov.b @r1,r5
    c.r[0] = c.r[2];  // 0601EF7C mov r2,r0
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0601EF7E mov.b @(r0,r3),r4
    c.r[5] = c.r[5] & 0xFFu;  // 0601EF80 extu.b r5,r5
    c.r[0] = ld32(0x0601EFC4u);  // 0601EF82 mov.l 0x0601EFC4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601EF88u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601EF88u) return; }  // 0601EF84 jsr @r0 ; extu.b r4,r4
    c.r[1] = c.r[0];  // 0601EF88 mov r0,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0601EF8A extu.w r1,r1
    st32(c.r[13] + 20, c.r[1]);  // 0601EF8C mov.l r1,@(20,r13)
    c.r[1] = ld32(0x0601EFC8u);  // 0601EF8E mov.l 0x0601EFC8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601EF94u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601EF94u) return; }  // 0601EF90 jsr @r1 ; nop
L_0601EF94:
    c.r[15] = c.r[14];  // 0601EF94 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601EF96 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601EF98 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0601EF9A mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0601EF9C mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0601EF9E mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0601EFA0 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0601EFA2 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601EFACu);  // 0601EFA4 mov.w 0x0601EFAC,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601EFA6 rts ; mov.l @r15+,r8
}

void f_0601EFCC(SH2Context& c) {
    ran[360] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601EFCC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0601EFCE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0601EFD0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0601EFD2 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601EFD4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601EFD6 sts.l pr,@-r15
    c.r[15] -= 76;  // 0601EFD8 add #-76,r15
    c.r[14] = c.r[15];  // 0601EFDA mov r15,r14
    c.r[3] = ld32(0x0601F12Cu);  // 0601EFDC mov.l 0x0601F12C,r3
    c.r[0] = ld32(0x0601F130u);  // 0601EFDE mov.l 0x0601F130,r0
    c.r[6] = 0x0u;  // 0601EFE0 mov #0,r6
    c.r[1] = ld32(c.r[3]);  // 0601EFE2 mov.l @r3,r1
    c.r[5] = 0xFFFFFFFBu;  // 0601EFE4 mov #-5,r5
    c.r[1] += 1;  // 0601EFE6 add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0601EFE8 mov.b @r1+,r2
    c.r[4] = c.r[14];  // 0601EFEA mov r14,r4
    c.r[10] = c.r[2] & 0xFFu;  // 0601EFEC extu.b r2,r10
    { const uint32_t x = c.r[0]; c.pr = 0x0601EFF2u; st32(c.r[3], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601EFF2u) return; }  // 0601EFEE jsr @r0 ; mov.l r1,@r3
    c.r[8] = c.r[0];  // 0601EFF2 mov r0,r8
    c.r[4] = 0x0u;  // 0601EFF4 mov #0,r4
    c.t = (int32_t)c.r[4] >= (int32_t)c.r[8];  // 0601EFF6 cmp/ge r8,r4
    { const bool k = !c.t; c.r[0] = c.r[14]; if (k) { goto L_0601F000; } }  // 0601EFF8 bf/s 0x0601F000 ; mov r14,r0
    goto L_0601F110;  // 0601EFFC bra 0x0601F110 ; nop
L_0601F000:
    c.r[9] = ld32(0x0601F134u);  // 0601F000 mov.l 0x0601F134,r9
L_0601F002:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[4]);  // 0601F002 mov.b @(r0,r4),r1
    c.r[7] = ld32(c.r[9]);  // 0601F004 mov.l @r9,r7
    c.r[6] = c.r[1] & 0xFFu;  // 0601F006 extu.b r1,r6
    c.r[6] <<= 2;  // 0601F008 shll2 r6
    c.r[6] <<= 2;  // 0601F00A shll2 r6
    c.r[2] = c.r[6];  // 0601F00C mov r6,r2
    c.r[2] += c.r[7];  // 0601F00E add r7,r2
    c.r[5] = ld32(c.r[2] + 4);  // 0601F010 mov.l @(4,r2),r5
    c.r[1] = ld32(0x0601F138u);  // 0601F012 mov.l 0x0601F138,r1
    c.r[5] &= c.r[1];  // 0601F014 and r1,r5
    c.t = (c.r[5] & c.r[5]) == 0;  // 0601F016 tst r5,r5
    { const bool k = !c.t; c.r[1] = c.r[2]; if (k) { goto L_0601F104; } }  // 0601F018 bf/s 0x0601F104 ; mov r2,r1
    c.r[1] += 1;  // 0601F01C add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601F01E mov.b @r1,r1
    c.r[0] = c.r[6];  // 0601F020 mov r6,r0
    c.r[3] = c.r[1] & 0xFFu;  // 0601F022 extu.b r1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0601F024 mov.b @(r0,r7),r1
    c.r[11] = (uint32_t)(int16_t)ld16(0x0601F124u);  // 0601F026 mov.w 0x0601F124,r11
    c.r[7] = c.r[1] & 0xFFu;  // 0601F028 extu.b r1,r7
    c.r[1] = ld32(0x0601F13Cu);  // 0601F02A mov.l 0x0601F13C,r1
    c.r[0] = c.r[1];  // 0601F02C mov r1,r0
    c.r[1] = ld32(c.r[0] + c.r[11]);  // 0601F02E mov.l @(r0,r11),r1
    c.r[3] <<= 2;  // 0601F030 shll2 r3
    c.r[3] <<= 2;  // 0601F032 shll2 r3
    c.r[3] <<= 2;  // 0601F034 shll2 r3
    c.r[3] += c.r[1];  // 0601F036 add r1,r3
    c.r[0] = c.r[3];  // 0601F038 mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0601F03A mov.b @(r0,r7),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601F03C extu.b r1,r1
    c.t = c.r[10] == c.r[1];  // 0601F03E cmp/eq r1,r10
    { const bool k = !c.t; c.r[1] = ld32(c.r[2] + 12); if (k) { goto L_0601F082; } }  // 0601F040 bf/s 0x0601F082 ; mov.l @(12,r2),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601F044 tst r1,r1
    { const bool k = !c.t; c.r[1] = c.r[2]; if (k) { goto L_0601F104; } }  // 0601F046 bf/s 0x0601F104 ; mov r2,r1
    c.r[1] += 7;  // 0601F04A add #7,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601F04C mov.b @r1,r0
    c.r[0] |= 0x40u;  // 0601F04E or #64,r0
    st8(c.r[1], c.r[0]);  // 0601F050 mov.b r0,@r1
    c.r[1] = ld32(0x0601F12Cu);  // 0601F052 mov.l 0x0601F12C,r1
    c.r[3] = ld32(c.r[1]);  // 0601F054 mov.l @r1,r3
    c.r[1] = c.r[3];  // 0601F056 mov r3,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0601F058 mov.b @r1+,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0601F05A extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601F05C mov.b @r1,r1
    c.r[2] <<= 8;  // 0601F05E shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0601F060 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0601F062 or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0601F064 exts.w r2,r2
    c.r[1] = ld32(c.r[9]);  // 0601F066 mov.l @r9,r1
    c.r[3] += c.r[2];  // 0601F068 add r2,r3
    c.r[1] += c.r[6];  // 0601F06A add r6,r1
    st32(c.r[1] + 12, c.r[3]);  // 0601F06C mov.l r3,@(12,r1)
    c.r[2] = c.r[1];  // 0601F06E mov r1,r2
    c.r[2] += 3;  // 0601F070 add #3,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601F072 mov.b @r2,r0
    c.r[1] += 4;  // 0601F074 add #4,r1
    c.r[0] |= 0x1u;  // 0601F076 or #1,r0
    st8(c.r[2], c.r[0]);  // 0601F078 mov.b r0,@r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601F07A mov.b @r1,r0
    c.r[0] |= 0x80u;  // 0601F07C or #128,r0
    st8(c.r[1], c.r[0]); goto L_0601F104;  // 0601F07E bra 0x0601F104 ; mov.b r0,@r1
L_0601F082:
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601F082 tst r1,r1
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_0601F104; } }  // 0601F084 bt/s 0x0601F104 ; mov r2,r1
    c.r[1] += 7;  // 0601F088 add #7,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601F08A mov.b @r1,r2
    c.r[0] = c.r[2];  // 0601F08C mov r2,r0
    c.r[0] >>= 2;  // 0601F08E shlr2 r0
    c.r[0] >>= 2;  // 0601F090 shlr2 r0
    c.r[0] >>= 2;  // 0601F092 shlr2 r0
    c.r[0] &= 0x1u;  // 0601F094 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601F096 tst r0,r0
    if (c.t) { goto L_0601F104; }  // 0601F098 bt 0x0601F104
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601F126u);  // 0601F09A mov.w 0x0601F126,r0
    c.r[2] &= c.r[0];  // 0601F09C and r0,r2
    st8(c.r[1], c.r[2]);  // 0601F09E mov.b r2,@r1
    c.r[7] = ld32(c.r[9]);  // 0601F0A0 mov.l @r9,r7
    c.r[7] += c.r[6];  // 0601F0A2 add r6,r7
    st32(c.r[7] + 12, c.r[5]);  // 0601F0A4 mov.l r5,@(12,r7)
    c.r[1] = c.r[7];  // 0601F0A6 mov r7,r1
    c.r[1] += 2;  // 0601F0A8 add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601F0AA mov.b @r1,r2
    c.r[1] = ld32(0x0601F140u);  // 0601F0AC mov.l 0x0601F140,r1
    c.r[3] = ld32(c.r[1]);  // 0601F0AE mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0601F0B0 extu.b r2,r2
    c.r[1] = 0x1Eu;  // 0601F0B2 mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 0601F0B4 mul.l r1,r2
    c.r[1] = c.macl;  // 0601F0B6 sts macl,r1
    c.r[1] += c.r[3];  // 0601F0B8 add r3,r1
    c.r[1] += 15;  // 0601F0BA add #15,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601F0BC mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0601F0BE extu.b r2,r2
    c.r[1] = ld32(0x0601F144u);  // 0601F0C0 mov.l 0x0601F144,r1
    c.r[3] = c.r[2];  // 0601F0C2 mov r2,r3
    c.r[3] += c.r[3];  // 0601F0C4 add r3,r3
    c.r[3] += c.r[2];  // 0601F0C6 add r2,r3
    c.r[1] = ld32(c.r[1]);  // 0601F0C8 mov.l @r1,r1
    c.r[3] <<= 2;  // 0601F0CA shll2 r3
    c.r[3] += c.r[1];  // 0601F0CC add r1,r3
    c.r[3] += 3;  // 0601F0CE add #3,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0601F0D0 mov.b @r3,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601F128u);  // 0601F0D2 mov.w 0x0601F128,r0
    c.r[3] = c.r[1] & 0xFFu;  // 0601F0D4 extu.b r1,r3
    c.r[3] >>= 2;  // 0601F0D6 shlr2 r3
    c.r[3] >>= 2;  // 0601F0D8 shlr2 r3
    c.r[3] >>= 2;  // 0601F0DA shlr2 r3
    c.r[2] = c.r[3];  // 0601F0DC mov r3,r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 0601F0DE shlr r2
    c.r[1] = c.r[7];  // 0601F0E0 mov r7,r1
    c.r[1] += 3;  // 0601F0E2 add #3,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601F0E4 mov.b @r1,r6
    c.r[7] += 4;  // 0601F0E6 add #4,r7
    c.r[6] &= c.r[0];  // 0601F0E8 and r0,r6
    c.r[6] |= c.r[2];  // 0601F0EA or r2,r6
    st8(c.r[1], c.r[6]);  // 0601F0EC mov.b r6,@r1
    c.r[0] = 0x1u;  // 0601F0EE mov #1,r0
    c.r[3] &= c.r[0];  // 0601F0F0 and r0,r3
    c.r[3] <<= 2;  // 0601F0F2 shll2 r3
    c.r[3] <<= 2;  // 0601F0F4 shll2 r3
    c.r[3] += c.r[3];  // 0601F0F6 add r3,r3
    c.r[3] <<= 2;  // 0601F0F8 shll2 r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0601F0FA mov.b @r7,r1
    c.r[0] = 0x7Fu;  // 0601F0FC mov #127,r0
    c.r[1] &= c.r[0];  // 0601F0FE and r0,r1
    c.r[1] |= c.r[3];  // 0601F100 or r3,r1
    st8(c.r[7], c.r[1]);  // 0601F102 mov.b r1,@r7
L_0601F104:
    c.r[4] += 1;  // 0601F104 add #1,r4
    c.t = (int32_t)c.r[4] >= (int32_t)c.r[8];  // 0601F106 cmp/ge r8,r4
    { const bool k = c.t; c.r[0] = c.r[14]; if (k) { goto L_0601F110; } }  // 0601F108 bt/s 0x0601F110 ; mov r14,r0
    SH2_POLL(c); goto L_0601F002;  // 0601F10C bra 0x0601F002 ; nop
L_0601F110:
    c.r[14] += 76;  // 0601F110 add #76,r14
    c.r[15] = c.r[14];  // 0601F112 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601F114 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601F116 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0601F118 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0601F11A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0601F11C mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601F12Au);  // 0601F11E mov.w 0x0601F12A,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601F120 rts ; mov.l @r15+,r8
}

void f_0601F148(SH2Context& c) {
    ran[361] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601F148 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0601F14A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0601F14C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0601F14E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601F150 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601F152 sts.l pr,@-r15
    c.r[15] -= 76;  // 0601F154 add #-76,r15
    c.r[14] = c.r[15];  // 0601F156 mov r15,r14
    c.r[9] = 0x0u;  // 0601F158 mov #0,r9
    c.r[5] = 0x0u;  // 0601F15A mov #0,r5
    c.r[4] = 0x0u;  // 0601F15C mov #0,r4
    c.r[7] = 0x0u;  // 0601F15E mov #0,r7
    c.r[6] = ld32(0x0601F260u);  // 0601F160 mov.l 0x0601F260,r6
    c.r[3] = 0x49u;  // 0601F162 mov #73,r3
    c.r[2] = c.r[4];  // 0601F164 mov r4,r2
L_0601F166:
    c.r[1] = ld32(c.r[6]);  // 0601F166 mov.l @r6,r1
    c.r[2] <<= 2;  // 0601F168 shll2 r2
    c.r[2] <<= 2;  // 0601F16A shll2 r2
    c.r[2] += c.r[1];  // 0601F16C add r1,r2
    c.r[1] = ld32(c.r[2] + 12);  // 0601F16E mov.l @(12,r2),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601F170 tst r1,r1
    { const bool k = c.t; c.r[1] = c.r[4]; if (k) { goto L_0601F190; } }  // 0601F172 bt/s 0x0601F190 ; mov r4,r1
    c.r[2] += 7;  // 0601F176 add #7,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601F178 mov.b @r2,r1
    c.r[0] = c.r[1];  // 0601F17A mov r1,r0
    c.r[0] >>= 2;  // 0601F17C shlr2 r0
    c.r[0] >>= 2;  // 0601F17E shlr2 r0
    c.r[0] >>= 2;  // 0601F180 shlr2 r0
    c.r[0] &= 0x1u;  // 0601F182 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601F184 tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[4]; if (k) { goto L_0601F190; } }  // 0601F186 bt/s 0x0601F190 ; mov r4,r1
    c.r[0] = c.r[14];  // 0601F18A mov r14,r0
    st8(c.r[0] + c.r[7], c.r[4]);  // 0601F18C mov.b r4,@(r0,r7)
    c.r[7] += 1;  // 0601F18E add #1,r7
L_0601F190:
    c.r[1] += 1;  // 0601F190 add #1,r1
    c.r[4] = c.r[1] & 0xFFu;  // 0601F192 extu.b r1,r4
    c.t = c.r[4] > c.r[3];  // 0601F194 cmp/hi r3,r4
    { const bool k = !c.t; c.r[2] = c.r[4]; if (k) { SH2_POLL(c); goto L_0601F166; } }  // 0601F196 bf/s 0x0601F166 ; mov r4,r2
    c.r[1] = ld32(0x0601F264u);  // 0601F19A mov.l 0x0601F264,r1
    c.r[2] = ld32(c.r[1]);  // 0601F19C mov.l @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601F256u);  // 0601F19E mov.w 0x0601F256,r0
    c.r[6] = 0x0u;  // 0601F1A0 mov #0,r6
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[7];  // 0601F1A2 cmp/ge r7,r6
    c.r[1] = 0x0u;  // 0601F1A4 mov #0,r1
    { const bool k = c.t; st8(c.r[0] + c.r[2], c.r[1]); if (k) { goto L_0601F20C; } }  // 0601F1A6 bt/s 0x0601F20C ; mov.b r1,@(r0,r2)
    c.r[10] = (uint32_t)(int16_t)ld16(0x0601F258u);  // 0601F1AA mov.w 0x0601F258,r10
    c.r[11] = ld32(0x0601F260u);  // 0601F1AC mov.l 0x0601F260,r11
L_0601F1AE:
    c.r[8] = 0x0u;  // 0601F1AE mov #0,r8
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[7];  // 0601F1B0 cmp/ge r7,r8
    { const bool k = c.t; c.r[2] = 0x0u; if (k) { goto L_0601F1DE; } }  // 0601F1B2 bt/s 0x0601F1DE ; mov #0,r2
    c.r[0] = c.r[14];  // 0601F1B6 mov r14,r0
L_0601F1B8:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0601F1B8 mov.b @(r0,r8),r1
    c.r[4] = c.r[1] & 0xFFu;  // 0601F1BA extu.b r1,r4
    c.t = c.r[4] == c.r[10];  // 0601F1BC cmp/eq r10,r4
    { const bool k = c.t; c.r[0] = c.r[4]; if (k) { goto L_0601F1D6; } }  // 0601F1BE bt/s 0x0601F1D6 ; mov r4,r0
    c.r[1] = ld32(c.r[11]);  // 0601F1C2 mov.l @r11,r1
    c.r[0] <<= 2;  // 0601F1C4 shll2 r0
    c.r[0] <<= 2;  // 0601F1C6 shll2 r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601F1C8 mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601F1CA extu.b r1,r1
    c.t = c.r[1] > c.r[2];  // 0601F1CC cmp/hi r2,r1
    if (!c.t) { goto L_0601F1D6; }  // 0601F1CE bf 0x0601F1D6
    c.r[2] = c.r[1];  // 0601F1D0 mov r1,r2
    c.r[9] = c.r[4];  // 0601F1D2 mov r4,r9
    c.r[5] = c.r[8];  // 0601F1D4 mov r8,r5
L_0601F1D6:
    c.r[8] += 1;  // 0601F1D6 add #1,r8
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[7];  // 0601F1D8 cmp/ge r7,r8
    { const bool k = !c.t; c.r[0] = c.r[14]; if (k) { SH2_POLL(c); goto L_0601F1B8; } }  // 0601F1DA bf/s 0x0601F1B8 ; mov r14,r0
L_0601F1DE:
    c.r[1] = ld32(0x0601F264u);  // 0601F1DE mov.l 0x0601F264,r1
    c.r[3] = ld32(c.r[1]);  // 0601F1E0 mov.l @r1,r3
    c.r[4] = (uint32_t)(int16_t)ld16(0x0601F256u);  // 0601F1E2 mov.w 0x0601F256,r4
    c.r[0] = c.r[3];  // 0601F1E4 mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[4]);  // 0601F1E6 mov.b @(r0,r4),r2
    c.r[6] += 1;  // 0601F1E8 add #1,r6
    c.r[1] = c.r[2];  // 0601F1EA mov r2,r1
    c.r[1] += 1;  // 0601F1EC add #1,r1
    st8(c.r[0] + c.r[4], c.r[1]);  // 0601F1EE mov.b r1,@(r0,r4)
    c.r[1] = c.r[2] & 0xFFu;  // 0601F1F0 extu.b r2,r1
    c.r[1] += c.r[1];  // 0601F1F2 add r1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601F1F4 mov.b @(r0,r1),r2
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[7];  // 0601F1F6 cmp/ge r7,r6
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601F25Au);  // 0601F1F8 mov.w 0x0601F25A,r0
    c.r[2] &= c.r[0];  // 0601F1FA and r0,r2
    c.r[0] = c.r[3];  // 0601F1FC mov r3,r0
    st8(c.r[0] + c.r[1], c.r[2]);  // 0601F1FE mov.b r2,@(r0,r1)
    c.r[3] += c.r[1];  // 0601F200 add r1,r3
    c.r[3] += 1;  // 0601F202 add #1,r3
    st8(c.r[3], c.r[9]);  // 0601F204 mov.b r9,@r3
    c.r[0] = c.r[14];  // 0601F206 mov r14,r0
    { const bool k = !c.t; st8(c.r[0] + c.r[5], c.r[10]); if (k) { SH2_POLL(c); goto L_0601F1AE; } }  // 0601F208 bf/s 0x0601F1AE ; mov.b r10,@(r0,r5)
L_0601F20C:
    c.r[3] = ld32(0x0601F264u);  // 0601F20C mov.l 0x0601F264,r3
    c.r[2] = ld32(c.r[3]);  // 0601F20E mov.l @r3,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601F256u);  // 0601F210 mov.w 0x0601F256,r1
    c.r[0] = c.r[2];  // 0601F212 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601F214 mov.b @(r0,r1),r1
    c.r[8] = 0x0u;  // 0601F216 mov #0,r8
    c.r[1] = c.r[1] & 0xFFu;  // 0601F218 extu.b r1,r1
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 0601F21A cmp/ge r1,r8
    { const bool k = c.t; c.r[9] = c.r[3]; if (k) { goto L_0601F242; } }  // 0601F21C bt/s 0x0601F242 ; mov r3,r9
    c.r[10] = ld32(0x0601F268u);  // 0601F220 mov.l 0x0601F268,r10
    c.r[1] = c.r[8];  // 0601F222 mov r8,r1
L_0601F224:
    c.r[2] = ld32(c.r[9]);  // 0601F224 mov.l @r9,r2
    c.r[1] += c.r[1];  // 0601F226 add r1,r1
    c.r[2] += c.r[1];  // 0601F228 add r1,r2
    c.r[2] += 1;  // 0601F22A add #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601F22C mov.b @r2,r1
    { const uint32_t x = c.r[10]; c.pr = 0x0601F232u; c.r[4] = c.r[1] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601F232u) return; }  // 0601F22E jsr @r10 ; extu.b r1,r4
    c.r[1] = ld32(c.r[9]);  // 0601F232 mov.l @r9,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601F256u);  // 0601F234 mov.w 0x0601F256,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601F236 mov.b @(r0,r1),r1
    c.r[8] += 1;  // 0601F238 add #1,r8
    c.r[1] = c.r[1] & 0xFFu;  // 0601F23A extu.b r1,r1
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 0601F23C cmp/ge r1,r8
    { const bool k = !c.t; c.r[1] = c.r[8]; if (k) { SH2_POLL(c); goto L_0601F224; } }  // 0601F23E bf/s 0x0601F224 ; mov r8,r1
L_0601F242:
    c.r[14] += 76;  // 0601F242 add #76,r14
    c.r[15] = c.r[14];  // 0601F244 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601F246 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601F248 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0601F24A mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0601F24C mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0601F24E mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601F25Cu);  // 0601F250 mov.w 0x0601F25C,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601F252 rts ; mov.l @r15+,r8
}

void f_0601F26C(SH2Context& c) {
    ran[362] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601F26C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0601F26E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0601F270 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601F272 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601F274 sts.l pr,@-r15
    c.r[15] -= 76;  // 0601F276 add #-76,r15
    c.r[14] = c.r[15];  // 0601F278 mov r15,r14
    c.r[1] = ld32(0x0601F308u);  // 0601F27A mov.l 0x0601F308,r1
    c.r[8] = ld32(0x0601F30Cu);  // 0601F27C mov.l 0x0601F30C,r8
    c.r[0] = ld32(0x0601F310u);  // 0601F27E mov.l 0x0601F310,r0
    c.r[6] = 0x0u;  // 0601F280 mov #0,r6
    c.r[2] = ld32(c.r[1]);  // 0601F282 mov.l @r1,r2
    c.r[4] = c.r[14];  // 0601F284 mov r14,r4
    c.r[1] = c.r[2];  // 0601F286 mov r2,r1
    c.r[1] += 1;  // 0601F288 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601F28A mov.b @r1,r1
    c.r[2] += 2;  // 0601F28C add #2,r2
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601F28E mov.b @r2,r5
    c.r[9] = c.r[1] & 0xFFu;  // 0601F290 extu.b r1,r9
    c.r[1] = 0x0u;  // 0601F292 mov #0,r1
    { const uint32_t x = c.r[0]; c.pr = 0x0601F298u; st32(c.r[8] + 20, c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601F298u) return; }  // 0601F294 jsr @r0 ; mov.l r1,@(20,r8)
    c.r[5] = c.r[0];  // 0601F298 mov r0,r5
    c.r[7] = 0x0u;  // 0601F29A mov #0,r7
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[5];  // 0601F29C cmp/ge r5,r7
    { const bool k = c.t; c.r[4] = c.r[8]; if (k) { goto L_0601F2F2; } }  // 0601F29E bt/s 0x0601F2F2 ; mov r8,r4
    c.r[1] = ld32(0x0601F314u);  // 0601F2A2 mov.l 0x0601F314,r1
    c.r[6] = ld32(c.r[1]);  // 0601F2A4 mov.l @r1,r6
    c.r[10] = ld32(0x0601F318u);  // 0601F2A6 mov.l 0x0601F318,r10
    c.r[0] = c.r[14];  // 0601F2A8 mov r14,r0
L_0601F2AA:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0601F2AA mov.b @(r0,r7),r1
    c.r[8] = c.r[1] & 0xFFu;  // 0601F2AC extu.b r1,r8
    c.r[8] <<= 2;  // 0601F2AE shll2 r8
    c.r[8] <<= 2;  // 0601F2B0 shll2 r8
    c.r[3] = c.r[8];  // 0601F2B2 mov r8,r3
    c.r[3] += c.r[6];  // 0601F2B4 add r6,r3
    c.r[2] = ld32(c.r[3] + 4);  // 0601F2B6 mov.l @(4,r3),r2
    c.r[1] = ld32(0x0601F31Cu);  // 0601F2B8 mov.l 0x0601F31C,r1
    c.r[2] &= c.r[1];  // 0601F2BA and r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0601F2BC tst r2,r2
    { const bool k = !c.t; c.r[3] += 1; if (k) { goto L_0601F2EA; } }  // 0601F2BE bf/s 0x0601F2EA ; add #1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0601F2C2 mov.b @r3,r1
    c.r[0] = c.r[8];  // 0601F2C4 mov r8,r0
    c.r[2] = c.r[1] & 0xFFu;  // 0601F2C6 extu.b r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 0601F2C8 mov.b @(r0,r6),r1
    c.r[3] = c.r[1] & 0xFFu;  // 0601F2CA extu.b r1,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601F304u);  // 0601F2CC mov.w 0x0601F304,r1
    c.r[0] = c.r[10];  // 0601F2CE mov r10,r0
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 0601F2D0 mov.l @(r0,r1),r1
    c.r[2] <<= 2;  // 0601F2D2 shll2 r2
    c.r[2] <<= 2;  // 0601F2D4 shll2 r2
    c.r[2] <<= 2;  // 0601F2D6 shll2 r2
    c.r[2] += c.r[1];  // 0601F2D8 add r1,r2
    c.r[0] = c.r[2];  // 0601F2DA mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0601F2DC mov.b @(r0,r3),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601F2DE extu.b r1,r1
    c.t = c.r[9] == c.r[1];  // 0601F2E0 cmp/eq r1,r9
    if (!c.t) { goto L_0601F2EA; }  // 0601F2E2 bf 0x0601F2EA
    c.r[1] = ld32(c.r[4] + 20);  // 0601F2E4 mov.l @(20,r4),r1
    c.r[1] += 1;  // 0601F2E6 add #1,r1
    st32(c.r[4] + 20, c.r[1]);  // 0601F2E8 mov.l r1,@(20,r4)
L_0601F2EA:
    c.r[7] += 1;  // 0601F2EA add #1,r7
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[5];  // 0601F2EC cmp/ge r5,r7
    { const bool k = !c.t; c.r[0] = c.r[14]; if (k) { SH2_POLL(c); goto L_0601F2AA; } }  // 0601F2EE bf/s 0x0601F2AA ; mov r14,r0
L_0601F2F2:
    c.r[14] += 76;  // 0601F2F2 add #76,r14
    c.r[15] = c.r[14];  // 0601F2F4 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601F2F6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601F2F8 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0601F2FA mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0601F2FC mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601F306u);  // 0601F2FE mov.w 0x0601F306,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601F300 rts ; mov.l @r15+,r8
}

void f_0601F320(SH2Context& c) {
    ran[363] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601F320 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601F322 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0601F324 mov r15,r14
    c.r[1] = ld32(0x0601F38Cu);  // 0601F326 mov.l 0x0601F38C,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0601F328 mov.w @r1,r4
    c.r[0] = ld32(0x0601F390u);  // 0601F32A mov.l 0x0601F390,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601F330u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601F330u) return; }  // 0601F32C jsr @r0 ; extu.w r4,r4
    c.r[0] = c.r[0] & 0xFFu;  // 0601F330 extu.b r0,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601F386u);  // 0601F332 mov.w 0x0601F386,r1
    c.t = c.r[0] == c.r[1];  // 0601F334 cmp/eq r1,r0
    { const bool k = c.t; c.r[7] = c.r[0]; if (k) { goto L_0601F37C; } }  // 0601F336 bt/s 0x0601F37C ; mov r0,r7
    c.r[6] = ld32(0x0601F394u);  // 0601F33A mov.l 0x0601F394,r6
    c.r[2] = ld32(c.r[6]);  // 0601F33C mov.l @r6,r2
    c.r[7] <<= 2;  // 0601F33E shll2 r7
    c.r[7] <<= 2;  // 0601F340 shll2 r7
    c.r[2] += c.r[7];  // 0601F342 add r7,r2
    c.r[1] = c.r[2];  // 0601F344 mov r2,r1
    c.r[1] += 3;  // 0601F346 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601F348 mov.b @r1,r1
    c.r[5] = 0x3u;  // 0601F34A mov #3,r5
    c.r[3] = c.r[1];  // 0601F34C mov r1,r3
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 0601F34E shlr r3
    c.r[3] &= c.r[5];  // 0601F350 and r5,r3
    c.t = (c.r[3] & c.r[3]) == 0;  // 0601F352 tst r3,r3
    if (!c.t) { goto L_0601F37C; }  // 0601F354 bf 0x0601F37C
    c.r[1] = ld32(c.r[2] + 12);  // 0601F356 mov.l @(12,r2),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601F358 tst r1,r1
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_0601F37C; } }  // 0601F35A bt/s 0x0601F37C ; mov r2,r1
    c.r[1] += 7;  // 0601F35E add #7,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601F360 mov.b @r1,r2
    c.r[0] = c.r[2];  // 0601F362 mov r2,r0
    c.r[0] >>= 2;  // 0601F364 shlr2 r0
    c.r[0] >>= 2;  // 0601F366 shlr2 r0
    c.r[0] >>= 2;  // 0601F368 shlr2 r0
    c.r[0] &= 0x1u;  // 0601F36A and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601F36C tst r0,r0
    { const bool k = c.t; c.r[0] = c.r[2]; if (k) { goto L_0601F37C; } }  // 0601F36E bt/s 0x0601F37C ; mov r2,r0
    c.r[0] &= 0xBFu;  // 0601F372 and #191,r0
    st8(c.r[1], c.r[0]);  // 0601F374 mov.b r0,@r1
    c.r[1] = ld32(c.r[6]);  // 0601F376 mov.l @r6,r1
    c.r[7] += c.r[1];  // 0601F378 add r1,r7
    st32(c.r[7] + 12, c.r[3]);  // 0601F37A mov.l r3,@(12,r7)
L_0601F37C:
    c.r[15] = c.r[14];  // 0601F37C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601F37E lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601F388u);  // 0601F380 mov.w 0x0601F388,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601F382 rts ; mov.l @r15+,r14
}

void f_0601F398(SH2Context& c) {
    ran[364] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601F398 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0601F39A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601F39C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601F39E sts.l pr,@-r15
    c.r[7] = ld32(0x0601F570u);  // 0601F3A0 mov.l 0x0601F570,r7
    c.r[6] = ld32(c.r[7]);  // 0601F3A2 mov.l @r7,r6
    c.r[2] = c.r[6];  // 0601F3A4 mov r6,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]); c.r[2] += 1;  // 0601F3A6 mov.b @r2+,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601F3A8 extu.b r1,r1
    c.r[5] = c.r[1];  // 0601F3AA mov r1,r5
    c.r[5] <<= 8;  // 0601F3AC shll8 r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601F3AE mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601F3B0 extu.b r1,r1
    c.r[5] |= c.r[1];  // 0601F3B2 or r1,r5
    c.r[1] = ld32(0x0601F574u);  // 0601F3B4 mov.l 0x0601F574,r1
    c.t = (int32_t)c.r[5] > (int32_t)c.r[1];  // 0601F3B6 cmp/gt r1,r5
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0601F400; } }  // 0601F3B8 bt/s 0x0601F400 ; mov r15,r14
    c.r[1] = ld32(0x0601F578u);  // 0601F3BC mov.l 0x0601F578,r1
    c.t = (int32_t)c.r[5] >= (int32_t)c.r[1];  // 0601F3BE cmp/ge r1,r5
    { const bool k = !c.t; c.r[3] = c.r[7]; if (k) { goto L_0601F3C8; } }  // 0601F3C0 bf/s 0x0601F3C8 ; mov r7,r3
    goto L_0601F4CC;  // 0601F3C4 bra 0x0601F4CC ; nop
L_0601F3C8:
    c.r[1] = ld32(0x0601F57Cu);  // 0601F3C8 mov.l 0x0601F57C,r1
    c.t = c.r[5] == c.r[1];  // 0601F3CA cmp/eq r1,r5
    { const bool k = c.t; c.t = (int32_t)c.r[5] > (int32_t)c.r[1]; if (k) { goto L_0601F44E; } }  // 0601F3CC bt/s 0x0601F44E ; cmp/gt r1,r5
    if (c.t) { goto L_0601F3F2; }  // 0601F3D0 bt 0x0601F3F2
    c.r[1] = ld32(0x0601F580u);  // 0601F3D2 mov.l 0x0601F580,r1
    c.t = (int32_t)c.r[5] >= (int32_t)c.r[1];  // 0601F3D4 cmp/ge r1,r5
    if (c.t) { goto L_0601F3DC; }  // 0601F3D6 bt 0x0601F3DC
    goto L_0601F5D0;  // 0601F3D8 bra 0x0601F5D0 ; nop
L_0601F3DC:
    c.r[1] = ld32(0x0601F584u);  // 0601F3DC mov.l 0x0601F584,r1
    c.t = (int32_t)c.r[5] > (int32_t)c.r[1];  // 0601F3DE cmp/gt r1,r5
    if (c.t) { goto L_0601F3E6; }  // 0601F3E0 bt 0x0601F3E6
    goto L_0601F5C0;  // 0601F3E2 bra 0x0601F5C0 ; nop
L_0601F3E6:
    c.r[1] = ld32(0x0601F588u);  // 0601F3E6 mov.l 0x0601F588,r1
    c.t = c.r[5] == c.r[1];  // 0601F3E8 cmp/eq r1,r5
    { const bool k = c.t; c.r[1] = 0xFFFFFFFFu; if (k) { goto L_0601F444; } }  // 0601F3EA bt/s 0x0601F444 ; mov #-1,r1
    c.r[7] = c.r[5]; goto L_0601F5D2;  // 0601F3EE bra 0x0601F5D2 ; mov r5,r7
L_0601F3F2:
    c.r[1] = ld32(0x0601F58Cu);  // 0601F3F2 mov.l 0x0601F58C,r1
    c.t = c.r[5] == c.r[1];  // 0601F3F4 cmp/eq r1,r5
    { const bool k = c.t; c.t = (int32_t)c.r[5] > (int32_t)c.r[1]; if (k) { goto L_0601F466; } }  // 0601F3F6 bt/s 0x0601F466 ; cmp/gt r1,r5
    if (!c.t) { goto L_0601F45A; }  // 0601F3FA bf 0x0601F45A
    goto L_0601F474;  // 0601F3FC bra 0x0601F474 ; nop
L_0601F400:
    c.r[1] = ld32(0x0601F590u);  // 0601F400 mov.l 0x0601F590,r1
    c.t = (int32_t)c.r[5] > (int32_t)c.r[1];  // 0601F402 cmp/gt r1,r5
    if (c.t) { goto L_0601F41E; }  // 0601F404 bt 0x0601F41E
    c.r[1] = ld32(0x0601F594u);  // 0601F406 mov.l 0x0601F594,r1
    c.t = (int32_t)c.r[5] >= (int32_t)c.r[1];  // 0601F408 cmp/ge r1,r5
    if (c.t) { goto L_0601F4C8; }  // 0601F40A bt 0x0601F4C8
    c.r[1] = ld32(0x0601F598u);  // 0601F40C mov.l 0x0601F598,r1
    c.t = c.r[5] == c.r[1];  // 0601F40E cmp/eq r1,r5
    if (c.t) { goto L_0601F448; }  // 0601F410 bt 0x0601F448
    c.r[1] = ld32(0x0601F59Cu);  // 0601F412 mov.l 0x0601F59C,r1
    c.t = c.r[5] == c.r[1];  // 0601F414 cmp/eq r1,r5
    if (c.t) { goto L_0601F494; }  // 0601F416 bt 0x0601F494
    c.r[7] = c.r[5];  // 0601F418 mov r5,r7
    c.r[7] >>= 8; goto L_0601F5D4;  // 0601F41A bra 0x0601F5D4 ; shlr8 r7
L_0601F41E:
    c.r[1] = ld32(0x0601F5A0u);  // 0601F41E mov.l 0x0601F5A0,r1
    c.t = c.r[5] == c.r[1];  // 0601F420 cmp/eq r1,r5
    { const bool k = c.t; c.r[3] = c.r[7]; if (k) { goto L_0601F504; } }  // 0601F422 bt/s 0x0601F504 ; mov r7,r3
    c.t = (int32_t)c.r[5] >= (int32_t)c.r[1];  // 0601F426 cmp/ge r1,r5
    { const bool k = !c.t; c.r[3] += 68; if (k) { goto L_0601F4EA; } }  // 0601F428 bf/s 0x0601F4EA ; add #68,r3
    c.r[1] = ld32(0x0601F5A4u);  // 0601F42C mov.l 0x0601F5A4,r1
    c.t = c.r[5] == c.r[1];  // 0601F42E cmp/eq r1,r5
    { const bool k = c.t; c.r[3] = c.r[7]; if (k) { goto L_0601F520; } }  // 0601F430 bt/s 0x0601F520 ; mov r7,r3
    c.r[1] = ld32(0x0601F5A8u);  // 0601F434 mov.l 0x0601F5A8,r1
    c.t = c.r[5] == c.r[1];  // 0601F436 cmp/eq r1,r5
    { const bool k = !c.t; c.r[3] += 68; if (k) { goto L_0601F440; } }  // 0601F438 bf/s 0x0601F440 ; add #68,r3
    goto L_0601F540;  // 0601F43C bra 0x0601F540 ; nop
L_0601F440:
    c.r[7] = c.r[5]; goto L_0601F5D2;  // 0601F440 bra 0x0601F5D2 ; mov r5,r7
L_0601F444:
    c.r[2] = ld32(0x0601F5ACu);  // 0601F444 mov.l 0x0601F5AC,r2
    st8(c.r[2], c.r[1]);  // 0601F446 mov.b r1,@r2
L_0601F448:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601F568u);  // 0601F448 mov.w 0x0601F568,r0
    c.r[15] = c.r[14]; goto L_0601F61E;  // 0601F44A bra 0x0601F61E ; mov r14,r15
L_0601F44E:
    c.r[1] = ld32(0x0601F5B0u);  // 0601F44E mov.l 0x0601F5B0,r1
    c.r[2] = ld32(c.r[1]);  // 0601F450 mov.l @r1,r2
    c.r[1] = ld32(0x0601F5B4u);  // 0601F452 mov.l 0x0601F5B4,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601F56Au);  // 0601F454 mov.w 0x0601F56A,r0
    c.r[1] = ld32(c.r[1]); goto L_0601F470;  // 0601F456 bra 0x0601F470 ; mov.l @r1,r1
L_0601F45A:
    c.r[1] = ld32(0x0601F5B0u);  // 0601F45A mov.l 0x0601F5B0,r1
    c.r[2] = ld32(c.r[1]);  // 0601F45C mov.l @r1,r2
    c.r[1] = ld32(0x0601F5B4u);  // 0601F45E mov.l 0x0601F5B4,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601F56Cu);  // 0601F460 mov.w 0x0601F56C,r0
    c.r[1] = ld32(c.r[1]); goto L_0601F470;  // 0601F462 bra 0x0601F470 ; mov.l @r1,r1
L_0601F466:
    c.r[1] = ld32(0x0601F5B0u);  // 0601F466 mov.l 0x0601F5B0,r1
    c.r[2] = ld32(c.r[1]);  // 0601F468 mov.l @r1,r2
    c.r[1] = ld32(0x0601F5B4u);  // 0601F46A mov.l 0x0601F5B4,r1
    c.r[1] = ld32(c.r[1]);  // 0601F46C mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601F56Eu);  // 0601F46E mov.w 0x0601F56E,r0
L_0601F470:
    st32(c.r[0] + c.r[2], c.r[1]); SH2_POLL(c); goto L_0601F448;  // 0601F470 bra 0x0601F448 ; mov.l r1,@(r0,r2)
L_0601F474:
    c.r[3] = ld32(0x0601F5B4u);  // 0601F474 mov.l 0x0601F5B4,r3
    c.r[1] = c.r[3];  // 0601F476 mov r3,r1
    c.r[1] += 32;  // 0601F478 add #32,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601F47A mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0601F47C extu.b r1,r2
    c.r[1] = ld32(0x0601F5B8u);  // 0601F47E mov.l 0x0601F5B8,r1
    c.r[1] = ld32(c.r[1]);  // 0601F480 mov.l @r1,r1
    c.r[2] <<= 2;  // 0601F482 shll2 r2
    c.r[2] <<= 2;  // 0601F484 shll2 r2
    c.r[2] += c.r[1];  // 0601F486 add r1,r2
    c.r[1] = ld32(c.r[2] + 12);  // 0601F488 mov.l @(12,r2),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601F48A tst r1,r1
    if (c.t) { SH2_POLL(c); goto L_0601F448; }  // 0601F48C bt 0x0601F448
    c.r[1] = ld32(c.r[3]);  // 0601F48E mov.l @r3,r1
    st32(c.r[2] + 12, c.r[1]); SH2_POLL(c); goto L_0601F448;  // 0601F490 bra 0x0601F448 ; mov.l r1,@(12,r2)
L_0601F494:
    c.r[5] = ld32(0x0601F5B4u);  // 0601F494 mov.l 0x0601F5B4,r5
    c.r[1] = ld32(c.r[5] + 8);  // 0601F496 mov.l @(8,r5),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601F498 tst r1,r1
    { const bool k = c.t; c.r[1] = c.r[5]; if (k) { goto L_0601F4BE; } }  // 0601F49A bt/s 0x0601F4BE ; mov r5,r1
    c.r[3] = c.r[7];  // 0601F49E mov r7,r3
    c.r[3] += 68;  // 0601F4A0 add #68,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0601F4A2 mov.b @r3,r2
    c.r[6] += 2;  // 0601F4A4 add #2,r6
    c.r[1] = c.r[2];  // 0601F4A6 mov r2,r1
    c.r[1] += 1;  // 0601F4A8 add #1,r1
    st8(c.r[3], c.r[1]);  // 0601F4AA mov.b r1,@r3
    c.r[2] = c.r[2] & 0xFFu;  // 0601F4AC extu.b r2,r2
    c.r[2] <<= 2;  // 0601F4AE shll2 r2
    c.r[2] += c.r[7];  // 0601F4B0 add r7,r2
    st32(c.r[2] + 4, c.r[6]);  // 0601F4B2 mov.l r6,@(4,r2)
    c.r[1] = ld32(c.r[5] + 8);  // 0601F4B4 mov.l @(8,r5),r1
    st32(c.r[7], c.r[1]);  // 0601F4B6 mov.l r1,@r7
    c.r[1] = 0x0u;  // 0601F4B8 mov #0,r1
    st32(c.r[5] + 8, c.r[1]); goto L_0601F612;  // 0601F4BA bra 0x0601F612 ; mov.l r1,@(8,r5)
L_0601F4BE:
    c.r[1] += 37;  // 0601F4BE add #37,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601F4C0 mov.b @r1,r0
    c.r[0] &= 0xFu;  // 0601F4C2 and #15,r0
    st8(c.r[1], c.r[0]); SH2_POLL(c); goto L_0601F448;  // 0601F4C4 bra 0x0601F448 ; mov.b r0,@r1
L_0601F4C8:
    c.r[7] = ld32(0x0601F570u);  // 0601F4C8 mov.l 0x0601F570,r7
    c.r[3] = c.r[7];  // 0601F4CA mov r7,r3
L_0601F4CC:
    c.r[3] += 68;  // 0601F4CC add #68,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0601F4CE mov.b @r3,r2
    c.r[1] = c.r[2];  // 0601F4D0 mov r2,r1
    c.r[1] += 1;  // 0601F4D2 add #1,r1
    st8(c.r[3], c.r[1]);  // 0601F4D4 mov.b r1,@r3
    c.r[2] = c.r[2] & 0xFFu;  // 0601F4D6 extu.b r2,r2
    c.r[2] <<= 2;  // 0601F4D8 shll2 r2
    c.r[1] = ld32(c.r[7]);  // 0601F4DA mov.l @r7,r1
    c.r[2] += c.r[7];  // 0601F4DC add r7,r2
    c.r[1] += 2;  // 0601F4DE add #2,r1
    st32(c.r[2] + 4, c.r[1]);  // 0601F4E0 mov.l r1,@(4,r2)
    c.r[1] = ld32(0x0601F5B4u);  // 0601F4E2 mov.l 0x0601F5B4,r1
    c.r[1] = ld32(c.r[1]);  // 0601F4E4 mov.l @r1,r1
    st32(c.r[7], c.r[1]); goto L_0601F612;  // 0601F4E6 bra 0x0601F612 ; mov.l r1,@r7
L_0601F4EA:
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0601F4EA mov.b @r3,r2
    c.r[6] += 2;  // 0601F4EC add #2,r6
    c.r[1] = c.r[2];  // 0601F4EE mov r2,r1
    c.r[1] += 1;  // 0601F4F0 add #1,r1
    st8(c.r[3], c.r[1]);  // 0601F4F2 mov.b r1,@r3
    c.r[2] = c.r[2] & 0xFFu;  // 0601F4F4 extu.b r2,r2
    c.r[2] <<= 2;  // 0601F4F6 shll2 r2
    c.r[2] += c.r[7];  // 0601F4F8 add r7,r2
    st32(c.r[2] + 4, c.r[6]);  // 0601F4FA mov.l r6,@(4,r2)
    c.r[1] = ld32(0x0601F5B0u);  // 0601F4FC mov.l 0x0601F5B0,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601F56Au);  // 0601F4FE mov.w 0x0601F56A,r0
    c.r[1] = ld32(c.r[1]); goto L_0601F53A;  // 0601F500 bra 0x0601F53A ; mov.l @r1,r1
L_0601F504:
    c.r[3] += 68;  // 0601F504 add #68,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0601F506 mov.b @r3,r2
    c.r[6] += 2;  // 0601F508 add #2,r6
    c.r[1] = c.r[2];  // 0601F50A mov r2,r1
    c.r[1] += 1;  // 0601F50C add #1,r1
    st8(c.r[3], c.r[1]);  // 0601F50E mov.b r1,@r3
    c.r[2] = c.r[2] & 0xFFu;  // 0601F510 extu.b r2,r2
    c.r[2] <<= 2;  // 0601F512 shll2 r2
    c.r[2] += c.r[7];  // 0601F514 add r7,r2
    st32(c.r[2] + 4, c.r[6]);  // 0601F516 mov.l r6,@(4,r2)
    c.r[1] = ld32(0x0601F5B0u);  // 0601F518 mov.l 0x0601F5B0,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601F56Cu);  // 0601F51A mov.w 0x0601F56C,r0
    c.r[1] = ld32(c.r[1]); goto L_0601F53A;  // 0601F51C bra 0x0601F53A ; mov.l @r1,r1
L_0601F520:
    c.r[3] += 68;  // 0601F520 add #68,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0601F522 mov.b @r3,r2
    c.r[6] += 2;  // 0601F524 add #2,r6
    c.r[1] = c.r[2];  // 0601F526 mov r2,r1
    c.r[1] += 1;  // 0601F528 add #1,r1
    st8(c.r[3], c.r[1]);  // 0601F52A mov.b r1,@r3
    c.r[2] = c.r[2] & 0xFFu;  // 0601F52C extu.b r2,r2
    c.r[2] <<= 2;  // 0601F52E shll2 r2
    c.r[2] += c.r[7];  // 0601F530 add r7,r2
    st32(c.r[2] + 4, c.r[6]);  // 0601F532 mov.l r6,@(4,r2)
    c.r[1] = ld32(0x0601F5B0u);  // 0601F534 mov.l 0x0601F5B0,r1
    c.r[1] = ld32(c.r[1]);  // 0601F536 mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601F56Eu);  // 0601F538 mov.w 0x0601F56E,r0
L_0601F53A:
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 0601F53A mov.l @(r0,r1),r1
    st32(c.r[7], c.r[1]); goto L_0601F612;  // 0601F53C bra 0x0601F612 ; mov.l r1,@r7
L_0601F540:
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0601F540 mov.b @r3,r2
    c.r[6] += 2;  // 0601F542 add #2,r6
    c.r[1] = c.r[2];  // 0601F544 mov r2,r1
    c.r[1] += 1;  // 0601F546 add #1,r1
    st8(c.r[3], c.r[1]);  // 0601F548 mov.b r1,@r3
    c.r[2] = c.r[2] & 0xFFu;  // 0601F54A extu.b r2,r2
    c.r[2] <<= 2;  // 0601F54C shll2 r2
    c.r[2] += c.r[7];  // 0601F54E add r7,r2
    st32(c.r[2] + 4, c.r[6]);  // 0601F550 mov.l r6,@(4,r2)
    c.r[1] = ld32(0x0601F5BCu);  // 0601F552 mov.l 0x0601F5BC,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601F554 mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0601F556 extu.b r2,r2
    c.r[1] = ld32(0x0601F5B8u);  // 0601F558 mov.l 0x0601F5B8,r1
    c.r[1] = ld32(c.r[1]);  // 0601F55A mov.l @r1,r1
    c.r[2] <<= 2;  // 0601F55C shll2 r2
    c.r[2] <<= 2;  // 0601F55E shll2 r2
    c.r[2] += c.r[1];  // 0601F560 add r1,r2
    c.r[1] = ld32(c.r[2] + 12);  // 0601F562 mov.l @(12,r2),r1
    st32(c.r[7], c.r[1]); goto L_0601F612;  // 0601F564 bra 0x0601F612 ; mov.l r1,@r7
L_0601F5C0:
    c.r[1] = ld32(0x0601F628u);  // 0601F5C0 mov.l 0x0601F628,r1
    c.r[1] = ld32(c.r[1]);  // 0601F5C2 mov.l @r1,r1
    c.r[1] += 6;  // 0601F5C4 add #6,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601F5C6 mov.b @r1,r1
    c.r[5] = c.r[5] & 0xFFu;  // 0601F5C8 extu.b r5,r5
    c.r[1] = c.r[1] & 0xFFu;  // 0601F5CA extu.b r1,r1
    c.r[1] <<= 8;  // 0601F5CC shll8 r1
    c.r[5] |= c.r[1];  // 0601F5CE or r1,r5
L_0601F5D0:
    c.r[7] = c.r[5];  // 0601F5D0 mov r5,r7
L_0601F5D2:
    c.r[7] >>= 8;  // 0601F5D2 shlr8 r7
L_0601F5D4:
    c.r[9] = ld32(0x0601F62Cu);  // 0601F5D4 mov.l 0x0601F62C,r9
    c.r[3] = c.r[9];  // 0601F5D6 mov r9,r3
    c.r[3] += 31;  // 0601F5D8 add #31,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0601F5DA mov.b @r3,r1
    c.r[2] = c.r[7] & 0xFFFFu;  // 0601F5DC extu.w r7,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0601F5DE extu.b r1,r1
    c.t = c.r[2] == c.r[1];  // 0601F5E0 cmp/eq r1,r2
    if (c.t) { goto L_0601F5E6; }  // 0601F5E2 bt 0x0601F5E6
    st8(c.r[3], c.r[7]);  // 0601F5E4 mov.b r7,@r3
L_0601F5E6:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0601F5E6 mov.b @r3,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601F5E8 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601F5EA tst r1,r1
    { const bool k = c.t; c.r[8] = c.r[5] & 0xFFu; if (k) { goto L_0601F5FA; } }  // 0601F5EC bt/s 0x0601F5FA ; extu.b r5,r8
    c.r[5] = c.r[5] & 0xFFu;  // 0601F5F0 extu.b r5,r5
    c.r[1] = ld32(0x0601F630u);  // 0601F5F2 mov.l 0x0601F630,r1
    c.r[0] = ld32(0x0601F634u);  // 0601F5F4 mov.l 0x0601F634,r0
    c.r[4] = ld32(c.r[1]); goto L_0601F60A;  // 0601F5F6 bra 0x0601F60A ; mov.l @r1,r4
L_0601F5FA:
    c.r[0] = ld32(0x0601F638u);  // 0601F5FA mov.l 0x0601F638,r0
    c.r[5] = 0x7u;  // 0601F5FC mov #7,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0601F602u; c.r[4] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601F602u) return; }  // 0601F5FE jsr @r0 ; mov #2,r4
    c.r[1] = c.r[0];  // 0601F602 mov r0,r1
    c.r[0] = ld32(0x0601F634u);  // 0601F604 mov.l 0x0601F634,r0
    c.r[5] = c.r[8];  // 0601F606 mov r8,r5
    c.r[4] = c.r[1];  // 0601F608 mov r1,r4
L_0601F60A:
    { const uint32_t x = c.r[0]; c.pr = 0x0601F60Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601F60Eu) return; }  // 0601F60A jsr @r0 ; nop
    st32(c.r[9], c.r[0]); SH2_POLL(c); goto L_0601F448;  // 0601F60E bra 0x0601F448 ; mov.l r0,@r9
L_0601F612:
    c.r[1] = ld32(0x0601F63Cu);  // 0601F612 mov.l 0x0601F63C,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601F614 mov.b @r1,r0
    c.r[0] &= 0xFu;  // 0601F616 and #15,r0
    st8(c.r[1], c.r[0]);  // 0601F618 mov.b r0,@r1
    c.r[0] = ld32(0x0601F640u);  // 0601F61A mov.l 0x0601F640,r0
    c.r[15] = c.r[14];  // 0601F61C mov r14,r15
L_0601F61E:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601F61E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601F620 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0601F622 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601F624 rts ; mov.l @r15+,r8
}

void f_0601F644(SH2Context& c) {
    ran[365] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601F644 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601F646 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0601F648 mov r15,r14
    c.r[1] = ld32(0x0601F65Cu);  // 0601F64A mov.l 0x0601F65C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601F650u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601F650u) return; }  // 0601F64C jsr @r1 ; mov #0,r4
    c.r[15] = c.r[14];  // 0601F650 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601F652 lds.l @r15+,pr
    c.r[0] = ld32(0x0601F660u);  // 0601F654 mov.l 0x0601F660,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601F656 rts ; mov.l @r15+,r14
}

void f_0601F664(SH2Context& c) {
    ran[366] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601F664 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601F666 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0601F668 mov r15,r14
    c.r[1] = ld32(0x0601F680u);  // 0601F66A mov.l 0x0601F680,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601F670u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601F670u) return; }  // 0601F66C jsr @r1 ; mov #0,r4
    c.r[2] = ld32(0x0601F684u);  // 0601F670 mov.l 0x0601F684,r2
    c.r[1] = 0x0u;  // 0601F672 mov #0,r1
    st32(c.r[2], c.r[1]);  // 0601F674 mov.l r1,@r2
    c.r[15] = c.r[14];  // 0601F676 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601F678 lds.l @r15+,pr
    c.r[0] = ld32(0x0601F688u);  // 0601F67A mov.l 0x0601F688,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601F67C rts ; mov.l @r15+,r14
}

void f_0601F68C(SH2Context& c) {
    ran[367] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601F68C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601F68E sts.l pr,@-r15
    c.r[1] = ld32(0x0601F6ACu);  // 0601F690 mov.l 0x0601F6AC,r1
    c.r[1] = ld32(c.r[1]);  // 0601F692 mov.l @r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601F694 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0601F696 extu.b r1,r0
    c.r[0] <<= 2;  // 0601F698 shll2 r0
    c.r[1] = ld32(0x0601F6B0u);  // 0601F69A mov.l 0x0601F6B0,r1
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 0601F69C mov.l @(r0,r1),r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601F6A2u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601F6A2u) return; }  // 0601F69E jsr @r0 ; mov r15,r14
    c.r[15] = c.r[14];  // 0601F6A2 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601F6A4 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601F6A6 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[0] & 0xFFFFu; c.pc = x; return; }  // 0601F6A8 rts ; extu.w r0,r0
}

void f_0601F6B4(SH2Context& c) {
    ran[368] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601F6B4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601F6B6 sts.l pr,@-r15
    c.r[1] = ld32(0x0601F6F0u);  // 0601F6B8 mov.l 0x0601F6F0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601F6BEu; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601F6BEu) return; }  // 0601F6BA jsr @r1 ; mov r15,r14
    c.r[3] = ld32(0x0601F6F4u);  // 0601F6BE mov.l 0x0601F6F4,r3
    c.r[1] = c.r[3];  // 0601F6C0 mov r3,r1
    c.r[1] += 76;  // 0601F6C2 add #76,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601F6C4 mov.b @r1,r1
    c.r[7] = ld32(0x0601F6F8u);  // 0601F6C6 mov.l 0x0601F6F8,r7
    c.r[2] = ld32(c.r[7] + 12);  // 0601F6C8 mov.l @(12,r7),r2
    c.r[1] = c.r[1] & 0xFFu;  // 0601F6CA extu.b r1,r1
    c.t = c.r[2] > c.r[1];  // 0601F6CC cmp/hi r1,r2
    { const bool k = c.t; c.r[3] += 77; if (k) { goto L_0601F6E2; } }  // 0601F6CE bt/s 0x0601F6E2 ; add #77,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0601F6D2 mov.b @r3,r1
    c.r[2] = ld32(c.r[7] + 16);  // 0601F6D4 mov.l @(16,r7),r2
    c.r[1] = c.r[1] & 0xFFu;  // 0601F6D6 extu.b r1,r1
    c.t = c.r[2] > c.r[1];  // 0601F6D8 cmp/hi r1,r2
    if (c.t) { goto L_0601F6E2; }  // 0601F6DA bt 0x0601F6E2
    c.r[1] = ld32(0x0601F6FCu);  // 0601F6DC mov.l 0x0601F6FC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601F6E2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601F6E2u) return; }  // 0601F6DE jsr @r1 ; nop
L_0601F6E2:
    c.r[15] = c.r[14];  // 0601F6E2 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601F6E4 lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601F6ECu);  // 0601F6E6 mov.w 0x0601F6EC,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601F6E8 rts ; mov.l @r15+,r14
}

void f_0601F700(SH2Context& c) {
    ran[369] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601F700 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0601F702 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601F704 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601F706 sts.l pr,@-r15
    c.r[15] -= 76;  // 0601F708 add #-76,r15
    c.r[1] = ld32(0x0601F7BCu);  // 0601F70A mov.l 0x0601F7BC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601F710u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601F710u) return; }  // 0601F70C jsr @r1 ; mov r15,r14
    c.r[9] = 0x0u;  // 0601F710 mov #0,r9
    c.r[8] = 0x0u;  // 0601F712 mov #0,r8
    c.r[1] = ld32(0x0601F7C0u);  // 0601F714 mov.l 0x0601F7C0,r1
    c.r[0] = ld32(0x0601F7C4u);  // 0601F716 mov.l 0x0601F7C4,r0
    c.r[6] = 0x1u;  // 0601F718 mov #1,r6
    c.r[2] = ld32(c.r[1]);  // 0601F71A mov.l @r1,r2
    c.r[4] = c.r[14];  // 0601F71C mov r14,r4
    c.r[1] = c.r[2];  // 0601F71E mov r2,r1
    c.r[1] += 1;  // 0601F720 add #1,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601F722 mov.b @r1,r5
    c.r[2] += 2;  // 0601F724 add #2,r2
    c.r[5] = c.r[5] & 0xFFu;  // 0601F726 extu.b r5,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601F728 mov.b @r2,r1
    c.r[5] <<= 8;  // 0601F72A shll8 r5
    c.r[1] = c.r[1] & 0xFFu;  // 0601F72C extu.b r1,r1
    c.r[5] |= c.r[1];  // 0601F72E or r1,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0601F734u; c.r[5] = (uint32_t)(int32_t)(int16_t)c.r[5]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601F734u) return; }  // 0601F730 jsr @r0 ; exts.w r5,r5
    c.r[2] = c.r[0];  // 0601F734 mov r0,r2
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[2];  // 0601F736 cmp/ge r2,r9
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_0601F754; } }  // 0601F738 bt/s 0x0601F754 ; mov #0,r0
    c.r[1] = ld32(0x0601F7C8u);  // 0601F73C mov.l 0x0601F7C8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601F73E mov.b @r1,r1
    c.r[3] = c.r[1] & 0xFFu;  // 0601F740 extu.b r1,r3
L_0601F742:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 0601F742 mov.b @(r0,r14),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601F744 extu.b r1,r1
    c.t = c.r[3] == c.r[1];  // 0601F746 cmp/eq r1,r3
    { const bool k = !c.t; c.r[0] += 1; if (k) { goto L_0601F750; } }  // 0601F748 bf/s 0x0601F750 ; add #1,r0
    c.r[8] += 1; goto L_0601F754;  // 0601F74C bra 0x0601F754 ; add #1,r8
L_0601F750:
    c.t = (int32_t)c.r[0] >= (int32_t)c.r[2];  // 0601F750 cmp/ge r2,r0
    if (!c.t) { SH2_POLL(c); goto L_0601F742; }  // 0601F752 bf 0x0601F742
L_0601F754:
    c.t = (c.r[8] & c.r[8]) == 0;  // 0601F754 tst r8,r8
    { const bool k = c.t; c.r[6] = 0x1u; if (k) { goto L_0601F7A8; } }  // 0601F756 bt/s 0x0601F7A8 ; mov #1,r6
    c.r[1] = ld32(0x0601F7C0u);  // 0601F75A mov.l 0x0601F7C0,r1
    c.r[0] = ld32(0x0601F7C4u);  // 0601F75C mov.l 0x0601F7C4,r0
    c.r[2] = ld32(c.r[1]);  // 0601F75E mov.l @r1,r2
    c.r[4] = c.r[14];  // 0601F760 mov r14,r4
    c.r[1] = c.r[2];  // 0601F762 mov r2,r1
    c.r[1] += 3;  // 0601F764 add #3,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601F766 mov.b @r1,r5
    c.r[2] += 4;  // 0601F768 add #4,r2
    c.r[5] = c.r[5] & 0xFFu;  // 0601F76A extu.b r5,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601F76C mov.b @r2,r1
    c.r[5] <<= 8;  // 0601F76E shll8 r5
    c.r[1] = c.r[1] & 0xFFu;  // 0601F770 extu.b r1,r1
    c.r[5] |= c.r[1];  // 0601F772 or r1,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0601F778u; c.r[5] = (uint32_t)(int32_t)(int16_t)c.r[5]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601F778u) return; }  // 0601F774 jsr @r0 ; exts.w r5,r5
    c.r[2] = c.r[0];  // 0601F778 mov r0,r2
    c.r[0] = 0x0u;  // 0601F77A mov #0,r0
    c.t = (int32_t)c.r[0] >= (int32_t)c.r[2];  // 0601F77C cmp/ge r2,r0
    { const bool k = c.t; c.macl = c.r[8] * c.r[9]; if (k) { goto L_0601F79C; } }  // 0601F77E bt/s 0x0601F79C ; mul.l r9,r8
    c.r[1] = ld32(0x0601F7CCu);  // 0601F782 mov.l 0x0601F7CC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601F784 mov.b @r1,r1
    c.r[3] = c.r[1] & 0xFFu;  // 0601F786 extu.b r1,r3
L_0601F788:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 0601F788 mov.b @(r0,r14),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601F78A extu.b r1,r1
    c.t = c.r[3] == c.r[1];  // 0601F78C cmp/eq r1,r3
    { const bool k = !c.t; c.r[0] += 1; if (k) { goto L_0601F796; } }  // 0601F78E bf/s 0x0601F796 ; add #1,r0
    c.r[9] += 1; goto L_0601F79A;  // 0601F792 bra 0x0601F79A ; add #1,r9
L_0601F796:
    c.t = (int32_t)c.r[0] >= (int32_t)c.r[2];  // 0601F796 cmp/ge r2,r0
    if (!c.t) { SH2_POLL(c); goto L_0601F788; }  // 0601F798 bf 0x0601F788
L_0601F79A:
    c.macl = c.r[8] * c.r[9];  // 0601F79A mul.l r9,r8
L_0601F79C:
    c.r[1] = c.macl;  // 0601F79C sts macl,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601F79E tst r1,r1
    if (c.t) { goto L_0601F7A8; }  // 0601F7A0 bt 0x0601F7A8
    c.r[1] = ld32(0x0601F7D0u);  // 0601F7A2 mov.l 0x0601F7D0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601F7A8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601F7A8u) return; }  // 0601F7A4 jsr @r1 ; nop
L_0601F7A8:
    c.r[14] += 76;  // 0601F7A8 add #76,r14
    c.r[15] = c.r[14];  // 0601F7AA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601F7AC lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601F7AE mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0601F7B0 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601F7B8u);  // 0601F7B2 mov.w 0x0601F7B8,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601F7B4 rts ; mov.l @r15+,r8
}

void f_0601F7D4(SH2Context& c) {
    ran[370] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601F7D4 mov.l r14,@-r15
    c.r[3] = ld32(0x0601F804u);  // 0601F7D6 mov.l 0x0601F804,r3
    c.r[1] = 0x0u;  // 0601F7D8 mov #0,r1
    st32(c.r[3] + 20, c.r[1]);  // 0601F7DA mov.l r1,@(20,r3)
    c.r[2] = ld32(0x0601F808u);  // 0601F7DC mov.l 0x0601F808,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601F7DE mov.b @r2,r1
    c.r[0] = c.r[1];  // 0601F7E0 mov r1,r0
    c.r[0] >>= 2;  // 0601F7E2 shlr2 r0
    c.r[0] >>= 2;  // 0601F7E4 shlr2 r0
    c.r[0] >>= 2;  // 0601F7E6 shlr2 r0
    c.r[0] &= 0x1u;  // 0601F7E8 and #1,r0
    c.t = c.r[0] == 0x1u;  // 0601F7EA cmp/eq #1,r0
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0601F7F8; } }  // 0601F7EC bf/s 0x0601F7F8 ; mov r15,r14
    c.r[2] += 2;  // 0601F7F0 add #2,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0601F7F2 mov.w @r2,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0601F7F4 extu.w r1,r1
    st32(c.r[3] + 20, c.r[1]);  // 0601F7F6 mov.l r1,@(20,r3)
L_0601F7F8:
    c.r[15] = c.r[14];  // 0601F7F8 mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601F800u);  // 0601F7FA mov.w 0x0601F800,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601F7FC rts ; mov.l @r15+,r14
}

void f_0601F80C(SH2Context& c) {
    ran[371] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601F80C mov.l r14,@-r15
    c.r[3] = ld32(0x0601F83Cu);  // 0601F80E mov.l 0x0601F83C,r3
    c.r[1] = 0x0u;  // 0601F810 mov #0,r1
    st32(c.r[3] + 20, c.r[1]);  // 0601F812 mov.l r1,@(20,r3)
    c.r[2] = ld32(0x0601F840u);  // 0601F814 mov.l 0x0601F840,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601F816 mov.b @r2,r1
    c.r[0] = c.r[1];  // 0601F818 mov r1,r0
    c.r[0] >>= 2;  // 0601F81A shlr2 r0
    c.r[0] >>= 2;  // 0601F81C shlr2 r0
    c.r[0] >>= 2;  // 0601F81E shlr2 r0
    c.r[0] &= 0x1u;  // 0601F820 and #1,r0
    c.t = c.r[0] == 0x1u;  // 0601F822 cmp/eq #1,r0
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0601F830; } }  // 0601F824 bf/s 0x0601F830 ; mov r15,r14
    c.r[2] += 2;  // 0601F828 add #2,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0601F82A mov.w @r2,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0601F82C extu.w r1,r1
    st32(c.r[3] + 20, c.r[1]);  // 0601F82E mov.l r1,@(20,r3)
L_0601F830:
    c.r[15] = c.r[14];  // 0601F830 mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601F838u);  // 0601F832 mov.w 0x0601F838,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601F834 rts ; mov.l @r15+,r14
}

void f_0601F844(SH2Context& c) {
    ran[372] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601F844 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0601F846 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0601F848 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601F84A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601F84C sts.l pr,@-r15
    c.r[1] = ld32(0x0601F95Cu);  // 0601F84E mov.l 0x0601F95C,r1
    c.r[1] = ld32(c.r[1]);  // 0601F850 mov.l @r1,r1
    c.r[1] += 1;  // 0601F852 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601F854 mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0601F856 extu.b r1,r2
    c.r[1] = 0x4u;  // 0601F858 mov #4,r1
    c.t = c.r[2] > c.r[1];  // 0601F85A cmp/hi r1,r2
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0601F942; } }  // 0601F85C bt/s 0x0601F942 ; mov r15,r14
    c.r[1] = c.r[2];  // 0601F860 mov r2,r1
    c.r[1] += c.r[1];  // 0601F862 add r1,r1
    c.r[0] = 0x0601F870u;  // 0601F864 mova 0x0601F870,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0601F866 mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 0601F868 add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x0601F87Au: goto L_0601F87A; case 0x0601F8F4u: goto L_0601F8F4; case 0x0601F932u: goto L_0601F932; case 0x0601F942u: goto L_0601F942; default: sh2_call(c, x); return; } }  // 0601F86A jmp @r0 ; nop
L_0601F87A:
    c.r[1] = ld32(0x0601F960u);  // 0601F87A mov.l 0x0601F960,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601F880u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601F880u) return; }  // 0601F87C jsr @r1 ; nop
    c.r[1] = ld32(0x0601F95Cu);  // 0601F880 mov.l 0x0601F95C,r1
    c.r[10] = ld32(0x0601F964u);  // 0601F882 mov.l 0x0601F964,r10
    c.r[1] = ld32(c.r[1]);  // 0601F884 mov.l @r1,r1
    c.r[9] = ld32(0x0601F968u);  // 0601F886 mov.l 0x0601F968,r9
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0601F888 mov.b @r10,r5
    c.r[0] = ld32(0x0601F96Cu);  // 0601F88A mov.l 0x0601F96C,r0
    c.r[4] = ld32(c.r[9]);  // 0601F88C mov.l @r9,r4
    c.r[1] += 2;  // 0601F88E add #2,r1
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601F890 mov.b @r1,r8
    c.r[5] = c.r[5] & 0xFFu;  // 0601F892 extu.b r5,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0601F898u; c.r[8] = c.r[8] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601F898u) return; }  // 0601F894 jsr @r0 ; extu.b r8,r8
    c.r[1] = c.r[0];  // 0601F898 mov r0,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0601F89A extu.b r1,r2
    c.r[2] <<= 2;  // 0601F89C shll2 r2
    c.r[2] <<= 2;  // 0601F89E shll2 r2
    c.r[3] = c.r[2];  // 0601F8A0 mov r2,r3
    c.r[0] = c.r[2];  // 0601F8A2 mov r2,r0
    c.r[7] = c.r[8];  // 0601F8A4 mov r8,r7
    c.r[7] += c.r[7];  // 0601F8A6 add r7,r7
    c.r[1] = ld32(c.r[9]);  // 0601F8A8 mov.l @r9,r1
    c.r[8] = ld32(0x0601F970u);  // 0601F8AA mov.l 0x0601F970,r8
    c.r[3] += c.r[1];  // 0601F8AC add r1,r3
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601F8AE mov.b @(r0,r1),r4
    c.r[3] += 1;  // 0601F8B0 add #1,r3
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0601F8B2 mov.b @r3,r5
    c.r[4] = c.r[4] & 0xFFu;  // 0601F8B4 extu.b r4,r4
    c.r[2] = ld32(0x0601F974u);  // 0601F8B6 mov.l 0x0601F974,r2
    c.r[0] = c.r[2];  // 0601F8B8 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0601F8BA mov.b @(r0,r7),r1
    c.r[5] = c.r[5] & 0xFFu;  // 0601F8BC extu.b r5,r5
    c.r[4] -= c.r[1];  // 0601F8BE sub r1,r4
    c.r[7] += c.r[2];  // 0601F8C0 add r2,r7
    c.r[7] += 1;  // 0601F8C2 add #1,r7
    c.r[4] = c.r[4] & 0xFFu;  // 0601F8C4 extu.b r4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0601F8C6 mov.b @r7,r1
    c.r[0] = ld32(0x0601F978u);  // 0601F8C8 mov.l 0x0601F978,r0
    c.r[5] -= c.r[1];  // 0601F8CA sub r1,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0601F8CC mov.b @r10,r1
    c.r[5] = c.r[5] & 0xFFu;  // 0601F8CE extu.b r5,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0601F8D4u; st8(c.r[8], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601F8D4u) return; }  // 0601F8D0 jsr @r0 ; mov.b r1,@r8
    c.r[1] = c.r[0];  // 0601F8D4 mov r0,r1
    c.r[8] += 1;  // 0601F8D6 add #1,r8
    st8(c.r[8], c.r[1]);  // 0601F8D8 mov.b r1,@r8
    c.r[2] = c.r[1] & 0xFFu;  // 0601F8DA extu.b r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601F952u);  // 0601F8DC mov.w 0x0601F952,r1
    c.t = c.r[2] == c.r[1];  // 0601F8DE cmp/eq r1,r2
    if (!c.t) { goto L_0601F8EA; }  // 0601F8E0 bf 0x0601F8EA
    c.r[15] = c.r[14];  // 0601F8E2 mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601F954u);  // 0601F8E4 mov.w 0x0601F954,r0
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; } goto L_0601F948;  // 0601F8E6 bra 0x0601F948 ; lds.l @r15+,pr
L_0601F8EA:
    c.r[1] = ld32(0x0601F97Cu);  // 0601F8EA mov.l 0x0601F97C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601F8F0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601F8F0u) return; }  // 0601F8EC jsr @r1 ; nop
    goto L_0601F942;  // 0601F8F0 bra 0x0601F942 ; nop
L_0601F8F4:
    c.r[3] = ld32(0x0601F980u);  // 0601F8F4 mov.l 0x0601F980,r3
    c.r[1] = c.r[3];  // 0601F8F6 mov r3,r1
    c.r[1] += 37;  // 0601F8F8 add #37,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601F8FA mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601F8FC extu.b r1,r1
    c.r[1] >>= 2;  // 0601F8FE shlr2 r1
    c.r[1] >>= 2;  // 0601F900 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0601F902 shlr r1
    c.r[1] >>= 2;  // 0601F904 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601F906 tst r1,r1
    if (!c.t) { goto L_0601F91E; }  // 0601F908 bf 0x0601F91E
    c.r[1] = ld32(0x0601F95Cu);  // 0601F90A mov.l 0x0601F95C,r1
    c.r[1] = ld32(c.r[1]);  // 0601F90C mov.l @r1,r1
    c.r[1] += 2;  // 0601F90E add #2,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601F910 mov.b @r1,r0
    c.r[2] = ld32(0x0601F984u);  // 0601F912 mov.l 0x0601F984,r2
    c.r[0] &= 0x3u;  // 0601F914 and #3,r0
    c.r[1] = ld32(c.r[3] + 8);  // 0601F916 mov.l @(8,r3),r1
    c.r[0] <<= 2;  // 0601F918 shll2 r0
    st32(c.r[0] + c.r[2], c.r[1]); goto L_0601F942;  // 0601F91A bra 0x0601F942 ; mov.l r1,@(r0,r2)
L_0601F91E:
    c.r[1] = ld32(0x0601F95Cu);  // 0601F91E mov.l 0x0601F95C,r1
    c.r[1] = ld32(c.r[1]);  // 0601F920 mov.l @r1,r1
    c.r[1] += 2;  // 0601F922 add #2,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601F924 mov.b @r1,r0
    c.r[2] = ld32(0x0601F984u);  // 0601F926 mov.l 0x0601F984,r2
    c.r[0] &= 0x3u;  // 0601F928 and #3,r0
    c.r[0] <<= 2;  // 0601F92A shll2 r0
    c.r[1] = 0x0u;  // 0601F92C mov #0,r1
    st32(c.r[0] + c.r[2], c.r[1]); goto L_0601F942;  // 0601F92E bra 0x0601F942 ; mov.l r1,@(r0,r2)
L_0601F932:
    c.r[2] = ld32(0x0601F984u);  // 0601F932 mov.l 0x0601F984,r2
    c.r[1] = 0x0u;  // 0601F934 mov #0,r1
    st32(c.r[2] + 12, c.r[1]);  // 0601F936 mov.l r1,@(12,r2)
    st32(c.r[2] + 8, c.r[1]);  // 0601F938 mov.l r1,@(8,r2)
    st32(c.r[2] + 4, c.r[1]);  // 0601F93A mov.l r1,@(4,r2)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601F956u);  // 0601F93C mov.w 0x0601F956,r0
    st32(c.r[2], c.r[1]); goto L_0601F944;  // 0601F93E bra 0x0601F944 ; mov.l r1,@r2
L_0601F942:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601F958u);  // 0601F942 mov.w 0x0601F958,r0
L_0601F944:
    c.r[15] = c.r[14];  // 0601F944 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601F946 lds.l @r15+,pr
L_0601F948:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0601F948 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0601F94A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0601F94C mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601F94E rts ; mov.l @r15+,r8
}

void f_0601F988(SH2Context& c) {
    ran[373] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601F988 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601F98A sts.l pr,@-r15
    c.r[1] = ld32(0x0601F9C8u);  // 0601F98C mov.l 0x0601F9C8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601F992u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601F992u) return; }  // 0601F98E jsr @r1 ; mov r15,r14
    c.r[1] = ld32(0x0601F9CCu);  // 0601F992 mov.l 0x0601F9CC,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601F994 mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0601F996 extu.b r2,r2
    c.r[1] = ld32(0x0601F9D0u);  // 0601F998 mov.l 0x0601F9D0,r1
    c.r[1] = ld32(c.r[1]);  // 0601F99A mov.l @r1,r1
    c.r[2] <<= 2;  // 0601F99C shll2 r2
    c.r[2] <<= 2;  // 0601F99E shll2 r2
    c.r[2] += c.r[1];  // 0601F9A0 add r1,r2
    c.r[2] += 4;  // 0601F9A2 add #4,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601F9A4 mov.b @r2,r1
    c.r[0] = c.r[1];  // 0601F9A6 mov r1,r0
    c.r[0] >>= 2;  // 0601F9A8 shlr2 r0
    c.r[0] >>= 2;  // 0601F9AA shlr2 r0
    c.r[0] >>= 2;  // 0601F9AC shlr2 r0
    c.r[0] &= 0x1u;  // 0601F9AE and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601F9B0 tst r0,r0
    if (c.t) { goto L_0601F9BA; }  // 0601F9B2 bt 0x0601F9BA
    c.r[1] = ld32(0x0601F9D4u);  // 0601F9B4 mov.l 0x0601F9D4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601F9BAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601F9BAu) return; }  // 0601F9B6 jsr @r1 ; nop
L_0601F9BA:
    c.r[15] = c.r[14];  // 0601F9BA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601F9BC lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601F9C4u);  // 0601F9BE mov.w 0x0601F9C4,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601F9C0 rts ; mov.l @r15+,r14
}

void f_0601F9D8(SH2Context& c) {
    ran[374] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601F9D8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601F9DA sts.l pr,@-r15
    c.r[1] = ld32(0x0601FA10u);  // 0601F9DC mov.l 0x0601FA10,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601F9E2u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601F9E2u) return; }  // 0601F9DE jsr @r1 ; mov r15,r14
    c.r[1] = ld32(0x0601FA14u);  // 0601F9E2 mov.l 0x0601FA14,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601F9E4 mov.b @r1,r4
    c.r[0] = ld32(0x0601FA18u);  // 0601F9E6 mov.l 0x0601FA18,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0601F9ECu; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601F9ECu) return; }  // 0601F9E8 jsr @r0 ; extu.b r4,r4
    c.r[1] = ld32(0x0601FA1Cu);  // 0601F9EC mov.l 0x0601FA1C,r1
    st8(c.r[1], c.r[0]);  // 0601F9EE mov.b r0,@r1
    c.r[2] = c.r[0] & 0xFFu;  // 0601F9F0 extu.b r0,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601FA0Cu);  // 0601F9F2 mov.w 0x0601FA0C,r1
    c.t = c.r[2] == c.r[1];  // 0601F9F4 cmp/eq r1,r2
    if (c.t) { goto L_0601FA02; }  // 0601F9F6 bt 0x0601FA02
    c.r[1] = ld32(0x0601FA20u);  // 0601F9F8 mov.l 0x0601FA20,r1
    st8(c.r[1], c.r[0]);  // 0601F9FA mov.b r0,@r1
    c.r[1] = ld32(0x0601FA24u);  // 0601F9FC mov.l 0x0601FA24,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601FA02u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601FA02u) return; }  // 0601F9FE jsr @r1 ; nop
L_0601FA02:
    c.r[15] = c.r[14];  // 0601FA02 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0601FA04 lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601FA0Eu);  // 0601FA06 mov.w 0x0601FA0E,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601FA08 rts ; mov.l @r15+,r14
}

void f_0601FA28(SH2Context& c) {
    ran[375] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601FA28 mov.l r14,@-r15
    c.r[1] = ld32(0x0601FA54u);  // 0601FA2A mov.l 0x0601FA54,r1
    c.r[1] = ld32(c.r[1]);  // 0601FA2C mov.l @r1,r1
    c.r[1] += 1;  // 0601FA2E add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601FA30 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601FA32 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601FA34 tst r1,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0601FA42; } }  // 0601FA36 bt/s 0x0601FA42 ; mov r15,r14
    c.r[2] = ld32(0x0601FA58u);  // 0601FA3A mov.l 0x0601FA58,r2
    c.r[1] = ld32(0x0601FA5Cu);  // 0601FA3C mov.l 0x0601FA5C,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[2]); goto L_0601FA48;  // 0601FA3E bra 0x0601FA48 ; mov.w @r2,r2
L_0601FA42:
    c.r[2] = ld32(0x0601FA5Cu);  // 0601FA42 mov.l 0x0601FA5C,r2
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0601FA44 mov.w @r2,r2
    c.r[1] = ld32(0x0601FA58u);  // 0601FA46 mov.l 0x0601FA58,r1
L_0601FA48:
    st16(c.r[1], c.r[2]);  // 0601FA48 mov.w r2,@r1
    c.r[15] = c.r[14];  // 0601FA4A mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x0601FA52u);  // 0601FA4C mov.w 0x0601FA52,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0601FA4E rts ; mov.l @r15+,r14
}

void f_0601FA60(SH2Context& c) {
    ran[376] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0601FA60 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0601FA62 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0601FA64 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0601FA66 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0601FA68 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0601FA6A mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0601FA6C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0601FA6E sts.l pr,@-r15
    c.r[15] -= 76;  // 0601FA70 add #-76,r15
    c.r[1] = ld32(0x0601FBF8u);  // 0601FA72 mov.l 0x0601FBF8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601FA78u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601FA78u) return; }  // 0601FA74 jsr @r1 ; mov r15,r14
    c.r[0] = 0xFFFFFFFFu;  // 0601FA78 mov #-1,r0
    st32(c.r[14] + 32, c.r[0]);  // 0601FA7A mov.l r0,@(32,r14)
    c.r[6] = ld32(0x0601FBFCu);  // 0601FA7C mov.l 0x0601FBFC,r6
    c.r[7] = c.r[6];  // 0601FA7E mov r6,r7
    c.r[7] += 1;  // 0601FA80 add #1,r7
    c.r[3] = ld32(0x0601FC00u);  // 0601FA82 mov.l 0x0601FC00,r3
    c.r[2] = c.r[3];  // 0601FA84 mov r3,r2
    c.r[2] += 24;  // 0601FA86 add #24,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601FBEEu);  // 0601FA88 mov.w 0x0601FBEE,r1
    st16(c.r[2], c.r[1]);  // 0601FA8A mov.w r1,@r2
    c.r[12] = ld32(c.r[14] + 32);  // 0601FA8C mov.l @(32,r14),r12
    c.r[3] += 33;  // 0601FA8E add #33,r3
    c.r[0] = ld32(c.r[14] + 32);  // 0601FA90 mov.l @(32,r14),r0
    st32(c.r[14] + 28, c.r[12]);  // 0601FA92 mov.l r12,@(28,r14)
    c.r[12] = ld32(c.r[14] + 32);  // 0601FA94 mov.l @(32,r14),r12
    st32(c.r[14] + 24, c.r[0]);  // 0601FA96 mov.l r0,@(24,r14)
    c.r[0] = ld32(c.r[14] + 32);  // 0601FA98 mov.l @(32,r14),r0
    st32(c.r[14] + 20, c.r[12]);  // 0601FA9A mov.l r12,@(20,r14)
    c.r[12] = ld32(c.r[14] + 32);  // 0601FA9C mov.l @(32,r14),r12
    st32(c.r[14] + 16, c.r[0]);  // 0601FA9E mov.l r0,@(16,r14)
    c.r[0] = ld32(c.r[14] + 32);  // 0601FAA0 mov.l @(32,r14),r0
    st32(c.r[14] + 12, c.r[12]);  // 0601FAA2 mov.l r12,@(12,r14)
    c.r[12] = ld32(c.r[14] + 32);  // 0601FAA4 mov.l @(32,r14),r12
    st32(c.r[14] + 8, c.r[0]);  // 0601FAA6 mov.l r0,@(8,r14)
    st32(c.r[14] + 4, c.r[12]);  // 0601FAA8 mov.l r12,@(4,r14)
    st8(c.r[7], c.r[1]);  // 0601FAAA mov.b r1,@r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0601FAAC mov.b @r3,r1
    c.r[8] = (uint32_t)(int16_t)ld16(0x0601FBEEu);  // 0601FAAE mov.w 0x0601FBEE,r8
    st8(c.r[6], c.r[1]);  // 0601FAB0 mov.b r1,@r6
    c.r[1] = c.r[1] & 0xFFu;  // 0601FAB2 extu.b r1,r1
    st32(c.r[14] + 36, c.r[1]);  // 0601FAB4 mov.l r1,@(36,r14)
    c.r[10] = ld32(c.r[14] + 36);  // 0601FAB6 mov.l @(36,r14),r10
    c.r[9] = ld32(0x0601FC04u);  // 0601FAB8 mov.l 0x0601FC04,r9
    c.r[1] = ld32(c.r[9]);  // 0601FABA mov.l @r9,r1
    c.r[10] <<= 2;  // 0601FABC shll2 r10
    c.r[10] <<= 2;  // 0601FABE shll2 r10
    c.r[1] += c.r[10];  // 0601FAC0 add r10,r1
    c.r[1] += 2;  // 0601FAC2 add #2,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601FAC4 mov.b @r1,r5
    c.r[6] = c.r[8];  // 0601FAC6 mov r8,r6
    c.r[1] = ld32(0x0601FC08u);  // 0601FAC8 mov.l 0x0601FC08,r1
    c.r[4] = ld32(c.r[1]);  // 0601FACA mov.l @r1,r4
    c.r[1] = ld32(0x0601FC0Cu);  // 0601FACC mov.l 0x0601FC0C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601FAD2u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601FAD2u) return; }  // 0601FACE jsr @r1 ; extu.b r5,r5
    st32(c.r[14] + 60, c.r[8]);  // 0601FAD2 mov.l r8,@(60,r14)
    c.r[9] = ld32(c.r[9]);  // 0601FAD4 mov.l @r9,r9
    c.r[10] += c.r[9];  // 0601FAD6 add r9,r10
    c.r[10] += 9;  // 0601FAD8 add #9,r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0601FADA mov.b @r10,r1
    c.r[4] = c.r[1] & 0xFFu;  // 0601FADC extu.b r1,r4
    c.t = c.r[4] == c.r[8];  // 0601FADE cmp/eq r8,r4
    { const bool k = c.t; c.r[2] = c.r[4]; if (k) { goto L_0601FB22; } }  // 0601FAE0 bt/s 0x0601FB22 ; mov r4,r2
    c.r[2] <<= 2;  // 0601FAE4 shll2 r2
    c.r[2] <<= 2;  // 0601FAE6 shll2 r2
    c.r[2] += c.r[9];  // 0601FAE8 add r9,r2
    c.r[1] = c.r[2];  // 0601FAEA mov r2,r1
    c.r[1] += 4;  // 0601FAEC add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601FAEE mov.b @r1,r1
    c.r[0] = c.r[1];  // 0601FAF0 mov r1,r0
    c.r[0] >>= 2;  // 0601FAF2 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0601FAF4 shlr r0
    c.r[0] >>= 2;  // 0601FAF6 shlr2 r0
    c.r[0] &= 0x1u;  // 0601FAF8 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601FAFA tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[4]; if (k) { goto L_0601FB08; } }  // 0601FAFC bt/s 0x0601FB08 ; mov r4,r1
    c.r[2] += 6;  // 0601FB00 add #6,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601FB02 mov.b @r2,r1
    c.r[4] = c.r[1] & 0xFFu;  // 0601FB04 extu.b r1,r4
    c.r[1] = c.r[4];  // 0601FB06 mov r4,r1
L_0601FB08:
    c.r[1] <<= 2;  // 0601FB08 shll2 r1
    c.r[1] <<= 2;  // 0601FB0A shll2 r1
    c.r[1] += c.r[9];  // 0601FB0C add r9,r1
    c.r[1] += 4;  // 0601FB0E add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601FB10 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0601FB12 mov r1,r0
    c.r[0] >>= 2;  // 0601FB14 shlr2 r0
    c.r[0] >>= 2;  // 0601FB16 shlr2 r0
    c.r[0] >>= 2;  // 0601FB18 shlr2 r0
    c.r[0] &= 0x1u;  // 0601FB1A and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601FB1C tst r0,r0
    if (c.t) { goto L_0601FB22; }  // 0601FB1E bt 0x0601FB22
    c.r[4] = ld32(c.r[14] + 60);  // 0601FB20 mov.l @(60,r14),r4
L_0601FB22:
    c.r[3] = (uint32_t)(int16_t)ld16(0x0601FBEEu);  // 0601FB22 mov.w 0x0601FBEE,r3
    c.t = c.r[4] == c.r[3];  // 0601FB24 cmp/eq r3,r4
    if (!c.t) { goto L_0601FB2C; }  // 0601FB26 bf 0x0601FB2C
    goto L_0601FC46;  // 0601FB28 bra 0x0601FC46 ; nop
L_0601FB2C:
    c.r[0] = 0x0u;  // 0601FB2C mov #0,r0
    st32(c.r[14], c.r[0]);  // 0601FB2E mov.l r0,@r14
    c.r[1] = ld32(0x0601FC10u);  // 0601FB30 mov.l 0x0601FC10,r1
    c.r[2] = ld32(c.r[1]);  // 0601FB32 mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601FBF0u);  // 0601FB34 mov.w 0x0601FBF0,r1
    c.r[0] = c.r[2];  // 0601FB36 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601FB38 mov.b @(r0,r1),r1
    c.r[12] = ld32(c.r[14]);  // 0601FB3A mov.l @r14,r12
    c.r[1] = c.r[1] & 0xFFu;  // 0601FB3C extu.b r1,r1
    c.t = (int32_t)c.r[12] >= (int32_t)c.r[1];  // 0601FB3E cmp/ge r1,r12
    if (!c.t) { goto L_0601FB46; }  // 0601FB40 bf 0x0601FB46
    goto L_0601FC46;  // 0601FB42 bra 0x0601FC46 ; nop
L_0601FB46:
    c.r[10] = c.r[2];  // 0601FB46 mov r2,r10
    c.r[1] = ld32(0x0601FC08u);  // 0601FB48 mov.l 0x0601FC08,r1
    c.r[1] = ld32(c.r[1]);  // 0601FB4A mov.l @r1,r1
    c.r[0] = 0x48u;  // 0601FB4C mov #72,r0
    c.r[0] += c.r[14];  // 0601FB4E add r14,r0
    c.r[13] = ld32(0x0601FC14u);  // 0601FB50 mov.l 0x0601FC14,r13
    c.r[11] = (uint32_t)(int16_t)ld16(0x0601FBF2u);  // 0601FB52 mov.w 0x0601FBF2,r11
    c.r[5] = 0x0u;  // 0601FB54 mov #0,r5
    st32(c.r[0], c.r[1]);  // 0601FB56 mov.l r1,@r0
L_0601FB58:
    c.r[0] = c.r[5];  // 0601FB58 mov r5,r0
    c.r[2] = 0x7Fu;  // 0601FB5A mov #127,r2
    c.r[12] = 0x48u;  // 0601FB5C mov #72,r12
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 0601FB5E mov.b @(r0,r10),r1
    c.r[12] += c.r[14];  // 0601FB60 add r14,r12
    c.r[12] = ld32(c.r[12]);  // 0601FB62 mov.l @r12,r12
    c.r[2] &= c.r[1];  // 0601FB64 and r1,r2
    c.r[2] <<= 8;  // 0601FB66 shll8 r2
    c.r[1] = c.r[10];  // 0601FB68 mov r10,r1
    c.r[1] += c.r[5];  // 0601FB6A add r5,r1
    c.r[1] += 1;  // 0601FB6C add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601FB6E mov.b @r1,r1
    c.r[0] = 0x1u;  // 0601FB70 mov #1,r0
    c.r[8] = c.r[1] & 0xFFu;  // 0601FB72 extu.b r1,r8
    c.r[8] |= c.r[2];  // 0601FB74 or r2,r8
    c.r[2] = c.r[8];  // 0601FB76 mov r8,r2
    c.r[2] <<= 2;  // 0601FB78 shll2 r2
    c.r[2] += c.r[8];  // 0601FB7A add r8,r2
    c.r[2] <<= 2;  // 0601FB7C shll2 r2
    c.r[2] += c.r[12];  // 0601FB7E add r12,r2
    c.r[1] = c.r[2];  // 0601FB80 mov r2,r1
    c.r[1] += 50;  // 0601FB82 add #50,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601FB84 mov.b @r1,r1
    c.r[2] += 51;  // 0601FB86 add #51,r2
    c.r[6] = c.r[1] & 0xFFu;  // 0601FB88 extu.b r1,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601FB8A mov.b @r2,r1
    c.r[6] >>= 2;  // 0601FB8C shlr2 r6
    c.r[6] >>= 2;  // 0601FB8E shlr2 r6
    c.r[6] >>= 2;  // 0601FB90 shlr2 r6
    c.r[1] >>= 2;  // 0601FB92 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0601FB94 shlr r1
    c.r[1] &= c.r[0];  // 0601FB96 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601FB98 tst r1,r1
    { const bool k = !c.t; c.r[0] = ld32(c.r[14]); if (k) { goto L_0601FC2E; } }  // 0601FB9A bf/s 0x0601FC2E ; mov.l @r14,r0
    c.r[0] = c.r[6];  // 0601FB9E mov r6,r0
    c.t = c.r[0] == 0x2u;  // 0601FBA0 cmp/eq #2,r0
    { const bool k = !c.t; c.macl = c.r[8] * c.r[11]; if (k) { goto L_0601FBB6; } }  // 0601FBA2 bf/s 0x0601FBB6 ; mul.l r11,r8
    c.r[1] = ld32(0x0601FC18u);  // 0601FBA6 mov.l 0x0601FC18,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601FBA8 mov.b @r1,r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x0601FBEEu);  // 0601FBAA mov.w 0x0601FBEE,r12
    c.r[1] = c.r[1] & 0xFFu;  // 0601FBAC extu.b r1,r1
    c.t = c.r[1] == c.r[12];  // 0601FBAE cmp/eq r12,r1
    { const bool k = c.t; c.r[0] = ld32(c.r[14]); if (k) { goto L_0601FC2E; } }  // 0601FBB0 bt/s 0x0601FC2E ; mov.l @r14,r0
    c.macl = c.r[8] * c.r[11];  // 0601FBB4 mul.l r11,r8
L_0601FBB6:
    c.r[2] = (uint32_t)(int16_t)ld16(0x0601FBF4u);  // 0601FBB6 mov.w 0x0601FBF4,r2
    c.r[3] = ld32(c.r[13]);  // 0601FBB8 mov.l @r13,r3
    c.r[0] = c.macl;  // 0601FBBA sts macl,r0
    c.r[0] += c.r[3];  // 0601FBBC add r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0601FBBE mov.b @(r0,r2),r1
    c.r[9] = 0x0u;  // 0601FBC0 mov #0,r9
    c.r[1] = c.r[1] & 0xFFu;  // 0601FBC2 extu.b r1,r1
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[1];  // 0601FBC4 cmp/ge r1,r9
    { const bool k = c.t; c.r[0] = ld32(c.r[14]); if (k) { goto L_0601FC2E; } }  // 0601FBC6 bt/s 0x0601FC2E ; mov.l @r14,r0
    c.r[6] = c.r[3];  // 0601FBCA mov r3,r6
    c.r[0] = 0x44u;  // 0601FBCC mov #68,r0
    st32(c.r[0] + c.r[14], c.r[2]);  // 0601FBCE mov.l r2,@(r0,r14)
    c.r[7] = 0x0u;  // 0601FBD0 mov #0,r7
L_0601FBD2:
    c.macl = c.r[8] * c.r[11];  // 0601FBD2 mul.l r11,r8
    c.r[3] = c.macl;  // 0601FBD4 sts macl,r3
    c.r[3] += c.r[6];  // 0601FBD6 add r6,r3
    c.r[1] = c.r[3];  // 0601FBD8 mov r3,r1
    c.r[1] += c.r[7];  // 0601FBDA add r7,r1
    c.r[1] += 4;  // 0601FBDC add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601FBDE mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0601FBE0 extu.b r1,r2
    c.t = c.r[4] == c.r[2];  // 0601FBE2 cmp/eq r2,r4
    { const bool k = !c.t; c.r[12] = 0x44u; if (k) { goto L_0601FC1C; } }  // 0601FBE4 bf/s 0x0601FC1C ; mov #68,r12
    c.r[2] = c.r[2] & 0xFFu;  // 0601FBE8 extu.b r2,r2
    st32(c.r[14] + 60, c.r[2]); goto L_0601FC2C;  // 0601FBEA bra 0x0601FC2C ; mov.l r2,@(60,r14)
L_0601FC1C:
    c.r[12] += c.r[14];  // 0601FC1C add r14,r12
    c.r[0] = ld32(c.r[12]);  // 0601FC1E mov.l @r12,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0601FC20 mov.b @(r0,r3),r1
    c.r[9] += 1;  // 0601FC22 add #1,r9
    c.r[1] = c.r[1] & 0xFFu;  // 0601FC24 extu.b r1,r1
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[1];  // 0601FC26 cmp/ge r1,r9
    { const bool k = !c.t; c.r[7] += 8; if (k) { SH2_POLL(c); goto L_0601FBD2; } }  // 0601FC28 bf/s 0x0601FBD2 ; add #8,r7
L_0601FC2C:
    c.r[0] = ld32(c.r[14]);  // 0601FC2C mov.l @r14,r0
L_0601FC2E:
    c.r[1] = ld32(0x0601FC7Cu);  // 0601FC2E mov.l 0x0601FC7C,r1
    c.r[0] += 1;  // 0601FC30 add #1,r0
    st32(c.r[14], c.r[0]);  // 0601FC32 mov.l r0,@r14
    c.r[1] = ld32(c.r[1]);  // 0601FC34 mov.l @r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0601FC78u);  // 0601FC36 mov.w 0x0601FC78,r2
    c.r[0] = c.r[1];  // 0601FC38 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0601FC3A mov.b @(r0,r2),r1
    c.r[12] = ld32(c.r[14]);  // 0601FC3C mov.l @r14,r12
    c.r[1] = c.r[1] & 0xFFu;  // 0601FC3E extu.b r1,r1
    c.t = (int32_t)c.r[12] >= (int32_t)c.r[1];  // 0601FC40 cmp/ge r1,r12
    { const bool k = !c.t; c.r[5] += 2; if (k) { SH2_POLL(c); goto L_0601FB58; } }  // 0601FC42 bf/s 0x0601FB58 ; add #2,r5
L_0601FC46:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601FC7Au);  // 0601FC46 mov.w 0x0601FC7A,r1
    c.t = c.r[4] == c.r[1];  // 0601FC48 cmp/eq r1,r4
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_0601FC5C; } }  // 0601FC4A bt/s 0x0601FC5C ; mov #0,r0
    c.r[1] = ld32(0x0601FC80u);  // 0601FC4E mov.l 0x0601FC80,r1
    c.r[1] = ld32(c.r[1]);  // 0601FC50 mov.l @r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601FC52 tst r1,r1
    { const bool k = c.t; c.r[4] = c.r[4] & 0xFFu; if (k) { goto L_0601FC5C; } }  // 0601FC54 bt/s 0x0601FC5C ; extu.b r4,r4
    st32(c.r[14] + 60, c.r[4]);  // 0601FC58 mov.l r4,@(60,r14)
    c.r[0] = 0x0u;  // 0601FC5A mov #0,r0
L_0601FC5C:
    st32(c.r[14] + 56, c.r[0]);  // 0601FC5C mov.l r0,@(56,r14)
    c.r[12] = 0x0u;  // 0601FC5E mov #0,r12
    st32(c.r[14] + 44, c.r[12]);  // 0601FC60 mov.l r12,@(44,r14)
    st32(c.r[14] + 40, c.r[0]);  // 0601FC62 mov.l r0,@(40,r14)
    st32(c.r[14] + 52, c.r[12]);  // 0601FC64 mov.l r12,@(52,r14)
    st32(c.r[14] + 48, c.r[0]);  // 0601FC66 mov.l r0,@(48,r14)
    st32(c.r[14], c.r[12]);  // 0601FC68 mov.l r12,@r14
    c.r[3] = ld32(0x0601FC7Cu);  // 0601FC6A mov.l 0x0601FC7C,r3
    c.r[2] = ld32(c.r[3]);  // 0601FC6C mov.l @r3,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601FC78u);  // 0601FC6E mov.w 0x0601FC78,r1
    c.r[0] = c.r[2];  // 0601FC70 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601FC72 mov.b @(r0,r1),r1
    c.r[12] = ld32(c.r[14] + 48); goto L_0601FF34;  // 0601FC74 bra 0x0601FF34 ; mov.l @(48,r14),r12
L_0601FC84:
    c.r[12] = 0x7Fu;  // 0601FC84 mov #127,r12
    c.r[1] = ld32(c.r[3]);  // 0601FC86 mov.l @r3,r1
    c.r[2] += c.r[2];  // 0601FC88 add r2,r2
    c.r[0] = c.r[1];  // 0601FC8A mov r1,r0
    c.r[1] += c.r[2];  // 0601FC8C add r2,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0601FC8E mov.b @(r0,r2),r3
    c.r[1] += 1;  // 0601FC90 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601FC92 mov.b @r1,r1
    c.r[3] &= c.r[12];  // 0601FC94 and r12,r3
    c.r[3] <<= 8;  // 0601FC96 shll8 r3
    c.r[8] = c.r[1] & 0xFFu;  // 0601FC98 extu.b r1,r8
    c.r[8] |= c.r[3];  // 0601FC9A or r3,r8
    c.r[1] = ld32(0x0601FE4Cu);  // 0601FC9C mov.l 0x0601FE4C,r1
    c.r[2] = ld32(c.r[1]);  // 0601FC9E mov.l @r1,r2
    c.r[0] = 0x1u;  // 0601FCA0 mov #1,r0
    c.r[1] = c.r[8];  // 0601FCA2 mov r8,r1
    c.r[1] <<= 2;  // 0601FCA4 shll2 r1
    c.r[1] += c.r[8];  // 0601FCA6 add r8,r1
    c.r[1] <<= 2;  // 0601FCA8 shll2 r1
    c.r[2] += c.r[1];  // 0601FCAA add r1,r2
    c.r[1] = c.r[2];  // 0601FCAC mov r2,r1
    c.r[1] += 50;  // 0601FCAE add #50,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601FCB0 mov.b @r1,r1
    c.r[2] += 51;  // 0601FCB2 add #51,r2
    c.r[6] = c.r[1] & 0xFFu;  // 0601FCB4 extu.b r1,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601FCB6 mov.b @r2,r1
    c.r[6] >>= 2;  // 0601FCB8 shlr2 r6
    c.r[6] >>= 2;  // 0601FCBA shlr2 r6
    c.r[6] >>= 2;  // 0601FCBC shlr2 r6
    c.r[1] >>= 2;  // 0601FCBE shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0601FCC0 shlr r1
    c.r[1] &= c.r[0];  // 0601FCC2 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601FCC4 tst r1,r1
    { const bool k = c.t; c.r[12] = ld32(c.r[14]); if (k) { goto L_0601FCCE; } }  // 0601FCC6 bt/s 0x0601FCCE ; mov.l @r14,r12
    goto L_0601FF26;  // 0601FCCA bra 0x0601FF26 ; nop
L_0601FCCE:
    c.r[0] = c.r[6];  // 0601FCCE mov r6,r0
    c.t = c.r[0] == 0x2u;  // 0601FCD0 cmp/eq #2,r0
    if (!c.t) { goto L_0601FCE6; }  // 0601FCD2 bf 0x0601FCE6
    c.r[1] = ld32(0x0601FE50u);  // 0601FCD4 mov.l 0x0601FE50,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601FCD6 mov.b @r1,r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x0601FE44u);  // 0601FCD8 mov.w 0x0601FE44,r12
    c.r[1] = c.r[1] & 0xFFu;  // 0601FCDA extu.b r1,r1
    c.t = c.r[1] == c.r[12];  // 0601FCDC cmp/eq r12,r1
    { const bool k = !c.t; c.r[12] = ld32(c.r[14]); if (k) { goto L_0601FCE6; } }  // 0601FCDE bf/s 0x0601FCE6 ; mov.l @r14,r12
    goto L_0601FF26;  // 0601FCE2 bra 0x0601FF26 ; nop
L_0601FCE6:
    c.r[2] = (uint32_t)(int16_t)ld16(0x0601FE46u);  // 0601FCE6 mov.w 0x0601FE46,r2
    c.macl = c.r[8] * c.r[2];  // 0601FCE8 mul.l r2,r8
    c.r[3] = ld32(0x0601FE54u);  // 0601FCEA mov.l 0x0601FE54,r3
    c.r[1] = ld32(c.r[3]);  // 0601FCEC mov.l @r3,r1
    c.r[0] = c.macl;  // 0601FCEE sts macl,r0
    c.r[0] += c.r[1];  // 0601FCF0 add r1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601FE48u);  // 0601FCF2 mov.w 0x0601FE48,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601FCF4 mov.b @(r0,r1),r1
    c.r[9] = 0x0u;  // 0601FCF6 mov #0,r9
    c.r[1] = c.r[1] & 0xFFu;  // 0601FCF8 extu.b r1,r1
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[1];  // 0601FCFA cmp/ge r1,r9
    { const bool k = !c.t; c.r[12] = ld32(c.r[14]); if (k) { goto L_0601FD04; } }  // 0601FCFC bf/s 0x0601FD04 ; mov.l @r14,r12
    goto L_0601FF26;  // 0601FD00 bra 0x0601FF26 ; nop
L_0601FD04:
    c.r[13] = 0x0u;  // 0601FD04 mov #0,r13
L_0601FD06:
    c.r[0] = 0x48u;  // 0601FD06 mov #72,r0
    c.macl = c.r[8] * c.r[2];  // 0601FD08 mul.l r2,r8
    c.r[0] += c.r[14];  // 0601FD0A add r14,r0
    c.r[1] = ld32(c.r[3]);  // 0601FD0C mov.l @r3,r1
    c.r[12] = c.macl;  // 0601FD0E sts macl,r12
    st32(c.r[0], c.r[12]);  // 0601FD10 mov.l r12,@r0
    c.r[0] = 0x48u;  // 0601FD12 mov #72,r0
    c.r[0] += c.r[14];  // 0601FD14 add r14,r0
    c.r[12] = ld32(c.r[0]);  // 0601FD16 mov.l @r0,r12
    c.r[12] += c.r[1];  // 0601FD18 add r1,r12
    st32(c.r[0], c.r[12]);  // 0601FD1A mov.l r12,@r0
    c.r[0] = 0x48u;  // 0601FD1C mov #72,r0
    c.r[10] = ld32(c.r[0] + c.r[14]);  // 0601FD1E mov.l @(r0,r14),r10
    c.r[10] += c.r[13];  // 0601FD20 add r13,r10
    c.r[1] = c.r[10];  // 0601FD22 mov r10,r1
    c.r[1] += 4;  // 0601FD24 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601FD26 mov.b @r1,r1
    c.r[12] = ld32(0x0601FE58u);  // 0601FD28 mov.l 0x0601FE58,r12
    c.r[2] = c.r[1] & 0xFFu;  // 0601FD2A extu.b r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[12]);  // 0601FD2C mov.b @r12,r1
    c.r[0] = c.r[1];  // 0601FD2E mov r1,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0601FD30 cmp/eq #-1,r0
    { const bool k = c.t; c.r[0] = ld32(c.r[14] + 36); if (k) { goto L_0601FD40; } }  // 0601FD32 bt/s 0x0601FD40 ; mov.l @(36,r14),r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[12]);  // 0601FD36 mov.b @r12,r1
    c.t = c.r[1] == c.r[2];  // 0601FD38 cmp/eq r2,r1
    if (c.t) { goto L_0601FD40; }  // 0601FD3A bt 0x0601FD40
    goto L_0601FF06;  // 0601FD3C bra 0x0601FF06 ; nop
L_0601FD40:
    c.t = c.r[0] == c.r[2];  // 0601FD40 cmp/eq r2,r0
    { const bool k = !c.t; c.r[0] = ld32(c.r[14] + 60); if (k) { goto L_0601FD4A; } }  // 0601FD42 bf/s 0x0601FD4A ; mov.l @(60,r14),r0
    goto L_0601FF06;  // 0601FD46 bra 0x0601FF06 ; nop
L_0601FD4A:
    c.r[12] = (uint32_t)(int16_t)ld16(0x0601FE44u);  // 0601FD4A mov.w 0x0601FE44,r12
    c.t = c.r[0] == c.r[12];  // 0601FD4C cmp/eq r12,r0
    { const bool k = c.t; c.t = c.r[0] == c.r[2]; if (k) { goto L_0601FD58; } }  // 0601FD4E bt/s 0x0601FD58 ; cmp/eq r2,r0
    if (c.t) { goto L_0601FD58; }  // 0601FD52 bt 0x0601FD58
    goto L_0601FF06;  // 0601FD54 bra 0x0601FF06 ; nop
L_0601FD58:
    c.r[1] = ld32(0x0601FE5Cu);  // 0601FD58 mov.l 0x0601FE5C,r1
    c.r[3] = c.r[2];  // 0601FD5A mov r2,r3
    c.r[7] = ld32(c.r[1]);  // 0601FD5C mov.l @r1,r7
    c.r[3] <<= 2;  // 0601FD5E shll2 r3
    c.r[3] <<= 2;  // 0601FD60 shll2 r3
    c.r[3] += c.r[7];  // 0601FD62 add r7,r3
    c.r[1] = c.r[3];  // 0601FD64 mov r3,r1
    c.r[1] += 4;  // 0601FD66 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601FD68 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0601FD6A mov r1,r0
    c.r[0] >>= 2;  // 0601FD6C shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0601FD6E shlr r0
    c.r[0] >>= 2;  // 0601FD70 shlr2 r0
    c.r[0] &= 0x1u;  // 0601FD72 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601FD74 tst r0,r0
    { const bool k = c.t; c.r[3] += 6; if (k) { goto L_0601FD7E; } }  // 0601FD76 bt/s 0x0601FD7E ; add #6,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0601FD7A mov.b @r3,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0601FD7C extu.b r1,r2
L_0601FD7E:
    c.r[3] = c.r[2];  // 0601FD7E mov r2,r3
    c.r[3] <<= 2;  // 0601FD80 shll2 r3
    c.r[3] <<= 2;  // 0601FD82 shll2 r3
    c.r[3] += c.r[7];  // 0601FD84 add r7,r3
    c.r[1] = c.r[3];  // 0601FD86 mov r3,r1
    c.r[1] += 4;  // 0601FD88 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601FD8A mov.b @r1,r1
    c.r[0] = c.r[1];  // 0601FD8C mov r1,r0
    c.r[0] >>= 2;  // 0601FD8E shlr2 r0
    c.r[0] >>= 2;  // 0601FD90 shlr2 r0
    c.r[0] >>= 2;  // 0601FD92 shlr2 r0
    c.r[0] &= 0x1u;  // 0601FD94 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601FD96 tst r0,r0
    { const bool k = c.t; c.r[11] = c.r[2]; if (k) { goto L_0601FDC0; } }  // 0601FD98 bt/s 0x0601FDC0 ; mov r2,r11
    c.r[3] += 5;  // 0601FD9C add #5,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0601FD9E mov.b @r3,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0601FDA0 extu.b r1,r2
    c.r[1] = c.r[2];  // 0601FDA2 mov r2,r1
    c.r[1] <<= 2;  // 0601FDA4 shll2 r1
    c.r[1] <<= 2;  // 0601FDA6 shll2 r1
    c.r[1] += c.r[7];  // 0601FDA8 add r7,r1
    c.r[1] += 7;  // 0601FDAA add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601FDAC mov.b @r1,r1
    c.r[0] = c.r[1];  // 0601FDAE mov r1,r0
    c.r[0] >>= 2;  // 0601FDB0 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0601FDB2 shlr r0
    c.r[0] &= 0x1u;  // 0601FDB4 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0601FDB6 tst r0,r0
    { const bool k = c.t; c.r[11] = c.r[2]; if (k) { goto L_0601FDC0; } }  // 0601FDB8 bt/s 0x0601FDC0 ; mov r2,r11
    goto L_0601FF06;  // 0601FDBC bra 0x0601FF06 ; nop
L_0601FDC0:
    c.r[11] <<= 2;  // 0601FDC0 shll2 r11
    c.r[11] <<= 2;  // 0601FDC2 shll2 r11
    c.r[11] += c.r[7];  // 0601FDC4 add r7,r11
    c.r[1] = c.r[11];  // 0601FDC6 mov r11,r1
    c.r[1] += 11;  // 0601FDC8 add #11,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601FDCA mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601FDCC extu.b r1,r1
    c.r[1] >>= 2;  // 0601FDCE shlr2 r1
    c.r[1] >>= 2;  // 0601FDD0 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0601FDD2 shlr r1
    c.r[1] >>= 2;  // 0601FDD4 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601FDD6 tst r1,r1
    { const bool k = c.t; c.r[1] = c.r[11]; if (k) { goto L_0601FDE0; } }  // 0601FDD8 bt/s 0x0601FDE0 ; mov r11,r1
    goto L_0601FF06;  // 0601FDDC bra 0x0601FF06 ; nop
L_0601FDE0:
    c.r[1] += 3;  // 0601FDE0 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601FDE2 mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0601FDE4 extu.b r1,r2
    c.r[0] = c.r[2];  // 0601FDE6 mov r2,r0
    c.r[0] >>= 2;  // 0601FDE8 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0601FDEA shlr r0
    c.r[0] &= 0x3u;  // 0601FDEC and #3,r0
    c.t = c.r[0] == 0x2u;  // 0601FDEE cmp/eq #2,r0
    { const bool k = !c.t; c.r[1] = ld32(c.r[14] + 36); if (k) { goto L_0601FDF8; } }  // 0601FDF0 bf/s 0x0601FDF8 ; mov.l @(36,r14),r1
    goto L_0601FF06;  // 0601FDF4 bra 0x0601FF06 ; nop
L_0601FDF8:
    c.r[1] <<= 2;  // 0601FDF8 shll2 r1
    c.r[1] <<= 2;  // 0601FDFA shll2 r1
    c.r[1] += c.r[7];  // 0601FDFC add r7,r1
    c.r[1] += 4;  // 0601FDFE add #4,r1
    c.r[0] = 0xFu;  // 0601FE00 mov #15,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601FE02 mov.b @r1,r1
    c.r[12] = 0x3u;  // 0601FE04 mov #3,r12
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0601FE06 shlr r1
    c.r[1] &= c.r[0];  // 0601FE08 and r0,r1
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 0601FE0A shlr r2
    c.r[2] &= c.r[12];  // 0601FE0C and r12,r2
    c.r[5] = c.r[2];  // 0601FE0E mov r2,r5
    c.r[4] = c.r[1];  // 0601FE10 mov r1,r4
    c.r[0] = 0x40u;  // 0601FE12 mov #64,r0
    c.r[0] += c.r[14];  // 0601FE14 add r14,r0
    c.r[12] = ld32(0x0601FE60u);  // 0601FE16 mov.l 0x0601FE60,r12
    { const uint32_t x = c.r[12]; c.pr = 0x0601FE1Cu; st32(c.r[0], c.r[6]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601FE1Cu) return; }  // 0601FE18 jsr @r12 ; mov.l r6,@r0
    c.r[1] = c.r[0];  // 0601FE1C mov r0,r1
    c.r[0] = 0x1u;  // 0601FE1E mov #1,r0
    c.r[1] &= c.r[0];  // 0601FE20 and r0,r1
    c.r[12] = 0x40u;  // 0601FE22 mov #64,r12
    c.r[12] += c.r[14];  // 0601FE24 add r14,r12
    c.t = (c.r[1] & c.r[1]) == 0;  // 0601FE26 tst r1,r1
    { const bool k = c.t; c.r[6] = ld32(c.r[12]); if (k) { goto L_0601FF06; } }  // 0601FE28 bt/s 0x0601FF06 ; mov.l @r12,r6
    c.r[1] = c.r[10];  // 0601FE2C mov r10,r1
    c.r[1] += 7;  // 0601FE2E add #7,r1
    c.r[12] = 0x48u;  // 0601FE30 mov #72,r12
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601FE32 mov.b @r1,r1
    c.r[12] += c.r[14];  // 0601FE34 add r14,r12
    c.r[0] = ld32(c.r[12]);  // 0601FE36 mov.l @r12,r0
    c.r[7] = c.r[1] & 0xFFu;  // 0601FE38 extu.b r1,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[13]);  // 0601FE3A mov.b @(r0,r13),r1
    c.r[3] = 0x7Fu;  // 0601FE3C mov #127,r3
    c.r[3] &= c.r[1];  // 0601FE3E and r1,r3
    c.r[1] = c.r[10]; goto L_0601FE64;  // 0601FE40 bra 0x0601FE64 ; mov r10,r1
L_0601FE64:
    c.r[1] += 1;  // 0601FE64 add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601FE66 mov.b @r1,r2
    c.r[3] <<= 16;  // 0601FE68 shll16 r3
    c.r[3] <<= 8;  // 0601FE6A shll8 r3
    c.r[2] = c.r[2] & 0xFFu;  // 0601FE6C extu.b r2,r2
    c.r[2] <<= 16;  // 0601FE6E shll16 r2
    c.r[2] |= c.r[3];  // 0601FE70 or r3,r2
    c.r[1] = c.r[10];  // 0601FE72 mov r10,r1
    c.r[1] += 2;  // 0601FE74 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601FE76 mov.b @r1,r1
    c.r[10] += 3;  // 0601FE78 add #3,r10
    c.r[1] = c.r[1] & 0xFFu;  // 0601FE7A extu.b r1,r1
    c.r[1] <<= 8;  // 0601FE7C shll8 r1
    c.r[1] |= c.r[2];  // 0601FE7E or r2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0601FE80 mov.b @r10,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0601FE82 extu.b r2,r2
    c.r[2] |= c.r[1];  // 0601FE84 or r1,r2
    c.r[1] = 0x64u;  // 0601FE86 mov #100,r1
    c.macl = c.r[2] * c.r[1];  // 0601FE88 mul.l r1,r2
    c.r[11] += 2;  // 0601FE8A add #2,r11
    c.r[4] = c.macl;  // 0601FE8C sts macl,r4
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[11]);  // 0601FE8E mov.b @r11,r2
    c.r[1] = ld32(0x0601FEECu);  // 0601FE90 mov.l 0x0601FEEC,r1
    c.r[3] = ld32(c.r[1]);  // 0601FE92 mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0601FE94 extu.b r2,r2
    c.r[1] = 0x1Eu;  // 0601FE96 mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 0601FE98 mul.l r1,r2
    c.r[1] = c.macl;  // 0601FE9A sts macl,r1
    c.r[1] += c.r[3];  // 0601FE9C add r3,r1
    c.r[1] += 22;  // 0601FE9E add #22,r1
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0601FEA0 mov.w @r1,r5
    c.r[1] = ld32(0x0601FEF0u);  // 0601FEA2 mov.l 0x0601FEF0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0601FEA8u; c.r[5] = c.r[5] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0601FEA8u) return; }  // 0601FEA4 jsr @r1 ; extu.w r5,r5
    c.r[2] = c.r[0];  // 0601FEA8 mov r0,r2
    c.r[0] = c.r[6];  // 0601FEAA mov r6,r0
    c.t = c.r[0] == 0x2u;  // 0601FEAC cmp/eq #2,r0
    { const bool k = !c.t; c.r[1] = 0x63u; if (k) { goto L_0601FED6; } }  // 0601FEAE bf/s 0x0601FED6 ; mov #99,r1
    c.r[1] = ld32(0x0601FEF4u);  // 0601FEB2 mov.l 0x0601FEF4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601FEB4 mov.b @r1,r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x0601FEEAu);  // 0601FEB6 mov.w 0x0601FEEA,r12
    c.r[1] = c.r[1] & 0xFFu;  // 0601FEB8 extu.b r1,r1
    c.t = c.r[1] == c.r[12];  // 0601FEBA cmp/eq r12,r1
    { const bool k = c.t; c.r[1] = 0x63u; if (k) { goto L_0601FED6; } }  // 0601FEBC bt/s 0x0601FED6 ; mov #99,r1
    c.r[0] = ld32(c.r[14] + 40);  // 0601FEC0 mov.l @(40,r14),r0
    c.r[0] += c.r[2];  // 0601FEC2 add r2,r0
    st32(c.r[14] + 40, c.r[0]);  // 0601FEC4 mov.l r0,@(40,r14)
    st32(c.r[14] + 48, c.r[8]);  // 0601FEC6 mov.l r8,@(48,r14)
    c.r[12] = ld32(c.r[14] + 44);  // 0601FEC8 mov.l @(44,r14),r12
    st32(c.r[14] + 52, c.r[9]);  // 0601FECA mov.l r9,@(52,r14)
    c.r[0] = ld32(c.r[14] + 56);  // 0601FECC mov.l @(56,r14),r0
    c.r[12] += c.r[7];  // 0601FECE add r7,r12
    st32(c.r[14] + 44, c.r[12]);  // 0601FED0 mov.l r12,@(44,r14)
    c.r[0] += 1;  // 0601FED2 add #1,r0
    st32(c.r[14] + 56, c.r[0]);  // 0601FED4 mov.l r0,@(56,r14)
L_0601FED6:
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0601FED6 cmp/gt r1,r2
    { const bool k = !c.t; c.r[12] = ld32(c.r[14] + 4); if (k) { goto L_0601FEF8; } }  // 0601FED8 bf/s 0x0601FEF8 ; mov.l @(4,r14),r12
    c.t = (int32_t)c.r[2] > (int32_t)c.r[12];  // 0601FEDC cmp/gt r12,r2
    if (!c.t) { goto L_0601FF06; }  // 0601FEDE bf 0x0601FF06
    st32(c.r[14] + 4, c.r[2]);  // 0601FEE0 mov.l r2,@(4,r14)
    st32(c.r[14] + 16, c.r[7]);  // 0601FEE2 mov.l r7,@(16,r14)
    st32(c.r[14] + 12, c.r[9]);  // 0601FEE4 mov.l r9,@(12,r14)
    st32(c.r[14] + 8, c.r[8]); goto L_0601FF06;  // 0601FEE6 bra 0x0601FF06 ; mov.l r8,@(8,r14)
L_0601FEF8:
    c.r[0] = ld32(c.r[14] + 20);  // 0601FEF8 mov.l @(20,r14),r0
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[0];  // 0601FEFA cmp/ge r0,r2
    if (!c.t) { goto L_0601FF06; }  // 0601FEFC bf 0x0601FF06
    st32(c.r[14] + 20, c.r[2]);  // 0601FEFE mov.l r2,@(20,r14)
    st32(c.r[14] + 32, c.r[7]);  // 0601FF00 mov.l r7,@(32,r14)
    st32(c.r[14] + 28, c.r[9]);  // 0601FF02 mov.l r9,@(28,r14)
    st32(c.r[14] + 24, c.r[8]);  // 0601FF04 mov.l r8,@(24,r14)
L_0601FF06:
    c.r[2] = (uint32_t)(int16_t)ld16(0x0601FFFCu);  // 0601FF06 mov.w 0x0601FFFC,r2
    c.macl = c.r[8] * c.r[2];  // 0601FF08 mul.l r2,r8
    c.r[3] = ld32(0x06020004u);  // 0601FF0A mov.l 0x06020004,r3
    c.r[1] = ld32(c.r[3]);  // 0601FF0C mov.l @r3,r1
    c.r[0] = c.macl;  // 0601FF0E sts macl,r0
    c.r[0] += c.r[1];  // 0601FF10 add r1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601FFFEu);  // 0601FF12 mov.w 0x0601FFFE,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0601FF14 mov.b @(r0,r1),r1
    c.r[9] += 1;  // 0601FF16 add #1,r9
    c.r[1] = c.r[1] & 0xFFu;  // 0601FF18 extu.b r1,r1
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[1];  // 0601FF1A cmp/ge r1,r9
    { const bool k = c.t; c.r[13] += 8; if (k) { goto L_0601FF24; } }  // 0601FF1C bt/s 0x0601FF24 ; add #8,r13
    SH2_POLL(c); goto L_0601FD06;  // 0601FF20 bra 0x0601FD06 ; nop
L_0601FF24:
    c.r[12] = ld32(c.r[14]);  // 0601FF24 mov.l @r14,r12
L_0601FF26:
    c.r[3] = ld32(0x06020008u);  // 0601FF26 mov.l 0x06020008,r3
    c.r[12] += 1;  // 0601FF28 add #1,r12
    st32(c.r[14], c.r[12]);  // 0601FF2A mov.l r12,@r14
    c.r[1] = ld32(c.r[3]);  // 0601FF2C mov.l @r3,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06020000u);  // 0601FF2E mov.w 0x06020000,r2
    c.r[0] = c.r[1];  // 0601FF30 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0601FF32 mov.b @(r0,r2),r1
L_0601FF34:
    c.r[1] = c.r[1] & 0xFFu;  // 0601FF34 extu.b r1,r1
    c.t = (int32_t)c.r[12] >= (int32_t)c.r[1];  // 0601FF36 cmp/ge r1,r12
    { const bool k = c.t; c.r[2] = ld32(c.r[14]); if (k) { goto L_0601FF40; } }  // 0601FF38 bt/s 0x0601FF40 ; mov.l @r14,r2
    SH2_POLL(c); goto L_0601FC84;  // 0601FF3C bra 0x0601FC84 ; nop
L_0601FF40:
    c.r[12] = ld32(c.r[14] + 56);  // 0601FF40 mov.l @(56,r14),r12
    c.t = (c.r[12] & c.r[12]) == 0;  // 0601FF42 tst r12,r12
    { const bool k = c.t; c.r[0] = ld32(c.r[14] + 40); if (k) { goto L_0601FF72; } }  // 0601FF44 bt/s 0x0601FF72 ; mov.l @(40,r14),r0
    c.r[12] = ld32(c.r[14] + 4);  // 0601FF48 mov.l @(4,r14),r12
    c.t = (int32_t)c.r[0] > (int32_t)c.r[12];  // 0601FF4A cmp/gt r12,r0
    { const bool k = !c.t; c.r[12] = ld32(c.r[14] + 44); if (k) { goto L_0601FF5E; } }  // 0601FF4C bf/s 0x0601FF5E ; mov.l @(44,r14),r12
    st32(c.r[14] + 4, c.r[0]);  // 0601FF50 mov.l r0,@(4,r14)
    c.r[0] = ld32(c.r[14] + 52);  // 0601FF52 mov.l @(52,r14),r0
    st32(c.r[14] + 16, c.r[12]);  // 0601FF54 mov.l r12,@(16,r14)
    c.r[12] = ld32(c.r[14] + 48);  // 0601FF56 mov.l @(48,r14),r12
    st32(c.r[14] + 12, c.r[0]);  // 0601FF58 mov.l r0,@(12,r14)
    st32(c.r[14] + 8, c.r[12]);  // 0601FF5A mov.l r12,@(8,r14)
    c.r[0] = ld32(c.r[14] + 40);  // 0601FF5C mov.l @(40,r14),r0
L_0601FF5E:
    c.r[12] = ld32(c.r[14] + 20);  // 0601FF5E mov.l @(20,r14),r12
    c.t = (int32_t)c.r[0] > (int32_t)c.r[12];  // 0601FF60 cmp/gt r12,r0
    if (!c.t) { goto L_0601FF72; }  // 0601FF62 bf 0x0601FF72
    c.r[12] = ld32(c.r[14] + 44);  // 0601FF64 mov.l @(44,r14),r12
    st32(c.r[14] + 20, c.r[0]);  // 0601FF66 mov.l r0,@(20,r14)
    c.r[0] = ld32(c.r[14] + 52);  // 0601FF68 mov.l @(52,r14),r0
    st32(c.r[14] + 32, c.r[12]);  // 0601FF6A mov.l r12,@(32,r14)
    c.r[12] = ld32(c.r[14] + 48);  // 0601FF6C mov.l @(48,r14),r12
    st32(c.r[14] + 28, c.r[0]);  // 0601FF6E mov.l r0,@(28,r14)
    st32(c.r[14] + 24, c.r[12]);  // 0601FF70 mov.l r12,@(24,r14)
L_0601FF72:
    c.r[1] = ld32(0x0602000Cu);  // 0601FF72 mov.l 0x0602000C,r1
    c.r[1] = ld32(c.r[1] + 4);  // 0601FF74 mov.l @(4,r1),r1
    c.r[0] = ld32(c.r[14] + 4);  // 0601FF76 mov.l @(4,r14),r0
    c.t = (int32_t)c.r[1] > (int32_t)c.r[0];  // 0601FF78 cmp/gt r0,r1
    { const bool k = c.t; c.t = (int32_t)c.r[0] >= 0; if (k) { goto L_0601FF80; } }  // 0601FF7A bt/s 0x0601FF80 ; cmp/pz r0
    if (c.t) { goto L_0601FFAE; }  // 0601FF7E bt 0x0601FFAE
L_0601FF80:
    c.r[1] = ld32(0x06020010u);  // 0601FF80 mov.l 0x06020010,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601FF82 mov.b @r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06020002u);  // 0601FF84 mov.w 0x06020002,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0601FF86 extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 0601FF88 cmp/eq r2,r1
    { const bool k = c.t; c.r[12] = ld32(c.r[14] + 8); if (k) { goto L_06020030; } }  // 0601FF8A bt/s 0x06020030 ; mov.l @(8,r14),r12
    c.r[1] = ld32(0x06020014u);  // 0601FF8E mov.l 0x06020014,r1
    c.r[2] = ld32(c.r[1]);  // 0601FF90 mov.l @r1,r2
    c.r[1] = ld32(c.r[14] + 8);  // 0601FF92 mov.l @(8,r14),r1
    c.r[1] <<= 2;  // 0601FF94 shll2 r1
    c.r[1] += c.r[12];  // 0601FF96 add r12,r1
    c.r[1] <<= 2;  // 0601FF98 shll2 r1
    c.r[2] += c.r[1];  // 0601FF9A add r1,r2
    c.r[2] += 50;  // 0601FF9C add #50,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0601FF9E mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0601FFA0 extu.b r1,r1
    c.r[1] >>= 2;  // 0601FFA2 shlr2 r1
    c.r[1] >>= 2;  // 0601FFA4 shlr2 r1
    c.r[1] >>= 2;  // 0601FFA6 shlr2 r1
    c.r[0] = c.r[1];  // 0601FFA8 mov r1,r0
    c.t = c.r[0] == 0x2u;  // 0601FFAA cmp/eq #2,r0
    if (!c.t) { goto L_06020030; }  // 0601FFAC bf 0x06020030
L_0601FFAE:
    c.r[2] = ld32(0x06020018u);  // 0601FFAE mov.l 0x06020018,r2
    c.r[7] = c.r[2];  // 0601FFB0 mov r2,r7
    c.r[7] += 2;  // 0601FFB2 add #2,r7
    c.r[12] = 0xAu;  // 0601FFB4 mov #10,r12
    c.r[12] += c.r[14];  // 0601FFB6 add r14,r12
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[12]);  // 0601FFB8 mov.w @r12,r3
    c.r[1] = ld32(0x0602001Cu);  // 0601FFBA mov.l 0x0602001C,r1
    st16(c.r[1], c.r[3]);  // 0601FFBC mov.w r3,@r1
    st8(c.r[7], c.r[3]);  // 0601FFBE mov.b r3,@r7
    st8(c.r[2], c.r[3]);  // 0601FFC0 mov.b r3,@r2
    c.r[1] = ld32(0x06020004u);  // 0601FFC2 mov.l 0x06020004,r1
    c.r[2] = ld32(c.r[1]);  // 0601FFC4 mov.l @r1,r2
    c.r[6] = ld32(0x06020020u);  // 0601FFC6 mov.l 0x06020020,r6
    c.r[0] = ld32(c.r[14] + 8);  // 0601FFC8 mov.l @(8,r14),r0
    c.r[7] = ld32(0x06020024u);  // 0601FFCA mov.l 0x06020024,r7
    c.r[12] = ld32(c.r[14] + 12);  // 0601FFCC mov.l @(12,r14),r12
    c.r[1] = (uint32_t)(int16_t)ld16(0x0601FFFCu);  // 0601FFCE mov.w 0x0601FFFC,r1
    c.macl = c.r[0] * c.r[1];  // 0601FFD0 mul.l r1,r0
    c.r[12] <<= 2;  // 0601FFD2 shll2 r12
    c.r[12] += c.r[12];  // 0601FFD4 add r12,r12
    st32(c.r[14] + 12, c.r[12]);  // 0601FFD6 mov.l r12,@(12,r14)
    c.r[1] = c.macl;  // 0601FFD8 sts macl,r1
    c.r[1] += c.r[2];  // 0601FFDA add r2,r1
    c.r[1] += c.r[12];  // 0601FFDC add r12,r1
    c.r[1] += 4;  // 0601FFDE add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0601FFE0 mov.b @r1,r1
    c.r[2] = ld32(0x06020028u);  // 0601FFE2 mov.l 0x06020028,r2
    st8(c.r[7], c.r[1]);  // 0601FFE4 mov.b r1,@r7
    st8(c.r[6], c.r[1]);  // 0601FFE6 mov.b r1,@r6
    st8(c.r[2], c.r[1]);  // 0601FFE8 mov.b r1,@r2
    c.r[1] = c.r[2];  // 0601FFEA mov r2,r1
    c.r[1] += 1;  // 0601FFEC add #1,r1
    st8(c.r[1], c.r[3]);  // 0601FFEE mov.b r3,@r1
    c.r[0] = ld32(c.r[14] + 4);  // 0601FFF0 mov.l @(4,r14),r0
    c.r[1] = ld32(0x0602002Cu);  // 0601FFF2 mov.l 0x0602002C,r1
    c.r[12] = ld32(c.r[14] + 16);  // 0601FFF4 mov.l @(16,r14),r12
    st32(c.r[2] + 4, c.r[0]);  // 0601FFF6 mov.l r0,@(4,r2)
    st32(c.r[2] + 8, c.r[12]); goto L_060200D4;  // 0601FFF8 bra 0x060200D4 ; mov.l r12,@(8,r2)
L_06020030:
    c.r[1] = ld32(0x0602018Cu);  // 06020030 mov.l 0x0602018C,r1
    c.r[1] = ld32(c.r[1] + 4);  // 06020032 mov.l @(4,r1),r1
    c.r[0] = ld32(c.r[14] + 20);  // 06020034 mov.l @(20,r14),r0
    c.t = (int32_t)c.r[1] > (int32_t)c.r[0];  // 06020036 cmp/gt r0,r1
    { const bool k = c.t; c.t = (int32_t)c.r[0] >= 0; if (k) { goto L_0602003E; } }  // 06020038 bt/s 0x0602003E ; cmp/pz r0
    if (c.t) { goto L_0602006C; }  // 0602003C bt 0x0602006C
L_0602003E:
    c.r[1] = ld32(0x06020190u);  // 0602003E mov.l 0x06020190,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06020040 mov.b @r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06020186u);  // 06020042 mov.w 0x06020186,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06020044 extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 06020046 cmp/eq r2,r1
    { const bool k = c.t; c.r[12] = ld32(c.r[14] + 24); if (k) { goto L_060200BA; } }  // 06020048 bt/s 0x060200BA ; mov.l @(24,r14),r12
    c.r[1] = ld32(0x06020194u);  // 0602004C mov.l 0x06020194,r1
    c.r[2] = ld32(c.r[1]);  // 0602004E mov.l @r1,r2
    c.r[1] = ld32(c.r[14] + 24);  // 06020050 mov.l @(24,r14),r1
    c.r[1] <<= 2;  // 06020052 shll2 r1
    c.r[1] += c.r[12];  // 06020054 add r12,r1
    c.r[1] <<= 2;  // 06020056 shll2 r1
    c.r[2] += c.r[1];  // 06020058 add r1,r2
    c.r[2] += 50;  // 0602005A add #50,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602005C mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602005E extu.b r1,r1
    c.r[1] >>= 2;  // 06020060 shlr2 r1
    c.r[1] >>= 2;  // 06020062 shlr2 r1
    c.r[1] >>= 2;  // 06020064 shlr2 r1
    c.r[0] = c.r[1];  // 06020066 mov r1,r0
    c.t = c.r[0] == 0x2u;  // 06020068 cmp/eq #2,r0
    if (!c.t) { goto L_060200BA; }  // 0602006A bf 0x060200BA
L_0602006C:
    c.r[2] = ld32(0x06020198u);  // 0602006C mov.l 0x06020198,r2
    c.r[7] = c.r[2];  // 0602006E mov r2,r7
    c.r[7] += 2;  // 06020070 add #2,r7
    c.r[12] = 0x1Au;  // 06020072 mov #26,r12
    c.r[12] += c.r[14];  // 06020074 add r14,r12
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[12]);  // 06020076 mov.w @r12,r3
    c.r[1] = ld32(0x0602019Cu);  // 06020078 mov.l 0x0602019C,r1
    st16(c.r[1], c.r[3]);  // 0602007A mov.w r3,@r1
    st8(c.r[7], c.r[3]);  // 0602007C mov.b r3,@r7
    st8(c.r[2], c.r[3]);  // 0602007E mov.b r3,@r2
    c.r[1] = ld32(0x060201A0u);  // 06020080 mov.l 0x060201A0,r1
    c.r[2] = ld32(c.r[1]);  // 06020082 mov.l @r1,r2
    c.r[6] = ld32(0x060201A4u);  // 06020084 mov.l 0x060201A4,r6
    c.r[0] = ld32(c.r[14] + 24);  // 06020086 mov.l @(24,r14),r0
    c.r[7] = ld32(0x060201A8u);  // 06020088 mov.l 0x060201A8,r7
    c.r[12] = ld32(c.r[14] + 28);  // 0602008A mov.l @(28,r14),r12
    c.r[1] = (uint32_t)(int16_t)ld16(0x06020188u);  // 0602008C mov.w 0x06020188,r1
    c.macl = c.r[0] * c.r[1];  // 0602008E mul.l r1,r0
    c.r[12] <<= 2;  // 06020090 shll2 r12
    c.r[12] += c.r[12];  // 06020092 add r12,r12
    st32(c.r[14] + 28, c.r[12]);  // 06020094 mov.l r12,@(28,r14)
    c.r[1] = c.macl;  // 06020096 sts macl,r1
    c.r[1] += c.r[2];  // 06020098 add r2,r1
    c.r[1] += c.r[12];  // 0602009A add r12,r1
    c.r[1] += 4;  // 0602009C add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602009E mov.b @r1,r1
    c.r[2] = ld32(0x060201ACu);  // 060200A0 mov.l 0x060201AC,r2
    st8(c.r[7], c.r[1]);  // 060200A2 mov.b r1,@r7
    st8(c.r[6], c.r[1]);  // 060200A4 mov.b r1,@r6
    st8(c.r[2], c.r[1]);  // 060200A6 mov.b r1,@r2
    c.r[1] = c.r[2];  // 060200A8 mov r2,r1
    c.r[1] += 1;  // 060200AA add #1,r1
    st8(c.r[1], c.r[3]);  // 060200AC mov.b r3,@r1
    c.r[0] = ld32(c.r[14] + 20);  // 060200AE mov.l @(20,r14),r0
    c.r[1] = ld32(0x060201B0u);  // 060200B0 mov.l 0x060201B0,r1
    c.r[12] = ld32(c.r[14] + 32);  // 060200B2 mov.l @(32,r14),r12
    st32(c.r[2] + 4, c.r[0]);  // 060200B4 mov.l r0,@(4,r2)
    st32(c.r[2] + 8, c.r[12]); goto L_060200D4;  // 060200B6 bra 0x060200D4 ; mov.l r12,@(8,r2)
L_060200BA:
    c.r[2] = ld32(0x0602019Cu);  // 060200BA mov.l 0x0602019C,r2
    c.r[1] = 0xFFFFFFFFu;  // 060200BC mov #-1,r1
    st16(c.r[2], c.r[1]);  // 060200BE mov.w r1,@r2
    c.r[2] = ld32(0x060201ACu);  // 060200C0 mov.l 0x060201AC,r2
    c.r[3] = c.r[2];  // 060200C2 mov r2,r3
    c.r[3] += 1;  // 060200C4 add #1,r3
    c.r[1] = 0xFFFFFFFFu;  // 060200C6 mov #-1,r1
    st8(c.r[3], c.r[1]);  // 060200C8 mov.b r1,@r3
    st8(c.r[2], c.r[1]);  // 060200CA mov.b r1,@r2
    c.r[1] = 0xFFFFFFFFu;  // 060200CC mov #-1,r1
    st32(c.r[2] + 8, c.r[1]);  // 060200CE mov.l r1,@(8,r2)
    st32(c.r[2] + 4, c.r[1]);  // 060200D0 mov.l r1,@(4,r2)
    c.r[1] = ld32(0x060201B4u);  // 060200D2 mov.l 0x060201B4,r1
L_060200D4:
    { const uint32_t x = c.r[1]; c.pr = 0x060200D8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060200D8u) return; }  // 060200D4 jsr @r1 ; nop
    c.r[7] = ld32(0x060201B8u);  // 060200D8 mov.l 0x060201B8,r7
    c.r[1] = 0x0u;  // 060200DA mov #0,r1
    st32(c.r[7] + 20, c.r[1]);  // 060200DC mov.l r1,@(20,r7)
    c.r[1] = c.r[7];  // 060200DE mov r7,r1
    c.r[1] += 37;  // 060200E0 add #37,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060200E2 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060200E4 extu.b r1,r1
    c.r[1] >>= 2;  // 060200E6 shlr2 r1
    c.r[1] >>= 2;  // 060200E8 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060200EA shlr r1
    c.r[1] >>= 2;  // 060200EC shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060200EE tst r1,r1
    if (!c.t) { goto L_06020132; }  // 060200F0 bf 0x06020132
    c.r[1] = ld32(0x06020194u);  // 060200F2 mov.l 0x06020194,r1
    c.r[3] = ld32(c.r[1]);  // 060200F4 mov.l @r1,r3
    c.r[1] = ld32(0x06020198u);  // 060200F6 mov.l 0x06020198,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060200F8 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060200FA extu.b r1,r1
    c.r[2] = c.r[1];  // 060200FC mov r1,r2
    c.r[2] <<= 2;  // 060200FE shll2 r2
    c.r[2] += c.r[1];  // 06020100 add r1,r2
    c.r[2] <<= 2;  // 06020102 shll2 r2
    c.r[3] += c.r[2];  // 06020104 add r2,r3
    c.r[3] += 50;  // 06020106 add #50,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06020108 mov.b @r3,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0602010A extu.b r1,r0
    c.r[0] >>= 2;  // 0602010C shlr2 r0
    c.r[0] >>= 2;  // 0602010E shlr2 r0
    c.r[0] >>= 2;  // 06020110 shlr2 r0
    c.t = c.r[0] == 0x2u;  // 06020112 cmp/eq #2,r0
    if (!c.t) { goto L_06020132; }  // 06020114 bf 0x06020132
    c.r[0] = 0x27u;  // 06020116 mov #39,r0
    c.r[1] = ld32(0x060201A4u);  // 06020118 mov.l 0x060201A4,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 0602011A mov.b @(r0,r14),r0
    st8(c.r[1], c.r[0]);  // 0602011C mov.b r0,@r1
    c.r[1] = 0x1u;  // 0602011E mov #1,r1
    st32(c.r[7] + 20, c.r[1]);  // 06020120 mov.l r1,@(20,r7)
    c.r[1] = ld32(0x060201BCu);  // 06020122 mov.l 0x060201BC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06020124 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06020126 extu.b r1,r1
    st32(c.r[7] + 12, c.r[1]);  // 06020128 mov.l r1,@(12,r7)
    c.r[1] = ld32(0x060201C0u);  // 0602012A mov.l 0x060201C0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602012C mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602012E extu.b r1,r1
    st32(c.r[7] + 16, c.r[1]);  // 06020130 mov.l r1,@(16,r7)
L_06020132:
    c.r[1] = ld32(0x060201A8u);  // 06020132 mov.l 0x060201A8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06020134 mov.b @r1,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x06020186u);  // 06020136 mov.w 0x06020186,r3
    c.r[2] = c.r[1] & 0xFFu;  // 06020138 extu.b r1,r2
    c.t = c.r[2] == c.r[3];  // 0602013A cmp/eq r3,r2
    { const bool k = c.t; c.r[2] <<= 2; if (k) { goto L_0602016E; } }  // 0602013C bt/s 0x0602016E ; shll2 r2
    c.r[1] = ld32(0x060201C4u);  // 06020140 mov.l 0x060201C4,r1
    c.r[1] = ld32(c.r[1]);  // 06020142 mov.l @r1,r1
    c.r[2] <<= 2;  // 06020144 shll2 r2
    c.r[2] += c.r[1];  // 06020146 add r1,r2
    c.r[1] = c.r[2];  // 06020148 mov r2,r1
    c.r[1] += 9;  // 0602014A add #9,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602014C mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602014E extu.b r1,r1
    c.t = c.r[1] == c.r[3];  // 06020150 cmp/eq r3,r1
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_0602016E; } }  // 06020152 bt/s 0x0602016E ; mov r2,r1
    c.r[1] += 3;  // 06020156 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06020158 mov.b @r1,r1
    c.r[12] = 0x3u;  // 0602015A mov #3,r12
    c.r[3] = c.r[1];  // 0602015C mov r1,r3
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 0602015E shlr r3
    c.r[3] &= c.r[12];  // 06020160 and r12,r3
    c.t = (c.r[3] & c.r[3]) == 0;  // 06020162 tst r3,r3
    if (!c.t) { goto L_0602016E; }  // 06020164 bf 0x0602016E
    c.r[1] = ld32(c.r[2] + 12);  // 06020166 mov.l @(12,r2),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06020168 tst r1,r1
    if (c.t) { goto L_0602016E; }  // 0602016A bt 0x0602016E
    st32(c.r[2] + 12, c.r[3]);  // 0602016C mov.l r3,@(12,r2)
L_0602016E:
    c.r[14] += 76;  // 0602016E add #76,r14
    c.r[15] = c.r[14];  // 06020170 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06020172 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06020174 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06020176 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06020178 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0602017A mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0602017C mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0602017E mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602018Au);  // 06020180 mov.w 0x0602018A,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06020182 rts ; mov.l @r15+,r8
}

void f_060201C8(SH2Context& c) {
    ran[377] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060201C8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060201CA sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060201CC mov r15,r14
    c.r[1] = ld32(0x060201E8u);  // 060201CE mov.l 0x060201E8,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060201D0 mov.b @r1,r4
    c.r[2] = ld32(0x060201ECu);  // 060201D2 mov.l 0x060201EC,r2
    st8(c.r[2], c.r[4]);  // 060201D4 mov.b r4,@r2
    c.r[1] = ld32(0x060201F0u);  // 060201D6 mov.l 0x060201F0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060201DCu; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060201DCu) return; }  // 060201D8 jsr @r1 ; extu.b r4,r4
    c.r[15] = c.r[14];  // 060201DC mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060201DE lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x060201E6u);  // 060201E0 mov.w 0x060201E6,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060201E2 rts ; mov.l @r15+,r14
}

void f_060201F4(SH2Context& c) {
    ran[378] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060201F4 mov.l r14,@-r15
    c.r[1] = ld32(0x06020244u);  // 060201F6 mov.l 0x06020244,r1
    c.r[1] = ld32(c.r[1]);  // 060201F8 mov.l @r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060201FA mov.b @r1,r1
    c.r[14] = c.r[15];  // 060201FC mov r15,r14
    c.r[0] = c.r[1] & 0xFFu;  // 060201FE extu.b r1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602023Eu);  // 06020200 mov.w 0x0602023E,r1
    c.t = c.r[0] == c.r[1];  // 06020202 cmp/eq r1,r0
    { const bool k = !c.t; c.r[2] = c.r[0]; if (k) { goto L_06020224; } }  // 06020204 bf/s 0x06020224 ; mov r0,r2
    c.r[1] = ld32(0x06020248u);  // 06020208 mov.l 0x06020248,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602020A mov.b @r1,r1
    c.r[0] = c.r[1];  // 0602020C mov r1,r0
    c.r[0] >>= 2;  // 0602020E shlr2 r0
    c.r[0] >>= 2;  // 06020210 shlr2 r0
    c.r[0] &= 0x7u;  // 06020212 and #7,r0
    c.r[2] = c.r[0] & 0xFFu;  // 06020214 extu.b r0,r2
    c.r[1] = 0x2u;  // 06020216 mov #2,r1
    c.t = c.r[2] > c.r[1];  // 06020218 cmp/hi r1,r2
    { const bool k = c.t; c.r[15] = c.r[14]; if (k) { goto L_06020238; } }  // 0602021A bt/s 0x06020238 ; mov r14,r15
    c.r[1] = ld32(0x0602024Cu);  // 0602021E mov.l 0x0602024C,r1
    st8(c.r[1], c.r[0]); goto L_06020238;  // 06020220 bra 0x06020238 ; mov.b r0,@r1
L_06020224:
    c.r[1] = ld32(0x06020248u);  // 06020224 mov.l 0x06020248,r1
    c.r[3] = 0x7u;  // 06020226 mov #7,r3
    c.r[2] &= c.r[3];  // 06020228 and r3,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602022A mov.b @r1,r0
    c.r[2] <<= 2;  // 0602022C shll2 r2
    c.r[2] <<= 2;  // 0602022E shll2 r2
    c.r[0] &= 0x8Fu;  // 06020230 and #143,r0
    c.r[0] |= c.r[2];  // 06020232 or r2,r0
    st8(c.r[1], c.r[0]);  // 06020234 mov.b r0,@r1
    c.r[15] = c.r[14];  // 06020236 mov r14,r15
L_06020238:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06020240u);  // 06020238 mov.w 0x06020240,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602023A rts ; mov.l @r15+,r14
}

void f_06020250(SH2Context& c) {
    ran[379] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06020250 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06020252 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06020254 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06020256 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06020258 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0602025A mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602025C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602025E sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x060203DAu);  // 06020260 mov.w 0x060203DA,r3
    c.r[15] += c.r[3];  // 06020262 add r3,r15
    c.r[14] = c.r[15];  // 06020264 mov r15,r14
    c.r[1] = ld32(0x060203ECu);  // 06020266 mov.l 0x060203EC,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060203DCu);  // 06020268 mov.w 0x060203DC,r0
    c.r[0] += c.r[14];  // 0602026A add r14,r0
    c.r[12] = 0x0u;  // 0602026C mov #0,r12
    c.r[7] = (uint32_t)(int16_t)ld16(0x060203DEu);  // 0602026E mov.w 0x060203DE,r7
    c.r[7] += c.r[14];  // 06020270 add r14,r7
    c.r[11] = ld32(0x060203F0u);  // 06020272 mov.l 0x060203F0,r11
    c.r[10] = 0x0u;  // 06020274 mov #0,r10
    c.r[1] = ld32(c.r[1]);  // 06020276 mov.l @r1,r1
    c.r[9] = c.r[14];  // 06020278 mov r14,r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602027A mov.b @r1,r1
    c.r[13] = 0x0u;  // 0602027C mov #0,r13
    c.r[1] = c.r[1] & 0xFFu;  // 0602027E extu.b r1,r1
    st32(c.r[0], c.r[1]);  // 06020280 mov.l r1,@r0
    c.r[0] = 0x0u;  // 06020282 mov #0,r0
    st32(c.r[7], c.r[0]);  // 06020284 mov.l r0,@r7
L_06020286:
    c.r[3] = c.r[10];  // 06020286 mov r10,r3
    c.r[0] = ld32(c.r[11]);  // 06020288 mov.l @r11,r0
    c.r[2] = (uint32_t)(int16_t)ld16(0x060203E0u);  // 0602028A mov.w 0x060203E0,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 0602028C mov.b @(r0,r10),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602028E extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 06020290 cmp/eq r2,r1
    { const bool k = c.t; c.r[3] += c.r[0]; if (k) { goto L_06020314; } }  // 06020292 bt/s 0x06020314 ; add r0,r3
    c.r[1] = c.r[3];  // 06020296 mov r3,r1
    c.r[1] += 7;  // 06020298 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602029A mov.b @r1,r1
    c.r[0] = c.r[1];  // 0602029C mov r1,r0
    c.r[0] >>= 2;  // 0602029E shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060202A0 shlr r0
    c.r[0] &= 0x1u;  // 060202A2 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060202A4 tst r0,r0
    { const bool k = !c.t; c.r[3] += 4; if (k) { goto L_06020314; } }  // 060202A6 bf/s 0x06020314 ; add #4,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060202AA mov.b @r3,r1
    c.r[0] = c.r[1];  // 060202AC mov r1,r0
    c.r[0] >>= 2;  // 060202AE shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060202B0 shlr r0
    c.r[0] >>= 2;  // 060202B2 shlr2 r0
    c.r[0] &= 0x1u;  // 060202B4 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060202B6 tst r0,r0
    { const bool k = !c.t; c.r[0] = c.r[13]; if (k) { goto L_06020314; } }  // 060202B8 bf/s 0x06020314 ; mov r13,r0
    st8(c.r[0] + c.r[14], c.r[12]);  // 060202BC mov.b r12,@(r0,r14)
    c.r[8] = c.r[9];  // 060202BE mov r9,r8
    c.r[8] += 1;  // 060202C0 add #1,r8
    c.r[7] = 0x3u;  // 060202C2 mov #3,r7
    c.r[1] = ld32(c.r[11]);  // 060202C4 mov.l @r11,r1
    c.r[4] = 0x1u;  // 060202C6 mov #1,r4
    c.r[1] += c.r[10];  // 060202C8 add r10,r1
    c.r[1] += 3;  // 060202CA add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060202CC mov.b @r1,r1
    c.r[0] = ld32(0x060203F4u);  // 060202CE mov.l 0x060203F4,r0
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060202D0 shlr r1
    c.r[1] &= c.r[7];  // 060202D2 and r7,r1
    { const uint32_t x = c.r[0]; c.pr = 0x060202D8u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060202D8u) return; }  // 060202D4 jsr @r0 ; mov r1,r5
    c.r[1] = c.r[0];  // 060202D8 mov r0,r1
    st8(c.r[8], c.r[1]);  // 060202DA mov.b r1,@r8
    c.r[5] = c.r[12] & 0xFFu;  // 060202DC extu.b r12,r5
    c.r[7] = ld32(0x060203F8u);  // 060202DE mov.l 0x060203F8,r7
    { const uint32_t x = c.r[7]; c.pr = 0x060202E4u; c.r[4] = ld32(c.r[11]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060202E4u) return; }  // 060202E0 jsr @r7 ; mov.l @r11,r4
    c.r[1] = c.r[0];  // 060202E4 mov r0,r1
    c.r[3] = c.r[1] & 0xFFu;  // 060202E6 extu.b r1,r3
    c.r[2] = c.r[9];  // 060202E8 mov r9,r2
    c.r[2] += 2;  // 060202EA add #2,r2
    c.r[3] <<= 2;  // 060202EC shll2 r3
    c.r[3] <<= 2;  // 060202EE shll2 r3
    c.r[0] = c.r[3];  // 060202F0 mov r3,r0
    c.r[13] += 4;  // 060202F2 add #4,r13
    c.r[1] = ld32(c.r[11]);  // 060202F4 mov.l @r11,r1
    c.r[7] = (uint32_t)(int16_t)ld16(0x060203DEu);  // 060202F6 mov.w 0x060203DE,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060202F8 mov.b @(r0,r1),r1
    c.r[7] += c.r[14];  // 060202FA add r14,r7
    st8(c.r[2], c.r[1]);  // 060202FC mov.b r1,@r2
    c.r[1] = ld32(c.r[11]);  // 060202FE mov.l @r11,r1
    c.r[2] = c.r[9];  // 06020300 mov r9,r2
    c.r[3] += c.r[1];  // 06020302 add r1,r3
    c.r[3] += 1;  // 06020304 add #1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06020306 mov.b @r3,r1
    c.r[2] += 3;  // 06020308 add #3,r2
    st8(c.r[2], c.r[1]);  // 0602030A mov.b r1,@r2
    c.r[0] = ld32(c.r[7]);  // 0602030C mov.l @r7,r0
    c.r[9] += 4;  // 0602030E add #4,r9
    c.r[0] += 1;  // 06020310 add #1,r0
    st32(c.r[7], c.r[0]);  // 06020312 mov.l r0,@r7
L_06020314:
    c.r[12] += 1;  // 06020314 add #1,r12
    c.r[1] = 0x49u;  // 06020316 mov #73,r1
    c.t = (int32_t)c.r[12] > (int32_t)c.r[1];  // 06020318 cmp/gt r1,r12
    { const bool k = !c.t; c.r[10] += 16; if (k) { SH2_POLL(c); goto L_06020286; } }  // 0602031A bf/s 0x06020286 ; add #16,r10
    c.r[9] = (uint32_t)(int16_t)ld16(0x060203E0u);  // 0602031E mov.w 0x060203E0,r9
    c.r[0] = 0xFFFFFFFFu;  // 06020320 mov #-1,r0
    c.r[7] = (uint32_t)(int16_t)ld16(0x060203E2u);  // 06020322 mov.w 0x060203E2,r7
    c.r[7] += c.r[14];  // 06020324 add r14,r7
    st32(c.r[7], c.r[0]);  // 06020326 mov.l r0,@r7
    c.r[7] = (uint32_t)(int16_t)ld16(0x060203DEu);  // 06020328 mov.w 0x060203DE,r7
    c.r[7] += c.r[14];  // 0602032A add r14,r7
    c.r[7] = ld32(c.r[7]);  // 0602032C mov.l @r7,r7
    c.r[12] = 0x0u;  // 0602032E mov #0,r12
    c.t = (int32_t)c.r[12] >= (int32_t)c.r[7];  // 06020330 cmp/ge r7,r12
    { const bool k = !c.t; c.r[11] = c.r[9]; if (k) { goto L_0602033A; } }  // 06020332 bf/s 0x0602033A ; mov r9,r11
    goto L_060204CA;  // 06020336 bra 0x060204CA ; nop
L_0602033A:
    c.r[13] = c.r[14];  // 0602033A mov r14,r13
    c.r[7] = 0x0u;  // 0602033C mov #0,r7
    c.r[0] = (uint32_t)(int16_t)ld16(0x060203E4u);  // 0602033E mov.w 0x060203E4,r0
    st32(c.r[0] + c.r[14], c.r[7]);  // 06020340 mov.l r7,@(r0,r14)
L_06020342:
    c.r[7] = (uint32_t)(int16_t)ld16(0x060203E4u);  // 06020342 mov.w 0x060203E4,r7
    c.r[7] += c.r[14];  // 06020344 add r14,r7
    c.r[0] = ld32(c.r[7]);  // 06020346 mov.l @r7,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 06020348 mov.b @(r0,r14),r1
    c.r[10] = c.r[1] & 0xFFu;  // 0602034A extu.b r1,r10
    c.r[1] = ld32(0x060203F0u);  // 0602034C mov.l 0x060203F0,r1
    c.r[8] = c.r[10];  // 0602034E mov r10,r8
    c.r[1] = ld32(c.r[1]);  // 06020350 mov.l @r1,r1
    c.r[8] <<= 2;  // 06020352 shll2 r8
    c.r[8] <<= 2;  // 06020354 shll2 r8
    c.r[8] += c.r[1];  // 06020356 add r1,r8
    c.r[1] = c.r[8];  // 06020358 mov r8,r1
    c.r[1] += 7;  // 0602035A add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602035C mov.b @r1,r1
    c.r[0] = 0x1u;  // 0602035E mov #1,r0
    c.r[1] >>= 2;  // 06020360 shlr2 r1
    c.r[1] >>= 2;  // 06020362 shlr2 r1
    c.r[1] &= c.r[0];  // 06020364 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06020366 tst r1,r1
    if (c.t) { goto L_0602036E; }  // 06020368 bt 0x0602036E
    goto L_060204B0;  // 0602036A bra 0x060204B0 ; nop
L_0602036E:
    c.r[1] = ld32(c.r[8] + 12);  // 0602036E mov.l @(12,r8),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06020370 tst r1,r1
    { const bool k = !c.t; c.r[1] = c.r[8]; if (k) { goto L_0602037A; } }  // 06020372 bf/s 0x0602037A ; mov r8,r1
    goto L_060204B0;  // 06020376 bra 0x060204B0 ; nop
L_0602037A:
    c.r[1] += 3;  // 0602037A add #3,r1
    c.r[7] = 0x3u;  // 0602037C mov #3,r7
    c.r[0] = (uint32_t)(int16_t)ld16(0x060203DCu);  // 0602037E mov.w 0x060203DC,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06020380 mov.b @r1,r1
    c.r[4] = ld32(c.r[0] + c.r[14]);  // 06020382 mov.l @(r0,r14),r4
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06020384 shlr r1
    c.r[1] &= c.r[7];  // 06020386 and r7,r1
    c.r[7] = ld32(0x060203FCu);  // 06020388 mov.l 0x060203FC,r7
    { const uint32_t x = c.r[7]; c.pr = 0x0602038Eu; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602038Eu) return; }  // 0602038A jsr @r7 ; mov r1,r5
    c.r[1] = c.r[0];  // 0602038E mov r0,r1
    c.r[0] = 0x1u;  // 06020390 mov #1,r0
    c.r[1] &= c.r[0];  // 06020392 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06020394 tst r1,r1
    { const bool k = !c.t; c.r[8] += 4; if (k) { goto L_0602039E; } }  // 06020396 bf/s 0x0602039E ; add #4,r8
    goto L_060204B0;  // 0602039A bra 0x060204B0 ; nop
L_0602039E:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0602039E mov.b @r8,r1
    c.r[7] = 0xFu;  // 060203A0 mov #15,r7
    c.r[4] = c.r[1];  // 060203A2 mov r1,r4
    c.t = c.r[4] & 1; c.r[4] >>= 1;  // 060203A4 shlr r4
    c.r[4] &= c.r[7];  // 060203A6 and r7,r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 060203A8 tst r4,r4
    if (!c.t) { goto L_060203AE; }  // 060203AA bf 0x060203AE
    c.r[4] = 0x7u;  // 060203AC mov #7,r4
L_060203AE:
    c.r[1] = c.r[13];  // 060203AE mov r13,r1
    c.r[1] += 2;  // 060203B0 add #2,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060203E6u);  // 060203B2 mov.w 0x060203E6,r0
    c.r[0] += c.r[14];  // 060203B4 add r14,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060203B6 mov.b @r1,r1
    c.r[7] = (uint32_t)(int16_t)ld16(0x060203DEu);  // 060203B8 mov.w 0x060203DE,r7
    c.r[1] = c.r[1] & 0xFFu;  // 060203BA extu.b r1,r1
    st32(c.r[0], c.r[1]);  // 060203BC mov.l r1,@r0
    c.r[1] = c.r[13];  // 060203BE mov r13,r1
    c.r[1] += 3;  // 060203C0 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060203C2 mov.b @r1,r1
    c.r[7] += c.r[14];  // 060203C4 add r14,r7
    c.r[7] = ld32(c.r[7]);  // 060203C6 mov.l @r7,r7
    c.r[8] = c.r[1] & 0xFFu;  // 060203C8 extu.b r1,r8
    c.r[1] = 0x0u;  // 060203CA mov #0,r1
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[7];  // 060203CC cmp/ge r7,r1
    if (c.t) { goto L_06020496; }  // 060203CE bt 0x06020496
    c.r[6] = c.r[14];  // 060203D0 mov r14,r6
    c.r[7] = 0x0u;  // 060203D2 mov #0,r7
    c.r[0] = (uint32_t)(int16_t)ld16(0x060203E8u);  // 060203D4 mov.w 0x060203E8,r0
    c.r[0] += c.r[14]; goto L_06020400;  // 060203D6 bra 0x06020400 ; add r14,r0
L_06020400:
    st32(c.r[0], c.r[7]);  // 06020400 mov.l r7,@r0
L_06020402:
    c.r[7] = (uint32_t)(int16_t)ld16(0x060204A4u);  // 06020402 mov.w 0x060204A4,r7
    c.r[7] += c.r[14];  // 06020404 add r14,r7
    c.r[0] = ld32(c.r[7]);  // 06020406 mov.l @r7,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 06020408 mov.b @(r0,r14),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602040A extu.b r1,r1
    c.t = c.r[10] == c.r[1];  // 0602040C cmp/eq r1,r10
    { const bool k = c.t; c.r[1] = c.r[6]; if (k) { goto L_0602047C; } }  // 0602040E bt/s 0x0602047C ; mov r6,r1
    c.r[1] += 1;  // 06020412 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06020414 mov.b @r1,r1
    c.r[1] &= c.r[4];  // 06020416 and r4,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06020418 tst r1,r1
    if (c.t) { goto L_0602047C; }  // 0602041A bt 0x0602047C
    c.r[5] = c.r[9];  // 0602041C mov r9,r5
    c.r[5] += c.r[11];  // 0602041E add r11,r5
    c.r[1] = c.r[6];  // 06020420 mov r6,r1
    c.r[1] += 2;  // 06020422 add #2,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060204A6u);  // 06020424 mov.w 0x060204A6,r0
    c.r[0] += c.r[14];  // 06020426 add r14,r0
    c.r[7] = (uint32_t)(int16_t)ld16(0x060204A8u);  // 06020428 mov.w 0x060204A8,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602042A mov.b @r1,r1
    c.r[7] += c.r[14];  // 0602042C add r14,r7
    c.r[3] = ld32(c.r[0]);  // 0602042E mov.l @r0,r3
    c.r[1] = c.r[1] & 0xFFu;  // 06020430 extu.b r1,r1
    c.r[3] -= c.r[1];  // 06020432 sub r1,r3
    c.t = (int32_t)c.r[3] >= 0;  // 06020434 cmp/pz r3
    { const bool k = c.t; st32(c.r[7], c.r[3]); if (k) { goto L_06020440; } }  // 06020436 bt/s 0x06020440 ; mov.l r3,@r7
    c.r[7] = 0u - c.r[3];  // 0602043A neg r3,r7
    c.r[0] = (uint32_t)(int16_t)ld16(0x060204A8u);  // 0602043C mov.w 0x060204A8,r0
    st32(c.r[0] + c.r[14], c.r[7]);  // 0602043E mov.l r7,@(r0,r14)
L_06020440:
    c.r[1] = c.r[6];  // 06020440 mov r6,r1
    c.r[1] += 3;  // 06020442 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06020444 mov.b @r1,r1
    c.r[2] = c.r[8];  // 06020446 mov r8,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06020448 extu.b r1,r1
    c.r[2] -= c.r[1];  // 0602044A sub r1,r2
    c.t = (int32_t)c.r[2] >= 0;  // 0602044C cmp/pz r2
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_06020454; } }  // 0602044E bt/s 0x06020454 ; mov r2,r1
    c.r[1] = 0u - c.r[2];  // 06020452 neg r2,r1
L_06020454:
    c.r[0] = (uint32_t)(int16_t)ld16(0x060204A8u);  // 06020454 mov.w 0x060204A8,r0
    c.r[0] += c.r[14];  // 06020456 add r14,r0
    c.r[7] = ld32(c.r[0]);  // 06020458 mov.l @r0,r7
    c.r[7] += c.r[1];  // 0602045A add r1,r7
    st32(c.r[0], c.r[7]);  // 0602045C mov.l r7,@r0
    c.r[0] = (uint32_t)(int16_t)ld16(0x060204A8u);  // 0602045E mov.w 0x060204A8,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06020460 mov.l @(r0,r14),r0
    c.t = (int32_t)c.r[5] > (int32_t)c.r[0];  // 06020462 cmp/gt r0,r5
    if (!c.t) { goto L_0602047C; }  // 06020464 bf 0x0602047C
    c.r[9] = c.r[3];  // 06020466 mov r3,r9
    c.r[7] = (uint32_t)(int16_t)ld16(0x060204AAu);  // 06020468 mov.w 0x060204AA,r7
    c.r[7] += c.r[14];  // 0602046A add r14,r7
    c.t = (int32_t)c.r[9] >= 0;  // 0602046C cmp/pz r9
    { const bool k = c.t; st32(c.r[7], c.r[10]); if (k) { goto L_06020474; } }  // 0602046E bt/s 0x06020474 ; mov.l r10,@r7
    c.r[9] = 0u - c.r[9];  // 06020472 neg r9,r9
L_06020474:
    c.r[11] = c.r[2];  // 06020474 mov r2,r11
    c.t = (int32_t)c.r[11] >= 0;  // 06020476 cmp/pz r11
    if (c.t) { goto L_0602047C; }  // 06020478 bt 0x0602047C
    c.r[11] = 0u - c.r[11];  // 0602047A neg r11,r11
L_0602047C:
    c.r[0] = (uint32_t)(int16_t)ld16(0x060204A4u);  // 0602047C mov.w 0x060204A4,r0
    c.r[0] += c.r[14];  // 0602047E add r14,r0
    c.r[7] = ld32(c.r[0]);  // 06020480 mov.l @r0,r7
    c.r[7] += 4;  // 06020482 add #4,r7
    st32(c.r[0], c.r[7]);  // 06020484 mov.l r7,@r0
    c.r[0] = (uint32_t)(int16_t)ld16(0x060204ACu);  // 06020486 mov.w 0x060204AC,r0
    c.r[0] += c.r[14];  // 06020488 add r14,r0
    c.r[1] = ld32(c.r[0]);  // 0602048A mov.l @r0,r1
    c.r[6] += 4;  // 0602048C add #4,r6
    c.r[1] <<= 2;  // 0602048E shll2 r1
    c.r[1] += c.r[14];  // 06020490 add r14,r1
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[1];  // 06020492 cmp/ge r1,r6
    if (!c.t) { SH2_POLL(c); goto L_06020402; }  // 06020494 bf 0x06020402
L_06020496:
    c.r[1] = (uint32_t)(int16_t)ld16(0x060204AEu);  // 06020496 mov.w 0x060204AE,r1
    c.t = c.r[9] == c.r[1];  // 06020498 cmp/eq r1,r9
    if (!c.t) { goto L_060204B0; }  // 0602049A bf 0x060204B0
    c.r[7] = (uint32_t)(int16_t)ld16(0x060204AAu);  // 0602049C mov.w 0x060204AA,r7
    c.r[7] += c.r[14];  // 0602049E add r14,r7
    st32(c.r[7], c.r[10]); goto L_060204CA;  // 060204A0 bra 0x060204CA ; mov.l r10,@r7
L_060204B0:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602057Au);  // 060204B0 mov.w 0x0602057A,r0
    c.r[0] += c.r[14];  // 060204B2 add r14,r0
    c.r[7] = ld32(c.r[0]);  // 060204B4 mov.l @r0,r7
    c.r[7] += 4;  // 060204B6 add #4,r7
    st32(c.r[0], c.r[7]);  // 060204B8 mov.l r7,@r0
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602057Cu);  // 060204BA mov.w 0x0602057C,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 060204BC mov.l @(r0,r14),r0
    c.r[12] += 1;  // 060204BE add #1,r12
    c.t = (int32_t)c.r[12] >= (int32_t)c.r[0];  // 060204C0 cmp/ge r0,r12
    { const bool k = c.t; c.r[13] += 4; if (k) { goto L_060204CA; } }  // 060204C2 bt/s 0x060204CA ; add #4,r13
    SH2_POLL(c); goto L_06020342;  // 060204C6 bra 0x06020342 ; nop
L_060204CA:
    c.r[1] = ld32(0x06020588u);  // 060204CA mov.l 0x06020588,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060204D0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060204D0u) return; }  // 060204CC jsr @r1 ; nop
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602057Eu);  // 060204D0 mov.w 0x0602057E,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 060204D2 mov.l @(r0,r14),r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 060204D4 cmp/eq #-1,r0
    if (c.t) { goto L_06020560; }  // 060204D6 bt 0x06020560
    c.r[8] = ld32(0x0602058Cu);  // 060204D8 mov.l 0x0602058C,r8
    c.r[1] = ld32(0x06020590u);  // 060204DA mov.l 0x06020590,r1
    c.r[3] = c.r[1];  // 060204DC mov r1,r3
    c.r[3] += 33;  // 060204DE add #33,r3
    c.r[2] = c.r[1];  // 060204E0 mov r1,r2
    c.r[2] += 32;  // 060204E2 add #32,r2
    c.r[7] = (uint32_t)(int16_t)ld16(0x06020580u);  // 060204E4 mov.w 0x06020580,r7
    c.r[7] += c.r[14];  // 060204E6 add r14,r7
    c.r[6] = c.r[1];  // 060204E8 mov r1,r6
    c.r[6] += 24;  // 060204EA add #24,r6
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[7]);  // 060204EC mov.b @r7,r4
    c.r[0] = ld32(0x06020594u);  // 060204EE mov.l 0x06020594,r0
    st8(c.r[2], c.r[4]);  // 060204F0 mov.b r4,@r2
    st8(c.r[3], c.r[4]);  // 060204F2 mov.b r4,@r3
    st8(c.r[8], c.r[4]);  // 060204F4 mov.b r4,@r8
    c.r[2] = c.r[1];  // 060204F6 mov r1,r2
    c.r[2] += 30;  // 060204F8 add #30,r2
    c.r[3] = 0xFFFFFFFFu;  // 060204FA mov #-1,r3
    st8(c.r[2], c.r[3]);  // 060204FC mov.b r3,@r2
    c.r[2] = 0xFFFFFFFFu;  // 060204FE mov #-1,r2
    st32(c.r[1] + 16, c.r[2]);  // 06020500 mov.l r2,@(16,r1)
    st32(c.r[1] + 12, c.r[2]);  // 06020502 mov.l r2,@(12,r1)
    st8(c.r[0], c.r[3]);  // 06020504 mov.b r3,@r0
    c.r[1] = 0xFFFFFFFFu;  // 06020506 mov #-1,r1
    st16(c.r[6], c.r[1]);  // 06020508 mov.w r1,@r6
    c.r[1] = ld32(0x06020598u);  // 0602050A mov.l 0x06020598,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06020510u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06020510u) return; }  // 0602050C jsr @r1 ; extu.b r4,r4
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06020510 mov.b @r8,r6
    c.r[9] = ld32(0x0602059Cu);  // 06020512 mov.l 0x0602059C,r9
    c.r[1] = ld32(c.r[9]);  // 06020514 mov.l @r9,r1
    c.r[6] = c.r[6] & 0xFFu;  // 06020516 extu.b r6,r6
    c.r[2] = c.r[6];  // 06020518 mov r6,r2
    c.r[2] <<= 2;  // 0602051A shll2 r2
    c.r[2] <<= 2;  // 0602051C shll2 r2
    c.r[2] += c.r[1];  // 0602051E add r1,r2
    c.r[2] += 2;  // 06020520 add #2,r2
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06020522 mov.b @r2,r5
    c.r[1] = ld32(0x060205A0u);  // 06020524 mov.l 0x060205A0,r1
    c.r[4] = ld32(c.r[1]);  // 06020526 mov.l @r1,r4
    c.r[1] = ld32(0x060205A4u);  // 06020528 mov.l 0x060205A4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602052Eu; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602052Eu) return; }  // 0602052A jsr @r1 ; extu.b r5,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0602052E mov.b @r8,r1
    c.r[2] = ld32(c.r[9]);  // 06020530 mov.l @r9,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06020532 extu.b r1,r1
    c.r[1] <<= 2;  // 06020534 shll2 r1
    c.r[1] <<= 2;  // 06020536 shll2 r1
    c.r[1] += c.r[2];  // 06020538 add r2,r1
    c.r[1] += 2;  // 0602053A add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602053C mov.b @r1,r2
    c.r[1] = ld32(0x060205A8u);  // 0602053E mov.l 0x060205A8,r1
    c.r[3] = ld32(c.r[1]);  // 06020540 mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06020542 extu.b r2,r2
    c.r[1] = 0x1Eu;  // 06020544 mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 06020546 mul.l r1,r2
    c.r[1] = c.macl;  // 06020548 sts macl,r1
    c.r[1] += c.r[3];  // 0602054A add r3,r1
    c.r[1] += 15;  // 0602054C add #15,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602054E mov.b @r1,r5
    c.r[1] = ld32(0x060205ACu);  // 06020550 mov.l 0x060205AC,r1
    c.r[4] = ld32(c.r[1]);  // 06020552 mov.l @r1,r4
    c.r[1] = ld32(0x060205B0u);  // 06020554 mov.l 0x060205B0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602055Au; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602055Au) return; }  // 06020556 jsr @r1 ; extu.b r5,r5
    c.r[1] = ld32(0x060205B4u);  // 0602055A mov.l 0x060205B4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06020560u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06020560u) return; }  // 0602055C jsr @r1 ; nop
L_06020560:
    c.r[3] = (uint32_t)(int16_t)ld16(0x06020582u);  // 06020560 mov.w 0x06020582,r3
    c.r[14] += c.r[3];  // 06020562 add r3,r14
    c.r[15] = c.r[14];  // 06020564 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06020566 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06020568 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0602056A mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0602056C mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0602056E mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06020570 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06020572 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06020584u);  // 06020574 mov.w 0x06020584,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06020576 rts ; mov.l @r15+,r8
}

void f_060205B8(SH2Context& c) {
    ran[380] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060205B8 mov.l r14,@-r15
    c.r[7] = ld32(0x06020614u);  // 060205BA mov.l 0x06020614,r7
    c.r[1] = ld32(c.r[7]);  // 060205BC mov.l @r7,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 060205BE mov.b @r1+,r2
    c.r[14] = c.r[15];  // 060205C0 mov r15,r14
    c.r[2] = c.r[2] & 0xFFu;  // 060205C2 extu.b r2,r2
    c.r[3] = c.r[1];  // 060205C4 mov r1,r3
    c.t = (c.r[2] & c.r[2]) == 0;  // 060205C6 tst r2,r2
    { const bool k = c.t; st32(c.r[7], c.r[3]); if (k) { goto L_060205DA; } }  // 060205C8 bt/s 0x060205DA ; mov.l r3,@r7
    c.r[1] = ld32(0x06020618u);  // 060205CC mov.l 0x06020618,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060205CE mov.b @r1,r0
    c.r[0] &= 0x7Fu;  // 060205D0 and #127,r0
    st8(c.r[1], c.r[0]);  // 060205D2 mov.b r0,@r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602060Eu);  // 060205D4 mov.w 0x0602060E,r0
    c.r[15] = c.r[14]; goto L_0602060A;  // 060205D6 bra 0x0602060A ; mov r14,r15
L_060205DA:
    c.r[1] = ld32(0x06020618u);  // 060205DA mov.l 0x06020618,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060205DC mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060205DE extu.b r1,r1
    c.r[1] >>= 2;  // 060205E0 shlr2 r1
    c.r[1] >>= 2;  // 060205E2 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060205E4 shlr r1
    c.r[1] >>= 2;  // 060205E6 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060205E8 tst r1,r1
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_060205F4; } }  // 060205EA bt/s 0x060205F4 ; mov r3,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06020610u);  // 060205EE mov.w 0x06020610,r0
    c.r[15] = c.r[14]; goto L_0602060A;  // 060205F0 bra 0x0602060A ; mov r14,r15
L_060205F4:
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 060205F4 mov.b @r1+,r2
    c.r[0] = ld32(0x0602061Cu);  // 060205F6 mov.l 0x0602061C,r0
    c.r[2] = c.r[2] & 0xFFu;  // 060205F8 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060205FA mov.b @r1,r1
    c.r[2] <<= 8;  // 060205FC shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 060205FE extu.b r1,r1
    c.r[2] |= c.r[1];  // 06020600 or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 06020602 exts.w r2,r2
    c.r[3] += c.r[2];  // 06020604 add r2,r3
    st32(c.r[7], c.r[3]);  // 06020606 mov.l r3,@r7
    c.r[15] = c.r[14];  // 06020608 mov r14,r15
L_0602060A:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602060A rts ; mov.l @r15+,r14
}

void f_06020620(SH2Context& c) {
    ran[381] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06020620 mov.l r14,@-r15
    c.r[7] = ld32(0x0602067Cu);  // 06020622 mov.l 0x0602067C,r7
    c.r[1] = ld32(c.r[7]);  // 06020624 mov.l @r7,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 06020626 mov.b @r1+,r2
    c.r[14] = c.r[15];  // 06020628 mov r15,r14
    c.r[2] = c.r[2] & 0xFFu;  // 0602062A extu.b r2,r2
    c.r[3] = c.r[1];  // 0602062C mov r1,r3
    c.t = (c.r[2] & c.r[2]) == 0;  // 0602062E tst r2,r2
    { const bool k = c.t; st32(c.r[7], c.r[3]); if (k) { goto L_06020642; } }  // 06020630 bt/s 0x06020642 ; mov.l r3,@r7
    c.r[1] = ld32(0x06020680u);  // 06020634 mov.l 0x06020680,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06020636 mov.b @r1,r0
    c.r[0] |= 0x80u;  // 06020638 or #128,r0
    st8(c.r[1], c.r[0]);  // 0602063A mov.b r0,@r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06020676u);  // 0602063C mov.w 0x06020676,r0
    c.r[15] = c.r[14]; goto L_06020672;  // 0602063E bra 0x06020672 ; mov r14,r15
L_06020642:
    c.r[1] = ld32(0x06020680u);  // 06020642 mov.l 0x06020680,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06020644 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06020646 extu.b r1,r1
    c.r[1] >>= 2;  // 06020648 shlr2 r1
    c.r[1] >>= 2;  // 0602064A shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0602064C shlr r1
    c.r[1] >>= 2;  // 0602064E shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06020650 tst r1,r1
    { const bool k = !c.t; c.r[15] = c.r[14]; if (k) { goto L_0602065C; } }  // 06020652 bf/s 0x0602065C ; mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x06020678u);  // 06020656 mov.w 0x06020678,r0
    goto L_06020672;  // 06020658 bra 0x06020672 ; nop
L_0602065C:
    c.r[1] = c.r[3];  // 0602065C mov r3,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0602065E mov.b @r1+,r2
    c.r[0] = ld32(0x06020684u);  // 06020660 mov.l 0x06020684,r0
    c.r[2] = c.r[2] & 0xFFu;  // 06020662 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06020664 mov.b @r1,r1
    c.r[2] <<= 8;  // 06020666 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06020668 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0602066A or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0602066C exts.w r2,r2
    c.r[3] += c.r[2];  // 0602066E add r2,r3
    st32(c.r[7], c.r[3]);  // 06020670 mov.l r3,@r7
L_06020672:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06020672 rts ; mov.l @r15+,r14
}

void f_06020688(SH2Context& c) {
    ran[382] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06020688 mov.l r14,@-r15
    c.r[6] = ld32(0x060206D0u);  // 0602068A mov.l 0x060206D0,r6
    c.r[7] = ld32(c.r[6]);  // 0602068C mov.l @r6,r7
    c.r[1] = c.r[7];  // 0602068E mov r7,r1
    c.r[1] += 2;  // 06020690 add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06020692 mov.b @r1,r2
    c.r[3] = ld32(0x060206D4u);  // 06020694 mov.l 0x060206D4,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06020696 extu.b r2,r2
    c.r[1] = c.r[7];  // 06020698 mov r7,r1
    c.r[1] += 3;  // 0602069A add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602069C mov.b @r1,r1
    c.r[2] <<= 8;  // 0602069E shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 060206A0 extu.b r1,r1
    c.r[2] |= c.r[1];  // 060206A2 or r1,r2
    c.r[1] = ld32(c.r[3] + 20);  // 060206A4 mov.l @(20,r3),r1
    c.t = c.r[1] == c.r[2];  // 060206A6 cmp/eq r2,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_060206B2; } }  // 060206A8 bt/s 0x060206B2 ; mov r15,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x060206CEu);  // 060206AC mov.w 0x060206CE,r0
    c.r[15] = c.r[14]; goto L_060206CA;  // 060206AE bra 0x060206CA ; mov r14,r15
L_060206B2:
    c.r[1] = c.r[7];  // 060206B2 mov r7,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 060206B4 mov.b @r1+,r2
    c.r[0] = ld32(0x060206D8u);  // 060206B6 mov.l 0x060206D8,r0
    c.r[2] = c.r[2] & 0xFFu;  // 060206B8 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060206BA mov.b @r1,r1
    c.r[2] <<= 8;  // 060206BC shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 060206BE extu.b r1,r1
    c.r[2] |= c.r[1];  // 060206C0 or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 060206C2 exts.w r2,r2
    c.r[7] += c.r[2];  // 060206C4 add r2,r7
    st32(c.r[6], c.r[7]);  // 060206C6 mov.l r7,@r6
    c.r[15] = c.r[14];  // 060206C8 mov r14,r15
L_060206CA:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060206CA rts ; mov.l @r15+,r14
}

void f_060206DC(SH2Context& c) {
    ran[383] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060206DC mov.l r14,@-r15
    c.r[6] = ld32(0x06020724u);  // 060206DE mov.l 0x06020724,r6
    c.r[7] = ld32(c.r[6]);  // 060206E0 mov.l @r6,r7
    c.r[1] = c.r[7];  // 060206E2 mov r7,r1
    c.r[1] += 2;  // 060206E4 add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060206E6 mov.b @r1,r2
    c.r[3] = ld32(0x06020728u);  // 060206E8 mov.l 0x06020728,r3
    c.r[2] = c.r[2] & 0xFFu;  // 060206EA extu.b r2,r2
    c.r[1] = c.r[7];  // 060206EC mov r7,r1
    c.r[1] += 3;  // 060206EE add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060206F0 mov.b @r1,r1
    c.r[2] <<= 8;  // 060206F2 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 060206F4 extu.b r1,r1
    c.r[2] |= c.r[1];  // 060206F6 or r1,r2
    c.r[1] = ld32(c.r[3] + 20);  // 060206F8 mov.l @(20,r3),r1
    c.t = c.r[1] == c.r[2];  // 060206FA cmp/eq r2,r1
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_06020706; } }  // 060206FC bf/s 0x06020706 ; mov r15,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x06020722u);  // 06020700 mov.w 0x06020722,r0
    c.r[15] = c.r[14]; goto L_0602071E;  // 06020702 bra 0x0602071E ; mov r14,r15
L_06020706:
    c.r[1] = c.r[7];  // 06020706 mov r7,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 06020708 mov.b @r1+,r2
    c.r[0] = ld32(0x0602072Cu);  // 0602070A mov.l 0x0602072C,r0
    c.r[2] = c.r[2] & 0xFFu;  // 0602070C extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602070E mov.b @r1,r1
    c.r[2] <<= 8;  // 06020710 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06020712 extu.b r1,r1
    c.r[2] |= c.r[1];  // 06020714 or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 06020716 exts.w r2,r2
    c.r[7] += c.r[2];  // 06020718 add r2,r7
    st32(c.r[6], c.r[7]);  // 0602071A mov.l r7,@r6
    c.r[15] = c.r[14];  // 0602071C mov r14,r15
L_0602071E:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602071E rts ; mov.l @r15+,r14
}

void f_06020730(SH2Context& c) {
    ran[384] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06020730 mov.l r14,@-r15
    c.r[6] = ld32(0x06020778u);  // 06020732 mov.l 0x06020778,r6
    c.r[7] = ld32(c.r[6]);  // 06020734 mov.l @r6,r7
    c.r[1] = c.r[7];  // 06020736 mov r7,r1
    c.r[1] += 2;  // 06020738 add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602073A mov.b @r1,r2
    c.r[3] = ld32(0x0602077Cu);  // 0602073C mov.l 0x0602077C,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0602073E extu.b r2,r2
    c.r[1] = c.r[7];  // 06020740 mov r7,r1
    c.r[1] += 3;  // 06020742 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06020744 mov.b @r1,r1
    c.r[2] <<= 8;  // 06020746 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06020748 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0602074A or r1,r2
    c.r[1] = ld32(c.r[3] + 20);  // 0602074C mov.l @(20,r3),r1
    c.t = c.r[1] > c.r[2];  // 0602074E cmp/hi r2,r1
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0602075A; } }  // 06020750 bf/s 0x0602075A ; mov r15,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x06020776u);  // 06020754 mov.w 0x06020776,r0
    c.r[15] = c.r[14]; goto L_06020772;  // 06020756 bra 0x06020772 ; mov r14,r15
L_0602075A:
    c.r[1] = c.r[7];  // 0602075A mov r7,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0602075C mov.b @r1+,r2
    c.r[0] = ld32(0x06020780u);  // 0602075E mov.l 0x06020780,r0
    c.r[2] = c.r[2] & 0xFFu;  // 06020760 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06020762 mov.b @r1,r1
    c.r[2] <<= 8;  // 06020764 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06020766 extu.b r1,r1
    c.r[2] |= c.r[1];  // 06020768 or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 0602076A exts.w r2,r2
    c.r[7] += c.r[2];  // 0602076C add r2,r7
    st32(c.r[6], c.r[7]);  // 0602076E mov.l r7,@r6
    c.r[15] = c.r[14];  // 06020770 mov r14,r15
L_06020772:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06020772 rts ; mov.l @r15+,r14
}

void f_06020784(SH2Context& c) {
    ran[385] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06020784 mov.l r14,@-r15
    c.r[6] = ld32(0x060207CCu);  // 06020786 mov.l 0x060207CC,r6
    c.r[7] = ld32(c.r[6]);  // 06020788 mov.l @r6,r7
    c.r[1] = c.r[7];  // 0602078A mov r7,r1
    c.r[1] += 2;  // 0602078C add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602078E mov.b @r1,r2
    c.r[3] = ld32(0x060207D0u);  // 06020790 mov.l 0x060207D0,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06020792 extu.b r2,r2
    c.r[1] = c.r[7];  // 06020794 mov r7,r1
    c.r[1] += 3;  // 06020796 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06020798 mov.b @r1,r1
    c.r[2] <<= 8;  // 0602079A shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0602079C extu.b r1,r1
    c.r[2] |= c.r[1];  // 0602079E or r1,r2
    c.r[1] = ld32(c.r[3] + 20);  // 060207A0 mov.l @(20,r3),r1
    c.t = c.r[1] >= c.r[2];  // 060207A2 cmp/hs r2,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_060207AE; } }  // 060207A4 bt/s 0x060207AE ; mov r15,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x060207CAu);  // 060207A8 mov.w 0x060207CA,r0
    c.r[15] = c.r[14]; goto L_060207C6;  // 060207AA bra 0x060207C6 ; mov r14,r15
L_060207AE:
    c.r[1] = c.r[7];  // 060207AE mov r7,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 060207B0 mov.b @r1+,r2
    c.r[0] = ld32(0x060207D4u);  // 060207B2 mov.l 0x060207D4,r0
    c.r[2] = c.r[2] & 0xFFu;  // 060207B4 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060207B6 mov.b @r1,r1
    c.r[2] <<= 8;  // 060207B8 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 060207BA extu.b r1,r1
    c.r[2] |= c.r[1];  // 060207BC or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 060207BE exts.w r2,r2
    c.r[7] += c.r[2];  // 060207C0 add r2,r7
    st32(c.r[6], c.r[7]);  // 060207C2 mov.l r7,@r6
    c.r[15] = c.r[14];  // 060207C4 mov r14,r15
L_060207C6:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060207C6 rts ; mov.l @r15+,r14
}

void f_060207D8(SH2Context& c) {
    ran[386] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060207D8 mov.l r14,@-r15
    c.r[1] = ld32(0x06020810u);  // 060207DA mov.l 0x06020810,r1
    c.r[1] = ld32(c.r[1]);  // 060207DC mov.l @r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060207DE mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060207E0 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060207E2 tst r1,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_060207F8; } }  // 060207E4 bt/s 0x060207F8 ; mov r15,r14
    c.r[1] = ld32(0x06020814u);  // 060207E8 mov.l 0x06020814,r1
    c.r[0] = ld32(c.r[1] + 20);  // 060207EA mov.l @(20,r1),r0
    c.r[0] &= 0x1u;  // 060207EC and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060207EE tst r0,r0
    if (!c.t) { goto L_06020802; }  // 060207F0 bf 0x06020802
L_060207F2:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602080Au);  // 060207F2 mov.w 0x0602080A,r0
    c.r[15] = c.r[14]; goto L_06020806;  // 060207F4 bra 0x06020806 ; mov r14,r15
L_060207F8:
    c.r[1] = ld32(0x06020814u);  // 060207F8 mov.l 0x06020814,r1
    c.r[0] = ld32(c.r[1] + 20);  // 060207FA mov.l @(20,r1),r0
    c.r[0] &= 0x1u;  // 060207FC and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060207FE tst r0,r0
    if (!c.t) { SH2_POLL(c); goto L_060207F2; }  // 06020800 bf 0x060207F2
L_06020802:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602080Cu);  // 06020802 mov.w 0x0602080C,r0
    c.r[15] = c.r[14];  // 06020804 mov r14,r15
L_06020806:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06020806 rts ; mov.l @r15+,r14
}

void f_06020818(SH2Context& c) {
    ran[387] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06020818 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602081A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0602081C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0602081E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06020820 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06020822 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06020824 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06020826 sts.l pr,@-r15
    c.r[15] -= 4;  // 06020828 add #-4,r15
    c.r[14] = c.r[15];  // 0602082A mov r15,r14
    c.r[0] = 0x0u;  // 0602082C mov #0,r0
    st32(c.r[14], c.r[0]);  // 0602082E mov.l r0,@r14
    c.r[1] = ld32(0x06020968u);  // 06020830 mov.l 0x06020968,r1
    c.r[2] = ld32(c.r[1]);  // 06020832 mov.l @r1,r2
    c.r[10] = c.r[4] & 0xFFu;  // 06020834 extu.b r4,r10
    c.r[1] = c.r[10];  // 06020836 mov r10,r1
    c.r[1] <<= 2;  // 06020838 shll2 r1
    c.r[1] <<= 2;  // 0602083A shll2 r1
    c.r[3] = c.r[1];  // 0602083C mov r1,r3
    c.r[3] += c.r[2];  // 0602083E add r2,r3
    c.r[0] = c.r[1];  // 06020840 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06020842 mov.b @(r0,r2),r1
    c.r[3] += 1;  // 06020844 add #1,r3
    c.r[12] = c.r[1] & 0xFFu;  // 06020846 extu.b r1,r12
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06020848 mov.b @r3,r1
    c.r[9] = 0x2u;  // 0602084A mov #2,r9
    c.r[13] = c.r[1] & 0xFFu;  // 0602084C extu.b r1,r13
    c.r[2] = 0x0u;  // 0602084E mov #0,r2
L_06020850:
    c.r[5] = 0x40u;  // 06020850 mov #64,r5
    c.r[3] = c.r[12];  // 06020852 mov r12,r3
    c.r[3] += c.r[9];  // 06020854 add r9,r3
    c.r[6] = (uint32_t)(int16_t)ld16(0x06020966u);  // 06020856 mov.w 0x06020966,r6
    c.r[7] = 0x49u;  // 06020858 mov #73,r7
    c.t = c.r[2] == c.r[10];  // 0602085A cmp/eq r10,r2
L_0602085C:
    { const bool k = c.t; c.macl = c.r[13] * c.r[5]; if (k) { goto L_06020874; } }  // 0602085C bt/s 0x06020874 ; mul.l r5,r13
    c.r[0] = ld32(0x0602096Cu);  // 06020860 mov.l 0x0602096C,r0
    c.r[1] = ld32(c.r[0]);  // 06020862 mov.l @r0,r1
    c.r[4] = c.macl;  // 06020864 sts macl,r4
    c.r[4] += c.r[1];  // 06020866 add r1,r4
    c.r[0] = c.r[4];  // 06020868 mov r4,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0602086A mov.b @(r0,r3),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602086C extu.b r1,r1
    c.t = c.r[1] == c.r[6];  // 0602086E cmp/eq r6,r1
    { const bool k = !c.t; c.r[0] = c.r[2]; if (k) { goto L_0602087E; } }  // 06020870 bf/s 0x0602087E ; mov r2,r0
L_06020874:
    c.r[2] += 1;  // 06020874 add #1,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[7];  // 06020876 cmp/gt r7,r2
    { const bool k = !c.t; c.t = c.r[2] == c.r[10]; if (k) { SH2_POLL(c); goto L_0602085C; } }  // 06020878 bf/s 0x0602085C ; cmp/eq r10,r2
    c.r[0] = c.r[2];  // 0602087C mov r2,r0
L_0602087E:
    c.t = c.r[0] == 0x4Au;  // 0602087E cmp/eq #74,r0
    if (!c.t) { goto L_06020906; }  // 06020880 bf 0x06020906
    st32(c.r[14], c.r[9]);  // 06020882 mov.l r9,@r14
    c.r[11] = ld32(0x06020968u);  // 06020884 mov.l 0x06020968,r11
    c.r[8] = c.r[10];  // 06020886 mov r10,r8
    c.r[1] = ld32(c.r[11]);  // 06020888 mov.l @r11,r1
    c.r[8] <<= 2;  // 0602088A shll2 r8
    c.r[8] <<= 2;  // 0602088C shll2 r8
    c.r[1] += c.r[8];  // 0602088E add r8,r1
    c.r[1] += 2;  // 06020890 add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06020892 mov.b @r1,r2
    c.r[1] = ld32(0x06020970u);  // 06020894 mov.l 0x06020970,r1
    c.r[3] = ld32(c.r[1]);  // 06020896 mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06020898 extu.b r2,r2
    c.r[1] = 0x1Eu;  // 0602089A mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 0602089C mul.l r1,r2
    c.r[0] = c.macl;  // 0602089E sts macl,r0
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 060208A0 mov.w @(r0,r3),r5
    c.r[4] = 0x0u;  // 060208A2 mov #0,r4
    c.r[0] = ld32(0x06020974u);  // 060208A4 mov.l 0x06020974,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060208AAu; c.r[5] = c.r[5] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060208AAu) return; }  // 060208A6 jsr @r0 ; extu.w r5,r5
    c.r[3] = c.r[0] & 0xFFFFu;  // 060208AA extu.w r0,r3
    c.r[1] = ld32(0x06020978u);  // 060208AC mov.l 0x06020978,r1
    c.t = c.r[3] == c.r[1];  // 060208AE cmp/eq r1,r3
    { const bool k = c.t; c.r[3] <<= 2; if (k) { goto L_0602090E; } }  // 060208B0 bt/s 0x0602090E ; shll2 r3
    c.r[2] = ld32(0x0602097Cu);  // 060208B4 mov.l 0x0602097C,r2
    c.r[1] = c.r[3];  // 060208B6 mov r3,r1
    c.r[1] += c.r[2];  // 060208B8 add r2,r1
    c.r[1] += 2;  // 060208BA add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060208BC mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060208BE extu.b r1,r1
    c.r[1] >>= 2;  // 060208C0 shlr2 r1
    c.r[1] >>= 2;  // 060208C2 shlr2 r1
    c.r[1] >>= 2;  // 060208C4 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060208C6 tst r1,r1
    { const bool k = c.t; c.r[0] = c.r[2]; if (k) { goto L_06020906; } }  // 060208C8 bt/s 0x06020906 ; mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 060208CC mov.b @(r0,r3),r1
    c.r[2] = c.r[1] & 0xFFu;  // 060208CE extu.b r1,r2
    c.r[2] <<= 2;  // 060208D0 shll2 r2
    c.r[2] <<= 2;  // 060208D2 shll2 r2
    c.r[3] = ld32(c.r[11]);  // 060208D4 mov.l @r11,r3
    c.r[1] = c.r[2];  // 060208D6 mov r2,r1
    c.r[1] += c.r[3];  // 060208D8 add r3,r1
    c.r[1] += 1;  // 060208DA add #1,r1
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060208DC mov.b @r1,r7
    c.r[0] = c.r[2];  // 060208DE mov r2,r0
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 060208E0 mov.b @(r0,r3),r6
    c.r[7] = c.r[7] & 0xFFu;  // 060208E2 extu.b r7,r7
    c.r[6] = c.r[6] & 0xFFu;  // 060208E4 extu.b r6,r6
    c.r[1] = c.r[8];  // 060208E6 mov r8,r1
    c.r[1] += c.r[3];  // 060208E8 add r3,r1
    c.r[1] += 1;  // 060208EA add #1,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060208EC mov.b @r1,r5
    c.r[0] = c.r[8];  // 060208EE mov r8,r0
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 060208F0 mov.b @(r0,r3),r4
    c.r[5] = c.r[5] & 0xFFu;  // 060208F2 extu.b r5,r5
    c.r[4] += c.r[9];  // 060208F4 add r9,r4
    c.r[0] = ld32(0x06020980u);  // 060208F6 mov.l 0x06020980,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060208FCu; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060208FCu) return; }  // 060208F8 jsr @r0 ; extu.b r4,r4
    c.r[2] = c.r[0];  // 060208FC mov r0,r2
    c.r[1] = 0xAu;  // 060208FE mov #10,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 06020900 cmp/gt r1,r2
    { const bool k = !c.t; c.r[0] = ld32(c.r[14]); if (k) { goto L_06020910; } }  // 06020902 bf/s 0x06020910 ; mov.l @r14,r0
L_06020906:
    c.r[9] -= 1;  // 06020906 add #-1,r9
    c.t = (int32_t)c.r[9] > 0;  // 06020908 cmp/pl r9
    { const bool k = c.t; c.r[2] = 0x0u; if (k) { SH2_POLL(c); goto L_06020850; } }  // 0602090A bt/s 0x06020850 ; mov #0,r2
L_0602090E:
    c.r[0] = ld32(c.r[14]);  // 0602090E mov.l @r14,r0
L_06020910:
    c.t = (c.r[0] & c.r[0]) == 0;  // 06020910 tst r0,r0
    { const bool k = c.t; c.r[3] = c.r[10]; if (k) { goto L_06020950; } }  // 06020912 bt/s 0x06020950 ; mov r10,r3
    c.r[6] = ld32(0x06020968u);  // 06020916 mov.l 0x06020968,r6
    c.r[3] <<= 2;  // 06020918 shll2 r3
    c.r[3] <<= 2;  // 0602091A shll2 r3
    c.r[1] = ld32(c.r[6]);  // 0602091C mov.l @r6,r1
    c.r[0] = c.r[3];  // 0602091E mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06020920 mov.b @(r0,r1),r1
    c.r[12] = c.r[1] & 0xFFu;  // 06020922 extu.b r1,r12
    c.r[1] = 0x40u;  // 06020924 mov #64,r1
    c.macl = c.r[13] * c.r[1];  // 06020926 mul.l r1,r13
    c.r[5] = ld32(0x0602096Cu);  // 06020928 mov.l 0x0602096C,r5
    c.r[7] = ld32(c.r[5]);  // 0602092A mov.l @r5,r7
    c.r[2] = c.macl;  // 0602092C sts macl,r2
    c.r[2] += c.r[7];  // 0602092E add r7,r2
    c.r[1] = 0xFFFFFFFFu;  // 06020930 mov #-1,r1
    c.r[0] = c.r[2];  // 06020932 mov r2,r0
    st8(c.r[0] + c.r[12], c.r[1]);  // 06020934 mov.b r1,@(r0,r12)
    c.r[2] = ld32(c.r[6]);  // 06020936 mov.l @r6,r2
    c.r[0] = c.r[3];  // 06020938 mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0602093A mov.b @(r0,r2),r1
    c.r[9] += c.r[1];  // 0602093C add r1,r9
    st8(c.r[0] + c.r[2], c.r[9]);  // 0602093E mov.b r9,@(r0,r2)
    c.r[1] = ld32(c.r[6]);  // 06020940 mov.l @r6,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06020942 mov.b @(r0,r1),r1
    c.r[12] = c.r[1] & 0xFFu;  // 06020944 extu.b r1,r12
    c.r[1] = ld32(c.r[5]);  // 06020946 mov.l @r5,r1
    c.r[2] = c.macl;  // 06020948 sts macl,r2
    c.r[2] += c.r[1];  // 0602094A add r1,r2
    c.r[0] = c.r[2];  // 0602094C mov r2,r0
    st8(c.r[0] + c.r[12], c.r[10]);  // 0602094E mov.b r10,@(r0,r12)
L_06020950:
    c.r[14] += 4;  // 06020950 add #4,r14
    c.r[15] = c.r[14];  // 06020952 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06020954 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06020956 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06020958 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0602095A mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0602095C mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0602095E mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06020960 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06020962 rts ; mov.l @r15+,r8
}

void f_06020984(SH2Context& c) {
    ran[388] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06020984 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06020986 mov r15,r14
    c.r[1] = ld32(0x06020994u);  // 06020988 mov.l 0x06020994,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602098A mov.b @r1,r0
    c.r[0] &= 0x7Fu;  // 0602098C and #127,r0
    st8(c.r[1], c.r[0]);  // 0602098E mov.b r0,@r1
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06020990 rts ; mov.l @r15+,r14
}

void f_06020998(SH2Context& c) {
    ran[389] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06020998 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0602099A mov r15,r14
    c.r[1] = ld32(0x060209A8u);  // 0602099C mov.l 0x060209A8,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602099E mov.b @r1,r0
    c.r[0] |= 0x80u;  // 060209A0 or #128,r0
    st8(c.r[1], c.r[0]);  // 060209A2 mov.b r0,@r1
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060209A4 rts ; mov.l @r15+,r14
}

void f_060209AC(SH2Context& c) {
    ran[390] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060209AC mov.l r14,@-r15
    c.r[3] = ld32(0x060209D8u);  // 060209AE mov.l 0x060209D8,r3
    c.r[1] = ld32(c.r[3]);  // 060209B0 mov.l @r3,r1
    c.r[2] = ld32(0x060209DCu);  // 060209B2 mov.l 0x060209DC,r2
    c.r[1] += c.r[4];  // 060209B4 add r4,r1
    st32(c.r[2], c.r[1]);  // 060209B6 mov.l r1,@r2
    c.r[2] = c.r[3];  // 060209B8 mov r3,r2
    c.r[2] += 68;  // 060209BA add #68,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060209BC mov.b @r2,r1
    c.r[14] = c.r[15];  // 060209BE mov r15,r14
    c.r[1] -= 1;  // 060209C0 add #-1,r1
    st8(c.r[2], c.r[1]);  // 060209C2 mov.b r1,@r2
    c.r[1] = c.r[1] & 0xFFu;  // 060209C4 extu.b r1,r1
    c.r[1] <<= 2;  // 060209C6 shll2 r1
    c.r[1] += c.r[3];  // 060209C8 add r3,r1
    c.r[2] = ld32(c.r[1] + 4);  // 060209CA mov.l @(4,r1),r2
    st32(c.r[3], c.r[2]);  // 060209CC mov.l r2,@r3
    c.r[2] = 0x0u;  // 060209CE mov #0,r2
    st32(c.r[1] + 4, c.r[2]);  // 060209D0 mov.l r2,@(4,r1)
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060209D2 rts ; mov.l @r15+,r14
}

void f_060209E0(SH2Context& c) {
    ran[391] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060209E0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060209E2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060209E4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060209E6 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060209E8 mov r15,r14
    c.r[8] = c.r[4];  // 060209EA mov r4,r8
    c.r[8] = c.r[8] & 0xFFu;  // 060209EC extu.b r8,r8
    c.r[9] = ld32(0x06020A28u);  // 060209EE mov.l 0x06020A28,r9
    c.r[5] = c.r[8];  // 060209F0 mov r8,r5
    c.r[0] = ld32(0x06020A2Cu);  // 060209F2 mov.l 0x06020A2C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060209F8u; c.r[4] = ld32(c.r[9]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060209F8u) return; }  // 060209F4 jsr @r0 ; mov.l @r9,r4
    c.r[1] = c.r[0];  // 060209F8 mov r0,r1
    c.r[3] = c.r[1] & 0xFFu;  // 060209FA extu.b r1,r3
    c.r[8] <<= 2;  // 060209FC shll2 r8
    c.r[8] <<= 2;  // 060209FE shll2 r8
    c.r[3] <<= 2;  // 06020A00 shll2 r3
    c.r[3] <<= 2;  // 06020A02 shll2 r3
    c.r[2] = ld32(c.r[9]);  // 06020A04 mov.l @r9,r2
    c.r[0] = c.r[3];  // 06020A06 mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06020A08 mov.b @(r0,r2),r1
    c.r[0] = c.r[8];  // 06020A0A mov r8,r0
    st8(c.r[0] + c.r[2], c.r[1]);  // 06020A0C mov.b r1,@(r0,r2)
    c.r[1] = ld32(c.r[9]);  // 06020A0E mov.l @r9,r1
    c.r[15] = c.r[14];  // 06020A10 mov r14,r15
    c.r[8] += c.r[1];  // 06020A12 add r1,r8
    c.r[3] += c.r[1];  // 06020A14 add r1,r3
    c.r[3] += 1;  // 06020A16 add #1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06020A18 mov.b @r3,r1
    c.r[8] += 1;  // 06020A1A add #1,r8
    st8(c.r[8], c.r[1]);  // 06020A1C mov.b r1,@r8
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06020A1E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06020A20 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06020A22 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06020A24 rts ; mov.l @r15+,r8
}

void f_06020A30(SH2Context& c) {
    ran[392] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06020A30 mov.l r14,@-r15
    c.r[6] = c.r[5] & 0xFFu;  // 06020A32 extu.b r5,r6
    c.r[7] = c.r[6];  // 06020A34 mov r6,r7
    c.r[7] <<= 2;  // 06020A36 shll2 r7
    c.r[7] <<= 2;  // 06020A38 shll2 r7
    c.r[7] += c.r[4];  // 06020A3A add r4,r7
    c.r[1] = c.r[7];  // 06020A3C mov r7,r1
    c.r[1] += 4;  // 06020A3E add #4,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06020A40 mov.b @r1,r2
    c.r[1] = 0x60u;  // 06020A42 mov #96,r1
    c.r[1] &= c.r[2];  // 06020A44 and r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06020A46 tst r1,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06020AC8; } }  // 06020A48 bt/s 0x06020AC8 ; mov r15,r14
    c.r[0] = c.r[2];  // 06020A4C mov r2,r0
    c.r[0] >>= 2;  // 06020A4E shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06020A50 shlr r0
    c.r[0] >>= 2;  // 06020A52 shlr2 r0
    c.r[0] &= 0x1u;  // 06020A54 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06020A56 tst r0,r0
    { const bool k = c.t; c.r[3] = c.r[6]; if (k) { goto L_06020A62; } }  // 06020A58 bt/s 0x06020A62 ; mov r6,r3
    c.r[7] += 6;  // 06020A5C add #6,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06020A5E mov.b @r7,r1
    c.r[3] = c.r[1] & 0xFFu;  // 06020A60 extu.b r1,r3
L_06020A62:
    c.r[2] = c.r[3];  // 06020A62 mov r3,r2
    c.r[2] <<= 2;  // 06020A64 shll2 r2
    c.r[2] <<= 2;  // 06020A66 shll2 r2
    c.r[2] += c.r[4];  // 06020A68 add r4,r2
    c.r[1] = c.r[2];  // 06020A6A mov r2,r1
    c.r[1] += 4;  // 06020A6C add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06020A6E mov.b @r1,r1
    c.r[0] = c.r[1];  // 06020A70 mov r1,r0
    c.r[0] >>= 2;  // 06020A72 shlr2 r0
    c.r[0] >>= 2;  // 06020A74 shlr2 r0
    c.r[0] >>= 2;  // 06020A76 shlr2 r0
    c.r[0] &= 0x1u;  // 06020A78 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06020A7A tst r0,r0
    { const bool k = c.t; c.r[1] = 0x49u; if (k) { goto L_06020A88; } }  // 06020A7C bt/s 0x06020A88 ; mov #73,r1
    c.r[2] += 5;  // 06020A80 add #5,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06020A82 mov.b @r2,r1
    c.r[3] = c.r[1] & 0xFFu;  // 06020A84 extu.b r1,r3
    c.r[1] = 0x49u;  // 06020A86 mov #73,r1
L_06020A88:
    c.t = c.r[3] > c.r[1];  // 06020A88 cmp/hi r1,r3
    { const bool k = c.t; c.r[1] = c.r[6]; if (k) { goto L_06020ABA; } }  // 06020A8A bt/s 0x06020ABA ; mov r6,r1
    c.r[0] = c.r[3];  // 06020A8E mov r3,r0
    c.r[0] <<= 2;  // 06020A90 shll2 r0
    c.r[0] <<= 2;  // 06020A92 shll2 r0
    c.r[7] = c.r[0];  // 06020A94 mov r0,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[4]);  // 06020A96 mov.b @(r0,r4),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06020AD0u);  // 06020A98 mov.w 0x06020AD0,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06020A9A extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 06020A9C cmp/eq r2,r1
    { const bool k = c.t; c.r[7] += c.r[4]; if (k) { goto L_06020AB8; } }  // 06020A9E bt/s 0x06020AB8 ; add r4,r7
    c.r[7] += 7;  // 06020AA2 add #7,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06020AA4 mov.b @r7,r1
    c.r[0] = c.r[1];  // 06020AA6 mov r1,r0
    c.r[0] >>= 2;  // 06020AA8 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06020AAA shlr r0
    c.r[0] &= 0x1u;  // 06020AAC and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06020AAE tst r0,r0
    if (!c.t) { goto L_06020AB8; }  // 06020AB0 bf 0x06020AB8
    c.r[6] = c.r[3];  // 06020AB2 mov r3,r6
    c.r[15] = c.r[14]; goto L_06020ACA;  // 06020AB4 bra 0x06020ACA ; mov r14,r15
L_06020AB8:
    c.r[1] = c.r[6];  // 06020AB8 mov r6,r1
L_06020ABA:
    c.r[1] <<= 2;  // 06020ABA shll2 r1
    c.r[1] <<= 2;  // 06020ABC shll2 r1
    c.r[1] += c.r[4];  // 06020ABE add r4,r1
    c.r[1] += 4;  // 06020AC0 add #4,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06020AC2 mov.b @r1,r0
    c.r[0] &= 0xBFu;  // 06020AC4 and #191,r0
    st8(c.r[1], c.r[0]);  // 06020AC6 mov.b r0,@r1
L_06020AC8:
    c.r[15] = c.r[14];  // 06020AC8 mov r14,r15
L_06020ACA:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06020ACA mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[6]; c.pc = x; return; }  // 06020ACC rts ; mov r6,r0
}

void f_06020AD4(SH2Context& c) {
    ran[393] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06020AD4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06020AD6 sts.l pr,@-r15
    c.r[1] = ld32(0x06020AF4u);  // 06020AD8 mov.l 0x06020AF4,r1
    c.r[1] = ld32(c.r[1]);  // 06020ADA mov.l @r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06020ADC mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06020ADE extu.b r1,r0
    c.r[0] <<= 2;  // 06020AE0 shll2 r0
    c.r[1] = ld32(0x06020AF8u);  // 06020AE2 mov.l 0x06020AF8,r1
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 06020AE4 mov.l @(r0,r1),r0
    { const uint32_t x = c.r[0]; c.pr = 0x06020AEAu; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06020AEAu) return; }  // 06020AE6 jsr @r0 ; mov r15,r14
    c.r[15] = c.r[14];  // 06020AEA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06020AEC lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06020AEE mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[0] & 0xFFFFu; c.pc = x; return; }  // 06020AF0 rts ; extu.w r0,r0
}

void f_06020AFC(SH2Context& c) {
    ran[394] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06020AFC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06020AFE mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06020B00 sts.l pr,@-r15
    c.r[8] = ld32(0x06020B4Cu);  // 06020B02 mov.l 0x06020B4C,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06020B04 mov.b @r8,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06020B06 extu.b r1,r1
    c.r[1] >>= 2;  // 06020B08 shlr2 r1
    c.r[1] >>= 2;  // 06020B0A shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06020B0C shlr r1
    c.r[1] >>= 2;  // 06020B0E shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06020B10 tst r1,r1
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_06020B3C; } }  // 06020B12 bf/s 0x06020B3C ; mov r15,r14
    c.r[1] = ld32(0x06020B50u);  // 06020B16 mov.l 0x06020B50,r1
    c.r[2] = ld32(c.r[1]);  // 06020B18 mov.l @r1,r2
    c.r[0] = ld32(0x06020B54u);  // 06020B1A mov.l 0x06020B54,r0
    c.r[1] = c.r[2];  // 06020B1C mov r2,r1
    c.r[1] += 1;  // 06020B1E add #1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06020B20 mov.b @r1,r4
    c.r[2] += 2;  // 06020B22 add #2,r2
    c.r[4] = c.r[4] & 0xFFu;  // 06020B24 extu.b r4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06020B26 mov.b @r2,r1
    c.r[4] <<= 8;  // 06020B28 shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 06020B2A extu.b r1,r1
    { const uint32_t x = c.r[0]; c.pr = 0x06020B30u; c.r[4] |= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06020B30u) return; }  // 06020B2C jsr @r0 ; or r1,r4
    c.r[1] = c.r[0] & 0xFFFFu;  // 06020B30 extu.w r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06020B32 tst r1,r1
    if (!c.t) { goto L_06020B3C; }  // 06020B34 bf 0x06020B3C
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06020B36 mov.b @r8,r0
    c.r[0] |= 0x80u;  // 06020B38 or #128,r0
    st8(c.r[8], c.r[0]);  // 06020B3A mov.b r0,@r8
L_06020B3C:
    c.r[15] = c.r[14];  // 06020B3C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06020B3E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06020B40 mov.l @r15+,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x06020B48u);  // 06020B42 mov.w 0x06020B48,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06020B44 rts ; mov.l @r15+,r8
}

void f_06020B58(SH2Context& c) {
    ran[395] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06020B58 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06020B5A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06020B5C sts.l pr,@-r15
    c.r[8] = ld32(0x06020BA8u);  // 06020B5E mov.l 0x06020BA8,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06020B60 mov.b @r8,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06020B62 extu.b r1,r1
    c.r[1] >>= 2;  // 06020B64 shlr2 r1
    c.r[1] >>= 2;  // 06020B66 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06020B68 shlr r1
    c.r[1] >>= 2;  // 06020B6A shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06020B6C tst r1,r1
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_06020B98; } }  // 06020B6E bf/s 0x06020B98 ; mov r15,r14
    c.r[1] = ld32(0x06020BACu);  // 06020B72 mov.l 0x06020BAC,r1
    c.r[2] = ld32(c.r[1]);  // 06020B74 mov.l @r1,r2
    c.r[0] = ld32(0x06020BB0u);  // 06020B76 mov.l 0x06020BB0,r0
    c.r[1] = c.r[2];  // 06020B78 mov r2,r1
    c.r[1] += 1;  // 06020B7A add #1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06020B7C mov.b @r1,r4
    c.r[2] += 2;  // 06020B7E add #2,r2
    c.r[4] = c.r[4] & 0xFFu;  // 06020B80 extu.b r4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06020B82 mov.b @r2,r1
    c.r[4] <<= 8;  // 06020B84 shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 06020B86 extu.b r1,r1
    { const uint32_t x = c.r[0]; c.pr = 0x06020B8Cu; c.r[4] |= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06020B8Cu) return; }  // 06020B88 jsr @r0 ; or r1,r4
    c.r[1] = c.r[0] & 0xFFFFu;  // 06020B8C extu.w r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06020B8E tst r1,r1
    if (c.t) { goto L_06020B98; }  // 06020B90 bt 0x06020B98
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06020B92 mov.b @r8,r0
    c.r[0] |= 0x80u;  // 06020B94 or #128,r0
    st8(c.r[8], c.r[0]);  // 06020B96 mov.b r0,@r8
L_06020B98:
    c.r[15] = c.r[14];  // 06020B98 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06020B9A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06020B9C mov.l @r15+,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x06020BA4u);  // 06020B9E mov.w 0x06020BA4,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06020BA0 rts ; mov.l @r15+,r8
}

void f_06020BB4(SH2Context& c) {
    ran[396] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06020BB4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06020BB6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06020BB8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06020BBA mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06020BBC mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06020BBE mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06020BC0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06020BC2 sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x06020CCCu);  // 06020BC4 mov.w 0x06020CCC,r3
    c.r[15] += c.r[3];  // 06020BC6 add r3,r15
    c.r[14] = c.r[15];  // 06020BC8 mov r15,r14
    c.r[13] = ld32(0x06020CD4u);  // 06020BCA mov.l 0x06020CD4,r13
    c.r[1] = c.r[13];  // 06020BCC mov r13,r1
    c.r[1] += 37;  // 06020BCE add #37,r1
    c.r[7] = (uint32_t)(int16_t)ld16(0x06020CCEu);  // 06020BD0 mov.w 0x06020CCE,r7
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06020BD2 mov.b @r1,r0
    c.r[7] += c.r[14];  // 06020BD4 add r14,r7
    c.r[11] = c.r[0] & 0xFFu;  // 06020BD6 extu.b r0,r11
    st32(c.r[7], c.r[11]);  // 06020BD8 mov.l r11,@r7
    c.r[7] = (uint32_t)(int16_t)ld16(0x06020CCEu);  // 06020BDA mov.w 0x06020CCE,r7
    c.r[7] += c.r[14];  // 06020BDC add r14,r7
    c.r[11] = ld32(c.r[7]);  // 06020BDE mov.l @r7,r11
    c.r[11] >>= 2;  // 06020BE0 shlr2 r11
    c.r[11] >>= 2;  // 06020BE2 shlr2 r11
    c.t = c.r[11] & 1; c.r[11] >>= 1;  // 06020BE4 shlr r11
    c.r[11] >>= 2;  // 06020BE6 shlr2 r11
    st32(c.r[7], c.r[11]);  // 06020BE8 mov.l r11,@r7
    c.r[7] = (uint32_t)(int16_t)ld16(0x06020CCEu);  // 06020BEA mov.w 0x06020CCE,r7
    c.r[7] += c.r[14];  // 06020BEC add r14,r7
    c.r[7] = ld32(c.r[7]);  // 06020BEE mov.l @r7,r7
    c.r[10] = ld32(0x06020CD8u);  // 06020BF0 mov.l 0x06020CD8,r10
    c.t = (c.r[7] & c.r[7]) == 0;  // 06020BF2 tst r7,r7
    { const bool k = c.t; c.r[6] = 0x0u; if (k) { goto L_06020C02; } }  // 06020BF4 bt/s 0x06020C02 ; mov #0,r6
    c.r[0] &= 0x7Fu;  // 06020BF8 and #127,r0
    st8(c.r[1], c.r[0]);  // 06020BFA mov.b r0,@r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06020CD0u);  // 06020BFC mov.w 0x06020CD0,r0
    goto L_06020CB4;  // 06020BFE bra 0x06020CB4 ; nop
L_06020C02:
    c.r[11] = ld32(0x06020CDCu);  // 06020C02 mov.l 0x06020CDC,r11
    c.r[2] = ld32(c.r[11]);  // 06020C04 mov.l @r11,r2
    c.r[12] = ld32(0x06020CE0u);  // 06020C06 mov.l 0x06020CE0,r12
    c.r[1] = c.r[2];  // 06020C08 mov r2,r1
    c.r[1] += 1;  // 06020C0A add #1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06020C0C mov.b @r1,r4
    c.r[4] = c.r[4] & 0xFFu;  // 06020C0E extu.b r4,r4
    c.r[1] = c.r[2];  // 06020C10 mov r2,r1
    c.r[1] += 2;  // 06020C12 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06020C14 mov.b @r1,r1
    c.r[4] <<= 8;  // 06020C16 shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 06020C18 extu.b r1,r1
    c.r[4] |= c.r[1];  // 06020C1A or r1,r4
    c.r[4] = (uint32_t)(int32_t)(int16_t)c.r[4];  // 06020C1C exts.w r4,r4
    c.r[4] += c.r[2];  // 06020C1E add r2,r4
    c.r[4] += 1;  // 06020C20 add #1,r4
    st32(c.r[13] + 8, c.r[4]);  // 06020C22 mov.l r4,@(8,r13)
    c.r[1] = c.r[4];  // 06020C24 mov r4,r1
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 06020C26 mov.b @r1+,r8
    c.r[5] = c.r[14];  // 06020C28 mov r14,r5
    c.r[8] = c.r[8] & 0xFFu;  // 06020C2A extu.b r8,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06020C2C mov.b @r1,r1
    c.r[8] <<= 8;  // 06020C2E shll8 r8
    c.r[1] = c.r[1] & 0xFFu;  // 06020C30 extu.b r1,r1
    c.r[8] |= c.r[1];  // 06020C32 or r1,r8
    st16(c.r[10], c.r[8]);  // 06020C34 mov.w r8,@r10
    { const uint32_t x = c.r[12]; c.pr = 0x06020C3Au; c.r[4] += c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06020C3Au) return; }  // 06020C36 jsr @r12 ; add r8,r4
    c.r[9] = c.r[13];  // 06020C3A mov r13,r9
    c.r[9] += 38;  // 06020C3C add #38,r9
    c.r[8] += c.r[10];  // 06020C3E add r10,r8
    c.r[5] = c.r[14];  // 06020C40 mov r14,r5
    c.r[4] = c.r[8];  // 06020C42 mov r8,r4
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06020C44 mov.b @r9,r6
    c.r[7] = ld32(0x06020CE4u);  // 06020C46 mov.l 0x06020CE4,r7
    { const uint32_t x = c.r[7]; c.pr = 0x06020C4Cu; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06020C4Cu) return; }  // 06020C48 jsr @r7 ; extu.b r6,r6
    c.r[6] = 0x0u;  // 06020C4C mov #0,r6
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06020C4E mov.b @r9,r3
    c.r[5] = c.r[14];  // 06020C50 mov r14,r5
    c.r[4] = ld32(c.r[13] + 8);  // 06020C52 mov.l @(8,r13),r4
    c.r[3] = c.r[3] & 0xFFu;  // 06020C54 extu.b r3,r3
    c.r[8] = c.r[3];  // 06020C56 mov r3,r8
    c.r[8] += 4;  // 06020C58 add #4,r8
    c.r[8] = c.r[8] & 0xFFFFu;  // 06020C5A extu.w r8,r8
    c.r[1] = c.r[4];  // 06020C5C mov r4,r1
    c.r[1] += 2;  // 06020C5E add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06020C60 mov.b @r1,r2
    c.r[3] += 2;  // 06020C62 add #2,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06020C64 extu.b r2,r2
    c.r[1] = c.r[4];  // 06020C66 mov r4,r1
    c.r[1] += 3;  // 06020C68 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06020C6A mov.b @r1,r1
    c.r[2] <<= 8;  // 06020C6C shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06020C6E extu.b r1,r1
    c.r[2] |= c.r[1];  // 06020C70 or r1,r2
    c.r[1] = c.r[10];  // 06020C72 mov r10,r1
    c.r[1] += 2;  // 06020C74 add #2,r1
    st16(c.r[1], c.r[3]);  // 06020C76 mov.w r3,@r1
    c.r[2] += 2;  // 06020C78 add #2,r2
    { const uint32_t x = c.r[12]; c.pr = 0x06020C7Eu; c.r[4] += c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06020C7Eu) return; }  // 06020C7A jsr @r12 ; add r2,r4
    c.r[8] += c.r[10];  // 06020C7E add r10,r8
    c.r[5] = c.r[14];  // 06020C80 mov r14,r5
    c.r[4] = c.r[8];  // 06020C82 mov r8,r4
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06020C84 mov.b @r9,r6
    c.r[11] = ld32(0x06020CE4u);  // 06020C86 mov.l 0x06020CE4,r11
    { const uint32_t x = c.r[11]; c.pr = 0x06020C8Cu; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06020C8Cu) return; }  // 06020C88 jsr @r11 ; extu.b r6,r6
    st32(c.r[13] + 8, c.r[10]);  // 06020C8C mov.l r10,@(8,r13)
    c.r[7] = ld32(0x06020CDCu);  // 06020C8E mov.l 0x06020CDC,r7
    c.r[2] = ld32(0x06020CDCu);  // 06020C90 mov.l 0x06020CDC,r2
    c.r[1] = ld32(c.r[7]);  // 06020C92 mov.l @r7,r1
    c.r[2] += 68;  // 06020C94 add #68,r2
    st32(c.r[13], c.r[1]);  // 06020C96 mov.l r1,@r13
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06020C98 mov.b @r2,r1
    c.r[11] = ld32(0x06020CDCu);  // 06020C9A mov.l 0x06020CDC,r11
    c.r[1] -= 1;  // 06020C9C add #-1,r1
    st8(c.r[2], c.r[1]);  // 06020C9E mov.b r1,@r2
    c.r[1] = c.r[1] & 0xFFu;  // 06020CA0 extu.b r1,r1
    c.r[1] <<= 2;  // 06020CA2 shll2 r1
    c.r[1] += c.r[11];  // 06020CA4 add r11,r1
    c.r[2] = ld32(c.r[1] + 4);  // 06020CA6 mov.l @(4,r1),r2
    st32(c.r[7], c.r[2]);  // 06020CA8 mov.l r2,@r7
    c.r[7] = (uint32_t)(int16_t)ld16(0x06020CCEu);  // 06020CAA mov.w 0x06020CCE,r7
    c.r[7] += c.r[14];  // 06020CAC add r14,r7
    c.r[7] = ld32(c.r[7]);  // 06020CAE mov.l @r7,r7
    c.r[0] = ld32(0x06020CE8u);  // 06020CB0 mov.l 0x06020CE8,r0
    st32(c.r[1] + 4, c.r[7]);  // 06020CB2 mov.l r7,@(4,r1)
L_06020CB4:
    c.r[3] = (uint32_t)(int16_t)ld16(0x06020CD2u);  // 06020CB4 mov.w 0x06020CD2,r3
    c.r[14] += c.r[3];  // 06020CB6 add r3,r14
    c.r[15] = c.r[14];  // 06020CB8 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06020CBA lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06020CBC mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06020CBE mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06020CC0 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06020CC2 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06020CC4 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06020CC6 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06020CC8 rts ; mov.l @r15+,r8
}

void f_06020CEC(SH2Context& c) {
    ran[397] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06020CEC mov.l r14,@-r15
    c.r[7] = ld32(0x06020D20u);  // 06020CEE mov.l 0x06020D20,r7
    c.r[3] = ld32(0x06020D24u);  // 06020CF0 mov.l 0x06020D24,r3
    c.r[2] = c.r[3];  // 06020CF2 mov r3,r2
    c.r[1] = ld32(c.r[3]);  // 06020CF4 mov.l @r3,r1
    c.r[2] += 68;  // 06020CF6 add #68,r2
    st32(c.r[7], c.r[1]);  // 06020CF8 mov.l r1,@r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06020CFA mov.b @r2,r1
    c.r[14] = c.r[15];  // 06020CFC mov r15,r14
    c.r[1] -= 1;  // 06020CFE add #-1,r1
    st8(c.r[2], c.r[1]);  // 06020D00 mov.b r1,@r2
    c.r[1] = c.r[1] & 0xFFu;  // 06020D02 extu.b r1,r1
    c.r[1] <<= 2;  // 06020D04 shll2 r1
    c.r[1] += c.r[3];  // 06020D06 add r3,r1
    c.r[2] = ld32(c.r[1] + 4);  // 06020D08 mov.l @(4,r1),r2
    c.r[7] += 37;  // 06020D0A add #37,r7
    st32(c.r[3], c.r[2]);  // 06020D0C mov.l r2,@r3
    c.r[2] = 0x0u;  // 06020D0E mov #0,r2
    st32(c.r[1] + 4, c.r[2]);  // 06020D10 mov.l r2,@(4,r1)
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06020D12 mov.b @r7,r0
    c.r[0] |= 0x80u;  // 06020D14 or #128,r0
    st8(c.r[7], c.r[0]);  // 06020D16 mov.b r0,@r7
    c.r[0] = ld32(0x06020D28u);  // 06020D18 mov.l 0x06020D28,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06020D1A rts ; mov.l @r15+,r14
}

void f_06020D2C(SH2Context& c) {
    ran[398] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06020D2C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06020D2E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06020D30 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06020D32 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06020D34 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06020D36 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06020D38 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06020D3A sts.l pr,@-r15
    c.r[15] -= 76;  // 06020D3C add #-76,r15
    c.r[2] = ld32(0x06020E80u);  // 06020D3E mov.l 0x06020E80,r2
    c.r[1] = 0x0u;  // 06020D40 mov #0,r1
    st32(c.r[2] + 8, c.r[1]);  // 06020D42 mov.l r1,@(8,r2)
    c.r[2] += 37;  // 06020D44 add #37,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06020D46 mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06020D48 extu.b r1,r1
    c.r[1] >>= 2;  // 06020D4A shlr2 r1
    c.r[1] >>= 2;  // 06020D4C shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06020D4E shlr r1
    c.r[1] >>= 2;  // 06020D50 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06020D52 tst r1,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06020D5C; } }  // 06020D54 bt/s 0x06020D5C ; mov r15,r14
    goto L_06020F16;  // 06020D58 bra 0x06020F16 ; nop
L_06020D5C:
    c.r[1] = ld32(0x06020E84u);  // 06020D5C mov.l 0x06020E84,r1
    c.r[8] = ld32(0x06020E88u);  // 06020D5E mov.l 0x06020E88,r8
    c.r[0] = ld32(0x06020E8Cu);  // 06020D60 mov.l 0x06020E8C,r0
    c.r[2] = ld32(c.r[1]);  // 06020D62 mov.l @r1,r2
    c.r[7] = 0x0u;  // 06020D64 mov #0,r7
    c.r[1] = c.r[2];  // 06020D66 mov r2,r1
    c.r[1] += 1;  // 06020D68 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06020D6A mov.b @r1,r1
    c.r[2] += 2;  // 06020D6C add #2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06020D6E extu.b r1,r1
    c.r[6] = c.r[1];  // 06020D70 mov r1,r6
    c.r[6] <<= 8;  // 06020D72 shll8 r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06020D74 mov.b @r2,r1
    c.r[5] = c.r[14];  // 06020D76 mov r14,r5
    c.r[4] = ld32(c.r[8]);  // 06020D78 mov.l @r8,r4
    c.r[1] = c.r[1] & 0xFFu;  // 06020D7A extu.b r1,r1
    c.r[6] |= c.r[1];  // 06020D7C or r1,r6
    c.r[12] = c.r[6];  // 06020D7E mov r6,r12
    c.r[12] >>= 8;  // 06020D80 shlr8 r12
    c.r[12] >>= 2;  // 06020D82 shlr2 r12
    c.r[12] >>= 2;  // 06020D84 shlr2 r12
    c.r[1] = (uint32_t)(int16_t)ld16(0x06020E7Eu);  // 06020D86 mov.w 0x06020E7E,r1
    { const uint32_t x = c.r[0]; c.pr = 0x06020D8Cu; c.r[6] &= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06020D8Cu) return; }  // 06020D88 jsr @r0 ; and r1,r6
    c.r[10] = c.r[0];  // 06020D8C mov r0,r10
    c.t = (c.r[10] & c.r[10]) == 0;  // 06020D8E tst r10,r10
    { const bool k = c.t; c.r[9] = c.r[10]; if (k) { goto L_06020E04; } }  // 06020D90 bt/s 0x06020E04 ; mov r10,r9
    c.r[9] = 0x0u;  // 06020D94 mov #0,r9
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[10];  // 06020D96 cmp/ge r10,r9
    { const bool k = c.t; c.t = c.r[9] == c.r[10]; if (k) { goto L_06020E06; } }  // 06020D98 bt/s 0x06020E06 ; cmp/eq r10,r9
    c.r[11] = c.r[8];  // 06020D9C mov r8,r11
    c.r[0] = c.r[14];  // 06020D9E mov r14,r0
L_06020DA0:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 06020DA0 mov.b @(r0,r9),r1
    c.r[2] = c.r[1] & 0xFFu;  // 06020DA2 extu.b r1,r2
    c.r[3] = c.r[2];  // 06020DA4 mov r2,r3
    c.r[1] = ld32(c.r[11]);  // 06020DA6 mov.l @r11,r1
    c.r[3] <<= 2;  // 06020DA8 shll2 r3
    c.r[3] <<= 2;  // 06020DAA shll2 r3
    c.r[3] += c.r[1];  // 06020DAC add r1,r3
    c.r[1] = c.r[3];  // 06020DAE mov r3,r1
    c.r[1] += 4;  // 06020DB0 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06020DB2 mov.b @r1,r1
    c.r[0] = 0x1u;  // 06020DB4 mov #1,r0
    c.r[1] >>= 2;  // 06020DB6 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06020DB8 shlr r1
    c.r[1] >>= 2;  // 06020DBA shlr2 r1
    c.r[1] &= c.r[0];  // 06020DBC and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06020DBE tst r1,r1
    { const bool k = c.t; c.r[8] = c.r[2]; if (k) { goto L_06020DCA; } }  // 06020DC0 bt/s 0x06020DCA ; mov r2,r8
    c.r[3] += 6;  // 06020DC4 add #6,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06020DC6 mov.b @r3,r1
    c.r[8] = c.r[1] & 0xFFu;  // 06020DC8 extu.b r1,r8
L_06020DCA:
    c.r[2] = c.r[8];  // 06020DCA mov r8,r2
    c.r[2] <<= 2;  // 06020DCC shll2 r2
    c.r[2] <<= 2;  // 06020DCE shll2 r2
    c.r[1] = ld32(c.r[11]);  // 06020DD0 mov.l @r11,r1
    c.r[0] = 0x3u;  // 06020DD2 mov #3,r0
    c.r[2] += c.r[1];  // 06020DD4 add r1,r2
    c.r[2] += 3;  // 06020DD6 add #3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06020DD8 mov.b @r2,r1
    c.r[4] = c.r[12];  // 06020DDA mov r12,r4
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06020DDC shlr r1
    c.r[1] &= c.r[0];  // 06020DDE and r0,r1
    c.r[0] = ld32(0x06020E90u);  // 06020DE0 mov.l 0x06020E90,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06020DE6u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06020DE6u) return; }  // 06020DE2 jsr @r0 ; mov r1,r5
    c.r[1] = c.r[0];  // 06020DE6 mov r0,r1
    c.r[0] = 0x1u;  // 06020DE8 mov #1,r0
    c.r[1] &= c.r[0];  // 06020DEA and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06020DEC tst r1,r1
    if (c.t) { goto L_06020DFC; }  // 06020DEE bt 0x06020DFC
    c.r[1] = ld32(0x06020E94u);  // 06020DF0 mov.l 0x06020E94,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06020DF2 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06020DF4 extu.b r1,r1
    c.t = c.r[1] == c.r[8];  // 06020DF6 cmp/eq r8,r1
    { const bool k = c.t; c.t = c.r[9] == c.r[10]; if (k) { goto L_06020E06; } }  // 06020DF8 bt/s 0x06020E06 ; cmp/eq r10,r9
L_06020DFC:
    c.r[9] += 1;  // 06020DFC add #1,r9
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[10];  // 06020DFE cmp/ge r10,r9
    { const bool k = !c.t; c.r[0] = c.r[14]; if (k) { SH2_POLL(c); goto L_06020DA0; } }  // 06020E00 bf/s 0x06020DA0 ; mov r14,r0
L_06020E04:
    c.t = c.r[9] == c.r[10];  // 06020E04 cmp/eq r10,r9
L_06020E06:
    { const bool k = !c.t; c.r[7] = 0x0u; if (k) { goto L_06020E0E; } }  // 06020E06 bf/s 0x06020E0E ; mov #0,r7
    goto L_06020F16;  // 06020E0A bra 0x06020F16 ; nop
L_06020E0E:
    c.r[1] = ld32(0x06020E84u);  // 06020E0E mov.l 0x06020E84,r1
    c.r[8] = ld32(0x06020E88u);  // 06020E10 mov.l 0x06020E88,r8
    c.r[0] = ld32(0x06020E8Cu);  // 06020E12 mov.l 0x06020E8C,r0
    c.r[2] = ld32(c.r[1]);  // 06020E14 mov.l @r1,r2
    c.r[1] = c.r[2];  // 06020E16 mov r2,r1
    c.r[1] += 3;  // 06020E18 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06020E1A mov.b @r1,r1
    c.r[2] += 4;  // 06020E1C add #4,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06020E1E extu.b r1,r1
    c.r[6] = c.r[1];  // 06020E20 mov r1,r6
    c.r[6] <<= 8;  // 06020E22 shll8 r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06020E24 mov.b @r2,r1
    c.r[5] = c.r[14];  // 06020E26 mov r14,r5
    c.r[4] = ld32(c.r[8]);  // 06020E28 mov.l @r8,r4
    c.r[1] = c.r[1] & 0xFFu;  // 06020E2A extu.b r1,r1
    c.r[6] |= c.r[1];  // 06020E2C or r1,r6
    c.r[12] = c.r[6];  // 06020E2E mov r6,r12
    c.r[12] >>= 8;  // 06020E30 shlr8 r12
    c.r[12] >>= 2;  // 06020E32 shlr2 r12
    c.r[12] >>= 2;  // 06020E34 shlr2 r12
    c.r[1] = (uint32_t)(int16_t)ld16(0x06020E7Eu);  // 06020E36 mov.w 0x06020E7E,r1
    { const uint32_t x = c.r[0]; c.pr = 0x06020E3Cu; c.r[6] &= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06020E3Cu) return; }  // 06020E38 jsr @r0 ; and r1,r6
    c.r[10] = c.r[0];  // 06020E3C mov r0,r10
    c.t = (c.r[10] & c.r[10]) == 0;  // 06020E3E tst r10,r10
    { const bool k = c.t; c.r[9] = c.r[10]; if (k) { goto L_06020ED4; } }  // 06020E40 bt/s 0x06020ED4 ; mov r10,r9
    c.r[9] = 0x0u;  // 06020E44 mov #0,r9
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[10];  // 06020E46 cmp/ge r10,r9
    { const bool k = c.t; c.t = c.r[9] == c.r[10]; if (k) { goto L_06020ED6; } }  // 06020E48 bt/s 0x06020ED6 ; cmp/eq r10,r9
    c.r[11] = c.r[8];  // 06020E4C mov r8,r11
    c.r[13] = ld32(0x06020E98u);  // 06020E4E mov.l 0x06020E98,r13
    c.r[0] = c.r[14];  // 06020E50 mov r14,r0
L_06020E52:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 06020E52 mov.b @(r0,r9),r1
    c.r[2] = c.r[1] & 0xFFu;  // 06020E54 extu.b r1,r2
    c.r[3] = c.r[2];  // 06020E56 mov r2,r3
    c.r[1] = ld32(c.r[11]);  // 06020E58 mov.l @r11,r1
    c.r[3] <<= 2;  // 06020E5A shll2 r3
    c.r[3] <<= 2;  // 06020E5C shll2 r3
    c.r[3] += c.r[1];  // 06020E5E add r1,r3
    c.r[1] = c.r[3];  // 06020E60 mov r3,r1
    c.r[1] += 4;  // 06020E62 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06020E64 mov.b @r1,r1
    c.r[0] = 0x1u;  // 06020E66 mov #1,r0
    c.r[1] >>= 2;  // 06020E68 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06020E6A shlr r1
    c.r[1] >>= 2;  // 06020E6C shlr2 r1
    c.r[1] &= c.r[0];  // 06020E6E and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06020E70 tst r1,r1
    { const bool k = c.t; c.r[8] = c.r[2]; if (k) { goto L_06020E9C; } }  // 06020E72 bt/s 0x06020E9C ; mov r2,r8
    c.r[3] += 6;  // 06020E76 add #6,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06020E78 mov.b @r3,r1
    c.r[8] = c.r[1] & 0xFFu; goto L_06020E9C;  // 06020E7A bra 0x06020E9C ; extu.b r1,r8
L_06020E9C:
    c.r[2] = c.r[8];  // 06020E9C mov r8,r2
    c.r[2] <<= 2;  // 06020E9E shll2 r2
    c.r[2] <<= 2;  // 06020EA0 shll2 r2
    c.r[1] = ld32(c.r[11]);  // 06020EA2 mov.l @r11,r1
    c.r[0] = 0x3u;  // 06020EA4 mov #3,r0
    c.r[2] += c.r[1];  // 06020EA6 add r1,r2
    c.r[2] += 3;  // 06020EA8 add #3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06020EAA mov.b @r2,r1
    c.r[4] = c.r[12];  // 06020EAC mov r12,r4
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06020EAE shlr r1
    c.r[1] &= c.r[0];  // 06020EB0 and r0,r1
    c.r[0] = ld32(0x06020F38u);  // 06020EB2 mov.l 0x06020F38,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06020EB8u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06020EB8u) return; }  // 06020EB4 jsr @r0 ; mov r1,r5
    c.r[1] = c.r[0];  // 06020EB8 mov r0,r1
    c.r[0] = 0x1u;  // 06020EBA mov #1,r0
    c.r[1] &= c.r[0];  // 06020EBC and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06020EBE tst r1,r1
    if (c.t) { goto L_06020ECC; }  // 06020EC0 bt 0x06020ECC
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 06020EC2 mov.b @r13,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06020EC4 extu.b r1,r1
    c.t = c.r[1] == c.r[8];  // 06020EC6 cmp/eq r8,r1
    { const bool k = c.t; c.t = c.r[9] == c.r[10]; if (k) { goto L_06020ED6; } }  // 06020EC8 bt/s 0x06020ED6 ; cmp/eq r10,r9
L_06020ECC:
    c.r[9] += 1;  // 06020ECC add #1,r9
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[10];  // 06020ECE cmp/ge r10,r9
    { const bool k = !c.t; c.r[0] = c.r[14]; if (k) { SH2_POLL(c); goto L_06020E52; } }  // 06020ED0 bf/s 0x06020E52 ; mov r14,r0
L_06020ED4:
    c.t = c.r[9] == c.r[10];  // 06020ED4 cmp/eq r10,r9
L_06020ED6:
    if (c.t) { goto L_06020F16; }  // 06020ED6 bt 0x06020F16
    c.r[7] = ld32(0x06020F3Cu);  // 06020ED8 mov.l 0x06020F3C,r7
    c.r[1] = ld32(c.r[7]);  // 06020EDA mov.l @r7,r1
    c.r[6] = ld32(0x06020F40u);  // 06020EDC mov.l 0x06020F40,r6
    c.r[3] = c.r[1];  // 06020EDE mov r1,r3
    c.r[3] += 5;  // 06020EE0 add #5,r3
    st32(c.r[7], c.r[3]);  // 06020EE2 mov.l r3,@r7
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06020EE4 mov.b @r3,r2
    c.r[1] += 6;  // 06020EE6 add #6,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06020EE8 mov.b @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 06020EEA extu.b r2,r2
    c.r[2] <<= 8;  // 06020EEC shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06020EEE extu.b r1,r1
    c.r[2] |= c.r[1];  // 06020EF0 or r1,r2
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 06020EF2 exts.w r2,r2
    c.r[2] += c.r[3];  // 06020EF4 add r3,r2
    st32(c.r[6] + 8, c.r[2]);  // 06020EF6 mov.l r2,@(8,r6)
    st32(c.r[6], c.r[3]);  // 06020EF8 mov.l r3,@r6
    c.r[2] = c.r[7];  // 06020EFA mov r7,r2
    c.r[2] += 68;  // 06020EFC add #68,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06020EFE mov.b @r2,r1
    c.r[1] -= 1;  // 06020F00 add #-1,r1
    st8(c.r[2], c.r[1]);  // 06020F02 mov.b r1,@r2
    c.r[1] = c.r[1] & 0xFFu;  // 06020F04 extu.b r1,r1
    c.r[1] <<= 2;  // 06020F06 shll2 r1
    c.r[1] += c.r[7];  // 06020F08 add r7,r1
    c.r[2] = ld32(c.r[1] + 4);  // 06020F0A mov.l @(4,r1),r2
    c.r[0] = ld32(0x06020F44u);  // 06020F0C mov.l 0x06020F44,r0
    st32(c.r[7], c.r[2]);  // 06020F0E mov.l r2,@r7
    c.r[2] = 0x0u;  // 06020F10 mov #0,r2
    st32(c.r[1] + 4, c.r[2]); goto L_06020F20;  // 06020F12 bra 0x06020F20 ; mov.l r2,@(4,r1)
L_06020F16:
    c.r[1] = ld32(0x06020F48u);  // 06020F16 mov.l 0x06020F48,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06020F18 mov.b @r1,r0
    c.r[0] &= 0x7Fu;  // 06020F1A and #127,r0
    st8(c.r[1], c.r[0]);  // 06020F1C mov.b r0,@r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06020F36u);  // 06020F1E mov.w 0x06020F36,r0
L_06020F20:
    c.r[14] += 76;  // 06020F20 add #76,r14
    c.r[15] = c.r[14];  // 06020F22 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06020F24 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06020F26 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06020F28 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06020F2A mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06020F2C mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06020F2E mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06020F30 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06020F32 rts ; mov.l @r15+,r8
}

void f_06020F4C(SH2Context& c) {
    ran[399] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06020F4C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06020F4E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06020F50 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06020F52 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06020F54 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06020F56 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06020F58 mov r15,r14
    c.r[11] = c.r[4] & 0xFFu;  // 06020F5A extu.b r4,r11
    c.r[10] = c.r[5] & 0xFFu;  // 06020F5C extu.b r5,r10
    c.r[5] = c.r[6] & 0xFFu;  // 06020F5E extu.b r6,r5
    c.r[9] = c.r[5];  // 06020F60 mov r5,r9
    c.r[6] = c.r[7] & 0xFFu;  // 06020F62 extu.b r7,r6
    c.r[4] = c.r[6];  // 06020F64 mov r6,r4
    c.r[2] = ld32(c.r[14] + 24);  // 06020F66 mov.l @(24,r14),r2
    c.r[8] = ld32(0x06020FD8u);  // 06020F68 mov.l 0x06020FD8,r8
    c.r[1] = ld32(c.r[14] + 28);  // 06020F6A mov.l @(28,r14),r1
    c.r[7] = c.r[2] & 0xFFu;  // 06020F6C extu.b r2,r7
    c.r[1] = c.r[1] & 0xFFu;  // 06020F6E extu.b r1,r1
    c.r[3] = c.r[1];  // 06020F70 mov r1,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x06020FD4u);  // 06020F72 mov.w 0x06020FD4,r1
    c.t = c.r[3] == c.r[1];  // 06020F74 cmp/eq r1,r3
    { const bool k = !c.t; c.r[2] = c.r[7]; if (k) { goto L_06020F82; } }  // 06020F76 bf/s 0x06020F82 ; mov r7,r2
    c.r[1] = 0x1u;  // 06020F7A mov #1,r1
    c.r[0] = ld32(0x06020FDCu);  // 06020F7C mov.l 0x06020FDC,r0
    c.r[15] -= 4; st32(c.r[15], c.r[1]); goto L_06020F8C;  // 06020F7E bra 0x06020F8C ; mov.l r1,@-r15
L_06020F82:
    c.r[15] -= 4; st32(c.r[15], c.r[3]);  // 06020F82 mov.l r3,@-r15
    c.r[0] = ld32(0x06020FE0u);  // 06020F84 mov.l 0x06020FE0,r0
    c.r[7] = c.r[2];  // 06020F86 mov r2,r7
    c.r[6] = c.r[4];  // 06020F88 mov r4,r6
    c.r[5] = c.r[9];  // 06020F8A mov r9,r5
L_06020F8C:
    { const uint32_t x = c.r[0]; c.pr = 0x06020F90u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06020F90u) return; }  // 06020F8C jsr @r0 ; mov r8,r4
    c.r[7] = c.r[0] & 0xFFu;  // 06020F90 extu.b r0,r7
    c.r[1] = 0x0u;  // 06020F92 mov #0,r1
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[7];  // 06020F94 cmp/ge r7,r1
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_06020FC4; } }  // 06020F96 bt/s 0x06020FC4 ; mov #0,r0
    c.r[2] = c.r[8];  // 06020F9A mov r8,r2
    c.r[3] = 0x0u;  // 06020F9C mov #0,r3
    c.r[7] += c.r[7];  // 06020F9E add r7,r7
    c.r[7] += c.r[2];  // 06020FA0 add r2,r7
L_06020FA2:
    c.r[0] = c.r[3];  // 06020FA2 mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 06020FA4 mov.b @(r0,r8),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06020FA6 extu.b r1,r1
    c.t = c.r[11] == c.r[1];  // 06020FA8 cmp/eq r1,r11
    { const bool k = !c.t; c.r[1] = c.r[2]; if (k) { goto L_06020FBA; } }  // 06020FAA bf/s 0x06020FBA ; mov r2,r1
    c.r[1] += 1;  // 06020FAE add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06020FB0 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06020FB2 extu.b r1,r1
    c.t = c.r[10] == c.r[1];  // 06020FB4 cmp/eq r1,r10
    { const bool k = c.t; c.r[0] = 0x1u; if (k) { goto L_06020FC4; } }  // 06020FB6 bt/s 0x06020FC4 ; mov #1,r0
L_06020FBA:
    c.r[2] += 2;  // 06020FBA add #2,r2
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[7];  // 06020FBC cmp/ge r7,r2
    { const bool k = !c.t; c.r[3] += 2; if (k) { SH2_POLL(c); goto L_06020FA2; } }  // 06020FBE bf/s 0x06020FA2 ; add #2,r3
    c.r[0] = 0x0u;  // 06020FC2 mov #0,r0
L_06020FC4:
    c.r[15] = c.r[14];  // 06020FC4 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06020FC6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06020FC8 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06020FCA mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06020FCC mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06020FCE mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06020FD0 rts ; mov.l @r15+,r8
}

void f_06020FE4(SH2Context& c) {
    ran[400] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06020FE4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06020FE6 sts.l pr,@-r15
    c.r[1] = ld32(0x06021004u);  // 06020FE8 mov.l 0x06021004,r1
    c.r[1] = ld32(c.r[1]);  // 06020FEA mov.l @r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06020FEC mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06020FEE extu.b r1,r0
    c.r[0] <<= 2;  // 06020FF0 shll2 r0
    c.r[1] = ld32(0x06021008u);  // 06020FF2 mov.l 0x06021008,r1
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 06020FF4 mov.l @(r0,r1),r0
    { const uint32_t x = c.r[0]; c.pr = 0x06020FFAu; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06020FFAu) return; }  // 06020FF6 jsr @r0 ; mov r15,r14
    c.r[15] = c.r[14];  // 06020FFA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06020FFC lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06020FFE mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[0] & 0xFFFFu; c.pc = x; return; }  // 06021000 rts ; extu.w r0,r0
}

void f_0602100C(SH2Context& c) {
    ran[401] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0602100C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602100E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06021010 sts.l pr,@-r15
    c.r[1] = ld32(0x06021060u);  // 06021012 mov.l 0x06021060,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06021018u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06021018u) return; }  // 06021014 jsr @r1 ; mov r15,r14
    c.r[8] = ld32(0x06021064u);  // 06021018 mov.l 0x06021064,r8
    c.r[2] = ld32(c.r[8]);  // 0602101A mov.l @r8,r2
    c.r[0] = ld32(0x06021068u);  // 0602101C mov.l 0x06021068,r0
    c.r[1] = c.r[2];  // 0602101E mov r2,r1
    c.r[1] += 1;  // 06021020 add #1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06021022 mov.b @r1,r4
    c.r[2] += 2;  // 06021024 add #2,r2
    c.r[4] = c.r[4] & 0xFFu;  // 06021026 extu.b r4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06021028 mov.b @r2,r1
    c.r[4] <<= 8;  // 0602102A shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 0602102C extu.b r1,r1
    { const uint32_t x = c.r[0]; c.pr = 0x06021032u; c.r[4] |= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06021032u) return; }  // 0602102E jsr @r0 ; or r1,r4
    c.r[0] = c.r[0] & 0xFFu;  // 06021032 extu.b r0,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0602105Cu);  // 06021034 mov.w 0x0602105C,r1
    c.t = c.r[0] == c.r[1];  // 06021036 cmp/eq r1,r0
    if (c.t) { goto L_06021050; }  // 06021038 bt 0x06021050
    c.r[1] = ld32(c.r[8]);  // 0602103A mov.l @r8,r1
    c.r[4] = (uint32_t)(int32_t)(int16_t)c.r[0];  // 0602103C exts.w r0,r4
    c.r[1] += 3;  // 0602103E add #3,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06021040 mov.b @r1,r5
    c.r[6] = 0x0u;  // 06021042 mov #0,r6
    c.r[1] = ld32(0x0602106Cu);  // 06021044 mov.l 0x0602106C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602104Au; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602104Au) return; }  // 06021046 jsr @r1 ; extu.b r5,r5
    c.r[1] = ld32(0x06021070u);  // 0602104A mov.l 0x06021070,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06021050u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06021050u) return; }  // 0602104C jsr @r1 ; nop
L_06021050:
    c.r[15] = c.r[14];  // 06021050 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06021052 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06021054 mov.l @r15+,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602105Eu);  // 06021056 mov.w 0x0602105E,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06021058 rts ; mov.l @r15+,r8
}

void f_06021074(SH2Context& c) {
    ran[402] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06021074 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06021076 mov r15,r14
    c.r[1] = ld32(0x06021098u);  // 06021078 mov.l 0x06021098,r1
    c.r[2] = ld32(c.r[1]);  // 0602107A mov.l @r1,r2
    c.r[3] = ld32(0x0602109Cu);  // 0602107C mov.l 0x0602109C,r3
    c.r[1] = c.r[2];  // 0602107E mov r2,r1
    c.r[1] += 1;  // 06021080 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06021082 mov.b @r1,r1
    c.r[2] += 2;  // 06021084 add #2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06021086 extu.b r1,r1
    st32(c.r[3] + 12, c.r[1]);  // 06021088 mov.l r1,@(12,r3)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602108A mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602108C extu.b r1,r1
    st32(c.r[3] + 16, c.r[1]);  // 0602108E mov.l r1,@(16,r3)
    c.r[0] = (uint32_t)(int16_t)ld16(0x06021096u);  // 06021090 mov.w 0x06021096,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06021092 rts ; mov.l @r15+,r14
}

void f_060210A0(SH2Context& c) {
    ran[403] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060210A0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060210A2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060210A4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060210A6 sts.l pr,@-r15
    c.r[1] = ld32(0x060210ECu);  // 060210A8 mov.l 0x060210EC,r1
    c.r[1] = ld32(c.r[1]);  // 060210AA mov.l @r1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 060210AC mov.b @r1+,r2
    c.r[14] = c.r[15];  // 060210AE mov r15,r14
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060210B0 mov.b @r1,r1
    c.r[8] = c.r[1] & 0xFFu;  // 060210B2 extu.b r1,r8
    c.r[1] = ld32(0x060210F0u);  // 060210B4 mov.l 0x060210F0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060210BAu; c.r[9] = c.r[2] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060210BAu) return; }  // 060210B6 jsr @r1 ; extu.b r2,r9
    c.t = (c.r[9] & c.r[9]) == 0;  // 060210BA tst r9,r9
    { const bool k = c.t; c.t = c.r[9] == c.r[8]; if (k) { goto L_060210DA; } }  // 060210BC bt/s 0x060210DA ; cmp/eq r8,r9
    if (c.t) { goto L_060210D4; }  // 060210C0 bt 0x060210D4
    c.r[0] = ld32(0x060210F4u);  // 060210C2 mov.l 0x060210F4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060210C8u; c.r[9] += 1; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060210C8u) return; }  // 060210C4 jsr @r0 ; add #1,r9
    c.macl = c.r[0] * c.r[8];  // 060210C8 mul.l r8,r0
    c.r[1] = c.macl;  // 060210CA sts macl,r1
    c.r[1] >>= 16;  // 060210CC shlr16 r1
    c.r[1] += c.r[9];  // 060210CE add r9,r1
    c.t = c.r[1] > c.r[8];  // 060210D0 cmp/hi r8,r1
    if (!c.t) { goto L_060210DA; }  // 060210D2 bf 0x060210DA
L_060210D4:
    c.r[1] = ld32(0x060210F8u);  // 060210D4 mov.l 0x060210F8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060210DAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060210DAu) return; }  // 060210D6 jsr @r1 ; nop
L_060210DA:
    c.r[15] = c.r[14];  // 060210DA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060210DC lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060210DE mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060210E0 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x060210E8u);  // 060210E2 mov.w 0x060210E8,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060210E4 rts ; mov.l @r15+,r8
}

void f_060210FC(SH2Context& c) {
    ran[404] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060210FC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060210FE sts.l pr,@-r15
    c.r[1] = ld32(0x0602111Cu);  // 06021100 mov.l 0x0602111C,r1
    c.r[1] = ld32(c.r[1]);  // 06021102 mov.l @r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06021104 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06021106 extu.b r1,r0
    c.r[0] <<= 2;  // 06021108 shll2 r0
    c.r[1] = ld32(0x06021120u);  // 0602110A mov.l 0x06021120,r1
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 0602110C mov.l @(r0,r1),r0
    { const uint32_t x = c.r[0]; c.pr = 0x06021112u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06021112u) return; }  // 0602110E jsr @r0 ; mov r15,r14
    c.r[15] = c.r[14];  // 06021112 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06021114 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06021116 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[0] & 0xFFFFu; c.pc = x; return; }  // 06021118 rts ; extu.w r0,r0
}

void f_06021124(SH2Context& c) {
    ran[405] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06021124 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06021126 sts.l pr,@-r15
    c.r[1] = ld32(0x06021150u);  // 06021128 mov.l 0x06021150,r1
    c.r[2] = ld32(c.r[1]);  // 0602112A mov.l @r1,r2
    c.r[1] = c.r[2];  // 0602112C mov r2,r1
    c.r[1] += 1;  // 0602112E add #1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06021130 mov.b @r1,r4
    c.r[2] += 2;  // 06021132 add #2,r2
    c.r[4] = c.r[4] & 0xFFu;  // 06021134 extu.b r4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06021136 mov.b @r2,r1
    c.r[4] <<= 8;  // 06021138 shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 0602113A extu.b r1,r1
    c.r[4] |= c.r[1];  // 0602113C or r1,r4
    c.r[1] = ld32(0x06021154u);  // 0602113E mov.l 0x06021154,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06021144u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06021144u) return; }  // 06021140 jsr @r1 ; mov r15,r14
    c.r[15] = c.r[14];  // 06021144 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06021146 lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602114Eu);  // 06021148 mov.w 0x0602114E,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602114A rts ; mov.l @r15+,r14
}

void f_06021158(SH2Context& c) {
    ran[406] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06021158 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602115A sts.l pr,@-r15
    c.r[1] = ld32(0x06021184u);  // 0602115C mov.l 0x06021184,r1
    c.r[2] = ld32(c.r[1]);  // 0602115E mov.l @r1,r2
    c.r[1] = c.r[2];  // 06021160 mov r2,r1
    c.r[1] += 1;  // 06021162 add #1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06021164 mov.b @r1,r4
    c.r[2] += 2;  // 06021166 add #2,r2
    c.r[4] = c.r[4] & 0xFFu;  // 06021168 extu.b r4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602116A mov.b @r2,r1
    c.r[4] <<= 8;  // 0602116C shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 0602116E extu.b r1,r1
    c.r[4] |= c.r[1];  // 06021170 or r1,r4
    c.r[1] = ld32(0x06021188u);  // 06021172 mov.l 0x06021188,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06021178u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06021178u) return; }  // 06021174 jsr @r1 ; mov r15,r14
    c.r[15] = c.r[14];  // 06021178 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602117A lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x06021182u);  // 0602117C mov.w 0x06021182,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602117E rts ; mov.l @r15+,r14
}

void f_0602118C(SH2Context& c) {
    ran[407] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602118C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602118E sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06021190 mov r15,r14
    c.r[1] = ld32(0x060211CCu);  // 06021192 mov.l 0x060211CC,r1
    c.r[2] = ld32(c.r[1]);  // 06021194 mov.l @r1,r2
    c.r[0] = ld32(0x060211D0u);  // 06021196 mov.l 0x060211D0,r0
    c.r[1] = c.r[2];  // 06021198 mov r2,r1
    c.r[1] += 1;  // 0602119A add #1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602119C mov.b @r1,r4
    c.r[2] += 2;  // 0602119E add #2,r2
    c.r[4] = c.r[4] & 0xFFu;  // 060211A0 extu.b r4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060211A2 mov.b @r2,r1
    c.r[4] <<= 8;  // 060211A4 shll8 r4
    c.r[1] = c.r[1] & 0xFFu;  // 060211A6 extu.b r1,r1
    { const uint32_t x = c.r[0]; c.pr = 0x060211ACu; c.r[4] |= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060211ACu) return; }  // 060211A8 jsr @r0 ; or r1,r4
    c.r[1] = c.r[0] & 0xFFFFu;  // 060211AC extu.w r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060211AE tst r1,r1
    if (c.t) { goto L_060211B8; }  // 060211B0 bt 0x060211B8
    c.r[1] = ld32(0x060211D4u);  // 060211B2 mov.l 0x060211D4,r1
    goto L_060211BA;  // 060211B4 bra 0x060211BA ; nop
L_060211B8:
    c.r[1] = ld32(0x060211D8u);  // 060211B8 mov.l 0x060211D8,r1
L_060211BA:
    { const uint32_t x = c.r[1]; c.pr = 0x060211BEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060211BEu) return; }  // 060211BA jsr @r1 ; nop
    c.r[15] = c.r[14];  // 060211BE mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060211C0 lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x060211C8u);  // 060211C2 mov.w 0x060211C8,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060211C4 rts ; mov.l @r15+,r14
}

void f_060211DC(SH2Context& c) {
    ran[408] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060211DC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060211DE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060211E0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060211E2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060211E4 sts.l pr,@-r15
    c.r[1] = ld32(0x06021240u);  // 060211E6 mov.l 0x06021240,r1
    c.r[2] = ld32(c.r[1]);  // 060211E8 mov.l @r1,r2
    c.r[1] = c.r[2];  // 060211EA mov r2,r1
    c.r[1] += 1;  // 060211EC add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060211EE mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060211F0 extu.b r1,r1
    c.r[4] = c.r[1];  // 060211F2 mov r1,r4
    c.r[4] <<= 8;  // 060211F4 shll8 r4
    c.r[1] = c.r[2];  // 060211F6 mov r2,r1
    c.r[1] += 2;  // 060211F8 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060211FA mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060211FC extu.b r1,r1
    c.r[4] |= c.r[1];  // 060211FE or r1,r4
    c.r[1] = c.r[2];  // 06021200 mov r2,r1
    c.r[1] += 3;  // 06021202 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06021204 mov.b @r1,r1
    c.r[2] += 4;  // 06021206 add #4,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06021208 extu.b r1,r1
    c.r[9] = c.r[1];  // 0602120A mov r1,r9
    c.r[9] <<= 8;  // 0602120C shll8 r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602120E mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06021210 extu.b r1,r1
    c.r[9] |= c.r[1];  // 06021212 or r1,r9
    c.t = c.r[4] >= c.r[9];  // 06021214 cmp/hs r9,r4
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0602122C; } }  // 06021216 bt/s 0x0602122C ; mov r15,r14
    c.r[8] = c.r[4];  // 0602121A mov r4,r8
    c.r[10] = ld32(0x06021244u);  // 0602121C mov.l 0x06021244,r10
L_0602121E:
    { const uint32_t x = c.r[10]; c.pr = 0x06021222u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06021222u) return; }  // 0602121E jsr @r10 ; mov r8,r4
    c.r[1] = c.r[8];  // 06021222 mov r8,r1
    c.r[1] += 1;  // 06021224 add #1,r1
    c.r[8] = c.r[1] & 0xFFFFu;  // 06021226 extu.w r1,r8
    c.t = c.r[8] > c.r[9];  // 06021228 cmp/hi r9,r8
    if (!c.t) { SH2_POLL(c); goto L_0602121E; }  // 0602122A bf 0x0602121E
L_0602122C:
    c.r[15] = c.r[14];  // 0602122C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602122E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06021230 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06021232 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06021234 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602123Cu);  // 06021236 mov.w 0x0602123C,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06021238 rts ; mov.l @r15+,r8
}

void f_06021248(SH2Context& c) {
    ran[409] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06021248 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0602124A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602124C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602124E sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06021250 mov r15,r14
    c.r[1] = ld32(0x06021290u);  // 06021252 mov.l 0x06021290,r1
    c.r[2] = ld32(c.r[1]);  // 06021254 mov.l @r1,r2
    c.r[0] = ld32(0x06021294u);  // 06021256 mov.l 0x06021294,r0
    c.r[1] = c.r[2];  // 06021258 mov r2,r1
    c.r[1] += 1;  // 0602125A add #1,r1
    c.r[9] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602125C mov.b @r1,r9
    c.r[2] += 2;  // 0602125E add #2,r2
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06021260 mov.b @r2,r8
    c.r[9] = c.r[9] & 0xFFu;  // 06021262 extu.b r9,r9
    c.r[8] = c.r[8] & 0xFFu;  // 06021264 extu.b r8,r8
    c.r[5] = c.r[8];  // 06021266 mov r8,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0602126Cu; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602126Cu) return; }  // 06021268 jsr @r0 ; mov r9,r4
    c.r[2] = c.r[0];  // 0602126C mov r0,r2
    c.r[1] = ld32(0x06021298u);  // 0602126E mov.l 0x06021298,r1
    c.r[2] += 1;  // 06021270 add #1,r2
    st32(c.r[1] + 20, c.r[2]);  // 06021272 mov.l r2,@(20,r1)
    c.r[0] = ld32(0x0602129Cu);  // 06021274 mov.l 0x0602129C,r0
    c.r[6] = c.r[2];  // 06021276 mov r2,r6
    c.r[5] = c.r[8];  // 06021278 mov r8,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0602127Eu; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602127Eu) return; }  // 0602127A jsr @r0 ; mov r9,r4
    c.r[15] = c.r[14];  // 0602127E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06021280 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06021282 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06021284 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602128Cu);  // 06021286 mov.w 0x0602128C,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06021288 rts ; mov.l @r15+,r8
}

void f_060212A0(SH2Context& c) {
    ran[410] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060212A0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060212A2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060212A4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060212A6 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060212A8 mov r15,r14
    c.r[1] = ld32(0x060212E8u);  // 060212AA mov.l 0x060212E8,r1
    c.r[2] = ld32(c.r[1]);  // 060212AC mov.l @r1,r2
    c.r[0] = ld32(0x060212ECu);  // 060212AE mov.l 0x060212EC,r0
    c.r[1] = c.r[2];  // 060212B0 mov r2,r1
    c.r[1] += 1;  // 060212B2 add #1,r1
    c.r[9] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060212B4 mov.b @r1,r9
    c.r[2] += 2;  // 060212B6 add #2,r2
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060212B8 mov.b @r2,r8
    c.r[9] = c.r[9] & 0xFFu;  // 060212BA extu.b r9,r9
    c.r[8] = c.r[8] & 0xFFu;  // 060212BC extu.b r8,r8
    c.r[5] = c.r[8];  // 060212BE mov r8,r5
    { const uint32_t x = c.r[0]; c.pr = 0x060212C4u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060212C4u) return; }  // 060212C0 jsr @r0 ; mov r9,r4
    c.r[2] = c.r[0];  // 060212C4 mov r0,r2
    c.r[1] = ld32(0x060212F0u);  // 060212C6 mov.l 0x060212F0,r1
    c.r[2] -= 1;  // 060212C8 add #-1,r2
    st32(c.r[1] + 20, c.r[2]);  // 060212CA mov.l r2,@(20,r1)
    c.r[0] = ld32(0x060212F4u);  // 060212CC mov.l 0x060212F4,r0
    c.r[6] = c.r[2];  // 060212CE mov r2,r6
    c.r[5] = c.r[8];  // 060212D0 mov r8,r5
    { const uint32_t x = c.r[0]; c.pr = 0x060212D6u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060212D6u) return; }  // 060212D2 jsr @r0 ; mov r9,r4
    c.r[15] = c.r[14];  // 060212D6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060212D8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060212DA mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060212DC mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x060212E4u);  // 060212DE mov.w 0x060212E4,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060212E0 rts ; mov.l @r15+,r8
}

void f_060212F8(SH2Context& c) {
    ran[411] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060212F8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060212FA sts.l pr,@-r15
    c.r[1] = ld32(0x06021334u);  // 060212FC mov.l 0x06021334,r1
    c.r[2] = ld32(c.r[1]);  // 060212FE mov.l @r1,r2
    c.r[14] = c.r[15];  // 06021300 mov r15,r14
    c.r[1] = c.r[2];  // 06021302 mov r2,r1
    c.r[1] += 1;  // 06021304 add #1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06021306 mov.b @r1,r4
    c.r[0] = ld32(0x06021338u);  // 06021308 mov.l 0x06021338,r0
    c.r[1] = c.r[2];  // 0602130A mov r2,r1
    c.r[1] += 2;  // 0602130C add #2,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602130E mov.b @r1,r5
    c.r[4] = c.r[4] & 0xFFu;  // 06021310 extu.b r4,r4
    c.r[5] = c.r[5] & 0xFFu;  // 06021312 extu.b r5,r5
    c.r[1] = c.r[2];  // 06021314 mov r2,r1
    c.r[1] += 3;  // 06021316 add #3,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06021318 mov.b @r1,r6
    c.r[2] += 4;  // 0602131A add #4,r2
    c.r[6] = c.r[6] & 0xFFu;  // 0602131C extu.b r6,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602131E mov.b @r2,r1
    c.r[6] <<= 8;  // 06021320 shll8 r6
    c.r[1] = c.r[1] & 0xFFu;  // 06021322 extu.b r1,r1
    { const uint32_t x = c.r[0]; c.pr = 0x06021328u; c.r[6] |= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06021328u) return; }  // 06021324 jsr @r0 ; or r1,r6
    c.r[15] = c.r[14];  // 06021328 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602132A lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x06021332u);  // 0602132C mov.w 0x06021332,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602132E rts ; mov.l @r15+,r14
}

void f_0602133C(SH2Context& c) {
    ran[412] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602133C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602133E sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06021340 mov r15,r14
    c.r[1] = ld32(0x06021368u);  // 06021342 mov.l 0x06021368,r1
    c.r[2] = ld32(c.r[1]);  // 06021344 mov.l @r1,r2
    c.r[0] = ld32(0x0602136Cu);  // 06021346 mov.l 0x0602136C,r0
    c.r[1] = c.r[2];  // 06021348 mov r2,r1
    c.r[1] += 1;  // 0602134A add #1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602134C mov.b @r1,r4
    c.r[2] += 2;  // 0602134E add #2,r2
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06021350 mov.b @r2,r5
    c.r[4] = c.r[4] & 0xFFu;  // 06021352 extu.b r4,r4
    { const uint32_t x = c.r[0]; c.pr = 0x06021358u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06021358u) return; }  // 06021354 jsr @r0 ; extu.b r5,r5
    c.r[1] = ld32(0x06021370u);  // 06021358 mov.l 0x06021370,r1
    st32(c.r[1] + 20, c.r[0]);  // 0602135A mov.l r0,@(20,r1)
    c.r[15] = c.r[14];  // 0602135C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602135E lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x06021366u);  // 06021360 mov.w 0x06021366,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06021362 rts ; mov.l @r15+,r14
}

void f_06021374(SH2Context& c) {
    ran[413] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06021374 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06021376 mov r15,r14
    c.r[1] = ld32(0x060213A0u);  // 06021378 mov.l 0x060213A0,r1
    c.r[3] = ld32(c.r[1]);  // 0602137A mov.l @r1,r3
    c.r[1] = c.r[3];  // 0602137C mov r3,r1
    c.r[1] += 1;  // 0602137E add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06021380 mov.b @r1,r2
    c.r[3] += 2;  // 06021382 add #2,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06021384 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06021386 mov.b @r3,r1
    c.r[2] <<= 8;  // 06021388 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0602138A extu.b r1,r1
    c.r[2] |= c.r[1];  // 0602138C or r1,r2
    c.r[1] = ld32(0x060213A4u);  // 0602138E mov.l 0x060213A4,r1
    c.r[3] = ld32(c.r[1] + 20);  // 06021390 mov.l @(20,r1),r3
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 06021392 exts.w r2,r2
    c.r[3] += c.r[2];  // 06021394 add r2,r3
    st32(c.r[1] + 20, c.r[3]);  // 06021396 mov.l r3,@(20,r1)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602139Eu);  // 06021398 mov.w 0x0602139E,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602139A rts ; mov.l @r15+,r14
}

void f_060213A8(SH2Context& c) {
    ran[414] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060213A8 mov.l r14,@-r15
    c.r[1] = ld32(0x060213D4u);  // 060213AA mov.l 0x060213D4,r1
    c.r[3] = ld32(c.r[1]);  // 060213AC mov.l @r1,r3
    c.r[14] = c.r[15];  // 060213AE mov r15,r14
    c.r[1] = c.r[3];  // 060213B0 mov r3,r1
    c.r[1] += 1;  // 060213B2 add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060213B4 mov.b @r1,r2
    c.r[3] += 2;  // 060213B6 add #2,r3
    c.r[2] = c.r[2] & 0xFFu;  // 060213B8 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060213BA mov.b @r3,r1
    c.r[2] <<= 8;  // 060213BC shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 060213BE extu.b r1,r1
    c.r[2] |= c.r[1];  // 060213C0 or r1,r2
    c.r[3] = ld32(0x060213D8u);  // 060213C2 mov.l 0x060213D8,r3
    c.r[1] = ld32(c.r[3] + 20);  // 060213C4 mov.l @(20,r3),r1
    c.r[2] -= c.r[1];  // 060213C6 sub r1,r2
    st32(c.r[3] + 20, c.r[2]);  // 060213C8 mov.l r2,@(20,r3)
    c.r[0] = (uint32_t)(int16_t)ld16(0x060213D0u);  // 060213CA mov.w 0x060213D0,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060213CC rts ; mov.l @r15+,r14
}

void f_060213DC(SH2Context& c) {
    ran[415] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060213DC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060213DE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060213E0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060213E2 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060213E4 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060213E6 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060213E8 sts.l pr,@-r15
    c.r[1] = ld32(0x06021438u);  // 060213EA mov.l 0x06021438,r1
    c.r[2] = ld32(c.r[1]);  // 060213EC mov.l @r1,r2
    c.r[14] = c.r[15];  // 060213EE mov r15,r14
    c.r[1] = c.r[2];  // 060213F0 mov r2,r1
    c.r[1] += 1;  // 060213F2 add #1,r1
    c.r[10] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060213F4 mov.b @r1,r10
    c.r[11] = ld32(0x0602143Cu);  // 060213F6 mov.l 0x0602143C,r11
    c.r[10] = c.r[10] & 0xFFu;  // 060213F8 extu.b r10,r10
    c.r[1] = c.r[2];  // 060213FA mov r2,r1
    c.r[1] += 2;  // 060213FC add #2,r1
    c.r[2] += 3;  // 060213FE add #3,r2
    c.r[9] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06021400 mov.b @r1,r9
    c.r[4] = c.r[10];  // 06021402 mov r10,r4
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06021404 mov.b @r2,r8
    c.r[9] = c.r[9] & 0xFFu;  // 06021406 extu.b r9,r9
    c.r[8] = c.r[8] & 0xFFu;  // 06021408 extu.b r8,r8
    { const uint32_t x = c.r[11]; c.pr = 0x0602140Eu; c.r[5] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602140Eu) return; }  // 0602140A jsr @r11 ; mov r8,r5
    c.r[12] = c.r[0];  // 0602140E mov r0,r12
    c.r[5] = c.r[8];  // 06021410 mov r8,r5
    { const uint32_t x = c.r[11]; c.pr = 0x06021416u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06021416u) return; }  // 06021412 jsr @r11 ; mov r9,r4
    c.r[12] += c.r[0];  // 06021416 add r0,r12
    c.r[0] = ld32(0x06021440u);  // 06021418 mov.l 0x06021440,r0
    c.r[6] = c.r[12];  // 0602141A mov r12,r6
    c.r[5] = c.r[8];  // 0602141C mov r8,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06021422u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06021422u) return; }  // 0602141E jsr @r0 ; mov r10,r4
    c.r[15] = c.r[14];  // 06021422 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06021424 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06021426 mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06021428 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0602142A mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0602142C mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0602142E mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06021436u);  // 06021430 mov.w 0x06021436,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06021432 rts ; mov.l @r15+,r8
}

void f_06021444(SH2Context& c) {
    ran[416] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06021444 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06021446 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06021448 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602144A sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0602144C mov r15,r14
    c.r[1] = ld32(0x0602148Cu);  // 0602144E mov.l 0x0602148C,r1
    c.r[2] = ld32(c.r[1]);  // 06021450 mov.l @r1,r2
    c.r[0] = ld32(0x06021490u);  // 06021452 mov.l 0x06021490,r0
    c.r[1] = c.r[2];  // 06021454 mov r2,r1
    c.r[1] += 1;  // 06021456 add #1,r1
    c.r[9] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06021458 mov.b @r1,r9
    c.r[2] += 2;  // 0602145A add #2,r2
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0602145C mov.b @r2,r8
    c.r[9] = c.r[9] & 0xFFu;  // 0602145E extu.b r9,r9
    c.r[8] = c.r[8] & 0xFFu;  // 06021460 extu.b r8,r8
    c.r[5] = c.r[8];  // 06021462 mov r8,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06021468u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06021468u) return; }  // 06021464 jsr @r0 ; mov r9,r4
    c.r[2] = c.r[0];  // 06021468 mov r0,r2
    c.r[1] = ld32(0x06021494u);  // 0602146A mov.l 0x06021494,r1
    c.r[0] = ld32(0x06021498u);  // 0602146C mov.l 0x06021498,r0
    c.r[5] = c.r[8];  // 0602146E mov r8,r5
    c.r[1] = ld32(c.r[1] + 20);  // 06021470 mov.l @(20,r1),r1
    c.r[4] = c.r[9];  // 06021472 mov r9,r4
    c.r[2] += c.r[1];  // 06021474 add r1,r2
    { const uint32_t x = c.r[0]; c.pr = 0x0602147Au; c.r[6] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602147Au) return; }  // 06021476 jsr @r0 ; mov r2,r6
    c.r[15] = c.r[14];  // 0602147A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602147C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602147E mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06021480 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06021488u);  // 06021482 mov.w 0x06021488,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06021484 rts ; mov.l @r15+,r8
}

void f_0602149C(SH2Context& c) {
    ran[417] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602149C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602149E sts.l pr,@-r15
    c.r[1] = ld32(0x060214BCu);  // 060214A0 mov.l 0x060214BC,r1
    c.r[1] = ld32(c.r[1]);  // 060214A2 mov.l @r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060214A4 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 060214A6 extu.b r1,r0
    c.r[0] <<= 2;  // 060214A8 shll2 r0
    c.r[1] = ld32(0x060214C0u);  // 060214AA mov.l 0x060214C0,r1
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 060214AC mov.l @(r0,r1),r0
    { const uint32_t x = c.r[0]; c.pr = 0x060214B2u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060214B2u) return; }  // 060214AE jsr @r0 ; mov r15,r14
    c.r[15] = c.r[14];  // 060214B2 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060214B4 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060214B6 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[0] & 0xFFFFu; c.pc = x; return; }  // 060214B8 rts ; extu.w r0,r0
}

void f_060214C4(SH2Context& c) {
    ran[418] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060214C4 mov.l r14,@-r15
    c.r[3] = ld32(0x060214ECu);  // 060214C6 mov.l 0x060214EC,r3
    c.r[1] = ld32(c.r[3]);  // 060214C8 mov.l @r3,r1
    c.r[14] = c.r[15];  // 060214CA mov r15,r14
    c.r[2] = c.r[1];  // 060214CC mov r1,r2
    c.r[1] += 6;  // 060214CE add #6,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060214D0 mov.b @r1,r1
    c.r[2] += 7;  // 060214D2 add #7,r2
    st8(c.r[2], c.r[1]);  // 060214D4 mov.b r1,@r2
    c.r[1] = ld32(0x060214F0u);  // 060214D6 mov.l 0x060214F0,r1
    c.r[1] = ld32(c.r[1]);  // 060214D8 mov.l @r1,r1
    c.r[2] = ld32(c.r[3]);  // 060214DA mov.l @r3,r2
    c.r[1] += 1;  // 060214DC add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060214DE mov.b @r1,r1
    c.r[2] += 6;  // 060214E0 add #6,r2
    st8(c.r[2], c.r[1]);  // 060214E2 mov.b r1,@r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x060214EAu);  // 060214E4 mov.w 0x060214EA,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060214E6 rts ; mov.l @r15+,r14
}

void f_060214F4(SH2Context& c) {
    ran[419] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060214F4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060214F6 sts.l pr,@-r15
    c.r[1] = ld32(0x06021514u);  // 060214F8 mov.l 0x06021514,r1
    c.r[1] = ld32(c.r[1]);  // 060214FA mov.l @r1,r1
    c.r[14] = c.r[15];  // 060214FC mov r15,r14
    c.r[1] += 6;  // 060214FE add #6,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06021500 mov.b @r1,r4
    c.r[0] = ld32(0x06021518u);  // 06021502 mov.l 0x06021518,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06021508u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06021508u) return; }  // 06021504 jsr @r0 ; extu.b r4,r4
    c.r[15] = c.r[14];  // 06021508 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602150A lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x06021512u);  // 0602150C mov.w 0x06021512,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602150E rts ; mov.l @r15+,r14
}

void f_0602151C(SH2Context& c) {
    ran[420] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602151C mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0602151E mov r15,r14
    c.r[1] = ld32(0x06021538u);  // 06021520 mov.l 0x06021538,r1
    c.r[1] = ld32(c.r[1]);  // 06021522 mov.l @r1,r1
    c.r[2] = ld32(0x0602153Cu);  // 06021524 mov.l 0x0602153C,r2
    c.r[1] += 6;  // 06021526 add #6,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06021528 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602152A extu.b r1,r1
    st32(c.r[2] + 20, c.r[1]);  // 0602152C mov.l r1,@(20,r2)
    c.r[0] = (uint32_t)(int16_t)ld16(0x06021534u);  // 0602152E mov.w 0x06021534,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06021530 rts ; mov.l @r15+,r14
}

void f_06021540(SH2Context& c) {
    ran[421] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06021540 mov.l r14,@-r15
    c.r[1] = ld32(0x0602155Cu);  // 06021542 mov.l 0x0602155C,r1
    c.r[2] = ld32(c.r[1]);  // 06021544 mov.l @r1,r2
    c.r[14] = c.r[15];  // 06021546 mov r15,r14
    c.r[1] = ld32(0x06021560u);  // 06021548 mov.l 0x06021560,r1
    c.r[1] = ld32(c.r[1]);  // 0602154A mov.l @r1,r1
    c.r[1] += 1;  // 0602154C add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602154E mov.b @r1,r1
    c.r[2] += 7;  // 06021550 add #7,r2
    st8(c.r[2], c.r[1]);  // 06021552 mov.b r1,@r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602155Au);  // 06021554 mov.w 0x0602155A,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06021556 rts ; mov.l @r15+,r14
}

void f_06021564(SH2Context& c) {
    ran[422] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06021564 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06021566 mov r15,r14
    c.r[2] = ld32(0x06021578u);  // 06021568 mov.l 0x06021578,r2
    c.r[1] = 0x1u;  // 0602156A mov #1,r1
    st32(c.r[2], c.r[1]);  // 0602156C mov.l r1,@r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06021574u);  // 0602156E mov.w 0x06021574,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06021570 rts ; mov.l @r15+,r14
}

void f_0602157C(SH2Context& c) {
    ran[423] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602157C mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0602157E mov r15,r14
    c.r[2] = ld32(0x06021590u);  // 06021580 mov.l 0x06021590,r2
    c.r[1] = 0x0u;  // 06021582 mov #0,r1
    st32(c.r[2], c.r[1]);  // 06021584 mov.l r1,@r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602158Cu);  // 06021586 mov.w 0x0602158C,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06021588 rts ; mov.l @r15+,r14
}

void f_06021594(SH2Context& c) {
    ran[424] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06021594 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06021596 mov r15,r14
    c.r[2] = ld32(0x060215A8u);  // 06021598 mov.l 0x060215A8,r2
    c.r[1] = 0x1u;  // 0602159A mov #1,r1
    st32(c.r[2], c.r[1]);  // 0602159C mov.l r1,@r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x060215A4u);  // 0602159E mov.w 0x060215A4,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060215A0 rts ; mov.l @r15+,r14
}

void f_060215AC(SH2Context& c) {
    ran[425] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060215AC mov.l r14,@-r15
    c.r[14] = c.r[15];  // 060215AE mov r15,r14
    c.r[2] = ld32(0x060215C0u);  // 060215B0 mov.l 0x060215C0,r2
    c.r[1] = 0x0u;  // 060215B2 mov #0,r1
    st32(c.r[2], c.r[1]);  // 060215B4 mov.l r1,@r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x060215BCu);  // 060215B6 mov.w 0x060215BC,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060215B8 rts ; mov.l @r15+,r14
}

void f_060215C4(SH2Context& c) {
    ran[426] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060215C4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060215C6 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060215C8 sts.l pr,@-r15
    c.r[1] = ld32(0x060215F4u);  // 060215CA mov.l 0x060215F4,r1
    c.r[1] = ld32(c.r[1]);  // 060215CC mov.l @r1,r1
    c.r[8] = ld32(0x060215F8u);  // 060215CE mov.l 0x060215F8,r8
    st32(c.r[8] + 20, c.r[1]);  // 060215D0 mov.l r1,@(20,r8)
    c.r[1] = ld32(0x060215FCu);  // 060215D2 mov.l 0x060215FC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060215D8u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060215D8u) return; }  // 060215D4 jsr @r1 ; mov r15,r14
    c.r[1] = ld32(c.r[8] + 20);  // 060215D8 mov.l @(20,r8),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060215DA tst r1,r1
    if (c.t) { goto L_060215E4; }  // 060215DC bt 0x060215E4
    c.r[1] = ld32(0x06021600u);  // 060215DE mov.l 0x06021600,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060215E4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060215E4u) return; }  // 060215E0 jsr @r1 ; nop
L_060215E4:
    c.r[15] = c.r[14];  // 060215E4 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060215E6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060215E8 mov.l @r15+,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x060215F0u);  // 060215EA mov.w 0x060215F0,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060215EC rts ; mov.l @r15+,r8
}

void f_06021604(SH2Context& c) {
    ran[427] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06021604 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06021606 sts.l pr,@-r15
    c.r[1] = ld32(0x0602165Cu);  // 06021608 mov.l 0x0602165C,r1
    c.r[1] = ld32(c.r[1]);  // 0602160A mov.l @r1,r1
    c.r[1] += 1;  // 0602160C add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602160E mov.b @r1,r1
    c.r[14] = c.r[15];  // 06021610 mov r15,r14
    c.r[0] = c.r[1] & 0xFFu;  // 06021612 extu.b r1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06021614 tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[0]; if (k) { goto L_06021624; } }  // 06021616 bf/s 0x06021624 ; mov r0,r1
    c.r[1] = ld32(0x06021660u);  // 0602161A mov.l 0x06021660,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602161C mov.b @r1,r0
    c.r[0] &= 0xF7u;  // 0602161E and #247,r0
    st8(c.r[1], c.r[0]); goto L_06021650;  // 06021620 bra 0x06021650 ; mov.b r0,@r1
L_06021624:
    c.r[0] = c.r[1];  // 06021624 mov r1,r0
    c.t = c.r[0] == 0x1u;  // 06021626 cmp/eq #1,r0
    if (!c.t) { goto L_06021634; }  // 06021628 bf 0x06021634
    c.r[1] = ld32(0x06021660u);  // 0602162A mov.l 0x06021660,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602162C mov.b @r1,r0
    c.r[0] |= 0x8u;  // 0602162E or #8,r0
    st8(c.r[1], c.r[0]); goto L_06021650;  // 06021630 bra 0x06021650 ; mov.b r0,@r1
L_06021634:
    c.r[1] = ld32(0x06021664u);  // 06021634 mov.l 0x06021664,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602163Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602163Au) return; }  // 06021636 jsr @r1 ; nop
    c.r[1] = ld32(0x06021660u);  // 0602163A mov.l 0x06021660,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602163C mov.b @r1,r1
    c.r[0] = c.r[1];  // 0602163E mov r1,r0
    c.r[0] >>= 2;  // 06021640 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06021642 shlr r0
    c.r[0] &= 0x1u;  // 06021644 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06021646 tst r0,r0
    if (!c.t) { goto L_06021650; }  // 06021648 bf 0x06021650
    c.r[1] = ld32(0x06021668u);  // 0602164A mov.l 0x06021668,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06021650u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06021650u) return; }  // 0602164C jsr @r1 ; nop
L_06021650:
    c.r[15] = c.r[14];  // 06021650 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06021652 lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x0602165Au);  // 06021654 mov.w 0x0602165A,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06021656 rts ; mov.l @r15+,r14
}

void f_0602166C(SH2Context& c) {
    ran[428] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602166C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602166E sts.l pr,@-r15
    c.r[1] = ld32(0x060216C0u);  // 06021670 mov.l 0x060216C0,r1
    c.r[1] = ld32(c.r[1]);  // 06021672 mov.l @r1,r1
    c.r[1] += 1;  // 06021674 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06021676 mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 06021678 extu.b r1,r2
    c.r[0] = c.r[2];  // 0602167A mov r2,r0
    c.t = c.r[0] == 0x2u;  // 0602167C cmp/eq #2,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06021696; } }  // 0602167E bt/s 0x06021696 ; mov r15,r14
    c.r[1] = ld32(0x060216C4u);  // 06021682 mov.l 0x060216C4,r1
    c.r[0] = 0x1u;  // 06021684 mov #1,r0
    c.r[2] &= c.r[0];  // 06021686 and r0,r2
    c.r[2] <<= 2;  // 06021688 shll2 r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602168A mov.b @r1,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x060216BAu);  // 0602168C mov.w 0x060216BA,r0
    c.r[3] &= c.r[0];  // 0602168E and r0,r3
    c.r[3] |= c.r[2];  // 06021690 or r2,r3
    st8(c.r[1], c.r[3]); goto L_060216B0;  // 06021692 bra 0x060216B0 ; mov.b r3,@r1
L_06021696:
    c.r[1] = ld32(0x060216C8u);  // 06021696 mov.l 0x060216C8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0602169Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602169Cu) return; }  // 06021698 jsr @r1 ; nop
    c.r[1] = ld32(0x060216C4u);  // 0602169C mov.l 0x060216C4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602169E mov.b @r1,r1
    c.r[0] = c.r[1];  // 060216A0 mov r1,r0
    c.r[0] >>= 2;  // 060216A2 shlr2 r0
    c.r[0] &= 0x1u;  // 060216A4 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060216A6 tst r0,r0
    if (c.t) { goto L_060216B0; }  // 060216A8 bt 0x060216B0
    c.r[1] = ld32(0x060216CCu);  // 060216AA mov.l 0x060216CC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060216B0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060216B0u) return; }  // 060216AC jsr @r1 ; nop
L_060216B0:
    c.r[15] = c.r[14];  // 060216B0 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060216B2 lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x060216BCu);  // 060216B4 mov.w 0x060216BC,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060216B6 rts ; mov.l @r15+,r14
}

void f_060216D0(SH2Context& c) {
    ran[429] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060216D0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060216D2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060216D4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060216D6 sts.l pr,@-r15
    c.r[4] = c.r[4] & 0xFFFFu;  // 060216D8 extu.w r4,r4
    c.r[1] = ld32(0x06021718u);  // 060216DA mov.l 0x06021718,r1
    c.t = c.r[4] > c.r[1];  // 060216DC cmp/hi r1,r4
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06021708; } }  // 060216DE bt/s 0x06021708 ; mov r15,r14
    c.r[1] = ld32(0x0602171Cu);  // 060216E2 mov.l 0x0602171C,r1
    c.r[8] = (uint32_t)(int16_t)ld16(0x06021714u);  // 060216E4 mov.w 0x06021714,r8
    c.r[9] = ld32(c.r[1]);  // 060216E6 mov.l @r1,r9
    c.r[0] = 0x7u;  // 060216E8 mov #7,r0
    c.r[1] = c.r[4];  // 060216EA mov r4,r1
    c.r[1] >>= 2;  // 060216EC shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060216EE shlr r1
    c.r[9] += c.r[1];  // 060216F0 add r1,r9
    c.r[1] = ~c.r[4];  // 060216F2 not r4,r1
    c.r[1] &= c.r[0];  // 060216F4 and r0,r1
    c.r[5] = c.r[1];  // 060216F6 mov r1,r5
    c.r[0] = ld32(0x06021720u);  // 060216F8 mov.l 0x06021720,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060216FEu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060216FEu) return; }  // 060216FA jsr @r0 ; mov #1,r4
    c.r[2] = c.r[0];  // 060216FE mov r0,r2
    c.r[0] = c.r[9];  // 06021700 mov r9,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 06021702 mov.b @(r0,r8),r1
    c.r[2] |= c.r[1];  // 06021704 or r1,r2
    st8(c.r[0] + c.r[8], c.r[2]);  // 06021706 mov.b r2,@(r0,r8)
L_06021708:
    c.r[15] = c.r[14];  // 06021708 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602170A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0602170C mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0602170E mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06021710 rts ; mov.l @r15+,r8
}

void f_06021724(SH2Context& c) {
    ran[430] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06021724 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06021726 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06021728 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602172A sts.l pr,@-r15
    c.r[4] = c.r[4] & 0xFFFFu;  // 0602172C extu.w r4,r4
    c.r[1] = ld32(0x0602176Cu);  // 0602172E mov.l 0x0602176C,r1
    c.t = c.r[4] > c.r[1];  // 06021730 cmp/hi r1,r4
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0602175E; } }  // 06021732 bt/s 0x0602175E ; mov r15,r14
    c.r[1] = ld32(0x06021770u);  // 06021736 mov.l 0x06021770,r1
    c.r[8] = (uint32_t)(int16_t)ld16(0x0602176Au);  // 06021738 mov.w 0x0602176A,r8
    c.r[9] = ld32(c.r[1]);  // 0602173A mov.l @r1,r9
    c.r[0] = 0x7u;  // 0602173C mov #7,r0
    c.r[1] = c.r[4];  // 0602173E mov r4,r1
    c.r[1] >>= 2;  // 06021740 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06021742 shlr r1
    c.r[9] += c.r[1];  // 06021744 add r1,r9
    c.r[1] = ~c.r[4];  // 06021746 not r4,r1
    c.r[1] &= c.r[0];  // 06021748 and r0,r1
    c.r[5] = c.r[1];  // 0602174A mov r1,r5
    c.r[0] = ld32(0x06021774u);  // 0602174C mov.l 0x06021774,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06021752u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06021752u) return; }  // 0602174E jsr @r0 ; mov #1,r4
    c.r[1] = c.r[0];  // 06021752 mov r0,r1
    c.r[2] = ~c.r[1];  // 06021754 not r1,r2
    c.r[0] = c.r[9];  // 06021756 mov r9,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 06021758 mov.b @(r0,r8),r1
    c.r[2] &= c.r[1];  // 0602175A and r1,r2
    st8(c.r[0] + c.r[8], c.r[2]);  // 0602175C mov.b r2,@(r0,r8)
L_0602175E:
    c.r[15] = c.r[14];  // 0602175E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06021760 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06021762 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06021764 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06021766 rts ; mov.l @r15+,r8
}

void f_06021778(SH2Context& c) {
    ran[431] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06021778 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0602177A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0602177C sts.l pr,@-r15
    c.r[4] = c.r[4] & 0xFFFFu;  // 0602177E extu.w r4,r4
    c.r[1] = ld32(0x060217BCu);  // 06021780 mov.l 0x060217BC,r1
    c.t = c.r[4] > c.r[1];  // 06021782 cmp/hi r1,r4
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0602178C; } }  // 06021784 bf/s 0x0602178C ; mov r15,r14
    c.r[0] = 0x0u; goto L_060217AE;  // 06021788 bra 0x060217AE ; mov #0,r0
L_0602178C:
    c.r[1] = ld32(0x060217C0u);  // 0602178C mov.l 0x060217C0,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060217B8u);  // 0602178E mov.w 0x060217B8,r0
    c.r[2] = ld32(c.r[1]);  // 06021790 mov.l @r1,r2
    c.r[3] = 0x7u;  // 06021792 mov #7,r3
    c.r[1] = c.r[4];  // 06021794 mov r4,r1
    c.r[1] >>= 2;  // 06021796 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06021798 shlr r1
    c.r[2] += c.r[1];  // 0602179A add r1,r2
    c.r[1] = ~c.r[4];  // 0602179C not r4,r1
    c.r[1] &= c.r[3];  // 0602179E and r3,r1
    c.r[5] = c.r[1];  // 060217A0 mov r1,r5
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 060217A2 mov.b @(r0,r2),r8
    c.r[4] = 0x1u;  // 060217A4 mov #1,r4
    c.r[0] = ld32(0x060217C4u);  // 060217A6 mov.l 0x060217C4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060217ACu; c.r[8] = c.r[8] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060217ACu) return; }  // 060217A8 jsr @r0 ; extu.b r8,r8
    c.r[0] &= c.r[8];  // 060217AC and r8,r0
L_060217AE:
    c.r[15] = c.r[14];  // 060217AE mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060217B0 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060217B2 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060217B4 rts ; mov.l @r15+,r8
}

void f_060217C8(SH2Context& c) {
    ran[432] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060217C8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060217CA mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060217CC sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060217CE mov r15,r14
    c.r[8] = c.r[5];  // 060217D0 mov r5,r8
    c.r[4] = c.r[4] & 0xFFu;  // 060217D2 extu.b r4,r4
    c.r[1] = ld32(0x060218A0u);  // 060217D4 mov.l 0x060218A0,r1
    c.r[4] <<= 2;  // 060217D6 shll2 r4
    c.r[4] <<= 2;  // 060217D8 shll2 r4
    c.r[2] = c.r[4];  // 060217DA mov r4,r2
    c.r[1] = ld32(c.r[1]);  // 060217DC mov.l @r1,r1
    c.r[0] = c.r[4];  // 060217DE mov r4,r0
    c.r[2] += c.r[1];  // 060217E0 add r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060217E2 mov.b @(r0,r1),r1
    c.r[2] += 1;  // 060217E4 add #1,r2
    c.r[6] = c.r[1] & 0xFFu;  // 060217E6 extu.b r1,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060217E8 mov.b @r2,r1
    c.r[5] = c.r[6];  // 060217EA mov r6,r5
    c.r[7] = c.r[1] & 0xFFu;  // 060217EC extu.b r1,r7
    c.r[2] = ld32(0x060218A4u);  // 060217EE mov.l 0x060218A4,r2
    c.r[1] = c.r[2];  // 060217F0 mov r2,r1
    c.r[1] += 76;  // 060217F2 add #76,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060217F4 mov.b @r1,r1
    c.r[3] = c.r[1] & 0xFFu;  // 060217F6 extu.b r1,r3
    c.r[1] = c.r[3];  // 060217F8 mov r3,r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060217FA shlr r1
    c.t = c.r[6] >= c.r[1];  // 060217FC cmp/hs r1,r6
    { const bool k = c.t; c.r[4] = c.r[7]; if (k) { goto L_06021824; } }  // 060217FE bt/s 0x06021824 ; mov r7,r4
    c.r[2] += 77;  // 06021802 add #77,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06021804 mov.b @r2,r1
    c.r[2] = c.r[1] & 0xFFu;  // 06021806 extu.b r1,r2
    c.r[1] = c.r[2];  // 06021808 mov r2,r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0602180A shlr r1
    c.t = c.r[7] >= c.r[1];  // 0602180C cmp/hs r1,r7
    { const bool k = c.t; c.r[2] -= c.r[7]; if (k) { goto L_0602181E; } }  // 0602180E bt/s 0x0602181E ; sub r7,r2
    c.t = c.r[6] >= c.r[7];  // 06021812 cmp/hs r7,r6
    c.r[1] = 0x4u;  // 06021814 mov #4,r1
L_06021816:
    if (c.t) { goto L_06021846; }  // 06021816 bt 0x06021846
    c.r[1] = 0x1u;  // 06021818 mov #1,r1
    c.r[2] = c.r[1]; goto L_06021848;  // 0602181A bra 0x06021848 ; mov r1,r2
L_0602181E:
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[2];  // 0602181E cmp/ge r2,r6
    c.r[1] = 0x7u; SH2_POLL(c); goto L_06021816;  // 06021820 bra 0x06021816 ; mov #7,r1
L_06021824:
    c.r[2] += 77;  // 06021824 add #77,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06021826 mov.b @r2,r1
    c.r[2] = c.r[1] & 0xFFu;  // 06021828 extu.b r1,r2
    c.r[1] = c.r[2];  // 0602182A mov r2,r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0602182C shlr r1
    c.t = c.r[7] >= c.r[1];  // 0602182E cmp/hs r1,r7
    { const bool k = c.t; c.r[2] -= c.r[4]; if (k) { goto L_0602183C; } }  // 06021830 bt/s 0x0602183C ; sub r4,r2
    c.r[3] -= c.r[6];  // 06021834 sub r6,r3
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[7];  // 06021836 cmp/ge r7,r3
    c.r[1] = 0x4u; goto L_06021842;  // 06021838 bra 0x06021842 ; mov #4,r1
L_0602183C:
    c.r[3] -= c.r[5];  // 0602183C sub r5,r3
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[2];  // 0602183E cmp/ge r2,r3
    c.r[1] = 0x7u;  // 06021840 mov #7,r1
L_06021842:
    if (c.t) { goto L_06021846; }  // 06021842 bt 0x06021846
    c.r[1] = 0xDu;  // 06021844 mov #13,r1
L_06021846:
    c.r[2] = c.r[1];  // 06021846 mov r1,r2
L_06021848:
    c.r[1] = 0x8u;  // 06021848 mov #8,r1
    c.r[1] &= c.r[2];  // 0602184A and r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0602184C tst r1,r1
    { const bool k = c.t; c.r[4] = 0x0u; if (k) { goto L_06021858; } }  // 0602184E bt/s 0x06021858 ; mov #0,r4
    c.r[1] = ld32(0x060218A8u);  // 06021852 mov.l 0x060218A8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06021854 mov.b @r1,r1
    c.r[4] = c.r[1] & 0xFFu;  // 06021856 extu.b r1,r4
L_06021858:
    c.r[1] = 0x4u;  // 06021858 mov #4,r1
    c.r[1] &= c.r[2];  // 0602185A and r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0602185C tst r1,r1
    { const bool k = c.t; c.r[6] = 0x0u; if (k) { goto L_06021868; } }  // 0602185E bt/s 0x06021868 ; mov #0,r6
    c.r[1] = ld32(0x060218A8u);  // 06021862 mov.l 0x060218A8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06021864 mov.b @r1,r1
    c.r[6] = c.r[1] & 0xFFu;  // 06021866 extu.b r1,r6
L_06021868:
    c.r[1] = 0x2u;  // 06021868 mov #2,r1
    c.r[1] &= c.r[2];  // 0602186A and r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0602186C tst r1,r1
    { const bool k = c.t; c.r[5] = 0x0u; if (k) { goto L_06021878; } }  // 0602186E bt/s 0x06021878 ; mov #0,r5
    c.r[1] = ld32(0x060218ACu);  // 06021872 mov.l 0x060218AC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06021874 mov.b @r1,r1
    c.r[5] = c.r[1] & 0xFFu;  // 06021876 extu.b r1,r5
L_06021878:
    c.r[1] = ld32(0x060218ACu);  // 06021878 mov.l 0x060218AC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602187A mov.b @r1,r1
    c.r[0] = c.r[2];  // 0602187C mov r2,r0
    c.r[0] &= 0x1u;  // 0602187E and #1,r0
    c.macl = (c.r[1] & 0xFFFFu) * (c.r[0] & 0xFFFFu);  // 06021880 mulu.w r0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06021882 mov.l r8,@-r15
    c.r[7] = c.macl;  // 06021884 sts macl,r7
    c.r[0] = ld32(0x060218B0u);  // 06021886 mov.l 0x060218B0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0602188Cu; c.r[7] = c.r[7] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0602188Cu) return; }  // 06021888 jsr @r0 ; extu.b r7,r7
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0602188C cmp/eq #-1,r0
    { const bool k = c.t; c.r[0] = 0x1u; if (k) { goto L_06021894; } }  // 0602188E bt/s 0x06021894 ; mov #1,r0
    c.r[0] = 0x0u;  // 06021892 mov #0,r0
L_06021894:
    c.r[15] = c.r[14];  // 06021894 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06021896 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06021898 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602189A rts ; mov.l @r15+,r8
}

void f_060218B4(SH2Context& c) {
    ran[433] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060218B4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060218B6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060218B8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060218BA mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060218BC mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060218BE mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060218C0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060218C2 sts.l pr,@-r15
    c.r[15] -= 4;  // 060218C4 add #-4,r15
    c.r[14] = c.r[15];  // 060218C6 mov r15,r14
    c.r[4] = c.r[4] & 0xFFu;  // 060218C8 extu.b r4,r4
    c.r[8] = c.r[4];  // 060218CA mov r4,r8
    c.r[5] = c.r[5] & 0xFFu;  // 060218CC extu.b r5,r5
    c.r[3] = c.r[5];  // 060218CE mov r5,r3
    c.r[6] = c.r[6] & 0xFFu;  // 060218D0 extu.b r6,r6
    c.r[2] = c.r[6];  // 060218D2 mov r6,r2
    c.r[7] = c.r[7] & 0xFFu;  // 060218D4 extu.b r7,r7
    c.r[0] = 0x0u;  // 060218D6 mov #0,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x060219F8u);  // 060218D8 mov.w 0x060219F8,r1
    c.t = c.r[7] == c.r[1];  // 060218DA cmp/eq r1,r7
    { const bool k = !c.t; st32(c.r[14], c.r[0]); if (k) { goto L_060218EE; } }  // 060218DC bf/s 0x060218EE ; mov.l r0,@r14
    c.r[1] = 0x1u;  // 060218E0 mov #1,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060218E2 mov.l r1,@-r15
    c.r[0] = ld32(0x060219FCu);  // 060218E4 mov.l 0x060219FC,r0
    c.r[7] = c.r[6];  // 060218E6 mov r6,r7
    c.r[6] = c.r[5];  // 060218E8 mov r5,r6
    c.r[5] = c.r[4]; goto L_060218F8;  // 060218EA bra 0x060218F8 ; mov r4,r5
L_060218EE:
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 060218EE mov.l r7,@-r15
    c.r[0] = ld32(0x06021A00u);  // 060218F0 mov.l 0x06021A00,r0
    c.r[7] = c.r[2];  // 060218F2 mov r2,r7
    c.r[6] = c.r[3];  // 060218F4 mov r3,r6
    c.r[5] = c.r[8];  // 060218F6 mov r8,r5
L_060218F8:
    c.r[4] = ld32(0x06021A04u);  // 060218F8 mov.l 0x06021A04,r4
    { const uint32_t x = c.r[0]; c.pr = 0x060218FEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060218FEu) return; }  // 060218FA jsr @r0 ; nop
    c.r[13] = c.r[0] & 0xFFu;  // 060218FE extu.b r0,r13
    c.t = (c.r[13] & c.r[13]) == 0;  // 06021900 tst r13,r13
    { const bool k = c.t; c.r[15] += 4; if (k) { goto L_060219E0; } }  // 06021902 bt/s 0x060219E0 ; add #4,r15
    c.r[12] = ld32(0x06021A08u);  // 06021906 mov.l 0x06021A08,r12
    c.r[10] = 0x0u;  // 06021908 mov #0,r10
    c.t = (int32_t)c.r[10] >= (int32_t)c.r[13];  // 0602190A cmp/ge r13,r10
    if (c.t) { goto L_0602195E; }  // 0602190C bt 0x0602195E
    c.r[9] = 0x0u;  // 0602190E mov #0,r9
    c.r[11] = ld32(0x06021A04u);  // 06021910 mov.l 0x06021A04,r11
L_06021912:
    c.r[8] = c.r[11];  // 06021912 mov r11,r8
    c.r[8] += 1;  // 06021914 add #1,r8
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06021916 mov.b @r8,r5
    c.r[0] = ld32(0x06021A04u);  // 06021918 mov.l 0x06021A04,r0
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 0602191A mov.b @(r0,r9),r4
    c.r[5] = c.r[5] & 0xFFu;  // 0602191C extu.b r5,r5
    c.r[0] = ld32(0x06021A0Cu);  // 0602191E mov.l 0x06021A0C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06021924u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06021924u) return; }  // 06021920 jsr @r0 ; extu.b r4,r4
    c.r[1] = c.r[0];  // 06021924 mov r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06021926 tst r1,r1
    if (!c.t) { goto L_06021954; }  // 06021928 bf 0x06021954
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0602192A mov.b @r8,r1
    c.r[0] = ld32(0x06021A04u);  // 0602192C mov.l 0x06021A04,r0
    c.r[2] = c.r[1] & 0xFFu;  // 0602192E extu.b r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 06021930 mov.b @(r0,r9),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06021932 extu.b r1,r1
    c.r[1] += c.r[1];  // 06021934 add r1,r1
    c.r[2] <<= 2;  // 06021936 shll2 r2
    c.r[2] <<= 2;  // 06021938 shll2 r2
    c.r[2] += c.r[2];  // 0602193A add r2,r2
    c.r[2] <<= 2;  // 0602193C shll2 r2
    c.r[0] = ld32(0x06021A10u);  // 0602193E mov.l 0x06021A10,r0
    c.r[2] += c.r[0];  // 06021940 add r0,r2
    c.r[0] = c.r[1];  // 06021942 mov r1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 06021944 mov.w @(r0,r2),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06021946 extu.w r1,r1
    c.t = c.r[12] > c.r[1];  // 06021948 cmp/hi r1,r12
    { const bool k = !c.t; c.t = (c.r[1] & c.r[1]) == 0; if (k) { goto L_06021954; } }  // 0602194A bf/s 0x06021954 ; tst r1,r1
    if (c.t) { goto L_06021954; }  // 0602194E bt 0x06021954
    c.r[12] = c.r[1];  // 06021950 mov r1,r12
    st32(c.r[14], c.r[10]);  // 06021952 mov.l r10,@r14
L_06021954:
    c.r[11] += 2;  // 06021954 add #2,r11
    c.r[10] += 1;  // 06021956 add #1,r10
    c.t = (int32_t)c.r[10] >= (int32_t)c.r[13];  // 06021958 cmp/ge r13,r10
    { const bool k = !c.t; c.r[9] += 2; if (k) { SH2_POLL(c); goto L_06021912; } }  // 0602195A bf/s 0x06021912 ; add #2,r9
L_0602195E:
    c.r[7] = ld32(0x06021A14u);  // 0602195E mov.l 0x06021A14,r7
    c.r[1] = 0xFFFFFFFFu;  // 06021960 mov #-1,r1
    st32(c.r[7] + 16, c.r[1]);  // 06021962 mov.l r1,@(16,r7)
    st32(c.r[7] + 12, c.r[1]);  // 06021964 mov.l r1,@(12,r7)
    c.r[1] = ld32(0x06021A18u);  // 06021966 mov.l 0x06021A18,r1
    c.t = c.r[12] > c.r[1];  // 06021968 cmp/hi r1,r12
    { const bool k = c.t; c.r[0] = 0xFFFFFFFFu; if (k) { goto L_060219E2; } }  // 0602196A bt/s 0x060219E2 ; mov #-1,r0
    c.r[2] = ld32(0x06021A1Cu);  // 0602196E mov.l 0x06021A1C,r2
    c.r[8] = ld32(0x06021A20u);  // 06021970 mov.l 0x06021A20,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06021972 mov.b @r8,r1
    c.r[4] = ld32(0x06021A24u);  // 06021974 mov.l 0x06021A24,r4
    c.r[5] = ld32(c.r[4]);  // 06021976 mov.l @r4,r5
    c.r[6] = c.r[1] & 0xFFu;  // 06021978 extu.b r1,r6
    c.r[6] <<= 2;  // 0602197A shll2 r6
    c.r[6] <<= 2;  // 0602197C shll2 r6
    c.r[3] = c.r[6];  // 0602197E mov r6,r3
    c.r[3] += c.r[5];  // 06021980 add r5,r3
    c.r[0] = c.r[6];  // 06021982 mov r6,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 06021984 mov.b @(r0,r5),r1
    c.r[3] += 1;  // 06021986 add #1,r3
    st8(c.r[2], c.r[1]);  // 06021988 mov.b r1,@r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0602198A mov.b @r3,r1
    c.r[2] = ld32(0x06021A28u);  // 0602198C mov.l 0x06021A28,r2
    st8(c.r[2], c.r[1]);  // 0602198E mov.b r1,@r2
    c.r[0] = ld32(c.r[14] + 36);  // 06021990 mov.l @(36,r14),r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06021992 tst r0,r0
    { const bool k = !c.t; c.r[2] = ld32(c.r[14]); if (k) { goto L_060219B0; } }  // 06021994 bf/s 0x060219B0 ; mov.l @r14,r2
    c.r[2] += c.r[2];  // 06021998 add r2,r2
    c.r[1] = ld32(0x06021A04u);  // 0602199A mov.l 0x06021A04,r1
    c.r[1] += c.r[2];  // 0602199C add r2,r1
    c.r[0] = ld32(0x06021A04u);  // 0602199E mov.l 0x06021A04,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 060219A0 mov.b @(r0,r2),r2
    c.r[1] += 1;  // 060219A2 add #1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 060219A4 extu.b r2,r2
    st32(c.r[7] + 12, c.r[2]);  // 060219A6 mov.l r2,@(12,r7)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060219A8 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060219AA extu.b r1,r1
    st32(c.r[7] + 16, c.r[1]); goto L_060219DC;  // 060219AC bra 0x060219DC ; mov.l r1,@(16,r7)
L_060219B0:
    c.r[3] = ld32(0x06021A2Cu);  // 060219B0 mov.l 0x06021A2C,r3
    c.r[7] = ld32(0x06021A04u);  // 060219B2 mov.l 0x06021A04,r7
    c.r[1] = ld32(c.r[14]);  // 060219B4 mov.l @r14,r1
    c.r[0] = ld32(0x06021A04u);  // 060219B6 mov.l 0x06021A04,r0
    c.r[1] += c.r[1];  // 060219B8 add r1,r1
    c.r[7] += c.r[1];  // 060219BA add r1,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060219BC mov.b @(r0,r1),r1
    c.r[7] += 1;  // 060219BE add #1,r7
    c.r[0] = c.r[6];  // 060219C0 mov r6,r0
    st8(c.r[0] + c.r[5], c.r[1]);  // 060219C2 mov.b r1,@(r0,r5)
    st8(c.r[3], c.r[1]);  // 060219C4 mov.b r1,@r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[8]);  // 060219C6 mov.b @r8,r2
    c.r[3] += 1;  // 060219C8 add #1,r3
    c.r[1] = ld32(c.r[4]);  // 060219CA mov.l @r4,r1
    c.r[2] = c.r[2] & 0xFFu;  // 060219CC extu.b r2,r2
    c.r[2] <<= 2;  // 060219CE shll2 r2
    c.r[2] <<= 2;  // 060219D0 shll2 r2
    c.r[2] += c.r[1];  // 060219D2 add r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 060219D4 mov.b @r7,r1
    c.r[2] += 1;  // 060219D6 add #1,r2
    st8(c.r[2], c.r[1]);  // 060219D8 mov.b r1,@r2
    st8(c.r[3], c.r[1]);  // 060219DA mov.b r1,@r3
L_060219DC:
    c.r[0] = 0x0u; goto L_060219E2;  // 060219DC bra 0x060219E2 ; mov #0,r0
L_060219E0:
    c.r[0] = 0xFFFFFFFFu;  // 060219E0 mov #-1,r0
L_060219E2:
    c.r[14] += 4;  // 060219E2 add #4,r14
    c.r[15] = c.r[14];  // 060219E4 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060219E6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060219E8 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060219EA mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060219EC mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060219EE mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060219F0 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060219F2 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060219F4 rts ; mov.l @r15+,r8
}

void f_06021A30(SH2Context& c) {
    ran[434] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06021A30 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06021A32 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06021A34 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06021A36 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06021A38 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06021A3A mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06021A3C mov r15,r14
    c.r[8] = c.r[4];  // 06021A3E mov r4,r8
    c.r[1] = ld32(c.r[14] + 24);  // 06021A40 mov.l @(24,r14),r1
    c.r[11] = c.r[5] & 0xFFu;  // 06021A42 extu.b r5,r11
    c.r[9] = c.r[6] & 0xFFu;  // 06021A44 extu.b r6,r9
    c.r[2] = c.r[7] & 0xFFu;  // 06021A46 extu.b r7,r2
    c.r[7] = 0x0u;  // 06021A48 mov #0,r7
    c.t = c.r[11] > c.r[2];  // 06021A4A cmp/hi r2,r11
    { const bool k = c.t; c.r[1] = c.r[1] & 0xFFu; if (k) { goto L_06021A56; } }  // 06021A4C bt/s 0x06021A56 ; extu.b r1,r1
    c.t = c.r[9] > c.r[1];  // 06021A50 cmp/hi r1,r9
    { const bool k = !c.t; c.r[2] -= c.r[11]; if (k) { goto L_06021A5A; } }  // 06021A52 bf/s 0x06021A5A ; sub r11,r2
L_06021A56:
    c.r[0] = 0x0u; goto L_06021AA2;  // 06021A56 bra 0x06021AA2 ; mov #0,r0
L_06021A5A:
    c.r[2] += 1;  // 06021A5A add #1,r2
    c.r[10] = c.r[2] & 0xFFu;  // 06021A5C extu.b r2,r10
    c.r[1] -= c.r[9];  // 06021A5E sub r9,r1
    c.r[1] += 1;  // 06021A60 add #1,r1
    c.r[4] = c.r[1] & 0xFFu;  // 06021A62 extu.b r1,r4
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[10];  // 06021A64 cmp/ge r10,r7
    { const bool k = c.t; c.r[6] = 0x0u; if (k) { goto L_06021AA0; } }  // 06021A66 bt/s 0x06021AA0 ; mov #0,r6
    c.r[12] = 0x49u;  // 06021A6A mov #73,r12
    c.r[3] = 0x0u;  // 06021A6C mov #0,r3
L_06021A6E:
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[4];  // 06021A6E cmp/ge r4,r3
    if (c.t) { goto L_06021A98; }  // 06021A70 bt 0x06021A98
    c.r[5] = c.r[11];  // 06021A72 mov r11,r5
    c.r[5] += c.r[6];  // 06021A74 add r6,r5
L_06021A76:
    c.r[0] = c.r[7];  // 06021A76 mov r7,r0
    c.r[0] += c.r[0];  // 06021A78 add r0,r0
    c.r[2] = c.r[0];  // 06021A7A mov r0,r2
    c.r[2] += c.r[8];  // 06021A7C add r8,r2
    st8(c.r[0] + c.r[8], c.r[5]);  // 06021A7E mov.b r5,@(r0,r8)
    c.r[2] += 1;  // 06021A80 add #1,r2
    c.r[1] = c.r[9];  // 06021A82 mov r9,r1
    c.r[1] += c.r[3];  // 06021A84 add r3,r1
    c.t = c.r[7] > c.r[12];  // 06021A86 cmp/hi r12,r7
    { const bool k = c.t; st8(c.r[2], c.r[1]); if (k) { goto L_06021A98; } }  // 06021A88 bt/s 0x06021A98 ; mov.b r1,@r2
    c.r[1] = c.r[7];  // 06021A8C mov r7,r1
    c.r[1] += 1;  // 06021A8E add #1,r1
    c.r[3] += 1;  // 06021A90 add #1,r3
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[4];  // 06021A92 cmp/ge r4,r3
    { const bool k = !c.t; c.r[7] = c.r[1] & 0xFFu; if (k) { SH2_POLL(c); goto L_06021A76; } }  // 06021A94 bf/s 0x06021A76 ; extu.b r1,r7
L_06021A98:
    c.r[6] += 1;  // 06021A98 add #1,r6
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[10];  // 06021A9A cmp/ge r10,r6
    { const bool k = !c.t; c.r[3] = 0x0u; if (k) { SH2_POLL(c); goto L_06021A6E; } }  // 06021A9C bf/s 0x06021A6E ; mov #0,r3
L_06021AA0:
    c.r[0] = c.r[7];  // 06021AA0 mov r7,r0
L_06021AA2:
    c.r[15] = c.r[14];  // 06021AA2 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06021AA4 mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06021AA6 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06021AA8 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06021AAA mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06021AAC mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06021AAE rts ; mov.l @r15+,r8
}

void f_06021AB4(SH2Context& c) {
    ran[435] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06021AB4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06021AB6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06021AB8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06021ABA mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06021ABC mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06021ABE mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06021AC0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06021AC2 sts.l pr,@-r15
    c.r[15] -= 20;  // 06021AC4 add #-20,r15
    c.r[14] = c.r[15];  // 06021AC6 mov r15,r14
    st32(c.r[14] + 4, c.r[4]);  // 06021AC8 mov.l r4,@(4,r14)
    c.r[5] = c.r[5] & 0xFFu;  // 06021ACA extu.b r5,r5
    st32(c.r[14] + 8, c.r[5]);  // 06021ACC mov.l r5,@(8,r14)
    c.r[6] = c.r[6] & 0xFFu;  // 06021ACE extu.b r6,r6
    st32(c.r[14] + 12, c.r[6]);  // 06021AD0 mov.l r6,@(12,r14)
    c.r[7] = c.r[7] & 0xFFu;  // 06021AD2 extu.b r7,r7
    st32(c.r[14] + 16, c.r[7]);  // 06021AD4 mov.l r7,@(16,r14)
    c.r[0] = 0xBu;  // 06021AD6 mov #11,r0
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 06021AD8 mov.b @(r0,r14),r0
    c.r[3] = 0xFu;  // 06021ADA mov #15,r3
    st8(c.r[4], c.r[0]);  // 06021ADC mov.b r0,@r4
    c.r[1] = ld32(c.r[14] + 4);  // 06021ADE mov.l @(4,r14),r1
    c.r[3] += c.r[14];  // 06021AE0 add r14,r3
    c.r[1] += 1;  // 06021AE2 add #1,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06021AE4 mov.b @r3,r3
    c.r[8] = 0x1u;  // 06021AE6 mov #1,r8
    st8(c.r[1], c.r[3]);  // 06021AE8 mov.b r3,@r1
    c.r[0] = ld32(c.r[14] + 16);  // 06021AEA mov.l @(16,r14),r0
    c.r[12] = c.r[8];  // 06021AEC mov r8,r12
    c.t = (int32_t)c.r[12] > (int32_t)c.r[0];  // 06021AEE cmp/gt r0,r12
    { const bool k = c.t; c.r[13] = c.r[14]; if (k) { goto L_06021B8E; } }  // 06021AF0 bt/s 0x06021B8E ; mov r14,r13
    c.r[13] += 2;  // 06021AF4 add #2,r13
    c.r[1] = c.r[14];  // 06021AF6 mov r14,r1
L_06021AF8:
    c.r[1] += 3;  // 06021AF8 add #3,r1
    c.r[2] = 0x1u;  // 06021AFA mov #1,r2
    st8(c.r[1], c.r[2]);  // 06021AFC mov.b r2,@r1
    c.r[1] = c.r[14];  // 06021AFE mov r14,r1
    c.r[1] += 1;  // 06021B00 add #1,r1
    st8(c.r[1], c.r[2]);  // 06021B02 mov.b r2,@r1
    c.r[1] = 0x0u;  // 06021B04 mov #0,r1
    st8(c.r[14], c.r[1]);  // 06021B06 mov.b r1,@r14
    c.r[1] = 0u - c.r[8];  // 06021B08 neg r8,r1
    st8(c.r[13], c.r[1]);  // 06021B0A mov.b r1,@r13
    c.r[10] = 0x0u;  // 06021B0C mov #0,r10
    c.r[1] = c.r[8];  // 06021B0E mov r8,r1
    c.r[1] <<= 2;  // 06021B10 shll2 r1
    c.t = (int32_t)c.r[10] >= (int32_t)c.r[1];  // 06021B12 cmp/ge r1,r10
    { const bool k = c.t; c.r[1] = c.r[8]; if (k) { goto L_06021B82; } }  // 06021B14 bt/s 0x06021B82 ; mov r8,r1
    c.r[0] = c.r[12];  // 06021B18 mov r12,r0
    c.r[0] += c.r[0];  // 06021B1A add r0,r0
    c.r[11] = ld32(c.r[14] + 4);  // 06021B1C mov.l @(4,r14),r11
    c.r[9] = c.r[0];  // 06021B1E mov r0,r9
    c.r[11] += c.r[0];  // 06021B20 add r0,r11
    c.r[6] = c.r[8];  // 06021B22 mov r8,r6
L_06021B24:
    c.r[5] = c.r[14];  // 06021B24 mov r14,r5
    c.r[5] += 1;  // 06021B26 add #1,r5
    c.r[3] = ld32(0x06021BA8u);  // 06021B28 mov.l 0x06021BA8,r3
    { const uint32_t x = c.r[3]; c.pr = 0x06021B2Eu; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06021B2Eu) return; }  // 06021B2A jsr @r3 ; mov r14,r4
    c.r[6] = c.r[8];  // 06021B2E mov r8,r6
    c.r[5] = c.r[14];  // 06021B30 mov r14,r5
    c.r[5] += 3;  // 06021B32 add #3,r5
    c.r[0] = ld32(0x06021BA8u);  // 06021B34 mov.l 0x06021BA8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06021B3Au; c.r[4] = c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06021B3Au) return; }  // 06021B36 jsr @r0 ; mov r13,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[14]);  // 06021B3A mov.b @r14,r1
    c.r[3] = ld32(c.r[14] + 8);  // 06021B3C mov.l @(8,r14),r3
    c.r[1] += c.r[3];  // 06021B3E add r3,r1
    c.t = (int32_t)c.r[1] >= 0;  // 06021B40 cmp/pz r1
    if (!c.t) { goto L_06021B74; }  // 06021B42 bf 0x06021B74
    c.r[0] = ld32(c.r[14] + 4);  // 06021B44 mov.l @(4,r14),r0
    st8(c.r[0] + c.r[9], c.r[1]);  // 06021B46 mov.b r1,@(r0,r9)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 06021B48 mov.b @r13,r1
    c.r[5] = ld32(c.r[14] + 12);  // 06021B4A mov.l @(12,r14),r5
    c.r[5] += c.r[1];  // 06021B4C add r1,r5
    c.t = (int32_t)c.r[5] >= 0;  // 06021B4E cmp/pz r5
    { const bool k = !c.t; c.r[1] = c.r[11]; if (k) { goto L_06021B74; } }  // 06021B50 bf/s 0x06021B74 ; mov r11,r1
    c.r[1] += 1;  // 06021B54 add #1,r1
    st8(c.r[1], c.r[5]);  // 06021B56 mov.b r5,@r1
    c.r[5] = c.r[5] & 0xFFu;  // 06021B58 extu.b r5,r5
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 06021B5A mov.b @(r0,r9),r4
    c.r[3] = ld32(0x06021BACu);  // 06021B5C mov.l 0x06021BAC,r3
    { const uint32_t x = c.r[3]; c.pr = 0x06021B62u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06021B62u) return; }  // 06021B5E jsr @r3 ; extu.b r4,r4
    c.r[1] = c.r[0];  // 06021B62 mov r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06021B64 tst r1,r1
    { const bool k = c.t; c.r[0] = ld32(c.r[14] + 52); if (k) { goto L_06021B6E; } }  // 06021B66 bt/s 0x06021B6E ; mov.l @(52,r14),r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06021B6A tst r0,r0
    if (!c.t) { goto L_06021B74; }  // 06021B6C bf 0x06021B74
L_06021B6E:
    c.r[11] += 2;  // 06021B6E add #2,r11
    c.r[9] += 2;  // 06021B70 add #2,r9
    c.r[12] += 1;  // 06021B72 add #1,r12
L_06021B74:
    c.r[10] += 1;  // 06021B74 add #1,r10
    c.r[1] = c.r[8];  // 06021B76 mov r8,r1
    c.r[1] <<= 2;  // 06021B78 shll2 r1
    c.t = (int32_t)c.r[10] >= (int32_t)c.r[1];  // 06021B7A cmp/ge r1,r10
    { const bool k = !c.t; c.r[6] = c.r[8]; if (k) { SH2_POLL(c); goto L_06021B24; } }  // 06021B7C bf/s 0x06021B24 ; mov r8,r6
    c.r[1] = c.r[8];  // 06021B80 mov r8,r1
L_06021B82:
    c.r[1] += 1;  // 06021B82 add #1,r1
    c.r[3] = ld32(c.r[14] + 16);  // 06021B84 mov.l @(16,r14),r3
    c.r[8] = (uint32_t)(int32_t)(int8_t)c.r[1];  // 06021B86 exts.b r1,r8
    c.t = (int32_t)c.r[8] > (int32_t)c.r[3];  // 06021B88 cmp/gt r3,r8
    { const bool k = !c.t; c.r[1] = c.r[14]; if (k) { SH2_POLL(c); goto L_06021AF8; } }  // 06021B8A bf/s 0x06021AF8 ; mov r14,r1
L_06021B8E:
    c.r[14] += 20;  // 06021B8E add #20,r14
    c.r[15] = c.r[14];  // 06021B90 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06021B92 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06021B94 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06021B96 mov.l @r15+,r13
    c.r[0] = c.r[12] & 0xFFu;  // 06021B98 extu.b r12,r0
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06021B9A mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06021B9C mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06021B9E mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06021BA0 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06021BA2 rts ; mov.l @r15+,r8
}

void f_06021BB0(SH2Context& c) {
    ran[436] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06021BB0 mov.l r14,@-r15
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[5]);  // 06021BB2 mov.b @r5,r2
    c.r[1] = (uint32_t)(int32_t)(int8_t)c.r[2];  // 06021BB4 exts.b r2,r1
    c.t = (int32_t)c.r[1] > 0;  // 06021BB6 cmp/pl r1
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_06021BC8; } }  // 06021BB8 bf/s 0x06021BC8 ; mov r15,r14
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]);  // 06021BBC mov.b @r4,r1
    c.t = c.r[1] == c.r[6];  // 06021BBE cmp/eq r6,r1
    if (!c.t) { goto L_06021BDE; }  // 06021BC0 bf 0x06021BDE
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[5]);  // 06021BC2 mov.b @r5,r1
    c.r[1] = 0u - c.r[1]; goto L_06021BDA;  // 06021BC4 bra 0x06021BDA ; neg r1,r1
L_06021BC8:
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[4]);  // 06021BC8 mov.b @r4,r3
    c.r[1] = 0u - c.r[6];  // 06021BCA neg r6,r1
    c.t = c.r[3] == c.r[1];  // 06021BCC cmp/eq r1,r3
    { const bool k = c.t; c.r[3] += c.r[2]; if (k) { goto L_06021BD6; } }  // 06021BCE bt/s 0x06021BD6 ; add r2,r3
    st8(c.r[4], c.r[3]); goto L_06021BE2;  // 06021BD2 bra 0x06021BE2 ; mov.b r3,@r4
L_06021BD6:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[5]);  // 06021BD6 mov.b @r5,r1
    c.r[1] = 0u - c.r[1];  // 06021BD8 neg r1,r1
L_06021BDA:
    st8(c.r[5], c.r[1]);  // 06021BDA mov.b r1,@r5
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[4]);  // 06021BDC mov.b @r4,r2
L_06021BDE:
    c.r[1] += c.r[2];  // 06021BDE add r2,r1
    st8(c.r[4], c.r[1]);  // 06021BE0 mov.b r1,@r4
L_06021BE2:
    c.r[15] = c.r[14];  // 06021BE2 mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06021BE4 rts ; mov.l @r15+,r14
}

void f_06021BE8(SH2Context& c) {
    ran[437] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06021BE8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06021BEA mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06021BEC mov r15,r14
    c.r[4] = c.r[4] & 0xFFu;  // 06021BEE extu.b r4,r4
    c.r[5] = c.r[5] & 0xFFu;  // 06021BF0 extu.b r5,r5
    c.r[3] = 0x0u;  // 06021BF2 mov #0,r3
    c.r[1] = ld32(0x06021C38u);  // 06021BF4 mov.l 0x06021C38,r1
    c.r[7] = ld32(c.r[1]);  // 06021BF6 mov.l @r1,r7
    c.r[6] = ld32(0x06021C3Cu);  // 06021BF8 mov.l 0x06021C3C,r6
    c.r[2] = 0x0u;  // 06021BFA mov #0,r2
    c.r[8] = c.r[7];  // 06021BFC mov r7,r8
L_06021BFE:
    c.r[0] = c.r[2];  // 06021BFE mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06021C00 mov.b @(r0,r7),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06021C02 extu.b r1,r1
    c.t = c.r[1] == c.r[4];  // 06021C04 cmp/eq r4,r1
    { const bool k = !c.t; c.r[1] = c.r[8]; if (k) { goto L_06021C22; } }  // 06021C06 bf/s 0x06021C22 ; mov r8,r1
    c.r[1] += 1;  // 06021C0A add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06021C0C mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06021C0E extu.b r1,r1
    c.t = c.r[1] == c.r[5];  // 06021C10 cmp/eq r5,r1
    if (!c.t) { goto L_06021C22; }  // 06021C12 bf 0x06021C22
    c.r[1] = ld32(c.r[8] + 4);  // 06021C14 mov.l @(4,r8),r1
    c.r[1] &= c.r[6];  // 06021C16 and r6,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06021C18 tst r1,r1
    { const bool k = !c.t; c.r[8] += 16; if (k) { goto L_06021C24; } }  // 06021C1A bf/s 0x06021C24 ; add #16,r8
    c.r[0] = 0x1u; goto L_06021C30;  // 06021C1E bra 0x06021C30 ; mov #1,r0
L_06021C22:
    c.r[8] += 16;  // 06021C22 add #16,r8
L_06021C24:
    c.r[3] += 1;  // 06021C24 add #1,r3
    c.r[1] = 0x49u;  // 06021C26 mov #73,r1
    c.t = (int32_t)c.r[3] > (int32_t)c.r[1];  // 06021C28 cmp/gt r1,r3
    { const bool k = !c.t; c.r[2] += 16; if (k) { SH2_POLL(c); goto L_06021BFE; } }  // 06021C2A bf/s 0x06021BFE ; add #16,r2
    c.r[0] = 0x0u;  // 06021C2E mov #0,r0
L_06021C30:
    c.r[15] = c.r[14];  // 06021C30 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06021C32 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06021C34 rts ; mov.l @r15+,r8
}

void f_06021C40(SH2Context& c) {
    ran[438] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06021C40 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06021C42 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06021C44 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06021C46 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06021C48 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06021C4A mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06021C4C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06021C4E sts.l pr,@-r15
    c.r[15] -= 92;  // 06021C50 add #-92,r15
    c.r[14] = c.r[15];  // 06021C52 mov r15,r14
    c.r[8] = c.r[4];  // 06021C54 mov r4,r8
    c.r[8] = (uint32_t)(int32_t)(int16_t)c.r[8];  // 06021C56 exts.w r8,r8
    c.r[13] = ld32(0x06021DF4u);  // 06021C58 mov.l 0x06021DF4,r13
    c.r[2] = ld32(0x06021DF8u);  // 06021C5A mov.l 0x06021DF8,r2
    c.r[1] = c.r[2];  // 06021C5C mov r2,r1
    c.r[1] += 33;  // 06021C5E add #33,r1
    c.r[0] = 0x50u;  // 06021C60 mov #80,r0
    c.r[0] += c.r[14];  // 06021C62 add r14,r0
    c.r[9] = c.r[2];  // 06021C64 mov r2,r9
    c.r[9] += 36;  // 06021C66 add #36,r9
    c.r[7] = 0x0u;  // 06021C68 mov #0,r7
    c.r[6] = c.r[8];  // 06021C6A mov r8,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06021C6C mov.b @r1,r1
    c.r[5] = c.r[14];  // 06021C6E mov r14,r5
    c.r[1] = c.r[1] & 0xFFu;  // 06021C70 extu.b r1,r1
    st32(c.r[0], c.r[1]);  // 06021C72 mov.l r1,@r0
    c.r[1] = 0xFFFFFFFFu;  // 06021C74 mov #-1,r1
    st8(c.r[9], c.r[1]);  // 06021C76 mov.b r1,@r9
    c.r[1] = 0xFFFFFFFFu;  // 06021C78 mov #-1,r1
    st32(c.r[2] + 16, c.r[1]);  // 06021C7A mov.l r1,@(16,r2)
    st32(c.r[2] + 12, c.r[1]);  // 06021C7C mov.l r1,@(12,r2)
    c.r[1] = ld32(0x06021DFCu);  // 06021C7E mov.l 0x06021DFC,r1
    c.r[12] = ld32(0x06021E00u);  // 06021C80 mov.l 0x06021E00,r12
    { const uint32_t x = c.r[12]; c.pr = 0x06021C86u; c.r[4] = ld32(c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06021C86u) return; }  // 06021C82 jsr @r12 ; mov.l @r1,r4
    c.t = (int32_t)c.r[8] >= 0;  // 06021C86 cmp/pz r8
    { const bool k = !c.t; c.r[11] = c.r[0]; if (k) { goto L_06021C94; } }  // 06021C88 bf/s 0x06021C94 ; mov r0,r11
    c.t = c.r[0] == 0x1u;  // 06021C8C cmp/eq #1,r0
    { const bool k = !c.t; c.r[1] = (uint32_t)(int8_t)ld8(c.r[14]); if (k) { goto L_06021C94; } }  // 06021C8E bf/s 0x06021C94 ; mov.b @r14,r1
    st8(c.r[9], c.r[1]);  // 06021C92 mov.b r1,@r9
L_06021C94:
    c.t = (c.r[11] & c.r[11]) == 0;  // 06021C94 tst r11,r11
    { const bool k = !c.t; c.r[7] = 0x0u; if (k) { goto L_06021CA8; } }  // 06021C96 bf/s 0x06021CA8 ; mov #0,r7
    c.r[1] = ld32(0x06021DFCu);  // 06021C9A mov.l 0x06021DFC,r1
    c.r[4] = ld32(c.r[1]);  // 06021C9C mov.l @r1,r4
    c.r[0] = ld32(0x06021E00u);  // 06021C9E mov.l 0x06021E00,r0
    c.r[6] = 0xFFFFFFF9u;  // 06021CA0 mov #-7,r6
    { const uint32_t x = c.r[0]; c.pr = 0x06021CA6u; c.r[5] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06021CA6u) return; }  // 06021CA2 jsr @r0 ; mov r14,r5
    c.r[11] = c.r[0];  // 06021CA6 mov r0,r11
L_06021CA8:
    c.r[1] = ld32(0x06021DFCu);  // 06021CA8 mov.l 0x06021DFC,r1
    c.r[0] = 0x50u;  // 06021CAA mov #80,r0
    c.r[6] = ld32(c.r[1]);  // 06021CAC mov.l @r1,r6
    c.r[1] = ld32(c.r[0] + c.r[14]);  // 06021CAE mov.l @(r0,r14),r1
    c.r[1] <<= 2;  // 06021CB0 shll2 r1
    c.r[1] <<= 2;  // 06021CB2 shll2 r1
    c.r[1] += c.r[6];  // 06021CB4 add r6,r1
    c.r[1] += 9;  // 06021CB6 add #9,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06021CB8 mov.b @r1,r1
    c.r[5] = (uint32_t)(int16_t)ld16(0x06021DF0u);  // 06021CBA mov.w 0x06021DF0,r5
    c.r[3] = c.r[1] & 0xFFu;  // 06021CBC extu.b r1,r3
    c.t = c.r[3] == c.r[5];  // 06021CBE cmp/eq r5,r3
    if (c.t) { goto L_06021D22; }  // 06021CC0 bt 0x06021D22
    c.r[2] = c.r[3];  // 06021CC2 mov r3,r2
    c.r[2] <<= 2;  // 06021CC4 shll2 r2
    c.r[2] <<= 2;  // 06021CC6 shll2 r2
    c.r[2] += c.r[6];  // 06021CC8 add r6,r2
    c.r[1] = c.r[2];  // 06021CCA mov r2,r1
    c.r[1] += 4;  // 06021CCC add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06021CCE mov.b @r1,r1
    c.r[0] = c.r[1];  // 06021CD0 mov r1,r0
    c.r[0] >>= 2;  // 06021CD2 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06021CD4 shlr r0
    c.r[0] >>= 2;  // 06021CD6 shlr2 r0
    c.r[0] &= 0x1u;  // 06021CD8 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06021CDA tst r0,r0
    { const bool k = c.t; c.r[7] = c.r[3]; if (k) { goto L_06021CE8; } }  // 06021CDC bt/s 0x06021CE8 ; mov r3,r7
    c.r[2] += 6;  // 06021CE0 add #6,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06021CE2 mov.b @r2,r1
    c.r[3] = c.r[1] & 0xFFu;  // 06021CE4 extu.b r1,r3
    c.r[7] = c.r[3];  // 06021CE6 mov r3,r7
L_06021CE8:
    c.r[7] <<= 2;  // 06021CE8 shll2 r7
    c.r[7] <<= 2;  // 06021CEA shll2 r7
    c.r[1] = c.r[7];  // 06021CEC mov r7,r1
    c.r[1] += c.r[6];  // 06021CEE add r6,r1
    c.r[2] = ld32(c.r[1] + 4);  // 06021CF0 mov.l @(4,r1),r2
    c.r[1] = ld32(0x06021E04u);  // 06021CF2 mov.l 0x06021E04,r1
    c.r[2] &= c.r[1];  // 06021CF4 and r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06021CF6 tst r2,r2
    { const bool k = !c.t; c.r[0] = c.r[7]; if (k) { goto L_06021D06; } }  // 06021CF8 bf/s 0x06021D06 ; mov r7,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 06021CFC mov.b @(r0,r6),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06021CFE extu.b r1,r1
    c.t = c.r[1] == c.r[5];  // 06021D00 cmp/eq r5,r1
    { const bool k = !c.t; c.r[9] = 0x0u; if (k) { goto L_06021D0A; } }  // 06021D02 bf/s 0x06021D0A ; mov #0,r9
L_06021D06:
    c.r[3] = c.r[5];  // 06021D06 mov r5,r3
    c.r[9] = 0x0u;  // 06021D08 mov #0,r9
L_06021D0A:
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[11];  // 06021D0A cmp/ge r11,r9
    { const bool k = c.t; c.r[0] = c.r[14]; if (k) { goto L_06021D22; } }  // 06021D0C bt/s 0x06021D22 ; mov r14,r0
L_06021D10:
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 06021D10 mov.b @(r0,r9),r2
    c.r[1] = c.r[2] & 0xFFu;  // 06021D12 extu.b r2,r1
    c.t = c.r[3] == c.r[1];  // 06021D14 cmp/eq r1,r3
    { const bool k = !c.t; c.r[9] += 1; if (k) { goto L_06021D1E; } }  // 06021D16 bf/s 0x06021D1E ; add #1,r9
    goto L_06021F3C;  // 06021D1A bra 0x06021F3C ; nop
L_06021D1E:
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[11];  // 06021D1E cmp/ge r11,r9
    if (!c.t) { SH2_POLL(c); goto L_06021D10; }  // 06021D20 bf 0x06021D10
L_06021D22:
    c.r[10] = ld32(0x06021E08u);  // 06021D22 mov.l 0x06021E08,r10
    c.r[9] = 0x0u;  // 06021D24 mov #0,r9
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[11];  // 06021D26 cmp/ge r11,r9
    { const bool k = !c.t; c.r[0] = 0x0u; if (k) { goto L_06021D30; } }  // 06021D28 bf/s 0x06021D30 ; mov #0,r0
    goto L_06021E32;  // 06021D2C bra 0x06021E32 ; nop
L_06021D30:
    c.r[0] = c.r[14];  // 06021D30 mov r14,r0
L_06021D32:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 06021D32 mov.b @(r0,r9),r1
    c.r[8] = c.r[1] & 0xFFu;  // 06021D34 extu.b r1,r8
    c.r[1] = ld32(0x06021E0Cu);  // 06021D36 mov.l 0x06021E0C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06021D3Cu; c.r[4] = c.r[8] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06021D3Cu) return; }  // 06021D38 jsr @r1 ; extu.b r8,r4
    c.r[1] = ld32(0x06021DFCu);  // 06021D3C mov.l 0x06021DFC,r1
    c.r[2] = c.r[8];  // 06021D3E mov r8,r2
    c.r[2] <<= 2;  // 06021D40 shll2 r2
    c.r[2] <<= 2;  // 06021D42 shll2 r2
    c.r[3] = ld32(c.r[1]);  // 06021D44 mov.l @r1,r3
    c.r[6] = c.r[2];  // 06021D46 mov r2,r6
    c.r[6] += c.r[3];  // 06021D48 add r3,r6
    c.r[1] = c.r[6];  // 06021D4A mov r6,r1
    c.r[1] += 11;  // 06021D4C add #11,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06021D4E mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06021D50 extu.b r1,r1
    c.r[1] >>= 2;  // 06021D52 shlr2 r1
    c.r[1] >>= 2;  // 06021D54 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06021D56 shlr r1
    c.r[1] >>= 2;  // 06021D58 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06021D5A tst r1,r1
    { const bool k = !c.t; c.r[12] = 0x50u; if (k) { goto L_06021E24; } }  // 06021D5C bf/s 0x06021E24 ; mov #80,r12
    c.r[12] += c.r[14];  // 06021D60 add r14,r12
    c.r[12] = ld32(c.r[12]);  // 06021D62 mov.l @r12,r12
    c.t = c.r[8] == c.r[12];  // 06021D64 cmp/eq r12,r8
    { const bool k = c.t; c.r[1] = c.r[6]; if (k) { goto L_06021E24; } }  // 06021D66 bt/s 0x06021E24 ; mov r6,r1
    c.r[1] += 3;  // 06021D6A add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06021D6C mov.b @r1,r1
    c.r[0] = c.r[1];  // 06021D6E mov r1,r0
    c.r[0] >>= 2;  // 06021D70 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06021D72 shlr r0
    c.r[0] &= 0x3u;  // 06021D74 and #3,r0
    c.t = c.r[0] == 0x2u;  // 06021D76 cmp/eq #2,r0
    if (c.t) { goto L_06021E24; }  // 06021D78 bt 0x06021E24
    c.r[6] += 1;  // 06021D7A add #1,r6
    c.r[0] = c.r[2];  // 06021D7C mov r2,r0
    c.r[7] = 0x1u;  // 06021D7E mov #1,r7
    c.r[4] = c.r[13];  // 06021D80 mov r13,r4
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[6]);  // 06021D82 mov.b @r6,r6
    c.r[12] = ld32(0x06021E10u);  // 06021D84 mov.l 0x06021E10,r12
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06021D86 mov.b @(r0,r3),r5
    c.r[6] = c.r[6] & 0xFFu;  // 06021D88 extu.b r6,r6
    c.r[5] = c.r[5] & 0xFFu;  // 06021D8A extu.b r5,r5
    { const uint32_t x = c.r[12]; c.pr = 0x06021D90u; c.r[15] -= 4; st32(c.r[15], c.r[7]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06021D90u) return; }  // 06021D8C jsr @r12 ; mov.l r7,@-r15
    c.r[1] = c.r[0];  // 06021D90 mov r0,r1
    c.r[4] = c.r[1] & 0xFFu;  // 06021D92 extu.b r1,r4
    c.r[3] = 0x0u;  // 06021D94 mov #0,r3
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[4];  // 06021D96 cmp/ge r4,r3
    { const bool k = c.t; c.r[15] += 4; if (k) { goto L_06021E24; } }  // 06021D98 bt/s 0x06021E24 ; add #4,r15
    c.r[8] = ld32(0x06021E14u);  // 06021D9C mov.l 0x06021E14,r8
    c.r[5] = c.r[13];  // 06021D9E mov r13,r5
    c.r[6] = 0x0u;  // 06021DA0 mov #0,r6
    c.r[0] = c.r[6];  // 06021DA2 mov r6,r0
L_06021DA4:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[13]);  // 06021DA4 mov.b @(r0,r13),r1
    c.r[7] = c.r[1] & 0xFFu;  // 06021DA6 extu.b r1,r7
    c.r[1] = c.r[5];  // 06021DA8 mov r5,r1
    c.r[1] += 1;  // 06021DAA add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06021DAC mov.b @r1,r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x06021DF2u);  // 06021DAE mov.w 0x06021DF2,r12
    c.r[2] = c.r[1] & 0xFFu;  // 06021DB0 extu.b r1,r2
    c.macl = c.r[2] * c.r[12];  // 06021DB2 mul.l r12,r2
    c.r[0] = 0x54u;  // 06021DB4 mov #84,r0
    c.r[0] += c.r[14];  // 06021DB6 add r14,r0
    c.r[12] = c.macl;  // 06021DB8 sts macl,r12
    st32(c.r[0], c.r[12]);  // 06021DBA mov.l r12,@r0
    c.r[0] = 0x54u;  // 06021DBC mov #84,r0
    c.r[12] = ld32(c.r[0] + c.r[14]);  // 06021DBE mov.l @(r0,r14),r12
    c.r[1] = c.r[7];  // 06021DC0 mov r7,r1
    c.r[0] = ld32(0x06021E18u);  // 06021DC2 mov.l 0x06021E18,r0
    c.r[12] += c.r[0];  // 06021DC4 add r0,r12
    c.r[0] = 0x54u;  // 06021DC6 mov #84,r0
    st32(c.r[0] + c.r[14], c.r[12]);  // 06021DC8 mov.l r12,@(r0,r14)
    c.r[12] = 0x54u;  // 06021DCA mov #84,r12
    c.r[12] += c.r[14];  // 06021DCC add r14,r12
    c.r[0] = ld32(c.r[12]);  // 06021DCE mov.l @r12,r0
    c.r[1] += c.r[1];  // 06021DD0 add r1,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06021DD2 mov.w @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06021DD4 extu.w r1,r1
    c.t = c.r[10] > c.r[1];  // 06021DD6 cmp/hi r1,r10
    { const bool k = !c.t; c.t = (c.r[1] & c.r[1]) == 0; if (k) { goto L_06021DE6; } }  // 06021DD8 bf/s 0x06021DE6 ; tst r1,r1
    if (c.t) { goto L_06021DE6; }  // 06021DDC bt 0x06021DE6
    c.r[10] = c.r[1];  // 06021DDE mov r1,r10
    c.r[0] = ld32(0x06021E1Cu);  // 06021DE0 mov.l 0x06021E1C,r0
    st8(c.r[0], c.r[7]);  // 06021DE2 mov.b r7,@r0
    st8(c.r[8], c.r[2]);  // 06021DE4 mov.b r2,@r8
L_06021DE6:
    c.r[5] += 2;  // 06021DE6 add #2,r5
    c.r[6] += 2;  // 06021DE8 add #2,r6
    c.r[3] += 1;  // 06021DEA add #1,r3
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[4]; goto L_06021E20;  // 06021DEC bra 0x06021E20 ; cmp/ge r4,r3
L_06021E20:
    { const bool k = !c.t; c.r[0] = c.r[6]; if (k) { SH2_POLL(c); goto L_06021DA4; } }  // 06021E20 bf/s 0x06021DA4 ; mov r6,r0
L_06021E24:
    c.r[9] += 1;  // 06021E24 add #1,r9
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[11];  // 06021E26 cmp/ge r11,r9
    { const bool k = c.t; c.r[0] = c.r[14]; if (k) { goto L_06021E30; } }  // 06021E28 bt/s 0x06021E30 ; mov r14,r0
    SH2_POLL(c); goto L_06021D32;  // 06021E2C bra 0x06021D32 ; nop
L_06021E30:
    c.r[0] = 0x0u;  // 06021E30 mov #0,r0
L_06021E32:
    c.r[12] = 0x4Cu;  // 06021E32 mov #76,r12
    c.r[12] += c.r[14];  // 06021E34 add r14,r12
    c.r[1] = ld32(0x06021F9Cu);  // 06021E36 mov.l 0x06021F9C,r1
    c.t = c.r[10] == c.r[1];  // 06021E38 cmp/eq r1,r10
    { const bool k = !c.t; st32(c.r[12], c.r[0]); if (k) { goto L_06021F30; } }  // 06021E3A bf/s 0x06021F30 ; mov.l r0,@r12
    c.r[0] = 0x1u;  // 06021E3E mov #1,r0
    c.r[12] = 0x4Cu;  // 06021E40 mov #76,r12
    c.r[12] += c.r[14];  // 06021E42 add r14,r12
    c.r[9] = 0x0u;  // 06021E44 mov #0,r9
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[11];  // 06021E46 cmp/ge r11,r9
    { const bool k = c.t; st32(c.r[12], c.r[0]); if (k) { goto L_06021F30; } }  // 06021E48 bt/s 0x06021F30 ; mov.l r0,@r12
    c.r[12] = 0x4Cu;  // 06021E4C mov #76,r12
    c.r[12] += c.r[14];  // 06021E4E add r14,r12
    c.r[0] = ld32(c.r[12]);  // 06021E50 mov.l @r12,r0
    c.r[12] = 0x58u;  // 06021E52 mov #88,r12
    c.r[12] += c.r[14];  // 06021E54 add r14,r12
    st32(c.r[12], c.r[0]);  // 06021E56 mov.l r0,@r12
    c.r[0] = c.r[14];  // 06021E58 mov r14,r0
L_06021E5A:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 06021E5A mov.b @(r0,r9),r1
    c.r[8] = c.r[1] & 0xFFu;  // 06021E5C extu.b r1,r8
    c.r[1] = ld32(0x06021FA0u);  // 06021E5E mov.l 0x06021FA0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06021E64u; c.r[4] = c.r[8] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06021E64u) return; }  // 06021E60 jsr @r1 ; extu.b r8,r4
    c.r[1] = ld32(0x06021FA4u);  // 06021E64 mov.l 0x06021FA4,r1
    c.r[2] = c.r[8];  // 06021E66 mov r8,r2
    c.r[2] <<= 2;  // 06021E68 shll2 r2
    c.r[2] <<= 2;  // 06021E6A shll2 r2
    c.r[3] = ld32(c.r[1]);  // 06021E6C mov.l @r1,r3
    c.r[6] = c.r[2];  // 06021E6E mov r2,r6
    c.r[6] += c.r[3];  // 06021E70 add r3,r6
    c.r[1] = c.r[6];  // 06021E72 mov r6,r1
    c.r[1] += 11;  // 06021E74 add #11,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06021E76 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06021E78 extu.b r1,r1
    c.r[1] >>= 2;  // 06021E7A shlr2 r1
    c.r[1] >>= 2;  // 06021E7C shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06021E7E shlr r1
    c.r[1] >>= 2;  // 06021E80 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06021E82 tst r1,r1
    { const bool k = !c.t; c.r[12] = 0x50u; if (k) { goto L_06021F28; } }  // 06021E84 bf/s 0x06021F28 ; mov #80,r12
    c.r[12] += c.r[14];  // 06021E88 add r14,r12
    c.r[12] = ld32(c.r[12]);  // 06021E8A mov.l @r12,r12
    c.t = c.r[8] == c.r[12];  // 06021E8C cmp/eq r12,r8
    { const bool k = c.t; c.r[1] = c.r[6]; if (k) { goto L_06021F28; } }  // 06021E8E bt/s 0x06021F28 ; mov r6,r1
    c.r[1] += 3;  // 06021E92 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06021E94 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06021E96 mov r1,r0
    c.r[0] >>= 2;  // 06021E98 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06021E9A shlr r0
    c.r[0] &= 0x3u;  // 06021E9C and #3,r0
    c.t = c.r[0] == 0x2u;  // 06021E9E cmp/eq #2,r0
    if (c.t) { goto L_06021F28; }  // 06021EA0 bt 0x06021F28
    c.r[6] += 1;  // 06021EA2 add #1,r6
    c.r[0] = c.r[2];  // 06021EA4 mov r2,r0
    c.r[12] = 0x58u;  // 06021EA6 mov #88,r12
    c.r[12] += c.r[14];  // 06021EA8 add r14,r12
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[6]);  // 06021EAA mov.b @r6,r6
    c.r[7] = 0x7u;  // 06021EAC mov #7,r7
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06021EAE mov.b @(r0,r3),r5
    c.r[4] = c.r[13];  // 06021EB0 mov r13,r4
    c.r[12] = ld32(c.r[12]);  // 06021EB2 mov.l @r12,r12
    c.r[6] = c.r[6] & 0xFFu;  // 06021EB4 extu.b r6,r6
    c.r[5] = c.r[5] & 0xFFu;  // 06021EB6 extu.b r5,r5
    c.r[0] = ld32(0x06021FA8u);  // 06021EB8 mov.l 0x06021FA8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06021EBEu; c.r[15] -= 4; st32(c.r[15], c.r[12]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06021EBEu) return; }  // 06021EBA jsr @r0 ; mov.l r12,@-r15
    c.r[1] = c.r[0];  // 06021EBE mov r0,r1
    c.r[4] = c.r[1] & 0xFFu;  // 06021EC0 extu.b r1,r4
    c.r[12] = 0x58u;  // 06021EC2 mov #88,r12
    c.r[12] += c.r[14];  // 06021EC4 add r14,r12
    c.r[3] = ld32(c.r[12]);  // 06021EC6 mov.l @r12,r3
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[4];  // 06021EC8 cmp/ge r4,r3
    { const bool k = c.t; c.r[15] += 4; if (k) { goto L_06021F28; } }  // 06021ECA bt/s 0x06021F28 ; add #4,r15
    c.r[8] = ld32(0x06021FACu);  // 06021ECE mov.l 0x06021FAC,r8
    c.r[0] = 0x2u;  // 06021ED0 mov #2,r0
    c.r[5] = c.r[13];  // 06021ED2 mov r13,r5
    c.r[5] += c.r[0];  // 06021ED4 add r0,r5
    c.r[6] = c.r[0];  // 06021ED6 mov r0,r6
L_06021ED8:
    c.r[7] = c.r[5];  // 06021ED8 mov r5,r7
    c.r[7] += 1;  // 06021EDA add #1,r7
    c.r[0] = c.r[6];  // 06021EDC mov r6,r0
    c.r[12] = 0x54u;  // 06021EDE mov #84,r12
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[13]);  // 06021EE0 mov.b @(r0,r13),r2
    c.r[12] += c.r[14];  // 06021EE2 add r14,r12
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06021EE4 mov.b @r7,r1
    c.r[0] = c.r[2] & 0xFFu;  // 06021EE6 extu.b r2,r0
    st32(c.r[12], c.r[0]);  // 06021EE8 mov.l r0,@r12
    c.r[12] = 0x54u;  // 06021EEA mov #84,r12
    c.r[12] += c.r[14];  // 06021EEC add r14,r12
    c.r[0] = ld32(c.r[12]);  // 06021EEE mov.l @r12,r0
    c.r[1] = c.r[1] & 0xFFu;  // 06021EF0 extu.b r1,r1
    c.r[0] += c.r[0];  // 06021EF2 add r0,r0
    st32(c.r[12], c.r[0]);  // 06021EF4 mov.l r0,@r12
    c.r[12] = (uint32_t)(int16_t)ld16(0x06021F98u);  // 06021EF6 mov.w 0x06021F98,r12
    c.macl = c.r[1] * c.r[12];  // 06021EF8 mul.l r12,r1
    c.r[0] = ld32(0x06021FB0u);  // 06021EFA mov.l 0x06021FB0,r0
    c.r[1] = c.macl;  // 06021EFC sts macl,r1
    c.r[1] += c.r[0];  // 06021EFE add r0,r1
    c.r[12] = 0x54u;  // 06021F00 mov #84,r12
    c.r[12] += c.r[14];  // 06021F02 add r14,r12
    c.r[0] = ld32(c.r[12]);  // 06021F04 mov.l @r12,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06021F06 mov.w @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06021F08 extu.w r1,r1
    c.t = c.r[10] > c.r[1];  // 06021F0A cmp/hi r1,r10
    { const bool k = !c.t; c.t = (c.r[1] & c.r[1]) == 0; if (k) { goto L_06021F1E; } }  // 06021F0C bf/s 0x06021F1E ; tst r1,r1
    if (c.t) { goto L_06021F1E; }  // 06021F10 bt 0x06021F1E
    c.r[10] = c.r[1];  // 06021F12 mov r1,r10
    c.r[0] = ld32(0x06021FB4u);  // 06021F14 mov.l 0x06021FB4,r0
    st8(c.r[0], c.r[2]);  // 06021F16 mov.b r2,@r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06021F18 mov.b @r7,r1
    st8(c.r[8], c.r[1]); goto L_06021F28;  // 06021F1A bra 0x06021F28 ; mov.b r1,@r8
L_06021F1E:
    c.r[5] += 2;  // 06021F1E add #2,r5
    c.r[3] += 1;  // 06021F20 add #1,r3
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[4];  // 06021F22 cmp/ge r4,r3
    { const bool k = !c.t; c.r[6] += 2; if (k) { SH2_POLL(c); goto L_06021ED8; } }  // 06021F24 bf/s 0x06021ED8 ; add #2,r6
L_06021F28:
    c.r[9] += 1;  // 06021F28 add #1,r9
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[11];  // 06021F2A cmp/ge r11,r9
    { const bool k = !c.t; c.r[0] = c.r[14]; if (k) { SH2_POLL(c); goto L_06021E5A; } }  // 06021F2C bf/s 0x06021E5A ; mov r14,r0
L_06021F30:
    c.r[1] = ld32(0x06021FB8u);  // 06021F30 mov.l 0x06021FB8,r1
    c.t = c.r[10] > c.r[1];  // 06021F32 cmp/hi r1,r10
    { const bool k = !c.t; c.r[0] = 0xFFFFFFFFu; if (k) { goto L_06021F42; } }  // 06021F34 bf/s 0x06021F42 ; mov #-1,r0
    c.r[14] += 92; goto L_06021F84;  // 06021F38 bra 0x06021F84 ; add #92,r14
L_06021F3C:
    st8(c.r[14], c.r[2]);  // 06021F3C mov.b r2,@r14
    c.r[11] = 0x1u; SH2_POLL(c); goto L_06021D22;  // 06021F3E bra 0x06021D22 ; mov #1,r11
L_06021F42:
    c.r[3] = ld32(0x06021FBCu);  // 06021F42 mov.l 0x06021FBC,r3
    c.r[4] = ld32(0x06021FC0u);  // 06021F44 mov.l 0x06021FC0,r4
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[4]);  // 06021F46 mov.b @r4,r2
    c.r[5] = ld32(0x06021FA4u);  // 06021F48 mov.l 0x06021FA4,r5
    c.r[7] = ld32(c.r[5]);  // 06021F4A mov.l @r5,r7
    c.r[2] = c.r[2] & 0xFFu;  // 06021F4C extu.b r2,r2
    c.r[2] <<= 2;  // 06021F4E shll2 r2
    c.r[2] <<= 2;  // 06021F50 shll2 r2
    c.r[6] = c.r[2];  // 06021F52 mov r2,r6
    c.r[6] += c.r[7];  // 06021F54 add r7,r6
    c.r[0] = c.r[2];  // 06021F56 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06021F58 mov.b @(r0,r7),r1
    c.r[6] += 1;  // 06021F5A add #1,r6
    st8(c.r[3], c.r[1]);  // 06021F5C mov.b r1,@r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 06021F5E mov.b @r6,r1
    c.r[3] = ld32(0x06021FC4u);  // 06021F60 mov.l 0x06021FC4,r3
    st8(c.r[3], c.r[1]);  // 06021F62 mov.b r1,@r3
    c.r[3] = ld32(0x06021FB4u);  // 06021F64 mov.l 0x06021FB4,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]); c.r[3] += 1;  // 06021F66 mov.b @r3+,r1
    c.r[12] = 0x4Cu;  // 06021F68 mov #76,r12
    st8(c.r[0] + c.r[7], c.r[1]);  // 06021F6A mov.b r1,@(r0,r7)
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[4]);  // 06021F6C mov.b @r4,r2
    c.r[12] += c.r[14];  // 06021F6E add r14,r12
    c.r[1] = ld32(c.r[5]);  // 06021F70 mov.l @r5,r1
    c.r[2] = c.r[2] & 0xFFu;  // 06021F72 extu.b r2,r2
    c.r[2] <<= 2;  // 06021F74 shll2 r2
    c.r[2] <<= 2;  // 06021F76 shll2 r2
    c.r[2] += c.r[1];  // 06021F78 add r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06021F7A mov.b @r3,r1
    c.r[2] += 1;  // 06021F7C add #1,r2
    st8(c.r[2], c.r[1]);  // 06021F7E mov.b r1,@r2
    c.r[0] = ld32(c.r[12]);  // 06021F80 mov.l @r12,r0
    c.r[14] += 92;  // 06021F82 add #92,r14
L_06021F84:
    c.r[15] = c.r[14];  // 06021F84 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06021F86 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06021F88 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06021F8A mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06021F8C mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06021F8E mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06021F90 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06021F92 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06021F94 rts ; mov.l @r15+,r8
}

void f_06021FC8(SH2Context& c) {
    ran[439] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06021FC8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06021FCA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06021FCC mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06021FCE mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06021FD0 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06021FD2 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06021FD4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06021FD6 sts.l pr,@-r15
    c.r[15] -= 20;  // 06021FD8 add #-20,r15
    c.r[14] = c.r[15];  // 06021FDA mov r15,r14
    c.r[4] = c.r[4] & 0xFFFFu;  // 06021FDC extu.w r4,r4
    st32(c.r[14] + 12, c.r[4]);  // 06021FDE mov.l r4,@(12,r14)
    c.r[1] = ld32(0x06022168u);  // 06021FE0 mov.l 0x06022168,r1
    c.r[2] = 0xFFFFFFFFu;  // 06021FE2 mov #-1,r2
    st32(c.r[1] + 16, c.r[2]);  // 06021FE4 mov.l r2,@(16,r1)
    st32(c.r[1] + 12, c.r[2]);  // 06021FE6 mov.l r2,@(12,r1)
    c.r[1] += 33;  // 06021FE8 add #33,r1
    c.r[10] = ld32(0x0602216Cu);  // 06021FEA mov.l 0x0602216C,r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06021FEC mov.b @r1,r1
    c.r[13] = ld32(0x06022170u);  // 06021FEE mov.l 0x06022170,r13
    c.r[3] = ld32(c.r[10]);  // 06021FF0 mov.l @r10,r3
    c.r[6] = c.r[1] & 0xFFu;  // 06021FF2 extu.b r1,r6
    c.r[9] = c.r[6];  // 06021FF4 mov r6,r9
    c.r[9] <<= 2;  // 06021FF6 shll2 r9
    c.r[9] <<= 2;  // 06021FF8 shll2 r9
    c.r[1] = ld32(0x06022174u);  // 06021FFA mov.l 0x06022174,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06021FFC mov.b @r1,r2
    c.r[0] = c.r[9];  // 06021FFE mov r9,r0
    st8(c.r[0] + c.r[3], c.r[2]);  // 06022000 mov.b r2,@(r0,r3)
    c.r[2] = c.r[2] & 0xFFu;  // 06022002 extu.b r2,r2
    c.r[1] = ld32(0x06022178u);  // 06022004 mov.l 0x06022178,r1
    c.r[2] += c.r[2];  // 06022006 add r2,r2
    c.r[3] = ld32(c.r[10]);  // 06022008 mov.l @r10,r3
    c.r[0] = c.r[2];  // 0602200A mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602200C mov.b @r1,r1
    c.r[3] += c.r[9];  // 0602200E add r9,r3
    c.r[3] += 1;  // 06022010 add #1,r3
    st8(c.r[3], c.r[1]);  // 06022012 mov.b r1,@r3
    c.r[1] = c.r[1] & 0xFFu;  // 06022014 extu.b r1,r1
    c.r[1] <<= 2;  // 06022016 shll2 r1
    c.r[1] <<= 2;  // 06022018 shll2 r1
    c.r[1] += c.r[1];  // 0602201A add r1,r1
    c.r[1] <<= 2;  // 0602201C shll2 r1
    c.r[1] += c.r[13];  // 0602201E add r13,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06022020 mov.w @(r0,r1),r1
    c.r[12] = ld32(0x0602217Cu);  // 06022022 mov.l 0x0602217C,r12
    c.r[13] = ld32(c.r[14] + 12);  // 06022024 mov.l @(12,r14),r13
    c.r[1] += 1;  // 06022026 add #1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06022028 extu.w r1,r1
    c.t = (c.r[13] & c.r[13]) == 0;  // 0602202A tst r13,r13
    { const bool k = !c.t; st32(c.r[14] + 4, c.r[1]); if (k) { goto L_06022034; } }  // 0602202C bf/s 0x06022034 ; mov.l r1,@(4,r14)
    c.r[0] = 0x1u;  // 06022030 mov #1,r0
    st32(c.r[14] + 12, c.r[0]);  // 06022032 mov.l r0,@(12,r14)
L_06022034:
    c.r[1] = ld32(c.r[10]);  // 06022034 mov.l @r10,r1
    c.r[1] += c.r[9];  // 06022036 add r9,r1
    c.r[1] += 2;  // 06022038 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602203A mov.b @r1,r1
    c.r[5] = c.r[1] & 0xFFu;  // 0602203C extu.b r1,r5
    c.r[1] = ld32(0x06022180u);  // 0602203E mov.l 0x06022180,r1
    c.r[2] = ld32(c.r[1]);  // 06022040 mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 06022042 mov #30,r1
    c.macl = c.r[5] * c.r[1];  // 06022044 mul.l r1,r5
    c.r[1] = c.macl;  // 06022046 sts macl,r1
    c.r[1] += c.r[2];  // 06022048 add r2,r1
    c.r[1] += 16;  // 0602204A add #16,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0602204C mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0602204E extu.b r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06022164u);  // 06022050 mov.w 0x06022164,r1
    c.t = c.r[2] == c.r[1];  // 06022052 cmp/eq r1,r2
    if (c.t) { goto L_06022058; }  // 06022054 bt 0x06022058
    c.r[5] = c.r[2];  // 06022056 mov r2,r5
L_06022058:
    c.r[6] = c.r[6] & 0xFFu;  // 06022058 extu.b r6,r6
    c.r[5] = c.r[5] & 0xFFu;  // 0602205A extu.b r5,r5
    c.r[8] = ld32(0x06022184u);  // 0602205C mov.l 0x06022184,r8
    c.r[1] = ld32(0x06022188u);  // 0602205E mov.l 0x06022188,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06022064u; c.r[4] = ld32(c.r[8]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06022064u) return; }  // 06022060 jsr @r1 ; mov.l @r8,r4
    c.r[2] = ld32(0x0602218Cu);  // 06022064 mov.l 0x0602218C,r2
    c.r[0] = c.r[9];  // 06022066 mov r9,r0
    c.r[4] = ld32(0x06022190u);  // 06022068 mov.l 0x06022190,r4
    c.r[3] = ld32(c.r[8]);  // 0602206A mov.l @r8,r3
    c.r[13] = ld32(0x06022194u);  // 0602206C mov.l 0x06022194,r13
    c.r[1] = c.r[3];  // 0602206E mov r3,r1
    c.r[1] += 36;  // 06022070 add #36,r1
    c.r[3] += 24;  // 06022072 add #24,r3
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06022074 mov.b @r1,r7
    c.r[8] = 0x0u;  // 06022076 mov #0,r8
    st8(c.r[2], c.r[7]);  // 06022078 mov.b r7,@r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0602207A mov.w @r3,r1
    c.r[2] = ld32(0x06022198u);  // 0602207C mov.l 0x06022198,r2
    st16(c.r[2], c.r[1]);  // 0602207E mov.w r1,@r2
    c.r[2] = ld32(0x0602219Cu);  // 06022080 mov.l 0x0602219C,r2
    c.r[1] = ld32(0x060221A0u);  // 06022082 mov.l 0x060221A0,r1
    st32(c.r[1], c.r[8]);  // 06022084 mov.l r8,@r1
    st32(c.r[2], c.r[8]);  // 06022086 mov.l r8,@r2
    c.r[2] = ld32(c.r[10]);  // 06022088 mov.l @r10,r2
    c.r[1] = c.r[9];  // 0602208A mov r9,r1
    c.r[1] += c.r[2];  // 0602208C add r2,r1
    c.r[1] += 1;  // 0602208E add #1,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06022090 mov.b @r1,r6
    c.r[7] = c.r[7] & 0xFFu;  // 06022092 extu.b r7,r7
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06022094 mov.b @(r0,r2),r5
    c.r[6] = c.r[6] & 0xFFu;  // 06022096 extu.b r6,r6
    c.r[5] = c.r[5] & 0xFFu;  // 06022098 extu.b r5,r5
    c.r[1] = 0x1u;  // 0602209A mov #1,r1
    { const uint32_t x = c.r[13]; c.pr = 0x060220A0u; c.r[15] -= 4; st32(c.r[15], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060220A0u) return; }  // 0602209C jsr @r13 ; mov.l r1,@-r15
    c.r[1] = c.r[0];  // 060220A0 mov r0,r1
    c.r[10] = c.r[1] & 0xFFu;  // 060220A2 extu.b r1,r10
    c.t = (c.r[10] & c.r[10]) == 0;  // 060220A4 tst r10,r10
    { const bool k = !c.t; c.r[0] = 0x0u; if (k) { goto L_060220AE; } }  // 060220A6 bf/s 0x060220AE ; mov #0,r0
    goto L_0602227A;  // 060220AA bra 0x0602227A ; nop
L_060220AE:
    c.r[1] = ld32(0x060221A4u);  // 060220AE mov.l 0x060221A4,r1
    st32(c.r[1], c.r[8]);  // 060220B0 mov.l r8,@r1
    st32(c.r[14] + 8, c.r[0]);  // 060220B2 mov.l r0,@(8,r14)
    c.r[13] = 0x0u;  // 060220B4 mov #0,r13
    c.t = (int32_t)c.r[13] >= (int32_t)c.r[10];  // 060220B6 cmp/ge r10,r13
    { const bool k = !c.t; st32(c.r[14], c.r[13]); if (k) { goto L_060220C0; } }  // 060220B8 bf/s 0x060220C0 ; mov.l r13,@r14
    goto L_06022268;  // 060220BC bra 0x06022268 ; nop
L_060220C0:
    c.r[11] = c.r[1];  // 060220C0 mov r1,r11
L_060220C2:
    c.r[12] = ld32(0x0602217Cu);  // 060220C2 mov.l 0x0602217C,r12
    c.r[5] = 0x0u;  // 060220C4 mov #0,r5
    c.t = (int32_t)c.r[5] >= (int32_t)c.r[10];  // 060220C6 cmp/ge r10,r5
    { const bool k = c.t; c.r[9] = 0x0u; if (k) { goto L_06022160; } }  // 060220C8 bt/s 0x06022160 ; mov #0,r9
    c.r[8] = ld32(0x06022190u);  // 060220CC mov.l 0x06022190,r8
    c.r[4] = 0x0u;  // 060220CE mov #0,r4
L_060220D0:
    c.r[0] = ld32(0x06022190u);  // 060220D0 mov.l 0x06022190,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[4]);  // 060220D2 mov.b @(r0,r4),r1
    c.r[7] = c.r[1] & 0xFFu;  // 060220D4 extu.b r1,r7
    c.r[1] = c.r[8];  // 060220D6 mov r8,r1
    c.r[1] += 1;  // 060220D8 add #1,r1
    c.r[2] = c.r[7];  // 060220DA mov r7,r2
    c.r[2] += c.r[2];  // 060220DC add r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060220DE mov.b @r1,r1
    c.r[0] = ld32(0x06022170u);  // 060220E0 mov.l 0x06022170,r0
    c.r[6] = c.r[1] & 0xFFu;  // 060220E2 extu.b r1,r6
    c.r[13] = c.r[6];  // 060220E4 mov r6,r13
    c.r[13] <<= 2;  // 060220E6 shll2 r13
    c.r[13] <<= 2;  // 060220E8 shll2 r13
    c.r[13] += c.r[13];  // 060220EA add r13,r13
    c.r[13] <<= 2;  // 060220EC shll2 r13
    c.r[13] += c.r[0];  // 060220EE add r0,r13
    c.r[0] = c.r[13];  // 060220F0 mov r13,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 060220F2 mov.w @(r0,r2),r1
    c.r[3] = c.r[1] & 0xFFFFu;  // 060220F4 extu.w r1,r3
    c.t = (c.r[3] & c.r[3]) == 0;  // 060220F6 tst r3,r3
    { const bool k = !c.t; st32(c.r[14] + 16, c.r[13]); if (k) { goto L_06022118; } }  // 060220F8 bf/s 0x06022118 ; mov.l r13,@(16,r14)
    c.r[13] = ld32(0x060221A8u);  // 060220FC mov.l 0x060221A8,r13
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 060220FE mov.b @r13,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06022100 extu.b r1,r1
    c.t = c.r[1] == c.r[7];  // 06022102 cmp/eq r7,r1
    if (!c.t) { goto L_06022110; }  // 06022104 bf 0x06022110
    c.r[0] = ld32(0x060221ACu);  // 06022106 mov.l 0x060221AC,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06022108 mov.b @r0,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0602210A extu.b r1,r1
    c.t = c.r[1] == c.r[6];  // 0602210C cmp/eq r6,r1
    if (c.t) { goto L_06022118; }  // 0602210E bt 0x06022118
L_06022110:
    c.r[3] = ld32(0x0602217Cu);  // 06022110 mov.l 0x0602217C,r3
    c.r[0] = ld32(c.r[14] + 16);  // 06022112 mov.l @(16,r14),r0
    c.r[13] = (uint32_t)(int16_t)ld16(0x06022166u);  // 06022114 mov.w 0x06022166,r13
    st16(c.r[0] + c.r[2], c.r[13]);  // 06022116 mov.w r13,@(r0,r2)
L_06022118:
    c.r[0] = ld32(0x0602217Cu);  // 06022118 mov.l 0x0602217C,r0
    c.t = c.r[3] == c.r[0];  // 0602211A cmp/eq r0,r3
    { const bool k = c.t; c.r[2] = ld32(c.r[14] + 4); if (k) { goto L_06022126; } }  // 0602211C bt/s 0x06022126 ; mov.l @(4,r14),r2
    c.r[1] = c.r[3];  // 06022120 mov r3,r1
    c.r[1] += 1;  // 06022122 add #1,r1
    c.r[3] = c.r[1] & 0xFFFFu;  // 06022124 extu.w r1,r3
L_06022126:
    c.r[1] = ld32(0x0602218Cu);  // 06022126 mov.l 0x0602218C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06022128 mov.b @r1,r1
    c.r[2] -= c.r[3];  // 0602212A sub r3,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0602212C extu.b r1,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0602212E cmp/gt r1,r2
    { const bool k = c.t; c.r[13] = ld32(c.r[14] + 4); if (k) { goto L_06022156; } }  // 06022130 bt/s 0x06022156 ; mov.l @(4,r14),r13
    c.t = c.r[13] > c.r[3];  // 06022134 cmp/hi r3,r13
    { const bool k = !c.t; c.t = c.r[3] > c.r[12]; if (k) { goto L_06022156; } }  // 06022136 bf/s 0x06022156 ; cmp/hi r12,r3
    if (c.t) { goto L_06022156; }  // 0602213A bt 0x06022156
    c.r[0] = ld32(0x0602217Cu);  // 0602213C mov.l 0x0602217C,r0
    c.t = c.r[3] == c.r[0];  // 0602213E cmp/eq r0,r3
    { const bool k = c.t; c.r[13] = ld32(c.r[14] + 12); if (k) { goto L_06022156; } }  // 06022140 bt/s 0x06022156 ; mov.l @(12,r14),r13
    c.t = c.r[3] == c.r[13];  // 06022144 cmp/eq r13,r3
    { const bool k = c.t; c.t = c.r[3] >= c.r[12]; if (k) { goto L_06022156; } }  // 06022146 bt/s 0x06022156 ; cmp/hs r12,r3
    { const bool k = c.t; c.r[0] = ld32(c.r[14] + 8); if (k) { goto L_06022156; } }  // 0602214A bt/s 0x06022156 ; mov.l @(8,r14),r0
    c.t = (int32_t)c.r[3] > (int32_t)c.r[0];  // 0602214E cmp/gt r0,r3
    if (!c.t) { goto L_06022156; }  // 06022150 bf 0x06022156
    c.r[12] = c.r[3];  // 06022152 mov r3,r12
    c.r[9] = 0x1u;  // 06022154 mov #1,r9
L_06022156:
    c.r[8] += 2;  // 06022156 add #2,r8
    c.r[5] += 1;  // 06022158 add #1,r5
    c.t = (int32_t)c.r[5] >= (int32_t)c.r[10];  // 0602215A cmp/ge r10,r5
    { const bool k = !c.t; c.r[4] += 2; if (k) { SH2_POLL(c); goto L_060220D0; } }  // 0602215C bf/s 0x060220D0 ; add #2,r4
L_06022160:
    c.t = (c.r[9] & c.r[9]) == 0; goto L_060221B0;  // 06022160 bra 0x060221B0 ; tst r9,r9
L_060221B0:
    if (c.t) { goto L_06022256; }  // 060221B0 bt 0x06022256
    c.r[9] = 0x0u;  // 060221B2 mov #0,r9
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[10];  // 060221B4 cmp/ge r10,r9
    { const bool k = c.t; c.r[5] = 0x0u; if (k) { goto L_0602223C; } }  // 060221B6 bt/s 0x0602223C ; mov #0,r5
    c.r[8] = ld32(0x06022294u);  // 060221BA mov.l 0x06022294,r8
    c.r[4] = 0x0u;  // 060221BC mov #0,r4
L_060221BE:
    c.r[0] = ld32(0x06022294u);  // 060221BE mov.l 0x06022294,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[4]);  // 060221C0 mov.b @(r0,r4),r1
    c.r[7] = c.r[1] & 0xFFu;  // 060221C2 extu.b r1,r7
    c.r[1] = c.r[8];  // 060221C4 mov r8,r1
    c.r[1] += 1;  // 060221C6 add #1,r1
    c.r[3] = c.r[7];  // 060221C8 mov r7,r3
    c.r[3] += c.r[3];  // 060221CA add r3,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060221CC mov.b @r1,r1
    c.r[0] = ld32(0x06022298u);  // 060221CE mov.l 0x06022298,r0
    c.r[6] = c.r[1] & 0xFFu;  // 060221D0 extu.b r1,r6
    c.r[13] = c.r[6];  // 060221D2 mov r6,r13
    c.r[13] <<= 2;  // 060221D4 shll2 r13
    c.r[13] <<= 2;  // 060221D6 shll2 r13
    c.r[13] += c.r[13];  // 060221D8 add r13,r13
    c.r[13] <<= 2;  // 060221DA shll2 r13
    c.r[13] += c.r[0];  // 060221DC add r0,r13
    c.r[0] = c.r[13];  // 060221DE mov r13,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 060221E0 mov.w @(r0,r3),r1
    c.r[2] = c.r[1] & 0xFFFFu;  // 060221E2 extu.w r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 060221E4 tst r2,r2
    { const bool k = !c.t; st32(c.r[14] + 16, c.r[13]); if (k) { goto L_06022206; } }  // 060221E6 bf/s 0x06022206 ; mov.l r13,@(16,r14)
    c.r[13] = ld32(0x0602229Cu);  // 060221EA mov.l 0x0602229C,r13
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 060221EC mov.b @r13,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060221EE extu.b r1,r1
    c.t = c.r[1] == c.r[7];  // 060221F0 cmp/eq r7,r1
    if (!c.t) { goto L_060221FE; }  // 060221F2 bf 0x060221FE
    c.r[0] = ld32(0x060222A0u);  // 060221F4 mov.l 0x060222A0,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 060221F6 mov.b @r0,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060221F8 extu.b r1,r1
    c.t = c.r[1] == c.r[6];  // 060221FA cmp/eq r6,r1
    if (c.t) { goto L_06022206; }  // 060221FC bt 0x06022206
L_060221FE:
    c.r[2] = ld32(0x060222A4u);  // 060221FE mov.l 0x060222A4,r2
    c.r[0] = ld32(c.r[14] + 16);  // 06022200 mov.l @(16,r14),r0
    c.r[13] = (uint32_t)(int16_t)ld16(0x06022292u);  // 06022202 mov.w 0x06022292,r13
    st16(c.r[0] + c.r[3], c.r[13]);  // 06022204 mov.w r13,@(r0,r3)
L_06022206:
    c.r[0] = ld32(0x060222A4u);  // 06022206 mov.l 0x060222A4,r0
    c.t = c.r[2] == c.r[0];  // 06022208 cmp/eq r0,r2
    { const bool k = c.t; c.t = c.r[12] == c.r[2]; if (k) { goto L_06022216; } }  // 0602220A bt/s 0x06022216 ; cmp/eq r2,r12
    c.r[1] = c.r[2];  // 0602220E mov r2,r1
    c.r[1] += 1;  // 06022210 add #1,r1
    c.r[2] = c.r[1] & 0xFFFFu;  // 06022212 extu.w r1,r2
    c.t = c.r[12] == c.r[2];  // 06022214 cmp/eq r2,r12
L_06022216:
    if (!c.t) { goto L_06022232; }  // 06022216 bf 0x06022232
    c.r[1] = ld32(c.r[11]);  // 06022218 mov.l @r11,r1
    c.r[0] = ld32(0x060222A8u);  // 0602221A mov.l 0x060222A8,r0
    c.r[1] += c.r[1];  // 0602221C add r1,r1
    st8(c.r[0] + c.r[1], c.r[7]);  // 0602221E mov.b r7,@(r0,r1)
    c.r[1] = ld32(c.r[11]);  // 06022220 mov.l @r11,r1
    c.r[1] += c.r[1];  // 06022222 add r1,r1
    c.r[1] += c.r[0];  // 06022224 add r0,r1
    c.r[1] += 1;  // 06022226 add #1,r1
    st8(c.r[1], c.r[6]);  // 06022228 mov.b r6,@r1
    c.r[1] = ld32(c.r[11]);  // 0602222A mov.l @r11,r1
    c.r[9] += 1;  // 0602222C add #1,r9
    c.r[1] += 1;  // 0602222E add #1,r1
    st32(c.r[11], c.r[1]);  // 06022230 mov.l r1,@r11
L_06022232:
    c.r[8] += 2;  // 06022232 add #2,r8
    c.r[5] += 1;  // 06022234 add #1,r5
    c.t = (int32_t)c.r[5] >= (int32_t)c.r[10];  // 06022236 cmp/ge r10,r5
    { const bool k = !c.t; c.r[4] += 2; if (k) { SH2_POLL(c); goto L_060221BE; } }  // 06022238 bf/s 0x060221BE ; add #2,r4
L_0602223C:
    c.r[1] = 0xFFFFFFFFu;  // 0602223C mov #-1,r1
    c.r[2] = ld32(c.r[11]);  // 0602223E mov.l @r11,r2
    c.r[0] = ld32(0x060222A8u);  // 06022240 mov.l 0x060222A8,r0
    c.r[2] += c.r[2];  // 06022242 add r2,r2
    st8(c.r[0] + c.r[2], c.r[1]);  // 06022244 mov.b r1,@(r0,r2)
    c.r[1] = ld32(c.r[11]);  // 06022246 mov.l @r11,r1
    c.r[1] += c.r[1];  // 06022248 add r1,r1
    c.r[1] += c.r[0];  // 0602224A add r0,r1
    c.r[1] += 1;  // 0602224C add #1,r1
    st8(c.r[1], c.r[9]);  // 0602224E mov.b r9,@r1
    c.r[1] = ld32(c.r[11]);  // 06022250 mov.l @r11,r1
    c.r[1] += 1;  // 06022252 add #1,r1
    st32(c.r[11], c.r[1]);  // 06022254 mov.l r1,@r11
L_06022256:
    c.r[12] = (uint32_t)(int32_t)(int16_t)c.r[12];  // 06022256 exts.w r12,r12
    c.r[13] = ld32(c.r[14]);  // 06022258 mov.l @r14,r13
    st32(c.r[14] + 8, c.r[12]);  // 0602225A mov.l r12,@(8,r14)
    c.r[13] += 1;  // 0602225C add #1,r13
    c.t = (int32_t)c.r[13] >= (int32_t)c.r[10];  // 0602225E cmp/ge r10,r13
    { const bool k = c.t; st32(c.r[14], c.r[13]); if (k) { goto L_06022268; } }  // 06022260 bt/s 0x06022268 ; mov.l r13,@r14
    SH2_POLL(c); goto L_060220C2;  // 06022264 bra 0x060220C2 ; nop
L_06022268:
    c.r[1] = ld32(0x060222ACu);  // 06022268 mov.l 0x060222AC,r1
    c.r[3] = ld32(c.r[1]);  // 0602226A mov.l @r1,r3
    c.t = (c.r[3] & c.r[3]) == 0;  // 0602226C tst r3,r3
    if (!c.t) { goto L_0602227A; }  // 0602226E bf 0x0602227A
    c.r[10] = 0x0u;  // 06022270 mov #0,r10
    c.r[2] = ld32(0x060222B0u);  // 06022272 mov.l 0x060222B0,r2
    c.r[1] = ld32(0x060222B4u);  // 06022274 mov.l 0x060222B4,r1
    st32(c.r[1], c.r[3]);  // 06022276 mov.l r3,@r1
    st32(c.r[2], c.r[3]);  // 06022278 mov.l r3,@r2
L_0602227A:
    c.r[14] += 20;  // 0602227A add #20,r14
    c.r[15] = c.r[14];  // 0602227C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0602227E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06022280 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06022282 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06022284 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06022286 mov.l @r15+,r11
    c.r[0] = c.r[10];  // 06022288 mov r10,r0
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0602228A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0602228C mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0602228E rts ; mov.l @r15+,r8
}

}  // namespace p_srwfin_installed
