#include "p_srwfin_installed_funcs.h"

namespace p_srwfin_installed {

void f_0605D990(SH2Context& c) {
    ran[1434] = 1;
    c.t = (ld8(c.gbr + c.r[0]) & 0xCCu) == 0;  // 0605D990 tst.b #204,@(r0,gbr)
    c.t = (ld8(c.gbr + c.r[0]) & 0xCDu) == 0;  // 0605D992 tst.b #205,@(r0,gbr)
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605D994 mov.l r14,@-r15
    c.r[1] = ld32(0x0605D9F4u);  // 0605D996 mov.l 0x0605D9F4,r1
    c.r[7] = ld32(c.r[1]);  // 0605D998 mov.l @r1,r7
    c.r[1] = ld32(0x0605D9F8u);  // 0605D99A mov.l 0x0605D9F8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605D99C mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0605D99E extu.b r1,r2
    c.r[1] = ld32(0x0605D9FCu);  // 0605D9A0 mov.l 0x0605D9FC,r1
    c.r[0] = c.r[2];  // 0605D9A2 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0605D9A4 mov.b @(r0,r1),r1
    c.r[2] = ld32(0x0605DA00u);  // 0605D9A6 mov.l 0x0605DA00,r2
    c.r[2] = ld32(c.r[2]);  // 0605D9A8 mov.l @r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0605D9AA extu.b r1,r1
    { uint64_t p = (uint64_t)c.r[1] * c.r[2]; c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 0605D9AC dmulu.l r2,r1
    c.r[0] = c.r[7];  // 0605D9AE mov r7,r0
    c.r[2] = c.mach;  // 0605D9B0 sts mach,r2
    c.r[2] >>= 2;  // 0605D9B2 shlr2 r2
    c.r[3] = c.r[2];  // 0605D9B4 mov r2,r3
    c.r[3] <<= 2;  // 0605D9B6 shll2 r3
    c.r[3] += c.r[2];  // 0605D9B8 add r2,r3
    c.r[1] -= c.r[3];  // 0605D9BA sub r3,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605D9BC extu.b r1,r1
    c.r[3] = c.r[1];  // 0605D9BE mov r1,r3
    c.r[3] += c.r[3];  // 0605D9C0 add r3,r3
    c.r[3] += c.r[1];  // 0605D9C2 add r1,r3
    c.r[3] += c.r[3];  // 0605D9C4 add r3,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0605D9C6 extu.b r2,r2
    c.r[3] += c.r[2];  // 0605D9C8 add r2,r3
    c.r[3] += c.r[3];  // 0605D9CA add r3,r3
    c.r[2] = 0x7Fu;  // 0605D9CC mov #127,r2
    c.r[7] += c.r[3];  // 0605D9CE add r3,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0605D9D0 mov.b @(r0,r3),r1
    c.r[7] += 1;  // 0605D9D2 add #1,r7
    c.r[2] &= c.r[1];  // 0605D9D4 and r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0605D9D6 mov.b @r7,r1
    c.r[2] <<= 8;  // 0605D9D8 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0605D9DA extu.b r1,r1
    c.r[1] |= c.r[2];  // 0605D9DC or r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605D9DE tst r1,r1
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605D9F0u);  // 0605D9E0 mov.w 0x0605D9F0,r1
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0605D9E8; } }  // 0605D9E2 bf/s 0x0605D9E8 ; mov r15,r14
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605D9F2u);  // 0605D9E6 mov.w 0x0605D9F2,r1
L_0605D9E8:
    c.r[15] = c.r[14];  // 0605D9E8 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0605D9EA mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[1]; c.pc = x; return; }  // 0605D9EC rts ; mov r1,r0
}

void f_0605D994(SH2Context& c) {
    ran[1435] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605D994 mov.l r14,@-r15
    c.r[1] = ld32(0x0605D9F4u);  // 0605D996 mov.l 0x0605D9F4,r1
    c.r[7] = ld32(c.r[1]);  // 0605D998 mov.l @r1,r7
    c.r[1] = ld32(0x0605D9F8u);  // 0605D99A mov.l 0x0605D9F8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605D99C mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0605D99E extu.b r1,r2
    c.r[1] = ld32(0x0605D9FCu);  // 0605D9A0 mov.l 0x0605D9FC,r1
    c.r[0] = c.r[2];  // 0605D9A2 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0605D9A4 mov.b @(r0,r1),r1
    c.r[2] = ld32(0x0605DA00u);  // 0605D9A6 mov.l 0x0605DA00,r2
    c.r[2] = ld32(c.r[2]);  // 0605D9A8 mov.l @r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0605D9AA extu.b r1,r1
    { uint64_t p = (uint64_t)c.r[1] * c.r[2]; c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 0605D9AC dmulu.l r2,r1
    c.r[0] = c.r[7];  // 0605D9AE mov r7,r0
    c.r[2] = c.mach;  // 0605D9B0 sts mach,r2
    c.r[2] >>= 2;  // 0605D9B2 shlr2 r2
    c.r[3] = c.r[2];  // 0605D9B4 mov r2,r3
    c.r[3] <<= 2;  // 0605D9B6 shll2 r3
    c.r[3] += c.r[2];  // 0605D9B8 add r2,r3
    c.r[1] -= c.r[3];  // 0605D9BA sub r3,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605D9BC extu.b r1,r1
    c.r[3] = c.r[1];  // 0605D9BE mov r1,r3
    c.r[3] += c.r[3];  // 0605D9C0 add r3,r3
    c.r[3] += c.r[1];  // 0605D9C2 add r1,r3
    c.r[3] += c.r[3];  // 0605D9C4 add r3,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0605D9C6 extu.b r2,r2
    c.r[3] += c.r[2];  // 0605D9C8 add r2,r3
    c.r[3] += c.r[3];  // 0605D9CA add r3,r3
    c.r[2] = 0x7Fu;  // 0605D9CC mov #127,r2
    c.r[7] += c.r[3];  // 0605D9CE add r3,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0605D9D0 mov.b @(r0,r3),r1
    c.r[7] += 1;  // 0605D9D2 add #1,r7
    c.r[2] &= c.r[1];  // 0605D9D4 and r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0605D9D6 mov.b @r7,r1
    c.r[2] <<= 8;  // 0605D9D8 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0605D9DA extu.b r1,r1
    c.r[1] |= c.r[2];  // 0605D9DC or r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605D9DE tst r1,r1
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605D9F0u);  // 0605D9E0 mov.w 0x0605D9F0,r1
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0605D9E8; } }  // 0605D9E2 bf/s 0x0605D9E8 ; mov r15,r14
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605D9F2u);  // 0605D9E6 mov.w 0x0605D9F2,r1
L_0605D9E8:
    c.r[15] = c.r[14];  // 0605D9E8 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0605D9EA mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[1]; c.pc = x; return; }  // 0605D9EC rts ; mov r1,r0
}

void f_0605DA04(SH2Context& c) {
    ran[1436] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605DA04 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0605DA06 sts.l pr,@-r15
    c.r[15] -= 8;  // 0605DA08 add #-8,r15
    c.r[14] = c.r[15];  // 0605DA0A mov r15,r14
    c.r[1] = 0xFFFFFFFFu;  // 0605DA0C mov #-1,r1
    st8(c.r[14], c.r[1]);  // 0605DA0E mov.b r1,@r14
    c.r[7] = ld32(0x0605DA90u);  // 0605DA10 mov.l 0x0605DA90,r7
    c.r[1] = c.r[7];  // 0605DA12 mov r7,r1
    c.r[1] += 118;  // 0605DA14 add #118,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605DA16 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605DA18 extu.b r1,r1
    c.r[1] >>= 2;  // 0605DA1A shlr2 r1
    c.r[1] >>= 2;  // 0605DA1C shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0605DA1E shlr r1
    c.r[1] >>= 2;  // 0605DA20 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605DA22 tst r1,r1
    { const bool k = !c.t; c.r[1] = c.r[7]; if (k) { goto L_0605DA70; } }  // 0605DA24 bf/s 0x0605DA70 ; mov r7,r1
    c.r[1] += 122;  // 0605DA28 add #122,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605DA2A mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605DA2C extu.b r1,r1
    c.r[1] >>= 2;  // 0605DA2E shlr2 r1
    c.r[1] >>= 2;  // 0605DA30 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0605DA32 shlr r1
    c.r[1] >>= 2;  // 0605DA34 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605DA36 tst r1,r1
    { const bool k = !c.t; c.r[1] = c.r[7]; if (k) { goto L_0605DA70; } }  // 0605DA38 bf/s 0x0605DA70 ; mov r7,r1
    c.r[1] += 117;  // 0605DA3C add #117,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605DA3E mov.b @r1,r3
    c.r[2] = ld32(0x0605DA94u);  // 0605DA40 mov.l 0x0605DA94,r2
    c.r[2] = ld32(c.r[2]);  // 0605DA42 mov.l @r2,r2
    c.r[1] = c.r[7];  // 0605DA44 mov r7,r1
    c.r[1] += 79;  // 0605DA46 add #79,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605DA48 mov.b @r1,r1
    c.r[3] = c.r[3] & 0xFFu;  // 0605DA4A extu.b r3,r3
    c.r[3] += c.r[1];  // 0605DA4C add r1,r3
    c.r[1] = c.r[7];  // 0605DA4E mov r7,r1
    c.r[1] += 116;  // 0605DA50 add #116,r1
    c.r[7] += 78;  // 0605DA52 add #78,r7
    c.r[3] <<= 2;  // 0605DA54 shll2 r3
    c.r[3] <<= 2;  // 0605DA56 shll2 r3
    c.r[3] <<= 2;  // 0605DA58 shll2 r3
    c.r[3] += c.r[2];  // 0605DA5A add r2,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605DA5C mov.b @r1,r1
    c.r[0] = c.r[3];  // 0605DA5E mov r3,r0
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0605DA60 mov.b @r7,r7
    c.r[1] = c.r[1] & 0xFFu;  // 0605DA62 extu.b r1,r1
    c.r[1] += c.r[7];  // 0605DA64 add r7,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0605DA66 mov.b @(r0,r1),r4
    c.r[5] = c.r[14];  // 0605DA68 mov r14,r5
    c.r[1] = ld32(0x0605DA98u);  // 0605DA6A mov.l 0x0605DA98,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0605DA70u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605DA70u) return; }  // 0605DA6C jsr @r1 ; extu.b r4,r4
L_0605DA70:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[14]);  // 0605DA70 mov.b @r14,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0605DA8Au);  // 0605DA72 mov.w 0x0605DA8A,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0605DA74 extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 0605DA76 cmp/eq r2,r1
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605DA8Cu);  // 0605DA78 mov.w 0x0605DA8C,r1
    if (c.t) { goto L_0605DA7E; }  // 0605DA7A bt 0x0605DA7E
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605DA8Eu);  // 0605DA7C mov.w 0x0605DA8E,r1
L_0605DA7E:
    c.r[14] += 8;  // 0605DA7E add #8,r14
    c.r[15] = c.r[14];  // 0605DA80 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0605DA82 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0605DA84 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[1]; c.pc = x; return; }  // 0605DA86 rts ; mov r1,r0
}

void f_0605DA9C(SH2Context& c) {
    ran[1437] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605DA9C mov.l r14,@-r15
    c.r[2] = ld32(0x0605DAECu);  // 0605DA9E mov.l 0x0605DAEC,r2
    c.r[1] = c.r[2];  // 0605DAA0 mov r2,r1
    c.r[1] += 117;  // 0605DAA2 add #117,r1
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605DAA4 mov.b @r1,r7
    c.r[6] = ld32(0x0605DAF0u);  // 0605DAA6 mov.l 0x0605DAF0,r6
    c.r[1] = c.r[2];  // 0605DAA8 mov r2,r1
    c.r[1] += 79;  // 0605DAAA add #79,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605DAAC mov.b @r1,r1
    c.r[7] = c.r[7] & 0xFFu;  // 0605DAAE extu.b r7,r7
    c.r[7] += c.r[1];  // 0605DAB0 add r1,r7
    c.r[1] = c.r[2];  // 0605DAB2 mov r2,r1
    c.r[1] += 116;  // 0605DAB4 add #116,r1
    c.r[2] += 78;  // 0605DAB6 add #78,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605DAB8 mov.b @r1,r3
    c.r[7] <<= 2;  // 0605DABA shll2 r7
    c.r[7] <<= 2;  // 0605DABC shll2 r7
    c.r[7] <<= 2;  // 0605DABE shll2 r7
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605DAC0 mov.b @r2,r2
    c.r[3] = c.r[3] & 0xFFu;  // 0605DAC2 extu.b r3,r3
    c.r[1] = ld32(c.r[6]);  // 0605DAC4 mov.l @r6,r1
    c.r[3] += c.r[2];  // 0605DAC6 add r2,r3
    c.r[7] += c.r[1];  // 0605DAC8 add r1,r7
    c.r[0] = c.r[7];  // 0605DACA mov r7,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0605DACC mov.b @(r0,r3),r2
    c.r[6] += 19;  // 0605DACE add #19,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0605DAD0 mov.b @r6,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0605DAD2 extu.b r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0605DAD4 extu.b r1,r1
    c.t = c.r[2] == c.r[1];  // 0605DAD6 cmp/eq r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605DAE8u);  // 0605DAD8 mov.w 0x0605DAE8,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0605DAE0; } }  // 0605DADA bt/s 0x0605DAE0 ; mov r15,r14
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605DAEAu);  // 0605DADE mov.w 0x0605DAEA,r1
L_0605DAE0:
    c.r[15] = c.r[14];  // 0605DAE0 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0605DAE2 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[1]; c.pc = x; return; }  // 0605DAE4 rts ; mov r1,r0
}

void f_0605DAF4(SH2Context& c) {
    ran[1438] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605DAF4 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0605DAF6 mov r15,r14
    c.r[1] = ld32(0x0605DB14u);  // 0605DAF8 mov.l 0x0605DB14,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605DAFA mov.b @r1,r1
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0605DAFC mov.l @r15+,r14
    c.r[0] = c.r[1];  // 0605DAFE mov r1,r0
    c.r[0] >>= 2;  // 0605DB00 shlr2 r0
    c.r[0] >>= 2;  // 0605DB02 shlr2 r0
    c.r[0] >>= 2;  // 0605DB04 shlr2 r0
    c.r[0] &= 0x2u;  // 0605DB06 and #2,r0
    c.r[0] += 1;  // 0605DB08 add #1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605DB10u);  // 0605DB0A mov.w 0x0605DB10,r1
    { const uint32_t x = c.pr; c.r[0] |= c.r[1]; c.pc = x; return; }  // 0605DB0C rts ; or r1,r0
}

void f_0605DB18(SH2Context& c) {
    ran[1439] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605DB18 mov.l r14,@-r15
    c.r[1] = ld32(0x0605DB60u);  // 0605DB1A mov.l 0x0605DB60,r1
    c.r[1] = ld32(c.r[1]);  // 0605DB1C mov.l @r1,r1
    c.r[1] += 6;  // 0605DB1E add #6,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605DB20 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0605DB22 extu.b r1,r0
    c.r[1] = ld32(0x0605DB64u);  // 0605DB24 mov.l 0x0605DB64,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0605DB26 mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605DB28 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605DB2A tst r1,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0605DB54; } }  // 0605DB2C bt/s 0x0605DB54 ; mov r15,r14
    c.r[2] = c.r[1];  // 0605DB30 mov r1,r2
    c.r[2] -= 1;  // 0605DB32 add #-1,r2
    c.r[1] = ld32(0x0605DB68u);  // 0605DB34 mov.l 0x0605DB68,r1
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[2] * (int32_t)c.r[1]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 0605DB36 dmuls.l r1,r2
    c.r[1] = c.mach;  // 0605DB38 sts mach,r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0605DB3A shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0605DB3C shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0605DB3E shar r1
    c.t = c.r[2] >> 31; c.r[2] <<= 1;  // 0605DB40 shll r2
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 0605DB42 subc r2,r2
    c.r[1] -= c.r[2];  // 0605DB44 sub r2,r1
    c.r[1] += 1;  // 0605DB46 add #1,r1
    c.r[1] += c.r[1];  // 0605DB48 add r1,r1
    c.r[1] += 1;  // 0605DB4A add #1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0605DB5Cu);  // 0605DB4C mov.w 0x0605DB5C,r2
    c.r[1] |= c.r[2];  // 0605DB4E or r2,r1
    c.r[0] = c.r[1] & 0xFFFFu; goto L_0605DB56;  // 0605DB50 bra 0x0605DB56 ; extu.w r1,r0
L_0605DB54:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605DB5Eu);  // 0605DB54 mov.w 0x0605DB5E,r0
L_0605DB56:
    c.r[15] = c.r[14];  // 0605DB56 mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0605DB58 rts ; mov.l @r15+,r14
}

void f_0605DB6C(SH2Context& c) {
    ran[1440] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605DB6C mov.l r14,@-r15
    c.r[1] = ld32(0x0605DC9Cu);  // 0605DB6E mov.l 0x0605DC9C,r1
    c.r[1] = ld32(c.r[1]);  // 0605DB70 mov.l @r1,r1
    c.r[14] = c.r[15];  // 0605DB72 mov r15,r14
    c.r[1] += 1;  // 0605DB74 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605DB76 mov.b @r1,r1
    c.r[6] = c.r[1] & 0xFFu;  // 0605DB78 extu.b r1,r6
    c.r[0] = c.r[6];  // 0605DB7A mov r6,r0
    c.t = c.r[0] == 0x2u;  // 0605DB7C cmp/eq #2,r0
    { const bool k = !c.t; c.r[4] = 0x1u; if (k) { goto L_0605DC18; } }  // 0605DB7E bf/s 0x0605DC18 ; mov #1,r4
    c.r[1] = ld32(0x0605DCA0u);  // 0605DB82 mov.l 0x0605DCA0,r1
    c.r[7] = ld32(c.r[1]);  // 0605DB84 mov.l @r1,r7
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605DC94u);  // 0605DB86 mov.w 0x0605DC94,r1
    c.r[7] += c.r[1];  // 0605DB88 add r1,r7
    c.r[1] = ld32(0x0605DCA4u);  // 0605DB8A mov.l 0x0605DCA4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605DB8C mov.b @r1,r1
    c.r[5] = c.r[1] & 0xFFu;  // 0605DB8E extu.b r1,r5
    c.r[1] = c.r[5];  // 0605DB90 mov r5,r1
    c.r[1] <<= 2;  // 0605DB92 shll2 r1
    c.r[1] += c.r[1];  // 0605DB94 add r1,r1
    c.r[7] += c.r[1];  // 0605DB96 add r1,r7
    c.r[1] = c.r[7];  // 0605DB98 mov r7,r1
    c.r[1] += 4;  // 0605DB9A add #4,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605DB9C mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0605DB9E extu.b r2,r2
    c.r[1] = ld32(0x0605DCA8u);  // 0605DBA0 mov.l 0x0605DCA8,r1
    c.r[2] <<= 2;  // 0605DBA2 shll2 r2
    c.r[2] <<= 2;  // 0605DBA4 shll2 r2
    c.r[6] = c.r[2];  // 0605DBA6 mov r2,r6
    c.r[3] = ld32(c.r[1]);  // 0605DBA8 mov.l @r1,r3
    c.r[0] = c.r[2];  // 0605DBAA mov r2,r0
    c.r[1] = c.r[7];  // 0605DBAC mov r7,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0605DBAE mov.b @(r0,r3),r2
    c.r[1] += 5;  // 0605DBB0 add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605DBB2 mov.b @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0605DBB4 extu.b r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0605DBB6 extu.b r1,r1
    c.t = c.r[2] == c.r[1];  // 0605DBB8 cmp/eq r1,r2
    { const bool k = !c.t; c.r[6] += c.r[3]; if (k) { goto L_0605DC82; } }  // 0605DBBA bf/s 0x0605DC82 ; add r3,r6
    c.r[1] = c.r[6];  // 0605DBBE mov r6,r1
    c.r[1] += 1;  // 0605DBC0 add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605DBC2 mov.b @r1,r2
    c.r[7] += 6;  // 0605DBC4 add #6,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0605DBC6 mov.b @r7,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0605DBC8 extu.b r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0605DBCA extu.b r1,r1
    c.t = c.r[2] == c.r[1];  // 0605DBCC cmp/eq r1,r2
    { const bool k = !c.t; c.r[6] += 2; if (k) { goto L_0605DC82; } }  // 0605DBCE bf/s 0x0605DC82 ; add #2,r6
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0605DBD2 mov.b @r6,r2
    c.r[1] = ld32(0x0605DCACu);  // 0605DBD4 mov.l 0x0605DCAC,r1
    c.r[3] = ld32(c.r[1]);  // 0605DBD6 mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0605DBD8 extu.b r2,r2
    c.r[1] = 0x1Eu;  // 0605DBDA mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 0605DBDC mul.l r1,r2
    c.r[7] = c.macl;  // 0605DBDE sts macl,r7
    c.r[7] += c.r[3];  // 0605DBE0 add r3,r7
    c.r[1] = ld32(0x0605DCB0u);  // 0605DBE2 mov.l 0x0605DCB0,r1
    c.r[3] = ld32(c.r[1]);  // 0605DBE4 mov.l @r1,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[7]);  // 0605DBE6 mov.w @r7,r2
    c.r[1] = c.r[5];  // 0605DBE8 mov r5,r1
    c.r[1] <<= 2;  // 0605DBEA shll2 r1
    c.r[6] = c.r[1];  // 0605DBEC mov r1,r6
    c.r[0] = c.r[1];  // 0605DBEE mov r1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 0605DBF0 mov.w @(r0,r3),r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 0605DBF2 extu.w r2,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 0605DBF4 extu.w r1,r1
    c.t = c.r[2] == c.r[1];  // 0605DBF6 cmp/eq r1,r2
    { const bool k = !c.t; c.r[6] += c.r[3]; if (k) { goto L_0605DC82; } }  // 0605DBF8 bf/s 0x0605DC82 ; add r3,r6
    c.r[7] += 15;  // 0605DBFC add #15,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0605DBFE mov.b @r7,r1
    c.r[2] = ld32(0x0605DCB4u);  // 0605DC00 mov.l 0x0605DCB4,r2
    c.r[3] = ld32(c.r[2]);  // 0605DC02 mov.l @r2,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0605DC04 extu.b r1,r1
    c.r[2] = c.r[1];  // 0605DC06 mov r1,r2
    c.r[2] += c.r[2];  // 0605DC08 add r2,r2
    c.r[2] += c.r[1];  // 0605DC0A add r1,r2
    c.r[2] <<= 2;  // 0605DC0C shll2 r2
    c.r[0] = c.r[2];  // 0605DC0E mov r2,r0
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 0605DC10 mov.w @(r0,r3),r2
    c.r[6] += 2;  // 0605DC12 add #2,r6
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[6]); goto L_0605DC78;  // 0605DC14 bra 0x0605DC78 ; mov.w @r6,r1
L_0605DC18:
    c.r[1] = ld32(0x0605DCB8u);  // 0605DC18 mov.l 0x0605DCB8,r1
    c.r[0] = c.r[6];  // 0605DC1A mov r6,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0605DC1C mov.b @(r0,r1),r2
    c.r[2] = c.r[2] & 0xFFu;  // 0605DC1E extu.b r2,r2
    c.r[1] = ld32(0x0605DCA8u);  // 0605DC20 mov.l 0x0605DCA8,r1
    c.r[2] <<= 2;  // 0605DC22 shll2 r2
    c.r[2] <<= 2;  // 0605DC24 shll2 r2
    c.r[3] = c.r[2];  // 0605DC26 mov r2,r3
    c.r[1] = ld32(c.r[1]);  // 0605DC28 mov.l @r1,r1
    c.r[0] = c.r[2];  // 0605DC2A mov r2,r0
    c.r[3] += c.r[1];  // 0605DC2C add r1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0605DC2E mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605DC30 extu.b r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0605DC96u);  // 0605DC32 mov.w 0x0605DC96,r2
    c.t = c.r[1] == c.r[2];  // 0605DC34 cmp/eq r2,r1
    { const bool k = c.t; c.r[3] += 2; if (k) { goto L_0605DC82; } }  // 0605DC36 bt/s 0x0605DC82 ; add #2,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0605DC3A mov.b @r3,r2
    c.r[1] = ld32(0x0605DCACu);  // 0605DC3C mov.l 0x0605DCAC,r1
    c.r[3] = ld32(c.r[1]);  // 0605DC3E mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0605DC40 extu.b r2,r2
    c.r[1] = 0x1Eu;  // 0605DC42 mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 0605DC44 mul.l r1,r2
    c.r[6] += c.r[6];  // 0605DC46 add r6,r6
    c.r[0] = c.r[6];  // 0605DC48 mov r6,r0
    c.r[7] = c.macl;  // 0605DC4A sts macl,r7
    c.r[7] += c.r[3];  // 0605DC4C add r3,r7
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[7]);  // 0605DC4E mov.w @r7,r2
    c.r[1] = ld32(0x0605DCBCu);  // 0605DC50 mov.l 0x0605DCBC,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0605DC52 mov.w @(r0,r1),r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 0605DC54 extu.w r2,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 0605DC56 extu.w r1,r1
    c.t = c.r[2] == c.r[1];  // 0605DC58 cmp/eq r1,r2
    { const bool k = !c.t; c.r[7] += 15; if (k) { goto L_0605DC82; } }  // 0605DC5A bf/s 0x0605DC82 ; add #15,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0605DC5E mov.b @r7,r1
    c.r[2] = ld32(0x0605DCB4u);  // 0605DC60 mov.l 0x0605DCB4,r2
    c.r[3] = ld32(c.r[2]);  // 0605DC62 mov.l @r2,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0605DC64 extu.b r1,r1
    c.r[2] = c.r[1];  // 0605DC66 mov r1,r2
    c.r[2] += c.r[2];  // 0605DC68 add r2,r2
    c.r[2] += c.r[1];  // 0605DC6A add r1,r2
    c.r[2] <<= 2;  // 0605DC6C shll2 r2
    c.r[0] = c.r[2];  // 0605DC6E mov r2,r0
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 0605DC70 mov.w @(r0,r3),r2
    c.r[1] = ld32(0x0605DCC0u);  // 0605DC72 mov.l 0x0605DCC0,r1
    c.r[0] = c.r[6];  // 0605DC74 mov r6,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0605DC76 mov.w @(r0,r1),r1
L_0605DC78:
    c.r[2] = c.r[2] & 0xFFFFu;  // 0605DC78 extu.w r2,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 0605DC7A extu.w r1,r1
    c.t = c.r[2] == c.r[1];  // 0605DC7C cmp/eq r1,r2
    { const bool k = c.t; c.r[4] += c.r[4]; if (k) { goto L_0605DC86; } }  // 0605DC7E bt/s 0x0605DC86 ; add r4,r4
L_0605DC82:
    c.r[4] = 0x0u;  // 0605DC82 mov #0,r4
    c.r[4] += c.r[4];  // 0605DC84 add r4,r4
L_0605DC86:
    c.r[4] += 2;  // 0605DC86 add #2,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605DC98u);  // 0605DC88 mov.w 0x0605DC98,r1
    c.r[4] |= c.r[1];  // 0605DC8A or r1,r4
    c.r[15] = c.r[14];  // 0605DC8C mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0605DC8E mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[4]; c.pc = x; return; }  // 0605DC90 rts ; mov r4,r0
}

void f_0605DCC4(SH2Context& c) {
    ran[1441] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605DCC4 mov.l r14,@-r15
    c.r[1] = ld32(0x0605DCECu);  // 0605DCC6 mov.l 0x0605DCEC,r1
    c.r[2] = ld32(c.r[1]);  // 0605DCC8 mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605DCE6u);  // 0605DCCA mov.w 0x0605DCE6,r1
    c.r[0] = c.r[2];  // 0605DCCC mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0605DCCE mov.b @(r0,r1),r1
    c.r[0] = 0x4u;  // 0605DCD0 mov #4,r0
    c.r[1] &= c.r[0];  // 0605DCD2 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605DCD4 tst r1,r1
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605DCE8u);  // 0605DCD6 mov.w 0x0605DCE8,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0605DCDE; } }  // 0605DCD8 bt/s 0x0605DCDE ; mov r15,r14
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605DCEAu);  // 0605DCDC mov.w 0x0605DCEA,r1
L_0605DCDE:
    c.r[15] = c.r[14];  // 0605DCDE mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0605DCE0 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[1]; c.pc = x; return; }  // 0605DCE2 rts ; mov r1,r0
}

void f_0605DCF0(SH2Context& c) {
    ran[1442] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0605DCF0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0605DCF2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0605DCF4 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0605DCF6 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605DCF8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0605DCFA sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605DDA0u);  // 0605DCFC mov.w 0x0605DDA0,r3
    c.r[15] += c.r[3];  // 0605DCFE add r3,r15
    c.r[14] = c.r[15];  // 0605DD00 mov r15,r14
    c.r[9] = 0x0u;  // 0605DD02 mov #0,r9
    c.r[10] = (uint32_t)(int16_t)ld16(0x0605DDA2u);  // 0605DD04 mov.w 0x0605DDA2,r10
    c.r[11] = ld32(0x0605DDACu);  // 0605DD06 mov.l 0x0605DDAC,r11
    c.r[8] = 0x0u;  // 0605DD08 mov #0,r8
L_0605DD0A:
    c.r[1] = ld32(0x0605DDB0u);  // 0605DD0A mov.l 0x0605DDB0,r1
    c.r[0] = ld32(c.r[1]);  // 0605DD0C mov.l @r1,r0
    c.r[5] = c.r[8];  // 0605DD0E mov r8,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 0605DD10 mov.b @(r0,r8),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605DD12 extu.b r1,r1
    c.t = c.r[1] == c.r[10];  // 0605DD14 cmp/eq r10,r1
    { const bool k = c.t; c.r[5] += c.r[0]; if (k) { goto L_0605DD48; } }  // 0605DD16 bt/s 0x0605DD48 ; add r0,r5
    c.r[1] = c.r[5];  // 0605DD1A mov r5,r1
    c.r[1] += 7;  // 0605DD1C add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605DD1E mov.b @r1,r1
    c.r[0] = c.r[1];  // 0605DD20 mov r1,r0
    c.r[0] >>= 2;  // 0605DD22 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0605DD24 shlr r0
    c.r[0] &= 0x1u;  // 0605DD26 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605DD28 tst r0,r0
    { const bool k = !c.t; c.r[5] += 2; if (k) { goto L_0605DD48; } }  // 0605DD2A bf/s 0x0605DD48 ; add #2,r5
    c.r[6] = c.r[10];  // 0605DD2E mov r10,r6
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[5]);  // 0605DD30 mov.b @r5,r5
    c.r[4] = c.r[14];  // 0605DD32 mov r14,r4
    { const uint32_t x = c.r[11]; c.pr = 0x0605DD38u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605DD38u) return; }  // 0605DD34 jsr @r11 ; extu.b r5,r5
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605DDA4u);  // 0605DD38 mov.w 0x0605DDA4,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 0605DD3A mov.b @(r0,r14),r1
    c.r[0] = c.r[1];  // 0605DD3C mov r1,r0
    c.r[0] >>= 2;  // 0605DD3E shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0605DD40 shlr r0
    c.r[0] &= 0x1u;  // 0605DD42 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605DD44 tst r0,r0
    if (!c.t) { goto L_0605DD52; }  // 0605DD46 bf 0x0605DD52
L_0605DD48:
    c.r[9] += 1;  // 0605DD48 add #1,r9
    c.r[1] = 0x49u;  // 0605DD4A mov #73,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 0605DD4C cmp/gt r1,r9
    { const bool k = !c.t; c.r[8] += 16; if (k) { SH2_POLL(c); goto L_0605DD0A; } }  // 0605DD4E bf/s 0x0605DD0A ; add #16,r8
L_0605DD52:
    c.r[10] = 0x0u;  // 0605DD52 mov #0,r10
    c.r[1] = ld32(0x0605DDB4u);  // 0605DD54 mov.l 0x0605DDB4,r1
    c.r[1] = ld32(c.r[1]);  // 0605DD56 mov.l @r1,r1
    c.r[8] = ld32(0x0605DDB8u);  // 0605DD58 mov.l 0x0605DDB8,r8
    c.r[1] += 18;  // 0605DD5A add #18,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0605DD5C mov.w @r1,r4
    c.r[0] = ld32(0x0605DDBCu);  // 0605DD5E mov.l 0x0605DDBC,r0
    c.r[4] <<= 16;  // 0605DD60 shll16 r4
    c.r[4] <<= 2;  // 0605DD62 shll2 r4
    c.r[4] += c.r[4];  // 0605DD64 add r4,r4
    c.r[4] <<= 2;  // 0605DD66 shll2 r4
    c.r[4] >>= 16;  // 0605DD68 shlr16 r4
    c.r[4] <<= 2;  // 0605DD6A shll2 r4
    { const uint32_t x = c.r[0]; c.pr = 0x0605DD70u; c.r[4] >>= 8; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605DD70u) return; }  // 0605DD6C jsr @r0 ; shlr8 r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0605DD70 mov.b @r8,r1
    c.r[2] = c.r[0] & 0xFFu;  // 0605DD72 extu.b r0,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0605DD74 extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 0605DD76 cmp/eq r2,r1
    if (c.t) { goto L_0605DD82; }  // 0605DD78 bt 0x0605DD82
    c.r[0] = c.r[9];  // 0605DD7A mov r9,r0
    c.t = c.r[0] == 0x4Au;  // 0605DD7C cmp/eq #74,r0
    if (c.t) { goto L_0605DD82; }  // 0605DD7E bt 0x0605DD82
    c.r[10] = 0x1u;  // 0605DD80 mov #1,r10
L_0605DD82:
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605DDA6u);  // 0605DD82 mov.w 0x0605DDA6,r3
    c.r[14] += c.r[3];  // 0605DD84 add r3,r14
    c.r[15] = c.r[14];  // 0605DD86 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0605DD88 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0605DD8A mov.l @r15+,r14
    c.r[0] = c.r[10];  // 0605DD8C mov r10,r0
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0605DD8E mov.l @r15+,r11
    c.r[0] += c.r[0];  // 0605DD90 add r0,r0
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0605DD92 mov.l @r15+,r10
    c.r[0] += 1;  // 0605DD94 add #1,r0
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0605DD96 mov.l @r15+,r9
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605DDA8u);  // 0605DD98 mov.w 0x0605DDA8,r1
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0605DD9A mov.l @r15+,r8
    { const uint32_t x = c.pr; c.r[0] |= c.r[1]; c.pc = x; return; }  // 0605DD9C rts ; or r1,r0
}

void f_0605DDC0(SH2Context& c) {
    ran[1443] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605DDC0 mov.l r14,@-r15
    c.r[1] = ld32(0x0605DE08u);  // 0605DDC2 mov.l 0x0605DE08,r1
    c.r[1] = ld32(c.r[1]);  // 0605DDC4 mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605DE00u);  // 0605DDC6 mov.w 0x0605DE00,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0605DDC8 mov.b @(r0,r1),r1
    c.r[0] = c.r[1];  // 0605DDCA mov r1,r0
    c.r[0] >>= 2;  // 0605DDCC shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0605DDCE shlr r0
    c.r[0] &= 0x1u;  // 0605DDD0 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605DDD2 tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0605DDF8; } }  // 0605DDD4 bt/s 0x0605DDF8 ; mov r15,r14
    c.r[1] = ld32(0x0605DE0Cu);  // 0605DDD8 mov.l 0x0605DE0C,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605DDDA mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0605DDDC extu.b r2,r2
    c.r[1] = ld32(0x0605DE10u);  // 0605DDDE mov.l 0x0605DE10,r1
    c.r[1] = ld32(c.r[1]);  // 0605DDE0 mov.l @r1,r1
    c.r[2] <<= 2;  // 0605DDE2 shll2 r2
    c.r[2] <<= 2;  // 0605DDE4 shll2 r2
    c.r[2] += c.r[1];  // 0605DDE6 add r1,r2
    c.r[1] = ld32(c.r[2] + 12);  // 0605DDE8 mov.l @(12,r2),r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605DE02u);  // 0605DDEA mov.w 0x0605DE02,r0
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605DDEC tst r1,r1
    if (!c.t) { goto L_0605DDFA; }  // 0605DDEE bf 0x0605DDFA
    c.r[15] = c.r[14];  // 0605DDF0 mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605DE04u);  // 0605DDF2 mov.w 0x0605DE04,r0
    goto L_0605DDFC;  // 0605DDF4 bra 0x0605DDFC ; nop
L_0605DDF8:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605DE06u);  // 0605DDF8 mov.w 0x0605DE06,r0
L_0605DDFA:
    c.r[15] = c.r[14];  // 0605DDFA mov r14,r15
L_0605DDFC:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0605DDFC rts ; mov.l @r15+,r14
}

void f_0605DE14(SH2Context& c) {
    ran[1444] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0605DE14 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0605DE16 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605DE18 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0605DE1A sts.l pr,@-r15
    c.r[1] = ld32(0x0605DEC8u);  // 0605DE1C mov.l 0x0605DEC8,r1
    c.r[2] = ld32(c.r[1]);  // 0605DE1E mov.l @r1,r2
    c.r[1] = c.r[2];  // 0605DE20 mov r2,r1
    c.r[1] += 5;  // 0605DE22 add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605DE24 mov.b @r1,r1
    c.r[9] = c.r[1] & 0xFFu;  // 0605DE26 extu.b r1,r9
    c.r[1] = c.r[2];  // 0605DE28 mov r2,r1
    c.r[1] += 4;  // 0605DE2A add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605DE2C mov.b @r1,r1
    c.r[2] += 9;  // 0605DE2E add #9,r2
    c.r[3] = c.r[1] & 0xFFu;  // 0605DE30 extu.b r1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605DE32 mov.b @r2,r1
    c.r[8] = c.r[1] & 0xFFu;  // 0605DE34 extu.b r1,r8
    c.r[1] = ld32(0x0605DECCu);  // 0605DE36 mov.l 0x0605DECC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605DE38 mov.b @r1,r1
    c.r[7] = c.r[1] & 0xFFu;  // 0605DE3A extu.b r1,r7
    c.r[1] = ld32(0x0605DED0u);  // 0605DE3C mov.l 0x0605DED0,r1
    c.r[0] = c.r[7];  // 0605DE3E mov r7,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0605DE40 mov.b @(r0,r1),r2
    c.r[5] = c.r[3];  // 0605DE42 mov r3,r5
    c.r[2] = c.r[2] & 0xFFu;  // 0605DE44 extu.b r2,r2
    c.r[1] = ld32(0x0605DED4u);  // 0605DE46 mov.l 0x0605DED4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0605DE4Cu; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605DE4Cu) return; }  // 0605DE48 jsr @r1 ; mov r2,r4
    c.r[1] = c.r[0];  // 0605DE4C mov r0,r1
    c.macl = c.r[1] * c.r[3];  // 0605DE4E mul.l r3,r1
    c.r[14] = c.r[15];  // 0605DE50 mov r15,r14
    c.r[1] = c.macl;  // 0605DE52 sts macl,r1
    c.r[2] -= c.r[1];  // 0605DE54 sub r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0605DE56 extu.b r2,r2
    c.r[1] = c.r[3];  // 0605DE58 mov r3,r1
    c.r[1] -= 1;  // 0605DE5A add #-1,r1
    c.t = c.r[2] == c.r[1];  // 0605DE5C cmp/eq r1,r2
    { const bool k = !c.t; c.r[6] = 0x0u; if (k) { goto L_0605DE78; } }  // 0605DE5E bf/s 0x0605DE78 ; mov #0,r6
    c.r[1] = ld32(0x0605DED8u);  // 0605DE62 mov.l 0x0605DED8,r1
    c.r[0] = c.r[7];  // 0605DE64 mov r7,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0605DE66 mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605DE68 extu.b r1,r1
    c.macl = c.r[1] * c.r[9];  // 0605DE6A mul.l r9,r1
    c.r[1] = c.macl;  // 0605DE6C sts macl,r1
    c.macl = c.r[1] * c.r[3];  // 0605DE6E mul.l r3,r1
    c.r[1] = c.macl;  // 0605DE70 sts macl,r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[8];  // 0605DE72 cmp/gt r8,r1
    if (c.t) { goto L_0605DE78; }  // 0605DE74 bt 0x0605DE78
    c.r[6] = 0x1u;  // 0605DE76 mov #1,r6
L_0605DE78:
    c.r[1] = ld32(0x0605DECCu);  // 0605DE78 mov.l 0x0605DECC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605DE7A mov.b @r1,r1
    c.r[7] = c.r[1] & 0xFFu;  // 0605DE7C extu.b r1,r7
    c.r[1] = ld32(0x0605DED0u);  // 0605DE7E mov.l 0x0605DED0,r1
    c.r[0] = c.r[7];  // 0605DE80 mov r7,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0605DE82 mov.b @(r0,r1),r2
    c.r[5] = c.r[3];  // 0605DE84 mov r3,r5
    c.r[2] = c.r[2] & 0xFFu;  // 0605DE86 extu.b r2,r2
    c.r[1] = ld32(0x0605DED4u);  // 0605DE88 mov.l 0x0605DED4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0605DE8Eu; c.r[4] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605DE8Eu) return; }  // 0605DE8A jsr @r1 ; mov r2,r4
    c.r[1] = c.r[0];  // 0605DE8E mov r0,r1
    c.macl = c.r[1] * c.r[3];  // 0605DE90 mul.l r3,r1
    c.r[1] = c.macl;  // 0605DE92 sts macl,r1
    c.r[2] -= c.r[1];  // 0605DE94 sub r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0605DE96 extu.b r2,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0605DE98 tst r2,r2
    { const bool k = !c.t; c.r[0] = c.r[7]; if (k) { goto L_0605DEAE; } }  // 0605DE9A bf/s 0x0605DEAE ; mov r7,r0
    c.r[1] = ld32(0x0605DED8u);  // 0605DE9E mov.l 0x0605DED8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0605DEA0 mov.b @(r0,r1),r1
    c.r[2] = 0x1u;  // 0605DEA2 mov #1,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0605DEA4 extu.b r1,r1
    c.t = c.r[1] > c.r[2];  // 0605DEA6 cmp/hi r2,r1
    { const bool k = !c.t; c.r[6] = 0x3u; if (k) { goto L_0605DEAE; } }  // 0605DEA8 bf/s 0x0605DEAE ; mov #3,r6
    c.r[6] = 0x2u;  // 0605DEAC mov #2,r6
L_0605DEAE:
    c.r[6] += c.r[6];  // 0605DEAE add r6,r6
    c.r[15] = c.r[14];  // 0605DEB0 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0605DEB2 lds.l @r15+,pr
    c.r[6] += 1;  // 0605DEB4 add #1,r6
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0605DEB6 mov.l @r15+,r14
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605DEC4u);  // 0605DEB8 mov.w 0x0605DEC4,r1
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0605DEBA mov.l @r15+,r9
    c.r[6] |= c.r[1];  // 0605DEBC or r1,r6
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0605DEBE mov.l @r15+,r8
    { const uint32_t x = c.pr; c.r[0] = c.r[6]; c.pc = x; return; }  // 0605DEC0 rts ; mov r6,r0
}

void f_0605DEDC(SH2Context& c) {
    ran[1445] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0605DEDC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0605DEDE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0605DEE0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0605DEE2 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0605DEE4 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0605DEE6 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605DEE8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0605DEEA sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605DFC8u);  // 0605DEEC mov.w 0x0605DFC8,r3
    c.r[15] += c.r[3];  // 0605DEEE add r3,r15
    c.r[14] = c.r[15];  // 0605DEF0 mov r15,r14
    c.r[8] = ld32(0x0605DFD0u);  // 0605DEF2 mov.l 0x0605DFD0,r8
    c.r[0] = ld32(0x0605DFD4u);  // 0605DEF4 mov.l 0x0605DFD4,r0
    c.r[11] = ld32(0x0605DFD8u);  // 0605DEF6 mov.l 0x0605DFD8,r11
    c.r[9] = 0x1Eu;  // 0605DEF8 mov #30,r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]); c.r[8] += 1;  // 0605DEFA mov.b @r8+,r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x0605DFCAu);  // 0605DEFC mov.w 0x0605DFCA,r12
    c.r[2] = ld32(c.r[0]);  // 0605DEFE mov.l @r0,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0605DF00 extu.b r1,r1
    c.r[1] <<= 2;  // 0605DF02 shll2 r1
    c.r[1] <<= 2;  // 0605DF04 shll2 r1
    c.r[1] += c.r[2];  // 0605DF06 add r2,r1
    c.r[1] += 2;  // 0605DF08 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605DF0A mov.b @r1,r1
    c.r[12] += c.r[14];  // 0605DF0C add r14,r12
    c.r[1] = c.r[1] & 0xFFu;  // 0605DF0E extu.b r1,r1
    c.macl = c.r[1] * c.r[9];  // 0605DF10 mul.l r9,r1
    c.r[10] = ld32(0x0605DFDCu);  // 0605DF12 mov.l 0x0605DFDC,r10
    c.r[2] = ld32(c.r[11]);  // 0605DF14 mov.l @r11,r2
    c.r[1] = c.macl;  // 0605DF16 sts macl,r1
    c.r[1] += c.r[2];  // 0605DF18 add r2,r1
    c.r[1] += 15;  // 0605DF1A add #15,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605DF1C mov.b @r1,r5
    c.r[4] = c.r[12];  // 0605DF1E mov r12,r4
    { const uint32_t x = c.r[10]; c.pr = 0x0605DF24u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605DF24u) return; }  // 0605DF20 jsr @r10 ; extu.b r5,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0605DF24 mov.b @r8,r1
    c.r[0] = ld32(0x0605DFD4u);  // 0605DF26 mov.l 0x0605DFD4,r0
    c.r[2] = ld32(c.r[0]);  // 0605DF28 mov.l @r0,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0605DF2A extu.b r1,r1
    c.r[1] <<= 2;  // 0605DF2C shll2 r1
    c.r[1] <<= 2;  // 0605DF2E shll2 r1
    c.r[1] += c.r[2];  // 0605DF30 add r2,r1
    c.r[1] += 2;  // 0605DF32 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605DF34 mov.b @r1,r1
    c.r[13] = 0xFFFFFFFFu;  // 0605DF36 mov #-1,r13
    c.r[1] = c.r[1] & 0xFFu;  // 0605DF38 extu.b r1,r1
    c.macl = c.r[1] * c.r[9];  // 0605DF3A mul.l r9,r1
    c.r[4] = c.r[12];  // 0605DF3C mov r12,r4
    c.r[2] = ld32(c.r[11]);  // 0605DF3E mov.l @r11,r2
    c.r[1] = c.macl;  // 0605DF40 sts macl,r1
    c.r[1] += c.r[2];  // 0605DF42 add r2,r1
    c.r[1] += 15;  // 0605DF44 add #15,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605DF46 mov.b @r1,r5
    c.r[4] += 46;  // 0605DF48 add #46,r4
    { const uint32_t x = c.r[10]; c.pr = 0x0605DF4Eu; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605DF4Eu) return; }  // 0605DF4A jsr @r10 ; extu.b r5,r5
    c.r[4] = c.r[12];  // 0605DF4E mov r12,r4
    c.r[4] += 30;  // 0605DF50 add #30,r4
    c.r[8] = ld32(0x0605DFE0u);  // 0605DF52 mov.l 0x0605DFE0,r8
    c.r[6] = 0x4u;  // 0605DF54 mov #4,r6
    { const uint32_t x = c.r[8]; c.pr = 0x0605DF5Au; c.r[5] = 0x53u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605DF5Au) return; }  // 0605DF56 jsr @r8 ; mov #83,r5
    c.r[1] = c.r[0];  // 0605DF5A mov r0,r1
    c.r[1] = (uint32_t)(int32_t)(int8_t)c.r[1];  // 0605DF5C exts.b r1,r1
    c.r[0] = c.r[1];  // 0605DF5E mov r1,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0605DF60 cmp/eq #-1,r0
    if (c.t) { goto L_0605DF66; }  // 0605DF62 bt 0x0605DF66
    c.r[13] = 0x0u;  // 0605DF64 mov #0,r13
L_0605DF66:
    c.r[12] += 76;  // 0605DF66 add #76,r12
    c.r[6] = 0x4u;  // 0605DF68 mov #4,r6
    c.r[5] = 0x53u;  // 0605DF6A mov #83,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0605DF70u; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605DF70u) return; }  // 0605DF6C jsr @r8 ; mov r12,r4
    c.r[0] = (uint32_t)(int32_t)(int8_t)c.r[0];  // 0605DF70 exts.b r0,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0605DF72 cmp/eq #-1,r0
    if (c.t) { goto L_0605DF78; }  // 0605DF74 bt 0x0605DF78
    c.r[13] = 0x1u;  // 0605DF76 mov #1,r13
L_0605DF78:
    c.r[1] = 0xFFFFFFFFu;  // 0605DF78 mov #-1,r1
    c.t = (int32_t)c.r[13] > (int32_t)c.r[1];  // 0605DF7A cmp/gt r1,r13
    { const bool k = c.t; c.r[5] = 0x0u; if (k) { goto L_0605DF84; } }  // 0605DF7C bt/s 0x0605DF84 ; mov #0,r5
    goto L_0605E0EA;  // 0605DF80 bra 0x0605E0EA ; nop
L_0605DF84:
    c.r[6] = 0x0u;  // 0605DF84 mov #0,r6
    c.r[7] = 0x0u;  // 0605DF86 mov #0,r7
    c.r[0] = ld32(0x0605DFD4u);  // 0605DF88 mov.l 0x0605DFD4,r0
    c.r[4] = ld32(c.r[0]);  // 0605DF8A mov.l @r0,r4
    c.r[8] = (uint32_t)(int16_t)ld16(0x0605DFCCu);  // 0605DF8C mov.w 0x0605DFCC,r8
    c.r[3] = 0x0u;  // 0605DF8E mov #0,r3
    c.r[2] = c.r[4];  // 0605DF90 mov r4,r2
L_0605DF92:
    c.r[0] = c.r[3];  // 0605DF92 mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[4]);  // 0605DF94 mov.b @(r0,r4),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605DF96 extu.b r1,r1
    c.t = c.r[1] == c.r[8];  // 0605DF98 cmp/eq r8,r1
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_0605DFE8; } }  // 0605DF9A bt/s 0x0605DFE8 ; mov r2,r1
    c.r[1] += 7;  // 0605DF9E add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605DFA0 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0605DFA2 mov r1,r0
    c.r[0] >>= 2;  // 0605DFA4 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0605DFA6 shlr r0
    c.r[0] &= 0x1u;  // 0605DFA8 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605DFAA tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[2]; if (k) { goto L_0605DFE8; } }  // 0605DFAC bf/s 0x0605DFE8 ; mov r2,r1
    c.r[1] += 4;  // 0605DFB0 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605DFB2 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0605DFB4 mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0605DFB6 shlr r0
    c.r[0] &= 0x1u;  // 0605DFB8 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605DFBA tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[6]; if (k) { goto L_0605DFE4; } }  // 0605DFBC bt/s 0x0605DFE4 ; mov r6,r1
    c.r[1] = c.r[5];  // 0605DFC0 mov r5,r1
    c.r[1] += 1;  // 0605DFC2 add #1,r1
    c.r[5] = c.r[1] & 0xFFu; goto L_0605DFE8;  // 0605DFC4 bra 0x0605DFE8 ; extu.b r1,r5
L_0605DFE4:
    c.r[1] += 1;  // 0605DFE4 add #1,r1
    c.r[6] = c.r[1] & 0xFFu;  // 0605DFE6 extu.b r1,r6
L_0605DFE8:
    c.r[2] += 16;  // 0605DFE8 add #16,r2
    c.r[7] += 1;  // 0605DFEA add #1,r7
    c.r[1] = 0x49u;  // 0605DFEC mov #73,r1
    c.t = (int32_t)c.r[7] > (int32_t)c.r[1];  // 0605DFEE cmp/gt r1,r7
    { const bool k = !c.t; c.r[3] += 16; if (k) { SH2_POLL(c); goto L_0605DF92; } }  // 0605DFF0 bf/s 0x0605DF92 ; add #16,r3
    c.r[0] = ld32(0x0605E120u);  // 0605DFF4 mov.l 0x0605E120,r0
    c.r[1] = ld32(c.r[0]);  // 0605DFF6 mov.l @r0,r1
    c.r[11] = (uint32_t)(int16_t)ld16(0x0605E10Eu);  // 0605DFF8 mov.w 0x0605E10E,r11
    c.r[0] = c.r[1];  // 0605DFFA mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 0605DFFC mov.b @(r0,r11),r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605E110u);  // 0605DFFE mov.w 0x0605E110,r0
    c.r[1] &= c.r[0];  // 0605E000 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605E002 tst r1,r1
    { const bool k = !c.t; c.t = c.r[5] >= c.r[6]; if (k) { goto L_0605E0EA; } }  // 0605E004 bf/s 0x0605E0EA ; cmp/hs r6,r5
    { const bool k = !c.t; c.r[0] = c.r[13]; if (k) { goto L_0605E0EA; } }  // 0605E008 bf/s 0x0605E0EA ; mov r13,r0
    c.r[1] = ld32(0x0605E124u);  // 0605E00C mov.l 0x0605E124,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0605E00E mov.b @(r0,r1),r1
    c.r[12] = ld32(0x0605E128u);  // 0605E010 mov.l 0x0605E128,r12
    c.r[9] = c.r[1] & 0xFFu;  // 0605E012 extu.b r1,r9
    c.r[8] = c.r[9];  // 0605E014 mov r9,r8
    c.r[8] <<= 2;  // 0605E016 shll2 r8
    c.r[8] <<= 2;  // 0605E018 shll2 r8
    c.r[5] = c.r[8];  // 0605E01A mov r8,r5
    c.r[1] = ld32(c.r[12]);  // 0605E01C mov.l @r12,r1
    c.r[0] = c.r[8];  // 0605E01E mov r8,r0
    c.r[5] += c.r[1];  // 0605E020 add r1,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0605E022 mov.b @(r0,r1),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0605E112u);  // 0605E024 mov.w 0x0605E112,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0605E026 extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 0605E028 cmp/eq r2,r1
    { const bool k = c.t; c.r[0] = c.r[13]; if (k) { goto L_0605E0EC; } }  // 0605E02A bt/s 0x0605E0EC ; mov r13,r0
    c.r[1] = c.r[5];  // 0605E02E mov r5,r1
    c.r[1] += 7;  // 0605E030 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605E032 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0605E034 mov r1,r0
    c.r[0] >>= 2;  // 0605E036 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0605E038 shlr r0
    c.r[0] &= 0x1u;  // 0605E03A and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605E03C tst r0,r0
    { const bool k = !c.t; c.r[1] = 0x2Eu; if (k) { goto L_0605E0EA; } }  // 0605E03E bf/s 0x0605E0EA ; mov #46,r1
    c.macl = c.r[13] * c.r[1];  // 0605E042 mul.l r1,r13
    c.r[10] = (uint32_t)(int16_t)ld16(0x0605E114u);  // 0605E044 mov.w 0x0605E114,r10
    c.r[10] += c.r[14];  // 0605E046 add r14,r10
    c.r[1] = c.macl;  // 0605E048 sts macl,r1
    c.r[10] += c.r[1];  // 0605E04A add r1,r10
    c.r[1] = c.r[10];  // 0605E04C mov r10,r1
    c.r[1] += 10;  // 0605E04E add #10,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0605E050 mov.w @r1,r1
    c.r[2] = 0xFu;  // 0605E052 mov #15,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 0605E054 extu.w r1,r1
    c.t = c.r[1] > c.r[2];  // 0605E056 cmp/hi r2,r1
    { const bool k = c.t; c.r[0] = c.r[13]; if (k) { goto L_0605E0EC; } }  // 0605E058 bt/s 0x0605E0EC ; mov r13,r0
    c.r[5] += 2;  // 0605E05C add #2,r5
    c.r[1] = ld32(0x0605E12Cu);  // 0605E05E mov.l 0x0605E12C,r1
    c.r[6] = c.r[9];  // 0605E060 mov r9,r6
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[5]);  // 0605E062 mov.b @r5,r5
    c.r[4] = c.r[14];  // 0605E064 mov r14,r4
    { const uint32_t x = c.r[1]; c.pr = 0x0605E06Au; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605E06Au) return; }  // 0605E066 jsr @r1 ; extu.b r5,r5
    c.r[4] = c.r[14];  // 0605E06A mov r14,r4
    c.r[4] += 26;  // 0605E06C add #26,r4
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[4]);  // 0605E06E mov.w @r4,r2
    c.r[1] = ld32(0x0605E130u);  // 0605E070 mov.l 0x0605E130,r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 0605E072 extu.w r2,r2
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[2] * (int32_t)c.r[1]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 0605E074 dmuls.l r1,r2
    c.r[3] = c.mach;  // 0605E076 sts mach,r3
    c.t = c.r[3] & 1; c.r[3] = (uint32_t)((int32_t)c.r[3] >> 1);  // 0605E078 shar r3
    c.t = c.r[2] >> 31; c.r[2] <<= 1;  // 0605E07A shll r2
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 0605E07C subc r2,r2
    c.r[1] = c.r[14];  // 0605E07E mov r14,r1
    c.r[1] += 22;  // 0605E080 add #22,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0605E082 mov.w @r1,r1
    c.r[3] -= c.r[2];  // 0605E084 sub r2,r3
    c.r[1] = c.r[1] & 0xFFFFu;  // 0605E086 extu.w r1,r1
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[1];  // 0605E088 cmp/ge r1,r3
    if (!c.t) { goto L_0605E0EA; }  // 0605E08A bf 0x0605E0EA
    c.r[5] = ld32(c.r[12]);  // 0605E08C mov.l @r12,r5
    c.r[1] = ld32(0x0605E134u);  // 0605E08E mov.l 0x0605E134,r1
    c.r[5] += c.r[8];  // 0605E090 add r8,r5
    c.r[5] += 2;  // 0605E092 add #2,r5
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[5]);  // 0605E094 mov.b @r5,r2
    c.r[7] = 0x1Eu;  // 0605E096 mov #30,r7
    c.r[2] = c.r[2] & 0xFFu;  // 0605E098 extu.b r2,r2
    c.macl = c.r[2] * c.r[7];  // 0605E09A mul.l r7,r2
    c.r[6] = ld32(c.r[1]);  // 0605E09C mov.l @r1,r6
    c.r[10] += 12;  // 0605E09E add #12,r10
    c.r[1] = c.macl;  // 0605E0A0 sts macl,r1
    c.r[1] += c.r[6];  // 0605E0A2 add r6,r1
    c.r[1] += 15;  // 0605E0A4 add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605E0A6 mov.b @r1,r1
    c.r[2] = ld32(0x0605E138u);  // 0605E0A8 mov.l 0x0605E138,r2
    c.r[2] = ld32(c.r[2]);  // 0605E0AA mov.l @r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0605E0AC extu.b r1,r1
    c.r[3] = c.r[1];  // 0605E0AE mov r1,r3
    c.r[3] += c.r[3];  // 0605E0B0 add r3,r3
    c.r[3] += c.r[1];  // 0605E0B2 add r1,r3
    c.r[3] <<= 2;  // 0605E0B4 shll2 r3
    c.r[3] += c.r[2];  // 0605E0B6 add r2,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[10]);  // 0605E0B8 mov.w @r10,r1
    c.r[3] += 10;  // 0605E0BA add #10,r3
    st16(c.r[3], c.r[1]);  // 0605E0BC mov.w r1,@r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[5]);  // 0605E0BE mov.b @r5,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605E0C0 extu.b r1,r1
    c.macl = c.r[1] * c.r[7];  // 0605E0C2 mul.l r7,r1
    c.r[0] = ld32(0x0605E120u);  // 0605E0C4 mov.l 0x0605E120,r0
    c.r[5] = (uint32_t)(int16_t)ld16(0x0605E116u);  // 0605E0C6 mov.w 0x0605E116,r5
    c.r[2] = c.macl;  // 0605E0C8 sts macl,r2
    c.r[2] += c.r[6];  // 0605E0CA add r6,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[4]);  // 0605E0CC mov.w @r4,r1
    c.r[2] += 22;  // 0605E0CE add #22,r2
    st16(c.r[2], c.r[1]);  // 0605E0D0 mov.w r1,@r2
    c.r[1] = ld32(c.r[0]);  // 0605E0D2 mov.l @r0,r1
    c.r[6] = 0x0u;  // 0605E0D4 mov #0,r6
    c.r[0] = c.r[1];  // 0605E0D6 mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 0605E0D8 mov.b @(r0,r11),r2
    c.r[4] = (uint32_t)(int32_t)(int16_t)c.r[9];  // 0605E0DA exts.w r9,r4
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605E110u);  // 0605E0DC mov.w 0x0605E110,r0
    c.r[2] |= c.r[0];  // 0605E0DE or r0,r2
    c.r[0] = c.r[1];  // 0605E0E0 mov r1,r0
    c.r[1] = ld32(0x0605E13Cu);  // 0605E0E2 mov.l 0x0605E13C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0605E0E8u; st8(c.r[0] + c.r[11], c.r[2]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605E0E8u) return; }  // 0605E0E4 jsr @r1 ; mov.b r2,@(r0,r11)
    c.r[13] = 0xFFFFFFF6u;  // 0605E0E8 mov #-10,r13
L_0605E0EA:
    c.r[0] = c.r[13];  // 0605E0EA mov r13,r0
L_0605E0EC:
    c.t = c.r[0] == 0xFFFFFFF6u;  // 0605E0EC cmp/eq #-10,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605E118u);  // 0605E0EE mov.w 0x0605E118,r1
    if (!c.t) { goto L_0605E0F4; }  // 0605E0F0 bf 0x0605E0F4
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605E11Au);  // 0605E0F2 mov.w 0x0605E11A,r1
L_0605E0F4:
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605E11Cu);  // 0605E0F4 mov.w 0x0605E11C,r3
    c.r[14] += c.r[3];  // 0605E0F6 add r3,r14
    c.r[15] = c.r[14];  // 0605E0F8 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0605E0FA lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0605E0FC mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0605E0FE mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0605E100 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0605E102 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0605E104 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0605E106 mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0605E108 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.r[0] = c.r[1]; c.pc = x; return; }  // 0605E10A rts ; mov r1,r0
}

void f_0605E140(SH2Context& c) {
    ran[1446] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0605E140 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0605E142 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0605E144 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0605E146 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0605E148 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0605E14A mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605E14C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0605E14E sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605E29Au);  // 0605E150 mov.w 0x0605E29A,r3
    c.r[15] += c.r[3];  // 0605E152 add r3,r15
    c.r[14] = c.r[15];  // 0605E154 mov r15,r14
    c.r[11] = (uint32_t)(int16_t)ld16(0x0605E29Cu);  // 0605E156 mov.w 0x0605E29C,r11
    c.r[7] = 0x0u;  // 0605E158 mov #0,r7
    c.r[1] = ld32(0x0605E2A8u);  // 0605E15A mov.l 0x0605E2A8,r1
    c.r[4] = ld32(c.r[1]);  // 0605E15C mov.l @r1,r4
    c.r[9] = c.r[11];  // 0605E15E mov r11,r9
    c.r[8] = (uint32_t)(int16_t)ld16(0x0605E29Eu);  // 0605E160 mov.w 0x0605E29E,r8
    c.r[5] = 0x0u;  // 0605E162 mov #0,r5
    c.r[6] = c.r[4];  // 0605E164 mov r4,r6
L_0605E166:
    c.r[0] = c.r[5];  // 0605E166 mov r5,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[4]);  // 0605E168 mov.b @(r0,r4),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605E16A extu.b r1,r1
    c.t = c.r[1] == c.r[9];  // 0605E16C cmp/eq r9,r1
    { const bool k = c.t; c.r[1] = c.r[6]; if (k) { goto L_0605E1AE; } }  // 0605E16E bt/s 0x0605E1AE ; mov r6,r1
    c.r[1] += 7;  // 0605E172 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605E174 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0605E176 mov r1,r0
    c.r[0] >>= 2;  // 0605E178 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0605E17A shlr r0
    c.r[0] &= 0x1u;  // 0605E17C and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605E17E tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[6]; if (k) { goto L_0605E1AE; } }  // 0605E180 bf/s 0x0605E1AE ; mov r6,r1
    c.r[1] += 2;  // 0605E184 add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605E186 mov.b @r1,r2
    c.r[1] = ld32(0x0605E2ACu);  // 0605E188 mov.l 0x0605E2AC,r1
    c.r[3] = ld32(c.r[1]);  // 0605E18A mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0605E18C extu.b r2,r2
    c.r[1] = 0x1Eu;  // 0605E18E mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 0605E190 mul.l r1,r2
    c.r[0] = c.macl;  // 0605E192 sts macl,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 0605E194 mov.w @(r0,r3),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0605E196 extu.w r1,r1
    c.t = c.r[1] == c.r[8];  // 0605E198 cmp/eq r8,r1
    { const bool k = !c.t; c.r[1] = c.r[6]; if (k) { goto L_0605E1AE; } }  // 0605E19A bf/s 0x0605E1AE ; mov r6,r1
    c.r[1] += 3;  // 0605E19E add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605E1A0 mov.b @r1,r1
    c.r[0] = c.r[1];  // 0605E1A2 mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0605E1A4 shlr r0
    c.r[0] &= 0x3u;  // 0605E1A6 and #3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605E1A8 tst r0,r0
    { const bool k = c.t; c.r[0] = c.r[7]; if (k) { goto L_0605E1BC; } }  // 0605E1AA bt/s 0x0605E1BC ; mov r7,r0
L_0605E1AE:
    c.r[6] += 16;  // 0605E1AE add #16,r6
    c.r[7] += 1;  // 0605E1B0 add #1,r7
    c.r[1] = 0x49u;  // 0605E1B2 mov #73,r1
    c.t = (int32_t)c.r[7] > (int32_t)c.r[1];  // 0605E1B4 cmp/gt r1,r7
    { const bool k = !c.t; c.r[5] += 16; if (k) { SH2_POLL(c); goto L_0605E166; } }  // 0605E1B6 bf/s 0x0605E166 ; add #16,r5
    c.r[0] = c.r[7];  // 0605E1BA mov r7,r0
L_0605E1BC:
    c.t = c.r[0] == 0x4Au;  // 0605E1BC cmp/eq #74,r0
    if (!c.t) { goto L_0605E1C4; }  // 0605E1BE bf 0x0605E1C4
    goto L_0605E3B4;  // 0605E1C0 bra 0x0605E3B4 ; nop
L_0605E1C4:
    c.r[11] = c.r[7] & 0xFFu;  // 0605E1C4 extu.b r7,r11
    c.r[12] = ld32(0x0605E2A8u);  // 0605E1C6 mov.l 0x0605E2A8,r12
    c.r[9] = c.r[11];  // 0605E1C8 mov r11,r9
    c.r[9] <<= 2;  // 0605E1CA shll2 r9
    c.r[9] <<= 2;  // 0605E1CC shll2 r9
    c.r[1] = ld32(c.r[12]);  // 0605E1CE mov.l @r12,r1
    c.r[10] = 0x1Eu;  // 0605E1D0 mov #30,r10
    c.r[1] += c.r[9];  // 0605E1D2 add r9,r1
    c.r[1] += 2;  // 0605E1D4 add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605E1D6 mov.b @r1,r2
    c.r[8] = (uint32_t)(int16_t)ld16(0x0605E2A0u);  // 0605E1D8 mov.w 0x0605E2A0,r8
    c.r[2] = c.r[2] & 0xFFu;  // 0605E1DA extu.b r2,r2
    c.r[1] = ld32(0x0605E2ACu);  // 0605E1DC mov.l 0x0605E2AC,r1
    c.macl = c.r[2] * c.r[10];  // 0605E1DE mul.l r10,r2
    c.r[3] = ld32(c.r[1]);  // 0605E1E0 mov.l @r1,r3
    c.r[8] += c.r[14];  // 0605E1E2 add r14,r8
    c.r[1] = c.macl;  // 0605E1E4 sts macl,r1
    c.r[1] += c.r[3];  // 0605E1E6 add r3,r1
    c.r[1] += 15;  // 0605E1E8 add #15,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605E1EA mov.b @r1,r5
    c.r[4] = c.r[8];  // 0605E1EC mov r8,r4
    c.r[1] = ld32(0x0605E2B0u);  // 0605E1EE mov.l 0x0605E2B0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0605E1F4u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605E1F4u) return; }  // 0605E1F0 jsr @r1 ; extu.b r5,r5
    c.r[4] = c.r[8];  // 0605E1F4 mov r8,r4
    c.r[4] += 30;  // 0605E1F6 add #30,r4
    c.r[0] = ld32(0x0605E2B4u);  // 0605E1F8 mov.l 0x0605E2B4,r0
    c.r[6] = 0x4u;  // 0605E1FA mov #4,r6
    { const uint32_t x = c.r[0]; c.pr = 0x0605E200u; c.r[5] = 0x4Fu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605E200u) return; }  // 0605E1FC jsr @r0 ; mov #79,r5
    c.r[0] = (uint32_t)(int32_t)(int8_t)c.r[0];  // 0605E200 exts.b r0,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0605E202 cmp/eq #-1,r0
    { const bool k = !c.t; c.r[8] += 9; if (k) { goto L_0605E20C; } }  // 0605E204 bf/s 0x0605E20C ; add #9,r8
    goto L_0605E3B4;  // 0605E208 bra 0x0605E3B4 ; nop
L_0605E20C:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0605E20C mov.b @r8,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0605E2A2u);  // 0605E20E mov.w 0x0605E2A2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0605E210 extu.b r1,r1
    c.t = c.r[1] > c.r[2];  // 0605E212 cmp/hi r2,r1
    if (c.t) { goto L_0605E21A; }  // 0605E214 bt 0x0605E21A
    goto L_0605E3B4;  // 0605E216 bra 0x0605E3B4 ; nop
L_0605E21A:
    c.r[13] = ld32(0x0605E2B8u);  // 0605E21A mov.l 0x0605E2B8,r13
    { const uint32_t x = c.r[13]; c.pr = 0x0605E220u; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605E220u) return; }  // 0605E21C jsr @r13 ; mov r11,r4
    c.r[1] = c.r[0];  // 0605E220 mov r0,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605E222 extu.b r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605E2A4u);  // 0605E224 mov.w 0x0605E2A4,r0
    st32(c.r[0] + c.r[14], c.r[1]);  // 0605E226 mov.l r1,@(r0,r14)
    c.r[1] = ld32(c.r[12]);  // 0605E228 mov.l @r12,r1
    c.r[7] = 0x5u;  // 0605E22A mov #5,r7
    c.r[9] += c.r[1];  // 0605E22C add r1,r9
    c.r[9] += 2;  // 0605E22E add #2,r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0605E230 mov.b @r9,r1
    c.r[5] = c.r[10];  // 0605E232 mov r10,r5
    c.r[12] = c.r[1] & 0xFFu;  // 0605E234 extu.b r1,r12
L_0605E236:
    c.r[1] = ld32(0x0605E2ACu);  // 0605E236 mov.l 0x0605E2AC,r1
    c.r[2] = c.r[11];  // 0605E238 mov r11,r2
    c.r[3] = ld32(c.r[1]);  // 0605E23A mov.l @r1,r3
    c.macl = c.r[12] * c.r[5];  // 0605E23C mul.l r5,r12
    c.r[1] = c.r[7];  // 0605E23E mov r7,r1
    c.t = c.r[1] >> 31; c.r[1] = c.r[1] << 1 | c.t;  // 0605E240 rotl r1
    c.r[1] = c.t;  // 0605E242 movt r1
    c.r[1] += c.r[7];  // 0605E244 add r7,r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0605E246 shar r1
    c.r[6] = c.macl;  // 0605E248 sts macl,r6
    c.r[6] += c.r[3];  // 0605E24A add r3,r6
    c.r[6] += c.r[1];  // 0605E24C add r1,r6
    c.r[1] = ld32(0x0605E2A8u);  // 0605E24E mov.l 0x0605E2A8,r1
    c.r[1] = ld32(c.r[1]);  // 0605E250 mov.l @r1,r1
    c.r[2] <<= 2;  // 0605E252 shll2 r2
    c.r[2] <<= 2;  // 0605E254 shll2 r2
    c.r[2] += c.r[1];  // 0605E256 add r1,r2
    c.r[2] += 2;  // 0605E258 add #2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605E25A mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605E25C extu.b r1,r1
    c.macl = c.r[1] * c.r[5];  // 0605E25E mul.l r5,r1
    c.r[1] = c.macl;  // 0605E260 sts macl,r1
    c.r[1] += c.r[3];  // 0605E262 add r3,r1
    c.r[1] += 15;  // 0605E264 add #15,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605E266 mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0605E268 extu.b r2,r2
    c.r[1] = ld32(0x0605E2BCu);  // 0605E26A mov.l 0x0605E2BC,r1
    c.r[3] = c.r[2];  // 0605E26C mov r2,r3
    c.r[3] += c.r[3];  // 0605E26E add r3,r3
    c.r[3] += c.r[2];  // 0605E270 add r2,r3
    c.r[1] = ld32(c.r[1]);  // 0605E272 mov.l @r1,r1
    c.r[3] <<= 2;  // 0605E274 shll2 r3
    c.r[3] += c.r[1];  // 0605E276 add r1,r3
    c.r[3] += 2;  // 0605E278 add #2,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0605E27A mov.b @r3,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0605E27C extu.b r1,r0
    c.r[1] = ld32(0x0605E2C0u);  // 0605E27E mov.l 0x0605E2C0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0605E280 mov.b @(r0,r1),r1
    c.r[6] += 7;  // 0605E282 add #7,r6
    c.r[2] = c.r[1] & 0xFFu;  // 0605E284 extu.b r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0605E286 mov.b @r6,r1
    c.r[3] = c.r[1] & 0xFFu;  // 0605E288 extu.b r1,r3
    c.r[1] = 0x1u;  // 0605E28A mov #1,r1
    c.r[1] &= c.r[7];  // 0605E28C and r7,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605E28E tst r1,r1
    { const bool k = c.t; c.r[0] = 0xFu; if (k) { goto L_0605E2C4; } }  // 0605E290 bt/s 0x0605E2C4 ; mov #15,r0
    c.r[13] = (uint32_t)(int16_t)ld16(0x0605E2A6u);  // 0605E294 mov.w 0x0605E2A6,r13
    c.r[3] &= c.r[13]; goto L_0605E2C6;  // 0605E296 bra 0x0605E2C6 ; and r13,r3
L_0605E2C4:
    c.r[3] &= c.r[0];  // 0605E2C4 and r0,r3
L_0605E2C6:
    c.r[1] = 0x1u;  // 0605E2C6 mov #1,r1
    c.r[1] &= c.r[7];  // 0605E2C8 and r7,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605E2CA tst r1,r1
    if (!c.t) { goto L_0605E2D2; }  // 0605E2CC bf 0x0605E2D2
    c.r[2] <<= 2;  // 0605E2CE shll2 r2
    c.r[2] <<= 2;  // 0605E2D0 shll2 r2
L_0605E2D2:
    c.r[3] |= c.r[2];  // 0605E2D2 or r2,r3
    c.r[7] += 1;  // 0605E2D4 add #1,r7
    c.r[1] = 0x9u;  // 0605E2D6 mov #9,r1
    c.t = (int32_t)c.r[7] > (int32_t)c.r[1];  // 0605E2D8 cmp/gt r1,r7
    { const bool k = !c.t; st8(c.r[6], c.r[3]); if (k) { SH2_POLL(c); goto L_0605E236; } }  // 0605E2DA bf/s 0x0605E236 ; mov.b r3,@r6
    c.r[8] = ld32(0x0605E3E4u);  // 0605E2DE mov.l 0x0605E3E4,r8
    c.r[6] = c.r[11];  // 0605E2E0 mov r11,r6
    c.r[5] = c.r[12];  // 0605E2E2 mov r12,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0605E2E8u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605E2E8u) return; }  // 0605E2E4 jsr @r8 ; mov r14,r4
    c.r[13] = ld32(0x0605E3E8u);  // 0605E2E8 mov.l 0x0605E3E8,r13
    c.r[1] = 0x1Eu;  // 0605E2EA mov #30,r1
    c.r[10] = (uint32_t)(int16_t)ld16(0x0605E3D8u);  // 0605E2EC mov.w 0x0605E3D8,r10
    c.r[10] += c.r[14];  // 0605E2EE add r14,r10
    c.r[6] = c.r[11];  // 0605E2F0 mov r11,r6
    c.r[5] = c.r[12];  // 0605E2F2 mov r12,r5
    c.macl = c.r[12] * c.r[1];  // 0605E2F4 mul.l r1,r12
    c.r[4] = c.r[10];  // 0605E2F6 mov r10,r4
    c.r[3] = ld32(c.r[13]);  // 0605E2F8 mov.l @r13,r3
    c.r[2] = c.macl;  // 0605E2FA sts macl,r2
    c.r[2] += c.r[3];  // 0605E2FC add r3,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0605E2FE mov.w @r2,r1
    c.r[9] = c.macl;  // 0605E300 sts macl,r9
    c.r[1] += 1;  // 0605E302 add #1,r1
    { const uint32_t x = c.r[8]; c.pr = 0x0605E308u; st16(c.r[2], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605E308u) return; }  // 0605E304 jsr @r8 ; mov.w r1,@r2
    c.r[1] = c.r[10];  // 0605E308 mov r10,r1
    c.r[7] = ld32(c.r[13]);  // 0605E30A mov.l @r13,r7
    c.r[1] += 26;  // 0605E30C add #26,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0605E30E mov.w @r1,r1
    c.r[7] += c.r[9];  // 0605E310 add r9,r7
    c.r[7] += 22;  // 0605E312 add #22,r7
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[7]);  // 0605E314 mov.w @r7,r2
    c.macl = (c.r[2] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 0605E316 mulu.w r1,r2
    c.r[6] = ld32(0x0605E3ECu);  // 0605E318 mov.l 0x0605E3EC,r6
    c.r[1] = c.r[14];  // 0605E31A mov r14,r1
    c.r[1] += 26;  // 0605E31C add #26,r1
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0605E31E mov.w @r1,r5
    c.r[4] = c.macl;  // 0605E320 sts macl,r4
    c.macl = c.r[9];  // 0605E322 lds r9,macl
    { const uint32_t x = c.r[6]; c.pr = 0x0605E328u; c.r[5] = c.r[5] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605E328u) return; }  // 0605E324 jsr @r6 ; extu.w r5,r5
    c.r[5] = c.r[0];  // 0605E328 mov r0,r5
    c.r[1] = c.r[5] & 0xFFFFu;  // 0605E32A extu.w r5,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605E32C tst r1,r1
    { const bool k = !c.t; st16(c.r[7], c.r[5]); if (k) { goto L_0605E336; } }  // 0605E32E bf/s 0x0605E336 ; mov.w r5,@r7
    c.r[1] = 0x1u;  // 0605E332 mov #1,r1
    st16(c.r[7], c.r[1]);  // 0605E334 mov.w r1,@r7
L_0605E336:
    c.r[13] = ld32(0x0605E3E8u);  // 0605E336 mov.l 0x0605E3E8,r13
    c.r[1] = ld32(c.r[13]);  // 0605E338 mov.l @r13,r1
    c.r[7] = c.macl;  // 0605E33A sts macl,r7
    c.r[7] += c.r[1];  // 0605E33C add r1,r7
    c.r[7] += 24;  // 0605E33E add #24,r7
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[7]);  // 0605E340 mov.w @r7,r2
    c.r[10] += 28;  // 0605E342 add #28,r10
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[10]);  // 0605E344 mov.w @r10,r1
    c.macl = (c.r[2] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 0605E346 mulu.w r1,r2
    c.r[1] = c.r[14];  // 0605E348 mov r14,r1
    c.r[1] += 28;  // 0605E34A add #28,r1
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0605E34C mov.w @r1,r5
    c.r[4] = c.macl;  // 0605E34E sts macl,r4
    { const uint32_t x = c.r[6]; c.pr = 0x0605E354u; c.r[5] = c.r[5] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605E354u) return; }  // 0605E350 jsr @r6 ; extu.w r5,r5
    c.r[6] = c.r[0];  // 0605E354 mov r0,r6
    st16(c.r[7], c.r[6]);  // 0605E356 mov.w r6,@r7
    c.r[4] = (uint32_t)(int32_t)(int16_t)c.r[11];  // 0605E358 exts.w r11,r4
    c.r[1] = ld32(0x0605E3F0u);  // 0605E35A mov.l 0x0605E3F0,r1
    c.r[6] = 0x0u;  // 0605E35C mov #0,r6
    { const uint32_t x = c.r[1]; c.pr = 0x0605E362u; c.r[5] = 0x79u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605E362u) return; }  // 0605E35E jsr @r1 ; mov #121,r5
    c.r[13] = (uint32_t)(int16_t)ld16(0x0605E3DAu);  // 0605E362 mov.w 0x0605E3DA,r13
    c.r[13] += c.r[14];  // 0605E364 add r14,r13
    c.r[13] = ld32(c.r[13]);  // 0605E366 mov.l @r13,r13
    c.t = (c.r[13] & c.r[13]) == 0;  // 0605E368 tst r13,r13
    if (!c.t) { goto L_0605E3B4; }  // 0605E36A bf 0x0605E3B4
    c.r[0] = ld32(0x0605E3F4u);  // 0605E36C mov.l 0x0605E3F4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0605E372u; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605E372u) return; }  // 0605E36E jsr @r0 ; mov r11,r4
    c.r[1] = c.r[0] & 0xFFu;  // 0605E372 extu.b r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605E374 tst r1,r1
    { const bool k = c.t; c.r[8] = c.r[11]; if (k) { goto L_0605E3B4; } }  // 0605E376 bt/s 0x0605E3B4 ; mov r11,r8
    c.r[9] = ld32(0x0605E3F8u);  // 0605E37A mov.l 0x0605E3F8,r9
    c.r[2] = ld32(c.r[9]);  // 0605E37C mov.l @r9,r2
    c.r[8] <<= 2;  // 0605E37E shll2 r8
    c.r[8] <<= 2;  // 0605E380 shll2 r8
    c.r[2] += c.r[8];  // 0605E382 add r8,r2
    c.r[2] += 7;  // 0605E384 add #7,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605E386 mov.b @r2,r1
    c.r[0] = c.r[1];  // 0605E388 mov r1,r0
    c.r[0] >>= 2;  // 0605E38A shlr2 r0
    c.r[0] >>= 2;  // 0605E38C shlr2 r0
    c.r[0] &= 0x1u;  // 0605E38E and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605E390 tst r0,r0
    { const bool k = !c.t; c.r[0] = c.r[1]; if (k) { goto L_0605E39C; } }  // 0605E392 bf/s 0x0605E39C ; mov r1,r0
    c.r[0] |= 0x20u;  // 0605E396 or #32,r0
    st8(c.r[2], c.r[0]); goto L_0605E3B4;  // 0605E398 bra 0x0605E3B4 ; mov.b r0,@r2
L_0605E39C:
    c.r[0] &= 0xEFu;  // 0605E39C and #239,r0
    st8(c.r[2], c.r[0]);  // 0605E39E mov.b r0,@r2
    c.r[1] = ld32(0x0605E3FCu);  // 0605E3A0 mov.l 0x0605E3FC,r1
    c.r[5] = 0x1u;  // 0605E3A2 mov #1,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0605E3A8u; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605E3A8u) return; }  // 0605E3A4 jsr @r1 ; mov r11,r4
    c.r[1] = ld32(c.r[9]);  // 0605E3A8 mov.l @r9,r1
    c.r[1] += c.r[8];  // 0605E3AA add r8,r1
    c.r[1] += 3;  // 0605E3AC add #3,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605E3AE mov.b @r1,r0
    c.r[0] |= 0x20u;  // 0605E3B0 or #32,r0
    st8(c.r[1], c.r[0]);  // 0605E3B2 mov.b r0,@r1
L_0605E3B4:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605E3DCu);  // 0605E3B4 mov.w 0x0605E3DC,r1
    c.t = c.r[11] == c.r[1];  // 0605E3B6 cmp/eq r1,r11
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605E3DEu);  // 0605E3B8 mov.w 0x0605E3DE,r1
    if (c.t) { goto L_0605E3BE; }  // 0605E3BA bt 0x0605E3BE
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605E3E0u);  // 0605E3BC mov.w 0x0605E3E0,r1
L_0605E3BE:
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605E3E2u);  // 0605E3BE mov.w 0x0605E3E2,r3
    c.r[14] += c.r[3];  // 0605E3C0 add r3,r14
    c.r[15] = c.r[14];  // 0605E3C2 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0605E3C4 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0605E3C6 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0605E3C8 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0605E3CA mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0605E3CC mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0605E3CE mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0605E3D0 mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0605E3D2 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.r[0] = c.r[1]; c.pc = x; return; }  // 0605E3D4 rts ; mov r1,r0
}

void f_0605E400(SH2Context& c) {
    ran[1447] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605E400 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0605E402 sts.l pr,@-r15
    c.r[1] = ld32(0x0605E420u);  // 0605E404 mov.l 0x0605E420,r1
    c.r[1] = ld32(c.r[1]);  // 0605E406 mov.l @r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605E408 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0605E40A extu.b r1,r0
    c.r[0] <<= 2;  // 0605E40C shll2 r0
    c.r[1] = ld32(0x0605E424u);  // 0605E40E mov.l 0x0605E424,r1
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 0605E410 mov.l @(r0,r1),r0
    { const uint32_t x = c.r[0]; c.pr = 0x0605E416u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605E416u) return; }  // 0605E412 jsr @r0 ; mov r15,r14
    c.r[15] = c.r[14];  // 0605E416 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0605E418 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0605E41A mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[0] & 0xFFFFu; c.pc = x; return; }  // 0605E41C rts ; extu.w r0,r0
}

void f_0605E428(SH2Context& c) {
    ran[1448] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0605E428 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0605E42A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605E42C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0605E42E sts.l pr,@-r15
    c.r[15] -= 16;  // 0605E430 add #-16,r15
    c.r[3] = ld32(0x0605E5CCu);  // 0605E432 mov.l 0x0605E5CC,r3
    c.r[1] = ld32(c.r[3]);  // 0605E434 mov.l @r3,r1
    c.r[9] = ld32(0x0605E5D0u);  // 0605E436 mov.l 0x0605E5D0,r9
    c.r[1] += 1;  // 0605E438 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605E43A mov.b @r1,r1
    c.r[8] = ld32(0x0605E5D4u);  // 0605E43C mov.l 0x0605E5D4,r8
    c.r[0] = c.r[1] & 0xFFu;  // 0605E43E extu.b r1,r0
    c.t = c.r[0] == 0x8u;  // 0605E440 cmp/eq #8,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0605E44C; } }  // 0605E442 bt/s 0x0605E44C ; mov r15,r14
    c.r[2] = ld32(0x0605E5D8u);  // 0605E446 mov.l 0x0605E5D8,r2
    c.r[1] = 0x0u;  // 0605E448 mov #0,r1
    st8(c.r[2], c.r[1]);  // 0605E44A mov.b r1,@r2
L_0605E44C:
    c.r[1] = ld32(c.r[3]);  // 0605E44C mov.l @r3,r1
    c.r[1] += 1;  // 0605E44E add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605E450 mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0605E452 extu.b r1,r2
    c.r[1] = 0x9u;  // 0605E454 mov #9,r1
    c.t = c.r[2] > c.r[1];  // 0605E456 cmp/hi r1,r2
    { const bool k = !c.t; c.r[1] = c.r[2]; if (k) { goto L_0605E460; } }  // 0605E458 bf/s 0x0605E460 ; mov r2,r1
    goto L_0605E644;  // 0605E45C bra 0x0605E644 ; nop
L_0605E460:
    c.r[1] += c.r[1];  // 0605E460 add r1,r1
    c.r[0] = 0x0605E46Cu;  // 0605E462 mova 0x0605E46C,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0605E464 mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 0605E466 add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x0605E480u: goto L_0605E480; case 0x0605E48Au: goto L_0605E48A; case 0x0605E496u: goto L_0605E496; case 0x0605E4E0u: goto L_0605E4E0; case 0x0605E504u: goto L_0605E504; case 0x0605E50Au: goto L_0605E50A; case 0x0605E510u: goto L_0605E510; case 0x0605E608u: goto L_0605E608; case 0x0605E62Eu: goto L_0605E62E; case 0x0605E638u: goto L_0605E638; default: sh2_call(c, x); return; } }  // 0605E468 jmp @r0 ; nop
L_0605E480:
    c.r[2] = ld32(0x0605E5DCu);  // 0605E480 mov.l 0x0605E5DC,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605E482 mov.b @r2,r2
    c.r[1] = ld32(0x0605E5E0u);  // 0605E484 mov.l 0x0605E5E0,r1
    st8(c.r[1], c.r[2]); goto L_0605E64A;  // 0605E486 bra 0x0605E64A ; mov.b r2,@r1
L_0605E48A:
    c.r[1] = ld32(0x0605E5E4u);  // 0605E48A mov.l 0x0605E5E4,r1
    c.r[1] = ld32(c.r[1]);  // 0605E48C mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605E5B4u);  // 0605E48E mov.w 0x0605E5B4,r0
    c.r[2] = ld32(0x0605E5E0u);  // 0605E490 mov.l 0x0605E5E0,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]); goto L_0605E648;  // 0605E492 bra 0x0605E648 ; mov.b @(r0,r1),r1
L_0605E496:
    c.r[1] = ld32(0x0605E5E8u);  // 0605E496 mov.l 0x0605E5E8,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605E498 mov.b @r1,r4
    c.r[5] = c.r[14];  // 0605E49A mov r14,r5
    c.r[1] = ld32(0x0605E5ECu);  // 0605E49C mov.l 0x0605E5EC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0605E4A2u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605E4A2u) return; }  // 0605E49E jsr @r1 ; extu.b r4,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[14]);  // 0605E4A2 mov.b @r14,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0605E5B6u);  // 0605E4A4 mov.w 0x0605E5B6,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0605E4A6 extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 0605E4A8 cmp/eq r2,r1
    { const bool k = !c.t; c.r[1] = 0x1u; if (k) { goto L_0605E4B4; } }  // 0605E4AA bf/s 0x0605E4B4 ; mov #1,r1
    c.r[2] = ld32(0x0605E5E0u);  // 0605E4AE mov.l 0x0605E5E0,r2
    st8(c.r[2], c.r[1]); goto L_0605E4D6;  // 0605E4B0 bra 0x0605E4D6 ; mov.b r1,@r2
L_0605E4B4:
    c.r[2] = ld32(0x0605E5E0u);  // 0605E4B4 mov.l 0x0605E5E0,r2
    c.r[1] = 0x0u;  // 0605E4B6 mov #0,r1
    st8(c.r[2], c.r[1]);  // 0605E4B8 mov.b r1,@r2
    c.r[6] = 0x4u;  // 0605E4BA mov #4,r6
    c.r[7] = (uint32_t)(int16_t)ld16(0x0605E5B8u);  // 0605E4BC mov.w 0x0605E5B8,r7
L_0605E4BE:
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605E4BE mov.b @r2,r3
    c.r[0] = c.r[3] & 0xFFu;  // 0605E4C0 extu.b r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 0605E4C2 mov.b @(r0,r14),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605E4C4 extu.b r1,r1
    c.t = c.r[1] == c.r[7];  // 0605E4C6 cmp/eq r7,r1
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_0605E4D6; } }  // 0605E4C8 bt/s 0x0605E4D6 ; mov r3,r1
    c.r[1] += 1;  // 0605E4CC add #1,r1
    st8(c.r[2], c.r[1]);  // 0605E4CE mov.b r1,@r2
    c.r[1] = c.r[1] & 0xFFu;  // 0605E4D0 extu.b r1,r1
    c.t = c.r[1] > c.r[6];  // 0605E4D2 cmp/hi r6,r1
    if (!c.t) { SH2_POLL(c); goto L_0605E4BE; }  // 0605E4D4 bf 0x0605E4BE
L_0605E4D6:
    c.r[2] = ld32(0x0605E5E8u);  // 0605E4D6 mov.l 0x0605E5E8,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605E4D8 mov.b @r2,r2
    c.r[1] = ld32(0x0605E5F0u);  // 0605E4DA mov.l 0x0605E5F0,r1
    st8(c.r[1], c.r[2]); goto L_0605E64A;  // 0605E4DC bra 0x0605E64A ; mov.b r2,@r1
L_0605E4E0:
    c.r[2] = ld32(0x0605E5E0u);  // 0605E4E0 mov.l 0x0605E5E0,r2
    c.r[1] = 0x8u;  // 0605E4E2 mov #8,r1
    st8(c.r[2], c.r[1]);  // 0605E4E4 mov.b r1,@r2
    c.r[1] = ld32(0x0605E5F4u);  // 0605E4E6 mov.l 0x0605E5F4,r1
    c.r[1] = ld32(c.r[1]);  // 0605E4E8 mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605E5BAu);  // 0605E4EA mov.w 0x0605E5BA,r0
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0605E4EC mov.w @(r0,r1),r2
    c.r[3] = ld32(0x0605E5D8u);  // 0605E4EE mov.l 0x0605E5D8,r3
    c.r[2] = c.r[2] & 0xFFFFu;  // 0605E4F0 extu.w r2,r2
    c.r[2] >>= 2;  // 0605E4F2 shlr2 r2
    c.r[2] >>= 2;  // 0605E4F4 shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 0605E4F6 shlr r2
    c.r[2] >>= 2;  // 0605E4F8 shlr2 r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605E5BCu);  // 0605E4FA mov.w 0x0605E5BC,r1
    c.r[2] += c.r[1];  // 0605E4FC add r1,r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 0605E4FE shlr r2
    st8(c.r[3], c.r[2]); goto L_0605E64A;  // 0605E500 bra 0x0605E64A ; mov.b r2,@r3
L_0605E504:
    c.r[2] = ld32(0x0605E5E0u);  // 0605E504 mov.l 0x0605E5E0,r2
    c.r[1] = 0x11u; goto L_0605E648;  // 0605E506 bra 0x0605E648 ; mov #17,r1
L_0605E50A:
    c.r[2] = ld32(0x0605E5E0u);  // 0605E50A mov.l 0x0605E5E0,r2
    c.r[1] = 0xAu; goto L_0605E648;  // 0605E50C bra 0x0605E648 ; mov #10,r1
L_0605E510:
    c.r[1] = ld32(0x0605E5F8u);  // 0605E510 mov.l 0x0605E5F8,r1
    c.r[0] = ld32(0x0605E5FCu);  // 0605E512 mov.l 0x0605E5FC,r0
    c.r[7] = c.r[9];  // 0605E514 mov r9,r7
    c.r[1] = ld32(c.r[1]);  // 0605E516 mov.l @r1,r1
    c.r[5] = 0xFFFFFFFFu;  // 0605E518 mov #-1,r5
    c.r[1] += 42;  // 0605E51A add #42,r1
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0605E51C mov.w @r1,r6
    c.r[4] = 0x5u;  // 0605E51E mov #5,r4
    c.r[6] <<= 16;  // 0605E520 shll16 r6
    c.r[6] += c.r[6];  // 0605E522 add r6,r6
    c.r[6] >>= 16;  // 0605E524 shlr16 r6
    c.r[6] += c.r[6];  // 0605E526 add r6,r6
    c.r[6] >>= 8;  // 0605E528 shlr8 r6
    { const uint32_t x = c.r[0]; c.pr = 0x0605E52Eu; c.r[15] -= 4; st32(c.r[15], c.r[8]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605E52Eu) return; }  // 0605E52A jsr @r0 ; mov.l r8,@-r15
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0605E52E cmp/eq #-1,r0
    { const bool k = c.t; c.r[15] += 4; if (k) { goto L_0605E5AE; } }  // 0605E530 bt/s 0x0605E5AE ; add #4,r15
    c.r[3] = ld32(0x0605E600u);  // 0605E534 mov.l 0x0605E600,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605E5BEu);  // 0605E536 mov.w 0x0605E5BE,r1
    c.r[0] = c.r[3];  // 0605E538 mov r3,r0
    c.r[2] = (uint32_t)(int16_t)ld16(0x0605E5C0u);  // 0605E53A mov.w 0x0605E5C0,r2
    c.r[6] = c.r[14];  // 0605E53C mov r14,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0605E53E mov.b @(r0,r1),r1
    c.r[6] += 12;  // 0605E540 add #12,r6
    c.r[1] = c.r[1] & 0xFFu;  // 0605E542 extu.b r1,r1
    c.r[1] >>= 2;  // 0605E544 shlr2 r1
    c.r[1] >>= 2;  // 0605E546 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0605E548 shlr r1
    c.r[1] >>= 2;  // 0605E54A shlr2 r1
    c.macl = c.r[1] * c.r[2];  // 0605E54C mul.l r2,r1
    c.r[7] = c.r[14];  // 0605E54E mov r14,r7
    c.r[7] += 14;  // 0605E550 add #14,r7
    c.r[5] = c.macl;  // 0605E552 sts macl,r5
    c.r[5] += c.r[3];  // 0605E554 add r3,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605E5C2u);  // 0605E556 mov.w 0x0605E5C2,r1
    c.r[0] = c.r[5];  // 0605E558 mov r5,r0
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0605E55A mov.w @(r0,r1),r2
    c.r[4] = (uint32_t)(int16_t)ld16(0x0605E5C4u);  // 0605E55C mov.w 0x0605E5C4,r4
    c.r[2] = c.r[2] & 0xFFFFu;  // 0605E55E extu.w r2,r2
    st16(c.r[6], c.r[2]);  // 0605E560 mov.w r2,@r6
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605E5C6u);  // 0605E562 mov.w 0x0605E5C6,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0605E564 mov.b @(r0,r1),r1
    st8(c.r[7], c.r[1]);  // 0605E566 mov.b r1,@r7
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0605E568 mov.l r9,@-r15
    c.r[1] = c.r[14];  // 0605E56A mov r14,r1
    c.r[1] += 8;  // 0605E56C add #8,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0605E56E mov.l r1,@-r15
    c.r[1] = 0xAu;  // 0605E570 mov #10,r1
    c.macl = (c.r[2] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 0605E572 mulu.w r1,r2
    c.r[0] = c.r[3];  // 0605E574 mov r3,r0
    c.r[2] = ld32(c.r[0] + c.r[4]);  // 0605E576 mov.l @(r0,r4),r2
    c.r[1] = c.macl;  // 0605E578 sts macl,r1
    c.r[2] += c.r[1];  // 0605E57A add r1,r2
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 0605E57C mov.l r2,@-r15
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605E5C8u);  // 0605E57E mov.w 0x0605E5C8,r1
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 0605E580 mov.l @(r0,r1),r1
    c.r[5] += 64;  // 0605E582 add #64,r5
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0605E584 mov.l r1,@-r15
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605E5CAu);  // 0605E586 mov.w 0x0605E5CA,r1
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 0605E588 mov.l @(r0,r1),r1
    c.r[4] = c.r[9];  // 0605E58A mov r9,r4
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0605E58C mov.l r1,@-r15
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[5]);  // 0605E58E mov.b @r5,r1
    c.r[0] = 0x7u;  // 0605E590 mov #7,r0
    c.r[1] >>= 2;  // 0605E592 shlr2 r1
    c.r[1] &= c.r[0];  // 0605E594 and r0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0605E596 mov.l r1,@-r15
    c.r[1] = 0x1u;  // 0605E598 mov #1,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0605E59A mov.l r1,@-r15
    c.r[1] = 0x0u;  // 0605E59C mov #0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0605E59E mov.l r1,@-r15
    c.r[0] = ld32(0x0605E604u);  // 0605E5A0 mov.l 0x0605E604,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0605E5A6u; c.r[5] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605E5A6u) return; }  // 0605E5A2 jsr @r0 ; mov r8,r5
    c.r[8] += 3;  // 0605E5A6 add #3,r8
    c.r[2] = ld32(0x0605E5E0u);  // 0605E5A8 mov.l 0x0605E5E0,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]); goto L_0605E648;  // 0605E5AA bra 0x0605E648 ; mov.b @r8,r1
L_0605E5AE:
    c.r[2] = ld32(0x0605E5E0u);  // 0605E5AE mov.l 0x0605E5E0,r2
    c.r[1] = 0x1u; goto L_0605E648;  // 0605E5B0 bra 0x0605E648 ; mov #1,r1
L_0605E608:
    c.r[1] = ld32(0x0605E660u);  // 0605E608 mov.l 0x0605E660,r1
    c.r[2] = ld32(c.r[1]);  // 0605E60A mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605E65Au);  // 0605E60C mov.w 0x0605E65A,r1
    c.r[2] += c.r[1];  // 0605E60E add r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605E65Cu);  // 0605E610 mov.w 0x0605E65C,r1
    c.r[0] = c.r[2];  // 0605E612 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0605E614 mov.b @(r0,r1),r1
    c.r[3] = ld32(0x0605E664u);  // 0605E616 mov.l 0x0605E664,r3
    st8(c.r[3], c.r[1]);  // 0605E618 mov.b r1,@r3
    c.r[1] = ld32(0x0605E668u);  // 0605E61A mov.l 0x0605E668,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605E61C mov.b @r1,r5
    c.r[1] = ld32(0x0605E66Cu);  // 0605E61E mov.l 0x0605E66C,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605E620 mov.b @r1,r4
    c.r[5] = c.r[5] & 0xFFu;  // 0605E622 extu.b r5,r5
    c.r[1] = ld32(0x0605E670u);  // 0605E624 mov.l 0x0605E670,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0605E62Au; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605E62Au) return; }  // 0605E626 jsr @r1 ; extu.b r4,r4
    c.r[14] += 16; goto L_0605E64C;  // 0605E62A bra 0x0605E64C ; add #16,r14
L_0605E62E:
    c.r[2] = ld32(0x0605E674u);  // 0605E62E mov.l 0x0605E674,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605E630 mov.b @r2,r1
    c.r[3] = ld32(0x0605E664u);  // 0605E632 mov.l 0x0605E664,r3
    st8(c.r[3], c.r[1]); goto L_0605E646;  // 0605E634 bra 0x0605E646 ; mov.b r1,@r3
L_0605E638:
    c.r[2] = ld32(0x0605E664u);  // 0605E638 mov.l 0x0605E664,r2
    c.r[1] = 0x4Au;  // 0605E63A mov #74,r1
    st8(c.r[2], c.r[1]);  // 0605E63C mov.b r1,@r2
    c.r[2] = ld32(0x0605E674u);  // 0605E63E mov.l 0x0605E674,r2
    c.r[1] = 0x0u; goto L_0605E648;  // 0605E640 bra 0x0605E648 ; mov #0,r1
L_0605E644:
    c.r[2] = ld32(0x0605E664u);  // 0605E644 mov.l 0x0605E664,r2
L_0605E646:
    c.r[1] = 0x0u;  // 0605E646 mov #0,r1
L_0605E648:
    st8(c.r[2], c.r[1]);  // 0605E648 mov.b r1,@r2
L_0605E64A:
    c.r[14] += 16;  // 0605E64A add #16,r14
L_0605E64C:
    c.r[15] = c.r[14];  // 0605E64C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0605E64E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0605E650 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0605E652 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605E65Eu);  // 0605E654 mov.w 0x0605E65E,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0605E656 rts ; mov.l @r15+,r8
}

void f_0605E678(SH2Context& c) {
    ran[1449] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605E678 mov.l r14,@-r15
    c.r[1] = ld32(0x0605E6ACu);  // 0605E67A mov.l 0x0605E6AC,r1
    c.r[1] = ld32(c.r[1]);  // 0605E67C mov.l @r1,r1
    c.r[1] += 1;  // 0605E67E add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605E680 mov.b @r1,r1
    c.r[7] = ld32(0x0605E6B0u);  // 0605E682 mov.l 0x0605E6B0,r7
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0605E684 mov.b @r7,r2
    c.r[3] = c.r[1];  // 0605E686 mov r1,r3
    c.r[1] = c.r[2] & 0xFFu;  // 0605E688 extu.b r2,r1
    c.r[1] += c.r[3];  // 0605E68A add r3,r1
    c.t = (int32_t)c.r[1] >= 0;  // 0605E68C cmp/pz r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0605E69C; } }  // 0605E68E bt/s 0x0605E69C ; mov r15,r14
    c.r[1] = ld32(0x0605E6B4u);  // 0605E692 mov.l 0x0605E6B4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605E694 mov.b @r1,r1
    c.r[1] -= 1;  // 0605E696 add #-1,r1
    st8(c.r[7], c.r[1]); goto L_0605E6A0;  // 0605E698 bra 0x0605E6A0 ; mov.b r1,@r7
L_0605E69C:
    c.r[3] += c.r[2];  // 0605E69C add r2,r3
    st8(c.r[7], c.r[3]);  // 0605E69E mov.b r3,@r7
L_0605E6A0:
    c.r[15] = c.r[14];  // 0605E6A0 mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605E6A8u);  // 0605E6A2 mov.w 0x0605E6A8,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0605E6A4 rts ; mov.l @r15+,r14
}

void f_0605E6B8(SH2Context& c) {
    ran[1450] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0605E6B8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0605E6BA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0605E6BC mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605E6BE mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0605E6C0 mov r15,r14
    c.r[5] = 0x0u;  // 0605E6C2 mov #0,r5
    c.r[1] = ld32(0x0605E750u);  // 0605E6C4 mov.l 0x0605E750,r1
    c.r[4] = ld32(c.r[1]);  // 0605E6C6 mov.l @r1,r4
    c.r[9] = (uint32_t)(int16_t)ld16(0x0605E74Cu);  // 0605E6C8 mov.w 0x0605E74C,r9
    c.r[8] = ld32(0x0605E754u);  // 0605E6CA mov.l 0x0605E754,r8
    c.r[6] = 0x0u;  // 0605E6CC mov #0,r6
    c.r[3] = c.r[4];  // 0605E6CE mov r4,r3
L_0605E6D0:
    c.r[0] = c.r[6];  // 0605E6D0 mov r6,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[4]);  // 0605E6D2 mov.b @(r0,r4),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605E6D4 extu.b r1,r1
    c.t = c.r[1] == c.r[9];  // 0605E6D6 cmp/eq r9,r1
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_0605E732; } }  // 0605E6D8 bt/s 0x0605E732 ; mov r3,r1
    c.r[1] += 7;  // 0605E6DC add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605E6DE mov.b @r1,r1
    c.r[7] = c.r[1] & 0xFFu;  // 0605E6E0 extu.b r1,r7
    c.r[0] = c.r[7];  // 0605E6E2 mov r7,r0
    c.r[0] >>= 2;  // 0605E6E4 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0605E6E6 shlr r0
    c.r[0] &= 0x1u;  // 0605E6E8 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605E6EA tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[3]; if (k) { goto L_0605E732; } }  // 0605E6EC bf/s 0x0605E732 ; mov r3,r1
    c.r[1] += 3;  // 0605E6F0 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605E6F2 mov.b @r1,r1
    c.r[10] = c.r[1];  // 0605E6F4 mov r1,r10
    c.t = c.r[10] & 1; c.r[10] >>= 1;  // 0605E6F6 shlr r10
    c.r[1] = ld32(0x0605E758u);  // 0605E6F8 mov.l 0x0605E758,r1
    c.r[1] = ld32(c.r[1]);  // 0605E6FA mov.l @r1,r1
    c.r[0] = 0x3u;  // 0605E6FC mov #3,r0
    c.r[1] += 1;  // 0605E6FE add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605E700 mov.b @r1,r1
    c.r[10] &= c.r[0];  // 0605E702 and r0,r10
    c.r[1] = c.r[1] & 0xFFu;  // 0605E704 extu.b r1,r1
    c.t = c.r[10] == c.r[1];  // 0605E706 cmp/eq r1,r10
    if (!c.t) { goto L_0605E732; }  // 0605E708 bf 0x0605E732
    c.r[2] = ld32(c.r[3] + 4);  // 0605E70A mov.l @(4,r3),r2
    c.r[1] = ld32(0x0605E75Cu);  // 0605E70C mov.l 0x0605E75C,r1
    c.r[2] &= c.r[1];  // 0605E70E and r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0605E710 tst r2,r2
    { const bool k = !c.t; c.t = (c.r[10] & c.r[10]) == 0; if (k) { goto L_0605E732; } }  // 0605E712 bf/s 0x0605E732 ; tst r10,r10
    if (!c.t) { goto L_0605E71E; }  // 0605E716 bf 0x0605E71E
    c.r[1] = ld32(c.r[3] + 12);  // 0605E718 mov.l @(12,r3),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605E71A tst r1,r1
    if (!c.t) { goto L_0605E732; }  // 0605E71C bf 0x0605E732
L_0605E71E:
    c.r[7] >>= 2;  // 0605E71E shlr2 r7
    c.r[7] >>= 2;  // 0605E720 shlr2 r7
    c.r[7] >>= 2;  // 0605E722 shlr2 r7
    c.r[0] = 0x1u;  // 0605E724 mov #1,r0
    c.r[7] &= c.r[0];  // 0605E726 and r0,r7
    c.t = (c.r[7] & c.r[7]) == 0;  // 0605E728 tst r7,r7
    if (!c.t) { goto L_0605E732; }  // 0605E72A bf 0x0605E732
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0605E72C mov.b @r8,r1
    c.r[1] += 1;  // 0605E72E add #1,r1
    st8(c.r[8], c.r[1]);  // 0605E730 mov.b r1,@r8
L_0605E732:
    c.r[3] += 16;  // 0605E732 add #16,r3
    c.r[5] += 1;  // 0605E734 add #1,r5
    c.r[1] = 0x49u;  // 0605E736 mov #73,r1
    c.t = (int32_t)c.r[5] > (int32_t)c.r[1];  // 0605E738 cmp/gt r1,r5
    { const bool k = !c.t; c.r[6] += 16; if (k) { SH2_POLL(c); goto L_0605E6D0; } }  // 0605E73A bf/s 0x0605E6D0 ; add #16,r6
    c.r[15] = c.r[14];  // 0605E73E mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0605E740 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0605E742 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0605E744 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605E74Eu);  // 0605E746 mov.w 0x0605E74E,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0605E748 rts ; mov.l @r15+,r8
}

void f_0605E760(SH2Context& c) {
    ran[1451] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605E760 mov.l r14,@-r15
    c.r[1] = ld32(0x0605E7B4u);  // 0605E762 mov.l 0x0605E7B4,r1
    c.r[1] = ld32(c.r[1]);  // 0605E764 mov.l @r1,r1
    c.r[1] += 1;  // 0605E766 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605E768 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0605E76A extu.b r1,r0
    c.t = c.r[0] == 0x1u;  // 0605E76C cmp/eq #1,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0605E77A; } }  // 0605E76E bt/s 0x0605E77A ; mov r15,r14
    c.t = c.r[0] == 0x2u;  // 0605E772 cmp/eq #2,r0
    if (!c.t) { goto L_0605E798; }  // 0605E774 bf 0x0605E798
    goto L_0605E78A;  // 0605E776 bra 0x0605E78A ; nop
L_0605E77A:
    c.r[1] = ld32(0x0605E7B8u);  // 0605E77A mov.l 0x0605E7B8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605E77C mov.b @r1,r1
    c.r[2] = ld32(0x0605E7BCu);  // 0605E77E mov.l 0x0605E7BC,r2
    st8(c.r[2], c.r[1]);  // 0605E780 mov.b r1,@r2
    c.r[1] = ld32(0x0605E7C0u);  // 0605E782 mov.l 0x0605E7C0,r1
    c.r[2] = ld32(0x0605E7C4u);  // 0605E784 mov.l 0x0605E7C4,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]); goto L_0605E7A6;  // 0605E786 bra 0x0605E7A6 ; mov.b @r1,r1
L_0605E78A:
    c.r[1] = ld32(0x0605E7C8u);  // 0605E78A mov.l 0x0605E7C8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605E78C mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0605E78E extu.b r1,r0
    c.r[1] = ld32(0x0605E7CCu);  // 0605E790 mov.l 0x0605E7CC,r1
    c.r[2] = ld32(0x0605E7BCu);  // 0605E792 mov.l 0x0605E7BC,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]); goto L_0605E7A6;  // 0605E794 bra 0x0605E7A6 ; mov.b @(r0,r1),r1
L_0605E798:
    c.r[1] = ld32(0x0605E7BCu);  // 0605E798 mov.l 0x0605E7BC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605E79A mov.b @r1,r1
    c.r[2] = ld32(0x0605E7B8u);  // 0605E79C mov.l 0x0605E7B8,r2
    st8(c.r[2], c.r[1]);  // 0605E79E mov.b r1,@r2
    c.r[1] = ld32(0x0605E7C4u);  // 0605E7A0 mov.l 0x0605E7C4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605E7A2 mov.b @r1,r1
    c.r[2] = ld32(0x0605E7C0u);  // 0605E7A4 mov.l 0x0605E7C0,r2
L_0605E7A6:
    st8(c.r[2], c.r[1]);  // 0605E7A6 mov.b r1,@r2
    c.r[15] = c.r[14];  // 0605E7A8 mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605E7B0u);  // 0605E7AA mov.w 0x0605E7B0,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0605E7AC rts ; mov.l @r15+,r14
}

void f_0605E7D0(SH2Context& c) {
    ran[1452] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605E7D0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0605E7D2 sts.l pr,@-r15
    c.r[1] = ld32(0x0605E7F0u);  // 0605E7D4 mov.l 0x0605E7F0,r1
    c.r[1] = ld32(c.r[1]);  // 0605E7D6 mov.l @r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605E7D8 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0605E7DA extu.b r1,r0
    c.r[0] <<= 2;  // 0605E7DC shll2 r0
    c.r[1] = ld32(0x0605E7F4u);  // 0605E7DE mov.l 0x0605E7F4,r1
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 0605E7E0 mov.l @(r0,r1),r0
    { const uint32_t x = c.r[0]; c.pr = 0x0605E7E6u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605E7E6u) return; }  // 0605E7E2 jsr @r0 ; mov r15,r14
    c.r[15] = c.r[14];  // 0605E7E6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0605E7E8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0605E7EA mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[0] & 0xFFFFu; c.pc = x; return; }  // 0605E7EC rts ; extu.w r0,r0
}

void f_0605E7F8(SH2Context& c) {
    ran[1453] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605E7F8 mov.l r14,@-r15
    c.r[1] = ld32(0x0605E818u);  // 0605E7FA mov.l 0x0605E818,r1
    c.r[2] = ld32(c.r[1]);  // 0605E7FC mov.l @r1,r2
    c.r[2] += 4;  // 0605E7FE add #4,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605E800 mov.b @r2,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0605E802 extu.b r1,r0
    c.t = c.r[0] == 0x1u;  // 0605E804 cmp/eq #1,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0605E80E; } }  // 0605E806 bt/s 0x0605E80E ; mov r15,r14
    c.r[1] -= 1;  // 0605E80A add #-1,r1
    st8(c.r[2], c.r[1]);  // 0605E80C mov.b r1,@r2
L_0605E80E:
    c.r[15] = c.r[14];  // 0605E80E mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605E816u);  // 0605E810 mov.w 0x0605E816,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0605E812 rts ; mov.l @r15+,r14
}

void f_0605E81C(SH2Context& c) {
    ran[1454] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605E81C mov.l r14,@-r15
    c.r[1] = ld32(0x0605E83Cu);  // 0605E81E mov.l 0x0605E83C,r1
    c.r[2] = ld32(c.r[1]);  // 0605E820 mov.l @r1,r2
    c.r[2] += 4;  // 0605E822 add #4,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605E824 mov.b @r2,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0605E826 extu.b r1,r0
    c.t = c.r[0] == 0x7Fu;  // 0605E828 cmp/eq #127,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0605E832; } }  // 0605E82A bt/s 0x0605E832 ; mov r15,r14
    c.r[1] += 1;  // 0605E82E add #1,r1
    st8(c.r[2], c.r[1]);  // 0605E830 mov.b r1,@r2
L_0605E832:
    c.r[15] = c.r[14];  // 0605E832 mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605E83Au);  // 0605E834 mov.w 0x0605E83A,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0605E836 rts ; mov.l @r15+,r14
}

void f_0605E840(SH2Context& c) {
    ran[1455] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605E840 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0605E842 sts.l pr,@-r15
    c.r[1] = ld32(0x0605E8B8u);  // 0605E844 mov.l 0x0605E8B8,r1
    c.r[2] = ld32(c.r[1]);  // 0605E846 mov.l @r1,r2
    c.r[2] += 1;  // 0605E848 add #1,r2
    st32(c.r[1], c.r[2]);  // 0605E84A mov.l r2,@r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605E84C mov.b @r2,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0605E84E extu.b r1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605E850 tst r0,r0
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0605E860; } }  // 0605E852 bf/s 0x0605E860 ; mov r15,r14
    c.r[1] = ld32(0x0605E8BCu);  // 0605E856 mov.l 0x0605E8BC,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605E858 mov.b @r1,r0
    c.r[0] &= 0xF7u;  // 0605E85A and #247,r0
    st8(c.r[1], c.r[0]); goto L_0605E88A;  // 0605E85C bra 0x0605E88A ; mov.b r0,@r1
L_0605E860:
    c.t = c.r[0] == 0x1u;  // 0605E860 cmp/eq #1,r0
    if (!c.t) { goto L_0605E86E; }  // 0605E862 bf 0x0605E86E
    c.r[1] = ld32(0x0605E8BCu);  // 0605E864 mov.l 0x0605E8BC,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605E866 mov.b @r1,r0
    c.r[0] |= 0x8u;  // 0605E868 or #8,r0
    st8(c.r[1], c.r[0]); goto L_0605E88A;  // 0605E86A bra 0x0605E88A ; mov.b r0,@r1
L_0605E86E:
    c.r[1] = ld32(0x0605E8BCu);  // 0605E86E mov.l 0x0605E8BC,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605E870 mov.b @r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605E8B2u);  // 0605E872 mov.w 0x0605E8B2,r3
    c.r[0] = c.r[2];  // 0605E874 mov r2,r0
    c.r[0] >>= 2;  // 0605E876 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0605E878 shlr r0
    c.r[0] &= 0x1u;  // 0605E87A and #1,r0
    c.r[0] ^= 0x1u;  // 0605E87C xor #1,r0
    c.r[0] <<= 2;  // 0605E87E shll2 r0
    c.r[0] += c.r[0];  // 0605E880 add r0,r0
    c.r[2] &= c.r[3];  // 0605E882 and r3,r2
    c.r[2] |= c.r[0];  // 0605E884 or r0,r2
    st8(c.r[1], c.r[2]);  // 0605E886 mov.b r2,@r1
    c.r[1] = ld32(0x0605E8BCu);  // 0605E888 mov.l 0x0605E8BC,r1
L_0605E88A:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605E88A mov.b @r1,r1
    c.r[0] = c.r[1];  // 0605E88C mov r1,r0
    c.r[0] >>= 2;  // 0605E88E shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0605E890 shlr r0
    c.r[0] &= 0x1u;  // 0605E892 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605E894 tst r0,r0
    { const bool k = c.t; c.r[4] = 0x1u; if (k) { goto L_0605E8A0; } }  // 0605E896 bt/s 0x0605E8A0 ; mov #1,r4
    c.r[1] = ld32(0x0605E8C0u);  // 0605E89A mov.l 0x0605E8C0,r1
    goto L_0605E8A4;  // 0605E89C bra 0x0605E8A4 ; nop
L_0605E8A0:
    c.r[4] = ld32(0x0605E8C4u);  // 0605E8A0 mov.l 0x0605E8C4,r4
    c.r[1] = ld32(0x0605E8C0u);  // 0605E8A2 mov.l 0x0605E8C0,r1
L_0605E8A4:
    { const uint32_t x = c.r[1]; c.pr = 0x0605E8A8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605E8A8u) return; }  // 0605E8A4 jsr @r1 ; nop
    c.r[15] = c.r[14];  // 0605E8A8 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0605E8AA lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605E8B4u);  // 0605E8AC mov.w 0x0605E8B4,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0605E8AE rts ; mov.l @r15+,r14
}

void f_0605E8C8(SH2Context& c) {
    ran[1456] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0605E8C8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0605E8CA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605E8CC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0605E8CE sts.l pr,@-r15
    c.r[1] = ld32(0x0605E99Cu);  // 0605E8D0 mov.l 0x0605E99C,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605E8D2 mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0605E8D4 extu.b r2,r2
    c.r[1] = ld32(0x0605E9A0u);  // 0605E8D6 mov.l 0x0605E9A0,r1
    c.r[1] = ld32(c.r[1]);  // 0605E8D8 mov.l @r1,r1
    c.r[2] <<= 2;  // 0605E8DA shll2 r2
    c.r[2] <<= 2;  // 0605E8DC shll2 r2
    c.r[2] += c.r[1];  // 0605E8DE add r1,r2
    c.r[2] += 2;  // 0605E8E0 add #2,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605E8E2 mov.b @r2,r2
    c.r[1] = ld32(0x0605E9A4u);  // 0605E8E4 mov.l 0x0605E9A4,r1
    c.r[3] = ld32(c.r[1]);  // 0605E8E6 mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0605E8E8 extu.b r2,r2
    c.r[1] = 0x1Eu;  // 0605E8EA mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 0605E8EC mul.l r1,r2
    c.r[1] = c.macl;  // 0605E8EE sts macl,r1
    c.r[1] += c.r[3];  // 0605E8F0 add r3,r1
    c.r[1] += 15;  // 0605E8F2 add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605E8F4 mov.b @r1,r1
    c.r[9] = c.r[1] & 0xFFu;  // 0605E8F6 extu.b r1,r9
    c.r[1] = ld32(0x0605E9A8u);  // 0605E8F8 mov.l 0x0605E9A8,r1
    c.r[1] = ld32(c.r[1]);  // 0605E8FA mov.l @r1,r1
    c.r[1] += 1;  // 0605E8FC add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605E8FE mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605E900 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605E902 tst r1,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0605E94C; } }  // 0605E904 bt/s 0x0605E94C ; mov r15,r14
    c.r[1] = ld32(0x0605E9ACu);  // 0605E908 mov.l 0x0605E9AC,r1
    c.r[2] = c.r[9];  // 0605E90A mov r9,r2
    c.r[2] += c.r[2];  // 0605E90C add r2,r2
    c.r[2] += c.r[9];  // 0605E90E add r9,r2
    c.r[2] <<= 2;  // 0605E910 shll2 r2
    c.r[3] = ld32(c.r[1]);  // 0605E912 mov.l @r1,r3
    c.r[0] = c.r[2];  // 0605E914 mov r2,r0
    c.r[7] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 0605E916 mov.w @(r0,r3),r7
    c.r[1] = c.r[7] & 0xFFFFu;  // 0605E918 extu.w r7,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605E91A tst r1,r1
    { const bool k = c.t; c.r[1] = c.r[7]; if (k) { goto L_0605E924; } }  // 0605E91C bt/s 0x0605E924 ; mov r7,r1
    c.r[1] -= 1; goto L_0605E926;  // 0605E920 bra 0x0605E926 ; add #-1,r1
L_0605E924:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605E990u);  // 0605E924 mov.w 0x0605E990,r1
L_0605E926:
    st16(c.r[0] + c.r[3], c.r[1]);  // 0605E926 mov.w r1,@(r0,r3)
    c.r[8] = ld32(0x0605E9B0u);  // 0605E928 mov.l 0x0605E9B0,r8
    c.r[1] = ld32(0x0605E9B4u);  // 0605E92A mov.l 0x0605E9B4,r1
    c.r[4] = ld32(c.r[8]);  // 0605E92C mov.l @r8,r4
    { const uint32_t x = c.r[1]; c.pr = 0x0605E932u; c.r[5] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605E932u) return; }  // 0605E92E jsr @r1 ; mov r9,r5
    c.r[1] = ld32(0x0605E9ACu);  // 0605E932 mov.l 0x0605E9AC,r1
    c.r[2] = c.r[9];  // 0605E934 mov r9,r2
    c.r[2] += c.r[2];  // 0605E936 add r2,r2
    c.r[2] += c.r[9];  // 0605E938 add r9,r2
    c.r[1] = ld32(c.r[1]);  // 0605E93A mov.l @r1,r1
    c.r[2] <<= 2;  // 0605E93C shll2 r2
    c.r[2] += c.r[1];  // 0605E93E add r1,r2
    c.r[1] = ld32(c.r[8]);  // 0605E940 mov.l @r8,r1
    c.r[1] += 12;  // 0605E942 add #12,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0605E944 mov.w @r1,r1
    c.r[2] += 10;  // 0605E946 add #10,r2
    st16(c.r[2], c.r[1]); goto L_0605E982;  // 0605E948 bra 0x0605E982 ; mov.w r1,@r2
L_0605E94C:
    c.r[1] = ld32(0x0605E9B0u);  // 0605E94C mov.l 0x0605E9B0,r1
    c.r[7] = ld32(c.r[1]);  // 0605E94E mov.l @r1,r7
    c.r[7] += 42;  // 0605E950 add #42,r7
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[7]);  // 0605E952 mov.w @r7,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605E992u);  // 0605E954 mov.w 0x0605E992,r1
    c.r[3] = c.r[2] & 0xFFFFu;  // 0605E956 extu.w r2,r3
    c.r[3] >>= 2;  // 0605E958 shlr2 r3
    c.r[3] >>= 2;  // 0605E95A shlr2 r3
    c.r[3] >>= 2;  // 0605E95C shlr2 r3
    c.r[3] &= c.r[1];  // 0605E95E and r1,r3
    c.t = (c.r[3] & c.r[3]) == 0;  // 0605E960 tst r3,r3
    { const bool k = c.t; c.r[3] -= 1; if (k) { goto L_0605E978; } }  // 0605E962 bt/s 0x0605E978 ; add #-1,r3
    c.r[3] &= c.r[1];  // 0605E966 and r1,r3
    c.r[3] <<= 2;  // 0605E968 shll2 r3
    c.r[3] <<= 2;  // 0605E96A shll2 r3
    c.r[3] <<= 2;  // 0605E96C shll2 r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605E994u);  // 0605E96E mov.w 0x0605E994,r1
    c.r[1] &= c.r[2];  // 0605E970 and r2,r1
    c.r[1] |= c.r[3];  // 0605E972 or r3,r1
    st16(c.r[7], c.r[1]); goto L_0605E982;  // 0605E974 bra 0x0605E982 ; mov.w r1,@r7
L_0605E978:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605E994u);  // 0605E978 mov.w 0x0605E994,r1
    c.r[2] &= c.r[1];  // 0605E97A and r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605E996u);  // 0605E97C mov.w 0x0605E996,r1
    c.r[2] |= c.r[1];  // 0605E97E or r1,r2
    st16(c.r[7], c.r[2]);  // 0605E980 mov.w r2,@r7
L_0605E982:
    c.r[15] = c.r[14];  // 0605E982 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0605E984 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0605E986 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0605E988 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605E998u);  // 0605E98A mov.w 0x0605E998,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0605E98C rts ; mov.l @r15+,r8
}

void f_0605E9B8(SH2Context& c) {
    ran[1457] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0605E9B8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0605E9BA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0605E9BC mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605E9BE mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0605E9C0 sts.l pr,@-r15
    c.r[1] = ld32(0x0605EA88u);  // 0605E9C2 mov.l 0x0605EA88,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605E9C4 mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0605E9C6 extu.b r2,r2
    c.r[1] = ld32(0x0605EA8Cu);  // 0605E9C8 mov.l 0x0605EA8C,r1
    c.r[1] = ld32(c.r[1]);  // 0605E9CA mov.l @r1,r1
    c.r[2] <<= 2;  // 0605E9CC shll2 r2
    c.r[2] <<= 2;  // 0605E9CE shll2 r2
    c.r[2] += c.r[1];  // 0605E9D0 add r1,r2
    c.r[2] += 2;  // 0605E9D2 add #2,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605E9D4 mov.b @r2,r2
    c.r[1] = ld32(0x0605EA90u);  // 0605E9D6 mov.l 0x0605EA90,r1
    c.r[3] = ld32(c.r[1]);  // 0605E9D8 mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0605E9DA extu.b r2,r2
    c.r[1] = 0x1Eu;  // 0605E9DC mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 0605E9DE mul.l r1,r2
    c.r[1] = c.macl;  // 0605E9E0 sts macl,r1
    c.r[1] += c.r[3];  // 0605E9E2 add r3,r1
    c.r[1] += 15;  // 0605E9E4 add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605E9E6 mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0605E9E8 extu.b r1,r2
    c.r[1] = ld32(0x0605EA94u);  // 0605E9EA mov.l 0x0605EA94,r1
    c.r[1] = ld32(c.r[1]);  // 0605E9EC mov.l @r1,r1
    c.r[14] = c.r[15];  // 0605E9EE mov r15,r14
    c.r[1] += 1;  // 0605E9F0 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605E9F2 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605E9F4 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605E9F6 tst r1,r1
    { const bool k = c.t; c.r[5] = c.r[2]; if (k) { goto L_0605EA34; } }  // 0605E9F8 bt/s 0x0605EA34 ; mov r2,r5
    c.r[10] = ld32(0x0605EA98u);  // 0605E9FC mov.l 0x0605EA98,r10
    c.r[9] = c.r[2];  // 0605E9FE mov r2,r9
    c.r[9] += c.r[9];  // 0605EA00 add r9,r9
    c.r[9] += c.r[2];  // 0605EA02 add r2,r9
    c.r[9] <<= 2;  // 0605EA04 shll2 r9
    c.r[3] = ld32(c.r[10]);  // 0605EA06 mov.l @r10,r3
    c.r[0] = c.r[9];  // 0605EA08 mov r9,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 0605EA0A mov.w @(r0,r3),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0605EA80u);  // 0605EA0C mov.w 0x0605EA80,r2
    c.r[1] += 1;  // 0605EA0E add #1,r1
    st16(c.r[0] + c.r[3], c.r[1]);  // 0605EA10 mov.w r1,@(r0,r3)
    c.r[1] = c.r[1] & 0xFFFFu;  // 0605EA12 extu.w r1,r1
    c.t = c.r[1] == c.r[2];  // 0605EA14 cmp/eq r2,r1
    { const bool k = !c.t; c.r[1] = 0x0u; if (k) { goto L_0605EA1C; } }  // 0605EA16 bf/s 0x0605EA1C ; mov #0,r1
    st16(c.r[0] + c.r[3], c.r[1]);  // 0605EA1A mov.w r1,@(r0,r3)
L_0605EA1C:
    c.r[8] = ld32(0x0605EA9Cu);  // 0605EA1C mov.l 0x0605EA9C,r8
    c.r[1] = ld32(0x0605EAA0u);  // 0605EA1E mov.l 0x0605EAA0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0605EA24u; c.r[4] = ld32(c.r[8]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605EA24u) return; }  // 0605EA20 jsr @r1 ; mov.l @r8,r4
    c.r[1] = ld32(c.r[10]);  // 0605EA24 mov.l @r10,r1
    c.r[9] += c.r[1];  // 0605EA26 add r1,r9
    c.r[1] = ld32(c.r[8]);  // 0605EA28 mov.l @r8,r1
    c.r[1] += 12;  // 0605EA2A add #12,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0605EA2C mov.w @r1,r1
    c.r[9] += 10;  // 0605EA2E add #10,r9
    st16(c.r[9], c.r[1]); goto L_0605EA70;  // 0605EA30 bra 0x0605EA70 ; mov.w r1,@r9
L_0605EA34:
    c.r[1] = ld32(0x0605EA9Cu);  // 0605EA34 mov.l 0x0605EA9C,r1
    c.r[6] = ld32(c.r[1]);  // 0605EA36 mov.l @r1,r6
    c.r[5] = (uint32_t)(int16_t)ld16(0x0605EA82u);  // 0605EA38 mov.w 0x0605EA82,r5
    c.r[6] += 42;  // 0605EA3A add #42,r6
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[6]);  // 0605EA3C mov.w @r6,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605EA84u);  // 0605EA3E mov.w 0x0605EA84,r1
    c.r[3] = c.r[2] & 0xFFFFu;  // 0605EA40 extu.w r2,r3
    c.r[3] >>= 2;  // 0605EA42 shlr2 r3
    c.r[3] >>= 2;  // 0605EA44 shlr2 r3
    c.r[3] >>= 2;  // 0605EA46 shlr2 r3
    c.r[3] &= c.r[1];  // 0605EA48 and r1,r3
    c.r[3] += 1;  // 0605EA4A add #1,r3
    c.r[3] &= c.r[1];  // 0605EA4C and r1,r3
    c.r[3] <<= 2;  // 0605EA4E shll2 r3
    c.r[3] <<= 2;  // 0605EA50 shll2 r3
    c.r[3] <<= 2;  // 0605EA52 shll2 r3
    c.r[7] = c.r[2];  // 0605EA54 mov r2,r7
    c.r[7] &= c.r[5];  // 0605EA56 and r5,r7
    c.r[7] |= c.r[3];  // 0605EA58 or r3,r7
    c.r[2] = c.r[7] & 0xFFFFu;  // 0605EA5A extu.w r7,r2
    c.r[2] >>= 2;  // 0605EA5C shlr2 r2
    c.r[2] >>= 2;  // 0605EA5E shlr2 r2
    c.r[2] >>= 2;  // 0605EA60 shlr2 r2
    c.r[2] &= c.r[1];  // 0605EA62 and r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605EA80u);  // 0605EA64 mov.w 0x0605EA80,r1
    c.t = c.r[2] == c.r[1];  // 0605EA66 cmp/eq r1,r2
    { const bool k = !c.t; st16(c.r[6], c.r[7]); if (k) { goto L_0605EA70; } }  // 0605EA68 bf/s 0x0605EA70 ; mov.w r7,@r6
    c.r[7] &= c.r[5];  // 0605EA6C and r5,r7
    st16(c.r[6], c.r[7]);  // 0605EA6E mov.w r7,@r6
L_0605EA70:
    c.r[15] = c.r[14];  // 0605EA70 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0605EA72 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0605EA74 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0605EA76 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0605EA78 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605EA86u);  // 0605EA7A mov.w 0x0605EA86,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0605EA7C rts ; mov.l @r15+,r8
}

void f_0605EAA4(SH2Context& c) {
    ran[1458] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0605EAA4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0605EAA6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605EAA8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0605EAAA sts.l pr,@-r15
    c.r[1] = ld32(0x0605EBA0u);  // 0605EAAC mov.l 0x0605EBA0,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605EAAE mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0605EAB0 extu.b r2,r2
    c.r[1] = ld32(0x0605EBA4u);  // 0605EAB2 mov.l 0x0605EBA4,r1
    c.r[1] = ld32(c.r[1]);  // 0605EAB4 mov.l @r1,r1
    c.r[2] <<= 2;  // 0605EAB6 shll2 r2
    c.r[2] <<= 2;  // 0605EAB8 shll2 r2
    c.r[2] += c.r[1];  // 0605EABA add r1,r2
    c.r[2] += 2;  // 0605EABC add #2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605EABE mov.b @r2,r1
    c.r[9] = c.r[1] & 0xFFu;  // 0605EAC0 extu.b r1,r9
    c.r[1] = ld32(0x0605EBA8u);  // 0605EAC2 mov.l 0x0605EBA8,r1
    c.r[1] = ld32(c.r[1]);  // 0605EAC4 mov.l @r1,r1
    c.r[1] += 1;  // 0605EAC6 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605EAC8 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605EACA extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605EACC tst r1,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0605EB30; } }  // 0605EACE bt/s 0x0605EB30 ; mov r15,r14
    c.r[1] = ld32(0x0605EBACu);  // 0605EAD2 mov.l 0x0605EBAC,r1
    c.r[2] = ld32(c.r[1]);  // 0605EAD4 mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 0605EAD6 mov #30,r1
    c.macl = c.r[9] * c.r[1];  // 0605EAD8 mul.l r1,r9
    c.r[3] = c.macl;  // 0605EADA sts macl,r3
    c.r[3] += c.r[2];  // 0605EADC add r2,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0605EADE mov.w @r3,r2
    c.r[1] = c.r[2] & 0xFFFFu;  // 0605EAE0 extu.w r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605EAE2 tst r1,r1
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_0605EAEC; } }  // 0605EAE4 bt/s 0x0605EAEC ; mov r2,r1
    c.r[1] -= 1; goto L_0605EAEE;  // 0605EAE8 bra 0x0605EAEE ; add #-1,r1
L_0605EAEC:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605EB92u);  // 0605EAEC mov.w 0x0605EB92,r1
L_0605EAEE:
    st16(c.r[3], c.r[1]);  // 0605EAEE mov.w r1,@r3
    c.r[1] = ld32(0x0605EBA0u);  // 0605EAF0 mov.l 0x0605EBA0,r1
    c.r[8] = ld32(0x0605EBB0u);  // 0605EAF2 mov.l 0x0605EBB0,r8
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605EAF4 mov.b @r1,r6
    c.r[5] = c.r[9];  // 0605EAF6 mov r9,r5
    c.r[4] = ld32(c.r[8]);  // 0605EAF8 mov.l @r8,r4
    c.r[1] = ld32(0x0605EBB4u);  // 0605EAFA mov.l 0x0605EBB4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0605EB00u; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605EB00u) return; }  // 0605EAFC jsr @r1 ; extu.b r6,r6
    c.r[1] = ld32(0x0605EBACu);  // 0605EB00 mov.l 0x0605EBAC,r1
    c.r[2] = ld32(c.r[1]);  // 0605EB02 mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 0605EB04 mov #30,r1
    c.macl = c.r[9] * c.r[1];  // 0605EB06 mul.l r1,r9
    c.r[6] = c.macl;  // 0605EB08 sts macl,r6
    c.r[6] += c.r[2];  // 0605EB0A add r2,r6
    c.r[7] = c.r[6];  // 0605EB0C mov r6,r7
    c.r[7] += 22;  // 0605EB0E add #22,r7
    c.r[2] = ld32(c.r[8]);  // 0605EB10 mov.l @r8,r2
    c.r[6] += 24;  // 0605EB12 add #24,r6
    c.r[3] = c.r[2];  // 0605EB14 mov r2,r3
    c.r[1] = c.r[2];  // 0605EB16 mov r2,r1
    c.r[1] += 26;  // 0605EB18 add #26,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0605EB1A mov.w @r1,r1
    c.r[3] += 22;  // 0605EB1C add #22,r3
    st16(c.r[3], c.r[1]);  // 0605EB1E mov.w r1,@r3
    st16(c.r[7], c.r[1]);  // 0605EB20 mov.w r1,@r7
    c.r[3] = c.r[2];  // 0605EB22 mov r2,r3
    c.r[2] += 28;  // 0605EB24 add #28,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0605EB26 mov.w @r2,r1
    c.r[3] += 24;  // 0605EB28 add #24,r3
    st16(c.r[3], c.r[1]);  // 0605EB2A mov.w r1,@r3
    st16(c.r[6], c.r[1]); goto L_0605EB84;  // 0605EB2C bra 0x0605EB84 ; mov.w r1,@r6
L_0605EB30:
    c.r[7] = ld32(0x0605EBB0u);  // 0605EB30 mov.l 0x0605EBB0,r7
    c.r[3] = ld32(c.r[7]);  // 0605EB32 mov.l @r7,r3
    c.r[2] = (uint32_t)(int16_t)ld16(0x0605EB94u);  // 0605EB34 mov.w 0x0605EB94,r2
    c.r[0] = c.r[3];  // 0605EB36 mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0605EB38 mov.b @(r0,r2),r1
    c.r[6] = c.r[1];  // 0605EB3A mov r1,r6
    c.r[6] >>= 2;  // 0605EB3C shlr2 r6
    c.t = c.r[6] & 1; c.r[6] >>= 1;  // 0605EB3E shlr r6
    c.r[0] = 0x1u;  // 0605EB40 mov #1,r0
    c.r[6] &= c.r[0];  // 0605EB42 and r0,r6
    c.t = (c.r[6] & c.r[6]) == 0;  // 0605EB44 tst r6,r6
    if (c.t) { goto L_0605EB50; }  // 0605EB46 bt 0x0605EB50
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605EB96u);  // 0605EB48 mov.w 0x0605EB96,r0
    c.r[1] &= c.r[0];  // 0605EB4A and r0,r1
    c.r[0] = c.r[3];  // 0605EB4C mov r3,r0
    st8(c.r[0] + c.r[2], c.r[1]);  // 0605EB4E mov.b r1,@(r0,r2)
L_0605EB50:
    c.r[7] = ld32(c.r[7]);  // 0605EB50 mov.l @r7,r7
    c.r[6] = (uint32_t)(int16_t)ld16(0x0605EB98u);  // 0605EB52 mov.w 0x0605EB98,r6
    c.r[0] = c.r[7];  // 0605EB54 mov r7,r0
    c.r[3] = ld32(c.r[0] + c.r[6]);  // 0605EB56 mov.l @(r0,r6),r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605EB9Au);  // 0605EB58 mov.w 0x0605EB9A,r1
    c.r[2] = c.r[3];  // 0605EB5A mov r3,r2
    c.r[2] >>= 8;  // 0605EB5C shlr8 r2
    c.r[2] <<= 2;  // 0605EB5E shll2 r2
    c.r[2] >>= 8;  // 0605EB60 shlr8 r2
    c.r[2] &= c.r[1];  // 0605EB62 and r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0605EB64 tst r2,r2
    { const bool k = c.t; c.r[2] -= 1; if (k) { goto L_0605EB7A; } }  // 0605EB66 bt/s 0x0605EB7A ; add #-1,r2
    c.r[2] &= c.r[1];  // 0605EB6A and r1,r2
    c.r[2] <<= 8;  // 0605EB6C shll8 r2
    c.r[2] >>= 2;  // 0605EB6E shlr2 r2
    c.r[2] <<= 8;  // 0605EB70 shll8 r2
    c.r[1] = ld32(0x0605EBB8u);  // 0605EB72 mov.l 0x0605EBB8,r1
    c.r[1] &= c.r[3];  // 0605EB74 and r3,r1
    c.r[2] |= c.r[1]; goto L_0605EB82;  // 0605EB76 bra 0x0605EB82 ; or r1,r2
L_0605EB7A:
    c.r[1] = ld32(0x0605EBB8u);  // 0605EB7A mov.l 0x0605EBB8,r1
    c.r[1] &= c.r[3];  // 0605EB7C and r3,r1
    c.r[2] = ld32(0x0605EBBCu);  // 0605EB7E mov.l 0x0605EBBC,r2
    c.r[2] |= c.r[1];  // 0605EB80 or r1,r2
L_0605EB82:
    st32(c.r[0] + c.r[6], c.r[2]);  // 0605EB82 mov.l r2,@(r0,r6)
L_0605EB84:
    c.r[15] = c.r[14];  // 0605EB84 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0605EB86 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0605EB88 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0605EB8A mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605EB9Cu);  // 0605EB8C mov.w 0x0605EB9C,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0605EB8E rts ; mov.l @r15+,r8
}

void f_0605EBC0(SH2Context& c) {
    ran[1459] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0605EBC0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0605EBC2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0605EBC4 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605EBC6 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0605EBC8 sts.l pr,@-r15
    c.r[6] = ld32(0x0605ECC0u);  // 0605EBCA mov.l 0x0605ECC0,r6
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0605EBCC mov.b @r6,r2
    c.r[1] = ld32(0x0605ECC4u);  // 0605EBCE mov.l 0x0605ECC4,r1
    c.r[1] = ld32(c.r[1]);  // 0605EBD0 mov.l @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0605EBD2 extu.b r2,r2
    c.r[2] <<= 2;  // 0605EBD4 shll2 r2
    c.r[2] <<= 2;  // 0605EBD6 shll2 r2
    c.r[2] += c.r[1];  // 0605EBD8 add r1,r2
    c.r[2] += 2;  // 0605EBDA add #2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605EBDC mov.b @r2,r1
    c.r[3] = c.r[1] & 0xFFu;  // 0605EBDE extu.b r1,r3
    c.r[1] = ld32(0x0605ECC8u);  // 0605EBE0 mov.l 0x0605ECC8,r1
    c.r[1] = ld32(c.r[1]);  // 0605EBE2 mov.l @r1,r1
    c.r[14] = c.r[15];  // 0605EBE4 mov r15,r14
    c.r[1] += 1;  // 0605EBE6 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605EBE8 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605EBEA extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605EBEC tst r1,r1
    { const bool k = c.t; c.r[5] = c.r[3]; if (k) { goto L_0605EC46; } }  // 0605EBEE bt/s 0x0605EC46 ; mov r3,r5
    c.r[1] = 0x1Eu;  // 0605EBF2 mov #30,r1
    c.macl = c.r[3] * c.r[1];  // 0605EBF4 mul.l r1,r3
    c.r[10] = ld32(0x0605ECCCu);  // 0605EBF6 mov.l 0x0605ECCC,r10
    c.r[2] = ld32(c.r[10]);  // 0605EBF8 mov.l @r10,r2
    c.r[3] = c.macl;  // 0605EBFA sts macl,r3
    c.r[3] += c.r[2];  // 0605EBFC add r2,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0605EBFE mov.w @r3,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0605ECB2u);  // 0605EC00 mov.w 0x0605ECB2,r2
    c.r[1] += 1;  // 0605EC02 add #1,r1
    st16(c.r[3], c.r[1]);  // 0605EC04 mov.w r1,@r3
    c.r[1] = c.r[1] & 0xFFFFu;  // 0605EC06 extu.w r1,r1
    c.t = c.r[1] == c.r[2];  // 0605EC08 cmp/eq r2,r1
    { const bool k = !c.t; c.r[9] = c.macl; if (k) { goto L_0605EC12; } }  // 0605EC0A bf/s 0x0605EC12 ; sts macl,r9
    c.r[1] = 0x0u;  // 0605EC0E mov #0,r1
    st16(c.r[3], c.r[1]);  // 0605EC10 mov.w r1,@r3
L_0605EC12:
    c.r[8] = ld32(0x0605ECD0u);  // 0605EC12 mov.l 0x0605ECD0,r8
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0605EC14 mov.b @r6,r6
    c.r[1] = ld32(0x0605ECD4u);  // 0605EC16 mov.l 0x0605ECD4,r1
    c.r[4] = ld32(c.r[8]);  // 0605EC18 mov.l @r8,r4
    { const uint32_t x = c.r[1]; c.pr = 0x0605EC1Eu; c.r[6] = c.r[6] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605EC1Eu) return; }  // 0605EC1A jsr @r1 ; extu.b r6,r6
    c.r[6] = ld32(c.r[10]);  // 0605EC1E mov.l @r10,r6
    c.r[2] = ld32(c.r[8]);  // 0605EC20 mov.l @r8,r2
    c.r[6] += c.r[9];  // 0605EC22 add r9,r6
    c.r[7] = c.r[6];  // 0605EC24 mov r6,r7
    c.r[7] += 22;  // 0605EC26 add #22,r7
    c.r[3] = c.r[2];  // 0605EC28 mov r2,r3
    c.r[3] += 22;  // 0605EC2A add #22,r3
    c.r[1] = c.r[2];  // 0605EC2C mov r2,r1
    c.r[1] += 26;  // 0605EC2E add #26,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0605EC30 mov.w @r1,r1
    c.r[6] += 24;  // 0605EC32 add #24,r6
    st16(c.r[3], c.r[1]);  // 0605EC34 mov.w r1,@r3
    st16(c.r[7], c.r[1]);  // 0605EC36 mov.w r1,@r7
    c.r[3] = c.r[2];  // 0605EC38 mov r2,r3
    c.r[2] += 28;  // 0605EC3A add #28,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0605EC3C mov.w @r2,r1
    c.r[3] += 24;  // 0605EC3E add #24,r3
    st16(c.r[3], c.r[1]);  // 0605EC40 mov.w r1,@r3
    st16(c.r[6], c.r[1]); goto L_0605ECA2;  // 0605EC42 bra 0x0605ECA2 ; mov.w r1,@r6
L_0605EC46:
    c.r[7] = ld32(0x0605ECD0u);  // 0605EC46 mov.l 0x0605ECD0,r7
    c.r[3] = ld32(c.r[7]);  // 0605EC48 mov.l @r7,r3
    c.r[2] = (uint32_t)(int16_t)ld16(0x0605ECB4u);  // 0605EC4A mov.w 0x0605ECB4,r2
    c.r[0] = c.r[3];  // 0605EC4C mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0605EC4E mov.b @(r0,r2),r1
    c.r[6] = c.r[1];  // 0605EC50 mov r1,r6
    c.r[6] >>= 2;  // 0605EC52 shlr2 r6
    c.t = c.r[6] & 1; c.r[6] >>= 1;  // 0605EC54 shlr r6
    c.r[0] = 0x1u;  // 0605EC56 mov #1,r0
    c.r[6] &= c.r[0];  // 0605EC58 and r0,r6
    c.t = (c.r[6] & c.r[6]) == 0;  // 0605EC5A tst r6,r6
    if (c.t) { goto L_0605EC66; }  // 0605EC5C bt 0x0605EC66
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605ECB6u);  // 0605EC5E mov.w 0x0605ECB6,r0
    c.r[1] &= c.r[0];  // 0605EC60 and r0,r1
    c.r[0] = c.r[3];  // 0605EC62 mov r3,r0
    st8(c.r[0] + c.r[2], c.r[1]);  // 0605EC64 mov.b r1,@(r0,r2)
L_0605EC66:
    c.r[4] = (uint32_t)(int16_t)ld16(0x0605ECB8u);  // 0605EC66 mov.w 0x0605ECB8,r4
    c.r[6] = ld32(c.r[7]);  // 0605EC68 mov.l @r7,r6
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605ECBAu);  // 0605EC6A mov.w 0x0605ECBA,r1
    c.r[0] = c.r[6];  // 0605EC6C mov r6,r0
    c.r[2] = ld32(c.r[0] + c.r[4]);  // 0605EC6E mov.l @(r0,r4),r2
    c.r[5] = ld32(0x0605ECD8u);  // 0605EC70 mov.l 0x0605ECD8,r5
    c.r[3] = c.r[2];  // 0605EC72 mov r2,r3
    c.r[3] >>= 8;  // 0605EC74 shlr8 r3
    c.r[3] <<= 2;  // 0605EC76 shll2 r3
    c.r[3] >>= 8;  // 0605EC78 shlr8 r3
    c.r[3] &= c.r[1];  // 0605EC7A and r1,r3
    c.r[3] += 1;  // 0605EC7C add #1,r3
    c.r[3] &= c.r[1];  // 0605EC7E and r1,r3
    c.r[3] <<= 8;  // 0605EC80 shll8 r3
    c.r[3] >>= 2;  // 0605EC82 shlr2 r3
    c.r[3] <<= 8;  // 0605EC84 shll8 r3
    c.r[7] = c.r[2];  // 0605EC86 mov r2,r7
    c.r[7] &= c.r[5];  // 0605EC88 and r5,r7
    c.r[7] |= c.r[3];  // 0605EC8A or r3,r7
    c.r[2] = c.r[7];  // 0605EC8C mov r7,r2
    c.r[2] >>= 8;  // 0605EC8E shlr8 r2
    c.r[2] <<= 2;  // 0605EC90 shll2 r2
    c.r[2] >>= 8;  // 0605EC92 shlr8 r2
    c.r[2] &= c.r[1];  // 0605EC94 and r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605ECB2u);  // 0605EC96 mov.w 0x0605ECB2,r1
    c.t = c.r[2] == c.r[1];  // 0605EC98 cmp/eq r1,r2
    { const bool k = !c.t; st32(c.r[0] + c.r[4], c.r[7]); if (k) { goto L_0605ECA2; } }  // 0605EC9A bf/s 0x0605ECA2 ; mov.l r7,@(r0,r4)
    c.r[7] &= c.r[5];  // 0605EC9E and r5,r7
    st32(c.r[0] + c.r[4], c.r[7]);  // 0605ECA0 mov.l r7,@(r0,r4)
L_0605ECA2:
    c.r[15] = c.r[14];  // 0605ECA2 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0605ECA4 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0605ECA6 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0605ECA8 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0605ECAA mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605ECBCu);  // 0605ECAC mov.w 0x0605ECBC,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0605ECAE rts ; mov.l @r15+,r8
}

void f_0605ECDC(SH2Context& c) {
    ran[1460] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605ECDC mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0605ECDE mov r15,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605ECE6u);  // 0605ECE0 mov.w 0x0605ECE6,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0605ECE2 rts ; mov.l @r15+,r14
}

void f_0605ECE8(SH2Context& c) {
    ran[1461] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605ECE8 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0605ECEA mov r15,r14
    c.r[2] = ld32(0x0605ED44u);  // 0605ECEC mov.l 0x0605ED44,r2
    c.r[1] = c.r[2];  // 0605ECEE mov r2,r1
    c.r[1] += 117;  // 0605ECF0 add #117,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605ECF2 mov.b @r1,r3
    c.r[6] = ld32(0x0605ED48u);  // 0605ECF4 mov.l 0x0605ED48,r6
    c.r[1] = c.r[2];  // 0605ECF6 mov r2,r1
    c.r[1] += 79;  // 0605ECF8 add #79,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605ECFA mov.b @r1,r1
    c.r[3] = c.r[3] & 0xFFu;  // 0605ECFC extu.b r3,r3
    c.r[3] += c.r[1];  // 0605ECFE add r1,r3
    c.r[1] = c.r[2];  // 0605ED00 mov r2,r1
    c.r[1] += 116;  // 0605ED02 add #116,r1
    c.r[2] += 78;  // 0605ED04 add #78,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605ED06 mov.b @r1,r1
    c.r[3] <<= 2;  // 0605ED08 shll2 r3
    c.r[3] <<= 2;  // 0605ED0A shll2 r3
    c.r[3] <<= 2;  // 0605ED0C shll2 r3
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605ED0E mov.b @r2,r7
    c.r[1] = c.r[1] & 0xFFu;  // 0605ED10 extu.b r1,r1
    c.r[2] = ld32(c.r[6]);  // 0605ED12 mov.l @r6,r2
    c.r[1] += c.r[7];  // 0605ED14 add r7,r1
    c.r[3] += c.r[2];  // 0605ED16 add r2,r3
    c.r[0] = c.r[3];  // 0605ED18 mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0605ED1A mov.b @(r0,r1),r1
    c.r[7] = 0x0u;  // 0605ED1C mov #0,r7
    c.r[2] = c.r[1] & 0xFFu;  // 0605ED1E extu.b r1,r2
    c.r[3] = ld32(0x0605ED4Cu);  // 0605ED20 mov.l 0x0605ED4C,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605ED40u);  // 0605ED22 mov.w 0x0605ED40,r1
    c.t = c.r[2] == c.r[1];  // 0605ED24 cmp/eq r1,r2
    { const bool k = c.t; st8(c.r[3], c.r[7]); if (k) { goto L_0605ED2C; } }  // 0605ED26 bt/s 0x0605ED2C ; mov.b r7,@r3
    st8(c.r[3], c.r[2]);  // 0605ED2A mov.b r2,@r3
L_0605ED2C:
    c.r[3] = ld32(0x0605ED50u);  // 0605ED2C mov.l 0x0605ED50,r3
    c.r[2] = ld32(0x0605ED54u);  // 0605ED2E mov.l 0x0605ED54,r2
    c.r[1] = ld32(0x0605ED58u);  // 0605ED30 mov.l 0x0605ED58,r1
    st8(c.r[1], c.r[7]);  // 0605ED32 mov.b r7,@r1
    st8(c.r[2], c.r[7]);  // 0605ED34 mov.b r7,@r2
    st8(c.r[3], c.r[7]);  // 0605ED36 mov.b r7,@r3
    c.r[15] = c.r[14];  // 0605ED38 mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605ED42u);  // 0605ED3A mov.w 0x0605ED42,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0605ED3C rts ; mov.l @r15+,r14
}

void f_06060E54(SH2Context& c) {
    ran[1462] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06060E54 mov.l r14,@-r15
    c.r[1] = ld32(0x06060EF8u);  // 06060E56 mov.l 0x06060EF8,r1
    c.r[1] = ld32(c.r[1]);  // 06060E58 mov.l @r1,r1
    c.r[1] += 1;  // 06060E5A add #1,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06060E5C mov.b @r1,r3
    c.r[1] = ld32(0x06060EFCu);  // 06060E5E mov.l 0x06060EFC,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06060E60 mov.b @r1,r1
    c.r[2] = 0x2u;  // 06060E62 mov #2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06060E64 extu.b r1,r1
    c.t = c.r[1] > c.r[2];  // 06060E66 cmp/hi r2,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06060EEE; } }  // 06060E68 bt/s 0x06060EEE ; mov r15,r14
    c.t = (int32_t)c.r[3] > 0;  // 06060E6C cmp/pl r3
    { const bool k = !c.t; c.r[2] = 0x49u; if (k) { goto L_06060EAC; } }  // 06060E6E bf/s 0x06060EAC ; mov #73,r2
    c.r[7] = ld32(0x06060F00u);  // 06060E72 mov.l 0x06060F00,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06060E74 mov.b @r7,r1
    c.r[1] += c.r[3];  // 06060E76 add r3,r1
    st8(c.r[7], c.r[1]);  // 06060E78 mov.b r1,@r7
    c.r[1] = c.r[1] & 0xFFu;  // 06060E7A extu.b r1,r1
    c.t = c.r[1] > c.r[2];  // 06060E7C cmp/hi r2,r1
    { const bool k = !c.t; c.r[1] = 0x0u; if (k) { goto L_06060E84; } }  // 06060E7E bf/s 0x06060E84 ; mov #0,r1
    st8(c.r[7], c.r[1]);  // 06060E82 mov.b r1,@r7
L_06060E84:
    c.r[2] = ld32(0x06060F04u);  // 06060E84 mov.l 0x06060F04,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06060E86 mov.b @r2,r1
    c.r[7] = 0x7Fu;  // 06060E88 mov #127,r7
    c.r[1] += c.r[3];  // 06060E8A add r3,r1
    st8(c.r[2], c.r[1]);  // 06060E8C mov.b r1,@r2
    c.r[1] = c.r[1] & 0xFFu;  // 06060E8E extu.b r1,r1
    c.t = c.r[1] > c.r[7];  // 06060E90 cmp/hi r7,r1
    { const bool k = !c.t; c.r[1] = 0x0u; if (k) { goto L_06060E98; } }  // 06060E92 bf/s 0x06060E98 ; mov #0,r1
    st8(c.r[2], c.r[1]);  // 06060E96 mov.b r1,@r2
L_06060E98:
    c.r[2] = ld32(0x06060F08u);  // 06060E98 mov.l 0x06060F08,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06060E9A mov.b @r2,r1
    c.r[1] += c.r[3];  // 06060E9C add r3,r1
    st8(c.r[2], c.r[1]);  // 06060E9E mov.b r1,@r2
    c.r[1] = c.r[1] & 0xFFu;  // 06060EA0 extu.b r1,r1
    c.t = c.r[1] > c.r[7];  // 06060EA2 cmp/hi r7,r1
    { const bool k = !c.t; c.r[1] = 0x0u; if (k) { goto L_06060EEE; } }  // 06060EA4 bf/s 0x06060EEE ; mov #0,r1
    st8(c.r[2], c.r[1]); goto L_06060EEE;  // 06060EA8 bra 0x06060EEE ; mov.b r1,@r2
L_06060EAC:
    c.r[7] = ld32(0x06060F00u);  // 06060EAC mov.l 0x06060F00,r7
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06060EAE mov.b @r7,r2
    c.r[1] = c.r[2] & 0xFFu;  // 06060EB0 extu.b r2,r1
    c.r[1] += c.r[3];  // 06060EB2 add r3,r1
    c.t = (int32_t)c.r[1] >= 0;  // 06060EB4 cmp/pz r1
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_06060EBE; } }  // 06060EB6 bt/s 0x06060EBE ; mov r2,r1
    c.r[1] = 0x49u; goto L_06060EC0;  // 06060EBA bra 0x06060EC0 ; mov #73,r1
L_06060EBE:
    c.r[1] += c.r[3];  // 06060EBE add r3,r1
L_06060EC0:
    st8(c.r[7], c.r[1]);  // 06060EC0 mov.b r1,@r7
    c.r[7] = ld32(0x06060F04u);  // 06060EC2 mov.l 0x06060F04,r7
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06060EC4 mov.b @r7,r2
    c.r[1] = c.r[2] & 0xFFu;  // 06060EC6 extu.b r2,r1
    c.r[1] += c.r[3];  // 06060EC8 add r3,r1
    c.t = (int32_t)c.r[1] >= 0;  // 06060ECA cmp/pz r1
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_06060ED4; } }  // 06060ECC bt/s 0x06060ED4 ; mov r2,r1
    c.r[1] = 0x7Fu; goto L_06060ED6;  // 06060ED0 bra 0x06060ED6 ; mov #127,r1
L_06060ED4:
    c.r[1] += c.r[3];  // 06060ED4 add r3,r1
L_06060ED6:
    st8(c.r[7], c.r[1]);  // 06060ED6 mov.b r1,@r7
    c.r[7] = ld32(0x06060F08u);  // 06060ED8 mov.l 0x06060F08,r7
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06060EDA mov.b @r7,r2
    c.r[1] = c.r[2] & 0xFFu;  // 06060EDC extu.b r2,r1
    c.r[1] += c.r[3];  // 06060EDE add r3,r1
    c.t = (int32_t)c.r[1] >= 0;  // 06060EE0 cmp/pz r1
    { const bool k = c.t; c.r[3] += c.r[2]; if (k) { goto L_06060EEC; } }  // 06060EE2 bt/s 0x06060EEC ; add r2,r3
    c.r[1] = 0x7Fu;  // 06060EE6 mov #127,r1
    st8(c.r[7], c.r[1]); goto L_06060EEE;  // 06060EE8 bra 0x06060EEE ; mov.b r1,@r7
L_06060EEC:
    st8(c.r[7], c.r[3]);  // 06060EEC mov.b r3,@r7
L_06060EEE:
    c.r[15] = c.r[14];  // 06060EEE mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x06060EF6u);  // 06060EF0 mov.w 0x06060EF6,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06060EF2 rts ; mov.l @r15+,r14
}

void f_06060F0C(SH2Context& c) {
    ran[1463] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06060F0C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06060F0E sts.l pr,@-r15
    c.r[7] = ld32(0x06060FF0u);  // 06060F10 mov.l 0x06060FF0,r7
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06060F12 mov.b @r7,r3
    c.r[1] = 0x3u;  // 06060F14 mov #3,r1
    c.r[2] = c.r[3] & 0xFFu;  // 06060F16 extu.b r3,r2
    c.r[2] -= 1;  // 06060F18 add #-1,r2
    c.t = c.r[2] > c.r[1];  // 06060F1A cmp/hi r1,r2
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06060FB2; } }  // 06060F1C bt/s 0x06060FB2 ; mov r15,r14
    c.r[1] = c.r[2];  // 06060F20 mov r2,r1
    c.r[1] += c.r[1];  // 06060F22 add r1,r1
    c.r[0] = 0x06060F30u;  // 06060F24 mova 0x06060F30,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06060F26 mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 06060F28 add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x06060F38u: goto L_06060F38; case 0x06060F68u: goto L_06060F68; case 0x06060FA0u: goto L_06060FA0; case 0x06060FAAu: goto L_06060FAA; default: sh2_call(c, x); return; } }  // 06060F2A jmp @r0 ; nop
L_06060F38:
    c.r[2] = ld32(0x06060FF0u);  // 06060F38 mov.l 0x06060FF0,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06060F3A mov.b @r2,r1
    c.r[1] += 1;  // 06060F3C add #1,r1
    st8(c.r[2], c.r[1]);  // 06060F3E mov.b r1,@r2
    c.r[1] = ld32(0x06060FF4u);  // 06060F40 mov.l 0x06060FF4,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06060F42 mov.b @r1,r2
    c.r[1] = ld32(0x06060FF8u);  // 06060F44 mov.l 0x06060FF8,r1
    c.r[3] = ld32(c.r[1]);  // 06060F46 mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06060F48 extu.b r2,r2
    c.r[1] = 0x1Eu;  // 06060F4A mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 06060F4C mul.l r1,r2
    c.r[7] = ld32(0x06060FFCu);  // 06060F4E mov.l 0x06060FFC,r7
    c.r[1] = c.macl;  // 06060F50 sts macl,r1
    c.r[1] += c.r[3];  // 06060F52 add r3,r1
    c.r[1] += 15;  // 06060F54 add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06060F56 mov.b @r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06060FECu);  // 06060F58 mov.w 0x06060FEC,r2
    st8(c.r[7], c.r[1]);  // 06060F5A mov.b r1,@r7
    c.r[1] = c.r[1] & 0xFFu;  // 06060F5C extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 06060F5E cmp/eq r2,r1
    { const bool k = !c.t; c.r[1] = 0x0u; if (k) { goto L_06060FDC; } }  // 06060F60 bf/s 0x06060FDC ; mov #0,r1
    st8(c.r[7], c.r[1]); goto L_06060FDC;  // 06060F64 bra 0x06060FDC ; mov.b r1,@r7
L_06060F68:
    c.r[2] = ld32(0x06061000u);  // 06060F68 mov.l 0x06061000,r2
    c.r[1] = c.r[2];  // 06060F6A mov r2,r1
    c.r[1] += 117;  // 06060F6C add #117,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06060F6E mov.b @r1,r3
    c.r[6] = ld32(0x06061004u);  // 06060F70 mov.l 0x06061004,r6
    c.r[1] = c.r[2];  // 06060F72 mov r2,r1
    c.r[1] += 79;  // 06060F74 add #79,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06060F76 mov.b @r1,r1
    c.r[3] = c.r[3] & 0xFFu;  // 06060F78 extu.b r3,r3
    c.r[3] += c.r[1];  // 06060F7A add r1,r3
    c.r[1] = c.r[2];  // 06060F7C mov r2,r1
    c.r[1] += 116;  // 06060F7E add #116,r1
    c.r[2] += 78;  // 06060F80 add #78,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06060F82 mov.b @r1,r1
    c.r[3] <<= 2;  // 06060F84 shll2 r3
    c.r[3] <<= 2;  // 06060F86 shll2 r3
    c.r[3] <<= 2;  // 06060F88 shll2 r3
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06060F8A mov.b @r2,r7
    c.r[1] = c.r[1] & 0xFFu;  // 06060F8C extu.b r1,r1
    c.r[2] = ld32(c.r[6]);  // 06060F8E mov.l @r6,r2
    c.r[1] += c.r[7];  // 06060F90 add r7,r1
    c.r[3] += c.r[2];  // 06060F92 add r2,r3
    c.r[0] = c.r[3];  // 06060F94 mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06060F96 mov.b @(r0,r1),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06060FECu);  // 06060F98 mov.w 0x06060FEC,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06060F9A extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 06060F9C cmp/eq r2,r1
    if (c.t) { goto L_06060FAA; }  // 06060F9E bt 0x06060FAA
L_06060FA0:
    c.r[2] = ld32(0x06060FF0u);  // 06060FA0 mov.l 0x06060FF0,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06060FA2 mov.b @r2,r1
    c.r[1] += 1;  // 06060FA4 add #1,r1
    st8(c.r[2], c.r[1]); goto L_06060FDC;  // 06060FA6 bra 0x06060FDC ; mov.b r1,@r2
L_06060FAA:
    c.r[2] = ld32(0x06060FF0u);  // 06060FAA mov.l 0x06060FF0,r2
    c.r[1] = 0x0u;  // 06060FAC mov #0,r1
    st8(c.r[2], c.r[1]); goto L_06060FDC;  // 06060FAE bra 0x06060FDC ; mov.b r1,@r2
L_06060FB2:
    c.r[1] = c.r[3];  // 06060FB2 mov r3,r1
    c.r[1] += 1;  // 06060FB4 add #1,r1
    st8(c.r[7], c.r[1]);  // 06060FB6 mov.b r1,@r7
    c.r[1] = ld32(0x06061008u);  // 06060FB8 mov.l 0x06061008,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06060FBA mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 06060FBC extu.b r2,r2
    c.r[1] = ld32(0x0606100Cu);  // 06060FBE mov.l 0x0606100C,r1
    c.r[1] = ld32(c.r[1]);  // 06060FC0 mov.l @r1,r1
    c.r[2] <<= 2;  // 06060FC2 shll2 r2
    c.r[2] <<= 2;  // 06060FC4 shll2 r2
    c.r[2] += c.r[1];  // 06060FC6 add r1,r2
    c.r[2] += 2;  // 06060FC8 add #2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06060FCA mov.b @r2,r1
    c.r[3] = ld32(0x06060FF4u);  // 06060FCC mov.l 0x06060FF4,r3
    st8(c.r[3], c.r[1]);  // 06060FCE mov.b r1,@r3
    c.r[1] = c.r[1] & 0xFFu;  // 06060FD0 extu.b r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06060FECu);  // 06060FD2 mov.w 0x06060FEC,r2
    c.t = c.r[1] == c.r[2];  // 06060FD4 cmp/eq r2,r1
    { const bool k = !c.t; c.r[1] = 0x0u; if (k) { goto L_06060FDC; } }  // 06060FD6 bf/s 0x06060FDC ; mov #0,r1
    st8(c.r[3], c.r[1]);  // 06060FDA mov.b r1,@r3
L_06060FDC:
    c.r[0] = ld32(0x06061010u);  // 06060FDC mov.l 0x06061010,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06060FE2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06060FE2u) return; }  // 06060FDE jsr @r0 ; nop
    c.r[15] = c.r[14];  // 06060FE2 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06060FE4 lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x06060FEEu);  // 06060FE6 mov.w 0x06060FEE,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06060FE8 rts ; mov.l @r15+,r14
}

void f_06061014(SH2Context& c) {
    ran[1464] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06061014 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06061016 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06061018 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0606101A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0606101C sts.l pr,@-r15
    c.r[15] -= 44;  // 0606101E add #-44,r15
    c.r[14] = c.r[15];  // 06061020 mov r15,r14
    c.r[0] = ld32(0x06061064u);  // 06061022 mov.l 0x06061064,r0
    c.r[6] = 0x28u;  // 06061024 mov #40,r6
    c.r[5] = 0x20u;  // 06061026 mov #32,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0606102Cu; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606102Cu) return; }  // 06061028 jsr @r0 ; mov r14,r4
    c.r[2] = c.r[14];  // 0606102C mov r14,r2
    c.r[2] += 40;  // 0606102E add #40,r2
    c.r[1] = 0x0u;  // 06061030 mov #0,r1
    st8(c.r[2], c.r[1]);  // 06061032 mov.b r1,@r2
    c.r[8] = 0x2u;  // 06061034 mov #2,r8
    c.r[10] = ld32(0x06061068u);  // 06061036 mov.l 0x06061068,r10
    c.r[9] = ld32(0x0606106Cu);  // 06061038 mov.l 0x0606106C,r9
    c.r[5] = c.r[8] & 0xFFFFu;  // 0606103A extu.w r8,r5
L_0606103C:
    { const uint32_t x = c.r[10]; c.pr = 0x06061040u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06061040u) return; }  // 0606103C jsr @r10 ; mov #0,r4
    c.r[5] = c.r[0];  // 06061040 mov r0,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06061046u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06061046u) return; }  // 06061042 jsr @r9 ; mov r14,r4
    c.r[8] += 1;  // 06061046 add #1,r8
    c.r[1] = 0x1Bu;  // 06061048 mov #27,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 0606104A cmp/gt r1,r8
    { const bool k = !c.t; c.r[5] = c.r[8] & 0xFFFFu; if (k) { SH2_POLL(c); goto L_0606103C; } }  // 0606104C bf/s 0x0606103C ; extu.w r8,r5
    c.r[14] += 44;  // 06061050 add #44,r14
    c.r[15] = c.r[14];  // 06061052 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06061054 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06061056 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06061058 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0606105A mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06061062u);  // 0606105C mov.w 0x06061062,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0606105E rts ; mov.l @r15+,r8
}

void f_06061070(SH2Context& c) {
    ran[1465] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06061070 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06061072 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06061074 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06061076 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06061078 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0606107A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0606107C sts.l pr,@-r15
    c.r[1] = ld32(0x06061154u);  // 0606107E mov.l 0x06061154,r1
    c.r[1] = ld32(c.r[1]);  // 06061080 mov.l @r1,r1
    c.r[1] += 1;  // 06061082 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06061084 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06061086 mov r1,r0
    c.t = c.r[0] == 0x1u;  // 06061088 cmp/eq #1,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_060610B6; } }  // 0606108A bt/s 0x060610B6 ; mov r15,r14
    c.r[12] = 0x1u;  // 0606108E mov #1,r12
    c.t = (int32_t)c.r[1] > (int32_t)c.r[12];  // 06061090 cmp/gt r12,r1
    { const bool k = c.t; c.t = c.r[0] == 0x2u; if (k) { goto L_0606109E; } }  // 06061092 bt/s 0x0606109E ; cmp/eq #2,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 06061096 cmp/eq #-1,r0
    if (!c.t) { goto L_06061134; }  // 06061098 bf 0x06061134
    goto L_060610A4;  // 0606109A bra 0x060610A4 ; nop
L_0606109E:
    if (!c.t) { goto L_06061134; }  // 0606109E bf 0x06061134
    goto L_060610CA;  // 060610A0 bra 0x060610CA ; nop
L_060610A4:
    c.r[3] = ld32(0x06061158u);  // 060610A4 mov.l 0x06061158,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060610A6 mov.b @r3,r2
    c.r[1] = c.r[2] & 0xFFu;  // 060610A8 extu.b r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060610AA tst r1,r1
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_0606113A; } }  // 060610AC bt/s 0x0606113A ; mov r2,r1
    c.r[1] -= 1;  // 060610B0 add #-1,r1
    st8(c.r[3], c.r[1]); goto L_0606113A;  // 060610B2 bra 0x0606113A ; mov.b r1,@r3
L_060610B6:
    c.r[7] = ld32(0x06061158u);  // 060610B6 mov.l 0x06061158,r7
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[7]);  // 060610B8 mov.b @r7,r3
    c.r[1] = 0x1Eu;  // 060610BA mov #30,r1
    c.r[2] = c.r[3] & 0xFFu;  // 060610BC extu.b r3,r2
    c.t = c.r[2] > c.r[1];  // 060610BE cmp/hi r1,r2
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_0606113A; } }  // 060610C0 bt/s 0x0606113A ; mov r3,r1
    c.r[1] += 1;  // 060610C4 add #1,r1
    st8(c.r[7], c.r[1]); goto L_0606113A;  // 060610C6 bra 0x0606113A ; mov.b r1,@r7
L_060610CA:
    c.r[1] = ld32(0x06061158u);  // 060610CA mov.l 0x06061158,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060610CC mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 060610CE extu.b r1,r2
    c.r[1] = ld32(0x0606115Cu);  // 060610D0 mov.l 0x0606115C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060610D2 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 060610D4 extu.b r1,r0
    c.r[1] = ld32(0x06061160u);  // 060610D6 mov.l 0x06061160,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060610D8 mov.b @(r0,r1),r1
    c.r[2] <<= 2;  // 060610DA shll2 r2
    c.r[2] <<= 2;  // 060610DC shll2 r2
    c.r[1] = c.r[1] & 0xFFu;  // 060610DE extu.b r1,r1
    c.r[2] += c.r[1];  // 060610E0 add r1,r2
    c.r[1] = c.r[2];  // 060610E2 mov r2,r1
    c.r[10] = c.r[1];  // 060610E4 mov r1,r10
    c.r[10] >>= 2;  // 060610E6 shlr2 r10
    c.t = c.r[10] & 1; c.r[10] >>= 1;  // 060610E8 shlr r10
    c.r[1] = ld32(0x06061164u);  // 060610EA mov.l 0x06061164,r1
    c.r[1] = ld32(c.r[1]);  // 060610EC mov.l @r1,r1
    c.r[11] = (uint32_t)(int16_t)ld16(0x0606114Eu);  // 060610EE mov.w 0x0606114E,r11
    c.r[10] += c.r[1];  // 060610F0 add r1,r10
    c.r[0] = c.r[10];  // 060610F2 mov r10,r0
    c.r[9] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 060610F4 mov.b @(r0,r11),r9
    c.r[5] = c.r[2];  // 060610F6 mov r2,r5
    c.r[4] = c.r[9] & 0xFFu;  // 060610F8 extu.b r9,r4
    c.r[8] = c.r[5];  // 060610FA mov r5,r8
    c.r[8] >>= 2;  // 060610FC shlr2 r8
    c.t = c.r[8] & 1; c.r[8] >>= 1;  // 060610FE shlr r8
    c.r[8] <<= 2;  // 06061100 shll2 r8
    c.r[8] += c.r[8];  // 06061102 add r8,r8
    c.r[8] -= c.r[2];  // 06061104 sub r2,r8
    c.r[8] += 7;  // 06061106 add #7,r8
    c.r[0] = ld32(0x06061168u);  // 06061108 mov.l 0x06061168,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0606110Eu; c.r[5] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606110Eu) return; }  // 0606110A jsr @r0 ; mov r8,r5
    c.r[0] &= 0x1u;  // 0606110E and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06061110 tst r0,r0
    { const bool k = c.t; c.r[5] = c.r[8]; if (k) { goto L_06061124; } }  // 06061112 bt/s 0x06061124 ; mov r8,r5
    c.r[0] = ld32(0x0606116Cu);  // 06061116 mov.l 0x0606116C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0606111Cu; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606111Cu) return; }  // 06061118 jsr @r0 ; mov r12,r4
    c.r[1] = c.r[0];  // 0606111C mov r0,r1
    c.r[1] = ~c.r[1];  // 0606111E not r1,r1
    c.r[1] &= c.r[9]; goto L_0606112E;  // 06061120 bra 0x0606112E ; and r9,r1
L_06061124:
    c.r[0] = ld32(0x0606116Cu);  // 06061124 mov.l 0x0606116C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0606112Au; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606112Au) return; }  // 06061126 jsr @r0 ; mov r12,r4
    c.r[1] = c.r[0];  // 0606112A mov r0,r1
    c.r[1] |= c.r[9];  // 0606112C or r9,r1
L_0606112E:
    c.r[0] = c.r[10];  // 0606112E mov r10,r0
    st8(c.r[0] + c.r[11], c.r[1]); goto L_0606113A;  // 06061130 bra 0x0606113A ; mov.b r1,@(r0,r11)
L_06061134:
    c.r[2] = ld32(0x06061158u);  // 06061134 mov.l 0x06061158,r2
    c.r[1] = 0x0u;  // 06061136 mov #0,r1
    st8(c.r[2], c.r[1]);  // 06061138 mov.b r1,@r2
L_0606113A:
    c.r[15] = c.r[14];  // 0606113A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0606113C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0606113E mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06061140 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06061142 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06061144 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06061146 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06061150u);  // 06061148 mov.w 0x06061150,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0606114A rts ; mov.l @r15+,r8
}

void f_06061170(SH2Context& c) {
    ran[1466] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06061170 mov.l r14,@-r15
    c.r[1] = ld32(0x06061250u);  // 06061172 mov.l 0x06061250,r1
    c.r[1] = ld32(c.r[1]);  // 06061174 mov.l @r1,r1
    c.r[1] += 1;  // 06061176 add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06061178 mov.b @r1,r2
    c.r[1] = 0x20u;  // 0606117A mov #32,r1
    c.r[2] += 16;  // 0606117C add #16,r2
    c.t = c.r[2] > c.r[1];  // 0606117E cmp/hi r1,r2
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06061238; } }  // 06061180 bt/s 0x06061238 ; mov r15,r14
    c.r[1] = c.r[2];  // 06061184 mov r2,r1
    c.r[1] += c.r[1];  // 06061186 add r1,r1
    c.r[0] = 0x06061194u;  // 06061188 mova 0x06061194,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0606118A mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 0606118C add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x06061200u: goto L_06061200; case 0x06061238u: goto L_06061238; case 0x060611D6u: goto L_060611D6; case 0x060611EAu: goto L_060611EA; case 0x0606122Cu: goto L_0606122C; case 0x06061214u: goto L_06061214; default: sh2_call(c, x); return; } }  // 0606118E jmp @r0 ; nop
L_060611D6:
    c.r[3] = ld32(0x06061254u);  // 060611D6 mov.l 0x06061254,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060611D8 mov.b @r3,r2
    c.r[1] = c.r[2] & 0xFFu;  // 060611DA extu.b r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060611DC tst r1,r1
    { const bool k = c.t; c.r[15] = c.r[14]; if (k) { goto L_06061246; } }  // 060611DE bt/s 0x06061246 ; mov r14,r15
    c.r[1] = c.r[2];  // 060611E2 mov r2,r1
    c.r[1] -= 1;  // 060611E4 add #-1,r1
    st8(c.r[3], c.r[1]); goto L_06061246;  // 060611E6 bra 0x06061246 ; mov.b r1,@r3
L_060611EA:
    c.r[7] = ld32(0x06061254u);  // 060611EA mov.l 0x06061254,r7
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[7]);  // 060611EC mov.b @r7,r3
    c.r[1] = 0x7Eu;  // 060611EE mov #126,r1
    c.r[2] = c.r[3] & 0xFFu;  // 060611F0 extu.b r3,r2
    c.t = c.r[2] > c.r[1];  // 060611F2 cmp/hi r1,r2
    { const bool k = c.t; c.r[15] = c.r[14]; if (k) { goto L_06061246; } }  // 060611F4 bt/s 0x06061246 ; mov r14,r15
    c.r[1] = c.r[3];  // 060611F8 mov r3,r1
    c.r[1] += 1;  // 060611FA add #1,r1
    st8(c.r[7], c.r[1]); goto L_06061246;  // 060611FC bra 0x06061246 ; mov.b r1,@r7
L_06061200:
    c.r[3] = ld32(0x06061254u);  // 06061200 mov.l 0x06061254,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06061202 mov.b @r3,r2
    c.r[1] = c.r[2] & 0xFFu;  // 06061204 extu.b r2,r1
    c.r[1] -= 16;  // 06061206 add #-16,r1
    c.t = (int32_t)c.r[1] > 0;  // 06061208 cmp/pl r1
    { const bool k = !c.t; c.r[1] = c.r[2]; if (k) { goto L_06061244; } }  // 0606120A bf/s 0x06061244 ; mov r2,r1
    c.r[1] -= 16;  // 0606120E add #-16,r1
    st8(c.r[3], c.r[1]); goto L_06061244;  // 06061210 bra 0x06061244 ; mov.b r1,@r3
L_06061214:
    c.r[7] = ld32(0x06061254u);  // 06061214 mov.l 0x06061254,r7
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06061216 mov.b @r7,r3
    c.r[1] = 0x7Fu;  // 06061218 mov #127,r1
    c.r[2] = c.r[3] & 0xFFu;  // 0606121A extu.b r3,r2
    c.r[2] += 16;  // 0606121C add #16,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0606121E cmp/gt r1,r2
    { const bool k = c.t; c.r[15] = c.r[14]; if (k) { goto L_06061246; } }  // 06061220 bt/s 0x06061246 ; mov r14,r15
    c.r[1] = c.r[3];  // 06061224 mov r3,r1
    c.r[1] += 16;  // 06061226 add #16,r1
    st8(c.r[7], c.r[1]); goto L_06061246;  // 06061228 bra 0x06061246 ; mov.b r1,@r7
L_0606122C:
    c.r[1] = ld32(0x06061258u);  // 0606122C mov.l 0x06061258,r1
    c.r[2] = ld32(c.r[1]);  // 0606122E mov.l @r1,r2
    c.r[1] = ld32(0x06061254u);  // 06061230 mov.l 0x06061254,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06061232 mov.b @r1,r1
    c.r[2] += 4; goto L_06061242;  // 06061234 bra 0x06061242 ; add #4,r2
L_06061238:
    c.r[1] = ld32(0x06061258u);  // 06061238 mov.l 0x06061258,r1
    c.r[1] = ld32(c.r[1]);  // 0606123A mov.l @r1,r1
    c.r[1] += 4;  // 0606123C add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606123E mov.b @r1,r1
    c.r[2] = ld32(0x06061254u);  // 06061240 mov.l 0x06061254,r2
L_06061242:
    st8(c.r[2], c.r[1]);  // 06061242 mov.b r1,@r2
L_06061244:
    c.r[15] = c.r[14];  // 06061244 mov r14,r15
L_06061246:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606124Cu);  // 06061246 mov.w 0x0606124C,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06061248 rts ; mov.l @r15+,r14
}

void f_0606125C(SH2Context& c) {
    ran[1467] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0606125C mov.l r14,@-r15
    c.r[1] = ld32(0x06061284u);  // 0606125E mov.l 0x06061284,r1
    c.r[1] = ld32(c.r[1]);  // 06061260 mov.l @r1,r1
    c.r[1] += 1;  // 06061262 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06061264 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06061266 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06061268 tst r1,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06061274; } }  // 0606126A bt/s 0x06061274 ; mov r15,r14
    c.r[2] = ld32(0x06061288u);  // 0606126E mov.l 0x06061288,r2
    c.r[1] = 0x47u; goto L_06061278;  // 06061270 bra 0x06061278 ; mov #71,r1
L_06061274:
    c.r[2] = ld32(0x06061288u);  // 06061274 mov.l 0x06061288,r2
    c.r[1] = 0x45u;  // 06061276 mov #69,r1
L_06061278:
    st8(c.r[2], c.r[1]);  // 06061278 mov.b r1,@r2
    c.r[15] = c.r[14];  // 0606127A mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x06061282u);  // 0606127C mov.w 0x06061282,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0606127E rts ; mov.l @r15+,r14
}

void f_06061298(SH2Context& c) {
    ran[1468] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06061298 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0606129A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0606129C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0606129E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060612A0 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060612A2 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060612A4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060612A6 sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x06061376u);  // 060612A8 mov.w 0x06061376,r3
    c.r[15] += c.r[3];  // 060612AA add r3,r15
    c.r[14] = c.r[15];  // 060612AC mov r15,r14
    c.r[11] = (uint32_t)(int16_t)ld16(0x06061378u);  // 060612AE mov.w 0x06061378,r11
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606137Au);  // 060612B0 mov.w 0x0606137A,r0
    st32(c.r[0] + c.r[14], c.r[11]);  // 060612B2 mov.l r11,@(r0,r14)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606137Au);  // 060612B4 mov.w 0x0606137A,r0
    c.r[0] += c.r[14];  // 060612B6 add r14,r0
    c.r[1] = 0x0u;  // 060612B8 mov #0,r1
    c.r[2] = 0x0u;  // 060612BA mov #0,r2
    c.r[11] = (uint32_t)(int16_t)ld16(0x0606137Au);  // 060612BC mov.w 0x0606137A,r11
    c.r[11] += c.r[14];  // 060612BE add r14,r11
    c.r[13] = (uint32_t)(int16_t)ld16(0x0606137Cu);  // 060612C0 mov.w 0x0606137C,r13
    c.r[7] = (uint32_t)(int16_t)ld16(0x0606137Eu);  // 060612C2 mov.w 0x0606137E,r7
    c.r[9] = c.r[14];  // 060612C4 mov r14,r9
    c.r[3] = ld32(c.r[0]);  // 060612C6 mov.l @r0,r3
    c.r[9] += c.r[7];  // 060612C8 add r7,r9
    c.r[3] += c.r[14];  // 060612CA add r14,r3
    st32(c.r[3], c.r[1]);  // 060612CC mov.l r1,@r3
    st32(c.r[3] + 4, c.r[2]);  // 060612CE mov.l r2,@(4,r3)
    c.r[1] = ld32(0x06061384u);  // 060612D0 mov.l 0x06061384,r1
    c.r[2] = c.r[9];  // 060612D2 mov r9,r2
    c.r[0] = ld32(c.r[11]);  // 060612D4 mov.l @r11,r0
    c.r[2] += 8;  // 060612D6 add #8,r2
    st32(c.r[0] + c.r[14], c.r[1]);  // 060612D8 mov.l r1,@(r0,r14)
    c.r[1] = ld32(0x06061388u);  // 060612DA mov.l 0x06061388,r1
    c.r[0] = c.r[14];  // 060612DC mov r14,r0
    st32(c.r[0] + c.r[13], c.r[1]);  // 060612DE mov.l r1,@(r0,r13)
    c.r[1] = ld32(0x0606138Cu);  // 060612E0 mov.l 0x0606138C,r1
    st32(c.r[0] + c.r[7], c.r[1]);  // 060612E2 mov.l r1,@(r0,r7)
    c.r[1] = ld32(0x06061390u);  // 060612E4 mov.l 0x06061390,r1
    st32(c.r[9] + 4, c.r[1]);  // 060612E6 mov.l r1,@(4,r9)
    c.r[1] = ld32(0x06061394u);  // 060612E8 mov.l 0x06061394,r1
    st32(c.r[9] + 8, c.r[1]);  // 060612EA mov.l r1,@(8,r9)
    c.r[1] = ld32(0x06061398u);  // 060612EC mov.l 0x06061398,r1
    st32(c.r[2] + 4, c.r[1]);  // 060612EE mov.l r1,@(4,r2)
    c.r[0] = 0x0u;  // 060612F0 mov #0,r0
    c.r[11] = (uint32_t)(int16_t)ld16(0x06061380u);  // 060612F2 mov.w 0x06061380,r11
    c.r[11] += c.r[14];  // 060612F4 add r14,r11
    st32(c.r[11], c.r[0]);  // 060612F6 mov.l r0,@r11
    c.r[1] = ld32(0x0606139Cu);  // 060612F8 mov.l 0x0606139C,r1
    c.r[11] = (uint32_t)(int16_t)ld16(0x06061382u);  // 060612FA mov.w 0x06061382,r11
    c.r[2] = ld32(c.r[1]);  // 060612FC mov.l @r1,r2
    c.r[11] += c.r[14];  // 060612FE add r14,r11
    c.r[1] = c.r[2];  // 06061300 mov r2,r1
    c.r[1] += 2;  // 06061302 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06061304 mov.b @r1,r1
    c.r[2] += 1;  // 06061306 add #1,r2
    st32(c.r[11], c.r[1]);  // 06061308 mov.l r1,@r11
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606130A mov.b @r2,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0606130C extu.b r1,r2
    c.r[0] = c.r[2];  // 0606130E mov r2,r0
    c.t = c.r[0] == 0x1u;  // 06061310 cmp/eq #1,r0
    { const bool k = c.t; c.r[12] = 0x0u; if (k) { goto L_06061334; } }  // 06061312 bt/s 0x06061334 ; mov #0,r12
    c.r[6] = 0x1u;  // 06061316 mov #1,r6
    c.t = (int32_t)c.r[2] > (int32_t)c.r[6];  // 06061318 cmp/gt r6,r2
    { const bool k = c.t; c.t = c.r[0] == 0x2u; if (k) { goto L_0606132C; } }  // 0606131A bt/s 0x0606132C ; cmp/eq #2,r0
    c.t = (c.r[2] & c.r[2]) == 0;  // 0606131E tst r2,r2
    { const bool k = !c.t; c.r[1] = 0x10u; if (k) { goto L_06061328; } }  // 06061320 bf/s 0x06061328 ; mov #16,r1
    goto L_06061448;  // 06061324 bra 0x06061448 ; nop
L_06061328:
    c.r[2] = c.r[12]; goto L_060614F0;  // 06061328 bra 0x060614F0 ; mov r12,r2
L_0606132C:
    { const bool k = c.t; c.r[6] = 0x20u; if (k) { goto L_060613A8; } }  // 0606132C bt/s 0x060613A8 ; mov #32,r6
    c.r[1] = 0x10u; goto L_060614EE;  // 06061330 bra 0x060614EE ; mov #16,r1
L_06061334:
    c.r[1] = ld32(0x060613A0u);  // 06061334 mov.l 0x060613A0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06061336 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06061338 extu.b r1,r0
    c.r[1] = ld32(0x060613A4u);  // 0606133A mov.l 0x060613A4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606133C mov.b @(r0,r1),r1
    c.r[1] += 1;  // 0606133E add #1,r1
    c.r[12] = c.r[1] & 0xFFu;  // 06061340 extu.b r1,r12
    c.r[1] = 0x10u;  // 06061342 mov #16,r1
    c.t = c.r[12] > c.r[1];  // 06061344 cmp/hi r1,r12
    { const bool k = c.t; c.r[1] = c.r[12]; if (k) { goto L_0606134E; } }  // 06061346 bt/s 0x0606134E ; mov r12,r1
    goto L_060614EC;  // 0606134A bra 0x060614EC ; nop
L_0606134E:
    c.r[11] = (uint32_t)(int16_t)ld16(0x06061380u);  // 0606134E mov.w 0x06061380,r11
    c.r[11] += c.r[14];  // 06061350 add r14,r11
    c.r[1] -= 16;  // 06061352 add #-16,r1
    c.r[12] = c.r[1] & 0xFFu;  // 06061354 extu.b r1,r12
    c.r[1] = 0x7u;  // 06061356 mov #7,r1
    c.t = c.r[12] > c.r[1];  // 06061358 cmp/hi r1,r12
    { const bool k = !c.t; st32(c.r[11], c.r[2]); if (k) { goto L_06061366; } }  // 0606135A bf/s 0x06061366 ; mov.l r2,@r11
    c.r[1] = c.r[12];  // 0606135E mov r12,r1
    c.r[1] -= 1;  // 06061360 add #-1,r1
    c.r[12] = c.r[1] & 0xFFu; goto L_060614EC;  // 06061362 bra 0x060614EC ; extu.b r1,r12
L_06061366:
    c.r[0] = c.r[12];  // 06061366 mov r12,r0
    c.t = c.r[0] == 0x7u;  // 06061368 cmp/eq #7,r0
    if (c.t) { goto L_06061370; }  // 0606136A bt 0x06061370
    goto L_060614EC;  // 0606136C bra 0x060614EC ; nop
L_06061370:
    c.r[12] = 0x11u;  // 06061370 mov #17,r12
    c.r[1] = 0x10u; goto L_060614EE;  // 06061372 bra 0x060614EE ; mov #16,r1
L_060613A8:
    c.r[10] = ld32(0x06061530u);  // 060613A8 mov.l 0x06061530,r10
    c.r[1] = ld32(0x06061534u);  // 060613AA mov.l 0x06061534,r1
    c.r[11] = (uint32_t)(int16_t)ld16(0x0606152Au);  // 060613AC mov.w 0x0606152A,r11
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060613AE mov.b @r1,r1
    c.r[11] += c.r[14];  // 060613B0 add r14,r11
    st8(c.r[10], c.r[1]);  // 060613B2 mov.b r1,@r10
    c.r[0] = ld32(c.r[11]);  // 060613B4 mov.l @r11,r0
    c.r[8] = ld32(0x06061538u);  // 060613B6 mov.l 0x06061538,r8
    c.r[1] = ld32(c.r[0] + c.r[14]);  // 060613B8 mov.l @(r0,r14),r1
    c.r[10] += 1;  // 060613BA add #1,r10
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 060613BC mov.b @r1+,r2
    c.r[0] = c.r[14];  // 060613BE mov r14,r0
    st8(c.r[10], c.r[2]);  // 060613C0 mov.b r2,@r10
    c.r[2] = c.r[10];  // 060613C2 mov r10,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 060613C4 mov.b @r1+,r3
    c.r[2] += 1;  // 060613C6 add #1,r2
    st8(c.r[2], c.r[3]);  // 060613C8 mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 060613CA mov.b @r1+,r3
    c.r[2] += 1;  // 060613CC add #1,r2
    st8(c.r[2], c.r[3]);  // 060613CE mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 060613D0 mov.b @r1+,r3
    c.r[2] += 1;  // 060613D2 add #1,r2
    st8(c.r[2], c.r[3]);  // 060613D4 mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 060613D6 mov.b @r1+,r3
    c.r[2] += 1;  // 060613D8 add #1,r2
    st8(c.r[2], c.r[3]);  // 060613DA mov.b r3,@r2
    c.r[2] += 1;  // 060613DC add #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060613DE mov.b @r1,r1
    c.r[10] = c.r[2];  // 060613E0 mov r2,r10
    st8(c.r[2], c.r[1]);  // 060613E2 mov.b r1,@r2
    c.r[1] = ld32(c.r[0] + c.r[13]);  // 060613E4 mov.l @(r0,r13),r1
    c.r[10] += 1;  // 060613E6 add #1,r10
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 060613E8 mov.b @r1+,r2
    st8(c.r[10], c.r[2]);  // 060613EA mov.b r2,@r10
    c.r[2] = c.r[10];  // 060613EC mov r10,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 060613EE mov.b @r1+,r3
    c.r[2] += 1;  // 060613F0 add #1,r2
    st8(c.r[2], c.r[3]);  // 060613F2 mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 060613F4 mov.b @r1+,r3
    c.r[2] += 1;  // 060613F6 add #1,r2
    st8(c.r[2], c.r[3]);  // 060613F8 mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 060613FA mov.b @r1+,r3
    c.r[2] += 1;  // 060613FC add #1,r2
    st8(c.r[2], c.r[3]);  // 060613FE mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 06061400 mov.b @r1+,r3
    c.r[2] += 1;  // 06061402 add #1,r2
    st8(c.r[2], c.r[3]);  // 06061404 mov.b r3,@r2
    c.r[2] += 1;  // 06061406 add #1,r2
    c.r[10] = c.r[2];  // 06061408 mov r2,r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606140A mov.b @r1,r1
    c.r[10] += 1;  // 0606140C add #1,r10
    st8(c.r[2], c.r[1]);  // 0606140E mov.b r1,@r2
    c.r[5] = ld32(c.r[0] + c.r[7]);  // 06061410 mov.l @(r0,r7),r5
    { const uint32_t x = c.r[8]; c.pr = 0x06061416u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06061416u) return; }  // 06061412 jsr @r8 ; mov r10,r4
    c.r[10] += 32;  // 06061416 add #32,r10
    c.r[6] = 0x20u;  // 06061418 mov #32,r6
    c.r[5] = ld32(c.r[9] + 4);  // 0606141A mov.l @(4,r9),r5
    { const uint32_t x = c.r[8]; c.pr = 0x06061420u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06061420u) return; }  // 0606141C jsr @r8 ; mov r10,r4
    c.r[10] += 32;  // 06061420 add #32,r10
    c.r[6] = 0x20u;  // 06061422 mov #32,r6
    c.r[5] = ld32(c.r[9] + 8);  // 06061424 mov.l @(8,r9),r5
    { const uint32_t x = c.r[8]; c.pr = 0x0606142Au; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606142Au) return; }  // 06061426 jsr @r8 ; mov r10,r4
    c.r[10] += 32;  // 0606142A add #32,r10
    c.r[6] = 0x20u;  // 0606142C mov #32,r6
    c.r[5] = ld32(c.r[9] + 12);  // 0606142E mov.l @(12,r9),r5
    { const uint32_t x = c.r[8]; c.pr = 0x06061434u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06061434u) return; }  // 06061430 jsr @r8 ; mov r10,r4
    c.r[1] = ld32(0x0606153Cu);  // 06061434 mov.l 0x0606153C,r1
    c.r[10] += c.r[1];  // 06061436 add r1,r10
    c.r[5] = ld32(0x06061530u);  // 06061438 mov.l 0x06061530,r5
    c.r[4] = ld32(0x06061540u);  // 0606143A mov.l 0x06061540,r4
    c.r[7] = 0x0u;  // 0606143C mov #0,r7
    c.r[11] = ld32(0x06061544u);  // 0606143E mov.l 0x06061544,r11
    { const uint32_t x = c.r[11]; c.pr = 0x06061444u; c.r[6] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06061444u) return; }  // 06061440 jsr @r11 ; mov r10,r6
    c.r[1] = 0x10u; goto L_060614EE;  // 06061444 bra 0x060614EE ; mov #16,r1
L_06061448:
    c.r[8] = ld32(0x06061530u);  // 06061448 mov.l 0x06061530,r8
    c.r[4] = ld32(0x06061540u);  // 0606144A mov.l 0x06061540,r4
    c.r[5] = c.r[8];  // 0606144C mov r8,r5
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606152Cu);  // 0606144E mov.w 0x0606152C,r0
    c.r[0] += c.r[14];  // 06061450 add r14,r0
    c.r[11] = ld32(0x06061548u);  // 06061452 mov.l 0x06061548,r11
    { const uint32_t x = c.r[11]; c.pr = 0x06061458u; st32(c.r[0], c.r[7]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06061458u) return; }  // 06061454 jsr @r11 ; mov.l r7,@r0
    c.r[1] = c.r[0];  // 06061458 mov r0,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606152Cu);  // 0606145A mov.w 0x0606152C,r0
    c.r[0] += c.r[14];  // 0606145C add r14,r0
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606145E tst r1,r1
    { const bool k = !c.t; c.r[7] = ld32(c.r[0]); if (k) { goto L_060614EC; } }  // 06061460 bf/s 0x060614EC ; mov.l @r0,r7
    c.r[10] = c.r[8];  // 06061464 mov r8,r10
    c.r[2] = ld32(0x06061534u);  // 06061466 mov.l 0x06061534,r2
    c.r[11] = (uint32_t)(int16_t)ld16(0x0606152Au);  // 06061468 mov.w 0x0606152A,r11
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]); c.r[10] += 1;  // 0606146A mov.b @r10+,r1
    c.r[11] += c.r[14];  // 0606146C add r14,r11
    st8(c.r[2], c.r[1]);  // 0606146E mov.b r1,@r2
    c.r[0] = ld32(c.r[11]);  // 06061470 mov.l @r11,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[10]); c.r[10] += 1;  // 06061472 mov.b @r10+,r2
    c.r[8] = ld32(0x06061538u);  // 06061474 mov.l 0x06061538,r8
    c.r[1] = ld32(c.r[0] + c.r[14]);  // 06061476 mov.l @(r0,r14),r1
    c.r[3] = c.r[10];  // 06061478 mov r10,r3
    st8(c.r[1], c.r[2]);  // 0606147A mov.b r2,@r1
    c.r[1] += 1;  // 0606147C add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]); c.r[3] += 1;  // 0606147E mov.b @r3+,r2
    c.r[0] = c.r[14];  // 06061480 mov r14,r0
    st8(c.r[1], c.r[2]);  // 06061482 mov.b r2,@r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]); c.r[3] += 1;  // 06061484 mov.b @r3+,r2
    c.r[1] += 1;  // 06061486 add #1,r1
    st8(c.r[1], c.r[2]);  // 06061488 mov.b r2,@r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]); c.r[3] += 1;  // 0606148A mov.b @r3+,r2
    c.r[1] += 1;  // 0606148C add #1,r1
    st8(c.r[1], c.r[2]);  // 0606148E mov.b r2,@r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]); c.r[3] += 1;  // 06061490 mov.b @r3+,r2
    c.r[1] += 1;  // 06061492 add #1,r1
    st8(c.r[1], c.r[2]);  // 06061494 mov.b r2,@r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]); c.r[3] += 1;  // 06061496 mov.b @r3+,r2
    c.r[1] += 1;  // 06061498 add #1,r1
    st8(c.r[1], c.r[2]);  // 0606149A mov.b r2,@r1
    c.r[1] = ld32(c.r[0] + c.r[13]);  // 0606149C mov.l @(r0,r13),r1
    c.r[10] = c.r[3];  // 0606149E mov r3,r10
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[10]); c.r[10] += 1;  // 060614A0 mov.b @r10+,r2
    c.r[6] = 0x20u;  // 060614A2 mov #32,r6
    st8(c.r[1], c.r[2]);  // 060614A4 mov.b r2,@r1
    c.r[3] = c.r[10];  // 060614A6 mov r10,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]); c.r[3] += 1;  // 060614A8 mov.b @r3+,r2
    c.r[1] += 1;  // 060614AA add #1,r1
    st8(c.r[1], c.r[2]);  // 060614AC mov.b r2,@r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]); c.r[3] += 1;  // 060614AE mov.b @r3+,r2
    c.r[1] += 1;  // 060614B0 add #1,r1
    st8(c.r[1], c.r[2]);  // 060614B2 mov.b r2,@r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]); c.r[3] += 1;  // 060614B4 mov.b @r3+,r2
    c.r[1] += 1;  // 060614B6 add #1,r1
    st8(c.r[1], c.r[2]);  // 060614B8 mov.b r2,@r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]); c.r[3] += 1;  // 060614BA mov.b @r3+,r2
    c.r[1] += 1;  // 060614BC add #1,r1
    st8(c.r[1], c.r[2]);  // 060614BE mov.b r2,@r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]); c.r[3] += 1;  // 060614C0 mov.b @r3+,r2
    c.r[1] += 1;  // 060614C2 add #1,r1
    st8(c.r[1], c.r[2]);  // 060614C4 mov.b r2,@r1
    c.r[10] = c.r[3];  // 060614C6 mov r3,r10
    c.r[4] = ld32(c.r[0] + c.r[7]);  // 060614C8 mov.l @(r0,r7),r4
    { const uint32_t x = c.r[8]; c.pr = 0x060614CEu; c.r[5] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060614CEu) return; }  // 060614CA jsr @r8 ; mov r10,r5
    c.r[10] += 32;  // 060614CE add #32,r10
    c.r[6] = 0x20u;  // 060614D0 mov #32,r6
    c.r[4] = ld32(c.r[9] + 4);  // 060614D2 mov.l @(4,r9),r4
    { const uint32_t x = c.r[8]; c.pr = 0x060614D8u; c.r[5] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060614D8u) return; }  // 060614D4 jsr @r8 ; mov r10,r5
    c.r[10] += 32;  // 060614D8 add #32,r10
    c.r[6] = 0x20u;  // 060614DA mov #32,r6
    c.r[4] = ld32(c.r[9] + 8);  // 060614DC mov.l @(8,r9),r4
    { const uint32_t x = c.r[8]; c.pr = 0x060614E2u; c.r[5] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060614E2u) return; }  // 060614DE jsr @r8 ; mov r10,r5
    c.r[10] += 32;  // 060614E2 add #32,r10
    c.r[6] = 0x20u;  // 060614E4 mov #32,r6
    c.r[4] = ld32(c.r[9] + 12);  // 060614E6 mov.l @(12,r9),r4
    { const uint32_t x = c.r[8]; c.pr = 0x060614ECu; c.r[5] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060614ECu) return; }  // 060614E8 jsr @r8 ; mov r10,r5
L_060614EC:
    c.r[1] = 0x10u;  // 060614EC mov #16,r1
L_060614EE:
    c.r[2] = c.r[12];  // 060614EE mov r12,r2
L_060614F0:
    c.r[2] -= 1;  // 060614F0 add #-1,r2
    c.t = c.r[2] > c.r[1];  // 060614F2 cmp/hi r1,r2
    { const bool k = !c.t; c.r[1] = c.r[2]; if (k) { goto L_060614FC; } }  // 060614F4 bf/s 0x060614FC ; mov r2,r1
    goto L_060623A0;  // 060614F8 bra 0x060623A0 ; nop
L_060614FC:
    c.r[1] += c.r[1];  // 060614FC add r1,r1
    c.r[0] = 0x06061508u;  // 060614FE mova 0x06061508,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06061500 mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 06061502 add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x0606154Cu: goto L_0606154C; case 0x0606158Au: goto L_0606158A; case 0x0606175Cu: goto L_0606175C; case 0x0606179Au: goto L_0606179A; case 0x06061A30u: goto L_06061A30; case 0x06061A62u: goto L_06061A62; case 0x06061B58u: goto L_06061B58; case 0x06061C04u: goto L_06061C04; case 0x06061E12u: goto L_06061E12; case 0x06061E40u: goto L_06061E40; case 0x06061EA0u: goto L_06061EA0; case 0x06061ED4u: goto L_06061ED4; case 0x06061F08u: goto L_06061F08; case 0x06062108u: goto L_06062108; case 0x06062148u: goto L_06062148; case 0x06062192u: goto L_06062192; case 0x06062290u: goto L_06062290; default: sh2_call(c, x); return; } }  // 06061504 jmp @r0 ; nop
L_0606154C:
    c.r[11] = (uint32_t)(int16_t)ld16(0x06061620u);  // 0606154C mov.w 0x06061620,r11
    c.r[11] += c.r[14];  // 0606154E add r14,r11
    c.r[0] = ld32(c.r[11]);  // 06061550 mov.l @r11,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06061622u);  // 06061552 mov.w 0x06061622,r1
    c.r[0] <<= 2;  // 06061554 shll2 r0
    c.r[0] += c.r[0];  // 06061556 add r0,r0
    st32(c.r[11], c.r[0]);  // 06061558 mov.l r0,@r11
    c.r[11] = (uint32_t)(int16_t)ld16(0x06061620u);  // 0606155A mov.w 0x06061620,r11
    c.r[11] += c.r[14];  // 0606155C add r14,r11
    c.r[0] = ld32(c.r[11]);  // 0606155E mov.l @r11,r0
    c.r[1] += c.r[14];  // 06061560 add r14,r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 06061562 mov.l @(r0,r1),r2
    c.r[2] += 30;  // 06061564 add #30,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06061624u);  // 06061566 mov.w 0x06061624,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06061568 mov.b @r2,r1
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 0606156A mov.l @(r0,r14),r0
    c.r[13] = c.r[1] & 0xFFu;  // 0606156C extu.b r1,r13
    c.r[13] += c.r[0];  // 0606156E add r0,r13
    c.t = (int32_t)c.r[13] >= 0;  // 06061570 cmp/pz r13
    { const bool k = c.t; c.r[1] = 0xFFFFFF93u; if (k) { goto L_0606157A; } }  // 06061572 bt/s 0x0606157A ; mov #-109,r1
    goto L_060623A4;  // 06061576 bra 0x060623A4 ; nop
L_0606157A:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06061626u);  // 0606157A mov.w 0x06061626,r1
    c.t = (int32_t)c.r[13] > (int32_t)c.r[1];  // 0606157C cmp/gt r1,r13
    { const bool k = !c.t; c.r[1] = 0x0u; if (k) { goto L_06061586; } }  // 0606157E bf/s 0x06061586 ; mov #0,r1
    goto L_060623A4;  // 06061582 bra 0x060623A4 ; nop
L_06061586:
    st8(c.r[2], c.r[13]); goto L_060623A6;  // 06061586 bra 0x060623A6 ; mov.b r13,@r2
L_0606158A:
    c.r[12] = (uint32_t)(int16_t)ld16(0x06061622u);  // 0606158A mov.w 0x06061622,r12
    c.r[12] += c.r[14];  // 0606158C add r14,r12
    c.r[11] = (uint32_t)(int16_t)ld16(0x06061620u);  // 0606158E mov.w 0x06061620,r11
    c.r[11] += c.r[14];  // 06061590 add r14,r11
    c.r[13] = ld32(c.r[11]);  // 06061592 mov.l @r11,r13
    c.r[0] = c.r[12];  // 06061594 mov r12,r0
    c.r[13] <<= 2;  // 06061596 shll2 r13
    c.r[13] += c.r[13];  // 06061598 add r13,r13
    c.r[2] = ld32(c.r[0] + c.r[13]);  // 0606159A mov.l @(r0,r13),r2
    c.r[1] = c.r[2];  // 0606159C mov r2,r1
    c.r[1] += 10;  // 0606159E add #10,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060615A0 mov.w @r1,r1
    c.r[9] = c.r[1] & 0xFFFFu;  // 060615A2 extu.w r1,r9
    c.t = (c.r[9] & c.r[9]) == 0;  // 060615A4 tst r9,r9
    { const bool k = !c.t; c.r[2] += 2; if (k) { goto L_060615AE; } }  // 060615A6 bf/s 0x060615AE ; add #2,r2
    goto L_060616C8;  // 060615AA bra 0x060616C8 ; nop
L_060615AE:
    c.r[11] = (uint32_t)(int16_t)ld16(0x06061624u);  // 060615AE mov.w 0x06061624,r11
    c.r[11] += c.r[14];  // 060615B0 add r14,r11
    c.r[11] = ld32(c.r[11]);  // 060615B2 mov.l @r11,r11
    c.t = (int32_t)c.r[11] >= 0;  // 060615B4 cmp/pz r11
    c.r[11] = 0x1u;  // 060615B6 mov #1,r11
    c.r[0] = (uint32_t)(int16_t)ld16(0x06061624u);  // 060615B8 mov.w 0x06061624,r0
    c.r[0] += c.r[14];  // 060615BA add r14,r0
    { const bool k = c.t; st32(c.r[0], c.r[11]); if (k) { goto L_060615C6; } }  // 060615BC bt/s 0x060615C6 ; mov.l r11,@r0
    c.r[11] = 0xFFFFFFFFu;  // 060615C0 mov #-1,r11
    c.r[0] = (uint32_t)(int16_t)ld16(0x06061624u);  // 060615C2 mov.w 0x06061624,r0
    st32(c.r[0] + c.r[14], c.r[11]);  // 060615C4 mov.l r11,@(r0,r14)
L_060615C6:
    c.r[4] = ld32(0x0606162Cu);  // 060615C6 mov.l 0x0606162C,r4
    c.r[8] = ld32(0x06061630u);  // 060615C8 mov.l 0x06061630,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060615CEu; c.r[5] = 0x1Bu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060615CEu) return; }  // 060615CA jsr @r8 ; mov #27,r5
    c.r[1] = c.r[0];  // 060615CE mov r0,r1
    c.r[5] = c.r[9];  // 060615D0 mov r9,r5
    { const uint32_t x = c.r[8]; c.pr = 0x060615D6u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060615D6u) return; }  // 060615D2 jsr @r8 ; mov r1,r4
    c.r[10] = c.r[0];  // 060615D6 mov r0,r10
    c.r[10] += 38;  // 060615D8 add #38,r10
    c.r[5] = c.r[10];  // 060615DA mov r10,r5
    c.r[0] = ld32(0x06061634u);  // 060615DC mov.l 0x06061634,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060615E2u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060615E2u) return; }  // 060615DE jsr @r0 ; mov r14,r4
    c.r[1] = c.r[0];  // 060615E2 mov r0,r1
    c.r[10] = c.r[1];  // 060615E4 mov r1,r10
    c.r[10] += 2;  // 060615E6 add #2,r10
    c.r[11] = (uint32_t)(int16_t)ld16(0x06061628u);  // 060615E8 mov.w 0x06061628,r11
    c.r[11] += c.r[14];  // 060615EA add r14,r11
    st32(c.r[11], c.r[10]);  // 060615EC mov.l r10,@r11
    c.r[7] = (uint32_t)(int16_t)ld16(0x0606162Au);  // 060615EE mov.w 0x0606162A,r7
    c.r[3] = c.r[12];  // 060615F0 mov r12,r3
    c.r[2] = c.r[13];  // 060615F2 mov r13,r2
    c.r[6] = c.r[1];  // 060615F4 mov r1,r6
    c.r[6] += 3;  // 060615F6 add #3,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 060615F8 mov.b @r10,r1
L_060615FA:
    c.r[13] = c.r[1] & 0xFFu;  // 060615FA extu.b r1,r13
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 060615FC mov.b @r6,r1
    c.r[13] <<= 8;  // 060615FE shll8 r13
    c.r[1] = c.r[1] & 0xFFu;  // 06061600 extu.b r1,r1
    c.r[13] |= c.r[1];  // 06061602 or r1,r13
    c.r[13] &= c.r[7];  // 06061604 and r7,r13
    c.t = (c.r[13] & c.r[13]) == 0;  // 06061606 tst r13,r13
    { const bool k = c.t; c.r[6] += 4; if (k) { goto L_0606163A; } }  // 06061608 bt/s 0x0606163A ; add #4,r6
    c.r[0] = c.r[3];  // 0606160C mov r3,r0
    c.r[1] = ld32(c.r[0] + c.r[2]);  // 0606160E mov.l @(r0,r2),r1
    c.r[1] += 2;  // 06061610 add #2,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06061612 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06061614 extu.w r1,r1
    c.t = c.r[13] == c.r[1];  // 06061616 cmp/eq r1,r13
    if (c.t) { goto L_06061638; }  // 06061618 bt 0x06061638
    c.r[10] += 4;  // 0606161A add #4,r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]); SH2_POLL(c); goto L_060615FA;  // 0606161C bra 0x060615FA ; mov.b @r10,r1
L_06061638:
    c.t = (c.r[13] & c.r[13]) == 0;  // 06061638 tst r13,r13
L_0606163A:
    if (c.t) { goto L_060616EC; }  // 0606163A bt 0x060616EC
    c.r[11] = (uint32_t)(int16_t)ld16(0x06061744u);  // 0606163C mov.w 0x06061744,r11
    c.r[11] += c.r[14];  // 0606163E add r14,r11
    c.r[11] = ld32(c.r[11]);  // 06061640 mov.l @r11,r11
    c.t = (int32_t)c.r[11] > 0;  // 06061642 cmp/pl r11
    if (c.t) { goto L_0606164E; }  // 06061644 bt 0x0606164E
    c.r[0] = (uint32_t)(int16_t)ld16(0x06061746u);  // 06061646 mov.w 0x06061746,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06061648 mov.l @(r0,r14),r0
    c.t = c.r[10] == c.r[0];  // 0606164A cmp/eq r0,r10
    if (c.t) { goto L_060616EC; }  // 0606164C bt 0x060616EC
L_0606164E:
    c.r[11] = (uint32_t)(int16_t)ld16(0x06061744u);  // 0606164E mov.w 0x06061744,r11
    c.r[11] += c.r[14];  // 06061650 add r14,r11
    c.r[1] = ld32(c.r[11]);  // 06061652 mov.l @r11,r1
    c.r[9] = ld32(0x06061754u);  // 06061654 mov.l 0x06061754,r9
L_06061656:
    c.r[1] <<= 2;  // 06061656 shll2 r1
    c.r[10] += c.r[1];  // 06061658 add r1,r10
    c.r[2] = c.r[10];  // 0606165A mov r10,r2
    c.r[5] = 0x1Du;  // 0606165C mov #29,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]); c.r[2] += 1;  // 0606165E mov.b @r2+,r1
    c.r[4] = ld32(0x06061758u);  // 06061660 mov.l 0x06061758,r4
    c.r[13] = c.r[1] & 0xFFu;  // 06061662 extu.b r1,r13
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06061664 mov.b @r2,r1
    c.r[13] <<= 8;  // 06061666 shll8 r13
    c.r[1] = c.r[1] & 0xFFu;  // 06061668 extu.b r1,r1
    c.r[13] |= c.r[1];  // 0606166A or r1,r13
    c.r[1] = (uint32_t)(int16_t)ld16(0x06061748u);  // 0606166C mov.w 0x06061748,r1
    c.r[13] &= c.r[1];  // 0606166E and r1,r13
    { const uint32_t x = c.r[9]; c.pr = 0x06061674u; c.r[8] = c.r[13] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06061674u) return; }  // 06061670 jsr @r9 ; extu.w r13,r8
    c.r[1] = c.r[0];  // 06061674 mov r0,r1
    c.r[5] = c.r[8];  // 06061676 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0606167Cu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606167Cu) return; }  // 06061678 jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 0606167C mov r0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606167E mov.b @r1,r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x0606174Au);  // 06061680 mov.w 0x0606174A,r12
    c.r[12] &= c.r[1];  // 06061682 and r1,r12
    c.r[12] >>= 2;  // 06061684 shlr2 r12
    c.r[12] >>= 2;  // 06061686 shlr2 r12
    c.r[12] >>= 2;  // 06061688 shlr2 r12
    c.r[2] = c.r[12] & 0xFFu;  // 0606168A extu.b r12,r2
    c.r[1] = 0x1u;  // 0606168C mov #1,r1
    c.t = c.r[2] > c.r[1];  // 0606168E cmp/hi r1,r2
    { const bool k = !c.t; c.t = (c.r[13] & c.r[13]) == 0; if (k) { goto L_060616AA; } }  // 06061690 bf/s 0x060616AA ; tst r13,r13
    { const bool k = c.t; c.t = c.r[2] > c.r[1]; if (k) { goto L_060616AC; } }  // 06061694 bt/s 0x060616AC ; cmp/hi r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06061746u);  // 06061698 mov.w 0x06061746,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 0606169A mov.l @(r0,r14),r0
    c.t = c.r[10] == c.r[0];  // 0606169C cmp/eq r0,r10
    { const bool k = c.t; c.t = c.r[2] > c.r[1]; if (k) { goto L_060616AC; } }  // 0606169E bt/s 0x060616AC ; cmp/hi r1,r2
    c.r[11] = (uint32_t)(int16_t)ld16(0x06061744u);  // 060616A2 mov.w 0x06061744,r11
    c.r[11] += c.r[14];  // 060616A4 add r14,r11
    c.r[1] = ld32(c.r[11]); SH2_POLL(c); goto L_06061656;  // 060616A6 bra 0x06061656 ; mov.l @r11,r1
L_060616AA:
    c.t = c.r[2] > c.r[1];  // 060616AA cmp/hi r1,r2
L_060616AC:
    { const bool k = c.t; c.t = (c.r[13] & c.r[13]) == 0; if (k) { goto L_060616EC; } }  // 060616AC bt/s 0x060616EC ; tst r13,r13
    if (c.t) { goto L_060616EC; }  // 060616B0 bt 0x060616EC
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606174Cu);  // 060616B2 mov.w 0x0606174C,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606174Eu);  // 060616B4 mov.w 0x0606174E,r0
    c.r[2] = ld32(c.r[0] + c.r[14]);  // 060616B6 mov.l @(r0,r14),r2
    c.r[1] += c.r[14];  // 060616B8 add r14,r1
    c.r[2] <<= 2;  // 060616BA shll2 r2
    c.r[2] += c.r[2];  // 060616BC add r2,r2
    c.r[0] = c.r[1];  // 060616BE mov r1,r0
    c.r[1] = ld32(c.r[0] + c.r[2]);  // 060616C0 mov.l @(r0,r2),r1
    c.r[1] += 2;  // 060616C2 add #2,r1
    st16(c.r[1], c.r[13]); goto L_060616EC;  // 060616C4 bra 0x060616EC ; mov.w r13,@r1
L_060616C8:
    c.r[11] = (uint32_t)(int16_t)ld16(0x06061744u);  // 060616C8 mov.w 0x06061744,r11
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 060616CA mov.w @r2,r1
    c.r[11] += c.r[14];  // 060616CC add r14,r11
    c.r[11] = ld32(c.r[11]);  // 060616CE mov.l @r11,r11
    c.r[13] = c.r[1] & 0xFFFFu;  // 060616D0 extu.w r1,r13
    c.r[13] += c.r[11];  // 060616D2 add r11,r13
    c.t = (int32_t)c.r[13] >= 0;  // 060616D4 cmp/pz r13
    if (c.t) { goto L_060616DE; }  // 060616D6 bt 0x060616DE
    c.r[1] = (uint32_t)(int16_t)ld16(0x06061750u);  // 060616D8 mov.w 0x06061750,r1
    st16(c.r[2], c.r[1]); goto L_060616EC;  // 060616DA bra 0x060616EC ; mov.w r1,@r2
L_060616DE:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06061750u);  // 060616DE mov.w 0x06061750,r1
    c.t = (int32_t)c.r[13] > (int32_t)c.r[1];  // 060616E0 cmp/gt r1,r13
    if (!c.t) { goto L_060616EA; }  // 060616E2 bf 0x060616EA
    c.r[1] = 0x0u;  // 060616E4 mov #0,r1
    st16(c.r[2], c.r[1]); goto L_060616EC;  // 060616E6 bra 0x060616EC ; mov.w r1,@r2
L_060616EA:
    st16(c.r[2], c.r[13]);  // 060616EA mov.w r13,@r2
L_060616EC:
    c.r[10] = (uint32_t)(int16_t)ld16(0x0606174Cu);  // 060616EC mov.w 0x0606174C,r10
    c.r[10] += c.r[14];  // 060616EE add r14,r10
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606174Eu);  // 060616F0 mov.w 0x0606174E,r0
    c.r[12] = ld32(c.r[0] + c.r[14]);  // 060616F2 mov.l @(r0,r14),r12
    c.r[9] = ld32(0x06061754u);  // 060616F4 mov.l 0x06061754,r9
    c.r[12] <<= 2;  // 060616F6 shll2 r12
    c.r[12] += c.r[12];  // 060616F8 add r12,r12
    c.r[0] = c.r[10];  // 060616FA mov r10,r0
    c.r[1] = ld32(c.r[0] + c.r[12]);  // 060616FC mov.l @(r0,r12),r1
    c.r[5] = 0x1Du;  // 060616FE mov #29,r5
    c.r[1] += 2;  // 06061700 add #2,r1
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06061702 mov.w @r1,r8
    c.r[4] = ld32(0x06061758u);  // 06061704 mov.l 0x06061758,r4
    { const uint32_t x = c.r[9]; c.pr = 0x0606170Au; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606170Au) return; }  // 06061706 jsr @r9 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 0606170A mov r0,r1
    c.r[5] = c.r[8];  // 0606170C mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06061712u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06061712u) return; }  // 0606170E jsr @r9 ; mov r1,r4
    c.r[13] = c.r[0];  // 06061712 mov r0,r13
    c.r[0] = c.r[10];  // 06061714 mov r10,r0
    c.r[1] = ld32(c.r[0] + c.r[12]);  // 06061716 mov.l @(r0,r12),r1
    c.r[5] = 0x1Du;  // 06061718 mov #29,r5
    c.r[1] += 2;  // 0606171A add #2,r1
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606171C mov.w @r1,r8
    c.r[4] = ld32(0x06061758u);  // 0606171E mov.l 0x06061758,r4
    { const uint32_t x = c.r[9]; c.pr = 0x06061724u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06061724u) return; }  // 06061720 jsr @r9 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 06061724 mov r0,r1
    c.r[5] = c.r[8];  // 06061726 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0606172Cu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606172Cu) return; }  // 06061728 jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 0606172C mov r0,r1
    c.r[0] = c.r[10];  // 0606172E mov r10,r0
    c.r[3] = ld32(c.r[0] + c.r[12]);  // 06061730 mov.l @(r0,r12),r3
    c.r[13] += 3;  // 06061732 add #3,r13
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[13]);  // 06061734 mov.b @r13,r2
    c.r[1] += 4;  // 06061736 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06061738 mov.b @r1,r1
    c.r[3] += 4;  // 0606173A add #4,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0606173C extu.b r2,r2
    c.r[2] <<= 8;  // 0606173E shll8 r2
    c.r[1] = c.r[1] & 0xFFu; goto L_06062388;  // 06061740 bra 0x06062388 ; extu.b r1,r1
L_0606175C:
    c.r[11] = (uint32_t)(int16_t)ld16(0x060617D0u);  // 0606175C mov.w 0x060617D0,r11
    c.r[11] += c.r[14];  // 0606175E add r14,r11
    c.r[0] = ld32(c.r[11]);  // 06061760 mov.l @r11,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x060617D2u);  // 06061762 mov.w 0x060617D2,r1
    c.r[0] <<= 2;  // 06061764 shll2 r0
    c.r[0] += c.r[0];  // 06061766 add r0,r0
    st32(c.r[11], c.r[0]);  // 06061768 mov.l r0,@r11
    c.r[11] = (uint32_t)(int16_t)ld16(0x060617D0u);  // 0606176A mov.w 0x060617D0,r11
    c.r[11] += c.r[14];  // 0606176C add r14,r11
    c.r[0] = ld32(c.r[11]);  // 0606176E mov.l @r11,r0
    c.r[1] += c.r[14];  // 06061770 add r14,r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 06061772 mov.l @(r0,r1),r2
    c.r[2] += 4;  // 06061774 add #4,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x060617D4u);  // 06061776 mov.w 0x060617D4,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06061778 mov.w @r2,r1
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 0606177A mov.l @(r0,r14),r0
    c.r[13] = c.r[1] & 0xFFFFu;  // 0606177C extu.w r1,r13
    c.r[13] += c.r[0];  // 0606177E add r0,r13
    c.t = (int32_t)c.r[13] >= 0;  // 06061780 cmp/pz r13
    if (c.t) { goto L_0606178A; }  // 06061782 bt 0x0606178A
    c.r[1] = (uint32_t)(int16_t)ld16(0x060617D6u);  // 06061784 mov.w 0x060617D6,r1
    st16(c.r[2], c.r[1]); goto L_060623A6;  // 06061786 bra 0x060623A6 ; mov.w r1,@r2
L_0606178A:
    c.r[1] = (uint32_t)(int16_t)ld16(0x060617D6u);  // 0606178A mov.w 0x060617D6,r1
    c.t = (int32_t)c.r[13] > (int32_t)c.r[1];  // 0606178C cmp/gt r1,r13
L_0606178E:
    { const bool k = !c.t; c.r[1] = 0x0u; if (k) { goto L_06061796; } }  // 0606178E bf/s 0x06061796 ; mov #0,r1
    goto L_0606218A;  // 06061792 bra 0x0606218A ; nop
L_06061796:
    st16(c.r[2], c.r[13]); goto L_060623A6;  // 06061796 bra 0x060623A6 ; mov.w r13,@r2
L_0606179A:
    c.r[1] = (uint32_t)(int16_t)ld16(0x060617D2u);  // 0606179A mov.w 0x060617D2,r1
    c.r[1] += c.r[14];  // 0606179C add r14,r1
    c.r[11] = (uint32_t)(int16_t)ld16(0x060617D0u);  // 0606179E mov.w 0x060617D0,r11
    c.r[11] += c.r[14];  // 060617A0 add r14,r11
    c.r[2] = ld32(c.r[11]);  // 060617A2 mov.l @r11,r2
    c.r[0] = c.r[1];  // 060617A4 mov r1,r0
    c.r[2] <<= 2;  // 060617A6 shll2 r2
    c.r[2] += c.r[2];  // 060617A8 add r2,r2
    c.r[2] = ld32(c.r[0] + c.r[2]);  // 060617AA mov.l @(r0,r2),r2
    c.r[11] = (uint32_t)(int16_t)ld16(0x060617D4u);  // 060617AC mov.w 0x060617D4,r11
    c.r[2] += 10;  // 060617AE add #10,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 060617B0 mov.w @r2,r1
    c.r[11] += c.r[14];  // 060617B2 add r14,r11
    c.r[11] = ld32(c.r[11]);  // 060617B4 mov.l @r11,r11
    c.r[13] = c.r[1] & 0xFFFFu;  // 060617B6 extu.w r1,r13
    c.r[13] += c.r[11];  // 060617B8 add r11,r13
    c.t = (int32_t)c.r[13] >= 0;  // 060617BA cmp/pz r13
    if (c.t) { goto L_060617C4; }  // 060617BC bt 0x060617C4
    c.r[1] = (uint32_t)(int16_t)ld16(0x060617D8u);  // 060617BE mov.w 0x060617D8,r1
    st16(c.r[2], c.r[1]); goto L_060617DC;  // 060617C0 bra 0x060617DC ; mov.w r1,@r2
L_060617C4:
    c.r[1] = (uint32_t)(int16_t)ld16(0x060617D8u);  // 060617C4 mov.w 0x060617D8,r1
    c.t = (int32_t)c.r[13] > (int32_t)c.r[1];  // 060617C6 cmp/gt r1,r13
    { const bool k = !c.t; c.r[1] = 0x0u; if (k) { goto L_060617DA; } }  // 060617C8 bf/s 0x060617DA ; mov #0,r1
    st16(c.r[2], c.r[1]); goto L_060617DC;  // 060617CC bra 0x060617DC ; mov.w r1,@r2
L_060617DA:
    st16(c.r[2], c.r[13]);  // 060617DA mov.w r13,@r2
L_060617DC:
    c.r[11] = (uint32_t)(int16_t)ld16(0x0606196Eu);  // 060617DC mov.w 0x0606196E,r11
    c.r[0] = (uint32_t)(int16_t)ld16(0x06061970u);  // 060617DE mov.w 0x06061970,r0
    st32(c.r[0] + c.r[14], c.r[11]);  // 060617E0 mov.l r11,@(r0,r14)
    c.r[0] = (uint32_t)(int16_t)ld16(0x06061970u);  // 060617E2 mov.w 0x06061970,r0
    c.r[0] += c.r[14];  // 060617E4 add r14,r0
    c.r[11] = ld32(c.r[0]);  // 060617E6 mov.l @r0,r11
    c.r[11] += c.r[14];  // 060617E8 add r14,r11
    st32(c.r[0], c.r[11]);  // 060617EA mov.l r11,@r0
    c.r[0] = (uint32_t)(int16_t)ld16(0x06061972u);  // 060617EC mov.w 0x06061972,r0
    c.r[0] += c.r[14];  // 060617EE add r14,r0
    c.r[11] = (uint32_t)(int16_t)ld16(0x06061970u);  // 060617F0 mov.w 0x06061970,r11
    c.r[12] = ld32(c.r[0]);  // 060617F2 mov.l @r0,r12
    c.r[11] += c.r[14];  // 060617F4 add r14,r11
    c.r[0] = ld32(c.r[11]);  // 060617F6 mov.l @r11,r0
    c.r[12] <<= 2;  // 060617F8 shll2 r12
    c.r[12] += c.r[12];  // 060617FA add r12,r12
    c.r[1] = ld32(c.r[0] + c.r[12]);  // 060617FC mov.l @(r0,r12),r1
    c.r[1] += 10;  // 060617FE add #10,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06061800 mov.w @r1,r1
    c.r[8] = c.r[1] & 0xFFFFu;  // 06061802 extu.w r1,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 06061804 tst r8,r8
    { const bool k = !c.t; c.r[5] = 0x1Bu; if (k) { goto L_0606180E; } }  // 06061806 bf/s 0x0606180E ; mov #27,r5
    goto L_06061928;  // 0606180A bra 0x06061928 ; nop
L_0606180E:
    c.r[10] = ld32(0x06061978u);  // 0606180E mov.l 0x06061978,r10
    c.r[9] = ld32(0x0606197Cu);  // 06061810 mov.l 0x0606197C,r9
    { const uint32_t x = c.r[9]; c.pr = 0x06061816u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06061816u) return; }  // 06061812 jsr @r9 ; mov r10,r4
    c.r[1] = c.r[0];  // 06061816 mov r0,r1
    c.r[5] = c.r[8];  // 06061818 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0606181Eu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606181Eu) return; }  // 0606181A jsr @r9 ; mov r1,r4
    c.r[13] = c.r[0];  // 0606181E mov r0,r13
    c.r[11] = (uint32_t)(int16_t)ld16(0x06061970u);  // 06061820 mov.w 0x06061970,r11
    c.r[11] += c.r[14];  // 06061822 add r14,r11
    c.r[0] = ld32(c.r[11]);  // 06061824 mov.l @r11,r0
    c.r[1] = ld32(c.r[0] + c.r[12]);  // 06061826 mov.l @(r0,r12),r1
    c.r[5] = 0x1Bu;  // 06061828 mov #27,r5
    c.r[1] += 10;  // 0606182A add #10,r1
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606182C mov.w @r1,r8
    c.r[4] = c.r[10];  // 0606182E mov r10,r4
    { const uint32_t x = c.r[9]; c.pr = 0x06061834u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06061834u) return; }  // 06061830 jsr @r9 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 06061834 mov r0,r1
    c.r[5] = c.r[8];  // 06061836 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0606183Cu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606183Cu) return; }  // 06061838 jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 0606183C mov r0,r1
    c.r[11] = (uint32_t)(int16_t)ld16(0x06061970u);  // 0606183E mov.w 0x06061970,r11
    c.r[11] += c.r[14];  // 06061840 add r14,r11
    c.r[13] += 36;  // 06061842 add #36,r13
    c.r[1] += 37;  // 06061844 add #37,r1
    c.r[0] = ld32(c.r[11]);  // 06061846 mov.l @r11,r0
    c.r[5] = 0x1Bu;  // 06061848 mov #27,r5
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[13]);  // 0606184A mov.b @r13,r2
    c.r[4] = c.r[10];  // 0606184C mov r10,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606184E mov.b @r1,r1
    c.r[2] <<= 8;  // 06061850 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06061852 extu.b r1,r1
    c.r[3] = ld32(c.r[0] + c.r[12]);  // 06061854 mov.l @(r0,r12),r3
    c.r[2] |= c.r[1];  // 06061856 or r1,r2
    c.r[7] = c.r[3];  // 06061858 mov r3,r7
    c.r[7] += 14;  // 0606185A add #14,r7
    c.r[3] += 16;  // 0606185C add #16,r3
    st16(c.r[3], c.r[2]);  // 0606185E mov.w r2,@r3
    st16(c.r[7], c.r[2]);  // 06061860 mov.w r2,@r7
    c.r[1] = ld32(c.r[0] + c.r[12]);  // 06061862 mov.l @(r0,r12),r1
    c.r[11] = (uint32_t)(int16_t)ld16(0x06061970u);  // 06061864 mov.w 0x06061970,r11
    c.r[1] += 10;  // 06061866 add #10,r1
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06061868 mov.w @r1,r8
    c.r[11] += c.r[14];  // 0606186A add r14,r11
    { const uint32_t x = c.r[9]; c.pr = 0x06061870u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06061870u) return; }  // 0606186C jsr @r9 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 06061870 mov r0,r1
    c.r[5] = c.r[8];  // 06061872 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06061878u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06061878u) return; }  // 06061874 jsr @r9 ; mov r1,r4
    c.r[13] = c.r[0];  // 06061878 mov r0,r13
    c.r[11] = (uint32_t)(int16_t)ld16(0x06061970u);  // 0606187A mov.w 0x06061970,r11
    c.r[11] += c.r[14];  // 0606187C add r14,r11
    c.r[0] = ld32(c.r[11]);  // 0606187E mov.l @r11,r0
    c.r[1] = ld32(c.r[0] + c.r[12]);  // 06061880 mov.l @(r0,r12),r1
    c.r[5] = 0x1Bu;  // 06061882 mov #27,r5
    c.r[1] += 10;  // 06061884 add #10,r1
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06061886 mov.w @r1,r8
    c.r[4] = c.r[10];  // 06061888 mov r10,r4
    { const uint32_t x = c.r[9]; c.pr = 0x0606188Eu; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606188Eu) return; }  // 0606188A jsr @r9 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 0606188E mov r0,r1
    c.r[5] = c.r[8];  // 06061890 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06061896u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06061896u) return; }  // 06061892 jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 06061896 mov r0,r1
    c.r[11] = (uint32_t)(int16_t)ld16(0x06061970u);  // 06061898 mov.w 0x06061970,r11
    c.r[11] += c.r[14];  // 0606189A add r14,r11
    c.r[0] = ld32(c.r[11]);  // 0606189C mov.l @r11,r0
    c.r[13] += 34;  // 0606189E add #34,r13
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[13]);  // 060618A0 mov.b @r13,r2
    c.r[1] += 35;  // 060618A2 add #35,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060618A4 mov.b @r1,r1
    c.r[2] <<= 8;  // 060618A6 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 060618A8 extu.b r1,r1
    c.r[3] = ld32(c.r[0] + c.r[12]);  // 060618AA mov.l @(r0,r12),r3
    c.r[2] |= c.r[1];  // 060618AC or r1,r2
    c.r[7] = c.r[3];  // 060618AE mov r3,r7
    c.r[7] += 18;  // 060618B0 add #18,r7
    c.r[3] += 20;  // 060618B2 add #20,r3
    st16(c.r[3], c.r[2]);  // 060618B4 mov.w r2,@r3
    st16(c.r[7], c.r[2]);  // 060618B6 mov.w r2,@r7
    c.r[0] = (uint32_t)(int16_t)ld16(0x06061972u);  // 060618B8 mov.w 0x06061972,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 060618BA mov.l @(r0,r14),r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060618BC tst r0,r0
    { const bool k = !c.t; c.r[1] = 0x0u; if (k) { goto L_060618C4; } }  // 060618BE bf/s 0x060618C4 ; mov #0,r1
    c.r[1] = 0x8u;  // 060618C2 mov #8,r1
L_060618C4:
    c.r[11] = (uint32_t)(int16_t)ld16(0x06061970u);  // 060618C4 mov.w 0x06061970,r11
    c.r[11] += c.r[14];  // 060618C6 add r14,r11
    c.r[0] = ld32(c.r[11]);  // 060618C8 mov.l @r11,r0
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 060618CA mov.l @(r0,r1),r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060618CC mov.b @r1,r1
    c.r[0] = 0x1Fu;  // 060618CE mov #31,r0
    c.r[1] &= c.r[0];  // 060618D0 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060618D2 tst r1,r1
    if (c.t) { goto L_06061928; }  // 060618D4 bt 0x06061928
    c.r[11] = (uint32_t)(int16_t)ld16(0x06061972u);  // 060618D6 mov.w 0x06061972,r11
    c.r[11] += c.r[14];  // 060618D8 add r14,r11
    c.r[11] = ld32(c.r[11]);  // 060618DA mov.l @r11,r11
    c.t = (c.r[11] & c.r[11]) == 0;  // 060618DC tst r11,r11
    { const bool k = !c.t; c.r[1] = 0x0u; if (k) { goto L_060618E4; } }  // 060618DE bf/s 0x060618E4 ; mov #0,r1
    c.r[1] = 0x8u;  // 060618E2 mov #8,r1
L_060618E4:
    c.r[11] = (uint32_t)(int16_t)ld16(0x06061970u);  // 060618E4 mov.w 0x06061970,r11
    c.r[11] += c.r[14];  // 060618E6 add r14,r11
    c.r[0] = ld32(c.r[11]);  // 060618E8 mov.l @r11,r0
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 060618EA mov.l @(r0,r1),r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060618EC mov.b @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06061974u);  // 060618EE mov.w 0x06061974,r0
    c.r[2] &= c.r[0];  // 060618F0 and r0,r2
    st8(c.r[1], c.r[2]);  // 060618F2 mov.b r2,@r1
    { const bool k = !c.t; c.r[1] = 0x0u; if (k) { goto L_060618FA; } }  // 060618F4 bf/s 0x060618FA ; mov #0,r1
    c.r[1] = 0x8u;  // 060618F8 mov #8,r1
L_060618FA:
    c.r[11] = (uint32_t)(int16_t)ld16(0x06061970u);  // 060618FA mov.w 0x06061970,r11
    c.r[11] += c.r[14];  // 060618FC add r14,r11
    c.r[0] = ld32(c.r[11]);  // 060618FE mov.l @r11,r0
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 06061900 mov.l @(r0,r1),r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06061902 mov.b @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06061976u);  // 06061904 mov.w 0x06061976,r0
    c.r[2] &= c.r[0];  // 06061906 and r0,r2
    st8(c.r[1], c.r[2]);  // 06061908 mov.b r2,@r1
    { const bool k = !c.t; c.r[1] = 0x0u; if (k) { goto L_06061910; } }  // 0606190A bf/s 0x06061910 ; mov #0,r1
    c.r[1] = 0x8u;  // 0606190E mov #8,r1
L_06061910:
    c.r[11] = (uint32_t)(int16_t)ld16(0x06061970u);  // 06061910 mov.w 0x06061970,r11
    c.r[11] += c.r[14];  // 06061912 add r14,r11
    c.r[0] = ld32(c.r[11]);  // 06061914 mov.l @r11,r0
    c.r[5] = ld32(c.r[0] + c.r[1]);  // 06061916 mov.l @(r0,r1),r5
    c.r[1] = ld32(c.r[0] + c.r[12]);  // 06061918 mov.l @(r0,r12),r1
    c.r[11] = (uint32_t)(int16_t)ld16(0x06061970u);  // 0606191A mov.w 0x06061970,r11
    c.r[1] += 10;  // 0606191C add #10,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606191E mov.w @r1,r4
    c.r[11] += c.r[14];  // 06061920 add r14,r11
    c.r[1] = ld32(0x06061980u);  // 06061922 mov.l 0x06061980,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06061928u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06061928u) return; }  // 06061924 jsr @r1 ; extu.w r4,r4
L_06061928:
    c.r[2] = (uint32_t)(int16_t)ld16(0x0606196Eu);  // 06061928 mov.w 0x0606196E,r2
    c.r[2] += c.r[14];  // 0606192A add r14,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06061972u);  // 0606192C mov.w 0x06061972,r0
    c.r[1] = ld32(c.r[0] + c.r[14]);  // 0606192E mov.l @(r0,r14),r1
    c.r[4] = ld32(0x06061978u);  // 06061930 mov.l 0x06061978,r4
    c.r[1] <<= 2;  // 06061932 shll2 r1
    c.r[1] += c.r[1];  // 06061934 add r1,r1
    c.r[0] = c.r[2];  // 06061936 mov r2,r0
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 06061938 mov.l @(r0,r1),r1
    c.r[9] = ld32(0x0606197Cu);  // 0606193A mov.l 0x0606197C,r9
    c.r[1] += 10;  // 0606193C add #10,r1
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606193E mov.w @r1,r8
    c.r[5] = 0x1Bu;  // 06061940 mov #27,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06061946u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06061946u) return; }  // 06061942 jsr @r9 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 06061946 mov r0,r1
    c.r[5] = c.r[8];  // 06061948 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0606194Eu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606194Eu) return; }  // 0606194A jsr @r9 ; mov r1,r4
    c.r[10] = c.r[0];  // 0606194E mov r0,r10
    c.r[10] += 38;  // 06061950 add #38,r10
    c.r[5] = c.r[10];  // 06061952 mov r10,r5
    c.r[11] = ld32(0x06061984u);  // 06061954 mov.l 0x06061984,r11
    { const uint32_t x = c.r[11]; c.pr = 0x0606195Au; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606195Au) return; }  // 06061956 jsr @r11 ; mov r14,r4
    c.r[1] = c.r[0];  // 0606195A mov r0,r1
    c.r[10] = c.r[1];  // 0606195C mov r1,r10
    c.r[10] += 2;  // 0606195E add #2,r10
    c.r[12] = c.r[1];  // 06061960 mov r1,r12
    c.r[12] += 3;  // 06061962 add #3,r12
    c.r[5] = 0x1Du;  // 06061964 mov #29,r5
L_06061966:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 06061966 mov.b @r10,r1
    c.r[4] = ld32(0x06061978u);  // 06061968 mov.l 0x06061978,r4
    c.r[13] = c.r[1] & 0xFFu; goto L_06061988;  // 0606196A bra 0x06061988 ; extu.b r1,r13
L_06061988:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[12]);  // 06061988 mov.b @r12,r1
    c.r[13] <<= 8;  // 0606198A shll8 r13
    c.r[12] += 4;  // 0606198C add #4,r12
    c.r[1] = c.r[1] & 0xFFu;  // 0606198E extu.b r1,r1
    c.r[13] |= c.r[1];  // 06061990 or r1,r13
    c.r[1] = (uint32_t)(int16_t)ld16(0x06061AAAu);  // 06061992 mov.w 0x06061AAA,r1
    c.r[13] &= c.r[1];  // 06061994 and r1,r13
    { const uint32_t x = c.r[9]; c.pr = 0x0606199Au; c.r[8] = c.r[13] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606199Au) return; }  // 06061996 jsr @r9 ; extu.w r13,r8
    c.r[1] = c.r[0];  // 0606199A mov r0,r1
    c.r[5] = c.r[8];  // 0606199C mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x060619A2u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060619A2u) return; }  // 0606199E jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 060619A2 mov r0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060619A4 mov.b @r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06061AACu);  // 060619A6 mov.w 0x06061AAC,r2
    c.r[2] &= c.r[1];  // 060619A8 and r1,r2
    c.r[2] >>= 2;  // 060619AA shlr2 r2
    c.r[2] >>= 2;  // 060619AC shlr2 r2
    c.r[2] >>= 2;  // 060619AE shlr2 r2
    c.r[1] = 0x1u;  // 060619B0 mov #1,r1
    c.t = c.r[2] > c.r[1];  // 060619B2 cmp/hi r1,r2
    { const bool k = !c.t; c.t = (c.r[13] & c.r[13]) == 0; if (k) { goto L_060619C0; } }  // 060619B4 bf/s 0x060619C0 ; tst r13,r13
    { const bool k = c.t; c.r[10] += 4; if (k) { goto L_060619C0; } }  // 060619B8 bt/s 0x060619C0 ; add #4,r10
    c.r[5] = 0x1Du; SH2_POLL(c); goto L_06061966;  // 060619BC bra 0x06061966 ; mov #29,r5
L_060619C0:
    if (c.t) { goto L_060619D6; }  // 060619C0 bt 0x060619D6
    c.r[1] = (uint32_t)(int16_t)ld16(0x06061AAEu);  // 060619C2 mov.w 0x06061AAE,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06061AB0u);  // 060619C4 mov.w 0x06061AB0,r0
    c.r[2] = ld32(c.r[0] + c.r[14]);  // 060619C6 mov.l @(r0,r14),r2
    c.r[1] += c.r[14];  // 060619C8 add r14,r1
    c.r[2] <<= 2;  // 060619CA shll2 r2
    c.r[2] += c.r[2];  // 060619CC add r2,r2
    c.r[0] = c.r[1];  // 060619CE mov r1,r0
    c.r[1] = ld32(c.r[0] + c.r[2]);  // 060619D0 mov.l @(r0,r2),r1
    c.r[1] += 2;  // 060619D2 add #2,r1
    st16(c.r[1], c.r[13]);  // 060619D4 mov.w r13,@r1
L_060619D6:
    c.r[10] = (uint32_t)(int16_t)ld16(0x06061AAEu);  // 060619D6 mov.w 0x06061AAE,r10
    c.r[10] += c.r[14];  // 060619D8 add r14,r10
    c.r[11] = (uint32_t)(int16_t)ld16(0x06061AB0u);  // 060619DA mov.w 0x06061AB0,r11
    c.r[11] += c.r[14];  // 060619DC add r14,r11
    c.r[0] = c.r[10];  // 060619DE mov r10,r0
    c.r[12] = ld32(c.r[11]);  // 060619E0 mov.l @r11,r12
    c.r[9] = ld32(0x06061ABCu);  // 060619E2 mov.l 0x06061ABC,r9
    c.r[12] <<= 2;  // 060619E4 shll2 r12
    c.r[12] += c.r[12];  // 060619E6 add r12,r12
    c.r[1] = ld32(c.r[0] + c.r[12]);  // 060619E8 mov.l @(r0,r12),r1
    c.r[5] = 0x1Du;  // 060619EA mov #29,r5
    c.r[1] += 2;  // 060619EC add #2,r1
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060619EE mov.w @r1,r8
    c.r[4] = ld32(0x06061AC0u);  // 060619F0 mov.l 0x06061AC0,r4
    { const uint32_t x = c.r[9]; c.pr = 0x060619F6u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060619F6u) return; }  // 060619F2 jsr @r9 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 060619F6 mov r0,r1
    c.r[5] = c.r[8];  // 060619F8 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x060619FEu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060619FEu) return; }  // 060619FA jsr @r9 ; mov r1,r4
    c.r[13] = c.r[0];  // 060619FE mov r0,r13
    c.r[0] = c.r[10];  // 06061A00 mov r10,r0
    c.r[1] = ld32(c.r[0] + c.r[12]);  // 06061A02 mov.l @(r0,r12),r1
    c.r[5] = 0x1Du;  // 06061A04 mov #29,r5
    c.r[1] += 2;  // 06061A06 add #2,r1
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06061A08 mov.w @r1,r8
    c.r[4] = ld32(0x06061AC0u);  // 06061A0A mov.l 0x06061AC0,r4
    { const uint32_t x = c.r[9]; c.pr = 0x06061A10u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06061A10u) return; }  // 06061A0C jsr @r9 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 06061A10 mov r0,r1
    c.r[5] = c.r[8];  // 06061A12 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06061A18u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06061A18u) return; }  // 06061A14 jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 06061A18 mov r0,r1
    c.r[0] = c.r[10];  // 06061A1A mov r10,r0
    c.r[3] = ld32(c.r[0] + c.r[12]);  // 06061A1C mov.l @(r0,r12),r3
    c.r[13] += 3;  // 06061A1E add #3,r13
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[13]);  // 06061A20 mov.b @r13,r2
    c.r[1] += 4;  // 06061A22 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06061A24 mov.b @r1,r1
    c.r[3] += 4;  // 06061A26 add #4,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06061A28 extu.b r2,r2
    c.r[2] <<= 8;  // 06061A2A shll8 r2
    c.r[1] = c.r[1] & 0xFFu; goto L_06062388;  // 06061A2C bra 0x06062388 ; extu.b r1,r1
L_06061A30:
    c.r[11] = (uint32_t)(int16_t)ld16(0x06061AB0u);  // 06061A30 mov.w 0x06061AB0,r11
    c.r[11] += c.r[14];  // 06061A32 add r14,r11
    c.r[0] = ld32(c.r[11]);  // 06061A34 mov.l @r11,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06061AAEu);  // 06061A36 mov.w 0x06061AAE,r1
    c.r[0] <<= 2;  // 06061A38 shll2 r0
    c.r[0] += c.r[0];  // 06061A3A add r0,r0
    st32(c.r[11], c.r[0]);  // 06061A3C mov.l r0,@r11
    c.r[11] = (uint32_t)(int16_t)ld16(0x06061AB0u);  // 06061A3E mov.w 0x06061AB0,r11
    c.r[11] += c.r[14];  // 06061A40 add r14,r11
    c.r[0] = ld32(c.r[11]);  // 06061A42 mov.l @r11,r0
    c.r[1] += c.r[14];  // 06061A44 add r14,r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 06061A46 mov.l @(r0,r1),r2
    c.r[2] += 6;  // 06061A48 add #6,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06061AB2u);  // 06061A4A mov.w 0x06061AB2,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06061A4C mov.w @r2,r1
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06061A4E mov.l @(r0,r14),r0
    c.r[13] = c.r[1] & 0xFFFFu;  // 06061A50 extu.w r1,r13
    c.r[13] += c.r[0];  // 06061A52 add r0,r13
    c.t = (int32_t)c.r[13] >= 0;  // 06061A54 cmp/pz r13
    if (c.t) { goto L_06061A5C; }  // 06061A56 bt 0x06061A5C
    goto L_0606217C;  // 06061A58 bra 0x0606217C ; nop
L_06061A5C:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06061AB4u);  // 06061A5C mov.w 0x06061AB4,r1
    c.t = (int32_t)c.r[13] > (int32_t)c.r[1]; SH2_POLL(c); goto L_0606178E;  // 06061A5E bra 0x0606178E ; cmp/gt r1,r13
L_06061A62:
    c.r[11] = (uint32_t)(int16_t)ld16(0x06061AB0u);  // 06061A62 mov.w 0x06061AB0,r11
    c.r[11] += c.r[14];  // 06061A64 add r14,r11
    c.r[2] = ld32(c.r[11]);  // 06061A66 mov.l @r11,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06061AB6u);  // 06061A68 mov.w 0x06061AB6,r1
    c.r[2] <<= 2;  // 06061A6A shll2 r2
    c.r[2] += c.r[14];  // 06061A6C add r14,r2
    c.r[0] = c.r[2];  // 06061A6E mov r2,r0
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 06061A70 mov.l @(r0,r1),r1
    c.r[1] += 1;  // 06061A72 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06061A74 mov.b @r1,r1
    c.r[11] = 0x1u;  // 06061A76 mov #1,r11
    c.r[1] = c.r[1] & 0xFFu;  // 06061A78 extu.b r1,r1
    c.r[2] = c.r[1];  // 06061A7A mov r1,r2
    c.r[2] >>= 2;  // 06061A7C shlr2 r2
    c.r[2] >>= 2;  // 06061A7E shlr2 r2
    c.r[2] &= c.r[11];  // 06061A80 and r11,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06061A82 tst r2,r2
    { const bool k = c.t; c.r[12] = 0x0u; if (k) { goto L_06061A90; } }  // 06061A84 bt/s 0x06061A90 ; mov #0,r12
    c.r[1] >>= 2;  // 06061A88 shlr2 r1
    c.r[1] &= c.r[11];  // 06061A8A and r11,r1
    c.r[1] += 1;  // 06061A8C add #1,r1
    c.r[12] = (uint32_t)(int32_t)(int8_t)c.r[1];  // 06061A8E exts.b r1,r12
L_06061A90:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06061AB2u);  // 06061A90 mov.w 0x06061AB2,r0
    c.r[0] += c.r[14];  // 06061A92 add r14,r0
    c.r[11] = ld32(c.r[0]);  // 06061A94 mov.l @r0,r11
    c.r[11] += c.r[12];  // 06061A96 add r12,r11
    st32(c.r[0], c.r[11]);  // 06061A98 mov.l r11,@r0
    c.r[0] = (uint32_t)(int16_t)ld16(0x06061AB8u);  // 06061A9A mov.w 0x06061AB8,r0
    c.r[0] += c.r[14];  // 06061A9C add r14,r0
    c.r[12] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06061A9E mov.b @r0,r12
    c.t = (int32_t)c.r[12] >= 0;  // 06061AA0 cmp/pz r12
    { const bool k = c.t; c.r[1] = 0x2u; if (k) { goto L_06061AC4; } }  // 06061AA2 bt/s 0x06061AC4 ; mov #2,r1
    c.r[12] = 0x2u; goto L_06061ACA;  // 06061AA6 bra 0x06061ACA ; mov #2,r12
L_06061AC4:
    c.t = (int32_t)c.r[12] > (int32_t)c.r[1];  // 06061AC4 cmp/gt r1,r12
    if (!c.t) { goto L_06061ACA; }  // 06061AC6 bf 0x06061ACA
    c.r[12] = 0x0u;  // 06061AC8 mov #0,r12
L_06061ACA:
    c.r[11] = (uint32_t)(int16_t)ld16(0x06061BF4u);  // 06061ACA mov.w 0x06061BF4,r11
    c.r[11] += c.r[14];  // 06061ACC add r14,r11
    c.r[6] = ld32(c.r[11]);  // 06061ACE mov.l @r11,r6
    c.r[3] = (uint32_t)(int16_t)ld16(0x06061BF6u);  // 06061AD0 mov.w 0x06061BF6,r3
    c.r[6] <<= 2;  // 06061AD2 shll2 r6
    c.r[6] += c.r[14];  // 06061AD4 add r14,r6
    c.r[0] = c.r[6];  // 06061AD6 mov r6,r0
    c.r[2] = ld32(c.r[0] + c.r[3]);  // 06061AD8 mov.l @(r0,r3),r2
    c.r[1] = 0x20u;  // 06061ADA mov #32,r1
    c.r[2] += 1;  // 06061ADC add #1,r2
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06061ADE mov.b @r2,r7
    c.r[11] = (uint32_t)(int16_t)ld16(0x06061BF8u);  // 06061AE0 mov.w 0x06061BF8,r11
    c.r[1] &= c.r[7];  // 06061AE2 and r7,r1
    c.r[7] &= c.r[11];  // 06061AE4 and r11,r7
    c.r[7] |= c.r[1];  // 06061AE6 or r1,r7
    st8(c.r[2], c.r[7]);  // 06061AE8 mov.b r7,@r2
    c.r[2] = ld32(c.r[0] + c.r[3]);  // 06061AEA mov.l @(r0,r3),r2
    c.r[1] = 0x8u;  // 06061AEC mov #8,r1
    c.r[2] += 1;  // 06061AEE add #1,r2
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06061AF0 mov.b @r2,r7
    c.r[0] = (uint32_t)(int16_t)ld16(0x06061BFAu);  // 06061AF2 mov.w 0x06061BFA,r0
    c.r[1] &= c.r[7];  // 06061AF4 and r7,r1
    c.r[7] &= c.r[0];  // 06061AF6 and r0,r7
    c.r[7] |= c.r[1];  // 06061AF8 or r1,r7
    c.r[0] = c.r[12];  // 06061AFA mov r12,r0
    c.t = c.r[0] == 0x1u;  // 06061AFC cmp/eq #1,r0
    { const bool k = c.t; st8(c.r[2], c.r[7]); if (k) { goto L_06061B0C; } }  // 06061AFE bt/s 0x06061B0C ; mov.b r7,@r2
    c.t = c.r[0] == 0x2u;  // 06061B02 cmp/eq #2,r0
    { const bool k = c.t; c.r[0] = c.r[6]; if (k) { goto L_06061B2A; } }  // 06061B04 bt/s 0x06061B2A ; mov r6,r0
    goto L_060623A6;  // 06061B08 bra 0x060623A6 ; nop
L_06061B0C:
    c.r[0] = c.r[6];  // 06061B0C mov r6,r0
    c.r[1] = ld32(c.r[0] + c.r[3]);  // 06061B0E mov.l @(r0,r3),r1
    c.r[11] = 0x3u;  // 06061B10 mov #3,r11
    c.r[1] += 1;  // 06061B12 add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06061B14 mov.b @r1,r2
    c.r[0] = 0x1u;  // 06061B16 mov #1,r0
    c.r[3] = c.r[2];  // 06061B18 mov r2,r3
    c.r[3] >>= 2;  // 06061B1A shlr2 r3
    c.r[3] >>= 2;  // 06061B1C shlr2 r3
    c.r[3] &= c.r[11];  // 06061B1E and r11,r3
    c.r[3] |= c.r[0];  // 06061B20 or r0,r3
    c.r[3] <<= 2;  // 06061B22 shll2 r3
    c.r[11] = (uint32_t)(int16_t)ld16(0x06061BF8u);  // 06061B24 mov.w 0x06061BF8,r11
    c.r[3] <<= 2; goto L_06062288;  // 06061B26 bra 0x06062288 ; shll2 r3
L_06061B2A:
    c.r[1] = ld32(c.r[0] + c.r[3]);  // 06061B2A mov.l @(r0,r3),r1
    c.r[11] = 0x3u;  // 06061B2C mov #3,r11
    c.r[1] += 1;  // 06061B2E add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06061B30 mov.b @r1,r2
    c.r[0] = 0x1u;  // 06061B32 mov #1,r0
    c.r[7] = c.r[2];  // 06061B34 mov r2,r7
    c.r[7] >>= 2;  // 06061B36 shlr2 r7
    c.r[7] >>= 2;  // 06061B38 shlr2 r7
    c.r[7] &= c.r[11];  // 06061B3A and r11,r7
    c.r[7] |= c.r[0];  // 06061B3C or r0,r7
    c.r[7] <<= 2;  // 06061B3E shll2 r7
    c.r[7] <<= 2;  // 06061B40 shll2 r7
    c.r[11] = (uint32_t)(int16_t)ld16(0x06061BF8u);  // 06061B42 mov.w 0x06061BF8,r11
    c.r[2] &= c.r[11];  // 06061B44 and r11,r2
    c.r[2] |= c.r[7];  // 06061B46 or r7,r2
    st8(c.r[1], c.r[2]);  // 06061B48 mov.b r2,@r1
    c.r[0] = c.r[6];  // 06061B4A mov r6,r0
    c.r[1] = ld32(c.r[0] + c.r[3]);  // 06061B4C mov.l @(r0,r3),r1
    c.r[11] = 0x3u;  // 06061B4E mov #3,r11
    c.r[1] += 1;  // 06061B50 add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06061B52 mov.b @r1,r2
    c.r[0] = 0x1u; goto L_0606227C;  // 06061B54 bra 0x0606227C ; mov #1,r0
L_06061B58:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06061BF4u);  // 06061B58 mov.w 0x06061BF4,r0
    c.r[2] = ld32(c.r[0] + c.r[14]);  // 06061B5A mov.l @(r0,r14),r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06061BF6u);  // 06061B5C mov.w 0x06061BF6,r1
    c.r[2] <<= 2;  // 06061B5E shll2 r2
    c.r[2] += c.r[14];  // 06061B60 add r14,r2
    c.r[0] = c.r[2];  // 06061B62 mov r2,r0
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 06061B64 mov.l @(r0,r1),r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06061B66 mov.b @r1,r1
    c.r[11] = 0x1u;  // 06061B68 mov #1,r11
    c.r[1] = c.r[1] & 0xFFu;  // 06061B6A extu.b r1,r1
    c.r[2] = c.r[1];  // 06061B6C mov r1,r2
    c.r[2] >>= 2;  // 06061B6E shlr2 r2
    c.r[2] >>= 2;  // 06061B70 shlr2 r2
    c.r[2] >>= 2;  // 06061B72 shlr2 r2
    c.r[2] &= c.r[11];  // 06061B74 and r11,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06061B76 tst r2,r2
    { const bool k = c.t; c.r[12] = 0x0u; if (k) { goto L_06061B8E; } }  // 06061B78 bt/s 0x06061B8E ; mov #0,r12
    c.r[0] = c.r[1];  // 06061B7C mov r1,r0
    c.r[0] >>= 2;  // 06061B7E shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06061B80 shlr r0
    c.r[0] >>= 2;  // 06061B82 shlr2 r0
    c.r[0] &= 0x1u;  // 06061B84 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06061B86 tst r0,r0
    { const bool k = c.t; c.r[12] = 0x1u; if (k) { goto L_06061B8E; } }  // 06061B88 bt/s 0x06061B8E ; mov #1,r12
    c.r[12] = 0x2u;  // 06061B8C mov #2,r12
L_06061B8E:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06061BFCu);  // 06061B8E mov.w 0x06061BFC,r0
    c.r[0] += c.r[14];  // 06061B90 add r14,r0
    c.r[11] = ld32(c.r[0]);  // 06061B92 mov.l @r0,r11
    c.r[11] += c.r[12];  // 06061B94 add r12,r11
    st32(c.r[0], c.r[11]);  // 06061B96 mov.l r11,@r0
    c.r[0] = (uint32_t)(int16_t)ld16(0x06061BFEu);  // 06061B98 mov.w 0x06061BFE,r0
    c.r[0] += c.r[14];  // 06061B9A add r14,r0
    c.r[12] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06061B9C mov.b @r0,r12
    c.t = (int32_t)c.r[12] >= 0;  // 06061B9E cmp/pz r12
    { const bool k = c.t; c.r[1] = 0x2u; if (k) { goto L_06061BA8; } }  // 06061BA0 bt/s 0x06061BA8 ; mov #2,r1
    c.r[12] = 0x2u; goto L_06061BAE;  // 06061BA4 bra 0x06061BAE ; mov #2,r12
L_06061BA8:
    c.t = (int32_t)c.r[12] > (int32_t)c.r[1];  // 06061BA8 cmp/gt r1,r12
    if (!c.t) { goto L_06061BAE; }  // 06061BAA bf 0x06061BAE
    c.r[12] = 0x0u;  // 06061BAC mov #0,r12
L_06061BAE:
    c.r[11] = (uint32_t)(int16_t)ld16(0x06061BF4u);  // 06061BAE mov.w 0x06061BF4,r11
    c.r[11] += c.r[14];  // 06061BB0 add r14,r11
    c.r[2] = ld32(c.r[11]);  // 06061BB2 mov.l @r11,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x06061BF6u);  // 06061BB4 mov.w 0x06061BF6,r3
    c.r[2] <<= 2;  // 06061BB6 shll2 r2
    c.r[2] += c.r[14];  // 06061BB8 add r14,r2
    c.r[0] = c.r[2];  // 06061BBA mov r2,r0
    c.r[1] = ld32(c.r[0] + c.r[3]);  // 06061BBC mov.l @(r0,r3),r1
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06061BBE mov.b @r1,r7
    c.r[11] = (uint32_t)(int16_t)ld16(0x06061C00u);  // 06061BC0 mov.w 0x06061C00,r11
    c.r[7] &= c.r[11];  // 06061BC2 and r11,r7
    st8(c.r[1], c.r[7]);  // 06061BC4 mov.b r7,@r1
    c.r[1] = ld32(c.r[0] + c.r[3]);  // 06061BC6 mov.l @(r0,r3),r1
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06061BC8 mov.b @r1,r7
    c.r[0] = (uint32_t)(int16_t)ld16(0x06061C02u);  // 06061BCA mov.w 0x06061C02,r0
    c.r[7] &= c.r[0];  // 06061BCC and r0,r7
    c.r[0] = c.r[12];  // 06061BCE mov r12,r0
    c.t = c.r[0] == 0x1u;  // 06061BD0 cmp/eq #1,r0
    { const bool k = c.t; st8(c.r[1], c.r[7]); if (k) { goto L_06061BEA; } }  // 06061BD2 bt/s 0x06061BEA ; mov.b r7,@r1
    c.t = c.r[0] == 0x2u;  // 06061BD6 cmp/eq #2,r0
    { const bool k = c.t; c.r[0] = c.r[2]; if (k) { goto L_06061BE0; } }  // 06061BD8 bt/s 0x06061BE0 ; mov r2,r0
    goto L_060623A6;  // 06061BDC bra 0x060623A6 ; nop
L_06061BE0:
    c.r[1] = ld32(c.r[0] + c.r[3]);  // 06061BE0 mov.l @(r0,r3),r1
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06061BE2 mov.b @r1,r7
    c.r[11] = 0x20u;  // 06061BE4 mov #32,r11
    c.r[7] |= c.r[11];  // 06061BE6 or r11,r7
    st8(c.r[1], c.r[7]);  // 06061BE8 mov.b r7,@r1
L_06061BEA:
    c.r[0] = c.r[2];  // 06061BEA mov r2,r0
    c.r[1] = ld32(c.r[0] + c.r[3]);  // 06061BEC mov.l @(r0,r3),r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06061BEE mov.b @r1,r2
    c.r[11] = 0x40u; goto L_060620BE;  // 06061BF0 bra 0x060620BE ; mov #64,r11
L_06061C04:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06061D28u);  // 06061C04 mov.w 0x06061D28,r0
    c.r[0] += c.r[14];  // 06061C06 add r14,r0
    c.r[11] = (uint32_t)(int16_t)ld16(0x06061D2Au);  // 06061C08 mov.w 0x06061D2A,r11
    c.r[11] += c.r[14];  // 06061C0A add r14,r11
    c.r[0] = ld32(c.r[0]);  // 06061C0C mov.l @r0,r0
    c.r[12] = (uint32_t)(int16_t)ld16(0x06061D2Cu);  // 06061C0E mov.w 0x06061D2C,r12
    c.t = (c.r[0] & c.r[0]) == 0;  // 06061C10 tst r0,r0
    c.r[0] = c.t;  // 06061C12 movt r0
    st32(c.r[11], c.r[0]);  // 06061C14 mov.l r0,@r11
    c.r[11] = (uint32_t)(int16_t)ld16(0x06061D2Au);  // 06061C16 mov.w 0x06061D2A,r11
    c.r[11] += c.r[14];  // 06061C18 add r14,r11
    c.r[0] = ld32(c.r[11]);  // 06061C1A mov.l @r11,r0
    c.r[13] = c.t;  // 06061C1C movt r13
    c.r[0] <<= 2;  // 06061C1E shll2 r0
    c.r[0] += c.r[0];  // 06061C20 add r0,r0
    st32(c.r[11], c.r[0]);  // 06061C22 mov.l r0,@r11
    c.r[11] = (uint32_t)(int16_t)ld16(0x06061D2Au);  // 06061C24 mov.w 0x06061D2A,r11
    c.r[11] += c.r[14];  // 06061C26 add r14,r11
    c.r[0] = ld32(c.r[11]);  // 06061C28 mov.l @r11,r0
    c.r[12] += c.r[14];  // 06061C2A add r14,r12
    c.r[1] = ld32(c.r[0] + c.r[12]);  // 06061C2C mov.l @(r0,r12),r1
    c.r[1] += 10;  // 06061C2E add #10,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06061C30 mov.w @r1,r1
    c.r[8] = c.r[1] & 0xFFFFu;  // 06061C32 extu.w r1,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 06061C34 tst r8,r8
    { const bool k = !c.t; c.r[5] = 0x1Bu; if (k) { goto L_06061C3E; } }  // 06061C36 bf/s 0x06061C3E ; mov #27,r5
    goto L_060623A6;  // 06061C3A bra 0x060623A6 ; nop
L_06061C3E:
    c.r[10] = ld32(0x06061D38u);  // 06061C3E mov.l 0x06061D38,r10
    c.r[9] = ld32(0x06061D3Cu);  // 06061C40 mov.l 0x06061D3C,r9
    { const uint32_t x = c.r[9]; c.pr = 0x06061C46u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06061C46u) return; }  // 06061C42 jsr @r9 ; mov r10,r4
    c.r[1] = c.r[0];  // 06061C46 mov r0,r1
    c.r[5] = c.r[8];  // 06061C48 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06061C4Eu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06061C4Eu) return; }  // 06061C4A jsr @r9 ; mov r1,r4
    c.r[11] = (uint32_t)(int16_t)ld16(0x06061D2Eu);  // 06061C4E mov.w 0x06061D2E,r11
    c.r[11] += c.r[14];  // 06061C50 add r14,r11
    st32(c.r[11], c.r[0]);  // 06061C52 mov.l r0,@r11
    c.r[11] = (uint32_t)(int16_t)ld16(0x06061D2Au);  // 06061C54 mov.w 0x06061D2A,r11
    c.r[11] += c.r[14];  // 06061C56 add r14,r11
    c.r[0] = ld32(c.r[11]);  // 06061C58 mov.l @r11,r0
    c.r[1] = ld32(c.r[0] + c.r[12]);  // 06061C5A mov.l @(r0,r12),r1
    c.r[5] = 0x1Bu;  // 06061C5C mov #27,r5
    c.r[1] += 10;  // 06061C5E add #10,r1
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06061C60 mov.w @r1,r8
    c.r[4] = c.r[10];  // 06061C62 mov r10,r4
    { const uint32_t x = c.r[9]; c.pr = 0x06061C68u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06061C68u) return; }  // 06061C64 jsr @r9 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 06061C68 mov r0,r1
    c.r[5] = c.r[8];  // 06061C6A mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06061C70u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06061C70u) return; }  // 06061C6C jsr @r9 ; mov r1,r4
    c.r[3] = c.r[0];  // 06061C70 mov r0,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x06061D28u);  // 06061C72 mov.w 0x06061D28,r0
    c.r[0] += c.r[14];  // 06061C74 add r14,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06061D30u);  // 06061C76 mov.w 0x06061D30,r1
    c.r[11] = (uint32_t)(int16_t)ld16(0x06061D2Eu);  // 06061C78 mov.w 0x06061D2E,r11
    c.r[2] = ld32(c.r[0]);  // 06061C7A mov.l @r0,r2
    c.r[11] += c.r[14];  // 06061C7C add r14,r11
    c.r[2] <<= 2;  // 06061C7E shll2 r2
    c.r[2] += c.r[14];  // 06061C80 add r14,r2
    c.r[0] = c.r[2];  // 06061C82 mov r2,r0
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 06061C84 mov.l @(r0,r1),r1
    c.r[3] += 37;  // 06061C86 add #37,r3
    c.r[1] += 4;  // 06061C88 add #4,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06061C8A mov.w @r1,r2
    c.r[7] = ld32(0x06061D40u);  // 06061C8C mov.l 0x06061D40,r7
    c.r[0] = ld32(c.r[11]);  // 06061C8E mov.l @r11,r0
    c.r[1] = 0x64u;  // 06061C90 mov #100,r1
    c.r[0] += 36;  // 06061C92 add #36,r0
    st32(c.r[11], c.r[0]);  // 06061C94 mov.l r0,@r11
    c.r[11] = (uint32_t)(int16_t)ld16(0x06061D2Eu);  // 06061C96 mov.w 0x06061D2E,r11
    c.r[11] += c.r[14];  // 06061C98 add r14,r11
    c.r[0] = ld32(c.r[11]);  // 06061C9A mov.l @r11,r0
    c.macl = (c.r[2] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 06061C9C mulu.w r1,r2
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06061C9E mov.b @r0,r5
    c.r[4] = c.macl;  // 06061CA0 sts macl,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06061CA2 mov.b @r3,r1
    c.r[5] = c.r[5] & 0xFFu;  // 06061CA4 extu.b r5,r5
    c.r[5] <<= 8;  // 06061CA6 shll8 r5
    c.r[1] = c.r[1] & 0xFFu;  // 06061CA8 extu.b r1,r1
    { const uint32_t x = c.r[7]; c.pr = 0x06061CAEu; c.r[5] |= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06061CAEu) return; }  // 06061CAA jsr @r7 ; or r1,r5
    c.r[7] = c.r[0];  // 06061CAE mov r0,r7
    c.r[12] = (uint32_t)(int32_t)(int8_t)c.r[7];  // 06061CB0 exts.b r7,r12
    c.r[1] = 0x9u;  // 06061CB2 mov #9,r1
    c.t = (int32_t)c.r[12] > (int32_t)c.r[1];  // 06061CB4 cmp/gt r1,r12
    { const bool k = c.t; c.r[1] = 0x31u; if (k) { goto L_06061CBE; } }  // 06061CB6 bt/s 0x06061CBE ; mov #49,r1
    c.r[12] = 0x0u; goto L_06061CDA;  // 06061CBA bra 0x06061CDA ; mov #0,r12
L_06061CBE:
    c.t = (int32_t)c.r[12] > (int32_t)c.r[1];  // 06061CBE cmp/gt r1,r12
    { const bool k = c.t; c.r[1] = 0x59u; if (k) { goto L_06061CC8; } }  // 06061CC0 bt/s 0x06061CC8 ; mov #89,r1
    c.r[12] = 0x1u; goto L_06061CDA;  // 06061CC4 bra 0x06061CDA ; mov #1,r12
L_06061CC8:
    c.t = (int32_t)c.r[12] > (int32_t)c.r[1];  // 06061CC8 cmp/gt r1,r12
    { const bool k = c.t; c.r[1] = 0x63u; if (k) { goto L_06061CD2; } }  // 06061CCA bt/s 0x06061CD2 ; mov #99,r1
    c.r[12] = 0x2u; goto L_06061CDA;  // 06061CCE bra 0x06061CDA ; mov #2,r12
L_06061CD2:
    c.t = (int32_t)c.r[12] > (int32_t)c.r[1];  // 06061CD2 cmp/gt r1,r12
    { const bool k = c.t; c.r[12] = 0x4u; if (k) { goto L_06061CDA; } }  // 06061CD4 bt/s 0x06061CDA ; mov #4,r12
    c.r[12] = 0x3u;  // 06061CD8 mov #3,r12
L_06061CDA:
    c.r[11] = (uint32_t)(int16_t)ld16(0x06061D32u);  // 06061CDA mov.w 0x06061D32,r11
    c.r[11] += c.r[14];  // 06061CDC add r14,r11
    c.r[0] = ld32(c.r[11]);  // 06061CDE mov.l @r11,r0
    c.r[0] += c.r[12];  // 06061CE0 add r12,r0
    st32(c.r[11], c.r[0]);  // 06061CE2 mov.l r0,@r11
    c.r[11] = (uint32_t)(int16_t)ld16(0x06061D34u);  // 06061CE4 mov.w 0x06061D34,r11
    c.r[11] += c.r[14];  // 06061CE6 add r14,r11
    c.r[12] = (uint32_t)(int8_t)ld8(c.r[11]);  // 06061CE8 mov.b @r11,r12
    c.t = (int32_t)c.r[12] >= 0;  // 06061CEA cmp/pz r12
    { const bool k = c.t; c.r[1] = 0x4u; if (k) { goto L_06061CF4; } }  // 06061CEC bt/s 0x06061CF4 ; mov #4,r1
    c.r[12] = 0x4u; goto L_06061CFA;  // 06061CF0 bra 0x06061CFA ; mov #4,r12
L_06061CF4:
    c.t = (int32_t)c.r[12] > (int32_t)c.r[1];  // 06061CF4 cmp/gt r1,r12
    if (!c.t) { goto L_06061CFA; }  // 06061CF6 bf 0x06061CFA
    c.r[12] = 0x0u;  // 06061CF8 mov #0,r12
L_06061CFA:
    c.r[1] = 0x3u;  // 06061CFA mov #3,r1
    c.r[2] = c.r[12];  // 06061CFC mov r12,r2
    c.r[2] -= 1;  // 06061CFE add #-1,r2
    c.t = c.r[2] > c.r[1];  // 06061D00 cmp/hi r1,r2
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_06061D48; } }  // 06061D02 bt/s 0x06061D48 ; mov r2,r1
    c.r[1] += c.r[1];  // 06061D06 add r1,r1
    c.r[0] = 0x06061D14u;  // 06061D08 mova 0x06061D14,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06061D0A mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 06061D0C add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x06061D1Cu: goto L_06061D1C; case 0x06061D20u: goto L_06061D20; case 0x06061D24u: goto L_06061D24; case 0x06061D44u: goto L_06061D44; default: sh2_call(c, x); return; } }  // 06061D0E jmp @r0 ; nop
L_06061D1C:
    c.r[12] = 0xAu; goto L_06061D4A;  // 06061D1C bra 0x06061D4A ; mov #10,r12
L_06061D20:
    c.r[12] = 0x32u; goto L_06061D4A;  // 06061D20 bra 0x06061D4A ; mov #50,r12
L_06061D24:
    c.r[12] = 0x5Au; goto L_06061D4A;  // 06061D24 bra 0x06061D4A ; mov #90,r12
L_06061D44:
    c.r[12] = 0x64u; goto L_06061D4A;  // 06061D44 bra 0x06061D4A ; mov #100,r12
L_06061D48:
    c.r[12] = 0x0u;  // 06061D48 mov #0,r12
L_06061D4A:
    c.r[11] = (uint32_t)(int16_t)ld16(0x06061E84u);  // 06061D4A mov.w 0x06061E84,r11
    c.r[0] = (uint32_t)(int16_t)ld16(0x06061E86u);  // 06061D4C mov.w 0x06061E86,r0
    st32(c.r[0] + c.r[14], c.r[11]);  // 06061D4E mov.l r11,@(r0,r14)
    c.r[0] = (uint32_t)(int16_t)ld16(0x06061E86u);  // 06061D50 mov.w 0x06061E86,r0
    c.r[0] += c.r[14];  // 06061D52 add r14,r0
    c.r[13] <<= 2;  // 06061D54 shll2 r13
    c.r[13] += c.r[13];  // 06061D56 add r13,r13
    c.r[11] = ld32(c.r[0]);  // 06061D58 mov.l @r0,r11
    c.r[10] = ld32(0x06061E94u);  // 06061D5A mov.l 0x06061E94,r10
    c.r[11] += c.r[14];  // 06061D5C add r14,r11
    st32(c.r[0], c.r[11]);  // 06061D5E mov.l r11,@r0
    c.r[11] = (uint32_t)(int16_t)ld16(0x06061E86u);  // 06061D60 mov.w 0x06061E86,r11
    c.r[11] += c.r[14];  // 06061D62 add r14,r11
    c.r[0] = ld32(c.r[11]);  // 06061D64 mov.l @r11,r0
    c.r[9] = ld32(0x06061E98u);  // 06061D66 mov.l 0x06061E98,r9
    c.r[1] = ld32(c.r[0] + c.r[13]);  // 06061D68 mov.l @(r0,r13),r1
    c.r[5] = 0x1Bu;  // 06061D6A mov #27,r5
    c.r[1] += 10;  // 06061D6C add #10,r1
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06061D6E mov.w @r1,r8
    c.r[4] = c.r[10];  // 06061D70 mov r10,r4
    { const uint32_t x = c.r[9]; c.pr = 0x06061D76u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06061D76u) return; }  // 06061D72 jsr @r9 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 06061D76 mov r0,r1
    c.r[5] = c.r[8];  // 06061D78 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06061D7Eu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06061D7Eu) return; }  // 06061D7A jsr @r9 ; mov r1,r4
    c.r[11] = (uint32_t)(int16_t)ld16(0x06061E88u);  // 06061D7E mov.w 0x06061E88,r11
    c.r[11] += c.r[14];  // 06061D80 add r14,r11
    st32(c.r[11], c.r[0]);  // 06061D82 mov.l r0,@r11
    c.r[11] = (uint32_t)(int16_t)ld16(0x06061E86u);  // 06061D84 mov.w 0x06061E86,r11
    c.r[11] += c.r[14];  // 06061D86 add r14,r11
    c.r[0] = ld32(c.r[11]);  // 06061D88 mov.l @r11,r0
    c.r[1] = ld32(c.r[0] + c.r[13]);  // 06061D8A mov.l @(r0,r13),r1
    c.r[5] = 0x1Bu;  // 06061D8C mov #27,r5
    c.r[1] += 10;  // 06061D8E add #10,r1
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06061D90 mov.w @r1,r8
    c.r[4] = c.r[10];  // 06061D92 mov r10,r4
    { const uint32_t x = c.r[9]; c.pr = 0x06061D98u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06061D98u) return; }  // 06061D94 jsr @r9 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 06061D98 mov r0,r1
    c.r[5] = c.r[8];  // 06061D9A mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06061DA0u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06061DA0u) return; }  // 06061D9C jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 06061DA0 mov r0,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06061E8Au);  // 06061DA2 mov.w 0x06061E8A,r0
    c.r[0] += c.r[14];  // 06061DA4 add r14,r0
    c.r[5] = (uint32_t)(int16_t)ld16(0x06061E8Cu);  // 06061DA6 mov.w 0x06061E8C,r5
    c.r[6] = ld32(c.r[0]);  // 06061DA8 mov.l @r0,r6
    c.r[11] = (uint32_t)(int16_t)ld16(0x06061E88u);  // 06061DAA mov.w 0x06061E88,r11
    c.r[6] <<= 2;  // 06061DAC shll2 r6
    c.r[6] += c.r[14];  // 06061DAE add r14,r6
    c.r[0] = c.r[6];  // 06061DB0 mov r6,r0
    c.r[3] = ld32(c.r[0] + c.r[5]);  // 06061DB2 mov.l @(r0,r5),r3
    c.r[11] += c.r[14];  // 06061DB4 add r14,r11
    c.r[0] = ld32(c.r[11]);  // 06061DB6 mov.l @r11,r0
    c.r[0] += 36;  // 06061DB8 add #36,r0
    st32(c.r[11], c.r[0]);  // 06061DBA mov.l r0,@r11
    c.r[11] = (uint32_t)(int16_t)ld16(0x06061E88u);  // 06061DBC mov.w 0x06061E88,r11
    c.r[11] += c.r[14];  // 06061DBE add r14,r11
    c.r[0] = ld32(c.r[11]);  // 06061DC0 mov.l @r11,r0
    c.r[1] += 37;  // 06061DC2 add #37,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06061DC4 mov.b @r1,r1
    c.r[7] = c.r[3];  // 06061DC6 mov r3,r7
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06061DC8 mov.b @r0,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06061DCA extu.b r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 06061DCC extu.b r2,r2
    c.r[2] <<= 8;  // 06061DCE shll8 r2
    c.r[2] |= c.r[1];  // 06061DD0 or r1,r2
    c.macl = c.r[2] * c.r[12];  // 06061DD2 mul.l r12,r2
    c.r[7] += 4;  // 06061DD4 add #4,r7
    c.r[1] = ld32(0x06061E9Cu);  // 06061DD6 mov.l 0x06061E9C,r1
    c.r[2] = c.macl;  // 06061DD8 sts macl,r2
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[2] * (int32_t)c.r[1]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 06061DDA dmuls.l r1,r2
    c.r[3] += 2;  // 06061DDC add #2,r3
    c.r[0] = c.r[12];  // 06061DDE mov r12,r0
    c.r[1] = c.mach;  // 06061DE0 sts mach,r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06061DE2 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06061DE4 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06061DE6 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06061DE8 shar r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06061DEA shar r1
    c.t = c.r[2] >> 31; c.r[2] <<= 1;  // 06061DEC shll r2
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 06061DEE subc r2,r2
    c.r[1] -= c.r[2];  // 06061DF0 sub r2,r1
    st16(c.r[3], c.r[1]);  // 06061DF2 mov.w r1,@r3
    c.t = c.r[0] == 0x64u;  // 06061DF4 cmp/eq #100,r0
    { const bool k = !c.t; st16(c.r[7], c.r[1]); if (k) { goto L_06061E04; } }  // 06061DF6 bf/s 0x06061E04 ; mov.w r1,@r7
    c.r[0] = c.r[6];  // 06061DFA mov r6,r0
    c.r[1] = ld32(c.r[0] + c.r[5]);  // 06061DFC mov.l @(r0,r5),r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06061DFE mov.b @r1,r2
    c.r[11] = 0x10u; goto L_060620BE;  // 06061E00 bra 0x060620BE ; mov #16,r11
L_06061E04:
    c.r[0] = c.r[6];  // 06061E04 mov r6,r0
    c.r[1] = ld32(c.r[0] + c.r[5]);  // 06061E06 mov.l @(r0,r5),r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06061E08 mov.b @r1,r2
    c.r[11] = (uint32_t)(int16_t)ld16(0x06061E8Eu);  // 06061E0A mov.w 0x06061E8E,r11
    c.r[2] &= c.r[11];  // 06061E0C and r11,r2
    st8(c.r[1], c.r[2]); goto L_060623A6;  // 06061E0E bra 0x060623A6 ; mov.b r2,@r1
L_06061E12:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06061E8Au);  // 06061E12 mov.w 0x06061E8A,r0
    c.r[0] += c.r[14];  // 06061E14 add r14,r0
    c.r[11] = ld32(c.r[0]);  // 06061E16 mov.l @r0,r11
    c.r[1] = (uint32_t)(int16_t)ld16(0x06061E84u);  // 06061E18 mov.w 0x06061E84,r1
    c.r[11] <<= 2;  // 06061E1A shll2 r11
    c.r[11] += c.r[11];  // 06061E1C add r11,r11
    st32(c.r[0], c.r[11]);  // 06061E1E mov.l r11,@r0
    c.r[0] = (uint32_t)(int16_t)ld16(0x06061E8Au);  // 06061E20 mov.w 0x06061E8A,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06061E22 mov.l @(r0,r14),r0
    c.r[1] += c.r[14];  // 06061E24 add r14,r1
    c.r[1] += c.r[0];  // 06061E26 add r0,r1
    c.r[2] = ld32(c.r[1] + 4);  // 06061E28 mov.l @(4,r1),r2
    c.r[3] = c.r[2];  // 06061E2A mov r2,r3
    c.r[3] += 10;  // 06061E2C add #10,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06061E2E mov.w @r3,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06061E30 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06061E32 tst r1,r1
    { const bool k = c.t; c.r[2] += 6; if (k) { goto L_06061E3C; } }  // 06061E34 bt/s 0x06061E3C ; add #6,r2
    c.r[1] = 0x0u; goto L_06061ECE;  // 06061E38 bra 0x06061ECE ; mov #0,r1
L_06061E3C:
    c.r[1] = 0x1u; goto L_06061ECE;  // 06061E3C bra 0x06061ECE ; mov #1,r1
L_06061E40:
    c.r[11] = (uint32_t)(int16_t)ld16(0x06061E8Au);  // 06061E40 mov.w 0x06061E8A,r11
    c.r[11] += c.r[14];  // 06061E42 add r14,r11
    c.r[0] = ld32(c.r[11]);  // 06061E44 mov.l @r11,r0
    c.r[0] <<= 2;  // 06061E46 shll2 r0
    st32(c.r[11], c.r[0]);  // 06061E48 mov.l r0,@r11
    c.r[11] = (uint32_t)(int16_t)ld16(0x06061E8Au);  // 06061E4A mov.w 0x06061E8A,r11
    c.r[11] += c.r[14];  // 06061E4C add r14,r11
    c.r[0] = ld32(c.r[11]);  // 06061E4E mov.l @r11,r0
    c.r[0] += c.r[14];  // 06061E50 add r14,r0
    st32(c.r[11], c.r[0]);  // 06061E52 mov.l r0,@r11
    c.r[11] = (uint32_t)(int16_t)ld16(0x06061E8Au);  // 06061E54 mov.w 0x06061E8A,r11
    c.r[11] += c.r[14];  // 06061E56 add r14,r11
    c.r[0] = ld32(c.r[11]);  // 06061E58 mov.l @r11,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06061E8Cu);  // 06061E5A mov.w 0x06061E8C,r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 06061E5C mov.l @(r0,r1),r2
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06061E5E mov.w @r2,r3
    c.r[0] = 0x3u;  // 06061E60 mov #3,r0
    c.r[1] = c.r[3];  // 06061E62 mov r3,r1
    c.r[1] >>= 2;  // 06061E64 shlr2 r1
    c.r[1] >>= 2;  // 06061E66 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06061E68 shlr r1
    c.r[1] >>= 2;  // 06061E6A shlr2 r1
    c.r[1] &= c.r[0];  // 06061E6C and r0,r1
    c.r[0] = c.r[1];  // 06061E6E mov r1,r0
    c.t = c.r[0] == 0x3u;  // 06061E70 cmp/eq #3,r0
    if (!c.t) { goto L_06061E7C; }  // 06061E72 bf 0x06061E7C
    c.r[1] = (uint32_t)(int16_t)ld16(0x06061E90u);  // 06061E74 mov.w 0x06061E90,r1
    c.r[1] &= c.r[3];  // 06061E76 and r3,r1
    st16(c.r[2], c.r[1]); goto L_060623A6;  // 06061E78 bra 0x060623A6 ; mov.w r1,@r2
L_06061E7C:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06061E92u);  // 06061E7C mov.w 0x06061E92,r1
    c.r[1] |= c.r[3];  // 06061E7E or r3,r1
    st16(c.r[2], c.r[1]); goto L_060623A6;  // 06061E80 bra 0x060623A6 ; mov.w r1,@r2
L_06061EA0:
    c.r[11] = (uint32_t)(int16_t)ld16(0x06061F96u);  // 06061EA0 mov.w 0x06061F96,r11
    c.r[11] += c.r[14];  // 06061EA2 add r14,r11
    c.r[0] = ld32(c.r[11]);  // 06061EA4 mov.l @r11,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06061F98u);  // 06061EA6 mov.w 0x06061F98,r1
    c.r[0] <<= 2;  // 06061EA8 shll2 r0
    c.r[0] += c.r[0];  // 06061EAA add r0,r0
    st32(c.r[11], c.r[0]);  // 06061EAC mov.l r0,@r11
    c.r[11] = (uint32_t)(int16_t)ld16(0x06061F96u);  // 06061EAE mov.w 0x06061F96,r11
    c.r[11] += c.r[14];  // 06061EB0 add r14,r11
    c.r[0] = ld32(c.r[11]);  // 06061EB2 mov.l @r11,r0
    c.r[1] += c.r[14];  // 06061EB4 add r14,r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 06061EB6 mov.l @(r0,r1),r2
    c.r[3] = c.r[2];  // 06061EB8 mov r2,r3
    c.r[3] += 24;  // 06061EBA add #24,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06061EBC mov.w @r3,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06061EBE extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06061EC0 tst r1,r1
    { const bool k = c.t; c.r[1] = 0x28u; if (k) { goto L_06061ECC; } }  // 06061EC2 bt/s 0x06061ECC ; mov #40,r1
    c.r[2] += 22;  // 06061EC6 add #22,r2
    c.r[1] = 0x0u; goto L_06061ECE;  // 06061EC8 bra 0x06061ECE ; mov #0,r1
L_06061ECC:
    c.r[2] += 22;  // 06061ECC add #22,r2
L_06061ECE:
    st16(c.r[2], c.r[1]);  // 06061ECE mov.w r1,@r2
    st16(c.r[3], c.r[1]); goto L_060623A6;  // 06061ED0 bra 0x060623A6 ; mov.w r1,@r3
L_06061ED4:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06061F96u);  // 06061ED4 mov.w 0x06061F96,r0
    c.r[0] += c.r[14];  // 06061ED6 add r14,r0
    c.r[11] = ld32(c.r[0]);  // 06061ED8 mov.l @r0,r11
    c.r[1] = (uint32_t)(int16_t)ld16(0x06061F98u);  // 06061EDA mov.w 0x06061F98,r1
    c.r[11] <<= 2;  // 06061EDC shll2 r11
    c.r[11] += c.r[11];  // 06061EDE add r11,r11
    st32(c.r[0], c.r[11]);  // 06061EE0 mov.l r11,@r0
    c.r[11] = (uint32_t)(int16_t)ld16(0x06061F96u);  // 06061EE2 mov.w 0x06061F96,r11
    c.r[11] += c.r[14];  // 06061EE4 add r14,r11
    c.r[0] = ld32(c.r[11]);  // 06061EE6 mov.l @r11,r0
    c.r[1] += c.r[14];  // 06061EE8 add r14,r1
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 06061EEA mov.l @(r0,r1),r2
    c.r[3] = c.r[2];  // 06061EEC mov r2,r3
    c.r[3] += 27;  // 06061EEE add #27,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06061EF0 mov.b @r3,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06061EF2 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06061EF4 tst r1,r1
    { const bool k = c.t; c.r[1] = 0x14u; if (k) { goto L_06061F00; } }  // 06061EF6 bt/s 0x06061F00 ; mov #20,r1
    c.r[2] += 26;  // 06061EFA add #26,r2
    c.r[1] = 0x0u; goto L_06061F02;  // 06061EFC bra 0x06061F02 ; mov #0,r1
L_06061F00:
    c.r[2] += 26;  // 06061F00 add #26,r2
L_06061F02:
    st8(c.r[2], c.r[1]);  // 06061F02 mov.b r1,@r2
    st8(c.r[3], c.r[1]); goto L_060623A6;  // 06061F04 bra 0x060623A6 ; mov.b r1,@r3
L_06061F08:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06061F96u);  // 06061F08 mov.w 0x06061F96,r0
    c.r[1] = ld32(c.r[0] + c.r[14]);  // 06061F0A mov.l @(r0,r14),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06061F9Au);  // 06061F0C mov.w 0x06061F9A,r2
    c.r[1] <<= 2;  // 06061F0E shll2 r1
    c.r[1] += c.r[14];  // 06061F10 add r14,r1
    c.r[0] = c.r[1];  // 06061F12 mov r1,r0
    c.r[2] = ld32(c.r[0] + c.r[2]);  // 06061F14 mov.l @(r0,r2),r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06061F16 mov.b @r2,r1
    c.r[11] = 0x3u;  // 06061F18 mov #3,r11
    c.r[1] >>= 2;  // 06061F1A shlr2 r1
    c.r[1] &= c.r[11];  // 06061F1C and r11,r1
    c.r[0] = c.r[1];  // 06061F1E mov r1,r0
    c.t = c.r[0] == 0x1u;  // 06061F20 cmp/eq #1,r0
    { const bool k = c.t; c.r[12] = 0x3u; if (k) { goto L_06061F7C; } }  // 06061F22 bt/s 0x06061F7C ; mov #3,r12
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06061F26 mov.w @r2,r1
    c.r[11] = 0x3u;  // 06061F28 mov #3,r11
    c.r[2] = c.r[1];  // 06061F2A mov r1,r2
    c.r[2] >>= 2;  // 06061F2C shlr2 r2
    c.r[2] >>= 2;  // 06061F2E shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 06061F30 shlr r2
    c.r[2] >>= 2;  // 06061F32 shlr2 r2
    c.r[2] &= c.r[11];  // 06061F34 and r11,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06061F36 tst r2,r2
    { const bool k = c.t; c.r[1] = 0x2u; if (k) { goto L_06061F42; } }  // 06061F38 bt/s 0x06061F42 ; mov #2,r1
    c.t = c.r[2] > c.r[1];  // 06061F3C cmp/hi r1,r2
    { const bool k = !c.t; c.r[12] = 0x4u; if (k) { goto L_06061F7C; } }  // 06061F3E bf/s 0x06061F7C ; mov #4,r12
L_06061F42:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06061F98u);  // 06061F42 mov.w 0x06061F98,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06061F96u);  // 06061F44 mov.w 0x06061F96,r0
    c.r[2] = ld32(c.r[0] + c.r[14]);  // 06061F46 mov.l @(r0,r14),r2
    c.r[1] += c.r[14];  // 06061F48 add r14,r1
    c.r[2] <<= 2;  // 06061F4A shll2 r2
    c.r[2] += c.r[2];  // 06061F4C add r2,r2
    c.r[0] = c.r[1];  // 06061F4E mov r1,r0
    c.r[1] = ld32(c.r[0] + c.r[2]);  // 06061F50 mov.l @(r0,r2),r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06061F52 mov.b @r1,r1
    c.r[11] = 0x1Fu;  // 06061F54 mov #31,r11
    c.r[1] &= c.r[11];  // 06061F56 and r11,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06061F58 tst r1,r1
    { const bool k = c.t; c.r[12] = 0x0u; if (k) { goto L_06061F7C; } }  // 06061F5A bt/s 0x06061F7C ; mov #0,r12
    c.r[0] = (uint32_t)(int16_t)ld16(0x06061F96u);  // 06061F5E mov.w 0x06061F96,r0
    c.r[2] = ld32(c.r[0] + c.r[14]);  // 06061F60 mov.l @(r0,r14),r2
    c.r[2] <<= 2;  // 06061F62 shll2 r2
    c.r[2] += c.r[14];  // 06061F64 add r14,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06061F9Au);  // 06061F66 mov.w 0x06061F9A,r1
    c.r[0] = c.r[2];  // 06061F68 mov r2,r0
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 06061F6A mov.l @(r0,r1),r1
    c.r[11] = 0x1u;  // 06061F6C mov #1,r11
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06061F6E mov.b @r1,r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06061F70 shlr r1
    c.r[1] &= c.r[11];  // 06061F72 and r11,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06061F74 tst r1,r1
    { const bool k = c.t; c.r[12] = 0x1u; if (k) { goto L_06061F7C; } }  // 06061F76 bt/s 0x06061F7C ; mov #1,r12
    c.r[12] = 0x2u;  // 06061F7A mov #2,r12
L_06061F7C:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06061F9Cu);  // 06061F7C mov.w 0x06061F9C,r0
    c.r[0] += c.r[14];  // 06061F7E add r14,r0
    c.r[11] = ld32(c.r[0]);  // 06061F80 mov.l @r0,r11
    c.r[11] += c.r[12];  // 06061F82 add r12,r11
    st32(c.r[0], c.r[11]);  // 06061F84 mov.l r11,@r0
    c.r[0] = (uint32_t)(int16_t)ld16(0x06061F9Eu);  // 06061F86 mov.w 0x06061F9E,r0
    c.r[0] += c.r[14];  // 06061F88 add r14,r0
    c.r[12] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06061F8A mov.b @r0,r12
    c.t = (int32_t)c.r[12] >= 0;  // 06061F8C cmp/pz r12
    { const bool k = c.t; c.r[1] = 0x4u; if (k) { goto L_06061FA0; } }  // 06061F8E bt/s 0x06061FA0 ; mov #4,r1
    c.r[12] = 0x4u; goto L_06061FA6;  // 06061F92 bra 0x06061FA6 ; mov #4,r12
L_06061FA0:
    c.t = (int32_t)c.r[12] > (int32_t)c.r[1];  // 06061FA0 cmp/gt r1,r12
    if (!c.t) { goto L_06061FA6; }  // 06061FA2 bf 0x06061FA6
    c.r[12] = 0x0u;  // 06061FA4 mov #0,r12
L_06061FA6:
    c.r[11] = (uint32_t)(int16_t)ld16(0x060620F0u);  // 06061FA6 mov.w 0x060620F0,r11
    c.r[11] += c.r[14];  // 06061FA8 add r14,r11
    c.r[6] = ld32(c.r[11]);  // 06061FAA mov.l @r11,r6
    c.r[3] = (uint32_t)(int16_t)ld16(0x060620F2u);  // 06061FAC mov.w 0x060620F2,r3
    c.r[6] <<= 2;  // 06061FAE shll2 r6
    c.r[6] += c.r[14];  // 06061FB0 add r14,r6
    c.r[0] = c.r[6];  // 06061FB2 mov r6,r0
    c.r[1] = ld32(c.r[0] + c.r[3]);  // 06061FB4 mov.l @(r0,r3),r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06061FB6 mov.b @r1,r2
    c.r[11] = (uint32_t)(int16_t)ld16(0x060620F4u);  // 06061FB8 mov.w 0x060620F4,r11
    c.r[2] &= c.r[11];  // 06061FBA and r11,r2
    st8(c.r[1], c.r[2]);  // 06061FBC mov.b r2,@r1
    c.r[7] = ld32(c.r[0] + c.r[3]);  // 06061FBE mov.l @(r0,r3),r7
    c.r[2] = (uint32_t)(int16_t)ld16(0x060620F6u);  // 06061FC0 mov.w 0x060620F6,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[7]);  // 06061FC2 mov.w @r7,r1
    c.r[11] = (uint32_t)(int16_t)ld16(0x060620F0u);  // 06061FC4 mov.w 0x060620F0,r11
    c.r[1] &= c.r[2];  // 06061FC6 and r2,r1
    st16(c.r[7], c.r[1]);  // 06061FC8 mov.w r1,@r7
    c.r[1] = ld32(c.r[0] + c.r[3]);  // 06061FCA mov.l @(r0,r3),r1
    c.r[11] += c.r[14];  // 06061FCC add r14,r11
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06061FCE mov.b @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x060620F8u);  // 06061FD0 mov.w 0x060620F8,r0
    c.r[2] &= c.r[0];  // 06061FD2 and r0,r2
    st8(c.r[1], c.r[2]);  // 06061FD4 mov.b r2,@r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x060620FAu);  // 06061FD6 mov.w 0x060620FA,r2
    c.r[2] += c.r[14];  // 06061FD8 add r14,r2
    c.r[3] = ld32(c.r[11]);  // 06061FDA mov.l @r11,r3
    c.r[0] = c.r[2];  // 06061FDC mov r2,r0
    c.r[3] <<= 2;  // 06061FDE shll2 r3
    c.r[3] += c.r[3];  // 06061FE0 add r3,r3
    c.r[1] = ld32(c.r[0] + c.r[3]);  // 06061FE2 mov.l @(r0,r3),r1
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06061FE4 mov.b @r1,r7
    c.r[11] = (uint32_t)(int16_t)ld16(0x060620FCu);  // 06061FE6 mov.w 0x060620FC,r11
    c.r[7] &= c.r[11];  // 06061FE8 and r11,r7
    st8(c.r[1], c.r[7]);  // 06061FEA mov.b r7,@r1
    c.r[1] = ld32(c.r[0] + c.r[3]);  // 06061FEC mov.l @(r0,r3),r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06061FEE mov.b @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x060620FEu);  // 06061FF0 mov.w 0x060620FE,r0
    c.r[2] &= c.r[0];  // 06061FF2 and r0,r2
    st8(c.r[1], c.r[2]);  // 06061FF4 mov.b r2,@r1
    c.r[1] = 0x3u;  // 06061FF6 mov #3,r1
    c.r[2] = c.r[12];  // 06061FF8 mov r12,r2
    c.r[2] -= 1;  // 06061FFA add #-1,r2
    c.t = c.r[2] > c.r[1];  // 06061FFC cmp/hi r1,r2
    { const bool k = !c.t; c.r[1] = c.r[2]; if (k) { goto L_06062006; } }  // 06061FFE bf/s 0x06062006 ; mov r2,r1
    goto L_060623A6;  // 06062002 bra 0x060623A6 ; nop
L_06062006:
    c.r[1] += c.r[1];  // 06062006 add r1,r1
    c.r[0] = 0x06062014u;  // 06062008 mova 0x06062014,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0606200A mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 0606200C add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x06062034u: goto L_06062034; case 0x0606201Cu: goto L_0606201C; case 0x06062098u: goto L_06062098; case 0x060620C4u: goto L_060620C4; default: sh2_call(c, x); return; } }  // 0606200E jmp @r0 ; nop
L_0606201C:
    c.r[11] = (uint32_t)(int16_t)ld16(0x060620F0u);  // 0606201C mov.w 0x060620F0,r11
    c.r[11] += c.r[14];  // 0606201E add r14,r11
    c.r[1] = ld32(c.r[11]);  // 06062020 mov.l @r11,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x060620F2u);  // 06062022 mov.w 0x060620F2,r2
    c.r[1] <<= 2;  // 06062024 shll2 r1
    c.r[1] += c.r[14];  // 06062026 add r14,r1
    c.r[0] = c.r[1];  // 06062028 mov r1,r0
    c.r[1] = ld32(c.r[0] + c.r[2]);  // 0606202A mov.l @(r0,r2),r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606202C mov.b @r1,r2
    c.r[11] = 0x2u;  // 0606202E mov #2,r11
    c.r[2] |= c.r[11];  // 06062030 or r11,r2
    st8(c.r[1], c.r[2]);  // 06062032 mov.b r2,@r1
L_06062034:
    c.r[2] = (uint32_t)(int16_t)ld16(0x060620FAu);  // 06062034 mov.w 0x060620FA,r2
    c.r[2] += c.r[14];  // 06062036 add r14,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x060620F0u);  // 06062038 mov.w 0x060620F0,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 0606203A mov.l @(r0,r14),r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606203C tst r0,r0
    { const bool k = !c.t; c.r[1] = 0x0u; if (k) { goto L_06062044; } }  // 0606203E bf/s 0x06062044 ; mov #0,r1
    c.r[1] = 0x8u;  // 06062042 mov #8,r1
L_06062044:
    c.r[0] = c.r[2];  // 06062044 mov r2,r0
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 06062046 mov.l @(r0,r1),r1
    c.r[1] += 10;  // 06062048 add #10,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606204A mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0606204C extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606204E tst r1,r1
    if (c.t) { goto L_0606207C; }  // 06062050 bt 0x0606207C
    c.r[11] = (uint32_t)(int16_t)ld16(0x060620F0u);  // 06062052 mov.w 0x060620F0,r11
    c.r[11] += c.r[14];  // 06062054 add r14,r11
    c.r[1] = ld32(c.r[11]);  // 06062056 mov.l @r11,r1
    c.r[1] <<= 2;  // 06062058 shll2 r1
    c.r[1] += c.r[1];  // 0606205A add r1,r1
    c.r[5] = ld32(c.r[0] + c.r[1]);  // 0606205C mov.l @(r0,r1),r5
    c.r[0] = (uint32_t)(int16_t)ld16(0x060620F0u);  // 0606205E mov.w 0x060620F0,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06062060 mov.l @(r0,r14),r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06062062 tst r0,r0
    { const bool k = !c.t; c.r[1] = 0x0u; if (k) { goto L_0606206A; } }  // 06062064 bf/s 0x0606206A ; mov #0,r1
    c.r[1] = 0x8u;  // 06062068 mov #8,r1
L_0606206A:
    c.r[0] = c.r[2];  // 0606206A mov r2,r0
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 0606206C mov.l @(r0,r1),r1
    c.r[1] += 10;  // 0606206E add #10,r1
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06062070 mov.w @r1,r4
    c.r[1] = ld32(0x06062104u);  // 06062072 mov.l 0x06062104,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06062078u; c.r[4] = c.r[4] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06062078u) return; }  // 06062074 jsr @r1 ; extu.w r4,r4
    goto L_060623A6;  // 06062078 bra 0x060623A6 ; nop
L_0606207C:
    c.r[11] = (uint32_t)(int16_t)ld16(0x060620F0u);  // 0606207C mov.w 0x060620F0,r11
    c.r[11] += c.r[14];  // 0606207E add r14,r11
    c.r[0] = ld32(c.r[11]);  // 06062080 mov.l @r11,r0
    c.r[0] <<= 2;  // 06062082 shll2 r0
    c.r[0] += c.r[0];  // 06062084 add r0,r0
    st32(c.r[11], c.r[0]);  // 06062086 mov.l r0,@r11
    c.r[11] = (uint32_t)(int16_t)ld16(0x060620F0u);  // 06062088 mov.w 0x060620F0,r11
    c.r[11] += c.r[14];  // 0606208A add r14,r11
    c.r[0] = ld32(c.r[11]);  // 0606208C mov.l @r11,r0
    c.r[1] = ld32(c.r[0] + c.r[2]);  // 0606208E mov.l @(r0,r2),r1
    c.r[11] = 0x4u;  // 06062090 mov #4,r11
    c.r[0] = (uint32_t)(int16_t)ld16(0x060620FCu);  // 06062092 mov.w 0x060620FC,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); goto L_060620BC;  // 06062094 bra 0x060620BC ; mov.b @r1,r2
L_06062098:
    c.r[0] = (uint32_t)(int16_t)ld16(0x060620F0u);  // 06062098 mov.w 0x060620F0,r0
    c.r[0] += c.r[14];  // 0606209A add r14,r0
    c.r[11] = ld32(c.r[0]);  // 0606209C mov.l @r0,r11
    c.r[11] <<= 2;  // 0606209E shll2 r11
    st32(c.r[0], c.r[11]);  // 060620A0 mov.l r11,@r0
    c.r[0] = (uint32_t)(int16_t)ld16(0x060620F0u);  // 060620A2 mov.w 0x060620F0,r0
    c.r[0] += c.r[14];  // 060620A4 add r14,r0
    c.r[11] = ld32(c.r[0]);  // 060620A6 mov.l @r0,r11
    c.r[11] += c.r[14];  // 060620A8 add r14,r11
    st32(c.r[0], c.r[11]);  // 060620AA mov.l r11,@r0
    c.r[11] = (uint32_t)(int16_t)ld16(0x060620F0u);  // 060620AC mov.w 0x060620F0,r11
    c.r[11] += c.r[14];  // 060620AE add r14,r11
    c.r[0] = ld32(c.r[11]);  // 060620B0 mov.l @r11,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x060620F2u);  // 060620B2 mov.w 0x060620F2,r1
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 060620B4 mov.l @(r0,r1),r1
    c.r[11] = 0x4u;  // 060620B6 mov #4,r11
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060620B8 mov.b @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x060620F4u);  // 060620BA mov.w 0x060620F4,r0
L_060620BC:
    c.r[2] &= c.r[0];  // 060620BC and r0,r2
L_060620BE:
    c.r[2] |= c.r[11];  // 060620BE or r11,r2
    st8(c.r[1], c.r[2]); goto L_060623A6;  // 060620C0 bra 0x060623A6 ; mov.b r2,@r1
L_060620C4:
    c.r[0] = (uint32_t)(int16_t)ld16(0x060620F0u);  // 060620C4 mov.w 0x060620F0,r0
    c.r[0] += c.r[14];  // 060620C6 add r14,r0
    c.r[11] = ld32(c.r[0]);  // 060620C8 mov.l @r0,r11
    c.r[11] <<= 2;  // 060620CA shll2 r11
    st32(c.r[0], c.r[11]);  // 060620CC mov.l r11,@r0
    c.r[0] = (uint32_t)(int16_t)ld16(0x060620F0u);  // 060620CE mov.w 0x060620F0,r0
    c.r[0] += c.r[14];  // 060620D0 add r14,r0
    c.r[11] = ld32(c.r[0]);  // 060620D2 mov.l @r0,r11
    c.r[11] += c.r[14];  // 060620D4 add r14,r11
    st32(c.r[0], c.r[11]);  // 060620D6 mov.l r11,@r0
    c.r[11] = (uint32_t)(int16_t)ld16(0x060620F0u);  // 060620D8 mov.w 0x060620F0,r11
    c.r[11] += c.r[14];  // 060620DA add r14,r11
    c.r[0] = ld32(c.r[11]);  // 060620DC mov.l @r11,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x060620F2u);  // 060620DE mov.w 0x060620F2,r1
    c.r[3] = ld32(c.r[0] + c.r[1]);  // 060620E0 mov.l @(r0,r1),r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x060620F6u);  // 060620E2 mov.w 0x060620F6,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 060620E4 mov.w @r3,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06062100u);  // 060620E6 mov.w 0x06062100,r0
    c.r[1] &= c.r[2];  // 060620E8 and r2,r1
    c.r[1] |= c.r[0];  // 060620EA or r0,r1
    st16(c.r[3], c.r[1]); goto L_060623A6;  // 060620EC bra 0x060623A6 ; mov.w r1,@r3
L_06062108:
    c.r[11] = (uint32_t)(int16_t)ld16(0x060621DEu);  // 06062108 mov.w 0x060621DE,r11
    c.r[11] += c.r[14];  // 0606210A add r14,r11
    c.r[0] = ld32(c.r[11]);  // 0606210C mov.l @r11,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x060621E0u);  // 0606210E mov.w 0x060621E0,r1
    c.r[0] <<= 2;  // 06062110 shll2 r0
    c.r[0] += c.r[0];  // 06062112 add r0,r0
    st32(c.r[11], c.r[0]);  // 06062114 mov.l r0,@r11
    c.r[11] = (uint32_t)(int16_t)ld16(0x060621DEu);  // 06062116 mov.w 0x060621DE,r11
    c.r[11] += c.r[14];  // 06062118 add r14,r11
    c.r[11] = ld32(c.r[11]);  // 0606211A mov.l @r11,r11
    c.r[1] += c.r[14];  // 0606211C add r14,r1
    c.r[1] += c.r[11];  // 0606211E add r11,r1
    c.r[2] = ld32(c.r[1] + 4);  // 06062120 mov.l @(4,r1),r2
    c.r[2] += 10;  // 06062122 add #10,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06062124 mov.w @r2,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06062126 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06062128 tst r1,r1
    if (!c.t) { goto L_06062130; }  // 0606212A bf 0x06062130
    goto L_060623A6;  // 0606212C bra 0x060623A6 ; nop
L_06062130:
    c.r[0] = (uint32_t)(int16_t)ld16(0x060621E2u);  // 06062130 mov.w 0x060621E2,r0
    c.r[0] += c.r[14];  // 06062132 add r14,r0
    c.r[13] = ld32(c.r[0]);  // 06062134 mov.l @r0,r13
    c.r[13] += c.r[1];  // 06062136 add r1,r13
    c.t = (int32_t)c.r[13] > 0;  // 06062138 cmp/pl r13
    if (c.t) { goto L_06062142; }  // 0606213A bt 0x06062142
    c.r[1] = (uint32_t)(int16_t)ld16(0x060621E4u);  // 0606213C mov.w 0x060621E4,r1
    st16(c.r[2], c.r[1]); goto L_060623A6;  // 0606213E bra 0x060623A6 ; mov.w r1,@r2
L_06062142:
    c.r[1] = (uint32_t)(int16_t)ld16(0x060621E4u);  // 06062142 mov.w 0x060621E4,r1
    c.t = (int32_t)c.r[13] > (int32_t)c.r[1]; SH2_POLL(c); goto L_0606178E;  // 06062144 bra 0x0606178E ; cmp/gt r1,r13
L_06062148:
    c.r[11] = (uint32_t)(int16_t)ld16(0x060621DEu);  // 06062148 mov.w 0x060621DE,r11
    c.r[11] += c.r[14];  // 0606214A add r14,r11
    c.r[0] = ld32(c.r[11]);  // 0606214C mov.l @r11,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x060621E0u);  // 0606214E mov.w 0x060621E0,r1
    c.r[0] <<= 2;  // 06062150 shll2 r0
    c.r[0] += c.r[0];  // 06062152 add r0,r0
    st32(c.r[11], c.r[0]);  // 06062154 mov.l r0,@r11
    c.r[11] = (uint32_t)(int16_t)ld16(0x060621DEu);  // 06062156 mov.w 0x060621DE,r11
    c.r[11] += c.r[14];  // 06062158 add r14,r11
    c.r[11] = ld32(c.r[11]);  // 0606215A mov.l @r11,r11
    c.r[1] += c.r[14];  // 0606215C add r14,r1
    c.r[1] += c.r[11];  // 0606215E add r11,r1
    c.r[2] = ld32(c.r[1] + 4);  // 06062160 mov.l @(4,r1),r2
    c.r[2] += 6;  // 06062162 add #6,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06062164 mov.w @r2,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06062166 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06062168 tst r1,r1
    if (!c.t) { goto L_06062170; }  // 0606216A bf 0x06062170
    goto L_060623A6;  // 0606216C bra 0x060623A6 ; nop
L_06062170:
    c.r[0] = (uint32_t)(int16_t)ld16(0x060621E2u);  // 06062170 mov.w 0x060621E2,r0
    c.r[0] += c.r[14];  // 06062172 add r14,r0
    c.r[13] = ld32(c.r[0]);  // 06062174 mov.l @r0,r13
    c.r[13] += c.r[1];  // 06062176 add r1,r13
    c.t = (int32_t)c.r[13] > 0;  // 06062178 cmp/pl r13
    if (c.t) { goto L_06062182; }  // 0606217A bt 0x06062182
L_0606217C:
    c.r[1] = (uint32_t)(int16_t)ld16(0x060621E6u);  // 0606217C mov.w 0x060621E6,r1
    st16(c.r[2], c.r[1]); goto L_060623A6;  // 0606217E bra 0x060623A6 ; mov.w r1,@r2
L_06062182:
    c.r[1] = (uint32_t)(int16_t)ld16(0x060621E6u);  // 06062182 mov.w 0x060621E6,r1
    c.t = (int32_t)c.r[13] > (int32_t)c.r[1];  // 06062184 cmp/gt r1,r13
    { const bool k = !c.t; c.r[1] = 0x0u; if (k) { goto L_0606218E; } }  // 06062186 bf/s 0x0606218E ; mov #0,r1
L_0606218A:
    st16(c.r[2], c.r[1]); goto L_060623A6;  // 0606218A bra 0x060623A6 ; mov.w r1,@r2
L_0606218E:
    st16(c.r[2], c.r[13]); goto L_060623A6;  // 0606218E bra 0x060623A6 ; mov.w r13,@r2
L_06062192:
    c.r[11] = (uint32_t)(int16_t)ld16(0x060621DEu);  // 06062192 mov.w 0x060621DE,r11
    c.r[11] += c.r[14];  // 06062194 add r14,r11
    c.r[2] = ld32(c.r[11]);  // 06062196 mov.l @r11,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x060621E8u);  // 06062198 mov.w 0x060621E8,r1
    c.r[2] <<= 2;  // 0606219A shll2 r2
    c.r[2] += c.r[14];  // 0606219C add r14,r2
    c.r[0] = c.r[2];  // 0606219E mov r2,r0
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 060621A0 mov.l @(r0,r1),r1
    c.r[1] += 1;  // 060621A2 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060621A4 mov.b @r1,r1
    c.r[11] = 0x2u;  // 060621A6 mov #2,r11
    c.r[1] = c.r[1] & 0xFFu;  // 060621A8 extu.b r1,r1
    c.r[2] = c.r[1];  // 060621AA mov r1,r2
    c.r[2] >>= 2;  // 060621AC shlr2 r2
    c.r[2] >>= 2;  // 060621AE shlr2 r2
    c.r[2] &= c.r[11];  // 060621B0 and r11,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 060621B2 tst r2,r2
    { const bool k = c.t; c.r[12] = 0x0u; if (k) { goto L_060621C4; } }  // 060621B4 bt/s 0x060621C4 ; mov #0,r12
    c.r[1] >>= 2;  // 060621B8 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060621BA shlr r1
    c.r[0] = 0x1u;  // 060621BC mov #1,r0
    c.r[1] &= c.r[0];  // 060621BE and r0,r1
    c.r[1] += 1;  // 060621C0 add #1,r1
    c.r[12] = (uint32_t)(int32_t)(int8_t)c.r[1];  // 060621C2 exts.b r1,r12
L_060621C4:
    c.r[11] = (uint32_t)(int16_t)ld16(0x060621E2u);  // 060621C4 mov.w 0x060621E2,r11
    c.r[11] += c.r[14];  // 060621C6 add r14,r11
    c.r[0] = ld32(c.r[11]);  // 060621C8 mov.l @r11,r0
    c.r[0] += c.r[12];  // 060621CA add r12,r0
    st32(c.r[11], c.r[0]);  // 060621CC mov.l r0,@r11
    c.r[11] = (uint32_t)(int16_t)ld16(0x060621EAu);  // 060621CE mov.w 0x060621EA,r11
    c.r[11] += c.r[14];  // 060621D0 add r14,r11
    c.r[12] = (uint32_t)(int8_t)ld8(c.r[11]);  // 060621D2 mov.b @r11,r12
    c.t = (int32_t)c.r[12] >= 0;  // 060621D4 cmp/pz r12
    { const bool k = c.t; c.r[1] = 0x2u; if (k) { goto L_060621EC; } }  // 060621D6 bt/s 0x060621EC ; mov #2,r1
    c.r[12] = 0x2u; goto L_060621F2;  // 060621DA bra 0x060621F2 ; mov #2,r12
L_060621EC:
    c.t = (int32_t)c.r[12] > (int32_t)c.r[1];  // 060621EC cmp/gt r1,r12
    if (!c.t) { goto L_060621F2; }  // 060621EE bf 0x060621F2
    c.r[12] = 0x0u;  // 060621F0 mov #0,r12
L_060621F2:
    c.r[0] = (uint32_t)(int16_t)ld16(0x060622E0u);  // 060621F2 mov.w 0x060622E0,r0
    c.r[6] = ld32(c.r[0] + c.r[14]);  // 060621F4 mov.l @(r0,r14),r6
    c.r[3] = (uint32_t)(int16_t)ld16(0x060622E2u);  // 060621F6 mov.w 0x060622E2,r3
    c.r[6] <<= 2;  // 060621F8 shll2 r6
    c.r[6] += c.r[14];  // 060621FA add r14,r6
    c.r[0] = c.r[6];  // 060621FC mov r6,r0
    c.r[2] = ld32(c.r[0] + c.r[3]);  // 060621FE mov.l @(r0,r3),r2
    c.r[1] = 0x10u;  // 06062200 mov #16,r1
    c.r[2] += 1;  // 06062202 add #1,r2
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06062204 mov.b @r2,r7
    c.r[11] = (uint32_t)(int16_t)ld16(0x060622E4u);  // 06062206 mov.w 0x060622E4,r11
    c.r[1] &= c.r[7];  // 06062208 and r7,r1
    c.r[7] &= c.r[11];  // 0606220A and r11,r7
    c.r[7] |= c.r[1];  // 0606220C or r1,r7
    st8(c.r[2], c.r[7]);  // 0606220E mov.b r7,@r2
    c.r[2] = ld32(c.r[0] + c.r[3]);  // 06062210 mov.l @(r0,r3),r2
    c.r[1] = 0x4u;  // 06062212 mov #4,r1
    c.r[2] += 1;  // 06062214 add #1,r2
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06062216 mov.b @r2,r7
    c.r[0] = (uint32_t)(int16_t)ld16(0x060622E6u);  // 06062218 mov.w 0x060622E6,r0
    c.r[1] &= c.r[7];  // 0606221A and r7,r1
    c.r[7] &= c.r[0];  // 0606221C and r0,r7
    c.r[7] |= c.r[1];  // 0606221E or r1,r7
    c.r[0] = c.r[12];  // 06062220 mov r12,r0
    c.t = c.r[0] == 0x1u;  // 06062222 cmp/eq #1,r0
    { const bool k = c.t; st8(c.r[2], c.r[7]); if (k) { goto L_06062232; } }  // 06062224 bt/s 0x06062232 ; mov.b r7,@r2
    c.t = c.r[0] == 0x2u;  // 06062228 cmp/eq #2,r0
    { const bool k = c.t; c.r[0] = c.r[6]; if (k) { goto L_06062250; } }  // 0606222A bt/s 0x06062250 ; mov r6,r0
    goto L_060623A6;  // 0606222E bra 0x060623A6 ; nop
L_06062232:
    c.r[0] = c.r[6];  // 06062232 mov r6,r0
    c.r[1] = ld32(c.r[0] + c.r[3]);  // 06062234 mov.l @(r0,r3),r1
    c.r[11] = 0x3u;  // 06062236 mov #3,r11
    c.r[1] += 1;  // 06062238 add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606223A mov.b @r1,r2
    c.r[0] = 0x2u;  // 0606223C mov #2,r0
    c.r[3] = c.r[2];  // 0606223E mov r2,r3
    c.r[3] >>= 2;  // 06062240 shlr2 r3
    c.r[3] >>= 2;  // 06062242 shlr2 r3
    c.r[3] &= c.r[11];  // 06062244 and r11,r3
    c.r[3] |= c.r[0];  // 06062246 or r0,r3
    c.r[3] <<= 2;  // 06062248 shll2 r3
    c.r[11] = (uint32_t)(int16_t)ld16(0x060622E4u);  // 0606224A mov.w 0x060622E4,r11
    c.r[3] <<= 2; goto L_06062288;  // 0606224C bra 0x06062288 ; shll2 r3
L_06062250:
    c.r[1] = ld32(c.r[0] + c.r[3]);  // 06062250 mov.l @(r0,r3),r1
    c.r[11] = 0x3u;  // 06062252 mov #3,r11
    c.r[1] += 1;  // 06062254 add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06062256 mov.b @r1,r2
    c.r[0] = 0x2u;  // 06062258 mov #2,r0
    c.r[7] = c.r[2];  // 0606225A mov r2,r7
    c.r[7] >>= 2;  // 0606225C shlr2 r7
    c.r[7] >>= 2;  // 0606225E shlr2 r7
    c.r[7] &= c.r[11];  // 06062260 and r11,r7
    c.r[7] |= c.r[0];  // 06062262 or r0,r7
    c.r[7] <<= 2;  // 06062264 shll2 r7
    c.r[7] <<= 2;  // 06062266 shll2 r7
    c.r[11] = (uint32_t)(int16_t)ld16(0x060622E4u);  // 06062268 mov.w 0x060622E4,r11
    c.r[2] &= c.r[11];  // 0606226A and r11,r2
    c.r[2] |= c.r[7];  // 0606226C or r7,r2
    st8(c.r[1], c.r[2]);  // 0606226E mov.b r2,@r1
    c.r[0] = c.r[6];  // 06062270 mov r6,r0
    c.r[1] = ld32(c.r[0] + c.r[3]);  // 06062272 mov.l @(r0,r3),r1
    c.r[11] = 0x3u;  // 06062274 mov #3,r11
    c.r[1] += 1;  // 06062276 add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06062278 mov.b @r1,r2
    c.r[0] = 0x2u;  // 0606227A mov #2,r0
L_0606227C:
    c.r[3] = c.r[2];  // 0606227C mov r2,r3
    c.r[3] >>= 2;  // 0606227E shlr2 r3
    c.r[3] &= c.r[11];  // 06062280 and r11,r3
    c.r[3] |= c.r[0];  // 06062282 or r0,r3
    c.r[3] <<= 2;  // 06062284 shll2 r3
    c.r[11] = (uint32_t)(int16_t)ld16(0x060622E6u);  // 06062286 mov.w 0x060622E6,r11
L_06062288:
    c.r[2] &= c.r[11];  // 06062288 and r11,r2
    c.r[2] |= c.r[3];  // 0606228A or r3,r2
    st8(c.r[1], c.r[2]); goto L_060623A6;  // 0606228C bra 0x060623A6 ; mov.b r2,@r1
L_06062290:
    c.r[1] = (uint32_t)(int16_t)ld16(0x060622E2u);  // 06062290 mov.w 0x060622E2,r1
    c.r[0] = c.r[14];  // 06062292 mov r14,r0
    c.r[1] = ld32(c.r[0] + c.r[1]);  // 06062294 mov.l @(r0,r1),r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06062296 mov.b @r1,r1
    c.r[11] = 0x3u;  // 06062298 mov #3,r11
    c.r[1] >>= 2;  // 0606229A shlr2 r1
    c.r[1] &= c.r[11];  // 0606229C and r11,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606229E tst r1,r1
    { const bool k = c.t; c.r[0] = c.r[1]; if (k) { goto L_060622AE; } }  // 060622A0 bt/s 0x060622AE ; mov r1,r0
    c.t = c.r[0] == 0x2u;  // 060622A4 cmp/eq #2,r0
    { const bool k = !c.t; c.r[12] = 0x2u; if (k) { goto L_060622EC; } }  // 060622A6 bf/s 0x060622EC ; mov #2,r12
    c.r[12] = 0x1u; goto L_060622EC;  // 060622AA bra 0x060622EC ; mov #1,r12
L_060622AE:
    c.r[1] = ld32(0x060622E8u);  // 060622AE mov.l 0x060622E8,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060622B0 mov.w @r1,r1
    c.r[2] = c.r[1];  // 060622B2 mov r1,r2
    c.r[2] >>= 2;  // 060622B4 shlr2 r2
    c.r[2] >>= 2;  // 060622B6 shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 060622B8 shlr r2
    c.r[2] >>= 2;  // 060622BA shlr2 r2
    c.r[2] &= c.r[11];  // 060622BC and r11,r2
    c.r[0] = c.r[2];  // 060622BE mov r2,r0
    c.t = c.r[0] == 0x2u;  // 060622C0 cmp/eq #2,r0
    { const bool k = c.t; c.r[12] = 0x5u; if (k) { goto L_060622EC; } }  // 060622C2 bt/s 0x060622EC ; mov #5,r12
    c.r[1] = 0x2u;  // 060622C6 mov #2,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 060622C8 cmp/gt r1,r2
    { const bool k = c.t; c.t = c.r[0] == 0x3u; if (k) { goto L_060622D8; } }  // 060622CA bt/s 0x060622D8 ; cmp/eq #3,r0
    c.t = c.r[0] == 0x1u;  // 060622CE cmp/eq #1,r0
    { const bool k = c.t; c.r[12] = 0x4u; if (k) { goto L_060622EC; } }  // 060622D0 bt/s 0x060622EC ; mov #4,r12
    c.r[12] = 0x3u; goto L_060622EC;  // 060622D4 bra 0x060622EC ; mov #3,r12
L_060622D8:
    { const bool k = c.t; c.r[12] = 0x6u; if (k) { goto L_060622EC; } }  // 060622D8 bt/s 0x060622EC ; mov #6,r12
    c.r[12] = 0x3u; goto L_060622EC;  // 060622DC bra 0x060622EC ; mov #3,r12
L_060622EC:
    c.r[11] = (uint32_t)(int16_t)ld16(0x060623C0u);  // 060622EC mov.w 0x060623C0,r11
    c.r[11] += c.r[14];  // 060622EE add r14,r11
    c.r[0] = ld32(c.r[11]);  // 060622F0 mov.l @r11,r0
    c.r[0] += c.r[12];  // 060622F2 add r12,r0
    st32(c.r[11], c.r[0]);  // 060622F4 mov.l r0,@r11
    c.r[11] = (uint32_t)(int16_t)ld16(0x060623C2u);  // 060622F6 mov.w 0x060623C2,r11
    c.r[11] += c.r[14];  // 060622F8 add r14,r11
    c.r[12] = (uint32_t)(int8_t)ld8(c.r[11]);  // 060622FA mov.b @r11,r12
    c.t = (int32_t)c.r[12] > 0;  // 060622FC cmp/pl r12
    { const bool k = c.t; c.r[1] = 0x6u; if (k) { goto L_06062306; } }  // 060622FE bt/s 0x06062306 ; mov #6,r1
    c.r[12] = 0x6u; goto L_0606230C;  // 06062302 bra 0x0606230C ; mov #6,r12
L_06062306:
    c.t = (int32_t)c.r[12] > (int32_t)c.r[1];  // 06062306 cmp/gt r1,r12
    if (!c.t) { goto L_0606230C; }  // 06062308 bf 0x0606230C
    c.r[12] = 0x1u;  // 0606230A mov #1,r12
L_0606230C:
    c.r[0] = (uint32_t)(int16_t)ld16(0x060623C4u);  // 0606230C mov.w 0x060623C4,r0
    c.r[3] = ld32(0x060623D0u);  // 0606230E mov.l 0x060623D0,r3
    c.r[1] = ld32(c.r[0] + c.r[14]);  // 06062310 mov.l @(r0,r14),r1
    c.r[7] = (uint32_t)(int16_t)ld16(0x060623C6u);  // 06062312 mov.w 0x060623C6,r7
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06062314 mov.b @r1,r0
    c.r[4] = c.r[12];  // 06062316 mov r12,r4
    c.r[0] &= 0xF3u;  // 06062318 and #243,r0
    st8(c.r[1], c.r[0]);  // 0606231A mov.b r0,@r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0606231C mov.w @r3,r1
    c.r[4] -= 1;  // 0606231E add #-1,r4
    c.r[2] = c.r[1];  // 06062320 mov r1,r2
    c.r[2] &= c.r[7];  // 06062322 and r7,r2
    c.r[1] = 0x5u;  // 06062324 mov #5,r1
    c.t = c.r[4] > c.r[1];  // 06062326 cmp/hi r1,r4
    { const bool k = c.t; st16(c.r[3], c.r[2]); if (k) { goto L_0606239A; } }  // 06062328 bt/s 0x0606239A ; mov.w r2,@r3
    c.r[1] = c.r[4];  // 0606232C mov r4,r1
    c.r[1] += c.r[1];  // 0606232E add r1,r1
    c.r[0] = 0x0606233Cu;  // 06062330 mova 0x0606233C,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06062332 mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 06062334 add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x06062348u: goto L_06062348; case 0x06062356u: goto L_06062356; case 0x06062362u: goto L_06062362; case 0x0606236Eu: goto L_0606236E; case 0x0606237Eu: goto L_0606237E; case 0x0606238Eu: goto L_0606238E; default: sh2_call(c, x); return; } }  // 06062336 jmp @r0 ; nop
L_06062348:
    c.r[0] = (uint32_t)(int16_t)ld16(0x060623C4u);  // 06062348 mov.w 0x060623C4,r0
    c.r[1] = ld32(c.r[0] + c.r[14]);  // 0606234A mov.l @(r0,r14),r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606234C mov.b @r1,r0
    c.r[0] &= 0xF3u;  // 0606234E and #243,r0
    c.r[0] |= 0x8u;  // 06062350 or #8,r0
    st8(c.r[1], c.r[0]); goto L_060623A6;  // 06062352 bra 0x060623A6 ; mov.b r0,@r1
L_06062356:
    c.r[0] = (uint32_t)(int16_t)ld16(0x060623C4u);  // 06062356 mov.w 0x060623C4,r0
    c.r[1] = ld32(c.r[0] + c.r[14]);  // 06062358 mov.l @(r0,r14),r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606235A mov.b @r1,r0
    c.r[0] |= 0xCu;  // 0606235C or #12,r0
    st8(c.r[1], c.r[0]); goto L_060623A6;  // 0606235E bra 0x060623A6 ; mov.b r0,@r1
L_06062362:
    c.r[1] = ld32(0x060623D0u);  // 06062362 mov.l 0x060623D0,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06062364 mov.w @r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x060623C6u);  // 06062366 mov.w 0x060623C6,r3
    c.r[2] &= c.r[3];  // 06062368 and r3,r2
    st16(c.r[1], c.r[2]); goto L_060623A6;  // 0606236A bra 0x060623A6 ; mov.w r2,@r1
L_0606236E:
    c.r[3] = ld32(0x060623D0u);  // 0606236E mov.l 0x060623D0,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06062370 mov.w @r3,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x060623C6u);  // 06062372 mov.w 0x060623C6,r1
    c.r[0] = c.r[2];  // 06062374 mov r2,r0
    c.r[0] &= c.r[1];  // 06062376 and r1,r0
    c.r[0] |= 0x80u;  // 06062378 or #128,r0
    st16(c.r[3], c.r[0]); goto L_060623A6;  // 0606237A bra 0x060623A6 ; mov.w r0,@r3
L_0606237E:
    c.r[3] = ld32(0x060623D0u);  // 0606237E mov.l 0x060623D0,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06062380 mov.w @r3,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x060623C6u);  // 06062382 mov.w 0x060623C6,r1
    c.r[2] &= c.r[1];  // 06062384 and r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x060623C8u);  // 06062386 mov.w 0x060623C8,r1
L_06062388:
    c.r[2] |= c.r[1];  // 06062388 or r1,r2
    st16(c.r[3], c.r[2]); goto L_060623A6;  // 0606238A bra 0x060623A6 ; mov.w r2,@r3
L_0606238E:
    c.r[1] = ld32(0x060623D0u);  // 0606238E mov.l 0x060623D0,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06062390 mov.w @r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x060623CAu);  // 06062392 mov.w 0x060623CA,r3
    c.r[2] |= c.r[3];  // 06062394 or r3,r2
    st16(c.r[1], c.r[2]); goto L_060623A6;  // 06062396 bra 0x060623A6 ; mov.w r2,@r1
L_0606239A:
    c.r[2] &= c.r[7];  // 0606239A and r7,r2
    st16(c.r[3], c.r[2]); goto L_060623A6;  // 0606239C bra 0x060623A6 ; mov.w r2,@r3
L_060623A0:
    c.r[2] = ld32(0x060623D4u);  // 060623A0 mov.l 0x060623D4,r2
    c.r[1] = 0x0u;  // 060623A2 mov #0,r1
L_060623A4:
    st8(c.r[2], c.r[1]);  // 060623A4 mov.b r1,@r2
L_060623A6:
    c.r[3] = (uint32_t)(int16_t)ld16(0x060623CCu);  // 060623A6 mov.w 0x060623CC,r3
    c.r[14] += c.r[3];  // 060623A8 add r3,r14
    c.r[15] = c.r[14];  // 060623AA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060623AC lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060623AE mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060623B0 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060623B2 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060623B4 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060623B6 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060623B8 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x060623CEu);  // 060623BA mov.w 0x060623CE,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060623BC rts ; mov.l @r15+,r8
}

void f_060623D8(SH2Context& c) {
    ran[1469] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060623D8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060623DA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060623DC mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060623DE mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060623E0 sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x0606249Eu);  // 060623E2 mov.w 0x0606249E,r3
    c.r[15] += c.r[3];  // 060623E4 add r3,r15
    c.r[14] = c.r[15];  // 060623E6 mov r15,r14
    c.r[8] = c.r[4];  // 060623E8 mov r4,r8
    c.r[10] = c.r[5];  // 060623EA mov r5,r10
    c.r[8] = c.r[8] & 0xFFFFu;  // 060623EC extu.w r8,r8
    c.r[4] = ld32(0x060624A4u);  // 060623EE mov.l 0x060624A4,r4
    c.r[9] = ld32(0x060624A8u);  // 060623F0 mov.l 0x060624A8,r9
    { const uint32_t x = c.r[9]; c.pr = 0x060623F6u; c.r[5] = 0x1Bu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060623F6u) return; }  // 060623F2 jsr @r9 ; mov #27,r5
    c.r[5] = c.r[8];  // 060623F6 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x060623FCu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060623FCu) return; }  // 060623F8 jsr @r9 ; mov r0,r4
    c.r[1] = c.r[0];  // 060623FC mov r0,r1
    c.r[1] += 38;  // 060623FE add #38,r1
    c.r[0] = ld32(0x060624ACu);  // 06062400 mov.l 0x060624AC,r0
    c.r[5] = c.r[1];  // 06062402 mov r1,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06062408u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06062408u) return; }  // 06062404 jsr @r0 ; mov r14,r4
    c.r[8] = c.r[14];  // 06062408 mov r14,r8
    c.r[8] += 39;  // 0606240A add #39,r8
    c.r[9] = ld32(0x060624B0u);  // 0606240C mov.l 0x060624B0,r9
    c.r[6] = 0x4u;  // 0606240E mov #4,r6
    c.r[5] = 0x1u;  // 06062410 mov #1,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06062416u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06062416u) return; }  // 06062412 jsr @r9 ; mov r8,r4
    c.r[0] = (uint32_t)(int32_t)(int8_t)c.r[0];  // 06062416 exts.b r0,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 06062418 cmp/eq #-1,r0
    { const bool k = c.t; c.r[6] = 0x4u; if (k) { goto L_06062426; } }  // 0606241A bt/s 0x06062426 ; mov #4,r6
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0606241E mov.b @r10,r0
    c.r[0] &= 0xE3u;  // 06062420 and #227,r0
    c.r[0] |= 0x4u;  // 06062422 or #4,r0
    st8(c.r[10], c.r[0]);  // 06062424 mov.b r0,@r10
L_06062426:
    c.r[5] = 0x2u;  // 06062426 mov #2,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0606242Cu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606242Cu) return; }  // 06062428 jsr @r9 ; mov r8,r4
    c.r[0] = (uint32_t)(int32_t)(int8_t)c.r[0];  // 0606242C exts.b r0,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0606242E cmp/eq #-1,r0
    { const bool k = c.t; c.r[6] = 0x4u; if (k) { goto L_0606243C; } }  // 06062430 bt/s 0x0606243C ; mov #4,r6
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[10]);  // 06062434 mov.b @r10,r0
    c.r[0] &= 0xE3u;  // 06062436 and #227,r0
    c.r[0] |= 0x8u;  // 06062438 or #8,r0
    st8(c.r[10], c.r[0]);  // 0606243A mov.b r0,@r10
L_0606243C:
    c.r[5] = 0x3u;  // 0606243C mov #3,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06062442u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06062442u) return; }  // 0606243E jsr @r9 ; mov r8,r4
    c.r[0] = (uint32_t)(int32_t)(int8_t)c.r[0];  // 06062442 exts.b r0,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 06062444 cmp/eq #-1,r0
    { const bool k = c.t; c.r[6] = 0x4u; if (k) { goto L_06062452; } }  // 06062446 bt/s 0x06062452 ; mov #4,r6
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0606244A mov.b @r10,r0
    c.r[0] &= 0xE3u;  // 0606244C and #227,r0
    c.r[0] |= 0xCu;  // 0606244E or #12,r0
    st8(c.r[10], c.r[0]);  // 06062450 mov.b r0,@r10
L_06062452:
    c.r[5] = 0xEu;  // 06062452 mov #14,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06062458u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06062458u) return; }  // 06062454 jsr @r9 ; mov r8,r4
    c.r[0] = (uint32_t)(int32_t)(int8_t)c.r[0];  // 06062458 exts.b r0,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0606245A cmp/eq #-1,r0
    { const bool k = c.t; c.r[6] = 0x4u; if (k) { goto L_06062468; } }  // 0606245C bt/s 0x06062468 ; mov #4,r6
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[10]);  // 06062460 mov.b @r10,r0
    c.r[0] &= 0xFCu;  // 06062462 and #252,r0
    c.r[0] |= 0x1u;  // 06062464 or #1,r0
    st8(c.r[10], c.r[0]);  // 06062466 mov.b r0,@r10
L_06062468:
    c.r[5] = 0x4u;  // 06062468 mov #4,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0606246Eu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606246Eu) return; }  // 0606246A jsr @r9 ; mov r8,r4
    c.r[0] = (uint32_t)(int32_t)(int8_t)c.r[0];  // 0606246E exts.b r0,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 06062470 cmp/eq #-1,r0
    if (c.t) { goto L_0606247C; }  // 06062472 bt 0x0606247C
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[10]);  // 06062474 mov.b @r10,r0
    c.r[0] &= 0xFCu;  // 06062476 and #252,r0
    c.r[0] |= 0x2u;  // 06062478 or #2,r0
    st8(c.r[10], c.r[0]);  // 0606247A mov.b r0,@r10
L_0606247C:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0606247C mov.b @r10,r0
    c.r[1] = 0x1Fu;  // 0606247E mov #31,r1
    c.r[1] &= c.r[0];  // 06062480 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06062482 tst r1,r1
    { const bool k = !c.t; c.r[0] &= 0xE3u; if (k) { goto L_0606248C; } }  // 06062484 bf/s 0x0606248C ; and #227,r0
    c.r[0] |= 0x4u;  // 06062488 or #4,r0
    st8(c.r[10], c.r[0]);  // 0606248A mov.b r0,@r10
L_0606248C:
    c.r[3] = (uint32_t)(int16_t)ld16(0x060624A0u);  // 0606248C mov.w 0x060624A0,r3
    c.r[14] += c.r[3];  // 0606248E add r3,r14
    c.r[15] = c.r[14];  // 06062490 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06062492 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06062494 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06062496 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06062498 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0606249A rts ; mov.l @r15+,r8
}

void f_060624B4(SH2Context& c) {
    ran[1470] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060624B4 mov.l r14,@-r15
    c.r[1] = ld32(0x06062598u);  // 060624B6 mov.l 0x06062598,r1
    c.r[1] = ld32(c.r[1]);  // 060624B8 mov.l @r1,r1
    c.r[1] += 1;  // 060624BA add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060624BC mov.b @r1,r2
    c.r[1] = 0x20u;  // 060624BE mov #32,r1
    c.r[2] += 16;  // 060624C0 add #16,r2
    c.t = c.r[2] > c.r[1];  // 060624C2 cmp/hi r1,r2
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0606257C; } }  // 060624C4 bt/s 0x0606257C ; mov r15,r14
    c.r[1] = c.r[2];  // 060624C8 mov r2,r1
    c.r[1] += c.r[1];  // 060624CA add r1,r1
    c.r[0] = 0x060624D8u;  // 060624CC mova 0x060624D8,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 060624CE mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 060624D0 add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x06062544u: goto L_06062544; case 0x0606257Cu: goto L_0606257C; case 0x0606251Au: goto L_0606251A; case 0x0606252Eu: goto L_0606252E; case 0x06062570u: goto L_06062570; case 0x06062558u: goto L_06062558; default: sh2_call(c, x); return; } }  // 060624D2 jmp @r0 ; nop
L_0606251A:
    c.r[3] = ld32(0x0606259Cu);  // 0606251A mov.l 0x0606259C,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0606251C mov.b @r3,r2
    c.r[1] = c.r[2] & 0xFFu;  // 0606251E extu.b r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06062520 tst r1,r1
    { const bool k = c.t; c.r[15] = c.r[14]; if (k) { goto L_0606258A; } }  // 06062522 bt/s 0x0606258A ; mov r14,r15
    c.r[1] = c.r[2];  // 06062526 mov r2,r1
    c.r[1] -= 1;  // 06062528 add #-1,r1
    st8(c.r[3], c.r[1]); goto L_0606258A;  // 0606252A bra 0x0606258A ; mov.b r1,@r3
L_0606252E:
    c.r[7] = ld32(0x0606259Cu);  // 0606252E mov.l 0x0606259C,r7
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06062530 mov.b @r7,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x06062590u);  // 06062532 mov.w 0x06062590,r1
    c.r[2] = c.r[3] & 0xFFu;  // 06062534 extu.b r3,r2
    c.t = c.r[2] > c.r[1];  // 06062536 cmp/hi r1,r2
    { const bool k = c.t; c.r[15] = c.r[14]; if (k) { goto L_0606258A; } }  // 06062538 bt/s 0x0606258A ; mov r14,r15
    c.r[1] = c.r[3];  // 0606253C mov r3,r1
    c.r[1] += 1;  // 0606253E add #1,r1
    st8(c.r[7], c.r[1]); goto L_0606258A;  // 06062540 bra 0x0606258A ; mov.b r1,@r7
L_06062544:
    c.r[3] = ld32(0x0606259Cu);  // 06062544 mov.l 0x0606259C,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06062546 mov.b @r3,r2
    c.r[1] = c.r[2] & 0xFFu;  // 06062548 extu.b r2,r1
    c.r[1] -= 16;  // 0606254A add #-16,r1
    c.t = (int32_t)c.r[1] > 0;  // 0606254C cmp/pl r1
    { const bool k = !c.t; c.r[1] = c.r[2]; if (k) { goto L_06062588; } }  // 0606254E bf/s 0x06062588 ; mov r2,r1
    c.r[1] -= 16;  // 06062552 add #-16,r1
    st8(c.r[3], c.r[1]); goto L_06062588;  // 06062554 bra 0x06062588 ; mov.b r1,@r3
L_06062558:
    c.r[7] = ld32(0x0606259Cu);  // 06062558 mov.l 0x0606259C,r7
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0606255A mov.b @r7,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x06062592u);  // 0606255C mov.w 0x06062592,r1
    c.r[2] = c.r[3] & 0xFFu;  // 0606255E extu.b r3,r2
    c.r[2] += 16;  // 06062560 add #16,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 06062562 cmp/gt r1,r2
    { const bool k = c.t; c.r[15] = c.r[14]; if (k) { goto L_0606258A; } }  // 06062564 bt/s 0x0606258A ; mov r14,r15
    c.r[1] = c.r[3];  // 06062568 mov r3,r1
    c.r[1] += 16;  // 0606256A add #16,r1
    st8(c.r[7], c.r[1]); goto L_0606258A;  // 0606256C bra 0x0606258A ; mov.b r1,@r7
L_06062570:
    c.r[1] = ld32(0x060625A0u);  // 06062570 mov.l 0x060625A0,r1
    c.r[2] = ld32(c.r[1]);  // 06062572 mov.l @r1,r2
    c.r[1] = ld32(0x0606259Cu);  // 06062574 mov.l 0x0606259C,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06062576 mov.b @r1,r1
    c.r[2] += 6; goto L_06062586;  // 06062578 bra 0x06062586 ; add #6,r2
L_0606257C:
    c.r[1] = ld32(0x060625A0u);  // 0606257C mov.l 0x060625A0,r1
    c.r[1] = ld32(c.r[1]);  // 0606257E mov.l @r1,r1
    c.r[1] += 6;  // 06062580 add #6,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06062582 mov.b @r1,r1
    c.r[2] = ld32(0x0606259Cu);  // 06062584 mov.l 0x0606259C,r2
L_06062586:
    st8(c.r[2], c.r[1]);  // 06062586 mov.b r1,@r2
L_06062588:
    c.r[15] = c.r[14];  // 06062588 mov r14,r15
L_0606258A:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06062594u);  // 0606258A mov.w 0x06062594,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0606258C rts ; mov.l @r15+,r14
}

void f_060625A4(SH2Context& c) {
    ran[1471] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060625A4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060625A6 sts.l pr,@-r15
    c.r[1] = ld32(0x060625C4u);  // 060625A8 mov.l 0x060625C4,r1
    c.r[1] = ld32(c.r[1]);  // 060625AA mov.l @r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060625AC mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 060625AE extu.b r1,r0
    c.r[0] <<= 2;  // 060625B0 shll2 r0
    c.r[1] = ld32(0x060625C8u);  // 060625B2 mov.l 0x060625C8,r1
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 060625B4 mov.l @(r0,r1),r0
    { const uint32_t x = c.r[0]; c.pr = 0x060625BAu; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060625BAu) return; }  // 060625B6 jsr @r0 ; mov r15,r14
    c.r[15] = c.r[14];  // 060625BA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060625BC lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060625BE mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[0] & 0xFFFFu; c.pc = x; return; }  // 060625C0 rts ; extu.w r0,r0
}

void f_060625CC(SH2Context& c) {
    ran[1472] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060625CC mov.l r14,@-r15
    c.r[14] = c.r[15];  // 060625CE mov r15,r14
    c.r[2] = ld32(0x0606264Cu);  // 060625D0 mov.l 0x0606264C,r2
    c.r[1] = c.r[2];  // 060625D2 mov r2,r1
    c.r[1] += 16;  // 060625D4 add #16,r1
    c.r[7] = 0x0u;  // 060625D6 mov #0,r7
    c.r[6] = 0xFFFFFFFFu;  // 060625D8 mov #-1,r6
    c.r[3] = c.r[2];  // 060625DA mov r2,r3
    c.r[3] += 20;  // 060625DC add #20,r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060625DE mov.b @r1,r0
    c.r[5] = 0x3Fu;  // 060625E0 mov #63,r5
    c.r[0] &= 0xBu;  // 060625E2 and #11,r0
    c.r[0] |= 0xAu;  // 060625E4 or #10,r0
    st8(c.r[1], c.r[0]);  // 060625E6 mov.b r0,@r1
    c.r[1] = c.r[2];  // 060625E8 mov r2,r1
    c.r[1] += 17;  // 060625EA add #17,r1
    st8(c.r[1], c.r[7]);  // 060625EC mov.b r7,@r1
    c.r[1] = c.r[2];  // 060625EE mov r2,r1
    c.r[1] += 18;  // 060625F0 add #18,r1
    st8(c.r[1], c.r[6]);  // 060625F2 mov.b r6,@r1
    c.r[1] = c.r[2];  // 060625F4 mov r2,r1
    c.r[1] += 19;  // 060625F6 add #19,r1
    st8(c.r[1], c.r[6]);  // 060625F8 mov.b r6,@r1
    c.r[1] = ld32(0x06062650u);  // 060625FA mov.l 0x06062650,r1
    st32(c.r[2] + 4, c.r[1]);  // 060625FC mov.l r1,@(4,r2)
    c.r[1] = ld32(0x06062654u);  // 060625FE mov.l 0x06062654,r1
    st32(c.r[2] + 8, c.r[1]);  // 06062600 mov.l r1,@(8,r2)
    c.r[1] = c.r[2];  // 06062602 mov r2,r1
    c.r[1] += 21;  // 06062604 add #21,r1
    st8(c.r[1], c.r[7]);  // 06062606 mov.b r7,@r1
    st8(c.r[3], c.r[7]);  // 06062608 mov.b r7,@r3
    c.r[3] = c.r[2];  // 0606260A mov r2,r3
    c.r[3] += 22;  // 0606260C add #22,r3
    c.r[7] = ld32(0x06062658u);  // 0606260E mov.l 0x06062658,r7
    c.r[1] = c.r[7];  // 06062610 mov r7,r1
    c.r[1] += 88;  // 06062612 add #88,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06062614 mov.w @r1,r1
    c.r[7] += 90;  // 06062616 add #90,r7
    st16(c.r[3], c.r[1]);  // 06062618 mov.w r1,@r3
    c.r[3] = c.r[2];  // 0606261A mov r2,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0606261C mov.b @r7,r1
    c.r[3] += 24;  // 0606261E add #24,r3
    st8(c.r[3], c.r[1]);  // 06062620 mov.b r1,@r3
    c.r[1] = ld32(0x0606265Cu);  // 06062622 mov.l 0x0606265C,r1
    st32(c.r[2], c.r[1]);  // 06062624 mov.l r1,@r2
    c.r[7] = 0x0u;  // 06062626 mov #0,r7
    c.r[3] = 0x0u;  // 06062628 mov #0,r3
L_0606262A:
    c.r[1] = 0x0u;  // 0606262A mov #0,r1
L_0606262C:
    c.r[0] = ld32(c.r[2]);  // 0606262C mov.l @r2,r0
    c.r[0] += c.r[3];  // 0606262E add r3,r0
    st8(c.r[0] + c.r[1], c.r[6]);  // 06062630 mov.b r6,@(r0,r1)
    c.r[1] += 1;  // 06062632 add #1,r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[5];  // 06062634 cmp/gt r5,r1
    if (!c.t) { SH2_POLL(c); goto L_0606262C; }  // 06062636 bf 0x0606262C
    c.r[7] += 1;  // 06062638 add #1,r7
    c.r[1] = 0x3Fu;  // 0606263A mov #63,r1
    c.t = (int32_t)c.r[7] > (int32_t)c.r[1];  // 0606263C cmp/gt r1,r7
    { const bool k = !c.t; c.r[3] += 64; if (k) { SH2_POLL(c); goto L_0606262A; } }  // 0606263E bf/s 0x0606262A ; add #64,r3
    c.r[15] = c.r[14];  // 06062642 mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606264Au);  // 06062644 mov.w 0x0606264A,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06062646 rts ; mov.l @r15+,r14
}

void f_06062660(SH2Context& c) {
    ran[1473] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06062660 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06062662 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06062664 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06062666 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06062668 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0606266A mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0606266C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0606266E sts.l pr,@-r15
    c.r[15] -= 8;  // 06062670 add #-8,r15
    c.r[14] = c.r[15];  // 06062672 mov r15,r14
    c.r[9] = ld32(0x06062778u);  // 06062674 mov.l 0x06062778,r9
    c.r[8] = ld32(0x0606277Cu);  // 06062676 mov.l 0x0606277C,r8
    c.r[10] = ld32(0x06062780u);  // 06062678 mov.l 0x06062780,r10
    c.r[11] = c.r[10];  // 0606267A mov r10,r11
    c.r[11] += 88;  // 0606267C add #88,r11
    c.r[0] = ld32(0x06062784u);  // 0606267E mov.l 0x06062784,r0
    c.r[7] = 0xFFFFFFFFu;  // 06062680 mov #-1,r7
    c.r[6] = c.r[9];  // 06062682 mov r9,r6
    c.r[5] = 0x0u;  // 06062684 mov #0,r5
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[11]);  // 06062686 mov.w @r11,r1
    c.r[4] = 0x2u;  // 06062688 mov #2,r4
    c.r[1] = c.r[1] & 0xFFFFu;  // 0606268A extu.w r1,r1
    { const uint32_t x = c.r[0]; c.pr = 0x06062690u; st32(c.r[14], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06062690u) return; }  // 0606268C jsr @r0 ; mov.l r1,@r14
    c.r[0] = ld32(0x06062788u);  // 06062690 mov.l 0x06062788,r0
    c.r[5] = c.r[8];  // 06062692 mov r8,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06062698u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06062698u) return; }  // 06062694 jsr @r0 ; mov r9,r4
    c.r[1] = ld32(0x0606278Cu);  // 06062698 mov.l 0x0606278C,r1
    c.r[6] = 0x40u;  // 0606269A mov #64,r6
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606269C mov.b @r1,r5
    c.r[5] = c.r[5] & 0xFFu;  // 0606269E extu.b r5,r5
    c.r[5] <<= 2;  // 060626A0 shll2 r5
    c.r[5] += c.r[5];  // 060626A2 add r5,r5
    c.r[5] <<= 2;  // 060626A4 shll2 r5
    c.r[1] = ld32(0x06062790u);  // 060626A6 mov.l 0x06062790,r1
    c.r[5] += c.r[1];  // 060626A8 add r1,r5
    c.r[1] = ld32(0x06062794u);  // 060626AA mov.l 0x06062794,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060626B0u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060626B0u) return; }  // 060626AC jsr @r1 ; mov r8,r4
    c.r[9] = 0x0u;  // 060626B0 mov #0,r9
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606276Cu);  // 060626B2 mov.w 0x0606276C,r1
    c.r[8] += c.r[1];  // 060626B4 add r1,r8
    c.r[13] = c.r[1];  // 060626B6 mov r1,r13
L_060626B8:
    c.r[5] = ld32(c.r[10] + 4);  // 060626B8 mov.l @(4,r10),r5
    c.r[7] = 0x10u;  // 060626BA mov #16,r7
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[11]);  // 060626BC mov.w @r11,r1
    c.r[4] = ld32(c.r[10]);  // 060626BE mov.l @r10,r4
    c.r[1] = c.r[1] & 0xFFFFu;  // 060626C0 extu.w r1,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060626C2 mov.l r1,@-r15
    c.r[1] = ld32(0x06062798u);  // 060626C4 mov.l 0x06062798,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060626CAu; c.r[6] = 0x10u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060626CAu) return; }  // 060626C6 jsr @r1 ; mov #16,r6
    c.r[7] = c.r[8];  // 060626CA mov r8,r7
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[11]);  // 060626CC mov.w @r11,r5
    c.r[4] = ld32(c.r[10] + 4);  // 060626CE mov.l @(4,r10),r4
    c.r[5] = c.r[5] & 0xFFFFu;  // 060626D0 extu.w r5,r5
    c.r[1] = c.r[5];  // 060626D2 mov r5,r1
    c.r[1] <<= 2;  // 060626D4 shll2 r1
    c.r[1] += c.r[1];  // 060626D6 add r1,r1
    c.r[4] += c.r[1];  // 060626D8 add r1,r4
    c.r[1] = ld32(0x0606279Cu);  // 060626DA mov.l 0x0606279C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060626E0u; c.r[6] = 0x3u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060626E0u) return; }  // 060626DC jsr @r1 ; mov #3,r6
    c.r[12] = c.r[10];  // 060626E0 mov r10,r12
    c.r[12] += 90;  // 060626E2 add #90,r12
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[12]);  // 060626E4 mov.b @r12,r6
    c.r[1] = 0xAu;  // 060626E6 mov #10,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[11]);  // 060626E8 mov.w @r11,r2
    c.r[7] = 0x0u;  // 060626EA mov #0,r7
    c.r[4] = ld32(c.r[10] + 8);  // 060626EC mov.l @(8,r10),r4
    c.r[6] = c.r[6] & 0xFFu;  // 060626EE extu.b r6,r6
    c.macl = (c.r[2] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 060626F0 mulu.w r1,r2
    c.r[1] = c.macl;  // 060626F2 sts macl,r1
    c.r[4] += c.r[1];  // 060626F4 add r1,r4
    c.r[1] = ld32(0x060627A0u);  // 060626F6 mov.l 0x060627A0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060626F8 mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060626FA mov.l r13,@-r15
    c.r[1] = 0x0u;  // 060626FC mov #0,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 060626FE mov.l r1,@-r15
    c.r[1] = ld32(0x060627A4u);  // 06062700 mov.l 0x060627A4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06062706u; c.r[5] = c.r[2] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06062706u) return; }  // 06062702 jsr @r1 ; extu.w r2,r5
    c.r[15] += 16;  // 06062706 add #16,r15
    c.r[9] += 1;  // 06062708 add #1,r9
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[11]);  // 0606270A mov.w @r11,r1
    c.r[1] += 1;  // 0606270C add #1,r1
    st16(c.r[11], c.r[1]);  // 0606270E mov.w r1,@r11
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606276Eu);  // 06062710 mov.w 0x0606276E,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 06062712 cmp/gt r1,r9
    { const bool k = !c.t; c.r[8] += c.r[13]; if (k) { SH2_POLL(c); goto L_060626B8; } }  // 06062714 bf/s 0x060626B8 ; add r13,r8
    c.r[7] = c.r[12];  // 06062718 mov r12,r7
    c.r[7] -= 90;  // 0606271A add #-90,r7
    c.r[1] = ld32(0x060627A8u);  // 0606271C mov.l 0x060627A8,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606271E mov.w @r1,r1
    c.r[5] = (uint32_t)(int16_t)ld16(0x06062770u);  // 06062720 mov.w 0x06062770,r5
    c.r[2] = ld32(c.r[7] + 8);  // 06062722 mov.l @(8,r7),r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 06062724 extu.w r1,r1
    c.r[3] = c.r[1];  // 06062726 mov r1,r3
    c.r[3] <<= 2;  // 06062728 shll2 r3
    c.r[3] += c.r[1];  // 0606272A add r1,r3
    c.r[3] += c.r[3];  // 0606272C add r3,r3
    c.r[3] += c.r[2];  // 0606272E add r2,r3
    c.r[3] += 4;  // 06062730 add #4,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06062732 mov.w @r3,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06062772u);  // 06062734 mov.w 0x06062772,r1
    c.r[2] &= c.r[1];  // 06062736 and r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06062774u);  // 06062738 mov.w 0x06062774,r1
    c.r[2] |= c.r[1];  // 0606273A or r1,r2
    st16(c.r[3], c.r[2]);  // 0606273C mov.w r2,@r3
    c.r[3] = ld32(c.r[14]);  // 0606273E mov.l @r14,r3
    c.r[1] = ld32(0x060627ACu);  // 06062740 mov.l 0x060627AC,r1
    c.r[4] = ld32(c.r[7] + 4);  // 06062742 mov.l @(4,r7),r4
    c.r[3] <<= 2;  // 06062744 shll2 r3
    c.r[3] += c.r[3];  // 06062746 add r3,r3
    st32(c.r[14], c.r[3]);  // 06062748 mov.l r3,@r14
    { const uint32_t x = c.r[1]; c.pr = 0x0606274Eu; c.r[4] += c.r[3]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606274Eu) return; }  // 0606274A jsr @r1 ; add r3,r4
    c.r[14] += 8;  // 0606274E add #8,r14
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[12]);  // 06062750 mov.b @r12,r1
    c.r[15] = c.r[14];  // 06062752 mov r14,r15
    c.r[1] += 4;  // 06062754 add #4,r1
    st8(c.r[12], c.r[1]);  // 06062756 mov.b r1,@r12
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06062758 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0606275A mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0606275C mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0606275E mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06062760 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06062762 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06062764 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06062776u);  // 06062766 mov.w 0x06062776,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06062768 rts ; mov.l @r15+,r8
}

void f_060627B0(SH2Context& c) {
    ran[1474] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060627B0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060627B2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060627B4 sts.l pr,@-r15
    c.r[1] = ld32(0x06062844u);  // 060627B6 mov.l 0x06062844,r1
    c.r[1] = ld32(c.r[1]);  // 060627B8 mov.l @r1,r1
    c.r[1] += 1;  // 060627BA add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060627BC mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060627BE extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060627C0 tst r1,r1
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_060627EA; } }  // 060627C2 bf/s 0x060627EA ; mov r15,r14
    c.r[1] = ld32(0x06062848u);  // 060627C6 mov.l 0x06062848,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060627CCu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060627CCu) return; }  // 060627C8 jsr @r1 ; nop
    c.r[1] = ld32(0x0606284Cu);  // 060627CC mov.l 0x0606284C,r1
    c.r[5] = 0x0u;  // 060627CE mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x060627D4u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060627D4u) return; }  // 060627D0 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06062850u);  // 060627D4 mov.l 0x06062850,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060627DAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060627DAu) return; }  // 060627D6 jsr @r1 ; nop
    c.r[1] = ld32(0x06062854u);  // 060627DA mov.l 0x06062854,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060627E0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060627E0u) return; }  // 060627DC jsr @r1 ; nop
    c.r[1] = ld32(0x06062858u);  // 060627E0 mov.l 0x06062858,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060627E6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060627E6u) return; }  // 060627E2 jsr @r1 ; nop
    c.r[15] = c.r[14]; goto L_06062836;  // 060627E6 bra 0x06062836 ; mov r14,r15
L_060627EA:
    c.r[8] = ld32(0x0606285Cu);  // 060627EA mov.l 0x0606285C,r8
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[8]);  // 060627EC mov.b @r8,r4
    c.r[1] = ld32(0x06062860u);  // 060627EE mov.l 0x06062860,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060627F4u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060627F4u) return; }  // 060627F0 jsr @r1 ; extu.b r4,r4
    c.r[1] = ld32(0x06062864u);  // 060627F4 mov.l 0x06062864,r1
    c.r[6] = 0x0u;  // 060627F6 mov #0,r6
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[8]);  // 060627F8 mov.b @r8,r4
    c.r[5] = 0x0u;  // 060627FA mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06062800u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06062800u) return; }  // 060627FC jsr @r1 ; extu.b r4,r4
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06062800 mov.b @r8,r4
    c.r[1] = ld32(0x06062868u);  // 06062802 mov.l 0x06062868,r1
    c.r[1] = ld32(c.r[1]);  // 06062804 mov.l @r1,r1
    c.r[4] = c.r[4] & 0xFFu;  // 06062806 extu.b r4,r4
    c.r[2] = c.r[4];  // 06062808 mov r4,r2
    c.r[2] <<= 2;  // 0606280A shll2 r2
    c.r[2] <<= 2;  // 0606280C shll2 r2
    c.r[2] += c.r[1];  // 0606280E add r1,r2
    c.r[2] += 3;  // 06062810 add #3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06062812 mov.b @r2,r1
    c.r[0] = c.r[1];  // 06062814 mov r1,r0
    c.r[0] >>= 2;  // 06062816 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06062818 shlr r0
    c.r[0] >>= 2;  // 0606281A shlr2 r0
    c.r[0] &= 0x1u;  // 0606281C and #1,r0
    c.r[1] = ld32(0x0606286Cu);  // 0606281E mov.l 0x0606286C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06062824u; c.r[5] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06062824u) return; }  // 06062820 jsr @r1 ; mov r0,r5
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06062824 mov.b @r8,r4
    c.r[1] = ld32(0x06062870u);  // 06062826 mov.l 0x06062870,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606282Cu; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606282Cu) return; }  // 06062828 jsr @r1 ; extu.b r4,r4
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0606282C mov.b @r8,r4
    c.r[1] = ld32(0x06062874u);  // 0606282E mov.l 0x06062874,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06062834u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06062834u) return; }  // 06062830 jsr @r1 ; extu.b r4,r4
    c.r[15] = c.r[14];  // 06062834 mov r14,r15
L_06062836:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06062836 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06062838 mov.l @r15+,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x06062840u);  // 0606283A mov.w 0x06062840,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0606283C rts ; mov.l @r15+,r8
}

void f_06062878(SH2Context& c) {
    ran[1475] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06062878 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0606287A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0606287C sts.l pr,@-r15
    c.r[1] = ld32(0x060628C8u);  // 0606287E mov.l 0x060628C8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06062880 mov.b @r1,r1
    c.r[6] = c.r[1] & 0xFFu;  // 06062882 extu.b r1,r6
    c.r[1] = (uint32_t)(int16_t)ld16(0x060628C2u);  // 06062884 mov.w 0x060628C2,r1
    c.t = c.r[6] == c.r[1];  // 06062886 cmp/eq r1,r6
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_060628B6; } }  // 06062888 bt/s 0x060628B6 ; mov r15,r14
    c.r[1] = ld32(0x060628CCu);  // 0606288C mov.l 0x060628CC,r1
    c.r[2] = c.r[6];  // 0606288E mov r6,r2
    c.r[2] <<= 2;  // 06062890 shll2 r2
    c.r[2] <<= 2;  // 06062892 shll2 r2
    c.r[1] = ld32(c.r[1]);  // 06062894 mov.l @r1,r1
    c.r[8] = ld32(0x060628D0u);  // 06062896 mov.l 0x060628D0,r8
    c.r[4] = ld32(c.r[8]);  // 06062898 mov.l @r8,r4
    c.r[2] += c.r[1];  // 0606289A add r1,r2
    c.r[2] += 2;  // 0606289C add #2,r2
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606289E mov.b @r2,r5
    c.r[1] = ld32(0x060628D4u);  // 060628A0 mov.l 0x060628D4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060628A6u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060628A6u) return; }  // 060628A2 jsr @r1 ; extu.b r5,r5
    c.r[1] = ld32(c.r[8]);  // 060628A6 mov.l @r8,r1
    c.r[1] += 14;  // 060628A8 add #14,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060628AA mov.b @r1,r5
    c.r[1] = ld32(0x060628D8u);  // 060628AC mov.l 0x060628D8,r1
    c.r[4] = ld32(c.r[1]);  // 060628AE mov.l @r1,r4
    c.r[1] = ld32(0x060628DCu);  // 060628B0 mov.l 0x060628DC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060628B6u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060628B6u) return; }  // 060628B2 jsr @r1 ; extu.b r5,r5
L_060628B6:
    c.r[15] = c.r[14];  // 060628B6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060628B8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060628BA mov.l @r15+,r14
    c.r[0] = (uint32_t)(int16_t)ld16(0x060628C4u);  // 060628BC mov.w 0x060628C4,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060628BE rts ; mov.l @r15+,r8
}

void f_060628E0(SH2Context& c) {
    ran[1476] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060628E0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060628E2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060628E4 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060628E6 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060628E8 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060628EA mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060628EC sts.l pr,@-r15
    c.r[15] -= 8;  // 060628EE add #-8,r15
    c.r[14] = c.r[15];  // 060628F0 mov r15,r14
    c.r[1] = 0x0u;  // 060628F2 mov #0,r1
    c.r[2] = 0x0u;  // 060628F4 mov #0,r2
    st32(c.r[14], c.r[1]);  // 060628F6 mov.l r1,@r14
    st32(c.r[14] + 4, c.r[2]);  // 060628F8 mov.l r2,@(4,r14)
    c.r[1] = ld32(0x06062A70u);  // 060628FA mov.l 0x06062A70,r1
    st32(c.r[14], c.r[1]);  // 060628FC mov.l r1,@r14
    c.r[1] = ld32(0x06062A74u);  // 060628FE mov.l 0x06062A74,r1
    st32(c.r[14] + 4, c.r[1]);  // 06062900 mov.l r1,@(4,r14)
    c.r[1] = ld32(0x06062A78u);  // 06062902 mov.l 0x06062A78,r1
    c.r[1] = ld32(c.r[1]);  // 06062904 mov.l @r1,r1
    c.r[1] += 1;  // 06062906 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06062908 mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0606290A extu.b r1,r2
    c.r[0] = c.r[2];  // 0606290C mov r2,r0
    c.t = c.r[0] == 0x2u;  // 0606290E cmp/eq #2,r0
    { const bool k = !c.t; c.r[5] = 0x0u; if (k) { goto L_06062918; } }  // 06062910 bf/s 0x06062918 ; mov #0,r5
    goto L_06062AF4;  // 06062914 bra 0x06062AF4 ; nop
L_06062918:
    c.r[1] = 0x2u;  // 06062918 mov #2,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0606291A cmp/gt r1,r2
    { const bool k = c.t; c.t = c.r[0] == 0x3u; if (k) { goto L_0606292A; } }  // 0606291C bt/s 0x0606292A ; cmp/eq #3,r0
    c.t = c.r[0] == 0x1u;  // 06062920 cmp/eq #1,r0
    { const bool k = c.t; c.r[10] = 0x0u; if (k) { goto L_06062936; } }  // 06062922 bt/s 0x06062936 ; mov #0,r10
    goto L_06062C9E;  // 06062926 bra 0x06062C9E ; nop
L_0606292A:
    { const bool k = !c.t; c.r[4] = 0x0u; if (k) { goto L_06062932; } }  // 0606292A bf/s 0x06062932 ; mov #0,r4
    goto L_06062B78;  // 0606292E bra 0x06062B78 ; nop
L_06062932:
    goto L_06062C9E;  // 06062932 bra 0x06062C9E ; nop
L_06062936:
    c.r[12] = ld32(0x06062A7Cu);  // 06062936 mov.l 0x06062A7C,r12
    c.r[9] = ld32(0x06062A80u);  // 06062938 mov.l 0x06062A80,r9
    c.r[11] = (uint32_t)(int16_t)ld16(0x06062A6Cu);  // 0606293A mov.w 0x06062A6C,r11
L_0606293C:
    c.r[0] = c.r[5];  // 0606293C mov r5,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[12]);  // 0606293E mov.b @(r0,r12),r1
    c.r[8] = c.r[1] & 0xFFu;  // 06062940 extu.b r1,r8
    c.r[0] = c.r[10];  // 06062942 mov r10,r0
    c.r[1] = ld32(c.r[0] + c.r[14]);  // 06062944 mov.l @(r0,r14),r1
    c.r[1] += 2;  // 06062946 add #2,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06062948 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0606294A extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606294C tst r1,r1
    { const bool k = c.t; c.r[3] = c.r[8]; if (k) { goto L_06062970; } }  // 0606294E bt/s 0x06062970 ; mov r8,r3
    c.r[2] = c.r[8];  // 06062952 mov r8,r2
    c.r[1] = ld32(c.r[9]);  // 06062954 mov.l @r9,r1
    c.r[2] <<= 2;  // 06062956 shll2 r2
    c.r[2] <<= 2;  // 06062958 shll2 r2
    c.r[1] += c.r[2];  // 0606295A add r2,r1
    c.r[1] += 10;  // 0606295C add #10,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606295E mov.b @r1,r0
    c.r[0] &= 0xBFu;  // 06062960 and #191,r0
    st8(c.r[1], c.r[0]);  // 06062962 mov.b r0,@r1
    c.r[1] = ld32(c.r[9]);  // 06062964 mov.l @r9,r1
    c.r[1] += c.r[2];  // 06062966 add r2,r1
    c.r[1] += 11;  // 06062968 add #11,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606296A mov.b @r1,r0
    c.r[0] &= 0xEFu;  // 0606296C and #239,r0
    st8(c.r[1], c.r[0]);  // 0606296E mov.b r0,@r1
L_06062970:
    c.r[7] = ld32(c.r[9]);  // 06062970 mov.l @r9,r7
    c.r[3] <<= 2;  // 06062972 shll2 r3
    c.r[3] <<= 2;  // 06062974 shll2 r3
    c.r[3] += c.r[7];  // 06062976 add r7,r3
    c.r[3] += 9;  // 06062978 add #9,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0606297A mov.b @r3,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606297C extu.b r1,r1
    c.t = c.r[1] == c.r[11];  // 0606297E cmp/eq r11,r1
    { const bool k = c.t; c.r[2] = c.r[8]; if (k) { goto L_06062A0C; } }  // 06062980 bt/s 0x06062A0C ; mov r8,r2
    c.r[2] = 0x0u;  // 06062984 mov #0,r2
    c.r[6] = c.r[7];  // 06062986 mov r7,r6
    c.r[4] = c.r[3];  // 06062988 mov r3,r4
    c.r[3] = 0x0u;  // 0606298A mov #0,r3
L_0606298C:
    c.r[0] = c.r[3];  // 0606298C mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 0606298E mov.b @(r0,r6),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06062990 extu.b r1,r1
    c.t = c.r[1] == c.r[11];  // 06062992 cmp/eq r11,r1
    { const bool k = c.t; c.r[1] = c.r[7]; if (k) { goto L_060629B2; } }  // 06062994 bt/s 0x060629B2 ; mov r7,r1
    c.r[1] += 7;  // 06062998 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606299A mov.b @r1,r1
    c.r[0] = c.r[1];  // 0606299C mov r1,r0
    c.r[0] >>= 2;  // 0606299E shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060629A0 shlr r0
    c.r[0] &= 0x1u;  // 060629A2 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060629A4 tst r0,r0
    if (!c.t) { goto L_060629B2; }  // 060629A6 bf 0x060629B2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]);  // 060629A8 mov.b @r4,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060629AA extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 060629AC cmp/eq r2,r1
    { const bool k = c.t; c.r[0] = c.r[2]; if (k) { goto L_060629C0; } }  // 060629AE bt/s 0x060629C0 ; mov r2,r0
L_060629B2:
    c.r[7] += 16;  // 060629B2 add #16,r7
    c.r[2] += 1;  // 060629B4 add #1,r2
    c.r[1] = 0x49u;  // 060629B6 mov #73,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 060629B8 cmp/gt r1,r2
    { const bool k = !c.t; c.r[3] += 16; if (k) { SH2_POLL(c); goto L_0606298C; } }  // 060629BA bf/s 0x0606298C ; add #16,r3
    c.r[0] = c.r[2];  // 060629BE mov r2,r0
L_060629C0:
    c.t = c.r[0] == 0x4Au;  // 060629C0 cmp/eq #74,r0
    { const bool k = c.t; c.t = (c.r[5] & c.r[5]) == 0; if (k) { goto L_06062A0A; } }  // 060629C2 bt/s 0x06062A0A ; tst r5,r5
    c.r[1] = c.t;  // 060629C6 movt r1
    c.r[0] = c.r[1];  // 060629C8 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[12]);  // 060629CA mov.b @(r0,r12),r1
    c.r[3] = c.r[1] & 0xFFu;  // 060629CC extu.b r1,r3
    c.t = c.r[2] == c.r[3];  // 060629CE cmp/eq r3,r2
    if (c.t) { goto L_060629FA; }  // 060629D0 bt 0x060629FA
    c.r[1] = ld32(c.r[9]);  // 060629D2 mov.l @r9,r1
    c.r[2] <<= 2;  // 060629D4 shll2 r2
    c.r[2] <<= 2;  // 060629D6 shll2 r2
    c.r[2] += c.r[1];  // 060629D8 add r1,r2
    c.r[1] = c.r[2];  // 060629DA mov r2,r1
    c.r[1] += 4;  // 060629DC add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060629DE mov.b @r1,r1
    c.r[0] = c.r[1];  // 060629E0 mov r1,r0
    c.r[0] >>= 2;  // 060629E2 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060629E4 shlr r0
    c.r[0] >>= 2;  // 060629E6 shlr2 r0
    c.r[0] &= 0x1u;  // 060629E8 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060629EA tst r0,r0
    { const bool k = c.t; c.r[2] += 6; if (k) { goto L_06062A0A; } }  // 060629EC bt/s 0x06062A0A ; add #6,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060629F0 mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060629F2 extu.b r1,r1
    c.t = c.r[1] == c.r[3];  // 060629F4 cmp/eq r3,r1
    { const bool k = !c.t; c.r[2] = c.r[8]; if (k) { goto L_06062A0C; } }  // 060629F6 bf/s 0x06062A0C ; mov r8,r2
L_060629FA:
    c.r[1] = ld32(c.r[9]);  // 060629FA mov.l @r9,r1
    c.r[2] = c.r[8];  // 060629FC mov r8,r2
    c.r[2] <<= 2;  // 060629FE shll2 r2
    c.r[2] <<= 2;  // 06062A00 shll2 r2
    c.r[2] += c.r[1];  // 06062A02 add r1,r2
    c.r[2] += 9;  // 06062A04 add #9,r2
    c.r[1] = 0xFFFFFFFFu;  // 06062A06 mov #-1,r1
    st8(c.r[2], c.r[1]);  // 06062A08 mov.b r1,@r2
L_06062A0A:
    c.r[2] = c.r[8];  // 06062A0A mov r8,r2
L_06062A0C:
    c.r[1] = ld32(c.r[9]);  // 06062A0C mov.l @r9,r1
    c.r[2] <<= 2;  // 06062A0E shll2 r2
    c.r[2] <<= 2;  // 06062A10 shll2 r2
    c.r[1] += c.r[2];  // 06062A12 add r2,r1
    c.r[1] += 10;  // 06062A14 add #10,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06062A16 mov.b @r1,r0
    c.r[0] &= 0xDFu;  // 06062A18 and #223,r0
    st8(c.r[1], c.r[0]);  // 06062A1A mov.b r0,@r1
    c.r[1] = ld32(c.r[9]);  // 06062A1C mov.l @r9,r1
    c.r[1] += c.r[2];  // 06062A1E add r2,r1
    c.r[1] += 10;  // 06062A20 add #10,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06062A22 mov.b @r1,r0
    c.r[0] &= 0xFDu;  // 06062A24 and #253,r0
    st8(c.r[1], c.r[0]);  // 06062A26 mov.b r0,@r1
    c.r[1] = ld32(c.r[9]);  // 06062A28 mov.l @r9,r1
    c.r[1] += c.r[2];  // 06062A2A add r2,r1
    c.r[1] += 11;  // 06062A2C add #11,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06062A2E mov.b @r1,r0
    c.r[5] += 1;  // 06062A30 add #1,r5
    c.r[0] &= 0xF7u;  // 06062A32 and #247,r0
    st8(c.r[1], c.r[0]);  // 06062A34 mov.b r0,@r1
    c.r[1] = 0x1u;  // 06062A36 mov #1,r1
    c.t = (int32_t)c.r[5] > (int32_t)c.r[1];  // 06062A38 cmp/gt r1,r5
    { const bool k = c.t; c.r[10] += 4; if (k) { goto L_06062A42; } }  // 06062A3A bt/s 0x06062A42 ; add #4,r10
    SH2_POLL(c); goto L_0606293C;  // 06062A3E bra 0x0606293C ; nop
L_06062A42:
    c.r[1] = ld32(0x06062A84u);  // 06062A42 mov.l 0x06062A84,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06062A44 mov.b @r1,r1
    c.r[0] = ld32(0x06062A88u);  // 06062A46 mov.l 0x06062A88,r0
    c.r[8] = c.r[1] & 0xFFu;  // 06062A48 extu.b r1,r8
    { const uint32_t x = c.r[0]; c.pr = 0x06062A4Eu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06062A4Eu) return; }  // 06062A4A jsr @r0 ; mov r8,r4
    c.r[5] = c.r[0] & 0xFFu;  // 06062A4E extu.b r0,r5
    c.r[2] = (uint32_t)(int16_t)ld16(0x06062A6Cu);  // 06062A50 mov.w 0x06062A6C,r2
    c.t = c.r[5] == c.r[2];  // 06062A52 cmp/eq r2,r5
    if (!c.t) { goto L_06062A8C; }  // 06062A54 bf 0x06062A8C
    c.r[2] = c.r[8];  // 06062A56 mov r8,r2
    c.r[1] = ld32(0x06062A80u);  // 06062A58 mov.l 0x06062A80,r1
    c.r[1] = ld32(c.r[1]);  // 06062A5A mov.l @r1,r1
    c.r[2] <<= 2;  // 06062A5C shll2 r2
    c.r[2] <<= 2;  // 06062A5E shll2 r2
    c.r[2] += c.r[1];  // 06062A60 add r1,r2
    c.r[2] += 10;  // 06062A62 add #10,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06062A64 mov.b @r2,r0
    c.r[0] &= 0xF7u;  // 06062A66 and #247,r0
    st8(c.r[2], c.r[0]); goto L_06062A9A;  // 06062A68 bra 0x06062A9A ; mov.b r0,@r2
L_06062A8C:
    c.r[1] = ld32(0x06062B64u);  // 06062A8C mov.l 0x06062B64,r1
    c.r[1] = ld32(c.r[1]);  // 06062A8E mov.l @r1,r1
    c.r[8] <<= 2;  // 06062A90 shll2 r8
    c.r[8] <<= 2;  // 06062A92 shll2 r8
    c.r[8] += c.r[1];  // 06062A94 add r1,r8
    c.r[8] += 8;  // 06062A96 add #8,r8
    st8(c.r[8], c.r[2]);  // 06062A98 mov.b r2,@r8
L_06062A9A:
    c.r[1] = ld32(0x06062B68u);  // 06062A9A mov.l 0x06062B68,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06062A9C mov.b @r1,r1
    c.r[0] = ld32(0x06062B6Cu);  // 06062A9E mov.l 0x06062B6C,r0
    c.r[8] = c.r[1] & 0xFFu;  // 06062AA0 extu.b r1,r8
    { const uint32_t x = c.r[0]; c.pr = 0x06062AA6u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06062AA6u) return; }  // 06062AA2 jsr @r0 ; mov r8,r4
    c.r[1] = ld32(0x06062B70u);  // 06062AA6 mov.l 0x06062B70,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06062AA8 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06062AAA extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06062AAC tst r1,r1
    { const bool k = !c.t; c.r[5] = c.r[0] & 0xFFu; if (k) { goto L_06062AB6; } }  // 06062AAE bf/s 0x06062AB6 ; extu.b r0,r5
    goto L_06062CB6;  // 06062AB2 bra 0x06062CB6 ; nop
L_06062AB6:
    c.r[1] = ld32(0x06062B74u);  // 06062AB6 mov.l 0x06062B74,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06062AB8 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06062ABA mov r1,r0
    c.r[0] >>= 2;  // 06062ABC shlr2 r0
    c.r[0] >>= 2;  // 06062ABE shlr2 r0
    c.r[0] &= 0x1u;  // 06062AC0 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06062AC2 tst r0,r0
    if (c.t) { goto L_06062ACA; }  // 06062AC4 bt 0x06062ACA
    goto L_06062CB6;  // 06062AC6 bra 0x06062CB6 ; nop
L_06062ACA:
    c.r[2] = (uint32_t)(int16_t)ld16(0x06062B62u);  // 06062ACA mov.w 0x06062B62,r2
    c.t = c.r[5] == c.r[2];  // 06062ACC cmp/eq r2,r5
    if (!c.t) { goto L_06062AE4; }  // 06062ACE bf 0x06062AE4
    c.r[2] = c.r[8];  // 06062AD0 mov r8,r2
    c.r[1] = ld32(0x06062B64u);  // 06062AD2 mov.l 0x06062B64,r1
    c.r[1] = ld32(c.r[1]);  // 06062AD4 mov.l @r1,r1
    c.r[2] <<= 2;  // 06062AD6 shll2 r2
    c.r[2] <<= 2;  // 06062AD8 shll2 r2
    c.r[2] += c.r[1];  // 06062ADA add r1,r2
    c.r[2] += 10;  // 06062ADC add #10,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06062ADE mov.b @r2,r0
    c.r[0] &= 0xF7u; goto L_06062CB4;  // 06062AE0 bra 0x06062CB4 ; and #247,r0
L_06062AE4:
    c.r[1] = ld32(0x06062B64u);  // 06062AE4 mov.l 0x06062B64,r1
    c.r[1] = ld32(c.r[1]);  // 06062AE6 mov.l @r1,r1
    c.r[8] <<= 2;  // 06062AE8 shll2 r8
    c.r[8] <<= 2;  // 06062AEA shll2 r8
    c.r[8] += c.r[1];  // 06062AEC add r1,r8
    c.r[8] += 8;  // 06062AEE add #8,r8
    st8(c.r[8], c.r[2]); goto L_06062CB6;  // 06062AF0 bra 0x06062CB6 ; mov.b r2,@r8
L_06062AF4:
    c.r[7] = ld32(0x06062B64u);  // 06062AF4 mov.l 0x06062B64,r7
    c.r[6] = (uint32_t)(int16_t)ld16(0x06062B62u);  // 06062AF6 mov.w 0x06062B62,r6
    c.r[2] = 0x0u;  // 06062AF8 mov #0,r2
L_06062AFA:
    c.r[0] = ld32(c.r[7]);  // 06062AFA mov.l @r7,r0
    c.r[3] = c.r[2];  // 06062AFC mov r2,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06062AFE mov.b @(r0,r2),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06062B00 extu.b r1,r1
    c.t = c.r[1] == c.r[6];  // 06062B02 cmp/eq r6,r1
    { const bool k = c.t; c.r[3] += c.r[0]; if (k) { goto L_06062B54; } }  // 06062B04 bt/s 0x06062B54 ; add r0,r3
    c.r[1] = c.r[3];  // 06062B08 mov r3,r1
    c.r[1] += 7;  // 06062B0A add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06062B0C mov.b @r1,r1
    c.r[0] = c.r[1];  // 06062B0E mov r1,r0
    c.r[0] >>= 2;  // 06062B10 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06062B12 shlr r0
    c.r[0] &= 0x1u;  // 06062B14 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06062B16 tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[3]; if (k) { goto L_06062B54; } }  // 06062B18 bf/s 0x06062B54 ; mov r3,r1
    c.r[1] += 10;  // 06062B1C add #10,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06062B1E mov.b @r1,r0
    c.r[0] &= 0xEFu;  // 06062B20 and #239,r0
    st8(c.r[1], c.r[0]);  // 06062B22 mov.b r0,@r1
    c.r[1] = ld32(c.r[7]);  // 06062B24 mov.l @r7,r1
    c.r[1] += c.r[2];  // 06062B26 add r2,r1
    c.r[1] += 10;  // 06062B28 add #10,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06062B2A mov.b @r1,r0
    c.r[0] &= 0xFEu;  // 06062B2C and #254,r0
    st8(c.r[1], c.r[0]);  // 06062B2E mov.b r0,@r1
    c.r[1] = ld32(c.r[7]);  // 06062B30 mov.l @r7,r1
    c.r[1] += c.r[2];  // 06062B32 add r2,r1
    c.r[1] += 11;  // 06062B34 add #11,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06062B36 mov.b @r1,r0
    c.r[0] &= 0x7Fu;  // 06062B38 and #127,r0
    st8(c.r[1], c.r[0]);  // 06062B3A mov.b r0,@r1
    c.r[1] = ld32(c.r[7]);  // 06062B3C mov.l @r7,r1
    c.r[1] += c.r[2];  // 06062B3E add r2,r1
    c.r[1] += 11;  // 06062B40 add #11,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06062B42 mov.b @r1,r0
    c.r[0] &= 0xBFu;  // 06062B44 and #191,r0
    st8(c.r[1], c.r[0]);  // 06062B46 mov.b r0,@r1
    c.r[1] = ld32(c.r[7]);  // 06062B48 mov.l @r7,r1
    c.r[1] += c.r[2];  // 06062B4A add r2,r1
    c.r[1] += 11;  // 06062B4C add #11,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06062B4E mov.b @r1,r0
    c.r[0] &= 0xDFu;  // 06062B50 and #223,r0
    st8(c.r[1], c.r[0]);  // 06062B52 mov.b r0,@r1
L_06062B54:
    c.r[5] += 1;  // 06062B54 add #1,r5
    c.r[1] = 0x49u;  // 06062B56 mov #73,r1
    c.t = (int32_t)c.r[5] > (int32_t)c.r[1];  // 06062B58 cmp/gt r1,r5
    { const bool k = !c.t; c.r[2] += 16; if (k) { SH2_POLL(c); goto L_06062AFA; } }  // 06062B5A bf/s 0x06062AFA ; add #16,r2
    c.r[14] += 8; goto L_06062CB8;  // 06062B5E bra 0x06062CB8 ; add #8,r14
L_06062B78:
    c.r[1] = ld32(0x06062CD4u);  // 06062B78 mov.l 0x06062CD4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06062B7A mov.b @r1,r1
    c.r[3] = c.r[1] & 0xFFu;  // 06062B7C extu.b r1,r3
    c.r[1] = ld32(0x06062CD8u);  // 06062B7E mov.l 0x06062CD8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06062B80 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06062B82 extu.b r1,r1
    c.t = (int32_t)c.r[4] >= (int32_t)c.r[1];  // 06062B84 cmp/ge r1,r4
    { const bool k = c.t; c.r[5] = 0x0u; if (k) { goto L_06062C46; } }  // 06062B86 bt/s 0x06062C46 ; mov #0,r5
    c.r[11] = ld32(0x06062CDCu);  // 06062B8A mov.l 0x06062CDC,r11
    c.r[12] = c.r[3];  // 06062B8C mov r3,r12
    c.r[12] <<= 2;  // 06062B8E shll2 r12
    c.r[12] <<= 2;  // 06062B90 shll2 r12
    c.r[10] = (uint32_t)(int16_t)ld16(0x06062CCCu);  // 06062B92 mov.w 0x06062CCC,r10
L_06062B94:
    c.r[1] = ld32(0x06062CE0u);  // 06062B94 mov.l 0x06062CE0,r1
    c.r[2] = ld32(c.r[1]);  // 06062B96 mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06062CCEu);  // 06062B98 mov.w 0x06062CCE,r1
    c.r[2] += c.r[1];  // 06062B9A add r1,r2
    c.r[1] = c.r[5];  // 06062B9C mov r5,r1
    c.r[1] <<= 2;  // 06062B9E shll2 r1
    c.r[1] += c.r[1];  // 06062BA0 add r1,r1
    c.r[2] += c.r[1];  // 06062BA2 add r1,r2
    c.r[2] += 4;  // 06062BA4 add #4,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06062BA6 mov.b @r2,r1
    c.r[8] = c.r[1] & 0xFFu;  // 06062BA8 extu.b r1,r8
    c.r[2] = c.r[8];  // 06062BAA mov r8,r2
    c.r[1] = ld32(c.r[11]);  // 06062BAC mov.l @r11,r1
    c.r[2] <<= 2;  // 06062BAE shll2 r2
    c.r[2] <<= 2;  // 06062BB0 shll2 r2
    c.r[2] += c.r[1];  // 06062BB2 add r1,r2
    c.r[2] += 10;  // 06062BB4 add #10,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06062BB6 mov.b @r2,r0
    c.r[0] &= 0xF7u;  // 06062BB8 and #247,r0
    st8(c.r[2], c.r[0]);  // 06062BBA mov.b r0,@r2
    c.r[7] = ld32(c.r[11]);  // 06062BBC mov.l @r11,r7
    c.r[3] = c.r[12];  // 06062BBE mov r12,r3
    c.r[3] += c.r[7];  // 06062BC0 add r7,r3
    c.r[3] += 9;  // 06062BC2 add #9,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06062BC4 mov.b @r3,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06062BC6 extu.b r1,r1
    c.t = c.r[1] == c.r[10];  // 06062BC8 cmp/eq r10,r1
    { const bool k = c.t; c.t = c.r[1] == c.r[8]; if (k) { goto L_06062C3A; } }  // 06062BCA bt/s 0x06062C3A ; cmp/eq r8,r1
    { const bool k = c.t; c.r[1] = c.r[4]; if (k) { goto L_06062C36; } }  // 06062BCE bt/s 0x06062C36 ; mov r4,r1
    c.r[2] = 0x0u;  // 06062BD2 mov #0,r2
    c.r[6] = c.r[7];  // 06062BD4 mov r7,r6
    c.r[9] = c.r[3];  // 06062BD6 mov r3,r9
    c.r[3] = c.r[6];  // 06062BD8 mov r6,r3
    c.r[7] = 0x0u;  // 06062BDA mov #0,r7
L_06062BDC:
    c.r[0] = c.r[7];  // 06062BDC mov r7,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 06062BDE mov.b @(r0,r6),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06062BE0 extu.b r1,r1
    c.t = c.r[1] == c.r[10];  // 06062BE2 cmp/eq r10,r1
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_06062C22; } }  // 06062BE4 bt/s 0x06062C22 ; mov r3,r1
    c.r[1] += 7;  // 06062BE8 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06062BEA mov.b @r1,r1
    c.r[0] = c.r[1];  // 06062BEC mov r1,r0
    c.r[0] >>= 2;  // 06062BEE shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06062BF0 shlr r0
    c.r[0] &= 0x1u;  // 06062BF2 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06062BF4 tst r0,r0
    if (!c.t) { goto L_06062C22; }  // 06062BF6 bf 0x06062C22
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06062BF8 mov.b @r9,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06062BFA extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 06062BFC cmp/eq r2,r1
    { const bool k = !c.t; c.r[1] = c.r[3]; if (k) { goto L_06062C22; } }  // 06062BFE bf/s 0x06062C22 ; mov r3,r1
    c.r[1] += 4;  // 06062C02 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06062C04 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06062C06 mov r1,r0
    c.r[0] >>= 2;  // 06062C08 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06062C0A shlr r0
    c.r[0] >>= 2;  // 06062C0C shlr2 r0
    c.r[0] &= 0x1u;  // 06062C0E and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06062C10 tst r0,r0
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_06062C22; } }  // 06062C12 bt/s 0x06062C22 ; mov r3,r1
    c.r[1] += 6;  // 06062C16 add #6,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06062C18 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06062C1A extu.b r1,r1
    c.t = c.r[1] == c.r[8];  // 06062C1C cmp/eq r8,r1
    { const bool k = c.t; c.r[0] = c.r[2]; if (k) { goto L_06062C30; } }  // 06062C1E bt/s 0x06062C30 ; mov r2,r0
L_06062C22:
    c.r[3] += 16;  // 06062C22 add #16,r3
    c.r[2] += 1;  // 06062C24 add #1,r2
    c.r[1] = 0x49u;  // 06062C26 mov #73,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 06062C28 cmp/gt r1,r2
    { const bool k = !c.t; c.r[7] += 16; if (k) { SH2_POLL(c); goto L_06062BDC; } }  // 06062C2A bf/s 0x06062BDC ; add #16,r7
    c.r[0] = c.r[2];  // 06062C2E mov r2,r0
L_06062C30:
    c.t = c.r[0] == 0x4Au;  // 06062C30 cmp/eq #74,r0
    { const bool k = c.t; c.r[1] = c.r[4]; if (k) { goto L_06062C3A; } }  // 06062C32 bt/s 0x06062C3A ; mov r4,r1
L_06062C36:
    c.r[1] += 1;  // 06062C36 add #1,r1
    c.r[4] = c.r[1] & 0xFFu;  // 06062C38 extu.b r1,r4
L_06062C3A:
    c.r[1] = ld32(0x06062CD8u);  // 06062C3A mov.l 0x06062CD8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06062C3C mov.b @r1,r1
    c.r[5] += 1;  // 06062C3E add #1,r5
    c.r[1] = c.r[1] & 0xFFu;  // 06062C40 extu.b r1,r1
    c.t = (int32_t)c.r[5] >= (int32_t)c.r[1];  // 06062C42 cmp/ge r1,r5
    if (!c.t) { SH2_POLL(c); goto L_06062B94; }  // 06062C44 bf 0x06062B94
L_06062C46:
    c.r[1] = ld32(0x06062CD4u);  // 06062C46 mov.l 0x06062CD4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06062C48 mov.b @r1,r1
    c.r[3] = ld32(0x06062CDCu);  // 06062C4A mov.l 0x06062CDC,r3
    c.r[2] = c.r[1] & 0xFFu;  // 06062C4C extu.b r1,r2
    c.r[1] = ld32(c.r[3]);  // 06062C4E mov.l @r3,r1
    c.r[2] <<= 2;  // 06062C50 shll2 r2
    c.r[2] <<= 2;  // 06062C52 shll2 r2
    c.r[1] += c.r[2];  // 06062C54 add r2,r1
    c.r[1] += 10;  // 06062C56 add #10,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06062C58 mov.b @r1,r0
    c.r[0] &= 0xBFu;  // 06062C5A and #191,r0
    st8(c.r[1], c.r[0]);  // 06062C5C mov.b r0,@r1
    c.r[1] = ld32(c.r[3]);  // 06062C5E mov.l @r3,r1
    c.r[1] += c.r[2];  // 06062C60 add r2,r1
    c.r[1] += 11;  // 06062C62 add #11,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06062C64 mov.b @r1,r0
    c.r[0] &= 0xEFu;  // 06062C66 and #239,r0
    st8(c.r[1], c.r[0]);  // 06062C68 mov.b r0,@r1
    c.r[1] = ld32(c.r[3]);  // 06062C6A mov.l @r3,r1
    c.r[1] += c.r[2];  // 06062C6C add r2,r1
    c.r[1] += 10;  // 06062C6E add #10,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06062C70 mov.b @r1,r0
    c.r[0] &= 0xDFu;  // 06062C72 and #223,r0
    st8(c.r[1], c.r[0]);  // 06062C74 mov.b r0,@r1
    c.r[1] = ld32(c.r[3]);  // 06062C76 mov.l @r3,r1
    c.r[1] += c.r[2];  // 06062C78 add r2,r1
    c.r[1] += 10;  // 06062C7A add #10,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06062C7C mov.b @r1,r0
    c.r[0] &= 0xFDu;  // 06062C7E and #253,r0
    st8(c.r[1], c.r[0]);  // 06062C80 mov.b r0,@r1
    c.r[1] = ld32(c.r[3]);  // 06062C82 mov.l @r3,r1
    c.r[1] += c.r[2];  // 06062C84 add r2,r1
    c.r[1] += 11;  // 06062C86 add #11,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06062C88 mov.b @r1,r0
    c.t = (c.r[4] & c.r[4]) == 0;  // 06062C8A tst r4,r4
    c.r[0] &= 0xF7u;  // 06062C8C and #247,r0
    { const bool k = c.t; st8(c.r[1], c.r[0]); if (k) { goto L_06062CB6; } }  // 06062C8E bt/s 0x06062CB6 ; mov.b r0,@r1
    c.r[1] = ld32(c.r[3]);  // 06062C92 mov.l @r3,r1
    c.r[2] += c.r[1];  // 06062C94 add r1,r2
    c.r[2] += 9;  // 06062C96 add #9,r2
    c.r[1] = 0xFFFFFFFFu;  // 06062C98 mov #-1,r1
    st8(c.r[2], c.r[1]); goto L_06062CB6;  // 06062C9A bra 0x06062CB6 ; mov.b r1,@r2
L_06062C9E:
    c.r[1] = ld32(0x06062CE4u);  // 06062C9E mov.l 0x06062CE4,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06062CA0 mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 06062CA2 extu.b r2,r2
    c.r[1] = ld32(0x06062CDCu);  // 06062CA4 mov.l 0x06062CDC,r1
    c.r[1] = ld32(c.r[1]);  // 06062CA6 mov.l @r1,r1
    c.r[2] <<= 2;  // 06062CA8 shll2 r2
    c.r[2] <<= 2;  // 06062CAA shll2 r2
    c.r[2] += c.r[1];  // 06062CAC add r1,r2
    c.r[2] += 10;  // 06062CAE add #10,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06062CB0 mov.b @r2,r0
    c.r[0] &= 0x7Fu;  // 06062CB2 and #127,r0
L_06062CB4:
    st8(c.r[2], c.r[0]);  // 06062CB4 mov.b r0,@r2
L_06062CB6:
    c.r[14] += 8;  // 06062CB6 add #8,r14
L_06062CB8:
    c.r[15] = c.r[14];  // 06062CB8 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06062CBA lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06062CBC mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06062CBE mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06062CC0 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06062CC2 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06062CC4 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06062CD0u);  // 06062CC6 mov.w 0x06062CD0,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06062CC8 rts ; mov.l @r15+,r8
}

void f_06062CE8(SH2Context& c) {
    ran[1477] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06062CE8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06062CEA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06062CEC mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06062CEE mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06062CF0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06062CF2 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06062CF4 mov r15,r14
    c.r[9] = 0x0u;  // 06062CF6 mov #0,r9
    c.r[11] = ld32(0x06062D2Cu);  // 06062CF8 mov.l 0x06062D2C,r11
    c.r[10] = 0x8u;  // 06062CFA mov #8,r10
    c.r[8] = 0x0u;  // 06062CFC mov #0,r8
L_06062CFE:
    c.r[5] = c.r[8] & 0xFFu;  // 06062CFE extu.b r8,r5
L_06062D00:
    { const uint32_t x = c.r[11]; c.pr = 0x06062D04u; c.r[4] = c.r[9] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06062D04u) return; }  // 06062D00 jsr @r11 ; extu.b r9,r4
    c.r[8] += 1;  // 06062D04 add #1,r8
    c.t = (int32_t)c.r[8] > (int32_t)c.r[10];  // 06062D06 cmp/gt r10,r8
    { const bool k = !c.t; c.r[5] = c.r[8] & 0xFFu; if (k) { SH2_POLL(c); goto L_06062D00; } }  // 06062D08 bf/s 0x06062D00 ; extu.b r8,r5
    c.r[9] += 1;  // 06062D0C add #1,r9
    c.r[1] = 0x2u;  // 06062D0E mov #2,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 06062D10 cmp/gt r1,r9
    { const bool k = !c.t; c.r[8] = 0x0u; if (k) { SH2_POLL(c); goto L_06062CFE; } }  // 06062D12 bf/s 0x06062CFE ; mov #0,r8
    c.r[15] = c.r[14];  // 06062D16 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06062D18 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06062D1A mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06062D1C mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06062D1E mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06062D20 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06062D28u);  // 06062D22 mov.w 0x06062D28,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06062D24 rts ; mov.l @r15+,r8
}

void f_06062D30(SH2Context& c) {
    ran[1478] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06062D30 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06062D32 sts.l pr,@-r15
    c.r[1] = ld32(0x06062D80u);  // 06062D34 mov.l 0x06062D80,r1
    c.r[1] = ld32(c.r[1]);  // 06062D36 mov.l @r1,r1
    c.r[1] += 1;  // 06062D38 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06062D3A mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06062D3C extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06062D3E tst r1,r1
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_06062D4E; } }  // 06062D40 bf/s 0x06062D4E ; mov r15,r14
    c.r[1] = ld32(0x06062D84u);  // 06062D44 mov.l 0x06062D84,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06062D4Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06062D4Au) return; }  // 06062D46 jsr @r1 ; nop
    c.r[15] = c.r[14]; goto L_06062D76;  // 06062D4A bra 0x06062D76 ; mov r14,r15
L_06062D4E:
    c.r[1] = ld32(0x06062D88u);  // 06062D4E mov.l 0x06062D88,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06062D50 mov.b @r1,r4
    c.r[4] = c.r[4] & 0xFFu;  // 06062D52 extu.b r4,r4
    c.r[1] = ld32(0x06062D8Cu);  // 06062D54 mov.l 0x06062D8C,r1
    c.r[2] = c.r[4];  // 06062D56 mov r4,r2
    c.r[1] = ld32(c.r[1]);  // 06062D58 mov.l @r1,r1
    c.r[2] <<= 2;  // 06062D5A shll2 r2
    c.r[2] <<= 2;  // 06062D5C shll2 r2
    c.r[2] += c.r[1];  // 06062D5E add r1,r2
    c.r[2] += 3;  // 06062D60 add #3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06062D62 mov.b @r2,r1
    c.r[0] = c.r[1];  // 06062D64 mov r1,r0
    c.r[0] >>= 2;  // 06062D66 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06062D68 shlr r0
    c.r[0] >>= 2;  // 06062D6A shlr2 r0
    c.r[0] &= 0x1u;  // 06062D6C and #1,r0
    c.r[1] = ld32(0x06062D90u);  // 06062D6E mov.l 0x06062D90,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06062D74u; c.r[5] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06062D74u) return; }  // 06062D70 jsr @r1 ; mov r0,r5
    c.r[15] = c.r[14];  // 06062D74 mov r14,r15
L_06062D76:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06062D76 lds.l @r15+,pr
    c.r[0] = (uint32_t)(int16_t)ld16(0x06062D7Eu);  // 06062D78 mov.w 0x06062D7E,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06062D7A rts ; mov.l @r15+,r14
}

void f_06062D94(SH2Context& c) {
    ran[1479] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06062D94 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06062D96 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06062D98 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06062D9A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06062D9C mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06062D9E mov r15,r14
    c.r[5] = 0x0u;  // 06062DA0 mov #0,r5
    c.r[10] = ld32(0x06062E48u);  // 06062DA2 mov.l 0x06062E48,r10
    c.r[4] = (uint32_t)(int16_t)ld16(0x06062E44u);  // 06062DA4 mov.w 0x06062E44,r4
    c.r[9] = 0x1Eu;  // 06062DA6 mov #30,r9
    c.r[8] = 0x0u;  // 06062DA8 mov #0,r8
    c.r[11] = ld32(0x06062E4Cu);  // 06062DAA mov.l 0x06062E4C,r11
    c.r[6] = 0x0u;  // 06062DAC mov #0,r6
L_06062DAE:
    c.r[3] = c.r[6];  // 06062DAE mov r6,r3
    c.r[2] = ld32(c.r[10]);  // 06062DB0 mov.l @r10,r2
    c.r[0] = c.r[6];  // 06062DB2 mov r6,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06062DB4 mov.b @(r0,r2),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06062DB6 extu.b r1,r1
    c.t = c.r[1] == c.r[4];  // 06062DB8 cmp/eq r4,r1
    { const bool k = c.t; c.r[3] += c.r[2]; if (k) { goto L_06062E2A; } }  // 06062DBA bt/s 0x06062E2A ; add r2,r3
    c.r[1] = c.r[3];  // 06062DBE mov r3,r1
    c.r[1] += 7;  // 06062DC0 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06062DC2 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06062DC4 mov r1,r0
    c.r[0] >>= 2;  // 06062DC6 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06062DC8 shlr r0
    c.r[0] &= 0x1u;  // 06062DCA and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06062DCC tst r0,r0
    if (c.t) { goto L_06062E2A; }  // 06062DCE bt 0x06062E2A
    c.r[3] += 3;  // 06062DD0 add #3,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06062DD2 mov.b @r3,r1
    c.r[0] = c.r[1];  // 06062DD4 mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06062DD6 shlr r0
    c.r[0] &= 0x3u;  // 06062DD8 and #3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06062DDA tst r0,r0
    { const bool k = c.t; c.r[0] = c.r[6]; if (k) { goto L_06062E2A; } }  // 06062DDC bt/s 0x06062E2A ; mov r6,r0
    st8(c.r[0] + c.r[2], c.r[4]);  // 06062DE0 mov.b r4,@(r0,r2)
    c.r[7] = ld32(c.r[10]);  // 06062DE2 mov.l @r10,r7
    c.r[7] += c.r[6];  // 06062DE4 add r6,r7
    c.r[7] += 2;  // 06062DE6 add #2,r7
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06062DE8 mov.b @r7,r2
    c.r[1] = ld32(0x06062E50u);  // 06062DEA mov.l 0x06062E50,r1
    c.r[2] = c.r[2] & 0xFFu;  // 06062DEC extu.b r2,r2
    c.macl = c.r[2] * c.r[9];  // 06062DEE mul.l r9,r2
    c.r[3] = ld32(c.r[1]);  // 06062DF0 mov.l @r1,r3
    c.r[1] = c.macl;  // 06062DF2 sts macl,r1
    c.r[1] += c.r[3];  // 06062DF4 add r3,r1
    st16(c.r[1], c.r[8]);  // 06062DF6 mov.w r8,@r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06062DF8 mov.b @r7,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06062DFA extu.b r1,r1
    c.macl = c.r[1] * c.r[9];  // 06062DFC mul.l r9,r1
    c.r[1] = c.macl;  // 06062DFE sts macl,r1
    c.r[1] += c.r[3];  // 06062E00 add r3,r1
    c.r[1] += 15;  // 06062E02 add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06062E04 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06062E06 extu.b r1,r1
    c.t = c.r[1] == c.r[4];  // 06062E08 cmp/eq r4,r1
    if (c.t) { goto L_06062E2A; }  // 06062E0A bt 0x06062E2A
    c.r[2] = ld32(c.r[11]);  // 06062E0C mov.l @r11,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x06062E44u);  // 06062E0E mov.w 0x06062E44,r3
    c.r[0] = c.r[1];  // 06062E10 mov r1,r0
L_06062E12:
    c.r[0] += c.r[0];  // 06062E12 add r0,r0
    c.r[0] += c.r[1];  // 06062E14 add r1,r0
    c.r[0] <<= 2;  // 06062E16 shll2 r0
    c.r[1] = c.r[0];  // 06062E18 mov r0,r1
    c.r[1] += c.r[2];  // 06062E1A add r2,r1
    st16(c.r[0] + c.r[2], c.r[8]);  // 06062E1C mov.w r8,@(r0,r2)
    c.r[1] += 8;  // 06062E1E add #8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06062E20 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06062E22 extu.b r1,r1
    c.t = c.r[1] == c.r[3];  // 06062E24 cmp/eq r3,r1
    { const bool k = !c.t; c.r[0] = c.r[1]; if (k) { SH2_POLL(c); goto L_06062E12; } }  // 06062E26 bf/s 0x06062E12 ; mov r1,r0
L_06062E2A:
    c.r[5] += 1;  // 06062E2A add #1,r5
    c.r[1] = 0x49u;  // 06062E2C mov #73,r1
    c.t = (int32_t)c.r[5] > (int32_t)c.r[1];  // 06062E2E cmp/gt r1,r5
    { const bool k = !c.t; c.r[6] += 16; if (k) { SH2_POLL(c); goto L_06062DAE; } }  // 06062E30 bf/s 0x06062DAE ; add #16,r6
    c.r[15] = c.r[14];  // 06062E34 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06062E36 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06062E38 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06062E3A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06062E3C mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06062E46u);  // 06062E3E mov.w 0x06062E46,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06062E40 rts ; mov.l @r15+,r8
}

void f_06062E54(SH2Context& c) {
    ran[1480] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06062E54 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06062E56 sts.l pr,@-r15
    c.r[1] = ld32(0x06062E74u);  // 06062E58 mov.l 0x06062E74,r1
    c.r[1] = ld32(c.r[1]);  // 06062E5A mov.l @r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06062E5C mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06062E5E extu.b r1,r0
    c.r[0] <<= 2;  // 06062E60 shll2 r0
    c.r[1] = ld32(0x06062E78u);  // 06062E62 mov.l 0x06062E78,r1
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 06062E64 mov.l @(r0,r1),r0
    { const uint32_t x = c.r[0]; c.pr = 0x06062E6Au; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06062E6Au) return; }  // 06062E66 jsr @r0 ; mov r15,r14
    c.r[15] = c.r[14];  // 06062E6A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06062E6C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06062E6E mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[0] & 0xFFFFu; c.pc = x; return; }  // 06062E70 rts ; extu.w r0,r0
}

void f_06062E7C(SH2Context& c) {
    ran[1481] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06062E7C mov.l r14,@-r15
    c.r[1] = ld32(0x06062F28u);  // 06062E7E mov.l 0x06062F28,r1
    c.r[1] = ld32(c.r[1]);  // 06062E80 mov.l @r1,r1
    c.r[1] += 1;  // 06062E82 add #1,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06062E84 mov.b @r1,r0
    c.r[1] = 0x7Fu;  // 06062E86 mov #127,r1
    c.r[1] &= c.r[0];  // 06062E88 and r0,r1
    c.r[0] &= 0x80u;  // 06062E8A and #128,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06062E8C tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06062EB6; } }  // 06062E8E bt/s 0x06062EB6 ; mov r15,r14
    c.t = (c.r[1] & c.r[1]) == 0;  // 06062E92 tst r1,r1
    { const bool k = !c.t; c.r[0] = c.r[1]; if (k) { goto L_06062EA2; } }  // 06062E94 bf/s 0x06062EA2 ; mov r1,r0
    c.r[1] = ld32(0x06062F2Cu);  // 06062E98 mov.l 0x06062F2C,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06062E9A mov.b @r1,r0
    c.r[0] &= 0x7Fu;  // 06062E9C and #127,r0
    st8(c.r[1], c.r[0]); goto L_06062F1E;  // 06062E9E bra 0x06062F1E ; mov.b r0,@r1
L_06062EA2:
    c.t = c.r[0] == 0x1u;  // 06062EA2 cmp/eq #1,r0
    if (!c.t) { goto L_06062EB0; }  // 06062EA4 bf 0x06062EB0
    c.r[1] = ld32(0x06062F2Cu);  // 06062EA6 mov.l 0x06062F2C,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06062EA8 mov.b @r1,r0
    c.r[0] |= 0x80u;  // 06062EAA or #128,r0
    st8(c.r[1], c.r[0]); goto L_06062F1E;  // 06062EAC bra 0x06062F1E ; mov.b r0,@r1
L_06062EB0:
    c.r[2] = ld32(0x06062F2Cu);  // 06062EB0 mov.l 0x06062F2C,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]); goto L_06062F04;  // 06062EB2 bra 0x06062F04 ; mov.b @r2,r0
L_06062EB6:
    c.t = (c.r[1] & c.r[1]) == 0;  // 06062EB6 tst r1,r1
    if (!c.t) { goto L_06062ED2; }  // 06062EB8 bf 0x06062ED2
    c.r[1] = ld32(0x06062F30u);  // 06062EBA mov.l 0x06062F30,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06062EBC mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 06062EBE extu.b r2,r2
    c.r[1] = ld32(0x06062F34u);  // 06062EC0 mov.l 0x06062F34,r1
    c.r[1] = ld32(c.r[1]);  // 06062EC2 mov.l @r1,r1
    c.r[2] <<= 2;  // 06062EC4 shll2 r2
    c.r[2] <<= 2;  // 06062EC6 shll2 r2
    c.r[2] += c.r[1];  // 06062EC8 add r1,r2
    c.r[2] += 3;  // 06062ECA add #3,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06062ECC mov.b @r2,r0
    c.r[0] &= 0x7Fu; goto L_06062F1C;  // 06062ECE bra 0x06062F1C ; and #127,r0
L_06062ED2:
    c.r[0] = c.r[1];  // 06062ED2 mov r1,r0
    c.t = c.r[0] == 0x1u;  // 06062ED4 cmp/eq #1,r0
    if (!c.t) { goto L_06062EF0; }  // 06062ED6 bf 0x06062EF0
    c.r[1] = ld32(0x06062F30u);  // 06062ED8 mov.l 0x06062F30,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06062EDA mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 06062EDC extu.b r2,r2
    c.r[1] = ld32(0x06062F34u);  // 06062EDE mov.l 0x06062F34,r1
    c.r[1] = ld32(c.r[1]);  // 06062EE0 mov.l @r1,r1
    c.r[2] <<= 2;  // 06062EE2 shll2 r2
    c.r[2] <<= 2;  // 06062EE4 shll2 r2
    c.r[2] += c.r[1];  // 06062EE6 add r1,r2
    c.r[2] += 3;  // 06062EE8 add #3,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06062EEA mov.b @r2,r0
    c.r[0] |= 0x80u; goto L_06062F1C;  // 06062EEC bra 0x06062F1C ; or #128,r0
L_06062EF0:
    c.r[1] = ld32(0x06062F30u);  // 06062EF0 mov.l 0x06062F30,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06062EF2 mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 06062EF4 extu.b r2,r2
    c.r[1] = ld32(0x06062F34u);  // 06062EF6 mov.l 0x06062F34,r1
    c.r[1] = ld32(c.r[1]);  // 06062EF8 mov.l @r1,r1
    c.r[2] <<= 2;  // 06062EFA shll2 r2
    c.r[2] <<= 2;  // 06062EFC shll2 r2
    c.r[2] += c.r[1];  // 06062EFE add r1,r2
    c.r[2] += 3;  // 06062F00 add #3,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06062F02 mov.b @r2,r0
L_06062F04:
    c.r[1] = c.r[0] & 0xFFu;  // 06062F04 extu.b r0,r1
    c.r[1] >>= 2;  // 06062F06 shlr2 r1
    c.r[1] >>= 2;  // 06062F08 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06062F0A shlr r1
    c.r[1] >>= 2;  // 06062F0C shlr2 r1
    c.r[1] += 1;  // 06062F0E add #1,r1
    c.r[1] <<= 2;  // 06062F10 shll2 r1
    c.r[1] <<= 2;  // 06062F12 shll2 r1
    c.r[1] += c.r[1];  // 06062F14 add r1,r1
    c.r[1] <<= 2;  // 06062F16 shll2 r1
    c.r[0] &= 0x7Fu;  // 06062F18 and #127,r0
    c.r[0] |= c.r[1];  // 06062F1A or r1,r0
L_06062F1C:
    st8(c.r[2], c.r[0]);  // 06062F1C mov.b r0,@r2
L_06062F1E:
    c.r[15] = c.r[14];  // 06062F1E mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x06062F26u);  // 06062F20 mov.w 0x06062F26,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06062F22 rts ; mov.l @r15+,r14
}

void f_06062F38(SH2Context& c) {
    ran[1482] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06062F38 mov.l r14,@-r15
    c.r[1] = ld32(0x06062FC8u);  // 06062F3A mov.l 0x06062FC8,r1
    c.r[2] = ld32(c.r[1]);  // 06062F3C mov.l @r1,r2
    c.r[2] += 1;  // 06062F3E add #1,r2
    st32(c.r[1], c.r[2]);  // 06062F40 mov.l r2,@r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06062F42 mov.b @r2,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06062F44 extu.b r1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06062F46 tst r0,r0
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_06062F56; } }  // 06062F48 bf/s 0x06062F56 ; mov r15,r14
    c.r[1] = ld32(0x06062FCCu);  // 06062F4C mov.l 0x06062FCC,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06062F4E mov.b @r1,r0
    c.r[0] &= 0xBFu;  // 06062F50 and #191,r0
    st8(c.r[1], c.r[0]); goto L_06062F82;  // 06062F52 bra 0x06062F82 ; mov.b r0,@r1
L_06062F56:
    c.t = c.r[0] == 0x1u;  // 06062F56 cmp/eq #1,r0
    if (!c.t) { goto L_06062F64; }  // 06062F58 bf 0x06062F64
    c.r[1] = ld32(0x06062FCCu);  // 06062F5A mov.l 0x06062FCC,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06062F5C mov.b @r1,r0
    c.r[0] |= 0x40u;  // 06062F5E or #64,r0
    st8(c.r[1], c.r[0]); goto L_06062F82;  // 06062F60 bra 0x06062F82 ; mov.b r0,@r1
L_06062F64:
    c.r[1] = ld32(0x06062FCCu);  // 06062F64 mov.l 0x06062FCC,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06062F66 mov.b @r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x06062FC0u);  // 06062F68 mov.w 0x06062FC0,r3
    c.r[0] = c.r[2];  // 06062F6A mov r2,r0
    c.r[0] >>= 2;  // 06062F6C shlr2 r0
    c.r[0] >>= 2;  // 06062F6E shlr2 r0
    c.r[0] >>= 2;  // 06062F70 shlr2 r0
    c.r[0] &= 0x1u;  // 06062F72 and #1,r0
    c.r[0] ^= 0x1u;  // 06062F74 xor #1,r0
    c.r[0] <<= 2;  // 06062F76 shll2 r0
    c.r[0] <<= 2;  // 06062F78 shll2 r0
    c.r[0] <<= 2;  // 06062F7A shll2 r0
    c.r[2] &= c.r[3];  // 06062F7C and r3,r2
    c.r[2] |= c.r[0];  // 06062F7E or r0,r2
    st8(c.r[1], c.r[2]);  // 06062F80 mov.b r2,@r1
L_06062F82:
    c.r[2] = ld32(0x06062FD0u);  // 06062F82 mov.l 0x06062FD0,r2
    c.r[1] = c.r[2];  // 06062F84 mov r2,r1
    c.r[1] += 16;  // 06062F86 add #16,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06062F88 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06062F8A mov r1,r0
    c.r[0] >>= 2;  // 06062F8C shlr2 r0
    c.r[0] >>= 2;  // 06062F8E shlr2 r0
    c.r[0] >>= 2;  // 06062F90 shlr2 r0
    c.r[0] &= 0x1u;  // 06062F92 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06062F94 tst r0,r0
    { const bool k = !c.t; c.r[2] += 18; if (k) { goto L_06062FB8; } }  // 06062F96 bf/s 0x06062FB8 ; add #18,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06062F9A mov.b @r2,r1
    c.r[2] = c.r[1] & 0xFFu;  // 06062F9C extu.b r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06062FC2u);  // 06062F9E mov.w 0x06062FC2,r1
    c.t = c.r[2] == c.r[1];  // 06062FA0 cmp/eq r1,r2
    { const bool k = c.t; c.r[15] = c.r[14]; if (k) { goto L_06062FBA; } }  // 06062FA2 bt/s 0x06062FBA ; mov r14,r15
    c.r[1] = ld32(0x06062FD4u);  // 06062FA6 mov.l 0x06062FD4,r1
    c.r[1] = ld32(c.r[1]);  // 06062FA8 mov.l @r1,r1
    c.r[2] <<= 2;  // 06062FAA shll2 r2
    c.r[2] <<= 2;  // 06062FAC shll2 r2
    c.r[2] += c.r[1];  // 06062FAE add r1,r2
    c.r[2] += 3;  // 06062FB0 add #3,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06062FB2 mov.b @r2,r0
    c.r[0] |= 0x40u;  // 06062FB4 or #64,r0
    st8(c.r[2], c.r[0]);  // 06062FB6 mov.b r0,@r2
L_06062FB8:
    c.r[15] = c.r[14];  // 06062FB8 mov r14,r15
L_06062FBA:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06062FC4u);  // 06062FBA mov.w 0x06062FC4,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06062FBC rts ; mov.l @r15+,r14
}

void f_06062FD8(SH2Context& c) {
    ran[1483] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06062FD8 mov.l r14,@-r15
    c.r[1] = ld32(0x06063028u);  // 06062FDA mov.l 0x06063028,r1
    c.r[1] = ld32(c.r[1]);  // 06062FDC mov.l @r1,r1
    c.r[1] += 1;  // 06062FDE add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06062FE0 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06062FE2 extu.b r1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06062FE4 tst r0,r0
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_06062FF4; } }  // 06062FE6 bf/s 0x06062FF4 ; mov r15,r14
    c.r[1] = ld32(0x0606302Cu);  // 06062FEA mov.l 0x0606302C,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06062FEC mov.b @r1,r0
    c.r[0] &= 0xF7u;  // 06062FEE and #247,r0
    st8(c.r[1], c.r[0]); goto L_0606301C;  // 06062FF0 bra 0x0606301C ; mov.b r0,@r1
L_06062FF4:
    c.t = c.r[0] == 0x1u;  // 06062FF4 cmp/eq #1,r0
    if (!c.t) { goto L_06063002; }  // 06062FF6 bf 0x06063002
    c.r[1] = ld32(0x0606302Cu);  // 06062FF8 mov.l 0x0606302C,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06062FFA mov.b @r1,r0
    c.r[0] |= 0x8u;  // 06062FFC or #8,r0
    st8(c.r[1], c.r[0]); goto L_0606301C;  // 06062FFE bra 0x0606301C ; mov.b r0,@r1
L_06063002:
    c.r[1] = ld32(0x0606302Cu);  // 06063002 mov.l 0x0606302C,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06063004 mov.b @r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x06063024u);  // 06063006 mov.w 0x06063024,r3
    c.r[0] = c.r[2];  // 06063008 mov r2,r0
    c.r[0] >>= 2;  // 0606300A shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0606300C shlr r0
    c.r[0] &= 0x1u;  // 0606300E and #1,r0
    c.r[0] ^= 0x1u;  // 06063010 xor #1,r0
    c.r[0] <<= 2;  // 06063012 shll2 r0
    c.r[0] += c.r[0];  // 06063014 add r0,r0
    c.r[2] &= c.r[3];  // 06063016 and r3,r2
    c.r[2] |= c.r[0];  // 06063018 or r0,r2
    st8(c.r[1], c.r[2]);  // 0606301A mov.b r2,@r1
L_0606301C:
    c.r[15] = c.r[14];  // 0606301C mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x06063026u);  // 0606301E mov.w 0x06063026,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06063020 rts ; mov.l @r15+,r14
}

void f_06063030(SH2Context& c) {
    ran[1484] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06063030 mov.l r14,@-r15
    c.r[1] = ld32(0x0606307Cu);  // 06063032 mov.l 0x0606307C,r1
    c.r[1] = ld32(c.r[1]);  // 06063034 mov.l @r1,r1
    c.r[1] += 1;  // 06063036 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06063038 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0606303A extu.b r1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606303C tst r0,r0
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0606304C; } }  // 0606303E bf/s 0x0606304C ; mov r15,r14
    c.r[1] = ld32(0x06063080u);  // 06063042 mov.l 0x06063080,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06063044 mov.b @r1,r0
    c.r[0] &= 0xFDu;  // 06063046 and #253,r0
    st8(c.r[1], c.r[0]); goto L_06063070;  // 06063048 bra 0x06063070 ; mov.b r0,@r1
L_0606304C:
    c.t = c.r[0] == 0x1u;  // 0606304C cmp/eq #1,r0
    if (!c.t) { goto L_0606305A; }  // 0606304E bf 0x0606305A
    c.r[1] = ld32(0x06063080u);  // 06063050 mov.l 0x06063080,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06063052 mov.b @r1,r0
    c.r[0] |= 0x2u;  // 06063054 or #2,r0
    st8(c.r[1], c.r[0]); goto L_06063070;  // 06063056 bra 0x06063070 ; mov.b r0,@r1
L_0606305A:
    c.r[1] = ld32(0x06063080u);  // 0606305A mov.l 0x06063080,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606305C mov.b @r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x06063078u);  // 0606305E mov.w 0x06063078,r3
    c.r[0] = c.r[2];  // 06063060 mov r2,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06063062 shlr r0
    c.r[0] &= 0x1u;  // 06063064 and #1,r0
    c.r[0] ^= 0x1u;  // 06063066 xor #1,r0
    c.r[0] += c.r[0];  // 06063068 add r0,r0
    c.r[2] &= c.r[3];  // 0606306A and r3,r2
    c.r[2] |= c.r[0];  // 0606306C or r0,r2
    st8(c.r[1], c.r[2]);  // 0606306E mov.b r2,@r1
L_06063070:
    c.r[15] = c.r[14];  // 06063070 mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606307Au);  // 06063072 mov.w 0x0606307A,r0
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06063074 rts ; mov.l @r15+,r14
}

void f_06063084(SH2Context& c) {
    ran[1485] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06063084 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06063086 sts.l pr,@-r15
    c.r[1] = ld32(0x060630A4u);  // 06063088 mov.l 0x060630A4,r1
    c.r[1] = ld32(c.r[1]);  // 0606308A mov.l @r1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606308C mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0606308E extu.b r1,r0
    c.r[0] <<= 2;  // 06063090 shll2 r0
    c.r[1] = ld32(0x060630A8u);  // 06063092 mov.l 0x060630A8,r1
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 06063094 mov.l @(r0,r1),r0
    { const uint32_t x = c.r[0]; c.pr = 0x0606309Au; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606309Au) return; }  // 06063096 jsr @r0 ; mov r15,r14
    c.r[15] = c.r[14];  // 0606309A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0606309C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0606309E mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[0] & 0xFFFFu; c.pc = x; return; }  // 060630A0 rts ; extu.w r0,r0
}

void f_060630AC(SH2Context& c) {
    ran[1486] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060630AC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060630AE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060630B0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060630B2 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060630B4 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060630B6 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060630B8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060630BA sts.l pr,@-r15
    c.r[15] -= 24;  // 060630BC add #-24,r15
    c.r[14] = c.r[15];  // 060630BE mov r15,r14
    c.r[4] = ld32(0x060631ECu);  // 060630C0 mov.l 0x060631EC,r4
    c.r[8] = ld32(0x060631F0u);  // 060630C2 mov.l 0x060631F0,r8
    { const uint32_t x = c.r[8]; c.pr = 0x060630C8u; c.r[5] = 0x22u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060630C8u) return; }  // 060630C4 jsr @r8 ; mov #34,r5
    c.r[1] = c.r[0];  // 060630C8 mov r0,r1
    c.r[5] = 0x1u;  // 060630CA mov #1,r5
    { const uint32_t x = c.r[8]; c.pr = 0x060630D0u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060630D0u) return; }  // 060630CC jsr @r8 ; mov r1,r4
    c.r[1] = c.r[0];  // 060630D0 mov r0,r1
    c.r[5] = 0x3u;  // 060630D2 mov #3,r5
    { const uint32_t x = c.r[8]; c.pr = 0x060630D8u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060630D8u) return; }  // 060630D4 jsr @r8 ; mov r1,r4
    c.r[1] = ld32(0x060631F4u);  // 060630D8 mov.l 0x060631F4,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060630DA mov.b @r1,r4
    c.r[0] = 0x3u;  // 060630DC mov #3,r0
    c.r[4] = c.r[4] & 0xFFu;  // 060630DE extu.b r4,r4
    c.r[1] = ld32(0x060631F8u);  // 060630E0 mov.l 0x060631F8,r1
    c.r[2] = c.r[4];  // 060630E2 mov r4,r2
    c.r[1] = ld32(c.r[1]);  // 060630E4 mov.l @r1,r1
    c.r[2] <<= 2;  // 060630E6 shll2 r2
    c.r[2] <<= 2;  // 060630E8 shll2 r2
    c.r[2] += c.r[1];  // 060630EA add r1,r2
    c.r[2] += 3;  // 060630EC add #3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060630EE mov.b @r2,r1
    c.r[5] = c.r[14];  // 060630F0 mov r14,r5
    c.r[13] = c.r[1];  // 060630F2 mov r1,r13
    c.r[13] >>= 2;  // 060630F4 shlr2 r13
    c.t = c.r[13] & 1; c.r[13] >>= 1;  // 060630F6 shlr r13
    c.r[1] = ld32(0x060631FCu);  // 060630F8 mov.l 0x060631FC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060630FEu; c.r[13] &= c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060630FEu) return; }  // 060630FA jsr @r1 ; and r0,r13
    c.r[1] = ld32(0x06063200u);  // 060630FE mov.l 0x06063200,r1
    c.r[1] = ld32(c.r[1]);  // 06063100 mov.l @r1,r1
    c.r[1] += 1;  // 06063102 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06063104 mov.b @r1,r1
    c.r[2] = 0x2u;  // 06063106 mov #2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06063108 extu.b r1,r1
    c.t = c.r[1] > c.r[2];  // 0606310A cmp/hi r2,r1
    { const bool k = !c.t; c.r[2] = 0x0u; if (k) { goto L_06063114; } }  // 0606310C bf/s 0x06063114 ; mov #0,r2
    goto L_0606334C;  // 06063110 bra 0x0606334C ; nop
L_06063114:
    c.r[1] = ld32(0x06063204u);  // 06063114 mov.l 0x06063204,r1
    st8(c.r[1], c.r[2]);  // 06063116 mov.b r2,@r1
    c.r[1] = ld32(0x06063208u);  // 06063118 mov.l 0x06063208,r1
    c.r[1] = ld32(c.r[1]);  // 0606311A mov.l @r1,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x060631EAu);  // 0606311C mov.w 0x060631EA,r3
    c.r[12] = 0x0u;  // 0606311E mov #0,r12
    c.r[10] = 0x0u;  // 06063120 mov #0,r10
    c.r[0] = c.r[1];  // 06063122 mov r1,r0
    st8(c.r[0] + c.r[3], c.r[2]);  // 06063124 mov.b r2,@(r0,r3)
L_06063126:
    c.r[0] = ld32(0x0606320Cu);  // 06063126 mov.l 0x0606320C,r0
    c.r[1] = ld32(c.r[0]);  // 06063128 mov.l @r0,r1
    c.r[1] += c.r[10];  // 0606312A add r10,r1
    c.r[1] += 44;  // 0606312C add #44,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606312E mov.w @r1,r1
    c.r[9] = c.r[1] & 0xFFFFu;  // 06063130 extu.w r1,r9
    c.t = (c.r[9] & c.r[9]) == 0;  // 06063132 tst r9,r9
    if (!c.t) { goto L_0606313A; }  // 06063134 bf 0x0606313A
    goto L_0606333E;  // 06063136 bra 0x0606333E ; nop
L_0606313A:
    c.r[1] = ld32(0x06063200u);  // 0606313A mov.l 0x06063200,r1
    c.r[1] = ld32(c.r[1]);  // 0606313C mov.l @r1,r1
    c.r[1] += 1;  // 0606313E add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06063140 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06063142 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06063144 tst r1,r1
    if (!c.t) { goto L_0606314C; }  // 06063146 bf 0x0606314C
    goto L_06063308;  // 06063148 bra 0x06063308 ; nop
L_0606314C:
    c.r[8] = ld32(0x060631F0u);  // 0606314C mov.l 0x060631F0,r8
    c.r[4] = ld32(0x060631ECu);  // 0606314E mov.l 0x060631EC,r4
    { const uint32_t x = c.r[8]; c.pr = 0x06063154u; c.r[5] = 0x1Du; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06063154u) return; }  // 06063150 jsr @r8 ; mov #29,r5
    c.r[5] = c.r[9];  // 06063154 mov r9,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0606315Au; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606315Au) return; }  // 06063156 jsr @r8 ; mov r0,r4
    c.r[0] += 16;  // 0606315A add #16,r0
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0606315C mov.b @r0,r5
    c.t = (c.r[5] & c.r[5]) == 0;  // 0606315E tst r5,r5
    { const bool k = c.t; c.r[1] = c.r[5]; if (k) { goto L_0606322C; } }  // 06063160 bt/s 0x0606322C ; mov r5,r1
    c.r[1] -= 33;  // 06063164 add #-33,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06063166 extu.b r1,r1
    c.r[2] = 0x8u;  // 06063168 mov #8,r2
    c.t = c.r[1] > c.r[2];  // 0606316A cmp/hi r2,r1
    { const bool k = c.t; c.r[11] = 0x0u; if (k) { goto L_06063174; } }  // 0606316C bt/s 0x06063174 ; mov #0,r11
    c.r[11] = 0x21u; goto L_06063180;  // 06063170 bra 0x06063180 ; mov #33,r11
L_06063174:
    c.r[1] = c.r[5];  // 06063174 mov r5,r1
    c.r[1] -= 51;  // 06063176 add #-51,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06063178 extu.b r1,r1
    c.t = c.r[1] > c.r[2];  // 0606317A cmp/hi r2,r1
    if (c.t) { goto L_06063180; }  // 0606317C bt 0x06063180
    c.r[11] = 0x33u;  // 0606317E mov #51,r11
L_06063180:
    c.t = (c.r[11] & c.r[11]) == 0;  // 06063180 tst r11,r11
    { const bool k = c.t; c.r[6] = 0x4u; if (k) { goto L_06063214; } }  // 06063182 bt/s 0x06063214 ; mov #4,r6
    c.r[2] = 0x0u;  // 06063186 mov #0,r2
    c.r[0] = ld32(0x06063210u);  // 06063188 mov.l 0x06063210,r0
    c.r[7] = ld32(c.r[0]);  // 0606318A mov.l @r0,r7
    c.r[3] = c.r[11];  // 0606318C mov r11,r3
    c.r[3] += 8;  // 0606318E add #8,r3
    c.r[6] = 0x3u;  // 06063190 mov #3,r6
L_06063192:
    c.r[1] = c.r[7];  // 06063192 mov r7,r1
    c.r[1] += c.r[2];  // 06063194 add r2,r1
    c.r[1] += 30;  // 06063196 add #30,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06063198 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606319A extu.b r1,r1
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[5];  // 0606319C cmp/ge r5,r1
    { const bool k = !c.t; c.t = (int32_t)c.r[1] > (int32_t)c.r[3]; if (k) { goto L_060631A6; } }  // 0606319E bf/s 0x060631A6 ; cmp/gt r3,r1
    { const bool k = !c.t; c.r[0] = c.r[2]; if (k) { goto L_060631AE; } }  // 060631A2 bf/s 0x060631AE ; mov r2,r0
L_060631A6:
    c.r[2] += 1;  // 060631A6 add #1,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[6];  // 060631A8 cmp/gt r6,r2
    if (!c.t) { SH2_POLL(c); goto L_06063192; }  // 060631AA bf 0x06063192
    c.r[0] = c.r[2];  // 060631AC mov r2,r0
L_060631AE:
    c.t = c.r[0] == 0x4u;  // 060631AE cmp/eq #4,r0
    { const bool k = !c.t; c.r[0] = c.r[11]; if (k) { goto L_0606322A; } }  // 060631B0 bf/s 0x0606322A ; mov r11,r0
    c.t = c.r[0] == 0x21u;  // 060631B4 cmp/eq #33,r0
    { const bool k = !c.t; c.r[1] = c.r[5]; if (k) { goto L_0606322C; } }  // 060631B6 bf/s 0x0606322C ; mov r5,r1
    c.r[1] += 9;  // 060631BA add #9,r1
    c.r[5] = (uint32_t)(int32_t)(int8_t)c.r[1];  // 060631BC exts.b r1,r5
    c.r[2] = 0x0u;  // 060631BE mov #0,r2
    c.r[0] = ld32(0x06063210u);  // 060631C0 mov.l 0x06063210,r0
    c.r[3] = ld32(c.r[0]);  // 060631C2 mov.l @r0,r3
    c.r[6] = 0x32u;  // 060631C4 mov #50,r6
    c.r[7] = 0x3u;  // 060631C6 mov #3,r7
    c.r[1] = c.r[3];  // 060631C8 mov r3,r1
L_060631CA:
    c.r[1] += c.r[2];  // 060631CA add r2,r1
    c.r[1] += 30;  // 060631CC add #30,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060631CE mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060631D0 extu.b r1,r1
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[5];  // 060631D2 cmp/ge r5,r1
    { const bool k = !c.t; c.t = (int32_t)c.r[1] > (int32_t)c.r[6]; if (k) { goto L_060631DC; } }  // 060631D4 bf/s 0x060631DC ; cmp/gt r6,r1
    { const bool k = !c.t; c.r[0] = c.r[2]; if (k) { goto L_060631E6; } }  // 060631D8 bf/s 0x060631E6 ; mov r2,r0
L_060631DC:
    c.r[2] += 1;  // 060631DC add #1,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[7];  // 060631DE cmp/gt r7,r2
    { const bool k = !c.t; c.r[1] = c.r[3]; if (k) { SH2_POLL(c); goto L_060631CA; } }  // 060631E0 bf/s 0x060631CA ; mov r3,r1
    c.r[0] = c.r[2];  // 060631E4 mov r2,r0
L_060631E6:
    c.t = c.r[0] == 0x4u; goto L_06063228;  // 060631E6 bra 0x06063228 ; cmp/eq #4,r0
L_06063214:
    c.r[5] = c.r[5] & 0xFFu;  // 06063214 extu.b r5,r5
    c.r[0] = ld32(0x0606337Cu);  // 06063216 mov.l 0x0606337C,r0
    c.r[4] = ld32(c.r[0]);  // 06063218 mov.l @r0,r4
    c.r[0] = ld32(0x06063380u);  // 0606321A mov.l 0x06063380,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06063220u; c.r[4] += 30; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06063220u) return; }  // 0606321C jsr @r0 ; add #30,r4
    c.r[1] = c.r[0];  // 06063220 mov r0,r1
    c.r[5] = (uint32_t)(int32_t)(int8_t)c.r[1];  // 06063222 exts.b r1,r5
    c.r[0] = c.r[5];  // 06063224 mov r5,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 06063226 cmp/eq #-1,r0
L_06063228:
    if (c.t) { goto L_0606322C; }  // 06063228 bt 0x0606322C
L_0606322A:
    c.r[5] = 0x0u;  // 0606322A mov #0,r5
L_0606322C:
    c.r[0] = ld32(0x06063384u);  // 0606322C mov.l 0x06063384,r0
    c.r[7] = ld32(c.r[0]);  // 0606322E mov.l @r0,r7
    c.r[7] += c.r[10];  // 06063230 add r10,r7
    c.r[1] = c.r[7];  // 06063232 mov r7,r1
    c.r[0] = ld32(0x0606337Cu);  // 06063234 mov.l 0x0606337C,r0
    c.r[3] = ld32(c.r[0]);  // 06063236 mov.l @r0,r3
    c.r[1] += 59;  // 06063238 add #59,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606323A mov.b @r1,r2
    c.r[3] += 9;  // 0606323C add #9,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0606323E mov.b @r3,r1
    c.r[2] = c.r[2] & 0xFFu;  // 06063240 extu.b r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06063242 extu.b r1,r1
    c.t = c.r[2] > c.r[1];  // 06063244 cmp/hi r1,r2
    { const bool k = c.t; c.t = (c.r[5] & c.r[5]) == 0; if (k) { goto L_06063282; } }  // 06063246 bt/s 0x06063282 ; tst r5,r5
    { const bool k = !c.t; c.r[1] = c.r[7]; if (k) { goto L_06063282; } }  // 0606324A bf/s 0x06063282 ; mov r7,r1
    c.r[1] += 52;  // 0606324E add #52,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06063250 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06063252 mov r1,r0
    c.r[0] >>= 2;  // 06063254 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06063256 shlr r0
    c.r[0] &= 0x7u;  // 06063258 and #7,r0
    c.r[1] = ld32(0x06063388u);  // 0606325A mov.l 0x06063388,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606325C mov.b @(r0,r1),r2
    c.r[1] = ld32(0x0606338Cu);  // 0606325E mov.l 0x0606338C,r1
    c.r[1] = ld32(c.r[1]);  // 06063260 mov.l @r1,r1
    c.r[1] += 18;  // 06063262 add #18,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06063264 mov.w @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 06063266 extu.b r2,r2
    c.r[1] <<= 16;  // 06063268 shll16 r1
    c.r[1] <<= 2;  // 0606326A shll2 r1
    c.r[1] += c.r[1];  // 0606326C add r1,r1
    c.r[1] <<= 2;  // 0606326E shll2 r1
    c.r[1] >>= 16;  // 06063270 shlr16 r1
    c.r[1] <<= 2;  // 06063272 shll2 r1
    c.r[1] >>= 8;  // 06063274 shlr8 r1
    c.t = c.r[2] > c.r[1];  // 06063276 cmp/hi r1,r2
    { const bool k = c.t; c.r[0] = c.r[13]; if (k) { goto L_06063282; } }  // 06063278 bt/s 0x06063282 ; mov r13,r0
    c.t = c.r[0] == 0x2u;  // 0606327C cmp/eq #2,r0
    { const bool k = !c.t; c.r[1] = c.r[7]; if (k) { goto L_06063294; } }  // 0606327E bf/s 0x06063294 ; mov r7,r1
L_06063282:
    c.r[0] = ld32(0x06063384u);  // 06063282 mov.l 0x06063384,r0
    c.r[1] = ld32(c.r[0]);  // 06063284 mov.l @r0,r1
    c.r[1] += c.r[10];  // 06063286 add r10,r1
    c.r[1] += 51;  // 06063288 add #51,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606328A mov.b @r1,r2
    c.r[0] = 0x8u;  // 0606328C mov #8,r0
    c.r[2] |= c.r[0];  // 0606328E or r0,r2
    st8(c.r[1], c.r[2]); goto L_0606329C;  // 06063290 bra 0x0606329C ; mov.b r2,@r1
L_06063294:
    c.r[1] += 51;  // 06063294 add #51,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06063296 mov.b @r1,r0
    c.r[0] &= 0xF7u;  // 06063298 and #247,r0
    st8(c.r[1], c.r[0]);  // 0606329A mov.b r0,@r1
L_0606329C:
    c.r[0] = c.r[14];  // 0606329C mov r14,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[12]);  // 0606329E mov.b @(r0,r12),r1
    c.r[3] = c.r[1] & 0xFFu;  // 060632A0 extu.b r1,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x06063374u);  // 060632A2 mov.w 0x06063374,r1
    c.t = c.r[3] == c.r[1];  // 060632A4 cmp/eq r1,r3
    if (c.t) { goto L_060632DC; }  // 060632A6 bt 0x060632DC
    c.r[1] = ld32(0x0606338Cu);  // 060632A8 mov.l 0x0606338C,r1
    c.r[2] = ld32(c.r[1]);  // 060632AA mov.l @r1,r2
    c.r[1] = ld32(0x06063390u);  // 060632AC mov.l 0x06063390,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060632AE mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 060632B0 extu.b r1,r0
    c.r[0] <<= 2;  // 060632B2 shll2 r0
    c.r[0] <<= 2;  // 060632B4 shll2 r0
    c.r[0] += c.r[2];  // 060632B6 add r2,r0
    c.r[0] += 40;  // 060632B8 add #40,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 060632BA mov.b @(r0,r3),r1
    c.r[1] = c.r[1] & 0xFFu;  // 060632BC extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060632BE tst r1,r1
    if (!c.t) { goto L_060632DC; }  // 060632C0 bf 0x060632DC
    c.r[0] = ld32(0x06063384u);  // 060632C2 mov.l 0x06063384,r0
    c.r[1] = ld32(c.r[0]);  // 060632C4 mov.l @r0,r1
    c.r[1] += c.r[10];  // 060632C6 add r10,r1
    c.r[1] += 51;  // 060632C8 add #51,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060632CA mov.b @r1,r2
    c.r[0] = 0x8u;  // 060632CC mov #8,r0
    c.r[2] |= c.r[0];  // 060632CE or r0,r2
    st8(c.r[1], c.r[2]);  // 060632D0 mov.b r2,@r1
    c.r[1] = ld32(0x06063394u);  // 060632D2 mov.l 0x06063394,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060632D4 mov.b @r1,r2
    c.r[0] = 0x1u;  // 060632D6 mov #1,r0
    c.r[2] |= c.r[0];  // 060632D8 or r0,r2
    st8(c.r[1], c.r[2]);  // 060632DA mov.b r2,@r1
L_060632DC:
    c.r[0] = ld32(0x06063384u);  // 060632DC mov.l 0x06063384,r0
    c.r[3] = ld32(c.r[0]);  // 060632DE mov.l @r0,r3
    c.r[7] = c.r[3];  // 060632E0 mov r3,r7
    c.r[7] += c.r[10];  // 060632E2 add r10,r7
    c.r[1] = c.r[7];  // 060632E4 mov r7,r1
    c.r[1] += 54;  // 060632E6 add #54,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060632E8 mov.w @r1,r2
    c.r[3] += 24;  // 060632EA add #24,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 060632EC mov.w @r3,r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 060632EE extu.w r2,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 060632F0 extu.w r1,r1
    c.t = c.r[2] > c.r[1];  // 060632F2 cmp/hi r1,r2
    { const bool k = !c.t; c.r[1] = c.r[7]; if (k) { goto L_06063308; } }  // 060632F4 bf/s 0x06063308 ; mov r7,r1
    c.r[1] += 51;  // 060632F8 add #51,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060632FA mov.b @r1,r0
    c.r[0] |= 0x8u;  // 060632FC or #8,r0
    st8(c.r[1], c.r[0]);  // 060632FE mov.b r0,@r1
    c.r[1] = ld32(0x06063394u);  // 06063300 mov.l 0x06063394,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06063302 mov.b @r1,r0
    c.r[0] |= 0x2u;  // 06063304 or #2,r0
    st8(c.r[1], c.r[0]);  // 06063306 mov.b r0,@r1
L_06063308:
    c.r[3] = ld32(0x06063398u);  // 06063308 mov.l 0x06063398,r3
    c.r[2] = ld32(c.r[3]);  // 0606330A mov.l @r3,r2
    c.r[5] = (uint32_t)(int16_t)ld16(0x06063376u);  // 0606330C mov.w 0x06063376,r5
    c.r[0] = c.r[2];  // 0606330E mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 06063310 mov.b @(r0,r5),r1
    c.r[6] = c.r[1] & 0xFFu;  // 06063312 extu.b r1,r6
    c.r[6] += c.r[6];  // 06063314 add r6,r6
    c.r[1] = c.r[12] & 0xFFFFu;  // 06063316 extu.w r12,r1
    c.r[4] = c.r[1];  // 06063318 mov r1,r4
    c.r[4] >>= 8;  // 0606331A shlr8 r4
    c.r[0] = 0x7Fu;  // 0606331C mov #127,r0
    c.r[4] &= c.r[0];  // 0606331E and r0,r4
    c.r[0] = c.r[2];  // 06063320 mov r2,r0
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 06063322 mov.b @(r0,r6),r7
    c.r[0] = (uint32_t)(int16_t)ld16(0x06063378u);  // 06063324 mov.w 0x06063378,r0
    c.r[7] &= c.r[0];  // 06063326 and r0,r7
    c.r[7] |= c.r[4];  // 06063328 or r4,r7
    c.r[0] = c.r[2];  // 0606332A mov r2,r0
    st8(c.r[0] + c.r[6], c.r[7]);  // 0606332C mov.b r7,@(r0,r6)
    c.r[2] += c.r[6];  // 0606332E add r6,r2
    c.r[2] += 1;  // 06063330 add #1,r2
    st8(c.r[2], c.r[1]);  // 06063332 mov.b r1,@r2
    c.r[2] = ld32(c.r[3]);  // 06063334 mov.l @r3,r2
    c.r[0] = c.r[2];  // 06063336 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 06063338 mov.b @(r0,r5),r1
    c.r[1] += 1;  // 0606333A add #1,r1
    st8(c.r[0] + c.r[5], c.r[1]);  // 0606333C mov.b r1,@(r0,r5)
L_0606333E:
    c.r[12] += 1;  // 0606333E add #1,r12
    c.r[1] = 0xFu;  // 06063340 mov #15,r1
    c.t = (int32_t)c.r[12] > (int32_t)c.r[1];  // 06063342 cmp/gt r1,r12
    { const bool k = c.t; c.r[10] += 20; if (k) { goto L_0606334C; } }  // 06063344 bt/s 0x0606334C ; add #20,r10
    SH2_POLL(c); goto L_06063126;  // 06063348 bra 0x06063126 ; nop
L_0606334C:
    c.r[1] = ld32(0x0606339Cu);  // 0606334C mov.l 0x0606339C,r1
    c.r[1] = ld32(c.r[1]);  // 0606334E mov.l @r1,r1
    c.r[1] += 1;  // 06063350 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06063352 mov.b @r1,r1
    c.r[2] = 0x1u;  // 06063354 mov #1,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06063356 extu.b r1,r1
    c.t = c.r[1] > c.r[2];  // 06063358 cmp/hi r2,r1
    if (!c.t) { goto L_06063362; }  // 0606335A bf 0x06063362
    c.r[1] = ld32(0x060633A0u);  // 0606335C mov.l 0x060633A0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06063362u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06063362u) return; }  // 0606335E jsr @r1 ; nop
L_06063362:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06063376u);  // 06063362 mov.w 0x06063376,r0
    st32(c.r[14] + 16, c.r[0]);  // 06063364 mov.l r0,@(16,r14)
L_06063366:
    c.r[0] = ld32(0x06063398u);  // 06063366 mov.l 0x06063398,r0
    c.r[1] = ld32(c.r[0]);  // 06063368 mov.l @r0,r1
    c.r[0] = ld32(c.r[14] + 16);  // 0606336A mov.l @(16,r14),r0
    c.r[11] = 0x0u;  // 0606336C mov #0,r11
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606336E mov.b @(r0,r1),r1
    c.r[12] = 0x0u; goto L_06063460;  // 06063370 bra 0x06063460 ; mov #0,r12
L_060633A4:
    c.r[0] = ld32(0x060634D4u);  // 060633A4 mov.l 0x060634D4,r0
    c.r[1] = ld32(c.r[0]);  // 060633A6 mov.l @r0,r1
    c.r[0] = ld32(c.r[14] + 16);  // 060633A8 mov.l @(16,r14),r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060633AA mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 060633AC extu.b r1,r1
    c.r[1] -= 1;  // 060633AE add #-1,r1
    c.t = (int32_t)c.r[12] >= (int32_t)c.r[1];  // 060633B0 cmp/ge r1,r12
    { const bool k = c.t; c.r[2] = c.r[12]; if (k) { goto L_06063454; } }  // 060633B2 bt/s 0x06063454 ; mov r12,r2
    c.r[13] = c.r[2];  // 060633B6 mov r2,r13
L_060633B8:
    c.r[13] += 1;  // 060633B8 add #1,r13
    c.r[6] = c.r[13] & 0xFFu;  // 060633BA extu.b r13,r6
    c.r[1] = ld32(0x060634D8u);  // 060633BC mov.l 0x060634D8,r1
    c.r[0] = ld32(0x060634D4u);  // 060633BE mov.l 0x060634D4,r0
    c.r[4] = c.r[2];  // 060633C0 mov r2,r4
    c.r[4] += c.r[4];  // 060633C2 add r4,r4
    c.r[5] = ld32(c.r[0]);  // 060633C4 mov.l @r0,r5
    c.r[2] = 0x7Fu;  // 060633C6 mov #127,r2
    c.r[3] = ld32(c.r[1]);  // 060633C8 mov.l @r1,r3
    c.r[0] = c.r[5];  // 060633CA mov r5,r0
    c.r[10] = c.r[5];  // 060633CC mov r5,r10
    c.r[10] += c.r[4];  // 060633CE add r4,r10
    c.r[9] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[4]);  // 060633D0 mov.b @(r0,r4),r9
    c.r[10] += 1;  // 060633D2 add #1,r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 060633D4 mov.b @r10,r1
    c.r[2] &= c.r[9];  // 060633D6 and r9,r2
    c.r[2] <<= 8;  // 060633D8 shll8 r2
    c.r[8] = c.r[1] & 0xFFu;  // 060633DA extu.b r1,r8
    c.r[8] |= c.r[2];  // 060633DC or r2,r8
    c.r[0] = 0x14u;  // 060633DE mov #20,r0
    c.macl = (c.r[8] & 0xFFFFu) * (c.r[0] & 0xFFFFu);  // 060633E0 mulu.w r0,r8
    c.r[6] += c.r[6];  // 060633E2 add r6,r6
    c.r[2] = c.macl;  // 060633E4 sts macl,r2
    c.r[2] += c.r[3];  // 060633E6 add r3,r2
    c.r[0] = c.r[5];  // 060633E8 mov r5,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 060633EA mov.b @(r0,r6),r1
    c.r[2] += 48;  // 060633EC add #48,r2
    c.r[0] = c.r[1];  // 060633EE mov r1,r0
    c.r[0] &= 0x7Fu;  // 060633F0 and #127,r0
    c.r[1] = c.r[5];  // 060633F2 mov r5,r1
    c.r[1] += c.r[6];  // 060633F4 add r6,r1
    c.r[1] += 1;  // 060633F6 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060633F8 mov.b @r1,r1
    c.r[0] <<= 8;  // 060633FA shll8 r0
    c.r[7] = c.r[1] & 0xFFu;  // 060633FC extu.b r1,r7
    c.r[7] |= c.r[0];  // 060633FE or r0,r7
    c.r[0] = 0x14u;  // 06063400 mov #20,r0
    c.macl = (c.r[7] & 0xFFFFu) * (c.r[0] & 0xFFFFu);  // 06063402 mulu.w r0,r7
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06063404 mov.w @r2,r2
    c.r[1] = c.macl;  // 06063406 sts macl,r1
    c.r[3] += c.r[1];  // 06063408 add r1,r3
    c.r[3] += 48;  // 0606340A add #48,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0606340C mov.w @r3,r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 0606340E extu.w r2,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 06063410 extu.w r1,r1
    c.t = c.r[2] > c.r[1];  // 06063412 cmp/hi r1,r2
    { const bool k = !c.t; c.r[1] = c.r[7] & 0xFFFFu; if (k) { goto L_06063440; } }  // 06063414 bf/s 0x06063440 ; extu.w r7,r1
    c.r[2] = c.r[1];  // 06063418 mov r1,r2
    c.r[2] >>= 8;  // 0606341A shlr8 r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x060634CCu);  // 0606341C mov.w 0x060634CC,r3
    c.r[3] &= c.r[9];  // 0606341E and r9,r3
    c.r[3] |= c.r[2];  // 06063420 or r2,r3
    c.r[0] = c.r[5];  // 06063422 mov r5,r0
    st8(c.r[0] + c.r[4], c.r[3]);  // 06063424 mov.b r3,@(r0,r4)
    st8(c.r[10], c.r[1]);  // 06063426 mov.b r1,@r10
    c.r[0] = ld32(0x060634D4u);  // 06063428 mov.l 0x060634D4,r0
    c.r[1] = ld32(c.r[0]);  // 0606342A mov.l @r0,r1
    c.r[0] = c.r[1];  // 0606342C mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 0606342E mov.b @(r0,r6),r2
    c.r[11] = 0x1u;  // 06063430 mov #1,r11
    c.r[0] = (uint32_t)(int16_t)ld16(0x060634CCu);  // 06063432 mov.w 0x060634CC,r0
    c.r[2] &= c.r[0];  // 06063434 and r0,r2
    c.r[0] = c.r[1];  // 06063436 mov r1,r0
    st8(c.r[0] + c.r[6], c.r[2]);  // 06063438 mov.b r2,@(r0,r6)
    c.r[1] += c.r[6];  // 0606343A add r6,r1
    c.r[1] += 1;  // 0606343C add #1,r1
    st8(c.r[1], c.r[8]);  // 0606343E mov.b r8,@r1
L_06063440:
    c.r[0] = ld32(0x060634D4u);  // 06063440 mov.l 0x060634D4,r0
    c.r[1] = ld32(c.r[0]);  // 06063442 mov.l @r0,r1
    c.r[0] = ld32(c.r[14] + 16);  // 06063444 mov.l @(16,r14),r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06063446 mov.b @(r0,r1),r1
    c.r[2] = c.r[13];  // 06063448 mov r13,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0606344A extu.b r1,r1
    c.r[1] -= 1;  // 0606344C add #-1,r1
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[1];  // 0606344E cmp/ge r1,r2
    { const bool k = !c.t; c.r[13] = c.r[2]; if (k) { SH2_POLL(c); goto L_060633B8; } }  // 06063450 bf/s 0x060633B8 ; mov r2,r13
L_06063454:
    c.r[1] = ld32(0x060634D4u);  // 06063454 mov.l 0x060634D4,r1
    c.r[1] = ld32(c.r[1]);  // 06063456 mov.l @r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x060634CEu);  // 06063458 mov.w 0x060634CE,r2
    c.r[0] = c.r[1];  // 0606345A mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0606345C mov.b @(r0,r2),r1
    c.r[12] += 1;  // 0606345E add #1,r12
L_06063460:
    c.r[1] = c.r[1] & 0xFFu;  // 06063460 extu.b r1,r1
    c.r[1] -= 1;  // 06063462 add #-1,r1
    c.t = (int32_t)c.r[12] >= (int32_t)c.r[1];  // 06063464 cmp/ge r1,r12
    { const bool k = !c.t; c.t = (c.r[11] & c.r[11]) == 0; if (k) { SH2_POLL(c); goto L_060633A4; } }  // 06063466 bf/s 0x060633A4 ; tst r11,r11
    if (c.t) { goto L_06063470; }  // 0606346A bt 0x06063470
    SH2_POLL(c); goto L_06063366;  // 0606346C bra 0x06063366 ; nop
L_06063470:
    c.r[1] = ld32(0x060634DCu);  // 06063470 mov.l 0x060634DC,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06063472 mov.b @r1,r4
    c.r[0] = ld32(0x060634E0u);  // 06063474 mov.l 0x060634E0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0606347Au; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606347Au) return; }  // 06063476 jsr @r0 ; extu.b r4,r4
    c.r[1] = c.r[0] & 0xFFFFu;  // 0606347A extu.w r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606347C tst r1,r1
    { const bool k = !c.t; c.r[12] = 0x0u; if (k) { goto L_060634B4; } }  // 0606347E bf/s 0x060634B4 ; mov #0,r12
    c.r[7] = ld32(0x060634D4u);  // 06063482 mov.l 0x060634D4,r7
    c.r[1] = ld32(c.r[7]);  // 06063484 mov.l @r7,r1
    c.r[3] = (uint32_t)(int16_t)ld16(0x060634CEu);  // 06063486 mov.w 0x060634CE,r3
    c.r[0] = c.r[1];  // 06063488 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0606348A mov.b @(r0,r3),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606348C extu.b r1,r1
    c.t = (int32_t)c.r[12] >= (int32_t)c.r[1];  // 0606348E cmp/ge r1,r12
    { const bool k = c.t; c.r[2] = 0x0u; if (k) { goto L_060634B4; } }  // 06063490 bt/s 0x060634B4 ; mov #0,r2
    c.r[6] = ld32(0x060634D8u);  // 06063494 mov.l 0x060634D8,r6
L_06063496:
    c.r[1] = ld32(c.r[6]);  // 06063496 mov.l @r6,r1
    c.r[1] += c.r[2];  // 06063498 add r2,r1
    c.r[1] += 51;  // 0606349A add #51,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606349C mov.b @r1,r5
    c.r[0] = 0x8u;  // 0606349E mov #8,r0
    c.r[5] |= c.r[0];  // 060634A0 or r0,r5
    st8(c.r[1], c.r[5]);  // 060634A2 mov.b r5,@r1
    c.r[1] = ld32(c.r[7]);  // 060634A4 mov.l @r7,r1
    c.r[12] += 1;  // 060634A6 add #1,r12
    c.r[0] = c.r[1];  // 060634A8 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 060634AA mov.b @(r0,r3),r1
    c.r[1] = c.r[1] & 0xFFu;  // 060634AC extu.b r1,r1
    c.t = (int32_t)c.r[12] >= (int32_t)c.r[1];  // 060634AE cmp/ge r1,r12
    { const bool k = !c.t; c.r[2] += 20; if (k) { SH2_POLL(c); goto L_06063496; } }  // 060634B0 bf/s 0x06063496 ; add #20,r2
L_060634B4:
    c.r[14] += 24;  // 060634B4 add #24,r14
    c.r[15] = c.r[14];  // 060634B6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060634B8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060634BA mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060634BC mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060634BE mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060634C0 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060634C2 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060634C4 mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x060634D0u);  // 060634C6 mov.w 0x060634D0,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060634C8 rts ; mov.l @r15+,r8
}

void f_060634E4(SH2Context& c) {
    ran[1487] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060634E4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060634E6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060634E8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060634EA mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060634EC mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060634EE mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060634F0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060634F2 sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x0606364Cu);  // 060634F4 mov.w 0x0606364C,r3
    c.r[1] = ld32(0x0606365Cu);  // 060634F6 mov.l 0x0606365C,r1
    c.r[1] = ld32(c.r[1]);  // 060634F8 mov.l @r1,r1
    c.r[15] += c.r[3];  // 060634FA add r3,r15
    c.r[1] += 1;  // 060634FC add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060634FE mov.b @r1,r1
    c.r[14] = c.r[15];  // 06063500 mov r15,r14
    c.r[0] = c.r[1] & 0xFFu;  // 06063502 extu.b r1,r0
    c.t = c.r[0] == 0x4u;  // 06063504 cmp/eq #4,r0
    { const bool k = !c.t; c.r[1] = 0x0u; if (k) { goto L_0606350C; } }  // 06063506 bf/s 0x0606350C ; mov #0,r1
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606364Eu);  // 0606350A mov.w 0x0606364E,r1
L_0606350C:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06063650u);  // 0606350C mov.w 0x06063650,r0
    st32(c.r[0] + c.r[14], c.r[1]);  // 0606350E mov.l r1,@(r0,r14)
    c.r[5] = (uint32_t)(int16_t)ld16(0x06063652u);  // 06063510 mov.w 0x06063652,r5
    c.r[4] = 0x0u;  // 06063512 mov #0,r4
    c.r[13] = 0x0u;  // 06063514 mov #0,r13
    c.r[9] = (uint32_t)(int16_t)ld16(0x06063654u);  // 06063516 mov.w 0x06063654,r9
    c.r[9] += c.r[14];  // 06063518 add r14,r9
    st32(c.r[9], c.r[13]);  // 0606351A mov.l r13,@r9
    c.r[9] = 0x0u;  // 0606351C mov #0,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06063656u);  // 0606351E mov.w 0x06063656,r0
    st32(c.r[0] + c.r[14], c.r[9]);  // 06063520 mov.l r9,@(r0,r14)
    c.r[11] = ld32(0x06063660u);  // 06063522 mov.l 0x06063660,r11
    c.r[8] = 0x3Fu;  // 06063524 mov #63,r8
    c.r[7] = ld32(0x06063664u);  // 06063526 mov.l 0x06063664,r7
    c.r[6] = 0x0u;  // 06063528 mov #0,r6
L_0606352A:
    c.r[12] = 0x0u;  // 0606352A mov #0,r12
L_0606352C:
    c.r[1] = ld32(0x06063668u);  // 0606352C mov.l 0x06063668,r1
    c.r[0] = ld32(c.r[1]);  // 0606352E mov.l @r1,r0
    c.r[0] += c.r[6];  // 06063530 add r6,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[12]);  // 06063532 mov.b @(r0,r12),r1
    c.r[10] = c.r[1] & 0xFFu;  // 06063534 extu.b r1,r10
    c.r[0] = c.r[12];  // 06063536 mov r12,r0
    c.r[0] += c.r[0];  // 06063538 add r0,r0
    c.r[3] = c.r[0];  // 0606353A mov r0,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[7]);  // 0606353C mov.w @(r0,r7),r1
    c.r[2] = c.r[1] & 0xFFFFu;  // 0606353E extu.w r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06063540 tst r2,r2
    { const bool k = c.t; c.r[3] += c.r[7]; if (k) { goto L_06063592; } }  // 06063542 bt/s 0x06063592 ; add r7,r3
    c.t = c.r[2] == c.r[11];  // 06063546 cmp/eq r11,r2
    if (c.t) { goto L_06063592; }  // 06063548 bt 0x06063592
    c.r[13] = (uint32_t)(int16_t)ld16(0x06063652u);  // 0606354A mov.w 0x06063652,r13
    c.t = c.r[10] == c.r[13];  // 0606354C cmp/eq r13,r10
    { const bool k = c.t; c.r[1] = c.r[5] & 0xFFFFu; if (k) { goto L_06063592; } }  // 0606354E bt/s 0x06063592 ; extu.w r5,r1
    c.t = c.r[1] > c.r[2];  // 06063552 cmp/hi r2,r1
    { const bool k = !c.t; c.r[1] = c.r[3]; if (k) { goto L_0606355E; } }  // 06063554 bf/s 0x0606355E ; mov r3,r1
    c.r[1] += 1;  // 06063558 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606355A mov.b @r1,r1
    c.r[5] = c.r[1] & 0xFFu;  // 0606355C extu.b r1,r5
L_0606355E:
    c.r[1] = c.r[4] & 0xFFFFu;  // 0606355E extu.w r4,r1
    c.t = c.r[1] >= c.r[2];  // 06063560 cmp/hs r2,r1
    { const bool k = c.t; c.r[3] += 1; if (k) { goto L_0606356A; } }  // 06063562 bt/s 0x0606356A ; add #1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06063566 mov.b @r3,r1
    c.r[4] = c.r[1] & 0xFFu;  // 06063568 extu.b r1,r4
L_0606356A:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06063654u);  // 0606356A mov.w 0x06063654,r0
    c.r[0] += c.r[14];  // 0606356C add r14,r0
    c.r[1] = c.r[14];  // 0606356E mov r14,r1
    c.r[1] += 1;  // 06063570 add #1,r1
    c.r[2] = ld32(c.r[0]);  // 06063572 mov.l @r0,r2
    c.r[13] = (uint32_t)(int16_t)ld16(0x06063654u);  // 06063574 mov.w 0x06063654,r13
    c.r[2] += c.r[2];  // 06063576 add r2,r2
    c.r[0] = c.r[14];  // 06063578 mov r14,r0
    st8(c.r[0] + c.r[2], c.r[12]);  // 0606357A mov.b r12,@(r0,r2)
    c.r[0] = (uint32_t)(int16_t)ld16(0x06063658u);  // 0606357C mov.w 0x06063658,r0
    c.r[9] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 0606357E mov.b @(r0,r14),r9
    c.r[13] += c.r[14];  // 06063580 add r14,r13
    c.r[0] = c.r[1];  // 06063582 mov r1,r0
    st8(c.r[0] + c.r[2], c.r[9]);  // 06063584 mov.b r9,@(r0,r2)
    c.r[1] = ld32(c.r[13]);  // 06063586 mov.l @r13,r1
    c.r[1] += 1;  // 06063588 add #1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606358A extu.b r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06063654u);  // 0606358C mov.w 0x06063654,r0
    c.r[0] += c.r[14];  // 0606358E add r14,r0
    st32(c.r[0], c.r[1]);  // 06063590 mov.l r1,@r0
L_06063592:
    c.r[12] += 1;  // 06063592 add #1,r12
    c.t = (int32_t)c.r[12] > (int32_t)c.r[8];  // 06063594 cmp/gt r8,r12
    if (!c.t) { SH2_POLL(c); goto L_0606352C; }  // 06063596 bf 0x0606352C
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606364Eu);  // 06063598 mov.w 0x0606364E,r1
    c.r[7] += c.r[1];  // 0606359A add r1,r7
    c.r[9] = (uint32_t)(int16_t)ld16(0x06063656u);  // 0606359C mov.w 0x06063656,r9
    c.r[9] += c.r[14];  // 0606359E add r14,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06063656u);  // 060635A0 mov.w 0x06063656,r0
    c.r[13] = ld32(c.r[9]);  // 060635A2 mov.l @r9,r13
    c.r[0] += c.r[14];  // 060635A4 add r14,r0
    c.r[13] += 1;  // 060635A6 add #1,r13
    st32(c.r[9], c.r[13]);  // 060635A8 mov.l r13,@r9
    c.r[0] = ld32(c.r[0]);  // 060635AA mov.l @r0,r0
    c.t = (int32_t)c.r[0] > (int32_t)c.r[8];  // 060635AC cmp/gt r8,r0
    { const bool k = !c.t; c.r[6] += 64; if (k) { SH2_POLL(c); goto L_0606352A; } }  // 060635AE bf/s 0x0606352A ; add #64,r6
    c.r[7] = ld32(0x06063668u);  // 060635B2 mov.l 0x06063668,r7
    c.r[1] = ld32(0x0606366Cu);  // 060635B4 mov.l 0x0606366C,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060635B6 mov.b @r1,r3
    c.r[1] = ld32(0x06063670u);  // 060635B8 mov.l 0x06063670,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060635BA mov.b @r1,r2
    c.r[1] = ld32(c.r[7]);  // 060635BC mov.l @r7,r1
    c.r[3] <<= 2;  // 060635BE shll2 r3
    c.r[3] <<= 2;  // 060635C0 shll2 r3
    c.r[3] <<= 2;  // 060635C2 shll2 r3
    c.r[3] += c.r[1];  // 060635C4 add r1,r3
    c.r[0] = c.r[3];  // 060635C6 mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 060635C8 mov.b @(r0,r2),r1
    c.r[11] = c.r[1] & 0xFFu;  // 060635CA extu.b r1,r11
    c.r[1] = ld32(0x0606365Cu);  // 060635CC mov.l 0x0606365C,r1
    c.r[1] = ld32(c.r[1]);  // 060635CE mov.l @r1,r1
    c.r[1] += 1;  // 060635D0 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060635D2 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060635D4 extu.b r1,r1
    c.r[0] = c.r[1];  // 060635D6 mov r1,r0
    c.t = c.r[0] == 0x6u;  // 060635D8 cmp/eq #6,r0
    if (c.t) { goto L_060635E0; }  // 060635DA bt 0x060635E0
    goto L_06063720;  // 060635DC bra 0x06063720 ; nop
L_060635E0:
    c.r[1] = ld32(0x06063674u);  // 060635E0 mov.l 0x06063674,r1
    c.r[3] = ld32(c.r[1]);  // 060635E2 mov.l @r1,r3
    c.r[1] = ld32(0x06063678u);  // 060635E4 mov.l 0x06063678,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060635E6 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060635E8 extu.b r1,r1
    c.r[2] = c.r[1];  // 060635EA mov r1,r2
    c.r[2] <<= 2;  // 060635EC shll2 r2
    c.r[2] += c.r[1];  // 060635EE add r1,r2
    c.r[2] <<= 2;  // 060635F0 shll2 r2
    c.r[3] += c.r[2];  // 060635F2 add r2,r3
    c.r[3] += 50;  // 060635F4 add #50,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060635F6 mov.b @r3,r1
    c.r[2] = 0x3Fu;  // 060635F8 mov #63,r2
    c.r[2] &= c.r[1];  // 060635FA and r1,r2
    c.r[1] = ld32(0x0606367Cu);  // 060635FC mov.l 0x0606367C,r1
    c.r[0] = c.r[2];  // 060635FE mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06063600 mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06063602 extu.b r1,r1
    c.r[0] = c.r[1];  // 06063604 mov r1,r0
    c.t = c.r[0] == 0x3u;  // 06063606 cmp/eq #3,r0
    { const bool k = c.t; c.r[13] = 0x0u; if (k) { goto L_06063616; } }  // 06063608 bt/s 0x06063616 ; mov #0,r13
    c.t = c.r[0] == 0xCu;  // 0606360C cmp/eq #12,r0
    { const bool k = c.t; c.r[9] = 0x0u; if (k) { goto L_06063616; } }  // 0606360E bt/s 0x06063616 ; mov #0,r9
    goto L_06063722;  // 06063612 bra 0x06063722 ; nop
L_06063616:
    c.r[9] = (uint32_t)(int16_t)ld16(0x06063656u);  // 06063616 mov.w 0x06063656,r9
    c.r[9] += c.r[14];  // 06063618 add r14,r9
    st32(c.r[9], c.r[13]);  // 0606361A mov.l r13,@r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06063656u);  // 0606361C mov.w 0x06063656,r0
    c.r[9] = ld32(c.r[0] + c.r[14]);  // 0606361E mov.l @(r0,r14),r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06063654u);  // 06063620 mov.w 0x06063654,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06063622 mov.l @(r0,r14),r0
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[0];  // 06063624 cmp/ge r0,r9
    if (c.t) { goto L_060636EE; }  // 06063626 bt 0x060636EE
    c.r[8] = c.r[7];  // 06063628 mov r7,r8
    c.r[5] = c.r[14];  // 0606362A mov r14,r5
    c.r[5] += 1;  // 0606362C add #1,r5
    c.r[4] = ld32(0x06063680u);  // 0606362E mov.l 0x06063680,r4
    c.r[6] = 0x0u;  // 06063630 mov #0,r6
L_06063632:
    c.r[0] = c.r[6];  // 06063632 mov r6,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 06063634 mov.b @(r0,r5),r1
    c.r[3] = c.r[1] & 0xFFu;  // 06063636 extu.b r1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 06063638 mov.b @(r0,r14),r1
    c.r[2] = c.r[1] & 0xFFu;  // 0606363A extu.b r1,r2
    c.r[1] = ld32(c.r[8]);  // 0606363C mov.l @r8,r1
    c.r[3] <<= 2;  // 0606363E shll2 r3
    c.r[3] <<= 2;  // 06063640 shll2 r3
    c.r[3] <<= 2;  // 06063642 shll2 r3
    c.r[3] += c.r[1];  // 06063644 add r1,r3
    c.r[0] = c.r[3];  // 06063646 mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]); goto L_06063684;  // 06063648 bra 0x06063684 ; mov.b @(r0,r2),r2
L_06063684:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]);  // 06063684 mov.b @r4,r1
    c.r[2] = c.r[2] & 0xFFu;  // 06063686 extu.b r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06063688 extu.b r1,r1
    c.t = c.r[2] == c.r[1];  // 0606368A cmp/eq r1,r2
    if (!c.t) { goto L_060636D2; }  // 0606368C bf 0x060636D2
    c.r[9] = (uint32_t)(int16_t)ld16(0x06063810u);  // 0606368E mov.w 0x06063810,r9
    c.r[9] += c.r[14];  // 06063690 add r14,r9
    c.r[13] = (uint32_t)(int16_t)ld16(0x06063812u);  // 06063692 mov.w 0x06063812,r13
    c.r[13] += c.r[14];  // 06063694 add r14,r13
    c.r[0] = (uint32_t)(int16_t)ld16(0x06063810u);  // 06063696 mov.w 0x06063810,r0
    c.r[7] = ld32(c.r[13]);  // 06063698 mov.l @r13,r7
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 0606369A mov.l @(r0,r14),r0
    c.r[7] -= 1;  // 0606369C add #-1,r7
    c.t = (int32_t)c.r[0] >= (int32_t)c.r[7];  // 0606369E cmp/ge r7,r0
    { const bool k = c.t; c.r[12] = ld32(c.r[9]); if (k) { goto L_060636C2; } }  // 060636A0 bt/s 0x060636C2 ; mov.l @r9,r12
L_060636A4:
    c.r[2] = c.r[12];  // 060636A4 mov r12,r2
    c.r[2] += c.r[2];  // 060636A6 add r2,r2
    c.r[3] = c.r[12];  // 060636A8 mov r12,r3
    c.r[3] += 1;  // 060636AA add #1,r3
    c.r[9] = c.r[3];  // 060636AC mov r3,r9
    c.r[9] += c.r[9];  // 060636AE add r9,r9
    c.r[0] = c.r[14];  // 060636B0 mov r14,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 060636B2 mov.b @(r0,r9),r1
    c.r[12] = c.r[3];  // 060636B4 mov r3,r12
    st8(c.r[0] + c.r[2], c.r[1]);  // 060636B6 mov.b r1,@(r0,r2)
    c.r[0] = c.r[5];  // 060636B8 mov r5,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 060636BA mov.b @(r0,r9),r1
    c.t = (int32_t)c.r[12] >= (int32_t)c.r[7];  // 060636BC cmp/ge r7,r12
    { const bool k = !c.t; st8(c.r[0] + c.r[2], c.r[1]); if (k) { SH2_POLL(c); goto L_060636A4; } }  // 060636BE bf/s 0x060636A4 ; mov.b r1,@(r0,r2)
L_060636C2:
    c.r[9] = (uint32_t)(int16_t)ld16(0x06063812u);  // 060636C2 mov.w 0x06063812,r9
    c.r[9] += c.r[14];  // 060636C4 add r14,r9
    c.r[1] = ld32(c.r[9]);  // 060636C6 mov.l @r9,r1
    c.r[1] -= 1;  // 060636C8 add #-1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060636CA extu.b r1,r1
    c.r[13] = (uint32_t)(int16_t)ld16(0x06063812u);  // 060636CC mov.w 0x06063812,r13
    c.r[13] += c.r[14];  // 060636CE add r14,r13
    st32(c.r[13], c.r[1]);  // 060636D0 mov.l r1,@r13
L_060636D2:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06063810u);  // 060636D2 mov.w 0x06063810,r0
    c.r[0] += c.r[14];  // 060636D4 add r14,r0
    c.r[13] = (uint32_t)(int16_t)ld16(0x06063810u);  // 060636D6 mov.w 0x06063810,r13
    c.r[9] = ld32(c.r[0]);  // 060636D8 mov.l @r0,r9
    c.r[13] += c.r[14];  // 060636DA add r14,r13
    c.r[9] += 1;  // 060636DC add #1,r9
    st32(c.r[0], c.r[9]);  // 060636DE mov.l r9,@r0
    c.r[0] = ld32(c.r[13]);  // 060636E0 mov.l @r13,r0
    c.r[13] = (uint32_t)(int16_t)ld16(0x06063812u);  // 060636E2 mov.w 0x06063812,r13
    c.r[13] += c.r[14];  // 060636E4 add r14,r13
    c.r[13] = ld32(c.r[13]);  // 060636E6 mov.l @r13,r13
    c.t = (int32_t)c.r[0] >= (int32_t)c.r[13];  // 060636E8 cmp/ge r13,r0
    { const bool k = !c.t; c.r[6] += 2; if (k) { SH2_POLL(c); goto L_06063632; } }  // 060636EA bf/s 0x06063632 ; add #2,r6
L_060636EE:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06063814u);  // 060636EE mov.w 0x06063814,r1
    c.t = c.r[11] == c.r[1];  // 060636F0 cmp/eq r1,r11
    { const bool k = c.t; c.r[9] = 0x0u; if (k) { goto L_06063722; } }  // 060636F2 bt/s 0x06063722 ; mov #0,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06063812u);  // 060636F6 mov.w 0x06063812,r0
    c.r[3] = ld32(c.r[0] + c.r[14]);  // 060636F8 mov.l @(r0,r14),r3
    c.r[3] += c.r[3];  // 060636FA add r3,r3
    c.r[1] = ld32(0x06063824u);  // 060636FC mov.l 0x06063824,r1
    c.r[0] = c.r[14];  // 060636FE mov r14,r0
    c.r[2] = c.r[14];  // 06063700 mov r14,r2
    c.r[2] += 1;  // 06063702 add #1,r2
    c.r[9] = (uint32_t)(int16_t)ld16(0x06063812u);  // 06063704 mov.w 0x06063812,r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06063706 mov.b @r1,r1
    c.r[9] += c.r[14];  // 06063708 add r14,r9
    st8(c.r[0] + c.r[3], c.r[1]);  // 0606370A mov.b r1,@(r0,r3)
    c.r[1] = ld32(0x06063828u);  // 0606370C mov.l 0x06063828,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606370E mov.b @r1,r1
    c.r[0] = c.r[2];  // 06063710 mov r2,r0
    st8(c.r[0] + c.r[3], c.r[1]);  // 06063712 mov.b r1,@(r0,r3)
    c.r[1] = ld32(c.r[9]);  // 06063714 mov.l @r9,r1
    c.r[1] += 1;  // 06063716 add #1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06063718 extu.b r1,r1
    c.r[13] = (uint32_t)(int16_t)ld16(0x06063812u);  // 0606371A mov.w 0x06063812,r13
    c.r[13] += c.r[14];  // 0606371C add r14,r13
    st32(c.r[13], c.r[1]);  // 0606371E mov.l r1,@r13
L_06063720:
    c.r[9] = 0x0u;  // 06063720 mov #0,r9
L_06063722:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06063810u);  // 06063722 mov.w 0x06063810,r0
    st32(c.r[0] + c.r[14], c.r[9]);  // 06063724 mov.l r9,@(r0,r14)
    c.r[3] = ld32(0x0606382Cu);  // 06063726 mov.l 0x0606382C,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x06063816u);  // 06063728 mov.w 0x06063816,r1
    c.r[2] = ld32(c.r[3]);  // 0606372A mov.l @r3,r2
    c.r[9] = (uint32_t)(int16_t)ld16(0x06063810u);  // 0606372C mov.w 0x06063810,r9
    c.r[0] = c.r[2];  // 0606372E mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06063730 mov.b @(r0,r1),r1
    c.r[9] += c.r[14];  // 06063732 add r14,r9
    c.r[9] = ld32(c.r[9]);  // 06063734 mov.l @r9,r9
    c.r[1] = c.r[1] & 0xFFu;  // 06063736 extu.b r1,r1
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[1];  // 06063738 cmp/ge r1,r9
    if (!c.t) { goto L_06063740; }  // 0606373A bf 0x06063740
    goto L_06063FB2;  // 0606373C bra 0x06063FB2 ; nop
L_06063740:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06063818u);  // 06063740 mov.w 0x06063818,r0
    c.r[13] = (uint32_t)(int16_t)ld16(0x0606381Au);  // 06063742 mov.w 0x0606381A,r13
    c.r[13] += c.r[14];  // 06063744 add r14,r13
    st32(c.r[13], c.r[0]);  // 06063746 mov.l r0,@r13
L_06063748:
    c.r[9] = (uint32_t)(int16_t)ld16(0x06063810u);  // 06063748 mov.w 0x06063810,r9
    c.r[9] += c.r[14];  // 0606374A add r14,r9
    c.r[1] = ld32(c.r[9]);  // 0606374C mov.l @r9,r1
    c.r[13] = ld32(0x06063830u);  // 0606374E mov.l 0x06063830,r13
    c.r[2] = ld32(c.r[3]);  // 06063750 mov.l @r3,r2
    c.r[1] += c.r[1];  // 06063752 add r1,r1
    c.r[2] += c.r[1];  // 06063754 add r1,r2
    c.r[2] += 1;  // 06063756 add #1,r2
    c.r[9] = (uint32_t)(int16_t)ld16(0x0606381Au);  // 06063758 mov.w 0x0606381A,r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606375A mov.b @r2,r1
    c.r[9] += c.r[14];  // 0606375C add r14,r9
    c.r[10] = c.r[1] & 0xFFu;  // 0606375E extu.b r1,r10
    c.r[1] = (uint32_t)(int16_t)ld16(0x0606381Cu);  // 06063760 mov.w 0x0606381C,r1
    c.r[2] = ld32(c.r[13]);  // 06063762 mov.l @r13,r2
    c.macl = c.r[10] * c.r[1];  // 06063764 mul.l r1,r10
    c.r[0] = ld32(c.r[9]);  // 06063766 mov.l @r9,r0
    c.r[13] = ld32(0x06063834u);  // 06063768 mov.l 0x06063834,r13
    c.r[3] = c.macl;  // 0606376A sts macl,r3
    c.r[3] += c.r[2];  // 0606376C add r2,r3
    c.r[1] = 0x0u;  // 0606376E mov #0,r1
    st8(c.r[0] + c.r[3], c.r[1]);  // 06063770 mov.b r1,@(r0,r3)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 06063772 mov.b @r13,r1
    c.r[0] = ld32(0x06063838u);  // 06063774 mov.l 0x06063838,r0
    c.r[2] = ld32(c.r[0]);  // 06063776 mov.l @r0,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06063778 extu.b r1,r1
    c.r[1] <<= 2;  // 0606377A shll2 r1
    c.r[1] <<= 2;  // 0606377C shll2 r1
    c.r[1] += c.r[2];  // 0606377E add r2,r1
    c.r[1] += 7;  // 06063780 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06063782 mov.b @r1,r1
    c.r[9] = 0x1u;  // 06063784 mov #1,r9
    c.r[1] >>= 2;  // 06063786 shlr2 r1
    c.r[1] >>= 2;  // 06063788 shlr2 r1
    c.r[1] &= c.r[9];  // 0606378A and r9,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606378C tst r1,r1
    { const bool k = c.t; c.r[1] = c.r[10]; if (k) { goto L_060637C0; } }  // 0606378E bt/s 0x060637C0 ; mov r10,r1
    c.r[13] = ld32(0x0606383Cu);  // 06063792 mov.l 0x0606383C,r13
    c.r[1] <<= 2;  // 06063794 shll2 r1
    c.r[1] += c.r[10];  // 06063796 add r10,r1
    c.r[2] = ld32(c.r[13]);  // 06063798 mov.l @r13,r2
    c.r[1] <<= 2;  // 0606379A shll2 r1
    c.r[2] += c.r[1];  // 0606379C add r1,r2
    c.r[2] += 51;  // 0606379E add #51,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060637A0 mov.b @r2,r1
    c.r[1] >>= 2;  // 060637A2 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060637A4 shlr r1
    c.r[1] >>= 2;  // 060637A6 shlr2 r1
    c.r[1] &= c.r[9];  // 060637A8 and r9,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060637AA tst r1,r1
    if (!c.t) { goto L_060637C0; }  // 060637AC bf 0x060637C0
    c.r[1] = ld32(0x06063840u);  // 060637AE mov.l 0x06063840,r1
    c.r[1] = ld32(c.r[1]);  // 060637B0 mov.l @r1,r1
    c.r[1] += 1;  // 060637B2 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060637B4 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 060637B6 extu.b r1,r0
    c.t = c.r[0] == 0x5u;  // 060637B8 cmp/eq #5,r0
    if (c.t) { goto L_060637C0; }  // 060637BA bt 0x060637C0
    goto L_06063EBC;  // 060637BC bra 0x06063EBC ; nop
L_060637C0:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06063812u);  // 060637C0 mov.w 0x06063812,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 060637C2 mov.l @(r0,r14),r0
    c.r[12] = 0x0u;  // 060637C4 mov #0,r12
    c.t = (int32_t)c.r[12] >= (int32_t)c.r[0];  // 060637C6 cmp/ge r0,r12
    { const bool k = !c.t; c.r[13] = 0x0u; if (k) { goto L_060637D0; } }  // 060637C8 bf/s 0x060637D0 ; mov #0,r13
    goto L_06063EBC;  // 060637CC bra 0x06063EBC ; nop
L_060637D0:
    c.r[9] = (uint32_t)(int16_t)ld16(0x0606381Eu);  // 060637D0 mov.w 0x0606381E,r9
    c.r[9] += c.r[14];  // 060637D2 add r14,r9
    st32(c.r[9], c.r[13]);  // 060637D4 mov.l r13,@r9
L_060637D6:
    c.r[4] = ld32(0x06063844u);  // 060637D6 mov.l 0x06063844,r4
    c.r[0] = ld32(0x06063848u);  // 060637D8 mov.l 0x06063848,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060637DEu; c.r[5] = 0x22u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060637DEu) return; }  // 060637DA jsr @r0 ; mov #34,r5
    c.r[1] = c.r[0];  // 060637DE mov r0,r1
    c.r[5] = 0x1u;  // 060637E0 mov #1,r5
    c.r[9] = ld32(0x06063848u);  // 060637E2 mov.l 0x06063848,r9
    { const uint32_t x = c.r[9]; c.pr = 0x060637E8u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060637E8u) return; }  // 060637E4 jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 060637E8 mov r0,r1
    c.r[5] = 0x3u;  // 060637EA mov #3,r5
    { const uint32_t x = c.r[9]; c.pr = 0x060637F0u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060637F0u) return; }  // 060637EC jsr @r9 ; mov r1,r4
    c.r[6] = c.r[0];  // 060637F0 mov r0,r6
    c.r[1] = c.r[14];  // 060637F2 mov r14,r1
    c.r[1] += 1;  // 060637F4 add #1,r1
    c.r[9] = (uint32_t)(int16_t)ld16(0x0606381Eu);  // 060637F6 mov.w 0x0606381E,r9
    c.r[9] += c.r[14];  // 060637F8 add r14,r9
    c.r[13] = (uint32_t)(int16_t)ld16(0x0606381Eu);  // 060637FA mov.w 0x0606381E,r13
    c.r[13] += c.r[14];  // 060637FC add r14,r13
    c.r[5] = 0x22u;  // 060637FE mov #34,r5
    c.r[0] = ld32(c.r[9]);  // 06063800 mov.l @r9,r0
    c.r[4] = ld32(0x06063844u);  // 06063802 mov.l 0x06063844,r4
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06063804 mov.b @(r0,r1),r2
    c.r[9] = (uint32_t)(int16_t)ld16(0x06063820u);  // 06063806 mov.w 0x06063820,r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 06063808 mov.b @(r0,r14),r1
    c.r[2] = c.r[2] & 0xFFu;  // 0606380A extu.b r2,r2
    c.r[3] = c.r[1] & 0xFFu; goto L_0606384C;  // 0606380C bra 0x0606384C ; extu.b r1,r3
L_0606384C:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06063A06u);  // 0606384C mov.w 0x06063A06,r0
    st32(c.r[0] + c.r[14], c.r[9]);  // 0606384E mov.l r9,@(r0,r14)
    c.r[9] = (uint32_t)(int16_t)ld16(0x06063A06u);  // 06063850 mov.w 0x06063A06,r9
    c.r[9] += c.r[14];  // 06063852 add r14,r9
    c.r[13] = ld32(c.r[9]);  // 06063854 mov.l @r9,r13
    c.r[0] = ld32(0x06063A10u);  // 06063856 mov.l 0x06063A10,r0
    c.r[1] = ld32(c.r[0] + c.r[13]);  // 06063858 mov.l @(r0,r13),r1
    c.r[9] = (uint32_t)(int16_t)ld16(0x06063A08u);  // 0606385A mov.w 0x06063A08,r9
    c.r[0] = 0x40u;  // 0606385C mov #64,r0
    c.macl = c.r[2] * c.r[0];  // 0606385E mul.l r0,r2
    c.r[9] += c.r[14];  // 06063860 add r14,r9
    c.r[13] = (uint32_t)(int16_t)ld16(0x06063A0Au);  // 06063862 mov.w 0x06063A0A,r13
    c.r[2] = c.macl;  // 06063864 sts macl,r2
    c.r[2] += c.r[1];  // 06063866 add r1,r2
    c.r[0] = c.r[2];  // 06063868 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0606386A mov.b @(r0,r3),r1
    c.r[13] += c.r[14];  // 0606386C add r14,r13
    c.r[1] = c.r[1] & 0xFFu;  // 0606386E extu.b r1,r1
    c.r[0] = c.r[6];  // 06063870 mov r6,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06063872 mov.b @(r0,r1),r1
    c.r[2] = c.macl;  // 06063874 sts macl,r2
    c.r[0] = c.r[1];  // 06063876 mov r1,r0
    c.r[0] &= 0x40u;  // 06063878 and #64,r0
    st32(c.r[9], c.r[0]);  // 0606387A mov.l r0,@r9
    c.r[1] = ld32(0x06063A14u);  // 0606387C mov.l 0x06063A14,r1
    c.r[1] = ld32(c.r[1]);  // 0606387E mov.l @r1,r1
    c.r[2] += c.r[1];  // 06063880 add r1,r2
    c.r[0] = c.r[2];  // 06063882 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06063884 mov.b @(r0,r3),r1
    c.r[9] = ld32(0x06063A18u);  // 06063886 mov.l 0x06063A18,r9
    c.r[11] = c.r[1] & 0xFFu;  // 06063888 extu.b r1,r11
    c.r[8] = c.r[11];  // 0606388A mov r11,r8
    c.r[1] = ld32(c.r[9]);  // 0606388C mov.l @r9,r1
    c.r[8] <<= 2;  // 0606388E shll2 r8
    c.r[8] <<= 2;  // 06063890 shll2 r8
    c.r[1] += c.r[8];  // 06063892 add r8,r1
    c.r[1] += 3;  // 06063894 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06063896 mov.b @r1,r1
    c.r[9] = (uint32_t)(int16_t)ld16(0x06063A0Au);  // 06063898 mov.w 0x06063A0A,r9
    c.r[0] = c.r[1];  // 0606389A mov r1,r0
    c.r[0] >>= 2;  // 0606389C shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0606389E shlr r0
    st32(c.r[13], c.r[0]);  // 060638A0 mov.l r0,@r13
    c.r[0] = (uint32_t)(int16_t)ld16(0x06063A0Au);  // 060638A2 mov.w 0x06063A0A,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 060638A4 mov.l @(r0,r14),r0
    c.r[9] += c.r[14];  // 060638A6 add r14,r9
    c.r[0] &= 0x3u;  // 060638A8 and #3,r0
    st32(c.r[9], c.r[0]);  // 060638AA mov.l r0,@r9
    c.r[9] = ld32(0x06063A1Cu);  // 060638AC mov.l 0x06063A1C,r9
    { const uint32_t x = c.r[9]; c.pr = 0x060638B2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060638B2u) return; }  // 060638AE jsr @r9 ; nop
    c.r[1] = c.r[0];  // 060638B2 mov r0,r1
    c.r[5] = 0x0u;  // 060638B4 mov #0,r5
    { const uint32_t x = c.r[9]; c.pr = 0x060638BAu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060638BAu) return; }  // 060638B6 jsr @r9 ; mov r1,r4
    c.r[3] = c.r[0];  // 060638BA mov r0,r3
    c.r[13] = ld32(0x06063A20u);  // 060638BC mov.l 0x06063A20,r13
    c.r[0] = (uint32_t)(int16_t)ld16(0x06063A0Au);  // 060638BE mov.w 0x06063A0A,r0
    c.r[0] += c.r[14];  // 060638C0 add r14,r0
    c.r[9] = (uint32_t)(int16_t)ld16(0x06063A0Cu);  // 060638C2 mov.w 0x06063A0C,r9
    c.r[9] += c.r[14];  // 060638C4 add r14,r9
    c.r[1] = ld32(c.r[13]);  // 060638C6 mov.l @r13,r1
    c.r[5] = 0x22u;  // 060638C8 mov #34,r5
    c.r[1] += 37;  // 060638CA add #37,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060638CC mov.b @r1,r1
    c.r[4] = ld32(0x06063A24u);  // 060638CE mov.l 0x06063A24,r4
    c.r[0] = ld32(c.r[0]);  // 060638D0 mov.l @r0,r0
    c.r[1] = c.r[1] & 0xFFu;  // 060638D2 extu.b r1,r1
    c.r[1] >>= 2;  // 060638D4 shlr2 r1
    c.r[1] >>= 2;  // 060638D6 shlr2 r1
    c.r[2] = c.r[1];  // 060638D8 mov r1,r2
    c.r[2] <<= 2;  // 060638DA shll2 r2
    c.r[2] += c.r[1];  // 060638DC add r1,r2
    c.r[2] += c.r[3];  // 060638DE add r3,r2
    c.r[2] += c.r[0];  // 060638E0 add r0,r2
    c.r[2] += 2;  // 060638E2 add #2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060638E4 mov.b @r2,r1
    c.r[13] = ld32(0x06063A1Cu);  // 060638E6 mov.l 0x06063A1C,r13
    c.r[1] = c.r[1] & 0xFFu;  // 060638E8 extu.b r1,r1
    { const uint32_t x = c.r[13]; c.pr = 0x060638EEu; st32(c.r[9], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060638EEu) return; }  // 060638EA jsr @r13 ; mov.l r1,@r9
    c.r[1] = c.r[0];  // 060638EE mov r0,r1
    c.r[5] = 0x1u;  // 060638F0 mov #1,r5
    { const uint32_t x = c.r[13]; c.pr = 0x060638F6u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060638F6u) return; }  // 060638F2 jsr @r13 ; mov r1,r4
    c.r[1] = c.r[0];  // 060638F6 mov r0,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06063A0Cu);  // 060638F8 mov.w 0x06063A0C,r0
    c.r[5] = ld32(c.r[0] + c.r[14]);  // 060638FA mov.l @(r0,r14),r5
    { const uint32_t x = c.r[13]; c.pr = 0x06063900u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06063900u) return; }  // 060638FC jsr @r13 ; mov r1,r4
    c.r[6] = c.r[0];  // 06063900 mov r0,r6
    c.r[9] = (uint32_t)(int16_t)ld16(0x06063A0Cu);  // 06063902 mov.w 0x06063A0C,r9
    c.r[9] += c.r[14];  // 06063904 add r14,r9
    c.r[9] = ld32(c.r[9]);  // 06063906 mov.l @r9,r9
    c.t = (c.r[9] & c.r[9]) == 0;  // 06063908 tst r9,r9
    { const bool k = c.t; c.r[7] = 0x0u; if (k) { goto L_06063944; } }  // 0606390A bt/s 0x06063944 ; mov #0,r7
    c.r[13] = ld32(0x06063A18u);  // 0606390E mov.l 0x06063A18,r13
    c.r[1] = c.r[8];  // 06063910 mov r8,r1
    c.r[3] = ld32(c.r[13]);  // 06063912 mov.l @r13,r3
    c.r[0] = c.r[8];  // 06063914 mov r8,r0
    c.r[1] += c.r[3];  // 06063916 add r3,r1
    c.r[1] += 1;  // 06063918 add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606391A mov.b @r1,r2
    c.r[9] = (uint32_t)(int16_t)ld16(0x06063A06u);  // 0606391C mov.w 0x06063A06,r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0606391E mov.b @(r0,r3),r1
    c.r[9] += c.r[14];  // 06063920 add r14,r9
    c.r[13] = ld32(c.r[9]);  // 06063922 mov.l @r9,r13
    c.r[3] = c.r[1] & 0xFFu;  // 06063924 extu.b r1,r3
    c.r[0] = ld32(0x06063A10u);  // 06063926 mov.l 0x06063A10,r0
    c.r[1] = ld32(c.r[0] + c.r[13]);  // 06063928 mov.l @(r0,r13),r1
    c.r[2] = c.r[2] & 0xFFu;  // 0606392A extu.b r2,r2
    c.r[0] = 0x40u;  // 0606392C mov #64,r0
    c.macl = c.r[2] * c.r[0];  // 0606392E mul.l r0,r2
    c.r[2] = c.macl;  // 06063930 sts macl,r2
    c.r[2] += c.r[1];  // 06063932 add r1,r2
    c.r[0] = c.r[2];  // 06063934 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06063936 mov.b @(r0,r3),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06063938 extu.b r1,r1
    c.r[0] = c.r[6];  // 0606393A mov r6,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0606393C mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606393E extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06063940 tst r1,r1
    if (!c.t) { goto L_06063946; }  // 06063942 bf 0x06063946
L_06063944:
    c.r[7] = 0x1u;  // 06063944 mov #1,r7
L_06063946:
    c.r[9] = (uint32_t)(int16_t)ld16(0x06063A0Cu);  // 06063946 mov.w 0x06063A0C,r9
    c.r[9] += c.r[14];  // 06063948 add r14,r9
    st32(c.r[9], c.r[7]);  // 0606394A mov.l r7,@r9
    c.r[13] = ld32(0x06063A20u);  // 0606394C mov.l 0x06063A20,r13
    c.r[9] = c.r[10];  // 0606394E mov r10,r9
    c.r[9] <<= 2;  // 06063950 shll2 r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06063A06u);  // 06063952 mov.w 0x06063A06,r0
    c.r[0] += c.r[14];  // 06063954 add r14,r0
    c.r[1] = ld32(c.r[13]);  // 06063956 mov.l @r13,r1
    c.r[5] = 0x1Du;  // 06063958 mov #29,r5
    st32(c.r[0], c.r[9]);  // 0606395A mov.l r9,@r0
    c.r[13] = (uint32_t)(int16_t)ld16(0x06063A06u);  // 0606395C mov.w 0x06063A06,r13
    c.r[13] += c.r[14];  // 0606395E add r14,r13
    c.r[9] = (uint32_t)(int16_t)ld16(0x06063A06u);  // 06063960 mov.w 0x06063A06,r9
    c.r[0] = ld32(c.r[13]);  // 06063962 mov.l @r13,r0
    c.r[9] += c.r[14];  // 06063964 add r14,r9
    c.r[0] += c.r[10];  // 06063966 add r10,r0
    st32(c.r[13], c.r[0]);  // 06063968 mov.l r0,@r13
    c.r[0] = (uint32_t)(int16_t)ld16(0x06063A06u);  // 0606396A mov.w 0x06063A06,r0
    c.r[13] = ld32(c.r[9]);  // 0606396C mov.l @r9,r13
    c.r[0] += c.r[14];  // 0606396E add r14,r0
    c.r[13] <<= 2;  // 06063970 shll2 r13
    st32(c.r[9], c.r[13]);  // 06063972 mov.l r13,@r9
    c.r[0] = ld32(c.r[0]);  // 06063974 mov.l @r0,r0
    c.r[4] = ld32(0x06063A24u);  // 06063976 mov.l 0x06063A24,r4
    c.r[1] += c.r[0];  // 06063978 add r0,r1
    c.r[1] += 44;  // 0606397A add #44,r1
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606397C mov.w @r1,r8
    c.r[9] = ld32(0x06063A1Cu);  // 0606397E mov.l 0x06063A1C,r9
    { const uint32_t x = c.r[9]; c.pr = 0x06063984u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06063984u) return; }  // 06063980 jsr @r9 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 06063984 mov r0,r1
    c.r[5] = c.r[8];  // 06063986 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x0606398Cu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606398Cu) return; }  // 06063988 jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 0606398C mov r0,r1
    c.r[0] = 0x3Fu;  // 0606398E mov #63,r0
    c.r[13] = (uint32_t)(int16_t)ld16(0x06063A0Eu);  // 06063990 mov.w 0x06063A0E,r13
    c.r[13] += c.r[14];  // 06063992 add r14,r13
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06063994 mov.b @r1,r1
    c.r[9] = ld32(0x06063A20u);  // 06063996 mov.l 0x06063A20,r9
    c.r[0] &= c.r[1];  // 06063998 and r1,r0
    st32(c.r[13], c.r[0]);  // 0606399A mov.l r0,@r13
    c.r[13] = (uint32_t)(int16_t)ld16(0x06063A06u);  // 0606399C mov.w 0x06063A06,r13
    c.r[5] = ld32(c.r[9]);  // 0606399E mov.l @r9,r5
    c.r[13] += c.r[14];  // 060639A0 add r14,r13
    c.r[2] = ld32(c.r[13]);  // 060639A2 mov.l @r13,r2
    c.r[2] += c.r[5];  // 060639A4 add r5,r2
    c.r[1] = c.r[2];  // 060639A6 mov r2,r1
    c.r[1] += 50;  // 060639A8 add #50,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060639AA mov.b @r1,r1
    c.r[3] = c.r[1] & 0xFFu;  // 060639AC extu.b r1,r3
    c.r[3] >>= 2;  // 060639AE shlr2 r3
    c.r[3] >>= 2;  // 060639B0 shlr2 r3
    c.r[3] >>= 2;  // 060639B2 shlr2 r3
    c.r[0] = c.r[3];  // 060639B4 mov r3,r0
    c.t = c.r[0] == 0x3u;  // 060639B6 cmp/eq #3,r0
    { const bool k = c.t; c.r[1] = 0x1u; if (k) { goto L_060639C0; } }  // 060639B8 bt/s 0x060639C0 ; mov #1,r1
    goto L_06063B18;  // 060639BC bra 0x06063B18 ; nop
L_060639C0:
    c.r[1] = ld32(0x06063A28u);  // 060639C0 mov.l 0x06063A28,r1
    c.r[1] = ld32(c.r[1]);  // 060639C2 mov.l @r1,r1
    c.r[1] += 1;  // 060639C4 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060639C6 mov.b @r1,r1
    c.r[3] = c.r[1] & 0xFFu;  // 060639C8 extu.b r1,r3
    c.r[0] = c.r[3];  // 060639CA mov r3,r0
    c.t = c.r[0] == 0x5u;  // 060639CC cmp/eq #5,r0
    { const bool k = !c.t; c.r[0] = 0x3u; if (k) { goto L_060639D6; } }  // 060639CE bf/s 0x060639D6 ; mov #3,r0
    goto L_06063EA2;  // 060639D2 bra 0x06063EA2 ; nop
L_060639D6:
    c.r[9] = ld32(0x06063A2Cu);  // 060639D6 mov.l 0x06063A2C,r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 060639D8 mov.b @r9,r1
    c.r[13] = ld32(0x06063A18u);  // 060639DA mov.l 0x06063A18,r13
    c.r[2] = ld32(c.r[13]);  // 060639DC mov.l @r13,r2
    c.r[4] = c.r[1] & 0xFFu;  // 060639DE extu.b r1,r4
    c.r[1] = c.r[4];  // 060639E0 mov r4,r1
    c.r[1] <<= 2;  // 060639E2 shll2 r1
    c.r[1] <<= 2;  // 060639E4 shll2 r1
    c.r[1] += c.r[2];  // 060639E6 add r2,r1
    c.r[1] += 3;  // 060639E8 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060639EA mov.b @r1,r1
    c.r[7] = c.r[1];  // 060639EC mov r1,r7
    c.t = c.r[7] & 1; c.r[7] >>= 1;  // 060639EE shlr r7
    c.r[1] = c.r[11];  // 060639F0 mov r11,r1
    c.r[1] <<= 2;  // 060639F2 shll2 r1
    c.r[1] <<= 2;  // 060639F4 shll2 r1
    c.r[1] += c.r[2];  // 060639F6 add r2,r1
    c.r[1] += 3;  // 060639F8 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060639FA mov.b @r1,r1
    c.r[7] &= c.r[0];  // 060639FC and r0,r7
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060639FE shlr r1
    c.r[1] &= c.r[0];  // 06063A00 and r0,r1
    c.t = c.r[7] == c.r[1]; goto L_06063A30;  // 06063A02 bra 0x06063A30 ; cmp/eq r1,r7
L_06063A30:
    if (c.t) { goto L_06063A36; }  // 06063A30 bt 0x06063A36
    goto L_06063EA2;  // 06063A32 bra 0x06063EA2 ; nop
L_06063A36:
    c.r[9] = (uint32_t)(int16_t)ld16(0x06063AEEu);  // 06063A36 mov.w 0x06063AEE,r9
    c.r[9] += c.r[14];  // 06063A38 add r14,r9
    c.r[0] = ld32(c.r[9]);  // 06063A3A mov.l @r9,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 06063A3C mov.b @(r0,r14),r1
    c.r[0] = c.r[3];  // 06063A3E mov r3,r0
    c.t = c.r[0] == 0x6u;  // 06063A40 cmp/eq #6,r0
    { const bool k = !c.t; c.r[7] = c.r[1] & 0xFFu; if (k) { goto L_06063A52; } }  // 06063A42 bf/s 0x06063A52 ; extu.b r1,r7
    c.r[9] = (uint32_t)(int16_t)ld16(0x06063AF0u);  // 06063A46 mov.w 0x06063AF0,r9
    c.r[9] += c.r[14];  // 06063A48 add r14,r9
    c.r[1] = ld32(c.r[9]);  // 06063A4A mov.l @r9,r1
    c.r[1] += 2;  // 06063A4C add #2,r1
    c.r[1] = c.r[1] & 0xFFu; goto L_06063A5A;  // 06063A4E bra 0x06063A5A ; extu.b r1,r1
L_06063A52:
    c.r[13] = (uint32_t)(int16_t)ld16(0x06063AF2u);  // 06063A52 mov.w 0x06063AF2,r13
    c.r[13] += c.r[14];  // 06063A54 add r14,r13
    c.r[13] = (uint32_t)(int8_t)ld8(c.r[13]);  // 06063A56 mov.b @r13,r13
    c.r[1] = c.r[13] & 0xFFu;  // 06063A58 extu.b r13,r1
L_06063A5A:
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06063A5A mov.l r1,@-r15
    c.r[0] = ld32(0x06063B00u);  // 06063A5C mov.l 0x06063B00,r0
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 06063A5E mov.l r0,@-r15
    c.r[1] = c.r[14];  // 06063A60 mov r14,r1
    c.r[1] += 1;  // 06063A62 add #1,r1
    c.r[9] = (uint32_t)(int16_t)ld16(0x06063AEEu);  // 06063A64 mov.w 0x06063AEE,r9
    c.r[9] += c.r[14];  // 06063A66 add r14,r9
    c.r[0] = ld32(c.r[9]);  // 06063A68 mov.l @r9,r0
    c.r[6] = c.r[10];  // 06063A6A mov r10,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06063A6C mov.b @(r0,r1),r1
    c.r[13] = ld32(0x06063B04u);  // 06063A6E mov.l 0x06063B04,r13
    c.r[1] = c.r[1] & 0xFFu;  // 06063A70 extu.b r1,r1
    { const uint32_t x = c.r[13]; c.pr = 0x06063A76u; c.r[15] -= 4; st32(c.r[15], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06063A76u) return; }  // 06063A72 jsr @r13 ; mov.l r1,@-r15
    c.r[1] = c.r[0];  // 06063A76 mov r0,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06063A78 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06063A7A tst r1,r1
    { const bool k = !c.t; c.r[15] += 12; if (k) { goto L_06063A84; } }  // 06063A7C bf/s 0x06063A84 ; add #12,r15
    goto L_06063EA2;  // 06063A80 bra 0x06063EA2 ; nop
L_06063A84:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06063AF4u);  // 06063A84 mov.w 0x06063AF4,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06063A86 mov.l @(r0,r14),r0
    c.t = c.r[0] == 0x2u;  // 06063A88 cmp/eq #2,r0
    { const bool k = !c.t; c.r[2] = c.r[11]; if (k) { goto L_06063A92; } }  // 06063A8A bf/s 0x06063A92 ; mov r11,r2
    goto L_06063EA2;  // 06063A8E bra 0x06063EA2 ; nop
L_06063A92:
    c.r[9] = ld32(0x06063B08u);  // 06063A92 mov.l 0x06063B08,r9
    c.r[2] <<= 2;  // 06063A94 shll2 r2
    c.r[2] <<= 2;  // 06063A96 shll2 r2
    c.r[8] = (uint32_t)(int16_t)ld16(0x06063AF6u);  // 06063A98 mov.w 0x06063AF6,r8
    c.r[8] += c.r[14];  // 06063A9A add r14,r8
    c.r[6] = (uint32_t)(int16_t)ld16(0x06063AF8u);  // 06063A9C mov.w 0x06063AF8,r6
    c.r[1] = ld32(c.r[9]);  // 06063A9E mov.l @r9,r1
    c.r[4] = c.r[8];  // 06063AA0 mov r8,r4
    c.r[2] += c.r[1];  // 06063AA2 add r1,r2
    c.r[2] += 2;  // 06063AA4 add #2,r2
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06063AA6 mov.b @r2,r5
    c.r[1] = ld32(0x06063B0Cu);  // 06063AA8 mov.l 0x06063B0C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06063AAEu; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06063AAEu) return; }  // 06063AAA jsr @r1 ; extu.b r5,r5
    c.r[0] = (uint32_t)(int16_t)ld16(0x06063AFAu);  // 06063AAE mov.w 0x06063AFA,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06063AB0 mov.l @(r0,r14),r0
    c.t = c.r[0] == 0x3Fu;  // 06063AB2 cmp/eq #63,r0
    if (!c.t) { goto L_06063AC0; }  // 06063AB4 bf 0x06063AC0
    c.r[0] = ld32(0x06063B10u);  // 06063AB6 mov.l 0x06063B10,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06063ABCu; c.r[4] = c.r[11]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06063ABCu) return; }  // 06063AB8 jsr @r0 ; mov r11,r4
    c.t = c.r[0] == 0xFFFFFFFFu;  // 06063ABC cmp/eq #-1,r0
    if (!c.t) { goto L_06063AE2; }  // 06063ABE bf 0x06063AE2
L_06063AC0:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06063AFAu);  // 06063AC0 mov.w 0x06063AFA,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06063AC2 mov.l @(r0,r14),r0
    c.t = c.r[0] == 0x3Eu;  // 06063AC4 cmp/eq #62,r0
    { const bool k = c.t; c.r[1] = c.r[8]; if (k) { goto L_06063ACE; } }  // 06063AC6 bt/s 0x06063ACE ; mov r8,r1
    goto L_06063EA2;  // 06063ACA bra 0x06063EA2 ; nop
L_06063ACE:
    c.r[1] += 22;  // 06063ACE add #22,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06063AD0 mov.w @r1,r2
    c.r[8] += 26;  // 06063AD2 add #26,r8
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06063AD4 mov.w @r8,r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 06063AD6 extu.w r2,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 06063AD8 extu.w r1,r1
    c.t = c.r[2] == c.r[1];  // 06063ADA cmp/eq r1,r2
    if (!c.t) { goto L_06063AE2; }  // 06063ADC bf 0x06063AE2
    goto L_06063EA2;  // 06063ADE bra 0x06063EA2 ; nop
L_06063AE2:
    c.r[9] = ld32(0x06063B14u);  // 06063AE2 mov.l 0x06063B14,r9
    c.r[1] = (uint32_t)(int16_t)ld16(0x06063AFCu);  // 06063AE4 mov.w 0x06063AFC,r1
    c.r[2] = ld32(c.r[9]);  // 06063AE6 mov.l @r9,r2
    c.r[9] = (uint32_t)(int16_t)ld16(0x06063AFEu);  // 06063AE8 mov.w 0x06063AFE,r9
    c.macl = c.r[10] * c.r[1]; goto L_06063D9C;  // 06063AEA bra 0x06063D9C ; mul.l r1,r10
L_06063B18:
    c.t = c.r[3] > c.r[1];  // 06063B18 cmp/hi r1,r3
    { const bool k = !c.t; c.r[0] = c.r[3]; if (k) { goto L_06063B30; } }  // 06063B1A bf/s 0x06063B30 ; mov r3,r0
    c.t = c.r[0] == 0x2u;  // 06063B1E cmp/eq #2,r0
    { const bool k = !c.t; c.r[2] += 51; if (k) { goto L_06063B74; } }  // 06063B20 bf/s 0x06063B74 ; add #51,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06063B24 mov.b @r2,r1
    c.r[0] = c.r[1];  // 06063B26 mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06063B28 shlr r0
    c.r[0] &= 0x1u;  // 06063B2A and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06063B2C tst r0,r0
    if (c.t) { goto L_06063B74; }  // 06063B2E bt 0x06063B74
L_06063B30:
    c.r[9] = ld32(0x06063BE0u);  // 06063B30 mov.l 0x06063BE0,r9
    c.r[13] = ld32(0x06063BE4u);  // 06063B32 mov.l 0x06063BE4,r13
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06063B34 mov.b @r9,r1
    c.r[0] = 0xFu;  // 06063B36 mov #15,r0
    c.r[2] = ld32(c.r[13]);  // 06063B38 mov.l @r13,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06063B3A extu.b r1,r1
    c.r[1] <<= 2;  // 06063B3C shll2 r1
    c.r[1] <<= 2;  // 06063B3E shll2 r1
    c.r[1] += c.r[2];  // 06063B40 add r2,r1
    c.r[1] += 4;  // 06063B42 add #4,r1
    c.r[9] = 0x3u;  // 06063B44 mov #3,r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06063B46 mov.b @r1,r1
    c.r[13] = ld32(0x06063BE8u);  // 06063B48 mov.l 0x06063BE8,r13
    c.r[3] = c.r[1];  // 06063B4A mov r1,r3
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 06063B4C shlr r3
    c.r[3] &= c.r[0];  // 06063B4E and r0,r3
    c.r[1] = c.r[11];  // 06063B50 mov r11,r1
    c.r[1] <<= 2;  // 06063B52 shll2 r1
    c.r[1] <<= 2;  // 06063B54 shll2 r1
    c.r[1] += c.r[2];  // 06063B56 add r2,r1
    c.r[1] += 3;  // 06063B58 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06063B5A mov.b @r1,r1
    c.r[4] = c.r[3];  // 06063B5C mov r3,r4
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06063B5E shlr r1
    c.r[1] &= c.r[9];  // 06063B60 and r9,r1
    { const uint32_t x = c.r[13]; c.pr = 0x06063B66u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06063B66u) return; }  // 06063B62 jsr @r13 ; mov r1,r5
    c.r[1] = c.r[0];  // 06063B66 mov r0,r1
    c.r[0] = 0x1u;  // 06063B68 mov #1,r0
    c.r[1] &= c.r[0];  // 06063B6A and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06063B6C tst r1,r1
    if (!c.t) { goto L_06063B74; }  // 06063B6E bf 0x06063B74
    goto L_06063EA2;  // 06063B70 bra 0x06063EA2 ; nop
L_06063B74:
    c.r[1] = ld32(0x06063BECu);  // 06063B74 mov.l 0x06063BEC,r1
    c.r[1] = ld32(c.r[1]);  // 06063B76 mov.l @r1,r1
    c.r[1] += 1;  // 06063B78 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06063B7A mov.b @r1,r1
    c.r[3] = c.r[1] & 0xFFu;  // 06063B7C extu.b r1,r3
    c.r[0] = c.r[3];  // 06063B7E mov r3,r0
    c.t = c.r[0] == 0x5u;  // 06063B80 cmp/eq #5,r0
    { const bool k = !c.t; c.r[1] = c.r[10]; if (k) { goto L_06063BB6; } }  // 06063B82 bf/s 0x06063BB6 ; mov r10,r1
    c.r[9] = ld32(0x06063BF0u);  // 06063B86 mov.l 0x06063BF0,r9
    c.r[1] <<= 2;  // 06063B88 shll2 r1
    c.r[1] += c.r[10];  // 06063B8A add r10,r1
    c.r[2] = ld32(c.r[9]);  // 06063B8C mov.l @r9,r2
    c.r[1] <<= 2;  // 06063B8E shll2 r1
    c.r[2] += c.r[1];  // 06063B90 add r1,r2
    c.r[2] += 50;  // 06063B92 add #50,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06063B94 mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06063B96 extu.b r1,r1
    c.r[1] >>= 2;  // 06063B98 shlr2 r1
    c.r[1] >>= 2;  // 06063B9A shlr2 r1
    c.r[1] >>= 2;  // 06063B9C shlr2 r1
    c.r[0] = c.r[1];  // 06063B9E mov r1,r0
    c.t = c.r[0] == 0x2u;  // 06063BA0 cmp/eq #2,r0
    if (!c.t) { goto L_06063BA8; }  // 06063BA2 bf 0x06063BA8
    goto L_06063EA2;  // 06063BA4 bra 0x06063EA2 ; nop
L_06063BA8:
    c.r[1] = ld32(0x06063BF4u);  // 06063BA8 mov.l 0x06063BF4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06063BAA mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06063BAC extu.b r1,r1
    c.t = c.r[11] == c.r[1];  // 06063BAE cmp/eq r1,r11
    if (c.t) { goto L_06063BB6; }  // 06063BB0 bt 0x06063BB6
    goto L_06063EA2;  // 06063BB2 bra 0x06063EA2 ; nop
L_06063BB6:
    c.r[9] = (uint32_t)(int16_t)ld16(0x06063BDCu);  // 06063BB6 mov.w 0x06063BDC,r9
    c.r[9] += c.r[14];  // 06063BB8 add r14,r9
    c.r[0] = ld32(c.r[9]);  // 06063BBA mov.l @r9,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 06063BBC mov.b @(r0,r14),r1
    c.r[7] = c.r[1] & 0xFFu;  // 06063BBE extu.b r1,r7
    c.r[0] = ld32(0x06063BE0u);  // 06063BC0 mov.l 0x06063BE0,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06063BC2 mov.b @r0,r1
    c.r[13] = ld32(0x06063BF0u);  // 06063BC4 mov.l 0x06063BF0,r13
    c.r[5] = ld32(c.r[13]);  // 06063BC6 mov.l @r13,r5
    c.r[0] = c.r[3];  // 06063BC8 mov r3,r0
    c.t = c.r[0] == 0x6u;  // 06063BCA cmp/eq #6,r0
    { const bool k = !c.t; c.r[4] = c.r[1] & 0xFFu; if (k) { goto L_06063BF8; } }  // 06063BCC bf/s 0x06063BF8 ; extu.b r1,r4
    c.r[9] = (uint32_t)(int16_t)ld16(0x06063BDEu);  // 06063BD0 mov.w 0x06063BDE,r9
    c.r[9] += c.r[14];  // 06063BD2 add r14,r9
    c.r[1] = ld32(c.r[9]);  // 06063BD4 mov.l @r9,r1
    c.r[1] += 2;  // 06063BD6 add #2,r1
    c.r[1] = c.r[1] & 0xFFu; goto L_06063C00;  // 06063BD8 bra 0x06063C00 ; extu.b r1,r1
L_06063BF8:
    c.r[13] = (uint32_t)(int16_t)ld16(0x06063D42u);  // 06063BF8 mov.w 0x06063D42,r13
    c.r[13] += c.r[14];  // 06063BFA add r14,r13
    c.r[13] = (uint32_t)(int8_t)ld8(c.r[13]);  // 06063BFC mov.b @r13,r13
    c.r[1] = c.r[13] & 0xFFu;  // 06063BFE extu.b r13,r1
L_06063C00:
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 06063C00 mov.l r1,@-r15
    c.r[0] = ld32(0x06063D50u);  // 06063C02 mov.l 0x06063D50,r0
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 06063C04 mov.l r0,@-r15
    c.r[1] = c.r[14];  // 06063C06 mov r14,r1
    c.r[1] += 1;  // 06063C08 add #1,r1
    c.r[9] = (uint32_t)(int16_t)ld16(0x06063D44u);  // 06063C0A mov.w 0x06063D44,r9
    c.r[9] += c.r[14];  // 06063C0C add r14,r9
    c.r[0] = ld32(c.r[9]);  // 06063C0E mov.l @r9,r0
    c.r[6] = c.r[10];  // 06063C10 mov r10,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06063C12 mov.b @(r0,r1),r1
    c.r[13] = ld32(0x06063D54u);  // 06063C14 mov.l 0x06063D54,r13
    c.r[1] = c.r[1] & 0xFFu;  // 06063C16 extu.b r1,r1
    { const uint32_t x = c.r[13]; c.pr = 0x06063C1Cu; c.r[15] -= 4; st32(c.r[15], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06063C1Cu) return; }  // 06063C18 jsr @r13 ; mov.l r1,@-r15
    c.r[1] = c.r[0];  // 06063C1C mov r0,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06063C1E extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06063C20 tst r1,r1
    { const bool k = !c.t; c.r[15] += 12; if (k) { goto L_06063C2A; } }  // 06063C22 bf/s 0x06063C2A ; add #12,r15
    goto L_06063EA2;  // 06063C26 bra 0x06063EA2 ; nop
L_06063C2A:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06063D46u);  // 06063C2A mov.w 0x06063D46,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06063C2C mov.l @(r0,r14),r0
    c.t = c.r[0] == 0x2u;  // 06063C2E cmp/eq #2,r0
    if (!c.t) { goto L_06063C36; }  // 06063C30 bf 0x06063C36
    goto L_06063EA2;  // 06063C32 bra 0x06063EA2 ; nop
L_06063C36:
    c.r[8] = c.r[10];  // 06063C36 mov r10,r8
    c.r[9] = ld32(0x06063D58u);  // 06063C38 mov.l 0x06063D58,r9
    c.r[8] <<= 2;  // 06063C3A shll2 r8
    c.r[8] += c.r[10];  // 06063C3C add r10,r8
    c.r[1] = ld32(c.r[9]);  // 06063C3E mov.l @r9,r1
    c.r[8] <<= 2;  // 06063C40 shll2 r8
    c.r[1] += c.r[8];  // 06063C42 add r8,r1
    c.r[1] += 56;  // 06063C44 add #56,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06063C46 mov.b @r1,r1
    c.r[13] = 0x3u;  // 06063C48 mov #3,r13
    c.r[1] &= c.r[13];  // 06063C4A and r13,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06063C4C tst r1,r1
    { const bool k = !c.t; c.r[4] = 0x1u; if (k) { goto L_06063C86; } }  // 06063C4E bf/s 0x06063C86 ; mov #1,r4
    c.r[1] = ld32(0x06063D5Cu);  // 06063C52 mov.l 0x06063D5C,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06063C54 mov.b @r1,r0
    c.r[1] = 0xFu;  // 06063C56 mov #15,r1
    c.r[1] &= c.r[0];  // 06063C58 and r0,r1
    c.r[0] = ld32(0x06063D60u);  // 06063C5A mov.l 0x06063D60,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06063C60u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06063C60u) return; }  // 06063C5C jsr @r0 ; mov r1,r5
    c.r[4] = (uint32_t)(int16_t)ld16(0x06063D48u);  // 06063C60 mov.w 0x06063D48,r4
    c.r[1] = ld32(0x06063D64u);  // 06063C62 mov.l 0x06063D64,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06063C68u; c.r[4] &= c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06063C68u) return; }  // 06063C64 jsr @r1 ; and r0,r4
    c.r[2] = c.r[4];  // 06063C68 mov r4,r2
    c.r[4] = (uint32_t)(int16_t)ld16(0x06063D4Au);  // 06063C6A mov.w 0x06063D4A,r4
    c.r[1] = ld32(0x06063D68u);  // 06063C6C mov.l 0x06063D68,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06063C72u; c.r[4] &= c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06063C72u) return; }  // 06063C6E jsr @r1 ; and r0,r4
    c.r[2] |= c.r[4];  // 06063C72 or r4,r2
    c.r[0] &= 0x80u;  // 06063C74 and #128,r0
    c.r[1] = ld32(0x06063D6Cu);  // 06063C76 mov.l 0x06063D6C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06063C7Cu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06063C7Cu) return; }  // 06063C78 jsr @r1 ; mov r0,r4
    c.r[2] |= c.r[4];  // 06063C7C or r4,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06063C7E tst r2,r2
    if (c.t) { goto L_06063C86; }  // 06063C80 bt 0x06063C86
    goto L_06063EA2;  // 06063C82 bra 0x06063EA2 ; nop
L_06063C86:
    c.r[0] = ld32(0x06063D58u);  // 06063C86 mov.l 0x06063D58,r0
    c.r[1] = ld32(c.r[0]);  // 06063C88 mov.l @r0,r1
    c.r[1] += c.r[8];  // 06063C8A add r8,r1
    c.r[1] += 56;  // 06063C8C add #56,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06063C8E mov.b @r1,r1
    c.r[9] = 0x3u;  // 06063C90 mov #3,r9
    c.r[1] = c.r[1] & 0xFFu;  // 06063C92 extu.b r1,r1
    c.r[2] = c.r[1];  // 06063C94 mov r1,r2
    c.r[2] >>= 2;  // 06063C96 shlr2 r2
    c.r[2] &= c.r[9];  // 06063C98 and r9,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06063C9A tst r2,r2
    if (!c.t) { goto L_06063CAC; }  // 06063C9C bf 0x06063CAC
    c.r[13] = (uint32_t)(int16_t)ld16(0x06063D46u);  // 06063C9E mov.w 0x06063D46,r13
    c.r[13] += c.r[14];  // 06063CA0 add r14,r13
    c.r[13] = ld32(c.r[13]);  // 06063CA2 mov.l @r13,r13
    c.t = (c.r[13] & c.r[13]) == 0;  // 06063CA4 tst r13,r13
    if (!c.t) { goto L_06063CAC; }  // 06063CA6 bf 0x06063CAC
    goto L_06063EA2;  // 06063CA8 bra 0x06063EA2 ; nop
L_06063CAC:
    c.r[1] >>= 2;  // 06063CAC shlr2 r1
    c.r[1] >>= 2;  // 06063CAE shlr2 r1
    c.r[0] = 0x3u;  // 06063CB0 mov #3,r0
    c.r[1] &= c.r[0];  // 06063CB2 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06063CB4 tst r1,r1
    if (!c.t) { goto L_06063CCE; }  // 06063CB6 bf 0x06063CCE
    c.r[9] = (uint32_t)(int16_t)ld16(0x06063D4Cu);  // 06063CB8 mov.w 0x06063D4C,r9
    c.r[9] += c.r[14];  // 06063CBA add r14,r9
    c.r[9] = ld32(c.r[9]);  // 06063CBC mov.l @r9,r9
    c.t = (c.r[9] & c.r[9]) == 0;  // 06063CBE tst r9,r9
    if (c.t) { goto L_06063CCE; }  // 06063CC0 bt 0x06063CCE
    c.r[0] = (uint32_t)(int16_t)ld16(0x06063D46u);  // 06063CC2 mov.w 0x06063D46,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06063CC4 mov.l @(r0,r14),r0
    c.t = c.r[0] == 0x1u;  // 06063CC6 cmp/eq #1,r0
    if (!c.t) { goto L_06063CCE; }  // 06063CC8 bf 0x06063CCE
    goto L_06063EA2;  // 06063CCA bra 0x06063EA2 ; nop
L_06063CCE:
    c.r[9] = ld32(0x06063D58u);  // 06063CCE mov.l 0x06063D58,r9
    c.r[1] = c.r[10];  // 06063CD0 mov r10,r1
    c.r[1] <<= 2;  // 06063CD2 shll2 r1
    c.r[1] += c.r[10];  // 06063CD4 add r10,r1
    c.r[2] = ld32(c.r[9]);  // 06063CD6 mov.l @r9,r2
    c.r[1] <<= 2;  // 06063CD8 shll2 r1
    c.r[2] += c.r[1];  // 06063CDA add r1,r2
    c.r[2] += 56;  // 06063CDC add #56,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06063CDE mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06063CE0 extu.b r1,r1
    c.r[1] >>= 2;  // 06063CE2 shlr2 r1
    c.r[1] >>= 2;  // 06063CE4 shlr2 r1
    c.r[1] >>= 2;  // 06063CE6 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06063CE8 tst r1,r1
    if (!c.t) { goto L_06063D36; }  // 06063CEA bf 0x06063D36
    c.r[13] = (uint32_t)(int16_t)ld16(0x06063D4Cu);  // 06063CEC mov.w 0x06063D4C,r13
    c.r[13] += c.r[14];  // 06063CEE add r14,r13
    c.r[13] = ld32(c.r[13]);  // 06063CF0 mov.l @r13,r13
    c.t = (c.r[13] & c.r[13]) == 0;  // 06063CF2 tst r13,r13
    { const bool k = !c.t; c.r[4] = 0x1u; if (k) { goto L_06063D36; } }  // 06063CF4 bf/s 0x06063D36 ; mov #1,r4
    c.r[1] = ld32(0x06063D5Cu);  // 06063CF8 mov.l 0x06063D5C,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06063CFA mov.b @r1,r0
    c.r[1] = 0xFu;  // 06063CFC mov #15,r1
    c.r[1] &= c.r[0];  // 06063CFE and r0,r1
    c.r[0] = ld32(0x06063D60u);  // 06063D00 mov.l 0x06063D60,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06063D06u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06063D06u) return; }  // 06063D02 jsr @r0 ; mov r1,r5
    c.r[4] = (uint32_t)(int16_t)ld16(0x06063D48u);  // 06063D06 mov.w 0x06063D48,r4
    c.r[1] = ld32(0x06063D64u);  // 06063D08 mov.l 0x06063D64,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06063D0Eu; c.r[4] &= c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06063D0Eu) return; }  // 06063D0A jsr @r1 ; and r0,r4
    c.r[2] = c.r[4];  // 06063D0E mov r4,r2
    c.r[4] = (uint32_t)(int16_t)ld16(0x06063D4Au);  // 06063D10 mov.w 0x06063D4A,r4
    c.r[1] = ld32(0x06063D68u);  // 06063D12 mov.l 0x06063D68,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06063D18u; c.r[4] &= c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06063D18u) return; }  // 06063D14 jsr @r1 ; and r0,r4
    c.r[2] |= c.r[4];  // 06063D18 or r4,r2
    c.r[0] &= 0x80u;  // 06063D1A and #128,r0
    c.r[1] = ld32(0x06063D6Cu);  // 06063D1C mov.l 0x06063D6C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06063D22u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06063D22u) return; }  // 06063D1E jsr @r1 ; mov r0,r4
    c.r[2] |= c.r[4];  // 06063D22 or r4,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06063D24 tst r2,r2
    if (!c.t) { goto L_06063D34; }  // 06063D26 bf 0x06063D34
    c.r[0] = (uint32_t)(int16_t)ld16(0x06063D46u);  // 06063D28 mov.w 0x06063D46,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06063D2A mov.l @(r0,r14),r0
    c.t = c.r[0] == 0x1u;  // 06063D2C cmp/eq #1,r0
    if (!c.t) { goto L_06063D34; }  // 06063D2E bf 0x06063D34
    goto L_06063EA2;  // 06063D30 bra 0x06063EA2 ; nop
L_06063D34:
    c.r[9] = ld32(0x06063D58u);  // 06063D34 mov.l 0x06063D58,r9
L_06063D36:
    c.r[1] = c.r[10];  // 06063D36 mov r10,r1
    c.r[1] <<= 2;  // 06063D38 shll2 r1
    c.r[1] += c.r[10];  // 06063D3A add r10,r1
    c.r[2] = ld32(c.r[9]);  // 06063D3C mov.l @r9,r2
    c.r[1] <<= 2; goto L_06063D70;  // 06063D3E bra 0x06063D70 ; shll2 r1
L_06063D70:
    c.r[2] += c.r[1];  // 06063D70 add r1,r2
    c.r[2] += 50;  // 06063D72 add #50,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06063D74 mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06063D76 extu.b r1,r1
    c.r[1] >>= 2;  // 06063D78 shlr2 r1
    c.r[1] >>= 2;  // 06063D7A shlr2 r1
    c.r[1] >>= 2;  // 06063D7C shlr2 r1
    c.r[0] = c.r[1];  // 06063D7E mov r1,r0
    c.t = c.r[0] == 0x1u;  // 06063D80 cmp/eq #1,r0
    if (!c.t) { goto L_06063D92; }  // 06063D82 bf 0x06063D92
    c.r[9] = (uint32_t)(int16_t)ld16(0x06063F34u);  // 06063D84 mov.w 0x06063F34,r9
    c.r[9] += c.r[14];  // 06063D86 add r14,r9
    c.r[9] = ld32(c.r[9]);  // 06063D88 mov.l @r9,r9
    c.t = (c.r[9] & c.r[9]) == 0;  // 06063D8A tst r9,r9
    if (c.t) { goto L_06063D92; }  // 06063D8C bt 0x06063D92
    goto L_06063EA2;  // 06063D8E bra 0x06063EA2 ; nop
L_06063D92:
    c.r[13] = ld32(0x06063F40u);  // 06063D92 mov.l 0x06063F40,r13
    c.r[1] = (uint32_t)(int16_t)ld16(0x06063F36u);  // 06063D94 mov.w 0x06063F36,r1
    c.r[9] = (uint32_t)(int16_t)ld16(0x06063F38u);  // 06063D96 mov.w 0x06063F38,r9
    c.macl = c.r[10] * c.r[1];  // 06063D98 mul.l r1,r10
    c.r[2] = ld32(c.r[13]);  // 06063D9A mov.l @r13,r2
L_06063D9C:
    c.r[9] += c.r[14];  // 06063D9C add r14,r9
    c.r[0] = ld32(c.r[9]);  // 06063D9E mov.l @r9,r0
    c.r[8] = c.macl;  // 06063DA0 sts macl,r8
    c.r[2] += c.r[8];  // 06063DA2 add r8,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06063DA4 mov.b @(r0,r2),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06063DA6 extu.b r1,r1
    c.r[1] <<= 2;  // 06063DA8 shll2 r1
    c.r[1] += c.r[1];  // 06063DAA add r1,r1
    c.r[2] += c.r[1];  // 06063DAC add r1,r2
    c.r[2] += 4;  // 06063DAE add #4,r2
    st8(c.r[2], c.r[11]);  // 06063DB0 mov.b r11,@r2
    c.r[1] = ld32(0x06063F44u);  // 06063DB2 mov.l 0x06063F44,r1
    c.r[1] = ld32(c.r[1]);  // 06063DB4 mov.l @r1,r1
    c.r[1] += 1;  // 06063DB6 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06063DB8 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06063DBA extu.b r1,r1
    c.r[0] = c.r[1];  // 06063DBC mov r1,r0
    c.t = c.r[0] == 0x7u;  // 06063DBE cmp/eq #7,r0
    if (c.t) { goto L_06063E40; }  // 06063DC0 bt 0x06063E40
    c.r[6] = c.r[10];  // 06063DC2 mov r10,r6
    c.r[9] = ld32(0x06063F48u);  // 06063DC4 mov.l 0x06063F48,r9
    c.r[5] = c.r[11];  // 06063DC6 mov r11,r5
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06063DC8 mov.b @r9,r4
    c.r[13] = ld32(0x06063F4Cu);  // 06063DCA mov.l 0x06063F4C,r13
    { const uint32_t x = c.r[13]; c.pr = 0x06063DD0u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06063DD0u) return; }  // 06063DCC jsr @r13 ; extu.b r4,r4
    c.r[3] = c.r[0];  // 06063DD0 mov r0,r3
    c.r[0] = ld32(0x06063F40u);  // 06063DD2 mov.l 0x06063F40,r0
    c.r[9] = (uint32_t)(int16_t)ld16(0x06063F38u);  // 06063DD4 mov.w 0x06063F38,r9
    c.r[9] += c.r[14];  // 06063DD6 add r14,r9
    c.r[13] = ld32(0x06063F48u);  // 06063DD8 mov.l 0x06063F48,r13
    c.r[2] = ld32(c.r[0]);  // 06063DDA mov.l @r0,r2
    c.r[6] = c.r[10];  // 06063DDC mov r10,r6
    c.r[0] = ld32(c.r[9]);  // 06063DDE mov.l @r9,r0
    c.r[2] += c.r[8];  // 06063DE0 add r8,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06063DE2 mov.b @(r0,r2),r1
    c.r[5] = c.r[11];  // 06063DE4 mov r11,r5
    c.r[1] = c.r[1] & 0xFFu;  // 06063DE6 extu.b r1,r1
    c.r[1] <<= 2;  // 06063DE8 shll2 r1
    c.r[1] += c.r[1];  // 06063DEA add r1,r1
    c.r[2] += c.r[1];  // 06063DEC add r1,r2
    c.r[2] += 7;  // 06063DEE add #7,r2
    st8(c.r[2], c.r[3]);  // 06063DF0 mov.b r3,@r2
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[13]);  // 06063DF2 mov.b @r13,r4
    c.r[0] = ld32(0x06063F50u);  // 06063DF4 mov.l 0x06063F50,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06063DFAu; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06063DFAu) return; }  // 06063DF6 jsr @r0 ; extu.b r4,r4
    c.r[7] = c.r[0];  // 06063DFA mov r0,r7
    c.r[9] = ld32(0x06063F40u);  // 06063DFC mov.l 0x06063F40,r9
    c.r[6] = c.r[7];  // 06063DFE mov r7,r6
    c.r[3] = ld32(c.r[9]);  // 06063E00 mov.l @r9,r3
    c.r[13] = 0x7Fu;  // 06063E02 mov #127,r13
    c.r[9] = (uint32_t)(int16_t)ld16(0x06063F38u);  // 06063E04 mov.w 0x06063F38,r9
    c.r[9] += c.r[14];  // 06063E06 add r14,r9
    c.r[0] = ld32(c.r[9]);  // 06063E08 mov.l @r9,r0
    c.r[3] += c.r[8];  // 06063E0A add r8,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06063E0C mov.b @(r0,r3),r1
    c.r[9] = (uint32_t)(int16_t)ld16(0x06063F3Au);  // 06063E0E mov.w 0x06063F3A,r9
    c.r[2] = c.r[1] & 0xFFu;  // 06063E10 extu.b r1,r2
    c.r[2] <<= 2;  // 06063E12 shll2 r2
    c.r[2] += c.r[2];  // 06063E14 add r2,r2
    c.r[6] >>= 16;  // 06063E16 shlr16 r6
    c.r[6] >>= 8;  // 06063E18 shlr8 r6
    c.r[6] &= c.r[13];  // 06063E1A and r13,r6
    c.r[0] = c.r[3];  // 06063E1C mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06063E1E mov.b @(r0,r2),r1
    c.r[3] += c.r[2];  // 06063E20 add r2,r3
    c.r[1] &= c.r[9];  // 06063E22 and r9,r1
    c.r[1] |= c.r[6];  // 06063E24 or r6,r1
    st8(c.r[0] + c.r[2], c.r[1]);  // 06063E26 mov.b r1,@(r0,r2)
    c.r[2] = c.r[3];  // 06063E28 mov r3,r2
    c.r[2] += 1;  // 06063E2A add #1,r2
    c.r[1] = c.r[7];  // 06063E2C mov r7,r1
    c.r[1] >>= 16;  // 06063E2E shlr16 r1
    st8(c.r[2], c.r[1]);  // 06063E30 mov.b r1,@r2
    c.r[2] = c.r[3];  // 06063E32 mov r3,r2
    c.r[2] += 2;  // 06063E34 add #2,r2
    c.r[1] = c.r[7];  // 06063E36 mov r7,r1
    c.r[1] >>= 8;  // 06063E38 shlr8 r1
    st8(c.r[2], c.r[1]);  // 06063E3A mov.b r1,@r2
    c.r[3] += 3;  // 06063E3C add #3,r3
    st8(c.r[3], c.r[7]);  // 06063E3E mov.b r7,@r3
L_06063E40:
    c.r[13] = ld32(0x06063F40u);  // 06063E40 mov.l 0x06063F40,r13
    c.r[1] = ld32(c.r[13]);  // 06063E42 mov.l @r13,r1
    c.r[9] = (uint32_t)(int16_t)ld16(0x06063F38u);  // 06063E44 mov.w 0x06063F38,r9
    c.macl = c.r[8];  // 06063E46 lds r8,macl
    c.r[9] += c.r[14];  // 06063E48 add r14,r9
    c.r[0] = ld32(c.r[9]);  // 06063E4A mov.l @r9,r0
    c.r[2] = c.macl;  // 06063E4C sts macl,r2
    c.r[2] += c.r[1];  // 06063E4E add r1,r2
    c.r[9] = (uint32_t)(int16_t)ld16(0x06063F3Cu);  // 06063E50 mov.w 0x06063F3C,r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06063E52 mov.b @(r0,r2),r1
    c.r[9] += c.r[14];  // 06063E54 add r14,r9
    c.r[1] = c.r[1] & 0xFFu;  // 06063E56 extu.b r1,r1
    c.r[1] <<= 2;  // 06063E58 shll2 r1
    c.r[1] += c.r[1];  // 06063E5A add r1,r1
    c.r[2] += c.r[1];  // 06063E5C add r1,r2
    c.r[0] = ld32(c.r[9]);  // 06063E5E mov.l @r9,r0
    c.r[2] += 5;  // 06063E60 add #5,r2
    c.r[9] = (uint32_t)(int16_t)ld16(0x06063F38u);  // 06063E62 mov.w 0x06063F38,r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 06063E64 mov.b @(r0,r14),r1
    c.r[9] += c.r[14];  // 06063E66 add r14,r9
    st8(c.r[2], c.r[1]);  // 06063E68 mov.b r1,@r2
    c.r[1] = ld32(c.r[13]);  // 06063E6A mov.l @r13,r1
    c.r[2] = c.macl;  // 06063E6C sts macl,r2
    c.r[0] = ld32(c.r[9]);  // 06063E6E mov.l @r9,r0
    c.r[2] += c.r[1];  // 06063E70 add r1,r2
    c.r[9] = (uint32_t)(int16_t)ld16(0x06063F3Cu);  // 06063E72 mov.w 0x06063F3C,r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06063E74 mov.b @(r0,r2),r1
    c.r[9] += c.r[14];  // 06063E76 add r14,r9
    c.r[1] = c.r[1] & 0xFFu;  // 06063E78 extu.b r1,r1
    c.r[1] <<= 2;  // 06063E7A shll2 r1
    c.r[1] += c.r[1];  // 06063E7C add r1,r1
    c.r[2] += c.r[1];  // 06063E7E add r1,r2
    c.r[2] += 6;  // 06063E80 add #6,r2
    c.r[1] = c.r[14];  // 06063E82 mov r14,r1
    c.r[0] = ld32(c.r[9]);  // 06063E84 mov.l @r9,r0
    c.r[1] += 1;  // 06063E86 add #1,r1
    c.r[9] = (uint32_t)(int16_t)ld16(0x06063F38u);  // 06063E88 mov.w 0x06063F38,r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06063E8A mov.b @(r0,r1),r1
    c.r[9] += c.r[14];  // 06063E8C add r14,r9
    st8(c.r[2], c.r[1]);  // 06063E8E mov.b r1,@r2
    c.r[1] = ld32(c.r[13]);  // 06063E90 mov.l @r13,r1
    c.r[2] = c.macl;  // 06063E92 sts macl,r2
    c.r[0] = ld32(c.r[9]);  // 06063E94 mov.l @r9,r0
    c.r[2] += c.r[1];  // 06063E96 add r1,r2
    c.r[13] = (uint32_t)(int16_t)ld16(0x06063F38u);  // 06063E98 mov.w 0x06063F38,r13
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06063E9A mov.b @(r0,r2),r1
    c.r[13] += c.r[14];  // 06063E9C add r14,r13
    c.r[1] += 1;  // 06063E9E add #1,r1
    st8(c.r[0] + c.r[2], c.r[1]);  // 06063EA0 mov.b r1,@(r0,r2)
L_06063EA2:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06063F3Cu);  // 06063EA2 mov.w 0x06063F3C,r0
    c.r[0] += c.r[14];  // 06063EA4 add r14,r0
    c.r[13] = (uint32_t)(int16_t)ld16(0x06063F3Eu);  // 06063EA6 mov.w 0x06063F3E,r13
    c.r[9] = ld32(c.r[0]);  // 06063EA8 mov.l @r0,r9
    c.r[13] += c.r[14];  // 06063EAA add r14,r13
    c.r[9] += 2;  // 06063EAC add #2,r9
    st32(c.r[0], c.r[9]);  // 06063EAE mov.l r9,@r0
    c.r[13] = ld32(c.r[13]);  // 06063EB0 mov.l @r13,r13
    c.r[12] += 1;  // 06063EB2 add #1,r12
    c.t = (int32_t)c.r[12] >= (int32_t)c.r[13];  // 06063EB4 cmp/ge r13,r12
    if (c.t) { goto L_06063EBC; }  // 06063EB6 bt 0x06063EBC
    SH2_POLL(c); goto L_060637D6;  // 06063EB8 bra 0x060637D6 ; nop
L_06063EBC:
    c.r[0] = ld32(0x06063F40u);  // 06063EBC mov.l 0x06063F40,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06063F36u);  // 06063EBE mov.w 0x06063F36,r1
    c.r[9] = (uint32_t)(int16_t)ld16(0x06063F38u);  // 06063EC0 mov.w 0x06063F38,r9
    c.macl = c.r[10] * c.r[1];  // 06063EC2 mul.l r1,r10
    c.r[2] = ld32(c.r[0]);  // 06063EC4 mov.l @r0,r2
    c.r[9] += c.r[14];  // 06063EC6 add r14,r9
    c.r[0] = ld32(c.r[9]);  // 06063EC8 mov.l @r9,r0
    c.r[1] = c.macl;  // 06063ECA sts macl,r1
    c.r[1] += c.r[2];  // 06063ECC add r2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06063ECE mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06063ED0 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06063ED2 tst r1,r1
    { const bool k = !c.t; c.r[2] = c.r[10]; if (k) { goto L_06063F8E; } }  // 06063ED4 bf/s 0x06063F8E ; mov r10,r2
    c.r[13] = ld32(0x06063F54u);  // 06063ED8 mov.l 0x06063F54,r13
    c.r[2] <<= 2;  // 06063EDA shll2 r2
    c.r[2] += c.r[10];  // 06063EDC add r10,r2
    c.r[1] = ld32(c.r[13]);  // 06063EDE mov.l @r13,r1
    c.r[2] <<= 2;  // 06063EE0 shll2 r2
    c.r[1] += c.r[2];  // 06063EE2 add r2,r1
    c.r[1] += 51;  // 06063EE4 add #51,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06063EE6 mov.b @r1,r3
    c.r[0] = 0x8u;  // 06063EE8 mov #8,r0
    c.r[3] |= c.r[0];  // 06063EEA or r0,r3
    st8(c.r[1], c.r[3]);  // 06063EEC mov.b r3,@r1
    c.r[1] = ld32(0x06063F44u);  // 06063EEE mov.l 0x06063F44,r1
    c.r[1] = ld32(c.r[1]);  // 06063EF0 mov.l @r1,r1
    c.r[1] += 1;  // 06063EF2 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06063EF4 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06063EF6 extu.b r1,r1
    c.r[0] = c.r[1];  // 06063EF8 mov r1,r0
    c.t = c.r[0] == 0x5u;  // 06063EFA cmp/eq #5,r0
    if (c.t) { goto L_06063F14; }  // 06063EFC bt 0x06063F14
    c.r[1] = ld32(c.r[13]);  // 06063EFE mov.l @r13,r1
    c.r[1] += c.r[2];  // 06063F00 add r2,r1
    c.r[1] += 50;  // 06063F02 add #50,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06063F04 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06063F06 extu.b r1,r1
    c.r[1] >>= 2;  // 06063F08 shlr2 r1
    c.r[1] >>= 2;  // 06063F0A shlr2 r1
    c.r[1] >>= 2;  // 06063F0C shlr2 r1
    c.r[0] = c.r[1];  // 06063F0E mov r1,r0
    c.t = c.r[0] == 0x2u;  // 06063F10 cmp/eq #2,r0
    if (c.t) { goto L_06063F8E; }  // 06063F12 bt 0x06063F8E
L_06063F14:
    c.r[1] = ld32(0x06063F58u);  // 06063F14 mov.l 0x06063F58,r1
    c.r[9] = ld32(0x06063F5Cu);  // 06063F16 mov.l 0x06063F5C,r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06063F18 mov.b @r1,r1
    c.r[13] = ld32(0x06063F48u);  // 06063F1A mov.l 0x06063F48,r13
    c.r[2] = ld32(c.r[9]);  // 06063F1C mov.l @r9,r2
    c.r[6] = c.r[10];  // 06063F1E mov r10,r6
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[13]);  // 06063F20 mov.b @r13,r4
    c.r[3] = c.r[1] & 0xFFu;  // 06063F22 extu.b r1,r3
    c.r[3] <<= 2;  // 06063F24 shll2 r3
    c.r[3] <<= 2;  // 06063F26 shll2 r3
    c.r[1] = c.r[3];  // 06063F28 mov r3,r1
    c.r[1] += c.r[2];  // 06063F2A add r2,r1
    c.r[0] = c.r[3];  // 06063F2C mov r3,r0
    c.r[9] = ld32(0x06063F54u);  // 06063F2E mov.l 0x06063F54,r9
    c.r[4] = c.r[4] & 0xFFu; goto L_06063F60;  // 06063F30 bra 0x06063F60 ; extu.b r4,r4
L_06063F60:
    c.r[1] += 1;  // 06063F60 add #1,r1
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06063F62 mov.b @(r0,r2),r7
    c.r[13] = ld32(0x06064110u);  // 06063F64 mov.l 0x06064110,r13
    c.r[5] = ld32(c.r[9]);  // 06063F66 mov.l @r9,r5
    c.r[0] = (uint32_t)(int16_t)ld16(0x060640F8u);  // 06063F68 mov.w 0x060640F8,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06063F6A mov.l @(r0,r14),r0
    c.r[9] = ld32(0x06064114u);  // 06063F6C mov.l 0x06064114,r9
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 06063F6E mov.l r0,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06063F70 mov.l r9,@-r15
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06063F72 mov.b @r1,r1
    c.r[7] = c.r[7] & 0xFFu;  // 06063F74 extu.b r7,r7
    c.r[1] = c.r[1] & 0xFFu;  // 06063F76 extu.b r1,r1
    { const uint32_t x = c.r[13]; c.pr = 0x06063F7Cu; c.r[15] -= 4; st32(c.r[15], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06063F7Cu) return; }  // 06063F78 jsr @r13 ; mov.l r1,@-r15
    c.r[1] = c.r[0];  // 06063F7C mov r0,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06063F7E extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06063F80 tst r1,r1
    { const bool k = !c.t; c.r[15] += 12; if (k) { goto L_06063F8E; } }  // 06063F82 bf/s 0x06063F8E ; add #12,r15
    c.r[1] = ld32(0x06064118u);  // 06063F86 mov.l 0x06064118,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06063F88 mov.b @r1,r0
    c.r[0] |= 0x4u;  // 06063F8A or #4,r0
    st8(c.r[1], c.r[0]);  // 06063F8C mov.b r0,@r1
L_06063F8E:
    c.r[0] = (uint32_t)(int16_t)ld16(0x060640FAu);  // 06063F8E mov.w 0x060640FA,r0
    c.r[0] += c.r[14];  // 06063F90 add r14,r0
    c.r[3] = ld32(0x0606411Cu);  // 06063F92 mov.l 0x0606411C,r3
    c.r[9] = ld32(c.r[0]);  // 06063F94 mov.l @r0,r9
    c.r[2] = (uint32_t)(int16_t)ld16(0x060640FCu);  // 06063F96 mov.w 0x060640FC,r2
    c.r[9] += 1;  // 06063F98 add #1,r9
    st32(c.r[0], c.r[9]);  // 06063F9A mov.l r9,@r0
    c.r[1] = ld32(c.r[3]);  // 06063F9C mov.l @r3,r1
    c.r[9] = (uint32_t)(int16_t)ld16(0x060640FAu);  // 06063F9E mov.w 0x060640FA,r9
    c.r[0] = c.r[1];  // 06063FA0 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06063FA2 mov.b @(r0,r2),r1
    c.r[9] += c.r[14];  // 06063FA4 add r14,r9
    c.r[9] = ld32(c.r[9]);  // 06063FA6 mov.l @r9,r9
    c.r[1] = c.r[1] & 0xFFu;  // 06063FA8 extu.b r1,r1
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[1];  // 06063FAA cmp/ge r1,r9
    if (c.t) { goto L_06063FB2; }  // 06063FAC bt 0x06063FB2
    SH2_POLL(c); goto L_06063748;  // 06063FAE bra 0x06063748 ; nop
L_06063FB2:
    c.r[1] = ld32(0x06064120u);  // 06063FB2 mov.l 0x06064120,r1
    c.r[1] = ld32(c.r[1]);  // 06063FB4 mov.l @r1,r1
    c.r[1] += 1;  // 06063FB6 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06063FB8 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06063FBA extu.b r1,r1
    c.r[0] = c.r[1];  // 06063FBC mov r1,r0
    c.t = c.r[0] == 0x4u;  // 06063FBE cmp/eq #4,r0
    { const bool k = c.t; c.r[13] = 0x0u; if (k) { goto L_06063FCC; } }  // 06063FC0 bt/s 0x06063FCC ; mov #0,r13
    c.t = c.r[0] == 0x6u;  // 06063FC4 cmp/eq #6,r0
    if (c.t) { goto L_06063FCC; }  // 06063FC6 bt 0x06063FCC
    goto L_060640E0;  // 06063FC8 bra 0x060640E0 ; nop
L_06063FCC:
    c.r[9] = (uint32_t)(int16_t)ld16(0x060640FAu);  // 06063FCC mov.w 0x060640FA,r9
    c.r[9] += c.r[14];  // 06063FCE add r14,r9
    st32(c.r[9], c.r[13]);  // 06063FD0 mov.l r13,@r9
    c.r[6] = ld32(0x06064124u);  // 06063FD2 mov.l 0x06064124,r6
    c.r[1] = ld32(0x06064128u);  // 06063FD4 mov.l 0x06064128,r1
    c.r[7] = (uint32_t)(int16_t)ld16(0x060640FEu);  // 06063FD6 mov.w 0x060640FE,r7
    c.r[9] = (uint32_t)(int16_t)ld16(0x06064100u);  // 06063FD8 mov.w 0x06064100,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06064102u);  // 06063FDA mov.w 0x06064102,r0
    c.r[0] += c.r[14];  // 06063FDC add r14,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[6]);  // 06063FDE mov.b @r6,r2
    c.r[13] = (uint32_t)(int16_t)ld16(0x060640FAu);  // 06063FE0 mov.w 0x060640FA,r13
    c.r[3] = ld32(c.r[1]);  // 06063FE2 mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06063FE4 extu.b r2,r2
    st32(c.r[0], c.r[9]);  // 06063FE6 mov.l r9,@r0
    c.r[9] = (uint32_t)(int16_t)ld16(0x06064102u);  // 06063FE8 mov.w 0x06064102,r9
    c.macl = c.r[2] * c.r[7];  // 06063FEA mul.l r7,r2
    c.r[9] += c.r[14];  // 06063FEC add r14,r9
    c.r[0] = ld32(c.r[9]);  // 06063FEE mov.l @r9,r0
    c.r[1] = c.macl;  // 06063FF0 sts macl,r1
    c.r[1] += c.r[3];  // 06063FF2 add r3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06063FF4 mov.b @(r0,r1),r1
    c.r[13] += c.r[14];  // 06063FF6 add r14,r13
    c.r[13] = ld32(c.r[13]);  // 06063FF8 mov.l @r13,r13
    c.r[1] = c.r[1] & 0xFFu;  // 06063FFA extu.b r1,r1
    c.t = (int32_t)c.r[13] >= (int32_t)c.r[1];  // 06063FFC cmp/ge r1,r13
    { const bool k = c.t; c.r[12] = c.r[6]; if (k) { goto L_060640A6; } }  // 06063FFE bt/s 0x060640A6 ; mov r6,r12
    c.r[4] = c.r[3];  // 06064002 mov r3,r4
    c.r[11] = c.r[7];  // 06064004 mov r7,r11
    c.r[1] = ld32(0x0606412Cu);  // 06064006 mov.l 0x0606412C,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06064104u);  // 06064008 mov.w 0x06064104,r0
    c.r[0] += c.r[14];  // 0606400A add r14,r0
    c.r[9] = (uint32_t)(int16_t)ld16(0x06064106u);  // 0606400C mov.w 0x06064106,r9
    c.r[9] += c.r[14];  // 0606400E add r14,r9
    c.r[1] = ld32(c.r[1]);  // 06064010 mov.l @r1,r1
    c.r[6] = 0x0u;  // 06064012 mov #0,r6
    st32(c.r[0], c.r[1]);  // 06064014 mov.l r1,@r0
    c.r[1] = ld32(0x06064130u);  // 06064016 mov.l 0x06064130,r1
    c.r[8] = ld32(c.r[1]);  // 06064018 mov.l @r1,r8
    c.r[7] = 0x0u;  // 0606401A mov #0,r7
    c.r[1] = ld32(0x06064134u);  // 0606401C mov.l 0x06064134,r1
    c.r[1] = ld32(c.r[1]);  // 0606401E mov.l @r1,r1
    c.r[5] = c.r[8];  // 06064020 mov r8,r5
    st32(c.r[9], c.r[1]);  // 06064022 mov.l r1,@r9
L_06064024:
    c.r[13] = (uint32_t)(int16_t)ld16(0x06064104u);  // 06064024 mov.w 0x06064104,r13
    c.r[13] += c.r[14];  // 06064026 add r14,r13
    c.r[0] = (uint32_t)(int16_t)ld16(0x06064106u);  // 06064028 mov.w 0x06064106,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[12]);  // 0606402A mov.b @r12,r1
    c.r[0] += c.r[14];  // 0606402C add r14,r0
    c.r[1] = c.r[1] & 0xFFu;  // 0606402E extu.b r1,r1
    c.macl = c.r[1] * c.r[11];  // 06064030 mul.l r11,r1
    c.r[3] = c.r[5];  // 06064032 mov r5,r3
    c.r[3] += 2;  // 06064034 add #2,r3
    c.r[1] = c.macl;  // 06064036 sts macl,r1
    c.r[1] += c.r[4];  // 06064038 add r4,r1
    c.r[1] += c.r[7];  // 0606403A add r7,r1
    c.r[1] += 4;  // 0606403C add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606403E mov.b @r1,r1
    c.r[5] += 4;  // 06064040 add #4,r5
    c.r[13] = ld32(c.r[13]);  // 06064042 mov.l @r13,r13
    c.r[1] = c.r[1] & 0xFFu;  // 06064044 extu.b r1,r1
    c.r[1] <<= 2;  // 06064046 shll2 r1
    c.r[1] <<= 2;  // 06064048 shll2 r1
    c.r[1] += c.r[13];  // 0606404A add r13,r1
    c.r[1] += 2;  // 0606404C add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606404E mov.b @r1,r1
    c.r[9] = (uint32_t)(int16_t)ld16(0x060640FAu);  // 06064050 mov.w 0x060640FA,r9
    c.r[10] = c.r[1] & 0xFFu;  // 06064052 extu.b r1,r10
    c.r[1] = 0x1Eu;  // 06064054 mov #30,r1
    c.macl = c.r[10] * c.r[1];  // 06064056 mul.l r1,r10
    c.r[9] += c.r[14];  // 06064058 add r14,r9
    c.r[0] = ld32(c.r[0]);  // 0606405A mov.l @r0,r0
    c.r[2] = c.macl;  // 0606405C sts macl,r2
    c.r[2] += c.r[0];  // 0606405E add r0,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06064060 mov.w @r2,r1
    c.r[0] = c.r[6];  // 06064062 mov r6,r0
    st16(c.r[0] + c.r[8], c.r[1]);  // 06064064 mov.w r1,@(r0,r8)
    c.r[2] += 15;  // 06064066 add #15,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06064068 mov.b @r2,r2
    c.r[1] = ld32(0x06064138u);  // 0606406A mov.l 0x06064138,r1
    c.r[1] = ld32(c.r[1]);  // 0606406C mov.l @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0606406E extu.b r2,r2
    c.r[10] = c.r[2];  // 06064070 mov r2,r10
    c.r[10] += c.r[10];  // 06064072 add r10,r10
    c.r[10] += c.r[2];  // 06064074 add r2,r10
    c.r[10] <<= 2;  // 06064076 shll2 r10
    c.r[0] = c.r[10];  // 06064078 mov r10,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0606407A mov.w @(r0,r1),r1
    c.r[7] += 8;  // 0606407C add #8,r7
    st16(c.r[3], c.r[1]);  // 0606407E mov.w r1,@r3
    c.r[13] = ld32(c.r[9]);  // 06064080 mov.l @r9,r13
    c.r[13] += 1;  // 06064082 add #1,r13
    st32(c.r[9], c.r[13]);  // 06064084 mov.l r13,@r9
    c.r[9] = (uint32_t)(int16_t)ld16(0x06064102u);  // 06064086 mov.w 0x06064102,r9
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[12]);  // 06064088 mov.b @r12,r1
    c.r[9] += c.r[14];  // 0606408A add r14,r9
    c.r[1] = c.r[1] & 0xFFu;  // 0606408C extu.b r1,r1
    c.macl = c.r[1] * c.r[11];  // 0606408E mul.l r11,r1
    c.r[13] = (uint32_t)(int16_t)ld16(0x060640FAu);  // 06064090 mov.w 0x060640FA,r13
    c.r[0] = ld32(c.r[9]);  // 06064092 mov.l @r9,r0
    c.r[1] = c.macl;  // 06064094 sts macl,r1
    c.r[1] += c.r[4];  // 06064096 add r4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06064098 mov.b @(r0,r1),r1
    c.r[13] += c.r[14];  // 0606409A add r14,r13
    c.r[13] = ld32(c.r[13]);  // 0606409C mov.l @r13,r13
    c.r[1] = c.r[1] & 0xFFu;  // 0606409E extu.b r1,r1
    c.t = (int32_t)c.r[13] >= (int32_t)c.r[1];  // 060640A0 cmp/ge r1,r13
    { const bool k = !c.t; c.r[6] += 4; if (k) { SH2_POLL(c); goto L_06064024; } }  // 060640A2 bf/s 0x06064024 ; add #4,r6
L_060640A6:
    c.r[0] = (uint32_t)(int16_t)ld16(0x060640FAu);  // 060640A6 mov.w 0x060640FA,r0
    c.r[3] = ld32(c.r[0] + c.r[14]);  // 060640A8 mov.l @(r0,r14),r3
    c.r[1] = ld32(0x06064130u);  // 060640AA mov.l 0x06064130,r1
    c.r[7] = ld32(c.r[1]);  // 060640AC mov.l @r1,r7
    c.r[3] <<= 2;  // 060640AE shll2 r3
    c.r[2] = c.r[3];  // 060640B0 mov r3,r2
    c.r[2] += c.r[7];  // 060640B2 add r7,r2
    c.r[2] += 2;  // 060640B4 add #2,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06064108u);  // 060640B6 mov.w 0x06064108,r1
    st16(c.r[2], c.r[1]);  // 060640B8 mov.w r1,@r2
    c.r[0] = c.r[3];  // 060640BA mov r3,r0
    st16(c.r[0] + c.r[7], c.r[1]);  // 060640BC mov.w r1,@(r0,r7)
    c.r[1] = ld32(0x06064124u);  // 060640BE mov.l 0x06064124,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060640C0 mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 060640C2 extu.b r1,r2
    c.r[0] = c.r[2];  // 060640C4 mov r2,r0
    c.t = c.r[0] == 0xEu;  // 060640C6 cmp/eq #14,r0
    if (c.t) { goto L_060640E0; }  // 060640C8 bt 0x060640E0
    c.r[1] = ld32(0x06064128u);  // 060640CA mov.l 0x06064128,r1
    c.r[1] = ld32(c.r[1]);  // 060640CC mov.l @r1,r1
    c.r[6] = (uint32_t)(int16_t)ld16(0x060640FEu);  // 060640CE mov.w 0x060640FE,r6
    c.macl = c.r[2] * c.r[6];  // 060640D0 mul.l r6,r2
    c.r[4] = (uint32_t)(int16_t)ld16(0x0606410Au);  // 060640D2 mov.w 0x0606410A,r4
    c.r[4] += c.r[1];  // 060640D4 add r1,r4
    c.r[5] = c.macl;  // 060640D6 sts macl,r5
    c.r[5] += c.r[1];  // 060640D8 add r1,r5
    c.r[1] = ld32(0x0606413Cu);  // 060640DA mov.l 0x0606413C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060640E0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060640E0u) return; }  // 060640DC jsr @r1 ; nop
L_060640E0:
    c.r[3] = (uint32_t)(int16_t)ld16(0x0606410Cu);  // 060640E0 mov.w 0x0606410C,r3
    c.r[14] += c.r[3];  // 060640E2 add r3,r14
    c.r[15] = c.r[14];  // 060640E4 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060640E6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060640E8 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060640EA mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060640EC mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060640EE mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060640F0 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060640F2 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060640F4 rts ; mov.l @r15+,r8
}

void f_06064140(SH2Context& c) {
    ran[1488] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06064140 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06064142 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06064144 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06064146 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06064148 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0606414A mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0606414C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0606414E sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x060641BAu);  // 06064150 mov.w 0x060641BA,r3
    c.r[15] += c.r[3];  // 06064152 add r3,r15
    c.r[14] = c.r[15];  // 06064154 mov r15,r14
    c.r[10] = 0x0u;  // 06064156 mov #0,r10
    c.r[7] = 0x49u;  // 06064158 mov #73,r7
    c.r[3] = ld32(0x060641BCu);  // 0606415A mov.l 0x060641BC,r3
L_0606415C:
    c.r[2] = c.r[10];  // 0606415C mov r10,r2
    c.r[2] += c.r[2];  // 0606415E add r2,r2
    c.r[1] = ld32(c.r[3]);  // 06064160 mov.l @r3,r1
    c.r[10] += 1;  // 06064162 add #1,r10
    c.r[0] = c.r[1];  // 06064164 mov r1,r0
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06064166 mov.b @(r0,r2),r6
    c.t = (int32_t)c.r[10] > (int32_t)c.r[7];  // 06064168 cmp/gt r7,r10
    c.r[0] = 0x7Fu;  // 0606416A mov #127,r0
    c.r[6] &= c.r[0];  // 0606416C and r0,r6
    c.r[0] = c.r[1];  // 0606416E mov r1,r0
    { const bool k = !c.t; st8(c.r[0] + c.r[2], c.r[6]); if (k) { SH2_POLL(c); goto L_0606415C; } }  // 06064170 bf/s 0x0606415C ; mov.b r6,@(r0,r2)
    c.r[1] = ld32(0x060641C0u);  // 06064174 mov.l 0x060641C0,r1
    c.r[2] = ld32(c.r[1]);  // 06064176 mov.l @r1,r2
    c.r[2] += 1;  // 06064178 add #1,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606417A mov.b @r2,r0
    c.r[3] = ld32(0x060641C4u);  // 0606417C mov.l 0x060641C4,r3
    c.r[0] &= 0xF0u;  // 0606417E and #240,r0
    c.r[0] >>= 2;  // 06064180 shlr2 r0
    c.r[0] >>= 2;  // 06064182 shlr2 r0
    st8(c.r[3], c.r[0]);  // 06064184 mov.b r0,@r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06064186 mov.b @r2,r0
    c.r[1] = ld32(0x060641C8u);  // 06064188 mov.l 0x060641C8,r1
    c.r[0] &= 0xFu;  // 0606418A and #15,r0
    st8(c.r[1], c.r[0]);  // 0606418C mov.b r0,@r1
    c.r[1] = 0x6u;  // 0606418E mov #6,r1
    c.r[2] = c.r[0];  // 06064190 mov r0,r2
    c.r[2] -= 1;  // 06064192 add #-1,r2
    c.t = c.r[2] > c.r[1];  // 06064194 cmp/hi r1,r2
    { const bool k = !c.t; c.r[5] = c.r[3]; if (k) { goto L_0606419E; } }  // 06064196 bf/s 0x0606419E ; mov r3,r5
    goto L_06064B6E;  // 0606419A bra 0x06064B6E ; nop
L_0606419E:
    c.r[1] = c.r[2];  // 0606419E mov r2,r1
    c.r[1] += c.r[1];  // 060641A0 add r1,r1
    c.r[0] = 0x060641ACu;  // 060641A2 mova 0x060641AC,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 060641A4 mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 060641A6 add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x060641CCu: goto L_060641CC; case 0x06064320u: goto L_06064320; case 0x06064428u: goto L_06064428; case 0x06064574u: goto L_06064574; case 0x060646D6u: goto L_060646D6; case 0x06064890u: goto L_06064890; case 0x06064970u: goto L_06064970; default: sh2_call(c, x); return; } }  // 060641A8 jmp @r0 ; nop
L_060641CC:
    c.r[1] = ld32(0x060642E4u);  // 060641CC mov.l 0x060642E4,r1
    c.r[2] = ld32(c.r[1]);  // 060641CE mov.l @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x060642DEu);  // 060641D0 mov.w 0x060642DE,r0
    c.r[10] = 0x0u;  // 060641D2 mov #0,r10
    c.r[4] = ld32(0x060642E8u);  // 060641D4 mov.l 0x060642E8,r4
    c.r[8] = (uint32_t)(int16_t)ld16(0x060642E0u);  // 060641D6 mov.w 0x060642E0,r8
    c.r[5] = ld32(0x060642ECu);  // 060641D8 mov.l 0x060642EC,r5
    c.r[6] = 0x0u;  // 060641DA mov #0,r6
    c.r[1] = 0x0u;  // 060641DC mov #0,r1
    st8(c.r[0] + c.r[2], c.r[1]);  // 060641DE mov.b r1,@(r0,r2)
L_060641E0:
    c.r[0] = ld32(c.r[4]);  // 060641E0 mov.l @r4,r0
    c.r[2] = c.r[6];  // 060641E2 mov r6,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 060641E4 mov.b @(r0,r6),r1
    c.r[1] = c.r[1] & 0xFFu;  // 060641E6 extu.b r1,r1
    c.t = c.r[1] == c.r[8];  // 060641E8 cmp/eq r8,r1
    { const bool k = c.t; c.r[2] += c.r[0]; if (k) { goto L_06064270; } }  // 060641EA bt/s 0x06064270 ; add r0,r2
    c.r[1] = c.r[2];  // 060641EE mov r2,r1
    c.r[1] += 7;  // 060641F0 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060641F2 mov.b @r1,r1
    c.r[0] = c.r[1];  // 060641F4 mov r1,r0
    c.r[0] >>= 2;  // 060641F6 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060641F8 shlr r0
    c.r[0] &= 0x1u;  // 060641FA and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060641FC tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[2]; if (k) { goto L_06064270; } }  // 060641FE bf/s 0x06064270 ; mov r2,r1
    c.r[1] += 3;  // 06064202 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06064204 mov.b @r1,r1
    c.r[0] = 0x3u;  // 06064206 mov #3,r0
    c.r[3] = c.r[1];  // 06064208 mov r1,r3
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 0606420A shlr r3
    c.r[3] &= c.r[0];  // 0606420C and r0,r3
    c.t = (c.r[3] & c.r[3]) == 0;  // 0606420E tst r3,r3
    if (!c.t) { goto L_0606421A; }  // 06064210 bf 0x0606421A
    c.r[1] = ld32(c.r[2] + 12);  // 06064212 mov.l @(12,r2),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06064214 tst r1,r1
    { const bool k = !c.t; c.t = (c.r[3] & c.r[3]) == 0; if (k) { goto L_06064270; } }  // 06064216 bf/s 0x06064270 ; tst r3,r3
L_0606421A:
    if (!c.t) { goto L_06064224; }  // 0606421A bf 0x06064224
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[5]);  // 0606421C mov.b @r5,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606421E extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06064220 tst r1,r1
    if (c.t) { goto L_06064230; }  // 06064222 bt 0x06064230
L_06064224:
    c.t = (c.r[3] & c.r[3]) == 0;  // 06064224 tst r3,r3
    if (c.t) { goto L_06064270; }  // 06064226 bt 0x06064270
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[5]);  // 06064228 mov.b @r5,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606422A extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606422C tst r1,r1
    if (c.t) { goto L_06064270; }  // 0606422E bt 0x06064270
L_06064230:
    c.r[1] = ld32(c.r[4]);  // 06064230 mov.l @r4,r1
    c.r[1] += c.r[6];  // 06064232 add r6,r1
    c.r[2] = ld32(c.r[1] + 4);  // 06064234 mov.l @(4,r1),r2
    c.r[1] = ld32(0x060642F0u);  // 06064236 mov.l 0x060642F0,r1
    c.r[2] &= c.r[1];  // 06064238 and r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0606423A tst r2,r2
    if (!c.t) { goto L_06064270; }  // 0606423C bf 0x06064270
    c.r[1] = ld32(0x060642E4u);  // 0606423E mov.l 0x060642E4,r1
    c.r[3] = ld32(c.r[1]);  // 06064240 mov.l @r1,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x060642DEu);  // 06064242 mov.w 0x060642DE,r7
    c.r[0] = c.r[3];  // 06064244 mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06064246 mov.b @(r0,r7),r2
    c.r[1] = c.r[2];  // 06064248 mov r2,r1
    c.r[1] += 1;  // 0606424A add #1,r1
    st8(c.r[0] + c.r[7], c.r[1]);  // 0606424C mov.b r1,@(r0,r7)
    c.r[7] = c.r[2] & 0xFFu;  // 0606424E extu.b r2,r7
    c.r[7] += c.r[7];  // 06064250 add r7,r7
    c.r[1] = c.r[10] & 0xFFFFu;  // 06064252 extu.w r10,r1
    c.r[9] = c.r[1];  // 06064254 mov r1,r9
    c.r[9] >>= 8;  // 06064256 shlr8 r9
    c.r[0] = 0x7Fu;  // 06064258 mov #127,r0
    c.r[9] &= c.r[0];  // 0606425A and r0,r9
    c.r[0] = c.r[3];  // 0606425C mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0606425E mov.b @(r0,r7),r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x060642E2u);  // 06064260 mov.w 0x060642E2,r0
    c.r[2] &= c.r[0];  // 06064262 and r0,r2
    c.r[2] |= c.r[9];  // 06064264 or r9,r2
    c.r[0] = c.r[3];  // 06064266 mov r3,r0
    st8(c.r[0] + c.r[7], c.r[2]);  // 06064268 mov.b r2,@(r0,r7)
    c.r[3] += c.r[7];  // 0606426A add r7,r3
    c.r[3] += 1;  // 0606426C add #1,r3
    st8(c.r[3], c.r[1]);  // 0606426E mov.b r1,@r3
L_06064270:
    c.r[10] += 1;  // 06064270 add #1,r10
    c.r[1] = 0x49u;  // 06064272 mov #73,r1
    c.t = (int32_t)c.r[10] > (int32_t)c.r[1];  // 06064274 cmp/gt r1,r10
    { const bool k = !c.t; c.r[6] += 16; if (k) { SH2_POLL(c); goto L_060641E0; } }  // 06064276 bf/s 0x060641E0 ; add #16,r6
    c.r[1] = ld32(0x060642E4u);  // 0606427A mov.l 0x060642E4,r1
    c.r[1] = ld32(c.r[1]);  // 0606427C mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060642DEu);  // 0606427E mov.w 0x060642DE,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06064280 mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06064282 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06064284 tst r1,r1
    { const bool k = c.t; c.r[10] = 0x0u; if (k) { goto L_0606428E; } }  // 06064286 bt/s 0x0606428E ; mov #0,r10
    goto L_06064C1A;  // 0606428A bra 0x06064C1A ; nop
L_0606428E:
    c.r[5] = ld32(0x060642E8u);  // 0606428E mov.l 0x060642E8,r5
    c.r[7] = ld32(c.r[5]);  // 06064290 mov.l @r5,r7
    c.r[4] = (uint32_t)(int16_t)ld16(0x060642E0u);  // 06064292 mov.w 0x060642E0,r4
    c.r[6] = ld32(0x060642ECu);  // 06064294 mov.l 0x060642EC,r6
    c.r[3] = 0x0u;  // 06064296 mov #0,r3
    c.r[2] = c.r[7];  // 06064298 mov r7,r2
L_0606429A:
    c.r[0] = c.r[3];  // 0606429A mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0606429C mov.b @(r0,r7),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606429E extu.b r1,r1
    c.t = c.r[1] == c.r[4];  // 060642A0 cmp/eq r4,r1
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_06064310; } }  // 060642A2 bt/s 0x06064310 ; mov r2,r1
    c.r[1] += 7;  // 060642A6 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060642A8 mov.b @r1,r1
    c.r[0] = c.r[1];  // 060642AA mov r1,r0
    c.r[0] >>= 2;  // 060642AC shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060642AE shlr r0
    c.r[0] &= 0x1u;  // 060642B0 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060642B2 tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[2]; if (k) { goto L_06064310; } }  // 060642B4 bf/s 0x06064310 ; mov r2,r1
    c.r[1] += 3;  // 060642B8 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060642BA mov.b @r1,r1
    c.r[0] = 0x3u;  // 060642BC mov #3,r0
    c.r[8] = c.r[1];  // 060642BE mov r1,r8
    c.t = c.r[8] & 1; c.r[8] >>= 1;  // 060642C0 shlr r8
    c.r[8] &= c.r[0];  // 060642C2 and r0,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 060642C4 tst r8,r8
    if (!c.t) { goto L_060642D0; }  // 060642C6 bf 0x060642D0
    c.r[1] = ld32(c.r[2] + 12);  // 060642C8 mov.l @(12,r2),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060642CA tst r1,r1
    { const bool k = !c.t; c.t = (c.r[8] & c.r[8]) == 0; if (k) { goto L_06064310; } }  // 060642CC bf/s 0x06064310 ; tst r8,r8
L_060642D0:
    if (!c.t) { goto L_060642DA; }  // 060642D0 bf 0x060642DA
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 060642D2 mov.b @r6,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060642D4 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060642D6 tst r1,r1
    if (c.t) { goto L_060642FE; }  // 060642D8 bt 0x060642FE
L_060642DA:
    c.t = (c.r[8] & c.r[8]) == 0; goto L_060642F4;  // 060642DA bra 0x060642F4 ; tst r8,r8
L_060642F4:
    if (c.t) { goto L_06064310; }  // 060642F4 bt 0x06064310
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 060642F6 mov.b @r6,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060642F8 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060642FA tst r1,r1
    if (c.t) { goto L_06064310; }  // 060642FC bt 0x06064310
L_060642FE:
    c.r[1] = ld32(c.r[5]);  // 060642FE mov.l @r5,r1
    c.r[1] += c.r[3];  // 06064300 add r3,r1
    c.r[1] += 4;  // 06064302 add #4,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06064304 mov.b @r1,r0
    c.r[0] &= 0x60u;  // 06064306 and #96,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06064308 tst r0,r0
    if (!c.t) { goto L_06064310; }  // 0606430A bf 0x06064310
    goto L_06064B3A;  // 0606430C bra 0x06064B3A ; nop
L_06064310:
    c.r[3] += 16;  // 06064310 add #16,r3
    c.r[10] += 1;  // 06064312 add #1,r10
    c.r[1] = 0x49u;  // 06064314 mov #73,r1
    c.t = (int32_t)c.r[10] > (int32_t)c.r[1];  // 06064316 cmp/gt r1,r10
    { const bool k = !c.t; c.r[2] += 16; if (k) { SH2_POLL(c); goto L_0606429A; } }  // 06064318 bf/s 0x0606429A ; add #16,r2
    goto L_06064C1A;  // 0606431C bra 0x06064C1A ; nop
L_06064320:
    c.r[3] = ld32(0x06064418u);  // 06064320 mov.l 0x06064418,r3
    c.r[2] = ld32(c.r[3]);  // 06064322 mov.l @r3,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06064410u);  // 06064324 mov.w 0x06064410,r0
    c.r[1] = 0x0u;  // 06064326 mov #0,r1
    c.r[10] = 0x0u;  // 06064328 mov #0,r10
    c.r[8] = ld32(0x0606441Cu);  // 0606432A mov.l 0x0606441C,r8
    c.r[9] = (uint32_t)(int16_t)ld16(0x06064412u);  // 0606432C mov.w 0x06064412,r9
    c.r[4] = c.r[0];  // 0606432E mov r0,r4
    c.r[5] = 0x0u;  // 06064330 mov #0,r5
    st8(c.r[0] + c.r[2], c.r[1]);  // 06064332 mov.b r1,@(r0,r2)
L_06064334:
    c.r[0] = ld32(c.r[8]);  // 06064334 mov.l @r8,r0
    c.r[2] = c.r[5];  // 06064336 mov r5,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 06064338 mov.b @(r0,r5),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606433A extu.b r1,r1
    c.t = c.r[1] == c.r[9];  // 0606433C cmp/eq r9,r1
    { const bool k = c.t; c.r[2] += c.r[0]; if (k) { goto L_06064402; } }  // 0606433E bt/s 0x06064402 ; add r0,r2
    c.r[1] = c.r[2];  // 06064342 mov r2,r1
    c.r[1] += 7;  // 06064344 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06064346 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06064348 mov r1,r0
    c.r[0] >>= 2;  // 0606434A shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0606434C shlr r0
    c.r[0] &= 0x1u;  // 0606434E and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06064350 tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[2]; if (k) { goto L_06064402; } }  // 06064352 bf/s 0x06064402 ; mov r2,r1
    c.r[1] += 3;  // 06064356 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06064358 mov.b @r1,r1
    c.r[0] = 0x3u;  // 0606435A mov #3,r0
    c.r[7] = c.r[1];  // 0606435C mov r1,r7
    c.t = c.r[7] & 1; c.r[7] >>= 1;  // 0606435E shlr r7
    c.r[7] &= c.r[0];  // 06064360 and r0,r7
    c.t = (c.r[7] & c.r[7]) == 0;  // 06064362 tst r7,r7
    if (!c.t) { goto L_0606436E; }  // 06064364 bf 0x0606436E
    c.r[1] = ld32(c.r[2] + 12);  // 06064366 mov.l @(12,r2),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06064368 tst r1,r1
    { const bool k = !c.t; c.t = (c.r[7] & c.r[7]) == 0; if (k) { goto L_06064402; } }  // 0606436A bf/s 0x06064402 ; tst r7,r7
L_0606436E:
    if (!c.t) { goto L_0606437C; }  // 0606436E bf 0x0606437C
    c.r[1] = ld32(0x06064420u);  // 06064370 mov.l 0x06064420,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06064372 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06064374 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06064376 tst r1,r1
    { const bool k = c.t; c.t = (c.r[7] & c.r[7]) == 0; if (k) { goto L_06064388; } }  // 06064378 bt/s 0x06064388 ; tst r7,r7
L_0606437C:
    if (c.t) { goto L_06064402; }  // 0606437C bt 0x06064402
    c.r[1] = ld32(0x06064420u);  // 0606437E mov.l 0x06064420,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06064380 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06064382 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06064384 tst r1,r1
    if (c.t) { goto L_06064402; }  // 06064386 bt 0x06064402
L_06064388:
    c.r[2] = ld32(c.r[8]);  // 06064388 mov.l @r8,r2
    c.r[2] += c.r[5];  // 0606438A add r5,r2
    c.r[1] = c.r[2];  // 0606438C mov r2,r1
    c.r[1] += 4;  // 0606438E add #4,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06064390 mov.b @r1,r0
    c.r[0] &= 0x60u;  // 06064392 and #96,r0
    c.t = c.r[0] == 0x40u;  // 06064394 cmp/eq #64,r0
    { const bool k = !c.t; c.r[2] += 5; if (k) { goto L_06064402; } }  // 06064396 bf/s 0x06064402 ; add #5,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606439A mov.b @r2,r2
    c.r[1] = ld32(0x06064424u);  // 0606439C mov.l 0x06064424,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606439E mov.b @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 060643A0 extu.b r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 060643A2 extu.b r1,r1
    c.t = c.r[2] == c.r[1];  // 060643A4 cmp/eq r1,r2
    if (!c.t) { goto L_06064402; }  // 060643A6 bf 0x06064402
    c.r[2] = ld32(c.r[3]);  // 060643A8 mov.l @r3,r2
    c.r[0] = c.r[2];  // 060643AA mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[4]);  // 060643AC mov.b @(r0,r4),r1
    c.r[6] = c.r[1] & 0xFFu;  // 060643AE extu.b r1,r6
    c.r[6] += c.r[6];  // 060643B0 add r6,r6
    c.r[1] = c.r[10] & 0xFFFFu;  // 060643B2 extu.w r10,r1
    c.r[11] = c.r[1];  // 060643B4 mov r1,r11
    c.r[11] >>= 8;  // 060643B6 shlr8 r11
    c.r[0] = 0x7Fu;  // 060643B8 mov #127,r0
    c.r[11] &= c.r[0];  // 060643BA and r0,r11
    c.r[0] = c.r[2];  // 060643BC mov r2,r0
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 060643BE mov.b @(r0,r6),r7
    c.r[0] = (uint32_t)(int16_t)ld16(0x06064414u);  // 060643C0 mov.w 0x06064414,r0
    c.r[7] &= c.r[0];  // 060643C2 and r0,r7
    c.r[7] |= c.r[11];  // 060643C4 or r11,r7
    c.r[0] = c.r[2];  // 060643C6 mov r2,r0
    st8(c.r[0] + c.r[6], c.r[7]);  // 060643C8 mov.b r7,@(r0,r6)
    c.r[2] += c.r[6];  // 060643CA add r6,r2
    c.r[2] += 1;  // 060643CC add #1,r2
    st8(c.r[2], c.r[1]);  // 060643CE mov.b r1,@r2
    c.r[1] = ld32(c.r[8]);  // 060643D0 mov.l @r8,r1
    c.r[1] += c.r[5];  // 060643D2 add r5,r1
    c.r[1] += 7;  // 060643D4 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060643D6 mov.b @r1,r1
    c.r[0] = 0x1u;  // 060643D8 mov #1,r0
    c.r[1] >>= 2;  // 060643DA shlr2 r1
    c.r[1] >>= 2;  // 060643DC shlr2 r1
    c.r[1] &= c.r[0];  // 060643DE and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060643E0 tst r1,r1
    if (c.t) { goto L_060643F8; }  // 060643E2 bt 0x060643F8
    c.r[2] = ld32(c.r[3]);  // 060643E4 mov.l @r3,r2
    c.r[0] = c.r[2];  // 060643E6 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[4]);  // 060643E8 mov.b @(r0,r4),r1
    c.r[1] = c.r[1] & 0xFFu;  // 060643EA extu.b r1,r1
    c.r[1] += c.r[1];  // 060643EC add r1,r1
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060643EE mov.b @(r0,r1),r7
    c.r[0] = (uint32_t)(int16_t)ld16(0x06064414u);  // 060643F0 mov.w 0x06064414,r0
    c.r[7] |= c.r[0];  // 060643F2 or r0,r7
    c.r[0] = c.r[2];  // 060643F4 mov r2,r0
    st8(c.r[0] + c.r[1], c.r[7]);  // 060643F6 mov.b r7,@(r0,r1)
L_060643F8:
    c.r[2] = ld32(c.r[3]);  // 060643F8 mov.l @r3,r2
    c.r[0] = c.r[2];  // 060643FA mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[4]);  // 060643FC mov.b @(r0,r4),r1
    c.r[1] += 1;  // 060643FE add #1,r1
    st8(c.r[0] + c.r[4], c.r[1]);  // 06064400 mov.b r1,@(r0,r4)
L_06064402:
    c.r[10] += 1;  // 06064402 add #1,r10
    c.r[1] = 0x49u;  // 06064404 mov #73,r1
    c.t = (int32_t)c.r[10] > (int32_t)c.r[1];  // 06064406 cmp/gt r1,r10
    { const bool k = !c.t; c.r[5] += 16; if (k) { SH2_POLL(c); goto L_06064334; } }  // 06064408 bf/s 0x06064334 ; add #16,r5
    goto L_06064C1A;  // 0606440C bra 0x06064C1A ; nop
L_06064428:
    c.r[1] = ld32(0x0606455Cu);  // 06064428 mov.l 0x0606455C,r1
    c.r[2] = ld32(c.r[1]);  // 0606442A mov.l @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06064550u);  // 0606442C mov.w 0x06064550,r0
    c.r[10] = 0x0u;  // 0606442E mov #0,r10
    c.r[11] = ld32(0x06064560u);  // 06064430 mov.l 0x06064560,r11
    c.r[9] = 0x0u;  // 06064432 mov #0,r9
    c.r[1] = 0x0u;  // 06064434 mov #0,r1
    st8(c.r[0] + c.r[2], c.r[1]);  // 06064436 mov.b r1,@(r0,r2)
L_06064438:
    c.r[1] = ld32(0x06064564u);  // 06064438 mov.l 0x06064564,r1
    c.r[3] = ld32(c.r[1]);  // 0606443A mov.l @r1,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x06064552u);  // 0606443C mov.w 0x06064552,r1
    c.r[3] += c.r[1];  // 0606443E add r1,r3
    c.r[1] = c.r[10];  // 06064440 mov r10,r1
    c.r[1] <<= 2;  // 06064442 shll2 r1
    c.r[1] += c.r[1];  // 06064444 add r1,r1
    c.r[3] += c.r[1];  // 06064446 add r1,r3
    c.r[1] = ld32(0x0606455Cu);  // 06064448 mov.l 0x0606455C,r1
    c.r[2] = ld32(c.r[1]);  // 0606444A mov.l @r1,r2
    c.r[1] = c.r[10];  // 0606444C mov r10,r1
    c.r[1] += c.r[1];  // 0606444E add r1,r1
    c.r[2] += c.r[1];  // 06064450 add r1,r2
    c.r[2] += 1;  // 06064452 add #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06064454 mov.b @r2,r1
    c.r[3] += 4;  // 06064456 add #4,r3
    st8(c.r[3], c.r[1]);  // 06064458 mov.b r1,@r3
    c.r[3] = c.r[9];  // 0606445A mov r9,r3
    c.r[0] = ld32(c.r[11]);  // 0606445C mov.l @r11,r0
    c.r[2] = (uint32_t)(int16_t)ld16(0x06064554u);  // 0606445E mov.w 0x06064554,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 06064460 mov.b @(r0,r9),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06064462 extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 06064464 cmp/eq r2,r1
    { const bool k = c.t; c.r[3] += c.r[0]; if (k) { goto L_0606452C; } }  // 06064466 bt/s 0x0606452C ; add r0,r3
    c.r[1] = c.r[3];  // 0606446A mov r3,r1
    c.r[1] += 3;  // 0606446C add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606446E mov.b @r1,r1
    c.r[0] = 0x3u;  // 06064470 mov #3,r0
    c.r[2] = c.r[1];  // 06064472 mov r1,r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 06064474 shlr r2
    c.r[2] &= c.r[0];  // 06064476 and r0,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06064478 tst r2,r2
    if (!c.t) { goto L_06064482; }  // 0606447A bf 0x06064482
    c.r[1] = ld32(c.r[3] + 12);  // 0606447C mov.l @(12,r3),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606447E tst r1,r1
    if (!c.t) { goto L_0606452C; }  // 06064480 bf 0x0606452C
L_06064482:
    c.r[3] += 7;  // 06064482 add #7,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06064484 mov.b @r3,r1
    c.r[0] = c.r[1];  // 06064486 mov r1,r0
    c.r[0] >>= 2;  // 06064488 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0606448A shlr r0
    c.r[0] &= 0x1u;  // 0606448C and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0606448E tst r0,r0
    { const bool k = c.t; c.t = (c.r[2] & c.r[2]) == 0; if (k) { goto L_0606452C; } }  // 06064490 bt/s 0x0606452C ; tst r2,r2
    if (!c.t) { goto L_060644A2; }  // 06064494 bf 0x060644A2
    c.r[1] = ld32(0x06064568u);  // 06064496 mov.l 0x06064568,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06064498 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606449A extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606449C tst r1,r1
    { const bool k = c.t; c.t = (c.r[2] & c.r[2]) == 0; if (k) { goto L_060644AE; } }  // 0606449E bt/s 0x060644AE ; tst r2,r2
L_060644A2:
    if (c.t) { goto L_0606452C; }  // 060644A2 bt 0x0606452C
    c.r[1] = ld32(0x06064568u);  // 060644A4 mov.l 0x06064568,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060644A6 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060644A8 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060644AA tst r1,r1
    if (c.t) { goto L_0606452C; }  // 060644AC bt 0x0606452C
L_060644AE:
    c.r[1] = ld32(c.r[11]);  // 060644AE mov.l @r11,r1
    c.r[1] += c.r[9];  // 060644B0 add r9,r1
    c.r[1] += 4;  // 060644B2 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060644B4 mov.b @r1,r1
    c.r[0] = c.r[1];  // 060644B6 mov r1,r0
    c.r[0] >>= 2;  // 060644B8 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060644BA shlr r0
    c.r[0] >>= 2;  // 060644BC shlr2 r0
    c.r[0] &= 0x1u;  // 060644BE and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060644C0 tst r0,r0
    { const bool k = !c.t; c.r[4] = c.r[14]; if (k) { goto L_0606452C; } }  // 060644C2 bf/s 0x0606452C ; mov r14,r4
    c.r[1] = ld32(0x0606455Cu);  // 060644C6 mov.l 0x0606455C,r1
    c.r[3] = ld32(c.r[1]);  // 060644C8 mov.l @r1,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x06064550u);  // 060644CA mov.w 0x06064550,r7
    c.r[0] = c.r[3];  // 060644CC mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 060644CE mov.b @(r0,r7),r2
    c.r[1] = c.r[2];  // 060644D0 mov r2,r1
    c.r[1] += 1;  // 060644D2 add #1,r1
    st8(c.r[0] + c.r[7], c.r[1]);  // 060644D4 mov.b r1,@(r0,r7)
    c.r[7] = c.r[2] & 0xFFu;  // 060644D6 extu.b r2,r7
    c.r[7] += c.r[7];  // 060644D8 add r7,r7
    c.r[1] = c.r[10] & 0xFFFFu;  // 060644DA extu.w r10,r1
    c.r[6] = c.r[1];  // 060644DC mov r1,r6
    c.r[6] >>= 8;  // 060644DE shlr8 r6
    c.r[0] = 0x7Fu;  // 060644E0 mov #127,r0
    c.r[6] &= c.r[0];  // 060644E2 and r0,r6
    c.r[0] = c.r[3];  // 060644E4 mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 060644E6 mov.b @(r0,r7),r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06064556u);  // 060644E8 mov.w 0x06064556,r0
    c.r[2] &= c.r[0];  // 060644EA and r0,r2
    c.r[2] |= c.r[6];  // 060644EC or r6,r2
    c.r[0] = c.r[3];  // 060644EE mov r3,r0
    st8(c.r[0] + c.r[7], c.r[2]);  // 060644F0 mov.b r2,@(r0,r7)
    c.r[3] += c.r[7];  // 060644F2 add r7,r3
    c.r[3] += 1;  // 060644F4 add #1,r3
    st8(c.r[3], c.r[1]);  // 060644F6 mov.b r1,@r3
    c.r[1] = ld32(c.r[11]);  // 060644F8 mov.l @r11,r1
    c.r[1] += c.r[9];  // 060644FA add r9,r1
    c.r[1] += 2;  // 060644FC add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060644FE mov.b @r1,r1
    c.r[6] = (uint32_t)(int16_t)ld16(0x06064554u);  // 06064500 mov.w 0x06064554,r6
    c.r[8] = c.r[1] & 0xFFu;  // 06064502 extu.b r1,r8
    c.r[1] = ld32(0x0606456Cu);  // 06064504 mov.l 0x0606456C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0606450Au; c.r[5] = c.r[8] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0606450Au) return; }  // 06064506 jsr @r1 ; extu.b r8,r5
    c.r[1] = ld32(0x06064570u);  // 0606450A mov.l 0x06064570,r1
    c.r[2] = ld32(c.r[1]);  // 0606450C mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 0606450E mov #30,r1
    c.macl = c.r[8] * c.r[1];  // 06064510 mul.l r1,r8
    c.r[3] = c.macl;  // 06064512 sts macl,r3
    c.r[3] += c.r[2];  // 06064514 add r2,r3
    c.r[2] = c.r[3];  // 06064516 mov r3,r2
    c.r[1] = c.r[14];  // 06064518 mov r14,r1
    c.r[1] += 26;  // 0606451A add #26,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606451C mov.w @r1,r1
    c.r[2] += 22;  // 0606451E add #22,r2
    st16(c.r[2], c.r[1]);  // 06064520 mov.w r1,@r2
    c.r[1] = c.r[14];  // 06064522 mov r14,r1
    c.r[1] += 28;  // 06064524 add #28,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06064526 mov.w @r1,r1
    c.r[3] += 24;  // 06064528 add #24,r3
    st16(c.r[3], c.r[1]);  // 0606452A mov.w r1,@r3
L_0606452C:
    c.r[10] += 1;  // 0606452C add #1,r10
    c.r[1] = 0x49u;  // 0606452E mov #73,r1
    c.t = (int32_t)c.r[10] > (int32_t)c.r[1];  // 06064530 cmp/gt r1,r10
    { const bool k = !c.t; c.r[9] += 16; if (k) { SH2_POLL(c); goto L_06064438; } }  // 06064532 bf/s 0x06064438 ; add #16,r9
    c.r[1] = ld32(0x06064564u);  // 06064536 mov.l 0x06064564,r1
    c.r[3] = ld32(c.r[1]);  // 06064538 mov.l @r1,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x06064552u);  // 0606453A mov.w 0x06064552,r1
    c.r[3] += c.r[1];  // 0606453C add r1,r3
    c.r[1] = ld32(0x0606455Cu);  // 0606453E mov.l 0x0606455C,r1
    c.r[1] = ld32(c.r[1]);  // 06064540 mov.l @r1,r1
    c.r[7] = (uint32_t)(int16_t)ld16(0x06064550u);  // 06064542 mov.w 0x06064550,r7
    c.r[0] = c.r[1];  // 06064544 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06064546 mov.b @(r0,r7),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06064558u);  // 06064548 mov.w 0x06064558,r2
    c.r[0] = c.r[3];  // 0606454A mov r3,r0
    st8(c.r[0] + c.r[2], c.r[1]); goto L_06064C1A;  // 0606454C bra 0x06064C1A ; mov.b r1,@(r0,r2)
L_06064574:
    c.r[1] = ld32(0x060646B0u);  // 06064574 mov.l 0x060646B0,r1
    c.r[2] = ld32(c.r[1]);  // 06064576 mov.l @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x060646A8u);  // 06064578 mov.w 0x060646A8,r0
    c.r[10] = 0x0u;  // 0606457A mov #0,r10
    c.r[13] = ld32(0x060646B4u);  // 0606457C mov.l 0x060646B4,r13
    c.r[12] = (uint32_t)(int16_t)ld16(0x060646AAu);  // 0606457E mov.w 0x060646AA,r12
    c.r[11] = 0x0u;  // 06064580 mov #0,r11
    c.r[1] = 0x0u;  // 06064582 mov #0,r1
    st8(c.r[0] + c.r[2], c.r[1]);  // 06064584 mov.b r1,@(r0,r2)
L_06064586:
    c.r[1] = ld32(0x060646B8u);  // 06064586 mov.l 0x060646B8,r1
    c.r[0] = ld32(c.r[1]);  // 06064588 mov.l @r1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[11]);  // 0606458A mov.w @(r0,r11),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0606458C extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606458E tst r1,r1
    { const bool k = !c.t; c.r[8] = 0x0u; if (k) { goto L_06064598; } }  // 06064590 bf/s 0x06064598 ; mov #0,r8
    goto L_0606469E;  // 06064594 bra 0x0606469E ; nop
L_06064598:
    c.r[3] = ld32(c.r[13]);  // 06064598 mov.l @r13,r3
    c.r[7] = 0x49u;  // 0606459A mov #73,r7
    c.r[6] = 0x0u;  // 0606459C mov #0,r6
    c.r[2] = c.r[3];  // 0606459E mov r3,r2
L_060645A0:
    c.r[0] = c.r[6];  // 060645A0 mov r6,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 060645A2 mov.b @(r0,r3),r1
    c.r[1] = c.r[1] & 0xFFu;  // 060645A4 extu.b r1,r1
    c.t = c.r[1] == c.r[12];  // 060645A6 cmp/eq r12,r1
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_060645B8; } }  // 060645A8 bt/s 0x060645B8 ; mov r2,r1
    c.r[1] += 2;  // 060645AC add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060645AE mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060645B0 extu.b r1,r1
    c.t = c.r[1] == c.r[10];  // 060645B2 cmp/eq r10,r1
    { const bool k = c.t; c.r[0] = c.r[8]; if (k) { goto L_060645C4; } }  // 060645B4 bt/s 0x060645C4 ; mov r8,r0
L_060645B8:
    c.r[2] += 16;  // 060645B8 add #16,r2
    c.r[8] += 1;  // 060645BA add #1,r8
    c.t = (int32_t)c.r[8] > (int32_t)c.r[7];  // 060645BC cmp/gt r7,r8
    { const bool k = !c.t; c.r[6] += 16; if (k) { SH2_POLL(c); goto L_060645A0; } }  // 060645BE bf/s 0x060645A0 ; add #16,r6
    c.r[0] = c.r[8];  // 060645C2 mov r8,r0
L_060645C4:
    c.t = c.r[0] == 0x4Au;  // 060645C4 cmp/eq #74,r0
    if (!c.t) { goto L_0606469E; }  // 060645C6 bf 0x0606469E
    c.r[1] = ld32(0x060646B8u);  // 060645C8 mov.l 0x060646B8,r1
    c.r[1] = ld32(c.r[1]);  // 060645CA mov.l @r1,r1
    c.r[1] += c.r[11];  // 060645CC add r11,r1
    c.r[1] += 2;  // 060645CE add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060645D0 mov.b @r1,r1
    c.r[3] = c.r[1] & 0xFFu;  // 060645D2 extu.b r1,r3
    c.r[0] = c.r[3];  // 060645D4 mov r3,r0
    c.r[0] >>= 2;  // 060645D6 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060645D8 shlr r0
    c.r[0] >>= 2;  // 060645DA shlr2 r0
    c.r[0] &= 0x1u;  // 060645DC and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060645DE tst r0,r0
    { const bool k = !c.t; c.r[2] = c.r[3]; if (k) { goto L_0606469E; } }  // 060645E0 bf/s 0x0606469E ; mov r3,r2
    c.r[1] = ld32(0x060646BCu);  // 060645E4 mov.l 0x060646BC,r1
    c.r[1] = ld32(c.r[1]);  // 060645E6 mov.l @r1,r1
    c.r[1] += 8;  // 060645E8 add #8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060645EA mov.b @r1,r1
    c.r[2] >>= 2;  // 060645EC shlr2 r2
    c.r[2] >>= 2;  // 060645EE shlr2 r2
    c.r[2] >>= 2;  // 060645F0 shlr2 r2
    c.r[1] = c.r[1] & 0xFFu;  // 060645F2 extu.b r1,r1
    c.r[1] >>= 2;  // 060645F4 shlr2 r1
    c.r[1] >>= 2;  // 060645F6 shlr2 r1
    c.r[1] >>= 2;  // 060645F8 shlr2 r1
    c.t = c.r[2] == c.r[1];  // 060645FA cmp/eq r1,r2
    { const bool k = !c.t; c.r[0] = c.r[3]; if (k) { goto L_0606469E; } }  // 060645FC bf/s 0x0606469E ; mov r3,r0
    c.r[0] >>= 2;  // 06064600 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06064602 shlr r0
    c.r[2] = 0x3u;  // 06064604 mov #3,r2
    c.r[2] &= c.r[0];  // 06064606 and r0,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06064608 tst r2,r2
    if (!c.t) { goto L_06064618; }  // 0606460A bf 0x06064618
    c.r[1] = ld32(0x060646C0u);  // 0606460C mov.l 0x060646C0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606460E mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06064610 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06064612 tst r1,r1
    { const bool k = c.t; c.t = (c.r[2] & c.r[2]) == 0; if (k) { goto L_06064624; } }  // 06064614 bt/s 0x06064624 ; tst r2,r2
L_06064618:
    if (c.t) { goto L_0606469E; }  // 06064618 bt 0x0606469E
    c.r[1] = ld32(0x060646C0u);  // 0606461A mov.l 0x060646C0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606461C mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606461E extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06064620 tst r1,r1
    if (c.t) { goto L_0606469E; }  // 06064622 bt 0x0606469E
L_06064624:
    c.r[1] = ld32(0x060646B8u);  // 06064624 mov.l 0x060646B8,r1
    c.r[3] = ld32(c.r[1]);  // 06064626 mov.l @r1,r3
    c.r[2] = c.r[11];  // 06064628 mov r11,r2
    c.r[2] += c.r[3];  // 0606462A add r3,r2
    c.r[1] = c.r[2];  // 0606462C mov r2,r1
    c.r[1] += 15;  // 0606462E add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06064630 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06064632 extu.b r1,r1
    c.t = c.r[1] == c.r[12];  // 06064634 cmp/eq r12,r1
    { const bool k = c.t; c.r[2] += 16; if (k) { goto L_0606469E; } }  // 06064636 bt/s 0x0606469E ; add #16,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0606463A mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606463C extu.b r1,r1
    c.t = c.r[1] == c.r[12];  // 0606463E cmp/eq r12,r1
    { const bool k = !c.t; c.r[0] = c.r[11]; if (k) { goto L_0606469E; } }  // 06064640 bf/s 0x0606469E ; mov r11,r0
    c.r[9] = ld32(0x060646C4u);  // 06064644 mov.l 0x060646C4,r9
    c.r[5] = 0x1Bu;  // 06064646 mov #27,r5
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 06064648 mov.w @(r0,r3),r8
    c.r[4] = ld32(0x060646C8u);  // 0606464A mov.l 0x060646C8,r4
    { const uint32_t x = c.r[9]; c.pr = 0x06064650u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06064650u) return; }  // 0606464C jsr @r9 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 06064650 mov r0,r1
    c.r[5] = c.r[8];  // 06064652 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06064658u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06064658u) return; }  // 06064654 jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 06064658 mov r0,r1
    c.r[1] += 8;  // 0606465A add #8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606465C mov.b @r1,r1
    c.r[0] = 0x1u;  // 0606465E mov #1,r0
    c.r[1] >>= 2;  // 06064660 shlr2 r1
    c.r[1] >>= 2;  // 06064662 shlr2 r1
    c.r[1] >>= 2;  // 06064664 shlr2 r1
    c.r[1] &= c.r[0];  // 06064666 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06064668 tst r1,r1
    if (c.t) { goto L_0606469E; }  // 0606466A bt 0x0606469E
    c.r[1] = ld32(0x060646B0u);  // 0606466C mov.l 0x060646B0,r1
    c.r[3] = ld32(c.r[1]);  // 0606466E mov.l @r1,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x060646A8u);  // 06064670 mov.w 0x060646A8,r7
    c.r[0] = c.r[3];  // 06064672 mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06064674 mov.b @(r0,r7),r2
    c.r[1] = c.r[2];  // 06064676 mov r2,r1
    c.r[1] += 1;  // 06064678 add #1,r1
    st8(c.r[0] + c.r[7], c.r[1]);  // 0606467A mov.b r1,@(r0,r7)
    c.r[7] = c.r[2] & 0xFFu;  // 0606467C extu.b r2,r7
    c.r[7] += c.r[7];  // 0606467E add r7,r7
    c.r[1] = c.r[10] & 0xFFFFu;  // 06064680 extu.w r10,r1
    c.r[6] = c.r[1];  // 06064682 mov r1,r6
    c.r[6] >>= 8;  // 06064684 shlr8 r6
    c.r[0] = 0x7Fu;  // 06064686 mov #127,r0
    c.r[6] &= c.r[0];  // 06064688 and r0,r6
    c.r[0] = c.r[3];  // 0606468A mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0606468C mov.b @(r0,r7),r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x060646ACu);  // 0606468E mov.w 0x060646AC,r0
    c.r[2] &= c.r[0];  // 06064690 and r0,r2
    c.r[2] |= c.r[6];  // 06064692 or r6,r2
    c.r[0] = c.r[3];  // 06064694 mov r3,r0
    st8(c.r[0] + c.r[7], c.r[2]);  // 06064696 mov.b r2,@(r0,r7)
    c.r[3] += c.r[7];  // 06064698 add r7,r3
    c.r[3] += 1;  // 0606469A add #1,r3
    st8(c.r[3], c.r[1]);  // 0606469C mov.b r1,@r3
L_0606469E:
    c.r[11] += 30;  // 0606469E add #30,r11
    c.r[10] += 1;  // 060646A0 add #1,r10
    c.r[1] = 0x7Fu;  // 060646A2 mov #127,r1
    c.t = (int32_t)c.r[10] > (int32_t)c.r[1]; goto L_060646CC;  // 060646A4 bra 0x060646CC ; cmp/gt r1,r10
L_060646CC:
    if (c.t) { goto L_060646D2; }  // 060646CC bt 0x060646D2
    SH2_POLL(c); goto L_06064586;  // 060646CE bra 0x06064586 ; nop
L_060646D2:
    goto L_06064C1A;  // 060646D2 bra 0x06064C1A ; nop
L_060646D6:
    c.r[1] = ld32(0x06064820u);  // 060646D6 mov.l 0x06064820,r1
    c.r[2] = ld32(c.r[1]);  // 060646D8 mov.l @r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x0606481Au);  // 060646DA mov.w 0x0606481A,r3
    c.r[10] = 0x0u;  // 060646DC mov #0,r10
    c.r[13] = ld32(0x06064824u);  // 060646DE mov.l 0x06064824,r13
    c.r[11] = 0x0u;  // 060646E0 mov #0,r11
    c.r[1] = 0x0u;  // 060646E2 mov #0,r1
    c.r[0] = c.r[2];  // 060646E4 mov r2,r0
    st8(c.r[0] + c.r[3], c.r[1]);  // 060646E6 mov.b r1,@(r0,r3)
L_060646E8:
    c.r[0] = ld32(c.r[13]);  // 060646E8 mov.l @r13,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[11]);  // 060646EA mov.w @(r0,r11),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 060646EC extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060646EE tst r1,r1
    if (!c.t) { goto L_060646F6; }  // 060646F0 bf 0x060646F6
    goto L_0606487E;  // 060646F2 bra 0x0606487E ; nop
L_060646F6:
    c.r[8] = 0x0u;  // 060646F6 mov #0,r8
    c.r[1] = ld32(0x06064828u);  // 060646F8 mov.l 0x06064828,r1
    c.r[3] = ld32(c.r[1]);  // 060646FA mov.l @r1,r3
    c.r[7] = 0x49u;  // 060646FC mov #73,r7
    c.r[6] = 0x0u;  // 060646FE mov #0,r6
    c.r[2] = c.r[3];  // 06064700 mov r3,r2
L_06064702:
    c.r[0] = c.r[6];  // 06064702 mov r6,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06064704 mov.b @(r0,r3),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06064706 extu.b r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606481Cu);  // 06064708 mov.w 0x0606481C,r0
    c.t = c.r[1] == c.r[0];  // 0606470A cmp/eq r0,r1
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_0606471C; } }  // 0606470C bt/s 0x0606471C ; mov r2,r1
    c.r[1] += 2;  // 06064710 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06064712 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06064714 extu.b r1,r1
    c.t = c.r[1] == c.r[10];  // 06064716 cmp/eq r10,r1
    { const bool k = c.t; c.r[0] = c.r[8]; if (k) { goto L_06064728; } }  // 06064718 bt/s 0x06064728 ; mov r8,r0
L_0606471C:
    c.r[2] += 16;  // 0606471C add #16,r2
    c.r[8] += 1;  // 0606471E add #1,r8
    c.t = (int32_t)c.r[8] > (int32_t)c.r[7];  // 06064720 cmp/gt r7,r8
    { const bool k = !c.t; c.r[6] += 16; if (k) { SH2_POLL(c); goto L_06064702; } }  // 06064722 bf/s 0x06064702 ; add #16,r6
    c.r[0] = c.r[8];  // 06064726 mov r8,r0
L_06064728:
    c.t = c.r[0] == 0x4Au;  // 06064728 cmp/eq #74,r0
    if (c.t) { goto L_06064730; }  // 0606472A bt 0x06064730
    goto L_0606487E;  // 0606472C bra 0x0606487E ; nop
L_06064730:
    c.r[1] = ld32(c.r[13]);  // 06064730 mov.l @r13,r1
    c.r[1] += c.r[11];  // 06064732 add r11,r1
    c.r[1] += 2;  // 06064734 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06064736 mov.b @r1,r1
    c.r[3] = c.r[1] & 0xFFu;  // 06064738 extu.b r1,r3
    c.r[0] = c.r[3];  // 0606473A mov r3,r0
    c.r[0] >>= 2;  // 0606473C shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0606473E shlr r0
    c.r[0] >>= 2;  // 06064740 shlr2 r0
    c.r[0] &= 0x1u;  // 06064742 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06064744 tst r0,r0
    if (c.t) { goto L_0606474C; }  // 06064746 bt 0x0606474C
    goto L_0606487E;  // 06064748 bra 0x0606487E ; nop
L_0606474C:
    c.r[2] = c.r[3];  // 0606474C mov r3,r2
    c.r[1] = ld32(0x0606482Cu);  // 0606474E mov.l 0x0606482C,r1
    c.r[1] = ld32(c.r[1]);  // 06064750 mov.l @r1,r1
    c.r[1] += 8;  // 06064752 add #8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06064754 mov.b @r1,r1
    c.r[2] >>= 2;  // 06064756 shlr2 r2
    c.r[2] >>= 2;  // 06064758 shlr2 r2
    c.r[2] >>= 2;  // 0606475A shlr2 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0606475C extu.b r1,r1
    c.r[1] >>= 2;  // 0606475E shlr2 r1
    c.r[1] >>= 2;  // 06064760 shlr2 r1
    c.r[1] >>= 2;  // 06064762 shlr2 r1
    c.t = c.r[2] == c.r[1];  // 06064764 cmp/eq r1,r2
    { const bool k = c.t; c.r[0] = c.r[3]; if (k) { goto L_0606476E; } }  // 06064766 bt/s 0x0606476E ; mov r3,r0
    goto L_0606487E;  // 0606476A bra 0x0606487E ; nop
L_0606476E:
    c.r[0] >>= 2;  // 0606476E shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06064770 shlr r0
    c.r[2] = 0x3u;  // 06064772 mov #3,r2
    c.r[2] &= c.r[0];  // 06064774 and r0,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06064776 tst r2,r2
    if (!c.t) { goto L_06064786; }  // 06064778 bf 0x06064786
    c.r[1] = ld32(0x06064830u);  // 0606477A mov.l 0x06064830,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606477C mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606477E extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06064780 tst r1,r1
    { const bool k = c.t; c.t = (c.r[2] & c.r[2]) == 0; if (k) { goto L_06064792; } }  // 06064782 bt/s 0x06064792 ; tst r2,r2
L_06064786:
    if (c.t) { goto L_0606487E; }  // 06064786 bt 0x0606487E
    c.r[1] = ld32(0x06064830u);  // 06064788 mov.l 0x06064830,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606478A mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606478C extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606478E tst r1,r1
    if (c.t) { goto L_0606487E; }  // 06064790 bt 0x0606487E
L_06064792:
    c.r[3] = ld32(c.r[13]);  // 06064792 mov.l @r13,r3
    c.r[2] = c.r[11];  // 06064794 mov r11,r2
    c.r[2] += c.r[3];  // 06064796 add r3,r2
    c.r[1] = c.r[2];  // 06064798 mov r2,r1
    c.r[1] += 15;  // 0606479A add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606479C mov.b @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606481Cu);  // 0606479E mov.w 0x0606481C,r0
    c.r[1] = c.r[1] & 0xFFu;  // 060647A0 extu.b r1,r1
    c.t = c.r[1] == c.r[0];  // 060647A2 cmp/eq r0,r1
    if (c.t) { goto L_0606487E; }  // 060647A4 bt 0x0606487E
    c.r[2] += 16;  // 060647A6 add #16,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060647A8 mov.b @r2,r1
    c.r[12] = c.r[1] & 0xFFu;  // 060647AA extu.b r1,r12
    c.t = c.r[12] == c.r[0];  // 060647AC cmp/eq r0,r12
    { const bool k = !c.t; c.r[0] = c.r[11]; if (k) { goto L_0606487E; } }  // 060647AE bf/s 0x0606487E ; mov r11,r0
    c.r[9] = ld32(0x06064834u);  // 060647B2 mov.l 0x06064834,r9
    c.r[5] = 0x1Bu;  // 060647B4 mov #27,r5
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 060647B6 mov.w @(r0,r3),r8
    c.r[4] = ld32(0x06064838u);  // 060647B8 mov.l 0x06064838,r4
    { const uint32_t x = c.r[9]; c.pr = 0x060647BEu; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060647BEu) return; }  // 060647BA jsr @r9 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 060647BE mov r0,r1
    c.r[5] = c.r[8];  // 060647C0 mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x060647C6u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060647C6u) return; }  // 060647C2 jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 060647C6 mov r0,r1
    c.r[1] += 8;  // 060647C8 add #8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060647CA mov.b @r1,r1
    c.r[0] = 0x1u;  // 060647CC mov #1,r0
    c.r[1] >>= 2;  // 060647CE shlr2 r1
    c.r[1] >>= 2;  // 060647D0 shlr2 r1
    c.r[1] >>= 2;  // 060647D2 shlr2 r1
    c.r[1] &= c.r[0];  // 060647D4 and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060647D6 tst r1,r1
    if (!c.t) { goto L_0606487E; }  // 060647D8 bf 0x0606487E
    c.r[1] = ld32(0x06064820u);  // 060647DA mov.l 0x06064820,r1
    c.r[3] = ld32(c.r[1]);  // 060647DC mov.l @r1,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x0606481Au);  // 060647DE mov.w 0x0606481A,r7
    c.r[0] = c.r[3];  // 060647E0 mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 060647E2 mov.b @(r0,r7),r2
    c.r[1] = c.r[2];  // 060647E4 mov r2,r1
    c.r[1] += 1;  // 060647E6 add #1,r1
    st8(c.r[0] + c.r[7], c.r[1]);  // 060647E8 mov.b r1,@(r0,r7)
    c.r[7] = c.r[2] & 0xFFu;  // 060647EA extu.b r2,r7
    c.r[7] += c.r[7];  // 060647EC add r7,r7
    c.r[1] = c.r[10] & 0xFFFFu;  // 060647EE extu.w r10,r1
    c.r[6] = c.r[1];  // 060647F0 mov r1,r6
    c.r[6] >>= 8;  // 060647F2 shlr8 r6
    c.r[0] = 0x7Fu;  // 060647F4 mov #127,r0
    c.r[6] &= c.r[0];  // 060647F6 and r0,r6
    c.r[0] = c.r[3];  // 060647F8 mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 060647FA mov.b @(r0,r7),r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0606481Eu);  // 060647FC mov.w 0x0606481E,r0
    c.r[2] &= c.r[0];  // 060647FE and r0,r2
    c.r[2] |= c.r[6];  // 06064800 or r6,r2
    c.r[0] = c.r[3];  // 06064802 mov r3,r0
    st8(c.r[0] + c.r[7], c.r[2]);  // 06064804 mov.b r2,@(r0,r7)
    c.r[3] += c.r[7];  // 06064806 add r7,r3
    c.r[3] += 1;  // 06064808 add #1,r3
    st8(c.r[3], c.r[1]);  // 0606480A mov.b r1,@r3
    c.r[1] = ld32(c.r[13]);  // 0606480C mov.l @r13,r1
    c.r[0] = c.r[11];  // 0606480E mov r11,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06064810 mov.w @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06064812 extu.w r1,r1
    c.r[0] = c.r[1];  // 06064814 mov r1,r0
    c.t = c.r[0] == 0xEu; goto L_0606483C;  // 06064816 bra 0x0606483C ; cmp/eq #14,r0
L_0606483C:
    if (!c.t) { goto L_0606487E; }  // 0606483C bf 0x0606487E
    c.r[5] = c.r[10] & 0xFFu;  // 0606483E extu.b r10,r5
    c.r[1] = ld32(0x0606495Cu);  // 06064840 mov.l 0x0606495C,r1
    c.r[6] = c.r[12];  // 06064842 mov r12,r6
    { const uint32_t x = c.r[1]; c.pr = 0x06064848u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06064848u) return; }  // 06064844 jsr @r1 ; mov r14,r4
    c.r[1] = c.r[14];  // 06064848 mov r14,r1
    c.r[1] += 37;  // 0606484A add #37,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0606484C mov.b @r1,r4
    c.r[0] = ld32(0x06064960u);  // 0606484E mov.l 0x06064960,r0
    c.r[4] = c.r[4] & 0xFFu;  // 06064850 extu.b r4,r4
    c.r[4] >>= 2;  // 06064852 shlr2 r4
    { const uint32_t x = c.r[0]; c.pr = 0x06064858u; c.r[4] >>= 2; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06064858u) return; }  // 06064854 jsr @r0 ; shlr2 r4
    c.r[1] = c.r[0] & 0xFFu;  // 06064858 extu.b r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0606485A tst r1,r1
    if (!c.t) { goto L_0606487E; }  // 0606485C bf 0x0606487E
    c.r[3] = ld32(c.r[13]);  // 0606485E mov.l @r13,r3
    c.r[3] += c.r[11];  // 06064860 add r11,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06064862 mov.w @r3,r1
    c.r[2] = c.r[3];  // 06064864 mov r3,r2
    c.r[1] += 1;  // 06064866 add #1,r1
    st16(c.r[3], c.r[1]);  // 06064868 mov.w r1,@r3
    c.r[1] = c.r[14];  // 0606486A mov r14,r1
    c.r[1] += 26;  // 0606486C add #26,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0606486E mov.w @r1,r1
    c.r[2] += 22;  // 06064870 add #22,r2
    st16(c.r[2], c.r[1]);  // 06064872 mov.w r1,@r2
    c.r[1] = c.r[14];  // 06064874 mov r14,r1
    c.r[1] += 28;  // 06064876 add #28,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06064878 mov.w @r1,r1
    c.r[3] += 24;  // 0606487A add #24,r3
    st16(c.r[3], c.r[1]);  // 0606487C mov.w r1,@r3
L_0606487E:
    c.r[10] += 1;  // 0606487E add #1,r10
    c.r[1] = 0x7Fu;  // 06064880 mov #127,r1
    c.t = (int32_t)c.r[10] > (int32_t)c.r[1];  // 06064882 cmp/gt r1,r10
    { const bool k = c.t; c.r[11] += 30; if (k) { goto L_0606488C; } }  // 06064884 bt/s 0x0606488C ; add #30,r11
    SH2_POLL(c); goto L_060646E8;  // 06064888 bra 0x060646E8 ; nop
L_0606488C:
    goto L_06064C1A;  // 0606488C bra 0x06064C1A ; nop
L_06064890:
    c.r[1] = ld32(0x06064964u);  // 06064890 mov.l 0x06064964,r1
    c.r[2] = ld32(c.r[1]);  // 06064892 mov.l @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06064954u);  // 06064894 mov.w 0x06064954,r0
    c.r[10] = 0x0u;  // 06064896 mov #0,r10
    c.r[4] = ld32(0x06064968u);  // 06064898 mov.l 0x06064968,r4
    c.r[8] = (uint32_t)(int16_t)ld16(0x06064956u);  // 0606489A mov.w 0x06064956,r8
    c.r[5] = ld32(0x0606496Cu);  // 0606489C mov.l 0x0606496C,r5
    c.r[6] = 0x0u;  // 0606489E mov #0,r6
    c.r[1] = 0x0u;  // 060648A0 mov #0,r1
    st8(c.r[0] + c.r[2], c.r[1]);  // 060648A2 mov.b r1,@(r0,r2)
L_060648A4:
    c.r[0] = ld32(c.r[4]);  // 060648A4 mov.l @r4,r0
    c.r[2] = c.r[6];  // 060648A6 mov r6,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 060648A8 mov.b @(r0,r6),r1
    c.r[1] = c.r[1] & 0xFFu;  // 060648AA extu.b r1,r1
    c.t = c.r[1] == c.r[8];  // 060648AC cmp/eq r8,r1
    { const bool k = c.t; c.r[2] += c.r[0]; if (k) { goto L_06064946; } }  // 060648AE bt/s 0x06064946 ; add r0,r2
    c.r[1] = c.r[2];  // 060648B2 mov r2,r1
    c.r[1] += 7;  // 060648B4 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060648B6 mov.b @r1,r1
    c.r[0] = c.r[1];  // 060648B8 mov r1,r0
    c.r[0] >>= 2;  // 060648BA shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060648BC shlr r0
    c.r[0] &= 0x1u;  // 060648BE and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060648C0 tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[2]; if (k) { goto L_06064946; } }  // 060648C2 bf/s 0x06064946 ; mov r2,r1
    c.r[1] += 3;  // 060648C6 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060648C8 mov.b @r1,r1
    c.r[0] = 0x3u;  // 060648CA mov #3,r0
    c.r[3] = c.r[1];  // 060648CC mov r1,r3
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 060648CE shlr r3
    c.r[3] &= c.r[0];  // 060648D0 and r0,r3
    c.t = (c.r[3] & c.r[3]) == 0;  // 060648D2 tst r3,r3
    if (!c.t) { goto L_060648DE; }  // 060648D4 bf 0x060648DE
    c.r[1] = ld32(c.r[2] + 12);  // 060648D6 mov.l @(12,r2),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060648D8 tst r1,r1
    { const bool k = !c.t; c.t = (c.r[3] & c.r[3]) == 0; if (k) { goto L_06064946; } }  // 060648DA bf/s 0x06064946 ; tst r3,r3
L_060648DE:
    if (!c.t) { goto L_060648E8; }  // 060648DE bf 0x060648E8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[5]);  // 060648E0 mov.b @r5,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060648E2 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060648E4 tst r1,r1
    if (c.t) { goto L_060648FE; }  // 060648E6 bt 0x060648FE
L_060648E8:
    c.r[2] += 4;  // 060648E8 add #4,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060648EA mov.b @r2,r1
    c.r[0] = c.r[1];  // 060648EC mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060648EE shlr r0
    c.r[0] &= 0x1u;  // 060648F0 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060648F2 tst r0,r0
    if (c.t) { goto L_06064946; }  // 060648F4 bt 0x06064946
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[5]);  // 060648F6 mov.b @r5,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060648F8 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060648FA tst r1,r1
    if (c.t) { goto L_06064946; }  // 060648FC bt 0x06064946
L_060648FE:
    c.r[1] = ld32(c.r[4]);  // 060648FE mov.l @r4,r1
    c.r[1] += c.r[6];  // 06064900 add r6,r1
    c.r[1] += 4;  // 06064902 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06064904 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06064906 mov r1,r0
    c.r[0] >>= 2;  // 06064908 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0606490A shlr r0
    c.r[0] >>= 2;  // 0606490C shlr2 r0
    c.r[0] &= 0x1u;  // 0606490E and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06064910 tst r0,r0
    if (!c.t) { goto L_06064946; }  // 06064912 bf 0x06064946
    c.r[1] = ld32(0x06064964u);  // 06064914 mov.l 0x06064964,r1
    c.r[3] = ld32(c.r[1]);  // 06064916 mov.l @r1,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x06064954u);  // 06064918 mov.w 0x06064954,r7
    c.r[0] = c.r[3];  // 0606491A mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0606491C mov.b @(r0,r7),r2
    c.r[1] = c.r[2];  // 0606491E mov r2,r1
    c.r[1] += 1;  // 06064920 add #1,r1
    st8(c.r[0] + c.r[7], c.r[1]);  // 06064922 mov.b r1,@(r0,r7)
    c.r[7] = c.r[2] & 0xFFu;  // 06064924 extu.b r2,r7
    c.r[7] += c.r[7];  // 06064926 add r7,r7
    c.r[1] = c.r[10] & 0xFFFFu;  // 06064928 extu.w r10,r1
    c.r[9] = c.r[1];  // 0606492A mov r1,r9
    c.r[9] >>= 8;  // 0606492C shlr8 r9
    c.r[0] = 0x7Fu;  // 0606492E mov #127,r0
    c.r[9] &= c.r[0];  // 06064930 and r0,r9
    c.r[0] = c.r[3];  // 06064932 mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06064934 mov.b @(r0,r7),r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06064958u);  // 06064936 mov.w 0x06064958,r0
    c.r[2] &= c.r[0];  // 06064938 and r0,r2
    c.r[2] |= c.r[9];  // 0606493A or r9,r2
    c.r[0] = c.r[3];  // 0606493C mov r3,r0
    st8(c.r[0] + c.r[7], c.r[2]);  // 0606493E mov.b r2,@(r0,r7)
    c.r[3] += c.r[7];  // 06064940 add r7,r3
    c.r[3] += 1;  // 06064942 add #1,r3
    st8(c.r[3], c.r[1]);  // 06064944 mov.b r1,@r3
L_06064946:
    c.r[10] += 1;  // 06064946 add #1,r10
    c.r[1] = 0x49u;  // 06064948 mov #73,r1
    c.t = (int32_t)c.r[10] > (int32_t)c.r[1];  // 0606494A cmp/gt r1,r10
    { const bool k = !c.t; c.r[6] += 16; if (k) { SH2_POLL(c); goto L_060648A4; } }  // 0606494C bf/s 0x060648A4 ; add #16,r6
    goto L_06064C1A;  // 06064950 bra 0x06064C1A ; nop
L_06064970:
    c.r[1] = ld32(0x06064A3Cu);  // 06064970 mov.l 0x06064A3C,r1
    c.r[2] = ld32(c.r[1]);  // 06064972 mov.l @r1,r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x06064A38u);  // 06064974 mov.w 0x06064A38,r3
    c.r[10] = 0x0u;  // 06064976 mov #0,r10
    c.r[12] = ld32(0x06064A40u);  // 06064978 mov.l 0x06064A40,r12
    c.r[13] = 0x1Eu;  // 0606497A mov #30,r13
    c.r[9] = 0x0u;  // 0606497C mov #0,r9
    c.r[1] = 0x0u;  // 0606497E mov #0,r1
    c.r[0] = c.r[2];  // 06064980 mov r2,r0
    st8(c.r[0] + c.r[3], c.r[1]);  // 06064982 mov.b r1,@(r0,r3)
L_06064984:
    c.r[3] = c.r[9];  // 06064984 mov r9,r3
    c.r[0] = ld32(c.r[12]);  // 06064986 mov.l @r12,r0
    c.r[2] = (uint32_t)(int16_t)ld16(0x06064A3Au);  // 06064988 mov.w 0x06064A3A,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 0606498A mov.b @(r0,r9),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0606498C extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 0606498E cmp/eq r2,r1
    { const bool k = !c.t; c.r[3] += c.r[0]; if (k) { goto L_06064998; } }  // 06064990 bf/s 0x06064998 ; add r0,r3
    goto L_06064B28;  // 06064994 bra 0x06064B28 ; nop
L_06064998:
    c.r[3] += 2;  // 06064998 add #2,r3
    c.r[0] = ld32(0x06064A44u);  // 0606499A mov.l 0x06064A44,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0606499C mov.b @r3,r1
    c.r[11] = ld32(0x06064A48u);  // 0606499E mov.l 0x06064A48,r11
    c.r[1] = c.r[1] & 0xFFu;  // 060649A0 extu.b r1,r1
    c.macl = c.r[1] * c.r[13];  // 060649A2 mul.l r13,r1
    c.r[5] = 0x1Bu;  // 060649A4 mov #27,r5
    c.r[2] = ld32(c.r[0]);  // 060649A6 mov.l @r0,r2
    c.r[1] = c.macl;  // 060649A8 sts macl,r1
    c.r[0] = c.r[1];  // 060649AA mov r1,r0
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 060649AC mov.w @(r0,r2),r8
    c.r[4] = ld32(0x06064A4Cu);  // 060649AE mov.l 0x06064A4C,r4
    { const uint32_t x = c.r[11]; c.pr = 0x060649B4u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060649B4u) return; }  // 060649B0 jsr @r11 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 060649B4 mov r0,r1
    c.r[5] = c.r[8];  // 060649B6 mov r8,r5
    { const uint32_t x = c.r[11]; c.pr = 0x060649BCu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060649BCu) return; }  // 060649B8 jsr @r11 ; mov r1,r4
    c.r[7] = c.r[0];  // 060649BC mov r0,r7
    c.r[1] = c.r[7];  // 060649BE mov r7,r1
    c.r[1] += 7;  // 060649C0 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060649C2 mov.b @r1,r1
    c.r[2] = 0x78u;  // 060649C4 mov #120,r2
    c.r[2] &= c.r[1];  // 060649C6 and r1,r2
    c.r[2] >>= 2;  // 060649C8 shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 060649CA shlr r2
    c.r[0] = c.r[2];  // 060649CC mov r2,r0
    c.t = c.r[0] == 0x9u;  // 060649CE cmp/eq #9,r0
    { const bool k = !c.t; c.r[0] = c.r[1]; if (k) { goto L_06064A50; } }  // 060649D0 bf/s 0x06064A50 ; mov r1,r0
    c.r[0] &= 0x7u;  // 060649D4 and #7,r0
    c.t = c.r[0] == 0x1u;  // 060649D6 cmp/eq #1,r0
    if (!c.t) { goto L_06064A50; }  // 060649D8 bf 0x06064A50
    c.r[3] = ld32(c.r[12]);  // 060649DA mov.l @r12,r3
    c.r[2] = c.r[9];  // 060649DC mov r9,r2
    c.r[2] += c.r[3];  // 060649DE add r3,r2
    c.r[1] = c.r[2];  // 060649E0 mov r2,r1
    c.r[1] += 4;  // 060649E2 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060649E4 mov.b @r1,r1
    c.r[0] = c.r[1];  // 060649E6 mov r1,r0
    c.r[0] >>= 2;  // 060649E8 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060649EA shlr r0
    c.r[0] >>= 2;  // 060649EC shlr2 r0
    c.r[0] &= 0x1u;  // 060649EE and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060649F0 tst r0,r0
    { const bool k = c.t; c.r[2] += 6; if (k) { goto L_06064A50; } }  // 060649F2 bt/s 0x06064A50 ; add #6,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060649F6 mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060649F8 extu.b r1,r1
    c.r[1] <<= 2;  // 060649FA shll2 r1
    c.r[1] <<= 2;  // 060649FC shll2 r1
    c.r[1] += c.r[3];  // 060649FE add r3,r1
    c.r[1] += 2;  // 06064A00 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06064A02 mov.b @r1,r1
    c.r[0] = ld32(0x06064A44u);  // 06064A04 mov.l 0x06064A44,r0
    c.r[1] = c.r[1] & 0xFFu;  // 06064A06 extu.b r1,r1
    c.macl = c.r[1] * c.r[13];  // 06064A08 mul.l r13,r1
    c.r[5] = 0x1Bu;  // 06064A0A mov #27,r5
    c.r[2] = ld32(c.r[0]);  // 06064A0C mov.l @r0,r2
    c.r[1] = c.macl;  // 06064A0E sts macl,r1
    c.r[0] = c.r[1];  // 06064A10 mov r1,r0
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 06064A12 mov.w @(r0,r2),r8
    c.r[4] = ld32(0x06064A4Cu);  // 06064A14 mov.l 0x06064A4C,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06064A1Au; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06064A1Au) return; }  // 06064A16 jsr @r11 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 06064A1A mov r0,r1
    c.r[5] = c.r[8];  // 06064A1C mov r8,r5
    { const uint32_t x = c.r[11]; c.pr = 0x06064A22u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06064A22u) return; }  // 06064A1E jsr @r11 ; mov r1,r4
    c.r[1] = c.r[0];  // 06064A22 mov r0,r1
    c.r[1] += 7;  // 06064A24 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06064A26 mov.b @r1,r1
    c.r[0] = 0x7u;  // 06064A28 mov #7,r0
    c.r[1] &= c.r[0];  // 06064A2A and r0,r1
    c.r[0] = c.r[1];  // 06064A2C mov r1,r0
    c.t = c.r[0] == 0x2u;  // 06064A2E cmp/eq #2,r0
    if (!c.t) { goto L_06064AF6; }  // 06064A30 bf 0x06064AF6
    c.r[10] += 1;  // 06064A32 add #1,r10
    goto L_06064B2A;  // 06064A34 bra 0x06064B2A ; nop
L_06064A50:
    c.r[2] = ld32(c.r[12]);  // 06064A50 mov.l @r12,r2
    c.r[2] += c.r[9];  // 06064A52 add r9,r2
    c.r[1] = c.r[2];  // 06064A54 mov r2,r1
    c.r[1] += 7;  // 06064A56 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06064A58 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06064A5A mov r1,r0
    c.r[0] >>= 2;  // 06064A5C shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06064A5E shlr r0
    c.r[0] &= 0x1u;  // 06064A60 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06064A62 tst r0,r0
    { const bool k = c.t; c.r[2] += 3; if (k) { goto L_06064ACE; } }  // 06064A64 bt/s 0x06064ACE ; add #3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06064A68 mov.b @r2,r1
    c.r[0] = 0x3u;  // 06064A6A mov #3,r0
    c.r[2] = c.r[1];  // 06064A6C mov r1,r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 06064A6E shlr r2
    c.r[2] &= c.r[0];  // 06064A70 and r0,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06064A72 tst r2,r2
    if (!c.t) { goto L_06064A82; }  // 06064A74 bf 0x06064A82
    c.r[1] = ld32(0x06064C40u);  // 06064A76 mov.l 0x06064C40,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06064A78 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06064A7A extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06064A7C tst r1,r1
    { const bool k = c.t; c.t = (c.r[2] & c.r[2]) == 0; if (k) { goto L_06064A8E; } }  // 06064A7E bt/s 0x06064A8E ; tst r2,r2
L_06064A82:
    if (c.t) { goto L_06064ACE; }  // 06064A82 bt 0x06064ACE
    c.r[1] = ld32(0x06064C40u);  // 06064A84 mov.l 0x06064C40,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06064A86 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06064A88 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06064A8A tst r1,r1
    if (c.t) { goto L_06064ACE; }  // 06064A8C bt 0x06064ACE
L_06064A8E:
    c.r[2] = ld32(c.r[12]);  // 06064A8E mov.l @r12,r2
    c.r[2] += c.r[9];  // 06064A90 add r9,r2
    c.r[1] = c.r[2];  // 06064A92 mov r2,r1
    c.r[1] += 4;  // 06064A94 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06064A96 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06064A98 mov r1,r0
    c.r[0] >>= 2;  // 06064A9A shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06064A9C shlr r0
    c.r[0] >>= 2;  // 06064A9E shlr2 r0
    c.r[0] &= 0x1u;  // 06064AA0 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06064AA2 tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[2]; if (k) { goto L_06064ACE; } }  // 06064AA4 bf/s 0x06064ACE ; mov r2,r1
    c.r[1] += 3;  // 06064AA8 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06064AAA mov.b @r1,r1
    c.r[0] = c.r[1];  // 06064AAC mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06064AAE shlr r0
    c.r[0] &= 0x3u;  // 06064AB0 and #3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06064AB2 tst r0,r0
    if (!c.t) { goto L_06064AF6; }  // 06064AB4 bf 0x06064AF6
    c.r[1] = ld32(c.r[2] + 12);  // 06064AB6 mov.l @(12,r2),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06064AB8 tst r1,r1
    { const bool k = c.t; c.r[7] += 8; if (k) { goto L_06064AF6; } }  // 06064ABA bt/s 0x06064AF6 ; add #8,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06064ABE mov.b @r7,r1
    c.r[0] = c.r[1];  // 06064AC0 mov r1,r0
    c.r[0] >>= 2;  // 06064AC2 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06064AC4 shlr r0
    c.r[0] >>= 2;  // 06064AC6 shlr2 r0
    c.r[0] &= 0x1u;  // 06064AC8 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06064ACA tst r0,r0
    if (!c.t) { goto L_06064AF6; }  // 06064ACC bf 0x06064AF6
L_06064ACE:
    c.r[1] = ld32(c.r[12]);  // 06064ACE mov.l @r12,r1
    c.r[1] += c.r[9];  // 06064AD0 add r9,r1
    c.r[1] += 2;  // 06064AD2 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06064AD4 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06064AD6 extu.b r1,r1
    c.macl = c.r[1] * c.r[13];  // 06064AD8 mul.l r13,r1
    c.r[0] = ld32(0x06064C44u);  // 06064ADA mov.l 0x06064C44,r0
    c.r[2] = ld32(c.r[0]);  // 06064ADC mov.l @r0,r2
    c.r[1] = c.macl;  // 06064ADE sts macl,r1
    c.r[0] = c.r[1];  // 06064AE0 mov r1,r0
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 06064AE2 mov.w @(r0,r2),r5
    c.r[4] = 0x0u;  // 06064AE4 mov #0,r4
    c.r[0] = ld32(0x06064C48u);  // 06064AE6 mov.l 0x06064C48,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06064AECu; c.r[5] = c.r[5] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06064AECu) return; }  // 06064AE8 jsr @r0 ; extu.w r5,r5
    c.r[1] = c.r[0];  // 06064AEC mov r0,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06064AEE extu.w r1,r1
    c.r[0] = c.r[1];  // 06064AF0 mov r1,r0
    c.t = c.r[0] == 0x4u;  // 06064AF2 cmp/eq #4,r0
    if (!c.t) { goto L_06064B28; }  // 06064AF4 bf 0x06064B28
L_06064AF6:
    c.r[1] = ld32(0x06064C4Cu);  // 06064AF6 mov.l 0x06064C4C,r1
    c.r[3] = ld32(c.r[1]);  // 06064AF8 mov.l @r1,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x06064C34u);  // 06064AFA mov.w 0x06064C34,r7
    c.r[0] = c.r[3];  // 06064AFC mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06064AFE mov.b @(r0,r7),r2
    c.r[1] = c.r[2];  // 06064B00 mov r2,r1
    c.r[1] += 1;  // 06064B02 add #1,r1
    st8(c.r[0] + c.r[7], c.r[1]);  // 06064B04 mov.b r1,@(r0,r7)
    c.r[7] = c.r[2] & 0xFFu;  // 06064B06 extu.b r2,r7
    c.r[7] += c.r[7];  // 06064B08 add r7,r7
    c.r[1] = c.r[10] & 0xFFFFu;  // 06064B0A extu.w r10,r1
    c.r[6] = c.r[1];  // 06064B0C mov r1,r6
    c.r[6] >>= 8;  // 06064B0E shlr8 r6
    c.r[0] = 0x7Fu;  // 06064B10 mov #127,r0
    c.r[6] &= c.r[0];  // 06064B12 and r0,r6
    c.r[0] = c.r[3];  // 06064B14 mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06064B16 mov.b @(r0,r7),r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06064C36u);  // 06064B18 mov.w 0x06064C36,r0
    c.r[2] &= c.r[0];  // 06064B1A and r0,r2
    c.r[2] |= c.r[6];  // 06064B1C or r6,r2
    c.r[0] = c.r[3];  // 06064B1E mov r3,r0
    st8(c.r[0] + c.r[7], c.r[2]);  // 06064B20 mov.b r2,@(r0,r7)
    c.r[3] += c.r[7];  // 06064B22 add r7,r3
    c.r[3] += 1;  // 06064B24 add #1,r3
    st8(c.r[3], c.r[1]);  // 06064B26 mov.b r1,@r3
L_06064B28:
    c.r[10] += 1;  // 06064B28 add #1,r10
L_06064B2A:
    c.r[1] = 0x49u;  // 06064B2A mov #73,r1
    c.t = (int32_t)c.r[10] > (int32_t)c.r[1];  // 06064B2C cmp/gt r1,r10
    { const bool k = c.t; c.r[9] += 16; if (k) { goto L_06064B36; } }  // 06064B2E bt/s 0x06064B36 ; add #16,r9
    SH2_POLL(c); goto L_06064984;  // 06064B32 bra 0x06064984 ; nop
L_06064B36:
    goto L_06064C1A;  // 06064B36 bra 0x06064C1A ; nop
L_06064B3A:
    c.r[1] = ld32(0x06064C4Cu);  // 06064B3A mov.l 0x06064C4C,r1
    c.r[3] = ld32(c.r[1]);  // 06064B3C mov.l @r1,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x06064C34u);  // 06064B3E mov.w 0x06064C34,r7
    c.r[0] = c.r[3];  // 06064B40 mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06064B42 mov.b @(r0,r7),r2
    c.r[1] = c.r[2];  // 06064B44 mov r2,r1
    c.r[1] += 1;  // 06064B46 add #1,r1
    st8(c.r[0] + c.r[7], c.r[1]);  // 06064B48 mov.b r1,@(r0,r7)
    c.r[7] = c.r[2] & 0xFFu;  // 06064B4A extu.b r2,r7
    c.r[7] += c.r[7];  // 06064B4C add r7,r7
    c.r[1] = c.r[10] & 0xFFFFu;  // 06064B4E extu.w r10,r1
    c.r[6] = c.r[1];  // 06064B50 mov r1,r6
    c.r[6] >>= 8;  // 06064B52 shlr8 r6
    c.r[0] = 0x7Fu;  // 06064B54 mov #127,r0
    c.r[6] &= c.r[0];  // 06064B56 and r0,r6
    c.r[0] = c.r[3];  // 06064B58 mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06064B5A mov.b @(r0,r7),r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06064C36u);  // 06064B5C mov.w 0x06064C36,r0
    c.r[2] &= c.r[0];  // 06064B5E and r0,r2
    c.r[2] |= c.r[6];  // 06064B60 or r6,r2
    c.r[0] = c.r[3];  // 06064B62 mov r3,r0
    st8(c.r[0] + c.r[7], c.r[2]);  // 06064B64 mov.b r2,@(r0,r7)
    c.r[3] += c.r[7];  // 06064B66 add r7,r3
    c.r[3] += 1;  // 06064B68 add #1,r3
    st8(c.r[3], c.r[1]); goto L_06064C1A;  // 06064B6A bra 0x06064C1A ; mov.b r1,@r3
L_06064B6E:
    c.r[1] = ld32(0x06064C4Cu);  // 06064B6E mov.l 0x06064C4C,r1
    c.r[2] = ld32(c.r[1]);  // 06064B70 mov.l @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06064C34u);  // 06064B72 mov.w 0x06064C34,r0
    c.r[10] = 0x0u;  // 06064B74 mov #0,r10
    c.r[4] = ld32(0x06064C50u);  // 06064B76 mov.l 0x06064C50,r4
    c.r[8] = (uint32_t)(int16_t)ld16(0x06064C38u);  // 06064B78 mov.w 0x06064C38,r8
    c.r[6] = 0x0u;  // 06064B7A mov #0,r6
    c.r[1] = 0x0u;  // 06064B7C mov #0,r1
    st8(c.r[0] + c.r[2], c.r[1]);  // 06064B7E mov.b r1,@(r0,r2)
L_06064B80:
    c.r[0] = ld32(c.r[4]);  // 06064B80 mov.l @r4,r0
    c.r[2] = c.r[6];  // 06064B82 mov r6,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 06064B84 mov.b @(r0,r6),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06064B86 extu.b r1,r1
    c.t = c.r[1] == c.r[8];  // 06064B88 cmp/eq r8,r1
    { const bool k = c.t; c.r[2] += c.r[0]; if (k) { goto L_06064C10; } }  // 06064B8A bt/s 0x06064C10 ; add r0,r2
    c.r[1] = c.r[2];  // 06064B8E mov r2,r1
    c.r[1] += 7;  // 06064B90 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06064B92 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06064B94 mov r1,r0
    c.r[0] >>= 2;  // 06064B96 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06064B98 shlr r0
    c.r[0] &= 0x1u;  // 06064B9A and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06064B9C tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[2]; if (k) { goto L_06064C10; } }  // 06064B9E bf/s 0x06064C10 ; mov r2,r1
    c.r[1] += 3;  // 06064BA2 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06064BA4 mov.b @r1,r1
    c.r[0] = 0x3u;  // 06064BA6 mov #3,r0
    c.r[3] = c.r[1];  // 06064BA8 mov r1,r3
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 06064BAA shlr r3
    c.r[3] &= c.r[0];  // 06064BAC and r0,r3
    c.t = (c.r[3] & c.r[3]) == 0;  // 06064BAE tst r3,r3
    if (!c.t) { goto L_06064BBA; }  // 06064BB0 bf 0x06064BBA
    c.r[1] = ld32(c.r[2] + 12);  // 06064BB2 mov.l @(12,r2),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06064BB4 tst r1,r1
    { const bool k = !c.t; c.t = (c.r[3] & c.r[3]) == 0; if (k) { goto L_06064C10; } }  // 06064BB6 bf/s 0x06064C10 ; tst r3,r3
L_06064BBA:
    if (!c.t) { goto L_06064BC4; }  // 06064BBA bf 0x06064BC4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[5]);  // 06064BBC mov.b @r5,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06064BBE extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06064BC0 tst r1,r1
    if (c.t) { goto L_06064BD0; }  // 06064BC2 bt 0x06064BD0
L_06064BC4:
    c.t = (c.r[3] & c.r[3]) == 0;  // 06064BC4 tst r3,r3
    if (c.t) { goto L_06064C10; }  // 06064BC6 bt 0x06064C10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[5]);  // 06064BC8 mov.b @r5,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06064BCA extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06064BCC tst r1,r1
    if (c.t) { goto L_06064C10; }  // 06064BCE bt 0x06064C10
L_06064BD0:
    c.r[1] = ld32(c.r[4]);  // 06064BD0 mov.l @r4,r1
    c.r[1] += c.r[6];  // 06064BD2 add r6,r1
    c.r[1] += 4;  // 06064BD4 add #4,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06064BD6 mov.b @r1,r0
    c.r[0] &= 0x60u;  // 06064BD8 and #96,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06064BDA tst r0,r0
    if (!c.t) { goto L_06064C10; }  // 06064BDC bf 0x06064C10
    c.r[1] = ld32(0x06064C4Cu);  // 06064BDE mov.l 0x06064C4C,r1
    c.r[3] = ld32(c.r[1]);  // 06064BE0 mov.l @r1,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x06064C34u);  // 06064BE2 mov.w 0x06064C34,r7
    c.r[0] = c.r[3];  // 06064BE4 mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06064BE6 mov.b @(r0,r7),r2
    c.r[1] = c.r[2];  // 06064BE8 mov r2,r1
    c.r[1] += 1;  // 06064BEA add #1,r1
    st8(c.r[0] + c.r[7], c.r[1]);  // 06064BEC mov.b r1,@(r0,r7)
    c.r[7] = c.r[2] & 0xFFu;  // 06064BEE extu.b r2,r7
    c.r[7] += c.r[7];  // 06064BF0 add r7,r7
    c.r[1] = c.r[10] & 0xFFFFu;  // 06064BF2 extu.w r10,r1
    c.r[9] = c.r[1];  // 06064BF4 mov r1,r9
    c.r[9] >>= 8;  // 06064BF6 shlr8 r9
    c.r[0] = 0x7Fu;  // 06064BF8 mov #127,r0
    c.r[9] &= c.r[0];  // 06064BFA and r0,r9
    c.r[0] = c.r[3];  // 06064BFC mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06064BFE mov.b @(r0,r7),r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06064C36u);  // 06064C00 mov.w 0x06064C36,r0
    c.r[2] &= c.r[0];  // 06064C02 and r0,r2
    c.r[2] |= c.r[9];  // 06064C04 or r9,r2
    c.r[0] = c.r[3];  // 06064C06 mov r3,r0
    st8(c.r[0] + c.r[7], c.r[2]);  // 06064C08 mov.b r2,@(r0,r7)
    c.r[3] += c.r[7];  // 06064C0A add r7,r3
    c.r[3] += 1;  // 06064C0C add #1,r3
    st8(c.r[3], c.r[1]);  // 06064C0E mov.b r1,@r3
L_06064C10:
    c.r[10] += 1;  // 06064C10 add #1,r10
    c.r[1] = 0x49u;  // 06064C12 mov #73,r1
    c.t = (int32_t)c.r[10] > (int32_t)c.r[1];  // 06064C14 cmp/gt r1,r10
    { const bool k = !c.t; c.r[6] += 16; if (k) { SH2_POLL(c); goto L_06064B80; } }  // 06064C16 bf/s 0x06064B80 ; add #16,r6
L_06064C1A:
    c.r[3] = (uint32_t)(int16_t)ld16(0x06064C3Au);  // 06064C1A mov.w 0x06064C3A,r3
    c.r[14] += c.r[3];  // 06064C1C add r3,r14
    c.r[15] = c.r[14];  // 06064C1E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06064C20 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06064C22 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06064C24 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06064C26 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06064C28 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06064C2A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06064C2C mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x06064C3Cu);  // 06064C2E mov.w 0x06064C3C,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06064C30 rts ; mov.l @r15+,r8
}

}  // namespace p_srwfin_installed
