#include "p_srwfin_installed_funcs.h"

namespace p_srwfin_installed {

void f_06054904(SH2Context& c) {
    ran[1324] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06054904 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06054906 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06054908 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0605490A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0605490C mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0605490E mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06054910 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06054912 sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x06054A14u);  // 06054914 mov.w 0x06054A14,r3
    c.r[15] += c.r[3];  // 06054916 add r3,r15
    c.r[14] = c.r[15];  // 06054918 mov r15,r14
    c.r[4] = c.r[4] & 0xFFu;  // 0605491A extu.b r4,r4
    c.r[1] = ld32(0x06054A24u);  // 0605491C mov.l 0x06054A24,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06054A16u);  // 0605491E mov.w 0x06054A16,r0
    c.r[0] += c.r[14];  // 06054920 add r14,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06054922 mov.b @r1,r2
    c.r[13] = (uint32_t)(int16_t)ld16(0x06054A18u);  // 06054924 mov.w 0x06054A18,r13
    c.r[2] = c.r[2] & 0xFFu;  // 06054926 extu.b r2,r2
    c.r[1] = ld32(0x06054A28u);  // 06054928 mov.l 0x06054A28,r1
    c.r[1] = ld32(c.r[1]);  // 0605492A mov.l @r1,r1
    c.r[2] <<= 2;  // 0605492C shll2 r2
    c.r[2] <<= 2;  // 0605492E shll2 r2
    c.r[2] += c.r[1];  // 06054930 add r1,r2
    c.r[1] = c.r[2];  // 06054932 mov r2,r1
    c.r[1] += 2;  // 06054934 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06054936 mov.b @r1,r1
    c.r[2] += 3;  // 06054938 add #3,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0605493A extu.b r1,r1
    st32(c.r[0], c.r[1]);  // 0605493C mov.l r1,@r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605493E mov.b @r2,r1
    c.r[13] += c.r[14];  // 06054940 add r14,r13
    c.r[0] = c.r[1];  // 06054942 mov r1,r0
    c.r[0] >>= 2;  // 06054944 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06054946 shlr r0
    st32(c.r[13], c.r[0]);  // 06054948 mov.l r0,@r13
    c.r[0] = (uint32_t)(int16_t)ld16(0x06054A18u);  // 0605494A mov.w 0x06054A18,r0
    c.r[0] += c.r[14];  // 0605494C add r14,r0
    c.r[13] = (uint32_t)(int16_t)ld16(0x06054A18u);  // 0605494E mov.w 0x06054A18,r13
    c.r[13] += c.r[14];  // 06054950 add r14,r13
    c.r[0] = ld32(c.r[0]);  // 06054952 mov.l @r0,r0
    c.r[1] = ld32(0x06054A2Cu);  // 06054954 mov.l 0x06054A2C,r1
    c.r[0] &= 0x3u;  // 06054956 and #3,r0
    st32(c.r[13], c.r[0]);  // 06054958 mov.l r0,@r13
    c.r[2] = ld32(c.r[1]);  // 0605495A mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06054A1Au);  // 0605495C mov.w 0x06054A1A,r1
    c.r[0] = c.r[2];  // 0605495E mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06054960 mov.b @(r0,r1),r1
    c.r[13] = 0x1u;  // 06054962 mov #1,r13
    c.r[1] >>= 2;  // 06054964 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06054966 shlr r1
    c.r[1] >>= 2;  // 06054968 shlr2 r1
    c.r[1] &= c.r[13];  // 0605496A and r13,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605496C tst r1,r1
    { const bool k = c.t; c.r[12] = 0x0u; if (k) { goto L_0605497C; } }  // 0605496E bt/s 0x0605497C ; mov #0,r12
    c.r[13] = (uint32_t)(int16_t)ld16(0x06054A1Cu);  // 06054972 mov.w 0x06054A1C,r13
    c.r[0] = (uint32_t)(int16_t)ld16(0x06054A1Eu);  // 06054974 mov.w 0x06054A1E,r0
    c.r[0] += c.r[14];  // 06054976 add r14,r0
    st32(c.r[0], c.r[13]); goto L_06054998;  // 06054978 bra 0x06054998 ; mov.l r13,@r0
L_0605497C:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06054A20u);  // 0605497C mov.w 0x06054A20,r1
    c.r[0] = c.r[2];  // 0605497E mov r2,r0
    c.r[13] = (uint32_t)(int16_t)ld16(0x06054A1Eu);  // 06054980 mov.w 0x06054A1E,r13
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06054982 mov.b @(r0,r1),r1
    c.r[13] += c.r[14];  // 06054984 add r14,r13
    c.r[0] = c.r[1];  // 06054986 mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06054988 shlr r0
    st32(c.r[13], c.r[0]);  // 0605498A mov.l r0,@r13
    c.r[0] = (uint32_t)(int16_t)ld16(0x06054A1Eu);  // 0605498C mov.w 0x06054A1E,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 0605498E mov.l @(r0,r14),r0
    c.r[0] &= 0xFu;  // 06054990 and #15,r0
    c.r[13] = (uint32_t)(int16_t)ld16(0x06054A1Eu);  // 06054992 mov.w 0x06054A1E,r13
    c.r[13] += c.r[14];  // 06054994 add r14,r13
    st32(c.r[13], c.r[0]);  // 06054996 mov.l r0,@r13
L_06054998:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06054A1Eu);  // 06054998 mov.w 0x06054A1E,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 0605499A mov.l @(r0,r14),r0
    c.t = c.r[0] == 0x4u;  // 0605499C cmp/eq #4,r0
    { const bool k = c.t; c.r[2] = c.r[4]; if (k) { goto L_06054A38; } }  // 0605499E bt/s 0x06054A38 ; mov r4,r2
    c.r[13] = (uint32_t)(int16_t)ld16(0x06054A1Eu);  // 060549A2 mov.w 0x06054A1E,r13
    c.r[13] += c.r[14];  // 060549A4 add r14,r13
    c.r[13] = ld32(c.r[13]);  // 060549A6 mov.l @r13,r13
    c.r[1] = 0x4u;  // 060549A8 mov #4,r1
    c.t = (int32_t)c.r[13] > (int32_t)c.r[1];  // 060549AA cmp/gt r1,r13
    if (c.t) { goto L_060549C6; }  // 060549AC bt 0x060549C6
    c.r[0] = (uint32_t)(int16_t)ld16(0x06054A1Eu);  // 060549AE mov.w 0x06054A1E,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 060549B0 mov.l @(r0,r14),r0
    c.t = c.r[0] == 0x1u;  // 060549B2 cmp/eq #1,r0
    if (c.t) { goto L_060549DC; }  // 060549B4 bt 0x060549DC
    c.r[0] = (uint32_t)(int16_t)ld16(0x06054A1Eu);  // 060549B6 mov.w 0x06054A1E,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 060549B8 mov.l @(r0,r14),r0
    c.t = c.r[0] == 0x3u;  // 060549BA cmp/eq #3,r0
    if (c.t) { goto L_060549C2; }  // 060549BC bt 0x060549C2
    goto L_06054DC0;  // 060549BE bra 0x06054DC0 ; nop
L_060549C2:
    goto L_060549DC;  // 060549C2 bra 0x060549DC ; nop
L_060549C6:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06054A1Eu);  // 060549C6 mov.w 0x06054A1E,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 060549C8 mov.l @(r0,r14),r0
    c.t = c.r[0] == 0x5u;  // 060549CA cmp/eq #5,r0
    if (c.t) { goto L_060549DC; }  // 060549CC bt 0x060549DC
    c.r[0] = (uint32_t)(int16_t)ld16(0x06054A1Eu);  // 060549CE mov.w 0x06054A1E,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 060549D0 mov.l @(r0,r14),r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06054A1Cu);  // 060549D2 mov.w 0x06054A1C,r1
    c.t = c.r[0] == c.r[1];  // 060549D4 cmp/eq r1,r0
    if (c.t) { goto L_060549DC; }  // 060549D6 bt 0x060549DC
    goto L_06054DC0;  // 060549D8 bra 0x06054DC0 ; nop
L_060549DC:
    c.r[1] = ld32(0x06054A30u);  // 060549DC mov.l 0x06054A30,r1
    c.r[13] = (uint32_t)(int16_t)ld16(0x06054A16u);  // 060549DE mov.w 0x06054A16,r13
    c.r[3] = ld32(c.r[1]);  // 060549E0 mov.l @r1,r3
    c.r[13] += c.r[14];  // 060549E2 add r14,r13
    c.r[13] = ld32(c.r[13]);  // 060549E4 mov.l @r13,r13
    c.r[1] = 0x1Eu;  // 060549E6 mov #30,r1
    c.macl = c.r[13] * c.r[1];  // 060549E8 mul.l r1,r13
    c.r[7] = c.r[4];  // 060549EA mov r4,r7
    c.r[7] += c.r[7];  // 060549EC add r7,r7
    c.r[2] = c.macl;  // 060549EE sts macl,r2
    c.r[1] = ld32(0x06054A34u);  // 060549F0 mov.l 0x06054A34,r1
    c.r[1] = ld32(c.r[1]);  // 060549F2 mov.l @r1,r1
    c.r[13] = 0x7Fu;  // 060549F4 mov #127,r13
    c.r[0] = c.r[1];  // 060549F6 mov r1,r0
    c.r[1] += c.r[7];  // 060549F8 add r7,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 060549FA mov.b @(r0,r7),r6
    c.r[1] += 1;  // 060549FC add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060549FE mov.b @r1,r1
    c.r[6] &= c.r[13];  // 06054A00 and r13,r6
    c.r[6] <<= 8;  // 06054A02 shll8 r6
    c.r[1] = c.r[1] & 0xFFu;  // 06054A04 extu.b r1,r1
    c.r[1] |= c.r[6];  // 06054A06 or r6,r1
    c.r[0] = c.r[2];  // 06054A08 mov r2,r0
    st16(c.r[0] + c.r[3], c.r[1]);  // 06054A0A mov.w r1,@(r0,r3)
    c.r[1] = ld32(0x06054A24u);  // 06054A0C mov.l 0x06054A24,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06054A0E mov.b @r1,r1
    c.r[12] = c.r[1] & 0xFFu; goto L_06054DC0;  // 06054A10 bra 0x06054DC0 ; extu.b r1,r12
L_06054A38:
    c.r[1] = ld32(0x06054C1Cu);  // 06054A38 mov.l 0x06054C1C,r1
    c.r[2] += c.r[2];  // 06054A3A add r2,r2
    c.r[1] = ld32(c.r[1]);  // 06054A3C mov.l @r1,r1
    c.r[13] = 0x7Fu;  // 06054A3E mov #127,r13
    c.r[0] = c.r[1];  // 06054A40 mov r1,r0
    c.r[1] += c.r[2];  // 06054A42 add r2,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06054A44 mov.b @(r0,r2),r3
    c.r[1] += 1;  // 06054A46 add #1,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06054A48 mov.b @r1,r4
    c.r[3] &= c.r[13];  // 06054A4A and r13,r3
    c.r[3] <<= 8;  // 06054A4C shll8 r3
    c.r[4] = c.r[4] & 0xFFu;  // 06054A4E extu.b r4,r4
    c.r[0] = ld32(0x06054C20u);  // 06054A50 mov.l 0x06054C20,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06054A56u; c.r[4] |= c.r[3]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06054A56u) return; }  // 06054A52 jsr @r0 ; or r3,r4
    c.r[1] = c.r[0];  // 06054A56 mov r0,r1
    c.r[12] = c.r[1] & 0xFFu;  // 06054A58 extu.b r1,r12
    c.r[4] = ld32(0x06054C24u);  // 06054A5A mov.l 0x06054C24,r4
    c.r[6] = c.r[12];  // 06054A5C mov r12,r6
    c.r[6] <<= 2;  // 06054A5E shll2 r6
    c.r[6] <<= 2;  // 06054A60 shll2 r6
    c.r[3] = c.r[6];  // 06054A62 mov r6,r3
    c.r[13] = (uint32_t)(int16_t)ld16(0x06054C10u);  // 06054A64 mov.w 0x06054C10,r13
    c.r[13] += c.r[14];  // 06054A66 add r14,r13
    c.r[2] = ld32(c.r[4]);  // 06054A68 mov.l @r4,r2
    c.r[5] = ld32(0x06054C28u);  // 06054A6A mov.l 0x06054C28,r5
    c.r[3] += c.r[2];  // 06054A6C add r2,r3
    c.r[0] = c.r[3];  // 06054A6E mov r3,r0
    c.r[0] += 2;  // 06054A70 add #2,r0
    st32(c.r[13], c.r[0]);  // 06054A72 mov.l r0,@r13
    c.r[13] = (uint32_t)(int16_t)ld16(0x06054C10u);  // 06054A74 mov.w 0x06054C10,r13
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[5]);  // 06054A76 mov.b @r5,r1
    c.r[13] += c.r[14];  // 06054A78 add r14,r13
    c.r[0] = ld32(c.r[13]);  // 06054A7A mov.l @r13,r0
    c.r[1] = c.r[1] & 0xFFu;  // 06054A7C extu.b r1,r1
    c.r[1] <<= 2;  // 06054A7E shll2 r1
    c.r[1] <<= 2;  // 06054A80 shll2 r1
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06054A82 mov.b @r0,r8
    c.r[7] = c.r[1];  // 06054A84 mov r1,r7
    c.r[0] = c.r[1];  // 06054A86 mov r1,r0
    c.r[1] = ld32(c.r[0] + c.r[2]);  // 06054A88 mov.l @(r0,r2),r1
    c.r[7] += c.r[2];  // 06054A8A add r2,r7
    c.r[0] = c.r[6];  // 06054A8C mov r6,r0
    st32(c.r[0] + c.r[2], c.r[1]);  // 06054A8E mov.l r1,@(r0,r2)
    c.r[1] = ld32(c.r[7] + 4);  // 06054A90 mov.l @(4,r7),r1
    c.r[13] = (uint32_t)(int16_t)ld16(0x06054C10u);  // 06054A92 mov.w 0x06054C10,r13
    st32(c.r[3] + 4, c.r[1]);  // 06054A94 mov.l r1,@(4,r3)
    c.r[7] += 8;  // 06054A96 add #8,r7
    c.r[1] = ld32(c.r[7]); c.r[7] += 4;  // 06054A98 mov.l @r7+,r1
    c.r[3] += 8;  // 06054A9A add #8,r3
    st32(c.r[3], c.r[1]);  // 06054A9C mov.l r1,@r3
    c.r[1] = ld32(c.r[7]);  // 06054A9E mov.l @r7,r1
    c.r[13] += c.r[14];  // 06054AA0 add r14,r13
    st32(c.r[3] + 4, c.r[1]);  // 06054AA2 mov.l r1,@(4,r3)
    c.r[0] = ld32(c.r[13]);  // 06054AA4 mov.l @r13,r0
    st8(c.r[0], c.r[8]);  // 06054AA6 mov.b r8,@r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[5]);  // 06054AA8 mov.b @r5,r1
    c.r[6] = 0x0u;  // 06054AAA mov #0,r6
    c.r[2] = ld32(c.r[4]);  // 06054AAC mov.l @r4,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06054AAE extu.b r1,r1
    c.r[1] <<= 2;  // 06054AB0 shll2 r1
    c.r[1] <<= 2;  // 06054AB2 shll2 r1
    c.r[1] += c.r[2];  // 06054AB4 add r2,r1
    c.r[1] += 4;  // 06054AB6 add #4,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06054AB8 mov.b @r1,r2
    c.r[13] = 0x20u;  // 06054ABA mov #32,r13
    c.r[2] |= c.r[13];  // 06054ABC or r13,r2
    st8(c.r[1], c.r[2]);  // 06054ABE mov.b r2,@r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[5]);  // 06054AC0 mov.b @r5,r1
    c.r[7] = 0x0u;  // 06054AC2 mov #0,r7
    c.r[2] = ld32(c.r[4]);  // 06054AC4 mov.l @r4,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06054AC6 extu.b r1,r1
    c.r[1] <<= 2;  // 06054AC8 shll2 r1
    c.r[1] <<= 2;  // 06054ACA shll2 r1
    c.r[1] += c.r[2];  // 06054ACC add r2,r1
    c.r[1] += 6;  // 06054ACE add #6,r1
    st8(c.r[1], c.r[12]);  // 06054AD0 mov.b r12,@r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[5]);  // 06054AD2 mov.b @r5,r1
    c.r[0] = 0x7Fu;  // 06054AD4 mov #127,r0
    c.r[2] = ld32(c.r[4]);  // 06054AD6 mov.l @r4,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06054AD8 extu.b r1,r1
    c.r[1] <<= 2;  // 06054ADA shll2 r1
    c.r[1] <<= 2;  // 06054ADC shll2 r1
    c.r[1] += c.r[2];  // 06054ADE add r2,r1
    c.r[1] += 3;  // 06054AE0 add #3,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06054AE2 mov.b @r1,r2
    c.r[4] = (uint32_t)(int16_t)ld16(0x06054C12u);  // 06054AE4 mov.w 0x06054C12,r4
    c.r[2] &= c.r[0];  // 06054AE6 and r0,r2
    st8(c.r[1], c.r[2]);  // 06054AE8 mov.b r2,@r1
L_06054AEA:
    c.r[1] = ld32(0x06054C24u);  // 06054AEA mov.l 0x06054C24,r1
    c.r[0] = ld32(c.r[1]);  // 06054AEC mov.l @r1,r0
    c.r[2] = c.r[7];  // 06054AEE mov r7,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06054AF0 mov.b @(r0,r7),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06054AF2 extu.b r1,r1
    c.t = c.r[1] == c.r[4];  // 06054AF4 cmp/eq r4,r1
    { const bool k = c.t; c.r[2] += c.r[0]; if (k) { goto L_06054B22; } }  // 06054AF6 bt/s 0x06054B22 ; add r0,r2
    c.r[1] = c.r[2];  // 06054AFA mov r2,r1
    c.r[1] += 7;  // 06054AFC add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06054AFE mov.b @r1,r1
    c.r[0] = c.r[1];  // 06054B00 mov r1,r0
    c.r[0] >>= 2;  // 06054B02 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06054B04 shlr r0
    c.r[0] &= 0x1u;  // 06054B06 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06054B08 tst r0,r0
    if (!c.t) { goto L_06054B22; }  // 06054B0A bf 0x06054B22
    c.r[3] = c.r[2];  // 06054B0C mov r2,r3
    c.r[3] += 6;  // 06054B0E add #6,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06054B10 mov.b @r3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[5]);  // 06054B12 mov.b @r5,r1
    c.r[2] = c.r[2] & 0xFFu;  // 06054B14 extu.b r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06054B16 extu.b r1,r1
    c.t = c.r[2] == c.r[1];  // 06054B18 cmp/eq r1,r2
    { const bool k = !c.t; c.t = c.r[6] == c.r[12]; if (k) { goto L_06054B22; } }  // 06054B1A bf/s 0x06054B22 ; cmp/eq r12,r6
    if (c.t) { goto L_06054B22; }  // 06054B1E bt 0x06054B22
    st8(c.r[3], c.r[12]);  // 06054B20 mov.b r12,@r3
L_06054B22:
    c.r[6] += 1;  // 06054B22 add #1,r6
    c.r[1] = 0x49u;  // 06054B24 mov #73,r1
    c.t = (int32_t)c.r[6] > (int32_t)c.r[1];  // 06054B26 cmp/gt r1,r6
    { const bool k = !c.t; c.r[7] += 16; if (k) { SH2_POLL(c); goto L_06054AEA; } }  // 06054B28 bf/s 0x06054AEA ; add #16,r7
    c.r[9] = ld32(0x06054C24u);  // 06054B2C mov.l 0x06054C24,r9
    c.r[8] = c.r[12];  // 06054B2E mov r12,r8
    c.r[8] <<= 2;  // 06054B30 shll2 r8
    c.r[8] <<= 2;  // 06054B32 shll2 r8
    c.r[1] = c.r[8];  // 06054B34 mov r8,r1
    c.r[13] = ld32(0x06054C2Cu);  // 06054B36 mov.l 0x06054C2C,r13
    c.r[6] = ld32(c.r[9]);  // 06054B38 mov.l @r9,r6
    c.r[11] = 0x1Eu;  // 06054B3A mov #30,r11
    c.r[1] += c.r[6];  // 06054B3C add r6,r1
    c.r[1] += 2;  // 06054B3E add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06054B40 mov.b @r1,r1
    c.r[2] = ld32(0x06054C30u);  // 06054B42 mov.l 0x06054C30,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06054B44 extu.b r1,r1
    c.macl = c.r[1] * c.r[11];  // 06054B46 mul.l r11,r1
    c.r[0] = c.r[8];  // 06054B48 mov r8,r0
    c.r[7] = ld32(c.r[13]);  // 06054B4A mov.l @r13,r7
    c.r[1] = c.macl;  // 06054B4C sts macl,r1
    c.r[1] += c.r[7];  // 06054B4E add r7,r1
    c.r[1] += 15;  // 06054B50 add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06054B52 mov.b @r1,r1
    c.r[10] = (uint32_t)(int16_t)ld16(0x06054C14u);  // 06054B54 mov.w 0x06054C14,r10
    c.r[3] = ld32(c.r[2]);  // 06054B56 mov.l @r2,r3
    c.r[1] = c.r[1] & 0xFFu;  // 06054B58 extu.b r1,r1
    c.r[5] = c.r[1];  // 06054B5A mov r1,r5
    c.r[5] += c.r[5];  // 06054B5C add r5,r5
    c.r[5] += c.r[1];  // 06054B5E add r1,r5
    c.r[1] = ld32(0x06054C28u);  // 06054B60 mov.l 0x06054C28,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06054B62 mov.b @r1,r1
    c.r[5] <<= 2;  // 06054B64 shll2 r5
    c.r[1] = c.r[1] & 0xFFu;  // 06054B66 extu.b r1,r1
    c.r[1] <<= 2;  // 06054B68 shll2 r1
    c.r[1] <<= 2;  // 06054B6A shll2 r1
    c.r[1] += c.r[6];  // 06054B6C add r6,r1
    c.r[1] += 2;  // 06054B6E add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06054B70 mov.b @r1,r1
    c.r[13] = (uint32_t)(int16_t)ld16(0x06054C16u);  // 06054B72 mov.w 0x06054C16,r13
    c.r[1] = c.r[1] & 0xFFu;  // 06054B74 extu.b r1,r1
    c.macl = c.r[1] * c.r[11];  // 06054B76 mul.l r11,r1
    c.r[13] += c.r[14];  // 06054B78 add r14,r13
    c.r[5] += c.r[3];  // 06054B7A add r3,r5
    c.r[1] = c.macl;  // 06054B7C sts macl,r1
    c.r[1] += c.r[7];  // 06054B7E add r7,r1
    c.r[1] += 15;  // 06054B80 add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06054B82 mov.b @r1,r1
    c.r[5] += 9;  // 06054B84 add #9,r5
    c.r[1] = c.r[1] & 0xFFu;  // 06054B86 extu.b r1,r1
    c.r[2] = c.r[1];  // 06054B88 mov r1,r2
    c.r[2] += c.r[2];  // 06054B8A add r2,r2
    c.r[2] += c.r[1];  // 06054B8C add r1,r2
    c.r[2] <<= 2;  // 06054B8E shll2 r2
    c.r[2] += c.r[3];  // 06054B90 add r3,r2
    c.r[2] += 9;  // 06054B92 add #9,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06054B94 mov.b @r2,r1
    c.r[6] = (uint32_t)(int16_t)ld16(0x06054C12u);  // 06054B96 mov.w 0x06054C12,r6
    st8(c.r[5], c.r[1]);  // 06054B98 mov.b r1,@r5
    c.r[3] = ld32(c.r[9]);  // 06054B9A mov.l @r9,r3
    c.r[1] = c.r[8];  // 06054B9C mov r8,r1
    c.r[1] += c.r[3];  // 06054B9E add r3,r1
    c.r[1] += 1;  // 06054BA0 add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06054BA2 mov.b @r1,r2
    c.r[7] = ld32(0x06054C34u);  // 06054BA4 mov.l 0x06054C34,r7
    c.r[2] = c.r[2] & 0xFFu;  // 06054BA6 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06054BA8 mov.b @(r0,r3),r1
    c.r[2] <<= 2;  // 06054BAA shll2 r2
    c.r[2] <<= 2;  // 06054BAC shll2 r2
    c.r[2] <<= 2;  // 06054BAE shll2 r2
    c.r[3] = ld32(c.r[7]);  // 06054BB0 mov.l @r7,r3
    c.r[1] = c.r[1] & 0xFFu;  // 06054BB2 extu.b r1,r1
    c.r[2] += c.r[3];  // 06054BB4 add r3,r2
    c.r[0] = c.r[2];  // 06054BB6 mov r2,r0
    st8(c.r[0] + c.r[1], c.r[12]);  // 06054BB8 mov.b r12,@(r0,r1)
    c.r[0] = c.r[14];  // 06054BBA mov r14,r0
    c.r[0] += c.r[10];  // 06054BBC add r10,r0
    st32(c.r[13], c.r[0]);  // 06054BBE mov.l r0,@r13
    c.r[1] = ld32(c.r[9]);  // 06054BC0 mov.l @r9,r1
    c.r[13] = (uint32_t)(int16_t)ld16(0x06054C16u);  // 06054BC2 mov.w 0x06054C16,r13
    c.r[1] += c.r[8];  // 06054BC4 add r8,r1
    c.r[1] += 2;  // 06054BC6 add #2,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06054BC8 mov.b @r1,r5
    c.r[13] += c.r[14];  // 06054BCA add r14,r13
    c.r[4] = ld32(c.r[13]);  // 06054BCC mov.l @r13,r4
    c.r[1] = ld32(0x06054C38u);  // 06054BCE mov.l 0x06054C38,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06054BD4u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06054BD4u) return; }  // 06054BD0 jsr @r1 ; extu.b r5,r5
    c.r[0] = ld32(0x06054C2Cu);  // 06054BD4 mov.l 0x06054C2C,r0
    c.r[1] = ld32(c.r[9]);  // 06054BD6 mov.l @r9,r1
    c.r[13] = (uint32_t)(int16_t)ld16(0x06054C16u);  // 06054BD8 mov.w 0x06054C16,r13
    c.r[8] += c.r[1];  // 06054BDA add r1,r8
    c.r[8] += 2;  // 06054BDC add #2,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06054BDE mov.b @r8,r1
    c.r[13] += c.r[14];  // 06054BE0 add r14,r13
    c.r[1] = c.r[1] & 0xFFu;  // 06054BE2 extu.b r1,r1
    c.r[8] = ld32(c.r[13]);  // 06054BE4 mov.l @r13,r8
    c.macl = c.r[1] * c.r[11];  // 06054BE6 mul.l r11,r1
    c.r[2] = ld32(c.r[0]);  // 06054BE8 mov.l @r0,r2
    c.r[8] += c.r[10];  // 06054BEA add r10,r8
    c.r[1] = c.macl;  // 06054BEC sts macl,r1
    c.r[1] += c.r[2];  // 06054BEE add r2,r1
    c.r[1] += 15;  // 06054BF0 add #15,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06054BF2 mov.b @r1,r5
    c.r[4] = c.r[8];  // 06054BF4 mov r8,r4
    c.r[1] = ld32(0x06054C3Cu);  // 06054BF6 mov.l 0x06054C3C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06054BFCu; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06054BFCu) return; }  // 06054BF8 jsr @r1 ; extu.b r5,r5
    c.r[8] += 22;  // 06054BFC add #22,r8
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06054BFE mov.w @r8,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06054C18u);  // 06054C00 mov.w 0x06054C18,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 06054C02 extu.w r1,r1
    c.t = c.r[1] > c.r[2];  // 06054C04 cmp/hi r2,r1
    { const bool k = !c.t; c.r[1] = 0x0u; if (k) { goto L_06054C56; } }  // 06054C06 bf/s 0x06054C56 ; mov #0,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06054C16u);  // 06054C0A mov.w 0x06054C16,r0
    c.r[0] += c.r[14]; goto L_06054C40;  // 06054C0C bra 0x06054C40 ; add r14,r0
L_06054C40:
    c.r[13] = ld32(c.r[0]);  // 06054C40 mov.l @r0,r13
    c.r[13] += 32;  // 06054C42 add #32,r13
    st32(c.r[0], c.r[13]);  // 06054C44 mov.l r13,@r0
    c.r[0] = (uint32_t)(int16_t)ld16(0x06054D7Cu);  // 06054C46 mov.w 0x06054D7C,r0
    c.r[13] = ld32(c.r[0] + c.r[14]);  // 06054C48 mov.l @(r0,r14),r13
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[13]);  // 06054C4A mov.w @r13,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06054C4C extu.w r1,r1
    c.t = c.r[1] > c.r[2];  // 06054C4E cmp/hi r2,r1
    { const bool k = c.t; c.r[1] = 0x1u; if (k) { goto L_06054C56; } }  // 06054C50 bt/s 0x06054C56 ; mov #1,r1
    c.r[1] = 0x0u;  // 06054C54 mov #0,r1
L_06054C56:
    c.r[1] = c.r[1] & 0xFFu;  // 06054C56 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06054C58 tst r1,r1
    { const bool k = c.t; c.r[2] = c.r[12]; if (k) { goto L_06054CF4; } }  // 06054C5A bt/s 0x06054CF4 ; mov r12,r2
    c.r[1] = ld32(0x06054D84u);  // 06054C5E mov.l 0x06054D84,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06054C60 mov.b @r1,r1
    c.r[11] = ld32(0x06054D88u);  // 06054C62 mov.l 0x06054D88,r11
    c.r[5] = ld32(c.r[11]);  // 06054C64 mov.l @r11,r5
    c.r[10] = c.r[1] & 0xFFu;  // 06054C66 extu.b r1,r10
    c.r[10] <<= 2;  // 06054C68 shll2 r10
    c.r[10] <<= 2;  // 06054C6A shll2 r10
    c.r[5] += c.r[10];  // 06054C6C add r10,r5
    c.r[1] = c.r[5];  // 06054C6E mov r5,r1
    c.r[1] += 7;  // 06054C70 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06054C72 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06054C74 mov r1,r0
    c.r[0] >>= 2;  // 06054C76 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06054C78 shlr r0
    c.r[0] >>= 2;  // 06054C7A shlr2 r0
    c.r[0] &= 0x1u;  // 06054C7C and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06054C7E tst r0,r0
    { const bool k = c.t; c.r[9] = c.r[14]; if (k) { goto L_06054C88; } }  // 06054C80 bt/s 0x06054C88 ; mov r14,r9
    goto L_06054DC0;  // 06054C84 bra 0x06054DC0 ; nop
L_06054C88:
    c.r[8] = (uint32_t)(int16_t)ld16(0x06054D7Eu);  // 06054C88 mov.w 0x06054D7E,r8
    c.r[9] += c.r[8];  // 06054C8A add r8,r9
    c.r[5] += 2;  // 06054C8C add #2,r5
    c.r[1] = ld32(0x06054D8Cu);  // 06054C8E mov.l 0x06054D8C,r1
    c.r[6] = (uint32_t)(int16_t)ld16(0x06054D80u);  // 06054C90 mov.w 0x06054D80,r6
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[5]);  // 06054C92 mov.b @r5,r5
    c.r[4] = c.r[9];  // 06054C94 mov r9,r4
    { const uint32_t x = c.r[1]; c.pr = 0x06054C9Au; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06054C9Au) return; }  // 06054C96 jsr @r1 ; extu.b r5,r5
    c.r[1] = ld32(c.r[11]);  // 06054C9A mov.l @r11,r1
    c.r[10] += c.r[1];  // 06054C9C add r1,r10
    c.r[10] += 2;  // 06054C9E add #2,r10
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[10]);  // 06054CA0 mov.b @r10,r2
    c.r[1] = ld32(0x06054D90u);  // 06054CA2 mov.l 0x06054D90,r1
    c.r[3] = ld32(c.r[1]);  // 06054CA4 mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06054CA6 extu.b r2,r2
    c.r[1] = 0x1Eu;  // 06054CA8 mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 06054CAA mul.l r1,r2
    c.r[8] += c.r[9];  // 06054CAC add r9,r8
    c.r[1] = c.macl;  // 06054CAE sts macl,r1
    c.r[1] += c.r[3];  // 06054CB0 add r3,r1
    c.r[1] += 15;  // 06054CB2 add #15,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06054CB4 mov.b @r1,r5
    c.r[4] = c.r[8];  // 06054CB6 mov r8,r4
    c.r[1] = ld32(0x06054D94u);  // 06054CB8 mov.l 0x06054D94,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06054CBEu; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06054CBEu) return; }  // 06054CBA jsr @r1 ; extu.b r5,r5
    c.r[8] += 22;  // 06054CBE add #22,r8
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06054CC0 mov.w @r8,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06054D82u);  // 06054CC2 mov.w 0x06054D82,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 06054CC4 extu.w r1,r1
    c.t = c.r[1] > c.r[2];  // 06054CC6 cmp/hi r2,r1
    { const bool k = !c.t; c.r[9] += 32; if (k) { goto L_06054CD6; } }  // 06054CC8 bf/s 0x06054CD6 ; add #32,r9
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]);  // 06054CCC mov.w @r9,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06054CCE extu.w r1,r1
    c.t = c.r[1] > c.r[2];  // 06054CD0 cmp/hi r2,r1
    { const bool k = c.t; c.r[1] = 0x1u; if (k) { goto L_06054CD8; } }  // 06054CD2 bt/s 0x06054CD8 ; mov #1,r1
L_06054CD6:
    c.r[1] = 0x0u;  // 06054CD6 mov #0,r1
L_06054CD8:
    c.r[1] = c.r[1] & 0xFFu;  // 06054CD8 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06054CDA tst r1,r1
    { const bool k = !c.t; c.r[2] = c.r[12]; if (k) { goto L_06054DC0; } }  // 06054CDC bf/s 0x06054DC0 ; mov r12,r2
    c.r[1] = ld32(0x06054D88u);  // 06054CE0 mov.l 0x06054D88,r1
    c.r[1] = ld32(c.r[1]);  // 06054CE2 mov.l @r1,r1
    c.r[2] <<= 2;  // 06054CE4 shll2 r2
    c.r[2] <<= 2;  // 06054CE6 shll2 r2
    c.r[2] += c.r[1];  // 06054CE8 add r1,r2
    c.r[2] += 7;  // 06054CEA add #7,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06054CEC mov.b @r2,r0
    c.r[0] |= 0x20u;  // 06054CEE or #32,r0
    st8(c.r[2], c.r[0]); goto L_06054DC0;  // 06054CF0 bra 0x06054DC0 ; mov.b r0,@r2
L_06054CF4:
    c.r[11] = ld32(0x06054D88u);  // 06054CF4 mov.l 0x06054D88,r11
    c.r[1] = ld32(c.r[11]);  // 06054CF6 mov.l @r11,r1
    c.r[2] <<= 2;  // 06054CF8 shll2 r2
    c.r[2] <<= 2;  // 06054CFA shll2 r2
    c.r[2] += c.r[1];  // 06054CFC add r1,r2
    c.r[2] += 7;  // 06054CFE add #7,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06054D00 mov.b @r2,r0
    c.r[1] = ld32(0x06054D84u);  // 06054D02 mov.l 0x06054D84,r1
    c.r[0] &= 0xDFu;  // 06054D04 and #223,r0
    st8(c.r[2], c.r[0]);  // 06054D06 mov.b r0,@r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06054D08 mov.b @r1,r1
    c.r[5] = ld32(c.r[11]);  // 06054D0A mov.l @r11,r5
    c.r[10] = c.r[1] & 0xFFu;  // 06054D0C extu.b r1,r10
    c.r[10] <<= 2;  // 06054D0E shll2 r10
    c.r[10] <<= 2;  // 06054D10 shll2 r10
    c.r[5] += c.r[10];  // 06054D12 add r10,r5
    c.r[1] = c.r[5];  // 06054D14 mov r5,r1
    c.r[1] += 7;  // 06054D16 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06054D18 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06054D1A mov r1,r0
    c.r[0] >>= 2;  // 06054D1C shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06054D1E shlr r0
    c.r[0] >>= 2;  // 06054D20 shlr2 r0
    c.r[0] &= 0x1u;  // 06054D22 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06054D24 tst r0,r0
    { const bool k = !c.t; c.r[9] = c.r[14]; if (k) { goto L_06054DC0; } }  // 06054D26 bf/s 0x06054DC0 ; mov r14,r9
    c.r[8] = (uint32_t)(int16_t)ld16(0x06054D7Eu);  // 06054D2A mov.w 0x06054D7E,r8
    c.r[9] += c.r[8];  // 06054D2C add r8,r9
    c.r[5] += 2;  // 06054D2E add #2,r5
    c.r[1] = ld32(0x06054D8Cu);  // 06054D30 mov.l 0x06054D8C,r1
    c.r[6] = (uint32_t)(int16_t)ld16(0x06054D80u);  // 06054D32 mov.w 0x06054D80,r6
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[5]);  // 06054D34 mov.b @r5,r5
    c.r[4] = c.r[9];  // 06054D36 mov r9,r4
    { const uint32_t x = c.r[1]; c.pr = 0x06054D3Cu; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06054D3Cu) return; }  // 06054D38 jsr @r1 ; extu.b r5,r5
    c.r[1] = ld32(c.r[11]);  // 06054D3C mov.l @r11,r1
    c.r[10] += c.r[1];  // 06054D3E add r1,r10
    c.r[10] += 2;  // 06054D40 add #2,r10
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[10]);  // 06054D42 mov.b @r10,r2
    c.r[1] = ld32(0x06054D90u);  // 06054D44 mov.l 0x06054D90,r1
    c.r[3] = ld32(c.r[1]);  // 06054D46 mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06054D48 extu.b r2,r2
    c.r[1] = 0x1Eu;  // 06054D4A mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 06054D4C mul.l r1,r2
    c.r[8] += c.r[9];  // 06054D4E add r9,r8
    c.r[1] = c.macl;  // 06054D50 sts macl,r1
    c.r[1] += c.r[3];  // 06054D52 add r3,r1
    c.r[1] += 15;  // 06054D54 add #15,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06054D56 mov.b @r1,r5
    c.r[4] = c.r[8];  // 06054D58 mov r8,r4
    c.r[1] = ld32(0x06054D94u);  // 06054D5A mov.l 0x06054D94,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06054D60u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06054D60u) return; }  // 06054D5C jsr @r1 ; extu.b r5,r5
    c.r[8] += 22;  // 06054D60 add #22,r8
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06054D62 mov.w @r8,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06054D82u);  // 06054D64 mov.w 0x06054D82,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 06054D66 extu.w r1,r1
    c.t = c.r[1] > c.r[2];  // 06054D68 cmp/hi r2,r1
    { const bool k = !c.t; c.r[9] += 32; if (k) { goto L_06054D98; } }  // 06054D6A bf/s 0x06054D98 ; add #32,r9
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]);  // 06054D6E mov.w @r9,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06054D70 extu.w r1,r1
    c.t = c.r[1] > c.r[2];  // 06054D72 cmp/hi r2,r1
    { const bool k = !c.t; c.r[1] = 0x1u; if (k) { goto L_06054D98; } }  // 06054D74 bf/s 0x06054D98 ; mov #1,r1
    c.r[1] = c.r[1] & 0xFFu; goto L_06054D9C;  // 06054D78 bra 0x06054D9C ; extu.b r1,r1
L_06054D98:
    c.r[1] = 0x0u;  // 06054D98 mov #0,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06054D9A extu.b r1,r1
L_06054D9C:
    c.t = (c.r[1] & c.r[1]) == 0;  // 06054D9C tst r1,r1
    { const bool k = c.t; c.r[2] = c.r[12]; if (k) { goto L_06054DC0; } }  // 06054D9E bt/s 0x06054DC0 ; mov r12,r2
    c.r[3] = ld32(0x06054F24u);  // 06054DA2 mov.l 0x06054F24,r3
    c.r[1] = ld32(c.r[3]);  // 06054DA4 mov.l @r3,r1
    c.r[2] <<= 2;  // 06054DA6 shll2 r2
    c.r[2] <<= 2;  // 06054DA8 shll2 r2
    c.r[1] += c.r[2];  // 06054DAA add r2,r1
    c.r[1] += 7;  // 06054DAC add #7,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06054DAE mov.b @r1,r0
    c.r[0] |= 0x10u;  // 06054DB0 or #16,r0
    st8(c.r[1], c.r[0]);  // 06054DB2 mov.b r0,@r1
    c.r[1] = ld32(c.r[3]);  // 06054DB4 mov.l @r3,r1
    c.r[1] += c.r[2];  // 06054DB6 add r2,r1
    c.r[1] += 3;  // 06054DB8 add #3,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06054DBA mov.b @r1,r0
    c.r[0] &= 0xDFu;  // 06054DBC and #223,r0
    st8(c.r[1], c.r[0]);  // 06054DBE mov.b r0,@r1
L_06054DC0:
    c.r[1] = ld32(0x06054F24u);  // 06054DC0 mov.l 0x06054F24,r1
    c.r[2] = c.r[12];  // 06054DC2 mov r12,r2
    c.r[2] <<= 2;  // 06054DC4 shll2 r2
    c.r[2] <<= 2;  // 06054DC6 shll2 r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06054F14u);  // 06054DC8 mov.w 0x06054F14,r0
    c.r[0] += c.r[14];  // 06054DCA add r14,r0
    c.r[8] = (uint32_t)(int16_t)ld16(0x06054F16u);  // 06054DCC mov.w 0x06054F16,r8
    c.r[6] = c.r[8];  // 06054DCE mov r8,r6
    c.r[13] = (uint32_t)(int16_t)ld16(0x06054F14u);  // 06054DD0 mov.w 0x06054F14,r13
    c.r[1] = ld32(c.r[1]);  // 06054DD2 mov.l @r1,r1
    c.r[13] += c.r[14];  // 06054DD4 add r14,r13
    c.r[2] += c.r[1];  // 06054DD6 add r1,r2
    c.r[2] += 2;  // 06054DD8 add #2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06054DDA mov.b @r2,r1
    c.r[4] = c.r[14];  // 06054DDC mov r14,r4
    c.r[1] = c.r[1] & 0xFFu;  // 06054DDE extu.b r1,r1
    st32(c.r[0], c.r[1]);  // 06054DE0 mov.l r1,@r0
    c.r[1] = ld32(0x06054F28u);  // 06054DE2 mov.l 0x06054F28,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06054DE8u; c.r[5] = ld32(c.r[13]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06054DE8u) return; }  // 06054DE4 jsr @r1 ; mov.l @r13,r5
    c.r[0] = (uint32_t)(int16_t)ld16(0x06054F18u);  // 06054DE8 mov.w 0x06054F18,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06054DEA mov.l @(r0,r14),r0
    c.t = c.r[0] == c.r[8];  // 06054DEC cmp/eq r8,r0
    { const bool k = !c.t; c.r[1] = 0x1Eu; if (k) { goto L_06054E1C; } }  // 06054DEE bf/s 0x06054E1C ; mov #30,r1
    c.r[1] = ld32(0x06054F2Cu);  // 06054DF2 mov.l 0x06054F2C,r1
    c.r[13] = (uint32_t)(int16_t)ld16(0x06054F14u);  // 06054DF4 mov.w 0x06054F14,r13
    c.r[2] = ld32(c.r[1]);  // 06054DF6 mov.l @r1,r2
    c.r[13] += c.r[14];  // 06054DF8 add r14,r13
    c.r[13] = ld32(c.r[13]);  // 06054DFA mov.l @r13,r13
    c.r[1] = 0x1Eu;  // 06054DFC mov #30,r1
    c.macl = c.r[13] * c.r[1];  // 06054DFE mul.l r1,r13
    c.r[3] = c.macl;  // 06054E00 sts macl,r3
    c.r[3] += c.r[2];  // 06054E02 add r2,r3
    c.r[2] = c.r[3];  // 06054E04 mov r3,r2
    c.r[1] = c.r[14];  // 06054E06 mov r14,r1
    c.r[1] += 26;  // 06054E08 add #26,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06054E0A mov.w @r1,r1
    c.r[2] += 22;  // 06054E0C add #22,r2
    st16(c.r[2], c.r[1]);  // 06054E0E mov.w r1,@r2
    c.r[1] = c.r[14];  // 06054E10 mov r14,r1
    c.r[1] += 28;  // 06054E12 add #28,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06054E14 mov.w @r1,r1
    c.r[3] += 24;  // 06054E16 add #24,r3
    st16(c.r[3], c.r[1]); goto L_06054E8A;  // 06054E18 bra 0x06054E8A ; mov.w r1,@r3
L_06054E1C:
    c.r[11] = ld32(0x06054F2Cu);  // 06054E1C mov.l 0x06054F2C,r11
    c.r[0] = (uint32_t)(int16_t)ld16(0x06054F14u);  // 06054E1E mov.w 0x06054F14,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06054E20 mov.l @(r0,r14),r0
    c.r[13] = (uint32_t)(int16_t)ld16(0x06054F1Au);  // 06054E22 mov.w 0x06054F1A,r13
    c.r[2] = ld32(c.r[11]);  // 06054E24 mov.l @r11,r2
    c.macl = c.r[0] * c.r[1];  // 06054E26 mul.l r1,r0
    c.r[13] += c.r[14];  // 06054E28 add r14,r13
    c.r[13] = ld32(c.r[13]);  // 06054E2A mov.l @r13,r13
    c.r[7] = c.macl;  // 06054E2C sts macl,r7
    c.macl = c.r[13] * c.r[1];  // 06054E2E mul.l r1,r13
    c.r[6] = c.r[7];  // 06054E30 mov r7,r6
    c.r[6] += c.r[2];  // 06054E32 add r2,r6
    c.r[8] = c.macl;  // 06054E34 sts macl,r8
    c.r[2] += c.r[8];  // 06054E36 add r8,r2
    c.r[2] += 22;  // 06054E38 add #22,r2
    c.r[1] = c.r[14];  // 06054E3A mov r14,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06054E3C mov.w @r2,r2
    c.r[1] += 26;  // 06054E3E add #26,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06054E40 mov.w @r1,r1
    c.r[10] = ld32(0x06054F30u);  // 06054E42 mov.l 0x06054F30,r10
    c.macl = (c.r[2] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 06054E44 mulu.w r1,r2
    c.r[9] = ld32(0x06054F34u);  // 06054E46 mov.l 0x06054F34,r9
    c.r[1] = ld32(c.r[10]);  // 06054E48 mov.l @r10,r1
    c.r[6] += 22;  // 06054E4A add #22,r6
    c.r[1] += 26;  // 06054E4C add #26,r1
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06054E4E mov.w @r1,r5
    c.r[4] = c.macl;  // 06054E50 sts macl,r4
    c.macl = c.r[7];  // 06054E52 lds r7,macl
    { const uint32_t x = c.r[9]; c.pr = 0x06054E58u; c.r[5] = c.r[5] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06054E58u) return; }  // 06054E54 jsr @r9 ; extu.w r5,r5
    c.r[5] = c.r[0];  // 06054E58 mov r0,r5
    c.r[1] = c.r[5] & 0xFFFFu;  // 06054E5A extu.w r5,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06054E5C tst r1,r1
    { const bool k = !c.t; st16(c.r[6], c.r[5]); if (k) { goto L_06054E66; } }  // 06054E5E bf/s 0x06054E66 ; mov.w r5,@r6
    c.r[1] = 0x1u;  // 06054E62 mov #1,r1
    st16(c.r[6], c.r[1]);  // 06054E64 mov.w r1,@r6
L_06054E66:
    c.r[1] = ld32(c.r[11]);  // 06054E66 mov.l @r11,r1
    c.r[7] = c.macl;  // 06054E68 sts macl,r7
    c.r[7] += c.r[1];  // 06054E6A add r1,r7
    c.r[8] += c.r[1];  // 06054E6C add r1,r8
    c.r[8] += 24;  // 06054E6E add #24,r8
    c.r[1] = c.r[14];  // 06054E70 mov r14,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06054E72 mov.w @r8,r2
    c.r[1] += 28;  // 06054E74 add #28,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06054E76 mov.w @r1,r1
    c.macl = (c.r[2] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 06054E78 mulu.w r1,r2
    c.r[1] = ld32(c.r[10]);  // 06054E7A mov.l @r10,r1
    c.r[7] += 24;  // 06054E7C add #24,r7
    c.r[1] += 28;  // 06054E7E add #28,r1
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06054E80 mov.w @r1,r5
    c.r[4] = c.macl;  // 06054E82 sts macl,r4
    { const uint32_t x = c.r[9]; c.pr = 0x06054E88u; c.r[5] = c.r[5] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06054E88u) return; }  // 06054E84 jsr @r9 ; extu.w r5,r5
    st16(c.r[7], c.r[0]);  // 06054E88 mov.w r0,@r7
L_06054E8A:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06054F1Cu);  // 06054E8A mov.w 0x06054F1C,r1
    c.r[0] = c.r[14];  // 06054E8C mov r14,r0
    c.r[13] = (uint32_t)(int16_t)ld16(0x06054F14u);  // 06054E8E mov.w 0x06054F14,r13
    c.r[13] += c.r[14];  // 06054E90 add r14,r13
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06054E92 mov.b @(r0,r1),r1
    c.r[2] = 0x0u;  // 06054E94 mov #0,r2
    c.r[13] = ld32(c.r[13]);  // 06054E96 mov.l @r13,r13
    c.r[3] = c.r[1];  // 06054E98 mov r1,r3
    c.r[3] >>= 2;  // 06054E9A shlr2 r3
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 06054E9C shlr r3
    c.r[1] = 0x1Eu;  // 06054E9E mov #30,r1
    c.r[0] = 0x7u;  // 06054EA0 mov #7,r0
    c.macl = c.r[13] * c.r[1];  // 06054EA2 mul.l r1,r13
    c.r[3] &= c.r[0];  // 06054EA4 and r0,r3
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[3];  // 06054EA6 cmp/ge r3,r2
    c.r[1] = ld32(0x06054F2Cu);  // 06054EA8 mov.l 0x06054F2C,r1
    c.r[1] = ld32(c.r[1]);  // 06054EAA mov.l @r1,r1
    c.r[7] = c.macl;  // 06054EAC sts macl,r7
    c.r[7] += c.r[1];  // 06054EAE add r1,r7
    { const bool k = c.t; c.r[7] += 17; if (k) { goto L_06054EC8; } }  // 06054EB0 bt/s 0x06054EC8 ; add #17,r7
    c.r[0] = c.r[7];  // 06054EB4 mov r7,r0
L_06054EB6:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06054EB6 mov.b @(r0,r2),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06054EB8 extu.b r1,r1
    c.r[0] = c.r[1];  // 06054EBA mov r1,r0
    c.t = c.r[0] == 0xAu;  // 06054EBC cmp/eq #10,r0
    if (c.t) { goto L_06054EC8; }  // 06054EBE bt 0x06054EC8
    c.r[2] += 1;  // 06054EC0 add #1,r2
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[3];  // 06054EC2 cmp/ge r3,r2
    { const bool k = !c.t; c.r[0] = c.r[7]; if (k) { SH2_POLL(c); goto L_06054EB6; } }  // 06054EC4 bf/s 0x06054EB6 ; mov r7,r0
L_06054EC8:
    c.t = c.r[2] == c.r[3];  // 06054EC8 cmp/eq r3,r2
    { const bool k = c.t; c.r[1] = 0xFFFFFFFFu; if (k) { goto L_06054ED0; } }  // 06054ECA bt/s 0x06054ED0 ; mov #-1,r1
    c.r[1] = c.r[2];  // 06054ECE mov r2,r1
L_06054ED0:
    c.r[1] = (uint32_t)(int32_t)(int8_t)c.r[1];  // 06054ED0 exts.b r1,r1
    c.r[0] = c.r[1];  // 06054ED2 mov r1,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 06054ED4 cmp/eq #-1,r0
    c.r[7] = c.t;  // 06054ED6 movt r7
    c.r[13] = 0x1u;  // 06054ED8 mov #1,r13
    c.r[7] ^= c.r[13];  // 06054EDA xor r13,r7
    c.r[1] = ld32(0x06054F24u);  // 06054EDC mov.l 0x06054F24,r1
    c.r[2] = c.r[12];  // 06054EDE mov r12,r2
    c.r[2] <<= 2;  // 06054EE0 shll2 r2
    c.r[2] <<= 2;  // 06054EE2 shll2 r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06054F1Eu);  // 06054EE4 mov.w 0x06054F1E,r0
    c.r[0] += c.r[14];  // 06054EE6 add r14,r0
    c.r[1] = ld32(c.r[1]);  // 06054EE8 mov.l @r1,r1
    c.r[13] = (uint32_t)(int16_t)ld16(0x06054F20u);  // 06054EEA mov.w 0x06054F20,r13
    c.r[2] += c.r[1];  // 06054EEC add r1,r2
    c.r[1] = ld32(c.r[0]);  // 06054EEE mov.l @r0,r1
    c.r[2] += 3;  // 06054EF0 add #3,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06054EF2 mov.b @r2,r3
    c.r[1] <<= 2;  // 06054EF4 shll2 r1
    c.r[1] += c.r[1];  // 06054EF6 add r1,r1
    c.r[3] &= c.r[13];  // 06054EF8 and r13,r3
    c.r[3] |= c.r[1];  // 06054EFA or r1,r3
    c.t = (c.r[7] & c.r[7]) == 0;  // 06054EFC tst r7,r7
    { const bool k = !c.t; st8(c.r[2], c.r[3]); if (k) { goto L_06054F38; } }  // 06054EFE bf/s 0x06054F38 ; mov.b r3,@r2
    c.r[1] = c.r[14];  // 06054F02 mov r14,r1
    c.r[1] += 37;  // 06054F04 add #37,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06054F06 mov.b @r1,r1
    c.r[0] = 0x10u;  // 06054F08 mov #16,r0
    c.r[1] = c.r[1] & 0xFFu;  // 06054F0A extu.b r1,r1
    c.r[1] >>= 2;  // 06054F0C shlr2 r1
    c.r[1] >>= 2;  // 06054F0E shlr2 r1
    c.r[1] |= c.r[0]; goto L_06054F3A;  // 06054F10 bra 0x06054F3A ; or r0,r1
L_06054F38:
    c.r[1] = 0x16u;  // 06054F38 mov #22,r1
L_06054F3A:
    c.r[13] = (uint32_t)(int16_t)ld16(0x060550A2u);  // 06054F3A mov.w 0x060550A2,r13
    c.r[13] += c.r[14];  // 06054F3C add r14,r13
    st32(c.r[13], c.r[1]);  // 06054F3E mov.l r1,@r13
    c.r[0] = (uint32_t)(int16_t)ld16(0x060550A4u);  // 06054F40 mov.w 0x060550A4,r0
    c.r[0] += c.r[14];  // 06054F42 add r14,r0
    c.r[9] = ld32(0x060550B0u);  // 06054F44 mov.l 0x060550B0,r9
    c.r[8] = c.r[12];  // 06054F46 mov r12,r8
    c.r[8] <<= 2;  // 06054F48 shll2 r8
    c.r[8] <<= 2;  // 06054F4A shll2 r8
    c.r[1] = c.r[8];  // 06054F4C mov r8,r1
    c.r[10] = ld32(0x060550B4u);  // 06054F4E mov.l 0x060550B4,r10
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06054F50 mov.b @r0,r7
    c.r[13] = (uint32_t)(int16_t)ld16(0x060550A2u);  // 06054F52 mov.w 0x060550A2,r13
    c.r[2] = ld32(c.r[9]);  // 06054F54 mov.l @r9,r2
    c.r[13] += c.r[14];  // 06054F56 add r14,r13
    c.r[6] = ld32(c.r[13]);  // 06054F58 mov.l @r13,r6
    c.r[1] += c.r[2];  // 06054F5A add r2,r1
    c.r[1] += 1;  // 06054F5C add #1,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06054F5E mov.b @r1,r5
    c.r[0] = c.r[8];  // 06054F60 mov r8,r0
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06054F62 mov.b @(r0,r2),r4
    c.r[5] = c.r[5] & 0xFFu;  // 06054F64 extu.b r5,r5
    { const uint32_t x = c.r[10]; c.pr = 0x06054F6Au; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06054F6Au) return; }  // 06054F66 jsr @r10 ; extu.b r4,r4
    c.r[1] = c.r[0];  // 06054F6A mov r0,r1
    c.r[1] = (uint32_t)(int32_t)(int8_t)c.r[1];  // 06054F6C exts.b r1,r1
    c.t = (int32_t)c.r[1] >= 0;  // 06054F6E cmp/pz r1
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_06054FAC; } }  // 06054F70 bt/s 0x06054FAC ; mov #0,r0
    c.r[1] = c.r[8];  // 06054F74 mov r8,r1
    c.r[0] = c.r[8];  // 06054F76 mov r8,r0
    c.r[13] = (uint32_t)(int16_t)ld16(0x060550A2u);  // 06054F78 mov.w 0x060550A2,r13
    c.r[2] = ld32(c.r[9]);  // 06054F7A mov.l @r9,r2
    c.r[13] += c.r[14];  // 06054F7C add r14,r13
    c.r[6] = ld32(c.r[13]);  // 06054F7E mov.l @r13,r6
    c.r[1] += c.r[2];  // 06054F80 add r2,r1
    c.r[1] += 1;  // 06054F82 add #1,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06054F84 mov.b @r1,r5
    c.r[7] = 0xFFFFFFFFu;  // 06054F86 mov #-1,r7
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06054F88 mov.b @(r0,r2),r4
    c.r[5] = c.r[5] & 0xFFu;  // 06054F8A extu.b r5,r5
    { const uint32_t x = c.r[10]; c.pr = 0x06054F90u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06054F90u) return; }  // 06054F8C jsr @r10 ; extu.b r4,r4
    c.r[2] = c.r[0];  // 06054F90 mov r0,r2
    c.r[3] = 0x3u;  // 06054F92 mov #3,r3
    c.r[3] &= c.r[2];  // 06054F94 and r2,r3
    c.r[1] = ld32(c.r[9]);  // 06054F96 mov.l @r9,r1
    c.r[3] <<= 2;  // 06054F98 shll2 r3
    c.r[3] += c.r[3];  // 06054F9A add r3,r3
    c.r[1] += c.r[8];  // 06054F9C add r8,r1
    c.r[1] += 3;  // 06054F9E add #3,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06054FA0 mov.b @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x060550A6u);  // 06054FA2 mov.w 0x060550A6,r0
    c.r[2] &= c.r[0];  // 06054FA4 and r0,r2
    c.r[2] |= c.r[3];  // 06054FA6 or r3,r2
    st8(c.r[1], c.r[2]);  // 06054FA8 mov.b r2,@r1
    c.r[0] = 0x0u;  // 06054FAA mov #0,r0
L_06054FAC:
    c.r[13] = (uint32_t)(int16_t)ld16(0x060550A2u);  // 06054FAC mov.w 0x060550A2,r13
    c.r[13] += c.r[14];  // 06054FAE add r14,r13
    st32(c.r[13], c.r[0]);  // 06054FB0 mov.l r0,@r13
    c.r[13] = 0x3u;  // 06054FB2 mov #3,r13
    c.r[1] = ld32(c.r[9]);  // 06054FB4 mov.l @r9,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060550A8u);  // 06054FB6 mov.w 0x060550A8,r0
    c.r[8] += c.r[1];  // 06054FB8 add r1,r8
    c.r[8] += 3;  // 06054FBA add #3,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06054FBC mov.b @r8,r1
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06054FBE mov.l @(r0,r14),r0
    c.r[1] >>= 2;  // 06054FC0 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06054FC2 shlr r1
    c.r[1] &= c.r[13];  // 06054FC4 and r13,r1
    c.t = c.r[0] == c.r[1];  // 06054FC6 cmp/eq r1,r0
    if (c.t) { goto L_06055062; }  // 06054FC8 bt 0x06055062
    c.r[13] = (uint32_t)(int16_t)ld16(0x060550A8u);  // 06054FCA mov.w 0x060550A8,r13
    c.r[13] += c.r[14];  // 06054FCC add r14,r13
    c.r[13] = ld32(c.r[13]);  // 06054FCE mov.l @r13,r13
    c.t = (c.r[13] & c.r[13]) == 0;  // 06054FD0 tst r13,r13
    { const bool k = !c.t; c.t = (c.r[1] & c.r[1]) == 0; if (k) { goto L_06054FDE; } }  // 06054FD2 bf/s 0x06054FDE ; tst r1,r1
    if (c.t) { goto L_06054FDE; }  // 06054FD6 bt 0x06054FDE
    c.r[13] = 0x1u;  // 06054FD8 mov #1,r13
    c.r[0] = (uint32_t)(int16_t)ld16(0x060550A2u);  // 06054FDA mov.w 0x060550A2,r0
    st32(c.r[0] + c.r[14], c.r[13]);  // 06054FDC mov.l r13,@(r0,r14)
L_06054FDE:
    c.r[0] = (uint32_t)(int16_t)ld16(0x060550A8u);  // 06054FDE mov.w 0x060550A8,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06054FE0 mov.l @(r0,r14),r0
    c.t = c.r[0] == 0x1u;  // 06054FE2 cmp/eq #1,r0
    { const bool k = !c.t; c.r[2] = c.r[12]; if (k) { goto L_0605500A; } }  // 06054FE4 bf/s 0x0605500A ; mov r12,r2
    c.r[1] = ld32(0x060550B0u);  // 06054FE8 mov.l 0x060550B0,r1
    c.r[1] = ld32(c.r[1]);  // 06054FEA mov.l @r1,r1
    c.r[2] <<= 2;  // 06054FEC shll2 r2
    c.r[2] <<= 2;  // 06054FEE shll2 r2
    c.r[2] += c.r[1];  // 06054FF0 add r1,r2
    c.r[2] += 3;  // 06054FF2 add #3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06054FF4 mov.b @r2,r1
    c.r[0] = c.r[1];  // 06054FF6 mov r1,r0
    c.r[0] >>= 2;  // 06054FF8 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06054FFA shlr r0
    c.r[0] &= 0x3u;  // 06054FFC and #3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06054FFE tst r0,r0
    { const bool k = !c.t; c.r[0] = 0x2u; if (k) { goto L_0605500A; } }  // 06055000 bf/s 0x0605500A ; mov #2,r0
    c.r[13] = (uint32_t)(int16_t)ld16(0x060550A2u);  // 06055004 mov.w 0x060550A2,r13
    c.r[13] += c.r[14];  // 06055006 add r14,r13
    st32(c.r[13], c.r[0]);  // 06055008 mov.l r0,@r13
L_0605500A:
    c.r[0] = (uint32_t)(int16_t)ld16(0x060550A8u);  // 0605500A mov.w 0x060550A8,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 0605500C mov.l @(r0,r14),r0
    c.t = c.r[0] == 0x2u;  // 0605500E cmp/eq #2,r0
    { const bool k = !c.t; c.r[2] = c.r[12]; if (k) { goto L_06055036; } }  // 06055010 bf/s 0x06055036 ; mov r12,r2
    c.r[1] = ld32(0x060550B0u);  // 06055014 mov.l 0x060550B0,r1
    c.r[1] = ld32(c.r[1]);  // 06055016 mov.l @r1,r1
    c.r[2] <<= 2;  // 06055018 shll2 r2
    c.r[2] <<= 2;  // 0605501A shll2 r2
    c.r[2] += c.r[1];  // 0605501C add r1,r2
    c.r[2] += 3;  // 0605501E add #3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06055020 mov.b @r2,r1
    c.r[0] = c.r[1];  // 06055022 mov r1,r0
    c.r[0] >>= 2;  // 06055024 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06055026 shlr r0
    c.r[0] &= 0x3u;  // 06055028 and #3,r0
    c.t = c.r[0] == 0x1u;  // 0605502A cmp/eq #1,r0
    { const bool k = !c.t; c.r[0] = 0x3u; if (k) { goto L_06055036; } }  // 0605502C bf/s 0x06055036 ; mov #3,r0
    c.r[13] = (uint32_t)(int16_t)ld16(0x060550A2u);  // 06055030 mov.w 0x060550A2,r13
    c.r[13] += c.r[14];  // 06055032 add r14,r13
    st32(c.r[13], c.r[0]);  // 06055034 mov.l r0,@r13
L_06055036:
    c.r[0] = (uint32_t)(int16_t)ld16(0x060550A8u);  // 06055036 mov.w 0x060550A8,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06055038 mov.l @(r0,r14),r0
    c.t = c.r[0] == 0x2u;  // 0605503A cmp/eq #2,r0
    { const bool k = !c.t; c.r[2] = c.r[12]; if (k) { goto L_06055062; } }  // 0605503C bf/s 0x06055062 ; mov r12,r2
    c.r[1] = ld32(0x060550B0u);  // 06055040 mov.l 0x060550B0,r1
    c.r[1] = ld32(c.r[1]);  // 06055042 mov.l @r1,r1
    c.r[2] <<= 2;  // 06055044 shll2 r2
    c.r[2] <<= 2;  // 06055046 shll2 r2
    c.r[2] += c.r[1];  // 06055048 add r1,r2
    c.r[2] += 3;  // 0605504A add #3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605504C mov.b @r2,r1
    c.r[0] = c.r[1];  // 0605504E mov r1,r0
    c.r[0] >>= 2;  // 06055050 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06055052 shlr r0
    c.r[0] &= 0x3u;  // 06055054 and #3,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06055056 tst r0,r0
    { const bool k = !c.t; c.r[0] = 0x4u; if (k) { goto L_06055062; } }  // 06055058 bf/s 0x06055062 ; mov #4,r0
    c.r[13] = (uint32_t)(int16_t)ld16(0x060550A2u);  // 0605505C mov.w 0x060550A2,r13
    c.r[13] += c.r[14];  // 0605505E add r14,r13
    st32(c.r[13], c.r[0]);  // 06055060 mov.l r0,@r13
L_06055062:
    c.r[13] = ld32(0x060550B0u);  // 06055062 mov.l 0x060550B0,r13
    c.r[2] = c.r[12];  // 06055064 mov r12,r2
    c.r[2] <<= 2;  // 06055066 shll2 r2
    c.r[2] <<= 2;  // 06055068 shll2 r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x060550A8u);  // 0605506A mov.w 0x060550A8,r0
    c.r[0] += c.r[14];  // 0605506C add r14,r0
    c.r[10] = ld32(0x060550B8u);  // 0605506E mov.l 0x060550B8,r10
    c.r[11] = (uint32_t)(int16_t)ld16(0x060550AAu);  // 06055070 mov.w 0x060550AA,r11
    c.r[11] += c.r[14];  // 06055072 add r14,r11
    c.r[9] = ld32(0x060550BCu);  // 06055074 mov.l 0x060550BC,r9
    c.r[6] = (uint32_t)(int16_t)ld16(0x060550ACu);  // 06055076 mov.w 0x060550AC,r6
    c.r[1] = ld32(c.r[13]);  // 06055078 mov.l @r13,r1
    c.r[4] = c.r[11];  // 0605507A mov r11,r4
    c.r[2] += c.r[1];  // 0605507C add r1,r2
    c.r[13] = ld32(c.r[0]);  // 0605507E mov.l @r0,r13
    c.r[2] += 3;  // 06055080 add #3,r2
    c.r[13] <<= 2;  // 06055082 shll2 r13
    c.r[13] += c.r[13];  // 06055084 add r13,r13
    st32(c.r[0], c.r[13]);  // 06055086 mov.l r13,@r0
    c.r[0] = (uint32_t)(int16_t)ld16(0x060550A6u);  // 06055088 mov.w 0x060550A6,r0
    c.r[13] = (uint32_t)(int16_t)ld16(0x060550A8u);  // 0605508A mov.w 0x060550A8,r13
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605508C mov.b @r2,r1
    c.r[13] += c.r[14];  // 0605508E add r14,r13
    c.r[13] = ld32(c.r[13]);  // 06055090 mov.l @r13,r13
    c.r[1] &= c.r[0];  // 06055092 and r0,r1
    c.r[1] |= c.r[13];  // 06055094 or r13,r1
    st8(c.r[2], c.r[1]);  // 06055096 mov.b r1,@r2
    st8(c.r[10], c.r[12]);  // 06055098 mov.b r12,@r10
    c.r[2] = c.r[12];  // 0605509A mov r12,r2
    c.r[0] = ld32(0x060550B0u);  // 0605509C mov.l 0x060550B0,r0
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[9]); goto L_060550C0;  // 0605509E bra 0x060550C0 ; mov.w @r9,r8
L_060550C0:
    c.r[1] = ld32(c.r[0]);  // 060550C0 mov.l @r0,r1
    c.r[8] += c.r[2];  // 060550C2 add r2,r8
    c.r[8] += 1;  // 060550C4 add #1,r8
    c.r[8] = c.r[8] & 0xFFFFu;  // 060550C6 extu.w r8,r8
    c.r[2] <<= 2;  // 060550C8 shll2 r2
    c.r[2] <<= 2;  // 060550CA shll2 r2
    c.r[2] += c.r[1];  // 060550CC add r1,r2
    c.r[2] += 2;  // 060550CE add #2,r2
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060550D0 mov.b @r2,r5
    c.r[1] = ld32(0x060551DCu);  // 060550D2 mov.l 0x060551DC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060550D8u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060550D8u) return; }  // 060550D4 jsr @r1 ; extu.b r5,r5
    c.r[13] = ld32(0x060551E0u);  // 060550D8 mov.l 0x060551E0,r13
    c.r[3] = c.r[8];  // 060550DA mov r8,r3
    c.r[3] <<= 2;  // 060550DC shll2 r3
    c.r[3] += c.r[8];  // 060550DE add r8,r3
    c.r[3] += c.r[3];  // 060550E0 add r3,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x060551D2u);  // 060550E2 mov.w 0x060551D2,r1
    c.r[0] = c.r[11];  // 060550E4 mov r11,r0
    c.r[6] = 0x0u;  // 060550E6 mov #0,r6
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 060550E8 mov.w @(r0,r1),r2
    c.r[5] = 0x0u;  // 060550EA mov #0,r5
    c.r[7] = ld32(c.r[13] + 8);  // 060550EC mov.l @(8,r13),r7
    c.r[2] = c.r[2] & 0xFFFFu;  // 060550EE extu.w r2,r2
    c.r[2] >>= 2;  // 060550F0 shlr2 r2
    c.r[2] >>= 2;  // 060550F2 shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 060550F4 shlr r2
    c.r[2] >>= 2;  // 060550F6 shlr2 r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]);  // 060550F8 mov.w @r9,r1
    c.r[0] = c.r[3];  // 060550FA mov r3,r0
    c.r[2] += c.r[1];  // 060550FC add r1,r2
    st16(c.r[0] + c.r[7], c.r[2]);  // 060550FE mov.w r2,@(r0,r7)
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[10]);  // 06055100 mov.b @r10,r4
    c.r[1] = ld32(0x060551E4u);  // 06055102 mov.l 0x060551E4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06055108u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06055108u) return; }  // 06055104 jsr @r1 ; extu.b r4,r4
    c.r[13] = ld32(0x060551E8u);  // 06055108 mov.l 0x060551E8,r13
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 0605510A mov.b @r10,r1
    c.r[0] = 0x1u;  // 0605510C mov #1,r0
    c.r[4] = c.r[1] & 0xFFu;  // 0605510E extu.b r1,r4
    c.r[11] = c.r[4];  // 06055110 mov r4,r11
    c.r[1] = ld32(c.r[13]);  // 06055112 mov.l @r13,r1
    c.r[11] <<= 2;  // 06055114 shll2 r11
    c.r[11] <<= 2;  // 06055116 shll2 r11
    c.r[1] += c.r[11];  // 06055118 add r11,r1
    c.r[1] += 3;  // 0605511A add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605511C mov.b @r1,r1
    c.r[13] = ld32(0x060551E0u);  // 0605511E mov.l 0x060551E0,r13
    c.r[2] = ld32(c.r[13] + 8);  // 06055120 mov.l @(8,r13),r2
    c.r[3] = c.r[1];  // 06055122 mov r1,r3
    c.r[3] >>= 2;  // 06055124 shlr2 r3
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 06055126 shlr r3
    c.r[3] >>= 2;  // 06055128 shlr2 r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]); c.r[9] += 2;  // 0605512A mov.w @r9+,r1
    c.r[3] &= c.r[0];  // 0605512C and r0,r3
    c.r[1] += c.r[4];  // 0605512E add r4,r1
    c.r[1] += 1;  // 06055130 add #1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06055132 extu.w r1,r1
    c.r[10] = c.r[1];  // 06055134 mov r1,r10
    c.r[10] <<= 2;  // 06055136 shll2 r10
    c.r[10] += c.r[1];  // 06055138 add r1,r10
    c.r[10] += c.r[10];  // 0605513A add r10,r10
    c.r[10] += c.r[2];  // 0605513C add r2,r10
    c.r[10] += 4;  // 0605513E add #4,r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06055140 mov.b @r9,r1
    c.t = (c.r[3] & c.r[3]) == 0;  // 06055142 tst r3,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[10]);  // 06055144 mov.w @r10,r2
    c.r[8] = c.r[1] & 0xFFu;  // 06055146 extu.b r1,r8
    c.r[1] = (uint32_t)(int16_t)ld16(0x060551D4u);  // 06055148 mov.w 0x060551D4,r1
    c.r[9] = c.r[1];  // 0605514A mov r1,r9
    { const bool k = c.t; c.r[9] &= c.r[2]; if (k) { goto L_06055170; } }  // 0605514C bt/s 0x06055170 ; and r2,r9
    c.r[0] = ld32(0x060551ECu);  // 06055150 mov.l 0x060551EC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06055156u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06055156u) return; }  // 06055152 jsr @r0 ; nop
    c.r[1] = c.r[0] & 0xFFFFu;  // 06055156 extu.w r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06055158 tst r1,r1
    { const bool k = c.t; c.r[13] = 0x3u; if (k) { goto L_06055170; } }  // 0605515A bt/s 0x06055170 ; mov #3,r13
    c.r[0] = ld32(0x060551E8u);  // 0605515E mov.l 0x060551E8,r0
    c.r[1] = ld32(c.r[0]);  // 06055160 mov.l @r0,r1
    c.r[11] += c.r[1];  // 06055162 add r1,r11
    c.r[11] += 3;  // 06055164 add #3,r11
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[11]);  // 06055166 mov.b @r11,r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06055168 shlr r1
    c.r[1] &= c.r[13];  // 0605516A and r13,r1
    c.r[8] += c.r[1]; goto L_06055172;  // 0605516C bra 0x06055172 ; add r1,r8
L_06055170:
    c.r[8] += 3;  // 06055170 add #3,r8
L_06055172:
    c.r[8] <<= 2;  // 06055172 shll2 r8
    c.r[8] <<= 2;  // 06055174 shll2 r8
    c.r[1] = c.r[9];  // 06055176 mov r9,r1
    c.r[1] |= c.r[8];  // 06055178 or r8,r1
    st16(c.r[10], c.r[1]);  // 0605517A mov.w r1,@r10
    c.r[4] = ld32(0x060551F0u);  // 0605517C mov.l 0x060551F0,r4
    c.r[5] = ld32(0x060551F4u);  // 0605517E mov.l 0x060551F4,r5
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[4]);  // 06055180 mov.b @r4,r7
    c.r[1] = ld32(0x060551E8u);  // 06055182 mov.l 0x060551E8,r1
    c.r[6] = ld32(c.r[1]);  // 06055184 mov.l @r1,r6
    c.r[7] = c.r[7] & 0xFFu;  // 06055186 extu.b r7,r7
    c.r[3] = c.r[7];  // 06055188 mov r7,r3
    c.r[3] <<= 2;  // 0605518A shll2 r3
    c.r[3] <<= 2;  // 0605518C shll2 r3
    c.r[1] = c.r[3];  // 0605518E mov r3,r1
    c.r[1] += c.r[6];  // 06055190 add r6,r1
    c.r[1] += 1;  // 06055192 add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06055194 mov.b @r1,r2
    c.r[0] = c.r[3];  // 06055196 mov r3,r0
    c.r[2] = c.r[2] & 0xFFu;  // 06055198 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 0605519A mov.b @(r0,r6),r1
    c.r[2] <<= 2;  // 0605519C shll2 r2
    c.r[2] <<= 2;  // 0605519E shll2 r2
    c.r[2] <<= 2;  // 060551A0 shll2 r2
    c.r[3] = ld32(c.r[5]);  // 060551A2 mov.l @r5,r3
    c.r[1] = c.r[1] & 0xFFu;  // 060551A4 extu.b r1,r1
    c.r[2] += c.r[3];  // 060551A6 add r3,r2
    c.r[0] = c.r[2];  // 060551A8 mov r2,r0
    st8(c.r[0] + c.r[1], c.r[7]);  // 060551AA mov.b r7,@(r0,r1)
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[4]);  // 060551AC mov.b @r4,r4
    c.r[1] = ld32(0x060551F8u);  // 060551AE mov.l 0x060551F8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060551B4u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060551B4u) return; }  // 060551B0 jsr @r1 ; extu.b r4,r4
    c.r[13] = (uint32_t)(int16_t)ld16(0x060551D6u);  // 060551B4 mov.w 0x060551D6,r13
    c.r[13] += c.r[14];  // 060551B6 add r14,r13
    c.r[0] = ld32(c.r[13]);  // 060551B8 mov.l @r13,r0
    c.r[3] = (uint32_t)(int16_t)ld16(0x060551D8u);  // 060551BA mov.w 0x060551D8,r3
    c.r[14] += c.r[3];  // 060551BC add r3,r14
    c.r[15] = c.r[14];  // 060551BE mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060551C0 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060551C2 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060551C4 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060551C6 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060551C8 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060551CA mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060551CC mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060551CE rts ; mov.l @r15+,r8
}

void f_060551FC(SH2Context& c) {
    ran[1325] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060551FC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060551FE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06055200 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06055202 mov r15,r14
    c.r[8] = c.r[4] & 0xFFFFu;  // 06055204 extu.w r4,r8
    c.r[6] = 0x0u;  // 06055206 mov #0,r6
    c.r[1] = ld32(0x06055270u);  // 06055208 mov.l 0x06055270,r1
    c.r[4] = ld32(c.r[1]);  // 0605520A mov.l @r1,r4
    c.r[9] = (uint32_t)(int16_t)ld16(0x0605526Cu);  // 0605520C mov.w 0x0605526C,r9
    c.r[5] = 0x0u;  // 0605520E mov #0,r5
    c.r[7] = c.r[4];  // 06055210 mov r4,r7
L_06055212:
    c.r[0] = c.r[5];  // 06055212 mov r5,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[4]);  // 06055214 mov.b @(r0,r4),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06055216 extu.b r1,r1
    c.t = c.r[1] == c.r[9];  // 06055218 cmp/eq r9,r1
    { const bool k = c.t; c.r[1] = c.r[7]; if (k) { goto L_0605524A; } }  // 0605521A bt/s 0x0605524A ; mov r7,r1
    c.r[1] += 7;  // 0605521E add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06055220 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06055222 mov r1,r0
    c.r[0] >>= 2;  // 06055224 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06055226 shlr r0
    c.r[0] &= 0x1u;  // 06055228 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605522A tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[7]; if (k) { goto L_0605524A; } }  // 0605522C bf/s 0x0605524A ; mov r7,r1
    c.r[1] += 2;  // 06055230 add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06055232 mov.b @r1,r2
    c.r[1] = ld32(0x06055274u);  // 06055234 mov.l 0x06055274,r1
    c.r[3] = ld32(c.r[1]);  // 06055236 mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06055238 extu.b r2,r2
    c.r[1] = 0x1Eu;  // 0605523A mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 0605523C mul.l r1,r2
    c.r[0] = c.macl;  // 0605523E sts macl,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 06055240 mov.w @(r0,r3),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06055242 extu.w r1,r1
    c.t = c.r[1] == c.r[8];  // 06055244 cmp/eq r8,r1
    { const bool k = c.t; c.r[0] = c.r[6]; if (k) { goto L_06055258; } }  // 06055246 bt/s 0x06055258 ; mov r6,r0
L_0605524A:
    c.r[7] += 16;  // 0605524A add #16,r7
    c.r[6] += 1;  // 0605524C add #1,r6
    c.r[1] = 0x49u;  // 0605524E mov #73,r1
    c.t = (int32_t)c.r[6] > (int32_t)c.r[1];  // 06055250 cmp/gt r1,r6
    { const bool k = !c.t; c.r[5] += 16; if (k) { SH2_POLL(c); goto L_06055212; } }  // 06055252 bf/s 0x06055212 ; add #16,r5
    c.r[0] = c.r[6];  // 06055256 mov r6,r0
L_06055258:
    c.t = c.r[0] == 0x4Au;  // 06055258 cmp/eq #74,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605526Cu);  // 0605525A mov.w 0x0605526C,r1
    if (c.t) { goto L_06055260; }  // 0605525C bt 0x06055260
    c.r[1] = c.r[6] & 0xFFu;  // 0605525E extu.b r6,r1
L_06055260:
    c.r[15] = c.r[14];  // 06055260 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06055262 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06055264 mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06055266 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.r[0] = c.r[1]; c.pc = x; return; }  // 06055268 rts ; mov r1,r0
}

void f_06055278(SH2Context& c) {
    ran[1326] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06055278 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0605527A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0605527C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0605527E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06055280 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06055282 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06055284 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06055286 sts.l pr,@-r15
    c.r[15] -= 36;  // 06055288 add #-36,r15
    c.r[14] = c.r[15];  // 0605528A mov r15,r14
    c.r[9] = c.r[6];  // 0605528C mov r6,r9
    c.r[12] = c.r[5] & 0xFFu;  // 0605528E extu.b r5,r12
    c.r[9] = c.r[9] & 0xFFu;  // 06055290 extu.b r9,r9
    c.r[1] = ld32(0x060553C4u);  // 06055292 mov.l 0x060553C4,r1
    c.r[11] = c.r[12];  // 06055294 mov r12,r11
    c.r[11] <<= 2;  // 06055296 shll2 r11
    c.r[11] <<= 2;  // 06055298 shll2 r11
    c.r[2] = ld32(c.r[1]);  // 0605529A mov.l @r1,r2
    c.r[10] = ld32(0x060553C8u);  // 0605529C mov.l 0x060553C8,r10
    c.r[2] += c.r[11];  // 0605529E add r11,r2
    c.r[2] += 2;  // 060552A0 add #2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060552A2 mov.b @r2,r1
    c.r[5] = c.r[14];  // 060552A4 mov r14,r5
    c.r[1] = c.r[1] & 0xFFu;  // 060552A6 extu.b r1,r1
    st32(c.r[14] + 32, c.r[1]);  // 060552A8 mov.l r1,@(32,r14)
    st8(c.r[2], c.r[4]);  // 060552AA mov.b r4,@r2
    { const uint32_t x = c.r[10]; c.pr = 0x060552B0u; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060552B0u) return; }  // 060552AC jsr @r10 ; mov r12,r4
    c.r[8] = c.r[14];  // 060552B0 mov r14,r8
    c.r[8] += 16;  // 060552B2 add #16,r8
    c.r[5] = c.r[8];  // 060552B4 mov r8,r5
    { const uint32_t x = c.r[10]; c.pr = 0x060552BAu; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060552BAu) return; }  // 060552B6 jsr @r10 ; mov r9,r4
    c.r[5] = 0x0u;  // 060552BA mov #0,r5
    c.r[13] = (uint32_t)(int16_t)ld16(0x060553C0u);  // 060552BC mov.w 0x060553C0,r13
    c.r[9] <<= 2;  // 060552BE shll2 r9
    c.r[9] <<= 2;  // 060552C0 shll2 r9
    c.r[4] = c.r[14];  // 060552C2 mov r14,r4
L_060552C4:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]);  // 060552C4 mov.b @r4,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060552C6 extu.b r1,r1
    c.t = c.r[1] == c.r[13];  // 060552C8 cmp/eq r13,r1
    { const bool k = c.t; c.r[6] = 0x0u; if (k) { goto L_0605538C; } }  // 060552CA bt/s 0x0605538C ; mov #0,r6
    c.r[3] = 0xFu;  // 060552CE mov #15,r3
    c.r[0] = c.r[8];  // 060552D0 mov r8,r0
L_060552D2:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[6]);  // 060552D2 mov.b @(r0,r6),r1
    c.r[2] = c.r[1] & 0xFFu;  // 060552D4 extu.b r1,r2
    c.t = c.r[2] == c.r[13];  // 060552D6 cmp/eq r13,r2
    if (c.t) { goto L_060552E4; }  // 060552D8 bt 0x060552E4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]);  // 060552DA mov.b @r4,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060552DC extu.b r1,r1
    c.t = c.r[2] == c.r[1];  // 060552DE cmp/eq r1,r2
    { const bool k = c.t; c.r[0] = c.r[6]; if (k) { goto L_060552EE; } }  // 060552E0 bt/s 0x060552EE ; mov r6,r0
L_060552E4:
    c.r[6] += 1;  // 060552E4 add #1,r6
    c.t = (int32_t)c.r[6] > (int32_t)c.r[3];  // 060552E6 cmp/gt r3,r6
    { const bool k = !c.t; c.r[0] = c.r[8]; if (k) { SH2_POLL(c); goto L_060552D2; } }  // 060552E8 bf/s 0x060552D2 ; mov r8,r0
    c.r[0] = c.r[6];  // 060552EC mov r6,r0
L_060552EE:
    c.t = c.r[0] == 0x10u;  // 060552EE cmp/eq #16,r0
    { const bool k = c.t; c.r[7] = c.r[9]; if (k) { goto L_0605538C; } }  // 060552F0 bt/s 0x0605538C ; mov r9,r7
    c.r[1] = ld32(0x060553CCu);  // 060552F4 mov.l 0x060553CC,r1
    c.r[2] = ld32(c.r[1]);  // 060552F6 mov.l @r1,r2
    c.r[7] += c.r[2];  // 060552F8 add r2,r7
    c.r[2] += c.r[11];  // 060552FA add r11,r2
    c.r[2] += 40;  // 060552FC add #40,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]);  // 060552FE mov.b @r4,r1
    c.r[0] = c.r[2];  // 06055300 mov r2,r0
    c.r[3] = c.r[1] & 0xFFu;  // 06055302 extu.b r1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06055304 mov.b @(r0,r3),r1
    c.r[7] += 40;  // 06055306 add #40,r7
    c.r[0] = c.r[7];  // 06055308 mov r7,r0
    st8(c.r[0] + c.r[3], c.r[1]);  // 0605530A mov.b r1,@(r0,r3)
    c.r[1] = ld32(0x060553C4u);  // 0605530C mov.l 0x060553C4,r1
    c.r[7] = ld32(c.r[1]);  // 0605530E mov.l @r1,r7
    c.r[0] = 0x1Eu;  // 06055310 mov #30,r0
    c.r[1] = c.r[9];  // 06055312 mov r9,r1
    c.r[1] += c.r[7];  // 06055314 add r7,r1
    c.r[1] += 2;  // 06055316 add #2,r1
    c.r[7] += c.r[11];  // 06055318 add r11,r7
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605531A mov.b @r1,r2
    c.r[7] += 2;  // 0605531C add #2,r7
    c.r[2] = c.r[2] & 0xFFu;  // 0605531E extu.b r2,r2
    c.r[1] = ld32(0x060553D0u);  // 06055320 mov.l 0x060553D0,r1
    c.r[3] = ld32(c.r[1]);  // 06055322 mov.l @r1,r3
    c.macl = c.r[2] * c.r[0];  // 06055324 mul.l r0,r2
    c.r[1] = c.r[6];  // 06055326 mov r6,r1
    c.t = c.r[1] >> 31; c.r[1] = c.r[1] << 1 | c.t;  // 06055328 rotl r1
    c.r[1] = c.t;  // 0605532A movt r1
    c.r[1] += c.r[6];  // 0605532C add r6,r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 0605532E shar r1
    c.r[10] = c.macl;  // 06055330 sts macl,r10
    c.r[10] += c.r[3];  // 06055332 add r3,r10
    c.r[10] += c.r[1];  // 06055334 add r1,r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06055336 mov.b @r7,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06055338 extu.b r1,r1
    c.macl = c.r[1] * c.r[0];  // 0605533A mul.l r0,r1
    c.r[2] = c.macl;  // 0605533C sts macl,r2
    c.r[2] += c.r[3];  // 0605533E add r3,r2
    c.r[1] = c.r[5];  // 06055340 mov r5,r1
    c.t = c.r[1] >> 31; c.r[1] = c.r[1] << 1 | c.t;  // 06055342 rotl r1
    c.r[1] = c.t;  // 06055344 movt r1
    c.r[1] += c.r[5];  // 06055346 add r5,r1
    c.t = c.r[1] & 1; c.r[1] = (uint32_t)((int32_t)c.r[1] >> 1);  // 06055348 shar r1
    c.r[2] += c.r[1];  // 0605534A add r1,r2
    c.r[2] += 7;  // 0605534C add #7,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605534E mov.b @r2,r1
    c.r[3] = c.r[1] & 0xFFu;  // 06055350 extu.b r1,r3
    c.r[1] = 0x1u;  // 06055352 mov #1,r1
    c.r[1] &= c.r[5];  // 06055354 and r5,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06055356 tst r1,r1
    { const bool k = !c.t; c.r[10] += 7; if (k) { goto L_06055364; } }  // 06055358 bf/s 0x06055364 ; add #7,r10
    c.r[1] = c.r[3];  // 0605535C mov r3,r1
    c.r[1] >>= 2;  // 0605535E shlr2 r1
    c.r[1] >>= 2; goto L_06055368;  // 06055360 bra 0x06055368 ; shlr2 r1
L_06055364:
    c.r[1] = 0xFu;  // 06055364 mov #15,r1
    c.r[1] &= c.r[3];  // 06055366 and r3,r1
L_06055368:
    c.r[0] = 0x1u;  // 06055368 mov #1,r0
    c.r[6] &= c.r[0];  // 0605536A and r0,r6
    c.t = (c.r[6] & c.r[6]) == 0;  // 0605536C tst r6,r6
    { const bool k = !c.t; c.r[2] = c.r[1]; if (k) { goto L_06055376; } }  // 0605536E bf/s 0x06055376 ; mov r1,r2
    c.r[2] <<= 2;  // 06055372 shll2 r2
    c.r[2] <<= 2;  // 06055374 shll2 r2
L_06055376:
    c.r[1] = 0x1u;  // 06055376 mov #1,r1
    c.r[1] &= c.r[5];  // 06055378 and r5,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605537A tst r1,r1
    { const bool k = c.t; c.r[0] = 0xFu; if (k) { goto L_06055386; } }  // 0605537C bt/s 0x06055386 ; mov #15,r0
    c.r[0] = (uint32_t)(int16_t)ld16(0x060553C2u);  // 06055380 mov.w 0x060553C2,r0
    c.r[3] &= c.r[0]; goto L_06055388;  // 06055382 bra 0x06055388 ; and r0,r3
L_06055386:
    c.r[3] &= c.r[0];  // 06055386 and r0,r3
L_06055388:
    c.r[2] |= c.r[3];  // 06055388 or r3,r2
    st8(c.r[10], c.r[2]);  // 0605538A mov.b r2,@r10
L_0605538C:
    c.r[5] += 1;  // 0605538C add #1,r5
    c.r[0] = 0xFu;  // 0605538E mov #15,r0
    c.t = (int32_t)c.r[5] > (int32_t)c.r[0];  // 06055390 cmp/gt r0,r5
    { const bool k = !c.t; c.r[4] += 1; if (k) { SH2_POLL(c); goto L_060552C4; } }  // 06055392 bf/s 0x060552C4 ; add #1,r4
    c.r[1] = ld32(0x060553C4u);  // 06055396 mov.l 0x060553C4,r1
    c.r[12] <<= 2;  // 06055398 shll2 r12
    c.r[12] <<= 2;  // 0605539A shll2 r12
    c.r[0] = 0x23u;  // 0605539C mov #35,r0
    c.r[1] = ld32(c.r[1]);  // 0605539E mov.l @r1,r1
    c.r[0] += c.r[14];  // 060553A0 add r14,r0
    c.r[12] += c.r[1];  // 060553A2 add r1,r12
    c.r[12] += 2;  // 060553A4 add #2,r12
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0]);  // 060553A6 mov.b @r0,r0
    st8(c.r[12], c.r[0]);  // 060553A8 mov.b r0,@r12
    c.r[14] += 36;  // 060553AA add #36,r14
    c.r[15] = c.r[14];  // 060553AC mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060553AE lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060553B0 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060553B2 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060553B4 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060553B6 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060553B8 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060553BA mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060553BC rts ; mov.l @r15+,r8
}

void f_060553D4(SH2Context& c) {
    ran[1327] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060553D4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060553D6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060553D8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060553DA mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060553DC mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060553DE mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060553E0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060553E2 sts.l pr,@-r15
    c.r[15] -= 36;  // 060553E4 add #-36,r15
    c.r[14] = c.r[15];  // 060553E6 mov r15,r14
    c.r[4] = c.r[4] & 0xFFu;  // 060553E8 extu.b r4,r4
    st32(c.r[14] + 12, c.r[4]);  // 060553EA mov.l r4,@(12,r14)
    c.r[0] = 0x0u;  // 060553EC mov #0,r0
    st32(c.r[14] + 16, c.r[0]);  // 060553EE mov.l r0,@(16,r14)
    c.r[9] = 0x0u;  // 060553F0 mov #0,r9
    c.r[10] = 0x4u;  // 060553F2 mov #4,r10
    c.r[7] = c.r[14];  // 060553F4 mov r14,r7
    c.r[7] += 1;  // 060553F6 add #1,r7
    c.r[8] = ld32(0x06055544u);  // 060553F8 mov.l 0x06055544,r8
    c.r[5] = ld32(0x06055548u);  // 060553FA mov.l 0x06055548,r5
    c.r[6] = ld32(0x0605554Cu);  // 060553FC mov.l 0x0605554C,r6
    c.r[4] = ld32(0x06055550u);  // 060553FE mov.l 0x06055550,r4
    c.r[3] = 0x0u;  // 06055400 mov #0,r3
L_06055402:
    c.r[0] = c.r[3];  // 06055402 mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 06055404 mov.b @(r0,r14),r1
    c.r[11] = (uint32_t)(int16_t)ld16(0x0605553Au);  // 06055406 mov.w 0x0605553A,r11
    c.r[1] &= c.r[11];  // 06055408 and r11,r1
    st8(c.r[0] + c.r[14], c.r[1]);  // 0605540A mov.b r1,@(r0,r14)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 0605540C mov.b @(r0,r7),r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605553Cu);  // 0605540E mov.w 0x0605553C,r0
    c.r[1] |= c.r[0];  // 06055410 or r0,r1
    c.r[0] = c.r[3];  // 06055412 mov r3,r0
    st8(c.r[0] + c.r[7], c.r[1]);  // 06055414 mov.b r1,@(r0,r7)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[5]);  // 06055416 mov.b @r5,r1
    c.r[2] = c.r[1] & 0xFFu;  // 06055418 extu.b r1,r2
    c.r[2] <<= 2;  // 0605541A shll2 r2
    c.r[2] <<= 2;  // 0605541C shll2 r2
    c.r[1] = ld32(c.r[6]);  // 0605541E mov.l @r6,r1
    c.r[0] = c.r[2];  // 06055420 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06055422 mov.b @(r0,r1),r1
    c.r[3] += 2;  // 06055424 add #2,r3
    c.r[0] = c.r[9];  // 06055426 mov r9,r0
    st8(c.r[0] + c.r[8], c.r[1]);  // 06055428 mov.b r1,@(r0,r8)
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[5]);  // 0605542A mov.b @r5,r1
    c.r[9] += 1;  // 0605542C add #1,r9
    c.r[2] = ld32(c.r[6]);  // 0605542E mov.l @r6,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06055430 extu.b r1,r1
    c.r[1] <<= 2;  // 06055432 shll2 r1
    c.r[1] <<= 2;  // 06055434 shll2 r1
    c.r[1] += c.r[2];  // 06055436 add r2,r1
    c.r[1] += 1;  // 06055438 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605543A mov.b @r1,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[10];  // 0605543C cmp/gt r10,r9
    { const bool k = !c.t; st8(c.r[0] + c.r[4], c.r[1]); if (k) { SH2_POLL(c); goto L_06055402; } }  // 0605543E bf/s 0x06055402 ; mov.b r1,@(r0,r4)
    c.r[1] = ld32(0x06055554u);  // 06055442 mov.l 0x06055554,r1
    c.r[1] = ld32(c.r[1]);  // 06055444 mov.l @r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0605553Eu);  // 06055446 mov.w 0x0605553E,r2
    c.r[0] = c.r[1];  // 06055448 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0605544A mov.b @(r0,r2),r1
    c.r[11] = 0xFu;  // 0605544C mov #15,r11
    c.r[2] = c.r[1];  // 0605544E mov r1,r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 06055450 shlr r2
    c.r[2] &= c.r[11];  // 06055452 and r11,r2
    c.r[1] = 0x7u;  // 06055454 mov #7,r1
    c.r[2] -= 2;  // 06055456 add #-2,r2
    c.t = c.r[2] > c.r[1];  // 06055458 cmp/hi r1,r2
    { const bool k = !c.t; c.r[1] = c.r[2]; if (k) { goto L_06055462; } }  // 0605545A bf/s 0x06055462 ; mov r2,r1
    goto L_06055850;  // 0605545E bra 0x06055850 ; nop
L_06055462:
    c.r[1] += c.r[1];  // 06055462 add r1,r1
    c.r[0] = 0x06055470u;  // 06055464 mova 0x06055470,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06055466 mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 06055468 add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x06055480u: goto L_06055480; case 0x06055850u: goto L_06055850; case 0x06055496u: goto L_06055496; case 0x060555FCu: goto L_060555FC; case 0x06055774u: goto L_06055774; default: sh2_call(c, x); return; } }  // 0605546A jmp @r0 ; nop
L_06055480:
    c.r[0] = ld32(0x06055558u);  // 06055480 mov.l 0x06055558,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06055486u; c.r[4] = ld32(c.r[14] + 12); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06055486u) return; }  // 06055482 jsr @r0 ; mov.l @(12,r14),r4
    c.r[1] = c.r[0];  // 06055486 mov r0,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06055488 extu.b r1,r1
    st32(c.r[14] + 16, c.r[1]);  // 0605548A mov.l r1,@(16,r14)
    c.r[11] = c.r[1];  // 0605548C mov r1,r11
    c.r[11] >>= 2;  // 0605548E shlr2 r11
    c.r[11] >>= 2;  // 06055490 shlr2 r11
    st32(c.r[14] + 16, c.r[11]); goto L_06055B00;  // 06055492 bra 0x06055B00 ; mov.l r11,@(16,r14)
L_06055496:
    c.r[1] = ld32(0x0605555Cu);  // 06055496 mov.l 0x0605555C,r1
    c.r[2] = ld32(c.r[1]);  // 06055498 mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06055540u);  // 0605549A mov.w 0x06055540,r1
    c.r[0] = c.r[2];  // 0605549C mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0605549E mov.b @(r0,r1),r1
    c.r[11] = 0x40u;  // 060554A0 mov #64,r11
    c.r[1] &= c.r[11];  // 060554A2 and r11,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060554A4 tst r1,r1
    { const bool k = c.t; c.r[11] = 0xFu; if (k) { goto L_060554AE; } }  // 060554A6 bt/s 0x060554AE ; mov #15,r11
    goto L_060555F8;  // 060554AA bra 0x060555F8 ; nop
L_060554AE:
    c.r[1] = ld32(0x06055554u);  // 060554AE mov.l 0x06055554,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0605553Eu);  // 060554B0 mov.w 0x0605553E,r2
    c.r[9] = 0x1u;  // 060554B2 mov #1,r9
    c.r[1] = ld32(c.r[1]);  // 060554B4 mov.l @r1,r1
    c.r[12] = c.r[9];  // 060554B6 mov r9,r12
    c.r[0] = c.r[1];  // 060554B8 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 060554BA mov.b @(r0,r2),r1
    c.r[13] = ld32(0x06055560u);  // 060554BC mov.l 0x06055560,r13
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060554BE shlr r1
    c.r[1] &= c.r[11];  // 060554C0 and r11,r1
    c.r[1] -= 1;  // 060554C2 add #-1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060554C4 extu.b r1,r1
    st32(c.r[14] + 32, c.r[1]);  // 060554C6 mov.l r1,@(32,r14)
    c.r[10] = c.r[9] & 0xFFFFu;  // 060554C8 extu.w r9,r10
L_060554CA:
    c.r[8] = ld32(0x06055564u);  // 060554CA mov.l 0x06055564,r8
    c.r[4] = ld32(0x06055568u);  // 060554CC mov.l 0x06055568,r4
    { const uint32_t x = c.r[8]; c.pr = 0x060554D2u; c.r[5] = 0x1Bu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060554D2u) return; }  // 060554CE jsr @r8 ; mov #27,r5
    c.r[1] = c.r[0];  // 060554D2 mov r0,r1
    c.r[5] = c.r[10];  // 060554D4 mov r10,r5
    { const uint32_t x = c.r[8]; c.pr = 0x060554DAu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060554DAu) return; }  // 060554D6 jsr @r8 ; mov r1,r4
    c.r[1] = c.r[0];  // 060554DA mov r0,r1
    c.r[1] += 7;  // 060554DC add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060554DE mov.b @r1,r1
    c.r[0] = 0x78u;  // 060554E0 mov #120,r0
    c.r[11] = ld32(c.r[14] + 32);  // 060554E2 mov.l @(32,r14),r11
    c.r[1] &= c.r[0];  // 060554E4 and r0,r1
    c.r[1] >>= 2;  // 060554E6 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060554E8 shlr r1
    c.t = c.r[1] == c.r[11];  // 060554EA cmp/eq r11,r1
    { const bool k = !c.t; c.r[2] = c.r[9]; if (k) { goto L_060555EA; } }  // 060554EC bf/s 0x060555EA ; mov r9,r2
    c.r[2] -= 53;  // 060554F0 add #-53,r2
    c.r[1] = 0x2u;  // 060554F2 mov #2,r1
    c.t = c.r[2] > c.r[1];  // 060554F4 cmp/hi r1,r2
    { const bool k = c.t; c.r[5] = c.r[10]; if (k) { goto L_0605556C; } }  // 060554F6 bt/s 0x0605556C ; mov r10,r5
    c.r[3] = 0x0u;  // 060554FA mov #0,r3
    c.r[2] = ld32(c.r[13]);  // 060554FC mov.l @r13,r2
    c.r[7] = 0x7Fu;  // 060554FE mov #127,r7
    c.r[6] = 0x0u;  // 06055500 mov #0,r6
L_06055502:
    c.r[0] = c.r[6];  // 06055502 mov r6,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 06055504 mov.w @(r0,r2),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06055506 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06055508 tst r1,r1
    { const bool k = c.t; c.t = c.r[1] == c.r[9]; if (k) { goto L_06055510; } }  // 0605550A bt/s 0x06055510 ; cmp/eq r9,r1
    if (c.t) { goto L_06055518; }  // 0605550E bt 0x06055518
L_06055510:
    c.r[3] += 1;  // 06055510 add #1,r3
    c.t = (int32_t)c.r[3] > (int32_t)c.r[7];  // 06055512 cmp/gt r7,r3
    { const bool k = !c.t; c.r[6] += 30; if (k) { SH2_POLL(c); goto L_06055502; } }  // 06055514 bf/s 0x06055502 ; add #30,r6
L_06055518:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605553Au);  // 06055518 mov.w 0x0605553A,r1
    c.t = c.r[3] == c.r[1];  // 0605551A cmp/eq r1,r3
    { const bool k = c.t; c.r[2] = c.r[3] & 0xFFFFu; if (k) { goto L_060555EA; } }  // 0605551C bt/s 0x060555EA ; extu.w r3,r2
    c.r[3] = c.r[2];  // 06055520 mov r2,r3
    c.r[3] >>= 8;  // 06055522 shlr8 r3
    c.r[11] = 0x7Fu;  // 06055524 mov #127,r11
    c.r[3] &= c.r[11];  // 06055526 and r11,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[14]);  // 06055528 mov.b @r14,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605553Au);  // 0605552A mov.w 0x0605553A,r0
    c.r[1] &= c.r[0];  // 0605552C and r0,r1
    c.r[1] |= c.r[3];  // 0605552E or r3,r1
    st8(c.r[14], c.r[1]);  // 06055530 mov.b r1,@r14
    c.r[1] = c.r[14];  // 06055532 mov r14,r1
    c.r[1] += 1;  // 06055534 add #1,r1
    st8(c.r[1], c.r[2]); goto L_060555EA;  // 06055536 bra 0x060555EA ; mov.b r2,@r1
L_0605556C:
    c.r[7] = 0x0u;  // 0605556C mov #0,r7
    c.r[1] = ld32(0x060556ACu);  // 0605556E mov.l 0x060556AC,r1
    c.r[3] = ld32(c.r[1]);  // 06055570 mov.l @r1,r3
    c.r[6] = 0x0u;  // 06055572 mov #0,r6
    c.r[4] = c.r[3];  // 06055574 mov r3,r4
L_06055576:
    c.r[0] = c.r[6];  // 06055576 mov r6,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[4]);  // 06055578 mov.b @(r0,r4),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x060556A2u);  // 0605557A mov.w 0x060556A2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0605557C extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 0605557E cmp/eq r2,r1
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_060555B0; } }  // 06055580 bt/s 0x060555B0 ; mov r3,r1
    c.r[1] += 7;  // 06055584 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06055586 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06055588 mov r1,r0
    c.r[0] >>= 2;  // 0605558A shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0605558C shlr r0
    c.r[0] &= 0x1u;  // 0605558E and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06055590 tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[3]; if (k) { goto L_060555B0; } }  // 06055592 bf/s 0x060555B0 ; mov r3,r1
    c.r[1] += 2;  // 06055596 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06055598 mov.b @r1,r1
    c.r[11] = 0x1Eu;  // 0605559A mov #30,r11
    c.r[1] = c.r[1] & 0xFFu;  // 0605559C extu.b r1,r1
    c.macl = c.r[1] * c.r[11];  // 0605559E mul.l r11,r1
    c.r[2] = ld32(c.r[13]);  // 060555A0 mov.l @r13,r2
    c.r[1] = c.macl;  // 060555A2 sts macl,r1
    c.r[0] = c.r[1];  // 060555A4 mov r1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 060555A6 mov.w @(r0,r2),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 060555A8 extu.w r1,r1
    c.t = c.r[1] == c.r[5];  // 060555AA cmp/eq r5,r1
    { const bool k = c.t; c.r[0] = c.r[7]; if (k) { goto L_060555BE; } }  // 060555AC bt/s 0x060555BE ; mov r7,r0
L_060555B0:
    c.r[3] += 16;  // 060555B0 add #16,r3
    c.r[7] += 1;  // 060555B2 add #1,r7
    c.r[1] = 0x49u;  // 060555B4 mov #73,r1
    c.t = (int32_t)c.r[7] > (int32_t)c.r[1];  // 060555B6 cmp/gt r1,r7
    { const bool k = !c.t; c.r[6] += 16; if (k) { SH2_POLL(c); goto L_06055576; } }  // 060555B8 bf/s 0x06055576 ; add #16,r6
    c.r[0] = c.r[7];  // 060555BC mov r7,r0
L_060555BE:
    c.t = c.r[0] == 0x4Au;  // 060555BE cmp/eq #74,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x060556A2u);  // 060555C0 mov.w 0x060556A2,r1
    if (c.t) { goto L_060555C6; }  // 060555C2 bt 0x060555C6
    c.r[1] = c.r[7] & 0xFFu;  // 060555C4 extu.b r7,r1
L_060555C6:
    c.r[10] = c.r[1];  // 060555C6 mov r1,r10
    c.r[1] = (uint32_t)(int16_t)ld16(0x060556A2u);  // 060555C8 mov.w 0x060556A2,r1
    c.t = c.r[10] == c.r[1];  // 060555CA cmp/eq r1,r10
    { const bool k = c.t; c.r[2] = c.r[12]; if (k) { goto L_060555EA; } }  // 060555CC bt/s 0x060555EA ; mov r12,r2
    c.r[1] = c.r[12];  // 060555D0 mov r12,r1
    c.r[1] += 1;  // 060555D2 add #1,r1
    c.r[12] = c.r[1] & 0xFFu;  // 060555D4 extu.b r1,r12
    c.r[2] += c.r[2];  // 060555D6 add r2,r2
    c.r[0] = c.r[14];  // 060555D8 mov r14,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 060555DA mov.b @(r0,r2),r1
    c.r[11] = (uint32_t)(int16_t)ld16(0x060556A4u);  // 060555DC mov.w 0x060556A4,r11
    c.r[1] &= c.r[11];  // 060555DE and r11,r1
    st8(c.r[0] + c.r[2], c.r[1]);  // 060555E0 mov.b r1,@(r0,r2)
    c.r[1] = c.r[14];  // 060555E2 mov r14,r1
    c.r[1] += 1;  // 060555E4 add #1,r1
    c.r[0] = c.r[1];  // 060555E6 mov r1,r0
    st8(c.r[0] + c.r[2], c.r[10]);  // 060555E8 mov.b r10,@(r0,r2)
L_060555EA:
    c.r[9] += 1;  // 060555EA add #1,r9
    c.r[1] = (uint32_t)(int16_t)ld16(0x060556A6u);  // 060555EC mov.w 0x060556A6,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 060555EE cmp/gt r1,r9
    { const bool k = c.t; c.r[10] = c.r[9] & 0xFFFFu; if (k) { goto L_060555F8; } }  // 060555F0 bt/s 0x060555F8 ; extu.w r9,r10
    SH2_POLL(c); goto L_060554CA;  // 060555F4 bra 0x060554CA ; nop
L_060555F8:
    c.r[10] = 0x3u; goto L_06055852;  // 060555F8 bra 0x06055852 ; mov #3,r10
L_060555FC:
    c.r[1] = ld32(0x060556B0u);  // 060555FC mov.l 0x060556B0,r1
    c.r[2] = ld32(c.r[1]);  // 060555FE mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x060556A8u);  // 06055600 mov.w 0x060556A8,r1
    c.r[0] = c.r[2];  // 06055602 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06055604 mov.b @(r0,r1),r1
    c.r[11] = 0x10u;  // 06055606 mov #16,r11
    c.r[1] &= c.r[11];  // 06055608 and r11,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605560A tst r1,r1
    { const bool k = c.t; c.r[11] = 0xFu; if (k) { goto L_06055614; } }  // 0605560C bt/s 0x06055614 ; mov #15,r11
    goto L_06055764;  // 06055610 bra 0x06055764 ; nop
L_06055614:
    c.r[1] = ld32(0x060556B4u);  // 06055614 mov.l 0x060556B4,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x060556AAu);  // 06055616 mov.w 0x060556AA,r2
    c.r[9] = 0x1u;  // 06055618 mov #1,r9
    c.r[1] = ld32(c.r[1]);  // 0605561A mov.l @r1,r1
    c.r[12] = c.r[9];  // 0605561C mov r9,r12
    c.r[0] = c.r[1];  // 0605561E mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06055620 mov.b @(r0,r2),r1
    c.r[13] = ld32(0x060556B8u);  // 06055622 mov.l 0x060556B8,r13
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06055624 shlr r1
    c.r[1] &= c.r[11];  // 06055626 and r11,r1
    c.r[1] -= 1;  // 06055628 add #-1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605562A extu.b r1,r1
    st32(c.r[14] + 32, c.r[1]);  // 0605562C mov.l r1,@(32,r14)
    c.r[10] = c.r[9] & 0xFFFFu;  // 0605562E extu.w r9,r10
L_06055630:
    c.r[8] = ld32(0x060556BCu);  // 06055630 mov.l 0x060556BC,r8
    c.r[4] = ld32(0x060556C0u);  // 06055632 mov.l 0x060556C0,r4
    { const uint32_t x = c.r[8]; c.pr = 0x06055638u; c.r[5] = 0x1Bu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06055638u) return; }  // 06055634 jsr @r8 ; mov #27,r5
    c.r[1] = c.r[0];  // 06055638 mov r0,r1
    c.r[5] = c.r[10];  // 0605563A mov r10,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06055640u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06055640u) return; }  // 0605563C jsr @r8 ; mov r1,r4
    c.r[1] = c.r[0];  // 06055640 mov r0,r1
    c.r[1] += 7;  // 06055642 add #7,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06055644 mov.b @r1,r2
    c.r[0] = ld32(c.r[14] + 32);  // 06055646 mov.l @(32,r14),r0
    c.r[1] = 0x78u;  // 06055648 mov #120,r1
    c.r[1] &= c.r[2];  // 0605564A and r2,r1
    c.r[1] >>= 2;  // 0605564C shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0605564E shlr r1
    c.t = c.r[1] == c.r[0];  // 06055650 cmp/eq r0,r1
    { const bool k = c.t; c.r[0] = c.r[2]; if (k) { goto L_0605565A; } }  // 06055652 bt/s 0x0605565A ; mov r2,r0
    goto L_06055756;  // 06055656 bra 0x06055756 ; nop
L_0605565A:
    c.r[0] &= 0x7u;  // 0605565A and #7,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605565C tst r0,r0
    { const bool k = !c.t; c.r[3] = 0x0u; if (k) { goto L_060556D6; } }  // 0605565E bf/s 0x060556D6 ; mov #0,r3
    c.r[2] = ld32(c.r[13]);  // 06055662 mov.l @r13,r2
    c.r[7] = 0x7Fu;  // 06055664 mov #127,r7
    c.r[6] = 0x0u;  // 06055666 mov #0,r6
L_06055668:
    c.r[0] = c.r[6];  // 06055668 mov r6,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 0605566A mov.w @(r0,r2),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0605566C extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605566E tst r1,r1
    { const bool k = c.t; c.t = c.r[1] == c.r[9]; if (k) { goto L_06055676; } }  // 06055670 bt/s 0x06055676 ; cmp/eq r9,r1
    if (c.t) { goto L_0605567E; }  // 06055674 bt 0x0605567E
L_06055676:
    c.r[3] += 1;  // 06055676 add #1,r3
    c.t = (int32_t)c.r[3] > (int32_t)c.r[7];  // 06055678 cmp/gt r7,r3
    { const bool k = !c.t; c.r[6] += 30; if (k) { SH2_POLL(c); goto L_06055668; } }  // 0605567A bf/s 0x06055668 ; add #30,r6
L_0605567E:
    c.r[1] = (uint32_t)(int16_t)ld16(0x060556A4u);  // 0605567E mov.w 0x060556A4,r1
    c.t = c.r[3] == c.r[1];  // 06055680 cmp/eq r1,r3
    { const bool k = c.t; c.r[1] = c.r[14]; if (k) { goto L_060556C4; } }  // 06055682 bt/s 0x060556C4 ; mov r14,r1
    c.r[2] = c.r[3] & 0xFFFFu;  // 06055686 extu.w r3,r2
    c.r[3] = c.r[2];  // 06055688 mov r2,r3
    c.r[3] >>= 8;  // 0605568A shlr8 r3
    c.r[11] = 0x7Fu;  // 0605568C mov #127,r11
    c.r[3] &= c.r[11];  // 0605568E and r11,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[14]);  // 06055690 mov.b @r14,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060556A4u);  // 06055692 mov.w 0x060556A4,r0
    c.r[1] &= c.r[0];  // 06055694 and r0,r1
    c.r[1] |= c.r[3];  // 06055696 or r3,r1
    st8(c.r[14], c.r[1]);  // 06055698 mov.b r1,@r14
    c.r[1] = c.r[14];  // 0605569A mov r14,r1
    c.r[1] += 1;  // 0605569C add #1,r1
    st8(c.r[1], c.r[2]); goto L_06055756;  // 0605569E bra 0x06055756 ; mov.b r2,@r1
L_060556C4:
    c.r[1] += 8;  // 060556C4 add #8,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060556C6 mov.b @r1,r0
    c.r[2] = c.r[14];  // 060556C8 mov r14,r2
    c.r[2] += 9;  // 060556CA add #9,r2
    c.r[0] &= 0x80u;  // 060556CC and #128,r0
    st8(c.r[1], c.r[0]);  // 060556CE mov.b r0,@r1
    c.r[1] = 0x0u;  // 060556D0 mov #0,r1
    st8(c.r[2], c.r[1]); goto L_06055764;  // 060556D2 bra 0x06055764 ; mov.b r1,@r2
L_060556D6:
    c.r[5] = c.r[10];  // 060556D6 mov r10,r5
    c.r[7] = 0x0u;  // 060556D8 mov #0,r7
    c.r[1] = ld32(0x06055770u);  // 060556DA mov.l 0x06055770,r1
    c.r[3] = ld32(c.r[1]);  // 060556DC mov.l @r1,r3
    c.r[6] = 0x0u;  // 060556DE mov #0,r6
    c.r[4] = c.r[3];  // 060556E0 mov r3,r4
L_060556E2:
    c.r[0] = c.r[6];  // 060556E2 mov r6,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[4]);  // 060556E4 mov.b @(r0,r4),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06055768u);  // 060556E6 mov.w 0x06055768,r2
    c.r[1] = c.r[1] & 0xFFu;  // 060556E8 extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 060556EA cmp/eq r2,r1
    { const bool k = c.t; c.r[1] = c.r[3]; if (k) { goto L_0605571C; } }  // 060556EC bt/s 0x0605571C ; mov r3,r1
    c.r[1] += 7;  // 060556F0 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060556F2 mov.b @r1,r1
    c.r[0] = c.r[1];  // 060556F4 mov r1,r0
    c.r[0] >>= 2;  // 060556F6 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060556F8 shlr r0
    c.r[0] &= 0x1u;  // 060556FA and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060556FC tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[3]; if (k) { goto L_0605571C; } }  // 060556FE bf/s 0x0605571C ; mov r3,r1
    c.r[1] += 2;  // 06055702 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06055704 mov.b @r1,r1
    c.r[11] = 0x1Eu;  // 06055706 mov #30,r11
    c.r[1] = c.r[1] & 0xFFu;  // 06055708 extu.b r1,r1
    c.macl = c.r[1] * c.r[11];  // 0605570A mul.l r11,r1
    c.r[2] = ld32(c.r[13]);  // 0605570C mov.l @r13,r2
    c.r[1] = c.macl;  // 0605570E sts macl,r1
    c.r[0] = c.r[1];  // 06055710 mov r1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 06055712 mov.w @(r0,r2),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06055714 extu.w r1,r1
    c.t = c.r[1] == c.r[5];  // 06055716 cmp/eq r5,r1
    { const bool k = c.t; c.r[0] = c.r[7]; if (k) { goto L_0605572A; } }  // 06055718 bt/s 0x0605572A ; mov r7,r0
L_0605571C:
    c.r[3] += 16;  // 0605571C add #16,r3
    c.r[7] += 1;  // 0605571E add #1,r7
    c.r[1] = 0x49u;  // 06055720 mov #73,r1
    c.t = (int32_t)c.r[7] > (int32_t)c.r[1];  // 06055722 cmp/gt r1,r7
    { const bool k = !c.t; c.r[6] += 16; if (k) { SH2_POLL(c); goto L_060556E2; } }  // 06055724 bf/s 0x060556E2 ; add #16,r6
    c.r[0] = c.r[7];  // 06055728 mov r7,r0
L_0605572A:
    c.t = c.r[0] == 0x4Au;  // 0605572A cmp/eq #74,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06055768u);  // 0605572C mov.w 0x06055768,r1
    if (c.t) { goto L_06055732; }  // 0605572E bt 0x06055732
    c.r[1] = c.r[7] & 0xFFu;  // 06055730 extu.b r7,r1
L_06055732:
    c.r[10] = c.r[1];  // 06055732 mov r1,r10
    c.r[1] = (uint32_t)(int16_t)ld16(0x06055768u);  // 06055734 mov.w 0x06055768,r1
    c.t = c.r[10] == c.r[1];  // 06055736 cmp/eq r1,r10
    { const bool k = c.t; c.r[2] = c.r[12]; if (k) { goto L_06055756; } }  // 06055738 bt/s 0x06055756 ; mov r12,r2
    c.r[1] = c.r[12];  // 0605573C mov r12,r1
    c.r[1] += 1;  // 0605573E add #1,r1
    c.r[12] = c.r[1] & 0xFFu;  // 06055740 extu.b r1,r12
    c.r[2] += c.r[2];  // 06055742 add r2,r2
    c.r[0] = c.r[14];  // 06055744 mov r14,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06055746 mov.b @(r0,r2),r1
    c.r[11] = (uint32_t)(int16_t)ld16(0x0605576Au);  // 06055748 mov.w 0x0605576A,r11
    c.r[1] &= c.r[11];  // 0605574A and r11,r1
    st8(c.r[0] + c.r[2], c.r[1]);  // 0605574C mov.b r1,@(r0,r2)
    c.r[1] = c.r[14];  // 0605574E mov r14,r1
    c.r[1] += 1;  // 06055750 add #1,r1
    c.r[0] = c.r[1];  // 06055752 mov r1,r0
    st8(c.r[0] + c.r[2], c.r[10]);  // 06055754 mov.b r10,@(r0,r2)
L_06055756:
    c.r[9] += 1;  // 06055756 add #1,r9
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605576Cu);  // 06055758 mov.w 0x0605576C,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 0605575A cmp/gt r1,r9
    { const bool k = c.t; c.r[10] = c.r[9] & 0xFFFFu; if (k) { goto L_06055764; } }  // 0605575C bt/s 0x06055764 ; extu.w r9,r10
    SH2_POLL(c); goto L_06055630;  // 06055760 bra 0x06055630 ; nop
L_06055764:
    c.r[10] = 0x4u; goto L_06055852;  // 06055764 bra 0x06055852 ; mov #4,r10
L_06055774:
    c.r[1] = ld32(0x060558C8u);  // 06055774 mov.l 0x060558C8,r1
    c.r[2] = ld32(c.r[1]);  // 06055776 mov.l @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x060558C2u);  // 06055778 mov.w 0x060558C2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0605577A mov.b @(r0,r2),r1
    c.r[0] = c.r[1] & 0xFFu;  // 0605577C extu.b r1,r0
    c.r[0] >>= 2;  // 0605577E shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06055780 shlr r0
    c.r[0] >>= 2;  // 06055782 shlr2 r0
    c.t = c.r[0] == 0x2u;  // 06055784 cmp/eq #2,r0
    { const bool k = !c.t; c.r[2] += 1; if (k) { goto L_06055850; } }  // 06055786 bf/s 0x06055850 ; add #1,r2
    c.r[3] = 0x0u;  // 0605578A mov #0,r3
    c.r[6] = 0x7Fu;  // 0605578C mov #127,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605578E mov.b @r2,r1
    c.r[5] = 0x0u;  // 06055790 mov #0,r5
    c.r[1] += 1;  // 06055792 add #1,r1
    c.r[10] = c.r[1] & 0xFFu;  // 06055794 extu.b r1,r10
    c.r[1] = ld32(0x060558CCu);  // 06055796 mov.l 0x060558CC,r1
    c.r[2] = c.r[10] & 0xFFFFu;  // 06055798 extu.w r10,r2
    c.r[7] = ld32(c.r[1]);  // 0605579A mov.l @r1,r7
L_0605579C:
    c.r[0] = c.r[5];  // 0605579C mov r5,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[7]);  // 0605579E mov.w @(r0,r7),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 060557A0 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060557A2 tst r1,r1
    { const bool k = c.t; c.t = c.r[1] == c.r[2]; if (k) { goto L_060557AA; } }  // 060557A4 bt/s 0x060557AA ; cmp/eq r2,r1
    if (c.t) { goto L_060557B2; }  // 060557A8 bt 0x060557B2
L_060557AA:
    c.r[3] += 1;  // 060557AA add #1,r3
    c.t = (int32_t)c.r[3] > (int32_t)c.r[6];  // 060557AC cmp/gt r6,r3
    { const bool k = !c.t; c.r[5] += 30; if (k) { SH2_POLL(c); goto L_0605579C; } }  // 060557AE bf/s 0x0605579C ; add #30,r5
L_060557B2:
    c.r[1] = (uint32_t)(int16_t)ld16(0x060558C4u);  // 060557B2 mov.w 0x060558C4,r1
    c.t = c.r[10] == c.r[1];  // 060557B4 cmp/eq r1,r10
    { const bool k = c.t; c.r[10] = 0x1u; if (k) { goto L_06055852; } }  // 060557B6 bt/s 0x06055852 ; mov #1,r10
    c.r[2] = c.r[3] & 0xFFFFu;  // 060557BA extu.w r3,r2
    c.r[3] = c.r[2];  // 060557BC mov r2,r3
    c.r[3] >>= 8;  // 060557BE shlr8 r3
    c.r[11] = 0x7Fu;  // 060557C0 mov #127,r11
    c.r[3] &= c.r[11];  // 060557C2 and r11,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[14]);  // 060557C4 mov.b @r14,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060558C4u);  // 060557C6 mov.w 0x060558C4,r0
    c.r[1] &= c.r[0];  // 060557C8 and r0,r1
    c.r[1] |= c.r[3];  // 060557CA or r3,r1
    st8(c.r[14], c.r[1]);  // 060557CC mov.b r1,@r14
    c.r[1] = c.r[14];  // 060557CE mov r14,r1
    c.r[1] += 1;  // 060557D0 add #1,r1
    st8(c.r[1], c.r[2]);  // 060557D2 mov.b r2,@r1
    c.r[1] = ld32(0x060558C8u);  // 060557D4 mov.l 0x060558C8,r1
    c.r[1] = ld32(c.r[1]);  // 060557D6 mov.l @r1,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060557D8 mov.w @r1,r1
    c.r[6] = 0x0u;  // 060557DA mov #0,r6
    c.r[1] += 2;  // 060557DC add #2,r1
    c.r[8] = c.r[1] & 0xFFFFu;  // 060557DE extu.w r1,r8
    c.r[1] = ld32(0x060558D0u);  // 060557E0 mov.l 0x060558D0,r1
    c.r[7] = ld32(c.r[1]);  // 060557E2 mov.l @r1,r7
    c.r[5] = 0x0u;  // 060557E4 mov #0,r5
    c.r[4] = c.r[7];  // 060557E6 mov r7,r4
L_060557E8:
    c.r[0] = c.r[5];  // 060557E8 mov r5,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[4]);  // 060557EA mov.b @(r0,r4),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x060558C6u);  // 060557EC mov.w 0x060558C6,r2
    c.r[1] = c.r[1] & 0xFFu;  // 060557EE extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 060557F0 cmp/eq r2,r1
    { const bool k = c.t; c.r[1] = c.r[7]; if (k) { goto L_06055822; } }  // 060557F2 bt/s 0x06055822 ; mov r7,r1
    c.r[1] += 7;  // 060557F6 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060557F8 mov.b @r1,r1
    c.r[0] = c.r[1];  // 060557FA mov r1,r0
    c.r[0] >>= 2;  // 060557FC shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060557FE shlr r0
    c.r[0] &= 0x1u;  // 06055800 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06055802 tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[7]; if (k) { goto L_06055822; } }  // 06055804 bf/s 0x06055822 ; mov r7,r1
    c.r[1] += 2;  // 06055808 add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605580A mov.b @r1,r2
    c.r[1] = ld32(0x060558CCu);  // 0605580C mov.l 0x060558CC,r1
    c.r[3] = ld32(c.r[1]);  // 0605580E mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06055810 extu.b r2,r2
    c.r[1] = 0x1Eu;  // 06055812 mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 06055814 mul.l r1,r2
    c.r[0] = c.macl;  // 06055816 sts macl,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 06055818 mov.w @(r0,r3),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0605581A extu.w r1,r1
    c.t = c.r[1] == c.r[8];  // 0605581C cmp/eq r8,r1
    { const bool k = c.t; c.r[0] = c.r[6]; if (k) { goto L_06055830; } }  // 0605581E bt/s 0x06055830 ; mov r6,r0
L_06055822:
    c.r[7] += 16;  // 06055822 add #16,r7
    c.r[6] += 1;  // 06055824 add #1,r6
    c.r[1] = 0x49u;  // 06055826 mov #73,r1
    c.t = (int32_t)c.r[6] > (int32_t)c.r[1];  // 06055828 cmp/gt r1,r6
    { const bool k = !c.t; c.r[5] += 16; if (k) { SH2_POLL(c); goto L_060557E8; } }  // 0605582A bf/s 0x060557E8 ; add #16,r5
    c.r[0] = c.r[6];  // 0605582E mov r6,r0
L_06055830:
    c.t = c.r[0] == 0x4Au;  // 06055830 cmp/eq #74,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x060558C6u);  // 06055832 mov.w 0x060558C6,r1
    if (c.t) { goto L_06055838; }  // 06055834 bt 0x06055838
    c.r[1] = c.r[6] & 0xFFu;  // 06055836 extu.b r6,r1
L_06055838:
    c.r[10] = c.r[1];  // 06055838 mov r1,r10
    c.r[1] = (uint32_t)(int16_t)ld16(0x060558C6u);  // 0605583A mov.w 0x060558C6,r1
    c.t = c.r[10] == c.r[1];  // 0605583C cmp/eq r1,r10
    { const bool k = c.t; c.r[1] = c.r[14]; if (k) { goto L_06055850; } }  // 0605583E bt/s 0x06055850 ; mov r14,r1
    c.r[1] += 2;  // 06055842 add #2,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06055844 mov.b @r1,r0
    c.r[0] &= 0x80u;  // 06055846 and #128,r0
    st8(c.r[1], c.r[0]);  // 06055848 mov.b r0,@r1
    c.r[1] = c.r[14];  // 0605584A mov r14,r1
    c.r[1] += 3;  // 0605584C add #3,r1
    st8(c.r[1], c.r[10]);  // 0605584E mov.b r10,@r1
L_06055850:
    c.r[10] = 0x1u;  // 06055850 mov #1,r10
L_06055852:
    c.r[1] = c.r[10];  // 06055852 mov r10,r1
    c.r[1] += 1;  // 06055854 add #1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06055856 extu.b r1,r1
    st32(c.r[14] + 20, c.r[1]);  // 06055858 mov.l r1,@(20,r14)
    c.r[2] = c.r[10];  // 0605585A mov r10,r2
    c.r[2] += c.r[2];  // 0605585C add r2,r2
    c.r[0] = c.r[14];  // 0605585E mov r14,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06055860 mov.b @(r0,r2),r1
    c.r[3] = 0x7Fu;  // 06055862 mov #127,r3
    c.r[3] &= c.r[1];  // 06055864 and r1,r3
    c.r[1] = c.r[14];  // 06055866 mov r14,r1
    c.r[1] += 1;  // 06055868 add #1,r1
    c.r[0] = c.r[1];  // 0605586A mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0605586C mov.b @(r0,r2),r1
    c.r[3] <<= 8;  // 0605586E shll8 r3
    c.r[1] = c.r[1] & 0xFFu;  // 06055870 extu.b r1,r1
    c.r[1] |= c.r[3];  // 06055872 or r3,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x060558C6u);  // 06055874 mov.w 0x060558C6,r2
    c.t = c.r[1] == c.r[2];  // 06055876 cmp/eq r2,r1
    { const bool k = !c.t; c.r[0] = ld32(c.r[14] + 12); if (k) { goto L_06055880; } }  // 06055878 bf/s 0x06055880 ; mov.l @(12,r14),r0
    goto L_06055AAA;  // 0605587C bra 0x06055AAA ; nop
L_06055880:
    c.r[11] = ld32(c.r[14] + 20);  // 06055880 mov.l @(20,r14),r11
    c.r[9] = 0x0u;  // 06055882 mov #0,r9
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[11];  // 06055884 cmp/ge r11,r9
    { const bool k = !c.t; c.r[10] = 0x0u; if (k) { goto L_0605588E; } }  // 06055886 bf/s 0x0605588E ; mov #0,r10
    goto L_06055A66;  // 0605588A bra 0x06055A66 ; nop
L_0605588E:
    c.r[0] = ld32(0x060558D4u);  // 0605588E mov.l 0x060558D4,r0
    st32(c.r[14] + 24, c.r[0]);  // 06055890 mov.l r0,@(24,r14)
    c.r[13] = 0x0u;  // 06055892 mov #0,r13
    c.r[11] = ld32(0x060558D8u);  // 06055894 mov.l 0x060558D8,r11
    st32(c.r[14] + 28, c.r[11]);  // 06055896 mov.l r11,@(28,r14)
L_06055898:
    c.t = (c.r[9] & c.r[9]) == 0;  // 06055898 tst r9,r9
    { const bool k = c.t; c.r[0] = c.r[13]; if (k) { goto L_060558E0; } }  // 0605589A bt/s 0x060558E0 ; mov r13,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 0605589E mov.b @(r0,r14),r1
    c.r[3] = 0x7Fu;  // 060558A0 mov #127,r3
    c.r[3] &= c.r[1];  // 060558A2 and r1,r3
    c.r[1] = c.r[14];  // 060558A4 mov r14,r1
    c.r[1] += 1;  // 060558A6 add #1,r1
    c.r[0] = c.r[1];  // 060558A8 mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[13]);  // 060558AA mov.b @(r0,r13),r2
    c.r[3] <<= 8;  // 060558AC shll8 r3
    c.r[2] = c.r[2] & 0xFFu;  // 060558AE extu.b r2,r2
    c.r[2] |= c.r[3];  // 060558B0 or r3,r2
    c.r[1] = ld32(0x060558D0u);  // 060558B2 mov.l 0x060558D0,r1
    c.r[1] = ld32(c.r[1]);  // 060558B4 mov.l @r1,r1
    c.r[2] <<= 2;  // 060558B6 shll2 r2
    c.r[2] <<= 2;  // 060558B8 shll2 r2
    c.r[2] += c.r[1];  // 060558BA add r1,r2
    c.r[2] += 2;  // 060558BC add #2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]); goto L_060558DC;  // 060558BE bra 0x060558DC ; mov.b @r2,r1
L_060558DC:
    c.r[1] = c.r[1] & 0xFFu; goto L_060558E8;  // 060558DC bra 0x060558E8 ; extu.b r1,r1
L_060558E0:
    c.r[1] = c.r[14];  // 060558E0 mov r14,r1
    c.r[1] += 1;  // 060558E2 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060558E4 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060558E6 extu.b r1,r1
L_060558E8:
    c.r[12] = c.r[1];  // 060558E8 mov r1,r12
    c.r[11] = ld32(0x06055B1Cu);  // 060558EA mov.l 0x06055B1C,r11
    c.r[1] = 0x1Eu;  // 060558EC mov #30,r1
    c.r[5] = 0x1Bu;  // 060558EE mov #27,r5
    c.macl = c.r[12] * c.r[1];  // 060558F0 mul.l r1,r12
    c.r[2] = ld32(c.r[11]);  // 060558F2 mov.l @r11,r2
    c.r[4] = ld32(0x06055B20u);  // 060558F4 mov.l 0x06055B20,r4
    c.r[11] = ld32(0x06055B24u);  // 060558F6 mov.l 0x06055B24,r11
    c.r[0] = c.macl;  // 060558F8 sts macl,r0
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 060558FA mov.w @(r0,r2),r8
    st32(c.r[14] + 32, c.r[0]);  // 060558FC mov.l r0,@(32,r14)
    { const uint32_t x = c.r[11]; c.pr = 0x06055902u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06055902u) return; }  // 060558FE jsr @r11 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 06055902 mov r0,r1
    c.r[5] = c.r[8];  // 06055904 mov r8,r5
    { const uint32_t x = c.r[11]; c.pr = 0x0605590Au; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605590Au) return; }  // 06055906 jsr @r11 ; mov r1,r4
    c.r[1] = c.r[0];  // 0605590A mov r0,r1
    c.r[1] += 25;  // 0605590C add #25,r1
    c.r[3] = 0x30u;  // 0605590E mov #48,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06055910 mov.b @r1,r1
    c.r[0] = ld32(0x06055B1Cu);  // 06055912 mov.l 0x06055B1C,r0
    c.r[7] = ld32(c.r[0]);  // 06055914 mov.l @r0,r7
    c.r[2] = 0x0u;  // 06055916 mov #0,r2
    c.r[11] = ld32(c.r[14] + 32);  // 06055918 mov.l @(32,r14),r11
    c.r[3] &= c.r[1];  // 0605591A and r1,r3
    c.r[7] += c.r[11];  // 0605591C add r11,r7
    c.r[3] >>= 2;  // 0605591E shlr2 r3
    c.r[3] >>= 2;  // 06055920 shlr2 r3
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[3];  // 06055922 cmp/ge r3,r2
    { const bool k = c.t; c.r[7] += 17; if (k) { goto L_0605593C; } }  // 06055924 bt/s 0x0605593C ; add #17,r7
    c.r[0] = c.r[7];  // 06055928 mov r7,r0
L_0605592A:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0605592A mov.b @(r0,r2),r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605592C extu.b r1,r1
    c.r[0] = c.r[1];  // 0605592E mov r1,r0
    c.t = c.r[0] == 0xAu;  // 06055930 cmp/eq #10,r0
    if (c.t) { goto L_0605593C; }  // 06055932 bt 0x0605593C
    c.r[2] += 1;  // 06055934 add #1,r2
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[3];  // 06055936 cmp/ge r3,r2
    { const bool k = !c.t; c.r[0] = c.r[7]; if (k) { SH2_POLL(c); goto L_0605592A; } }  // 06055938 bf/s 0x0605592A ; mov r7,r0
L_0605593C:
    c.t = c.r[2] == c.r[3];  // 0605593C cmp/eq r3,r2
    { const bool k = c.t; c.r[1] = 0xFFFFFFFFu; if (k) { goto L_06055944; } }  // 0605593E bt/s 0x06055944 ; mov #-1,r1
    c.r[1] = c.r[2];  // 06055942 mov r2,r1
L_06055944:
    c.r[1] = (uint32_t)(int32_t)(int8_t)c.r[1];  // 06055944 exts.b r1,r1
    c.r[0] = c.r[1];  // 06055946 mov r1,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 06055948 cmp/eq #-1,r0
    c.r[11] = c.t;  // 0605594A movt r11
    st32(c.r[14] + 32, c.r[11]);  // 0605594C mov.l r11,@(32,r14)
    c.r[0] = c.r[11];  // 0605594E mov r11,r0
    c.r[0] ^= 0x1u;  // 06055950 xor #1,r0
    c.t = (c.r[9] & c.r[9]) == 0;  // 06055952 tst r9,r9
    { const bool k = !c.t; st32(c.r[14] + 32, c.r[0]); if (k) { goto L_060559BE; } }  // 06055954 bf/s 0x060559BE ; mov.l r0,@(32,r14)
    c.t = (c.r[0] & c.r[0]) == 0;  // 06055958 tst r0,r0
    { const bool k = !c.t; c.r[1] = 0x1Eu; if (k) { goto L_0605598C; } }  // 0605595A bf/s 0x0605598C ; mov #30,r1
    c.r[11] = ld32(0x06055B1Cu);  // 0605595E mov.l 0x06055B1C,r11
    c.r[5] = 0x1Bu;  // 06055960 mov #27,r5
    c.macl = c.r[12] * c.r[1];  // 06055962 mul.l r1,r12
    c.r[4] = ld32(0x06055B20u);  // 06055964 mov.l 0x06055B20,r4
    c.r[2] = ld32(c.r[11]);  // 06055966 mov.l @r11,r2
    c.r[1] = c.macl;  // 06055968 sts macl,r1
    c.r[0] = c.r[1];  // 0605596A mov r1,r0
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 0605596C mov.w @(r0,r2),r8
    c.r[11] = ld32(0x06055B24u);  // 0605596E mov.l 0x06055B24,r11
    { const uint32_t x = c.r[11]; c.pr = 0x06055974u; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06055974u) return; }  // 06055970 jsr @r11 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 06055974 mov r0,r1
    c.r[5] = c.r[8];  // 06055976 mov r8,r5
    { const uint32_t x = c.r[11]; c.pr = 0x0605597Cu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605597Cu) return; }  // 06055978 jsr @r11 ; mov r1,r4
    c.r[1] = c.r[0];  // 0605597C mov r0,r1
    c.r[1] += 25;  // 0605597E add #25,r1
    c.r[0] = 0xFu;  // 06055980 mov #15,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06055982 mov.b @r1,r1
    c.r[11] = 0x10u;  // 06055984 mov #16,r11
    c.r[1] &= c.r[0];  // 06055986 and r0,r1
    c.r[1] |= c.r[11]; goto L_0605598E;  // 06055988 bra 0x0605598E ; or r11,r1
L_0605598C:
    c.r[1] = 0x16u;  // 0605598C mov #22,r1
L_0605598E:
    c.r[0] = ld32(c.r[14] + 28);  // 0605598E mov.l @(28,r14),r0
    c.r[11] = ld32(c.r[14] + 24);  // 06055990 mov.l @(24,r14),r11
    c.r[7] = 0xFFFFFFFFu;  // 06055992 mov #-1,r7
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06055994 mov.b @r0,r5
    c.r[6] = c.r[1];  // 06055996 mov r1,r6
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[11]);  // 06055998 mov.b @r11,r4
    c.r[5] = c.r[5] & 0xFFu;  // 0605599A extu.b r5,r5
    c.r[0] = ld32(0x06055B28u);  // 0605599C mov.l 0x06055B28,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060559A2u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060559A2u) return; }  // 0605599E jsr @r0 ; extu.b r4,r4
    c.r[1] = c.r[0];  // 060559A2 mov r0,r1
    c.r[3] = (uint32_t)(int32_t)(int8_t)c.r[1];  // 060559A4 exts.b r1,r3
    c.t = (int32_t)c.r[3] >= 0;  // 060559A6 cmp/pz r3
    { const bool k = !c.t; c.r[1] = c.r[10]; if (k) { goto L_06055A4C; } }  // 060559A8 bf/s 0x06055A4C ; mov r10,r1
    c.r[1] += c.r[1];  // 060559AC add r1,r1
    c.r[3] <<= 2;  // 060559AE shll2 r3
    c.r[3] <<= 2;  // 060559B0 shll2 r3
    c.r[3] += c.r[3];  // 060559B2 add r3,r3
    c.r[3] <<= 2;  // 060559B4 shll2 r3
    c.r[0] = c.r[14];  // 060559B6 mov r14,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060559B8 mov.b @(r0,r1),r2
    c.r[11] = 0x7Fu; goto L_06055A38;  // 060559BA bra 0x06055A38 ; mov #127,r11
L_060559BE:
    c.r[0] = ld32(c.r[14] + 32);  // 060559BE mov.l @(32,r14),r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060559C0 tst r0,r0
    { const bool k = !c.t; c.r[1] = 0x1Eu; if (k) { goto L_060559F0; } }  // 060559C2 bf/s 0x060559F0 ; mov #30,r1
    c.r[11] = ld32(0x06055B1Cu);  // 060559C6 mov.l 0x06055B1C,r11
    c.r[5] = 0x1Bu;  // 060559C8 mov #27,r5
    c.macl = c.r[12] * c.r[1];  // 060559CA mul.l r1,r12
    c.r[4] = ld32(0x06055B20u);  // 060559CC mov.l 0x06055B20,r4
    c.r[2] = ld32(c.r[11]);  // 060559CE mov.l @r11,r2
    c.r[1] = c.macl;  // 060559D0 sts macl,r1
    c.r[0] = c.r[1];  // 060559D2 mov r1,r0
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 060559D4 mov.w @(r0,r2),r8
    c.r[11] = ld32(0x06055B24u);  // 060559D6 mov.l 0x06055B24,r11
    { const uint32_t x = c.r[11]; c.pr = 0x060559DCu; c.r[8] = c.r[8] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060559DCu) return; }  // 060559D8 jsr @r11 ; extu.w r8,r8
    c.r[1] = c.r[0];  // 060559DC mov r0,r1
    c.r[5] = c.r[8];  // 060559DE mov r8,r5
    { const uint32_t x = c.r[11]; c.pr = 0x060559E4u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060559E4u) return; }  // 060559E0 jsr @r11 ; mov r1,r4
    c.r[1] = c.r[0];  // 060559E4 mov r0,r1
    c.r[1] += 25;  // 060559E6 add #25,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060559E8 mov.b @r1,r1
    c.r[0] = 0xFu;  // 060559EA mov #15,r0
    c.r[1] &= c.r[0]; goto L_060559F2;  // 060559EC bra 0x060559F2 ; and r0,r1
L_060559F0:
    c.r[1] = 0x6u;  // 060559F0 mov #6,r1
L_060559F2:
    c.r[5] = ld32(c.r[14] + 28);  // 060559F2 mov.l @(28,r14),r5
    c.r[6] = c.r[1];  // 060559F4 mov r1,r6
    c.r[11] = ld32(0x06055B2Cu);  // 060559F6 mov.l 0x06055B2C,r11
    { const uint32_t x = c.r[11]; c.pr = 0x060559FCu; c.r[4] = ld32(c.r[14] + 24); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060559FCu) return; }  // 060559F8 jsr @r11 ; mov.l @(24,r14),r4
    c.t = c.r[0] == 0xFFFFFFFFu;  // 060559FC cmp/eq #-1,r0
    { const bool k = c.t; c.r[3] = c.r[0]; if (k) { goto L_06055A46; } }  // 060559FE bt/s 0x06055A46 ; mov r0,r3
    c.r[0] = ld32(c.r[14] + 28);  // 06055A02 mov.l @(28,r14),r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06055A04 mov.b @r0,r1
    c.r[11] = ld32(c.r[14] + 24);  // 06055A06 mov.l @(24,r14),r11
    c.r[6] = c.r[1] & 0xFFu;  // 06055A08 extu.b r1,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[11]);  // 06055A0A mov.b @r11,r1
    c.r[2] = ld32(0x06055B30u);  // 06055A0C mov.l 0x06055B30,r2
    c.r[7] = c.r[1] & 0xFFu;  // 06055A0E extu.b r1,r7
    c.r[1] = ld32(c.r[2]);  // 06055A10 mov.l @r2,r1
    c.r[6] <<= 2;  // 06055A12 shll2 r6
    c.r[6] <<= 2;  // 06055A14 shll2 r6
    c.r[6] <<= 2;  // 06055A16 shll2 r6
    c.r[6] += c.r[1];  // 06055A18 add r1,r6
    c.r[1] = c.r[14];  // 06055A1A mov r14,r1
    c.r[1] += 1;  // 06055A1C add #1,r1
    c.r[0] = c.r[1];  // 06055A1E mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[13]);  // 06055A20 mov.b @(r0,r13),r1
    c.r[11] = 0x7Fu;  // 06055A22 mov #127,r11
    c.r[0] = c.r[6];  // 06055A24 mov r6,r0
    st8(c.r[0] + c.r[7], c.r[1]);  // 06055A26 mov.b r1,@(r0,r7)
    c.r[1] = c.r[10];  // 06055A28 mov r10,r1
    c.r[1] += c.r[1];  // 06055A2A add r1,r1
    c.r[0] = c.r[14];  // 06055A2C mov r14,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06055A2E mov.b @(r0,r1),r2
    c.r[3] <<= 2;  // 06055A30 shll2 r3
    c.r[3] <<= 2;  // 06055A32 shll2 r3
    c.r[3] += c.r[3];  // 06055A34 add r3,r3
    c.r[3] <<= 2;  // 06055A36 shll2 r3
L_06055A38:
    c.r[2] &= c.r[11];  // 06055A38 and r11,r2
    c.r[2] |= c.r[3];  // 06055A3A or r3,r2
    st8(c.r[0] + c.r[1], c.r[2]);  // 06055A3C mov.b r2,@(r0,r1)
    c.r[1] = c.r[10];  // 06055A3E mov r10,r1
    c.r[1] += 1;  // 06055A40 add #1,r1
    c.r[10] = c.r[1] & 0xFFu; goto L_06055A4C;  // 06055A42 bra 0x06055A4C ; extu.b r1,r10
L_06055A46:
    c.r[0] = ld32(c.r[14] + 24);  // 06055A46 mov.l @(24,r14),r0
    c.r[1] = 0xFFFFFFFFu;  // 06055A48 mov #-1,r1
    st8(c.r[0], c.r[1]);  // 06055A4A mov.b r1,@r0
L_06055A4C:
    c.r[13] += 2;  // 06055A4C add #2,r13
    c.r[11] = ld32(c.r[14] + 24);  // 06055A4E mov.l @(24,r14),r11
    c.r[9] += 1;  // 06055A50 add #1,r9
    c.r[0] = ld32(c.r[14] + 28);  // 06055A52 mov.l @(28,r14),r0
    c.r[11] += 1;  // 06055A54 add #1,r11
    st32(c.r[14] + 24, c.r[11]);  // 06055A56 mov.l r11,@(24,r14)
    c.r[0] += 1;  // 06055A58 add #1,r0
    c.r[11] = ld32(c.r[14] + 20);  // 06055A5A mov.l @(20,r14),r11
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[11];  // 06055A5C cmp/ge r11,r9
    { const bool k = c.t; st32(c.r[14] + 28, c.r[0]); if (k) { goto L_06055A66; } }  // 06055A5E bt/s 0x06055A66 ; mov.l r0,@(28,r14)
    SH2_POLL(c); goto L_06055898;  // 06055A62 bra 0x06055898 ; nop
L_06055A66:
    c.t = c.r[9] == c.r[10];  // 06055A66 cmp/eq r10,r9
    { const bool k = !c.t; c.r[0] = 0x1u; if (k) { goto L_06055A6E; } }  // 06055A68 bf/s 0x06055A6E ; mov #1,r0
    st32(c.r[14] + 16, c.r[0]);  // 06055A6C mov.l r0,@(16,r14)
L_06055A6E:
    c.r[11] = ld32(c.r[14] + 20);  // 06055A6E mov.l @(20,r14),r11
    c.r[9] = 0x1u;  // 06055A70 mov #1,r9
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[11];  // 06055A72 cmp/ge r11,r9
    { const bool k = c.t; c.r[0] = ld32(c.r[14] + 12); if (k) { goto L_06055AAA; } }  // 06055A74 bt/s 0x06055AAA ; mov.l @(12,r14),r0
    c.r[8] = ld32(0x06055B34u);  // 06055A78 mov.l 0x06055B34,r8
    c.r[7] = (uint32_t)(int16_t)ld16(0x06055B18u);  // 06055A7A mov.w 0x06055B18,r7
    c.r[4] = ld32(0x06055B30u);  // 06055A7C mov.l 0x06055B30,r4
    c.r[5] = ld32(0x06055B38u);  // 06055A7E mov.l 0x06055B38,r5
    c.r[6] = 0x40u;  // 06055A80 mov #64,r6
    c.r[0] = c.r[9];  // 06055A82 mov r9,r0
L_06055A84:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 06055A84 mov.b @(r0,r8),r1
    c.r[3] = c.r[1] & 0xFFu;  // 06055A86 extu.b r1,r3
    c.t = c.r[3] == c.r[7];  // 06055A88 cmp/eq r7,r3
    { const bool k = c.t; c.r[11] = ld32(c.r[14] + 20); if (k) { goto L_06055AA0; } }  // 06055A8A bt/s 0x06055AA0 ; mov.l @(20,r14),r11
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 06055A8E mov.b @(r0,r5),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06055A90 extu.b r1,r1
    c.macl = c.r[1] * c.r[6];  // 06055A92 mul.l r6,r1
    c.r[2] = ld32(c.r[4]);  // 06055A94 mov.l @r4,r2
    c.r[1] = c.macl;  // 06055A96 sts macl,r1
    c.r[1] += c.r[2];  // 06055A98 add r2,r1
    c.r[0] = c.r[1];  // 06055A9A mov r1,r0
    st8(c.r[0] + c.r[3], c.r[7]);  // 06055A9C mov.b r7,@(r0,r3)
    c.r[11] = ld32(c.r[14] + 20);  // 06055A9E mov.l @(20,r14),r11
L_06055AA0:
    c.r[9] += 1;  // 06055AA0 add #1,r9
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[11];  // 06055AA2 cmp/ge r11,r9
    { const bool k = !c.t; c.r[0] = c.r[9]; if (k) { SH2_POLL(c); goto L_06055A84; } }  // 06055AA4 bf/s 0x06055A84 ; mov r9,r0
    c.r[0] = ld32(c.r[14] + 12);  // 06055AA8 mov.l @(12,r14),r0
L_06055AAA:
    c.t = (c.r[0] & c.r[0]) == 0;  // 06055AAA tst r0,r0
    { const bool k = c.t; c.r[0] = ld32(c.r[14] + 16); if (k) { goto L_06055B02; } }  // 06055AAC bt/s 0x06055B02 ; mov.l @(16,r14),r0
    c.r[7] = ld32(0x06055B3Cu);  // 06055AB0 mov.l 0x06055B3C,r7
    c.r[2] = ld32(c.r[7]);  // 06055AB2 mov.l @r7,r2
    c.r[0] = 0x17u;  // 06055AB4 mov #23,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[14]);  // 06055AB6 mov.b @r14,r1
    c.r[0] += c.r[14];  // 06055AB8 add r14,r0
    st8(c.r[2], c.r[1]);  // 06055ABA mov.b r1,@r2
    c.r[1] = c.r[14];  // 06055ABC mov r14,r1
    c.r[1] += 1;  // 06055ABE add #1,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 06055AC0 mov.b @r1+,r3
    c.r[2] += 1;  // 06055AC2 add #1,r2
    st8(c.r[2], c.r[3]);  // 06055AC4 mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 06055AC6 mov.b @r1+,r3
    c.r[2] += 1;  // 06055AC8 add #1,r2
    st8(c.r[2], c.r[3]);  // 06055ACA mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 06055ACC mov.b @r1+,r3
    c.r[2] += 1;  // 06055ACE add #1,r2
    st8(c.r[2], c.r[3]);  // 06055AD0 mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 06055AD2 mov.b @r1+,r3
    c.r[2] += 1;  // 06055AD4 add #1,r2
    st8(c.r[2], c.r[3]);  // 06055AD6 mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 06055AD8 mov.b @r1+,r3
    c.r[2] += 1;  // 06055ADA add #1,r2
    st8(c.r[2], c.r[3]);  // 06055ADC mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 06055ADE mov.b @r1+,r3
    c.r[2] += 1;  // 06055AE0 add #1,r2
    st8(c.r[2], c.r[3]);  // 06055AE2 mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 06055AE4 mov.b @r1+,r3
    c.r[2] += 1;  // 06055AE6 add #1,r2
    st8(c.r[2], c.r[3]);  // 06055AE8 mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 06055AEA mov.b @r1+,r3
    c.r[2] += 1;  // 06055AEC add #1,r2
    st8(c.r[2], c.r[3]);  // 06055AEE mov.b r3,@r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06055AF0 mov.b @r1,r1
    c.r[2] += 1;  // 06055AF2 add #1,r2
    st8(c.r[2], c.r[1]);  // 06055AF4 mov.b r1,@r2
    c.r[1] = ld32(c.r[7]);  // 06055AF6 mov.l @r7,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06055B1Au);  // 06055AF8 mov.w 0x06055B1A,r2
    c.r[11] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06055AFA mov.b @r0,r11
    c.r[0] = c.r[1];  // 06055AFC mov r1,r0
    st8(c.r[0] + c.r[2], c.r[11]);  // 06055AFE mov.b r11,@(r0,r2)
L_06055B00:
    c.r[0] = ld32(c.r[14] + 16);  // 06055B00 mov.l @(16,r14),r0
L_06055B02:
    c.r[14] += 36;  // 06055B02 add #36,r14
    c.r[15] = c.r[14];  // 06055B04 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06055B06 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06055B08 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06055B0A mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06055B0C mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06055B0E mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06055B10 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06055B12 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06055B14 rts ; mov.l @r15+,r8
}

void f_06055B40(SH2Context& c) {
    ran[1328] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06055B40 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06055B42 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06055B44 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06055B46 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06055B48 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06055B4A mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06055B4C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06055B4E sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x06055C28u);  // 06055B50 mov.w 0x06055C28,r3
    c.r[15] += c.r[3];  // 06055B52 add r3,r15
    c.r[14] = c.r[15];  // 06055B54 mov r15,r14
    c.r[13] = 0x0u;  // 06055B56 mov #0,r13
    c.r[0] = (uint32_t)(int16_t)ld16(0x06055C2Au);  // 06055B58 mov.w 0x06055C2A,r0
    st32(c.r[0] + c.r[14], c.r[13]);  // 06055B5A mov.l r13,@(r0,r14)
    c.r[0] = (uint32_t)(int16_t)ld16(0x06055C2Cu);  // 06055B5C mov.w 0x06055C2C,r0
    st32(c.r[0] + c.r[14], c.r[13]);  // 06055B5E mov.l r13,@(r0,r14)
    c.r[1] = ld32(0x06055C34u);  // 06055B60 mov.l 0x06055C34,r1
    c.r[1] = ld32(c.r[1]);  // 06055B62 mov.l @r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06055C2Eu);  // 06055B64 mov.w 0x06055C2E,r2
    c.r[0] = c.r[1];  // 06055B66 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06055B68 mov.b @(r0,r2),r1
    c.r[13] = 0xFu;  // 06055B6A mov #15,r13
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06055B6C shlr r1
    c.r[1] &= c.r[13];  // 06055B6E and r13,r1
    c.r[0] = c.r[1];  // 06055B70 mov r1,r0
    c.t = c.r[0] == 0x2u;  // 06055B72 cmp/eq #2,r0
    if (!c.t) { goto L_06055B9C; }  // 06055B74 bf 0x06055B9C
    c.r[13] = ld32(0x06055C38u);  // 06055B76 mov.l 0x06055C38,r13
    { const uint32_t x = c.r[13]; c.pr = 0x06055B7Cu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06055B7Cu) return; }  // 06055B78 jsr @r13 ; mov #0,r4
    c.r[1] = c.r[0];  // 06055B7C mov r0,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06055B7E extu.b r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06055C2Au);  // 06055B80 mov.w 0x06055C2A,r0
    st32(c.r[0] + c.r[14], c.r[1]);  // 06055B82 mov.l r1,@(r0,r14)
    c.r[13] = (uint32_t)(int16_t)ld16(0x06055C2Au);  // 06055B84 mov.w 0x06055C2A,r13
    c.r[13] += c.r[14];  // 06055B86 add r14,r13
    c.r[13] = ld32(c.r[13]);  // 06055B88 mov.l @r13,r13
    c.t = (c.r[13] & c.r[13]) == 0;  // 06055B8A tst r13,r13
    { const bool k = c.t; c.r[13] = 0x5u; if (k) { goto L_06055B94; } }  // 06055B8C bt/s 0x06055B94 ; mov #5,r13
    goto L_06055D98;  // 06055B90 bra 0x06055D98 ; nop
L_06055B94:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06055C2Au);  // 06055B94 mov.w 0x06055C2A,r0
    c.r[0] += c.r[14];  // 06055B96 add r14,r0
    st32(c.r[0], c.r[13]); goto L_06055D98;  // 06055B98 bra 0x06055D98 ; mov.l r13,@r0
L_06055B9C:
    c.r[3] = ld32(0x06055C3Cu);  // 06055B9C mov.l 0x06055C3C,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x06055C30u);  // 06055B9E mov.w 0x06055C30,r1
    c.r[2] = ld32(c.r[3]);  // 06055BA0 mov.l @r3,r2
    c.r[13] = (uint32_t)(int16_t)ld16(0x06055C2Au);  // 06055BA2 mov.w 0x06055C2A,r13
    c.r[0] = c.r[2];  // 06055BA4 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06055BA6 mov.b @(r0,r1),r1
    c.r[13] += c.r[14];  // 06055BA8 add r14,r13
    c.r[13] = ld32(c.r[13]);  // 06055BAA mov.l @r13,r13
    c.r[1] = c.r[1] & 0xFFu;  // 06055BAC extu.b r1,r1
    c.t = (int32_t)c.r[13] >= (int32_t)c.r[1];  // 06055BAE cmp/ge r1,r13
    { const bool k = !c.t; c.r[11] = 0x0u; if (k) { goto L_06055BB8; } }  // 06055BB0 bf/s 0x06055BB8 ; mov #0,r11
    goto L_06055D98;  // 06055BB4 bra 0x06055D98 ; nop
L_06055BB8:
    c.r[0] = ld32(0x06055C3Cu);  // 06055BB8 mov.l 0x06055C3C,r0
    c.r[2] = c.r[11];  // 06055BBA mov r11,r2
    c.r[1] = ld32(c.r[0]);  // 06055BBC mov.l @r0,r1
    c.r[2] += c.r[2];  // 06055BBE add r2,r2
    c.r[1] += c.r[2];  // 06055BC0 add r2,r1
    c.r[1] += 1;  // 06055BC2 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06055BC4 mov.b @r1,r1
    c.t = (c.r[11] & c.r[11]) == 0;  // 06055BC6 tst r11,r11
    { const bool k = !c.t; c.r[10] = c.r[1] & 0xFFu; if (k) { goto L_06055C4C; } }  // 06055BC8 bf/s 0x06055C4C ; extu.b r1,r10
    c.r[13] = ld32(0x06055C40u);  // 06055BCC mov.l 0x06055C40,r13
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 06055BCE mov.b @r13,r1
    c.r[0] = ld32(0x06055C44u);  // 06055BD0 mov.l 0x06055C44,r0
    c.r[2] = ld32(c.r[0]);  // 06055BD2 mov.l @r0,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06055BD4 extu.b r1,r1
    c.r[1] <<= 2;  // 06055BD6 shll2 r1
    c.r[1] <<= 2;  // 06055BD8 shll2 r1
    c.r[1] += c.r[2];  // 06055BDA add r2,r1
    c.r[1] += 2;  // 06055BDC add #2,r1
    c.r[13] = (uint32_t)(int16_t)ld16(0x06055C2Cu);  // 06055BDE mov.w 0x06055C2C,r13
    c.r[13] += c.r[14];  // 06055BE0 add r14,r13
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06055BE2 mov.b @r1,r1
    c.r[0] = ld32(0x06055C48u);  // 06055BE4 mov.l 0x06055C48,r0
    c.r[1] = c.r[1] & 0xFFu;  // 06055BE6 extu.b r1,r1
    st32(c.r[13], c.r[1]);  // 06055BE8 mov.l r1,@r13
    c.r[13] = (uint32_t)(int16_t)ld16(0x06055C2Cu);  // 06055BEA mov.w 0x06055C2C,r13
    c.r[13] += c.r[14];  // 06055BEC add r14,r13
    c.r[13] = ld32(c.r[13]);  // 06055BEE mov.l @r13,r13
    c.r[1] = 0x1Eu;  // 06055BF0 mov #30,r1
    c.r[2] = ld32(c.r[0]);  // 06055BF2 mov.l @r0,r2
    c.macl = c.r[13] * c.r[1];  // 06055BF4 mul.l r1,r13
    c.r[0] = ld32(0x06055C40u);  // 06055BF6 mov.l 0x06055C40,r0
    c.r[1] = c.macl;  // 06055BF8 sts macl,r1
    c.r[1] += c.r[2];  // 06055BFA add r2,r1
    c.r[1] += 16;  // 06055BFC add #16,r1
    st8(c.r[1], c.r[10]);  // 06055BFE mov.b r10,@r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06055C00 mov.b @r0,r1
    c.r[13] = ld32(0x06055C44u);  // 06055C02 mov.l 0x06055C44,r13
    c.r[2] = ld32(c.r[13]);  // 06055C04 mov.l @r13,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06055C06 extu.b r1,r1
    c.r[1] <<= 2;  // 06055C08 shll2 r1
    c.r[1] <<= 2;  // 06055C0A shll2 r1
    c.r[1] += c.r[2];  // 06055C0C add r2,r1
    c.r[1] += 2;  // 06055C0E add #2,r1
    st8(c.r[1], c.r[10]);  // 06055C10 mov.b r10,@r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06055C12 mov.b @r0,r1
    c.r[10] = c.r[1] & 0xFFu;  // 06055C14 extu.b r1,r10
    c.r[0] = ld32(0x06055C3Cu);  // 06055C16 mov.l 0x06055C3C,r0
    c.r[1] = ld32(c.r[0]);  // 06055C18 mov.l @r0,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06055C1A mov.b @r1,r2
    c.r[13] = (uint32_t)(int16_t)ld16(0x06055C32u);  // 06055C1C mov.w 0x06055C32,r13
    c.r[2] &= c.r[13];  // 06055C1E and r13,r2
    st8(c.r[1], c.r[2]);  // 06055C20 mov.b r2,@r1
    c.r[1] += 1;  // 06055C22 add #1,r1
    st8(c.r[1], c.r[10]); goto L_06055C9E;  // 06055C24 bra 0x06055C9E ; mov.b r10,@r1
L_06055C4C:
    c.r[0] = ld32(0x06055DC4u);  // 06055C4C mov.l 0x06055DC4,r0
    c.r[3] = c.r[10];  // 06055C4E mov r10,r3
    c.r[3] <<= 2;  // 06055C50 shll2 r3
    c.r[3] <<= 2;  // 06055C52 shll2 r3
    c.r[1] = ld32(c.r[0]);  // 06055C54 mov.l @r0,r1
    c.r[13] = 0x7Fu;  // 06055C56 mov #127,r13
    c.r[1] += c.r[3];  // 06055C58 add r3,r1
    c.r[1] += 3;  // 06055C5A add #3,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06055C5C mov.b @r1,r2
    c.r[6] = c.r[10];  // 06055C5E mov r10,r6
    c.r[2] &= c.r[13];  // 06055C60 and r13,r2
    st8(c.r[1], c.r[2]);  // 06055C62 mov.b r2,@r1
    c.r[2] = ld32(c.r[0]);  // 06055C64 mov.l @r0,r2
    c.r[1] = ld32(0x06055DC8u);  // 06055C66 mov.l 0x06055DC8,r1
    c.r[0] = c.r[11];  // 06055C68 mov r11,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06055C6A mov.b @(r0,r1),r1
    c.r[13] = ld32(0x06055DC4u);  // 06055C6C mov.l 0x06055DC4,r13
    c.r[0] = c.r[3];  // 06055C6E mov r3,r0
    st8(c.r[0] + c.r[2], c.r[1]);  // 06055C70 mov.b r1,@(r0,r2)
    c.r[1] = ld32(0x06055DCCu);  // 06055C72 mov.l 0x06055DCC,r1
    c.r[2] = ld32(c.r[13]);  // 06055C74 mov.l @r13,r2
    c.r[0] = c.r[11];  // 06055C76 mov r11,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06055C78 mov.b @(r0,r1),r1
    c.r[2] += c.r[3];  // 06055C7A add r3,r2
    c.r[2] += 1;  // 06055C7C add #1,r2
    st8(c.r[2], c.r[1]);  // 06055C7E mov.b r1,@r2
    c.r[1] = ld32(c.r[13]);  // 06055C80 mov.l @r13,r1
    c.r[0] = ld32(0x06055DD0u);  // 06055C82 mov.l 0x06055DD0,r0
    c.r[1] += c.r[3];  // 06055C84 add r3,r1
    c.r[1] += 4;  // 06055C86 add #4,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06055C88 mov.b @r1,r2
    c.r[13] = (uint32_t)(int16_t)ld16(0x06055DB6u);  // 06055C8A mov.w 0x06055DB6,r13
    c.r[2] &= c.r[13];  // 06055C8C and r13,r2
    st8(c.r[1], c.r[2]);  // 06055C8E mov.b r2,@r1
    c.r[1] = ld32(0x06055DD4u);  // 06055C90 mov.l 0x06055DD4,r1
    c.r[13] = (uint32_t)(int16_t)ld16(0x06055DB8u);  // 06055C92 mov.w 0x06055DB8,r13
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06055C94 mov.b @r0,r5
    c.r[13] += c.r[14];  // 06055C96 add r14,r13
    c.r[4] = ld32(c.r[13]);  // 06055C98 mov.l @r13,r4
    { const uint32_t x = c.r[1]; c.pr = 0x06055C9Eu; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06055C9Eu) return; }  // 06055C9A jsr @r1 ; extu.b r5,r5
L_06055C9E:
    c.r[0] = ld32(0x06055DC4u);  // 06055C9E mov.l 0x06055DC4,r0
    c.r[12] = c.r[10];  // 06055CA0 mov r10,r12
    c.r[12] <<= 2;  // 06055CA2 shll2 r12
    c.r[12] <<= 2;  // 06055CA4 shll2 r12
    c.r[13] = ld32(0x06055DD8u);  // 06055CA6 mov.l 0x06055DD8,r13
    c.r[3] = c.r[11];  // 06055CA8 mov r11,r3
    c.r[3] += c.r[3];  // 06055CAA add r3,r3
    c.r[8] = 0x1Eu;  // 06055CAC mov #30,r8
    c.r[2] = ld32(c.r[0]);  // 06055CAE mov.l @r0,r2
    c.r[6] = (uint32_t)(int16_t)ld16(0x06055DBAu);  // 06055CB0 mov.w 0x06055DBA,r6
    c.r[1] = ld32(c.r[13]);  // 06055CB2 mov.l @r13,r1
    c.r[2] += c.r[12];  // 06055CB4 add r12,r2
    c.r[0] = c.r[1];  // 06055CB6 mov r1,r0
    c.r[2] += 3;  // 06055CB8 add #3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06055CBA mov.b @(r0,r3),r1
    c.r[13] = 0x8u;  // 06055CBC mov #8,r13
    c.r[3] = c.r[1];  // 06055CBE mov r1,r3
    c.r[3] >>= 2;  // 06055CC0 shlr2 r3
    c.r[3] >>= 2;  // 06055CC2 shlr2 r3
    c.r[3] &= c.r[13];  // 06055CC4 and r13,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x06055DBCu);  // 06055CC6 mov.w 0x06055DBC,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06055CC8 mov.b @r2,r1
    c.r[13] = ld32(0x06055DC4u);  // 06055CCA mov.l 0x06055DC4,r13
    c.r[1] &= c.r[0];  // 06055CCC and r0,r1
    c.r[1] |= c.r[3];  // 06055CCE or r3,r1
    st8(c.r[2], c.r[1]);  // 06055CD0 mov.b r1,@r2
    c.r[1] = ld32(c.r[13]);  // 06055CD2 mov.l @r13,r1
    c.r[1] += c.r[12];  // 06055CD4 add r12,r1
    c.r[1] += 2;  // 06055CD6 add #2,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06055CD8 mov.b @r1,r5
    c.r[0] = ld32(0x06055DDCu);  // 06055CDA mov.l 0x06055DDC,r0
    c.r[5] = c.r[5] & 0xFFu;  // 06055CDC extu.b r5,r5
    c.macl = c.r[5] * c.r[8];  // 06055CDE mul.l r8,r5
    c.r[2] = ld32(c.r[0]);  // 06055CE0 mov.l @r0,r2
    c.r[1] = 0xFFFFFFFFu;  // 06055CE2 mov #-1,r1
    c.r[9] = c.macl;  // 06055CE4 sts macl,r9
    c.r[2] += c.r[9];  // 06055CE6 add r9,r2
    c.r[2] += 16;  // 06055CE8 add #16,r2
    st8(c.r[2], c.r[1]);  // 06055CEA mov.b r1,@r2
    c.r[1] = ld32(0x06055DE0u);  // 06055CEC mov.l 0x06055DE0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06055CF2u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06055CF2u) return; }  // 06055CEE jsr @r1 ; mov r14,r4
    c.r[13] = ld32(0x06055DDCu);  // 06055CF2 mov.l 0x06055DDC,r13
    c.r[7] = c.r[9];  // 06055CF4 mov r9,r7
    c.r[0] = (uint32_t)(int16_t)ld16(0x06055DB8u);  // 06055CF6 mov.w 0x06055DB8,r0
    c.r[0] += c.r[14];  // 06055CF8 add r14,r0
    c.r[1] = c.r[14];  // 06055CFA mov r14,r1
    c.r[0] = ld32(c.r[0]);  // 06055CFC mov.l @r0,r0
    c.r[1] += 26;  // 06055CFE add #26,r1
    c.r[2] = ld32(c.r[13]);  // 06055D00 mov.l @r13,r2
    c.macl = c.r[0] * c.r[8];  // 06055D02 mul.l r8,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06055D04 mov.w @r1,r1
    c.r[7] += c.r[2];  // 06055D06 add r2,r7
    c.r[6] = c.macl;  // 06055D08 sts macl,r6
    c.r[2] += c.r[6];  // 06055D0A add r6,r2
    c.r[2] += 22;  // 06055D0C add #22,r2
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06055D0E mov.w @r2,r2
    c.r[7] += 22;  // 06055D10 add #22,r7
    c.macl = (c.r[2] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 06055D12 mulu.w r1,r2
    c.r[13] = ld32(0x06055DE4u);  // 06055D14 mov.l 0x06055DE4,r13
    c.r[1] = ld32(c.r[13]);  // 06055D16 mov.l @r13,r1
    c.r[8] = ld32(0x06055DE8u);  // 06055D18 mov.l 0x06055DE8,r8
    c.r[1] += 26;  // 06055D1A add #26,r1
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06055D1C mov.w @r1,r5
    c.r[4] = c.macl;  // 06055D1E sts macl,r4
    c.macl = c.r[9];  // 06055D20 lds r9,macl
    { const uint32_t x = c.r[8]; c.pr = 0x06055D26u; c.r[5] = c.r[5] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06055D26u) return; }  // 06055D22 jsr @r8 ; extu.w r5,r5
    c.r[5] = c.r[0];  // 06055D26 mov r0,r5
    c.r[1] = c.r[5] & 0xFFFFu;  // 06055D28 extu.w r5,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06055D2A tst r1,r1
    { const bool k = !c.t; st16(c.r[7], c.r[5]); if (k) { goto L_06055D34; } }  // 06055D2C bf/s 0x06055D34 ; mov.w r5,@r7
    c.r[1] = 0x1u;  // 06055D30 mov #1,r1
    st16(c.r[7], c.r[1]);  // 06055D32 mov.w r1,@r7
L_06055D34:
    c.r[13] = ld32(0x06055DDCu);  // 06055D34 mov.l 0x06055DDC,r13
    c.r[1] = ld32(c.r[13]);  // 06055D36 mov.l @r13,r1
    c.r[7] = c.macl;  // 06055D38 sts macl,r7
    c.r[7] += c.r[1];  // 06055D3A add r1,r7
    c.r[6] += c.r[1];  // 06055D3C add r1,r6
    c.r[6] += 24;  // 06055D3E add #24,r6
    c.r[1] = c.r[14];  // 06055D40 mov r14,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[6]);  // 06055D42 mov.w @r6,r2
    c.r[1] += 28;  // 06055D44 add #28,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06055D46 mov.w @r1,r1
    c.r[0] = ld32(0x06055DE4u);  // 06055D48 mov.l 0x06055DE4,r0
    c.macl = (c.r[2] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 06055D4A mulu.w r1,r2
    c.r[7] += 24;  // 06055D4C add #24,r7
    c.r[1] = ld32(c.r[0]);  // 06055D4E mov.l @r0,r1
    c.r[13] = ld32(0x06055DC4u);  // 06055D50 mov.l 0x06055DC4,r13
    c.r[1] += 28;  // 06055D52 add #28,r1
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06055D54 mov.w @r1,r5
    c.r[4] = c.macl;  // 06055D56 sts macl,r4
    { const uint32_t x = c.r[8]; c.pr = 0x06055D5Cu; c.r[5] = c.r[5] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06055D5Cu) return; }  // 06055D58 jsr @r8 ; extu.w r5,r5
    c.r[6] = c.r[0];  // 06055D5C mov r0,r6
    st16(c.r[7], c.r[6]);  // 06055D5E mov.w r6,@r7
    c.r[2] = ld32(0x06055DECu);  // 06055D60 mov.l 0x06055DEC,r2
    c.r[7] = ld32(c.r[13]);  // 06055D62 mov.l @r13,r7
    c.r[1] = c.r[12];  // 06055D64 mov r12,r1
    c.r[1] += c.r[7];  // 06055D66 add r7,r1
    c.r[1] += 1;  // 06055D68 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06055D6A mov.b @r1,r1
    c.r[0] = c.r[12];  // 06055D6C mov r12,r0
    c.r[3] = c.r[1] & 0xFFu;  // 06055D6E extu.b r1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06055D70 mov.b @(r0,r7),r1
    c.r[13] = ld32(0x06055DD8u);  // 06055D72 mov.l 0x06055DD8,r13
    c.r[7] = c.r[1] & 0xFFu;  // 06055D74 extu.b r1,r7
    c.r[1] = ld32(c.r[2]);  // 06055D76 mov.l @r2,r1
    c.r[3] <<= 2;  // 06055D78 shll2 r3
    c.r[3] <<= 2;  // 06055D7A shll2 r3
    c.r[3] <<= 2;  // 06055D7C shll2 r3
    c.r[3] += c.r[1];  // 06055D7E add r1,r3
    c.r[0] = c.r[3];  // 06055D80 mov r3,r0
    st8(c.r[0] + c.r[7], c.r[10]);  // 06055D82 mov.b r10,@(r0,r7)
    c.r[1] = ld32(c.r[13]);  // 06055D84 mov.l @r13,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06055DBEu);  // 06055D86 mov.w 0x06055DBE,r2
    c.r[0] = c.r[1];  // 06055D88 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06055D8A mov.b @(r0,r2),r1
    c.r[11] += 1;  // 06055D8C add #1,r11
    c.r[1] = c.r[1] & 0xFFu;  // 06055D8E extu.b r1,r1
    c.t = (int32_t)c.r[11] >= (int32_t)c.r[1];  // 06055D90 cmp/ge r1,r11
    if (c.t) { goto L_06055D98; }  // 06055D92 bt 0x06055D98
    SH2_POLL(c); goto L_06055BB8;  // 06055D94 bra 0x06055BB8 ; nop
L_06055D98:
    c.r[13] = (uint32_t)(int16_t)ld16(0x06055DC0u);  // 06055D98 mov.w 0x06055DC0,r13
    c.r[13] += c.r[14];  // 06055D9A add r14,r13
    c.r[0] = ld32(c.r[13]);  // 06055D9C mov.l @r13,r0
    c.r[3] = (uint32_t)(int16_t)ld16(0x06055DC2u);  // 06055D9E mov.w 0x06055DC2,r3
    c.r[14] += c.r[3];  // 06055DA0 add r3,r14
    c.r[15] = c.r[14];  // 06055DA2 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06055DA4 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06055DA6 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06055DA8 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06055DAA mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06055DAC mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06055DAE mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06055DB0 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06055DB2 rts ; mov.l @r15+,r8
}

void f_06055DF0(SH2Context& c) {
    ran[1329] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06055DF0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06055DF2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06055DF4 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06055DF6 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06055DF8 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06055DFA mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06055DFC mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06055DFE sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x06055F60u);  // 06055E00 mov.w 0x06055F60,r3
    c.r[15] += c.r[3];  // 06055E02 add r3,r15
    c.r[14] = c.r[15];  // 06055E04 mov r15,r14
    c.r[4] = c.r[4] & 0xFFu;  // 06055E06 extu.b r4,r4
    c.r[0] = (uint32_t)(int16_t)ld16(0x06055F62u);  // 06055E08 mov.w 0x06055F62,r0
    st32(c.r[0] + c.r[14], c.r[4]);  // 06055E0A mov.l r4,@(r0,r14)
    c.r[3] = (uint32_t)(int16_t)ld16(0x06055F64u);  // 06055E0C mov.w 0x06055F64,r3
    c.r[2] = c.r[14];  // 06055E0E mov r14,r2
    c.r[2] += c.r[3];  // 06055E10 add r3,r2
    c.r[1] = 0x1u;  // 06055E12 mov #1,r1
    c.r[0] = c.r[14];  // 06055E14 mov r14,r0
    st8(c.r[0] + c.r[3], c.r[1]);  // 06055E16 mov.b r1,@(r0,r3)
    c.r[3] = c.r[2];  // 06055E18 mov r2,r3
    c.r[3] += 1;  // 06055E1A add #1,r3
    c.r[1] = 0x9u;  // 06055E1C mov #9,r1
    st8(c.r[3], c.r[1]);  // 06055E1E mov.b r1,@r3
    c.r[3] = c.r[2];  // 06055E20 mov r2,r3
    c.r[3] += 2;  // 06055E22 add #2,r3
    c.r[1] = 0x8u;  // 06055E24 mov #8,r1
    st8(c.r[3], c.r[1]);  // 06055E26 mov.b r1,@r3
    c.r[3] = c.r[2];  // 06055E28 mov r2,r3
    c.r[3] += 3;  // 06055E2A add #3,r3
    c.r[1] = 0xAu;  // 06055E2C mov #10,r1
    st8(c.r[3], c.r[1]);  // 06055E2E mov.b r1,@r3
    c.r[3] = c.r[2];  // 06055E30 mov r2,r3
    c.r[3] += 4;  // 06055E32 add #4,r3
    c.r[1] = 0x2u;  // 06055E34 mov #2,r1
    st8(c.r[3], c.r[1]);  // 06055E36 mov.b r1,@r3
    c.r[3] = c.r[2];  // 06055E38 mov r2,r3
    c.r[3] += 5;  // 06055E3A add #5,r3
    c.r[1] = 0x6u;  // 06055E3C mov #6,r1
    st8(c.r[3], c.r[1]);  // 06055E3E mov.b r1,@r3
    c.r[3] = c.r[2];  // 06055E40 mov r2,r3
    c.r[3] += 6;  // 06055E42 add #6,r3
    c.r[1] = 0x4u;  // 06055E44 mov #4,r1
    st8(c.r[3], c.r[1]);  // 06055E46 mov.b r1,@r3
    c.r[2] += 7;  // 06055E48 add #7,r2
    c.r[1] = 0x5u;  // 06055E4A mov #5,r1
    st8(c.r[2], c.r[1]);  // 06055E4C mov.b r1,@r2
    c.r[13] = 0x0u;  // 06055E4E mov #0,r13
    c.r[12] = (uint32_t)(int16_t)ld16(0x06055F66u);  // 06055E50 mov.w 0x06055F66,r12
    c.r[12] += c.r[14];  // 06055E52 add r14,r12
    st32(c.r[12], c.r[13]);  // 06055E54 mov.l r13,@r12
    c.r[12] = 0x0u;  // 06055E56 mov #0,r12
    c.r[0] = (uint32_t)(int16_t)ld16(0x06055F68u);  // 06055E58 mov.w 0x06055F68,r0
    st32(c.r[0] + c.r[14], c.r[12]);  // 06055E5A mov.l r12,@(r0,r14)
    c.r[13] = ld32(0x06055F70u);  // 06055E5C mov.l 0x06055F70,r13
    c.r[1] = ld32(c.r[13]);  // 06055E5E mov.l @r13,r1
    c.r[9] = (uint32_t)(int16_t)ld16(0x06055F6Au);  // 06055E60 mov.w 0x06055F6A,r9
    c.r[0] = c.r[1];  // 06055E62 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 06055E64 mov.b @(r0,r9),r1
    c.r[12] = 0xFu;  // 06055E66 mov #15,r12
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06055E68 shlr r1
    c.r[1] &= c.r[12];  // 06055E6A and r12,r1
    c.r[0] = c.r[1];  // 06055E6C mov r1,r0
    c.t = c.r[0] == 0x9u;  // 06055E6E cmp/eq #9,r0
    { const bool k = !c.t; c.t = c.r[0] == 0x5u; if (k) { goto L_06055F54; } }  // 06055E70 bf/s 0x06055F54 ; cmp/eq #5,r0
    c.r[6] = ld32(0x06055F74u);  // 06055E74 mov.l 0x06055F74,r6
    c.r[11] = ld32(0x06055F78u);  // 06055E76 mov.l 0x06055F78,r11
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[11]);  // 06055E78 mov.b @r11,r7
    c.r[1] = ld32(0x06055F7Cu);  // 06055E7A mov.l 0x06055F7C,r1
    c.r[4] = ld32(c.r[1]);  // 06055E7C mov.l @r1,r4
    c.r[3] = c.r[7] & 0xFFu;  // 06055E7E extu.b r7,r3
    c.r[3] <<= 2;  // 06055E80 shll2 r3
    c.r[3] <<= 2;  // 06055E82 shll2 r3
    c.r[1] = c.r[3];  // 06055E84 mov r3,r1
    c.r[1] += c.r[4];  // 06055E86 add r4,r1
    c.r[1] += 1;  // 06055E88 add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06055E8A mov.b @r1,r2
    c.r[0] = c.r[3];  // 06055E8C mov r3,r0
    c.r[2] = c.r[2] & 0xFFu;  // 06055E8E extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[4]);  // 06055E90 mov.b @(r0,r4),r1
    c.r[2] <<= 2;  // 06055E92 shll2 r2
    c.r[2] <<= 2;  // 06055E94 shll2 r2
    c.r[2] <<= 2;  // 06055E96 shll2 r2
    c.r[3] = ld32(c.r[6]);  // 06055E98 mov.l @r6,r3
    c.r[1] = c.r[1] & 0xFFu;  // 06055E9A extu.b r1,r1
    c.r[2] += c.r[3];  // 06055E9C add r3,r2
    c.r[0] = c.r[2];  // 06055E9E mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06055EA0 mov.b @(r0,r1),r1
    c.r[7] = c.r[7] & 0xFFu;  // 06055EA2 extu.b r7,r7
    c.r[10] = c.r[1] & 0xFFu;  // 06055EA4 extu.b r1,r10
    c.t = c.r[10] == c.r[7];  // 06055EA6 cmp/eq r7,r10
    if (!c.t) { goto L_06055EAE; }  // 06055EA8 bf 0x06055EAE
    goto L_060563F4;  // 06055EAA bra 0x060563F4 ; nop
L_06055EAE:
    c.r[6] = (uint32_t)(int16_t)ld16(0x06055F6Cu);  // 06055EAE mov.w 0x06055F6C,r6
    c.t = c.r[10] == c.r[6];  // 06055EB0 cmp/eq r6,r10
    { const bool k = !c.t; c.r[5] = c.r[10]; if (k) { goto L_06055EBA; } }  // 06055EB2 bf/s 0x06055EBA ; mov r10,r5
    goto L_060563F4;  // 06055EB6 bra 0x060563F4 ; nop
L_06055EBA:
    c.r[5] <<= 2;  // 06055EBA shll2 r5
    c.r[5] <<= 2;  // 06055EBC shll2 r5
    c.r[5] += c.r[4];  // 06055EBE add r4,r5
    c.r[1] = c.r[5];  // 06055EC0 mov r5,r1
    c.r[1] += 7;  // 06055EC2 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06055EC4 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06055EC6 extu.b r1,r1
    c.r[1] >>= 2;  // 06055EC8 shlr2 r1
    c.r[1] >>= 2;  // 06055ECA shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06055ECC shlr r1
    c.r[1] >>= 2;  // 06055ECE shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06055ED0 tst r1,r1
    { const bool k = c.t; c.r[5] += 2; if (k) { goto L_06055EDA; } }  // 06055ED2 bt/s 0x06055EDA ; add #2,r5
    goto L_060563F4;  // 06055ED6 bra 0x060563F4 ; nop
L_06055EDA:
    c.r[8] = c.r[14];  // 06055EDA mov r14,r8
    c.r[8] += 12;  // 06055EDC add #12,r8
    c.r[1] = ld32(0x06055F80u);  // 06055EDE mov.l 0x06055F80,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[5]);  // 06055EE0 mov.b @r5,r5
    c.r[4] = c.r[8];  // 06055EE2 mov r8,r4
    { const uint32_t x = c.r[1]; c.pr = 0x06055EE8u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06055EE8u) return; }  // 06055EE4 jsr @r1 ; extu.b r5,r5
    c.r[1] = ld32(c.r[13]);  // 06055EE8 mov.l @r13,r1
    c.r[0] = c.r[1];  // 06055EEA mov r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 06055EEC mov.b @(r0,r9),r2
    c.r[2] = c.r[2] & 0xFFu;  // 06055EEE extu.b r2,r2
    c.r[0] = c.r[8];  // 06055EF0 mov r8,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 06055EF2 mov.b @(r0,r9),r1
    c.r[2] >>= 2;  // 06055EF4 shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 06055EF6 shlr r2
    c.r[2] >>= 2;  // 06055EF8 shlr2 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06055EFA extu.b r1,r1
    c.r[1] >>= 2;  // 06055EFC shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06055EFE shlr r1
    c.r[1] >>= 2;  // 06055F00 shlr2 r1
    c.t = c.r[2] > c.r[1];  // 06055F02 cmp/hi r1,r2
    { const bool k = !c.t; c.r[1] = c.r[14]; if (k) { goto L_06055F26; } }  // 06055F04 bf/s 0x06055F26 ; mov r14,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[14]);  // 06055F08 mov.b @r14,r0
    c.r[1] += 1;  // 06055F0A add #1,r1
    c.r[0] &= 0x80u;  // 06055F0C and #128,r0
    st8(c.r[14], c.r[0]);  // 06055F0E mov.b r0,@r14
    st8(c.r[1], c.r[10]);  // 06055F10 mov.b r10,@r1
    c.r[1] = c.r[14];  // 06055F12 mov r14,r1
    c.r[1] += 2;  // 06055F14 add #2,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06055F16 mov.b @r1,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[11]);  // 06055F18 mov.b @r11,r2
    c.r[0] &= 0x80u;  // 06055F1A and #128,r0
    st8(c.r[1], c.r[0]);  // 06055F1C mov.b r0,@r1
    c.r[1] = c.r[14];  // 06055F1E mov r14,r1
    c.r[1] += 3;  // 06055F20 add #3,r1
    st8(c.r[1], c.r[2]); goto L_06055F48;  // 06055F22 bra 0x06055F48 ; mov.b r2,@r1
L_06055F26:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[14]);  // 06055F26 mov.b @r14,r0
    c.r[1] += 1;  // 06055F28 add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[11]);  // 06055F2A mov.b @r11,r2
    c.r[0] &= 0x80u;  // 06055F2C and #128,r0
    st8(c.r[14], c.r[0]);  // 06055F2E mov.b r0,@r14
    st8(c.r[1], c.r[2]);  // 06055F30 mov.b r2,@r1
    c.r[2] = c.r[10];  // 06055F32 mov r10,r2
    c.r[1] = c.r[14];  // 06055F34 mov r14,r1
    c.r[1] += 2;  // 06055F36 add #2,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06055F38 mov.b @r1,r0
    c.r[2] >>= 8;  // 06055F3A shlr8 r2
    c.r[0] &= 0x80u;  // 06055F3C and #128,r0
    c.r[0] |= c.r[2];  // 06055F3E or r2,r0
    st8(c.r[1], c.r[0]);  // 06055F40 mov.b r0,@r1
    c.r[1] = c.r[14];  // 06055F42 mov r14,r1
    c.r[1] += 3;  // 06055F44 add #3,r1
    st8(c.r[1], c.r[10]);  // 06055F46 mov.b r10,@r1
L_06055F48:
    c.r[13] = 0x2u;  // 06055F48 mov #2,r13
    c.r[12] = (uint32_t)(int16_t)ld16(0x06055F68u);  // 06055F4A mov.w 0x06055F68,r12
    c.r[12] += c.r[14];  // 06055F4C add r14,r12
    st32(c.r[12], c.r[13]);  // 06055F4E mov.l r13,@r12
    c.r[12] = 0x1u; goto L_060563F0;  // 06055F50 bra 0x060563F0 ; mov #1,r12
L_06055F54:
    { const bool k = c.t; c.t = c.r[0] == 0x7u; if (k) { goto L_06055F84; } }  // 06055F54 bt/s 0x06055F84 ; cmp/eq #7,r0
    { const bool k = c.t; c.r[12] = 0x20u; if (k) { goto L_06055FA4; } }  // 06055F58 bt/s 0x06055FA4 ; mov #32,r12
    goto L_06055FBC;  // 06055F5C bra 0x06055FBC ; nop
L_06055F84:
    c.r[1] = ld32(0x06055FA0u);  // 06055F84 mov.l 0x06055FA0,r1
    c.r[2] = ld32(c.r[1]);  // 06055F86 mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06055F9Cu);  // 06055F88 mov.w 0x06055F9C,r1
    c.r[0] = c.r[2];  // 06055F8A mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06055F8C mov.b @(r0,r1),r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x06055F9Eu);  // 06055F8E mov.w 0x06055F9E,r12
    c.r[1] &= c.r[12];  // 06055F90 and r12,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06055F92 tst r1,r1
    { const bool k = !c.t; c.r[0] = 0x4u; if (k) { goto L_06055FBC; } }  // 06055F94 bf/s 0x06055FBC ; mov #4,r0
    goto L_06055FB6;  // 06055F98 bra 0x06055FB6 ; nop
L_06055FA4:
    c.r[1] = ld32(0x06056174u);  // 06055FA4 mov.l 0x06056174,r1
    c.r[2] = ld32(c.r[1]);  // 06055FA6 mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06056152u);  // 06055FA8 mov.w 0x06056152,r1
    c.r[0] = c.r[2];  // 06055FAA mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06055FAC mov.b @(r0,r1),r1
    c.r[1] &= c.r[12];  // 06055FAE and r12,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06055FB0 tst r1,r1
    { const bool k = !c.t; c.r[0] = 0x5u; if (k) { goto L_06055FBC; } }  // 06055FB2 bf/s 0x06055FBC ; mov #5,r0
L_06055FB6:
    c.r[13] = (uint32_t)(int16_t)ld16(0x06056154u);  // 06055FB6 mov.w 0x06056154,r13
    c.r[13] += c.r[14];  // 06055FB8 add r14,r13
    st32(c.r[13], c.r[0]);  // 06055FBA mov.l r0,@r13
L_06055FBC:
    c.r[12] = (uint32_t)(int16_t)ld16(0x06056154u);  // 06055FBC mov.w 0x06056154,r12
    c.r[12] += c.r[14];  // 06055FBE add r14,r12
    c.r[12] = ld32(c.r[12]);  // 06055FC0 mov.l @r12,r12
    c.t = (c.r[12] & c.r[12]) == 0;  // 06055FC2 tst r12,r12
    { const bool k = !c.t; c.r[2] = c.r[14]; if (k) { goto L_06055FCC; } }  // 06055FC4 bf/s 0x06055FCC ; mov r14,r2
    goto L_060563F4;  // 06055FC8 bra 0x060563F4 ; nop
L_06055FCC:
    c.r[2] += 1;  // 06055FCC add #1,r2
    c.r[1] = 0x0u;  // 06055FCE mov #0,r1
    c.r[3] = 0x8u;  // 06055FD0 mov #8,r3
L_06055FD2:
    c.r[0] = c.r[1];  // 06055FD2 mov r1,r0
    c.r[12] = (uint32_t)(int16_t)ld16(0x06056156u);  // 06055FD4 mov.w 0x06056156,r12
    c.r[13] = (uint32_t)(int16_t)ld16(0x06056158u);  // 06055FD6 mov.w 0x06056158,r13
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 06055FD8 mov.b @(r0,r14),r7
    c.r[1] += 2;  // 06055FDA add #2,r1
    c.r[7] &= c.r[12];  // 06055FDC and r12,r7
    st8(c.r[0] + c.r[14], c.r[7]);  // 06055FDE mov.b r7,@(r0,r14)
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06055FE0 mov.b @(r0,r2),r7
    c.t = (int32_t)c.r[1] > (int32_t)c.r[3];  // 06055FE2 cmp/gt r3,r1
    c.r[7] |= c.r[13];  // 06055FE4 or r13,r7
    { const bool k = !c.t; st8(c.r[0] + c.r[2], c.r[7]); if (k) { SH2_POLL(c); goto L_06055FD2; } }  // 06055FE6 bf/s 0x06055FD2 ; mov.b r7,@(r0,r2)
    c.r[1] = ld32(0x06056178u);  // 06055FEA mov.l 0x06056178,r1
    c.r[7] = c.r[14];  // 06055FEC mov r14,r7
    c.r[7] += 1;  // 06055FEE add #1,r7
    c.r[6] = 0x1u;  // 06055FF0 mov #1,r6
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605615Au);  // 06055FF2 mov.w 0x0605615A,r0
    c.r[0] += c.r[14];  // 06055FF4 add r14,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06055FF6 mov.b @r1,r2
    c.r[13] = (uint32_t)(int16_t)ld16(0x0605615Au);  // 06055FF8 mov.w 0x0605615A,r13
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[14]);  // 06055FFA mov.b @r14,r1
    c.r[13] += c.r[14];  // 06055FFC add r14,r13
    c.r[1] &= c.r[12];  // 06055FFE and r12,r1
    st8(c.r[14], c.r[1]);  // 06056000 mov.b r1,@r14
    st8(c.r[7], c.r[2]);  // 06056002 mov.b r2,@r7
    c.r[12] = ld32(0x0605617Cu);  // 06056004 mov.l 0x0605617C,r12
    st32(c.r[0], c.r[12]);  // 06056006 mov.l r12,@r0
    c.r[2] = c.r[2] & 0xFFu;  // 06056008 extu.b r2,r2
    c.r[1] = ld32(0x06056180u);  // 0605600A mov.l 0x06056180,r1
    c.r[2] <<= 2;  // 0605600C shll2 r2
    c.r[2] <<= 2;  // 0605600E shll2 r2
    c.r[3] = c.r[2];  // 06056010 mov r2,r3
    c.r[12] = (uint32_t)(int16_t)ld16(0x0605615Cu);  // 06056012 mov.w 0x0605615C,r12
    c.r[0] = ld32(c.r[13]);  // 06056014 mov.l @r13,r0
    c.r[12] += c.r[14];  // 06056016 add r14,r12
    c.r[13] = (uint32_t)(int16_t)ld16(0x0605615Eu);  // 06056018 mov.w 0x0605615E,r13
    c.r[13] += c.r[14];  // 0605601A add r14,r13
    st32(c.r[13], c.r[0]);  // 0605601C mov.l r0,@r13
    c.r[0] = c.r[2];  // 0605601E mov r2,r0
    c.r[13] = (uint32_t)(int16_t)ld16(0x06056160u);  // 06056020 mov.w 0x06056160,r13
    c.r[1] = ld32(c.r[1]);  // 06056022 mov.l @r1,r1
    c.r[13] += c.r[14];  // 06056024 add r14,r13
    c.r[3] += c.r[1];  // 06056026 add r1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06056028 mov.b @(r0,r1),r1
    c.r[3] += 1;  // 0605602A add #1,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0605602C extu.b r1,r1
    st32(c.r[12], c.r[1]);  // 0605602E mov.l r1,@r12
    c.r[0] = (uint32_t)(int16_t)ld16(0x06056162u);  // 06056030 mov.w 0x06056162,r0
    c.r[0] += c.r[14];  // 06056032 add r14,r0
    c.r[12] = (uint32_t)(int16_t)ld16(0x06056164u);  // 06056034 mov.w 0x06056164,r12
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06056036 mov.b @r3,r1
    c.r[12] += c.r[14];  // 06056038 add r14,r12
    c.r[1] = c.r[1] & 0xFFu;  // 0605603A extu.b r1,r1
    st32(c.r[13], c.r[1]);  // 0605603C mov.l r1,@r13
    st32(c.r[0], c.r[7]);  // 0605603E mov.l r7,@r0
    c.r[13] = ld32(0x06056184u);  // 06056040 mov.l 0x06056184,r13
    st32(c.r[12], c.r[13]);  // 06056042 mov.l r13,@r12
    c.r[11] = 0x0u;  // 06056044 mov #0,r11
L_06056046:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06056166u);  // 06056046 mov.w 0x06056166,r1
    c.r[1] += c.r[14];  // 06056048 add r14,r1
    c.r[0] = c.r[1];  // 0605604A mov r1,r0
    c.r[2] = 0x8u;  // 0605604C mov #8,r2
    c.r[12] = (uint32_t)(int16_t)ld16(0x0605615Cu);  // 0605604E mov.w 0x0605615C,r12
    c.r[12] += c.r[14];  // 06056050 add r14,r12
    c.r[13] = (uint32_t)(int16_t)ld16(0x06056168u);  // 06056052 mov.w 0x06056168,r13
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 06056054 mov.b @(r0,r11),r3
    c.r[13] += c.r[14];  // 06056056 add r14,r13
    c.r[12] = ld32(c.r[12]);  // 06056058 mov.l @r12,r12
    c.r[2] &= c.r[3];  // 0605605A and r3,r2
    c.r[2] >>= 2;  // 0605605C shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 0605605E shlr r2
    c.r[2] += c.r[12];  // 06056060 add r12,r2
    c.r[1] = 0x4u;  // 06056062 mov #4,r1
    c.r[1] &= c.r[3];  // 06056064 and r3,r1
    c.r[1] >>= 2;  // 06056066 shlr2 r1
    c.r[2] -= c.r[1];  // 06056068 sub r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0605606A extu.b r2,r2
    st32(c.r[13], c.r[2]);  // 0605606C mov.l r2,@r13
    c.r[1] = 0x2u;  // 0605606E mov #2,r1
    c.r[1] &= c.r[3];  // 06056070 and r3,r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06056072 shlr r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06056160u);  // 06056074 mov.w 0x06056160,r0
    c.r[0] += c.r[14];  // 06056076 add r14,r0
    c.r[2] = 0x1u;  // 06056078 mov #1,r2
    c.r[2] &= c.r[3];  // 0605607A and r3,r2
    c.r[12] = (uint32_t)(int16_t)ld16(0x0605616Au);  // 0605607C mov.w 0x0605616A,r12
    c.r[12] += c.r[14];  // 0605607E add r14,r12
    c.r[0] = ld32(c.r[0]);  // 06056080 mov.l @r0,r0
    c.r[13] = (uint32_t)(int16_t)ld16(0x06056168u);  // 06056082 mov.w 0x06056168,r13
    c.r[1] += c.r[0];  // 06056084 add r0,r1
    c.r[1] -= c.r[2];  // 06056086 sub r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06056088 extu.b r1,r1
    st32(c.r[12], c.r[1]);  // 0605608A mov.l r1,@r12
    c.r[1] = ld32(0x06056188u);  // 0605608C mov.l 0x06056188,r1
    c.r[1] += 76;  // 0605608E add #76,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06056090 mov.b @r1,r1
    c.r[13] += c.r[14];  // 06056092 add r14,r13
    c.r[13] = ld32(c.r[13]);  // 06056094 mov.l @r13,r13
    c.r[1] = c.r[1] & 0xFFu;  // 06056096 extu.b r1,r1
    c.t = c.r[13] > c.r[1];  // 06056098 cmp/hi r1,r13
    if (!c.t) { goto L_060560A0; }  // 0605609A bf 0x060560A0
    goto L_0605622E;  // 0605609C bra 0x0605622E ; nop
L_060560A0:
    c.r[0] = ld32(0x0605618Cu);  // 060560A0 mov.l 0x0605618C,r0
    c.r[12] = (uint32_t)(int16_t)ld16(0x0605616Au);  // 060560A2 mov.w 0x0605616A,r12
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 060560A4 mov.b @r0,r1
    c.r[12] += c.r[14];  // 060560A6 add r14,r12
    c.r[12] = ld32(c.r[12]);  // 060560A8 mov.l @r12,r12
    c.r[1] = c.r[1] & 0xFFu;  // 060560AA extu.b r1,r1
    c.t = c.r[12] > c.r[1];  // 060560AC cmp/hi r1,r12
    if (!c.t) { goto L_060560B4; }  // 060560AE bf 0x060560B4
    goto L_0605622E;  // 060560B0 bra 0x0605622E ; nop
L_060560B4:
    c.r[1] = ld32(0x06056190u);  // 060560B4 mov.l 0x06056190,r1
    c.r[13] = (uint32_t)(int16_t)ld16(0x0605616Au);  // 060560B6 mov.w 0x0605616A,r13
    c.r[13] += c.r[14];  // 060560B8 add r14,r13
    c.r[1] = ld32(c.r[1]);  // 060560BA mov.l @r1,r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x06056168u);  // 060560BC mov.w 0x06056168,r12
    c.r[2] = ld32(c.r[13]);  // 060560BE mov.l @r13,r2
    c.r[12] += c.r[14];  // 060560C0 add r14,r12
    c.r[0] = ld32(c.r[12]);  // 060560C2 mov.l @r12,r0
    c.r[2] <<= 2;  // 060560C4 shll2 r2
    c.r[2] <<= 2;  // 060560C6 shll2 r2
    c.r[2] <<= 2;  // 060560C8 shll2 r2
    c.r[2] += c.r[1];  // 060560CA add r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 060560CC mov.b @(r0,r2),r1
    c.r[10] = c.r[1] & 0xFFu;  // 060560CE extu.b r1,r10
    c.r[1] = (uint32_t)(int16_t)ld16(0x06056158u);  // 060560D0 mov.w 0x06056158,r1
    c.t = c.r[10] == c.r[1];  // 060560D2 cmp/eq r1,r10
    if (!c.t) { goto L_060560DA; }  // 060560D4 bf 0x060560DA
    goto L_0605622E;  // 060560D6 bra 0x0605622E ; nop
L_060560DA:
    c.r[5] = 0x1Bu;  // 060560DA mov #27,r5
    c.r[1] = ld32(0x06056194u);  // 060560DC mov.l 0x06056194,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x0605616Cu);  // 060560DE mov.w 0x0605616C,r2
    c.r[12] = (uint32_t)(int16_t)ld16(0x0605616Eu);  // 060560E0 mov.w 0x0605616E,r12
    c.r[12] += c.r[14];  // 060560E2 add r14,r12
    c.r[1] = ld32(c.r[1]);  // 060560E4 mov.l @r1,r1
    c.r[9] = ld32(0x06056198u);  // 060560E6 mov.l 0x06056198,r9
    c.r[0] = c.r[1];  // 060560E8 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 060560EA mov.b @(r0,r2),r1
    c.r[13] = c.r[1];  // 060560EC mov r1,r13
    c.t = c.r[13] & 1; c.r[13] >>= 1;  // 060560EE shlr r13
    st32(c.r[12], c.r[13]);  // 060560F0 mov.l r13,@r12
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605616Eu);  // 060560F2 mov.w 0x0605616E,r0
    c.r[0] += c.r[14];  // 060560F4 add r14,r0
    c.r[12] = (uint32_t)(int16_t)ld16(0x0605616Eu);  // 060560F6 mov.w 0x0605616E,r12
    c.r[12] += c.r[14];  // 060560F8 add r14,r12
    c.r[1] = ld32(0x06056180u);  // 060560FA mov.l 0x06056180,r1
    c.r[0] = ld32(c.r[0]);  // 060560FC mov.l @r0,r0
    c.r[2] = c.r[10];  // 060560FE mov r10,r2
    c.r[0] &= 0xFu;  // 06056100 and #15,r0
    st32(c.r[12], c.r[0]);  // 06056102 mov.l r0,@r12
    c.r[1] = ld32(c.r[1]);  // 06056104 mov.l @r1,r1
    c.r[2] <<= 2;  // 06056106 shll2 r2
    c.r[2] <<= 2;  // 06056108 shll2 r2
    c.r[2] += c.r[1];  // 0605610A add r1,r2
    c.r[2] += 2;  // 0605610C add #2,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605610E mov.b @r2,r2
    c.r[1] = ld32(0x0605619Cu);  // 06056110 mov.l 0x0605619C,r1
    c.r[3] = ld32(c.r[1]);  // 06056112 mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06056114 extu.b r2,r2
    c.r[1] = 0x1Eu;  // 06056116 mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 06056118 mul.l r1,r2
    c.r[4] = ld32(0x060561A0u);  // 0605611A mov.l 0x060561A0,r4
    c.r[12] = (uint32_t)(int16_t)ld16(0x06056170u);  // 0605611C mov.w 0x06056170,r12
    c.r[1] = c.macl;  // 0605611E sts macl,r1
    c.r[0] = c.r[1];  // 06056120 mov r1,r0
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 06056122 mov.w @(r0,r3),r8
    c.r[12] += c.r[14];  // 06056124 add r14,r12
    c.r[8] = c.r[8] & 0xFFFFu;  // 06056126 extu.w r8,r8
    { const uint32_t x = c.r[9]; c.pr = 0x0605612Cu; st32(c.r[12], c.r[6]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605612Cu) return; }  // 06056128 jsr @r9 ; mov.l r6,@r12
    c.r[1] = c.r[0];  // 0605612C mov r0,r1
    c.r[5] = c.r[8];  // 0605612E mov r8,r5
    { const uint32_t x = c.r[9]; c.pr = 0x06056134u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06056134u) return; }  // 06056130 jsr @r9 ; mov r1,r4
    c.r[1] = c.r[0];  // 06056134 mov r0,r1
    c.r[1] += 7;  // 06056136 add #7,r1
    c.r[2] = 0x78u;  // 06056138 mov #120,r2
    c.r[13] = (uint32_t)(int16_t)ld16(0x06056172u);  // 0605613A mov.w 0x06056172,r13
    c.r[13] += c.r[14];  // 0605613C add r14,r13
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605613E mov.b @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06056170u);  // 06056140 mov.w 0x06056170,r0
    c.r[13] = (uint32_t)(int8_t)ld8(c.r[13]);  // 06056142 mov.b @r13,r13
    c.r[6] = ld32(c.r[0] + c.r[14]);  // 06056144 mov.l @(r0,r14),r6
    c.r[2] &= c.r[1];  // 06056146 and r1,r2
    c.r[1] = c.r[13] & 0xFFu;  // 06056148 extu.b r13,r1
    c.r[2] >>= 2;  // 0605614A shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 0605614C shlr r2
    c.t = c.r[1] == c.r[2]; goto L_060561A4;  // 0605614E bra 0x060561A4 ; cmp/eq r2,r1
L_060561A4:
    if (!c.t) { goto L_0605622E; }  // 060561A4 bf 0x0605622E
    c.r[7] = 0x0u;  // 060561A6 mov #0,r7
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[6];  // 060561A8 cmp/ge r6,r7
    { const bool k = c.t; c.t = c.r[7] == c.r[6]; if (k) { goto L_060561D4; } }  // 060561AA bt/s 0x060561D4 ; cmp/eq r6,r7
    c.r[2] = 0x0u;  // 060561AE mov #0,r2
L_060561B0:
    c.r[0] = c.r[2];  // 060561B0 mov r2,r0
    c.r[3] = 0x7Fu;  // 060561B2 mov #127,r3
    c.r[12] = (uint32_t)(int16_t)ld16(0x06056324u);  // 060561B4 mov.w 0x06056324,r12
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 060561B6 mov.b @(r0,r14),r1
    c.r[12] += c.r[14];  // 060561B8 add r14,r12
    c.r[0] = ld32(c.r[12]);  // 060561BA mov.l @r12,r0
    c.r[3] &= c.r[1];  // 060561BC and r1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 060561BE mov.b @(r0,r2),r1
    c.r[3] <<= 8;  // 060561C0 shll8 r3
    c.r[1] = c.r[1] & 0xFFu;  // 060561C2 extu.b r1,r1
    c.r[1] |= c.r[3];  // 060561C4 or r3,r1
    c.t = c.r[1] == c.r[10];  // 060561C6 cmp/eq r10,r1
    if (c.t) { goto L_060561D2; }  // 060561C8 bt 0x060561D2
    c.r[7] += 1;  // 060561CA add #1,r7
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[6];  // 060561CC cmp/ge r6,r7
    { const bool k = !c.t; c.r[2] += 2; if (k) { SH2_POLL(c); goto L_060561B0; } }  // 060561CE bf/s 0x060561B0 ; add #2,r2
L_060561D2:
    c.t = c.r[7] == c.r[6];  // 060561D2 cmp/eq r6,r7
L_060561D4:
    { const bool k = !c.t; c.r[1] = c.r[7]; if (k) { goto L_0605622E; } }  // 060561D4 bf/s 0x0605622E ; mov r7,r1
    c.r[13] = (uint32_t)(int16_t)ld16(0x06056326u);  // 060561D8 mov.w 0x06056326,r13
    c.r[13] += c.r[14];  // 060561DA add r14,r13
    c.r[0] = ld32(c.r[13]);  // 060561DC mov.l @r13,r0
    c.r[0] <<= 8;  // 060561DE shll8 r0
    st32(c.r[13], c.r[0]);  // 060561E0 mov.l r0,@r13
    c.r[12] = (uint32_t)(int16_t)ld16(0x06056326u);  // 060561E2 mov.w 0x06056326,r12
    c.r[12] += c.r[14];  // 060561E4 add r14,r12
    c.r[1] += 1;  // 060561E6 add #1,r1
    c.r[13] = ld32(c.r[12]);  // 060561E8 mov.l @r12,r13
    c.r[6] = c.r[1] & 0xFFu;  // 060561EA extu.b r1,r6
    c.r[12] = (uint32_t)(int16_t)ld16(0x06056328u);  // 060561EC mov.w 0x06056328,r12
    c.r[12] += c.r[14];  // 060561EE add r14,r12
    c.r[12] = ld32(c.r[12]);  // 060561F0 mov.l @r12,r12
    c.r[2] = c.r[7];  // 060561F2 mov r7,r2
    c.r[13] |= c.r[12];  // 060561F4 or r12,r13
    c.r[12] = (uint32_t)(int16_t)ld16(0x06056326u);  // 060561F6 mov.w 0x06056326,r12
    c.r[12] += c.r[14];  // 060561F8 add r14,r12
    st32(c.r[12], c.r[13]);  // 060561FA mov.l r13,@r12
    c.r[13] = (uint32_t)(int16_t)ld16(0x0605632Au);  // 060561FC mov.w 0x0605632A,r13
    c.r[13] += c.r[14];  // 060561FE add r14,r13
    c.r[12] = (uint32_t)(int16_t)ld16(c.r[13]);  // 06056200 mov.w @r13,r12
    c.r[2] += c.r[2];  // 06056202 add r2,r2
    c.r[13] = (uint32_t)(int16_t)ld16(0x0605632Cu);  // 06056204 mov.w 0x0605632C,r13
    c.r[13] += c.r[14];  // 06056206 add r14,r13
    c.r[0] = ld32(c.r[13]);  // 06056208 mov.l @r13,r0
    c.r[1] = c.r[10];  // 0605620A mov r10,r1
    st16(c.r[0], c.r[12]);  // 0605620C mov.w r12,@r0
    c.r[13] = (uint32_t)(int16_t)ld16(0x0605632Cu);  // 0605620E mov.w 0x0605632C,r13
    c.r[13] += c.r[14];  // 06056210 add r14,r13
    c.r[0] = ld32(c.r[13]);  // 06056212 mov.l @r13,r0
    c.r[1] >>= 8;  // 06056214 shlr8 r1
    c.r[0] += 2;  // 06056216 add #2,r0
    st32(c.r[13], c.r[0]);  // 06056218 mov.l r0,@r13
    c.r[0] = c.r[14];  // 0605621A mov r14,r0
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0605621C mov.b @(r0,r2),r3
    c.r[12] = (uint32_t)(int16_t)ld16(0x0605632Eu);  // 0605621E mov.w 0x0605632E,r12
    c.r[3] &= c.r[12];  // 06056220 and r12,r3
    c.r[3] |= c.r[1];  // 06056222 or r1,r3
    st8(c.r[0] + c.r[2], c.r[3]);  // 06056224 mov.b r3,@(r0,r2)
    c.r[12] = (uint32_t)(int16_t)ld16(0x06056324u);  // 06056226 mov.w 0x06056324,r12
    c.r[12] += c.r[14];  // 06056228 add r14,r12
    c.r[0] = ld32(c.r[12]);  // 0605622A mov.l @r12,r0
    st8(c.r[0] + c.r[2], c.r[10]);  // 0605622C mov.b r10,@(r0,r2)
L_0605622E:
    c.r[11] += 1;  // 0605622E add #1,r11
    c.r[1] = 0x7u;  // 06056230 mov #7,r1
    c.t = (int32_t)c.r[11] > (int32_t)c.r[1];  // 06056232 cmp/gt r1,r11
    if (c.t) { goto L_0605623A; }  // 06056234 bt 0x0605623A
    SH2_POLL(c); goto L_06056046;  // 06056236 bra 0x06056046 ; nop
L_0605623A:
    c.r[13] = (uint32_t)(int16_t)ld16(0x06056330u);  // 0605623A mov.w 0x06056330,r13
    c.r[13] += c.r[14];  // 0605623C add r14,r13
    c.r[0] = ld32(c.r[13]);  // 0605623E mov.l @r13,r0
    c.r[12] = (uint32_t)(int16_t)ld16(0x06056332u);  // 06056240 mov.w 0x06056332,r12
    c.r[12] += c.r[14];  // 06056242 add r14,r12
    c.r[13] = (uint32_t)(int16_t)ld16(0x06056334u);  // 06056244 mov.w 0x06056334,r13
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06056246 mov.b @r0,r1
    c.r[13] += c.r[14];  // 06056248 add r14,r13
    c.r[1] = c.r[1] & 0xFFu;  // 0605624A extu.b r1,r1
    st32(c.r[12], c.r[1]);  // 0605624C mov.l r1,@r12
    c.r[12] = (uint32_t)(int16_t)ld16(0x06056336u);  // 0605624E mov.w 0x06056336,r12
    c.r[0] = ld32(c.r[13]);  // 06056250 mov.l @r13,r0
    c.r[12] += c.r[14];  // 06056252 add r14,r12
    c.r[0] += 2;  // 06056254 add #2,r0
    st32(c.r[13], c.r[0]);  // 06056256 mov.l r0,@r13
    c.r[0] -= 2;  // 06056258 add #-2,r0
    c.r[13] = (uint32_t)(int16_t)ld16(0x06056330u);  // 0605625A mov.w 0x06056330,r13
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0]);  // 0605625C mov.w @r0,r1
    c.r[13] += c.r[14];  // 0605625E add r14,r13
    c.r[1] >>= 8;  // 06056260 shlr8 r1
    c.r[1] = c.r[1] & 0xFFu;  // 06056262 extu.b r1,r1
    st32(c.r[12], c.r[1]);  // 06056264 mov.l r1,@r12
    c.r[12] = (uint32_t)(int16_t)ld16(0x0605632Cu);  // 06056266 mov.w 0x0605632C,r12
    c.r[0] = ld32(c.r[13]);  // 06056268 mov.l @r13,r0
    c.r[12] += c.r[14];  // 0605626A add r14,r12
    c.r[0] += 2;  // 0605626C add #2,r0
    st32(c.r[13], c.r[0]);  // 0605626E mov.l r0,@r13
    c.r[0] = (uint32_t)(int16_t)ld16(0x06056334u);  // 06056270 mov.w 0x06056334,r0
    c.r[1] = ld32(c.r[12]);  // 06056272 mov.l @r12,r1
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06056274 mov.l @(r0,r14),r0
    c.r[1] += 2;  // 06056276 add #2,r1
    c.t = c.r[0] == c.r[1];  // 06056278 cmp/eq r1,r0
    { const bool k = c.t; c.r[11] = 0x0u; if (k) { goto L_06056282; } }  // 0605627A bt/s 0x06056282 ; mov #0,r11
    SH2_POLL(c); goto L_06056046;  // 0605627E bra 0x06056046 ; nop
L_06056282:
    c.r[12] = (uint32_t)(int16_t)ld16(0x06056338u);  // 06056282 mov.w 0x06056338,r12
    c.r[12] += c.r[14];  // 06056284 add r14,r12
    c.r[12] = ld32(c.r[12]);  // 06056286 mov.l @r12,r12
    c.t = (int32_t)c.r[11] >= (int32_t)c.r[12];  // 06056288 cmp/ge r12,r11
    if (c.t) { goto L_060562B6; }  // 0605628A bt 0x060562B6
    c.r[3] = c.r[14];  // 0605628C mov r14,r3
    c.r[3] += 1;  // 0605628E add #1,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x0605633Au);  // 06056290 mov.w 0x0605633A,r7
    c.r[2] = 0x0u;  // 06056292 mov #0,r2
L_06056294:
    c.r[0] = c.r[2];  // 06056294 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 06056296 mov.b @(r0,r14),r1
    c.r[6] = 0x7Fu;  // 06056298 mov #127,r6
    c.r[6] &= c.r[1];  // 0605629A and r1,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0605629C mov.b @(r0,r3),r1
    c.r[6] <<= 8;  // 0605629E shll8 r6
    c.r[1] = c.r[1] & 0xFFu;  // 060562A0 extu.b r1,r1
    c.r[1] |= c.r[6];  // 060562A2 or r6,r1
    c.t = c.r[1] == c.r[7];  // 060562A4 cmp/eq r7,r1
    if (c.t) { goto L_060562B6; }  // 060562A6 bt 0x060562B6
    c.r[11] += 1;  // 060562A8 add #1,r11
    c.r[12] = (uint32_t)(int16_t)ld16(0x06056338u);  // 060562AA mov.w 0x06056338,r12
    c.r[12] += c.r[14];  // 060562AC add r14,r12
    c.r[12] = ld32(c.r[12]);  // 060562AE mov.l @r12,r12
    c.t = (int32_t)c.r[11] >= (int32_t)c.r[12];  // 060562B0 cmp/ge r12,r11
    { const bool k = !c.t; c.r[2] += 2; if (k) { SH2_POLL(c); goto L_06056294; } }  // 060562B2 bf/s 0x06056294 ; add #2,r2
L_060562B6:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06056338u);  // 060562B6 mov.w 0x06056338,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 060562B8 mov.l @(r0,r14),r0
    c.t = c.r[0] == c.r[11];  // 060562BA cmp/eq r11,r0
    { const bool k = c.t; c.r[11] = 0x0u; if (k) { goto L_060562C4; } }  // 060562BC bt/s 0x060562C4 ; mov #0,r11
    goto L_060563EE;  // 060562C0 bra 0x060563EE ; nop
L_060562C4:
    c.r[12] = (uint32_t)(int16_t)ld16(0x06056338u);  // 060562C4 mov.w 0x06056338,r12
    c.r[12] += c.r[14];  // 060562C6 add r14,r12
    c.r[0] = (uint32_t)(int16_t)ld16(0x06056338u);  // 060562C8 mov.w 0x06056338,r0
    c.r[13] = ld32(c.r[12]);  // 060562CA mov.l @r12,r13
    c.r[0] += c.r[14];  // 060562CC add r14,r0
    c.r[12] = (uint32_t)(int16_t)ld16(0x0605633Cu);  // 060562CE mov.w 0x0605633C,r12
    c.r[12] += c.r[14];  // 060562D0 add r14,r12
    st32(c.r[12], c.r[13]);  // 060562D2 mov.l r13,@r12
    c.r[1] = ld32(c.r[0]);  // 060562D4 mov.l @r0,r1
    c.r[1] -= 1;  // 060562D6 add #-1,r1
    c.t = (int32_t)c.r[11] >= (int32_t)c.r[1];  // 060562D8 cmp/ge r1,r11
    { const bool k = !c.t; c.r[13] = 0x1u; if (k) { goto L_060562E2; } }  // 060562DA bf/s 0x060562E2 ; mov #1,r13
    goto L_060563E6;  // 060562DE bra 0x060563E6 ; nop
L_060562E2:
    c.r[13] = c.r[14];  // 060562E2 mov r14,r13
    c.r[13] += 1;  // 060562E4 add #1,r13
    c.r[12] = (uint32_t)(int16_t)ld16(0x06056328u);  // 060562E6 mov.w 0x06056328,r12
    c.r[12] += c.r[14];  // 060562E8 add r14,r12
    st32(c.r[12], c.r[13]);  // 060562EA mov.l r13,@r12
    c.r[7] = c.r[11];  // 060562EC mov r11,r7
L_060562EE:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06056338u);  // 060562EE mov.w 0x06056338,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 060562F0 mov.l @(r0,r14),r0
    c.r[7] += 1;  // 060562F2 add #1,r7
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[0];  // 060562F4 cmp/ge r0,r7
    if (c.t) { goto L_060563D6; }  // 060562F6 bt 0x060563D6
    c.r[9] = c.r[11];  // 060562F8 mov r11,r9
    c.r[9] += c.r[9];  // 060562FA add r9,r9
    c.r[5] = c.r[7];  // 060562FC mov r7,r5
    c.r[5] += c.r[5];  // 060562FE add r5,r5
L_06056300:
    c.r[0] = c.r[14];  // 06056300 mov r14,r0
    c.r[2] = 0x7Fu;  // 06056302 mov #127,r2
    c.r[13] = (uint32_t)(int16_t)ld16(0x0605633Eu);  // 06056304 mov.w 0x0605633E,r13
    c.r[13] += c.r[14];  // 06056306 add r14,r13
    c.r[12] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 06056308 mov.b @(r0,r9),r12
    c.r[10] = 0x7Fu;  // 0605630A mov #127,r10
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605633Eu);  // 0605630C mov.w 0x0605633E,r0
    st8(c.r[0] + c.r[14], c.r[12]);  // 0605630E mov.b r12,@(r0,r14)
    c.r[12] = (uint32_t)(int16_t)ld16(0x06056328u);  // 06056310 mov.w 0x06056328,r12
    c.r[13] = (uint32_t)(int8_t)ld8(c.r[13]);  // 06056312 mov.b @r13,r13
    c.r[12] += c.r[14];  // 06056314 add r14,r12
    c.r[0] = ld32(c.r[12]);  // 06056316 mov.l @r12,r0
    c.r[2] &= c.r[13];  // 06056318 and r13,r2
    c.r[2] <<= 8;  // 0605631A shll8 r2
    c.r[13] = 0x1Eu;  // 0605631C mov #30,r13
    c.r[12] = (uint32_t)(int16_t)ld16(0x06056328u);  // 0605631E mov.w 0x06056328,r12
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]); goto L_06056340;  // 06056320 bra 0x06056340 ; mov.b @(r0,r9),r1
L_06056340:
    c.r[12] += c.r[14];  // 06056340 add r14,r12
    c.r[8] = c.r[1] & 0xFFu;  // 06056342 extu.b r1,r8
    c.r[1] = ld32(0x0605647Cu);  // 06056344 mov.l 0x0605647C,r1
    c.r[3] = ld32(c.r[1]);  // 06056346 mov.l @r1,r3
    c.r[8] |= c.r[2];  // 06056348 or r2,r8
    c.r[1] = c.r[8];  // 0605634A mov r8,r1
    c.r[1] <<= 2;  // 0605634C shll2 r1
    c.r[1] <<= 2;  // 0605634E shll2 r1
    c.r[1] += c.r[3];  // 06056350 add r3,r1
    c.r[1] += 2;  // 06056352 add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06056354 mov.b @r1,r2
    c.r[0] = c.r[5];  // 06056356 mov r5,r0
    c.r[1] = ld32(0x06056480u);  // 06056358 mov.l 0x06056480,r1
    c.r[4] = ld32(c.r[1]);  // 0605635A mov.l @r1,r4
    c.r[2] = c.r[2] & 0xFFu;  // 0605635C extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 0605635E mov.b @(r0,r14),r1
    c.macl = c.r[2] * c.r[13];  // 06056360 mul.l r13,r2
    c.r[0] = ld32(c.r[12]);  // 06056362 mov.l @r12,r0
    c.r[10] &= c.r[1];  // 06056364 and r1,r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 06056366 mov.b @(r0,r5),r1
    c.r[10] <<= 8;  // 06056368 shll8 r10
    c.r[6] = c.r[1] & 0xFFu;  // 0605636A extu.b r1,r6
    c.r[6] |= c.r[10];  // 0605636C or r10,r6
    c.r[1] = c.r[6];  // 0605636E mov r6,r1
    c.r[1] <<= 2;  // 06056370 shll2 r1
    c.r[1] <<= 2;  // 06056372 shll2 r1
    c.r[1] += c.r[3];  // 06056374 add r3,r1
    c.r[1] += 2;  // 06056376 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06056378 mov.b @r1,r1
    c.r[2] = c.macl;  // 0605637A sts macl,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0605637C extu.b r1,r1
    c.macl = c.r[1] * c.r[13];  // 0605637E mul.l r13,r1
    c.r[0] = c.r[2];  // 06056380 mov r2,r0
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[4]);  // 06056382 mov.w @(r0,r4),r2
    c.r[1] = c.macl;  // 06056384 sts macl,r1
    c.r[0] = c.r[1];  // 06056386 mov r1,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[4]);  // 06056388 mov.w @(r0,r4),r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 0605638A extu.w r2,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 0605638C extu.w r1,r1
    c.t = c.r[2] > c.r[1];  // 0605638E cmp/hi r1,r2
    if (!c.t) { goto L_060563C8; }  // 06056390 bf 0x060563C8
    c.r[10] = c.r[8];  // 06056392 mov r8,r10
    c.r[1] = c.r[6];  // 06056394 mov r6,r1
    c.r[1] >>= 8;  // 06056396 shlr8 r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x0605646Cu);  // 06056398 mov.w 0x0605646C,r12
    c.r[12] += c.r[14];  // 0605639A add r14,r12
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[12]);  // 0605639C mov.b @r12,r2
    c.r[0] = c.r[14];  // 0605639E mov r14,r0
    c.r[12] = (uint32_t)(int16_t)ld16(0x0605646Eu);  // 060563A0 mov.w 0x0605646E,r12
    c.r[2] &= c.r[12];  // 060563A2 and r12,r2
    c.r[2] |= c.r[1];  // 060563A4 or r1,r2
    st8(c.r[0] + c.r[9], c.r[2]);  // 060563A6 mov.b r2,@(r0,r9)
    c.r[12] = (uint32_t)(int16_t)ld16(0x06056470u);  // 060563A8 mov.w 0x06056470,r12
    c.r[12] += c.r[14];  // 060563AA add r14,r12
    c.r[1] = c.r[10];  // 060563AC mov r10,r1
    c.r[0] = ld32(c.r[12]);  // 060563AE mov.l @r12,r0
    c.r[1] >>= 8;  // 060563B0 shlr8 r1
    st8(c.r[0] + c.r[9], c.r[6]);  // 060563B2 mov.b r6,@(r0,r9)
    c.r[0] = c.r[5];  // 060563B4 mov r5,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 060563B6 mov.b @(r0,r14),r2
    c.r[12] = (uint32_t)(int16_t)ld16(0x0605646Eu);  // 060563B8 mov.w 0x0605646E,r12
    c.r[2] &= c.r[12];  // 060563BA and r12,r2
    c.r[2] |= c.r[1];  // 060563BC or r1,r2
    st8(c.r[0] + c.r[14], c.r[2]);  // 060563BE mov.b r2,@(r0,r14)
    c.r[12] = (uint32_t)(int16_t)ld16(0x06056470u);  // 060563C0 mov.w 0x06056470,r12
    c.r[12] += c.r[14];  // 060563C2 add r14,r12
    c.r[0] = ld32(c.r[12]);  // 060563C4 mov.l @r12,r0
    st8(c.r[0] + c.r[5], c.r[10]);  // 060563C6 mov.b r10,@(r0,r5)
L_060563C8:
    c.r[13] = (uint32_t)(int16_t)ld16(0x06056472u);  // 060563C8 mov.w 0x06056472,r13
    c.r[13] += c.r[14];  // 060563CA add r14,r13
    c.r[13] = ld32(c.r[13]);  // 060563CC mov.l @r13,r13
    c.r[7] += 1;  // 060563CE add #1,r7
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[13];  // 060563D0 cmp/ge r13,r7
    { const bool k = !c.t; c.r[5] += 2; if (k) { SH2_POLL(c); goto L_06056300; } }  // 060563D2 bf/s 0x06056300 ; add #2,r5
L_060563D6:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06056472u);  // 060563D6 mov.w 0x06056472,r0
    c.r[1] = ld32(c.r[0] + c.r[14]);  // 060563D8 mov.l @(r0,r14),r1
    c.r[11] += 1;  // 060563DA add #1,r11
    c.r[1] -= 1;  // 060563DC add #-1,r1
    c.t = (int32_t)c.r[11] >= (int32_t)c.r[1];  // 060563DE cmp/ge r1,r11
    { const bool k = !c.t; c.r[7] = c.r[11]; if (k) { SH2_POLL(c); goto L_060562EE; } }  // 060563E0 bf/s 0x060562EE ; mov r11,r7
    c.r[13] = 0x1u;  // 060563E4 mov #1,r13
L_060563E6:
    c.r[12] = (uint32_t)(int16_t)ld16(0x06056472u);  // 060563E6 mov.w 0x06056472,r12
    c.r[12] += c.r[14];  // 060563E8 add r14,r12
    st32(c.r[12], c.r[13]); goto L_060563F4;  // 060563EA bra 0x060563F4 ; mov.l r13,@r12
L_060563EE:
    c.r[12] = 0x0u;  // 060563EE mov #0,r12
L_060563F0:
    c.r[0] = (uint32_t)(int16_t)ld16(0x06056472u);  // 060563F0 mov.w 0x06056472,r0
    st32(c.r[0] + c.r[14], c.r[12]);  // 060563F2 mov.l r12,@(r0,r14)
L_060563F4:
    c.r[13] = (uint32_t)(int16_t)ld16(0x06056474u);  // 060563F4 mov.w 0x06056474,r13
    c.r[13] += c.r[14];  // 060563F6 add r14,r13
    c.r[13] = ld32(c.r[13]);  // 060563F8 mov.l @r13,r13
    c.t = (c.r[13] & c.r[13]) == 0;  // 060563FA tst r13,r13
    { const bool k = c.t; c.r[1] = (uint32_t)(int8_t)ld8(c.r[14]); if (k) { goto L_0605644E; } }  // 060563FC bt/s 0x0605644E ; mov.b @r14,r1
    c.r[7] = ld32(0x06056484u);  // 06056400 mov.l 0x06056484,r7
    c.r[2] = ld32(c.r[7]);  // 06056402 mov.l @r7,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06056476u);  // 06056404 mov.w 0x06056476,r0
    c.r[0] += c.r[14];  // 06056406 add r14,r0
    st8(c.r[2], c.r[1]);  // 06056408 mov.b r1,@r2
    c.r[1] = c.r[14];  // 0605640A mov r14,r1
    c.r[1] += 1;  // 0605640C add #1,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0605640E mov.b @r1+,r3
    c.r[2] += 1;  // 06056410 add #1,r2
    st8(c.r[2], c.r[3]);  // 06056412 mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 06056414 mov.b @r1+,r3
    c.r[2] += 1;  // 06056416 add #1,r2
    st8(c.r[2], c.r[3]);  // 06056418 mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0605641A mov.b @r1+,r3
    c.r[2] += 1;  // 0605641C add #1,r2
    st8(c.r[2], c.r[3]);  // 0605641E mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 06056420 mov.b @r1+,r3
    c.r[2] += 1;  // 06056422 add #1,r2
    st8(c.r[2], c.r[3]);  // 06056424 mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 06056426 mov.b @r1+,r3
    c.r[2] += 1;  // 06056428 add #1,r2
    st8(c.r[2], c.r[3]);  // 0605642A mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0605642C mov.b @r1+,r3
    c.r[2] += 1;  // 0605642E add #1,r2
    st8(c.r[2], c.r[3]);  // 06056430 mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 06056432 mov.b @r1+,r3
    c.r[2] += 1;  // 06056434 add #1,r2
    st8(c.r[2], c.r[3]);  // 06056436 mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 06056438 mov.b @r1+,r3
    c.r[2] += 1;  // 0605643A add #1,r2
    st8(c.r[2], c.r[3]);  // 0605643C mov.b r3,@r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605643E mov.b @r1,r1
    c.r[2] += 1;  // 06056440 add #1,r2
    st8(c.r[2], c.r[1]);  // 06056442 mov.b r1,@r2
    c.r[1] = ld32(c.r[7]);  // 06056444 mov.l @r7,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06056478u);  // 06056446 mov.w 0x06056478,r2
    c.r[12] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06056448 mov.b @r0,r12
    c.r[0] = c.r[1];  // 0605644A mov r1,r0
    st8(c.r[0] + c.r[2], c.r[12]);  // 0605644C mov.b r12,@(r0,r2)
L_0605644E:
    c.r[13] = (uint32_t)(int16_t)ld16(0x06056472u);  // 0605644E mov.w 0x06056472,r13
    c.r[13] += c.r[14];  // 06056450 add r14,r13
    c.r[0] = ld32(c.r[13]);  // 06056452 mov.l @r13,r0
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605647Au);  // 06056454 mov.w 0x0605647A,r3
    c.r[14] += c.r[3];  // 06056456 add r3,r14
    c.r[15] = c.r[14];  // 06056458 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0605645A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0605645C mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0605645E mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06056460 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06056462 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06056464 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06056466 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06056468 rts ; mov.l @r15+,r8
}

void f_06056488(SH2Context& c) {
    ran[1330] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06056488 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0605648A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0605648C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0605648E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06056490 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06056492 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06056494 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06056496 sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x06056660u);  // 06056498 mov.w 0x06056660,r3
    c.r[15] += c.r[3];  // 0605649A add r3,r15
    c.r[14] = c.r[15];  // 0605649C mov r15,r14
    c.r[9] = 0x0u;  // 0605649E mov #0,r9
    c.r[10] = 0x0u;  // 060564A0 mov #0,r10
    c.r[0] = (uint32_t)(int16_t)ld16(0x06056662u);  // 060564A2 mov.w 0x06056662,r0
    c.r[0] += c.r[14];  // 060564A4 add r14,r0
    st32(c.r[0], c.r[9]);  // 060564A6 mov.l r9,@r0
    st32(c.r[0] + 4, c.r[10]);  // 060564A8 mov.l r10,@(4,r0)
    c.r[12] = 0x0u;  // 060564AA mov #0,r12
    c.r[1] = (uint32_t)(int16_t)ld16(0x06056664u);  // 060564AC mov.w 0x06056664,r1
    c.r[1] += c.r[14];  // 060564AE add r14,r1
    st32(c.r[1], c.r[12]);  // 060564B0 mov.l r12,@r1
    c.r[1] = 0x0u;  // 060564B2 mov #0,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06056666u);  // 060564B4 mov.w 0x06056666,r0
    st32(c.r[0] + c.r[14], c.r[1]);  // 060564B6 mov.l r1,@(r0,r14)
    c.r[3] = ld32(0x06056674u);  // 060564B8 mov.l 0x06056674,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x06056668u);  // 060564BA mov.w 0x06056668,r0
    c.r[2] = ld32(c.r[3]);  // 060564BC mov.l @r3,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605666Au);  // 060564BE mov.w 0x0605666A,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 060564C0 mov.b @(r0,r2),r2
    c.r[1] += c.r[14];  // 060564C2 add r14,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605666Au);  // 060564C4 mov.w 0x0605666A,r0
    c.r[0] += c.r[14];  // 060564C6 add r14,r0
    st8(c.r[0], c.r[2]);  // 060564C8 mov.b r2,@r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060564CA mov.b @r1,r1
    c.r[12] = c.r[1] & 0xFFu;  // 060564CC extu.b r1,r12
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605666Au);  // 060564CE mov.w 0x0605666A,r1
    c.r[1] += c.r[14];  // 060564D0 add r14,r1
    st32(c.r[1], c.r[12]);  // 060564D2 mov.l r12,@r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x0605666Au);  // 060564D4 mov.w 0x0605666A,r12
    c.r[12] += c.r[14];  // 060564D6 add r14,r12
    c.r[12] = ld32(c.r[12]);  // 060564D8 mov.l @r12,r12
    c.r[13] = 0x0u;  // 060564DA mov #0,r13
    c.t = (int32_t)c.r[13] >= (int32_t)c.r[12];  // 060564DC cmp/ge r12,r13
    if (!c.t) { goto L_060564E4; }  // 060564DE bf 0x060564E4
    goto L_060568CE;  // 060564E0 bra 0x060568CE ; nop
L_060564E4:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06056666u);  // 060564E4 mov.w 0x06056666,r1
    c.r[1] += c.r[14];  // 060564E6 add r14,r1
    c.r[12] = ld32(c.r[1]);  // 060564E8 mov.l @r1,r12
    c.r[0] = ld32(0x06056674u);  // 060564EA mov.l 0x06056674,r0
    c.r[2] = ld32(c.r[0]);  // 060564EC mov.l @r0,r2
    c.r[12] += c.r[12];  // 060564EE add r12,r12
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605666Au);  // 060564F0 mov.w 0x0605666A,r1
    c.r[1] += c.r[14];  // 060564F2 add r14,r1
    st32(c.r[1], c.r[12]);  // 060564F4 mov.l r12,@r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605666Au);  // 060564F6 mov.w 0x0605666A,r0
    c.r[0] += c.r[14];  // 060564F8 add r14,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605666Au);  // 060564FA mov.w 0x0605666A,r1
    c.r[1] += c.r[14];  // 060564FC add r14,r1
    c.r[0] = ld32(c.r[0]);  // 060564FE mov.l @r0,r0
    c.r[12] = (uint32_t)(int16_t)ld16(0x0605666Au);  // 06056500 mov.w 0x0605666A,r12
    c.r[2] += c.r[0];  // 06056502 add r0,r2
    c.r[2] += 1;  // 06056504 add #1,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06056506 mov.b @r2,r2
    c.r[12] += c.r[14];  // 06056508 add r14,r12
    st8(c.r[1], c.r[2]);  // 0605650A mov.b r2,@r1
    c.r[12] = (uint32_t)(int8_t)ld8(c.r[12]);  // 0605650C mov.b @r12,r12
    c.r[6] = (uint32_t)(int16_t)ld16(0x0605666Cu);  // 0605650E mov.w 0x0605666C,r6
    c.r[0] = c.r[12] & 0xFFu;  // 06056510 extu.b r12,r0
    c.r[12] = (uint32_t)(int16_t)ld16(0x0605666Eu);  // 06056512 mov.w 0x0605666E,r12
    c.r[12] += c.r[14];  // 06056514 add r14,r12
    st32(c.r[12], c.r[0]);  // 06056516 mov.l r0,@r12
    c.r[0] = ld32(0x06056678u);  // 06056518 mov.l 0x06056678,r0
    c.r[12] = (uint32_t)(int16_t)ld16(0x0605666Eu);  // 0605651A mov.w 0x0605666E,r12
    c.r[1] = ld32(c.r[0]);  // 0605651C mov.l @r0,r1
    c.r[12] += c.r[14];  // 0605651E add r14,r12
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605666Au);  // 06056520 mov.w 0x0605666A,r0
    st32(c.r[0] + c.r[14], c.r[1]);  // 06056522 mov.l r1,@(r0,r14)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605666Au);  // 06056524 mov.w 0x0605666A,r0
    c.r[8] = ld32(c.r[12]);  // 06056526 mov.l @r12,r8
    c.r[0] += c.r[14];  // 06056528 add r14,r0
    c.r[1] = ld32(c.r[0]);  // 0605652A mov.l @r0,r1
    c.r[8] <<= 2;  // 0605652C shll2 r8
    c.r[8] <<= 2;  // 0605652E shll2 r8
    c.r[1] += c.r[8];  // 06056530 add r8,r1
    st32(c.r[0], c.r[1]);  // 06056532 mov.l r1,@r0
    c.r[12] = (uint32_t)(int16_t)ld16(0x0605666Au);  // 06056534 mov.w 0x0605666A,r12
    c.r[12] += c.r[14];  // 06056536 add r14,r12
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605666Au);  // 06056538 mov.w 0x0605666A,r1
    c.r[0] = ld32(c.r[12]);  // 0605653A mov.l @r12,r0
    c.r[1] += c.r[14];  // 0605653C add r14,r1
    c.r[0] += 2;  // 0605653E add #2,r0
    st32(c.r[12], c.r[0]);  // 06056540 mov.l r0,@r12
    c.r[12] = ld32(c.r[1]);  // 06056542 mov.l @r1,r12
    c.r[4] = c.r[14];  // 06056544 mov r14,r4
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[12]);  // 06056546 mov.b @r12,r5
    c.r[0] = ld32(0x0605667Cu);  // 06056548 mov.l 0x0605667C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0605654Eu; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605654Eu) return; }  // 0605654A jsr @r0 ; extu.b r5,r5
    c.r[12] = c.r[14];  // 0605654E mov r14,r12
    c.r[12] += 22;  // 06056550 add #22,r12
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605666Au);  // 06056552 mov.w 0x0605666A,r1
    c.r[1] += c.r[14];  // 06056554 add r14,r1
    st32(c.r[1], c.r[12]);  // 06056556 mov.l r12,@r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605666Au);  // 06056558 mov.w 0x0605666A,r0
    c.r[0] += c.r[14];  // 0605655A add r14,r0
    c.r[1] = ld32(c.r[0]);  // 0605655C mov.l @r0,r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x0605666Au);  // 0605655E mov.w 0x0605666A,r12
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06056560 mov.w @r1,r1
    c.r[12] += c.r[14];  // 06056562 add r14,r12
    st16(c.r[0], c.r[1]);  // 06056564 mov.w r1,@r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605666Au);  // 06056566 mov.w 0x0605666A,r1
    c.r[12] = (uint32_t)(int16_t)ld16(c.r[12]);  // 06056568 mov.w @r12,r12
    c.r[1] += c.r[14];  // 0605656A add r14,r1
    c.r[0] = c.r[12] & 0xFFFFu;  // 0605656C extu.w r12,r0
    c.r[12] = (uint32_t)(int16_t)ld16(0x0605666Au);  // 0605656E mov.w 0x0605666A,r12
    c.r[12] += c.r[14];  // 06056570 add r14,r12
    st32(c.r[12], c.r[0]);  // 06056572 mov.l r0,@r12
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605666Au);  // 06056574 mov.w 0x0605666A,r0
    c.r[0] += c.r[14];  // 06056576 add r14,r0
    c.r[12] = c.r[14];  // 06056578 mov r14,r12
    c.r[0] = ld32(c.r[0]);  // 0605657A mov.l @r0,r0
    c.r[12] += 26;  // 0605657C add #26,r12
    c.r[9] += c.r[0];  // 0605657E add r0,r9
    st32(c.r[1], c.r[12]);  // 06056580 mov.l r12,@r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605666Au);  // 06056582 mov.w 0x0605666A,r0
    c.r[0] += c.r[14];  // 06056584 add r14,r0
    c.r[1] = ld32(c.r[0]);  // 06056586 mov.l @r0,r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x0605666Au);  // 06056588 mov.w 0x0605666A,r12
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0605658A mov.w @r1,r1
    c.r[12] += c.r[14];  // 0605658C add r14,r12
    st16(c.r[0], c.r[1]);  // 0605658E mov.w r1,@r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605666Au);  // 06056590 mov.w 0x0605666A,r1
    c.r[12] = (uint32_t)(int16_t)ld16(c.r[12]);  // 06056592 mov.w @r12,r12
    c.r[1] += c.r[14];  // 06056594 add r14,r1
    c.r[0] = c.r[12] & 0xFFFFu;  // 06056596 extu.w r12,r0
    c.r[12] = (uint32_t)(int16_t)ld16(0x0605666Au);  // 06056598 mov.w 0x0605666A,r12
    c.r[12] += c.r[14];  // 0605659A add r14,r12
    st32(c.r[12], c.r[0]);  // 0605659C mov.l r0,@r12
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605666Au);  // 0605659E mov.w 0x0605666A,r0
    c.r[0] += c.r[14];  // 060565A0 add r14,r0
    c.r[12] = c.r[14];  // 060565A2 mov r14,r12
    c.r[0] = ld32(c.r[0]);  // 060565A4 mov.l @r0,r0
    c.r[12] += 24;  // 060565A6 add #24,r12
    c.r[10] += c.r[0];  // 060565A8 add r0,r10
    st32(c.r[1], c.r[12]);  // 060565AA mov.l r12,@r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605666Au);  // 060565AC mov.w 0x0605666A,r0
    c.r[0] += c.r[14];  // 060565AE add r14,r0
    c.r[1] = ld32(c.r[0]);  // 060565B0 mov.l @r0,r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x0605666Au);  // 060565B2 mov.w 0x0605666A,r12
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060565B4 mov.w @r1,r1
    c.r[12] += c.r[14];  // 060565B6 add r14,r12
    st16(c.r[0], c.r[1]);  // 060565B8 mov.w r1,@r0
    c.r[12] = (uint32_t)(int16_t)ld16(c.r[12]);  // 060565BA mov.w @r12,r12
    c.r[0] = c.r[12] & 0xFFFFu;  // 060565BC extu.w r12,r0
    c.r[12] = (uint32_t)(int16_t)ld16(0x0605666Au);  // 060565BE mov.w 0x0605666A,r12
    c.r[12] += c.r[14];  // 060565C0 add r14,r12
    st32(c.r[12], c.r[0]);  // 060565C2 mov.l r0,@r12
    c.r[0] = (uint32_t)(int16_t)ld16(0x06056662u);  // 060565C4 mov.w 0x06056662,r0
    c.r[1] = ld32(c.r[0] + c.r[14]);  // 060565C6 mov.l @(r0,r14),r1
    c.r[12] = c.r[14];  // 060565C8 mov r14,r12
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605666Au);  // 060565CA mov.w 0x0605666A,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 060565CC mov.l @(r0,r14),r0
    c.r[12] += 28;  // 060565CE add #28,r12
    c.r[1] += c.r[0];  // 060565D0 add r0,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06056662u);  // 060565D2 mov.w 0x06056662,r0
    st32(c.r[0] + c.r[14], c.r[1]);  // 060565D4 mov.l r1,@(r0,r14)
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605666Au);  // 060565D6 mov.w 0x0605666A,r1
    c.r[1] += c.r[14];  // 060565D8 add r14,r1
    st32(c.r[1], c.r[12]);  // 060565DA mov.l r12,@r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605666Au);  // 060565DC mov.w 0x0605666A,r0
    c.r[0] += c.r[14];  // 060565DE add r14,r0
    c.r[1] = ld32(c.r[0]);  // 060565E0 mov.l @r0,r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x0605666Au);  // 060565E2 mov.w 0x0605666A,r12
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060565E4 mov.w @r1,r1
    c.r[12] += c.r[14];  // 060565E6 add r14,r12
    st16(c.r[0], c.r[1]);  // 060565E8 mov.w r1,@r0
    c.r[12] = (uint32_t)(int16_t)ld16(c.r[12]);  // 060565EA mov.w @r12,r12
    c.r[0] = c.r[12] & 0xFFFFu;  // 060565EC extu.w r12,r0
    c.r[12] = (uint32_t)(int16_t)ld16(0x0605666Au);  // 060565EE mov.w 0x0605666A,r12
    c.r[12] += c.r[14];  // 060565F0 add r14,r12
    st32(c.r[12], c.r[0]);  // 060565F2 mov.l r0,@r12
    c.r[0] = (uint32_t)(int16_t)ld16(0x06056670u);  // 060565F4 mov.w 0x06056670,r0
    c.r[1] = ld32(c.r[0] + c.r[14]);  // 060565F6 mov.l @(r0,r14),r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605666Au);  // 060565F8 mov.w 0x0605666A,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 060565FA mov.l @(r0,r14),r0
    c.r[1] += c.r[0];  // 060565FC add r0,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06056670u);  // 060565FE mov.w 0x06056670,r0
    st32(c.r[0] + c.r[14], c.r[1]);  // 06056600 mov.l r1,@(r0,r14)
    c.r[1] = (uint32_t)(int16_t)ld16(0x06056666u);  // 06056602 mov.w 0x06056666,r1
    c.r[1] += c.r[14];  // 06056604 add r14,r1
    c.r[1] = ld32(c.r[1]);  // 06056606 mov.l @r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06056608 tst r1,r1
    { const bool k = c.t; c.r[7] = 0x0u; if (k) { goto L_06056612; } }  // 0605660A bt/s 0x06056612 ; mov #0,r7
    goto L_06056744;  // 0605660E bra 0x06056744 ; nop
L_06056612:
    c.r[12] = (uint32_t)(int16_t)ld16(0x0605666Eu);  // 06056612 mov.w 0x0605666E,r12
    c.r[12] += c.r[14];  // 06056614 add r14,r12
    c.r[1] = ld32(0x06056678u);  // 06056616 mov.l 0x06056678,r1
    c.r[3] = 0x7Fu;  // 06056618 mov #127,r3
    c.r[0] = ld32(c.r[12]);  // 0605661A mov.l @r12,r0
    c.r[5] = 0x1Eu;  // 0605661C mov #30,r5
    c.r[12] = (uint32_t)(int16_t)ld16(0x06056664u);  // 0605661E mov.w 0x06056664,r12
    c.r[12] += c.r[14];  // 06056620 add r14,r12
    st32(c.r[12], c.r[0]);  // 06056622 mov.l r0,@r12
    c.r[0] = (uint32_t)(int16_t)ld16(0x06056672u);  // 06056624 mov.w 0x06056672,r0
    c.r[12] = ld32(c.r[1]);  // 06056626 mov.l @r1,r12
    c.r[0] += c.r[14];  // 06056628 add r14,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06056672u);  // 0605662A mov.w 0x06056672,r1
    c.r[1] += c.r[14];  // 0605662C add r14,r1
    st32(c.r[1], c.r[12]);  // 0605662E mov.l r12,@r1
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605666Au);  // 06056630 mov.w 0x0605666A,r1
    c.r[1] += c.r[14];  // 06056632 add r14,r1
    c.r[0] = ld32(c.r[0]);  // 06056634 mov.l @r0,r0
    c.r[12] = (uint32_t)(int16_t)ld16(0x0605666Au);  // 06056636 mov.w 0x0605666A,r12
    c.r[8] += c.r[0];  // 06056638 add r0,r8
    c.r[8] += 2;  // 0605663A add #2,r8
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0605663C mov.b @r8,r8
    c.r[12] += c.r[14];  // 0605663E add r14,r12
    st8(c.r[1], c.r[8]);  // 06056640 mov.b r8,@r1
    c.r[12] = (uint32_t)(int8_t)ld8(c.r[12]);  // 06056642 mov.b @r12,r12
    c.r[0] = ld32(0x06056680u);  // 06056644 mov.l 0x06056680,r0
    c.r[6] = ld32(c.r[0]);  // 06056646 mov.l @r0,r6
    c.r[13] = c.r[12] & 0xFFu;  // 06056648 extu.b r12,r13
    c.r[2] = c.r[6];  // 0605664A mov r6,r2
    c.r[1] = c.r[2];  // 0605664C mov r2,r1
L_0605664E:
    c.r[1] += 16;  // 0605664E add #16,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06056650 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06056652 extu.b r1,r1
    c.t = c.r[1] == c.r[13];  // 06056654 cmp/eq r13,r1
    { const bool k = c.t; c.r[2] += 30; if (k) { goto L_06056688; } }  // 06056656 bt/s 0x06056688 ; add #30,r2
    c.r[7] += 1;  // 0605665A add #1,r7
    c.t = (int32_t)c.r[7] > (int32_t)c.r[3]; goto L_06056684;  // 0605665C bra 0x06056684 ; cmp/gt r3,r7
L_06056684:
    { const bool k = !c.t; c.r[1] = c.r[2]; if (k) { SH2_POLL(c); goto L_0605664E; } }  // 06056684 bf/s 0x0605664E ; mov r2,r1
L_06056688:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06056730u);  // 06056688 mov.w 0x06056730,r1
    c.t = c.r[7] == c.r[1];  // 0605668A cmp/eq r1,r7
    if (!c.t) { goto L_06056692; }  // 0605668C bf 0x06056692
    goto L_0605688E;  // 0605668E bra 0x0605688E ; nop
L_06056692:
    c.r[1] = ld32(0x0605673Cu);  // 06056692 mov.l 0x0605673C,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06056732u);  // 06056694 mov.w 0x06056732,r0
    c.r[12] = ld32(c.r[1]);  // 06056696 mov.l @r1,r12
    c.r[0] += c.r[14];  // 06056698 add r14,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06056734u);  // 0605669A mov.w 0x06056734,r1
    c.r[1] += c.r[14];  // 0605669C add r14,r1
    st32(c.r[1], c.r[12]);  // 0605669E mov.l r12,@r1
    c.r[1] = (uint32_t)(int16_t)ld16(0x06056734u);  // 060566A0 mov.w 0x06056734,r1
    c.r[2] = ld32(c.r[0]);  // 060566A2 mov.l @r0,r2
    c.r[1] += c.r[14];  // 060566A4 add r14,r1
    c.r[12] = ld32(c.r[1]);  // 060566A6 mov.l @r1,r12
    c.r[2] <<= 2;  // 060566A8 shll2 r2
    c.r[2] <<= 2;  // 060566AA shll2 r2
    c.r[12] += c.r[2];  // 060566AC add r2,r12
    st32(c.r[1], c.r[12]);  // 060566AE mov.l r12,@r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06056734u);  // 060566B0 mov.w 0x06056734,r0
    c.r[0] += c.r[14];  // 060566B2 add r14,r0
    c.r[12] = (uint32_t)(int16_t)ld16(0x06056734u);  // 060566B4 mov.w 0x06056734,r12
    c.r[1] = ld32(c.r[0]);  // 060566B6 mov.l @r0,r1
    c.r[12] += c.r[14];  // 060566B8 add r14,r12
    c.r[1] += 2;  // 060566BA add #2,r1
    st32(c.r[0], c.r[1]);  // 060566BC mov.l r1,@r0
    c.r[0] = ld32(c.r[12]);  // 060566BE mov.l @r12,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06056734u);  // 060566C0 mov.w 0x06056734,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0]);  // 060566C2 mov.b @r0,r0
    c.r[1] += c.r[14];  // 060566C4 add r14,r1
    st8(c.r[12], c.r[0]);  // 060566C6 mov.b r0,@r12
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060566C8 mov.b @r1,r1
    c.r[12] = ld32(0x0605673Cu);  // 060566CA mov.l 0x0605673C,r12
    c.r[13] = c.r[1] & 0xFFu;  // 060566CC extu.b r1,r13
    c.macl = c.r[13] * c.r[5];  // 060566CE mul.l r5,r13
    c.r[1] = (uint32_t)(int16_t)ld16(0x06056736u);  // 060566D0 mov.w 0x06056736,r1
    c.r[1] += c.r[14];  // 060566D2 add r14,r1
    c.r[3] = c.macl;  // 060566D4 sts macl,r3
    c.r[6] += c.r[3];  // 060566D6 add r3,r6
    c.r[6] += 16;  // 060566D8 add #16,r6
    st8(c.r[6], c.r[7]);  // 060566DA mov.b r7,@r6
    c.r[13] = c.r[7] & 0xFFu;  // 060566DC extu.b r7,r13
    c.r[0] = ld32(c.r[12]);  // 060566DE mov.l @r12,r0
    c.macl = c.r[7] * c.r[5];  // 060566E0 mul.l r5,r7
    c.r[12] = (uint32_t)(int16_t)ld16(0x06056736u);  // 060566E2 mov.w 0x06056736,r12
    c.r[12] += c.r[14];  // 060566E4 add r14,r12
    st32(c.r[12], c.r[0]);  // 060566E6 mov.l r0,@r12
    c.r[1] = ld32(c.r[1]);  // 060566E8 mov.l @r1,r1
    c.r[12] = ld32(0x06056740u);  // 060566EA mov.l 0x06056740,r12
    c.r[2] += c.r[1];  // 060566EC add r1,r2
    c.r[2] += 2;  // 060566EE add #2,r2
    st8(c.r[2], c.r[7]);  // 060566F0 mov.b r7,@r2
    c.r[2] = c.macl;  // 060566F2 sts macl,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06056738u);  // 060566F4 mov.w 0x06056738,r1
    c.r[1] += c.r[14];  // 060566F6 add r14,r1
    c.r[0] = ld32(c.r[12]);  // 060566F8 mov.l @r12,r0
    c.macl = c.r[13] * c.r[5];  // 060566FA mul.l r5,r13
    c.r[12] = (uint32_t)(int16_t)ld16(0x06056738u);  // 060566FC mov.w 0x06056738,r12
    c.r[12] += c.r[14];  // 060566FE add r14,r12
    st32(c.r[12], c.r[0]);  // 06056700 mov.l r0,@r12
    c.r[12] = (uint32_t)(int16_t)ld16(0x06056738u);  // 06056702 mov.w 0x06056738,r12
    c.r[12] += c.r[14];  // 06056704 add r14,r12
    c.r[1] = ld32(c.r[1]);  // 06056706 mov.l @r1,r1
    c.r[0] = ld32(0x06056740u);  // 06056708 mov.l 0x06056740,r0
    c.r[12] = ld32(c.r[12]);  // 0605670A mov.l @r12,r12
    c.r[2] += c.r[1];  // 0605670C add r1,r2
    c.r[2] += 15;  // 0605670E add #15,r2
    c.r[3] += c.r[12];  // 06056710 add r12,r3
    c.r[3] += 15;  // 06056712 add #15,r3
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06056714 mov.b @r3,r3
    c.r[12] = (uint32_t)(int16_t)ld16(0x0605673Au);  // 06056716 mov.w 0x0605673A,r12
    st8(c.r[2], c.r[3]);  // 06056718 mov.b r3,@r2
    c.r[1] = ld32(c.r[0]);  // 0605671A mov.l @r0,r1
    c.r[12] += c.r[14];  // 0605671C add r14,r12
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605673Au);  // 0605671E mov.w 0x0605673A,r0
    st32(c.r[0] + c.r[14], c.r[1]);  // 06056720 mov.l r1,@(r0,r14)
    c.r[12] = ld32(c.r[12]);  // 06056722 mov.l @r12,r12
    c.r[2] = c.macl;  // 06056724 sts macl,r2
    c.r[2] += c.r[12];  // 06056726 add r12,r2
    c.r[2] += 16;  // 06056728 add #16,r2
    c.r[0] = 0xFFFFFFFFu;  // 0605672A mov #-1,r0
    st8(c.r[2], c.r[0]); goto L_0605688E;  // 0605672C bra 0x0605688E ; mov.b r0,@r2
L_06056744:
    c.r[1] = ld32(0x0605693Cu);  // 06056744 mov.l 0x0605693C,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605692Eu);  // 06056746 mov.w 0x0605692E,r0
    c.r[12] = ld32(c.r[1]);  // 06056748 mov.l @r1,r12
    c.r[0] += c.r[14];  // 0605674A add r14,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605692Eu);  // 0605674C mov.w 0x0605692E,r1
    c.r[1] += c.r[14];  // 0605674E add r14,r1
    st32(c.r[1], c.r[12]);  // 06056750 mov.l r12,@r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x0605692Eu);  // 06056752 mov.w 0x0605692E,r12
    c.r[1] = ld32(c.r[0]);  // 06056754 mov.l @r0,r1
    c.r[12] += c.r[14];  // 06056756 add r14,r12
    c.r[1] += c.r[8];  // 06056758 add r8,r1
    st32(c.r[0], c.r[1]);  // 0605675A mov.l r1,@r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605692Eu);  // 0605675C mov.w 0x0605692E,r1
    c.r[0] = ld32(c.r[12]);  // 0605675E mov.l @r12,r0
    c.r[1] += c.r[14];  // 06056760 add r14,r1
    c.r[0] += 3;  // 06056762 add #3,r0
    st32(c.r[12], c.r[0]);  // 06056764 mov.l r0,@r12
    c.r[12] = ld32(c.r[1]);  // 06056766 mov.l @r1,r12
    c.r[0] = 0x7Fu;  // 06056768 mov #127,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605692Eu);  // 0605676A mov.w 0x0605692E,r1
    c.r[1] += c.r[14];  // 0605676C add r14,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[12]);  // 0605676E mov.b @r12,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605692Eu);  // 06056770 mov.w 0x0605692E,r1
    c.r[2] &= c.r[0];  // 06056772 and r0,r2
    st8(c.r[12], c.r[2]);  // 06056774 mov.b r2,@r12
    c.r[12] = ld32(0x0605693Cu);  // 06056776 mov.l 0x0605693C,r12
    c.r[0] = ld32(c.r[12]);  // 06056778 mov.l @r12,r0
    c.r[1] += c.r[14];  // 0605677A add r14,r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x0605692Eu);  // 0605677C mov.w 0x0605692E,r12
    c.r[12] += c.r[14];  // 0605677E add r14,r12
    st32(c.r[12], c.r[0]);  // 06056780 mov.l r0,@r12
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605692Eu);  // 06056782 mov.w 0x0605692E,r0
    c.r[12] = ld32(c.r[1]);  // 06056784 mov.l @r1,r12
    c.r[0] += c.r[14];  // 06056786 add r14,r0
    c.r[12] += c.r[8];  // 06056788 add r8,r12
    st32(c.r[1], c.r[12]);  // 0605678A mov.l r12,@r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x0605692Eu);  // 0605678C mov.w 0x0605692E,r12
    c.r[1] = ld32(c.r[0]);  // 0605678E mov.l @r0,r1
    c.r[12] += c.r[14];  // 06056790 add r14,r12
    c.r[1] += 4;  // 06056792 add #4,r1
    st32(c.r[0], c.r[1]);  // 06056794 mov.l r1,@r0
    c.r[0] = ld32(c.r[12]);  // 06056796 mov.l @r12,r0
    c.r[1] = 0x20u;  // 06056798 mov #32,r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x0605692Eu);  // 0605679A mov.w 0x0605692E,r12
    c.r[12] += c.r[14];  // 0605679C add r14,r12
    c.r[12] = (uint32_t)(int16_t)ld16(0x0605692Eu);  // 0605679E mov.w 0x0605692E,r12
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0]);  // 060567A0 mov.b @r0,r2
    c.r[12] += c.r[14];  // 060567A2 add r14,r12
    c.r[2] |= c.r[1];  // 060567A4 or r1,r2
    st8(c.r[0], c.r[2]);  // 060567A6 mov.b r2,@r0
    c.r[0] = ld32(0x0605693Cu);  // 060567A8 mov.l 0x0605693C,r0
    c.r[3] = ld32(c.r[0]);  // 060567AA mov.l @r0,r3
    c.r[1] = ld32(0x06056940u);  // 060567AC mov.l 0x06056940,r1
    c.r[2] = ld32(c.r[1]);  // 060567AE mov.l @r1,r2
    c.r[3] += c.r[8];  // 060567B0 add r8,r3
    c.r[3] += 6;  // 060567B2 add #6,r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]); c.r[2] += 1;  // 060567B4 mov.b @r2+,r0
    c.r[1] = ld32(0x0605693Cu);  // 060567B6 mov.l 0x0605693C,r1
    st8(c.r[12], c.r[0]);  // 060567B8 mov.b r0,@r12
    c.r[0] = c.r[8];  // 060567BA mov r8,r0
    c.r[12] = (uint32_t)(int16_t)ld16(0x0605692Eu);  // 060567BC mov.w 0x0605692E,r12
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060567BE mov.b @r2,r2
    c.r[12] += c.r[14];  // 060567C0 add r14,r12
    st8(c.r[3], c.r[2]);  // 060567C2 mov.b r2,@r3
    c.r[7] = ld32(c.r[1]);  // 060567C4 mov.l @r1,r7
    c.r[2] = ld32(0x06056944u);  // 060567C6 mov.l 0x06056944,r2
    c.r[0] += c.r[7];  // 060567C8 add r7,r0
    st32(c.r[12], c.r[0]);  // 060567CA mov.l r0,@r12
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605692Eu);  // 060567CC mov.w 0x0605692E,r1
    c.r[1] += c.r[14];  // 060567CE add r14,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605692Eu);  // 060567D0 mov.w 0x0605692E,r0
    c.r[12] = ld32(c.r[1]);  // 060567D2 mov.l @r1,r12
    c.r[0] += c.r[14];  // 060567D4 add r14,r0
    c.r[12] += 1;  // 060567D6 add #1,r12
    st32(c.r[1], c.r[12]);  // 060567D8 mov.l r12,@r1
    c.r[1] = ld32(c.r[0]);  // 060567DA mov.l @r0,r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x0605692Eu);  // 060567DC mov.w 0x0605692E,r12
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060567DE mov.b @r1,r1
    c.r[12] += c.r[14];  // 060567E0 add r14,r12
    st8(c.r[0], c.r[1]);  // 060567E2 mov.b r1,@r0
    c.r[0] = c.r[8];  // 060567E4 mov r8,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605692Eu);  // 060567E6 mov.w 0x0605692E,r1
    c.r[12] = (uint32_t)(int8_t)ld8(c.r[12]);  // 060567E8 mov.b @r12,r12
    c.r[1] += c.r[14];  // 060567EA add r14,r1
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 060567EC mov.b @(r0,r7),r7
    c.r[3] = c.r[12] & 0xFFu;  // 060567EE extu.b r12,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605692Eu);  // 060567F0 mov.w 0x0605692E,r0
    st8(c.r[0] + c.r[14], c.r[7]);  // 060567F2 mov.b r7,@(r0,r14)
    c.r[12] = (uint32_t)(int16_t)ld16(0x0605692Eu);  // 060567F4 mov.w 0x0605692E,r12
    c.r[12] += c.r[14];  // 060567F6 add r14,r12
    c.r[3] <<= 2;  // 060567F8 shll2 r3
    c.r[3] <<= 2;  // 060567FA shll2 r3
    c.r[3] <<= 2;  // 060567FC shll2 r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605692Eu);  // 060567FE mov.w 0x0605692E,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06056800 mov.b @r1,r1
    c.r[0] += c.r[14];  // 06056802 add r14,r0
    c.r[2] = ld32(c.r[2]);  // 06056804 mov.l @r2,r2
    c.r[7] = c.r[1] & 0xFFu;  // 06056806 extu.b r1,r7
    st32(c.r[12], c.r[2]);  // 06056808 mov.l r2,@r12
    c.r[0] = ld32(c.r[0]);  // 0605680A mov.l @r0,r0
    c.r[12] = ld32(0x0605693Cu);  // 0605680C mov.l 0x0605693C,r12
    c.r[3] += c.r[0];  // 0605680E add r0,r3
    c.r[1] = 0xFFFFFFFFu;  // 06056810 mov #-1,r1
    c.r[0] = c.r[3];  // 06056812 mov r3,r0
    st8(c.r[0] + c.r[7], c.r[1]);  // 06056814 mov.b r1,@(r0,r7)
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605692Eu);  // 06056816 mov.w 0x0605692E,r1
    c.r[0] = ld32(c.r[12]);  // 06056818 mov.l @r12,r0
    c.r[1] += c.r[14];  // 0605681A add r14,r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x0605692Eu);  // 0605681C mov.w 0x0605692E,r12
    c.r[12] += c.r[14];  // 0605681E add r14,r12
    st32(c.r[12], c.r[0]);  // 06056820 mov.l r0,@r12
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605692Eu);  // 06056822 mov.w 0x0605692E,r0
    c.r[12] = ld32(c.r[1]);  // 06056824 mov.l @r1,r12
    c.r[0] += c.r[14];  // 06056826 add r14,r0
    c.r[12] += c.r[8];  // 06056828 add r8,r12
    st32(c.r[1], c.r[12]);  // 0605682A mov.l r12,@r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x0605692Eu);  // 0605682C mov.w 0x0605692E,r12
    c.r[1] = ld32(c.r[0]);  // 0605682E mov.l @r0,r1
    c.r[12] += c.r[14];  // 06056830 add r14,r12
    c.r[1] += 2;  // 06056832 add #2,r1
    st32(c.r[0], c.r[1]);  // 06056834 mov.l r1,@r0
    c.r[0] = ld32(c.r[12]);  // 06056836 mov.l @r12,r0
    c.r[1] = ld32(0x06056948u);  // 06056838 mov.l 0x06056948,r1
    c.r[3] = ld32(c.r[1]);  // 0605683A mov.l @r1,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0605683C mov.b @r0,r2
    c.r[12] = 0x1Eu;  // 0605683E mov #30,r12
    c.r[2] = c.r[2] & 0xFFu;  // 06056840 extu.b r2,r2
    c.macl = c.r[2] * c.r[12];  // 06056842 mul.l r12,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605692Eu);  // 06056844 mov.w 0x0605692E,r0
    c.r[0] += c.r[14];  // 06056846 add r14,r0
    c.r[1] = c.macl;  // 06056848 sts macl,r1
    st32(c.r[0], c.r[1]);  // 0605684A mov.l r1,@r0
    c.r[12] = (uint32_t)(int16_t)ld16(0x0605692Eu);  // 0605684C mov.w 0x0605692E,r12
    c.r[12] += c.r[14];  // 0605684E add r14,r12
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605692Eu);  // 06056850 mov.w 0x0605692E,r1
    c.r[0] = ld32(c.r[12]);  // 06056852 mov.l @r12,r0
    c.r[1] += c.r[14];  // 06056854 add r14,r1
    c.r[0] += c.r[3];  // 06056856 add r3,r0
    st32(c.r[12], c.r[0]);  // 06056858 mov.l r0,@r12
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605692Eu);  // 0605685A mov.w 0x0605692E,r0
    c.r[12] = ld32(c.r[1]);  // 0605685C mov.l @r1,r12
    c.r[0] += c.r[14];  // 0605685E add r14,r0
    c.r[12] += 16;  // 06056860 add #16,r12
    st32(c.r[1], c.r[12]);  // 06056862 mov.l r12,@r1
    c.r[1] = ld32(c.r[0]);  // 06056864 mov.l @r0,r1
    c.r[12] = ld32(0x0605693Cu);  // 06056866 mov.l 0x0605693C,r12
    st8(c.r[1], c.r[13]);  // 06056868 mov.b r13,@r1
    c.r[1] = (uint32_t)(int16_t)ld16(0x06056930u);  // 0605686A mov.w 0x06056930,r1
    c.r[0] = ld32(c.r[12]);  // 0605686C mov.l @r12,r0
    c.r[1] += c.r[14];  // 0605686E add r14,r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x06056930u);  // 06056870 mov.w 0x06056930,r12
    c.r[12] += c.r[14];  // 06056872 add r14,r12
    st32(c.r[12], c.r[0]);  // 06056874 mov.l r0,@r12
    c.r[12] = (uint32_t)(int16_t)ld16(0x06056932u);  // 06056876 mov.w 0x06056932,r12
    c.r[12] += c.r[14];  // 06056878 add r14,r12
    c.r[1] = ld32(c.r[1]);  // 0605687A mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06056934u);  // 0605687C mov.w 0x06056934,r0
    c.r[6] = ld32(c.r[12]);  // 0605687E mov.l @r12,r6
    c.r[5] = ld32(c.r[0] + c.r[14]);  // 06056880 mov.l @(r0,r14),r5
    c.r[8] += c.r[1];  // 06056882 add r1,r8
    c.r[8] += 2;  // 06056884 add #2,r8
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06056886 mov.b @r8,r4
    c.r[1] = ld32(0x0605694Cu);  // 06056888 mov.l 0x0605694C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0605688Eu; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605688Eu) return; }  // 0605688A jsr @r1 ; extu.b r4,r4
L_0605688E:
    c.r[12] = (uint32_t)(int16_t)ld16(0x06056936u);  // 0605688E mov.w 0x06056936,r12
    c.r[12] += c.r[14];  // 06056890 add r14,r12
    c.r[3] = ld32(0x06056940u);  // 06056892 mov.l 0x06056940,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605692Eu);  // 06056894 mov.w 0x0605692E,r1
    c.r[0] = ld32(c.r[12]);  // 06056896 mov.l @r12,r0
    c.r[1] += c.r[14];  // 06056898 add r14,r1
    c.r[0] += 1;  // 0605689A add #1,r0
    st32(c.r[12], c.r[0]);  // 0605689C mov.l r0,@r12
    c.r[3] = ld32(c.r[3]);  // 0605689E mov.l @r3,r3
    c.r[2] = (uint32_t)(int16_t)ld16(0x06056938u);  // 060568A0 mov.w 0x06056938,r2
    st32(c.r[1], c.r[3]);  // 060568A2 mov.l r3,@r1
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605692Eu);  // 060568A4 mov.w 0x0605692E,r1
    c.r[1] += c.r[14];  // 060568A6 add r14,r1
    c.r[0] = ld32(c.r[1]);  // 060568A8 mov.l @r1,r0
    c.r[12] = (uint32_t)(int16_t)ld16(0x0605692Eu);  // 060568AA mov.w 0x0605692E,r12
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 060568AC mov.b @(r0,r2),r2
    c.r[12] += c.r[14];  // 060568AE add r14,r12
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605692Eu);  // 060568B0 mov.w 0x0605692E,r0
    st8(c.r[0] + c.r[14], c.r[2]);  // 060568B2 mov.b r2,@(r0,r14)
    c.r[12] = (uint32_t)(int8_t)ld8(c.r[12]);  // 060568B4 mov.b @r12,r12
    c.r[0] = c.r[12] & 0xFFu;  // 060568B6 extu.b r12,r0
    c.r[12] = (uint32_t)(int16_t)ld16(0x0605692Eu);  // 060568B8 mov.w 0x0605692E,r12
    c.r[12] += c.r[14];  // 060568BA add r14,r12
    st32(c.r[12], c.r[0]);  // 060568BC mov.l r0,@r12
    c.r[0] = (uint32_t)(int16_t)ld16(0x06056936u);  // 060568BE mov.w 0x06056936,r0
    c.r[1] = ld32(c.r[0] + c.r[14]);  // 060568C0 mov.l @(r0,r14),r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605692Eu);  // 060568C2 mov.w 0x0605692E,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 060568C4 mov.l @(r0,r14),r0
    c.t = (int32_t)c.r[1] >= (int32_t)c.r[0];  // 060568C6 cmp/ge r0,r1
    if (c.t) { goto L_060568CE; }  // 060568C8 bt 0x060568CE
    SH2_POLL(c); goto L_060564E4;  // 060568CA bra 0x060564E4 ; nop
L_060568CE:
    c.r[1] = ld32(0x06056940u);  // 060568CE mov.l 0x06056940,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605692Eu);  // 060568D0 mov.w 0x0605692E,r0
    c.r[0] += c.r[14];  // 060568D2 add r14,r0
    c.r[12] = ld32(c.r[1]);  // 060568D4 mov.l @r1,r12
    c.r[6] = (uint32_t)(int16_t)ld16(0x0605693Au);  // 060568D6 mov.w 0x0605693A,r6
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605692Eu);  // 060568D8 mov.w 0x0605692E,r1
    c.r[1] += c.r[14];  // 060568DA add r14,r1
    st32(c.r[1], c.r[12]);  // 060568DC mov.l r12,@r1
    c.r[1] = ld32(c.r[0]);  // 060568DE mov.l @r0,r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x0605692Eu);  // 060568E0 mov.w 0x0605692E,r12
    c.r[1] += 1;  // 060568E2 add #1,r1
    st32(c.r[0], c.r[1]);  // 060568E4 mov.l r1,@r0
    c.r[1] -= 1;  // 060568E6 add #-1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060568E8 mov.b @r1,r2
    c.r[12] += c.r[14];  // 060568EA add r14,r12
    c.r[0] = ld32(c.r[12]);  // 060568EC mov.l @r12,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605692Eu);  // 060568EE mov.w 0x0605692E,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0]);  // 060568F0 mov.b @r0,r0
    c.r[1] += c.r[14];  // 060568F2 add r14,r1
    st8(c.r[12], c.r[0]);  // 060568F4 mov.b r0,@r12
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060568F6 mov.b @r1,r1
    c.r[4] = c.r[14];  // 060568F8 mov r14,r4
    c.r[12] = c.r[1] & 0xFFu;  // 060568FA extu.b r1,r12
    c.r[1] = (uint32_t)(int16_t)ld16(0x06056934u);  // 060568FC mov.w 0x06056934,r1
    c.r[1] += c.r[14];  // 060568FE add r14,r1
    st32(c.r[1], c.r[12]);  // 06056900 mov.l r12,@r1
    c.r[12] = ld32(0x0605693Cu);  // 06056902 mov.l 0x0605693C,r12
    c.r[1] = (uint32_t)(int16_t)ld16(0x06056934u);  // 06056904 mov.w 0x06056934,r1
    c.r[0] = ld32(c.r[12]);  // 06056906 mov.l @r12,r0
    c.r[1] += c.r[14];  // 06056908 add r14,r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x0605692Eu);  // 0605690A mov.w 0x0605692E,r12
    c.r[12] += c.r[14];  // 0605690C add r14,r12
    st32(c.r[12], c.r[0]);  // 0605690E mov.l r0,@r12
    c.r[12] = (uint32_t)(int16_t)ld16(0x0605692Eu);  // 06056910 mov.w 0x0605692E,r12
    c.r[2] = ld32(c.r[1]);  // 06056912 mov.l @r1,r2
    c.r[12] += c.r[14];  // 06056914 add r14,r12
    c.r[12] = ld32(c.r[12]);  // 06056916 mov.l @r12,r12
    c.r[2] <<= 2;  // 06056918 shll2 r2
    c.r[2] <<= 2;  // 0605691A shll2 r2
    c.r[2] += c.r[12];  // 0605691C add r12,r2
    c.r[2] += 2;  // 0605691E add #2,r2
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06056920 mov.b @r2,r5
    c.r[0] = ld32(0x06056950u);  // 06056922 mov.l 0x06056950,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06056928u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06056928u) return; }  // 06056924 jsr @r0 ; extu.b r5,r5
    c.r[12] = c.r[14];  // 06056928 mov r14,r12
    c.r[12] += 26; goto L_06056954;  // 0605692A bra 0x06056954 ; add #26,r12
L_06056954:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06056B1Au);  // 06056954 mov.w 0x06056B1A,r1
    c.r[1] += c.r[14];  // 06056956 add r14,r1
    st32(c.r[1], c.r[12]);  // 06056958 mov.l r12,@r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06056B1Au);  // 0605695A mov.w 0x06056B1A,r0
    c.r[0] += c.r[14];  // 0605695C add r14,r0
    c.r[1] = ld32(c.r[0]);  // 0605695E mov.l @r0,r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x06056B1Au);  // 06056960 mov.w 0x06056B1A,r12
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06056962 mov.w @r1,r1
    c.r[12] += c.r[14];  // 06056964 add r14,r12
    st16(c.r[0], c.r[1]);  // 06056966 mov.w r1,@r0
    c.r[12] = (uint32_t)(int16_t)ld16(c.r[12]);  // 06056968 mov.w @r12,r12
    c.r[1] = ld32(0x06056B28u);  // 0605696A mov.l 0x06056B28,r1
    c.r[0] = c.r[12] & 0xFFFFu;  // 0605696C extu.w r12,r0
    c.r[12] = (uint32_t)(int16_t)ld16(0x06056B1Au);  // 0605696E mov.w 0x06056B1A,r12
    c.r[12] += c.r[14];  // 06056970 add r14,r12
    st32(c.r[12], c.r[0]);  // 06056972 mov.l r0,@r12
    c.r[0] = (uint32_t)(int16_t)ld16(0x06056B1Au);  // 06056974 mov.w 0x06056B1A,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 06056976 mov.l @(r0,r14),r0
    c.r[12] = 0x1Eu;  // 06056978 mov #30,r12
    c.r[2] = ld32(c.r[1]);  // 0605697A mov.l @r1,r2
    c.macl = c.r[0] * c.r[9];  // 0605697C mul.l r9,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06056B1Au);  // 0605697E mov.w 0x06056B1A,r1
    c.r[1] += c.r[14];  // 06056980 add r14,r1
    c.r[3] = c.macl;  // 06056982 sts macl,r3
    c.r[9] = c.macl;  // 06056984 sts macl,r9
    c.r[4] = c.r[3];  // 06056986 mov r3,r4
    c.r[0] = ld32(0x06056B2Cu);  // 06056988 mov.l 0x06056B2C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0605698Eu; c.r[5] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605698Eu) return; }  // 0605698A jsr @r0 ; mov r10,r5
    c.macl = c.r[13] * c.r[12];  // 0605698E mul.l r12,r13
    c.r[7] = c.macl;  // 06056990 sts macl,r7
    c.r[7] += c.r[2];  // 06056992 add r2,r7
    c.r[2] = c.r[0];  // 06056994 mov r0,r2
    c.r[0] = ld32(0x06056B2Cu);  // 06056996 mov.l 0x06056B2C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0605699Cu; c.r[4] = c.r[3]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605699Cu) return; }  // 06056998 jsr @r0 ; mov r3,r4
    c.r[6] = c.r[0];  // 0605699C mov r0,r6
    c.macl = c.r[6] * c.r[10];  // 0605699E mul.l r10,r6
    c.r[0] = (uint32_t)(int16_t)ld16(0x06056B1Au);  // 060569A0 mov.w 0x06056B1A,r0
    c.r[0] += c.r[14];  // 060569A2 add r14,r0
    c.r[12] = c.macl;  // 060569A4 sts macl,r12
    st32(c.r[1], c.r[12]);  // 060569A6 mov.l r12,@r1
    c.r[0] = ld32(c.r[0]);  // 060569A8 mov.l @r0,r0
    c.r[3] -= c.r[0];  // 060569AA sub r0,r3
    c.t = (c.r[3] & c.r[3]) == 0;  // 060569AC tst r3,r3
    { const bool k = c.t; c.r[7] += 22; if (k) { goto L_060569B4; } }  // 060569AE bt/s 0x060569B4 ; add #22,r7
    c.r[2] += 1;  // 060569B2 add #1,r2
L_060569B4:
    st16(c.r[7], c.r[2]);  // 060569B4 mov.w r2,@r7
    c.r[12] = c.r[14];  // 060569B6 mov r14,r12
    c.r[12] += 28;  // 060569B8 add #28,r12
    c.r[1] = (uint32_t)(int16_t)ld16(0x06056B1Au);  // 060569BA mov.w 0x06056B1A,r1
    c.r[1] += c.r[14];  // 060569BC add r14,r1
    st32(c.r[1], c.r[12]);  // 060569BE mov.l r12,@r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06056B1Au);  // 060569C0 mov.w 0x06056B1A,r0
    c.r[0] += c.r[14];  // 060569C2 add r14,r0
    c.r[1] = ld32(c.r[0]);  // 060569C4 mov.l @r0,r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x06056B1Au);  // 060569C6 mov.w 0x06056B1A,r12
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060569C8 mov.w @r1,r1
    c.r[12] += c.r[14];  // 060569CA add r14,r12
    st16(c.r[0], c.r[1]);  // 060569CC mov.w r1,@r0
    c.r[12] = (uint32_t)(int16_t)ld16(c.r[12]);  // 060569CE mov.w @r12,r12
    c.r[0] = c.r[12] & 0xFFFFu;  // 060569D0 extu.w r12,r0
    c.r[12] = (uint32_t)(int16_t)ld16(0x06056B1Au);  // 060569D2 mov.w 0x06056B1A,r12
    c.r[12] += c.r[14];  // 060569D4 add r14,r12
    st32(c.r[12], c.r[0]);  // 060569D6 mov.l r0,@r12
    c.r[0] = (uint32_t)(int16_t)ld16(0x06056B1Au);  // 060569D8 mov.w 0x06056B1A,r0
    c.r[1] = ld32(c.r[0] + c.r[14]);  // 060569DA mov.l @(r0,r14),r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06056B1Cu);  // 060569DC mov.w 0x06056B1C,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 060569DE mov.l @(r0,r14),r0
    c.macl = c.r[1] * c.r[0];  // 060569E0 mul.l r0,r1
    c.r[3] = c.macl;  // 060569E2 sts macl,r3
    c.r[12] = c.macl;  // 060569E4 sts macl,r12
    c.r[1] = (uint32_t)(int16_t)ld16(0x06056B1Cu);  // 060569E6 mov.w 0x06056B1C,r1
    c.r[1] += c.r[14];  // 060569E8 add r14,r1
    st32(c.r[1], c.r[12]);  // 060569EA mov.l r12,@r1
    c.r[0] = ld32(0x06056B28u);  // 060569EC mov.l 0x06056B28,r0
    c.r[1] = 0x1Eu;  // 060569EE mov #30,r1
    c.r[4] = c.r[3];  // 060569F0 mov r3,r4
    c.r[12] = (uint32_t)(int16_t)ld16(0x06056B1Eu);  // 060569F2 mov.w 0x06056B1E,r12
    c.r[12] += c.r[14];  // 060569F4 add r14,r12
    c.r[2] = ld32(c.r[0]);  // 060569F6 mov.l @r0,r2
    c.macl = c.r[13] * c.r[1];  // 060569F8 mul.l r1,r13
    c.r[0] = ld32(0x06056B2Cu);  // 060569FA mov.l 0x06056B2C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06056A00u; c.r[5] = ld32(c.r[12]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06056A00u) return; }  // 060569FC jsr @r0 ; mov.l @r12,r5
    c.r[4] = c.r[3];  // 06056A00 mov r3,r4
    c.r[7] = c.macl;  // 06056A02 sts macl,r7
    c.r[7] += c.r[2];  // 06056A04 add r2,r7
    c.r[2] = c.r[0];  // 06056A06 mov r0,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06056B1Eu);  // 06056A08 mov.w 0x06056B1E,r1
    c.r[1] += c.r[14];  // 06056A0A add r14,r1
    c.r[0] = ld32(0x06056B2Cu);  // 06056A0C mov.l 0x06056B2C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06056A12u; c.r[5] = ld32(c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06056A12u) return; }  // 06056A0E jsr @r0 ; mov.l @r1,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x06056B1Eu);  // 06056A12 mov.w 0x06056B1E,r1
    c.r[1] += c.r[14];  // 06056A14 add r14,r1
    c.r[1] = ld32(c.r[1]);  // 06056A16 mov.l @r1,r1
    c.r[6] = c.r[0];  // 06056A18 mov r0,r6
    c.macl = c.r[6] * c.r[1];  // 06056A1A mul.l r1,r6
    c.r[12] = (uint32_t)(int16_t)ld16(0x06056B1Au);  // 06056A1C mov.w 0x06056B1A,r12
    c.r[12] += c.r[14];  // 06056A1E add r14,r12
    c.r[0] = c.macl;  // 06056A20 sts macl,r0
    st32(c.r[12], c.r[0]);  // 06056A22 mov.l r0,@r12
    c.r[1] = (uint32_t)(int16_t)ld16(0x06056B1Au);  // 06056A24 mov.w 0x06056B1A,r1
    c.r[1] += c.r[14];  // 06056A26 add r14,r1
    c.r[1] = ld32(c.r[1]);  // 06056A28 mov.l @r1,r1
    c.r[3] -= c.r[1];  // 06056A2A sub r1,r3
    c.t = (c.r[3] & c.r[3]) == 0;  // 06056A2C tst r3,r3
    { const bool k = c.t; c.r[7] += 24; if (k) { goto L_06056A34; } }  // 06056A2E bt/s 0x06056A34 ; add #24,r7
    c.r[2] += 1;  // 06056A32 add #1,r2
L_06056A34:
    st16(c.r[7], c.r[2]);  // 06056A34 mov.w r2,@r7
    c.r[7] = ld32(0x06056B30u);  // 06056A36 mov.l 0x06056B30,r7
    c.r[10] = ld32(0x06056B34u);  // 06056A38 mov.l 0x06056B34,r10
    c.r[12] = (uint32_t)(int16_t)ld16(0x06056B20u);  // 06056A3A mov.w 0x06056B20,r12
    c.r[12] += c.r[14];  // 06056A3C add r14,r12
    c.r[0] = (uint32_t)(int16_t)ld16(0x06056B1Au);  // 06056A3E mov.w 0x06056B1A,r0
    c.r[0] += c.r[14];  // 06056A40 add r14,r0
    c.r[9] = c.r[14];  // 06056A42 mov r14,r9
    c.r[8] = ld32(c.r[12]);  // 06056A44 mov.l @r12,r8
    c.r[9] += 37;  // 06056A46 add #37,r9
    c.r[3] = ld32(c.r[10]);  // 06056A48 mov.l @r10,r3
    c.r[8] <<= 2;  // 06056A4A shll2 r8
    c.r[8] <<= 2;  // 06056A4C shll2 r8
    c.r[1] = c.r[8];  // 06056A4E mov r8,r1
    c.r[1] += c.r[3];  // 06056A50 add r3,r1
    st32(c.r[0], c.r[1]);  // 06056A52 mov.l r1,@r0
    c.r[12] = (uint32_t)(int16_t)ld16(0x06056B1Au);  // 06056A54 mov.w 0x06056B1A,r12
    c.r[12] += c.r[14];  // 06056A56 add r14,r12
    c.r[0] = ld32(c.r[12]);  // 06056A58 mov.l @r12,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06056B1Au);  // 06056A5A mov.w 0x06056B1A,r1
    c.r[0] += 1;  // 06056A5C add #1,r0
    st32(c.r[12], c.r[0]);  // 06056A5E mov.l r0,@r12
    c.r[0] = c.r[8];  // 06056A60 mov r8,r0
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06056A62 mov.b @(r0,r3),r3
    c.r[1] += c.r[14];  // 06056A64 add r14,r1
    c.r[12] = ld32(c.r[1]);  // 06056A66 mov.l @r1,r12
    c.r[0] = (uint32_t)(int16_t)ld16(0x06056B1Au);  // 06056A68 mov.w 0x06056B1A,r0
    c.r[0] += c.r[14];  // 06056A6A add r14,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06056B1Au);  // 06056A6C mov.w 0x06056B1A,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[12]);  // 06056A6E mov.b @r12,r2
    c.r[1] += c.r[14];  // 06056A70 add r14,r1
    c.r[2] = c.r[2] & 0xFFu;  // 06056A72 extu.b r2,r2
    st8(c.r[0], c.r[3]);  // 06056A74 mov.b r3,@r0
    c.r[2] <<= 2;  // 06056A76 shll2 r2
    c.r[2] <<= 2;  // 06056A78 shll2 r2
    c.r[2] <<= 2;  // 06056A7A shll2 r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06056B22u);  // 06056A7C mov.w 0x06056B22,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06056A7E mov.b @r1,r1
    c.r[0] += c.r[14];  // 06056A80 add r14,r0
    c.r[12] = c.r[1] & 0xFFu;  // 06056A82 extu.b r1,r12
    c.r[1] = (uint32_t)(int16_t)ld16(0x06056B1Au);  // 06056A84 mov.w 0x06056B1A,r1
    c.r[1] += c.r[14];  // 06056A86 add r14,r1
    st32(c.r[1], c.r[12]);  // 06056A88 mov.l r12,@r1
    c.r[3] = ld32(c.r[7]);  // 06056A8A mov.l @r7,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x06056B1Au);  // 06056A8C mov.w 0x06056B1A,r1
    c.r[2] += c.r[3];  // 06056A8E add r3,r2
    c.r[12] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06056A90 mov.b @r0,r12
    c.r[1] += c.r[14];  // 06056A92 add r14,r1
    c.r[0] = ld32(c.r[1]);  // 06056A94 mov.l @r1,r0
    c.r[11] = ld32(0x06056B38u);  // 06056A96 mov.l 0x06056B38,r11
    st8(c.r[0] + c.r[2], c.r[12]);  // 06056A98 mov.b r12,@(r0,r2)
    c.r[2] = c.r[8];  // 06056A9A mov r8,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06056B1Au);  // 06056A9C mov.w 0x06056B1A,r0
    c.r[0] += c.r[14];  // 06056A9E add r14,r0
    c.r[12] = (uint32_t)(int16_t)ld16(0x06056B1Au);  // 06056AA0 mov.w 0x06056B1A,r12
    c.r[3] = ld32(c.r[10]);  // 06056AA2 mov.l @r10,r3
    c.r[12] += c.r[14];  // 06056AA4 add r14,r12
    c.r[2] += c.r[3];  // 06056AA6 add r3,r2
    c.r[1] = c.r[2];  // 06056AA8 mov r2,r1
    c.r[1] += 3;  // 06056AAA add #3,r1
    st32(c.r[0], c.r[1]);  // 06056AAC mov.l r1,@r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06056B24u);  // 06056AAE mov.w 0x06056B24,r1
    c.r[0] = ld32(c.r[12]);  // 06056AB0 mov.l @r12,r0
    c.r[1] += c.r[14];  // 06056AB2 add r14,r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x06056B24u);  // 06056AB4 mov.w 0x06056B24,r12
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[0]);  // 06056AB6 mov.b @r0,r0
    c.r[12] += c.r[14];  // 06056AB8 add r14,r12
    st8(c.r[12], c.r[0]);  // 06056ABA mov.b r0,@r12
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06056ABC mov.b @r1,r7
    c.r[2] += 1;  // 06056ABE add #1,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06056AC0 mov.b @r9,r0
    c.r[12] = 0x3u;  // 06056AC2 mov #3,r12
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06056AC4 mov.b @r2,r5
    c.r[7] >>= 2;  // 06056AC6 shlr2 r7
    c.t = c.r[7] & 1; c.r[7] >>= 1;  // 06056AC8 shlr r7
    c.r[7] &= c.r[12];  // 06056ACA and r12,r7
    c.r[6] = c.r[0] & 0xFFu;  // 06056ACC extu.b r0,r6
    c.r[6] >>= 2;  // 06056ACE shlr2 r6
    c.r[6] >>= 2;  // 06056AD0 shlr2 r6
    c.r[1] = 0x10u;  // 06056AD2 mov #16,r1
    c.r[6] |= c.r[1];  // 06056AD4 or r1,r6
    c.r[0] = c.r[8];  // 06056AD6 mov r8,r0
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06056AD8 mov.b @(r0,r3),r4
    c.r[5] = c.r[5] & 0xFFu;  // 06056ADA extu.b r5,r5
    { const uint32_t x = c.r[11]; c.pr = 0x06056AE0u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06056AE0u) return; }  // 06056ADC jsr @r11 ; extu.b r4,r4
    c.r[2] = c.r[0];  // 06056AE0 mov r0,r2
    c.r[2] = (uint32_t)(int32_t)(int8_t)c.r[2];  // 06056AE2 exts.b r2,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06056B1Au);  // 06056AE4 mov.w 0x06056B1A,r1
    c.r[1] += c.r[14];  // 06056AE6 add r14,r1
    st32(c.r[1], c.r[2]);  // 06056AE8 mov.l r2,@r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x06056B1Au);  // 06056AEA mov.w 0x06056B1A,r12
    c.r[12] += c.r[14];  // 06056AEC add r14,r12
    c.r[12] = ld32(c.r[12]);  // 06056AEE mov.l @r12,r12
    c.t = (int32_t)c.r[12] >= 0;  // 06056AF0 cmp/pz r12
    { const bool k = c.t; c.r[12] = 0x10u; if (k) { goto L_06056B96; } }  // 06056AF2 bt/s 0x06056B96 ; mov #16,r12
    c.r[0] = (uint32_t)(int16_t)ld16(0x06056B1Au);  // 06056AF6 mov.w 0x06056B1A,r0
    c.r[0] += c.r[14];  // 06056AF8 add r14,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06056B1Au);  // 06056AFA mov.w 0x06056B1A,r1
    c.r[1] += c.r[14];  // 06056AFC add r14,r1
    c.r[9] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06056AFE mov.b @r9,r9
    c.r[7] = 0xFFFFFFFFu;  // 06056B00 mov #-1,r7
    st8(c.r[0], c.r[9]);  // 06056B02 mov.b r9,@r0
    c.r[0] = (uint32_t)(int16_t)ld16(0x06056B1Au);  // 06056B04 mov.w 0x06056B1A,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06056B06 mov.b @r1,r1
    c.r[0] += c.r[14];  // 06056B08 add r14,r0
    c.r[2] = ld32(c.r[10]);  // 06056B0A mov.l @r10,r2
    c.r[3] = c.r[1] & 0xFFu;  // 06056B0C extu.b r1,r3
    c.r[3] >>= 2;  // 06056B0E shlr2 r3
    c.r[3] >>= 2;  // 06056B10 shlr2 r3
    c.r[3] |= c.r[12];  // 06056B12 or r12,r3
    c.r[1] = c.r[8];  // 06056B14 mov r8,r1
    c.r[1] += c.r[2]; goto L_06056B3C;  // 06056B16 bra 0x06056B3C ; add r2,r1
L_06056B3C:
    st32(c.r[0], c.r[1]);  // 06056B3C mov.l r1,@r0
    c.r[12] = (uint32_t)(int16_t)ld16(0x06056BB4u);  // 06056B3E mov.w 0x06056BB4,r12
    c.r[12] += c.r[14];  // 06056B40 add r14,r12
    c.r[1] = (uint32_t)(int16_t)ld16(0x06056BB4u);  // 06056B42 mov.w 0x06056BB4,r1
    c.r[0] = ld32(c.r[12]);  // 06056B44 mov.l @r12,r0
    c.r[1] += c.r[14];  // 06056B46 add r14,r1
    c.r[0] += 1;  // 06056B48 add #1,r0
    st32(c.r[12], c.r[0]);  // 06056B4A mov.l r0,@r12
    c.r[12] = ld32(c.r[1]);  // 06056B4C mov.l @r1,r12
    c.r[0] = c.r[8];  // 06056B4E mov r8,r0
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06056B50 mov.b @(r0,r2),r4
    c.r[6] = c.r[3];  // 06056B52 mov r3,r6
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[12]);  // 06056B54 mov.b @r12,r5
    c.r[4] = c.r[4] & 0xFFu;  // 06056B56 extu.b r4,r4
    { const uint32_t x = c.r[11]; c.pr = 0x06056B5Cu; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06056B5Cu) return; }  // 06056B58 jsr @r11 ; extu.b r5,r5
    c.r[2] = c.r[0];  // 06056B5C mov r0,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06056BB4u);  // 06056B5E mov.w 0x06056BB4,r1
    c.r[1] += c.r[14];  // 06056B60 add r14,r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x06056BB4u);  // 06056B62 mov.w 0x06056BB4,r12
    c.r[12] += c.r[14];  // 06056B64 add r14,r12
    c.r[3] = 0x3u;  // 06056B66 mov #3,r3
    c.r[3] &= c.r[2];  // 06056B68 and r2,r3
    c.r[10] = ld32(c.r[10]);  // 06056B6A mov.l @r10,r10
    c.r[3] <<= 2;  // 06056B6C shll2 r3
    c.r[3] += c.r[3];  // 06056B6E add r3,r3
    st32(c.r[1], c.r[10]);  // 06056B70 mov.l r10,@r1
    c.r[1] = (uint32_t)(int16_t)ld16(0x06056BB4u);  // 06056B72 mov.w 0x06056BB4,r1
    c.r[0] = ld32(c.r[12]);  // 06056B74 mov.l @r12,r0
    c.r[1] += c.r[14];  // 06056B76 add r14,r1
    c.r[0] += c.r[8];  // 06056B78 add r8,r0
    st32(c.r[12], c.r[0]);  // 06056B7A mov.l r0,@r12
    c.r[0] = (uint32_t)(int16_t)ld16(0x06056BB4u);  // 06056B7C mov.w 0x06056BB4,r0
    c.r[12] = ld32(c.r[1]);  // 06056B7E mov.l @r1,r12
    c.r[0] += c.r[14];  // 06056B80 add r14,r0
    c.r[12] += 3;  // 06056B82 add #3,r12
    st32(c.r[1], c.r[12]);  // 06056B84 mov.l r12,@r1
    c.r[1] = ld32(c.r[0]);  // 06056B86 mov.l @r0,r1
    c.r[12] = (uint32_t)(int16_t)ld16(0x06056BB6u);  // 06056B88 mov.w 0x06056BB6,r12
    c.r[0] = (uint32_t)(int16_t)ld16(0x06056BB4u);  // 06056B8A mov.w 0x06056BB4,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06056B8C mov.b @r1,r2
    c.r[0] += c.r[14];  // 06056B8E add r14,r0
    c.r[2] &= c.r[12];  // 06056B90 and r12,r2
    c.r[2] |= c.r[3];  // 06056B92 or r3,r2
    st8(c.r[1], c.r[2]);  // 06056B94 mov.b r2,@r1
L_06056B96:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06056BB8u);  // 06056B96 mov.w 0x06056BB8,r1
    c.r[1] += c.r[14];  // 06056B98 add r14,r1
    c.r[0] = ld32(c.r[1]);  // 06056B9A mov.l @r1,r0
    c.r[3] = (uint32_t)(int16_t)ld16(0x06056BBAu);  // 06056B9C mov.w 0x06056BBA,r3
    c.r[14] += c.r[3];  // 06056B9E add r3,r14
    c.r[15] = c.r[14];  // 06056BA0 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06056BA2 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06056BA4 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06056BA6 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06056BA8 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06056BAA mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06056BAC mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06056BAE mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06056BB0 rts ; mov.l @r15+,r8
}

void f_06056BBC(SH2Context& c) {
    ran[1331] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06056BBC mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06056BBE mov r15,r14
    c.r[4] = c.r[4] & 0xFFu;  // 06056BC0 extu.b r4,r4
    c.r[5] = c.r[5] & 0xFFu;  // 06056BC2 extu.b r5,r5
    c.r[1] = ld32(0x06056BF4u);  // 06056BC4 mov.l 0x06056BF4,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06056BC6 mov.w @r1,r1
    c.r[5] += c.r[1];  // 06056BC8 add r1,r5
    c.r[5] += 1;  // 06056BCA add #1,r5
    c.r[5] = c.r[5] & 0xFFFFu;  // 06056BCC extu.w r5,r5
    c.r[1] = ld32(0x06056BF8u);  // 06056BCE mov.l 0x06056BF8,r1
    c.r[3] = c.r[5];  // 06056BD0 mov r5,r3
    c.r[3] <<= 2;  // 06056BD2 shll2 r3
    c.r[3] += c.r[5];  // 06056BD4 add r5,r3
    c.r[3] += c.r[3];  // 06056BD6 add r3,r3
    c.r[1] = ld32(c.r[1] + 8);  // 06056BD8 mov.l @(8,r1),r1
    c.r[4] <<= 8;  // 06056BDA shll8 r4
    c.r[4] <<= 2;  // 06056BDC shll2 r4
    c.r[3] += c.r[1];  // 06056BDE add r1,r3
    c.r[3] += 4;  // 06056BE0 add #4,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06056BE2 mov.w @r3,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06056BF0u);  // 06056BE4 mov.w 0x06056BF0,r1
    c.r[2] &= c.r[1];  // 06056BE6 and r1,r2
    c.r[2] |= c.r[4];  // 06056BE8 or r4,r2
    st16(c.r[3], c.r[2]);  // 06056BEA mov.w r2,@r3
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06056BEC rts ; mov.l @r15+,r14
}

void f_06056BFC(SH2Context& c) {
    ran[1332] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06056BFC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06056BFE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06056C00 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06056C02 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06056C04 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06056C06 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06056C08 sts.l pr,@-r15
    c.r[11] = c.r[4] & 0xFFu;  // 06056C0A extu.b r4,r11
    c.r[12] = ld32(0x06056CE4u);  // 06056C0C mov.l 0x06056CE4,r12
    c.r[10] = c.r[11];  // 06056C0E mov r11,r10
    c.r[1] = ld32(c.r[12]);  // 06056C10 mov.l @r12,r1
    c.r[10] <<= 2;  // 06056C12 shll2 r10
    c.r[10] <<= 2;  // 06056C14 shll2 r10
    c.r[1] += c.r[10];  // 06056C16 add r10,r1
    c.r[1] += 3;  // 06056C18 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06056C1A mov.b @r1,r1
    c.r[0] = 0x3u;  // 06056C1C mov #3,r0
    c.r[9] = c.r[1];  // 06056C1E mov r1,r9
    c.r[9] >>= 2;  // 06056C20 shlr2 r9
    c.t = c.r[9] & 1; c.r[9] >>= 1;  // 06056C22 shlr r9
    c.r[9] &= c.r[0];  // 06056C24 and r0,r9
    c.r[0] = c.r[9];  // 06056C26 mov r9,r0
    c.t = c.r[0] == 0x2u;  // 06056C28 cmp/eq #2,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06056C80; } }  // 06056C2A bt/s 0x06056C80 ; mov r15,r14
    c.t = c.r[0] == 0x1u;  // 06056C2E cmp/eq #1,r0
    if (!c.t) { goto L_06056CA8; }  // 06056C30 bf 0x06056CA8
    c.r[4] = ld32(0x06056CE8u);  // 06056C32 mov.l 0x06056CE8,r4
    c.r[8] = ld32(0x06056CECu);  // 06056C34 mov.l 0x06056CEC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06056C3Au; c.r[5] = 0x22u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06056C3Au) return; }  // 06056C36 jsr @r8 ; mov #34,r5
    c.r[1] = c.r[0];  // 06056C3A mov r0,r1
    c.r[5] = c.r[9];  // 06056C3C mov r9,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06056C42u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06056C42u) return; }  // 06056C3E jsr @r8 ; mov r1,r4
    c.r[1] = c.r[0];  // 06056C42 mov r0,r1
    c.r[5] = 0x3u;  // 06056C44 mov #3,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06056C4Au; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06056C4Au) return; }  // 06056C46 jsr @r8 ; mov r1,r4
    c.r[6] = c.r[0];  // 06056C4A mov r0,r6
    c.r[7] = ld32(0x06056CF0u);  // 06056C4C mov.l 0x06056CF0,r7
    c.r[3] = ld32(c.r[12]);  // 06056C4E mov.l @r12,r3
    c.r[1] = c.r[10];  // 06056C50 mov r10,r1
    c.r[1] += c.r[3];  // 06056C52 add r3,r1
    c.r[1] += 1;  // 06056C54 add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06056C56 mov.b @r1,r2
    c.r[0] = c.r[10];  // 06056C58 mov r10,r0
    c.r[2] = c.r[2] & 0xFFu;  // 06056C5A extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06056C5C mov.b @(r0,r3),r1
    c.r[2] <<= 2;  // 06056C5E shll2 r2
    c.r[2] <<= 2;  // 06056C60 shll2 r2
    c.r[2] <<= 2;  // 06056C62 shll2 r2
    c.r[3] = (uint32_t)(int16_t)ld16(0x06056CDCu);  // 06056C64 mov.w 0x06056CDC,r3
    c.r[0] = c.r[7];  // 06056C66 mov r7,r0
    c.r[3] = ld32(c.r[0] + c.r[3]);  // 06056C68 mov.l @(r0,r3),r3
    c.r[1] = c.r[1] & 0xFFu;  // 06056C6A extu.b r1,r1
    c.r[2] += c.r[3];  // 06056C6C add r3,r2
    c.r[0] = c.r[2];  // 06056C6E mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06056C70 mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06056C72 extu.b r1,r1
    c.r[0] = c.r[6];  // 06056C74 mov r6,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06056C76 mov.b @(r0,r1),r1
    c.r[0] = 0x40u;  // 06056C78 mov #64,r0
    c.r[1] &= c.r[0];  // 06056C7A and r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06056C7C tst r1,r1
    if (c.t) { goto L_06056CA8; }  // 06056C7E bt 0x06056CA8
L_06056C80:
    c.r[1] = ld32(0x06056CF4u);  // 06056C80 mov.l 0x06056CF4,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06056C82 mov.w @r1,r1
    c.r[11] += c.r[1];  // 06056C84 add r1,r11
    c.r[11] += 1;  // 06056C86 add #1,r11
    c.r[2] = c.r[11] & 0xFFFFu;  // 06056C88 extu.w r11,r2
    c.r[1] = ld32(0x06056CF8u);  // 06056C8A mov.l 0x06056CF8,r1
    c.r[3] = c.r[2];  // 06056C8C mov r2,r3
    c.r[3] <<= 2;  // 06056C8E shll2 r3
    c.r[3] += c.r[2];  // 06056C90 add r2,r3
    c.r[1] = ld32(c.r[1] + 8);  // 06056C92 mov.l @(8,r1),r1
    c.r[3] += c.r[3];  // 06056C94 add r3,r3
    c.r[3] += c.r[1];  // 06056C96 add r1,r3
    c.r[3] += 4;  // 06056C98 add #4,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06056C9A mov.w @r3,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06056CDEu);  // 06056C9C mov.w 0x06056CDE,r1
    c.r[2] &= c.r[1];  // 06056C9E and r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06056CE0u);  // 06056CA0 mov.w 0x06056CE0,r1
    c.r[2] |= c.r[1];  // 06056CA2 or r1,r2
    st16(c.r[3], c.r[2]); goto L_06056CCA;  // 06056CA4 bra 0x06056CCA ; mov.w r2,@r3
L_06056CA8:
    c.r[1] = ld32(0x06056CF4u);  // 06056CA8 mov.l 0x06056CF4,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06056CAA mov.w @r1,r1
    c.r[11] += c.r[1];  // 06056CAC add r1,r11
    c.r[11] += 1;  // 06056CAE add #1,r11
    c.r[2] = c.r[11] & 0xFFFFu;  // 06056CB0 extu.w r11,r2
    c.r[1] = ld32(0x06056CF8u);  // 06056CB2 mov.l 0x06056CF8,r1
    c.r[3] = c.r[2];  // 06056CB4 mov r2,r3
    c.r[3] <<= 2;  // 06056CB6 shll2 r3
    c.r[3] += c.r[2];  // 06056CB8 add r2,r3
    c.r[1] = ld32(c.r[1] + 8);  // 06056CBA mov.l @(8,r1),r1
    c.r[3] += c.r[3];  // 06056CBC add r3,r3
    c.r[3] += c.r[1];  // 06056CBE add r1,r3
    c.r[3] += 4;  // 06056CC0 add #4,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06056CC2 mov.w @r3,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06056CDEu);  // 06056CC4 mov.w 0x06056CDE,r2
    c.r[1] &= c.r[2];  // 06056CC6 and r2,r1
    st16(c.r[3], c.r[1]);  // 06056CC8 mov.w r1,@r3
L_06056CCA:
    c.r[15] = c.r[14];  // 06056CCA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06056CCC lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06056CCE mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06056CD0 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06056CD2 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06056CD4 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06056CD6 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06056CD8 rts ; mov.l @r15+,r8
}

void f_06056CFC(SH2Context& c) {
    ran[1333] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06056CFC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06056CFE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06056D00 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06056D02 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06056D04 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06056D06 mov r15,r14
    c.r[8] = 0x0u;  // 06056D08 mov #0,r8
    c.r[10] = ld32(0x06056D3Cu);  // 06056D0A mov.l 0x06056D3C,r10
    c.r[9] = 0x0u;  // 06056D0C mov #0,r9
L_06056D0E:
    c.r[1] = ld32(0x06056D40u);  // 06056D0E mov.l 0x06056D40,r1
    c.r[0] = ld32(c.r[1]);  // 06056D10 mov.l @r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 06056D12 mov.b @(r0,r9),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06056D38u);  // 06056D14 mov.w 0x06056D38,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06056D16 extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 06056D18 cmp/eq r2,r1
    if (c.t) { goto L_06056D20; }  // 06056D1A bt 0x06056D20
    { const uint32_t x = c.r[10]; c.pr = 0x06056D20u; c.r[4] = c.r[8] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06056D20u) return; }  // 06056D1C jsr @r10 ; extu.b r8,r4
L_06056D20:
    c.r[8] += 1;  // 06056D20 add #1,r8
    c.r[1] = 0x49u;  // 06056D22 mov #73,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 06056D24 cmp/gt r1,r8
    { const bool k = !c.t; c.r[9] += 16; if (k) { SH2_POLL(c); goto L_06056D0E; } }  // 06056D26 bf/s 0x06056D0E ; add #16,r9
    c.r[15] = c.r[14];  // 06056D2A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06056D2C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06056D2E mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06056D30 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06056D32 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06056D34 rts ; mov.l @r15+,r8
}

void f_06056D44(SH2Context& c) {
    ran[1334] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06056D44 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06056D46 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06056D48 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06056D4A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06056D4C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06056D4E sts.l pr,@-r15
    c.r[15] -= 8;  // 06056D50 add #-8,r15
    c.r[14] = c.r[15];  // 06056D52 mov r15,r14
    c.r[11] = c.r[4] & 0xFFu;  // 06056D54 extu.b r4,r11
    c.r[8] = 0x0u;  // 06056D56 mov #0,r8
    c.r[3] = ld32(0x06056E80u);  // 06056D58 mov.l 0x06056E80,r3
    c.r[2] = ld32(c.r[3]);  // 06056D5A mov.l @r3,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06056E7Au);  // 06056D5C mov.w 0x06056E7A,r1
    c.r[0] = c.r[2];  // 06056D5E mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06056D60 mov.b @(r0,r1),r1
    c.r[1] >>= 2;  // 06056D62 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06056D64 shlr r1
    c.r[0] = 0x7u;  // 06056D66 mov #7,r0
    c.r[1] &= c.r[0];  // 06056D68 and r0,r1
    c.t = (int32_t)c.r[8] >= (int32_t)c.r[1];  // 06056D6A cmp/ge r1,r8
    { const bool k = c.t; c.r[9] = 0x0u; if (k) { goto L_06056E26; } }  // 06056D6C bt/s 0x06056E26 ; mov #0,r9
    c.r[10] = c.r[14];  // 06056D70 mov r14,r10
    c.r[10] += 1;  // 06056D72 add #1,r10
L_06056D74:
    c.r[1] = ld32(c.r[3]);  // 06056D74 mov.l @r3,r1
    c.r[1] += c.r[9];  // 06056D76 add r9,r1
    c.r[1] += 16;  // 06056D78 add #16,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06056D7A mov.b @r1,r1
    c.r[2] = c.r[1] & 0xFFu;  // 06056D7C extu.b r1,r2
    c.r[1] = 0xDu;  // 06056D7E mov #13,r1
    c.r[2] -= 8;  // 06056D80 add #-8,r2
    c.t = c.r[2] > c.r[1];  // 06056D82 cmp/hi r1,r2
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_06056E10; } }  // 06056D84 bt/s 0x06056E10 ; mov r2,r1
    c.r[1] += c.r[1];  // 06056D88 add r1,r1
    c.r[0] = 0x06056D94u;  // 06056D8A mova 0x06056D94,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06056D8C mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 06056D8E add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x06056DB0u: goto L_06056DB0; case 0x06056E10u: goto L_06056E10; case 0x06056DC6u: goto L_06056DC6; case 0x06056DDCu: goto L_06056DDC; default: sh2_call(c, x); return; } }  // 06056D90 jmp @r0 ; nop
L_06056DB0:
    c.r[1] = ld32(0x06056E80u);  // 06056DB0 mov.l 0x06056E80,r1
    c.r[3] = ld32(c.r[1]);  // 06056DB2 mov.l @r1,r3
    c.r[1] = c.r[3];  // 06056DB4 mov r3,r1
    c.r[1] += 24;  // 06056DB6 add #24,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06056DB8 mov.w @r1,r2
    c.r[3] += 28;  // 06056DBA add #28,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06056DBC mov.w @r3,r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 06056DBE extu.w r2,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 06056DC0 extu.w r1,r1
    c.t = c.r[2] == c.r[1]; goto L_06056DE8;  // 06056DC2 bra 0x06056DE8 ; cmp/eq r1,r2
L_06056DC6:
    c.r[1] = ld32(0x06056E80u);  // 06056DC6 mov.l 0x06056E80,r1
    c.r[3] = ld32(c.r[1]);  // 06056DC8 mov.l @r1,r3
    c.r[1] = c.r[3];  // 06056DCA mov r3,r1
    c.r[1] += 22;  // 06056DCC add #22,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06056DCE mov.w @r1,r2
    c.r[3] += 26;  // 06056DD0 add #26,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06056DD2 mov.w @r3,r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 06056DD4 extu.w r2,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 06056DD6 extu.w r1,r1
    c.t = c.r[2] == c.r[1]; goto L_06056DE8;  // 06056DD8 bra 0x06056DE8 ; cmp/eq r1,r2
L_06056DDC:
    c.r[1] = ld32(0x06056E84u);  // 06056DDC mov.l 0x06056E84,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06056DDE mov.b @r1,r4
    c.r[0] = ld32(0x06056E88u);  // 06056DE0 mov.l 0x06056E88,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06056DE6u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06056DE6u) return; }  // 06056DE2 jsr @r0 ; extu.b r4,r4
    c.t = c.r[0] == 0xFFFFFFFFu;  // 06056DE6 cmp/eq #-1,r0
L_06056DE8:
    { const bool k = c.t; c.r[3] = c.r[8]; if (k) { goto L_06056E10; } }  // 06056DE8 bt/s 0x06056E10 ; mov r8,r3
    c.r[1] = c.r[8];  // 06056DEC mov r8,r1
    c.r[1] += 1;  // 06056DEE add #1,r1
    c.r[8] = c.r[1] & 0xFFu;  // 06056DF0 extu.b r1,r8
    c.r[3] += c.r[3];  // 06056DF2 add r3,r3
    c.r[1] = c.r[9] & 0xFFFFu;  // 06056DF4 extu.w r9,r1
    c.r[7] = c.r[1];  // 06056DF6 mov r1,r7
    c.r[7] >>= 8;  // 06056DF8 shlr8 r7
    c.r[0] = 0x7Fu;  // 06056DFA mov #127,r0
    c.r[7] &= c.r[0];  // 06056DFC and r0,r7
    c.r[0] = c.r[14];  // 06056DFE mov r14,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06056E00 mov.b @(r0,r3),r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06056E7Cu);  // 06056E02 mov.w 0x06056E7C,r0
    c.r[2] &= c.r[0];  // 06056E04 and r0,r2
    c.r[2] |= c.r[7];  // 06056E06 or r7,r2
    c.r[0] = c.r[14];  // 06056E08 mov r14,r0
    st8(c.r[0] + c.r[3], c.r[2]);  // 06056E0A mov.b r2,@(r0,r3)
    c.r[0] = c.r[10];  // 06056E0C mov r10,r0
    st8(c.r[0] + c.r[3], c.r[1]);  // 06056E0E mov.b r1,@(r0,r3)
L_06056E10:
    c.r[3] = ld32(0x06056E80u);  // 06056E10 mov.l 0x06056E80,r3
    c.r[1] = ld32(c.r[3]);  // 06056E12 mov.l @r3,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06056E7Au);  // 06056E14 mov.w 0x06056E7A,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06056E16 mov.b @(r0,r1),r1
    c.r[9] += 1;  // 06056E18 add #1,r9
    c.r[0] = c.r[1];  // 06056E1A mov r1,r0
    c.r[0] >>= 2;  // 06056E1C shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06056E1E shlr r0
    c.r[0] &= 0x7u;  // 06056E20 and #7,r0
    c.t = (int32_t)c.r[9] >= (int32_t)c.r[0];  // 06056E22 cmp/ge r0,r9
    if (!c.t) { SH2_POLL(c); goto L_06056D74; }  // 06056E24 bf 0x06056D74
L_06056E26:
    c.t = (c.r[11] & c.r[11]) == 0;  // 06056E26 tst r11,r11
    { const bool k = c.t; c.r[1] = (uint32_t)(int8_t)ld8(c.r[14]); if (k) { goto L_06056E66; } }  // 06056E28 bt/s 0x06056E66 ; mov.b @r14,r1
    c.r[7] = ld32(0x06056E8Cu);  // 06056E2C mov.l 0x06056E8C,r7
    c.r[2] = ld32(c.r[7]);  // 06056E2E mov.l @r7,r2
    st8(c.r[2], c.r[1]);  // 06056E30 mov.b r1,@r2
    c.r[1] = c.r[14];  // 06056E32 mov r14,r1
    c.r[1] += 1;  // 06056E34 add #1,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 06056E36 mov.b @r1+,r3
    c.r[2] += 1;  // 06056E38 add #1,r2
    st8(c.r[2], c.r[3]);  // 06056E3A mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 06056E3C mov.b @r1+,r3
    c.r[2] += 1;  // 06056E3E add #1,r2
    st8(c.r[2], c.r[3]);  // 06056E40 mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 06056E42 mov.b @r1+,r3
    c.r[2] += 1;  // 06056E44 add #1,r2
    st8(c.r[2], c.r[3]);  // 06056E46 mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 06056E48 mov.b @r1+,r3
    c.r[2] += 1;  // 06056E4A add #1,r2
    st8(c.r[2], c.r[3]);  // 06056E4C mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 06056E4E mov.b @r1+,r3
    c.r[2] += 1;  // 06056E50 add #1,r2
    st8(c.r[2], c.r[3]);  // 06056E52 mov.b r3,@r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 06056E54 mov.b @r1+,r3
    c.r[2] += 1;  // 06056E56 add #1,r2
    st8(c.r[2], c.r[3]);  // 06056E58 mov.b r3,@r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06056E5A mov.b @r1,r1
    c.r[2] += 1;  // 06056E5C add #1,r2
    st8(c.r[2], c.r[1]);  // 06056E5E mov.b r1,@r2
    c.r[1] = ld32(c.r[7]);  // 06056E60 mov.l @r7,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06056E7Eu);  // 06056E62 mov.w 0x06056E7E,r0
    st8(c.r[0] + c.r[1], c.r[8]);  // 06056E64 mov.b r8,@(r0,r1)
L_06056E66:
    c.r[14] += 8;  // 06056E66 add #8,r14
    c.r[15] = c.r[14];  // 06056E68 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06056E6A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06056E6C mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06056E6E mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06056E70 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06056E72 mov.l @r15+,r9
    c.r[0] = c.r[8];  // 06056E74 mov r8,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06056E76 rts ; mov.l @r15+,r8
}

void f_06056E90(SH2Context& c) {
    ran[1335] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06056E90 mov.l r14,@-r15
    c.r[4] = c.r[4] & 0xFFu;  // 06056E92 extu.b r4,r4
    c.r[1] = ld32(0x06056EE0u);  // 06056E94 mov.l 0x06056EE0,r1
    c.r[1] = ld32(c.r[1]);  // 06056E96 mov.l @r1,r1
    c.r[4] <<= 2;  // 06056E98 shll2 r4
    c.r[4] <<= 2;  // 06056E9A shll2 r4
    c.r[4] += c.r[1];  // 06056E9C add r1,r4
    c.r[4] += 2;  // 06056E9E add #2,r4
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[4]);  // 06056EA0 mov.b @r4,r2
    c.r[1] = ld32(0x06056EE4u);  // 06056EA2 mov.l 0x06056EE4,r1
    c.r[3] = ld32(c.r[1]);  // 06056EA4 mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06056EA6 extu.b r2,r2
    c.r[1] = 0x1Eu;  // 06056EA8 mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 06056EAA mul.l r1,r2
    c.r[5] = c.r[5] & 0xFFu;  // 06056EAC extu.b r5,r5
    c.r[7] = c.macl;  // 06056EAE sts macl,r7
    c.r[7] += c.r[3];  // 06056EB0 add r3,r7
    c.r[7] += c.r[5];  // 06056EB2 add r5,r7
    c.r[7] += 17;  // 06056EB4 add #17,r7
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06056EB6 mov.b @r7,r2
    c.r[1] = 0x0u;  // 06056EB8 mov #0,r1
    c.r[2] = c.r[2] & 0xFFu;  // 06056EBA extu.b r2,r2
    st8(c.r[7], c.r[1]);  // 06056EBC mov.b r1,@r7
    c.r[1] = ld32(0x06056EE8u);  // 06056EBE mov.l 0x06056EE8,r1
    c.r[3] = ld32(c.r[1]);  // 06056EC0 mov.l @r1,r3
    c.r[7] = (uint32_t)(int16_t)ld16(0x06056EDEu);  // 06056EC2 mov.w 0x06056EDE,r7
    c.r[3] += c.r[2];  // 06056EC4 add r2,r3
    c.r[0] = c.r[3];  // 06056EC6 mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06056EC8 mov.b @(r0,r7),r2
    c.r[1] = c.r[2] & 0xFFu;  // 06056ECA extu.b r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06056ECC tst r1,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06056ED8; } }  // 06056ECE bt/s 0x06056ED8 ; mov r15,r14
    c.r[1] = c.r[2];  // 06056ED2 mov r2,r1
    c.r[1] -= 1;  // 06056ED4 add #-1,r1
    st8(c.r[0] + c.r[7], c.r[1]);  // 06056ED6 mov.b r1,@(r0,r7)
L_06056ED8:
    c.r[15] = c.r[14];  // 06056ED8 mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06056EDA rts ; mov.l @r15+,r14
}

void f_06056EEC(SH2Context& c) {
    ran[1336] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06056EEC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06056EEE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06056EF0 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06056EF2 mov r15,r14
    c.r[4] = c.r[4] & 0xFFu;  // 06056EF4 extu.b r4,r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 06056EF6 tst r4,r4
    { const bool k = c.t; c.r[4] = 0x3Eu; if (k) { goto L_06056EFE; } }  // 06056EF8 bt/s 0x06056EFE ; mov #62,r4
    c.r[4] = 0x3Fu;  // 06056EFC mov #63,r4
L_06056EFE:
    c.r[1] = ld32(0x06056F78u);  // 06056EFE mov.l 0x06056F78,r1
    c.r[2] = ld32(c.r[1]);  // 06056F00 mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06056F74u);  // 06056F02 mov.w 0x06056F74,r1
    c.r[0] = c.r[2];  // 06056F04 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06056F06 mov.b @(r0,r1),r1
    c.r[3] = 0x0u;  // 06056F08 mov #0,r3
    c.r[7] = c.r[1] & 0xFFu;  // 06056F0A extu.b r1,r7
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[7];  // 06056F0C cmp/ge r7,r3
    if (c.t) { goto L_06056F56; }  // 06056F0E bt 0x06056F56
    c.r[5] = c.r[2];  // 06056F10 mov r2,r5
    c.r[1] = ld32(0x06056F7Cu);  // 06056F12 mov.l 0x06056F7C,r1
    c.r[9] = ld32(c.r[1]);  // 06056F14 mov.l @r1,r9
    c.r[8] = c.r[7];  // 06056F16 mov r7,r8
    c.r[6] = c.r[5];  // 06056F18 mov r5,r6
    c.r[7] = 0x0u;  // 06056F1A mov #0,r7
L_06056F1C:
    c.r[1] = c.r[6];  // 06056F1C mov r6,r1
    c.r[1] += 1;  // 06056F1E add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06056F20 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06056F22 extu.b r1,r1
    c.r[2] = c.r[1];  // 06056F24 mov r1,r2
    c.r[2] <<= 2;  // 06056F26 shll2 r2
    c.r[2] += c.r[1];  // 06056F28 add r1,r2
    c.r[2] <<= 2;  // 06056F2A shll2 r2
    c.r[2] += c.r[9];  // 06056F2C add r9,r2
    c.r[1] = c.r[2];  // 06056F2E mov r2,r1
    c.r[1] += 51;  // 06056F30 add #51,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06056F32 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06056F34 mov r1,r0
    c.r[0] >>= 2;  // 06056F36 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06056F38 shlr r0
    c.r[0] &= 0x1u;  // 06056F3A and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06056F3C tst r0,r0
    { const bool k = !c.t; c.r[2] += 50; if (k) { goto L_06056F4C; } }  // 06056F3E bf/s 0x06056F4C ; add #50,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06056F42 mov.b @r2,r0
    c.r[1] = c.r[4] & 0xFFFFu;  // 06056F44 extu.w r4,r1
    c.r[0] &= 0x3Fu;  // 06056F46 and #63,r0
    c.t = c.r[0] == c.r[1];  // 06056F48 cmp/eq r1,r0
    if (c.t) { goto L_06056F56; }  // 06056F4A bt 0x06056F56
L_06056F4C:
    c.r[6] += 2;  // 06056F4C add #2,r6
    c.r[3] += 1;  // 06056F4E add #1,r3
    c.t = (int32_t)c.r[3] >= (int32_t)c.r[8];  // 06056F50 cmp/ge r8,r3
    { const bool k = !c.t; c.r[7] += 2; if (k) { SH2_POLL(c); goto L_06056F1C; } }  // 06056F52 bf/s 0x06056F1C ; add #2,r7
L_06056F56:
    c.r[1] = ld32(0x06056F78u);  // 06056F56 mov.l 0x06056F78,r1
    c.r[1] = ld32(c.r[1]);  // 06056F58 mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06056F74u);  // 06056F5A mov.w 0x06056F74,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06056F5C mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06056F5E extu.b r1,r1
    c.t = c.r[3] == c.r[1];  // 06056F60 cmp/eq r1,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x06056F76u);  // 06056F62 mov.w 0x06056F76,r1
    if (c.t) { goto L_06056F68; }  // 06056F64 bt 0x06056F68
    c.r[1] = c.r[3] & 0xFFu;  // 06056F66 extu.b r3,r1
L_06056F68:
    c.r[15] = c.r[14];  // 06056F68 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06056F6A mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06056F6C mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06056F6E mov.l @r15+,r8
    { const uint32_t x = c.pr; c.r[0] = c.r[1]; c.pc = x; return; }  // 06056F70 rts ; mov r1,r0
}

void f_06056F80(SH2Context& c) {
    ran[1337] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06056F80 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06056F82 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06056F84 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06056F86 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06056F88 mov r15,r14
    c.r[4] = c.r[4] & 0xFFu;  // 06056F8A extu.b r4,r4
    c.r[6] = 0x0u;  // 06056F8C mov #0,r6
    c.r[1] = ld32(0x06057018u);  // 06056F8E mov.l 0x06057018,r1
    c.r[8] = ld32(c.r[1]);  // 06056F90 mov.l @r1,r8
    c.r[9] = (uint32_t)(int16_t)ld16(0x06057014u);  // 06056F92 mov.w 0x06057014,r9
    c.r[10] = ld32(0x0605701Cu);  // 06056F94 mov.l 0x0605701C,r10
    c.r[5] = 0x0u;  // 06056F96 mov #0,r5
    c.r[7] = c.r[8];  // 06056F98 mov r8,r7
L_06056F9A:
    c.r[0] = c.r[5];  // 06056F9A mov r5,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 06056F9C mov.b @(r0,r8),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06056F9E extu.b r1,r1
    c.t = c.r[1] == c.r[9];  // 06056FA0 cmp/eq r9,r1
    { const bool k = c.t; c.r[1] = c.r[7]; if (k) { goto L_06056FF0; } }  // 06056FA2 bt/s 0x06056FF0 ; mov r7,r1
    c.r[1] += 7;  // 06056FA6 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06056FA8 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06056FAA mov r1,r0
    c.r[0] >>= 2;  // 06056FAC shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06056FAE shlr r0
    c.r[0] &= 0x1u;  // 06056FB0 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06056FB2 tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[7]; if (k) { goto L_06056FF0; } }  // 06056FB4 bf/s 0x06056FF0 ; mov r7,r1
    c.r[1] += 2;  // 06056FB8 add #2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06056FBA mov.b @r1,r2
    c.r[1] = ld32(0x06057020u);  // 06056FBC mov.l 0x06057020,r1
    c.r[3] = ld32(c.r[1]);  // 06056FBE mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06056FC0 extu.b r2,r2
    c.r[1] = 0x1Eu;  // 06056FC2 mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 06056FC4 mul.l r1,r2
    c.r[1] = c.macl;  // 06056FC6 sts macl,r1
    c.r[1] += c.r[3];  // 06056FC8 add r3,r1
    c.r[1] += 15;  // 06056FCA add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]); goto L_06056FE2;  // 06056FCC bra 0x06056FE2 ; mov.b @r1,r1
L_06056FD0:
    { const bool k = c.t; c.r[2] = c.r[3]; if (k) { goto L_06056FEA; } }  // 06056FD0 bt/s 0x06056FEA ; mov r3,r2
    c.r[2] += c.r[2];  // 06056FD4 add r2,r2
    c.r[2] += c.r[3];  // 06056FD6 add r3,r2
    c.r[1] = ld32(c.r[10]);  // 06056FD8 mov.l @r10,r1
    c.r[2] <<= 2;  // 06056FDA shll2 r2
    c.r[2] += c.r[1];  // 06056FDC add r1,r2
    c.r[2] += 8;  // 06056FDE add #8,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06056FE0 mov.b @r2,r1
L_06056FE2:
    c.r[3] = c.r[1] & 0xFFu;  // 06056FE2 extu.b r1,r3
    c.t = c.r[3] == c.r[4];  // 06056FE4 cmp/eq r4,r3
    { const bool k = !c.t; c.t = c.r[3] == c.r[9]; if (k) { SH2_POLL(c); goto L_06056FD0; } }  // 06056FE6 bf/s 0x06056FD0 ; cmp/eq r9,r3
L_06056FEA:
    c.t = c.r[3] == c.r[4];  // 06056FEA cmp/eq r4,r3
    { const bool k = c.t; c.r[0] = c.r[6]; if (k) { goto L_06056FFE; } }  // 06056FEC bt/s 0x06056FFE ; mov r6,r0
L_06056FF0:
    c.r[7] += 16;  // 06056FF0 add #16,r7
    c.r[6] += 1;  // 06056FF2 add #1,r6
    c.r[1] = 0x49u;  // 06056FF4 mov #73,r1
    c.t = (int32_t)c.r[6] > (int32_t)c.r[1];  // 06056FF6 cmp/gt r1,r6
    { const bool k = !c.t; c.r[5] += 16; if (k) { SH2_POLL(c); goto L_06056F9A; } }  // 06056FF8 bf/s 0x06056F9A ; add #16,r5
    c.r[0] = c.r[6];  // 06056FFC mov r6,r0
L_06056FFE:
    c.t = c.r[0] == 0x4Au;  // 06056FFE cmp/eq #74,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x06057014u);  // 06057000 mov.w 0x06057014,r1
    if (c.t) { goto L_06057006; }  // 06057002 bt 0x06057006
    c.r[1] = c.r[6] & 0xFFu;  // 06057004 extu.b r6,r1
L_06057006:
    c.r[15] = c.r[14];  // 06057006 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06057008 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0605700A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0605700C mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0605700E mov.l @r15+,r8
    { const uint32_t x = c.pr; c.r[0] = c.r[1]; c.pc = x; return; }  // 06057010 rts ; mov r1,r0
}

void f_06057024(SH2Context& c) {
    ran[1338] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06057024 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06057026 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06057028 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0605702A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0605702C mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0605702E mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06057030 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06057032 sts.l pr,@-r15
    c.r[15] -= 4;  // 06057034 add #-4,r15
    c.r[14] = c.r[15];  // 06057036 mov r15,r14
    st32(c.r[14], c.r[4]);  // 06057038 mov.l r4,@r14
    c.r[12] = 0x0u;  // 0605703A mov #0,r12
    c.r[13] = ld32(0x06057164u);  // 0605703C mov.l 0x06057164,r13
    c.r[11] = ld32(0x06057168u);  // 0605703E mov.l 0x06057168,r11
    c.r[9] = ld32(c.r[14]);  // 06057040 mov.l @r14,r9
L_06057042:
    c.r[1] = c.r[9];  // 06057042 mov r9,r1
    c.r[1] += 44;  // 06057044 add #44,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06057046 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06057048 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605704A tst r1,r1
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_06057140; } }  // 0605704C bt/s 0x06057140 ; mov r9,r1
    c.r[1] += 50;  // 06057050 add #50,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06057052 mov.b @r1,r1
    c.r[10] = c.r[1] & 0xFFu;  // 06057054 extu.b r1,r10
    c.r[10] >>= 2;  // 06057056 shlr2 r10
    c.r[10] >>= 2;  // 06057058 shlr2 r10
    c.r[10] >>= 2;  // 0605705A shlr2 r10
    c.r[0] = c.r[10];  // 0605705C mov r10,r0
    c.t = c.r[0] == 0x1u;  // 0605705E cmp/eq #1,r0
    { const bool k = !c.t; c.r[5] = 0x22u; if (k) { goto L_06057140; } }  // 06057060 bf/s 0x06057140 ; mov #34,r5
    { const uint32_t x = c.r[11]; c.pr = 0x06057068u; c.r[4] = c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06057068u) return; }  // 06057064 jsr @r11 ; mov r13,r4
    c.r[5] = 0x0u;  // 06057068 mov #0,r5
    { const uint32_t x = c.r[11]; c.pr = 0x0605706Eu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605706Eu) return; }  // 0605706A jsr @r11 ; mov r0,r4
    c.r[1] = ld32(c.r[14]);  // 0605706E mov.l @r14,r1
    c.r[1] += 37;  // 06057070 add #37,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06057072 mov.b @r1,r1
    c.r[5] = 0x22u;  // 06057074 mov #34,r5
    c.r[1] = c.r[1] & 0xFFu;  // 06057076 extu.b r1,r1
    c.r[1] >>= 2;  // 06057078 shlr2 r1
    c.r[1] >>= 2;  // 0605707A shlr2 r1
    c.r[2] = c.r[1];  // 0605707C mov r1,r2
    c.r[2] <<= 2;  // 0605707E shll2 r2
    c.r[2] += c.r[1];  // 06057080 add r1,r2
    c.r[2] += c.r[0];  // 06057082 add r0,r2
    c.r[2] += 3;  // 06057084 add #3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06057086 mov.b @r2,r1
    c.r[4] = c.r[13];  // 06057088 mov r13,r4
    { const uint32_t x = c.r[11]; c.pr = 0x0605708Eu; c.r[8] = c.r[1] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605708Eu) return; }  // 0605708A jsr @r11 ; extu.b r1,r8
    c.r[5] = c.r[10];  // 0605708E mov r10,r5
    { const uint32_t x = c.r[11]; c.pr = 0x06057094u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06057094u) return; }  // 06057090 jsr @r11 ; mov r0,r4
    c.r[5] = c.r[8];  // 06057094 mov r8,r5
    { const uint32_t x = c.r[11]; c.pr = 0x0605709Au; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605709Au) return; }  // 06057096 jsr @r11 ; mov r0,r4
    c.t = (c.r[8] & c.r[8]) == 0;  // 0605709A tst r8,r8
    { const bool k = c.t; c.r[2] = c.r[0]; if (k) { goto L_060570AE; } }  // 0605709C bt/s 0x060570AE ; mov r0,r2
    c.r[1] = c.r[2];  // 060570A0 mov r2,r1
    c.r[1] += 11;  // 060570A2 add #11,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060570A4 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060570A6 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060570A8 tst r1,r1
    { const bool k = !c.t; c.t = (c.r[8] & c.r[8]) == 0; if (k) { goto L_060570BA; } }  // 060570AA bf/s 0x060570BA ; tst r8,r8
L_060570AE:
    c.r[1] = c.r[9];  // 060570AE mov r9,r1
    c.r[1] += 56;  // 060570B0 add #56,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060570B2 mov.b @r1,r0
    c.r[0] &= 0xCFu;  // 060570B4 and #207,r0
    st8(c.r[1], c.r[0]);  // 060570B6 mov.b r0,@r1
    c.t = (c.r[8] & c.r[8]) == 0;  // 060570B8 tst r8,r8
L_060570BA:
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_060570CC; } }  // 060570BA bt/s 0x060570CC ; mov r9,r1
    c.r[1] = c.r[2];  // 060570BE mov r2,r1
    c.r[1] += 1;  // 060570C0 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060570C2 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060570C4 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060570C6 tst r1,r1
    { const bool k = !c.t; c.r[1] = c.r[9]; if (k) { goto L_060570D4; } }  // 060570C8 bf/s 0x060570D4 ; mov r9,r1
L_060570CC:
    c.r[1] += 56;  // 060570CC add #56,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060570CE mov.b @r1,r0
    c.r[0] &= 0x3Fu;  // 060570D0 and #63,r0
    st8(c.r[1], c.r[0]);  // 060570D2 mov.b r0,@r1
L_060570D4:
    c.t = (c.r[8] & c.r[8]) == 0;  // 060570D4 tst r8,r8
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_060570E6; } }  // 060570D6 bt/s 0x060570E6 ; mov r9,r1
    c.r[2] += 24;  // 060570DA add #24,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060570DC mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060570DE extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060570E0 tst r1,r1
    { const bool k = !c.t; c.r[1] = c.r[9]; if (k) { goto L_060570EE; } }  // 060570E2 bf/s 0x060570EE ; mov r9,r1
L_060570E6:
    c.r[1] += 56;  // 060570E6 add #56,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060570E8 mov.b @r1,r0
    c.r[0] &= 0xFCu;  // 060570EA and #252,r0
    st8(c.r[1], c.r[0]);  // 060570EC mov.b r0,@r1
L_060570EE:
    c.r[5] = 0x22u;  // 060570EE mov #34,r5
    { const uint32_t x = c.r[11]; c.pr = 0x060570F4u; c.r[4] = c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060570F4u) return; }  // 060570F0 jsr @r11 ; mov r13,r4
    c.r[5] = 0x0u;  // 060570F4 mov #0,r5
    { const uint32_t x = c.r[11]; c.pr = 0x060570FAu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060570FAu) return; }  // 060570F6 jsr @r11 ; mov r0,r4
    c.r[1] = ld32(c.r[14]);  // 060570FA mov.l @r14,r1
    c.r[1] += 37;  // 060570FC add #37,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060570FE mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06057100 extu.b r1,r1
    c.r[1] >>= 2;  // 06057102 shlr2 r1
    c.r[1] >>= 2;  // 06057104 shlr2 r1
    c.r[2] = c.r[1];  // 06057106 mov r1,r2
    c.r[2] <<= 2;  // 06057108 shll2 r2
    c.r[2] += c.r[1];  // 0605710A add r1,r2
    c.r[2] += c.r[0];  // 0605710C add r0,r2
    c.r[2] += 2;  // 0605710E add #2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06057110 mov.b @r2,r1
    c.r[8] = c.r[1] & 0xFFu;  // 06057112 extu.b r1,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 06057114 tst r8,r8
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_06057138; } }  // 06057116 bt/s 0x06057138 ; mov r9,r1
    c.r[5] = 0x22u;  // 0605711A mov #34,r5
    { const uint32_t x = c.r[11]; c.pr = 0x06057120u; c.r[4] = c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06057120u) return; }  // 0605711C jsr @r11 ; mov r13,r4
    c.r[5] = 0x1u;  // 06057120 mov #1,r5
    { const uint32_t x = c.r[11]; c.pr = 0x06057126u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06057126u) return; }  // 06057122 jsr @r11 ; mov r0,r4
    c.r[5] = c.r[8];  // 06057126 mov r8,r5
    { const uint32_t x = c.r[11]; c.pr = 0x0605712Cu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605712Cu) return; }  // 06057128 jsr @r11 ; mov r0,r4
    c.r[0] += 21;  // 0605712C add #21,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0605712E mov.b @r0,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06057130 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06057132 tst r1,r1
    { const bool k = !c.t; c.r[1] = c.r[9]; if (k) { goto L_06057140; } }  // 06057134 bf/s 0x06057140 ; mov r9,r1
L_06057138:
    c.r[1] += 56;  // 06057138 add #56,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605713A mov.b @r1,r0
    c.r[0] &= 0xF3u;  // 0605713C and #243,r0
    st8(c.r[1], c.r[0]);  // 0605713E mov.b r0,@r1
L_06057140:
    c.r[12] += 1;  // 06057140 add #1,r12
    c.r[1] = 0xFu;  // 06057142 mov #15,r1
    c.t = (int32_t)c.r[12] > (int32_t)c.r[1];  // 06057144 cmp/gt r1,r12
    { const bool k = c.t; c.r[9] += 20; if (k) { goto L_0605714E; } }  // 06057146 bt/s 0x0605714E ; add #20,r9
    SH2_POLL(c); goto L_06057042;  // 0605714A bra 0x06057042 ; nop
L_0605714E:
    c.r[14] += 4;  // 0605714E add #4,r14
    c.r[15] = c.r[14];  // 06057150 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06057152 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06057154 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06057156 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06057158 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0605715A mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0605715C mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0605715E mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06057160 rts ; mov.l @r15+,r8
}

void f_0605716C(SH2Context& c) {
    ran[1339] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0605716C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0605716E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06057170 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06057172 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06057174 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06057176 mov r15,r14
    c.r[4] = c.r[4] & 0xFFu;  // 06057178 extu.b r4,r4
    c.r[8] = 0x1u;  // 0605717A mov #1,r8
    c.r[1] = ld32(0x060571F8u);  // 0605717C mov.l 0x060571F8,r1
    c.r[1] = ld32(c.r[1]);  // 0605717E mov.l @r1,r1
    c.r[4] <<= 2;  // 06057180 shll2 r4
    c.r[4] <<= 2;  // 06057182 shll2 r4
    c.r[4] += c.r[1];  // 06057184 add r1,r4
    c.r[4] += 2;  // 06057186 add #2,r4
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[4]);  // 06057188 mov.b @r4,r2
    c.r[1] = 0x1Eu;  // 0605718A mov #30,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0605718C extu.b r2,r2
    c.macl = c.r[2] * c.r[1];  // 0605718E mul.l r1,r2
    c.r[10] = ld32(0x060571FCu);  // 06057190 mov.l 0x060571FC,r10
    c.r[3] = ld32(c.r[10]);  // 06057192 mov.l @r10,r3
    c.r[9] = c.macl;  // 06057194 sts macl,r9
    c.r[0] = c.r[9];  // 06057196 mov r9,r0
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[3]);  // 06057198 mov.w @(r0,r3),r5
    c.r[4] = 0x0u;  // 0605719A mov #0,r4
    c.r[0] = ld32(0x06057200u);  // 0605719C mov.l 0x06057200,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060571A2u; c.r[5] = c.r[5] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060571A2u) return; }  // 0605719E jsr @r0 ; extu.w r5,r5
    c.r[1] = c.r[0];  // 060571A2 mov r0,r1
    c.r[2] = c.r[1] & 0xFFFFu;  // 060571A4 extu.w r1,r2
    c.r[1] = ld32(0x06057204u);  // 060571A6 mov.l 0x06057204,r1
    c.t = c.r[2] == c.r[1];  // 060571A8 cmp/eq r1,r2
    if (c.t) { goto L_060571E6; }  // 060571AA bt 0x060571E6
    c.r[2] <<= 2;  // 060571AC shll2 r2
    c.r[1] = ld32(0x06057208u);  // 060571AE mov.l 0x06057208,r1
    c.r[1] = ld32(c.r[1]);  // 060571B0 mov.l @r1,r1
    c.r[1] += c.r[2];  // 060571B2 add r2,r1
    c.r[1] += 22;  // 060571B4 add #22,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060571B6 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060571B8 extu.b r1,r1
    c.r[0] = c.r[1];  // 060571BA mov r1,r0
    c.r[0] >>= 2;  // 060571BC shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060571BE shlr r0
    c.r[0] >>= 2;  // 060571C0 shlr2 r0
    c.r[0] &= 0x1u;  // 060571C2 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060571C4 tst r0,r0
    { const bool k = !c.t; c.r[1] >>= 2; if (k) { goto L_060571E8; } }  // 060571C6 bf/s 0x060571E8 ; shlr2 r1
    c.r[1] >>= 2;  // 060571CA shlr2 r1
    c.r[1] >>= 2;  // 060571CC shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060571CE tst r1,r1
    if (!c.t) { goto L_060571E8; }  // 060571D0 bf 0x060571E8
    c.r[1] = ld32(c.r[10]);  // 060571D2 mov.l @r10,r1
    c.r[9] += c.r[1];  // 060571D4 add r1,r9
    c.r[9] += 24;  // 060571D6 add #24,r9
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]);  // 060571D8 mov.w @r9,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 060571DA extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060571DC tst r1,r1
    if (!c.t) { goto L_060571E8; }  // 060571DE bf 0x060571E8
    c.r[8] = 0x0u;  // 060571E0 mov #0,r8
    c.r[15] = c.r[14]; goto L_060571EA;  // 060571E2 bra 0x060571EA ; mov r14,r15
L_060571E6:
    c.r[8] = c.r[2];  // 060571E6 mov r2,r8
L_060571E8:
    c.r[15] = c.r[14];  // 060571E8 mov r14,r15
L_060571EA:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060571EA lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060571EC mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060571EE mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060571F0 mov.l @r15+,r9
    c.r[0] = c.r[8];  // 060571F2 mov r8,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060571F4 rts ; mov.l @r15+,r8
}

void f_0605720C(SH2Context& c) {
    ran[1340] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0605720C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0605720E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06057210 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06057212 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06057214 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06057216 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06057218 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0605721A sts.l pr,@-r15
    c.r[15] -= 16;  // 0605721C add #-16,r15
    c.r[14] = c.r[15];  // 0605721E mov r15,r14
    st32(c.r[14] + 4, c.r[7]);  // 06057220 mov.l r7,@(4,r14)
    c.r[4] = c.r[4] & 0xFFu;  // 06057222 extu.b r4,r4
    st32(c.r[14], c.r[4]);  // 06057224 mov.l r4,@r14
    c.r[13] = c.r[5] & 0xFFu;  // 06057226 extu.b r5,r13
    c.r[11] = c.r[6];  // 06057228 mov r6,r11
    c.r[1] = ld32(0x06057324u);  // 0605722A mov.l 0x06057324,r1
    c.r[9] = ld32(c.r[14] + 4);  // 0605722C mov.l @(4,r14),r9
    c.r[4] = 0x1u;  // 0605722E mov #1,r4
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06057230 mov.b @r1,r0
    c.r[10] = c.r[9];  // 06057232 mov r9,r10
    c.r[1] = 0xFu;  // 06057234 mov #15,r1
    c.r[1] &= c.r[0];  // 06057236 and r0,r1
    c.r[0] = ld32(0x06057328u);  // 06057238 mov.l 0x06057328,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0605723Eu; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605723Eu) return; }  // 0605723A jsr @r0 ; mov r1,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605731Au);  // 0605723E mov.w 0x0605731A,r1
    c.r[0] &= c.r[1];  // 06057240 and r1,r0
    c.r[1] = ld32(0x0605732Cu);  // 06057242 mov.l 0x0605732C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06057248u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06057248u) return; }  // 06057244 jsr @r1 ; mov r0,r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 06057248 tst r4,r4
    { const bool k = !c.t; c.r[12] = 0x0u; if (k) { goto L_06057250; } }  // 0605724A bf/s 0x06057250 ; mov #0,r12
    c.r[12] = 0x2u;  // 0605724E mov #2,r12
L_06057250:
    c.r[4] = ld32(0x06057330u);  // 06057250 mov.l 0x06057330,r4
    c.r[8] = ld32(0x06057334u);  // 06057252 mov.l 0x06057334,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06057258u; c.r[5] = 0x22u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06057258u) return; }  // 06057254 jsr @r8 ; mov #34,r5
    c.r[1] = c.r[0];  // 06057258 mov r0,r1
    c.r[5] = 0x1u;  // 0605725A mov #1,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06057260u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06057260u) return; }  // 0605725C jsr @r8 ; mov r1,r4
    c.r[1] = c.r[0];  // 06057260 mov r0,r1
    c.r[5] = c.r[12];  // 06057262 mov r12,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06057268u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06057268u) return; }  // 06057264 jsr @r8 ; mov r1,r4
    st32(c.r[14] + 8, c.r[0]);  // 06057268 mov.l r0,@(8,r14)
    c.r[6] = 0x0u;  // 0605726A mov #0,r6
    c.r[5] = 0x3Fu;  // 0605726C mov #63,r5
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605731Cu);  // 0605726E mov.w 0x0605731C,r3
    c.r[2] = c.r[11];  // 06057270 mov r11,r2
L_06057272:
    c.r[1] = 0x0u;  // 06057272 mov #0,r1
L_06057274:
    c.r[0] = c.r[1];  // 06057274 mov r1,r0
    c.r[0] += c.r[0];  // 06057276 add r0,r0
    c.r[1] += 1;  // 06057278 add #1,r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[5];  // 0605727A cmp/gt r5,r1
    { const bool k = !c.t; st16(c.r[0] + c.r[2], c.r[3]); if (k) { SH2_POLL(c); goto L_06057274; } }  // 0605727C bf/s 0x06057274 ; mov.w r3,@(r0,r2)
    c.r[7] = (uint32_t)(int16_t)ld16(0x0605731Eu);  // 06057280 mov.w 0x0605731E,r7
    c.r[6] += 1;  // 06057282 add #1,r6
    c.r[1] = 0x3Fu;  // 06057284 mov #63,r1
    c.t = (int32_t)c.r[6] > (int32_t)c.r[1];  // 06057286 cmp/gt r1,r6
    { const bool k = !c.t; c.r[2] += c.r[7]; if (k) { SH2_POLL(c); goto L_06057272; } }  // 06057288 bf/s 0x06057272 ; add r7,r2
    c.r[3] = ld32(c.r[14]);  // 0605728C mov.l @r14,r3
    c.r[3] += c.r[3];  // 0605728E add r3,r3
    c.r[1] = 0x0u;  // 06057290 mov #0,r1
    c.r[0] = c.r[3];  // 06057292 mov r3,r0
    c.macl = c.r[13] * c.r[7];  // 06057294 mul.l r7,r13
    c.r[12] = ld32(0x06057338u);  // 06057296 mov.l 0x06057338,r12
    c.r[8] = c.r[7];  // 06057298 mov r7,r8
    c.r[2] = c.macl;  // 0605729A sts macl,r2
    c.r[2] += c.r[11];  // 0605729C add r11,r2
    st16(c.r[0] + c.r[2], c.r[1]);  // 0605729E mov.w r1,@(r0,r2)
    c.r[0] = ld32(c.r[14]);  // 060572A0 mov.l @r14,r0
L_060572A2:
    c.r[6] = 0x1u;  // 060572A2 mov #1,r6
    c.r[0] += c.r[0];  // 060572A4 add r0,r0
    st32(c.r[14] + 12, c.r[0]);  // 060572A6 mov.l r0,@(12,r14)
L_060572A8:
    c.r[2] = c.r[6];  // 060572A8 mov r6,r2
    c.r[2] >>= 2;  // 060572AA shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 060572AC shlr r2
    c.r[0] = 0x1u;  // 060572AE mov #1,r0
    c.r[2] &= c.r[0];  // 060572B0 and r0,r2
    c.r[2] += c.r[13];  // 060572B2 add r13,r2
    c.r[1] = c.r[6];  // 060572B4 mov r6,r1
    c.r[1] >>= 2;  // 060572B6 shlr2 r1
    c.r[1] &= c.r[0];  // 060572B8 and r0,r1
    c.r[2] -= c.r[1];  // 060572BA sub r1,r2
    c.r[7] = c.r[2] & 0xFFu;  // 060572BC extu.b r2,r7
    c.r[4] = c.r[7];  // 060572BE mov r7,r4
    c.r[2] = 0x2u;  // 060572C0 mov #2,r2
    c.r[2] &= c.r[6];  // 060572C2 and r6,r2
    c.t = c.r[2] & 1; c.r[2] = (uint32_t)((int32_t)c.r[2] >> 1);  // 060572C4 shar r2
    c.r[1] = 0x1u;  // 060572C6 mov #1,r1
    c.r[0] = ld32(c.r[14]);  // 060572C8 mov.l @r14,r0
    c.r[1] &= c.r[6];  // 060572CA and r6,r1
    c.r[2] += c.r[0];  // 060572CC add r0,r2
    c.r[2] -= c.r[1];  // 060572CE sub r1,r2
    c.r[3] = c.r[2] & 0xFFu;  // 060572D0 extu.b r2,r3
    c.r[1] = c.r[12];  // 060572D2 mov r12,r1
    c.r[1] += 76;  // 060572D4 add #76,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060572D6 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060572D8 extu.b r1,r1
    c.t = c.r[3] > c.r[1];  // 060572DA cmp/hi r1,r3
    { const bool k = c.t; c.r[5] = c.r[3]; if (k) { goto L_06057372; } }  // 060572DC bt/s 0x06057372 ; mov r3,r5
    c.r[1] = c.r[12];  // 060572E0 mov r12,r1
    c.r[1] += 77;  // 060572E2 add #77,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060572E4 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060572E6 extu.b r1,r1
    c.t = c.r[7] > c.r[1];  // 060572E8 cmp/hi r1,r7
    if (c.t) { goto L_06057372; }  // 060572EA bt 0x06057372
    c.r[0] = (uint32_t)(int16_t)ld16(0x06057320u);  // 060572EC mov.w 0x06057320,r0
    c.r[1] = ld32(c.r[0] + c.r[12]);  // 060572EE mov.l @(r0,r12),r1
    c.r[0] = c.r[7];  // 060572F0 mov r7,r0
    c.r[0] <<= 2;  // 060572F2 shll2 r0
    c.r[0] <<= 2;  // 060572F4 shll2 r0
    c.r[0] <<= 2;  // 060572F6 shll2 r0
    c.r[0] += c.r[1];  // 060572F8 add r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 060572FA mov.b @(r0,r3),r1
    c.r[2] = c.r[1] & 0xFFu;  // 060572FC extu.b r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 060572FE tst r2,r2
    { const bool k = c.t; c.r[0] = ld32(c.r[14] + 8); if (k) { goto L_0605730A; } }  // 06057300 bt/s 0x0605730A ; mov.l @(8,r14),r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06057304 mov.b @(r0,r2),r1
    c.r[2] = c.r[1] & 0xFFu;  // 06057306 extu.b r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06057308 tst r2,r2
L_0605730A:
    { const bool k = !c.t; c.macl = c.r[7] * c.r[8]; if (k) { goto L_0605733C; } }  // 0605730A bf/s 0x0605733C ; mul.l r8,r7
    c.r[3] += c.r[3];  // 0605730E add r3,r3
    c.r[1] = 0x0u;  // 06057310 mov #0,r1
    c.r[0] = c.macl;  // 06057312 sts macl,r0
    c.r[0] += c.r[11];  // 06057314 add r11,r0
    st16(c.r[0] + c.r[3], c.r[1]); goto L_06057372;  // 06057316 bra 0x06057372 ; mov.w r1,@(r0,r3)
L_0605733C:
    c.r[0] = 0x3Fu;  // 0605733C mov #63,r0
    c.macl = c.r[13] * c.r[8];  // 0605733E mul.l r8,r13
    c.r[2] &= c.r[0];  // 06057340 and r0,r2
    c.r[0] = ld32(c.r[14] + 12);  // 06057342 mov.l @(12,r14),r0
    c.r[1] = c.macl;  // 06057344 sts macl,r1
    c.r[1] += c.r[11];  // 06057346 add r11,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06057348 mov.w @(r0,r1),r1
    c.r[2] += c.r[1];  // 0605734A add r1,r2
    c.r[2] = c.r[2] & 0xFFFFu;  // 0605734C extu.w r2,r2
    c.r[0] = 0x1Eu;  // 0605734E mov #30,r0
    c.t = c.r[2] > c.r[0];  // 06057350 cmp/hi r0,r2
    { const bool k = c.t; c.r[3] = c.r[5]; if (k) { goto L_06057372; } }  // 06057352 bt/s 0x06057372 ; mov r5,r3
    c.macl = c.r[4] * c.r[8];  // 06057356 mul.l r8,r4
    c.r[3] += c.r[3];  // 06057358 add r3,r3
    c.r[0] = c.r[3];  // 0605735A mov r3,r0
    c.r[7] = c.macl;  // 0605735C sts macl,r7
    c.r[7] += c.r[11];  // 0605735E add r11,r7
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[7]);  // 06057360 mov.w @(r0,r7),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06057362 extu.w r1,r1
    c.t = c.r[1] > c.r[2];  // 06057364 cmp/hi r2,r1
    if (!c.t) { goto L_06057372; }  // 06057366 bf 0x06057372
    st16(c.r[0] + c.r[7], c.r[2]);  // 06057368 mov.w r2,@(r0,r7)
    c.r[4] <<= 8;  // 0605736A shll8 r4
    c.r[4] |= c.r[5];  // 0605736C or r5,r4
    st16(c.r[10], c.r[4]);  // 0605736E mov.w r4,@r10
    c.r[10] += 2;  // 06057370 add #2,r10
L_06057372:
    c.r[6] += c.r[6];  // 06057372 add r6,r6
    c.r[1] = 0xFu;  // 06057374 mov #15,r1
    c.t = (int32_t)c.r[6] > (int32_t)c.r[1];  // 06057376 cmp/gt r1,r6
    { const bool k = !c.t; c.r[1] = c.r[9]; if (k) { SH2_POLL(c); goto L_060572A8; } }  // 06057378 bf/s 0x060572A8 ; mov r9,r1
    c.r[1] += 1;  // 0605737C add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605737E mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06057380 extu.b r1,r1
    st32(c.r[14], c.r[1]);  // 06057382 mov.l r1,@r14
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]); c.r[9] += 2;  // 06057384 mov.w @r9+,r1
    c.r[0] = ld32(c.r[14] + 4);  // 06057386 mov.l @(4,r14),r0
    c.r[1] >>= 8;  // 06057388 shlr8 r1
    c.r[13] = c.r[1] & 0xFFu;  // 0605738A extu.b r1,r13
    c.r[1] = (uint32_t)(int16_t)ld16(0x060573C0u);  // 0605738C mov.w 0x060573C0,r1
    c.r[1] += c.r[0];  // 0605738E add r0,r1
    c.t = c.r[10] >= c.r[1];  // 06057390 cmp/hs r1,r10
    if (!c.t) { goto L_06057396; }  // 06057392 bf 0x06057396
    c.r[10] = ld32(c.r[14] + 4);  // 06057394 mov.l @(4,r14),r10
L_06057396:
    c.t = c.r[9] >= c.r[1];  // 06057396 cmp/hs r1,r9
    if (!c.t) { goto L_0605739C; }  // 06057398 bf 0x0605739C
    c.r[9] = ld32(c.r[14] + 4);  // 0605739A mov.l @(4,r14),r9
L_0605739C:
    c.r[1] = c.r[10];  // 0605739C mov r10,r1
    c.r[1] += 2;  // 0605739E add #2,r1
    c.t = c.r[9] == c.r[1];  // 060573A0 cmp/eq r1,r9
    { const bool k = c.t; c.r[0] = ld32(c.r[14]); if (k) { goto L_060573AA; } }  // 060573A2 bt/s 0x060573AA ; mov.l @r14,r0
    SH2_POLL(c); goto L_060572A2;  // 060573A6 bra 0x060572A2 ; nop
L_060573AA:
    c.r[14] += 16;  // 060573AA add #16,r14
    c.r[15] = c.r[14];  // 060573AC mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060573AE lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060573B0 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060573B2 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060573B4 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060573B6 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060573B8 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060573BA mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060573BC rts ; mov.l @r15+,r8
}

void f_060573C4(SH2Context& c) {
    ran[1341] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060573C4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060573C6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060573C8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060573CA mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060573CC mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060573CE mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060573D0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060573D2 sts.l pr,@-r15
    c.r[15] -= 28;  // 060573D4 add #-28,r15
    c.r[14] = c.r[15];  // 060573D6 mov r15,r14
    c.r[4] = c.r[4] & 0xFFu;  // 060573D8 extu.b r4,r4
    st32(c.r[14] + 8, c.r[4]);  // 060573DA mov.l r4,@(8,r14)
    c.r[5] = c.r[5] & 0xFFu;  // 060573DC extu.b r5,r5
    st32(c.r[14] + 12, c.r[5]);  // 060573DE mov.l r5,@(12,r14)
    c.r[6] = c.r[6] & 0xFFu;  // 060573E0 extu.b r6,r6
    c.r[7] = c.r[7] & 0xFFu;  // 060573E2 extu.b r7,r7
    c.r[0] = 0x40u;  // 060573E4 mov #64,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 060573E6 mov.l @(r0,r14),r0
    st32(c.r[14] + 16, c.r[0]);  // 060573E8 mov.l r0,@(16,r14)
    c.r[0] = c.r[4];  // 060573EA mov r4,r0
    c.t = c.r[0] == c.r[6];  // 060573EC cmp/eq r6,r0
    { const bool k = !c.t; c.r[2] = c.r[7]; if (k) { goto L_060573FE; } }  // 060573EE bf/s 0x060573FE ; mov r7,r2
    c.r[0] = c.r[5];  // 060573F2 mov r5,r0
    c.t = c.r[0] == c.r[7];  // 060573F4 cmp/eq r7,r0
    { const bool k = !c.t; c.r[13] = ld32(c.r[14] + 16); if (k) { goto L_060573FE; } }  // 060573F6 bf/s 0x060573FE ; mov.l @(16,r14),r13
    goto L_0605760E;  // 060573FA bra 0x0605760E ; nop
L_060573FE:
    c.r[0] = 0x44u;  // 060573FE mov #68,r0
    c.r[0] += c.r[14];  // 06057400 add r14,r0
    c.r[13] = ld32(c.r[14] + 60);  // 06057402 mov.l @(60,r14),r13
    c.r[12] = c.r[2];  // 06057404 mov r2,r12
    st32(c.r[14] + 20, c.r[13]);  // 06057406 mov.l r13,@(20,r14)
    c.r[11] = ld32(c.r[0]);  // 06057408 mov.l @r0,r11
    c.r[9] = 0x1u;  // 0605740A mov #1,r9
    c.r[13] = ld32(c.r[14] + 8);  // 0605740C mov.l @(8,r14),r13
    c.t = c.r[13] >= c.r[6];  // 0605740E cmp/hs r6,r13
    { const bool k = c.t; st32(c.r[14] + 24, c.r[6]); if (k) { goto L_06057450; } }  // 06057410 bt/s 0x06057450 ; mov.l r6,@(24,r14)
    c.r[2] = c.r[6];  // 06057414 mov r6,r2
    c.r[0] = ld32(c.r[14] + 12);  // 06057416 mov.l @(12,r14),r0
    c.r[1] = c.r[12];  // 06057418 mov r12,r1
    c.r[1] -= c.r[0];  // 0605741A sub r0,r1
    c.t = (int32_t)c.r[1] >= 0;  // 0605741C cmp/pz r1
    { const bool k = c.t; c.r[2] -= c.r[13]; if (k) { goto L_06057424; } }  // 0605741E bt/s 0x06057424 ; sub r13,r2
    c.r[1] = 0u - c.r[1];  // 06057422 neg r1,r1
L_06057424:
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 06057424 cmp/gt r1,r2
    { const bool k = !c.t; c.r[13] = ld32(c.r[14] + 12); if (k) { goto L_06057444; } }  // 06057426 bf/s 0x06057444 ; mov.l @(12,r14),r13
    c.t = c.r[13] >= c.r[12];  // 0605742A cmp/hs r12,r13
    { const bool k = c.t; c.r[0] = ld32(c.r[14] + 12); if (k) { goto L_06057438; } }  // 0605742C bt/s 0x06057438 ; mov.l @(12,r14),r0
    c.r[0] = c.r[9];  // 06057430 mov r9,r0
    c.r[9] = 0x2u;  // 06057432 mov #2,r9
    c.r[1] = 0x2u; goto L_06057442;  // 06057434 bra 0x06057442 ; mov #2,r1
L_06057438:
    c.t = c.r[0] > c.r[12];  // 06057438 cmp/hi r12,r0
    { const bool k = !c.t; c.r[0] = c.r[9]; if (k) { goto L_06057444; } }  // 0605743A bf/s 0x06057444 ; mov r9,r0
    c.r[9] = 0x2u;  // 0605743E mov #2,r9
    c.r[1] = 0x1u;  // 06057440 mov #1,r1
L_06057442:
    st8(c.r[0] + c.r[14], c.r[1]);  // 06057442 mov.b r1,@(r0,r14)
L_06057444:
    c.r[0] = c.r[9];  // 06057444 mov r9,r0
    c.r[1] = c.r[9];  // 06057446 mov r9,r1
    c.r[1] += 1;  // 06057448 add #1,r1
    c.r[9] = c.r[1] & 0xFFu;  // 0605744A extu.b r1,r9
    c.r[1] = 0x8u; goto L_06057490;  // 0605744C bra 0x06057490 ; mov #8,r1
L_06057450:
    c.r[13] = ld32(c.r[14] + 8);  // 06057450 mov.l @(8,r14),r13
    c.r[0] = ld32(c.r[14] + 24);  // 06057452 mov.l @(24,r14),r0
    c.t = c.r[13] > c.r[0];  // 06057454 cmp/hi r0,r13
    { const bool k = !c.t; c.r[2] = c.r[13]; if (k) { goto L_06057492; } }  // 06057456 bf/s 0x06057492 ; mov r13,r2
    c.r[1] = ld32(c.r[14] + 12);  // 0605745A mov.l @(12,r14),r1
    c.r[1] -= c.r[12];  // 0605745C sub r12,r1
    c.t = (int32_t)c.r[1] >= 0;  // 0605745E cmp/pz r1
    { const bool k = c.t; c.r[2] -= c.r[0]; if (k) { goto L_06057466; } }  // 06057460 bt/s 0x06057466 ; sub r0,r2
    c.r[1] = 0u - c.r[1];  // 06057464 neg r1,r1
L_06057466:
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 06057466 cmp/gt r1,r2
    { const bool k = !c.t; c.r[13] = ld32(c.r[14] + 12); if (k) { goto L_06057486; } }  // 06057468 bf/s 0x06057486 ; mov.l @(12,r14),r13
    c.t = c.r[13] >= c.r[12];  // 0605746C cmp/hs r12,r13
    { const bool k = c.t; c.r[0] = ld32(c.r[14] + 12); if (k) { goto L_0605747A; } }  // 0605746E bt/s 0x0605747A ; mov.l @(12,r14),r0
    c.r[0] = c.r[9];  // 06057472 mov r9,r0
    c.r[9] = 0x2u;  // 06057474 mov #2,r9
    c.r[1] = 0x2u; goto L_06057484;  // 06057476 bra 0x06057484 ; mov #2,r1
L_0605747A:
    c.t = c.r[0] > c.r[12];  // 0605747A cmp/hi r12,r0
    { const bool k = !c.t; c.r[0] = c.r[9]; if (k) { goto L_06057486; } }  // 0605747C bf/s 0x06057486 ; mov r9,r0
    c.r[9] = 0x2u;  // 06057480 mov #2,r9
    c.r[1] = 0x1u;  // 06057482 mov #1,r1
L_06057484:
    st8(c.r[0] + c.r[14], c.r[1]);  // 06057484 mov.b r1,@(r0,r14)
L_06057486:
    c.r[0] = c.r[9];  // 06057486 mov r9,r0
    c.r[1] = c.r[9];  // 06057488 mov r9,r1
    c.r[1] += 1;  // 0605748A add #1,r1
    c.r[9] = c.r[1] & 0xFFu;  // 0605748C extu.b r1,r9
    c.r[1] = 0x4u;  // 0605748E mov #4,r1
L_06057490:
    st8(c.r[0] + c.r[14], c.r[1]);  // 06057490 mov.b r1,@(r0,r14)
L_06057492:
    c.r[0] = c.r[9];  // 06057492 mov r9,r0
    c.t = c.r[0] == 0x2u;  // 06057494 cmp/eq #2,r0
    { const bool k = !c.t; c.r[13] = ld32(c.r[14] + 12); if (k) { goto L_060574B6; } }  // 06057496 bf/s 0x060574B6 ; mov.l @(12,r14),r13
    c.t = c.r[13] >= c.r[12];  // 0605749A cmp/hs r12,r13
    if (c.t) { goto L_060574A4; }  // 0605749C bt 0x060574A4
    c.r[9] = 0x3u;  // 0605749E mov #3,r9
    c.r[1] = 0x2u;  // 060574A0 mov #2,r1
    st8(c.r[0] + c.r[14], c.r[1]);  // 060574A2 mov.b r1,@(r0,r14)
L_060574A4:
    c.r[0] = ld32(c.r[14] + 12);  // 060574A4 mov.l @(12,r14),r0
    c.t = c.r[0] > c.r[12];  // 060574A6 cmp/hi r12,r0
    { const bool k = !c.t; c.r[0] = c.r[9]; if (k) { goto L_060574B6; } }  // 060574A8 bf/s 0x060574B6 ; mov r9,r0
    c.r[1] = c.r[9];  // 060574AC mov r9,r1
    c.r[1] += 1;  // 060574AE add #1,r1
    c.r[9] = c.r[1] & 0xFFu;  // 060574B0 extu.b r1,r9
    c.r[1] = 0x1u;  // 060574B2 mov #1,r1
    st8(c.r[0] + c.r[14], c.r[1]);  // 060574B4 mov.b r1,@(r0,r14)
L_060574B6:
    c.r[10] = 0x0u;  // 060574B6 mov #0,r10
    c.r[8] = 0x1u;  // 060574B8 mov #1,r8
L_060574BA:
    c.t = c.r[8] >= c.r[9];  // 060574BA cmp/hs r9,r8
    { const bool k = c.t; c.t = c.r[8] == c.r[9]; if (k) { goto L_060574E0; } }  // 060574BC bt/s 0x060574E0 ; cmp/eq r9,r8
    c.r[5] = c.r[10];  // 060574C0 mov r10,r5
    c.r[13] = ld32(0x06057630u);  // 060574C2 mov.l 0x06057630,r13
    { const uint32_t x = c.r[13]; c.pr = 0x060574C8u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060574C8u) return; }  // 060574C4 jsr @r13 ; mov r8,r4
    c.r[2] = c.r[0];  // 060574C8 mov r0,r2
    c.r[0] = c.r[14];  // 060574CA mov r14,r0
L_060574CC:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 060574CC mov.b @(r0,r8),r1
    c.r[1] = c.r[1] & 0xFFu;  // 060574CE extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 060574D0 cmp/eq r2,r1
    { const bool k = c.t; c.r[1] = c.r[8]; if (k) { goto L_060574DE; } }  // 060574D2 bt/s 0x060574DE ; mov r8,r1
    c.r[1] += 1;  // 060574D6 add #1,r1
    c.r[8] = c.r[1] & 0xFFu;  // 060574D8 extu.b r1,r8
    c.t = c.r[8] >= c.r[9];  // 060574DA cmp/hs r9,r8
    if (!c.t) { SH2_POLL(c); goto L_060574CC; }  // 060574DC bf 0x060574CC
L_060574DE:
    c.t = c.r[8] == c.r[9];  // 060574DE cmp/eq r9,r8
L_060574E0:
    { const bool k = !c.t; c.r[1] = c.r[10]; if (k) { goto L_060574FA; } }  // 060574E0 bf/s 0x060574FA ; mov r10,r1
    c.r[1] = c.r[9];  // 060574E4 mov r9,r1
    c.r[1] += 1;  // 060574E6 add #1,r1
    c.r[9] = c.r[1] & 0xFFu;  // 060574E8 extu.b r1,r9
    c.r[5] = c.r[10];  // 060574EA mov r10,r5
    c.r[13] = ld32(0x06057630u);  // 060574EC mov.l 0x06057630,r13
    { const uint32_t x = c.r[13]; c.pr = 0x060574F2u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060574F2u) return; }  // 060574EE jsr @r13 ; mov #1,r4
    c.r[1] = c.r[0];  // 060574F2 mov r0,r1
    c.r[0] = c.r[14];  // 060574F4 mov r14,r0
    st8(c.r[0] + c.r[8], c.r[1]);  // 060574F6 mov.b r1,@(r0,r8)
    c.r[1] = c.r[10];  // 060574F8 mov r10,r1
L_060574FA:
    c.r[1] += 1;  // 060574FA add #1,r1
    c.r[10] = c.r[1] & 0xFFu;  // 060574FC extu.b r1,r10
    c.r[1] = 0x3u;  // 060574FE mov #3,r1
    c.t = c.r[10] > c.r[1];  // 06057500 cmp/hi r1,r10
    { const bool k = !c.t; c.r[8] = 0x1u; if (k) { SH2_POLL(c); goto L_060574BA; } }  // 06057502 bf/s 0x060574BA ; mov #1,r8
    c.r[1] = c.r[14];  // 06057506 mov r14,r1
    c.r[1] += 1;  // 06057508 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605750A mov.b @r1,r1
    c.r[5] = (uint32_t)(int16_t)ld16(0x06057628u);  // 0605750C mov.w 0x06057628,r5
    c.r[4] = ld32(0x06057634u);  // 0605750E mov.l 0x06057634,r4
    st8(c.r[14], c.r[1]);  // 06057510 mov.b r1,@r14
    c.r[1] = ld32(c.r[14] + 24);  // 06057512 mov.l @(24,r14),r1
L_06057514:
    c.macl = c.r[12] * c.r[5];  // 06057514 mul.l r5,r12
L_06057516:
    c.r[13] = ld32(c.r[14] + 20);  // 06057516 mov.l @(20,r14),r13
    c.r[1] += c.r[1];  // 06057518 add r1,r1
    c.r[0] = c.r[1];  // 0605751A mov r1,r0
    c.r[2] = c.macl;  // 0605751C sts macl,r2
    c.r[2] += c.r[13];  // 0605751E add r13,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 06057520 mov.w @(r0,r2),r1
    c.r[7] = 0x0u;  // 06057522 mov #0,r7
    c.r[6] = c.r[1] & 0xFFFFu;  // 06057524 extu.w r1,r6
L_06057526:
    c.r[9] = 0x0u;  // 06057526 mov #0,r9
    c.r[0] = c.r[14];  // 06057528 mov r14,r0
L_0605752A:
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[9]);  // 0605752A mov.b @(r0,r9),r3
    c.r[2] = ld32(c.r[14] + 24);  // 0605752C mov.l @(24,r14),r2
    c.r[1] = 0x8u;  // 0605752E mov #8,r1
    c.r[13] = ld32(c.r[14] + 20);  // 06057530 mov.l @(20,r14),r13
    c.r[1] &= c.r[3];  // 06057532 and r3,r1
    c.r[1] >>= 2;  // 06057534 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06057536 shlr r1
    c.r[2] -= c.r[1];  // 06057538 sub r1,r2
    c.r[1] = 0x4u;  // 0605753A mov #4,r1
    c.r[1] &= c.r[3];  // 0605753C and r3,r1
    c.r[1] >>= 2;  // 0605753E shlr2 r1
    c.r[2] += c.r[1];  // 06057540 add r1,r2
    c.r[10] = c.r[2] & 0xFFu;  // 06057542 extu.b r2,r10
    c.r[1] = 0x2u;  // 06057544 mov #2,r1
    c.r[1] &= c.r[3];  // 06057546 and r3,r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06057548 shlr r1
    c.r[2] = c.r[12];  // 0605754A mov r12,r2
    c.r[2] -= c.r[1];  // 0605754C sub r1,r2
    c.r[1] = 0x1u;  // 0605754E mov #1,r1
    c.r[1] &= c.r[3];  // 06057550 and r3,r1
    c.r[2] += c.r[1];  // 06057552 add r1,r2
    c.r[8] = c.r[2] & 0xFFu;  // 06057554 extu.b r2,r8
    c.r[1] = c.r[10];  // 06057556 mov r10,r1
    c.macl = c.r[8] * c.r[5];  // 06057558 mul.l r5,r8
    c.r[1] += c.r[1];  // 0605755A add r1,r1
    c.r[0] = c.r[1];  // 0605755C mov r1,r0
    c.r[2] = c.macl;  // 0605755E sts macl,r2
    c.r[2] += c.r[13];  // 06057560 add r13,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 06057562 mov.w @(r0,r2),r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06057564 extu.w r1,r1
    c.t = c.r[6] > c.r[1];  // 06057566 cmp/hi r1,r6
    { const bool k = c.t; c.t = (c.r[1] & c.r[1]) == 0; if (k) { goto L_06057576; } }  // 06057568 bt/s 0x06057576 ; tst r1,r1
    c.t = (c.r[7] & c.r[7]) == 0;  // 0605756C tst r7,r7
    { const bool k = c.t; c.t = c.r[6] == c.r[1]; if (k) { goto L_060575AE; } }  // 0605756E bt/s 0x060575AE ; cmp/eq r1,r6
    { const bool k = !c.t; c.t = (c.r[1] & c.r[1]) == 0; if (k) { goto L_060575AE; } }  // 06057572 bf/s 0x060575AE ; tst r1,r1
L_06057576:
    { const bool k = !c.t; c.r[13] = ld32(c.r[14] + 12); if (k) { goto L_06057588; } }  // 06057576 bf/s 0x06057588 ; mov.l @(12,r14),r13
    c.t = c.r[8] == c.r[13];  // 0605757A cmp/eq r13,r8
    { const bool k = !c.t; c.r[1] = c.r[9]; if (k) { goto L_060575B0; } }  // 0605757C bf/s 0x060575B0 ; mov r9,r1
    c.r[0] = ld32(c.r[14] + 8);  // 06057580 mov.l @(8,r14),r0
    c.t = c.r[10] == c.r[0];  // 06057582 cmp/eq r0,r10
    { const bool k = !c.t; c.r[1] += 1; if (k) { goto L_060575B2; } }  // 06057584 bf/s 0x060575B2 ; add #1,r1
L_06057588:
    c.r[1] = c.r[4];  // 06057588 mov r4,r1
    c.r[1] += 76;  // 0605758A add #76,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605758C mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605758E extu.b r1,r1
    c.t = c.r[10] > c.r[1];  // 06057590 cmp/hi r1,r10
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_060575B0; } }  // 06057592 bt/s 0x060575B0 ; mov r9,r1
    c.r[13] = ld32(0x06057638u);  // 06057596 mov.l 0x06057638,r13
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 06057598 mov.b @r13,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605759A extu.b r1,r1
    c.t = c.r[8] > c.r[1];  // 0605759C cmp/hi r1,r8
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_060575B0; } }  // 0605759E bt/s 0x060575B0 ; mov r9,r1
    st8(c.r[11], c.r[3]);  // 060575A2 mov.b r3,@r11
    c.r[11] += 1;  // 060575A4 add #1,r11
    st32(c.r[14] + 24, c.r[10]);  // 060575A6 mov.l r10,@(24,r14)
    c.r[9] = (uint32_t)(int16_t)ld16(0x0605762Au);  // 060575A8 mov.w 0x0605762A,r9
    c.r[12] = c.r[8]; goto L_060575BC;  // 060575AA bra 0x060575BC ; mov r8,r12
L_060575AE:
    c.r[1] = c.r[9];  // 060575AE mov r9,r1
L_060575B0:
    c.r[1] += 1;  // 060575B0 add #1,r1
L_060575B2:
    c.r[9] = c.r[1] & 0xFFu;  // 060575B2 extu.b r1,r9
    c.r[1] = 0x4u;  // 060575B4 mov #4,r1
    c.t = c.r[9] > c.r[1];  // 060575B6 cmp/hi r1,r9
    { const bool k = !c.t; c.r[0] = c.r[14]; if (k) { SH2_POLL(c); goto L_0605752A; } }  // 060575B8 bf/s 0x0605752A ; mov r14,r0
L_060575BC:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0605762Au);  // 060575BC mov.w 0x0605762A,r0
    c.t = c.r[9] == c.r[0];  // 060575BE cmp/eq r0,r9
    { const bool k = !c.t; c.r[7] = 0x1u; if (k) { SH2_POLL(c); goto L_06057526; } }  // 060575C0 bf/s 0x06057526 ; mov #1,r7
    c.r[1] = c.r[11];  // 060575C4 mov r11,r1
    c.r[1] -= 1;  // 060575C6 add #-1,r1
    c.r[13] = 0x44u;  // 060575C8 mov #68,r13
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060575CA mov.b @r1,r1
    c.r[13] += c.r[14];  // 060575CC add r14,r13
    st8(c.r[14], c.r[1]);  // 060575CE mov.b r1,@r14
    c.r[13] = ld32(c.r[13]);  // 060575D0 mov.l @r13,r13
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605762Cu);  // 060575D2 mov.w 0x0605762C,r1
    c.r[1] += c.r[13];  // 060575D4 add r13,r1
    c.t = c.r[11] >= c.r[1];  // 060575D6 cmp/hs r1,r11
    { const bool k = !c.t; c.r[0] = 0x44u; if (k) { goto L_060575DE; } }  // 060575D8 bf/s 0x060575DE ; mov #68,r0
    c.r[11] = ld32(c.r[0] + c.r[14]);  // 060575DC mov.l @(r0,r14),r11
L_060575DE:
    c.r[13] = ld32(c.r[14] + 12);  // 060575DE mov.l @(12,r14),r13
    c.t = c.r[12] == c.r[13];  // 060575E0 cmp/eq r13,r12
    { const bool k = !c.t; c.r[1] = ld32(c.r[14] + 24); if (k) { SH2_POLL(c); goto L_06057514; } }  // 060575E2 bf/s 0x06057514 ; mov.l @(24,r14),r1
    c.r[0] = ld32(c.r[14] + 24);  // 060575E6 mov.l @(24,r14),r0
    c.r[13] = ld32(c.r[14] + 8);  // 060575E8 mov.l @(8,r14),r13
    c.t = c.r[0] == c.r[13];  // 060575EA cmp/eq r13,r0
    { const bool k = !c.t; c.macl = c.r[12] * c.r[5]; if (k) { SH2_POLL(c); goto L_06057516; } }  // 060575EC bf/s 0x06057516 ; mul.l r5,r12
    c.r[0] = 0x44u;  // 060575F0 mov #68,r0
    c.r[0] += c.r[14]; goto L_06057602;  // 060575F2 bra 0x06057602 ; add r14,r0
L_060575F6:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[11]);  // 060575F6 mov.b @r11,r1
    c.r[13] = ld32(c.r[14] + 16);  // 060575F8 mov.l @(16,r14),r13
    c.r[0] += c.r[14];  // 060575FA add r14,r0
    st8(c.r[13], c.r[1]);  // 060575FC mov.b r1,@r13
    c.r[13] += 1;  // 060575FE add #1,r13
    st32(c.r[14] + 16, c.r[13]);  // 06057600 mov.l r13,@(16,r14)
L_06057602:
    c.r[0] = ld32(c.r[0]);  // 06057602 mov.l @r0,r0
    c.r[11] -= 1;  // 06057604 add #-1,r11
    c.t = c.r[11] >= c.r[0];  // 06057606 cmp/hs r0,r11
    { const bool k = c.t; c.r[0] = 0x44u; if (k) { SH2_POLL(c); goto L_060575F6; } }  // 06057608 bt/s 0x060575F6 ; mov #68,r0
    c.r[13] = ld32(c.r[14] + 16);  // 0605760C mov.l @(16,r14),r13
L_0605760E:
    c.r[1] = 0xFFFFFFFFu;  // 0605760E mov #-1,r1
    st8(c.r[13], c.r[1]);  // 06057610 mov.b r1,@r13
    c.r[14] += 28;  // 06057612 add #28,r14
    c.r[15] = c.r[14];  // 06057614 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06057616 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06057618 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0605761A mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0605761C mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0605761E mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06057620 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06057622 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06057624 rts ; mov.l @r15+,r8
}

void f_0605763C(SH2Context& c) {
    ran[1342] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605763C mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0605763E mov r15,r14
    c.r[4] = c.r[4] & 0xFFu;  // 06057640 extu.b r4,r4
    c.r[7] = 0x0u;  // 06057642 mov #0,r7
    c.r[5] = ld32(0x06057698u);  // 06057644 mov.l 0x06057698,r5
    c.r[6] = (uint32_t)(int16_t)ld16(0x06057696u);  // 06057646 mov.w 0x06057696,r6
    c.r[3] = 0x0u;  // 06057648 mov #0,r3
L_0605764A:
    c.r[0] = ld32(c.r[5]);  // 0605764A mov.l @r5,r0
    c.r[2] = c.r[3];  // 0605764C mov r3,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0605764E mov.b @(r0,r3),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06057650 extu.b r1,r1
    c.t = c.r[1] == c.r[6];  // 06057652 cmp/eq r6,r1
    { const bool k = c.t; c.r[2] += c.r[0]; if (k) { goto L_06057686; } }  // 06057654 bt/s 0x06057686 ; add r0,r2
    c.r[1] = c.r[2];  // 06057658 mov r2,r1
    c.r[1] += 7;  // 0605765A add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605765C mov.b @r1,r1
    c.r[0] = c.r[1];  // 0605765E mov r1,r0
    c.r[0] >>= 2;  // 06057660 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06057662 shlr r0
    c.r[0] &= 0x1u;  // 06057664 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06057666 tst r0,r0
    if (!c.t) { goto L_06057686; }  // 06057668 bf 0x06057686
    c.r[2] += 8;  // 0605766A add #8,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605766C mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605766E extu.b r1,r1
    c.t = c.r[1] == c.r[4];  // 06057670 cmp/eq r4,r1
    if (!c.t) { goto L_06057676; }  // 06057672 bf 0x06057676
    st8(c.r[2], c.r[6]);  // 06057674 mov.b r6,@r2
L_06057676:
    c.r[2] = ld32(c.r[5]);  // 06057676 mov.l @r5,r2
    c.r[2] += c.r[3];  // 06057678 add r3,r2
    c.r[2] += 9;  // 0605767A add #9,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605767C mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605767E extu.b r1,r1
    c.t = c.r[1] == c.r[4];  // 06057680 cmp/eq r4,r1
    if (!c.t) { goto L_06057686; }  // 06057682 bf 0x06057686
    st8(c.r[2], c.r[6]);  // 06057684 mov.b r6,@r2
L_06057686:
    c.r[7] += 1;  // 06057686 add #1,r7
    c.r[1] = 0x49u;  // 06057688 mov #73,r1
    c.t = (int32_t)c.r[7] > (int32_t)c.r[1];  // 0605768A cmp/gt r1,r7
    { const bool k = !c.t; c.r[3] += 16; if (k) { SH2_POLL(c); goto L_0605764A; } }  // 0605768C bf/s 0x0605764A ; add #16,r3
    c.r[15] = c.r[14];  // 06057690 mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06057692 rts ; mov.l @r15+,r14
}

void f_0605769C(SH2Context& c) {
    ran[1343] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605769C mov.l r14,@-r15
    c.r[1] = ld32(0x060576F0u);  // 0605769E mov.l 0x060576F0,r1
    c.r[7] = ld32(c.r[1]);  // 060576A0 mov.l @r1,r7
    c.r[4] = c.r[4] & 0xFFu;  // 060576A2 extu.b r4,r4
    c.r[1] = c.r[4];  // 060576A4 mov r4,r1
    c.r[1] <<= 2;  // 060576A6 shll2 r1
    c.r[1] <<= 2;  // 060576A8 shll2 r1
    c.r[1] += c.r[7];  // 060576AA add r7,r1
    c.r[1] += 8;  // 060576AC add #8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060576AE mov.b @r1,r1
    c.r[6] = (uint32_t)(int16_t)ld16(0x060576EEu);  // 060576B0 mov.w 0x060576EE,r6
    c.r[2] = c.r[1] & 0xFFu;  // 060576B2 extu.b r1,r2
    c.t = c.r[2] == c.r[6];  // 060576B4 cmp/eq r6,r2
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_060576E6; } }  // 060576B6 bt/s 0x060576E6 ; mov r15,r14
    c.r[3] = c.r[2];  // 060576BA mov r2,r3
    c.r[3] <<= 2;  // 060576BC shll2 r3
    c.r[3] <<= 2;  // 060576BE shll2 r3
    c.r[3] += c.r[7];  // 060576C0 add r7,r3
    c.r[1] = c.r[3];  // 060576C2 mov r3,r1
    c.r[1] += 4;  // 060576C4 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060576C6 mov.b @r1,r1
    c.r[0] = c.r[1];  // 060576C8 mov r1,r0
    c.r[0] >>= 2;  // 060576CA shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060576CC shlr r0
    c.r[0] >>= 2;  // 060576CE shlr2 r0
    c.r[0] &= 0x1u;  // 060576D0 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060576D2 tst r0,r0
    { const bool k = c.t; c.r[15] = c.r[14]; if (k) { goto L_060576E8; } }  // 060576D4 bt/s 0x060576E8 ; mov r14,r15
    c.r[3] += 6;  // 060576D8 add #6,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060576DA mov.b @r3,r1
    c.r[0] = c.r[1] & 0xFFu;  // 060576DC extu.b r1,r0
    c.t = c.r[0] == c.r[4];  // 060576DE cmp/eq r4,r0
    { const bool k = !c.t; c.r[2] = c.r[0]; if (k) { goto L_060576E8; } }  // 060576E0 bf/s 0x060576E8 ; mov r0,r2
    c.r[2] = c.r[6];  // 060576E4 mov r6,r2
L_060576E6:
    c.r[15] = c.r[14];  // 060576E6 mov r14,r15
L_060576E8:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060576E8 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[2]; c.pc = x; return; }  // 060576EA rts ; mov r2,r0
}

void f_060576F4(SH2Context& c) {
    ran[1344] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060576F4 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 060576F6 mov r15,r14
    c.r[4] = c.r[4] & 0xFFFFu;  // 060576F8 extu.w r4,r4
    c.r[0] = 0x0u;  // 060576FA mov #0,r0
    c.r[3] = 0x6u;  // 060576FC mov #6,r3
    c.r[2] = ld32(0x06057718u);  // 060576FE mov.l 0x06057718,r2
L_06057700:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06057700 mov.b @(r0,r2),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06057702 extu.b r1,r1
    c.t = c.r[1] > c.r[4];  // 06057704 cmp/hi r4,r1
    { const bool k = c.t; c.r[1] = c.r[0]; if (k) { goto L_06057712; } }  // 06057706 bt/s 0x06057712 ; mov r0,r1
    c.r[1] += 1;  // 0605770A add #1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0605770C extu.b r1,r0
    c.t = c.r[0] > c.r[3];  // 0605770E cmp/hi r3,r0
    if (!c.t) { SH2_POLL(c); goto L_06057700; }  // 06057710 bf 0x06057700
L_06057712:
    c.r[15] = c.r[14];  // 06057712 mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06057714 rts ; mov.l @r15+,r14
}

void f_0605771C(SH2Context& c) {
    ran[1345] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0605771C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0605771E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06057720 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06057722 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06057724 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06057726 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06057728 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0605772A mov r15,r14
    c.r[11] = c.r[4] & 0xFFu;  // 0605772C extu.b r4,r11
    c.r[8] = 0x0u;  // 0605772E mov #0,r8
    c.r[2] = ld32(0x060577ACu);  // 06057730 mov.l 0x060577AC,r2
    c.r[1] = c.r[2];  // 06057732 mov r2,r1
    c.r[1] += 77;  // 06057734 add #77,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06057736 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06057738 extu.b r1,r1
    c.t = c.r[8] > c.r[1];  // 0605773A cmp/hi r1,r8
    { const bool k = c.t; c.r[9] = 0x0u; if (k) { goto L_06057792; } }  // 0605773C bt/s 0x06057792 ; mov #0,r9
    c.r[12] = ld32(0x060577B0u);  // 06057740 mov.l 0x060577B0,r12
    c.r[2] += 76;  // 06057742 add #76,r2
L_06057744:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06057744 mov.b @r2,r1
    c.r[8] = 0x0u;  // 06057746 mov #0,r8
    c.r[1] = c.r[1] & 0xFFu;  // 06057748 extu.b r1,r1
    c.t = c.r[8] > c.r[1];  // 0605774A cmp/hi r1,r8
    { const bool k = c.t; c.r[1] = c.r[9]; if (k) { goto L_0605777E; } }  // 0605774C bt/s 0x0605777E ; mov r9,r1
    c.r[10] = c.r[2];  // 06057750 mov r2,r10
    c.r[6] = 0x10u;  // 06057752 mov #16,r6
L_06057754:
    c.r[6] |= c.r[11];  // 06057754 or r11,r6
    c.r[7] = 0xFFFFFFFFu;  // 06057756 mov #-1,r7
    c.r[6] = c.r[6] & 0xFFu;  // 06057758 extu.b r6,r6
    c.r[5] = c.r[9];  // 0605775A mov r9,r5
    { const uint32_t x = c.r[12]; c.pr = 0x06057760u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06057760u) return; }  // 0605775C jsr @r12 ; mov r8,r4
    c.r[1] = (uint32_t)(int32_t)(int8_t)c.r[0];  // 06057760 exts.b r0,r1
    c.t = (int32_t)c.r[1] >= 0;  // 06057762 cmp/pz r1
    { const bool k = !c.t; c.r[1] = c.r[8]; if (k) { goto L_0605776E; } }  // 06057764 bf/s 0x0605776E ; mov r8,r1
    c.r[8] = (uint32_t)(int16_t)ld16(0x060577AAu);  // 06057768 mov.w 0x060577AA,r8
    c.r[9] = c.r[8];  // 0605776A mov r8,r9
    c.r[1] = c.r[8];  // 0605776C mov r8,r1
L_0605776E:
    c.r[1] += 1;  // 0605776E add #1,r1
    c.r[8] = c.r[1] & 0xFFu;  // 06057770 extu.b r1,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 06057772 mov.b @r10,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06057774 extu.b r1,r1
    c.t = c.r[8] > c.r[1];  // 06057776 cmp/hi r1,r8
    { const bool k = !c.t; c.r[6] = 0x10u; if (k) { SH2_POLL(c); goto L_06057754; } }  // 06057778 bf/s 0x06057754 ; mov #16,r6
    c.r[1] = c.r[9];  // 0605777C mov r9,r1
L_0605777E:
    c.r[1] += 1;  // 0605777E add #1,r1
    c.r[9] = c.r[1] & 0xFFu;  // 06057780 extu.b r1,r9
    c.r[2] = ld32(0x060577ACu);  // 06057782 mov.l 0x060577AC,r2
    c.r[1] = c.r[2];  // 06057784 mov r2,r1
    c.r[1] += 77;  // 06057786 add #77,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06057788 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0605778A extu.b r1,r1
    c.t = c.r[9] > c.r[1];  // 0605778C cmp/hi r1,r9
    { const bool k = !c.t; c.r[2] += 76; if (k) { SH2_POLL(c); goto L_06057744; } }  // 0605778E bf/s 0x06057744 ; add #76,r2
L_06057792:
    c.r[15] = c.r[14];  // 06057792 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06057794 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06057796 mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06057798 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0605779A mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0605779C mov.l @r15+,r10
    c.r[1] = 0x40u;  // 0605779E mov #64,r1
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060577A0 mov.l @r15+,r9
    c.t = c.r[8] > c.r[1];  // 060577A2 cmp/hi r1,r8
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060577A4 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.r[0] = c.t; c.pc = x; return; }  // 060577A6 rts ; movt r0
}

void f_060577B4(SH2Context& c) {
    ran[1346] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060577B4 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 060577B6 mov r15,r14
    c.r[2] = c.r[4] & 0xFFu;  // 060577B8 extu.b r4,r2
    c.r[6] = c.r[6] & 0xFFu;  // 060577BA extu.b r6,r6
    c.r[1] = ld32(0x06057864u);  // 060577BC mov.l 0x06057864,r1
    c.r[0] = c.r[2];  // 060577BE mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060577C0 mov.b @(r0,r1),r1
    c.t = (c.r[6] & c.r[6]) == 0;  // 060577C2 tst r6,r6
    { const bool k = c.t; c.r[1] = c.r[1] & 0xFFu; if (k) { goto L_060577CA; } }  // 060577C4 bt/s 0x060577CA ; extu.b r1,r1
    c.r[1] += c.r[1];  // 060577C8 add r1,r1
L_060577CA:
    c.r[1] = c.r[1] & 0xFFu;  // 060577CA extu.b r1,r1
    c.r[7] = c.r[1];  // 060577CC mov r1,r7
    c.r[1] = ld32(0x06057868u);  // 060577CE mov.l 0x06057868,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060577D0 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060577D2 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060577D4 tst r1,r1
    { const bool k = !c.t; c.r[0] = c.r[2]; if (k) { goto L_06057858; } }  // 060577D6 bf/s 0x06057858 ; mov r2,r0
    c.t = c.r[0] == 0x1Au;  // 060577DA cmp/eq #26,r0
    { const bool k = c.t; c.r[3] = c.r[5]; if (k) { goto L_060577EC; } }  // 060577DC bt/s 0x060577EC ; mov r5,r3
    c.t = c.r[0] == 0x1u;  // 060577E0 cmp/eq #1,r0
    { const bool k = c.t; c.r[3] += 30; if (k) { goto L_060577EE; } }  // 060577E2 bt/s 0x060577EE ; add #30,r3
    c.t = c.r[0] == 0x3u;  // 060577E6 cmp/eq #3,r0
    { const bool k = !c.t; c.r[3] = c.r[5]; if (k) { goto L_06057858; } }  // 060577E8 bf/s 0x06057858 ; mov r5,r3
L_060577EC:
    c.r[3] += 30;  // 060577EC add #30,r3
L_060577EE:
    c.r[6] = 0x4u;  // 060577EE mov #4,r6
    c.r[2] = 0x0u;  // 060577F0 mov #0,r2
    c.r[0] = c.r[3];  // 060577F2 mov r3,r0
L_060577F4:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 060577F4 mov.b @(r0,r2),r1
    c.r[1] = c.r[1] & 0xFFu;  // 060577F6 extu.b r1,r1
    c.r[0] = c.r[1];  // 060577F8 mov r1,r0
    c.t = c.r[0] == 0x52u;  // 060577FA cmp/eq #82,r0
    if (c.t) { goto L_06057806; }  // 060577FC bt 0x06057806
    c.r[2] += 1;  // 060577FE add #1,r2
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[6];  // 06057800 cmp/ge r6,r2
    { const bool k = !c.t; c.r[0] = c.r[3]; if (k) { SH2_POLL(c); goto L_060577F4; } }  // 06057802 bf/s 0x060577F4 ; mov r3,r0
L_06057806:
    c.r[0] = c.r[2];  // 06057806 mov r2,r0
    c.t = c.r[0] == 0x4u;  // 06057808 cmp/eq #4,r0
    { const bool k = c.t; c.r[1] = 0xFFFFFFFFu; if (k) { goto L_06057810; } }  // 0605780A bt/s 0x06057810 ; mov #-1,r1
    c.r[1] = c.r[2];  // 0605780E mov r2,r1
L_06057810:
    c.r[0] = (uint32_t)(int32_t)(int8_t)c.r[1];  // 06057810 exts.b r1,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 06057812 cmp/eq #-1,r0
    { const bool k = !c.t; c.r[3] = c.r[5]; if (k) { goto L_06057844; } }  // 06057814 bf/s 0x06057844 ; mov r5,r3
    c.r[3] += 30;  // 06057818 add #30,r3
    c.r[6] = 0x4u;  // 0605781A mov #4,r6
    c.r[2] = 0x0u;  // 0605781C mov #0,r2
    c.r[0] = c.r[3];  // 0605781E mov r3,r0
L_06057820:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06057820 mov.b @(r0,r2),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06057822 extu.b r1,r1
    c.r[0] = c.r[1];  // 06057824 mov r1,r0
    c.t = c.r[0] == 0x53u;  // 06057826 cmp/eq #83,r0
    if (c.t) { goto L_06057832; }  // 06057828 bt 0x06057832
    c.r[2] += 1;  // 0605782A add #1,r2
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[6];  // 0605782C cmp/ge r6,r2
    { const bool k = !c.t; c.r[0] = c.r[3]; if (k) { SH2_POLL(c); goto L_06057820; } }  // 0605782E bf/s 0x06057820 ; mov r3,r0
L_06057832:
    c.r[0] = c.r[2];  // 06057832 mov r2,r0
    c.t = c.r[0] == 0x4u;  // 06057834 cmp/eq #4,r0
    { const bool k = c.t; c.r[1] = 0xFFFFFFFFu; if (k) { goto L_0605783C; } }  // 06057836 bt/s 0x0605783C ; mov #-1,r1
    c.r[1] = c.r[2];  // 0605783A mov r2,r1
L_0605783C:
    c.r[0] = (uint32_t)(int32_t)(int8_t)c.r[1];  // 0605783C exts.b r1,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0605783E cmp/eq #-1,r0
    { const bool k = c.t; c.r[15] = c.r[14]; if (k) { goto L_0605785A; } }  // 06057840 bt/s 0x0605785A ; mov r14,r15
L_06057844:
    c.r[1] = c.r[7];  // 06057844 mov r7,r1
    c.r[1] += c.r[1];  // 06057846 add r1,r1
    c.r[1] += c.r[7];  // 06057848 add r7,r1
    c.t = (int32_t)c.r[1] >= 0;  // 0605784A cmp/pz r1
    if (c.t) { goto L_06057850; }  // 0605784C bt 0x06057850
    c.r[1] += 3;  // 0605784E add #3,r1
L_06057850:
    c.r[7] = c.r[1];  // 06057850 mov r1,r7
    c.r[7] >>= 2;  // 06057852 shlr2 r7
    c.r[0] = (uint32_t)(int16_t)ld16(0x06057860u);  // 06057854 mov.w 0x06057860,r0
    c.r[7] &= c.r[0];  // 06057856 and r0,r7
L_06057858:
    c.r[15] = c.r[14];  // 06057858 mov r14,r15
L_0605785A:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0605785A mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[7]; c.pc = x; return; }  // 0605785C rts ; mov r7,r0
}

void f_0605786C(SH2Context& c) {
    ran[1347] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0605786C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0605786E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06057870 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06057872 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06057874 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06057876 sts.l pr,@-r15
    c.r[15] -= 52;  // 06057878 add #-52,r15
    c.r[14] = c.r[15];  // 0605787A mov r15,r14
    c.r[4] = c.r[4] & 0xFFu;  // 0605787C extu.b r4,r4
    c.r[5] = c.r[5] & 0xFFu;  // 0605787E extu.b r5,r5
    c.r[11] = c.r[6] & 0xFFu;  // 06057880 extu.b r6,r11
    c.r[8] = c.r[7] & 0xFFu;  // 06057882 extu.b r7,r8
    c.r[0] = c.r[8];  // 06057884 mov r8,r0
    c.t = c.r[0] == 0x2u;  // 06057886 cmp/eq #2,r0
    { const bool k = !c.t; c.r[10] = 0x1u; if (k) { goto L_06057892; } }  // 06057888 bf/s 0x06057892 ; mov #1,r10
    c.r[1] = (uint32_t)(int16_t)ld16(0x06057960u);  // 0605788C mov.w 0x06057960,r1
    c.t = c.r[4] == c.r[1];  // 0605788E cmp/eq r1,r4
    if (c.t) { goto L_0605794C; }  // 06057890 bt 0x0605794C
L_06057892:
    c.t = (c.r[8] & c.r[8]) == 0;  // 06057892 tst r8,r8
    if (!c.t) { goto L_060578A0; }  // 06057894 bf 0x060578A0
    c.r[1] = ld32(0x06057964u);  // 06057896 mov.l 0x06057964,r1
    c.r[2] = ld32(c.r[1]);  // 06057898 mov.l @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06057962u);  // 0605789A mov.w 0x06057962,r0
    c.r[1] = 0x0u;  // 0605789C mov #0,r1
    st8(c.r[0] + c.r[2], c.r[1]);  // 0605789E mov.b r1,@(r0,r2)
L_060578A0:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06057960u);  // 060578A0 mov.w 0x06057960,r1
    c.t = c.r[5] == c.r[1];  // 060578A2 cmp/eq r1,r5
    { const bool k = c.t; c.r[2] = c.r[11]; if (k) { goto L_060578D0; } }  // 060578A4 bt/s 0x060578D0 ; mov r11,r2
    c.r[1] = ld32(0x06057968u);  // 060578A8 mov.l 0x06057968,r1
    c.r[2] = c.r[5];  // 060578AA mov r5,r2
    c.r[1] = ld32(c.r[1]);  // 060578AC mov.l @r1,r1
    c.r[2] <<= 2;  // 060578AE shll2 r2
    c.r[2] <<= 2;  // 060578B0 shll2 r2
    c.r[2] += c.r[1];  // 060578B2 add r1,r2
    c.r[1] = c.r[2];  // 060578B4 mov r2,r1
    c.r[1] += 4;  // 060578B6 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060578B8 mov.b @r1,r1
    c.r[0] = c.r[1];  // 060578BA mov r1,r0
    c.r[0] >>= 2;  // 060578BC shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060578BE shlr r0
    c.r[0] >>= 2;  // 060578C0 shlr2 r0
    c.r[0] &= 0x1u;  // 060578C2 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060578C4 tst r0,r0
    { const bool k = c.t; c.r[2] += 6; if (k) { goto L_060578CE; } }  // 060578C6 bt/s 0x060578CE ; add #6,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060578CA mov.b @r2,r1
    c.r[5] = c.r[1] & 0xFFu;  // 060578CC extu.b r1,r5
L_060578CE:
    c.r[2] = c.r[11];  // 060578CE mov r11,r2
L_060578D0:
    c.r[2] <<= 2;  // 060578D0 shll2 r2
    c.r[1] = ld32(0x0605796Cu);  // 060578D2 mov.l 0x0605796C,r1
    c.r[0] = c.r[2];  // 060578D4 mov r2,r0
    c.r[2] = ld32(c.r[0] + c.r[1]);  // 060578D6 mov.l @(r0,r1),r2
    c.r[6] = c.r[8];  // 060578D8 mov r8,r6
    { const uint32_t x = c.r[2]; c.pr = 0x060578DEu; st32(c.r[14] + 48, c.r[2]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060578DEu) return; }  // 060578DA jsr @r2 ; mov.l r2,@(48,r14)
    c.r[1] = c.r[0];  // 060578DE mov r0,r1
    c.r[0] = c.r[8];  // 060578E0 mov r8,r0
    c.t = c.r[0] == 0x2u;  // 060578E2 cmp/eq #2,r0
    { const bool k = !c.t; c.r[10] = c.r[1] & 0xFFu; if (k) { goto L_0605794C; } }  // 060578E4 bf/s 0x0605794C ; extu.b r1,r10
    c.r[9] = ld32(0x06057970u);  // 060578E8 mov.l 0x06057970,r9
    c.r[8] = ld32(0x06057974u);  // 060578EA mov.l 0x06057974,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 060578EC mov.b @r8,r1
    c.r[4] = c.r[14];  // 060578EE mov r14,r4
    c.r[2] = ld32(c.r[9]);  // 060578F0 mov.l @r9,r2
    c.r[1] = c.r[1] & 0xFFu;  // 060578F2 extu.b r1,r1
    c.r[1] += c.r[1];  // 060578F4 add r1,r1
    c.r[2] += c.r[1];  // 060578F6 add r1,r2
    c.r[2] += 1;  // 060578F8 add #1,r2
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060578FA mov.b @r2,r5
    c.r[1] = ld32(0x06057978u);  // 060578FC mov.l 0x06057978,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06057902u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06057902u) return; }  // 060578FE jsr @r1 ; extu.b r5,r5
    c.r[1] = ld32(0x0605797Cu);  // 06057902 mov.l 0x0605797C,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06057960u);  // 06057904 mov.w 0x06057960,r2
    c.r[5] = c.r[14];  // 06057906 mov r14,r5
    c.r[4] = c.r[11];  // 06057908 mov r11,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605790A mov.b @r1,r1
    c.r[0] = ld32(0x06057980u);  // 0605790C mov.l 0x06057980,r0
    c.r[1] = c.r[1] & 0xFFu;  // 0605790E extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 06057910 cmp/eq r2,r1
    { const uint32_t x = c.r[0]; c.pr = 0x06057916u; c.r[6] = c.t; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06057916u) return; }  // 06057912 jsr @r0 ; movt r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06057916 mov.b @r8,r1
    c.r[7] = c.r[0];  // 06057918 mov r0,r7
    c.r[2] = ld32(c.r[9]);  // 0605791A mov.l @r9,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0605791C extu.b r1,r1
    c.r[1] += c.r[1];  // 0605791E add r1,r1
    c.r[0] = c.r[2];  // 06057920 mov r2,r0
    c.r[2] += c.r[1];  // 06057922 add r1,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06057924 mov.b @(r0,r1),r3
    c.r[2] += 1;  // 06057926 add #1,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06057928 mov.b @r2,r2
    c.r[0] = 0x7Fu;  // 0605792A mov #127,r0
    c.r[3] &= c.r[0];  // 0605792C and r0,r3
    c.r[3] <<= 8;  // 0605792E shll8 r3
    c.r[2] = c.r[2] & 0xFFu;  // 06057930 extu.b r2,r2
    c.r[2] |= c.r[3];  // 06057932 or r3,r2
    c.r[1] = ld32(0x06057984u);  // 06057934 mov.l 0x06057984,r1
    c.r[3] = c.r[2];  // 06057936 mov r2,r3
    c.r[3] += c.r[3];  // 06057938 add r3,r3
    c.r[3] += c.r[2];  // 0605793A add r2,r3
    c.r[1] = ld32(c.r[1]);  // 0605793C mov.l @r1,r1
    c.r[3] <<= 2;  // 0605793E shll2 r3
    c.r[3] += c.r[1];  // 06057940 add r1,r3
    c.r[3] += 10;  // 06057942 add #10,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06057944 mov.w @r3,r1
    c.r[2] = c.r[7] & 0xFFu;  // 06057946 extu.b r7,r2
    c.r[1] -= c.r[2];  // 06057948 sub r2,r1
    st16(c.r[3], c.r[1]);  // 0605794A mov.w r1,@r3
L_0605794C:
    c.r[14] += 52;  // 0605794C add #52,r14
    c.r[15] = c.r[14];  // 0605794E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06057950 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06057952 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06057954 mov.l @r15+,r11
    c.r[0] = c.r[10];  // 06057956 mov r10,r0
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06057958 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0605795A mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0605795C rts ; mov.l @r15+,r8
}

void f_06057988(SH2Context& c) {
    ran[1348] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06057988 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0605798A mov r15,r14
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0605798C mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = 0x0u; c.pc = x; return; }  // 0605798E rts ; mov #0,r0
}

void f_06057994(SH2Context& c) {
    ran[1349] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06057994 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06057996 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06057998 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0605799A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605799C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0605799E sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x06057A58u);  // 060579A0 mov.w 0x06057A58,r3
    c.r[15] += c.r[3];  // 060579A2 add r3,r15
    c.r[14] = c.r[15];  // 060579A4 mov r15,r14
    c.r[11] = c.r[4] & 0xFFu;  // 060579A6 extu.b r4,r11
    c.r[5] = c.r[5] & 0xFFu;  // 060579A8 extu.b r5,r5
    c.r[10] = c.r[5];  // 060579AA mov r5,r10
    c.r[8] = c.r[6] & 0xFFu;  // 060579AC extu.b r6,r8
    c.r[9] = c.r[8];  // 060579AE mov r8,r9
    c.r[6] = (uint32_t)(int16_t)ld16(0x06057A5Au);  // 060579B0 mov.w 0x06057A5A,r6
    c.r[1] = ld32(0x06057A60u);  // 060579B2 mov.l 0x06057A60,r1
    c.r[5] <<= 2;  // 060579B4 shll2 r5
    c.r[5] <<= 2;  // 060579B6 shll2 r5
    c.r[1] = ld32(c.r[1]);  // 060579B8 mov.l @r1,r1
    c.r[4] = c.r[14];  // 060579BA mov r14,r4
    c.r[5] += c.r[1];  // 060579BC add r1,r5
    c.r[5] += 2;  // 060579BE add #2,r5
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[5]);  // 060579C0 mov.b @r5,r5
    c.r[1] = ld32(0x06057A64u);  // 060579C2 mov.l 0x06057A64,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060579C8u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060579C8u) return; }  // 060579C4 jsr @r1 ; extu.b r5,r5
    c.t = (c.r[8] & c.r[8]) == 0;  // 060579C8 tst r8,r8
    { const bool k = !c.t; c.r[1] = c.r[14]; if (k) { goto L_060579E6; } }  // 060579CA bf/s 0x060579E6 ; mov r14,r1
    c.r[1] += 22;  // 060579CE add #22,r1
    c.r[3] = c.r[14];  // 060579D0 mov r14,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060579D2 mov.w @r1,r2
    c.r[3] += 26;  // 060579D4 add #26,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 060579D6 mov.w @r3,r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 060579D8 extu.w r2,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 060579DA extu.w r1,r1
    c.t = c.r[2] == c.r[1];  // 060579DC cmp/eq r1,r2
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_06057A44; } }  // 060579DE bt/s 0x06057A44 ; mov #0,r0
    c.r[0] = 0x1u; goto L_06057A44;  // 060579E2 bra 0x06057A44 ; mov #1,r0
L_060579E6:
    c.r[0] = c.r[9];  // 060579E6 mov r9,r0
    c.t = c.r[0] == 0x1u;  // 060579E8 cmp/eq #1,r0
    { const bool k = !c.t; c.r[1] += 26; if (k) { goto L_06057A42; } }  // 060579EA bf/s 0x06057A42 ; add #26,r1
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060579EE mov.w @r1,r3
    c.r[1] = 0x1Eu;  // 060579F0 mov #30,r1
    c.macl = (c.r[3] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 060579F2 mulu.w r1,r3
    c.r[2] = c.macl;  // 060579F4 sts macl,r2
    c.r[1] = ld32(0x06057A68u);  // 060579F6 mov.l 0x06057A68,r1
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[2] * (int32_t)c.r[1]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 060579F8 dmuls.l r1,r2
    c.r[3] = c.r[3] & 0xFFFFu;  // 060579FA extu.w r3,r3
    c.r[6] = c.mach;  // 060579FC sts mach,r6
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 060579FE shar r6
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 06057A00 shar r6
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 06057A02 shar r6
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 06057A04 shar r6
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 06057A06 shar r6
    c.t = c.r[2] >> 31; c.r[2] <<= 1;  // 06057A08 shll r2
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 06057A0A subc r2,r2
    c.r[1] = c.r[14];  // 06057A0C mov r14,r1
    c.r[1] += 22;  // 06057A0E add #22,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06057A10 mov.w @r1,r1
    c.r[6] -= c.r[2];  // 06057A12 sub r2,r6
    c.r[2] = c.r[1] & 0xFFFFu;  // 06057A14 extu.w r1,r2
    c.r[1] = c.r[2];  // 06057A16 mov r2,r1
    c.r[1] += c.r[6];  // 06057A18 add r6,r1
    c.t = c.r[1] > c.r[3];  // 06057A1A cmp/hi r3,r1
    if (!c.t) { goto L_06057A22; }  // 06057A1C bf 0x06057A22
    c.r[6] = c.r[3];  // 06057A1E mov r3,r6
    c.r[6] -= c.r[2];  // 06057A20 sub r2,r6
L_06057A22:
    c.r[4] = (uint32_t)(int32_t)(int16_t)c.r[10];  // 06057A22 exts.w r10,r4
    c.r[1] = ld32(0x06057A6Cu);  // 06057A24 mov.l 0x06057A6C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06057A2Au; c.r[5] = 0x11u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06057A2Au) return; }  // 06057A26 jsr @r1 ; mov #17,r5
    c.r[1] = ld32(0x06057A70u);  // 06057A2A mov.l 0x06057A70,r1
    c.r[2] = ld32(c.r[1]);  // 06057A2C mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06057A5Cu);  // 06057A2E mov.w 0x06057A5C,r1
    c.r[2] += c.r[1];  // 06057A30 add r1,r2
    c.r[1] = ld32(0x06057A74u);  // 06057A32 mov.l 0x06057A74,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06057A34 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06057A36 extu.w r1,r1
    c.r[1] <<= 2;  // 06057A38 shll2 r1
    c.r[1] += c.r[1];  // 06057A3A add r1,r1
    c.r[2] += c.r[1];  // 06057A3C add r1,r2
    c.r[2] += 4;  // 06057A3E add #4,r2
    st8(c.r[2], c.r[11]);  // 06057A40 mov.b r11,@r2
L_06057A42:
    c.r[0] = 0x0u;  // 06057A42 mov #0,r0
L_06057A44:
    c.r[3] = (uint32_t)(int16_t)ld16(0x06057A5Eu);  // 06057A44 mov.w 0x06057A5E,r3
    c.r[14] += c.r[3];  // 06057A46 add r3,r14
    c.r[15] = c.r[14];  // 06057A48 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06057A4A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06057A4C mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06057A4E mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06057A50 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06057A52 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06057A54 rts ; mov.l @r15+,r8
}

void f_06057A78(SH2Context& c) {
    ran[1350] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06057A78 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06057A7A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06057A7C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06057A7E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06057A80 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06057A82 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06057A84 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06057A86 sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x06057B98u);  // 06057A88 mov.w 0x06057B98,r3
    c.r[15] += c.r[3];  // 06057A8A add r3,r15
    c.r[14] = c.r[15];  // 06057A8C mov r15,r14
    c.r[4] = c.r[4] & 0xFFu;  // 06057A8E extu.b r4,r4
    c.r[0] = (uint32_t)(int16_t)ld16(0x06057B9Au);  // 06057A90 mov.w 0x06057B9A,r0
    st32(c.r[0] + c.r[14], c.r[4]);  // 06057A92 mov.l r4,@(r0,r14)
    c.r[8] = c.r[6] & 0xFFu;  // 06057A94 extu.b r6,r8
    c.t = (c.r[8] & c.r[8]) == 0;  // 06057A96 tst r8,r8
    { const bool k = c.t; c.r[10] = c.r[5] & 0xFFu; if (k) { goto L_06057AA0; } }  // 06057A98 bt/s 0x06057AA0 ; extu.b r5,r10
    goto L_06057BB8;  // 06057A9C bra 0x06057BB8 ; nop
L_06057AA0:
    c.r[9] = 0x0u;  // 06057AA0 mov #0,r9
    c.r[13] = (uint32_t)(int16_t)ld16(0x06057B9Cu);  // 06057AA2 mov.w 0x06057B9C,r13
    c.r[11] = (uint32_t)(int16_t)ld16(0x06057B9Eu);  // 06057AA4 mov.w 0x06057B9E,r11
    c.r[11] += c.r[14];  // 06057AA6 add r14,r11
    c.r[0] = c.r[11];  // 06057AA8 mov r11,r0
    c.r[0] += 28;  // 06057AAA add #28,r0
    c.r[12] = (uint32_t)(int16_t)ld16(0x06057BA0u);  // 06057AAC mov.w 0x06057BA0,r12
    c.r[12] += c.r[14];  // 06057AAE add r14,r12
    st32(c.r[12], c.r[0]);  // 06057AB0 mov.l r0,@r12
L_06057AB2:
    c.r[1] = ld32(0x06057BA4u);  // 06057AB2 mov.l 0x06057BA4,r1
    c.r[0] = c.r[9];  // 06057AB4 mov r9,r0
    c.r[0] <<= 2;  // 06057AB6 shll2 r0
    c.r[0] <<= 2;  // 06057AB8 shll2 r0
    c.r[7] = ld32(c.r[1]);  // 06057ABA mov.l @r1,r7
    c.r[3] = c.r[0];  // 06057ABC mov r0,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[7]);  // 06057ABE mov.b @(r0,r7),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06057AC0 extu.b r1,r1
    c.t = c.r[1] == c.r[13];  // 06057AC2 cmp/eq r13,r1
    { const bool k = c.t; c.r[3] += c.r[7]; if (k) { goto L_06057B78; } }  // 06057AC4 bt/s 0x06057B78 ; add r7,r3
    c.r[1] = c.r[3];  // 06057AC8 mov r3,r1
    c.r[1] += 7;  // 06057ACA add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06057ACC mov.b @r1,r1
    c.r[0] = c.r[1];  // 06057ACE mov r1,r0
    c.r[0] >>= 2;  // 06057AD0 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06057AD2 shlr r0
    c.r[0] &= 0x1u;  // 06057AD4 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06057AD6 tst r0,r0
    { const bool k = !c.t; c.r[0] = 0x3u; if (k) { goto L_06057B78; } }  // 06057AD8 bf/s 0x06057B78 ; mov #3,r0
    c.r[12] = (uint32_t)(int16_t)ld16(0x06057B9Au);  // 06057ADC mov.w 0x06057B9A,r12
    c.r[12] += c.r[14];  // 06057ADE add r14,r12
    c.r[1] = ld32(c.r[12]);  // 06057AE0 mov.l @r12,r1
    c.r[1] <<= 2;  // 06057AE2 shll2 r1
    c.r[1] <<= 2;  // 06057AE4 shll2 r1
    c.r[1] += c.r[7];  // 06057AE6 add r7,r1
    c.r[1] += 3;  // 06057AE8 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06057AEA mov.b @r1,r1
    c.r[2] = c.r[1];  // 06057AEC mov r1,r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 06057AEE shlr r2
    c.r[1] = c.r[3];  // 06057AF0 mov r3,r1
    c.r[1] += 3;  // 06057AF2 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06057AF4 mov.b @r1,r1
    c.r[2] &= c.r[0];  // 06057AF6 and r0,r2
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06057AF8 shlr r1
    c.r[1] &= c.r[0];  // 06057AFA and r0,r1
    c.t = c.r[2] == c.r[1];  // 06057AFC cmp/eq r1,r2
    { const bool k = !c.t; c.t = (c.r[2] & c.r[2]) == 0; if (k) { goto L_06057B78; } }  // 06057AFE bf/s 0x06057B78 ; tst r2,r2
    if (!c.t) { goto L_06057B0A; }  // 06057B02 bf 0x06057B0A
    c.r[1] = ld32(c.r[3] + 12);  // 06057B04 mov.l @(12,r3),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06057B06 tst r1,r1
    if (!c.t) { goto L_06057B78; }  // 06057B08 bf 0x06057B78
L_06057B0A:
    c.r[3] += 4;  // 06057B0A add #4,r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06057B0C mov.b @r3,r0
    c.r[0] &= 0x60u;  // 06057B0E and #96,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06057B10 tst r0,r0
    if (!c.t) { goto L_06057B78; }  // 06057B12 bf 0x06057B78
    c.r[10] = c.r[9] & 0xFFu;  // 06057B14 extu.b r9,r10
    c.r[1] = c.r[10];  // 06057B16 mov r10,r1
    c.r[1] <<= 2;  // 06057B18 shll2 r1
    c.r[1] <<= 2;  // 06057B1A shll2 r1
    c.r[1] += c.r[7];  // 06057B1C add r7,r1
    c.r[1] += 2;  // 06057B1E add #2,r1
    c.r[6] = c.r[13];  // 06057B20 mov r13,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06057B22 mov.b @r1,r1
    c.r[4] = c.r[11];  // 06057B24 mov r11,r4
    c.r[8] = c.r[1] & 0xFFu;  // 06057B26 extu.b r1,r8
    c.r[1] = ld32(0x06057BA8u);  // 06057B28 mov.l 0x06057BA8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06057B2Eu; c.r[5] = c.r[8] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06057B2Eu) return; }  // 06057B2A jsr @r1 ; extu.b r8,r5
    c.r[1] = ld32(0x06057BACu);  // 06057B2E mov.l 0x06057BAC,r1
    c.r[2] = ld32(c.r[1]);  // 06057B30 mov.l @r1,r2
    c.r[12] = (uint32_t)(int16_t)ld16(0x06057BA0u);  // 06057B32 mov.w 0x06057BA0,r12
    c.r[1] = 0x1Eu;  // 06057B34 mov #30,r1
    c.macl = c.r[8] * c.r[1];  // 06057B36 mul.l r1,r8
    c.r[12] += c.r[14];  // 06057B38 add r14,r12
    c.r[0] = ld32(c.r[12]);  // 06057B3A mov.l @r12,r0
    c.r[1] = c.macl;  // 06057B3C sts macl,r1
    c.r[1] += c.r[2];  // 06057B3E add r2,r1
    c.r[1] += 24;  // 06057B40 add #24,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06057B42 mov.w @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0]);  // 06057B44 mov.w @r0,r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 06057B46 extu.w r2,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 06057B48 extu.w r1,r1
    c.t = c.r[2] == c.r[1];  // 06057B4A cmp/eq r1,r2
    { const bool k = !c.t; c.r[8] = 0xFFFFFFFEu; if (k) { goto L_06057B58; } }  // 06057B4C bf/s 0x06057B58 ; mov #-2,r8
    c.r[0] = ld32(0x06057BB0u);  // 06057B50 mov.l 0x06057BB0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06057B56u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06057B56u) return; }  // 06057B52 jsr @r0 ; mov r10,r4
    c.r[8] = c.r[0];  // 06057B56 mov r0,r8
L_06057B58:
    c.r[0] = c.r[8];  // 06057B58 mov r8,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 06057B5A cmp/eq #-1,r0
    if (c.t) { goto L_06057B78; }  // 06057B5C bt 0x06057B78
    c.r[1] = ld32(0x06057BB4u);  // 06057B5E mov.l 0x06057BB4,r1
    c.r[3] = ld32(c.r[1]);  // 06057B60 mov.l @r1,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x06057BA2u);  // 06057B62 mov.w 0x06057BA2,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06057B64 mov.b @(r0,r3),r2
    c.r[1] = c.r[2];  // 06057B66 mov r2,r1
    c.r[1] += 1;  // 06057B68 add #1,r1
    st8(c.r[0] + c.r[3], c.r[1]);  // 06057B6A mov.b r1,@(r0,r3)
    c.r[2] = c.r[2] & 0xFFu;  // 06057B6C extu.b r2,r2
    c.r[2] <<= 2;  // 06057B6E shll2 r2
    c.r[2] += c.r[2];  // 06057B70 add r2,r2
    c.r[3] += c.r[2];  // 06057B72 add r2,r3
    c.r[3] += 4;  // 06057B74 add #4,r3
    st8(c.r[3], c.r[9]);  // 06057B76 mov.b r9,@r3
L_06057B78:
    c.r[9] += 1;  // 06057B78 add #1,r9
    c.r[1] = 0x49u;  // 06057B7A mov #73,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 06057B7C cmp/gt r1,r9
    if (!c.t) { SH2_POLL(c); goto L_06057AB2; }  // 06057B7E bf 0x06057AB2
    c.r[1] = ld32(0x06057BB4u);  // 06057B80 mov.l 0x06057BB4,r1
    c.r[1] = ld32(c.r[1]);  // 06057B82 mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06057BA2u);  // 06057B84 mov.w 0x06057BA2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06057B86 mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06057B88 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06057B8A tst r1,r1
    { const bool k = !c.t; c.r[0] = 0x0u; if (k) { goto L_06057B94; } }  // 06057B8C bf/s 0x06057B94 ; mov #0,r0
    goto L_06057CB8;  // 06057B90 bra 0x06057CB8 ; nop
L_06057B94:
    c.r[0] = 0x1u; goto L_06057CB8;  // 06057B94 bra 0x06057CB8 ; mov #1,r0
L_06057BB8:
    c.r[13] = ld32(0x06057CDCu);  // 06057BB8 mov.l 0x06057CDC,r13
    c.r[11] = c.r[10];  // 06057BBA mov r10,r11
    c.r[11] <<= 2;  // 06057BBC shll2 r11
    c.r[11] <<= 2;  // 06057BBE shll2 r11
    c.r[6] = (uint32_t)(int16_t)ld16(0x06057CD0u);  // 06057BC0 mov.w 0x06057CD0,r6
    c.r[1] = ld32(c.r[13]);  // 06057BC2 mov.l @r13,r1
    c.r[4] = c.r[14];  // 06057BC4 mov r14,r4
    c.r[1] += c.r[11];  // 06057BC6 add r11,r1
    c.r[1] += 2;  // 06057BC8 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06057BCA mov.b @r1,r1
    c.r[12] = ld32(0x06057CE0u);  // 06057BCC mov.l 0x06057CE0,r12
    c.r[9] = c.r[1] & 0xFFu;  // 06057BCE extu.b r1,r9
    { const uint32_t x = c.r[12]; c.pr = 0x06057BD4u; c.r[5] = c.r[9] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06057BD4u) return; }  // 06057BD0 jsr @r12 ; extu.b r9,r5
    c.r[1] = ld32(0x06057CE4u);  // 06057BD4 mov.l 0x06057CE4,r1
    c.r[2] = ld32(c.r[1]);  // 06057BD6 mov.l @r1,r2
    c.r[7] = c.r[14];  // 06057BD8 mov r14,r7
    c.r[1] = 0x1Eu;  // 06057BDA mov #30,r1
    c.macl = c.r[9] * c.r[1];  // 06057BDC mul.l r1,r9
    c.r[7] += 28;  // 06057BDE add #28,r7
    c.r[0] = c.r[8];  // 06057BE0 mov r8,r0
    c.r[3] = c.macl;  // 06057BE2 sts macl,r3
    c.r[3] += c.r[2];  // 06057BE4 add r2,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[7]);  // 06057BE6 mov.w @r7,r1
    c.r[3] += 24;  // 06057BE8 add #24,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06057BEA mov.w @r3,r2
    c.t = c.r[0] == 0x2u;  // 06057BEC cmp/eq #2,r0
    c.r[1] -= c.r[2];  // 06057BEE sub r2,r1
    { const bool k = !c.t; c.r[6] = c.r[1] & 0xFFFFu; if (k) { goto L_06057C90; } }  // 06057BF0 bf/s 0x06057C90 ; extu.w r1,r6
    c.r[9] = (uint32_t)(int16_t)ld16(0x06057CD2u);  // 06057BF4 mov.w 0x06057CD2,r9
    c.r[9] += c.r[14];  // 06057BF6 add r14,r9
    c.r[1] = ld32(0x06057CE8u);  // 06057BF8 mov.l 0x06057CE8,r1
    c.r[5] = c.r[9];  // 06057BFA mov r9,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06057C00u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06057C00u) return; }  // 06057BFC jsr @r1 ; mov r10,r4
    c.r[8] = c.r[9];  // 06057C00 mov r9,r8
    c.r[8] += 16;  // 06057C02 add #16,r8
    c.r[1] = ld32(c.r[13]);  // 06057C04 mov.l @r13,r1
    c.r[6] = c.r[10];  // 06057C06 mov r10,r6
    c.r[11] += c.r[1];  // 06057C08 add r1,r11
    c.r[11] += 2;  // 06057C0A add #2,r11
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[11]);  // 06057C0C mov.b @r11,r5
    c.r[4] = c.r[8];  // 06057C0E mov r8,r4
    { const uint32_t x = c.r[12]; c.pr = 0x06057C14u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06057C14u) return; }  // 06057C10 jsr @r12 ; extu.b r5,r5
    c.r[2] = 0x0u;  // 06057C14 mov #0,r2
    c.r[6] = (uint32_t)(int16_t)ld16(0x06057CD0u);  // 06057C16 mov.w 0x06057CD0,r6
    c.r[7] = ld32(0x06057CECu);  // 06057C18 mov.l 0x06057CEC,r7
L_06057C1A:
    c.r[0] = c.r[9];  // 06057C1A mov r9,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06057C1C mov.b @(r0,r2),r1
    c.r[3] = c.r[1] & 0xFFu;  // 06057C1E extu.b r1,r3
    c.t = c.r[3] == c.r[6];  // 06057C20 cmp/eq r6,r3
    { const bool k = c.t; c.r[0] = c.r[10]; if (k) { goto L_06057C3A; } }  // 06057C22 bt/s 0x06057C3A ; mov r10,r0
    c.r[1] = ld32(c.r[7]);  // 06057C26 mov.l @r7,r1
    c.r[0] <<= 2;  // 06057C28 shll2 r0
    c.r[0] <<= 2;  // 06057C2A shll2 r0
    c.r[0] += c.r[1];  // 06057C2C add r1,r0
    c.r[1] = c.r[8];  // 06057C2E mov r8,r1
    c.r[1] += 52;  // 06057C30 add #52,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06057C32 mov.w @r1,r1
    c.r[0] += 40;  // 06057C34 add #40,r0
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06057C36 shlr r1
    st8(c.r[0] + c.r[3], c.r[1]);  // 06057C38 mov.b r1,@(r0,r3)
L_06057C3A:
    c.r[2] += 1;  // 06057C3A add #1,r2
    c.r[1] = 0xFu;  // 06057C3C mov #15,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 06057C3E cmp/gt r1,r2
    { const bool k = !c.t; c.r[8] += 20; if (k) { SH2_POLL(c); goto L_06057C1A; } }  // 06057C40 bf/s 0x06057C1A ; add #20,r8
    c.r[1] = ld32(0x06057CDCu);  // 06057C44 mov.l 0x06057CDC,r1
    c.r[1] = ld32(c.r[1]);  // 06057C46 mov.l @r1,r1
    c.r[10] <<= 2;  // 06057C48 shll2 r10
    c.r[10] <<= 2;  // 06057C4A shll2 r10
    c.r[10] += c.r[1];  // 06057C4C add r1,r10
    c.r[10] += 2;  // 06057C4E add #2,r10
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[10]);  // 06057C50 mov.b @r10,r2
    c.r[1] = ld32(0x06057CE4u);  // 06057C52 mov.l 0x06057CE4,r1
    c.r[3] = ld32(c.r[1]);  // 06057C54 mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06057C56 extu.b r2,r2
    c.r[1] = 0x1Eu;  // 06057C58 mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 06057C5A mul.l r1,r2
    c.r[1] = c.macl;  // 06057C5C sts macl,r1
    c.r[1] += c.r[3];  // 06057C5E add r3,r1
    c.r[1] += 15;  // 06057C60 add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06057C62 mov.b @r1,r1
    c.r[9] = c.r[1] & 0xFFu;  // 06057C64 extu.b r1,r9
    c.r[1] = ld32(0x06057CF0u);  // 06057C66 mov.l 0x06057CF0,r1
    c.r[3] = c.r[9];  // 06057C68 mov r9,r3
    c.r[3] += c.r[3];  // 06057C6A add r3,r3
    c.r[3] += c.r[9];  // 06057C6C add r9,r3
    c.r[1] = ld32(c.r[1]);  // 06057C6E mov.l @r1,r1
    c.r[3] <<= 2;  // 06057C70 shll2 r3
    c.r[3] += c.r[1];  // 06057C72 add r1,r3
    c.r[3] += 9;  // 06057C74 add #9,r3
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06057C76 mov.b @r3,r7
    c.r[1] = 0x31u;  // 06057C78 mov #49,r1
    c.r[2] = c.r[7] & 0xFFu;  // 06057C7A extu.b r7,r2
    c.r[2] -= 10;  // 06057C7C add #-10,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 06057C7E cmp/gt r1,r2
    { const bool k = c.t; c.r[1] = c.r[7]; if (k) { goto L_06057C8A; } }  // 06057C80 bt/s 0x06057C8A ; mov r7,r1
    c.r[1] = 0x32u;  // 06057C84 mov #50,r1
    st8(c.r[3], c.r[1]); goto L_06057CB6;  // 06057C86 bra 0x06057CB6 ; mov.b r1,@r3
L_06057C8A:
    c.r[1] -= 10;  // 06057C8A add #-10,r1
    st8(c.r[3], c.r[1]); goto L_06057CB6;  // 06057C8C bra 0x06057CB6 ; mov.b r1,@r3
L_06057C90:
    c.r[4] = (uint32_t)(int32_t)(int16_t)c.r[10];  // 06057C90 exts.w r10,r4
    c.r[1] = ld32(0x06057CF4u);  // 06057C92 mov.l 0x06057CF4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06057C98u; c.r[5] = 0x12u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06057C98u) return; }  // 06057C94 jsr @r1 ; mov #18,r5
    c.r[1] = ld32(0x06057CF8u);  // 06057C98 mov.l 0x06057CF8,r1
    c.r[2] = ld32(c.r[1]);  // 06057C9A mov.l @r1,r2
    c.r[12] = (uint32_t)(int16_t)ld16(0x06057CD4u);  // 06057C9C mov.w 0x06057CD4,r12
    c.r[1] = (uint32_t)(int16_t)ld16(0x06057CD6u);  // 06057C9E mov.w 0x06057CD6,r1
    c.r[2] += c.r[1];  // 06057CA0 add r1,r2
    c.r[1] = ld32(0x06057CFCu);  // 06057CA2 mov.l 0x06057CFC,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06057CA4 mov.w @r1,r1
    c.r[12] += c.r[14];  // 06057CA6 add r14,r12
    c.r[1] = c.r[1] & 0xFFFFu;  // 06057CA8 extu.w r1,r1
    c.r[1] <<= 2;  // 06057CAA shll2 r1
    c.r[1] += c.r[1];  // 06057CAC add r1,r1
    c.r[2] += c.r[1];  // 06057CAE add r1,r2
    c.r[2] += 4;  // 06057CB0 add #4,r2
    c.r[12] = (uint32_t)(int8_t)ld8(c.r[12]);  // 06057CB2 mov.b @r12,r12
    st8(c.r[2], c.r[12]);  // 06057CB4 mov.b r12,@r2
L_06057CB6:
    c.r[0] = 0x0u;  // 06057CB6 mov #0,r0
L_06057CB8:
    c.r[3] = (uint32_t)(int16_t)ld16(0x06057CD8u);  // 06057CB8 mov.w 0x06057CD8,r3
    c.r[14] += c.r[3];  // 06057CBA add r3,r14
    c.r[15] = c.r[14];  // 06057CBC mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06057CBE lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06057CC0 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06057CC2 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06057CC4 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06057CC6 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06057CC8 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06057CCA mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06057CCC rts ; mov.l @r15+,r8
}

void f_06057D00(SH2Context& c) {
    ran[1351] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06057D00 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06057D02 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06057D04 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06057D06 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06057D08 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06057D0A mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06057D0C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06057D0E sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x06057DC0u);  // 06057D10 mov.w 0x06057DC0,r3
    c.r[15] += c.r[3];  // 06057D12 add r3,r15
    c.r[14] = c.r[15];  // 06057D14 mov r15,r14
    c.r[13] = c.r[4] & 0xFFu;  // 06057D16 extu.b r4,r13
    c.r[5] = c.r[5] & 0xFFu;  // 06057D18 extu.b r5,r5
    c.r[12] = c.r[5];  // 06057D1A mov r5,r12
    c.r[9] = c.r[6] & 0xFFu;  // 06057D1C extu.b r6,r9
    c.r[10] = c.r[9];  // 06057D1E mov r9,r10
    c.r[1] = ld32(0x06057DC8u);  // 06057D20 mov.l 0x06057DC8,r1
    c.r[5] <<= 2;  // 06057D22 shll2 r5
    c.r[5] <<= 2;  // 06057D24 shll2 r5
    c.r[1] = ld32(c.r[1]);  // 06057D26 mov.l @r1,r1
    c.r[6] = (uint32_t)(int16_t)ld16(0x06057DC2u);  // 06057D28 mov.w 0x06057DC2,r6
    c.r[5] += c.r[1];  // 06057D2A add r1,r5
    c.r[5] += 2;  // 06057D2C add #2,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[5]);  // 06057D2E mov.b @r5,r1
    c.r[4] = c.r[14];  // 06057D30 mov r14,r4
    c.r[8] = c.r[1] & 0xFFu;  // 06057D32 extu.b r1,r8
    c.r[11] = c.r[8];  // 06057D34 mov r8,r11
    c.r[1] = ld32(0x06057DCCu);  // 06057D36 mov.l 0x06057DCC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06057D3Cu; c.r[5] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06057D3Cu) return; }  // 06057D38 jsr @r1 ; mov r8,r5
    c.t = (c.r[9] & c.r[9]) == 0;  // 06057D3C tst r9,r9
    { const bool k = !c.t; c.r[0] = c.r[10]; if (k) { goto L_06057D66; } }  // 06057D3E bf/s 0x06057D66 ; mov r10,r0
    c.r[1] = ld32(0x06057DD0u);  // 06057D42 mov.l 0x06057DD0,r1
    c.r[2] = ld32(c.r[1]);  // 06057D44 mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 06057D46 mov #30,r1
    c.macl = c.r[8] * c.r[1];  // 06057D48 mul.l r1,r8
    c.r[3] = c.macl;  // 06057D4A sts macl,r3
    c.r[3] += c.r[2];  // 06057D4C add r2,r3
    c.r[3] += 22;  // 06057D4E add #22,r3
    c.r[1] = c.r[14];  // 06057D50 mov r14,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06057D52 mov.w @r3,r2
    c.r[1] += 26;  // 06057D54 add #26,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06057D56 mov.w @r1,r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 06057D58 extu.w r2,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 06057D5A extu.w r1,r1
    c.t = c.r[2] == c.r[1];  // 06057D5C cmp/eq r1,r2
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_06057DA8; } }  // 06057D5E bt/s 0x06057DA8 ; mov #0,r0
    c.r[0] = 0x1u; goto L_06057DA8;  // 06057D62 bra 0x06057DA8 ; mov #1,r0
L_06057D66:
    c.t = c.r[0] == 0x1u;  // 06057D66 cmp/eq #1,r0
    { const bool k = !c.t; c.r[1] = c.r[14]; if (k) { goto L_06057DA6; } }  // 06057D68 bf/s 0x06057DA6 ; mov r14,r1
    c.r[1] += 26;  // 06057D6C add #26,r1
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06057D6E mov.w @r1,r6
    c.r[1] = ld32(0x06057DD0u);  // 06057D70 mov.l 0x06057DD0,r1
    c.r[2] = ld32(c.r[1]);  // 06057D72 mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 06057D74 mov #30,r1
    c.macl = c.r[11] * c.r[1];  // 06057D76 mul.l r1,r11
    c.r[4] = (uint32_t)(int32_t)(int16_t)c.r[12];  // 06057D78 exts.w r12,r4
    c.r[1] = c.macl;  // 06057D7A sts macl,r1
    c.r[1] += c.r[2];  // 06057D7C add r2,r1
    c.r[1] += 22;  // 06057D7E add #22,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06057D80 mov.w @r1,r1
    c.r[6] = c.r[6] & 0xFFFFu;  // 06057D82 extu.w r6,r6
    c.r[1] = c.r[1] & 0xFFFFu;  // 06057D84 extu.w r1,r1
    c.r[6] -= c.r[1];  // 06057D86 sub r1,r6
    c.r[1] = ld32(0x06057DD4u);  // 06057D88 mov.l 0x06057DD4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06057D8Eu; c.r[5] = 0x13u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06057D8Eu) return; }  // 06057D8A jsr @r1 ; mov #19,r5
    c.r[1] = ld32(0x06057DD8u);  // 06057D8E mov.l 0x06057DD8,r1
    c.r[2] = ld32(c.r[1]);  // 06057D90 mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06057DC4u);  // 06057D92 mov.w 0x06057DC4,r1
    c.r[2] += c.r[1];  // 06057D94 add r1,r2
    c.r[1] = ld32(0x06057DDCu);  // 06057D96 mov.l 0x06057DDC,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06057D98 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06057D9A extu.w r1,r1
    c.r[1] <<= 2;  // 06057D9C shll2 r1
    c.r[1] += c.r[1];  // 06057D9E add r1,r1
    c.r[2] += c.r[1];  // 06057DA0 add r1,r2
    c.r[2] += 4;  // 06057DA2 add #4,r2
    st8(c.r[2], c.r[13]);  // 06057DA4 mov.b r13,@r2
L_06057DA6:
    c.r[0] = 0x0u;  // 06057DA6 mov #0,r0
L_06057DA8:
    c.r[3] = (uint32_t)(int16_t)ld16(0x06057DC6u);  // 06057DA8 mov.w 0x06057DC6,r3
    c.r[14] += c.r[3];  // 06057DAA add r3,r14
    c.r[15] = c.r[14];  // 06057DAC mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06057DAE lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06057DB0 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06057DB2 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06057DB4 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06057DB6 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06057DB8 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06057DBA mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06057DBC rts ; mov.l @r15+,r8
}

void f_06057DE0(SH2Context& c) {
    ran[1352] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06057DE0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06057DE2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06057DE4 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06057DE6 mov r15,r14
    c.r[8] = c.r[4] & 0xFFu;  // 06057DE8 extu.b r4,r8
    c.r[2] = c.r[5] & 0xFFu;  // 06057DEA extu.b r5,r2
    c.r[4] = c.r[2];  // 06057DEC mov r2,r4
    c.r[0] = c.r[6] & 0xFFu;  // 06057DEE extu.b r6,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06057DF0 tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[0]; if (k) { goto L_06057E12; } }  // 06057DF2 bf/s 0x06057E12 ; mov r0,r1
    c.r[1] = ld32(0x06057E60u);  // 06057DF6 mov.l 0x06057E60,r1
    c.r[1] = ld32(c.r[1]);  // 06057DF8 mov.l @r1,r1
    c.r[2] <<= 2;  // 06057DFA shll2 r2
    c.r[2] <<= 2;  // 06057DFC shll2 r2
    c.r[2] += c.r[1];  // 06057DFE add r1,r2
    c.r[2] += 10;  // 06057E00 add #10,r2
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06057E02 mov.w @r2,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06057E5Au);  // 06057E04 mov.w 0x06057E5A,r1
    c.r[1] &= c.r[2];  // 06057E06 and r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06057E08 tst r1,r1
    { const bool k = !c.t; c.r[0] = 0x1u; if (k) { goto L_06057E4E; } }  // 06057E0A bf/s 0x06057E4E ; mov #1,r0
    c.r[15] = c.r[14]; goto L_06057E52;  // 06057E0E bra 0x06057E52 ; mov r14,r15
L_06057E12:
    c.r[0] = c.r[1];  // 06057E12 mov r1,r0
    c.t = c.r[0] == 0x2u;  // 06057E14 cmp/eq #2,r0
    { const bool k = !c.t; c.r[2] <<= 2; if (k) { goto L_06057E2C; } }  // 06057E16 bf/s 0x06057E2C ; shll2 r2
    c.r[1] = ld32(0x06057E60u);  // 06057E1A mov.l 0x06057E60,r1
    c.r[1] = ld32(c.r[1]);  // 06057E1C mov.l @r1,r1
    c.r[2] <<= 2;  // 06057E1E shll2 r2
    c.r[2] += c.r[1];  // 06057E20 add r1,r2
    c.r[2] += 10;  // 06057E22 add #10,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06057E24 mov.b @r2,r0
    c.r[0] |= 0x40u;  // 06057E26 or #64,r0
    st8(c.r[2], c.r[0]); goto L_06057E4E;  // 06057E28 bra 0x06057E4E ; mov.b r0,@r2
L_06057E2C:
    c.r[4] = (uint32_t)(int32_t)(int16_t)c.r[4];  // 06057E2C exts.w r4,r4
    c.r[1] = ld32(0x06057E64u);  // 06057E2E mov.l 0x06057E64,r1
    c.r[6] = 0x0u;  // 06057E30 mov #0,r6
    { const uint32_t x = c.r[1]; c.pr = 0x06057E36u; c.r[5] = 0x14u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06057E36u) return; }  // 06057E32 jsr @r1 ; mov #20,r5
    c.r[1] = ld32(0x06057E68u);  // 06057E36 mov.l 0x06057E68,r1
    c.r[2] = ld32(c.r[1]);  // 06057E38 mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06057E5Cu);  // 06057E3A mov.w 0x06057E5C,r1
    c.r[2] += c.r[1];  // 06057E3C add r1,r2
    c.r[1] = ld32(0x06057E6Cu);  // 06057E3E mov.l 0x06057E6C,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06057E40 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06057E42 extu.w r1,r1
    c.r[1] <<= 2;  // 06057E44 shll2 r1
    c.r[1] += c.r[1];  // 06057E46 add r1,r1
    c.r[2] += c.r[1];  // 06057E48 add r1,r2
    c.r[2] += 4;  // 06057E4A add #4,r2
    st8(c.r[2], c.r[8]);  // 06057E4C mov.b r8,@r2
L_06057E4E:
    c.r[0] = 0x0u;  // 06057E4E mov #0,r0
    c.r[15] = c.r[14];  // 06057E50 mov r14,r15
L_06057E52:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06057E52 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06057E54 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06057E56 rts ; mov.l @r15+,r8
}

void f_06057E70(SH2Context& c) {
    ran[1353] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06057E70 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06057E72 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06057E74 mov r15,r14
    c.r[7] = c.r[6];  // 06057E76 mov r6,r7
    c.r[4] = c.r[4] & 0xFFu;  // 06057E78 extu.b r4,r4
    c.r[5] = c.r[5] & 0xFFu;  // 06057E7A extu.b r5,r5
    c.r[7] = c.r[7] & 0xFFu;  // 06057E7C extu.b r7,r7
    c.r[0] = ld32(0x06057E94u);  // 06057E7E mov.l 0x06057E94,r0
    c.r[6] = c.r[5];  // 06057E80 mov r5,r6
    c.r[5] = c.r[4];  // 06057E82 mov r4,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06057E88u; c.r[4] = 0x15u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06057E88u) return; }  // 06057E84 jsr @r0 ; mov #21,r4
    c.r[15] = c.r[14];  // 06057E88 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06057E8A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06057E8C mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[0] & 0xFFu; c.pc = x; return; }  // 06057E8E rts ; extu.b r0,r0
}

void f_06057E98(SH2Context& c) {
    ran[1354] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06057E98 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06057E9A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06057E9C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06057E9E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06057EA0 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06057EA2 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06057EA4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06057EA6 sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x06057FC0u);  // 06057EA8 mov.w 0x06057FC0,r3
    c.r[15] += c.r[3];  // 06057EAA add r3,r15
    c.r[14] = c.r[15];  // 06057EAC mov r15,r14
    c.r[13] = c.r[4] & 0xFFu;  // 06057EAE extu.b r4,r13
    c.r[12] = c.r[5] & 0xFFu;  // 06057EB0 extu.b r5,r12
    c.r[11] = c.r[7] & 0xFFu;  // 06057EB2 extu.b r7,r11
    c.r[10] = 0x0u;  // 06057EB4 mov #0,r10
    c.r[9] = 0x0u;  // 06057EB6 mov #0,r9
L_06057EB8:
    c.r[1] = ld32(0x06057FC8u);  // 06057EB8 mov.l 0x06057FC8,r1
    c.r[2] = ld32(c.r[1]);  // 06057EBA mov.l @r1,r2
    c.r[1] = c.r[9];  // 06057EBC mov r9,r1
    c.r[1] <<= 2;  // 06057EBE shll2 r1
    c.r[1] <<= 2;  // 06057EC0 shll2 r1
    c.r[8] = c.r[1];  // 06057EC2 mov r1,r8
    c.r[0] = c.r[1];  // 06057EC4 mov r1,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06057EC6 mov.b @(r0,r2),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06057EC8 extu.b r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06057FC2u);  // 06057ECA mov.w 0x06057FC2,r0
    c.t = c.r[1] == c.r[0];  // 06057ECC cmp/eq r0,r1
    { const bool k = c.t; c.r[8] += c.r[2]; if (k) { goto L_06057FAC; } }  // 06057ECE bt/s 0x06057FAC ; add r2,r8
    c.r[1] = c.r[8];  // 06057ED2 mov r8,r1
    c.r[1] += 7;  // 06057ED4 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06057ED6 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06057ED8 mov r1,r0
    c.r[0] >>= 2;  // 06057EDA shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06057EDC shlr r0
    c.r[0] &= 0x1u;  // 06057EDE and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06057EE0 tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[12]; if (k) { goto L_06057FAC; } }  // 06057EE2 bf/s 0x06057FAC ; mov r12,r1
    c.r[1] <<= 2;  // 06057EE6 shll2 r1
    c.r[1] <<= 2;  // 06057EE8 shll2 r1
    c.r[1] += c.r[2];  // 06057EEA add r2,r1
    c.r[1] += 3;  // 06057EEC add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06057EEE mov.b @r1,r1
    c.r[0] = 0x3u;  // 06057EF0 mov #3,r0
    c.r[2] = c.r[1];  // 06057EF2 mov r1,r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 06057EF4 shlr r2
    c.r[1] = c.r[8];  // 06057EF6 mov r8,r1
    c.r[1] += 3;  // 06057EF8 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06057EFA mov.b @r1,r1
    c.r[2] &= c.r[0];  // 06057EFC and r0,r2
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06057EFE shlr r1
    c.r[1] &= c.r[0];  // 06057F00 and r0,r1
    c.t = c.r[2] == c.r[1];  // 06057F02 cmp/eq r1,r2
    { const bool k = !c.t; c.t = (c.r[2] & c.r[2]) == 0; if (k) { goto L_06057FAC; } }  // 06057F04 bf/s 0x06057FAC ; tst r2,r2
    if (!c.t) { goto L_06057F10; }  // 06057F08 bf 0x06057F10
    c.r[1] = ld32(c.r[8] + 12);  // 06057F0A mov.l @(12,r8),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06057F0C tst r1,r1
    if (!c.t) { goto L_06057FAC; }  // 06057F0E bf 0x06057FAC
L_06057F10:
    c.r[1] = c.r[8];  // 06057F10 mov r8,r1
    c.r[1] += 4;  // 06057F12 add #4,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06057F14 mov.b @r1,r0
    c.r[0] &= 0x60u;  // 06057F16 and #96,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06057F18 tst r0,r0
    { const bool k = !c.t; c.r[8] += 2; if (k) { goto L_06057FAC; } }  // 06057F1A bf/s 0x06057FAC ; add #2,r8
    c.r[1] = ld32(0x06057FCCu);  // 06057F1E mov.l 0x06057FCC,r1
    c.r[6] = (uint32_t)(int16_t)ld16(0x06057FC2u);  // 06057F20 mov.w 0x06057FC2,r6
    c.r[8] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06057F22 mov.b @r8,r8
    c.r[4] = c.r[14];  // 06057F24 mov r14,r4
    c.r[8] = c.r[8] & 0xFFu;  // 06057F26 extu.b r8,r8
    { const uint32_t x = c.r[1]; c.pr = 0x06057F2Cu; c.r[5] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06057F2Cu) return; }  // 06057F28 jsr @r1 ; mov r8,r5
    c.r[1] = ld32(0x06057FD0u);  // 06057F2C mov.l 0x06057FD0,r1
    c.r[2] = ld32(c.r[1]);  // 06057F2E mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 06057F30 mov #30,r1
    c.macl = c.r[8] * c.r[1];  // 06057F32 mul.l r1,r8
    c.r[3] = c.macl;  // 06057F34 sts macl,r3
    c.r[3] += c.r[2];  // 06057F36 add r2,r3
    c.r[3] += 22;  // 06057F38 add #22,r3
    c.r[1] = c.r[14];  // 06057F3A mov r14,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06057F3C mov.w @r3,r2
    c.r[1] += 26;  // 06057F3E add #26,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06057F40 mov.w @r1,r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 06057F42 extu.w r2,r2
    c.r[3] = c.r[1] & 0xFFFFu;  // 06057F44 extu.w r1,r3
    c.t = c.r[2] == c.r[3];  // 06057F46 cmp/eq r3,r2
    { const bool k = c.t; c.t = (c.r[11] & c.r[11]) == 0; if (k) { goto L_06057FAC; } }  // 06057F48 bt/s 0x06057FAC ; tst r11,r11
    { const bool k = c.t; c.r[0] = c.r[11]; if (k) { goto L_06057FB4; } }  // 06057F4C bt/s 0x06057FB4 ; mov r11,r0
    c.t = c.r[0] == 0x1u;  // 06057F50 cmp/eq #1,r0
    { const bool k = !c.t; c.r[0] = c.r[13]; if (k) { goto L_06057FAC; } }  // 06057F52 bf/s 0x06057FAC ; mov r13,r0
    c.t = c.r[0] == 0x17u;  // 06057F56 cmp/eq #23,r0
    { const bool k = c.t; c.r[6] = c.r[3]; if (k) { goto L_06057F68; } }  // 06057F58 bt/s 0x06057F68 ; mov r3,r6
    c.t = c.r[6] & 1; c.r[6] >>= 1;  // 06057F5C shlr r6
    c.r[1] = c.r[2];  // 06057F5E mov r2,r1
    c.r[1] += c.r[6];  // 06057F60 add r6,r1
    c.t = c.r[1] > c.r[3];  // 06057F62 cmp/hi r3,r1
    if (!c.t) { goto L_06057F6A; }  // 06057F64 bf 0x06057F6A
    c.r[6] = c.r[3];  // 06057F66 mov r3,r6
L_06057F68:
    c.r[6] -= c.r[2];  // 06057F68 sub r2,r6
L_06057F6A:
    c.r[4] = (uint32_t)(int32_t)(int16_t)c.r[9];  // 06057F6A exts.w r9,r4
    c.r[1] = ld32(0x06057FD4u);  // 06057F6C mov.l 0x06057FD4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06057F72u; c.r[5] = c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06057F72u) return; }  // 06057F6E jsr @r1 ; mov r13,r5
    c.t = (c.r[10] & c.r[10]) == 0;  // 06057F72 tst r10,r10
    if (!c.t) { goto L_06057F92; }  // 06057F74 bf 0x06057F92
    c.r[10] = 0x1u;  // 06057F76 mov #1,r10
    c.r[1] = ld32(0x06057FD8u);  // 06057F78 mov.l 0x06057FD8,r1
    c.r[2] = ld32(c.r[1]);  // 06057F7A mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06057FC4u);  // 06057F7C mov.w 0x06057FC4,r1
    c.r[2] += c.r[1];  // 06057F7E add r1,r2
    c.r[1] = ld32(0x06057FDCu);  // 06057F80 mov.l 0x06057FDC,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06057F82 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06057F84 extu.w r1,r1
    c.r[1] <<= 2;  // 06057F86 shll2 r1
    c.r[1] += c.r[1];  // 06057F88 add r1,r1
    c.r[2] += c.r[1];  // 06057F8A add r1,r2
    c.r[2] += 4;  // 06057F8C add #4,r2
    st8(c.r[2], c.r[12]); goto L_06057FAC;  // 06057F8E bra 0x06057FAC ; mov.b r12,@r2
L_06057F92:
    c.r[1] = ld32(0x06057FD8u);  // 06057F92 mov.l 0x06057FD8,r1
    c.r[2] = ld32(c.r[1]);  // 06057F94 mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06057FC4u);  // 06057F96 mov.w 0x06057FC4,r1
    c.r[2] += c.r[1];  // 06057F98 add r1,r2
    c.r[1] = ld32(0x06057FDCu);  // 06057F9A mov.l 0x06057FDC,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06057F9C mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06057F9E extu.w r1,r1
    c.r[1] <<= 2;  // 06057FA0 shll2 r1
    c.r[1] += c.r[1];  // 06057FA2 add r1,r1
    c.r[2] += c.r[1];  // 06057FA4 add r1,r2
    c.r[2] += 4;  // 06057FA6 add #4,r2
    c.r[0] = 0xFFFFFFFFu;  // 06057FA8 mov #-1,r0
    st8(c.r[2], c.r[0]);  // 06057FAA mov.b r0,@r2
L_06057FAC:
    c.r[9] += 1;  // 06057FAC add #1,r9
    c.r[1] = 0x49u;  // 06057FAE mov #73,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 06057FB0 cmp/gt r1,r9
    if (!c.t) { SH2_POLL(c); goto L_06057EB8; }  // 06057FB2 bf 0x06057EB8
L_06057FB4:
    c.r[0] = c.r[9];  // 06057FB4 mov r9,r0
    c.t = c.r[0] == 0x4Au;  // 06057FB6 cmp/eq #74,r0
    { const bool k = !c.t; c.r[0] = 0x0u; if (k) { goto L_06057FE0; } }  // 06057FB8 bf/s 0x06057FE0 ; mov #0,r0
    goto L_06057FE2;  // 06057FBC bra 0x06057FE2 ; nop
L_06057FE0:
    c.r[0] = 0x1u;  // 06057FE0 mov #1,r0
L_06057FE2:
    c.r[3] = (uint32_t)(int16_t)ld16(0x06057FFAu);  // 06057FE2 mov.w 0x06057FFA,r3
    c.r[14] += c.r[3];  // 06057FE4 add r3,r14
    c.r[15] = c.r[14];  // 06057FE6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06057FE8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06057FEA mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06057FEC mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06057FEE mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06057FF0 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06057FF2 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06057FF4 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06057FF6 rts ; mov.l @r15+,r8
}

void f_06057FFC(SH2Context& c) {
    ran[1355] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06057FFC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06057FFE mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06058000 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06058002 mov r15,r14
    c.r[8] = c.r[4] & 0xFFu;  // 06058004 extu.b r4,r8
    c.r[2] = c.r[5] & 0xFFu;  // 06058006 extu.b r5,r2
    c.r[4] = c.r[2];  // 06058008 mov r2,r4
    c.r[0] = c.r[6] & 0xFFu;  // 0605800A extu.b r6,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605800C tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[0]; if (k) { goto L_06058032; } }  // 0605800E bf/s 0x06058032 ; mov r0,r1
    c.r[1] = ld32(0x0605807Cu);  // 06058012 mov.l 0x0605807C,r1
    c.r[1] = ld32(c.r[1]);  // 06058014 mov.l @r1,r1
    c.r[2] <<= 2;  // 06058016 shll2 r2
    c.r[2] <<= 2;  // 06058018 shll2 r2
    c.r[2] += c.r[1];  // 0605801A add r1,r2
    c.r[2] += 10;  // 0605801C add #10,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605801E mov.b @r2,r1
    c.r[0] = c.r[1];  // 06058020 mov r1,r0
    c.r[0] >>= 2;  // 06058022 shlr2 r0
    c.r[0] >>= 2;  // 06058024 shlr2 r0
    c.r[0] &= 0x1u;  // 06058026 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06058028 tst r0,r0
    { const bool k = !c.t; c.r[0] = 0x1u; if (k) { goto L_0605806E; } }  // 0605802A bf/s 0x0605806E ; mov #1,r0
    c.r[15] = c.r[14]; goto L_06058072;  // 0605802E bra 0x06058072 ; mov r14,r15
L_06058032:
    c.r[0] = c.r[1];  // 06058032 mov r1,r0
    c.t = c.r[0] == 0x2u;  // 06058034 cmp/eq #2,r0
    { const bool k = !c.t; c.r[2] <<= 2; if (k) { goto L_0605804C; } }  // 06058036 bf/s 0x0605804C ; shll2 r2
    c.r[1] = ld32(0x0605807Cu);  // 0605803A mov.l 0x0605807C,r1
    c.r[1] = ld32(c.r[1]);  // 0605803C mov.l @r1,r1
    c.r[2] <<= 2;  // 0605803E shll2 r2
    c.r[2] += c.r[1];  // 06058040 add r1,r2
    c.r[2] += 10;  // 06058042 add #10,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06058044 mov.b @r2,r0
    c.r[0] |= 0x10u;  // 06058046 or #16,r0
    st8(c.r[2], c.r[0]); goto L_0605806E;  // 06058048 bra 0x0605806E ; mov.b r0,@r2
L_0605804C:
    c.r[4] = (uint32_t)(int32_t)(int16_t)c.r[4];  // 0605804C exts.w r4,r4
    c.r[1] = ld32(0x06058080u);  // 0605804E mov.l 0x06058080,r1
    c.r[6] = 0x0u;  // 06058050 mov #0,r6
    { const uint32_t x = c.r[1]; c.pr = 0x06058056u; c.r[5] = 0x16u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06058056u) return; }  // 06058052 jsr @r1 ; mov #22,r5
    c.r[1] = ld32(0x06058084u);  // 06058056 mov.l 0x06058084,r1
    c.r[2] = ld32(c.r[1]);  // 06058058 mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605807Au);  // 0605805A mov.w 0x0605807A,r1
    c.r[2] += c.r[1];  // 0605805C add r1,r2
    c.r[1] = ld32(0x06058088u);  // 0605805E mov.l 0x06058088,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06058060 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06058062 extu.w r1,r1
    c.r[1] <<= 2;  // 06058064 shll2 r1
    c.r[1] += c.r[1];  // 06058066 add r1,r1
    c.r[2] += c.r[1];  // 06058068 add r1,r2
    c.r[2] += 4;  // 0605806A add #4,r2
    st8(c.r[2], c.r[8]);  // 0605806C mov.b r8,@r2
L_0605806E:
    c.r[0] = 0x0u;  // 0605806E mov #0,r0
    c.r[15] = c.r[14];  // 06058070 mov r14,r15
L_06058072:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06058072 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06058074 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06058076 rts ; mov.l @r15+,r8
}

void f_0605808C(SH2Context& c) {
    ran[1356] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0605808C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0605808E sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06058090 mov r15,r14
    c.r[7] = c.r[6];  // 06058092 mov r6,r7
    c.r[4] = c.r[4] & 0xFFu;  // 06058094 extu.b r4,r4
    c.r[5] = c.r[5] & 0xFFu;  // 06058096 extu.b r5,r5
    c.r[7] = c.r[7] & 0xFFu;  // 06058098 extu.b r7,r7
    c.r[0] = ld32(0x060580B0u);  // 0605809A mov.l 0x060580B0,r0
    c.r[6] = c.r[5];  // 0605809C mov r5,r6
    c.r[5] = c.r[4];  // 0605809E mov r4,r5
    { const uint32_t x = c.r[0]; c.pr = 0x060580A4u; c.r[4] = 0x17u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060580A4u) return; }  // 060580A0 jsr @r0 ; mov #23,r4
    c.r[15] = c.r[14];  // 060580A4 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060580A6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060580A8 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[0] & 0xFFu; c.pc = x; return; }  // 060580AA rts ; extu.b r0,r0
}

void f_060580B4(SH2Context& c) {
    ran[1357] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060580B4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060580B6 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060580B8 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060580BA mov r15,r14
    c.r[8] = c.r[4] & 0xFFu;  // 060580BC extu.b r4,r8
    c.r[2] = c.r[5] & 0xFFu;  // 060580BE extu.b r5,r2
    c.r[4] = c.r[2];  // 060580C0 mov r2,r4
    c.r[0] = c.r[6] & 0xFFu;  // 060580C2 extu.b r6,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060580C4 tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[0]; if (k) { goto L_060580EA; } }  // 060580C6 bf/s 0x060580EA ; mov r0,r1
    c.r[1] = ld32(0x06058134u);  // 060580CA mov.l 0x06058134,r1
    c.r[1] = ld32(c.r[1]);  // 060580CC mov.l @r1,r1
    c.r[2] <<= 2;  // 060580CE shll2 r2
    c.r[2] <<= 2;  // 060580D0 shll2 r2
    c.r[2] += c.r[1];  // 060580D2 add r1,r2
    c.r[2] += 10;  // 060580D4 add #10,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060580D6 mov.b @r2,r1
    c.r[0] = c.r[1];  // 060580D8 mov r1,r0
    c.r[0] >>= 2;  // 060580DA shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060580DC shlr r0
    c.r[0] &= 0x1u;  // 060580DE and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060580E0 tst r0,r0
    { const bool k = !c.t; c.r[0] = 0x1u; if (k) { goto L_06058126; } }  // 060580E2 bf/s 0x06058126 ; mov #1,r0
    c.r[15] = c.r[14]; goto L_0605812A;  // 060580E6 bra 0x0605812A ; mov r14,r15
L_060580EA:
    c.r[0] = c.r[1];  // 060580EA mov r1,r0
    c.t = c.r[0] == 0x2u;  // 060580EC cmp/eq #2,r0
    { const bool k = !c.t; c.r[2] <<= 2; if (k) { goto L_06058104; } }  // 060580EE bf/s 0x06058104 ; shll2 r2
    c.r[1] = ld32(0x06058134u);  // 060580F2 mov.l 0x06058134,r1
    c.r[1] = ld32(c.r[1]);  // 060580F4 mov.l @r1,r1
    c.r[2] <<= 2;  // 060580F6 shll2 r2
    c.r[2] += c.r[1];  // 060580F8 add r1,r2
    c.r[2] += 10;  // 060580FA add #10,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060580FC mov.b @r2,r0
    c.r[0] |= 0x8u;  // 060580FE or #8,r0
    st8(c.r[2], c.r[0]); goto L_06058126;  // 06058100 bra 0x06058126 ; mov.b r0,@r2
L_06058104:
    c.r[4] = (uint32_t)(int32_t)(int16_t)c.r[4];  // 06058104 exts.w r4,r4
    c.r[1] = ld32(0x06058138u);  // 06058106 mov.l 0x06058138,r1
    c.r[6] = 0x0u;  // 06058108 mov #0,r6
    { const uint32_t x = c.r[1]; c.pr = 0x0605810Eu; c.r[5] = 0x18u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605810Eu) return; }  // 0605810A jsr @r1 ; mov #24,r5
    c.r[1] = ld32(0x0605813Cu);  // 0605810E mov.l 0x0605813C,r1
    c.r[2] = ld32(c.r[1]);  // 06058110 mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06058132u);  // 06058112 mov.w 0x06058132,r1
    c.r[2] += c.r[1];  // 06058114 add r1,r2
    c.r[1] = ld32(0x06058140u);  // 06058116 mov.l 0x06058140,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06058118 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0605811A extu.w r1,r1
    c.r[1] <<= 2;  // 0605811C shll2 r1
    c.r[1] += c.r[1];  // 0605811E add r1,r1
    c.r[2] += c.r[1];  // 06058120 add r1,r2
    c.r[2] += 4;  // 06058122 add #4,r2
    st8(c.r[2], c.r[8]);  // 06058124 mov.b r8,@r2
L_06058126:
    c.r[0] = 0x0u;  // 06058126 mov #0,r0
    c.r[15] = c.r[14];  // 06058128 mov r14,r15
L_0605812A:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0605812A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0605812C mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0605812E rts ; mov.l @r15+,r8
}

void f_06058144(SH2Context& c) {
    ran[1358] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06058144 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06058146 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06058148 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0605814A mov r15,r14
    c.r[8] = c.r[4] & 0xFFu;  // 0605814C extu.b r4,r8
    c.r[2] = c.r[5] & 0xFFu;  // 0605814E extu.b r5,r2
    c.r[4] = c.r[2];  // 06058150 mov r2,r4
    c.r[0] = c.r[6] & 0xFFu;  // 06058152 extu.b r6,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06058154 tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[0]; if (k) { goto L_06058178; } }  // 06058156 bf/s 0x06058178 ; mov r0,r1
    c.r[1] = ld32(0x060581C4u);  // 0605815A mov.l 0x060581C4,r1
    c.r[1] = ld32(c.r[1]);  // 0605815C mov.l @r1,r1
    c.r[2] <<= 2;  // 0605815E shll2 r2
    c.r[2] <<= 2;  // 06058160 shll2 r2
    c.r[2] += c.r[1];  // 06058162 add r1,r2
    c.r[2] += 10;  // 06058164 add #10,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06058166 mov.b @r2,r1
    c.r[0] = c.r[1];  // 06058168 mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0605816A shlr r0
    c.r[0] &= 0x1u;  // 0605816C and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605816E tst r0,r0
    { const bool k = !c.t; c.r[0] = 0x1u; if (k) { goto L_060581B4; } }  // 06058170 bf/s 0x060581B4 ; mov #1,r0
    c.r[15] = c.r[14]; goto L_060581B8;  // 06058174 bra 0x060581B8 ; mov r14,r15
L_06058178:
    c.r[0] = c.r[1];  // 06058178 mov r1,r0
    c.t = c.r[0] == 0x2u;  // 0605817A cmp/eq #2,r0
    { const bool k = !c.t; c.r[2] <<= 2; if (k) { goto L_06058192; } }  // 0605817C bf/s 0x06058192 ; shll2 r2
    c.r[1] = ld32(0x060581C4u);  // 06058180 mov.l 0x060581C4,r1
    c.r[1] = ld32(c.r[1]);  // 06058182 mov.l @r1,r1
    c.r[2] <<= 2;  // 06058184 shll2 r2
    c.r[2] += c.r[1];  // 06058186 add r1,r2
    c.r[2] += 10;  // 06058188 add #10,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605818A mov.b @r2,r0
    c.r[0] |= 0x2u;  // 0605818C or #2,r0
    st8(c.r[2], c.r[0]); goto L_060581B4;  // 0605818E bra 0x060581B4 ; mov.b r0,@r2
L_06058192:
    c.r[4] = (uint32_t)(int32_t)(int16_t)c.r[4];  // 06058192 exts.w r4,r4
    c.r[1] = ld32(0x060581C8u);  // 06058194 mov.l 0x060581C8,r1
    c.r[6] = 0x0u;  // 06058196 mov #0,r6
    { const uint32_t x = c.r[1]; c.pr = 0x0605819Cu; c.r[5] = 0x19u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605819Cu) return; }  // 06058198 jsr @r1 ; mov #25,r5
    c.r[1] = ld32(0x060581CCu);  // 0605819C mov.l 0x060581CC,r1
    c.r[2] = ld32(c.r[1]);  // 0605819E mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x060581C0u);  // 060581A0 mov.w 0x060581C0,r1
    c.r[2] += c.r[1];  // 060581A2 add r1,r2
    c.r[1] = ld32(0x060581D0u);  // 060581A4 mov.l 0x060581D0,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060581A6 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 060581A8 extu.w r1,r1
    c.r[1] <<= 2;  // 060581AA shll2 r1
    c.r[1] += c.r[1];  // 060581AC add r1,r1
    c.r[2] += c.r[1];  // 060581AE add r1,r2
    c.r[2] += 4;  // 060581B0 add #4,r2
    st8(c.r[2], c.r[8]);  // 060581B2 mov.b r8,@r2
L_060581B4:
    c.r[0] = 0x0u;  // 060581B4 mov #0,r0
    c.r[15] = c.r[14];  // 060581B6 mov r14,r15
L_060581B8:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060581B8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060581BA mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060581BC rts ; mov.l @r15+,r8
}

void f_060581D4(SH2Context& c) {
    ran[1359] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060581D4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060581D6 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060581D8 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060581DA mov r15,r14
    c.r[8] = c.r[4] & 0xFFu;  // 060581DC extu.b r4,r8
    c.r[4] = c.r[5] & 0xFFu;  // 060581DE extu.b r5,r4
    c.r[1] = ld32(0x0605828Cu);  // 060581E0 mov.l 0x0605828C,r1
    c.r[2] = c.r[4];  // 060581E2 mov r4,r2
    c.r[1] = ld32(c.r[1]);  // 060581E4 mov.l @r1,r1
    c.r[2] <<= 2;  // 060581E6 shll2 r2
    c.r[2] <<= 2;  // 060581E8 shll2 r2
    c.r[2] += c.r[1];  // 060581EA add r1,r2
    c.r[2] += 2;  // 060581EC add #2,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060581EE mov.b @r2,r2
    c.r[1] = ld32(0x06058290u);  // 060581F0 mov.l 0x06058290,r1
    c.r[3] = ld32(c.r[1]);  // 060581F2 mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 060581F4 extu.b r2,r2
    c.r[1] = 0x1Eu;  // 060581F6 mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 060581F8 mul.l r1,r2
    c.r[0] = c.r[6] & 0xFFu;  // 060581FA extu.b r6,r0
    c.r[6] = c.r[0];  // 060581FC mov r0,r6
    c.r[1] = c.macl;  // 060581FE sts macl,r1
    c.r[1] += c.r[3];  // 06058200 add r3,r1
    c.r[1] += 15;  // 06058202 add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06058204 mov.b @r1,r1
    c.t = (c.r[0] & c.r[0]) == 0;  // 06058206 tst r0,r0
    c.r[3] = c.r[1] & 0xFFu;  // 06058208 extu.b r1,r3
    { const bool k = !c.t; c.r[7] = c.r[3]; if (k) { goto L_0605822E; } }  // 0605820A bf/s 0x0605822E ; mov r3,r7
    c.r[1] = ld32(0x06058294u);  // 0605820E mov.l 0x06058294,r1
    c.r[2] = c.r[3];  // 06058210 mov r3,r2
    c.r[2] += c.r[2];  // 06058212 add r2,r2
    c.r[2] += c.r[3];  // 06058214 add r3,r2
    c.r[1] = ld32(c.r[1]);  // 06058216 mov.l @r1,r1
    c.r[2] <<= 2;  // 06058218 shll2 r2
    c.r[2] += c.r[1];  // 0605821A add r1,r2
    c.r[2] += 9;  // 0605821C add #9,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605821E mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06058220 extu.b r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06058284u);  // 06058222 mov.w 0x06058284,r2
    c.t = c.r[1] > c.r[2];  // 06058224 cmp/hi r2,r1
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_0605827A; } }  // 06058226 bt/s 0x0605827A ; mov #0,r0
    c.r[0] = 0x1u; goto L_0605827A;  // 0605822A bra 0x0605827A ; mov #1,r0
L_0605822E:
    c.r[0] = c.r[6];  // 0605822E mov r6,r0
    c.t = c.r[0] == 0x1u;  // 06058230 cmp/eq #1,r0
    { const bool k = !c.t; c.r[2] = c.r[7]; if (k) { goto L_06058278; } }  // 06058232 bf/s 0x06058278 ; mov r7,r2
    c.r[1] = ld32(0x06058294u);  // 06058236 mov.l 0x06058294,r1
    c.r[2] += c.r[2];  // 06058238 add r2,r2
    c.r[2] += c.r[7];  // 0605823A add r7,r2
    c.r[1] = ld32(c.r[1]);  // 0605823C mov.l @r1,r1
    c.r[2] <<= 2;  // 0605823E shll2 r2
    c.r[2] += c.r[1];  // 06058240 add r1,r2
    c.r[2] += 9;  // 06058242 add #9,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06058244 mov.b @r2,r2
    c.r[6] = (uint32_t)(int16_t)ld16(0x06058286u);  // 06058246 mov.w 0x06058286,r6
    c.r[1] = c.r[2] & 0xFFu;  // 06058248 extu.b r2,r1
    c.r[1] += 10;  // 0605824A add #10,r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[6];  // 0605824C cmp/gt r6,r1
    { const bool k = !c.t; c.r[6] -= c.r[2]; if (k) { goto L_06058256; } }  // 0605824E bf/s 0x06058256 ; sub r2,r6
    c.r[6] = c.r[6] & 0xFFu; goto L_06058258;  // 06058252 bra 0x06058258 ; extu.b r6,r6
L_06058256:
    c.r[6] = 0xAu;  // 06058256 mov #10,r6
L_06058258:
    c.r[4] = (uint32_t)(int32_t)(int16_t)c.r[4];  // 06058258 exts.w r4,r4
    c.r[1] = ld32(0x06058298u);  // 0605825A mov.l 0x06058298,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06058260u; c.r[5] = 0x1Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06058260u) return; }  // 0605825C jsr @r1 ; mov #26,r5
    c.r[1] = ld32(0x0605829Cu);  // 06058260 mov.l 0x0605829C,r1
    c.r[2] = ld32(c.r[1]);  // 06058262 mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06058288u);  // 06058264 mov.w 0x06058288,r1
    c.r[2] += c.r[1];  // 06058266 add r1,r2
    c.r[1] = ld32(0x060582A0u);  // 06058268 mov.l 0x060582A0,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0605826A mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0605826C extu.w r1,r1
    c.r[1] <<= 2;  // 0605826E shll2 r1
    c.r[1] += c.r[1];  // 06058270 add r1,r1
    c.r[2] += c.r[1];  // 06058272 add r1,r2
    c.r[2] += 4;  // 06058274 add #4,r2
    st8(c.r[2], c.r[8]);  // 06058276 mov.b r8,@r2
L_06058278:
    c.r[0] = 0x0u;  // 06058278 mov #0,r0
L_0605827A:
    c.r[15] = c.r[14];  // 0605827A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0605827C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0605827E mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06058280 rts ; mov.l @r15+,r8
}

void f_060582A4(SH2Context& c) {
    ran[1360] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060582A4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060582A6 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060582A8 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060582AA mov r15,r14
    c.r[8] = c.r[4] & 0xFFu;  // 060582AC extu.b r4,r8
    c.r[2] = c.r[5] & 0xFFu;  // 060582AE extu.b r5,r2
    c.r[4] = c.r[2];  // 060582B0 mov r2,r4
    c.r[0] = c.r[6] & 0xFFu;  // 060582B2 extu.b r6,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060582B4 tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[0]; if (k) { goto L_060582DC; } }  // 060582B6 bf/s 0x060582DC ; mov r0,r1
    c.r[1] = ld32(0x06058328u);  // 060582BA mov.l 0x06058328,r1
    c.r[1] = ld32(c.r[1]);  // 060582BC mov.l @r1,r1
    c.r[2] <<= 2;  // 060582BE shll2 r2
    c.r[2] <<= 2;  // 060582C0 shll2 r2
    c.r[2] += c.r[1];  // 060582C2 add r1,r2
    c.r[2] += 10;  // 060582C4 add #10,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060582C6 mov.b @r2,r1
    c.r[0] = c.r[1];  // 060582C8 mov r1,r0
    c.r[0] >>= 2;  // 060582CA shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060582CC shlr r0
    c.r[0] >>= 2;  // 060582CE shlr2 r0
    c.r[0] &= 0x1u;  // 060582D0 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060582D2 tst r0,r0
    { const bool k = !c.t; c.r[0] = 0x1u; if (k) { goto L_06058318; } }  // 060582D4 bf/s 0x06058318 ; mov #1,r0
    c.r[15] = c.r[14]; goto L_0605831C;  // 060582D8 bra 0x0605831C ; mov r14,r15
L_060582DC:
    c.r[0] = c.r[1];  // 060582DC mov r1,r0
    c.t = c.r[0] == 0x2u;  // 060582DE cmp/eq #2,r0
    { const bool k = !c.t; c.r[2] <<= 2; if (k) { goto L_060582F6; } }  // 060582E0 bf/s 0x060582F6 ; shll2 r2
    c.r[1] = ld32(0x06058328u);  // 060582E4 mov.l 0x06058328,r1
    c.r[1] = ld32(c.r[1]);  // 060582E6 mov.l @r1,r1
    c.r[2] <<= 2;  // 060582E8 shll2 r2
    c.r[2] += c.r[1];  // 060582EA add r1,r2
    c.r[2] += 10;  // 060582EC add #10,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060582EE mov.b @r2,r0
    c.r[0] |= 0x20u;  // 060582F0 or #32,r0
    st8(c.r[2], c.r[0]); goto L_06058318;  // 060582F2 bra 0x06058318 ; mov.b r0,@r2
L_060582F6:
    c.r[4] = (uint32_t)(int32_t)(int16_t)c.r[4];  // 060582F6 exts.w r4,r4
    c.r[1] = ld32(0x0605832Cu);  // 060582F8 mov.l 0x0605832C,r1
    c.r[6] = 0x0u;  // 060582FA mov #0,r6
    { const uint32_t x = c.r[1]; c.pr = 0x06058300u; c.r[5] = 0x1Bu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06058300u) return; }  // 060582FC jsr @r1 ; mov #27,r5
    c.r[1] = ld32(0x06058330u);  // 06058300 mov.l 0x06058330,r1
    c.r[2] = ld32(c.r[1]);  // 06058302 mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06058324u);  // 06058304 mov.w 0x06058324,r1
    c.r[2] += c.r[1];  // 06058306 add r1,r2
    c.r[1] = ld32(0x06058334u);  // 06058308 mov.l 0x06058334,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0605830A mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0605830C extu.w r1,r1
    c.r[1] <<= 2;  // 0605830E shll2 r1
    c.r[1] += c.r[1];  // 06058310 add r1,r1
    c.r[2] += c.r[1];  // 06058312 add r1,r2
    c.r[2] += 4;  // 06058314 add #4,r2
    st8(c.r[2], c.r[8]);  // 06058316 mov.b r8,@r2
L_06058318:
    c.r[0] = 0x0u;  // 06058318 mov #0,r0
    c.r[15] = c.r[14];  // 0605831A mov r14,r15
L_0605831C:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0605831C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0605831E mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06058320 rts ; mov.l @r15+,r8
}

void f_06058338(SH2Context& c) {
    ran[1361] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06058338 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0605833A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0605833C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0605833E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06058340 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06058342 sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x0605841Eu);  // 06058344 mov.w 0x0605841E,r3
    c.r[15] += c.r[3];  // 06058346 add r3,r15
    c.r[14] = c.r[15];  // 06058348 mov r15,r14
    c.r[11] = c.r[4] & 0xFFu;  // 0605834A extu.b r4,r11
    c.r[0] = c.r[6] & 0xFFu;  // 0605834C extu.b r6,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605834E tst r0,r0
    { const bool k = !c.t; c.r[9] = c.r[5] & 0xFFu; if (k) { goto L_06058434; } }  // 06058350 bf/s 0x06058434 ; extu.b r5,r9
    c.r[9] = 0x0u;  // 06058354 mov #0,r9
    c.r[10] = (uint32_t)(int16_t)ld16(0x06058420u);  // 06058356 mov.w 0x06058420,r10
L_06058358:
    c.r[1] = ld32(0x06058424u);  // 06058358 mov.l 0x06058424,r1
    c.r[0] = c.r[9];  // 0605835A mov r9,r0
    c.r[0] <<= 2;  // 0605835C shll2 r0
    c.r[0] <<= 2;  // 0605835E shll2 r0
    c.r[2] = ld32(c.r[1]);  // 06058360 mov.l @r1,r2
    c.r[3] = c.r[0];  // 06058362 mov r0,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06058364 mov.b @(r0,r2),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06058366 extu.b r1,r1
    c.t = c.r[1] == c.r[10];  // 06058368 cmp/eq r10,r1
    { const bool k = c.t; c.r[3] += c.r[2]; if (k) { goto L_06058402; } }  // 0605836A bt/s 0x06058402 ; add r2,r3
    c.r[1] = c.r[3];  // 0605836E mov r3,r1
    c.r[1] += 7;  // 06058370 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06058372 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06058374 mov r1,r0
    c.r[0] >>= 2;  // 06058376 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06058378 shlr r0
    c.r[0] &= 0x1u;  // 0605837A and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605837C tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[11]; if (k) { goto L_06058402; } }  // 0605837E bf/s 0x06058402 ; mov r11,r1
    c.r[1] <<= 2;  // 06058382 shll2 r1
    c.r[1] <<= 2;  // 06058384 shll2 r1
    c.r[1] += c.r[2];  // 06058386 add r2,r1
    c.r[1] += 3;  // 06058388 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605838A mov.b @r1,r1
    c.r[7] = 0x3u;  // 0605838C mov #3,r7
    c.r[2] = c.r[1];  // 0605838E mov r1,r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 06058390 shlr r2
    c.r[1] = c.r[3];  // 06058392 mov r3,r1
    c.r[1] += 3;  // 06058394 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06058396 mov.b @r1,r1
    c.r[2] &= c.r[7];  // 06058398 and r7,r2
    c.r[0] = c.r[1];  // 0605839A mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0605839C shlr r0
    c.r[0] &= 0x3u;  // 0605839E and #3,r0
    c.t = c.r[2] == c.r[0];  // 060583A0 cmp/eq r0,r2
    { const bool k = !c.t; c.t = (c.r[2] & c.r[2]) == 0; if (k) { goto L_06058402; } }  // 060583A2 bf/s 0x06058402 ; tst r2,r2
    if (!c.t) { goto L_060583AE; }  // 060583A6 bf 0x060583AE
    c.r[1] = ld32(c.r[3] + 12);  // 060583A8 mov.l @(12,r3),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060583AA tst r1,r1
    if (!c.t) { goto L_06058402; }  // 060583AC bf 0x06058402
L_060583AE:
    c.r[1] = c.r[3];  // 060583AE mov r3,r1
    c.r[1] += 4;  // 060583B0 add #4,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060583B2 mov.b @r1,r0
    c.r[0] &= 0x60u;  // 060583B4 and #96,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060583B6 tst r0,r0
    { const bool k = !c.t; c.r[3] += 2; if (k) { goto L_06058402; } }  // 060583B8 bf/s 0x06058402 ; add #2,r3
    c.r[6] = c.r[10];  // 060583BC mov r10,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060583BE mov.b @r3,r1
    c.r[4] = c.r[14];  // 060583C0 mov r14,r4
    c.r[8] = c.r[1] & 0xFFu;  // 060583C2 extu.b r1,r8
    c.r[1] = ld32(0x06058428u);  // 060583C4 mov.l 0x06058428,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060583CAu; c.r[5] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060583CAu) return; }  // 060583C6 jsr @r1 ; mov r8,r5
    c.r[1] = ld32(0x0605842Cu);  // 060583CA mov.l 0x0605842C,r1
    c.r[2] = ld32(c.r[1]);  // 060583CC mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 060583CE mov #30,r1
    c.macl = c.r[8] * c.r[1];  // 060583D0 mul.l r1,r8
    c.r[3] = c.macl;  // 060583D2 sts macl,r3
    c.r[3] += c.r[2];  // 060583D4 add r2,r3
    c.r[3] += 22;  // 060583D6 add #22,r3
    c.r[1] = c.r[14];  // 060583D8 mov r14,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 060583DA mov.w @r3,r2
    c.r[1] += 26;  // 060583DC add #26,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060583DE mov.w @r1,r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 060583E0 extu.w r2,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 060583E2 extu.w r1,r1
    c.t = c.r[2] == c.r[1];  // 060583E4 cmp/eq r1,r2
    if (c.t) { goto L_06058402; }  // 060583E6 bt 0x06058402
    c.r[1] = ld32(0x06058430u);  // 060583E8 mov.l 0x06058430,r1
    c.r[3] = ld32(c.r[1]);  // 060583EA mov.l @r1,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x06058422u);  // 060583EC mov.w 0x06058422,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 060583EE mov.b @(r0,r3),r2
    c.r[1] = c.r[2];  // 060583F0 mov r2,r1
    c.r[1] += 1;  // 060583F2 add #1,r1
    st8(c.r[0] + c.r[3], c.r[1]);  // 060583F4 mov.b r1,@(r0,r3)
    c.r[2] = c.r[2] & 0xFFu;  // 060583F6 extu.b r2,r2
    c.r[2] <<= 2;  // 060583F8 shll2 r2
    c.r[2] += c.r[2];  // 060583FA add r2,r2
    c.r[3] += c.r[2];  // 060583FC add r2,r3
    c.r[3] += 4;  // 060583FE add #4,r3
    st8(c.r[3], c.r[9]);  // 06058400 mov.b r9,@r3
L_06058402:
    c.r[9] += 1;  // 06058402 add #1,r9
    c.r[1] = 0x49u;  // 06058404 mov #73,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 06058406 cmp/gt r1,r9
    if (!c.t) { SH2_POLL(c); goto L_06058358; }  // 06058408 bf 0x06058358
    c.r[1] = ld32(0x06058430u);  // 0605840A mov.l 0x06058430,r1
    c.r[1] = ld32(c.r[1]);  // 0605840C mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06058422u);  // 0605840E mov.w 0x06058422,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06058410 mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06058412 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06058414 tst r1,r1
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_060584B8; } }  // 06058416 bt/s 0x060584B8 ; mov #0,r0
    c.r[0] = 0x1u; goto L_060584B8;  // 0605841A bra 0x060584B8 ; mov #1,r0
L_06058434:
    c.t = c.r[0] == 0x1u;  // 06058434 cmp/eq #1,r0
    { const bool k = !c.t; c.r[2] = c.r[9]; if (k) { goto L_060584B6; } }  // 06058436 bf/s 0x060584B6 ; mov r9,r2
    c.r[1] = ld32(0x060584D4u);  // 0605843A mov.l 0x060584D4,r1
    c.r[2] <<= 2;  // 0605843C shll2 r2
    c.r[2] <<= 2;  // 0605843E shll2 r2
    c.r[1] = ld32(c.r[1]);  // 06058440 mov.l @r1,r1
    c.r[6] = (uint32_t)(int16_t)ld16(0x060584CCu);  // 06058442 mov.w 0x060584CC,r6
    c.r[2] += c.r[1];  // 06058444 add r1,r2
    c.r[2] += 2;  // 06058446 add #2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06058448 mov.b @r2,r1
    c.r[4] = c.r[14];  // 0605844A mov r14,r4
    c.r[8] = c.r[1] & 0xFFu;  // 0605844C extu.b r1,r8
    c.r[1] = ld32(0x060584D8u);  // 0605844E mov.l 0x060584D8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06058454u; c.r[5] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06058454u) return; }  // 06058450 jsr @r1 ; mov r8,r5
    c.r[1] = c.r[14];  // 06058454 mov r14,r1
    c.r[1] += 26;  // 06058456 add #26,r1
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06058458 mov.w @r1,r3
    c.r[1] = 0x1Eu;  // 0605845A mov #30,r1
    c.macl = (c.r[3] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 0605845C mulu.w r1,r3
    c.r[2] = c.macl;  // 0605845E sts macl,r2
    c.r[1] = ld32(0x060584DCu);  // 06058460 mov.l 0x060584DC,r1
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[2] * (int32_t)c.r[1]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 06058462 dmuls.l r1,r2
    c.r[6] = c.mach;  // 06058464 sts mach,r6
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 06058466 shar r6
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 06058468 shar r6
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 0605846A shar r6
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 0605846C shar r6
    c.t = c.r[6] & 1; c.r[6] = (uint32_t)((int32_t)c.r[6] >> 1);  // 0605846E shar r6
    c.t = c.r[2] >> 31; c.r[2] <<= 1;  // 06058470 shll r2
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 06058472 subc r2,r2
    c.r[6] -= c.r[2];  // 06058474 sub r2,r6
    c.r[1] = ld32(0x060584E0u);  // 06058476 mov.l 0x060584E0,r1
    c.r[2] = ld32(c.r[1]);  // 06058478 mov.l @r1,r2
    c.r[1] = 0x1Eu;  // 0605847A mov #30,r1
    c.macl = c.r[8] * c.r[1];  // 0605847C mul.l r1,r8
    c.r[1] = c.macl;  // 0605847E sts macl,r1
    c.r[1] += c.r[2];  // 06058480 add r2,r1
    c.r[1] += 22;  // 06058482 add #22,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06058484 mov.w @r1,r1
    c.r[3] = c.r[3] & 0xFFFFu;  // 06058486 extu.w r3,r3
    c.r[2] = c.r[1] & 0xFFFFu;  // 06058488 extu.w r1,r2
    c.r[1] = c.r[2];  // 0605848A mov r2,r1
    c.r[1] += c.r[6];  // 0605848C add r6,r1
    c.t = c.r[1] > c.r[3];  // 0605848E cmp/hi r3,r1
    if (!c.t) { goto L_06058496; }  // 06058490 bf 0x06058496
    c.r[6] = c.r[3];  // 06058492 mov r3,r6
    c.r[6] -= c.r[2];  // 06058494 sub r2,r6
L_06058496:
    c.r[4] = (uint32_t)(int32_t)(int16_t)c.r[9];  // 06058496 exts.w r9,r4
    c.r[1] = ld32(0x060584E4u);  // 06058498 mov.l 0x060584E4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0605849Eu; c.r[5] = 0x1Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605849Eu) return; }  // 0605849A jsr @r1 ; mov #28,r5
    c.r[1] = ld32(0x060584E8u);  // 0605849E mov.l 0x060584E8,r1
    c.r[2] = ld32(c.r[1]);  // 060584A0 mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x060584CEu);  // 060584A2 mov.w 0x060584CE,r1
    c.r[2] += c.r[1];  // 060584A4 add r1,r2
    c.r[1] = ld32(0x060584ECu);  // 060584A6 mov.l 0x060584EC,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060584A8 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 060584AA extu.w r1,r1
    c.r[1] <<= 2;  // 060584AC shll2 r1
    c.r[1] += c.r[1];  // 060584AE add r1,r1
    c.r[2] += c.r[1];  // 060584B0 add r1,r2
    c.r[2] += 4;  // 060584B2 add #4,r2
    st8(c.r[2], c.r[11]);  // 060584B4 mov.b r11,@r2
L_060584B6:
    c.r[0] = 0x0u;  // 060584B6 mov #0,r0
L_060584B8:
    c.r[3] = (uint32_t)(int16_t)ld16(0x060584D0u);  // 060584B8 mov.w 0x060584D0,r3
    c.r[14] += c.r[3];  // 060584BA add r3,r14
    c.r[15] = c.r[14];  // 060584BC mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060584BE lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060584C0 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060584C2 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060584C4 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060584C6 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060584C8 rts ; mov.l @r15+,r8
}

void f_060584F0(SH2Context& c) {
    ran[1362] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060584F0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060584F2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060584F4 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060584F6 mov r15,r14
    c.r[8] = c.r[4] & 0xFFu;  // 060584F8 extu.b r4,r8
    c.r[2] = c.r[5] & 0xFFu;  // 060584FA extu.b r5,r2
    c.r[4] = c.r[2];  // 060584FC mov r2,r4
    c.r[0] = c.r[6] & 0xFFu;  // 060584FE extu.b r6,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06058500 tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[0]; if (k) { goto L_06058528; } }  // 06058502 bf/s 0x06058528 ; mov r0,r1
    c.r[1] = ld32(0x06058574u);  // 06058506 mov.l 0x06058574,r1
    c.r[1] = ld32(c.r[1]);  // 06058508 mov.l @r1,r1
    c.r[2] <<= 2;  // 0605850A shll2 r2
    c.r[2] <<= 2;  // 0605850C shll2 r2
    c.r[2] += c.r[1];  // 0605850E add r1,r2
    c.r[2] += 10;  // 06058510 add #10,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06058512 mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06058514 extu.b r1,r1
    c.r[1] >>= 2;  // 06058516 shlr2 r1
    c.r[1] >>= 2;  // 06058518 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0605851A shlr r1
    c.r[1] >>= 2;  // 0605851C shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605851E tst r1,r1
    { const bool k = !c.t; c.r[0] = 0x1u; if (k) { goto L_06058564; } }  // 06058520 bf/s 0x06058564 ; mov #1,r0
    c.r[15] = c.r[14]; goto L_06058568;  // 06058524 bra 0x06058568 ; mov r14,r15
L_06058528:
    c.r[0] = c.r[1];  // 06058528 mov r1,r0
    c.t = c.r[0] == 0x2u;  // 0605852A cmp/eq #2,r0
    { const bool k = !c.t; c.r[2] <<= 2; if (k) { goto L_06058542; } }  // 0605852C bf/s 0x06058542 ; shll2 r2
    c.r[1] = ld32(0x06058574u);  // 06058530 mov.l 0x06058574,r1
    c.r[1] = ld32(c.r[1]);  // 06058532 mov.l @r1,r1
    c.r[2] <<= 2;  // 06058534 shll2 r2
    c.r[2] += c.r[1];  // 06058536 add r1,r2
    c.r[2] += 10;  // 06058538 add #10,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605853A mov.b @r2,r0
    c.r[0] |= 0x80u;  // 0605853C or #128,r0
    st8(c.r[2], c.r[0]); goto L_06058564;  // 0605853E bra 0x06058564 ; mov.b r0,@r2
L_06058542:
    c.r[4] = (uint32_t)(int32_t)(int16_t)c.r[4];  // 06058542 exts.w r4,r4
    c.r[1] = ld32(0x06058578u);  // 06058544 mov.l 0x06058578,r1
    c.r[6] = 0x0u;  // 06058546 mov #0,r6
    { const uint32_t x = c.r[1]; c.pr = 0x0605854Cu; c.r[5] = 0x1Du; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605854Cu) return; }  // 06058548 jsr @r1 ; mov #29,r5
    c.r[1] = ld32(0x0605857Cu);  // 0605854C mov.l 0x0605857C,r1
    c.r[2] = ld32(c.r[1]);  // 0605854E mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06058570u);  // 06058550 mov.w 0x06058570,r1
    c.r[2] += c.r[1];  // 06058552 add r1,r2
    c.r[1] = ld32(0x06058580u);  // 06058554 mov.l 0x06058580,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06058556 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06058558 extu.w r1,r1
    c.r[1] <<= 2;  // 0605855A shll2 r1
    c.r[1] += c.r[1];  // 0605855C add r1,r1
    c.r[2] += c.r[1];  // 0605855E add r1,r2
    c.r[2] += 4;  // 06058560 add #4,r2
    st8(c.r[2], c.r[8]);  // 06058562 mov.b r8,@r2
L_06058564:
    c.r[0] = 0x0u;  // 06058564 mov #0,r0
    c.r[15] = c.r[14];  // 06058566 mov r14,r15
L_06058568:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06058568 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0605856A mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0605856C rts ; mov.l @r15+,r8
}

void f_06058584(SH2Context& c) {
    ran[1363] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06058584 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06058586 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06058588 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0605858A mov r15,r14
    c.r[8] = c.r[4] & 0xFFu;  // 0605858C extu.b r4,r8
    c.r[2] = c.r[5] & 0xFFu;  // 0605858E extu.b r5,r2
    c.r[4] = c.r[2];  // 06058590 mov r2,r4
    c.r[0] = c.r[6] & 0xFFu;  // 06058592 extu.b r6,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06058594 tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[0]; if (k) { goto L_060585B8; } }  // 06058596 bf/s 0x060585B8 ; mov r0,r1
    c.r[1] = ld32(0x06058604u);  // 0605859A mov.l 0x06058604,r1
    c.r[1] = ld32(c.r[1]);  // 0605859C mov.l @r1,r1
    c.r[2] <<= 2;  // 0605859E shll2 r2
    c.r[2] <<= 2;  // 060585A0 shll2 r2
    c.r[2] += c.r[1];  // 060585A2 add r1,r2
    c.r[2] += 10;  // 060585A4 add #10,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060585A6 mov.b @r2,r1
    c.r[0] = c.r[1];  // 060585A8 mov r1,r0
    c.r[0] >>= 2;  // 060585AA shlr2 r0
    c.r[0] &= 0x1u;  // 060585AC and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060585AE tst r0,r0
    { const bool k = !c.t; c.r[0] = 0x1u; if (k) { goto L_060585F4; } }  // 060585B0 bf/s 0x060585F4 ; mov #1,r0
    c.r[15] = c.r[14]; goto L_060585F8;  // 060585B4 bra 0x060585F8 ; mov r14,r15
L_060585B8:
    c.r[0] = c.r[1];  // 060585B8 mov r1,r0
    c.t = c.r[0] == 0x2u;  // 060585BA cmp/eq #2,r0
    { const bool k = !c.t; c.r[2] <<= 2; if (k) { goto L_060585D2; } }  // 060585BC bf/s 0x060585D2 ; shll2 r2
    c.r[1] = ld32(0x06058604u);  // 060585C0 mov.l 0x06058604,r1
    c.r[1] = ld32(c.r[1]);  // 060585C2 mov.l @r1,r1
    c.r[2] <<= 2;  // 060585C4 shll2 r2
    c.r[2] += c.r[1];  // 060585C6 add r1,r2
    c.r[2] += 10;  // 060585C8 add #10,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060585CA mov.b @r2,r0
    c.r[0] |= 0x4u;  // 060585CC or #4,r0
    st8(c.r[2], c.r[0]); goto L_060585F4;  // 060585CE bra 0x060585F4 ; mov.b r0,@r2
L_060585D2:
    c.r[4] = (uint32_t)(int32_t)(int16_t)c.r[4];  // 060585D2 exts.w r4,r4
    c.r[1] = ld32(0x06058608u);  // 060585D4 mov.l 0x06058608,r1
    c.r[6] = 0x0u;  // 060585D6 mov #0,r6
    { const uint32_t x = c.r[1]; c.pr = 0x060585DCu; c.r[5] = 0x1Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060585DCu) return; }  // 060585D8 jsr @r1 ; mov #30,r5
    c.r[1] = ld32(0x0605860Cu);  // 060585DC mov.l 0x0605860C,r1
    c.r[2] = ld32(c.r[1]);  // 060585DE mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06058600u);  // 060585E0 mov.w 0x06058600,r1
    c.r[2] += c.r[1];  // 060585E2 add r1,r2
    c.r[1] = ld32(0x06058610u);  // 060585E4 mov.l 0x06058610,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060585E6 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 060585E8 extu.w r1,r1
    c.r[1] <<= 2;  // 060585EA shll2 r1
    c.r[1] += c.r[1];  // 060585EC add r1,r1
    c.r[2] += c.r[1];  // 060585EE add r1,r2
    c.r[2] += 4;  // 060585F0 add #4,r2
    st8(c.r[2], c.r[8]);  // 060585F2 mov.b r8,@r2
L_060585F4:
    c.r[0] = 0x0u;  // 060585F4 mov #0,r0
    c.r[15] = c.r[14];  // 060585F6 mov r14,r15
L_060585F8:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060585F8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060585FA mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060585FC rts ; mov.l @r15+,r8
}

void f_06058614(SH2Context& c) {
    ran[1364] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06058614 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06058616 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06058618 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0605861A mov r15,r14
    c.r[8] = c.r[4] & 0xFFu;  // 0605861C extu.b r4,r8
    c.r[2] = c.r[5] & 0xFFu;  // 0605861E extu.b r5,r2
    c.r[4] = c.r[2];  // 06058620 mov r2,r4
    c.r[0] = c.r[6] & 0xFFu;  // 06058622 extu.b r6,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06058624 tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[0]; if (k) { goto L_06058644; } }  // 06058626 bf/s 0x06058644 ; mov r0,r1
    c.r[1] = ld32(0x06058690u);  // 0605862A mov.l 0x06058690,r1
    c.r[1] = ld32(c.r[1]);  // 0605862C mov.l @r1,r1
    c.r[2] <<= 2;  // 0605862E shll2 r2
    c.r[2] <<= 2;  // 06058630 shll2 r2
    c.r[2] += c.r[1];  // 06058632 add r1,r2
    c.r[2] += 10;  // 06058634 add #10,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06058636 mov.b @r2,r0
    c.r[0] &= 0x1u;  // 06058638 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605863A tst r0,r0
    { const bool k = !c.t; c.r[0] = 0x1u; if (k) { goto L_06058680; } }  // 0605863C bf/s 0x06058680 ; mov #1,r0
    c.r[15] = c.r[14]; goto L_06058684;  // 06058640 bra 0x06058684 ; mov r14,r15
L_06058644:
    c.r[0] = c.r[1];  // 06058644 mov r1,r0
    c.t = c.r[0] == 0x2u;  // 06058646 cmp/eq #2,r0
    { const bool k = !c.t; c.r[2] <<= 2; if (k) { goto L_0605865E; } }  // 06058648 bf/s 0x0605865E ; shll2 r2
    c.r[1] = ld32(0x06058690u);  // 0605864C mov.l 0x06058690,r1
    c.r[1] = ld32(c.r[1]);  // 0605864E mov.l @r1,r1
    c.r[2] <<= 2;  // 06058650 shll2 r2
    c.r[2] += c.r[1];  // 06058652 add r1,r2
    c.r[2] += 10;  // 06058654 add #10,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06058656 mov.b @r2,r0
    c.r[0] |= 0x1u;  // 06058658 or #1,r0
    st8(c.r[2], c.r[0]); goto L_06058680;  // 0605865A bra 0x06058680 ; mov.b r0,@r2
L_0605865E:
    c.r[4] = (uint32_t)(int32_t)(int16_t)c.r[4];  // 0605865E exts.w r4,r4
    c.r[1] = ld32(0x06058694u);  // 06058660 mov.l 0x06058694,r1
    c.r[6] = 0x0u;  // 06058662 mov #0,r6
    { const uint32_t x = c.r[1]; c.pr = 0x06058668u; c.r[5] = 0x1Fu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06058668u) return; }  // 06058664 jsr @r1 ; mov #31,r5
    c.r[1] = ld32(0x06058698u);  // 06058668 mov.l 0x06058698,r1
    c.r[2] = ld32(c.r[1]);  // 0605866A mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605868Cu);  // 0605866C mov.w 0x0605868C,r1
    c.r[2] += c.r[1];  // 0605866E add r1,r2
    c.r[1] = ld32(0x0605869Cu);  // 06058670 mov.l 0x0605869C,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06058672 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06058674 extu.w r1,r1
    c.r[1] <<= 2;  // 06058676 shll2 r1
    c.r[1] += c.r[1];  // 06058678 add r1,r1
    c.r[2] += c.r[1];  // 0605867A add r1,r2
    c.r[2] += 4;  // 0605867C add #4,r2
    st8(c.r[2], c.r[8]);  // 0605867E mov.b r8,@r2
L_06058680:
    c.r[0] = 0x0u;  // 06058680 mov #0,r0
    c.r[15] = c.r[14];  // 06058682 mov r14,r15
L_06058684:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06058684 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06058686 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06058688 rts ; mov.l @r15+,r8
}

void f_060586A0(SH2Context& c) {
    ran[1365] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060586A0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060586A2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060586A4 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060586A6 mov r15,r14
    c.r[8] = c.r[4] & 0xFFu;  // 060586A8 extu.b r4,r8
    c.r[1] = c.r[6] & 0xFFu;  // 060586AA extu.b r6,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060586AC tst r1,r1
    { const bool k = !c.t; c.r[4] = c.r[5] & 0xFFu; if (k) { goto L_0605877E; } }  // 060586AE bf/s 0x0605877E ; extu.b r5,r4
    c.r[6] = 0x0u;  // 060586B2 mov #0,r6
    c.r[4] = (uint32_t)(int16_t)ld16(0x060587F8u);  // 060586B4 mov.w 0x060587F8,r4
    c.r[5] = (uint32_t)(int16_t)ld16(0x060587FAu);  // 060586B6 mov.w 0x060587FA,r5
    c.r[7] = 0x0u;  // 060586B8 mov #0,r7
L_060586BA:
    c.r[1] = ld32(0x06058804u);  // 060586BA mov.l 0x06058804,r1
    c.r[2] = c.r[7];  // 060586BC mov r7,r2
    c.r[3] = ld32(c.r[1]);  // 060586BE mov.l @r1,r3
    c.r[0] = c.r[7];  // 060586C0 mov r7,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 060586C2 mov.b @(r0,r3),r1
    c.r[1] = c.r[1] & 0xFFu;  // 060586C4 extu.b r1,r1
    c.t = c.r[1] == c.r[4];  // 060586C6 cmp/eq r4,r1
    { const bool k = c.t; c.r[2] += c.r[3]; if (k) { goto L_06058760; } }  // 060586C8 bt/s 0x06058760 ; add r3,r2
    c.r[1] = c.r[2];  // 060586CC mov r2,r1
    c.r[1] += 7;  // 060586CE add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060586D0 mov.b @r1,r1
    c.r[0] = c.r[1];  // 060586D2 mov r1,r0
    c.r[0] >>= 2;  // 060586D4 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060586D6 shlr r0
    c.r[0] &= 0x1u;  // 060586D8 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060586DA tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[8]; if (k) { goto L_06058760; } }  // 060586DC bf/s 0x06058760 ; mov r8,r1
    c.r[1] <<= 2;  // 060586E0 shll2 r1
    c.r[1] <<= 2;  // 060586E2 shll2 r1
    c.r[1] += c.r[3];  // 060586E4 add r3,r1
    c.r[1] += 3;  // 060586E6 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060586E8 mov.b @r1,r1
    c.r[0] = 0x3u;  // 060586EA mov #3,r0
    c.r[3] = c.r[1];  // 060586EC mov r1,r3
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 060586EE shlr r3
    c.r[1] = c.r[2];  // 060586F0 mov r2,r1
    c.r[1] += 3;  // 060586F2 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060586F4 mov.b @r1,r1
    c.r[3] &= c.r[0];  // 060586F6 and r0,r3
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060586F8 shlr r1
    c.r[1] &= c.r[0];  // 060586FA and r0,r1
    c.t = c.r[3] == c.r[1];  // 060586FC cmp/eq r1,r3
    { const bool k = !c.t; c.t = (c.r[3] & c.r[3]) == 0; if (k) { goto L_06058760; } }  // 060586FE bf/s 0x06058760 ; tst r3,r3
    if (!c.t) { goto L_0605870A; }  // 06058702 bf 0x0605870A
    c.r[1] = ld32(c.r[2] + 12);  // 06058704 mov.l @(12,r2),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06058706 tst r1,r1
    if (!c.t) { goto L_06058760; }  // 06058708 bf 0x06058760
L_0605870A:
    c.r[1] = c.r[2];  // 0605870A mov r2,r1
    c.r[1] += 4;  // 0605870C add #4,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605870E mov.b @r1,r0
    c.r[0] &= 0x60u;  // 06058710 and #96,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06058712 tst r0,r0
    { const bool k = !c.t; c.r[2] += 2; if (k) { goto L_06058760; } }  // 06058714 bf/s 0x06058760 ; add #2,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06058718 mov.b @r2,r2
    c.r[1] = ld32(0x06058808u);  // 0605871A mov.l 0x06058808,r1
    c.r[3] = ld32(c.r[1]);  // 0605871C mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 0605871E extu.b r2,r2
    c.r[1] = 0x1Eu;  // 06058720 mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 06058722 mul.l r1,r2
    c.r[1] = c.macl;  // 06058724 sts macl,r1
    c.r[1] += c.r[3];  // 06058726 add r3,r1
    c.r[1] += 15;  // 06058728 add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605872A mov.b @r1,r1
    c.r[3] = c.r[1] & 0xFFu;  // 0605872C extu.b r1,r3
    c.r[1] = ld32(0x0605880Cu);  // 0605872E mov.l 0x0605880C,r1
    c.r[2] = c.r[3];  // 06058730 mov r3,r2
    c.r[2] += c.r[2];  // 06058732 add r2,r2
    c.r[2] += c.r[3];  // 06058734 add r3,r2
    c.r[1] = ld32(c.r[1]);  // 06058736 mov.l @r1,r1
    c.r[2] <<= 2;  // 06058738 shll2 r2
    c.r[2] += c.r[1];  // 0605873A add r1,r2
    c.r[2] += 9;  // 0605873C add #9,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0605873E mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06058740 extu.b r1,r1
    c.t = c.r[1] > c.r[5];  // 06058742 cmp/hi r5,r1
    if (c.t) { goto L_06058760; }  // 06058744 bt 0x06058760
    c.r[1] = ld32(0x06058810u);  // 06058746 mov.l 0x06058810,r1
    c.r[3] = ld32(c.r[1]);  // 06058748 mov.l @r1,r3
    c.r[0] = (uint32_t)(int16_t)ld16(0x060587FCu);  // 0605874A mov.w 0x060587FC,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0605874C mov.b @(r0,r3),r2
    c.r[1] = c.r[2];  // 0605874E mov r2,r1
    c.r[1] += 1;  // 06058750 add #1,r1
    st8(c.r[0] + c.r[3], c.r[1]);  // 06058752 mov.b r1,@(r0,r3)
    c.r[2] = c.r[2] & 0xFFu;  // 06058754 extu.b r2,r2
    c.r[2] <<= 2;  // 06058756 shll2 r2
    c.r[2] += c.r[2];  // 06058758 add r2,r2
    c.r[3] += c.r[2];  // 0605875A add r2,r3
    c.r[3] += 4;  // 0605875C add #4,r3
    st8(c.r[3], c.r[6]);  // 0605875E mov.b r6,@r3
L_06058760:
    c.r[6] += 1;  // 06058760 add #1,r6
    c.r[1] = 0x49u;  // 06058762 mov #73,r1
    c.t = (int32_t)c.r[6] > (int32_t)c.r[1];  // 06058764 cmp/gt r1,r6
    { const bool k = !c.t; c.r[7] += 16; if (k) { SH2_POLL(c); goto L_060586BA; } }  // 06058766 bf/s 0x060586BA ; add #16,r7
    c.r[1] = ld32(0x06058810u);  // 0605876A mov.l 0x06058810,r1
    c.r[1] = ld32(c.r[1]);  // 0605876C mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x060587FCu);  // 0605876E mov.w 0x060587FC,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06058770 mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06058772 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06058774 tst r1,r1
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_060587EE; } }  // 06058776 bt/s 0x060587EE ; mov #0,r0
    c.r[0] = 0x1u; goto L_060587EE;  // 0605877A bra 0x060587EE ; mov #1,r0
L_0605877E:
    c.r[0] = c.r[1];  // 0605877E mov r1,r0
    c.t = c.r[0] == 0x1u;  // 06058780 cmp/eq #1,r0
    { const bool k = !c.t; c.r[2] = c.r[4]; if (k) { goto L_060587EC; } }  // 06058782 bf/s 0x060587EC ; mov r4,r2
    c.r[1] = ld32(0x06058804u);  // 06058786 mov.l 0x06058804,r1
    c.r[1] = ld32(c.r[1]);  // 06058788 mov.l @r1,r1
    c.r[2] <<= 2;  // 0605878A shll2 r2
    c.r[2] <<= 2;  // 0605878C shll2 r2
    c.r[2] += c.r[1];  // 0605878E add r1,r2
    c.r[2] += 2;  // 06058790 add #2,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06058792 mov.b @r2,r2
    c.r[1] = ld32(0x06058808u);  // 06058794 mov.l 0x06058808,r1
    c.r[3] = ld32(c.r[1]);  // 06058796 mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06058798 extu.b r2,r2
    c.r[1] = 0x1Eu;  // 0605879A mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 0605879C mul.l r1,r2
    c.r[1] = c.macl;  // 0605879E sts macl,r1
    c.r[1] += c.r[3];  // 060587A0 add r3,r1
    c.r[1] += 15;  // 060587A2 add #15,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060587A4 mov.b @r1,r1
    c.r[3] = c.r[1] & 0xFFu;  // 060587A6 extu.b r1,r3
    c.r[1] = ld32(0x0605880Cu);  // 060587A8 mov.l 0x0605880C,r1
    c.r[2] = c.r[3];  // 060587AA mov r3,r2
    c.r[2] += c.r[2];  // 060587AC add r2,r2
    c.r[2] += c.r[3];  // 060587AE add r3,r2
    c.r[1] = ld32(c.r[1]);  // 060587B0 mov.l @r1,r1
    c.r[2] <<= 2;  // 060587B2 shll2 r2
    c.r[2] += c.r[1];  // 060587B4 add r1,r2
    c.r[2] += 9;  // 060587B6 add #9,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060587B8 mov.b @r2,r2
    c.r[6] = (uint32_t)(int16_t)ld16(0x060587FEu);  // 060587BA mov.w 0x060587FE,r6
    c.r[1] = c.r[2] & 0xFFu;  // 060587BC extu.b r2,r1
    c.r[1] += 10;  // 060587BE add #10,r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[6];  // 060587C0 cmp/gt r6,r1
    { const bool k = !c.t; c.r[6] -= c.r[2]; if (k) { goto L_060587CA; } }  // 060587C2 bf/s 0x060587CA ; sub r2,r6
    c.r[6] = c.r[6] & 0xFFu; goto L_060587CC;  // 060587C6 bra 0x060587CC ; extu.b r6,r6
L_060587CA:
    c.r[6] = 0xAu;  // 060587CA mov #10,r6
L_060587CC:
    c.r[4] = (uint32_t)(int32_t)(int16_t)c.r[4];  // 060587CC exts.w r4,r4
    c.r[1] = ld32(0x06058814u);  // 060587CE mov.l 0x06058814,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060587D4u; c.r[5] = 0x20u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060587D4u) return; }  // 060587D0 jsr @r1 ; mov #32,r5
    c.r[1] = ld32(0x06058810u);  // 060587D4 mov.l 0x06058810,r1
    c.r[2] = ld32(c.r[1]);  // 060587D6 mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06058800u);  // 060587D8 mov.w 0x06058800,r1
    c.r[2] += c.r[1];  // 060587DA add r1,r2
    c.r[1] = ld32(0x06058818u);  // 060587DC mov.l 0x06058818,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060587DE mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 060587E0 extu.w r1,r1
    c.r[1] <<= 2;  // 060587E2 shll2 r1
    c.r[1] += c.r[1];  // 060587E4 add r1,r1
    c.r[2] += c.r[1];  // 060587E6 add r1,r2
    c.r[2] += 4;  // 060587E8 add #4,r2
    st8(c.r[2], c.r[8]);  // 060587EA mov.b r8,@r2
L_060587EC:
    c.r[0] = 0x0u;  // 060587EC mov #0,r0
L_060587EE:
    c.r[15] = c.r[14];  // 060587EE mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060587F0 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060587F2 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060587F4 rts ; mov.l @r15+,r8
}

void f_0605881C(SH2Context& c) {
    ran[1366] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0605881C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0605881E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06058820 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06058822 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06058824 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06058826 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06058828 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0605882A mov r15,r14
    c.r[8] = c.r[4] & 0xFFu;  // 0605882C extu.b r4,r8
    c.r[1] = c.r[6] & 0xFFu;  // 0605882E extu.b r6,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06058830 tst r1,r1
    { const bool k = !c.t; c.r[4] = c.r[5] & 0xFFu; if (k) { goto L_060588D0; } }  // 06058832 bf/s 0x060588D0 ; extu.b r5,r4
    c.r[6] = 0x0u;  // 06058836 mov #0,r6
    c.r[4] = (uint32_t)(int16_t)ld16(0x06058946u);  // 06058838 mov.w 0x06058946,r4
    c.r[5] = (uint32_t)(int16_t)ld16(0x06058948u);  // 0605883A mov.w 0x06058948,r5
    c.r[7] = 0x0u;  // 0605883C mov #0,r7
L_0605883E:
    c.r[1] = ld32(0x0605894Cu);  // 0605883E mov.l 0x0605894C,r1
    c.r[3] = c.r[7];  // 06058840 mov r7,r3
    c.r[2] = ld32(c.r[1]);  // 06058842 mov.l @r1,r2
    c.r[0] = c.r[7];  // 06058844 mov r7,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06058846 mov.b @(r0,r2),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06058848 extu.b r1,r1
    c.t = c.r[1] == c.r[4];  // 0605884A cmp/eq r4,r1
    { const bool k = c.t; c.r[3] += c.r[2]; if (k) { goto L_060588B2; } }  // 0605884C bt/s 0x060588B2 ; add r2,r3
    c.r[1] = c.r[3];  // 06058850 mov r3,r1
    c.r[1] += 7;  // 06058852 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06058854 mov.b @r1,r1
    c.r[0] = c.r[1];  // 06058856 mov r1,r0
    c.r[0] >>= 2;  // 06058858 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0605885A shlr r0
    c.r[0] &= 0x1u;  // 0605885C and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0605885E tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[8]; if (k) { goto L_060588B2; } }  // 06058860 bf/s 0x060588B2 ; mov r8,r1
    c.r[1] <<= 2;  // 06058864 shll2 r1
    c.r[1] <<= 2;  // 06058866 shll2 r1
    c.r[1] += c.r[2];  // 06058868 add r2,r1
    c.r[1] += 3;  // 0605886A add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0605886C mov.b @r1,r1
    c.r[0] = 0x3u;  // 0605886E mov #3,r0
    c.r[2] = c.r[1];  // 06058870 mov r1,r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 06058872 shlr r2
    c.r[1] = c.r[3];  // 06058874 mov r3,r1
    c.r[1] += 3;  // 06058876 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06058878 mov.b @r1,r1
    c.r[2] &= c.r[0];  // 0605887A and r0,r2
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0605887C shlr r1
    c.r[1] &= c.r[0];  // 0605887E and r0,r1
    c.t = c.r[2] == c.r[1];  // 06058880 cmp/eq r1,r2
    { const bool k = !c.t; c.t = (c.r[2] & c.r[2]) == 0; if (k) { goto L_060588B2; } }  // 06058882 bf/s 0x060588B2 ; tst r2,r2
    if (!c.t) { goto L_0605888E; }  // 06058886 bf 0x0605888E
    c.r[1] = ld32(c.r[3] + 12);  // 06058888 mov.l @(12,r3),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0605888A tst r1,r1
    if (!c.t) { goto L_060588B2; }  // 0605888C bf 0x060588B2
L_0605888E:
    c.r[0] = ld32(c.r[3] + 4);  // 0605888E mov.l @(4,r3),r0
    c.r[1] = ld32(0x06058950u);  // 06058890 mov.l 0x06058950,r1
    c.r[0] &= c.r[1];  // 06058892 and r1,r0
    c.t = c.r[0] == 0x10u;  // 06058894 cmp/eq #16,r0
    if (!c.t) { goto L_060588B2; }  // 06058896 bf 0x060588B2
    c.r[1] = ld32(0x06058954u);  // 06058898 mov.l 0x06058954,r1
    c.r[3] = ld32(c.r[1]);  // 0605889A mov.l @r1,r3
    c.r[0] = c.r[3];  // 0605889C mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 0605889E mov.b @(r0,r5),r2
    c.r[1] = c.r[2];  // 060588A0 mov r2,r1
    c.r[1] += 1;  // 060588A2 add #1,r1
    st8(c.r[0] + c.r[5], c.r[1]);  // 060588A4 mov.b r1,@(r0,r5)
    c.r[2] = c.r[2] & 0xFFu;  // 060588A6 extu.b r2,r2
    c.r[2] <<= 2;  // 060588A8 shll2 r2
    c.r[2] += c.r[2];  // 060588AA add r2,r2
    c.r[3] += c.r[2];  // 060588AC add r2,r3
    c.r[3] += 4;  // 060588AE add #4,r3
    st8(c.r[3], c.r[6]);  // 060588B0 mov.b r6,@r3
L_060588B2:
    c.r[6] += 1;  // 060588B2 add #1,r6
    c.r[1] = 0x49u;  // 060588B4 mov #73,r1
    c.t = (int32_t)c.r[6] > (int32_t)c.r[1];  // 060588B6 cmp/gt r1,r6
    { const bool k = !c.t; c.r[7] += 16; if (k) { SH2_POLL(c); goto L_0605883E; } }  // 060588B8 bf/s 0x0605883E ; add #16,r7
    c.r[1] = ld32(0x06058954u);  // 060588BC mov.l 0x06058954,r1
    c.r[1] = ld32(c.r[1]);  // 060588BE mov.l @r1,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x06058948u);  // 060588C0 mov.w 0x06058948,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060588C2 mov.b @(r0,r1),r1
    c.r[1] = c.r[1] & 0xFFu;  // 060588C4 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060588C6 tst r1,r1
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_06058988; } }  // 060588C8 bt/s 0x06058988 ; mov #0,r0
    c.r[0] = 0x1u; goto L_06058988;  // 060588CC bra 0x06058988 ; mov #1,r0
L_060588D0:
    c.r[0] = c.r[1];  // 060588D0 mov r1,r0
    c.t = c.r[0] == 0x2u;  // 060588D2 cmp/eq #2,r0
    if (!c.t) { goto L_06058964; }  // 060588D4 bf 0x06058964
    c.r[8] = c.r[4];  // 060588D6 mov r4,r8
    c.r[11] = ld32(0x0605894Cu);  // 060588D8 mov.l 0x0605894C,r11
    c.r[1] = ld32(c.r[11]);  // 060588DA mov.l @r11,r1
    c.r[8] <<= 2;  // 060588DC shll2 r8
    c.r[8] <<= 2;  // 060588DE shll2 r8
    c.r[1] += c.r[8];  // 060588E0 add r8,r1
    c.r[1] += 7;  // 060588E2 add #7,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060588E4 mov.b @r1,r0
    c.r[0] &= 0xEFu;  // 060588E6 and #239,r0
    st8(c.r[1], c.r[0]);  // 060588E8 mov.b r0,@r1
    c.r[1] = ld32(c.r[11]);  // 060588EA mov.l @r11,r1
    c.r[3] = ld32(0x06058958u);  // 060588EC mov.l 0x06058958,r3
    c.r[1] += c.r[8];  // 060588EE add r8,r1
    c.r[1] += 3;  // 060588F0 add #3,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060588F2 mov.b @r1,r0
    c.r[2] = ld32(0x0605895Cu);  // 060588F4 mov.l 0x0605895C,r2
    c.r[0] |= 0x20u;  // 060588F6 or #32,r0
    st8(c.r[1], c.r[0]);  // 060588F8 mov.b r0,@r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]); c.r[3] += 2;  // 060588FA mov.w @r3+,r1
    c.r[0] = ld32(0x06058960u);  // 060588FC mov.l 0x06058960,r0
    c.r[2] = ld32(c.r[2] + 8);  // 060588FE mov.l @(8,r2),r2
    c.r[1] += c.r[4];  // 06058900 add r4,r1
    c.r[1] += 1;  // 06058902 add #1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06058904 extu.w r1,r1
    c.r[12] = c.r[1];  // 06058906 mov r1,r12
    c.r[12] <<= 2;  // 06058908 shll2 r12
    c.r[12] += c.r[1];  // 0605890A add r1,r12
    c.r[12] += c.r[12];  // 0605890C add r12,r12
    c.r[12] += c.r[2];  // 0605890E add r2,r12
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06058910 mov.b @r3,r1
    c.r[12] += 4;  // 06058912 add #4,r12
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[12]);  // 06058914 mov.w @r12,r2
    c.r[9] = c.r[1] & 0xFFu;  // 06058916 extu.b r1,r9
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605894Au);  // 06058918 mov.w 0x0605894A,r1
    c.r[10] = c.r[1];  // 0605891A mov r1,r10
    { const uint32_t x = c.r[0]; c.pr = 0x06058920u; c.r[10] &= c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06058920u) return; }  // 0605891C jsr @r0 ; and r2,r10
    c.r[1] = c.r[0] & 0xFFFFu;  // 06058920 extu.w r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06058922 tst r1,r1
    if (c.t) { goto L_06058938; }  // 06058924 bt 0x06058938
    c.r[1] = ld32(c.r[11]);  // 06058926 mov.l @r11,r1
    c.r[8] += c.r[1];  // 06058928 add r1,r8
    c.r[8] += 3;  // 0605892A add #3,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0605892C mov.b @r8,r1
    c.r[0] = c.r[1];  // 0605892E mov r1,r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06058930 shlr r0
    c.r[0] &= 0x3u;  // 06058932 and #3,r0
    c.r[9] += c.r[0]; goto L_0605893A;  // 06058934 bra 0x0605893A ; add r0,r9
L_06058938:
    c.r[9] += 3;  // 06058938 add #3,r9
L_0605893A:
    c.r[9] <<= 2;  // 0605893A shll2 r9
    c.r[9] <<= 2;  // 0605893C shll2 r9
    c.r[1] = c.r[10];  // 0605893E mov r10,r1
    c.r[1] |= c.r[9];  // 06058940 or r9,r1
    st16(c.r[12], c.r[1]); goto L_06058986;  // 06058942 bra 0x06058986 ; mov.w r1,@r12
L_06058964:
    c.r[4] = (uint32_t)(int32_t)(int16_t)c.r[4];  // 06058964 exts.w r4,r4
    c.r[1] = ld32(0x0605899Cu);  // 06058966 mov.l 0x0605899C,r1
    c.r[6] = 0x0u;  // 06058968 mov #0,r6
    { const uint32_t x = c.r[1]; c.pr = 0x0605896Eu; c.r[5] = 0x21u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0605896Eu) return; }  // 0605896A jsr @r1 ; mov #33,r5
    c.r[1] = ld32(0x060589A0u);  // 0605896E mov.l 0x060589A0,r1
    c.r[2] = ld32(c.r[1]);  // 06058970 mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x0605899Au);  // 06058972 mov.w 0x0605899A,r1
    c.r[2] += c.r[1];  // 06058974 add r1,r2
    c.r[1] = ld32(0x060589A4u);  // 06058976 mov.l 0x060589A4,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06058978 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0605897A extu.w r1,r1
    c.r[1] <<= 2;  // 0605897C shll2 r1
    c.r[1] += c.r[1];  // 0605897E add r1,r1
    c.r[2] += c.r[1];  // 06058980 add r1,r2
    c.r[2] += 4;  // 06058982 add #4,r2
    st8(c.r[2], c.r[8]);  // 06058984 mov.b r8,@r2
L_06058986:
    c.r[0] = 0x0u;  // 06058986 mov #0,r0
L_06058988:
    c.r[15] = c.r[14];  // 06058988 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0605898A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0605898C mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0605898E mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06058990 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06058992 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06058994 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06058996 rts ; mov.l @r15+,r8
}

void f_060589A8(SH2Context& c) {
    ran[1367] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060589A8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060589AA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060589AC mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 060589AE mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 060589B0 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 060589B2 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060589B4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060589B6 sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x06058A8Au);  // 060589B8 mov.w 0x06058A8A,r3
    c.r[15] += c.r[3];  // 060589BA add r3,r15
    c.r[14] = c.r[15];  // 060589BC mov r15,r14
    c.r[8] = c.r[4] & 0xFFu;  // 060589BE extu.b r4,r8
    c.r[10] = c.r[8];  // 060589C0 mov r8,r10
    c.r[11] = c.r[5] & 0xFFu;  // 060589C2 extu.b r5,r11
    c.r[13] = c.r[11];  // 060589C4 mov r11,r13
    c.r[0] = c.r[6] & 0xFFu;  // 060589C6 extu.b r6,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060589C8 tst r0,r0
    { const bool k = !c.t; c.r[1] = c.r[0]; if (k) { goto L_06058AA4; } }  // 060589CA bf/s 0x06058AA4 ; mov r0,r1
    c.r[1] = ld32(0x06058A94u);  // 060589CE mov.l 0x06058A94,r1
    c.r[2] = c.r[8];  // 060589D0 mov r8,r2
    c.r[1] = ld32(c.r[1]);  // 060589D2 mov.l @r1,r1
    c.r[2] <<= 2;  // 060589D4 shll2 r2
    c.r[2] <<= 2;  // 060589D6 shll2 r2
    c.r[2] += c.r[1];  // 060589D8 add r1,r2
    c.r[1] = c.r[2];  // 060589DA mov r2,r1
    c.r[1] += 4;  // 060589DC add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060589DE mov.b @r1,r1
    c.r[0] = c.r[1];  // 060589E0 mov r1,r0
    c.r[0] >>= 2;  // 060589E2 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 060589E4 shlr r0
    c.r[0] >>= 2;  // 060589E6 shlr2 r0
    c.r[0] &= 0x1u;  // 060589E8 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060589EA tst r0,r0
    { const bool k = c.t; c.r[9] = 0x0u; if (k) { goto L_060589F6; } }  // 060589EC bt/s 0x060589F6 ; mov #0,r9
    c.r[2] += 6;  // 060589F0 add #6,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060589F2 mov.b @r2,r1
    c.r[10] = c.r[1] & 0xFFu;  // 060589F4 extu.b r1,r10
L_060589F6:
    c.r[11] = (uint32_t)(int16_t)ld16(0x06058A8Cu);  // 060589F6 mov.w 0x06058A8C,r11
    c.r[8] = 0x0u;  // 060589F8 mov #0,r8
L_060589FA:
    c.r[1] = ld32(0x06058A94u);  // 060589FA mov.l 0x06058A94,r1
    c.r[5] = c.r[8];  // 060589FC mov r8,r5
    c.r[3] = ld32(c.r[1]);  // 060589FE mov.l @r1,r3
    c.r[0] = c.r[8];  // 06058A00 mov r8,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06058A02 mov.b @(r0,r3),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06058A04 extu.b r1,r1
    c.t = c.r[1] == c.r[11];  // 06058A06 cmp/eq r11,r1
    { const bool k = c.t; c.r[5] += c.r[3]; if (k) { goto L_06058A7C; } }  // 06058A08 bt/s 0x06058A7C ; add r3,r5
    c.r[1] = c.r[5];  // 06058A0C mov r5,r1
    c.r[1] += 3;  // 06058A0E add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06058A10 mov.b @r1,r1
    c.r[0] = 0x3u;  // 06058A12 mov #3,r0
    c.r[2] = c.r[1];  // 06058A14 mov r1,r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 06058A16 shlr r2
    c.r[1] = c.r[10];  // 06058A18 mov r10,r1
    c.r[1] <<= 2;  // 06058A1A shll2 r1
    c.r[1] <<= 2;  // 06058A1C shll2 r1
    c.r[1] += c.r[3];  // 06058A1E add r3,r1
    c.r[1] += 3;  // 06058A20 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06058A22 mov.b @r1,r1
    c.r[2] &= c.r[0];  // 06058A24 and r0,r2
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06058A26 shlr r1
    c.r[1] &= c.r[0];  // 06058A28 and r0,r1
    c.t = c.r[2] == c.r[1];  // 06058A2A cmp/eq r1,r2
    if (!c.t) { goto L_06058A7C; }  // 06058A2C bf 0x06058A7C
    c.r[0] = ld32(c.r[5] + 4);  // 06058A2E mov.l @(4,r5),r0
    c.r[1] = ld32(0x06058A98u);  // 06058A30 mov.l 0x06058A98,r1
    c.r[0] &= c.r[1];  // 06058A32 and r1,r0
    c.t = c.r[0] == 0x8u;  // 06058A34 cmp/eq #8,r0
    { const bool k = !c.t; c.t = (c.r[2] & c.r[2]) == 0; if (k) { goto L_06058A7C; } }  // 06058A36 bf/s 0x06058A7C ; tst r2,r2
    if (!c.t) { goto L_06058A42; }  // 06058A3A bf 0x06058A42
    c.r[1] = ld32(c.r[5] + 12);  // 06058A3C mov.l @(12,r5),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06058A3E tst r1,r1
    if (!c.t) { goto L_06058A7C; }  // 06058A40 bf 0x06058A7C
L_06058A42:
    c.r[5] += 2;  // 06058A42 add #2,r5
    c.r[1] = ld32(0x06058A9Cu);  // 06058A44 mov.l 0x06058A9C,r1
    c.r[6] = c.r[11];  // 06058A46 mov r11,r6
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[5]);  // 06058A48 mov.b @r5,r5
    c.r[4] = c.r[14];  // 06058A4A mov r14,r4
    { const uint32_t x = c.r[1]; c.pr = 0x06058A50u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06058A50u) return; }  // 06058A4C jsr @r1 ; extu.b r5,r5
    c.r[1] = c.r[14];  // 06058A50 mov r14,r1
    c.r[1] += 37;  // 06058A52 add #37,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06058A8Eu);  // 06058A54 mov.w 0x06058A8E,r2
    c.r[5] = c.r[14];  // 06058A56 mov r14,r5
    c.r[4] = c.r[14];  // 06058A58 mov r14,r4
    c.r[4] += c.r[2];  // 06058A5A add r2,r4
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06058A5C mov.b @r1,r6
    c.r[0] = ld32(0x06058AA0u);  // 06058A5E mov.l 0x06058AA0,r0
    c.r[6] = c.r[6] & 0xFFu;  // 06058A60 extu.b r6,r6
    c.r[6] >>= 2;  // 06058A62 shlr2 r6
    c.r[6] >>= 2;  // 06058A64 shlr2 r6
    c.r[1] = (uint32_t)(int16_t)ld16(0x06058A90u);  // 06058A66 mov.w 0x06058A90,r1
    { const uint32_t x = c.r[0]; c.pr = 0x06058A6Cu; c.r[5] += c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06058A6Cu) return; }  // 06058A68 jsr @r0 ; add r1,r5
    c.r[1] = c.r[0];  // 06058A6C mov r0,r1
    c.r[3] = (uint32_t)(int32_t)(int8_t)c.r[1];  // 06058A6E exts.b r1,r3
    c.r[0] = c.r[3];  // 06058A70 mov r3,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 06058A72 cmp/eq #-1,r0
    { const bool k = c.t; c.r[0] = 0x1u; if (k) { goto L_06058A7C; } }  // 06058A74 bt/s 0x06058A7C ; mov #1,r0
    goto L_06058BCA;  // 06058A78 bra 0x06058BCA ; nop
L_06058A7C:
    c.r[9] += 1;  // 06058A7C add #1,r9
    c.r[1] = 0x49u;  // 06058A7E mov #73,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 06058A80 cmp/gt r1,r9
    { const bool k = !c.t; c.r[8] += 16; if (k) { SH2_POLL(c); goto L_060589FA; } }  // 06058A82 bf/s 0x060589FA ; add #16,r8
    c.r[0] = 0x0u; goto L_06058BCA;  // 06058A86 bra 0x06058BCA ; mov #0,r0
L_06058AA4:
    c.r[0] = c.r[1];  // 06058AA4 mov r1,r0
    c.t = c.r[0] == 0x2u;  // 06058AA6 cmp/eq #2,r0
    { const bool k = !c.t; c.r[9] = c.r[11]; if (k) { goto L_06058BA6; } }  // 06058AA8 bf/s 0x06058BA6 ; mov r11,r9
    c.r[6] = (uint32_t)(int16_t)ld16(0x06058BE2u);  // 06058AAC mov.w 0x06058BE2,r6
    c.r[12] = ld32(0x06058BF0u);  // 06058AAE mov.l 0x06058BF0,r12
    c.r[1] = ld32(c.r[12]);  // 06058AB0 mov.l @r12,r1
    c.r[9] <<= 2;  // 06058AB2 shll2 r9
    c.r[9] <<= 2;  // 06058AB4 shll2 r9
    c.r[1] += c.r[9];  // 06058AB6 add r9,r1
    c.r[1] += 2;  // 06058AB8 add #2,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06058ABA mov.b @r1,r5
    c.r[4] = c.r[14];  // 06058ABC mov r14,r4
    c.r[1] = ld32(0x06058BF4u);  // 06058ABE mov.l 0x06058BF4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06058AC4u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06058AC4u) return; }  // 06058AC0 jsr @r1 ; extu.b r5,r5
    c.r[10] = (uint32_t)(int16_t)ld16(0x06058BE4u);  // 06058AC4 mov.w 0x06058BE4,r10
    c.r[4] = c.r[14];  // 06058AC6 mov r14,r4
    c.r[4] += c.r[10];  // 06058AC8 add r10,r4
    c.r[2] = c.r[8];  // 06058ACA mov r8,r2
    c.r[2] <<= 2;  // 06058ACC shll2 r2
    c.r[2] <<= 2;  // 06058ACE shll2 r2
    c.r[1] = ld32(c.r[12]);  // 06058AD0 mov.l @r12,r1
    c.r[0] = c.r[2];  // 06058AD2 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06058AD4 mov.b @(r0,r1),r1
    c.r[8] = (uint32_t)(int16_t)ld16(0x06058BE6u);  // 06058AD6 mov.w 0x06058BE6,r8
    c.r[0] = c.r[14];  // 06058AD8 mov r14,r0
    st8(c.r[0] + c.r[10], c.r[1]);  // 06058ADA mov.b r1,@(r0,r10)
    c.r[1] = ld32(c.r[12]);  // 06058ADC mov.l @r12,r1
    c.r[5] = c.r[14];  // 06058ADE mov r14,r5
    c.r[2] += c.r[1];  // 06058AE0 add r1,r2
    c.r[2] += 1;  // 06058AE2 add #1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06058AE4 mov.b @r2,r1
    c.r[5] += c.r[8];  // 06058AE6 add r8,r5
    st8(c.r[0] + c.r[8], c.r[1]);  // 06058AE8 mov.b r1,@(r0,r8)
    c.r[1] = c.r[14];  // 06058AEA mov r14,r1
    c.r[1] += 37;  // 06058AEC add #37,r1
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06058AEE mov.b @r1,r6
    c.r[0] = ld32(0x06058BF8u);  // 06058AF0 mov.l 0x06058BF8,r0
    c.r[6] = c.r[6] & 0xFFu;  // 06058AF2 extu.b r6,r6
    c.r[6] >>= 2;  // 06058AF4 shlr2 r6
    { const uint32_t x = c.r[0]; c.pr = 0x06058AFAu; c.r[6] >>= 2; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06058AFAu) return; }  // 06058AF6 jsr @r0 ; shlr2 r6
    c.r[1] = c.r[0];  // 06058AFA mov r0,r1
    c.r[3] = (uint32_t)(int32_t)(int8_t)c.r[1];  // 06058AFC exts.b r1,r3
    c.r[1] = ld32(c.r[12]);  // 06058AFE mov.l @r12,r1
    c.r[1] += c.r[9];  // 06058B00 add r9,r1
    c.r[1] += 3;  // 06058B02 add #3,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06058B04 mov.b @r1,r2
    c.r[0] = 0x20u;  // 06058B06 mov #32,r0
    c.r[2] |= c.r[0];  // 06058B08 or r0,r2
    st8(c.r[1], c.r[2]);  // 06058B0A mov.b r2,@r1
    c.r[1] = 0x3u;  // 06058B0C mov #3,r1
    c.r[1] &= c.r[3];  // 06058B0E and r3,r1
    c.r[2] = ld32(c.r[12]);  // 06058B10 mov.l @r12,r2
    c.r[1] <<= 2;  // 06058B12 shll2 r1
    c.r[1] += c.r[1];  // 06058B14 add r1,r1
    c.r[2] += c.r[9];  // 06058B16 add r9,r2
    c.r[2] += 3;  // 06058B18 add #3,r2
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06058B1A mov.b @r2,r7
    c.r[0] = (uint32_t)(int16_t)ld16(0x06058BE8u);  // 06058B1C mov.w 0x06058BE8,r0
    c.r[7] &= c.r[0];  // 06058B1E and r0,r7
    c.r[7] |= c.r[1];  // 06058B20 or r1,r7
    c.r[0] = c.r[3];  // 06058B22 mov r3,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 06058B24 cmp/eq #-1,r0
    { const bool k = c.t; st8(c.r[2], c.r[7]); if (k) { goto L_06058BC8; } }  // 06058B26 bt/s 0x06058BC8 ; mov.b r7,@r2
    c.r[0] = c.r[14];  // 06058B2A mov r14,r0
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 06058B2C mov.b @(r0,r8),r6
    c.r[4] = c.r[11];  // 06058B2E mov r11,r4
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[10]);  // 06058B30 mov.b @(r0,r10),r5
    c.r[6] = c.r[6] & 0xFFu;  // 06058B32 extu.b r6,r6
    c.r[8] = ld32(0x06058BFCu);  // 06058B34 mov.l 0x06058BFC,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06058B3Au; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06058B3Au) return; }  // 06058B36 jsr @r8 ; extu.b r5,r5
    c.r[7] = ld32(0x06058C00u);  // 06058B3A mov.l 0x06058C00,r7
    c.r[1] = c.r[9];  // 06058B3C mov r9,r1
    c.r[0] = c.r[9];  // 06058B3E mov r9,r0
    c.r[3] = ld32(c.r[12]);  // 06058B40 mov.l @r12,r3
    c.r[10] = c.r[8];  // 06058B42 mov r8,r10
    c.r[1] += c.r[3];  // 06058B44 add r3,r1
    c.r[1] += 1;  // 06058B46 add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06058B48 mov.b @r1,r2
    c.r[8] = 0x0u;  // 06058B4A mov #0,r8
    c.r[2] = c.r[2] & 0xFFu;  // 06058B4C extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 06058B4E mov.b @(r0,r3),r1
    c.r[2] <<= 2;  // 06058B50 shll2 r2
    c.r[2] <<= 2;  // 06058B52 shll2 r2
    c.r[2] <<= 2;  // 06058B54 shll2 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06058B56 extu.b r1,r1
    c.r[3] = ld32(c.r[7]);  // 06058B58 mov.l @r7,r3
    c.r[9] = 0x0u;  // 06058B5A mov #0,r9
    c.r[2] += c.r[3];  // 06058B5C add r3,r2
    c.r[0] = c.r[2];  // 06058B5E mov r2,r0
    st8(c.r[0] + c.r[1], c.r[11]);  // 06058B60 mov.b r11,@(r0,r1)
L_06058B62:
    c.r[1] = ld32(0x06058BF0u);  // 06058B62 mov.l 0x06058BF0,r1
    c.r[3] = c.r[8];  // 06058B64 mov r8,r3
    c.r[0] = ld32(c.r[1]);  // 06058B66 mov.l @r1,r0
    c.r[2] = (uint32_t)(int16_t)ld16(0x06058BE2u);  // 06058B68 mov.w 0x06058BE2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 06058B6A mov.b @(r0,r8),r1
    c.r[1] = c.r[1] & 0xFFu;  // 06058B6C extu.b r1,r1
    c.t = c.r[1] == c.r[2];  // 06058B6E cmp/eq r2,r1
    { const bool k = c.t; c.r[3] += c.r[0]; if (k) { goto L_06058B98; } }  // 06058B70 bt/s 0x06058B98 ; add r0,r3
    c.r[2] = ld32(c.r[3] + 4);  // 06058B74 mov.l @(4,r3),r2
    c.r[1] = ld32(0x06058C04u);  // 06058B76 mov.l 0x06058C04,r1
    c.r[2] &= c.r[1];  // 06058B78 and r1,r2
    c.t = c.r[2] == c.r[1];  // 06058B7A cmp/eq r1,r2
    { const bool k = !c.t; c.r[3] += 6; if (k) { goto L_06058B98; } }  // 06058B7C bf/s 0x06058B98 ; add #6,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06058B80 mov.b @r3,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06058B82 extu.b r1,r1
    c.t = c.r[1] == c.r[13];  // 06058B84 cmp/eq r13,r1
    { const bool k = !c.t; c.r[4] = c.r[9] & 0xFFu; if (k) { goto L_06058B98; } }  // 06058B86 bf/s 0x06058B98 ; extu.b r9,r4
    c.r[0] = (uint32_t)(int16_t)ld16(0x06058BE6u);  // 06058B8A mov.w 0x06058BE6,r0
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 06058B8C mov.b @(r0,r14),r6
    c.r[0] = (uint32_t)(int16_t)ld16(0x06058BE4u);  // 06058B8E mov.w 0x06058BE4,r0
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 06058B90 mov.b @(r0,r14),r5
    c.r[6] = c.r[6] & 0xFFu;  // 06058B92 extu.b r6,r6
    { const uint32_t x = c.r[10]; c.pr = 0x06058B98u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06058B98u) return; }  // 06058B94 jsr @r10 ; extu.b r5,r5
L_06058B98:
    c.r[9] += 1;  // 06058B98 add #1,r9
    c.r[1] = 0x49u;  // 06058B9A mov #73,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 06058B9C cmp/gt r1,r9
    { const bool k = !c.t; c.r[8] += 16; if (k) { SH2_POLL(c); goto L_06058B62; } }  // 06058B9E bf/s 0x06058B62 ; add #16,r8
    c.r[0] = 0x0u; goto L_06058BCA;  // 06058BA2 bra 0x06058BCA ; mov #0,r0
L_06058BA6:
    c.r[4] = (uint32_t)(int32_t)(int16_t)c.r[13];  // 06058BA6 exts.w r13,r4
    c.r[1] = ld32(0x06058C08u);  // 06058BA8 mov.l 0x06058C08,r1
    c.r[6] = 0x0u;  // 06058BAA mov #0,r6
    { const uint32_t x = c.r[1]; c.pr = 0x06058BB0u; c.r[5] = 0x22u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06058BB0u) return; }  // 06058BAC jsr @r1 ; mov #34,r5
    c.r[1] = ld32(0x06058C0Cu);  // 06058BB0 mov.l 0x06058C0C,r1
    c.r[2] = ld32(c.r[1]);  // 06058BB2 mov.l @r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06058BEAu);  // 06058BB4 mov.w 0x06058BEA,r1
    c.r[2] += c.r[1];  // 06058BB6 add r1,r2
    c.r[1] = ld32(0x06058C10u);  // 06058BB8 mov.l 0x06058C10,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06058BBA mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06058BBC extu.w r1,r1
    c.r[1] <<= 2;  // 06058BBE shll2 r1
    c.r[1] += c.r[1];  // 06058BC0 add r1,r1
    c.r[2] += c.r[1];  // 06058BC2 add r1,r2
    c.r[2] += 4;  // 06058BC4 add #4,r2
    st8(c.r[2], c.r[10]);  // 06058BC6 mov.b r10,@r2
L_06058BC8:
    c.r[0] = 0x0u;  // 06058BC8 mov #0,r0
L_06058BCA:
    c.r[3] = (uint32_t)(int16_t)ld16(0x06058BECu);  // 06058BCA mov.w 0x06058BEC,r3
    c.r[14] += c.r[3];  // 06058BCC add r3,r14
    c.r[15] = c.r[14];  // 06058BCE mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06058BD0 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06058BD2 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06058BD4 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06058BD6 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06058BD8 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06058BDA mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06058BDC mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06058BDE rts ; mov.l @r15+,r8
}

void f_06058C14(SH2Context& c) {
    ran[1368] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06058C14 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06058C16 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06058C18 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06058C1A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06058C1C mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06058C1E mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06058C20 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06058C22 sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x06058CCEu);  // 06058C24 mov.w 0x06058CCE,r3
    c.r[15] += c.r[3];  // 06058C26 add r3,r15
    c.r[12] = c.r[4] & 0xFFu;  // 06058C28 extu.b r4,r12
    c.r[8] = ld32(0x06058CDCu);  // 06058C2A mov.l 0x06058CDC,r8
    c.r[9] = c.r[12];  // 06058C2C mov r12,r9
    c.r[9] <<= 2;  // 06058C2E shll2 r9
    c.r[9] <<= 2;  // 06058C30 shll2 r9
    c.r[1] = ld32(c.r[8]);  // 06058C32 mov.l @r8,r1
    c.r[0] = c.r[9];  // 06058C34 mov r9,r0
    st8(c.r[0] + c.r[1], c.r[5]);  // 06058C36 mov.b r5,@(r0,r1)
    c.r[1] = ld32(c.r[8]);  // 06058C38 mov.l @r8,r1
    c.r[14] = c.r[15];  // 06058C3A mov r15,r14
    c.r[1] += c.r[9];  // 06058C3C add r9,r1
    c.r[1] += 1;  // 06058C3E add #1,r1
    st8(c.r[1], c.r[6]);  // 06058C40 mov.b r6,@r1
    c.r[1] = ld32(c.r[8]);  // 06058C42 mov.l @r8,r1
    c.r[10] = (uint32_t)(int16_t)ld16(0x06058CD0u);  // 06058C44 mov.w 0x06058CD0,r10
    c.r[1] += c.r[9];  // 06058C46 add r9,r1
    c.r[1] += 7;  // 06058C48 add #7,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06058C4A mov.b @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06058CD2u);  // 06058C4C mov.w 0x06058CD2,r0
    c.r[2] &= c.r[0];  // 06058C4E and r0,r2
    st8(c.r[1], c.r[2]);  // 06058C50 mov.b r2,@r1
    c.r[1] = ld32(c.r[8]);  // 06058C52 mov.l @r8,r1
    c.r[10] += c.r[14];  // 06058C54 add r14,r10
    c.r[1] += c.r[9];  // 06058C56 add r9,r1
    c.r[1] += 7;  // 06058C58 add #7,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06058C5A mov.b @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06058CD4u);  // 06058C5C mov.w 0x06058CD4,r0
    c.r[2] &= c.r[0];  // 06058C5E and r0,r2
    st8(c.r[1], c.r[2]);  // 06058C60 mov.b r2,@r1
    c.r[1] = ld32(c.r[8]);  // 06058C62 mov.l @r8,r1
    c.r[4] = c.r[10];  // 06058C64 mov r10,r4
    c.r[1] += c.r[9];  // 06058C66 add r9,r1
    c.r[1] += 2;  // 06058C68 add #2,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06058C6A mov.b @r1,r5
    c.r[6] = (uint32_t)(int16_t)ld16(0x06058CD6u);  // 06058C6C mov.w 0x06058CD6,r6
    c.r[1] = ld32(0x06058CE0u);  // 06058C6E mov.l 0x06058CE0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06058C74u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06058C74u) return; }  // 06058C70 jsr @r1 ; extu.b r5,r5
    c.r[1] = ld32(c.r[8]);  // 06058C74 mov.l @r8,r1
    c.r[9] += c.r[1];  // 06058C76 add r1,r9
    c.r[9] += 2;  // 06058C78 add #2,r9
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06058C7A mov.b @r9,r2
    c.r[1] = ld32(0x06058CE4u);  // 06058C7C mov.l 0x06058CE4,r1
    c.r[3] = ld32(c.r[1]);  // 06058C7E mov.l @r1,r3
    c.r[2] = c.r[2] & 0xFFu;  // 06058C80 extu.b r2,r2
    c.r[1] = 0x1Eu;  // 06058C82 mov #30,r1
    c.macl = c.r[2] * c.r[1];  // 06058C84 mul.l r1,r2
    c.r[8] = (uint32_t)(int16_t)ld16(0x06058CD8u);  // 06058C86 mov.w 0x06058CD8,r8
    c.r[8] += c.r[10];  // 06058C88 add r10,r8
    c.r[1] = c.macl;  // 06058C8A sts macl,r1
    c.r[1] += c.r[3];  // 06058C8C add r3,r1
    c.r[1] += 15;  // 06058C8E add #15,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06058C90 mov.b @r1,r5
    c.r[4] = c.r[8];  // 06058C92 mov r8,r4
    c.r[1] = ld32(0x06058CE8u);  // 06058C94 mov.l 0x06058CE8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06058C9Au; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06058C9Au) return; }  // 06058C96 jsr @r1 ; extu.b r5,r5
    c.r[8] += 22;  // 06058C9A add #22,r8
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06058C9C mov.w @r8,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06058CDAu);  // 06058C9E mov.w 0x06058CDA,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 06058CA0 extu.w r1,r1
    c.t = c.r[1] > c.r[2];  // 06058CA2 cmp/hi r2,r1
    { const bool k = !c.t; c.r[10] += 32; if (k) { goto L_06058CB2; } }  // 06058CA4 bf/s 0x06058CB2 ; add #32,r10
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[10]);  // 06058CA8 mov.w @r10,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06058CAA extu.w r1,r1
    c.t = c.r[1] > c.r[2];  // 06058CAC cmp/hi r2,r1
    { const bool k = c.t; c.r[1] = 0x1u; if (k) { goto L_06058CB4; } }  // 06058CAE bt/s 0x06058CB4 ; mov #1,r1
L_06058CB2:
    c.r[1] = 0x0u;  // 06058CB2 mov #0,r1
L_06058CB4:
    c.r[1] = c.r[1] & 0xFFu;  // 06058CB4 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06058CB6 tst r1,r1
    { const bool k = c.t; c.r[2] = c.r[12]; if (k) { goto L_06058CEC; } }  // 06058CB8 bt/s 0x06058CEC ; mov r12,r2
    c.r[1] = ld32(0x06058CDCu);  // 06058CBC mov.l 0x06058CDC,r1
    c.r[1] = ld32(c.r[1]);  // 06058CBE mov.l @r1,r1
    c.r[2] <<= 2;  // 06058CC0 shll2 r2
    c.r[2] <<= 2;  // 06058CC2 shll2 r2
    c.r[2] += c.r[1];  // 06058CC4 add r1,r2
    c.r[2] += 7;  // 06058CC6 add #7,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06058CC8 mov.b @r2,r0
    c.r[0] |= 0x20u; goto L_06058CFC;  // 06058CCA bra 0x06058CFC ; or #32,r0
L_06058CEC:
    c.r[1] = ld32(0x06058EF8u);  // 06058CEC mov.l 0x06058EF8,r1
    c.r[1] = ld32(c.r[1]);  // 06058CEE mov.l @r1,r1
    c.r[2] <<= 2;  // 06058CF0 shll2 r2
    c.r[2] <<= 2;  // 06058CF2 shll2 r2
    c.r[2] += c.r[1];  // 06058CF4 add r1,r2
    c.r[2] += 7;  // 06058CF6 add #7,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06058CF8 mov.b @r2,r0
    c.r[0] &= 0xDFu;  // 06058CFA and #223,r0
L_06058CFC:
    st8(c.r[2], c.r[0]);  // 06058CFC mov.b r0,@r2
    c.r[8] = ld32(0x06058EF8u);  // 06058CFE mov.l 0x06058EF8,r8
    c.r[9] = c.r[12];  // 06058D00 mov r12,r9
    c.r[9] <<= 2;  // 06058D02 shll2 r9
    c.r[9] <<= 2;  // 06058D04 shll2 r9
    c.r[1] = ld32(c.r[8]);  // 06058D06 mov.l @r8,r1
    c.r[2] = 0xFFFFFFFFu;  // 06058D08 mov #-1,r2
    c.r[1] += c.r[9];  // 06058D0A add r9,r1
    c.r[1] += 8;  // 06058D0C add #8,r1
    st8(c.r[1], c.r[2]);  // 06058D0E mov.b r2,@r1
    c.r[1] = ld32(c.r[8]);  // 06058D10 mov.l @r8,r1
    c.r[1] += c.r[9];  // 06058D12 add r9,r1
    c.r[1] += 9;  // 06058D14 add #9,r1
    st8(c.r[1], c.r[2]);  // 06058D16 mov.b r2,@r1
    c.r[1] = ld32(c.r[8]);  // 06058D18 mov.l @r8,r1
    c.r[1] += c.r[9];  // 06058D1A add r9,r1
    c.r[1] += 10;  // 06058D1C add #10,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06058D1E mov.b @r1,r2
    c.r[0] = 0x7Fu;  // 06058D20 mov #127,r0
    c.r[2] &= c.r[0];  // 06058D22 and r0,r2
    st8(c.r[1], c.r[2]);  // 06058D24 mov.b r2,@r1
    c.r[1] = ld32(c.r[8]);  // 06058D26 mov.l @r8,r1
    c.r[1] += c.r[9];  // 06058D28 add r9,r1
    c.r[1] += 10;  // 06058D2A add #10,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06058D2C mov.b @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06058EE2u);  // 06058D2E mov.w 0x06058EE2,r0
    c.r[2] &= c.r[0];  // 06058D30 and r0,r2
    st8(c.r[1], c.r[2]);  // 06058D32 mov.b r2,@r1
    c.r[1] = ld32(c.r[8]);  // 06058D34 mov.l @r8,r1
    c.r[1] += c.r[9];  // 06058D36 add r9,r1
    c.r[1] += 10;  // 06058D38 add #10,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06058D3A mov.b @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06058EE4u);  // 06058D3C mov.w 0x06058EE4,r0
    c.r[2] &= c.r[0];  // 06058D3E and r0,r2
    st8(c.r[1], c.r[2]);  // 06058D40 mov.b r2,@r1
    c.r[1] = ld32(c.r[8]);  // 06058D42 mov.l @r8,r1
    c.r[1] += c.r[9];  // 06058D44 add r9,r1
    c.r[1] += 10;  // 06058D46 add #10,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06058D48 mov.b @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06058EE6u);  // 06058D4A mov.w 0x06058EE6,r0
    c.r[2] &= c.r[0];  // 06058D4C and r0,r2
    st8(c.r[1], c.r[2]);  // 06058D4E mov.b r2,@r1
    c.r[1] = ld32(c.r[8]);  // 06058D50 mov.l @r8,r1
    c.r[1] += c.r[9];  // 06058D52 add r9,r1
    c.r[1] += 10;  // 06058D54 add #10,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06058D56 mov.b @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06058EE8u);  // 06058D58 mov.w 0x06058EE8,r0
    c.r[2] &= c.r[0];  // 06058D5A and r0,r2
    st8(c.r[1], c.r[2]);  // 06058D5C mov.b r2,@r1
    c.r[1] = ld32(c.r[8]);  // 06058D5E mov.l @r8,r1
    c.r[1] += c.r[9];  // 06058D60 add r9,r1
    c.r[1] += 10;  // 06058D62 add #10,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06058D64 mov.b @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06058EEAu);  // 06058D66 mov.w 0x06058EEA,r0
    c.r[2] &= c.r[0];  // 06058D68 and r0,r2
    st8(c.r[1], c.r[2]);  // 06058D6A mov.b r2,@r1
    c.r[1] = ld32(c.r[8]);  // 06058D6C mov.l @r8,r1
    c.r[1] += c.r[9];  // 06058D6E add r9,r1
    c.r[1] += 10;  // 06058D70 add #10,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06058D72 mov.b @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06058EECu);  // 06058D74 mov.w 0x06058EEC,r0
    c.r[2] &= c.r[0];  // 06058D76 and r0,r2
    st8(c.r[1], c.r[2]);  // 06058D78 mov.b r2,@r1
    c.r[1] = ld32(c.r[8]);  // 06058D7A mov.l @r8,r1
    c.r[1] += c.r[9];  // 06058D7C add r9,r1
    c.r[1] += 10;  // 06058D7E add #10,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06058D80 mov.b @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06058EEEu);  // 06058D82 mov.w 0x06058EEE,r0
    c.r[2] &= c.r[0];  // 06058D84 and r0,r2
    st8(c.r[1], c.r[2]);  // 06058D86 mov.b r2,@r1
    c.r[1] = ld32(c.r[8]);  // 06058D88 mov.l @r8,r1
    c.r[1] += c.r[9];  // 06058D8A add r9,r1
    c.r[1] += 11;  // 06058D8C add #11,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06058D8E mov.b @r1,r2
    c.r[0] = 0x7Fu;  // 06058D90 mov #127,r0
    c.r[2] &= c.r[0];  // 06058D92 and r0,r2
    st8(c.r[1], c.r[2]);  // 06058D94 mov.b r2,@r1
    c.r[1] = ld32(c.r[8]);  // 06058D96 mov.l @r8,r1
    c.r[1] += c.r[9];  // 06058D98 add r9,r1
    c.r[1] += 11;  // 06058D9A add #11,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06058D9C mov.b @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06058EE2u);  // 06058D9E mov.w 0x06058EE2,r0
    c.r[2] &= c.r[0];  // 06058DA0 and r0,r2
    st8(c.r[1], c.r[2]);  // 06058DA2 mov.b r2,@r1
    c.r[1] = ld32(c.r[8]);  // 06058DA4 mov.l @r8,r1
    c.r[1] += c.r[9];  // 06058DA6 add r9,r1
    c.r[1] += 11;  // 06058DA8 add #11,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06058DAA mov.b @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06058EE4u);  // 06058DAC mov.w 0x06058EE4,r0
    c.r[2] &= c.r[0];  // 06058DAE and r0,r2
    st8(c.r[1], c.r[2]);  // 06058DB0 mov.b r2,@r1
    c.r[1] = ld32(c.r[8]);  // 06058DB2 mov.l @r8,r1
    c.r[1] += c.r[9];  // 06058DB4 add r9,r1
    c.r[1] += 11;  // 06058DB6 add #11,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06058DB8 mov.b @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06058EE6u);  // 06058DBA mov.w 0x06058EE6,r0
    c.r[2] &= c.r[0];  // 06058DBC and r0,r2
    st8(c.r[1], c.r[2]);  // 06058DBE mov.b r2,@r1
    c.r[1] = ld32(c.r[8]);  // 06058DC0 mov.l @r8,r1
    c.r[1] += c.r[9];  // 06058DC2 add r9,r1
    c.r[1] += 11;  // 06058DC4 add #11,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06058DC6 mov.b @r1,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x06058EE8u);  // 06058DC8 mov.w 0x06058EE8,r0
    c.r[2] &= c.r[0];  // 06058DCA and r0,r2
    st8(c.r[1], c.r[2]);  // 06058DCC mov.b r2,@r1
    c.r[1] = ld32(c.r[8]);  // 06058DCE mov.l @r8,r1
    c.r[10] = ld32(0x06058EFCu);  // 06058DD0 mov.l 0x06058EFC,r10
    c.r[1] += c.r[9];  // 06058DD2 add r9,r1
    c.r[1] += 2;  // 06058DD4 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06058DD6 mov.b @r1,r1
    c.r[6] = (uint32_t)(int16_t)ld16(0x06058EF0u);  // 06058DD8 mov.w 0x06058EF0,r6
    c.r[5] = c.r[1] & 0xFFu;  // 06058DDA extu.b r1,r5
    c.r[1] = 0x1Eu;  // 06058DDC mov #30,r1
    c.macl = c.r[5] * c.r[1];  // 06058DDE mul.l r1,r5
    c.r[4] = c.r[14];  // 06058DE0 mov r14,r4
    c.r[2] = ld32(c.r[10]);  // 06058DE2 mov.l @r10,r2
    c.r[11] = c.macl;  // 06058DE4 sts macl,r11
    c.r[2] += c.r[11];  // 06058DE6 add r11,r2
    c.r[2] += 15;  // 06058DE8 add #15,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06058DEA mov.b @r2,r1
    c.r[0] = ld32(0x06058F00u);  // 06058DEC mov.l 0x06058F00,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06058DF2u; c.r[13] = c.r[1] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06058DF2u) return; }  // 06058DEE jsr @r0 ; extu.b r1,r13
    c.r[4] = (uint32_t)(int16_t)ld16(0x06058EF2u);  // 06058DF2 mov.w 0x06058EF2,r4
    c.r[4] += c.r[14];  // 06058DF4 add r14,r4
    c.r[1] = ld32(0x06058F04u);  // 06058DF6 mov.l 0x06058F04,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06058DFCu; c.r[5] = c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06058DFCu) return; }  // 06058DF8 jsr @r1 ; mov r13,r5
    c.macl = c.r[11];  // 06058DFC lds r11,macl
    c.r[0] = (uint32_t)(int16_t)ld16(0x06058EE4u);  // 06058DFE mov.w 0x06058EE4,r0
    c.r[1] = ld32(c.r[10]);  // 06058E00 mov.l @r10,r1
    c.r[2] = c.macl;  // 06058E02 sts macl,r2
    c.r[2] += c.r[1];  // 06058E04 add r1,r2
    c.r[2] += 2;  // 06058E06 add #2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06058E08 mov.b @r2,r1
    c.r[4] = c.r[12];  // 06058E0A mov r12,r4
    c.r[1] &= c.r[0];  // 06058E0C and r0,r1
    st8(c.r[2], c.r[1]);  // 06058E0E mov.b r1,@r2
    c.r[1] = ld32(c.r[10]);  // 06058E10 mov.l @r10,r1
    c.r[3] = c.macl;  // 06058E12 sts macl,r3
    c.r[3] += c.r[1];  // 06058E14 add r1,r3
    c.r[2] = c.r[3];  // 06058E16 mov r3,r2
    c.r[2] += 22;  // 06058E18 add #22,r2
    c.r[1] = c.r[14];  // 06058E1A mov r14,r1
    c.r[1] += 26;  // 06058E1C add #26,r1
    c.r[3] += 24;  // 06058E1E add #24,r3
    c.r[10] = (uint32_t)(int16_t)ld16(0x06058EF4u);  // 06058E20 mov.w 0x06058EF4,r10
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06058E22 mov.w @r1,r1
    c.r[10] += c.r[14];  // 06058E24 add r14,r10
    st16(c.r[2], c.r[1]);  // 06058E26 mov.w r1,@r2
    c.r[1] = c.r[14];  // 06058E28 mov r14,r1
    c.r[1] += 28;  // 06058E2A add #28,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06058E2C mov.w @r1,r1
    st16(c.r[3], c.r[1]);  // 06058E2E mov.w r1,@r3
    c.r[1] = ld32(0x06058F08u);  // 06058E30 mov.l 0x06058F08,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06058E36u; c.r[5] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06058E36u) return; }  // 06058E32 jsr @r1 ; mov r10,r5
    c.r[6] = c.r[12];  // 06058E36 mov r12,r6
    c.r[1] = ld32(c.r[8]);  // 06058E38 mov.l @r8,r1
    c.r[0] = ld32(0x06058F00u);  // 06058E3A mov.l 0x06058F00,r0
    c.r[9] += c.r[1];  // 06058E3C add r1,r9
    c.r[9] += 2;  // 06058E3E add #2,r9
    c.r[8] = c.r[10];  // 06058E40 mov r10,r8
    c.r[8] += 16;  // 06058E42 add #16,r8
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06058E44 mov.b @r9,r5
    c.r[4] = c.r[8];  // 06058E46 mov r8,r4
    { const uint32_t x = c.r[0]; c.pr = 0x06058E4Cu; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06058E4Cu) return; }  // 06058E48 jsr @r0 ; extu.b r5,r5
    c.r[2] = 0x0u;  // 06058E4C mov #0,r2
    c.r[6] = (uint32_t)(int16_t)ld16(0x06058EF0u);  // 06058E4E mov.w 0x06058EF0,r6
    c.r[7] = ld32(0x06058F0Cu);  // 06058E50 mov.l 0x06058F0C,r7
L_06058E52:
    c.r[0] = c.r[10];  // 06058E52 mov r10,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06058E54 mov.b @(r0,r2),r1
    c.r[3] = c.r[1] & 0xFFu;  // 06058E56 extu.b r1,r3
    c.t = c.r[3] == c.r[6];  // 06058E58 cmp/eq r6,r3
    { const bool k = c.t; c.r[0] = c.r[12]; if (k) { goto L_06058E72; } }  // 06058E5A bt/s 0x06058E72 ; mov r12,r0
    c.r[1] = ld32(c.r[7]);  // 06058E5E mov.l @r7,r1
    c.r[0] <<= 2;  // 06058E60 shll2 r0
    c.r[0] <<= 2;  // 06058E62 shll2 r0
    c.r[0] += c.r[1];  // 06058E64 add r1,r0
    c.r[1] = c.r[8];  // 06058E66 mov r8,r1
    c.r[1] += 52;  // 06058E68 add #52,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06058E6A mov.w @r1,r1
    c.r[0] += 40;  // 06058E6C add #40,r0
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06058E6E shlr r1
    st8(c.r[0] + c.r[3], c.r[1]);  // 06058E70 mov.b r1,@(r0,r3)
L_06058E72:
    c.r[2] += 1;  // 06058E72 add #1,r2
    c.r[1] = 0xFu;  // 06058E74 mov #15,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 06058E76 cmp/gt r1,r2
    { const bool k = !c.t; c.r[8] += 20; if (k) { SH2_POLL(c); goto L_06058E52; } }  // 06058E78 bf/s 0x06058E52 ; add #20,r8
    c.r[1] = (uint32_t)(int16_t)ld16(0x06058EF0u);  // 06058E7C mov.w 0x06058EF0,r1
    c.t = c.r[13] == c.r[1];  // 06058E7E cmp/eq r1,r13
    { const bool k = c.t; c.r[2] = c.r[13]; if (k) { goto L_06058EC0; } }  // 06058E80 bt/s 0x06058EC0 ; mov r13,r2
    c.r[9] = ld32(0x06058F10u);  // 06058E84 mov.l 0x06058F10,r9
    c.r[8] = (uint32_t)(int16_t)ld16(0x06058EF2u);  // 06058E86 mov.w 0x06058EF2,r8
    c.r[8] += c.r[14];  // 06058E88 add r14,r8
L_06058E8A:
    c.r[2] += c.r[2];  // 06058E8A add r2,r2
    c.r[2] += c.r[13];  // 06058E8C add r13,r2
    c.r[2] <<= 2;  // 06058E8E shll2 r2
    c.r[3] = ld32(c.r[9]);  // 06058E90 mov.l @r9,r3
    c.r[1] = 0x64u;  // 06058E92 mov #100,r1
    c.r[3] += c.r[2];  // 06058E94 add r2,r3
    c.r[3] += 9;  // 06058E96 add #9,r3
    st8(c.r[3], c.r[1]);  // 06058E98 mov.b r1,@r3
    c.r[1] = c.r[8];  // 06058E9A mov r8,r1
    c.r[3] = ld32(c.r[9]);  // 06058E9C mov.l @r9,r3
    c.r[1] += 12;  // 06058E9E add #12,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06058EA0 mov.w @r1,r1
    c.r[3] += c.r[2];  // 06058EA2 add r2,r3
    c.r[2] = c.r[3];  // 06058EA4 mov r3,r2
    c.r[2] += 10;  // 06058EA6 add #10,r2
    st16(c.r[2], c.r[1]);  // 06058EA8 mov.w r1,@r2
    c.r[3] += 8;  // 06058EAA add #8,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06058EAC mov.b @r3,r1
    c.r[4] = c.r[8];  // 06058EAE mov r8,r4
    c.r[13] = c.r[1] & 0xFFu;  // 06058EB0 extu.b r1,r13
    c.r[1] = ld32(0x06058F04u);  // 06058EB2 mov.l 0x06058F04,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06058EB8u; c.r[5] = c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06058EB8u) return; }  // 06058EB4 jsr @r1 ; mov r13,r5
    c.r[1] = (uint32_t)(int16_t)ld16(0x06058EF0u);  // 06058EB8 mov.w 0x06058EF0,r1
    c.t = c.r[13] == c.r[1];  // 06058EBA cmp/eq r1,r13
    { const bool k = !c.t; c.r[2] = c.r[13]; if (k) { SH2_POLL(c); goto L_06058E8A; } }  // 06058EBC bf/s 0x06058E8A ; mov r13,r2
L_06058EC0:
    c.r[1] = ld32(0x06058F14u);  // 06058EC0 mov.l 0x06058F14,r1
    c.r[6] = 0x0u;  // 06058EC2 mov #0,r6
    c.r[5] = 0x0u;  // 06058EC4 mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06058ECAu; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06058ECAu) return; }  // 06058EC6 jsr @r1 ; mov r12,r4
    c.r[3] = (uint32_t)(int16_t)ld16(0x06058EF6u);  // 06058ECA mov.w 0x06058EF6,r3
    c.r[14] += c.r[3];  // 06058ECC add r3,r14
    c.r[15] = c.r[14];  // 06058ECE mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06058ED0 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06058ED2 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06058ED4 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06058ED6 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06058ED8 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06058EDA mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06058EDC mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06058EDE rts ; mov.l @r15+,r8
}

}  // namespace p_srwfin_installed
