#include "p_fin_low_funcs.h"

namespace p_fin_low {

void f_00200000(SH2Context& c) {
    ran[0] = 1;
}

void f_0024B2F0(SH2Context& c) {
    ran[1] = 1;
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0024B2F0 sts.l pr,@-r15
    c.r[0] = ld32(0x0024B538u);  // 0024B2F2 mov.l 0x0024B538,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0024B2F8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0024B2F8u) return; }  // 0024B2F4 jsr @r0 ; nop
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 0024B2F8 mov.l r0,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0024B2FA mov.l r1,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 0024B2FC mov.l r2,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[3]);  // 0024B2FE mov.l r3,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[4]);  // 0024B300 mov.l r4,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[5]);  // 0024B302 mov.l r5,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[6]);  // 0024B304 mov.l r6,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 0024B306 mov.l r7,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0024B308 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0024B30A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0024B30C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0024B30E mov.l r11,@-r15
    c.r[0] = sh2_get_sr(c);  // 0024B310 stc sr,r0
    c.r[15] -= 4; st32(c.r[15], c.r[0]);  // 0024B312 mov.l r0,@-r15
    c.r[9] = ld32(0x0024B54Cu);  // 0024B314 mov.l 0x0024B54C,r9
    c.r[3] = 0x0u;  // 0024B316 mov #0,r3
    c.r[8] = c.r[3];  // 0024B318 mov r3,r8
    c.r[11] = c.r[3];  // 0024B31A mov r3,r11
    c.r[0] = ld32(0x0024B53Cu);  // 0024B31C mov.l 0x0024B53C,r0
    c.r[4] = 0x7Fu;  // 0024B31E mov #127,r4
    c.r[4] += 30;  // 0024B320 add #30,r4
    c.r[5] = 0x7Fu;  // 0024B322 mov #127,r5
    c.r[5] += 78;  // 0024B324 add #78,r5
L_0024B326:
    c.r[1] = c.r[0];  // 0024B326 mov r0,r1
    c.r[2] = ld32(0x0024B550u);  // 0024B328 mov.l 0x0024B550,r2
    c.r[1] += c.r[2];  // 0024B32A add r2,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0024B32C mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0024B32E extu.b r2,r2
    c.r[2] <<= 8;  // 0024B330 shll8 r2
    c.r[1] += 1;  // 0024B332 add #1,r1
    c.r[10] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0024B334 mov.b @r1,r10
    c.r[10] = c.r[10] & 0xFFu;  // 0024B336 extu.b r10,r10
    c.r[2] |= c.r[10];  // 0024B338 or r10,r2
    c.r[2] <<= 8;  // 0024B33A shll8 r2
    c.r[1] += 1;  // 0024B33C add #1,r1
    c.r[10] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0024B33E mov.b @r1,r10
    c.r[10] = c.r[10] & 0xFFu;  // 0024B340 extu.b r10,r10
    c.r[2] |= c.r[10];  // 0024B342 or r10,r2
    c.r[2] <<= 8;  // 0024B344 shll8 r2
    c.r[1] += 1;  // 0024B346 add #1,r1
    c.r[10] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0024B348 mov.b @r1,r10
    c.r[10] = c.r[10] & 0xFFu;  // 0024B34A extu.b r10,r10
    c.r[2] |= c.r[10];  // 0024B34C or r10,r2
    c.r[7] = ld32(0x0024B544u);  // 0024B34E mov.l 0x0024B544,r7
    c.t = c.r[2] == c.r[7];  // 0024B350 cmp/eq r7,r2
    if (c.t) { goto L_0024B388; }  // 0024B352 bt 0x0024B388
    c.r[7] = ld32(0x0024B548u);  // 0024B354 mov.l 0x0024B548,r7
    c.t = c.r[2] == c.r[7];  // 0024B356 cmp/eq r7,r2
    if (!c.t) { goto L_0024B3CA; }  // 0024B358 bf 0x0024B3CA
    c.r[1] = c.r[0];  // 0024B35A mov r0,r1
    c.r[7] = c.r[3];  // 0024B35C mov r3,r7
    c.r[6] = 0xAu;  // 0024B35E mov #10,r6
    { const uint32_t x = c.r[9]; c.pr = 0x0024B364u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0024B364u) return; }  // 0024B360 jsr @r9 ; nop
    c.t = c.r[2] == c.r[3];  // 0024B364 cmp/eq r3,r2
    if (c.t) { goto L_0024B3CA; }  // 0024B366 bt 0x0024B3CA
    c.r[1] += 80;  // 0024B368 add #80,r1
    c.r[1] += 80;  // 0024B36A add #80,r1
    c.r[7] = c.r[3];  // 0024B36C mov r3,r7
    c.r[6] = 0x9u;  // 0024B36E mov #9,r6
    { const uint32_t x = c.r[9]; c.pr = 0x0024B374u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0024B374u) return; }  // 0024B370 jsr @r9 ; nop
    c.t = c.r[2] == c.r[3];  // 0024B374 cmp/eq r3,r2
    if (c.t) { goto L_0024B3CA; }  // 0024B376 bt 0x0024B3CA
    c.t = c.r[11] == c.r[3];  // 0024B378 cmp/eq r3,r11
    if (c.t) { goto L_0024B382; }  // 0024B37A bt 0x0024B382
    c.r[11] = 0xFFFFFFFFu;  // 0024B37C mov #-1,r11
    goto L_0024B3CA;  // 0024B37E bra 0x0024B3CA ; nop
L_0024B382:
    c.r[11] = c.r[0];  // 0024B382 mov r0,r11
    goto L_0024B3CA;  // 0024B384 bra 0x0024B3CA ; nop
L_0024B388:
    c.r[1] = c.r[0];  // 0024B388 mov r0,r1
    c.r[7] = c.r[3];  // 0024B38A mov r3,r7
    c.r[6] = 0x6u;  // 0024B38C mov #6,r6
    { const uint32_t x = c.r[9]; c.pr = 0x0024B392u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0024B392u) return; }  // 0024B38E jsr @r9 ; nop
    c.t = c.r[2] == c.r[3];  // 0024B392 cmp/eq r3,r2
    if (c.t) { goto L_0024B3CA; }  // 0024B394 bt 0x0024B3CA
    c.r[7] = ld32(0x0024B540u);  // 0024B396 mov.l 0x0024B540,r7
    c.r[6] = 0x4u;  // 0024B398 mov #4,r6
    { const uint32_t x = c.r[9]; c.pr = 0x0024B39Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0024B39Eu) return; }  // 0024B39A jsr @r9 ; nop
    c.t = c.r[2] == c.r[3];  // 0024B39E cmp/eq r3,r2
    if (c.t) { goto L_0024B3CA; }  // 0024B3A0 bt 0x0024B3CA
    c.r[1] += 80;  // 0024B3A2 add #80,r1
    c.r[1] += 80;  // 0024B3A4 add #80,r1
    c.r[7] = ld32(0x0024B540u);  // 0024B3A6 mov.l 0x0024B540,r7
    c.r[6] = 0x4u;  // 0024B3A8 mov #4,r6
    { const uint32_t x = c.r[9]; c.pr = 0x0024B3AEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0024B3AEu) return; }  // 0024B3AA jsr @r9 ; nop
    c.t = c.r[2] == c.r[3];  // 0024B3AE cmp/eq r3,r2
    if (c.t) { goto L_0024B3CA; }  // 0024B3B0 bt 0x0024B3CA
    c.r[7] = c.r[3];  // 0024B3B2 mov r3,r7
    c.r[6] = 0x5u;  // 0024B3B4 mov #5,r6
    { const uint32_t x = c.r[9]; c.pr = 0x0024B3BAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0024B3BAu) return; }  // 0024B3B6 jsr @r9 ; nop
    c.t = c.r[2] == c.r[3];  // 0024B3BA cmp/eq r3,r2
    if (c.t) { goto L_0024B3CA; }  // 0024B3BC bt 0x0024B3CA
    c.t = c.r[8] == c.r[3];  // 0024B3BE cmp/eq r3,r8
    if (c.t) { goto L_0024B3C8; }  // 0024B3C0 bt 0x0024B3C8
    c.r[8] = 0xFFFFFFFFu;  // 0024B3C2 mov #-1,r8
    goto L_0024B3CA;  // 0024B3C4 bra 0x0024B3CA ; nop
L_0024B3C8:
    c.r[8] = c.r[0];  // 0024B3C8 mov r0,r8
L_0024B3CA:
    c.r[0] += 1;  // 0024B3CA add #1,r0
    c.r[4] -= 1; c.t = c.r[4] == 0;  // 0024B3CC dt r4
    if (!c.t) { SH2_POLL(c); goto L_0024B326; }  // 0024B3CE bf 0x0024B326
    c.r[4] = 0x7Fu;  // 0024B3D0 mov #127,r4
    c.r[4] += 30;  // 0024B3D2 add #30,r4
    c.r[5] -= 1; c.t = c.r[5] == 0;  // 0024B3D4 dt r5
    c.r[0] += 3;  // 0024B3D6 add #3,r0
    if (!c.t) { SH2_POLL(c); goto L_0024B326; }  // 0024B3D8 bf 0x0024B326
    c.t = c.r[8] == c.r[3];  // 0024B3DA cmp/eq r3,r8
    if (c.t) { goto L_0024B45A; }  // 0024B3DC bt 0x0024B45A
    c.r[1] = 0xFFFFFFFFu;  // 0024B3DE mov #-1,r1
    c.t = c.r[8] == c.r[1];  // 0024B3E0 cmp/eq r1,r8
    if (c.t) { goto L_0024B45A; }  // 0024B3E2 bt 0x0024B45A
    c.r[0] = ld32(0x0024B560u);  // 0024B3E4 mov.l 0x0024B560,r0
    c.r[1] = ld32(0x0024B56Cu);  // 0024B3E6 mov.l 0x0024B56C,r1
    c.r[2] = c.r[1] << 16 | c.r[1] >> 16;  // 0024B3E8 swap.w r1,r2
    st16(c.r[0], c.r[2]);  // 0024B3EA mov.w r2,@r0
    c.r[0] += 2;  // 0024B3EC add #2,r0
    st16(c.r[0], c.r[1]);  // 0024B3EE mov.w r1,@r0
    c.r[0] += 2;  // 0024B3F0 add #2,r0
    c.r[1] = ld32(0x0024B570u);  // 0024B3F2 mov.l 0x0024B570,r1
    c.r[2] = c.r[1] << 16 | c.r[1] >> 16;  // 0024B3F4 swap.w r1,r2
    st16(c.r[0], c.r[2]);  // 0024B3F6 mov.w r2,@r0
    c.r[0] += 2;  // 0024B3F8 add #2,r0
    st16(c.r[0], c.r[1]);  // 0024B3FA mov.w r1,@r0
    c.r[0] += 2;  // 0024B3FC add #2,r0
    c.r[1] = ld32(0x0024B574u);  // 0024B3FE mov.l 0x0024B574,r1
    c.r[2] = c.r[1] << 16 | c.r[1] >> 16;  // 0024B400 swap.w r1,r2
    st16(c.r[0], c.r[2]);  // 0024B402 mov.w r2,@r0
    c.r[0] += 2;  // 0024B404 add #2,r0
    st16(c.r[0], c.r[1]);  // 0024B406 mov.w r1,@r0
    c.r[0] = c.r[8];  // 0024B408 mov r8,r0
    c.r[7] = ld32(0x0024B55Cu);  // 0024B40A mov.l 0x0024B55C,r7
    c.r[6] = 0x2u;  // 0024B40C mov #2,r6
L_0024B40E:
    c.r[1] = c.r[0];  // 0024B40E mov r0,r1
    c.r[2] = ld32(0x0024B554u);  // 0024B410 mov.l 0x0024B554,r2
    c.r[1] += c.r[2];  // 0024B412 add r2,r1
    c.r[4] = 0x10u;  // 0024B414 mov #16,r4
L_0024B416:
    c.r[2] = 0xCu;  // 0024B416 mov #12,r2
L_0024B418:
    st8(c.r[1], c.r[3]);  // 0024B418 mov.b r3,@r1
    c.r[1] += 1;  // 0024B41A add #1,r1
    c.r[2] -= 1; c.t = c.r[2] == 0;  // 0024B41C dt r2
    if (!c.t) { SH2_POLL(c); goto L_0024B418; }  // 0024B41E bf 0x0024B418
    c.r[1] += 127;  // 0024B420 add #127,r1
    c.r[1] += 21;  // 0024B422 add #21,r1
    c.r[4] -= 1; c.t = c.r[4] == 0;  // 0024B424 dt r4
    if (!c.t) { SH2_POLL(c); goto L_0024B416; }  // 0024B426 bf 0x0024B416
    c.r[1] = c.r[0];  // 0024B428 mov r0,r1
    c.r[1] += 4;  // 0024B42A add #4,r1
    c.r[2] = ld32(0x0024B558u);  // 0024B42C mov.l 0x0024B558,r2
    c.r[1] += c.r[2];  // 0024B42E add r2,r1
    c.r[5] = ld32(0x0024B564u);  // 0024B430 mov.l 0x0024B564,r5
    c.r[4] = 0x9u;  // 0024B432 mov #9,r4
L_0024B434:
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[5]); c.r[5] += 1;  // 0024B434 mov.b @r5+,r2
    st8(c.r[1], c.r[2]);  // 0024B436 mov.b r2,@r1
    c.r[1] += 1;  // 0024B438 add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[5]); c.r[5] += 1;  // 0024B43A mov.b @r5+,r2
    st8(c.r[1], c.r[2]);  // 0024B43C mov.b r2,@r1
    c.r[1] += 1;  // 0024B43E add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[5]); c.r[5] += 1;  // 0024B440 mov.b @r5+,r2
    st8(c.r[1], c.r[2]);  // 0024B442 mov.b r2,@r1
    c.r[1] += 1;  // 0024B444 add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[5]); c.r[5] += 1;  // 0024B446 mov.b @r5+,r2
    st8(c.r[1], c.r[2]);  // 0024B448 mov.b r2,@r1
    c.r[1] += 1;  // 0024B44A add #1,r1
    c.r[1] += 127;  // 0024B44C add #127,r1
    c.r[1] += 29;  // 0024B44E add #29,r1
    c.r[4] -= 1; c.t = c.r[4] == 0;  // 0024B450 dt r4
    if (!c.t) { SH2_POLL(c); goto L_0024B434; }  // 0024B452 bf 0x0024B434
    c.r[0] += c.r[7];  // 0024B454 add r7,r0
    c.r[6] -= 1; c.t = c.r[6] == 0;  // 0024B456 dt r6
    if (!c.t) { SH2_POLL(c); goto L_0024B40E; }  // 0024B458 bf 0x0024B40E
L_0024B45A:
    c.t = c.r[11] == c.r[3];  // 0024B45A cmp/eq r3,r11
    if (c.t) { goto L_0024B4DA; }  // 0024B45C bt 0x0024B4DA
    c.r[1] = 0xFFFFFFFFu;  // 0024B45E mov #-1,r1
    c.t = c.r[11] == c.r[1];  // 0024B460 cmp/eq r1,r11
    if (c.t) { goto L_0024B4DA; }  // 0024B462 bt 0x0024B4DA
    c.r[0] = ld32(0x0024B560u);  // 0024B464 mov.l 0x0024B560,r0
    c.r[1] = ld32(0x0024B56Cu);  // 0024B466 mov.l 0x0024B56C,r1
    c.r[2] = c.r[1] << 16 | c.r[1] >> 16;  // 0024B468 swap.w r1,r2
    st16(c.r[0], c.r[2]);  // 0024B46A mov.w r2,@r0
    c.r[0] += 2;  // 0024B46C add #2,r0
    st16(c.r[0], c.r[1]);  // 0024B46E mov.w r1,@r0
    c.r[0] += 2;  // 0024B470 add #2,r0
    c.r[1] = ld32(0x0024B570u);  // 0024B472 mov.l 0x0024B570,r1
    c.r[2] = c.r[1] << 16 | c.r[1] >> 16;  // 0024B474 swap.w r1,r2
    st16(c.r[0], c.r[2]);  // 0024B476 mov.w r2,@r0
    c.r[0] += 2;  // 0024B478 add #2,r0
    st16(c.r[0], c.r[1]);  // 0024B47A mov.w r1,@r0
    c.r[0] += 2;  // 0024B47C add #2,r0
    c.r[1] = ld32(0x0024B574u);  // 0024B47E mov.l 0x0024B574,r1
    c.r[2] = c.r[1] << 16 | c.r[1] >> 16;  // 0024B480 swap.w r1,r2
    st16(c.r[0], c.r[2]);  // 0024B482 mov.w r2,@r0
    c.r[0] += 2;  // 0024B484 add #2,r0
    st16(c.r[0], c.r[1]);  // 0024B486 mov.w r1,@r0
    c.r[0] = c.r[11];  // 0024B488 mov r11,r0
    c.r[7] = ld32(0x0024B55Cu);  // 0024B48A mov.l 0x0024B55C,r7
    c.r[6] = 0x2u;  // 0024B48C mov #2,r6
L_0024B48E:
    c.r[1] = c.r[0];  // 0024B48E mov r0,r1
    c.r[2] = ld32(0x0024B554u);  // 0024B490 mov.l 0x0024B554,r2
    c.r[1] += c.r[2];  // 0024B492 add r2,r1
    c.r[4] = 0x10u;  // 0024B494 mov #16,r4
L_0024B496:
    c.r[2] = 0xCu;  // 0024B496 mov #12,r2
L_0024B498:
    st8(c.r[1], c.r[3]);  // 0024B498 mov.b r3,@r1
    c.r[1] += 1;  // 0024B49A add #1,r1
    c.r[2] -= 1; c.t = c.r[2] == 0;  // 0024B49C dt r2
    if (!c.t) { SH2_POLL(c); goto L_0024B498; }  // 0024B49E bf 0x0024B498
    c.r[1] += 127;  // 0024B4A0 add #127,r1
    c.r[1] += 21;  // 0024B4A2 add #21,r1
    c.r[4] -= 1; c.t = c.r[4] == 0;  // 0024B4A4 dt r4
    if (!c.t) { SH2_POLL(c); goto L_0024B496; }  // 0024B4A6 bf 0x0024B496
    c.r[1] = c.r[0];  // 0024B4A8 mov r0,r1
    c.r[1] += 4;  // 0024B4AA add #4,r1
    c.r[2] = ld32(0x0024B558u);  // 0024B4AC mov.l 0x0024B558,r2
    c.r[1] += c.r[2];  // 0024B4AE add r2,r1
    c.r[5] = ld32(0x0024B568u);  // 0024B4B0 mov.l 0x0024B568,r5
    c.r[4] = 0x9u;  // 0024B4B2 mov #9,r4
L_0024B4B4:
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[5]); c.r[5] += 1;  // 0024B4B4 mov.b @r5+,r2
    st8(c.r[1], c.r[2]);  // 0024B4B6 mov.b r2,@r1
    c.r[1] += 1;  // 0024B4B8 add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[5]); c.r[5] += 1;  // 0024B4BA mov.b @r5+,r2
    st8(c.r[1], c.r[2]);  // 0024B4BC mov.b r2,@r1
    c.r[1] += 1;  // 0024B4BE add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[5]); c.r[5] += 1;  // 0024B4C0 mov.b @r5+,r2
    st8(c.r[1], c.r[2]);  // 0024B4C2 mov.b r2,@r1
    c.r[1] += 1;  // 0024B4C4 add #1,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[5]); c.r[5] += 1;  // 0024B4C6 mov.b @r5+,r2
    st8(c.r[1], c.r[2]);  // 0024B4C8 mov.b r2,@r1
    c.r[1] += 1;  // 0024B4CA add #1,r1
    c.r[1] += 127;  // 0024B4CC add #127,r1
    c.r[1] += 29;  // 0024B4CE add #29,r1
    c.r[4] -= 1; c.t = c.r[4] == 0;  // 0024B4D0 dt r4
    if (!c.t) { SH2_POLL(c); goto L_0024B4B4; }  // 0024B4D2 bf 0x0024B4B4
    c.r[0] += c.r[7];  // 0024B4D4 add r7,r0
    c.r[6] -= 1; c.t = c.r[6] == 0;  // 0024B4D6 dt r6
    if (!c.t) { SH2_POLL(c); goto L_0024B48E; }  // 0024B4D8 bf 0x0024B48E
L_0024B4DA:
    c.r[0] = ld32(c.r[15]); c.r[15] += 4;  // 0024B4DA mov.l @r15+,r0
    sh2_set_sr(c, c.r[0] & 0x3F3u); SH2_POLL(c);  // 0024B4DC ldc r0,sr
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0024B4DE mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0024B4E0 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0024B4E2 mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0024B4E4 mov.l @r15+,r8
    c.r[7] = ld32(c.r[15]); c.r[15] += 4;  // 0024B4E6 mov.l @r15+,r7
    c.r[6] = ld32(c.r[15]); c.r[15] += 4;  // 0024B4E8 mov.l @r15+,r6
    c.r[5] = ld32(c.r[15]); c.r[15] += 4;  // 0024B4EA mov.l @r15+,r5
    c.r[4] = ld32(c.r[15]); c.r[15] += 4;  // 0024B4EC mov.l @r15+,r4
    c.r[3] = ld32(c.r[15]); c.r[15] += 4;  // 0024B4EE mov.l @r15+,r3
    c.r[2] = ld32(c.r[15]); c.r[15] += 4;  // 0024B4F0 mov.l @r15+,r2
    c.r[1] = ld32(c.r[15]); c.r[15] += 4;  // 0024B4F2 mov.l @r15+,r1
    c.r[0] = ld32(c.r[15]); c.r[15] += 4;  // 0024B4F4 mov.l @r15+,r0
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0024B4F6 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0024B4F8 rts ; nop
}

void f_0024B4FC(SH2Context& c) {
    ran[2] = 1;
L_0024B4FC:
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0024B4FC mov.b @r1,r2
    c.r[2] = c.r[2] & 0xFFu;  // 0024B4FE extu.b r2,r2
    c.r[2] <<= 8;  // 0024B500 shll8 r2
    c.r[1] += 1;  // 0024B502 add #1,r1
    c.r[10] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0024B504 mov.b @r1,r10
    c.r[10] = c.r[10] & 0xFFu;  // 0024B506 extu.b r10,r10
    c.r[2] |= c.r[10];  // 0024B508 or r10,r2
    c.r[2] <<= 8;  // 0024B50A shll8 r2
    c.r[1] += 1;  // 0024B50C add #1,r1
    c.r[10] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0024B50E mov.b @r1,r10
    c.r[10] = c.r[10] & 0xFFu;  // 0024B510 extu.b r10,r10
    c.r[2] |= c.r[10];  // 0024B512 or r10,r2
    c.r[2] <<= 8;  // 0024B514 shll8 r2
    c.r[1] += 1;  // 0024B516 add #1,r1
    c.r[10] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0024B518 mov.b @r1,r10
    c.r[10] = c.r[10] & 0xFFu;  // 0024B51A extu.b r10,r10
    c.r[2] |= c.r[10];  // 0024B51C or r10,r2
    c.t = c.r[2] == c.r[7];  // 0024B51E cmp/eq r7,r2
    if (!c.t) { goto L_0024B530; }  // 0024B520 bf 0x0024B530
    c.r[1] += 127;  // 0024B522 add #127,r1
    c.r[1] += 30;  // 0024B524 add #30,r1
    c.r[6] -= 1; c.t = c.r[6] == 0;  // 0024B526 dt r6
    if (!c.t) { SH2_POLL(c); goto L_0024B4FC; }  // 0024B528 bf 0x0024B4FC
    c.r[2] = 0x1u;  // 0024B52A mov #1,r2
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0024B52C rts ; nop
L_0024B530:
    c.r[2] = 0x0u;  // 0024B530 mov #0,r2
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0024B532 rts ; nop
}

void f_00288AC8(SH2Context& c) {
    ran[3] = 1;
L_00288AC8:
    c.r[0] = c.r[9];  // 00288AC8 mov r9,r0
L_00288ACA:
    c.t = c.r[0] == 0x4u;  // 00288ACA cmp/eq #4,r0
L_00288ACC:
    if (!c.t) { goto L_00288AF6; }  // 00288ACC bf 0x00288AF6
L_00288ACE:
    c.r[0] = c.r[5];  // 00288ACE mov r5,r0
L_00288AD0:
    c.t = c.r[0] == 0x1u;  // 00288AD0 cmp/eq #1,r0
L_00288AD2:
    if (!c.t) { goto L_00288AF6; }  // 00288AD2 bf 0x00288AF6
L_00288AD4:
    c.r[0] = c.r[10];  // 00288AD4 mov r10,r0
L_00288AD6:
    c.r[0] = c.r[0] & 0xFFu;  // 00288AD6 extu.b r0,r0
L_00288AD8:
    c.t = c.r[0] == c.r[10];  // 00288AD8 cmp/eq r10,r0
L_00288ADA:
    if (!c.t) { goto L_00288AF6; }  // 00288ADA bf 0x00288AF6
L_00288ADC:
    c.r[0] = (uint32_t)(int32_t)(int8_t)c.r[0];  // 00288ADC exts.b r0,r0
L_00288ADE:
    c.t = c.r[0] == 0x3Du;  // 00288ADE cmp/eq #61,r0
L_00288AE0:
    if (c.t) { goto L_00288AFC; }  // 00288AE0 bt 0x00288AFC
L_00288AE2:
    c.t = c.r[0] == 0x3Eu;  // 00288AE2 cmp/eq #62,r0
L_00288AE4:
    if (c.t) { goto L_00288AFC; }  // 00288AE4 bt 0x00288AFC
L_00288AE6:
    c.t = c.r[0] == 0xFFFFFFC8u;  // 00288AE6 cmp/eq #-56,r0
L_00288AE8:
    if (c.t) { goto L_00288B04; }  // 00288AE8 bt 0x00288B04
L_00288AEA:
    c.t = c.r[0] == 0xFFFFFFC9u;  // 00288AEA cmp/eq #-55,r0
L_00288AEC:
    if (c.t) { goto L_00288B04; }  // 00288AEC bt 0x00288B04
L_00288AEE:
    c.t = c.r[0] == 0xFFFFFFCFu;  // 00288AEE cmp/eq #-49,r0
L_00288AF0:
    if (c.t) { goto L_00288B0C; }  // 00288AF0 bt 0x00288B0C
L_00288AF2:
    c.t = c.r[0] == 0xFFFFFFD0u;  // 00288AF2 cmp/eq #-48,r0
L_00288AF4:
    if (c.t) { goto L_00288B0C; }  // 00288AF4 bt 0x00288B0C
L_00288AF6:
    c.r[0] = ld32(0x00288B20u);  // 00288AF6 mov.l 0x00288B20,r0
L_00288AF8:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x00288AC8u: goto L_00288AC8; case 0x00288ACAu: goto L_00288ACA; case 0x00288ACCu: goto L_00288ACC; case 0x00288ACEu: goto L_00288ACE; case 0x00288AD0u: goto L_00288AD0; case 0x00288AD2u: goto L_00288AD2; case 0x00288AD4u: goto L_00288AD4; case 0x00288AD6u: goto L_00288AD6; case 0x00288AD8u: goto L_00288AD8; case 0x00288ADAu: goto L_00288ADA; case 0x00288ADCu: goto L_00288ADC; case 0x00288ADEu: goto L_00288ADE; case 0x00288AE0u: goto L_00288AE0; case 0x00288AE2u: goto L_00288AE2; case 0x00288AE4u: goto L_00288AE4; case 0x00288AE6u: goto L_00288AE6; case 0x00288AE8u: goto L_00288AE8; case 0x00288AEAu: goto L_00288AEA; case 0x00288AECu: goto L_00288AEC; case 0x00288AEEu: goto L_00288AEE; case 0x00288AF0u: goto L_00288AF0; case 0x00288AF2u: goto L_00288AF2; case 0x00288AF4u: goto L_00288AF4; case 0x00288AF6u: goto L_00288AF6; case 0x00288AF8u: goto L_00288AF8; case 0x00288AFCu: goto L_00288AFC; case 0x00288AFEu: goto L_00288AFE; case 0x00288B04u: goto L_00288B04; case 0x00288B06u: goto L_00288B06; case 0x00288B0Cu: goto L_00288B0C; case 0x00288B0Eu: goto L_00288B0E; default: sh2_call(c, x); return; } }  // 00288AF8 jmp @r0 ; nop
L_00288AFC:
    c.r[0] = ld32(0x00288B14u);  // 00288AFC mov.l 0x00288B14,r0
L_00288AFE:
    { const uint32_t x = c.pr; c.pc = x; return; }  // 00288AFE rts ; nop
L_00288B04:
    c.r[0] = ld32(0x00288B18u);  // 00288B04 mov.l 0x00288B18,r0
L_00288B06:
    { const uint32_t x = c.pr; c.pc = x; return; }  // 00288B06 rts ; nop
L_00288B0C:
    c.r[0] = ld32(0x00288B1Cu);  // 00288B0C mov.l 0x00288B1C,r0
L_00288B0E:
    { const uint32_t x = c.pr; c.pc = x; return; }  // 00288B0E rts ; nop
}

void f_00288B74(SH2Context& c) {
    ran[4] = 1;
L_00288B74:
    c.t = (int32_t)c.r[7] >= 0;  // 00288B74 cmp/pz r7
L_00288B76:
    if (!c.t) { goto L_00288B92; }  // 00288B76 bf 0x00288B92
L_00288B78:
    c.r[5] = ld32(0x00288B98u);  // 00288B78 mov.l 0x00288B98,r5
L_00288B7A:
    c.r[5] = ld32(c.r[5]);  // 00288B7A mov.l @r5,r5
L_00288B7C:
    c.r[1] <<= 2;  // 00288B7C shll2 r1
L_00288B7E:
    c.r[1] += 28;  // 00288B7E add #28,r1
L_00288B80:
    c.r[5] += c.r[1];  // 00288B80 add r1,r5
L_00288B82:
    c.r[5] += c.r[2];  // 00288B82 add r2,r5
L_00288B84:
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 00288B84 sts.l pr,@-r15
L_00288B86:
    c.r[0] = ld32(0x00288B9Cu);  // 00288B86 mov.l 0x00288B9C,r0
L_00288B88:
    { const uint32_t x = c.r[0]; c.pr = 0x00288B8Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x00288B8Cu) return; }  // 00288B88 jsr @r0 ; nop
L_00288B8C:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 00288B8C lds.l @r15+,pr
L_00288B8E:
    { const uint32_t x = c.pr; c.r[0] = c.r[3]; c.pc = x; return; }  // 00288B8E rts ; mov r3,r0
L_00288B92:
    c.r[0] = ld32(0x00288BA0u);  // 00288B92 mov.l 0x00288BA0,r0
L_00288B94:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x00288B74u: goto L_00288B74; case 0x00288B76u: goto L_00288B76; case 0x00288B78u: goto L_00288B78; case 0x00288B7Au: goto L_00288B7A; case 0x00288B7Cu: goto L_00288B7C; case 0x00288B7Eu: goto L_00288B7E; case 0x00288B80u: goto L_00288B80; case 0x00288B82u: goto L_00288B82; case 0x00288B84u: goto L_00288B84; case 0x00288B86u: goto L_00288B86; case 0x00288B88u: goto L_00288B88; case 0x00288B8Cu: goto L_00288B8C; case 0x00288B8Eu: goto L_00288B8E; case 0x00288B92u: goto L_00288B92; case 0x00288B94u: goto L_00288B94; default: sh2_call(c, x); return; } }  // 00288B94 jmp @r0 ; nop
}

void f_00288BA4(SH2Context& c) {
    ran[5] = 1;
L_00288BA4:
    c.r[3] = ld32(0x00288BB8u);  // 00288BA4 mov.l 0x00288BB8,r3
L_00288BA6:
    c.t = c.r[2] == c.r[3];  // 00288BA6 cmp/eq r3,r2
L_00288BA8:
    if (!c.t) { goto L_00288BB0; }  // 00288BA8 bf 0x00288BB0
L_00288BAA:
    c.r[3] = ld32(0x00288BBCu);  // 00288BAA mov.l 0x00288BBC,r3
L_00288BAC:
    c.r[1] = 0x0u;  // 00288BAC mov #0,r1
L_00288BAE:
    st8(c.r[3], c.r[1]);  // 00288BAE mov.b r1,@r3
L_00288BB0:
    c.r[3] = ld32(0x00288BC0u);  // 00288BB0 mov.l 0x00288BC0,r3
L_00288BB2:
    { const uint32_t x = c.r[3]; SH2_POLL(c); switch (x) { case 0x00288BA4u: goto L_00288BA4; case 0x00288BA6u: goto L_00288BA6; case 0x00288BA8u: goto L_00288BA8; case 0x00288BAAu: goto L_00288BAA; case 0x00288BACu: goto L_00288BAC; case 0x00288BAEu: goto L_00288BAE; case 0x00288BB0u: goto L_00288BB0; case 0x00288BB2u: goto L_00288BB2; default: sh2_call(c, x); return; } }  // 00288BB2 jmp @r3 ; nop
}

void f_00288BD0(SH2Context& c) {
    ran[6] = 1;
L_00288BD0:
    c.r[0] = c.r[9];  // 00288BD0 mov r9,r0
L_00288BD2:
    c.t = c.r[0] == 0x5u;  // 00288BD2 cmp/eq #5,r0
L_00288BD4:
    if (!c.t) { goto L_00288BE8; }  // 00288BD4 bf 0x00288BE8
L_00288BD6:
    c.r[0] = c.r[5];  // 00288BD6 mov r5,r0
L_00288BD8:
    c.t = c.r[0] == 0x2u;  // 00288BD8 cmp/eq #2,r0
L_00288BDA:
    if (!c.t) { goto L_00288BE8; }  // 00288BDA bf 0x00288BE8
L_00288BDC:
    c.r[0] = c.r[10];  // 00288BDC mov r10,r0
L_00288BDE:
    c.t = c.r[0] == 0x65u;  // 00288BDE cmp/eq #101,r0
L_00288BE0:
    if (!c.t) { goto L_00288BE8; }  // 00288BE0 bf 0x00288BE8
L_00288BE2:
    c.r[0] = ld32(0x00288BF0u);  // 00288BE2 mov.l 0x00288BF0,r0
L_00288BE4:
    { const uint32_t x = c.pr; c.pc = x; return; }  // 00288BE4 rts ; nop
L_00288BE8:
    c.r[0] = ld32(0x00288BF4u);  // 00288BE8 mov.l 0x00288BF4,r0
L_00288BEA:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x00288BD0u: goto L_00288BD0; case 0x00288BD2u: goto L_00288BD2; case 0x00288BD4u: goto L_00288BD4; case 0x00288BD6u: goto L_00288BD6; case 0x00288BD8u: goto L_00288BD8; case 0x00288BDAu: goto L_00288BDA; case 0x00288BDCu: goto L_00288BDC; case 0x00288BDEu: goto L_00288BDE; case 0x00288BE0u: goto L_00288BE0; case 0x00288BE2u: goto L_00288BE2; case 0x00288BE4u: goto L_00288BE4; case 0x00288BE8u: goto L_00288BE8; case 0x00288BEAu: goto L_00288BEA; default: sh2_call(c, x); return; } }  // 00288BEA jmp @r0 ; nop
}

void f_00288CB0(SH2Context& c) {
    ran[7] = 1;
L_00288CB0:
    c.r[0] = c.r[9];  // 00288CB0 mov r9,r0
L_00288CB2:
    c.t = c.r[0] == 0x5u;  // 00288CB2 cmp/eq #5,r0
L_00288CB4:
    if (!c.t) { goto L_00288CCE; }  // 00288CB4 bf 0x00288CCE
L_00288CB6:
    c.r[0] = c.r[5];  // 00288CB6 mov r5,r0
L_00288CB8:
    c.t = c.r[0] == 0x2u;  // 00288CB8 cmp/eq #2,r0
L_00288CBA:
    if (!c.t) { goto L_00288CCE; }  // 00288CBA bf 0x00288CCE
L_00288CBC:
    c.r[0] = ld32(0x00288CD4u);  // 00288CBC mov.l 0x00288CD4,r0
L_00288CBE:
    c.t = c.r[0] == c.r[10];  // 00288CBE cmp/eq r10,r0
L_00288CC0:
    if (c.t) { goto L_00288CC8; }  // 00288CC0 bt 0x00288CC8
L_00288CC2:
    c.r[0] = ld32(0x00288CD8u);  // 00288CC2 mov.l 0x00288CD8,r0
L_00288CC4:
    c.t = c.r[0] == c.r[10];  // 00288CC4 cmp/eq r10,r0
L_00288CC6:
    if (!c.t) { goto L_00288CCE; }  // 00288CC6 bf 0x00288CCE
L_00288CC8:
    c.r[0] = ld32(0x00288CDCu);  // 00288CC8 mov.l 0x00288CDC,r0
L_00288CCA:
    { const uint32_t x = c.pr; c.pc = x; return; }  // 00288CCA rts ; nop
L_00288CCE:
    c.r[0] = ld32(0x00288CE0u);  // 00288CCE mov.l 0x00288CE0,r0
L_00288CD0:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x00288CB0u: goto L_00288CB0; case 0x00288CB2u: goto L_00288CB2; case 0x00288CB4u: goto L_00288CB4; case 0x00288CB6u: goto L_00288CB6; case 0x00288CB8u: goto L_00288CB8; case 0x00288CBAu: goto L_00288CBA; case 0x00288CBCu: goto L_00288CBC; case 0x00288CBEu: goto L_00288CBE; case 0x00288CC0u: goto L_00288CC0; case 0x00288CC2u: goto L_00288CC2; case 0x00288CC4u: goto L_00288CC4; case 0x00288CC6u: goto L_00288CC6; case 0x00288CC8u: goto L_00288CC8; case 0x00288CCAu: goto L_00288CCA; case 0x00288CCEu: goto L_00288CCE; case 0x00288CD0u: goto L_00288CD0; default: sh2_call(c, x); return; } }  // 00288CD0 jmp @r0 ; nop
}

void f_00288D04(SH2Context& c) {
    ran[8] = 1;
L_00288D04:
    c.r[3] = c.r[5];  // 00288D04 mov r5,r3
L_00288D06:
    c.r[0] = ld32(0x00288D40u);  // 00288D06 mov.l 0x00288D40,r0
L_00288D08:
    c.t = c.r[0] == c.r[4];  // 00288D08 cmp/eq r4,r0
L_00288D0A:
    if (!c.t) { goto L_00288D18; }  // 00288D0A bf 0x00288D18
L_00288D0C:
    c.r[0] = 0xDu;  // 00288D0C mov #13,r0
L_00288D0E:
    c.t = c.r[0] == c.r[5];  // 00288D0E cmp/eq r5,r0
L_00288D10:
    if (!c.t) { goto L_00288D38; }  // 00288D10 bf 0x00288D38
L_00288D12:
    c.r[5] = 0xCu;  // 00288D12 mov #12,r5
L_00288D14:
    goto L_00288D38;  // 00288D14 bra 0x00288D38 ; nop
L_00288D18:
    c.r[0] = ld32(0x00288D44u);  // 00288D18 mov.l 0x00288D44,r0
L_00288D1A:
    c.t = c.r[0] == c.r[4];  // 00288D1A cmp/eq r4,r0
L_00288D1C:
    if (!c.t) { goto L_00288D38; }  // 00288D1C bf 0x00288D38
L_00288D1E:
    c.r[1] = 0x4Cu;  // 00288D1E mov #76,r1
L_00288D20:
    c.r[1] <<= 2;  // 00288D20 shll2 r1
L_00288D22:
    c.r[3] -= c.r[1];  // 00288D22 sub r1,r3
L_00288D24:
    c.r[0] = 0xFu;  // 00288D24 mov #15,r0
L_00288D26:
    c.t = c.r[3] > c.r[0];  // 00288D26 cmp/hi r0,r3
L_00288D28:
    if (c.t) { goto L_00288D38; }  // 00288D28 bt 0x00288D38
L_00288D2A:
    c.t = c.r[3] & 1; c.r[3] >>= 1;  // 00288D2A shlr r3
L_00288D2C:
    c.r[3] <<= 8;  // 00288D2C shll8 r3
L_00288D2E:
    c.r[3] >>= 2;  // 00288D2E shlr2 r3
L_00288D30:
    c.r[0] = ld32(0x00288D48u);  // 00288D30 mov.l 0x00288D48,r0
L_00288D32:
    c.r[0] += c.r[3];  // 00288D32 add r3,r0
L_00288D34:
    { const uint32_t x = c.pr; c.pc = x; return; }  // 00288D34 rts ; nop
L_00288D38:
    c.r[0] = ld32(0x00288D4Cu);  // 00288D38 mov.l 0x00288D4C,r0
L_00288D3A:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x00288D04u: goto L_00288D04; case 0x00288D06u: goto L_00288D06; case 0x00288D08u: goto L_00288D08; case 0x00288D0Au: goto L_00288D0A; case 0x00288D0Cu: goto L_00288D0C; case 0x00288D0Eu: goto L_00288D0E; case 0x00288D10u: goto L_00288D10; case 0x00288D12u: goto L_00288D12; case 0x00288D14u: goto L_00288D14; case 0x00288D18u: goto L_00288D18; case 0x00288D1Au: goto L_00288D1A; case 0x00288D1Cu: goto L_00288D1C; case 0x00288D1Eu: goto L_00288D1E; case 0x00288D20u: goto L_00288D20; case 0x00288D22u: goto L_00288D22; case 0x00288D24u: goto L_00288D24; case 0x00288D26u: goto L_00288D26; case 0x00288D28u: goto L_00288D28; case 0x00288D2Au: goto L_00288D2A; case 0x00288D2Cu: goto L_00288D2C; case 0x00288D2Eu: goto L_00288D2E; case 0x00288D30u: goto L_00288D30; case 0x00288D32u: goto L_00288D32; case 0x00288D34u: goto L_00288D34; case 0x00288D38u: goto L_00288D38; case 0x00288D3Au: goto L_00288D3A; default: sh2_call(c, x); return; } }  // 00288D3A jmp @r0 ; nop
}

void f_00288FB2(SH2Context& c) {
    ran[9] = 1;
L_00288FB2:
    c.t = (c.r[6] & c.r[6]) == 0;  // 00288FB2 tst r6,r6
L_00288FB4:
    if (c.t) { goto L_0028900E; }  // 00288FB4 bt 0x0028900E
L_00288FB6:
    c.r[3] = c.r[5];  // 00288FB6 mov r5,r3
L_00288FB8:
    c.r[1] = c.r[5];  // 00288FB8 mov r5,r1
L_00288FBA:
    c.r[1] -= 16;  // 00288FBA add #-16,r1
L_00288FBC:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 00288FBC mov.b @r1+,r0
L_00288FBE:
    c.t = c.r[0] == 0x1u;  // 00288FBE cmp/eq #1,r0
L_00288FC0:
    if (!c.t) { goto L_0028904C; }  // 00288FC0 bf 0x0028904C
L_00288FC2:
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 00288FC2 mov.b @r1,r2
L_00288FC4:
    c.r[2] -= 48;  // 00288FC4 add #-48,r2
L_00288FC6:
    c.r[0] = 0xFu;  // 00288FC6 mov #15,r0
L_00288FC8:
    c.t = c.r[2] > c.r[0];  // 00288FC8 cmp/hi r0,r2
L_00288FCA:
    if (c.t) { goto L_0028904C; }  // 00288FCA bt 0x0028904C
L_00288FCC:
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 00288FCC shlr r2
L_00288FCE:
    c.r[2] <<= 8;  // 00288FCE shll8 r2
L_00288FD0:
    c.r[2] >>= 2;  // 00288FD0 shlr2 r2
L_00288FD2:
    c.r[4] = c.r[2];  // 00288FD2 mov r2,r4
L_00288FD4:
    c.r[1] = ld32(0x00289058u);  // 00288FD4 mov.l 0x00289058,r1
L_00288FD6:
    c.r[1] += c.r[2];  // 00288FD6 add r2,r1
L_00288FD8:
    c.r[1] += 20;  // 00288FD8 add #20,r1
L_00288FDA:
    c.r[7] = 0x6u;  // 00288FDA mov #6,r7
L_00288FDC:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]); c.r[3] += 1;  // 00288FDC mov.b @r3+,r0
L_00288FDE:
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 00288FDE mov.b @r1+,r2
L_00288FE0:
    c.t = c.r[0] == c.r[2];  // 00288FE0 cmp/eq r2,r0
L_00288FE2:
    if (c.t) { goto L_00288FF8; }  // 00288FE2 bt 0x00288FF8
L_00288FE4:
    c.r[6] = c.r[0];  // 00288FE4 mov r0,r6
L_00288FE6:
    c.r[0] = c.r[2];  // 00288FE6 mov r2,r0
L_00288FE8:
    c.t = c.r[0] == 0xFFFFFFFFu;  // 00288FE8 cmp/eq #-1,r0
L_00288FEA:
    if (!c.t) { goto L_0028904C; }  // 00288FEA bf 0x0028904C
L_00288FEC:
    c.t = (c.r[6] & c.r[6]) == 0;  // 00288FEC tst r6,r6
L_00288FEE:
    if (!c.t) { goto L_0028904C; }  // 00288FEE bf 0x0028904C
L_00288FF0:
    c.r[7] -= 1; c.t = c.r[7] == 0;  // 00288FF0 dt r7
L_00288FF2:
    if (!c.t) { SH2_POLL(c); goto L_00288FDC; }  // 00288FF2 bf 0x00288FDC
L_00288FF4:
    goto L_0028904C;  // 00288FF4 bra 0x0028904C ; nop
L_00288FF8:
    c.t = c.r[0] == 0xFFFFFFFFu;  // 00288FF8 cmp/eq #-1,r0
L_00288FFA:
    if (c.t) { goto L_00289004; }  // 00288FFA bt 0x00289004
L_00288FFC:
    c.r[7] -= 1; c.t = c.r[7] == 0;  // 00288FFC dt r7
L_00288FFE:
    if (!c.t) { SH2_POLL(c); goto L_00288FDC; }  // 00288FFE bf 0x00288FDC
L_00289000:
    goto L_0028904C;  // 00289000 bra 0x0028904C ; nop
L_00289004:
    c.r[5] = ld32(0x00289058u);  // 00289004 mov.l 0x00289058,r5
L_00289006:
    c.r[5] += c.r[4];  // 00289006 add r4,r5
L_00289008:
    c.r[5] += 52;  // 00289008 add #52,r5
L_0028900A:
    goto L_0028904C;  // 0028900A bra 0x0028904C ; nop
L_0028900E:
    c.r[3] = c.r[5];  // 0028900E mov r5,r3
L_00289010:
    c.r[1] = c.r[5];  // 00289010 mov r5,r1
L_00289012:
    c.r[1] -= 2;  // 00289012 add #-2,r1
L_00289014:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 00289014 mov.b @r1+,r0
L_00289016:
    c.t = c.r[0] == 0x1u;  // 00289016 cmp/eq #1,r0
L_00289018:
    if (!c.t) { goto L_0028904C; }  // 00289018 bf 0x0028904C
L_0028901A:
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0028901A mov.b @r1,r2
L_0028901C:
    c.r[2] -= 48;  // 0028901C add #-48,r2
L_0028901E:
    c.r[0] = 0xFu;  // 0028901E mov #15,r0
L_00289020:
    c.t = c.r[2] > c.r[0];  // 00289020 cmp/hi r0,r2
L_00289022:
    if (c.t) { goto L_0028904C; }  // 00289022 bt 0x0028904C
L_00289024:
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 00289024 shlr r2
L_00289026:
    c.r[2] <<= 8;  // 00289026 shll8 r2
L_00289028:
    c.r[2] >>= 2;  // 00289028 shlr2 r2
L_0028902A:
    c.r[4] = c.r[2];  // 0028902A mov r2,r4
L_0028902C:
    c.r[1] = ld32(0x00289058u);  // 0028902C mov.l 0x00289058,r1
L_0028902E:
    c.r[1] += c.r[2];  // 0028902E add r2,r1
L_00289030:
    c.r[7] = 0xEu;  // 00289030 mov #14,r7
L_00289032:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]); c.r[3] += 1;  // 00289032 mov.b @r3+,r0
L_00289034:
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 00289034 mov.b @r1+,r2
L_00289036:
    c.t = c.r[0] == c.r[2];  // 00289036 cmp/eq r2,r0
L_00289038:
    if (!c.t) { goto L_0028904C; }  // 00289038 bf 0x0028904C
L_0028903A:
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0028903A cmp/eq #-1,r0
L_0028903C:
    if (c.t) { goto L_00289046; }  // 0028903C bt 0x00289046
L_0028903E:
    c.r[7] -= 1; c.t = c.r[7] == 0;  // 0028903E dt r7
L_00289040:
    if (!c.t) { SH2_POLL(c); goto L_00289032; }  // 00289040 bf 0x00289032
L_00289042:
    goto L_0028904C;  // 00289042 bra 0x0028904C ; nop
L_00289046:
    c.r[5] = ld32(0x00289058u);  // 00289046 mov.l 0x00289058,r5
L_00289048:
    c.r[5] += c.r[4];  // 00289048 add r4,r5
L_0028904A:
    c.r[5] += 32;  // 0028904A add #32,r5
L_0028904C:
    c.r[4] = 0x0u;  // 0028904C mov #0,r4
L_0028904E:
    c.r[6] = 0x0u;  // 0028904E mov #0,r6
L_00289050:
    c.r[0] = ld32(0x0028905Cu);  // 00289050 mov.l 0x0028905C,r0
L_00289052:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x00288FB2u: goto L_00288FB2; case 0x00288FB4u: goto L_00288FB4; case 0x00288FB6u: goto L_00288FB6; case 0x00288FB8u: goto L_00288FB8; case 0x00288FBAu: goto L_00288FBA; case 0x00288FBCu: goto L_00288FBC; case 0x00288FBEu: goto L_00288FBE; case 0x00288FC0u: goto L_00288FC0; case 0x00288FC2u: goto L_00288FC2; case 0x00288FC4u: goto L_00288FC4; case 0x00288FC6u: goto L_00288FC6; case 0x00288FC8u: goto L_00288FC8; case 0x00288FCAu: goto L_00288FCA; case 0x00288FCCu: goto L_00288FCC; case 0x00288FCEu: goto L_00288FCE; case 0x00288FD0u: goto L_00288FD0; case 0x00288FD2u: goto L_00288FD2; case 0x00288FD4u: goto L_00288FD4; case 0x00288FD6u: goto L_00288FD6; case 0x00288FD8u: goto L_00288FD8; case 0x00288FDAu: goto L_00288FDA; case 0x00288FDCu: goto L_00288FDC; case 0x00288FDEu: goto L_00288FDE; case 0x00288FE0u: goto L_00288FE0; case 0x00288FE2u: goto L_00288FE2; case 0x00288FE4u: goto L_00288FE4; case 0x00288FE6u: goto L_00288FE6; case 0x00288FE8u: goto L_00288FE8; case 0x00288FEAu: goto L_00288FEA; case 0x00288FECu: goto L_00288FEC; case 0x00288FEEu: goto L_00288FEE; case 0x00288FF0u: goto L_00288FF0; case 0x00288FF2u: goto L_00288FF2; case 0x00288FF4u: goto L_00288FF4; case 0x00288FF8u: goto L_00288FF8; case 0x00288FFAu: goto L_00288FFA; case 0x00288FFCu: goto L_00288FFC; case 0x00288FFEu: goto L_00288FFE; case 0x00289000u: goto L_00289000; case 0x00289004u: goto L_00289004; case 0x00289006u: goto L_00289006; case 0x00289008u: goto L_00289008; case 0x0028900Au: goto L_0028900A; case 0x0028900Eu: goto L_0028900E; case 0x00289010u: goto L_00289010; case 0x00289012u: goto L_00289012; case 0x00289014u: goto L_00289014; case 0x00289016u: goto L_00289016; case 0x00289018u: goto L_00289018; case 0x0028901Au: goto L_0028901A; case 0x0028901Cu: goto L_0028901C; case 0x0028901Eu: goto L_0028901E; case 0x00289020u: goto L_00289020; case 0x00289022u: goto L_00289022; case 0x00289024u: goto L_00289024; case 0x00289026u: goto L_00289026; case 0x00289028u: goto L_00289028; case 0x0028902Au: goto L_0028902A; case 0x0028902Cu: goto L_0028902C; case 0x0028902Eu: goto L_0028902E; case 0x00289030u: goto L_00289030; case 0x00289032u: goto L_00289032; case 0x00289034u: goto L_00289034; case 0x00289036u: goto L_00289036; case 0x00289038u: goto L_00289038; case 0x0028903Au: goto L_0028903A; case 0x0028903Cu: goto L_0028903C; case 0x0028903Eu: goto L_0028903E; case 0x00289040u: goto L_00289040; case 0x00289042u: goto L_00289042; case 0x00289046u: goto L_00289046; case 0x00289048u: goto L_00289048; case 0x0028904Au: goto L_0028904A; case 0x0028904Cu: goto L_0028904C; case 0x0028904Eu: goto L_0028904E; case 0x00289050u: goto L_00289050; case 0x00289052u: goto L_00289052; default: sh2_call(c, x); return; } }  // 00289052 jmp @r0 ; nop
}

void f_00289A94(SH2Context& c) {
    ran[10] = 1;
L_00289A94:
    c.r[3] = c.r[5];  // 00289A94 mov r5,r3
L_00289A96:
    c.r[1] = ld32(0x00289AA8u);  // 00289A96 mov.l 0x00289AA8,r1
L_00289A98:
    c.r[1] = ld32(c.r[1]);  // 00289A98 mov.l @r1,r1
L_00289A9A:
    c.r[6] = ld32(0x00289AACu);  // 00289A9A mov.l 0x00289AAC,r6
L_00289A9C:
    c.r[6] += 7;  // 00289A9C add #7,r6
L_00289A9E:
    c.r[6] += c.r[1];  // 00289A9E add r1,r6
L_00289AA0:
    c.r[0] = ld32(0x00289AB0u);  // 00289AA0 mov.l 0x00289AB0,r0
L_00289AA2:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x00289A94u: goto L_00289A94; case 0x00289A96u: goto L_00289A96; case 0x00289A98u: goto L_00289A98; case 0x00289A9Au: goto L_00289A9A; case 0x00289A9Cu: goto L_00289A9C; case 0x00289A9Eu: goto L_00289A9E; case 0x00289AA0u: goto L_00289AA0; case 0x00289AA2u: goto L_00289AA2; default: sh2_call(c, x); return; } }  // 00289AA2 jmp @r0 ; nop
}

void f_00289B58(SH2Context& c) {
    ran[11] = 1;
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 00289B58 sts.l pr,@-r15
    c.r[0] = ld32(0x00289B70u);  // 00289B5A mov.l 0x00289B70,r0
    { const uint32_t x = c.r[0]; c.pr = 0x00289B60u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x00289B60u) return; }  // 00289B5C jsr @r0 ; nop
    if (c.t) { goto L_00289B68; }  // 00289B60 bt 0x00289B68
    c.r[0] = ld32(0x00289B74u);  // 00289B62 mov.l 0x00289B74,r0
    { const uint32_t x = c.r[0]; c.pr = 0x00289B68u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x00289B68u) return; }  // 00289B64 jsr @r0 ; nop
L_00289B68:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 00289B68 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.pc = x; return; }  // 00289B6A rts ; nop
}

void f_00289B78(SH2Context& c) {
    ran[12] = 1;
L_00289B78:
    c.t = (c.r[6] & c.r[6]) == 0;  // 00289B78 tst r6,r6
L_00289B7A:
    if (c.t) { goto L_00289BB6; }  // 00289B7A bt 0x00289BB6
L_00289B7C:
    c.r[1] = c.r[5];  // 00289B7C mov r5,r1
L_00289B7E:
    c.r[1] -= 16;  // 00289B7E add #-16,r1
L_00289B80:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 00289B80 mov.b @r1+,r0
L_00289B82:
    c.t = c.r[0] == 0x1u;  // 00289B82 cmp/eq #1,r0
L_00289B84:
    if (!c.t) { goto L_00289BB6; }  // 00289B84 bf 0x00289BB6
L_00289B86:
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 00289B86 mov.b @r1,r2
L_00289B88:
    c.r[2] -= 48;  // 00289B88 add #-48,r2
L_00289B8A:
    c.r[0] = 0xFu;  // 00289B8A mov #15,r0
L_00289B8C:
    c.t = c.r[2] > c.r[0];  // 00289B8C cmp/hi r0,r2
L_00289B8E:
    if (c.t) { goto L_00289BB6; }  // 00289B8E bt 0x00289BB6
L_00289B90:
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 00289B90 shlr r2
L_00289B92:
    c.r[2] <<= 8;  // 00289B92 shll8 r2
L_00289B94:
    c.r[2] >>= 2;  // 00289B94 shlr2 r2
L_00289B96:
    c.r[6] = ld32(0x00289BBCu);  // 00289B96 mov.l 0x00289BBC,r6
L_00289B98:
    c.r[6] += c.r[2];  // 00289B98 add r2,r6
L_00289B9A:
    c.r[3] = c.r[5];  // 00289B9A mov r5,r3
L_00289B9C:
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 00289B9C sts.l pr,@-r15
L_00289B9E:
    c.r[0] = ld32(0x00289BC0u);  // 00289B9E mov.l 0x00289BC0,r0
L_00289BA0:
    { const uint32_t x = c.r[0]; c.pr = 0x00289BA4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x00289BA4u) return; }  // 00289BA0 jsr @r0 ; nop
L_00289BA4:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 00289BA4 lds.l @r15+,pr
L_00289BA6:
    if (!c.t) { goto L_00289BB4; }  // 00289BA6 bf 0x00289BB4
L_00289BA8:
    c.r[5] = c.r[3];  // 00289BA8 mov r3,r5
L_00289BAA:
    c.r[4] = 0x0u;  // 00289BAA mov #0,r4
L_00289BAC:
    c.r[6] = 0x0u;  // 00289BAC mov #0,r6
L_00289BAE:
    c.r[0] = ld32(0x00289BC4u);  // 00289BAE mov.l 0x00289BC4,r0
L_00289BB0:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x00289B78u: goto L_00289B78; case 0x00289B7Au: goto L_00289B7A; case 0x00289B7Cu: goto L_00289B7C; case 0x00289B7Eu: goto L_00289B7E; case 0x00289B80u: goto L_00289B80; case 0x00289B82u: goto L_00289B82; case 0x00289B84u: goto L_00289B84; case 0x00289B86u: goto L_00289B86; case 0x00289B88u: goto L_00289B88; case 0x00289B8Au: goto L_00289B8A; case 0x00289B8Cu: goto L_00289B8C; case 0x00289B8Eu: goto L_00289B8E; case 0x00289B90u: goto L_00289B90; case 0x00289B92u: goto L_00289B92; case 0x00289B94u: goto L_00289B94; case 0x00289B96u: goto L_00289B96; case 0x00289B98u: goto L_00289B98; case 0x00289B9Au: goto L_00289B9A; case 0x00289B9Cu: goto L_00289B9C; case 0x00289B9Eu: goto L_00289B9E; case 0x00289BA0u: goto L_00289BA0; case 0x00289BA4u: goto L_00289BA4; case 0x00289BA6u: goto L_00289BA6; case 0x00289BA8u: goto L_00289BA8; case 0x00289BAAu: goto L_00289BAA; case 0x00289BACu: goto L_00289BAC; case 0x00289BAEu: goto L_00289BAE; case 0x00289BB0u: goto L_00289BB0; case 0x00289BB4u: goto L_00289BB4; case 0x00289BB6u: goto L_00289BB6; case 0x00289BB8u: goto L_00289BB8; default: sh2_call(c, x); return; } }  // 00289BB0 jmp @r0 ; nop
L_00289BB4:
    c.r[6] = 0x1u;  // 00289BB4 mov #1,r6
L_00289BB6:
    c.r[0] = ld32(0x00289BC8u);  // 00289BB6 mov.l 0x00289BC8,r0
L_00289BB8:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x00289B78u: goto L_00289B78; case 0x00289B7Au: goto L_00289B7A; case 0x00289B7Cu: goto L_00289B7C; case 0x00289B7Eu: goto L_00289B7E; case 0x00289B80u: goto L_00289B80; case 0x00289B82u: goto L_00289B82; case 0x00289B84u: goto L_00289B84; case 0x00289B86u: goto L_00289B86; case 0x00289B88u: goto L_00289B88; case 0x00289B8Au: goto L_00289B8A; case 0x00289B8Cu: goto L_00289B8C; case 0x00289B8Eu: goto L_00289B8E; case 0x00289B90u: goto L_00289B90; case 0x00289B92u: goto L_00289B92; case 0x00289B94u: goto L_00289B94; case 0x00289B96u: goto L_00289B96; case 0x00289B98u: goto L_00289B98; case 0x00289B9Au: goto L_00289B9A; case 0x00289B9Cu: goto L_00289B9C; case 0x00289B9Eu: goto L_00289B9E; case 0x00289BA0u: goto L_00289BA0; case 0x00289BA4u: goto L_00289BA4; case 0x00289BA6u: goto L_00289BA6; case 0x00289BA8u: goto L_00289BA8; case 0x00289BAAu: goto L_00289BAA; case 0x00289BACu: goto L_00289BAC; case 0x00289BAEu: goto L_00289BAE; case 0x00289BB0u: goto L_00289BB0; case 0x00289BB4u: goto L_00289BB4; case 0x00289BB6u: goto L_00289BB6; case 0x00289BB8u: goto L_00289BB8; default: sh2_call(c, x); return; } }  // 00289BB8 jmp @r0 ; nop
}

void f_00289D78(SH2Context& c) {
    ran[13] = 1;
L_00289D78:
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 00289D78 mov.l r1,@-r15
L_00289D7A:
    c.r[15] -= 4; st32(c.r[15], sh2_get_sr(c));  // 00289D7A stc.l sr,@-r15
L_00289D7C:
    c.r[1] = ld32(0x00289DA0u);  // 00289D7C mov.l 0x00289DA0,r1
L_00289D7E:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 00289D7E mov.b @r1,r0
L_00289D80:
    c.t = c.r[0] == 0x26u;  // 00289D80 cmp/eq #38,r0
L_00289D82:
    if (!c.t) { goto L_00289D96; }  // 00289D82 bf 0x00289D96
L_00289D84:
    c.r[1] += 1;  // 00289D84 add #1,r1
L_00289D86:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 00289D86 mov.b @r1,r0
L_00289D88:
    c.t = (c.r[0] & c.r[0]) == 0;  // 00289D88 tst r0,r0
L_00289D8A:
    if (!c.t) { goto L_00289D96; }  // 00289D8A bf 0x00289D96
L_00289D8C:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; sh2_set_sr(c, v & 0x3F3u); SH2_POLL(c); }  // 00289D8C ldc.l @r15+,sr
L_00289D8E:
    c.r[1] = ld32(c.r[15]); c.r[15] += 4;  // 00289D8E mov.l @r15+,r1
L_00289D90:
    c.r[0] = ld32(0x00289DA4u);  // 00289D90 mov.l 0x00289DA4,r0
L_00289D92:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x00289D78u: goto L_00289D78; case 0x00289D7Au: goto L_00289D7A; case 0x00289D7Cu: goto L_00289D7C; case 0x00289D7Eu: goto L_00289D7E; case 0x00289D80u: goto L_00289D80; case 0x00289D82u: goto L_00289D82; case 0x00289D84u: goto L_00289D84; case 0x00289D86u: goto L_00289D86; case 0x00289D88u: goto L_00289D88; case 0x00289D8Au: goto L_00289D8A; case 0x00289D8Cu: goto L_00289D8C; case 0x00289D8Eu: goto L_00289D8E; case 0x00289D90u: goto L_00289D90; case 0x00289D92u: goto L_00289D92; case 0x00289D96u: goto L_00289D96; case 0x00289D98u: goto L_00289D98; case 0x00289D9Au: goto L_00289D9A; case 0x00289D9Cu: goto L_00289D9C; default: sh2_call(c, x); return; } }  // 00289D92 jmp @r0 ; nop
L_00289D96:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; sh2_set_sr(c, v & 0x3F3u); SH2_POLL(c); }  // 00289D96 ldc.l @r15+,sr
L_00289D98:
    c.r[1] = ld32(c.r[15]); c.r[15] += 4;  // 00289D98 mov.l @r15+,r1
L_00289D9A:
    c.r[0] = ld32(0x00289DA8u);  // 00289D9A mov.l 0x00289DA8,r0
L_00289D9C:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x00289D78u: goto L_00289D78; case 0x00289D7Au: goto L_00289D7A; case 0x00289D7Cu: goto L_00289D7C; case 0x00289D7Eu: goto L_00289D7E; case 0x00289D80u: goto L_00289D80; case 0x00289D82u: goto L_00289D82; case 0x00289D84u: goto L_00289D84; case 0x00289D86u: goto L_00289D86; case 0x00289D88u: goto L_00289D88; case 0x00289D8Au: goto L_00289D8A; case 0x00289D8Cu: goto L_00289D8C; case 0x00289D8Eu: goto L_00289D8E; case 0x00289D90u: goto L_00289D90; case 0x00289D92u: goto L_00289D92; case 0x00289D96u: goto L_00289D96; case 0x00289D98u: goto L_00289D98; case 0x00289D9Au: goto L_00289D9A; case 0x00289D9Cu: goto L_00289D9C; default: sh2_call(c, x); return; } }  // 00289D9C jmp @r0 ; nop
}

void f_00289DAC(SH2Context& c) {
    ran[14] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 00289DAC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 00289DAE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 00289DB0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 00289DB2 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 00289DB4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 00289DB6 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 00289DB8 mov r15,r14
    c.r[10] = 0x6u;  // 00289DBA mov #6,r10
    c.r[1] = ld32(0x00289E5Cu);  // 00289DBC mov.l 0x00289E5C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x00289DC2u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x00289DC2u) return; }  // 00289DBE jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x00289E60u);  // 00289DC2 mov.l 0x00289E60,r1
    { const uint32_t x = c.r[1]; c.pr = 0x00289DC8u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x00289DC8u) return; }  // 00289DC4 jsr @r1 ; mov #1,r4
    c.r[1] = ld32(0x00289E64u);  // 00289DC8 mov.l 0x00289E64,r1
    { const uint32_t x = c.r[1]; c.pr = 0x00289DCEu; c.r[9] = 0xDu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x00289DCEu) return; }  // 00289DCA jsr @r1 ; mov #13,r9
    c.r[3] = ld32(0x00289E68u);  // 00289DCE mov.l 0x00289E68,r3
    c.r[2] = 0x2u;  // 00289DD0 mov #2,r2
    c.r[1] = (uint32_t)(int32_t)(int8_t)c.r[2];  // 00289DD2 exts.b r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 00289DD4 tst r1,r1
    { const bool k = c.t; c.r[1] = 0x2u; if (k) { goto L_00289DF4; } }  // 00289DD6 bt/s 0x00289DF4 ; mov #2,r1
    c.r[1] = c.r[9];  // 00289DDA mov r9,r1
    c.r[1] -= c.r[2];  // 00289DDC sub r2,r1
    c.r[9] = c.r[1] & 0xFFu;  // 00289DDE extu.b r1,r9
    c.r[4] = (uint32_t)(int16_t)ld16(0x00289E54u);  // 00289DE0 mov.w 0x00289E54,r4
    c.r[1] = 0x2u;  // 00289DE2 mov #2,r1
    c.r[7] = 0x1Au;  // 00289DE4 mov #26,r7
    c.r[6] = c.r[9];  // 00289DE6 mov r9,r6
    c.r[1] += c.r[1];  // 00289DE8 add r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 00289DEA extu.b r1,r1
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 00289DEC mov.l r1,@-r15
    c.r[1] = ld32(0x00289E6Cu);  // 00289DEE mov.l 0x00289E6C,r1
    c.r[5] = c.r[10]; goto L_00289E00;  // 00289DF0 bra 0x00289E00 ; mov r10,r5
L_00289DF4:
    c.r[4] = (uint32_t)(int16_t)ld16(0x00289E54u);  // 00289DF4 mov.w 0x00289E54,r4
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 00289DF6 mov.l r1,@-r15
    c.r[1] = ld32(0x00289E6Cu);  // 00289DF8 mov.l 0x00289E6C,r1
    c.r[7] = 0x1Au;  // 00289DFA mov #26,r7
    c.r[6] = c.r[9];  // 00289DFC mov r9,r6
    c.r[5] = c.r[10];  // 00289DFE mov r10,r5
L_00289E00:
    { const uint32_t x = c.r[1]; c.pr = 0x00289E04u; c.r[11] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x00289E04u) return; }  // 00289E00 jsr @r1 ; mov #1,r11
    c.r[4] = (uint32_t)(int16_t)ld16(0x00289E56u);  // 00289E04 mov.w 0x00289E56,r4
    c.r[8] = ld32(0x00289E70u);  // 00289E06 mov.l 0x00289E70,r8
    { const uint32_t x = c.r[8]; c.pr = 0x00289E0Cu; c.r[15] += 4; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x00289E0Cu) return; }  // 00289E08 jsr @r8 ; add #4,r15
    c.r[10] |= c.r[11];  // 00289E0C or r11,r10
    { const uint32_t x = c.r[8]; c.pr = 0x00289E12u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x00289E12u) return; }  // 00289E0E jsr @r8 ; mov r10,r4
    c.r[9] += 1;  // 00289E12 add #1,r9
    { const uint32_t x = c.r[8]; c.pr = 0x00289E18u; c.r[4] = c.r[9] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x00289E18u) return; }  // 00289E14 jsr @r8 ; extu.b r9,r4
    c.r[1] = ld32(0x00289E74u);  // 00289E18 mov.l 0x00289E74,r1
    c.r[4] = ld32(0x00289E78u);  // 00289E1A mov.l 0x00289E78,r4
    c.r[8] = ld32(0x00289E7Cu);  // 00289E1C mov.l 0x00289E7C,r8
    c.r[9] = (uint32_t)(int8_t)ld8(c.r[1]);  // 00289E1E mov.b @r1,r9
    c.r[5] = 0x17u;  // 00289E20 mov #23,r5
    { const uint32_t x = c.r[8]; c.pr = 0x00289E26u; c.r[9] = c.r[9] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x00289E26u) return; }  // 00289E22 jsr @r8 ; extu.w r9,r9
    c.r[5] = 0x23u;  // 00289E26 mov #35,r5
    { const uint32_t x = c.r[8]; c.pr = 0x00289E2Cu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x00289E2Cu) return; }  // 00289E28 jsr @r8 ; mov r0,r4
    c.r[5] = c.r[9];  // 00289E2C mov r9,r5
    { const uint32_t x = c.r[8]; c.pr = 0x00289E32u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x00289E32u) return; }  // 00289E2E jsr @r8 ; mov r0,r4
    c.r[1] = ld32(0x00289E80u);  // 00289E32 mov.l 0x00289E80,r1
    c.r[6] = 0x0u;  // 00289E34 mov #0,r6
    c.r[5] = c.r[0];  // 00289E36 mov r0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x00289E3Cu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x00289E3Cu) return; }  // 00289E38 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x00289E84u);  // 00289E3C mov.l 0x00289E84,r1
    { const uint32_t x = c.r[1]; c.pr = 0x00289E42u; c.r[4] = 0x42u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x00289E42u) return; }  // 00289E3E jsr @r1 ; mov #66,r4
    c.r[15] = c.r[14];  // 00289E42 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 00289E44 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 00289E46 mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 00289E48 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 00289E4A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 00289E4C mov.l @r15+,r9
    c.r[0] = (uint32_t)(int16_t)ld16(0x00289E58u);  // 00289E4E mov.w 0x00289E58,r0
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 00289E50 rts ; mov.l @r15+,r8
}

void f_00289F18(SH2Context& c) {
    ran[15] = 1;
    c.r[0] = ld32(0x0028A048u);  // 00289F18 mov.l 0x0028A048,r0
    c.t = c.r[6] == c.r[0];  // 00289F1A cmp/eq r0,r6
    if (!c.t) { goto L_00289F4A; }  // 00289F1C bf 0x00289F4A
    c.r[4] = c.r[3];  // 00289F1E mov r3,r4
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 00289F20 mov.b @r4+,r0
    c.t = c.r[0] == 0xFFFFFFECu;  // 00289F22 cmp/eq #-20,r0
    if (!c.t) { goto L_00289F4A; }  // 00289F24 bf 0x00289F4A
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 00289F26 mov.b @r4+,r0
    c.t = c.r[0] == 0x50u;  // 00289F28 cmp/eq #80,r0
    if (!c.t) { goto L_00289F4A; }  // 00289F2A bf 0x00289F4A
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 00289F2C mov.b @r4+,r0
    c.t = c.r[0] == 0xFFFFFFF2u;  // 00289F2E cmp/eq #-14,r0
    if (!c.t) { goto L_00289F4A; }  // 00289F30 bf 0x00289F4A
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 00289F32 mov.b @r4+,r0
    c.t = c.r[0] == 0x2u;  // 00289F34 cmp/eq #2,r0
    if (!c.t) { goto L_00289F4A; }  // 00289F36 bf 0x00289F4A
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 00289F38 mov.b @r4+,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 00289F3A cmp/eq #-1,r0
    if (!c.t) { goto L_00289F4A; }  // 00289F3C bf 0x00289F4A
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 00289F3E mov.b @r4+,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 00289F40 cmp/eq #-1,r0
    if (!c.t) { goto L_00289F4A; }  // 00289F42 bf 0x00289F4A
    c.r[3] = c.r[6];  // 00289F44 mov r6,r3
    { const uint32_t x = c.pr; c.t = 1; c.pc = x; return; }  // 00289F46 rts ; sett
L_00289F4A:
    c.r[0] = ld32(0x0028A04Cu);  // 00289F4A mov.l 0x0028A04C,r0
    c.t = c.r[6] == c.r[0];  // 00289F4C cmp/eq r0,r6
    if (!c.t) { goto L_00289F7C; }  // 00289F4E bf 0x00289F7C
    c.r[4] = c.r[3];  // 00289F50 mov r3,r4
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 00289F52 mov.b @r4+,r0
    c.t = c.r[0] == 0xFFFFFFF2u;  // 00289F54 cmp/eq #-14,r0
    if (!c.t) { goto L_00289F7C; }  // 00289F56 bf 0x00289F7C
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 00289F58 mov.b @r4+,r0
    c.t = c.r[0] == 0x3u;  // 00289F5A cmp/eq #3,r0
    if (!c.t) { goto L_00289F7C; }  // 00289F5C bf 0x00289F7C
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 00289F5E mov.b @r4+,r0
    c.t = c.r[0] == 0x0u;  // 00289F60 cmp/eq #0,r0
    if (!c.t) { goto L_00289F7C; }  // 00289F62 bf 0x00289F7C
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 00289F64 mov.b @r4+,r0
    c.t = c.r[0] == 0x0u;  // 00289F66 cmp/eq #0,r0
    if (!c.t) { goto L_00289F7C; }  // 00289F68 bf 0x00289F7C
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 00289F6A mov.b @r4+,r0
    c.t = c.r[0] == 0x0u;  // 00289F6C cmp/eq #0,r0
    if (!c.t) { goto L_00289F7C; }  // 00289F6E bf 0x00289F7C
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 00289F70 mov.b @r4+,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 00289F72 cmp/eq #-1,r0
    if (!c.t) { goto L_00289F7C; }  // 00289F74 bf 0x00289F7C
    c.r[3] = c.r[6];  // 00289F76 mov r6,r3
    { const uint32_t x = c.pr; c.t = 1; c.pc = x; return; }  // 00289F78 rts ; sett
L_00289F7C:
    c.r[0] = ld32(0x0028A04Cu);  // 00289F7C mov.l 0x0028A04C,r0
    c.t = c.r[6] == c.r[0];  // 00289F7E cmp/eq r0,r6
    if (!c.t) { goto L_00289FAE; }  // 00289F80 bf 0x00289FAE
    c.r[4] = c.r[3];  // 00289F82 mov r3,r4
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 00289F84 mov.b @r4+,r0
    c.t = c.r[0] == 0xFFFFFFF2u;  // 00289F86 cmp/eq #-14,r0
    if (!c.t) { goto L_00289FAE; }  // 00289F88 bf 0x00289FAE
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 00289F8A mov.b @r4+,r0
    c.t = c.r[0] == 0x3u;  // 00289F8C cmp/eq #3,r0
    if (!c.t) { goto L_00289FAE; }  // 00289F8E bf 0x00289FAE
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 00289F90 mov.b @r4+,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 00289F92 cmp/eq #-1,r0
    if (!c.t) { goto L_00289FAE; }  // 00289F94 bf 0x00289FAE
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 00289F96 mov.b @r4+,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 00289F98 cmp/eq #-1,r0
    if (!c.t) { goto L_00289FAE; }  // 00289F9A bf 0x00289FAE
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 00289F9C mov.b @r4+,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 00289F9E cmp/eq #-1,r0
    if (!c.t) { goto L_00289FAE; }  // 00289FA0 bf 0x00289FAE
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 00289FA2 mov.b @r4+,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 00289FA4 cmp/eq #-1,r0
    if (!c.t) { goto L_00289FAE; }  // 00289FA6 bf 0x00289FAE
    c.r[3] = c.r[6];  // 00289FA8 mov r6,r3
    { const uint32_t x = c.pr; c.t = 1; c.pc = x; return; }  // 00289FAA rts ; sett
L_00289FAE:
    c.r[0] = ld32(0x0028A048u);  // 00289FAE mov.l 0x0028A048,r0
    c.t = c.r[6] == c.r[0];  // 00289FB0 cmp/eq r0,r6
    if (!c.t) { goto L_00289FE0; }  // 00289FB2 bf 0x00289FE0
    c.r[4] = c.r[3];  // 00289FB4 mov r3,r4
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 00289FB6 mov.b @r4+,r0
    c.t = c.r[0] == 0xFFFFFFECu;  // 00289FB8 cmp/eq #-20,r0
    if (!c.t) { goto L_00289FE0; }  // 00289FBA bf 0x00289FE0
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 00289FBC mov.b @r4+,r0
    c.t = c.r[0] == 0x50u;  // 00289FBE cmp/eq #80,r0
    if (!c.t) { goto L_00289FE0; }  // 00289FC0 bf 0x00289FE0
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 00289FC2 mov.b @r4+,r0
    c.t = c.r[0] == 0xFFFFFFF3u;  // 00289FC4 cmp/eq #-13,r0
    if (!c.t) { goto L_00289FE0; }  // 00289FC6 bf 0x00289FE0
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 00289FC8 mov.b @r4+,r0
    c.t = c.r[0] == 0x4Du;  // 00289FCA cmp/eq #77,r0
    if (!c.t) { goto L_00289FE0; }  // 00289FCC bf 0x00289FE0
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 00289FCE mov.b @r4+,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 00289FD0 cmp/eq #-1,r0
    if (!c.t) { goto L_00289FE0; }  // 00289FD2 bf 0x00289FE0
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 00289FD4 mov.b @r4+,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 00289FD6 cmp/eq #-1,r0
    if (!c.t) { goto L_00289FE0; }  // 00289FD8 bf 0x00289FE0
    c.r[3] = c.r[6];  // 00289FDA mov r6,r3
    { const uint32_t x = c.pr; c.t = 1; c.pc = x; return; }  // 00289FDC rts ; sett
L_00289FE0:
    c.r[0] = ld32(0x0028A048u);  // 00289FE0 mov.l 0x0028A048,r0
    c.t = c.r[6] == c.r[0];  // 00289FE2 cmp/eq r0,r6
    if (!c.t) { goto L_0028A012; }  // 00289FE4 bf 0x0028A012
    c.r[4] = c.r[3];  // 00289FE6 mov r3,r4
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 00289FE8 mov.b @r4+,r0
    c.t = c.r[0] == 0xFFFFFFECu;  // 00289FEA cmp/eq #-20,r0
    if (!c.t) { goto L_0028A012; }  // 00289FEC bf 0x0028A012
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 00289FEE mov.b @r4+,r0
    c.t = c.r[0] == 0x50u;  // 00289FF0 cmp/eq #80,r0
    if (!c.t) { goto L_0028A012; }  // 00289FF2 bf 0x0028A012
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 00289FF4 mov.b @r4+,r0
    c.t = c.r[0] == 0xFFFFFFF3u;  // 00289FF6 cmp/eq #-13,r0
    if (!c.t) { goto L_0028A012; }  // 00289FF8 bf 0x0028A012
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 00289FFA mov.b @r4+,r0
    c.t = c.r[0] == 0x4Du;  // 00289FFC cmp/eq #77,r0
    if (!c.t) { goto L_0028A012; }  // 00289FFE bf 0x0028A012
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 0028A000 mov.b @r4+,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0028A002 cmp/eq #-1,r0
    if (!c.t) { goto L_0028A012; }  // 0028A004 bf 0x0028A012
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 0028A006 mov.b @r4+,r0
    c.t = c.r[0] == 0x0u;  // 0028A008 cmp/eq #0,r0
    if (!c.t) { goto L_0028A012; }  // 0028A00A bf 0x0028A012
    c.r[3] = c.r[6];  // 0028A00C mov r6,r3
    { const uint32_t x = c.pr; c.t = 1; c.pc = x; return; }  // 0028A00E rts ; sett
L_0028A012:
    c.r[0] = ld32(0x0028A048u);  // 0028A012 mov.l 0x0028A048,r0
    c.t = c.r[6] == c.r[0];  // 0028A014 cmp/eq r0,r6
    if (!c.t) { goto L_0028A044; }  // 0028A016 bf 0x0028A044
    c.r[4] = c.r[3];  // 0028A018 mov r3,r4
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 0028A01A mov.b @r4+,r0
    c.t = c.r[0] == 0xFFFFFFECu;  // 0028A01C cmp/eq #-20,r0
    if (!c.t) { goto L_0028A044; }  // 0028A01E bf 0x0028A044
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 0028A020 mov.b @r4+,r0
    c.t = c.r[0] == 0x50u;  // 0028A022 cmp/eq #80,r0
    if (!c.t) { goto L_0028A044; }  // 0028A024 bf 0x0028A044
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 0028A026 mov.b @r4+,r0
    c.t = c.r[0] == 0xFFFFFFF3u;  // 0028A028 cmp/eq #-13,r0
    if (!c.t) { goto L_0028A044; }  // 0028A02A bf 0x0028A044
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 0028A02C mov.b @r4+,r0
    c.t = c.r[0] == 0x4Du;  // 0028A02E cmp/eq #77,r0
    if (!c.t) { goto L_0028A044; }  // 0028A030 bf 0x0028A044
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 0028A032 mov.b @r4+,r0
    c.t = c.r[0] == 0x0u;  // 0028A034 cmp/eq #0,r0
    if (!c.t) { goto L_0028A044; }  // 0028A036 bf 0x0028A044
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[4]); c.r[4] += 1;  // 0028A038 mov.b @r4+,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0028A03A cmp/eq #-1,r0
    if (!c.t) { goto L_0028A044; }  // 0028A03C bf 0x0028A044
    c.r[3] = c.r[6];  // 0028A03E mov r6,r3
    { const uint32_t x = c.pr; c.t = 1; c.pc = x; return; }  // 0028A040 rts ; sett
L_0028A044:
    { const uint32_t x = c.pr; c.t = 0; c.pc = x; return; }  // 0028A044 rts ; clrt
}

void f_0028AE78(SH2Context& c) {
    ran[16] = 1;
L_0028AE78:
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0028AE78 sts.l pr,@-r15
L_0028AE7A:
    c.r[15] -= 4; st32(c.r[15], c.r[1]);  // 0028AE7A mov.l r1,@-r15
L_0028AE7C:
    c.r[15] -= 4; st32(c.r[15], c.r[2]);  // 0028AE7C mov.l r2,@-r15
L_0028AE7E:
    c.r[15] -= 4; st32(c.r[15], c.r[3]);  // 0028AE7E mov.l r3,@-r15
L_0028AE80:
    c.r[15] -= 4; st32(c.r[15], c.r[4]);  // 0028AE80 mov.l r4,@-r15
L_0028AE82:
    c.r[15] -= 4; st32(c.r[15], c.r[5]);  // 0028AE82 mov.l r5,@-r15
L_0028AE84:
    c.r[15] -= 4; st32(c.r[15], c.r[6]);  // 0028AE84 mov.l r6,@-r15
L_0028AE86:
    c.r[15] -= 4; st32(c.r[15], c.r[7]);  // 0028AE86 mov.l r7,@-r15
L_0028AE88:
    c.pr = 0x0028AE8Cu; SH2_POLL(c); sh2_call(c, 0x0028AEE2u); if (c.pc != 0x0028AE8Cu) return;  // 0028AE88 bsr 0x0028AEE2 ; nop
L_0028AE8C:
    c.r[0] = c.r[4];  // 0028AE8C mov r4,r0
L_0028AE8E:
    c.r[0] += 1;  // 0028AE8E add #1,r0
L_0028AE90:
    c.r[1] = ld32(0x0028AFD8u);  // 0028AE90 mov.l 0x0028AFD8,r1
L_0028AE92:
    st8(c.r[1], c.r[0]);  // 0028AE92 mov.b r0,@r1
L_0028AE94:
    c.pr = 0x0028AE98u; SH2_POLL(c); sh2_call(c, 0x0028AF4Eu); if (c.pc != 0x0028AE98u) return;  // 0028AE94 bsr 0x0028AF4E ; nop
L_0028AE98:
    c.r[7] = ld32(c.r[15]); c.r[15] += 4;  // 0028AE98 mov.l @r15+,r7
L_0028AE9A:
    c.r[6] = ld32(c.r[15]); c.r[15] += 4;  // 0028AE9A mov.l @r15+,r6
L_0028AE9C:
    c.r[5] = ld32(c.r[15]); c.r[15] += 4;  // 0028AE9C mov.l @r15+,r5
L_0028AE9E:
    c.r[4] = ld32(c.r[15]); c.r[15] += 4;  // 0028AE9E mov.l @r15+,r4
L_0028AEA0:
    c.r[3] = ld32(c.r[15]); c.r[15] += 4;  // 0028AEA0 mov.l @r15+,r3
L_0028AEA2:
    c.r[2] = ld32(c.r[15]); c.r[15] += 4;  // 0028AEA2 mov.l @r15+,r2
L_0028AEA4:
    c.r[1] = ld32(c.r[15]); c.r[15] += 4;  // 0028AEA4 mov.l @r15+,r1
L_0028AEA6:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0028AEA6 lds.l @r15+,pr
L_0028AEA8:
    c.r[0] = ld32(0x0028AFDCu);  // 0028AEA8 mov.l 0x0028AFDC,r0
L_0028AEAA:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x0028AE78u: goto L_0028AE78; case 0x0028AE7Au: goto L_0028AE7A; case 0x0028AE7Cu: goto L_0028AE7C; case 0x0028AE7Eu: goto L_0028AE7E; case 0x0028AE80u: goto L_0028AE80; case 0x0028AE82u: goto L_0028AE82; case 0x0028AE84u: goto L_0028AE84; case 0x0028AE86u: goto L_0028AE86; case 0x0028AE88u: goto L_0028AE88; case 0x0028AE8Cu: goto L_0028AE8C; case 0x0028AE8Eu: goto L_0028AE8E; case 0x0028AE90u: goto L_0028AE90; case 0x0028AE92u: goto L_0028AE92; case 0x0028AE94u: goto L_0028AE94; case 0x0028AE98u: goto L_0028AE98; case 0x0028AE9Au: goto L_0028AE9A; case 0x0028AE9Cu: goto L_0028AE9C; case 0x0028AE9Eu: goto L_0028AE9E; case 0x0028AEA0u: goto L_0028AEA0; case 0x0028AEA2u: goto L_0028AEA2; case 0x0028AEA4u: goto L_0028AEA4; case 0x0028AEA6u: goto L_0028AEA6; case 0x0028AEA8u: goto L_0028AEA8; case 0x0028AEAAu: goto L_0028AEAA; default: sh2_call(c, x); return; } }  // 0028AEAA jmp @r0 ; nop
}

void f_0028AEE2(SH2Context& c) {
    ran[17] = 1;
    c.r[1] = ld32(0x0028AFF0u);  // 0028AEE2 mov.l 0x0028AFF0,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1] + 7);  // 0028AEE4 mov.b @(7,r1),r0
    c.r[0] = c.r[0] & 0xFFu;  // 0028AEE6 extu.b r0,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0028AEE8 tst r0,r0
    if (c.t) { goto L_0028AF0A; }  // 0028AEEA bt 0x0028AF0A
    c.r[0] -= 1;  // 0028AEEC add #-1,r0
    c.r[4] = c.r[0];  // 0028AEEE mov r0,r4
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0028AEF0 mov.w @(0,r1),r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0028AEF2 tst r0,r0
    if (!c.t) { goto L_0028AF1A; }  // 0028AEF4 bf 0x0028AF1A
    c.r[1] = ld32(0x0028AFF4u);  // 0028AEF6 mov.l 0x0028AFF4,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0028AEF8 mov.b @r1,r0
    c.r[0] = c.r[0] & 0xFFu;  // 0028AEFA extu.b r0,r0
    c.t = c.r[0] == c.r[4];  // 0028AEFC cmp/eq r4,r0
    if (c.t) { goto L_0028AF1A; }  // 0028AEFE bt 0x0028AF1A
    c.r[1] = ld32(0x0028AFF8u);  // 0028AF00 mov.l 0x0028AFF8,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0028AF02 mov.b @r1,r0
    c.r[0] = c.r[0] & 0xFFu;  // 0028AF04 extu.b r0,r0
    c.t = c.r[0] == c.r[4];  // 0028AF06 cmp/eq r4,r0
    if (c.t) { goto L_0028AF1A; }  // 0028AF08 bt 0x0028AF1A
L_0028AF0A:
    c.r[1] = ld32(0x0028AFFCu);  // 0028AF0A mov.l 0x0028AFFC,r1
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0028AF0C mov.w @r1,r0
    c.t = (c.r[0] & 0x98u) == 0;  // 0028AF0E tst #152,r0
    c.r[1] = ld32(0x0028AFF4u);  // 0028AF10 mov.l 0x0028AFF4,r1
    if (c.t) { goto L_0028AF16; }  // 0028AF12 bt 0x0028AF16
    c.r[1] += 1;  // 0028AF14 add #1,r1
L_0028AF16:
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0028AF16 mov.b @r1,r4
    c.r[4] = c.r[4] & 0xFFu;  // 0028AF18 extu.b r4,r4
L_0028AF1A:
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0028AF1A rts ; nop
}

void f_0028AF1E(SH2Context& c) {
    ran[18] = 1;
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0028AF1E sts.l pr,@-r15
    c.r[2] = ld32(0x0028B000u);  // 0028AF20 mov.l 0x0028B000,r2
    c.pr = 0x0028AF26u; SH2_POLL(c); sh2_call(c, 0x0028AF38u); if (c.pc != 0x0028AF26u) return;  // 0028AF22 bsr 0x0028AF38 ; nop
    c.r[0] = 0x24u;  // 0028AF26 mov #36,r0
    c.r[0] <<= 2;  // 0028AF28 shll2 r0
    c.pr = 0x0028AF2Eu; c.r[2] += c.r[0]; SH2_POLL(c); sh2_call(c, 0x0028AF38u); if (c.pc != 0x0028AF2Eu) return;  // 0028AF2A bsr 0x0028AF38 ; add r0,r2
    c.pr = 0x0028AF32u; c.r[2] += c.r[1]; SH2_POLL(c); sh2_call(c, 0x0028AF38u); if (c.pc != 0x0028AF32u) return;  // 0028AF2E bsr 0x0028AF38 ; add r1,r2
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0028AF32 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0028AF34 rts ; nop
}

void f_0028AF38(SH2Context& c) {
    ran[19] = 1;
    c.r[3] = c.r[2];  // 0028AF38 mov r2,r3
    c.r[7] = 0x4u;  // 0028AF3A mov #4,r7
    c.r[0] = 0x0u;  // 0028AF3C mov #0,r0
L_0028AF3E:
    c.r[0] <<= 8;  // 0028AF3E shll8 r0
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[3]); c.r[3] += 1;  // 0028AF40 mov.b @r3+,r6
    c.r[6] = c.r[6] & 0xFFu;  // 0028AF42 extu.b r6,r6
    c.r[0] |= c.r[6];  // 0028AF44 or r6,r0
    c.r[7] -= 1; c.t = c.r[7] == 0;  // 0028AF46 dt r7
    if (!c.t) { SH2_POLL(c); goto L_0028AF3E; }  // 0028AF48 bf 0x0028AF3E
    { const uint32_t x = c.pr; c.r[2] += c.r[0]; c.pc = x; return; }  // 0028AF4A rts ; add r0,r2
}

void f_0028AF4E(SH2Context& c) {
    ran[20] = 1;
    c.r[1] = ld32(0x0028B008u);  // 0028AF4E mov.l 0x0028B008,r1
    c.r[3] = 0x3Cu;  // 0028AF50 mov #60,r3
L_0028AF52:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0028AF52 mov.b @r1+,r0
    c.r[0] = c.r[0] & 0xFFu;  // 0028AF54 extu.b r0,r0
    c.t = c.r[0] == c.r[4];  // 0028AF56 cmp/eq r4,r0
    if (c.t) { goto L_0028AFBA; }  // 0028AF58 bt 0x0028AFBA
    c.r[3] -= 1; c.t = c.r[3] == 0;  // 0028AF5A dt r3
    if (!c.t) { SH2_POLL(c); goto L_0028AF52; }  // 0028AF5C bf 0x0028AF52
    c.r[0] = 0x0028B004u;  // 0028AF5E mova 0x0028B004,r0
    c.r[1] = c.r[0];  // 0028AF60 mov r0,r1
L_0028AF62:
    c.r[5] = ld32(0x0028B00Cu);  // 0028AF62 mov.l 0x0028B00C,r5
    c.r[6] = 0x1Eu;  // 0028AF64 mov #30,r6
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0028AF66 mov.b @r1,r0
    c.t = c.r[0] == 0x3Eu;  // 0028AF68 cmp/eq #62,r0
    if (!c.t) { goto L_0028AF6E; }  // 0028AF6A bf 0x0028AF6E
    c.r[1] += 1;  // 0028AF6C add #1,r1
L_0028AF6E:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0028AF6E mov.b @r1+,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0028AF70 cmp/eq #-1,r0
    if (c.t) { goto L_0028AF80; }  // 0028AF72 bt 0x0028AF80
    st8(c.r[5], c.r[0]);  // 0028AF74 mov.b r0,@r5
    c.r[5] += 1;  // 0028AF76 add #1,r5
    c.r[6] -= 1; c.t = c.r[6] == 0;  // 0028AF78 dt r6
    if (!c.t) { SH2_POLL(c); goto L_0028AF6E; }  // 0028AF7A bf 0x0028AF6E
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0028AF7C rts ; nop
L_0028AF80:
    c.r[7] = c.r[5];  // 0028AF80 mov r5,r7
    c.r[7] -= 1;  // 0028AF82 add #-1,r7
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0028AF84 mov.b @r7,r0
    c.t = c.r[0] == 0x3Fu;  // 0028AF86 cmp/eq #63,r0
    if (!c.t) { goto L_0028AF8E; }  // 0028AF88 bf 0x0028AF8E
    c.r[5] = c.r[7];  // 0028AF8A mov r7,r5
    c.r[6] += 1;  // 0028AF8C add #1,r6
L_0028AF8E:
    c.r[7] = 0x3u;  // 0028AF8E mov #3,r7
L_0028AF90:
    c.t = c.r[6] >= c.r[7];  // 0028AF90 cmp/hs r7,r6
    if (!c.t) { goto L_0028AFA8; }  // 0028AF92 bf 0x0028AFA8
    c.r[0] = 0xFFFFFFF7u;  // 0028AF94 mov #-9,r0
    st8(c.r[5], c.r[0]);  // 0028AF96 mov.b r0,@r5
    c.r[0] = 0x0u;  // 0028AF98 mov #0,r0
    st8(c.r[5] + 1, c.r[0]);  // 0028AF9A mov.b r0,@(1,r5)
    c.r[0] = 0x40u;  // 0028AF9C mov #64,r0
    st8(c.r[5] + 2, c.r[0]);  // 0028AF9E mov.b r0,@(2,r5)
    c.r[5] += 3;  // 0028AFA0 add #3,r5
    c.r[6] -= 3;  // 0028AFA2 add #-3,r6
    SH2_POLL(c); goto L_0028AF90;  // 0028AFA4 bra 0x0028AF90 ; nop
L_0028AFA8:
    c.t = (c.r[6] & c.r[6]) == 0;  // 0028AFA8 tst r6,r6
    if (c.t) { goto L_0028AFB6; }  // 0028AFAA bt 0x0028AFB6
    c.r[0] = 0x0u;  // 0028AFAC mov #0,r0
L_0028AFAE:
    st8(c.r[5], c.r[0]);  // 0028AFAE mov.b r0,@r5
    c.r[5] += 1;  // 0028AFB0 add #1,r5
    c.r[6] -= 1; c.t = c.r[6] == 0;  // 0028AFB2 dt r6
    if (!c.t) { SH2_POLL(c); goto L_0028AFAE; }  // 0028AFB4 bf 0x0028AFAE
L_0028AFB6:
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0028AFB6 rts ; nop
L_0028AFBA:
    c.r[2] = ld32(0x0028B010u);  // 0028AFBA mov.l 0x0028B010,r2
    c.r[1] -= c.r[2];  // 0028AFBC sub r2,r1
    c.r[1] <<= 2;  // 0028AFBE shll2 r1
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0028AFC0 sts.l pr,@-r15
    c.pr = 0x0028AFC6u; SH2_POLL(c); sh2_call(c, 0x0028AF1Eu); if (c.pc != 0x0028AFC6u) return;  // 0028AFC2 bsr 0x0028AF1E ; nop
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0028AFC6 lds.l @r15+,pr
    c.r[1] = c.r[2];  // 0028AFC8 mov r2,r1
    SH2_POLL(c); goto L_0028AF62;  // 0028AFCA bra 0x0028AF62 ; nop
}

void f_0028B172(SH2Context& c) {
    ran[21] = 1;
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0028B172 sts.l pr,@-r15
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[5] + 15);  // 0028B174 mov.b @(15,r5),r0
    c.r[7] = c.r[0] & 0xFFu;  // 0028B176 extu.b r0,r7
    c.r[0] = c.r[7];  // 0028B178 mov r7,r0
    c.r[0] -= 27;  // 0028B17A add #-27,r0
    c.r[1] = 0x4u;  // 0028B17C mov #4,r1
    c.t = c.r[0] > c.r[1];  // 0028B17E cmp/hi r1,r0
    if (!c.t) { goto L_0028B1FA; }  // 0028B180 bf 0x0028B1FA
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[5] + 4);  // 0028B182 mov.b @(4,r5),r0
    c.r[6] = c.r[5];  // 0028B184 mov r5,r6
    c.r[6] += c.r[0];  // 0028B186 add r0,r6
    c.r[6] -= 17;  // 0028B188 add #-17,r6
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[5] + 5);  // 0028B18A mov.b @(5,r5),r0
    c.r[3] = c.r[0] & 0xFFu;  // 0028B18C extu.b r0,r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[5] + 7);  // 0028B18E mov.b @(7,r5),r0
    c.r[0] = c.r[0] & 0xFFu;  // 0028B190 extu.b r0,r0
    c.r[0] -= 1;  // 0028B192 add #-1,r0
    c.r[0] = c.r[0] & 0xFFu;  // 0028B194 extu.b r0,r0
    c.t = c.r[0] == c.r[3];  // 0028B196 cmp/eq r3,r0
    if (c.t) { goto L_0028B1DA; }  // 0028B198 bt 0x0028B1DA
    c.pr = 0x0028B19Eu; SH2_POLL(c); sh2_call(c, 0x0028B200u); if (c.pc != 0x0028B19Eu) return;  // 0028B19A bsr 0x0028B200 ; nop
    c.t = c.r[0] == c.r[3];  // 0028B19E cmp/eq r3,r0
    if (!c.t) { goto L_0028B1A8; }  // 0028B1A0 bf 0x0028B1A8
    c.r[0] = c.r[0] & 0xFFu;  // 0028B1A2 extu.b r0,r0
    c.pr = 0x0028B1A8u; SH2_POLL(c); sh2_call(c, 0x0028B200u); if (c.pc != 0x0028B1A8u) return;  // 0028B1A4 bsr 0x0028B200 ; nop
L_0028B1A8:
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0028B1A8 cmp/eq #-1,r0
    if (c.t) { goto L_0028B1C0; }  // 0028B1AA bt 0x0028B1C0
    c.r[4] = c.r[0];  // 0028B1AC mov r0,r4
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[5] + 8);  // 0028B1AE mov.b @(8,r5),r0
    c.r[0] = c.r[0] & 0xFFu;  // 0028B1B0 extu.b r0,r0
    c.t = c.r[0] == c.r[4];  // 0028B1B2 cmp/eq r4,r0
    if (c.t) { goto L_0028B1C0; }  // 0028B1B4 bt 0x0028B1C0
    c.r[1] = ld32(0x0028B388u);  // 0028B1B6 mov.l 0x0028B388,r1
    c.r[1] += c.r[7];  // 0028B1B8 add r7,r1
    st8(c.r[1], c.r[4]);  // 0028B1BA mov.b r4,@r1
    goto L_0028B1F4;  // 0028B1BC bra 0x0028B1F4 ; nop
L_0028B1C0:
    c.r[0] = 0x0u;  // 0028B1C0 mov #0,r0
    st8(c.r[6], c.r[0]);  // 0028B1C2 mov.b r0,@r6
    c.r[1] = ld32(0x0028B38Cu);  // 0028B1C4 mov.l 0x0028B38C,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0028B1C6 mov.b @r1,r0
    c.r[0] = c.r[0] & 0xFFu;  // 0028B1C8 extu.b r0,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0028B1CA tst r0,r0
    if (c.t) { goto L_0028B1D6; }  // 0028B1CC bt 0x0028B1D6
    c.r[0] -= 1;  // 0028B1CE add #-1,r0
    c.r[1] = ld32(0x0028B388u);  // 0028B1D0 mov.l 0x0028B388,r1
    c.r[1] += c.r[7];  // 0028B1D2 add r7,r1
    st8(c.r[1], c.r[0]);  // 0028B1D4 mov.b r0,@r1
L_0028B1D6:
    c.r[4] = c.r[3]; goto L_0028B1F4;  // 0028B1D6 bra 0x0028B1F4 ; mov r3,r4
L_0028B1DA:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[5] + 8);  // 0028B1DA mov.b @(8,r5),r0
    c.r[0] = c.r[0] & 0xFFu;  // 0028B1DC extu.b r0,r0
    c.t = c.r[0] == c.r[3];  // 0028B1DE cmp/eq r3,r0
    if (!c.t) { goto L_0028B1EE; }  // 0028B1E0 bf 0x0028B1EE
    c.pr = 0x0028B1E6u; SH2_POLL(c); sh2_call(c, 0x0028B200u); if (c.pc != 0x0028B1E6u) return;  // 0028B1E2 bsr 0x0028B200 ; nop
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0028B1E6 cmp/eq #-1,r0
    if (c.t) { goto L_0028B1FA; }  // 0028B1E8 bt 0x0028B1FA
    st8(c.r[5] + 8, c.r[0]);  // 0028B1EA mov.b r0,@(8,r5)
    c.r[0] = c.r[0] & 0xFFu;  // 0028B1EC extu.b r0,r0
L_0028B1EE:
    c.r[4] = c.r[0];  // 0028B1EE mov r0,r4
    c.r[0] = 0x1u;  // 0028B1F0 mov #1,r0
    st8(c.r[6], c.r[0]);  // 0028B1F2 mov.b r0,@r6
L_0028B1F4:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0028B1F4 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0028B1F6 rts ; nop
L_0028B1FA:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0028B1FA lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[4] = 0xFFFFFFFFu; c.pc = x; return; }  // 0028B1FC rts ; mov #-1,r4
}

void f_0028B200(SH2Context& c) {
    ran[22] = 1;
    c.r[1] = 0x26u;  // 0028B200 mov #38,r1
    c.t = c.r[0] >= c.r[1];  // 0028B202 cmp/hs r1,r0
    if (c.t) { goto L_0028B20C; }  // 0028B204 bt 0x0028B20C
    c.r[1] = ld32(0x0028B3C4u);  // 0028B206 mov.l 0x0028B3C4,r1
    { const uint32_t x = c.pr; c.r[0] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]); c.pc = x; return; }  // 0028B208 rts ; mov.b @(r0,r1),r0
L_0028B20C:
    { const uint32_t x = c.pr; c.r[0] = 0xFFFFFFFFu; c.pc = x; return; }  // 0028B20C rts ; mov #-1,r0
}

void f_0028B20C(SH2Context& c) {
    ran[23] = 1;
    { const uint32_t x = c.pr; c.r[0] = 0xFFFFFFFFu; c.pc = x; return; }  // 0028B20C rts ; mov #-1,r0
}

void f_0028B210(SH2Context& c) {
    ran[24] = 1;
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0028B210 sts.l pr,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0028B212 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0028B214 mov.l r9,@-r15
    c.r[9] = ld32(0x0028B384u);  // 0028B216 mov.l 0x0028B384,r9
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[9] + 9);  // 0028B218 mov.b @(9,r9),r0
    c.r[0] += 1;  // 0028B21A add #1,r0
    st8(c.r[9] + 9, c.r[0]);  // 0028B21C mov.b r0,@(9,r9)
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0028B21E cmp/eq #-1,r0
    if (c.t) { goto L_0028B2E4; }  // 0028B220 bt 0x0028B2E4
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0028B222 mov.b @(0,r9),r0
    c.t = c.r[0] == 0x1u;  // 0028B224 cmp/eq #1,r0
    if (c.t) { goto L_0028B24C; }  // 0028B226 bt 0x0028B24C
    c.t = c.r[0] == 0x2u;  // 0028B228 cmp/eq #2,r0
    if (c.t) { goto L_0028B26E; }  // 0028B22A bt 0x0028B26E
    c.t = c.r[0] == 0x3u;  // 0028B22C cmp/eq #3,r0
    if (c.t) { goto L_0028B29C; }  // 0028B22E bt 0x0028B29C
    c.t = c.r[0] == 0x6u;  // 0028B230 cmp/eq #6,r0
    if (c.t) { goto L_0028B2B8; }  // 0028B232 bt 0x0028B2B8
    c.t = c.r[0] == 0x4u;  // 0028B234 cmp/eq #4,r0
    if (c.t) { goto L_0028B2D2; }  // 0028B236 bt 0x0028B2D2
    c.r[0] = ld32(0x0028B3C8u);  // 0028B238 mov.l 0x0028B3C8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0028B23Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0028B23Eu) return; }  // 0028B23A jsr @r0 ; nop
    c.r[1] = ld32(0x0028B3B4u);  // 0028B23E mov.l 0x0028B3B4,r1
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0028B240 mov.w @r1,r0
    c.r[0] = c.r[0] & 0xFFFFu;  // 0028B242 extu.w r0,r0
    c.t = c.r[0] == 0x20u;  // 0028B244 cmp/eq #32,r0
    if (!c.t) { goto L_0028B2EC; }  // 0028B246 bf 0x0028B2EC
    c.r[0] = 0x0u; goto L_0028B2EA;  // 0028B248 bra 0x0028B2EA ; mov #0,r0
L_0028B24C:
    c.r[1] = ld32(0x0028B3A4u);  // 0028B24C mov.l 0x0028B3A4,r1
    c.r[0] = ld32(c.r[1]);  // 0028B24E mov.l @r1,r0
    c.r[1] = ld32(0x0028B3A8u);  // 0028B250 mov.l 0x0028B3A8,r1
    c.t = c.r[0] == c.r[1];  // 0028B252 cmp/eq r1,r0
    if (c.t) { goto L_0028B25C; }  // 0028B254 bt 0x0028B25C
    c.r[1] = ld32(0x0028B3ACu);  // 0028B256 mov.l 0x0028B3AC,r1
    c.t = c.r[0] == c.r[1];  // 0028B258 cmp/eq r1,r0
    if (!c.t) { goto L_0028B2EC; }  // 0028B25A bf 0x0028B2EC
L_0028B25C:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[9] + 3);  // 0028B25C mov.b @(3,r9),r0
    c.r[4] = c.r[0] & 0xFFu;  // 0028B25E extu.b r0,r4
    c.r[0] = ld32(0x0028B3CCu);  // 0028B260 mov.l 0x0028B3CC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0028B266u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0028B266u) return; }  // 0028B262 jsr @r0 ; nop
    c.t = (c.r[0] & c.r[0]) == 0;  // 0028B266 tst r0,r0
    if (!c.t) { goto L_0028B2EC; }  // 0028B268 bf 0x0028B2EC
    c.r[0] = 0x2u; goto L_0028B2EA;  // 0028B26A bra 0x0028B2EA ; mov #2,r0
L_0028B26E:
    c.r[0] = ld32(0x0028B3D0u);  // 0028B26E mov.l 0x0028B3D0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0028B274u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0028B274u) return; }  // 0028B270 jsr @r0 ; nop
    c.r[1] = ld32(0x0028B3D4u);  // 0028B274 mov.l 0x0028B3D4,r1
    c.t = c.r[0] == c.r[1];  // 0028B276 cmp/eq r1,r0
    if (!c.t) { goto L_0028B27E; }  // 0028B278 bf 0x0028B27E
    c.r[0] = 0x3u; goto L_0028B2EA;  // 0028B27A bra 0x0028B2EA ; mov #3,r0
L_0028B27E:
    c.r[1] = ld32(0x0028B3B4u);  // 0028B27E mov.l 0x0028B3B4,r1
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0028B280 mov.w @r1,r0
    c.t = c.r[0] == 0x40u;  // 0028B282 cmp/eq #64,r0
    if (!c.t) { goto L_0028B2EC; }  // 0028B284 bf 0x0028B2EC
    c.r[1] -= 8;  // 0028B286 add #-8,r1
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0028B288 mov.w @r1,r0
    c.r[0] = c.r[0] & 0xFFFFu;  // 0028B28A extu.w r0,r0
    c.r[0] -= 57;  // 0028B28C add #-57,r0
    c.r[2] = 0x3Fu;  // 0028B28E mov #63,r2
    c.t = c.r[0] > c.r[2];  // 0028B290 cmp/hi r2,r0
    if (c.t) { goto L_0028B2EC; }  // 0028B292 bt 0x0028B2EC
    c.r[2] = 0x79u;  // 0028B294 mov #121,r2
    st16(c.r[1], c.r[2]);  // 0028B296 mov.w r2,@r1
    goto L_0028B2EC;  // 0028B298 bra 0x0028B2EC ; nop
L_0028B29C:
    c.r[1] = ld32(0x0028B3D8u);  // 0028B29C mov.l 0x0028B3D8,r1
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0028B29E mov.w @r1,r0
    c.r[0] = c.r[0] & 0xFFFFu;  // 0028B2A0 extu.w r0,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0028B2A2 tst r0,r0
    if (!c.t) { goto L_0028B2EC; }  // 0028B2A4 bf 0x0028B2EC
    c.r[1] = ld32(0x0028B3B4u);  // 0028B2A6 mov.l 0x0028B3B4,r1
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0028B2A8 mov.w @r1,r0
    c.t = (c.r[0] & 0x1u) == 0;  // 0028B2AA tst #1,r0
    if (c.t) { goto L_0028B2EC; }  // 0028B2AC bt 0x0028B2EC
    c.r[1] = ld32(0x0028B3DCu);  // 0028B2AE mov.l 0x0028B3DC,r1
    c.r[0] = 0x0u;  // 0028B2B0 mov #0,r0
    st8(c.r[1], c.r[0]);  // 0028B2B2 mov.b r0,@r1
    c.r[0] = 0x6u; goto L_0028B2EA;  // 0028B2B4 bra 0x0028B2EA ; mov #6,r0
L_0028B2B8:
    c.r[1] = ld32(0x0028B3DCu);  // 0028B2B8 mov.l 0x0028B3DC,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0028B2BA mov.b @r1,r0
    c.r[0] += 1;  // 0028B2BC add #1,r0
    st8(c.r[1], c.r[0]);  // 0028B2BE mov.b r0,@r1
    c.r[0] = c.r[0] & 0xFFu;  // 0028B2C0 extu.b r0,r0
    c.r[1] = 0x8u;  // 0028B2C2 mov #8,r1
    c.t = c.r[0] >= c.r[1];  // 0028B2C4 cmp/hs r1,r0
    if (!c.t) { goto L_0028B2EC; }  // 0028B2C6 bf 0x0028B2EC
    c.r[0] = ld32(0x0028B3E0u);  // 0028B2C8 mov.l 0x0028B3E0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0028B2CEu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0028B2CEu) return; }  // 0028B2CA jsr @r0 ; mov #0,r4
    c.r[0] = 0x4u; goto L_0028B2EA;  // 0028B2CE bra 0x0028B2EA ; mov #4,r0
L_0028B2D2:
    c.r[0] = ld32(0x0028B3E0u);  // 0028B2D2 mov.l 0x0028B3E0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0028B2D8u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0028B2D8u) return; }  // 0028B2D4 jsr @r0 ; mov #1,r4
    c.pr = 0x0028B2DCu; SH2_POLL(c); sh2_call(c, 0x0028B2F6u); if (c.pc != 0x0028B2DCu) return;  // 0028B2D8 bsr 0x0028B2F6 ; nop
    c.r[0] = 0x0u;  // 0028B2DC mov #0,r0
    st8(c.r[9] + 9, c.r[0]);  // 0028B2DE mov.b r0,@(9,r9)
    c.r[0] = 0x5u; goto L_0028B2EA;  // 0028B2E0 bra 0x0028B2EA ; mov #5,r0
L_0028B2E4:
    c.pr = 0x0028B2E8u; SH2_POLL(c); sh2_call(c, 0x0028B2F6u); if (c.pc != 0x0028B2E8u) return;  // 0028B2E4 bsr 0x0028B2F6 ; nop
    c.r[0] = 0x0u;  // 0028B2E8 mov #0,r0
L_0028B2EA:
    st8(c.r[9], c.r[0]);  // 0028B2EA mov.b r0,@(0,r9)
L_0028B2EC:
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0028B2EC mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0028B2EE mov.l @r15+,r8
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0028B2F0 lds.l @r15+,pr
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0028B2F2 rts ; nop
}

void f_0028B2F6(SH2Context& c) {
    ran[25] = 1;
    c.r[1] = ld32(0x0028B3A4u);  // 0028B2F6 mov.l 0x0028B3A4,r1
    c.r[0] = ld32(c.r[1]);  // 0028B2F8 mov.l @r1,r0
    c.r[1] = ld32(0x0028B3A8u);  // 0028B2FA mov.l 0x0028B3A8,r1
    c.t = c.r[0] == c.r[1];  // 0028B2FC cmp/eq r1,r0
    if (c.t) { goto L_0028B30C; }  // 0028B2FE bt 0x0028B30C
    c.r[1] = ld32(0x0028B3ACu);  // 0028B300 mov.l 0x0028B3AC,r1
    c.t = c.r[0] == c.r[1];  // 0028B302 cmp/eq r1,r0
    if (c.t) { goto L_0028B30C; }  // 0028B304 bt 0x0028B30C
    c.r[1] = ld32(0x0028B3B0u);  // 0028B306 mov.l 0x0028B3B0,r1
    c.t = c.r[0] == c.r[1];  // 0028B308 cmp/eq r1,r0
    if (!c.t) { goto L_0028B332; }  // 0028B30A bf 0x0028B332
L_0028B30C:
    c.r[1] = ld32(0x0028B3E4u);  // 0028B30C mov.l 0x0028B3E4,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0028B30E mov.b @r1,r0
    c.r[0] &= 0xFu;  // 0028B310 and #15,r0
    c.r[2] = c.r[0];  // 0028B312 mov r0,r2
    c.r[2] <<= 2;  // 0028B314 shll2 r2
    c.r[2] <<= 2;  // 0028B316 shll2 r2
    c.r[2] |= c.r[0];  // 0028B318 or r0,r2
    c.r[0] = c.r[2];  // 0028B31A mov r2,r0
    c.r[0] <<= 8;  // 0028B31C shll8 r0
    c.r[2] |= c.r[0];  // 0028B31E or r0,r2
    c.r[0] = c.r[2];  // 0028B320 mov r2,r0
    c.r[0] <<= 16;  // 0028B322 shll16 r0
    c.r[2] |= c.r[0];  // 0028B324 or r0,r2
    c.r[1] = ld32(0x0028B3E8u);  // 0028B326 mov.l 0x0028B3E8,r1
    c.r[3] = ld32(0x0028B3ECu);  // 0028B328 mov.l 0x0028B3EC,r3
L_0028B32A:
    st32(c.r[1], c.r[2]);  // 0028B32A mov.l r2,@r1
    c.r[3] -= 1; c.t = c.r[3] == 0;  // 0028B32C dt r3
    { const bool k = !c.t; c.r[1] += 4; if (k) { SH2_POLL(c); goto L_0028B32A; } }  // 0028B32E bf/s 0x0028B32A ; add #4,r1
L_0028B332:
    { const uint32_t x = c.pr; c.pc = x; return; }  // 0028B332 rts ; nop
}

void f_0028BE2A(SH2Context& c) {
    ran[26] = 1;
L_0028BE2A:
    c.t = c.r[1] == c.r[2];  // 0028BE2A cmp/eq r2,r1
L_0028BE2C:
    if (!c.t) { goto L_0028BE34; }  // 0028BE2C bf 0x0028BE34
L_0028BE2E:
    c.r[0] = ld32(0x0028BE44u);  // 0028BE2E mov.l 0x0028BE44,r0
L_0028BE30:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x0028BE2Au: goto L_0028BE2A; case 0x0028BE2Cu: goto L_0028BE2C; case 0x0028BE2Eu: goto L_0028BE2E; case 0x0028BE30u: goto L_0028BE30; case 0x0028BE34u: goto L_0028BE34; case 0x0028BE36u: goto L_0028BE36; default: sh2_call(c, x); return; } }  // 0028BE30 jmp @r0 ; nop
L_0028BE34:
    c.r[0] = ld32(0x0028BE48u);  // 0028BE34 mov.l 0x0028BE48,r0
L_0028BE36:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x0028BE2Au: goto L_0028BE2A; case 0x0028BE2Cu: goto L_0028BE2C; case 0x0028BE2Eu: goto L_0028BE2E; case 0x0028BE30u: goto L_0028BE30; case 0x0028BE34u: goto L_0028BE34; case 0x0028BE36u: goto L_0028BE36; default: sh2_call(c, x); return; } }  // 0028BE36 jmp @r0 ; nop
}

}  // namespace p_fin_low
