#include "p_srwfin_kor_funcs.h"
#include "p_srwfin_installed_funcs.h"
#include "p_fin_installer_funcs.h"
#include "p_fin_resident_funcs.h"
#include "p_fin_low_funcs.h"

extern const SH2Module* const g_sh2_modules[] = {
    &p_srwfin_kor::module,
    &p_srwfin_installed::module,
    &p_fin_installer::module,
    &p_fin_resident::module,
    &p_fin_low::module,
};
extern const int g_sh2_nmodules = 5;
extern const uint32_t g_sh2_tasks[2] = {0x00000000, 0x00000000};
extern const SH2TaskSwitch g_sh2_task_switches[] = {{0, 0, 0, 0, 0}};
extern const int g_sh2_ntask_switches = 0;
