#include "p_srwfin_kor_funcs.h"

namespace p_srwfin_kor {

void f_06004000(SH2Context& c) {
    ran[0] = 1;
L_06004000:
    c.r[4] = ld32(0x06004024u);  // 06004000 mov.l 0x06004024,r4
L_06004002:
    c.r[15] = ld32(0x0600401Cu);  // 06004002 mov.l 0x0600401C,r15
L_06004004:
    c.r[0] = 0xFFFFFFF0u;  // 06004004 mov #-16,r0
L_06004006:
    c.r[0] = c.r[0] & 0xFFu;  // 06004006 extu.b r0,r0
L_06004008:
    sh2_set_sr(c, c.r[0] & 0x3F3u); SH2_POLL(c);  // 06004008 ldc r0,sr
L_0600400A:
    c.r[15] = ld32(c.r[15]);  // 0600400A mov.l @r15,r15
L_0600400C:
    c.r[1] = 0xFFFFFFA4u;  // 0600400C mov #-92,r1
L_0600400E:
    c.r[1] <<= 2;  // 0600400E shll2 r1
L_06004010:
    c.r[0] = 0x11u;  // 06004010 mov #17,r0
L_06004012:
    st8(c.r[1] + 2, c.r[0]);  // 06004012 mov.b r0,@(2,r1)
L_06004014:
    c.r[0] = ld32(0x06004020u);  // 06004014 mov.l 0x06004020,r0
L_06004016:
    { const uint32_t x = c.r[4]; c.gbr = c.r[0]; SH2_POLL(c); switch (x) { case 0x06004000u: goto L_06004000; case 0x06004002u: goto L_06004002; case 0x06004004u: goto L_06004004; case 0x06004006u: goto L_06004006; case 0x06004008u: goto L_06004008; case 0x0600400Au: goto L_0600400A; case 0x0600400Cu: goto L_0600400C; case 0x0600400Eu: goto L_0600400E; case 0x06004010u: goto L_06004010; case 0x06004012u: goto L_06004012; case 0x06004014u: goto L_06004014; case 0x06004016u: goto L_06004016; case 0x06004060u: goto L_06004060; case 0x06004062u: goto L_06004062; case 0x06004064u: goto L_06004064; case 0x06004066u: goto L_06004066; case 0x06004068u: goto L_06004068; case 0x0600406Au: goto L_0600406A; case 0x0600406Cu: goto L_0600406C; case 0x0600406Eu: goto L_0600406E; case 0x06004070u: goto L_06004070; case 0x06004074u: goto L_06004074; case 0x06004076u: goto L_06004076; case 0x06004078u: goto L_06004078; case 0x0600407Au: goto L_0600407A; case 0x0600407Eu: goto L_0600407E; case 0x06004080u: goto L_06004080; case 0x06004082u: goto L_06004082; case 0x06004084u: goto L_06004084; case 0x06004086u: goto L_06004086; case 0x06004088u: goto L_06004088; case 0x0600408Au: goto L_0600408A; case 0x0600408Cu: goto L_0600408C; case 0x0600408Eu: goto L_0600408E; case 0x06004090u: goto L_06004090; case 0x06004092u: goto L_06004092; case 0x06004094u: goto L_06004094; case 0x06004098u: goto L_06004098; case 0x0600409Au: goto L_0600409A; case 0x0600409Cu: goto L_0600409C; case 0x0600409Eu: goto L_0600409E; case 0x060040A0u: goto L_060040A0; case 0x060040A2u: goto L_060040A2; case 0x060040A4u: goto L_060040A4; case 0x060040A8u: goto L_060040A8; case 0x060040AAu: goto L_060040AA; case 0x060040AEu: goto L_060040AE; case 0x060040B0u: goto L_060040B0; case 0x060040B2u: goto L_060040B2; case 0x060040B6u: goto L_060040B6; case 0x060040B8u: goto L_060040B8; case 0x060040BCu: goto L_060040BC; case 0x060040BEu: goto L_060040BE; case 0x060040C2u: goto L_060040C2; case 0x060040C4u: goto L_060040C4; case 0x060040C8u: goto L_060040C8; case 0x060040CAu: goto L_060040CA; case 0x060040CCu: goto L_060040CC; case 0x060040CEu: goto L_060040CE; case 0x060040D0u: goto L_060040D0; case 0x060040D4u: goto L_060040D4; case 0x060040D6u: goto L_060040D6; case 0x060040D8u: goto L_060040D8; case 0x060040DAu: goto L_060040DA; case 0x060040DCu: goto L_060040DC; case 0x060040E0u: goto L_060040E0; case 0x060040E2u: goto L_060040E2; case 0x060040E4u: goto L_060040E4; case 0x060040E6u: goto L_060040E6; case 0x060040E8u: goto L_060040E8; case 0x060040EAu: goto L_060040EA; case 0x060040EEu: goto L_060040EE; case 0x060040F0u: goto L_060040F0; case 0x060040F4u: goto L_060040F4; case 0x060040F6u: goto L_060040F6; case 0x060040F8u: goto L_060040F8; case 0x060040FAu: goto L_060040FA; case 0x060040FCu: goto L_060040FC; case 0x06004100u: goto L_06004100; case 0x06004102u: goto L_06004102; case 0x06004104u: goto L_06004104; case 0x06004106u: goto L_06004106; case 0x0600410Au: goto L_0600410A; case 0x0600410Eu: goto L_0600410E; case 0x06004110u: goto L_06004110; case 0x06004114u: goto L_06004114; case 0x06004116u: goto L_06004116; case 0x06004118u: goto L_06004118; case 0x0600411Au: goto L_0600411A; case 0x0600411Cu: goto L_0600411C; case 0x06004120u: goto L_06004120; case 0x06004122u: goto L_06004122; case 0x06004124u: goto L_06004124; case 0x06004126u: goto L_06004126; case 0x06004128u: goto L_06004128; case 0x0600412Au: goto L_0600412A; case 0x0600412Cu: goto L_0600412C; case 0x06004130u: goto L_06004130; case 0x06004132u: goto L_06004132; case 0x06004134u: goto L_06004134; case 0x06004136u: goto L_06004136; case 0x06004138u: goto L_06004138; case 0x0600413Au: goto L_0600413A; case 0x0600413Cu: goto L_0600413C; case 0x0600413Eu: goto L_0600413E; case 0x06004140u: goto L_06004140; case 0x06004142u: goto L_06004142; case 0x06004144u: goto L_06004144; case 0x06004146u: goto L_06004146; case 0x06004148u: goto L_06004148; case 0x0600414Cu: goto L_0600414C; case 0x0600414Eu: goto L_0600414E; case 0x06004152u: goto L_06004152; case 0x06004154u: goto L_06004154; case 0x06004156u: goto L_06004156; case 0x06004158u: goto L_06004158; case 0x0600415Cu: goto L_0600415C; case 0x0600415Eu: goto L_0600415E; case 0x06004162u: goto L_06004162; case 0x06004164u: goto L_06004164; case 0x06004166u: goto L_06004166; case 0x06004168u: goto L_06004168; case 0x0600416Au: goto L_0600416A; case 0x0600416Cu: goto L_0600416C; case 0x0600416Eu: goto L_0600416E; case 0x06004172u: goto L_06004172; case 0x06004174u: goto L_06004174; case 0x06004176u: goto L_06004176; case 0x0600417Au: goto L_0600417A; case 0x0600417Cu: goto L_0600417C; case 0x06004180u: goto L_06004180; case 0x06004182u: goto L_06004182; case 0x06004186u: goto L_06004186; case 0x06004188u: goto L_06004188; case 0x0600418Au: goto L_0600418A; case 0x0600418Cu: goto L_0600418C; case 0x0600418Eu: goto L_0600418E; case 0x06004192u: goto L_06004192; case 0x06004194u: goto L_06004194; case 0x06004198u: goto L_06004198; case 0x0600419Au: goto L_0600419A; case 0x0600419Cu: goto L_0600419C; case 0x0600419Eu: goto L_0600419E; case 0x060041A0u: goto L_060041A0; case 0x060041A2u: goto L_060041A2; case 0x060041A4u: goto L_060041A4; case 0x060041A6u: goto L_060041A6; case 0x060041A8u: goto L_060041A8; case 0x060041AAu: goto L_060041AA; case 0x060041ACu: goto L_060041AC; case 0x060041B0u: goto L_060041B0; case 0x060041B4u: goto L_060041B4; case 0x060041B6u: goto L_060041B6; case 0x060041B8u: goto L_060041B8; case 0x060041BCu: goto L_060041BC; case 0x060041BEu: goto L_060041BE; case 0x06004244u: goto L_06004244; case 0x06004246u: goto L_06004246; case 0x06004248u: goto L_06004248; case 0x0600424Au: goto L_0600424A; case 0x0600424Eu: goto L_0600424E; case 0x06004250u: goto L_06004250; case 0x06004254u: goto L_06004254; case 0x06004256u: goto L_06004256; case 0x06004258u: goto L_06004258; case 0x0600425Au: goto L_0600425A; case 0x0600425Cu: goto L_0600425C; case 0x0600425Eu: goto L_0600425E; case 0x06004260u: goto L_06004260; case 0x06004262u: goto L_06004262; default: sh2_call(c, x); return; } }  // 06004016 jmp @r4 ; ldc r0,gbr
L_06004060:
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06004060 mov.l r8,@-r15
L_06004062:
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06004062 mov.l r9,@-r15
L_06004064:
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06004064 mov.l r10,@-r15
L_06004066:
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06004066 mov.l r11,@-r15
L_06004068:
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06004068 mov.l r12,@-r15
L_0600406A:
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0600406A mov.l r14,@-r15
L_0600406C:
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0600406C sts.l pr,@-r15
L_0600406E:
    c.r[1] = ld32(0x060041C4u);  // 0600406E mov.l 0x060041C4,r1
L_06004070:
    { const uint32_t x = c.r[1]; c.pr = 0x06004074u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004074u) return; }  // 06004070 jsr @r1 ; mov r15,r14
L_06004074:
    c.r[1] = ld32(0x060041C8u);  // 06004074 mov.l 0x060041C8,r1
L_06004076:
    c.r[2] = ld32(0x060041CCu);  // 06004076 mov.l 0x060041CC,r2
L_06004078:
    c.t = c.r[1] >= c.r[2];  // 06004078 cmp/hs r2,r1
L_0600407A:
    { const bool k = c.t; c.r[3] = 0x0u; if (k) { goto L_06004086; } }  // 0600407A bt/s 0x06004086 ; mov #0,r3
L_0600407E:
    st8(c.r[1], c.r[3]);  // 0600407E mov.b r3,@r1
L_06004080:
    c.r[1] += 1;  // 06004080 add #1,r1
L_06004082:
    c.t = c.r[1] >= c.r[2];  // 06004082 cmp/hs r2,r1
L_06004084:
    if (!c.t) { SH2_POLL(c); goto L_0600407E; }  // 06004084 bf 0x0600407E
L_06004086:
    c.r[1] = ld32(0x060041D0u);  // 06004086 mov.l 0x060041D0,r1
L_06004088:
    c.r[8] = 0x0u;  // 06004088 mov #0,r8
L_0600408A:
    c.r[3] = (uint32_t)(int16_t)ld16(0x060041C2u);  // 0600408A mov.w 0x060041C2,r3
L_0600408C:
    c.r[2] = 0x0u;  // 0600408C mov #0,r2
L_0600408E:
    st8(c.r[1], c.r[2]);  // 0600408E mov.b r2,@r1
L_06004090:
    c.r[8] += 1;  // 06004090 add #1,r8
L_06004092:
    c.t = c.r[8] > c.r[3];  // 06004092 cmp/hi r3,r8
L_06004094:
    { const bool k = !c.t; c.r[1] += 1; if (k) { SH2_POLL(c); goto L_0600408E; } }  // 06004094 bf/s 0x0600408E ; add #1,r1
L_06004098:
    c.r[2] = ld32(0x060041D4u);  // 06004098 mov.l 0x060041D4,r2
L_0600409A:
    c.r[1] = 0x0u;  // 0600409A mov #0,r1
L_0600409C:
    st8(c.r[2], c.r[1]);  // 0600409C mov.b r1,@r2
L_0600409E:
    c.r[1] = ld32(0x060041D8u);  // 0600409E mov.l 0x060041D8,r1
L_060040A0:
    c.r[6] = 0xFFFFFFFFu;  // 060040A0 mov #-1,r6
L_060040A2:
    c.r[5] = 0x0u;  // 060040A2 mov #0,r5
L_060040A4:
    { const uint32_t x = c.r[1]; c.pr = 0x060040A8u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060040A8u) return; }  // 060040A4 jsr @r1 ; mov #0,r4
L_060040A8:
    c.r[1] = ld32(0x060041DCu);  // 060040A8 mov.l 0x060041DC,r1
L_060040AA:
    { const uint32_t x = c.r[1]; c.pr = 0x060040AEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060040AEu) return; }  // 060040AA jsr @r1 ; nop
L_060040AE:
    c.r[4] = ld32(0x060041E0u);  // 060040AE mov.l 0x060041E0,r4
L_060040B0:
    c.r[1] = ld32(0x060041E4u);  // 060040B0 mov.l 0x060041E4,r1
L_060040B2:
    { const uint32_t x = c.r[1]; c.pr = 0x060040B6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060040B6u) return; }  // 060040B2 jsr @r1 ; nop
L_060040B6:
    c.r[1] = ld32(0x060041E8u);  // 060040B6 mov.l 0x060041E8,r1
L_060040B8:
    { const uint32_t x = c.r[1]; c.pr = 0x060040BCu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060040BCu) return; }  // 060040B8 jsr @r1 ; nop
L_060040BC:
    c.r[1] = ld32(0x060041ECu);  // 060040BC mov.l 0x060041EC,r1
L_060040BE:
    { const uint32_t x = c.r[1]; c.pr = 0x060040C2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060040C2u) return; }  // 060040BE jsr @r1 ; nop
L_060040C2:
    c.r[0] = ld32(0x060041F0u);  // 060040C2 mov.l 0x060041F0,r0
L_060040C4:
    { const uint32_t x = c.r[0]; c.pr = 0x060040C8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060040C8u) return; }  // 060040C4 jsr @r0 ; nop
L_060040C8:
    c.r[0] &= 0x20u;  // 060040C8 and #32,r0
L_060040CA:
    c.t = (c.r[0] & c.r[0]) == 0;  // 060040CA tst r0,r0
L_060040CC:
    if (c.t) { goto L_060040D4; }  // 060040CC bt 0x060040D4
L_060040CE:
    c.r[1] = ld32(0x060041F4u);  // 060040CE mov.l 0x060041F4,r1
L_060040D0:
    { const uint32_t x = c.r[1]; c.pr = 0x060040D4u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060040D4u) return; }  // 060040D0 jsr @r1 ; mov #1,r4
L_060040D4:
    c.r[8] = ld32(0x060041F8u);  // 060040D4 mov.l 0x060041F8,r8
L_060040D6:
    c.r[7] = ld32(0x060041FCu);  // 060040D6 mov.l 0x060041FC,r7
L_060040D8:
    c.r[6] = ld32(0x06004200u);  // 060040D8 mov.l 0x06004200,r6
L_060040DA:
    c.r[4] = ld32(0x06004204u);  // 060040DA mov.l 0x06004204,r4
L_060040DC:
    { const uint32_t x = c.r[8]; c.pr = 0x060040E0u; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060040E0u) return; }  // 060040DC jsr @r8 ; mov #0,r5
L_060040E0:
    c.t = (int32_t)c.r[0] > 0;  // 060040E0 cmp/pl r0
L_060040E2:
    if (!c.t) { SH2_POLL(c); goto L_060040D6; }  // 060040E2 bf 0x060040D6
L_060040E4:
    c.r[5] = ld32(0x06004208u);  // 060040E4 mov.l 0x06004208,r5
L_060040E6:
    c.r[4] = ld32(0x06004200u);  // 060040E6 mov.l 0x06004200,r4
L_060040E8:
    c.r[0] = ld32(0x0600420Cu);  // 060040E8 mov.l 0x0600420C,r0
L_060040EA:
    { const uint32_t x = c.r[0]; c.pr = 0x060040EEu; c.r[8] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060040EEu) return; }  // 060040EA jsr @r0 ; mov #0,r8
L_060040EE:
    c.r[9] = ld32(0x060041ECu);  // 060040EE mov.l 0x060041EC,r9
L_060040F0:
    { const uint32_t x = c.r[9]; c.pr = 0x060040F4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060040F4u) return; }  // 060040F0 jsr @r9 ; nop
L_060040F4:
    c.r[1] = ld32(0x06004210u);  // 060040F4 mov.l 0x06004210,r1
L_060040F6:
    st8(c.r[1], c.r[8]);  // 060040F6 mov.b r8,@r1
L_060040F8:
    c.r[1] = ld32(0x06004214u);  // 060040F8 mov.l 0x06004214,r1
L_060040FA:
    c.r[5] = 0x0u;  // 060040FA mov #0,r5
L_060040FC:
    { const uint32_t x = c.r[1]; c.pr = 0x06004100u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004100u) return; }  // 060040FC jsr @r1 ; mov #0,r4
L_06004100:
    c.r[1] = ld32(0x06004218u);  // 06004100 mov.l 0x06004218,r1
L_06004102:
    st8(c.r[1], c.r[8]);  // 06004102 mov.b r8,@r1
L_06004104:
    c.r[1] = ld32(0x0600421Cu);  // 06004104 mov.l 0x0600421C,r1
L_06004106:
    { const uint32_t x = c.r[1]; c.pr = 0x0600410Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600410Au) return; }  // 06004106 jsr @r1 ; nop
L_0600410A:
    { const uint32_t x = c.r[9]; c.pr = 0x0600410Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600410Eu) return; }  // 0600410A jsr @r9 ; nop
L_0600410E:
    c.r[0] = ld32(0x060041F0u);  // 0600410E mov.l 0x060041F0,r0
L_06004110:
    { const uint32_t x = c.r[0]; c.pr = 0x06004114u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004114u) return; }  // 06004110 jsr @r0 ; nop
L_06004114:
    c.r[0] &= 0x20u;  // 06004114 and #32,r0
L_06004116:
    c.t = (c.r[0] & c.r[0]) == 0;  // 06004116 tst r0,r0
L_06004118:
    if (c.t) { goto L_06004120; }  // 06004118 bt 0x06004120
L_0600411A:
    c.r[1] = ld32(0x060041F4u);  // 0600411A mov.l 0x060041F4,r1
L_0600411C:
    { const uint32_t x = c.r[1]; c.pr = 0x06004120u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004120u) return; }  // 0600411C jsr @r1 ; mov #1,r4
L_06004120:
    c.r[11] = ld32(0x06004220u);  // 06004120 mov.l 0x06004220,r11
L_06004122:
    c.r[12] = ld32(0x06004224u);  // 06004122 mov.l 0x06004224,r12
L_06004124:
    c.r[1] = ld32(0x06004228u);  // 06004124 mov.l 0x06004228,r1
L_06004126:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06004126 mov.b @r1,r1
L_06004128:
    c.r[1] = c.r[1] & 0xFFu;  // 06004128 extu.b r1,r1
L_0600412A:
    c.t = (c.r[1] & c.r[1]) == 0;  // 0600412A tst r1,r1
L_0600412C:
    { const bool k = c.t; c.r[8] = 0x0u; if (k) { goto L_06004162; } }  // 0600412C bt/s 0x06004162 ; mov #0,r8
L_06004130:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[11]);  // 06004130 mov.b @r11,r1
L_06004132:
    c.r[0] = c.r[1];  // 06004132 mov r1,r0
L_06004134:
    c.r[0] >>= 2;  // 06004134 shlr2 r0
L_06004136:
    c.r[0] >>= 2;  // 06004136 shlr2 r0
L_06004138:
    c.r[0] >>= 2;  // 06004138 shlr2 r0
L_0600413A:
    c.r[0] &= 0x1u;  // 0600413A and #1,r0
L_0600413C:
    c.t = (c.r[0] & c.r[0]) == 0;  // 0600413C tst r0,r0
L_0600413E:
    if (!c.t) { goto L_0600414C; }  // 0600413E bf 0x0600414C
L_06004140:
    c.r[1] = ld32(0x06004210u);  // 06004140 mov.l 0x06004210,r1
L_06004142:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06004142 mov.b @r1,r1
L_06004144:
    c.r[0] = c.r[1] & 0xFFu;  // 06004144 extu.b r1,r0
L_06004146:
    c.t = c.r[0] == 0x1u;  // 06004146 cmp/eq #1,r0
L_06004148:
    { const bool k = c.t; c.r[10] = 0xFu; if (k) { goto L_06004164; } }  // 06004148 bt/s 0x06004164 ; mov #15,r10
L_0600414C:
    c.r[1] = ld32(0x0600422Cu);  // 0600414C mov.l 0x0600422C,r1
L_0600414E:
    { const uint32_t x = c.r[1]; c.pr = 0x06004152u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004152u) return; }  // 0600414E jsr @r1 ; nop
L_06004152:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[11]);  // 06004152 mov.b @r11,r0
L_06004154:
    c.r[0] &= 0x1u;  // 06004154 and #1,r0
L_06004156:
    c.t = (c.r[0] & c.r[0]) == 0;  // 06004156 tst r0,r0
L_06004158:
    { const bool k = c.t; c.r[8] = 0x0u; if (k) { goto L_06004162; } }  // 06004158 bt/s 0x06004162 ; mov #0,r8
L_0600415C:
    c.r[1] = ld32(0x06004230u);  // 0600415C mov.l 0x06004230,r1
L_0600415E:
    { const uint32_t x = c.r[1]; c.pr = 0x06004162u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004162u) return; }  // 0600415E jsr @r1 ; nop
L_06004162:
    c.r[10] = 0xFu;  // 06004162 mov #15,r10
L_06004164:
    c.r[9] = 0x0u;  // 06004164 mov #0,r9
L_06004166:
    c.r[0] = c.r[9];  // 06004166 mov r9,r0
L_06004168:
    c.r[1] = ld32(c.r[0] + c.r[12]);  // 06004168 mov.l @(r0,r12),r1
L_0600416A:
    c.t = (c.r[1] & c.r[1]) == 0;  // 0600416A tst r1,r1
L_0600416C:
    if (c.t) { goto L_06004172; }  // 0600416C bt 0x06004172
L_0600416E:
    { const uint32_t x = c.r[1]; c.pr = 0x06004172u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004172u) return; }  // 0600416E jsr @r1 ; nop
L_06004172:
    c.r[8] += 1;  // 06004172 add #1,r8
L_06004174:
    c.t = c.r[8] > c.r[10];  // 06004174 cmp/hi r10,r8
L_06004176:
    { const bool k = !c.t; c.r[9] += 4; if (k) { SH2_POLL(c); goto L_06004166; } }  // 06004176 bf/s 0x06004166 ; add #4,r9
L_0600417A:
    c.r[1] = ld32(0x06004234u);  // 0600417A mov.l 0x06004234,r1
L_0600417C:
    { const uint32_t x = c.r[1]; c.pr = 0x06004180u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004180u) return; }  // 0600417C jsr @r1 ; nop
L_06004180:
    c.r[0] = ld32(0x060041F0u);  // 06004180 mov.l 0x060041F0,r0
L_06004182:
    { const uint32_t x = c.r[0]; c.pr = 0x06004186u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004186u) return; }  // 06004182 jsr @r0 ; nop
L_06004186:
    c.r[0] &= 0x20u;  // 06004186 and #32,r0
L_06004188:
    c.t = (c.r[0] & c.r[0]) == 0;  // 06004188 tst r0,r0
L_0600418A:
    if (c.t) { goto L_06004192; }  // 0600418A bt 0x06004192
L_0600418C:
    c.r[1] = ld32(0x060041F4u);  // 0600418C mov.l 0x060041F4,r1
L_0600418E:
    { const uint32_t x = c.r[1]; c.pr = 0x06004192u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004192u) return; }  // 0600418E jsr @r1 ; mov #1,r4
L_06004192:
    c.r[1] = ld32(0x060041ECu);  // 06004192 mov.l 0x060041EC,r1
L_06004194:
    { const uint32_t x = c.r[1]; c.pr = 0x06004198u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004198u) return; }  // 06004194 jsr @r1 ; nop
L_06004198:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[11]);  // 06004198 mov.b @r11,r1
L_0600419A:
    c.r[2] = c.r[1] & 0xFFu;  // 0600419A extu.b r1,r2
L_0600419C:
    c.r[1] = ld32(0x06004238u);  // 0600419C mov.l 0x06004238,r1
L_0600419E:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0600419E mov.b @r1,r1
L_060041A0:
    c.r[2] >>= 2;  // 060041A0 shlr2 r2
L_060041A2:
    c.r[2] >>= 2;  // 060041A2 shlr2 r2
L_060041A4:
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 060041A4 shlr r2
L_060041A6:
    c.r[2] >>= 2;  // 060041A6 shlr2 r2
L_060041A8:
    c.r[1] = c.r[1] & 0xFFu;  // 060041A8 extu.b r1,r1
L_060041AA:
    c.t = c.r[2] == c.r[1];  // 060041AA cmp/eq r1,r2
L_060041AC:
    { const bool k = c.t; c.t = (c.r[2] & c.r[2]) == 0; if (k) { goto L_06004254; } }  // 060041AC bt/s 0x06004254 ; tst r2,r2
L_060041B0:
    { const bool k = c.t; c.r[6] = 0x0u; if (k) { goto L_06004244; } }  // 060041B0 bt/s 0x06004244 ; mov #0,r6
L_060041B4:
    c.r[1] = ld32(0x0600423Cu);  // 060041B4 mov.l 0x0600423C,r1
L_060041B6:
    c.r[5] = 0x0u;  // 060041B6 mov #0,r5
L_060041B8:
    { const uint32_t x = c.r[1]; c.pr = 0x060041BCu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060041BCu) return; }  // 060041B8 jsr @r1 ; mov #0,r4
L_060041BC:
    c.r[1] = ld32(0x06004240u);  // 060041BC mov.l 0x06004240,r1
L_060041BE:
    goto L_06004250;  // 060041BE bra 0x06004250 ; nop
L_06004244:
    c.r[4] = (uint32_t)(int16_t)ld16(0x06004266u);  // 06004244 mov.w 0x06004266,r4
L_06004246:
    c.r[1] = ld32(0x06004268u);  // 06004246 mov.l 0x06004268,r1
L_06004248:
    c.r[6] = c.r[4];  // 06004248 mov r4,r6
L_0600424A:
    { const uint32_t x = c.r[1]; c.pr = 0x0600424Eu; c.r[5] = c.r[4]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600424Eu) return; }  // 0600424A jsr @r1 ; mov r4,r5
L_0600424E:
    c.r[1] = ld32(0x0600426Cu);  // 0600424E mov.l 0x0600426C,r1
L_06004250:
    { const uint32_t x = c.r[1]; c.pr = 0x06004254u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004254u) return; }  // 06004250 jsr @r1 ; nop
L_06004254:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[11]);  // 06004254 mov.b @r11,r1
L_06004256:
    c.r[2] = ld32(0x06004270u);  // 06004256 mov.l 0x06004270,r2
L_06004258:
    c.r[1] = c.r[1] & 0xFFu;  // 06004258 extu.b r1,r1
L_0600425A:
    c.r[1] >>= 2;  // 0600425A shlr2 r1
L_0600425C:
    c.r[1] >>= 2;  // 0600425C shlr2 r1
L_0600425E:
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0600425E shlr r1
L_06004260:
    c.r[1] >>= 2;  // 06004260 shlr2 r1
L_06004262:
    st8(c.r[2], c.r[1]); SH2_POLL(c); goto L_06004124;  // 06004262 bra 0x06004124 ; mov.b r1,@r2
}

void f_06004060(SH2Context& c) {
    ran[1] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06004060 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06004062 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06004064 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06004066 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06004068 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0600406A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0600406C sts.l pr,@-r15
    c.r[1] = ld32(0x060041C4u);  // 0600406E mov.l 0x060041C4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06004074u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004074u) return; }  // 06004070 jsr @r1 ; mov r15,r14
    c.r[1] = ld32(0x060041C8u);  // 06004074 mov.l 0x060041C8,r1
    c.r[2] = ld32(0x060041CCu);  // 06004076 mov.l 0x060041CC,r2
    c.t = c.r[1] >= c.r[2];  // 06004078 cmp/hs r2,r1
    { const bool k = c.t; c.r[3] = 0x0u; if (k) { goto L_06004086; } }  // 0600407A bt/s 0x06004086 ; mov #0,r3
L_0600407E:
    st8(c.r[1], c.r[3]);  // 0600407E mov.b r3,@r1
    c.r[1] += 1;  // 06004080 add #1,r1
    c.t = c.r[1] >= c.r[2];  // 06004082 cmp/hs r2,r1
    if (!c.t) { SH2_POLL(c); goto L_0600407E; }  // 06004084 bf 0x0600407E
L_06004086:
    c.r[1] = ld32(0x060041D0u);  // 06004086 mov.l 0x060041D0,r1
    c.r[8] = 0x0u;  // 06004088 mov #0,r8
    c.r[3] = (uint32_t)(int16_t)ld16(0x060041C2u);  // 0600408A mov.w 0x060041C2,r3
    c.r[2] = 0x0u;  // 0600408C mov #0,r2
L_0600408E:
    st8(c.r[1], c.r[2]);  // 0600408E mov.b r2,@r1
    c.r[8] += 1;  // 06004090 add #1,r8
    c.t = c.r[8] > c.r[3];  // 06004092 cmp/hi r3,r8
    { const bool k = !c.t; c.r[1] += 1; if (k) { SH2_POLL(c); goto L_0600408E; } }  // 06004094 bf/s 0x0600408E ; add #1,r1
    c.r[2] = ld32(0x060041D4u);  // 06004098 mov.l 0x060041D4,r2
    c.r[1] = 0x0u;  // 0600409A mov #0,r1
    st8(c.r[2], c.r[1]);  // 0600409C mov.b r1,@r2
    c.r[1] = ld32(0x060041D8u);  // 0600409E mov.l 0x060041D8,r1
    c.r[6] = 0xFFFFFFFFu;  // 060040A0 mov #-1,r6
    c.r[5] = 0x0u;  // 060040A2 mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x060040A8u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060040A8u) return; }  // 060040A4 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x060041DCu);  // 060040A8 mov.l 0x060041DC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060040AEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060040AEu) return; }  // 060040AA jsr @r1 ; nop
    c.r[4] = ld32(0x060041E0u);  // 060040AE mov.l 0x060041E0,r4
    c.r[1] = ld32(0x060041E4u);  // 060040B0 mov.l 0x060041E4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060040B6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060040B6u) return; }  // 060040B2 jsr @r1 ; nop
    c.r[1] = ld32(0x060041E8u);  // 060040B6 mov.l 0x060041E8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060040BCu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060040BCu) return; }  // 060040B8 jsr @r1 ; nop
    c.r[1] = ld32(0x060041ECu);  // 060040BC mov.l 0x060041EC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060040C2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060040C2u) return; }  // 060040BE jsr @r1 ; nop
    c.r[0] = ld32(0x060041F0u);  // 060040C2 mov.l 0x060041F0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060040C8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060040C8u) return; }  // 060040C4 jsr @r0 ; nop
    c.r[0] &= 0x20u;  // 060040C8 and #32,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 060040CA tst r0,r0
    if (c.t) { goto L_060040D4; }  // 060040CC bt 0x060040D4
    c.r[1] = ld32(0x060041F4u);  // 060040CE mov.l 0x060041F4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060040D4u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060040D4u) return; }  // 060040D0 jsr @r1 ; mov #1,r4
L_060040D4:
    c.r[8] = ld32(0x060041F8u);  // 060040D4 mov.l 0x060041F8,r8
L_060040D6:
    c.r[7] = ld32(0x060041FCu);  // 060040D6 mov.l 0x060041FC,r7
    c.r[6] = ld32(0x06004200u);  // 060040D8 mov.l 0x06004200,r6
    c.r[4] = ld32(0x06004204u);  // 060040DA mov.l 0x06004204,r4
    { const uint32_t x = c.r[8]; c.pr = 0x060040E0u; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060040E0u) return; }  // 060040DC jsr @r8 ; mov #0,r5
    c.t = (int32_t)c.r[0] > 0;  // 060040E0 cmp/pl r0
    if (!c.t) { SH2_POLL(c); goto L_060040D6; }  // 060040E2 bf 0x060040D6
    c.r[5] = ld32(0x06004208u);  // 060040E4 mov.l 0x06004208,r5
    c.r[4] = ld32(0x06004200u);  // 060040E6 mov.l 0x06004200,r4
    c.r[0] = ld32(0x0600420Cu);  // 060040E8 mov.l 0x0600420C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060040EEu; c.r[8] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060040EEu) return; }  // 060040EA jsr @r0 ; mov #0,r8
    c.r[9] = ld32(0x060041ECu);  // 060040EE mov.l 0x060041EC,r9
    { const uint32_t x = c.r[9]; c.pr = 0x060040F4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060040F4u) return; }  // 060040F0 jsr @r9 ; nop
    c.r[1] = ld32(0x06004210u);  // 060040F4 mov.l 0x06004210,r1
    st8(c.r[1], c.r[8]);  // 060040F6 mov.b r8,@r1
    c.r[1] = ld32(0x06004214u);  // 060040F8 mov.l 0x06004214,r1
    c.r[5] = 0x0u;  // 060040FA mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06004100u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004100u) return; }  // 060040FC jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06004218u);  // 06004100 mov.l 0x06004218,r1
    st8(c.r[1], c.r[8]);  // 06004102 mov.b r8,@r1
    c.r[1] = ld32(0x0600421Cu);  // 06004104 mov.l 0x0600421C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0600410Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600410Au) return; }  // 06004106 jsr @r1 ; nop
    { const uint32_t x = c.r[9]; c.pr = 0x0600410Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600410Eu) return; }  // 0600410A jsr @r9 ; nop
    c.r[0] = ld32(0x060041F0u);  // 0600410E mov.l 0x060041F0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06004114u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004114u) return; }  // 06004110 jsr @r0 ; nop
    c.r[0] &= 0x20u;  // 06004114 and #32,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06004116 tst r0,r0
    if (c.t) { goto L_06004120; }  // 06004118 bt 0x06004120
    c.r[1] = ld32(0x060041F4u);  // 0600411A mov.l 0x060041F4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06004120u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004120u) return; }  // 0600411C jsr @r1 ; mov #1,r4
L_06004120:
    c.r[11] = ld32(0x06004220u);  // 06004120 mov.l 0x06004220,r11
    c.r[12] = ld32(0x06004224u);  // 06004122 mov.l 0x06004224,r12
L_06004124:
    c.r[1] = ld32(0x06004228u);  // 06004124 mov.l 0x06004228,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06004126 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06004128 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0600412A tst r1,r1
    { const bool k = c.t; c.r[8] = 0x0u; if (k) { goto L_06004162; } }  // 0600412C bt/s 0x06004162 ; mov #0,r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[11]);  // 06004130 mov.b @r11,r1
    c.r[0] = c.r[1];  // 06004132 mov r1,r0
    c.r[0] >>= 2;  // 06004134 shlr2 r0
    c.r[0] >>= 2;  // 06004136 shlr2 r0
    c.r[0] >>= 2;  // 06004138 shlr2 r0
    c.r[0] &= 0x1u;  // 0600413A and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0600413C tst r0,r0
    if (!c.t) { goto L_0600414C; }  // 0600413E bf 0x0600414C
    c.r[1] = ld32(0x06004210u);  // 06004140 mov.l 0x06004210,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06004142 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06004144 extu.b r1,r0
    c.t = c.r[0] == 0x1u;  // 06004146 cmp/eq #1,r0
    { const bool k = c.t; c.r[10] = 0xFu; if (k) { goto L_06004164; } }  // 06004148 bt/s 0x06004164 ; mov #15,r10
L_0600414C:
    c.r[1] = ld32(0x0600422Cu);  // 0600414C mov.l 0x0600422C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06004152u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004152u) return; }  // 0600414E jsr @r1 ; nop
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[11]);  // 06004152 mov.b @r11,r0
    c.r[0] &= 0x1u;  // 06004154 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06004156 tst r0,r0
    { const bool k = c.t; c.r[8] = 0x0u; if (k) { goto L_06004162; } }  // 06004158 bt/s 0x06004162 ; mov #0,r8
    c.r[1] = ld32(0x06004230u);  // 0600415C mov.l 0x06004230,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06004162u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004162u) return; }  // 0600415E jsr @r1 ; nop
L_06004162:
    c.r[10] = 0xFu;  // 06004162 mov #15,r10
L_06004164:
    c.r[9] = 0x0u;  // 06004164 mov #0,r9
L_06004166:
    c.r[0] = c.r[9];  // 06004166 mov r9,r0
    c.r[1] = ld32(c.r[0] + c.r[12]);  // 06004168 mov.l @(r0,r12),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0600416A tst r1,r1
    if (c.t) { goto L_06004172; }  // 0600416C bt 0x06004172
    { const uint32_t x = c.r[1]; c.pr = 0x06004172u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004172u) return; }  // 0600416E jsr @r1 ; nop
L_06004172:
    c.r[8] += 1;  // 06004172 add #1,r8
    c.t = c.r[8] > c.r[10];  // 06004174 cmp/hi r10,r8
    { const bool k = !c.t; c.r[9] += 4; if (k) { SH2_POLL(c); goto L_06004166; } }  // 06004176 bf/s 0x06004166 ; add #4,r9
    c.r[1] = ld32(0x06004234u);  // 0600417A mov.l 0x06004234,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06004180u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004180u) return; }  // 0600417C jsr @r1 ; nop
    c.r[0] = ld32(0x060041F0u);  // 06004180 mov.l 0x060041F0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06004186u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004186u) return; }  // 06004182 jsr @r0 ; nop
    c.r[0] &= 0x20u;  // 06004186 and #32,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06004188 tst r0,r0
    if (c.t) { goto L_06004192; }  // 0600418A bt 0x06004192
    c.r[1] = ld32(0x060041F4u);  // 0600418C mov.l 0x060041F4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06004192u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004192u) return; }  // 0600418E jsr @r1 ; mov #1,r4
L_06004192:
    c.r[1] = ld32(0x060041ECu);  // 06004192 mov.l 0x060041EC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06004198u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004198u) return; }  // 06004194 jsr @r1 ; nop
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[11]);  // 06004198 mov.b @r11,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0600419A extu.b r1,r2
    c.r[1] = ld32(0x06004238u);  // 0600419C mov.l 0x06004238,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0600419E mov.b @r1,r1
    c.r[2] >>= 2;  // 060041A0 shlr2 r2
    c.r[2] >>= 2;  // 060041A2 shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 060041A4 shlr r2
    c.r[2] >>= 2;  // 060041A6 shlr2 r2
    c.r[1] = c.r[1] & 0xFFu;  // 060041A8 extu.b r1,r1
    c.t = c.r[2] == c.r[1];  // 060041AA cmp/eq r1,r2
    { const bool k = c.t; c.t = (c.r[2] & c.r[2]) == 0; if (k) { goto L_06004254; } }  // 060041AC bt/s 0x06004254 ; tst r2,r2
    { const bool k = c.t; c.r[6] = 0x0u; if (k) { goto L_06004244; } }  // 060041B0 bt/s 0x06004244 ; mov #0,r6
    c.r[1] = ld32(0x0600423Cu);  // 060041B4 mov.l 0x0600423C,r1
    c.r[5] = 0x0u;  // 060041B6 mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x060041BCu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060041BCu) return; }  // 060041B8 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06004240u);  // 060041BC mov.l 0x06004240,r1
    goto L_06004250;  // 060041BE bra 0x06004250 ; nop
L_06004244:
    c.r[4] = (uint32_t)(int16_t)ld16(0x06004266u);  // 06004244 mov.w 0x06004266,r4
    c.r[1] = ld32(0x06004268u);  // 06004246 mov.l 0x06004268,r1
    c.r[6] = c.r[4];  // 06004248 mov r4,r6
    { const uint32_t x = c.r[1]; c.pr = 0x0600424Eu; c.r[5] = c.r[4]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600424Eu) return; }  // 0600424A jsr @r1 ; mov r4,r5
    c.r[1] = ld32(0x0600426Cu);  // 0600424E mov.l 0x0600426C,r1
L_06004250:
    { const uint32_t x = c.r[1]; c.pr = 0x06004254u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004254u) return; }  // 06004250 jsr @r1 ; nop
L_06004254:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[11]);  // 06004254 mov.b @r11,r1
    c.r[2] = ld32(0x06004270u);  // 06004256 mov.l 0x06004270,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06004258 extu.b r1,r1
    c.r[1] >>= 2;  // 0600425A shlr2 r1
    c.r[1] >>= 2;  // 0600425C shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 0600425E shlr r1
    c.r[1] >>= 2;  // 06004260 shlr2 r1
    st8(c.r[2], c.r[1]); SH2_POLL(c); goto L_06004124;  // 06004262 bra 0x06004124 ; mov.b r1,@r2
}

void f_06004274(SH2Context& c) {
    ran[2] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06004274 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06004276 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06004278 sts.l pr,@-r15
    c.r[1] = ld32(0x0600434Cu);  // 0600427A mov.l 0x0600434C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06004280u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004280u) return; }  // 0600427C jsr @r1 ; mov r15,r14
    c.r[0] = ld32(0x06004350u);  // 06004280 mov.l 0x06004350,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06004286u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004286u) return; }  // 06004282 jsr @r0 ; nop
    c.r[1] = ld32(0x06004354u);  // 06004286 mov.l 0x06004354,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0600428Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600428Cu) return; }  // 06004288 jsr @r1 ; nop
    c.r[0] = ld32(0x06004358u);  // 0600428C mov.l 0x06004358,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06004292u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004292u) return; }  // 0600428E jsr @r0 ; nop
    c.r[0] &= 0x20u;  // 06004292 and #32,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06004294 tst r0,r0
    if (c.t) { goto L_0600429E; }  // 06004296 bt 0x0600429E
    c.r[1] = ld32(0x0600435Cu);  // 06004298 mov.l 0x0600435C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0600429Eu; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600429Eu) return; }  // 0600429A jsr @r1 ; mov #1,r4
L_0600429E:
    c.r[1] = ld32(0x06004360u);  // 0600429E mov.l 0x06004360,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060042A4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060042A4u) return; }  // 060042A0 jsr @r1 ; nop
    c.r[1] = ld32(0x06004364u);  // 060042A4 mov.l 0x06004364,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060042AAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060042AAu) return; }  // 060042A6 jsr @r1 ; nop
    c.r[1] = ld32(0x06004368u);  // 060042AA mov.l 0x06004368,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060042B0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060042B0u) return; }  // 060042AC jsr @r1 ; nop
    c.r[1] = ld32(0x0600436Cu);  // 060042B0 mov.l 0x0600436C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060042B6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060042B6u) return; }  // 060042B2 jsr @r1 ; nop
    c.r[6] = ld32(0x06004370u);  // 060042B6 mov.l 0x06004370,r6
    c.r[8] = ld32(0x06004374u);  // 060042B8 mov.l 0x06004374,r8
    c.r[5] = 0x1u;  // 060042BA mov #1,r5
    { const uint32_t x = c.r[8]; c.pr = 0x060042C0u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060042C0u) return; }  // 060042BC jsr @r8 ; mov #0,r4
    c.r[6] = ld32(0x06004378u);  // 060042C0 mov.l 0x06004378,r6
    c.r[5] = 0x3u;  // 060042C2 mov #3,r5
    { const uint32_t x = c.r[8]; c.pr = 0x060042C8u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060042C8u) return; }  // 060042C4 jsr @r8 ; mov #0,r4
    c.r[6] = ld32(0x0600437Cu);  // 060042C8 mov.l 0x0600437C,r6
    c.r[5] = 0x4u;  // 060042CA mov #4,r5
    { const uint32_t x = c.r[8]; c.pr = 0x060042D0u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060042D0u) return; }  // 060042CC jsr @r8 ; mov #0,r4
    c.r[6] = ld32(0x06004380u);  // 060042D0 mov.l 0x06004380,r6
    c.r[5] = 0x5u;  // 060042D2 mov #5,r5
    { const uint32_t x = c.r[8]; c.pr = 0x060042D8u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060042D8u) return; }  // 060042D4 jsr @r8 ; mov #0,r4
    c.r[3] = ld32(0x06004384u);  // 060042D8 mov.l 0x06004384,r3
    c.r[6] = 0x1u;  // 060042DA mov #1,r6
    c.r[1] = c.r[3];  // 060042DC mov r3,r1
    c.r[1] += 1;  // 060042DE add #1,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060042E0 mov.b @r3,r0
    c.r[7] = 0x0u;  // 060042E2 mov #0,r7
    c.r[6] &= c.r[0];  // 060042E4 and r0,r6
    st8(c.r[3], c.r[6]);  // 060042E6 mov.b r6,@r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060042E8 mov.b @r1,r0
    c.r[2] = ld32(0x06004388u);  // 060042EA mov.l 0x06004388,r2
    c.r[0] &= 0x7Fu;  // 060042EC and #127,r0
    st8(c.r[1], c.r[0]);  // 060042EE mov.b r0,@r1
    c.r[1] = ld32(0x0600438Cu);  // 060042F0 mov.l 0x0600438C,r1
    st8(c.r[1], c.r[7]);  // 060042F2 mov.b r7,@r1
    c.r[1] = ld32(0x06004390u);  // 060042F4 mov.l 0x06004390,r1
    st8(c.r[1], c.r[7]);  // 060042F6 mov.b r7,@r1
    c.r[1] = ld32(0x06004394u);  // 060042F8 mov.l 0x06004394,r1
    st8(c.r[1], c.r[7]);  // 060042FA mov.b r7,@r1
    c.r[1] = ld32(0x06004398u);  // 060042FC mov.l 0x06004398,r1
    st8(c.r[1], c.r[7]);  // 060042FE mov.b r7,@r1
    c.r[1] = 0x0u;  // 06004300 mov #0,r1
    st32(c.r[2], c.r[1]);  // 06004302 mov.l r1,@r2
    st8(c.r[3], c.r[6]);  // 06004304 mov.b r6,@r3
    c.r[1] = ld32(0x0600439Cu);  // 06004306 mov.l 0x0600439C,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06004308 mov.b @r1,r0
    c.r[0] &= 0x7Fu;  // 0600430A and #127,r0
    st8(c.r[1], c.r[0]);  // 0600430C mov.b r0,@r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0600430E mov.b @r1,r0
    c.r[0] &= 0xDFu;  // 06004310 and #223,r0
    st8(c.r[1], c.r[0]);  // 06004312 mov.b r0,@r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06004314 mov.b @r1,r0
    c.r[3] = ld32(0x060043A0u);  // 06004316 mov.l 0x060043A0,r3
    c.r[0] &= 0xEFu;  // 06004318 and #239,r0
    st8(c.r[1], c.r[0]);  // 0600431A mov.b r0,@r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0600431C mov.b @r3,r0
    c.r[15] = c.r[14];  // 0600431E mov r14,r15
    c.r[0] &= 0x7u;  // 06004320 and #7,r0
    st8(c.r[3], c.r[0]);  // 06004322 mov.b r0,@r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06004324 mov.w @r3,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06004348u);  // 06004326 mov.w 0x06004348,r2
    c.r[1] &= c.r[2];  // 06004328 and r2,r1
    st16(c.r[3], c.r[1]);  // 0600432A mov.w r1,@r3
    c.r[1] = ld32(0x060043A4u);  // 0600432C mov.l 0x060043A4,r1
    c.r[2] = 0x0u;  // 0600432E mov #0,r2
    st16(c.r[1], c.r[2]);  // 06004330 mov.w r2,@r1
    c.r[1] = ld32(0x060043A8u);  // 06004332 mov.l 0x060043A8,r1
    st8(c.r[1], c.r[7]);  // 06004334 mov.b r7,@r1
    c.r[1] = ld32(0x060043ACu);  // 06004336 mov.l 0x060043AC,r1
    st16(c.r[1], c.r[2]);  // 06004338 mov.w r2,@r1
    c.r[2] = ld32(0x060043B0u);  // 0600433A mov.l 0x060043B0,r2
    c.r[1] = ld32(0x060043B4u);  // 0600433C mov.l 0x060043B4,r1
    st32(c.r[2], c.r[1]);  // 0600433E mov.l r1,@r2
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06004340 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06004342 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06004344 rts ; mov.l @r15+,r8
}

void f_060043B8(SH2Context& c) {
    ran[3] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060043B8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060043BA sts.l pr,@-r15
    c.r[1] = ld32(0x06004404u);  // 060043BC mov.l 0x06004404,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060043C2u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060043C2u) return; }  // 060043BE jsr @r1 ; mov r15,r14
    c.r[1] = ld32(0x06004408u);  // 060043C2 mov.l 0x06004408,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060043C8u; c.r[4] = 0x3u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060043C8u) return; }  // 060043C4 jsr @r1 ; mov #3,r4
    c.r[1] = ld32(0x0600440Cu);  // 060043C8 mov.l 0x0600440C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060043CEu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060043CEu) return; }  // 060043CA jsr @r1 ; mov #0,r4
    c.r[4] = ld32(0x06004410u);  // 060043CE mov.l 0x06004410,r4
    c.r[1] = ld32(0x06004414u);  // 060043D0 mov.l 0x06004414,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060043D6u; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060043D6u) return; }  // 060043D2 jsr @r1 ; mov #0,r5
    c.r[1] = ld32(0x06004418u);  // 060043D6 mov.l 0x06004418,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060043DCu; c.r[4] = 0x5Fu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060043DCu) return; }  // 060043D8 jsr @r1 ; mov #95,r4
    c.r[1] = ld32(0x0600441Cu);  // 060043DC mov.l 0x0600441C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060043E2u; c.r[4] = 0x8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060043E2u) return; }  // 060043DE jsr @r1 ; mov #8,r4
    c.r[1] = ld32(0x06004420u);  // 060043E2 mov.l 0x06004420,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060043E8u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060043E8u) return; }  // 060043E4 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06004424u);  // 060043E8 mov.l 0x06004424,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060043EEu; c.r[4] = 0x6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060043EEu) return; }  // 060043EA jsr @r1 ; mov #6,r4
    c.r[2] = ld32(0x06004428u);  // 060043EE mov.l 0x06004428,r2
    c.r[1] = 0x0u;  // 060043F0 mov #0,r1
    st32(c.r[2], c.r[1]);  // 060043F2 mov.l r1,@r2
    c.r[2] = ld32(0x0600442Cu);  // 060043F4 mov.l 0x0600442C,r2
    c.r[1] = 0x1u;  // 060043F6 mov #1,r1
    st8(c.r[2], c.r[1]);  // 060043F8 mov.b r1,@r2
    c.r[15] = c.r[14];  // 060043FA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060043FC lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060043FE rts ; mov.l @r15+,r14
}

void f_06004430(SH2Context& c) {
    ran[4] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06004430 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06004432 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06004434 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06004436 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06004438 sts.l pr,@-r15
    c.r[1] = ld32(0x0600448Cu);  // 0600443A mov.l 0x0600448C,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0600443C mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0600443E extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06004440 tst r1,r1
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0600444C; } }  // 06004442 bt/s 0x0600444C ; mov r15,r14
    c.r[1] = ld32(0x06004490u);  // 06004446 mov.l 0x06004490,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0600444Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600444Cu) return; }  // 06004448 jsr @r1 ; nop
L_0600444C:
    c.r[3] = ld32(0x06004494u);  // 0600444C mov.l 0x06004494,r3
    c.r[2] = ld32(c.r[3]);  // 0600444E mov.l @r3,r2
    c.r[1] = 0xFFFFFFFDu;  // 06004450 mov #-3,r1
    c.t = c.r[2] > c.r[1];  // 06004452 cmp/hi r1,r2
    { const bool k = !c.t; c.r[1] = 0x0u; if (k) { goto L_0600445A; } }  // 06004454 bf/s 0x0600445A ; mov #0,r1
    st32(c.r[3], c.r[1]);  // 06004458 mov.l r1,@r3
L_0600445A:
    c.r[10] = ld32(0x06004498u);  // 0600445A mov.l 0x06004498,r10
    c.r[8] = 0x0u;  // 0600445C mov #0,r8
    c.r[1] = ld32(c.r[3]);  // 0600445E mov.l @r3,r1
    c.r[9] = 0x3Cu;  // 06004460 mov #60,r9
    c.r[1] += 1;  // 06004462 add #1,r1
    st32(c.r[3], c.r[1]);  // 06004464 mov.l r1,@r3
    c.r[1] = ld32(c.r[3]);  // 06004466 mov.l @r3,r1
    c.r[0] = c.r[8];  // 06004468 mov r8,r0
L_0600446A:
    c.r[1] = ld32(c.r[0] + c.r[10]);  // 0600446A mov.l @(r0,r10),r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0600446C tst r1,r1
    if (c.t) { goto L_06004474; }  // 0600446E bt 0x06004474
    { const uint32_t x = c.r[1]; c.pr = 0x06004474u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004474u) return; }  // 06004470 jsr @r1 ; nop
L_06004474:
    c.r[8] += 4;  // 06004474 add #4,r8
    c.t = (int32_t)c.r[8] > (int32_t)c.r[9];  // 06004476 cmp/gt r9,r8
    { const bool k = !c.t; c.r[0] = c.r[8]; if (k) { SH2_POLL(c); goto L_0600446A; } }  // 06004478 bf/s 0x0600446A ; mov r8,r0
    c.r[15] = c.r[14];  // 0600447C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0600447E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06004480 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06004482 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06004484 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06004486 rts ; mov.l @r15+,r8
}

void f_0600449C(SH2Context& c) {
    ran[5] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0600449C mov.l r14,@-r15
    c.r[15] -= 4;  // 0600449E add #-4,r15
    c.r[14] = c.r[15];  // 060044A0 mov r15,r14
    c.r[5] = c.r[5] & 0xFFFFu;  // 060044A2 extu.w r5,r5
    c.r[3] = c.r[6] & 0xFFFFu;  // 060044A4 extu.w r6,r3
    c.r[0] = c.r[3];  // 060044A6 mov r3,r0
    c.t = c.r[0] == 0x2u;  // 060044A8 cmp/eq #2,r0
    { const bool k = c.t; c.r[2] = c.r[3]; if (k) { goto L_060044D2; } }  // 060044AA bt/s 0x060044D2 ; mov r3,r2
    c.r[1] = 0x2u;  // 060044AE mov #2,r1
    c.t = (int32_t)c.r[3] > (int32_t)c.r[1];  // 060044B0 cmp/gt r1,r3
    { const bool k = c.t; c.t = c.r[0] == 0x1u; if (k) { goto L_060044BE; } }  // 060044B2 bt/s 0x060044BE ; cmp/eq #1,r0
    if (c.t) { goto L_060044CA; }  // 060044B6 bt 0x060044CA
    c.r[7] = 0x0u;  // 060044B8 mov #0,r7
    c.r[14] += 4; goto L_06004534;  // 060044BA bra 0x06004534 ; add #4,r14
L_060044BE:
    c.r[0] = c.r[2];  // 060044BE mov r2,r0
    c.t = c.r[0] == 0x4u;  // 060044C0 cmp/eq #4,r0
    { const bool k = c.t; c.r[0] = c.r[5]; if (k) { goto L_060044EE; } }  // 060044C2 bt/s 0x060044EE ; mov r5,r0
    c.r[7] = 0x0u; goto L_06004532;  // 060044C6 bra 0x06004532 ; mov #0,r7
L_060044CA:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[4]);  // 060044CA mov.b @r4,r1
    c.r[7] = c.r[1] & 0xFFu;  // 060044CC extu.b r1,r7
    c.r[7] += c.r[5]; goto L_06004532;  // 060044CE bra 0x06004532 ; add r5,r7
L_060044D2:
    c.r[0] = c.r[5];  // 060044D2 mov r5,r0
    c.r[0] += c.r[0];  // 060044D4 add r0,r0
    c.r[1] = c.r[0];  // 060044D6 mov r0,r1
    c.r[1] += c.r[4];  // 060044D8 add r4,r1
    c.r[2] = c.r[14];  // 060044DA mov r14,r2
    c.r[2] += 1;  // 060044DC add #1,r2
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[4]);  // 060044DE mov.b @(r0,r4),r3
    c.r[1] += 1;  // 060044E0 add #1,r1
    st8(c.r[14], c.r[3]);  // 060044E2 mov.b r3,@r14
    c.r[7] = c.r[3] & 0xFFu;  // 060044E4 extu.b r3,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060044E6 mov.b @r1,r1
    c.r[7] <<= 8;  // 060044E8 shll8 r7
    st8(c.r[2], c.r[1]); goto L_0600452C;  // 060044EA bra 0x0600452C ; mov.b r1,@r2
L_060044EE:
    c.r[0] <<= 2;  // 060044EE shll2 r0
    c.r[6] = c.r[0];  // 060044F0 mov r0,r6
    c.r[6] += c.r[4];  // 060044F2 add r4,r6
    c.r[2] = c.r[14];  // 060044F4 mov r14,r2
    c.r[2] += 1;  // 060044F6 add #1,r2
    c.r[1] = c.r[6];  // 060044F8 mov r6,r1
    c.r[1] += 1;  // 060044FA add #1,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[4]);  // 060044FC mov.b @(r0,r4),r5
    c.r[7] = c.r[14];  // 060044FE mov r14,r7
    st8(c.r[14], c.r[5]);  // 06004500 mov.b r5,@r14
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06004502 mov.b @r1,r3
    c.r[7] += 2;  // 06004504 add #2,r7
    st8(c.r[2], c.r[3]);  // 06004506 mov.b r3,@r2
    c.r[1] = c.r[6];  // 06004508 mov r6,r1
    c.r[1] += 2;  // 0600450A add #2,r1
    c.r[6] += 3;  // 0600450C add #3,r6
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0600450E mov.b @r1,r2
    c.r[3] = c.r[3] & 0xFFu;  // 06004510 extu.b r3,r3
    st8(c.r[7], c.r[2]);  // 06004512 mov.b r2,@r7
    c.r[7] = c.r[14];  // 06004514 mov r14,r7
    c.r[7] += 3;  // 06004516 add #3,r7
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 06004518 mov.b @r6,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0600451A extu.b r2,r2
    st8(c.r[7], c.r[1]);  // 0600451C mov.b r1,@r7
    c.r[7] = c.r[5];  // 0600451E mov r5,r7
    c.r[7] <<= 16;  // 06004520 shll16 r7
    c.r[7] <<= 8;  // 06004522 shll8 r7
    c.r[3] <<= 16;  // 06004524 shll16 r3
    c.r[7] |= c.r[3];  // 06004526 or r3,r7
    c.r[2] <<= 8;  // 06004528 shll8 r2
    c.r[7] |= c.r[2];  // 0600452A or r2,r7
L_0600452C:
    c.r[1] = c.r[1] & 0xFFu;  // 0600452C extu.b r1,r1
    c.r[7] |= c.r[1];  // 0600452E or r1,r7
    c.r[7] += c.r[4];  // 06004530 add r4,r7
L_06004532:
    c.r[14] += 4;  // 06004532 add #4,r14
L_06004534:
    c.r[15] = c.r[14];  // 06004534 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06004536 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = c.r[7]; c.pc = x; return; }  // 06004538 rts ; mov r7,r0
}

void f_0600453C(SH2Context& c) {
    ran[6] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0600453C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0600453E sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06004540 mov r15,r14
    c.r[7] = c.r[5];  // 06004542 mov r5,r7
    c.r[1] = ld32(0x06004554u);  // 06004544 mov.l 0x06004554,r1
    c.r[6] = 0x4u;  // 06004546 mov #4,r6
    { const uint32_t x = c.r[1]; c.pr = 0x0600454Cu; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600454Cu) return; }  // 06004548 jsr @r1 ; mov #0,r5
    c.r[15] = c.r[14];  // 0600454C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0600454E lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06004550 rts ; mov.l @r15+,r14
}

void f_06004558(SH2Context& c) {
    ran[7] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06004558 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0600455A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0600455C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0600455E sts.l pr,@-r15
    c.r[15] -= 4;  // 06004560 add #-4,r15
    c.r[14] = c.r[15];  // 06004562 mov r15,r14
    c.r[9] = c.r[4];  // 06004564 mov r4,r9
    c.r[0] = c.r[6] & 0xFFu;  // 06004566 extu.b r6,r0
    c.t = c.r[0] == 0x1u;  // 06004568 cmp/eq #1,r0
    { const bool k = c.t; c.r[4] = c.r[7]; if (k) { goto L_06004578; } }  // 0600456A bt/s 0x06004578 ; mov r7,r4
    c.t = c.r[0] == 0x2u;  // 0600456E cmp/eq #2,r0
    if (c.t) { goto L_0600458E; }  // 06004570 bt 0x0600458E
    st32(c.r[14], c.r[5]);  // 06004572 mov.l r5,@r14
    c.r[2] = 0x3u; goto L_0600459A;  // 06004574 bra 0x0600459A ; mov #3,r2
L_06004578:
    c.r[5] = c.r[5] & 0xFFu;  // 06004578 extu.b r5,r5
    c.r[1] = c.r[5];  // 0600457A mov r5,r1
    c.r[1] <<= 16;  // 0600457C shll16 r1
    c.r[1] <<= 8;  // 0600457E shll8 r1
    c.r[2] = c.r[5];  // 06004580 mov r5,r2
    c.r[2] <<= 16;  // 06004582 shll16 r2
    c.r[1] |= c.r[2];  // 06004584 or r2,r1
    c.r[2] = c.r[5];  // 06004586 mov r5,r2
    c.r[2] <<= 8;  // 06004588 shll8 r2
    c.r[1] |= c.r[2]; goto L_06004594;  // 0600458A bra 0x06004594 ; or r2,r1
L_0600458E:
    c.r[5] = c.r[5] & 0xFFFFu;  // 0600458E extu.w r5,r5
    c.r[1] = c.r[5];  // 06004590 mov r5,r1
    c.r[1] <<= 16;  // 06004592 shll16 r1
L_06004594:
    c.r[1] |= c.r[5];  // 06004594 or r5,r1
    st32(c.r[14], c.r[1]);  // 06004596 mov.l r1,@r14
    c.r[2] = 0x3u;  // 06004598 mov #3,r2
L_0600459A:
    c.r[2] &= c.r[4];  // 0600459A and r4,r2
    c.r[1] = 0x3u;  // 0600459C mov #3,r1
    c.t = c.r[2] > c.r[1];  // 0600459E cmp/hi r1,r2
    { const bool k = c.t; c.r[1] = 0xFFFFFFFCu; if (k) { goto L_060045FA; } }  // 060045A0 bt/s 0x060045FA ; mov #-4,r1
    c.r[1] = c.r[2];  // 060045A4 mov r2,r1
    c.r[1] += c.r[1];  // 060045A6 add r1,r1
    c.r[0] = 0x060045B4u;  // 060045A8 mova 0x060045B4,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 060045AA mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 060045AC add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x060045F8u: goto L_060045F8; case 0x060045BCu: goto L_060045BC; case 0x060045CCu: goto L_060045CC; case 0x060045D2u: goto L_060045D2; default: sh2_call(c, x); return; } }  // 060045AE jmp @r0 ; nop
L_060045BC:
    c.r[1] = c.r[9];  // 060045BC mov r9,r1
    c.r[1] += c.r[4];  // 060045BE add r4,r1
    c.r[2] = c.r[14];  // 060045C0 mov r14,r2
    c.r[2] += 3;  // 060045C2 add #3,r2
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060045C4 mov.b @r2,r2
    c.r[1] -= 1;  // 060045C6 add #-1,r1
    st8(c.r[1], c.r[2]); goto L_060045F8;  // 060045C8 bra 0x060045F8 ; mov.b r2,@r1
L_060045CC:
    c.r[3] = c.r[9];  // 060045CC mov r9,r3
    c.r[3] += c.r[4]; goto L_060045E4;  // 060045CE bra 0x060045E4 ; add r4,r3
L_060045D2:
    c.r[3] = c.r[9];  // 060045D2 mov r9,r3
    c.r[3] += c.r[4];  // 060045D4 add r4,r3
    c.r[7] = c.r[3];  // 060045D6 mov r3,r7
    c.r[7] -= 3;  // 060045D8 add #-3,r7
    c.r[2] = ld32(c.r[14]);  // 060045DA mov.l @r14,r2
    c.r[1] = ld32(0x06004628u);  // 060045DC mov.l 0x06004628,r1
    c.r[2] &= c.r[1];  // 060045DE and r1,r2
    c.r[2] >>= 8;  // 060045E0 shlr8 r2
    st8(c.r[7], c.r[2]);  // 060045E2 mov.b r2,@r7
L_060045E4:
    c.r[2] = c.r[3];  // 060045E4 mov r3,r2
    c.r[1] = ld32(c.r[14]);  // 060045E6 mov.l @r14,r1
    c.r[2] -= 2;  // 060045E8 add #-2,r2
    c.r[1] >>= 8;  // 060045EA shlr8 r1
    st8(c.r[2], c.r[1]);  // 060045EC mov.b r1,@r2
    c.r[1] = c.r[14];  // 060045EE mov r14,r1
    c.r[1] += 3;  // 060045F0 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060045F2 mov.b @r1,r1
    c.r[3] -= 1;  // 060045F4 add #-1,r3
    st8(c.r[3], c.r[1]);  // 060045F6 mov.b r1,@r3
L_060045F8:
    c.r[1] = 0xFFFFFFFCu;  // 060045F8 mov #-4,r1
L_060045FA:
    c.r[4] &= c.r[1];  // 060045FA and r1,r4
    c.r[8] = ld32(0x0600462Cu);  // 060045FC mov.l 0x0600462C,r8
    c.r[1] = 0x1u;  // 060045FE mov #1,r1
    st8(c.r[8], c.r[1]);  // 06004600 mov.b r1,@r8
    c.r[1] = ld32(0x06004630u);  // 06004602 mov.l 0x06004630,r1
    c.r[7] = 0x11u;  // 06004604 mov #17,r7
    c.r[6] = c.r[4];  // 06004606 mov r4,r6
    c.r[5] = c.r[9];  // 06004608 mov r9,r5
    { const uint32_t x = c.r[1]; c.pr = 0x0600460Eu; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600460Eu) return; }  // 0600460A jsr @r1 ; mov r14,r4
    c.r[1] = ld32(0x06004634u);  // 0600460E mov.l 0x06004634,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06004614u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004614u) return; }  // 06004610 jsr @r1 ; nop
    c.r[1] = 0x0u;  // 06004614 mov #0,r1
    st8(c.r[8], c.r[1]);  // 06004616 mov.b r1,@r8
    c.r[14] += 4;  // 06004618 add #4,r14
    c.r[15] = c.r[14];  // 0600461A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0600461C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0600461E mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06004620 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06004622 rts ; mov.l @r15+,r8
}

void f_06004638(SH2Context& c) {
    ran[8] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06004638 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 0600463A mov r15,r14
    c.r[4] = c.r[4] & 0xFFu;  // 0600463C extu.b r4,r4
    c.r[3] = c.r[5] & 0xFFu;  // 0600463E extu.b r5,r3
    c.r[1] = 0xFu;  // 06004640 mov #15,r1
    c.t = c.r[3] > c.r[1];  // 06004642 cmp/hi r1,r3
    { const bool k = c.t; c.r[2] = c.r[3]; if (k) { goto L_0600465C; } }  // 06004644 bt/s 0x0600465C ; mov r3,r2
    c.t = (c.r[4] & c.r[4]) == 0;  // 06004648 tst r4,r4
    { const bool k = !c.t; c.r[3] <<= 2; if (k) { goto L_06004654; } }  // 0600464A bf/s 0x06004654 ; shll2 r3
    c.r[1] = ld32(0x06004664u);  // 0600464E mov.l 0x06004664,r1
    c.r[0] = c.r[3]; goto L_0600465A;  // 06004650 bra 0x0600465A ; mov r3,r0
L_06004654:
    c.r[2] <<= 2;  // 06004654 shll2 r2
    c.r[1] = ld32(0x06004668u);  // 06004656 mov.l 0x06004668,r1
    c.r[0] = c.r[2];  // 06004658 mov r2,r0
L_0600465A:
    st32(c.r[0] + c.r[1], c.r[6]);  // 0600465A mov.l r6,@(r0,r1)
L_0600465C:
    c.r[15] = c.r[14];  // 0600465C mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0600465E rts ; mov.l @r15+,r14
}

void f_0600466C(SH2Context& c) {
    ran[9] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0600466C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0600466E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06004670 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06004672 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06004674 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06004676 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06004678 mov.l r14,@-r15
    c.r[1] = ld32(0x060047B0u);  // 0600467A mov.l 0x060047B0,r1
    c.r[2] = ld32(c.r[1]);  // 0600467C mov.l @r1,r2
    c.r[15] -= 24;  // 0600467E add #-24,r15
    c.r[1] = c.r[2];  // 06004680 mov r2,r1
    c.r[3] = ld32(c.r[1]); c.r[1] += 4;  // 06004682 mov.l @r1+,r3
    c.r[14] = c.r[15];  // 06004684 mov r15,r14
    st32(c.r[14], c.r[3]);  // 06004686 mov.l r3,@r14
    c.r[2] = ld32(c.r[2] + 4);  // 06004688 mov.l @(4,r2),r2
    c.r[1] += 4;  // 0600468A add #4,r1
    st32(c.r[14] + 4, c.r[2]);  // 0600468C mov.l r2,@(4,r14)
    c.r[2] = c.r[14];  // 0600468E mov r14,r2
    c.r[3] = ld32(c.r[1]); c.r[1] += 4;  // 06004690 mov.l @r1+,r3
    c.r[2] += 8;  // 06004692 add #8,r2
    st32(c.r[2], c.r[3]);  // 06004694 mov.l r3,@r2
    c.r[3] = ld32(c.r[1]); c.r[1] += 4;  // 06004696 mov.l @r1+,r3
    c.r[2] += 4;  // 06004698 add #4,r2
    st32(c.r[2], c.r[3]);  // 0600469A mov.l r3,@r2
    c.r[3] = ld32(c.r[1]); c.r[1] += 4;  // 0600469C mov.l @r1+,r3
    c.r[2] += 4;  // 0600469E add #4,r2
    st32(c.r[2], c.r[3]);  // 060046A0 mov.l r3,@r2
    c.r[1] = ld32(c.r[1]);  // 060046A2 mov.l @r1,r1
    c.r[7] = ld32(0x060047B4u);  // 060046A4 mov.l 0x060047B4,r7
    st32(c.r[2] + 4, c.r[1]);  // 060046A6 mov.l r1,@(4,r2)
    c.r[2] = c.r[14];  // 060046A8 mov r14,r2
    c.r[2] += 2;  // 060046AA add #2,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 060046AC mov.w @r2,r1
    c.r[3] = c.r[14];  // 060046AE mov r14,r3
    c.r[1] = ~c.r[1];  // 060046B0 not r1,r1
    st16(c.r[2], c.r[1]);  // 060046B2 mov.w r1,@r2
    c.r[2] = c.r[14];  // 060046B4 mov r14,r2
    c.r[2] += 4;  // 060046B6 add #4,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 060046B8 mov.w @r2,r1
    c.r[3] += 6;  // 060046BA add #6,r3
    c.r[6] = ~c.r[1];  // 060046BC not r1,r6
    st16(c.r[2], c.r[6]);  // 060046BE mov.w r6,@r2
    c.r[2] = c.r[7];  // 060046C0 mov r7,r2
    c.r[2] += 6;  // 060046C2 add #6,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[3]);  // 060046C4 mov.w @r3,r1
    c.r[7] += 4;  // 060046C6 add #4,r7
    c.r[1] = ~c.r[1];  // 060046C8 not r1,r1
    st16(c.r[2], c.r[1]);  // 060046CA mov.w r1,@r2
    st16(c.r[3], c.r[1]);  // 060046CC mov.w r1,@r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x060047A6u);  // 060046CE mov.w 0x060047A6,r1
    c.r[1] &= c.r[6];  // 060046D0 and r6,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060046D2 tst r1,r1
    { const bool k = c.t; c.r[2] = c.r[6] & 0xFFFFu; if (k) { goto L_060046EC; } }  // 060046D4 bt/s 0x060046EC ; extu.w r6,r2
    c.r[6] >>= 8;  // 060046D8 shlr8 r6
    c.t = c.r[6] & 1; c.r[6] >>= 1;  // 060046DA shlr r6
    c.r[6] >>= 2;  // 060046DC shlr2 r6
    c.r[0] = 0x1u;  // 060046DE mov #1,r0
    c.r[6] &= c.r[0];  // 060046E0 and r0,r6
    c.t = (c.r[6] & c.r[6]) == 0;  // 060046E2 tst r6,r6
    if (c.t) { goto L_060046EC; }  // 060046E4 bt 0x060046EC
    c.r[1] = ld32(0x060047B8u);  // 060046E6 mov.l 0x060047B8,r1
    c.r[1] &= c.r[2]; goto L_060046F0;  // 060046E8 bra 0x060046F0 ; and r2,r1
L_060046EC:
    c.r[1] = ld32(0x060047BCu);  // 060046EC mov.l 0x060047BC,r1
    c.r[1] &= c.r[2];  // 060046EE and r2,r1
L_060046F0:
    st16(c.r[7], c.r[1]);  // 060046F0 mov.w r1,@r7
    c.r[1] = c.r[14];  // 060046F2 mov r14,r1
    c.r[1] += 2;  // 060046F4 add #2,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060046F6 mov.w @r1,r2
    c.r[7] = ld32(0x060047C0u);  // 060046F8 mov.l 0x060047C0,r7
    c.r[1] = (uint32_t)(int16_t)ld16(0x060047A6u);  // 060046FA mov.w 0x060047A6,r1
    c.r[1] &= c.r[2];  // 060046FC and r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060046FE tst r1,r1
    { const bool k = c.t; c.r[3] = c.r[2] & 0xFFFFu; if (k) { goto L_06004712; } }  // 06004700 bt/s 0x06004712 ; extu.w r2,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x060047A8u);  // 06004704 mov.w 0x060047A8,r1
    c.r[1] &= c.r[2];  // 06004706 and r2,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06004708 tst r1,r1
    if (c.t) { goto L_06004712; }  // 0600470A bt 0x06004712
    c.r[1] = ld32(0x060047B8u);  // 0600470C mov.l 0x060047B8,r1
    c.r[1] &= c.r[3]; goto L_06004716;  // 0600470E bra 0x06004716 ; and r3,r1
L_06004712:
    c.r[1] = ld32(0x060047BCu);  // 06004712 mov.l 0x060047BC,r1
    c.r[1] &= c.r[3];  // 06004714 and r3,r1
L_06004716:
    st16(c.r[7], c.r[1]);  // 06004716 mov.w r1,@r7
    c.r[3] = 0x0u;  // 06004718 mov #0,r3
    c.r[1] = ld32(0x060047C4u);  // 0600471A mov.l 0x060047C4,r1
    c.r[12] = ld32(c.r[1]);  // 0600471C mov.l @r1,r12
    c.r[10] = 0x16u;  // 0600471E mov #22,r10
    c.r[8] = ld32(0x060047C8u);  // 06004720 mov.l 0x060047C8,r8
    c.r[9] = c.r[14];  // 06004722 mov r14,r9
    c.r[9] += 4;  // 06004724 add #4,r9
    c.r[6] = ld32(0x060047CCu);  // 06004726 mov.l 0x060047CC,r6
    c.r[4] = ld32(0x060047D0u);  // 06004728 mov.l 0x060047D0,r4
    c.r[5] = c.r[6];  // 0600472A mov r6,r5
    c.r[5] -= 2;  // 0600472C add #-2,r5
    c.r[11] = ld32(0x060047D4u);  // 0600472E mov.l 0x060047D4,r11
    c.r[7] = 0x0u;  // 06004730 mov #0,r7
L_06004732:
    c.r[0] = c.r[3];  // 06004732 mov r3,r0
    c.t = c.r[0] >> 31; c.r[0] = c.r[0] << 1 | c.t;  // 06004734 rotl r0
    c.r[0] = c.t;  // 06004736 movt r0
    c.r[0] += c.r[3];  // 06004738 add r3,r0
    c.t = c.r[0] & 1; c.r[0] = (uint32_t)((int32_t)c.r[0] >> 1);  // 0600473A shar r0
    c.r[0] += c.r[12];  // 0600473C add r12,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x060047AAu);  // 0600473E mov.w 0x060047AA,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06004740 mov.b @(r0,r1),r1
    c.r[2] = c.r[1] & 0xFFu;  // 06004742 extu.b r1,r2
    c.r[1] = 0x1u;  // 06004744 mov #1,r1
    c.r[1] &= c.r[3];  // 06004746 and r3,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06004748 tst r1,r1
    { const bool k = c.t; c.r[0] = 0xFu; if (k) { goto L_06004754; } }  // 0600474A bt/s 0x06004754 ; mov #15,r0
    c.r[0] = (uint32_t)(int16_t)ld16(0x060047ACu);  // 0600474E mov.w 0x060047AC,r0
    c.r[2] &= c.r[0]; goto L_06004756;  // 06004750 bra 0x06004756 ; and r0,r2
L_06004754:
    c.r[2] &= c.r[0];  // 06004754 and r0,r2
L_06004756:
    c.r[1] = 0x1u;  // 06004756 mov #1,r1
    c.r[1] &= c.r[3];  // 06004758 and r3,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0600475A tst r1,r1
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_06004766; } }  // 0600475C bt/s 0x06004766 ; mov r2,r1
    c.r[1] >>= 2;  // 06004760 shlr2 r1
    c.r[1] >>= 2; goto L_06004768;  // 06004762 bra 0x06004768 ; shlr2 r1
L_06004766:
    c.r[1] = c.r[2] & 0xFFu;  // 06004766 extu.b r2,r1
L_06004768:
    c.r[2] = c.r[1];  // 06004768 mov r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0600476A tst r2,r2
    if (c.t) { goto L_06004818; }  // 0600476C bt 0x06004818
    c.r[0] = c.r[2];  // 0600476E mov r2,r0
    c.t = c.r[0] == 0xBu;  // 06004770 cmp/eq #11,r0
    { const bool k = !c.t; c.r[0] = c.r[8]; if (k) { goto L_060047D8; } }  // 06004772 bf/s 0x060047D8 ; mov r8,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[10]);  // 06004776 mov.w @(r0,r10),r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[9]);  // 06004778 mov.w @r9,r2
    c.r[1] &= c.r[2];  // 0600477A and r2,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0600477C extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0600477E tst r1,r1
    { const bool k = c.t; c.r[1] = c.r[14]; if (k) { goto L_06004792; } }  // 06004780 bt/s 0x06004792 ; mov r14,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[6]);  // 06004784 mov.w @r6,r1
    c.r[0] = c.r[7];  // 06004786 mov r7,r0
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[4]);  // 06004788 mov.w @(r0,r4),r2
    c.r[1] |= c.r[2];  // 0600478A or r2,r1
    st16(c.r[6], c.r[1]);  // 0600478C mov.w r1,@r6
    c.r[1] = c.r[14];  // 0600478E mov r14,r1
    c.r[0] = c.r[8];  // 06004790 mov r8,r0
L_06004792:
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[10]);  // 06004792 mov.w @(r0,r10),r2
    c.r[1] += 2;  // 06004794 add #2,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06004796 mov.w @r1,r1
    c.r[2] &= c.r[1];  // 06004798 and r1,r2
    c.r[2] = c.r[2] & 0xFFFFu;  // 0600479A extu.w r2,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 0600479C tst r2,r2
    if (c.t) { goto L_06004818; }  // 0600479E bt 0x06004818
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[5]);  // 060047A0 mov.w @r5,r1
    c.r[0] = c.r[7]; goto L_06004812;  // 060047A2 bra 0x06004812 ; mov r7,r0
L_060047D8:
    c.r[13] = c.r[1];  // 060047D8 mov r1,r13
    c.r[13] += c.r[13];  // 060047DA add r13,r13
    c.r[0] = c.r[13];  // 060047DC mov r13,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[11]);  // 060047DE mov.w @(r0,r11),r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[9]);  // 060047E0 mov.w @r9,r2
    c.r[1] &= c.r[2];  // 060047E2 and r2,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[8]);  // 060047E4 mov.w @(r0,r8),r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 060047E6 extu.w r1,r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 060047E8 extu.w r2,r2
    c.t = c.r[1] == c.r[2];  // 060047EA cmp/eq r2,r1
    if (!c.t) { goto L_060047F8; }  // 060047EC bf 0x060047F8
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[6]);  // 060047EE mov.w @r6,r1
    c.r[0] = c.r[7];  // 060047F0 mov r7,r0
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[4]);  // 060047F2 mov.w @(r0,r4),r2
    c.r[1] |= c.r[2];  // 060047F4 or r2,r1
    st16(c.r[6], c.r[1]);  // 060047F6 mov.w r1,@r6
L_060047F8:
    c.r[1] = c.r[14];  // 060047F8 mov r14,r1
    c.r[0] = c.r[13];  // 060047FA mov r13,r0
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[11]);  // 060047FC mov.w @(r0,r11),r2
    c.r[1] += 2;  // 060047FE add #2,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06004800 mov.w @r1,r1
    c.r[2] &= c.r[1];  // 06004802 and r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[8]);  // 06004804 mov.w @(r0,r8),r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 06004806 extu.w r2,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 06004808 extu.w r1,r1
    c.t = c.r[2] == c.r[1];  // 0600480A cmp/eq r1,r2
    if (!c.t) { goto L_06004818; }  // 0600480C bf 0x06004818
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[5]);  // 0600480E mov.w @r5,r1
    c.r[0] = c.r[7];  // 06004810 mov r7,r0
L_06004812:
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[4]);  // 06004812 mov.w @(r0,r4),r2
    c.r[1] |= c.r[2];  // 06004814 or r2,r1
    st16(c.r[5], c.r[1]);  // 06004816 mov.w r1,@r5
L_06004818:
    c.r[3] += 1;  // 06004818 add #1,r3
    c.r[1] = 0xAu;  // 0600481A mov #10,r1
    c.t = (int32_t)c.r[3] > (int32_t)c.r[1];  // 0600481C cmp/gt r1,r3
    { const bool k = !c.t; c.r[7] += 2; if (k) { SH2_POLL(c); goto L_06004732; } }  // 0600481E bf/s 0x06004732 ; add #2,r7
    c.r[14] += 24;  // 06004822 add #24,r14
    c.r[15] = c.r[14];  // 06004824 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06004826 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06004828 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0600482A mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0600482C mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0600482E mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06004830 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06004832 rts ; mov.l @r15+,r8
}

void f_06004838(SH2Context& c) {
    ran[10] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06004838 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0600483A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0600483C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0600483E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06004840 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06004842 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06004844 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06004846 mov r15,r14
    c.r[9] = 0x0u;  // 06004848 mov #0,r9
    c.r[11] = ld32(0x060048E4u);  // 0600484A mov.l 0x060048E4,r11
    c.r[12] = ld32(0x060048E8u);  // 0600484C mov.l 0x060048E8,r12
    c.r[10] = 0x0u;  // 0600484E mov #0,r10
    c.r[13] = c.r[12];  // 06004850 mov r12,r13
    c.r[13] -= 2;  // 06004852 add #-2,r13
    c.r[4] = c.r[11];  // 06004854 mov r11,r4
    c.r[5] = 0x0u;  // 06004856 mov #0,r5
L_06004858:
    c.r[2] = c.r[9];  // 06004858 mov r9,r2
    c.r[1] = c.r[4];  // 0600485A mov r4,r1
    c.r[1] += 2;  // 0600485C add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0600485E mov.b @r1,r1
    c.r[2] += c.r[2];  // 06004860 add r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06004862 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06004864 tst r1,r1
    { const bool k = c.t; c.r[0] = c.r[5]; if (k) { goto L_060048BE; } }  // 06004866 bt/s 0x060048BE ; mov r5,r0
    c.r[1] = ld32(0x060048ECu);  // 0600486A mov.l 0x060048EC,r1
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[12]);  // 0600486C mov.w @r12,r8
    c.r[0] = c.r[2];  // 0600486E mov r2,r0
    c.r[6] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06004870 mov.w @(r0,r1),r6
    c.r[1] = c.r[8];  // 06004872 mov r8,r1
    c.r[1] &= c.r[6];  // 06004874 and r6,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06004876 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06004878 tst r1,r1
    if (!c.t) { goto L_060048BC; }  // 0600487A bf 0x060048BC
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[13]);  // 0600487C mov.w @r13,r1
    c.r[1] &= c.r[6];  // 0600487E and r6,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06004880 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06004882 tst r1,r1
    { const bool k = c.t; c.r[0] = c.r[5]; if (k) { goto L_060048BE; } }  // 06004884 bt/s 0x060048BE ; mov r5,r0
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[11]);  // 06004888 mov.b @(r0,r11),r3
    c.r[1] = 0x1Eu;  // 0600488A mov #30,r1
    c.r[2] = c.r[3] & 0xFFu;  // 0600488C extu.b r3,r2
    c.t = c.r[2] > c.r[1];  // 0600488E cmp/hi r1,r2
    if (!c.t) { goto L_060048B2; }  // 06004890 bf 0x060048B2
    c.r[3] = c.r[4];  // 06004892 mov r4,r3
    c.r[3] += 1;  // 06004894 add #1,r3
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06004896 mov.b @r3,r7
    c.r[1] = 0x3u;  // 06004898 mov #3,r1
    c.r[2] = c.r[7] & 0xFFu;  // 0600489A extu.b r7,r2
    c.t = c.r[2] > c.r[1];  // 0600489C cmp/hi r1,r2
    { const bool k = !c.t; c.r[1] = c.r[8]; if (k) { goto L_060048AA; } }  // 0600489E bf/s 0x060048AA ; mov r8,r1
    c.r[1] |= c.r[6];  // 060048A2 or r6,r1
    st16(c.r[12], c.r[1]);  // 060048A4 mov.w r1,@r12
    st8(c.r[3], c.r[10]); goto L_060048C6;  // 060048A6 bra 0x060048C6 ; mov.b r10,@r3
L_060048AA:
    c.r[1] = c.r[7];  // 060048AA mov r7,r1
    c.r[1] += 1;  // 060048AC add #1,r1
    st8(c.r[3], c.r[1]); goto L_060048C6;  // 060048AE bra 0x060048C6 ; mov.b r1,@r3
L_060048B2:
    c.r[1] = c.r[3];  // 060048B2 mov r3,r1
    c.r[1] += 1;  // 060048B4 add #1,r1
    c.r[0] = c.r[5];  // 060048B6 mov r5,r0
    st8(c.r[0] + c.r[11], c.r[1]); goto L_060048C6;  // 060048B8 bra 0x060048C6 ; mov.b r1,@(r0,r11)
L_060048BC:
    c.r[0] = c.r[5];  // 060048BC mov r5,r0
L_060048BE:
    st8(c.r[0] + c.r[11], c.r[10]);  // 060048BE mov.b r10,@(r0,r11)
    c.r[1] = c.r[4];  // 060048C0 mov r4,r1
    c.r[1] += 1;  // 060048C2 add #1,r1
    st8(c.r[1], c.r[10]);  // 060048C4 mov.b r10,@r1
L_060048C6:
    c.r[4] += 3;  // 060048C6 add #3,r4
    c.r[9] += 1;  // 060048C8 add #1,r9
    c.r[1] = 0xCu;  // 060048CA mov #12,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 060048CC cmp/gt r1,r9
    { const bool k = !c.t; c.r[5] += 3; if (k) { SH2_POLL(c); goto L_06004858; } }  // 060048CE bf/s 0x06004858 ; add #3,r5
    c.r[15] = c.r[14];  // 060048D2 mov r14,r15
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060048D4 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060048D6 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060048D8 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060048DA mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060048DC mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060048DE mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060048E0 rts ; mov.l @r15+,r8
}

void f_060048F0(SH2Context& c) {
    ran[11] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 060048F0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 060048F2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 060048F4 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060048F6 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 060048F8 sts.l pr,@-r15
    c.r[1] = ld32(0x06004A64u);  // 060048FA mov.l 0x06004A64,r1
    c.r[1] = ld32(c.r[1]);  // 060048FC mov.l @r1,r1
    c.r[1] += 2;  // 060048FE add #2,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06004900 mov.w @r1,r1
    c.r[2] = c.r[1] & 0xFFFFu;  // 06004902 extu.w r1,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06004A62u);  // 06004904 mov.w 0x06004A62,r1
    c.r[2] &= c.r[1];  // 06004906 and r1,r2
    c.t = (c.r[2] & c.r[2]) == 0;  // 06004908 tst r2,r2
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_06004924; } }  // 0600490A bt/s 0x06004924 ; mov r15,r14
    c.r[1] = ld32(0x06004A68u);  // 0600490E mov.l 0x06004A68,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06004910 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06004912 extu.b r1,r0
    c.r[0] >>= 2;  // 06004914 shlr2 r0
    c.r[0] >>= 2;  // 06004916 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06004918 shlr r0
    c.r[0] >>= 2;  // 0600491A shlr2 r0
    c.t = c.r[0] == 0x1u;  // 0600491C cmp/eq #1,r0
    if (c.t) { goto L_06004924; }  // 0600491E bt 0x06004924
    goto L_06004B14;  // 06004920 bra 0x06004B14 ; nop
L_06004924:
    c.r[0] = ld32(0x06004A6Cu);  // 06004924 mov.l 0x06004A6C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0600492Au; c.r[4] = 0xFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600492Au) return; }  // 06004926 jsr @r0 ; mov #15,r4
    c.r[1] = c.r[0] & 0xFFFFu;  // 0600492A extu.w r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0600492C tst r1,r1
    if (c.t) { goto L_06004938; }  // 0600492E bt 0x06004938
    c.r[1] = ld32(0x06004A70u);  // 06004930 mov.l 0x06004A70,r1
    c.r[1] = ld32(c.r[1]);  // 06004932 mov.l @r1,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06004938u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004938u) return; }  // 06004934 jsr @r1 ; nop
L_06004938:
    c.r[0] = ld32(0x06004A74u);  // 06004938 mov.l 0x06004A74,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0600493Eu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600493Eu) return; }  // 0600493A jsr @r0 ; mov #0,r4
    c.r[0] = ld32(0x06004A78u);  // 0600493E mov.l 0x06004A78,r0
    c.r[6] = 0x0u;  // 06004940 mov #0,r6
    c.r[5] = 0x0u;  // 06004942 mov #0,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06004948u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004948u) return; }  // 06004944 jsr @r0 ; mov #0,r4
    c.r[4] = ld32(0x06004A7Cu);  // 06004948 mov.l 0x06004A7C,r4
    c.r[1] = c.r[4];  // 0600494A mov r4,r1
    c.r[1] += 66;  // 0600494C add #66,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0600494E mov.w @r1,r1
    c.r[0] = c.r[1] & 0xFFFFu;  // 06004950 extu.w r1,r0
    c.t = c.r[0] == 0x20u;  // 06004952 cmp/eq #32,r0
    if (!c.t) { goto L_0600495C; }  // 06004954 bf 0x0600495C
    c.r[1] = ld32(0x06004A80u);  // 06004956 mov.l 0x06004A80,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0600495Cu; c.r[4] = ld32(c.r[4]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600495Cu) return; }  // 06004958 jsr @r1 ; mov.l @r4,r4
L_0600495C:
    c.r[1] = ld32(0x06004A84u);  // 0600495C mov.l 0x06004A84,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0600495E mov.b @r1,r4
    c.r[8] = ld32(0x06004A88u);  // 06004960 mov.l 0x06004A88,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06004966u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004966u) return; }  // 06004962 jsr @r8 ; extu.b r4,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0600496Au; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600496Au) return; }  // 06004966 jsr @r8 ; mov #0,r4
    c.r[0] = ld32(0x06004A8Cu);  // 0600496A mov.l 0x06004A8C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06004970u; c.r[9] = 0xFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004970u) return; }  // 0600496C jsr @r0 ; mov #15,r9
    c.r[2] = 0x0u;  // 06004970 mov #0,r2
    c.r[3] = 0x0u;  // 06004972 mov #0,r3
    c.r[6] = ld32(0x06004A90u);  // 06004974 mov.l 0x06004A90,r6
    c.r[7] = ld32(0x06004A94u);  // 06004976 mov.l 0x06004A94,r7
L_06004978:
    c.r[1] = c.r[2] & 0xFFu;  // 06004978 extu.b r2,r1
    c.t = c.r[1] > c.r[9];  // 0600497A cmp/hi r9,r1
    { const bool k = c.t; c.r[0] = c.r[1]; if (k) { goto L_06004986; } }  // 0600497C bt/s 0x06004986 ; mov r1,r0
    c.r[0] <<= 2;  // 06004980 shll2 r0
    st32(c.r[0] + c.r[6], c.r[3]);  // 06004982 mov.l r3,@(r0,r6)
    c.t = c.r[1] > c.r[9];  // 06004984 cmp/hi r9,r1
L_06004986:
    { const bool k = c.t; c.r[1] <<= 2; if (k) { goto L_0600498E; } }  // 06004986 bt/s 0x0600498E ; shll2 r1
    c.r[0] = c.r[1];  // 0600498A mov r1,r0
    st32(c.r[0] + c.r[7], c.r[3]);  // 0600498C mov.l r3,@(r0,r7)
L_0600498E:
    c.r[2] += 1;  // 0600498E add #1,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[9];  // 06004990 cmp/gt r9,r2
    if (!c.t) { SH2_POLL(c); goto L_06004978; }  // 06004992 bf 0x06004978
    c.r[8] = ld32(0x06004A98u);  // 06004994 mov.l 0x06004A98,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0600499Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600499Au) return; }  // 06004996 jsr @r8 ; nop
    c.r[1] = ld32(0x06004A9Cu);  // 0600499A mov.l 0x06004A9C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060049A0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060049A0u) return; }  // 0600499C jsr @r1 ; nop
    { const uint32_t x = c.r[8]; c.pr = 0x060049A4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060049A4u) return; }  // 060049A0 jsr @r8 ; nop
    c.r[2] = 0x0u;  // 060049A4 mov #0,r2
    c.r[7] = c.r[9];  // 060049A6 mov r9,r7
    c.r[3] = 0x0u;  // 060049A8 mov #0,r3
    c.r[1] = ld32(0x06004AA0u);  // 060049AA mov.l 0x06004AA0,r1
L_060049AC:
    st32(c.r[1] + 4, c.r[3]);  // 060049AC mov.l r3,@(4,r1)
    c.r[2] += 1;  // 060049AE add #1,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[7];  // 060049B0 cmp/gt r7,r2
    { const bool k = !c.t; c.r[1] += 4; if (k) { SH2_POLL(c); goto L_060049AC; } }  // 060049B2 bf/s 0x060049AC ; add #4,r1
    c.r[9] = ld32(0x06004AA4u);  // 060049B6 mov.l 0x06004AA4,r9
    { const uint32_t x = c.r[9]; c.pr = 0x060049BCu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060049BCu) return; }  // 060049B8 jsr @r9 ; mov #0,r4
    c.r[10] = ld32(0x06004A98u);  // 060049BC mov.l 0x06004A98,r10
    { const uint32_t x = c.r[10]; c.pr = 0x060049C2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060049C2u) return; }  // 060049BE jsr @r10 ; nop
    c.r[1] = ld32(0x06004AA8u);  // 060049C2 mov.l 0x06004AA8,r1
    c.r[6] = 0xFFFFFFFFu;  // 060049C4 mov #-1,r6
    c.r[5] = 0x0u;  // 060049C6 mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x060049CCu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060049CCu) return; }  // 060049C8 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06004A9Cu);  // 060049CC mov.l 0x06004A9C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060049D2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060049D2u) return; }  // 060049CE jsr @r1 ; nop
    c.r[1] = ld32(0x06004AACu);  // 060049D2 mov.l 0x06004AAC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060049D8u; c.r[4] = 0x3u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060049D8u) return; }  // 060049D4 jsr @r1 ; mov #3,r4
    c.r[1] = ld32(0x06004AB0u);  // 060049D8 mov.l 0x06004AB0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060049DEu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060049DEu) return; }  // 060049DA jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06004AB4u);  // 060049DE mov.l 0x06004AB4,r1
    c.r[4] = ld32(0x06004AB8u);  // 060049E0 mov.l 0x06004AB8,r4
    { const uint32_t x = c.r[1]; c.pr = 0x060049E6u; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060049E6u) return; }  // 060049E2 jsr @r1 ; mov #0,r5
    c.r[1] = ld32(0x06004ABCu);  // 060049E6 mov.l 0x06004ABC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060049ECu; c.r[4] = 0x5Fu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060049ECu) return; }  // 060049E8 jsr @r1 ; mov #95,r4
    c.r[1] = ld32(0x06004AC0u);  // 060049EC mov.l 0x06004AC0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060049F2u; c.r[4] = 0x8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060049F2u) return; }  // 060049EE jsr @r1 ; mov #8,r4
    c.r[1] = ld32(0x06004AC4u);  // 060049F2 mov.l 0x06004AC4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060049F8u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060049F8u) return; }  // 060049F4 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06004AC8u);  // 060049F8 mov.l 0x06004AC8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060049FEu; c.r[4] = 0x6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060049FEu) return; }  // 060049FA jsr @r1 ; mov #6,r4
    c.r[2] = ld32(0x06004ACCu);  // 060049FE mov.l 0x06004ACC,r2
    c.r[1] = 0x0u;  // 06004A00 mov #0,r1
    st32(c.r[2], c.r[1]);  // 06004A02 mov.l r1,@r2
    c.r[1] = ld32(0x06004AD0u);  // 06004A04 mov.l 0x06004AD0,r1
    c.r[8] = 0x1u;  // 06004A06 mov #1,r8
    c.r[4] = ld32(0x06004AD4u);  // 06004A08 mov.l 0x06004AD4,r4
    { const uint32_t x = c.r[9]; c.pr = 0x06004A0Eu; st8(c.r[1], c.r[8]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004A0Eu) return; }  // 06004A0A jsr @r9 ; mov.b r8,@r1
    c.r[1] = ld32(0x06004AD8u);  // 06004A0E mov.l 0x06004AD8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06004A14u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004A14u) return; }  // 06004A10 jsr @r1 ; nop
    { const uint32_t x = c.r[10]; c.pr = 0x06004A18u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004A18u) return; }  // 06004A14 jsr @r10 ; nop
    c.r[2] = ld32(0x06004ADCu);  // 06004A18 mov.l 0x06004ADC,r2
    c.r[1] = 0x0u;  // 06004A1A mov #0,r1
    st8(c.r[2], c.r[1]);  // 06004A1C mov.b r1,@r2
    c.r[1] = ld32(0x06004AE0u);  // 06004A1E mov.l 0x06004AE0,r1
    st8(c.r[1], c.r[8]);  // 06004A20 mov.b r8,@r1
    c.r[1] = ld32(0x06004AE4u);  // 06004A22 mov.l 0x06004AE4,r1
    c.r[5] = 0x0u;  // 06004A24 mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06004A2Au; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004A2Au) return; }  // 06004A26 jsr @r1 ; mov #0,r4
    c.r[7] = ld32(0x06004AE8u);  // 06004A2A mov.l 0x06004AE8,r7
    c.r[8] = ld32(0x06004AECu);  // 06004A2C mov.l 0x06004AEC,r8
    c.r[4] = ld32(0x06004AF0u);  // 06004A2E mov.l 0x06004AF0,r4
    c.r[0] = ld32(0x06004AF4u);  // 06004A30 mov.l 0x06004AF4,r0
    c.r[6] = c.r[8];  // 06004A32 mov r8,r6
    { const uint32_t x = c.r[0]; c.pr = 0x06004A38u; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004A38u) return; }  // 06004A34 jsr @r0 ; mov #0,r5
    c.r[1] = ld32(0x06004AF8u);  // 06004A38 mov.l 0x06004AF8,r1
    { const uint32_t x = c.r[10]; c.pr = 0x06004A3Eu; st32(c.r[1], c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004A3Eu) return; }  // 06004A3A jsr @r10 ; mov.l r0,@r1
    c.r[0] = ld32(0x06004AFCu);  // 06004A3E mov.l 0x06004AFC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06004A44u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004A44u) return; }  // 06004A40 jsr @r0 ; nop
    c.r[0] &= 0x20u;  // 06004A44 and #32,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06004A46 tst r0,r0
    if (c.t) { goto L_06004A50; }  // 06004A48 bt 0x06004A50
    c.r[1] = ld32(0x06004B00u);  // 06004A4A mov.l 0x06004B00,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06004A50u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004A50u) return; }  // 06004A4C jsr @r1 ; mov #1,r4
L_06004A50:
    c.r[5] = ld32(0x06004B04u);  // 06004A50 mov.l 0x06004B04,r5
    c.r[0] = ld32(0x06004B08u);  // 06004A52 mov.l 0x06004B08,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06004A58u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004A58u) return; }  // 06004A54 jsr @r0 ; mov r8,r4
    c.r[1] = ld32(0x06004B0Cu);  // 06004A58 mov.l 0x06004B0C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06004A5Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004A5Eu) return; }  // 06004A5A jsr @r1 ; nop
    goto L_06004B10;  // 06004A5E bra 0x06004B10 ; nop
L_06004B10:
    { const uint32_t x = c.r[10]; c.pr = 0x06004B14u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004B14u) return; }  // 06004B10 jsr @r10 ; nop
L_06004B14:
    c.r[1] = ld32(0x06004C5Cu);  // 06004B14 mov.l 0x06004C5C,r1
    c.r[1] = ld32(c.r[1]);  // 06004B16 mov.l @r1,r1
    c.r[1] += 4;  // 06004B18 add #4,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06004B1A mov.w @r1,r1
    c.r[0] = ~c.r[1];  // 06004B1C not r1,r0
    c.r[0] >>= 8;  // 06004B1E shlr8 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06004B20 shlr r0
    c.r[0] >>= 2;  // 06004B22 shlr2 r0
    c.r[0] &= 0x1u;  // 06004B24 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06004B26 tst r0,r0
    if (!c.t) { goto L_06004B2E; }  // 06004B28 bf 0x06004B2E
    goto L_06004C4C;  // 06004B2A bra 0x06004C4C ; nop
L_06004B2E:
    c.r[2] = ld32(0x06004C60u);  // 06004B2E mov.l 0x06004C60,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06004B30 mov.b @r2,r1
    c.r[0] = c.r[1];  // 06004B32 mov r1,r0
    c.r[0] >>= 2;  // 06004B34 shlr2 r0
    c.r[0] >>= 2;  // 06004B36 shlr2 r0
    c.r[0] &= 0x1u;  // 06004B38 and #1,r0
    c.t = c.r[0] == 0x1u;  // 06004B3A cmp/eq #1,r0
    { const bool k = c.t; c.r[7] = 0x0u; if (k) { goto L_06004B44; } }  // 06004B3C bt/s 0x06004B44 ; mov #0,r7
    goto L_06004C4C;  // 06004B40 bra 0x06004C4C ; nop
L_06004B44:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06004B44 mov.b @r2,r0
    c.r[3] = 0xFu;  // 06004B46 mov #15,r3
    c.r[0] &= 0xEFu;  // 06004B48 and #239,r0
    st8(c.r[2], c.r[0]);  // 06004B4A mov.b r0,@r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06004B4C mov.b @r2,r0
    c.r[1] = ld32(0x06004C64u);  // 06004B4E mov.l 0x06004C64,r1
    c.r[0] |= 0x8u;  // 06004B50 or #8,r0
    st8(c.r[2], c.r[0]);  // 06004B52 mov.b r0,@r2
    c.r[2] = 0x0u;  // 06004B54 mov #0,r2
    c.r[6] = c.r[2] & 0xFFu;  // 06004B56 extu.b r2,r6
L_06004B58:
    c.t = c.r[6] > c.r[3];  // 06004B58 cmp/hi r3,r6
    { const bool k = c.t; c.r[6] <<= 2; if (k) { goto L_06004B62; } }  // 06004B5A bt/s 0x06004B62 ; shll2 r6
    c.r[0] = c.r[6];  // 06004B5E mov r6,r0
    st32(c.r[0] + c.r[1], c.r[7]);  // 06004B60 mov.l r7,@(r0,r1)
L_06004B62:
    c.r[2] += 1;  // 06004B62 add #1,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[3];  // 06004B64 cmp/gt r3,r2
    { const bool k = !c.t; c.r[6] = c.r[2] & 0xFFu; if (k) { SH2_POLL(c); goto L_06004B58; } }  // 06004B66 bf/s 0x06004B58 ; extu.b r2,r6
    c.r[2] = 0x0u;  // 06004B6A mov #0,r2
    c.r[1] = ld32(0x06004C68u);  // 06004B6C mov.l 0x06004C68,r1
    st32(c.r[1], c.r[2]);  // 06004B6E mov.l r2,@r1
    st32(c.r[1] + 8, c.r[2]);  // 06004B70 mov.l r2,@(8,r1)
    c.r[2] = 0x6u;  // 06004B72 mov #6,r2
    c.r[7] = 0x0u;  // 06004B74 mov #0,r7
    c.r[6] = c.r[2] & 0xFFu;  // 06004B76 extu.b r2,r6
L_06004B78:
    c.t = c.r[6] > c.r[3];  // 06004B78 cmp/hi r3,r6
    { const bool k = c.t; c.r[6] <<= 2; if (k) { goto L_06004B82; } }  // 06004B7A bt/s 0x06004B82 ; shll2 r6
    c.r[0] = c.r[6];  // 06004B7E mov r6,r0
    st32(c.r[0] + c.r[1], c.r[7]);  // 06004B80 mov.l r7,@(r0,r1)
L_06004B82:
    c.r[2] += 1;  // 06004B82 add #1,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[3];  // 06004B84 cmp/gt r3,r2
    { const bool k = !c.t; c.r[6] = c.r[2] & 0xFFu; if (k) { SH2_POLL(c); goto L_06004B78; } }  // 06004B86 bf/s 0x06004B78 ; extu.b r2,r6
    c.r[10] = ld32(0x06004C6Cu);  // 06004B8A mov.l 0x06004C6C,r10
    { const uint32_t x = c.r[10]; c.pr = 0x06004B90u; c.r[8] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004B90u) return; }  // 06004B8C jsr @r10 ; mov #0,r8
    c.r[1] = ld32(0x06004C70u);  // 06004B90 mov.l 0x06004C70,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06004B96u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004B96u) return; }  // 06004B92 jsr @r1 ; nop
    c.r[2] = ld32(0x06004C74u);  // 06004B96 mov.l 0x06004C74,r2
    c.r[1] = ld32(0x06004C78u);  // 06004B98 mov.l 0x06004C78,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06004B9A mov.b @r1,r0
    c.r[0] &= 0x7Fu;  // 06004B9C and #127,r0
    st8(c.r[1], c.r[0]);  // 06004B9E mov.b r0,@r1
    { const uint32_t x = c.r[10]; c.pr = 0x06004BA4u; st8(c.r[2], c.r[8]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004BA4u) return; }  // 06004BA0 jsr @r10 ; mov.b r8,@r2
    c.r[9] = ld32(0x06004C7Cu);  // 06004BA4 mov.l 0x06004C7C,r9
    c.r[0] = ld32(0x06004C80u);  // 06004BA6 mov.l 0x06004C80,r0
    c.r[6] = 0x0u;  // 06004BA8 mov #0,r6
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06004BAA mov.b @r9,r4
    c.r[5] = 0x0u;  // 06004BAC mov #0,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06004BB2u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004BB2u) return; }  // 06004BAE jsr @r0 ; extu.b r4,r4
    c.r[1] = ld32(0x06004C84u);  // 06004BB2 mov.l 0x06004C84,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06004BB4 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06004BB6 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06004BB8 tst r1,r1
    if (c.t) { goto L_06004BC2; }  // 06004BBA bt 0x06004BC2
    c.r[1] = ld32(0x06004C88u);  // 06004BBC mov.l 0x06004C88,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06004BC2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004BC2u) return; }  // 06004BBE jsr @r1 ; nop
L_06004BC2:
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06004BC2 mov.b @r9,r4
    c.r[0] = ld32(0x06004C8Cu);  // 06004BC4 mov.l 0x06004C8C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06004BCAu; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004BCAu) return; }  // 06004BC6 jsr @r0 ; extu.b r4,r4
    c.r[1] = ld32(0x06004C90u);  // 06004BCA mov.l 0x06004C90,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06004BD0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004BD0u) return; }  // 06004BCC jsr @r1 ; nop
    { const uint32_t x = c.r[10]; c.pr = 0x06004BD4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004BD4u) return; }  // 06004BD0 jsr @r10 ; nop
    c.r[1] = ld32(0x06004C94u);  // 06004BD4 mov.l 0x06004C94,r1
    st8(c.r[1], c.r[8]);  // 06004BD6 mov.b r8,@r1
    c.r[1] = ld32(0x06004C98u);  // 06004BD8 mov.l 0x06004C98,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06004BDEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004BDEu) return; }  // 06004BDA jsr @r1 ; nop
    c.r[1] = ld32(0x06004C9Cu);  // 06004BDE mov.l 0x06004C9C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06004BE4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004BE4u) return; }  // 06004BE0 jsr @r1 ; nop
    c.r[2] = ld32(0x06004CA0u);  // 06004BE4 mov.l 0x06004CA0,r2
    c.r[1] = 0x1u;  // 06004BE6 mov #1,r1
    st8(c.r[2], c.r[1]);  // 06004BE8 mov.b r1,@r2
    c.r[1] = ld32(0x06004CA4u);  // 06004BEA mov.l 0x06004CA4,r1
    c.r[2] = 0x0u;  // 06004BEC mov #0,r2
    st16(c.r[1], c.r[2]);  // 06004BEE mov.w r2,@r1
    c.r[1] = ld32(0x06004CA8u);  // 06004BF0 mov.l 0x06004CA8,r1
    st16(c.r[1], c.r[2]);  // 06004BF2 mov.w r2,@r1
    c.r[1] = ld32(0x06004CACu);  // 06004BF4 mov.l 0x06004CAC,r1
    c.r[6] = 0x0u;  // 06004BF6 mov #0,r6
    c.r[5] = 0x0u;  // 06004BF8 mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06004BFEu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004BFEu) return; }  // 06004BFA jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06004CB0u);  // 06004BFE mov.l 0x06004CB0,r1
    st8(c.r[1], c.r[8]);  // 06004C00 mov.b r8,@r1
    c.r[1] = ld32(0x06004CB4u);  // 06004C02 mov.l 0x06004CB4,r1
    st8(c.r[1], c.r[8]);  // 06004C04 mov.b r8,@r1
    c.r[1] = ld32(0x06004CB8u);  // 06004C06 mov.l 0x06004CB8,r1
    st8(c.r[1], c.r[8]);  // 06004C08 mov.b r8,@r1
    c.r[1] = ld32(0x06004CBCu);  // 06004C0A mov.l 0x06004CBC,r1
    st8(c.r[1], c.r[8]);  // 06004C0C mov.b r8,@r1
    c.r[1] = ld32(0x06004CC0u);  // 06004C0E mov.l 0x06004CC0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06004C14u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004C14u) return; }  // 06004C10 jsr @r1 ; mov #1,r4
    c.r[2] = ld32(0x06004CC4u);  // 06004C14 mov.l 0x06004CC4,r2
    c.r[7] = ld32(0x06004C60u);  // 06004C16 mov.l 0x06004C60,r7
    c.r[6] = c.r[2];  // 06004C18 mov r2,r6
    c.r[3] = ld32(c.r[7] + 4);  // 06004C1A mov.l @(4,r7),r3
    c.r[6] += 70;  // 06004C1C add #70,r6
    c.r[1] = c.r[3];  // 06004C1E mov r3,r1
    c.r[1] += 1;  // 06004C20 add #1,r1
    st32(c.r[2], c.r[1]);  // 06004C22 mov.l r1,@r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06004C24 mov.b @r3,r1
    c.r[7] += 8;  // 06004C26 add #8,r7
    st8(c.r[6], c.r[1]);  // 06004C28 mov.b r1,@r6
    c.r[3] = c.r[2];  // 06004C2A mov r2,r3
    c.r[3] += 72;  // 06004C2C add #72,r3
    c.r[1] = 0x0u;  // 06004C2E mov #0,r1
    st32(c.r[3], c.r[1]);  // 06004C30 mov.l r1,@r3
    c.r[1] = c.r[2];  // 06004C32 mov r2,r1
    c.r[1] += 69;  // 06004C34 add #69,r1
    st8(c.r[1], c.r[8]);  // 06004C36 mov.b r8,@r1
    c.r[3] = c.r[2];  // 06004C38 mov r2,r3
    c.r[3] += 68;  // 06004C3A add #68,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06004C3C mov.b @r7,r1
    c.r[2] += 71;  // 06004C3E add #71,r2
    st8(c.r[3], c.r[1]);  // 06004C40 mov.b r1,@r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06004C42 mov.b @r2,r0
    c.r[0] |= 0x80u;  // 06004C44 or #128,r0
    c.r[0] &= 0xBFu;  // 06004C46 and #191,r0
    { const uint32_t x = c.r[10]; c.pr = 0x06004C4Cu; st8(c.r[2], c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004C4Cu) return; }  // 06004C48 jsr @r10 ; mov.b r0,@r2
L_06004C4C:
    c.r[15] = c.r[14];  // 06004C4C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06004C4E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06004C50 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06004C52 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06004C54 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06004C56 rts ; mov.l @r15+,r8
}

void f_0600490E(SH2Context& c) {
    ran[12] = 1;
    c.r[1] = ld32(0x06004A68u);  // 0600490E mov.l 0x06004A68,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06004910 mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06004912 extu.b r1,r0
    c.r[0] >>= 2;  // 06004914 shlr2 r0
    c.r[0] >>= 2;  // 06004916 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06004918 shlr r0
    c.r[0] >>= 2;  // 0600491A shlr2 r0
    c.t = c.r[0] == 0x1u;  // 0600491C cmp/eq #1,r0
    if (c.t) { goto L_06004924; }  // 0600491E bt 0x06004924
    goto L_06004B14;  // 06004920 bra 0x06004B14 ; nop
L_06004924:
    c.r[0] = ld32(0x06004A6Cu);  // 06004924 mov.l 0x06004A6C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0600492Au; c.r[4] = 0xFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600492Au) return; }  // 06004926 jsr @r0 ; mov #15,r4
    c.r[1] = c.r[0] & 0xFFFFu;  // 0600492A extu.w r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0600492C tst r1,r1
    if (c.t) { goto L_06004938; }  // 0600492E bt 0x06004938
    c.r[1] = ld32(0x06004A70u);  // 06004930 mov.l 0x06004A70,r1
    c.r[1] = ld32(c.r[1]);  // 06004932 mov.l @r1,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06004938u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004938u) return; }  // 06004934 jsr @r1 ; nop
L_06004938:
    c.r[0] = ld32(0x06004A74u);  // 06004938 mov.l 0x06004A74,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0600493Eu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600493Eu) return; }  // 0600493A jsr @r0 ; mov #0,r4
    c.r[0] = ld32(0x06004A78u);  // 0600493E mov.l 0x06004A78,r0
    c.r[6] = 0x0u;  // 06004940 mov #0,r6
    c.r[5] = 0x0u;  // 06004942 mov #0,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06004948u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004948u) return; }  // 06004944 jsr @r0 ; mov #0,r4
    c.r[4] = ld32(0x06004A7Cu);  // 06004948 mov.l 0x06004A7C,r4
    c.r[1] = c.r[4];  // 0600494A mov r4,r1
    c.r[1] += 66;  // 0600494C add #66,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0600494E mov.w @r1,r1
    c.r[0] = c.r[1] & 0xFFFFu;  // 06004950 extu.w r1,r0
    c.t = c.r[0] == 0x20u;  // 06004952 cmp/eq #32,r0
    if (!c.t) { goto L_0600495C; }  // 06004954 bf 0x0600495C
    c.r[1] = ld32(0x06004A80u);  // 06004956 mov.l 0x06004A80,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0600495Cu; c.r[4] = ld32(c.r[4]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600495Cu) return; }  // 06004958 jsr @r1 ; mov.l @r4,r4
L_0600495C:
    c.r[1] = ld32(0x06004A84u);  // 0600495C mov.l 0x06004A84,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0600495E mov.b @r1,r4
    c.r[8] = ld32(0x06004A88u);  // 06004960 mov.l 0x06004A88,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06004966u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004966u) return; }  // 06004962 jsr @r8 ; extu.b r4,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0600496Au; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600496Au) return; }  // 06004966 jsr @r8 ; mov #0,r4
    c.r[0] = ld32(0x06004A8Cu);  // 0600496A mov.l 0x06004A8C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06004970u; c.r[9] = 0xFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004970u) return; }  // 0600496C jsr @r0 ; mov #15,r9
    c.r[2] = 0x0u;  // 06004970 mov #0,r2
    c.r[3] = 0x0u;  // 06004972 mov #0,r3
    c.r[6] = ld32(0x06004A90u);  // 06004974 mov.l 0x06004A90,r6
    c.r[7] = ld32(0x06004A94u);  // 06004976 mov.l 0x06004A94,r7
L_06004978:
    c.r[1] = c.r[2] & 0xFFu;  // 06004978 extu.b r2,r1
    c.t = c.r[1] > c.r[9];  // 0600497A cmp/hi r9,r1
    { const bool k = c.t; c.r[0] = c.r[1]; if (k) { goto L_06004986; } }  // 0600497C bt/s 0x06004986 ; mov r1,r0
    c.r[0] <<= 2;  // 06004980 shll2 r0
    st32(c.r[0] + c.r[6], c.r[3]);  // 06004982 mov.l r3,@(r0,r6)
    c.t = c.r[1] > c.r[9];  // 06004984 cmp/hi r9,r1
L_06004986:
    { const bool k = c.t; c.r[1] <<= 2; if (k) { goto L_0600498E; } }  // 06004986 bt/s 0x0600498E ; shll2 r1
    c.r[0] = c.r[1];  // 0600498A mov r1,r0
    st32(c.r[0] + c.r[7], c.r[3]);  // 0600498C mov.l r3,@(r0,r7)
L_0600498E:
    c.r[2] += 1;  // 0600498E add #1,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[9];  // 06004990 cmp/gt r9,r2
    if (!c.t) { SH2_POLL(c); goto L_06004978; }  // 06004992 bf 0x06004978
    c.r[8] = ld32(0x06004A98u);  // 06004994 mov.l 0x06004A98,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0600499Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600499Au) return; }  // 06004996 jsr @r8 ; nop
    c.r[1] = ld32(0x06004A9Cu);  // 0600499A mov.l 0x06004A9C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060049A0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060049A0u) return; }  // 0600499C jsr @r1 ; nop
    { const uint32_t x = c.r[8]; c.pr = 0x060049A4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060049A4u) return; }  // 060049A0 jsr @r8 ; nop
    c.r[2] = 0x0u;  // 060049A4 mov #0,r2
    c.r[7] = c.r[9];  // 060049A6 mov r9,r7
    c.r[3] = 0x0u;  // 060049A8 mov #0,r3
    c.r[1] = ld32(0x06004AA0u);  // 060049AA mov.l 0x06004AA0,r1
L_060049AC:
    st32(c.r[1] + 4, c.r[3]);  // 060049AC mov.l r3,@(4,r1)
    c.r[2] += 1;  // 060049AE add #1,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[7];  // 060049B0 cmp/gt r7,r2
    { const bool k = !c.t; c.r[1] += 4; if (k) { SH2_POLL(c); goto L_060049AC; } }  // 060049B2 bf/s 0x060049AC ; add #4,r1
    c.r[9] = ld32(0x06004AA4u);  // 060049B6 mov.l 0x06004AA4,r9
    { const uint32_t x = c.r[9]; c.pr = 0x060049BCu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060049BCu) return; }  // 060049B8 jsr @r9 ; mov #0,r4
    c.r[10] = ld32(0x06004A98u);  // 060049BC mov.l 0x06004A98,r10
    { const uint32_t x = c.r[10]; c.pr = 0x060049C2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060049C2u) return; }  // 060049BE jsr @r10 ; nop
    c.r[1] = ld32(0x06004AA8u);  // 060049C2 mov.l 0x06004AA8,r1
    c.r[6] = 0xFFFFFFFFu;  // 060049C4 mov #-1,r6
    c.r[5] = 0x0u;  // 060049C6 mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x060049CCu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060049CCu) return; }  // 060049C8 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06004A9Cu);  // 060049CC mov.l 0x06004A9C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060049D2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060049D2u) return; }  // 060049CE jsr @r1 ; nop
    c.r[1] = ld32(0x06004AACu);  // 060049D2 mov.l 0x06004AAC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060049D8u; c.r[4] = 0x3u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060049D8u) return; }  // 060049D4 jsr @r1 ; mov #3,r4
    c.r[1] = ld32(0x06004AB0u);  // 060049D8 mov.l 0x06004AB0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060049DEu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060049DEu) return; }  // 060049DA jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06004AB4u);  // 060049DE mov.l 0x06004AB4,r1
    c.r[4] = ld32(0x06004AB8u);  // 060049E0 mov.l 0x06004AB8,r4
    { const uint32_t x = c.r[1]; c.pr = 0x060049E6u; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060049E6u) return; }  // 060049E2 jsr @r1 ; mov #0,r5
    c.r[1] = ld32(0x06004ABCu);  // 060049E6 mov.l 0x06004ABC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060049ECu; c.r[4] = 0x5Fu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060049ECu) return; }  // 060049E8 jsr @r1 ; mov #95,r4
    c.r[1] = ld32(0x06004AC0u);  // 060049EC mov.l 0x06004AC0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060049F2u; c.r[4] = 0x8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060049F2u) return; }  // 060049EE jsr @r1 ; mov #8,r4
    c.r[1] = ld32(0x06004AC4u);  // 060049F2 mov.l 0x06004AC4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060049F8u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060049F8u) return; }  // 060049F4 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06004AC8u);  // 060049F8 mov.l 0x06004AC8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060049FEu; c.r[4] = 0x6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060049FEu) return; }  // 060049FA jsr @r1 ; mov #6,r4
    c.r[2] = ld32(0x06004ACCu);  // 060049FE mov.l 0x06004ACC,r2
    c.r[1] = 0x0u;  // 06004A00 mov #0,r1
    st32(c.r[2], c.r[1]);  // 06004A02 mov.l r1,@r2
    c.r[1] = ld32(0x06004AD0u);  // 06004A04 mov.l 0x06004AD0,r1
    c.r[8] = 0x1u;  // 06004A06 mov #1,r8
    c.r[4] = ld32(0x06004AD4u);  // 06004A08 mov.l 0x06004AD4,r4
    { const uint32_t x = c.r[9]; c.pr = 0x06004A0Eu; st8(c.r[1], c.r[8]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004A0Eu) return; }  // 06004A0A jsr @r9 ; mov.b r8,@r1
    c.r[1] = ld32(0x06004AD8u);  // 06004A0E mov.l 0x06004AD8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06004A14u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004A14u) return; }  // 06004A10 jsr @r1 ; nop
    { const uint32_t x = c.r[10]; c.pr = 0x06004A18u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004A18u) return; }  // 06004A14 jsr @r10 ; nop
    c.r[2] = ld32(0x06004ADCu);  // 06004A18 mov.l 0x06004ADC,r2
    c.r[1] = 0x0u;  // 06004A1A mov #0,r1
    st8(c.r[2], c.r[1]);  // 06004A1C mov.b r1,@r2
    c.r[1] = ld32(0x06004AE0u);  // 06004A1E mov.l 0x06004AE0,r1
    st8(c.r[1], c.r[8]);  // 06004A20 mov.b r8,@r1
    c.r[1] = ld32(0x06004AE4u);  // 06004A22 mov.l 0x06004AE4,r1
    c.r[5] = 0x0u;  // 06004A24 mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06004A2Au; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004A2Au) return; }  // 06004A26 jsr @r1 ; mov #0,r4
    c.r[7] = ld32(0x06004AE8u);  // 06004A2A mov.l 0x06004AE8,r7
    c.r[8] = ld32(0x06004AECu);  // 06004A2C mov.l 0x06004AEC,r8
    c.r[4] = ld32(0x06004AF0u);  // 06004A2E mov.l 0x06004AF0,r4
    c.r[0] = ld32(0x06004AF4u);  // 06004A30 mov.l 0x06004AF4,r0
    c.r[6] = c.r[8];  // 06004A32 mov r8,r6
    { const uint32_t x = c.r[0]; c.pr = 0x06004A38u; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004A38u) return; }  // 06004A34 jsr @r0 ; mov #0,r5
    c.r[1] = ld32(0x06004AF8u);  // 06004A38 mov.l 0x06004AF8,r1
    { const uint32_t x = c.r[10]; c.pr = 0x06004A3Eu; st32(c.r[1], c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004A3Eu) return; }  // 06004A3A jsr @r10 ; mov.l r0,@r1
    c.r[0] = ld32(0x06004AFCu);  // 06004A3E mov.l 0x06004AFC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06004A44u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004A44u) return; }  // 06004A40 jsr @r0 ; nop
    c.r[0] &= 0x20u;  // 06004A44 and #32,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06004A46 tst r0,r0
    if (c.t) { goto L_06004A50; }  // 06004A48 bt 0x06004A50
    c.r[1] = ld32(0x06004B00u);  // 06004A4A mov.l 0x06004B00,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06004A50u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004A50u) return; }  // 06004A4C jsr @r1 ; mov #1,r4
L_06004A50:
    c.r[5] = ld32(0x06004B04u);  // 06004A50 mov.l 0x06004B04,r5
    c.r[0] = ld32(0x06004B08u);  // 06004A52 mov.l 0x06004B08,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06004A58u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004A58u) return; }  // 06004A54 jsr @r0 ; mov r8,r4
    c.r[1] = ld32(0x06004B0Cu);  // 06004A58 mov.l 0x06004B0C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06004A5Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004A5Eu) return; }  // 06004A5A jsr @r1 ; nop
    goto L_06004B10;  // 06004A5E bra 0x06004B10 ; nop
L_06004B10:
    { const uint32_t x = c.r[10]; c.pr = 0x06004B14u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004B14u) return; }  // 06004B10 jsr @r10 ; nop
L_06004B14:
    c.r[1] = ld32(0x06004C5Cu);  // 06004B14 mov.l 0x06004C5C,r1
    c.r[1] = ld32(c.r[1]);  // 06004B16 mov.l @r1,r1
    c.r[1] += 4;  // 06004B18 add #4,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06004B1A mov.w @r1,r1
    c.r[0] = ~c.r[1];  // 06004B1C not r1,r0
    c.r[0] >>= 8;  // 06004B1E shlr8 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06004B20 shlr r0
    c.r[0] >>= 2;  // 06004B22 shlr2 r0
    c.r[0] &= 0x1u;  // 06004B24 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06004B26 tst r0,r0
    if (!c.t) { goto L_06004B2E; }  // 06004B28 bf 0x06004B2E
    goto L_06004C4C;  // 06004B2A bra 0x06004C4C ; nop
L_06004B2E:
    c.r[2] = ld32(0x06004C60u);  // 06004B2E mov.l 0x06004C60,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06004B30 mov.b @r2,r1
    c.r[0] = c.r[1];  // 06004B32 mov r1,r0
    c.r[0] >>= 2;  // 06004B34 shlr2 r0
    c.r[0] >>= 2;  // 06004B36 shlr2 r0
    c.r[0] &= 0x1u;  // 06004B38 and #1,r0
    c.t = c.r[0] == 0x1u;  // 06004B3A cmp/eq #1,r0
    { const bool k = c.t; c.r[7] = 0x0u; if (k) { goto L_06004B44; } }  // 06004B3C bt/s 0x06004B44 ; mov #0,r7
    goto L_06004C4C;  // 06004B40 bra 0x06004C4C ; nop
L_06004B44:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06004B44 mov.b @r2,r0
    c.r[3] = 0xFu;  // 06004B46 mov #15,r3
    c.r[0] &= 0xEFu;  // 06004B48 and #239,r0
    st8(c.r[2], c.r[0]);  // 06004B4A mov.b r0,@r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06004B4C mov.b @r2,r0
    c.r[1] = ld32(0x06004C64u);  // 06004B4E mov.l 0x06004C64,r1
    c.r[0] |= 0x8u;  // 06004B50 or #8,r0
    st8(c.r[2], c.r[0]);  // 06004B52 mov.b r0,@r2
    c.r[2] = 0x0u;  // 06004B54 mov #0,r2
    c.r[6] = c.r[2] & 0xFFu;  // 06004B56 extu.b r2,r6
L_06004B58:
    c.t = c.r[6] > c.r[3];  // 06004B58 cmp/hi r3,r6
    { const bool k = c.t; c.r[6] <<= 2; if (k) { goto L_06004B62; } }  // 06004B5A bt/s 0x06004B62 ; shll2 r6
    c.r[0] = c.r[6];  // 06004B5E mov r6,r0
    st32(c.r[0] + c.r[1], c.r[7]);  // 06004B60 mov.l r7,@(r0,r1)
L_06004B62:
    c.r[2] += 1;  // 06004B62 add #1,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[3];  // 06004B64 cmp/gt r3,r2
    { const bool k = !c.t; c.r[6] = c.r[2] & 0xFFu; if (k) { SH2_POLL(c); goto L_06004B58; } }  // 06004B66 bf/s 0x06004B58 ; extu.b r2,r6
    c.r[2] = 0x0u;  // 06004B6A mov #0,r2
    c.r[1] = ld32(0x06004C68u);  // 06004B6C mov.l 0x06004C68,r1
    st32(c.r[1], c.r[2]);  // 06004B6E mov.l r2,@r1
    st32(c.r[1] + 8, c.r[2]);  // 06004B70 mov.l r2,@(8,r1)
    c.r[2] = 0x6u;  // 06004B72 mov #6,r2
    c.r[7] = 0x0u;  // 06004B74 mov #0,r7
    c.r[6] = c.r[2] & 0xFFu;  // 06004B76 extu.b r2,r6
L_06004B78:
    c.t = c.r[6] > c.r[3];  // 06004B78 cmp/hi r3,r6
    { const bool k = c.t; c.r[6] <<= 2; if (k) { goto L_06004B82; } }  // 06004B7A bt/s 0x06004B82 ; shll2 r6
    c.r[0] = c.r[6];  // 06004B7E mov r6,r0
    st32(c.r[0] + c.r[1], c.r[7]);  // 06004B80 mov.l r7,@(r0,r1)
L_06004B82:
    c.r[2] += 1;  // 06004B82 add #1,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[3];  // 06004B84 cmp/gt r3,r2
    { const bool k = !c.t; c.r[6] = c.r[2] & 0xFFu; if (k) { SH2_POLL(c); goto L_06004B78; } }  // 06004B86 bf/s 0x06004B78 ; extu.b r2,r6
    c.r[10] = ld32(0x06004C6Cu);  // 06004B8A mov.l 0x06004C6C,r10
    { const uint32_t x = c.r[10]; c.pr = 0x06004B90u; c.r[8] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004B90u) return; }  // 06004B8C jsr @r10 ; mov #0,r8
    c.r[1] = ld32(0x06004C70u);  // 06004B90 mov.l 0x06004C70,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06004B96u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004B96u) return; }  // 06004B92 jsr @r1 ; nop
    c.r[2] = ld32(0x06004C74u);  // 06004B96 mov.l 0x06004C74,r2
    c.r[1] = ld32(0x06004C78u);  // 06004B98 mov.l 0x06004C78,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06004B9A mov.b @r1,r0
    c.r[0] &= 0x7Fu;  // 06004B9C and #127,r0
    st8(c.r[1], c.r[0]);  // 06004B9E mov.b r0,@r1
    { const uint32_t x = c.r[10]; c.pr = 0x06004BA4u; st8(c.r[2], c.r[8]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004BA4u) return; }  // 06004BA0 jsr @r10 ; mov.b r8,@r2
    c.r[9] = ld32(0x06004C7Cu);  // 06004BA4 mov.l 0x06004C7C,r9
    c.r[0] = ld32(0x06004C80u);  // 06004BA6 mov.l 0x06004C80,r0
    c.r[6] = 0x0u;  // 06004BA8 mov #0,r6
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06004BAA mov.b @r9,r4
    c.r[5] = 0x0u;  // 06004BAC mov #0,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06004BB2u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004BB2u) return; }  // 06004BAE jsr @r0 ; extu.b r4,r4
    c.r[1] = ld32(0x06004C84u);  // 06004BB2 mov.l 0x06004C84,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06004BB4 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06004BB6 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06004BB8 tst r1,r1
    if (c.t) { goto L_06004BC2; }  // 06004BBA bt 0x06004BC2
    c.r[1] = ld32(0x06004C88u);  // 06004BBC mov.l 0x06004C88,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06004BC2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004BC2u) return; }  // 06004BBE jsr @r1 ; nop
L_06004BC2:
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06004BC2 mov.b @r9,r4
    c.r[0] = ld32(0x06004C8Cu);  // 06004BC4 mov.l 0x06004C8C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06004BCAu; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004BCAu) return; }  // 06004BC6 jsr @r0 ; extu.b r4,r4
    c.r[1] = ld32(0x06004C90u);  // 06004BCA mov.l 0x06004C90,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06004BD0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004BD0u) return; }  // 06004BCC jsr @r1 ; nop
    { const uint32_t x = c.r[10]; c.pr = 0x06004BD4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004BD4u) return; }  // 06004BD0 jsr @r10 ; nop
    c.r[1] = ld32(0x06004C94u);  // 06004BD4 mov.l 0x06004C94,r1
    st8(c.r[1], c.r[8]);  // 06004BD6 mov.b r8,@r1
    c.r[1] = ld32(0x06004C98u);  // 06004BD8 mov.l 0x06004C98,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06004BDEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004BDEu) return; }  // 06004BDA jsr @r1 ; nop
    c.r[1] = ld32(0x06004C9Cu);  // 06004BDE mov.l 0x06004C9C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06004BE4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004BE4u) return; }  // 06004BE0 jsr @r1 ; nop
    c.r[2] = ld32(0x06004CA0u);  // 06004BE4 mov.l 0x06004CA0,r2
    c.r[1] = 0x1u;  // 06004BE6 mov #1,r1
    st8(c.r[2], c.r[1]);  // 06004BE8 mov.b r1,@r2
    c.r[1] = ld32(0x06004CA4u);  // 06004BEA mov.l 0x06004CA4,r1
    c.r[2] = 0x0u;  // 06004BEC mov #0,r2
    st16(c.r[1], c.r[2]);  // 06004BEE mov.w r2,@r1
    c.r[1] = ld32(0x06004CA8u);  // 06004BF0 mov.l 0x06004CA8,r1
    st16(c.r[1], c.r[2]);  // 06004BF2 mov.w r2,@r1
    c.r[1] = ld32(0x06004CACu);  // 06004BF4 mov.l 0x06004CAC,r1
    c.r[6] = 0x0u;  // 06004BF6 mov #0,r6
    c.r[5] = 0x0u;  // 06004BF8 mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06004BFEu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004BFEu) return; }  // 06004BFA jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06004CB0u);  // 06004BFE mov.l 0x06004CB0,r1
    st8(c.r[1], c.r[8]);  // 06004C00 mov.b r8,@r1
    c.r[1] = ld32(0x06004CB4u);  // 06004C02 mov.l 0x06004CB4,r1
    st8(c.r[1], c.r[8]);  // 06004C04 mov.b r8,@r1
    c.r[1] = ld32(0x06004CB8u);  // 06004C06 mov.l 0x06004CB8,r1
    st8(c.r[1], c.r[8]);  // 06004C08 mov.b r8,@r1
    c.r[1] = ld32(0x06004CBCu);  // 06004C0A mov.l 0x06004CBC,r1
    st8(c.r[1], c.r[8]);  // 06004C0C mov.b r8,@r1
    c.r[1] = ld32(0x06004CC0u);  // 06004C0E mov.l 0x06004CC0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06004C14u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004C14u) return; }  // 06004C10 jsr @r1 ; mov #1,r4
    c.r[2] = ld32(0x06004CC4u);  // 06004C14 mov.l 0x06004CC4,r2
    c.r[7] = ld32(0x06004C60u);  // 06004C16 mov.l 0x06004C60,r7
    c.r[6] = c.r[2];  // 06004C18 mov r2,r6
    c.r[3] = ld32(c.r[7] + 4);  // 06004C1A mov.l @(4,r7),r3
    c.r[6] += 70;  // 06004C1C add #70,r6
    c.r[1] = c.r[3];  // 06004C1E mov r3,r1
    c.r[1] += 1;  // 06004C20 add #1,r1
    st32(c.r[2], c.r[1]);  // 06004C22 mov.l r1,@r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06004C24 mov.b @r3,r1
    c.r[7] += 8;  // 06004C26 add #8,r7
    st8(c.r[6], c.r[1]);  // 06004C28 mov.b r1,@r6
    c.r[3] = c.r[2];  // 06004C2A mov r2,r3
    c.r[3] += 72;  // 06004C2C add #72,r3
    c.r[1] = 0x0u;  // 06004C2E mov #0,r1
    st32(c.r[3], c.r[1]);  // 06004C30 mov.l r1,@r3
    c.r[1] = c.r[2];  // 06004C32 mov r2,r1
    c.r[1] += 69;  // 06004C34 add #69,r1
    st8(c.r[1], c.r[8]);  // 06004C36 mov.b r8,@r1
    c.r[3] = c.r[2];  // 06004C38 mov r2,r3
    c.r[3] += 68;  // 06004C3A add #68,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06004C3C mov.b @r7,r1
    c.r[2] += 71;  // 06004C3E add #71,r2
    st8(c.r[3], c.r[1]);  // 06004C40 mov.b r1,@r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06004C42 mov.b @r2,r0
    c.r[0] |= 0x80u;  // 06004C44 or #128,r0
    c.r[0] &= 0xBFu;  // 06004C46 and #191,r0
    { const uint32_t x = c.r[10]; c.pr = 0x06004C4Cu; st8(c.r[2], c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004C4Cu) return; }  // 06004C48 jsr @r10 ; mov.b r0,@r2
L_06004C4C:
    c.r[15] = c.r[14];  // 06004C4C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06004C4E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06004C50 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06004C52 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06004C54 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06004C56 rts ; mov.l @r15+,r8
}

void f_06004924(SH2Context& c) {
    ran[13] = 1;
    c.r[0] = ld32(0x06004A6Cu);  // 06004924 mov.l 0x06004A6C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0600492Au; c.r[4] = 0xFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600492Au) return; }  // 06004926 jsr @r0 ; mov #15,r4
    c.r[1] = c.r[0] & 0xFFFFu;  // 0600492A extu.w r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0600492C tst r1,r1
    if (c.t) { goto L_06004938; }  // 0600492E bt 0x06004938
    c.r[1] = ld32(0x06004A70u);  // 06004930 mov.l 0x06004A70,r1
    c.r[1] = ld32(c.r[1]);  // 06004932 mov.l @r1,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06004938u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004938u) return; }  // 06004934 jsr @r1 ; nop
L_06004938:
    c.r[0] = ld32(0x06004A74u);  // 06004938 mov.l 0x06004A74,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0600493Eu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600493Eu) return; }  // 0600493A jsr @r0 ; mov #0,r4
    c.r[0] = ld32(0x06004A78u);  // 0600493E mov.l 0x06004A78,r0
    c.r[6] = 0x0u;  // 06004940 mov #0,r6
    c.r[5] = 0x0u;  // 06004942 mov #0,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06004948u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004948u) return; }  // 06004944 jsr @r0 ; mov #0,r4
    c.r[4] = ld32(0x06004A7Cu);  // 06004948 mov.l 0x06004A7C,r4
    c.r[1] = c.r[4];  // 0600494A mov r4,r1
    c.r[1] += 66;  // 0600494C add #66,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0600494E mov.w @r1,r1
    c.r[0] = c.r[1] & 0xFFFFu;  // 06004950 extu.w r1,r0
    c.t = c.r[0] == 0x20u;  // 06004952 cmp/eq #32,r0
    if (!c.t) { goto L_0600495C; }  // 06004954 bf 0x0600495C
    c.r[1] = ld32(0x06004A80u);  // 06004956 mov.l 0x06004A80,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0600495Cu; c.r[4] = ld32(c.r[4]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600495Cu) return; }  // 06004958 jsr @r1 ; mov.l @r4,r4
L_0600495C:
    c.r[1] = ld32(0x06004A84u);  // 0600495C mov.l 0x06004A84,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0600495E mov.b @r1,r4
    c.r[8] = ld32(0x06004A88u);  // 06004960 mov.l 0x06004A88,r8
    { const uint32_t x = c.r[8]; c.pr = 0x06004966u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004966u) return; }  // 06004962 jsr @r8 ; extu.b r4,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0600496Au; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600496Au) return; }  // 06004966 jsr @r8 ; mov #0,r4
    c.r[0] = ld32(0x06004A8Cu);  // 0600496A mov.l 0x06004A8C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06004970u; c.r[9] = 0xFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004970u) return; }  // 0600496C jsr @r0 ; mov #15,r9
    c.r[2] = 0x0u;  // 06004970 mov #0,r2
    c.r[3] = 0x0u;  // 06004972 mov #0,r3
    c.r[6] = ld32(0x06004A90u);  // 06004974 mov.l 0x06004A90,r6
    c.r[7] = ld32(0x06004A94u);  // 06004976 mov.l 0x06004A94,r7
L_06004978:
    c.r[1] = c.r[2] & 0xFFu;  // 06004978 extu.b r2,r1
    c.t = c.r[1] > c.r[9];  // 0600497A cmp/hi r9,r1
    { const bool k = c.t; c.r[0] = c.r[1]; if (k) { goto L_06004986; } }  // 0600497C bt/s 0x06004986 ; mov r1,r0
    c.r[0] <<= 2;  // 06004980 shll2 r0
    st32(c.r[0] + c.r[6], c.r[3]);  // 06004982 mov.l r3,@(r0,r6)
    c.t = c.r[1] > c.r[9];  // 06004984 cmp/hi r9,r1
L_06004986:
    { const bool k = c.t; c.r[1] <<= 2; if (k) { goto L_0600498E; } }  // 06004986 bt/s 0x0600498E ; shll2 r1
    c.r[0] = c.r[1];  // 0600498A mov r1,r0
    st32(c.r[0] + c.r[7], c.r[3]);  // 0600498C mov.l r3,@(r0,r7)
L_0600498E:
    c.r[2] += 1;  // 0600498E add #1,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[9];  // 06004990 cmp/gt r9,r2
    if (!c.t) { SH2_POLL(c); goto L_06004978; }  // 06004992 bf 0x06004978
    c.r[8] = ld32(0x06004A98u);  // 06004994 mov.l 0x06004A98,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0600499Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600499Au) return; }  // 06004996 jsr @r8 ; nop
    c.r[1] = ld32(0x06004A9Cu);  // 0600499A mov.l 0x06004A9C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060049A0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060049A0u) return; }  // 0600499C jsr @r1 ; nop
    { const uint32_t x = c.r[8]; c.pr = 0x060049A4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060049A4u) return; }  // 060049A0 jsr @r8 ; nop
    c.r[2] = 0x0u;  // 060049A4 mov #0,r2
    c.r[7] = c.r[9];  // 060049A6 mov r9,r7
    c.r[3] = 0x0u;  // 060049A8 mov #0,r3
    c.r[1] = ld32(0x06004AA0u);  // 060049AA mov.l 0x06004AA0,r1
L_060049AC:
    st32(c.r[1] + 4, c.r[3]);  // 060049AC mov.l r3,@(4,r1)
    c.r[2] += 1;  // 060049AE add #1,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[7];  // 060049B0 cmp/gt r7,r2
    { const bool k = !c.t; c.r[1] += 4; if (k) { SH2_POLL(c); goto L_060049AC; } }  // 060049B2 bf/s 0x060049AC ; add #4,r1
    c.r[9] = ld32(0x06004AA4u);  // 060049B6 mov.l 0x06004AA4,r9
    { const uint32_t x = c.r[9]; c.pr = 0x060049BCu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060049BCu) return; }  // 060049B8 jsr @r9 ; mov #0,r4
    c.r[10] = ld32(0x06004A98u);  // 060049BC mov.l 0x06004A98,r10
    { const uint32_t x = c.r[10]; c.pr = 0x060049C2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060049C2u) return; }  // 060049BE jsr @r10 ; nop
    c.r[1] = ld32(0x06004AA8u);  // 060049C2 mov.l 0x06004AA8,r1
    c.r[6] = 0xFFFFFFFFu;  // 060049C4 mov #-1,r6
    c.r[5] = 0x0u;  // 060049C6 mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x060049CCu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060049CCu) return; }  // 060049C8 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06004A9Cu);  // 060049CC mov.l 0x06004A9C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060049D2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060049D2u) return; }  // 060049CE jsr @r1 ; nop
    c.r[1] = ld32(0x06004AACu);  // 060049D2 mov.l 0x06004AAC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060049D8u; c.r[4] = 0x3u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060049D8u) return; }  // 060049D4 jsr @r1 ; mov #3,r4
    c.r[1] = ld32(0x06004AB0u);  // 060049D8 mov.l 0x06004AB0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060049DEu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060049DEu) return; }  // 060049DA jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06004AB4u);  // 060049DE mov.l 0x06004AB4,r1
    c.r[4] = ld32(0x06004AB8u);  // 060049E0 mov.l 0x06004AB8,r4
    { const uint32_t x = c.r[1]; c.pr = 0x060049E6u; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060049E6u) return; }  // 060049E2 jsr @r1 ; mov #0,r5
    c.r[1] = ld32(0x06004ABCu);  // 060049E6 mov.l 0x06004ABC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060049ECu; c.r[4] = 0x5Fu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060049ECu) return; }  // 060049E8 jsr @r1 ; mov #95,r4
    c.r[1] = ld32(0x06004AC0u);  // 060049EC mov.l 0x06004AC0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060049F2u; c.r[4] = 0x8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060049F2u) return; }  // 060049EE jsr @r1 ; mov #8,r4
    c.r[1] = ld32(0x06004AC4u);  // 060049F2 mov.l 0x06004AC4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060049F8u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060049F8u) return; }  // 060049F4 jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06004AC8u);  // 060049F8 mov.l 0x06004AC8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060049FEu; c.r[4] = 0x6u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060049FEu) return; }  // 060049FA jsr @r1 ; mov #6,r4
    c.r[2] = ld32(0x06004ACCu);  // 060049FE mov.l 0x06004ACC,r2
    c.r[1] = 0x0u;  // 06004A00 mov #0,r1
    st32(c.r[2], c.r[1]);  // 06004A02 mov.l r1,@r2
    c.r[1] = ld32(0x06004AD0u);  // 06004A04 mov.l 0x06004AD0,r1
    c.r[8] = 0x1u;  // 06004A06 mov #1,r8
    c.r[4] = ld32(0x06004AD4u);  // 06004A08 mov.l 0x06004AD4,r4
    { const uint32_t x = c.r[9]; c.pr = 0x06004A0Eu; st8(c.r[1], c.r[8]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004A0Eu) return; }  // 06004A0A jsr @r9 ; mov.b r8,@r1
    c.r[1] = ld32(0x06004AD8u);  // 06004A0E mov.l 0x06004AD8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06004A14u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004A14u) return; }  // 06004A10 jsr @r1 ; nop
    { const uint32_t x = c.r[10]; c.pr = 0x06004A18u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004A18u) return; }  // 06004A14 jsr @r10 ; nop
    c.r[2] = ld32(0x06004ADCu);  // 06004A18 mov.l 0x06004ADC,r2
    c.r[1] = 0x0u;  // 06004A1A mov #0,r1
    st8(c.r[2], c.r[1]);  // 06004A1C mov.b r1,@r2
    c.r[1] = ld32(0x06004AE0u);  // 06004A1E mov.l 0x06004AE0,r1
    st8(c.r[1], c.r[8]);  // 06004A20 mov.b r8,@r1
    c.r[1] = ld32(0x06004AE4u);  // 06004A22 mov.l 0x06004AE4,r1
    c.r[5] = 0x0u;  // 06004A24 mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06004A2Au; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004A2Au) return; }  // 06004A26 jsr @r1 ; mov #0,r4
    c.r[7] = ld32(0x06004AE8u);  // 06004A2A mov.l 0x06004AE8,r7
    c.r[8] = ld32(0x06004AECu);  // 06004A2C mov.l 0x06004AEC,r8
    c.r[4] = ld32(0x06004AF0u);  // 06004A2E mov.l 0x06004AF0,r4
    c.r[0] = ld32(0x06004AF4u);  // 06004A30 mov.l 0x06004AF4,r0
    c.r[6] = c.r[8];  // 06004A32 mov r8,r6
    { const uint32_t x = c.r[0]; c.pr = 0x06004A38u; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004A38u) return; }  // 06004A34 jsr @r0 ; mov #0,r5
    c.r[1] = ld32(0x06004AF8u);  // 06004A38 mov.l 0x06004AF8,r1
    { const uint32_t x = c.r[10]; c.pr = 0x06004A3Eu; st32(c.r[1], c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004A3Eu) return; }  // 06004A3A jsr @r10 ; mov.l r0,@r1
    c.r[0] = ld32(0x06004AFCu);  // 06004A3E mov.l 0x06004AFC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06004A44u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004A44u) return; }  // 06004A40 jsr @r0 ; nop
    c.r[0] &= 0x20u;  // 06004A44 and #32,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06004A46 tst r0,r0
    if (c.t) { goto L_06004A50; }  // 06004A48 bt 0x06004A50
    c.r[1] = ld32(0x06004B00u);  // 06004A4A mov.l 0x06004B00,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06004A50u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004A50u) return; }  // 06004A4C jsr @r1 ; mov #1,r4
L_06004A50:
    c.r[5] = ld32(0x06004B04u);  // 06004A50 mov.l 0x06004B04,r5
    c.r[0] = ld32(0x06004B08u);  // 06004A52 mov.l 0x06004B08,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06004A58u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004A58u) return; }  // 06004A54 jsr @r0 ; mov r8,r4
    c.r[1] = ld32(0x06004B0Cu);  // 06004A58 mov.l 0x06004B0C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06004A5Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004A5Eu) return; }  // 06004A5A jsr @r1 ; nop
    goto L_06004B10;  // 06004A5E bra 0x06004B10 ; nop
L_06004B10:
    { const uint32_t x = c.r[10]; c.pr = 0x06004B14u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004B14u) return; }  // 06004B10 jsr @r10 ; nop
    c.r[1] = ld32(0x06004C5Cu);  // 06004B14 mov.l 0x06004C5C,r1
    c.r[1] = ld32(c.r[1]);  // 06004B16 mov.l @r1,r1
    c.r[1] += 4;  // 06004B18 add #4,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06004B1A mov.w @r1,r1
    c.r[0] = ~c.r[1];  // 06004B1C not r1,r0
    c.r[0] >>= 8;  // 06004B1E shlr8 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06004B20 shlr r0
    c.r[0] >>= 2;  // 06004B22 shlr2 r0
    c.r[0] &= 0x1u;  // 06004B24 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06004B26 tst r0,r0
    if (!c.t) { goto L_06004B2E; }  // 06004B28 bf 0x06004B2E
    goto L_06004C4C;  // 06004B2A bra 0x06004C4C ; nop
L_06004B2E:
    c.r[2] = ld32(0x06004C60u);  // 06004B2E mov.l 0x06004C60,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06004B30 mov.b @r2,r1
    c.r[0] = c.r[1];  // 06004B32 mov r1,r0
    c.r[0] >>= 2;  // 06004B34 shlr2 r0
    c.r[0] >>= 2;  // 06004B36 shlr2 r0
    c.r[0] &= 0x1u;  // 06004B38 and #1,r0
    c.t = c.r[0] == 0x1u;  // 06004B3A cmp/eq #1,r0
    { const bool k = c.t; c.r[7] = 0x0u; if (k) { goto L_06004B44; } }  // 06004B3C bt/s 0x06004B44 ; mov #0,r7
    goto L_06004C4C;  // 06004B40 bra 0x06004C4C ; nop
L_06004B44:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06004B44 mov.b @r2,r0
    c.r[3] = 0xFu;  // 06004B46 mov #15,r3
    c.r[0] &= 0xEFu;  // 06004B48 and #239,r0
    st8(c.r[2], c.r[0]);  // 06004B4A mov.b r0,@r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06004B4C mov.b @r2,r0
    c.r[1] = ld32(0x06004C64u);  // 06004B4E mov.l 0x06004C64,r1
    c.r[0] |= 0x8u;  // 06004B50 or #8,r0
    st8(c.r[2], c.r[0]);  // 06004B52 mov.b r0,@r2
    c.r[2] = 0x0u;  // 06004B54 mov #0,r2
    c.r[6] = c.r[2] & 0xFFu;  // 06004B56 extu.b r2,r6
L_06004B58:
    c.t = c.r[6] > c.r[3];  // 06004B58 cmp/hi r3,r6
    { const bool k = c.t; c.r[6] <<= 2; if (k) { goto L_06004B62; } }  // 06004B5A bt/s 0x06004B62 ; shll2 r6
    c.r[0] = c.r[6];  // 06004B5E mov r6,r0
    st32(c.r[0] + c.r[1], c.r[7]);  // 06004B60 mov.l r7,@(r0,r1)
L_06004B62:
    c.r[2] += 1;  // 06004B62 add #1,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[3];  // 06004B64 cmp/gt r3,r2
    { const bool k = !c.t; c.r[6] = c.r[2] & 0xFFu; if (k) { SH2_POLL(c); goto L_06004B58; } }  // 06004B66 bf/s 0x06004B58 ; extu.b r2,r6
    c.r[2] = 0x0u;  // 06004B6A mov #0,r2
    c.r[1] = ld32(0x06004C68u);  // 06004B6C mov.l 0x06004C68,r1
    st32(c.r[1], c.r[2]);  // 06004B6E mov.l r2,@r1
    st32(c.r[1] + 8, c.r[2]);  // 06004B70 mov.l r2,@(8,r1)
    c.r[2] = 0x6u;  // 06004B72 mov #6,r2
    c.r[7] = 0x0u;  // 06004B74 mov #0,r7
    c.r[6] = c.r[2] & 0xFFu;  // 06004B76 extu.b r2,r6
L_06004B78:
    c.t = c.r[6] > c.r[3];  // 06004B78 cmp/hi r3,r6
    { const bool k = c.t; c.r[6] <<= 2; if (k) { goto L_06004B82; } }  // 06004B7A bt/s 0x06004B82 ; shll2 r6
    c.r[0] = c.r[6];  // 06004B7E mov r6,r0
    st32(c.r[0] + c.r[1], c.r[7]);  // 06004B80 mov.l r7,@(r0,r1)
L_06004B82:
    c.r[2] += 1;  // 06004B82 add #1,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[3];  // 06004B84 cmp/gt r3,r2
    { const bool k = !c.t; c.r[6] = c.r[2] & 0xFFu; if (k) { SH2_POLL(c); goto L_06004B78; } }  // 06004B86 bf/s 0x06004B78 ; extu.b r2,r6
    c.r[10] = ld32(0x06004C6Cu);  // 06004B8A mov.l 0x06004C6C,r10
    { const uint32_t x = c.r[10]; c.pr = 0x06004B90u; c.r[8] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004B90u) return; }  // 06004B8C jsr @r10 ; mov #0,r8
    c.r[1] = ld32(0x06004C70u);  // 06004B90 mov.l 0x06004C70,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06004B96u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004B96u) return; }  // 06004B92 jsr @r1 ; nop
    c.r[2] = ld32(0x06004C74u);  // 06004B96 mov.l 0x06004C74,r2
    c.r[1] = ld32(0x06004C78u);  // 06004B98 mov.l 0x06004C78,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06004B9A mov.b @r1,r0
    c.r[0] &= 0x7Fu;  // 06004B9C and #127,r0
    st8(c.r[1], c.r[0]);  // 06004B9E mov.b r0,@r1
    { const uint32_t x = c.r[10]; c.pr = 0x06004BA4u; st8(c.r[2], c.r[8]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004BA4u) return; }  // 06004BA0 jsr @r10 ; mov.b r8,@r2
    c.r[9] = ld32(0x06004C7Cu);  // 06004BA4 mov.l 0x06004C7C,r9
    c.r[0] = ld32(0x06004C80u);  // 06004BA6 mov.l 0x06004C80,r0
    c.r[6] = 0x0u;  // 06004BA8 mov #0,r6
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06004BAA mov.b @r9,r4
    c.r[5] = 0x0u;  // 06004BAC mov #0,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06004BB2u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004BB2u) return; }  // 06004BAE jsr @r0 ; extu.b r4,r4
    c.r[1] = ld32(0x06004C84u);  // 06004BB2 mov.l 0x06004C84,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06004BB4 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06004BB6 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06004BB8 tst r1,r1
    if (c.t) { goto L_06004BC2; }  // 06004BBA bt 0x06004BC2
    c.r[1] = ld32(0x06004C88u);  // 06004BBC mov.l 0x06004C88,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06004BC2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004BC2u) return; }  // 06004BBE jsr @r1 ; nop
L_06004BC2:
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06004BC2 mov.b @r9,r4
    c.r[0] = ld32(0x06004C8Cu);  // 06004BC4 mov.l 0x06004C8C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06004BCAu; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004BCAu) return; }  // 06004BC6 jsr @r0 ; extu.b r4,r4
    c.r[1] = ld32(0x06004C90u);  // 06004BCA mov.l 0x06004C90,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06004BD0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004BD0u) return; }  // 06004BCC jsr @r1 ; nop
    { const uint32_t x = c.r[10]; c.pr = 0x06004BD4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004BD4u) return; }  // 06004BD0 jsr @r10 ; nop
    c.r[1] = ld32(0x06004C94u);  // 06004BD4 mov.l 0x06004C94,r1
    st8(c.r[1], c.r[8]);  // 06004BD6 mov.b r8,@r1
    c.r[1] = ld32(0x06004C98u);  // 06004BD8 mov.l 0x06004C98,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06004BDEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004BDEu) return; }  // 06004BDA jsr @r1 ; nop
    c.r[1] = ld32(0x06004C9Cu);  // 06004BDE mov.l 0x06004C9C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06004BE4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004BE4u) return; }  // 06004BE0 jsr @r1 ; nop
    c.r[2] = ld32(0x06004CA0u);  // 06004BE4 mov.l 0x06004CA0,r2
    c.r[1] = 0x1u;  // 06004BE6 mov #1,r1
    st8(c.r[2], c.r[1]);  // 06004BE8 mov.b r1,@r2
    c.r[1] = ld32(0x06004CA4u);  // 06004BEA mov.l 0x06004CA4,r1
    c.r[2] = 0x0u;  // 06004BEC mov #0,r2
    st16(c.r[1], c.r[2]);  // 06004BEE mov.w r2,@r1
    c.r[1] = ld32(0x06004CA8u);  // 06004BF0 mov.l 0x06004CA8,r1
    st16(c.r[1], c.r[2]);  // 06004BF2 mov.w r2,@r1
    c.r[1] = ld32(0x06004CACu);  // 06004BF4 mov.l 0x06004CAC,r1
    c.r[6] = 0x0u;  // 06004BF6 mov #0,r6
    c.r[5] = 0x0u;  // 06004BF8 mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06004BFEu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004BFEu) return; }  // 06004BFA jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06004CB0u);  // 06004BFE mov.l 0x06004CB0,r1
    st8(c.r[1], c.r[8]);  // 06004C00 mov.b r8,@r1
    c.r[1] = ld32(0x06004CB4u);  // 06004C02 mov.l 0x06004CB4,r1
    st8(c.r[1], c.r[8]);  // 06004C04 mov.b r8,@r1
    c.r[1] = ld32(0x06004CB8u);  // 06004C06 mov.l 0x06004CB8,r1
    st8(c.r[1], c.r[8]);  // 06004C08 mov.b r8,@r1
    c.r[1] = ld32(0x06004CBCu);  // 06004C0A mov.l 0x06004CBC,r1
    st8(c.r[1], c.r[8]);  // 06004C0C mov.b r8,@r1
    c.r[1] = ld32(0x06004CC0u);  // 06004C0E mov.l 0x06004CC0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06004C14u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004C14u) return; }  // 06004C10 jsr @r1 ; mov #1,r4
    c.r[2] = ld32(0x06004CC4u);  // 06004C14 mov.l 0x06004CC4,r2
    c.r[7] = ld32(0x06004C60u);  // 06004C16 mov.l 0x06004C60,r7
    c.r[6] = c.r[2];  // 06004C18 mov r2,r6
    c.r[3] = ld32(c.r[7] + 4);  // 06004C1A mov.l @(4,r7),r3
    c.r[6] += 70;  // 06004C1C add #70,r6
    c.r[1] = c.r[3];  // 06004C1E mov r3,r1
    c.r[1] += 1;  // 06004C20 add #1,r1
    st32(c.r[2], c.r[1]);  // 06004C22 mov.l r1,@r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06004C24 mov.b @r3,r1
    c.r[7] += 8;  // 06004C26 add #8,r7
    st8(c.r[6], c.r[1]);  // 06004C28 mov.b r1,@r6
    c.r[3] = c.r[2];  // 06004C2A mov r2,r3
    c.r[3] += 72;  // 06004C2C add #72,r3
    c.r[1] = 0x0u;  // 06004C2E mov #0,r1
    st32(c.r[3], c.r[1]);  // 06004C30 mov.l r1,@r3
    c.r[1] = c.r[2];  // 06004C32 mov r2,r1
    c.r[1] += 69;  // 06004C34 add #69,r1
    st8(c.r[1], c.r[8]);  // 06004C36 mov.b r8,@r1
    c.r[3] = c.r[2];  // 06004C38 mov r2,r3
    c.r[3] += 68;  // 06004C3A add #68,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06004C3C mov.b @r7,r1
    c.r[2] += 71;  // 06004C3E add #71,r2
    st8(c.r[3], c.r[1]);  // 06004C40 mov.b r1,@r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06004C42 mov.b @r2,r0
    c.r[0] |= 0x80u;  // 06004C44 or #128,r0
    c.r[0] &= 0xBFu;  // 06004C46 and #191,r0
    { const uint32_t x = c.r[10]; c.pr = 0x06004C4Cu; st8(c.r[2], c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004C4Cu) return; }  // 06004C48 jsr @r10 ; mov.b r0,@r2
L_06004C4C:
    c.r[15] = c.r[14];  // 06004C4C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06004C4E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06004C50 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06004C52 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06004C54 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06004C56 rts ; mov.l @r15+,r8
}

void f_06004B20(SH2Context& c) {
    ran[14] = 1;
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 06004B20 shlr r0
    c.r[0] >>= 2;  // 06004B22 shlr2 r0
    c.r[0] &= 0x1u;  // 06004B24 and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06004B26 tst r0,r0
    if (!c.t) { goto L_06004B2E; }  // 06004B28 bf 0x06004B2E
    goto L_06004C4C;  // 06004B2A bra 0x06004C4C ; nop
L_06004B2E:
    c.r[2] = ld32(0x06004C60u);  // 06004B2E mov.l 0x06004C60,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06004B30 mov.b @r2,r1
    c.r[0] = c.r[1];  // 06004B32 mov r1,r0
    c.r[0] >>= 2;  // 06004B34 shlr2 r0
    c.r[0] >>= 2;  // 06004B36 shlr2 r0
    c.r[0] &= 0x1u;  // 06004B38 and #1,r0
    c.t = c.r[0] == 0x1u;  // 06004B3A cmp/eq #1,r0
    { const bool k = c.t; c.r[7] = 0x0u; if (k) { goto L_06004B44; } }  // 06004B3C bt/s 0x06004B44 ; mov #0,r7
    goto L_06004C4C;  // 06004B40 bra 0x06004C4C ; nop
L_06004B44:
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06004B44 mov.b @r2,r0
    c.r[3] = 0xFu;  // 06004B46 mov #15,r3
    c.r[0] &= 0xEFu;  // 06004B48 and #239,r0
    st8(c.r[2], c.r[0]);  // 06004B4A mov.b r0,@r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06004B4C mov.b @r2,r0
    c.r[1] = ld32(0x06004C64u);  // 06004B4E mov.l 0x06004C64,r1
    c.r[0] |= 0x8u;  // 06004B50 or #8,r0
    st8(c.r[2], c.r[0]);  // 06004B52 mov.b r0,@r2
    c.r[2] = 0x0u;  // 06004B54 mov #0,r2
    c.r[6] = c.r[2] & 0xFFu;  // 06004B56 extu.b r2,r6
L_06004B58:
    c.t = c.r[6] > c.r[3];  // 06004B58 cmp/hi r3,r6
    { const bool k = c.t; c.r[6] <<= 2; if (k) { goto L_06004B62; } }  // 06004B5A bt/s 0x06004B62 ; shll2 r6
    c.r[0] = c.r[6];  // 06004B5E mov r6,r0
    st32(c.r[0] + c.r[1], c.r[7]);  // 06004B60 mov.l r7,@(r0,r1)
L_06004B62:
    c.r[2] += 1;  // 06004B62 add #1,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[3];  // 06004B64 cmp/gt r3,r2
    { const bool k = !c.t; c.r[6] = c.r[2] & 0xFFu; if (k) { SH2_POLL(c); goto L_06004B58; } }  // 06004B66 bf/s 0x06004B58 ; extu.b r2,r6
    c.r[2] = 0x0u;  // 06004B6A mov #0,r2
    c.r[1] = ld32(0x06004C68u);  // 06004B6C mov.l 0x06004C68,r1
    st32(c.r[1], c.r[2]);  // 06004B6E mov.l r2,@r1
    st32(c.r[1] + 8, c.r[2]);  // 06004B70 mov.l r2,@(8,r1)
    c.r[2] = 0x6u;  // 06004B72 mov #6,r2
    c.r[7] = 0x0u;  // 06004B74 mov #0,r7
    c.r[6] = c.r[2] & 0xFFu;  // 06004B76 extu.b r2,r6
L_06004B78:
    c.t = c.r[6] > c.r[3];  // 06004B78 cmp/hi r3,r6
    { const bool k = c.t; c.r[6] <<= 2; if (k) { goto L_06004B82; } }  // 06004B7A bt/s 0x06004B82 ; shll2 r6
    c.r[0] = c.r[6];  // 06004B7E mov r6,r0
    st32(c.r[0] + c.r[1], c.r[7]);  // 06004B80 mov.l r7,@(r0,r1)
L_06004B82:
    c.r[2] += 1;  // 06004B82 add #1,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[3];  // 06004B84 cmp/gt r3,r2
    { const bool k = !c.t; c.r[6] = c.r[2] & 0xFFu; if (k) { SH2_POLL(c); goto L_06004B78; } }  // 06004B86 bf/s 0x06004B78 ; extu.b r2,r6
    c.r[10] = ld32(0x06004C6Cu);  // 06004B8A mov.l 0x06004C6C,r10
    { const uint32_t x = c.r[10]; c.pr = 0x06004B90u; c.r[8] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004B90u) return; }  // 06004B8C jsr @r10 ; mov #0,r8
    c.r[1] = ld32(0x06004C70u);  // 06004B90 mov.l 0x06004C70,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06004B96u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004B96u) return; }  // 06004B92 jsr @r1 ; nop
    c.r[2] = ld32(0x06004C74u);  // 06004B96 mov.l 0x06004C74,r2
    c.r[1] = ld32(0x06004C78u);  // 06004B98 mov.l 0x06004C78,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06004B9A mov.b @r1,r0
    c.r[0] &= 0x7Fu;  // 06004B9C and #127,r0
    st8(c.r[1], c.r[0]);  // 06004B9E mov.b r0,@r1
    { const uint32_t x = c.r[10]; c.pr = 0x06004BA4u; st8(c.r[2], c.r[8]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004BA4u) return; }  // 06004BA0 jsr @r10 ; mov.b r8,@r2
    c.r[9] = ld32(0x06004C7Cu);  // 06004BA4 mov.l 0x06004C7C,r9
    c.r[0] = ld32(0x06004C80u);  // 06004BA6 mov.l 0x06004C80,r0
    c.r[6] = 0x0u;  // 06004BA8 mov #0,r6
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06004BAA mov.b @r9,r4
    c.r[5] = 0x0u;  // 06004BAC mov #0,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06004BB2u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004BB2u) return; }  // 06004BAE jsr @r0 ; extu.b r4,r4
    c.r[1] = ld32(0x06004C84u);  // 06004BB2 mov.l 0x06004C84,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06004BB4 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06004BB6 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06004BB8 tst r1,r1
    if (c.t) { goto L_06004BC2; }  // 06004BBA bt 0x06004BC2
    c.r[1] = ld32(0x06004C88u);  // 06004BBC mov.l 0x06004C88,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06004BC2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004BC2u) return; }  // 06004BBE jsr @r1 ; nop
L_06004BC2:
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06004BC2 mov.b @r9,r4
    c.r[0] = ld32(0x06004C8Cu);  // 06004BC4 mov.l 0x06004C8C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06004BCAu; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004BCAu) return; }  // 06004BC6 jsr @r0 ; extu.b r4,r4
    c.r[1] = ld32(0x06004C90u);  // 06004BCA mov.l 0x06004C90,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06004BD0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004BD0u) return; }  // 06004BCC jsr @r1 ; nop
    { const uint32_t x = c.r[10]; c.pr = 0x06004BD4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004BD4u) return; }  // 06004BD0 jsr @r10 ; nop
    c.r[1] = ld32(0x06004C94u);  // 06004BD4 mov.l 0x06004C94,r1
    st8(c.r[1], c.r[8]);  // 06004BD6 mov.b r8,@r1
    c.r[1] = ld32(0x06004C98u);  // 06004BD8 mov.l 0x06004C98,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06004BDEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004BDEu) return; }  // 06004BDA jsr @r1 ; nop
    c.r[1] = ld32(0x06004C9Cu);  // 06004BDE mov.l 0x06004C9C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06004BE4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004BE4u) return; }  // 06004BE0 jsr @r1 ; nop
    c.r[2] = ld32(0x06004CA0u);  // 06004BE4 mov.l 0x06004CA0,r2
    c.r[1] = 0x1u;  // 06004BE6 mov #1,r1
    st8(c.r[2], c.r[1]);  // 06004BE8 mov.b r1,@r2
    c.r[1] = ld32(0x06004CA4u);  // 06004BEA mov.l 0x06004CA4,r1
    c.r[2] = 0x0u;  // 06004BEC mov #0,r2
    st16(c.r[1], c.r[2]);  // 06004BEE mov.w r2,@r1
    c.r[1] = ld32(0x06004CA8u);  // 06004BF0 mov.l 0x06004CA8,r1
    st16(c.r[1], c.r[2]);  // 06004BF2 mov.w r2,@r1
    c.r[1] = ld32(0x06004CACu);  // 06004BF4 mov.l 0x06004CAC,r1
    c.r[6] = 0x0u;  // 06004BF6 mov #0,r6
    c.r[5] = 0x0u;  // 06004BF8 mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06004BFEu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004BFEu) return; }  // 06004BFA jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06004CB0u);  // 06004BFE mov.l 0x06004CB0,r1
    st8(c.r[1], c.r[8]);  // 06004C00 mov.b r8,@r1
    c.r[1] = ld32(0x06004CB4u);  // 06004C02 mov.l 0x06004CB4,r1
    st8(c.r[1], c.r[8]);  // 06004C04 mov.b r8,@r1
    c.r[1] = ld32(0x06004CB8u);  // 06004C06 mov.l 0x06004CB8,r1
    st8(c.r[1], c.r[8]);  // 06004C08 mov.b r8,@r1
    c.r[1] = ld32(0x06004CBCu);  // 06004C0A mov.l 0x06004CBC,r1
    st8(c.r[1], c.r[8]);  // 06004C0C mov.b r8,@r1
    c.r[1] = ld32(0x06004CC0u);  // 06004C0E mov.l 0x06004CC0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06004C14u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004C14u) return; }  // 06004C10 jsr @r1 ; mov #1,r4
    c.r[2] = ld32(0x06004CC4u);  // 06004C14 mov.l 0x06004CC4,r2
    c.r[7] = ld32(0x06004C60u);  // 06004C16 mov.l 0x06004C60,r7
    c.r[6] = c.r[2];  // 06004C18 mov r2,r6
    c.r[3] = ld32(c.r[7] + 4);  // 06004C1A mov.l @(4,r7),r3
    c.r[6] += 70;  // 06004C1C add #70,r6
    c.r[1] = c.r[3];  // 06004C1E mov r3,r1
    c.r[1] += 1;  // 06004C20 add #1,r1
    st32(c.r[2], c.r[1]);  // 06004C22 mov.l r1,@r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06004C24 mov.b @r3,r1
    c.r[7] += 8;  // 06004C26 add #8,r7
    st8(c.r[6], c.r[1]);  // 06004C28 mov.b r1,@r6
    c.r[3] = c.r[2];  // 06004C2A mov r2,r3
    c.r[3] += 72;  // 06004C2C add #72,r3
    c.r[1] = 0x0u;  // 06004C2E mov #0,r1
    st32(c.r[3], c.r[1]);  // 06004C30 mov.l r1,@r3
    c.r[1] = c.r[2];  // 06004C32 mov r2,r1
    c.r[1] += 69;  // 06004C34 add #69,r1
    st8(c.r[1], c.r[8]);  // 06004C36 mov.b r8,@r1
    c.r[3] = c.r[2];  // 06004C38 mov r2,r3
    c.r[3] += 68;  // 06004C3A add #68,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06004C3C mov.b @r7,r1
    c.r[2] += 71;  // 06004C3E add #71,r2
    st8(c.r[3], c.r[1]);  // 06004C40 mov.b r1,@r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06004C42 mov.b @r2,r0
    c.r[0] |= 0x80u;  // 06004C44 or #128,r0
    c.r[0] &= 0xBFu;  // 06004C46 and #191,r0
    { const uint32_t x = c.r[10]; c.pr = 0x06004C4Cu; st8(c.r[2], c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004C4Cu) return; }  // 06004C48 jsr @r10 ; mov.b r0,@r2
L_06004C4C:
    c.r[15] = c.r[14];  // 06004C4C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06004C4E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06004C50 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06004C52 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06004C54 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06004C56 rts ; mov.l @r15+,r8
}

void f_06004B44(SH2Context& c) {
    ran[15] = 1;
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06004B44 mov.b @r2,r0
    c.r[3] = 0xFu;  // 06004B46 mov #15,r3
    c.r[0] &= 0xEFu;  // 06004B48 and #239,r0
    st8(c.r[2], c.r[0]);  // 06004B4A mov.b r0,@r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06004B4C mov.b @r2,r0
    c.r[1] = ld32(0x06004C64u);  // 06004B4E mov.l 0x06004C64,r1
    c.r[0] |= 0x8u;  // 06004B50 or #8,r0
    st8(c.r[2], c.r[0]);  // 06004B52 mov.b r0,@r2
    c.r[2] = 0x0u;  // 06004B54 mov #0,r2
    c.r[6] = c.r[2] & 0xFFu;  // 06004B56 extu.b r2,r6
L_06004B58:
    c.t = c.r[6] > c.r[3];  // 06004B58 cmp/hi r3,r6
    { const bool k = c.t; c.r[6] <<= 2; if (k) { goto L_06004B62; } }  // 06004B5A bt/s 0x06004B62 ; shll2 r6
    c.r[0] = c.r[6];  // 06004B5E mov r6,r0
    st32(c.r[0] + c.r[1], c.r[7]);  // 06004B60 mov.l r7,@(r0,r1)
L_06004B62:
    c.r[2] += 1;  // 06004B62 add #1,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[3];  // 06004B64 cmp/gt r3,r2
    { const bool k = !c.t; c.r[6] = c.r[2] & 0xFFu; if (k) { SH2_POLL(c); goto L_06004B58; } }  // 06004B66 bf/s 0x06004B58 ; extu.b r2,r6
    c.r[2] = 0x0u;  // 06004B6A mov #0,r2
    c.r[1] = ld32(0x06004C68u);  // 06004B6C mov.l 0x06004C68,r1
    st32(c.r[1], c.r[2]);  // 06004B6E mov.l r2,@r1
    st32(c.r[1] + 8, c.r[2]);  // 06004B70 mov.l r2,@(8,r1)
    c.r[2] = 0x6u;  // 06004B72 mov #6,r2
    c.r[7] = 0x0u;  // 06004B74 mov #0,r7
    c.r[6] = c.r[2] & 0xFFu;  // 06004B76 extu.b r2,r6
L_06004B78:
    c.t = c.r[6] > c.r[3];  // 06004B78 cmp/hi r3,r6
    { const bool k = c.t; c.r[6] <<= 2; if (k) { goto L_06004B82; } }  // 06004B7A bt/s 0x06004B82 ; shll2 r6
    c.r[0] = c.r[6];  // 06004B7E mov r6,r0
    st32(c.r[0] + c.r[1], c.r[7]);  // 06004B80 mov.l r7,@(r0,r1)
L_06004B82:
    c.r[2] += 1;  // 06004B82 add #1,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[3];  // 06004B84 cmp/gt r3,r2
    { const bool k = !c.t; c.r[6] = c.r[2] & 0xFFu; if (k) { SH2_POLL(c); goto L_06004B78; } }  // 06004B86 bf/s 0x06004B78 ; extu.b r2,r6
    c.r[10] = ld32(0x06004C6Cu);  // 06004B8A mov.l 0x06004C6C,r10
    { const uint32_t x = c.r[10]; c.pr = 0x06004B90u; c.r[8] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004B90u) return; }  // 06004B8C jsr @r10 ; mov #0,r8
    c.r[1] = ld32(0x06004C70u);  // 06004B90 mov.l 0x06004C70,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06004B96u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004B96u) return; }  // 06004B92 jsr @r1 ; nop
    c.r[2] = ld32(0x06004C74u);  // 06004B96 mov.l 0x06004C74,r2
    c.r[1] = ld32(0x06004C78u);  // 06004B98 mov.l 0x06004C78,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06004B9A mov.b @r1,r0
    c.r[0] &= 0x7Fu;  // 06004B9C and #127,r0
    st8(c.r[1], c.r[0]);  // 06004B9E mov.b r0,@r1
    { const uint32_t x = c.r[10]; c.pr = 0x06004BA4u; st8(c.r[2], c.r[8]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004BA4u) return; }  // 06004BA0 jsr @r10 ; mov.b r8,@r2
    c.r[9] = ld32(0x06004C7Cu);  // 06004BA4 mov.l 0x06004C7C,r9
    c.r[0] = ld32(0x06004C80u);  // 06004BA6 mov.l 0x06004C80,r0
    c.r[6] = 0x0u;  // 06004BA8 mov #0,r6
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06004BAA mov.b @r9,r4
    c.r[5] = 0x0u;  // 06004BAC mov #0,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06004BB2u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004BB2u) return; }  // 06004BAE jsr @r0 ; extu.b r4,r4
    c.r[1] = ld32(0x06004C84u);  // 06004BB2 mov.l 0x06004C84,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06004BB4 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06004BB6 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06004BB8 tst r1,r1
    if (c.t) { goto L_06004BC2; }  // 06004BBA bt 0x06004BC2
    c.r[1] = ld32(0x06004C88u);  // 06004BBC mov.l 0x06004C88,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06004BC2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004BC2u) return; }  // 06004BBE jsr @r1 ; nop
L_06004BC2:
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06004BC2 mov.b @r9,r4
    c.r[0] = ld32(0x06004C8Cu);  // 06004BC4 mov.l 0x06004C8C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06004BCAu; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004BCAu) return; }  // 06004BC6 jsr @r0 ; extu.b r4,r4
    c.r[1] = ld32(0x06004C90u);  // 06004BCA mov.l 0x06004C90,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06004BD0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004BD0u) return; }  // 06004BCC jsr @r1 ; nop
    { const uint32_t x = c.r[10]; c.pr = 0x06004BD4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004BD4u) return; }  // 06004BD0 jsr @r10 ; nop
    c.r[1] = ld32(0x06004C94u);  // 06004BD4 mov.l 0x06004C94,r1
    st8(c.r[1], c.r[8]);  // 06004BD6 mov.b r8,@r1
    c.r[1] = ld32(0x06004C98u);  // 06004BD8 mov.l 0x06004C98,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06004BDEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004BDEu) return; }  // 06004BDA jsr @r1 ; nop
    c.r[1] = ld32(0x06004C9Cu);  // 06004BDE mov.l 0x06004C9C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06004BE4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004BE4u) return; }  // 06004BE0 jsr @r1 ; nop
    c.r[2] = ld32(0x06004CA0u);  // 06004BE4 mov.l 0x06004CA0,r2
    c.r[1] = 0x1u;  // 06004BE6 mov #1,r1
    st8(c.r[2], c.r[1]);  // 06004BE8 mov.b r1,@r2
    c.r[1] = ld32(0x06004CA4u);  // 06004BEA mov.l 0x06004CA4,r1
    c.r[2] = 0x0u;  // 06004BEC mov #0,r2
    st16(c.r[1], c.r[2]);  // 06004BEE mov.w r2,@r1
    c.r[1] = ld32(0x06004CA8u);  // 06004BF0 mov.l 0x06004CA8,r1
    st16(c.r[1], c.r[2]);  // 06004BF2 mov.w r2,@r1
    c.r[1] = ld32(0x06004CACu);  // 06004BF4 mov.l 0x06004CAC,r1
    c.r[6] = 0x0u;  // 06004BF6 mov #0,r6
    c.r[5] = 0x0u;  // 06004BF8 mov #0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06004BFEu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004BFEu) return; }  // 06004BFA jsr @r1 ; mov #0,r4
    c.r[1] = ld32(0x06004CB0u);  // 06004BFE mov.l 0x06004CB0,r1
    st8(c.r[1], c.r[8]);  // 06004C00 mov.b r8,@r1
    c.r[1] = ld32(0x06004CB4u);  // 06004C02 mov.l 0x06004CB4,r1
    st8(c.r[1], c.r[8]);  // 06004C04 mov.b r8,@r1
    c.r[1] = ld32(0x06004CB8u);  // 06004C06 mov.l 0x06004CB8,r1
    st8(c.r[1], c.r[8]);  // 06004C08 mov.b r8,@r1
    c.r[1] = ld32(0x06004CBCu);  // 06004C0A mov.l 0x06004CBC,r1
    st8(c.r[1], c.r[8]);  // 06004C0C mov.b r8,@r1
    c.r[1] = ld32(0x06004CC0u);  // 06004C0E mov.l 0x06004CC0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06004C14u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004C14u) return; }  // 06004C10 jsr @r1 ; mov #1,r4
    c.r[2] = ld32(0x06004CC4u);  // 06004C14 mov.l 0x06004CC4,r2
    c.r[7] = ld32(0x06004C60u);  // 06004C16 mov.l 0x06004C60,r7
    c.r[6] = c.r[2];  // 06004C18 mov r2,r6
    c.r[3] = ld32(c.r[7] + 4);  // 06004C1A mov.l @(4,r7),r3
    c.r[6] += 70;  // 06004C1C add #70,r6
    c.r[1] = c.r[3];  // 06004C1E mov r3,r1
    c.r[1] += 1;  // 06004C20 add #1,r1
    st32(c.r[2], c.r[1]);  // 06004C22 mov.l r1,@r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06004C24 mov.b @r3,r1
    c.r[7] += 8;  // 06004C26 add #8,r7
    st8(c.r[6], c.r[1]);  // 06004C28 mov.b r1,@r6
    c.r[3] = c.r[2];  // 06004C2A mov r2,r3
    c.r[3] += 72;  // 06004C2C add #72,r3
    c.r[1] = 0x0u;  // 06004C2E mov #0,r1
    st32(c.r[3], c.r[1]);  // 06004C30 mov.l r1,@r3
    c.r[1] = c.r[2];  // 06004C32 mov r2,r1
    c.r[1] += 69;  // 06004C34 add #69,r1
    st8(c.r[1], c.r[8]);  // 06004C36 mov.b r8,@r1
    c.r[3] = c.r[2];  // 06004C38 mov r2,r3
    c.r[3] += 68;  // 06004C3A add #68,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 06004C3C mov.b @r7,r1
    c.r[2] += 71;  // 06004C3E add #71,r2
    st8(c.r[3], c.r[1]);  // 06004C40 mov.b r1,@r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06004C42 mov.b @r2,r0
    c.r[0] |= 0x80u;  // 06004C44 or #128,r0
    c.r[0] &= 0xBFu;  // 06004C46 and #191,r0
    { const uint32_t x = c.r[10]; c.pr = 0x06004C4Cu; st8(c.r[2], c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004C4Cu) return; }  // 06004C48 jsr @r10 ; mov.b r0,@r2
    c.r[15] = c.r[14];  // 06004C4C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06004C4E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06004C50 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06004C52 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06004C54 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06004C56 rts ; mov.l @r15+,r8
}

void f_06004CC8(SH2Context& c) {
    ran[16] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06004CC8 mov.l r14,@-r15
    c.r[5] = c.r[5] & 0xFFFFu;  // 06004CCA extu.w r5,r5
    c.r[5] <<= 2;  // 06004CCC shll2 r5
    c.r[4] += c.r[5];  // 06004CCE add r5,r4
    c.r[1] = c.r[4];  // 06004CD0 mov r4,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 06004CD2 mov.b @r1+,r2
    c.r[0] = c.r[2];  // 06004CD4 mov r2,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06004CD6 mov.b @r1,r1
    c.r[0] <<= 16;  // 06004CD8 shll16 r0
    c.r[0] <<= 8;  // 06004CDA shll8 r0
    c.r[1] = c.r[1] & 0xFFu;  // 06004CDC extu.b r1,r1
    c.r[1] <<= 16;  // 06004CDE shll16 r1
    c.r[0] |= c.r[1];  // 06004CE0 or r1,r0
    c.r[1] = c.r[4];  // 06004CE2 mov r4,r1
    c.r[1] += 2;  // 06004CE4 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06004CE6 mov.b @r1,r1
    c.r[14] = c.r[15];  // 06004CE8 mov r15,r14
    c.r[1] = c.r[1] & 0xFFu;  // 06004CEA extu.b r1,r1
    c.r[1] <<= 8;  // 06004CEC shll8 r1
    c.r[0] |= c.r[1];  // 06004CEE or r1,r0
    c.r[1] = c.r[4];  // 06004CF0 mov r4,r1
    c.r[1] += 3;  // 06004CF2 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06004CF4 mov.b @r1,r1
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06004CF6 mov.l @r15+,r14
    c.r[1] = c.r[1] & 0xFFu;  // 06004CF8 extu.b r1,r1
    c.r[0] |= c.r[1];  // 06004CFA or r1,r0
    { const uint32_t x = c.pr; c.r[0] += c.r[4]; c.pc = x; return; }  // 06004CFC rts ; add r4,r0
}

void f_06004D00(SH2Context& c) {
    ran[17] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06004D00 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06004D02 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06004D04 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06004D06 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06004D08 mov r15,r14
    c.r[4] = c.r[4] & 0xFFFFu;  // 06004D0A extu.w r4,r4
    c.r[9] = c.r[4];  // 06004D0C mov r4,r9
    c.r[9] >>= 2;  // 06004D0E shlr2 r9
    c.t = c.r[9] & 1; c.r[9] >>= 1;  // 06004D10 shlr r9
    c.r[1] = ld32(0x06004D44u);  // 06004D12 mov.l 0x06004D44,r1
    c.r[8] = (uint32_t)(int16_t)ld16(0x06004D40u);  // 06004D14 mov.w 0x06004D40,r8
    c.r[1] = ld32(c.r[1]);  // 06004D16 mov.l @r1,r1
    c.r[0] = 0x7u;  // 06004D18 mov #7,r0
    c.r[9] += c.r[1];  // 06004D1A add r1,r9
    c.r[1] = ~c.r[4];  // 06004D1C not r4,r1
    c.r[1] &= c.r[0];  // 06004D1E and r0,r1
    c.r[5] = c.r[1];  // 06004D20 mov r1,r5
    c.r[0] = ld32(0x06004D48u);  // 06004D22 mov.l 0x06004D48,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06004D28u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004D28u) return; }  // 06004D24 jsr @r0 ; mov #1,r4
    c.r[2] = c.r[0];  // 06004D28 mov r0,r2
    c.r[15] = c.r[14];  // 06004D2A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06004D2C lds.l @r15+,pr
    c.r[0] = c.r[9];  // 06004D2E mov r9,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 06004D30 mov.b @(r0,r8),r1
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06004D32 mov.l @r15+,r14
    c.r[2] &= c.r[1];  // 06004D34 and r1,r2
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06004D36 mov.l @r15+,r9
    c.r[1] = c.r[2] & 0xFFu;  // 06004D38 extu.b r2,r1
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 06004D3A mov.l @r15+,r8
    { const uint32_t x = c.pr; c.r[0] = c.r[1]; c.pc = x; return; }  // 06004D3C rts ; mov r1,r0
}

void f_06004D4C(SH2Context& c) {
    ran[18] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06004D4C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06004D4E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06004D50 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06004D52 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06004D54 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06004D56 mov r15,r14
    c.r[8] = c.r[4];  // 06004D58 mov r4,r8
    c.r[9] = c.r[5];  // 06004D5A mov r5,r9
    c.r[8] = c.r[8] & 0xFFu;  // 06004D5C extu.b r8,r8
    c.r[9] = c.r[9] & 0xFFu;  // 06004D5E extu.b r9,r9
    c.r[4] = ld32(0x06004D94u);  // 06004D60 mov.l 0x06004D94,r4
    c.r[0] = ld32(0x06004D98u);  // 06004D62 mov.l 0x06004D98,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06004D68u; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004D68u) return; }  // 06004D64 jsr @r0 ; mov #0,r5
    c.r[1] = ld32(0x06004D9Cu);  // 06004D68 mov.l 0x06004D9C,r1
    st32(c.r[1], c.r[0]);  // 06004D6A mov.l r0,@r1
    c.r[10] = ld32(0x06004DA0u);  // 06004D6C mov.l 0x06004DA0,r10
    c.r[6] = 0x4u;  // 06004D6E mov #4,r6
    c.r[5] = c.r[8];  // 06004D70 mov r8,r5
    { const uint32_t x = c.r[10]; c.pr = 0x06004D76u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004D76u) return; }  // 06004D72 jsr @r10 ; mov r0,r4
    c.r[8] <<= 2;  // 06004D76 shll2 r8
    c.r[0] += c.r[8];  // 06004D78 add r8,r0
    c.r[6] = 0x4u;  // 06004D7A mov #4,r6
    c.r[5] = c.r[9];  // 06004D7C mov r9,r5
    { const uint32_t x = c.r[10]; c.pr = 0x06004D82u; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004D82u) return; }  // 06004D7E jsr @r10 ; mov r0,r4
    c.r[15] = c.r[14];  // 06004D82 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06004D84 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06004D86 mov.l @r15+,r14
    c.r[9] <<= 2;  // 06004D88 shll2 r9
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06004D8A mov.l @r15+,r10
    c.r[0] += c.r[9];  // 06004D8C add r9,r0
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06004D8E mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06004D90 rts ; mov.l @r15+,r8
}

void f_06004DA4(SH2Context& c) {
    ran[19] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06004DA4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06004DA6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06004DA8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06004DAA mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06004DAC sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06004DAE mov r15,r14
    c.r[9] = c.r[4];  // 06004DB0 mov r4,r9
    c.r[8] = c.r[5];  // 06004DB2 mov r5,r8
    c.r[9] = c.r[9] & 0xFFu;  // 06004DB4 extu.b r9,r9
    c.r[8] = c.r[8] & 0xFFu;  // 06004DB6 extu.b r8,r8
    c.r[0] = ld32(0x06004E1Cu);  // 06004DB8 mov.l 0x06004E1C,r0
    c.r[4] = ld32(0x06004E20u);  // 06004DBA mov.l 0x06004E20,r4
    { const uint32_t x = c.r[0]; c.pr = 0x06004DC0u; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004DC0u) return; }  // 06004DBC jsr @r0 ; mov #0,r5
    c.r[1] = ld32(0x06004E24u);  // 06004DC0 mov.l 0x06004E24,r1
    st32(c.r[1], c.r[0]);  // 06004DC2 mov.l r0,@r1
    c.r[10] = ld32(0x06004E28u);  // 06004DC4 mov.l 0x06004E28,r10
    c.r[6] = 0x4u;  // 06004DC6 mov #4,r6
    c.r[5] = c.r[9];  // 06004DC8 mov r9,r5
    { const uint32_t x = c.r[10]; c.pr = 0x06004DCEu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004DCEu) return; }  // 06004DCA jsr @r10 ; mov r0,r4
    c.r[9] <<= 2;  // 06004DCE shll2 r9
    c.r[0] += c.r[9];  // 06004DD0 add r9,r0
    c.r[6] = 0x4u;  // 06004DD2 mov #4,r6
    c.r[5] = c.r[8];  // 06004DD4 mov r8,r5
    { const uint32_t x = c.r[10]; c.pr = 0x06004DDAu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06004DDAu) return; }  // 06004DD6 jsr @r10 ; mov r0,r4
    c.r[8] <<= 2;  // 06004DDA shll2 r8
    c.r[1] = c.r[0];  // 06004DDC mov r0,r1
    c.r[1] += c.r[8];  // 06004DDE add r8,r1
    c.r[2] = ld32(0x06004E2Cu);  // 06004DE0 mov.l 0x06004E2C,r2
    c.r[3] = c.r[2];  // 06004DE2 mov r2,r3
    c.r[1] += 1;  // 06004DE4 add #1,r1
    st32(c.r[2], c.r[1]);  // 06004DE6 mov.l r1,@r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[8]);  // 06004DE8 mov.b @(r0,r8),r1
    c.r[3] += 70;  // 06004DEA add #70,r3
    st8(c.r[3], c.r[1]);  // 06004DEC mov.b r1,@r3
    c.r[3] = c.r[2];  // 06004DEE mov r2,r3
    c.r[3] += 72;  // 06004DF0 add #72,r3
    c.r[1] = 0x0u;  // 06004DF2 mov #0,r1
    st32(c.r[3], c.r[1]);  // 06004DF4 mov.l r1,@r3
    c.r[1] = c.r[2];  // 06004DF6 mov r2,r1
    c.r[1] += 69;  // 06004DF8 add #69,r1
    c.r[3] = 0x0u;  // 06004DFA mov #0,r3
    st8(c.r[1], c.r[3]);  // 06004DFC mov.b r3,@r1
    c.r[1] = c.r[2];  // 06004DFE mov r2,r1
    c.r[1] += 68;  // 06004E00 add #68,r1
    st8(c.r[1], c.r[3]);  // 06004E02 mov.b r3,@r1
    c.r[2] += 71;  // 06004E04 add #71,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06004E06 mov.b @r2,r0
    c.r[15] = c.r[14];  // 06004E08 mov r14,r15
    c.r[0] |= 0x80u;  // 06004E0A or #128,r0
    c.r[0] &= 0xBFu;  // 06004E0C and #191,r0
    st8(c.r[2], c.r[0]);  // 06004E0E mov.b r0,@r2
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06004E10 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06004E12 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06004E14 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06004E16 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06004E18 rts ; mov.l @r15+,r8
}

void f_06004E30(SH2Context& c) {
    ran[20] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06004E30 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06004E32 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06004E34 mov r15,r14
    c.r[6] = 0x0u;  // 06004E36 mov #0,r6
    c.r[0] = 0x7u;  // 06004E38 mov #7,r0
    c.r[5] = ld32(0x06004ED0u);  // 06004E3A mov.l 0x06004ED0,r5
    c.r[2] = c.r[6];  // 06004E3C mov r6,r2
L_06004E3E:
    c.r[2] <<= 2;  // 06004E3E shll2 r2
    c.r[7] = c.r[2];  // 06004E40 mov r2,r7
    c.r[7] += c.r[4];  // 06004E42 add r4,r7
    c.r[2] += c.r[5];  // 06004E44 add r5,r2
    c.r[3] = c.r[7];  // 06004E46 mov r7,r3
    c.r[1] = ld32(c.r[2] + 4);  // 06004E48 mov.l @(4,r2),r1
    c.r[3] += 76;  // 06004E4A add #76,r3
    st32(c.r[7] + 4, c.r[1]);  // 06004E4C mov.l r1,@(4,r7)
    c.r[1] = c.r[2];  // 06004E4E mov r2,r1
    c.r[1] += 76;  // 06004E50 add #76,r1
    c.r[1] = ld32(c.r[1]);  // 06004E52 mov.l @r1,r1
    c.r[2] += 108;  // 06004E54 add #108,r2
    st32(c.r[3], c.r[1]);  // 06004E56 mov.l r1,@r3
    c.r[1] = ld32(c.r[2]);  // 06004E58 mov.l @r2,r1
    c.r[7] += 108;  // 06004E5A add #108,r7
    st32(c.r[7], c.r[1]);  // 06004E5C mov.l r1,@r7
    c.r[1] = c.r[6];  // 06004E5E mov r6,r1
    c.r[1] += 1;  // 06004E60 add #1,r1
    c.r[6] = c.r[1] & 0xFFFFu;  // 06004E62 extu.w r1,r6
    c.t = c.r[6] > c.r[0];  // 06004E64 cmp/hi r0,r6
    { const bool k = !c.t; c.r[2] = c.r[6]; if (k) { SH2_POLL(c); goto L_06004E3E; } }  // 06004E66 bf/s 0x06004E3E ; mov r6,r2
    c.r[2] = ld32(0x06004ED0u);  // 06004E6A mov.l 0x06004ED0,r2
    c.r[3] = c.r[4];  // 06004E6C mov r4,r3
    c.r[3] += 68;  // 06004E6E add #68,r3
    c.r[1] = ld32(c.r[2]);  // 06004E70 mov.l @r2,r1
    c.r[7] = 0x7Fu;  // 06004E72 mov #127,r7
    st32(c.r[4], c.r[1]);  // 06004E74 mov.l r1,@r4
    c.r[1] = c.r[2];  // 06004E76 mov r2,r1
    c.r[1] += 68;  // 06004E78 add #68,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06004E7A mov.b @r1,r1
    c.r[8] = (uint32_t)(int16_t)ld16(0x06004ECAu);  // 06004E7C mov.w 0x06004ECA,r8
    st8(c.r[3], c.r[1]);  // 06004E7E mov.b r1,@r3
    c.r[3] = c.r[4];  // 06004E80 mov r4,r3
    c.r[1] = c.r[2];  // 06004E82 mov r2,r1
    c.r[1] += 69;  // 06004E84 add #69,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06004E86 mov.b @r1,r1
    c.r[3] += 69;  // 06004E88 add #69,r3
    st8(c.r[3], c.r[1]);  // 06004E8A mov.b r1,@r3
    c.r[3] = c.r[4];  // 06004E8C mov r4,r3
    c.r[1] = c.r[2];  // 06004E8E mov r2,r1
    c.r[1] += 70;  // 06004E90 add #70,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06004E92 mov.b @r1,r1
    c.r[3] += 70;  // 06004E94 add #70,r3
    st8(c.r[3], c.r[1]);  // 06004E96 mov.b r1,@r3
    c.r[3] = c.r[4];  // 06004E98 mov r4,r3
    c.r[3] += 72;  // 06004E9A add #72,r3
    c.r[1] = c.r[2];  // 06004E9C mov r2,r1
    c.r[1] += 72;  // 06004E9E add #72,r1
    c.r[1] = ld32(c.r[1]);  // 06004EA0 mov.l @r1,r1
    c.r[2] += 71;  // 06004EA2 add #71,r2
    st32(c.r[3], c.r[1]);  // 06004EA4 mov.l r1,@r3
    c.r[1] = c.r[4];  // 06004EA6 mov r4,r1
    c.r[1] += 71;  // 06004EA8 add #71,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06004EAA mov.b @r2,r0
    c.r[3] = (uint32_t)(int16_t)ld16(0x06004ECCu);  // 06004EAC mov.w 0x06004ECC,r3
    c.r[3] &= c.r[0];  // 06004EAE and r0,r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06004EB0 mov.b @r1,r0
    c.r[15] = c.r[14];  // 06004EB2 mov r14,r15
    c.r[7] &= c.r[0];  // 06004EB4 and r0,r7
    c.r[7] |= c.r[3];  // 06004EB6 or r3,r7
    st8(c.r[1], c.r[7]);  // 06004EB8 mov.b r7,@r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06004EBA mov.b @r2,r0
    c.r[7] &= c.r[8];  // 06004EBC and r8,r7
    c.r[0] &= 0x40u;  // 06004EBE and #64,r0
    c.r[7] |= c.r[0];  // 06004EC0 or r0,r7
    st8(c.r[1], c.r[7]);  // 06004EC2 mov.b r7,@r1
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06004EC4 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06004EC6 rts ; mov.l @r15+,r8
}

void f_06004ED4(SH2Context& c) {
    ran[21] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06004ED4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06004ED6 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06004ED8 mov r15,r14
    c.r[6] = 0x0u;  // 06004EDA mov #0,r6
    c.r[0] = 0x7u;  // 06004EDC mov #7,r0
    c.r[5] = ld32(0x06004F74u);  // 06004EDE mov.l 0x06004F74,r5
    c.r[2] = c.r[6];  // 06004EE0 mov r6,r2
L_06004EE2:
    c.r[2] <<= 2;  // 06004EE2 shll2 r2
    c.r[7] = c.r[2];  // 06004EE4 mov r2,r7
    c.r[7] += c.r[5];  // 06004EE6 add r5,r7
    c.r[2] += c.r[4];  // 06004EE8 add r4,r2
    c.r[3] = c.r[7];  // 06004EEA mov r7,r3
    c.r[1] = ld32(c.r[2] + 4);  // 06004EEC mov.l @(4,r2),r1
    c.r[3] += 76;  // 06004EEE add #76,r3
    st32(c.r[7] + 4, c.r[1]);  // 06004EF0 mov.l r1,@(4,r7)
    c.r[1] = c.r[2];  // 06004EF2 mov r2,r1
    c.r[1] += 76;  // 06004EF4 add #76,r1
    c.r[1] = ld32(c.r[1]);  // 06004EF6 mov.l @r1,r1
    c.r[2] += 108;  // 06004EF8 add #108,r2
    st32(c.r[3], c.r[1]);  // 06004EFA mov.l r1,@r3
    c.r[1] = ld32(c.r[2]);  // 06004EFC mov.l @r2,r1
    c.r[7] += 108;  // 06004EFE add #108,r7
    st32(c.r[7], c.r[1]);  // 06004F00 mov.l r1,@r7
    c.r[1] = c.r[6];  // 06004F02 mov r6,r1
    c.r[1] += 1;  // 06004F04 add #1,r1
    c.r[6] = c.r[1] & 0xFFFFu;  // 06004F06 extu.w r1,r6
    c.t = c.r[6] > c.r[0];  // 06004F08 cmp/hi r0,r6
    { const bool k = !c.t; c.r[2] = c.r[6]; if (k) { SH2_POLL(c); goto L_06004EE2; } }  // 06004F0A bf/s 0x06004EE2 ; mov r6,r2
    c.r[2] = ld32(0x06004F74u);  // 06004F0E mov.l 0x06004F74,r2
    c.r[3] = c.r[2];  // 06004F10 mov r2,r3
    c.r[3] += 68;  // 06004F12 add #68,r3
    c.r[1] = ld32(c.r[4]);  // 06004F14 mov.l @r4,r1
    c.r[7] = 0x7Fu;  // 06004F16 mov #127,r7
    st32(c.r[2], c.r[1]);  // 06004F18 mov.l r1,@r2
    c.r[1] = c.r[4];  // 06004F1A mov r4,r1
    c.r[1] += 68;  // 06004F1C add #68,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06004F1E mov.b @r1,r1
    c.r[8] = (uint32_t)(int16_t)ld16(0x06004F6Eu);  // 06004F20 mov.w 0x06004F6E,r8
    st8(c.r[3], c.r[1]);  // 06004F22 mov.b r1,@r3
    c.r[3] = c.r[2];  // 06004F24 mov r2,r3
    c.r[1] = c.r[4];  // 06004F26 mov r4,r1
    c.r[1] += 69;  // 06004F28 add #69,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06004F2A mov.b @r1,r1
    c.r[3] += 69;  // 06004F2C add #69,r3
    st8(c.r[3], c.r[1]);  // 06004F2E mov.b r1,@r3
    c.r[3] = c.r[2];  // 06004F30 mov r2,r3
    c.r[1] = c.r[4];  // 06004F32 mov r4,r1
    c.r[1] += 70;  // 06004F34 add #70,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06004F36 mov.b @r1,r1
    c.r[3] += 70;  // 06004F38 add #70,r3
    st8(c.r[3], c.r[1]);  // 06004F3A mov.b r1,@r3
    c.r[3] = c.r[2];  // 06004F3C mov r2,r3
    c.r[3] += 72;  // 06004F3E add #72,r3
    c.r[1] = c.r[4];  // 06004F40 mov r4,r1
    c.r[1] += 72;  // 06004F42 add #72,r1
    c.r[1] = ld32(c.r[1]);  // 06004F44 mov.l @r1,r1
    c.r[2] += 71;  // 06004F46 add #71,r2
    st32(c.r[3], c.r[1]);  // 06004F48 mov.l r1,@r3
    c.r[1] = c.r[4];  // 06004F4A mov r4,r1
    c.r[1] += 71;  // 06004F4C add #71,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06004F4E mov.b @r1,r0
    c.r[3] = (uint32_t)(int16_t)ld16(0x06004F70u);  // 06004F50 mov.w 0x06004F70,r3
    c.r[3] &= c.r[0];  // 06004F52 and r0,r3
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06004F54 mov.b @r2,r0
    c.r[15] = c.r[14];  // 06004F56 mov r14,r15
    c.r[7] &= c.r[0];  // 06004F58 and r0,r7
    c.r[7] |= c.r[3];  // 06004F5A or r3,r7
    st8(c.r[2], c.r[7]);  // 06004F5C mov.b r7,@r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06004F5E mov.b @r1,r0
    c.r[7] &= c.r[8];  // 06004F60 and r8,r7
    c.r[0] &= 0x40u;  // 06004F62 and #64,r0
    c.r[7] |= c.r[0];  // 06004F64 or r0,r7
    st8(c.r[2], c.r[7]);  // 06004F66 mov.b r7,@r2
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06004F68 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06004F6A rts ; mov.l @r15+,r8
}

void f_06004F78(SH2Context& c) {
    ran[22] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06004F78 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06004F7A mov r15,r14
    c.r[1] = ld32(0x06004F94u);  // 06004F7C mov.l 0x06004F94,r1
    c.r[7] = c.r[1];  // 06004F7E mov r1,r7
    c.r[3] = ld32(c.r[1]);  // 06004F80 mov.l @r1,r3
    c.r[7] += 70;  // 06004F82 add #70,r7
    c.r[2] = c.r[3];  // 06004F84 mov r3,r2
    c.r[2] += 1;  // 06004F86 add #1,r2
    st32(c.r[1], c.r[2]);  // 06004F88 mov.l r2,@r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06004F8A mov.b @r3,r1
    st8(c.r[7], c.r[1]);  // 06004F8C mov.b r1,@r7
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06004F8E rts ; mov.l @r15+,r14
}

void f_06004FB8(SH2Context& c) {
    ran[23] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06004FB8 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06004FBA mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06004FBC mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06004FBE mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06004FC0 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06004FC2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06004FC4 sts.l pr,@-r15
    c.r[2] = ld32(0x06005104u);  // 06004FC6 mov.l 0x06005104,r2
    c.r[1] = ld32(c.r[2]);  // 06004FC8 mov.l @r2,r1
    c.r[1] += 1;  // 06004FCA add #1,r1
    st32(c.r[2], c.r[1]);  // 06004FCC mov.l r1,@r2
    c.r[1] = ld32(c.r[2]);  // 06004FCE mov.l @r2,r1
    c.r[15] -= 64;  // 06004FD0 add #-64,r15
    c.r[2] = ld32(0x06005108u);  // 06004FD2 mov.l 0x06005108,r2
    c.r[1] = c.r[2];  // 06004FD4 mov r2,r1
    c.r[1] += 71;  // 06004FD6 add #71,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06004FD8 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06004FDA extu.b r1,r1
    c.r[1] >>= 2;  // 06004FDC shlr2 r1
    c.r[1] >>= 2;  // 06004FDE shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 06004FE0 shlr r1
    c.r[1] >>= 2;  // 06004FE2 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06004FE4 tst r1,r1
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_06004FEE; } }  // 06004FE6 bf/s 0x06004FEE ; mov r15,r14
    goto L_060052AE;  // 06004FEA bra 0x060052AE ; nop
L_06004FEE:
    c.r[10] = c.r[2];  // 06004FEE mov r2,r10
    c.r[11] = c.r[10];  // 06004FF0 mov r10,r11
    c.r[11] += 70;  // 06004FF2 add #70,r11
    c.r[12] = ld32(0x0600510Cu);  // 06004FF4 mov.l 0x0600510C,r12
    c.r[8] = c.r[10];  // 06004FF6 mov r10,r8
    c.r[8] += 72;  // 06004FF8 add #72,r8
L_06004FFA:
    c.r[1] = ld32(0x06005110u);  // 06004FFA mov.l 0x06005110,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06004FFC mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06004FFE extu.b r1,r0
    c.t = c.r[0] == 0x1u;  // 06005000 cmp/eq #1,r0
    { const bool k = c.t; c.r[1] = c.r[10]; if (k) { goto L_06005030; } }  // 06005002 bt/s 0x06005030 ; mov r10,r1
    c.r[1] += 68;  // 06005006 add #68,r1
    c.r[0] = ld32(0x06005114u);  // 06005008 mov.l 0x06005114,r0
    c.r[5] = ld32(0x06005118u);  // 0600500A mov.l 0x06005118,r5
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0600500C mov.b @r1,r7
    c.r[4] = c.r[14];  // 0600500E mov r14,r4
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[11]);  // 06005010 mov.b @r11,r6
    c.r[7] = c.r[7] & 0xFFu;  // 06005012 extu.b r7,r7
    c.r[1] = ld32(c.r[10]);  // 06005014 mov.l @r10,r1
    c.r[6] = c.r[6] & 0xFFu;  // 06005016 extu.b r6,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06005018 mov.b @r1,r1
    c.r[6] <<= 8;  // 0600501A shll8 r6
    c.r[1] = c.r[1] & 0xFFu;  // 0600501C extu.b r1,r1
    { const uint32_t x = c.r[0]; c.pr = 0x06005022u; c.r[6] |= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06005022u) return; }  // 0600501E jsr @r0 ; or r1,r6
    c.r[5] = 0x1Bu;  // 06005022 mov #27,r5
    { const uint32_t x = c.r[12]; c.pr = 0x06005028u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06005028u) return; }  // 06005024 jsr @r12 ; mov #0,r4
    c.r[1] = ld32(0x0600511Cu);  // 06005028 mov.l 0x0600511C,r1
    c.r[5] = c.r[0];  // 0600502A mov r0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06005030u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06005030u) return; }  // 0600502C jsr @r1 ; mov r14,r4
L_06005030:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[11]);  // 06005030 mov.b @r11,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06005032 extu.b r1,r0
    c.r[0] <<= 2;  // 06005034 shll2 r0
    c.r[1] = ld32(0x06005120u);  // 06005036 mov.l 0x06005120,r1
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 06005038 mov.l @(r0,r1),r0
    { const uint32_t x = c.r[0]; c.pr = 0x0600503Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600503Eu) return; }  // 0600503A jsr @r0 ; nop
    c.r[9] = c.r[0] & 0xFFFFu;  // 0600503E extu.w r0,r9
    c.r[1] = (uint32_t)(int16_t)ld16(0x060050F2u);  // 06005040 mov.w 0x060050F2,r1
    c.r[2] = c.r[1];  // 06005042 mov r1,r2
    c.r[2] &= c.r[9];  // 06005044 and r9,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x060050F4u);  // 06005046 mov.w 0x060050F4,r1
    c.t = c.r[2] == c.r[1];  // 06005048 cmp/eq r1,r2
    { const bool k = !c.t; c.t = (int32_t)c.r[2] > (int32_t)c.r[1]; if (k) { goto L_06005052; } }  // 0600504A bf/s 0x06005052 ; cmp/gt r1,r2
    goto L_06005204;  // 0600504E bra 0x06005204 ; nop
L_06005052:
    if (c.t) { goto L_060050B6; }  // 06005052 bt 0x060050B6
    c.r[1] = (uint32_t)(int16_t)ld16(0x060050F6u);  // 06005054 mov.w 0x060050F6,r1
    c.t = c.r[2] == c.r[1];  // 06005056 cmp/eq r1,r2
    { const bool k = !c.t; c.t = (int32_t)c.r[2] > (int32_t)c.r[1]; if (k) { goto L_06005060; } }  // 06005058 bf/s 0x06005060 ; cmp/gt r1,r2
    goto L_060051C6;  // 0600505C bra 0x060051C6 ; nop
L_06005060:
    if (c.t) { goto L_0600508A; }  // 06005060 bt 0x0600508A
    c.r[1] = (uint32_t)(int16_t)ld16(0x060050F8u);  // 06005062 mov.w 0x060050F8,r1
    c.t = c.r[2] == c.r[1];  // 06005064 cmp/eq r1,r2
    { const bool k = !c.t; c.t = (int32_t)c.r[2] > (int32_t)c.r[1]; if (k) { goto L_0600506E; } }  // 06005066 bf/s 0x0600506E ; cmp/gt r1,r2
    goto L_06005298;  // 0600506A bra 0x06005298 ; nop
L_0600506E:
    { const bool k = c.t; c.t = (c.r[2] & c.r[2]) == 0; if (k) { goto L_0600507A; } }  // 0600506E bt/s 0x0600507A ; tst r2,r2
    { const bool k = c.t; c.t = (c.r[9] & c.r[9]) == 0; if (k) { goto L_0600516A; } }  // 06005072 bt/s 0x0600516A ; tst r9,r9
    goto L_06005298;  // 06005076 bra 0x06005298 ; nop
L_0600507A:
    c.r[1] = (uint32_t)(int16_t)ld16(0x060050FAu);  // 0600507A mov.w 0x060050FA,r1
    c.t = c.r[2] == c.r[1];  // 0600507C cmp/eq r1,r2
    if (c.t) { goto L_06005084; }  // 0600507E bt 0x06005084
    goto L_06005298;  // 06005080 bra 0x06005298 ; nop
L_06005084:
    c.r[1] = ld32(c.r[8]);  // 06005084 mov.l @r8,r1
    goto L_060051C0;  // 06005086 bra 0x060051C0 ; nop
L_0600508A:
    c.r[1] = (uint32_t)(int16_t)ld16(0x060050FCu);  // 0600508A mov.w 0x060050FC,r1
    c.t = c.r[2] == c.r[1];  // 0600508C cmp/eq r1,r2
    { const bool k = !c.t; c.t = (int32_t)c.r[2] > (int32_t)c.r[1]; if (k) { goto L_06005096; } }  // 0600508E bf/s 0x06005096 ; cmp/gt r1,r2
    goto L_060051D6;  // 06005092 bra 0x060051D6 ; nop
L_06005096:
    if (c.t) { goto L_060050A6; }  // 06005096 bt 0x060050A6
    c.r[1] = (uint32_t)(int16_t)ld16(0x060050FEu);  // 06005098 mov.w 0x060050FE,r1
    c.t = c.r[2] == c.r[1];  // 0600509A cmp/eq r1,r2
    if (!c.t) { goto L_060050A2; }  // 0600509C bf 0x060050A2
    goto L_060051CE;  // 0600509E bra 0x060051CE ; nop
L_060050A2:
    goto L_06005298;  // 060050A2 bra 0x06005298 ; nop
L_060050A6:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06005100u);  // 060050A6 mov.w 0x06005100,r1
    c.t = c.r[2] == c.r[1];  // 060050A8 cmp/eq r1,r2
    { const bool k = !c.t; c.r[1] = 0x0u; if (k) { goto L_060050B2; } }  // 060050AA bf/s 0x060050B2 ; mov #0,r1
    goto L_06005206;  // 060050AE bra 0x06005206 ; nop
L_060050B2:
    goto L_06005298;  // 060050B2 bra 0x06005298 ; nop
L_060050B6:
    c.r[1] = ld32(0x06005124u);  // 060050B6 mov.l 0x06005124,r1
    c.t = c.r[2] == c.r[1];  // 060050B8 cmp/eq r1,r2
    { const bool k = !c.t; c.t = (int32_t)c.r[2] > (int32_t)c.r[1]; if (k) { goto L_060050C2; } }  // 060050BA bf/s 0x060050C2 ; cmp/gt r1,r2
    goto L_0600523A;  // 060050BE bra 0x0600523A ; nop
L_060050C2:
    if (c.t) { goto L_06005134; }  // 060050C2 bt 0x06005134
    c.r[1] = ld32(0x06005128u);  // 060050C4 mov.l 0x06005128,r1
    c.t = c.r[2] == c.r[1];  // 060050C6 cmp/eq r1,r2
    { const bool k = !c.t; c.t = (int32_t)c.r[2] > (int32_t)c.r[1]; if (k) { goto L_060050D0; } }  // 060050C8 bf/s 0x060050D0 ; cmp/gt r1,r2
    goto L_0600522C;  // 060050CC bra 0x0600522C ; nop
L_060050D0:
    if (c.t) { goto L_060050E2; }  // 060050D0 bt 0x060050E2
    c.r[1] = ld32(0x0600512Cu);  // 060050D2 mov.l 0x0600512C,r1
    c.t = c.r[2] == c.r[1];  // 060050D4 cmp/eq r1,r2
    { const bool k = !c.t; c.r[1] = 0x0u; if (k) { goto L_060050DE; } }  // 060050D6 bf/s 0x060050DE ; mov #0,r1
    goto L_0600521C;  // 060050DA bra 0x0600521C ; nop
L_060050DE:
    goto L_06005298;  // 060050DE bra 0x06005298 ; nop
L_060050E2:
    c.r[1] = ld32(0x06005130u);  // 060050E2 mov.l 0x06005130,r1
    c.t = c.r[2] == c.r[1];  // 060050E4 cmp/eq r1,r2
    if (c.t) { goto L_060050EC; }  // 060050E6 bt 0x060050EC
    goto L_06005298;  // 060050E8 bra 0x06005298 ; nop
L_060050EC:
    c.r[1] = ld32(c.r[8]);  // 060050EC mov.l @r8,r1
    goto L_06005234;  // 060050EE bra 0x06005234 ; nop
L_06005134:
    c.r[1] = ld32(0x060052C8u);  // 06005134 mov.l 0x060052C8,r1
    c.t = c.r[2] == c.r[1];  // 06005136 cmp/eq r1,r2
    { const bool k = !c.t; c.t = (int32_t)c.r[2] > (int32_t)c.r[1]; if (k) { goto L_06005140; } }  // 06005138 bf/s 0x06005140 ; cmp/gt r1,r2
    goto L_06005270;  // 0600513C bra 0x06005270 ; nop
L_06005140:
    if (c.t) { goto L_0600514E; }  // 06005140 bt 0x0600514E
    c.r[1] = ld32(0x060052CCu);  // 06005142 mov.l 0x060052CC,r1
    c.t = c.r[2] == c.r[1];  // 06005144 cmp/eq r1,r2
    { const bool k = c.t; c.r[1] = 0x0u; if (k) { goto L_06005242; } }  // 06005146 bt/s 0x06005242 ; mov #0,r1
    goto L_06005298;  // 0600514A bra 0x06005298 ; nop
L_0600514E:
    c.r[1] = ld32(0x060052D0u);  // 0600514E mov.l 0x060052D0,r1
    c.t = c.r[2] == c.r[1];  // 06005150 cmp/eq r1,r2
    { const bool k = !c.t; c.r[1] = 0x0u; if (k) { goto L_0600515A; } }  // 06005152 bf/s 0x0600515A ; mov #0,r1
    goto L_06005272;  // 06005156 bra 0x06005272 ; nop
L_0600515A:
    c.r[1] = ld32(0x060052D4u);  // 0600515A mov.l 0x060052D4,r1
    c.t = c.r[2] == c.r[1];  // 0600515C cmp/eq r1,r2
    { const bool k = !c.t; c.r[1] = 0x0u; if (k) { goto L_06005166; } }  // 0600515E bf/s 0x06005166 ; mov #0,r1
    goto L_0600528A;  // 06005162 bra 0x0600528A ; nop
L_06005166:
    goto L_06005298;  // 06005166 bra 0x06005298 ; nop
L_0600516A:
    { const bool k = !c.t; c.r[1] = c.r[10]; if (k) { goto L_06005172; } }  // 0600516A bf/s 0x06005172 ; mov r10,r1
    goto L_060052AE;  // 0600516E bra 0x060052AE ; nop
L_06005172:
    c.r[1] += 71;  // 06005172 add #71,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06005174 mov.b @r1,r3
    c.r[0] = c.r[3];  // 06005176 mov r3,r0
    c.r[0] >>= 2;  // 06005178 shlr2 r0
    c.r[0] >>= 2;  // 0600517A shlr2 r0
    c.r[0] >>= 2;  // 0600517C shlr2 r0
    c.r[0] &= 0x1u;  // 0600517E and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06005180 tst r0,r0
    { const bool k = !c.t; c.r[0] = c.r[3]; if (k) { goto L_06005194; } }  // 06005182 bf/s 0x06005194 ; mov r3,r0
    c.r[0] |= 0x40u;  // 06005186 or #64,r0
    st8(c.r[1], c.r[0]);  // 06005188 mov.b r0,@r1
    c.r[1] = ld32(0x060052D8u);  // 0600518A mov.l 0x060052D8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06005190u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06005190u) return; }  // 0600518C jsr @r1 ; nop
    c.r[14] += 64; goto L_060052B0;  // 06005190 bra 0x060052B0 ; add #64,r14
L_06005194:
    c.r[5] = 0xEu;  // 06005194 mov #14,r5
    { const uint32_t x = c.r[12]; c.pr = 0x0600519Au; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600519Au) return; }  // 06005196 jsr @r12 ; mov #0,r4
    c.r[1] = c.r[0];  // 0600519A mov r0,r1
    c.r[8] = ld32(0x060052DCu);  // 0600519C mov.l 0x060052DC,r8
    c.r[4] = ld32(0x060052E0u);  // 0600519E mov.l 0x060052E0,r4
    { const uint32_t x = c.r[8]; c.pr = 0x060051A4u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060051A4u) return; }  // 060051A0 jsr @r8 ; mov r1,r5
    c.r[5] = 0xEu;  // 060051A4 mov #14,r5
    { const uint32_t x = c.r[12]; c.pr = 0x060051AAu; c.r[4] = 0xAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060051AAu) return; }  // 060051A6 jsr @r12 ; mov #10,r4
    c.r[2] = c.r[0];  // 060051AA mov r0,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x060052C2u);  // 060051AC mov.w 0x060052C2,r1
    c.r[9] &= c.r[1];  // 060051AE and r1,r9
    c.r[9] <<= 2;  // 060051B0 shll2 r9
    c.r[1] = ld32(0x060052E4u);  // 060051B2 mov.l 0x060052E4,r1
    c.r[0] = c.r[9];  // 060051B4 mov r9,r0
    c.r[4] = ld32(c.r[0] + c.r[1]);  // 060051B6 mov.l @(r0,r1),r4
    { const uint32_t x = c.r[8]; c.pr = 0x060051BCu; c.r[5] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060051BCu) return; }  // 060051B8 jsr @r8 ; mov r2,r5
    c.r[14] += 64; goto L_060052B0;  // 060051BC bra 0x060052B0 ; add #64,r14
L_060051C0:
    c.r[1] += 1;  // 060051C0 add #1,r1
    st32(c.r[8], c.r[1]); goto L_06005298;  // 060051C2 bra 0x06005298 ; mov.l r1,@r8
L_060051C6:
    c.r[1] = ld32(c.r[8]);  // 060051C6 mov.l @r8,r1
    c.r[1] -= 1;  // 060051C8 add #-1,r1
    st32(c.r[8], c.r[1]); goto L_06005298;  // 060051CA bra 0x06005298 ; mov.l r1,@r8
L_060051CE:
    c.r[1] = (uint32_t)(int16_t)ld16(0x060052C4u);  // 060051CE mov.w 0x060052C4,r1
    c.r[9] &= c.r[1];  // 060051D0 and r1,r9
    st32(c.r[8], c.r[9]); goto L_06005298;  // 060051D2 bra 0x06005298 ; mov.l r9,@r8
L_060051D6:
    c.r[1] = 0x0u;  // 060051D6 mov #0,r1
    st32(c.r[8], c.r[1]);  // 060051D8 mov.l r1,@r8
    c.r[1] = (uint32_t)(int16_t)ld16(0x060052C4u);  // 060051DA mov.w 0x060052C4,r1
    c.r[0] = ld32(c.r[10]);  // 060051DC mov.l @r10,r0
    c.r[1] &= c.r[9];  // 060051DE and r9,r1
    c.r[3] = c.r[0];  // 060051E0 mov r0,r3
    c.r[3] += c.r[1];  // 060051E2 add r1,r3
    st32(c.r[10], c.r[3]);  // 060051E4 mov.l r3,@r10
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060051E6 mov.b @(r0,r1),r2
    c.r[2] = c.r[2] & 0xFFu;  // 060051E8 extu.b r2,r2
    c.r[1] = c.r[3];  // 060051EA mov r3,r1
    c.r[1] += 1;  // 060051EC add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060051EE mov.b @r1,r1
    c.r[2] <<= 8;  // 060051F0 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 060051F2 extu.b r1,r1
    c.r[2] |= c.r[1];  // 060051F4 or r1,r2
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 060051F6 exts.w r2,r0
    c.r[1] = c.r[3];  // 060051F8 mov r3,r1
    c.r[1] += c.r[0];  // 060051FA add r0,r1
    c.r[1] += 1;  // 060051FC add #1,r1
    st32(c.r[10], c.r[1]);  // 060051FE mov.l r1,@r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]); goto L_06005296;  // 06005200 bra 0x06005296 ; mov.b @(r0,r3),r1
L_06005204:
    c.r[1] = 0x0u;  // 06005204 mov #0,r1
L_06005206:
    st32(c.r[8], c.r[1]);  // 06005206 mov.l r1,@r8
    c.r[1] = (uint32_t)(int16_t)ld16(0x060052C4u);  // 06005208 mov.w 0x060052C4,r1
    c.r[2] = c.r[1];  // 0600520A mov r1,r2
    c.r[0] = ld32(c.r[10]);  // 0600520C mov.l @r10,r0
    c.r[2] &= c.r[9];  // 0600520E and r9,r2
    c.r[1] = c.r[0];  // 06005210 mov r0,r1
    c.r[1] += c.r[2];  // 06005212 add r2,r1
    c.r[1] += 1;  // 06005214 add #1,r1
    st32(c.r[10], c.r[1]);  // 06005216 mov.l r1,@r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]); goto L_06005296;  // 06005218 bra 0x06005296 ; mov.b @(r0,r2),r1
L_0600521C:
    st32(c.r[8], c.r[1]);  // 0600521C mov.l r1,@r8
    c.r[2] = ld32(c.r[10]);  // 0600521E mov.l @r10,r2
    c.r[1] = c.r[2];  // 06005220 mov r2,r1
    c.r[1] += 1;  // 06005222 add #1,r1
    st32(c.r[10], c.r[1]);  // 06005224 mov.l r1,@r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06005226 mov.b @r2,r1
    st8(c.r[11], c.r[1]); goto L_060052AE;  // 06005228 bra 0x060052AE ; mov.b r1,@r11
L_0600522C:
    c.r[1] = ld32(c.r[8]);  // 0600522C mov.l @r8,r1
    c.r[1] += 1;  // 0600522E add #1,r1
    st32(c.r[8], c.r[1]); goto L_060052AE;  // 06005230 bra 0x060052AE ; mov.l r1,@r8
L_06005234:
    c.r[1] -= 1;  // 06005234 add #-1,r1
    st32(c.r[8], c.r[1]); goto L_060052AE;  // 06005236 bra 0x060052AE ; mov.l r1,@r8
L_0600523A:
    c.r[1] = (uint32_t)(int16_t)ld16(0x060052C4u);  // 0600523A mov.w 0x060052C4,r1
    c.r[9] &= c.r[1];  // 0600523C and r1,r9
    st32(c.r[8], c.r[9]); goto L_060052AE;  // 0600523E bra 0x060052AE ; mov.l r9,@r8
L_06005242:
    st32(c.r[8], c.r[1]);  // 06005242 mov.l r1,@r8
    c.r[1] = (uint32_t)(int16_t)ld16(0x060052C4u);  // 06005244 mov.w 0x060052C4,r1
    c.r[0] = ld32(c.r[10]);  // 06005246 mov.l @r10,r0
    c.r[1] &= c.r[9];  // 06005248 and r9,r1
    c.r[3] = c.r[0];  // 0600524A mov r0,r3
    c.r[3] += c.r[1];  // 0600524C add r1,r3
    st32(c.r[10], c.r[3]);  // 0600524E mov.l r3,@r10
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06005250 mov.b @(r0,r1),r2
    c.r[2] = c.r[2] & 0xFFu;  // 06005252 extu.b r2,r2
    c.r[1] = c.r[3];  // 06005254 mov r3,r1
    c.r[1] += 1;  // 06005256 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06005258 mov.b @r1,r1
    c.r[2] <<= 8;  // 0600525A shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0600525C extu.b r1,r1
    c.r[2] |= c.r[1];  // 0600525E or r1,r2
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 06005260 exts.w r2,r0
    c.r[1] = c.r[3];  // 06005262 mov r3,r1
    c.r[1] += c.r[0];  // 06005264 add r0,r1
    c.r[1] += 1;  // 06005266 add #1,r1
    st32(c.r[10], c.r[1]);  // 06005268 mov.l r1,@r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0600526A mov.b @(r0,r3),r1
    st8(c.r[11], c.r[1]); goto L_060052AE;  // 0600526C bra 0x060052AE ; mov.b r1,@r11
L_06005270:
    c.r[1] = 0x0u;  // 06005270 mov #0,r1
L_06005272:
    st32(c.r[8], c.r[1]);  // 06005272 mov.l r1,@r8
    c.r[1] = (uint32_t)(int16_t)ld16(0x060052C4u);  // 06005274 mov.w 0x060052C4,r1
    c.r[2] = c.r[1];  // 06005276 mov r1,r2
    c.r[0] = ld32(c.r[10]);  // 06005278 mov.l @r10,r0
    c.r[2] &= c.r[9];  // 0600527A and r9,r2
    c.r[1] = c.r[0];  // 0600527C mov r0,r1
    c.r[1] += c.r[2];  // 0600527E add r2,r1
    c.r[1] += 1;  // 06005280 add #1,r1
    st32(c.r[10], c.r[1]);  // 06005282 mov.l r1,@r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06005284 mov.b @(r0,r2),r1
    st8(c.r[11], c.r[1]); goto L_060052AE;  // 06005286 bra 0x060052AE ; mov.b r1,@r11
L_0600528A:
    st32(c.r[8], c.r[1]);  // 0600528A mov.l r1,@r8
    c.r[2] = ld32(c.r[10]);  // 0600528C mov.l @r10,r2
    c.r[1] = c.r[2];  // 0600528E mov r2,r1
    c.r[1] += 1;  // 06005290 add #1,r1
    st32(c.r[10], c.r[1]);  // 06005292 mov.l r1,@r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06005294 mov.b @r2,r1
L_06005296:
    st8(c.r[11], c.r[1]);  // 06005296 mov.b r1,@r11
L_06005298:
    c.r[1] = ld32(0x060052E8u);  // 06005298 mov.l 0x060052E8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0600529A mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0600529C extu.b r1,r1
    c.r[1] >>= 2;  // 0600529E shlr2 r1
    c.r[1] >>= 2;  // 060052A0 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060052A2 shlr r1
    c.r[1] >>= 2;  // 060052A4 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060052A6 tst r1,r1
    if (c.t) { goto L_060052AE; }  // 060052A8 bt 0x060052AE
    SH2_POLL(c); goto L_06004FFA;  // 060052AA bra 0x06004FFA ; nop
L_060052AE:
    c.r[14] += 64;  // 060052AE add #64,r14
L_060052B0:
    c.r[15] = c.r[14];  // 060052B0 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060052B2 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060052B4 mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060052B6 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060052B8 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060052BA mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060052BC mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060052BE rts ; mov.l @r15+,r8
}

void f_06005000(SH2Context& c) {
    ran[24] = 1;
    goto L_06005000;
L_06004FFA:
    c.r[1] = ld32(0x06005110u);  // 06004FFA mov.l 0x06005110,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06004FFC mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06004FFE extu.b r1,r0
L_06005000:
    c.t = c.r[0] == 0x1u;  // 06005000 cmp/eq #1,r0
    { const bool k = c.t; c.r[1] = c.r[10]; if (k) { goto L_06005030; } }  // 06005002 bt/s 0x06005030 ; mov r10,r1
    c.r[1] += 68;  // 06005006 add #68,r1
    c.r[0] = ld32(0x06005114u);  // 06005008 mov.l 0x06005114,r0
    c.r[5] = ld32(0x06005118u);  // 0600500A mov.l 0x06005118,r5
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0600500C mov.b @r1,r7
    c.r[4] = c.r[14];  // 0600500E mov r14,r4
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[11]);  // 06005010 mov.b @r11,r6
    c.r[7] = c.r[7] & 0xFFu;  // 06005012 extu.b r7,r7
    c.r[1] = ld32(c.r[10]);  // 06005014 mov.l @r10,r1
    c.r[6] = c.r[6] & 0xFFu;  // 06005016 extu.b r6,r6
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06005018 mov.b @r1,r1
    c.r[6] <<= 8;  // 0600501A shll8 r6
    c.r[1] = c.r[1] & 0xFFu;  // 0600501C extu.b r1,r1
    { const uint32_t x = c.r[0]; c.pr = 0x06005022u; c.r[6] |= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06005022u) return; }  // 0600501E jsr @r0 ; or r1,r6
    c.r[5] = 0x1Bu;  // 06005022 mov #27,r5
    { const uint32_t x = c.r[12]; c.pr = 0x06005028u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06005028u) return; }  // 06005024 jsr @r12 ; mov #0,r4
    c.r[1] = ld32(0x0600511Cu);  // 06005028 mov.l 0x0600511C,r1
    c.r[5] = c.r[0];  // 0600502A mov r0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06005030u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06005030u) return; }  // 0600502C jsr @r1 ; mov r14,r4
L_06005030:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[11]);  // 06005030 mov.b @r11,r1
    c.r[0] = c.r[1] & 0xFFu;  // 06005032 extu.b r1,r0
    c.r[0] <<= 2;  // 06005034 shll2 r0
    c.r[1] = ld32(0x06005120u);  // 06005036 mov.l 0x06005120,r1
    c.r[0] = ld32(c.r[0] + c.r[1]);  // 06005038 mov.l @(r0,r1),r0
    { const uint32_t x = c.r[0]; c.pr = 0x0600503Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600503Eu) return; }  // 0600503A jsr @r0 ; nop
    c.r[9] = c.r[0] & 0xFFFFu;  // 0600503E extu.w r0,r9
    c.r[1] = (uint32_t)(int16_t)ld16(0x060050F2u);  // 06005040 mov.w 0x060050F2,r1
    c.r[2] = c.r[1];  // 06005042 mov r1,r2
    c.r[2] &= c.r[9];  // 06005044 and r9,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x060050F4u);  // 06005046 mov.w 0x060050F4,r1
    c.t = c.r[2] == c.r[1];  // 06005048 cmp/eq r1,r2
    { const bool k = !c.t; c.t = (int32_t)c.r[2] > (int32_t)c.r[1]; if (k) { goto L_06005052; } }  // 0600504A bf/s 0x06005052 ; cmp/gt r1,r2
    goto L_06005204;  // 0600504E bra 0x06005204 ; nop
L_06005052:
    if (c.t) { goto L_060050B6; }  // 06005052 bt 0x060050B6
    c.r[1] = (uint32_t)(int16_t)ld16(0x060050F6u);  // 06005054 mov.w 0x060050F6,r1
    c.t = c.r[2] == c.r[1];  // 06005056 cmp/eq r1,r2
    { const bool k = !c.t; c.t = (int32_t)c.r[2] > (int32_t)c.r[1]; if (k) { goto L_06005060; } }  // 06005058 bf/s 0x06005060 ; cmp/gt r1,r2
    goto L_060051C6;  // 0600505C bra 0x060051C6 ; nop
L_06005060:
    if (c.t) { goto L_0600508A; }  // 06005060 bt 0x0600508A
    c.r[1] = (uint32_t)(int16_t)ld16(0x060050F8u);  // 06005062 mov.w 0x060050F8,r1
    c.t = c.r[2] == c.r[1];  // 06005064 cmp/eq r1,r2
    { const bool k = !c.t; c.t = (int32_t)c.r[2] > (int32_t)c.r[1]; if (k) { goto L_0600506E; } }  // 06005066 bf/s 0x0600506E ; cmp/gt r1,r2
    goto L_06005298;  // 0600506A bra 0x06005298 ; nop
L_0600506E:
    { const bool k = c.t; c.t = (c.r[2] & c.r[2]) == 0; if (k) { goto L_0600507A; } }  // 0600506E bt/s 0x0600507A ; tst r2,r2
    { const bool k = c.t; c.t = (c.r[9] & c.r[9]) == 0; if (k) { goto L_0600516A; } }  // 06005072 bt/s 0x0600516A ; tst r9,r9
    goto L_06005298;  // 06005076 bra 0x06005298 ; nop
L_0600507A:
    c.r[1] = (uint32_t)(int16_t)ld16(0x060050FAu);  // 0600507A mov.w 0x060050FA,r1
    c.t = c.r[2] == c.r[1];  // 0600507C cmp/eq r1,r2
    if (c.t) { goto L_06005084; }  // 0600507E bt 0x06005084
    goto L_06005298;  // 06005080 bra 0x06005298 ; nop
L_06005084:
    c.r[1] = ld32(c.r[8]);  // 06005084 mov.l @r8,r1
    goto L_060051C0;  // 06005086 bra 0x060051C0 ; nop
L_0600508A:
    c.r[1] = (uint32_t)(int16_t)ld16(0x060050FCu);  // 0600508A mov.w 0x060050FC,r1
    c.t = c.r[2] == c.r[1];  // 0600508C cmp/eq r1,r2
    { const bool k = !c.t; c.t = (int32_t)c.r[2] > (int32_t)c.r[1]; if (k) { goto L_06005096; } }  // 0600508E bf/s 0x06005096 ; cmp/gt r1,r2
    goto L_060051D6;  // 06005092 bra 0x060051D6 ; nop
L_06005096:
    if (c.t) { goto L_060050A6; }  // 06005096 bt 0x060050A6
    c.r[1] = (uint32_t)(int16_t)ld16(0x060050FEu);  // 06005098 mov.w 0x060050FE,r1
    c.t = c.r[2] == c.r[1];  // 0600509A cmp/eq r1,r2
    if (!c.t) { goto L_060050A2; }  // 0600509C bf 0x060050A2
    goto L_060051CE;  // 0600509E bra 0x060051CE ; nop
L_060050A2:
    goto L_06005298;  // 060050A2 bra 0x06005298 ; nop
L_060050A6:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06005100u);  // 060050A6 mov.w 0x06005100,r1
    c.t = c.r[2] == c.r[1];  // 060050A8 cmp/eq r1,r2
    { const bool k = !c.t; c.r[1] = 0x0u; if (k) { goto L_060050B2; } }  // 060050AA bf/s 0x060050B2 ; mov #0,r1
    goto L_06005206;  // 060050AE bra 0x06005206 ; nop
L_060050B2:
    goto L_06005298;  // 060050B2 bra 0x06005298 ; nop
L_060050B6:
    c.r[1] = ld32(0x06005124u);  // 060050B6 mov.l 0x06005124,r1
    c.t = c.r[2] == c.r[1];  // 060050B8 cmp/eq r1,r2
    { const bool k = !c.t; c.t = (int32_t)c.r[2] > (int32_t)c.r[1]; if (k) { goto L_060050C2; } }  // 060050BA bf/s 0x060050C2 ; cmp/gt r1,r2
    goto L_0600523A;  // 060050BE bra 0x0600523A ; nop
L_060050C2:
    if (c.t) { goto L_06005134; }  // 060050C2 bt 0x06005134
    c.r[1] = ld32(0x06005128u);  // 060050C4 mov.l 0x06005128,r1
    c.t = c.r[2] == c.r[1];  // 060050C6 cmp/eq r1,r2
    { const bool k = !c.t; c.t = (int32_t)c.r[2] > (int32_t)c.r[1]; if (k) { goto L_060050D0; } }  // 060050C8 bf/s 0x060050D0 ; cmp/gt r1,r2
    goto L_0600522C;  // 060050CC bra 0x0600522C ; nop
L_060050D0:
    if (c.t) { goto L_060050E2; }  // 060050D0 bt 0x060050E2
    c.r[1] = ld32(0x0600512Cu);  // 060050D2 mov.l 0x0600512C,r1
    c.t = c.r[2] == c.r[1];  // 060050D4 cmp/eq r1,r2
    { const bool k = !c.t; c.r[1] = 0x0u; if (k) { goto L_060050DE; } }  // 060050D6 bf/s 0x060050DE ; mov #0,r1
    goto L_0600521C;  // 060050DA bra 0x0600521C ; nop
L_060050DE:
    goto L_06005298;  // 060050DE bra 0x06005298 ; nop
L_060050E2:
    c.r[1] = ld32(0x06005130u);  // 060050E2 mov.l 0x06005130,r1
    c.t = c.r[2] == c.r[1];  // 060050E4 cmp/eq r1,r2
    if (c.t) { goto L_060050EC; }  // 060050E6 bt 0x060050EC
    goto L_06005298;  // 060050E8 bra 0x06005298 ; nop
L_060050EC:
    c.r[1] = ld32(c.r[8]);  // 060050EC mov.l @r8,r1
    goto L_06005234;  // 060050EE bra 0x06005234 ; nop
L_06005134:
    c.r[1] = ld32(0x060052C8u);  // 06005134 mov.l 0x060052C8,r1
    c.t = c.r[2] == c.r[1];  // 06005136 cmp/eq r1,r2
    { const bool k = !c.t; c.t = (int32_t)c.r[2] > (int32_t)c.r[1]; if (k) { goto L_06005140; } }  // 06005138 bf/s 0x06005140 ; cmp/gt r1,r2
    goto L_06005270;  // 0600513C bra 0x06005270 ; nop
L_06005140:
    if (c.t) { goto L_0600514E; }  // 06005140 bt 0x0600514E
    c.r[1] = ld32(0x060052CCu);  // 06005142 mov.l 0x060052CC,r1
    c.t = c.r[2] == c.r[1];  // 06005144 cmp/eq r1,r2
    { const bool k = c.t; c.r[1] = 0x0u; if (k) { goto L_06005242; } }  // 06005146 bt/s 0x06005242 ; mov #0,r1
    goto L_06005298;  // 0600514A bra 0x06005298 ; nop
L_0600514E:
    c.r[1] = ld32(0x060052D0u);  // 0600514E mov.l 0x060052D0,r1
    c.t = c.r[2] == c.r[1];  // 06005150 cmp/eq r1,r2
    { const bool k = !c.t; c.r[1] = 0x0u; if (k) { goto L_0600515A; } }  // 06005152 bf/s 0x0600515A ; mov #0,r1
    goto L_06005272;  // 06005156 bra 0x06005272 ; nop
L_0600515A:
    c.r[1] = ld32(0x060052D4u);  // 0600515A mov.l 0x060052D4,r1
    c.t = c.r[2] == c.r[1];  // 0600515C cmp/eq r1,r2
    { const bool k = !c.t; c.r[1] = 0x0u; if (k) { goto L_06005166; } }  // 0600515E bf/s 0x06005166 ; mov #0,r1
    goto L_0600528A;  // 06005162 bra 0x0600528A ; nop
L_06005166:
    goto L_06005298;  // 06005166 bra 0x06005298 ; nop
L_0600516A:
    { const bool k = !c.t; c.r[1] = c.r[10]; if (k) { goto L_06005172; } }  // 0600516A bf/s 0x06005172 ; mov r10,r1
    goto L_060052AE;  // 0600516E bra 0x060052AE ; nop
L_06005172:
    c.r[1] += 71;  // 06005172 add #71,r1
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06005174 mov.b @r1,r3
    c.r[0] = c.r[3];  // 06005176 mov r3,r0
    c.r[0] >>= 2;  // 06005178 shlr2 r0
    c.r[0] >>= 2;  // 0600517A shlr2 r0
    c.r[0] >>= 2;  // 0600517C shlr2 r0
    c.r[0] &= 0x1u;  // 0600517E and #1,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 06005180 tst r0,r0
    { const bool k = !c.t; c.r[0] = c.r[3]; if (k) { goto L_06005194; } }  // 06005182 bf/s 0x06005194 ; mov r3,r0
    c.r[0] |= 0x40u;  // 06005186 or #64,r0
    st8(c.r[1], c.r[0]);  // 06005188 mov.b r0,@r1
    c.r[1] = ld32(0x060052D8u);  // 0600518A mov.l 0x060052D8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06005190u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06005190u) return; }  // 0600518C jsr @r1 ; nop
    c.r[14] += 64; goto L_060052B0;  // 06005190 bra 0x060052B0 ; add #64,r14
L_06005194:
    c.r[5] = 0xEu;  // 06005194 mov #14,r5
    { const uint32_t x = c.r[12]; c.pr = 0x0600519Au; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600519Au) return; }  // 06005196 jsr @r12 ; mov #0,r4
    c.r[1] = c.r[0];  // 0600519A mov r0,r1
    c.r[8] = ld32(0x060052DCu);  // 0600519C mov.l 0x060052DC,r8
    c.r[4] = ld32(0x060052E0u);  // 0600519E mov.l 0x060052E0,r4
    { const uint32_t x = c.r[8]; c.pr = 0x060051A4u; c.r[5] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060051A4u) return; }  // 060051A0 jsr @r8 ; mov r1,r5
    c.r[5] = 0xEu;  // 060051A4 mov #14,r5
    { const uint32_t x = c.r[12]; c.pr = 0x060051AAu; c.r[4] = 0xAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060051AAu) return; }  // 060051A6 jsr @r12 ; mov #10,r4
    c.r[2] = c.r[0];  // 060051AA mov r0,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x060052C2u);  // 060051AC mov.w 0x060052C2,r1
    c.r[9] &= c.r[1];  // 060051AE and r1,r9
    c.r[9] <<= 2;  // 060051B0 shll2 r9
    c.r[1] = ld32(0x060052E4u);  // 060051B2 mov.l 0x060052E4,r1
    c.r[0] = c.r[9];  // 060051B4 mov r9,r0
    c.r[4] = ld32(c.r[0] + c.r[1]);  // 060051B6 mov.l @(r0,r1),r4
    { const uint32_t x = c.r[8]; c.pr = 0x060051BCu; c.r[5] = c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060051BCu) return; }  // 060051B8 jsr @r8 ; mov r2,r5
    c.r[14] += 64; goto L_060052B0;  // 060051BC bra 0x060052B0 ; add #64,r14
L_060051C0:
    c.r[1] += 1;  // 060051C0 add #1,r1
    st32(c.r[8], c.r[1]); goto L_06005298;  // 060051C2 bra 0x06005298 ; mov.l r1,@r8
L_060051C6:
    c.r[1] = ld32(c.r[8]);  // 060051C6 mov.l @r8,r1
    c.r[1] -= 1;  // 060051C8 add #-1,r1
    st32(c.r[8], c.r[1]); goto L_06005298;  // 060051CA bra 0x06005298 ; mov.l r1,@r8
L_060051CE:
    c.r[1] = (uint32_t)(int16_t)ld16(0x060052C4u);  // 060051CE mov.w 0x060052C4,r1
    c.r[9] &= c.r[1];  // 060051D0 and r1,r9
    st32(c.r[8], c.r[9]); goto L_06005298;  // 060051D2 bra 0x06005298 ; mov.l r9,@r8
L_060051D6:
    c.r[1] = 0x0u;  // 060051D6 mov #0,r1
    st32(c.r[8], c.r[1]);  // 060051D8 mov.l r1,@r8
    c.r[1] = (uint32_t)(int16_t)ld16(0x060052C4u);  // 060051DA mov.w 0x060052C4,r1
    c.r[0] = ld32(c.r[10]);  // 060051DC mov.l @r10,r0
    c.r[1] &= c.r[9];  // 060051DE and r9,r1
    c.r[3] = c.r[0];  // 060051E0 mov r0,r3
    c.r[3] += c.r[1];  // 060051E2 add r1,r3
    st32(c.r[10], c.r[3]);  // 060051E4 mov.l r3,@r10
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060051E6 mov.b @(r0,r1),r2
    c.r[2] = c.r[2] & 0xFFu;  // 060051E8 extu.b r2,r2
    c.r[1] = c.r[3];  // 060051EA mov r3,r1
    c.r[1] += 1;  // 060051EC add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060051EE mov.b @r1,r1
    c.r[2] <<= 8;  // 060051F0 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 060051F2 extu.b r1,r1
    c.r[2] |= c.r[1];  // 060051F4 or r1,r2
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 060051F6 exts.w r2,r0
    c.r[1] = c.r[3];  // 060051F8 mov r3,r1
    c.r[1] += c.r[0];  // 060051FA add r0,r1
    c.r[1] += 1;  // 060051FC add #1,r1
    st32(c.r[10], c.r[1]);  // 060051FE mov.l r1,@r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]); goto L_06005296;  // 06005200 bra 0x06005296 ; mov.b @(r0,r3),r1
L_06005204:
    c.r[1] = 0x0u;  // 06005204 mov #0,r1
L_06005206:
    st32(c.r[8], c.r[1]);  // 06005206 mov.l r1,@r8
    c.r[1] = (uint32_t)(int16_t)ld16(0x060052C4u);  // 06005208 mov.w 0x060052C4,r1
    c.r[2] = c.r[1];  // 0600520A mov r1,r2
    c.r[0] = ld32(c.r[10]);  // 0600520C mov.l @r10,r0
    c.r[2] &= c.r[9];  // 0600520E and r9,r2
    c.r[1] = c.r[0];  // 06005210 mov r0,r1
    c.r[1] += c.r[2];  // 06005212 add r2,r1
    c.r[1] += 1;  // 06005214 add #1,r1
    st32(c.r[10], c.r[1]);  // 06005216 mov.l r1,@r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]); goto L_06005296;  // 06005218 bra 0x06005296 ; mov.b @(r0,r2),r1
L_0600521C:
    st32(c.r[8], c.r[1]);  // 0600521C mov.l r1,@r8
    c.r[2] = ld32(c.r[10]);  // 0600521E mov.l @r10,r2
    c.r[1] = c.r[2];  // 06005220 mov r2,r1
    c.r[1] += 1;  // 06005222 add #1,r1
    st32(c.r[10], c.r[1]);  // 06005224 mov.l r1,@r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06005226 mov.b @r2,r1
    st8(c.r[11], c.r[1]); goto L_060052AE;  // 06005228 bra 0x060052AE ; mov.b r1,@r11
L_0600522C:
    c.r[1] = ld32(c.r[8]);  // 0600522C mov.l @r8,r1
    c.r[1] += 1;  // 0600522E add #1,r1
    st32(c.r[8], c.r[1]); goto L_060052AE;  // 06005230 bra 0x060052AE ; mov.l r1,@r8
L_06005234:
    c.r[1] -= 1;  // 06005234 add #-1,r1
    st32(c.r[8], c.r[1]); goto L_060052AE;  // 06005236 bra 0x060052AE ; mov.l r1,@r8
L_0600523A:
    c.r[1] = (uint32_t)(int16_t)ld16(0x060052C4u);  // 0600523A mov.w 0x060052C4,r1
    c.r[9] &= c.r[1];  // 0600523C and r1,r9
    st32(c.r[8], c.r[9]); goto L_060052AE;  // 0600523E bra 0x060052AE ; mov.l r9,@r8
L_06005242:
    st32(c.r[8], c.r[1]);  // 06005242 mov.l r1,@r8
    c.r[1] = (uint32_t)(int16_t)ld16(0x060052C4u);  // 06005244 mov.w 0x060052C4,r1
    c.r[0] = ld32(c.r[10]);  // 06005246 mov.l @r10,r0
    c.r[1] &= c.r[9];  // 06005248 and r9,r1
    c.r[3] = c.r[0];  // 0600524A mov r0,r3
    c.r[3] += c.r[1];  // 0600524C add r1,r3
    st32(c.r[10], c.r[3]);  // 0600524E mov.l r3,@r10
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06005250 mov.b @(r0,r1),r2
    c.r[2] = c.r[2] & 0xFFu;  // 06005252 extu.b r2,r2
    c.r[1] = c.r[3];  // 06005254 mov r3,r1
    c.r[1] += 1;  // 06005256 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06005258 mov.b @r1,r1
    c.r[2] <<= 8;  // 0600525A shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0600525C extu.b r1,r1
    c.r[2] |= c.r[1];  // 0600525E or r1,r2
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[2];  // 06005260 exts.w r2,r0
    c.r[1] = c.r[3];  // 06005262 mov r3,r1
    c.r[1] += c.r[0];  // 06005264 add r0,r1
    c.r[1] += 1;  // 06005266 add #1,r1
    st32(c.r[10], c.r[1]);  // 06005268 mov.l r1,@r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 0600526A mov.b @(r0,r3),r1
    st8(c.r[11], c.r[1]); goto L_060052AE;  // 0600526C bra 0x060052AE ; mov.b r1,@r11
L_06005270:
    c.r[1] = 0x0u;  // 06005270 mov #0,r1
L_06005272:
    st32(c.r[8], c.r[1]);  // 06005272 mov.l r1,@r8
    c.r[1] = (uint32_t)(int16_t)ld16(0x060052C4u);  // 06005274 mov.w 0x060052C4,r1
    c.r[2] = c.r[1];  // 06005276 mov r1,r2
    c.r[0] = ld32(c.r[10]);  // 06005278 mov.l @r10,r0
    c.r[2] &= c.r[9];  // 0600527A and r9,r2
    c.r[1] = c.r[0];  // 0600527C mov r0,r1
    c.r[1] += c.r[2];  // 0600527E add r2,r1
    c.r[1] += 1;  // 06005280 add #1,r1
    st32(c.r[10], c.r[1]);  // 06005282 mov.l r1,@r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 06005284 mov.b @(r0,r2),r1
    st8(c.r[11], c.r[1]); goto L_060052AE;  // 06005286 bra 0x060052AE ; mov.b r1,@r11
L_0600528A:
    st32(c.r[8], c.r[1]);  // 0600528A mov.l r1,@r8
    c.r[2] = ld32(c.r[10]);  // 0600528C mov.l @r10,r2
    c.r[1] = c.r[2];  // 0600528E mov r2,r1
    c.r[1] += 1;  // 06005290 add #1,r1
    st32(c.r[10], c.r[1]);  // 06005292 mov.l r1,@r10
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06005294 mov.b @r2,r1
L_06005296:
    st8(c.r[11], c.r[1]);  // 06005296 mov.b r1,@r11
L_06005298:
    c.r[1] = ld32(0x060052E8u);  // 06005298 mov.l 0x060052E8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0600529A mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0600529C extu.b r1,r1
    c.r[1] >>= 2;  // 0600529E shlr2 r1
    c.r[1] >>= 2;  // 060052A0 shlr2 r1
    c.t = c.r[1] & 1; c.r[1] >>= 1;  // 060052A2 shlr r1
    c.r[1] >>= 2;  // 060052A4 shlr2 r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060052A6 tst r1,r1
    if (c.t) { goto L_060052AE; }  // 060052A8 bt 0x060052AE
    SH2_POLL(c); goto L_06004FFA;  // 060052AA bra 0x06004FFA ; nop
L_060052AE:
    c.r[14] += 64;  // 060052AE add #64,r14
L_060052B0:
    c.r[15] = c.r[14];  // 060052B0 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060052B2 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060052B4 mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060052B6 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060052B8 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060052BA mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060052BC mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060052BE rts ; mov.l @r15+,r8
}

void f_06005408(SH2Context& c) {
    ran[25] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06005408 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0600540A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0600540C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0600540E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06005410 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06005412 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06005414 mov r15,r14
    c.r[9] = ld32(0x06005488u);  // 06005416 mov.l 0x06005488,r9
    c.r[1] = ld32(0x0600548Cu);  // 06005418 mov.l 0x0600548C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0600541Eu; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600541Eu) return; }  // 0600541A jsr @r1 ; mov r9,r4
    c.r[10] = ld32(0x06005490u);  // 0600541E mov.l 0x06005490,r10
    c.r[1] = ld32(0x06005494u);  // 06005420 mov.l 0x06005494,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06005426u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06005426u) return; }  // 06005422 jsr @r1 ; mov r10,r4
    c.r[0] = ld32(0x06005498u);  // 06005426 mov.l 0x06005498,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0600542Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600542Cu) return; }  // 06005428 jsr @r0 ; nop
    c.r[11] = ld32(0x0600549Cu);  // 0600542C mov.l 0x0600549C,r11
    st32(c.r[11], c.r[0]);  // 0600542E mov.l r0,@r11
    c.r[8] = ld32(0x060054A0u);  // 06005430 mov.l 0x060054A0,r8
    c.r[0] = ld32(0x060054A4u);  // 06005432 mov.l 0x060054A4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06005438u; c.r[4] = ld32(c.r[9] + 8); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06005438u) return; }  // 06005434 jsr @r0 ; mov.l @(8,r9),r4
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06005438 mov.w @r8,r1
    c.r[0] |= c.r[1];  // 0600543A or r1,r0
    st16(c.r[8], c.r[0]);  // 0600543C mov.w r0,@r8
    c.r[0] = ld32(0x060054A8u);  // 0600543E mov.l 0x060054A8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06005444u; c.r[4] = ld32(c.r[10]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06005444u) return; }  // 06005440 jsr @r0 ; mov.l @r10,r4
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06005444 mov.w @r8,r1
    c.r[0] |= c.r[1];  // 06005446 or r1,r0
    st16(c.r[8], c.r[0]);  // 06005448 mov.w r0,@r8
    c.r[0] = ld32(0x060054ACu);  // 0600544A mov.l 0x060054AC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06005450u; c.r[4] = ld32(c.r[11]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06005450u) return; }  // 0600544C jsr @r0 ; mov.l @r11,r4
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06005450 mov.w @r8,r1
    c.r[0] |= c.r[1];  // 06005452 or r1,r0
    c.r[1] = c.r[0] & 0xFFFFu;  // 06005454 extu.w r0,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06005456 tst r1,r1
    { const bool k = c.t; st16(c.r[8], c.r[0]); if (k) { goto L_06005476; } }  // 06005458 bt/s 0x06005476 ; mov.w r0,@r8
    c.r[0] = ld32(0x060054B0u);  // 0600545C mov.l 0x060054B0,r0
    c.r[5] = 0xCu;  // 0600545E mov #12,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06005464u; c.r[4] = 0xEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06005464u) return; }  // 06005460 jsr @r0 ; mov #14,r4
    c.r[4] = ld32(0x060054B4u);  // 06005464 mov.l 0x060054B4,r4
    c.r[1] = ld32(0x060054B8u);  // 06005466 mov.l 0x060054B8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0600546Cu; c.r[5] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600546Cu) return; }  // 06005468 jsr @r1 ; mov r0,r5
    c.r[8] = ld32(0x060054BCu);  // 0600546C mov.l 0x060054BC,r8
L_0600546E:
    { const uint32_t x = c.r[8]; c.pr = 0x06005472u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06005472u) return; }  // 0600546E jsr @r8 ; nop
    SH2_POLL(c); goto L_0600546E;  // 06005472 bra 0x0600546E ; nop
L_06005476:
    c.r[15] = c.r[14];  // 06005476 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06005478 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0600547A mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0600547C mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0600547E mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06005480 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06005482 rts ; mov.l @r15+,r8
}

void f_06005688(SH2Context& c) {
    ran[26] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06005688 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0600568A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0600568C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0600568E sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06005690 mov r15,r14
    c.r[9] = c.r[4];  // 06005692 mov r4,r9
    c.t = (int32_t)c.r[9] >= 0;  // 06005694 cmp/pz r9
    { const bool k = !c.t; c.r[8] = 0x1u; if (k) { goto L_0600569E; } }  // 06005696 bf/s 0x0600569E ; mov #1,r8
    c.r[0] = 0x0u; goto L_06005856;  // 0600569A bra 0x06005856 ; mov #0,r0
L_0600569E:
    c.r[1] = 0x18u;  // 0600569E mov #24,r1
    c.r[2] = c.r[9];  // 060056A0 mov r9,r2
    c.r[2] += 25;  // 060056A2 add #25,r2
    c.t = c.r[2] > c.r[1];  // 060056A4 cmp/hi r1,r2
    { const bool k = !c.t; c.r[1] = c.r[2]; if (k) { goto L_060056AE; } }  // 060056A6 bf/s 0x060056AE ; mov r2,r1
    goto L_06005834;  // 060056AA bra 0x06005834 ; nop
L_060056AE:
    c.r[1] += c.r[1];  // 060056AE add r1,r1
    c.r[0] = 0x060056BCu;  // 060056B0 mova 0x060056BC,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 060056B2 mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 060056B4 add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x06005820u: goto L_06005820; case 0x06005812u: goto L_06005812; case 0x06005806u: goto L_06005806; case 0x060057F8u: goto L_060057F8; case 0x060057EAu: goto L_060057EA; case 0x060057DCu: goto L_060057DC; case 0x060057CEu: goto L_060057CE; case 0x06005834u: goto L_06005834; case 0x060057C0u: goto L_060057C0; case 0x060057B2u: goto L_060057B2; case 0x060057A4u: goto L_060057A4; case 0x06005796u: goto L_06005796; case 0x06005788u: goto L_06005788; case 0x0600577Au: goto L_0600577A; case 0x0600576Cu: goto L_0600576C; case 0x0600575Eu: goto L_0600575E; case 0x06005750u: goto L_06005750; case 0x06005742u: goto L_06005742; case 0x06005734u: goto L_06005734; case 0x06005726u: goto L_06005726; case 0x06005718u: goto L_06005718; case 0x0600570Au: goto L_0600570A; case 0x060056FCu: goto L_060056FC; case 0x060056EEu: goto L_060056EE; default: sh2_call(c, x); return; } }  // 060056B6 jmp @r0 ; nop
L_060056EE:
    c.r[0] = ld32(0x06005864u);  // 060056EE mov.l 0x06005864,r0
    c.r[5] = 0x9u;  // 060056F0 mov #9,r5
    { const uint32_t x = c.r[0]; c.pr = 0x060056F6u; c.r[4] = 0x14u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060056F6u) return; }  // 060056F2 jsr @r0 ; mov #20,r4
    c.r[4] = ld32(0x06005868u);  // 060056F6 mov.l 0x06005868,r4
    goto L_0600582A;  // 060056F8 bra 0x0600582A ; nop
L_060056FC:
    c.r[0] = ld32(0x06005864u);  // 060056FC mov.l 0x06005864,r0
    c.r[5] = 0x9u;  // 060056FE mov #9,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06005704u; c.r[4] = 0x14u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06005704u) return; }  // 06005700 jsr @r0 ; mov #20,r4
    c.r[4] = ld32(0x0600586Cu);  // 06005704 mov.l 0x0600586C,r4
    goto L_0600582A;  // 06005706 bra 0x0600582A ; nop
L_0600570A:
    c.r[0] = ld32(0x06005864u);  // 0600570A mov.l 0x06005864,r0
    c.r[5] = 0x9u;  // 0600570C mov #9,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06005712u; c.r[4] = 0x14u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06005712u) return; }  // 0600570E jsr @r0 ; mov #20,r4
    c.r[4] = ld32(0x06005870u);  // 06005712 mov.l 0x06005870,r4
    goto L_0600582A;  // 06005714 bra 0x0600582A ; nop
L_06005718:
    c.r[0] = ld32(0x06005864u);  // 06005718 mov.l 0x06005864,r0
    c.r[5] = 0x9u;  // 0600571A mov #9,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06005720u; c.r[4] = 0x14u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06005720u) return; }  // 0600571C jsr @r0 ; mov #20,r4
    c.r[4] = ld32(0x06005874u);  // 06005720 mov.l 0x06005874,r4
    goto L_0600582A;  // 06005722 bra 0x0600582A ; nop
L_06005726:
    c.r[0] = ld32(0x06005864u);  // 06005726 mov.l 0x06005864,r0
    c.r[5] = 0x9u;  // 06005728 mov #9,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0600572Eu; c.r[4] = 0x14u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600572Eu) return; }  // 0600572A jsr @r0 ; mov #20,r4
    c.r[4] = ld32(0x06005878u);  // 0600572E mov.l 0x06005878,r4
    goto L_0600582A;  // 06005730 bra 0x0600582A ; nop
L_06005734:
    c.r[0] = ld32(0x06005864u);  // 06005734 mov.l 0x06005864,r0
    c.r[5] = 0x9u;  // 06005736 mov #9,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0600573Cu; c.r[4] = 0x14u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600573Cu) return; }  // 06005738 jsr @r0 ; mov #20,r4
    c.r[4] = ld32(0x0600587Cu);  // 0600573C mov.l 0x0600587C,r4
    goto L_0600582A;  // 0600573E bra 0x0600582A ; nop
L_06005742:
    c.r[0] = ld32(0x06005864u);  // 06005742 mov.l 0x06005864,r0
    c.r[5] = 0x9u;  // 06005744 mov #9,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0600574Au; c.r[4] = 0x14u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600574Au) return; }  // 06005746 jsr @r0 ; mov #20,r4
    c.r[4] = ld32(0x06005880u);  // 0600574A mov.l 0x06005880,r4
    goto L_0600582A;  // 0600574C bra 0x0600582A ; nop
L_06005750:
    c.r[0] = ld32(0x06005864u);  // 06005750 mov.l 0x06005864,r0
    c.r[5] = 0x9u;  // 06005752 mov #9,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06005758u; c.r[4] = 0x14u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06005758u) return; }  // 06005754 jsr @r0 ; mov #20,r4
    c.r[4] = ld32(0x06005884u);  // 06005758 mov.l 0x06005884,r4
    goto L_0600582A;  // 0600575A bra 0x0600582A ; nop
L_0600575E:
    c.r[0] = ld32(0x06005864u);  // 0600575E mov.l 0x06005864,r0
    c.r[5] = 0x9u;  // 06005760 mov #9,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06005766u; c.r[4] = 0x14u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06005766u) return; }  // 06005762 jsr @r0 ; mov #20,r4
    c.r[4] = ld32(0x06005888u);  // 06005766 mov.l 0x06005888,r4
    goto L_0600582A;  // 06005768 bra 0x0600582A ; nop
L_0600576C:
    c.r[0] = ld32(0x06005864u);  // 0600576C mov.l 0x06005864,r0
    c.r[5] = 0x9u;  // 0600576E mov #9,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06005774u; c.r[4] = 0x14u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06005774u) return; }  // 06005770 jsr @r0 ; mov #20,r4
    c.r[4] = ld32(0x0600588Cu);  // 06005774 mov.l 0x0600588C,r4
    goto L_0600582A;  // 06005776 bra 0x0600582A ; nop
L_0600577A:
    c.r[0] = ld32(0x06005864u);  // 0600577A mov.l 0x06005864,r0
    c.r[5] = 0x9u;  // 0600577C mov #9,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06005782u; c.r[4] = 0x14u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06005782u) return; }  // 0600577E jsr @r0 ; mov #20,r4
    c.r[4] = ld32(0x06005890u);  // 06005782 mov.l 0x06005890,r4
    goto L_0600582A;  // 06005784 bra 0x0600582A ; nop
L_06005788:
    c.r[0] = ld32(0x06005864u);  // 06005788 mov.l 0x06005864,r0
    c.r[5] = 0x9u;  // 0600578A mov #9,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06005790u; c.r[4] = 0x14u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06005790u) return; }  // 0600578C jsr @r0 ; mov #20,r4
    c.r[4] = ld32(0x06005894u);  // 06005790 mov.l 0x06005894,r4
    goto L_0600582A;  // 06005792 bra 0x0600582A ; nop
L_06005796:
    c.r[0] = ld32(0x06005864u);  // 06005796 mov.l 0x06005864,r0
    c.r[5] = 0x9u;  // 06005798 mov #9,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0600579Eu; c.r[4] = 0x14u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600579Eu) return; }  // 0600579A jsr @r0 ; mov #20,r4
    c.r[4] = ld32(0x06005898u);  // 0600579E mov.l 0x06005898,r4
    goto L_0600582A;  // 060057A0 bra 0x0600582A ; nop
L_060057A4:
    c.r[0] = ld32(0x06005864u);  // 060057A4 mov.l 0x06005864,r0
    c.r[5] = 0x9u;  // 060057A6 mov #9,r5
    { const uint32_t x = c.r[0]; c.pr = 0x060057ACu; c.r[4] = 0x14u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060057ACu) return; }  // 060057A8 jsr @r0 ; mov #20,r4
    c.r[4] = ld32(0x0600589Cu);  // 060057AC mov.l 0x0600589C,r4
    goto L_0600582A;  // 060057AE bra 0x0600582A ; nop
L_060057B2:
    c.r[0] = ld32(0x06005864u);  // 060057B2 mov.l 0x06005864,r0
    c.r[5] = 0x9u;  // 060057B4 mov #9,r5
    { const uint32_t x = c.r[0]; c.pr = 0x060057BAu; c.r[4] = 0x14u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060057BAu) return; }  // 060057B6 jsr @r0 ; mov #20,r4
    c.r[4] = ld32(0x060058A0u);  // 060057BA mov.l 0x060058A0,r4
    goto L_0600582A;  // 060057BC bra 0x0600582A ; nop
L_060057C0:
    c.r[0] = ld32(0x06005864u);  // 060057C0 mov.l 0x06005864,r0
    c.r[5] = 0x9u;  // 060057C2 mov #9,r5
    { const uint32_t x = c.r[0]; c.pr = 0x060057C8u; c.r[4] = 0x14u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060057C8u) return; }  // 060057C4 jsr @r0 ; mov #20,r4
    c.r[4] = ld32(0x060058A4u);  // 060057C8 mov.l 0x060058A4,r4
    goto L_0600582A;  // 060057CA bra 0x0600582A ; nop
L_060057CE:
    c.r[0] = ld32(0x06005864u);  // 060057CE mov.l 0x06005864,r0
    c.r[5] = 0x9u;  // 060057D0 mov #9,r5
    { const uint32_t x = c.r[0]; c.pr = 0x060057D6u; c.r[4] = 0x14u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060057D6u) return; }  // 060057D2 jsr @r0 ; mov #20,r4
    c.r[4] = ld32(0x060058A8u);  // 060057D6 mov.l 0x060058A8,r4
    goto L_0600582A;  // 060057D8 bra 0x0600582A ; nop
L_060057DC:
    c.r[0] = ld32(0x06005864u);  // 060057DC mov.l 0x06005864,r0
    c.r[5] = 0x9u;  // 060057DE mov #9,r5
    { const uint32_t x = c.r[0]; c.pr = 0x060057E4u; c.r[4] = 0x14u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060057E4u) return; }  // 060057E0 jsr @r0 ; mov #20,r4
    c.r[4] = ld32(0x060058ACu);  // 060057E4 mov.l 0x060058AC,r4
    goto L_0600582A;  // 060057E6 bra 0x0600582A ; nop
L_060057EA:
    c.r[0] = ld32(0x06005864u);  // 060057EA mov.l 0x06005864,r0
    c.r[5] = 0x9u;  // 060057EC mov #9,r5
    { const uint32_t x = c.r[0]; c.pr = 0x060057F2u; c.r[4] = 0x14u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060057F2u) return; }  // 060057EE jsr @r0 ; mov #20,r4
    c.r[4] = ld32(0x060058B0u);  // 060057F2 mov.l 0x060058B0,r4
    goto L_0600582A;  // 060057F4 bra 0x0600582A ; nop
L_060057F8:
    c.r[0] = ld32(0x06005864u);  // 060057F8 mov.l 0x06005864,r0
    c.r[5] = 0x9u;  // 060057FA mov #9,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06005800u; c.r[4] = 0x14u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06005800u) return; }  // 060057FC jsr @r0 ; mov #20,r4
    c.r[4] = ld32(0x060058B4u);  // 06005800 mov.l 0x060058B4,r4
    goto L_0600582A;  // 06005802 bra 0x0600582A ; nop
L_06005806:
    c.r[1] = ld32(0x060058B8u);  // 06005806 mov.l 0x060058B8,r1
    c.r[1] = ld32(c.r[1]);  // 06005808 mov.l @r1,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0600580Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600580Eu) return; }  // 0600580A jsr @r1 ; nop
    c.r[0] = c.r[8]; goto L_06005856;  // 0600580E bra 0x06005856 ; mov r8,r0
L_06005812:
    c.r[0] = ld32(0x06005864u);  // 06005812 mov.l 0x06005864,r0
    c.r[5] = 0x9u;  // 06005814 mov #9,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0600581Au; c.r[4] = 0x14u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600581Au) return; }  // 06005816 jsr @r0 ; mov #20,r4
    c.r[4] = ld32(0x060058BCu);  // 0600581A mov.l 0x060058BC,r4
    goto L_0600582A;  // 0600581C bra 0x0600582A ; nop
L_06005820:
    c.r[0] = ld32(0x06005864u);  // 06005820 mov.l 0x06005864,r0
    c.r[5] = 0x9u;  // 06005822 mov #9,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06005828u; c.r[4] = 0x14u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06005828u) return; }  // 06005824 jsr @r0 ; mov #20,r4
    c.r[4] = ld32(0x060058C0u);  // 06005828 mov.l 0x060058C0,r4
L_0600582A:
    c.r[1] = ld32(0x060058C4u);  // 0600582A mov.l 0x060058C4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06005830u; c.r[5] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06005830u) return; }  // 0600582C jsr @r1 ; mov r0,r5
    c.r[0] = c.r[8]; goto L_06005856;  // 06005830 bra 0x06005856 ; mov r8,r0
L_06005834:
    c.r[8] = ld32(0x06005864u);  // 06005834 mov.l 0x06005864,r8
    c.r[5] = 0x9u;  // 06005836 mov #9,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0600583Cu; c.r[4] = 0xBu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600583Cu) return; }  // 06005838 jsr @r8 ; mov #11,r4
    c.r[4] = ld32(0x060058C8u);  // 0600583C mov.l 0x060058C8,r4
    c.r[1] = ld32(0x060058C4u);  // 0600583E mov.l 0x060058C4,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06005844u; c.r[5] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06005844u) return; }  // 06005840 jsr @r1 ; mov r0,r5
    c.r[5] = 0x9u;  // 06005844 mov #9,r5
    { const uint32_t x = c.r[8]; c.pr = 0x0600584Au; c.r[4] = 0x1Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600584Au) return; }  // 06005846 jsr @r8 ; mov #30,r4
    c.r[1] = ld32(0x060058CCu);  // 0600584A mov.l 0x060058CC,r1
    c.r[5] = c.r[0];  // 0600584C mov r0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06005852u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06005852u) return; }  // 0600584E jsr @r1 ; mov r9,r4
    c.r[8] = 0xFFFFFFFFu;  // 06005852 mov #-1,r8
    c.r[0] = c.r[8];  // 06005854 mov r8,r0
L_06005856:
    c.r[15] = c.r[14];  // 06005856 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06005858 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0600585A mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0600585C mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0600585E rts ; mov.l @r15+,r8
}

void f_06005998(SH2Context& c) {
    ran[27] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06005998 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0600599A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0600599C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0600599E sts.l pr,@-r15
    c.r[14] = c.r[15];  // 060059A0 mov r15,r14
    c.r[9] = c.r[4];  // 060059A2 mov r4,r9
    c.t = (int32_t)c.r[9] >= 0;  // 060059A4 cmp/pz r9
    { const bool k = !c.t; c.r[8] = 0x1u; if (k) { goto L_060059AE; } }  // 060059A6 bf/s 0x060059AE ; mov #1,r8
    c.r[0] = 0x0u; goto L_06005AC6;  // 060059AA bra 0x06005AC6 ; mov #0,r0
L_060059AE:
    c.r[1] = 0x18u;  // 060059AE mov #24,r1
    c.r[2] = c.r[9];  // 060059B0 mov r9,r2
    c.r[2] += 25;  // 060059B2 add #25,r2
    c.t = c.r[2] > c.r[1];  // 060059B4 cmp/hi r1,r2
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_06005AA4; } }  // 060059B6 bt/s 0x06005AA4 ; mov r2,r1
    c.r[1] += c.r[1];  // 060059BA add r1,r1
    c.r[0] = 0x060059C8u;  // 060059BC mova 0x060059C8,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 060059BE mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 060059C0 add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x06005A90u: goto L_06005A90; case 0x06005AA4u: goto L_06005AA4; case 0x06005A84u: goto L_06005A84; case 0x06005A76u: goto L_06005A76; case 0x06005A68u: goto L_06005A68; case 0x06005A5Au: goto L_06005A5A; case 0x06005A4Cu: goto L_06005A4C; case 0x06005A3Eu: goto L_06005A3E; case 0x06005A30u: goto L_06005A30; case 0x06005A22u: goto L_06005A22; case 0x06005A14u: goto L_06005A14; case 0x060059FAu: goto L_060059FA; default: sh2_call(c, x); return; } }  // 060059C2 jmp @r0 ; nop
L_060059FA:
    c.r[0] = ld32(0x06005AD4u);  // 060059FA mov.l 0x06005AD4,r0
    c.r[5] = 0xAu;  // 060059FC mov #10,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06005A02u; c.r[4] = 0x14u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06005A02u) return; }  // 060059FE jsr @r0 ; mov #20,r4
    c.r[4] = ld32(0x06005AD8u);  // 06005A02 mov.l 0x06005AD8,r4
    c.r[1] = ld32(0x06005ADCu);  // 06005A04 mov.l 0x06005ADC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06005A0Au; c.r[5] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06005A0Au) return; }  // 06005A06 jsr @r1 ; mov r0,r5
    c.r[0] = ld32(0x06005AE0u);  // 06005A0A mov.l 0x06005AE0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06005A10u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06005A10u) return; }  // 06005A0C jsr @r0 ; nop
    c.r[0] = 0x0u; goto L_06005AC6;  // 06005A10 bra 0x06005AC6 ; mov #0,r0
L_06005A14:
    c.r[0] = ld32(0x06005AD4u);  // 06005A14 mov.l 0x06005AD4,r0
    c.r[5] = 0xAu;  // 06005A16 mov #10,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06005A1Cu; c.r[4] = 0x14u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06005A1Cu) return; }  // 06005A18 jsr @r0 ; mov #20,r4
    c.r[4] = ld32(0x06005AE4u);  // 06005A1C mov.l 0x06005AE4,r4
    goto L_06005A9A;  // 06005A1E bra 0x06005A9A ; nop
L_06005A22:
    c.r[0] = ld32(0x06005AD4u);  // 06005A22 mov.l 0x06005AD4,r0
    c.r[5] = 0xAu;  // 06005A24 mov #10,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06005A2Au; c.r[4] = 0x14u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06005A2Au) return; }  // 06005A26 jsr @r0 ; mov #20,r4
    c.r[4] = ld32(0x06005AE8u);  // 06005A2A mov.l 0x06005AE8,r4
    goto L_06005A9A;  // 06005A2C bra 0x06005A9A ; nop
L_06005A30:
    c.r[0] = ld32(0x06005AD4u);  // 06005A30 mov.l 0x06005AD4,r0
    c.r[5] = 0xAu;  // 06005A32 mov #10,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06005A38u; c.r[4] = 0x14u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06005A38u) return; }  // 06005A34 jsr @r0 ; mov #20,r4
    c.r[4] = ld32(0x06005AECu);  // 06005A38 mov.l 0x06005AEC,r4
    goto L_06005A9A;  // 06005A3A bra 0x06005A9A ; nop
L_06005A3E:
    c.r[0] = ld32(0x06005AD4u);  // 06005A3E mov.l 0x06005AD4,r0
    c.r[5] = 0xAu;  // 06005A40 mov #10,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06005A46u; c.r[4] = 0x14u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06005A46u) return; }  // 06005A42 jsr @r0 ; mov #20,r4
    c.r[4] = ld32(0x06005AF0u);  // 06005A46 mov.l 0x06005AF0,r4
    goto L_06005A9A;  // 06005A48 bra 0x06005A9A ; nop
L_06005A4C:
    c.r[0] = ld32(0x06005AD4u);  // 06005A4C mov.l 0x06005AD4,r0
    c.r[5] = 0xAu;  // 06005A4E mov #10,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06005A54u; c.r[4] = 0x14u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06005A54u) return; }  // 06005A50 jsr @r0 ; mov #20,r4
    c.r[4] = ld32(0x06005AF4u);  // 06005A54 mov.l 0x06005AF4,r4
    goto L_06005A9A;  // 06005A56 bra 0x06005A9A ; nop
L_06005A5A:
    c.r[0] = ld32(0x06005AD4u);  // 06005A5A mov.l 0x06005AD4,r0
    c.r[5] = 0xAu;  // 06005A5C mov #10,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06005A62u; c.r[4] = 0x14u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06005A62u) return; }  // 06005A5E jsr @r0 ; mov #20,r4
    c.r[4] = ld32(0x06005AF8u);  // 06005A62 mov.l 0x06005AF8,r4
    goto L_06005A9A;  // 06005A64 bra 0x06005A9A ; nop
L_06005A68:
    c.r[0] = ld32(0x06005AD4u);  // 06005A68 mov.l 0x06005AD4,r0
    c.r[5] = 0xAu;  // 06005A6A mov #10,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06005A70u; c.r[4] = 0x14u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06005A70u) return; }  // 06005A6C jsr @r0 ; mov #20,r4
    c.r[4] = ld32(0x06005AFCu);  // 06005A70 mov.l 0x06005AFC,r4
    goto L_06005A9A;  // 06005A72 bra 0x06005A9A ; nop
L_06005A76:
    c.r[0] = ld32(0x06005AD4u);  // 06005A76 mov.l 0x06005AD4,r0
    c.r[5] = 0xAu;  // 06005A78 mov #10,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06005A7Eu; c.r[4] = 0x14u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06005A7Eu) return; }  // 06005A7A jsr @r0 ; mov #20,r4
    c.r[4] = ld32(0x06005B00u);  // 06005A7E mov.l 0x06005B00,r4
    goto L_06005A9A;  // 06005A80 bra 0x06005A9A ; nop
L_06005A84:
    c.r[1] = ld32(0x06005B04u);  // 06005A84 mov.l 0x06005B04,r1
    c.r[1] = ld32(c.r[1]);  // 06005A86 mov.l @r1,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06005A8Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06005A8Cu) return; }  // 06005A88 jsr @r1 ; nop
    c.r[0] = c.r[8]; goto L_06005AC6;  // 06005A8C bra 0x06005AC6 ; mov r8,r0
L_06005A90:
    c.r[0] = ld32(0x06005AD4u);  // 06005A90 mov.l 0x06005AD4,r0
    c.r[5] = 0xAu;  // 06005A92 mov #10,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06005A98u; c.r[4] = 0x14u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06005A98u) return; }  // 06005A94 jsr @r0 ; mov #20,r4
    c.r[4] = ld32(0x06005B08u);  // 06005A98 mov.l 0x06005B08,r4
L_06005A9A:
    c.r[1] = ld32(0x06005ADCu);  // 06005A9A mov.l 0x06005ADC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06005AA0u; c.r[5] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06005AA0u) return; }  // 06005A9C jsr @r1 ; mov r0,r5
    c.r[0] = c.r[8]; goto L_06005AC6;  // 06005AA0 bra 0x06005AC6 ; mov r8,r0
L_06005AA4:
    c.r[8] = ld32(0x06005AD4u);  // 06005AA4 mov.l 0x06005AD4,r8
    c.r[5] = 0xAu;  // 06005AA6 mov #10,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06005AACu; c.r[4] = 0xBu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06005AACu) return; }  // 06005AA8 jsr @r8 ; mov #11,r4
    c.r[4] = ld32(0x06005B0Cu);  // 06005AAC mov.l 0x06005B0C,r4
    c.r[1] = ld32(0x06005ADCu);  // 06005AAE mov.l 0x06005ADC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06005AB4u; c.r[5] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06005AB4u) return; }  // 06005AB0 jsr @r1 ; mov r0,r5
    c.r[5] = 0xAu;  // 06005AB4 mov #10,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06005ABAu; c.r[4] = 0x1Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06005ABAu) return; }  // 06005AB6 jsr @r8 ; mov #30,r4
    c.r[1] = ld32(0x06005B10u);  // 06005ABA mov.l 0x06005B10,r1
    c.r[5] = c.r[0];  // 06005ABC mov r0,r5
    { const uint32_t x = c.r[1]; c.pr = 0x06005AC2u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06005AC2u) return; }  // 06005ABE jsr @r1 ; mov r9,r4
    c.r[8] = 0xFFFFFFFFu;  // 06005AC2 mov #-1,r8
    c.r[0] = c.r[8];  // 06005AC4 mov r8,r0
L_06005AC6:
    c.r[15] = c.r[14];  // 06005AC6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06005AC8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06005ACA mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06005ACC mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06005ACE rts ; mov.l @r15+,r8
}

void f_06005D7C(SH2Context& c) {
    ran[28] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06005D7C mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06005D7E mov r15,r14
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06005D80 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[0] = 0x0u; c.pc = x; return; }  // 06005D82 rts ; mov #0,r0
}

void f_06005D88(SH2Context& c) {
    ran[29] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06005D88 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06005D8A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06005D8C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06005D8E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06005D90 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06005D92 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06005D94 mov r15,r14
    c.r[0] = ld32(0x06005DF8u);  // 06005D96 mov.l 0x06005DF8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06005D9Cu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06005D9Cu) return; }  // 06005D98 jsr @r0 ; mov #0,r4
    c.r[9] = 0x0u;  // 06005D9C mov #0,r9
    c.r[11] = ld32(0x06005DFCu);  // 06005D9E mov.l 0x06005DFC,r11
    c.r[10] = ld32(0x06005E00u);  // 06005DA0 mov.l 0x06005E00,r10
    c.r[8] = c.r[9] & 0xFFu;  // 06005DA2 extu.b r9,r8
L_06005DA4:
    c.r[5] = 0x0u;  // 06005DA4 mov #0,r5
    { const uint32_t x = c.r[11]; c.pr = 0x06005DAAu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06005DAAu) return; }  // 06005DA6 jsr @r11 ; mov r8,r4
    c.r[6] = 0x0u;  // 06005DAA mov #0,r6
    c.r[5] = 0x7u;  // 06005DAC mov #7,r5
    { const uint32_t x = c.r[10]; c.pr = 0x06005DB2u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06005DB2u) return; }  // 06005DAE jsr @r10 ; mov r8,r4
    c.r[9] += 1;  // 06005DB2 add #1,r9
    c.r[1] = 0x4u;  // 06005DB4 mov #4,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 06005DB6 cmp/gt r1,r9
    { const bool k = !c.t; c.r[8] = c.r[9] & 0xFFu; if (k) { SH2_POLL(c); goto L_06005DA4; } }  // 06005DB8 bf/s 0x06005DA4 ; extu.b r9,r8
    c.r[0] = ld32(0x06005E04u);  // 06005DBC mov.l 0x06005E04,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06005DC2u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06005DC2u) return; }  // 06005DBE jsr @r0 ; mov #0,r4
    c.r[2] = ld32(0x06005E08u);  // 06005DC2 mov.l 0x06005E08,r2
    c.r[1] = 0x1u;  // 06005DC4 mov #1,r1
    st16(c.r[2], c.r[1]);  // 06005DC6 mov.w r1,@r2
    c.r[2] = ld32(0x06005E0Cu);  // 06005DC8 mov.l 0x06005E0C,r2
    c.r[1] = 0x8u;  // 06005DCA mov #8,r1
    st16(c.r[2], c.r[1]);  // 06005DCC mov.w r1,@r2
    c.r[2] = ld32(0x06005E10u);  // 06005DCE mov.l 0x06005E10,r2
    c.r[1] = ld32(0x06005E14u);  // 06005DD0 mov.l 0x06005E14,r1
    st32(c.r[2], c.r[1]);  // 06005DD2 mov.l r1,@r2
    c.r[2] = ld32(0x06005E18u);  // 06005DD4 mov.l 0x06005E18,r2
    c.r[1] = ld32(0x06005E1Cu);  // 06005DD6 mov.l 0x06005E1C,r1
    st32(c.r[2], c.r[1]);  // 06005DD8 mov.l r1,@r2
    c.r[2] = ld32(0x06005E20u);  // 06005DDA mov.l 0x06005E20,r2
    c.r[1] = ld32(0x06005E24u);  // 06005DDC mov.l 0x06005E24,r1
    st32(c.r[2], c.r[1]);  // 06005DDE mov.l r1,@r2
    c.r[2] = ld32(0x06005E28u);  // 06005DE0 mov.l 0x06005E28,r2
    c.r[1] = ld32(0x06005E2Cu);  // 06005DE2 mov.l 0x06005E2C,r1
    st32(c.r[2], c.r[1]);  // 06005DE4 mov.l r1,@r2
    c.r[15] = c.r[14];  // 06005DE6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06005DE8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06005DEA mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06005DEC mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06005DEE mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06005DF0 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06005DF2 rts ; mov.l @r15+,r8
}

void f_06005E3C(SH2Context& c) {
    ran[30] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06005E3C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06005E3E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06005E40 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06005E42 sts.l pr,@-r15
    c.r[15] -= 16;  // 06005E44 add #-16,r15
    c.r[14] = c.r[15];  // 06005E46 mov r15,r14
    c.r[9] = ld32(0x06005EF8u);  // 06005E48 mov.l 0x06005EF8,r9
    c.r[4] = ld32(0x06005EFCu);  // 06005E4A mov.l 0x06005EFC,r4
    c.r[7] = 0xDu;  // 06005E4C mov #13,r7
    c.r[6] = c.r[9];  // 06005E4E mov r9,r6
    c.r[0] = ld32(0x06005F00u);  // 06005E50 mov.l 0x06005F00,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06005E56u; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06005E56u) return; }  // 06005E52 jsr @r0 ; mov #0,r5
    c.t = c.r[0] == 0xFFFFFFFFu;  // 06005E56 cmp/eq #-1,r0
    { const bool k = c.t; c.r[8] = c.r[0]; if (k) { goto L_06005EE4; } }  // 06005E58 bt/s 0x06005EE4 ; mov r0,r8
    c.r[8] = 0x0u;  // 06005E5C mov #0,r8
    st32(c.r[14], c.r[9]);  // 06005E5E mov.l r9,@r14
    c.r[2] = c.r[14];  // 06005E60 mov r14,r2
    c.r[2] += 4;  // 06005E62 add #4,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06005EF2u);  // 06005E64 mov.w 0x06005EF2,r1
    st16(c.r[2], c.r[1]);  // 06005E66 mov.w r1,@r2
    c.r[1] = ld32(0x06005F04u);  // 06005E68 mov.l 0x06005F04,r1
    st32(c.r[14] + 8, c.r[1]);  // 06005E6A mov.l r1,@(8,r14)
    c.r[2] = c.r[14];  // 06005E6C mov r14,r2
    c.r[2] += 12;  // 06005E6E add #12,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06005EF4u);  // 06005E70 mov.w 0x06005EF4,r1
    st16(c.r[2], c.r[1]);  // 06005E72 mov.w r1,@r2
    c.r[1] = ld32(0x06005F08u);  // 06005E74 mov.l 0x06005F08,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06005E7Au; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06005E7Au) return; }  // 06005E76 jsr @r1 ; mov r14,r4
    c.r[0] = ld32(0x06005F0Cu);  // 06005E7A mov.l 0x06005F0C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06005E80u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06005E80u) return; }  // 06005E7C jsr @r0 ; nop
    c.r[0] = ld32(0x06005F10u);  // 06005E80 mov.l 0x06005F10,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06005E86u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06005E86u) return; }  // 06005E82 jsr @r0 ; nop
    c.r[0] = ld32(0x06005F14u);  // 06005E86 mov.l 0x06005F14,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06005E8Cu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06005E8Cu) return; }  // 06005E88 jsr @r0 ; mov #0,r4
    c.r[1] = ld32(0x06005F18u);  // 06005E8C mov.l 0x06005F18,r1
    c.r[7] = 0x0u;  // 06005E8E mov #0,r7
    st16(c.r[1], c.r[7]);  // 06005E90 mov.w r7,@r1
    c.r[2] = ld32(0x06005F1Cu);  // 06005E92 mov.l 0x06005F1C,r2
    c.r[1] = c.r[2];  // 06005E94 mov r2,r1
    c.r[1] += 10;  // 06005E96 add #10,r1
    st16(c.r[1], c.r[7]);  // 06005E98 mov.w r7,@r1
    c.r[1] = c.r[2];  // 06005E9A mov r2,r1
    c.r[1] += 8;  // 06005E9C add #8,r1
    st16(c.r[1], c.r[7]);  // 06005E9E mov.w r7,@r1
    c.r[3] = c.r[2];  // 06005EA0 mov r2,r3
    c.r[3] += 4;  // 06005EA2 add #4,r3
    c.r[1] = 0x0u;  // 06005EA4 mov #0,r1
    st8(c.r[3], c.r[1]);  // 06005EA6 mov.b r1,@r3
    c.r[1] = c.r[2];  // 06005EA8 mov r2,r1
    c.r[1] += 6;  // 06005EAA add #6,r1
    st16(c.r[1], c.r[7]);  // 06005EAC mov.w r7,@r1
    c.r[3] = c.r[2];  // 06005EAE mov r2,r3
    c.r[3] += 14;  // 06005EB0 add #14,r3
    c.r[1] = 0x1u;  // 06005EB2 mov #1,r1
    st16(c.r[3], c.r[1]);  // 06005EB4 mov.w r1,@r3
    c.r[1] = 0xFFFFFFFFu;  // 06005EB6 mov #-1,r1
    st8(c.r[2], c.r[1]);  // 06005EB8 mov.b r1,@r2
    c.r[1] = c.r[2];  // 06005EBA mov r2,r1
    c.r[1] += 1;  // 06005EBC add #1,r1
    c.r[3] = 0x30u;  // 06005EBE mov #48,r3
    st8(c.r[1], c.r[3]);  // 06005EC0 mov.b r3,@r1
    c.r[1] = c.r[2];  // 06005EC2 mov r2,r1
    c.r[1] += 2;  // 06005EC4 add #2,r1
    st8(c.r[1], c.r[3]);  // 06005EC6 mov.b r3,@r1
    st32(c.r[2] + 16, c.r[8]);  // 06005EC8 mov.l r8,@(16,r2)
    c.r[0] = ld32(0x06005F20u);  // 06005ECA mov.l 0x06005F20,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06005ED0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06005ED0u) return; }  // 06005ECC jsr @r0 ; nop
    c.r[0] = c.r[0] & 0xFFu;  // 06005ED0 extu.b r0,r0
    c.t = c.r[0] == 0x1u;  // 06005ED2 cmp/eq #1,r0
    { const bool k = c.t; c.r[2] = 0x0u; if (k) { goto L_06005EDA; } }  // 06005ED4 bt/s 0x06005EDA ; mov #0,r2
    c.r[2] = (uint32_t)(int16_t)ld16(0x06005EF6u);  // 06005ED8 mov.w 0x06005EF6,r2
L_06005EDA:
    c.r[1] = ld32(0x06005F24u);  // 06005EDA mov.l 0x06005F24,r1
    c.r[1] = ld32(c.r[1]);  // 06005EDC mov.l @r1,r1
    c.r[1] += 3;  // 06005EDE add #3,r1
    st8(c.r[1], c.r[2]);  // 06005EE0 mov.b r2,@r1
    c.r[0] = 0x0u;  // 06005EE2 mov #0,r0
L_06005EE4:
    c.r[14] += 16;  // 06005EE4 add #16,r14
    c.r[15] = c.r[14];  // 06005EE6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06005EE8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06005EEA mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06005EEC mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06005EEE rts ; mov.l @r15+,r8
}

void f_06005F44(SH2Context& c) {
    ran[31] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06005F44 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06005F46 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06005F48 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06005F4A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06005F4C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06005F4E sts.l pr,@-r15
    c.r[8] = ld32(0x06006114u);  // 06005F50 mov.l 0x06006114,r8
    c.r[2] = c.r[8];  // 06005F52 mov r8,r2
    c.r[2] += 2;  // 06005F54 add #2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06005F56 mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06005F58 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06005F5A tst r1,r1
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_06005F74; } }  // 06005F5C bf/s 0x06005F74 ; mov r15,r14
    c.r[1] = 0x1u;  // 06005F60 mov #1,r1
    st8(c.r[2], c.r[1]);  // 06005F62 mov.b r1,@r2
    c.r[0] = ld32(0x06006118u);  // 06005F64 mov.l 0x06006118,r0
    c.r[5] = 0x10u;  // 06005F66 mov #16,r5
    { const uint32_t x = c.r[0]; c.pr = 0x06005F6Cu; c.r[4] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06005F6Cu) return; }  // 06005F68 jsr @r0 ; mov #2,r4
    c.r[4] = ld32(0x0600611Cu);  // 06005F6C mov.l 0x0600611C,r4
    c.r[1] = ld32(0x06006120u);  // 06005F6E mov.l 0x06006120,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06005F74u; c.r[5] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06005F74u) return; }  // 06005F70 jsr @r1 ; mov r0,r5
L_06005F74:
    c.r[1] = c.r[8];  // 06005F74 mov r8,r1
    c.r[1] += 4;  // 06005F76 add #4,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06005F78 mov.w @r1,r1
    c.r[2] = c.r[1] & 0xFFFFu;  // 06005F7A extu.w r1,r2
    c.r[1] = 0x20u;  // 06005F7C mov #32,r1
    c.t = c.r[2] > c.r[1];  // 06005F7E cmp/hi r1,r2
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_0600604A; } }  // 06005F80 bt/s 0x0600604A ; mov r2,r1
    c.r[1] += c.r[1];  // 06005F84 add r1,r1
    c.r[0] = 0x06005F90u;  // 06005F86 mova 0x06005F90,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06005F88 mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 06005F8A add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x0600604Au: goto L_0600604A; case 0x06006036u: goto L_06006036; case 0x06005FD2u: goto L_06005FD2; default: sh2_call(c, x); return; } }  // 06005F8C jmp @r0 ; nop
L_06005FD2:
    c.r[10] = ld32(0x06006114u);  // 06005FD2 mov.l 0x06006114,r10
    c.r[11] = c.r[10];  // 06005FD4 mov r10,r11
    c.r[11] += 3;  // 06005FD6 add #3,r11
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[11]);  // 06005FD8 mov.b @r11,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06005FDA extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06005FDC tst r1,r1
    { const bool k = c.t; c.r[1] = 0x0u; if (k) { goto L_06005FE4; } }  // 06005FDE bt/s 0x06005FE4 ; mov #0,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[10]);  // 06005FE2 mov.b @r10,r1
L_06005FE4:
    st8(c.r[10], c.r[1]);  // 06005FE4 mov.b r1,@r10
    c.r[9] = c.r[10];  // 06005FE6 mov r10,r9
    c.r[9] += 1;  // 06005FE8 add #1,r9
    c.r[0] = ld32(0x06006124u);  // 06005FEA mov.l 0x06006124,r0
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06005FEC mov.b @r9,r6
    c.r[4] = 0x0u;  // 06005FEE mov #0,r4
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[10]);  // 06005FF0 mov.b @r10,r5
    c.r[6] = c.r[6] & 0xFFu;  // 06005FF2 extu.b r6,r6
    { const uint32_t x = c.r[0]; c.pr = 0x06005FF8u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06005FF8u) return; }  // 06005FF4 jsr @r0 ; extu.b r5,r5
    c.r[5] = c.r[0] & 0xFFu;  // 06005FF8 extu.b r0,r5
    c.r[8] = c.r[10];  // 06005FFA mov r10,r8
    c.r[8] += 2;  // 06005FFC add #2,r8
    c.r[0] = ld32(0x06006128u);  // 06005FFE mov.l 0x06006128,r0
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06006000 mov.b @r8,r4
    c.r[6] = 0x0u;  // 06006002 mov #0,r6
    { const uint32_t x = c.r[0]; c.pr = 0x06006008u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06006008u) return; }  // 06006004 jsr @r0 ; extu.b r4,r4
    c.r[5] = (uint32_t)(int16_t)ld16(0x0600610Eu);  // 06006008 mov.w 0x0600610E,r5
    c.r[0] = ld32(0x0600612Cu);  // 0600600A mov.l 0x0600612C,r0
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0600600C mov.b @r8,r4
    c.r[6] = 0x40u;  // 0600600E mov #64,r6
    { const uint32_t x = c.r[0]; c.pr = 0x06006014u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06006014u) return; }  // 06006010 jsr @r0 ; extu.b r4,r4
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06006014 mov.b @r8,r7
    c.r[0] = ld32(0x06006130u);  // 06006016 mov.l 0x06006130,r0
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06006018 mov.b @r9,r6
    c.r[7] = c.r[7] & 0xFFu;  // 0600601A extu.b r7,r7
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[11]);  // 0600601C mov.b @r11,r5
    c.r[6] = c.r[6] & 0xFFu;  // 0600601E extu.b r6,r6
    c.r[5] += c.r[5];  // 06006020 add r5,r5
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06006022 mov.b @r8,r4
    c.r[5] = c.r[5] & 0xFFu;  // 06006024 extu.b r5,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0600602Au; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600602Au) return; }  // 06006026 jsr @r0 ; extu.b r4,r4
    c.r[2] = c.r[10];  // 0600602A mov r10,r2
    c.r[2] += 4;  // 0600602C add #4,r2
    c.r[1] = 0x20u;  // 0600602E mov #32,r1
    st16(c.r[2], c.r[1]);  // 06006030 mov.w r1,@r2
    goto L_0600604A;  // 06006032 bra 0x0600604A ; nop
L_06006036:
    c.r[8] = ld32(0x06006114u);  // 06006036 mov.l 0x06006114,r8
    c.r[1] = c.r[8];  // 06006038 mov r8,r1
    c.r[1] += 2;  // 0600603A add #2,r1
    c.r[4] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0600603C mov.b @r1,r4
    c.r[0] = ld32(0x06006134u);  // 0600603E mov.l 0x06006134,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06006044u; c.r[4] = c.r[4] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06006044u) return; }  // 06006040 jsr @r0 ; extu.b r4,r4
    c.r[8] += 4;  // 06006044 add #4,r8
    c.r[1] = 0x8u;  // 06006046 mov #8,r1
    st16(c.r[8], c.r[1]);  // 06006048 mov.w r1,@r8
L_0600604A:
    c.r[8] = ld32(0x06006138u);  // 0600604A mov.l 0x06006138,r8
    c.r[1] = ld32(c.r[8] + 16);  // 0600604C mov.l @(16,r8),r1
    c.r[10] = c.r[8];  // 0600604E mov r8,r10
    c.r[1] += 1;  // 06006050 add #1,r1
    st32(c.r[8] + 16, c.r[1]);  // 06006052 mov.l r1,@(16,r8)
    c.r[1] = ld32(c.r[8] + 16);  // 06006054 mov.l @(16,r8),r1
    c.r[10] += 14;  // 06006056 add #14,r10
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[10]);  // 06006058 mov.w @r10,r1
    c.r[2] = c.r[1] & 0xFFFFu;  // 0600605A extu.w r1,r2
    c.r[0] = c.r[2];  // 0600605C mov r2,r0
    c.t = c.r[0] == 0x8u;  // 0600605E cmp/eq #8,r0
    { const bool k = !c.t; c.r[3] = 0x8u; if (k) { goto L_06006068; } }  // 06006060 bf/s 0x06006068 ; mov #8,r3
    goto L_06006278;  // 06006064 bra 0x06006278 ; nop
L_06006068:
    c.t = (int32_t)c.r[2] > (int32_t)c.r[3];  // 06006068 cmp/gt r3,r2
    { const bool k = c.t; c.t = c.r[0] == 0x40u; if (k) { goto L_06006090; } }  // 0600606A bt/s 0x06006090 ; cmp/eq #64,r0
    c.t = c.r[0] == 0x2u;  // 0600606E cmp/eq #2,r0
    { const bool k = !c.t; c.r[9] = c.r[8]; if (k) { goto L_06006078; } }  // 06006070 bf/s 0x06006078 ; mov r8,r9
    goto L_06006202;  // 06006074 bra 0x06006202 ; nop
L_06006078:
    c.r[1] = 0x2u;  // 06006078 mov #2,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0600607A cmp/gt r1,r2
    { const bool k = c.t; c.t = c.r[0] == 0x4u; if (k) { goto L_06006084; } }  // 0600607C bt/s 0x06006084 ; cmp/eq #4,r0
    goto L_06006278;  // 06006080 bra 0x06006278 ; nop
L_06006084:
    { const bool k = !c.t; c.r[9] += 8; if (k) { goto L_0600608C; } }  // 06006084 bf/s 0x0600608C ; add #8,r9
    goto L_06006240;  // 06006088 bra 0x06006240 ; nop
L_0600608C:
    c.r[15] = c.r[14]; goto L_0600627A;  // 0600608C bra 0x0600627A ; mov r14,r15
L_06006090:
    { const bool k = !c.t; c.r[9] = c.r[8]; if (k) { goto L_06006098; } }  // 06006090 bf/s 0x06006098 ; mov r8,r9
    goto L_0600619C;  // 06006094 bra 0x0600619C ; nop
L_06006098:
    c.r[9] = 0x40u;  // 06006098 mov #64,r9
    c.t = (int32_t)c.r[2] > (int32_t)c.r[9];  // 0600609A cmp/gt r9,r2
    { const bool k = c.t; c.t = c.r[0] == 0x10u; if (k) { goto L_060060A8; } }  // 0600609C bt/s 0x060060A8 ; cmp/eq #16,r0
    { const bool k = c.t; c.r[4] = 0x0u; if (k) { goto L_060060BE; } }  // 060060A0 bt/s 0x060060BE ; mov #0,r4
    c.r[15] = c.r[14]; goto L_0600627A;  // 060060A4 bra 0x0600627A ; mov r14,r15
L_060060A8:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0600610Eu);  // 060060A8 mov.w 0x0600610E,r1
    c.t = c.r[2] == c.r[1];  // 060060AA cmp/eq r1,r2
    if (!c.t) { goto L_060060B2; }  // 060060AC bf 0x060060B2
    goto L_060061E8;  // 060060AE bra 0x060061E8 ; nop
L_060060B2:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06006110u);  // 060060B2 mov.w 0x06006110,r1
    c.t = c.r[2] == c.r[1];  // 060060B4 cmp/eq r1,r2
    { const bool k = c.t; c.r[9] = c.r[8]; if (k) { goto L_06006144; } }  // 060060B6 bt/s 0x06006144 ; mov r8,r9
    c.r[15] = c.r[14]; goto L_0600627A;  // 060060BA bra 0x0600627A ; mov r14,r15
L_060060BE:
    c.r[2] = ld32(0x0600613Cu);  // 060060BE mov.l 0x0600613C,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 060060C0 mov.b @r8,r1
    c.r[6] = 0x0u;  // 060060C2 mov #0,r6
    c.r[2] = ld32(c.r[2]);  // 060060C4 mov.l @r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 060060C6 extu.b r1,r1
    c.r[0] = c.r[2];  // 060060C8 mov r2,r0
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060060CA mov.b @(r0,r1),r5
    c.r[0] = ld32(0x06006128u);  // 060060CC mov.l 0x06006128,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060060D2u; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060060D2u) return; }  // 060060CE jsr @r0 ; extu.b r5,r5
    c.r[5] = (uint32_t)(int16_t)ld16(0x0600610Eu);  // 060060D2 mov.w 0x0600610E,r5
    c.r[6] = c.r[9];  // 060060D4 mov r9,r6
    c.r[0] = ld32(0x0600612Cu);  // 060060D6 mov.l 0x0600612C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060060DCu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060060DCu) return; }  // 060060D8 jsr @r0 ; mov #0,r4
    c.r[1] = c.r[8];  // 060060DC mov r8,r1
    c.r[1] += 12;  // 060060DE add #12,r1
    c.r[7] = 0x7u;  // 060060E0 mov #7,r7
    c.r[6] = 0x0u;  // 060060E2 mov #0,r6
    c.r[4] = 0x0u;  // 060060E4 mov #0,r4
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[1]);  // 060060E6 mov.w @r1,r5
    c.r[0] = ld32(0x06006130u);  // 060060E8 mov.l 0x06006130,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060060EEu; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060060EEu) return; }  // 060060EA jsr @r0 ; extu.b r5,r5
    c.r[1] = 0x0u;  // 060060EE mov #0,r1
    st32(c.r[8] + 16, c.r[1]);  // 060060F0 mov.l r1,@(16,r8)
    c.r[1] = c.r[8];  // 060060F2 mov r8,r1
    c.r[1] += 10;  // 060060F4 add #10,r1
    c.r[2] = 0x0u;  // 060060F6 mov #0,r2
    st16(c.r[1], c.r[2]);  // 060060F8 mov.w r2,@r1
    c.r[1] = c.r[8];  // 060060FA mov r8,r1
    c.r[1] += 8;  // 060060FC add #8,r1
    st16(c.r[1], c.r[2]);  // 060060FE mov.w r2,@r1
    c.r[1] = 0x20u;  // 06006100 mov #32,r1
    st16(c.r[10], c.r[1]);  // 06006102 mov.w r1,@r10
    c.r[0] = ld32(0x06006140u);  // 06006104 mov.l 0x06006140,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0600610Au; c.r[4] = 0xFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600610Au) return; }  // 06006106 jsr @r0 ; mov #15,r4
    c.r[15] = c.r[14]; goto L_0600627A;  // 0600610A bra 0x0600627A ; mov r14,r15
L_06006144:
    c.r[9] += 6;  // 06006144 add #6,r9
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]);  // 06006146 mov.w @r9,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06006220u);  // 06006148 mov.w 0x06006220,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 0600614A extu.w r1,r1
    c.t = c.r[1] > c.r[2];  // 0600614C cmp/hi r2,r1
    { const bool k = !c.t; c.r[8] = 0x0u; if (k) { goto L_0600616A; } }  // 0600614E bf/s 0x0600616A ; mov #0,r8
    st16(c.r[9], c.r[8]);  // 06006152 mov.w r8,@r9
    c.r[1] = 0x1u;  // 06006154 mov #1,r1
    st16(c.r[10], c.r[1]);  // 06006156 mov.w r1,@r10
    c.r[0] = ld32(0x06006224u);  // 06006158 mov.l 0x06006224,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0600615Eu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600615Eu) return; }  // 0600615A jsr @r0 ; mov #0,r4
    c.r[0] = ld32(0x06006228u);  // 0600615E mov.l 0x06006228,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06006164u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06006164u) return; }  // 06006160 jsr @r0 ; nop
    c.r[1] = ld32(0x0600622Cu);  // 06006164 mov.l 0x0600622C,r1
    st16(c.r[1], c.r[8]); goto L_0600618E;  // 06006166 bra 0x0600618E ; mov.w r8,@r1
L_0600616A:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]);  // 0600616A mov.w @r9,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06006222u);  // 0600616C mov.w 0x06006222,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 0600616E extu.w r1,r1
    c.t = c.r[1] == c.r[2];  // 06006170 cmp/eq r2,r1
    if (!c.t) { goto L_0600617E; }  // 06006172 bf 0x0600617E
L_06006174:
    c.r[0] = ld32(0x06006230u);  // 06006174 mov.l 0x06006230,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0600617Au; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600617Au) return; }  // 06006176 jsr @r0 ; mov #0,r4
    goto L_060061DC;  // 0600617A bra 0x060061DC ; nop
L_0600617E:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]);  // 0600617E mov.w @r9,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06006180 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06006182 tst r1,r1
    { const bool k = !c.t; c.r[6] = 0x3u; if (k) { goto L_0600618E; } }  // 06006184 bf/s 0x0600618E ; mov #3,r6
    c.r[0] = ld32(0x06006234u);  // 06006188 mov.l 0x06006234,r0
    c.r[5] = 0x0u; goto L_060061D8;  // 0600618A bra 0x060061D8 ; mov #0,r5
L_0600618E:
    c.r[1] = ld32(0x06006238u);  // 0600618E mov.l 0x06006238,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06006190 mov.w @r1,r2
    c.r[2] += 1;  // 06006192 add #1,r2
    st16(c.r[1], c.r[2]);  // 06006194 mov.w r2,@r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06006196 mov.w @r1,r1
    c.r[15] = c.r[14]; goto L_0600627A;  // 06006198 bra 0x0600627A ; mov r14,r15
L_0600619C:
    c.r[9] += 6;  // 0600619C add #6,r9
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]);  // 0600619E mov.w @r9,r1
    c.r[2] = 0x78u;  // 060061A0 mov #120,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 060061A2 extu.w r1,r1
    c.t = c.r[1] > c.r[2];  // 060061A4 cmp/hi r2,r1
    { const bool k = !c.t; c.r[8] = 0x0u; if (k) { goto L_060061C2; } }  // 060061A6 bf/s 0x060061C2 ; mov #0,r8
    st16(c.r[9], c.r[8]);  // 060061AA mov.w r8,@r9
    c.r[1] = 0x1u;  // 060061AC mov #1,r1
    st16(c.r[10], c.r[1]);  // 060061AE mov.w r1,@r10
    c.r[0] = ld32(0x06006224u);  // 060061B0 mov.l 0x06006224,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060061B6u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060061B6u) return; }  // 060061B2 jsr @r0 ; mov #0,r4
    c.r[0] = ld32(0x06006228u);  // 060061B6 mov.l 0x06006228,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060061BCu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060061BCu) return; }  // 060061B8 jsr @r0 ; nop
    c.r[1] = ld32(0x0600622Cu);  // 060061BC mov.l 0x0600622C,r1
    st16(c.r[1], c.r[8]); goto L_06006278;  // 060061BE bra 0x06006278 ; mov.w r8,@r1
L_060061C2:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]);  // 060061C2 mov.w @r9,r1
    c.r[0] = c.r[1] & 0xFFFFu;  // 060061C4 extu.w r1,r0
    c.t = c.r[0] == 0x38u;  // 060061C6 cmp/eq #56,r0
    if (c.t) { SH2_POLL(c); goto L_06006174; }  // 060061C8 bt 0x06006174
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]);  // 060061CA mov.w @r9,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 060061CC extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 060061CE tst r1,r1
    { const bool k = !c.t; c.r[6] = 0x1u; if (k) { goto L_060061DC; } }  // 060061D0 bf/s 0x060061DC ; mov #1,r6
    c.r[0] = ld32(0x06006234u);  // 060061D4 mov.l 0x06006234,r0
    c.r[5] = 0x0u;  // 060061D6 mov #0,r5
L_060061D8:
    { const uint32_t x = c.r[0]; c.pr = 0x060061DCu; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060061DCu) return; }  // 060061D8 jsr @r0 ; mov #0,r4
L_060061DC:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]);  // 060061DC mov.w @r9,r1
    c.r[1] += 1;  // 060061DE add #1,r1
    st16(c.r[9], c.r[1]);  // 060061E0 mov.w r1,@r9
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]);  // 060061E2 mov.w @r9,r1
    c.r[15] = c.r[14]; goto L_0600627A;  // 060061E4 bra 0x0600627A ; mov r14,r15
L_060061E8:
    c.r[2] = c.r[8];  // 060061E8 mov r8,r2
    c.r[2] += 4;  // 060061EA add #4,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060061EC mov.b @r2,r1
    c.r[1] += 1;  // 060061EE add #1,r1
    st8(c.r[2], c.r[1]);  // 060061F0 mov.b r1,@r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060061F2 mov.b @r2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060061F4 mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060061F6 extu.b r1,r1
    c.t = c.r[1] > c.r[3];  // 060061F8 cmp/hi r3,r1
    { const bool k = !c.t; c.r[1] = 0x8u; if (k) { goto L_06006278; } }  // 060061FA bf/s 0x06006278 ; mov #8,r1
    goto L_06006276;  // 060061FE bra 0x06006276 ; nop
L_06006202:
    c.r[9] += 8;  // 06006202 add #8,r9
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]);  // 06006204 mov.w @r9,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06006206 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06006208 tst r1,r1
    { const bool k = !c.t; c.r[4] = 0x0u; if (k) { goto L_0600625E; } }  // 0600620A bf/s 0x0600625E ; mov #0,r4
    c.r[2] = ld32(0x0600623Cu);  // 0600620E mov.l 0x0600623C,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06006210 mov.b @r8,r1
    c.r[6] = 0x1u;  // 06006212 mov #1,r6
    c.r[2] = ld32(c.r[2]);  // 06006214 mov.l @r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06006216 extu.b r1,r1
    c.r[0] = c.r[2];  // 06006218 mov r2,r0
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0600621A mov.b @(r0,r1),r5
    c.r[5] -= 10; goto L_06006258;  // 0600621C bra 0x06006258 ; add #-10,r5
L_06006240:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]);  // 06006240 mov.w @r9,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06006242 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06006244 tst r1,r1
    { const bool k = !c.t; c.r[4] = 0x0u; if (k) { goto L_0600625E; } }  // 06006246 bf/s 0x0600625E ; mov #0,r4
    c.r[2] = ld32(0x06006288u);  // 0600624A mov.l 0x06006288,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0600624C mov.b @r8,r1
    c.r[6] = 0x1u;  // 0600624E mov #1,r6
    c.r[2] = ld32(c.r[2]);  // 06006250 mov.l @r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 06006252 extu.b r1,r1
    c.r[0] = c.r[2];  // 06006254 mov r2,r0
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 06006256 mov.b @(r0,r1),r5
L_06006258:
    c.r[0] = ld32(0x0600628Cu);  // 06006258 mov.l 0x0600628C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0600625Eu; c.r[5] = c.r[5] & 0xFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600625Eu) return; }  // 0600625A jsr @r0 ; extu.b r5,r5
L_0600625E:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]);  // 0600625E mov.w @r9,r1
    c.r[1] += 1;  // 06006260 add #1,r1
    st16(c.r[9], c.r[1]);  // 06006262 mov.w r1,@r9
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]);  // 06006264 mov.w @r9,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]);  // 06006266 mov.w @r9,r1
    c.r[2] = 0x3Bu;  // 06006268 mov #59,r2
    c.r[1] = c.r[1] & 0xFFFFu;  // 0600626A extu.w r1,r1
    c.t = c.r[1] > c.r[2];  // 0600626C cmp/hi r2,r1
    { const bool k = !c.t; c.r[1] = 0x0u; if (k) { goto L_06006278; } }  // 0600626E bf/s 0x06006278 ; mov #0,r1
    st16(c.r[9], c.r[1]);  // 06006272 mov.w r1,@r9
    c.r[1] = 0x20u;  // 06006274 mov #32,r1
L_06006276:
    st16(c.r[10], c.r[1]);  // 06006276 mov.w r1,@r10
L_06006278:
    c.r[15] = c.r[14];  // 06006278 mov r14,r15
L_0600627A:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0600627A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0600627C mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0600627E mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06006280 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06006282 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06006284 rts ; mov.l @r15+,r8
}

void f_06006290(SH2Context& c) {
    ran[32] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06006290 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06006292 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06006294 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06006296 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06006298 mov r15,r14
    c.r[4] = c.r[4] & 0xFFu;  // 0600629A extu.b r4,r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 0600629C tst r4,r4
    c.r[4] = ld32(0x06006304u);  // 0600629E mov.l 0x06006304,r4
    { const bool k = c.t; c.r[5] = c.r[5] & 0xFFu; if (k) { goto L_060062A6; } }  // 060062A0 bt/s 0x060062A6 ; extu.b r5,r5
    c.r[4] = ld32(0x06006308u);  // 060062A4 mov.l 0x06006308,r4
L_060062A6:
    c.r[9] = c.r[5];  // 060062A6 mov r5,r9
    c.r[9] <<= 2;  // 060062A8 shll2 r9
    c.r[9] += c.r[9];  // 060062AA add r9,r9
    c.r[3] = ld32(0x0600630Cu);  // 060062AC mov.l 0x0600630C,r3
    c.r[0] = c.r[9];  // 060062AE mov r9,r0
    c.r[1] = c.r[3];  // 060062B0 mov r3,r1
    c.r[1] += 1;  // 060062B2 add #1,r1
    c.r[8] = ld32(0x06006310u);  // 060062B4 mov.l 0x06006310,r8
    c.r[4] += c.r[6];  // 060062B6 add r6,r4
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 060062B8 mov.b @(r0,r3),r5
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060062BA mov.b @(r0,r1),r2
    c.r[5] = c.r[5] & 0xFFu;  // 060062BC extu.b r5,r5
    c.r[5] <<= 16;  // 060062BE shll16 r5
    c.r[2] = c.r[2] & 0xFFu;  // 060062C0 extu.b r2,r2
    c.r[3] += 2;  // 060062C2 add #2,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[3]);  // 060062C4 mov.b @(r0,r3),r1
    c.r[2] <<= 8;  // 060062C6 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 060062C8 extu.b r1,r1
    c.r[2] |= c.r[1];  // 060062CA or r1,r2
    c.r[5] |= c.r[2];  // 060062CC or r2,r5
    c.r[1] = 0x1u;  // 060062CE mov #1,r1
    st8(c.r[8], c.r[1]);  // 060062D0 mov.b r1,@r8
    c.r[1] = ld32(0x06006314u);  // 060062D2 mov.l 0x06006314,r1
    c.r[5] += c.r[1];  // 060062D4 add r1,r5
    c.r[1] = ld32(0x06006318u);  // 060062D6 mov.l 0x06006318,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060062DCu; c.r[6] = c.r[7]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060062DCu) return; }  // 060062D8 jsr @r1 ; mov r7,r6
    c.r[1] = ld32(0x0600631Cu);  // 060062DC mov.l 0x0600631C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060062E2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060062E2u) return; }  // 060062DE jsr @r1 ; nop
    c.r[1] = 0x0u;  // 060062E2 mov #0,r1
    st8(c.r[8], c.r[1]);  // 060062E4 mov.b r1,@r8
    c.r[1] = ld32(0x06006320u);  // 060062E6 mov.l 0x06006320,r1
    c.r[0] = c.r[9];  // 060062E8 mov r9,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 060062EA mov.b @(r0,r1),r2
    c.r[15] = c.r[14];  // 060062EC mov r14,r15
    c.r[0] = (uint32_t)(int16_t)ld16(0x06006302u);  // 060062EE mov.w 0x06006302,r0
    c.r[2] |= c.r[0];  // 060062F0 or r0,r2
    c.r[0] = c.r[9];  // 060062F2 mov r9,r0
    st8(c.r[0] + c.r[1], c.r[2]);  // 060062F4 mov.b r2,@(r0,r1)
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060062F6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060062F8 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060062FA mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060062FC mov.l @r15+,r8
    { const uint32_t x = c.pr; c.r[0] = 0x0u; c.pc = x; return; }  // 060062FE rts ; mov #0,r0
}

void f_0600632C(SH2Context& c) {
    ran[33] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0600632C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0600632E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06006330 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06006332 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06006334 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06006336 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06006338 mov r15,r14
    c.r[0] = c.r[4] & 0xFFu;  // 0600633A extu.b r4,r0
    c.r[10] = c.r[0];  // 0600633C mov r0,r10
    c.r[9] = ld32(0x0600646Cu);  // 0600633E mov.l 0x0600646C,r9
    c.r[8] = c.r[9];  // 06006340 mov r9,r8
    c.r[8] += 2;  // 06006342 add #2,r8
    c.r[0] &= 0x7Fu;  // 06006344 and #127,r0
    st8(c.r[8], c.r[0]);  // 06006346 mov.b r0,@r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 06006348 mov.b @r8,r1
    c.r[2] = 0x40u;  // 0600634A mov #64,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0600634C extu.b r1,r1
    c.t = c.r[1] > c.r[2];  // 0600634E cmp/hi r2,r1
    { const bool k = !c.t; c.r[1] = 0x40u; if (k) { goto L_06006356; } }  // 06006350 bf/s 0x06006356 ; mov #64,r1
    st8(c.r[8], c.r[1]);  // 06006354 mov.b r1,@r8
L_06006356:
    c.r[4] = ld32(0x06006470u);  // 06006356 mov.l 0x06006470,r4
    c.r[0] = ld32(0x06006474u);  // 06006358 mov.l 0x06006474,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0600635Eu; c.r[5] = 0x3u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600635Eu) return; }  // 0600635A jsr @r0 ; mov #3,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0600635E mov.b @r8,r1
    c.r[3] = c.r[0];  // 06006360 mov r0,r3
    c.r[1] = c.r[1] & 0xFFu;  // 06006362 extu.b r1,r1
    c.r[1] <<= 2;  // 06006364 shll2 r1
    c.r[1] <<= 2;  // 06006366 shll2 r1
    c.r[3] += c.r[1];  // 06006368 add r1,r3
    c.r[0] = c.r[3];  // 0600636A mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0]); c.r[0] += 1;  // 0600636C mov.b @r0+,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0600636E mov.b @r0,r1
    c.r[2] <<= 16;  // 06006370 shll16 r2
    c.r[2] <<= 8;  // 06006372 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06006374 extu.b r1,r1
    c.r[1] <<= 16;  // 06006376 shll16 r1
    c.r[2] |= c.r[1];  // 06006378 or r1,r2
    c.r[1] = c.r[3];  // 0600637A mov r3,r1
    c.r[1] += 2;  // 0600637C add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0600637E mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06006380 extu.b r1,r1
    c.r[1] <<= 8;  // 06006382 shll8 r1
    c.r[2] |= c.r[1];  // 06006384 or r1,r2
    c.r[1] = c.r[3];  // 06006386 mov r3,r1
    c.r[1] += 3;  // 06006388 add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0600638A mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0600638C extu.b r1,r1
    c.r[2] |= c.r[1];  // 0600638E or r1,r2
    st32(c.r[9] + 20, c.r[2]);  // 06006390 mov.l r2,@(20,r9)
    c.r[1] = c.r[3];  // 06006392 mov r3,r1
    c.r[1] += 4;  // 06006394 add #4,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06006396 mov.b @r1,r2
    c.r[1] = c.r[3];  // 06006398 mov r3,r1
    c.r[1] += 5;  // 0600639A add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0600639C mov.b @r1,r1
    c.r[2] <<= 16;  // 0600639E shll16 r2
    c.r[2] <<= 8;  // 060063A0 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 060063A2 extu.b r1,r1
    c.r[1] <<= 16;  // 060063A4 shll16 r1
    c.r[2] |= c.r[1];  // 060063A6 or r1,r2
    c.r[1] = c.r[3];  // 060063A8 mov r3,r1
    c.r[1] += 6;  // 060063AA add #6,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060063AC mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060063AE extu.b r1,r1
    c.r[1] <<= 8;  // 060063B0 shll8 r1
    c.r[2] |= c.r[1];  // 060063B2 or r1,r2
    c.r[1] = c.r[3];  // 060063B4 mov r3,r1
    c.r[1] += 7;  // 060063B6 add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060063B8 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060063BA extu.b r1,r1
    c.r[2] |= c.r[1];  // 060063BC or r1,r2
    st32(c.r[9] + 24, c.r[2]);  // 060063BE mov.l r2,@(24,r9)
    c.r[1] = c.r[3];  // 060063C0 mov r3,r1
    c.r[1] += 8;  // 060063C2 add #8,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060063C4 mov.b @r1,r2
    c.r[1] = c.r[3];  // 060063C6 mov r3,r1
    c.r[1] += 9;  // 060063C8 add #9,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060063CA mov.b @r1,r1
    c.r[2] <<= 16;  // 060063CC shll16 r2
    c.r[2] <<= 8;  // 060063CE shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 060063D0 extu.b r1,r1
    c.r[1] <<= 16;  // 060063D2 shll16 r1
    c.r[2] |= c.r[1];  // 060063D4 or r1,r2
    c.r[1] = c.r[3];  // 060063D6 mov r3,r1
    c.r[1] += 10;  // 060063D8 add #10,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060063DA mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060063DC extu.b r1,r1
    c.r[1] <<= 8;  // 060063DE shll8 r1
    c.r[2] |= c.r[1];  // 060063E0 or r1,r2
    c.r[1] = c.r[3];  // 060063E2 mov r3,r1
    c.r[1] += 11;  // 060063E4 add #11,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060063E6 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060063E8 extu.b r1,r1
    c.r[2] |= c.r[1];  // 060063EA or r1,r2
    st32(c.r[9] + 28, c.r[2]);  // 060063EC mov.l r2,@(28,r9)
    c.r[1] = c.r[3];  // 060063EE mov r3,r1
    c.r[1] += 12;  // 060063F0 add #12,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060063F2 mov.b @r1,r2
    c.r[1] = c.r[3];  // 060063F4 mov r3,r1
    c.r[1] += 13;  // 060063F6 add #13,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060063F8 mov.b @r1,r1
    c.r[2] <<= 16;  // 060063FA shll16 r2
    c.r[2] <<= 8;  // 060063FC shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 060063FE extu.b r1,r1
    c.r[1] <<= 16;  // 06006400 shll16 r1
    c.r[2] |= c.r[1];  // 06006402 or r1,r2
    c.r[1] = c.r[3];  // 06006404 mov r3,r1
    c.r[1] += 14;  // 06006406 add #14,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06006408 mov.b @r1,r1
    c.r[3] += 15;  // 0600640A add #15,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0600640C extu.b r1,r1
    c.r[1] <<= 8;  // 0600640E shll8 r1
    c.r[2] |= c.r[1];  // 06006410 or r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06006412 mov.b @r3,r1
    c.r[11] = (uint32_t)(int16_t)ld16(0x06006466u);  // 06006414 mov.w 0x06006466,r11
    c.r[1] = c.r[1] & 0xFFu;  // 06006416 extu.b r1,r1
    c.r[2] |= c.r[1];  // 06006418 or r1,r2
    st32(c.r[9] + 32, c.r[2]);  // 0600641A mov.l r2,@(32,r9)
    c.r[1] = ld32(c.r[9] + 20);  // 0600641C mov.l @(20,r9),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06006468u);  // 0600641E mov.w 0x06006468,r2
    c.r[2] &= c.r[1];  // 06006420 and r1,r2
    st32(c.r[9] + 36, c.r[2]);  // 06006422 mov.l r2,@(36,r9)
    c.r[5] = ld32(c.r[9] + 20);  // 06006424 mov.l @(20,r9),r5
    c.r[10] &= c.r[11];  // 06006426 and r11,r10
    c.r[2] = ld32(c.r[9] + 32);  // 06006428 mov.l @(32,r9),r2
    c.t = (c.r[10] & c.r[10]) == 0;  // 0600642A tst r10,r10
    c.r[1] = ld32(c.r[9] + 20);  // 0600642C mov.l @(20,r9),r1
    c.r[6] = c.r[2];  // 0600642E mov r2,r6
    { const bool k = c.t; c.r[6] -= c.r[1]; if (k) { goto L_0600644C; } }  // 06006430 bt/s 0x0600644C ; sub r1,r6
    c.r[6] >>= 8;  // 06006434 shlr8 r6
    c.t = c.r[6] & 1; c.r[6] >>= 1;  // 06006436 shlr r6
    c.r[6] >>= 2;  // 06006438 shlr2 r6
    c.r[6] += 2;  // 0600643A add #2,r6
    c.r[7] = c.r[6] & 0xFFFFu;  // 0600643C extu.w r6,r7
    c.r[6] = ld32(0x06006478u);  // 0600643E mov.l 0x06006478,r6
    c.r[5] >>= 8;  // 06006440 shlr8 r5
    c.t = c.r[5] & 1; c.r[5] >>= 1;  // 06006442 shlr r5
    c.r[4] = ld32(0x0600647Cu);  // 06006444 mov.l 0x0600647C,r4
    c.r[0] = ld32(0x06006480u);  // 06006446 mov.l 0x06006480,r0
    c.r[5] >>= 2; goto L_06006452;  // 06006448 bra 0x06006452 ; shlr2 r5
L_0600644C:
    c.r[7] = ld32(0x06006478u);  // 0600644C mov.l 0x06006478,r7
    c.r[0] = ld32(0x06006484u);  // 0600644E mov.l 0x06006484,r0
    c.r[4] = 0x6u;  // 06006450 mov #6,r4
L_06006452:
    { const uint32_t x = c.r[0]; c.pr = 0x06006456u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06006456u) return; }  // 06006452 jsr @r0 ; nop
    c.r[15] = c.r[14];  // 06006456 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06006458 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0600645A mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0600645C mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0600645E mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06006460 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06006462 rts ; mov.l @r15+,r8
}

void f_06006488(SH2Context& c) {
    ran[34] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06006488 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0600648A mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0600648C sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0600648E mov r15,r14
    c.r[4] = c.r[4] & 0xFFu;  // 06006490 extu.b r4,r4
    c.r[8] = ld32(0x06006554u);  // 06006492 mov.l 0x06006554,r8
    st8(c.r[8], c.r[4]);  // 06006494 mov.b r4,@r8
    c.r[4] = ld32(0x06006558u);  // 06006496 mov.l 0x06006558,r4
    c.r[0] = ld32(0x0600655Cu);  // 06006498 mov.l 0x0600655C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0600649Eu; c.r[5] = 0x4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600649Eu) return; }  // 0600649A jsr @r0 ; mov #4,r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[8]);  // 0600649E mov.b @r8,r1
    c.r[3] = c.r[0];  // 060064A0 mov r0,r3
    c.r[1] = c.r[1] & 0xFFu;  // 060064A2 extu.b r1,r1
    c.r[2] = c.r[1];  // 060064A4 mov r1,r2
    c.r[2] += c.r[2];  // 060064A6 add r2,r2
    c.r[2] += c.r[1];  // 060064A8 add r1,r2
    c.r[2] <<= 2;  // 060064AA shll2 r2
    c.r[3] += c.r[2];  // 060064AC add r2,r3
    c.r[0] = c.r[3];  // 060064AE mov r3,r0
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0]); c.r[0] += 1;  // 060064B0 mov.b @r0+,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 060064B2 mov.b @r0,r1
    c.r[2] <<= 16;  // 060064B4 shll16 r2
    c.r[2] <<= 8;  // 060064B6 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 060064B8 extu.b r1,r1
    c.r[1] <<= 16;  // 060064BA shll16 r1
    c.r[2] |= c.r[1];  // 060064BC or r1,r2
    c.r[1] = c.r[3];  // 060064BE mov r3,r1
    c.r[1] += 2;  // 060064C0 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060064C2 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060064C4 extu.b r1,r1
    c.r[1] <<= 8;  // 060064C6 shll8 r1
    c.r[2] |= c.r[1];  // 060064C8 or r1,r2
    c.r[1] = c.r[3];  // 060064CA mov r3,r1
    c.r[1] += 3;  // 060064CC add #3,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060064CE mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060064D0 extu.b r1,r1
    c.r[2] |= c.r[1];  // 060064D2 or r1,r2
    st32(c.r[8] + 8, c.r[2]);  // 060064D4 mov.l r2,@(8,r8)
    c.r[1] = c.r[3];  // 060064D6 mov r3,r1
    c.r[1] += 4;  // 060064D8 add #4,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060064DA mov.b @r1,r2
    c.r[1] = c.r[3];  // 060064DC mov r3,r1
    c.r[1] += 5;  // 060064DE add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060064E0 mov.b @r1,r1
    c.r[2] <<= 16;  // 060064E2 shll16 r2
    c.r[2] <<= 8;  // 060064E4 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 060064E6 extu.b r1,r1
    c.r[1] <<= 16;  // 060064E8 shll16 r1
    c.r[2] |= c.r[1];  // 060064EA or r1,r2
    c.r[1] = c.r[3];  // 060064EC mov r3,r1
    c.r[1] += 6;  // 060064EE add #6,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060064F0 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060064F2 extu.b r1,r1
    c.r[1] <<= 8;  // 060064F4 shll8 r1
    c.r[2] |= c.r[1];  // 060064F6 or r1,r2
    c.r[1] = c.r[3];  // 060064F8 mov r3,r1
    c.r[1] += 7;  // 060064FA add #7,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060064FC mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060064FE extu.b r1,r1
    c.r[2] |= c.r[1];  // 06006500 or r1,r2
    st32(c.r[8] + 12, c.r[2]);  // 06006502 mov.l r2,@(12,r8)
    c.r[1] = c.r[3];  // 06006504 mov r3,r1
    c.r[1] += 8;  // 06006506 add #8,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06006508 mov.b @r1,r2
    c.r[1] = c.r[3];  // 0600650A mov r3,r1
    c.r[1] += 9;  // 0600650C add #9,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0600650E mov.b @r1,r1
    c.r[2] <<= 16;  // 06006510 shll16 r2
    c.r[2] <<= 8;  // 06006512 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 06006514 extu.b r1,r1
    c.r[1] <<= 16;  // 06006516 shll16 r1
    c.r[2] |= c.r[1];  // 06006518 or r1,r2
    c.r[1] = c.r[3];  // 0600651A mov r3,r1
    c.r[1] += 10;  // 0600651C add #10,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0600651E mov.b @r1,r1
    c.r[3] += 11;  // 06006520 add #11,r3
    c.r[1] = c.r[1] & 0xFFu;  // 06006522 extu.b r1,r1
    c.r[1] <<= 8;  // 06006524 shll8 r1
    c.r[2] |= c.r[1];  // 06006526 or r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 06006528 mov.b @r3,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0600652A extu.b r1,r1
    c.r[2] |= c.r[1];  // 0600652C or r1,r2
    st32(c.r[8] + 16, c.r[2]);  // 0600652E mov.l r2,@(16,r8)
    c.r[1] = ld32(c.r[8] + 8);  // 06006530 mov.l @(8,r8),r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06006552u);  // 06006532 mov.w 0x06006552,r2
    c.r[2] &= c.r[1];  // 06006534 and r1,r2
    st32(c.r[8] + 20, c.r[2]);  // 06006536 mov.l r2,@(20,r8)
    c.r[5] = ld32(c.r[8] + 8);  // 06006538 mov.l @(8,r8),r5
    c.r[7] = ld32(0x06006560u);  // 0600653A mov.l 0x06006560,r7
    c.r[6] = ld32(c.r[8] + 16);  // 0600653C mov.l @(16,r8),r6
    c.r[4] = 0x7u;  // 0600653E mov #7,r4
    c.r[1] = ld32(c.r[8] + 8);  // 06006540 mov.l @(8,r8),r1
    c.r[0] = ld32(0x06006564u);  // 06006542 mov.l 0x06006564,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06006548u; c.r[6] -= c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06006548u) return; }  // 06006544 jsr @r0 ; sub r1,r6
    c.r[15] = c.r[14];  // 06006548 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0600654A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0600654C mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0600654E rts ; mov.l @r15+,r8
}

void f_06006568(SH2Context& c) {
    ran[35] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06006568 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0600656A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0600656C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0600656E sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06006570 mov r15,r14
    c.r[8] = c.r[4];  // 06006572 mov r4,r8
    c.r[9] = c.r[5] & 0xFFFFu;  // 06006574 extu.w r5,r9
    c.r[5] = c.r[9];  // 06006576 mov r9,r5
    c.r[5] >>= 2;  // 06006578 shlr2 r5
    c.r[5] >>= 2;  // 0600657A shlr2 r5
    c.t = c.r[5] & 1; c.r[5] >>= 1;  // 0600657C shlr r5
    c.r[5] >>= 2;  // 0600657E shlr2 r5
    c.r[1] = ld32(0x060065C0u);  // 06006580 mov.l 0x060065C0,r1
    c.r[6] = 0x2u;  // 06006582 mov #2,r6
    c.r[0] = ld32(0x060065C4u);  // 06006584 mov.l 0x060065C4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0600658Au; c.r[4] = ld32(c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600658Au) return; }  // 06006586 jsr @r0 ; mov.l @r1,r4
    c.r[2] = 0x7Fu;  // 0600658A mov #127,r2
    c.r[2] &= c.r[9];  // 0600658C and r9,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0600658E mov.b @(r0,r2),r1
    c.r[8] = (uint32_t)(int32_t)(int16_t)c.r[8];  // 06006590 exts.w r8,r8
    c.r[1] = c.r[1] & 0xFFu;  // 06006592 extu.b r1,r1
    c.r[8] += c.r[1];  // 06006594 add r1,r8
    c.r[8] = (uint32_t)(int32_t)(int16_t)c.r[8];  // 06006596 exts.w r8,r8
    c.t = (int32_t)c.r[8] >= 0;  // 06006598 cmp/pz r8
    { const bool k = c.t; c.r[3] = c.r[0]; if (k) { goto L_060065A0; } }  // 0600659A bt/s 0x060065A0 ; mov r0,r3
    c.r[8] = (uint32_t)(int16_t)ld16(0x060065BCu);  // 0600659E mov.w 0x060065BC,r8
L_060065A0:
    c.r[1] = (uint32_t)(int16_t)ld16(0x060065BCu);  // 060065A0 mov.w 0x060065BC,r1
    c.t = (int32_t)c.r[8] > (int32_t)c.r[1];  // 060065A2 cmp/gt r1,r8
    if (!c.t) { goto L_060065A8; }  // 060065A4 bf 0x060065A8
    c.r[8] = 0x0u;  // 060065A6 mov #0,r8
L_060065A8:
    c.r[0] = c.r[3];  // 060065A8 mov r3,r0
    st8(c.r[0] + c.r[2], c.r[8]);  // 060065AA mov.b r8,@(r0,r2)
    c.r[15] = c.r[14];  // 060065AC mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060065AE lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060065B0 mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060065B2 mov.l @r15+,r9
    c.r[1] = c.r[8] & 0xFFu;  // 060065B4 extu.b r8,r1
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 060065B6 mov.l @r15+,r8
    { const uint32_t x = c.pr; c.r[0] = c.r[1]; c.pc = x; return; }  // 060065B8 rts ; mov r1,r0
}

void f_060065C8(SH2Context& c) {
    ran[36] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 060065C8 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 060065CA mov r15,r14
    c.r[4] = (uint32_t)(int32_t)(int8_t)c.r[4];  // 060065CC exts.b r4,r4
    c.r[5] = c.r[5] & 0xFFu;  // 060065CE extu.b r5,r5
    c.r[6] = c.r[6] & 0xFFu;  // 060065D0 extu.b r6,r6
    c.r[3] = c.r[6];  // 060065D2 mov r6,r3
    c.t = (c.r[5] & c.r[5]) == 0;  // 060065D4 tst r5,r5
    { const bool k = c.t; c.r[0] = 0x0u; if (k) { goto L_060065E8; } }  // 060065D6 bt/s 0x060065E8 ; mov #0,r0
    c.r[1] = ld32(0x06006640u);  // 060065DA mov.l 0x06006640,r1
    c.r[5] <<= 2;  // 060065DC shll2 r5
    c.r[5] <<= 2;  // 060065DE shll2 r5
    c.r[2] = ld32(c.r[1]);  // 060065E0 mov.l @r1,r2
    c.r[5] += c.r[6];  // 060065E2 add r6,r5
    c.r[2] += c.r[5]; goto L_060065EE;  // 060065E4 bra 0x060065EE ; add r5,r2
L_060065E8:
    c.r[1] = ld32(0x06006644u);  // 060065E8 mov.l 0x06006644,r1
    c.r[2] = ld32(c.r[1]);  // 060065EA mov.l @r1,r2
    c.r[2] += c.r[3];  // 060065EC add r3,r2
L_060065EE:
    c.t = (c.r[4] & c.r[4]) == 0;  // 060065EE tst r4,r4
    if (!c.t) { goto L_060065F8; }  // 060065F0 bf 0x060065F8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060065F2 mov.b @r2,r1
    c.r[0] = c.r[1] & 0xFFu; goto L_06006634;  // 060065F4 bra 0x06006634 ; extu.b r1,r0
L_060065F8:
    c.t = (int32_t)c.r[4] > 0;  // 060065F8 cmp/pl r4
    if (!c.t) { goto L_06006614; }  // 060065FA bf 0x06006614
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060065FC mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 060065FE extu.b r1,r1
    c.r[0] = c.r[1];  // 06006600 mov r1,r0
    c.r[0] += c.r[4];  // 06006602 add r4,r0
    c.r[1] = (uint32_t)(int16_t)ld16(0x0600663Au);  // 06006604 mov.w 0x0600663A,r1
    c.t = (int32_t)c.r[0] > (int32_t)c.r[1];  // 06006606 cmp/gt r1,r0
    { const bool k = c.t; c.r[1] = c.r[0]; if (k) { goto L_06006612; } }  // 06006608 bt/s 0x06006612 ; mov r0,r1
    c.r[1] += 1;  // 0600660C add #1,r1
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[1]; goto L_06006614;  // 0600660E bra 0x06006614 ; exts.w r1,r0
L_06006612:
    c.r[0] = 0x0u;  // 06006612 mov #0,r0
L_06006614:
    c.t = (int32_t)c.r[4] >= 0;  // 06006614 cmp/pz r4
    if (c.t) { goto L_06006630; }  // 06006616 bt 0x06006630
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 06006618 mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0600661A extu.b r1,r1
    c.r[0] = c.r[1];  // 0600661C mov r1,r0
    c.r[0] += c.r[4];  // 0600661E add r4,r0
    c.r[1] = 0x1u;  // 06006620 mov #1,r1
    c.t = (int32_t)c.r[0] > (int32_t)c.r[1];  // 06006622 cmp/gt r1,r0
    { const bool k = !c.t; c.r[1] = c.r[0]; if (k) { goto L_0600662E; } }  // 06006624 bf/s 0x0600662E ; mov r0,r1
    c.r[1] -= 1;  // 06006628 add #-1,r1
    c.r[0] = (uint32_t)(int32_t)(int16_t)c.r[1]; goto L_06006630;  // 0600662A bra 0x06006630 ; exts.w r1,r0
L_0600662E:
    c.r[0] = (uint32_t)(int16_t)ld16(0x0600663Cu);  // 0600662E mov.w 0x0600663C,r0
L_06006630:
    st8(c.r[2], c.r[0]);  // 06006630 mov.b r0,@r2
    c.r[0] = c.r[0] & 0xFFu;  // 06006632 extu.b r0,r0
L_06006634:
    c.r[15] = c.r[14];  // 06006634 mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06006636 rts ; mov.l @r15+,r14
}

void f_06006648(SH2Context& c) {
    ran[37] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06006648 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0600664A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0600664C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0600664E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06006650 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06006652 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06006654 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06006656 sts.l pr,@-r15
    c.r[0] = c.r[4] & 0xFFFFu;  // 06006658 extu.w r4,r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0600665A tst r0,r0
    { const bool k = c.t; c.r[14] = c.r[15]; if (k) { goto L_0600666A; } }  // 0600665C bt/s 0x0600666A ; mov r15,r14
    c.t = c.r[0] == 0x1u;  // 06006660 cmp/eq #1,r0
    if (c.t) { goto L_060066FC; }  // 06006662 bt 0x060066FC
    c.r[15] = c.r[14];  // 06006664 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; } goto L_060067EE;  // 06006666 bra 0x060067EE ; lds.l @r15+,pr
L_0600666A:
    c.r[9] = ld32(0x06006804u);  // 0600666A mov.l 0x06006804,r9
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0600666C mov.b @r9,r0
    c.r[1] = ld32(0x06006808u);  // 0600666E mov.l 0x06006808,r1
    c.r[0] &= 0x7Fu;  // 06006670 and #127,r0
    st8(c.r[9], c.r[0]);  // 06006672 mov.b r0,@r9
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06006674 mov.b @r1,r0
    c.r[0] &= 0x7Fu;  // 06006676 and #127,r0
    st8(c.r[1], c.r[0]);  // 06006678 mov.b r0,@r1
    c.r[1] = ld32(0x0600680Cu);  // 0600667A mov.l 0x0600680C,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0600667C mov.b @r1,r0
    c.r[0] &= 0x7Fu;  // 0600667E and #127,r0
    st8(c.r[1], c.r[0]);  // 06006680 mov.b r0,@r1
    c.r[1] = ld32(0x06006810u);  // 06006682 mov.l 0x06006810,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06006684 mov.b @r1,r0
    c.r[0] &= 0x7Fu;  // 06006686 and #127,r0
    st8(c.r[1], c.r[0]);  // 06006688 mov.b r0,@r1
    c.r[1] = ld32(0x06006814u);  // 0600668A mov.l 0x06006814,r1
    c.r[12] = ld32(c.r[1] + 36);  // 0600668C mov.l @(36,r1),r12
    c.r[2] = ld32(c.r[1] + 24);  // 0600668E mov.l @(24,r1),r2
    c.r[1] = ld32(c.r[1] + 20);  // 06006690 mov.l @(20,r1),r1
    c.r[13] = c.r[2];  // 06006692 mov r2,r13
    c.r[13] -= c.r[1];  // 06006694 sub r1,r13
    c.r[1] = 0x3u;  // 06006696 mov #3,r1
    c.t = c.r[13] > c.r[1];  // 06006698 cmp/hi r1,r13
    { const bool k = !c.t; c.r[4] = 0xFFFFFFFCu; if (k) { goto L_060066AE; } }  // 0600669A bf/s 0x060066AE ; mov #-4,r4
    c.r[4] &= c.r[13];  // 0600669E and r13,r4
    c.r[5] = ld32(0x06006818u);  // 060066A0 mov.l 0x06006818,r5
    c.r[5] -= c.r[4];  // 060066A2 sub r4,r5
    c.r[1] = ld32(0x0600681Cu);  // 060066A4 mov.l 0x0600681C,r1
    c.r[4] += c.r[1];  // 060066A6 add r1,r4
    c.r[1] = ld32(0x06006820u);  // 060066A8 mov.l 0x06006820,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060066AEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060066AEu) return; }  // 060066AA jsr @r1 ; nop
L_060066AE:
    c.r[7] = ld32(0x06006824u);  // 060066AE mov.l 0x06006824,r7
    c.r[3] = ld32(0x06006828u);  // 060066B0 mov.l 0x06006828,r3
    c.r[1] = c.r[3];  // 060066B2 mov r3,r1
    c.r[3] += 2;  // 060066B4 add #2,r3
    c.r[8] = ld32(0x0600682Cu);  // 060066B6 mov.l 0x0600682C,r8
    c.r[12] += c.r[7];  // 060066B8 add r7,r12
    c.r[6] = c.r[13];  // 060066BA mov r13,r6
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 060066BC mov.b @r1+,r5
    c.r[5] = c.r[5] & 0xFFu;  // 060066BE extu.b r5,r5
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060066C0 mov.b @r1,r2
    c.r[5] <<= 16;  // 060066C2 shll16 r5
    c.r[2] = c.r[2] & 0xFFu;  // 060066C4 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 060066C6 mov.b @r3,r1
    c.r[2] <<= 8;  // 060066C8 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 060066CA extu.b r1,r1
    c.r[2] |= c.r[1];  // 060066CC or r1,r2
    c.r[5] |= c.r[2];  // 060066CE or r2,r5
    c.r[1] = 0x1u;  // 060066D0 mov #1,r1
    st8(c.r[8], c.r[1]);  // 060066D2 mov.b r1,@r8
    c.r[1] = ld32(0x06006830u);  // 060066D4 mov.l 0x06006830,r1
    c.r[5] += c.r[1];  // 060066D6 add r1,r5
    c.r[1] = ld32(0x06006834u);  // 060066D8 mov.l 0x06006834,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060066DEu; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060066DEu) return; }  // 060066DA jsr @r1 ; mov r12,r4
    c.r[1] = ld32(0x06006838u);  // 060066DE mov.l 0x06006838,r1
    { const uint32_t x = c.r[1]; c.pr = 0x060066E4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060066E4u) return; }  // 060066E0 jsr @r1 ; nop
    c.r[1] = 0x0u;  // 060066E4 mov #0,r1
    st8(c.r[8], c.r[1]);  // 060066E6 mov.b r1,@r8
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[9]);  // 060066E8 mov.b @r9,r0
    c.r[0] |= 0x80u;  // 060066EA or #128,r0
    st8(c.r[9], c.r[0]);  // 060066EC mov.b r0,@r9
    c.r[0] = ld32(0x0600683Cu);  // 060066EE mov.l 0x0600683C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060066F4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060066F4u) return; }  // 060066F0 jsr @r0 ; nop
    c.r[2] = ld32(0x06006840u);  // 060066F4 mov.l 0x06006840,r2
    c.r[1] = 0x0u;  // 060066F6 mov #0,r1
    st16(c.r[2], c.r[1]); goto L_060067EA;  // 060066F8 bra 0x060067EA ; mov.w r1,@r2
L_060066FC:
    c.r[8] = ld32(0x06006814u);  // 060066FC mov.l 0x06006814,r8
    c.r[9] = ld32(0x06006844u);  // 060066FE mov.l 0x06006844,r9
    c.r[12] = ld32(c.r[8] + 36);  // 06006700 mov.l @(36,r8),r12
    c.r[10] = ld32(0x0600682Cu);  // 06006702 mov.l 0x0600682C,r10
    c.r[2] = ld32(c.r[8] + 24);  // 06006704 mov.l @(24,r8),r2
    c.r[7] = 0x1u;  // 06006706 mov #1,r7
    c.r[1] = ld32(c.r[8] + 20);  // 06006708 mov.l @(20,r8),r1
    c.r[4] = ld32(0x06006824u);  // 0600670A mov.l 0x06006824,r4
    c.r[2] -= c.r[1];  // 0600670C sub r1,r2
    c.r[12] += c.r[2];  // 0600670E add r2,r12
    c.r[2] = ld32(c.r[8] + 28);  // 06006710 mov.l @(28,r8),r2
    c.r[4] += c.r[12];  // 06006712 add r12,r4
    c.r[1] = ld32(c.r[8] + 24);  // 06006714 mov.l @(24,r8),r1
    c.r[13] = c.r[2];  // 06006716 mov r2,r13
    c.r[13] -= c.r[1];  // 06006718 sub r1,r13
    c.r[1] = c.r[9];  // 0600671A mov r9,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0600671C mov.b @r1+,r5
    c.r[5] = c.r[5] & 0xFFu;  // 0600671E extu.b r5,r5
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06006720 mov.b @r1,r2
    c.r[5] <<= 16;  // 06006722 shll16 r5
    c.r[2] = c.r[2] & 0xFFu;  // 06006724 extu.b r2,r2
    c.r[1] = c.r[9];  // 06006726 mov r9,r1
    c.r[1] += 2;  // 06006728 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0600672A mov.b @r1,r1
    c.r[2] <<= 8;  // 0600672C shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0600672E extu.b r1,r1
    c.r[2] |= c.r[1];  // 06006730 or r1,r2
    c.r[5] |= c.r[2];  // 06006732 or r2,r5
    st8(c.r[10], c.r[7]);  // 06006734 mov.b r7,@r10
    c.r[7] = ld32(0x06006830u);  // 06006736 mov.l 0x06006830,r7
    c.r[5] += c.r[7];  // 06006738 add r7,r5
    c.r[7] = ld32(0x06006834u);  // 0600673A mov.l 0x06006834,r7
    { const uint32_t x = c.r[7]; c.pr = 0x06006740u; c.r[6] = c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06006740u) return; }  // 0600673C jsr @r7 ; mov r13,r6
    c.r[7] = ld32(0x06006838u);  // 06006740 mov.l 0x06006838,r7
    { const uint32_t x = c.r[7]; c.pr = 0x06006746u; c.r[11] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06006746u) return; }  // 06006742 jsr @r7 ; mov #0,r11
    st8(c.r[10], c.r[11]);  // 06006746 mov.b r11,@r10
    c.r[1] = ld32(0x06006808u);  // 06006748 mov.l 0x06006808,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0600674A mov.b @r1,r0
    c.r[0] |= 0x80u;  // 0600674C or #128,r0
    st8(c.r[1], c.r[0]);  // 0600674E mov.b r0,@r1
    c.r[1] = ld32(0x0600680Cu);  // 06006750 mov.l 0x0600680C,r1
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06006752 mov.b @r1,r0
    c.r[0] |= 0x80u;  // 06006754 or #128,r0
    st8(c.r[1], c.r[0]);  // 06006756 mov.b r0,@r1
    c.r[6] = ld32(c.r[8] + 32);  // 06006758 mov.l @(32,r8),r6
    c.r[1] = ld32(c.r[8] + 28);  // 0600675A mov.l @(28,r8),r1
    c.r[12] += c.r[13];  // 0600675C add r13,r12
    c.r[6] -= c.r[1];  // 0600675E sub r1,r6
    c.r[1] = c.r[9];  // 06006760 mov r9,r1
    c.r[1] += 24;  // 06006762 add #24,r1
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06006764 mov.b @r1,r5
    c.r[7] = 0x1u;  // 06006766 mov #1,r7
    c.r[5] = c.r[5] & 0xFFu;  // 06006768 extu.b r5,r5
    c.r[5] <<= 16;  // 0600676A shll16 r5
    c.r[1] = c.r[9];  // 0600676C mov r9,r1
    c.r[1] += 25;  // 0600676E add #25,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06006770 mov.b @r1,r2
    c.r[9] += 26;  // 06006772 add #26,r9
    c.r[2] = c.r[2] & 0xFFu;  // 06006774 extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 06006776 mov.b @r9,r1
    c.r[2] <<= 8;  // 06006778 shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0600677A extu.b r1,r1
    c.r[2] |= c.r[1];  // 0600677C or r1,r2
    c.r[5] |= c.r[2];  // 0600677E or r2,r5
    st8(c.r[10], c.r[7]);  // 06006780 mov.b r7,@r10
    c.r[7] = ld32(0x06006830u);  // 06006782 mov.l 0x06006830,r7
    c.r[5] += c.r[7];  // 06006784 add r7,r5
    c.r[7] = ld32(0x06006824u);  // 06006786 mov.l 0x06006824,r7
    c.r[12] += c.r[7];  // 06006788 add r7,r12
    c.r[7] = ld32(0x06006834u);  // 0600678A mov.l 0x06006834,r7
    { const uint32_t x = c.r[7]; c.pr = 0x06006790u; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06006790u) return; }  // 0600678C jsr @r7 ; mov r12,r4
    c.r[7] = ld32(0x06006838u);  // 06006790 mov.l 0x06006838,r7
    { const uint32_t x = c.r[7]; c.pr = 0x06006796u; c.r[9] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06006796u) return; }  // 06006792 jsr @r7 ; mov #0,r9
    st8(c.r[10], c.r[11]);  // 06006796 mov.b r11,@r10
    c.r[1] = ld32(0x06006810u);  // 06006798 mov.l 0x06006810,r1
    c.r[2] = ld32(0x06006840u);  // 0600679A mov.l 0x06006840,r2
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0600679C mov.b @r1,r0
    c.r[4] = 0x0u;  // 0600679E mov #0,r4
    c.r[0] |= 0x80u;  // 060067A0 or #128,r0
    st8(c.r[1], c.r[0]);  // 060067A2 mov.b r0,@r1
    c.r[1] = (uint32_t)(int16_t)ld16(0x060067FEu);  // 060067A4 mov.w 0x060067FE,r1
    c.r[0] = ld32(0x06006848u);  // 060067A6 mov.l 0x06006848,r0
    { const uint32_t x = c.r[0]; c.pr = 0x060067ACu; st16(c.r[2], c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060067ACu) return; }  // 060067A8 jsr @r0 ; mov.w r1,@r2
    c.r[11] = ld32(0x0600684Cu);  // 060067AC mov.l 0x0600684C,r11
    c.r[10] = ld32(0x06006850u);  // 060067AE mov.l 0x06006850,r10
    c.r[8] = c.r[9] & 0xFFu;  // 060067B0 extu.b r9,r8
L_060067B2:
    c.r[5] = 0x0u;  // 060067B2 mov #0,r5
    { const uint32_t x = c.r[11]; c.pr = 0x060067B8u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060067B8u) return; }  // 060067B4 jsr @r11 ; mov r8,r4
    c.r[6] = 0x0u;  // 060067B8 mov #0,r6
    c.r[5] = 0x7u;  // 060067BA mov #7,r5
    { const uint32_t x = c.r[10]; c.pr = 0x060067C0u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x060067C0u) return; }  // 060067BC jsr @r10 ; mov r8,r4
    c.r[9] += 1;  // 060067C0 add #1,r9
    c.r[1] = 0x4u;  // 060067C2 mov #4,r1
    c.t = (int32_t)c.r[9] > (int32_t)c.r[1];  // 060067C4 cmp/gt r1,r9
    { const bool k = !c.t; c.r[8] = c.r[9] & 0xFFu; if (k) { SH2_POLL(c); goto L_060067B2; } }  // 060067C6 bf/s 0x060067B2 ; extu.b r9,r8
    c.r[1] = ld32(0x06006814u);  // 060067CA mov.l 0x06006814,r1
    c.r[3] = c.r[1];  // 060067CC mov r1,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]);  // 060067CE mov.b @r1,r2
    c.r[3] += 1;  // 060067D0 add #1,r3
    st8(c.r[3], c.r[2]);  // 060067D2 mov.b r2,@r3
    c.r[2] = c.r[1];  // 060067D4 mov r1,r2
    c.r[2] += 2;  // 060067D6 add #2,r2
    c.r[3] = c.r[1];  // 060067D8 mov r1,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[2]);  // 060067DA mov.b @r2,r2
    c.r[3] += 4;  // 060067DC add #4,r3
    st8(c.r[1], c.r[2]);  // 060067DE mov.b r2,@r1
    c.r[2] = 0x0u;  // 060067E0 mov #0,r2
    st8(c.r[3], c.r[2]);  // 060067E2 mov.b r2,@r3
    c.r[1] += 14;  // 060067E4 add #14,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06006800u);  // 060067E6 mov.w 0x06006800,r2
    st16(c.r[1], c.r[2]);  // 060067E8 mov.w r2,@r1
L_060067EA:
    c.r[15] = c.r[14];  // 060067EA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 060067EC lds.l @r15+,pr
L_060067EE:
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 060067EE mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 060067F0 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 060067F2 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 060067F4 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 060067F6 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 060067F8 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060067FA rts ; mov.l @r15+,r8
}

void f_06006854(SH2Context& c) {
    ran[38] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06006854 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06006856 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06006858 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0600685A mov r15,r14
    c.r[8] = c.r[4];  // 0600685C mov r4,r8
    c.r[8] = c.r[8] & 0xFFu;  // 0600685E extu.b r8,r8
    c.r[1] = ld32(0x06006888u);  // 06006860 mov.l 0x06006888,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06006866u; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06006866u) return; }  // 06006862 jsr @r1 ; mov r8,r4
    c.r[0] = ld32(0x0600688Cu);  // 06006866 mov.l 0x0600688C,r0
    c.r[5] = 0x1u;  // 06006868 mov #1,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0600686Eu; c.r[4] = 0xFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600686Eu) return; }  // 0600686A jsr @r0 ; mov #15,r4
    c.r[1] = ld32(0x06006890u);  // 0600686E mov.l 0x06006890,r1
    c.r[1] = ld32(c.r[1]);  // 06006870 mov.l @r1,r1
    c.t = (c.r[8] & c.r[8]) == 0;  // 06006872 tst r8,r8
    c.r[2] = 0x0u;  // 06006874 mov #0,r2
    { const bool k = !c.t; c.r[1] += 3; if (k) { goto L_0600687C; } }  // 06006876 bf/s 0x0600687C ; add #3,r1
    c.r[2] = 0xFFFFFF80u;  // 0600687A mov #-128,r2
L_0600687C:
    st8(c.r[1], c.r[2]);  // 0600687C mov.b r2,@r1
    c.r[15] = c.r[14];  // 0600687E mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06006880 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06006882 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06006884 rts ; mov.l @r15+,r8
}

void f_06006894(SH2Context& c) {
    ran[39] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06006894 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06006896 mov r15,r14
    c.r[15] += 122;  // 06006898 add #122,r15
    c.r[10] += 102;  // 0600689A add #102,r10
    c.r[3] += 124;  // 0600689C add #124,r3
    c.r[13] += 112;  // 0600689E add #112,r13
    c.r[0] += 118;  // 060068A0 add #118,r0
    c.r[10] -= 128;  // 060068A2 add #-128,r10
    st8(c.r[6] + 10, c.r[0]);  // 060068A4 mov.b r0,@(10,r6)
    c.r[6] += 112;  // 060068A6 add #112,r6
    c.r[10] += 124;  // 060068A8 add #124,r10
    c.r[6] += 124;  // 060068AA add #124,r6
    c.r[13] += 125;  // 060068AC add #125,r13
    c.r[0] += 125;  // 060068AE add #125,r0
    c.r[13] += 122;  // 060068B0 add #122,r13
    c.r[9] += 120;  // 060068B2 add #120,r9
    c.r[14] -= 128;  // 060068B4 add #-128,r14
    c.r[10] += 118;  // 060068B6 add #118,r10
    c.r[8] += 118;  // 060068B8 add #118,r8
    c.r[15] += 118;  // 060068BA add #118,r15
    c.r[10] += 124;  // 060068BC add #124,r10
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[8] + 10);  // 060068BE mov.b @(10,r8),r0
    c.r[3] += 115;  // 060068C0 add #115,r3
    c.r[13] -= 127;  // 060068C2 add #-127,r13
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[7] + 13);  // 060068C4 mov.b @(13,r7),r0
    c.r[10] += 118;  // 060068C6 add #118,r10
    c.r[6] += 118;  // 060068C8 add #118,r6
    c.r[6] -= 128;  // 060068CA add #-128,r6
    c.r[13] -= 125;  // 060068CC add #-125,r13
    c.r[6] += 122;  // 060068CE add #122,r6
    c.r[6] -= 128;  // 060068D0 add #-128,r6
    c.r[10] += 122;  // 060068D2 add #122,r10
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[6] + 6);  // 060068D4 mov.b @(6,r6),r0
    c.r[6] += 115;  // 060068D6 add #115,r6
    st8(c.r[8], c.r[0]);  // 060068D8 mov.b r0,@(0,r8)
    st8(c.r[8], c.r[0]);  // 060068DA mov.b r0,@(0,r8)
    st8(c.r[8], c.r[0]);  // 060068DC mov.b r0,@(0,r8)
    st8(c.r[8], c.r[0]);  // 060068DE mov.b r0,@(0,r8)
    st8(c.r[8], c.r[0]);  // 060068E0 mov.b r0,@(0,r8)
    st8(c.r[8], c.r[0]);  // 060068E2 mov.b r0,@(0,r8)
    st8(c.r[8], c.r[0]);  // 060068E4 mov.b r0,@(0,r8)
    st8(c.r[8], c.r[0]);  // 060068E6 mov.b r0,@(0,r8)
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060068E8 rts ; mov.l @r15+,r14
}

void f_06006898(SH2Context& c) {
    ran[40] = 1;
    c.r[15] += 122;  // 06006898 add #122,r15
    c.r[10] += 102;  // 0600689A add #102,r10
    c.r[3] += 124;  // 0600689C add #124,r3
    c.r[13] += 112;  // 0600689E add #112,r13
    c.r[0] += 118;  // 060068A0 add #118,r0
    c.r[10] -= 128;  // 060068A2 add #-128,r10
    st8(c.r[6] + 10, c.r[0]);  // 060068A4 mov.b r0,@(10,r6)
    c.r[6] += 112;  // 060068A6 add #112,r6
    c.r[10] += 124;  // 060068A8 add #124,r10
    c.r[6] += 124;  // 060068AA add #124,r6
    c.r[13] += 125;  // 060068AC add #125,r13
    c.r[0] += 125;  // 060068AE add #125,r0
    c.r[13] += 122;  // 060068B0 add #122,r13
    c.r[9] += 120;  // 060068B2 add #120,r9
    c.r[14] -= 128;  // 060068B4 add #-128,r14
    c.r[10] += 118;  // 060068B6 add #118,r10
    c.r[8] += 118;  // 060068B8 add #118,r8
    c.r[15] += 118;  // 060068BA add #118,r15
    c.r[10] += 124;  // 060068BC add #124,r10
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[8] + 10);  // 060068BE mov.b @(10,r8),r0
    c.r[3] += 115;  // 060068C0 add #115,r3
    c.r[13] -= 127;  // 060068C2 add #-127,r13
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[7] + 13);  // 060068C4 mov.b @(13,r7),r0
    c.r[10] += 118;  // 060068C6 add #118,r10
    c.r[6] += 118;  // 060068C8 add #118,r6
    c.r[6] -= 128;  // 060068CA add #-128,r6
    c.r[13] -= 125;  // 060068CC add #-125,r13
    c.r[6] += 122;  // 060068CE add #122,r6
    c.r[6] -= 128;  // 060068D0 add #-128,r6
    c.r[10] += 122;  // 060068D2 add #122,r10
    c.r[0] = (uint32_t)(int8_t)ld8(c.r[6] + 6);  // 060068D4 mov.b @(6,r6),r0
    c.r[6] += 115;  // 060068D6 add #115,r6
    st8(c.r[8], c.r[0]);  // 060068D8 mov.b r0,@(0,r8)
    st8(c.r[8], c.r[0]);  // 060068DA mov.b r0,@(0,r8)
    st8(c.r[8], c.r[0]);  // 060068DC mov.b r0,@(0,r8)
    st8(c.r[8], c.r[0]);  // 060068DE mov.b r0,@(0,r8)
    st8(c.r[8], c.r[0]);  // 060068E0 mov.b r0,@(0,r8)
    st8(c.r[8], c.r[0]);  // 060068E2 mov.b r0,@(0,r8)
    st8(c.r[8], c.r[0]);  // 060068E4 mov.b r0,@(0,r8)
    st8(c.r[8], c.r[0]);  // 060068E6 mov.b r0,@(0,r8)
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 060068E8 rts ; mov.l @r15+,r14
}

void f_06009AC4(SH2Context& c) {
    ran[41] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06009AC4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06009AC6 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06009AC8 sts.l pr,@-r15
    c.r[8] = ld32(0x06009B38u);  // 06009ACA mov.l 0x06009B38,r8
    c.r[4] = ld32(0x06009B3Cu);  // 06009ACC mov.l 0x06009B3C,r4
    st32(c.r[8] + 16, c.r[4]);  // 06009ACE mov.l r4,@(16,r8)
    c.r[1] = ld32(0x06009B40u);  // 06009AD0 mov.l 0x06009B40,r1
    st32(c.r[8] + 20, c.r[1]);  // 06009AD2 mov.l r1,@(20,r8)
    c.r[1] = ld32(0x06009B44u);  // 06009AD4 mov.l 0x06009B44,r1
    st32(c.r[8], c.r[1]);  // 06009AD6 mov.l r1,@r8
    c.r[1] = ld32(0x06009B48u);  // 06009AD8 mov.l 0x06009B48,r1
    st32(c.r[8] + 4, c.r[1]);  // 06009ADA mov.l r1,@(4,r8)
    c.r[1] = ld32(0x06009B4Cu);  // 06009ADC mov.l 0x06009B4C,r1
    st32(c.r[8] + 8, c.r[1]);  // 06009ADE mov.l r1,@(8,r8)
    c.r[1] = ld32(0x06009B50u);  // 06009AE0 mov.l 0x06009B50,r1
    st32(c.r[8] + 12, c.r[1]);  // 06009AE2 mov.l r1,@(12,r8)
    c.r[14] = c.r[15];  // 06009AE4 mov r15,r14
    c.r[5] = 0x18u;  // 06009AE6 mov #24,r5
    c.r[5] <<= 8;  // 06009AE8 shll8 r5
    c.r[1] = ld32(0x06009B54u);  // 06009AEA mov.l 0x06009B54,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06009AF0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06009AF0u) return; }  // 06009AEC jsr @r1 ; nop
    c.r[4] = ld32(0x06009B44u);  // 06009AF0 mov.l 0x06009B44,r4
    c.r[5] = 0x4Cu;  // 06009AF2 mov #76,r5
    c.r[5] <<= 8;  // 06009AF4 shll8 r5
    c.t = c.r[5] >> 31; c.r[5] <<= 1;  // 06009AF6 shll r5
    c.r[1] = ld32(0x06009B54u);  // 06009AF8 mov.l 0x06009B54,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06009AFEu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06009AFEu) return; }  // 06009AFA jsr @r1 ; nop
    c.r[4] = c.r[8];  // 06009AFE mov r8,r4
    c.r[4] += 24;  // 06009B00 add #24,r4
    c.r[5] = 0x42u;  // 06009B02 mov #66,r5
    c.r[1] = ld32(0x06009B54u);  // 06009B04 mov.l 0x06009B54,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06009B0Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06009B0Au) return; }  // 06009B06 jsr @r1 ; nop
    c.r[8] = ld32(0x06009B58u);  // 06009B0A mov.l 0x06009B58,r8
    c.r[5] = 0x1Fu;  // 06009B0C mov #31,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06009B12u; c.r[4] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06009B12u) return; }  // 06009B0E jsr @r8 ; mov #0,r4
    c.r[5] = 0x1Fu;  // 06009B12 mov #31,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06009B18u; c.r[4] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06009B18u) return; }  // 06009B14 jsr @r8 ; mov #1,r4
    c.r[5] = 0x1Fu;  // 06009B18 mov #31,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06009B1Eu; c.r[4] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06009B1Eu) return; }  // 06009B1A jsr @r8 ; mov #2,r4
    c.r[5] = 0x1Fu;  // 06009B1E mov #31,r5
    { const uint32_t x = c.r[8]; c.pr = 0x06009B24u; c.r[4] = 0x3u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06009B24u) return; }  // 06009B20 jsr @r8 ; mov #3,r4
    c.r[2] = ld32(0x06009B5Cu);  // 06009B24 mov.l 0x06009B5C,r2
    c.r[1] = ld32(0x06009B38u);  // 06009B26 mov.l 0x06009B38,r1
    c.r[1] = ld32(c.r[1]);  // 06009B28 mov.l @r1,r1
    c.r[15] = c.r[14];  // 06009B2A mov r14,r15
    st32(c.r[2], c.r[1]);  // 06009B2C mov.l r1,@r2
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06009B2E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06009B30 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06009B32 rts ; mov.l @r15+,r8
}

void f_06009B60(SH2Context& c) {
    ran[42] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06009B60 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06009B62 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06009B64 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06009B66 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06009B68 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06009B6A sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06009B6C mov r15,r14
    c.r[9] = c.r[4];  // 06009B6E mov r4,r9
    c.r[1] = ld32(c.r[14] + 24);  // 06009B70 mov.l @(24,r14),r1
    c.r[10] = c.r[6] & 0xFFFFu;  // 06009B72 extu.w r6,r10
    c.r[8] = (uint32_t)(int16_t)ld16(0x06009BE8u);  // 06009B74 mov.w 0x06009BE8,r8
    c.r[1] = c.r[1] & 0xFFFFu;  // 06009B76 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06009B78 tst r1,r1
    { const bool k = c.t; c.r[11] = c.r[7] & 0xFFFFu; if (k) { goto L_06009BBE; } }  // 06009B7A bt/s 0x06009BBE ; extu.w r7,r11
    c.r[3] = c.r[1];  // 06009B7E mov r1,r3
    c.r[3] <<= 2;  // 06009B80 shll2 r3
    c.r[3] += c.r[3];  // 06009B82 add r3,r3
    c.r[3] -= 8;  // 06009B84 add #-8,r3
    c.r[9] += c.r[3];  // 06009B86 add r3,r9
    c.r[3] += c.r[5];  // 06009B88 add r5,r3
    c.r[1] = c.r[9];  // 06009B8A mov r9,r1
    c.r[1] += 4;  // 06009B8C add #4,r1
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06009B8E mov.w @r1,r8
    c.r[3] += 2;  // 06009B90 add #2,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[9]);  // 06009B92 mov.w @r9,r2
    c.r[0] = ld32(0x06009BECu);  // 06009B94 mov.l 0x06009BEC,r0
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06009B96 mov.w @r3,r5
    c.r[8] = c.r[8] & 0xFFFFu;  // 06009B98 extu.w r8,r8
    c.r[1] = c.r[9];  // 06009B9A mov r9,r1
    c.r[1] += 2;  // 06009B9C add #2,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06009B9E mov.w @r1,r1
    c.r[8] <<= 2;  // 06009BA0 shll2 r8
    c.r[8] += c.r[8];  // 06009BA2 add r8,r8
    c.macl = (c.r[2] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 06009BA4 mulu.w r1,r2
    c.r[5] = c.r[5] & 0xFFFFu;  // 06009BA6 extu.w r5,r5
    c.r[4] = c.macl;  // 06009BA8 sts macl,r4
    { const uint32_t x = c.r[0]; c.pr = 0x06009BAEu; c.r[4] <<= 2; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06009BAEu) return; }  // 06009BAA jsr @r0 ; shll2 r4
    c.r[0] += 31;  // 06009BAE add #31,r0
    c.r[1] = ld32(0x06009BF0u);  // 06009BB0 mov.l 0x06009BF0,r1
    c.r[0] &= c.r[1];  // 06009BB2 and r1,r0
    c.r[8] += c.r[0];  // 06009BB4 add r0,r8
    c.r[8] >>= 2;  // 06009BB6 shlr2 r8
    c.t = c.r[8] & 1; c.r[8] >>= 1;  // 06009BB8 shlr r8
    c.r[8] = c.r[8] & 0xFFFFu;  // 06009BBA extu.w r8,r8
    c.r[9] += 8;  // 06009BBC add #8,r9
L_06009BBE:
    st16(c.r[9], c.r[10]);  // 06009BBE mov.w r10,@r9
    c.r[1] = c.r[9];  // 06009BC0 mov r9,r1
    c.r[1] += 2;  // 06009BC2 add #2,r1
    st16(c.r[1], c.r[11]);  // 06009BC4 mov.w r11,@r1
    c.r[1] = c.r[9];  // 06009BC6 mov r9,r1
    c.r[1] += 4;  // 06009BC8 add #4,r1
    st16(c.r[1], c.r[8]);  // 06009BCA mov.w r8,@r1
    c.r[9] += 6;  // 06009BCC add #6,r9
    c.r[10] >>= 2;  // 06009BCE shlr2 r10
    c.t = c.r[10] & 1; c.r[10] >>= 1;  // 06009BD0 shlr r10
    c.r[10] <<= 8;  // 06009BD2 shll8 r10
    c.r[11] |= c.r[10];  // 06009BD4 or r10,r11
    st16(c.r[9], c.r[11]);  // 06009BD6 mov.w r11,@r9
    c.r[15] = c.r[14];  // 06009BD8 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06009BDA lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06009BDC mov.l @r15+,r14
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06009BDE mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06009BE0 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06009BE2 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06009BE4 rts ; mov.l @r15+,r8
}

void f_06009BF4(SH2Context& c) {
    ran[43] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06009BF4 mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06009BF6 mov r15,r14
    st16(c.r[4], c.r[5]);  // 06009BF8 mov.w r5,@r4
    c.r[1] = c.r[4];  // 06009BFA mov r4,r1
    c.r[1] += 2;  // 06009BFC add #2,r1
    st16(c.r[1], c.r[6]);  // 06009BFE mov.w r6,@r1
    st32(c.r[4] + 4, c.r[7]);  // 06009C00 mov.l r7,@(4,r4)
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06009C02 rts ; mov.l @r15+,r14
}

void f_06009C08(SH2Context& c) {
    ran[44] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06009C08 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06009C0A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06009C0C mov.l r14,@-r15
    c.r[14] = c.r[15];  // 06009C0E mov r15,r14
    st16(c.r[4], c.r[5]);  // 06009C10 mov.w r5,@r4
    c.r[1] = c.r[4];  // 06009C12 mov r4,r1
    c.r[1] += 2;  // 06009C14 add #2,r1
    c.r[9] = 0x7u;  // 06009C16 mov #7,r9
    c.r[7] &= c.r[9];  // 06009C18 and r9,r7
    c.r[8] = ld32(c.r[14] + 12);  // 06009C1A mov.l @(12,r14),r8
    c.r[9] = 0x3u;  // 06009C1C mov #3,r9
    c.r[3] = ld32(c.r[14] + 20);  // 06009C1E mov.l @(20,r14),r3
    c.r[2] = ld32(c.r[14] + 16);  // 06009C20 mov.l @(16,r14),r2
    c.r[0] = c.r[3];  // 06009C22 mov r3,r0
    c.r[0] >>= 16;  // 06009C24 shlr16 r0
    c.r[0] >>= 8;  // 06009C26 shlr8 r0
    c.r[0] &= 0xC0u;  // 06009C28 and #192,r0
    c.r[2] |= c.r[0];  // 06009C2A or r0,r2
    st16(c.r[1], c.r[2]);  // 06009C2C mov.w r2,@r1
    c.r[1] = c.r[4];  // 06009C2E mov r4,r1
    c.r[1] += 4;  // 06009C30 add #4,r1
    c.r[7] <<= 8;  // 06009C32 shll8 r7
    c.r[7] <<= 2;  // 06009C34 shll2 r7
    c.r[7] <<= 2;  // 06009C36 shll2 r7
    c.r[8] &= c.r[9];  // 06009C38 and r9,r8
    c.r[8] <<= 8;  // 06009C3A shll8 r8
    c.r[8] <<= 2;  // 06009C3C shll2 r8
    c.r[7] |= c.r[8];  // 06009C3E or r8,r7
    c.r[9] = 0x3Fu;  // 06009C40 mov #63,r9
    c.r[6] &= c.r[9];  // 06009C42 and r9,r6
    c.r[6] <<= 2;  // 06009C44 shll2 r6
    c.r[6] <<= 2;  // 06009C46 shll2 r6
    c.r[7] |= c.r[6];  // 06009C48 or r6,r7
    st16(c.r[1], c.r[7]);  // 06009C4A mov.w r7,@r1
    c.r[2] = c.r[4];  // 06009C4C mov r4,r2
    c.r[2] += 6;  // 06009C4E add #6,r2
    c.r[1] = 0x0u;  // 06009C50 mov #0,r1
    st16(c.r[2], c.r[1]);  // 06009C52 mov.w r1,@r2
    c.r[4] += 8;  // 06009C54 add #8,r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x06009C64u);  // 06009C56 mov.w 0x06009C64,r1
    c.r[3] &= c.r[1];  // 06009C58 and r1,r3
    st16(c.r[4], c.r[3]);  // 06009C5A mov.w r3,@r4
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06009C5C mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06009C5E mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06009C60 rts ; mov.l @r15+,r8
}

void f_06009C68(SH2Context& c) {
    ran[45] = 1;
L_06009C68:
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06009C68 mov.l r14,@-r15
L_06009C6A:
    c.r[14] = c.r[15];  // 06009C6A mov r15,r14
L_06009C6C:
    c.r[0] = c.r[4];  // 06009C6C mov r4,r0
L_06009C6E:
    c.r[0] &= 0x3u;  // 06009C6E and #3,r0
L_06009C70:
    c.r[7] = ~c.r[5];  // 06009C70 not r5,r7
L_06009C72:
    c.r[6] = 0x1Fu;  // 06009C72 mov #31,r6
L_06009C74:
    c.r[1] = 0x3u;  // 06009C74 mov #3,r1
L_06009C76:
    c.t = c.r[0] > c.r[1];  // 06009C76 cmp/hi r1,r0
L_06009C78:
    { const bool k = c.t; c.r[7] &= c.r[6]; if (k) { goto L_06009CB8; } }  // 06009C78 bt/s 0x06009CB8 ; and r6,r7
L_06009C7C:
    c.r[1] = c.r[0];  // 06009C7C mov r0,r1
L_06009C7E:
    c.r[1] += c.r[1];  // 06009C7E add r1,r1
L_06009C80:
    c.r[0] = 0x06009C8Cu;  // 06009C80 mova 0x06009C8C,r0
L_06009C82:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 06009C82 mov.w @(r0,r1),r1
L_06009C84:
    c.r[0] += c.r[1];  // 06009C84 add r1,r0
L_06009C86:
    { const uint32_t x = c.r[0]; SH2_POLL(c); switch (x) { case 0x06009C68u: goto L_06009C68; case 0x06009C6Au: goto L_06009C6A; case 0x06009C6Cu: goto L_06009C6C; case 0x06009C6Eu: goto L_06009C6E; case 0x06009C70u: goto L_06009C70; case 0x06009C72u: goto L_06009C72; case 0x06009C74u: goto L_06009C74; case 0x06009C76u: goto L_06009C76; case 0x06009C78u: goto L_06009C78; case 0x06009C7Cu: goto L_06009C7C; case 0x06009C7Eu: goto L_06009C7E; case 0x06009C80u: goto L_06009C80; case 0x06009C82u: goto L_06009C82; case 0x06009C84u: goto L_06009C84; case 0x06009C86u: goto L_06009C86; case 0x06009C8Au: goto L_06009C8A; case 0x06009C8Cu: goto L_06009C8C; case 0x06009CB8u: goto L_06009CB8; case 0x06009CBAu: goto L_06009CBA; default: sh2_call(c, x); return; } }  // 06009C86 jmp @r0 ; nop
L_06009C8A:
    ;  // 06009C8A nop
L_06009C8C:
    c.t = 0;  // 06009C8C clrt
    sh2_call(c, 0x06009C8Eu); return;
L_06009CB8:
    c.r[15] = c.r[14];  // 06009CB8 mov r14,r15
L_06009CBA:
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06009CBA rts ; mov.l @r15+,r14
}

void f_06009C94(SH2Context& c) {
    ran[46] = 1;
    c.r[3] = ld32(0x06009CC4u);  // 06009C94 mov.l 0x06009CC4,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x06009CBEu);  // 06009C96 mov.w 0x06009CBE,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]); goto L_06009CB2;  // 06009C98 bra 0x06009CB2 ; mov.w @r3,r2
L_06009CB2:
    c.r[1] &= c.r[2];  // 06009CB2 and r2,r1
    c.r[1] |= c.r[7];  // 06009CB4 or r7,r1
    st16(c.r[3], c.r[1]);  // 06009CB6 mov.w r1,@r3
    c.r[15] = c.r[14];  // 06009CB8 mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06009CBA rts ; mov.l @r15+,r14
}

void f_06009C9C(SH2Context& c) {
    ran[47] = 1;
    c.r[3] = ld32(0x06009CC4u);  // 06009C9C mov.l 0x06009CC4,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]); goto L_06009CAE;  // 06009C9E bra 0x06009CAE ; mov.w @r3,r2
L_06009CAE:
    c.r[1] = (uint32_t)(int16_t)ld16(0x06009CC0u);  // 06009CAE mov.w 0x06009CC0,r1
    c.r[7] <<= 8;  // 06009CB0 shll8 r7
    c.r[1] &= c.r[2];  // 06009CB2 and r2,r1
    c.r[1] |= c.r[7];  // 06009CB4 or r7,r1
    st16(c.r[3], c.r[1]);  // 06009CB6 mov.w r1,@r3
    c.r[15] = c.r[14];  // 06009CB8 mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06009CBA rts ; mov.l @r15+,r14
}

void f_06009CA2(SH2Context& c) {
    ran[48] = 1;
    c.r[3] = ld32(0x06009CC8u);  // 06009CA2 mov.l 0x06009CC8,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x06009CBEu);  // 06009CA4 mov.w 0x06009CBE,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]); goto L_06009CB2;  // 06009CA6 bra 0x06009CB2 ; mov.w @r3,r2
L_06009CB2:
    c.r[1] &= c.r[2];  // 06009CB2 and r2,r1
    c.r[1] |= c.r[7];  // 06009CB4 or r7,r1
    st16(c.r[3], c.r[1]);  // 06009CB6 mov.w r1,@r3
    c.r[15] = c.r[14];  // 06009CB8 mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06009CBA rts ; mov.l @r15+,r14
}

void f_06009CAA(SH2Context& c) {
    ran[49] = 1;
    c.r[3] = ld32(0x06009CC8u);  // 06009CAA mov.l 0x06009CC8,r3
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[3]);  // 06009CAC mov.w @r3,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06009CC0u);  // 06009CAE mov.w 0x06009CC0,r1
    c.r[7] <<= 8;  // 06009CB0 shll8 r7
    c.r[1] &= c.r[2];  // 06009CB2 and r2,r1
    c.r[1] |= c.r[7];  // 06009CB4 or r7,r1
    st16(c.r[3], c.r[1]);  // 06009CB6 mov.w r1,@r3
    c.r[15] = c.r[14];  // 06009CB8 mov r14,r15
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06009CBA rts ; mov.l @r15+,r14
}

void f_06009CCC(SH2Context& c) {
    ran[50] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06009CCC mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06009CCE mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06009CD0 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06009CD2 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06009CD4 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06009CD6 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06009CD8 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06009CDA sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06009CDC mov r15,r14
    c.r[10] = c.r[5];  // 06009CDE mov r5,r10
    c.t = (c.r[10] & c.r[10]) == 0;  // 06009CE0 tst r10,r10
    { const bool k = c.t; c.r[9] = c.r[4]; if (k) { goto L_06009D46; } }  // 06009CE2 bt/s 0x06009D46 ; mov r4,r9
    c.r[2] = ld32(0x06009D5Cu);  // 06009CE6 mov.l 0x06009D5C,r2
    c.r[1] = 0x1u;  // 06009CE8 mov #1,r1
    st8(c.r[2], c.r[1]);  // 06009CEA mov.b r1,@r2
    c.r[10] -= 1;  // 06009CEC add #-1,r10
    c.r[13] = ld32(0x06009D60u);  // 06009CEE mov.l 0x06009D60,r13
    c.r[12] = ld32(0x06009D64u);  // 06009CF0 mov.l 0x06009D64,r12
    c.r[11] = c.r[9];  // 06009CF2 mov r9,r11
    c.r[11] += 2;  // 06009CF4 add #2,r11
L_06009CF6:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]);  // 06009CF6 mov.w @r9,r1
    c.r[3] = ld32(0x06009D68u);  // 06009CF8 mov.l 0x06009D68,r3
    c.r[0] = ld32(c.r[3]);  // 06009CFA mov.l @r3,r0
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[11]);  // 06009CFC mov.w @r11,r5
    c.r[2] = c.r[1] & 0xFFFFu;  // 06009CFE extu.w r1,r2
    c.r[2] <<= 2;  // 06009D00 shll2 r2
    c.r[2] += c.r[2];  // 06009D02 add r2,r2
    c.r[8] = c.r[0];  // 06009D04 mov r0,r8
    c.r[8] += c.r[2];  // 06009D06 add r2,r8
    c.r[1] = c.r[8];  // 06009D08 mov r8,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 06009D0A mov.w @(r0,r2),r2
    c.r[1] += 2;  // 06009D0C add #2,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06009D0E mov.w @r1,r1
    c.r[11] += 8;  // 06009D10 add #8,r11
    c.macl = (c.r[2] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 06009D12 mulu.w r1,r2
    c.r[5] = c.r[5] & 0xFFFFu;  // 06009D14 extu.w r5,r5
    c.r[4] = c.macl;  // 06009D16 sts macl,r4
    { const uint32_t x = c.r[13]; c.pr = 0x06009D1Cu; c.r[4] <<= 2; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06009D1Cu) return; }  // 06009D18 jsr @r13 ; shll2 r4
    c.r[8] += 4;  // 06009D1C add #4,r8
    c.r[1] = ld32(0x06009D6Cu);  // 06009D1E mov.l 0x06009D6C,r1
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06009D20 mov.w @r8,r5
    c.r[6] = c.r[0];  // 06009D22 mov r0,r6
    c.r[4] = ld32(c.r[9] + 4);  // 06009D24 mov.l @(4,r9),r4
    c.r[5] = c.r[5] & 0xFFFFu;  // 06009D26 extu.w r5,r5
    c.r[5] <<= 2;  // 06009D28 shll2 r5
    c.r[5] += c.r[5];  // 06009D2A add r5,r5
    { const uint32_t x = c.r[12]; c.pr = 0x06009D30u; c.r[5] += c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06009D30u) return; }  // 06009D2C jsr @r12 ; add r1,r5
    c.r[9] += 8;  // 06009D30 add #8,r9
    c.r[1] = c.r[10];  // 06009D32 mov r10,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06009D34 tst r1,r1
    { const bool k = !c.t; c.r[10] -= 1; if (k) { SH2_POLL(c); goto L_06009CF6; } }  // 06009D36 bf/s 0x06009CF6 ; add #-1,r10
    c.r[1] = ld32(0x06009D70u);  // 06009D3A mov.l 0x06009D70,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06009D40u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06009D40u) return; }  // 06009D3C jsr @r1 ; nop
    c.r[2] = ld32(0x06009D5Cu);  // 06009D40 mov.l 0x06009D5C,r2
    c.r[1] = 0x0u;  // 06009D42 mov #0,r1
    st8(c.r[2], c.r[1]);  // 06009D44 mov.b r1,@r2
L_06009D46:
    c.r[15] = c.r[14];  // 06009D46 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06009D48 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06009D4A mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06009D4C mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06009D4E mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06009D50 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06009D52 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06009D54 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06009D56 rts ; mov.l @r15+,r8
}

void f_06009D74(SH2Context& c) {
    ran[51] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06009D74 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06009D76 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06009D78 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06009D7A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06009D7C mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06009D7E mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06009D80 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06009D82 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 06009D84 mov r15,r14
    c.r[10] = c.r[5];  // 06009D86 mov r5,r10
    c.t = (c.r[10] & c.r[10]) == 0;  // 06009D88 tst r10,r10
    { const bool k = c.t; c.r[9] = c.r[4]; if (k) { goto L_06009DEC; } }  // 06009D8A bt/s 0x06009DEC ; mov r4,r9
    c.r[1] = ld32(0x06009E00u);  // 06009D8E mov.l 0x06009E00,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06009D90 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06009D92 extu.b r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06009D94 tst r1,r1
    { const bool k = !c.t; c.r[10] -= 1; if (k) { goto L_06009DEC; } }  // 06009D96 bf/s 0x06009DEC ; add #-1,r10
    c.r[13] = ld32(0x06009E04u);  // 06009D9A mov.l 0x06009E04,r13
    c.r[12] = ld32(0x06009E08u);  // 06009D9C mov.l 0x06009E08,r12
    c.r[11] = c.r[9];  // 06009D9E mov r9,r11
    c.r[11] += 2;  // 06009DA0 add #2,r11
L_06009DA2:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]);  // 06009DA2 mov.w @r9,r1
    c.r[3] = ld32(0x06009E0Cu);  // 06009DA4 mov.l 0x06009E0C,r3
    c.r[0] = ld32(c.r[3]);  // 06009DA6 mov.l @r3,r0
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[11]);  // 06009DA8 mov.w @r11,r5
    c.r[2] = c.r[1] & 0xFFFFu;  // 06009DAA extu.w r1,r2
    c.r[2] <<= 2;  // 06009DAC shll2 r2
    c.r[2] += c.r[2];  // 06009DAE add r2,r2
    c.r[8] = c.r[0];  // 06009DB0 mov r0,r8
    c.r[8] += c.r[2];  // 06009DB2 add r2,r8
    c.r[1] = c.r[8];  // 06009DB4 mov r8,r1
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 06009DB6 mov.w @(r0,r2),r2
    c.r[1] += 2;  // 06009DB8 add #2,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06009DBA mov.w @r1,r1
    c.r[11] += 8;  // 06009DBC add #8,r11
    c.macl = (c.r[2] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 06009DBE mulu.w r1,r2
    c.r[5] = c.r[5] & 0xFFFFu;  // 06009DC0 extu.w r5,r5
    c.r[4] = c.macl;  // 06009DC2 sts macl,r4
    { const uint32_t x = c.r[13]; c.pr = 0x06009DC8u; c.r[4] <<= 2; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06009DC8u) return; }  // 06009DC4 jsr @r13 ; shll2 r4
    c.r[8] += 4;  // 06009DC8 add #4,r8
    c.r[1] = ld32(0x06009E10u);  // 06009DCA mov.l 0x06009E10,r1
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[8]);  // 06009DCC mov.w @r8,r5
    c.r[6] = c.r[0];  // 06009DCE mov r0,r6
    c.r[4] = ld32(c.r[9] + 4);  // 06009DD0 mov.l @(4,r9),r4
    c.r[5] = c.r[5] & 0xFFFFu;  // 06009DD2 extu.w r5,r5
    c.r[5] <<= 2;  // 06009DD4 shll2 r5
    c.r[5] += c.r[5];  // 06009DD6 add r5,r5
    { const uint32_t x = c.r[12]; c.pr = 0x06009DDCu; c.r[5] += c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06009DDCu) return; }  // 06009DD8 jsr @r12 ; add r1,r5
    c.r[9] += 8;  // 06009DDC add #8,r9
    c.r[1] = c.r[10];  // 06009DDE mov r10,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 06009DE0 tst r1,r1
    { const bool k = !c.t; c.r[10] -= 1; if (k) { SH2_POLL(c); goto L_06009DA2; } }  // 06009DE2 bf/s 0x06009DA2 ; add #-1,r10
    c.r[1] = ld32(0x06009E14u);  // 06009DE6 mov.l 0x06009E14,r1
    { const uint32_t x = c.r[1]; c.pr = 0x06009DECu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06009DECu) return; }  // 06009DE8 jsr @r1 ; nop
L_06009DEC:
    c.r[15] = c.r[14];  // 06009DEC mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06009DEE lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 06009DF0 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 06009DF2 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 06009DF4 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 06009DF6 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 06009DF8 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 06009DFA mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06009DFC rts ; mov.l @r15+,r8
}

void f_06009E18(SH2Context& c) {
    ran[52] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06009E18 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06009E1A sts.l pr,@-r15
    c.r[15] -= 16;  // 06009E1C add #-16,r15
    c.r[1] = ld32(c.r[4]);  // 06009E1E mov.l @r4,r1
    c.r[14] = c.r[15];  // 06009E20 mov r15,r14
    st32(c.r[14], c.r[1]);  // 06009E22 mov.l r1,@r14
    c.r[1] = ld32(c.r[4] + 4);  // 06009E24 mov.l @(4,r4),r1
    c.r[0] = ld32(0x06009E44u);  // 06009E26 mov.l 0x06009E44,r0
    st32(c.r[14] + 4, c.r[1]);  // 06009E28 mov.l r1,@(4,r14)
    c.r[1] = ld32(c.r[4] + 8);  // 06009E2A mov.l @(8,r4),r1
    c.r[6] = 0x0u;  // 06009E2C mov #0,r6
    st32(c.r[14] + 8, c.r[1]);  // 06009E2E mov.l r1,@(8,r14)
    c.r[1] = ld32(0x06009E48u);  // 06009E30 mov.l 0x06009E48,r1
    st32(c.r[14] + 12, c.r[1]);  // 06009E32 mov.l r1,@(12,r14)
    { const uint32_t x = c.r[0]; c.pr = 0x06009E38u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06009E38u) return; }  // 06009E34 jsr @r0 ; mov r14,r4
    c.r[14] += 16;  // 06009E38 add #16,r14
    c.r[15] = c.r[14];  // 06009E3A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06009E3C lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06009E3E rts ; mov.l @r15+,r14
}

void f_06009E4C(SH2Context& c) {
    ran[53] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06009E4C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06009E4E sts.l pr,@-r15
    c.r[15] -= 32;  // 06009E50 add #-32,r15
    c.r[14] = c.r[15];  // 06009E52 mov r15,r14
    c.r[1] = ld32(0x06009F38u);  // 06009E54 mov.l 0x06009F38,r1
    c.r[2] = c.r[4];  // 06009E56 mov r4,r2
    c.r[2] += 22;  // 06009E58 add #22,r2
    c.r[3] = 0x1u;  // 06009E5A mov #1,r3
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[4]);  // 06009E5C mov.w @r4,r5
    c.r[7] = 0xFu;  // 06009E5E mov #15,r7
    c.r[0] = ld32(c.r[1]);  // 06009E60 mov.l @r1,r0
    c.r[5] = c.r[5] & 0xFFFFu;  // 06009E62 extu.w r5,r5
    c.r[5] <<= 2;  // 06009E64 shll2 r5
    c.r[5] += c.r[5];  // 06009E66 add r5,r5
    c.r[1] = c.r[4];  // 06009E68 mov r4,r1
    c.r[1] += 18;  // 06009E6A add #18,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06009E6C mov.w @r1,r1
    c.r[6] = c.r[0];  // 06009E6E mov r0,r6
    c.r[3] |= c.r[1];  // 06009E70 or r1,r3
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 06009E72 mov.w @r2,r1
    c.r[6] += c.r[5];  // 06009E74 add r5,r6
    c.r[3] |= c.r[1];  // 06009E76 or r1,r3
    st16(c.r[14], c.r[3]);  // 06009E78 mov.w r3,@r14
    c.r[1] = c.r[14];  // 06009E7A mov r14,r1
    c.r[1] += 2;  // 06009E7C add #2,r1
    c.r[3] = 0x0u;  // 06009E7E mov #0,r3
    st16(c.r[1], c.r[3]);  // 06009E80 mov.w r3,@r1
    c.r[2] = c.r[14];  // 06009E82 mov r14,r2
    c.r[2] += 4;  // 06009E84 add #4,r2
    c.r[1] = (uint32_t)(int16_t)ld16(0x06009F32u);  // 06009E86 mov.w 0x06009F32,r1
    st16(c.r[2], c.r[1]);  // 06009E88 mov.w r1,@r2
    c.r[2] = c.r[14];  // 06009E8A mov r14,r2
    c.r[1] = c.r[4];  // 06009E8C mov r4,r1
    c.r[1] += 14;  // 06009E8E add #14,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06009E90 mov.b @r1,r1
    c.r[2] += 6;  // 06009E92 add #6,r2
    c.r[7] &= c.r[1];  // 06009E94 and r1,r7
    c.r[1] = c.r[4];  // 06009E96 mov r4,r1
    c.r[1] += 12;  // 06009E98 add #12,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06009E9A mov.w @r1,r1
    c.r[7] <<= 8;  // 06009E9C shll8 r7
    c.r[7] <<= 2;  // 06009E9E shll2 r7
    c.r[7] <<= 2;  // 06009EA0 shll2 r7
    c.r[1] = c.r[1] & 0xFFFFu;  // 06009EA2 extu.w r1,r1
    c.r[1] <<= 2;  // 06009EA4 shll2 r1
    c.r[1] <<= 2;  // 06009EA6 shll2 r1
    c.r[7] |= c.r[1];  // 06009EA8 or r1,r7
    st16(c.r[2], c.r[7]);  // 06009EAA mov.w r7,@r2
    c.r[2] = c.r[14];  // 06009EAC mov r14,r2
    c.r[2] += 8;  // 06009EAE add #8,r2
    c.r[1] = c.r[6];  // 06009EB0 mov r6,r1
    c.r[1] += 4;  // 06009EB2 add #4,r1
    c.r[7] = c.r[14];  // 06009EB4 mov r14,r7
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06009EB6 mov.w @r1,r1
    c.r[7] += 10;  // 06009EB8 add #10,r7
    st16(c.r[2], c.r[1]);  // 06009EBA mov.w r1,@r2
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[5]);  // 06009EBC mov.w @(r0,r5),r2
    c.r[6] += 2;  // 06009EBE add #2,r6
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[6]);  // 06009EC0 mov.w @r6,r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 06009EC2 extu.w r2,r2
    c.r[2] >>= 2;  // 06009EC4 shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 06009EC6 shlr r2
    c.r[2] <<= 8;  // 06009EC8 shll8 r2
    c.r[2] |= c.r[1];  // 06009ECA or r1,r2
    st16(c.r[7], c.r[2]);  // 06009ECC mov.w r2,@r7
    c.r[7] = c.r[14];  // 06009ECE mov r14,r7
    c.r[7] += 12;  // 06009ED0 add #12,r7
    c.r[1] = c.r[4];  // 06009ED2 mov r4,r1
    c.r[1] += 2;  // 06009ED4 add #2,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06009ED6 mov.w @r1,r1
    c.r[2] = (uint32_t)(int16_t)ld16(0x06009F34u);  // 06009ED8 mov.w 0x06009F34,r2
    c.r[1] += c.r[2];  // 06009EDA add r2,r1
    st16(c.r[7], c.r[1]);  // 06009EDC mov.w r1,@r7
    c.r[2] = c.r[14];  // 06009EDE mov r14,r2
    c.r[1] = c.r[4];  // 06009EE0 mov r4,r1
    c.r[1] += 4;  // 06009EE2 add #4,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 06009EE4 mov.w @r1,r1
    c.r[2] += 14;  // 06009EE6 add #14,r2
    c.r[1] -= 112;  // 06009EE8 add #-112,r1
    st16(c.r[2], c.r[1]);  // 06009EEA mov.w r1,@r2
    c.r[2] = c.r[14];  // 06009EEC mov r14,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[5]);  // 06009EEE mov.w @(r0,r5),r1
    c.r[2] += 16;  // 06009EF0 add #16,r2
    st16(c.r[2], c.r[1]);  // 06009EF2 mov.w r1,@r2
    c.r[2] = c.r[14];  // 06009EF4 mov r14,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[6]);  // 06009EF6 mov.w @r6,r1
    c.r[2] += 18;  // 06009EF8 add #18,r2
    st16(c.r[2], c.r[1]);  // 06009EFA mov.w r1,@r2
    c.r[1] = c.r[14];  // 06009EFC mov r14,r1
    c.r[1] += 20;  // 06009EFE add #20,r1
    st16(c.r[1], c.r[3]);  // 06009F00 mov.w r3,@r1
    c.r[1] = c.r[14];  // 06009F02 mov r14,r1
    c.r[1] += 22;  // 06009F04 add #22,r1
    st16(c.r[1], c.r[3]);  // 06009F06 mov.w r3,@r1
    c.r[1] = c.r[14];  // 06009F08 mov r14,r1
    c.r[1] += 24;  // 06009F0A add #24,r1
    st16(c.r[1], c.r[3]);  // 06009F0C mov.w r3,@r1
    c.r[1] = c.r[14];  // 06009F0E mov r14,r1
    c.r[1] += 26;  // 06009F10 add #26,r1
    st16(c.r[1], c.r[3]);  // 06009F12 mov.w r3,@r1
    c.r[1] = c.r[14];  // 06009F14 mov r14,r1
    c.r[1] += 28;  // 06009F16 add #28,r1
    st16(c.r[1], c.r[3]);  // 06009F18 mov.w r3,@r1
    c.r[1] = c.r[14];  // 06009F1A mov r14,r1
    c.r[1] += 30;  // 06009F1C add #30,r1
    st16(c.r[1], c.r[3]);  // 06009F1E mov.w r3,@r1
    c.r[5] = ld32(c.r[4] + 8);  // 06009F20 mov.l @(8,r4),r5
    c.r[0] = ld32(0x06009F3Cu);  // 06009F22 mov.l 0x06009F3C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x06009F28u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x06009F28u) return; }  // 06009F24 jsr @r0 ; mov r14,r4
    c.r[14] += 32;  // 06009F28 add #32,r14
    c.r[15] = c.r[14];  // 06009F2A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 06009F2C lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 06009F2E rts ; mov.l @r15+,r14
}

void f_06009F40(SH2Context& c) {
    ran[54] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 06009F40 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 06009F42 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 06009F44 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 06009F46 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 06009F48 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 06009F4A mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 06009F4C mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 06009F4E sts.l pr,@-r15
    c.r[15] -= 112;  // 06009F50 add #-112,r15
    c.r[14] = c.r[15];  // 06009F52 mov r15,r14
    c.r[8] = c.r[5];  // 06009F54 mov r5,r8
    st32(c.r[14] + 12, c.r[6]);  // 06009F56 mov.l r6,@(12,r14)
    st32(c.r[14] + 16, c.r[7]);  // 06009F58 mov.l r7,@(16,r14)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0600A02Eu);  // 06009F5A mov.w 0x0600A02E,r0
    c.r[0] += c.r[14];  // 06009F5C add r14,r0
    c.r[13] = (uint32_t)(int16_t)ld16(0x0600A030u);  // 06009F5E mov.w 0x0600A030,r13
    c.r[13] += c.r[14];  // 06009F60 add r14,r13
    c.r[1] = ld32(c.r[0]);  // 06009F62 mov.l @r0,r1
    c.r[12] = c.r[4];  // 06009F64 mov r4,r12
    c.r[2] = ld32(c.r[13]);  // 06009F66 mov.l @r13,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0600A032u);  // 06009F68 mov.w 0x0600A032,r0
    c.r[0] += c.r[14];  // 06009F6A add r14,r0
    c.r[1] = c.r[1] & 0xFFFFu;  // 06009F6C extu.w r1,r1
    c.r[2] = c.r[2] & 0xFFFFu;  // 06009F6E extu.w r2,r2
    c.r[13] = (uint32_t)(int16_t)ld16(0x0600A034u);  // 06009F70 mov.w 0x0600A034,r13
    c.r[3] = ld32(c.r[0]);  // 06009F72 mov.l @r0,r3
    c.r[13] += c.r[14];  // 06009F74 add r14,r13
    st32(c.r[14] + 20, c.r[1]);  // 06009F76 mov.l r1,@(20,r14)
    st32(c.r[14] + 24, c.r[2]);  // 06009F78 mov.l r2,@(24,r14)
    c.r[11] = c.r[3] & 0xFFu;  // 06009F7A extu.b r3,r11
    c.r[0] = (uint32_t)(int16_t)ld16(0x0600A036u);  // 06009F7C mov.w 0x0600A036,r0
    c.r[0] += c.r[14];  // 06009F7E add r14,r0
    c.r[3] = 0x2u;  // 06009F80 mov #2,r3
    c.r[2] = c.r[14];  // 06009F82 mov r14,r2
    c.r[2] += 1;  // 06009F84 add #1,r2
    c.r[13] = ld32(c.r[13]);  // 06009F86 mov.l @r13,r13
    c.r[1] = 0x8u;  // 06009F88 mov #8,r1
    st32(c.r[14] + 28, c.r[13]);  // 06009F8A mov.l r13,@(28,r14)
    c.r[0] = ld32(c.r[0]);  // 06009F8C mov.l @r0,r0
    c.r[13] = 0x0u;  // 06009F8E mov #0,r13
    st32(c.r[14] + 32, c.r[0]);  // 06009F90 mov.l r0,@(32,r14)
    st32(c.r[14] + 36, c.r[4]);  // 06009F92 mov.l r4,@(36,r14)
    c.r[9] = ld32(c.r[14] + 36);  // 06009F94 mov.l @(36,r14),r9
    st8(c.r[14], c.r[3]);  // 06009F96 mov.b r3,@r14
    st8(c.r[2], c.r[1]);  // 06009F98 mov.b r1,@r2
    c.r[2] = c.r[14];  // 06009F9A mov r14,r2
    c.r[2] += 2;  // 06009F9C add #2,r2
    c.r[1] = 0x4u;  // 06009F9E mov #4,r1
    st8(c.r[2], c.r[1]);  // 06009FA0 mov.b r1,@r2
    st32(c.r[14] + 40, c.r[13]);  // 06009FA2 mov.l r13,@(40,r14)
    c.r[2] = c.r[14];  // 06009FA4 mov r14,r2
    c.r[2] += 4;  // 06009FA6 add #4,r2
    c.r[1] = 0x1u;  // 06009FA8 mov #1,r1
    st8(c.r[2], c.r[1]);  // 06009FAA mov.b r1,@r2
    c.r[2] = c.r[14];  // 06009FAC mov r14,r2
    c.r[2] += 5;  // 06009FAE add #5,r2
    c.r[1] = 0x3u;  // 06009FB0 mov #3,r1
    st8(c.r[2], c.r[1]);  // 06009FB2 mov.b r1,@r2
    c.r[1] = c.r[14];  // 06009FB4 mov r14,r1
    c.r[1] += 6;  // 06009FB6 add #6,r1
    st8(c.r[1], c.r[3]);  // 06009FB8 mov.b r3,@r1
    c.r[2] = c.r[14];  // 06009FBA mov r14,r2
    c.r[2] += 8;  // 06009FBC add #8,r2
    c.r[1] = 0x28u;  // 06009FBE mov #40,r1
    st8(c.r[2], c.r[1]);  // 06009FC0 mov.b r1,@r2
    c.r[2] = c.r[14];  // 06009FC2 mov r14,r2
    c.r[2] += 9;  // 06009FC4 add #9,r2
    c.r[1] = 0x0u;  // 06009FC6 mov #0,r1
    st8(c.r[2], c.r[1]);  // 06009FC8 mov.b r1,@r2
    c.r[2] = c.r[14];  // 06009FCA mov r14,r2
    c.r[2] += 10;  // 06009FCC add #10,r2
    c.r[1] = 0x20u;  // 06009FCE mov #32,r1
    st8(c.r[2], c.r[1]);  // 06009FD0 mov.b r1,@r2
    c.r[0] = ld32(c.r[14] + 12);  // 06009FD2 mov.l @(12,r14),r0
    c.r[12] += 2;  // 06009FD4 add #2,r12
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0]);  // 06009FD6 mov.w @r0,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 06009FD8 extu.w r1,r1
    st32(c.r[14] + 52, c.r[1]);  // 06009FDA mov.l r1,@(52,r14)
    c.r[1] = ld32(c.r[14] + 36);  // 06009FDC mov.l @(36,r14),r1
    st32(c.r[14] + 56, c.r[13]);  // 06009FDE mov.l r13,@(56,r14)
    c.r[1] += 1;  // 06009FE0 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 06009FE2 mov.b @r1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 06009FE4 extu.b r1,r1
    c.r[0] = c.r[1];  // 06009FE6 mov r1,r0
    c.t = c.r[0] == 0x58u;  // 06009FE8 cmp/eq #88,r0
    { const bool k = c.t; c.r[10] = 0x0u; if (k) { goto L_06009FF8; } }  // 06009FEA bt/s 0x06009FF8 ; mov #0,r10
    c.t = c.r[0] == 0x5Fu;  // 06009FEE cmp/eq #95,r0
    if (c.t) { goto L_0600A00A; }  // 06009FF0 bt 0x0600A00A
    c.r[14] += 112;  // 06009FF2 add #112,r14
    c.r[15] = c.r[14]; goto L_0600A44C;  // 06009FF4 bra 0x0600A44C ; mov r14,r15
L_06009FF8:
    c.r[8] += 2;  // 06009FF8 add #2,r8
    c.r[5] = c.r[8];  // 06009FFA mov r8,r5
    c.r[13] = ld32(0x0600A038u);  // 06009FFC mov.l 0x0600A038,r13
    { const uint32_t x = c.r[13]; c.pr = 0x0600A002u; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600A002u) return; }  // 06009FFE jsr @r13 ; mov r12,r4
    c.r[12] = c.r[8];  // 0600A002 mov r8,r12
    st32(c.r[14] + 36, c.r[12]);  // 0600A004 mov.l r12,@(36,r14)
    c.r[0] = 0xFFFFFFFEu;  // 0600A006 mov #-2,r0
    st32(c.r[14] + 56, c.r[0]);  // 0600A008 mov.l r0,@(56,r14)
L_0600A00A:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[9]);  // 0600A00A mov.b @r9,r1
    c.r[2] = c.r[1] & 0xFFu;  // 0600A00C extu.b r1,r2
    c.r[0] = c.r[2];  // 0600A00E mov r2,r0
    c.t = c.r[0] == 0x50u;  // 0600A010 cmp/eq #80,r0
    { const bool k = c.t; c.r[1] = 0x50u; if (k) { goto L_0600A03C; } }  // 0600A012 bt/s 0x0600A03C ; mov #80,r1
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0600A016 cmp/gt r1,r2
    { const bool k = c.t; c.t = c.r[0] == 0x70u; if (k) { goto L_0600A026; } }  // 0600A018 bt/s 0x0600A026 ; cmp/eq #112,r0
    c.t = c.r[0] == 0x44u;  // 0600A01C cmp/eq #68,r0
    if (c.t) { goto L_0600A05E; }  // 0600A01E bt 0x0600A05E
    c.r[14] += 112;  // 0600A020 add #112,r14
    c.r[15] = c.r[14]; goto L_0600A44C;  // 0600A022 bra 0x0600A44C ; mov r14,r15
L_0600A026:
    { const bool k = c.t; c.r[1] = ld32(c.r[14] + 40); if (k) { goto L_0600A058; } }  // 0600A026 bt/s 0x0600A058 ; mov.l @(40,r14),r1
    c.r[14] += 112; goto L_0600A44A;  // 0600A02A bra 0x0600A44A ; add #112,r14
L_0600A03C:
    c.r[13] = ld32(c.r[14] + 16);  // 0600A03C mov.l @(16,r14),r13
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 0600A03E mov.b @r13,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0600A040 extu.b r1,r1
    c.r[2] = c.r[1];  // 0600A042 mov r1,r2
    c.r[2] += 15;  // 0600A044 add #15,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0600A1ECu);  // 0600A046 mov.w 0x0600A1EC,r0
    c.r[13] = ld32(c.r[14] + 16);  // 0600A048 mov.l @(16,r14),r13
    c.r[2] &= c.r[0];  // 0600A04A and r0,r2
    st8(c.r[13], c.r[2]);  // 0600A04C mov.b r2,@r13
    c.r[1] = ld32(c.r[14] + 40);  // 0600A04E mov.l @(40,r14),r1
    c.r[1] += 1;  // 0600A050 add #1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0600A052 extu.b r1,r1
    st32(c.r[14] + 40, c.r[1]);  // 0600A054 mov.l r1,@(40,r14)
    c.r[1] = ld32(c.r[14] + 40);  // 0600A056 mov.l @(40,r14),r1
L_0600A058:
    c.r[1] += 1;  // 0600A058 add #1,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0600A05A extu.b r1,r1
    st32(c.r[14] + 40, c.r[1]);  // 0600A05C mov.l r1,@(40,r14)
L_0600A05E:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[12]); c.r[12] += 2;  // 0600A05E mov.w @r12+,r1
    c.r[0] = ld32(c.r[14] + 20);  // 0600A060 mov.l @(20,r14),r0
    c.r[1] = c.r[1] & 0xFFFFu;  // 0600A062 extu.w r1,r1
    c.t = c.r[0] >= c.r[1];  // 0600A064 cmp/hs r1,r0
    { const bool k = !c.t; st32(c.r[14] + 48, c.r[1]); if (k) { goto L_0600A06E; } }  // 0600A066 bf/s 0x0600A06E ; mov.l r1,@(48,r14)
    goto L_0600A448;  // 0600A06A bra 0x0600A448 ; nop
L_0600A06E:
    c.r[13] = ld32(c.r[14] + 24);  // 0600A06E mov.l @(24,r14),r13
    c.t = (c.r[13] & c.r[13]) == 0;  // 0600A070 tst r13,r13
    { const bool k = !c.t; c.r[1] = c.r[0]; if (k) { goto L_0600A07A; } }  // 0600A072 bf/s 0x0600A07A ; mov r0,r1
    goto L_0600A448;  // 0600A076 bra 0x0600A448 ; nop
L_0600A07A:
    c.r[1] <<= 2;  // 0600A07A shll2 r1
    c.r[1] <<= 2;  // 0600A07C shll2 r1
    c.r[0] = ld32(c.r[14] + 20);  // 0600A07E mov.l @(20,r14),r0
    c.r[12] += c.r[1];  // 0600A080 add r1,r12
    c.r[13] = ld32(c.r[14] + 12);  // 0600A082 mov.l @(12,r14),r13
    st32(c.r[14] + 60, c.r[0]);  // 0600A084 mov.l r0,@(60,r14)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0600A1EEu);  // 0600A086 mov.w 0x0600A1EE,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[13]);  // 0600A088 mov.w @r13,r1
    c.r[0] += c.r[14];  // 0600A08A add r14,r0
    c.r[1] = c.r[1] & 0xFFFFu;  // 0600A08C extu.w r1,r1
    c.r[13] = ld32(c.r[0]);  // 0600A08E mov.l @r0,r13
    c.r[1] <<= 2;  // 0600A090 shll2 r1
    c.r[1] += c.r[1];  // 0600A092 add r1,r1
    c.r[13] += c.r[1];  // 0600A094 add r1,r13
    st32(c.r[0], c.r[13]);  // 0600A096 mov.l r13,@r0
    c.r[0] = ld32(c.r[14] + 60);  // 0600A098 mov.l @(60,r14),r0
    c.r[13] = ld32(c.r[14] + 48);  // 0600A09A mov.l @(48,r14),r13
    c.t = (int32_t)c.r[0] >= (int32_t)c.r[13];  // 0600A09C cmp/ge r13,r0
    { const bool k = !c.t; c.r[9] = ld32(c.r[14] + 52); if (k) { goto L_0600A0A6; } }  // 0600A09E bf/s 0x0600A0A6 ; mov.l @(52,r14),r9
    goto L_0600A33A;  // 0600A0A2 bra 0x0600A33A ; nop
L_0600A0A6:
    c.r[0] = c.r[11];  // 0600A0A6 mov r11,r0
    c.r[0] &= 0x7u;  // 0600A0A8 and #7,r0
    c.r[13] = 0x40u;  // 0600A0AA mov #64,r13
    c.r[13] += c.r[14];  // 0600A0AC add r14,r13
    st32(c.r[13], c.r[0]);  // 0600A0AE mov.l r0,@r13
    c.r[0] = 0x40u;  // 0600A0B0 mov #64,r0
    c.r[0] += c.r[14];  // 0600A0B2 add r14,r0
    c.r[13] = ld32(c.r[0]);  // 0600A0B4 mov.l @r0,r13
    c.r[13] <<= 8;  // 0600A0B6 shll8 r13
    c.r[13] <<= 2;  // 0600A0B8 shll2 r13
    c.r[13] <<= 2;  // 0600A0BA shll2 r13
    st32(c.r[0], c.r[13]);  // 0600A0BC mov.l r13,@r0
    c.r[0] = (uint32_t)(int16_t)ld16(0x0600A1F0u);  // 0600A0BE mov.w 0x0600A1F0,r0
    c.r[13] = ld32(c.r[0] + c.r[14]);  // 0600A0C0 mov.l @(r0,r14),r13
    c.r[13] += 2;  // 0600A0C2 add #2,r13
    c.r[0] = 0x44u;  // 0600A0C4 mov #68,r0
    st32(c.r[0] + c.r[14], c.r[13]);  // 0600A0C6 mov.l r13,@(r0,r14)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0600A1F2u);  // 0600A0C8 mov.w 0x0600A1F2,r0
    c.r[13] = ld32(c.r[0] + c.r[14]);  // 0600A0CA mov.l @(r0,r14),r13
    c.r[13] += 8;  // 0600A0CC add #8,r13
    c.r[0] = 0x48u;  // 0600A0CE mov #72,r0
    st32(c.r[0] + c.r[14], c.r[13]);  // 0600A0D0 mov.l r13,@(r0,r14)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0600A1F2u);  // 0600A0D2 mov.w 0x0600A1F2,r0
    c.r[13] = ld32(c.r[0] + c.r[14]);  // 0600A0D4 mov.l @(r0,r14),r13
    c.r[13] += 6;  // 0600A0D6 add #6,r13
    c.r[0] = 0x4Cu;  // 0600A0D8 mov #76,r0
    st32(c.r[0] + c.r[14], c.r[13]);  // 0600A0DA mov.l r13,@(r0,r14)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0600A1F2u);  // 0600A0DC mov.w 0x0600A1F2,r0
    c.r[13] = ld32(c.r[0] + c.r[14]);  // 0600A0DE mov.l @(r0,r14),r13
    c.r[13] += 4;  // 0600A0E0 add #4,r13
    c.r[0] = 0x50u;  // 0600A0E2 mov #80,r0
    st32(c.r[0] + c.r[14], c.r[13]);  // 0600A0E4 mov.l r13,@(r0,r14)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0600A1F2u);  // 0600A0E6 mov.w 0x0600A1F2,r0
    c.r[13] = ld32(c.r[0] + c.r[14]);  // 0600A0E8 mov.l @(r0,r14),r13
    c.r[13] += 2;  // 0600A0EA add #2,r13
    c.r[0] = 0x54u;  // 0600A0EC mov #84,r0
    st32(c.r[0] + c.r[14], c.r[13]);  // 0600A0EE mov.l r13,@(r0,r14)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0600A1EEu);  // 0600A0F0 mov.w 0x0600A1EE,r0
    c.r[13] = ld32(c.r[0] + c.r[14]);  // 0600A0F2 mov.l @(r0,r14),r13
    c.r[13] += 2;  // 0600A0F4 add #2,r13
    c.r[0] = 0x58u;  // 0600A0F6 mov #88,r0
    st32(c.r[0] + c.r[14], c.r[13]);  // 0600A0F8 mov.l r13,@(r0,r14)
    c.r[13] = c.r[12];  // 0600A0FA mov r12,r13
    c.r[13] -= 2;  // 0600A0FC add #-2,r13
    c.r[0] = 0x5Cu;  // 0600A0FE mov #92,r0
    st32(c.r[0] + c.r[14], c.r[13]);  // 0600A100 mov.l r13,@(r0,r14)
    c.r[13] = c.r[12];  // 0600A102 mov r12,r13
    c.r[13] -= 4;  // 0600A104 add #-4,r13
    c.r[0] = 0x60u;  // 0600A106 mov #96,r0
    st32(c.r[0] + c.r[14], c.r[13]);  // 0600A108 mov.l r13,@(r0,r14)
    c.r[13] = c.r[12];  // 0600A10A mov r12,r13
    c.r[13] -= 9;  // 0600A10C add #-9,r13
    c.r[0] = 0x64u;  // 0600A10E mov #100,r0
    st32(c.r[0] + c.r[14], c.r[13]);  // 0600A110 mov.l r13,@(r0,r14)
    c.r[13] = c.r[12];  // 0600A112 mov r12,r13
    c.r[13] -= 6;  // 0600A114 add #-6,r13
    c.r[0] = 0x68u;  // 0600A116 mov #104,r0
    st32(c.r[0] + c.r[14], c.r[13]);  // 0600A118 mov.l r13,@(r0,r14)
    c.r[13] = c.r[12];  // 0600A11A mov r12,r13
    c.r[13] -= 8;  // 0600A11C add #-8,r13
    c.r[0] = 0x6Cu;  // 0600A11E mov #108,r0
    st32(c.r[0] + c.r[14], c.r[13]);  // 0600A120 mov.l r13,@(r0,r14)
L_0600A122:
    c.r[1] = ld32(c.r[14] + 20);  // 0600A122 mov.l @(20,r14),r1
    c.r[0] = ld32(c.r[14] + 24);  // 0600A124 mov.l @(24,r14),r0
    c.r[13] = ld32(c.r[14] + 60);  // 0600A126 mov.l @(60,r14),r13
    c.r[1] += c.r[0];  // 0600A128 add r0,r1
    c.t = (int32_t)c.r[13] >= (int32_t)c.r[1];  // 0600A12A cmp/ge r1,r13
    if (!c.t) { goto L_0600A132; }  // 0600A12C bf 0x0600A132
    goto L_0600A338;  // 0600A12E bra 0x0600A338 ; nop
L_0600A132:
    st32(c.r[14] + 44, c.r[12]);  // 0600A132 mov.l r12,@(44,r14)
    c.r[0] = 0x5Cu;  // 0600A134 mov #92,r0
    c.r[0] += c.r[14];  // 0600A136 add r14,r0
    c.r[13] = ld32(c.r[0]);  // 0600A138 mov.l @r0,r13
    c.r[13] += 16;  // 0600A13A add #16,r13
    st32(c.r[0], c.r[13]);  // 0600A13C mov.l r13,@r0
    c.r[0] = 0x60u;  // 0600A13E mov #96,r0
    c.r[0] += c.r[14];  // 0600A140 add r14,r0
    c.r[13] = ld32(c.r[0]);  // 0600A142 mov.l @r0,r13
    c.r[13] += 16;  // 0600A144 add #16,r13
    st32(c.r[0], c.r[13]);  // 0600A146 mov.l r13,@r0
    c.r[0] = 0x64u;  // 0600A148 mov #100,r0
    c.r[0] += c.r[14];  // 0600A14A add r14,r0
    c.r[13] = ld32(c.r[0]);  // 0600A14C mov.l @r0,r13
    c.r[13] += 16;  // 0600A14E add #16,r13
    st32(c.r[0], c.r[13]);  // 0600A150 mov.l r13,@r0
    c.r[0] = 0x68u;  // 0600A152 mov #104,r0
    c.r[0] += c.r[14];  // 0600A154 add r14,r0
    c.r[13] = ld32(c.r[0]);  // 0600A156 mov.l @r0,r13
    c.r[13] += 16;  // 0600A158 add #16,r13
    st32(c.r[0], c.r[13]);  // 0600A15A mov.l r13,@r0
    c.r[0] = 0x6Cu;  // 0600A15C mov #108,r0
    c.r[0] += c.r[14];  // 0600A15E add r14,r0
    c.r[13] = ld32(c.r[0]);  // 0600A160 mov.l @r0,r13
    c.r[7] = ld32(0x0600A1F8u);  // 0600A162 mov.l 0x0600A1F8,r7
    c.r[13] += 16;  // 0600A164 add #16,r13
    st32(c.r[0], c.r[13]);  // 0600A166 mov.l r13,@r0
    c.r[0] = ld32(c.r[14] + 40);  // 0600A168 mov.l @(40,r14),r0
    c.r[13] = 0x6Cu;  // 0600A16A mov #108,r13
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 0600A16C mov.b @(r0,r14),r1
    c.r[13] += c.r[14];  // 0600A16E add r14,r13
    c.r[0] = ld32(c.r[13]);  // 0600A170 mov.l @r13,r0
    c.r[1] = c.r[1] & 0xFFu;  // 0600A172 extu.b r1,r1
    c.r[13] = 0x6Cu;  // 0600A174 mov #108,r13
    c.r[13] += c.r[14];  // 0600A176 add r14,r13
    c.r[4] = (uint32_t)(int16_t)ld16(c.r[0]);  // 0600A178 mov.w @r0,r4
    c.r[13] = 0x6Cu;  // 0600A17A mov #108,r13
    c.r[4] += c.r[1];  // 0600A17C add r1,r4
    c.r[4] -= 1;  // 0600A17E add #-1,r4
    st16(c.r[0], c.r[4]);  // 0600A180 mov.w r4,@r0
    c.r[0] = ld32(c.r[14] + 40);  // 0600A182 mov.l @(40,r14),r0
    c.r[13] += c.r[14];  // 0600A184 add r14,r13
    c.r[6] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[14]);  // 0600A186 mov.b @(r0,r14),r6
    c.r[4] = c.r[4] & 0xFFFFu;  // 0600A188 extu.w r4,r4
    c.r[6] = c.r[6] & 0xFFu;  // 0600A18A extu.b r6,r6
    { const uint32_t x = c.r[7]; c.pr = 0x0600A190u; c.r[5] = c.r[6]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600A190u) return; }  // 0600A18C jsr @r7 ; mov r6,r5
    c.r[7] = c.r[0];  // 0600A190 mov r0,r7
    c.r[0] = ld32(c.r[13]);  // 0600A192 mov.l @r13,r0
    c.macl = c.r[7] * c.r[6];  // 0600A194 mul.l r6,r7
    c.r[13] = 0x68u;  // 0600A196 mov #104,r13
    c.r[13] += c.r[14];  // 0600A198 add r14,r13
    c.r[1] = c.macl;  // 0600A19A sts macl,r1
    st16(c.r[0], c.r[1]);  // 0600A19C mov.w r1,@r0
    c.r[0] = ld32(c.r[13]);  // 0600A19E mov.l @r13,r0
    c.r[10] = c.r[1] & 0xFFFFu;  // 0600A1A0 extu.w r1,r10
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0]);  // 0600A1A2 mov.w @r0,r1
    c.r[12] += 16;  // 0600A1A4 add #16,r12
    c.r[13] = ld32(c.r[14] + 12);  // 0600A1A6 mov.l @(12,r14),r13
    c.r[11] = c.r[1] & 0xFFFFu;  // 0600A1A8 extu.w r1,r11
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[13]);  // 0600A1AA mov.w @r13,r1
    c.r[8] = (uint32_t)(int16_t)ld16(0x0600A1F4u);  // 0600A1AC mov.w 0x0600A1F4,r8
    c.r[1] = c.r[1] & 0xFFFFu;  // 0600A1AE extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0600A1B0 tst r1,r1
    { const bool k = c.t; c.r[9] = ld32(c.r[14] + 32); if (k) { goto L_0600A210; } }  // 0600A1B2 bt/s 0x0600A210 ; mov.l @(32,r14),r9
    c.r[3] = c.r[1];  // 0600A1B6 mov r1,r3
    c.r[3] <<= 2;  // 0600A1B8 shll2 r3
    c.r[3] += c.r[3];  // 0600A1BA add r3,r3
    c.r[3] -= 8;  // 0600A1BC add #-8,r3
    c.r[9] += c.r[3];  // 0600A1BE add r3,r9
    c.r[1] = c.r[9];  // 0600A1C0 mov r9,r1
    c.r[0] = ld32(c.r[14] + 28);  // 0600A1C2 mov.l @(28,r14),r0
    c.r[1] += 4;  // 0600A1C4 add #4,r1
    c.r[8] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0600A1C6 mov.w @r1,r8
    c.r[13] = ld32(0x0600A1FCu);  // 0600A1C8 mov.l 0x0600A1FC,r13
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[9]);  // 0600A1CA mov.w @r9,r2
    c.r[3] += c.r[0];  // 0600A1CC add r0,r3
    c.r[8] = c.r[8] & 0xFFFFu;  // 0600A1CE extu.w r8,r8
    c.r[8] <<= 2;  // 0600A1D0 shll2 r8
    c.r[8] += c.r[8];  // 0600A1D2 add r8,r8
    c.r[1] = c.r[9];  // 0600A1D4 mov r9,r1
    c.r[1] += 2;  // 0600A1D6 add #2,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0600A1D8 mov.w @r1,r1
    c.r[3] += 2;  // 0600A1DA add #2,r3
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[3]);  // 0600A1DC mov.w @r3,r5
    c.macl = (c.r[2] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 0600A1DE mulu.w r1,r2
    c.r[5] = c.r[5] & 0xFFFFu;  // 0600A1E0 extu.w r5,r5
    c.r[4] = c.macl;  // 0600A1E2 sts macl,r4
    { const uint32_t x = c.r[13]; c.pr = 0x0600A1E8u; c.r[4] <<= 2; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600A1E8u) return; }  // 0600A1E4 jsr @r13 ; shll2 r4
    c.r[2] = c.r[0]; goto L_0600A200;  // 0600A1E8 bra 0x0600A200 ; mov r0,r2
L_0600A200:
    c.r[2] += 31;  // 0600A200 add #31,r2
    c.r[1] = ld32(0x0600A3F0u);  // 0600A202 mov.l 0x0600A3F0,r1
    c.r[2] &= c.r[1];  // 0600A204 and r1,r2
    c.r[8] += c.r[2];  // 0600A206 add r2,r8
    c.r[8] >>= 2;  // 0600A208 shlr2 r8
    c.t = c.r[8] & 1; c.r[8] >>= 1;  // 0600A20A shlr r8
    c.r[8] = c.r[8] & 0xFFFFu;  // 0600A20C extu.w r8,r8
    c.r[9] += 8;  // 0600A20E add #8,r9
L_0600A210:
    st16(c.r[9], c.r[10]);  // 0600A210 mov.w r10,@r9
    c.r[1] = c.r[9];  // 0600A212 mov r9,r1
    c.r[1] += 2;  // 0600A214 add #2,r1
    st16(c.r[1], c.r[11]);  // 0600A216 mov.w r11,@r1
    c.r[1] = c.r[9];  // 0600A218 mov r9,r1
    c.r[1] += 4;  // 0600A21A add #4,r1
    st16(c.r[1], c.r[8]);  // 0600A21C mov.w r8,@r1
    c.r[9] += 6;  // 0600A21E add #6,r9
    c.r[10] >>= 2;  // 0600A220 shlr2 r10
    c.t = c.r[10] & 1; c.r[10] >>= 1;  // 0600A222 shlr r10
    c.r[10] <<= 8;  // 0600A224 shll8 r10
    c.r[0] = ld32(c.r[14] + 12);  // 0600A226 mov.l @(12,r14),r0
    c.r[11] |= c.r[10];  // 0600A228 or r10,r11
    c.r[13] = ld32(c.r[14] + 44);  // 0600A22A mov.l @(44,r14),r13
    st16(c.r[9], c.r[11]);  // 0600A22C mov.w r11,@r9
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[0]);  // 0600A22E mov.w @r0,r3
    c.r[2] = ld32(c.r[13]);  // 0600A230 mov.l @r13,r2
    c.r[1] = c.r[14];  // 0600A232 mov r14,r1
    c.r[0] = ld32(c.r[14] + 40);  // 0600A234 mov.l @(40,r14),r0
    c.r[1] += 4;  // 0600A236 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0600A238 mov.b @(r0,r1),r1
    c.r[0] = ld32(c.r[14] + 36);  // 0600A23A mov.l @(36,r14),r0
    c.r[13] = ld32(c.r[14] + 56);  // 0600A23C mov.l @(56,r14),r13
    c.r[2] += c.r[0];  // 0600A23E add r0,r2
    c.r[2] += c.r[13];  // 0600A240 add r13,r2
    c.r[0] = (uint32_t)(int16_t)ld16(0x0600A3E4u);  // 0600A242 mov.w 0x0600A3E4,r0
    c.r[13] = ld32(c.r[0] + c.r[14]);  // 0600A244 mov.l @(r0,r14),r13
    st16(c.r[13], c.r[3]);  // 0600A246 mov.w r3,@r13
    c.r[0] = 0x58u;  // 0600A248 mov #88,r0
    c.r[13] = ld32(c.r[0] + c.r[14]);  // 0600A24A mov.l @(r0,r14),r13
    c.r[1] = c.r[1] & 0xFFu;  // 0600A24C extu.b r1,r1
    st16(c.r[13], c.r[1]);  // 0600A24E mov.w r1,@r13
    c.r[0] = 0x58u;  // 0600A250 mov #88,r0
    c.r[0] += c.r[14];  // 0600A252 add r14,r0
    c.r[13] = ld32(c.r[0]);  // 0600A254 mov.l @r0,r13
    c.r[13] += 8;  // 0600A256 add #8,r13
    st32(c.r[0], c.r[13]);  // 0600A258 mov.l r13,@r0
    c.r[0] = (uint32_t)(int16_t)ld16(0x0600A3E4u);  // 0600A25A mov.w 0x0600A3E4,r0
    c.r[13] = ld32(c.r[0] + c.r[14]);  // 0600A25C mov.l @(r0,r14),r13
    c.r[0] = ld32(c.r[14] + 12);  // 0600A25E mov.l @(12,r14),r0
    st32(c.r[13] + 4, c.r[2]);  // 0600A260 mov.l r2,@(4,r13)
    c.r[13] = ld32(c.r[14] + 16);  // 0600A262 mov.l @(16,r14),r13
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[0]);  // 0600A264 mov.w @r0,r3
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[13]);  // 0600A266 mov.b @r13,r2
    c.r[0] = 0x64u;  // 0600A268 mov #100,r0
    c.r[13] = ld32(c.r[0] + c.r[14]);  // 0600A26A mov.l @(r0,r14),r13
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 0600A26C mov.b @r13,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0600A26E extu.b r2,r2
    c.r[0] = ld32(c.r[14] + 40);  // 0600A270 mov.l @(40,r14),r0
    c.r[1] = c.r[1] & 0xFFu;  // 0600A272 extu.b r1,r1
    c.r[2] += c.r[1];  // 0600A274 add r1,r2
    c.r[1] = c.r[14];  // 0600A276 mov r14,r1
    c.r[1] += 8;  // 0600A278 add #8,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[1]);  // 0600A27A mov.b @(r0,r1),r1
    c.r[13] = (uint32_t)(int16_t)ld16(0x0600A3E6u);  // 0600A27C mov.w 0x0600A3E6,r13
    c.r[1] |= c.r[13];  // 0600A27E or r13,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0600A3E8u);  // 0600A280 mov.w 0x0600A3E8,r0
    c.r[13] = ld32(c.r[0] + c.r[14]);  // 0600A282 mov.l @(r0,r14),r13
    st16(c.r[13], c.r[3]);  // 0600A284 mov.w r3,@r13
    c.r[0] = 0x54u;  // 0600A286 mov #84,r0
    c.r[13] = ld32(c.r[0] + c.r[14]);  // 0600A288 mov.l @(r0,r14),r13
    c.r[1] = c.r[1] & 0xFFu;  // 0600A28A extu.b r1,r1
    st16(c.r[13], c.r[1]);  // 0600A28C mov.w r1,@r13
    c.r[0] = 0x54u;  // 0600A28E mov #84,r0
    c.r[0] += c.r[14];  // 0600A290 add r14,r0
    c.r[13] = ld32(c.r[0]);  // 0600A292 mov.l @r0,r13
    c.r[13] += 10;  // 0600A294 add #10,r13
    st32(c.r[0], c.r[13]);  // 0600A296 mov.l r13,@r0
    c.r[0] = 0x3Fu;  // 0600A298 mov #63,r0
    c.r[2] &= c.r[0];  // 0600A29A and r0,r2
    c.r[2] <<= 2;  // 0600A29C shll2 r2
    c.r[2] <<= 2;  // 0600A29E shll2 r2
    c.r[13] = 0x40u;  // 0600A2A0 mov #64,r13
    c.r[13] += c.r[14];  // 0600A2A2 add r14,r13
    c.r[0] = 0x50u;  // 0600A2A4 mov #80,r0
    c.r[13] = ld32(c.r[13]);  // 0600A2A6 mov.l @r13,r13
    c.r[0] += c.r[14];  // 0600A2A8 add r14,r0
    c.r[2] |= c.r[13];  // 0600A2AA or r13,r2
    c.r[13] = ld32(c.r[0]);  // 0600A2AC mov.l @r0,r13
    st16(c.r[13], c.r[2]);  // 0600A2AE mov.w r2,@r13
    c.r[0] = 0x50u;  // 0600A2B0 mov #80,r0
    c.r[0] += c.r[14];  // 0600A2B2 add r14,r0
    c.r[13] = ld32(c.r[0]);  // 0600A2B4 mov.l @r0,r13
    c.r[13] += 10;  // 0600A2B6 add #10,r13
    st32(c.r[0], c.r[13]);  // 0600A2B8 mov.l r13,@r0
    c.r[0] = 0x4Cu;  // 0600A2BA mov #76,r0
    c.r[13] = ld32(c.r[0] + c.r[14]);  // 0600A2BC mov.l @(r0,r14),r13
    c.r[1] = 0x0u;  // 0600A2BE mov #0,r1
    st16(c.r[13], c.r[1]);  // 0600A2C0 mov.w r1,@r13
    c.r[0] = 0x4Cu;  // 0600A2C2 mov #76,r0
    c.r[0] += c.r[14];  // 0600A2C4 add r14,r0
    c.r[13] = ld32(c.r[0]);  // 0600A2C6 mov.l @r0,r13
    c.r[13] += 10;  // 0600A2C8 add #10,r13
    st32(c.r[0], c.r[13]);  // 0600A2CA mov.l r13,@r0
    c.r[0] = 0x48u;  // 0600A2CC mov #72,r0
    c.r[13] = ld32(c.r[0] + c.r[14]);  // 0600A2CE mov.l @(r0,r14),r13
    c.r[1] = (uint32_t)(int16_t)ld16(0x0600A3EAu);  // 0600A2D0 mov.w 0x0600A3EA,r1
    st16(c.r[13], c.r[1]);  // 0600A2D2 mov.w r1,@r13
    c.r[0] = 0x48u;  // 0600A2D4 mov #72,r0
    c.r[0] += c.r[14];  // 0600A2D6 add r14,r0
    c.r[13] = ld32(c.r[0]);  // 0600A2D8 mov.l @r0,r13
    c.r[13] += 10;  // 0600A2DA add #10,r13
    st32(c.r[0], c.r[13]);  // 0600A2DC mov.l r13,@r0
    c.r[0] = 0x60u;  // 0600A2DE mov #96,r0
    c.r[13] = ld32(c.r[0] + c.r[14]);  // 0600A2E0 mov.l @(r0,r14),r13
    c.r[0] = (uint32_t)(int16_t)ld16(0x0600A3ECu);  // 0600A2E2 mov.w 0x0600A3EC,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[13]);  // 0600A2E4 mov.w @r13,r1
    c.r[13] = ld32(c.r[0] + c.r[14]);  // 0600A2E6 mov.l @(r0,r14),r13
    st16(c.r[13], c.r[1]);  // 0600A2E8 mov.w r1,@r13
    c.r[0] = 0x5Cu;  // 0600A2EA mov #92,r0
    c.r[13] = ld32(c.r[0] + c.r[14]);  // 0600A2EC mov.l @(r0,r14),r13
    c.r[0] = 0x44u;  // 0600A2EE mov #68,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[13]);  // 0600A2F0 mov.w @r13,r1
    c.r[13] = ld32(c.r[0] + c.r[14]);  // 0600A2F2 mov.l @(r0,r14),r13
    st16(c.r[13], c.r[1]);  // 0600A2F4 mov.w r1,@r13
    c.r[0] = 0x44u;  // 0600A2F6 mov #68,r0
    c.r[0] += c.r[14];  // 0600A2F8 add r14,r0
    c.r[13] = ld32(c.r[0]);  // 0600A2FA mov.l @r0,r13
    c.r[13] += 4;  // 0600A2FC add #4,r13
    st32(c.r[0], c.r[13]);  // 0600A2FE mov.l r13,@r0
    c.r[0] = ld32(c.r[14] + 60);  // 0600A300 mov.l @(60,r14),r0
    c.r[13] = ld32(c.r[14] + 12);  // 0600A302 mov.l @(12,r14),r13
    c.r[0] += 1;  // 0600A304 add #1,r0
    st32(c.r[14] + 60, c.r[0]);  // 0600A306 mov.l r0,@(60,r14)
    c.r[0] = (uint32_t)(int16_t)ld16(0x0600A3E4u);  // 0600A308 mov.w 0x0600A3E4,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[13]);  // 0600A30A mov.w @r13,r1
    c.r[0] += c.r[14];  // 0600A30C add r14,r0
    c.r[1] += 1;  // 0600A30E add #1,r1
    st16(c.r[13], c.r[1]);  // 0600A310 mov.w r1,@r13
    c.r[13] = ld32(c.r[0]);  // 0600A312 mov.l @r0,r13
    c.r[13] += 8;  // 0600A314 add #8,r13
    st32(c.r[0], c.r[13]);  // 0600A316 mov.l r13,@r0
    c.r[0] = (uint32_t)(int16_t)ld16(0x0600A3E8u);  // 0600A318 mov.w 0x0600A3E8,r0
    c.r[0] += c.r[14];  // 0600A31A add r14,r0
    c.r[13] = ld32(c.r[0]);  // 0600A31C mov.l @r0,r13
    c.r[13] += 10;  // 0600A31E add #10,r13
    st32(c.r[0], c.r[13]);  // 0600A320 mov.l r13,@r0
    c.r[0] = (uint32_t)(int16_t)ld16(0x0600A3ECu);  // 0600A322 mov.w 0x0600A3EC,r0
    c.r[0] += c.r[14];  // 0600A324 add r14,r0
    c.r[13] = ld32(c.r[0]);  // 0600A326 mov.l @r0,r13
    c.r[13] += 4;  // 0600A328 add #4,r13
    st32(c.r[0], c.r[13]);  // 0600A32A mov.l r13,@r0
    c.r[0] = ld32(c.r[14] + 60);  // 0600A32C mov.l @(60,r14),r0
    c.r[13] = ld32(c.r[14] + 48);  // 0600A32E mov.l @(48,r14),r13
    c.t = (int32_t)c.r[0] >= (int32_t)c.r[13];  // 0600A330 cmp/ge r13,r0
    if (c.t) { goto L_0600A338; }  // 0600A332 bt 0x0600A338
    SH2_POLL(c); goto L_0600A122;  // 0600A334 bra 0x0600A122 ; nop
L_0600A338:
    c.r[9] = ld32(c.r[14] + 52);  // 0600A338 mov.l @(52,r14),r9
L_0600A33A:
    c.r[0] = ld32(c.r[14] + 28);  // 0600A33A mov.l @(28,r14),r0
    c.r[10] = ld32(c.r[14] + 60);  // 0600A33C mov.l @(60,r14),r10
    c.r[13] = ld32(c.r[14] + 20);  // 0600A33E mov.l @(20,r14),r13
    c.r[9] <<= 2;  // 0600A340 shll2 r9
    c.r[9] += c.r[9];  // 0600A342 add r9,r9
    c.r[10] -= c.r[13];  // 0600A344 sub r13,r10
    c.t = (c.r[10] & c.r[10]) == 0;  // 0600A346 tst r10,r10
    { const bool k = c.t; c.r[9] += c.r[0]; if (k) { goto L_0600A3B0; } }  // 0600A348 bt/s 0x0600A3B0 ; add r0,r9
    c.r[2] = ld32(0x0600A3F4u);  // 0600A34C mov.l 0x0600A3F4,r2
    c.r[1] = 0x1u;  // 0600A34E mov #1,r1
    st8(c.r[2], c.r[1]);  // 0600A350 mov.b r1,@r2
    c.r[10] -= 1;  // 0600A352 add #-1,r10
    c.r[11] = c.r[9];  // 0600A354 mov r9,r11
    c.r[11] += 2;  // 0600A356 add #2,r11
L_0600A358:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]);  // 0600A358 mov.w @r9,r1
    c.r[0] = ld32(0x0600A3F8u);  // 0600A35A mov.l 0x0600A3F8,r0
    c.r[3] = ld32(c.r[0]);  // 0600A35C mov.l @r0,r3
    c.r[13] = ld32(0x0600A3FCu);  // 0600A35E mov.l 0x0600A3FC,r13
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[11]);  // 0600A360 mov.w @r11,r5
    c.r[2] = c.r[1] & 0xFFFFu;  // 0600A362 extu.w r1,r2
    c.r[2] <<= 2;  // 0600A364 shll2 r2
    c.r[2] += c.r[2];  // 0600A366 add r2,r2
    c.r[8] = c.r[3];  // 0600A368 mov r3,r8
    c.r[8] += c.r[2];  // 0600A36A add r2,r8
    c.r[1] = c.r[8];  // 0600A36C mov r8,r1
    c.r[0] = c.r[3];  // 0600A36E mov r3,r0
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[2]);  // 0600A370 mov.w @(r0,r2),r2
    c.r[1] += 2;  // 0600A372 add #2,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0600A374 mov.w @r1,r1
    c.r[11] += 8;  // 0600A376 add #8,r11
    c.macl = (c.r[2] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 0600A378 mulu.w r1,r2
    c.r[5] = c.r[5] & 0xFFFFu;  // 0600A37A extu.w r5,r5
    c.r[4] = c.macl;  // 0600A37C sts macl,r4
    { const uint32_t x = c.r[13]; c.pr = 0x0600A382u; c.r[4] <<= 2; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600A382u) return; }  // 0600A37E jsr @r13 ; shll2 r4
    c.r[2] = c.r[0];  // 0600A382 mov r0,r2
    c.r[8] += 4;  // 0600A384 add #4,r8
    c.r[1] = ld32(0x0600A400u);  // 0600A386 mov.l 0x0600A400,r1
    c.r[6] = c.r[2];  // 0600A388 mov r2,r6
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[8]);  // 0600A38A mov.w @r8,r5
    c.r[0] = ld32(0x0600A404u);  // 0600A38C mov.l 0x0600A404,r0
    c.r[4] = ld32(c.r[9] + 4);  // 0600A38E mov.l @(4,r9),r4
    c.r[5] = c.r[5] & 0xFFFFu;  // 0600A390 extu.w r5,r5
    c.r[5] <<= 2;  // 0600A392 shll2 r5
    c.r[5] += c.r[5];  // 0600A394 add r5,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0600A39Au; c.r[5] += c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600A39Au) return; }  // 0600A396 jsr @r0 ; add r1,r5
    c.r[9] += 8;  // 0600A39A add #8,r9
    c.r[1] = c.r[10];  // 0600A39C mov r10,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0600A39E tst r1,r1
    { const bool k = !c.t; c.r[10] -= 1; if (k) { SH2_POLL(c); goto L_0600A358; } }  // 0600A3A0 bf/s 0x0600A358 ; add #-1,r10
    c.r[1] = ld32(0x0600A408u);  // 0600A3A4 mov.l 0x0600A408,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0600A3AAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600A3AAu) return; }  // 0600A3A6 jsr @r1 ; nop
    c.r[2] = ld32(0x0600A3F4u);  // 0600A3AA mov.l 0x0600A3F4,r2
    c.r[1] = 0x0u;  // 0600A3AC mov #0,r1
    st8(c.r[2], c.r[1]);  // 0600A3AE mov.b r1,@r2
L_0600A3B0:
    c.r[13] = ld32(c.r[14] + 40);  // 0600A3B0 mov.l @(40,r14),r13
    c.t = (c.r[13] & c.r[13]) == 0;  // 0600A3B2 tst r13,r13
    { const bool k = c.t; c.r[10] = 0x1u; if (k) { goto L_0600A448; } }  // 0600A3B4 bt/s 0x0600A448 ; mov #1,r10
    c.r[0] = ld32(c.r[14] + 48);  // 0600A3B8 mov.l @(48,r14),r0
    c.r[13] = ld32(c.r[14] + 60);  // 0600A3BA mov.l @(60,r14),r13
    c.r[0] -= c.r[13];  // 0600A3BC sub r13,r0
    c.r[0] <<= 2;  // 0600A3BE shll2 r0
    c.r[0] <<= 2;  // 0600A3C0 shll2 r0
    st32(c.r[14] + 48, c.r[0]);  // 0600A3C2 mov.l r0,@(48,r14)
    c.r[12] += c.r[0];  // 0600A3C4 add r0,r12
    c.r[0] = (uint32_t)(int16_t)ld16(0x0600A3EEu);  // 0600A3C6 mov.w 0x0600A3EE,r0
    c.r[0] = ld32(c.r[0] + c.r[14]);  // 0600A3C8 mov.l @(r0,r14),r0
    c.t = (c.r[0] & c.r[0]) == 0;  // 0600A3CA tst r0,r0
    { const bool k = !c.t; c.r[9] = ld32(c.r[12]); c.r[12] += 4; if (k) { goto L_0600A42C; } }  // 0600A3CC bf/s 0x0600A42C ; mov.l @r12+,r9
    c.r[8] = ld32(0x0600A3F4u);  // 0600A3D0 mov.l 0x0600A3F4,r8
    c.r[1] = 0x1u;  // 0600A3D2 mov #1,r1
    st8(c.r[8], c.r[1]);  // 0600A3D4 mov.b r1,@r8
    c.r[6] = c.r[9];  // 0600A3D6 mov r9,r6
    c.r[6] += c.r[6];  // 0600A3D8 add r6,r6
    c.r[1] = ld32(0x0600A40Cu);  // 0600A3DA mov.l 0x0600A40C,r1
    c.r[13] = ld32(c.r[14] + 16);  // 0600A3DC mov.l @(16,r14),r13
    c.r[7] = 0x7u;  // 0600A3DE mov #7,r7
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[13]); goto L_0600A410;  // 0600A3E0 bra 0x0600A410 ; mov.b @r13,r5
L_0600A410:
    c.r[5] = c.r[5] & 0xFFu;  // 0600A410 extu.b r5,r5
    c.r[5] <<= 2;  // 0600A412 shll2 r5
    c.r[5] += c.r[5];  // 0600A414 add r5,r5
    c.r[5] <<= 2;  // 0600A416 shll2 r5
    c.r[5] += c.r[1];  // 0600A418 add r1,r5
    c.r[1] = ld32(0x0600A464u);  // 0600A41A mov.l 0x0600A464,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0600A420u; c.r[4] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600A420u) return; }  // 0600A41C jsr @r1 ; mov r12,r4
    c.r[1] = ld32(0x0600A468u);  // 0600A420 mov.l 0x0600A468,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0600A426u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600A426u) return; }  // 0600A422 jsr @r1 ; nop
    c.r[1] = 0x0u;  // 0600A426 mov #0,r1
    st8(c.r[8], c.r[1]); goto L_0600A43A;  // 0600A428 bra 0x0600A43A ; mov.b r1,@r8
L_0600A42C:
    c.r[6] = c.r[9];  // 0600A42C mov r9,r6
    c.r[6] += c.r[6];  // 0600A42E add r6,r6
    c.r[1] = ld32(0x0600A46Cu);  // 0600A430 mov.l 0x0600A46C,r1
    c.r[0] = (uint32_t)(int16_t)ld16(0x0600A460u);  // 0600A432 mov.w 0x0600A460,r0
    c.r[4] = ld32(c.r[0] + c.r[14]);  // 0600A434 mov.l @(r0,r14),r4
    { const uint32_t x = c.r[1]; c.pr = 0x0600A43Au; c.r[5] = c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600A43Au) return; }  // 0600A436 jsr @r1 ; mov r12,r5
L_0600A43A:
    c.r[13] = ld32(c.r[14] + 16);  // 0600A43A mov.l @(16,r14),r13
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[13]);  // 0600A43C mov.b @r13,r1
    c.r[9] >>= 2;  // 0600A43E shlr2 r9
    c.r[9] >>= 2;  // 0600A440 shlr2 r9
    c.r[9] += c.r[1];  // 0600A442 add r1,r9
    st8(c.r[13], c.r[9]);  // 0600A444 mov.b r9,@r13
    c.r[10] = 0x1u;  // 0600A446 mov #1,r10
L_0600A448:
    c.r[14] += 112;  // 0600A448 add #112,r14
L_0600A44A:
    c.r[15] = c.r[14];  // 0600A44A mov r14,r15
L_0600A44C:
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0600A44C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0600A44E mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0600A450 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0600A452 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0600A454 mov.l @r15+,r11
    c.r[0] = c.r[10];  // 0600A456 mov r10,r0
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0600A458 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0600A45A mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0600A45C rts ; mov.l @r15+,r8
}

void f_0600A470(SH2Context& c) {
    ran[55] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0600A470 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0600A472 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0600A474 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0600A476 mov r15,r14
    c.r[8] = ld32(0x0600A4F0u);  // 0600A478 mov.l 0x0600A4F0,r8
    c.r[4] = ld32(0x0600A4F4u);  // 0600A47A mov.l 0x0600A4F4,r4
    c.r[0] = ld32(0x0600A4F8u);  // 0600A47C mov.l 0x0600A4F8,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0600A482u; c.r[5] = 0x5u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600A482u) return; }  // 0600A47E jsr @r0 ; mov #5,r5
    c.r[7] = c.r[0];  // 0600A482 mov r0,r7
    st32(c.r[8], c.r[7]);  // 0600A484 mov.l r7,@r8
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0]); c.r[0] += 1;  // 0600A486 mov.b @r0+,r2
    c.r[3] = ld32(0x0600A4FCu);  // 0600A488 mov.l 0x0600A4FC,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0]);  // 0600A48A mov.b @r0,r1
    c.r[2] <<= 16;  // 0600A48C shll16 r2
    c.r[2] <<= 8;  // 0600A48E shll8 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0600A490 extu.b r1,r1
    c.r[1] <<= 16;  // 0600A492 shll16 r1
    c.r[2] |= c.r[1];  // 0600A494 or r1,r2
    c.r[1] = c.r[7];  // 0600A496 mov r7,r1
    c.r[1] += 2;  // 0600A498 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0600A49A mov.b @r1,r1
    c.r[7] += 3;  // 0600A49C add #3,r7
    c.r[1] = c.r[1] & 0xFFu;  // 0600A49E extu.b r1,r1
    c.r[1] <<= 8;  // 0600A4A0 shll8 r1
    c.r[2] |= c.r[1];  // 0600A4A2 or r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[7]);  // 0600A4A4 mov.b @r7,r1
    c.r[0] = ld32(0x0600A500u);  // 0600A4A6 mov.l 0x0600A500,r0
    c.r[1] = c.r[1] & 0xFFu;  // 0600A4A8 extu.b r1,r1
    c.r[2] |= c.r[1];  // 0600A4AA or r1,r2
    st32(c.r[3], c.r[2]);  // 0600A4AC mov.l r2,@r3
    c.r[3] = ld32(0x0600A504u);  // 0600A4AE mov.l 0x0600A504,r3
    c.r[1] = c.r[3];  // 0600A4B0 mov r3,r1
    c.r[1] += 66;  // 0600A4B2 add #66,r1
    c.r[2] = 0x0u;  // 0600A4B4 mov #0,r2
    st16(c.r[1], c.r[2]);  // 0600A4B6 mov.w r2,@r1
    c.r[1] = c.r[3];  // 0600A4B8 mov r3,r1
    c.r[1] += 70;  // 0600A4BA add #70,r1
    st16(c.r[1], c.r[2]);  // 0600A4BC mov.w r2,@r1
    c.r[3] += 64;  // 0600A4BE add #64,r3
    { const uint32_t x = c.r[0]; c.pr = 0x0600A4C4u; st16(c.r[3], c.r[2]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600A4C4u) return; }  // 0600A4C0 jsr @r0 ; mov.w r2,@r3
    c.r[1] = ld32(0x0600A508u);  // 0600A4C4 mov.l 0x0600A508,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0600A4CAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600A4CAu) return; }  // 0600A4C6 jsr @r1 ; nop
    c.r[4] = ld32(0x0600A50Cu);  // 0600A4CA mov.l 0x0600A50C,r4
    c.r[1] = ld32(0x0600A510u);  // 0600A4CC mov.l 0x0600A510,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0600A4D2u; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600A4D2u) return; }  // 0600A4CE jsr @r1 ; mov #0,r5
    c.r[6] = ld32(0x0600A514u);  // 0600A4D2 mov.l 0x0600A514,r6
    c.r[0] = ld32(0x0600A518u);  // 0600A4D4 mov.l 0x0600A518,r0
    c.r[5] = 0x18u;  // 0600A4D6 mov #24,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0600A4DCu; c.r[4] = 0xCu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600A4DCu) return; }  // 0600A4D8 jsr @r0 ; mov #12,r4
    c.r[4] = ld32(0x0600A51Cu);  // 0600A4DC mov.l 0x0600A51C,r4
    c.r[1] = ld32(0x0600A520u);  // 0600A4DE mov.l 0x0600A520,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0600A4E4u; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600A4E4u) return; }  // 0600A4E0 jsr @r1 ; mov #0,r5
    c.r[15] = c.r[14];  // 0600A4E4 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0600A4E6 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0600A4E8 mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0600A4EA rts ; mov.l @r15+,r8
}

void f_0600A558(SH2Context& c) {
    ran[56] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0600A558 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0600A55A mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0600A55C mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0600A55E mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0600A560 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0600A562 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0600A564 sts.l pr,@-r15
    c.r[3] = (uint32_t)(int16_t)ld16(0x0600A654u);  // 0600A566 mov.w 0x0600A654,r3
    c.r[15] += c.r[3];  // 0600A568 add r3,r15
    c.r[8] = ld32(0x0600A658u);  // 0600A56A mov.l 0x0600A658,r8
    c.r[11] = c.r[8];  // 0600A56C mov r8,r11
    c.r[11] += 66;  // 0600A56E add #66,r11
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[11]);  // 0600A570 mov.w @r11,r1
    c.r[0] = c.r[1] & 0xFFFFu;  // 0600A572 extu.w r1,r0
    c.t = c.r[0] == 0x8u;  // 0600A574 cmp/eq #8,r0
    { const bool k = !c.t; c.r[14] = c.r[15]; if (k) { goto L_0600A57E; } }  // 0600A576 bf/s 0x0600A57E ; mov r15,r14
    goto L_0600A90C;  // 0600A57A bra 0x0600A90C ; nop
L_0600A57E:
    c.r[1] = 0x8u;  // 0600A57E mov #8,r1
    c.t = (int32_t)c.r[0] > (int32_t)c.r[1];  // 0600A580 cmp/gt r1,r0
    { const bool k = c.t; c.t = c.r[0] == 0x20u; if (k) { goto L_0600A5A4; } }  // 0600A582 bt/s 0x0600A5A4 ; cmp/eq #32,r0
    c.t = c.r[0] == 0x1u;  // 0600A586 cmp/eq #1,r0
    { const bool k = c.t; c.r[10] = 0x1u; if (k) { goto L_0600A5D2; } }  // 0600A588 bt/s 0x0600A5D2 ; mov #1,r10
    c.t = (int32_t)c.r[0] > (int32_t)c.r[10];  // 0600A58C cmp/gt r10,r0
    { const bool k = c.t; c.t = c.r[0] == 0x2u; if (k) { goto L_0600A596; } }  // 0600A58E bt/s 0x0600A596 ; cmp/eq #2,r0
    goto L_0600A90C;  // 0600A592 bra 0x0600A90C ; nop
L_0600A596:
    { const bool k = c.t; c.t = c.r[0] == 0x4u; if (k) { goto L_0600A5EC; } }  // 0600A596 bt/s 0x0600A5EC ; cmp/eq #4,r0
    if (c.t) { goto L_0600A5A0; }  // 0600A59A bt 0x0600A5A0
    goto L_0600A90C;  // 0600A59C bra 0x0600A90C ; nop
L_0600A5A0:
    goto L_0600A814;  // 0600A5A0 bra 0x0600A814 ; nop
L_0600A5A4:
    { const bool k = !c.t; c.r[1] = 0x20u; if (k) { goto L_0600A5AC; } }  // 0600A5A4 bf/s 0x0600A5AC ; mov #32,r1
    goto L_0600A892;  // 0600A5A8 bra 0x0600A892 ; nop
L_0600A5AC:
    c.t = (int32_t)c.r[0] > (int32_t)c.r[1];  // 0600A5AC cmp/gt r1,r0
    { const bool k = c.t; c.t = c.r[0] == 0x40u; if (k) { goto L_0600A5BE; } }  // 0600A5AE bt/s 0x0600A5BE ; cmp/eq #64,r0
    c.t = c.r[0] == 0x10u;  // 0600A5B2 cmp/eq #16,r0
    if (c.t) { goto L_0600A5BA; }  // 0600A5B4 bt 0x0600A5BA
    goto L_0600A90C;  // 0600A5B6 bra 0x0600A90C ; nop
L_0600A5BA:
    goto L_0600A888;  // 0600A5BA bra 0x0600A888 ; nop
L_0600A5BE:
    if (!c.t) { goto L_0600A5C4; }  // 0600A5BE bf 0x0600A5C4
    goto L_0600A8E4;  // 0600A5C0 bra 0x0600A8E4 ; nop
L_0600A5C4:
    c.r[1] = (uint32_t)(int16_t)ld16(0x0600A656u);  // 0600A5C4 mov.w 0x0600A656,r1
    c.t = c.r[0] == c.r[1];  // 0600A5C6 cmp/eq r1,r0
    if (c.t) { goto L_0600A5CE; }  // 0600A5C8 bt 0x0600A5CE
    goto L_0600A90C;  // 0600A5CA bra 0x0600A90C ; nop
L_0600A5CE:
    goto L_0600A8F8;  // 0600A5CE bra 0x0600A8F8 ; nop
L_0600A5D2:
    c.r[1] = ld32(0x0600A65Cu);  // 0600A5D2 mov.l 0x0600A65C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0600A5D8u; c.r[4] = ld32(c.r[8]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600A5D8u) return; }  // 0600A5D4 jsr @r1 ; mov.l @r8,r4
    c.r[1] = ld32(0x0600A660u);  // 0600A5D8 mov.l 0x0600A660,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0600A5DEu; c.r[4] = ld32(c.r[8] + 4); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600A5DEu) return; }  // 0600A5DA jsr @r1 ; mov.l @(4,r8),r4
    c.r[1] = ld32(0x0600A664u);  // 0600A5DE mov.l 0x0600A664,r1
    c.r[4] = ld32(c.r[1]);  // 0600A5E0 mov.l @r1,r4
    c.r[1] = ld32(0x0600A668u);  // 0600A5E2 mov.l 0x0600A668,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0600A5E8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600A5E8u) return; }  // 0600A5E4 jsr @r1 ; nop
    c.r[1] = 0x0u; goto L_0600A90A;  // 0600A5E8 bra 0x0600A90A ; mov #0,r1
L_0600A5EC:
    c.r[0] = ld32(0x0600A66Cu);  // 0600A5EC mov.l 0x0600A66C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0600A5F2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600A5F2u) return; }  // 0600A5EE jsr @r0 ; nop
    c.r[1] = c.r[0];  // 0600A5F2 mov r0,r1
    c.r[9] = ld32(0x0600A664u);  // 0600A5F4 mov.l 0x0600A664,r9
    c.t = (c.r[1] & c.r[1]) == 0;  // 0600A5F6 tst r1,r1
    { const bool k = !c.t; st32(c.r[9], c.r[1]); if (k) { goto L_0600A612; } }  // 0600A5F8 bf/s 0x0600A612 ; mov.l r1,@r9
    c.r[0] = ld32(0x0600A670u);  // 0600A5FC mov.l 0x0600A670,r0
    c.r[5] = 0x9u;  // 0600A5FE mov #9,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0600A604u; c.r[4] = 0x14u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600A604u) return; }  // 0600A600 jsr @r0 ; mov #20,r4
    c.r[4] = ld32(0x0600A674u);  // 0600A604 mov.l 0x0600A674,r4
    c.r[1] = ld32(0x0600A678u);  // 0600A606 mov.l 0x0600A678,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0600A60Cu; c.r[5] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600A60Cu) return; }  // 0600A608 jsr @r1 ; mov r0,r5
    c.r[1] = 0x1u;  // 0600A60C mov #1,r1
    st16(c.r[11], c.r[1]); goto L_0600A8D0;  // 0600A60E bra 0x0600A8D0 ; mov.w r1,@r11
L_0600A612:
    c.r[0] = ld32(0x0600A67Cu);  // 0600A612 mov.l 0x0600A67C,r0
    c.r[6] = c.r[10];  // 0600A614 mov r10,r6
    c.r[5] = 0x0u;  // 0600A616 mov #0,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0600A61Cu; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600A61Cu) return; }  // 0600A618 jsr @r0 ; mov r1,r4
    c.r[0] = ld32(0x0600A680u);  // 0600A61C mov.l 0x0600A680,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0600A622u; c.r[4] = ld32(c.r[9]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600A622u) return; }  // 0600A61E jsr @r0 ; mov.l @r9,r4
    c.r[9] = c.r[8];  // 0600A622 mov r8,r9
    c.r[9] += 68;  // 0600A624 add #68,r9
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[9]);  // 0600A626 mov.w @r9,r2
    c.r[1] = 0xCu;  // 0600A628 mov #12,r1
    c.macl = (c.r[2] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 0600A62A mulu.w r1,r2
    c.r[0] = ld32(0x0600A684u);  // 0600A62C mov.l 0x0600A684,r0
    c.r[4] = c.macl;  // 0600A62E sts macl,r4
    c.r[1] = ld32(0x0600A688u);  // 0600A630 mov.l 0x0600A688,r1
    { const uint32_t x = c.r[0]; c.pr = 0x0600A636u; c.r[4] += c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600A636u) return; }  // 0600A632 jsr @r0 ; add r1,r4
    c.r[10] = c.r[0];  // 0600A636 mov r0,r10
    c.t = (c.r[10] & c.r[10]) == 0;  // 0600A638 tst r10,r10
    { const bool k = !c.t; st32(c.r[8] + 4, c.r[10]); if (k) { goto L_0600A690; } }  // 0600A63A bf/s 0x0600A690 ; mov.l r10,@(4,r8)
    c.r[0] = ld32(0x0600A670u);  // 0600A63E mov.l 0x0600A670,r0
    c.r[5] = 0x9u;  // 0600A640 mov #9,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0600A646u; c.r[4] = 0x14u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600A646u) return; }  // 0600A642 jsr @r0 ; mov #20,r4
    c.r[4] = ld32(0x0600A68Cu);  // 0600A646 mov.l 0x0600A68C,r4
    c.r[1] = ld32(0x0600A678u);  // 0600A648 mov.l 0x0600A678,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0600A64Eu; c.r[5] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600A64Eu) return; }  // 0600A64A jsr @r1 ; mov r0,r5
    c.r[1] = 0x1u;  // 0600A64E mov #1,r1
    st16(c.r[11], c.r[1]); goto L_0600A8D0;  // 0600A650 bra 0x0600A8D0 ; mov.w r1,@r11
L_0600A690:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[9]);  // 0600A690 mov.w @r9,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0600A692 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0600A694 tst r1,r1
    { const bool k = c.t; c.r[1] = c.r[8]; if (k) { goto L_0600A74E; } }  // 0600A696 bt/s 0x0600A74E ; mov r8,r1
    c.r[1] += 70;  // 0600A69A add #70,r1
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0600A69C mov.w @r1,r0
    c.r[3] = ld32(0x0600A834u);  // 0600A69E mov.l 0x0600A834,r3
    c.r[2] = c.r[0] & 0xFFFFu;  // 0600A6A0 extu.w r0,r2
    c.r[2] >>= 2;  // 0600A6A2 shlr2 r2
    c.r[2] >>= 2;  // 0600A6A4 shlr2 r2
    c.t = c.r[2] & 1; c.r[2] >>= 1;  // 0600A6A6 shlr r2
    c.r[2] >>= 2;  // 0600A6A8 shlr2 r2
    c.r[1] = 0x3u;  // 0600A6AA mov #3,r1
    c.macl = (c.r[2] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 0600A6AC mulu.w r1,r2
    c.r[3] = ld32(c.r[3]);  // 0600A6AE mov.l @r3,r3
    c.r[6] = c.macl;  // 0600A6B0 sts macl,r6
    c.r[6] += c.r[3];  // 0600A6B2 add r3,r6
    c.r[1] = c.r[6];  // 0600A6B4 mov r6,r1
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0600A6B6 mov.b @r1+,r2
    c.r[6] += 2;  // 0600A6B8 add #2,r6
    c.r[2] = c.r[2] & 0xFFu;  // 0600A6BA extu.b r2,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0600A6BC mov.b @r1,r1
    c.r[2] <<= 16;  // 0600A6BE shll16 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0600A6C0 extu.b r1,r1
    c.r[1] <<= 8;  // 0600A6C2 shll8 r1
    c.r[2] |= c.r[1];  // 0600A6C4 or r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0600A6C6 mov.b @r6,r1
    c.r[0] &= 0x7Fu;  // 0600A6C8 and #127,r0
    c.r[1] = c.r[1] & 0xFFu;  // 0600A6CA extu.b r1,r1
    c.r[2] |= c.r[1];  // 0600A6CC or r1,r2
    c.r[1] = 0x6u;  // 0600A6CE mov #6,r1
    c.macl = (c.r[0] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 0600A6D0 mulu.w r1,r0
    c.r[2] += c.r[3];  // 0600A6D2 add r3,r2
    c.r[1] = c.macl;  // 0600A6D4 sts macl,r1
    c.r[2] += c.r[1];  // 0600A6D6 add r1,r2
    st32(c.r[8] + 60, c.r[2]);  // 0600A6D8 mov.l r2,@(60,r8)
    c.r[1] = c.r[2];  // 0600A6DA mov r2,r1
    c.r[6] = c.r[2];  // 0600A6DC mov r2,r6
    c.r[5] = (uint32_t)(int8_t)ld8(c.r[1]); c.r[1] += 1;  // 0600A6DE mov.b @r1+,r5
    c.r[6] += 3;  // 0600A6E0 add #3,r6
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[6]);  // 0600A6E2 mov.b @r6,r3
    c.r[5] = c.r[5] & 0xFFu;  // 0600A6E4 extu.b r5,r5
    c.r[5] <<= 16;  // 0600A6E6 shll16 r5
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0600A6E8 mov.b @r1,r1
    c.r[3] = c.r[3] & 0xFFu;  // 0600A6EA extu.b r3,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0600A6EC extu.b r1,r1
    c.r[1] <<= 8;  // 0600A6EE shll8 r1
    c.r[5] |= c.r[1];  // 0600A6F0 or r1,r5
    c.r[1] = c.r[2];  // 0600A6F2 mov r2,r1
    c.r[1] += 2;  // 0600A6F4 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0600A6F6 mov.b @r1,r1
    c.r[3] <<= 16;  // 0600A6F8 shll16 r3
    c.r[1] = c.r[1] & 0xFFu;  // 0600A6FA extu.b r1,r1
    c.r[5] |= c.r[1];  // 0600A6FC or r1,r5
    c.r[1] = c.r[2];  // 0600A6FE mov r2,r1
    c.r[1] += 4;  // 0600A700 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0600A702 mov.b @r1,r1
    c.r[2] += 5;  // 0600A704 add #5,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0600A706 extu.b r1,r1
    c.r[1] <<= 8;  // 0600A708 shll8 r1
    c.r[3] |= c.r[1];  // 0600A70A or r1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0600A70C mov.b @r2,r1
    c.r[1] = c.r[1] & 0xFFu;  // 0600A70E extu.b r1,r1
    c.r[3] |= c.r[1];  // 0600A710 or r1,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0600A826u);  // 0600A712 mov.w 0x0600A826,r1
    c.macl = c.r[3] * c.r[1];  // 0600A714 mul.l r1,r3
    c.r[7] = c.r[8];  // 0600A716 mov r8,r7
    c.r[7] += 72;  // 0600A718 add #72,r7
    c.r[12] = c.macl;  // 0600A71A sts macl,r12
    c.r[2] = c.macl;  // 0600A71C sts macl,r2
    c.r[2] += 1;  // 0600A71E add #1,r2
    c.r[2] <<= 2;  // 0600A720 shll2 r2
    c.r[2] <<= 2;  // 0600A722 shll2 r2
    c.r[2] <<= 2;  // 0600A724 shll2 r2
    c.r[1] = ld32(0x0600A838u);  // 0600A726 mov.l 0x0600A838,r1
    { uint64_t p = (uint64_t)((int64_t)(int32_t)c.r[2] * (int32_t)c.r[1]); c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 0600A728 dmuls.l r1,r2
    c.r[8] += 76;  // 0600A72A add #76,r8
    st32(c.r[7], c.r[12]);  // 0600A72C mov.l r12,@r7
    c.r[4] = c.mach;  // 0600A72E sts mach,r4
    c.r[1] = ld32(0x0600A83Cu);  // 0600A730 mov.l 0x0600A83C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0600A736u; c.r[4] += c.r[2]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600A736u) return; }  // 0600A732 jsr @r1 ; add r2,r4
    c.t = c.r[2] >> 31; c.r[2] <<= 1;  // 0600A736 shll r2
    { uint32_t a = c.r[2], b = c.r[2], t = c.t; c.r[2] = a - b - t; c.t = (uint64_t)a < (uint64_t)b + t; }  // 0600A738 subc r2,r2
    c.r[4] -= c.r[2];  // 0600A73A sub r2,r4
    st32(c.r[8], c.r[4]);  // 0600A73C mov.l r4,@r8
    c.r[1] = ld32(0x0600A840u);  // 0600A73E mov.l 0x0600A840,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0600A744u; c.r[4] = c.r[10]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600A744u) return; }  // 0600A740 jsr @r1 ; mov r10,r4
    c.r[0] = ld32(0x0600A844u);  // 0600A744 mov.l 0x0600A844,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0600A74Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600A74Au) return; }  // 0600A746 jsr @r0 ; nop
    goto L_0600A75A;  // 0600A74A bra 0x0600A75A ; nop
L_0600A74E:
    c.r[1] += 72;  // 0600A74E add #72,r1
    c.r[2] = ld32(0x0600A848u);  // 0600A750 mov.l 0x0600A848,r2
    st32(c.r[1], c.r[2]);  // 0600A752 mov.l r2,@r1
    c.r[8] += 76;  // 0600A754 add #76,r8
    c.r[1] = (uint32_t)(int16_t)ld16(0x0600A828u);  // 0600A756 mov.w 0x0600A828,r1
    st32(c.r[8], c.r[1]);  // 0600A758 mov.l r1,@r8
L_0600A75A:
    c.r[8] = ld32(0x0600A84Cu);  // 0600A75A mov.l 0x0600A84C,r8
    c.r[1] = ld32(0x0600A850u);  // 0600A75C mov.l 0x0600A850,r1
    st32(c.r[8], c.r[1]);  // 0600A75E mov.l r1,@r8
    c.r[1] = ld32(0x0600A854u);  // 0600A760 mov.l 0x0600A854,r1
    st32(c.r[8] + 4, c.r[1]);  // 0600A762 mov.l r1,@(4,r8)
    c.r[1] = (uint32_t)(int16_t)ld16(0x0600A82Au);  // 0600A764 mov.w 0x0600A82A,r1
    st32(c.r[8] + 8, c.r[1]);  // 0600A766 mov.l r1,@(8,r8)
    c.r[1] = ld32(0x0600A858u);  // 0600A768 mov.l 0x0600A858,r1
    st32(c.r[8] + 12, c.r[1]);  // 0600A76A mov.l r1,@(12,r8)
    c.r[1] = (uint32_t)(int16_t)ld16(0x0600A82Cu);  // 0600A76C mov.w 0x0600A82C,r1
    st32(c.r[8] + 16, c.r[1]);  // 0600A76E mov.l r1,@(16,r8)
    c.r[9] = c.r[8];  // 0600A770 mov r8,r9
    c.r[9] -= 8;  // 0600A772 add #-8,r9
    c.r[5] = ld32(c.r[9] + 4);  // 0600A774 mov.l @(4,r9),r5
    c.r[0] = ld32(0x0600A85Cu);  // 0600A776 mov.l 0x0600A85C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0600A77Cu; c.r[4] = c.r[8]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600A77Cu) return; }  // 0600A778 jsr @r0 ; mov r8,r4
    c.t = (c.r[0] & c.r[0]) == 0;  // 0600A77C tst r0,r0
    { const bool k = !c.t; st32(c.r[9], c.r[0]); if (k) { goto L_0600A79C; } }  // 0600A77E bf/s 0x0600A79C ; mov.l r0,@r9
    c.r[0] = ld32(0x0600A860u);  // 0600A782 mov.l 0x0600A860,r0
    c.r[5] = 0x9u;  // 0600A784 mov #9,r5
    { const uint32_t x = c.r[0]; c.pr = 0x0600A78Au; c.r[4] = 0x14u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600A78Au) return; }  // 0600A786 jsr @r0 ; mov #20,r4
    c.r[4] = ld32(0x0600A864u);  // 0600A78A mov.l 0x0600A864,r4
    c.r[1] = ld32(0x0600A868u);  // 0600A78C mov.l 0x0600A868,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0600A792u; c.r[5] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600A792u) return; }  // 0600A78E jsr @r1 ; mov r0,r5
    c.r[8] += 58;  // 0600A792 add #58,r8
    c.r[1] = 0x1u;  // 0600A794 mov #1,r1
    st16(c.r[8], c.r[1]);  // 0600A796 mov.w r1,@r8
    c.r[4] = ld32(c.r[9]); goto L_0600A8D2;  // 0600A798 bra 0x0600A8D2 ; mov.l @r9,r4
L_0600A79C:
    c.r[5] = c.r[8];  // 0600A79C mov r8,r5
    c.r[5] += 20;  // 0600A79E add #20,r5
    c.r[10] = 0x1u;  // 0600A7A0 mov #1,r10
    st32(c.r[9] + 28, c.r[10]);  // 0600A7A2 mov.l r10,@(28,r9)
    c.r[1] = 0x6u;  // 0600A7A4 mov #6,r1
    st32(c.r[5] + 4, c.r[1]);  // 0600A7A6 mov.l r1,@(4,r5)
    c.r[1] = ld32(0x0600A86Cu);  // 0600A7A8 mov.l 0x0600A86C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0600A7AEu; c.r[4] = c.r[0]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600A7AEu) return; }  // 0600A7AA jsr @r1 ; mov r0,r4
    c.r[1] = ld32(0x0600A870u);  // 0600A7AE mov.l 0x0600A870,r1
    c.r[4] = ld32(c.r[9]);  // 0600A7B0 mov.l @r9,r4
    { const uint32_t x = c.r[1]; c.pr = 0x0600A7B6u; c.r[5] = 0xAu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600A7B6u) return; }  // 0600A7B2 jsr @r1 ; mov #10,r5
    c.r[5] = (uint32_t)(int16_t)ld16(0x0600A82Eu);  // 0600A7B6 mov.w 0x0600A82E,r5
    c.r[1] = ld32(0x0600A874u);  // 0600A7B8 mov.l 0x0600A874,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0600A7BEu; c.r[4] = ld32(c.r[9]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600A7BEu) return; }  // 0600A7BA jsr @r1 ; mov.l @r9,r4
    c.r[1] = c.r[8];  // 0600A7BE mov r8,r1
    c.r[1] += 60;  // 0600A7C0 add #60,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0600A7C2 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0600A7C4 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0600A7C6 tst r1,r1
    { const bool k = c.t; c.r[1] = c.r[8]; if (k) { goto L_0600A7F8; } }  // 0600A7C8 bt/s 0x0600A7F8 ; mov r8,r1
    c.r[1] += 56;  // 0600A7CC add #56,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0600A7CE mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0600A7D0 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0600A7D2 tst r1,r1
    { const bool k = c.t; c.r[4] = 0x0u; if (k) { goto L_0600A7EA; } }  // 0600A7D4 bt/s 0x0600A7EA ; mov #0,r4
    c.r[8] += 62;  // 0600A7D8 add #62,r8
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[8]);  // 0600A7DA mov.w @r8,r5
    c.r[0] = ld32(0x0600A878u);  // 0600A7DC mov.l 0x0600A878,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0600A7E2u; c.r[5] = c.r[5] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600A7E2u) return; }  // 0600A7DE jsr @r0 ; extu.w r5,r5
    c.r[5] = c.r[0] & 0xFFu;  // 0600A7E2 extu.b r0,r5
    c.r[1] = ld32(0x0600A87Cu);  // 0600A7E4 mov.l 0x0600A87C,r1
    c.r[6] = c.r[10]; goto L_0600A7FE;  // 0600A7E6 bra 0x0600A7FE ; mov r10,r6
L_0600A7EA:
    c.r[8] += 62;  // 0600A7EA add #62,r8
    c.r[5] = (uint32_t)(int16_t)ld16(c.r[8]);  // 0600A7EC mov.w @r8,r5
    c.r[0] = ld32(0x0600A878u);  // 0600A7EE mov.l 0x0600A878,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0600A7F4u; c.r[5] = c.r[5] & 0xFFFFu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600A7F4u) return; }  // 0600A7F0 jsr @r0 ; extu.w r5,r5
    c.r[5] = c.r[0] & 0xFFu; goto L_0600A7FA;  // 0600A7F4 bra 0x0600A7FA ; extu.b r0,r5
L_0600A7F8:
    c.r[5] = (uint32_t)(int16_t)ld16(0x0600A830u);  // 0600A7F8 mov.w 0x0600A830,r5
L_0600A7FA:
    c.r[1] = ld32(0x0600A87Cu);  // 0600A7FA mov.l 0x0600A87C,r1
    c.r[6] = 0x0u;  // 0600A7FC mov #0,r6
L_0600A7FE:
    { const uint32_t x = c.r[1]; c.pr = 0x0600A802u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600A802u) return; }  // 0600A7FE jsr @r1 ; mov r9,r4
    c.r[8] = ld32(0x0600A880u);  // 0600A802 mov.l 0x0600A880,r8
    c.r[4] = ld32(c.r[8]);  // 0600A804 mov.l @r8,r4
    c.r[1] = ld32(0x0600A884u);  // 0600A806 mov.l 0x0600A884,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0600A80Cu; c.r[5] = 0x2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600A80Cu) return; }  // 0600A808 jsr @r1 ; mov #2,r5
    c.r[8] += 66;  // 0600A80C add #66,r8
    c.r[1] = 0x4u;  // 0600A80E mov #4,r1
    st16(c.r[8], c.r[1]); goto L_0600A90C;  // 0600A810 bra 0x0600A90C ; mov.w r1,@r8
L_0600A814:
    c.r[0] = ld32(0x0600A844u);  // 0600A814 mov.l 0x0600A844,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0600A81Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600A81Au) return; }  // 0600A816 jsr @r0 ; nop
    c.r[1] = (uint32_t)(int16_t)ld16(0x0600A832u);  // 0600A81A mov.w 0x0600A832,r1
    c.t = c.r[0] == c.r[1];  // 0600A81C cmp/eq r1,r0
    { const bool k = c.t; c.r[1] = 0x8u; if (k) { goto L_0600A90C; } }  // 0600A81E bt/s 0x0600A90C ; mov #8,r1
    st16(c.r[11], c.r[1]); goto L_0600A90C;  // 0600A822 bra 0x0600A90C ; mov.w r1,@r11
L_0600A888:
    c.r[1] = ld32(0x0600A924u);  // 0600A888 mov.l 0x0600A924,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0600A88Eu; c.r[4] = ld32(c.r[8]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600A88Eu) return; }  // 0600A88A jsr @r1 ; mov.l @r8,r4
    c.r[1] = 0x20u;  // 0600A88E mov #32,r1
    st16(c.r[11], c.r[1]);  // 0600A890 mov.w r1,@r11
L_0600A892:
    c.r[0] = ld32(0x0600A928u);  // 0600A892 mov.l 0x0600A928,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0600A898u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600A898u) return; }  // 0600A894 jsr @r0 ; nop
    c.r[8] = ld32(0x0600A92Cu);  // 0600A898 mov.l 0x0600A92C,r8
    c.r[1] = ld32(0x0600A930u);  // 0600A89A mov.l 0x0600A930,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0600A8A0u; c.r[4] = ld32(c.r[8]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600A8A0u) return; }  // 0600A89C jsr @r1 ; mov.l @r8,r4
    c.r[9] = c.r[8];  // 0600A8A0 mov r8,r9
    c.r[9] += 76;  // 0600A8A2 add #76,r9
    c.r[1] = ld32(c.r[9]);  // 0600A8A4 mov.l @r9,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0600A8A6 tst r1,r1
    { const bool k = c.t; c.r[2] = c.r[8]; if (k) { goto L_0600A8CA; } }  // 0600A8A8 bt/s 0x0600A8CA ; mov r8,r2
    c.r[0] = ld32(0x0600A934u);  // 0600A8AC mov.l 0x0600A934,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0600A8B2u; c.r[4] = ld32(c.r[8]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600A8B2u) return; }  // 0600A8AE jsr @r0 ; mov.l @r8,r4
    c.t = c.r[0] == 0x5u;  // 0600A8B2 cmp/eq #5,r0
    { const bool k = c.t; c.r[2] = c.r[8]; if (k) { goto L_0600A8CA; } }  // 0600A8B4 bt/s 0x0600A8CA ; mov r8,r2
    c.r[0] = ld32(0x0600A938u);  // 0600A8B8 mov.l 0x0600A938,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0600A8BEu; c.r[4] = ld32(c.r[8]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600A8BEu) return; }  // 0600A8BA jsr @r0 ; mov.l @r8,r4
    c.r[1] = c.r[8];  // 0600A8BE mov r8,r1
    c.r[1] += 72;  // 0600A8C0 add #72,r1
    c.r[1] = ld32(c.r[1]);  // 0600A8C2 mov.l @r1,r1
    c.t = (int32_t)c.r[0] > (int32_t)c.r[1];  // 0600A8C4 cmp/gt r1,r0
    { const bool k = !c.t; c.r[2] = c.r[8]; if (k) { goto L_0600A8DC; } }  // 0600A8C6 bf/s 0x0600A8DC ; mov r8,r2
L_0600A8CA:
    c.r[2] += 66;  // 0600A8CA add #66,r2
    c.r[1] = 0x1u;  // 0600A8CC mov #1,r1
    st16(c.r[2], c.r[1]);  // 0600A8CE mov.w r1,@r2
L_0600A8D0:
    c.r[4] = ld32(c.r[8]);  // 0600A8D0 mov.l @r8,r4
L_0600A8D2:
    c.r[1] = ld32(0x0600A93Cu);  // 0600A8D2 mov.l 0x0600A93C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0600A8D8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600A8D8u) return; }  // 0600A8D4 jsr @r1 ; nop
    goto L_0600A90C;  // 0600A8D8 bra 0x0600A90C ; nop
L_0600A8DC:
    c.r[1] = ld32(c.r[9]);  // 0600A8DC mov.l @r9,r1
    c.r[1] -= 1;  // 0600A8DE add #-1,r1
    st32(c.r[9], c.r[1]); goto L_0600A90C;  // 0600A8E0 bra 0x0600A90C ; mov.l r1,@r9
L_0600A8E4:
    c.r[5] = (uint32_t)(int16_t)ld16(0x0600A922u);  // 0600A8E4 mov.w 0x0600A922,r5
    c.r[1] = ld32(0x0600A940u);  // 0600A8E6 mov.l 0x0600A940,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0600A8ECu; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600A8ECu) return; }  // 0600A8E8 jsr @r1 ; mov r14,r4
    c.r[4] = ld32(c.r[8]);  // 0600A8EC mov.l @r8,r4
    c.r[1] = ld32(0x0600A944u);  // 0600A8EE mov.l 0x0600A944,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0600A8F4u; c.r[5] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600A8F4u) return; }  // 0600A8F0 jsr @r1 ; mov #0,r5
    goto L_0600A90C;  // 0600A8F4 bra 0x0600A90C ; nop
L_0600A8F8:
    c.r[5] = (uint32_t)(int16_t)ld16(0x0600A922u);  // 0600A8F8 mov.w 0x0600A922,r5
    c.r[1] = ld32(0x0600A940u);  // 0600A8FA mov.l 0x0600A940,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0600A900u; c.r[4] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600A900u) return; }  // 0600A8FC jsr @r1 ; mov r14,r4
    c.r[4] = ld32(c.r[8]);  // 0600A900 mov.l @r8,r4
    c.r[1] = ld32(0x0600A944u);  // 0600A902 mov.l 0x0600A944,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0600A908u; c.r[5] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600A908u) return; }  // 0600A904 jsr @r1 ; mov #1,r5
    c.r[1] = 0x20u;  // 0600A908 mov #32,r1
L_0600A90A:
    st16(c.r[11], c.r[1]);  // 0600A90A mov.w r1,@r11
L_0600A90C:
    c.r[3] = ld32(0x0600A948u);  // 0600A90C mov.l 0x0600A948,r3
    c.r[14] += c.r[3];  // 0600A90E add r3,r14
    c.r[15] = c.r[14];  // 0600A910 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0600A912 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0600A914 mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0600A916 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0600A918 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0600A91A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0600A91C mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0600A91E rts ; mov.l @r15+,r8
}

void f_0600A94C(SH2Context& c) {
    ran[57] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0600A94C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0600A94E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0600A950 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0600A952 mov r15,r14
    c.r[8] = ld32(0x0600A980u);  // 0600A954 mov.l 0x0600A980,r8
    c.r[1] = ld32(0x0600A984u);  // 0600A956 mov.l 0x0600A984,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0600A95Cu; c.r[4] = ld32(c.r[8]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600A95Cu) return; }  // 0600A958 jsr @r1 ; mov.l @r8,r4
    c.r[1] = ld32(0x0600A988u);  // 0600A95C mov.l 0x0600A988,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0600A962u; c.r[4] = ld32(c.r[8]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600A962u) return; }  // 0600A95E jsr @r1 ; mov.l @r8,r4
    c.r[1] = ld32(0x0600A98Cu);  // 0600A962 mov.l 0x0600A98C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0600A968u; c.r[4] = ld32(c.r[8] + 4); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600A968u) return; }  // 0600A964 jsr @r1 ; mov.l @(4,r8),r4
    c.r[1] = ld32(0x0600A990u);  // 0600A968 mov.l 0x0600A990,r1
    c.r[4] = ld32(c.r[1]);  // 0600A96A mov.l @r1,r4
    c.r[1] = ld32(0x0600A994u);  // 0600A96C mov.l 0x0600A994,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0600A972u; c.r[8] += 66; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600A972u) return; }  // 0600A96E jsr @r1 ; add #66,r8
    c.r[1] = 0x0u;  // 0600A972 mov #0,r1
    st16(c.r[8], c.r[1]);  // 0600A974 mov.w r1,@r8
    c.r[15] = c.r[14];  // 0600A976 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0600A978 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0600A97A mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0600A97C rts ; mov.l @r15+,r8
}

void f_0600A998(SH2Context& c) {
    ran[58] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0600A998 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0600A99A sts.l pr,@-r15
    c.r[15] -= 12;  // 0600A99C add #-12,r15
    c.r[0] = ld32(0x0600A9E4u);  // 0600A99E mov.l 0x0600A9E4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0600A9A4u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600A9A4u) return; }  // 0600A9A0 jsr @r0 ; mov r15,r14
    c.r[5] = c.r[0];  // 0600A9A4 mov r0,r5
    c.r[3] = c.r[14];  // 0600A9A6 mov r14,r3
    c.r[3] += 8;  // 0600A9A8 add #8,r3
    c.r[2] = c.r[14];  // 0600A9AA mov r14,r2
    c.r[2] += 10;  // 0600A9AC add #10,r2
    c.r[1] = 0xFFFFFFFFu;  // 0600A9AE mov #-1,r1
    st16(c.r[2], c.r[1]);  // 0600A9B0 mov.w r1,@r2
    st16(c.r[3], c.r[1]);  // 0600A9B2 mov.w r1,@r3
    st16(c.r[14], c.r[1]);  // 0600A9B4 mov.w r1,@r14
    c.r[3] = c.r[14];  // 0600A9B6 mov r14,r3
    c.r[3] += 4;  // 0600A9B8 add #4,r3
    c.r[2] = c.r[14];  // 0600A9BA mov r14,r2
    c.r[2] += 6;  // 0600A9BC add #6,r2
    c.r[1] = 0x4u;  // 0600A9BE mov #4,r1
    st16(c.r[2], c.r[1]);  // 0600A9C0 mov.w r1,@r2
    st16(c.r[3], c.r[1]);  // 0600A9C2 mov.w r1,@r3
    c.r[2] = c.r[14];  // 0600A9C4 mov r14,r2
    c.r[2] += 2;  // 0600A9C6 add #2,r2
    c.r[1] = 0x0u;  // 0600A9C8 mov #0,r1
    st16(c.r[2], c.r[1]);  // 0600A9CA mov.w r1,@r2
    c.r[1] = ld32(0x0600A9E8u);  // 0600A9CC mov.l 0x0600A9E8,r1
    c.r[0] = ld32(0x0600A9ECu);  // 0600A9CE mov.l 0x0600A9EC,r0
    c.r[7] = 0x0u;  // 0600A9D0 mov #0,r7
    c.r[4] = ld32(c.r[1]);  // 0600A9D2 mov.l @r1,r4
    { const uint32_t x = c.r[0]; c.pr = 0x0600A9D8u; c.r[6] = c.r[14]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600A9D8u) return; }  // 0600A9D4 jsr @r0 ; mov r14,r6
    c.r[14] += 12;  // 0600A9D8 add #12,r14
    c.r[15] = c.r[14];  // 0600A9DA mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0600A9DC lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0600A9DE rts ; mov.l @r15+,r14
}

void f_0600A9F4(SH2Context& c) {
    ran[59] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0600A9F4 mov.l r14,@-r15
    c.r[4] = c.r[4] & 0xFFu;  // 0600A9F6 extu.b r4,r4
    c.r[1] = ld32(0x0600AA54u);  // 0600A9F8 mov.l 0x0600AA54,r1
    c.r[0] = c.r[4];  // 0600A9FA mov r4,r0
    c.r[0] += c.r[0];  // 0600A9FC add r0,r0
    c.r[0] += c.r[4];  // 0600A9FE add r4,r0
    c.r[2] = ld32(c.r[1]);  // 0600AA00 mov.l @r1,r2
    c.r[3] = c.r[0];  // 0600AA02 mov r0,r3
    c.r[3] += c.r[2];  // 0600AA04 add r2,r3
    c.r[1] = c.r[3];  // 0600AA06 mov r3,r1
    c.r[1] += 3;  // 0600AA08 add #3,r1
    c.r[7] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0600AA0A mov.b @r1,r7
    c.r[2] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[2]);  // 0600AA0C mov.b @(r0,r2),r2
    c.r[7] = c.r[7] & 0xFFu;  // 0600AA0E extu.b r7,r7
    c.r[7] <<= 16;  // 0600AA10 shll16 r7
    c.r[1] = c.r[3];  // 0600AA12 mov r3,r1
    c.r[1] += 4;  // 0600AA14 add #4,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0600AA16 mov.b @r1,r1
    c.r[2] = c.r[2] & 0xFFu;  // 0600AA18 extu.b r2,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0600AA1A extu.b r1,r1
    c.r[1] <<= 8;  // 0600AA1C shll8 r1
    c.r[7] |= c.r[1];  // 0600AA1E or r1,r7
    c.r[1] = c.r[3];  // 0600AA20 mov r3,r1
    c.r[1] += 5;  // 0600AA22 add #5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0600AA24 mov.b @r1,r1
    c.r[2] <<= 16;  // 0600AA26 shll16 r2
    c.r[1] = c.r[1] & 0xFFu;  // 0600AA28 extu.b r1,r1
    c.r[7] |= c.r[1];  // 0600AA2A or r1,r7
    c.r[1] = c.r[3];  // 0600AA2C mov r3,r1
    c.r[1] += 1;  // 0600AA2E add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0600AA30 mov.b @r1,r1
    c.r[3] += 2;  // 0600AA32 add #2,r3
    c.r[1] = c.r[1] & 0xFFu;  // 0600AA34 extu.b r1,r1
    c.r[1] <<= 8;  // 0600AA36 shll8 r1
    c.r[2] |= c.r[1];  // 0600AA38 or r1,r2
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[3]);  // 0600AA3A mov.b @r3,r1
    c.r[14] = c.r[15];  // 0600AA3C mov r15,r14
    c.r[1] = c.r[1] & 0xFFu;  // 0600AA3E extu.b r1,r1
    c.r[2] |= c.r[1];  // 0600AA40 or r1,r2
    c.r[1] = ld32(0x0600AA58u);  // 0600AA42 mov.l 0x0600AA58,r1
    c.r[1] = ld32(c.r[1]);  // 0600AA44 mov.l @r1,r1
    c.r[7] -= c.r[2];  // 0600AA46 sub r2,r7
    { uint64_t p = (uint64_t)c.r[7] * c.r[1]; c.mach = (uint32_t)(p >> 32); c.macl = (uint32_t)p; }  // 0600AA48 dmulu.l r1,r7
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0600AA4A mov.l @r15+,r14
    c.r[1] = c.mach;  // 0600AA4C sts mach,r1
    c.r[1] >>= 2;  // 0600AA4E shlr2 r1
    { const uint32_t x = c.pr; c.r[0] = c.r[1] & 0xFFFFu; c.pc = x; return; }  // 0600AA50 rts ; extu.w r1,r0
}

void f_0600AA5C(SH2Context& c) {
    ran[60] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0600AA5C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0600AA5E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0600AA60 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0600AA62 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0600AA64 mov r15,r14
    c.r[9] = c.r[4];  // 0600AA66 mov r4,r9
    c.r[6] = c.r[6] & 0xFFu;  // 0600AA68 extu.b r6,r6
    c.t = (c.r[6] & c.r[6]) == 0;  // 0600AA6A tst r6,r6
    { const bool k = c.t; c.r[8] = c.r[5] & 0xFFu; if (k) { goto L_0600AA8A; } }  // 0600AA6C bt/s 0x0600AA8A ; extu.b r5,r8
    c.r[5] = c.r[8];  // 0600AA70 mov r8,r5
    c.r[5] -= 127;  // 0600AA72 add #-127,r5
    c.t = c.r[5] & 1; c.r[5] = (uint32_t)((int32_t)c.r[5] >> 1);  // 0600AA74 shar r5
    c.t = c.r[5] & 1; c.r[5] = (uint32_t)((int32_t)c.r[5] >> 1);  // 0600AA76 shar r5
    c.t = c.r[5] & 1; c.r[5] = (uint32_t)((int32_t)c.r[5] >> 1);  // 0600AA78 shar r5
    c.t = c.r[5] & 1; c.r[5] = (uint32_t)((int32_t)c.r[5] >> 1);  // 0600AA7A shar r5
    c.r[5] -= 1;  // 0600AA7C add #-1,r5
    c.r[1] = ld32(0x0600AAA8u);  // 0600AA7E mov.l 0x0600AAA8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0600AA84u; c.r[4] = ld32(c.r[9]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600AA84u) return; }  // 0600AA80 jsr @r1 ; mov.l @r9,r4
    c.r[1] = c.r[8];  // 0600AA84 mov r8,r1
    c.r[1] -= 8;  // 0600AA86 add #-8,r1
    c.r[8] = c.r[1] & 0xFFu;  // 0600AA88 extu.b r1,r8
L_0600AA8A:
    c.r[1] = ld32(0x0600AAACu);  // 0600AA8A mov.l 0x0600AAAC,r1
    c.r[6] = c.r[8];  // 0600AA8C mov r8,r6
    c.r[4] = ld32(c.r[9]);  // 0600AA8E mov.l @r9,r4
    { const uint32_t x = c.r[1]; c.pr = 0x0600AA94u; c.r[5] = 0x7u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600AA94u) return; }  // 0600AA90 jsr @r1 ; mov #7,r5
    c.r[1] = ld32(0x0600AAB0u);  // 0600AA94 mov.l 0x0600AAB0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0600AA9Au; c.r[4] = ld32(c.r[9]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600AA9Au) return; }  // 0600AA96 jsr @r1 ; mov.l @r9,r4
    c.r[15] = c.r[14];  // 0600AA9A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0600AA9C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0600AA9E mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0600AAA0 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0600AAA2 rts ; mov.l @r15+,r8
}

void f_0600ABF4(SH2Context& c) {
    ran[61] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0600ABF4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0600ABF6 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0600ABF8 mov r15,r14
    c.r[1] = ld32(0x0600AC48u);  // 0600ABFA mov.l 0x0600AC48,r1
    c.r[2] = 0x0u;  // 0600ABFC mov #0,r2
    st16(c.r[1], c.r[2]);  // 0600ABFE mov.w r2,@r1
    c.r[1] = ld32(0x0600AC4Cu);  // 0600AC00 mov.l 0x0600AC4C,r1
    st16(c.r[1], c.r[2]);  // 0600AC02 mov.w r2,@r1
    c.r[1] = ld32(0x0600AC50u);  // 0600AC04 mov.l 0x0600AC50,r1
    st16(c.r[1], c.r[2]);  // 0600AC06 mov.w r2,@r1
    c.r[1] = ld32(0x0600AC54u);  // 0600AC08 mov.l 0x0600AC54,r1
    st16(c.r[1], c.r[2]);  // 0600AC0A mov.w r2,@r1
    c.r[6] = ld32(0x0600AC58u);  // 0600AC0C mov.l 0x0600AC58,r6
    c.r[1] = 0x1u;  // 0600AC0E mov #1,r1
    st32(c.r[6], c.r[1]);  // 0600AC10 mov.l r1,@r6
    c.r[1] = ld32(0x0600AC5Cu);  // 0600AC12 mov.l 0x0600AC5C,r1
    st32(c.r[6] + 8, c.r[1]);  // 0600AC14 mov.l r1,@(8,r6)
    c.r[1] = (uint32_t)(int16_t)ld16(0x0600AC44u);  // 0600AC16 mov.w 0x0600AC44,r1
    st32(c.r[6] + 4, c.r[1]);  // 0600AC18 mov.l r1,@(4,r6)
    c.r[5] = ld32(0x0600AC60u);  // 0600AC1A mov.l 0x0600AC60,r5
    c.r[0] = ld32(0x0600AC64u);  // 0600AC1C mov.l 0x0600AC64,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0600AC22u; c.r[4] = 0x10u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600AC22u) return; }  // 0600AC1E jsr @r0 ; mov #16,r4
    c.r[5] = ld32(0x0600AC68u);  // 0600AC22 mov.l 0x0600AC68,r5
    c.r[4] = ld32(0x0600AC6Cu);  // 0600AC24 mov.l 0x0600AC6C,r4
    c.r[1] = ld32(0x0600AC70u);  // 0600AC26 mov.l 0x0600AC70,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0600AC2Cu; st32(c.r[5], c.r[0]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600AC2Cu) return; }  // 0600AC28 jsr @r1 ; mov.l r0,@r5
    c.r[1] = ld32(0x0600AC74u);  // 0600AC2C mov.l 0x0600AC74,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0600AC32u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600AC32u) return; }  // 0600AC2E jsr @r1 ; nop
    c.r[5] = ld32(0x0600AC78u);  // 0600AC32 mov.l 0x0600AC78,r5
    c.r[4] = ld32(0x0600AC7Cu);  // 0600AC34 mov.l 0x0600AC7C,r4
    c.r[1] = ld32(0x0600AC80u);  // 0600AC36 mov.l 0x0600AC80,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0600AC3Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600AC3Cu) return; }  // 0600AC38 jsr @r1 ; nop
    c.r[15] = c.r[14];  // 0600AC3C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0600AC3E lds.l @r15+,pr
    { const uint32_t x = c.pr; c.r[14] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0600AC40 rts ; mov.l @r15+,r14
}

void f_0600AC84(SH2Context& c) {
    ran[62] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0600AC84 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0600AC86 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0600AC88 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0600AC8A mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0600AC8C mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0600AC8E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0600AC90 sts.l pr,@-r15
    c.r[15] -= 12;  // 0600AC92 add #-12,r15
    c.r[12] = ld32(0x0600AECCu);  // 0600AC94 mov.l 0x0600AECC,r12
    c.r[9] = ld32(c.r[12]);  // 0600AC96 mov.l @r12,r9
    c.r[14] = c.r[15];  // 0600AC98 mov r15,r14
    c.r[1] = c.r[9];  // 0600AC9A mov r9,r1
    c.r[1] += 20;  // 0600AC9C add #20,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0600AC9E mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0600ACA0 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0600ACA2 tst r1,r1
    { const bool k = c.t; c.r[10] = 0x0u; if (k) { goto L_0600ACAE; } }  // 0600ACA4 bt/s 0x0600ACAE ; mov #0,r10
    c.r[4] = ld32(c.r[9]);  // 0600ACA8 mov.l @r9,r4
    c.t = (c.r[4] & c.r[4]) == 0;  // 0600ACAA tst r4,r4
    if (!c.t) { goto L_0600AD78; }  // 0600ACAC bf 0x0600AD78
L_0600ACAE:
    c.r[1] = ld32(0x0600AED0u);  // 0600ACAE mov.l 0x0600AED0,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0600ACB0 mov.w @r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0600ACB2 tst r1,r1
    { const bool k = !c.t; c.t = (int32_t)c.r[10] > 0; if (k) { goto L_0600ACBC; } }  // 0600ACB4 bf/s 0x0600ACBC ; cmp/pl r10
    goto L_0600B0D4;  // 0600ACB8 bra 0x0600B0D4 ; nop
L_0600ACBC:
    c.r[1] = ld32(0x0600AED4u);  // 0600ACBC mov.l 0x0600AED4,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0600ACBE mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0600ACC0 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0600ACC2 tst r1,r1
    { const bool k = c.t; c.r[1] = 0x2Cu; if (k) { goto L_0600ACCC; } }  // 0600ACC4 bt/s 0x0600ACCC ; mov #44,r1
    goto L_0600B0D2;  // 0600ACC8 bra 0x0600B0D2 ; nop
L_0600ACCC:
    c.r[8] = ld32(0x0600AED8u);  // 0600ACCC mov.l 0x0600AED8,r8
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[8]);  // 0600ACCE mov.w @r8,r2
    c.macl = (c.r[2] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 0600ACD0 mulu.w r1,r2
    c.r[4] = c.macl;  // 0600ACD2 sts macl,r4
    c.r[1] = ld32(0x0600AEDCu);  // 0600ACD4 mov.l 0x0600AEDC,r1
    c.r[4] += c.r[1];  // 0600ACD6 add r1,r4
    c.r[1] = ld32(0x0600AEE0u);  // 0600ACD8 mov.l 0x0600AEE0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0600ACDEu; st32(c.r[12], c.r[4]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600ACDEu) return; }  // 0600ACDA jsr @r1 ; mov.l r4,@r12
    c.r[4] = ld32(c.r[12]);  // 0600ACDE mov.l @r12,r4
    c.r[1] = ld32(c.r[4]);  // 0600ACE0 mov.l @r4,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0600ACE2 tst r1,r1
    { const bool k = !c.t; c.t = (int32_t)c.r[10] > 0; if (k) { goto L_0600ACEC; } }  // 0600ACE4 bf/s 0x0600ACEC ; cmp/pl r10
    goto L_0600B0D4;  // 0600ACE8 bra 0x0600B0D4 ; nop
L_0600ACEC:
    c.r[2] = c.r[4];  // 0600ACEC mov r4,r2
    c.r[2] += 20;  // 0600ACEE add #20,r2
    c.r[1] = 0x1u;  // 0600ACF0 mov #1,r1
    st16(c.r[2], c.r[1]);  // 0600ACF2 mov.w r1,@r2
    c.r[1] = ld32(0x0600AEE4u);  // 0600ACF4 mov.l 0x0600AEE4,r1
    st32(c.r[1], c.r[10]);  // 0600ACF6 mov.l r10,@r1
    c.r[1] = ld32(0x0600AEE8u);  // 0600ACF8 mov.l 0x0600AEE8,r1
    st32(c.r[1], c.r[10]);  // 0600ACFA mov.l r10,@r1
    c.r[1] = ld32(0x0600AEECu);  // 0600ACFC mov.l 0x0600AEEC,r1
    st32(c.r[1], c.r[10]);  // 0600ACFE mov.l r10,@r1
    c.r[5] = ld32(0x0600AEF0u);  // 0600AD00 mov.l 0x0600AEF0,r5
    c.r[0] = ld32(0x0600AEF4u);  // 0600AD02 mov.l 0x0600AEF4,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0600AD08u; c.r[4] = ld32(c.r[4]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600AD08u) return; }  // 0600AD04 jsr @r0 ; mov.l @r4,r4
    c.r[1] = ld32(c.r[12]);  // 0600AD08 mov.l @r12,r1
    c.r[0] = ld32(0x0600AEF8u);  // 0600AD0A mov.l 0x0600AEF8,r0
    c.r[4] = ld32(c.r[1]);  // 0600AD0C mov.l @r1,r4
    { const uint32_t x = c.r[0]; c.pr = 0x0600AD12u; c.r[5] = 0x8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600AD12u) return; }  // 0600AD0E jsr @r0 ; mov #8,r5
    c.r[1] = ld32(c.r[12]);  // 0600AD12 mov.l @r12,r1
    c.r[0] = ld32(0x0600AEFCu);  // 0600AD14 mov.l 0x0600AEFC,r0
    c.r[4] = ld32(c.r[1]);  // 0600AD16 mov.l @r1,r4
    { const uint32_t x = c.r[0]; c.pr = 0x0600AD1Cu; c.r[5] = 0x1u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600AD1Cu) return; }  // 0600AD18 jsr @r0 ; mov #1,r5
    c.r[1] = ld32(c.r[12]);  // 0600AD1C mov.l @r12,r1
    c.r[5] = ld32(c.r[1] + 36);  // 0600AD1E mov.l @(36,r1),r5
    c.r[0] = ld32(0x0600AF00u);  // 0600AD20 mov.l 0x0600AF00,r0
    c.r[4] = ld32(c.r[1]);  // 0600AD22 mov.l @r1,r4
    { const uint32_t x = c.r[0]; c.pr = 0x0600AD28u; c.r[6] = 0x0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600AD28u) return; }  // 0600AD24 jsr @r0 ; mov #0,r6
    c.r[1] = ld32(c.r[12]);  // 0600AD28 mov.l @r12,r1
    c.r[0] = ld32(0x0600AF04u);  // 0600AD2A mov.l 0x0600AF04,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0600AD30u; c.r[4] = ld32(c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600AD30u) return; }  // 0600AD2C jsr @r0 ; mov.l @r1,r4
    c.r[7] = c.r[14];  // 0600AD30 mov r14,r7
    c.r[1] = ld32(c.r[12]);  // 0600AD32 mov.l @r12,r1
    c.r[6] = 0x0u;  // 0600AD34 mov #0,r6
    c.r[4] = ld32(c.r[1]);  // 0600AD36 mov.l @r1,r4
    c.r[5] = 0x0u;  // 0600AD38 mov #0,r5
    c.r[1] = ld32(0x0600AF08u);  // 0600AD3A mov.l 0x0600AF08,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0600AD40u; c.r[15] -= 4; st32(c.r[15], c.r[10]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600AD40u) return; }  // 0600AD3C jsr @r1 ; mov.l r10,@-r15
    c.r[4] = ld32(c.r[12]);  // 0600AD40 mov.l @r12,r4
    c.r[1] = ld32(c.r[4] + 36);  // 0600AD42 mov.l @(36,r4),r1
    c.r[3] = ld32(0x0600AF0Cu);  // 0600AD44 mov.l 0x0600AF0C,r3
    c.r[2] = ld32(c.r[14]);  // 0600AD46 mov.l @r14,r2
    c.r[1] <<= 8;  // 0600AD48 shll8 r1
    c.r[1] += c.r[1];  // 0600AD4A add r1,r1
    c.r[1] <<= 2;  // 0600AD4C shll2 r1
    c.r[2] -= c.r[1];  // 0600AD4E sub r1,r2
    c.r[1] = ld32(c.r[4] + 28);  // 0600AD50 mov.l @(28,r4),r1
    c.r[1] <<= 8;  // 0600AD52 shll8 r1
    c.r[1] += c.r[1];  // 0600AD54 add r1,r1
    c.r[1] <<= 2;  // 0600AD56 shll2 r1
    c.t = (int32_t)c.r[1] > (int32_t)c.r[2];  // 0600AD58 cmp/gt r2,r1
    { const bool k = !c.t; c.r[15] += 4; if (k) { goto L_0600AD60; } }  // 0600AD5A bf/s 0x0600AD60 ; add #4,r15
    c.r[1] = c.r[2];  // 0600AD5E mov r2,r1
L_0600AD60:
    st32(c.r[3], c.r[1]);  // 0600AD60 mov.l r1,@r3
    c.r[5] = ld32(c.r[4] + 28);  // 0600AD62 mov.l @(28,r4),r5
    c.r[0] = ld32(0x0600AF10u);  // 0600AD64 mov.l 0x0600AF10,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0600AD6Au; c.r[4] = ld32(c.r[4]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600AD6Au) return; }  // 0600AD66 jsr @r0 ; mov.l @r4,r4
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[8]);  // 0600AD6A mov.w @r8,r1
    c.r[10] = c.r[0];  // 0600AD6C mov r0,r10
    c.r[0] = c.r[1];  // 0600AD6E mov r1,r0
    c.r[0] += 1;  // 0600AD70 add #1,r0
    c.r[0] &= 0xFu;  // 0600AD72 and #15,r0
    st16(c.r[8], c.r[0]); goto L_0600B0D2;  // 0600AD74 bra 0x0600B0D2 ; mov.w r0,@r8
L_0600AD78:
    c.r[1] = ld32(0x0600AF14u);  // 0600AD78 mov.l 0x0600AF14,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0600AD7A mov.b @r1,r1
    c.r[0] = c.r[1] & 0xFFu;  // 0600AD7C extu.b r1,r0
    c.r[0] >>= 2;  // 0600AD7E shlr2 r0
    c.r[0] >>= 2;  // 0600AD80 shlr2 r0
    c.t = c.r[0] & 1; c.r[0] >>= 1;  // 0600AD82 shlr r0
    c.r[0] >>= 2;  // 0600AD84 shlr2 r0
    c.t = c.r[0] == 0x1u;  // 0600AD86 cmp/eq #1,r0
    if (c.t) { goto L_0600AD8E; }  // 0600AD88 bt 0x0600AD8E
    goto L_0600AF3C;  // 0600AD8A bra 0x0600AF3C ; nop
L_0600AD8E:
    c.r[11] = ld32(0x0600AEECu);  // 0600AD8E mov.l 0x0600AEEC,r11
    c.r[1] = ld32(c.r[11]);  // 0600AD90 mov.l @r11,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0600AD92 tst r1,r1
    if (c.t) { goto L_0600AE1A; }  // 0600AD94 bt 0x0600AE1A
    c.r[8] = ld32(0x0600AEE4u);  // 0600AD96 mov.l 0x0600AEE4,r8
    c.r[1] = ld32(c.r[8]);  // 0600AD98 mov.l @r8,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0600AD9A tst r1,r1
    if (!c.t) { goto L_0600ADCA; }  // 0600AD9C bf 0x0600ADCA
    c.r[1] = ld32(0x0600AF0Cu);  // 0600AD9E mov.l 0x0600AF0C,r1
    c.r[3] = ld32(c.r[1]);  // 0600ADA0 mov.l @r1,r3
    c.r[2] = ld32(0x0600AEE8u);  // 0600ADA2 mov.l 0x0600AEE8,r2
    c.r[1] = ld32(c.r[2]);  // 0600ADA4 mov.l @r2,r1
    c.r[7] = (uint32_t)(int16_t)ld16(0x0600AEC4u);  // 0600ADA6 mov.w 0x0600AEC4,r7
    c.r[3] -= c.r[1];  // 0600ADA8 sub r1,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0600AEC6u);  // 0600ADAA mov.w 0x0600AEC6,r1
    c.t = (int32_t)c.r[3] > (int32_t)c.r[1];  // 0600ADAC cmp/gt r1,r3
    if (c.t) { goto L_0600ADB2; }  // 0600ADAE bt 0x0600ADB2
    c.r[7] = c.r[3];  // 0600ADB0 mov r3,r7
L_0600ADB2:
    st32(c.r[8], c.r[7]);  // 0600ADB2 mov.l r7,@r8
    c.r[6] = ld32(0x0600AF18u);  // 0600ADB4 mov.l 0x0600AF18,r6
    c.r[4] = (uint32_t)(int16_t)ld16(0x0600AEC8u);  // 0600ADB6 mov.w 0x0600AEC8,r4
    c.r[1] = ld32(0x0600AF1Cu);  // 0600ADB8 mov.l 0x0600AF1C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0600ADBEu; c.r[4] += c.r[7]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600ADBEu) return; }  // 0600ADBA jsr @r1 ; add r7,r4
    c.r[5] = c.r[4];  // 0600ADBE mov r4,r5
    c.r[0] = ld32(0x0600AF20u);  // 0600ADC0 mov.l 0x0600AF20,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0600ADC6u; c.r[4] = ld32(c.r[9]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600ADC6u) return; }  // 0600ADC2 jsr @r0 ; mov.l @r9,r4
    c.r[10] = c.r[0]; goto L_0600ADF0;  // 0600ADC6 bra 0x0600ADF0 ; mov r0,r10
L_0600ADCA:
    c.r[0] = ld32(0x0600AF24u);  // 0600ADCA mov.l 0x0600AF24,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0600ADD0u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600ADD0u) return; }  // 0600ADCC jsr @r0 ; nop
    c.r[10] = c.r[0];  // 0600ADD0 mov r0,r10
    c.r[6] = c.r[14];  // 0600ADD2 mov r14,r6
    c.r[6] += 8;  // 0600ADD4 add #8,r6
    c.r[1] = ld32(c.r[12]);  // 0600ADD6 mov.l @r12,r1
    c.r[5] = c.r[14];  // 0600ADD8 mov r14,r5
    c.r[4] = ld32(c.r[1]);  // 0600ADDA mov.l @r1,r4
    c.r[1] = ld32(0x0600AF28u);  // 0600ADDC mov.l 0x0600AF28,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0600ADE2u; c.r[5] += 4; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600ADE2u) return; }  // 0600ADDE jsr @r1 ; add #4,r5
    c.r[2] = ld32(c.r[14] + 8);  // 0600ADE2 mov.l @(8,r14),r2
    c.r[1] = ld32(c.r[8]);  // 0600ADE4 mov.l @r8,r1
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[1];  // 0600ADE6 cmp/ge r1,r2
    if (!c.t) { goto L_0600ADF0; }  // 0600ADE8 bf 0x0600ADF0
    c.r[0] = ld32(c.r[11]);  // 0600ADEA mov.l @r11,r0
    c.r[0] ^= 0x1u;  // 0600ADEC xor #1,r0
    st32(c.r[11], c.r[0]);  // 0600ADEE mov.l r0,@r11
L_0600ADF0:
    c.r[11] = ld32(0x0600AEE8u);  // 0600ADF0 mov.l 0x0600AEE8,r11
    c.r[6] = ld32(c.r[11]);  // 0600ADF2 mov.l @r11,r6
    c.t = (c.r[6] & c.r[6]) == 0;  // 0600ADF4 tst r6,r6
    { const bool k = !c.t; c.t = (int32_t)c.r[10] >= 0; if (k) { goto L_0600ADFE; } }  // 0600ADF6 bf/s 0x0600ADFE ; cmp/pz r10
    goto L_0600B0B0;  // 0600ADFA bra 0x0600B0B0 ; nop
L_0600ADFE:
    { const bool k = c.t; c.r[0] = c.r[10]; if (k) { goto L_0600AE0A; } }  // 0600ADFE bt/s 0x0600AE0A ; mov r10,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0600AE02 cmp/eq #-1,r0
    if (c.t) { goto L_0600AE0A; }  // 0600AE04 bt 0x0600AE0A
    goto L_0600B0B0;  // 0600AE06 bra 0x0600B0B0 ; nop
L_0600AE0A:
    c.r[9] = ld32(0x0600AF2Cu);  // 0600AE0A mov.l 0x0600AF2C,r9
    c.r[1] = 0x1u;  // 0600AE0C mov #1,r1
    st8(c.r[9], c.r[1]);  // 0600AE0E mov.b r1,@r9
    c.r[8] = ld32(0x0600AECCu);  // 0600AE10 mov.l 0x0600AECC,r8
    c.r[1] = ld32(c.r[8]);  // 0600AE12 mov.l @r8,r1
    c.r[4] = ld32(0x0600AF30u);  // 0600AE14 mov.l 0x0600AF30,r4
    c.r[5] = ld32(c.r[1] + 40); goto L_0600AE9C;  // 0600AE16 bra 0x0600AE9C ; mov.l @(40,r1),r5
L_0600AE1A:
    c.r[8] = ld32(0x0600AEE8u);  // 0600AE1A mov.l 0x0600AEE8,r8
    c.r[1] = ld32(c.r[8]);  // 0600AE1C mov.l @r8,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0600AE1E tst r1,r1
    if (!c.t) { goto L_0600AE4E; }  // 0600AE20 bf 0x0600AE4E
    c.r[1] = ld32(0x0600AF0Cu);  // 0600AE22 mov.l 0x0600AF0C,r1
    c.r[3] = ld32(c.r[1]);  // 0600AE24 mov.l @r1,r3
    c.r[2] = ld32(0x0600AEE4u);  // 0600AE26 mov.l 0x0600AEE4,r2
    c.r[1] = ld32(c.r[2]);  // 0600AE28 mov.l @r2,r1
    c.r[7] = (uint32_t)(int16_t)ld16(0x0600AEC4u);  // 0600AE2A mov.w 0x0600AEC4,r7
    c.r[3] -= c.r[1];  // 0600AE2C sub r1,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0600AEC6u);  // 0600AE2E mov.w 0x0600AEC6,r1
    c.t = (int32_t)c.r[3] > (int32_t)c.r[1];  // 0600AE30 cmp/gt r1,r3
    if (c.t) { goto L_0600AE36; }  // 0600AE32 bt 0x0600AE36
    c.r[7] = c.r[3];  // 0600AE34 mov r3,r7
L_0600AE36:
    st32(c.r[8], c.r[7]);  // 0600AE36 mov.l r7,@r8
    c.r[6] = ld32(0x0600AF30u);  // 0600AE38 mov.l 0x0600AF30,r6
    c.r[4] = (uint32_t)(int16_t)ld16(0x0600AEC8u);  // 0600AE3A mov.w 0x0600AEC8,r4
    c.r[1] = ld32(0x0600AF1Cu);  // 0600AE3C mov.l 0x0600AF1C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0600AE42u; c.r[4] += c.r[7]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600AE42u) return; }  // 0600AE3E jsr @r1 ; add r7,r4
    c.r[5] = c.r[4];  // 0600AE42 mov r4,r5
    c.r[0] = ld32(0x0600AF20u);  // 0600AE44 mov.l 0x0600AF20,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0600AE4Au; c.r[4] = ld32(c.r[9]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600AE4Au) return; }  // 0600AE46 jsr @r0 ; mov.l @r9,r4
    c.r[10] = c.r[0]; goto L_0600AE74;  // 0600AE4A bra 0x0600AE74 ; mov r0,r10
L_0600AE4E:
    c.r[0] = ld32(0x0600AF24u);  // 0600AE4E mov.l 0x0600AF24,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0600AE54u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600AE54u) return; }  // 0600AE50 jsr @r0 ; nop
    c.r[10] = c.r[0];  // 0600AE54 mov r0,r10
    c.r[6] = c.r[14];  // 0600AE56 mov r14,r6
    c.r[6] += 8;  // 0600AE58 add #8,r6
    c.r[1] = ld32(c.r[12]);  // 0600AE5A mov.l @r12,r1
    c.r[5] = c.r[14];  // 0600AE5C mov r14,r5
    c.r[4] = ld32(c.r[1]);  // 0600AE5E mov.l @r1,r4
    c.r[1] = ld32(0x0600AF28u);  // 0600AE60 mov.l 0x0600AF28,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0600AE66u; c.r[5] += 4; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600AE66u) return; }  // 0600AE62 jsr @r1 ; add #4,r5
    c.r[2] = ld32(c.r[14] + 8);  // 0600AE66 mov.l @(8,r14),r2
    c.r[1] = ld32(c.r[8]);  // 0600AE68 mov.l @r8,r1
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[1];  // 0600AE6A cmp/ge r1,r2
    if (!c.t) { goto L_0600AE74; }  // 0600AE6C bf 0x0600AE74
    c.r[0] = ld32(c.r[11]);  // 0600AE6E mov.l @r11,r0
    c.r[0] ^= 0x1u;  // 0600AE70 xor #1,r0
    st32(c.r[11], c.r[0]);  // 0600AE72 mov.l r0,@r11
L_0600AE74:
    c.r[11] = ld32(0x0600AEE4u);  // 0600AE74 mov.l 0x0600AEE4,r11
    c.r[6] = ld32(c.r[11]);  // 0600AE76 mov.l @r11,r6
    c.t = (c.r[6] & c.r[6]) == 0;  // 0600AE78 tst r6,r6
    { const bool k = !c.t; c.t = (int32_t)c.r[10] >= 0; if (k) { goto L_0600AE82; } }  // 0600AE7A bf/s 0x0600AE82 ; cmp/pz r10
    goto L_0600B0B0;  // 0600AE7E bra 0x0600B0B0 ; nop
L_0600AE82:
    { const bool k = c.t; c.r[0] = c.r[10]; if (k) { goto L_0600AE8E; } }  // 0600AE82 bt/s 0x0600AE8E ; mov r10,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0600AE86 cmp/eq #-1,r0
    if (c.t) { goto L_0600AE8E; }  // 0600AE88 bt 0x0600AE8E
    goto L_0600B0B0;  // 0600AE8A bra 0x0600B0B0 ; nop
L_0600AE8E:
    c.r[9] = ld32(0x0600AF2Cu);  // 0600AE8E mov.l 0x0600AF2C,r9
    c.r[1] = 0x1u;  // 0600AE90 mov #1,r1
    st8(c.r[9], c.r[1]);  // 0600AE92 mov.b r1,@r9
    c.r[8] = ld32(0x0600AECCu);  // 0600AE94 mov.l 0x0600AECC,r8
    c.r[1] = ld32(c.r[8]);  // 0600AE96 mov.l @r8,r1
    c.r[5] = ld32(c.r[1] + 40);  // 0600AE98 mov.l @(40,r1),r5
    c.r[4] = ld32(0x0600AF18u);  // 0600AE9A mov.l 0x0600AF18,r4
L_0600AE9C:
    c.r[1] = ld32(0x0600AF34u);  // 0600AE9C mov.l 0x0600AF34,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0600AEA2u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600AEA2u) return; }  // 0600AE9E jsr @r1 ; nop
    c.r[1] = ld32(0x0600AF38u);  // 0600AEA2 mov.l 0x0600AF38,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0600AEA8u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600AEA8u) return; }  // 0600AEA4 jsr @r1 ; nop
    c.r[1] = 0x0u;  // 0600AEA8 mov #0,r1
    st8(c.r[9], c.r[1]);  // 0600AEAA mov.b r1,@r9
    c.r[1] = ld32(c.r[8]);  // 0600AEAC mov.l @r8,r1
    c.r[3] = ld32(c.r[11]);  // 0600AEAE mov.l @r11,r3
    c.r[2] = ld32(c.r[1] + 40);  // 0600AEB0 mov.l @(40,r1),r2
    c.r[2] += c.r[3];  // 0600AEB2 add r3,r2
    st32(c.r[1] + 40, c.r[2]);  // 0600AEB4 mov.l r2,@(40,r1)
    c.r[1] = ld32(0x0600AF0Cu);  // 0600AEB6 mov.l 0x0600AF0C,r1
    c.r[2] = ld32(c.r[1]);  // 0600AEB8 mov.l @r1,r2
    c.r[2] -= c.r[3];  // 0600AEBA sub r3,r2
    st32(c.r[1], c.r[2]);  // 0600AEBC mov.l r2,@r1
    c.r[1] = 0x0u;  // 0600AEBE mov #0,r1
    st32(c.r[11], c.r[1]); goto L_0600B0B0;  // 0600AEC0 bra 0x0600B0B0 ; mov.l r1,@r11
L_0600AF3C:
    c.r[1] = ld32(0x0600AFD4u);  // 0600AF3C mov.l 0x0600AFD4,r1
    c.r[1] = ld32(c.r[1]);  // 0600AF3E mov.l @r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0600AF40 tst r1,r1
    if (c.t) { goto L_0600B000; }  // 0600AF42 bt 0x0600B000
    c.r[6] = ld32(0x0600AFD8u);  // 0600AF44 mov.l 0x0600AFD8,r6
    c.r[1] = ld32(0x0600AFDCu);  // 0600AF46 mov.l 0x0600AFDC,r1
    c.r[3] = ld32(c.r[1]);  // 0600AF48 mov.l @r1,r3
    c.r[2] = ld32(0x0600AFE0u);  // 0600AF4A mov.l 0x0600AFE0,r2
    c.r[1] = ld32(c.r[2]);  // 0600AF4C mov.l @r2,r1
    c.r[7] = (uint32_t)(int16_t)ld16(0x0600AFCCu);  // 0600AF4E mov.w 0x0600AFCC,r7
    c.r[3] -= c.r[1];  // 0600AF50 sub r1,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0600AFCEu);  // 0600AF52 mov.w 0x0600AFCE,r1
    c.t = (int32_t)c.r[3] > (int32_t)c.r[1];  // 0600AF54 cmp/gt r1,r3
    if (c.t) { goto L_0600AF5A; }  // 0600AF56 bt 0x0600AF5A
    c.r[7] = c.r[3];  // 0600AF58 mov r3,r7
L_0600AF5A:
    st32(c.r[6], c.r[7]);  // 0600AF5A mov.l r7,@r6
    c.r[6] = ld32(0x0600AFE4u);  // 0600AF5C mov.l 0x0600AFE4,r6
    c.r[4] = (uint32_t)(int16_t)ld16(0x0600AFD0u);  // 0600AF5E mov.w 0x0600AFD0,r4
    c.r[1] = ld32(0x0600AFE8u);  // 0600AF60 mov.l 0x0600AFE8,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0600AF66u; c.r[4] += c.r[7]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600AF66u) return; }  // 0600AF62 jsr @r1 ; add r7,r4
    c.r[5] = c.r[4];  // 0600AF66 mov r4,r5
    c.r[0] = ld32(0x0600AFECu);  // 0600AF68 mov.l 0x0600AFEC,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0600AF6Eu; c.r[4] = ld32(c.r[9]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600AF6Eu) return; }  // 0600AF6A jsr @r0 ; mov.l @r9,r4
    c.r[10] = c.r[0];  // 0600AF6E mov r0,r10
    c.t = (int32_t)c.r[10] >= 0;  // 0600AF70 cmp/pz r10
    { const bool k = c.t; c.t = c.r[0] == 0xFFFFFFFFu; if (k) { goto L_0600AF7C; } }  // 0600AF72 bt/s 0x0600AF7C ; cmp/eq #-1,r0
    if (c.t) { goto L_0600AF7C; }  // 0600AF76 bt 0x0600AF7C
    goto L_0600B0A8;  // 0600AF78 bra 0x0600B0A8 ; nop
L_0600AF7C:
    c.r[9] = c.r[12];  // 0600AF7C mov r12,r9
    c.r[11] = ld32(0x0600AFF0u);  // 0600AF7E mov.l 0x0600AFF0,r11
    c.r[8] = ld32(0x0600AFF4u);  // 0600AF80 mov.l 0x0600AFF4,r8
L_0600AF82:
    c.r[1] = ld32(c.r[9]);  // 0600AF82 mov.l @r9,r1
    { const uint32_t x = c.r[11]; c.pr = 0x0600AF88u; c.r[4] = ld32(c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600AF88u) return; }  // 0600AF84 jsr @r11 ; mov.l @r1,r4
    c.r[10] = c.r[0];  // 0600AF88 mov r0,r10
    c.r[6] = c.r[14];  // 0600AF8A mov r14,r6
    c.r[6] += 8;  // 0600AF8C add #8,r6
    c.r[1] = ld32(c.r[9]);  // 0600AF8E mov.l @r9,r1
    c.r[5] = c.r[14];  // 0600AF90 mov r14,r5
    c.r[4] = ld32(c.r[1]);  // 0600AF92 mov.l @r1,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0600AF98u; c.r[5] += 4; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600AF98u) return; }  // 0600AF94 jsr @r8 ; add #4,r5
    c.r[2] = ld32(c.r[14] + 8);  // 0600AF98 mov.l @(8,r14),r2
    c.r[1] = ld32(0x0600AFD8u);  // 0600AF9A mov.l 0x0600AFD8,r1
    c.r[1] = ld32(c.r[1]);  // 0600AF9C mov.l @r1,r1
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[1];  // 0600AF9E cmp/ge r1,r2
    { const bool k = c.t; c.t = (int32_t)c.r[10] >= 0; if (k) { goto L_0600AFAC; } }  // 0600AFA0 bt/s 0x0600AFAC ; cmp/pz r10
    { const bool k = c.t; c.r[0] = c.r[10]; if (k) { SH2_POLL(c); goto L_0600AF82; } }  // 0600AFA4 bt/s 0x0600AF82 ; mov r10,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0600AFA8 cmp/eq #-1,r0
    if (c.t) { SH2_POLL(c); goto L_0600AF82; }  // 0600AFAA bt 0x0600AF82
L_0600AFAC:
    c.r[11] = ld32(0x0600AFE0u);  // 0600AFAC mov.l 0x0600AFE0,r11
    c.r[6] = ld32(c.r[11]);  // 0600AFAE mov.l @r11,r6
    c.t = (c.r[6] & c.r[6]) == 0;  // 0600AFB0 tst r6,r6
    { const bool k = c.t; c.t = (int32_t)c.r[10] >= 0; if (k) { goto L_0600B0A8; } }  // 0600AFB2 bt/s 0x0600B0A8 ; cmp/pz r10
    { const bool k = c.t; c.r[0] = c.r[10]; if (k) { goto L_0600AFBE; } }  // 0600AFB6 bt/s 0x0600AFBE ; mov r10,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0600AFBA cmp/eq #-1,r0
    if (!c.t) { goto L_0600B0A8; }  // 0600AFBC bf 0x0600B0A8
L_0600AFBE:
    c.r[8] = ld32(0x0600AFF8u);  // 0600AFBE mov.l 0x0600AFF8,r8
    c.r[1] = 0x1u;  // 0600AFC0 mov #1,r1
    st8(c.r[8], c.r[1]);  // 0600AFC2 mov.b r1,@r8
    c.r[1] = ld32(c.r[9]);  // 0600AFC4 mov.l @r9,r1
    c.r[4] = ld32(0x0600AFFCu);  // 0600AFC6 mov.l 0x0600AFFC,r4
    c.r[5] = ld32(c.r[1] + 40); goto L_0600B082;  // 0600AFC8 bra 0x0600B082 ; mov.l @(40,r1),r5
L_0600B000:
    c.r[6] = ld32(0x0600B13Cu);  // 0600B000 mov.l 0x0600B13C,r6
    c.r[1] = ld32(0x0600B140u);  // 0600B002 mov.l 0x0600B140,r1
    c.r[3] = ld32(c.r[1]);  // 0600B004 mov.l @r1,r3
    c.r[2] = ld32(0x0600B144u);  // 0600B006 mov.l 0x0600B144,r2
    c.r[1] = ld32(c.r[2]);  // 0600B008 mov.l @r2,r1
    c.r[7] = (uint32_t)(int16_t)ld16(0x0600B136u);  // 0600B00A mov.w 0x0600B136,r7
    c.r[3] -= c.r[1];  // 0600B00C sub r1,r3
    c.r[1] = (uint32_t)(int16_t)ld16(0x0600B138u);  // 0600B00E mov.w 0x0600B138,r1
    c.t = (int32_t)c.r[3] > (int32_t)c.r[1];  // 0600B010 cmp/gt r1,r3
    if (c.t) { goto L_0600B016; }  // 0600B012 bt 0x0600B016
    c.r[7] = c.r[3];  // 0600B014 mov r3,r7
L_0600B016:
    st32(c.r[6], c.r[7]);  // 0600B016 mov.l r7,@r6
    c.r[6] = ld32(0x0600B148u);  // 0600B018 mov.l 0x0600B148,r6
    c.r[4] = (uint32_t)(int16_t)ld16(0x0600B13Au);  // 0600B01A mov.w 0x0600B13A,r4
    c.r[1] = ld32(0x0600B14Cu);  // 0600B01C mov.l 0x0600B14C,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0600B022u; c.r[4] += c.r[7]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600B022u) return; }  // 0600B01E jsr @r1 ; add r7,r4
    c.r[5] = c.r[4];  // 0600B022 mov r4,r5
    c.r[0] = ld32(0x0600B150u);  // 0600B024 mov.l 0x0600B150,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0600B02Au; c.r[4] = ld32(c.r[9]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600B02Au) return; }  // 0600B026 jsr @r0 ; mov.l @r9,r4
    c.r[10] = c.r[0];  // 0600B02A mov r0,r10
    c.t = (int32_t)c.r[10] >= 0;  // 0600B02C cmp/pz r10
    { const bool k = c.t; c.t = c.r[0] == 0xFFFFFFFFu; if (k) { goto L_0600B034; } }  // 0600B02E bt/s 0x0600B034 ; cmp/eq #-1,r0
    if (!c.t) { goto L_0600B0A8; }  // 0600B032 bf 0x0600B0A8
L_0600B034:
    c.r[9] = c.r[12];  // 0600B034 mov r12,r9
    c.r[11] = ld32(0x0600B154u);  // 0600B036 mov.l 0x0600B154,r11
    c.r[8] = ld32(0x0600B158u);  // 0600B038 mov.l 0x0600B158,r8
L_0600B03A:
    c.r[1] = ld32(c.r[9]);  // 0600B03A mov.l @r9,r1
    { const uint32_t x = c.r[11]; c.pr = 0x0600B040u; c.r[4] = ld32(c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600B040u) return; }  // 0600B03C jsr @r11 ; mov.l @r1,r4
    c.r[10] = c.r[0];  // 0600B040 mov r0,r10
    c.r[6] = c.r[14];  // 0600B042 mov r14,r6
    c.r[6] += 8;  // 0600B044 add #8,r6
    c.r[1] = ld32(c.r[9]);  // 0600B046 mov.l @r9,r1
    c.r[5] = c.r[14];  // 0600B048 mov r14,r5
    c.r[4] = ld32(c.r[1]);  // 0600B04A mov.l @r1,r4
    { const uint32_t x = c.r[8]; c.pr = 0x0600B050u; c.r[5] += 4; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600B050u) return; }  // 0600B04C jsr @r8 ; add #4,r5
    c.r[2] = ld32(c.r[14] + 8);  // 0600B050 mov.l @(8,r14),r2
    c.r[1] = ld32(0x0600B13Cu);  // 0600B052 mov.l 0x0600B13C,r1
    c.r[1] = ld32(c.r[1]);  // 0600B054 mov.l @r1,r1
    c.t = (int32_t)c.r[2] >= (int32_t)c.r[1];  // 0600B056 cmp/ge r1,r2
    { const bool k = c.t; c.t = (int32_t)c.r[10] >= 0; if (k) { goto L_0600B064; } }  // 0600B058 bt/s 0x0600B064 ; cmp/pz r10
    { const bool k = c.t; c.r[0] = c.r[10]; if (k) { SH2_POLL(c); goto L_0600B03A; } }  // 0600B05C bt/s 0x0600B03A ; mov r10,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0600B060 cmp/eq #-1,r0
    if (c.t) { SH2_POLL(c); goto L_0600B03A; }  // 0600B062 bt 0x0600B03A
L_0600B064:
    c.r[11] = ld32(0x0600B144u);  // 0600B064 mov.l 0x0600B144,r11
    c.r[6] = ld32(c.r[11]);  // 0600B066 mov.l @r11,r6
    c.t = (c.r[6] & c.r[6]) == 0;  // 0600B068 tst r6,r6
    { const bool k = c.t; c.t = (int32_t)c.r[10] >= 0; if (k) { goto L_0600B0A8; } }  // 0600B06A bt/s 0x0600B0A8 ; cmp/pz r10
    { const bool k = c.t; c.r[0] = c.r[10]; if (k) { goto L_0600B076; } }  // 0600B06E bt/s 0x0600B076 ; mov r10,r0
    c.t = c.r[0] == 0xFFFFFFFFu;  // 0600B072 cmp/eq #-1,r0
    if (!c.t) { goto L_0600B0A8; }  // 0600B074 bf 0x0600B0A8
L_0600B076:
    c.r[8] = ld32(0x0600B15Cu);  // 0600B076 mov.l 0x0600B15C,r8
    c.r[1] = 0x1u;  // 0600B078 mov #1,r1
    st8(c.r[8], c.r[1]);  // 0600B07A mov.b r1,@r8
    c.r[1] = ld32(c.r[9]);  // 0600B07C mov.l @r9,r1
    c.r[5] = ld32(c.r[1] + 40);  // 0600B07E mov.l @(40,r1),r5
    c.r[4] = ld32(0x0600B160u);  // 0600B080 mov.l 0x0600B160,r4
L_0600B082:
    c.r[1] = ld32(0x0600B164u);  // 0600B082 mov.l 0x0600B164,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0600B088u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600B088u) return; }  // 0600B084 jsr @r1 ; nop
    c.r[1] = ld32(0x0600B168u);  // 0600B088 mov.l 0x0600B168,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0600B08Eu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600B08Eu) return; }  // 0600B08A jsr @r1 ; nop
    c.r[1] = 0x0u;  // 0600B08E mov #0,r1
    st8(c.r[8], c.r[1]);  // 0600B090 mov.b r1,@r8
    c.r[1] = ld32(c.r[9]);  // 0600B092 mov.l @r9,r1
    c.r[3] = ld32(c.r[11]);  // 0600B094 mov.l @r11,r3
    c.r[2] = ld32(c.r[1] + 40);  // 0600B096 mov.l @(40,r1),r2
    c.r[2] += c.r[3];  // 0600B098 add r3,r2
    st32(c.r[1] + 40, c.r[2]);  // 0600B09A mov.l r2,@(40,r1)
    c.r[1] = ld32(0x0600B140u);  // 0600B09C mov.l 0x0600B140,r1
    c.r[2] = ld32(c.r[1]);  // 0600B09E mov.l @r1,r2
    c.r[2] -= c.r[3];  // 0600B0A0 sub r3,r2
    st32(c.r[1], c.r[2]);  // 0600B0A2 mov.l r2,@r1
    c.r[1] = 0x0u;  // 0600B0A4 mov #0,r1
    st32(c.r[11], c.r[1]);  // 0600B0A6 mov.l r1,@r11
L_0600B0A8:
    c.r[1] = ld32(0x0600B16Cu);  // 0600B0A8 mov.l 0x0600B16C,r1
    c.r[0] = ld32(c.r[1]);  // 0600B0AA mov.l @r1,r0
    c.r[0] ^= 0x1u;  // 0600B0AC xor #1,r0
    st32(c.r[1], c.r[0]);  // 0600B0AE mov.l r0,@r1
L_0600B0B0:
    c.r[1] = ld32(0x0600B140u);  // 0600B0B0 mov.l 0x0600B140,r1
    c.r[1] = ld32(c.r[1]);  // 0600B0B2 mov.l @r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0600B0B4 tst r1,r1
    { const bool k = !c.t; c.t = (int32_t)c.r[10] > 0; if (k) { goto L_0600B0D4; } }  // 0600B0B6 bf/s 0x0600B0D4 ; cmp/pl r10
    c.r[8] = ld32(0x0600B170u);  // 0600B0BA mov.l 0x0600B170,r8
    c.r[1] = ld32(0x0600B174u);  // 0600B0BC mov.l 0x0600B174,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0600B0C2u; c.r[4] = ld32(c.r[8]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600B0C2u) return; }  // 0600B0BE jsr @r1 ; mov.l @r8,r4
    c.r[2] = ld32(c.r[8]);  // 0600B0C2 mov.l @r8,r2
    c.r[1] = 0x0u;  // 0600B0C4 mov #0,r1
    c.r[2] += 20;  // 0600B0C6 add #20,r2
    st16(c.r[2], c.r[1]);  // 0600B0C8 mov.w r1,@r2
    c.r[2] = ld32(0x0600B178u);  // 0600B0CA mov.l 0x0600B178,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0600B0CC mov.w @r2,r1
    c.r[1] -= 1;  // 0600B0CE add #-1,r1
    st16(c.r[2], c.r[1]);  // 0600B0D0 mov.w r1,@r2
L_0600B0D2:
    c.t = (int32_t)c.r[10] > 0;  // 0600B0D2 cmp/pl r10
L_0600B0D4:
    { const bool k = c.t; c.r[1] = 0x19u; if (k) { goto L_0600B1AC; } }  // 0600B0D4 bt/s 0x0600B1AC ; mov #25,r1
    c.r[2] = c.r[10];  // 0600B0D8 mov r10,r2
    c.r[2] += 25;  // 0600B0DA add #25,r2
    c.t = c.r[2] > c.r[1];  // 0600B0DC cmp/hi r1,r2
    { const bool k = c.t; c.r[1] = c.r[2]; if (k) { goto L_0600B184; } }  // 0600B0DE bt/s 0x0600B184 ; mov r2,r1
    c.r[1] += c.r[1];  // 0600B0E2 add r1,r1
    c.r[0] = 0x0600B0F0u;  // 0600B0E4 mova 0x0600B0F0,r0
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[1]);  // 0600B0E6 mov.w @(r0,r1),r1
    c.r[0] += c.r[1];  // 0600B0E8 add r1,r0
    { const uint32_t x = c.r[0]; switch (x) { case 0x0600B184u: goto L_0600B184; case 0x0600B12Cu: goto L_0600B12C; case 0x0600B124u: goto L_0600B124; default: sh2_call(c, x); return; } }  // 0600B0EA jmp @r0 ; nop
L_0600B124:
    c.r[2] = ld32(0x0600B17Cu);  // 0600B124 mov.l 0x0600B17C,r2
    c.r[1] = 0x0u;  // 0600B126 mov #0,r1
    st16(c.r[2], c.r[1]); goto L_0600B1AC;  // 0600B128 bra 0x0600B1AC ; mov.w r1,@r2
L_0600B12C:
    c.r[1] = ld32(0x0600B180u);  // 0600B12C mov.l 0x0600B180,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0600B132u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600B132u) return; }  // 0600B12E jsr @r1 ; nop
    goto L_0600B198;  // 0600B132 bra 0x0600B198 ; nop
L_0600B184:
    c.r[1] = ld32(0x0600B1C0u);  // 0600B184 mov.l 0x0600B1C0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0600B18Au; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600B18Au) return; }  // 0600B186 jsr @r1 ; nop
    c.r[7] = ld32(0x0600B1C4u);  // 0600B18A mov.l 0x0600B1C4,r7
    c.r[3] = (uint32_t)(int16_t)ld16(c.r[7]);  // 0600B18C mov.w @r7,r3
    c.r[1] = 0xFu;  // 0600B18E mov #15,r1
    c.r[2] = (uint32_t)(int32_t)(int16_t)c.r[3];  // 0600B190 exts.w r3,r2
    c.t = (int32_t)c.r[2] > (int32_t)c.r[1];  // 0600B192 cmp/gt r1,r2
    { const bool k = !c.t; c.r[1] = c.r[3]; if (k) { goto L_0600B1A8; } }  // 0600B194 bf/s 0x0600B1A8 ; mov r3,r1
L_0600B198:
    c.r[1] = ld32(0x0600B1C8u);  // 0600B198 mov.l 0x0600B1C8,r1
    st32(c.r[1], c.r[10]);  // 0600B19A mov.l r10,@r1
    c.r[1] = ld32(0x0600B1CCu);  // 0600B19C mov.l 0x0600B1CC,r1
    c.r[1] = ld32(c.r[1]);  // 0600B19E mov.l @r1,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0600B1A4u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600B1A4u) return; }  // 0600B1A0 jsr @r1 ; nop
    c.r[14] += 12; goto L_0600B1AE;  // 0600B1A4 bra 0x0600B1AE ; add #12,r14
L_0600B1A8:
    c.r[1] += 1;  // 0600B1A8 add #1,r1
    st16(c.r[7], c.r[1]);  // 0600B1AA mov.w r1,@r7
L_0600B1AC:
    c.r[14] += 12;  // 0600B1AC add #12,r14
L_0600B1AE:
    c.r[15] = c.r[14];  // 0600B1AE mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0600B1B0 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0600B1B2 mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0600B1B4 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0600B1B6 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0600B1B8 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0600B1BA mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0600B1BC rts ; mov.l @r15+,r8
}

void f_0600B1D0(SH2Context& c) {
    ran[63] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0600B1D0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0600B1D2 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0600B1D4 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0600B1D6 sts.l pr,@-r15
    c.r[8] = ld32(0x0600B238u);  // 0600B1D8 mov.l 0x0600B238,r8
    c.r[1] = ld32(c.r[8]);  // 0600B1DA mov.l @r8,r1
    c.r[14] = c.r[15];  // 0600B1DC mov r15,r14
    c.r[0] = ld32(0x0600B23Cu);  // 0600B1DE mov.l 0x0600B23C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0600B1E4u; c.r[4] = ld32(c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600B1E4u) return; }  // 0600B1E0 jsr @r0 ; mov.l @r1,r4
    c.r[1] = ld32(c.r[8]);  // 0600B1E4 mov.l @r8,r1
    c.r[9] = ld32(0x0600B240u);  // 0600B1E6 mov.l 0x0600B240,r9
    { const uint32_t x = c.r[9]; c.pr = 0x0600B1ECu; c.r[4] = ld32(c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600B1ECu) return; }  // 0600B1E8 jsr @r9 ; mov.l @r1,r4
    c.r[1] = ld32(c.r[8]);  // 0600B1EC mov.l @r8,r1
    { const uint32_t x = c.r[9]; c.pr = 0x0600B1F2u; c.r[4] = ld32(c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600B1F2u) return; }  // 0600B1EE jsr @r9 ; mov.l @r1,r4
    c.r[1] = ld32(c.r[8]);  // 0600B1F2 mov.l @r8,r1
    { const uint32_t x = c.r[9]; c.pr = 0x0600B1F8u; c.r[4] = ld32(c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600B1F8u) return; }  // 0600B1F4 jsr @r9 ; mov.l @r1,r4
    c.r[1] = ld32(c.r[8]);  // 0600B1F8 mov.l @r8,r1
    { const uint32_t x = c.r[9]; c.pr = 0x0600B1FEu; c.r[4] = ld32(c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600B1FEu) return; }  // 0600B1FA jsr @r9 ; mov.l @r1,r4
    c.r[1] = ld32(c.r[8]);  // 0600B1FE mov.l @r8,r1
    c.r[4] = ld32(c.r[1]);  // 0600B200 mov.l @r1,r4
    c.r[1] = ld32(0x0600B244u);  // 0600B202 mov.l 0x0600B244,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0600B208u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600B208u) return; }  // 0600B204 jsr @r1 ; nop
    c.r[2] = ld32(c.r[8]);  // 0600B208 mov.l @r8,r2
    c.r[1] = 0x0u;  // 0600B20A mov #0,r1
    c.r[2] += 20;  // 0600B20C add #20,r2
    st16(c.r[2], c.r[1]);  // 0600B20E mov.w r1,@r2
    c.r[2] = ld32(0x0600B248u);  // 0600B210 mov.l 0x0600B248,r2
    c.r[1] = 0xFFFFFFFFu;  // 0600B212 mov #-1,r1
    st32(c.r[2], c.r[1]);  // 0600B214 mov.l r1,@r2
    c.r[2] = ld32(0x0600B24Cu);  // 0600B216 mov.l 0x0600B24C,r2
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0600B218 mov.w @r2,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0600B21A extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0600B21C tst r1,r1
    { const bool k = !c.t; c.r[1] = 0x10u; if (k) { goto L_0600B224; } }  // 0600B21E bf/s 0x0600B224 ; mov #16,r1
    st16(c.r[2], c.r[1]);  // 0600B222 mov.w r1,@r2
L_0600B224:
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0600B224 mov.w @r2,r1
    c.r[15] = c.r[14];  // 0600B226 mov r14,r15
    c.r[1] -= 1;  // 0600B228 add #-1,r1
    st16(c.r[2], c.r[1]);  // 0600B22A mov.w r1,@r2
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0600B22C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0600B22E mov.l @r15+,r14
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0600B230 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0600B232 rts ; mov.l @r15+,r8
}

void f_0600B250(SH2Context& c) {
    ran[64] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0600B250 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0600B252 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0600B254 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0600B256 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0600B258 sts.l pr,@-r15
    c.r[10] = ld32(0x0600B2ACu);  // 0600B25A mov.l 0x0600B2AC,r10
    c.r[1] = ld32(c.r[10]);  // 0600B25C mov.l @r10,r1
    c.r[14] = c.r[15];  // 0600B25E mov r15,r14
    c.r[0] = ld32(0x0600B2B0u);  // 0600B260 mov.l 0x0600B2B0,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0600B266u; c.r[4] = ld32(c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600B266u) return; }  // 0600B262 jsr @r0 ; mov.l @r1,r4
    c.r[9] = ld32(0x0600B2B4u);  // 0600B266 mov.l 0x0600B2B4,r9
    st32(c.r[9], c.r[0]);  // 0600B268 mov.l r0,@r9
    c.r[1] = ld32(c.r[10]);  // 0600B26A mov.l @r10,r1
    c.r[8] = ld32(0x0600B2B8u);  // 0600B26C mov.l 0x0600B2B8,r8
    { const uint32_t x = c.r[8]; c.pr = 0x0600B272u; c.r[4] = ld32(c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600B272u) return; }  // 0600B26E jsr @r8 ; mov.l @r1,r4
    st32(c.r[9], c.r[0]);  // 0600B272 mov.l r0,@r9
    c.r[1] = ld32(c.r[10]);  // 0600B274 mov.l @r10,r1
    { const uint32_t x = c.r[8]; c.pr = 0x0600B27Au; c.r[4] = ld32(c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600B27Au) return; }  // 0600B276 jsr @r8 ; mov.l @r1,r4
    st32(c.r[9], c.r[0]);  // 0600B27A mov.l r0,@r9
    c.r[1] = ld32(c.r[10]);  // 0600B27C mov.l @r10,r1
    { const uint32_t x = c.r[8]; c.pr = 0x0600B282u; c.r[4] = ld32(c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600B282u) return; }  // 0600B27E jsr @r8 ; mov.l @r1,r4
    st32(c.r[9], c.r[0]);  // 0600B282 mov.l r0,@r9
    c.r[1] = ld32(c.r[10]);  // 0600B284 mov.l @r10,r1
    { const uint32_t x = c.r[8]; c.pr = 0x0600B28Au; c.r[4] = ld32(c.r[1]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600B28Au) return; }  // 0600B286 jsr @r8 ; mov.l @r1,r4
    st32(c.r[9], c.r[0]);  // 0600B28A mov.l r0,@r9
    c.r[1] = ld32(c.r[10]);  // 0600B28C mov.l @r10,r1
    c.r[4] = ld32(c.r[1]);  // 0600B28E mov.l @r1,r4
    c.r[1] = ld32(0x0600B2BCu);  // 0600B290 mov.l 0x0600B2BC,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0600B296u; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600B296u) return; }  // 0600B292 jsr @r1 ; nop
    c.r[1] = ld32(0x0600B2C0u);  // 0600B296 mov.l 0x0600B2C0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0600B29Cu; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600B29Cu) return; }  // 0600B298 jsr @r1 ; nop
    c.r[15] = c.r[14];  // 0600B29C mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0600B29E lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0600B2A0 mov.l @r15+,r14
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0600B2A2 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0600B2A4 mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0600B2A6 rts ; mov.l @r15+,r8
}

void f_0600B2C4(SH2Context& c) {
    ran[65] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0600B2C4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0600B2C6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0600B2C8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0600B2CA mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0600B2CC mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0600B2CE mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0600B2D0 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0600B2D2 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0600B2D4 mov r15,r14
    c.r[12] = 0x0u;  // 0600B2D6 mov #0,r12
    c.r[13] = ld32(0x0600B344u);  // 0600B2D8 mov.l 0x0600B344,r13
    c.r[9] = 0x0u;  // 0600B2DA mov #0,r9
    c.r[10] = 0x0u;  // 0600B2DC mov #0,r10
    c.r[8] = c.r[13];  // 0600B2DE mov r13,r8
L_0600B2E0:
    c.r[11] = c.r[8];  // 0600B2E0 mov r8,r11
    c.r[11] += 20;  // 0600B2E2 add #20,r11
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[11]);  // 0600B2E4 mov.w @r11,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0600B2E6 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0600B2E8 tst r1,r1
    { const bool k = c.t; c.r[0] = c.r[10]; if (k) { goto L_0600B2F6; } }  // 0600B2EA bt/s 0x0600B2F6 ; mov r10,r0
    c.r[1] = ld32(0x0600B348u);  // 0600B2EE mov.l 0x0600B348,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0600B2F4u; c.r[4] = ld32(c.r[0] + c.r[13]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600B2F4u) return; }  // 0600B2F0 jsr @r1 ; mov.l @(r0,r13),r4
    c.r[0] = c.r[10];  // 0600B2F4 mov r10,r0
L_0600B2F6:
    st32(c.r[0] + c.r[13], c.r[9]);  // 0600B2F6 mov.l r9,@(r0,r13)
    c.r[1] = c.r[8];  // 0600B2F8 mov r8,r1
    c.r[1] += 18;  // 0600B2FA add #18,r1
    st16(c.r[1], c.r[9]);  // 0600B2FC mov.w r9,@r1
    c.r[1] = c.r[8];  // 0600B2FE mov r8,r1
    c.r[1] += 4;  // 0600B300 add #4,r1
    st8(c.r[1], c.r[9]);  // 0600B302 mov.b r9,@r1
    st16(c.r[11], c.r[9]);  // 0600B304 mov.w r9,@r11
    st32(c.r[8] + 24, c.r[9]);  // 0600B306 mov.l r9,@(24,r8)
    st32(c.r[8] + 28, c.r[9]);  // 0600B308 mov.l r9,@(28,r8)
    st32(c.r[8] + 32, c.r[9]);  // 0600B30A mov.l r9,@(32,r8)
    st32(c.r[8] + 36, c.r[9]);  // 0600B30C mov.l r9,@(36,r8)
    st32(c.r[8] + 40, c.r[9]);  // 0600B30E mov.l r9,@(40,r8)
    c.r[10] += 44;  // 0600B310 add #44,r10
    c.r[12] += 1;  // 0600B312 add #1,r12
    c.r[1] = 0xFu;  // 0600B314 mov #15,r1
    c.t = c.r[12] > c.r[1];  // 0600B316 cmp/hi r1,r12
    { const bool k = !c.t; c.r[8] += 44; if (k) { SH2_POLL(c); goto L_0600B2E0; } }  // 0600B318 bf/s 0x0600B2E0 ; add #44,r8
    c.r[1] = ld32(0x0600B34Cu);  // 0600B31C mov.l 0x0600B34C,r1
    c.r[2] = 0x0u;  // 0600B31E mov #0,r2
    st16(c.r[1], c.r[2]);  // 0600B320 mov.w r2,@r1
    c.r[1] = ld32(0x0600B350u);  // 0600B322 mov.l 0x0600B350,r1
    st16(c.r[1], c.r[2]);  // 0600B324 mov.w r2,@r1
    c.r[1] = ld32(0x0600B354u);  // 0600B326 mov.l 0x0600B354,r1
    st16(c.r[1], c.r[2]);  // 0600B328 mov.w r2,@r1
    c.r[2] = ld32(0x0600B358u);  // 0600B32A mov.l 0x0600B358,r2
    c.r[1] = ld32(0x0600B344u);  // 0600B32C mov.l 0x0600B344,r1
    st32(c.r[2], c.r[1]);  // 0600B32E mov.l r1,@r2
    c.r[15] = c.r[14];  // 0600B330 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0600B332 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0600B334 mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0600B336 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0600B338 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0600B33A mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0600B33C mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0600B33E mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0600B340 rts ; mov.l @r15+,r8
}

void f_0600B35C(SH2Context& c) {
    ran[66] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0600B35C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0600B35E mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0600B360 sts.l pr,@-r15
    c.r[8] = c.r[4];  // 0600B362 mov r4,r8
    c.r[1] = c.r[8];  // 0600B364 mov r8,r1
    c.r[1] += 18;  // 0600B366 add #18,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0600B368 mov.w @r1,r1
    c.r[0] = c.r[1] & 0xFFFFu;  // 0600B36A extu.w r1,r0
    c.r[0] <<= 2;  // 0600B36C shll2 r0
    c.r[1] = ld32(0x0600B394u);  // 0600B36E mov.l 0x0600B394,r1
    c.r[4] = ld32(c.r[0] + c.r[1]);  // 0600B370 mov.l @(r0,r1),r4
    c.r[0] = ld32(0x0600B398u);  // 0600B372 mov.l 0x0600B398,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0600B378u; c.r[14] = c.r[15]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600B378u) return; }  // 0600B374 jsr @r0 ; mov r15,r14
    c.r[1] = c.r[0];  // 0600B378 mov r0,r1
    c.r[0] = ld32(0x0600B39Cu);  // 0600B37A mov.l 0x0600B39C,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0600B380u; c.r[4] = c.r[1]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600B380u) return; }  // 0600B37C jsr @r0 ; mov r1,r4
    st32(c.r[8], c.r[0]);  // 0600B380 mov.l r0,@r8
    c.r[8] += 20;  // 0600B382 add #20,r8
    c.r[1] = 0x1u;  // 0600B384 mov #1,r1
    st16(c.r[8], c.r[1]);  // 0600B386 mov.w r1,@r8
    c.r[15] = c.r[14];  // 0600B388 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0600B38A lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0600B38C mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0600B38E rts ; mov.l @r15+,r8
}

void f_0600B3A0(SH2Context& c) {
    ran[67] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0600B3A0 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0600B3A2 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0600B3A4 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0600B3A6 mov r15,r14
    c.r[8] = c.r[4];  // 0600B3A8 mov r4,r8
    c.r[1] = ld32(0x0600B3D0u);  // 0600B3AA mov.l 0x0600B3D0,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0600B3B0u; c.r[4] = ld32(c.r[8]); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600B3B0u) return; }  // 0600B3AC jsr @r1 ; mov.l @r8,r4
    c.r[2] = c.r[8];  // 0600B3B0 mov r8,r2
    c.r[2] += 20;  // 0600B3B2 add #20,r2
    c.r[1] = 0x0u;  // 0600B3B4 mov #0,r1
    st16(c.r[2], c.r[1]);  // 0600B3B6 mov.w r1,@r2
    c.r[1] = 0x0u;  // 0600B3B8 mov #0,r1
    st32(c.r[8] + 24, c.r[1]);  // 0600B3BA mov.l r1,@(24,r8)
    st32(c.r[8] + 28, c.r[1]);  // 0600B3BC mov.l r1,@(28,r8)
    st32(c.r[8] + 36, c.r[1]);  // 0600B3BE mov.l r1,@(36,r8)
    st32(c.r[8] + 32, c.r[1]);  // 0600B3C0 mov.l r1,@(32,r8)
    st32(c.r[8], c.r[1]);  // 0600B3C2 mov.l r1,@r8
    st32(c.r[8] + 40, c.r[1]);  // 0600B3C4 mov.l r1,@(40,r8)
    c.r[15] = c.r[14];  // 0600B3C6 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0600B3C8 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0600B3CA mov.l @r15+,r14
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0600B3CC rts ; mov.l @r15+,r8
}

void f_0600B3D4(SH2Context& c) {
    ran[68] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0600B3D4 mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0600B3D6 mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0600B3D8 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0600B3DA mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0600B3DC mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0600B3DE mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0600B3E0 sts.l pr,@-r15
    c.r[14] = c.r[15];  // 0600B3E2 mov r15,r14
    c.r[9] = c.r[5];  // 0600B3E4 mov r5,r9
    c.r[11] = c.r[6];  // 0600B3E6 mov r6,r11
    c.r[10] = ld32(0x0600B464u);  // 0600B3E8 mov.l 0x0600B464,r10
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[10]);  // 0600B3EA mov.w @r10,r2
    c.r[1] = 0x2Cu;  // 0600B3EC mov #44,r1
    c.macl = (c.r[2] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 0600B3EE mulu.w r1,r2
    c.r[12] = c.r[7];  // 0600B3F0 mov r7,r12
    c.r[8] = c.macl;  // 0600B3F2 sts macl,r8
    c.r[1] = ld32(0x0600B468u);  // 0600B3F4 mov.l 0x0600B468,r1
    c.r[8] += c.r[1];  // 0600B3F6 add r1,r8
    c.r[1] = c.r[8];  // 0600B3F8 mov r8,r1
    c.r[1] += 20;  // 0600B3FA add #20,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0600B3FC mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0600B3FE extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0600B400 tst r1,r1
    { const bool k = !c.t; c.r[0] = c.r[4] & 0xFFu; if (k) { goto L_0600B44E; } }  // 0600B402 bf/s 0x0600B44E ; extu.b r4,r0
    c.r[1] = c.r[8];  // 0600B406 mov r8,r1
    c.r[1] += 18;  // 0600B408 add #18,r1
    st16(c.r[1], c.r[0]);  // 0600B40A mov.w r0,@r1
    c.r[0] <<= 2;  // 0600B40C shll2 r0
    c.r[1] = ld32(0x0600B46Cu);  // 0600B40E mov.l 0x0600B46C,r1
    c.r[4] = c.r[8];  // 0600B410 mov r8,r4
    c.r[5] = ld32(c.r[0] + c.r[1]);  // 0600B412 mov.l @(r0,r1),r5
    c.r[0] = ld32(0x0600B470u);  // 0600B414 mov.l 0x0600B470,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0600B41Au; c.r[4] += 4; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600B41Au) return; }  // 0600B416 jsr @r0 ; add #4,r4
    st32(c.r[8] + 40, c.r[12]);  // 0600B41A mov.l r12,@(40,r8)
    st32(c.r[8] + 32, c.r[9]);  // 0600B41C mov.l r9,@(32,r8)
    c.r[2] = ld32(0x0600B474u);  // 0600B41E mov.l 0x0600B474,r2
    { const uint32_t x = c.r[2]; c.pr = 0x0600B424u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600B424u) return; }  // 0600B420 jsr @r2 ; mov r9,r4
    st32(c.r[8] + 36, c.r[4]);  // 0600B424 mov.l r4,@(36,r8)
    st32(c.r[8] + 24, c.r[11]);  // 0600B426 mov.l r11,@(24,r8)
    c.r[4] = ld32(c.r[8] + 32);  // 0600B428 mov.l @(32,r8),r4
    c.r[1] = (uint32_t)(int16_t)ld16(0x0600B462u);  // 0600B42A mov.w 0x0600B462,r1
    c.r[4] += c.r[11];  // 0600B42C add r11,r4
    c.r[4] += c.r[1];  // 0600B42E add r1,r4
    { const uint32_t x = c.r[2]; c.pr = 0x0600B434u; c.r[1] = ld32(c.r[8] + 36); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600B434u) return; }  // 0600B430 jsr @r2 ; mov.l @(36,r8),r1
    c.r[4] -= c.r[1];  // 0600B434 sub r1,r4
    st32(c.r[8] + 28, c.r[4]);  // 0600B436 mov.l r4,@(28,r8)
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[10]);  // 0600B438 mov.w @r10,r1
    c.r[2] = ld32(0x0600B478u);  // 0600B43A mov.l 0x0600B478,r2
    c.r[0] = c.r[1];  // 0600B43C mov r1,r0
    c.r[0] += 1;  // 0600B43E add #1,r0
    c.r[0] &= 0xFu;  // 0600B440 and #15,r0
    st16(c.r[10], c.r[0]);  // 0600B442 mov.w r0,@r10
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0600B444 mov.w @r2,r1
    c.r[0] = 0x0u;  // 0600B446 mov #0,r0
    c.r[1] += 1;  // 0600B448 add #1,r1
    st16(c.r[2], c.r[1]); goto L_0600B450;  // 0600B44A bra 0x0600B450 ; mov.w r1,@r2
L_0600B44E:
    c.r[0] = 0xFFFFFFFFu;  // 0600B44E mov #-1,r0
L_0600B450:
    c.r[15] = c.r[14];  // 0600B450 mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0600B452 lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0600B454 mov.l @r15+,r14
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0600B456 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0600B458 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0600B45A mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0600B45C mov.l @r15+,r9
    { const uint32_t x = c.pr; c.r[8] = ld32(c.r[15]); c.r[15] += 4; c.pc = x; return; }  // 0600B45E rts ; mov.l @r15+,r8
}

void f_0600B47C(SH2Context& c) {
    ran[69] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0600B47C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0600B47E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0600B480 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0600B482 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0600B484 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0600B486 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0600B488 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0600B48A sts.l pr,@-r15
    c.r[15] -= 4;  // 0600B48C add #-4,r15
    c.r[14] = c.r[15];  // 0600B48E mov r15,r14
    c.r[4] = c.r[4] & 0xFFu;  // 0600B490 extu.b r4,r4
    st32(c.r[14], c.r[4]);  // 0600B492 mov.l r4,@r14
    c.r[4] = c.r[6] & 0xFFu;  // 0600B494 extu.b r6,r4
    c.r[7] = c.r[7] & 0xFFFFu;  // 0600B496 extu.w r7,r7
    c.macl = c.r[7] * c.r[4];  // 0600B498 mul.l r4,r7
    c.r[8] = c.r[4];  // 0600B49A mov r4,r8
    c.r[10] = ld32(c.r[14] + 36);  // 0600B49C mov.l @(36,r14),r10
    c.r[3] = c.macl;  // 0600B49E sts macl,r3
    c.r[3] <<= 2;  // 0600B4A0 shll2 r3
    c.r[2] = c.r[3];  // 0600B4A2 mov r3,r2
    c.r[0] = c.r[3];  // 0600B4A4 mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 0600B4A6 mov.b @(r0,r5),r1
    c.r[2] += c.r[5];  // 0600B4A8 add r5,r2
    c.r[12] = c.r[1];  // 0600B4AA mov r1,r12
    c.r[12] <<= 16;  // 0600B4AC shll16 r12
    c.r[12] <<= 8;  // 0600B4AE shll8 r12
    c.r[1] = c.r[2];  // 0600B4B0 mov r2,r1
    c.r[1] += 1;  // 0600B4B2 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0600B4B4 mov.b @r1,r1
    c.r[0] = c.r[4];  // 0600B4B6 mov r4,r0
    c.r[1] = c.r[1] & 0xFFu;  // 0600B4B8 extu.b r1,r1
    c.r[1] <<= 16;  // 0600B4BA shll16 r1
    c.r[12] |= c.r[1];  // 0600B4BC or r1,r12
    c.r[1] = c.r[2];  // 0600B4BE mov r2,r1
    c.r[1] += 2;  // 0600B4C0 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0600B4C2 mov.b @r1,r1
    c.r[2] += 3;  // 0600B4C4 add #3,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0600B4C6 extu.b r1,r1
    c.r[1] <<= 8;  // 0600B4C8 shll8 r1
    c.r[12] |= c.r[1];  // 0600B4CA or r1,r12
    c.r[8] <<= 2;  // 0600B4CC shll2 r8
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0600B4CE mov.b @r2,r1
    c.t = c.r[0] == 0x1u;  // 0600B4D0 cmp/eq #1,r0
    c.r[1] = c.r[1] & 0xFFu;  // 0600B4D2 extu.b r1,r1
    { const bool k = !c.t; c.r[12] |= c.r[1]; if (k) { goto L_0600B4DE; } }  // 0600B4D4 bf/s 0x0600B4DE ; or r1,r12
    c.r[1] = c.r[3];  // 0600B4D8 mov r3,r1
    c.r[1] += c.r[8]; goto L_0600B4E6;  // 0600B4DA bra 0x0600B4E6 ; add r8,r1
L_0600B4DE:
    c.r[1] = c.r[4];  // 0600B4DE mov r4,r1
    c.r[1] -= 1;  // 0600B4E0 add #-1,r1
    c.r[1] <<= 2;  // 0600B4E2 shll2 r1
    c.r[1] += c.r[3];  // 0600B4E4 add r3,r1
L_0600B4E6:
    c.r[1] += c.r[5];  // 0600B4E6 add r5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0600B4E8 mov.b @r1,r1
    c.r[0] = c.r[4];  // 0600B4EA mov r4,r0
    c.macl = c.r[7] * c.r[4];  // 0600B4EC mul.l r4,r7
    c.r[6] = c.r[1];  // 0600B4EE mov r1,r6
    c.r[6] <<= 16;  // 0600B4F0 shll16 r6
    c.r[6] <<= 8;  // 0600B4F2 shll8 r6
    c.r[3] = c.macl;  // 0600B4F4 sts macl,r3
    c.r[3] <<= 2;  // 0600B4F6 shll2 r3
    c.t = c.r[0] == 0x1u;  // 0600B4F8 cmp/eq #1,r0
    { const bool k = !c.t; c.r[2] = c.r[3]; if (k) { goto L_0600B504; } }  // 0600B4FA bf/s 0x0600B504 ; mov r3,r2
    c.r[2] += c.r[5];  // 0600B4FE add r5,r2
    c.r[2] += 5; goto L_0600B512;  // 0600B500 bra 0x0600B512 ; add #5,r2
L_0600B504:
    c.r[2] = c.r[5];  // 0600B504 mov r5,r2
    c.r[2] += 1;  // 0600B506 add #1,r2
    c.r[1] = c.r[4];  // 0600B508 mov r4,r1
    c.r[1] -= 1;  // 0600B50A add #-1,r1
    c.r[1] <<= 2;  // 0600B50C shll2 r1
    c.r[3] += c.r[1];  // 0600B50E add r1,r3
    c.r[2] += c.r[3];  // 0600B510 add r3,r2
L_0600B512:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0600B512 mov.b @r2,r1
    c.r[0] = c.r[4];  // 0600B514 mov r4,r0
    c.macl = c.r[7] * c.r[4];  // 0600B516 mul.l r4,r7
    c.r[9] = c.r[1] & 0xFFu;  // 0600B518 extu.b r1,r9
    c.r[9] <<= 16;  // 0600B51A shll16 r9
    c.r[3] = c.macl;  // 0600B51C sts macl,r3
    c.r[3] <<= 2;  // 0600B51E shll2 r3
    c.t = c.r[0] == 0x1u;  // 0600B520 cmp/eq #1,r0
    { const bool k = !c.t; c.r[9] |= c.r[6]; if (k) { goto L_0600B52E; } }  // 0600B522 bf/s 0x0600B52E ; or r6,r9
    c.r[2] = c.r[3];  // 0600B526 mov r3,r2
    c.r[2] += c.r[5];  // 0600B528 add r5,r2
    c.r[2] += 6; goto L_0600B53C;  // 0600B52A bra 0x0600B53C ; add #6,r2
L_0600B52E:
    c.r[2] = c.r[5];  // 0600B52E mov r5,r2
    c.r[2] += 2;  // 0600B530 add #2,r2
    c.r[1] = c.r[4];  // 0600B532 mov r4,r1
    c.r[1] -= 1;  // 0600B534 add #-1,r1
    c.r[1] <<= 2;  // 0600B536 shll2 r1
    c.r[3] += c.r[1];  // 0600B538 add r1,r3
    c.r[2] += c.r[3];  // 0600B53A add r3,r2
L_0600B53C:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0600B53C mov.b @r2,r1
    c.r[0] = c.r[4];  // 0600B53E mov r4,r0
    c.macl = c.r[7] * c.r[4];  // 0600B540 mul.l r4,r7
    c.r[6] = c.r[1] & 0xFFu;  // 0600B542 extu.b r1,r6
    c.r[6] <<= 8;  // 0600B544 shll8 r6
    c.r[3] = c.macl;  // 0600B546 sts macl,r3
    c.r[3] <<= 2;  // 0600B548 shll2 r3
    c.t = c.r[0] == 0x1u;  // 0600B54A cmp/eq #1,r0
    { const bool k = !c.t; c.r[6] |= c.r[9]; if (k) { goto L_0600B558; } }  // 0600B54C bf/s 0x0600B558 ; or r9,r6
    c.r[2] = c.r[3];  // 0600B550 mov r3,r2
    c.r[2] += c.r[5];  // 0600B552 add r5,r2
    c.r[2] += 7; goto L_0600B566;  // 0600B554 bra 0x0600B566 ; add #7,r2
L_0600B558:
    c.r[2] = c.r[5];  // 0600B558 mov r5,r2
    c.r[2] += 3;  // 0600B55A add #3,r2
    c.r[1] = c.r[4];  // 0600B55C mov r4,r1
    c.r[1] -= 1;  // 0600B55E add #-1,r1
    c.r[1] <<= 2;  // 0600B560 shll2 r1
    c.r[3] += c.r[1];  // 0600B562 add r1,r3
    c.r[2] += c.r[3];  // 0600B564 add r3,r2
L_0600B566:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0600B566 mov.b @r2,r1
    c.r[13] = c.r[10];  // 0600B568 mov r10,r13
    c.r[13] += 16;  // 0600B56A add #16,r13
    c.macl = c.r[7] * c.r[4];  // 0600B56C mul.l r4,r7
    c.r[11] = c.r[1] & 0xFFu;  // 0600B56E extu.b r1,r11
    c.r[11] |= c.r[6];  // 0600B570 or r6,r11
    c.r[11] += c.r[8];  // 0600B572 add r8,r11
    c.r[11] -= c.r[12];  // 0600B574 sub r12,r11
    c.r[6] = 0x0u;  // 0600B576 mov #0,r6
    c.r[9] = c.macl;  // 0600B578 sts macl,r9
    c.r[9] <<= 2;  // 0600B57A shll2 r9
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[4];  // 0600B57C cmp/ge r4,r6
    { const bool k = c.t; c.r[9] += c.r[12]; if (k) { goto L_0600B5C4; } }  // 0600B57E bt/s 0x0600B5C4 ; add r12,r9
    c.r[8] = 0x0u;  // 0600B582 mov #0,r8
    c.macl = c.r[7] * c.r[4];  // 0600B584 mul.l r4,r7
L_0600B586:
    c.r[1] = c.macl;  // 0600B586 sts macl,r1
    c.r[1] += c.r[6];  // 0600B588 add r6,r1
    c.r[1] <<= 2;  // 0600B58A shll2 r1
    c.r[2] = c.r[1];  // 0600B58C mov r1,r2
    c.r[2] += c.r[5];  // 0600B58E add r5,r2
    c.r[0] = c.r[1];  // 0600B590 mov r1,r0
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 0600B592 mov.b @(r0,r5),r3
    c.r[6] += 1;  // 0600B594 add #1,r6
    c.r[3] <<= 16;  // 0600B596 shll16 r3
    c.r[3] <<= 8;  // 0600B598 shll8 r3
    c.r[1] = c.r[2];  // 0600B59A mov r2,r1
    c.r[1] += 1;  // 0600B59C add #1,r1
    c.r[0] = c.r[8];  // 0600B59E mov r8,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0600B5A0 mov.b @r1,r1
    c.r[8] += 4;  // 0600B5A2 add #4,r8
    c.r[1] = c.r[1] & 0xFFu;  // 0600B5A4 extu.b r1,r1
    c.r[1] <<= 16;  // 0600B5A6 shll16 r1
    c.r[3] |= c.r[1];  // 0600B5A8 or r1,r3
    c.r[1] = c.r[2];  // 0600B5AA mov r2,r1
    c.r[1] += 2;  // 0600B5AC add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0600B5AE mov.b @r1,r1
    c.r[2] += 3;  // 0600B5B0 add #3,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0600B5B2 extu.b r1,r1
    c.r[1] <<= 8;  // 0600B5B4 shll8 r1
    c.r[3] |= c.r[1];  // 0600B5B6 or r1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0600B5B8 mov.b @r2,r1
    c.t = (int32_t)c.r[6] >= (int32_t)c.r[4];  // 0600B5BA cmp/ge r4,r6
    c.r[1] = c.r[1] & 0xFFu;  // 0600B5BC extu.b r1,r1
    c.r[3] |= c.r[1];  // 0600B5BE or r1,r3
    { const bool k = !c.t; st32(c.r[0] + c.r[10], c.r[3]); if (k) { SH2_POLL(c); goto L_0600B586; } }  // 0600B5C0 bf/s 0x0600B586 ; mov.l r3,@(r0,r10)
L_0600B5C4:
    c.r[12] = (uint32_t)(int16_t)ld16(0x0600B650u);  // 0600B5C4 mov.w 0x0600B650,r12
    c.r[1] = c.r[9];  // 0600B5C6 mov r9,r1
    c.r[1] &= c.r[12];  // 0600B5C8 and r12,r1
    c.r[1] += 16;  // 0600B5CA add #16,r1
    st32(c.r[10] + 12, c.r[1]);  // 0600B5CC mov.l r1,@(12,r10)
    c.r[10] = ld32(0x0600B654u);  // 0600B5CE mov.l 0x0600B654,r10
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[10]);  // 0600B5D0 mov.w @r10,r2
    c.r[1] = 0x2Cu;  // 0600B5D2 mov #44,r1
    c.macl = (c.r[2] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 0600B5D4 mulu.w r1,r2
    c.r[8] = c.macl;  // 0600B5D6 sts macl,r8
    c.r[1] = ld32(0x0600B658u);  // 0600B5D8 mov.l 0x0600B658,r1
    c.r[8] += c.r[1];  // 0600B5DA add r1,r8
    c.r[1] = c.r[8];  // 0600B5DC mov r8,r1
    c.r[1] += 20;  // 0600B5DE add #20,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0600B5E0 mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0600B5E2 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0600B5E4 tst r1,r1
    { const bool k = c.t; c.r[1] = c.r[8]; if (k) { goto L_0600B5EE; } }  // 0600B5E6 bt/s 0x0600B5EE ; mov r8,r1
    c.r[1] = 0xFFFFFFFFu; goto L_0600B638;  // 0600B5EA bra 0x0600B638 ; mov #-1,r1
L_0600B5EE:
    c.r[1] += 18;  // 0600B5EE add #18,r1
    c.r[0] = 0x2u;  // 0600B5F0 mov #2,r0
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[14]);  // 0600B5F2 mov.w @(r0,r14),r0
    c.r[4] = c.r[8];  // 0600B5F4 mov r8,r4
    st16(c.r[1], c.r[0]);  // 0600B5F6 mov.w r0,@r1
    c.r[0] = ld32(c.r[14]);  // 0600B5F8 mov.l @r14,r0
    c.r[1] = ld32(0x0600B65Cu);  // 0600B5FA mov.l 0x0600B65C,r1
    c.r[0] <<= 2;  // 0600B5FC shll2 r0
    st32(c.r[14], c.r[0]);  // 0600B5FE mov.l r0,@r14
    c.r[5] = ld32(c.r[0] + c.r[1]);  // 0600B600 mov.l @(r0,r1),r5
    c.r[0] = ld32(0x0600B660u);  // 0600B602 mov.l 0x0600B660,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0600B608u; c.r[4] += 4; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600B608u) return; }  // 0600B604 jsr @r0 ; add #4,r4
    st32(c.r[8] + 40, c.r[13]);  // 0600B608 mov.l r13,@(40,r8)
    st32(c.r[8] + 32, c.r[9]);  // 0600B60A mov.l r9,@(32,r8)
    c.r[1] = ld32(0x0600B664u);  // 0600B60C mov.l 0x0600B664,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0600B612u; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600B612u) return; }  // 0600B60E jsr @r1 ; mov r9,r4
    st32(c.r[8] + 36, c.r[4]);  // 0600B612 mov.l r4,@(36,r8)
    c.r[4] = ld32(c.r[8] + 32);  // 0600B614 mov.l @(32,r8),r4
    st32(c.r[8] + 24, c.r[11]);  // 0600B616 mov.l r11,@(24,r8)
    c.r[4] += c.r[11];  // 0600B618 add r11,r4
    { const uint32_t x = c.r[1]; c.pr = 0x0600B61Eu; c.r[4] += c.r[12]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600B61Eu) return; }  // 0600B61A jsr @r1 ; add r12,r4
    c.r[1] = ld32(c.r[8] + 36);  // 0600B61E mov.l @(36,r8),r1
    c.r[0] = 0xFu;  // 0600B620 mov #15,r0
    c.r[4] -= c.r[1];  // 0600B622 sub r1,r4
    st32(c.r[8] + 28, c.r[4]);  // 0600B624 mov.l r4,@(28,r8)
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[10]);  // 0600B626 mov.w @r10,r1
    c.r[2] = ld32(0x0600B668u);  // 0600B628 mov.l 0x0600B668,r2
    c.r[1] += 1;  // 0600B62A add #1,r1
    c.r[1] &= c.r[0];  // 0600B62C and r0,r1
    st16(c.r[10], c.r[1]);  // 0600B62E mov.w r1,@r10
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0600B630 mov.w @r2,r1
    c.r[1] += 1;  // 0600B632 add #1,r1
    st16(c.r[2], c.r[1]);  // 0600B634 mov.w r1,@r2
    c.r[1] = 0x0u;  // 0600B636 mov #0,r1
L_0600B638:
    c.r[14] += 4;  // 0600B638 add #4,r14
    c.r[15] = c.r[14];  // 0600B63A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0600B63C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0600B63E mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0600B640 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0600B642 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0600B644 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0600B646 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0600B648 mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0600B64A mov.l @r15+,r8
    { const uint32_t x = c.pr; c.r[0] = c.r[1]; c.pc = x; return; }  // 0600B64C rts ; mov r1,r0
}

void f_0600B66C(SH2Context& c) {
    ran[70] = 1;
    c.r[15] -= 4; st32(c.r[15], c.r[8]);  // 0600B66C mov.l r8,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[9]);  // 0600B66E mov.l r9,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[10]);  // 0600B670 mov.l r10,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[11]);  // 0600B672 mov.l r11,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[12]);  // 0600B674 mov.l r12,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[13]);  // 0600B676 mov.l r13,@-r15
    c.r[15] -= 4; st32(c.r[15], c.r[14]);  // 0600B678 mov.l r14,@-r15
    c.r[15] -= 4; st32(c.r[15], c.pr);  // 0600B67A sts.l pr,@-r15
    c.r[15] -= 8;  // 0600B67C add #-8,r15
    c.r[14] = c.r[15];  // 0600B67E mov r15,r14
    c.r[1] = c.r[5];  // 0600B680 mov r5,r1
    c.r[4] = c.r[4] & 0xFFu;  // 0600B682 extu.b r4,r4
    st32(c.r[14], c.r[4]);  // 0600B684 mov.l r4,@r14
    c.r[8] = c.r[6] & 0xFFu;  // 0600B686 extu.b r6,r8
    c.r[7] = c.r[7] & 0xFFFFu;  // 0600B688 extu.w r7,r7
    c.r[2] = c.r[7];  // 0600B68A mov r7,r2
    c.r[2] >>= 8;  // 0600B68C shlr8 r2
    c.r[0] = 0xFu;  // 0600B68E mov #15,r0
    c.r[2] &= c.r[0];  // 0600B690 and r0,r2
    c.r[10] = c.r[7] & 0xFFu;  // 0600B692 extu.b r7,r10
    c.r[6] = 0x4u;  // 0600B694 mov #4,r6
    c.r[5] = c.r[2];  // 0600B696 mov r2,r5
    c.r[4] = c.r[1];  // 0600B698 mov r1,r4
    c.r[0] = ld32(0x0600B854u);  // 0600B69A mov.l 0x0600B854,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0600B6A0u; c.r[11] = ld32(c.r[14] + 40); SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600B6A0u) return; }  // 0600B69C jsr @r0 ; mov.l @(40,r14),r11
    c.macl = c.r[10] * c.r[8];  // 0600B6A0 mul.l r8,r10
    c.r[5] = c.r[0];  // 0600B6A2 mov r0,r5
    c.r[3] = c.macl;  // 0600B6A4 sts macl,r3
    c.r[3] <<= 2;  // 0600B6A6 shll2 r3
    c.r[2] = c.r[3];  // 0600B6A8 mov r3,r2
    c.r[0] = c.r[3];  // 0600B6AA mov r3,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 0600B6AC mov.b @(r0,r5),r1
    c.r[2] += c.r[5];  // 0600B6AE add r5,r2
    c.r[4] = c.r[1];  // 0600B6B0 mov r1,r4
    c.r[4] <<= 16;  // 0600B6B2 shll16 r4
    c.r[4] <<= 8;  // 0600B6B4 shll8 r4
    c.r[1] = c.r[2];  // 0600B6B6 mov r2,r1
    c.r[1] += 1;  // 0600B6B8 add #1,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0600B6BA mov.b @r1,r1
    c.r[0] = c.r[8];  // 0600B6BC mov r8,r0
    c.r[1] = c.r[1] & 0xFFu;  // 0600B6BE extu.b r1,r1
    c.r[1] <<= 16;  // 0600B6C0 shll16 r1
    c.r[4] |= c.r[1];  // 0600B6C2 or r1,r4
    c.r[1] = c.r[2];  // 0600B6C4 mov r2,r1
    c.r[1] += 2;  // 0600B6C6 add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0600B6C8 mov.b @r1,r1
    c.r[2] += 3;  // 0600B6CA add #3,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0600B6CC extu.b r1,r1
    c.r[1] <<= 8;  // 0600B6CE shll8 r1
    c.r[4] |= c.r[1];  // 0600B6D0 or r1,r4
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0600B6D2 mov.b @r2,r1
    c.t = c.r[0] == 0x1u;  // 0600B6D4 cmp/eq #1,r0
    c.r[1] = c.r[1] & 0xFFu;  // 0600B6D6 extu.b r1,r1
    { const bool k = !c.t; c.r[4] |= c.r[1]; if (k) { goto L_0600B6E2; } }  // 0600B6D8 bf/s 0x0600B6E2 ; or r1,r4
    c.r[1] = c.r[3];  // 0600B6DC mov r3,r1
    c.r[1] += 4; goto L_0600B6EA;  // 0600B6DE bra 0x0600B6EA ; add #4,r1
L_0600B6E2:
    c.r[1] = c.r[8];  // 0600B6E2 mov r8,r1
    c.r[1] -= 1;  // 0600B6E4 add #-1,r1
    c.r[1] <<= 2;  // 0600B6E6 shll2 r1
    c.r[1] += c.r[3];  // 0600B6E8 add r3,r1
L_0600B6EA:
    c.r[1] += c.r[5];  // 0600B6EA add r5,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0600B6EC mov.b @r1,r1
    c.r[0] = c.r[8];  // 0600B6EE mov r8,r0
    c.macl = c.r[10] * c.r[8];  // 0600B6F0 mul.l r8,r10
    c.r[7] = c.r[1];  // 0600B6F2 mov r1,r7
    c.r[7] <<= 16;  // 0600B6F4 shll16 r7
    c.r[7] <<= 8;  // 0600B6F6 shll8 r7
    c.r[3] = c.macl;  // 0600B6F8 sts macl,r3
    c.r[3] <<= 2;  // 0600B6FA shll2 r3
    c.t = c.r[0] == 0x1u;  // 0600B6FC cmp/eq #1,r0
    { const bool k = !c.t; c.r[2] = c.r[3]; if (k) { goto L_0600B708; } }  // 0600B6FE bf/s 0x0600B708 ; mov r3,r2
    c.r[2] += c.r[5];  // 0600B702 add r5,r2
    c.r[2] += 5; goto L_0600B716;  // 0600B704 bra 0x0600B716 ; add #5,r2
L_0600B708:
    c.r[2] = c.r[5];  // 0600B708 mov r5,r2
    c.r[2] += 1;  // 0600B70A add #1,r2
    c.r[1] = c.r[8];  // 0600B70C mov r8,r1
    c.r[1] -= 1;  // 0600B70E add #-1,r1
    c.r[1] <<= 2;  // 0600B710 shll2 r1
    c.r[3] += c.r[1];  // 0600B712 add r1,r3
    c.r[2] += c.r[3];  // 0600B714 add r3,r2
L_0600B716:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0600B716 mov.b @r2,r1
    c.r[0] = c.r[8];  // 0600B718 mov r8,r0
    c.macl = c.r[10] * c.r[8];  // 0600B71A mul.l r8,r10
    c.r[6] = c.r[1] & 0xFFu;  // 0600B71C extu.b r1,r6
    c.r[6] <<= 16;  // 0600B71E shll16 r6
    c.r[3] = c.macl;  // 0600B720 sts macl,r3
    c.r[3] <<= 2;  // 0600B722 shll2 r3
    c.t = c.r[0] == 0x1u;  // 0600B724 cmp/eq #1,r0
    { const bool k = !c.t; c.r[6] |= c.r[7]; if (k) { goto L_0600B732; } }  // 0600B726 bf/s 0x0600B732 ; or r7,r6
    c.r[2] = c.r[3];  // 0600B72A mov r3,r2
    c.r[2] += c.r[5];  // 0600B72C add r5,r2
    c.r[2] += 6; goto L_0600B740;  // 0600B72E bra 0x0600B740 ; add #6,r2
L_0600B732:
    c.r[2] = c.r[5];  // 0600B732 mov r5,r2
    c.r[2] += 2;  // 0600B734 add #2,r2
    c.r[1] = c.r[8];  // 0600B736 mov r8,r1
    c.r[1] -= 1;  // 0600B738 add #-1,r1
    c.r[1] <<= 2;  // 0600B73A shll2 r1
    c.r[3] += c.r[1];  // 0600B73C add r1,r3
    c.r[2] += c.r[3];  // 0600B73E add r3,r2
L_0600B740:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0600B740 mov.b @r2,r1
    c.r[0] = c.r[8];  // 0600B742 mov r8,r0
    c.macl = c.r[10] * c.r[8];  // 0600B744 mul.l r8,r10
    c.r[7] = c.r[1] & 0xFFu;  // 0600B746 extu.b r1,r7
    c.r[7] <<= 8;  // 0600B748 shll8 r7
    c.r[3] = c.macl;  // 0600B74A sts macl,r3
    c.r[3] <<= 2;  // 0600B74C shll2 r3
    c.t = c.r[0] == 0x1u;  // 0600B74E cmp/eq #1,r0
    { const bool k = !c.t; c.r[7] |= c.r[6]; if (k) { goto L_0600B75C; } }  // 0600B750 bf/s 0x0600B75C ; or r6,r7
    c.r[2] = c.r[3];  // 0600B754 mov r3,r2
    c.r[2] += c.r[5];  // 0600B756 add r5,r2
    c.r[2] += 7; goto L_0600B76A;  // 0600B758 bra 0x0600B76A ; add #7,r2
L_0600B75C:
    c.r[2] = c.r[5];  // 0600B75C mov r5,r2
    c.r[2] += 3;  // 0600B75E add #3,r2
    c.r[1] = c.r[8];  // 0600B760 mov r8,r1
    c.r[1] -= 1;  // 0600B762 add #-1,r1
    c.r[1] <<= 2;  // 0600B764 shll2 r1
    c.r[3] += c.r[1];  // 0600B766 add r1,r3
    c.r[2] += c.r[3];  // 0600B768 add r3,r2
L_0600B76A:
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0600B76A mov.b @r2,r1
    c.r[9] = c.r[4];  // 0600B76C mov r4,r9
    c.r[0] = c.r[11];  // 0600B76E mov r11,r0
    c.r[0] += 16;  // 0600B770 add #16,r0
    c.r[12] = c.r[1] & 0xFFu;  // 0600B772 extu.b r1,r12
    c.r[12] |= c.r[7];  // 0600B774 or r7,r12
    c.r[12] -= c.r[9];  // 0600B776 sub r9,r12
    c.r[7] = 0x0u;  // 0600B778 mov #0,r7
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[8];  // 0600B77A cmp/ge r8,r7
    { const bool k = c.t; st32(c.r[14] + 4, c.r[0]); if (k) { goto L_0600B7C2; } }  // 0600B77C bt/s 0x0600B7C2 ; mov.l r0,@(4,r14)
    c.r[6] = 0x0u;  // 0600B780 mov #0,r6
    c.macl = c.r[10] * c.r[8];  // 0600B782 mul.l r8,r10
L_0600B784:
    c.r[1] = c.macl;  // 0600B784 sts macl,r1
    c.r[1] += c.r[7];  // 0600B786 add r7,r1
    c.r[1] <<= 2;  // 0600B788 shll2 r1
    c.r[2] = c.r[1];  // 0600B78A mov r1,r2
    c.r[2] += c.r[5];  // 0600B78C add r5,r2
    c.r[0] = c.r[1];  // 0600B78E mov r1,r0
    c.r[3] = (uint32_t)(int8_t)ld8(c.r[0] + c.r[5]);  // 0600B790 mov.b @(r0,r5),r3
    c.r[7] += 1;  // 0600B792 add #1,r7
    c.r[3] <<= 16;  // 0600B794 shll16 r3
    c.r[3] <<= 8;  // 0600B796 shll8 r3
    c.r[1] = c.r[2];  // 0600B798 mov r2,r1
    c.r[1] += 1;  // 0600B79A add #1,r1
    c.r[0] = c.r[6];  // 0600B79C mov r6,r0
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0600B79E mov.b @r1,r1
    c.r[6] += 4;  // 0600B7A0 add #4,r6
    c.r[1] = c.r[1] & 0xFFu;  // 0600B7A2 extu.b r1,r1
    c.r[1] <<= 16;  // 0600B7A4 shll16 r1
    c.r[3] |= c.r[1];  // 0600B7A6 or r1,r3
    c.r[1] = c.r[2];  // 0600B7A8 mov r2,r1
    c.r[1] += 2;  // 0600B7AA add #2,r1
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[1]);  // 0600B7AC mov.b @r1,r1
    c.r[2] += 3;  // 0600B7AE add #3,r2
    c.r[1] = c.r[1] & 0xFFu;  // 0600B7B0 extu.b r1,r1
    c.r[1] <<= 8;  // 0600B7B2 shll8 r1
    c.r[3] |= c.r[1];  // 0600B7B4 or r1,r3
    c.r[1] = (uint32_t)(int8_t)ld8(c.r[2]);  // 0600B7B6 mov.b @r2,r1
    c.t = (int32_t)c.r[7] >= (int32_t)c.r[8];  // 0600B7B8 cmp/ge r8,r7
    c.r[1] = c.r[1] & 0xFFu;  // 0600B7BA extu.b r1,r1
    c.r[3] |= c.r[1];  // 0600B7BC or r1,r3
    { const bool k = !c.t; st32(c.r[0] + c.r[11], c.r[3]); if (k) { SH2_POLL(c); goto L_0600B784; } }  // 0600B7BE bf/s 0x0600B784 ; mov.l r3,@(r0,r11)
L_0600B7C2:
    c.r[13] = (uint32_t)(int16_t)ld16(0x0600B850u);  // 0600B7C2 mov.w 0x0600B850,r13
    c.r[1] = c.r[9];  // 0600B7C4 mov r9,r1
    c.r[1] &= c.r[13];  // 0600B7C6 and r13,r1
    c.r[1] += 16;  // 0600B7C8 add #16,r1
    st32(c.r[11] + 12, c.r[1]);  // 0600B7CA mov.l r1,@(12,r11)
    c.r[10] = ld32(0x0600B858u);  // 0600B7CC mov.l 0x0600B858,r10
    c.r[2] = (uint32_t)(int16_t)ld16(c.r[10]);  // 0600B7CE mov.w @r10,r2
    c.r[1] = 0x2Cu;  // 0600B7D0 mov #44,r1
    c.macl = (c.r[2] & 0xFFFFu) * (c.r[1] & 0xFFFFu);  // 0600B7D2 mulu.w r1,r2
    c.r[8] = c.macl;  // 0600B7D4 sts macl,r8
    c.r[1] = ld32(0x0600B85Cu);  // 0600B7D6 mov.l 0x0600B85C,r1
    c.r[8] += c.r[1];  // 0600B7D8 add r1,r8
    c.r[1] = c.r[8];  // 0600B7DA mov r8,r1
    c.r[1] += 20;  // 0600B7DC add #20,r1
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[1]);  // 0600B7DE mov.w @r1,r1
    c.r[1] = c.r[1] & 0xFFFFu;  // 0600B7E0 extu.w r1,r1
    c.t = (c.r[1] & c.r[1]) == 0;  // 0600B7E2 tst r1,r1
    { const bool k = c.t; c.r[1] = c.r[8]; if (k) { goto L_0600B7EC; } }  // 0600B7E4 bt/s 0x0600B7EC ; mov r8,r1
    c.r[1] = 0xFFFFFFFFu; goto L_0600B838;  // 0600B7E8 bra 0x0600B838 ; mov #-1,r1
L_0600B7EC:
    c.r[1] += 18;  // 0600B7EC add #18,r1
    c.r[0] = 0x2u;  // 0600B7EE mov #2,r0
    c.r[0] = (uint32_t)(int16_t)ld16(c.r[0] + c.r[14]);  // 0600B7F0 mov.w @(r0,r14),r0
    c.r[4] = c.r[8];  // 0600B7F2 mov r8,r4
    st16(c.r[1], c.r[0]);  // 0600B7F4 mov.w r0,@r1
    c.r[0] = ld32(c.r[14]);  // 0600B7F6 mov.l @r14,r0
    c.r[1] = ld32(0x0600B860u);  // 0600B7F8 mov.l 0x0600B860,r1
    c.r[0] <<= 2;  // 0600B7FA shll2 r0
    st32(c.r[14], c.r[0]);  // 0600B7FC mov.l r0,@r14
    c.r[5] = ld32(c.r[0] + c.r[1]);  // 0600B7FE mov.l @(r0,r1),r5
    c.r[0] = ld32(0x0600B864u);  // 0600B800 mov.l 0x0600B864,r0
    { const uint32_t x = c.r[0]; c.pr = 0x0600B806u; c.r[4] += 4; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600B806u) return; }  // 0600B802 jsr @r0 ; add #4,r4
    st32(c.r[8] + 32, c.r[9]);  // 0600B806 mov.l r9,@(32,r8)
    c.r[1] = ld32(0x0600B868u);  // 0600B808 mov.l 0x0600B868,r1
    { const uint32_t x = c.r[1]; c.pr = 0x0600B80Eu; c.r[4] = c.r[9]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600B80Eu) return; }  // 0600B80A jsr @r1 ; mov r9,r4
    st32(c.r[8] + 36, c.r[4]);  // 0600B80E mov.l r4,@(36,r8)
    st32(c.r[8] + 24, c.r[12]);  // 0600B810 mov.l r12,@(24,r8)
    c.r[4] = ld32(c.r[8] + 32);  // 0600B812 mov.l @(32,r8),r4
    c.r[2] = ld32(0x0600B86Cu);  // 0600B814 mov.l 0x0600B86C,r2
    c.r[0] = ld32(c.r[14] + 4);  // 0600B816 mov.l @(4,r14),r0
    c.r[4] += c.r[12];  // 0600B818 add r12,r4
    { const uint32_t x = c.r[1]; c.pr = 0x0600B81Eu; c.r[4] += c.r[13]; SH2_POLL(c); sh2_call(c, x); if (c.pc != 0x0600B81Eu) return; }  // 0600B81A jsr @r1 ; add r13,r4
    c.r[1] = ld32(c.r[8] + 36);  // 0600B81E mov.l @(36,r8),r1
    st32(c.r[8] + 40, c.r[0]);  // 0600B820 mov.l r0,@(40,r8)
    c.r[4] -= c.r[1];  // 0600B822 sub r1,r4
    st32(c.r[8] + 28, c.r[4]);  // 0600B824 mov.l r4,@(28,r8)
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[10]);  // 0600B826 mov.w @r10,r1
    c.r[0] = 0xFu;  // 0600B828 mov #15,r0
    c.r[1] += 1;  // 0600B82A add #1,r1
    c.r[1] &= c.r[0];  // 0600B82C and r0,r1
    st16(c.r[10], c.r[1]);  // 0600B82E mov.w r1,@r10
    c.r[1] = (uint32_t)(int16_t)ld16(c.r[2]);  // 0600B830 mov.w @r2,r1
    c.r[1] += 1;  // 0600B832 add #1,r1
    st16(c.r[2], c.r[1]);  // 0600B834 mov.w r1,@r2
    c.r[1] = 0x0u;  // 0600B836 mov #0,r1
L_0600B838:
    c.r[14] += 8;  // 0600B838 add #8,r14
    c.r[15] = c.r[14];  // 0600B83A mov r14,r15
    { uint32_t v = ld32(c.r[15]); c.r[15] += 4; c.pr = v; }  // 0600B83C lds.l @r15+,pr
    c.r[14] = ld32(c.r[15]); c.r[15] += 4;  // 0600B83E mov.l @r15+,r14
    c.r[13] = ld32(c.r[15]); c.r[15] += 4;  // 0600B840 mov.l @r15+,r13
    c.r[12] = ld32(c.r[15]); c.r[15] += 4;  // 0600B842 mov.l @r15+,r12
    c.r[11] = ld32(c.r[15]); c.r[15] += 4;  // 0600B844 mov.l @r15+,r11
    c.r[10] = ld32(c.r[15]); c.r[15] += 4;  // 0600B846 mov.l @r15+,r10
    c.r[9] = ld32(c.r[15]); c.r[15] += 4;  // 0600B848 mov.l @r15+,r9
    c.r[8] = ld32(c.r[15]); c.r[15] += 4;  // 0600B84A mov.l @r15+,r8
    { const uint32_t x = c.pr; c.r[0] = c.r[1]; c.pc = x; return; }  // 0600B84C rts ; mov r1,r0
}

}  // namespace p_srwfin_kor
