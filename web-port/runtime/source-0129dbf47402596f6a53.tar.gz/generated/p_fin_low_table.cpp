#include "p_fin_low_funcs.h"

namespace p_fin_low {

static const SH2FuncEntry funcs[] = {
    {0x00200000u, f_00200000},
    {0x0024B2F0u, f_0024B2F0},
    {0x0024B4FCu, f_0024B4FC},
    {0x00288AC8u, f_00288AC8},
    {0x00288B74u, f_00288B74},
    {0x00288BA4u, f_00288BA4},
    {0x00288BD0u, f_00288BD0},
    {0x00288CB0u, f_00288CB0},
    {0x00288D04u, f_00288D04},
    {0x00288FB2u, f_00288FB2},
    {0x00289A94u, f_00289A94},
    {0x00289B58u, f_00289B58},
    {0x00289B78u, f_00289B78},
    {0x00289D78u, f_00289D78},
    {0x00289DACu, f_00289DAC},
    {0x00289F18u, f_00289F18},
    {0x0028AE78u, f_0028AE78},
    {0x0028AEE2u, f_0028AEE2},
    {0x0028AF1Eu, f_0028AF1E},
    {0x0028AF38u, f_0028AF38},
    {0x0028AF4Eu, f_0028AF4E},
    {0x0028B172u, f_0028B172},
    {0x0028B200u, f_0028B200},
    {0x0028B20Cu, f_0028B20C},
    {0x0028B210u, f_0028B210},
    {0x0028B2F6u, f_0028B2F6},
    {0x0028BE2Au, f_0028BE2A},
};

uint8_t ran[27];
static const uint16_t sizes[] = {0, 262, 29, 35, 18, 9, 15, 18, 29, 82, 9, 11, 34, 20, 84, 152, 27, 30, 13, 11, 64, 71, 8, 2, 115, 32, 8};

extern const SH2Module module = {"FIN_LOW", 0x00200000u, 573348u, 0xE8AC6663u, funcs, 27, ran, sizes, true};

}  // namespace p_fin_low
