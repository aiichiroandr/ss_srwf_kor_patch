#pragma once
#include "saturn/sh2.h"

namespace p_fin_resident {
void f_060D9EF0(SH2Context& c);
void f_060D9EFA(SH2Context& c);
void f_060D9FE6(SH2Context& c);
void f_060DA006(SH2Context& c);
void f_060DA1F0(SH2Context& c);
void f_060DA800(SH2Context& c);
void f_060DA82A(SH2Context& c);
void f_060DA854(SH2Context& c);
void f_060DA88A(SH2Context& c);
void f_060DA8BE(SH2Context& c);
void f_060DA8FA(SH2Context& c);
void f_060DA914(SH2Context& c);
void f_060DA92A(SH2Context& c);
void f_060DA9F0(SH2Context& c);
void f_060DAA6A(SH2Context& c);
void f_060DAB4E(SH2Context& c);
void f_060DABDC(SH2Context& c);
void f_060DABEC(SH2Context& c);
void f_060DACD2(SH2Context& c);
void f_060DAD12(SH2Context& c);
void f_060DAD34(SH2Context& c);
void f_060DAD4A(SH2Context& c);
void f_060DAE00(SH2Context& c);
void f_060DAE70(SH2Context& c);
void f_060DAF00(SH2Context& c);
void f_060DB000(SH2Context& c);
void f_060DB100(SH2Context& c);
void f_060DB200(SH2Context& c);
void f_060DB300(SH2Context& c);
void f_060DB400(SH2Context& c);
void f_060DB600(SH2Context& c);
void f_060DB800(SH2Context& c);
void f_060DB900(SH2Context& c);
extern uint8_t ran[];
extern const SH2Module module;
}  // namespace p_fin_resident
