// saturn-recomp runtime — VDP2: the picture of a field, composed in software
// from VRAM, colour RAM, the registers and VDP1's framebuffer.
//
// What is done: the four normal scroll screens (NBG0-NBG3) in cell mode
// (1x1 or 2x2 cells, 1- or 2-word pattern names with the supplement, plane
// sizes, map offsets, 16/256/2048 colours and RGB) and NBG0/NBG1 in bitmap
// mode; NBG0/NBG1's fractional scroll, line scroll and coordinate increments (zoom);
// the sprite layer from VDP1's framebuffer, including rotation parameter A, every sprite type, palette and
// RGB mixed (SPCLMD), with its priorities and colour-calculation ratios;
// priorities with the chip's order for ties (sprite, NBG0, NBG1, NBG2,
// NBG3); special priority and special colour calculation by screen or by
// character, and colour calculation by the colour's MSB; colour calculation
// of the top two layers (the top one's ratio or the second's, or add), with
// the line colour screen (one colour, or one a line) as the second image
// under a top screen that LNCLEN names, or gradation (the screen BOKN names,
// blurred along the line, as the second image); windows 0 and 1, as
// rectangles or line windows, on the scroll screens, the sprite layer and
// colour calculation; the colour offsets A and B; the back screen (one
// colour or one a line); the display bit; the high resolutions (640 and 704
// dots), with double-density interlace composed as one picture of both
// fields' lines (448, 480 or 512), the scroll screens a dot row a line;
// shadows (normal, MSB and transparent) on the scroll screens, the back
// screen and the sprite itself.
// RBG0 A/B rotation and coefficient tables are supported.
// What is not: RBG1 (rotation), vertical-cell scroll,
// mosaic, the sprite window, special priority and colour calculation by dot
// (the special function codes), gradation of RBG0, extended colour
// calculation, the exclusive resolutions. A register that asks for one of them is noted once.
#include "saturn.h"
#include "state.h"
#include "video.h"
#include <algorithm>
#include <cstring>
#include <vector>

uint8_t g_vdp2_vram[0x80000], g_vdp2_cram[0x1000], g_vdp2_regs[0x200];

static uint16_t reg(uint32_t off) { return (uint16_t)(g_vdp2_regs[off] << 8 | g_vdp2_regs[off + 1]); }
static uint8_t vb(uint32_t a) { return g_vdp2_vram[a & 0x7FFFF]; }
static uint16_t vw(uint32_t a) { a &= 0x7FFFE; return (uint16_t)(g_vdp2_vram[a] << 8 | g_vdp2_vram[a + 1]); }

static int32_t signed_bits(uint32_t value, int bits) {
    uint32_t sign = 1u << (bits - 1);
    return (int32_t)((value & (sign * 2 - 1)) ^ sign) - (int32_t)sign;
}

static uint16_t sprite_dot(int x, int y, bool dd) {
    if (!(vdp1_reg_read(0, 2) & 2)) return vdp1_dot(x, y, dd);
    uint32_t table = (((uint32_t)(reg(0xBC) & 7) << 16 | reg(0xBE)) & ~0x41u) * 2;
    auto parameter = [&](uint32_t off, int bits, int shift) {
        return signed_bits(((uint32_t)vw(table + off) << 16 | vw(table + off + 2)) >> shift, bits);
    };
    int32_t sx = parameter(0, 23, 6), sy = parameter(4, 23, 6);
    int32_t vx = parameter(12, 13, 6), vy = parameter(16, 13, 6);
    int32_t dx = parameter(20, 12, 7), dy = parameter(24, 12, 7);
    if (!(reg(0xB2) & 1)) sx += y * vx;
    if (!(reg(0xB2) & 2)) sy += y * vy;
    sx = signed_bits((uint32_t)(sx >> 1), 20);
    sy = signed_bits((uint32_t)(sy >> 1), 20);
    return vdp1_dot((sx + x * dx) >> 9, (sy + x * dy) >> 9, false);
}

int vdp2_lines() {
    switch (reg(0x00) >> 4 & 3) {
    case 1: return 240;
    case 2: return 256;
    default: return 224;
    }
}

static int cram_mode() { return reg(0x0E) >> 12 & 3; }

// A colour RAM entry as 0x00RRGGBB, and its MSB (the colour calculation bit).
static uint32_t decode_cram(uint32_t i, bool* msb) {
    if (cram_mode() == 2) {
        uint32_t a = (i & 0x3FF) * 4;
        uint32_t v = (uint32_t)g_vdp2_cram[a] << 24 | g_vdp2_cram[a + 1] << 16 | g_vdp2_cram[a + 2] << 8 | g_vdp2_cram[a + 3];
        if (msb) *msb = v >> 31;
        return (v & 0xFF) << 16 | (v & 0xFF00) | (v >> 16 & 0xFF);
    }
    uint32_t a = (i & (cram_mode() == 1 ? 0x7FF : 0x3FF)) * 2;
    uint16_t v = (uint16_t)(g_vdp2_cram[a] << 8 | g_vdp2_cram[a + 1]);
    if (msb) *msb = v >> 15;
    return (uint32_t)((v & 0x1F) << 3) << 16 | ((v >> 5 & 0x1F) << 3) << 8 | ((v >> 10 & 0x1F) << 3);
}

// CRAM is immutable during synchronous composition. Decode once per frame,
// including the calculation MSB and hardware address wrapping for each mode.
static uint32_t palette_rgb[2048];
static bool palette_msb[2048];
static void prepare_palette() {
    for (uint32_t i=0;i<2048;++i) palette_rgb[i]=decode_cram(i,&palette_msb[i]);
}
static uint32_t cram(uint32_t i, bool* msb) {
    i &= 2047;
    if(msb) *msb=palette_msb[i];
    return palette_rgb[i];
}

static uint32_t rgb555(uint16_t v) {
    return (uint32_t)((v & 0x1F) << 3) << 16 | ((v >> 5 & 0x1F) << 3) << 8 | ((v >> 10 & 0x1F) << 3);
}

// One layer's pixel on a line.
struct Pix {
    uint32_t rgb;
    uint8_t prio;                               // 0: nothing here
    uint8_t ratio;                              // colour-calculation ratio, 0-31
    bool cc;                                    // colour calculation on
    bool offset;                                // colour offset on
    bool offset_b;                              // ... offset B rather than A
    bool spr, scc;                              // the character's special priority and colour calculation bits
    bool msb;                                   // the colour data's MSB
    bool shade;                                 // an MSB shadow: the sprite dot at half brightness
};

enum { L_SPRITE, L_RBG0, L_NBG0, L_NBG1, L_NBG2, L_NBG3, L_COUNT };

// ---- the scroll screens ---------------------------------------------------------------------
struct Nbg {
    bool on, opaque, bitmap, cell2x2, word1, cnsm;
    int colors;                                 // 0 16, 1 256, 2 2048, 3 32K RGB, 4 16M RGB
    uint16_t supp;                              // the pattern name supplement
    int plane_w, plane_h;                       // in pages
    uint32_t plane[4];                          // A B C D: VRAM addresses
    uint32_t page_bytes;
    int bm_w, bm_h;                             // bitmap size
    uint32_t bm_addr;
    uint16_t bm_pal;
    bool bm_spr, bm_scc;
    uint32_t caos;                              // colour RAM offset, in entries
    int32_t sx, sy, dx, dy;                     // scroll and increments, 8 fraction bits
    uint8_t prio, ratio;
    bool cc, offset, offset_b;
};

static void setup_nbg(int n, Nbg& s) {
    s = Nbg{};
    uint16_t bgon = reg(0x20);
    s.on = bgon >> n & 1;
    s.opaque = bgon >> (8 + n) & 1;
    if (!s.on) return;
    uint16_t chctl = n < 2 ? reg(0x28) : reg(0x2A);
    int sh = (n & 1) * 8;
    if (n < 2) {
        uint16_t c = (uint16_t)(chctl >> sh);
        s.colors = n == 0 ? c >> 4 & 7 : c >> 4 & 3;
        s.bitmap = c >> 1 & 1;
        s.cell2x2 = c & 1;
        int bmsz = c >> 2 & 3;
        s.bm_w = bmsz & 2 ? 1024 : 512;
        s.bm_h = bmsz & 1 ? 512 : 256;
    } else {
        uint16_t c = (uint16_t)(chctl >> ((n - 2) * 4));
        s.colors = c >> 1 & 1;
        s.cell2x2 = c & 1;
    }
    uint16_t pncn = reg(0x30 + n * 2);
    s.word1 = pncn >> 15 & 1;
    s.cnsm = pncn >> 14 & 1;
    s.supp = pncn & 0x3FF;
    int plsz = reg(0x3A) >> (n * 2) & 3;
    s.plane_w = plsz == 0 ? 1 : 2;
    s.plane_h = plsz == 3 ? 2 : 1;
    uint32_t mpof = reg(0x3C) >> (n * 4) & 7;
    s.page_bytes = (s.cell2x2 ? 0x800u : 0x2000u) * (s.word1 ? 1 : 2);
    uint32_t mask = (uint32_t)(s.plane_w * s.plane_h - 1);
    for (int i = 0; i < 4; ++i) {
        uint16_t mp = reg(0x40 + n * 4 + (i / 2) * 2);
        uint32_t m = (mpof << 6 | (uint32_t)(mp >> ((i & 1) * 8) & 0x3F)) & ~mask;
        s.plane[i] = m * s.page_bytes;
    }
    if (s.bitmap) {
        s.bm_addr = mpof * 0x20000;
        uint16_t bmpn = (uint16_t)(reg(0x2C) >> sh);
        s.bm_pal = (uint16_t)((bmpn & 7) << 4);
        s.bm_spr = bmpn >> 5 & 1;
        s.bm_scc = bmpn >> 4 & 1;
    }
    int caos_sh = n * 4;
    s.caos = (uint32_t)(reg(0xE4) >> caos_sh & 7) << 8;
    if (n < 2) {
        uint32_t b = 0x70 + n * 0x10;
        s.sx = (int32_t)((reg(b) & 0x7FF) << 8 | reg(b + 2) >> 8);
        s.sy = (int32_t)((reg(b + 4) & 0x7FF) << 8 | reg(b + 6) >> 8);
        s.dx = (int32_t)((reg(b + 8) & 7) << 8 | reg(b + 10) >> 8);
        s.dy = (int32_t)((reg(b + 12) & 7) << 8 | reg(b + 14) >> 8);
    } else {
        uint32_t b = 0x90 + (n - 2) * 4;
        s.sx = (int32_t)(reg(b) & 0x7FF) << 8;
        s.sy = (int32_t)(reg(b + 2) & 0x7FF) << 8;
        s.dx = s.dy = 0x100;
    }
    uint16_t prin = reg(0xF8 + (n / 2) * 2);
    s.prio = (uint8_t)(prin >> ((n & 1) * 8) & 7);
    uint16_t ccrn = reg(0x108 + (n / 2) * 2);
    s.ratio = (uint8_t)(ccrn >> ((n & 1) * 8) & 0x1F);
    s.cc = reg(0xEC) >> n & 1;
    s.offset = reg(0x110) >> n & 1;
    s.offset_b = reg(0x112) >> n & 1;
}

// the dot of a character (or bitmap) at (x, y) in its own pixels: false if transparent
static bool dot(const Nbg& s, uint32_t base, int x, int y, int width, uint32_t pal, Pix& p) {
    uint32_t i = (uint32_t)(y * width + x);
    uint32_t v;
    switch (s.colors) {
    case 0: v = vb(base + i / 2); v = (i & 1) ? (v & 0xF) : (v >> 4); break;
    case 1: v = vb(base + i); break;
    case 2: v = vw(base + i * 2) & 0x7FF; break;
    case 3: {
        uint16_t w = vw(base + i * 2);
        if (!(w & 0x8000) && !s.opaque) return false;
        p.rgb = rgb555(w);
        p.msb = w >> 15;
        return true;
    }
    default: {
        uint32_t w = (uint32_t)vw(base + i * 4) << 16 | vw(base + i * 4 + 2);
        if (!(w & 0x80000000u) && !s.opaque) return false;
        p.rgb = (w & 0xFF) << 16 | (w & 0xFF00) | (w >> 16 & 0xFF);
        p.msb = w >> 31;
        return true;
    }
    }
    if (v == 0 && !s.opaque) return false;
    uint32_t index = s.colors == 0 ? pal * 16 + v : s.colors == 1 ? (pal & 0x70) * 16 + v : v;
    p.rgb = cram(index + s.caos, &p.msb);
    return true;
}

// RBG0/cell helpers adapted from vs-sr-dev/saturnkit, MIT, commit 1b345ef949e1fa258ce3f693f03c0df8acdfb40d.
static bool cell_pixel(const Nbg& s, const uint32_t* planes, int side, uint32_t sx, uint32_t sy, Pix& p,
                       const uint16_t* pnd_over = nullptr) {
    uint32_t pw = (uint32_t)s.plane_w * 512, ph = (uint32_t)s.plane_h * 512;
    int cs = s.cell2x2 ? 16 : 8;
    uint32_t ix = sx & (pw - 1), iy = sy & (ph - 1);
    uint32_t pnd_addr = 0;
    if (!pnd_over) {
        int pl = (int)(sy >> (9 + (s.plane_h >> 1))) * side + (int)(sx >> (9 + (s.plane_w >> 1)));
        uint32_t page = (iy / 512) * (uint32_t)s.plane_w + ix / 512;
        uint32_t cx = (ix & 511) >> (3 + s.cell2x2), cy = (iy & 511) >> (3 + s.cell2x2);
        uint32_t cpr = 512u >> (3 + s.cell2x2);
        pnd_addr = planes[pl] + page * s.page_bytes + (cy * cpr + cx) * (s.word1 ? 2 : 4);
    }
    uint32_t chr, pal;
    bool hf, vf;
    if (s.word1 || pnd_over) {
        uint16_t w = pnd_over ? *pnd_over : vw(pnd_addr);
        p.spr = s.supp >> 9 & 1; p.scc = s.supp >> 8 & 1;
        pal = s.colors == 0 ? (uint32_t)(w >> 12 & 0xF) | (s.supp >> 1 & 0x70) : (uint32_t)(w >> 8 & 0x70);
        if (!s.cnsm) {
            hf = w & 0x400; vf = w & 0x800;
            chr = s.cell2x2 ? ((w & 0x3FFu) << 2) | (s.supp & 3u) | ((s.supp & 0x1Cu) << 10)
                            : (w & 0x3FFu) | ((s.supp & 0x1Fu) << 10);
        } else {
            hf = vf = false;
            chr = s.cell2x2 ? ((w & 0xFFFu) << 2) | (s.supp & 3u) | ((s.supp & 0x10u) << 10)
                            : (w & 0xFFFu) | ((s.supp & 0x1Cu) << 10);
        }
    } else {
        uint16_t w0 = vw(pnd_addr), w1 = vw(pnd_addr + 2);
        hf = w0 & 0x4000; vf = w0 & 0x8000;
        p.spr = w0 >> 13 & 1; p.scc = w0 >> 12 & 1;
        pal = w0 & 0x7F;
        chr = w1 & 0x7FFF;
    }
    int px = (int)(ix & (cs - 1)), py = (int)(iy & (cs - 1));
    if (hf) px = cs - 1 - px;
    if (vf) py = cs - 1 - py;
    static const uint32_t kCellBytes[] = {32, 64, 128, 128, 256};
    uint32_t base = chr * 0x20;
    if (s.cell2x2) base += (uint32_t)((py >> 3) * 2 + (px >> 3)) * kCellBytes[s.colors];
    return dot(s, base, px & 7, py & 7, 8, pal, p);
}

static bool nbg_pixel(const Nbg& s, int x, int y, Pix& p) {
    uint32_t sx = (uint32_t)(s.sx + x * s.dx) >> 8, sy = (uint32_t)(s.sy + y * s.dy) >> 8;
    if (s.bitmap) {
        p.spr = s.bm_spr; p.scc = s.bm_scc;
        return dot(s, s.bm_addr, sx & (s.bm_w - 1), sy & (s.bm_h - 1), s.bm_w, s.bm_pal, p);
    }
    return cell_pixel(s, s.plane, 2, sx & (s.plane_w * 1024 - 1), sy & (s.plane_h * 1024 - 1), p);
}

// SCRCTL entries are packed X, Y, horizontal increment, in that order.
// A Y entry replaces the accumulated screen-line coordinate for its interval.
static Nbg nbg_line(const Nbg& base, int n, int y) {
    Nbg line = base;
    line.sy += y * base.dy;
    if (n >= 2 || !base.on) return line;
    unsigned control = reg(0x9A) >> (n * 8);
    unsigned fields = control & 0xE;
    if (!fields) return line;
    unsigned interval = 1u << ((control >> 4) & 3);
    unsigned count = !!(fields & 2) + !!(fields & 4) + !!(fields & 8);
    unsigned ar = 0xA0 + n * 4;
    uint32_t address = (((reg(ar) & 7u) << 16) | (reg(ar + 2) & 0xFFFEu)) * 2;
    address += (unsigned)y / interval * count * 4;
    auto next = [&](unsigned mask) {
        int32_t value = (vw(address) & mask) * 256 + (vw(address + 2) >> 8);
        address += 4;
        return value;
    };
    if (fields & 2) line.sx += next(0x7FF);
    if (fields & 4) line.sy = base.sy + next(0x7FF) + (y % interval) * base.dy;
    if (fields & 8) line.dx = next(7);
    return line;
}

// ---- the rotation screen RBG0 -----------------------------------------------------------------
// Each dot's map coordinates come from rotation parameter A or B (RPMD: A, B, or B where A's
// coefficient is transparent). A parameter is a table in VRAM (RPTA, A then B 0x80 bytes on):
// the screen's start (Xst, Yst, Zst) and its steps per line (dXst, dYst) and per dot (dX, dY),
// the matrix A-F, the viewpoint P, the centre C, the shift M and the scale kx, ky. A coefficient
// table (KTCTL, KTAOF) may give, per line or per dot, kx and ky, one of them, or Xp, and a
// transparent bit. The map is 4x4 planes of the parameter's plane size, or a bitmap; outside it
// (PLSZ's screen-over) it repeats, shows one pattern (OVPNR), or is transparent.
struct RotParam {
    Nbg chr;                                    // characters, plane size, the map's pattern names
    uint32_t plane[16];
    int32_t xst, yst, zst, dxst, dyst, dx, dy, m[6], px, py, pz, cx, cy, cz, mx, my, kx, ky;
    uint32_t ka0;                               // KTAOF and KAst, 10 fraction bits
    int32_t dkast, dkax;
    bool coef, coef1w;
    int coef_mode, over;
    uint16_t over_pn;
    // on the current line
    int32_t xsp, ysp, xp, yp, ldx, ldy;
    uint32_t ka, line_coef;
};

struct Rbg {
    bool on;
    int mode;                                   // RPMD
    bool crkte, perdot, bank_coef[4];
    RotParam par[2];
    uint8_t prio, ratio;
    bool cc, offset, offset_b;
};

static int32_t sext(uint32_t v, int bits) { return (int32_t)(v << (32 - bits)) >> (32 - bits); }
static uint32_t vl(uint32_t a) { return (uint32_t)vw(a) << 16 | vw(a + 2); }

static void setup_rbg(Rbg& r) {
    r = Rbg{};
    uint16_t bgon = reg(0x20);
    r.on = bgon >> 4 & 1;
    if (!r.on) return;
    r.mode = reg(0xB0) & 3;
    uint16_t ramctl = reg(0x0E);
    r.crkte = ramctl >> 15 & 1;
    for (int b = 0; b < 4; ++b) {                // which VRAM banks hold coefficients (RDBS), split or not
        int esb = b & (2 | (ramctl >> (8 + (b >> 1)) & 1));
        r.bank_coef[b] = r.crkte || (ramctl >> (esb * 2) & 3) == 1;
        r.perdot |= r.bank_coef[b];
    }
    r.prio = (uint8_t)(reg(0xFC) & 7);
    r.ratio = (uint8_t)(reg(0x10C) & 0x1F);
    r.cc = reg(0xEC) >> 4 & 1;
    r.offset = reg(0x110) >> 4 & 1;
    r.offset_b = reg(0x112) >> 4 & 1;
    uint16_t chctl = (uint16_t)(reg(0x2A) >> 8), pncr = reg(0x38);
    uint32_t rpta = ((uint32_t)(reg(0xBC) & 7) << 16 | (reg(0xBE) & 0xFFFE)) * 2 & 0xFFF7C;
    for (int i = 0; i < 2; ++i) {
        RotParam& p = r.par[i];
        Nbg& s = p.chr;
        s.on = true;
        s.opaque = bgon >> 12 & 1;
        s.colors = chctl >> 4 & 7;
        s.bitmap = i == 0 && (chctl >> 1 & 1);
        s.cell2x2 = chctl & 1;
        s.bm_w = 512;
        s.bm_h = chctl >> 2 & 1 ? 512 : 256;
        s.bm_pal = (uint16_t)((reg(0x2E) & 7) << 4);
        s.bm_spr = reg(0x2E) >> 5 & 1;
        s.bm_scc = reg(0x2E) >> 4 & 1;
        s.word1 = pncr >> 15 & 1;
        s.cnsm = pncr >> 14 & 1;
        s.supp = pncr & 0x3FF;
        s.caos = (uint32_t)(reg(0xE6) & 7) << 8;
        int plsz = reg(0x3A) >> (8 + i * 4) & 3;
        s.plane_w = plsz == 0 ? 1 : 2;
        s.plane_h = plsz == 3 ? 2 : 1;
        s.page_bytes = (s.cell2x2 ? 0x800u : 0x2000u) * (s.word1 ? 1 : 2);
        p.over = reg(0x3A) >> (10 + i * 4) & 3;
        p.over_pn = reg(0xB8 + i * 2);
        uint32_t mpof = reg(0x3E) >> (i * 4) & 7, mask = (uint32_t)(s.plane_w * s.plane_h - 1);
        for (int k = 0; k < 16; ++k) {
            uint32_t mp = reg(0x50 + i * 0x10 + (k / 2) * 2) >> ((k & 1) * 8) & 0x3F;
            p.plane[k] = ((mpof << 6 | mp) & ~mask) * s.page_bytes;
        }
        s.bm_addr = mpof * 0x20000;
        uint32_t a = rpta + (uint32_t)i * 0x80;
        p.xst = sext(vl(a + 0x00) >> 6, 23);
        p.yst = sext(vl(a + 0x04) >> 6, 23);
        p.zst = sext(vl(a + 0x08) >> 6, 23);
        p.dxst = sext(vl(a + 0x0C) >> 6, 13);
        p.dyst = sext(vl(a + 0x10) >> 6, 13);
        p.dx = sext(vl(a + 0x14) >> 6, 13);
        p.dy = sext(vl(a + 0x18) >> 6, 13);
        for (int k = 0; k < 6; ++k) p.m[k] = sext(vl(a + 0x1C + k * 4) >> 6, 14);
        p.px = sext(vw(a + 0x34), 14); p.py = sext(vw(a + 0x36), 14); p.pz = sext(vw(a + 0x38), 14);
        p.cx = sext(vw(a + 0x3C), 14); p.cy = sext(vw(a + 0x3E), 14); p.cz = sext(vw(a + 0x40), 14);
        p.mx = sext(vl(a + 0x44) >> 6, 24);
        p.my = sext(vl(a + 0x48) >> 6, 24);
        p.kx = sext(vl(a + 0x4C), 24);
        p.ky = sext(vl(a + 0x50), 24);
        uint16_t ktctl = (uint16_t)(reg(0xB4) >> (i * 8));
        p.coef = ktctl & 1;
        p.coef1w = ktctl >> 1 & 1;
        p.coef_mode = ktctl >> 2 & 3;
        p.ka0 = ((uint32_t)(reg(0xB6) >> (i * 8) & 7) << 26) + (vl(a + 0x54) >> 6);
        p.dkast = sext(vl(a + 0x58) >> 6, 20);
        p.dkax = sext(vl(a + 0x5C) >> 6, 20);
    }
}

// a coefficient's address (in words) from its table address (10 fraction bits)
static uint32_t coef_addr(const Rbg& r, const RotParam& p, uint32_t ka) {
    uint32_t a = (ka >> 10) << (p.coef1w ? 0 : 1);
    return a & (r.crkte ? 0x3FFu : 0x3FFFFu);
}

// a coefficient: bit 31 transparent, bits 23-0 the value (7.16)
static uint32_t coef_read(const Rbg& r, const RotParam& p, uint32_t addr) {
    auto word = [&](uint32_t w) -> uint16_t {
        if (!r.crkte) return vw(w * 2);
        uint32_t b = (0x800 + w * 2) & 0xFFE;
        return (uint16_t)(g_vdp2_cram[b] << 8 | g_vdp2_cram[b + 1]);
    };
    if (p.coef1w) {
        uint16_t t = word(addr);
        return ((uint32_t)sext((uint32_t)t << 6, 21) & 0xFFFFFF) | (uint32_t)(t & 0x8000) << 16;
    }
    return (uint32_t)word(addr) << 16 | word(addr + 1);
}

static void rbg_line(Rbg& r, int y) {
    for (RotParam& p : r.par) {
        int64_t x0 = p.xst + (int64_t)p.dxst * y - p.px * 1024, y0 = p.yst + (int64_t)p.dyst * y - p.py * 1024;
        int64_t z0 = p.zst - p.pz * 1024;
        p.xsp = (int32_t)((p.m[0] * x0 + p.m[1] * y0 + p.m[2] * z0) >> 10);
        p.ysp = (int32_t)((p.m[3] * x0 + p.m[4] * y0 + p.m[5] * z0) >> 10);
        p.xp = p.m[0] * (p.px - p.cx) + p.m[1] * (p.py - p.cy) + p.m[2] * (p.pz - p.cz) + p.cx * 1024 + p.mx;
        p.yp = p.m[3] * (p.px - p.cx) + p.m[4] * (p.py - p.cy) + p.m[5] * (p.pz - p.cz) + p.cy * 1024 + p.my;
        p.ldx = (p.m[0] * p.dx + p.m[1] * p.dy) >> 10;
        p.ldy = (p.m[3] * p.dx + p.m[4] * p.dy) >> 10;
        p.ka = p.ka0 + (uint32_t)(p.dkast * y);
        p.line_coef = coef_read(r, p, coef_addr(r, p, p.ka));
    }
}

static bool rbg_pixel(const Rbg& r, int x, Pix& out) {
    int sel = r.mode == 1 ? 1 : 0;              // RPMD 3 (by the rotation-parameter window) is taken as A
    auto coef_at = [&](int i) {
        const RotParam& p = r.par[i];
        if (!r.perdot) return p.line_coef;
        uint32_t a = coef_addr(r, p, p.ka + (uint32_t)(x * p.dkax));
        return r.bank_coef[r.crkte ? 0 : (a >> 16) & 3] ? coef_read(r, p, a) : 0u;
    };
    uint32_t c = 0;
    if (r.mode == 2) {
        c = r.par[0].coef ? coef_at(0) : 0;
        if (c >> 31) { sel = 1; c = r.par[1].line_coef; }
    } else if (r.par[sel].coef) {
        c = coef_at(sel);
    }
    const RotParam& p = r.par[sel];
    int32_t kx = p.kx, ky = p.ky;
    uint32_t xp = (uint32_t)p.xp;
    if (p.coef) {
        if (c >> 31) return false;              // a transparent coefficient
        int32_t v = sext(c, 24);
        switch (p.coef_mode) {
        case 0: kx = ky = v; break;
        case 1: kx = v; break;
        case 2: ky = v; break;
        default: xp = (uint32_t)v << 2; break;
        }
    }
    uint32_t ix = (xp + (uint32_t)(((int64_t)kx * (int32_t)(p.xsp + p.ldx * x)) >> 16)) >> 10;
    uint32_t iy = ((uint32_t)p.yp + (uint32_t)(((int64_t)ky * (int32_t)(p.ysp + p.ldy * x)) >> 16)) >> 10;
    const Nbg& s = p.chr;
    uint32_t mw = s.bitmap ? (uint32_t)s.bm_w : (uint32_t)s.plane_w * 512 * 4;
    uint32_t mh = s.bitmap ? (uint32_t)s.bm_h : (uint32_t)s.plane_h * 512 * 4;
    bool outside = false;
    if (p.over == 3) outside = (ix | iy) & ~511u;
    else if (p.over) outside = (ix & ~(mw - 1)) || (iy & ~(mh - 1));
    if (outside && (p.over & 2)) return false;
    if (s.bitmap) {
        out.spr = s.bm_spr; out.scc = s.bm_scc;
        return dot(s, s.bm_addr, (int)(ix & (mw - 1)), (int)(iy & (mh - 1)), s.bm_w, s.bm_pal, out);
    }
    return cell_pixel(s, p.plane, 4, ix & (mw - 1), iy & (mh - 1), out, outside ? &p.over_pn : nullptr);
}

// ---- the sprite layer -----------------------------------------------------------------------
struct SpriteType { int pr_shift, pr_mask, cc_shift, cc_mask, dc_mask; };
static const SpriteType kTypes[16] = {
    {14, 3, 11, 7, 0x7FF}, {13, 7, 11, 3, 0x7FF}, {14, 1, 11, 7, 0x7FF}, {13, 3, 11, 3, 0x7FF},
    {13, 3, 10, 7, 0x3FF}, {12, 7, 11, 1, 0x7FF}, {12, 7, 10, 3, 0x3FF}, {12, 7, 9, 7, 0x1FF},
    {7, 1, 0, 0, 0x7F},    {7, 1, 6, 1, 0x3F},    {6, 3, 0, 0, 0x3F},    {0, 0, 6, 3, 0x3F},
    {7, 1, 0, 0, 0xFF},    {7, 1, 6, 1, 0xFF},    {6, 3, 0, 0, 0xFF},    {0, 0, 6, 3, 0xFF},
};

// S_SHADOW is a dot that shows nothing itself and halves the brightness of what is under it.
enum SpriteDot { S_NONE, S_DOT, S_SHADOW };

static SpriteDot sprite_pixel(uint16_t d, Pix& p) {
    uint16_t spctl = reg(0xE0);
    int type = spctl & 0xF;
    bool window = spctl >> 4 & 1;
    bool mixed = spctl >> 5 & 1;
    int ccmode = spctl >> 12 & 3, ccnum = spctl >> 8 & 7;
    if (d == 0) return S_NONE;
    auto prio_of = [](int i) { return (uint8_t)(reg(0xF0 + (i / 2) * 2) >> ((i & 1) * 8) & 7); };
    auto ratio_of = [](int i) { return (uint8_t)(reg(0x100 + (i / 2) * 2) >> ((i & 1) * 8) & 0x1F); };
    bool msb;
    SpriteDot kind = S_DOT;
    if (mixed && (d & 0x8000)) {
        p.rgb = rgb555(d);
        p.prio = prio_of(0);
        p.ratio = ratio_of(0);
        msb = true;
    } else {
        const SpriteType& t = kTypes[type];
        if (type >= 8) d &= 0xFF;
        uint16_t dc = d & t.dc_mask;
        // Types 2-7 leave the MSB free, for the sprite window when SPWINEN is set and for shadows when not.
        bool msb_shadow = type >= 2 && type <= 7 && !window && (d & 0x8000);
        if (dc == t.dc_mask - 1) kind = S_SHADOW;                       // a normal shadow
        else if (msb_shadow && !(d & 0x7FFF)) {
            if (!(reg(0xE2) >> 8 & 1)) return S_NONE;                    // transparent shadows off (TPSDSL)
            kind = S_SHADOW;
        } else if (dc == 0) return S_NONE;
        p.shade = msb_shadow;
        int pr = t.pr_mask ? d >> t.pr_shift & t.pr_mask : 0;
        int cc = t.cc_mask ? d >> t.cc_shift & t.cc_mask : 0;
        p.prio = prio_of(pr);
        p.ratio = ratio_of(cc);
        uint32_t caos = (uint32_t)(reg(0xE6) >> 4 & 7) << 8;
        p.rgb = cram(dc + caos, &msb);
    }
    switch (ccmode) {
    case 0: p.cc = p.prio <= ccnum; break;
    case 1: p.cc = p.prio == ccnum; break;
    case 2: p.cc = p.prio >= ccnum; break;
    default: p.cc = msb; break;
    }
    p.cc = p.cc && (reg(0xEC) >> 6 & 1);
    p.offset = reg(0x110) >> 6 & 1;
    p.offset_b = reg(0x112) >> 6 & 1;
    return p.prio ? kind : S_NONE;
}

// ---- windows ----------------------------------------------------------------------------------
// Window 0 or 1 on one line: the line in its Y range, and its X span there.
struct Win { bool on_line; int xs, xe; };

static Win window_line(int w, int y, bool dd) {
    uint32_t b = 0xC0 + w * 8;
    int xs = reg(b) & 0x3FF, xe = reg(b + 4) & 0x3FF;
    uint16_t lwta = reg(0xD8 + w * 4);
    if (lwta & 0x8000) {                         // a line window: a span a line from the table
        uint32_t a = (((uint32_t)(lwta & 7) << 16 | reg(0xDA + w * 4)) & 0x7FFFE) * 2 + (uint32_t)y * 4;
        xs = vw(a) & 0x3FF;
        xe = vw(a + 2) & 0x3FF;
    }
    if (!(reg(0x00) & 2)) { xs >>= 1; xe >>= 1; } // X counts half dots below the high resolutions
    int ys = reg(b + 2) & 0x3FF, ye = reg(b + 6) & 0x3FF;
    if (!dd) { ys &= 0x1FF; ye &= 0x1FF; }
    return {y >= ys && y <= ye, xs, xe};
}

// Whether a layer's window control byte (WCTLA-D) makes dot x transparent: each enabled window's
// area (bit 0 or 2: inside when clear, outside when set), joined by OR or by AND (bit 7).
static bool windowed(uint8_t ctl, const Win w[2], int x) {
    bool any = false, all = true, used = false;
    for (int i = 0; i < 2; ++i) {
        if (!(ctl >> (i * 2 + 1) & 1)) continue;
        bool in = w[i].on_line && x >= w[i].xs && x <= w[i].xe;
        bool area = (ctl >> (i * 2) & 1) ? !in : in;
        any |= area;
        all &= area;
        used = true;
    }
    return used && (ctl & 0x80 ? all : any);
}

// ---- composing ------------------------------------------------------------------------------
static void note_unsupported() {
    static bool noted[9];
    bool fresh = false;
    auto once = [&](int i, bool cond, const char* what, uint16_t v) {
        if (cond && !noted[i]) { noted[i] = fresh = true; sat_note("VDP2: %s (%04X) is not done", what, v); }
    };
    once(0, (reg(0x20) & 0x20) || ((reg(0x20) & 0x10) && (reg(0xB0) & 3) == 3), "RBG1/rotation parameter window", reg(0x20));
    once(1, reg(0x9A) & 0x0101, "vertical cell scroll (SCRCTL)", reg(0x9A));
    once(2, reg(0x22) & 0xF, "mosaic (MZCTL)", reg(0x22));
    once(3, (reg(0xD0) | reg(0xD2) | reg(0xD4) | reg(0xD6)) & 0x2020, "the sprite window (WCTL)", reg(0xD0));
    once(4, (reg(0xEC) & 0x8400) == 0x0400 && reg(0xEC) & 0x5F, "extended colour calculation (CCCTL)", reg(0xEC));
    once(8, reg(0xEC) & 0x8000 && (reg(0xEC) >> 12 & 7) == 1, "gradation of RBG0 (CCCTL)", reg(0xEC));
    once(5, (reg(0x00) & 7) >= 4, "an exclusive resolution (TVMD)", reg(0x00));
    auto mode = [](uint16_t r, int m) {
        for (int n = 0; n < 4; ++n) if ((r >> (n * 2) & 3) == m) return true;
        return false;
    };
    once(6, reg(0xE8) & 0x10, "the line colour screen under RBG0 (LNCLEN)", reg(0xE8));
    once(7, mode(reg(0xEA), 2) || mode(reg(0xEE), 2), "special priority or colour calculation by dot (SFPRMD, SFCCMD)", reg(0xEA));
}

static uint32_t apply_offset(uint32_t rgb, bool b) {
    uint32_t base = b ? 0x11A : 0x114;
    int out = 0;
    for (int i = 0; i < 3; ++i) {
        int o = (int)((uint32_t)(reg(base + i * 2) & 0x1FF) << 23) >> 23;
        int c = (int)(rgb >> (16 - i * 8) & 0xFF) + o;
        out = out << 8 | std::clamp(c, 0, 255);
    }
    return (uint32_t)out;
}

template<bool Sparse>
static void compose_frame(Frame& f) {
    uint16_t tvmd = reg(0x00);
    static const int kWidths[4] = {320, 352, 640, 704};
    int hreso = tvmd & 7;
    f.w = kWidths[hreso < 4 ? hreso : hreso & 1];
    bool dd = (tvmd >> 6 & 3) == 3;              // double-density interlace
    f.h = vdp2_lines() * (dd ? 2 : 1);
    f.px.assign((size_t)f.w * f.h, 0);
    if (!(tvmd & 0x8000)) return;                // display off
    note_unsupported();
    Rbg rbg;
    setup_rbg(rbg);
    Nbg nbg[4];
    for (int n = 0; n < 4; ++n) setup_nbg(n, nbg[n]);
    // Layer enable/priority cannot change during this synchronous composition.
    // Preserve original tie order, and retain all row states for gradation.
    int active_nbg[4], active_nbg_count = 0;
    for (int n = 0; n < 4; ++n)
        if (nbg[n].on && nbg[n].prio) active_nbg[active_nbg_count++] = n;
    const bool sprite_rotated = (vdp1_reg_read(0, 2) & 2) != 0;
    uint32_t bk = ((uint32_t)(reg(0xAC) & 7) << 16 | reg(0xAE)) * 2;
    bool bk_lines = reg(0xAC) & 0x8000;
    bool add = reg(0xEC) >> 8 & 1;
    bool second_ratio = reg(0xEC) >> 9 & 1;      // CCRTMD: the ratio is the second image's
    Pix back{};
    back.offset = reg(0x110) >> 5 & 1;
    back.offset_b = reg(0x112) >> 5 & 1;
    back.ratio = (uint8_t)(reg(0x10E) >> 8 & 0x1F);
    // the line colour screen: inserted as the second image under a top screen LNCLEN names
    uint16_t lnclen = reg(0xE8);
    uint32_t lc_table = ((uint32_t)(reg(0xA8) & 7) << 16 | reg(0xAA)) * 2;
    bool lc_lines = reg(0xA8) & 0x8000;
    Pix line_colour{};
    line_colour.ratio = (uint8_t)(reg(0x10E) & 0x1F);
    uint16_t sfprmd = reg(0xEA), sfccmd = reg(0xEE);
    uint8_t wctl[L_COUNT] = {(uint8_t)(reg(0xD4) >> 8), (uint8_t)reg(0xD4), (uint8_t)reg(0xD0), (uint8_t)(reg(0xD0) >> 8),
                             (uint8_t)reg(0xD2), (uint8_t)(reg(0xD2) >> 8)};
    uint8_t cc_wctl = (uint8_t)(reg(0xD6) >> 8);
    uint16_t sdctl = reg(0xE2);
    // gradation: the screen BOKN names, blurred along the line, as the second image wherever it is the
    // top or second image of a colour calculation
    static const int kGradLayer[8] = {L_SPRITE, -1, L_NBG0, -1, L_NBG1, L_NBG2, L_NBG3, -1};
    int grad = reg(0xEC) & 0x8000 && hreso < 2 && cram_mode() == 0 ? kGradLayer[reg(0xEC) >> 12 & 7] : -1;
    std::vector<uint32_t> blur(grad >= 0 ? f.w : 0);
    for (int y = 0; y < f.h; ++y) {
        int sprite_width = 0;
        const uint16_t* sprite_row = sprite_rotated ? nullptr : vdp1_display_row(y, dd, sprite_width);
        auto sprite_at = [&](int x) -> uint16_t {
            return sprite_row ? (x < sprite_width ? sprite_row[x] : 0) : sprite_dot(x, y, dd);
        };
        int line = dd ? y >> 1 : y;
        Nbg row[4];
        for (int n = 0; n < 4; ++n) row[n] = nbg_line(nbg[n], n, y);
        if (rbg.on) rbg_line(rbg, y);
        Win win[2] = {window_line(0, y, dd), window_line(1, y, dd)};
        back.rgb = rgb555(vw(bk + (bk_lines ? (uint32_t)line * 2 : 0)));
        // a table word a line, a line of either field in double-density interlace
        line_colour.rgb = cram(vw(lc_table + (lc_lines ? (uint32_t)y * 2 : 0)) & 0x7FF, nullptr);
        if (grad >= 0) {
            // each dot averaged with the average of the two before it; a dot the screen does not draw is black
            auto avg = [](uint32_t a, uint32_t b) { return (a + b - ((a ^ b) & 0x010101)) >> 1; };
            uint32_t prev[2] = {0, 0};
            for (int x = 0; x < f.w; ++x) {
                Pix p{};
                bool drawn = grad == L_SPRITE ? sprite_pixel(sprite_at(x), p) == S_DOT
                                              : nbg[grad - L_NBG0].on && nbg_pixel(row[grad - L_NBG0], x, 0, p);
                uint32_t here = drawn ? p.rgb : 0;
                if (x == 0) prev[0] = prev[1] = here;
                blur[x] = avg(avg(prev[0], prev[1]), here);
                prev[0] = prev[1];
                prev[1] = here;
            }
        }
        for (int x = 0; x < f.w; ++x) {
            Pix l[L_COUNT];
            int top = -1, second = -1;
            auto consider = [&](int i) {
                if (!l[i].prio) return;
                if (top < 0 || l[i].prio > l[top].prio) { second = top; top = i; }
                else if (second < 0 || l[i].prio > l[second].prio) second = i;
            };
            // in the order that wins ties: sprite, then NBG0..NBG3
            l[L_SPRITE] = {};
            uint8_t shadow = 0;                  // the priority of a shadow dot here
            if (!windowed(wctl[L_SPRITE], win, x)) {
                switch (sprite_pixel(sprite_at(x), l[L_SPRITE])) {
                case S_DOT: consider(L_SPRITE); break;
                case S_SHADOW: shadow = l[L_SPRITE].prio; l[L_SPRITE] = {}; break;
                case S_NONE: break;
                }
            }
            Pix& rp = l[L_RBG0];
            rp = {};
            if (rbg.on && rbg.prio && !windowed(wctl[L_RBG0], win, x) && rbg_pixel(rbg, x, rp)) {
                rp.prio = rbg.prio;
                if ((sfprmd >> 8 & 3) == 1) rp.prio = (rbg.prio & 6) | rp.spr;
                rp.cc = rbg.cc;
                if ((sfccmd >> 8 & 3) == 1) rp.cc &= rp.scc;
                if ((sfccmd >> 8 & 3) == 3) rp.cc &= rp.msb;
                rp.ratio = rbg.ratio; rp.offset = rbg.offset; rp.offset_b = rbg.offset_b;
                consider(L_RBG0);
            }
            if constexpr (Sparse) {
            for (int active = 0; active < active_nbg_count; ++active) {
                const int n = active_nbg[active];
                Pix& p = l[L_NBG0 + n];
                p = {};
                const Nbg& s = row[n];
                if (windowed(wctl[L_NBG0 + n], win, x)) continue;
                if (!nbg_pixel(s, x, 0, p)) continue;
                p.prio = s.prio;
                if ((sfprmd >> (n * 2) & 3) == 1) p.prio = (uint8_t)((s.prio & 6) | p.spr);
                if (!p.prio) continue;
                switch (sfccmd >> (n * 2) & 3) {
                case 1: p.cc = s.cc && p.scc; break;
                case 3: p.cc = s.cc && p.msb; break;
                default: p.cc = s.cc; break;
                }
                p.ratio = s.ratio; p.offset = s.offset; p.offset_b = s.offset_b;
                consider(L_NBG0 + n);
            }
            } else {
            for (int n = 0; n < 4; ++n) {
                Pix& p = l[L_NBG0 + n];
                p = {};
                const Nbg& s = row[n];
                if (!s.on || !s.prio || windowed(wctl[L_NBG0 + n], win, x)) continue;
                if (!nbg_pixel(s, x, 0, p)) continue;
                p.prio = s.prio;
                if ((sfprmd >> (n * 2) & 3) == 1) p.prio = (uint8_t)((s.prio & 6) | p.spr);
                if (!p.prio) continue;
                switch (sfccmd >> (n * 2) & 3) {
                case 1: p.cc = s.cc && p.scc; break;
                case 3: p.cc = s.cc && p.msb; break;
                default: p.cc = s.cc; break;
                }
                p.ratio = s.ratio; p.offset = s.offset; p.offset_b = s.offset_b;
                consider(L_NBG0 + n);
            }
            }
            const Pix& t = top >= 0 ? l[top] : back;
            Pix u = top >= 0 && (lnclen >> (top == L_SPRITE ? 5 : top == L_RBG0 ? 4 : top - L_NBG0) & 1) && grad < 0 ? line_colour
                  : second >= 0 ? l[second] : back;
            if (grad >= 0 && (top == grad || second == grad)) u.rgb = blur[x];
            uint32_t rgb = t.rgb;
            if (top >= 0 && t.cc && !windowed(cc_wctl, win, x)) {
                uint32_t out = 0;
                int ratio = second_ratio ? u.ratio : t.ratio;
                for (int sh = 16; sh >= 0; sh -= 8) {
                    int a = (int)(t.rgb >> sh & 0xFF), b = (int)(u.rgb >> sh & 0xFF);
                    // ratio 0 is 31:1, not 32:0: the second image always shows through a little
                    int c = add ? std::min(a + b, 255) : (a * (31 - ratio) + b * (ratio + 1)) >> 5;
                    out |= (uint32_t)c << sh;
                }
                rgb = out;
            }
            if (t.offset) rgb = apply_offset(rgb, t.offset_b);
            // A shadow halves the top screen under it when SDCTL enables that screen (bit 5: the back screen).
            bool shaded = top == L_SPRITE ? t.shade
                        : shadow && shadow >= t.prio && (sdctl >> (top == L_RBG0 ? 4 : top >= 0 ? top - L_NBG0 : 5) & 1);
            if (shaded) rgb = rgb >> 1 & 0x7F7F7F;
            f.px[(size_t)y * f.w + x] = rgb;
        }
    }
}

// Choose once per frame, so dense scenes retain their original fixed loop
// without an extra active-list index or run-time branch in every pixel.
void vdp2_compose(Frame& f) {
    prepare_palette();
    int active = 0;
    for (int n = 0; n < 4; ++n) {
        Nbg layer;
        setup_nbg(n, layer);
        active += layer.on && layer.prio;
    }
    if (active <= 1) compose_frame<true>(f);
    else compose_frame<false>(f);
}

void vdp2_state(State& s) { s(g_vdp2_vram), s(g_vdp2_cram), s(g_vdp2_regs); }
