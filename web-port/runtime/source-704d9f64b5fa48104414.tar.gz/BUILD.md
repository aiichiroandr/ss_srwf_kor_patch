# Web runtime source snapshot

Runtime 704d9f64b5fa48104414. Includes generated translation units, runtime,
third-party sources/notices, and build adapters. No ROM or extracted game data
files are included. Execution requires the user's own supported disc image.

With Emscripten 6.0.13,
CMake and Ninja available:

emcmake cmake -S generated -B out -G Ninja -DCMAKE_PROJECT_INCLUDE_BEFORE="$PWD/tools/web-toolchain.cmake" -DSATURN_EXTRA="$PWD/tools/web-target.cmake" -DSATURN_NO_SDL=ON -DSATURN_VDP1_GPL=ON -DCMAKE_BUILD_TYPE=Release
cmake --build out --target saturn --parallel 4

See LICENSE and THIRD_PARTY.md for component notices, including GPL v2 or later
VDP1 code. This snapshot does not grant rights to the original game assets.
